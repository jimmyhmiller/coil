000000000000093c <_stogir.verify.integer-operations-target-structured>:
     93c: d10c03ff     	sub	sp, sp, #0x300
     940: f90003fd     	str	x29, [sp]
     944: f90007fe     	str	x30, [sp, #0x8]
     948: 910003fd     	mov	x29, sp
     94c: f9015bf3     	str	x19, [sp, #0x2b0]
     950: f9015ff4     	str	x20, [sp, #0x2b8]
     954: f90163f5     	str	x21, [sp, #0x2c0]
     958: f90167f6     	str	x22, [sp, #0x2c8]
     95c: f9016bf7     	str	x23, [sp, #0x2d0]
     960: f9016ff8     	str	x24, [sp, #0x2d8]
     964: f90173f9     	str	x25, [sp, #0x2e0]
     968: f90177fa     	str	x26, [sp, #0x2e8]
     96c: f9017bfb     	str	x27, [sp, #0x2f0]
     970: f9017ffc     	str	x28, [sp, #0x2f8]
     974: 2a1f0033     	orr	w19, w1, wzr
     978: 2a1f0034     	orr	w20, w1, wzr
     97c: 2a1f0035     	orr	w21, w1, wzr
     980: 9101e016     	add	x22, x0, #0x78
     984: 9100a017     	add	x23, x0, #0x28
     988: 91014018     	add	x24, x0, #0x50
     98c: 910083f0     	add	x16, sp, #0x20
     990: aa1f0201     	orr	x1, x16, xzr
     994: 91002039     	add	x25, x1, #0x8
     998: 910103f0     	add	x16, sp, #0x40
     99c: aa1f0201     	orr	x1, x16, xzr
     9a0: 9100203a     	add	x26, x1, #0x8
     9a4: 910343f0     	add	x16, sp, #0xd0
     9a8: aa1f0201     	orr	x1, x16, xzr
     9ac: 9100203b     	add	x27, x1, #0x8
     9b0: 9103c3f0     	add	x16, sp, #0xf0
     9b4: aa1f0201     	orr	x1, x16, xzr
     9b8: 9100203c     	add	x28, x1, #0x8
     9bc: 910443f0     	add	x16, sp, #0x110
     9c0: aa1f0201     	orr	x1, x16, xzr
     9c4: 91002021     	add	x1, x1, #0x8
     9c8: 9104c3f0     	add	x16, sp, #0x130
     9cc: aa1f0202     	orr	x2, x16, xzr
     9d0: 91002042     	add	x2, x2, #0x8
     9d4: 910543f0     	add	x16, sp, #0x150
     9d8: aa1f0203     	orr	x3, x16, xzr
     9dc: 91002063     	add	x3, x3, #0x8
     9e0: 9105c3f0     	add	x16, sp, #0x170
     9e4: aa1f0204     	orr	x4, x16, xzr
     9e8: 91002084     	add	x4, x4, #0x8
     9ec: 910643f0     	add	x16, sp, #0x190
     9f0: aa1f0205     	orr	x5, x16, xzr
     9f4: 910020a5     	add	x5, x5, #0x8
     9f8: 910783f0     	add	x16, sp, #0x1e0
     9fc: aa1f0206     	orr	x6, x16, xzr
     a00: 910020c6     	add	x6, x6, #0x8
     a04: d2800027     	mov	x7, #0x1                ; =1
     a08: d2e00009     	movz	x9, #0x0, lsl #48
     a0c: 9000000a     	adrp	x10, 0x0 <_gap_verify_graph>
     a10: f940014a     	ldr	x10, [x10]
     a14: d2e0000b     	movz	x11, #0x0, lsl #48
     a18: f100017f     	cmp	x11, #0x0
     a1c: 54006681     	b.ne	0x16ec <_stogir.verify.integer-operations-target-structured+0xdb0>
     a20: f940040c     	ldr	x12, [x0, #0x8]
     a24: eb0c00ff     	cmp	x7, x12
     a28: 540066ca     	b.ge	0x1700 <_stogir.verify.integer-operations-target-structured+0xdc4>
     a2c: f940000c     	ldr	x12, [x0]
     a30: 8b07118c     	add	x12, x12, x7, lsl #4
     a34: f940018d     	ldr	x13, [x12]
     a38: 53001dae     	uxtb	w14, w13
     a3c: f940058c     	ldr	x12, [x12, #0x8]
     a40: aa1f01cf     	orr	x15, x14, xzr
     a44: 910043f0     	add	x16, sp, #0x10
     a48: f900020d     	str	x13, [x16]
     a4c: 910043f0     	add	x16, sp, #0x10
     a50: f900060c     	str	x12, [x16, #0x8]
     a54: f9403c0c     	ldr	x12, [x0, #0x78]
     a58: b867798c     	ldr	w12, [x12, x7, lsl #2]
     a5c: f1020dff     	cmp	x15, #0x83
     a60: 540032aa     	b.ge	0x10b4 <_stogir.verify.integer-operations-target-structured+0x778>
     a64: 90000010     	adrp	x16, 0x0 <_gap_verify_graph>
     a68: f9400210     	ldr	x16, [x16]
     a6c: 786f7a0d     	ldrh	w13, [x16, x15, lsl #1]
     a70: f10039ff     	cmp	x15, #0xe
     a74: 5400650b     	b.lt	0x1714 <_stogir.verify.integer-operations-target-structured+0xdd8>
     a78: f90103e0     	str	x0, [sp, #0x200]
     a7c: f1005dff     	cmp	x15, #0x17
     a80: 1a9fc7e0     	cset	w0, le
     a84: d3401c00     	ubfx	x0, x0, #0, #8
     a88: f90107e0     	str	x0, [sp, #0x208]
     a8c: 2a1f00e0     	orr	w0, w7, wzr
     a90: f9010be1     	str	x1, [sp, #0x210]
     a94: 121e01a1     	and	w1, w13, #0x4
     a98: d3407c21     	ubfx	x1, x1, #0, #32
     a9c: f9011be8     	str	x8, [sp, #0x230]
     aa0: f90147e2     	str	x2, [sp, #0x288]
     aa4: 910043e2     	add	x2, sp, #0x10
     aa8: f9013fe3     	str	x3, [sp, #0x278]
     aac: 2a0c03e3     	mov	w3, w12
     ab0: f90137e4     	str	x4, [sp, #0x268]
     ab4: f90133e5     	str	x5, [sp, #0x260]
     ab8: f9012fe6     	str	x6, [sp, #0x258]
     abc: f9012be7     	str	x7, [sp, #0x250]
     ac0: b90273ee     	str	w14, [sp, #0x270]
     ac4: b90283ec     	str	w12, [sp, #0x280]
     ac8: b90293e0     	str	w0, [sp, #0x290]
     acc: b9021bf3     	str	w19, [sp, #0x218]
     ad0: 2a0d03f3     	mov	w19, w13
     ad4: b90223f4     	str	w20, [sp, #0x220]
     ad8: aa0903f4     	mov	x20, x9
     adc: b9022bf5     	str	w21, [sp, #0x228]
     ae0: aa0103f5     	mov	x21, x1
     ae4: 2a0003e1     	mov	w1, w0
     ae8: f94103e0     	ldr	x0, [sp, #0x200]
     aec: f9011ff8     	str	x24, [sp, #0x238]
     af0: aa0f03f8     	mov	x24, x15
     af4: f90123f7     	str	x23, [sp, #0x240]
     af8: aa0b03f7     	mov	x23, x11
     afc: f90127f6     	str	x22, [sp, #0x248]
     b00: aa0a03f6     	mov	x22, x10
     b04: 94000000     	bl	0xb04 <_stogir.verify.integer-operations-target-structured+0x1c8>
     b08: 53001c01     	uxtb	w1, w0
     b0c: f10002bf     	cmp	x21, #0x0
     b10: 54002da1     	b.ne	0x10c4 <_stogir.verify.integer-operations-target-structured+0x788>
     b14: f100003f     	cmp	x1, #0x0
     b18: 54002d61     	b.ne	0x10c4 <_stogir.verify.integer-operations-target-structured+0x788>
     b1c: f9014fe0     	str	x0, [sp, #0x298]
     b20: aa0103f5     	mov	x21, x1
     b24: f101131f     	cmp	x24, #0x44
     b28: 540002e1     	b.ne	0xb84 <_stogir.verify.integer-operations-target-structured+0x248>
     b2c: f10002bf     	cmp	x21, #0x0
     b30: 540002a1     	b.ne	0xb84 <_stogir.verify.integer-operations-target-structured+0x248>
     b34: 910103e8     	add	x8, sp, #0x40
     b38: f94103e0     	ldr	x0, [sp, #0x200]
     b3c: b94293e1     	ldr	w1, [sp, #0x290]
     b40: 94000000     	bl	0xb40 <_stogir.verify.integer-operations-target-structured+0x204>
     b44: 910103f0     	add	x16, sp, #0x40
     b48: b9400200     	ldr	w0, [x16]
     b4c: d340fc10     	lsr	x16, x0, #0
     b50: f100061f     	cmp	x16, #0x1
     b54: 540000e0     	b.eq	0xb70 <_stogir.verify.integer-operations-target-structured+0x234>
     b58: 54000043     	b.lo	0xb60 <_stogir.verify.integer-operations-target-structured+0x224>
     b5c: 14000006     	b	0xb74 <_stogir.verify.integer-operations-target-structured+0x238>
     b60: f100021f     	cmp	x16, #0x0
     b64: 54000040     	b.eq	0xb6c <_stogir.verify.integer-operations-target-structured+0x230>
     b68: 14000003     	b	0xb74 <_stogir.verify.integer-operations-target-structured+0x238>
     b6c: 14000171     	b	0x1130 <_stogir.verify.integer-operations-target-structured+0x7f4>
     b70: 14000002     	b	0xb78 <_stogir.verify.integer-operations-target-structured+0x23c>
     b74: 14000172     	b	0x113c <_stogir.verify.integer-operations-target-structured+0x800>
     b78: 910103f0     	add	x16, sp, #0x40
     b7c: f9400616     	ldr	x22, [x16, #0x8]
     b80: f9400757     	ldr	x23, [x26, #0x8]
     b84: f100771f     	cmp	x24, #0x1d
     b88: 54002de0     	b.eq	0x1144 <_stogir.verify.integer-operations-target-structured+0x808>
     b8c: f1007b1f     	cmp	x24, #0x1e
     b90: 54002da0     	b.eq	0x1144 <_stogir.verify.integer-operations-target-structured+0x808>
     b94: 121d0260     	and	w0, w19, #0x8
     b98: d3407c00     	ubfx	x0, x0, #0, #32
     b9c: f100001f     	cmp	x0, #0x0
     ba0: 540034e1     	b.ne	0x123c <_stogir.verify.integer-operations-target-structured+0x900>
     ba4: f100b31f     	cmp	x24, #0x2c
     ba8: 540034a0     	b.eq	0x123c <_stogir.verify.integer-operations-target-structured+0x900>
     bac: 121c0260     	and	w0, w19, #0x10
     bb0: d3407c00     	ubfx	x0, x0, #0, #32
     bb4: f100001f     	cmp	x0, #0x0
     bb8: 540002a0     	b.eq	0xc0c <_stogir.verify.integer-operations-target-structured+0x2d0>
     bbc: 910343e8     	add	x8, sp, #0xd0
     bc0: f94103e0     	ldr	x0, [sp, #0x200]
     bc4: b94293e1     	ldr	w1, [sp, #0x290]
     bc8: 94000000     	bl	0xbc8 <_stogir.verify.integer-operations-target-structured+0x28c>
     bcc: 910343f0     	add	x16, sp, #0xd0
     bd0: b9400200     	ldr	w0, [x16]
     bd4: d340fc10     	lsr	x16, x0, #0
     bd8: f100061f     	cmp	x16, #0x1
     bdc: 540000e0     	b.eq	0xbf8 <_stogir.verify.integer-operations-target-structured+0x2bc>
     be0: 54000043     	b.lo	0xbe8 <_stogir.verify.integer-operations-target-structured+0x2ac>
     be4: 14000006     	b	0xbfc <_stogir.verify.integer-operations-target-structured+0x2c0>
     be8: f100021f     	cmp	x16, #0x0
     bec: 54000040     	b.eq	0xbf4 <_stogir.verify.integer-operations-target-structured+0x2b8>
     bf0: 14000003     	b	0xbfc <_stogir.verify.integer-operations-target-structured+0x2c0>
     bf4: 140001bb     	b	0x12e0 <_stogir.verify.integer-operations-target-structured+0x9a4>
     bf8: 14000002     	b	0xc00 <_stogir.verify.integer-operations-target-structured+0x2c4>
     bfc: 140001bc     	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x9b0>
     c00: 910343f0     	add	x16, sp, #0xd0
     c04: f9400616     	ldr	x22, [x16, #0x8]
     c08: f9400777     	ldr	x23, [x27, #0x8]
     c0c: 121b0260     	and	w0, w19, #0x20
     c10: d3407c00     	ubfx	x0, x0, #0, #32
     c14: f100001f     	cmp	x0, #0x0
     c18: 540002a0     	b.eq	0xc6c <_stogir.verify.integer-operations-target-structured+0x330>
     c1c: 9103c3e8     	add	x8, sp, #0xf0
     c20: f94103e0     	ldr	x0, [sp, #0x200]
     c24: b94293e1     	ldr	w1, [sp, #0x290]
     c28: 94000000     	bl	0xc28 <_stogir.verify.integer-operations-target-structured+0x2ec>
     c2c: 9103c3f0     	add	x16, sp, #0xf0
     c30: b9400200     	ldr	w0, [x16]
     c34: d340fc10     	lsr	x16, x0, #0
     c38: f100061f     	cmp	x16, #0x1
     c3c: 540000e0     	b.eq	0xc58 <_stogir.verify.integer-operations-target-structured+0x31c>
     c40: 54000043     	b.lo	0xc48 <_stogir.verify.integer-operations-target-structured+0x30c>
     c44: 14000006     	b	0xc5c <_stogir.verify.integer-operations-target-structured+0x320>
     c48: f100021f     	cmp	x16, #0x0
     c4c: 54000040     	b.eq	0xc54 <_stogir.verify.integer-operations-target-structured+0x318>
     c50: 14000003     	b	0xc5c <_stogir.verify.integer-operations-target-structured+0x320>
     c54: 140001a8     	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x9b8>
     c58: 14000002     	b	0xc60 <_stogir.verify.integer-operations-target-structured+0x324>
     c5c: 140001a9     	b	0x1300 <_stogir.verify.integer-operations-target-structured+0x9c4>
     c60: 9103c3f0     	add	x16, sp, #0xf0
     c64: f9400616     	ldr	x22, [x16, #0x8]
     c68: f9400797     	ldr	x23, [x28, #0x8]
     c6c: 121a0260     	and	w0, w19, #0x40
     c70: d3407c00     	ubfx	x0, x0, #0, #32
     c74: f100001f     	cmp	x0, #0x0
     c78: 54005520     	b.eq	0x171c <_stogir.verify.integer-operations-target-structured+0xde0>
     c7c: 910443e8     	add	x8, sp, #0x110
     c80: f94103e0     	ldr	x0, [sp, #0x200]
     c84: b94293e1     	ldr	w1, [sp, #0x290]
     c88: 94000000     	bl	0xc88 <_stogir.verify.integer-operations-target-structured+0x34c>
     c8c: 910443f0     	add	x16, sp, #0x110
     c90: b9400200     	ldr	w0, [x16]
     c94: d340fc10     	lsr	x16, x0, #0
     c98: f100061f     	cmp	x16, #0x1
     c9c: 54000100     	b.eq	0xcbc <_stogir.verify.integer-operations-target-structured+0x380>
     ca0: 54000043     	b.lo	0xca8 <_stogir.verify.integer-operations-target-structured+0x36c>
     ca4: 14000007     	b	0xcc0 <_stogir.verify.integer-operations-target-structured+0x384>
     ca8: f100021f     	cmp	x16, #0x0
     cac: 54000040     	b.eq	0xcb4 <_stogir.verify.integer-operations-target-structured+0x378>
     cb0: 14000004     	b	0xcc0 <_stogir.verify.integer-operations-target-structured+0x384>
     cb4: f9410be0     	ldr	x0, [sp, #0x210]
     cb8: 14000194     	b	0x1308 <_stogir.verify.integer-operations-target-structured+0x9cc>
     cbc: 14000002     	b	0xcc4 <_stogir.verify.integer-operations-target-structured+0x388>
     cc0: 14000195     	b	0x1314 <_stogir.verify.integer-operations-target-structured+0x9d8>
     cc4: 910443f0     	add	x16, sp, #0x110
     cc8: f9400616     	ldr	x22, [x16, #0x8]
     ccc: f9410be0     	ldr	x0, [sp, #0x210]
     cd0: f9400417     	ldr	x23, [x0, #0x8]
     cd4: 12190261     	and	w1, w19, #0x80
     cd8: d3407c21     	ubfx	x1, x1, #0, #32
     cdc: f100003f     	cmp	x1, #0x0
     ce0: 54005220     	b.eq	0x1724 <_stogir.verify.integer-operations-target-structured+0xde8>
     ce4: 9104c3e8     	add	x8, sp, #0x130
     ce8: b94293e1     	ldr	w1, [sp, #0x290]
     cec: f9010be0     	str	x0, [sp, #0x210]
     cf0: f94103e0     	ldr	x0, [sp, #0x200]
     cf4: 94000000     	bl	0xcf4 <_stogir.verify.integer-operations-target-structured+0x3b8>
     cf8: 9104c3f0     	add	x16, sp, #0x130
     cfc: b9400200     	ldr	w0, [x16]
     d00: d340fc10     	lsr	x16, x0, #0
     d04: f100061f     	cmp	x16, #0x1
     d08: 54000100     	b.eq	0xd28 <_stogir.verify.integer-operations-target-structured+0x3ec>
     d0c: 54000043     	b.lo	0xd14 <_stogir.verify.integer-operations-target-structured+0x3d8>
     d10: 14000007     	b	0xd2c <_stogir.verify.integer-operations-target-structured+0x3f0>
     d14: f100021f     	cmp	x16, #0x0
     d18: 54000040     	b.eq	0xd20 <_stogir.verify.integer-operations-target-structured+0x3e4>
     d1c: 14000004     	b	0xd2c <_stogir.verify.integer-operations-target-structured+0x3f0>
     d20: f94147e0     	ldr	x0, [sp, #0x288]
     d24: 1400017e     	b	0x131c <_stogir.verify.integer-operations-target-structured+0x9e0>
     d28: 14000002     	b	0xd30 <_stogir.verify.integer-operations-target-structured+0x3f4>
     d2c: 1400017f     	b	0x1328 <_stogir.verify.integer-operations-target-structured+0x9ec>
     d30: 9104c3f0     	add	x16, sp, #0x130
     d34: f9400616     	ldr	x22, [x16, #0x8]
     d38: f94147e0     	ldr	x0, [sp, #0x288]
     d3c: f9400417     	ldr	x23, [x0, #0x8]
     d40: 12180261     	and	w1, w19, #0x100
     d44: d3407c21     	ubfx	x1, x1, #0, #32
     d48: f100003f     	cmp	x1, #0x0
     d4c: 54004f20     	b.eq	0x1730 <_stogir.verify.integer-operations-target-structured+0xdf4>
     d50: 910543e8     	add	x8, sp, #0x150
     d54: b94293e1     	ldr	w1, [sp, #0x290]
     d58: b94223e2     	ldr	w2, [sp, #0x220]
     d5c: f90147e0     	str	x0, [sp, #0x288]
     d60: f94103e0     	ldr	x0, [sp, #0x200]
     d64: 94000000     	bl	0xd64 <_stogir.verify.integer-operations-target-structured+0x428>
     d68: 910543f0     	add	x16, sp, #0x150
     d6c: b9400200     	ldr	w0, [x16]
     d70: d340fc10     	lsr	x16, x0, #0
     d74: f100061f     	cmp	x16, #0x1
     d78: 54000100     	b.eq	0xd98 <_stogir.verify.integer-operations-target-structured+0x45c>
     d7c: 54000043     	b.lo	0xd84 <_stogir.verify.integer-operations-target-structured+0x448>
     d80: 14000007     	b	0xd9c <_stogir.verify.integer-operations-target-structured+0x460>
     d84: f100021f     	cmp	x16, #0x0
     d88: 54000040     	b.eq	0xd90 <_stogir.verify.integer-operations-target-structured+0x454>
     d8c: 14000004     	b	0xd9c <_stogir.verify.integer-operations-target-structured+0x460>
     d90: f9413fe0     	ldr	x0, [sp, #0x278]
     d94: 14000167     	b	0x1330 <_stogir.verify.integer-operations-target-structured+0x9f4>
     d98: 14000002     	b	0xda0 <_stogir.verify.integer-operations-target-structured+0x464>
     d9c: 14000168     	b	0x133c <_stogir.verify.integer-operations-target-structured+0xa00>
     da0: 910543f0     	add	x16, sp, #0x150
     da4: f9400616     	ldr	x22, [x16, #0x8]
     da8: f9413fe0     	ldr	x0, [sp, #0x278]
     dac: f9400417     	ldr	x23, [x0, #0x8]
     db0: 12170261     	and	w1, w19, #0x200
     db4: d3407c21     	ubfx	x1, x1, #0, #32
     db8: f100003f     	cmp	x1, #0x0
     dbc: 54004c00     	b.eq	0x173c <_stogir.verify.integer-operations-target-structured+0xe00>
     dc0: 9105c3e8     	add	x8, sp, #0x170
     dc4: b94293e1     	ldr	w1, [sp, #0x290]
     dc8: b9422be2     	ldr	w2, [sp, #0x228]
     dcc: f9013fe0     	str	x0, [sp, #0x278]
     dd0: f94103e0     	ldr	x0, [sp, #0x200]
     dd4: 94000000     	bl	0xdd4 <_stogir.verify.integer-operations-target-structured+0x498>
     dd8: 9105c3f0     	add	x16, sp, #0x170
     ddc: b9400200     	ldr	w0, [x16]
     de0: d340fc10     	lsr	x16, x0, #0
     de4: f100061f     	cmp	x16, #0x1
     de8: 54000100     	b.eq	0xe08 <_stogir.verify.integer-operations-target-structured+0x4cc>
     dec: 54000043     	b.lo	0xdf4 <_stogir.verify.integer-operations-target-structured+0x4b8>
     df0: 14000007     	b	0xe0c <_stogir.verify.integer-operations-target-structured+0x4d0>
     df4: f100021f     	cmp	x16, #0x0
     df8: 54000040     	b.eq	0xe00 <_stogir.verify.integer-operations-target-structured+0x4c4>
     dfc: 14000004     	b	0xe0c <_stogir.verify.integer-operations-target-structured+0x4d0>
     e00: f94137e0     	ldr	x0, [sp, #0x268]
     e04: 14000150     	b	0x1344 <_stogir.verify.integer-operations-target-structured+0xa08>
     e08: 14000002     	b	0xe10 <_stogir.verify.integer-operations-target-structured+0x4d4>
     e0c: 14000151     	b	0x1350 <_stogir.verify.integer-operations-target-structured+0xa14>
     e10: 9105c3f0     	add	x16, sp, #0x170
     e14: f9400616     	ldr	x22, [x16, #0x8]
     e18: f94137e0     	ldr	x0, [sp, #0x268]
     e1c: f9400417     	ldr	x23, [x0, #0x8]
     e20: f100f31f     	cmp	x24, #0x3c
     e24: 54004921     	b.ne	0x1748 <_stogir.verify.integer-operations-target-structured+0xe0c>
     e28: 910643e8     	add	x8, sp, #0x190
     e2c: b94293e1     	ldr	w1, [sp, #0x290]
     e30: f90137e0     	str	x0, [sp, #0x268]
     e34: f94103e0     	ldr	x0, [sp, #0x200]
     e38: 94000000     	bl	0xe38 <_stogir.verify.integer-operations-target-structured+0x4fc>
     e3c: 910643f0     	add	x16, sp, #0x190
     e40: b9400200     	ldr	w0, [x16]
     e44: d340fc10     	lsr	x16, x0, #0
     e48: f100061f     	cmp	x16, #0x1
     e4c: 54000100     	b.eq	0xe6c <_stogir.verify.integer-operations-target-structured+0x530>
     e50: 54000043     	b.lo	0xe58 <_stogir.verify.integer-operations-target-structured+0x51c>
     e54: 14000007     	b	0xe70 <_stogir.verify.integer-operations-target-structured+0x534>
     e58: f100021f     	cmp	x16, #0x0
     e5c: 54000040     	b.eq	0xe64 <_stogir.verify.integer-operations-target-structured+0x528>
     e60: 14000004     	b	0xe70 <_stogir.verify.integer-operations-target-structured+0x534>
     e64: f94133e0     	ldr	x0, [sp, #0x260]
     e68: 1400013c     	b	0x1358 <_stogir.verify.integer-operations-target-structured+0xa1c>
     e6c: 14000002     	b	0xe74 <_stogir.verify.integer-operations-target-structured+0x538>
     e70: 1400013d     	b	0x1364 <_stogir.verify.integer-operations-target-structured+0xa28>
     e74: 910643f0     	add	x16, sp, #0x190
     e78: f9400616     	ldr	x22, [x16, #0x8]
     e7c: f94133e0     	ldr	x0, [sp, #0x260]
     e80: f9400417     	ldr	x23, [x0, #0x8]
     e84: f101e31f     	cmp	x24, #0x78
     e88: 54004661     	b.ne	0x1754 <_stogir.verify.integer-operations-target-structured+0xe18>
     e8c: 910043f0     	add	x16, sp, #0x10
     e90: b9400201     	ldr	w1, [x16]
     e94: d3483c21     	ubfx	x1, x1, #8, #8
     e98: f100003f     	cmp	x1, #0x0
     e9c: 54002681     	b.ne	0x136c <_stogir.verify.integer-operations-target-structured+0xa30>
     ea0: 910043f0     	add	x16, sp, #0x10
     ea4: b9400a01     	ldr	w1, [x16, #0x8]
     ea8: 93407c21     	sxtw	x1, w1
     eac: f100003f     	cmp	x1, #0x0
     eb0: 54000080     	b.eq	0xec0 <_stogir.verify.integer-operations-target-structured+0x584>
     eb4: 90000016     	adrp	x22, 0x0 <_gap_verify_graph>
     eb8: f94002d6     	ldr	x22, [x22]
     ebc: d28003f7     	mov	x23, #0x1f              ; =31
     ec0: f90133e0     	str	x0, [sp, #0x260]
     ec4: 91000680     	add	x0, x20, #0x1
     ec8: 93407c14     	sxtw	x20, w0
     ecc: f9414fe0     	ldr	x0, [sp, #0x298]
     ed0: 53003c00     	uxth	w0, w0
     ed4: 52800111     	mov	w17, #0x8               ; =8
     ed8: 53003c10     	uxth	w16, w0
     edc: 53000e31     	ubfx	w17, w17, #0, #4
     ee0: 1ad12600     	lsr	w0, w16, w17
     ee4: 53003c00     	uxth	w0, w0
     ee8: 53001c00     	uxtb	w0, w0
     eec: f100001f     	cmp	x0, #0x0
     ef0: 54004360     	b.eq	0x175c <_stogir.verify.integer-operations-target-structured+0xe20>
     ef4: 910783e8     	add	x8, sp, #0x1e0
     ef8: b94293e1     	ldr	w1, [sp, #0x290]
     efc: f90153f9     	str	x25, [sp, #0x2a0]
     f00: aa0003f9     	mov	x25, x0
     f04: f94103e0     	ldr	x0, [sp, #0x200]
     f08: 94000000     	bl	0xf08 <_stogir.verify.integer-operations-target-structured+0x5cc>
     f0c: 910783f0     	add	x16, sp, #0x1e0
     f10: b9400200     	ldr	w0, [x16]
     f14: d340fc10     	lsr	x16, x0, #0
     f18: f100061f     	cmp	x16, #0x1
     f1c: 54000100     	b.eq	0xf3c <_stogir.verify.integer-operations-target-structured+0x600>
     f20: 54000043     	b.lo	0xf28 <_stogir.verify.integer-operations-target-structured+0x5ec>
     f24: 14000007     	b	0xf40 <_stogir.verify.integer-operations-target-structured+0x604>
     f28: f100021f     	cmp	x16, #0x0
     f2c: 54000040     	b.eq	0xf34 <_stogir.verify.integer-operations-target-structured+0x5f8>
     f30: 14000004     	b	0xf40 <_stogir.verify.integer-operations-target-structured+0x604>
     f34: f9412fe0     	ldr	x0, [sp, #0x258]
     f38: 14000133     	b	0x1404 <_stogir.verify.integer-operations-target-structured+0xac8>
     f3c: 14000002     	b	0xf44 <_stogir.verify.integer-operations-target-structured+0x608>
     f40: 14000134     	b	0x1410 <_stogir.verify.integer-operations-target-structured+0xad4>
     f44: 910783f0     	add	x16, sp, #0x1e0
     f48: f9400616     	ldr	x22, [x16, #0x8]
     f4c: f9412fe0     	ldr	x0, [sp, #0x258]
     f50: f9400417     	ldr	x23, [x0, #0x8]
     f54: f10002bf     	cmp	x21, #0x0
     f58: 540040a1     	b.ne	0x176c <_stogir.verify.integer-operations-target-structured+0xe30>
     f5c: f100033f     	cmp	x25, #0x0
     f60: 540040c1     	b.ne	0x1778 <_stogir.verify.integer-operations-target-structured+0xe3c>
     f64: 12000261     	and	w1, w19, #0x1
     f68: 121f0262     	and	w2, w19, #0x2
     f6c: d3407c33     	ubfx	x19, x1, #0, #32
     f70: d3407c42     	ubfx	x2, x2, #0, #32
     f74: f94107f5     	ldr	x21, [sp, #0x208]
     f78: f10002bf     	cmp	x21, #0x0
     f7c: 540000a1     	b.ne	0xf90 <_stogir.verify.integer-operations-target-structured+0x654>
     f80: f100027f     	cmp	x19, #0x0
     f84: 54000061     	b.ne	0xf90 <_stogir.verify.integer-operations-target-structured+0x654>
     f88: f100005f     	cmp	x2, #0x0
     f8c: 54003fc0     	b.eq	0x1784 <_stogir.verify.integer-operations-target-structured+0xe48>
     f90: 910043f0     	add	x16, sp, #0x10
     f94: b9400601     	ldr	w1, [x16, #0x4]
     f98: 93407c21     	sxtw	x1, w1
     f9c: d2e00010     	movz	x16, #0x0, lsl #48
     fa0: cb010203     	sub	x3, x16, x1
     fa4: d1000464     	sub	x4, x3, #0x1
     fa8: f100003f     	cmp	x1, #0x0
     fac: 54003f2d     	b.le	0x1790 <_stogir.verify.integer-operations-target-structured+0xe54>
     fb0: f94103f9     	ldr	x25, [sp, #0x200]
     fb4: f9400723     	ldr	x3, [x25, #0x8]
     fb8: eb03003f     	cmp	x1, x3
     fbc: 54003f0a     	b.ge	0x179c <_stogir.verify.integer-operations-target-structured+0xe60>
     fc0: f94127e5     	ldr	x5, [sp, #0x248]
     fc4: f94004a3     	ldr	x3, [x5, #0x8]
     fc8: eb03003f     	cmp	x1, x3
     fcc: 5400226a     	b.ge	0x1418 <_stogir.verify.integer-operations-target-structured+0xadc>
     fd0: f9403f23     	ldr	x3, [x25, #0x78]
     fd4: b8617863     	ldr	w3, [x3, x1, lsl #2]
     fd8: 93407c63     	sxtw	x3, w3
     fdc: f100007f     	cmp	x3, #0x0
     fe0: 1a9fb7e3     	cset	w3, ge
     fe4: d3401c63     	ubfx	x3, x3, #0, #8
     fe8: f94123e6     	ldr	x6, [sp, #0x240]
     fec: f9411fe8     	ldr	x8, [sp, #0x238]
     ff0: f100007f     	cmp	x3, #0x0
     ff4: 540024e0     	b.eq	0x1490 <_stogir.verify.integer-operations-target-structured+0xb54>
     ff8: f100003f     	cmp	x1, #0x0
     ffc: 5400244d     	b.le	0x1484 <_stogir.verify.integer-operations-target-structured+0xb48>
    1000: f9400323     	ldr	x3, [x25]
    1004: 8b011061     	add	x1, x3, x1, lsl #4
    1008: f100003f     	cmp	x1, #0x0
    100c: 54002461     	b.ne	0x1498 <_stogir.verify.integer-operations-target-structured+0xb5c>
    1010: f90103f9     	str	x25, [sp, #0x200]
    1014: f90127e5     	str	x5, [sp, #0x248]
    1018: f90157fa     	str	x26, [sp, #0x2a8]
    101c: f9012fe0     	str	x0, [sp, #0x258]
    1020: f90123e6     	str	x6, [sp, #0x240]
    1024: f9011fe8     	str	x8, [sp, #0x238]
    1028: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    102c: f94002d6     	ldr	x22, [x22]
    1030: d28002f7     	mov	x23, #0x17              ; =23
    1034: 91000680     	add	x0, x20, #0x1
    1038: 93407c14     	sxtw	x20, w0
    103c: b94283e0     	ldr	w0, [sp, #0x280]
    1040: 93407c00     	sxtw	x0, w0
    1044: 91001000     	add	x0, x0, #0x4
    1048: 937ffc10     	asr	x16, x0, #63
    104c: d37efe10     	lsr	x16, x16, #62
    1050: 8b100000     	add	x0, x0, x16
    1054: 9342fc00     	asr	x0, x0, #2
    1058: f9412be1     	ldr	x1, [sp, #0x250]
    105c: 8b010001     	add	x1, x0, x1
    1060: f9411be8     	ldr	x8, [sp, #0x230]
    1064: f94103e0     	ldr	x0, [sp, #0x200]
    1068: b9421bf3     	ldr	w19, [sp, #0x218]
    106c: f94153f9     	ldr	x25, [sp, #0x2a0]
    1070: f94157fa     	ldr	x26, [sp, #0x2a8]
    1074: f94147e2     	ldr	x2, [sp, #0x288]
    1078: f9413fe3     	ldr	x3, [sp, #0x278]
    107c: b9422bf5     	ldr	w21, [sp, #0x228]
    1080: f94137e4     	ldr	x4, [sp, #0x268]
    1084: f94133e5     	ldr	x5, [sp, #0x260]
    1088: f9412fe6     	ldr	x6, [sp, #0x258]
    108c: f9411ff8     	ldr	x24, [sp, #0x238]
    1090: aa0103e7     	mov	x7, x1
    1094: f9410be1     	ldr	x1, [sp, #0x210]
    1098: aa1403e9     	mov	x9, x20
    109c: b94223f4     	ldr	w20, [sp, #0x220]
    10a0: aa1603ea     	mov	x10, x22
    10a4: f94127f6     	ldr	x22, [sp, #0x248]
    10a8: aa1703eb     	mov	x11, x23
    10ac: f94123f7     	ldr	x23, [sp, #0x240]
    10b0: 17fffe5a     	b	0xa18 <_stogir.verify.integer-operations-target-structured+0xdc>
    10b4: 52a0000d     	movz	w13, #0x0, lsl #16
    10b8: 17fffe6e     	b	0xa70 <_stogir.verify.integer-operations-target-structured+0x134>
    10bc: d2e00000     	movz	x0, #0x0, lsl #48
    10c0: 17fffe72     	b	0xa88 <_stogir.verify.integer-operations-target-structured+0x14c>
    10c4: 910083e8     	add	x8, sp, #0x20
    10c8: b9421be2     	ldr	w2, [sp, #0x218]
    10cc: f9014fe0     	str	x0, [sp, #0x298]
    10d0: f94103e0     	ldr	x0, [sp, #0x200]
    10d4: aa0103f5     	mov	x21, x1
    10d8: b94293e1     	ldr	w1, [sp, #0x290]
    10dc: 94000000     	bl	0x10dc <_stogir.verify.integer-operations-target-structured+0x7a0>
    10e0: 910083f0     	add	x16, sp, #0x20
    10e4: b9400200     	ldr	w0, [x16]
    10e8: d340fc10     	lsr	x16, x0, #0
    10ec: f100061f     	cmp	x16, #0x1
    10f0: 540000e0     	b.eq	0x110c <_stogir.verify.integer-operations-target-structured+0x7d0>
    10f4: 54000043     	b.lo	0x10fc <_stogir.verify.integer-operations-target-structured+0x7c0>
    10f8: 14000006     	b	0x1110 <_stogir.verify.integer-operations-target-structured+0x7d4>
    10fc: f100021f     	cmp	x16, #0x0
    1100: 54000040     	b.eq	0x1108 <_stogir.verify.integer-operations-target-structured+0x7cc>
    1104: 14000003     	b	0x1110 <_stogir.verify.integer-operations-target-structured+0x7d4>
    1108: 14000007     	b	0x1124 <_stogir.verify.integer-operations-target-structured+0x7e8>
    110c: 14000002     	b	0x1114 <_stogir.verify.integer-operations-target-structured+0x7d8>
    1110: 1400015c     	b	0x1680 <_stogir.verify.integer-operations-target-structured+0xd44>
    1114: 910083f0     	add	x16, sp, #0x20
    1118: f9400616     	ldr	x22, [x16, #0x8]
    111c: f9400737     	ldr	x23, [x25, #0x8]
    1120: 17fffe81     	b	0xb24 <_stogir.verify.integer-operations-target-structured+0x1e8>
    1124: 91000680     	add	x0, x20, #0x1
    1128: 93407c14     	sxtw	x20, w0
    112c: 17fffffd     	b	0x1120 <_stogir.verify.integer-operations-target-structured+0x7e4>
    1130: 91000680     	add	x0, x20, #0x1
    1134: 93407c14     	sxtw	x20, w0
    1138: 17fffe93     	b	0xb84 <_stogir.verify.integer-operations-target-structured+0x248>
    113c: d4200000     	brk	#0
    1140: 17ffffff     	b	0x113c <_stogir.verify.integer-operations-target-structured+0x800>
    1144: 910043f0     	add	x16, sp, #0x10
    1148: b9400e00     	ldr	w0, [x16, #0xc]
    114c: 93407c01     	sxtw	x1, w0
    1150: f100003f     	cmp	x1, #0x0
    1154: 54ffd200     	b.eq	0xb94 <_stogir.verify.integer-operations-target-structured+0x258>
    1158: 910183e8     	add	x8, sp, #0x60
    115c: 2a0003e1     	mov	w1, w0
    1160: f94103e0     	ldr	x0, [sp, #0x200]
    1164: 94000000     	bl	0x1164 <_stogir.verify.integer-operations-target-structured+0x828>
    1168: 910183f0     	add	x16, sp, #0x60
    116c: b9400200     	ldr	w0, [x16]
    1170: d340fc10     	lsr	x16, x0, #0
    1174: f100061f     	cmp	x16, #0x1
    1178: 540000e0     	b.eq	0x1194 <_stogir.verify.integer-operations-target-structured+0x858>
    117c: 54000043     	b.lo	0x1184 <_stogir.verify.integer-operations-target-structured+0x848>
    1180: 14000006     	b	0x1198 <_stogir.verify.integer-operations-target-structured+0x85c>
    1184: f100021f     	cmp	x16, #0x0
    1188: 54000040     	b.eq	0x1190 <_stogir.verify.integer-operations-target-structured+0x854>
    118c: 14000003     	b	0x1198 <_stogir.verify.integer-operations-target-structured+0x85c>
    1190: 14000003     	b	0x119c <_stogir.verify.integer-operations-target-structured+0x860>
    1194: 14000006     	b	0x11ac <_stogir.verify.integer-operations-target-structured+0x870>
    1198: 14000027     	b	0x1234 <_stogir.verify.integer-operations-target-structured+0x8f8>
    119c: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    11a0: f94002d6     	ldr	x22, [x22]
    11a4: d28002d7     	mov	x23, #0x16              ; =22
    11a8: 17fffe7b     	b	0xb94 <_stogir.verify.integer-operations-target-structured+0x258>
    11ac: 910183f0     	add	x16, sp, #0x60
    11b0: f9400600     	ldr	x0, [x16, #0x8]
    11b4: 910043f0     	add	x16, sp, #0x10
    11b8: b9400e01     	ldr	w1, [x16, #0xc]
    11bc: 93407c21     	sxtw	x1, w1
    11c0: f100003f     	cmp	x1, #0x0
    11c4: 540002cb     	b.lt	0x121c <_stogir.verify.integer-operations-target-structured+0x8e0>
    11c8: 53001c00     	uxtb	w0, w0
    11cc: f1020c1f     	cmp	x0, #0x83
    11d0: 540002ea     	b.ge	0x122c <_stogir.verify.integer-operations-target-structured+0x8f0>
    11d4: 90000011     	adrp	x17, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    11d8: f9400231     	ldr	x17, [x17]
    11dc: 38716801     	ldrb	w1, [x0, x17]
    11e0: 53001c30     	uxtb	w16, w1
    11e4: 121f0201     	and	w1, w16, #0x2
    11e8: 53001c21     	uxtb	w1, w1
    11ec: d3401c21     	ubfx	x1, x1, #0, #8
    11f0: f100003f     	cmp	x1, #0x0
    11f4: 1a9f17e1     	cset	w1, eq
    11f8: 53001c30     	uxtb	w16, w1
    11fc: 6b1f021f     	cmp	w16, wzr
    1200: 9a9f17e1     	cset	x1, eq
    1204: f100003f     	cmp	x1, #0x0
    1208: 54000101     	b.ne	0x1228 <_stogir.verify.integer-operations-target-structured+0x8ec>
    120c: f101941f     	cmp	x0, #0x65
    1210: 540000c0     	b.eq	0x1228 <_stogir.verify.integer-operations-target-structured+0x8ec>
    1214: f101981f     	cmp	x0, #0x66
    1218: 54000080     	b.eq	0x1228 <_stogir.verify.integer-operations-target-structured+0x8ec>
    121c: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1220: f94002d6     	ldr	x22, [x22]
    1224: d28005b7     	mov	x23, #0x2d              ; =45
    1228: 17ffffe0     	b	0x11a8 <_stogir.verify.integer-operations-target-structured+0x86c>
    122c: 52a00001     	movz	w1, #0x0, lsl #16
    1230: 17ffffec     	b	0x11e0 <_stogir.verify.integer-operations-target-structured+0x8a4>
    1234: d4200000     	brk	#0
    1238: 17ffffff     	b	0x1234 <_stogir.verify.integer-operations-target-structured+0x8f8>
    123c: f100b31f     	cmp	x24, #0x2c
    1240: 54000341     	b.ne	0x12a8 <_stogir.verify.integer-operations-target-structured+0x96c>
    1244: 910243e8     	add	x8, sp, #0x90
    1248: f94103e0     	ldr	x0, [sp, #0x200]
    124c: b94293e1     	ldr	w1, [sp, #0x290]
    1250: 94000000     	bl	0x1250 <_stogir.verify.integer-operations-target-structured+0x914>
    1254: 910243f0     	add	x16, sp, #0x90
    1258: f9400200     	ldr	x0, [x16]
    125c: 910243f0     	add	x16, sp, #0x90
    1260: f9400601     	ldr	x1, [x16, #0x8]
    1264: 910243f0     	add	x16, sp, #0x90
    1268: f9400a02     	ldr	x2, [x16, #0x10]
    126c: d3407c00     	ubfx	x0, x0, #0, #32
    1270: d340fc10     	lsr	x16, x0, #0
    1274: f100061f     	cmp	x16, #0x1
    1278: 540000e0     	b.eq	0x1294 <_stogir.verify.integer-operations-target-structured+0x958>
    127c: 54000043     	b.lo	0x1284 <_stogir.verify.integer-operations-target-structured+0x948>
    1280: 14000006     	b	0x1298 <_stogir.verify.integer-operations-target-structured+0x95c>
    1284: f100021f     	cmp	x16, #0x0
    1288: 54000040     	b.eq	0x1290 <_stogir.verify.integer-operations-target-structured+0x954>
    128c: 14000003     	b	0x1298 <_stogir.verify.integer-operations-target-structured+0x95c>
    1290: 14000011     	b	0x12d4 <_stogir.verify.integer-operations-target-structured+0x998>
    1294: 14000002     	b	0x129c <_stogir.verify.integer-operations-target-structured+0x960>
    1298: 140000f8     	b	0x1678 <_stogir.verify.integer-operations-target-structured+0xd3c>
    129c: aa0103f6     	mov	x22, x1
    12a0: aa0203f7     	mov	x23, x2
    12a4: 17fffe42     	b	0xbac <_stogir.verify.integer-operations-target-structured+0x270>
    12a8: 9102c3e8     	add	x8, sp, #0xb0
    12ac: f94103e0     	ldr	x0, [sp, #0x200]
    12b0: b94293e1     	ldr	w1, [sp, #0x290]
    12b4: 94000000     	bl	0x12b4 <_stogir.verify.integer-operations-target-structured+0x978>
    12b8: 9102c3f0     	add	x16, sp, #0xb0
    12bc: f9400200     	ldr	x0, [x16]
    12c0: 9102c3f0     	add	x16, sp, #0xb0
    12c4: f9400601     	ldr	x1, [x16, #0x8]
    12c8: 9102c3f0     	add	x16, sp, #0xb0
    12cc: f9400a02     	ldr	x2, [x16, #0x10]
    12d0: 17ffffe7     	b	0x126c <_stogir.verify.integer-operations-target-structured+0x930>
    12d4: 91000680     	add	x0, x20, #0x1
    12d8: 93407c14     	sxtw	x20, w0
    12dc: 17fffff2     	b	0x12a4 <_stogir.verify.integer-operations-target-structured+0x968>
    12e0: 91000680     	add	x0, x20, #0x1
    12e4: 93407c14     	sxtw	x20, w0
    12e8: 17fffe49     	b	0xc0c <_stogir.verify.integer-operations-target-structured+0x2d0>
    12ec: d4200000     	brk	#0
    12f0: 17ffffff     	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x9b0>
    12f4: 91000680     	add	x0, x20, #0x1
    12f8: 93407c14     	sxtw	x20, w0
    12fc: 17fffe5c     	b	0xc6c <_stogir.verify.integer-operations-target-structured+0x330>
    1300: d4200000     	brk	#0
    1304: 17ffffff     	b	0x1300 <_stogir.verify.integer-operations-target-structured+0x9c4>
    1308: 91000681     	add	x1, x20, #0x1
    130c: 93407c34     	sxtw	x20, w1
    1310: 17fffe71     	b	0xcd4 <_stogir.verify.integer-operations-target-structured+0x398>
    1314: d4200000     	brk	#0
    1318: 17ffffff     	b	0x1314 <_stogir.verify.integer-operations-target-structured+0x9d8>
    131c: 91000681     	add	x1, x20, #0x1
    1320: 93407c34     	sxtw	x20, w1
    1324: 17fffe87     	b	0xd40 <_stogir.verify.integer-operations-target-structured+0x404>
    1328: d4200000     	brk	#0
    132c: 17ffffff     	b	0x1328 <_stogir.verify.integer-operations-target-structured+0x9ec>
    1330: 91000681     	add	x1, x20, #0x1
    1334: 93407c34     	sxtw	x20, w1
    1338: 17fffe9e     	b	0xdb0 <_stogir.verify.integer-operations-target-structured+0x474>
    133c: d4200000     	brk	#0
    1340: 17ffffff     	b	0x133c <_stogir.verify.integer-operations-target-structured+0xa00>
    1344: 91000681     	add	x1, x20, #0x1
    1348: 93407c34     	sxtw	x20, w1
    134c: 17fffeb5     	b	0xe20 <_stogir.verify.integer-operations-target-structured+0x4e4>
    1350: d4200000     	brk	#0
    1354: 17ffffff     	b	0x1350 <_stogir.verify.integer-operations-target-structured+0xa14>
    1358: 91000681     	add	x1, x20, #0x1
    135c: 93407c34     	sxtw	x20, w1
    1360: 17fffec9     	b	0xe84 <_stogir.verify.integer-operations-target-structured+0x548>
    1364: d4200000     	brk	#0
    1368: 17ffffff     	b	0x1364 <_stogir.verify.integer-operations-target-structured+0xa28>
    136c: 910043f0     	add	x16, sp, #0x10
    1370: b9400a01     	ldr	w1, [x16, #0x8]
    1374: 9106c3e8     	add	x8, sp, #0x1b0
    1378: f90133e0     	str	x0, [sp, #0x260]
    137c: f94103e0     	ldr	x0, [sp, #0x200]
    1380: 94000000     	bl	0x1380 <_stogir.verify.integer-operations-target-structured+0xa44>
    1384: 9106c3f0     	add	x16, sp, #0x1b0
    1388: b9400200     	ldr	w0, [x16]
    138c: d340fc10     	lsr	x16, x0, #0
    1390: f100061f     	cmp	x16, #0x1
    1394: 540000e0     	b.eq	0x13b0 <_stogir.verify.integer-operations-target-structured+0xa74>
    1398: 54000043     	b.lo	0x13a0 <_stogir.verify.integer-operations-target-structured+0xa64>
    139c: 14000006     	b	0x13b4 <_stogir.verify.integer-operations-target-structured+0xa78>
    13a0: f100021f     	cmp	x16, #0x0
    13a4: 54000040     	b.eq	0x13ac <_stogir.verify.integer-operations-target-structured+0xa70>
    13a8: 14000003     	b	0x13b4 <_stogir.verify.integer-operations-target-structured+0xa78>
    13ac: 14000003     	b	0x13b8 <_stogir.verify.integer-operations-target-structured+0xa7c>
    13b0: 14000006     	b	0x13c8 <_stogir.verify.integer-operations-target-structured+0xa8c>
    13b4: 14000012     	b	0x13fc <_stogir.verify.integer-operations-target-structured+0xac0>
    13b8: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    13bc: f94002d6     	ldr	x22, [x22]
    13c0: d2800297     	mov	x23, #0x14              ; =20
    13c4: 17fffec0     	b	0xec4 <_stogir.verify.integer-operations-target-structured+0x588>
    13c8: 9106c3f0     	add	x16, sp, #0x1b0
    13cc: f9400600     	ldr	x0, [x16, #0x8]
    13d0: 910043f0     	add	x16, sp, #0x10
    13d4: b9400201     	ldr	w1, [x16]
    13d8: d3407c00     	ubfx	x0, x0, #0, #32
    13dc: d3483c21     	ubfx	x1, x1, #8, #8
    13e0: d3483c00     	ubfx	x0, x0, #8, #8
    13e4: eb01001f     	cmp	x0, x1
    13e8: 54000080     	b.eq	0x13f8 <_stogir.verify.integer-operations-target-structured+0xabc>
    13ec: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    13f0: f94002d6     	ldr	x22, [x22]
    13f4: d2800357     	mov	x23, #0x1a              ; =26
    13f8: 17fffff3     	b	0x13c4 <_stogir.verify.integer-operations-target-structured+0xa88>
    13fc: d4200000     	brk	#0
    1400: 17ffffff     	b	0x13fc <_stogir.verify.integer-operations-target-structured+0xac0>
    1404: 91000681     	add	x1, x20, #0x1
    1408: 93407c34     	sxtw	x20, w1
    140c: 17fffed2     	b	0xf54 <_stogir.verify.integer-operations-target-structured+0x618>
    1410: d4200000     	brk	#0
    1414: 17ffffff     	b	0x1410 <_stogir.verify.integer-operations-target-structured+0xad4>
    1418: d2e00003     	movz	x3, #0x0, lsl #48
    141c: 17fffef3     	b	0xfe8 <_stogir.verify.integer-operations-target-structured+0x6ac>
    1420: d2e00003     	movz	x3, #0x0, lsl #48
    1424: 17fffef1     	b	0xfe8 <_stogir.verify.integer-operations-target-structured+0x6ac>
    1428: f100003f     	cmp	x1, #0x0
    142c: 54001bca     	b.ge	0x17a4 <_stogir.verify.integer-operations-target-structured+0xe68>
    1430: f94123e6     	ldr	x6, [sp, #0x240]
    1434: f94004c7     	ldr	x7, [x6, #0x8]
    1438: f9411fe8     	ldr	x8, [sp, #0x238]
    143c: f9400509     	ldr	x9, [x8, #0x8]
    1440: eb0900ff     	cmp	x7, x9
    1444: 54000181     	b.ne	0x1474 <_stogir.verify.integer-operations-target-structured+0xb38>
    1448: eb07007f     	cmp	x3, x7
    144c: 5400010c     	b.gt	0x146c <_stogir.verify.integer-operations-target-structured+0xb30>
    1450: f9402b23     	ldr	x3, [x25, #0x50]
    1454: b8647863     	ldr	w3, [x3, x4, lsl #2]
    1458: 93407c63     	sxtw	x3, w3
    145c: f100007f     	cmp	x3, #0x0
    1460: 1a9fd7e3     	cset	w3, gt
    1464: d3401c63     	ubfx	x3, x3, #0, #8
    1468: 17fffee2     	b	0xff0 <_stogir.verify.integer-operations-target-structured+0x6b4>
    146c: d2e00003     	movz	x3, #0x0, lsl #48
    1470: 17fffffe     	b	0x1468 <_stogir.verify.integer-operations-target-structured+0xb2c>
    1474: d2e00003     	movz	x3, #0x0, lsl #48
    1478: 17fffffc     	b	0x1468 <_stogir.verify.integer-operations-target-structured+0xb2c>
    147c: d2e00003     	movz	x3, #0x0, lsl #48
    1480: 17fffffa     	b	0x1468 <_stogir.verify.integer-operations-target-structured+0xb2c>
    1484: f9401721     	ldr	x1, [x25, #0x28]
    1488: 8b041021     	add	x1, x1, x4, lsl #4
    148c: 17fffedf     	b	0x1008 <_stogir.verify.integer-operations-target-structured+0x6cc>
    1490: d2e00001     	movz	x1, #0x0, lsl #48
    1494: 17fffedd     	b	0x1008 <_stogir.verify.integer-operations-target-structured+0x6cc>
    1498: b9400021     	ldr	w1, [x1]
    149c: 910043f0     	add	x16, sp, #0x10
    14a0: b9400203     	ldr	w3, [x16]
    14a4: d3483c21     	ubfx	x1, x1, #8, #8
    14a8: aa1f0024     	orr	x4, x1, xzr
    14ac: d3483c63     	ubfx	x3, x3, #8, #8
    14b0: f100187f     	cmp	x3, #0x6
    14b4: 54000661     	b.ne	0x1580 <_stogir.verify.integer-operations-target-structured+0xc44>
    14b8: f100189f     	cmp	x4, #0x6
    14bc: 540005e1     	b.ne	0x1578 <_stogir.verify.integer-operations-target-structured+0xc3c>
    14c0: f1006b1f     	cmp	x24, #0x1a
    14c4: 54000521     	b.ne	0x1568 <_stogir.verify.integer-operations-target-structured+0xc2c>
    14c8: d2800023     	mov	x3, #0x1                ; =1
    14cc: f100049f     	cmp	x4, #0x1
    14d0: 5400170b     	b.lt	0x17b0 <_stogir.verify.integer-operations-target-structured+0xe74>
    14d4: f1002c9f     	cmp	x4, #0xb
    14d8: 540017ec     	b.gt	0x17d4 <_stogir.verify.integer-operations-target-structured+0xe98>
    14dc: f100005f     	cmp	x2, #0x0
    14e0: 540018c0     	b.eq	0x17f8 <_stogir.verify.integer-operations-target-structured+0xebc>
    14e4: b94273ed     	ldr	w13, [sp, #0x270]
    14e8: f9012fe0     	str	x0, [sp, #0x258]
    14ec: 2a0d03e0     	mov	w0, w13
    14f0: f90127e5     	str	x5, [sp, #0x248]
    14f4: f90123e6     	str	x6, [sp, #0x240]
    14f8: f9011fe8     	str	x8, [sp, #0x238]
    14fc: f90103f9     	str	x25, [sp, #0x200]
    1500: aa0403f9     	mov	x25, x4
    1504: f90157fa     	str	x26, [sp, #0x2a8]
    1508: aa0303fa     	mov	x26, x3
    150c: 94000000     	bl	0x150c <_stogir.verify.integer-operations-target-structured+0xbd0>
    1510: f100001f     	cmp	x0, #0x0
    1514: 540003a1     	b.ne	0x1588 <_stogir.verify.integer-operations-target-structured+0xc4c>
    1518: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    151c: f94002d6     	ldr	x22, [x22]
    1520: d2800397     	mov	x23, #0x1c              ; =28
    1524: 910043f0     	add	x16, sp, #0x10
    1528: b9400200     	ldr	w0, [x16]
    152c: f10002bf     	cmp	x21, #0x0
    1530: 540006c0     	b.eq	0x1608 <_stogir.verify.integer-operations-target-structured+0xccc>
    1534: d2800021     	mov	x1, #0x1                ; =1
    1538: d3483c00     	ubfx	x0, x0, #8, #8
    153c: 93407c21     	sxtw	x1, w1
    1540: eb01001f     	cmp	x0, x1
    1544: 54000080     	b.eq	0x1554 <_stogir.verify.integer-operations-target-structured+0xc18>
    1548: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    154c: f94002d6     	ldr	x22, [x22]
    1550: d28004d7     	mov	x23, #0x26              ; =38
    1554: f10002bf     	cmp	x21, #0x0
    1558: 540005c1     	b.ne	0x1610 <_stogir.verify.integer-operations-target-structured+0xcd4>
    155c: f100027f     	cmp	x19, #0x0
    1560: 54000581     	b.ne	0x1610 <_stogir.verify.integer-operations-target-structured+0xcd4>
    1564: 17fffeb4     	b	0x1034 <_stogir.verify.integer-operations-target-structured+0x6f8>
    1568: f1006f1f     	cmp	x24, #0x1b
    156c: 1a9f17e3     	cset	w3, eq
    1570: d3401c63     	ubfx	x3, x3, #0, #8
    1574: 17ffffd6     	b	0x14cc <_stogir.verify.integer-operations-target-structured+0xb90>
    1578: d2e00003     	movz	x3, #0x0, lsl #48
    157c: 17ffffd4     	b	0x14cc <_stogir.verify.integer-operations-target-structured+0xb90>
    1580: d2e00003     	movz	x3, #0x0, lsl #48
    1584: 17ffffd2     	b	0x14cc <_stogir.verify.integer-operations-target-structured+0xb90>
    1588: f100027f     	cmp	x19, #0x0
    158c: 54fffcc0     	b.eq	0x1524 <_stogir.verify.integer-operations-target-structured+0xbe8>
    1590: f1006b1f     	cmp	x24, #0x1a
    1594: 5400028b     	b.lt	0x15e4 <_stogir.verify.integer-operations-target-structured+0xca8>
    1598: f1007b1f     	cmp	x24, #0x1e
    159c: 5400024c     	b.gt	0x15e4 <_stogir.verify.integer-operations-target-structured+0xca8>
    15a0: f100073f     	cmp	x25, #0x1
    15a4: 54fffbab     	b.lt	0x1518 <_stogir.verify.integer-operations-target-structured+0xbdc>
    15a8: f1002f3f     	cmp	x25, #0xb
    15ac: 54fffb6c     	b.gt	0x1518 <_stogir.verify.integer-operations-target-structured+0xbdc>
    15b0: f100073f     	cmp	x25, #0x1
    15b4: 54fffb81     	b.ne	0x1524 <_stogir.verify.integer-operations-target-structured+0xbe8>
    15b8: f100bb1f     	cmp	x24, #0x2e
    15bc: 54fffb40     	b.eq	0x1524 <_stogir.verify.integer-operations-target-structured+0xbe8>
    15c0: f100bf1f     	cmp	x24, #0x2f
    15c4: 54fffb00     	b.eq	0x1524 <_stogir.verify.integer-operations-target-structured+0xbe8>
    15c8: f100c31f     	cmp	x24, #0x30
    15cc: 54fffac0     	b.eq	0x1524 <_stogir.verify.integer-operations-target-structured+0xbe8>
    15d0: f100eb1f     	cmp	x24, #0x3a
    15d4: 54fffa80     	b.eq	0x1524 <_stogir.verify.integer-operations-target-structured+0xbe8>
    15d8: f100ef1f     	cmp	x24, #0x3b
    15dc: 54fff9e1     	b.ne	0x1518 <_stogir.verify.integer-operations-target-structured+0xbdc>
    15e0: 17ffffd1     	b	0x1524 <_stogir.verify.integer-operations-target-structured+0xbe8>
    15e4: f100bb1f     	cmp	x24, #0x2e
    15e8: 5400006b     	b.lt	0x15f4 <_stogir.verify.integer-operations-target-structured+0xcb8>
    15ec: f100d71f     	cmp	x24, #0x35
    15f0: 54fffd8d     	b.le	0x15a0 <_stogir.verify.integer-operations-target-structured+0xc64>
    15f4: f100eb1f     	cmp	x24, #0x3a
    15f8: 54fffd40     	b.eq	0x15a0 <_stogir.verify.integer-operations-target-structured+0xc64>
    15fc: f100ef1f     	cmp	x24, #0x3b
    1600: 54fffd00     	b.eq	0x15a0 <_stogir.verify.integer-operations-target-structured+0xc64>
    1604: 17ffffc5     	b	0x1518 <_stogir.verify.integer-operations-target-structured+0xbdc>
    1608: aa1903e1     	mov	x1, x25
    160c: 17ffffcb     	b	0x1538 <_stogir.verify.integer-operations-target-structured+0xbfc>
    1610: 910043f0     	add	x16, sp, #0x10
    1614: b9400a00     	ldr	w0, [x16, #0x8]
    1618: 2a0003e1     	mov	w1, w0
    161c: f94103e0     	ldr	x0, [sp, #0x200]
    1620: 94000000     	bl	0x1620 <_stogir.verify.integer-operations-target-structured+0xce4>
    1624: f100001f     	cmp	x0, #0x0
    1628: 540000a1     	b.ne	0x163c <_stogir.verify.integer-operations-target-structured+0xd00>
    162c: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1630: f94002d6     	ldr	x22, [x22]
    1634: d28003b7     	mov	x23, #0x1d              ; =29
    1638: 17ffffcb     	b	0x1564 <_stogir.verify.integer-operations-target-structured+0xc28>
    163c: b9400000     	ldr	w0, [x0]
    1640: d3483c00     	ubfx	x0, x0, #8, #8
    1644: eb00033f     	cmp	x25, x0
    1648: 540000e0     	b.eq	0x1664 <_stogir.verify.integer-operations-target-structured+0xd28>
    164c: f100035f     	cmp	x26, #0x0
    1650: 540000c0     	b.eq	0x1668 <_stogir.verify.integer-operations-target-structured+0xd2c>
    1654: f100141f     	cmp	x0, #0x5
    1658: 54000060     	b.eq	0x1664 <_stogir.verify.integer-operations-target-structured+0xd28>
    165c: f1002c1f     	cmp	x0, #0xb
    1660: 54000041     	b.ne	0x1668 <_stogir.verify.integer-operations-target-structured+0xd2c>
    1664: 17fffff5     	b	0x1638 <_stogir.verify.integer-operations-target-structured+0xcfc>
    1668: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    166c: f94002d6     	ldr	x22, [x22]
    1670: d28003b7     	mov	x23, #0x1d              ; =29
    1674: 17fffffc     	b	0x1664 <_stogir.verify.integer-operations-target-structured+0xd28>
    1678: d4200000     	brk	#0
    167c: 17ffffff     	b	0x1678 <_stogir.verify.integer-operations-target-structured+0xd3c>
    1680: d4200000     	brk	#0
    1684: 17ffffff     	b	0x1680 <_stogir.verify.integer-operations-target-structured+0xd44>
    1688: f10002ff     	cmp	x23, #0x0
    168c: 540002c1     	b.ne	0x16e4 <_stogir.verify.integer-operations-target-structured+0xda8>
    1690: 92407e96     	and	x22, x20, #0xffffffff
    1694: d2e00000     	movz	x0, #0x0, lsl #48
    1698: d2e00017     	movz	x23, #0x0, lsl #48
    169c: f9411be1     	ldr	x1, [sp, #0x230]
    16a0: f9000020     	str	x0, [x1]
    16a4: f9000436     	str	x22, [x1, #0x8]
    16a8: f9000837     	str	x23, [x1, #0x10]
    16ac: f9415bf3     	ldr	x19, [sp, #0x2b0]
    16b0: f9415ff4     	ldr	x20, [sp, #0x2b8]
    16b4: f94163f5     	ldr	x21, [sp, #0x2c0]
    16b8: f94167f6     	ldr	x22, [sp, #0x2c8]
    16bc: f9416bf7     	ldr	x23, [sp, #0x2d0]
    16c0: f9416ff8     	ldr	x24, [sp, #0x2d8]
    16c4: f94173f9     	ldr	x25, [sp, #0x2e0]
    16c8: f94177fa     	ldr	x26, [sp, #0x2e8]
    16cc: f9417bfb     	ldr	x27, [sp, #0x2f0]
    16d0: f9417ffc     	ldr	x28, [sp, #0x2f8]
    16d4: f94003fd     	ldr	x29, [sp]
    16d8: f94007fe     	ldr	x30, [sp, #0x8]
    16dc: 910c03ff     	add	sp, sp, #0x300
    16e0: d65f03c0     	ret
    16e4: d2800020     	mov	x0, #0x1                ; =1
    16e8: 17ffffed     	b	0x169c <_stogir.verify.integer-operations-target-structured+0xd60>
    16ec: aa0903f4     	mov	x20, x9
    16f0: f9011be8     	str	x8, [sp, #0x230]
    16f4: aa0a03f6     	mov	x22, x10
    16f8: aa0b03f7     	mov	x23, x11
    16fc: 17ffffe3     	b	0x1688 <_stogir.verify.integer-operations-target-structured+0xd4c>
    1700: aa0903f4     	mov	x20, x9
    1704: f9011be8     	str	x8, [sp, #0x230]
    1708: aa0a03f6     	mov	x22, x10
    170c: aa0b03f7     	mov	x23, x11
    1710: 17ffffde     	b	0x1688 <_stogir.verify.integer-operations-target-structured+0xd4c>
    1714: f90103e0     	str	x0, [sp, #0x200]
    1718: 17fffe69     	b	0x10bc <_stogir.verify.integer-operations-target-structured+0x780>
    171c: f9410be0     	ldr	x0, [sp, #0x210]
    1720: 17fffd6d     	b	0xcd4 <_stogir.verify.integer-operations-target-structured+0x398>
    1724: f9010be0     	str	x0, [sp, #0x210]
    1728: f94147e0     	ldr	x0, [sp, #0x288]
    172c: 17fffd85     	b	0xd40 <_stogir.verify.integer-operations-target-structured+0x404>
    1730: f90147e0     	str	x0, [sp, #0x288]
    1734: f9413fe0     	ldr	x0, [sp, #0x278]
    1738: 17fffd9e     	b	0xdb0 <_stogir.verify.integer-operations-target-structured+0x474>
    173c: f9013fe0     	str	x0, [sp, #0x278]
    1740: f94137e0     	ldr	x0, [sp, #0x268]
    1744: 17fffdb7     	b	0xe20 <_stogir.verify.integer-operations-target-structured+0x4e4>
    1748: f90137e0     	str	x0, [sp, #0x268]
    174c: f94133e0     	ldr	x0, [sp, #0x260]
    1750: 17fffdcd     	b	0xe84 <_stogir.verify.integer-operations-target-structured+0x548>
    1754: f90133e0     	str	x0, [sp, #0x260]
    1758: 17fffddd     	b	0xecc <_stogir.verify.integer-operations-target-structured+0x590>
    175c: f90153f9     	str	x25, [sp, #0x2a0]
    1760: aa0003f9     	mov	x25, x0
    1764: f9412fe0     	ldr	x0, [sp, #0x258]
    1768: 17fffdfb     	b	0xf54 <_stogir.verify.integer-operations-target-structured+0x618>
    176c: f90157fa     	str	x26, [sp, #0x2a8]
    1770: f9012fe0     	str	x0, [sp, #0x258]
    1774: 17fffe32     	b	0x103c <_stogir.verify.integer-operations-target-structured+0x700>
    1778: f90157fa     	str	x26, [sp, #0x2a8]
    177c: f9012fe0     	str	x0, [sp, #0x258]
    1780: 17fffe2f     	b	0x103c <_stogir.verify.integer-operations-target-structured+0x700>
    1784: f90157fa     	str	x26, [sp, #0x2a8]
    1788: f9012fe0     	str	x0, [sp, #0x258]
    178c: 17fffe2c     	b	0x103c <_stogir.verify.integer-operations-target-structured+0x700>
    1790: f94103f9     	ldr	x25, [sp, #0x200]
    1794: f94127e5     	ldr	x5, [sp, #0x248]
    1798: 17ffff24     	b	0x1428 <_stogir.verify.integer-operations-target-structured+0xaec>
    179c: f94127e5     	ldr	x5, [sp, #0x248]
    17a0: 17ffff20     	b	0x1420 <_stogir.verify.integer-operations-target-structured+0xae4>
    17a4: f94123e6     	ldr	x6, [sp, #0x240]
    17a8: f9411fe8     	ldr	x8, [sp, #0x238]
    17ac: 17ffff34     	b	0x147c <_stogir.verify.integer-operations-target-structured+0xb40>
    17b0: f90103f9     	str	x25, [sp, #0x200]
    17b4: f90127e5     	str	x5, [sp, #0x248]
    17b8: f90157fa     	str	x26, [sp, #0x2a8]
    17bc: aa0303fa     	mov	x26, x3
    17c0: f9012fe0     	str	x0, [sp, #0x258]
    17c4: aa0403f9     	mov	x25, x4
    17c8: f90123e6     	str	x6, [sp, #0x240]
    17cc: f9011fe8     	str	x8, [sp, #0x238]
    17d0: 17ffff52     	b	0x1518 <_stogir.verify.integer-operations-target-structured+0xbdc>
    17d4: f90103f9     	str	x25, [sp, #0x200]
    17d8: f90127e5     	str	x5, [sp, #0x248]
    17dc: f90157fa     	str	x26, [sp, #0x2a8]
    17e0: aa0303fa     	mov	x26, x3
    17e4: f9012fe0     	str	x0, [sp, #0x258]
    17e8: aa0403f9     	mov	x25, x4
    17ec: f90123e6     	str	x6, [sp, #0x240]
    17f0: f9011fe8     	str	x8, [sp, #0x238]
    17f4: 17ffff49     	b	0x1518 <_stogir.verify.integer-operations-target-structured+0xbdc>
    17f8: f90103f9     	str	x25, [sp, #0x200]
    17fc: f90127e5     	str	x5, [sp, #0x248]
    1800: f90157fa     	str	x26, [sp, #0x2a8]
    1804: aa0303fa     	mov	x26, x3
    1808: f9012fe0     	str	x0, [sp, #0x258]
    180c: aa0403f9     	mov	x25, x4
    1810: f90123e6     	str	x6, [sp, #0x240]
    1814: f9011fe8     	str	x8, [sp, #0x238]
    1818: 17ffff5c     	b	0x1588 <_stogir.verify.integer-operations-target-structured+0xc4c>

