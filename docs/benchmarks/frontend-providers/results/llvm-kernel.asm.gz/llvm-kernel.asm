
build/frontend-providers/llvm.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000004e008 <_gap_provider_kernel>:
   4e008: d10503ff     	sub	sp, sp, #0x140
   4e00c: a90e6ffc     	stp	x28, x27, [sp, #0xe0]
   4e010: a90f67fa     	stp	x26, x25, [sp, #0xf0]
   4e014: a9105ff8     	stp	x24, x23, [sp, #0x100]
   4e018: a91157f6     	stp	x22, x21, [sp, #0x110]
   4e01c: a9124ff4     	stp	x20, x19, [sp, #0x120]
   4e020: a9137bfd     	stp	x29, x30, [sp, #0x130]
   4e024: 9104c3fd     	add	x29, sp, #0x130
   4e028: f9403c08     	ldr	x8, [x0, #0x78]
   4e02c: f100051f     	cmp	x8, #0x1
   4e030: 5400390b     	b.lt	0x4e750 <_gap_provider_kernel+0x748>
   4e034: aa0003f5     	mov	x21, x0
   4e038: aa1f03e8     	mov	x8, xzr
   4e03c: aa1f03f4     	mov	x20, xzr
   4e040: 92800013     	mov	x19, #-0x1              ; =-1
   4e044: 52800618     	mov	w24, #0x30              ; =48
   4e048: f90017e0     	str	x0, [sp, #0x28]
   4e04c: 14000008     	b	0x4e06c <_gap_provider_kernel+0x64>
   4e050: f94003f3     	ldr	x19, [sp]
   4e054: f9403ea9     	ldr	x9, [x21, #0x78]
   4e058: a908ffff     	stp	xzr, xzr, [sp, #0x88]
   4e05c: f9004fff     	str	xzr, [sp, #0x98]
   4e060: 91000668     	add	x8, x19, #0x1
   4e064: eb09011f     	cmp	x8, x9
   4e068: 5400376a     	b.ge	0x4e754 <_gap_provider_kernel+0x74c>
   4e06c: a90053e8     	stp	x8, x20, [sp]
   4e070: 90000009     	adrp	x9, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e070:  ARM64_RELOC_PAGE21	__MergedGlobals.335
   4e074: 91000129     	add	x9, x9, #0x0
		000000000004e074:  ARM64_RELOC_PAGEOFF12	__MergedGlobals.335
   4e078: 90000008     	adrp	x8, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e078:  ARM64_RELOC_PAGE21	l_vtable.coil.alloc.Allocator-dyn.3
   4e07c: 91000108     	add	x8, x8, #0x0
		000000000004e07c:  ARM64_RELOC_PAGEOFF12	l_vtable.coil.alloc.Allocator-dyn.3
   4e080: 90000004     	adrp	x4, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e080:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__coil.compiler.resolve.PrimitiveProvider.0
   4e084: a939a3a9     	stp	x9, x8, [x29, #-0x68]
   4e088: d101a3a0     	sub	x0, x29, #0x68
   4e08c: aa1f03e1     	mov	x1, xzr
   4e090: f9400084     	ldr	x4, [x4]
		000000000004e090:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__coil.compiler.resolve.PrimitiveProvider.0
   4e094: aa1f03e2     	mov	x2, xzr
   4e098: 52800043     	mov	w3, #0x2                ; =2
   4e09c: 52800405     	mov	w5, #0x20               ; =32
   4e0a0: 52800106     	mov	w6, #0x8                ; =8
   4e0a4: 94000000     	bl	0x4e0a4 <_gap_provider_kernel+0x9c>
		000000000004e0a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
   4e0a8: 34003800     	cbz	w0, 0x4e7a8 <_gap_provider_kernel+0x7a0>
   4e0ac: 90000008     	adrp	x8, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e0ac:  ARM64_RELOC_PAGE21	l_str.11513
   4e0b0: 91000109     	add	x9, x8, #0x0
		000000000004e0b0:  ARM64_RELOC_PAGEOFF12	l_str.11513
   4e0b4: f240027f     	tst	x19, #0x1
   4e0b8: 52800088     	mov	w8, #0x4                ; =4
   4e0bc: aa0103fb     	mov	x27, x1
   4e0c0: aa1f03eb     	mov	x11, xzr
   4e0c4: a9002029     	stp	x9, x8, [x1]
   4e0c8: 90000008     	adrp	x8, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e0c8:  ARM64_RELOC_PAGE21	l_str.11511
   4e0cc: 91000108     	add	x8, x8, #0x0
		000000000004e0cc:  ARM64_RELOC_PAGEOFF12	l_str.11511
   4e0d0: 90000009     	adrp	x9, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e0d0:  ARM64_RELOC_PAGE21	l_str.11512
   4e0d4: 91000129     	add	x9, x9, #0x0
		000000000004e0d4:  ARM64_RELOC_PAGEOFF12	l_str.11512
   4e0d8: 52800059     	mov	w25, #0x2               ; =2
   4e0dc: 9a88012a     	csel	x10, x9, x8, eq
   4e0e0: 52800128     	mov	w8, #0x9                ; =9
   4e0e4: 528000e9     	mov	w9, #0x7                ; =7
   4e0e8: 9a880136     	csel	x22, x9, x8, eq
   4e0ec: 5280003a     	mov	w26, #0x1               ; =1
   4e0f0: f9000bea     	str	x10, [sp, #0x10]
   4e0f4: a901582a     	stp	x10, x22, [x1, #0x10]
   4e0f8: f90013f6     	str	x22, [sp, #0x20]
   4e0fc: 14000007     	b	0x4e118 <_gap_provider_kernel+0x110>
   4e100: f94017f5     	ldr	x21, [sp, #0x28]
   4e104: f94013f6     	ldr	x22, [sp, #0x20]
   4e108: f9400feb     	ldr	x11, [sp, #0x18]
   4e10c: 9100056b     	add	x11, x11, #0x1
   4e110: eb1a017f     	cmp	x11, x26
   4e114: 54002caa     	b.ge	0x4e6a8 <_gap_provider_kernel+0x6a0>
   4e118: 8b0b1768     	add	x8, x27, x11, lsl #5
   4e11c: f9402ab3     	ldr	x19, [x21, #0x50]
   4e120: f9000feb     	str	x11, [sp, #0x18]
   4e124: a9407109     	ldp	x9, x28, [x8]
   4e128: f9002be9     	str	x9, [sp, #0x50]
   4e12c: a9415109     	ldp	x9, x20, [x8, #0x10]
   4e130: f1000668     	subs	x8, x19, #0x1
   4e134: f90043e9     	str	x9, [sp, #0x80]
   4e138: 54000c8b     	b.lt	0x4e2c8 <_gap_provider_kernel+0x2c0>
   4e13c: f100827f     	cmp	x19, #0x20
   4e140: 54000643     	b.lo	0x4e208 <_gap_provider_kernel+0x200>
   4e144: aa1f03f6     	mov	x22, xzr
   4e148: 927be917     	and	x23, x8, #0xffffffffffffffe0
   4e14c: 14000004     	b	0x4e15c <_gap_provider_kernel+0x154>
   4e150: 910006d6     	add	x22, x22, #0x1
   4e154: eb1302df     	cmp	x22, x19
   4e158: 54000b80     	b.eq	0x4e2c8 <_gap_provider_kernel+0x2c0>
   4e15c: eb1602ff     	cmp	x23, x22
   4e160: 540001ad     	b.le	0x4e194 <_gap_provider_kernel+0x18c>
   4e164: f94017e8     	ldr	x8, [sp, #0x28]
   4e168: f9402d09     	ldr	x9, [x8, #0x58]
   4e16c: f9402108     	ldr	x8, [x8, #0x40]
   4e170: f100053f     	cmp	x9, #0x1
   4e174: 5400014b     	b.lt	0x4e19c <_gap_provider_kernel+0x194>
   4e178: 9ac926ca     	lsr	x10, x22, x9
   4e17c: f9401108     	ldr	x8, [x8, #0x20]
   4e180: f1001529     	subs	x9, x9, #0x5
   4e184: 9240114a     	and	x10, x10, #0x1f
   4e188: f86a7908     	ldr	x8, [x8, x10, lsl #3]
   4e18c: 54ffff68     	b.hi	0x4e178 <_gap_provider_kernel+0x170>
   4e190: 14000003     	b	0x4e19c <_gap_provider_kernel+0x194>
   4e194: f94017e8     	ldr	x8, [sp, #0x28]
   4e198: f9402508     	ldr	x8, [x8, #0x48]
   4e19c: 924012d5     	and	x21, x22, #0x1f
   4e1a0: f9400d08     	ldr	x8, [x8, #0x18]
   4e1a4: 52800d09     	mov	w9, #0x68               ; =104
   4e1a8: 9ba922a8     	umaddl	x8, w21, w9, x8
   4e1ac: f9400509     	ldr	x9, [x8, #0x8]
   4e1b0: eb1c013f     	cmp	x9, x28
   4e1b4: 54fffce1     	b.ne	0x4e150 <_gap_provider_kernel+0x148>
   4e1b8: b40000dc     	cbz	x28, 0x4e1d0 <_gap_provider_kernel+0x1c8>
   4e1bc: f9400100     	ldr	x0, [x8]
   4e1c0: f9402be1     	ldr	x1, [sp, #0x50]
   4e1c4: aa1c03e2     	mov	x2, x28
   4e1c8: 94000000     	bl	0x4e1c8 <_gap_provider_kernel+0x1c0>
		000000000004e1c8:  ARM64_RELOC_BRANCH26	_memcmp
   4e1cc: 35fffc20     	cbnz	w0, 0x4e150 <_gap_provider_kernel+0x148>
   4e1d0: eb1602ff     	cmp	x23, x22
   4e1d4: 540006ed     	b.le	0x4e2b0 <_gap_provider_kernel+0x2a8>
   4e1d8: f94017e9     	ldr	x9, [sp, #0x28]
   4e1dc: f9402d28     	ldr	x8, [x9, #0x58]
   4e1e0: f9402137     	ldr	x23, [x9, #0x40]
   4e1e4: f100051f     	cmp	x8, #0x1
   4e1e8: 5400036b     	b.lt	0x4e254 <_gap_provider_kernel+0x24c>
   4e1ec: 9ac826c9     	lsr	x9, x22, x8
   4e1f0: f94012ea     	ldr	x10, [x23, #0x20]
   4e1f4: f1001508     	subs	x8, x8, #0x5
   4e1f8: 92401129     	and	x9, x9, #0x1f
   4e1fc: f8697957     	ldr	x23, [x10, x9, lsl #3]
   4e200: 54ffff68     	b.hi	0x4e1ec <_gap_provider_kernel+0x1e4>
   4e204: 14000014     	b	0x4e254 <_gap_provider_kernel+0x24c>
   4e208: f94017e8     	ldr	x8, [sp, #0x28]
   4e20c: aa1f03f5     	mov	x21, xzr
   4e210: f9402517     	ldr	x23, [x8, #0x48]
   4e214: f9400ee8     	ldr	x8, [x23, #0x18]
   4e218: 91002116     	add	x22, x8, #0x8
   4e21c: 14000005     	b	0x4e230 <_gap_provider_kernel+0x228>
   4e220: 910006b5     	add	x21, x21, #0x1
   4e224: 9101a2d6     	add	x22, x22, #0x68
   4e228: eb15027f     	cmp	x19, x21
   4e22c: 540004e0     	b.eq	0x4e2c8 <_gap_provider_kernel+0x2c0>
   4e230: f94002c8     	ldr	x8, [x22]
   4e234: eb1c011f     	cmp	x8, x28
   4e238: 54ffff41     	b.ne	0x4e220 <_gap_provider_kernel+0x218>
   4e23c: b40000dc     	cbz	x28, 0x4e254 <_gap_provider_kernel+0x24c>
   4e240: f85f82c0     	ldur	x0, [x22, #-0x8]
   4e244: f9402be1     	ldr	x1, [sp, #0x50]
   4e248: aa1c03e2     	mov	x2, x28
   4e24c: 94000000     	bl	0x4e24c <_gap_provider_kernel+0x244>
		000000000004e24c:  ARM64_RELOC_BRANCH26	_memcmp
   4e250: 35fffe80     	cbnz	w0, 0x4e220 <_gap_provider_kernel+0x218>
   4e254: f9400ee8     	ldr	x8, [x23, #0x18]
   4e258: 52800d09     	mov	w9, #0x68               ; =104
   4e25c: 9b0922a8     	madd	x8, x21, x9, x8
   4e260: b4000348     	cbz	x8, 0x4e2c8 <_gap_provider_kernel+0x2c0>
   4e264: f9400d13     	ldr	x19, [x8, #0x18]
   4e268: f100067f     	cmp	x19, #0x1
   4e26c: 54fff4ab     	b.lt	0x4e100 <_gap_provider_kernel+0xf8>
   4e270: f9400908     	ldr	x8, [x8, #0x10]
   4e274: b40020f4     	cbz	x20, 0x4e690 <_gap_provider_kernel+0x688>
   4e278: 91002115     	add	x21, x8, #0x8
   4e27c: 14000004     	b	0x4e28c <_gap_provider_kernel+0x284>
   4e280: f1000673     	subs	x19, x19, #0x1
   4e284: 910042b5     	add	x21, x21, #0x10
   4e288: 54fff3c0     	b.eq	0x4e100 <_gap_provider_kernel+0xf8>
   4e28c: f94002a8     	ldr	x8, [x21]
   4e290: eb14011f     	cmp	x8, x20
   4e294: 54ffff61     	b.ne	0x4e280 <_gap_provider_kernel+0x278>
   4e298: f85f82a0     	ldur	x0, [x21, #-0x8]
   4e29c: f94043e1     	ldr	x1, [sp, #0x80]
   4e2a0: aa1403e2     	mov	x2, x20
   4e2a4: 94000000     	bl	0x4e2a4 <_gap_provider_kernel+0x29c>
		000000000004e2a4:  ARM64_RELOC_BRANCH26	_memcmp
   4e2a8: 35fffec0     	cbnz	w0, 0x4e280 <_gap_provider_kernel+0x278>
   4e2ac: 14000007     	b	0x4e2c8 <_gap_provider_kernel+0x2c0>
   4e2b0: f94017e8     	ldr	x8, [sp, #0x28]
   4e2b4: f9402517     	ldr	x23, [x8, #0x48]
   4e2b8: f9400ee8     	ldr	x8, [x23, #0x18]
   4e2bc: 52800d09     	mov	w9, #0x68               ; =104
   4e2c0: 9b0922a8     	madd	x8, x21, x9, x8
   4e2c4: b5fffd08     	cbnz	x8, 0x4e264 <_gap_provider_kernel+0x25c>
   4e2c8: f94017f5     	ldr	x21, [sp, #0x28]
   4e2cc: f9400ea8     	ldr	x8, [x21, #0x18]
   4e2d0: f100051f     	cmp	x8, #0x1
   4e2d4: 54fff18b     	b.lt	0x4e104 <_gap_provider_kernel+0xfc>
   4e2d8: f94013f6     	ldr	x22, [sp, #0x20]
   4e2dc: aa1f03ec     	mov	x12, xzr
   4e2e0: f9001ffc     	str	x28, [sp, #0x38]
   4e2e4: 14000007     	b	0x4e300 <_gap_provider_kernel+0x2f8>
   4e2e8: a94257f6     	ldp	x22, x21, [sp, #0x20]
   4e2ec: f9401bec     	ldr	x12, [sp, #0x30]
   4e2f0: f9400ea8     	ldr	x8, [x21, #0x18]
   4e2f4: 9100058c     	add	x12, x12, #0x1
   4e2f8: eb08019f     	cmp	x12, x8
   4e2fc: 54fff06a     	b.ge	0x4e108 <_gap_provider_kernel+0x100>
   4e300: d1000509     	sub	x9, x8, #0x1
   4e304: 927be929     	and	x9, x9, #0xffffffffffffffe0
   4e308: eb0c013f     	cmp	x9, x12
   4e30c: fa5fc904     	ccmp	x8, #0x1f, #0x4, gt
   4e310: 5400018d     	b.le	0x4e340 <_gap_provider_kernel+0x338>
   4e314: f94012aa     	ldr	x10, [x21, #0x20]
   4e318: f94006a9     	ldr	x9, [x21, #0x8]
   4e31c: f100055f     	cmp	x10, #0x1
   4e320: 5400012b     	b.lt	0x4e344 <_gap_provider_kernel+0x33c>
   4e324: 9aca258b     	lsr	x11, x12, x10
   4e328: f9401129     	ldr	x9, [x9, #0x20]
   4e32c: f100154a     	subs	x10, x10, #0x5
   4e330: 9240116b     	and	x11, x11, #0x1f
   4e334: f86b7929     	ldr	x9, [x9, x11, lsl #3]
   4e338: 54ffff68     	b.hi	0x4e324 <_gap_provider_kernel+0x31c>
   4e33c: 14000002     	b	0x4e344 <_gap_provider_kernel+0x33c>
   4e340: f9400aa9     	ldr	x9, [x21, #0x10]
   4e344: 9240118a     	and	x10, x12, #0x1f
   4e348: f9400d29     	ldr	x9, [x9, #0x18]
   4e34c: 52801e0b     	mov	w11, #0xf0              ; =240
   4e350: 9bab2549     	umaddl	x9, w10, w11, x9
   4e354: f90033e9     	str	x9, [sp, #0x60]
   4e358: f9403529     	ldr	x9, [x9, #0x68]
   4e35c: f100053f     	cmp	x9, #0x1
   4e360: f9003be9     	str	x9, [sp, #0x70]
   4e364: 54fffc8b     	b.lt	0x4e2f4 <_gap_provider_kernel+0x2ec>
   4e368: f94033f5     	ldr	x21, [sp, #0x60]
   4e36c: aa1f03f7     	mov	x23, xzr
   4e370: f9001bec     	str	x12, [sp, #0x30]
   4e374: 1400000f     	b	0x4e3b0 <_gap_provider_kernel+0x3a8>
   4e378: f9401ffc     	ldr	x28, [sp, #0x38]
   4e37c: 8b1a1768     	add	x8, x27, x26, lsl #5
   4e380: 3cd803a0     	ldur	q0, [x29, #-0x80]
   4e384: f94037ea     	ldr	x10, [sp, #0x68]
   4e388: f9403fe9     	ldr	x9, [sp, #0x78]
   4e38c: 9100075a     	add	x26, x26, #0x1
   4e390: 3d800100     	str	q0, [x8]
   4e394: a901250a     	stp	x10, x9, [x8, #0x10]
   4e398: f94036a8     	ldr	x8, [x21, #0x68]
   4e39c: f9003be8     	str	x8, [sp, #0x70]
   4e3a0: f9403be8     	ldr	x8, [sp, #0x70]
   4e3a4: 910006f7     	add	x23, x23, #0x1
   4e3a8: eb0802ff     	cmp	x23, x8
   4e3ac: 54fff9ea     	b.ge	0x4e2e8 <_gap_provider_kernel+0x2e0>
   4e3b0: f94032a8     	ldr	x8, [x21, #0x60]
   4e3b4: 9b1822f3     	madd	x19, x23, x24, x8
   4e3b8: f9400668     	ldr	x8, [x19, #0x8]
   4e3bc: eb1c011f     	cmp	x8, x28
   4e3c0: 54ffff01     	b.ne	0x4e3a0 <_gap_provider_kernel+0x398>
   4e3c4: b40000dc     	cbz	x28, 0x4e3dc <_gap_provider_kernel+0x3d4>
   4e3c8: f9400260     	ldr	x0, [x19]
   4e3cc: f9402be1     	ldr	x1, [sp, #0x50]
   4e3d0: aa1c03e2     	mov	x2, x28
   4e3d4: 94000000     	bl	0x4e3d4 <_gap_provider_kernel+0x3cc>
		000000000004e3d4:  ARM64_RELOC_BRANCH26	_memcmp
   4e3d8: 35fffe40     	cbnz	w0, 0x4e3a0 <_gap_provider_kernel+0x398>
   4e3dc: f9401668     	ldr	x8, [x19, #0x28]
   4e3e0: f9400516     	ldr	x22, [x8, #0x8]
   4e3e4: f10006df     	cmp	x22, #0x1
   4e3e8: 5400010b     	b.lt	0x4e408 <_gap_provider_kernel+0x400>
   4e3ec: f9400115     	ldr	x21, [x8]
   4e3f0: b5000234     	cbnz	x20, 0x4e434 <_gap_provider_kernel+0x42c>
   4e3f4: f94006a8     	ldr	x8, [x21, #0x8]
   4e3f8: b40002e8     	cbz	x8, 0x4e454 <_gap_provider_kernel+0x44c>
   4e3fc: f10006d6     	subs	x22, x22, #0x1
   4e400: 910082b5     	add	x21, x21, #0x20
   4e404: 54ffff81     	b.ne	0x4e3f4 <_gap_provider_kernel+0x3ec>
   4e408: f9401268     	ldr	x8, [x19, #0x20]
   4e40c: f9400515     	ldr	x21, [x8, #0x8]
   4e410: f10006bf     	cmp	x21, #0x1
   4e414: 540004eb     	b.lt	0x4e4b0 <_gap_provider_kernel+0x4a8>
   4e418: f9400108     	ldr	x8, [x8]
   4e41c: b4000414     	cbz	x20, 0x4e49c <_gap_provider_kernel+0x494>
   4e420: 91002116     	add	x22, x8, #0x8
   4e424: 14000014     	b	0x4e474 <_gap_provider_kernel+0x46c>
   4e428: f10006d6     	subs	x22, x22, #0x1
   4e42c: 910082b5     	add	x21, x21, #0x20
   4e430: 54fffec0     	b.eq	0x4e408 <_gap_provider_kernel+0x400>
   4e434: f94006a8     	ldr	x8, [x21, #0x8]
   4e438: eb14011f     	cmp	x8, x20
   4e43c: 54ffff61     	b.ne	0x4e428 <_gap_provider_kernel+0x420>
   4e440: f94002a0     	ldr	x0, [x21]
   4e444: f94043e1     	ldr	x1, [sp, #0x80]
   4e448: aa1403e2     	mov	x2, x20
   4e44c: 94000000     	bl	0x4e44c <_gap_provider_kernel+0x444>
		000000000004e44c:  ARM64_RELOC_BRANCH26	_memcmp
   4e450: 35fffec0     	cbnz	w0, 0x4e428 <_gap_provider_kernel+0x420>
   4e454: a94122a9     	ldp	x9, x8, [x21, #0x10]
   4e458: f90037e9     	str	x9, [sp, #0x68]
   4e45c: f9003fe8     	str	x8, [sp, #0x78]
   4e460: f94033f5     	ldr	x21, [sp, #0x60]
   4e464: 14000039     	b	0x4e548 <_gap_provider_kernel+0x540>
   4e468: f10006b5     	subs	x21, x21, #0x1
   4e46c: 910042d6     	add	x22, x22, #0x10
   4e470: 54000200     	b.eq	0x4e4b0 <_gap_provider_kernel+0x4a8>
   4e474: f94002c8     	ldr	x8, [x22]
   4e478: eb14011f     	cmp	x8, x20
   4e47c: 54ffff61     	b.ne	0x4e468 <_gap_provider_kernel+0x460>
   4e480: f85f82c0     	ldur	x0, [x22, #-0x8]
   4e484: f94043e1     	ldr	x1, [sp, #0x80]
   4e488: aa1403e2     	mov	x2, x20
   4e48c: 94000000     	bl	0x4e48c <_gap_provider_kernel+0x484>
		000000000004e48c:  ARM64_RELOC_BRANCH26	_memcmp
   4e490: 35fffec0     	cbnz	w0, 0x4e468 <_gap_provider_kernel+0x460>
   4e494: f94033f5     	ldr	x21, [sp, #0x60]
   4e498: 17ffffc2     	b	0x4e3a0 <_gap_provider_kernel+0x398>
   4e49c: 91002108     	add	x8, x8, #0x8
   4e4a0: f8410509     	ldr	x9, [x8], #0x10
   4e4a4: b4ffff89     	cbz	x9, 0x4e494 <_gap_provider_kernel+0x48c>
   4e4a8: f10006b5     	subs	x21, x21, #0x1
   4e4ac: 54ffffa1     	b.ne	0x4e4a0 <_gap_provider_kernel+0x498>
   4e4b0: b9401268     	ldr	w8, [x19, #0x10]
   4e4b4: f94043e9     	ldr	x9, [sp, #0x80]
   4e4b8: f94033f5     	ldr	x21, [sp, #0x60]
   4e4bc: f9003ff4     	str	x20, [sp, #0x78]
   4e4c0: f90037e9     	str	x9, [sp, #0x68]
   4e4c4: 34000428     	cbz	w8, 0x4e548 <_gap_provider_kernel+0x540>
   4e4c8: f9400e68     	ldr	x8, [x19, #0x18]
   4e4cc: f9400513     	ldr	x19, [x8, #0x8]
   4e4d0: f100067f     	cmp	x19, #0x1
   4e4d4: 54fff66b     	b.lt	0x4e3a0 <_gap_provider_kernel+0x398>
   4e4d8: f9400108     	ldr	x8, [x8]
   4e4dc: b4000254     	cbz	x20, 0x4e524 <_gap_provider_kernel+0x51c>
   4e4e0: 91002115     	add	x21, x8, #0x8
   4e4e4: 14000004     	b	0x4e4f4 <_gap_provider_kernel+0x4ec>
   4e4e8: f1000673     	subs	x19, x19, #0x1
   4e4ec: 910042b5     	add	x21, x21, #0x10
   4e4f0: 54fffd20     	b.eq	0x4e494 <_gap_provider_kernel+0x48c>
   4e4f4: f94002a8     	ldr	x8, [x21]
   4e4f8: eb14011f     	cmp	x8, x20
   4e4fc: 54ffff61     	b.ne	0x4e4e8 <_gap_provider_kernel+0x4e0>
   4e500: f85f82a0     	ldur	x0, [x21, #-0x8]
   4e504: f94043e1     	ldr	x1, [sp, #0x80]
   4e508: aa1403e2     	mov	x2, x20
   4e50c: 94000000     	bl	0x4e50c <_gap_provider_kernel+0x504>
		000000000004e50c:  ARM64_RELOC_BRANCH26	_memcmp
   4e510: 35fffec0     	cbnz	w0, 0x4e4e8 <_gap_provider_kernel+0x4e0>
   4e514: f94043e8     	ldr	x8, [sp, #0x80]
   4e518: f9003ff4     	str	x20, [sp, #0x78]
   4e51c: f90037e8     	str	x8, [sp, #0x68]
   4e520: 17ffffd0     	b	0x4e460 <_gap_provider_kernel+0x458>
   4e524: 91002108     	add	x8, x8, #0x8
   4e528: f8410509     	ldr	x9, [x8], #0x10
   4e52c: b4000089     	cbz	x9, 0x4e53c <_gap_provider_kernel+0x534>
   4e530: f1000673     	subs	x19, x19, #0x1
   4e534: 54ffffa1     	b.ne	0x4e528 <_gap_provider_kernel+0x520>
   4e538: 17ffff9a     	b	0x4e3a0 <_gap_provider_kernel+0x398>
   4e53c: f94043e8     	ldr	x8, [sp, #0x80]
   4e540: f9003fff     	str	xzr, [sp, #0x78]
   4e544: f90037e8     	str	x8, [sp, #0x68]
   4e548: f9002ffa     	str	x26, [sp, #0x58]
   4e54c: f100075a     	subs	x26, x26, #0x1
   4e550: 5400058b     	b.lt	0x4e600 <_gap_provider_kernel+0x5f8>
   4e554: a9046ff9     	stp	x25, x27, [sp, #0x40]
   4e558: a94056b9     	ldp	x25, x21, [x21]
   4e55c: aa1f03f8     	mov	x24, xzr
   4e560: 2a1f03fc     	mov	w28, wzr
   4e564: 9100437b     	add	x27, x27, #0x10
   4e568: 14000003     	b	0x4e574 <_gap_provider_kernel+0x56c>
   4e56c: 9100837b     	add	x27, x27, #0x20
   4e570: d100075a     	sub	x26, x26, #0x1
   4e574: f85f8368     	ldur	x8, [x27, #-0x8]
   4e578: eb15011f     	cmp	x8, x21
   4e57c: 54000261     	b.ne	0x4e5c8 <_gap_provider_kernel+0x5c0>
   4e580: a9404f76     	ldp	x22, x19, [x27]
   4e584: b40000d5     	cbz	x21, 0x4e59c <_gap_provider_kernel+0x594>
   4e588: f85f0360     	ldur	x0, [x27, #-0x10]
   4e58c: aa1903e1     	mov	x1, x25
   4e590: aa1503e2     	mov	x2, x21
   4e594: 94000000     	bl	0x4e594 <_gap_provider_kernel+0x58c>
		000000000004e594:  ARM64_RELOC_BRANCH26	_memcmp
   4e598: 35000180     	cbnz	w0, 0x4e5c8 <_gap_provider_kernel+0x5c0>
   4e59c: f9403fe8     	ldr	x8, [sp, #0x78]
   4e5a0: eb08027f     	cmp	x19, x8
   4e5a4: 54000121     	b.ne	0x4e5c8 <_gap_provider_kernel+0x5c0>
   4e5a8: b4000173     	cbz	x19, 0x4e5d4 <_gap_provider_kernel+0x5cc>
   4e5ac: f94037e1     	ldr	x1, [sp, #0x68]
   4e5b0: aa1603e0     	mov	x0, x22
   4e5b4: aa1303e2     	mov	x2, x19
   4e5b8: 94000000     	bl	0x4e5b8 <_gap_provider_kernel+0x5b0>
		000000000004e5b8:  ARM64_RELOC_BRANCH26	_memcmp
   4e5bc: 7100001f     	cmp	w0, #0x0
   4e5c0: 1a9f17e8     	cset	w8, eq
   4e5c4: 2a1c011c     	orr	w28, w8, w28
   4e5c8: b40000fa     	cbz	x26, 0x4e5e4 <_gap_provider_kernel+0x5dc>
   4e5cc: 91000718     	add	x24, x24, #0x1
   4e5d0: 17ffffe7     	b	0x4e56c <_gap_provider_kernel+0x564>
   4e5d4: b400055a     	cbz	x26, 0x4e67c <_gap_provider_kernel+0x674>
   4e5d8: 91000718     	add	x24, x24, #0x1
   4e5dc: 5280003c     	mov	w28, #0x1               ; =1
   4e5e0: 17ffffe3     	b	0x4e56c <_gap_provider_kernel+0x564>
   4e5e4: a9446ff9     	ldp	x25, x27, [sp, #0x40]
   4e5e8: 52800618     	mov	w24, #0x30              ; =48
   4e5ec: f94033f5     	ldr	x21, [sp, #0x60]
   4e5f0: 3600009c     	tbz	w28, #0x0, 0x4e600 <_gap_provider_kernel+0x5f8>
   4e5f4: f9402ffa     	ldr	x26, [sp, #0x58]
   4e5f8: f9401ffc     	ldr	x28, [sp, #0x38]
   4e5fc: 17ffff69     	b	0x4e3a0 <_gap_provider_kernel+0x398>
   4e600: f9402ffa     	ldr	x26, [sp, #0x58]
   4e604: 3dc002a0     	ldr	q0, [x21]
   4e608: eb19035f     	cmp	x26, x25
   4e60c: 3c9803a0     	stur	q0, [x29, #-0x80]
   4e610: 54ffeb4b     	b.lt	0x4e378 <_gap_provider_kernel+0x370>
   4e614: d37ffb28     	lsl	x8, x25, #1
   4e618: f100033f     	cmp	x25, #0x0
   4e61c: 52800049     	mov	w9, #0x2                ; =2
   4e620: 9a880135     	csel	x21, x9, x8, eq
   4e624: 90000008     	adrp	x8, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e624:  ARM64_RELOC_PAGE21	__MergedGlobals.335
   4e628: 91000109     	add	x9, x8, #0x0
		000000000004e628:  ARM64_RELOC_PAGEOFF12	__MergedGlobals.335
   4e62c: eb1902bf     	cmp	x21, x25
   4e630: 90000008     	adrp	x8, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e630:  ARM64_RELOC_PAGE21	l_vtable.coil.alloc.Allocator-dyn.3
   4e634: 91000108     	add	x8, x8, #0x0
		000000000004e634:  ARM64_RELOC_PAGEOFF12	l_vtable.coil.alloc.Allocator-dyn.3
   4e638: a939a3a9     	stp	x9, x8, [x29, #-0x68]
   4e63c: 540001ad     	b.le	0x4e670 <_gap_provider_kernel+0x668>
   4e640: 90000004     	adrp	x4, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e640:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__coil.compiler.resolve.PrimitiveProvider.0
   4e644: d101a3a0     	sub	x0, x29, #0x68
   4e648: aa1b03e1     	mov	x1, x27
   4e64c: f9400084     	ldr	x4, [x4]
		000000000004e64c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__coil.compiler.resolve.PrimitiveProvider.0
   4e650: aa1903e2     	mov	x2, x25
   4e654: aa1503e3     	mov	x3, x21
   4e658: 52800405     	mov	w5, #0x20               ; =32
   4e65c: 52800106     	mov	w6, #0x8                ; =8
   4e660: 94000000     	bl	0x4e660 <_gap_provider_kernel+0x658>
		000000000004e660:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
   4e664: 340008a0     	cbz	w0, 0x4e778 <_gap_provider_kernel+0x770>
   4e668: aa0103fb     	mov	x27, x1
   4e66c: aa1503f9     	mov	x25, x21
   4e670: f9401ffc     	ldr	x28, [sp, #0x38]
   4e674: f94033f5     	ldr	x21, [sp, #0x60]
   4e678: 17ffff41     	b	0x4e37c <_gap_provider_kernel+0x374>
   4e67c: a9446ff9     	ldp	x25, x27, [sp, #0x40]
   4e680: 52800618     	mov	w24, #0x30              ; =48
   4e684: a945d7fa     	ldp	x26, x21, [sp, #0x58]
   4e688: f9401ffc     	ldr	x28, [sp, #0x38]
   4e68c: 17ffff45     	b	0x4e3a0 <_gap_provider_kernel+0x398>
   4e690: 91002108     	add	x8, x8, #0x8
   4e694: f8410509     	ldr	x9, [x8], #0x10
   4e698: b4ffe189     	cbz	x9, 0x4e2c8 <_gap_provider_kernel+0x2c0>
   4e69c: f1000673     	subs	x19, x19, #0x1
   4e6a0: 54ffffa1     	b.ne	0x4e694 <_gap_provider_kernel+0x68c>
   4e6a4: 17fffe97     	b	0x4e100 <_gap_provider_kernel+0xf8>
   4e6a8: 90000008     	adrp	x8, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e6a8:  ARM64_RELOC_PAGE21	__MergedGlobals.335
   4e6ac: 91000108     	add	x8, x8, #0x0
		000000000004e6ac:  ARM64_RELOC_PAGEOFF12	__MergedGlobals.335
   4e6b0: f100075f     	cmp	x26, #0x1
   4e6b4: a909a3f9     	stp	x25, x8, [sp, #0x98]
   4e6b8: 90000008     	adrp	x8, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e6b8:  ARM64_RELOC_PAGE21	l_vtable.coil.alloc.Allocator-dyn.3
   4e6bc: 91000108     	add	x8, x8, #0x0
		000000000004e6bc:  ARM64_RELOC_PAGEOFF12	l_vtable.coil.alloc.Allocator-dyn.3
   4e6c0: a908ebfb     	stp	x27, x26, [sp, #0x88]
   4e6c4: f90057e8     	str	x8, [sp, #0xa8]
   4e6c8: 5400024b     	b.lt	0x4e710 <_gap_provider_kernel+0x708>
   4e6cc: 91006368     	add	x8, x27, #0x18
   4e6d0: aa1a03f3     	mov	x19, x26
   4e6d4: aa0803f4     	mov	x20, x8
   4e6d8: f8420689     	ldr	x9, [x20], #0x20
   4e6dc: eb16013f     	cmp	x9, x22
   4e6e0: 54000541     	b.ne	0x4e788 <_gap_provider_kernel+0x780>
   4e6e4: f85f8100     	ldur	x0, [x8, #-0x8]
   4e6e8: f9400be1     	ldr	x1, [sp, #0x10]
   4e6ec: aa1603e2     	mov	x2, x22
   4e6f0: 94000000     	bl	0x4e6f0 <_gap_provider_kernel+0x6e8>
		000000000004e6f0:  ARM64_RELOC_BRANCH26	_memcmp
   4e6f4: 350004a0     	cbnz	w0, 0x4e788 <_gap_provider_kernel+0x780>
   4e6f8: f1000673     	subs	x19, x19, #0x1
   4e6fc: aa1403e8     	mov	x8, x20
   4e700: 54fffec1     	b.ne	0x4e6d8 <_gap_provider_kernel+0x6d0>
   4e704: f94007f4     	ldr	x20, [sp, #0x8]
   4e708: 8b140354     	add	x20, x26, x20
   4e70c: 14000004     	b	0x4e71c <_gap_provider_kernel+0x714>
   4e710: f94007f4     	ldr	x20, [sp, #0x8]
   4e714: 8b140354     	add	x20, x26, x20
   4e718: b400005a     	cbz	x26, 0x4e720 <_gap_provider_kernel+0x718>
   4e71c: f9004bff     	str	xzr, [sp, #0x90]
   4e720: f100073f     	cmp	x25, #0x1
   4e724: 54ffc96b     	b.lt	0x4e050 <_gap_provider_kernel+0x48>
   4e728: 90000003     	adrp	x3, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e728:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__coil.compiler.resolve.PrimitiveProvider.0
   4e72c: 910223e8     	add	x8, sp, #0x88
   4e730: aa1b03e1     	mov	x1, x27
   4e734: f9400063     	ldr	x3, [x3]
		000000000004e734:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__coil.compiler.resolve.PrimitiveProvider.0
   4e738: 91006100     	add	x0, x8, #0x18
   4e73c: aa1903e2     	mov	x2, x25
   4e740: 52800404     	mov	w4, #0x20               ; =32
   4e744: 52800105     	mov	w5, #0x8                ; =8
   4e748: 94000000     	bl	0x4e748 <_gap_provider_kernel+0x740>
		000000000004e748:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
   4e74c: 17fffe41     	b	0x4e050 <_gap_provider_kernel+0x48>
   4e750: aa1f03f4     	mov	x20, xzr
   4e754: aa1403e0     	mov	x0, x20
   4e758: a9537bfd     	ldp	x29, x30, [sp, #0x130]
   4e75c: a9524ff4     	ldp	x20, x19, [sp, #0x120]
   4e760: a95157f6     	ldp	x22, x21, [sp, #0x110]
   4e764: a9505ff8     	ldp	x24, x23, [sp, #0x100]
   4e768: a94f67fa     	ldp	x26, x25, [sp, #0xf0]
   4e76c: a94e6ffc     	ldp	x28, x27, [sp, #0xe0]
   4e770: 910503ff     	add	sp, sp, #0x140
   4e774: d65f03c0     	ret
   4e778: d37beaa1     	lsl	x1, x21, #5
   4e77c: 90000000     	adrp	x0, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e77c:  ARM64_RELOC_PAGE21	l_cstr.11620
   4e780: 91000000     	add	x0, x0, #0x0
		000000000004e780:  ARM64_RELOC_PAGEOFF12	l_cstr.11620
   4e784: 94000000     	bl	0x4e784 <_gap_provider_kernel+0x77c>
		000000000004e784:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
   4e788: 90000000     	adrp	x0, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e788:  ARM64_RELOC_PAGE21	l_str.11514
   4e78c: 91000000     	add	x0, x0, #0x0
		000000000004e78c:  ARM64_RELOC_PAGEOFF12	l_str.11514
   4e790: 90000002     	adrp	x2, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e790:  ARM64_RELOC_PAGE21	l_str.11515
   4e794: 91000042     	add	x2, x2, #0x0
		000000000004e794:  ARM64_RELOC_PAGEOFF12	l_str.11515
   4e798: 52800321     	mov	w1, #0x19               ; =25
   4e79c: 52800163     	mov	w3, #0xb                ; =11
   4e7a0: 528002a4     	mov	w4, #0x15               ; =21
   4e7a4: 94000000     	bl	0x4e7a4 <_gap_provider_kernel+0x79c>
		000000000004e7a4:  ARM64_RELOC_BRANCH26	_coil.assert.assert-fail
   4e7a8: 90000000     	adrp	x0, 0x4e000 <_gap_provider_create+0x8e0>
		000000000004e7a8:  ARM64_RELOC_PAGE21	l_cstr.11620
   4e7ac: 91000000     	add	x0, x0, #0x0
		000000000004e7ac:  ARM64_RELOC_PAGEOFF12	l_cstr.11620
   4e7b0: 52800801     	mov	w1, #0x40               ; =64
   4e7b4: 94000000     	bl	0x4e7b4 <_gap_provider_kernel+0x7ac>
		000000000004e7b4:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
