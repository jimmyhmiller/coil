
build/frontend-providers/stogir-before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000000aee0 <_coil.compiler.resolve.primitive-providers-in>:
    aee0: d10483ff     	sub	sp, sp, #0x120
    aee4: f90003fd     	str	x29, [sp]
    aee8: f90007fe     	str	x30, [sp, #0x8]
    aeec: 910003fd     	mov	x29, sp
    aef0: f90067f3     	str	x19, [sp, #0xc8]
    aef4: f9006bf4     	str	x20, [sp, #0xd0]
    aef8: f9006ff5     	str	x21, [sp, #0xd8]
    aefc: f90073f6     	str	x22, [sp, #0xe0]
    af00: f90077f7     	str	x23, [sp, #0xe8]
    af04: f9007bf8     	str	x24, [sp, #0xf0]
    af08: f9007ff9     	str	x25, [sp, #0xf8]
    af0c: f90083fa     	str	x26, [sp, #0x100]
    af10: f90087fb     	str	x27, [sp, #0x108]
    af14: f9008bfc     	str	x28, [sp, #0x110]
    af18: 910103f0     	add	x16, sp, #0x40
    af1c: aa1f0207     	orr	x7, x16, xzr
    af20: f9400009     	ldr	x9, [x0]
    af24: 910020f3     	add	x19, x7, #0x8
    af28: f9400400     	ldr	x0, [x0, #0x8]
    af2c: 910043f0     	add	x16, sp, #0x10
    af30: d2e00011     	movz	x17, #0x0, lsl #48
    af34: f9000211     	str	x17, [x16]
    af38: 910043f0     	add	x16, sp, #0x10
    af3c: d2e00011     	movz	x17, #0x0, lsl #48
    af40: f9000611     	str	x17, [x16, #0x8]
    af44: 910043f0     	add	x16, sp, #0x10
    af48: d2e00011     	movz	x17, #0x0, lsl #48
    af4c: f9000a11     	str	x17, [x16, #0x10]
    af50: 910043f0     	add	x16, sp, #0x10
    af54: f9000e09     	str	x9, [x16, #0x18]
    af58: 910043f0     	add	x16, sp, #0x10
    af5c: f9001200     	str	x0, [x16, #0x20]
    af60: 910043e0     	add	x0, sp, #0x10
    af64: aa0803f4     	mov	x20, x8
    af68: aa0103f5     	mov	x21, x1
    af6c: aa0203f6     	mov	x22, x2
    af70: aa0303f7     	mov	x23, x3
    af74: aa0403f8     	mov	x24, x4
    af78: aa0503f9     	mov	x25, x5
    af7c: aa0603fa     	mov	x26, x6
    af80: d2800041     	mov	x1, #0x2                ; =2
    af84: 94000000     	bl	0xaf84 <_coil.compiler.resolve.primitive-providers-in+0xa4>
		000000000000af84:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__coil.compiler.resolve.PrimitiveProvider
    af88: 910043f0     	add	x16, sp, #0x10
    af8c: f9400200     	ldr	x0, [x16]
    af90: f9000017     	str	x23, [x0]
    af94: f9000418     	str	x24, [x0, #0x8]
    af98: f9000819     	str	x25, [x0, #0x10]
    af9c: f9000c1a     	str	x26, [x0, #0x18]
    afa0: 910043f0     	add	x16, sp, #0x10
    afa4: d2800031     	mov	x17, #0x1               ; =1
    afa8: f9000611     	str	x17, [x16, #0x8]
    afac: d2e00017     	movz	x23, #0x0, lsl #48
    afb0: 140000f4     	b	0xb380 <_coil.compiler.resolve.primitive-providers-in+0x4a0>
    afb4: d1000400     	sub	x0, x0, #0x1
    afb8: 9345fc00     	asr	x0, x0, #5
    afbc: d37be800     	lsl	x0, x0, #5
    afc0: eb00039f     	cmp	x28, x0
    afc4: 5400006b     	b.lt	0xafd0 <_coil.compiler.resolve.primitive-providers-in+0xf0>
    afc8: f94006a0     	ldr	x0, [x21, #0x8]
    afcc: 1400001a     	b	0xb034 <_coil.compiler.resolve.primitive-providers-in+0x154>
    afd0: f94002a0     	ldr	x0, [x21]
    afd4: f9400ea1     	ldr	x1, [x21, #0x18]
    afd8: 14000015     	b	0xb02c <_coil.compiler.resolve.primitive-providers-in+0x14c>
    afdc: d37ff800     	lsl	x0, x0, #1
    afe0: aa0003e1     	mov	x1, x0
    afe4: 910043e0     	add	x0, sp, #0x10
    afe8: 94000000     	bl	0xafe8 <_coil.compiler.resolve.primitive-providers-in+0x108>
		000000000000afe8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__coil.compiler.resolve.PrimitiveProvider
    afec: 91000680     	add	x0, x20, #0x1
    aff0: 910043f0     	add	x16, sp, #0x10
    aff4: f9400201     	ldr	x1, [x16]
    aff8: 8b141421     	add	x1, x1, x20, lsl #5
    affc: f900003b     	str	x27, [x1]
    b000: f900043c     	str	x28, [x1, #0x8]
    b004: f9000833     	str	x19, [x1, #0x10]
    b008: f9000c3a     	str	x26, [x1, #0x18]
    b00c: 910043f0     	add	x16, sp, #0x10
    b010: f9000600     	str	x0, [x16, #0x8]
    b014: 14000028     	b	0xb0b4 <_coil.compiler.resolve.primitive-providers-in+0x1d4>
    b018: 9ac12b82     	asr	x2, x28, x1
    b01c: d1001421     	sub	x1, x1, #0x5
    b020: 92401042     	and	x2, x2, #0x1f
    b024: f9401000     	ldr	x0, [x0, #0x20]
    b028: f8627800     	ldr	x0, [x0, x2, lsl #3]
    b02c: f100003f     	cmp	x1, #0x0
    b030: 54ffff4c     	b.gt	0xb018 <_coil.compiler.resolve.primitive-providers-in+0x138>
    b034: 92401381     	and	x1, x28, #0x1f
    b038: d2801e11     	mov	x17, #0xf0              ; =240
    b03c: 9b117c21     	mul	x1, x1, x17
    b040: f9400c00     	ldr	x0, [x0, #0x18]
    b044: 8b000022     	add	x2, x1, x0
    b048: 91004043     	add	x3, x2, #0x10
    b04c: 91014064     	add	x4, x3, #0x50
    b050: 92e00005     	movn	x5, #0x0, lsl #48
    b054: 14000026     	b	0xb0ec <_coil.compiler.resolve.primitive-providers-in+0x20c>
    b058: d340fce7     	lsr	x7, x7, #0
    b05c: f9003fe3     	str	x3, [sp, #0x78]
    b060: f90043e4     	str	x4, [sp, #0x80]
    b064: f90047e5     	str	x5, [sp, #0x88]
    b068: f9004be9     	str	x9, [sp, #0x90]
    b06c: f90033f6     	str	x22, [sp, #0x60]
    b070: aa0103f6     	mov	x22, x1
    b074: aa1803e1     	mov	x1, x24
    b078: f90037f8     	str	x24, [sp, #0x68]
    b07c: aa0003f8     	mov	x24, x0
    b080: aa0603e0     	mov	x0, x6
    b084: f9003bf9     	str	x25, [sp, #0x70]
    b088: aa0203f9     	mov	x25, x2
    b08c: aa0703e2     	mov	x2, x7
    b090: 94000000     	bl	0xb090 <_coil.compiler.resolve.primitive-providers-in+0x1b0>
		000000000000b090:  ARM64_RELOC_BRANCH26	_memcmp
    b094: 93407c00     	sxtw	x0, w0
    b098: f100001f     	cmp	x0, #0x0
    b09c: 540005a0     	b.eq	0xb150 <_coil.compiler.resolve.primitive-providers-in+0x270>
    b0a0: f90063f4     	str	x20, [sp, #0xc0]
    b0a4: f90053fa     	str	x26, [sp, #0xa0]
    b0a8: f9005bfb     	str	x27, [sp, #0xb0]
    b0ac: f9005ffc     	str	x28, [sp, #0xb8]
    b0b0: f9004ff3     	str	x19, [sp, #0x98]
    b0b4: f94063f4     	ldr	x20, [sp, #0xc0]
    b0b8: f94053fa     	ldr	x26, [sp, #0xa0]
    b0bc: f9405bfb     	ldr	x27, [sp, #0xb0]
    b0c0: f9405ffc     	ldr	x28, [sp, #0xb8]
    b0c4: f9403fe3     	ldr	x3, [sp, #0x78]
    b0c8: f94043e4     	ldr	x4, [sp, #0x80]
    b0cc: f9404ff3     	ldr	x19, [sp, #0x98]
    b0d0: aa1803e0     	mov	x0, x24
    b0d4: f94037f8     	ldr	x24, [sp, #0x68]
    b0d8: aa1603e1     	mov	x1, x22
    b0dc: f94033f6     	ldr	x22, [sp, #0x60]
    b0e0: aa1903e2     	mov	x2, x25
    b0e4: f9403bf9     	ldr	x25, [sp, #0x70]
    b0e8: f94047e5     	ldr	x5, [sp, #0x88]
    b0ec: f9400486     	ldr	x6, [x4, #0x8]
    b0f0: 910004a5     	add	x5, x5, #0x1
    b0f4: eb0600bf     	cmp	x5, x6
    b0f8: 54001b4a     	b.ge	0xb460 <_coil.compiler.resolve.primitive-providers-in+0x580>
    b0fc: d2800611     	mov	x17, #0x30              ; =48
    b100: 9b117ca6     	mul	x6, x5, x17
    b104: f9402867     	ldr	x7, [x3, #0x50]
    b108: 8b0700c8     	add	x8, x6, x7
    b10c: aa1f0109     	orr	x9, x8, xzr
    b110: f86768c6     	ldr	x6, [x6, x7]
    b114: f9400507     	ldr	x7, [x8, #0x8]
    b118: eb1900ff     	cmp	x7, x25
    b11c: 54001b41     	b.ne	0xb484 <_coil.compiler.resolve.primitive-providers-in+0x5a4>
    b120: f10000ff     	cmp	x7, #0x0
    b124: 54fff9a1     	b.ne	0xb058 <_coil.compiler.resolve.primitive-providers-in+0x178>
    b128: f90033f6     	str	x22, [sp, #0x60]
    b12c: f9003bf9     	str	x25, [sp, #0x70]
    b130: f9003fe3     	str	x3, [sp, #0x78]
    b134: f90043e4     	str	x4, [sp, #0x80]
    b138: f90047e5     	str	x5, [sp, #0x88]
    b13c: f9004be9     	str	x9, [sp, #0x90]
    b140: f90037f8     	str	x24, [sp, #0x68]
    b144: aa0003f8     	mov	x24, x0
    b148: aa0103f6     	mov	x22, x1
    b14c: aa0203f9     	mov	x25, x2
    b150: 910103e8     	add	x8, sp, #0x40
    b154: f9404be0     	ldr	x0, [sp, #0x90]
    b158: aa1a03e1     	mov	x1, x26
    b15c: aa1b03e2     	mov	x2, x27
    b160: 94000000     	bl	0xb160 <_coil.compiler.resolve.primitive-providers-in+0x280>
		000000000000b160:  ARM64_RELOC_BRANCH26	_coil.compiler.loader.use-local-of
    b164: 910103f0     	add	x16, sp, #0x40
    b168: b9400200     	ldr	w0, [x16]
    b16c: d340fc10     	lsr	x16, x0, #0
    b170: f100061f     	cmp	x16, #0x1
    b174: 54000180     	b.eq	0xb1a4 <_coil.compiler.resolve.primitive-providers-in+0x2c4>
    b178: 54000043     	b.lo	0xb180 <_coil.compiler.resolve.primitive-providers-in+0x2a0>
    b17c: 1400000b     	b	0xb1a8 <_coil.compiler.resolve.primitive-providers-in+0x2c8>
    b180: f100021f     	cmp	x16, #0x0
    b184: 54000040     	b.eq	0xb18c <_coil.compiler.resolve.primitive-providers-in+0x2ac>
    b188: 14000008     	b	0xb1a8 <_coil.compiler.resolve.primitive-providers-in+0x2c8>
    b18c: f90063f4     	str	x20, [sp, #0xc0]
    b190: f90053fa     	str	x26, [sp, #0xa0]
    b194: f9005bfb     	str	x27, [sp, #0xb0]
    b198: f9005ffc     	str	x28, [sp, #0xb8]
    b19c: f9004ff3     	str	x19, [sp, #0x98]
    b1a0: 17ffffc5     	b	0xb0b4 <_coil.compiler.resolve.primitive-providers-in+0x1d4>
    b1a4: 14000002     	b	0xb1ac <_coil.compiler.resolve.primitive-providers-in+0x2cc>
    b1a8: 14000090     	b	0xb3e8 <_coil.compiler.resolve.primitive-providers-in+0x508>
    b1ac: 910103f0     	add	x16, sp, #0x40
    b1b0: f9400600     	ldr	x0, [x16, #0x8]
    b1b4: f9400661     	ldr	x1, [x19, #0x8]
    b1b8: 92e00002     	movn	x2, #0x0, lsl #48
    b1bc: d2e00003     	movz	x3, #0x0, lsl #48
    b1c0: 1400000c     	b	0xb1f0 <_coil.compiler.resolve.primitive-providers-in+0x310>
    b1c4: d503201f     	nop
    b1c8: d280003b     	mov	x27, #0x1               ; =1
    b1cc: f94063f4     	ldr	x20, [sp, #0xc0]
    b1d0: f9405ffc     	ldr	x28, [sp, #0xb8]
    b1d4: aa1303e0     	mov	x0, x19
    b1d8: f9404ff3     	ldr	x19, [sp, #0x98]
    b1dc: aa1a03e1     	mov	x1, x26
    b1e0: f94053fa     	ldr	x26, [sp, #0xa0]
    b1e4: f94057e2     	ldr	x2, [sp, #0xa8]
    b1e8: aa1b03e3     	mov	x3, x27
    b1ec: f9405bfb     	ldr	x27, [sp, #0xb0]
    b1f0: 910043f0     	add	x16, sp, #0x10
    b1f4: f9400604     	ldr	x4, [x16, #0x8]
    b1f8: 91000442     	add	x2, x2, #0x1
    b1fc: eb04005f     	cmp	x2, x4
    b200: 5400160a     	b.ge	0xb4c0 <_coil.compiler.resolve.primitive-providers-in+0x5e0>
    b204: 910043f0     	add	x16, sp, #0x10
    b208: f9400204     	ldr	x4, [x16]
    b20c: 8b021484     	add	x4, x4, x2, lsl #5
    b210: f9400085     	ldr	x5, [x4]
    b214: f9400486     	ldr	x6, [x4, #0x8]
    b218: f9400887     	ldr	x7, [x4, #0x10]
    b21c: f9400c84     	ldr	x4, [x4, #0x18]
    b220: f8786ac8     	ldr	x8, [x22, x24]
    b224: f9400729     	ldr	x9, [x25, #0x8]
    b228: eb0900df     	cmp	x6, x9
    b22c: 540015c1     	b.ne	0xb4e4 <_coil.compiler.resolve.primitive-providers-in+0x604>
    b230: f10000df     	cmp	x6, #0x0
    b234: 54000321     	b.ne	0xb298 <_coil.compiler.resolve.primitive-providers-in+0x3b8>
    b238: f90063f4     	str	x20, [sp, #0xc0]
    b23c: f90053fa     	str	x26, [sp, #0xa0]
    b240: f9005bfb     	str	x27, [sp, #0xb0]
    b244: aa0303fb     	mov	x27, x3
    b248: f9005ffc     	str	x28, [sp, #0xb8]
    b24c: f9004ff3     	str	x19, [sp, #0x98]
    b250: aa0003f3     	mov	x19, x0
    b254: aa0103fa     	mov	x26, x1
    b258: f90057e2     	str	x2, [sp, #0xa8]
    b25c: aa0703fc     	mov	x28, x7
    b260: aa0403f4     	mov	x20, x4
    b264: eb1a029f     	cmp	x20, x26
    b268: 54fffb21     	b.ne	0xb1cc <_coil.compiler.resolve.primitive-providers-in+0x2ec>
    b26c: f100029f     	cmp	x20, #0x0
    b270: 54fffac0     	b.eq	0xb1c8 <_coil.compiler.resolve.primitive-providers-in+0x2e8>
    b274: d340fe80     	lsr	x0, x20, #0
    b278: aa1303e1     	mov	x1, x19
    b27c: aa0003e2     	mov	x2, x0
    b280: aa1c03e0     	mov	x0, x28
    b284: 94000000     	bl	0xb284 <_coil.compiler.resolve.primitive-providers-in+0x3a4>
		000000000000b284:  ARM64_RELOC_BRANCH26	_memcmp
    b288: 93407c00     	sxtw	x0, w0
    b28c: f100001f     	cmp	x0, #0x0
    b290: 54fff9c0     	b.eq	0xb1c8 <_coil.compiler.resolve.primitive-providers-in+0x2e8>
    b294: 17ffffce     	b	0xb1cc <_coil.compiler.resolve.primitive-providers-in+0x2ec>
    b298: d340fcc6     	lsr	x6, x6, #0
    b29c: f90057e2     	str	x2, [sp, #0xa8]
    b2a0: aa0603e2     	mov	x2, x6
    b2a4: f9004ff3     	str	x19, [sp, #0x98]
    b2a8: aa0003f3     	mov	x19, x0
    b2ac: aa0503e0     	mov	x0, x5
    b2b0: f90053fa     	str	x26, [sp, #0xa0]
    b2b4: aa0103fa     	mov	x26, x1
    b2b8: aa0803e1     	mov	x1, x8
    b2bc: f9005bfb     	str	x27, [sp, #0xb0]
    b2c0: aa0303fb     	mov	x27, x3
    b2c4: f9005ffc     	str	x28, [sp, #0xb8]
    b2c8: aa0703fc     	mov	x28, x7
    b2cc: f90063f4     	str	x20, [sp, #0xc0]
    b2d0: aa0403f4     	mov	x20, x4
    b2d4: 94000000     	bl	0xb2d4 <_coil.compiler.resolve.primitive-providers-in+0x3f4>
		000000000000b2d4:  ARM64_RELOC_BRANCH26	_memcmp
    b2d8: 93407c00     	sxtw	x0, w0
    b2dc: f100001f     	cmp	x0, #0x0
    b2e0: 54fffc20     	b.eq	0xb264 <_coil.compiler.resolve.primitive-providers-in+0x384>
    b2e4: 17ffffba     	b	0xb1cc <_coil.compiler.resolve.primitive-providers-in+0x2ec>
    b2e8: f100037f     	cmp	x27, #0x0
    b2ec: 54ffee41     	b.ne	0xb0b4 <_coil.compiler.resolve.primitive-providers-in+0x1d4>
    b2f0: aa1f0094     	orr	x20, x4, xzr
    b2f4: f8786adb     	ldr	x27, [x22, x24]
    b2f8: f940073c     	ldr	x28, [x25, #0x8]
    b2fc: 910043f0     	add	x16, sp, #0x10
    b300: f9400a00     	ldr	x0, [x16, #0x10]
    b304: eb00029f     	cmp	x20, x0
    b308: 54ffe72b     	b.lt	0xafec <_coil.compiler.resolve.primitive-providers-in+0x10c>
    b30c: f100001f     	cmp	x0, #0x0
    b310: 54ffe661     	b.ne	0xafdc <_coil.compiler.resolve.primitive-providers-in+0xfc>
    b314: d2800040     	mov	x0, #0x2                ; =2
    b318: 17ffff32     	b	0xafe0 <_coil.compiler.resolve.primitive-providers-in+0x100>
    b31c: f94063f4     	ldr	x20, [sp, #0xc0]
    b320: f94033f6     	ldr	x22, [sp, #0x60]
    b324: f9403bf9     	ldr	x25, [sp, #0x70]
    b328: f94053fa     	ldr	x26, [sp, #0xa0]
    b32c: f9405bfb     	ldr	x27, [sp, #0xb0]
    b330: f9404ff3     	ldr	x19, [sp, #0x98]
    b334: f94037f8     	ldr	x24, [sp, #0x68]
    b338: f9405ffc     	ldr	x28, [sp, #0xb8]
    b33c: f9400aa0     	ldr	x0, [x21, #0x10]
    b340: 9100079c     	add	x28, x28, #0x1
    b344: eb00039f     	cmp	x28, x0
    b348: 54000e2a     	b.ge	0xb50c <_coil.compiler.resolve.primitive-providers-in+0x62c>
    b34c: f100039f     	cmp	x28, #0x0
    b350: 54000e6b     	b.lt	0xb51c <_coil.compiler.resolve.primitive-providers-in+0x63c>
    b354: eb00039f     	cmp	x28, x0
    b358: 54000e6a     	b.ge	0xb524 <_coil.compiler.resolve.primitive-providers-in+0x644>
    b35c: f100801f     	cmp	x0, #0x20
    b360: 54ffe2aa     	b.ge	0xafb4 <_coil.compiler.resolve.primitive-providers-in+0xd4>
    b364: d2e00000     	movz	x0, #0x0, lsl #48
    b368: 17ffff16     	b	0xafc0 <_coil.compiler.resolve.primitive-providers-in+0xe0>
    b36c: d503201f     	nop
    b370: 910006f7     	add	x23, x23, #0x1
    b374: f94063f4     	ldr	x20, [sp, #0xc0]
    b378: f94033f6     	ldr	x22, [sp, #0x60]
    b37c: f9404ff3     	ldr	x19, [sp, #0x98]
    b380: 910043f0     	add	x16, sp, #0x10
    b384: f9400600     	ldr	x0, [x16, #0x8]
    b388: eb0002ff     	cmp	x23, x0
    b38c: 54000d0a     	b.ge	0xb52c <_coil.compiler.resolve.primitive-providers-in+0x64c>
    b390: 910043f0     	add	x16, sp, #0x10
    b394: f9400200     	ldr	x0, [x16]
    b398: 8b171400     	add	x0, x0, x23, lsl #5
    b39c: f9400018     	ldr	x24, [x0]
    b3a0: f9400419     	ldr	x25, [x0, #0x8]
    b3a4: f940081a     	ldr	x26, [x0, #0x10]
    b3a8: f9400c1b     	ldr	x27, [x0, #0x18]
    b3ac: aa1603e0     	mov	x0, x22
    b3b0: aa1803e1     	mov	x1, x24
    b3b4: aa1903e2     	mov	x2, x25
    b3b8: aa1a03e3     	mov	x3, x26
    b3bc: aa1b03e4     	mov	x4, x27
    b3c0: 94000000     	bl	0xb3c0 <_coil.compiler.resolve.primitive-providers-in+0x4e0>
		000000000000b3c0:  ARM64_RELOC_BRANCH26	_coil.compiler.resolve.exports-check
    b3c4: f100001f     	cmp	x0, #0x0
    b3c8: 54000b60     	b.eq	0xb534 <_coil.compiler.resolve.primitive-providers-in+0x654>
    b3cc: 92e0001c     	movn	x28, #0x0, lsl #48
    b3d0: 17ffffdb     	b	0xb33c <_coil.compiler.resolve.primitive-providers-in+0x45c>
    b3d4: f9400aa0     	ldr	x0, [x21, #0x10]
    b3d8: aa0003e1     	mov	x1, x0
    b3dc: f9405fe0     	ldr	x0, [sp, #0xb8]
    b3e0: 94000000     	bl	0xb3e0 <_coil.compiler.resolve.primitive-providers-in+0x500>
		000000000000b3e0:  ARM64_RELOC_BRANCH26	_coil.avec.avec--bounds-error
    b3e4: 14000000     	b	0xb3e4 <_coil.compiler.resolve.primitive-providers-in+0x504>
    b3e8: d4200000     	brk	#0
    b3ec: 17ffffff     	b	0xb3e8 <_coil.compiler.resolve.primitive-providers-in+0x508>
    b3f0: 910043f0     	add	x16, sp, #0x10
    b3f4: f9400201     	ldr	x1, [x16]
    b3f8: 910043f0     	add	x16, sp, #0x10
    b3fc: f9400a02     	ldr	x2, [x16, #0x10]
    b400: 910043f0     	add	x16, sp, #0x10
    b404: f9400e03     	ldr	x3, [x16, #0x18]
    b408: 910043f0     	add	x16, sp, #0x10
    b40c: f9401204     	ldr	x4, [x16, #0x20]
    b410: f94063e5     	ldr	x5, [sp, #0xc0]
    b414: f90000a1     	str	x1, [x5]
    b418: f90004a0     	str	x0, [x5, #0x8]
    b41c: f90008a2     	str	x2, [x5, #0x10]
    b420: f9000ca3     	str	x3, [x5, #0x18]
    b424: f90010a4     	str	x4, [x5, #0x20]
    b428: f94067f3     	ldr	x19, [sp, #0xc8]
    b42c: f9406bf4     	ldr	x20, [sp, #0xd0]
    b430: f9406ff5     	ldr	x21, [sp, #0xd8]
    b434: f94073f6     	ldr	x22, [sp, #0xe0]
    b438: f94077f7     	ldr	x23, [sp, #0xe8]
    b43c: f9407bf8     	ldr	x24, [sp, #0xf0]
    b440: f9407ff9     	ldr	x25, [sp, #0xf8]
    b444: f94083fa     	ldr	x26, [sp, #0x100]
    b448: f94087fb     	ldr	x27, [sp, #0x108]
    b44c: f9408bfc     	ldr	x28, [sp, #0x110]
    b450: f94003fd     	ldr	x29, [sp]
    b454: f94007fe     	ldr	x30, [sp, #0x8]
    b458: 910483ff     	add	sp, sp, #0x120
    b45c: d65f03c0     	ret
    b460: f90063f4     	str	x20, [sp, #0xc0]
    b464: f90033f6     	str	x22, [sp, #0x60]
    b468: f9003bf9     	str	x25, [sp, #0x70]
    b46c: f90053fa     	str	x26, [sp, #0xa0]
    b470: f9005bfb     	str	x27, [sp, #0xb0]
    b474: f9005ffc     	str	x28, [sp, #0xb8]
    b478: f9004ff3     	str	x19, [sp, #0x98]
    b47c: f90037f8     	str	x24, [sp, #0x68]
    b480: 17ffffa7     	b	0xb31c <_coil.compiler.resolve.primitive-providers-in+0x43c>
    b484: f90063f4     	str	x20, [sp, #0xc0]
    b488: f90033f6     	str	x22, [sp, #0x60]
    b48c: f9003bf9     	str	x25, [sp, #0x70]
    b490: f90053fa     	str	x26, [sp, #0xa0]
    b494: f9005bfb     	str	x27, [sp, #0xb0]
    b498: f9005ffc     	str	x28, [sp, #0xb8]
    b49c: f9003fe3     	str	x3, [sp, #0x78]
    b4a0: f90043e4     	str	x4, [sp, #0x80]
    b4a4: f90047e5     	str	x5, [sp, #0x88]
    b4a8: f9004ff3     	str	x19, [sp, #0x98]
    b4ac: f90037f8     	str	x24, [sp, #0x68]
    b4b0: aa0003f8     	mov	x24, x0
    b4b4: aa0103f6     	mov	x22, x1
    b4b8: aa0203f9     	mov	x25, x2
    b4bc: 17fffefe     	b	0xb0b4 <_coil.compiler.resolve.primitive-providers-in+0x1d4>
    b4c0: f90063f4     	str	x20, [sp, #0xc0]
    b4c4: f90053fa     	str	x26, [sp, #0xa0]
    b4c8: f9005bfb     	str	x27, [sp, #0xb0]
    b4cc: aa0303fb     	mov	x27, x3
    b4d0: f9005ffc     	str	x28, [sp, #0xb8]
    b4d4: f9004ff3     	str	x19, [sp, #0x98]
    b4d8: aa0003f3     	mov	x19, x0
    b4dc: aa0103fa     	mov	x26, x1
    b4e0: 17ffff82     	b	0xb2e8 <_coil.compiler.resolve.primitive-providers-in+0x408>
    b4e4: f90063f4     	str	x20, [sp, #0xc0]
    b4e8: f90053fa     	str	x26, [sp, #0xa0]
    b4ec: f9005bfb     	str	x27, [sp, #0xb0]
    b4f0: aa0303fb     	mov	x27, x3
    b4f4: f9005ffc     	str	x28, [sp, #0xb8]
    b4f8: f9004ff3     	str	x19, [sp, #0x98]
    b4fc: aa0003f3     	mov	x19, x0
    b500: aa0103fa     	mov	x26, x1
    b504: f90057e2     	str	x2, [sp, #0xa8]
    b508: 17ffff31     	b	0xb1cc <_coil.compiler.resolve.primitive-providers-in+0x2ec>
    b50c: f90063f4     	str	x20, [sp, #0xc0]
    b510: f90033f6     	str	x22, [sp, #0x60]
    b514: f9004ff3     	str	x19, [sp, #0x98]
    b518: 17ffff96     	b	0xb370 <_coil.compiler.resolve.primitive-providers-in+0x490>
    b51c: f9005ffc     	str	x28, [sp, #0xb8]
    b520: 17ffffad     	b	0xb3d4 <_coil.compiler.resolve.primitive-providers-in+0x4f4>
    b524: f9005ffc     	str	x28, [sp, #0xb8]
    b528: 17ffffab     	b	0xb3d4 <_coil.compiler.resolve.primitive-providers-in+0x4f4>
    b52c: f90063f4     	str	x20, [sp, #0xc0]
    b530: 17ffffb0     	b	0xb3f0 <_coil.compiler.resolve.primitive-providers-in+0x510>
    b534: f90063f4     	str	x20, [sp, #0xc0]
    b538: f90033f6     	str	x22, [sp, #0x60]
    b53c: f9004ff3     	str	x19, [sp, #0x98]
    b540: 17ffff8c     	b	0xb370 <_coil.compiler.resolve.primitive-providers-in+0x490>
