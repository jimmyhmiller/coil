
build/frontend-providers/stogir-after.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000000aed8 <_coil.compiler.resolve.primitive-providers-in>:
    aed8: d10483ff     	sub	sp, sp, #0x120
    aedc: f90003fd     	str	x29, [sp]
    aee0: f90007fe     	str	x30, [sp, #0x8]
    aee4: 910003fd     	mov	x29, sp
    aee8: f90067f3     	str	x19, [sp, #0xc8]
    aeec: f9006bf4     	str	x20, [sp, #0xd0]
    aef0: f9006ff5     	str	x21, [sp, #0xd8]
    aef4: f90073f6     	str	x22, [sp, #0xe0]
    aef8: f90077f7     	str	x23, [sp, #0xe8]
    aefc: f9007bf8     	str	x24, [sp, #0xf0]
    af00: f9007ff9     	str	x25, [sp, #0xf8]
    af04: f90083fa     	str	x26, [sp, #0x100]
    af08: f90087fb     	str	x27, [sp, #0x108]
    af0c: f9008bfc     	str	x28, [sp, #0x110]
    af10: 910103f0     	add	x16, sp, #0x40
    af14: aa1f0207     	orr	x7, x16, xzr
    af18: f9400009     	ldr	x9, [x0]
    af1c: 910020f3     	add	x19, x7, #0x8
    af20: f9400400     	ldr	x0, [x0, #0x8]
    af24: 910043f0     	add	x16, sp, #0x10
    af28: d2e00011     	movz	x17, #0x0, lsl #48
    af2c: f9000211     	str	x17, [x16]
    af30: 910043f0     	add	x16, sp, #0x10
    af34: d2e00011     	movz	x17, #0x0, lsl #48
    af38: f9000611     	str	x17, [x16, #0x8]
    af3c: 910043f0     	add	x16, sp, #0x10
    af40: d2e00011     	movz	x17, #0x0, lsl #48
    af44: f9000a11     	str	x17, [x16, #0x10]
    af48: 910043f0     	add	x16, sp, #0x10
    af4c: f9000e09     	str	x9, [x16, #0x18]
    af50: 910043f0     	add	x16, sp, #0x10
    af54: f9001200     	str	x0, [x16, #0x20]
    af58: 910043e0     	add	x0, sp, #0x10
    af5c: f90063e8     	str	x8, [sp, #0xc0]
    af60: aa0103f5     	mov	x21, x1
    af64: aa0203f6     	mov	x22, x2
    af68: aa0303f7     	mov	x23, x3
    af6c: aa0403f8     	mov	x24, x4
    af70: aa0503f9     	mov	x25, x5
    af74: aa0603fa     	mov	x26, x6
    af78: d2800041     	mov	x1, #0x2                ; =2
    af7c: 94000000     	bl	0xaf7c <_coil.compiler.resolve.primitive-providers-in+0xa4>
		000000000000af7c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__coil.compiler.resolve.PrimitiveProvider
    af80: 910043f0     	add	x16, sp, #0x10
    af84: f9400200     	ldr	x0, [x16]
    af88: f9000017     	str	x23, [x0]
    af8c: f9000418     	str	x24, [x0, #0x8]
    af90: f9000819     	str	x25, [x0, #0x10]
    af94: f9000c1a     	str	x26, [x0, #0x18]
    af98: 910043f0     	add	x16, sp, #0x10
    af9c: d2800031     	mov	x17, #0x1               ; =1
    afa0: f9000611     	str	x17, [x16, #0x8]
    afa4: d2e00017     	movz	x23, #0x0, lsl #48
    afa8: 140000eb     	b	0xb354 <_coil.compiler.resolve.primitive-providers-in+0x47c>
    afac: d1000400     	sub	x0, x0, #0x1
    afb0: 9345fc00     	asr	x0, x0, #5
    afb4: d37be800     	lsl	x0, x0, #5
    afb8: eb00039f     	cmp	x28, x0
    afbc: 5400006b     	b.lt	0xafc8 <_coil.compiler.resolve.primitive-providers-in+0xf0>
    afc0: f94006a0     	ldr	x0, [x21, #0x8]
    afc4: 1400001a     	b	0xb02c <_coil.compiler.resolve.primitive-providers-in+0x154>
    afc8: f94002a0     	ldr	x0, [x21]
    afcc: f9400ea1     	ldr	x1, [x21, #0x18]
    afd0: 14000015     	b	0xb024 <_coil.compiler.resolve.primitive-providers-in+0x14c>
    afd4: d37ff800     	lsl	x0, x0, #1
    afd8: aa0003e1     	mov	x1, x0
    afdc: 910043e0     	add	x0, sp, #0x10
    afe0: 94000000     	bl	0xafe0 <_coil.compiler.resolve.primitive-providers-in+0x108>
		000000000000afe0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__coil.compiler.resolve.PrimitiveProvider
    afe4: 91000680     	add	x0, x20, #0x1
    afe8: 910043f0     	add	x16, sp, #0x10
    afec: f9400201     	ldr	x1, [x16]
    aff0: 8b141421     	add	x1, x1, x20, lsl #5
    aff4: f900003b     	str	x27, [x1]
    aff8: f900043c     	str	x28, [x1, #0x8]
    affc: f9000833     	str	x19, [x1, #0x10]
    b000: f9000c3a     	str	x26, [x1, #0x18]
    b004: 910043f0     	add	x16, sp, #0x10
    b008: f9000600     	str	x0, [x16, #0x8]
    b00c: 14000027     	b	0xb0a8 <_coil.compiler.resolve.primitive-providers-in+0x1d0>
    b010: 9ac12b82     	asr	x2, x28, x1
    b014: d1001421     	sub	x1, x1, #0x5
    b018: 92401042     	and	x2, x2, #0x1f
    b01c: f9401000     	ldr	x0, [x0, #0x20]
    b020: f8627800     	ldr	x0, [x0, x2, lsl #3]
    b024: f100003f     	cmp	x1, #0x0
    b028: 54ffff4c     	b.gt	0xb010 <_coil.compiler.resolve.primitive-providers-in+0x138>
    b02c: 92401381     	and	x1, x28, #0x1f
    b030: d2801e11     	mov	x17, #0xf0              ; =240
    b034: 9b117c21     	mul	x1, x1, x17
    b038: f9400c00     	ldr	x0, [x0, #0x18]
    b03c: 8b000022     	add	x2, x1, x0
    b040: 91004043     	add	x3, x2, #0x10
    b044: 91014064     	add	x4, x3, #0x50
    b048: 92e00005     	movn	x5, #0x0, lsl #48
    b04c: 14000024     	b	0xb0dc <_coil.compiler.resolve.primitive-providers-in+0x204>
    b050: d340fce7     	lsr	x7, x7, #0
    b054: f9003fe3     	str	x3, [sp, #0x78]
    b058: f90043e4     	str	x4, [sp, #0x80]
    b05c: f90047e5     	str	x5, [sp, #0x88]
    b060: f9004be9     	str	x9, [sp, #0x90]
    b064: f90033f6     	str	x22, [sp, #0x60]
    b068: aa0103f6     	mov	x22, x1
    b06c: aa1803e1     	mov	x1, x24
    b070: f90037f8     	str	x24, [sp, #0x68]
    b074: aa0003f8     	mov	x24, x0
    b078: aa0603e0     	mov	x0, x6
    b07c: f9003bf9     	str	x25, [sp, #0x70]
    b080: aa0203f9     	mov	x25, x2
    b084: aa0703e2     	mov	x2, x7
    b088: 94000000     	bl	0xb088 <_coil.compiler.resolve.primitive-providers-in+0x1b0>
		000000000000b088:  ARM64_RELOC_BRANCH26	_memcmp
    b08c: 93407c00     	sxtw	x0, w0
    b090: f100001f     	cmp	x0, #0x0
    b094: 54000560     	b.eq	0xb140 <_coil.compiler.resolve.primitive-providers-in+0x268>
    b098: f90053fa     	str	x26, [sp, #0xa0]
    b09c: f9005bfb     	str	x27, [sp, #0xb0]
    b0a0: f9005ffc     	str	x28, [sp, #0xb8]
    b0a4: f9004ff3     	str	x19, [sp, #0x98]
    b0a8: f94053fa     	ldr	x26, [sp, #0xa0]
    b0ac: f9405bfb     	ldr	x27, [sp, #0xb0]
    b0b0: f9405ffc     	ldr	x28, [sp, #0xb8]
    b0b4: f9403fe3     	ldr	x3, [sp, #0x78]
    b0b8: f94043e4     	ldr	x4, [sp, #0x80]
    b0bc: f9404ff3     	ldr	x19, [sp, #0x98]
    b0c0: aa1803e0     	mov	x0, x24
    b0c4: f94037f8     	ldr	x24, [sp, #0x68]
    b0c8: aa1603e1     	mov	x1, x22
    b0cc: f94033f6     	ldr	x22, [sp, #0x60]
    b0d0: aa1903e2     	mov	x2, x25
    b0d4: f9403bf9     	ldr	x25, [sp, #0x70]
    b0d8: f94047e5     	ldr	x5, [sp, #0x88]
    b0dc: f9400486     	ldr	x6, [x4, #0x8]
    b0e0: 910004a5     	add	x5, x5, #0x1
    b0e4: eb0600bf     	cmp	x5, x6
    b0e8: 54001a6a     	b.ge	0xb434 <_coil.compiler.resolve.primitive-providers-in+0x55c>
    b0ec: d2800611     	mov	x17, #0x30              ; =48
    b0f0: 9b117ca6     	mul	x6, x5, x17
    b0f4: f9402867     	ldr	x7, [x3, #0x50]
    b0f8: 8b0700c8     	add	x8, x6, x7
    b0fc: aa1f0109     	orr	x9, x8, xzr
    b100: f86768c6     	ldr	x6, [x6, x7]
    b104: f9400507     	ldr	x7, [x8, #0x8]
    b108: eb1900ff     	cmp	x7, x25
    b10c: 54001a41     	b.ne	0xb454 <_coil.compiler.resolve.primitive-providers-in+0x57c>
    b110: f10000ff     	cmp	x7, #0x0
    b114: 54fff9e1     	b.ne	0xb050 <_coil.compiler.resolve.primitive-providers-in+0x178>
    b118: f90033f6     	str	x22, [sp, #0x60]
    b11c: f9003bf9     	str	x25, [sp, #0x70]
    b120: f9003fe3     	str	x3, [sp, #0x78]
    b124: f90043e4     	str	x4, [sp, #0x80]
    b128: f90047e5     	str	x5, [sp, #0x88]
    b12c: f9004be9     	str	x9, [sp, #0x90]
    b130: f90037f8     	str	x24, [sp, #0x68]
    b134: aa0003f8     	mov	x24, x0
    b138: aa0103f6     	mov	x22, x1
    b13c: aa0203f9     	mov	x25, x2
    b140: 910103e8     	add	x8, sp, #0x40
    b144: f9404be0     	ldr	x0, [sp, #0x90]
    b148: aa1a03e1     	mov	x1, x26
    b14c: aa1b03e2     	mov	x2, x27
    b150: 94000000     	bl	0xb150 <_coil.compiler.resolve.primitive-providers-in+0x278>
		000000000000b150:  ARM64_RELOC_BRANCH26	_coil.compiler.loader.use-local-of
    b154: 910103f0     	add	x16, sp, #0x40
    b158: b9400200     	ldr	w0, [x16]
    b15c: d340fc10     	lsr	x16, x0, #0
    b160: f100061f     	cmp	x16, #0x1
    b164: 54000160     	b.eq	0xb190 <_coil.compiler.resolve.primitive-providers-in+0x2b8>
    b168: 54000043     	b.lo	0xb170 <_coil.compiler.resolve.primitive-providers-in+0x298>
    b16c: 1400000a     	b	0xb194 <_coil.compiler.resolve.primitive-providers-in+0x2bc>
    b170: f100021f     	cmp	x16, #0x0
    b174: 54000040     	b.eq	0xb17c <_coil.compiler.resolve.primitive-providers-in+0x2a4>
    b178: 14000007     	b	0xb194 <_coil.compiler.resolve.primitive-providers-in+0x2bc>
    b17c: f90053fa     	str	x26, [sp, #0xa0]
    b180: f9005bfb     	str	x27, [sp, #0xb0]
    b184: f9005ffc     	str	x28, [sp, #0xb8]
    b188: f9004ff3     	str	x19, [sp, #0x98]
    b18c: 17ffffc7     	b	0xb0a8 <_coil.compiler.resolve.primitive-providers-in+0x1d0>
    b190: 14000002     	b	0xb198 <_coil.compiler.resolve.primitive-providers-in+0x2c0>
    b194: 1400008a     	b	0xb3bc <_coil.compiler.resolve.primitive-providers-in+0x4e4>
    b198: 910103f0     	add	x16, sp, #0x40
    b19c: f9400600     	ldr	x0, [x16, #0x8]
    b1a0: f9400661     	ldr	x1, [x19, #0x8]
    b1a4: 92e00002     	movn	x2, #0x0, lsl #48
    b1a8: d2e00003     	movz	x3, #0x0, lsl #48
    b1ac: 1400000a     	b	0xb1d4 <_coil.compiler.resolve.primitive-providers-in+0x2fc>
    b1b0: d280003b     	mov	x27, #0x1               ; =1
    b1b4: f9405ffc     	ldr	x28, [sp, #0xb8]
    b1b8: aa1303e0     	mov	x0, x19
    b1bc: f9404ff3     	ldr	x19, [sp, #0x98]
    b1c0: aa1a03e1     	mov	x1, x26
    b1c4: f94053fa     	ldr	x26, [sp, #0xa0]
    b1c8: f94057e2     	ldr	x2, [sp, #0xa8]
    b1cc: aa1b03e3     	mov	x3, x27
    b1d0: f9405bfb     	ldr	x27, [sp, #0xb0]
    b1d4: 910043f0     	add	x16, sp, #0x10
    b1d8: f9400604     	ldr	x4, [x16, #0x8]
    b1dc: 91000442     	add	x2, x2, #0x1
    b1e0: eb04005f     	cmp	x2, x4
    b1e4: 5400154a     	b.ge	0xb48c <_coil.compiler.resolve.primitive-providers-in+0x5b4>
    b1e8: 910043f0     	add	x16, sp, #0x10
    b1ec: f9400204     	ldr	x4, [x16]
    b1f0: 8b021484     	add	x4, x4, x2, lsl #5
    b1f4: f9400085     	ldr	x5, [x4]
    b1f8: f9400486     	ldr	x6, [x4, #0x8]
    b1fc: f9400887     	ldr	x7, [x4, #0x10]
    b200: f9400c84     	ldr	x4, [x4, #0x18]
    b204: f8786ac8     	ldr	x8, [x22, x24]
    b208: f9400729     	ldr	x9, [x25, #0x8]
    b20c: eb0900df     	cmp	x6, x9
    b210: 540014e1     	b.ne	0xb4ac <_coil.compiler.resolve.primitive-providers-in+0x5d4>
    b214: f10000df     	cmp	x6, #0x0
    b218: 54000301     	b.ne	0xb278 <_coil.compiler.resolve.primitive-providers-in+0x3a0>
    b21c: f90053fa     	str	x26, [sp, #0xa0]
    b220: f9005bfb     	str	x27, [sp, #0xb0]
    b224: aa0303fb     	mov	x27, x3
    b228: f9005ffc     	str	x28, [sp, #0xb8]
    b22c: f9004ff3     	str	x19, [sp, #0x98]
    b230: aa0003f3     	mov	x19, x0
    b234: aa0103fa     	mov	x26, x1
    b238: f90057e2     	str	x2, [sp, #0xa8]
    b23c: aa0703fc     	mov	x28, x7
    b240: aa0403f4     	mov	x20, x4
    b244: eb1a029f     	cmp	x20, x26
    b248: 54fffb61     	b.ne	0xb1b4 <_coil.compiler.resolve.primitive-providers-in+0x2dc>
    b24c: f100029f     	cmp	x20, #0x0
    b250: 54fffb00     	b.eq	0xb1b0 <_coil.compiler.resolve.primitive-providers-in+0x2d8>
    b254: d340fe80     	lsr	x0, x20, #0
    b258: aa1303e1     	mov	x1, x19
    b25c: aa0003e2     	mov	x2, x0
    b260: aa1c03e0     	mov	x0, x28
    b264: 94000000     	bl	0xb264 <_coil.compiler.resolve.primitive-providers-in+0x38c>
		000000000000b264:  ARM64_RELOC_BRANCH26	_memcmp
    b268: 93407c00     	sxtw	x0, w0
    b26c: f100001f     	cmp	x0, #0x0
    b270: 54fffa00     	b.eq	0xb1b0 <_coil.compiler.resolve.primitive-providers-in+0x2d8>
    b274: 17ffffd0     	b	0xb1b4 <_coil.compiler.resolve.primitive-providers-in+0x2dc>
    b278: d340fcc6     	lsr	x6, x6, #0
    b27c: f90057e2     	str	x2, [sp, #0xa8]
    b280: aa0603e2     	mov	x2, x6
    b284: aa0403f4     	mov	x20, x4
    b288: f9004ff3     	str	x19, [sp, #0x98]
    b28c: aa0003f3     	mov	x19, x0
    b290: aa0503e0     	mov	x0, x5
    b294: f90053fa     	str	x26, [sp, #0xa0]
    b298: aa0103fa     	mov	x26, x1
    b29c: aa0803e1     	mov	x1, x8
    b2a0: f9005bfb     	str	x27, [sp, #0xb0]
    b2a4: aa0303fb     	mov	x27, x3
    b2a8: f9005ffc     	str	x28, [sp, #0xb8]
    b2ac: aa0703fc     	mov	x28, x7
    b2b0: 94000000     	bl	0xb2b0 <_coil.compiler.resolve.primitive-providers-in+0x3d8>
		000000000000b2b0:  ARM64_RELOC_BRANCH26	_memcmp
    b2b4: 93407c00     	sxtw	x0, w0
    b2b8: f100001f     	cmp	x0, #0x0
    b2bc: 54fffc40     	b.eq	0xb244 <_coil.compiler.resolve.primitive-providers-in+0x36c>
    b2c0: 17ffffbd     	b	0xb1b4 <_coil.compiler.resolve.primitive-providers-in+0x2dc>
    b2c4: f100037f     	cmp	x27, #0x0
    b2c8: 54ffef01     	b.ne	0xb0a8 <_coil.compiler.resolve.primitive-providers-in+0x1d0>
    b2cc: aa1f0094     	orr	x20, x4, xzr
    b2d0: f8786adb     	ldr	x27, [x22, x24]
    b2d4: f940073c     	ldr	x28, [x25, #0x8]
    b2d8: 910043f0     	add	x16, sp, #0x10
    b2dc: f9400a00     	ldr	x0, [x16, #0x10]
    b2e0: eb00029f     	cmp	x20, x0
    b2e4: 54ffe80b     	b.lt	0xafe4 <_coil.compiler.resolve.primitive-providers-in+0x10c>
    b2e8: f100001f     	cmp	x0, #0x0
    b2ec: 54ffe741     	b.ne	0xafd4 <_coil.compiler.resolve.primitive-providers-in+0xfc>
    b2f0: d2800040     	mov	x0, #0x2                ; =2
    b2f4: 17ffff39     	b	0xafd8 <_coil.compiler.resolve.primitive-providers-in+0x100>
    b2f8: f94033f6     	ldr	x22, [sp, #0x60]
    b2fc: f9403bf9     	ldr	x25, [sp, #0x70]
    b300: f94053fa     	ldr	x26, [sp, #0xa0]
    b304: f9405bfb     	ldr	x27, [sp, #0xb0]
    b308: f9404ff3     	ldr	x19, [sp, #0x98]
    b30c: f94037f8     	ldr	x24, [sp, #0x68]
    b310: f9405ffc     	ldr	x28, [sp, #0xb8]
    b314: f9400aa0     	ldr	x0, [x21, #0x10]
    b318: 9100079c     	add	x28, x28, #0x1
    b31c: eb00039f     	cmp	x28, x0
    b320: 54000d8a     	b.ge	0xb4d0 <_coil.compiler.resolve.primitive-providers-in+0x5f8>
    b324: f100039f     	cmp	x28, #0x0
    b328: 54000dab     	b.lt	0xb4dc <_coil.compiler.resolve.primitive-providers-in+0x604>
    b32c: eb00039f     	cmp	x28, x0
    b330: 54000daa     	b.ge	0xb4e4 <_coil.compiler.resolve.primitive-providers-in+0x60c>
    b334: f100801f     	cmp	x0, #0x20
    b338: 54ffe3aa     	b.ge	0xafac <_coil.compiler.resolve.primitive-providers-in+0xd4>
    b33c: d2e00000     	movz	x0, #0x0, lsl #48
    b340: 17ffff1e     	b	0xafb8 <_coil.compiler.resolve.primitive-providers-in+0xe0>
    b344: d503201f     	nop
    b348: 910006f7     	add	x23, x23, #0x1
    b34c: f94033f6     	ldr	x22, [sp, #0x60]
    b350: f9404ff3     	ldr	x19, [sp, #0x98]
    b354: 910043f0     	add	x16, sp, #0x10
    b358: f9400600     	ldr	x0, [x16, #0x8]
    b35c: eb0002ff     	cmp	x23, x0
    b360: 5400032a     	b.ge	0xb3c4 <_coil.compiler.resolve.primitive-providers-in+0x4ec>
    b364: 910043f0     	add	x16, sp, #0x10
    b368: f9400200     	ldr	x0, [x16]
    b36c: 8b171400     	add	x0, x0, x23, lsl #5
    b370: f9400018     	ldr	x24, [x0]
    b374: f9400419     	ldr	x25, [x0, #0x8]
    b378: f940081a     	ldr	x26, [x0, #0x10]
    b37c: f9400c1b     	ldr	x27, [x0, #0x18]
    b380: aa1603e0     	mov	x0, x22
    b384: aa1803e1     	mov	x1, x24
    b388: aa1903e2     	mov	x2, x25
    b38c: aa1a03e3     	mov	x3, x26
    b390: aa1b03e4     	mov	x4, x27
    b394: 94000000     	bl	0xb394 <_coil.compiler.resolve.primitive-providers-in+0x4bc>
		000000000000b394:  ARM64_RELOC_BRANCH26	_coil.compiler.resolve.exports-check
    b398: f100001f     	cmp	x0, #0x0
    b39c: 54000a80     	b.eq	0xb4ec <_coil.compiler.resolve.primitive-providers-in+0x614>
    b3a0: 92e0001c     	movn	x28, #0x0, lsl #48
    b3a4: 17ffffdc     	b	0xb314 <_coil.compiler.resolve.primitive-providers-in+0x43c>
    b3a8: f9400aa0     	ldr	x0, [x21, #0x10]
    b3ac: aa0003e1     	mov	x1, x0
    b3b0: f9405fe0     	ldr	x0, [sp, #0xb8]
    b3b4: 94000000     	bl	0xb3b4 <_coil.compiler.resolve.primitive-providers-in+0x4dc>
		000000000000b3b4:  ARM64_RELOC_BRANCH26	_coil.avec.avec--bounds-error
    b3b8: 14000000     	b	0xb3b8 <_coil.compiler.resolve.primitive-providers-in+0x4e0>
    b3bc: d4200000     	brk	#0
    b3c0: 17ffffff     	b	0xb3bc <_coil.compiler.resolve.primitive-providers-in+0x4e4>
    b3c4: 910043f0     	add	x16, sp, #0x10
    b3c8: f9400201     	ldr	x1, [x16]
    b3cc: 910043f0     	add	x16, sp, #0x10
    b3d0: f9400a02     	ldr	x2, [x16, #0x10]
    b3d4: 910043f0     	add	x16, sp, #0x10
    b3d8: f9400e03     	ldr	x3, [x16, #0x18]
    b3dc: 910043f0     	add	x16, sp, #0x10
    b3e0: f9401204     	ldr	x4, [x16, #0x20]
    b3e4: f94063e5     	ldr	x5, [sp, #0xc0]
    b3e8: f90000a1     	str	x1, [x5]
    b3ec: f90004a0     	str	x0, [x5, #0x8]
    b3f0: f90008a2     	str	x2, [x5, #0x10]
    b3f4: f9000ca3     	str	x3, [x5, #0x18]
    b3f8: f90010a4     	str	x4, [x5, #0x20]
    b3fc: f94067f3     	ldr	x19, [sp, #0xc8]
    b400: f9406bf4     	ldr	x20, [sp, #0xd0]
    b404: f9406ff5     	ldr	x21, [sp, #0xd8]
    b408: f94073f6     	ldr	x22, [sp, #0xe0]
    b40c: f94077f7     	ldr	x23, [sp, #0xe8]
    b410: f9407bf8     	ldr	x24, [sp, #0xf0]
    b414: f9407ff9     	ldr	x25, [sp, #0xf8]
    b418: f94083fa     	ldr	x26, [sp, #0x100]
    b41c: f94087fb     	ldr	x27, [sp, #0x108]
    b420: f9408bfc     	ldr	x28, [sp, #0x110]
    b424: f94003fd     	ldr	x29, [sp]
    b428: f94007fe     	ldr	x30, [sp, #0x8]
    b42c: 910483ff     	add	sp, sp, #0x120
    b430: d65f03c0     	ret
    b434: f90033f6     	str	x22, [sp, #0x60]
    b438: f9003bf9     	str	x25, [sp, #0x70]
    b43c: f90053fa     	str	x26, [sp, #0xa0]
    b440: f9005bfb     	str	x27, [sp, #0xb0]
    b444: f9005ffc     	str	x28, [sp, #0xb8]
    b448: f9004ff3     	str	x19, [sp, #0x98]
    b44c: f90037f8     	str	x24, [sp, #0x68]
    b450: 17ffffaa     	b	0xb2f8 <_coil.compiler.resolve.primitive-providers-in+0x420>
    b454: f90033f6     	str	x22, [sp, #0x60]
    b458: f9003bf9     	str	x25, [sp, #0x70]
    b45c: f90053fa     	str	x26, [sp, #0xa0]
    b460: f9005bfb     	str	x27, [sp, #0xb0]
    b464: f9005ffc     	str	x28, [sp, #0xb8]
    b468: f9003fe3     	str	x3, [sp, #0x78]
    b46c: f90043e4     	str	x4, [sp, #0x80]
    b470: f90047e5     	str	x5, [sp, #0x88]
    b474: f9004ff3     	str	x19, [sp, #0x98]
    b478: f90037f8     	str	x24, [sp, #0x68]
    b47c: aa0003f8     	mov	x24, x0
    b480: aa0103f6     	mov	x22, x1
    b484: aa0203f9     	mov	x25, x2
    b488: 17ffff08     	b	0xb0a8 <_coil.compiler.resolve.primitive-providers-in+0x1d0>
    b48c: f90053fa     	str	x26, [sp, #0xa0]
    b490: f9005bfb     	str	x27, [sp, #0xb0]
    b494: aa0303fb     	mov	x27, x3
    b498: f9005ffc     	str	x28, [sp, #0xb8]
    b49c: f9004ff3     	str	x19, [sp, #0x98]
    b4a0: aa0003f3     	mov	x19, x0
    b4a4: aa0103fa     	mov	x26, x1
    b4a8: 17ffff87     	b	0xb2c4 <_coil.compiler.resolve.primitive-providers-in+0x3ec>
    b4ac: f90053fa     	str	x26, [sp, #0xa0]
    b4b0: f9005bfb     	str	x27, [sp, #0xb0]
    b4b4: aa0303fb     	mov	x27, x3
    b4b8: f9005ffc     	str	x28, [sp, #0xb8]
    b4bc: f9004ff3     	str	x19, [sp, #0x98]
    b4c0: aa0003f3     	mov	x19, x0
    b4c4: aa0103fa     	mov	x26, x1
    b4c8: f90057e2     	str	x2, [sp, #0xa8]
    b4cc: 17ffff3a     	b	0xb1b4 <_coil.compiler.resolve.primitive-providers-in+0x2dc>
    b4d0: f90033f6     	str	x22, [sp, #0x60]
    b4d4: f9004ff3     	str	x19, [sp, #0x98]
    b4d8: 17ffff9c     	b	0xb348 <_coil.compiler.resolve.primitive-providers-in+0x470>
    b4dc: f9005ffc     	str	x28, [sp, #0xb8]
    b4e0: 17ffffb2     	b	0xb3a8 <_coil.compiler.resolve.primitive-providers-in+0x4d0>
    b4e4: f9005ffc     	str	x28, [sp, #0xb8]
    b4e8: 17ffffb0     	b	0xb3a8 <_coil.compiler.resolve.primitive-providers-in+0x4d0>
    b4ec: f90033f6     	str	x22, [sp, #0x60]
    b4f0: f9004ff3     	str	x19, [sp, #0x98]
    b4f4: 17ffff95     	b	0xb348 <_coil.compiler.resolve.primitive-providers-in+0x470>
