
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-memory-area-alias/build/area-comparison/prepare-graph/before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_prepare_graph>:
       0:      	sub	sp, sp, #0x2e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x2c0]
      14:      	str	x20, [sp, #0x2c8]
      18:      	str	x21, [sp, #0x2d0]
      1c:      	str	x22, [sp, #0x2d8]
      20:      	add	x16, sp, #0x10
      24:      	orr	x3, x16, xzr
      28:      	add	x16, sp, #0x20
      2c:      	orr	x4, x16, xzr
      30:      	add	x16, sp, #0x10
      34:      	str	w2, [x16]
      38:      	add	x16, sp, #0x20
      3c:      	adrp	x17, 0x0 <_gap_prepare_graph>
		000000000000003c:  ARM64_RELOC_PAGE21	l_stogir.388
      40:      	ldr	x17, [x17]
		0000000000000040:  ARM64_RELOC_PAGEOFF12	l_stogir.388
      44:      	str	x17, [x16]
      48:      	add	x16, sp, #0x20
      4c:      	adrp	x17, 0x0 <_gap_prepare_graph>
		000000000000004c:  ARM64_RELOC_PAGE21	l_stogir.389
      50:      	ldr	x17, [x17]
		0000000000000050:  ARM64_RELOC_PAGEOFF12	l_stogir.389
      54:      	str	x17, [x16, #0x8]
      58:      	add	x8, sp, #0x30
      5c:      	mov	x2, x3
      60:      	mov	x3, #0x1                ; =1
      64:      	bl	0x64 <_gap_prepare_graph+0x64>
		0000000000000064:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare
      68:      	add	x16, sp, #0x30
      6c:      	ldr	w0, [x16]
      70:      	lsr	x16, x0, #0
      74:      	cmp	x16, #0x1
      78:      	b.eq	0x94 <_gap_prepare_graph+0x94>
      7c:      	b.lo	0x84 <_gap_prepare_graph+0x84>
      80:      	b	0x98 <_gap_prepare_graph+0x98>
      84:      	cmp	x16, #0x0
      88:      	b.eq	0x90 <_gap_prepare_graph+0x90>
      8c:      	b	0x98 <_gap_prepare_graph+0x98>
      90:      	b	0xa4 <_gap_prepare_graph+0xa4>
      94:      	b	0x9c <_gap_prepare_graph+0x9c>
      98:      	b	0x540 <_gap_prepare_graph+0x540>
      9c:      	movz	x20, #0x0, lsl #48
      a0:      	b	0x514 <_gap_prepare_graph+0x514>
      a4:      	add	x16, sp, #0x30
      a8:      	orr	x0, x16, xzr
      ac:      	add	x16, sp, #0x180
      b0:      	orr	x19, x16, xzr
      b4:      	add	x0, x0, #0x8
      b8:      	add	x20, x19, #0xa0
      bc:      	add	x21, x20, #0x28
      c0:      	mov	x1, x0
      c4:      	add	x0, sp, #0x180
      c8:      	mov	x2, #0x140              ; =320
      cc:      	bl	0xcc <_gap_prepare_graph+0xcc>
		00000000000000cc:  ARM64_RELOC_BRANCH26	_memmove
      d0:      	ldr	x0, [x20, #0x28]
      d4:      	ldr	x1, [x21, #0x8]
      d8:      	movz	x20, #0x0, lsl #48
      dc:      	movz	x2, #0x0, lsl #48
      e0:      	b	0x128 <_gap_prepare_graph+0x128>
      e4:      	nop
      e8:      	movz	w3, #0x0, lsl #16
      ec:      	movz	w4, #0x0, lsl #16
      f0:      	ubfx	x3, x3, #0, #32
      f4:      	lsr	x16, x3, #0
      f8:      	cmp	x16, #0x1
      fc:      	b.eq	0x118 <_gap_prepare_graph+0x118>
     100:      	b.lo	0x108 <_gap_prepare_graph+0x108>
     104:      	b	0x11c <_gap_prepare_graph+0x11c>
     108:      	cmp	x16, #0x0
     10c:      	b.eq	0x114 <_gap_prepare_graph+0x114>
     110:      	b	0x11c <_gap_prepare_graph+0x11c>
     114:      	b	0x150 <_gap_prepare_graph+0x150>
     118:      	b	0x120 <_gap_prepare_graph+0x120>
     11c:      	b	0x538 <_gap_prepare_graph+0x538>
     120:      	sxtw	x4, w4
     124:      	add	x20, x4, x20
     128:      	cmp	x2, x1
     12c:      	b.ge	0xe8 <_gap_prepare_graph+0xe8>
     130:      	add	x3, x2, #0x1
     134:      	add	x2, x0, x2, lsl #2
     138:      	ldr	w2, [x2]
     13c:      	movn	w17, #0x0, lsl #16
     140:      	and	w4, w2, w17
     144:      	mov	x2, x3
     148:      	mov	w3, #0x1                ; =1
     14c:      	b	0xf0 <_gap_prepare_graph+0xf0>
     150:      	b	0x164 <_gap_prepare_graph+0x164>
     154:      	nop
     158:      	sub	x0, x0, #0x1
     15c:      	add	x16, sp, #0x180
     160:      	str	x0, [x16, #0x8]
     164:      	add	x16, sp, #0x180
     168:      	ldr	x0, [x16, #0x8]
     16c:      	cmp	x0, #0x0
     170:      	b.ne	0x158 <_gap_prepare_graph+0x158>
     174:      	add	x16, sp, #0x180
     178:      	ldr	x0, [x16, #0x10]
     17c:      	cmp	x0, #0x0
     180:      	b.le	0x1b4 <_gap_prepare_graph+0x1b4>
     184:      	add	x1, x19, #0x18
     188:      	add	x16, sp, #0x180
     18c:      	ldr	x2, [x16]
     190:      	fmov	d31, x0
     194:      	mov	x0, x1
     198:      	mov	x1, x2
     19c:      	fmov	x2, d31
     1a0:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000001a0:  ARM64_RELOC_PAGE21	l_stogir.390
     1a4:      	ldr	x3, [x3]
		00000000000001a4:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     1a8:      	mov	x4, #0x4                ; =4
     1ac:      	mov	x5, #0x4                ; =4
     1b0:      	bl	0x1b0 <_gap_prepare_graph+0x1b0>
		00000000000001b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     1b4:      	add	x21, x19, #0x28
     1b8:      	add	x16, sp, #0x180
     1bc:      	movz	x17, #0x0, lsl #48
     1c0:      	str	x17, [x16]
     1c4:      	add	x16, sp, #0x180
     1c8:      	movz	x17, #0x0, lsl #48
     1cc:      	str	x17, [x16, #0x8]
     1d0:      	add	x16, sp, #0x180
     1d4:      	movz	x17, #0x0, lsl #48
     1d8:      	str	x17, [x16, #0x10]
     1dc:      	b	0x1e8 <_gap_prepare_graph+0x1e8>
     1e0:      	sub	x0, x0, #0x1
     1e4:      	str	x0, [x21, #0x8]
     1e8:      	ldr	x0, [x21, #0x8]
     1ec:      	cmp	x0, #0x0
     1f0:      	b.ne	0x1e0 <_gap_prepare_graph+0x1e0>
     1f4:      	ldr	x0, [x21, #0x10]
     1f8:      	cmp	x0, #0x0
     1fc:      	b.le	0x230 <_gap_prepare_graph+0x230>
     200:      	add	x1, x21, #0x18
     204:      	add	x16, sp, #0x180
     208:      	ldr	x2, [x16, #0x28]
     20c:      	fmov	d31, x0
     210:      	mov	x0, x1
     214:      	mov	x1, x2
     218:      	fmov	x2, d31
     21c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000021c:  ARM64_RELOC_PAGE21	l_stogir.390
     220:      	ldr	x3, [x3]
		0000000000000220:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     224:      	mov	x4, #0x4                ; =4
     228:      	mov	x5, #0x4                ; =4
     22c:      	bl	0x22c <_gap_prepare_graph+0x22c>
		000000000000022c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     230:      	add	x22, x19, #0x50
     234:      	add	x16, sp, #0x180
     238:      	movz	x17, #0x0, lsl #48
     23c:      	str	x17, [x16, #0x28]
     240:      	movz	x17, #0x0, lsl #48
     244:      	str	x17, [x21, #0x8]
     248:      	movz	x17, #0x0, lsl #48
     24c:      	str	x17, [x21, #0x10]
     250:      	b	0x260 <_gap_prepare_graph+0x260>
     254:      	nop
     258:      	sub	x0, x0, #0x1
     25c:      	str	x0, [x22, #0x8]
     260:      	ldr	x0, [x22, #0x8]
     264:      	cmp	x0, #0x0
     268:      	b.ne	0x258 <_gap_prepare_graph+0x258>
     26c:      	ldr	x0, [x22, #0x10]
     270:      	cmp	x0, #0x0
     274:      	b.le	0x2a8 <_gap_prepare_graph+0x2a8>
     278:      	add	x1, x22, #0x18
     27c:      	add	x16, sp, #0x180
     280:      	ldr	x2, [x16, #0x50]
     284:      	fmov	d31, x0
     288:      	mov	x0, x1
     28c:      	mov	x1, x2
     290:      	fmov	x2, d31
     294:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000294:  ARM64_RELOC_PAGE21	l_stogir.391
     298:      	ldr	x3, [x3]
		0000000000000298:  ARM64_RELOC_PAGEOFF12	l_stogir.391
     29c:      	mov	x4, #0x10               ; =16
     2a0:      	mov	x5, #0x4                ; =4
     2a4:      	bl	0x2a4 <_gap_prepare_graph+0x2a4>
		00000000000002a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     2a8:      	add	x21, x19, #0x78
     2ac:      	add	x16, sp, #0x180
     2b0:      	movz	x17, #0x0, lsl #48
     2b4:      	str	x17, [x16, #0x50]
     2b8:      	movz	x17, #0x0, lsl #48
     2bc:      	str	x17, [x22, #0x8]
     2c0:      	movz	x17, #0x0, lsl #48
     2c4:      	str	x17, [x22, #0x10]
     2c8:      	b	0x2d8 <_gap_prepare_graph+0x2d8>
     2cc:      	nop
     2d0:      	sub	x0, x0, #0x1
     2d4:      	str	x0, [x21, #0x8]
     2d8:      	ldr	x0, [x21, #0x8]
     2dc:      	cmp	x0, #0x0
     2e0:      	b.ne	0x2d0 <_gap_prepare_graph+0x2d0>
     2e4:      	ldr	x0, [x21, #0x10]
     2e8:      	cmp	x0, #0x0
     2ec:      	b.le	0x320 <_gap_prepare_graph+0x320>
     2f0:      	add	x1, x21, #0x18
     2f4:      	add	x16, sp, #0x180
     2f8:      	ldr	x2, [x16, #0x78]
     2fc:      	fmov	d31, x0
     300:      	mov	x0, x1
     304:      	mov	x1, x2
     308:      	fmov	x2, d31
     30c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000030c:  ARM64_RELOC_PAGE21	l_stogir.390
     310:      	ldr	x3, [x3]
		0000000000000310:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     314:      	mov	x4, #0x4                ; =4
     318:      	mov	x5, #0x4                ; =4
     31c:      	bl	0x31c <_gap_prepare_graph+0x31c>
		000000000000031c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     320:      	add	x22, x19, #0xf0
     324:      	add	x16, sp, #0x180
     328:      	movz	x17, #0x0, lsl #48
     32c:      	str	x17, [x16, #0x78]
     330:      	movz	x17, #0x0, lsl #48
     334:      	str	x17, [x21, #0x8]
     338:      	movz	x17, #0x0, lsl #48
     33c:      	str	x17, [x21, #0x10]
     340:      	b	0x350 <_gap_prepare_graph+0x350>
     344:      	nop
     348:      	sub	x0, x0, #0x1
     34c:      	str	x0, [x22, #0x8]
     350:      	ldr	x0, [x22, #0x8]
     354:      	cmp	x0, #0x0
     358:      	b.ne	0x348 <_gap_prepare_graph+0x348>
     35c:      	ldr	x0, [x22, #0x10]
     360:      	cmp	x0, #0x0
     364:      	b.le	0x398 <_gap_prepare_graph+0x398>
     368:      	add	x1, x22, #0x18
     36c:      	add	x16, sp, #0x180
     370:      	ldr	x2, [x16, #0xf0]
     374:      	fmov	d31, x0
     378:      	mov	x0, x1
     37c:      	mov	x1, x2
     380:      	fmov	x2, d31
     384:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000384:  ARM64_RELOC_PAGE21	l_stogir.390
     388:      	ldr	x3, [x3]
		0000000000000388:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     38c:      	mov	x4, #0x4                ; =4
     390:      	mov	x5, #0x4                ; =4
     394:      	bl	0x394 <_gap_prepare_graph+0x394>
		0000000000000394:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     398:      	add	x21, x19, #0x118
     39c:      	add	x16, sp, #0x180
     3a0:      	movz	x17, #0x0, lsl #48
     3a4:      	str	x17, [x16, #0xf0]
     3a8:      	movz	x17, #0x0, lsl #48
     3ac:      	str	x17, [x22, #0x8]
     3b0:      	movz	x17, #0x0, lsl #48
     3b4:      	str	x17, [x22, #0x10]
     3b8:      	b	0x3c8 <_gap_prepare_graph+0x3c8>
     3bc:      	nop
     3c0:      	sub	x0, x0, #0x1
     3c4:      	str	x0, [x21, #0x8]
     3c8:      	ldr	x0, [x21, #0x8]
     3cc:      	cmp	x0, #0x0
     3d0:      	b.ne	0x3c0 <_gap_prepare_graph+0x3c0>
     3d4:      	ldr	x0, [x21, #0x10]
     3d8:      	cmp	x0, #0x0
     3dc:      	b.le	0x410 <_gap_prepare_graph+0x410>
     3e0:      	add	x1, x21, #0x18
     3e4:      	add	x16, sp, #0x180
     3e8:      	ldr	x2, [x16, #0x118]
     3ec:      	fmov	d31, x0
     3f0:      	mov	x0, x1
     3f4:      	mov	x1, x2
     3f8:      	fmov	x2, d31
     3fc:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000003fc:  ARM64_RELOC_PAGE21	l_stogir.390
     400:      	ldr	x3, [x3]
		0000000000000400:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     404:      	mov	x4, #0x4                ; =4
     408:      	mov	x5, #0x4                ; =4
     40c:      	bl	0x40c <_gap_prepare_graph+0x40c>
		000000000000040c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     410:      	add	x19, x19, #0xa0
     414:      	add	x16, sp, #0x180
     418:      	movz	x17, #0x0, lsl #48
     41c:      	str	x17, [x16, #0x118]
     420:      	movz	x17, #0x0, lsl #48
     424:      	str	x17, [x21, #0x8]
     428:      	movz	x17, #0x0, lsl #48
     42c:      	str	x17, [x21, #0x10]
     430:      	b	0x440 <_gap_prepare_graph+0x440>
     434:      	nop
     438:      	sub	x0, x0, #0x1
     43c:      	str	x0, [x19, #0x8]
     440:      	ldr	x0, [x19, #0x8]
     444:      	cmp	x0, #0x0
     448:      	b.ne	0x438 <_gap_prepare_graph+0x438>
     44c:      	ldr	x0, [x19, #0x10]
     450:      	cmp	x0, #0x0
     454:      	b.le	0x488 <_gap_prepare_graph+0x488>
     458:      	add	x1, x19, #0x18
     45c:      	add	x16, sp, #0x180
     460:      	ldr	x2, [x16, #0xa0]
     464:      	fmov	d31, x0
     468:      	mov	x0, x1
     46c:      	mov	x1, x2
     470:      	fmov	x2, d31
     474:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000474:  ARM64_RELOC_PAGE21	l_stogir.392
     478:      	ldr	x3, [x3]
		0000000000000478:  ARM64_RELOC_PAGEOFF12	l_stogir.392
     47c:      	mov	x4, #0x10               ; =16
     480:      	mov	x5, #0x8                ; =8
     484:      	bl	0x484 <_gap_prepare_graph+0x484>
		0000000000000484:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     488:      	add	x21, x19, #0x28
     48c:      	add	x16, sp, #0x180
     490:      	movz	x17, #0x0, lsl #48
     494:      	str	x17, [x16, #0xa0]
     498:      	movz	x17, #0x0, lsl #48
     49c:      	str	x17, [x19, #0x8]
     4a0:      	movz	x17, #0x0, lsl #48
     4a4:      	str	x17, [x19, #0x10]
     4a8:      	b	0x4b8 <_gap_prepare_graph+0x4b8>
     4ac:      	nop
     4b0:      	sub	x0, x0, #0x1
     4b4:      	str	x0, [x21, #0x8]
     4b8:      	ldr	x0, [x21, #0x8]
     4bc:      	cmp	x0, #0x0
     4c0:      	b.ne	0x4b0 <_gap_prepare_graph+0x4b0>
     4c4:      	ldr	x0, [x21, #0x10]
     4c8:      	cmp	x0, #0x0
     4cc:      	b.le	0x4fc <_gap_prepare_graph+0x4fc>
     4d0:      	add	x1, x21, #0x18
     4d4:      	ldr	x2, [x19, #0x28]
     4d8:      	fmov	d31, x0
     4dc:      	mov	x0, x1
     4e0:      	mov	x1, x2
     4e4:      	fmov	x2, d31
     4e8:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000004e8:  ARM64_RELOC_PAGE21	l_stogir.390
     4ec:      	ldr	x3, [x3]
		00000000000004ec:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     4f0:      	mov	x4, #0x4                ; =4
     4f4:      	mov	x5, #0x4                ; =4
     4f8:      	bl	0x4f8 <_gap_prepare_graph+0x4f8>
		00000000000004f8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     4fc:      	movz	x17, #0x0, lsl #48
     500:      	str	x17, [x19, #0x28]
     504:      	movz	x17, #0x0, lsl #48
     508:      	str	x17, [x21, #0x8]
     50c:      	movz	x17, #0x0, lsl #48
     510:      	str	x17, [x21, #0x10]
     514:      	mov	x0, x20
     518:      	ldr	x19, [sp, #0x2c0]
     51c:      	ldr	x20, [sp, #0x2c8]
     520:      	ldr	x21, [sp, #0x2d0]
     524:      	ldr	x22, [sp, #0x2d8]
     528:      	ldr	x29, [sp]
     52c:      	ldr	x30, [sp, #0x8]
     530:      	add	sp, sp, #0x2e0
     534:      	ret
     538:      	brk	#0
     53c:      	b	0x538 <_gap_prepare_graph+0x538>
     540:      	brk	#0
     544:      	b	0x540 <_gap_prepare_graph+0x540>

0000000000000548 <_stogir.pipeline.prepare>:
     548:      	sub	sp, sp, #0x310
     54c:      	str	x29, [sp]
     550:      	str	x30, [sp, #0x8]
     554:      	mov	x29, sp
     558:      	str	x19, [sp, #0x2d0]
     55c:      	str	x20, [sp, #0x2d8]
     560:      	str	x21, [sp, #0x2e0]
     564:      	str	x22, [sp, #0x2e8]
     568:      	str	x23, [sp, #0x2f0]
     56c:      	str	x24, [sp, #0x2f8]
     570:      	str	x25, [sp, #0x300]
     574:      	mov	x19, x8
     578:      	add	x8, sp, #0x10
     57c:      	mov	x20, x0
     580:      	mov	w21, w1
     584:      	mov	x22, x2
     588:      	mov	x23, x3
     58c:      	mov	x24, x4
     590:      	bl	0x590 <_stogir.pipeline.prepare+0x48>
		0000000000000590:  ARM64_RELOC_BRANCH26	_stogir.pipeline.validate-input
     594:      	add	x16, sp, #0x10
     598:      	ldr	w0, [x16]
     59c:      	lsr	x16, x0, #0
     5a0:      	cmp	x16, #0x1
     5a4:      	b.eq	0x5c0 <_stogir.pipeline.prepare+0x78>
     5a8:      	b.lo	0x5b0 <_stogir.pipeline.prepare+0x68>
     5ac:      	b	0x5c4 <_stogir.pipeline.prepare+0x7c>
     5b0:      	cmp	x16, #0x0
     5b4:      	b.eq	0x5bc <_stogir.pipeline.prepare+0x74>
     5b8:      	b	0x5c4 <_stogir.pipeline.prepare+0x7c>
     5bc:      	b	0x608 <_stogir.pipeline.prepare+0xc0>
     5c0:      	b	0x5c8 <_stogir.pipeline.prepare+0x80>
     5c4:      	b	0x668 <_stogir.pipeline.prepare+0x120>
     5c8:      	add	x16, sp, #0x10
     5cc:      	orr	x0, x16, xzr
     5d0:      	add	x16, sp, #0x30
     5d4:      	orr	x25, x16, xzr
     5d8:      	add	x0, x0, #0x8
     5dc:      	add	x1, x25, #0x8
     5e0:      	add	x16, sp, #0x10
     5e4:      	ldr	x2, [x16, #0x8]
     5e8:      	ldr	x0, [x0, #0x8]
     5ec:      	add	x16, sp, #0x30
     5f0:      	mov	w17, #0x1               ; =1
     5f4:      	str	w17, [x16]
     5f8:      	add	x16, sp, #0x30
     5fc:      	str	x2, [x16, #0x8]
     600:      	str	x0, [x1, #0x8]
     604:      	b	0x62c <_stogir.pipeline.prepare+0xe4>
     608:      	add	x16, sp, #0x180
     60c:      	orr	x25, x16, xzr
     610:      	add	x8, sp, #0x180
     614:      	mov	x0, x20
     618:      	mov	w1, w21
     61c:      	mov	x2, x22
     620:      	mov	x3, x23
     624:      	mov	x4, x24
     628:      	bl	0x628 <_stogir.pipeline.prepare+0xe0>
		0000000000000628:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare-checked
     62c:      	mov	x0, x19
     630:      	mov	x1, x25
     634:      	mov	x2, #0x148              ; =328
     638:      	bl	0x638 <_stogir.pipeline.prepare+0xf0>
		0000000000000638:  ARM64_RELOC_BRANCH26	_memmove
     63c:      	ldr	x19, [sp, #0x2d0]
     640:      	ldr	x20, [sp, #0x2d8]
     644:      	ldr	x21, [sp, #0x2e0]
     648:      	ldr	x22, [sp, #0x2e8]
     64c:      	ldr	x23, [sp, #0x2f0]
     650:      	ldr	x24, [sp, #0x2f8]
     654:      	ldr	x25, [sp, #0x300]
     658:      	ldr	x29, [sp]
     65c:      	ldr	x30, [sp, #0x8]
     660:      	add	sp, sp, #0x310
     664:      	ret
     668:      	brk	#0
     66c:      	b	0x668 <_stogir.pipeline.prepare+0x120>

0000000000000670 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32>:
     670:      	ldr	x1, [x0]
     674:      	ldr	x0, [x0, #0x8]
     678:      	str	x1, [x8]
     67c:      	str	x0, [x8, #0x8]
     680:      	movz	x17, #0x0, lsl #48
     684:      	str	x17, [x8, #0x10]
     688:      	ret

000000000000068c <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
     68c:      	sub	sp, sp, #0x10
     690:      	mov	x1, sp
     694:      	ldr	x2, [x0, #0x10]
     698:      	ldr	x3, [x0]
     69c:      	ldr	x4, [x0, #0x8]
     6a0:      	cmp	x2, x4
     6a4:      	b.ge	0x6c8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x3c>
     6a8:      	add	x4, x2, #0x1
     6ac:      	add	x2, x3, x2, lsl #2
     6b0:      	str	x4, [x0, #0x10]
     6b4:      	ldr	w0, [x2]
     6b8:      	sxtw	x0, w0
     6bc:      	and	x0, x0, #0xffffffff
     6c0:      	mov	x2, #0x1                ; =1
     6c4:      	b	0x6d0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
     6c8:      	movz	x2, #0x0, lsl #48
     6cc:      	movz	x0, #0x0, lsl #48
     6d0:      	str	x2, [x1]
     6d4:      	str	x0, [x1, #0x8]
     6d8:      	ldr	x0, [sp]
     6dc:      	ldr	x1, [sp, #0x8]
     6e0:      	add	sp, sp, #0x10
     6e4:      	ret

00000000000006e8 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate>:
     6e8:      	sub	sp, sp, #0x40
     6ec:      	str	x29, [sp]
     6f0:      	str	x30, [sp, #0x8]
     6f4:      	mov	x29, sp
     6f8:      	str	x19, [sp, #0x20]
     6fc:      	str	x20, [sp, #0x28]
     700:      	str	x21, [sp, #0x30]
     704:      	add	x19, x29, #0x10
     708:      	mov	x20, sp
     70c:      	sub	sp, sp, #0x10
     710:      	mov	x21, sp
     714:      	ldr	x0, [x1, #0x18]
     718:      	ldr	x1, [x1, #0x10]
     71c:      	cmp	x0, #0x10
     720:      	b.gt	0x740 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x58>
     724:      	mov	x0, x1
     728:      	bl	0x728 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x40>
		0000000000000728:  ARM64_RELOC_BRANCH26	_malloc
     72c:      	cmp	x0, #0x0
     730:      	b.ne	0x770 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x88>
     734:      	movz	x1, #0x0, lsl #48
     738:      	movz	x0, #0x0, lsl #48
     73c:      	b	0x774 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x8c>
     740:      	movz	x17, #0x0, lsl #48
     744:      	str	x17, [x21]
     748:      	mov	x2, x1
     74c:      	mov	x1, x0
     750:      	mov	x0, x21
     754:      	bl	0x754 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x6c>
		0000000000000754:  ARM64_RELOC_BRANCH26	_posix_memalign
     758:      	sxtw	x0, w0
     75c:      	cmp	x0, #0x0
     760:      	b.ne	0x778 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x90>
     764:      	ldr	x0, [x21]
     768:      	mov	x1, #0x1                ; =1
     76c:      	b	0x780 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     770:      	mov	x1, #0x1                ; =1
     774:      	b	0x780 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     778:      	movz	x1, #0x0, lsl #48
     77c:      	movz	x0, #0x0, lsl #48
     780:      	mov	sp, x20
     784:      	str	x1, [x19]
     788:      	str	x0, [x19, #0x8]
     78c:      	ldr	x0, [x29, #0x10]
     790:      	ldr	x1, [x29, #0x18]
     794:      	sub	sp, x29, #0x0
     798:      	ldr	x19, [sp, #0x20]
     79c:      	ldr	x20, [sp, #0x28]
     7a0:      	ldr	x21, [sp, #0x30]
     7a4:      	ldr	x29, [sp]
     7a8:      	ldr	x30, [sp, #0x8]
     7ac:      	add	sp, sp, #0x40
     7b0:      	ret

00000000000007b4 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$resize>:
     7b4:      	ldr	x0, [x3, #0x10]
     7b8:      	ldr	x1, [x2, #0x10]
     7bc:      	cmp	x0, x1
     7c0:      	cset	w0, le
     7c4:      	ubfx	x0, x0, #0, #8
     7c8:      	ret

00000000000007cc <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap>:
     7cc:      	sub	sp, sp, #0x30
     7d0:      	str	x29, [sp]
     7d4:      	str	x30, [sp, #0x8]
     7d8:      	mov	x29, sp
     7dc:      	str	x19, [sp, #0x20]
     7e0:      	add	x19, sp, #0x10
     7e4:      	ldr	x0, [x3, #0x18]
     7e8:      	cmp	x0, #0x10
     7ec:      	b.le	0x824 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x58>
     7f0:      	movz	x1, #0x0, lsl #48
     7f4:      	movz	x0, #0x0, lsl #48
     7f8:      	b	0x800 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x34>
     7fc:      	mov	x1, #0x1                ; =1
     800:      	str	x1, [x19]
     804:      	str	x0, [x19, #0x8]
     808:      	ldr	x0, [sp, #0x10]
     80c:      	ldr	x1, [sp, #0x18]
     810:      	ldr	x19, [sp, #0x20]
     814:      	ldr	x29, [sp]
     818:      	ldr	x30, [sp, #0x8]
     81c:      	add	sp, sp, #0x30
     820:      	ret
     824:      	ldr	x0, [x3, #0x10]
     828:      	fmov	d31, x0
     82c:      	mov	x0, x1
     830:      	fmov	x1, d31
     834:      	bl	0x834 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x68>
		0000000000000834:  ARM64_RELOC_BRANCH26	_realloc
     838:      	cmp	x0, #0x0
     83c:      	b.ne	0x7fc <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x30>
     840:      	movz	x1, #0x0, lsl #48
     844:      	movz	x0, #0x0, lsl #48
     848:      	b	0x800 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x34>

000000000000084c <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate>:
     84c:      	sub	sp, sp, #0x10
     850:      	str	x29, [sp]
     854:      	str	x30, [sp, #0x8]
     858:      	mov	x29, sp
     85c:      	mov	x0, x1
     860:      	bl	0x860 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate+0x14>
		0000000000000860:  ARM64_RELOC_BRANCH26	_free
     864:      	movz	x0, #0x0, lsl #48
     868:      	ldr	x29, [sp]
     86c:      	ldr	x30, [sp, #0x8]
     870:      	add	sp, sp, #0x10
     874:      	ret

0000000000000878 <_stogir.pipeline.validate-input>:
     878:      	sub	sp, sp, #0x40
     87c:      	str	x29, [sp]
     880:      	str	x30, [sp, #0x8]
     884:      	mov	x29, sp
     888:      	str	x19, [sp, #0x30]
     88c:      	mov	x19, x8
     890:      	add	x8, sp, #0x10
     894:      	bl	0x894 <_stogir.pipeline.validate-input+0x1c>
		0000000000000894:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input
     898:      	add	x16, sp, #0x10
     89c:      	ldr	x0, [x16]
     8a0:      	str	x0, [x19]
     8a4:      	add	x16, sp, #0x10
     8a8:      	ldr	x0, [x16, #0x8]
     8ac:      	str	x0, [x19, #0x8]
     8b0:      	add	x16, sp, #0x10
     8b4:      	ldr	x0, [x16, #0x10]
     8b8:      	str	x0, [x19, #0x10]
     8bc:      	ldr	x19, [sp, #0x30]
     8c0:      	ldr	x29, [sp]
     8c4:      	ldr	x30, [sp, #0x8]
     8c8:      	add	sp, sp, #0x40
     8cc:      	ret

00000000000008d0 <_stogir.pipeline.prepare-checked>:
     8d0:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
     8d4:      	str	x29, [sp]
     8d8:      	str	x30, [sp, #0x8]
     8dc:      	mov	x29, sp
     8e0:      	str	x19, [sp, #0xfb0]
     8e4:      	str	x20, [sp, #0xfb8]
     8e8:      	str	x21, [sp, #0xfc0]
     8ec:      	str	x22, [sp, #0xfc8]
     8f0:      	str	x23, [sp, #0xfd0]
     8f4:      	str	x24, [sp, #0xfd8]
     8f8:      	str	x25, [sp, #0xfe0]
     8fc:      	str	x26, [sp, #0xfe8]
     900:      	str	x27, [sp, #0xff0]
     904:      	str	x28, [sp, #0xff8]
     908:      	sxtw	x5, w1
     90c:      	cmp	x5, #0x0
     910:      	b.gt	0x990 <_stogir.pipeline.prepare-checked+0xc0>
     914:      	str	x8, [sp, #0xe58]
     918:      	add	x16, sp, #0x10
     91c:      	orr	x19, x16, xzr
     920:      	add	x16, sp, #0x10
     924:      	mov	w17, #0x1               ; =1
     928:      	str	w17, [x16]
     92c:      	add	x0, x19, #0x8
     930:      	add	x16, sp, #0x10
     934:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000934:  ARM64_RELOC_PAGE21	l_stogir.393
     938:      	ldr	x17, [x17]
		0000000000000938:  ARM64_RELOC_PAGEOFF12	l_stogir.393
     93c:      	str	x17, [x16, #0x8]
     940:      	mov	x17, #0x17              ; =23
     944:      	str	x17, [x0, #0x8]
     948:      	ldr	x0, [sp, #0xe58]
     94c:      	mov	x1, x19
     950:      	mov	x2, #0x148              ; =328
     954:      	bl	0x954 <_stogir.pipeline.prepare-checked+0x84>
		0000000000000954:  ARM64_RELOC_BRANCH26	_memmove
     958:      	ldr	x19, [sp, #0xfb0]
     95c:      	ldr	x20, [sp, #0xfb8]
     960:      	ldr	x21, [sp, #0xfc0]
     964:      	ldr	x22, [sp, #0xfc8]
     968:      	ldr	x23, [sp, #0xfd0]
     96c:      	ldr	x24, [sp, #0xfd8]
     970:      	ldr	x25, [sp, #0xfe0]
     974:      	ldr	x26, [sp, #0xfe8]
     978:      	ldr	x27, [sp, #0xff0]
     97c:      	ldr	x28, [sp, #0xff8]
     980:      	ldr	x29, [sp]
     984:      	ldr	x30, [sp, #0x8]
     988:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     98c:      	ret
     990:      	mov	x19, x8
     994:      	mov	x20, x0
     998:      	mov	w21, w1
     99c:      	mov	x22, x2
     9a0:      	mov	x23, x3
     9a4:      	mov	x24, x4
     9a8:      	bl	0x9a8 <_stogir.pipeline.prepare-checked+0xd8>
		00000000000009a8:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
     9ac:      	cmp	x0, #0x0
     9b0:      	b.eq	0x1db4 <_stogir.pipeline.prepare-checked+0x14e4>
     9b4:      	add	x16, sp, #0x160
     9b8:      	orr	x25, x16, xzr
     9bc:      	add	x8, sp, #0x160
     9c0:      	mov	x0, x20
     9c4:      	mov	x1, x24
     9c8:      	bl	0x9c8 <_stogir.pipeline.prepare-checked+0xf8>
		00000000000009c8:  ARM64_RELOC_BRANCH26	_stogir.cfg.build
     9cc:      	add	x16, sp, #0x160
     9d0:      	ldr	w0, [x16]
     9d4:      	lsr	x16, x0, #0
     9d8:      	cmp	x16, #0x1
     9dc:      	b.eq	0x9f8 <_stogir.pipeline.prepare-checked+0x128>
     9e0:      	b.lo	0x9e8 <_stogir.pipeline.prepare-checked+0x118>
     9e4:      	b	0x9fc <_stogir.pipeline.prepare-checked+0x12c>
     9e8:      	cmp	x16, #0x0
     9ec:      	b.eq	0x9f4 <_stogir.pipeline.prepare-checked+0x124>
     9f0:      	b	0x9fc <_stogir.pipeline.prepare-checked+0x12c>
     9f4:      	b	0xa40 <_stogir.pipeline.prepare-checked+0x170>
     9f8:      	b	0xa00 <_stogir.pipeline.prepare-checked+0x130>
     9fc:      	b	0x1a84 <_stogir.pipeline.prepare-checked+0x11b4>
     a00:      	add	x16, sp, #0x1e0
     a04:      	orr	x20, x16, xzr
     a08:      	add	x0, x25, #0x8
     a0c:      	add	x1, x20, #0x8
     a10:      	add	x16, sp, #0x160
     a14:      	ldr	x2, [x16, #0x8]
     a18:      	ldr	x0, [x0, #0x8]
     a1c:      	add	x16, sp, #0x1e0
     a20:      	mov	w17, #0x1               ; =1
     a24:      	str	w17, [x16]
     a28:      	add	x16, sp, #0x1e0
     a2c:      	str	x2, [x16, #0x8]
     a30:      	str	x0, [x1, #0x8]
     a34:      	str	x19, [sp, #0xe58]
     a38:      	mov	x19, x20
     a3c:      	b	0x948 <_stogir.pipeline.prepare-checked+0x78>
     a40:      	add	x16, sp, #0x330
     a44:      	orr	x26, x16, xzr
     a48:      	add	x16, sp, #0x3b0
     a4c:      	orr	x27, x16, xzr
     a50:      	add	x16, sp, #0x450
     a54:      	orr	x28, x16, xzr
     a58:      	add	x16, sp, #0x4f0
     a5c:      	orr	x0, x16, xzr
     a60:      	add	x16, sp, #0x550
     a64:      	orr	x1, x16, xzr
     a68:      	add	x16, sp, #0x5b0
     a6c:      	orr	x2, x16, xzr
     a70:      	add	x16, sp, #0x610
     a74:      	orr	x3, x16, xzr
     a78:      	add	x16, sp, #0x670
     a7c:      	orr	x4, x16, xzr
     a80:      	add	x16, sp, #0x710
     a84:      	orr	x5, x16, xzr
     a88:      	add	x16, sp, #0x760
     a8c:      	orr	x6, x16, xzr
     a90:      	add	x7, x25, #0x8
     a94:      	add	x16, sp, #0x160
     a98:      	ldr	x8, [x16, #0x8]
     a9c:      	ldr	x9, [x7, #0x8]
     aa0:      	ldr	x10, [x7, #0x10]
     aa4:      	ldr	x11, [x7, #0x18]
     aa8:      	ldr	x12, [x7, #0x20]
     aac:      	ldr	x13, [x7, #0x28]
     ab0:      	ldr	x14, [x7, #0x30]
     ab4:      	ldr	x15, [x7, #0x38]
     ab8:      	ldr	x25, [x7, #0x40]
     abc:      	str	x0, [sp, #0xe30]
     ac0:      	ldr	x0, [x7, #0x48]
     ac4:      	str	x1, [sp, #0xe38]
     ac8:      	ldr	x1, [x7, #0x50]
     acc:      	str	x2, [sp, #0xe40]
     ad0:      	ldr	x2, [x7, #0x58]
     ad4:      	str	x3, [sp, #0xe48]
     ad8:      	ldr	x3, [x7, #0x60]
     adc:      	str	x4, [sp, #0xe50]
     ae0:      	ldr	x4, [x7, #0x68]
     ae4:      	ldr	x7, [x7, #0x70]
     ae8:      	add	x16, sp, #0x330
     aec:      	str	x8, [x16]
     af0:      	add	x16, sp, #0x330
     af4:      	str	x9, [x16, #0x8]
     af8:      	add	x16, sp, #0x330
     afc:      	str	x10, [x16, #0x10]
     b00:      	add	x16, sp, #0x330
     b04:      	str	x11, [x16, #0x18]
     b08:      	add	x16, sp, #0x330
     b0c:      	str	x12, [x16, #0x20]
     b10:      	add	x16, sp, #0x330
     b14:      	str	x13, [x16, #0x28]
     b18:      	add	x16, sp, #0x330
     b1c:      	str	x14, [x16, #0x30]
     b20:      	add	x16, sp, #0x330
     b24:      	str	x15, [x16, #0x38]
     b28:      	add	x16, sp, #0x330
     b2c:      	str	x25, [x16, #0x40]
     b30:      	add	x16, sp, #0x330
     b34:      	str	x0, [x16, #0x48]
     b38:      	add	x16, sp, #0x330
     b3c:      	str	x1, [x16, #0x50]
     b40:      	add	x16, sp, #0x330
     b44:      	str	x2, [x16, #0x58]
     b48:      	add	x16, sp, #0x330
     b4c:      	str	x3, [x16, #0x60]
     b50:      	add	x16, sp, #0x330
     b54:      	str	x4, [x16, #0x68]
     b58:      	add	x16, sp, #0x330
     b5c:      	str	x7, [x16, #0x70]
     b60:      	add	x8, sp, #0x400
     b64:      	mov	x0, x26
     b68:      	mov	x2, x24
     b6c:      	ldr	x25, [sp, #0xe30]
     b70:      	str	x19, [sp, #0xe58]
     b74:      	ldr	x19, [sp, #0xe38]
     b78:      	str	x20, [sp, #0xe60]
     b7c:      	ldr	x20, [sp, #0xe40]
     b80:      	str	x22, [sp, #0xe68]
     b84:      	ldr	x22, [sp, #0xe48]
     b88:      	str	x23, [sp, #0xe70]
     b8c:      	mov	x23, x5
     b90:      	str	x26, [sp, #0xe78]
     b94:      	mov	x26, x6
     b98:      	mov	x1, #0x1                ; =1
     b9c:      	uxtb	w1, w1
     ba0:      	bl	0xba0 <_stogir.pipeline.prepare-checked+0x2d0>
		0000000000000ba0:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     ba4:      	add	x16, sp, #0x400
     ba8:      	ldr	x0, [x16]
     bac:      	add	x16, sp, #0x3b0
     bb0:      	str	x0, [x16]
     bb4:      	add	x16, sp, #0x400
     bb8:      	ldr	x0, [x16, #0x8]
     bbc:      	add	x16, sp, #0x3b0
     bc0:      	str	x0, [x16, #0x8]
     bc4:      	add	x16, sp, #0x400
     bc8:      	ldr	x0, [x16, #0x10]
     bcc:      	add	x16, sp, #0x3b0
     bd0:      	str	x0, [x16, #0x10]
     bd4:      	add	x16, sp, #0x400
     bd8:      	ldr	x0, [x16, #0x18]
     bdc:      	add	x16, sp, #0x3b0
     be0:      	str	x0, [x16, #0x18]
     be4:      	add	x16, sp, #0x400
     be8:      	ldr	x0, [x16, #0x20]
     bec:      	add	x16, sp, #0x3b0
     bf0:      	str	x0, [x16, #0x20]
     bf4:      	add	x16, sp, #0x400
     bf8:      	ldr	x0, [x16, #0x28]
     bfc:      	add	x16, sp, #0x3b0
     c00:      	str	x0, [x16, #0x28]
     c04:      	add	x16, sp, #0x400
     c08:      	ldr	x0, [x16, #0x30]
     c0c:      	add	x16, sp, #0x3b0
     c10:      	str	x0, [x16, #0x30]
     c14:      	add	x16, sp, #0x400
     c18:      	ldr	x0, [x16, #0x38]
     c1c:      	add	x16, sp, #0x3b0
     c20:      	str	x0, [x16, #0x38]
     c24:      	add	x16, sp, #0x400
     c28:      	ldr	x0, [x16, #0x40]
     c2c:      	add	x16, sp, #0x3b0
     c30:      	str	x0, [x16, #0x40]
     c34:      	add	x16, sp, #0x400
     c38:      	ldr	x0, [x16, #0x48]
     c3c:      	add	x16, sp, #0x3b0
     c40:      	str	x0, [x16, #0x48]
     c44:      	add	x8, sp, #0x4a0
     c48:      	ldr	x0, [sp, #0xe78]
     c4c:      	mov	x2, x24
     c50:      	movz	x1, #0x0, lsl #48
     c54:      	uxtb	w1, w1
     c58:      	bl	0xc58 <_stogir.pipeline.prepare-checked+0x388>
		0000000000000c58:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     c5c:      	add	x16, sp, #0x4a0
     c60:      	ldr	x0, [x16]
     c64:      	add	x16, sp, #0x450
     c68:      	str	x0, [x16]
     c6c:      	add	x16, sp, #0x4a0
     c70:      	ldr	x0, [x16, #0x8]
     c74:      	add	x16, sp, #0x450
     c78:      	str	x0, [x16, #0x8]
     c7c:      	add	x16, sp, #0x4a0
     c80:      	ldr	x0, [x16, #0x10]
     c84:      	add	x16, sp, #0x450
     c88:      	str	x0, [x16, #0x10]
     c8c:      	add	x16, sp, #0x4a0
     c90:      	ldr	x0, [x16, #0x18]
     c94:      	add	x16, sp, #0x450
     c98:      	str	x0, [x16, #0x18]
     c9c:      	add	x16, sp, #0x4a0
     ca0:      	ldr	x0, [x16, #0x20]
     ca4:      	add	x16, sp, #0x450
     ca8:      	str	x0, [x16, #0x20]
     cac:      	add	x16, sp, #0x4a0
     cb0:      	ldr	x0, [x16, #0x28]
     cb4:      	add	x16, sp, #0x450
     cb8:      	str	x0, [x16, #0x28]
     cbc:      	add	x16, sp, #0x4a0
     cc0:      	ldr	x0, [x16, #0x30]
     cc4:      	add	x16, sp, #0x450
     cc8:      	str	x0, [x16, #0x30]
     ccc:      	add	x16, sp, #0x4a0
     cd0:      	ldr	x0, [x16, #0x38]
     cd4:      	add	x16, sp, #0x450
     cd8:      	str	x0, [x16, #0x38]
     cdc:      	add	x16, sp, #0x4a0
     ce0:      	ldr	x0, [x16, #0x40]
     ce4:      	add	x16, sp, #0x450
     ce8:      	str	x0, [x16, #0x40]
     cec:      	add	x16, sp, #0x4a0
     cf0:      	ldr	x0, [x16, #0x48]
     cf4:      	add	x16, sp, #0x450
     cf8:      	str	x0, [x16, #0x48]
     cfc:      	add	x8, sp, #0x520
     d00:      	ldr	x0, [sp, #0xe78]
     d04:      	mov	x1, x28
     d08:      	mov	w2, w21
     d0c:      	mov	x3, x24
     d10:      	bl	0xd10 <_stogir.pipeline.prepare-checked+0x440>
		0000000000000d10:  ARM64_RELOC_BRANCH26	_stogir.adjacency.reverse-postorder
     d14:      	add	x16, sp, #0x520
     d18:      	ldr	x0, [x16]
     d1c:      	add	x16, sp, #0x4f0
     d20:      	str	x0, [x16]
     d24:      	add	x16, sp, #0x520
     d28:      	ldr	x0, [x16, #0x8]
     d2c:      	add	x16, sp, #0x4f0
     d30:      	str	x0, [x16, #0x8]
     d34:      	add	x16, sp, #0x520
     d38:      	ldr	x0, [x16, #0x10]
     d3c:      	add	x16, sp, #0x4f0
     d40:      	str	x0, [x16, #0x10]
     d44:      	add	x16, sp, #0x520
     d48:      	ldr	x0, [x16, #0x18]
     d4c:      	add	x16, sp, #0x4f0
     d50:      	str	x0, [x16, #0x18]
     d54:      	add	x16, sp, #0x520
     d58:      	ldr	x0, [x16, #0x20]
     d5c:      	add	x16, sp, #0x4f0
     d60:      	str	x0, [x16, #0x20]
     d64:      	add	x8, sp, #0x580
     d68:      	ldr	x0, [sp, #0xe78]
     d6c:      	mov	x1, x27
     d70:      	mov	x2, x25
     d74:      	mov	x3, x24
     d78:      	bl	0xd78 <_stogir.pipeline.prepare-checked+0x4a8>
		0000000000000d78:  ARM64_RELOC_BRANCH26	_stogir.dominators.build
     d7c:      	add	x16, sp, #0x580
     d80:      	ldr	x0, [x16]
     d84:      	add	x16, sp, #0x550
     d88:      	str	x0, [x16]
     d8c:      	add	x16, sp, #0x580
     d90:      	ldr	x0, [x16, #0x8]
     d94:      	add	x16, sp, #0x550
     d98:      	str	x0, [x16, #0x8]
     d9c:      	add	x16, sp, #0x580
     da0:      	ldr	x0, [x16, #0x10]
     da4:      	add	x16, sp, #0x550
     da8:      	str	x0, [x16, #0x10]
     dac:      	add	x16, sp, #0x580
     db0:      	ldr	x0, [x16, #0x18]
     db4:      	add	x16, sp, #0x550
     db8:      	str	x0, [x16, #0x18]
     dbc:      	add	x16, sp, #0x580
     dc0:      	ldr	x0, [x16, #0x20]
     dc4:      	add	x16, sp, #0x550
     dc8:      	str	x0, [x16, #0x20]
     dcc:      	add	x8, sp, #0x5e0
     dd0:      	ldr	x0, [sp, #0xe78]
     dd4:      	mov	x1, x27
     dd8:      	mov	x2, x19
     ddc:      	mov	x3, x24
     de0:      	bl	0xde0 <_stogir.pipeline.prepare-checked+0x510>
		0000000000000de0:  ARM64_RELOC_BRANCH26	_stogir.loops.depths
     de4:      	add	x16, sp, #0x5e0
     de8:      	ldr	x0, [x16]
     dec:      	add	x16, sp, #0x5b0
     df0:      	str	x0, [x16]
     df4:      	add	x16, sp, #0x5e0
     df8:      	ldr	x0, [x16, #0x8]
     dfc:      	add	x16, sp, #0x5b0
     e00:      	str	x0, [x16, #0x8]
     e04:      	add	x16, sp, #0x5e0
     e08:      	ldr	x0, [x16, #0x10]
     e0c:      	add	x16, sp, #0x5b0
     e10:      	str	x0, [x16, #0x10]
     e14:      	add	x16, sp, #0x5e0
     e18:      	ldr	x0, [x16, #0x18]
     e1c:      	add	x16, sp, #0x5b0
     e20:      	str	x0, [x16, #0x18]
     e24:      	add	x16, sp, #0x5e0
     e28:      	ldr	x0, [x16, #0x20]
     e2c:      	add	x16, sp, #0x5b0
     e30:      	str	x0, [x16, #0x20]
     e34:      	add	x8, sp, #0x640
     e38:      	ldr	x0, [sp, #0xe60]
     e3c:      	ldr	x1, [sp, #0xe68]
     e40:      	ldr	x2, [sp, #0xe70]
     e44:      	mov	x3, x24
     e48:      	bl	0xe48 <_stogir.pipeline.prepare-checked+0x578>
		0000000000000e48:  ARM64_RELOC_BRANCH26	_stogir.liveness.mark
     e4c:      	add	x16, sp, #0x640
     e50:      	ldr	x0, [x16]
     e54:      	add	x16, sp, #0x610
     e58:      	str	x0, [x16]
     e5c:      	add	x16, sp, #0x640
     e60:      	ldr	x0, [x16, #0x8]
     e64:      	add	x16, sp, #0x610
     e68:      	str	x0, [x16, #0x8]
     e6c:      	add	x16, sp, #0x640
     e70:      	ldr	x0, [x16, #0x10]
     e74:      	add	x16, sp, #0x610
     e78:      	str	x0, [x16, #0x10]
     e7c:      	add	x16, sp, #0x640
     e80:      	ldr	x0, [x16, #0x18]
     e84:      	add	x16, sp, #0x610
     e88:      	str	x0, [x16, #0x18]
     e8c:      	add	x16, sp, #0x640
     e90:      	ldr	x0, [x16, #0x20]
     e94:      	add	x16, sp, #0x610
     e98:      	str	x0, [x16, #0x20]
     e9c:      	add	x8, sp, #0x6c0
     ea0:      	ldr	x0, [sp, #0xe60]
     ea4:      	mov	x1, x24
     ea8:      	bl	0xea8 <_stogir.pipeline.prepare-checked+0x5d8>
		0000000000000ea8:  ARM64_RELOC_BRANCH26	_stogir.uses.build
     eac:      	add	x16, sp, #0x6c0
     eb0:      	ldr	x0, [x16]
     eb4:      	add	x16, sp, #0x670
     eb8:      	str	x0, [x16]
     ebc:      	add	x16, sp, #0x6c0
     ec0:      	ldr	x0, [x16, #0x8]
     ec4:      	add	x16, sp, #0x670
     ec8:      	str	x0, [x16, #0x8]
     ecc:      	add	x16, sp, #0x6c0
     ed0:      	ldr	x0, [x16, #0x10]
     ed4:      	add	x16, sp, #0x670
     ed8:      	str	x0, [x16, #0x10]
     edc:      	add	x16, sp, #0x6c0
     ee0:      	ldr	x0, [x16, #0x18]
     ee4:      	add	x16, sp, #0x670
     ee8:      	str	x0, [x16, #0x18]
     eec:      	add	x16, sp, #0x6c0
     ef0:      	ldr	x0, [x16, #0x20]
     ef4:      	add	x16, sp, #0x670
     ef8:      	str	x0, [x16, #0x20]
     efc:      	add	x16, sp, #0x6c0
     f00:      	ldr	x0, [x16, #0x28]
     f04:      	add	x16, sp, #0x670
     f08:      	str	x0, [x16, #0x28]
     f0c:      	add	x16, sp, #0x6c0
     f10:      	ldr	x0, [x16, #0x30]
     f14:      	add	x16, sp, #0x670
     f18:      	str	x0, [x16, #0x30]
     f1c:      	add	x16, sp, #0x6c0
     f20:      	ldr	x0, [x16, #0x38]
     f24:      	add	x16, sp, #0x670
     f28:      	str	x0, [x16, #0x38]
     f2c:      	add	x16, sp, #0x6c0
     f30:      	ldr	x0, [x16, #0x40]
     f34:      	add	x16, sp, #0x670
     f38:      	str	x0, [x16, #0x40]
     f3c:      	add	x16, sp, #0x6c0
     f40:      	ldr	x0, [x16, #0x48]
     f44:      	add	x16, sp, #0x670
     f48:      	str	x0, [x16, #0x48]
     f4c:      	ldr	x0, [x24]
     f50:      	ldr	x1, [x24, #0x8]
     f54:      	ldr	x2, [x24]
     f58:      	ldr	x3, [x24, #0x8]
     f5c:      	add	x16, sp, #0x710
     f60:      	movz	x17, #0x0, lsl #48
     f64:      	str	x17, [x16]
     f68:      	add	x16, sp, #0x710
     f6c:      	movz	x17, #0x0, lsl #48
     f70:      	str	x17, [x16, #0x8]
     f74:      	add	x16, sp, #0x710
     f78:      	movz	x17, #0x0, lsl #48
     f7c:      	str	x17, [x16, #0x10]
     f80:      	add	x16, sp, #0x710
     f84:      	str	x0, [x16, #0x18]
     f88:      	add	x16, sp, #0x710
     f8c:      	str	x1, [x16, #0x20]
     f90:      	add	x16, sp, #0x710
     f94:      	movz	x17, #0x0, lsl #48
     f98:      	str	x17, [x16, #0x28]
     f9c:      	add	x16, sp, #0x710
     fa0:      	movz	x17, #0x0, lsl #48
     fa4:      	str	x17, [x16, #0x30]
     fa8:      	add	x16, sp, #0x710
     fac:      	movz	x17, #0x0, lsl #48
     fb0:      	str	x17, [x16, #0x38]
     fb4:      	add	x16, sp, #0x710
     fb8:      	str	x2, [x16, #0x40]
     fbc:      	add	x16, sp, #0x710
     fc0:      	str	x3, [x16, #0x48]
     fc4:      	add	x8, sp, #0x760
     fc8:      	ldr	x0, [sp, #0xe60]
     fcc:      	ldr	x1, [sp, #0xe78]
     fd0:      	mov	x2, x24
     fd4:      	bl	0xfd4 <_stogir.pipeline.prepare-checked+0x704>
		0000000000000fd4:  ARM64_RELOC_BRANCH26	_stogir.placement.pinned
     fd8:      	add	x16, sp, #0x760
     fdc:      	ldr	w0, [x16]
     fe0:      	lsr	x16, x0, #0
     fe4:      	cmp	x16, #0x1
     fe8:      	b.eq	0x1004 <_stogir.pipeline.prepare-checked+0x734>
     fec:      	b.lo	0xff4 <_stogir.pipeline.prepare-checked+0x724>
     ff0:      	b	0x1008 <_stogir.pipeline.prepare-checked+0x738>
     ff4:      	cmp	x16, #0x0
     ff8:      	b.eq	0x1000 <_stogir.pipeline.prepare-checked+0x730>
     ffc:      	b	0x1008 <_stogir.pipeline.prepare-checked+0x738>
    1000:      	b	0x1590 <_stogir.pipeline.prepare-checked+0xcc0>
    1004:      	b	0x100c <_stogir.pipeline.prepare-checked+0x73c>
    1008:      	b	0x1d7c <_stogir.pipeline.prepare-checked+0x14ac>
    100c:      	add	x0, x26, #0x8
    1010:      	add	x16, sp, #0x760
    1014:      	ldr	x21, [x16, #0x8]
    1018:      	ldr	x26, [x0, #0x8]
    101c:      	str	x28, [sp, #0xe88]
    1020:      	b	0x1514 <_stogir.pipeline.prepare-checked+0xc44>
    1024:      	nop
    1028:      	sub	x0, x0, #0x1
    102c:      	add	x16, sp, #0x610
    1030:      	str	x0, [x16, #0x8]
    1034:      	add	x16, sp, #0x610
    1038:      	ldr	x0, [x16, #0x8]
    103c:      	cmp	x0, #0x0
    1040:      	b.ne	0x1028 <_stogir.pipeline.prepare-checked+0x758>
    1044:      	add	x16, sp, #0x610
    1048:      	ldr	x0, [x16, #0x10]
    104c:      	cmp	x0, #0x0
    1050:      	b.le	0x1084 <_stogir.pipeline.prepare-checked+0x7b4>
    1054:      	add	x1, x22, #0x18
    1058:      	add	x16, sp, #0x610
    105c:      	ldr	x2, [x16]
    1060:      	fmov	d31, x0
    1064:      	mov	x0, x1
    1068:      	mov	x1, x2
    106c:      	fmov	x2, d31
    1070:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001070:  ARM64_RELOC_PAGE21	l_stogir.394
    1074:      	ldr	x3, [x3]
		0000000000001074:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    1078:      	mov	x4, #0x1                ; =1
    107c:      	mov	x5, #0x1                ; =1
    1080:      	bl	0x1080 <_stogir.pipeline.prepare-checked+0x7b0>
		0000000000001080:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1084:      	add	x16, sp, #0x610
    1088:      	movz	x17, #0x0, lsl #48
    108c:      	str	x17, [x16]
    1090:      	add	x16, sp, #0x610
    1094:      	movz	x17, #0x0, lsl #48
    1098:      	str	x17, [x16, #0x8]
    109c:      	add	x16, sp, #0x610
    10a0:      	movz	x17, #0x0, lsl #48
    10a4:      	str	x17, [x16, #0x10]
    10a8:      	ldr	x0, [sp, #0xe50]
    10ac:      	bl	0x10ac <_stogir.pipeline.prepare-checked+0x7dc>
		00000000000010ac:  ARM64_RELOC_BRANCH26	_stogir.uses.release!
    10b0:      	cmp	x26, #0x0
    10b4:      	b.ne	0x181c <_stogir.pipeline.prepare-checked+0xf4c>
    10b8:      	add	x16, sp, #0xa60
    10bc:      	orr	x20, x16, xzr
    10c0:      	add	x16, sp, #0xbb0
    10c4:      	orr	x0, x16, xzr
    10c8:      	add	x16, sp, #0xa60
    10cc:      	movz	w17, #0x0, lsl #16
    10d0:      	str	w17, [x16]
    10d4:      	add	x1, x20, #0x8
    10d8:      	add	x19, x0, #0x78
    10dc:      	add	x21, x0, #0xa0
    10e0:      	add	x22, x0, #0xf0
    10e4:      	add	x23, x0, #0x118
    10e8:      	add	x16, sp, #0x550
    10ec:      	ldr	x24, [x16]
    10f0:      	orr	x25, x1, xzr
    10f4:      	add	x16, sp, #0x550
    10f8:      	ldr	x26, [x16, #0x8]
    10fc:      	add	x16, sp, #0x550
    1100:      	ldr	x27, [x16, #0x10]
    1104:      	add	x16, sp, #0x550
    1108:      	ldr	x28, [x16, #0x18]
    110c:      	add	x16, sp, #0x550
    1110:      	ldr	x0, [x16, #0x20]
    1114:      	add	x16, sp, #0x5b0
    1118:      	ldr	x1, [x16]
    111c:      	add	x16, sp, #0x5b0
    1120:      	ldr	x2, [x16, #0x8]
    1124:      	add	x16, sp, #0x5b0
    1128:      	ldr	x3, [x16, #0x10]
    112c:      	add	x16, sp, #0x5b0
    1130:      	ldr	x4, [x16, #0x18]
    1134:      	add	x16, sp, #0x5b0
    1138:      	ldr	x5, [x16, #0x20]
    113c:      	add	x16, sp, #0x330
    1140:      	ldr	x6, [x16]
    1144:      	add	x16, sp, #0x330
    1148:      	ldr	x7, [x16, #0x8]
    114c:      	add	x16, sp, #0x330
    1150:      	ldr	x8, [x16, #0x10]
    1154:      	add	x16, sp, #0x330
    1158:      	ldr	x9, [x16, #0x18]
    115c:      	add	x16, sp, #0x330
    1160:      	ldr	x10, [x16, #0x20]
    1164:      	add	x16, sp, #0x330
    1168:      	ldr	x11, [x16, #0x28]
    116c:      	add	x16, sp, #0x330
    1170:      	ldr	x12, [x16, #0x30]
    1174:      	add	x16, sp, #0x330
    1178:      	ldr	x13, [x16, #0x38]
    117c:      	add	x16, sp, #0x330
    1180:      	ldr	x14, [x16, #0x40]
    1184:      	add	x16, sp, #0x330
    1188:      	ldr	x15, [x16, #0x48]
    118c:      	str	x0, [sp, #0xe90]
    1190:      	add	x16, sp, #0x330
    1194:      	ldr	x0, [x16, #0x50]
    1198:      	str	x0, [sp, #0xe98]
    119c:      	add	x16, sp, #0x330
    11a0:      	ldr	x0, [x16, #0x58]
    11a4:      	str	x0, [sp, #0xea0]
    11a8:      	add	x16, sp, #0x330
    11ac:      	ldr	x0, [x16, #0x60]
    11b0:      	str	x0, [sp, #0xea8]
    11b4:      	add	x16, sp, #0x330
    11b8:      	ldr	x0, [x16, #0x68]
    11bc:      	str	x0, [sp, #0xeb0]
    11c0:      	add	x16, sp, #0x330
    11c4:      	ldr	x0, [x16, #0x70]
    11c8:      	str	x0, [sp, #0xeb8]
    11cc:      	add	x16, sp, #0x4f0
    11d0:      	ldr	x0, [x16]
    11d4:      	str	x0, [sp, #0xec0]
    11d8:      	add	x16, sp, #0x4f0
    11dc:      	ldr	x0, [x16, #0x8]
    11e0:      	str	x0, [sp, #0xec8]
    11e4:      	add	x16, sp, #0x4f0
    11e8:      	ldr	x0, [x16, #0x10]
    11ec:      	str	x0, [sp, #0xed0]
    11f0:      	add	x16, sp, #0x4f0
    11f4:      	ldr	x0, [x16, #0x18]
    11f8:      	str	x0, [sp, #0xed8]
    11fc:      	add	x16, sp, #0x4f0
    1200:      	ldr	x0, [x16, #0x20]
    1204:      	str	x0, [sp, #0xee0]
    1208:      	add	x16, sp, #0x710
    120c:      	ldr	x0, [x16]
    1210:      	str	x0, [sp, #0xee8]
    1214:      	add	x16, sp, #0x710
    1218:      	ldr	x0, [x16, #0x8]
    121c:      	str	x0, [sp, #0xef0]
    1220:      	add	x16, sp, #0x710
    1224:      	ldr	x0, [x16, #0x10]
    1228:      	str	x0, [sp, #0xef8]
    122c:      	add	x16, sp, #0x710
    1230:      	ldr	x0, [x16, #0x18]
    1234:      	str	x0, [sp, #0xf00]
    1238:      	add	x16, sp, #0x710
    123c:      	ldr	x0, [x16, #0x20]
    1240:      	str	x0, [sp, #0xf08]
    1244:      	add	x16, sp, #0x710
    1248:      	ldr	x0, [x16, #0x28]
    124c:      	str	x0, [sp, #0xf10]
    1250:      	add	x16, sp, #0x710
    1254:      	ldr	x0, [x16, #0x30]
    1258:      	str	x0, [sp, #0xf18]
    125c:      	add	x16, sp, #0x710
    1260:      	ldr	x0, [x16, #0x38]
    1264:      	str	x0, [sp, #0xf20]
    1268:      	add	x16, sp, #0x710
    126c:      	ldr	x0, [x16, #0x40]
    1270:      	str	x0, [sp, #0xf28]
    1274:      	add	x16, sp, #0x710
    1278:      	ldr	x0, [x16, #0x48]
    127c:      	str	x1, [sp, #0xf68]
    1280:      	str	x2, [sp, #0xf40]
    1284:      	str	x3, [sp, #0xf48]
    1288:      	str	x4, [sp, #0xf50]
    128c:      	str	x5, [sp, #0xf58]
    1290:      	str	x0, [sp, #0xfa8]
    1294:      	add	x0, sp, #0xbb0
    1298:      	str	x25, [sp, #0xf30]
    129c:      	mov	x25, x8
    12a0:      	str	x20, [sp, #0xf38]
    12a4:      	mov	x20, x7
    12a8:      	str	x23, [sp, #0xf60]
    12ac:      	mov	x23, x6
    12b0:      	str	x28, [sp, #0xf70]
    12b4:      	mov	x28, x9
    12b8:      	str	x27, [sp, #0xf78]
    12bc:      	mov	x27, x10
    12c0:      	str	x22, [sp, #0xf80]
    12c4:      	mov	x22, x11
    12c8:      	str	x26, [sp, #0xf88]
    12cc:      	mov	x26, x12
    12d0:      	str	x24, [sp, #0xf90]
    12d4:      	mov	x24, x13
    12d8:      	str	x21, [sp, #0xf98]
    12dc:      	mov	x21, x14
    12e0:      	str	x19, [sp, #0xfa0]
    12e4:      	mov	x19, x15
    12e8:      	movz	x1, #0x0, lsl #48
    12ec:      	mov	x2, #0x140              ; =320
    12f0:      	bl	0x12f0 <_stogir.pipeline.prepare-checked+0xa20>
		00000000000012f0:  ARM64_RELOC_BRANCH26	_memset
    12f4:      	add	x16, sp, #0xbb0
    12f8:      	str	x23, [x16]
    12fc:      	add	x16, sp, #0xbb0
    1300:      	str	x20, [x16, #0x8]
    1304:      	add	x16, sp, #0xbb0
    1308:      	str	x25, [x16, #0x10]
    130c:      	add	x16, sp, #0xbb0
    1310:      	str	x28, [x16, #0x18]
    1314:      	add	x16, sp, #0xbb0
    1318:      	str	x27, [x16, #0x20]
    131c:      	add	x16, sp, #0xbb0
    1320:      	str	x22, [x16, #0x28]
    1324:      	add	x16, sp, #0xbb0
    1328:      	str	x26, [x16, #0x30]
    132c:      	add	x16, sp, #0xbb0
    1330:      	str	x24, [x16, #0x38]
    1334:      	add	x16, sp, #0xbb0
    1338:      	str	x21, [x16, #0x40]
    133c:      	add	x16, sp, #0xbb0
    1340:      	str	x19, [x16, #0x48]
    1344:      	ldr	x0, [sp, #0xe98]
    1348:      	add	x16, sp, #0xbb0
    134c:      	str	x0, [x16, #0x50]
    1350:      	ldr	x0, [sp, #0xea0]
    1354:      	add	x16, sp, #0xbb0
    1358:      	str	x0, [x16, #0x58]
    135c:      	ldr	x0, [sp, #0xea8]
    1360:      	add	x16, sp, #0xbb0
    1364:      	str	x0, [x16, #0x60]
    1368:      	ldr	x0, [sp, #0xeb0]
    136c:      	add	x16, sp, #0xbb0
    1370:      	str	x0, [x16, #0x68]
    1374:      	ldr	x0, [sp, #0xeb8]
    1378:      	add	x16, sp, #0xbb0
    137c:      	str	x0, [x16, #0x70]
    1380:      	ldr	x0, [sp, #0xec0]
    1384:      	add	x16, sp, #0xbb0
    1388:      	str	x0, [x16, #0x78]
    138c:      	ldr	x0, [sp, #0xfa0]
    1390:      	ldr	x1, [sp, #0xec8]
    1394:      	str	x1, [x0, #0x8]
    1398:      	ldr	x1, [sp, #0xed0]
    139c:      	str	x1, [x0, #0x10]
    13a0:      	ldr	x1, [sp, #0xed8]
    13a4:      	str	x1, [x0, #0x18]
    13a8:      	ldr	x1, [sp, #0xee0]
    13ac:      	str	x1, [x0, #0x20]
    13b0:      	ldr	x0, [sp, #0xee8]
    13b4:      	add	x16, sp, #0xbb0
    13b8:      	str	x0, [x16, #0xa0]
    13bc:      	ldr	x0, [sp, #0xf98]
    13c0:      	ldr	x1, [sp, #0xef0]
    13c4:      	str	x1, [x0, #0x8]
    13c8:      	ldr	x1, [sp, #0xef8]
    13cc:      	str	x1, [x0, #0x10]
    13d0:      	ldr	x1, [sp, #0xf00]
    13d4:      	str	x1, [x0, #0x18]
    13d8:      	ldr	x1, [sp, #0xf08]
    13dc:      	str	x1, [x0, #0x20]
    13e0:      	ldr	x1, [sp, #0xf10]
    13e4:      	str	x1, [x0, #0x28]
    13e8:      	ldr	x1, [sp, #0xf18]
    13ec:      	str	x1, [x0, #0x30]
    13f0:      	ldr	x1, [sp, #0xf20]
    13f4:      	str	x1, [x0, #0x38]
    13f8:      	ldr	x1, [sp, #0xf28]
    13fc:      	str	x1, [x0, #0x40]
    1400:      	ldr	x1, [sp, #0xfa8]
    1404:      	str	x1, [x0, #0x48]
    1408:      	ldr	x0, [sp, #0xf90]
    140c:      	add	x16, sp, #0xbb0
    1410:      	str	x0, [x16, #0xf0]
    1414:      	ldr	x0, [sp, #0xf80]
    1418:      	ldr	x1, [sp, #0xf88]
    141c:      	str	x1, [x0, #0x8]
    1420:      	ldr	x1, [sp, #0xf78]
    1424:      	str	x1, [x0, #0x10]
    1428:      	ldr	x1, [sp, #0xf70]
    142c:      	str	x1, [x0, #0x18]
    1430:      	ldr	x1, [sp, #0xe90]
    1434:      	str	x1, [x0, #0x20]
    1438:      	ldr	x0, [sp, #0xf68]
    143c:      	add	x16, sp, #0xbb0
    1440:      	str	x0, [x16, #0x118]
    1444:      	ldr	x0, [sp, #0xf40]
    1448:      	ldr	x1, [sp, #0xf60]
    144c:      	str	x0, [x1, #0x8]
    1450:      	ldr	x0, [sp, #0xf48]
    1454:      	str	x0, [x1, #0x10]
    1458:      	ldr	x0, [sp, #0xf50]
    145c:      	str	x0, [x1, #0x18]
    1460:      	ldr	x0, [sp, #0xf58]
    1464:      	str	x0, [x1, #0x20]
    1468:      	add	x0, sp, #0xcf0
    146c:      	add	x1, sp, #0xbb0
    1470:      	mov	x2, #0x140              ; =320
    1474:      	bl	0x1474 <_stogir.pipeline.prepare-checked+0xba4>
		0000000000001474:  ARM64_RELOC_BRANCH26	_memmove
    1478:      	ldr	x0, [sp, #0xf30]
    147c:      	add	x1, sp, #0xcf0
    1480:      	mov	x2, #0x140              ; =320
    1484:      	bl	0x1484 <_stogir.pipeline.prepare-checked+0xbb4>
		0000000000001484:  ARM64_RELOC_BRANCH26	_memmove
    1488:      	ldr	x19, [sp, #0xf38]
    148c:      	b	0xa3c <_stogir.pipeline.prepare-checked+0x16c>
    1490:      	sub	x0, x0, #0x1
    1494:      	str	x0, [x24, #0x8]
    1498:      	ldr	x0, [x24, #0x8]
    149c:      	cmp	x0, #0x0
    14a0:      	b.ne	0x1490 <_stogir.pipeline.prepare-checked+0xbc0>
    14a4:      	ldr	x0, [x24, #0x10]
    14a8:      	cmp	x0, #0x0
    14ac:      	b.le	0x14e0 <_stogir.pipeline.prepare-checked+0xc10>
    14b0:      	add	x1, x24, #0x18
    14b4:      	add	x16, sp, #0x3b0
    14b8:      	ldr	x2, [x16, #0x28]
    14bc:      	fmov	d31, x0
    14c0:      	mov	x0, x1
    14c4:      	mov	x1, x2
    14c8:      	fmov	x2, d31
    14cc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		00000000000014cc:  ARM64_RELOC_PAGE21	l_stogir.395
    14d0:      	ldr	x3, [x3]
		00000000000014d0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    14d4:      	mov	x4, #0x8                ; =8
    14d8:      	mov	x5, #0x8                ; =8
    14dc:      	bl	0x14dc <_stogir.pipeline.prepare-checked+0xc0c>
		00000000000014dc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    14e0:      	add	x16, sp, #0x3b0
    14e4:      	movz	x17, #0x0, lsl #48
    14e8:      	str	x17, [x16, #0x28]
    14ec:      	movz	x17, #0x0, lsl #48
    14f0:      	str	x17, [x24, #0x8]
    14f4:      	movz	x17, #0x0, lsl #48
    14f8:      	str	x17, [x24, #0x10]
    14fc:      	ldr	x0, [sp, #0xe88]
    1500:      	bl	0x1500 <_stogir.pipeline.prepare-checked+0xc30>
		0000000000001500:  ARM64_RELOC_BRANCH26	_stogir.adjacency.release!
    1504:      	b	0x1034 <_stogir.pipeline.prepare-checked+0x764>
    1508:      	sub	x0, x0, #0x1
    150c:      	add	x16, sp, #0x3b0
    1510:      	str	x0, [x16, #0x8]
    1514:      	add	x16, sp, #0x3b0
    1518:      	ldr	x0, [x16, #0x8]
    151c:      	cmp	x0, #0x0
    1520:      	b.ne	0x1508 <_stogir.pipeline.prepare-checked+0xc38>
    1524:      	add	x16, sp, #0x3b0
    1528:      	ldr	x0, [x16, #0x10]
    152c:      	cmp	x0, #0x0
    1530:      	b.le	0x1564 <_stogir.pipeline.prepare-checked+0xc94>
    1534:      	add	x1, x27, #0x18
    1538:      	add	x16, sp, #0x3b0
    153c:      	ldr	x2, [x16]
    1540:      	fmov	d31, x0
    1544:      	mov	x0, x1
    1548:      	mov	x1, x2
    154c:      	fmov	x2, d31
    1550:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001550:  ARM64_RELOC_PAGE21	l_stogir.396
    1554:      	ldr	x3, [x3]
		0000000000001554:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    1558:      	mov	x4, #0x10               ; =16
    155c:      	mov	x5, #0x8                ; =8
    1560:      	bl	0x1560 <_stogir.pipeline.prepare-checked+0xc90>
		0000000000001560:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1564:      	add	x24, x27, #0x28
    1568:      	add	x16, sp, #0x3b0
    156c:      	movz	x17, #0x0, lsl #48
    1570:      	str	x17, [x16]
    1574:      	add	x16, sp, #0x3b0
    1578:      	movz	x17, #0x0, lsl #48
    157c:      	str	x17, [x16, #0x8]
    1580:      	add	x16, sp, #0x3b0
    1584:      	movz	x17, #0x0, lsl #48
    1588:      	str	x17, [x16, #0x10]
    158c:      	b	0x1498 <_stogir.pipeline.prepare-checked+0xbc8>
    1590:      	add	x16, sp, #0x790
    1594:      	orr	x0, x16, xzr
    1598:      	add	x1, x26, #0x8
    159c:      	add	x16, sp, #0x760
    15a0:      	ldr	x2, [x16, #0x8]
    15a4:      	ldr	x3, [x1, #0x8]
    15a8:      	ldr	x4, [x1, #0x10]
    15ac:      	ldr	x5, [x1, #0x18]
    15b0:      	ldr	x1, [x1, #0x20]
    15b4:      	add	x16, sp, #0x790
    15b8:      	str	x2, [x16]
    15bc:      	add	x16, sp, #0x790
    15c0:      	str	x3, [x16, #0x8]
    15c4:      	add	x16, sp, #0x790
    15c8:      	str	x4, [x16, #0x10]
    15cc:      	add	x16, sp, #0x790
    15d0:      	str	x5, [x16, #0x18]
    15d4:      	add	x16, sp, #0x790
    15d8:      	str	x1, [x16, #0x20]
    15dc:      	add	x8, sp, #0x7c0
    15e0:      	mov	x1, x0
    15e4:      	mov	x2, x19
    15e8:      	mov	w3, w21
    15ec:      	ldr	x4, [sp, #0xe50]
    15f0:      	mov	x5, x24
    15f4:      	mov	x26, x0
    15f8:      	ldr	x0, [sp, #0xe60]
    15fc:      	bl	0x15fc <_stogir.pipeline.prepare-checked+0xd2c>
		00000000000015fc:  ARM64_RELOC_BRANCH26	_stogir.placement.early-with-uses!
    1600:      	add	x16, sp, #0x7c0
    1604:      	ldr	w0, [x16]
    1608:      	lsr	x16, x0, #0
    160c:      	cmp	x16, #0x1
    1610:      	b.eq	0x1630 <_stogir.pipeline.prepare-checked+0xd60>
    1614:      	b.lo	0x161c <_stogir.pipeline.prepare-checked+0xd4c>
    1618:      	b	0x1634 <_stogir.pipeline.prepare-checked+0xd64>
    161c:      	cmp	x16, #0x0
    1620:      	b.eq	0x1628 <_stogir.pipeline.prepare-checked+0xd58>
    1624:      	b	0x1634 <_stogir.pipeline.prepare-checked+0xd64>
    1628:      	mov	x1, x26
    162c:      	b	0x1820 <_stogir.pipeline.prepare-checked+0xf50>
    1630:      	b	0x1638 <_stogir.pipeline.prepare-checked+0xd68>
    1634:      	b	0x1d84 <_stogir.pipeline.prepare-checked+0x14b4>
    1638:      	add	x16, sp, #0x7c0
    163c:      	orr	x0, x16, xzr
    1640:      	add	x0, x0, #0x8
    1644:      	add	x16, sp, #0x7c0
    1648:      	ldr	x21, [x16, #0x8]
    164c:      	mov	x1, x26
    1650:      	ldr	x26, [x0, #0x8]
    1654:      	b	0x182c <_stogir.pipeline.prepare-checked+0xf5c>
    1658:      	sub	x0, x0, #0x1
    165c:      	add	x16, sp, #0x4f0
    1660:      	str	x0, [x16, #0x8]
    1664:      	add	x16, sp, #0x4f0
    1668:      	ldr	x0, [x16, #0x8]
    166c:      	cmp	x0, #0x0
    1670:      	b.ne	0x1658 <_stogir.pipeline.prepare-checked+0xd88>
    1674:      	add	x16, sp, #0x4f0
    1678:      	ldr	x0, [x16, #0x10]
    167c:      	cmp	x0, #0x0
    1680:      	b.le	0x16b4 <_stogir.pipeline.prepare-checked+0xde4>
    1684:      	add	x1, x25, #0x18
    1688:      	add	x16, sp, #0x4f0
    168c:      	ldr	x2, [x16]
    1690:      	fmov	d31, x0
    1694:      	mov	x0, x1
    1698:      	mov	x1, x2
    169c:      	fmov	x2, d31
    16a0:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		00000000000016a0:  ARM64_RELOC_PAGE21	l_stogir.397
    16a4:      	ldr	x3, [x3]
		00000000000016a4:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    16a8:      	mov	x4, #0x4                ; =4
    16ac:      	mov	x5, #0x4                ; =4
    16b0:      	bl	0x16b0 <_stogir.pipeline.prepare-checked+0xde0>
		00000000000016b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    16b4:      	add	x16, sp, #0x910
    16b8:      	orr	x19, x16, xzr
    16bc:      	add	x20, x19, #0x8
    16c0:      	add	x16, sp, #0x4f0
    16c4:      	movz	x17, #0x0, lsl #48
    16c8:      	str	x17, [x16]
    16cc:      	add	x16, sp, #0x4f0
    16d0:      	movz	x17, #0x0, lsl #48
    16d4:      	str	x17, [x16, #0x8]
    16d8:      	add	x16, sp, #0x4f0
    16dc:      	movz	x17, #0x0, lsl #48
    16e0:      	str	x17, [x16, #0x10]
    16e4:      	mov	x0, x23
    16e8:      	bl	0x16e8 <_stogir.pipeline.prepare-checked+0xe18>
		00000000000016e8:  ARM64_RELOC_BRANCH26	_stogir.schedule.release!
    16ec:      	add	x16, sp, #0x910
    16f0:      	mov	w17, #0x1               ; =1
    16f4:      	str	w17, [x16]
    16f8:      	add	x16, sp, #0x910
    16fc:      	str	x21, [x16, #0x8]
    1700:      	str	x26, [x20, #0x8]
    1704:      	b	0x148c <_stogir.pipeline.prepare-checked+0xbbc>
    1708:      	sub	x0, x0, #0x1
    170c:      	add	x16, sp, #0x5b0
    1710:      	str	x0, [x16, #0x8]
    1714:      	add	x16, sp, #0x5b0
    1718:      	ldr	x0, [x16, #0x8]
    171c:      	cmp	x0, #0x0
    1720:      	b.ne	0x1708 <_stogir.pipeline.prepare-checked+0xe38>
    1724:      	add	x16, sp, #0x5b0
    1728:      	ldr	x0, [x16, #0x10]
    172c:      	cmp	x0, #0x0
    1730:      	b.le	0x1764 <_stogir.pipeline.prepare-checked+0xe94>
    1734:      	add	x1, x20, #0x18
    1738:      	add	x16, sp, #0x5b0
    173c:      	ldr	x2, [x16]
    1740:      	fmov	d31, x0
    1744:      	mov	x0, x1
    1748:      	mov	x1, x2
    174c:      	fmov	x2, d31
    1750:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001750:  ARM64_RELOC_PAGE21	l_stogir.397
    1754:      	ldr	x3, [x3]
		0000000000001754:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    1758:      	mov	x4, #0x4                ; =4
    175c:      	mov	x5, #0x4                ; =4
    1760:      	bl	0x1760 <_stogir.pipeline.prepare-checked+0xe90>
		0000000000001760:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1764:      	add	x16, sp, #0x5b0
    1768:      	movz	x17, #0x0, lsl #48
    176c:      	str	x17, [x16]
    1770:      	add	x16, sp, #0x5b0
    1774:      	movz	x17, #0x0, lsl #48
    1778:      	str	x17, [x16, #0x8]
    177c:      	add	x16, sp, #0x5b0
    1780:      	movz	x17, #0x0, lsl #48
    1784:      	str	x17, [x16, #0x10]
    1788:      	ldr	x0, [sp, #0xe78]
    178c:      	bl	0x178c <_stogir.pipeline.prepare-checked+0xebc>
		000000000000178c:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    1790:      	b	0x1664 <_stogir.pipeline.prepare-checked+0xd94>
    1794:      	nop
    1798:      	sub	x0, x0, #0x1
    179c:      	add	x16, sp, #0x550
    17a0:      	str	x0, [x16, #0x8]
    17a4:      	add	x16, sp, #0x550
    17a8:      	ldr	x0, [x16, #0x8]
    17ac:      	cmp	x0, #0x0
    17b0:      	b.ne	0x1798 <_stogir.pipeline.prepare-checked+0xec8>
    17b4:      	add	x16, sp, #0x550
    17b8:      	ldr	x0, [x16, #0x10]
    17bc:      	cmp	x0, #0x0
    17c0:      	b.le	0x17f4 <_stogir.pipeline.prepare-checked+0xf24>
    17c4:      	add	x1, x19, #0x18
    17c8:      	add	x16, sp, #0x550
    17cc:      	ldr	x2, [x16]
    17d0:      	fmov	d31, x0
    17d4:      	mov	x0, x1
    17d8:      	mov	x1, x2
    17dc:      	fmov	x2, d31
    17e0:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		00000000000017e0:  ARM64_RELOC_PAGE21	l_stogir.397
    17e4:      	ldr	x3, [x3]
		00000000000017e4:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    17e8:      	mov	x4, #0x4                ; =4
    17ec:      	mov	x5, #0x4                ; =4
    17f0:      	bl	0x17f0 <_stogir.pipeline.prepare-checked+0xf20>
		00000000000017f0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    17f4:      	add	x16, sp, #0x550
    17f8:      	movz	x17, #0x0, lsl #48
    17fc:      	str	x17, [x16]
    1800:      	add	x16, sp, #0x550
    1804:      	movz	x17, #0x0, lsl #48
    1808:      	str	x17, [x16, #0x8]
    180c:      	add	x16, sp, #0x550
    1810:      	movz	x17, #0x0, lsl #48
    1814:      	str	x17, [x16, #0x10]
    1818:      	b	0x1714 <_stogir.pipeline.prepare-checked+0xe44>
    181c:      	b	0x17a4 <_stogir.pipeline.prepare-checked+0xed4>
    1820:      	adrp	x21, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001820:  ARM64_RELOC_PAGE21	l_stogir.398
    1824:      	ldr	x21, [x21]
		0000000000001824:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    1828:      	movz	x26, #0x0, lsl #48
    182c:      	cmp	x26, #0x0
    1830:      	b.ne	0x1dbc <_stogir.pipeline.prepare-checked+0x14ec>
    1834:      	add	x8, sp, #0x7e0
    1838:      	ldr	x0, [sp, #0xe60]
    183c:      	mov	x2, x19
    1840:      	mov	x3, x20
    1844:      	mov	x4, x22
    1848:      	ldr	x5, [sp, #0xe50]
    184c:      	mov	x6, x24
    1850:      	str	x24, [sp, #0xe80]
    1854:      	mov	x24, x1
    1858:      	bl	0x1858 <_stogir.pipeline.prepare-checked+0xf88>
		0000000000001858:  ARM64_RELOC_BRANCH26	_stogir.placement.late-with-uses!
    185c:      	add	x16, sp, #0x7e0
    1860:      	ldr	w0, [x16]
    1864:      	lsr	x16, x0, #0
    1868:      	cmp	x16, #0x1
    186c:      	b.eq	0x1888 <_stogir.pipeline.prepare-checked+0xfb8>
    1870:      	b.lo	0x1878 <_stogir.pipeline.prepare-checked+0xfa8>
    1874:      	b	0x188c <_stogir.pipeline.prepare-checked+0xfbc>
    1878:      	cmp	x16, #0x0
    187c:      	b.eq	0x1884 <_stogir.pipeline.prepare-checked+0xfb4>
    1880:      	b	0x188c <_stogir.pipeline.prepare-checked+0xfbc>
    1884:      	b	0x18a8 <_stogir.pipeline.prepare-checked+0xfd8>
    1888:      	b	0x1890 <_stogir.pipeline.prepare-checked+0xfc0>
    188c:      	b	0x1d8c <_stogir.pipeline.prepare-checked+0x14bc>
    1890:      	add	x16, sp, #0x7e0
    1894:      	orr	x0, x16, xzr
    1898:      	add	x0, x0, #0x8
    189c:      	add	x16, sp, #0x7e0
    18a0:      	ldr	x21, [x16, #0x8]
    18a4:      	ldr	x26, [x0, #0x8]
    18a8:      	cmp	x26, #0x0
    18ac:      	b.ne	0x1910 <_stogir.pipeline.prepare-checked+0x1040>
    18b0:      	add	x8, sp, #0x800
    18b4:      	ldr	x0, [sp, #0xe60]
    18b8:      	mov	x1, x24
    18bc:      	mov	x2, x22
    18c0:      	bl	0x18c0 <_stogir.pipeline.prepare-checked+0xff0>
		00000000000018c0:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.place!
    18c4:      	add	x16, sp, #0x800
    18c8:      	ldr	w0, [x16]
    18cc:      	lsr	x16, x0, #0
    18d0:      	cmp	x16, #0x1
    18d4:      	b.eq	0x18f0 <_stogir.pipeline.prepare-checked+0x1020>
    18d8:      	b.lo	0x18e0 <_stogir.pipeline.prepare-checked+0x1010>
    18dc:      	b	0x18f4 <_stogir.pipeline.prepare-checked+0x1024>
    18e0:      	cmp	x16, #0x0
    18e4:      	b.eq	0x18ec <_stogir.pipeline.prepare-checked+0x101c>
    18e8:      	b	0x18f4 <_stogir.pipeline.prepare-checked+0x1024>
    18ec:      	b	0x1910 <_stogir.pipeline.prepare-checked+0x1040>
    18f0:      	b	0x18f8 <_stogir.pipeline.prepare-checked+0x1028>
    18f4:      	b	0x1d94 <_stogir.pipeline.prepare-checked+0x14c4>
    18f8:      	add	x16, sp, #0x800
    18fc:      	orr	x0, x16, xzr
    1900:      	add	x0, x0, #0x8
    1904:      	add	x16, sp, #0x800
    1908:      	ldr	x21, [x16, #0x8]
    190c:      	ldr	x26, [x0, #0x8]
    1910:      	cmp	x26, #0x0
    1914:      	b.ne	0x1984 <_stogir.pipeline.prepare-checked+0x10b4>
    1918:      	add	x8, sp, #0x820
    191c:      	ldr	x0, [sp, #0xe78]
    1920:      	mov	x1, x28
    1924:      	mov	x2, x19
    1928:      	mov	x3, x20
    192c:      	mov	x4, x25
    1930:      	ldr	x5, [sp, #0xe80]
    1934:      	bl	0x1934 <_stogir.pipeline.prepare-checked+0x1064>
		0000000000001934:  ARM64_RELOC_BRANCH26	_stogir.loops.reorder!
    1938:      	add	x16, sp, #0x820
    193c:      	ldr	w0, [x16]
    1940:      	lsr	x16, x0, #0
    1944:      	cmp	x16, #0x1
    1948:      	b.eq	0x1964 <_stogir.pipeline.prepare-checked+0x1094>
    194c:      	b.lo	0x1954 <_stogir.pipeline.prepare-checked+0x1084>
    1950:      	b	0x1968 <_stogir.pipeline.prepare-checked+0x1098>
    1954:      	cmp	x16, #0x0
    1958:      	b.eq	0x1960 <_stogir.pipeline.prepare-checked+0x1090>
    195c:      	b	0x1968 <_stogir.pipeline.prepare-checked+0x1098>
    1960:      	b	0x1984 <_stogir.pipeline.prepare-checked+0x10b4>
    1964:      	b	0x196c <_stogir.pipeline.prepare-checked+0x109c>
    1968:      	b	0x1d9c <_stogir.pipeline.prepare-checked+0x14cc>
    196c:      	add	x16, sp, #0x820
    1970:      	orr	x0, x16, xzr
    1974:      	add	x0, x0, #0x8
    1978:      	add	x16, sp, #0x820
    197c:      	ldr	x21, [x16, #0x8]
    1980:      	ldr	x26, [x0, #0x8]
    1984:      	cmp	x26, #0x0
    1988:      	b.ne	0x1dc8 <_stogir.pipeline.prepare-checked+0x14f8>
    198c:      	add	x16, sp, #0x840
    1990:      	orr	x0, x16, xzr
    1994:      	add	x8, sp, #0x840
    1998:      	mov	x1, x24
    199c:      	mov	x2, x22
    19a0:      	ldr	x3, [sp, #0xe50]
    19a4:      	ldr	x4, [sp, #0xe80]
    19a8:      	str	x28, [sp, #0xe88]
    19ac:      	mov	x28, x0
    19b0:      	ldr	x0, [sp, #0xe60]
    19b4:      	bl	0x19b4 <_stogir.pipeline.prepare-checked+0x10e4>
		00000000000019b4:  ARM64_RELOC_BRANCH26	_stogir.schedule.order-with-uses
    19b8:      	add	x16, sp, #0x840
    19bc:      	ldr	w0, [x16]
    19c0:      	lsr	x16, x0, #0
    19c4:      	cmp	x16, #0x1
    19c8:      	b.eq	0x19e4 <_stogir.pipeline.prepare-checked+0x1114>
    19cc:      	b.lo	0x19d4 <_stogir.pipeline.prepare-checked+0x1104>
    19d0:      	b	0x19e8 <_stogir.pipeline.prepare-checked+0x1118>
    19d4:      	cmp	x16, #0x0
    19d8:      	b.eq	0x19e0 <_stogir.pipeline.prepare-checked+0x1110>
    19dc:      	b	0x19e8 <_stogir.pipeline.prepare-checked+0x1118>
    19e0:      	b	0x1a8c <_stogir.pipeline.prepare-checked+0x11bc>
    19e4:      	b	0x19ec <_stogir.pipeline.prepare-checked+0x111c>
    19e8:      	b	0x1da4 <_stogir.pipeline.prepare-checked+0x14d4>
    19ec:      	add	x0, x28, #0x8
    19f0:      	add	x16, sp, #0x840
    19f4:      	ldr	x21, [x16, #0x8]
    19f8:      	ldr	x26, [x0, #0x8]
    19fc:      	b	0x1a0c <_stogir.pipeline.prepare-checked+0x113c>
    1a00:      	sub	x0, x0, #0x1
    1a04:      	add	x16, sp, #0x790
    1a08:      	str	x0, [x16, #0x8]
    1a0c:      	add	x16, sp, #0x790
    1a10:      	ldr	x0, [x16, #0x8]
    1a14:      	cmp	x0, #0x0
    1a18:      	b.ne	0x1a00 <_stogir.pipeline.prepare-checked+0x1130>
    1a1c:      	add	x16, sp, #0x790
    1a20:      	ldr	x0, [x16, #0x10]
    1a24:      	cmp	x0, #0x0
    1a28:      	b.le	0x1a5c <_stogir.pipeline.prepare-checked+0x118c>
    1a2c:      	add	x1, x24, #0x18
    1a30:      	add	x16, sp, #0x790
    1a34:      	ldr	x2, [x16]
    1a38:      	fmov	d31, x0
    1a3c:      	mov	x0, x1
    1a40:      	mov	x1, x2
    1a44:      	fmov	x2, d31
    1a48:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001a48:  ARM64_RELOC_PAGE21	l_stogir.397
    1a4c:      	ldr	x3, [x3]
		0000000000001a4c:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    1a50:      	mov	x4, #0x4                ; =4
    1a54:      	mov	x5, #0x4                ; =4
    1a58:      	bl	0x1a58 <_stogir.pipeline.prepare-checked+0x1188>
		0000000000001a58:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1a5c:      	add	x16, sp, #0x790
    1a60:      	movz	x17, #0x0, lsl #48
    1a64:      	str	x17, [x16]
    1a68:      	add	x16, sp, #0x790
    1a6c:      	movz	x17, #0x0, lsl #48
    1a70:      	str	x17, [x16, #0x8]
    1a74:      	add	x16, sp, #0x790
    1a78:      	movz	x17, #0x0, lsl #48
    1a7c:      	str	x17, [x16, #0x10]
    1a80:      	b	0x1020 <_stogir.pipeline.prepare-checked+0x750>
    1a84:      	brk	#0
    1a88:      	b	0x1a84 <_stogir.pipeline.prepare-checked+0x11b4>
    1a8c:      	add	x0, x28, #0x8
    1a90:      	add	x16, sp, #0x840
    1a94:      	ldr	x1, [x16, #0x8]
    1a98:      	ldr	x2, [x0, #0x8]
    1a9c:      	ldr	x3, [x0, #0x10]
    1aa0:      	ldr	x4, [x0, #0x18]
    1aa4:      	ldr	x0, [x0, #0x20]
    1aa8:      	add	x16, sp, #0x870
    1aac:      	str	x1, [x16]
    1ab0:      	add	x16, sp, #0x870
    1ab4:      	str	x2, [x16, #0x8]
    1ab8:      	add	x16, sp, #0x870
    1abc:      	str	x3, [x16, #0x10]
    1ac0:      	add	x16, sp, #0x870
    1ac4:      	str	x4, [x16, #0x18]
    1ac8:      	add	x16, sp, #0x870
    1acc:      	str	x0, [x16, #0x20]
    1ad0:      	b	0x1ae4 <_stogir.pipeline.prepare-checked+0x1214>
    1ad4:      	nop
    1ad8:      	sub	x0, x0, #0x1
    1adc:      	add	x16, sp, #0x710
    1ae0:      	str	x0, [x16, #0x8]
    1ae4:      	add	x16, sp, #0x710
    1ae8:      	ldr	x0, [x16, #0x8]
    1aec:      	cmp	x0, #0x0
    1af0:      	b.ne	0x1ad8 <_stogir.pipeline.prepare-checked+0x1208>
    1af4:      	add	x16, sp, #0x710
    1af8:      	ldr	x0, [x16, #0x10]
    1afc:      	cmp	x0, #0x0
    1b00:      	b.le	0x1b34 <_stogir.pipeline.prepare-checked+0x1264>
    1b04:      	add	x1, x23, #0x18
    1b08:      	add	x16, sp, #0x710
    1b0c:      	ldr	x2, [x16]
    1b10:      	fmov	d31, x0
    1b14:      	mov	x0, x1
    1b18:      	mov	x1, x2
    1b1c:      	fmov	x2, d31
    1b20:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001b20:  ARM64_RELOC_PAGE21	l_stogir.399
    1b24:      	ldr	x3, [x3]
		0000000000001b24:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    1b28:      	mov	x4, #0x10               ; =16
    1b2c:      	mov	x5, #0x8                ; =8
    1b30:      	bl	0x1b30 <_stogir.pipeline.prepare-checked+0x1260>
		0000000000001b30:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1b34:      	add	x28, x23, #0x28
    1b38:      	add	x16, sp, #0x710
    1b3c:      	movz	x17, #0x0, lsl #48
    1b40:      	str	x17, [x16]
    1b44:      	add	x16, sp, #0x710
    1b48:      	movz	x17, #0x0, lsl #48
    1b4c:      	str	x17, [x16, #0x8]
    1b50:      	add	x16, sp, #0x710
    1b54:      	movz	x17, #0x0, lsl #48
    1b58:      	str	x17, [x16, #0x10]
    1b5c:      	b	0x1b68 <_stogir.pipeline.prepare-checked+0x1298>
    1b60:      	sub	x0, x0, #0x1
    1b64:      	str	x0, [x28, #0x8]
    1b68:      	ldr	x0, [x28, #0x8]
    1b6c:      	cmp	x0, #0x0
    1b70:      	b.ne	0x1b60 <_stogir.pipeline.prepare-checked+0x1290>
    1b74:      	ldr	x0, [x28, #0x10]
    1b78:      	cmp	x0, #0x0
    1b7c:      	b.le	0x1bb0 <_stogir.pipeline.prepare-checked+0x12e0>
    1b80:      	add	x1, x28, #0x18
    1b84:      	add	x16, sp, #0x710
    1b88:      	ldr	x2, [x16, #0x28]
    1b8c:      	fmov	d31, x0
    1b90:      	mov	x0, x1
    1b94:      	mov	x1, x2
    1b98:      	fmov	x2, d31
    1b9c:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001b9c:  ARM64_RELOC_PAGE21	l_stogir.397
    1ba0:      	ldr	x3, [x3]
		0000000000001ba0:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    1ba4:      	mov	x4, #0x4                ; =4
    1ba8:      	mov	x5, #0x4                ; =4
    1bac:      	bl	0x1bac <_stogir.pipeline.prepare-checked+0x12dc>
		0000000000001bac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1bb0:      	add	x16, sp, #0x870
    1bb4:      	orr	x0, x16, xzr
    1bb8:      	add	x16, sp, #0x710
    1bbc:      	movz	x17, #0x0, lsl #48
    1bc0:      	str	x17, [x16, #0x28]
    1bc4:      	movz	x17, #0x0, lsl #48
    1bc8:      	str	x17, [x28, #0x8]
    1bcc:      	movz	x17, #0x0, lsl #48
    1bd0:      	str	x17, [x28, #0x10]
    1bd4:      	add	x8, sp, #0x8a0
    1bd8:      	mov	x1, x24
    1bdc:      	mov	x2, x25
    1be0:      	ldr	x3, [sp, #0xe80]
    1be4:      	mov	x28, x0
    1be8:      	bl	0x1be8 <_stogir.pipeline.prepare-checked+0x1318>
		0000000000001be8:  ARM64_RELOC_BRANCH26	_stogir.schedule.pack
    1bec:      	add	x16, sp, #0x8a0
    1bf0:      	ldr	x0, [x16]
    1bf4:      	add	x16, sp, #0x710
    1bf8:      	str	x0, [x16]
    1bfc:      	add	x16, sp, #0x8a0
    1c00:      	ldr	x0, [x16, #0x8]
    1c04:      	add	x16, sp, #0x710
    1c08:      	str	x0, [x16, #0x8]
    1c0c:      	add	x16, sp, #0x8a0
    1c10:      	ldr	x0, [x16, #0x10]
    1c14:      	add	x16, sp, #0x710
    1c18:      	str	x0, [x16, #0x10]
    1c1c:      	add	x16, sp, #0x8a0
    1c20:      	ldr	x0, [x16, #0x18]
    1c24:      	add	x16, sp, #0x710
    1c28:      	str	x0, [x16, #0x18]
    1c2c:      	add	x16, sp, #0x8a0
    1c30:      	ldr	x0, [x16, #0x20]
    1c34:      	add	x16, sp, #0x710
    1c38:      	str	x0, [x16, #0x20]
    1c3c:      	add	x16, sp, #0x8a0
    1c40:      	ldr	x0, [x16, #0x28]
    1c44:      	add	x16, sp, #0x710
    1c48:      	str	x0, [x16, #0x28]
    1c4c:      	add	x16, sp, #0x8a0
    1c50:      	ldr	x0, [x16, #0x30]
    1c54:      	add	x16, sp, #0x710
    1c58:      	str	x0, [x16, #0x30]
    1c5c:      	add	x16, sp, #0x8a0
    1c60:      	ldr	x0, [x16, #0x38]
    1c64:      	add	x16, sp, #0x710
    1c68:      	str	x0, [x16, #0x38]
    1c6c:      	add	x16, sp, #0x8a0
    1c70:      	ldr	x0, [x16, #0x40]
    1c74:      	add	x16, sp, #0x710
    1c78:      	str	x0, [x16, #0x40]
    1c7c:      	add	x16, sp, #0x8a0
    1c80:      	ldr	x0, [x16, #0x48]
    1c84:      	add	x16, sp, #0x710
    1c88:      	str	x0, [x16, #0x48]
    1c8c:      	add	x8, sp, #0x8f0
    1c90:      	ldr	x0, [sp, #0xe60]
    1c94:      	mov	x1, x24
    1c98:      	mov	x2, x23
    1c9c:      	ldr	x3, [sp, #0xe80]
    1ca0:      	bl	0x1ca0 <_stogir.pipeline.prepare-checked+0x13d0>
		0000000000001ca0:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.cluster!
    1ca4:      	add	x16, sp, #0x8f0
    1ca8:      	ldr	w0, [x16]
    1cac:      	lsr	x16, x0, #0
    1cb0:      	cmp	x16, #0x1
    1cb4:      	b.eq	0x1cd0 <_stogir.pipeline.prepare-checked+0x1400>
    1cb8:      	b.lo	0x1cc0 <_stogir.pipeline.prepare-checked+0x13f0>
    1cbc:      	b	0x1cd4 <_stogir.pipeline.prepare-checked+0x1404>
    1cc0:      	cmp	x16, #0x0
    1cc4:      	b.eq	0x1ccc <_stogir.pipeline.prepare-checked+0x13fc>
    1cc8:      	b	0x1cd4 <_stogir.pipeline.prepare-checked+0x1404>
    1ccc:      	b	0x1cf0 <_stogir.pipeline.prepare-checked+0x1420>
    1cd0:      	b	0x1cd8 <_stogir.pipeline.prepare-checked+0x1408>
    1cd4:      	b	0x1dac <_stogir.pipeline.prepare-checked+0x14dc>
    1cd8:      	add	x16, sp, #0x8f0
    1cdc:      	orr	x0, x16, xzr
    1ce0:      	add	x0, x0, #0x8
    1ce4:      	add	x16, sp, #0x8f0
    1ce8:      	ldr	x21, [x16, #0x8]
    1cec:      	ldr	x26, [x0, #0x8]
    1cf0:      	b	0x1d04 <_stogir.pipeline.prepare-checked+0x1434>
    1cf4:      	nop
    1cf8:      	sub	x0, x0, #0x1
    1cfc:      	add	x16, sp, #0x870
    1d00:      	str	x0, [x16, #0x8]
    1d04:      	add	x16, sp, #0x870
    1d08:      	ldr	x0, [x16, #0x8]
    1d0c:      	cmp	x0, #0x0
    1d10:      	b.ne	0x1cf8 <_stogir.pipeline.prepare-checked+0x1428>
    1d14:      	add	x16, sp, #0x870
    1d18:      	ldr	x0, [x16, #0x10]
    1d1c:      	cmp	x0, #0x0
    1d20:      	b.le	0x1d54 <_stogir.pipeline.prepare-checked+0x1484>
    1d24:      	add	x1, x28, #0x18
    1d28:      	add	x16, sp, #0x870
    1d2c:      	ldr	x2, [x16]
    1d30:      	fmov	d31, x0
    1d34:      	mov	x0, x1
    1d38:      	mov	x1, x2
    1d3c:      	fmov	x2, d31
    1d40:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001d40:  ARM64_RELOC_PAGE21	l_stogir.397
    1d44:      	ldr	x3, [x3]
		0000000000001d44:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    1d48:      	mov	x4, #0x4                ; =4
    1d4c:      	mov	x5, #0x4                ; =4
    1d50:      	bl	0x1d50 <_stogir.pipeline.prepare-checked+0x1480>
		0000000000001d50:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1d54:      	add	x16, sp, #0x870
    1d58:      	movz	x17, #0x0, lsl #48
    1d5c:      	str	x17, [x16]
    1d60:      	add	x16, sp, #0x870
    1d64:      	movz	x17, #0x0, lsl #48
    1d68:      	str	x17, [x16, #0x8]
    1d6c:      	add	x16, sp, #0x870
    1d70:      	movz	x17, #0x0, lsl #48
    1d74:      	str	x17, [x16, #0x10]
    1d78:      	b	0x19fc <_stogir.pipeline.prepare-checked+0x112c>
    1d7c:      	brk	#0
    1d80:      	b	0x1d7c <_stogir.pipeline.prepare-checked+0x14ac>
    1d84:      	brk	#0
    1d88:      	b	0x1d84 <_stogir.pipeline.prepare-checked+0x14b4>
    1d8c:      	brk	#0
    1d90:      	b	0x1d8c <_stogir.pipeline.prepare-checked+0x14bc>
    1d94:      	brk	#0
    1d98:      	b	0x1d94 <_stogir.pipeline.prepare-checked+0x14c4>
    1d9c:      	brk	#0
    1da0:      	b	0x1d9c <_stogir.pipeline.prepare-checked+0x14cc>
    1da4:      	brk	#0
    1da8:      	b	0x1da4 <_stogir.pipeline.prepare-checked+0x14d4>
    1dac:      	brk	#0
    1db0:      	b	0x1dac <_stogir.pipeline.prepare-checked+0x14dc>
    1db4:      	str	x19, [sp, #0xe58]
    1db8:      	b	0x918 <_stogir.pipeline.prepare-checked+0x48>
    1dbc:      	str	x24, [sp, #0xe80]
    1dc0:      	mov	x24, x1
    1dc4:      	b	0x18a8 <_stogir.pipeline.prepare-checked+0xfd8>
    1dc8:      	str	x28, [sp, #0xe88]
    1dcc:      	b	0x19fc <_stogir.pipeline.prepare-checked+0x112c>

0000000000001dd0 <_stogir.cfg.release!>:
    1dd0:      	sub	sp, sp, #0x30
    1dd4:      	str	x29, [sp]
    1dd8:      	str	x30, [sp, #0x8]
    1ddc:      	mov	x29, sp
    1de0:      	str	x19, [sp, #0x10]
    1de4:      	str	x20, [sp, #0x18]
    1de8:      	str	x21, [sp, #0x20]
    1dec:      	b	0x1df8 <_stogir.cfg.release!+0x28>
    1df0:      	sub	x1, x1, #0x1
    1df4:      	str	x1, [x0, #0x8]
    1df8:      	ldr	x1, [x0, #0x8]
    1dfc:      	cmp	x1, #0x0
    1e00:      	b.ne	0x1df0 <_stogir.cfg.release!+0x20>
    1e04:      	ldr	x1, [x0, #0x10]
    1e08:      	cmp	x1, #0x0
    1e0c:      	b.le	0x1f50 <_stogir.cfg.release!+0x180>
    1e10:      	add	x2, x0, #0x18
    1e14:      	ldr	x3, [x0]
    1e18:      	mov	x19, x0
    1e1c:      	mov	x0, x2
    1e20:      	mov	x2, x1
    1e24:      	mov	x1, x3
    1e28:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001e28:  ARM64_RELOC_PAGE21	l_stogir.400
    1e2c:      	ldr	x3, [x3]
		0000000000001e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    1e30:      	mov	x4, #0x4                ; =4
    1e34:      	mov	x5, #0x4                ; =4
    1e38:      	bl	0x1e38 <_stogir.cfg.release!+0x68>
		0000000000001e38:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1e3c:      	add	x20, x19, #0x28
    1e40:      	movz	x17, #0x0, lsl #48
    1e44:      	str	x17, [x19]
    1e48:      	movz	x17, #0x0, lsl #48
    1e4c:      	str	x17, [x19, #0x8]
    1e50:      	movz	x17, #0x0, lsl #48
    1e54:      	str	x17, [x19, #0x10]
    1e58:      	b	0x1e68 <_stogir.cfg.release!+0x98>
    1e5c:      	nop
    1e60:      	sub	x0, x0, #0x1
    1e64:      	str	x0, [x20, #0x8]
    1e68:      	ldr	x0, [x20, #0x8]
    1e6c:      	cmp	x0, #0x0
    1e70:      	b.ne	0x1e60 <_stogir.cfg.release!+0x90>
    1e74:      	ldr	x0, [x20, #0x10]
    1e78:      	cmp	x0, #0x0
    1e7c:      	b.le	0x1eac <_stogir.cfg.release!+0xdc>
    1e80:      	add	x1, x20, #0x18
    1e84:      	ldr	x2, [x19, #0x28]
    1e88:      	fmov	d31, x0
    1e8c:      	mov	x0, x1
    1e90:      	mov	x1, x2
    1e94:      	fmov	x2, d31
    1e98:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001e98:  ARM64_RELOC_PAGE21	l_stogir.400
    1e9c:      	ldr	x3, [x3]
		0000000000001e9c:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    1ea0:      	mov	x4, #0x4                ; =4
    1ea4:      	mov	x5, #0x4                ; =4
    1ea8:      	bl	0x1ea8 <_stogir.cfg.release!+0xd8>
		0000000000001ea8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1eac:      	add	x21, x19, #0x50
    1eb0:      	movz	x17, #0x0, lsl #48
    1eb4:      	str	x17, [x19, #0x28]
    1eb8:      	movz	x17, #0x0, lsl #48
    1ebc:      	str	x17, [x20, #0x8]
    1ec0:      	movz	x17, #0x0, lsl #48
    1ec4:      	str	x17, [x20, #0x10]
    1ec8:      	b	0x1ed8 <_stogir.cfg.release!+0x108>
    1ecc:      	nop
    1ed0:      	sub	x0, x0, #0x1
    1ed4:      	str	x0, [x21, #0x8]
    1ed8:      	ldr	x0, [x21, #0x8]
    1edc:      	cmp	x0, #0x0
    1ee0:      	b.ne	0x1ed0 <_stogir.cfg.release!+0x100>
    1ee4:      	ldr	x0, [x21, #0x10]
    1ee8:      	cmp	x0, #0x0
    1eec:      	b.le	0x1f1c <_stogir.cfg.release!+0x14c>
    1ef0:      	add	x1, x21, #0x18
    1ef4:      	ldr	x2, [x19, #0x50]
    1ef8:      	fmov	d31, x0
    1efc:      	mov	x0, x1
    1f00:      	mov	x1, x2
    1f04:      	fmov	x2, d31
    1f08:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001f08:  ARM64_RELOC_PAGE21	l_stogir.401
    1f0c:      	ldr	x3, [x3]
		0000000000001f0c:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    1f10:      	mov	x4, #0x10               ; =16
    1f14:      	mov	x5, #0x4                ; =4
    1f18:      	bl	0x1f18 <_stogir.cfg.release!+0x148>
		0000000000001f18:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1f1c:      	movz	x17, #0x0, lsl #48
    1f20:      	str	x17, [x19, #0x50]
    1f24:      	movz	x17, #0x0, lsl #48
    1f28:      	str	x17, [x21, #0x8]
    1f2c:      	movz	x17, #0x0, lsl #48
    1f30:      	str	x17, [x21, #0x10]
    1f34:      	ldr	x19, [sp, #0x10]
    1f38:      	ldr	x20, [sp, #0x18]
    1f3c:      	ldr	x21, [sp, #0x20]
    1f40:      	ldr	x29, [sp]
    1f44:      	ldr	x30, [sp, #0x8]
    1f48:      	add	sp, sp, #0x30
    1f4c:      	ret
    1f50:      	mov	x19, x0
    1f54:      	b	0x1e3c <_stogir.cfg.release!+0x6c>

0000000000001f58 <_inherent$coil.arraylist.ArrayList$free!__i32>:
    1f58:      	sub	sp, sp, #0x20
    1f5c:      	str	x29, [sp]
    1f60:      	str	x30, [sp, #0x8]
    1f64:      	mov	x29, sp
    1f68:      	str	x19, [sp, #0x10]
    1f6c:      	b	0x1f78 <_inherent$coil.arraylist.ArrayList$free!__i32+0x20>
    1f70:      	sub	x1, x1, #0x1
    1f74:      	str	x1, [x0, #0x8]
    1f78:      	ldr	x1, [x0, #0x8]
    1f7c:      	cmp	x1, #0x0
    1f80:      	b.ne	0x1f70 <_inherent$coil.arraylist.ArrayList$free!__i32+0x18>
    1f84:      	ldr	x1, [x0, #0x10]
    1f88:      	cmp	x1, #0x0
    1f8c:      	b.le	0x1fec <_inherent$coil.arraylist.ArrayList$free!__i32+0x94>
    1f90:      	add	x2, x0, #0x18
    1f94:      	ldr	x3, [x0]
    1f98:      	mov	x19, x0
    1f9c:      	mov	x0, x2
    1fa0:      	mov	x2, x1
    1fa4:      	mov	x1, x3
    1fa8:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001fa8:  ARM64_RELOC_PAGE21	l_stogir.402
    1fac:      	ldr	x3, [x3]
		0000000000001fac:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    1fb0:      	mov	x4, #0x4                ; =4
    1fb4:      	mov	x5, #0x4                ; =4
    1fb8:      	bl	0x1fb8 <_inherent$coil.arraylist.ArrayList$free!__i32+0x60>
		0000000000001fb8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1fbc:      	movz	x17, #0x0, lsl #48
    1fc0:      	str	x17, [x19]
    1fc4:      	movz	x17, #0x0, lsl #48
    1fc8:      	str	x17, [x19, #0x8]
    1fcc:      	movz	x17, #0x0, lsl #48
    1fd0:      	str	x17, [x19, #0x10]
    1fd4:      	movz	x0, #0x0, lsl #48
    1fd8:      	ldr	x19, [sp, #0x10]
    1fdc:      	ldr	x29, [sp]
    1fe0:      	ldr	x30, [sp, #0x8]
    1fe4:      	add	sp, sp, #0x20
    1fe8:      	ret
    1fec:      	mov	x19, x0
    1ff0:      	b	0x1fbc <_inherent$coil.arraylist.ArrayList$free!__i32+0x64>
    1ff4:      	udf	#0x0

0000000000001ff8 <_stogir.schedule.release!>:
    1ff8:      	sub	sp, sp, #0x20
    1ffc:      	str	x29, [sp]
    2000:      	str	x30, [sp, #0x8]
    2004:      	mov	x29, sp
    2008:      	str	x19, [sp, #0x10]
    200c:      	str	x20, [sp, #0x18]
    2010:      	b	0x2020 <_stogir.schedule.release!+0x28>
    2014:      	nop
    2018:      	sub	x1, x1, #0x1
    201c:      	str	x1, [x0, #0x8]
    2020:      	ldr	x1, [x0, #0x8]
    2024:      	cmp	x1, #0x0
    2028:      	b.ne	0x2018 <_stogir.schedule.release!+0x20>
    202c:      	ldr	x1, [x0, #0x10]
    2030:      	cmp	x1, #0x0
    2034:      	b.le	0x2104 <_stogir.schedule.release!+0x10c>
    2038:      	add	x2, x0, #0x18
    203c:      	ldr	x3, [x0]
    2040:      	mov	x19, x0
    2044:      	mov	x0, x2
    2048:      	mov	x2, x1
    204c:      	mov	x1, x3
    2050:      	adrp	x3, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002050:  ARM64_RELOC_PAGE21	l_stogir.403
    2054:      	ldr	x3, [x3]
		0000000000002054:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    2058:      	mov	x4, #0x10               ; =16
    205c:      	mov	x5, #0x8                ; =8
    2060:      	bl	0x2060 <_stogir.schedule.release!+0x68>
		0000000000002060:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    2064:      	add	x20, x19, #0x28
    2068:      	movz	x17, #0x0, lsl #48
    206c:      	str	x17, [x19]
    2070:      	movz	x17, #0x0, lsl #48
    2074:      	str	x17, [x19, #0x8]
    2078:      	movz	x17, #0x0, lsl #48
    207c:      	str	x17, [x19, #0x10]
    2080:      	b	0x2090 <_stogir.schedule.release!+0x98>
    2084:      	nop
    2088:      	sub	x0, x0, #0x1
    208c:      	str	x0, [x20, #0x8]
    2090:      	ldr	x0, [x20, #0x8]
    2094:      	cmp	x0, #0x0
    2098:      	b.ne	0x2088 <_stogir.schedule.release!+0x90>
    209c:      	ldr	x0, [x20, #0x10]
    20a0:      	cmp	x0, #0x0
    20a4:      	b.le	0x20d4 <_stogir.schedule.release!+0xdc>
    20a8:      	add	x1, x20, #0x18
    20ac:      	ldr	x2, [x19, #0x28]
    20b0:      	fmov	d31, x0
    20b4:      	mov	x0, x1
    20b8:      	mov	x1, x2
    20bc:      	fmov	x2, d31
    20c0:      	adrp	x3, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000020c0:  ARM64_RELOC_PAGE21	l_stogir.404
    20c4:      	ldr	x3, [x3]
		00000000000020c4:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    20c8:      	mov	x4, #0x4                ; =4
    20cc:      	mov	x5, #0x4                ; =4
    20d0:      	bl	0x20d0 <_stogir.schedule.release!+0xd8>
		00000000000020d0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    20d4:      	movz	x17, #0x0, lsl #48
    20d8:      	str	x17, [x19, #0x28]
    20dc:      	movz	x17, #0x0, lsl #48
    20e0:      	str	x17, [x20, #0x8]
    20e4:      	movz	x17, #0x0, lsl #48
    20e8:      	str	x17, [x20, #0x10]
    20ec:      	ldr	x19, [sp, #0x10]
    20f0:      	ldr	x20, [sp, #0x18]
    20f4:      	ldr	x29, [sp]
    20f8:      	ldr	x30, [sp, #0x8]
    20fc:      	add	sp, sp, #0x20
    2100:      	ret
    2104:      	mov	x19, x0
    2108:      	b	0x2064 <_stogir.schedule.release!+0x6c>

000000000000210c <_stogir.verify.schedule-input>:
    210c:      	sub	sp, sp, #0x80
    2110:      	str	x29, [sp]
    2114:      	str	x30, [sp, #0x8]
    2118:      	mov	x29, sp
    211c:      	str	x19, [sp, #0x50]
    2120:      	str	x20, [sp, #0x58]
    2124:      	str	x21, [sp, #0x60]
    2128:      	str	x22, [sp, #0x68]
    212c:      	str	x23, [sp, #0x70]
    2130:      	mov	x19, x8
    2134:      	add	x8, sp, #0x10
    2138:      	mov	x20, x0
    213c:      	mov	w21, w1
    2140:      	mov	x22, x2
    2144:      	mov	x23, x3
    2148:      	bl	0x2148 <_stogir.verify.schedule-input+0x3c>
		0000000000002148:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    214c:      	add	x16, sp, #0x10
    2150:      	ldr	w0, [x16]
    2154:      	lsr	x16, x0, #0
    2158:      	cmp	x16, #0x1
    215c:      	b.eq	0x2178 <_stogir.verify.schedule-input+0x6c>
    2160:      	b.lo	0x2168 <_stogir.verify.schedule-input+0x5c>
    2164:      	b	0x217c <_stogir.verify.schedule-input+0x70>
    2168:      	cmp	x16, #0x0
    216c:      	b.eq	0x2174 <_stogir.verify.schedule-input+0x68>
    2170:      	b	0x217c <_stogir.verify.schedule-input+0x70>
    2174:      	b	0x21a0 <_stogir.verify.schedule-input+0x94>
    2178:      	b	0x2180 <_stogir.verify.schedule-input+0x74>
    217c:      	b	0x2200 <_stogir.verify.schedule-input+0xf4>
    2180:      	add	x16, sp, #0x10
    2184:      	orr	x0, x16, xzr
    2188:      	add	x0, x0, #0x8
    218c:      	add	x16, sp, #0x10
    2190:      	ldr	x1, [x16, #0x8]
    2194:      	ldr	x0, [x0, #0x8]
    2198:      	mov	x2, #0x1                ; =1
    219c:      	b	0x21d0 <_stogir.verify.schedule-input+0xc4>
    21a0:      	add	x8, sp, #0x30
    21a4:      	mov	x0, x20
    21a8:      	mov	w1, w21
    21ac:      	mov	x2, x22
    21b0:      	mov	x3, x23
    21b4:      	bl	0x21b4 <_stogir.verify.schedule-input+0xa8>
		00000000000021b4:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input-structured
    21b8:      	add	x16, sp, #0x30
    21bc:      	ldr	x2, [x16]
    21c0:      	add	x16, sp, #0x30
    21c4:      	ldr	x1, [x16, #0x8]
    21c8:      	add	x16, sp, #0x30
    21cc:      	ldr	x0, [x16, #0x10]
    21d0:      	str	x2, [x19]
    21d4:      	str	x1, [x19, #0x8]
    21d8:      	str	x0, [x19, #0x10]
    21dc:      	ldr	x19, [sp, #0x50]
    21e0:      	ldr	x20, [sp, #0x58]
    21e4:      	ldr	x21, [sp, #0x60]
    21e8:      	ldr	x22, [sp, #0x68]
    21ec:      	ldr	x23, [sp, #0x70]
    21f0:      	ldr	x29, [sp]
    21f4:      	ldr	x30, [sp, #0x8]
    21f8:      	add	sp, sp, #0x80
    21fc:      	ret
    2200:      	brk	#0
    2204:      	b	0x2200 <_stogir.verify.schedule-input+0xf4>

0000000000002208 <_stogir.graph.contains?>:
    2208:      	sxtw	x1, w1
    220c:      	cmp	x1, #0x0
    2210:      	b.le	0x2250 <_stogir.graph.contains?+0x48>
    2214:      	ldr	x2, [x0, #0x8]
    2218:      	cmp	x1, x2
    221c:      	b.ge	0x22ac <_stogir.graph.contains?+0xa4>
    2220:      	add	x2, x0, #0x78
    2224:      	ldr	x2, [x2, #0x8]
    2228:      	cmp	x1, x2
    222c:      	b.ge	0x22bc <_stogir.graph.contains?+0xb4>
    2230:      	ldr	x0, [x0, #0x78]
    2234:      	add	x0, x0, x1, lsl #2
    2238:      	ldr	w0, [x0]
    223c:      	sxtw	x0, w0
    2240:      	cmp	x0, #0x0
    2244:      	cset	w0, ge
    2248:      	ubfx	x0, x0, #0, #8
    224c:      	b	0x22c0 <_stogir.graph.contains?+0xb8>
    2250:      	cmp	x1, #0x0
    2254:      	b.ge	0x22b4 <_stogir.graph.contains?+0xac>
    2258:      	add	x2, x0, #0x28
    225c:      	add	x3, x0, #0x50
    2260:      	ldr	x2, [x2, #0x8]
    2264:      	ldr	x3, [x3, #0x8]
    2268:      	cmp	x2, x3
    226c:      	b.ne	0x22cc <_stogir.graph.contains?+0xc4>
    2270:      	movz	x16, #0x0, lsl #48
    2274:      	sub	x3, x16, x1
    2278:      	cmp	x3, x2
    227c:      	b.gt	0x22c4 <_stogir.graph.contains?+0xbc>
    2280:      	movz	x16, #0x0, lsl #48
    2284:      	sub	x1, x16, x1
    2288:      	sub	x1, x1, #0x1
    228c:      	ldr	x0, [x0, #0x50]
    2290:      	add	x0, x0, x1, lsl #2
    2294:      	ldr	w0, [x0]
    2298:      	sxtw	x0, w0
    229c:      	cmp	x0, #0x0
    22a0:      	cset	w0, gt
    22a4:      	ubfx	x0, x0, #0, #8
    22a8:      	b	0x22c8 <_stogir.graph.contains?+0xc0>
    22ac:      	movz	x0, #0x0, lsl #48
    22b0:      	b	0x22c0 <_stogir.graph.contains?+0xb8>
    22b4:      	movz	x0, #0x0, lsl #48
    22b8:      	b	0x22c8 <_stogir.graph.contains?+0xc0>
    22bc:      	movz	x0, #0x0, lsl #48
    22c0:      	b	0x22c8 <_stogir.graph.contains?+0xc0>
    22c4:      	movz	x0, #0x0, lsl #48
    22c8:      	ret
    22cc:      	movz	x0, #0x0, lsl #48
    22d0:      	b	0x22c8 <_stogir.graph.contains?+0xc0>
    22d4:      	udf	#0x0

00000000000022d8 <_stogir.cfg.build>:
    22d8:      	sub	sp, sp, #0x2e0
    22dc:      	str	x29, [sp, #0x10]
    22e0:      	str	x30, [sp, #0x18]
    22e4:      	add	x29, sp, #0x10
    22e8:      	str	x19, [sp, #0x288]
    22ec:      	str	x20, [sp, #0x290]
    22f0:      	str	x21, [sp, #0x298]
    22f4:      	str	x22, [sp, #0x2a0]
    22f8:      	str	x23, [sp, #0x2a8]
    22fc:      	str	x24, [sp, #0x2b0]
    2300:      	str	x25, [sp, #0x2b8]
    2304:      	str	x26, [sp, #0x2c0]
    2308:      	str	x27, [sp, #0x2c8]
    230c:      	str	x28, [sp, #0x2d0]
    2310:      	mov	x19, x8
    2314:      	add	x8, sp, #0x20
    2318:      	mov	x20, x0
    231c:      	mov	x21, x1
    2320:      	bl	0x2320 <_stogir.cfg.build+0x48>
		0000000000002320:  ARM64_RELOC_BRANCH26	_stogir.verify.control-sources
    2324:      	add	x16, sp, #0x20
    2328:      	ldr	w0, [x16]
    232c:      	lsr	x16, x0, #0
    2330:      	cmp	x16, #0x1
    2334:      	b.eq	0x2350 <_stogir.cfg.build+0x78>
    2338:      	b.lo	0x2340 <_stogir.cfg.build+0x68>
    233c:      	b	0x2354 <_stogir.cfg.build+0x7c>
    2340:      	cmp	x16, #0x0
    2344:      	b.eq	0x234c <_stogir.cfg.build+0x74>
    2348:      	b	0x2354 <_stogir.cfg.build+0x7c>
    234c:      	b	0x279c <_stogir.cfg.build+0x4c4>
    2350:      	b	0x2358 <_stogir.cfg.build+0x80>
    2354:      	b	0x2e20 <_stogir.cfg.build+0xb48>
    2358:      	add	x16, sp, #0x20
    235c:      	orr	x0, x16, xzr
    2360:      	add	x0, x0, #0x8
    2364:      	add	x16, sp, #0x20
    2368:      	ldr	x21, [x16, #0x8]
    236c:      	ldr	x22, [x0, #0x8]
    2370:      	str	x19, [sp, #0x250]
    2374:      	mov	x13, #0x1               ; =1
    2378:      	movz	x0, #0x0, lsl #48
    237c:      	movz	x1, #0x0, lsl #48
    2380:      	movz	x2, #0x0, lsl #48
    2384:      	movz	x3, #0x0, lsl #48
    2388:      	movz	x4, #0x0, lsl #48
    238c:      	movz	x5, #0x0, lsl #48
    2390:      	movz	x6, #0x0, lsl #48
    2394:      	movz	x7, #0x0, lsl #48
    2398:      	movz	x8, #0x0, lsl #48
    239c:      	movz	x9, #0x0, lsl #48
    23a0:      	movz	x10, #0x0, lsl #48
    23a4:      	movz	x11, #0x0, lsl #48
    23a8:      	movz	x12, #0x0, lsl #48
    23ac:      	b	0x2720 <_stogir.cfg.build+0x448>
    23b0:      	sub	w3, w2, #0x1
    23b4:      	lsl	w3, w3, #2
    23b8:      	ubfx	x3, x3, #0, #32
    23bc:      	lsr	x3, x4, x3
    23c0:      	and	w3, w3, #0xf
    23c4:      	b	0x247c <_stogir.cfg.build+0x1a4>
    23c8:      	lsl	x2, x2, #1
    23cc:      	str	x23, [sp, #0x258]
    23d0:      	mov	x23, x0
    23d4:      	mov	x0, x24
    23d8:      	str	w25, [sp, #0x280]
    23dc:      	mov	x25, x1
    23e0:      	mov	x1, x2
    23e4:      	bl	0x23e4 <_stogir.cfg.build+0x10c>
		00000000000023e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge
    23e8:      	add	x0, x25, #0x1
    23ec:      	add	x16, sp, #0x40
    23f0:      	ldr	x1, [x16, #0x50]
    23f4:      	add	x1, x1, x25, lsl #4
    23f8:      	str	x20, [x1]
    23fc:      	str	x23, [x1, #0x8]
    2400:      	str	x0, [x24, #0x8]
    2404:      	add	x0, x19, #0x1
    2408:      	sxtw	x19, w0
    240c:      	ldr	x20, [sp, #0x260]
    2410:      	ldr	x23, [sp, #0x258]
    2414:      	ldr	x0, [sp, #0x270]
    2418:      	ldr	w25, [sp, #0x280]
    241c:      	mov	x1, x19
    2420:      	ldr	x19, [sp, #0x278]
    2424:      	cmp	x22, #0x0
    2428:      	b.ne	0x243c <_stogir.cfg.build+0x164>
    242c:      	cmp	x1, x0
    2430:      	cset	w2, le
    2434:      	ubfx	x2, x2, #0, #8
    2438:      	b	0x2440 <_stogir.cfg.build+0x168>
    243c:      	movz	x2, #0x0, lsl #48
    2440:      	cmp	x2, #0x0
    2444:      	b.eq	0x2e28 <_stogir.cfg.build+0xb50>
    2448:      	orr	w2, w1, wzr
    244c:      	uxtb	w16, w27
    2450:      	cmp	w16, wzr
    2454:      	b.eq	0x2480 <_stogir.cfg.build+0x1a8>
    2458:      	sxtw	x3, w2
    245c:      	ldr	w4, [x28]
    2460:      	cmp	x3, #0x0
    2464:      	b.le	0x2478 <_stogir.cfg.build+0x1a0>
    2468:      	cmp	x3, #0x4
    246c:      	b.le	0x23b0 <_stogir.cfg.build+0xd8>
    2470:      	mov	w3, #0x4                ; =4
    2474:      	b	0x23b4 <_stogir.cfg.build+0xdc>
    2478:      	movz	w3, #0x0, lsl #16
    247c:      	b	0x2484 <_stogir.cfg.build+0x1ac>
    2480:      	movz	w3, #0x0, lsl #16
    2484:      	adrp	x16, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002484:  ARM64_RELOC_PAGE21	l_stogir.405
    2488:      	ldr	x16, [x16]
		0000000000002488:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    248c:      	ldr	w4, [x16]
    2490:      	ubfx	x3, x3, #0, #32
    2494:      	cmp	x3, x4
    2498:      	b.ne	0x2e38 <_stogir.cfg.build+0xb60>
    249c:      	str	x0, [sp, #0x270]
    24a0:      	mov	x0, x20
    24a4:      	str	x19, [sp, #0x278]
    24a8:      	mov	x19, x1
    24ac:      	mov	w1, w25
    24b0:      	str	x20, [sp, #0x260]
    24b4:      	mov	w20, w2
    24b8:      	bl	0x24b8 <_stogir.cfg.build+0x1e0>
		00000000000024b8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    24bc:      	ubfx	x0, x0, #0, #32
    24c0:      	lsr	x16, x0, #0
    24c4:      	cmp	x16, #0x1
    24c8:      	b.eq	0x24e4 <_stogir.cfg.build+0x20c>
    24cc:      	b.lo	0x24d4 <_stogir.cfg.build+0x1fc>
    24d0:      	b	0x24e8 <_stogir.cfg.build+0x210>
    24d4:      	cmp	x16, #0x0
    24d8:      	b.eq	0x24e0 <_stogir.cfg.build+0x208>
    24dc:      	b	0x24e8 <_stogir.cfg.build+0x210>
    24e0:      	b	0x24ec <_stogir.cfg.build+0x214>
    24e4:      	b	0x2504 <_stogir.cfg.build+0x22c>
    24e8:      	b	0x2e10 <_stogir.cfg.build+0xb38>
    24ec:      	str	x23, [sp, #0x258]
    24f0:      	str	w25, [sp, #0x280]
    24f4:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000024f4:  ARM64_RELOC_PAGE21	l_stogir.406
    24f8:      	ldr	x21, [x21]
		00000000000024f8:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    24fc:      	mov	x22, #0x19              ; =25
    2500:      	b	0x2404 <_stogir.cfg.build+0x12c>
    2504:      	add	x16, sp, #0x40
    2508:      	ldr	x0, [x16, #0x28]
    250c:      	sxtw	x2, w1
    2510:      	add	x0, x0, x2, lsl #2
    2514:      	ldr	w0, [x0]
    2518:      	sxtw	x2, w0
    251c:      	cmp	x2, #0x0
    2520:      	b.ne	0x2678 <_stogir.cfg.build+0x3a0>
    2524:      	str	x23, [sp, #0x258]
    2528:      	str	w25, [sp, #0x280]
    252c:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		000000000000252c:  ARM64_RELOC_PAGE21	l_stogir.407
    2530:      	ldr	x21, [x21]
		0000000000002530:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2534:      	mov	x22, #0x1e              ; =30
    2538:      	b	0x2404 <_stogir.cfg.build+0x12c>
    253c:      	ldr	x20, [sp, #0x260]
    2540:      	ldr	x23, [sp, #0x258]
    2544:      	ldr	x19, [sp, #0x278]
    2548:      	mov	x0, x19
    254c:      	bl	0x254c <_stogir.cfg.build+0x274>
		000000000000254c:  ARM64_RELOC_BRANCH26	_coil.core.Iterator$coil.slice.SliceIter$next__i32
    2550:      	ubfx	x0, x0, #0, #32
    2554:      	lsr	x16, x0, #0
    2558:      	cmp	x16, #0x1
    255c:      	b.eq	0x257c <_stogir.cfg.build+0x2a4>
    2560:      	b.lo	0x2568 <_stogir.cfg.build+0x290>
    2564:      	b	0x2580 <_stogir.cfg.build+0x2a8>
    2568:      	cmp	x16, #0x0
    256c:      	b.eq	0x2574 <_stogir.cfg.build+0x29c>
    2570:      	b	0x2580 <_stogir.cfg.build+0x2a8>
    2574:      	str	x23, [sp, #0x258]
    2578:      	b	0x25d0 <_stogir.cfg.build+0x2f8>
    257c:      	b	0x2584 <_stogir.cfg.build+0x2ac>
    2580:      	b	0x2e18 <_stogir.cfg.build+0xb40>
    2584:      	ldr	x0, [x20]
    2588:      	sxtw	x2, w1
    258c:      	orr	w25, w1, wzr
    2590:      	orr	w26, w1, wzr
    2594:      	add	x0, x0, x2, lsl #4
    2598:      	ldr	x0, [x0]
    259c:      	ldr	x1, [x20, #0x78]
    25a0:      	uxtb	w0, w0
    25a4:      	add	x1, x1, x2, lsl #2
    25a8:      	cmp	x0, #0x83
    25ac:      	cset	w27, lt
    25b0:      	adrp	x16, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000025b0:  ARM64_RELOC_PAGE21	l_stogir.408
    25b4:      	ldr	x16, [x16]
		00000000000025b4:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    25b8:      	add	x0, x16, x0, lsl #2
    25bc:      	ldr	w1, [x1]
    25c0:      	orr	x28, x0, xzr
    25c4:      	sxtw	x0, w1
    25c8:      	mov	x1, #0x1                ; =1
    25cc:      	b	0x2424 <_stogir.cfg.build+0x14c>
    25d0:      	ldr	x0, [sp, #0x268]
    25d4:      	bl	0x25d4 <_stogir.cfg.build+0x2fc>
		00000000000025d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    25d8:      	mov	x0, x21
    25dc:      	mov	x1, x22
    25e0:      	adrp	x2, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000025e0:  ARM64_RELOC_PAGE21	l_stogir.409
    25e4:      	ldr	x2, [x2]
		00000000000025e4:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    25e8:      	movz	x3, #0x0, lsl #48
    25ec:      	bl	0x25ec <_stogir.cfg.build+0x314>
		00000000000025ec:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    25f0:      	cmp	x0, #0x0
    25f4:      	b.eq	0x26e0 <_stogir.cfg.build+0x408>
    25f8:      	add	x16, sp, #0x40
    25fc:      	ldr	x21, [x16]
    2600:      	add	x16, sp, #0x40
    2604:      	ldr	x22, [x16, #0x8]
    2608:      	add	x16, sp, #0x40
    260c:      	ldr	x0, [x16, #0x10]
    2610:      	add	x16, sp, #0x40
    2614:      	ldr	x1, [x16, #0x18]
    2618:      	add	x16, sp, #0x40
    261c:      	ldr	x2, [x16, #0x20]
    2620:      	add	x16, sp, #0x40
    2624:      	ldr	x3, [x16, #0x28]
    2628:      	add	x16, sp, #0x40
    262c:      	ldr	x4, [x16, #0x30]
    2630:      	add	x16, sp, #0x40
    2634:      	ldr	x5, [x16, #0x38]
    2638:      	add	x16, sp, #0x40
    263c:      	ldr	x6, [x16, #0x40]
    2640:      	add	x16, sp, #0x40
    2644:      	ldr	x7, [x16, #0x48]
    2648:      	add	x16, sp, #0x40
    264c:      	ldr	x8, [x16, #0x50]
    2650:      	add	x16, sp, #0x40
    2654:      	ldr	x9, [x16, #0x58]
    2658:      	add	x16, sp, #0x40
    265c:      	ldr	x10, [x16, #0x60]
    2660:      	add	x16, sp, #0x40
    2664:      	ldr	x11, [x16, #0x68]
    2668:      	add	x16, sp, #0x40
    266c:      	ldr	x12, [x16, #0x70]
    2670:      	movz	x13, #0x0, lsl #48
    2674:      	b	0x2720 <_stogir.cfg.build+0x448>
    2678:      	add	x16, sp, #0x210
    267c:      	movz	x17, #0x0, lsl #48
    2680:      	str	x17, [x16]
    2684:      	add	x16, sp, #0x210
    2688:      	movz	x17, #0x0, lsl #48
    268c:      	str	x17, [x16, #0x8]
    2690:      	add	x16, sp, #0x210
    2694:      	str	w0, [x16]
    2698:      	add	x16, sp, #0x210
    269c:      	str	w26, [x16, #0x4]
    26a0:      	add	x16, sp, #0x210
    26a4:      	str	w1, [x16, #0x8]
    26a8:      	add	x16, sp, #0x210
    26ac:      	str	w20, [x16, #0xc]
    26b0:      	add	x16, sp, #0x210
    26b4:      	ldr	x20, [x16]
    26b8:      	add	x16, sp, #0x210
    26bc:      	ldr	x0, [x16, #0x8]
    26c0:      	ldr	x1, [x24, #0x8]
    26c4:      	ldr	x2, [x24, #0x10]
    26c8:      	cmp	x1, x2
    26cc:      	b.lt	0x2e54 <_stogir.cfg.build+0xb7c>
    26d0:      	cmp	x2, #0x0
    26d4:      	b.ne	0x23c8 <_stogir.cfg.build+0xf0>
    26d8:      	mov	x2, #0x2                ; =2
    26dc:      	b	0x23cc <_stogir.cfg.build+0xf4>
    26e0:      	ldr	x0, [sp, #0x258]
    26e4:      	bl	0x26e4 <_stogir.cfg.build+0x40c>
		00000000000026e4:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    26e8:      	mov	x13, #0x1               ; =1
    26ec:      	movz	x0, #0x0, lsl #48
    26f0:      	movz	x1, #0x0, lsl #48
    26f4:      	movz	x2, #0x0, lsl #48
    26f8:      	movz	x3, #0x0, lsl #48
    26fc:      	movz	x4, #0x0, lsl #48
    2700:      	movz	x5, #0x0, lsl #48
    2704:      	movz	x6, #0x0, lsl #48
    2708:      	movz	x7, #0x0, lsl #48
    270c:      	movz	x8, #0x0, lsl #48
    2710:      	movz	x9, #0x0, lsl #48
    2714:      	movz	x10, #0x0, lsl #48
    2718:      	movz	x11, #0x0, lsl #48
    271c:      	movz	x12, #0x0, lsl #48
    2720:      	ldr	x14, [sp, #0x250]
    2724:      	str	x13, [x14]
    2728:      	str	x21, [x14, #0x8]
    272c:      	str	x22, [x14, #0x10]
    2730:      	str	x0, [x14, #0x18]
    2734:      	str	x1, [x14, #0x20]
    2738:      	str	x2, [x14, #0x28]
    273c:      	str	x3, [x14, #0x30]
    2740:      	str	x4, [x14, #0x38]
    2744:      	str	x5, [x14, #0x40]
    2748:      	str	x6, [x14, #0x48]
    274c:      	str	x7, [x14, #0x50]
    2750:      	str	x8, [x14, #0x58]
    2754:      	str	x9, [x14, #0x60]
    2758:      	str	x10, [x14, #0x68]
    275c:      	str	x11, [x14, #0x70]
    2760:      	str	x12, [x14, #0x78]
    2764:      	ldr	x19, [sp, #0x288]
    2768:      	ldr	x20, [sp, #0x290]
    276c:      	ldr	x21, [sp, #0x298]
    2770:      	ldr	x22, [sp, #0x2a0]
    2774:      	ldr	x23, [sp, #0x2a8]
    2778:      	ldr	x24, [sp, #0x2b0]
    277c:      	ldr	x25, [sp, #0x2b8]
    2780:      	ldr	x26, [sp, #0x2c0]
    2784:      	ldr	x27, [sp, #0x2c8]
    2788:      	ldr	x28, [sp, #0x2d0]
    278c:      	ldr	x29, [sp, #0x10]
    2790:      	ldr	x30, [sp, #0x18]
    2794:      	add	sp, sp, #0x2e0
    2798:      	ret
    279c:      	add	x16, sp, #0x40
    27a0:      	orr	x23, x16, xzr
    27a4:      	add	x8, sp, #0xc0
    27a8:      	mov	x0, x21
    27ac:      	bl	0x27ac <_stogir.cfg.build+0x4d4>
		00000000000027ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    27b0:      	add	x22, x23, #0x28
    27b4:      	add	x16, sp, #0xc0
    27b8:      	ldr	x24, [x16]
    27bc:      	add	x16, sp, #0xc0
    27c0:      	ldr	x25, [x16, #0x8]
    27c4:      	add	x16, sp, #0xc0
    27c8:      	ldr	x26, [x16, #0x10]
    27cc:      	add	x16, sp, #0xc0
    27d0:      	ldr	x27, [x16, #0x18]
    27d4:      	add	x16, sp, #0xc0
    27d8:      	ldr	x28, [x16, #0x20]
    27dc:      	add	x8, sp, #0xf0
    27e0:      	mov	x0, x21
    27e4:      	bl	0x27e4 <_stogir.cfg.build+0x50c>
		00000000000027e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    27e8:      	add	x16, sp, #0xf0
    27ec:      	ldr	x0, [x16]
    27f0:      	add	x16, sp, #0xf0
    27f4:      	ldr	x1, [x16, #0x8]
    27f8:      	add	x16, sp, #0xf0
    27fc:      	ldr	x2, [x16, #0x10]
    2800:      	add	x16, sp, #0xf0
    2804:      	ldr	x3, [x16, #0x18]
    2808:      	add	x16, sp, #0xf0
    280c:      	ldr	x4, [x16, #0x20]
    2810:      	add	x8, sp, #0x120
    2814:      	str	x21, [sp, #0x240]
    2818:      	str	x22, [sp, #0x248]
    281c:      	mov	x22, x1
    2820:      	str	x19, [sp, #0x250]
    2824:      	mov	x19, x2
    2828:      	str	x23, [sp, #0x258]
    282c:      	mov	x23, x3
    2830:      	str	x20, [sp, #0x260]
    2834:      	mov	x20, x4
    2838:      	fmov	d31, x0
    283c:      	mov	x0, x21
    2840:      	fmov	x21, d31
    2844:      	bl	0x2844 <_stogir.cfg.build+0x56c>
		0000000000002844:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge
    2848:      	add	x16, sp, #0x120
    284c:      	ldr	x0, [x16]
    2850:      	add	x16, sp, #0x120
    2854:      	ldr	x1, [x16, #0x8]
    2858:      	add	x16, sp, #0x120
    285c:      	ldr	x2, [x16, #0x10]
    2860:      	add	x16, sp, #0x120
    2864:      	ldr	x3, [x16, #0x18]
    2868:      	add	x16, sp, #0x120
    286c:      	ldr	x4, [x16, #0x20]
    2870:      	add	x16, sp, #0x40
    2874:      	str	x24, [x16]
    2878:      	add	x16, sp, #0x40
    287c:      	str	x25, [x16, #0x8]
    2880:      	add	x16, sp, #0x40
    2884:      	str	x26, [x16, #0x10]
    2888:      	add	x16, sp, #0x40
    288c:      	str	x27, [x16, #0x18]
    2890:      	add	x16, sp, #0x40
    2894:      	str	x28, [x16, #0x20]
    2898:      	add	x16, sp, #0x40
    289c:      	str	x21, [x16, #0x28]
    28a0:      	add	x16, sp, #0x40
    28a4:      	str	x22, [x16, #0x30]
    28a8:      	add	x16, sp, #0x40
    28ac:      	str	x19, [x16, #0x38]
    28b0:      	add	x16, sp, #0x40
    28b4:      	str	x23, [x16, #0x40]
    28b8:      	add	x16, sp, #0x40
    28bc:      	str	x20, [x16, #0x48]
    28c0:      	add	x16, sp, #0x40
    28c4:      	str	x0, [x16, #0x50]
    28c8:      	add	x16, sp, #0x40
    28cc:      	str	x1, [x16, #0x58]
    28d0:      	add	x16, sp, #0x40
    28d4:      	str	x2, [x16, #0x60]
    28d8:      	add	x16, sp, #0x40
    28dc:      	str	x3, [x16, #0x68]
    28e0:      	add	x16, sp, #0x40
    28e4:      	str	x4, [x16, #0x70]
    28e8:      	add	x8, sp, #0x180
    28ec:      	ldr	x0, [sp, #0x240]
    28f0:      	bl	0x28f0 <_stogir.cfg.build+0x618>
		00000000000028f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    28f4:      	add	x16, sp, #0x180
    28f8:      	ldr	x0, [x16]
    28fc:      	add	x16, sp, #0x150
    2900:      	str	x0, [x16]
    2904:      	add	x16, sp, #0x180
    2908:      	ldr	x0, [x16, #0x8]
    290c:      	add	x16, sp, #0x150
    2910:      	str	x0, [x16, #0x8]
    2914:      	add	x16, sp, #0x180
    2918:      	ldr	x0, [x16, #0x10]
    291c:      	add	x16, sp, #0x150
    2920:      	str	x0, [x16, #0x10]
    2924:      	add	x16, sp, #0x180
    2928:      	ldr	x0, [x16, #0x18]
    292c:      	add	x16, sp, #0x150
    2930:      	str	x0, [x16, #0x18]
    2934:      	add	x16, sp, #0x180
    2938:      	ldr	x0, [x16, #0x20]
    293c:      	add	x16, sp, #0x150
    2940:      	str	x0, [x16, #0x20]
    2944:      	ldr	x0, [sp, #0x260]
    2948:      	bl	0x2948 <_stogir.cfg.build+0x670>
		0000000000002948:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    294c:      	mov	x1, x0
    2950:      	ldr	x0, [sp, #0x248]
    2954:      	bl	0x2954 <_stogir.cfg.build+0x67c>
		0000000000002954:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    2958:      	mov	x19, #0x1               ; =1
    295c:      	b	0x29a4 <_stogir.cfg.build+0x6cc>
    2960:      	orr	w0, w19, wzr
    2964:      	orr	w22, w0, wzr
    2968:      	ldr	x0, [sp, #0x258]
    296c:      	mov	w1, w22
    2970:      	bl	0x2970 <_stogir.cfg.build+0x698>
		0000000000002970:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    2974:      	add	x16, sp, #0x40
    2978:      	ldr	x0, [x16, #0x28]
    297c:      	add	x0, x0, x19, lsl #2
    2980:      	str	w22, [x0]
    2984:      	sxtw	x21, w21
    2988:      	add	x0, x21, #0x4
    298c:      	asr	x16, x0, #63
    2990:      	lsr	x16, x16, #62
    2994:      	add	x0, x0, x16
    2998:      	asr	x0, x0, #2
    299c:      	add	x19, x0, x19
    29a0:      	str	x20, [sp, #0x260]
    29a4:      	ldr	x20, [sp, #0x260]
    29a8:      	ldr	x0, [x20, #0x8]
    29ac:      	cmp	x19, x0
    29b0:      	b.ge	0x29e0 <_stogir.cfg.build+0x708>
    29b4:      	ldr	x0, [x20]
    29b8:      	add	x0, x0, x19, lsl #4
    29bc:      	ldr	x0, [x0]
    29c0:      	ldr	x1, [x20, #0x78]
    29c4:      	uxtb	w0, w0
    29c8:      	add	x1, x1, x19, lsl #2
    29cc:      	ldr	w21, [x1]
    29d0:      	bl	0x29d0 <_stogir.cfg.build+0x6f8>
		00000000000029d0:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-start?
    29d4:      	cmp	x0, #0x0
    29d8:      	b.ne	0x2960 <_stogir.cfg.build+0x688>
    29dc:      	b	0x2984 <_stogir.cfg.build+0x6ac>
    29e0:      	add	x16, sp, #0x150
    29e4:      	orr	x19, x16, xzr
    29e8:      	add	x23, x20, #0x78
    29ec:      	add	x24, x20, #0x78
    29f0:      	mov	x25, #0x1               ; =1
    29f4:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000029f4:  ARM64_RELOC_PAGE21	l_stogir.409
    29f8:      	ldr	x21, [x21]
		00000000000029f8:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    29fc:      	movz	x22, #0x0, lsl #48
    2a00:      	b	0x2aa4 <_stogir.cfg.build+0x7cc>
    2a04:      	movz	w1, #0x0, lsl #16
    2a08:      	movz	w0, #0x0, lsl #16
    2a0c:      	b	0x2c60 <_stogir.cfg.build+0x988>
    2a10:      	movz	w3, #0x0, lsl #16
    2a14:      	movz	w4, #0x0, lsl #16
    2a18:      	ubfx	x3, x3, #0, #32
    2a1c:      	lsr	x16, x3, #0
    2a20:      	cmp	x16, #0x1
    2a24:      	b.eq	0x2a40 <_stogir.cfg.build+0x768>
    2a28:      	b.lo	0x2a30 <_stogir.cfg.build+0x758>
    2a2c:      	b	0x2a44 <_stogir.cfg.build+0x76c>
    2a30:      	cmp	x16, #0x0
    2a34:      	b.eq	0x2a3c <_stogir.cfg.build+0x764>
    2a38:      	b	0x2a44 <_stogir.cfg.build+0x76c>
    2a3c:      	b	0x2a84 <_stogir.cfg.build+0x7ac>
    2a40:      	b	0x2a48 <_stogir.cfg.build+0x770>
    2a44:      	b	0x2e00 <_stogir.cfg.build+0xb28>
    2a48:      	sxtw	x4, w4
    2a4c:      	add	x16, sp, #0x40
    2a50:      	ldr	x3, [x16, #0x28]
    2a54:      	add	x3, x3, x4, lsl #2
    2a58:      	str	w28, [x3]
    2a5c:      	cmp	x2, x1
    2a60:      	b.ge	0x2a10 <_stogir.cfg.build+0x738>
    2a64:      	add	x3, x2, #0x1
    2a68:      	add	x2, x0, x2, lsl #2
    2a6c:      	ldr	w2, [x2]
    2a70:      	movn	w17, #0x0, lsl #16
    2a74:      	and	w4, w2, w17
    2a78:      	mov	x2, x3
    2a7c:      	mov	w3, #0x1                ; =1
    2a80:      	b	0x2a18 <_stogir.cfg.build+0x740>
    2a84:      	sxtw	x26, w26
    2a88:      	add	x0, x26, #0x4
    2a8c:      	asr	x16, x0, #63
    2a90:      	lsr	x16, x16, #62
    2a94:      	add	x0, x0, x16
    2a98:      	asr	x0, x0, #2
    2a9c:      	add	x25, x0, x25
    2aa0:      	ldr	x19, [sp, #0x268]
    2aa4:      	cmp	x22, #0x0
    2aa8:      	b.ne	0x2ac0 <_stogir.cfg.build+0x7e8>
    2aac:      	ldr	x0, [x20, #0x8]
    2ab0:      	cmp	x25, x0
    2ab4:      	cset	w0, lt
    2ab8:      	ubfx	x0, x0, #0, #8
    2abc:      	b	0x2ac4 <_stogir.cfg.build+0x7ec>
    2ac0:      	movz	x0, #0x0, lsl #48
    2ac4:      	cmp	x0, #0x0
    2ac8:      	b.eq	0x2e68 <_stogir.cfg.build+0xb90>
    2acc:      	ldr	x0, [x20]
    2ad0:      	add	x0, x0, x25, lsl #4
    2ad4:      	ldr	x0, [x0]
    2ad8:      	ldr	x1, [x20, #0x78]
    2adc:      	uxtb	w0, w0
    2ae0:      	add	x1, x1, x25, lsl #2
    2ae4:      	ldr	w26, [x1]
    2ae8:      	bl	0x2ae8 <_stogir.cfg.build+0x810>
		0000000000002ae8:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    2aec:      	cmp	x0, #0x0
    2af0:      	b.eq	0x2b18 <_stogir.cfg.build+0x840>
    2af4:      	add	x16, sp, #0x40
    2af8:      	ldr	x0, [x16, #0x28]
    2afc:      	add	x0, x0, x25, lsl #2
    2b00:      	ldr	w0, [x0]
    2b04:      	sxtw	x0, w0
    2b08:      	cmp	x0, #0x0
    2b0c:      	cset	w0, eq
    2b10:      	ubfx	x0, x0, #0, #8
    2b14:      	b	0x2b1c <_stogir.cfg.build+0x844>
    2b18:      	movz	x0, #0x0, lsl #48
    2b1c:      	cmp	x0, #0x0
    2b20:      	b.eq	0x2e70 <_stogir.cfg.build+0xb98>
    2b24:      	orr	w27, w25, wzr
    2b28:      	mov	x0, x19
    2b2c:      	bl	0x2b2c <_stogir.cfg.build+0x854>
		0000000000002b2c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$clear!__i32
    2b30:      	sxtw	x27, w27
    2b34:      	movz	x28, #0x0, lsl #48
    2b38:      	b	0x2ba0 <_stogir.cfg.build+0x8c8>
    2b3c:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002b3c:  ARM64_RELOC_PAGE21	l_stogir.410
    2b40:      	ldr	x21, [x21]
		0000000000002b40:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    2b44:      	mov	x22, #0x1b              ; =27
    2b48:      	b	0x2b9c <_stogir.cfg.build+0x8c4>
    2b4c:      	nop
    2b50:      	movz	x0, #0x0, lsl #48
    2b54:      	cmp	x0, #0x0
    2b58:      	b.eq	0x2e78 <_stogir.cfg.build+0xba0>
    2b5c:      	add	x16, sp, #0x40
    2b60:      	ldr	x0, [x16, #0x28]
    2b64:      	add	x0, x0, x27, lsl #2
    2b68:      	ldr	w0, [x0]
    2b6c:      	sxtw	x28, w0
    2b70:      	cmp	x28, #0x0
    2b74:      	b.ne	0x2e80 <_stogir.cfg.build+0xba8>
    2b78:      	add	x16, sp, #0x150
    2b7c:      	ldr	x0, [x16, #0x8]
    2b80:      	ldr	x1, [x20, #0x8]
    2b84:      	cmp	x0, x1
    2b88:      	b.lt	0x2bb8 <_stogir.cfg.build+0x8e0>
    2b8c:      	str	x19, [sp, #0x268]
    2b90:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002b90:  ARM64_RELOC_PAGE21	l_stogir.411
    2b94:      	ldr	x21, [x21]
		0000000000002b94:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    2b98:      	mov	x22, #0x27              ; =39
    2b9c:      	ldr	x19, [sp, #0x268]
    2ba0:      	cmp	x22, #0x0
    2ba4:      	b.ne	0x2b50 <_stogir.cfg.build+0x878>
    2ba8:      	cmp	x28, #0x0
    2bac:      	cset	w0, eq
    2bb0:      	ubfx	x0, x0, #0, #8
    2bb4:      	b	0x2b54 <_stogir.cfg.build+0x87c>
    2bb8:      	add	x16, sp, #0x150
    2bbc:      	ldr	x1, [x16, #0x10]
    2bc0:      	cmp	x0, x1
    2bc4:      	b.lt	0x2e88 <_stogir.cfg.build+0xbb0>
    2bc8:      	cmp	x1, #0x0
    2bcc:      	b.ne	0x2bd8 <_stogir.cfg.build+0x900>
    2bd0:      	mov	x1, #0x2                ; =2
    2bd4:      	b	0x2bdc <_stogir.cfg.build+0x904>
    2bd8:      	lsl	x1, x1, #1
    2bdc:      	str	x19, [sp, #0x268]
    2be0:      	fmov	d31, x0
    2be4:      	mov	x0, x19
    2be8:      	fmov	x19, d31
    2bec:      	bl	0x2bec <_stogir.cfg.build+0x914>
		0000000000002bec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    2bf0:      	orr	w0, w27, wzr
    2bf4:      	add	x1, x19, #0x1
    2bf8:      	sxtw	x2, w0
    2bfc:      	add	x16, sp, #0x150
    2c00:      	ldr	x3, [x16]
    2c04:      	add	x3, x3, x19, lsl #2
    2c08:      	str	w0, [x3]
    2c0c:      	add	x16, sp, #0x150
    2c10:      	str	x1, [x16, #0x8]
    2c14:      	cmp	x2, #0x0
    2c18:      	b.le	0x2c58 <_stogir.cfg.build+0x980>
    2c1c:      	lsl	x0, x2, #2
    2c20:      	ldr	x1, [x20, #0x8]
    2c24:      	cmp	x2, x1
    2c28:      	b.ge	0x2d34 <_stogir.cfg.build+0xa5c>
    2c2c:      	ldr	x1, [x24, #0x8]
    2c30:      	cmp	x2, x1
    2c34:      	b.ge	0x2d2c <_stogir.cfg.build+0xa54>
    2c38:      	ldr	x1, [x20, #0x78]
    2c3c:      	add	x1, x0, x1
    2c40:      	ldr	w1, [x1]
    2c44:      	sxtw	x1, w1
    2c48:      	cmp	x1, #0x0
    2c4c:      	cset	w1, ge
    2c50:      	ubfx	x1, x1, #0, #8
    2c54:      	b	0x2d30 <_stogir.cfg.build+0xa58>
    2c58:      	movz	w1, #0x0, lsl #16
    2c5c:      	movz	w0, #0x0, lsl #16
    2c60:      	ubfx	x1, x1, #0, #32
    2c64:      	lsr	x16, x1, #0
    2c68:      	cmp	x16, #0x1
    2c6c:      	b.eq	0x2c88 <_stogir.cfg.build+0x9b0>
    2c70:      	b.lo	0x2c78 <_stogir.cfg.build+0x9a0>
    2c74:      	b	0x2c8c <_stogir.cfg.build+0x9b4>
    2c78:      	cmp	x16, #0x0
    2c7c:      	b.eq	0x2c84 <_stogir.cfg.build+0x9ac>
    2c80:      	b	0x2c8c <_stogir.cfg.build+0x9b4>
    2c84:      	b	0x2c90 <_stogir.cfg.build+0x9b8>
    2c88:      	b	0x2ce8 <_stogir.cfg.build+0xa10>
    2c8c:      	b	0x2e08 <_stogir.cfg.build+0xb30>
    2c90:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002c90:  ARM64_RELOC_PAGE21	l_stogir.412
    2c94:      	ldr	x21, [x21]
		0000000000002c94:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    2c98:      	mov	x22, #0x1e              ; =30
    2c9c:      	b	0x2b48 <_stogir.cfg.build+0x870>
    2ca0:      	mov	x0, x21
    2ca4:      	mov	x1, x22
    2ca8:      	adrp	x2, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002ca8:  ARM64_RELOC_PAGE21	l_stogir.409
    2cac:      	ldr	x2, [x2]
		0000000000002cac:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    2cb0:      	movz	x3, #0x0, lsl #48
    2cb4:      	bl	0x2cb4 <_stogir.cfg.build+0x9dc>
		0000000000002cb4:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2cb8:      	cmp	x0, #0x0
    2cbc:      	b.eq	0x2a84 <_stogir.cfg.build+0x7ac>
    2cc0:      	add	x8, sp, #0x1b0
    2cc4:      	ldr	x0, [sp, #0x268]
    2cc8:      	bl	0x2cc8 <_stogir.cfg.build+0x9f0>
		0000000000002cc8:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2ccc:      	add	x16, sp, #0x1b0
    2cd0:      	ldr	x0, [x16]
    2cd4:      	add	x16, sp, #0x1b0
    2cd8:      	ldr	x1, [x16, #0x8]
    2cdc:      	add	x16, sp, #0x1b0
    2ce0:      	ldr	x2, [x16, #0x10]
    2ce4:      	b	0x2a5c <_stogir.cfg.build+0x784>
    2ce8:      	sxtw	x0, w0
    2cec:      	cmp	x0, #0x0
    2cf0:      	b.le	0x2b3c <_stogir.cfg.build+0x864>
    2cf4:      	ldr	x1, [x20, #0x8]
    2cf8:      	cmp	x0, x1
    2cfc:      	b.ge	0x2de4 <_stogir.cfg.build+0xb0c>
    2d00:      	ldr	x1, [x23, #0x8]
    2d04:      	cmp	x0, x1
    2d08:      	b.ge	0x2df8 <_stogir.cfg.build+0xb20>
    2d0c:      	ldr	x1, [x20, #0x78]
    2d10:      	add	x1, x1, x0, lsl #2
    2d14:      	ldr	w1, [x1]
    2d18:      	sxtw	x1, w1
    2d1c:      	cmp	x1, #0x0
    2d20:      	cset	w1, ge
    2d24:      	ubfx	x1, x1, #0, #8
    2d28:      	b	0x2dfc <_stogir.cfg.build+0xb24>
    2d2c:      	movz	x1, #0x0, lsl #48
    2d30:      	b	0x2d38 <_stogir.cfg.build+0xa60>
    2d34:      	movz	x1, #0x0, lsl #48
    2d38:      	cmp	x1, #0x0
    2d3c:      	b.eq	0x2c58 <_stogir.cfg.build+0x980>
    2d40:      	ldr	x1, [x20, #0x78]
    2d44:      	add	x0, x0, x1
    2d48:      	ldr	w0, [x0]
    2d4c:      	sxtw	x0, w0
    2d50:      	cmp	x0, #0x1
    2d54:      	b.lt	0x2a04 <_stogir.cfg.build+0x72c>
    2d58:      	ldr	x0, [x20]
    2d5c:      	add	x0, x0, x2, lsl #4
    2d60:      	ldr	w0, [x0, #0x4]
    2d64:      	movn	w17, #0x0, lsl #16
    2d68:      	and	w0, w0, w17
    2d6c:      	mov	w1, #0x1                ; =1
    2d70:      	b	0x2a0c <_stogir.cfg.build+0x734>
    2d74:      	mov	x0, x21
    2d78:      	mov	x1, x22
    2d7c:      	adrp	x2, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002d7c:  ARM64_RELOC_PAGE21	l_stogir.409
    2d80:      	ldr	x2, [x2]
		0000000000002d80:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    2d84:      	movz	x3, #0x0, lsl #48
    2d88:      	bl	0x2d88 <_stogir.cfg.build+0xab0>
		0000000000002d88:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2d8c:      	cmp	x0, #0x0
    2d90:      	b.eq	0x25d0 <_stogir.cfg.build+0x2f8>
    2d94:      	add	x16, sp, #0x1d0
    2d98:      	orr	x19, x16, xzr
    2d9c:      	ldr	x23, [sp, #0x258]
    2da0:      	add	x24, x23, #0x50
    2da4:      	add	x8, sp, #0x1f0
    2da8:      	mov	x0, x23
    2dac:      	bl	0x2dac <_stogir.cfg.build+0xad4>
		0000000000002dac:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2db0:      	add	x16, sp, #0x1f0
    2db4:      	ldr	x0, [x16]
    2db8:      	add	x16, sp, #0x1d0
    2dbc:      	str	x0, [x16]
    2dc0:      	add	x16, sp, #0x1f0
    2dc4:      	ldr	x0, [x16, #0x8]
    2dc8:      	add	x16, sp, #0x1d0
    2dcc:      	str	x0, [x16, #0x8]
    2dd0:      	add	x16, sp, #0x1f0
    2dd4:      	ldr	x0, [x16, #0x10]
    2dd8:      	add	x16, sp, #0x1d0
    2ddc:      	str	x0, [x16, #0x10]
    2de0:      	b	0x2548 <_stogir.cfg.build+0x270>
    2de4:      	movz	x1, #0x0, lsl #48
    2de8:      	cmp	x1, #0x0
    2dec:      	b.eq	0x2b3c <_stogir.cfg.build+0x864>
    2df0:      	mov	x27, x0
    2df4:      	b	0x2b48 <_stogir.cfg.build+0x870>
    2df8:      	movz	x1, #0x0, lsl #48
    2dfc:      	b	0x2de8 <_stogir.cfg.build+0xb10>
    2e00:      	brk	#0
    2e04:      	b	0x2e00 <_stogir.cfg.build+0xb28>
    2e08:      	brk	#0
    2e0c:      	b	0x2e08 <_stogir.cfg.build+0xb30>
    2e10:      	brk	#0
    2e14:      	b	0x2e10 <_stogir.cfg.build+0xb38>
    2e18:      	brk	#0
    2e1c:      	b	0x2e18 <_stogir.cfg.build+0xb40>
    2e20:      	brk	#0
    2e24:      	b	0x2e20 <_stogir.cfg.build+0xb48>
    2e28:      	str	x20, [sp, #0x260]
    2e2c:      	str	x23, [sp, #0x258]
    2e30:      	str	x19, [sp, #0x278]
    2e34:      	b	0x253c <_stogir.cfg.build+0x264>
    2e38:      	str	x20, [sp, #0x260]
    2e3c:      	str	x23, [sp, #0x258]
    2e40:      	str	x19, [sp, #0x278]
    2e44:      	mov	x19, x1
    2e48:      	str	x0, [sp, #0x270]
    2e4c:      	str	w25, [sp, #0x280]
    2e50:      	b	0x2404 <_stogir.cfg.build+0x12c>
    2e54:      	str	x23, [sp, #0x258]
    2e58:      	str	w25, [sp, #0x280]
    2e5c:      	mov	x23, x0
    2e60:      	mov	x25, x1
    2e64:      	b	0x23e8 <_stogir.cfg.build+0x110>
    2e68:      	str	x19, [sp, #0x268]
    2e6c:      	b	0x2d74 <_stogir.cfg.build+0xa9c>
    2e70:      	str	x19, [sp, #0x268]
    2e74:      	b	0x2a84 <_stogir.cfg.build+0x7ac>
    2e78:      	str	x19, [sp, #0x268]
    2e7c:      	b	0x2ca0 <_stogir.cfg.build+0x9c8>
    2e80:      	str	x19, [sp, #0x268]
    2e84:      	b	0x2b9c <_stogir.cfg.build+0x8c4>
    2e88:      	str	x19, [sp, #0x268]
    2e8c:      	mov	x19, x0
    2e90:      	b	0x2bf0 <_stogir.cfg.build+0x918>
    2e94:      	udf	#0x0

0000000000002e98 <_stogir.adjacency.build>:
    2e98:      	sub	sp, sp, #0x70
    2e9c:      	str	x29, [sp]
    2ea0:      	str	x30, [sp, #0x8]
    2ea4:      	mov	x29, sp
    2ea8:      	str	x19, [sp, #0x18]
    2eac:      	str	x20, [sp, #0x20]
    2eb0:      	str	x21, [sp, #0x28]
    2eb4:      	str	x22, [sp, #0x30]
    2eb8:      	str	x23, [sp, #0x38]
    2ebc:      	str	x24, [sp, #0x40]
    2ec0:      	str	x25, [sp, #0x48]
    2ec4:      	str	x26, [sp, #0x50]
    2ec8:      	str	x27, [sp, #0x58]
    2ecc:      	str	x28, [sp, #0x60]
    2ed0:      	add	x3, x0, #0x28
    2ed4:      	ldr	x3, [x3, #0x8]
    2ed8:      	orr	x19, x3, xzr
    2edc:      	mov	x20, sp
    2ee0:      	sub	sp, sp, #0x50
    2ee4:      	mov	x21, sp
    2ee8:      	sub	sp, sp, #0x30
    2eec:      	mov	x22, sp
    2ef0:      	ldr	x3, [x2]
    2ef4:      	ldr	x4, [x2, #0x8]
    2ef8:      	movz	x17, #0x0, lsl #48
    2efc:      	str	x17, [x21]
    2f00:      	movz	x17, #0x0, lsl #48
    2f04:      	str	x17, [x21, #0x8]
    2f08:      	movz	x17, #0x0, lsl #48
    2f0c:      	str	x17, [x21, #0x10]
    2f10:      	str	x3, [x21, #0x18]
    2f14:      	str	x4, [x21, #0x20]
    2f18:      	movz	x17, #0x0, lsl #48
    2f1c:      	str	x17, [x21, #0x28]
    2f20:      	movz	x17, #0x0, lsl #48
    2f24:      	str	x17, [x21, #0x30]
    2f28:      	movz	x17, #0x0, lsl #48
    2f2c:      	str	x17, [x21, #0x38]
    2f30:      	str	x3, [x21, #0x40]
    2f34:      	str	x4, [x21, #0x48]
    2f38:      	ldr	x3, [x2]
    2f3c:      	ldr	x2, [x2, #0x8]
    2f40:      	movz	x17, #0x0, lsl #48
    2f44:      	str	x17, [x22]
    2f48:      	movz	x17, #0x0, lsl #48
    2f4c:      	str	x17, [x22, #0x8]
    2f50:      	movz	x17, #0x0, lsl #48
    2f54:      	str	x17, [x22, #0x10]
    2f58:      	str	x3, [x22, #0x18]
    2f5c:      	str	x2, [x22, #0x20]
    2f60:      	ldr	x2, [x21, #0x8]
    2f64:      	orr	x23, x2, xzr
    2f68:      	ldr	x2, [x21, #0x10]
    2f6c:      	add	x24, x23, x19
    2f70:      	cmp	x24, x2
    2f74:      	b.le	0x3338 <_stogir.adjacency.build+0x4a0>
    2f78:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2f7c:      	cmp	x2, x17
    2f80:      	b.gt	0x2f8c <_stogir.adjacency.build+0xf4>
    2f84:      	lsl	x2, x2, #1
    2f88:      	b	0x2f90 <_stogir.adjacency.build+0xf8>
    2f8c:      	mov	x2, x24
    2f90:      	cmp	x2, x24
    2f94:      	b.gt	0x2f9c <_stogir.adjacency.build+0x104>
    2f98:      	mov	x2, x24
    2f9c:      	mov	x25, x8
    2fa0:      	mov	x26, x0
    2fa4:      	mov	x0, x21
    2fa8:      	mov	w27, w1
    2fac:      	mov	x1, x2
    2fb0:      	bl	0x2fb0 <_stogir.adjacency.build+0x118>
		0000000000002fb0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range
    2fb4:      	lsl	x0, x19, #4
    2fb8:      	ldr	x1, [x21]
    2fbc:      	add	x1, x1, x23, lsl #4
    2fc0:      	mov	x2, x0
    2fc4:      	mov	x0, x1
    2fc8:      	movz	x1, #0x0, lsl #48
    2fcc:      	bl	0x2fcc <_stogir.adjacency.build+0x134>
		0000000000002fcc:  ARM64_RELOC_BRANCH26	_memset
    2fd0:      	str	x24, [x21, #0x8]
    2fd4:      	ldr	x0, [x22, #0x8]
    2fd8:      	orr	x23, x0, xzr
    2fdc:      	ldr	x0, [x22, #0x10]
    2fe0:      	add	x24, x23, x19
    2fe4:      	cmp	x24, x0
    2fe8:      	b.le	0x301c <_stogir.adjacency.build+0x184>
    2fec:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2ff0:      	cmp	x0, x17
    2ff4:      	b.gt	0x3000 <_stogir.adjacency.build+0x168>
    2ff8:      	lsl	x0, x0, #1
    2ffc:      	b	0x3004 <_stogir.adjacency.build+0x16c>
    3000:      	mov	x0, x24
    3004:      	cmp	x0, x24
    3008:      	b.gt	0x3010 <_stogir.adjacency.build+0x178>
    300c:      	mov	x0, x24
    3010:      	mov	x1, x0
    3014:      	mov	x0, x22
    3018:      	bl	0x3018 <_stogir.adjacency.build+0x180>
		0000000000003018:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    301c:      	add	x28, x26, #0x50
    3020:      	ubfx	x27, x27, #0, #8
    3024:      	lsl	x0, x19, #3
    3028:      	cmp	x27, #0x0
    302c:      	cset	w19, ne
    3030:      	ldr	x1, [x22]
    3034:      	add	x1, x1, x23, lsl #3
    3038:      	mov	x2, x0
    303c:      	mov	x0, x1
    3040:      	movz	x1, #0x0, lsl #48
    3044:      	bl	0x3044 <_stogir.adjacency.build+0x1ac>
		0000000000003044:  ARM64_RELOC_BRANCH26	_memset
    3048:      	str	x24, [x22, #0x8]
    304c:      	ldr	x0, [x26, #0x50]
    3050:      	ldr	x1, [x28, #0x8]
    3054:      	movz	x2, #0x0, lsl #48
    3058:      	b	0x3084 <_stogir.adjacency.build+0x1ec>
    305c:      	sxtw	x3, w4
    3060:      	ldr	x4, [x21]
    3064:      	orr	x5, x4, xzr
    3068:      	add	x5, x5, x3, lsl #4
    306c:      	add	x3, x4, x3, lsl #4
    3070:      	ldr	x4, [x5]
    3074:      	ldr	x5, [x5, #0x8]
    3078:      	add	x5, x5, #0x1
    307c:      	str	x4, [x3]
    3080:      	str	x5, [x3, #0x8]
    3084:      	cmp	x2, x1
    3088:      	b.ge	0x30a4 <_stogir.adjacency.build+0x20c>
    308c:      	add	x3, x2, #0x1
    3090:      	add	x2, x0, x2, lsl #4
    3094:      	ldr	x4, [x2]
    3098:      	mov	x2, x3
    309c:      	mov	w3, #0x1                ; =1
    30a0:      	b	0x30ac <_stogir.adjacency.build+0x214>
    30a4:      	movz	w3, #0x0, lsl #16
    30a8:      	movz	x4, #0x0, lsl #48
    30ac:      	ubfx	x3, x3, #0, #32
    30b0:      	lsr	x16, x3, #0
    30b4:      	cmp	x16, #0x1
    30b8:      	b.eq	0x30d4 <_stogir.adjacency.build+0x23c>
    30bc:      	b.lo	0x30c4 <_stogir.adjacency.build+0x22c>
    30c0:      	b	0x30d8 <_stogir.adjacency.build+0x240>
    30c4:      	cmp	x16, #0x0
    30c8:      	b.eq	0x30d0 <_stogir.adjacency.build+0x238>
    30cc:      	b	0x30d8 <_stogir.adjacency.build+0x240>
    30d0:      	b	0x30f0 <_stogir.adjacency.build+0x258>
    30d4:      	b	0x30dc <_stogir.adjacency.build+0x244>
    30d8:      	b	0x3330 <_stogir.adjacency.build+0x498>
    30dc:      	uxtb	w16, w19
    30e0:      	cmp	w16, wzr
    30e4:      	b.eq	0x305c <_stogir.adjacency.build+0x1c4>
    30e8:      	asr	x3, x4, #32
    30ec:      	b	0x3060 <_stogir.adjacency.build+0x1c8>
    30f0:      	movz	x0, #0x0, lsl #48
    30f4:      	movz	x1, #0x0, lsl #48
    30f8:      	b	0x3138 <_stogir.adjacency.build+0x2a0>
    30fc:      	nop
    3100:      	add	x2, x0, #0x1
    3104:      	ldr	x3, [x21]
    3108:      	orr	x4, x3, xzr
    310c:      	add	x4, x4, x0, lsl #4
    3110:      	add	x3, x3, x0, lsl #4
    3114:      	ldr	x4, [x4, #0x8]
    3118:      	add	x5, x4, x1
    311c:      	str	x1, [x3]
    3120:      	str	x4, [x3, #0x8]
    3124:      	ldr	x3, [x22]
    3128:      	add	x0, x3, x0, lsl #3
    312c:      	str	x1, [x0]
    3130:      	mov	x0, x2
    3134:      	mov	x1, x5
    3138:      	ldr	x2, [x21, #0x8]
    313c:      	cmp	x0, x2
    3140:      	b.lt	0x3100 <_stogir.adjacency.build+0x268>
    3144:      	add	x19, x21, #0x28
    3148:      	ldr	x0, [x28, #0x8]
    314c:      	orr	x23, x0, xzr
    3150:      	ldr	x0, [x19, #0x8]
    3154:      	orr	x24, x0, xzr
    3158:      	ldr	x0, [x19, #0x10]
    315c:      	add	x1, x24, x23
    3160:      	cmp	x1, x0
    3164:      	b.le	0x3348 <_stogir.adjacency.build+0x4b0>
    3168:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    316c:      	cmp	x0, x17
    3170:      	b.gt	0x317c <_stogir.adjacency.build+0x2e4>
    3174:      	lsl	x0, x0, #1
    3178:      	b	0x3180 <_stogir.adjacency.build+0x2e8>
    317c:      	mov	x0, x1
    3180:      	cmp	x0, x1
    3184:      	b.gt	0x318c <_stogir.adjacency.build+0x2f4>
    3188:      	mov	x0, x1
    318c:      	str	x25, [x29, #0x10]
    3190:      	mov	x25, x1
    3194:      	mov	x1, x0
    3198:      	mov	x0, x19
    319c:      	bl	0x319c <_stogir.adjacency.build+0x304>
		000000000000319c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    31a0:      	cmp	x27, #0x0
    31a4:      	cset	w27, ne
    31a8:      	lsl	x0, x23, #3
    31ac:      	ldr	x1, [x21, #0x28]
    31b0:      	add	x1, x1, x24, lsl #3
    31b4:      	mov	x2, x0
    31b8:      	mov	x0, x1
    31bc:      	movz	x1, #0x0, lsl #48
    31c0:      	bl	0x31c0 <_stogir.adjacency.build+0x328>
		00000000000031c0:  ARM64_RELOC_BRANCH26	_memset
    31c4:      	str	x25, [x19, #0x8]
    31c8:      	movz	x0, #0x0, lsl #48
    31cc:      	b	0x3204 <_stogir.adjacency.build+0x36c>
    31d0:      	sxtw	x1, w1
    31d4:      	add	x2, x0, #0x1
    31d8:      	ldr	x3, [x22]
    31dc:      	add	x3, x3, x1, lsl #3
    31e0:      	ldr	x3, [x3]
    31e4:      	ldr	x4, [x21, #0x28]
    31e8:      	add	x5, x3, #0x1
    31ec:      	add	x3, x4, x3, lsl #3
    31f0:      	str	x0, [x3]
    31f4:      	ldr	x0, [x22]
    31f8:      	add	x0, x0, x1, lsl #3
    31fc:      	str	x5, [x0]
    3200:      	mov	x0, x2
    3204:      	ldr	x1, [x28, #0x8]
    3208:      	cmp	x0, x1
    320c:      	b.ge	0x3230 <_stogir.adjacency.build+0x398>
    3210:      	ldr	x1, [x26, #0x50]
    3214:      	add	x1, x1, x0, lsl #4
    3218:      	ldr	x1, [x1]
    321c:      	uxtb	w16, w27
    3220:      	cmp	w16, wzr
    3224:      	b.eq	0x31d0 <_stogir.adjacency.build+0x338>
    3228:      	asr	x1, x1, #32
    322c:      	b	0x31d4 <_stogir.adjacency.build+0x33c>
    3230:      	b	0x3240 <_stogir.adjacency.build+0x3a8>
    3234:      	nop
    3238:      	sub	x0, x0, #0x1
    323c:      	str	x0, [x22, #0x8]
    3240:      	ldr	x0, [x22, #0x8]
    3244:      	cmp	x0, #0x0
    3248:      	b.ne	0x3238 <_stogir.adjacency.build+0x3a0>
    324c:      	ldr	x0, [x22, #0x10]
    3250:      	cmp	x0, #0x0
    3254:      	b.le	0x3284 <_stogir.adjacency.build+0x3ec>
    3258:      	add	x1, x22, #0x18
    325c:      	ldr	x2, [x22]
    3260:      	fmov	d31, x0
    3264:      	mov	x0, x1
    3268:      	mov	x1, x2
    326c:      	fmov	x2, d31
    3270:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003270:  ARM64_RELOC_PAGE21	l_stogir.413
    3274:      	ldr	x3, [x3]
		0000000000003274:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    3278:      	mov	x4, #0x8                ; =8
    327c:      	mov	x5, #0x8                ; =8
    3280:      	bl	0x3280 <_stogir.adjacency.build+0x3e8>
		0000000000003280:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3284:      	movz	x17, #0x0, lsl #48
    3288:      	str	x17, [x22]
    328c:      	movz	x17, #0x0, lsl #48
    3290:      	str	x17, [x22, #0x8]
    3294:      	movz	x17, #0x0, lsl #48
    3298:      	str	x17, [x22, #0x10]
    329c:      	ldr	x0, [x21]
    32a0:      	ldr	x1, [x21, #0x8]
    32a4:      	ldr	x2, [x21, #0x10]
    32a8:      	ldr	x3, [x21, #0x18]
    32ac:      	ldr	x4, [x21, #0x20]
    32b0:      	ldr	x5, [x21, #0x28]
    32b4:      	ldr	x6, [x21, #0x30]
    32b8:      	ldr	x7, [x21, #0x38]
    32bc:      	ldr	x8, [x21, #0x40]
    32c0:      	ldr	x9, [x21, #0x48]
    32c4:      	mov	sp, x20
    32c8:      	ldr	x10, [x29, #0x10]
    32cc:      	str	x0, [x10]
    32d0:      	str	x1, [x10, #0x8]
    32d4:      	str	x2, [x10, #0x10]
    32d8:      	str	x3, [x10, #0x18]
    32dc:      	str	x4, [x10, #0x20]
    32e0:      	str	x5, [x10, #0x28]
    32e4:      	str	x6, [x10, #0x30]
    32e8:      	str	x7, [x10, #0x38]
    32ec:      	str	x8, [x10, #0x40]
    32f0:      	str	x9, [x10, #0x48]
    32f4:      	sub	sp, x29, #0x0
    32f8:      	ldr	x19, [sp, #0x18]
    32fc:      	ldr	x20, [sp, #0x20]
    3300:      	ldr	x21, [sp, #0x28]
    3304:      	ldr	x22, [sp, #0x30]
    3308:      	ldr	x23, [sp, #0x38]
    330c:      	ldr	x24, [sp, #0x40]
    3310:      	ldr	x25, [sp, #0x48]
    3314:      	ldr	x26, [sp, #0x50]
    3318:      	ldr	x27, [sp, #0x58]
    331c:      	ldr	x28, [sp, #0x60]
    3320:      	ldr	x29, [sp]
    3324:      	ldr	x30, [sp, #0x8]
    3328:      	add	sp, sp, #0x70
    332c:      	ret
    3330:      	brk	#0
    3334:      	b	0x3330 <_stogir.adjacency.build+0x498>
    3338:      	mov	x25, x8
    333c:      	mov	x26, x0
    3340:      	mov	w27, w1
    3344:      	b	0x2fb4 <_stogir.adjacency.build+0x11c>
    3348:      	str	x25, [x29, #0x10]
    334c:      	mov	x25, x1
    3350:      	b	0x31a0 <_stogir.adjacency.build+0x308>
    3354:      	udf	#0x0

0000000000003358 <_stogir.adjacency.reverse-postorder>:
    3358:      	sub	sp, sp, #0x140
    335c:      	str	x29, [sp]
    3360:      	str	x30, [sp, #0x8]
    3364:      	mov	x29, sp
    3368:      	str	x19, [sp, #0xf0]
    336c:      	str	x20, [sp, #0xf8]
    3370:      	str	x21, [sp, #0x100]
    3374:      	str	x22, [sp, #0x108]
    3378:      	str	x23, [sp, #0x110]
    337c:      	str	x24, [sp, #0x118]
    3380:      	str	x25, [sp, #0x120]
    3384:      	str	x26, [sp, #0x128]
    3388:      	str	x27, [sp, #0x130]
    338c:      	add	x4, x0, #0x28
    3390:      	add	x16, sp, #0x10
    3394:      	orr	x19, x16, xzr
    3398:      	ldr	x5, [x3]
    339c:      	ldr	x6, [x3, #0x8]
    33a0:      	add	x16, sp, #0x10
    33a4:      	movz	x17, #0x0, lsl #48
    33a8:      	str	x17, [x16]
    33ac:      	add	x16, sp, #0x10
    33b0:      	movz	x17, #0x0, lsl #48
    33b4:      	str	x17, [x16, #0x8]
    33b8:      	add	x16, sp, #0x10
    33bc:      	movz	x17, #0x0, lsl #48
    33c0:      	str	x17, [x16, #0x10]
    33c4:      	add	x16, sp, #0x10
    33c8:      	str	x5, [x16, #0x18]
    33cc:      	add	x16, sp, #0x10
    33d0:      	str	x6, [x16, #0x20]
    33d4:      	ldr	x5, [x3]
    33d8:      	ldr	x6, [x3, #0x8]
    33dc:      	add	x16, sp, #0x40
    33e0:      	movz	x17, #0x0, lsl #48
    33e4:      	str	x17, [x16]
    33e8:      	add	x16, sp, #0x40
    33ec:      	movz	x17, #0x0, lsl #48
    33f0:      	str	x17, [x16, #0x8]
    33f4:      	add	x16, sp, #0x40
    33f8:      	movz	x17, #0x0, lsl #48
    33fc:      	str	x17, [x16, #0x10]
    3400:      	add	x16, sp, #0x40
    3404:      	str	x5, [x16, #0x18]
    3408:      	add	x16, sp, #0x40
    340c:      	str	x6, [x16, #0x20]
    3410:      	ldr	x5, [x3]
    3414:      	ldr	x6, [x3, #0x8]
    3418:      	add	x16, sp, #0x70
    341c:      	movz	x17, #0x0, lsl #48
    3420:      	str	x17, [x16]
    3424:      	add	x16, sp, #0x70
    3428:      	movz	x17, #0x0, lsl #48
    342c:      	str	x17, [x16, #0x8]
    3430:      	add	x16, sp, #0x70
    3434:      	movz	x17, #0x0, lsl #48
    3438:      	str	x17, [x16, #0x10]
    343c:      	add	x16, sp, #0x70
    3440:      	str	x5, [x16, #0x18]
    3444:      	add	x16, sp, #0x70
    3448:      	str	x6, [x16, #0x20]
    344c:      	ldr	x5, [x3]
    3450:      	ldr	x3, [x3, #0x8]
    3454:      	add	x16, sp, #0xa0
    3458:      	movz	x17, #0x0, lsl #48
    345c:      	str	x17, [x16]
    3460:      	add	x16, sp, #0xa0
    3464:      	movz	x17, #0x0, lsl #48
    3468:      	str	x17, [x16, #0x8]
    346c:      	add	x16, sp, #0xa0
    3470:      	movz	x17, #0x0, lsl #48
    3474:      	str	x17, [x16, #0x10]
    3478:      	add	x16, sp, #0xa0
    347c:      	str	x5, [x16, #0x18]
    3480:      	add	x16, sp, #0xa0
    3484:      	str	x3, [x16, #0x20]
    3488:      	ldr	x3, [x4, #0x8]
    348c:      	orr	x20, x3, xzr
    3490:      	add	x16, sp, #0x10
    3494:      	ldr	x3, [x16, #0x8]
    3498:      	orr	x21, x3, xzr
    349c:      	add	x16, sp, #0x10
    34a0:      	ldr	x3, [x16, #0x10]
    34a4:      	add	x22, x21, x20
    34a8:      	cmp	x22, x3
    34ac:      	b.le	0x3a18 <_stogir.adjacency.reverse-postorder+0x6c0>
    34b0:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    34b4:      	cmp	x3, x17
    34b8:      	b.gt	0x34c4 <_stogir.adjacency.reverse-postorder+0x16c>
    34bc:      	lsl	x3, x3, #1
    34c0:      	b	0x34c8 <_stogir.adjacency.reverse-postorder+0x170>
    34c4:      	mov	x3, x22
    34c8:      	cmp	x3, x22
    34cc:      	b.gt	0x34d4 <_stogir.adjacency.reverse-postorder+0x17c>
    34d0:      	mov	x3, x22
    34d4:      	mov	x23, x8
    34d8:      	mov	x24, x0
    34dc:      	mov	x0, x19
    34e0:      	mov	x25, x1
    34e4:      	mov	x1, x3
    34e8:      	mov	w26, w2
    34ec:      	bl	0x34ec <_stogir.adjacency.reverse-postorder+0x194>
		00000000000034ec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    34f0:      	add	x16, sp, #0x40
    34f4:      	orr	x27, x16, xzr
    34f8:      	lsr	x0, x20, #0
    34fc:      	add	x16, sp, #0x10
    3500:      	ldr	x1, [x16]
    3504:      	add	x1, x1, x21
    3508:      	mov	x2, x0
    350c:      	mov	x0, x1
    3510:      	movz	x1, #0x0, lsl #48
    3514:      	bl	0x3514 <_stogir.adjacency.reverse-postorder+0x1bc>
		0000000000003514:  ARM64_RELOC_BRANCH26	_memset
    3518:      	add	x16, sp, #0x10
    351c:      	str	x22, [x16, #0x8]
    3520:      	add	x16, sp, #0xd0
    3524:      	movz	x17, #0x0, lsl #48
    3528:      	str	x17, [x16]
    352c:      	add	x16, sp, #0xd0
    3530:      	movz	x17, #0x0, lsl #48
    3534:      	str	x17, [x16, #0x8]
    3538:      	add	x16, sp, #0xd0
    353c:      	str	w26, [x16]
    3540:      	add	x16, sp, #0xd0
    3544:      	movz	x17, #0x0, lsl #48
    3548:      	str	x17, [x16, #0x8]
    354c:      	add	x16, sp, #0xd0
    3550:      	ldr	x20, [x16]
    3554:      	add	x16, sp, #0x40
    3558:      	ldr	x0, [x16, #0x8]
    355c:      	orr	x21, x0, xzr
    3560:      	add	x16, sp, #0x40
    3564:      	ldr	x0, [x16, #0x10]
    3568:      	cmp	x21, x0
    356c:      	b.lt	0x3590 <_stogir.adjacency.reverse-postorder+0x238>
    3570:      	cmp	x0, #0x0
    3574:      	b.ne	0x3580 <_stogir.adjacency.reverse-postorder+0x228>
    3578:      	mov	x0, #0x2                ; =2
    357c:      	b	0x3584 <_stogir.adjacency.reverse-postorder+0x22c>
    3580:      	lsl	x0, x0, #1
    3584:      	mov	x1, x0
    3588:      	mov	x0, x27
    358c:      	bl	0x358c <_stogir.adjacency.reverse-postorder+0x234>
		000000000000358c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    3590:      	sxtw	x26, w26
    3594:      	add	x16, sp, #0x70
    3598:      	orr	x22, x16, xzr
    359c:      	add	x0, x21, #0x1
    35a0:      	add	x16, sp, #0x40
    35a4:      	ldr	x1, [x16]
    35a8:      	add	x1, x1, x21, lsl #4
    35ac:      	str	x20, [x1]
    35b0:      	movz	x17, #0x0, lsl #48
    35b4:      	str	x17, [x1, #0x8]
    35b8:      	add	x16, sp, #0x40
    35bc:      	str	x0, [x16, #0x8]
    35c0:      	add	x16, sp, #0x10
    35c4:      	ldr	x0, [x16]
    35c8:      	add	x0, x0, x26
    35cc:      	mov	w17, #0x1               ; =1
    35d0:      	strb	w17, [x0]
    35d4:      	b	0x3658 <_stogir.adjacency.reverse-postorder+0x300>
    35d8:      	lsl	x0, x0, #1
    35dc:      	mov	x1, x0
    35e0:      	mov	x0, x22
    35e4:      	bl	0x35e4 <_stogir.adjacency.reverse-postorder+0x28c>
		00000000000035e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    35e8:      	add	x0, x21, #0x1
    35ec:      	add	x16, sp, #0x70
    35f0:      	ldr	x1, [x16]
    35f4:      	add	x1, x1, x21, lsl #2
    35f8:      	str	w20, [x1]
    35fc:      	add	x16, sp, #0x70
    3600:      	str	x0, [x16, #0x8]
    3604:      	add	x16, sp, #0x40
    3608:      	ldr	x0, [x16, #0x8]
    360c:      	cmp	x0, #0x0
    3610:      	b.eq	0x3658 <_stogir.adjacency.reverse-postorder+0x300>
    3614:      	sub	x0, x0, #0x1
    3618:      	add	x16, sp, #0x40
    361c:      	str	x0, [x16, #0x8]
    3620:      	b	0x3658 <_stogir.adjacency.reverse-postorder+0x300>
    3624:      	lsl	x0, x0, #1
    3628:      	mov	x1, x0
    362c:      	mov	x0, x27
    3630:      	bl	0x3630 <_stogir.adjacency.reverse-postorder+0x2d8>
		0000000000003630:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    3634:      	add	x0, x21, #0x1
    3638:      	add	x16, sp, #0x40
    363c:      	ldr	x1, [x16]
    3640:      	add	x1, x1, x21, lsl #4
    3644:      	str	x20, [x1]
    3648:      	movz	x17, #0x0, lsl #48
    364c:      	str	x17, [x1, #0x8]
    3650:      	add	x16, sp, #0x40
    3654:      	str	x0, [x16, #0x8]
    3658:      	add	x16, sp, #0x40
    365c:      	ldr	x0, [x16, #0x8]
    3660:      	cmp	x0, #0x0
    3664:      	b.le	0x3784 <_stogir.adjacency.reverse-postorder+0x42c>
    3668:      	add	x16, sp, #0x40
    366c:      	ldr	x1, [x16]
    3670:      	sub	x0, x0, #0x1
    3674:      	add	x2, x1, x0, lsl #4
    3678:      	ldr	x3, [x2]
    367c:      	orr	w20, w3, wzr
    3680:      	ldr	x2, [x2, #0x8]
    3684:      	sxtw	x4, w20
    3688:      	ldr	x5, [x25]
    368c:      	add	x4, x5, x4, lsl #4
    3690:      	ldr	x5, [x4]
    3694:      	ldr	x4, [x4, #0x8]
    3698:      	cmp	x2, x4
    369c:      	b.lt	0x36cc <_stogir.adjacency.reverse-postorder+0x374>
    36a0:      	add	x16, sp, #0x70
    36a4:      	ldr	x0, [x16, #0x8]
    36a8:      	orr	x21, x0, xzr
    36ac:      	add	x16, sp, #0x70
    36b0:      	ldr	x0, [x16, #0x10]
    36b4:      	cmp	x21, x0
    36b8:      	b.lt	0x35e8 <_stogir.adjacency.reverse-postorder+0x290>
    36bc:      	cmp	x0, #0x0
    36c0:      	b.ne	0x35d8 <_stogir.adjacency.reverse-postorder+0x280>
    36c4:      	mov	x0, #0x2                ; =2
    36c8:      	b	0x35dc <_stogir.adjacency.reverse-postorder+0x284>
    36cc:      	add	x4, x2, x5
    36d0:      	add	x2, x2, #0x1
    36d4:      	ldr	x5, [x25, #0x28]
    36d8:      	add	x0, x1, x0, lsl #4
    36dc:      	add	x1, x5, x4, lsl #3
    36e0:      	ldr	x1, [x1]
    36e4:      	ldr	x4, [x24, #0x50]
    36e8:      	add	x1, x4, x1, lsl #4
    36ec:      	ldr	x1, [x1]
    36f0:      	str	x3, [x0]
    36f4:      	lsr	x1, x1, #32
    36f8:      	str	x2, [x0, #0x8]
    36fc:      	sxtw	x0, w1
    3700:      	add	x16, sp, #0x10
    3704:      	ldr	x2, [x16]
    3708:      	add	x3, x2, x0
    370c:      	ldrb	w3, [x3]
    3710:      	cmp	x3, #0x0
    3714:      	b.ne	0x3658 <_stogir.adjacency.reverse-postorder+0x300>
    3718:      	add	x0, x2, x0
    371c:      	mov	w17, #0x1               ; =1
    3720:      	strb	w17, [x0]
    3724:      	add	x16, sp, #0xe0
    3728:      	movz	x17, #0x0, lsl #48
    372c:      	str	x17, [x16]
    3730:      	add	x16, sp, #0xe0
    3734:      	movz	x17, #0x0, lsl #48
    3738:      	str	x17, [x16, #0x8]
    373c:      	add	x16, sp, #0xe0
    3740:      	str	w1, [x16]
    3744:      	add	x16, sp, #0xe0
    3748:      	movz	x17, #0x0, lsl #48
    374c:      	str	x17, [x16, #0x8]
    3750:      	add	x16, sp, #0xe0
    3754:      	ldr	x20, [x16]
    3758:      	add	x16, sp, #0x40
    375c:      	ldr	x0, [x16, #0x8]
    3760:      	orr	x21, x0, xzr
    3764:      	add	x16, sp, #0x40
    3768:      	ldr	x0, [x16, #0x10]
    376c:      	cmp	x21, x0
    3770:      	b.lt	0x3634 <_stogir.adjacency.reverse-postorder+0x2dc>
    3774:      	cmp	x0, #0x0
    3778:      	b.ne	0x3624 <_stogir.adjacency.reverse-postorder+0x2cc>
    377c:      	mov	x0, #0x2                ; =2
    3780:      	b	0x3628 <_stogir.adjacency.reverse-postorder+0x2d0>
    3784:      	add	x16, sp, #0xa0
    3788:      	orr	x20, x16, xzr
    378c:      	add	x16, sp, #0x70
    3790:      	ldr	x0, [x16, #0x8]
    3794:      	orr	x21, x0, xzr
    3798:      	b	0x37cc <_stogir.adjacency.reverse-postorder+0x474>
    379c:      	nop
    37a0:      	lsl	x0, x0, #1
    37a4:      	mov	x1, x0
    37a8:      	mov	x0, x20
    37ac:      	bl	0x37ac <_stogir.adjacency.reverse-postorder+0x454>
		00000000000037ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    37b0:      	add	x0, x25, #0x1
    37b4:      	add	x16, sp, #0xa0
    37b8:      	ldr	x1, [x16]
    37bc:      	add	x1, x1, x25, lsl #2
    37c0:      	str	w24, [x1]
    37c4:      	add	x16, sp, #0xa0
    37c8:      	str	x0, [x16, #0x8]
    37cc:      	cmp	x21, #0x0
    37d0:      	b.le	0x3814 <_stogir.adjacency.reverse-postorder+0x4bc>
    37d4:      	sub	x21, x21, #0x1
    37d8:      	add	x16, sp, #0x70
    37dc:      	ldr	x0, [x16]
    37e0:      	add	x0, x0, x21, lsl #2
    37e4:      	ldr	w24, [x0]
    37e8:      	add	x16, sp, #0xa0
    37ec:      	ldr	x0, [x16, #0x8]
    37f0:      	orr	x25, x0, xzr
    37f4:      	add	x16, sp, #0xa0
    37f8:      	ldr	x0, [x16, #0x10]
    37fc:      	cmp	x25, x0
    3800:      	b.lt	0x37b0 <_stogir.adjacency.reverse-postorder+0x458>
    3804:      	cmp	x0, #0x0
    3808:      	b.ne	0x37a0 <_stogir.adjacency.reverse-postorder+0x448>
    380c:      	mov	x0, #0x2                ; =2
    3810:      	b	0x37a4 <_stogir.adjacency.reverse-postorder+0x44c>
    3814:      	b	0x3824 <_stogir.adjacency.reverse-postorder+0x4cc>
    3818:      	sub	x0, x0, #0x1
    381c:      	add	x16, sp, #0x10
    3820:      	str	x0, [x16, #0x8]
    3824:      	add	x16, sp, #0x10
    3828:      	ldr	x0, [x16, #0x8]
    382c:      	cmp	x0, #0x0
    3830:      	b.ne	0x3818 <_stogir.adjacency.reverse-postorder+0x4c0>
    3834:      	add	x16, sp, #0x10
    3838:      	ldr	x0, [x16, #0x10]
    383c:      	cmp	x0, #0x0
    3840:      	b.le	0x3874 <_stogir.adjacency.reverse-postorder+0x51c>
    3844:      	add	x1, x19, #0x18
    3848:      	add	x16, sp, #0x10
    384c:      	ldr	x2, [x16]
    3850:      	fmov	d31, x0
    3854:      	mov	x0, x1
    3858:      	mov	x1, x2
    385c:      	fmov	x2, d31
    3860:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003860:  ARM64_RELOC_PAGE21	l_stogir.414
    3864:      	ldr	x3, [x3]
		0000000000003864:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    3868:      	mov	x4, #0x1                ; =1
    386c:      	mov	x5, #0x1                ; =1
    3870:      	bl	0x3870 <_stogir.adjacency.reverse-postorder+0x518>
		0000000000003870:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3874:      	add	x16, sp, #0x10
    3878:      	movz	x17, #0x0, lsl #48
    387c:      	str	x17, [x16]
    3880:      	add	x16, sp, #0x10
    3884:      	movz	x17, #0x0, lsl #48
    3888:      	str	x17, [x16, #0x8]
    388c:      	add	x16, sp, #0x10
    3890:      	movz	x17, #0x0, lsl #48
    3894:      	str	x17, [x16, #0x10]
    3898:      	b	0x38ac <_stogir.adjacency.reverse-postorder+0x554>
    389c:      	nop
    38a0:      	sub	x0, x0, #0x1
    38a4:      	add	x16, sp, #0x40
    38a8:      	str	x0, [x16, #0x8]
    38ac:      	add	x16, sp, #0x40
    38b0:      	ldr	x0, [x16, #0x8]
    38b4:      	cmp	x0, #0x0
    38b8:      	b.ne	0x38a0 <_stogir.adjacency.reverse-postorder+0x548>
    38bc:      	add	x16, sp, #0x40
    38c0:      	ldr	x0, [x16, #0x10]
    38c4:      	cmp	x0, #0x0
    38c8:      	b.le	0x38fc <_stogir.adjacency.reverse-postorder+0x5a4>
    38cc:      	add	x1, x27, #0x18
    38d0:      	add	x16, sp, #0x40
    38d4:      	ldr	x2, [x16]
    38d8:      	fmov	d31, x0
    38dc:      	mov	x0, x1
    38e0:      	mov	x1, x2
    38e4:      	fmov	x2, d31
    38e8:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		00000000000038e8:  ARM64_RELOC_PAGE21	l_stogir.415
    38ec:      	ldr	x3, [x3]
		00000000000038ec:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    38f0:      	mov	x4, #0x10               ; =16
    38f4:      	mov	x5, #0x8                ; =8
    38f8:      	bl	0x38f8 <_stogir.adjacency.reverse-postorder+0x5a0>
		00000000000038f8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    38fc:      	add	x16, sp, #0x40
    3900:      	movz	x17, #0x0, lsl #48
    3904:      	str	x17, [x16]
    3908:      	add	x16, sp, #0x40
    390c:      	movz	x17, #0x0, lsl #48
    3910:      	str	x17, [x16, #0x8]
    3914:      	add	x16, sp, #0x40
    3918:      	movz	x17, #0x0, lsl #48
    391c:      	str	x17, [x16, #0x10]
    3920:      	b	0x3934 <_stogir.adjacency.reverse-postorder+0x5dc>
    3924:      	nop
    3928:      	sub	x0, x0, #0x1
    392c:      	add	x16, sp, #0x70
    3930:      	str	x0, [x16, #0x8]
    3934:      	add	x16, sp, #0x70
    3938:      	ldr	x0, [x16, #0x8]
    393c:      	cmp	x0, #0x0
    3940:      	b.ne	0x3928 <_stogir.adjacency.reverse-postorder+0x5d0>
    3944:      	add	x16, sp, #0x70
    3948:      	ldr	x0, [x16, #0x10]
    394c:      	cmp	x0, #0x0
    3950:      	b.le	0x3984 <_stogir.adjacency.reverse-postorder+0x62c>
    3954:      	add	x1, x22, #0x18
    3958:      	add	x16, sp, #0x70
    395c:      	ldr	x2, [x16]
    3960:      	fmov	d31, x0
    3964:      	mov	x0, x1
    3968:      	mov	x1, x2
    396c:      	fmov	x2, d31
    3970:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003970:  ARM64_RELOC_PAGE21	l_stogir.416
    3974:      	ldr	x3, [x3]
		0000000000003974:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    3978:      	mov	x4, #0x4                ; =4
    397c:      	mov	x5, #0x4                ; =4
    3980:      	bl	0x3980 <_stogir.adjacency.reverse-postorder+0x628>
		0000000000003980:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3984:      	add	x16, sp, #0x70
    3988:      	movz	x17, #0x0, lsl #48
    398c:      	str	x17, [x16]
    3990:      	add	x16, sp, #0x70
    3994:      	movz	x17, #0x0, lsl #48
    3998:      	str	x17, [x16, #0x8]
    399c:      	add	x16, sp, #0x70
    39a0:      	movz	x17, #0x0, lsl #48
    39a4:      	str	x17, [x16, #0x10]
    39a8:      	add	x16, sp, #0xa0
    39ac:      	ldr	x0, [x16]
    39b0:      	add	x16, sp, #0xa0
    39b4:      	ldr	x1, [x16, #0x8]
    39b8:      	add	x16, sp, #0xa0
    39bc:      	ldr	x2, [x16, #0x10]
    39c0:      	add	x16, sp, #0xa0
    39c4:      	ldr	x3, [x16, #0x18]
    39c8:      	add	x16, sp, #0xa0
    39cc:      	ldr	x4, [x16, #0x20]
    39d0:      	str	x0, [x23]
    39d4:      	str	x1, [x23, #0x8]
    39d8:      	str	x2, [x23, #0x10]
    39dc:      	str	x3, [x23, #0x18]
    39e0:      	str	x4, [x23, #0x20]
    39e4:      	ldr	x19, [sp, #0xf0]
    39e8:      	ldr	x20, [sp, #0xf8]
    39ec:      	ldr	x21, [sp, #0x100]
    39f0:      	ldr	x22, [sp, #0x108]
    39f4:      	ldr	x23, [sp, #0x110]
    39f8:      	ldr	x24, [sp, #0x118]
    39fc:      	ldr	x25, [sp, #0x120]
    3a00:      	ldr	x26, [sp, #0x128]
    3a04:      	ldr	x27, [sp, #0x130]
    3a08:      	ldr	x29, [sp]
    3a0c:      	ldr	x30, [sp, #0x8]
    3a10:      	add	sp, sp, #0x140
    3a14:      	ret
    3a18:      	mov	x23, x8
    3a1c:      	mov	x24, x0
    3a20:      	mov	x25, x1
    3a24:      	mov	w26, w2
    3a28:      	b	0x34f0 <_stogir.adjacency.reverse-postorder+0x198>
    3a2c:      	udf	#0x0

0000000000003a30 <_stogir.dominators.build>:
    3a30:      	sub	sp, sp, #0xc0
    3a34:      	str	x29, [sp]
    3a38:      	str	x30, [sp, #0x8]
    3a3c:      	mov	x29, sp
    3a40:      	str	x19, [sp, #0x70]
    3a44:      	str	x20, [sp, #0x78]
    3a48:      	str	x21, [sp, #0x80]
    3a4c:      	str	x22, [sp, #0x88]
    3a50:      	str	x23, [sp, #0x90]
    3a54:      	str	x24, [sp, #0x98]
    3a58:      	str	x25, [sp, #0xa0]
    3a5c:      	str	x26, [sp, #0xa8]
    3a60:      	str	x27, [sp, #0xb0]
    3a64:      	add	x4, x0, #0x28
    3a68:      	add	x16, sp, #0x10
    3a6c:      	orr	x5, x16, xzr
    3a70:      	ldr	x6, [x3]
    3a74:      	ldr	x7, [x3, #0x8]
    3a78:      	add	x16, sp, #0x10
    3a7c:      	movz	x17, #0x0, lsl #48
    3a80:      	str	x17, [x16]
    3a84:      	add	x16, sp, #0x10
    3a88:      	movz	x17, #0x0, lsl #48
    3a8c:      	str	x17, [x16, #0x8]
    3a90:      	add	x16, sp, #0x10
    3a94:      	movz	x17, #0x0, lsl #48
    3a98:      	str	x17, [x16, #0x10]
    3a9c:      	add	x16, sp, #0x10
    3aa0:      	str	x6, [x16, #0x18]
    3aa4:      	add	x16, sp, #0x10
    3aa8:      	str	x7, [x16, #0x20]
    3aac:      	ldr	x6, [x3]
    3ab0:      	ldr	x3, [x3, #0x8]
    3ab4:      	add	x16, sp, #0x40
    3ab8:      	movz	x17, #0x0, lsl #48
    3abc:      	str	x17, [x16]
    3ac0:      	add	x16, sp, #0x40
    3ac4:      	movz	x17, #0x0, lsl #48
    3ac8:      	str	x17, [x16, #0x8]
    3acc:      	add	x16, sp, #0x40
    3ad0:      	movz	x17, #0x0, lsl #48
    3ad4:      	str	x17, [x16, #0x10]
    3ad8:      	add	x16, sp, #0x40
    3adc:      	str	x6, [x16, #0x18]
    3ae0:      	add	x16, sp, #0x40
    3ae4:      	str	x3, [x16, #0x20]
    3ae8:      	ldr	x3, [x4, #0x8]
    3aec:      	orr	x19, x3, xzr
    3af0:      	add	x16, sp, #0x10
    3af4:      	ldr	x3, [x16, #0x8]
    3af8:      	orr	x20, x3, xzr
    3afc:      	add	x16, sp, #0x10
    3b00:      	ldr	x3, [x16, #0x10]
    3b04:      	add	x21, x20, x19
    3b08:      	cmp	x21, x3
    3b0c:      	b.le	0x3ec8 <_stogir.dominators.build+0x498>
    3b10:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    3b14:      	cmp	x3, x17
    3b18:      	b.gt	0x3b24 <_stogir.dominators.build+0xf4>
    3b1c:      	lsl	x3, x3, #1
    3b20:      	b	0x3b28 <_stogir.dominators.build+0xf8>
    3b24:      	mov	x3, x21
    3b28:      	cmp	x3, x21
    3b2c:      	b.gt	0x3b34 <_stogir.dominators.build+0x104>
    3b30:      	mov	x3, x21
    3b34:      	mov	x22, x8
    3b38:      	mov	x23, x0
    3b3c:      	mov	x0, x5
    3b40:      	mov	x24, x1
    3b44:      	mov	x1, x3
    3b48:      	mov	x25, x2
    3b4c:      	bl	0x3b4c <_stogir.dominators.build+0x11c>
		0000000000003b4c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3b50:      	add	x16, sp, #0x40
    3b54:      	orr	x26, x16, xzr
    3b58:      	add	x27, x23, #0x28
    3b5c:      	lsl	x0, x19, #2
    3b60:      	add	x16, sp, #0x10
    3b64:      	ldr	x1, [x16]
    3b68:      	add	x1, x1, x20, lsl #2
    3b6c:      	mov	x2, x0
    3b70:      	mov	x0, x1
    3b74:      	movz	x1, #0x0, lsl #48
    3b78:      	bl	0x3b78 <_stogir.dominators.build+0x148>
		0000000000003b78:  ARM64_RELOC_BRANCH26	_memset
    3b7c:      	add	x16, sp, #0x10
    3b80:      	str	x21, [x16, #0x8]
    3b84:      	movz	x19, #0x0, lsl #48
    3b88:      	b	0x3bc4 <_stogir.dominators.build+0x194>
    3b8c:      	nop
    3b90:      	lsl	x0, x0, #1
    3b94:      	mov	x1, x0
    3b98:      	mov	x0, x26
    3b9c:      	bl	0x3b9c <_stogir.dominators.build+0x16c>
		0000000000003b9c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    3ba0:      	add	x19, x19, #0x1
    3ba4:      	add	x0, x20, #0x1
    3ba8:      	add	x16, sp, #0x40
    3bac:      	ldr	x1, [x16]
    3bb0:      	add	x1, x1, x20, lsl #3
    3bb4:      	movn	x17, #0x0, lsl #48
    3bb8:      	str	x17, [x1]
    3bbc:      	add	x16, sp, #0x40
    3bc0:      	str	x0, [x16, #0x8]
    3bc4:      	ldr	x0, [x27, #0x8]
    3bc8:      	cmp	x19, x0
    3bcc:      	b.ge	0x3bfc <_stogir.dominators.build+0x1cc>
    3bd0:      	add	x16, sp, #0x40
    3bd4:      	ldr	x0, [x16, #0x8]
    3bd8:      	orr	x20, x0, xzr
    3bdc:      	add	x16, sp, #0x40
    3be0:      	ldr	x0, [x16, #0x10]
    3be4:      	cmp	x20, x0
    3be8:      	b.lt	0x3ba0 <_stogir.dominators.build+0x170>
    3bec:      	cmp	x0, #0x0
    3bf0:      	b.ne	0x3b90 <_stogir.dominators.build+0x160>
    3bf4:      	mov	x0, #0x2                ; =2
    3bf8:      	b	0x3b94 <_stogir.dominators.build+0x164>
    3bfc:      	movz	x0, #0x0, lsl #48
    3c00:      	b	0x3c30 <_stogir.dominators.build+0x200>
    3c04:      	nop
    3c08:      	add	x1, x0, #0x1
    3c0c:      	ldr	x2, [x25]
    3c10:      	add	x2, x2, x0, lsl #2
    3c14:      	ldr	w2, [x2]
    3c18:      	sxtw	x2, w2
    3c1c:      	add	x16, sp, #0x40
    3c20:      	ldr	x3, [x16]
    3c24:      	add	x2, x3, x2, lsl #3
    3c28:      	str	x0, [x2]
    3c2c:      	mov	x0, x1
    3c30:      	ldr	x1, [x25, #0x8]
    3c34:      	cmp	x0, x1
    3c38:      	b.lt	0x3c08 <_stogir.dominators.build+0x1d8>
    3c3c:      	cmp	x1, #0x0
    3c40:      	b.le	0x3dd0 <_stogir.dominators.build+0x3a0>
    3c44:      	ldr	x0, [x25]
    3c48:      	ldr	w0, [x0]
    3c4c:      	sxtw	x1, w0
    3c50:      	add	x16, sp, #0x10
    3c54:      	ldr	x2, [x16]
    3c58:      	add	x1, x2, x1, lsl #2
    3c5c:      	str	w0, [x1]
    3c60:      	b	0x3dc4 <_stogir.dominators.build+0x394>
    3c64:      	nop
    3c68:      	add	x16, sp, #0x10
    3c6c:      	ldr	x6, [x16]
    3c70:      	add	x6, x6, x11, lsl #2
    3c74:      	ldr	w6, [x6]
    3c78:      	add	x16, sp, #0x40
    3c7c:      	ldr	x9, [x16]
    3c80:      	orr	x10, x9, xzr
    3c84:      	sxtw	x11, w6
    3c88:      	add	x9, x8, x9
    3c8c:      	lsl	x12, x11, #3
    3c90:      	add	x10, x10, x11, lsl #3
    3c94:      	ldr	x10, [x10]
    3c98:      	ldr	x9, [x9]
    3c9c:      	cmp	x10, x9
    3ca0:      	b.gt	0x3c68 <_stogir.dominators.build+0x238>
    3ca4:      	b	0x3cb8 <_stogir.dominators.build+0x288>
    3ca8:      	add	x16, sp, #0x10
    3cac:      	ldr	x7, [x16]
    3cb0:      	add	x7, x7, x10, lsl #2
    3cb4:      	ldr	w7, [x7]
    3cb8:      	add	x16, sp, #0x40
    3cbc:      	ldr	x8, [x16]
    3cc0:      	orr	x9, x8, xzr
    3cc4:      	sxtw	x10, w7
    3cc8:      	add	x8, x12, x8
    3ccc:      	add	x9, x9, x10, lsl #3
    3cd0:      	ldr	x9, [x9]
    3cd4:      	ldr	x8, [x8]
    3cd8:      	cmp	x9, x8
    3cdc:      	b.gt	0x3ca8 <_stogir.dominators.build+0x278>
    3ce0:      	sxtw	x10, w6
    3ce4:      	sxtw	x8, w7
    3ce8:      	cmp	x10, x8
    3cec:      	b.eq	0x3cf8 <_stogir.dominators.build+0x2c8>
    3cf0:      	lsl	x8, x8, #3
    3cf4:      	b	0x3c78 <_stogir.dominators.build+0x248>
    3cf8:      	orr	w6, w10, wzr
    3cfc:      	add	x5, x5, #0x1
    3d00:      	sxtw	x7, w6
    3d04:      	cmp	x5, x3
    3d08:      	b.ge	0x3d58 <_stogir.dominators.build+0x328>
    3d0c:      	add	x8, x4, x5
    3d10:      	ldr	x9, [x24, #0x28]
    3d14:      	add	x8, x9, x8, lsl #3
    3d18:      	ldr	x8, [x8]
    3d1c:      	ldr	x9, [x23, #0x50]
    3d20:      	add	x8, x9, x8, lsl #4
    3d24:      	ldr	x8, [x8]
    3d28:      	add	x16, sp, #0x10
    3d2c:      	ldr	x9, [x16]
    3d30:      	sxtw	x10, w8
    3d34:      	add	x9, x9, x10, lsl #2
    3d38:      	ldr	w9, [x9]
    3d3c:      	sxtw	x9, w9
    3d40:      	cmp	x9, #0x0
    3d44:      	b.eq	0x3cfc <_stogir.dominators.build+0x2cc>
    3d48:      	cmp	x7, #0x0
    3d4c:      	b.eq	0x3cf8 <_stogir.dominators.build+0x2c8>
    3d50:      	orr	w7, w8, wzr
    3d54:      	b	0x3ce0 <_stogir.dominators.build+0x2b0>
    3d58:      	add	x16, sp, #0x10
    3d5c:      	ldr	x3, [x16]
    3d60:      	add	x4, x3, x2, lsl #2
    3d64:      	ldr	w4, [x4]
    3d68:      	sxtw	x4, w4
    3d6c:      	cmp	x4, x7
    3d70:      	b.eq	0x3d80 <_stogir.dominators.build+0x350>
    3d74:      	add	x1, x3, x2, lsl #2
    3d78:      	str	w6, [x1]
    3d7c:      	mov	x1, #0x1                ; =1
    3d80:      	add	x0, x0, #0x1
    3d84:      	ldr	x2, [x25, #0x8]
    3d88:      	cmp	x0, x2
    3d8c:      	b.ge	0x3dbc <_stogir.dominators.build+0x38c>
    3d90:      	ldr	x2, [x25]
    3d94:      	add	x2, x2, x0, lsl #2
    3d98:      	ldr	w2, [x2]
    3d9c:      	sxtw	x2, w2
    3da0:      	ldr	x3, [x24]
    3da4:      	add	x3, x3, x2, lsl #4
    3da8:      	ldr	x4, [x3]
    3dac:      	ldr	x3, [x3, #0x8]
    3db0:      	movz	x5, #0x0, lsl #48
    3db4:      	movz	w6, #0x0, lsl #16
    3db8:      	b	0x3d00 <_stogir.dominators.build+0x2d0>
    3dbc:      	cmp	x1, #0x0
    3dc0:      	b.eq	0x3dd0 <_stogir.dominators.build+0x3a0>
    3dc4:      	mov	x0, #0x1                ; =1
    3dc8:      	movz	x1, #0x0, lsl #48
    3dcc:      	b	0x3d84 <_stogir.dominators.build+0x354>
    3dd0:      	b	0x3de4 <_stogir.dominators.build+0x3b4>
    3dd4:      	nop
    3dd8:      	sub	x0, x0, #0x1
    3ddc:      	add	x16, sp, #0x40
    3de0:      	str	x0, [x16, #0x8]
    3de4:      	add	x16, sp, #0x40
    3de8:      	ldr	x0, [x16, #0x8]
    3dec:      	cmp	x0, #0x0
    3df0:      	b.ne	0x3dd8 <_stogir.dominators.build+0x3a8>
    3df4:      	add	x16, sp, #0x40
    3df8:      	ldr	x0, [x16, #0x10]
    3dfc:      	cmp	x0, #0x0
    3e00:      	b.le	0x3e34 <_stogir.dominators.build+0x404>
    3e04:      	add	x1, x26, #0x18
    3e08:      	add	x16, sp, #0x40
    3e0c:      	ldr	x2, [x16]
    3e10:      	fmov	d31, x0
    3e14:      	mov	x0, x1
    3e18:      	mov	x1, x2
    3e1c:      	fmov	x2, d31
    3e20:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003e20:  ARM64_RELOC_PAGE21	l_stogir.417
    3e24:      	ldr	x3, [x3]
		0000000000003e24:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    3e28:      	mov	x4, #0x8                ; =8
    3e2c:      	mov	x5, #0x8                ; =8
    3e30:      	bl	0x3e30 <_stogir.dominators.build+0x400>
		0000000000003e30:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3e34:      	add	x16, sp, #0x40
    3e38:      	movz	x17, #0x0, lsl #48
    3e3c:      	str	x17, [x16]
    3e40:      	add	x16, sp, #0x40
    3e44:      	movz	x17, #0x0, lsl #48
    3e48:      	str	x17, [x16, #0x8]
    3e4c:      	add	x16, sp, #0x40
    3e50:      	movz	x17, #0x0, lsl #48
    3e54:      	str	x17, [x16, #0x10]
    3e58:      	add	x16, sp, #0x10
    3e5c:      	ldr	x0, [x16]
    3e60:      	add	x16, sp, #0x10
    3e64:      	ldr	x1, [x16, #0x8]
    3e68:      	add	x16, sp, #0x10
    3e6c:      	ldr	x2, [x16, #0x10]
    3e70:      	add	x16, sp, #0x10
    3e74:      	ldr	x3, [x16, #0x18]
    3e78:      	add	x16, sp, #0x10
    3e7c:      	ldr	x4, [x16, #0x20]
    3e80:      	str	x0, [x22]
    3e84:      	str	x1, [x22, #0x8]
    3e88:      	str	x2, [x22, #0x10]
    3e8c:      	str	x3, [x22, #0x18]
    3e90:      	str	x4, [x22, #0x20]
    3e94:      	ldr	x19, [sp, #0x70]
    3e98:      	ldr	x20, [sp, #0x78]
    3e9c:      	ldr	x21, [sp, #0x80]
    3ea0:      	ldr	x22, [sp, #0x88]
    3ea4:      	ldr	x23, [sp, #0x90]
    3ea8:      	ldr	x24, [sp, #0x98]
    3eac:      	ldr	x25, [sp, #0xa0]
    3eb0:      	ldr	x26, [sp, #0xa8]
    3eb4:      	ldr	x27, [sp, #0xb0]
    3eb8:      	ldr	x29, [sp]
    3ebc:      	ldr	x30, [sp, #0x8]
    3ec0:      	add	sp, sp, #0xc0
    3ec4:      	ret
    3ec8:      	mov	x22, x8
    3ecc:      	mov	x23, x0
    3ed0:      	mov	x24, x1
    3ed4:      	mov	x25, x2
    3ed8:      	b	0x3b50 <_stogir.dominators.build+0x120>
    3edc:      	udf	#0x0

0000000000003ee0 <_stogir.loops.depths>:
    3ee0:      	sub	sp, sp, #0x1f0
    3ee4:      	str	x29, [sp]
    3ee8:      	str	x30, [sp, #0x8]
    3eec:      	mov	x29, sp
    3ef0:      	str	x19, [sp, #0x1a0]
    3ef4:      	str	x20, [sp, #0x1a8]
    3ef8:      	str	x21, [sp, #0x1b0]
    3efc:      	str	x22, [sp, #0x1b8]
    3f00:      	str	x23, [sp, #0x1c0]
    3f04:      	str	x24, [sp, #0x1c8]
    3f08:      	str	x25, [sp, #0x1d0]
    3f0c:      	str	x26, [sp, #0x1d8]
    3f10:      	str	x27, [sp, #0x1e0]
    3f14:      	str	x28, [sp, #0x1e8]
    3f18:      	add	x19, x0, #0x28
    3f1c:      	add	x16, sp, #0xb0
    3f20:      	orr	x20, x16, xzr
    3f24:      	mov	x21, x8
    3f28:      	add	x8, sp, #0x60
    3f2c:      	mov	x22, x0
    3f30:      	mov	x0, x2
    3f34:      	mov	x23, x1
    3f38:      	mov	x1, x3
    3f3c:      	mov	x24, x2
    3f40:      	mov	x25, x3
    3f44:      	bl	0x3f44 <_stogir.loops.depths+0x64>
		0000000000003f44:  ARM64_RELOC_BRANCH26	_stogir.dominators.build-index
    3f48:      	add	x16, sp, #0x60
    3f4c:      	ldr	x0, [x16]
    3f50:      	add	x16, sp, #0x10
    3f54:      	str	x0, [x16]
    3f58:      	add	x16, sp, #0x60
    3f5c:      	ldr	x0, [x16, #0x8]
    3f60:      	add	x16, sp, #0x10
    3f64:      	str	x0, [x16, #0x8]
    3f68:      	add	x16, sp, #0x60
    3f6c:      	ldr	x0, [x16, #0x10]
    3f70:      	add	x16, sp, #0x10
    3f74:      	str	x0, [x16, #0x10]
    3f78:      	add	x16, sp, #0x60
    3f7c:      	ldr	x0, [x16, #0x18]
    3f80:      	add	x16, sp, #0x10
    3f84:      	str	x0, [x16, #0x18]
    3f88:      	add	x16, sp, #0x60
    3f8c:      	ldr	x0, [x16, #0x20]
    3f90:      	add	x16, sp, #0x10
    3f94:      	str	x0, [x16, #0x20]
    3f98:      	add	x16, sp, #0x60
    3f9c:      	ldr	x0, [x16, #0x28]
    3fa0:      	add	x16, sp, #0x10
    3fa4:      	str	x0, [x16, #0x28]
    3fa8:      	add	x16, sp, #0x60
    3fac:      	ldr	x0, [x16, #0x30]
    3fb0:      	add	x16, sp, #0x10
    3fb4:      	str	x0, [x16, #0x30]
    3fb8:      	add	x16, sp, #0x60
    3fbc:      	ldr	x0, [x16, #0x38]
    3fc0:      	add	x16, sp, #0x10
    3fc4:      	str	x0, [x16, #0x38]
    3fc8:      	add	x16, sp, #0x60
    3fcc:      	ldr	x0, [x16, #0x40]
    3fd0:      	add	x16, sp, #0x10
    3fd4:      	str	x0, [x16, #0x40]
    3fd8:      	add	x16, sp, #0x60
    3fdc:      	ldr	x0, [x16, #0x48]
    3fe0:      	add	x16, sp, #0x10
    3fe4:      	str	x0, [x16, #0x48]
    3fe8:      	ldr	x0, [x25]
    3fec:      	ldr	x1, [x25, #0x8]
    3ff0:      	add	x16, sp, #0xb0
    3ff4:      	movz	x17, #0x0, lsl #48
    3ff8:      	str	x17, [x16]
    3ffc:      	add	x16, sp, #0xb0
    4000:      	movz	x17, #0x0, lsl #48
    4004:      	str	x17, [x16, #0x8]
    4008:      	add	x16, sp, #0xb0
    400c:      	movz	x17, #0x0, lsl #48
    4010:      	str	x17, [x16, #0x10]
    4014:      	add	x16, sp, #0xb0
    4018:      	str	x0, [x16, #0x18]
    401c:      	add	x16, sp, #0xb0
    4020:      	str	x1, [x16, #0x20]
    4024:      	ldr	x0, [x25]
    4028:      	ldr	x1, [x25, #0x8]
    402c:      	add	x16, sp, #0xe0
    4030:      	movz	x17, #0x0, lsl #48
    4034:      	str	x17, [x16]
    4038:      	add	x16, sp, #0xe0
    403c:      	movz	x17, #0x0, lsl #48
    4040:      	str	x17, [x16, #0x8]
    4044:      	add	x16, sp, #0xe0
    4048:      	movz	x17, #0x0, lsl #48
    404c:      	str	x17, [x16, #0x10]
    4050:      	add	x16, sp, #0xe0
    4054:      	str	x0, [x16, #0x18]
    4058:      	add	x16, sp, #0xe0
    405c:      	str	x1, [x16, #0x20]
    4060:      	ldr	x0, [x25]
    4064:      	ldr	x1, [x25, #0x8]
    4068:      	add	x16, sp, #0x110
    406c:      	movz	x17, #0x0, lsl #48
    4070:      	str	x17, [x16]
    4074:      	add	x16, sp, #0x110
    4078:      	movz	x17, #0x0, lsl #48
    407c:      	str	x17, [x16, #0x8]
    4080:      	add	x16, sp, #0x110
    4084:      	movz	x17, #0x0, lsl #48
    4088:      	str	x17, [x16, #0x10]
    408c:      	add	x16, sp, #0x110
    4090:      	str	x0, [x16, #0x18]
    4094:      	add	x16, sp, #0x110
    4098:      	str	x1, [x16, #0x20]
    409c:      	ldr	x0, [x19, #0x8]
    40a0:      	orr	x25, x0, xzr
    40a4:      	add	x16, sp, #0xb0
    40a8:      	ldr	x0, [x16, #0x8]
    40ac:      	orr	x26, x0, xzr
    40b0:      	add	x16, sp, #0xb0
    40b4:      	ldr	x0, [x16, #0x10]
    40b8:      	add	x27, x26, x25
    40bc:      	cmp	x27, x0
    40c0:      	b.le	0x40f4 <_stogir.loops.depths+0x214>
    40c4:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    40c8:      	cmp	x0, x17
    40cc:      	b.gt	0x40d8 <_stogir.loops.depths+0x1f8>
    40d0:      	lsl	x0, x0, #1
    40d4:      	b	0x40dc <_stogir.loops.depths+0x1fc>
    40d8:      	mov	x0, x27
    40dc:      	cmp	x0, x27
    40e0:      	b.gt	0x40e8 <_stogir.loops.depths+0x208>
    40e4:      	mov	x0, x27
    40e8:      	mov	x1, x0
    40ec:      	mov	x0, x20
    40f0:      	bl	0x40f0 <_stogir.loops.depths+0x210>
		00000000000040f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    40f4:      	add	x16, sp, #0x10
    40f8:      	orr	x20, x16, xzr
    40fc:      	add	x16, sp, #0xe0
    4100:      	orr	x28, x16, xzr
    4104:      	add	x16, sp, #0x110
    4108:      	orr	x0, x16, xzr
    410c:      	lsl	x1, x25, #2
    4110:      	add	x16, sp, #0xb0
    4114:      	ldr	x2, [x16]
    4118:      	add	x2, x2, x26, lsl #2
    411c:      	mov	x25, x0
    4120:      	mov	x0, x2
    4124:      	mov	x2, x1
    4128:      	movz	x1, #0x0, lsl #48
    412c:      	bl	0x412c <_stogir.loops.depths+0x24c>
		000000000000412c:  ARM64_RELOC_BRANCH26	_memset
    4130:      	add	x16, sp, #0xb0
    4134:      	str	x27, [x16, #0x8]
    4138:      	ldr	x0, [x19, #0x8]
    413c:      	mov	x1, x0
    4140:      	mov	x0, x28
    4144:      	bl	0x4144 <_stogir.loops.depths+0x264>
		0000000000004144:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    4148:      	ldr	x0, [x22]
    414c:      	orr	x19, x0, xzr
    4150:      	ldr	x0, [x22, #0x8]
    4154:      	orr	x26, x0, xzr
    4158:      	movz	x27, #0x0, lsl #48
    415c:      	b	0x42dc <_stogir.loops.depths+0x3fc>
    4160:      	lsl	x3, x3, #1
    4164:      	str	x19, [sp, #0x188]
    4168:      	mov	x19, x0
    416c:      	mov	x0, x25
    4170:      	str	w20, [sp, #0x190]
    4174:      	mov	w20, w1
    4178:      	mov	x1, x3
    417c:      	str	x22, [sp, #0x198]
    4180:      	mov	x22, x2
    4184:      	bl	0x4184 <_stogir.loops.depths+0x2a4>
		0000000000004184:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4188:      	add	x0, x22, #0x1
    418c:      	add	x16, sp, #0x110
    4190:      	ldr	x1, [x16]
    4194:      	add	x1, x1, x22, lsl #2
    4198:      	str	w20, [x1]
    419c:      	add	x16, sp, #0x110
    41a0:      	str	x0, [x16, #0x8]
    41a4:      	b	0x41b8 <_stogir.loops.depths+0x2d8>
    41a8:      	str	x22, [sp, #0x198]
    41ac:      	str	x19, [sp, #0x188]
    41b0:      	mov	x19, x0
    41b4:      	str	w20, [sp, #0x190]
    41b8:      	add	x19, x19, #0x1
    41bc:      	ldr	x22, [sp, #0x198]
    41c0:      	ldr	w20, [sp, #0x190]
    41c4:      	mov	x0, x19
    41c8:      	ldr	x19, [sp, #0x188]
    41cc:      	cmp	x0, x27
    41d0:      	b.ge	0x4760 <_stogir.loops.depths+0x880>
    41d4:      	add	x1, x26, x0
    41d8:      	ldr	x2, [x23, #0x28]
    41dc:      	add	x1, x2, x1, lsl #3
    41e0:      	ldr	x1, [x1]
    41e4:      	ldr	x2, [x22, #0x50]
    41e8:      	add	x1, x2, x1, lsl #4
    41ec:      	ldr	x1, [x1]
    41f0:      	ldr	x2, [x24]
    41f4:      	sxtw	x3, w1
    41f8:      	add	x2, x2, x3, lsl #2
    41fc:      	ldr	w2, [x2]
    4200:      	sxtw	x2, w2
    4204:      	cmp	x2, #0x0
    4208:      	b.eq	0x41a8 <_stogir.loops.depths+0x2c8>
    420c:      	add	x16, sp, #0xe0
    4210:      	ldr	x2, [x16]
    4214:      	add	x4, x2, x3, lsl #2
    4218:      	ldr	w4, [x4]
    421c:      	sxtw	x4, w4
    4220:      	cmp	x4, x19
    4224:      	b.eq	0x4770 <_stogir.loops.depths+0x890>
    4228:      	add	x2, x2, x3, lsl #2
    422c:      	str	w20, [x2]
    4230:      	add	x16, sp, #0xb0
    4234:      	ldr	x2, [x16]
    4238:      	orr	x4, x2, xzr
    423c:      	add	x4, x4, x3, lsl #2
    4240:      	add	x2, x2, x3, lsl #2
    4244:      	ldr	w3, [x4]
    4248:      	add	w3, w3, #0x1
    424c:      	str	w3, [x2]
    4250:      	add	x16, sp, #0x110
    4254:      	ldr	x2, [x16, #0x8]
    4258:      	add	x16, sp, #0x110
    425c:      	ldr	x3, [x16, #0x10]
    4260:      	cmp	x2, x3
    4264:      	b.lt	0x4784 <_stogir.loops.depths+0x8a4>
    4268:      	cmp	x3, #0x0
    426c:      	b.ne	0x4160 <_stogir.loops.depths+0x280>
    4270:      	mov	x3, #0x2                ; =2
    4274:      	b	0x4164 <_stogir.loops.depths+0x284>
    4278:      	add	x21, x21, #0x1
    427c:      	ldr	x22, [sp, #0x198]
    4280:      	ldr	x19, [sp, #0x188]
    4284:      	ldr	w20, [sp, #0x190]
    4288:      	add	x16, sp, #0x110
    428c:      	ldr	x0, [x16, #0x8]
    4290:      	cmp	x21, x0
    4294:      	b.ge	0x47a0 <_stogir.loops.depths+0x8c0>
    4298:      	add	x16, sp, #0x110
    429c:      	ldr	x0, [x16]
    42a0:      	add	x0, x0, x21, lsl #2
    42a4:      	ldr	w0, [x0]
    42a8:      	sxtw	x0, w0
    42ac:      	ldr	x1, [x23]
    42b0:      	add	x0, x1, x0, lsl #4
    42b4:      	ldr	x26, [x0]
    42b8:      	ldr	x27, [x0, #0x8]
    42bc:      	movz	x0, #0x0, lsl #48
    42c0:      	b	0x41cc <_stogir.loops.depths+0x2ec>
    42c4:      	ldr	x21, [sp, #0x180]
    42c8:      	ldr	x22, [sp, #0x198]
    42cc:      	ldr	x20, [sp, #0x148]
    42d0:      	ldr	x19, [sp, #0x140]
    42d4:      	ldr	x26, [sp, #0x170]
    42d8:      	ldr	x27, [sp, #0x178]
    42dc:      	cmp	x27, x26
    42e0:      	b.ge	0x4304 <_stogir.loops.depths+0x424>
    42e4:      	add	x0, x27, #0x1
    42e8:      	add	x1, x19, x27, lsl #2
    42ec:      	ldr	w1, [x1]
    42f0:      	movn	w17, #0x0, lsl #16
    42f4:      	and	w1, w1, w17
    42f8:      	mov	x27, x0
    42fc:      	mov	w0, #0x1                ; =1
    4300:      	b	0x430c <_stogir.loops.depths+0x42c>
    4304:      	movz	w0, #0x0, lsl #16
    4308:      	movz	w1, #0x0, lsl #16
    430c:      	ubfx	x0, x0, #0, #32
    4310:      	lsr	x16, x0, #0
    4314:      	cmp	x16, #0x1
    4318:      	b.eq	0x433c <_stogir.loops.depths+0x45c>
    431c:      	b.lo	0x4324 <_stogir.loops.depths+0x444>
    4320:      	b	0x4340 <_stogir.loops.depths+0x460>
    4324:      	cmp	x16, #0x0
    4328:      	b.eq	0x4330 <_stogir.loops.depths+0x450>
    432c:      	b	0x4340 <_stogir.loops.depths+0x460>
    4330:      	str	x21, [sp, #0x180]
    4334:      	str	x20, [sp, #0x148]
    4338:      	b	0x4344 <_stogir.loops.depths+0x464>
    433c:      	b	0x44dc <_stogir.loops.depths+0x5fc>
    4340:      	b	0x4708 <_stogir.loops.depths+0x828>
    4344:      	ldr	x0, [sp, #0x148]
    4348:      	bl	0x4348 <_stogir.loops.depths+0x468>
		0000000000004348:  ARM64_RELOC_BRANCH26	_stogir.dominators.release-index!
    434c:      	b	0x435c <_stogir.loops.depths+0x47c>
    4350:      	sub	x0, x0, #0x1
    4354:      	add	x16, sp, #0xe0
    4358:      	str	x0, [x16, #0x8]
    435c:      	add	x16, sp, #0xe0
    4360:      	ldr	x0, [x16, #0x8]
    4364:      	cmp	x0, #0x0
    4368:      	b.ne	0x4350 <_stogir.loops.depths+0x470>
    436c:      	add	x16, sp, #0xe0
    4370:      	ldr	x0, [x16, #0x10]
    4374:      	cmp	x0, #0x0
    4378:      	b.le	0x43ac <_stogir.loops.depths+0x4cc>
    437c:      	add	x1, x28, #0x18
    4380:      	add	x16, sp, #0xe0
    4384:      	ldr	x2, [x16]
    4388:      	fmov	d31, x0
    438c:      	mov	x0, x1
    4390:      	mov	x1, x2
    4394:      	fmov	x2, d31
    4398:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x120>
		0000000000004398:  ARM64_RELOC_PAGE21	l_stogir.418
    439c:      	ldr	x3, [x3]
		000000000000439c:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    43a0:      	mov	x4, #0x4                ; =4
    43a4:      	mov	x5, #0x4                ; =4
    43a8:      	bl	0x43a8 <_stogir.loops.depths+0x4c8>
		00000000000043a8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    43ac:      	add	x16, sp, #0xe0
    43b0:      	movz	x17, #0x0, lsl #48
    43b4:      	str	x17, [x16]
    43b8:      	add	x16, sp, #0xe0
    43bc:      	movz	x17, #0x0, lsl #48
    43c0:      	str	x17, [x16, #0x8]
    43c4:      	add	x16, sp, #0xe0
    43c8:      	movz	x17, #0x0, lsl #48
    43cc:      	str	x17, [x16, #0x10]
    43d0:      	b	0x43e4 <_stogir.loops.depths+0x504>
    43d4:      	nop
    43d8:      	sub	x0, x0, #0x1
    43dc:      	add	x16, sp, #0x110
    43e0:      	str	x0, [x16, #0x8]
    43e4:      	add	x16, sp, #0x110
    43e8:      	ldr	x0, [x16, #0x8]
    43ec:      	cmp	x0, #0x0
    43f0:      	b.ne	0x43d8 <_stogir.loops.depths+0x4f8>
    43f4:      	add	x16, sp, #0x110
    43f8:      	ldr	x0, [x16, #0x10]
    43fc:      	cmp	x0, #0x0
    4400:      	b.le	0x4434 <_stogir.loops.depths+0x554>
    4404:      	add	x1, x25, #0x18
    4408:      	add	x16, sp, #0x110
    440c:      	ldr	x2, [x16]
    4410:      	fmov	d31, x0
    4414:      	mov	x0, x1
    4418:      	mov	x1, x2
    441c:      	fmov	x2, d31
    4420:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x120>
		0000000000004420:  ARM64_RELOC_PAGE21	l_stogir.418
    4424:      	ldr	x3, [x3]
		0000000000004424:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    4428:      	mov	x4, #0x4                ; =4
    442c:      	mov	x5, #0x4                ; =4
    4430:      	bl	0x4430 <_stogir.loops.depths+0x550>
		0000000000004430:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4434:      	add	x16, sp, #0x110
    4438:      	movz	x17, #0x0, lsl #48
    443c:      	str	x17, [x16]
    4440:      	add	x16, sp, #0x110
    4444:      	movz	x17, #0x0, lsl #48
    4448:      	str	x17, [x16, #0x8]
    444c:      	add	x16, sp, #0x110
    4450:      	movz	x17, #0x0, lsl #48
    4454:      	str	x17, [x16, #0x10]
    4458:      	add	x16, sp, #0xb0
    445c:      	ldr	x0, [x16]
    4460:      	add	x16, sp, #0xb0
    4464:      	ldr	x1, [x16, #0x8]
    4468:      	add	x16, sp, #0xb0
    446c:      	ldr	x2, [x16, #0x10]
    4470:      	add	x16, sp, #0xb0
    4474:      	ldr	x3, [x16, #0x18]
    4478:      	add	x16, sp, #0xb0
    447c:      	ldr	x4, [x16, #0x20]
    4480:      	ldr	x5, [sp, #0x180]
    4484:      	str	x0, [x5]
    4488:      	str	x1, [x5, #0x8]
    448c:      	str	x2, [x5, #0x10]
    4490:      	str	x3, [x5, #0x18]
    4494:      	str	x4, [x5, #0x20]
    4498:      	ldr	x19, [sp, #0x1a0]
    449c:      	ldr	x20, [sp, #0x1a8]
    44a0:      	ldr	x21, [sp, #0x1b0]
    44a4:      	ldr	x22, [sp, #0x1b8]
    44a8:      	ldr	x23, [sp, #0x1c0]
    44ac:      	ldr	x24, [sp, #0x1c8]
    44b0:      	ldr	x25, [sp, #0x1d0]
    44b4:      	ldr	x26, [sp, #0x1d8]
    44b8:      	ldr	x27, [sp, #0x1e0]
    44bc:      	ldr	x28, [sp, #0x1e8]
    44c0:      	ldr	x29, [sp]
    44c4:      	ldr	x30, [sp, #0x8]
    44c8:      	add	sp, sp, #0x1f0
    44cc:      	ret
    44d0:      	sub	x0, x0, #0x1
    44d4:      	add	x16, sp, #0x110
    44d8:      	str	x0, [x16, #0x8]
    44dc:      	add	x16, sp, #0x110
    44e0:      	ldr	x0, [x16, #0x8]
    44e4:      	cmp	x0, #0x0
    44e8:      	b.ne	0x44d0 <_stogir.loops.depths+0x5f0>
    44ec:      	sxtw	x0, w1
    44f0:      	lsl	x2, x0, #2
    44f4:      	cmp	x0, #0x0
    44f8:      	cset	w3, gt
    44fc:      	add	x16, sp, #0xe0
    4500:      	ldr	x4, [x16]
    4504:      	add	x4, x4, x0, lsl #2
    4508:      	str	w1, [x4]
    450c:      	ldr	x4, [x23]
    4510:      	add	x4, x4, x0, lsl #4
    4514:      	ldr	x5, [x4]
    4518:      	ldr	x4, [x4, #0x8]
    451c:      	movz	x6, #0x0, lsl #48
    4520:      	movz	x7, #0x0, lsl #48
    4524:      	b	0x45c4 <_stogir.loops.depths+0x6e4>
    4528:      	lsl	x9, x9, #1
    452c:      	str	x2, [sp, #0x150]
    4530:      	str	w3, [sp, #0x158]
    4534:      	str	x5, [sp, #0x160]
    4538:      	str	x4, [sp, #0x168]
    453c:      	str	x19, [sp, #0x140]
    4540:      	mov	x19, x0
    4544:      	mov	x0, x25
    4548:      	str	x20, [sp, #0x148]
    454c:      	mov	w20, w1
    4550:      	mov	x1, x9
    4554:      	str	x26, [sp, #0x170]
    4558:      	mov	x26, x6
    455c:      	str	x27, [sp, #0x178]
    4560:      	mov	w27, w8
    4564:      	str	x21, [sp, #0x180]
    4568:      	mov	x21, x7
    456c:      	bl	0x456c <_stogir.loops.depths+0x68c>
		000000000000456c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4570:      	add	x0, x21, #0x1
    4574:      	add	x16, sp, #0x110
    4578:      	ldr	x1, [x16]
    457c:      	add	x1, x1, x21, lsl #2
    4580:      	str	w27, [x1]
    4584:      	add	x16, sp, #0x110
    4588:      	str	x0, [x16, #0x8]
    458c:      	mov	x7, #0x1                ; =1
    4590:      	add	x26, x26, #0x1
    4594:      	ldr	x21, [sp, #0x180]
    4598:      	mov	x0, x19
    459c:      	mov	w1, w20
    45a0:      	ldr	x20, [sp, #0x148]
    45a4:      	ldr	x5, [sp, #0x160]
    45a8:      	ldr	x4, [sp, #0x168]
    45ac:      	ldr	x2, [sp, #0x150]
    45b0:      	ldr	w3, [sp, #0x158]
    45b4:      	ldr	x19, [sp, #0x140]
    45b8:      	ldr	x27, [sp, #0x178]
    45bc:      	mov	x6, x26
    45c0:      	ldr	x26, [sp, #0x170]
    45c4:      	cmp	x6, x4
    45c8:      	b.ge	0x47a8 <_stogir.loops.depths+0x8c8>
    45cc:      	add	x8, x5, x6
    45d0:      	ldr	x9, [x23, #0x28]
    45d4:      	add	x8, x9, x8, lsl #3
    45d8:      	ldr	x8, [x8]
    45dc:      	ldr	x9, [x22, #0x50]
    45e0:      	add	x8, x9, x8, lsl #4
    45e4:      	ldr	x8, [x8]
    45e8:      	uxtb	w16, w3
    45ec:      	cmp	w16, wzr
    45f0:      	b.eq	0x47c8 <_stogir.loops.depths+0x8e8>
    45f4:      	sxtw	x9, w8
    45f8:      	cmp	x9, #0x0
    45fc:      	b.le	0x47fc <_stogir.loops.depths+0x91c>
    4600:      	add	x16, sp, #0x10
    4604:      	ldr	x10, [x16, #0x8]
    4608:      	cmp	x0, x10
    460c:      	b.ge	0x4830 <_stogir.loops.depths+0x950>
    4610:      	cmp	x9, x10
    4614:      	b.ge	0x4864 <_stogir.loops.depths+0x984>
    4618:      	add	x16, sp, #0x10
    461c:      	ldr	x10, [x16]
    4620:      	add	x11, x2, x10
    4624:      	ldr	w11, [x11]
    4628:      	sxtw	x11, w11
    462c:      	cmp	x11, #0x0
    4630:      	b.le	0x4898 <_stogir.loops.depths+0x9b8>
    4634:      	lsl	x12, x9, #2
    4638:      	add	x9, x10, x9, lsl #2
    463c:      	ldr	w9, [x9]
    4640:      	sxtw	x9, w9
    4644:      	cmp	x9, #0x0
    4648:      	b.le	0x48cc <_stogir.loops.depths+0x9ec>
    464c:      	cmp	x11, x9
    4650:      	b.gt	0x4900 <_stogir.loops.depths+0xa20>
    4654:      	add	x16, sp, #0x10
    4658:      	ldr	x9, [x16, #0x28]
    465c:      	orr	x10, x9, xzr
    4660:      	add	x10, x2, x10
    4664:      	add	x9, x12, x9
    4668:      	ldr	w10, [x10]
    466c:      	sxtw	x10, w10
    4670:      	ldr	w9, [x9]
    4674:      	sxtw	x9, w9
    4678:      	cmp	x10, x9
    467c:      	b.lt	0x4934 <_stogir.loops.depths+0xa54>
    4680:      	cmp	x7, #0x0
    4684:      	b.ne	0x46a8 <_stogir.loops.depths+0x7c8>
    4688:      	add	x16, sp, #0xb0
    468c:      	ldr	x7, [x16]
    4690:      	orr	x9, x7, xzr
    4694:      	add	x9, x2, x9
    4698:      	add	x7, x2, x7
    469c:      	ldr	w9, [x9]
    46a0:      	add	w9, w9, #0x1
    46a4:      	str	w9, [x7]
    46a8:      	add	x16, sp, #0xe0
    46ac:      	ldr	x7, [x16]
    46b0:      	add	x9, x12, x7
    46b4:      	ldr	w9, [x9]
    46b8:      	sxtw	x9, w9
    46bc:      	cmp	x9, x0
    46c0:      	b.ne	0x4710 <_stogir.loops.depths+0x830>
    46c4:      	str	x21, [sp, #0x180]
    46c8:      	str	x20, [sp, #0x148]
    46cc:      	mov	w20, w1
    46d0:      	str	x5, [sp, #0x160]
    46d4:      	str	x4, [sp, #0x168]
    46d8:      	str	x2, [sp, #0x150]
    46dc:      	str	w3, [sp, #0x158]
    46e0:      	str	x19, [sp, #0x140]
    46e4:      	mov	x19, x0
    46e8:      	str	x26, [sp, #0x170]
    46ec:      	mov	x26, x6
    46f0:      	str	x27, [sp, #0x178]
    46f4:      	b	0x458c <_stogir.loops.depths+0x6ac>
    46f8:      	cmp	x7, #0x0
    46fc:      	b.eq	0x4968 <_stogir.loops.depths+0xa88>
    4700:      	movz	x21, #0x0, lsl #48
    4704:      	b	0x4288 <_stogir.loops.depths+0x3a8>
    4708:      	brk	#0
    470c:      	b	0x4708 <_stogir.loops.depths+0x828>
    4710:      	add	x7, x12, x7
    4714:      	str	w1, [x7]
    4718:      	add	x16, sp, #0xb0
    471c:      	ldr	x7, [x16]
    4720:      	orr	x9, x7, xzr
    4724:      	add	x9, x12, x9
    4728:      	add	x7, x12, x7
    472c:      	ldr	w9, [x9]
    4730:      	add	w9, w9, #0x1
    4734:      	str	w9, [x7]
    4738:      	add	x16, sp, #0x110
    473c:      	ldr	x7, [x16, #0x8]
    4740:      	add	x16, sp, #0x110
    4744:      	ldr	x9, [x16, #0x10]
    4748:      	cmp	x7, x9
    474c:      	b.lt	0x4970 <_stogir.loops.depths+0xa90>
    4750:      	cmp	x9, #0x0
    4754:      	b.ne	0x4528 <_stogir.loops.depths+0x648>
    4758:      	mov	x9, #0x2                ; =2
    475c:      	b	0x452c <_stogir.loops.depths+0x64c>
    4760:      	str	x22, [sp, #0x198]
    4764:      	str	x19, [sp, #0x188]
    4768:      	str	w20, [sp, #0x190]
    476c:      	b	0x4278 <_stogir.loops.depths+0x398>
    4770:      	str	x22, [sp, #0x198]
    4774:      	str	x19, [sp, #0x188]
    4778:      	mov	x19, x0
    477c:      	str	w20, [sp, #0x190]
    4780:      	b	0x41b8 <_stogir.loops.depths+0x2d8>
    4784:      	str	x22, [sp, #0x198]
    4788:      	str	x19, [sp, #0x188]
    478c:      	mov	x19, x0
    4790:      	str	w20, [sp, #0x190]
    4794:      	mov	w20, w1
    4798:      	mov	x22, x2
    479c:      	b	0x4188 <_stogir.loops.depths+0x2a8>
    47a0:      	str	x22, [sp, #0x198]
    47a4:      	b	0x42c4 <_stogir.loops.depths+0x3e4>
    47a8:      	str	x21, [sp, #0x180]
    47ac:      	str	x20, [sp, #0x148]
    47b0:      	mov	w20, w1
    47b4:      	str	x19, [sp, #0x140]
    47b8:      	mov	x19, x0
    47bc:      	str	x26, [sp, #0x170]
    47c0:      	str	x27, [sp, #0x178]
    47c4:      	b	0x46f8 <_stogir.loops.depths+0x818>
    47c8:      	str	x21, [sp, #0x180]
    47cc:      	str	x20, [sp, #0x148]
    47d0:      	mov	w20, w1
    47d4:      	str	x5, [sp, #0x160]
    47d8:      	str	x4, [sp, #0x168]
    47dc:      	str	x2, [sp, #0x150]
    47e0:      	str	w3, [sp, #0x158]
    47e4:      	str	x19, [sp, #0x140]
    47e8:      	mov	x19, x0
    47ec:      	str	x26, [sp, #0x170]
    47f0:      	mov	x26, x6
    47f4:      	str	x27, [sp, #0x178]
    47f8:      	b	0x4590 <_stogir.loops.depths+0x6b0>
    47fc:      	str	x21, [sp, #0x180]
    4800:      	str	x20, [sp, #0x148]
    4804:      	mov	w20, w1
    4808:      	str	x5, [sp, #0x160]
    480c:      	str	x4, [sp, #0x168]
    4810:      	str	x2, [sp, #0x150]
    4814:      	str	w3, [sp, #0x158]
    4818:      	str	x19, [sp, #0x140]
    481c:      	mov	x19, x0
    4820:      	str	x26, [sp, #0x170]
    4824:      	mov	x26, x6
    4828:      	str	x27, [sp, #0x178]
    482c:      	b	0x4590 <_stogir.loops.depths+0x6b0>
    4830:      	str	x21, [sp, #0x180]
    4834:      	str	x20, [sp, #0x148]
    4838:      	mov	w20, w1
    483c:      	str	x5, [sp, #0x160]
    4840:      	str	x4, [sp, #0x168]
    4844:      	str	x2, [sp, #0x150]
    4848:      	str	w3, [sp, #0x158]
    484c:      	str	x19, [sp, #0x140]
    4850:      	mov	x19, x0
    4854:      	str	x26, [sp, #0x170]
    4858:      	mov	x26, x6
    485c:      	str	x27, [sp, #0x178]
    4860:      	b	0x4590 <_stogir.loops.depths+0x6b0>
    4864:      	str	x21, [sp, #0x180]
    4868:      	str	x20, [sp, #0x148]
    486c:      	mov	w20, w1
    4870:      	str	x5, [sp, #0x160]
    4874:      	str	x4, [sp, #0x168]
    4878:      	str	x2, [sp, #0x150]
    487c:      	str	w3, [sp, #0x158]
    4880:      	str	x19, [sp, #0x140]
    4884:      	mov	x19, x0
    4888:      	str	x26, [sp, #0x170]
    488c:      	mov	x26, x6
    4890:      	str	x27, [sp, #0x178]
    4894:      	b	0x4590 <_stogir.loops.depths+0x6b0>
    4898:      	str	x21, [sp, #0x180]
    489c:      	str	x20, [sp, #0x148]
    48a0:      	mov	w20, w1
    48a4:      	str	x5, [sp, #0x160]
    48a8:      	str	x4, [sp, #0x168]
    48ac:      	str	x2, [sp, #0x150]
    48b0:      	str	w3, [sp, #0x158]
    48b4:      	str	x19, [sp, #0x140]
    48b8:      	mov	x19, x0
    48bc:      	str	x26, [sp, #0x170]
    48c0:      	mov	x26, x6
    48c4:      	str	x27, [sp, #0x178]
    48c8:      	b	0x4590 <_stogir.loops.depths+0x6b0>
    48cc:      	str	x21, [sp, #0x180]
    48d0:      	str	x20, [sp, #0x148]
    48d4:      	mov	w20, w1
    48d8:      	str	x5, [sp, #0x160]
    48dc:      	str	x4, [sp, #0x168]
    48e0:      	str	x2, [sp, #0x150]
    48e4:      	str	w3, [sp, #0x158]
    48e8:      	str	x19, [sp, #0x140]
    48ec:      	mov	x19, x0
    48f0:      	str	x26, [sp, #0x170]
    48f4:      	mov	x26, x6
    48f8:      	str	x27, [sp, #0x178]
    48fc:      	b	0x4590 <_stogir.loops.depths+0x6b0>
    4900:      	str	x21, [sp, #0x180]
    4904:      	str	x20, [sp, #0x148]
    4908:      	mov	w20, w1
    490c:      	str	x5, [sp, #0x160]
    4910:      	str	x4, [sp, #0x168]
    4914:      	str	x2, [sp, #0x150]
    4918:      	str	w3, [sp, #0x158]
    491c:      	str	x19, [sp, #0x140]
    4920:      	mov	x19, x0
    4924:      	str	x26, [sp, #0x170]
    4928:      	mov	x26, x6
    492c:      	str	x27, [sp, #0x178]
    4930:      	b	0x4590 <_stogir.loops.depths+0x6b0>
    4934:      	str	x21, [sp, #0x180]
    4938:      	str	x20, [sp, #0x148]
    493c:      	mov	w20, w1
    4940:      	str	x5, [sp, #0x160]
    4944:      	str	x4, [sp, #0x168]
    4948:      	str	x2, [sp, #0x150]
    494c:      	str	w3, [sp, #0x158]
    4950:      	str	x19, [sp, #0x140]
    4954:      	mov	x19, x0
    4958:      	str	x26, [sp, #0x170]
    495c:      	mov	x26, x6
    4960:      	str	x27, [sp, #0x178]
    4964:      	b	0x4590 <_stogir.loops.depths+0x6b0>
    4968:      	str	x22, [sp, #0x198]
    496c:      	b	0x42c4 <_stogir.loops.depths+0x3e4>
    4970:      	str	x21, [sp, #0x180]
    4974:      	str	x20, [sp, #0x148]
    4978:      	mov	w20, w1
    497c:      	str	x5, [sp, #0x160]
    4980:      	str	x4, [sp, #0x168]
    4984:      	str	x2, [sp, #0x150]
    4988:      	mov	x21, x7
    498c:      	str	w3, [sp, #0x158]
    4990:      	str	x19, [sp, #0x140]
    4994:      	mov	x19, x0
    4998:      	str	x26, [sp, #0x170]
    499c:      	mov	x26, x6
    49a0:      	str	x27, [sp, #0x178]
    49a4:      	mov	w27, w8
    49a8:      	b	0x4570 <_stogir.loops.depths+0x690>

00000000000049ac <_stogir.liveness.mark>:
    49ac:      	sub	sp, sp, #0x110
    49b0:      	str	x29, [sp]
    49b4:      	str	x30, [sp, #0x8]
    49b8:      	mov	x29, sp
    49bc:      	str	x19, [sp, #0xc0]
    49c0:      	str	x20, [sp, #0xc8]
    49c4:      	str	x21, [sp, #0xd0]
    49c8:      	str	x22, [sp, #0xd8]
    49cc:      	str	x23, [sp, #0xe0]
    49d0:      	str	x24, [sp, #0xe8]
    49d4:      	str	x25, [sp, #0xf0]
    49d8:      	str	x26, [sp, #0xf8]
    49dc:      	str	x27, [sp, #0x100]
    49e0:      	str	x28, [sp, #0x108]
    49e4:      	add	x19, x0, #0x78
    49e8:      	add	x16, sp, #0x10
    49ec:      	orr	x20, x16, xzr
    49f0:      	add	x16, sp, #0x40
    49f4:      	orr	x21, x16, xzr
    49f8:      	ldr	x4, [x3]
    49fc:      	ldr	x5, [x3, #0x8]
    4a00:      	add	x16, sp, #0x10
    4a04:      	movz	x17, #0x0, lsl #48
    4a08:      	str	x17, [x16]
    4a0c:      	add	x16, sp, #0x10
    4a10:      	movz	x17, #0x0, lsl #48
    4a14:      	str	x17, [x16, #0x8]
    4a18:      	add	x16, sp, #0x10
    4a1c:      	movz	x17, #0x0, lsl #48
    4a20:      	str	x17, [x16, #0x10]
    4a24:      	add	x16, sp, #0x10
    4a28:      	str	x4, [x16, #0x18]
    4a2c:      	add	x16, sp, #0x10
    4a30:      	str	x5, [x16, #0x20]
    4a34:      	mov	x22, x8
    4a38:      	add	x8, sp, #0x70
    4a3c:      	mov	x23, x0
    4a40:      	mov	x0, x3
    4a44:      	mov	x24, x1
    4a48:      	mov	x25, x2
    4a4c:      	bl	0x4a4c <_stogir.liveness.mark+0xa0>
		0000000000004a4c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    4a50:      	add	x16, sp, #0x70
    4a54:      	ldr	x0, [x16]
    4a58:      	add	x16, sp, #0x40
    4a5c:      	str	x0, [x16]
    4a60:      	add	x16, sp, #0x70
    4a64:      	ldr	x0, [x16, #0x8]
    4a68:      	add	x16, sp, #0x40
    4a6c:      	str	x0, [x16, #0x8]
    4a70:      	add	x16, sp, #0x70
    4a74:      	ldr	x0, [x16, #0x10]
    4a78:      	add	x16, sp, #0x40
    4a7c:      	str	x0, [x16, #0x10]
    4a80:      	add	x16, sp, #0x70
    4a84:      	ldr	x0, [x16, #0x18]
    4a88:      	add	x16, sp, #0x40
    4a8c:      	str	x0, [x16, #0x18]
    4a90:      	add	x16, sp, #0x70
    4a94:      	ldr	x0, [x16, #0x20]
    4a98:      	add	x16, sp, #0x40
    4a9c:      	str	x0, [x16, #0x20]
    4aa0:      	ldr	x0, [x23, #0x8]
    4aa4:      	mov	x1, x0
    4aa8:      	mov	x0, x20
    4aac:      	bl	0x4aac <_stogir.liveness.mark+0x100>
		0000000000004aac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool
    4ab0:      	movz	x20, #0x0, lsl #48
    4ab4:      	cmp	x20, x25
    4ab8:      	b.ge	0x4adc <_stogir.liveness.mark+0x130>
    4abc:      	add	x0, x20, #0x1
    4ac0:      	add	x1, x24, x20, lsl #2
    4ac4:      	ldr	w1, [x1]
    4ac8:      	movn	w17, #0x0, lsl #16
    4acc:      	and	w26, w1, w17
    4ad0:      	mov	x20, x0
    4ad4:      	mov	w0, #0x1                ; =1
    4ad8:      	b	0x4ae4 <_stogir.liveness.mark+0x138>
    4adc:      	movz	w0, #0x0, lsl #16
    4ae0:      	movz	w26, #0x0, lsl #16
    4ae4:      	ubfx	x0, x0, #0, #32
    4ae8:      	lsr	x16, x0, #0
    4aec:      	cmp	x16, #0x1
    4af0:      	b.eq	0x4b0c <_stogir.liveness.mark+0x160>
    4af4:      	b.lo	0x4afc <_stogir.liveness.mark+0x150>
    4af8:      	b	0x4b10 <_stogir.liveness.mark+0x164>
    4afc:      	cmp	x16, #0x0
    4b00:      	b.eq	0x4b08 <_stogir.liveness.mark+0x15c>
    4b04:      	b	0x4b10 <_stogir.liveness.mark+0x164>
    4b08:      	b	0x4ba0 <_stogir.liveness.mark+0x1f4>
    4b0c:      	b	0x4b14 <_stogir.liveness.mark+0x168>
    4b10:      	b	0x4f30 <_stogir.liveness.mark+0x584>
    4b14:      	sxtw	x0, w26
    4b18:      	cmp	x0, #0x0
    4b1c:      	b.le	0x4ab4 <_stogir.liveness.mark+0x108>
    4b20:      	ldr	x1, [x23, #0x8]
    4b24:      	cmp	x0, x1
    4b28:      	b.ge	0x4ab4 <_stogir.liveness.mark+0x108>
    4b2c:      	ldr	x1, [x19, #0x8]
    4b30:      	cmp	x0, x1
    4b34:      	b.ge	0x4ab4 <_stogir.liveness.mark+0x108>
    4b38:      	ldr	x1, [x23, #0x78]
    4b3c:      	add	x1, x1, x0, lsl #2
    4b40:      	ldr	w1, [x1]
    4b44:      	sxtw	x1, w1
    4b48:      	cmp	x1, #0x0
    4b4c:      	b.lt	0x4ab4 <_stogir.liveness.mark+0x108>
    4b50:      	add	x16, sp, #0x10
    4b54:      	ldr	x1, [x16]
    4b58:      	add	x2, x1, x0
    4b5c:      	ldrb	w2, [x2]
    4b60:      	cmp	x2, #0x0
    4b64:      	b.ne	0x4ab4 <_stogir.liveness.mark+0x108>
    4b68:      	add	x0, x1, x0
    4b6c:      	mov	w17, #0x1               ; =1
    4b70:      	strb	w17, [x0]
    4b74:      	add	x16, sp, #0x40
    4b78:      	ldr	x0, [x16, #0x8]
    4b7c:      	orr	x27, x0, xzr
    4b80:      	add	x16, sp, #0x40
    4b84:      	ldr	x0, [x16, #0x10]
    4b88:      	cmp	x27, x0
    4b8c:      	b.lt	0x4f10 <_stogir.liveness.mark+0x564>
    4b90:      	cmp	x0, #0x0
    4b94:      	b.ne	0x4f00 <_stogir.liveness.mark+0x554>
    4b98:      	mov	x0, #0x2                ; =2
    4b9c:      	b	0x4f04 <_stogir.liveness.mark+0x558>
    4ba0:      	add	x19, x23, #0x78
    4ba4:      	movz	x20, #0x0, lsl #48
    4ba8:      	b	0x4ddc <_stogir.liveness.mark+0x430>
    4bac:      	movz	w3, #0x0, lsl #16
    4bb0:      	movz	w2, #0x0, lsl #16
    4bb4:      	b	0x4d4c <_stogir.liveness.mark+0x3a0>
    4bb8:      	sub	w2, w2, #0x1
    4bbc:      	lsl	w2, w2, #2
    4bc0:      	ubfx	x2, x2, #0, #32
    4bc4:      	lsr	x2, x4, x2
    4bc8:      	and	w2, w2, #0xf
    4bcc:      	b	0x4c70 <_stogir.liveness.mark+0x2c4>
    4bd0:      	lsl	x4, x4, #1
    4bd4:      	str	x0, [sp, #0xa0]
    4bd8:      	mov	x0, x21
    4bdc:      	str	x19, [sp, #0xa8]
    4be0:      	mov	x19, x1
    4be4:      	mov	x1, x4
    4be8:      	str	x21, [sp, #0xb0]
    4bec:      	mov	w21, w2
    4bf0:      	str	x23, [sp, #0xb8]
    4bf4:      	mov	x23, x3
    4bf8:      	bl	0x4bf8 <_stogir.liveness.mark+0x24c>
		0000000000004bf8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4bfc:      	add	x0, x23, #0x1
    4c00:      	add	x16, sp, #0x40
    4c04:      	ldr	x1, [x16]
    4c08:      	add	x1, x1, x23, lsl #2
    4c0c:      	str	w21, [x1]
    4c10:      	add	x16, sp, #0x40
    4c14:      	str	x0, [x16, #0x8]
    4c18:      	add	x0, x19, #0x1
    4c1c:      	sxtw	x19, w0
    4c20:      	ldr	x23, [sp, #0xb8]
    4c24:      	ldr	x21, [sp, #0xb0]
    4c28:      	ldr	x0, [sp, #0xa0]
    4c2c:      	mov	x1, x19
    4c30:      	ldr	x19, [sp, #0xa8]
    4c34:      	cmp	x1, x0
    4c38:      	b.gt	0x4f38 <_stogir.liveness.mark+0x58c>
    4c3c:      	orr	w2, w1, wzr
    4c40:      	sxtw	x3, w2
    4c44:      	uxtb	w16, w27
    4c48:      	cmp	w16, wzr
    4c4c:      	b.eq	0x4c74 <_stogir.liveness.mark+0x2c8>
    4c50:      	ldr	w4, [x28]
    4c54:      	cmp	x3, #0x0
    4c58:      	b.le	0x4c6c <_stogir.liveness.mark+0x2c0>
    4c5c:      	cmp	x3, #0x4
    4c60:      	b.le	0x4bb8 <_stogir.liveness.mark+0x20c>
    4c64:      	mov	w2, #0x4                ; =4
    4c68:      	b	0x4bbc <_stogir.liveness.mark+0x210>
    4c6c:      	movz	w2, #0x0, lsl #16
    4c70:      	b	0x4c78 <_stogir.liveness.mark+0x2cc>
    4c74:      	movz	w2, #0x0, lsl #16
    4c78:      	ubfx	x2, x2, #0, #32
    4c7c:      	cmp	x2, #0xf
    4c80:      	b.hs	0x4f48 <_stogir.liveness.mark+0x59c>
    4c84:      	mov	x16, #0x1               ; =1
    4c88:      	lsl	x2, x16, x2
    4c8c:      	mov	w17, #0x5e1c            ; =24092
    4c90:      	and	w2, w2, w17
    4c94:      	ubfx	x2, x2, #0, #32
    4c98:      	cmp	x2, #0x0
    4c9c:      	b.eq	0x4f60 <_stogir.liveness.mark+0x5b4>
    4ca0:      	uxtb	w16, w26
    4ca4:      	cmp	w16, wzr
    4ca8:      	b.ne	0x4d44 <_stogir.liveness.mark+0x398>
    4cac:      	ldr	x2, [x23, #0x8]
    4cb0:      	cmp	x24, x2
    4cb4:      	b.ge	0x4d44 <_stogir.liveness.mark+0x398>
    4cb8:      	ldr	x2, [x19, #0x8]
    4cbc:      	cmp	x24, x2
    4cc0:      	b.ge	0x4d44 <_stogir.liveness.mark+0x398>
    4cc4:      	ldr	x2, [x23, #0x78]
    4cc8:      	add	x2, x25, x2
    4ccc:      	ldr	w2, [x2]
    4cd0:      	sxtw	x2, w2
    4cd4:      	cmp	x2, #0x0
    4cd8:      	b.lt	0x4d44 <_stogir.liveness.mark+0x398>
    4cdc:      	cmp	x3, #0x1
    4ce0:      	b.lt	0x4bac <_stogir.liveness.mark+0x200>
    4ce4:      	ldr	x2, [x23, #0x78]
    4ce8:      	add	x2, x25, x2
    4cec:      	ldr	w2, [x2]
    4cf0:      	sxtw	x2, w2
    4cf4:      	cmp	x3, x2
    4cf8:      	b.gt	0x4bac <_stogir.liveness.mark+0x200>
    4cfc:      	ldr	x2, [x23]
    4d00:      	asr	x16, x3, #63
    4d04:      	lsr	x16, x16, #62
    4d08:      	add	x4, x3, x16
    4d0c:      	asr	x4, x4, #2
    4d10:      	asr	x16, x3, #63
    4d14:      	lsr	x16, x16, #62
    4d18:      	add	x3, x3, x16
    4d1c:      	and	x3, x3, #0x3
    4d20:      	sub	x3, x3, x16
    4d24:      	add	x4, x4, x24
    4d28:      	add	x2, x2, x4, lsl #4
    4d2c:      	add	x2, x2, x3, lsl #2
    4d30:      	ldr	w2, [x2]
    4d34:      	movn	w17, #0x0, lsl #16
    4d38:      	and	w2, w2, w17
    4d3c:      	mov	w3, #0x1                ; =1
    4d40:      	b	0x4bb4 <_stogir.liveness.mark+0x208>
    4d44:      	movz	w3, #0x0, lsl #16
    4d48:      	movz	w2, #0x0, lsl #16
    4d4c:      	ubfx	x3, x3, #0, #32
    4d50:      	lsr	x16, x3, #0
    4d54:      	cmp	x16, #0x1
    4d58:      	b.eq	0x4d88 <_stogir.liveness.mark+0x3dc>
    4d5c:      	b.lo	0x4d64 <_stogir.liveness.mark+0x3b8>
    4d60:      	b	0x4d8c <_stogir.liveness.mark+0x3e0>
    4d64:      	cmp	x16, #0x0
    4d68:      	b.eq	0x4d70 <_stogir.liveness.mark+0x3c4>
    4d6c:      	b	0x4d8c <_stogir.liveness.mark+0x3e0>
    4d70:      	str	x23, [sp, #0xb8]
    4d74:      	str	x21, [sp, #0xb0]
    4d78:      	str	x0, [sp, #0xa0]
    4d7c:      	str	x19, [sp, #0xa8]
    4d80:      	mov	x19, x1
    4d84:      	b	0x4c18 <_stogir.liveness.mark+0x26c>
    4d88:      	b	0x4d90 <_stogir.liveness.mark+0x3e4>
    4d8c:      	b	0x4ef8 <_stogir.liveness.mark+0x54c>
    4d90:      	sxtw	x3, w2
    4d94:      	cmp	x3, #0x0
    4d98:      	b.le	0x4f78 <_stogir.liveness.mark+0x5cc>
    4d9c:      	add	x16, sp, #0x10
    4da0:      	ldr	x4, [x16]
    4da4:      	add	x3, x3, x4
    4da8:      	ldrb	w4, [x3]
    4dac:      	cmp	x4, #0x0
    4db0:      	b.eq	0x4e4c <_stogir.liveness.mark+0x4a0>
    4db4:      	str	x23, [sp, #0xb8]
    4db8:      	str	x21, [sp, #0xb0]
    4dbc:      	str	x0, [sp, #0xa0]
    4dc0:      	str	x19, [sp, #0xa8]
    4dc4:      	mov	x19, x1
    4dc8:      	b	0x4c18 <_stogir.liveness.mark+0x26c>
    4dcc:      	add	x20, x20, #0x1
    4dd0:      	ldr	x23, [sp, #0xb8]
    4dd4:      	ldr	x21, [sp, #0xb0]
    4dd8:      	ldr	x19, [sp, #0xa8]
    4ddc:      	add	x16, sp, #0x40
    4de0:      	ldr	x0, [x16, #0x8]
    4de4:      	cmp	x20, x0
    4de8:      	b.ge	0x4f90 <_stogir.liveness.mark+0x5e4>
    4dec:      	add	x16, sp, #0x40
    4df0:      	ldr	x0, [x16]
    4df4:      	add	x0, x0, x20, lsl #2
    4df8:      	ldr	w0, [x0]
    4dfc:      	sxtw	x24, w0
    4e00:      	ldr	x0, [x23]
    4e04:      	lsl	x25, x24, #2
    4e08:      	cmp	x24, #0x0
    4e0c:      	cset	w26, le
    4e10:      	add	x0, x0, x24, lsl #4
    4e14:      	ldr	x0, [x0]
    4e18:      	ldr	x1, [x23, #0x78]
    4e1c:      	uxtb	w0, w0
    4e20:      	add	x1, x1, x24, lsl #2
    4e24:      	cmp	x0, #0x83
    4e28:      	cset	w27, lt
    4e2c:      	adrp	x16, 0x4000 <_stogir.loops.depths+0x120>
		0000000000004e2c:  ARM64_RELOC_PAGE21	l_stogir.419
    4e30:      	ldr	x16, [x16]
		0000000000004e30:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    4e34:      	add	x0, x16, x0, lsl #2
    4e38:      	ldr	w1, [x1]
    4e3c:      	orr	x28, x0, xzr
    4e40:      	sxtw	x0, w1
    4e44:      	mov	x1, #0x1                ; =1
    4e48:      	b	0x4c34 <_stogir.liveness.mark+0x288>
    4e4c:      	mov	w17, #0x1               ; =1
    4e50:      	strb	w17, [x3]
    4e54:      	add	x16, sp, #0x40
    4e58:      	ldr	x3, [x16, #0x8]
    4e5c:      	add	x16, sp, #0x40
    4e60:      	ldr	x4, [x16, #0x10]
    4e64:      	cmp	x3, x4
    4e68:      	b.lt	0x4f98 <_stogir.liveness.mark+0x5ec>
    4e6c:      	cmp	x4, #0x0
    4e70:      	b.ne	0x4bd0 <_stogir.liveness.mark+0x224>
    4e74:      	mov	x4, #0x2                ; =2
    4e78:      	b	0x4bd4 <_stogir.liveness.mark+0x228>
    4e7c:      	ldr	x0, [sp, #0xb0]
    4e80:      	bl	0x4e80 <_stogir.liveness.mark+0x4d4>
		0000000000004e80:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    4e84:      	add	x16, sp, #0x10
    4e88:      	ldr	x0, [x16]
    4e8c:      	add	x16, sp, #0x10
    4e90:      	ldr	x1, [x16, #0x8]
    4e94:      	add	x16, sp, #0x10
    4e98:      	ldr	x2, [x16, #0x10]
    4e9c:      	add	x16, sp, #0x10
    4ea0:      	ldr	x3, [x16, #0x18]
    4ea4:      	add	x16, sp, #0x10
    4ea8:      	ldr	x4, [x16, #0x20]
    4eac:      	str	x0, [x22]
    4eb0:      	str	x1, [x22, #0x8]
    4eb4:      	str	x2, [x22, #0x10]
    4eb8:      	str	x3, [x22, #0x18]
    4ebc:      	str	x4, [x22, #0x20]
    4ec0:      	ldr	x19, [sp, #0xc0]
    4ec4:      	ldr	x20, [sp, #0xc8]
    4ec8:      	ldr	x21, [sp, #0xd0]
    4ecc:      	ldr	x22, [sp, #0xd8]
    4ed0:      	ldr	x23, [sp, #0xe0]
    4ed4:      	ldr	x24, [sp, #0xe8]
    4ed8:      	ldr	x25, [sp, #0xf0]
    4edc:      	ldr	x26, [sp, #0xf8]
    4ee0:      	ldr	x27, [sp, #0x100]
    4ee4:      	ldr	x28, [sp, #0x108]
    4ee8:      	ldr	x29, [sp]
    4eec:      	ldr	x30, [sp, #0x8]
    4ef0:      	add	sp, sp, #0x110
    4ef4:      	ret
    4ef8:      	brk	#0
    4efc:      	b	0x4ef8 <_stogir.liveness.mark+0x54c>
    4f00:      	lsl	x0, x0, #1
    4f04:      	mov	x1, x0
    4f08:      	mov	x0, x21
    4f0c:      	bl	0x4f0c <_stogir.liveness.mark+0x560>
		0000000000004f0c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4f10:      	add	x0, x27, #0x1
    4f14:      	add	x16, sp, #0x40
    4f18:      	ldr	x1, [x16]
    4f1c:      	add	x1, x1, x27, lsl #2
    4f20:      	str	w26, [x1]
    4f24:      	add	x16, sp, #0x40
    4f28:      	str	x0, [x16, #0x8]
    4f2c:      	b	0x4ab4 <_stogir.liveness.mark+0x108>
    4f30:      	brk	#0
    4f34:      	b	0x4f30 <_stogir.liveness.mark+0x584>
    4f38:      	str	x23, [sp, #0xb8]
    4f3c:      	str	x21, [sp, #0xb0]
    4f40:      	str	x19, [sp, #0xa8]
    4f44:      	b	0x4dcc <_stogir.liveness.mark+0x420>
    4f48:      	str	x23, [sp, #0xb8]
    4f4c:      	str	x21, [sp, #0xb0]
    4f50:      	str	x0, [sp, #0xa0]
    4f54:      	str	x19, [sp, #0xa8]
    4f58:      	mov	x19, x1
    4f5c:      	b	0x4c18 <_stogir.liveness.mark+0x26c>
    4f60:      	str	x23, [sp, #0xb8]
    4f64:      	str	x21, [sp, #0xb0]
    4f68:      	str	x0, [sp, #0xa0]
    4f6c:      	str	x19, [sp, #0xa8]
    4f70:      	mov	x19, x1
    4f74:      	b	0x4c18 <_stogir.liveness.mark+0x26c>
    4f78:      	str	x23, [sp, #0xb8]
    4f7c:      	str	x21, [sp, #0xb0]
    4f80:      	str	x0, [sp, #0xa0]
    4f84:      	str	x19, [sp, #0xa8]
    4f88:      	mov	x19, x1
    4f8c:      	b	0x4c18 <_stogir.liveness.mark+0x26c>
    4f90:      	str	x21, [sp, #0xb0]
    4f94:      	b	0x4e7c <_stogir.liveness.mark+0x4d0>
    4f98:      	str	x23, [sp, #0xb8]
    4f9c:      	str	x21, [sp, #0xb0]
    4fa0:      	str	x0, [sp, #0xa0]
    4fa4:      	mov	x23, x3
    4fa8:      	mov	w21, w2
    4fac:      	str	x19, [sp, #0xa8]
    4fb0:      	mov	x19, x1
    4fb4:      	b	0x4bfc <_stogir.liveness.mark+0x250>

0000000000004fb8 <_stogir.uses.build>:
    4fb8:      	sub	sp, sp, #0xd0
    4fbc:      	str	x29, [sp]
    4fc0:      	str	x30, [sp, #0x8]
    4fc4:      	mov	x29, sp
    4fc8:      	str	x19, [sp, #0x90]
    4fcc:      	str	x20, [sp, #0x98]
    4fd0:      	str	x21, [sp, #0xa0]
    4fd4:      	str	x22, [sp, #0xa8]
    4fd8:      	str	x23, [sp, #0xb0]
    4fdc:      	str	x24, [sp, #0xb8]
    4fe0:      	str	x25, [sp, #0xc0]
    4fe4:      	str	x26, [sp, #0xc8]
    4fe8:      	add	x16, sp, #0x10
    4fec:      	orr	x19, x16, xzr
    4ff0:      	ldr	x2, [x1]
    4ff4:      	ldr	x3, [x1, #0x8]
    4ff8:      	add	x16, sp, #0x10
    4ffc:      	movz	x17, #0x0, lsl #48
    5000:      	str	x17, [x16]
    5004:      	add	x16, sp, #0x10
    5008:      	movz	x17, #0x0, lsl #48
    500c:      	str	x17, [x16, #0x8]
    5010:      	add	x16, sp, #0x10
    5014:      	movz	x17, #0x0, lsl #48
    5018:      	str	x17, [x16, #0x10]
    501c:      	add	x16, sp, #0x10
    5020:      	str	x2, [x16, #0x18]
    5024:      	add	x16, sp, #0x10
    5028:      	str	x3, [x16, #0x20]
    502c:      	add	x16, sp, #0x10
    5030:      	movz	x17, #0x0, lsl #48
    5034:      	str	x17, [x16, #0x28]
    5038:      	add	x16, sp, #0x10
    503c:      	movz	x17, #0x0, lsl #48
    5040:      	str	x17, [x16, #0x30]
    5044:      	add	x16, sp, #0x10
    5048:      	movz	x17, #0x0, lsl #48
    504c:      	str	x17, [x16, #0x38]
    5050:      	add	x16, sp, #0x10
    5054:      	str	x2, [x16, #0x40]
    5058:      	add	x16, sp, #0x10
    505c:      	str	x3, [x16, #0x48]
    5060:      	ldr	x2, [x1]
    5064:      	ldr	x1, [x1, #0x8]
    5068:      	add	x16, sp, #0x60
    506c:      	movz	x17, #0x0, lsl #48
    5070:      	str	x17, [x16]
    5074:      	add	x16, sp, #0x60
    5078:      	movz	x17, #0x0, lsl #48
    507c:      	str	x17, [x16, #0x8]
    5080:      	add	x16, sp, #0x60
    5084:      	movz	x17, #0x0, lsl #48
    5088:      	str	x17, [x16, #0x10]
    508c:      	add	x16, sp, #0x60
    5090:      	str	x2, [x16, #0x18]
    5094:      	add	x16, sp, #0x60
    5098:      	str	x1, [x16, #0x20]
    509c:      	ldr	x1, [x0, #0x8]
    50a0:      	orr	x20, x1, xzr
    50a4:      	add	x16, sp, #0x10
    50a8:      	ldr	x1, [x16, #0x8]
    50ac:      	orr	x21, x1, xzr
    50b0:      	add	x16, sp, #0x10
    50b4:      	ldr	x1, [x16, #0x10]
    50b8:      	add	x22, x21, x20
    50bc:      	cmp	x22, x1
    50c0:      	b.le	0x54f0 <_stogir.uses.build+0x538>
    50c4:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    50c8:      	cmp	x1, x17
    50cc:      	b.gt	0x50d8 <_stogir.uses.build+0x120>
    50d0:      	lsl	x1, x1, #1
    50d4:      	b	0x50dc <_stogir.uses.build+0x124>
    50d8:      	mov	x1, x22
    50dc:      	cmp	x1, x22
    50e0:      	b.gt	0x50e8 <_stogir.uses.build+0x130>
    50e4:      	mov	x1, x22
    50e8:      	mov	x23, x8
    50ec:      	mov	x24, x0
    50f0:      	mov	x0, x19
    50f4:      	bl	0x50f4 <_stogir.uses.build+0x13c>
		00000000000050f4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range
    50f8:      	add	x16, sp, #0x60
    50fc:      	orr	x25, x16, xzr
    5100:      	lsl	x0, x20, #4
    5104:      	add	x16, sp, #0x10
    5108:      	ldr	x1, [x16]
    510c:      	add	x1, x1, x21, lsl #4
    5110:      	mov	x2, x0
    5114:      	mov	x0, x1
    5118:      	movz	x1, #0x0, lsl #48
    511c:      	bl	0x511c <_stogir.uses.build+0x164>
		000000000000511c:  ARM64_RELOC_BRANCH26	_memset
    5120:      	add	x16, sp, #0x10
    5124:      	str	x22, [x16, #0x8]
    5128:      	ldr	x0, [x24, #0x8]
    512c:      	orr	x20, x0, xzr
    5130:      	add	x16, sp, #0x60
    5134:      	ldr	x0, [x16, #0x8]
    5138:      	orr	x21, x0, xzr
    513c:      	add	x16, sp, #0x60
    5140:      	ldr	x0, [x16, #0x10]
    5144:      	add	x22, x21, x20
    5148:      	cmp	x22, x0
    514c:      	b.le	0x5180 <_stogir.uses.build+0x1c8>
    5150:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    5154:      	cmp	x0, x17
    5158:      	b.gt	0x5164 <_stogir.uses.build+0x1ac>
    515c:      	lsl	x0, x0, #1
    5160:      	b	0x5168 <_stogir.uses.build+0x1b0>
    5164:      	mov	x0, x22
    5168:      	cmp	x0, x22
    516c:      	b.gt	0x5174 <_stogir.uses.build+0x1bc>
    5170:      	mov	x0, x22
    5174:      	mov	x1, x0
    5178:      	mov	x0, x25
    517c:      	bl	0x517c <_stogir.uses.build+0x1c4>
		000000000000517c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    5180:      	lsl	x0, x20, #3
    5184:      	add	x16, sp, #0x60
    5188:      	ldr	x1, [x16]
    518c:      	add	x1, x1, x21, lsl #3
    5190:      	mov	x2, x0
    5194:      	mov	x0, x1
    5198:      	movz	x1, #0x0, lsl #48
    519c:      	bl	0x519c <_stogir.uses.build+0x1e4>
		000000000000519c:  ARM64_RELOC_BRANCH26	_memset
    51a0:      	add	x16, sp, #0x60
    51a4:      	str	x22, [x16, #0x8]
    51a8:      	mov	x0, #0x1                ; =1
    51ac:      	b	0x52a8 <_stogir.uses.build+0x2f0>
    51b0:      	sub	w4, w4, #0x1
    51b4:      	lsl	w4, w4, #2
    51b8:      	ubfx	x4, x4, #0, #32
    51bc:      	lsr	x4, x1, x4
    51c0:      	and	w4, w4, #0xf
    51c4:      	b	0x51cc <_stogir.uses.build+0x214>
    51c8:      	movz	w4, #0x0, lsl #16
    51cc:      	ubfx	x4, x4, #0, #32
    51d0:      	cmp	x4, #0xf
    51d4:      	b.hs	0x5260 <_stogir.uses.build+0x2a8>
    51d8:      	mov	x16, #0x1               ; =1
    51dc:      	lsl	x4, x16, x4
    51e0:      	mov	w17, #0x5e1c            ; =24092
    51e4:      	and	w4, w4, w17
    51e8:      	ubfx	x4, x4, #0, #32
    51ec:      	cmp	x4, #0x0
    51f0:      	b.eq	0x5260 <_stogir.uses.build+0x2a8>
    51f4:      	ldr	x4, [x24]
    51f8:      	asr	x16, x5, #63
    51fc:      	lsr	x16, x16, #62
    5200:      	add	x6, x5, x16
    5204:      	asr	x6, x6, #2
    5208:      	asr	x16, x5, #63
    520c:      	lsr	x16, x16, #62
    5210:      	add	x5, x5, x16
    5214:      	and	x5, x5, #0x3
    5218:      	sub	x5, x5, x16
    521c:      	add	x6, x6, x0
    5220:      	add	x4, x4, x6, lsl #4
    5224:      	add	x4, x4, x5, lsl #2
    5228:      	ldr	w4, [x4]
    522c:      	sxtw	x4, w4
    5230:      	cmp	x4, #0x0
    5234:      	b.le	0x5260 <_stogir.uses.build+0x2a8>
    5238:      	add	x16, sp, #0x10
    523c:      	ldr	x5, [x16]
    5240:      	orr	x6, x5, xzr
    5244:      	add	x6, x6, x4, lsl #4
    5248:      	add	x4, x5, x4, lsl #4
    524c:      	ldr	x5, [x6]
    5250:      	ldr	x6, [x6, #0x8]
    5254:      	add	x6, x6, #0x1
    5258:      	str	x5, [x4]
    525c:      	str	x6, [x4, #0x8]
    5260:      	add	x3, x3, #0x1
    5264:      	sxtw	x3, w3
    5268:      	cmp	x3, x2
    526c:      	b.gt	0x5290 <_stogir.uses.build+0x2d8>
    5270:      	orr	w4, w3, wzr
    5274:      	sxtw	x5, w4
    5278:      	cmp	x5, #0x0
    527c:      	b.le	0x51c8 <_stogir.uses.build+0x210>
    5280:      	cmp	x5, #0x4
    5284:      	b.le	0x51b0 <_stogir.uses.build+0x1f8>
    5288:      	mov	w4, #0x4                ; =4
    528c:      	b	0x51b4 <_stogir.uses.build+0x1fc>
    5290:      	add	x1, x2, #0x4
    5294:      	asr	x16, x1, #63
    5298:      	lsr	x16, x16, #62
    529c:      	add	x1, x1, x16
    52a0:      	asr	x1, x1, #2
    52a4:      	add	x0, x1, x0
    52a8:      	ldr	x1, [x24, #0x8]
    52ac:      	cmp	x0, x1
    52b0:      	b.ge	0x52ec <_stogir.uses.build+0x334>
    52b4:      	ldr	x1, [x24]
    52b8:      	add	x1, x1, x0, lsl #4
    52bc:      	ldr	x1, [x1]
    52c0:      	ldr	x2, [x24, #0x78]
    52c4:      	uxtb	w1, w1
    52c8:      	add	x2, x2, x0, lsl #2
    52cc:      	adrp	x16, 0x5000 <_stogir.uses.build+0x48>
		00000000000052cc:  ARM64_RELOC_PAGE21	l_stogir.420
    52d0:      	ldr	x16, [x16]
		00000000000052d0:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    52d4:      	add	x1, x16, x1, lsl #2
    52d8:      	ldr	w2, [x2]
    52dc:      	sxtw	x2, w2
    52e0:      	ldr	w1, [x1]
    52e4:      	mov	x3, #0x1                ; =1
    52e8:      	b	0x5268 <_stogir.uses.build+0x2b0>
    52ec:      	movn	x0, #0x0, lsl #48
    52f0:      	movz	x20, #0x0, lsl #48
    52f4:      	b	0x5330 <_stogir.uses.build+0x378>
    52f8:      	add	x16, sp, #0x10
    52fc:      	ldr	x1, [x16]
    5300:      	orr	x2, x1, xzr
    5304:      	add	x2, x2, x0, lsl #4
    5308:      	add	x1, x1, x0, lsl #4
    530c:      	ldr	x2, [x2, #0x8]
    5310:      	add	x3, x2, x20
    5314:      	str	x20, [x1]
    5318:      	str	x2, [x1, #0x8]
    531c:      	add	x16, sp, #0x60
    5320:      	ldr	x1, [x16]
    5324:      	add	x1, x1, x0, lsl #3
    5328:      	str	x20, [x1]
    532c:      	mov	x20, x3
    5330:      	add	x16, sp, #0x10
    5334:      	ldr	x1, [x16, #0x8]
    5338:      	add	x0, x0, #0x1
    533c:      	cmp	x0, x1
    5340:      	b.lt	0x52f8 <_stogir.uses.build+0x340>
    5344:      	add	x21, x19, #0x28
    5348:      	ldr	x0, [x21, #0x8]
    534c:      	orr	x22, x0, xzr
    5350:      	ldr	x0, [x21, #0x10]
    5354:      	add	x26, x22, x20
    5358:      	cmp	x26, x0
    535c:      	b.le	0x5390 <_stogir.uses.build+0x3d8>
    5360:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    5364:      	cmp	x0, x17
    5368:      	b.gt	0x5374 <_stogir.uses.build+0x3bc>
    536c:      	lsl	x0, x0, #1
    5370:      	b	0x5378 <_stogir.uses.build+0x3c0>
    5374:      	mov	x0, x26
    5378:      	cmp	x0, x26
    537c:      	b.gt	0x5384 <_stogir.uses.build+0x3cc>
    5380:      	mov	x0, x26
    5384:      	mov	x1, x0
    5388:      	mov	x0, x21
    538c:      	bl	0x538c <_stogir.uses.build+0x3d4>
		000000000000538c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use
    5390:      	lsl	x0, x20, #3
    5394:      	add	x16, sp, #0x10
    5398:      	ldr	x1, [x16, #0x28]
    539c:      	add	x1, x1, x22, lsl #3
    53a0:      	mov	x2, x0
    53a4:      	mov	x0, x1
    53a8:      	movz	x1, #0x0, lsl #48
    53ac:      	bl	0x53ac <_stogir.uses.build+0x3f4>
		00000000000053ac:  ARM64_RELOC_BRANCH26	_memset
    53b0:      	str	x26, [x21, #0x8]
    53b4:      	mov	x0, x24
    53b8:      	mov	x1, x19
    53bc:      	mov	x2, x25
    53c0:      	bl	0x53c0 <_stogir.uses.build+0x408>
		00000000000053c0:  ARM64_RELOC_BRANCH26	_stogir.uses.scan!__constfalse
    53c4:      	b	0x53d4 <_stogir.uses.build+0x41c>
    53c8:      	sub	x0, x0, #0x1
    53cc:      	add	x16, sp, #0x60
    53d0:      	str	x0, [x16, #0x8]
    53d4:      	add	x16, sp, #0x60
    53d8:      	ldr	x0, [x16, #0x8]
    53dc:      	cmp	x0, #0x0
    53e0:      	b.ne	0x53c8 <_stogir.uses.build+0x410>
    53e4:      	add	x16, sp, #0x60
    53e8:      	ldr	x0, [x16, #0x10]
    53ec:      	cmp	x0, #0x0
    53f0:      	b.le	0x5424 <_stogir.uses.build+0x46c>
    53f4:      	add	x1, x25, #0x18
    53f8:      	add	x16, sp, #0x60
    53fc:      	ldr	x2, [x16]
    5400:      	fmov	d31, x0
    5404:      	mov	x0, x1
    5408:      	mov	x1, x2
    540c:      	fmov	x2, d31
    5410:      	adrp	x3, 0x5000 <_stogir.uses.build+0x48>
		0000000000005410:  ARM64_RELOC_PAGE21	l_stogir.421
    5414:      	ldr	x3, [x3]
		0000000000005414:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    5418:      	mov	x4, #0x8                ; =8
    541c:      	mov	x5, #0x8                ; =8
    5420:      	bl	0x5420 <_stogir.uses.build+0x468>
		0000000000005420:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    5424:      	add	x16, sp, #0x60
    5428:      	movz	x17, #0x0, lsl #48
    542c:      	str	x17, [x16]
    5430:      	add	x16, sp, #0x60
    5434:      	movz	x17, #0x0, lsl #48
    5438:      	str	x17, [x16, #0x8]
    543c:      	add	x16, sp, #0x60
    5440:      	movz	x17, #0x0, lsl #48
    5444:      	str	x17, [x16, #0x10]
    5448:      	add	x16, sp, #0x10
    544c:      	ldr	x0, [x16]
    5450:      	add	x16, sp, #0x10
    5454:      	ldr	x1, [x16, #0x8]
    5458:      	add	x16, sp, #0x10
    545c:      	ldr	x2, [x16, #0x10]
    5460:      	add	x16, sp, #0x10
    5464:      	ldr	x3, [x16, #0x18]
    5468:      	add	x16, sp, #0x10
    546c:      	ldr	x4, [x16, #0x20]
    5470:      	add	x16, sp, #0x10
    5474:      	ldr	x5, [x16, #0x28]
    5478:      	add	x16, sp, #0x10
    547c:      	ldr	x6, [x16, #0x30]
    5480:      	add	x16, sp, #0x10
    5484:      	ldr	x7, [x16, #0x38]
    5488:      	add	x16, sp, #0x10
    548c:      	ldr	x8, [x16, #0x40]
    5490:      	add	x16, sp, #0x10
    5494:      	ldr	x9, [x16, #0x48]
    5498:      	str	x0, [x23]
    549c:      	str	x1, [x23, #0x8]
    54a0:      	str	x2, [x23, #0x10]
    54a4:      	str	x3, [x23, #0x18]
    54a8:      	str	x4, [x23, #0x20]
    54ac:      	str	x5, [x23, #0x28]
    54b0:      	str	x6, [x23, #0x30]
    54b4:      	str	x7, [x23, #0x38]
    54b8:      	str	x8, [x23, #0x40]
    54bc:      	str	x9, [x23, #0x48]
    54c0:      	ldr	x19, [sp, #0x90]
    54c4:      	ldr	x20, [sp, #0x98]
    54c8:      	ldr	x21, [sp, #0xa0]
    54cc:      	ldr	x22, [sp, #0xa8]
    54d0:      	ldr	x23, [sp, #0xb0]
    54d4:      	ldr	x24, [sp, #0xb8]
    54d8:      	ldr	x25, [sp, #0xc0]
    54dc:      	ldr	x26, [sp, #0xc8]
    54e0:      	ldr	x29, [sp]
    54e4:      	ldr	x30, [sp, #0x8]
    54e8:      	add	sp, sp, #0xd0
    54ec:      	ret
    54f0:      	mov	x23, x8
    54f4:      	mov	x24, x0
    54f8:      	b	0x50f8 <_stogir.uses.build+0x140>

00000000000054fc <_inherent$coil.arraylist.ArrayList$new__i32>:
    54fc:      	ldr	x1, [x0]
    5500:      	ldr	x0, [x0, #0x8]
    5504:      	movz	x17, #0x0, lsl #48
    5508:      	str	x17, [x8]
    550c:      	movz	x17, #0x0, lsl #48
    5510:      	str	x17, [x8, #0x8]
    5514:      	movz	x17, #0x0, lsl #48
    5518:      	str	x17, [x8, #0x10]
    551c:      	str	x1, [x8, #0x18]
    5520:      	str	x0, [x8, #0x20]
    5524:      	ret

0000000000005528 <_stogir.placement.pinned>:
    5528:      	sub	sp, sp, #0xc0
    552c:      	str	x29, [sp, #0x10]
    5530:      	str	x30, [sp, #0x18]
    5534:      	add	x29, sp, #0x10
    5538:      	str	x19, [sp, #0x68]
    553c:      	str	x20, [sp, #0x70]
    5540:      	str	x21, [sp, #0x78]
    5544:      	str	x22, [sp, #0x80]
    5548:      	str	x23, [sp, #0x88]
    554c:      	str	x24, [sp, #0x90]
    5550:      	str	x25, [sp, #0x98]
    5554:      	str	x26, [sp, #0xa0]
    5558:      	str	x27, [sp, #0xa8]
    555c:      	str	x28, [sp, #0xb0]
    5560:      	add	x19, x1, #0x28
    5564:      	add	x16, sp, #0x20
    5568:      	orr	x20, x16, xzr
    556c:      	ldr	x3, [x2]
    5570:      	ldr	x2, [x2, #0x8]
    5574:      	add	x16, sp, #0x20
    5578:      	movz	x17, #0x0, lsl #48
    557c:      	str	x17, [x16]
    5580:      	add	x16, sp, #0x20
    5584:      	movz	x17, #0x0, lsl #48
    5588:      	str	x17, [x16, #0x8]
    558c:      	add	x16, sp, #0x20
    5590:      	movz	x17, #0x0, lsl #48
    5594:      	str	x17, [x16, #0x10]
    5598:      	add	x16, sp, #0x20
    559c:      	str	x3, [x16, #0x18]
    55a0:      	add	x16, sp, #0x20
    55a4:      	str	x2, [x16, #0x20]
    55a8:      	movz	x21, #0x0, lsl #48
    55ac:      	b	0x55f8 <_stogir.placement.pinned+0xd0>
    55b0:      	lsl	x2, x2, #1
    55b4:      	mov	x24, x8
    55b8:      	mov	x25, x0
    55bc:      	mov	x0, x20
    55c0:      	mov	x26, x1
    55c4:      	mov	x1, x2
    55c8:      	bl	0x55c8 <_stogir.placement.pinned+0xa0>
		00000000000055c8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    55cc:      	add	x21, x21, #0x1
    55d0:      	add	x0, x23, #0x1
    55d4:      	add	x16, sp, #0x20
    55d8:      	ldr	x1, [x16]
    55dc:      	add	x1, x1, x23, lsl #2
    55e0:      	str	w22, [x1]
    55e4:      	add	x16, sp, #0x20
    55e8:      	str	x0, [x16, #0x8]
    55ec:      	mov	x8, x24
    55f0:      	mov	x0, x25
    55f4:      	mov	x1, x26
    55f8:      	ldr	x2, [x19, #0x8]
    55fc:      	cmp	x21, x2
    5600:      	b.ge	0x5a98 <_stogir.placement.pinned+0x570>
    5604:      	ldr	x2, [x1, #0x28]
    5608:      	add	x2, x2, x21, lsl #2
    560c:      	ldr	w22, [x2]
    5610:      	add	x16, sp, #0x20
    5614:      	ldr	x2, [x16, #0x8]
    5618:      	orr	x23, x2, xzr
    561c:      	add	x16, sp, #0x20
    5620:      	ldr	x2, [x16, #0x10]
    5624:      	cmp	x23, x2
    5628:      	b.lt	0x5aa4 <_stogir.placement.pinned+0x57c>
    562c:      	cmp	x2, #0x0
    5630:      	b.ne	0x55b0 <_stogir.placement.pinned+0x88>
    5634:      	mov	x2, #0x2                ; =2
    5638:      	b	0x55b4 <_stogir.placement.pinned+0x8c>
    563c:      	add	x19, x25, #0x78
    5640:      	add	x21, x25, #0x78
    5644:      	add	x22, x25, #0x28
    5648:      	add	x23, x25, #0x50
    564c:      	mov	x26, #0x1               ; =1
    5650:      	adrp	x27, 0x5000 <_stogir.uses.build+0x48>
		0000000000005650:  ARM64_RELOC_PAGE21	l_stogir.422
    5654:      	ldr	x27, [x27]
		0000000000005654:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    5658:      	movz	x28, #0x0, lsl #48
    565c:      	b	0x56b4 <_stogir.placement.pinned+0x18c>
    5660:      	adrp	x27, 0x5000 <_stogir.uses.build+0x48>
		0000000000005660:  ARM64_RELOC_PAGE21	l_stogir.423
    5664:      	ldr	x27, [x27]
		0000000000005664:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    5668:      	mov	x28, #0x15              ; =21
    566c:      	b	0x5758 <_stogir.placement.pinned+0x230>
    5670:      	movz	w0, #0x0, lsl #16
    5674:      	uxtb	w16, w0
    5678:      	and	w0, w16, #0x20
    567c:      	uxtb	w0, w0
    5680:      	ubfx	x0, x0, #0, #8
    5684:      	cmp	x0, #0x0
    5688:      	b.ne	0x5700 <_stogir.placement.pinned+0x1d8>
    568c:      	str	x24, [sp, #0x60]
    5690:      	mov	w24, w1
    5694:      	sxtw	x24, w24
    5698:      	add	x0, x24, #0x4
    569c:      	asr	x16, x0, #63
    56a0:      	lsr	x16, x16, #62
    56a4:      	add	x0, x0, x16
    56a8:      	asr	x0, x0, #2
    56ac:      	add	x26, x0, x26
    56b0:      	ldr	x24, [sp, #0x60]
    56b4:      	cmp	x28, #0x0
    56b8:      	b.ne	0x5ab4 <_stogir.placement.pinned+0x58c>
    56bc:      	ldr	x0, [x25, #0x8]
    56c0:      	cmp	x26, x0
    56c4:      	b.ge	0x5abc <_stogir.placement.pinned+0x594>
    56c8:      	ldr	x0, [x25]
    56cc:      	add	x0, x0, x26, lsl #4
    56d0:      	ldr	x0, [x0]
    56d4:      	ldr	x1, [x25, #0x78]
    56d8:      	uxtb	w0, w0
    56dc:      	add	x1, x1, x26, lsl #2
    56e0:      	ldr	w1, [x1]
    56e4:      	cmp	x0, #0x83
    56e8:      	b.ge	0x5670 <_stogir.placement.pinned+0x148>
    56ec:      	adrp	x17, 0x5000 <_stogir.uses.build+0x48>
		00000000000056ec:  ARM64_RELOC_PAGE21	l_stogir.424
    56f0:      	ldr	x17, [x17]
		00000000000056f0:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    56f4:      	add	x0, x0, x17
    56f8:      	ldrb	w0, [x0]
    56fc:      	b	0x5674 <_stogir.placement.pinned+0x14c>
    5700:      	orr	w0, w26, wzr
    5704:      	str	x24, [sp, #0x60]
    5708:      	mov	w24, w1
    570c:      	mov	w1, w0
    5710:      	mov	x0, x25
    5714:      	mov	x2, #0x1                ; =1
    5718:      	bl	0x5718 <_stogir.placement.pinned+0x1f0>
		0000000000005718:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    571c:      	ubfx	x0, x0, #0, #32
    5720:      	lsr	x16, x0, #0
    5724:      	cmp	x16, #0x1
    5728:      	b.eq	0x5744 <_stogir.placement.pinned+0x21c>
    572c:      	b.lo	0x5734 <_stogir.placement.pinned+0x20c>
    5730:      	b	0x5748 <_stogir.placement.pinned+0x220>
    5734:      	cmp	x16, #0x0
    5738:      	b.eq	0x5740 <_stogir.placement.pinned+0x218>
    573c:      	b	0x5748 <_stogir.placement.pinned+0x220>
    5740:      	b	0x574c <_stogir.placement.pinned+0x224>
    5744:      	b	0x575c <_stogir.placement.pinned+0x234>
    5748:      	b	0x5a88 <_stogir.placement.pinned+0x560>
    574c:      	adrp	x27, 0x5000 <_stogir.uses.build+0x48>
		000000000000574c:  ARM64_RELOC_PAGE21	l_stogir.425
    5750:      	ldr	x27, [x27]
		0000000000005750:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    5754:      	mov	x28, #0x19              ; =25
    5758:      	b	0x5694 <_stogir.placement.pinned+0x16c>
    575c:      	sxtw	x0, w1
    5760:      	cmp	x0, #0x0
    5764:      	b.le	0x5660 <_stogir.placement.pinned+0x138>
    5768:      	lsl	x2, x0, #2
    576c:      	ldr	x3, [x25, #0x8]
    5770:      	cmp	x0, x3
    5774:      	b.ge	0x58cc <_stogir.placement.pinned+0x3a4>
    5778:      	ldr	x3, [x19, #0x8]
    577c:      	cmp	x0, x3
    5780:      	b.ge	0x58c4 <_stogir.placement.pinned+0x39c>
    5784:      	ldr	x3, [x25, #0x78]
    5788:      	add	x3, x2, x3
    578c:      	ldr	w3, [x3]
    5790:      	sxtw	x3, w3
    5794:      	cmp	x3, #0x0
    5798:      	cset	w3, ge
    579c:      	ubfx	x3, x3, #0, #8
    57a0:      	b	0x58c8 <_stogir.placement.pinned+0x3a0>
    57a4:      	cmp	x28, #0x0
    57a8:      	b.ne	0x57dc <_stogir.placement.pinned+0x2b4>
    57ac:      	add	x16, sp, #0x20
    57b0:      	ldr	x27, [x16]
    57b4:      	add	x16, sp, #0x20
    57b8:      	ldr	x28, [x16, #0x8]
    57bc:      	add	x16, sp, #0x20
    57c0:      	ldr	x0, [x16, #0x10]
    57c4:      	add	x16, sp, #0x20
    57c8:      	ldr	x1, [x16, #0x18]
    57cc:      	add	x16, sp, #0x20
    57d0:      	ldr	x2, [x16, #0x20]
    57d4:      	movz	x3, #0x0, lsl #48
    57d8:      	b	0x5870 <_stogir.placement.pinned+0x348>
    57dc:      	b	0x57ec <_stogir.placement.pinned+0x2c4>
    57e0:      	sub	x0, x0, #0x1
    57e4:      	add	x16, sp, #0x20
    57e8:      	str	x0, [x16, #0x8]
    57ec:      	add	x16, sp, #0x20
    57f0:      	ldr	x0, [x16, #0x8]
    57f4:      	cmp	x0, #0x0
    57f8:      	b.ne	0x57e0 <_stogir.placement.pinned+0x2b8>
    57fc:      	add	x16, sp, #0x20
    5800:      	ldr	x0, [x16, #0x10]
    5804:      	cmp	x0, #0x0
    5808:      	b.le	0x583c <_stogir.placement.pinned+0x314>
    580c:      	add	x1, x20, #0x18
    5810:      	add	x16, sp, #0x20
    5814:      	ldr	x2, [x16]
    5818:      	fmov	d31, x0
    581c:      	mov	x0, x1
    5820:      	mov	x1, x2
    5824:      	fmov	x2, d31
    5828:      	adrp	x3, 0x5000 <_stogir.uses.build+0x48>
		0000000000005828:  ARM64_RELOC_PAGE21	l_stogir.426
    582c:      	ldr	x3, [x3]
		000000000000582c:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    5830:      	mov	x4, #0x4                ; =4
    5834:      	mov	x5, #0x4                ; =4
    5838:      	bl	0x5838 <_stogir.placement.pinned+0x310>
		0000000000005838:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    583c:      	add	x16, sp, #0x20
    5840:      	movz	x17, #0x0, lsl #48
    5844:      	str	x17, [x16]
    5848:      	add	x16, sp, #0x20
    584c:      	movz	x17, #0x0, lsl #48
    5850:      	str	x17, [x16, #0x8]
    5854:      	add	x16, sp, #0x20
    5858:      	movz	x17, #0x0, lsl #48
    585c:      	str	x17, [x16, #0x10]
    5860:      	mov	x3, #0x1                ; =1
    5864:      	movz	x0, #0x0, lsl #48
    5868:      	movz	x1, #0x0, lsl #48
    586c:      	movz	x2, #0x0, lsl #48
    5870:      	ldr	x4, [sp, #0x60]
    5874:      	str	x3, [x4]
    5878:      	str	x27, [x4, #0x8]
    587c:      	str	x28, [x4, #0x10]
    5880:      	str	x0, [x4, #0x18]
    5884:      	str	x1, [x4, #0x20]
    5888:      	str	x2, [x4, #0x28]
    588c:      	ldr	x19, [sp, #0x68]
    5890:      	ldr	x20, [sp, #0x70]
    5894:      	ldr	x21, [sp, #0x78]
    5898:      	ldr	x22, [sp, #0x80]
    589c:      	ldr	x23, [sp, #0x88]
    58a0:      	ldr	x24, [sp, #0x90]
    58a4:      	ldr	x25, [sp, #0x98]
    58a8:      	ldr	x26, [sp, #0xa0]
    58ac:      	ldr	x27, [sp, #0xa8]
    58b0:      	ldr	x28, [sp, #0xb0]
    58b4:      	ldr	x29, [sp, #0x10]
    58b8:      	ldr	x30, [sp, #0x18]
    58bc:      	add	sp, sp, #0xc0
    58c0:      	ret
    58c4:      	movz	x3, #0x0, lsl #48
    58c8:      	b	0x58d0 <_stogir.placement.pinned+0x3a8>
    58cc:      	movz	x3, #0x0, lsl #48
    58d0:      	cmp	x3, #0x0
    58d4:      	b.eq	0x5660 <_stogir.placement.pinned+0x138>
    58d8:      	movz	x16, #0x0, lsl #48
    58dc:      	sub	x3, x16, x0
    58e0:      	cmp	x0, #0x0
    58e4:      	cset	w4, gt
    58e8:      	sub	x5, x3, #0x1
    58ec:      	uxtb	w16, w4
    58f0:      	cmp	w16, wzr
    58f4:      	b.eq	0x5940 <_stogir.placement.pinned+0x418>
    58f8:      	ldr	x3, [x25, #0x8]
    58fc:      	cmp	x0, x3
    5900:      	b.ge	0x5980 <_stogir.placement.pinned+0x458>
    5904:      	ldr	x3, [x21, #0x8]
    5908:      	cmp	x0, x3
    590c:      	b.ge	0x5a34 <_stogir.placement.pinned+0x50c>
    5910:      	ldr	x3, [x25, #0x78]
    5914:      	add	x2, x2, x3
    5918:      	ldr	w2, [x2]
    591c:      	sxtw	x2, w2
    5920:      	cmp	x2, #0x0
    5924:      	cset	w2, ge
    5928:      	ubfx	x2, x2, #0, #8
    592c:      	b	0x5a38 <_stogir.placement.pinned+0x510>
    5930:      	adrp	x27, 0x5000 <_stogir.uses.build+0x48>
		0000000000005930:  ARM64_RELOC_PAGE21	l_stogir.427
    5934:      	ldr	x27, [x27]
		0000000000005934:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    5938:      	mov	x28, #0x20              ; =32
    593c:      	b	0x566c <_stogir.placement.pinned+0x144>
    5940:      	cmp	x0, #0x0
    5944:      	b.ge	0x5988 <_stogir.placement.pinned+0x460>
    5948:      	ldr	x2, [x22, #0x8]
    594c:      	ldr	x6, [x23, #0x8]
    5950:      	cmp	x2, x6
    5954:      	b.ne	0x5a2c <_stogir.placement.pinned+0x504>
    5958:      	cmp	x3, x2
    595c:      	b.gt	0x5a80 <_stogir.placement.pinned+0x558>
    5960:      	ldr	x2, [x25, #0x50]
    5964:      	add	x2, x2, x5, lsl #2
    5968:      	ldr	w2, [x2]
    596c:      	sxtw	x2, w2
    5970:      	cmp	x2, #0x0
    5974:      	cset	w2, gt
    5978:      	ubfx	x2, x2, #0, #8
    597c:      	b	0x5a84 <_stogir.placement.pinned+0x55c>
    5980:      	movz	x2, #0x0, lsl #48
    5984:      	b	0x598c <_stogir.placement.pinned+0x464>
    5988:      	movz	x2, #0x0, lsl #48
    598c:      	cmp	x2, #0x0
    5990:      	b.eq	0x59c4 <_stogir.placement.pinned+0x49c>
    5994:      	uxtb	w16, w4
    5998:      	cmp	w16, wzr
    599c:      	b.eq	0x59b0 <_stogir.placement.pinned+0x488>
    59a0:      	ldr	x2, [x25]
    59a4:      	add	x0, x2, x0, lsl #4
    59a8:      	ldr	x0, [x0]
    59ac:      	b	0x59bc <_stogir.placement.pinned+0x494>
    59b0:      	ldr	x0, [x25, #0x28]
    59b4:      	add	x0, x0, x5, lsl #4
    59b8:      	ldr	x0, [x0]
    59bc:      	mov	w2, #0x1                ; =1
    59c0:      	b	0x59cc <_stogir.placement.pinned+0x4a4>
    59c4:      	movz	w2, #0x0, lsl #16
    59c8:      	movz	x0, #0x0, lsl #48
    59cc:      	ubfx	x2, x2, #0, #32
    59d0:      	lsr	x16, x2, #0
    59d4:      	cmp	x16, #0x1
    59d8:      	b.eq	0x59f4 <_stogir.placement.pinned+0x4cc>
    59dc:      	b.lo	0x59e4 <_stogir.placement.pinned+0x4bc>
    59e0:      	b	0x59f8 <_stogir.placement.pinned+0x4d0>
    59e4:      	cmp	x16, #0x0
    59e8:      	b.eq	0x59f0 <_stogir.placement.pinned+0x4c8>
    59ec:      	b	0x59f8 <_stogir.placement.pinned+0x4d0>
    59f0:      	b	0x59fc <_stogir.placement.pinned+0x4d4>
    59f4:      	b	0x5a0c <_stogir.placement.pinned+0x4e4>
    59f8:      	b	0x5a90 <_stogir.placement.pinned+0x568>
    59fc:      	adrp	x27, 0x5000 <_stogir.uses.build+0x48>
		00000000000059fc:  ARM64_RELOC_PAGE21	l_stogir.423
    5a00:      	ldr	x27, [x27]
		0000000000005a00:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    5a04:      	mov	x28, #0x15              ; =21
    5a08:      	b	0x593c <_stogir.placement.pinned+0x414>
    5a0c:      	uxtb	w0, w0
    5a10:      	cmp	x0, #0x83
    5a14:      	b.ge	0x5a3c <_stogir.placement.pinned+0x514>
    5a18:      	adrp	x17, 0x5000 <_stogir.uses.build+0x48>
		0000000000005a18:  ARM64_RELOC_PAGE21	l_stogir.424
    5a1c:      	ldr	x17, [x17]
		0000000000005a1c:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    5a20:      	add	x0, x0, x17
    5a24:      	ldrb	w0, [x0]
    5a28:      	b	0x5a40 <_stogir.placement.pinned+0x518>
    5a2c:      	movz	x2, #0x0, lsl #48
    5a30:      	b	0x598c <_stogir.placement.pinned+0x464>
    5a34:      	movz	x2, #0x0, lsl #48
    5a38:      	b	0x5984 <_stogir.placement.pinned+0x45c>
    5a3c:      	movz	w0, #0x0, lsl #16
    5a40:      	uxtb	w16, w0
    5a44:      	and	w0, w16, #0x2
    5a48:      	uxtb	w0, w0
    5a4c:      	ubfx	x0, x0, #0, #8
    5a50:      	cmp	x0, #0x0
    5a54:      	cset	w0, eq
    5a58:      	uxtb	w16, w0
    5a5c:      	cmp	w16, wzr
    5a60:      	cset	x0, eq
    5a64:      	cmp	x0, #0x0
    5a68:      	b.eq	0x5930 <_stogir.placement.pinned+0x408>
    5a6c:      	add	x16, sp, #0x20
    5a70:      	ldr	x0, [x16]
    5a74:      	add	x0, x0, x26, lsl #2
    5a78:      	str	w1, [x0]
    5a7c:      	b	0x593c <_stogir.placement.pinned+0x414>
    5a80:      	movz	x2, #0x0, lsl #48
    5a84:      	b	0x5a30 <_stogir.placement.pinned+0x508>
    5a88:      	brk	#0
    5a8c:      	b	0x5a88 <_stogir.placement.pinned+0x560>
    5a90:      	brk	#0
    5a94:      	b	0x5a90 <_stogir.placement.pinned+0x568>
    5a98:      	mov	x24, x8
    5a9c:      	mov	x25, x0
    5aa0:      	b	0x563c <_stogir.placement.pinned+0x114>
    5aa4:      	mov	x24, x8
    5aa8:      	mov	x25, x0
    5aac:      	mov	x26, x1
    5ab0:      	b	0x55cc <_stogir.placement.pinned+0xa4>
    5ab4:      	str	x24, [sp, #0x60]
    5ab8:      	b	0x57a4 <_stogir.placement.pinned+0x27c>
    5abc:      	str	x24, [sp, #0x60]
    5ac0:      	b	0x57a4 <_stogir.placement.pinned+0x27c>
    5ac4:      	udf	#0x0

0000000000005ac8 <_stogir.placement.early-with-uses!>:
    5ac8:      	sub	sp, sp, #0x1e0
    5acc:      	str	x29, [sp, #0x10]
    5ad0:      	str	x30, [sp, #0x18]
    5ad4:      	add	x29, sp, #0x10
    5ad8:      	str	x19, [sp, #0x188]
    5adc:      	str	x20, [sp, #0x190]
    5ae0:      	str	x21, [sp, #0x198]
    5ae4:      	str	x22, [sp, #0x1a0]
    5ae8:      	str	x23, [sp, #0x1a8]
    5aec:      	str	x24, [sp, #0x1b0]
    5af0:      	str	x25, [sp, #0x1b8]
    5af4:      	str	x26, [sp, #0x1c0]
    5af8:      	str	x27, [sp, #0x1c8]
    5afc:      	str	x28, [sp, #0x1d0]
    5b00:      	add	x16, sp, #0x20
    5b04:      	orr	x19, x16, xzr
    5b08:      	mov	x20, x8
    5b0c:      	add	x8, sp, #0x50
    5b10:      	mov	x21, x0
    5b14:      	mov	x0, x5
    5b18:      	mov	x22, x1
    5b1c:      	mov	x23, x2
    5b20:      	mov	w24, w3
    5b24:      	mov	x25, x4
    5b28:      	mov	x26, x5
    5b2c:      	bl	0x5b2c <_stogir.placement.early-with-uses!+0x64>
		0000000000005b2c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    5b30:      	add	x16, sp, #0x50
    5b34:      	ldr	x0, [x16]
    5b38:      	add	x16, sp, #0x20
    5b3c:      	str	x0, [x16]
    5b40:      	add	x16, sp, #0x50
    5b44:      	ldr	x0, [x16, #0x8]
    5b48:      	add	x16, sp, #0x20
    5b4c:      	str	x0, [x16, #0x8]
    5b50:      	add	x16, sp, #0x50
    5b54:      	ldr	x0, [x16, #0x10]
    5b58:      	add	x16, sp, #0x20
    5b5c:      	str	x0, [x16, #0x10]
    5b60:      	add	x16, sp, #0x50
    5b64:      	ldr	x0, [x16, #0x18]
    5b68:      	add	x16, sp, #0x20
    5b6c:      	str	x0, [x16, #0x18]
    5b70:      	add	x16, sp, #0x50
    5b74:      	ldr	x0, [x16, #0x20]
    5b78:      	add	x16, sp, #0x20
    5b7c:      	str	x0, [x16, #0x20]
    5b80:      	add	x8, sp, #0xb0
    5b84:      	mov	x0, x26
    5b88:      	bl	0x5b88 <_stogir.placement.early-with-uses!+0xc0>
		0000000000005b88:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    5b8c:      	add	x16, sp, #0xb0
    5b90:      	ldr	x0, [x16]
    5b94:      	add	x16, sp, #0x80
    5b98:      	str	x0, [x16]
    5b9c:      	add	x16, sp, #0xb0
    5ba0:      	ldr	x0, [x16, #0x8]
    5ba4:      	add	x16, sp, #0x80
    5ba8:      	str	x0, [x16, #0x8]
    5bac:      	add	x16, sp, #0xb0
    5bb0:      	ldr	x0, [x16, #0x10]
    5bb4:      	add	x16, sp, #0x80
    5bb8:      	str	x0, [x16, #0x10]
    5bbc:      	add	x16, sp, #0xb0
    5bc0:      	ldr	x0, [x16, #0x18]
    5bc4:      	add	x16, sp, #0x80
    5bc8:      	str	x0, [x16, #0x18]
    5bcc:      	add	x16, sp, #0xb0
    5bd0:      	ldr	x0, [x16, #0x20]
    5bd4:      	add	x16, sp, #0x80
    5bd8:      	str	x0, [x16, #0x20]
    5bdc:      	movz	x26, #0x0, lsl #48
    5be0:      	b	0x5c1c <_stogir.placement.early-with-uses!+0x154>
    5be4:      	nop
    5be8:      	lsl	x0, x0, #1
    5bec:      	mov	x1, x0
    5bf0:      	mov	x0, x19
    5bf4:      	bl	0x5bf4 <_stogir.placement.early-with-uses!+0x12c>
		0000000000005bf4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5bf8:      	add	x26, x26, #0x1
    5bfc:      	add	x0, x27, #0x1
    5c00:      	add	x16, sp, #0x20
    5c04:      	ldr	x1, [x16]
    5c08:      	add	x1, x1, x27, lsl #2
    5c0c:      	movn	w17, #0x0, lsl #16
    5c10:      	str	w17, [x1]
    5c14:      	add	x16, sp, #0x20
    5c18:      	str	x0, [x16, #0x8]
    5c1c:      	ldr	x0, [x21, #0x8]
    5c20:      	cmp	x26, x0
    5c24:      	b.ge	0x5c54 <_stogir.placement.early-with-uses!+0x18c>
    5c28:      	add	x16, sp, #0x20
    5c2c:      	ldr	x0, [x16, #0x8]
    5c30:      	orr	x27, x0, xzr
    5c34:      	add	x16, sp, #0x20
    5c38:      	ldr	x0, [x16, #0x10]
    5c3c:      	cmp	x27, x0
    5c40:      	b.lt	0x5bf8 <_stogir.placement.early-with-uses!+0x130>
    5c44:      	cmp	x0, #0x0
    5c48:      	b.ne	0x5be8 <_stogir.placement.early-with-uses!+0x120>
    5c4c:      	mov	x0, #0x2                ; =2
    5c50:      	b	0x5bec <_stogir.placement.early-with-uses!+0x124>
    5c54:      	add	x16, sp, #0x80
    5c58:      	orr	x26, x16, xzr
    5c5c:      	mov	x27, #0x1               ; =1
    5c60:      	movz	x28, #0x0, lsl #48
    5c64:      	adrp	x0, 0x5000 <_stogir.uses.build+0x48>
		0000000000005c64:  ARM64_RELOC_PAGE21	l_stogir.428
    5c68:      	ldr	x0, [x0]
		0000000000005c68:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    5c6c:      	movz	x1, #0x0, lsl #48
    5c70:      	b	0x5cd8 <_stogir.placement.early-with-uses!+0x210>
    5c74:      	lsl	x0, x0, #1
    5c78:      	mov	x1, x0
    5c7c:      	ldr	x0, [sp, #0x108]
    5c80:      	bl	0x5c80 <_stogir.placement.early-with-uses!+0x1b8>
		0000000000005c80:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5c84:      	add	x0, x23, #0x1
    5c88:      	add	x16, sp, #0x80
    5c8c:      	ldr	x1, [x16]
    5c90:      	add	x1, x1, x23, lsl #2
    5c94:      	str	w19, [x1]
    5c98:      	add	x16, sp, #0x80
    5c9c:      	str	x0, [x16, #0x8]
    5ca0:      	add	x0, x28, #0x1
    5ca4:      	sxtw	x28, w0
    5ca8:      	add	x0, x20, #0x4
    5cac:      	asr	x16, x0, #63
    5cb0:      	lsr	x16, x16, #62
    5cb4:      	add	x0, x0, x16
    5cb8:      	asr	x0, x0, #2
    5cbc:      	add	x27, x0, x27
    5cc0:      	ldr	x20, [sp, #0x118]
    5cc4:      	ldr	x23, [sp, #0x138]
    5cc8:      	ldr	x19, [sp, #0x100]
    5ccc:      	ldr	x26, [sp, #0x108]
    5cd0:      	ldr	x0, [sp, #0x120]
    5cd4:      	ldr	x1, [sp, #0x130]
    5cd8:      	ldr	x2, [x21, #0x8]
    5cdc:      	cmp	x27, x2
    5ce0:      	b.ge	0x6444 <_stogir.placement.early-with-uses!+0x97c>
    5ce4:      	lsl	x2, x27, #2
    5ce8:      	ldr	x3, [x21]
    5cec:      	add	x3, x3, x27, lsl #4
    5cf0:      	ldr	x3, [x3]
    5cf4:      	ldr	x4, [x21, #0x78]
    5cf8:      	uxtb	w3, w3
    5cfc:      	add	x4, x4, x27, lsl #2
    5d00:      	cmp	x3, #0x83
    5d04:      	cset	w5, lt
    5d08:      	ldr	w4, [x4]
    5d0c:      	uxtb	w16, w5
    5d10:      	cmp	w16, wzr
    5d14:      	b.eq	0x5d2c <_stogir.placement.early-with-uses!+0x264>
    5d18:      	adrp	x17, 0x5000 <_stogir.uses.build+0x48>
		0000000000005d18:  ARM64_RELOC_PAGE21	l_stogir.429
    5d1c:      	ldr	x17, [x17]
		0000000000005d1c:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    5d20:      	add	x6, x3, x17
    5d24:      	ldrb	w6, [x6]
    5d28:      	b	0x5d30 <_stogir.placement.early-with-uses!+0x268>
    5d2c:      	movz	w6, #0x0, lsl #16
    5d30:      	ldr	x7, [x22]
    5d34:      	add	x2, x7, x2
    5d38:      	ldr	w2, [x2]
    5d3c:      	sxtw	x2, w2
    5d40:      	cmp	x2, #0x0
    5d44:      	b.ne	0x5d70 <_stogir.placement.early-with-uses!+0x2a8>
    5d48:      	uxtb	w16, w6
    5d4c:      	and	w2, w16, #0x40
    5d50:      	uxtb	w2, w2
    5d54:      	ubfx	x2, x2, #0, #8
    5d58:      	cmp	x2, #0x0
    5d5c:      	b.ne	0x5d68 <_stogir.placement.early-with-uses!+0x2a0>
    5d60:      	movz	x2, #0x0, lsl #48
    5d64:      	b	0x5d6c <_stogir.placement.early-with-uses!+0x2a4>
    5d68:      	mov	x2, #0x1                ; =1
    5d6c:      	b	0x5d74 <_stogir.placement.early-with-uses!+0x2ac>
    5d70:      	movz	x2, #0x0, lsl #48
    5d74:      	sxtw	x4, w4
    5d78:      	cmp	x2, #0x0
    5d7c:      	b.eq	0x6460 <_stogir.placement.early-with-uses!+0x998>
    5d80:      	orr	w2, w27, wzr
    5d84:      	adrp	x16, 0x5000 <_stogir.uses.build+0x48>
		0000000000005d84:  ARM64_RELOC_PAGE21	l_stogir.430
    5d88:      	ldr	x16, [x16]
		0000000000005d88:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    5d8c:      	add	x3, x16, x3, lsl #2
    5d90:      	mov	x6, #0x1                ; =1
    5d94:      	movz	x7, #0x0, lsl #48
    5d98:      	b	0x5e18 <_stogir.placement.early-with-uses!+0x350>
    5d9c:      	sub	w9, w8, #0x1
    5da0:      	lsl	w9, w9, #2
    5da4:      	ubfx	x9, x9, #0, #32
    5da8:      	lsr	x9, x10, x9
    5dac:      	and	w9, w9, #0xf
    5db0:      	b	0x5e54 <_stogir.placement.early-with-uses!+0x38c>
    5db4:      	sxtw	x1, w1
    5db8:      	cmp	x1, #0x0
    5dbc:      	b.le	0x5de0 <_stogir.placement.early-with-uses!+0x318>
    5dc0:      	ldr	x0, [x22]
    5dc4:      	add	x0, x0, x1, lsl #2
    5dc8:      	ldr	w0, [x0]
    5dcc:      	sxtw	x0, w0
    5dd0:      	cmp	x0, #0x0
    5dd4:      	b.ne	0x5de0 <_stogir.placement.early-with-uses!+0x318>
    5dd8:      	add	x0, x23, #0x1
    5ddc:      	sxtw	x23, w0
    5de0:      	add	x0, x26, #0x1
    5de4:      	sxtw	x26, w0
    5de8:      	mov	x4, x20
    5dec:      	ldr	x20, [sp, #0x118]
    5df0:      	mov	w2, w19
    5df4:      	ldr	x19, [sp, #0x100]
    5df8:      	ldr	w5, [sp, #0x110]
    5dfc:      	ldr	x3, [sp, #0x128]
    5e00:      	mov	x6, x26
    5e04:      	ldr	x26, [sp, #0x108]
    5e08:      	mov	x7, x23
    5e0c:      	ldr	x23, [sp, #0x138]
    5e10:      	ldr	x0, [sp, #0x120]
    5e14:      	ldr	x1, [sp, #0x130]
    5e18:      	cmp	x6, x4
    5e1c:      	b.gt	0x6480 <_stogir.placement.early-with-uses!+0x9b8>
    5e20:      	orr	w8, w6, wzr
    5e24:      	uxtb	w16, w5
    5e28:      	cmp	w16, wzr
    5e2c:      	b.eq	0x5e58 <_stogir.placement.early-with-uses!+0x390>
    5e30:      	sxtw	x9, w8
    5e34:      	ldr	w10, [x3]
    5e38:      	cmp	x9, #0x0
    5e3c:      	b.le	0x5e50 <_stogir.placement.early-with-uses!+0x388>
    5e40:      	cmp	x9, #0x4
    5e44:      	b.le	0x5d9c <_stogir.placement.early-with-uses!+0x2d4>
    5e48:      	mov	w9, #0x4                ; =4
    5e4c:      	b	0x5da0 <_stogir.placement.early-with-uses!+0x2d8>
    5e50:      	movz	w9, #0x0, lsl #16
    5e54:      	b	0x5e5c <_stogir.placement.early-with-uses!+0x394>
    5e58:      	movz	w9, #0x0, lsl #16
    5e5c:      	ubfx	x9, x9, #0, #32
    5e60:      	cmp	x9, #0xf
    5e64:      	b.hs	0x64a8 <_stogir.placement.early-with-uses!+0x9e0>
    5e68:      	mov	x16, #0x1               ; =1
    5e6c:      	lsl	x9, x16, x9
    5e70:      	mov	w17, #0x5e1c            ; =24092
    5e74:      	and	w9, w9, w17
    5e78:      	ubfx	x9, x9, #0, #32
    5e7c:      	cmp	x9, #0x0
    5e80:      	b.eq	0x64dc <_stogir.placement.early-with-uses!+0xa14>
    5e84:      	str	x0, [sp, #0x120]
    5e88:      	mov	x0, x21
    5e8c:      	str	x1, [sp, #0x130]
    5e90:      	mov	w1, w2
    5e94:      	str	w5, [sp, #0x110]
    5e98:      	str	x3, [sp, #0x128]
    5e9c:      	str	x19, [sp, #0x100]
    5ea0:      	mov	w19, w2
    5ea4:      	mov	w2, w8
    5ea8:      	str	x26, [sp, #0x108]
    5eac:      	mov	x26, x6
    5eb0:      	str	x20, [sp, #0x118]
    5eb4:      	mov	x20, x4
    5eb8:      	str	x23, [sp, #0x138]
    5ebc:      	mov	x23, x7
    5ec0:      	bl	0x5ec0 <_stogir.placement.early-with-uses!+0x3f8>
		0000000000005ec0:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5ec4:      	ubfx	x0, x0, #0, #32
    5ec8:      	lsr	x16, x0, #0
    5ecc:      	cmp	x16, #0x1
    5ed0:      	b.eq	0x5eec <_stogir.placement.early-with-uses!+0x424>
    5ed4:      	b.lo	0x5edc <_stogir.placement.early-with-uses!+0x414>
    5ed8:      	b	0x5ef0 <_stogir.placement.early-with-uses!+0x428>
    5edc:      	cmp	x16, #0x0
    5ee0:      	b.eq	0x5ee8 <_stogir.placement.early-with-uses!+0x420>
    5ee4:      	b	0x5ef0 <_stogir.placement.early-with-uses!+0x428>
    5ee8:      	b	0x5ef4 <_stogir.placement.early-with-uses!+0x42c>
    5eec:      	b	0x5db4 <_stogir.placement.early-with-uses!+0x2ec>
    5ef0:      	b	0x643c <_stogir.placement.early-with-uses!+0x974>
    5ef4:      	adrp	x16, 0x5000 <_stogir.uses.build+0x48>
		0000000000005ef4:  ARM64_RELOC_PAGE21	l_stogir.431
    5ef8:      	ldr	x16, [x16]
		0000000000005ef8:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    5efc:      	str	x16, [sp, #0x120]
    5f00:      	mov	x16, #0x18              ; =24
    5f04:      	str	x16, [sp, #0x130]
    5f08:      	b	0x5de0 <_stogir.placement.early-with-uses!+0x318>
    5f0c:      	orr	w0, w23, wzr
    5f10:      	add	x16, sp, #0x20
    5f14:      	ldr	x1, [x16]
    5f18:      	add	x1, x1, x27, lsl #2
    5f1c:      	str	w0, [x1]
    5f20:      	cmp	x23, #0x0
    5f24:      	b.ne	0x5ca0 <_stogir.placement.early-with-uses!+0x1d8>
    5f28:      	add	x16, sp, #0x80
    5f2c:      	ldr	x0, [x16, #0x8]
    5f30:      	orr	x23, x0, xzr
    5f34:      	add	x16, sp, #0x80
    5f38:      	ldr	x0, [x16, #0x10]
    5f3c:      	cmp	x23, x0
    5f40:      	b.lt	0x5c84 <_stogir.placement.early-with-uses!+0x1bc>
    5f44:      	cmp	x0, #0x0
    5f48:      	b.ne	0x5c74 <_stogir.placement.early-with-uses!+0x1ac>
    5f4c:      	mov	x0, #0x2                ; =2
    5f50:      	b	0x5c78 <_stogir.placement.early-with-uses!+0x1b0>
    5f54:      	sxtw	x24, w24
    5f58:      	orr	x19, x22, xzr
    5f5c:      	ldr	x20, [sp, #0x138]
    5f60:      	movz	x23, #0x0, lsl #48
    5f64:      	movz	x26, #0x0, lsl #48
    5f68:      	b	0x60c4 <_stogir.placement.early-with-uses!+0x5fc>
    5f6c:      	movz	x1, #0x0, lsl #48
    5f70:      	movz	x2, #0x0, lsl #48
    5f74:      	b	0x5f84 <_stogir.placement.early-with-uses!+0x4bc>
    5f78:      	mov	x23, x3
    5f7c:      	b	0x5f84 <_stogir.placement.early-with-uses!+0x4bc>
    5f80:      	mov	x1, #0x1                ; =1
    5f84:      	cmp	x1, #0x0
    5f88:      	b.ne	0x614c <_stogir.placement.early-with-uses!+0x684>
    5f8c:      	cmp	x23, #0x0
    5f90:      	b.le	0x5f80 <_stogir.placement.early-with-uses!+0x4b8>
    5f94:      	ldr	x3, [x20, #0x8]
    5f98:      	cmp	x23, x3
    5f9c:      	b.ge	0x5f80 <_stogir.placement.early-with-uses!+0x4b8>
    5fa0:      	ldr	x3, [x20]
    5fa4:      	add	x3, x3, x23, lsl #2
    5fa8:      	ldr	w3, [x3]
    5fac:      	sxtw	x3, w3
    5fb0:      	cmp	x3, #0x0
    5fb4:      	b.ne	0x5fc0 <_stogir.placement.early-with-uses!+0x4f8>
    5fb8:      	mov	x1, #0x1                ; =1
    5fbc:      	b	0x5f7c <_stogir.placement.early-with-uses!+0x4b4>
    5fc0:      	cmp	x23, x0
    5fc4:      	b.ne	0x6424 <_stogir.placement.early-with-uses!+0x95c>
    5fc8:      	mov	x1, #0x1                ; =1
    5fcc:      	mov	x2, #0x1                ; =1
    5fd0:      	b	0x5f7c <_stogir.placement.early-with-uses!+0x4b4>
    5fd4:      	nop
    5fd8:      	lsl	x2, x2, #1
    5fdc:      	str	x19, [sp, #0x180]
    5fe0:      	mov	w19, w0
    5fe4:      	ldr	x0, [sp, #0x108]
    5fe8:      	str	x20, [sp, #0x138]
    5fec:      	mov	x20, x1
    5ff0:      	mov	x1, x2
    5ff4:      	bl	0x5ff4 <_stogir.placement.early-with-uses!+0x52c>
		0000000000005ff4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5ff8:      	add	x0, x20, #0x1
    5ffc:      	add	x16, sp, #0x80
    6000:      	ldr	x1, [x16]
    6004:      	add	x1, x1, x20, lsl #2
    6008:      	str	w19, [x1]
    600c:      	add	x16, sp, #0x80
    6010:      	str	x0, [x16, #0x8]
    6014:      	add	x24, x24, #0x1
    6018:      	ldr	x20, [sp, #0x138]
    601c:      	ldr	x19, [sp, #0x180]
    6020:      	cmp	x24, x23
    6024:      	b.ge	0x6510 <_stogir.placement.early-with-uses!+0xa48>
    6028:      	add	x0, x21, x24
    602c:      	ldr	x1, [x25, #0x28]
    6030:      	add	x0, x1, x0, lsl #3
    6034:      	ldr	x0, [x0]
    6038:      	add	x16, sp, #0x20
    603c:      	ldr	x1, [x16]
    6040:      	sxtw	x2, w0
    6044:      	add	x3, x1, x2, lsl #2
    6048:      	ldr	w3, [x3]
    604c:      	sxtw	x4, w3
    6050:      	cmp	x4, #0x0
    6054:      	b.le	0x651c <_stogir.placement.early-with-uses!+0xa54>
    6058:      	sub	w3, w3, #0x1
    605c:      	add	x1, x1, x2, lsl #2
    6060:      	str	w3, [x1]
    6064:      	cmp	x4, #0x1
    6068:      	b.ne	0x6528 <_stogir.placement.early-with-uses!+0xa60>
    606c:      	add	x16, sp, #0x80
    6070:      	ldr	x1, [x16, #0x8]
    6074:      	add	x16, sp, #0x80
    6078:      	ldr	x2, [x16, #0x10]
    607c:      	cmp	x1, x2
    6080:      	b.lt	0x6534 <_stogir.placement.early-with-uses!+0xa6c>
    6084:      	cmp	x2, #0x0
    6088:      	b.ne	0x5fd8 <_stogir.placement.early-with-uses!+0x510>
    608c:      	mov	x2, #0x2                ; =2
    6090:      	b	0x5fdc <_stogir.placement.early-with-uses!+0x514>
    6094:      	add	x0, x26, #0x1
    6098:      	sub	x1, x28, #0x1
    609c:      	sxtw	x26, w0
    60a0:      	sxtw	x28, w1
    60a4:      	ldr	x0, [sp, #0x178]
    60a8:      	add	x0, x0, #0x1
    60ac:      	ldr	x21, [sp, #0x140]
    60b0:      	ldr	x20, [sp, #0x138]
    60b4:      	ldr	x24, [sp, #0x168]
    60b8:      	ldr	x19, [sp, #0x180]
    60bc:      	mov	x23, x0
    60c0:      	str	x27, [sp, #0x130]
    60c4:      	ldr	x27, [sp, #0x130]
    60c8:      	cmp	x27, #0x0
    60cc:      	b.ne	0x637c <_stogir.placement.early-with-uses!+0x8b4>
    60d0:      	add	x16, sp, #0x80
    60d4:      	ldr	x0, [x16, #0x8]
    60d8:      	cmp	x23, x0
    60dc:      	b.ge	0x637c <_stogir.placement.early-with-uses!+0x8b4>
    60e0:      	add	x16, sp, #0x80
    60e4:      	ldr	x0, [x16]
    60e8:      	add	x0, x0, x23, lsl #2
    60ec:      	ldr	w0, [x0]
    60f0:      	sxtw	x1, w0
    60f4:      	ldr	x2, [x21]
    60f8:      	add	x2, x2, x1, lsl #4
    60fc:      	ldr	x2, [x2]
    6100:      	ldr	x3, [x21, #0x78]
    6104:      	uxtb	w2, w2
    6108:      	add	x3, x3, x1, lsl #2
    610c:      	cmp	x2, #0x83
    6110:      	cset	w4, lt
    6114:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006114:  ARM64_RELOC_PAGE21	l_stogir.430
    6118:      	ldr	x16, [x16]
		0000000000006118:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    611c:      	add	x2, x16, x2, lsl #2
    6120:      	ldr	w3, [x3]
    6124:      	sxtw	x3, w3
    6128:      	mov	x6, x24
    612c:      	mov	x5, #0x1                ; =1
    6130:      	b	0x6194 <_stogir.placement.early-with-uses!+0x6cc>
    6134:      	sub	w9, w7, #0x1
    6138:      	lsl	w9, w9, #2
    613c:      	ubfx	x9, x9, #0, #32
    6140:      	lsr	x9, x10, x9
    6144:      	and	w9, w9, #0xf
    6148:      	b	0x61f0 <_stogir.placement.early-with-uses!+0x728>
    614c:      	cmp	x2, #0x0
    6150:      	b.ne	0x6164 <_stogir.placement.early-with-uses!+0x69c>
    6154:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006154:  ARM64_RELOC_PAGE21	l_stogir.432
    6158:      	ldr	x16, [x16]
		0000000000006158:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    615c:      	str	x16, [sp, #0x120]
    6160:      	mov	x27, #0x2b              ; =43
    6164:      	add	x0, x24, #0x1
    6168:      	sxtw	x24, w0
    616c:      	ldr	x23, [sp, #0x178]
    6170:      	mov	x1, x21
    6174:      	ldr	x21, [sp, #0x140]
    6178:      	ldr	x3, [sp, #0x160]
    617c:      	ldr	w0, [sp, #0x148]
    6180:      	ldr	w4, [sp, #0x150]
    6184:      	ldr	x2, [sp, #0x158]
    6188:      	mov	x5, x24
    618c:      	ldr	x24, [sp, #0x168]
    6190:      	ldr	x6, [sp, #0x170]
    6194:      	cmp	x27, #0x0
    6198:      	b.ne	0x61ac <_stogir.placement.early-with-uses!+0x6e4>
    619c:      	cmp	x5, x3
    61a0:      	cset	w7, le
    61a4:      	ubfx	x7, x7, #0, #8
    61a8:      	b	0x61b0 <_stogir.placement.early-with-uses!+0x6e8>
    61ac:      	movz	x7, #0x0, lsl #48
    61b0:      	orr	w8, w6, wzr
    61b4:      	cmp	x7, #0x0
    61b8:      	b.eq	0x6548 <_stogir.placement.early-with-uses!+0xa80>
    61bc:      	orr	w7, w5, wzr
    61c0:      	uxtb	w16, w4
    61c4:      	cmp	w16, wzr
    61c8:      	b.eq	0x61f4 <_stogir.placement.early-with-uses!+0x72c>
    61cc:      	sxtw	x9, w7
    61d0:      	ldr	w10, [x2]
    61d4:      	cmp	x9, #0x0
    61d8:      	b.le	0x61ec <_stogir.placement.early-with-uses!+0x724>
    61dc:      	cmp	x9, #0x4
    61e0:      	b.le	0x6134 <_stogir.placement.early-with-uses!+0x66c>
    61e4:      	mov	w9, #0x4                ; =4
    61e8:      	b	0x6138 <_stogir.placement.early-with-uses!+0x670>
    61ec:      	movz	w9, #0x0, lsl #16
    61f0:      	b	0x61f8 <_stogir.placement.early-with-uses!+0x730>
    61f4:      	movz	w9, #0x0, lsl #16
    61f8:      	ubfx	x9, x9, #0, #32
    61fc:      	cmp	x9, #0xf
    6200:      	b.hs	0x6560 <_stogir.placement.early-with-uses!+0xa98>
    6204:      	mov	x16, #0x1               ; =1
    6208:      	lsl	x9, x16, x9
    620c:      	mov	w17, #0x5e1c            ; =24092
    6210:      	and	w9, w9, w17
    6214:      	ubfx	x9, x9, #0, #32
    6218:      	cmp	x9, #0x0
    621c:      	b.eq	0x658c <_stogir.placement.early-with-uses!+0xac4>
    6220:      	str	w0, [sp, #0x148]
    6224:      	str	w4, [sp, #0x150]
    6228:      	str	x2, [sp, #0x158]
    622c:      	mov	w2, w7
    6230:      	str	x3, [sp, #0x160]
    6234:      	str	x6, [sp, #0x170]
    6238:      	str	x21, [sp, #0x140]
    623c:      	str	x24, [sp, #0x168]
    6240:      	mov	x24, x5
    6244:      	str	x23, [sp, #0x178]
    6248:      	mov	w23, w8
    624c:      	fmov	s31, w0
    6250:      	mov	x0, x21
    6254:      	mov	x21, x1
    6258:      	fmov	w1, s31
    625c:      	bl	0x625c <_stogir.placement.early-with-uses!+0x794>
		000000000000625c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    6260:      	ubfx	x0, x0, #0, #32
    6264:      	lsr	x16, x0, #0
    6268:      	cmp	x16, #0x1
    626c:      	b.eq	0x6288 <_stogir.placement.early-with-uses!+0x7c0>
    6270:      	b.lo	0x6278 <_stogir.placement.early-with-uses!+0x7b0>
    6274:      	b	0x628c <_stogir.placement.early-with-uses!+0x7c4>
    6278:      	cmp	x16, #0x0
    627c:      	b.eq	0x6284 <_stogir.placement.early-with-uses!+0x7bc>
    6280:      	b	0x628c <_stogir.placement.early-with-uses!+0x7c4>
    6284:      	b	0x6290 <_stogir.placement.early-with-uses!+0x7c8>
    6288:      	b	0x62d0 <_stogir.placement.early-with-uses!+0x808>
    628c:      	b	0x6434 <_stogir.placement.early-with-uses!+0x96c>
    6290:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006290:  ARM64_RELOC_PAGE21	l_stogir.431
    6294:      	ldr	x16, [x16]
		0000000000006294:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    6298:      	str	x16, [sp, #0x120]
    629c:      	mov	x27, #0x18              ; =24
    62a0:      	b	0x6164 <_stogir.placement.early-with-uses!+0x69c>
    62a4:      	cmp	x27, #0x0
    62a8:      	b.ne	0x65b8 <_stogir.placement.early-with-uses!+0xaf0>
    62ac:      	ldr	x0, [x22]
    62b0:      	add	x0, x0, x21, lsl #2
    62b4:      	str	w23, [x0]
    62b8:      	ldr	x0, [x25]
    62bc:      	add	x0, x0, x21, lsl #4
    62c0:      	ldr	x21, [x0]
    62c4:      	ldr	x23, [x0, #0x8]
    62c8:      	movz	x24, #0x0, lsl #48
    62cc:      	b	0x6020 <_stogir.placement.early-with-uses!+0x558>
    62d0:      	sxtw	x1, w1
    62d4:      	cmp	x1, #0x0
    62d8:      	b.le	0x6164 <_stogir.placement.early-with-uses!+0x69c>
    62dc:      	sxtw	x23, w23
    62e0:      	ldr	x0, [x19]
    62e4:      	add	x0, x0, x1, lsl #2
    62e8:      	ldr	w0, [x0]
    62ec:      	sxtw	x0, w0
    62f0:      	mov	x2, x0
    62f4:      	movz	x1, #0x0, lsl #48
    62f8:      	movz	x3, #0x0, lsl #48
    62fc:      	b	0x630c <_stogir.placement.early-with-uses!+0x844>
    6300:      	mov	x2, x4
    6304:      	b	0x630c <_stogir.placement.early-with-uses!+0x844>
    6308:      	mov	x1, #0x1                ; =1
    630c:      	cmp	x1, #0x0
    6310:      	b.ne	0x635c <_stogir.placement.early-with-uses!+0x894>
    6314:      	cmp	x2, #0x0
    6318:      	b.le	0x6308 <_stogir.placement.early-with-uses!+0x840>
    631c:      	ldr	x4, [x20, #0x8]
    6320:      	cmp	x2, x4
    6324:      	b.ge	0x6308 <_stogir.placement.early-with-uses!+0x840>
    6328:      	ldr	x4, [x20]
    632c:      	add	x4, x4, x2, lsl #2
    6330:      	ldr	w4, [x4]
    6334:      	sxtw	x4, w4
    6338:      	cmp	x4, #0x0
    633c:      	b.ne	0x6348 <_stogir.placement.early-with-uses!+0x880>
    6340:      	mov	x1, #0x1                ; =1
    6344:      	b	0x6304 <_stogir.placement.early-with-uses!+0x83c>
    6348:      	cmp	x2, x23
    634c:      	b.ne	0x636c <_stogir.placement.early-with-uses!+0x8a4>
    6350:      	mov	x1, #0x1                ; =1
    6354:      	mov	x3, #0x1                ; =1
    6358:      	b	0x6304 <_stogir.placement.early-with-uses!+0x83c>
    635c:      	cmp	x3, #0x0
    6360:      	b.eq	0x5f6c <_stogir.placement.early-with-uses!+0x4a4>
    6364:      	str	x0, [sp, #0x170]
    6368:      	b	0x6164 <_stogir.placement.early-with-uses!+0x69c>
    636c:      	cmp	x2, x4
    6370:      	b.ne	0x6300 <_stogir.placement.early-with-uses!+0x838>
    6374:      	mov	x1, #0x1                ; =1
    6378:      	b	0x6304 <_stogir.placement.early-with-uses!+0x83c>
    637c:      	ldr	x0, [sp, #0x100]
    6380:      	bl	0x6380 <_stogir.placement.early-with-uses!+0x8b8>
		0000000000006380:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    6384:      	ldr	x0, [sp, #0x108]
    6388:      	bl	0x6388 <_stogir.placement.early-with-uses!+0x8c0>
		0000000000006388:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    638c:      	ldr	x0, [sp, #0x120]
    6390:      	mov	x1, x27
    6394:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006394:  ARM64_RELOC_PAGE21	l_stogir.428
    6398:      	ldr	x2, [x2]
		0000000000006398:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    639c:      	movz	x3, #0x0, lsl #48
    63a0:      	bl	0x63a0 <_stogir.placement.early-with-uses!+0x8d8>
		00000000000063a0:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    63a4:      	cmp	x0, #0x0
    63a8:      	b.eq	0x65c4 <_stogir.placement.early-with-uses!+0xafc>
    63ac:      	cmp	x28, #0x0
    63b0:      	b.le	0x63c8 <_stogir.placement.early-with-uses!+0x900>
    63b4:      	mov	x1, #0x1                ; =1
    63b8:      	adrp	x0, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		00000000000063b8:  ARM64_RELOC_PAGE21	l_stogir.433
    63bc:      	ldr	x0, [x0]
		00000000000063bc:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    63c0:      	mov	x27, #0x39              ; =57
    63c4:      	b	0x63d4 <_stogir.placement.early-with-uses!+0x90c>
    63c8:      	and	x0, x26, #0xffffffff
    63cc:      	movz	x1, #0x0, lsl #48
    63d0:      	movz	x27, #0x0, lsl #48
    63d4:      	b	0x63dc <_stogir.placement.early-with-uses!+0x914>
    63d8:      	mov	x1, #0x1                ; =1
    63dc:      	ldr	x2, [sp, #0x118]
    63e0:      	str	x1, [x2]
    63e4:      	str	x0, [x2, #0x8]
    63e8:      	str	x27, [x2, #0x10]
    63ec:      	ldr	x19, [sp, #0x188]
    63f0:      	ldr	x20, [sp, #0x190]
    63f4:      	ldr	x21, [sp, #0x198]
    63f8:      	ldr	x22, [sp, #0x1a0]
    63fc:      	ldr	x23, [sp, #0x1a8]
    6400:      	ldr	x24, [sp, #0x1b0]
    6404:      	ldr	x25, [sp, #0x1b8]
    6408:      	ldr	x26, [sp, #0x1c0]
    640c:      	ldr	x27, [sp, #0x1c8]
    6410:      	ldr	x28, [sp, #0x1d0]
    6414:      	ldr	x29, [sp, #0x10]
    6418:      	ldr	x30, [sp, #0x18]
    641c:      	add	sp, sp, #0x1e0
    6420:      	ret
    6424:      	cmp	x23, x3
    6428:      	b.ne	0x5f78 <_stogir.placement.early-with-uses!+0x4b0>
    642c:      	mov	x1, #0x1                ; =1
    6430:      	b	0x5f7c <_stogir.placement.early-with-uses!+0x4b4>
    6434:      	brk	#0
    6438:      	b	0x6434 <_stogir.placement.early-with-uses!+0x96c>
    643c:      	brk	#0
    6440:      	b	0x643c <_stogir.placement.early-with-uses!+0x974>
    6444:      	str	x20, [sp, #0x118]
    6448:      	str	x23, [sp, #0x138]
    644c:      	str	x19, [sp, #0x100]
    6450:      	str	x26, [sp, #0x108]
    6454:      	str	x0, [sp, #0x120]
    6458:      	str	x1, [sp, #0x130]
    645c:      	b	0x5f54 <_stogir.placement.early-with-uses!+0x48c>
    6460:      	str	x20, [sp, #0x118]
    6464:      	str	x23, [sp, #0x138]
    6468:      	str	x19, [sp, #0x100]
    646c:      	str	x26, [sp, #0x108]
    6470:      	mov	x20, x4
    6474:      	str	x0, [sp, #0x120]
    6478:      	str	x1, [sp, #0x130]
    647c:      	b	0x5ca8 <_stogir.placement.early-with-uses!+0x1e0>
    6480:      	str	x20, [sp, #0x118]
    6484:      	str	x23, [sp, #0x138]
    6488:      	mov	x23, x7
    648c:      	str	x19, [sp, #0x100]
    6490:      	str	x26, [sp, #0x108]
    6494:      	mov	x20, x4
    6498:      	mov	w19, w2
    649c:      	str	x0, [sp, #0x120]
    64a0:      	str	x1, [sp, #0x130]
    64a4:      	b	0x5f0c <_stogir.placement.early-with-uses!+0x444>
    64a8:      	str	x20, [sp, #0x118]
    64ac:      	str	x23, [sp, #0x138]
    64b0:      	mov	x23, x7
    64b4:      	str	x19, [sp, #0x100]
    64b8:      	str	x26, [sp, #0x108]
    64bc:      	mov	x26, x6
    64c0:      	mov	x20, x4
    64c4:      	mov	w19, w2
    64c8:      	str	x0, [sp, #0x120]
    64cc:      	str	x1, [sp, #0x130]
    64d0:      	str	w5, [sp, #0x110]
    64d4:      	str	x3, [sp, #0x128]
    64d8:      	b	0x5de0 <_stogir.placement.early-with-uses!+0x318>
    64dc:      	str	x20, [sp, #0x118]
    64e0:      	str	x23, [sp, #0x138]
    64e4:      	mov	x23, x7
    64e8:      	str	x19, [sp, #0x100]
    64ec:      	str	x26, [sp, #0x108]
    64f0:      	mov	x26, x6
    64f4:      	mov	x20, x4
    64f8:      	mov	w19, w2
    64fc:      	str	x0, [sp, #0x120]
    6500:      	str	x1, [sp, #0x130]
    6504:      	str	w5, [sp, #0x110]
    6508:      	str	x3, [sp, #0x128]
    650c:      	b	0x5de0 <_stogir.placement.early-with-uses!+0x318>
    6510:      	str	x20, [sp, #0x138]
    6514:      	str	x19, [sp, #0x180]
    6518:      	b	0x6094 <_stogir.placement.early-with-uses!+0x5cc>
    651c:      	str	x20, [sp, #0x138]
    6520:      	str	x19, [sp, #0x180]
    6524:      	b	0x6014 <_stogir.placement.early-with-uses!+0x54c>
    6528:      	str	x20, [sp, #0x138]
    652c:      	str	x19, [sp, #0x180]
    6530:      	b	0x6014 <_stogir.placement.early-with-uses!+0x54c>
    6534:      	str	x20, [sp, #0x138]
    6538:      	str	x19, [sp, #0x180]
    653c:      	mov	w19, w0
    6540:      	mov	x20, x1
    6544:      	b	0x5ff8 <_stogir.placement.early-with-uses!+0x530>
    6548:      	str	x23, [sp, #0x178]
    654c:      	str	x21, [sp, #0x140]
    6550:      	str	x24, [sp, #0x168]
    6554:      	mov	x21, x1
    6558:      	mov	w23, w8
    655c:      	b	0x62a4 <_stogir.placement.early-with-uses!+0x7dc>
    6560:      	str	x23, [sp, #0x178]
    6564:      	str	x6, [sp, #0x170]
    6568:      	str	x21, [sp, #0x140]
    656c:      	str	x24, [sp, #0x168]
    6570:      	mov	x24, x5
    6574:      	mov	x21, x1
    6578:      	str	x3, [sp, #0x160]
    657c:      	str	w0, [sp, #0x148]
    6580:      	str	w4, [sp, #0x150]
    6584:      	str	x2, [sp, #0x158]
    6588:      	b	0x6164 <_stogir.placement.early-with-uses!+0x69c>
    658c:      	str	x23, [sp, #0x178]
    6590:      	str	x6, [sp, #0x170]
    6594:      	str	x21, [sp, #0x140]
    6598:      	str	x24, [sp, #0x168]
    659c:      	mov	x24, x5
    65a0:      	mov	x21, x1
    65a4:      	str	x3, [sp, #0x160]
    65a8:      	str	w0, [sp, #0x148]
    65ac:      	str	w4, [sp, #0x150]
    65b0:      	str	x2, [sp, #0x158]
    65b4:      	b	0x6164 <_stogir.placement.early-with-uses!+0x69c>
    65b8:      	str	x20, [sp, #0x138]
    65bc:      	str	x19, [sp, #0x180]
    65c0:      	b	0x60a4 <_stogir.placement.early-with-uses!+0x5dc>
    65c4:      	ldr	x0, [sp, #0x120]
    65c8:      	b	0x63d8 <_stogir.placement.early-with-uses!+0x910>

00000000000065cc <_coil.core.Eq$slice<u8>$=>:
    65cc:      	sub	sp, sp, #0x10
    65d0:      	str	x29, [sp]
    65d4:      	str	x30, [sp, #0x8]
    65d8:      	mov	x29, sp
    65dc:      	cmp	x1, x3
    65e0:      	b.ne	0x661c <_coil.core.Eq$slice<u8>$=+0x50>
    65e4:      	cmp	x1, #0x0
    65e8:      	b.ne	0x65f4 <_coil.core.Eq$slice<u8>$=+0x28>
    65ec:      	mov	x0, #0x1                ; =1
    65f0:      	b	0x6618 <_coil.core.Eq$slice<u8>$=+0x4c>
    65f4:      	lsr	x1, x1, #0
    65f8:      	fmov	d31, x1
    65fc:      	mov	x1, x2
    6600:      	fmov	x2, d31
    6604:      	bl	0x6604 <_coil.core.Eq$slice<u8>$=+0x38>
		0000000000006604:  ARM64_RELOC_BRANCH26	_memcmp
    6608:      	sxtw	x0, w0
    660c:      	cmp	x0, #0x0
    6610:      	cset	w0, eq
    6614:      	ubfx	x0, x0, #0, #8
    6618:      	b	0x6620 <_coil.core.Eq$slice<u8>$=+0x54>
    661c:      	movz	x0, #0x0, lsl #48
    6620:      	ldr	x29, [sp]
    6624:      	ldr	x30, [sp, #0x8]
    6628:      	add	sp, sp, #0x10
    662c:      	ret

0000000000006630 <_stogir.placement.late-with-uses!>:
    6630:      	sub	sp, sp, #0x1f0
    6634:      	str	x29, [sp]
    6638:      	str	x30, [sp, #0x8]
    663c:      	mov	x29, sp
    6640:      	str	x19, [sp, #0x1a0]
    6644:      	str	x20, [sp, #0x1a8]
    6648:      	str	x21, [sp, #0x1b0]
    664c:      	str	x22, [sp, #0x1b8]
    6650:      	str	x23, [sp, #0x1c0]
    6654:      	str	x24, [sp, #0x1c8]
    6658:      	str	x25, [sp, #0x1d0]
    665c:      	str	x26, [sp, #0x1d8]
    6660:      	str	x27, [sp, #0x1e0]
    6664:      	str	x28, [sp, #0x1e8]
    6668:      	add	x16, sp, #0x10
    666c:      	orr	x19, x16, xzr
    6670:      	mov	x20, x8
    6674:      	add	x8, sp, #0x40
    6678:      	mov	x21, x0
    667c:      	mov	x0, x6
    6680:      	mov	x22, x1
    6684:      	mov	x23, x2
    6688:      	mov	x24, x3
    668c:      	mov	x25, x4
    6690:      	mov	x26, x5
    6694:      	mov	x27, x6
    6698:      	bl	0x6698 <_stogir.placement.late-with-uses!+0x68>
		0000000000006698:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    669c:      	add	x16, sp, #0x40
    66a0:      	ldr	x0, [x16]
    66a4:      	add	x16, sp, #0x10
    66a8:      	str	x0, [x16]
    66ac:      	add	x16, sp, #0x40
    66b0:      	ldr	x0, [x16, #0x8]
    66b4:      	add	x16, sp, #0x10
    66b8:      	str	x0, [x16, #0x8]
    66bc:      	add	x16, sp, #0x40
    66c0:      	ldr	x0, [x16, #0x10]
    66c4:      	add	x16, sp, #0x10
    66c8:      	str	x0, [x16, #0x10]
    66cc:      	add	x16, sp, #0x40
    66d0:      	ldr	x0, [x16, #0x18]
    66d4:      	add	x16, sp, #0x10
    66d8:      	str	x0, [x16, #0x18]
    66dc:      	add	x16, sp, #0x40
    66e0:      	ldr	x0, [x16, #0x20]
    66e4:      	add	x16, sp, #0x10
    66e8:      	str	x0, [x16, #0x20]
    66ec:      	add	x8, sp, #0xa0
    66f0:      	mov	x0, x27
    66f4:      	bl	0x66f4 <_stogir.placement.late-with-uses!+0xc4>
		00000000000066f4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    66f8:      	add	x16, sp, #0xa0
    66fc:      	ldr	x0, [x16]
    6700:      	add	x16, sp, #0x70
    6704:      	str	x0, [x16]
    6708:      	add	x16, sp, #0xa0
    670c:      	ldr	x0, [x16, #0x8]
    6710:      	add	x16, sp, #0x70
    6714:      	str	x0, [x16, #0x8]
    6718:      	add	x16, sp, #0xa0
    671c:      	ldr	x0, [x16, #0x10]
    6720:      	add	x16, sp, #0x70
    6724:      	str	x0, [x16, #0x10]
    6728:      	add	x16, sp, #0xa0
    672c:      	ldr	x0, [x16, #0x18]
    6730:      	add	x16, sp, #0x70
    6734:      	str	x0, [x16, #0x18]
    6738:      	add	x16, sp, #0xa0
    673c:      	ldr	x0, [x16, #0x20]
    6740:      	add	x16, sp, #0x70
    6744:      	str	x0, [x16, #0x20]
    6748:      	movz	x27, #0x0, lsl #48
    674c:      	b	0x6764 <_stogir.placement.late-with-uses!+0x134>
    6750:      	add	x27, x27, #0x1
    6754:      	mov	x0, x19
    6758:      	mov	x1, #0xffff             ; =65535
    675c:      	movk	x1, #0xffff, lsl #16
    6760:      	bl	0x6760 <_stogir.placement.late-with-uses!+0x130>
		0000000000006760:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    6764:      	ldr	x0, [x21, #0x8]
    6768:      	cmp	x27, x0
    676c:      	b.lt	0x6750 <_stogir.placement.late-with-uses!+0x120>
    6770:      	mov	x27, #0x1               ; =1
    6774:      	movz	x28, #0x0, lsl #48
    6778:      	b	0x67b8 <_stogir.placement.late-with-uses!+0x188>
    677c:      	nop
    6780:      	add	x28, x28, #0x1
    6784:      	ldr	x0, [sp, #0x110]
    6788:      	mov	x1, x27
    678c:      	movz	x2, #0x0, lsl #48
    6790:      	bl	0x6790 <_stogir.placement.late-with-uses!+0x160>
		0000000000006790:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    6794:      	sxtw	x28, w28
    6798:      	sxtw	x19, w19
    679c:      	add	x0, x19, #0x4
    67a0:      	asr	x16, x0, #63
    67a4:      	lsr	x16, x16, #62
    67a8:      	add	x0, x0, x16
    67ac:      	asr	x0, x0, #2
    67b0:      	add	x27, x0, x27
    67b4:      	ldr	x19, [sp, #0x110]
    67b8:      	ldr	x0, [x21, #0x8]
    67bc:      	cmp	x27, x0
    67c0:      	b.ge	0x7110 <_stogir.placement.late-with-uses!+0xae0>
    67c4:      	ldr	x0, [x21]
    67c8:      	add	x0, x0, x27, lsl #4
    67cc:      	ldr	x0, [x0]
    67d0:      	ldr	x1, [x21, #0x78]
    67d4:      	uxtb	w0, w0
    67d8:      	add	x1, x1, x27, lsl #2
    67dc:      	ldr	w1, [x1]
    67e0:      	str	x19, [sp, #0x110]
    67e4:      	mov	w19, w1
    67e8:      	bl	0x67e8 <_stogir.placement.late-with-uses!+0x1b8>
		00000000000067e8:  ARM64_RELOC_BRANCH26	_stogir.opcode.properties
    67ec:      	ldr	x1, [x25]
    67f0:      	add	x1, x27, x1
    67f4:      	ldrb	w1, [x1]
    67f8:      	cmp	x1, #0x0
    67fc:      	b.eq	0x6798 <_stogir.placement.late-with-uses!+0x168>
    6800:      	uxtb	w0, w0
    6804:      	uxtb	w16, w0
    6808:      	and	w0, w16, #0x40
    680c:      	uxtb	w0, w0
    6810:      	ubfx	x0, x0, #0, #8
    6814:      	cmp	x0, #0x0
    6818:      	b.ne	0x6780 <_stogir.placement.late-with-uses!+0x150>
    681c:      	b	0x6798 <_stogir.placement.late-with-uses!+0x168>
    6820:      	add	x16, sp, #0x70
    6824:      	orr	x19, x16, xzr
    6828:      	mov	x27, #0x1               ; =1
    682c:      	b	0x68b4 <_stogir.placement.late-with-uses!+0x284>
    6830:      	add	x3, x3, #0x1
    6834:      	sxtw	x3, w3
    6838:      	add	x2, x2, #0x1
    683c:      	cmp	x2, x0
    6840:      	b.ge	0x6878 <_stogir.placement.late-with-uses!+0x248>
    6844:      	add	x4, x1, x2
    6848:      	ldr	x5, [x26, #0x28]
    684c:      	add	x4, x5, x4, lsl #3
    6850:      	ldr	x4, [x4]
    6854:      	add	x16, sp, #0x10
    6858:      	ldr	x5, [x16]
    685c:      	sxtw	x4, w4
    6860:      	add	x4, x5, x4, lsl #2
    6864:      	ldr	w4, [x4]
    6868:      	sxtw	x4, w4
    686c:      	cmp	x4, #0x0
    6870:      	b.ge	0x6830 <_stogir.placement.late-with-uses!+0x200>
    6874:      	b	0x6838 <_stogir.placement.late-with-uses!+0x208>
    6878:      	orr	w0, w3, wzr
    687c:      	mov	x1, x27
    6880:      	mov	w2, w0
    6884:      	ldr	x0, [sp, #0x110]
    6888:      	str	x19, [sp, #0x118]
    688c:      	mov	x19, x3
    6890:      	bl	0x6890 <_stogir.placement.late-with-uses!+0x260>
		0000000000006890:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    6894:      	cmp	x19, #0x0
    6898:      	b.ne	0x68ac <_stogir.placement.late-with-uses!+0x27c>
    689c:      	orr	w0, w27, wzr
    68a0:      	mov	w1, w0
    68a4:      	ldr	x0, [sp, #0x118]
    68a8:      	bl	0x68a8 <_stogir.placement.late-with-uses!+0x278>
		00000000000068a8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    68ac:      	add	x27, x27, #0x1
    68b0:      	ldr	x19, [sp, #0x118]
    68b4:      	add	x16, sp, #0x10
    68b8:      	ldr	x0, [x16, #0x8]
    68bc:      	cmp	x27, x0
    68c0:      	b.ge	0x7118 <_stogir.placement.late-with-uses!+0xae8>
    68c4:      	add	x16, sp, #0x10
    68c8:      	ldr	x0, [x16]
    68cc:      	add	x0, x0, x27, lsl #2
    68d0:      	ldr	w0, [x0]
    68d4:      	sxtw	x0, w0
    68d8:      	cmp	x0, #0x0
    68dc:      	b.ne	0x7120 <_stogir.placement.late-with-uses!+0xaf0>
    68e0:      	ldr	x0, [x26]
    68e4:      	add	x0, x0, x27, lsl #4
    68e8:      	ldr	x1, [x0]
    68ec:      	ldr	x0, [x0, #0x8]
    68f0:      	movz	x2, #0x0, lsl #48
    68f4:      	movz	x3, #0x0, lsl #48
    68f8:      	b	0x683c <_stogir.placement.late-with-uses!+0x20c>
    68fc:      	add	x16, sp, #0xd0
    6900:      	orr	x0, x16, xzr
    6904:      	add	x16, sp, #0xf0
    6908:      	orr	x1, x16, xzr
    690c:      	add	x19, x21, #0x78
    6910:      	add	x27, x0, #0x8
    6914:      	add	x0, x1, #0x8
    6918:      	movz	x1, #0x0, lsl #48
    691c:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		000000000000691c:  ARM64_RELOC_PAGE21	l_stogir.434
    6920:      	ldr	x2, [x2]
		0000000000006920:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    6924:      	movz	x3, #0x0, lsl #48
    6928:      	b	0x697c <_stogir.placement.late-with-uses!+0x34c>
    692c:      	movz	w6, #0x0, lsl #16
    6930:      	movz	w5, #0x0, lsl #16
    6934:      	b	0x6d44 <_stogir.placement.late-with-uses!+0x714>
    6938:      	ldr	x20, [sp, #0x130]
    693c:      	sub	x0, x20, #0x1
    6940:      	sxtw	x20, w0
    6944:      	ldr	x0, [sp, #0x160]
    6948:      	add	x0, x0, #0x1
    694c:      	mov	x21, x26
    6950:      	ldr	x22, [sp, #0x198]
    6954:      	ldr	x24, [sp, #0x120]
    6958:      	ldr	x26, [sp, #0x158]
    695c:      	ldr	x25, [sp, #0x140]
    6960:      	mov	x1, x0
    6964:      	ldr	x0, [sp, #0x170]
    6968:      	mov	x2, x28
    696c:      	mov	x28, x20
    6970:      	ldr	x20, [sp, #0x128]
    6974:      	mov	x3, x19
    6978:      	ldr	x19, [sp, #0x138]
    697c:      	str	x24, [sp, #0x120]
    6980:      	mov	x24, x0
    6984:      	mov	x0, x2
    6988:      	str	x20, [sp, #0x128]
    698c:      	mov	x20, x1
    6990:      	mov	x1, x3
    6994:      	str	x28, [sp, #0x130]
    6998:      	mov	x28, x2
    699c:      	str	x19, [sp, #0x138]
    69a0:      	mov	x19, x3
    69a4:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		00000000000069a4:  ARM64_RELOC_PAGE21	l_stogir.434
    69a8:      	ldr	x2, [x2]
		00000000000069a8:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    69ac:      	movz	x3, #0x0, lsl #48
    69b0:      	bl	0x69b0 <_stogir.placement.late-with-uses!+0x380>
		00000000000069b0:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    69b4:      	cmp	x0, #0x0
    69b8:      	b.eq	0x69d4 <_stogir.placement.late-with-uses!+0x3a4>
    69bc:      	add	x16, sp, #0x70
    69c0:      	ldr	x0, [x16, #0x8]
    69c4:      	cmp	x20, x0
    69c8:      	cset	w0, lt
    69cc:      	ubfx	x0, x0, #0, #8
    69d0:      	b	0x69d8 <_stogir.placement.late-with-uses!+0x3a8>
    69d4:      	movz	x0, #0x0, lsl #48
    69d8:      	cmp	x0, #0x0
    69dc:      	b.eq	0x7128 <_stogir.placement.late-with-uses!+0xaf8>
    69e0:      	add	x16, sp, #0x70
    69e4:      	ldr	x0, [x16]
    69e8:      	add	x0, x0, x20, lsl #2
    69ec:      	ldr	w0, [x0]
    69f0:      	sxtw	x0, w0
    69f4:      	ldr	x1, [x26]
    69f8:      	add	x1, x1, x0, lsl #4
    69fc:      	ldr	x2, [x1]
    6a00:      	ldr	x1, [x1, #0x8]
    6a04:      	movz	x3, #0x0, lsl #48
    6a08:      	movz	w4, #0x0, lsl #16
    6a0c:      	b	0x6a40 <_stogir.placement.late-with-uses!+0x410>
    6a10:      	movz	x20, #0x0, lsl #48
    6a14:      	add	x26, x26, #0x1
    6a18:      	ldr	x21, [sp, #0x168]
    6a1c:      	mov	x0, x25
    6a20:      	ldr	x2, [sp, #0x148]
    6a24:      	ldr	x1, [sp, #0x150]
    6a28:      	ldr	x25, [sp, #0x140]
    6a2c:      	ldr	x24, [sp, #0x170]
    6a30:      	mov	x3, x26
    6a34:      	ldr	x26, [sp, #0x158]
    6a38:      	mov	w4, w20
    6a3c:      	ldr	x20, [sp, #0x160]
    6a40:      	cmp	x19, #0x0
    6a44:      	b.ne	0x6a58 <_stogir.placement.late-with-uses!+0x428>
    6a48:      	cmp	x3, x1
    6a4c:      	cset	w5, lt
    6a50:      	ubfx	x5, x5, #0, #8
    6a54:      	b	0x6a5c <_stogir.placement.late-with-uses!+0x42c>
    6a58:      	movz	x5, #0x0, lsl #48
    6a5c:      	sxtw	x6, w4
    6a60:      	cmp	x6, #0x0
    6a64:      	cset	w7, eq
    6a68:      	cmp	x5, #0x0
    6a6c:      	b.eq	0x7130 <_stogir.placement.late-with-uses!+0xb00>
    6a70:      	add	x5, x2, x3
    6a74:      	ldr	x8, [x26, #0x28]
    6a78:      	add	x5, x8, x5, lsl #3
    6a7c:      	ldr	x5, [x5]
    6a80:      	ldr	x8, [x25]
    6a84:      	orr	w9, w5, wzr
    6a88:      	sxtw	x10, w9
    6a8c:      	add	x8, x8, x10
    6a90:      	ldrb	w8, [x8]
    6a94:      	cmp	x8, #0x0
    6a98:      	b.eq	0x7154 <_stogir.placement.late-with-uses!+0xb24>
    6a9c:      	lsr	x5, x5, #32
    6aa0:      	add	x8, sp, #0xd0
    6aa4:      	str	x2, [sp, #0x148]
    6aa8:      	mov	w2, w9
    6aac:      	str	x1, [sp, #0x150]
    6ab0:      	mov	x1, x22
    6ab4:      	str	x25, [sp, #0x140]
    6ab8:      	mov	x25, x0
    6abc:      	mov	x0, x21
    6ac0:      	str	x26, [sp, #0x158]
    6ac4:      	mov	x26, x3
    6ac8:      	mov	w3, w5
    6acc:      	str	x20, [sp, #0x160]
    6ad0:      	mov	w20, w4
    6ad4:      	str	x21, [sp, #0x168]
    6ad8:      	mov	x21, x6
    6adc:      	str	x24, [sp, #0x170]
    6ae0:      	mov	w24, w7
    6ae4:      	bl	0x6ae4 <_stogir.placement.late-with-uses!+0x4b4>
		0000000000006ae4:  ARM64_RELOC_BRANCH26	_stogir.placement.use-block
    6ae8:      	add	x16, sp, #0xd0
    6aec:      	ldr	w0, [x16]
    6af0:      	lsr	x16, x0, #0
    6af4:      	cmp	x16, #0x1
    6af8:      	b.eq	0x6b14 <_stogir.placement.late-with-uses!+0x4e4>
    6afc:      	b.lo	0x6b04 <_stogir.placement.late-with-uses!+0x4d4>
    6b00:      	b	0x6b18 <_stogir.placement.late-with-uses!+0x4e8>
    6b04:      	cmp	x16, #0x0
    6b08:      	b.eq	0x6b10 <_stogir.placement.late-with-uses!+0x4e0>
    6b0c:      	b	0x6b18 <_stogir.placement.late-with-uses!+0x4e8>
    6b10:      	b	0x6b2c <_stogir.placement.late-with-uses!+0x4fc>
    6b14:      	b	0x6b1c <_stogir.placement.late-with-uses!+0x4ec>
    6b18:      	b	0x6fc8 <_stogir.placement.late-with-uses!+0x998>
    6b1c:      	add	x16, sp, #0xd0
    6b20:      	ldr	x28, [x16, #0x8]
    6b24:      	ldr	x19, [x27, #0x8]
    6b28:      	b	0x6a14 <_stogir.placement.late-with-uses!+0x3e4>
    6b2c:      	add	x16, sp, #0xd0
    6b30:      	ldr	w0, [x16, #0x8]
    6b34:      	orr	w1, w0, wzr
    6b38:      	uxtb	w16, w24
    6b3c:      	cmp	w16, wzr
    6b40:      	b.eq	0x6b7c <_stogir.placement.late-with-uses!+0x54c>
    6b44:      	mov	w20, w1
    6b48:      	b	0x6a14 <_stogir.placement.late-with-uses!+0x3e4>
    6b4c:      	mov	x0, x28
    6b50:      	mov	x1, x19
    6b54:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006b54:  ARM64_RELOC_PAGE21	l_stogir.434
    6b58:      	ldr	x2, [x2]
		0000000000006b58:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    6b5c:      	movz	x3, #0x0, lsl #48
    6b60:      	bl	0x6b60 <_stogir.placement.late-with-uses!+0x530>
		0000000000006b60:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6b64:      	cmp	x0, #0x0
    6b68:      	b.eq	0x6bdc <_stogir.placement.late-with-uses!+0x5ac>
    6b6c:      	uxtb	w16, w24
    6b70:      	cmp	w16, wzr
    6b74:      	cset	x0, eq
    6b78:      	b	0x6be0 <_stogir.placement.late-with-uses!+0x5b0>
    6b7c:      	cmp	x21, #0x0
    6b80:      	b.le	0x6a10 <_stogir.placement.late-with-uses!+0x3e0>
    6b84:      	sxtw	x0, w0
    6b88:      	cmp	x0, #0x0
    6b8c:      	b.le	0x6a10 <_stogir.placement.late-with-uses!+0x3e0>
    6b90:      	ldr	x2, [x23, #0x8]
    6b94:      	cmp	x21, x2
    6b98:      	b.ge	0x6a10 <_stogir.placement.late-with-uses!+0x3e0>
    6b9c:      	cmp	x0, x2
    6ba0:      	b.ge	0x6a10 <_stogir.placement.late-with-uses!+0x3e0>
    6ba4:      	ldr	x2, [x23]
    6ba8:      	add	x3, x2, x21, lsl #2
    6bac:      	ldr	w3, [x3]
    6bb0:      	sxtw	x3, w3
    6bb4:      	cmp	x3, #0x0
    6bb8:      	b.eq	0x6fc0 <_stogir.placement.late-with-uses!+0x990>
    6bbc:      	add	x0, x2, x0, lsl #2
    6bc0:      	ldr	w0, [x0]
    6bc4:      	sxtw	x0, w0
    6bc8:      	cmp	x0, #0x0
    6bcc:      	b.eq	0x6fc0 <_stogir.placement.late-with-uses!+0x990>
    6bd0:      	mov	w2, w20
    6bd4:      	movz	x0, #0x0, lsl #48
    6bd8:      	b	0x70d8 <_stogir.placement.late-with-uses!+0xaa8>
    6bdc:      	movz	x0, #0x0, lsl #48
    6be0:      	lsl	x21, x25, #2
    6be4:      	cmp	x0, #0x0
    6be8:      	b.eq	0x7180 <_stogir.placement.late-with-uses!+0xb50>
    6bec:      	ldr	x0, [x22]
    6bf0:      	add	x0, x21, x0
    6bf4:      	ldr	w0, [x0]
    6bf8:      	add	x8, sp, #0xf0
    6bfc:      	ldr	x1, [sp, #0x120]
    6c00:      	mov	w2, w0
    6c04:      	mov	x0, x23
    6c08:      	mov	w3, w20
    6c0c:      	bl	0x6c0c <_stogir.placement.late-with-uses!+0x5dc>
		0000000000006c0c:  ARM64_RELOC_BRANCH26	_stogir.placement.choose-block
    6c10:      	add	x16, sp, #0xf0
    6c14:      	ldr	w0, [x16]
    6c18:      	lsr	x16, x0, #0
    6c1c:      	cmp	x16, #0x1
    6c20:      	b.eq	0x6c40 <_stogir.placement.late-with-uses!+0x610>
    6c24:      	b.lo	0x6c2c <_stogir.placement.late-with-uses!+0x5fc>
    6c28:      	b	0x6c44 <_stogir.placement.late-with-uses!+0x614>
    6c2c:      	cmp	x16, #0x0
    6c30:      	b.eq	0x6c38 <_stogir.placement.late-with-uses!+0x608>
    6c34:      	b	0x6c44 <_stogir.placement.late-with-uses!+0x614>
    6c38:      	ldr	x20, [sp, #0x170]
    6c3c:      	b	0x6c5c <_stogir.placement.late-with-uses!+0x62c>
    6c40:      	b	0x6c48 <_stogir.placement.late-with-uses!+0x618>
    6c44:      	b	0x7108 <_stogir.placement.late-with-uses!+0xad8>
    6c48:      	add	x16, sp, #0xf0
    6c4c:      	ldr	x28, [x16, #0x8]
    6c50:      	ldr	x20, [sp, #0x170]
    6c54:      	ldr	x19, [x20, #0x8]
    6c58:      	b	0x6c74 <_stogir.placement.late-with-uses!+0x644>
    6c5c:      	add	x16, sp, #0xf0
    6c60:      	ldr	w0, [x16, #0x8]
    6c64:      	mov	x1, x25
    6c68:      	mov	w2, w0
    6c6c:      	mov	x0, x22
    6c70:      	bl	0x6c70 <_stogir.placement.late-with-uses!+0x640>
		0000000000006c70:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    6c74:      	mov	x0, x28
    6c78:      	mov	x1, x19
    6c7c:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006c7c:  ARM64_RELOC_PAGE21	l_stogir.434
    6c80:      	ldr	x2, [x2]
		0000000000006c80:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    6c84:      	movz	x3, #0x0, lsl #48
    6c88:      	bl	0x6c88 <_stogir.placement.late-with-uses!+0x658>
		0000000000006c88:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6c8c:      	cmp	x0, #0x0
    6c90:      	b.eq	0x7188 <_stogir.placement.late-with-uses!+0xb58>
    6c94:      	cmp	x25, #0x0
    6c98:      	cset	w24, le
    6c9c:      	ldr	x26, [sp, #0x168]
    6ca0:      	ldr	x0, [x26]
    6ca4:      	add	x0, x0, x25, lsl #4
    6ca8:      	ldr	x0, [x0]
    6cac:      	ldr	x1, [x26, #0x78]
    6cb0:      	uxtb	w0, w0
    6cb4:      	add	x1, x1, x25, lsl #2
    6cb8:      	cmp	x0, #0x83
    6cbc:      	cset	w2, lt
    6cc0:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006cc0:  ARM64_RELOC_PAGE21	l_stogir.435
    6cc4:      	ldr	x16, [x16]
		0000000000006cc4:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    6cc8:      	add	x0, x16, x0, lsl #2
    6ccc:      	ldr	w1, [x1]
    6cd0:      	sxtw	x1, w1
    6cd4:      	mov	x3, #0x1                ; =1
    6cd8:      	b	0x6dc4 <_stogir.placement.late-with-uses!+0x794>
    6cdc:      	sub	w4, w4, #0x1
    6ce0:      	lsl	w4, w4, #2
    6ce4:      	ubfx	x4, x4, #0, #32
    6ce8:      	lsr	x4, x6, x4
    6cec:      	and	w4, w4, #0xf
    6cf0:      	b	0x6cf8 <_stogir.placement.late-with-uses!+0x6c8>
    6cf4:      	movz	w4, #0x0, lsl #16
    6cf8:      	b	0x6d04 <_stogir.placement.late-with-uses!+0x6d4>
    6cfc:      	nop
    6d00:      	movz	w4, #0x0, lsl #16
    6d04:      	ubfx	x4, x4, #0, #32
    6d08:      	cmp	x4, #0xf
    6d0c:      	b.hs	0x719c <_stogir.placement.late-with-uses!+0xb6c>
    6d10:      	mov	x16, #0x1               ; =1
    6d14:      	lsl	x4, x16, x4
    6d18:      	mov	w17, #0x5e1c            ; =24092
    6d1c:      	and	w4, w4, w17
    6d20:      	ubfx	x4, x4, #0, #32
    6d24:      	cmp	x4, #0x0
    6d28:      	b.eq	0x71bc <_stogir.placement.late-with-uses!+0xb8c>
    6d2c:      	uxtb	w16, w24
    6d30:      	cmp	w16, wzr
    6d34:      	b.eq	0x6dfc <_stogir.placement.late-with-uses!+0x7cc>
    6d38:      	ldr	x4, [sp, #0x138]
    6d3c:      	movz	w6, #0x0, lsl #16
    6d40:      	movz	w5, #0x0, lsl #16
    6d44:      	ubfx	x6, x6, #0, #32
    6d48:      	lsr	x16, x6, #0
    6d4c:      	cmp	x16, #0x1
    6d50:      	b.eq	0x6d6c <_stogir.placement.late-with-uses!+0x73c>
    6d54:      	b.lo	0x6d5c <_stogir.placement.late-with-uses!+0x72c>
    6d58:      	b	0x6d70 <_stogir.placement.late-with-uses!+0x740>
    6d5c:      	cmp	x16, #0x0
    6d60:      	b.eq	0x6d68 <_stogir.placement.late-with-uses!+0x738>
    6d64:      	b	0x6d70 <_stogir.placement.late-with-uses!+0x740>
    6d68:      	b	0x6d74 <_stogir.placement.late-with-uses!+0x744>
    6d6c:      	b	0x6e38 <_stogir.placement.late-with-uses!+0x808>
    6d70:      	b	0x7100 <_stogir.placement.late-with-uses!+0xad0>
    6d74:      	str	x22, [sp, #0x198]
    6d78:      	str	x21, [sp, #0x190]
    6d7c:      	str	x20, [sp, #0x170]
    6d80:      	mov	x20, x3
    6d84:      	str	x1, [sp, #0x188]
    6d88:      	str	w2, [sp, #0x178]
    6d8c:      	str	x0, [sp, #0x180]
    6d90:      	str	x4, [sp, #0x138]
    6d94:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006d94:  ARM64_RELOC_PAGE21	l_stogir.436
    6d98:      	ldr	x28, [x28]
		0000000000006d98:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    6d9c:      	mov	x19, #0x1e              ; =30
    6da0:      	add	x0, x20, #0x1
    6da4:      	sxtw	x20, w0
    6da8:      	ldr	x22, [sp, #0x198]
    6dac:      	ldr	x21, [sp, #0x190]
    6db0:      	ldr	x1, [sp, #0x188]
    6db4:      	ldr	w2, [sp, #0x178]
    6db8:      	ldr	x0, [sp, #0x180]
    6dbc:      	mov	x3, x20
    6dc0:      	ldr	x20, [sp, #0x170]
    6dc4:      	cmp	x3, x1
    6dc8:      	b.gt	0x71dc <_stogir.placement.late-with-uses!+0xbac>
    6dcc:      	orr	w4, w3, wzr
    6dd0:      	sxtw	x5, w4
    6dd4:      	uxtb	w16, w2
    6dd8:      	cmp	w16, wzr
    6ddc:      	b.eq	0x6d00 <_stogir.placement.late-with-uses!+0x6d0>
    6de0:      	ldr	w6, [x0]
    6de4:      	cmp	x5, #0x0
    6de8:      	b.le	0x6cf4 <_stogir.placement.late-with-uses!+0x6c4>
    6dec:      	cmp	x5, #0x4
    6df0:      	b.le	0x6cdc <_stogir.placement.late-with-uses!+0x6ac>
    6df4:      	mov	w4, #0x4                ; =4
    6df8:      	b	0x6ce0 <_stogir.placement.late-with-uses!+0x6b0>
    6dfc:      	ldr	x4, [x26, #0x8]
    6e00:      	cmp	x25, x4
    6e04:      	b.ge	0x71e8 <_stogir.placement.late-with-uses!+0xbb8>
    6e08:      	ldr	x4, [sp, #0x138]
    6e0c:      	ldr	x6, [x4, #0x8]
    6e10:      	cmp	x25, x6
    6e14:      	b.ge	0x6e9c <_stogir.placement.late-with-uses!+0x86c>
    6e18:      	ldr	x6, [x26, #0x78]
    6e1c:      	add	x6, x21, x6
    6e20:      	ldr	w6, [x6]
    6e24:      	sxtw	x6, w6
    6e28:      	cmp	x6, #0x0
    6e2c:      	cset	w6, ge
    6e30:      	ubfx	x6, x6, #0, #8
    6e34:      	b	0x6ea0 <_stogir.placement.late-with-uses!+0x870>
    6e38:      	sxtw	x6, w5
    6e3c:      	cmp	x6, #0x0
    6e40:      	b.le	0x71f0 <_stogir.placement.late-with-uses!+0xbc0>
    6e44:      	add	x16, sp, #0x10
    6e48:      	ldr	x7, [x16]
    6e4c:      	add	x8, x7, x6, lsl #2
    6e50:      	ldr	w8, [x8]
    6e54:      	sxtw	x9, w8
    6e58:      	cmp	x9, #0x0
    6e5c:      	b.le	0x7214 <_stogir.placement.late-with-uses!+0xbe4>
    6e60:      	sub	w8, w8, #0x1
    6e64:      	add	x6, x7, x6, lsl #2
    6e68:      	str	w8, [x6]
    6e6c:      	cmp	x9, #0x1
    6e70:      	b.ne	0x7238 <_stogir.placement.late-with-uses!+0xc08>
    6e74:      	add	x16, sp, #0x70
    6e78:      	ldr	x6, [x16, #0x8]
    6e7c:      	add	x16, sp, #0x70
    6e80:      	ldr	x7, [x16, #0x10]
    6e84:      	cmp	x6, x7
    6e88:      	b.lt	0x725c <_stogir.placement.late-with-uses!+0xc2c>
    6e8c:      	cmp	x7, #0x0
    6e90:      	b.ne	0x6fd0 <_stogir.placement.late-with-uses!+0x9a0>
    6e94:      	mov	x7, #0x2                ; =2
    6e98:      	b	0x6fd4 <_stogir.placement.late-with-uses!+0x9a4>
    6e9c:      	movz	x6, #0x0, lsl #48
    6ea0:      	b	0x6ea8 <_stogir.placement.late-with-uses!+0x878>
    6ea4:      	movz	x6, #0x0, lsl #48
    6ea8:      	cmp	x6, #0x0
    6eac:      	b.eq	0x6d3c <_stogir.placement.late-with-uses!+0x70c>
    6eb0:      	cmp	x5, #0x1
    6eb4:      	b.lt	0x692c <_stogir.placement.late-with-uses!+0x2fc>
    6eb8:      	ldr	x6, [x26, #0x78]
    6ebc:      	add	x6, x21, x6
    6ec0:      	ldr	w6, [x6]
    6ec4:      	sxtw	x6, w6
    6ec8:      	cmp	x5, x6
    6ecc:      	b.gt	0x692c <_stogir.placement.late-with-uses!+0x2fc>
    6ed0:      	ldr	x6, [x26]
    6ed4:      	asr	x16, x5, #63
    6ed8:      	lsr	x16, x16, #62
    6edc:      	add	x7, x5, x16
    6ee0:      	asr	x7, x7, #2
    6ee4:      	asr	x16, x5, #63
    6ee8:      	lsr	x16, x16, #62
    6eec:      	add	x5, x5, x16
    6ef0:      	and	x5, x5, #0x3
    6ef4:      	sub	x5, x5, x16
    6ef8:      	add	x7, x7, x25
    6efc:      	add	x6, x6, x7, lsl #4
    6f00:      	add	x5, x6, x5, lsl #2
    6f04:      	ldr	w5, [x5]
    6f08:      	movn	w17, #0x0, lsl #16
    6f0c:      	and	w5, w5, w17
    6f10:      	mov	w6, #0x1                ; =1
    6f14:      	b	0x6934 <_stogir.placement.late-with-uses!+0x304>
    6f18:      	ldr	x0, [sp, #0x110]
    6f1c:      	bl	0x6f1c <_stogir.placement.late-with-uses!+0x8ec>
		0000000000006f1c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    6f20:      	ldr	x0, [sp, #0x118]
    6f24:      	bl	0x6f24 <_stogir.placement.late-with-uses!+0x8f4>
		0000000000006f24:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    6f28:      	mov	x0, x28
    6f2c:      	mov	x1, x19
    6f30:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006f30:  ARM64_RELOC_PAGE21	l_stogir.434
    6f34:      	ldr	x2, [x2]
		0000000000006f34:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    6f38:      	movz	x3, #0x0, lsl #48
    6f3c:      	bl	0x6f3c <_stogir.placement.late-with-uses!+0x90c>
		0000000000006f3c:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6f40:      	cmp	x0, #0x0
    6f44:      	b.eq	0x6f74 <_stogir.placement.late-with-uses!+0x944>
    6f48:      	cmp	x20, #0x0
    6f4c:      	b.le	0x6f64 <_stogir.placement.late-with-uses!+0x934>
    6f50:      	mov	x0, #0x1                ; =1
    6f54:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x538>
		0000000000006f54:  ARM64_RELOC_PAGE21	l_stogir.437
    6f58:      	ldr	x28, [x28]
		0000000000006f58:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    6f5c:      	mov	x19, #0x26              ; =38
    6f60:      	b	0x6f70 <_stogir.placement.late-with-uses!+0x940>
    6f64:      	movz	x0, #0x0, lsl #48
    6f68:      	movz	x28, #0x0, lsl #48
    6f6c:      	movz	x19, #0x0, lsl #48
    6f70:      	b	0x6f78 <_stogir.placement.late-with-uses!+0x948>
    6f74:      	mov	x0, #0x1                ; =1
    6f78:      	ldr	x1, [sp, #0x128]
    6f7c:      	str	x0, [x1]
    6f80:      	str	x28, [x1, #0x8]
    6f84:      	str	x19, [x1, #0x10]
    6f88:      	ldr	x19, [sp, #0x1a0]
    6f8c:      	ldr	x20, [sp, #0x1a8]
    6f90:      	ldr	x21, [sp, #0x1b0]
    6f94:      	ldr	x22, [sp, #0x1b8]
    6f98:      	ldr	x23, [sp, #0x1c0]
    6f9c:      	ldr	x24, [sp, #0x1c8]
    6fa0:      	ldr	x25, [sp, #0x1d0]
    6fa4:      	ldr	x26, [sp, #0x1d8]
    6fa8:      	ldr	x27, [sp, #0x1e0]
    6fac:      	ldr	x28, [sp, #0x1e8]
    6fb0:      	ldr	x29, [sp]
    6fb4:      	ldr	x30, [sp, #0x8]
    6fb8:      	add	sp, sp, #0x1f0
    6fbc:      	ret
    6fc0:      	movz	x20, #0x0, lsl #48
    6fc4:      	b	0x6a14 <_stogir.placement.late-with-uses!+0x3e4>
    6fc8:      	brk	#0
    6fcc:      	b	0x6fc8 <_stogir.placement.late-with-uses!+0x998>
    6fd0:      	lsl	x7, x7, #1
    6fd4:      	str	w2, [sp, #0x178]
    6fd8:      	str	x0, [sp, #0x180]
    6fdc:      	ldr	x0, [sp, #0x118]
    6fe0:      	str	x1, [sp, #0x188]
    6fe4:      	mov	x1, x7
    6fe8:      	str	x4, [sp, #0x138]
    6fec:      	str	x20, [sp, #0x170]
    6ff0:      	mov	x20, x3
    6ff4:      	str	x21, [sp, #0x190]
    6ff8:      	mov	w21, w5
    6ffc:      	str	x22, [sp, #0x198]
    7000:      	mov	x22, x6
    7004:      	bl	0x7004 <_stogir.placement.late-with-uses!+0x9d4>
		0000000000007004:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    7008:      	add	x0, x22, #0x1
    700c:      	add	x16, sp, #0x70
    7010:      	ldr	x1, [x16]
    7014:      	add	x1, x1, x22, lsl #2
    7018:      	str	w21, [x1]
    701c:      	add	x16, sp, #0x70
    7020:      	str	x0, [x16, #0x8]
    7024:      	b	0x6da0 <_stogir.placement.late-with-uses!+0x770>
    7028:      	ldr	x0, [x23]
    702c:      	orr	x2, x0, xzr
    7030:      	add	x2, x2, x20, lsl #2
    7034:      	add	x0, x0, x1, lsl #2
    7038:      	ldr	w1, [x2]
    703c:      	orr	w20, w1, wzr
    7040:      	ldr	w0, [x0]
    7044:      	orr	w1, w0, wzr
    7048:      	sxtw	x20, w20
    704c:      	sxtw	x1, w1
    7050:      	cmp	x20, x1
    7054:      	b.eq	0x6fc4 <_stogir.placement.late-with-uses!+0x994>
    7058:      	b	0x7028 <_stogir.placement.late-with-uses!+0x9f8>
    705c:      	nop
    7060:      	sxtw	x1, w1
    7064:      	sub	x2, x2, #0x1
    7068:      	ldr	x3, [x23]
    706c:      	add	x1, x3, x1, lsl #2
    7070:      	ldr	w1, [x1]
    7074:      	cmp	x2, x0
    7078:      	b.gt	0x7060 <_stogir.placement.late-with-uses!+0xa30>
    707c:      	b	0x7048 <_stogir.placement.late-with-uses!+0xa18>
    7080:      	sxtw	x20, w20
    7084:      	sub	x0, x0, #0x1
    7088:      	ldr	x3, [x23]
    708c:      	add	x3, x3, x20, lsl #2
    7090:      	ldr	w3, [x3]
    7094:      	orr	w20, w3, wzr
    7098:      	cmp	x0, x2
    709c:      	b.gt	0x7080 <_stogir.placement.late-with-uses!+0xa50>
    70a0:      	b	0x7074 <_stogir.placement.late-with-uses!+0xa44>
    70a4:      	nop
    70a8:      	orr	w3, w4, wzr
    70ac:      	add	x2, x2, #0x1
    70b0:      	ldr	x4, [x23]
    70b4:      	sxtw	x3, w3
    70b8:      	add	x4, x4, x3, lsl #2
    70bc:      	ldr	w4, [x4]
    70c0:      	sxtw	x5, w4
    70c4:      	cmp	x3, x5
    70c8:      	b.eq	0x7098 <_stogir.placement.late-with-uses!+0xa68>
    70cc:      	b	0x70a8 <_stogir.placement.late-with-uses!+0xa78>
    70d0:      	orr	w2, w3, wzr
    70d4:      	add	x0, x0, #0x1
    70d8:      	ldr	x3, [x23]
    70dc:      	sxtw	x2, w2
    70e0:      	add	x3, x3, x2, lsl #2
    70e4:      	ldr	w3, [x3]
    70e8:      	sxtw	x4, w3
    70ec:      	cmp	x2, x4
    70f0:      	b.ne	0x70d0 <_stogir.placement.late-with-uses!+0xaa0>
    70f4:      	mov	w3, w1
    70f8:      	movz	x2, #0x0, lsl #48
    70fc:      	b	0x70b0 <_stogir.placement.late-with-uses!+0xa80>
    7100:      	brk	#0
    7104:      	b	0x7100 <_stogir.placement.late-with-uses!+0xad0>
    7108:      	brk	#0
    710c:      	b	0x7108 <_stogir.placement.late-with-uses!+0xad8>
    7110:      	str	x19, [sp, #0x110]
    7114:      	b	0x6820 <_stogir.placement.late-with-uses!+0x1f0>
    7118:      	str	x19, [sp, #0x118]
    711c:      	b	0x68fc <_stogir.placement.late-with-uses!+0x2cc>
    7120:      	str	x19, [sp, #0x118]
    7124:      	b	0x68ac <_stogir.placement.late-with-uses!+0x27c>
    7128:      	ldr	x20, [sp, #0x130]
    712c:      	b	0x6f18 <_stogir.placement.late-with-uses!+0x8e8>
    7130:      	str	x20, [sp, #0x160]
    7134:      	str	x21, [sp, #0x168]
    7138:      	str	x26, [sp, #0x158]
    713c:      	str	x25, [sp, #0x140]
    7140:      	mov	x25, x0
    7144:      	str	x24, [sp, #0x170]
    7148:      	mov	w24, w7
    714c:      	mov	w20, w4
    7150:      	b	0x6b4c <_stogir.placement.late-with-uses!+0x51c>
    7154:      	str	x20, [sp, #0x160]
    7158:      	str	x21, [sp, #0x168]
    715c:      	str	x26, [sp, #0x158]
    7160:      	mov	x26, x3
    7164:      	str	x2, [sp, #0x148]
    7168:      	str	x1, [sp, #0x150]
    716c:      	str	x25, [sp, #0x140]
    7170:      	mov	x25, x0
    7174:      	str	x24, [sp, #0x170]
    7178:      	mov	w20, w4
    717c:      	b	0x6a14 <_stogir.placement.late-with-uses!+0x3e4>
    7180:      	ldr	x20, [sp, #0x170]
    7184:      	b	0x6c74 <_stogir.placement.late-with-uses!+0x644>
    7188:      	ldr	x26, [sp, #0x168]
    718c:      	str	x22, [sp, #0x198]
    7190:      	str	x20, [sp, #0x170]
    7194:      	ldr	x20, [sp, #0x130]
    7198:      	b	0x6944 <_stogir.placement.late-with-uses!+0x314>
    719c:      	str	x22, [sp, #0x198]
    71a0:      	str	x21, [sp, #0x190]
    71a4:      	str	x20, [sp, #0x170]
    71a8:      	mov	x20, x3
    71ac:      	str	x1, [sp, #0x188]
    71b0:      	str	w2, [sp, #0x178]
    71b4:      	str	x0, [sp, #0x180]
    71b8:      	b	0x6da0 <_stogir.placement.late-with-uses!+0x770>
    71bc:      	str	x22, [sp, #0x198]
    71c0:      	str	x21, [sp, #0x190]
    71c4:      	str	x20, [sp, #0x170]
    71c8:      	mov	x20, x3
    71cc:      	str	x1, [sp, #0x188]
    71d0:      	str	w2, [sp, #0x178]
    71d4:      	str	x0, [sp, #0x180]
    71d8:      	b	0x6da0 <_stogir.placement.late-with-uses!+0x770>
    71dc:      	str	x22, [sp, #0x198]
    71e0:      	str	x20, [sp, #0x170]
    71e4:      	b	0x6938 <_stogir.placement.late-with-uses!+0x308>
    71e8:      	ldr	x4, [sp, #0x138]
    71ec:      	b	0x6ea4 <_stogir.placement.late-with-uses!+0x874>
    71f0:      	str	x22, [sp, #0x198]
    71f4:      	str	x21, [sp, #0x190]
    71f8:      	str	x20, [sp, #0x170]
    71fc:      	mov	x20, x3
    7200:      	str	x1, [sp, #0x188]
    7204:      	str	w2, [sp, #0x178]
    7208:      	str	x0, [sp, #0x180]
    720c:      	str	x4, [sp, #0x138]
    7210:      	b	0x6da0 <_stogir.placement.late-with-uses!+0x770>
    7214:      	str	x22, [sp, #0x198]
    7218:      	str	x21, [sp, #0x190]
    721c:      	str	x20, [sp, #0x170]
    7220:      	mov	x20, x3
    7224:      	str	x1, [sp, #0x188]
    7228:      	str	w2, [sp, #0x178]
    722c:      	str	x0, [sp, #0x180]
    7230:      	str	x4, [sp, #0x138]
    7234:      	b	0x6da0 <_stogir.placement.late-with-uses!+0x770>
    7238:      	str	x22, [sp, #0x198]
    723c:      	str	x21, [sp, #0x190]
    7240:      	str	x20, [sp, #0x170]
    7244:      	mov	x20, x3
    7248:      	str	x1, [sp, #0x188]
    724c:      	str	w2, [sp, #0x178]
    7250:      	str	x0, [sp, #0x180]
    7254:      	str	x4, [sp, #0x138]
    7258:      	b	0x6da0 <_stogir.placement.late-with-uses!+0x770>
    725c:      	str	x22, [sp, #0x198]
    7260:      	str	x21, [sp, #0x190]
    7264:      	str	x20, [sp, #0x170]
    7268:      	mov	x20, x3
    726c:      	str	x1, [sp, #0x188]
    7270:      	mov	x22, x6
    7274:      	str	w2, [sp, #0x178]
    7278:      	str	x0, [sp, #0x180]
    727c:      	mov	w21, w5
    7280:      	str	x4, [sp, #0x138]
    7284:      	b	0x7008 <_stogir.placement.late-with-uses!+0x9d8>

0000000000007288 <_stogir.checked-schedule.place!>:
    7288:      	sub	sp, sp, #0x90
    728c:      	str	x29, [sp]
    7290:      	str	x30, [sp, #0x8]
    7294:      	mov	x29, sp
    7298:      	str	x19, [sp, #0x40]
    729c:      	str	x20, [sp, #0x48]
    72a0:      	str	x21, [sp, #0x50]
    72a4:      	str	x22, [sp, #0x58]
    72a8:      	str	x23, [sp, #0x60]
    72ac:      	str	x24, [sp, #0x68]
    72b0:      	str	x25, [sp, #0x70]
    72b4:      	str	x26, [sp, #0x78]
    72b8:      	str	x27, [sp, #0x80]
    72bc:      	str	x28, [sp, #0x88]
    72c0:      	orr	x19, x1, xzr
    72c4:      	orr	x20, x2, xzr
    72c8:      	add	x16, sp, #0x20
    72cc:      	orr	x1, x16, xzr
    72d0:      	add	x21, x1, #0x8
    72d4:      	mov	x22, #0x1               ; =1
    72d8:      	movz	x23, #0x0, lsl #48
    72dc:      	adrp	x24, 0x7000 <_stogir.placement.late-with-uses!+0x9d0>
		00000000000072dc:  ARM64_RELOC_PAGE21	l_stogir.438
    72e0:      	ldr	x24, [x24]
		00000000000072e0:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    72e4:      	movz	x25, #0x0, lsl #48
    72e8:      	b	0x7320 <_stogir.checked-schedule.place!+0x98>
    72ec:      	nop
    72f0:      	add	x16, sp, #0x20
    72f4:      	ldr	x24, [x16, #0x8]
    72f8:      	ldr	x25, [x21, #0x8]
    72fc:      	sxtw	x26, w26
    7300:      	add	x0, x26, #0x4
    7304:      	asr	x16, x0, #63
    7308:      	lsr	x16, x16, #62
    730c:      	add	x0, x0, x16
    7310:      	asr	x0, x0, #2
    7314:      	add	x22, x0, x22
    7318:      	mov	x8, x27
    731c:      	mov	x0, x28
    7320:      	cmp	x25, #0x0
    7324:      	b.ne	0x748c <_stogir.checked-schedule.place!+0x204>
    7328:      	ldr	x1, [x0, #0x8]
    732c:      	cmp	x22, x1
    7330:      	b.ge	0x7494 <_stogir.checked-schedule.place!+0x20c>
    7334:      	ldr	x1, [x0]
    7338:      	add	x1, x1, x22, lsl #4
    733c:      	ldr	x2, [x1]
    7340:      	uxtb	w3, w2
    7344:      	ldr	x1, [x1, #0x8]
    7348:      	add	x16, sp, #0x10
    734c:      	str	x2, [x16]
    7350:      	add	x16, sp, #0x10
    7354:      	str	x1, [x16, #0x8]
    7358:      	ldr	x1, [x0, #0x78]
    735c:      	add	x1, x1, x22, lsl #2
    7360:      	ldr	w26, [x1]
    7364:      	cmp	x3, #0x2c
    7368:      	b.ne	0x749c <_stogir.checked-schedule.place!+0x214>
    736c:      	ldr	x1, [x20]
    7370:      	add	x1, x22, x1
    7374:      	ldrb	w1, [x1]
    7378:      	cmp	x1, #0x0
    737c:      	b.eq	0x74a8 <_stogir.checked-schedule.place!+0x220>
    7380:      	orr	w1, w22, wzr
    7384:      	mov	x27, x8
    7388:      	add	x8, sp, #0x20
    738c:      	mov	x28, x0
    7390:      	bl	0x7390 <_stogir.checked-schedule.place!+0x108>
		0000000000007390:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    7394:      	add	x16, sp, #0x20
    7398:      	ldr	w0, [x16]
    739c:      	lsr	x16, x0, #0
    73a0:      	cmp	x16, #0x1
    73a4:      	b.eq	0x73c0 <_stogir.checked-schedule.place!+0x138>
    73a8:      	b.lo	0x73b0 <_stogir.checked-schedule.place!+0x128>
    73ac:      	b	0x73c4 <_stogir.checked-schedule.place!+0x13c>
    73b0:      	cmp	x16, #0x0
    73b4:      	b.eq	0x73bc <_stogir.checked-schedule.place!+0x134>
    73b8:      	b	0x73c4 <_stogir.checked-schedule.place!+0x13c>
    73bc:      	b	0x73c8 <_stogir.checked-schedule.place!+0x140>
    73c0:      	b	0x72f0 <_stogir.checked-schedule.place!+0x68>
    73c4:      	b	0x7484 <_stogir.checked-schedule.place!+0x1fc>
    73c8:      	add	x16, sp, #0x20
    73cc:      	ldr	w0, [x16, #0x8]
    73d0:      	sxtw	x0, w0
    73d4:      	cmp	x0, #0x0
    73d8:      	b.eq	0x7480 <_stogir.checked-schedule.place!+0x1f8>
    73dc:      	add	x16, sp, #0x10
    73e0:      	ldr	w0, [x16, #0x4]
    73e4:      	sxtw	x0, w0
    73e8:      	ldr	x1, [x19]
    73ec:      	add	x0, x1, x0, lsl #2
    73f0:      	ldr	w0, [x0]
    73f4:      	sxtw	x2, w0
    73f8:      	cmp	x2, #0x0
    73fc:      	b.gt	0x7470 <_stogir.checked-schedule.place!+0x1e8>
    7400:      	adrp	x24, 0x7000 <_stogir.placement.late-with-uses!+0x9d0>
		0000000000007400:  ARM64_RELOC_PAGE21	l_stogir.439
    7404:      	ldr	x24, [x24]
		0000000000007404:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    7408:      	mov	x25, #0x21              ; =33
    740c:      	b	0x7480 <_stogir.checked-schedule.place!+0x1f8>
    7410:      	cmp	x25, #0x0
    7414:      	b.ne	0x7428 <_stogir.checked-schedule.place!+0x1a0>
    7418:      	and	x24, x23, #0xffffffff
    741c:      	movz	x0, #0x0, lsl #48
    7420:      	movz	x25, #0x0, lsl #48
    7424:      	b	0x742c <_stogir.checked-schedule.place!+0x1a4>
    7428:      	mov	x0, #0x1                ; =1
    742c:      	str	x0, [x27]
    7430:      	str	x24, [x27, #0x8]
    7434:      	str	x25, [x27, #0x10]
    7438:      	ldr	x19, [sp, #0x40]
    743c:      	ldr	x20, [sp, #0x48]
    7440:      	ldr	x21, [sp, #0x50]
    7444:      	ldr	x22, [sp, #0x58]
    7448:      	ldr	x23, [sp, #0x60]
    744c:      	ldr	x24, [sp, #0x68]
    7450:      	ldr	x25, [sp, #0x70]
    7454:      	ldr	x26, [sp, #0x78]
    7458:      	ldr	x27, [sp, #0x80]
    745c:      	ldr	x28, [sp, #0x88]
    7460:      	ldr	x29, [sp]
    7464:      	ldr	x30, [sp, #0x8]
    7468:      	add	sp, sp, #0x90
    746c:      	ret
    7470:      	add	x2, x23, #0x1
    7474:      	add	x1, x1, x22, lsl #2
    7478:      	sxtw	x23, w2
    747c:      	str	w0, [x1]
    7480:      	b	0x72fc <_stogir.checked-schedule.place!+0x74>
    7484:      	brk	#0
    7488:      	b	0x7484 <_stogir.checked-schedule.place!+0x1fc>
    748c:      	mov	x27, x8
    7490:      	b	0x7410 <_stogir.checked-schedule.place!+0x188>
    7494:      	mov	x27, x8
    7498:      	b	0x7410 <_stogir.checked-schedule.place!+0x188>
    749c:      	mov	x27, x8
    74a0:      	mov	x28, x0
    74a4:      	b	0x72fc <_stogir.checked-schedule.place!+0x74>
    74a8:      	mov	x27, x8
    74ac:      	mov	x28, x0
    74b0:      	b	0x72fc <_stogir.checked-schedule.place!+0x74>
    74b4:      	udf	#0x0

00000000000074b8 <_stogir.loops.reorder!>:
    74b8:      	sub	sp, sp, #0x2e0
    74bc:      	str	x29, [sp]
    74c0:      	str	x30, [sp, #0x8]
    74c4:      	mov	x29, sp
    74c8:      	str	x19, [sp, #0x290]
    74cc:      	str	x20, [sp, #0x298]
    74d0:      	str	x21, [sp, #0x2a0]
    74d4:      	str	x22, [sp, #0x2a8]
    74d8:      	str	x23, [sp, #0x2b0]
    74dc:      	str	x24, [sp, #0x2b8]
    74e0:      	str	x25, [sp, #0x2c0]
    74e4:      	str	x26, [sp, #0x2c8]
    74e8:      	str	x27, [sp, #0x2d0]
    74ec:      	str	x28, [sp, #0x2d8]
    74f0:      	add	x6, x0, #0x50
    74f4:      	ldr	x7, [x0, #0x50]
    74f8:      	orr	x19, x7, xzr
    74fc:      	ldr	x6, [x6, #0x8]
    7500:      	orr	x20, x6, xzr
    7504:      	movz	x21, #0x0, lsl #48
    7508:      	movz	x22, #0x0, lsl #48
    750c:      	b	0x794c <_stogir.loops.reorder!+0x494>
    7510:      	movz	w1, #0x0, lsl #16
    7514:      	movz	x2, #0x0, lsl #48
    7518:      	ubfx	x1, x1, #0, #32
    751c:      	lsr	x16, x1, #0
    7520:      	cmp	x16, #0x1
    7524:      	b.eq	0x7548 <_stogir.loops.reorder!+0x90>
    7528:      	b.lo	0x7530 <_stogir.loops.reorder!+0x78>
    752c:      	b	0x754c <_stogir.loops.reorder!+0x94>
    7530:      	cmp	x16, #0x0
    7534:      	b.eq	0x753c <_stogir.loops.reorder!+0x84>
    7538:      	b	0x754c <_stogir.loops.reorder!+0x94>
    753c:      	str	x19, [sp, #0x258]
    7540:      	mov	x19, x0
    7544:      	b	0x75ec <_stogir.loops.reorder!+0x134>
    7548:      	b	0x7550 <_stogir.loops.reorder!+0x98>
    754c:      	b	0x80e4 <_stogir.loops.reorder!+0xc2c>
    7550:      	orr	w1, w2, wzr
    7554:      	asr	x3, x2, #32
    7558:      	add	x16, sp, #0x50
    755c:      	ldr	x4, [x16]
    7560:      	sxtw	x5, w1
    7564:      	orr	x6, x4, xzr
    7568:      	add	x3, x4, x3, lsl #2
    756c:      	add	x4, x6, x5, lsl #2
    7570:      	ldr	w4, [x4]
    7574:      	sxtw	x4, w4
    7578:      	ldr	w3, [x3]
    757c:      	cmp	x4, #0x0
    7580:      	b.lt	0x80ec <_stogir.loops.reorder!+0xc34>
    7584:      	sxtw	x3, w3
    7588:      	cmp	x3, #0x0
    758c:      	b.lt	0x80f8 <_stogir.loops.reorder!+0xc40>
    7590:      	cmp	x4, x3
    7594:      	b.lt	0x8104 <_stogir.loops.reorder!+0xc4c>
    7598:      	lsr	x2, x2, #32
    759c:      	str	x19, [sp, #0x258]
    75a0:      	mov	x19, x0
    75a4:      	mov	x0, x26
    75a8:      	fmov	s31, w1
    75ac:      	mov	w1, w2
    75b0:      	fmov	w2, s31
    75b4:      	bl	0x75b4 <_stogir.loops.reorder!+0xfc>
		00000000000075b4:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    75b8:      	cmp	x0, #0x0
    75bc:      	b.ne	0x75c4 <_stogir.loops.reorder!+0x10c>
    75c0:      	movz	x19, #0x0, lsl #48
    75c4:      	mov	x0, x19
    75c8:      	ldr	x19, [sp, #0x258]
    75cc:      	cmp	x22, x21
    75d0:      	b.ge	0x7510 <_stogir.loops.reorder!+0x58>
    75d4:      	add	x1, x22, #0x1
    75d8:      	add	x2, x20, x22, lsl #4
    75dc:      	ldr	x2, [x2]
    75e0:      	mov	x22, x1
    75e4:      	mov	w1, #0x1                ; =1
    75e8:      	b	0x7518 <_stogir.loops.reorder!+0x60>
    75ec:      	cmp	x19, #0x0
    75f0:      	b.eq	0x7770 <_stogir.loops.reorder!+0x2b8>
    75f4:      	add	x8, sp, #0x100
    75f8:      	ldr	x0, [sp, #0x250]
    75fc:      	bl	0x75fc <_stogir.loops.reorder!+0x144>
		00000000000075fc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7600:      	add	x16, sp, #0x100
    7604:      	ldr	x0, [x16]
    7608:      	add	x16, sp, #0xd0
    760c:      	str	x0, [x16]
    7610:      	add	x16, sp, #0x100
    7614:      	ldr	x0, [x16, #0x8]
    7618:      	add	x16, sp, #0xd0
    761c:      	str	x0, [x16, #0x8]
    7620:      	add	x16, sp, #0x100
    7624:      	ldr	x0, [x16, #0x10]
    7628:      	add	x16, sp, #0xd0
    762c:      	str	x0, [x16, #0x10]
    7630:      	add	x16, sp, #0x100
    7634:      	ldr	x0, [x16, #0x18]
    7638:      	add	x16, sp, #0xd0
    763c:      	str	x0, [x16, #0x18]
    7640:      	add	x16, sp, #0x100
    7644:      	ldr	x0, [x16, #0x20]
    7648:      	add	x16, sp, #0xd0
    764c:      	str	x0, [x16, #0x20]
    7650:      	add	x8, sp, #0x160
    7654:      	ldr	x0, [sp, #0x250]
    7658:      	bl	0x7658 <_stogir.loops.reorder!+0x1a0>
		0000000000007658:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame
    765c:      	add	x16, sp, #0x160
    7660:      	ldr	x0, [x16]
    7664:      	add	x16, sp, #0x130
    7668:      	str	x0, [x16]
    766c:      	add	x16, sp, #0x160
    7670:      	ldr	x0, [x16, #0x8]
    7674:      	add	x16, sp, #0x130
    7678:      	str	x0, [x16, #0x8]
    767c:      	add	x16, sp, #0x160
    7680:      	ldr	x0, [x16, #0x10]
    7684:      	add	x16, sp, #0x130
    7688:      	str	x0, [x16, #0x10]
    768c:      	add	x16, sp, #0x160
    7690:      	ldr	x0, [x16, #0x18]
    7694:      	add	x16, sp, #0x130
    7698:      	str	x0, [x16, #0x18]
    769c:      	add	x16, sp, #0x160
    76a0:      	ldr	x0, [x16, #0x20]
    76a4:      	add	x16, sp, #0x130
    76a8:      	str	x0, [x16, #0x20]
    76ac:      	add	x8, sp, #0x1c0
    76b0:      	ldr	x0, [sp, #0x250]
    76b4:      	bl	0x76b4 <_stogir.loops.reorder!+0x1fc>
		00000000000076b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    76b8:      	add	x16, sp, #0x1c0
    76bc:      	ldr	x0, [x16]
    76c0:      	add	x16, sp, #0x190
    76c4:      	str	x0, [x16]
    76c8:      	add	x16, sp, #0x1c0
    76cc:      	ldr	x0, [x16, #0x8]
    76d0:      	add	x16, sp, #0x190
    76d4:      	str	x0, [x16, #0x8]
    76d8:      	add	x16, sp, #0x1c0
    76dc:      	ldr	x0, [x16, #0x10]
    76e0:      	add	x16, sp, #0x190
    76e4:      	str	x0, [x16, #0x10]
    76e8:      	add	x16, sp, #0x1c0
    76ec:      	ldr	x0, [x16, #0x18]
    76f0:      	add	x16, sp, #0x190
    76f4:      	str	x0, [x16, #0x18]
    76f8:      	add	x16, sp, #0x1c0
    76fc:      	ldr	x0, [x16, #0x20]
    7700:      	add	x16, sp, #0x190
    7704:      	str	x0, [x16, #0x20]
    7708:      	ldr	x0, [x28]
    770c:      	ldr	w19, [x0]
    7710:      	movn	x0, #0x0, lsl #48
    7714:      	b	0x772c <_stogir.loops.reorder!+0x274>
    7718:      	add	x16, sp, #0x50
    771c:      	ldr	x1, [x16]
    7720:      	add	x1, x1, x0, lsl #2
    7724:      	movz	w17, #0x0, lsl #16
    7728:      	str	w17, [x1]
    772c:      	add	x16, sp, #0x50
    7730:      	ldr	x1, [x16, #0x8]
    7734:      	add	x0, x0, #0x1
    7738:      	cmp	x0, x1
    773c:      	b.lt	0x7718 <_stogir.loops.reorder!+0x260>
    7740:      	add	x16, sp, #0xd0
    7744:      	orr	x20, x16, xzr
    7748:      	add	x0, x25, #0x28
    774c:      	add	x8, sp, #0x1f0
    7750:      	bl	0x7750 <_stogir.loops.reorder!+0x298>
		0000000000007750:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64
    7754:      	add	x16, sp, #0x1f0
    7758:      	ldr	x21, [x16]
    775c:      	add	x16, sp, #0x1f0
    7760:      	ldr	x22, [x16, #0x8]
    7764:      	add	x16, sp, #0x1f0
    7768:      	ldr	x26, [x16, #0x10]
    776c:      	b	0x79cc <_stogir.loops.reorder!+0x514>
    7770:      	ldr	x0, [sp, #0x258]
    7774:      	bl	0x7774 <_stogir.loops.reorder!+0x2bc>
		0000000000007774:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7778:      	movz	x1, #0x0, lsl #48
    777c:      	movz	x0, #0x0, lsl #48
    7780:      	movz	x2, #0x0, lsl #48
    7784:      	b	0x7efc <_stogir.loops.reorder!+0xa44>
    7788:      	movz	w4, #0x0, lsl #16
    778c:      	movz	w5, #0x0, lsl #16
    7790:      	ubfx	x4, x4, #0, #32
    7794:      	lsr	x16, x4, #0
    7798:      	cmp	x16, #0x1
    779c:      	b.eq	0x77b8 <_stogir.loops.reorder!+0x300>
    77a0:      	b.lo	0x77a8 <_stogir.loops.reorder!+0x2f0>
    77a4:      	b	0x77bc <_stogir.loops.reorder!+0x304>
    77a8:      	cmp	x16, #0x0
    77ac:      	b.eq	0x77b4 <_stogir.loops.reorder!+0x2fc>
    77b0:      	b	0x77bc <_stogir.loops.reorder!+0x304>
    77b4:      	b	0x7808 <_stogir.loops.reorder!+0x350>
    77b8:      	b	0x77c0 <_stogir.loops.reorder!+0x308>
    77bc:      	b	0x80dc <_stogir.loops.reorder!+0xc24>
    77c0:      	sxtw	x5, w5
    77c4:      	ldr	x4, [x26]
    77c8:      	add	x4, x4, x5, lsl #2
    77cc:      	ldr	w4, [x4]
    77d0:      	sxtw	x4, w4
    77d4:      	cmp	x4, #0x0
    77d8:      	b.le	0x77e0 <_stogir.loops.reorder!+0x328>
    77dc:      	add	x3, x3, #0x1
    77e0:      	cmp	x2, x1
    77e4:      	b.ge	0x7788 <_stogir.loops.reorder!+0x2d0>
    77e8:      	add	x4, x2, #0x1
    77ec:      	add	x2, x0, x2, lsl #2
    77f0:      	ldr	w2, [x2]
    77f4:      	movn	w17, #0x0, lsl #16
    77f8:      	and	w5, w2, w17
    77fc:      	mov	x2, x4
    7800:      	mov	w4, #0x1                ; =1
    7804:      	b	0x7790 <_stogir.loops.reorder!+0x2d8>
    7808:      	ldr	x0, [x28, #0x8]
    780c:      	cmp	x3, x0
    7810:      	b.ne	0x7848 <_stogir.loops.reorder!+0x390>
    7814:      	orr	x19, x28, xzr
    7818:      	add	x8, sp, #0x30
    781c:      	mov	x0, x24
    7820:      	bl	0x7820 <_stogir.loops.reorder!+0x368>
		0000000000007820:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    7824:      	add	x16, sp, #0x30
    7828:      	ldr	x0, [x16]
    782c:      	add	x16, sp, #0x30
    7830:      	ldr	x1, [x16, #0x8]
    7834:      	add	x16, sp, #0x30
    7838:      	ldr	x2, [x16, #0x10]
    783c:      	movz	x3, #0x0, lsl #48
    7840:      	movz	x4, #0x0, lsl #48
    7844:      	b	0x7ec4 <_stogir.loops.reorder!+0xa0c>
    7848:      	mov	x1, #0x1                ; =1
    784c:      	adrp	x0, 0x7000 <_stogir.placement.late-with-uses!+0x9d0>
		000000000000784c:  ARM64_RELOC_PAGE21	l_stogir.440
    7850:      	ldr	x0, [x0]
		0000000000007850:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    7854:      	mov	x2, #0x32               ; =50
    7858:      	b	0x7f0c <_stogir.loops.reorder!+0xa54>
    785c:      	nop
    7860:      	movz	w6, #0x0, lsl #16
    7864:      	movz	x7, #0x0, lsl #48
    7868:      	ubfx	x6, x6, #0, #32
    786c:      	lsr	x16, x6, #0
    7870:      	cmp	x16, #0x1
    7874:      	b.eq	0x78ac <_stogir.loops.reorder!+0x3f4>
    7878:      	b.lo	0x7880 <_stogir.loops.reorder!+0x3c8>
    787c:      	b	0x78b0 <_stogir.loops.reorder!+0x3f8>
    7880:      	cmp	x16, #0x0
    7884:      	b.eq	0x788c <_stogir.loops.reorder!+0x3d4>
    7888:      	b	0x78b0 <_stogir.loops.reorder!+0x3f8>
    788c:      	mov	x23, x8
    7890:      	mov	x24, x0
    7894:      	mov	x25, x1
    7898:      	mov	x26, x2
    789c:      	mov	x27, x3
    78a0:      	mov	x28, x4
    78a4:      	str	x5, [sp, #0x250]
    78a8:      	b	0x796c <_stogir.loops.reorder!+0x4b4>
    78ac:      	b	0x78b4 <_stogir.loops.reorder!+0x3fc>
    78b0:      	b	0x80d4 <_stogir.loops.reorder!+0xc1c>
    78b4:      	orr	w6, w7, wzr
    78b8:      	ldr	x9, [x2]
    78bc:      	sxtw	x10, w6
    78c0:      	add	x11, x9, x10, lsl #2
    78c4:      	ldr	w11, [x11]
    78c8:      	sxtw	x11, w11
    78cc:      	cmp	x11, #0x0
    78d0:      	b.le	0x8110 <_stogir.loops.reorder!+0xc58>
    78d4:      	lsr	x7, x7, #32
    78d8:      	sxtw	x11, w7
    78dc:      	add	x9, x9, x11, lsl #2
    78e0:      	ldr	w9, [x9]
    78e4:      	sxtw	x9, w9
    78e8:      	cmp	x9, #0x0
    78ec:      	b.le	0x8130 <_stogir.loops.reorder!+0xc78>
    78f0:      	cmp	x10, x11
    78f4:      	b.lt	0x8150 <_stogir.loops.reorder!+0xc98>
    78f8:      	mov	x23, x8
    78fc:      	mov	x24, x0
    7900:      	mov	x0, x2
    7904:      	mov	x25, x1
    7908:      	mov	w1, w7
    790c:      	mov	x26, x2
    7910:      	mov	w2, w6
    7914:      	mov	x27, x3
    7918:      	mov	x28, x4
    791c:      	str	x5, [sp, #0x250]
    7920:      	bl	0x7920 <_stogir.loops.reorder!+0x468>
		0000000000007920:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    7924:      	cmp	x0, #0x0
    7928:      	b.ne	0x7930 <_stogir.loops.reorder!+0x478>
    792c:      	mov	x21, #0x1               ; =1
    7930:      	mov	x8, x23
    7934:      	mov	x0, x24
    7938:      	mov	x1, x25
    793c:      	mov	x2, x26
    7940:      	mov	x3, x27
    7944:      	mov	x4, x28
    7948:      	ldr	x5, [sp, #0x250]
    794c:      	cmp	x22, x20
    7950:      	b.ge	0x7860 <_stogir.loops.reorder!+0x3a8>
    7954:      	add	x6, x22, #0x1
    7958:      	add	x7, x19, x22, lsl #4
    795c:      	ldr	x7, [x7]
    7960:      	mov	x22, x6
    7964:      	mov	w6, #0x1                ; =1
    7968:      	b	0x7868 <_stogir.loops.reorder!+0x3b0>
    796c:      	ldr	x0, [x28, #0x8]
    7970:      	cmp	x0, #0x0
    7974:      	b.ne	0x7f50 <_stogir.loops.reorder!+0xa98>
    7978:      	movz	x1, #0x0, lsl #48
    797c:      	movz	x0, #0x0, lsl #48
    7980:      	movz	x2, #0x0, lsl #48
    7984:      	b	0x7f0c <_stogir.loops.reorder!+0xa54>
    7988:      	lsl	x2, x2, #1
    798c:      	str	x20, [sp, #0x260]
    7990:      	str	x21, [sp, #0x268]
    7994:      	mov	x21, x0
    7998:      	mov	x0, x20
    799c:      	mov	x20, x1
    79a0:      	mov	x1, x2
    79a4:      	bl	0x79a4 <_stogir.loops.reorder!+0x4ec>
		00000000000079a4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    79a8:      	add	x0, x21, #0x1
    79ac:      	add	x16, sp, #0xd0
    79b0:      	ldr	x1, [x16]
    79b4:      	add	x1, x1, x21, lsl #3
    79b8:      	str	x20, [x1]
    79bc:      	add	x16, sp, #0xd0
    79c0:      	str	x0, [x16, #0x8]
    79c4:      	ldr	x20, [sp, #0x260]
    79c8:      	ldr	x21, [sp, #0x268]
    79cc:      	cmp	x26, x22
    79d0:      	b.ge	0x79ec <_stogir.loops.reorder!+0x534>
    79d4:      	add	x0, x26, #0x1
    79d8:      	add	x1, x21, x26, lsl #3
    79dc:      	ldr	x1, [x1]
    79e0:      	mov	x26, x0
    79e4:      	mov	w0, #0x1                ; =1
    79e8:      	b	0x79f4 <_stogir.loops.reorder!+0x53c>
    79ec:      	movz	w0, #0x0, lsl #16
    79f0:      	movz	x1, #0x0, lsl #48
    79f4:      	ubfx	x0, x0, #0, #32
    79f8:      	lsr	x16, x0, #0
    79fc:      	cmp	x16, #0x1
    7a00:      	b.eq	0x7a20 <_stogir.loops.reorder!+0x568>
    7a04:      	b.lo	0x7a0c <_stogir.loops.reorder!+0x554>
    7a08:      	b	0x7a24 <_stogir.loops.reorder!+0x56c>
    7a0c:      	cmp	x16, #0x0
    7a10:      	b.eq	0x7a18 <_stogir.loops.reorder!+0x560>
    7a14:      	b	0x7a24 <_stogir.loops.reorder!+0x56c>
    7a18:      	str	x20, [sp, #0x260]
    7a1c:      	b	0x7a50 <_stogir.loops.reorder!+0x598>
    7a20:      	b	0x7a28 <_stogir.loops.reorder!+0x570>
    7a24:      	b	0x80cc <_stogir.loops.reorder!+0xc14>
    7a28:      	add	x16, sp, #0xd0
    7a2c:      	ldr	x0, [x16, #0x8]
    7a30:      	add	x16, sp, #0xd0
    7a34:      	ldr	x2, [x16, #0x10]
    7a38:      	cmp	x0, x2
    7a3c:      	b.lt	0x8170 <_stogir.loops.reorder!+0xcb8>
    7a40:      	cmp	x2, #0x0
    7a44:      	b.ne	0x7988 <_stogir.loops.reorder!+0x4d0>
    7a48:      	mov	x2, #0x2                ; =2
    7a4c:      	b	0x798c <_stogir.loops.reorder!+0x4d4>
    7a50:      	add	x16, sp, #0x130
    7a54:      	orr	x20, x16, xzr
    7a58:      	add	x16, sp, #0x190
    7a5c:      	orr	x21, x16, xzr
    7a60:      	add	x16, sp, #0x210
    7a64:      	orr	x0, x16, xzr
    7a68:      	add	x16, sp, #0x230
    7a6c:      	orr	x22, x16, xzr
    7a70:      	sxtw	x26, w19
    7a74:      	orr	x1, x25, xzr
    7a78:      	orr	x2, x25, xzr
    7a7c:      	ldr	x1, [x1]
    7a80:      	add	x1, x1, x26, lsl #4
    7a84:      	ldr	x3, [x1]
    7a88:      	ldr	x1, [x1, #0x8]
    7a8c:      	add	x16, sp, #0x210
    7a90:      	str	x3, [x16]
    7a94:      	add	x16, sp, #0x210
    7a98:      	str	x1, [x16, #0x8]
    7a9c:      	mov	x1, x0
    7aa0:      	ldr	x0, [sp, #0x260]
    7aa4:      	mov	x3, x27
    7aa8:      	str	x20, [sp, #0x270]
    7aac:      	mov	x20, x2
    7ab0:      	mov	x2, x24
    7ab4:      	bl	0x7ab4 <_stogir.loops.reorder!+0x5fc>
		0000000000007ab4:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    7ab8:      	add	x16, sp, #0x220
    7abc:      	movz	x17, #0x0, lsl #48
    7ac0:      	str	x17, [x16]
    7ac4:      	add	x16, sp, #0x220
    7ac8:      	movz	x17, #0x0, lsl #48
    7acc:      	str	x17, [x16, #0x8]
    7ad0:      	add	x16, sp, #0x220
    7ad4:      	str	w19, [x16]
    7ad8:      	add	x16, sp, #0x210
    7adc:      	ldr	x0, [x16, #0x8]
    7ae0:      	add	x16, sp, #0x220
    7ae4:      	str	x0, [x16, #0x8]
    7ae8:      	add	x16, sp, #0x220
    7aec:      	ldr	x1, [x16]
    7af0:      	mov	x2, x0
    7af4:      	ldr	x0, [sp, #0x270]
    7af8:      	bl	0x7af8 <_stogir.loops.reorder!+0x640>
		0000000000007af8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame
    7afc:      	add	x16, sp, #0x50
    7b00:      	ldr	x0, [x16]
    7b04:      	add	x0, x0, x26, lsl #2
    7b08:      	mov	w17, #0x1               ; =1
    7b0c:      	str	w17, [x0]
    7b10:      	b	0x7bc4 <_stogir.loops.reorder!+0x70c>
    7b14:      	lsl	x0, x0, #1
    7b18:      	mov	x1, x0
    7b1c:      	ldr	x0, [sp, #0x270]
    7b20:      	bl	0x7b20 <_stogir.loops.reorder!+0x668>
		0000000000007b20:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    7b24:      	add	x0, x21, #0x1
    7b28:      	add	x16, sp, #0x130
    7b2c:      	ldr	x1, [x16]
    7b30:      	add	x1, x1, x21, lsl #4
    7b34:      	str	x20, [x1]
    7b38:      	str	x19, [x1, #0x8]
    7b3c:      	add	x16, sp, #0x130
    7b40:      	str	x0, [x16, #0x8]
    7b44:      	add	x16, sp, #0x50
    7b48:      	ldr	x0, [x16]
    7b4c:      	add	x0, x0, x22, lsl #2
    7b50:      	mov	w17, #0x1               ; =1
    7b54:      	str	w17, [x0]
    7b58:      	b	0x7bb8 <_stogir.loops.reorder!+0x700>
    7b5c:      	nop
    7b60:      	lsl	x0, x0, #1
    7b64:      	mov	w26, w1
    7b68:      	mov	x1, x0
    7b6c:      	mov	x0, x21
    7b70:      	bl	0x7b70 <_stogir.loops.reorder!+0x6b8>
		0000000000007b70:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    7b74:      	add	x0, x19, #0x1
    7b78:      	add	x16, sp, #0x190
    7b7c:      	ldr	x1, [x16]
    7b80:      	add	x1, x1, x19, lsl #2
    7b84:      	str	w26, [x1]
    7b88:      	add	x16, sp, #0x190
    7b8c:      	str	x0, [x16, #0x8]
    7b90:      	add	x16, sp, #0x130
    7b94:      	ldr	x0, [x16, #0x8]
    7b98:      	cmp	x0, #0x0
    7b9c:      	b.eq	0x7bac <_stogir.loops.reorder!+0x6f4>
    7ba0:      	sub	x0, x0, #0x1
    7ba4:      	add	x16, sp, #0x130
    7ba8:      	str	x0, [x16, #0x8]
    7bac:      	str	x21, [sp, #0x280]
    7bb0:      	str	x22, [sp, #0x288]
    7bb4:      	str	x20, [sp, #0x278]
    7bb8:      	ldr	x21, [sp, #0x280]
    7bbc:      	ldr	x22, [sp, #0x288]
    7bc0:      	ldr	x20, [sp, #0x278]
    7bc4:      	add	x16, sp, #0x130
    7bc8:      	ldr	x0, [x16, #0x8]
    7bcc:      	cmp	x0, #0x0
    7bd0:      	b.le	0x8184 <_stogir.loops.reorder!+0xccc>
    7bd4:      	add	x16, sp, #0x130
    7bd8:      	ldr	x1, [x16]
    7bdc:      	sub	x19, x0, #0x1
    7be0:      	add	x0, x1, x19, lsl #4
    7be4:      	ldr	x26, [x0]
    7be8:      	orr	w1, w26, wzr
    7bec:      	ldr	x0, [x0, #0x8]
    7bf0:      	sxtw	x2, w1
    7bf4:      	ldr	x3, [x20]
    7bf8:      	add	x2, x3, x2, lsl #4
    7bfc:      	ldr	x2, [x2]
    7c00:      	cmp	x0, #0x0
    7c04:      	b.ne	0x7c34 <_stogir.loops.reorder!+0x77c>
    7c08:      	add	x16, sp, #0x190
    7c0c:      	ldr	x0, [x16, #0x8]
    7c10:      	orr	x19, x0, xzr
    7c14:      	add	x16, sp, #0x190
    7c18:      	ldr	x0, [x16, #0x10]
    7c1c:      	cmp	x19, x0
    7c20:      	b.lt	0x818c <_stogir.loops.reorder!+0xcd4>
    7c24:      	cmp	x0, #0x0
    7c28:      	b.ne	0x7b60 <_stogir.loops.reorder!+0x6a8>
    7c2c:      	mov	x0, #0x2                ; =2
    7c30:      	b	0x7b64 <_stogir.loops.reorder!+0x6ac>
    7c34:      	sub	x0, x0, #0x1
    7c38:      	add	x16, sp, #0xd0
    7c3c:      	ldr	x1, [x16]
    7c40:      	add	x3, x0, x2
    7c44:      	orr	x4, x1, xzr
    7c48:      	add	x5, x4, x2, lsl #3
    7c4c:      	add	x1, x1, x2, lsl #3
    7c50:      	add	x3, x4, x3, lsl #3
    7c54:      	ldr	x4, [x5]
    7c58:      	ldr	x5, [x24, #0x50]
    7c5c:      	add	x4, x5, x4, lsl #4
    7c60:      	ldr	x4, [x4]
    7c64:      	ldr	x3, [x3]
    7c68:      	lsr	x4, x4, #32
    7c6c:      	str	x3, [x1]
    7c70:      	sxtw	x1, w4
    7c74:      	mov	x5, x27
    7c78:      	str	x20, [sp, #0x278]
    7c7c:      	mov	x20, x0
    7c80:      	str	x21, [sp, #0x280]
    7c84:      	mov	w21, w4
    7c88:      	mov	x4, x24
    7c8c:      	str	x22, [sp, #0x288]
    7c90:      	mov	x22, x1
    7c94:      	mov	x1, x2
    7c98:      	mov	x2, x0
    7c9c:      	ldr	x0, [sp, #0x260]
    7ca0:      	movz	x3, #0x0, lsl #48
    7ca4:      	bl	0x7ca4 <_stogir.loops.reorder!+0x7ec>
		0000000000007ca4:  ARM64_RELOC_BRANCH26	_stogir.loops.sift!
    7ca8:      	add	x16, sp, #0x130
    7cac:      	ldr	x0, [x16]
    7cb0:      	add	x0, x0, x19, lsl #4
    7cb4:      	str	x26, [x0]
    7cb8:      	str	x20, [x0, #0x8]
    7cbc:      	add	x16, sp, #0x50
    7cc0:      	ldr	x0, [x16]
    7cc4:      	add	x0, x0, x22, lsl #2
    7cc8:      	ldr	w0, [x0]
    7ccc:      	sxtw	x0, w0
    7cd0:      	cmp	x0, #0x0
    7cd4:      	b.ne	0x7bb8 <_stogir.loops.reorder!+0x700>
    7cd8:      	ldr	x0, [x25]
    7cdc:      	add	x0, x0, x22, lsl #4
    7ce0:      	ldr	x1, [x0]
    7ce4:      	ldr	x0, [x0, #0x8]
    7ce8:      	add	x16, sp, #0x230
    7cec:      	str	x1, [x16]
    7cf0:      	add	x16, sp, #0x230
    7cf4:      	str	x0, [x16, #0x8]
    7cf8:      	ldr	x0, [sp, #0x260]
    7cfc:      	ldr	x1, [sp, #0x288]
    7d00:      	mov	x2, x24
    7d04:      	mov	x3, x27
    7d08:      	bl	0x7d08 <_stogir.loops.reorder!+0x850>
		0000000000007d08:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    7d0c:      	add	x16, sp, #0x240
    7d10:      	movz	x17, #0x0, lsl #48
    7d14:      	str	x17, [x16]
    7d18:      	add	x16, sp, #0x240
    7d1c:      	movz	x17, #0x0, lsl #48
    7d20:      	str	x17, [x16, #0x8]
    7d24:      	add	x16, sp, #0x240
    7d28:      	str	w21, [x16]
    7d2c:      	add	x16, sp, #0x230
    7d30:      	ldr	x0, [x16, #0x8]
    7d34:      	orr	x19, x0, xzr
    7d38:      	add	x16, sp, #0x240
    7d3c:      	str	x19, [x16, #0x8]
    7d40:      	add	x16, sp, #0x240
    7d44:      	ldr	x20, [x16]
    7d48:      	add	x16, sp, #0x130
    7d4c:      	ldr	x0, [x16, #0x8]
    7d50:      	orr	x21, x0, xzr
    7d54:      	add	x16, sp, #0x130
    7d58:      	ldr	x0, [x16, #0x10]
    7d5c:      	cmp	x21, x0
    7d60:      	b.lt	0x7b24 <_stogir.loops.reorder!+0x66c>
    7d64:      	cmp	x0, #0x0
    7d68:      	b.ne	0x7b14 <_stogir.loops.reorder!+0x65c>
    7d6c:      	mov	x0, #0x2                ; =2
    7d70:      	b	0x7b18 <_stogir.loops.reorder!+0x660>
    7d74:      	add	x16, sp, #0x190
    7d78:      	ldr	x0, [x16, #0x8]
    7d7c:      	ldr	x1, [x28, #0x8]
    7d80:      	cmp	x0, x1
    7d84:      	cset	w19, eq
    7d88:      	uxtb	w16, w19
    7d8c:      	cmp	w16, wzr
    7d90:      	b.eq	0x7e00 <_stogir.loops.reorder!+0x948>
    7d94:      	movn	x0, #0x0, lsl #48
    7d98:      	movz	x20, #0x0, lsl #48
    7d9c:      	b	0x7db0 <_stogir.loops.reorder!+0x8f8>
    7da0:      	mov	x20, #0x1               ; =1
    7da4:      	ldr	x2, [x28]
    7da8:      	add	x2, x2, x0, lsl #2
    7dac:      	str	w1, [x2]
    7db0:      	ldr	x1, [x28, #0x8]
    7db4:      	add	x0, x0, #0x1
    7db8:      	cmp	x0, x1
    7dbc:      	b.ge	0x7e04 <_stogir.loops.reorder!+0x94c>
    7dc0:      	add	x16, sp, #0x190
    7dc4:      	ldr	x1, [x16, #0x8]
    7dc8:      	add	x16, sp, #0x190
    7dcc:      	ldr	x2, [x16]
    7dd0:      	sub	x1, x1, #0x1
    7dd4:      	sub	x1, x1, x0
    7dd8:      	add	x1, x2, x1, lsl #2
    7ddc:      	ldr	w1, [x1]
    7de0:      	ldr	x2, [x28]
    7de4:      	sxtw	x3, w1
    7de8:      	add	x2, x2, x0, lsl #2
    7dec:      	ldr	w2, [x2]
    7df0:      	sxtw	x2, w2
    7df4:      	cmp	x2, x3
    7df8:      	b.eq	0x7da4 <_stogir.loops.reorder!+0x8ec>
    7dfc:      	b	0x7da0 <_stogir.loops.reorder!+0x8e8>
    7e00:      	movz	x20, #0x0, lsl #48
    7e04:      	ldr	x0, [sp, #0x258]
    7e08:      	bl	0x7e08 <_stogir.loops.reorder!+0x950>
		0000000000007e08:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7e0c:      	ldr	x0, [sp, #0x260]
    7e10:      	bl	0x7e10 <_stogir.loops.reorder!+0x958>
		0000000000007e10:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    7e14:      	ldr	x0, [sp, #0x270]
    7e18:      	bl	0x7e18 <_stogir.loops.reorder!+0x960>
		0000000000007e18:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame
    7e1c:      	ldr	x0, [sp, #0x280]
    7e20:      	bl	0x7e20 <_stogir.loops.reorder!+0x968>
		0000000000007e20:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7e24:      	uxtb	w16, w19
    7e28:      	cmp	w16, wzr
    7e2c:      	b.eq	0x7eec <_stogir.loops.reorder!+0xa34>
    7e30:      	and	x0, x20, #0xff
    7e34:      	movz	x1, #0x0, lsl #48
    7e38:      	movz	x2, #0x0, lsl #48
    7e3c:      	b	0x7efc <_stogir.loops.reorder!+0xa44>
    7e40:      	movz	w5, #0x0, lsl #16
    7e44:      	movz	w6, #0x0, lsl #16
    7e48:      	ubfx	x5, x5, #0, #32
    7e4c:      	lsr	x16, x5, #0
    7e50:      	cmp	x16, #0x1
    7e54:      	b.eq	0x7e70 <_stogir.loops.reorder!+0x9b8>
    7e58:      	b.lo	0x7e60 <_stogir.loops.reorder!+0x9a8>
    7e5c:      	b	0x7e74 <_stogir.loops.reorder!+0x9bc>
    7e60:      	cmp	x16, #0x0
    7e64:      	b.eq	0x7e6c <_stogir.loops.reorder!+0x9b4>
    7e68:      	b	0x7e74 <_stogir.loops.reorder!+0x9bc>
    7e6c:      	b	0x7f00 <_stogir.loops.reorder!+0xa48>
    7e70:      	b	0x7e78 <_stogir.loops.reorder!+0x9c0>
    7e74:      	b	0x80c4 <_stogir.loops.reorder!+0xc0c>
    7e78:      	sxtw	x5, w6
    7e7c:      	ldr	x7, [x26]
    7e80:      	add	x7, x7, x5, lsl #2
    7e84:      	ldr	w7, [x7]
    7e88:      	sxtw	x7, w7
    7e8c:      	cmp	x7, #0x0
    7e90:      	b.le	0x7ec4 <_stogir.loops.reorder!+0xa0c>
    7e94:      	ldr	x7, [x19]
    7e98:      	add	x7, x7, x4, lsl #2
    7e9c:      	ldr	w7, [x7]
    7ea0:      	sxtw	x7, w7
    7ea4:      	cmp	x7, x5
    7ea8:      	b.eq	0x7eb0 <_stogir.loops.reorder!+0x9f8>
    7eac:      	mov	x3, #0x1                ; =1
    7eb0:      	add	x5, x4, #0x1
    7eb4:      	ldr	x7, [x28]
    7eb8:      	add	x4, x7, x4, lsl #2
    7ebc:      	str	w6, [x4]
    7ec0:      	mov	x4, x5
    7ec4:      	cmp	x2, x1
    7ec8:      	b.ge	0x7e40 <_stogir.loops.reorder!+0x988>
    7ecc:      	add	x5, x2, #0x1
    7ed0:      	add	x2, x0, x2, lsl #2
    7ed4:      	ldr	w2, [x2]
    7ed8:      	movn	w17, #0x0, lsl #16
    7edc:      	and	w6, w2, w17
    7ee0:      	mov	x2, x5
    7ee4:      	mov	w5, #0x1                ; =1
    7ee8:      	b	0x7e48 <_stogir.loops.reorder!+0x990>
    7eec:      	mov	x1, #0x1                ; =1
    7ef0:      	adrp	x0, 0x7000 <_stogir.placement.late-with-uses!+0x9d0>
		0000000000007ef0:  ARM64_RELOC_PAGE21	l_stogir.441
    7ef4:      	ldr	x0, [x0]
		0000000000007ef4:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    7ef8:      	mov	x2, #0x33               ; =51
    7efc:      	b	0x7f0c <_stogir.loops.reorder!+0xa54>
    7f00:      	and	x0, x3, #0xff
    7f04:      	movz	x1, #0x0, lsl #48
    7f08:      	movz	x2, #0x0, lsl #48
    7f0c:      	str	x1, [x23]
    7f10:      	str	x0, [x23, #0x8]
    7f14:      	str	x2, [x23, #0x10]
    7f18:      	ldr	x19, [sp, #0x290]
    7f1c:      	ldr	x20, [sp, #0x298]
    7f20:      	ldr	x21, [sp, #0x2a0]
    7f24:      	ldr	x22, [sp, #0x2a8]
    7f28:      	ldr	x23, [sp, #0x2b0]
    7f2c:      	ldr	x24, [sp, #0x2b8]
    7f30:      	ldr	x25, [sp, #0x2c0]
    7f34:      	ldr	x26, [sp, #0x2c8]
    7f38:      	ldr	x27, [sp, #0x2d0]
    7f3c:      	ldr	x28, [sp, #0x2d8]
    7f40:      	ldr	x29, [sp]
    7f44:      	ldr	x30, [sp, #0x8]
    7f48:      	add	sp, sp, #0x2e0
    7f4c:      	ret
    7f50:      	cmp	x21, #0x0
    7f54:      	b.eq	0x7fc4 <_stogir.loops.reorder!+0xb0c>
    7f58:      	add	x16, sp, #0x50
    7f5c:      	orr	x19, x16, xzr
    7f60:      	add	x8, sp, #0x80
    7f64:      	ldr	x0, [sp, #0x250]
    7f68:      	bl	0x7f68 <_stogir.loops.reorder!+0xab0>
		0000000000007f68:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7f6c:      	add	x16, sp, #0x80
    7f70:      	ldr	x0, [x16]
    7f74:      	add	x16, sp, #0x50
    7f78:      	str	x0, [x16]
    7f7c:      	add	x16, sp, #0x80
    7f80:      	ldr	x0, [x16, #0x8]
    7f84:      	add	x16, sp, #0x50
    7f88:      	str	x0, [x16, #0x8]
    7f8c:      	add	x16, sp, #0x80
    7f90:      	ldr	x0, [x16, #0x10]
    7f94:      	add	x16, sp, #0x50
    7f98:      	str	x0, [x16, #0x10]
    7f9c:      	add	x16, sp, #0x80
    7fa0:      	ldr	x0, [x16, #0x18]
    7fa4:      	add	x16, sp, #0x50
    7fa8:      	str	x0, [x16, #0x18]
    7fac:      	add	x16, sp, #0x80
    7fb0:      	ldr	x0, [x16, #0x20]
    7fb4:      	add	x16, sp, #0x50
    7fb8:      	str	x0, [x16, #0x20]
    7fbc:      	movn	x20, #0x0, lsl #48
    7fc0:      	b	0x8088 <_stogir.loops.reorder!+0xbd0>
    7fc4:      	add	x8, sp, #0x10
    7fc8:      	mov	x0, x24
    7fcc:      	bl	0x7fcc <_stogir.loops.reorder!+0xb14>
		0000000000007fcc:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    7fd0:      	add	x16, sp, #0x10
    7fd4:      	ldr	x0, [x16]
    7fd8:      	add	x16, sp, #0x10
    7fdc:      	ldr	x1, [x16, #0x8]
    7fe0:      	add	x16, sp, #0x10
    7fe4:      	ldr	x2, [x16, #0x10]
    7fe8:      	movz	x3, #0x0, lsl #48
    7fec:      	b	0x77e0 <_stogir.loops.reorder!+0x328>
    7ff0:      	orr	w1, w0, wzr
    7ff4:      	ldr	x2, [x28]
    7ff8:      	add	x2, x2, x0, lsl #2
    7ffc:      	ldr	w2, [x2]
    8000:      	sxtw	x2, w2
    8004:      	add	x16, sp, #0x50
    8008:      	ldr	x3, [x16]
    800c:      	add	x2, x3, x2, lsl #2
    8010:      	str	w1, [x2]
    8014:      	ldr	x1, [x28, #0x8]
    8018:      	add	x0, x0, #0x1
    801c:      	cmp	x0, x1
    8020:      	b.lt	0x7ff0 <_stogir.loops.reorder!+0xb38>
    8024:      	add	x0, x24, #0x50
    8028:      	add	x8, sp, #0xb0
    802c:      	bl	0x802c <_stogir.loops.reorder!+0xb74>
		000000000000802c:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge
    8030:      	add	x16, sp, #0xb0
    8034:      	ldr	x20, [x16]
    8038:      	add	x16, sp, #0xb0
    803c:      	ldr	x21, [x16, #0x8]
    8040:      	add	x16, sp, #0xb0
    8044:      	ldr	x22, [x16, #0x10]
    8048:      	mov	x0, #0x1                ; =1
    804c:      	b	0x75cc <_stogir.loops.reorder!+0x114>
    8050:      	movn	x0, #0x0, lsl #48
    8054:      	b	0x8014 <_stogir.loops.reorder!+0xb5c>
    8058:      	lsl	x0, x0, #1
    805c:      	mov	x1, x0
    8060:      	mov	x0, x19
    8064:      	bl	0x8064 <_stogir.loops.reorder!+0xbac>
		0000000000008064:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8068:      	add	x0, x21, #0x1
    806c:      	add	x16, sp, #0x50
    8070:      	ldr	x1, [x16]
    8074:      	add	x1, x1, x21, lsl #2
    8078:      	movn	w17, #0x0, lsl #16
    807c:      	str	w17, [x1]
    8080:      	add	x16, sp, #0x50
    8084:      	str	x0, [x16, #0x8]
    8088:      	ldr	x0, [x26, #0x8]
    808c:      	add	x20, x20, #0x1
    8090:      	cmp	x20, x0
    8094:      	b.ge	0x8050 <_stogir.loops.reorder!+0xb98>
    8098:      	add	x16, sp, #0x50
    809c:      	ldr	x0, [x16, #0x8]
    80a0:      	orr	x21, x0, xzr
    80a4:      	add	x16, sp, #0x50
    80a8:      	ldr	x0, [x16, #0x10]
    80ac:      	cmp	x21, x0
    80b0:      	b.lt	0x8068 <_stogir.loops.reorder!+0xbb0>
    80b4:      	cmp	x0, #0x0
    80b8:      	b.ne	0x8058 <_stogir.loops.reorder!+0xba0>
    80bc:      	mov	x0, #0x2                ; =2
    80c0:      	b	0x805c <_stogir.loops.reorder!+0xba4>
    80c4:      	brk	#0
    80c8:      	b	0x80c4 <_stogir.loops.reorder!+0xc0c>
    80cc:      	brk	#0
    80d0:      	b	0x80cc <_stogir.loops.reorder!+0xc14>
    80d4:      	brk	#0
    80d8:      	b	0x80d4 <_stogir.loops.reorder!+0xc1c>
    80dc:      	brk	#0
    80e0:      	b	0x80dc <_stogir.loops.reorder!+0xc24>
    80e4:      	brk	#0
    80e8:      	b	0x80e4 <_stogir.loops.reorder!+0xc2c>
    80ec:      	str	x19, [sp, #0x258]
    80f0:      	mov	x19, x0
    80f4:      	b	0x75c4 <_stogir.loops.reorder!+0x10c>
    80f8:      	str	x19, [sp, #0x258]
    80fc:      	mov	x19, x0
    8100:      	b	0x75c4 <_stogir.loops.reorder!+0x10c>
    8104:      	str	x19, [sp, #0x258]
    8108:      	mov	x19, x0
    810c:      	b	0x75c4 <_stogir.loops.reorder!+0x10c>
    8110:      	mov	x23, x8
    8114:      	mov	x24, x0
    8118:      	mov	x25, x1
    811c:      	mov	x26, x2
    8120:      	mov	x27, x3
    8124:      	mov	x28, x4
    8128:      	str	x5, [sp, #0x250]
    812c:      	b	0x7930 <_stogir.loops.reorder!+0x478>
    8130:      	mov	x23, x8
    8134:      	mov	x24, x0
    8138:      	mov	x25, x1
    813c:      	mov	x26, x2
    8140:      	mov	x27, x3
    8144:      	mov	x28, x4
    8148:      	str	x5, [sp, #0x250]
    814c:      	b	0x7930 <_stogir.loops.reorder!+0x478>
    8150:      	mov	x23, x8
    8154:      	mov	x24, x0
    8158:      	mov	x25, x1
    815c:      	mov	x26, x2
    8160:      	mov	x27, x3
    8164:      	mov	x28, x4
    8168:      	str	x5, [sp, #0x250]
    816c:      	b	0x7930 <_stogir.loops.reorder!+0x478>
    8170:      	str	x20, [sp, #0x260]
    8174:      	str	x21, [sp, #0x268]
    8178:      	mov	x20, x1
    817c:      	mov	x21, x0
    8180:      	b	0x79a8 <_stogir.loops.reorder!+0x4f0>
    8184:      	str	x21, [sp, #0x280]
    8188:      	b	0x7d74 <_stogir.loops.reorder!+0x8bc>
    818c:      	mov	w26, w1
    8190:      	b	0x7b74 <_stogir.loops.reorder!+0x6bc>
    8194:      	udf	#0x0

0000000000008198 <_stogir.schedule.order-with-uses>:
    8198:      	sub	sp, sp, #0x2e0
    819c:      	str	x29, [sp, #0x10]
    81a0:      	str	x30, [sp, #0x18]
    81a4:      	add	x29, sp, #0x10
    81a8:      	str	x19, [sp, #0x288]
    81ac:      	str	x20, [sp, #0x290]
    81b0:      	str	x21, [sp, #0x298]
    81b4:      	str	x22, [sp, #0x2a0]
    81b8:      	str	x23, [sp, #0x2a8]
    81bc:      	str	x24, [sp, #0x2b0]
    81c0:      	str	x25, [sp, #0x2b8]
    81c4:      	str	x26, [sp, #0x2c0]
    81c8:      	str	x27, [sp, #0x2c8]
    81cc:      	str	x28, [sp, #0x2d0]
    81d0:      	add	x16, sp, #0x20
    81d4:      	orr	x19, x16, xzr
    81d8:      	add	x16, sp, #0x80
    81dc:      	orr	x20, x16, xzr
    81e0:      	add	x16, sp, #0xe0
    81e4:      	orr	x21, x16, xzr
    81e8:      	mov	x22, x8
    81ec:      	add	x8, sp, #0x50
    81f0:      	mov	x23, x0
    81f4:      	mov	x0, x4
    81f8:      	mov	x24, x1
    81fc:      	mov	x25, x2
    8200:      	mov	x26, x3
    8204:      	mov	x27, x4
    8208:      	bl	0x8208 <_stogir.schedule.order-with-uses+0x70>
		0000000000008208:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    820c:      	add	x16, sp, #0x50
    8210:      	ldr	x0, [x16]
    8214:      	add	x16, sp, #0x20
    8218:      	str	x0, [x16]
    821c:      	add	x16, sp, #0x50
    8220:      	ldr	x0, [x16, #0x8]
    8224:      	add	x16, sp, #0x20
    8228:      	str	x0, [x16, #0x8]
    822c:      	add	x16, sp, #0x50
    8230:      	ldr	x0, [x16, #0x10]
    8234:      	add	x16, sp, #0x20
    8238:      	str	x0, [x16, #0x10]
    823c:      	add	x16, sp, #0x50
    8240:      	ldr	x0, [x16, #0x18]
    8244:      	add	x16, sp, #0x20
    8248:      	str	x0, [x16, #0x18]
    824c:      	add	x16, sp, #0x50
    8250:      	ldr	x0, [x16, #0x20]
    8254:      	add	x16, sp, #0x20
    8258:      	str	x0, [x16, #0x20]
    825c:      	add	x8, sp, #0xb0
    8260:      	mov	x0, x27
    8264:      	bl	0x8264 <_stogir.schedule.order-with-uses+0xcc>
		0000000000008264:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    8268:      	add	x16, sp, #0xb0
    826c:      	ldr	x0, [x16]
    8270:      	add	x16, sp, #0x80
    8274:      	str	x0, [x16]
    8278:      	add	x16, sp, #0xb0
    827c:      	ldr	x0, [x16, #0x8]
    8280:      	add	x16, sp, #0x80
    8284:      	str	x0, [x16, #0x8]
    8288:      	add	x16, sp, #0xb0
    828c:      	ldr	x0, [x16, #0x10]
    8290:      	add	x16, sp, #0x80
    8294:      	str	x0, [x16, #0x10]
    8298:      	add	x16, sp, #0xb0
    829c:      	ldr	x0, [x16, #0x18]
    82a0:      	add	x16, sp, #0x80
    82a4:      	str	x0, [x16, #0x18]
    82a8:      	add	x16, sp, #0xb0
    82ac:      	ldr	x0, [x16, #0x20]
    82b0:      	add	x16, sp, #0x80
    82b4:      	str	x0, [x16, #0x20]
    82b8:      	add	x8, sp, #0x110
    82bc:      	mov	x0, x27
    82c0:      	bl	0x82c0 <_stogir.schedule.order-with-uses+0x128>
		00000000000082c0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    82c4:      	add	x16, sp, #0x110
    82c8:      	ldr	x0, [x16]
    82cc:      	add	x16, sp, #0xe0
    82d0:      	str	x0, [x16]
    82d4:      	add	x16, sp, #0x110
    82d8:      	ldr	x0, [x16, #0x8]
    82dc:      	add	x16, sp, #0xe0
    82e0:      	str	x0, [x16, #0x8]
    82e4:      	add	x16, sp, #0x110
    82e8:      	ldr	x0, [x16, #0x10]
    82ec:      	add	x16, sp, #0xe0
    82f0:      	str	x0, [x16, #0x10]
    82f4:      	add	x16, sp, #0x110
    82f8:      	ldr	x0, [x16, #0x18]
    82fc:      	add	x16, sp, #0xe0
    8300:      	str	x0, [x16, #0x18]
    8304:      	add	x16, sp, #0x110
    8308:      	ldr	x0, [x16, #0x20]
    830c:      	add	x16, sp, #0xe0
    8310:      	str	x0, [x16, #0x20]
    8314:      	add	x8, sp, #0x170
    8318:      	mov	x0, x27
    831c:      	bl	0x831c <_stogir.schedule.order-with-uses+0x184>
		000000000000831c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    8320:      	add	x16, sp, #0x170
    8324:      	ldr	x0, [x16]
    8328:      	add	x16, sp, #0x140
    832c:      	str	x0, [x16]
    8330:      	add	x16, sp, #0x170
    8334:      	ldr	x0, [x16, #0x8]
    8338:      	add	x16, sp, #0x140
    833c:      	str	x0, [x16, #0x8]
    8340:      	add	x16, sp, #0x170
    8344:      	ldr	x0, [x16, #0x10]
    8348:      	add	x16, sp, #0x140
    834c:      	str	x0, [x16, #0x10]
    8350:      	add	x16, sp, #0x170
    8354:      	ldr	x0, [x16, #0x18]
    8358:      	add	x16, sp, #0x140
    835c:      	str	x0, [x16, #0x18]
    8360:      	add	x16, sp, #0x170
    8364:      	ldr	x0, [x16, #0x20]
    8368:      	add	x16, sp, #0x140
    836c:      	str	x0, [x16, #0x20]
    8370:      	ldr	x0, [x23, #0x8]
    8374:      	mov	x1, x0
    8378:      	mov	x0, x20
    837c:      	bl	0x837c <_stogir.schedule.order-with-uses+0x1e4>
		000000000000837c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    8380:      	mov	x0, x23
    8384:      	bl	0x8384 <_stogir.schedule.order-with-uses+0x1ec>
		0000000000008384:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    8388:      	mov	x1, x0
    838c:      	mov	x0, x21
    8390:      	bl	0x8390 <_stogir.schedule.order-with-uses+0x1f8>
		0000000000008390:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64
    8394:      	movz	x28, #0x0, lsl #48
    8398:      	b	0x83e0 <_stogir.schedule.order-with-uses+0x248>
    839c:      	nop
    83a0:      	lsl	x1, x1, #1
    83a4:      	str	x19, [sp, #0x1f0]
    83a8:      	fmov	d31, x0
    83ac:      	mov	x0, x19
    83b0:      	fmov	x19, d31
    83b4:      	bl	0x83b4 <_stogir.schedule.order-with-uses+0x21c>
		00000000000083b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    83b8:      	add	x28, x28, #0x1
    83bc:      	add	x0, x19, #0x1
    83c0:      	add	x16, sp, #0x20
    83c4:      	ldr	x1, [x16]
    83c8:      	add	x1, x1, x19, lsl #3
    83cc:      	movn	x17, #0x0, lsl #48
    83d0:      	str	x17, [x1]
    83d4:      	add	x16, sp, #0x20
    83d8:      	str	x0, [x16, #0x8]
    83dc:      	ldr	x19, [sp, #0x1f0]
    83e0:      	ldr	x0, [x23, #0x8]
    83e4:      	cmp	x28, x0
    83e8:      	b.ge	0x8d80 <_stogir.schedule.order-with-uses+0xbe8>
    83ec:      	add	x16, sp, #0x20
    83f0:      	ldr	x0, [x16, #0x8]
    83f4:      	add	x16, sp, #0x20
    83f8:      	ldr	x1, [x16, #0x10]
    83fc:      	cmp	x0, x1
    8400:      	b.lt	0x8d88 <_stogir.schedule.order-with-uses+0xbf0>
    8404:      	cmp	x1, #0x0
    8408:      	b.ne	0x83a0 <_stogir.schedule.order-with-uses+0x208>
    840c:      	mov	x1, #0x2                ; =2
    8410:      	b	0x83a4 <_stogir.schedule.order-with-uses+0x20c>
    8414:      	mov	x19, #0x1               ; =1
    8418:      	adrp	x0, 0x8000 <_stogir.loops.reorder!+0xb48>
		0000000000008418:  ARM64_RELOC_PAGE21	l_stogir.442
    841c:      	ldr	x0, [x0]
		000000000000841c:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8420:      	movz	x1, #0x0, lsl #48
    8424:      	movz	x28, #0x0, lsl #48
    8428:      	b	0x8650 <_stogir.schedule.order-with-uses+0x4b8>
    842c:      	add	x16, sp, #0xe0
    8430:      	ldr	x0, [x16]
    8434:      	orr	x1, x0, xzr
    8438:      	add	x1, x1, x22, lsl #3
    843c:      	add	x0, x0, x22, lsl #3
    8440:      	ldr	x1, [x1]
    8444:      	add	x1, x1, #0x1
    8448:      	str	x1, [x0]
    844c:      	sxtw	x20, w20
    8450:      	cmp	x21, #0x43
    8454:      	cset	w0, eq
    8458:      	cmp	x21, #0x83
    845c:      	cset	w1, lt
    8460:      	adrp	x17, 0x8000 <_stogir.loops.reorder!+0xb48>
		0000000000008460:  ARM64_RELOC_PAGE21	l_stogir.443
    8464:      	ldr	x17, [x17]
		0000000000008464:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    8468:      	add	x2, x21, x17
    846c:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xb48>
		000000000000846c:  ARM64_RELOC_PAGE21	l_stogir.444
    8470:      	ldr	x16, [x16]
		0000000000008470:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    8474:      	add	x3, x16, x21, lsl #2
    8478:      	orr	x21, x3, xzr
    847c:      	mov	x3, #0x1                ; =1
    8480:      	movz	x4, #0x0, lsl #48
    8484:      	b	0x84f8 <_stogir.schedule.order-with-uses+0x360>
    8488:      	movz	w5, #0x0, lsl #16
    848c:      	uxtb	w16, w5
    8490:      	and	w5, w16, #0x2
    8494:      	uxtb	w5, w5
    8498:      	ubfx	x5, x5, #0, #8
    849c:      	cmp	x5, #0x0
    84a0:      	cset	w5, eq
    84a4:      	uxtb	w16, w5
    84a8:      	cmp	w16, wzr
    84ac:      	cset	x5, eq
    84b0:      	cmp	x5, #0x0
    84b4:      	b.eq	0x8514 <_stogir.schedule.order-with-uses+0x37c>
    84b8:      	str	x20, [sp, #0x240]
    84bc:      	mov	x20, x3
    84c0:      	str	w0, [sp, #0x228]
    84c4:      	str	w1, [sp, #0x230]
    84c8:      	str	x2, [sp, #0x238]
    84cc:      	str	x21, [sp, #0x248]
    84d0:      	mov	x21, x4
    84d4:      	add	x0, x20, #0x1
    84d8:      	sxtw	x20, w0
    84dc:      	ldr	w0, [sp, #0x228]
    84e0:      	ldr	w1, [sp, #0x230]
    84e4:      	ldr	x2, [sp, #0x238]
    84e8:      	mov	x3, x20
    84ec:      	ldr	x20, [sp, #0x240]
    84f0:      	mov	x4, x21
    84f4:      	ldr	x21, [sp, #0x248]
    84f8:      	cmp	x3, x20
    84fc:      	b.gt	0x8d94 <_stogir.schedule.order-with-uses+0xbfc>
    8500:      	uxtb	w16, w1
    8504:      	cmp	w16, wzr
    8508:      	b.eq	0x8488 <_stogir.schedule.order-with-uses+0x2f0>
    850c:      	ldrb	w5, [x2]
    8510:      	b	0x848c <_stogir.schedule.order-with-uses+0x2f4>
    8514:      	orr	w5, w3, wzr
    8518:      	sxtw	x6, w5
    851c:      	uxtb	w16, w0
    8520:      	cmp	w16, wzr
    8524:      	b.eq	0x8550 <_stogir.schedule.order-with-uses+0x3b8>
    8528:      	cmp	x6, #0x2
    852c:      	b.lt	0x8550 <_stogir.schedule.order-with-uses+0x3b8>
    8530:      	str	x20, [sp, #0x240]
    8534:      	mov	x20, x3
    8538:      	str	w0, [sp, #0x228]
    853c:      	str	w1, [sp, #0x230]
    8540:      	str	x2, [sp, #0x238]
    8544:      	str	x21, [sp, #0x248]
    8548:      	mov	x21, x4
    854c:      	b	0x84d4 <_stogir.schedule.order-with-uses+0x33c>
    8550:      	uxtb	w16, w1
    8554:      	cmp	w16, wzr
    8558:      	b.eq	0x8580 <_stogir.schedule.order-with-uses+0x3e8>
    855c:      	ldr	w7, [x21]
    8560:      	cmp	x6, #0x0
    8564:      	b.le	0x8578 <_stogir.schedule.order-with-uses+0x3e0>
    8568:      	cmp	x6, #0x4
    856c:      	b.le	0x8d1c <_stogir.schedule.order-with-uses+0xb84>
    8570:      	mov	w6, #0x4                ; =4
    8574:      	b	0x8d20 <_stogir.schedule.order-with-uses+0xb88>
    8578:      	movz	w6, #0x0, lsl #16
    857c:      	b	0x8584 <_stogir.schedule.order-with-uses+0x3ec>
    8580:      	movz	w6, #0x0, lsl #16
    8584:      	ubfx	x6, x6, #0, #32
    8588:      	cmp	x6, #0xf
    858c:      	b.hs	0x8d9c <_stogir.schedule.order-with-uses+0xc04>
    8590:      	mov	x16, #0x1               ; =1
    8594:      	lsl	x6, x16, x6
    8598:      	mov	w17, #0x5e1c            ; =24092
    859c:      	and	w6, w6, w17
    85a0:      	ubfx	x6, x6, #0, #32
    85a4:      	cmp	x6, #0x0
    85a8:      	b.eq	0x8dbc <_stogir.schedule.order-with-uses+0xc24>
    85ac:      	str	w0, [sp, #0x228]
    85b0:      	mov	x0, x23
    85b4:      	str	w1, [sp, #0x230]
    85b8:      	mov	w1, w27
    85bc:      	str	x2, [sp, #0x238]
    85c0:      	mov	w2, w5
    85c4:      	str	x20, [sp, #0x240]
    85c8:      	mov	x20, x3
    85cc:      	str	x21, [sp, #0x248]
    85d0:      	mov	x21, x4
    85d4:      	bl	0x85d4 <_stogir.schedule.order-with-uses+0x43c>
		00000000000085d4:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    85d8:      	ubfx	x0, x0, #0, #32
    85dc:      	lsr	x16, x0, #0
    85e0:      	cmp	x16, #0x1
    85e4:      	b.eq	0x8600 <_stogir.schedule.order-with-uses+0x468>
    85e8:      	b.lo	0x85f0 <_stogir.schedule.order-with-uses+0x458>
    85ec:      	b	0x8604 <_stogir.schedule.order-with-uses+0x46c>
    85f0:      	cmp	x16, #0x0
    85f4:      	b.eq	0x85fc <_stogir.schedule.order-with-uses+0x464>
    85f8:      	b	0x8604 <_stogir.schedule.order-with-uses+0x46c>
    85fc:      	b	0x8608 <_stogir.schedule.order-with-uses+0x470>
    8600:      	b	0x8d34 <_stogir.schedule.order-with-uses+0xb9c>
    8604:      	b	0x8d78 <_stogir.schedule.order-with-uses+0xbe0>
    8608:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xb48>
		0000000000008608:  ARM64_RELOC_PAGE21	l_stogir.445
    860c:      	ldr	x16, [x16]
		000000000000860c:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    8610:      	str	x16, [sp, #0x218]
    8614:      	mov	x16, #0x19              ; =25
    8618:      	str	x16, [sp, #0x220]
    861c:      	b	0x8d5c <_stogir.schedule.order-with-uses+0xbc4>
    8620:      	add	x28, x28, #0x1
    8624:      	add	x16, sp, #0x20
    8628:      	ldr	x0, [x16]
    862c:      	add	x0, x0, x19, lsl #3
    8630:      	str	x21, [x0]
    8634:      	add	x19, x19, #0x1
    8638:      	ldr	x22, [sp, #0x210]
    863c:      	ldr	x27, [sp, #0x208]
    8640:      	ldr	x20, [sp, #0x1f8]
    8644:      	ldr	x21, [sp, #0x200]
    8648:      	ldr	x0, [sp, #0x218]
    864c:      	ldr	x1, [sp, #0x220]
    8650:      	cmp	x1, #0x0
    8654:      	b.ne	0x8ddc <_stogir.schedule.order-with-uses+0xc44>
    8658:      	add	x16, sp, #0x20
    865c:      	ldr	x2, [x16, #0x8]
    8660:      	cmp	x19, x2
    8664:      	b.ge	0x8df8 <_stogir.schedule.order-with-uses+0xc60>
    8668:      	orr	w2, w19, wzr
    866c:      	str	x20, [sp, #0x1f8]
    8670:      	mov	x20, x0
    8674:      	mov	x0, x23
    8678:      	str	x21, [sp, #0x200]
    867c:      	mov	x21, x1
    8680:      	mov	w1, w2
    8684:      	str	x27, [sp, #0x208]
    8688:      	mov	w27, w2
    868c:      	bl	0x868c <_stogir.schedule.order-with-uses+0x4f4>
		000000000000868c:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
    8690:      	cmp	x0, #0x0
    8694:      	b.eq	0x8e14 <_stogir.schedule.order-with-uses+0xc7c>
    8698:      	ldr	x0, [x25]
    869c:      	add	x0, x19, x0
    86a0:      	ldrb	w0, [x0]
    86a4:      	cmp	x0, #0x0
    86a8:      	b.eq	0x8e24 <_stogir.schedule.order-with-uses+0xc8c>
    86ac:      	ldr	x0, [x24]
    86b0:      	add	x0, x0, x19, lsl #2
    86b4:      	ldr	w0, [x0]
    86b8:      	sxtw	x0, w0
    86bc:      	ldr	x1, [x23]
    86c0:      	add	x1, x1, x19, lsl #4
    86c4:      	ldr	x1, [x1]
    86c8:      	ldr	x2, [x23, #0x78]
    86cc:      	add	x2, x2, x19, lsl #2
    86d0:      	ldr	w2, [x2]
    86d4:      	cmp	x0, #0x0
    86d8:      	b.gt	0x86f8 <_stogir.schedule.order-with-uses+0x560>
    86dc:      	str	x22, [sp, #0x210]
    86e0:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xb48>
		00000000000086e0:  ARM64_RELOC_PAGE21	l_stogir.446
    86e4:      	ldr	x16, [x16]
		00000000000086e4:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    86e8:      	str	x16, [sp, #0x218]
    86ec:      	mov	x16, #0x19              ; =25
    86f0:      	str	x16, [sp, #0x220]
    86f4:      	b	0x8634 <_stogir.schedule.order-with-uses+0x49c>
    86f8:      	uxtb	w1, w1
    86fc:      	orr	x3, x1, xzr
    8700:      	str	x22, [sp, #0x210]
    8704:      	mov	x22, x0
    8708:      	mov	w0, w3
    870c:      	str	x20, [sp, #0x218]
    8710:      	mov	w20, w2
    8714:      	str	x21, [sp, #0x220]
    8718:      	mov	w21, w1
    871c:      	bl	0x871c <_stogir.schedule.order-with-uses+0x584>
		000000000000871c:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    8720:      	cmp	x0, #0x0
    8724:      	b.eq	0x842c <_stogir.schedule.order-with-uses+0x294>
    8728:      	add	x16, sp, #0x80
    872c:      	ldr	x0, [x16]
    8730:      	add	x1, x0, x22, lsl #2
    8734:      	ldr	w1, [x1]
    8738:      	sxtw	x1, w1
    873c:      	cmp	x1, #0x0
    8740:      	b.ne	0x8d60 <_stogir.schedule.order-with-uses+0xbc8>
    8744:      	add	x0, x0, x22, lsl #2
    8748:      	str	w27, [x0]
    874c:      	b	0x8d74 <_stogir.schedule.order-with-uses+0xbdc>
    8750:      	lsl	x7, x7, #1
    8754:      	str	x3, [sp, #0x260]
    8758:      	str	x2, [sp, #0x268]
    875c:      	str	x19, [sp, #0x250]
    8760:      	str	x20, [sp, #0x258]
    8764:      	mov	x20, x1
    8768:      	mov	x1, x7
    876c:      	str	w22, [sp, #0x270]
    8770:      	mov	x22, x4
    8774:      	str	x23, [sp, #0x278]
    8778:      	mov	w23, w5
    877c:      	str	x24, [sp, #0x280]
    8780:      	mov	x24, x6
    8784:      	fmov	d31, x0
    8788:      	mov	x0, x19
    878c:      	fmov	x19, d31
    8790:      	bl	0x8790 <_stogir.schedule.order-with-uses+0x5f8>
		0000000000008790:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8794:      	add	x0, x24, #0x1
    8798:      	add	x16, sp, #0x140
    879c:      	ldr	x1, [x16]
    87a0:      	add	x1, x1, x24, lsl #2
    87a4:      	str	w23, [x1]
    87a8:      	add	x16, sp, #0x140
    87ac:      	str	x0, [x16, #0x8]
    87b0:      	b	0x8948 <_stogir.schedule.order-with-uses+0x7b0>
    87b4:      	add	x16, sp, #0x140
    87b8:      	orr	x19, x16, xzr
    87bc:      	mov	x20, #0x1               ; =1
    87c0:      	b	0x87f8 <_stogir.schedule.order-with-uses+0x660>
    87c4:      	nop
    87c8:      	lsl	x0, x0, #1
    87cc:      	mov	x1, x0
    87d0:      	mov	x0, x19
    87d4:      	bl	0x87d4 <_stogir.schedule.order-with-uses+0x63c>
		00000000000087d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    87d8:      	add	x0, x22, #0x1
    87dc:      	add	x16, sp, #0x140
    87e0:      	ldr	x1, [x16]
    87e4:      	add	x1, x1, x22, lsl #2
    87e8:      	str	w21, [x1]
    87ec:      	add	x16, sp, #0x140
    87f0:      	str	x0, [x16, #0x8]
    87f4:      	add	x20, x20, #0x1
    87f8:      	add	x16, sp, #0x20
    87fc:      	ldr	x0, [x16, #0x8]
    8800:      	cmp	x20, x0
    8804:      	b.ge	0x88c0 <_stogir.schedule.order-with-uses+0x728>
    8808:      	add	x16, sp, #0x20
    880c:      	ldr	x0, [x16]
    8810:      	orr	x1, x0, xzr
    8814:      	add	x2, x1, x20, lsl #3
    8818:      	ldr	x2, [x2]
    881c:      	cmp	x2, #0x0
    8820:      	b.lt	0x87f4 <_stogir.schedule.order-with-uses+0x65c>
    8824:      	orr	w21, w20, wzr
    8828:      	ldr	x2, [x24]
    882c:      	sxtw	x3, w21
    8830:      	add	x2, x2, x20, lsl #2
    8834:      	ldr	w2, [x2]
    8838:      	sxtw	x2, w2
    883c:      	add	x16, sp, #0x80
    8840:      	ldr	x4, [x16]
    8844:      	add	x4, x4, x2, lsl #2
    8848:      	ldr	w4, [x4]
    884c:      	sxtw	x4, w4
    8850:      	cmp	x4, x3
    8854:      	b.ne	0x887c <_stogir.schedule.order-with-uses+0x6e4>
    8858:      	add	x1, x1, x20, lsl #3
    885c:      	add	x0, x0, x20, lsl #3
    8860:      	ldr	x1, [x1]
    8864:      	add	x16, sp, #0xe0
    8868:      	ldr	x3, [x16]
    886c:      	add	x2, x3, x2, lsl #3
    8870:      	ldr	x2, [x2]
    8874:      	add	x1, x2, x1
    8878:      	str	x1, [x0]
    887c:      	add	x16, sp, #0x20
    8880:      	ldr	x0, [x16]
    8884:      	add	x0, x0, x20, lsl #3
    8888:      	ldr	x0, [x0]
    888c:      	cmp	x0, #0x0
    8890:      	b.ne	0x87f4 <_stogir.schedule.order-with-uses+0x65c>
    8894:      	add	x16, sp, #0x140
    8898:      	ldr	x0, [x16, #0x8]
    889c:      	orr	x22, x0, xzr
    88a0:      	add	x16, sp, #0x140
    88a4:      	ldr	x0, [x16, #0x10]
    88a8:      	cmp	x22, x0
    88ac:      	b.lt	0x87d8 <_stogir.schedule.order-with-uses+0x640>
    88b0:      	cmp	x0, #0x0
    88b4:      	b.ne	0x87c8 <_stogir.schedule.order-with-uses+0x630>
    88b8:      	mov	x0, #0x2                ; =2
    88bc:      	b	0x87cc <_stogir.schedule.order-with-uses+0x634>
    88c0:      	orr	x20, x24, xzr
    88c4:      	ldr	x21, [sp, #0x220]
    88c8:      	cmp	x21, #0x0
    88cc:      	cset	w22, eq
    88d0:      	movz	x27, #0x0, lsl #48
    88d4:      	b	0x8ac4 <_stogir.schedule.order-with-uses+0x92c>
    88d8:      	sub	w7, w7, #0x1
    88dc:      	lsl	w7, w7, #2
    88e0:      	ubfx	x7, x7, #0, #32
    88e4:      	lsr	x6, x6, x7
    88e8:      	and	w6, w6, #0xf
    88ec:      	b	0x8b54 <_stogir.schedule.order-with-uses+0x9bc>
    88f0:      	movz	w9, #0x0, lsl #16
    88f4:      	uxtb	w16, w9
    88f8:      	and	w9, w16, #0x2
    88fc:      	uxtb	w9, w9
    8900:      	ubfx	x9, x9, #0, #8
    8904:      	cmp	x9, #0x0
    8908:      	cset	w9, eq
    890c:      	uxtb	w16, w9
    8910:      	cmp	w16, wzr
    8914:      	cset	x9, eq
    8918:      	cmp	x9, #0x0
    891c:      	b.eq	0x8a04 <_stogir.schedule.order-with-uses+0x86c>
    8920:      	str	x23, [sp, #0x278]
    8924:      	str	x19, [sp, #0x250]
    8928:      	mov	x19, x0
    892c:      	str	x20, [sp, #0x258]
    8930:      	mov	x20, x1
    8934:      	str	x3, [sp, #0x260]
    8938:      	str	x2, [sp, #0x268]
    893c:      	str	x24, [sp, #0x280]
    8940:      	str	w22, [sp, #0x270]
    8944:      	mov	x22, x4
    8948:      	add	x22, x22, #0x1
    894c:      	ldr	x23, [sp, #0x278]
    8950:      	mov	x0, x19
    8954:      	ldr	x19, [sp, #0x250]
    8958:      	mov	x1, x20
    895c:      	ldr	x20, [sp, #0x258]
    8960:      	ldr	x3, [sp, #0x260]
    8964:      	ldr	x2, [sp, #0x268]
    8968:      	ldr	x24, [sp, #0x280]
    896c:      	mov	x4, x22
    8970:      	ldr	w22, [sp, #0x270]
    8974:      	cmp	x4, x2
    8978:      	b.ge	0x8e34 <_stogir.schedule.order-with-uses+0xc9c>
    897c:      	add	x5, x3, x4
    8980:      	ldr	x6, [x26, #0x28]
    8984:      	add	x5, x6, x5, lsl #3
    8988:      	ldr	x5, [x5]
    898c:      	add	x16, sp, #0x1a0
    8990:      	str	x5, [x16]
    8994:      	ldr	x6, [x23]
    8998:      	sxtw	x5, w5
    899c:      	add	x6, x6, x5, lsl #4
    89a0:      	ldr	x6, [x6]
    89a4:      	ldr	x7, [x25]
    89a8:      	add	x7, x7, x5
    89ac:      	ldrb	w7, [x7]
    89b0:      	cmp	x7, #0x0
    89b4:      	b.eq	0x8e54 <_stogir.schedule.order-with-uses+0xcbc>
    89b8:      	ldr	x7, [x24]
    89bc:      	add	x7, x7, x5, lsl #2
    89c0:      	ldr	w7, [x7]
    89c4:      	sxtw	x7, w7
    89c8:      	cmp	x7, x1
    89cc:      	b.ne	0x8e80 <_stogir.schedule.order-with-uses+0xce8>
    89d0:      	uxtb	w6, w6
    89d4:      	add	x16, sp, #0x1a0
    89d8:      	ldr	w7, [x16, #0x4]
    89dc:      	cmp	x6, #0x83
    89e0:      	cset	w8, lt
    89e4:      	uxtb	w16, w8
    89e8:      	cmp	w16, wzr
    89ec:      	b.eq	0x88f0 <_stogir.schedule.order-with-uses+0x758>
    89f0:      	adrp	x17, 0x8000 <_stogir.loops.reorder!+0xb48>
		00000000000089f0:  ARM64_RELOC_PAGE21	l_stogir.443
    89f4:      	ldr	x17, [x17]
		00000000000089f4:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    89f8:      	add	x9, x6, x17
    89fc:      	ldrb	w9, [x9]
    8a00:      	b	0x88f4 <_stogir.schedule.order-with-uses+0x75c>
    8a04:      	sxtw	x9, w7
    8a08:      	cmp	x6, #0x43
    8a0c:      	b.ne	0x8b1c <_stogir.schedule.order-with-uses+0x984>
    8a10:      	cmp	x9, #0x2
    8a14:      	b.lt	0x8b1c <_stogir.schedule.order-with-uses+0x984>
    8a18:      	str	x23, [sp, #0x278]
    8a1c:      	str	x19, [sp, #0x250]
    8a20:      	mov	x19, x0
    8a24:      	str	x20, [sp, #0x258]
    8a28:      	mov	x20, x1
    8a2c:      	str	x3, [sp, #0x260]
    8a30:      	str	x2, [sp, #0x268]
    8a34:      	str	x24, [sp, #0x280]
    8a38:      	str	w22, [sp, #0x270]
    8a3c:      	mov	x22, x4
    8a40:      	b	0x8948 <_stogir.schedule.order-with-uses+0x7b0>
    8a44:      	add	x16, sp, #0x80
    8a48:      	ldr	x0, [x16]
    8a4c:      	add	x0, x0, x20, lsl #2
    8a50:      	ldr	w0, [x0]
    8a54:      	sxtw	x1, w0
    8a58:      	cmp	x1, #0x0
    8a5c:      	b.le	0x8aac <_stogir.schedule.order-with-uses+0x914>
    8a60:      	cmp	x1, x19
    8a64:      	b.eq	0x8aac <_stogir.schedule.order-with-uses+0x914>
    8a68:      	add	x16, sp, #0x20
    8a6c:      	ldr	x2, [x16]
    8a70:      	orr	x3, x2, xzr
    8a74:      	add	x3, x3, x1, lsl #3
    8a78:      	add	x2, x2, x1, lsl #3
    8a7c:      	ldr	x3, [x3]
    8a80:      	sub	x3, x3, #0x1
    8a84:      	str	x3, [x2]
    8a88:      	add	x16, sp, #0x20
    8a8c:      	ldr	x2, [x16]
    8a90:      	add	x1, x2, x1, lsl #3
    8a94:      	ldr	x1, [x1]
    8a98:      	cmp	x1, #0x0
    8a9c:      	b.ne	0x8aac <_stogir.schedule.order-with-uses+0x914>
    8aa0:      	mov	w1, w0
    8aa4:      	ldr	x0, [sp, #0x250]
    8aa8:      	bl	0x8aa8 <_stogir.schedule.order-with-uses+0x910>
		0000000000008aa8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    8aac:      	add	x27, x27, #0x1
    8ab0:      	ldr	x23, [sp, #0x278]
    8ab4:      	ldr	x19, [sp, #0x250]
    8ab8:      	ldr	x20, [sp, #0x258]
    8abc:      	ldr	x24, [sp, #0x280]
    8ac0:      	ldr	w22, [sp, #0x270]
    8ac4:      	uxtb	w16, w22
    8ac8:      	cmp	w16, wzr
    8acc:      	b.eq	0x8eac <_stogir.schedule.order-with-uses+0xd14>
    8ad0:      	add	x16, sp, #0x140
    8ad4:      	ldr	x0, [x16, #0x8]
    8ad8:      	cmp	x27, x0
    8adc:      	b.ge	0x8eb8 <_stogir.schedule.order-with-uses+0xd20>
    8ae0:      	add	x16, sp, #0x140
    8ae4:      	ldr	x0, [x16]
    8ae8:      	add	x0, x0, x27, lsl #2
    8aec:      	ldr	w0, [x0]
    8af0:      	sxtw	x0, w0
    8af4:      	ldr	x1, [x20]
    8af8:      	add	x1, x1, x0, lsl #2
    8afc:      	ldr	w1, [x1]
    8b00:      	sxtw	x1, w1
    8b04:      	ldr	x2, [x26]
    8b08:      	add	x2, x2, x0, lsl #4
    8b0c:      	ldr	x3, [x2]
    8b10:      	ldr	x2, [x2, #0x8]
    8b14:      	movz	x4, #0x0, lsl #48
    8b18:      	b	0x8974 <_stogir.schedule.order-with-uses+0x7dc>
    8b1c:      	uxtb	w16, w8
    8b20:      	cmp	w16, wzr
    8b24:      	b.eq	0x8b58 <_stogir.schedule.order-with-uses+0x9c0>
    8b28:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xb48>
		0000000000008b28:  ARM64_RELOC_PAGE21	l_stogir.444
    8b2c:      	ldr	x16, [x16]
		0000000000008b2c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    8b30:      	add	x6, x16, x6, lsl #2
    8b34:      	ldr	w6, [x6]
    8b38:      	cmp	x9, #0x0
    8b3c:      	b.le	0x8b50 <_stogir.schedule.order-with-uses+0x9b8>
    8b40:      	cmp	x9, #0x4
    8b44:      	b.le	0x88d8 <_stogir.schedule.order-with-uses+0x740>
    8b48:      	mov	w7, #0x4                ; =4
    8b4c:      	b	0x88dc <_stogir.schedule.order-with-uses+0x744>
    8b50:      	movz	w6, #0x0, lsl #16
    8b54:      	b	0x8b5c <_stogir.schedule.order-with-uses+0x9c4>
    8b58:      	movz	w6, #0x0, lsl #16
    8b5c:      	ubfx	x6, x6, #0, #32
    8b60:      	cmp	x6, #0xf
    8b64:      	b.hs	0x8ec4 <_stogir.schedule.order-with-uses+0xd2c>
    8b68:      	mov	x16, #0x1               ; =1
    8b6c:      	lsl	x6, x16, x6
    8b70:      	mov	w17, #0x5e1c            ; =24092
    8b74:      	and	w6, w6, w17
    8b78:      	ubfx	x6, x6, #0, #32
    8b7c:      	cmp	x6, #0x0
    8b80:      	b.eq	0x8ef0 <_stogir.schedule.order-with-uses+0xd58>
    8b84:      	add	x16, sp, #0x20
    8b88:      	ldr	x6, [x16]
    8b8c:      	orr	x7, x6, xzr
    8b90:      	add	x7, x7, x5, lsl #3
    8b94:      	add	x6, x6, x5, lsl #3
    8b98:      	ldr	x7, [x7]
    8b9c:      	sub	x7, x7, #0x1
    8ba0:      	str	x7, [x6]
    8ba4:      	add	x16, sp, #0x20
    8ba8:      	ldr	x6, [x16]
    8bac:      	add	x5, x6, x5, lsl #3
    8bb0:      	ldr	x5, [x5]
    8bb4:      	cmp	x5, #0x0
    8bb8:      	b.ne	0x8f1c <_stogir.schedule.order-with-uses+0xd84>
    8bbc:      	add	x16, sp, #0x1a0
    8bc0:      	ldr	w5, [x16]
    8bc4:      	add	x16, sp, #0x140
    8bc8:      	ldr	x6, [x16, #0x8]
    8bcc:      	add	x16, sp, #0x140
    8bd0:      	ldr	x7, [x16, #0x10]
    8bd4:      	cmp	x6, x7
    8bd8:      	b.lt	0x8f48 <_stogir.schedule.order-with-uses+0xdb0>
    8bdc:      	cmp	x7, #0x0
    8be0:      	b.ne	0x8750 <_stogir.schedule.order-with-uses+0x5b8>
    8be4:      	mov	x7, #0x2                ; =2
    8be8:      	b	0x8754 <_stogir.schedule.order-with-uses+0x5bc>
    8bec:      	ldr	x0, [sp, #0x1f0]
    8bf0:      	bl	0x8bf0 <_stogir.schedule.order-with-uses+0xa58>
		0000000000008bf0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    8bf4:      	ldr	x0, [sp, #0x1f8]
    8bf8:      	bl	0x8bf8 <_stogir.schedule.order-with-uses+0xa60>
		0000000000008bf8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    8bfc:      	ldr	x0, [sp, #0x200]
    8c00:      	bl	0x8c00 <_stogir.schedule.order-with-uses+0xa68>
		0000000000008c00:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    8c04:      	ldr	x0, [sp, #0x218]
    8c08:      	mov	x1, x21
    8c0c:      	adrp	x2, 0x8000 <_stogir.loops.reorder!+0xb48>
		0000000000008c0c:  ARM64_RELOC_PAGE21	l_stogir.442
    8c10:      	ldr	x2, [x2]
		0000000000008c10:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8c14:      	movz	x3, #0x0, lsl #48
    8c18:      	bl	0x8c18 <_stogir.schedule.order-with-uses+0xa80>
		0000000000008c18:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    8c1c:      	cmp	x0, #0x0
    8c20:      	b.eq	0x8c44 <_stogir.schedule.order-with-uses+0xaac>
    8c24:      	ldr	x0, [sp, #0x250]
    8c28:      	bl	0x8c28 <_stogir.schedule.order-with-uses+0xa90>
		0000000000008c28:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    8c2c:      	cmp	x0, x28
    8c30:      	b.eq	0x8c44 <_stogir.schedule.order-with-uses+0xaac>
    8c34:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xb48>
		0000000000008c34:  ARM64_RELOC_PAGE21	l_stogir.447
    8c38:      	ldr	x16, [x16]
		0000000000008c38:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    8c3c:      	str	x16, [sp, #0x218]
    8c40:      	mov	x21, #0x16              ; =22
    8c44:      	ldr	x0, [sp, #0x218]
    8c48:      	mov	x1, x21
    8c4c:      	adrp	x2, 0x8000 <_stogir.loops.reorder!+0xb48>
		0000000000008c4c:  ARM64_RELOC_PAGE21	l_stogir.442
    8c50:      	ldr	x2, [x2]
		0000000000008c50:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8c54:      	movz	x3, #0x0, lsl #48
    8c58:      	bl	0x8c58 <_stogir.schedule.order-with-uses+0xac0>
		0000000000008c58:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    8c5c:      	cmp	x0, #0x0
    8c60:      	b.eq	0x8f7c <_stogir.schedule.order-with-uses+0xde4>
    8c64:      	add	x8, sp, #0x1b0
    8c68:      	ldr	x0, [sp, #0x278]
    8c6c:      	ldr	x1, [sp, #0x250]
    8c70:      	ldr	x2, [sp, #0x208]
    8c74:      	bl	0x8c74 <_stogir.schedule.order-with-uses+0xadc>
		0000000000008c74:  ARM64_RELOC_BRANCH26	_stogir.schedule.entry-prefix
    8c78:      	add	x16, sp, #0x1b0
    8c7c:      	ldr	x19, [x16]
    8c80:      	add	x16, sp, #0x1b0
    8c84:      	ldr	x21, [x16, #0x8]
    8c88:      	add	x16, sp, #0x1b0
    8c8c:      	ldr	x20, [x16, #0x10]
    8c90:      	add	x16, sp, #0x1b0
    8c94:      	ldr	x22, [x16, #0x18]
    8c98:      	add	x16, sp, #0x1b0
    8c9c:      	ldr	x23, [x16, #0x20]
    8ca0:      	ldr	x0, [sp, #0x250]
    8ca4:      	bl	0x8ca4 <_stogir.schedule.order-with-uses+0xb0c>
		0000000000008ca4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    8ca8:      	movz	x0, #0x0, lsl #48
    8cac:      	b	0x8cc8 <_stogir.schedule.order-with-uses+0xb30>
    8cb0:      	ldr	x0, [sp, #0x250]
    8cb4:      	bl	0x8cb4 <_stogir.schedule.order-with-uses+0xb1c>
		0000000000008cb4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    8cb8:      	mov	x0, #0x1                ; =1
    8cbc:      	movz	x20, #0x0, lsl #48
    8cc0:      	movz	x22, #0x0, lsl #48
    8cc4:      	movz	x23, #0x0, lsl #48
    8cc8:      	ldr	x1, [sp, #0x210]
    8ccc:      	str	x0, [x1]
    8cd0:      	str	x19, [x1, #0x8]
    8cd4:      	str	x21, [x1, #0x10]
    8cd8:      	str	x20, [x1, #0x18]
    8cdc:      	str	x22, [x1, #0x20]
    8ce0:      	str	x23, [x1, #0x28]
    8ce4:      	ldr	x19, [sp, #0x288]
    8ce8:      	ldr	x20, [sp, #0x290]
    8cec:      	ldr	x21, [sp, #0x298]
    8cf0:      	ldr	x22, [sp, #0x2a0]
    8cf4:      	ldr	x23, [sp, #0x2a8]
    8cf8:      	ldr	x24, [sp, #0x2b0]
    8cfc:      	ldr	x25, [sp, #0x2b8]
    8d00:      	ldr	x26, [sp, #0x2c0]
    8d04:      	ldr	x27, [sp, #0x2c8]
    8d08:      	ldr	x28, [sp, #0x2d0]
    8d0c:      	ldr	x29, [sp, #0x10]
    8d10:      	ldr	x30, [sp, #0x18]
    8d14:      	add	sp, sp, #0x2e0
    8d18:      	ret
    8d1c:      	sub	w6, w5, #0x1
    8d20:      	lsl	w6, w6, #2
    8d24:      	ubfx	x6, x6, #0, #32
    8d28:      	lsr	x6, x7, x6
    8d2c:      	and	w6, w6, #0xf
    8d30:      	b	0x857c <_stogir.schedule.order-with-uses+0x3e4>
    8d34:      	sxtw	x1, w1
    8d38:      	cmp	x1, #0x0
    8d3c:      	b.le	0x8d5c <_stogir.schedule.order-with-uses+0xbc4>
    8d40:      	ldr	x0, [x24]
    8d44:      	add	x0, x0, x1, lsl #2
    8d48:      	ldr	w0, [x0]
    8d4c:      	sxtw	x0, w0
    8d50:      	cmp	x0, x22
    8d54:      	b.ne	0x8d5c <_stogir.schedule.order-with-uses+0xbc4>
    8d58:      	add	x21, x21, #0x1
    8d5c:      	b	0x84d4 <_stogir.schedule.order-with-uses+0x33c>
    8d60:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xb48>
		0000000000008d60:  ARM64_RELOC_PAGE21	l_stogir.448
    8d64:      	ldr	x16, [x16]
		0000000000008d64:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    8d68:      	str	x16, [sp, #0x218]
    8d6c:      	mov	x16, #0x13              ; =19
    8d70:      	str	x16, [sp, #0x220]
    8d74:      	b	0x844c <_stogir.schedule.order-with-uses+0x2b4>
    8d78:      	brk	#0
    8d7c:      	b	0x8d78 <_stogir.schedule.order-with-uses+0xbe0>
    8d80:      	str	x19, [sp, #0x1f0]
    8d84:      	b	0x8414 <_stogir.schedule.order-with-uses+0x27c>
    8d88:      	str	x19, [sp, #0x1f0]
    8d8c:      	mov	x19, x0
    8d90:      	b	0x83b8 <_stogir.schedule.order-with-uses+0x220>
    8d94:      	mov	x21, x4
    8d98:      	b	0x8620 <_stogir.schedule.order-with-uses+0x488>
    8d9c:      	str	x20, [sp, #0x240]
    8da0:      	mov	x20, x3
    8da4:      	str	w0, [sp, #0x228]
    8da8:      	str	w1, [sp, #0x230]
    8dac:      	str	x2, [sp, #0x238]
    8db0:      	str	x21, [sp, #0x248]
    8db4:      	mov	x21, x4
    8db8:      	b	0x84d4 <_stogir.schedule.order-with-uses+0x33c>
    8dbc:      	str	x20, [sp, #0x240]
    8dc0:      	mov	x20, x3
    8dc4:      	str	w0, [sp, #0x228]
    8dc8:      	str	w1, [sp, #0x230]
    8dcc:      	str	x2, [sp, #0x238]
    8dd0:      	str	x21, [sp, #0x248]
    8dd4:      	mov	x21, x4
    8dd8:      	b	0x84d4 <_stogir.schedule.order-with-uses+0x33c>
    8ddc:      	str	x22, [sp, #0x210]
    8de0:      	str	x27, [sp, #0x208]
    8de4:      	str	x20, [sp, #0x1f8]
    8de8:      	str	x21, [sp, #0x200]
    8dec:      	str	x0, [sp, #0x218]
    8df0:      	str	x1, [sp, #0x220]
    8df4:      	b	0x87b4 <_stogir.schedule.order-with-uses+0x61c>
    8df8:      	str	x22, [sp, #0x210]
    8dfc:      	str	x27, [sp, #0x208]
    8e00:      	str	x20, [sp, #0x1f8]
    8e04:      	str	x21, [sp, #0x200]
    8e08:      	str	x0, [sp, #0x218]
    8e0c:      	str	x1, [sp, #0x220]
    8e10:      	b	0x87b4 <_stogir.schedule.order-with-uses+0x61c>
    8e14:      	str	x22, [sp, #0x210]
    8e18:      	str	x20, [sp, #0x218]
    8e1c:      	str	x21, [sp, #0x220]
    8e20:      	b	0x8634 <_stogir.schedule.order-with-uses+0x49c>
    8e24:      	str	x22, [sp, #0x210]
    8e28:      	str	x20, [sp, #0x218]
    8e2c:      	str	x21, [sp, #0x220]
    8e30:      	b	0x8634 <_stogir.schedule.order-with-uses+0x49c>
    8e34:      	str	x23, [sp, #0x278]
    8e38:      	str	x19, [sp, #0x250]
    8e3c:      	mov	x19, x0
    8e40:      	str	x20, [sp, #0x258]
    8e44:      	mov	x20, x1
    8e48:      	str	x24, [sp, #0x280]
    8e4c:      	str	w22, [sp, #0x270]
    8e50:      	b	0x8a44 <_stogir.schedule.order-with-uses+0x8ac>
    8e54:      	str	x23, [sp, #0x278]
    8e58:      	str	x19, [sp, #0x250]
    8e5c:      	mov	x19, x0
    8e60:      	str	x20, [sp, #0x258]
    8e64:      	mov	x20, x1
    8e68:      	str	x3, [sp, #0x260]
    8e6c:      	str	x2, [sp, #0x268]
    8e70:      	str	x24, [sp, #0x280]
    8e74:      	str	w22, [sp, #0x270]
    8e78:      	mov	x22, x4
    8e7c:      	b	0x8948 <_stogir.schedule.order-with-uses+0x7b0>
    8e80:      	str	x23, [sp, #0x278]
    8e84:      	str	x19, [sp, #0x250]
    8e88:      	mov	x19, x0
    8e8c:      	str	x20, [sp, #0x258]
    8e90:      	mov	x20, x1
    8e94:      	str	x3, [sp, #0x260]
    8e98:      	str	x2, [sp, #0x268]
    8e9c:      	str	x24, [sp, #0x280]
    8ea0:      	str	w22, [sp, #0x270]
    8ea4:      	mov	x22, x4
    8ea8:      	b	0x8948 <_stogir.schedule.order-with-uses+0x7b0>
    8eac:      	str	x23, [sp, #0x278]
    8eb0:      	str	x19, [sp, #0x250]
    8eb4:      	b	0x8bec <_stogir.schedule.order-with-uses+0xa54>
    8eb8:      	str	x23, [sp, #0x278]
    8ebc:      	str	x19, [sp, #0x250]
    8ec0:      	b	0x8bec <_stogir.schedule.order-with-uses+0xa54>
    8ec4:      	str	x23, [sp, #0x278]
    8ec8:      	str	x19, [sp, #0x250]
    8ecc:      	mov	x19, x0
    8ed0:      	str	x20, [sp, #0x258]
    8ed4:      	mov	x20, x1
    8ed8:      	str	x3, [sp, #0x260]
    8edc:      	str	x2, [sp, #0x268]
    8ee0:      	str	x24, [sp, #0x280]
    8ee4:      	str	w22, [sp, #0x270]
    8ee8:      	mov	x22, x4
    8eec:      	b	0x8948 <_stogir.schedule.order-with-uses+0x7b0>
    8ef0:      	str	x23, [sp, #0x278]
    8ef4:      	str	x19, [sp, #0x250]
    8ef8:      	mov	x19, x0
    8efc:      	str	x20, [sp, #0x258]
    8f00:      	mov	x20, x1
    8f04:      	str	x3, [sp, #0x260]
    8f08:      	str	x2, [sp, #0x268]
    8f0c:      	str	x24, [sp, #0x280]
    8f10:      	str	w22, [sp, #0x270]
    8f14:      	mov	x22, x4
    8f18:      	b	0x8948 <_stogir.schedule.order-with-uses+0x7b0>
    8f1c:      	str	x23, [sp, #0x278]
    8f20:      	str	x19, [sp, #0x250]
    8f24:      	mov	x19, x0
    8f28:      	str	x20, [sp, #0x258]
    8f2c:      	mov	x20, x1
    8f30:      	str	x3, [sp, #0x260]
    8f34:      	str	x2, [sp, #0x268]
    8f38:      	str	x24, [sp, #0x280]
    8f3c:      	str	w22, [sp, #0x270]
    8f40:      	mov	x22, x4
    8f44:      	b	0x8948 <_stogir.schedule.order-with-uses+0x7b0>
    8f48:      	str	x23, [sp, #0x278]
    8f4c:      	str	x19, [sp, #0x250]
    8f50:      	mov	x19, x0
    8f54:      	str	x20, [sp, #0x258]
    8f58:      	mov	x20, x1
    8f5c:      	str	x3, [sp, #0x260]
    8f60:      	str	x2, [sp, #0x268]
    8f64:      	str	x24, [sp, #0x280]
    8f68:      	mov	w23, w5
    8f6c:      	mov	x24, x6
    8f70:      	str	w22, [sp, #0x270]
    8f74:      	mov	x22, x4
    8f78:      	b	0x8794 <_stogir.schedule.order-with-uses+0x5fc>
    8f7c:      	ldr	x19, [sp, #0x218]
    8f80:      	b	0x8cb0 <_stogir.schedule.order-with-uses+0xb18>
    8f84:      	udf	#0x0

0000000000008f88 <_stogir.schedule.pack>:
    8f88:      	sub	sp, sp, #0xe0
    8f8c:      	str	x29, [sp]
    8f90:      	str	x30, [sp, #0x8]
    8f94:      	mov	x29, sp
    8f98:      	str	x19, [sp, #0x90]
    8f9c:      	str	x20, [sp, #0x98]
    8fa0:      	str	x21, [sp, #0xa0]
    8fa4:      	str	x22, [sp, #0xa8]
    8fa8:      	str	x23, [sp, #0xb0]
    8fac:      	str	x24, [sp, #0xb8]
    8fb0:      	str	x25, [sp, #0xc0]
    8fb4:      	str	x26, [sp, #0xc8]
    8fb8:      	str	x27, [sp, #0xd0]
    8fbc:      	add	x16, sp, #0x10
    8fc0:      	orr	x19, x16, xzr
    8fc4:      	ldr	x4, [x3]
    8fc8:      	ldr	x5, [x3, #0x8]
    8fcc:      	add	x16, sp, #0x10
    8fd0:      	movz	x17, #0x0, lsl #48
    8fd4:      	str	x17, [x16]
    8fd8:      	add	x16, sp, #0x10
    8fdc:      	movz	x17, #0x0, lsl #48
    8fe0:      	str	x17, [x16, #0x8]
    8fe4:      	add	x16, sp, #0x10
    8fe8:      	movz	x17, #0x0, lsl #48
    8fec:      	str	x17, [x16, #0x10]
    8ff0:      	add	x16, sp, #0x10
    8ff4:      	str	x4, [x16, #0x18]
    8ff8:      	add	x16, sp, #0x10
    8ffc:      	str	x5, [x16, #0x20]
    9000:      	add	x16, sp, #0x10
    9004:      	movz	x17, #0x0, lsl #48
    9008:      	str	x17, [x16, #0x28]
    900c:      	add	x16, sp, #0x10
    9010:      	movz	x17, #0x0, lsl #48
    9014:      	str	x17, [x16, #0x30]
    9018:      	add	x16, sp, #0x10
    901c:      	movz	x17, #0x0, lsl #48
    9020:      	str	x17, [x16, #0x38]
    9024:      	add	x16, sp, #0x10
    9028:      	str	x4, [x16, #0x40]
    902c:      	add	x16, sp, #0x10
    9030:      	str	x5, [x16, #0x48]
    9034:      	ldr	x4, [x3]
    9038:      	ldr	x3, [x3, #0x8]
    903c:      	add	x16, sp, #0x60
    9040:      	movz	x17, #0x0, lsl #48
    9044:      	str	x17, [x16]
    9048:      	add	x16, sp, #0x60
    904c:      	movz	x17, #0x0, lsl #48
    9050:      	str	x17, [x16, #0x8]
    9054:      	add	x16, sp, #0x60
    9058:      	movz	x17, #0x0, lsl #48
    905c:      	str	x17, [x16, #0x10]
    9060:      	add	x16, sp, #0x60
    9064:      	str	x4, [x16, #0x18]
    9068:      	add	x16, sp, #0x60
    906c:      	str	x3, [x16, #0x20]
    9070:      	ldr	x3, [x1, #0x8]
    9074:      	orr	x20, x3, xzr
    9078:      	add	x16, sp, #0x10
    907c:      	ldr	x3, [x16, #0x8]
    9080:      	orr	x21, x3, xzr
    9084:      	add	x16, sp, #0x10
    9088:      	ldr	x3, [x16, #0x10]
    908c:      	add	x22, x21, x20
    9090:      	cmp	x22, x3
    9094:      	b.le	0x9564 <_stogir.schedule.pack+0x5dc>
    9098:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    909c:      	cmp	x3, x17
    90a0:      	b.gt	0x90ac <_stogir.schedule.pack+0x124>
    90a4:      	lsl	x3, x3, #1
    90a8:      	b	0x90b0 <_stogir.schedule.pack+0x128>
    90ac:      	mov	x3, x22
    90b0:      	cmp	x3, x22
    90b4:      	b.gt	0x90bc <_stogir.schedule.pack+0x134>
    90b8:      	mov	x3, x22
    90bc:      	mov	x23, x8
    90c0:      	mov	x24, x0
    90c4:      	mov	x0, x19
    90c8:      	mov	x25, x1
    90cc:      	mov	x1, x3
    90d0:      	mov	x26, x2
    90d4:      	bl	0x90d4 <_stogir.schedule.pack+0x14c>
		00000000000090d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range
    90d8:      	add	x16, sp, #0x60
    90dc:      	orr	x27, x16, xzr
    90e0:      	lsl	x0, x20, #4
    90e4:      	add	x16, sp, #0x10
    90e8:      	ldr	x1, [x16]
    90ec:      	add	x1, x1, x21, lsl #4
    90f0:      	mov	x2, x0
    90f4:      	mov	x0, x1
    90f8:      	movz	x1, #0x0, lsl #48
    90fc:      	bl	0x90fc <_stogir.schedule.pack+0x174>
		00000000000090fc:  ARM64_RELOC_BRANCH26	_memset
    9100:      	add	x16, sp, #0x10
    9104:      	str	x22, [x16, #0x8]
    9108:      	ldr	x0, [x25, #0x8]
    910c:      	orr	x20, x0, xzr
    9110:      	add	x16, sp, #0x60
    9114:      	ldr	x0, [x16, #0x8]
    9118:      	orr	x21, x0, xzr
    911c:      	add	x16, sp, #0x60
    9120:      	ldr	x0, [x16, #0x10]
    9124:      	add	x22, x21, x20
    9128:      	cmp	x22, x0
    912c:      	b.le	0x9160 <_stogir.schedule.pack+0x1d8>
    9130:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    9134:      	cmp	x0, x17
    9138:      	b.gt	0x9144 <_stogir.schedule.pack+0x1bc>
    913c:      	lsl	x0, x0, #1
    9140:      	b	0x9148 <_stogir.schedule.pack+0x1c0>
    9144:      	mov	x0, x22
    9148:      	cmp	x0, x22
    914c:      	b.gt	0x9154 <_stogir.schedule.pack+0x1cc>
    9150:      	mov	x0, x22
    9154:      	mov	x1, x0
    9158:      	mov	x0, x27
    915c:      	bl	0x915c <_stogir.schedule.pack+0x1d4>
		000000000000915c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    9160:      	lsl	x0, x20, #3
    9164:      	add	x16, sp, #0x60
    9168:      	ldr	x1, [x16]
    916c:      	add	x1, x1, x21, lsl #3
    9170:      	mov	x2, x0
    9174:      	mov	x0, x1
    9178:      	movz	x1, #0x0, lsl #48
    917c:      	bl	0x917c <_stogir.schedule.pack+0x1f4>
		000000000000917c:  ARM64_RELOC_BRANCH26	_memset
    9180:      	add	x16, sp, #0x60
    9184:      	str	x22, [x16, #0x8]
    9188:      	ldr	x0, [x24]
    918c:      	ldr	x1, [x24, #0x8]
    9190:      	movz	x2, #0x0, lsl #48
    9194:      	b	0x920c <_stogir.schedule.pack+0x284>
    9198:      	movz	w3, #0x0, lsl #16
    919c:      	movz	w4, #0x0, lsl #16
    91a0:      	ubfx	x3, x3, #0, #32
    91a4:      	lsr	x16, x3, #0
    91a8:      	cmp	x16, #0x1
    91ac:      	b.eq	0x91c8 <_stogir.schedule.pack+0x240>
    91b0:      	b.lo	0x91b8 <_stogir.schedule.pack+0x230>
    91b4:      	b	0x91cc <_stogir.schedule.pack+0x244>
    91b8:      	cmp	x16, #0x0
    91bc:      	b.eq	0x91c4 <_stogir.schedule.pack+0x23c>
    91c0:      	b	0x91cc <_stogir.schedule.pack+0x244>
    91c4:      	b	0x9234 <_stogir.schedule.pack+0x2ac>
    91c8:      	b	0x91d0 <_stogir.schedule.pack+0x248>
    91cc:      	b	0x955c <_stogir.schedule.pack+0x5d4>
    91d0:      	sxtw	x4, w4
    91d4:      	ldr	x3, [x25]
    91d8:      	add	x3, x3, x4, lsl #2
    91dc:      	ldr	w3, [x3]
    91e0:      	sxtw	x3, w3
    91e4:      	add	x16, sp, #0x10
    91e8:      	ldr	x4, [x16]
    91ec:      	orr	x5, x4, xzr
    91f0:      	add	x5, x5, x3, lsl #4
    91f4:      	add	x3, x4, x3, lsl #4
    91f8:      	ldr	x4, [x5]
    91fc:      	ldr	x5, [x5, #0x8]
    9200:      	add	x5, x5, #0x1
    9204:      	str	x4, [x3]
    9208:      	str	x5, [x3, #0x8]
    920c:      	cmp	x2, x1
    9210:      	b.ge	0x9198 <_stogir.schedule.pack+0x210>
    9214:      	add	x3, x2, #0x1
    9218:      	add	x2, x0, x2, lsl #2
    921c:      	ldr	w2, [x2]
    9220:      	movn	w17, #0x0, lsl #16
    9224:      	and	w4, w2, w17
    9228:      	mov	x2, x3
    922c:      	mov	w3, #0x1                ; =1
    9230:      	b	0x91a0 <_stogir.schedule.pack+0x218>
    9234:      	ldr	x0, [x26]
    9238:      	ldr	x1, [x26, #0x8]
    923c:      	movz	x2, #0x0, lsl #48
    9240:      	movz	x3, #0x0, lsl #48
    9244:      	b	0x92bc <_stogir.schedule.pack+0x334>
    9248:      	movz	w4, #0x0, lsl #16
    924c:      	movz	w5, #0x0, lsl #16
    9250:      	ubfx	x4, x4, #0, #32
    9254:      	lsr	x16, x4, #0
    9258:      	cmp	x16, #0x1
    925c:      	b.eq	0x9278 <_stogir.schedule.pack+0x2f0>
    9260:      	b.lo	0x9268 <_stogir.schedule.pack+0x2e0>
    9264:      	b	0x927c <_stogir.schedule.pack+0x2f4>
    9268:      	cmp	x16, #0x0
    926c:      	b.eq	0x9274 <_stogir.schedule.pack+0x2ec>
    9270:      	b	0x927c <_stogir.schedule.pack+0x2f4>
    9274:      	b	0x92e4 <_stogir.schedule.pack+0x35c>
    9278:      	b	0x9280 <_stogir.schedule.pack+0x2f8>
    927c:      	b	0x9554 <_stogir.schedule.pack+0x5cc>
    9280:      	sxtw	x5, w5
    9284:      	add	x16, sp, #0x10
    9288:      	ldr	x4, [x16]
    928c:      	orr	x6, x4, xzr
    9290:      	add	x6, x6, x5, lsl #4
    9294:      	add	x4, x4, x5, lsl #4
    9298:      	ldr	x6, [x6, #0x8]
    929c:      	add	x7, x6, x2
    92a0:      	str	x2, [x4]
    92a4:      	str	x6, [x4, #0x8]
    92a8:      	add	x16, sp, #0x60
    92ac:      	ldr	x4, [x16]
    92b0:      	add	x4, x4, x5, lsl #3
    92b4:      	str	x2, [x4]
    92b8:      	mov	x2, x7
    92bc:      	cmp	x3, x1
    92c0:      	b.ge	0x9248 <_stogir.schedule.pack+0x2c0>
    92c4:      	add	x4, x3, #0x1
    92c8:      	add	x3, x0, x3, lsl #2
    92cc:      	ldr	w3, [x3]
    92d0:      	movn	w17, #0x0, lsl #16
    92d4:      	and	w5, w3, w17
    92d8:      	mov	x3, x4
    92dc:      	mov	w4, #0x1                ; =1
    92e0:      	b	0x9250 <_stogir.schedule.pack+0x2c8>
    92e4:      	add	x19, x19, #0x28
    92e8:      	ldr	x0, [x24, #0x8]
    92ec:      	orr	x20, x0, xzr
    92f0:      	ldr	x0, [x19, #0x8]
    92f4:      	orr	x21, x0, xzr
    92f8:      	ldr	x0, [x19, #0x10]
    92fc:      	add	x22, x21, x20
    9300:      	cmp	x22, x0
    9304:      	b.le	0x9338 <_stogir.schedule.pack+0x3b0>
    9308:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    930c:      	cmp	x0, x17
    9310:      	b.gt	0x931c <_stogir.schedule.pack+0x394>
    9314:      	lsl	x0, x0, #1
    9318:      	b	0x9320 <_stogir.schedule.pack+0x398>
    931c:      	mov	x0, x22
    9320:      	cmp	x0, x22
    9324:      	b.gt	0x932c <_stogir.schedule.pack+0x3a4>
    9328:      	mov	x0, x22
    932c:      	mov	x1, x0
    9330:      	mov	x0, x19
    9334:      	bl	0x9334 <_stogir.schedule.pack+0x3ac>
		0000000000009334:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9338:      	lsl	x0, x20, #2
    933c:      	add	x16, sp, #0x10
    9340:      	ldr	x1, [x16, #0x28]
    9344:      	add	x1, x1, x21, lsl #2
    9348:      	mov	x2, x0
    934c:      	mov	x0, x1
    9350:      	movz	x1, #0x0, lsl #48
    9354:      	bl	0x9354 <_stogir.schedule.pack+0x3cc>
		0000000000009354:  ARM64_RELOC_BRANCH26	_memset
    9358:      	str	x22, [x19, #0x8]
    935c:      	ldr	x0, [x24]
    9360:      	ldr	x1, [x24, #0x8]
    9364:      	movz	x2, #0x0, lsl #48
    9368:      	b	0x93f0 <_stogir.schedule.pack+0x468>
    936c:      	nop
    9370:      	movz	w3, #0x0, lsl #16
    9374:      	movz	w4, #0x0, lsl #16
    9378:      	ubfx	x3, x3, #0, #32
    937c:      	lsr	x16, x3, #0
    9380:      	cmp	x16, #0x1
    9384:      	b.eq	0x93a0 <_stogir.schedule.pack+0x418>
    9388:      	b.lo	0x9390 <_stogir.schedule.pack+0x408>
    938c:      	b	0x93a4 <_stogir.schedule.pack+0x41c>
    9390:      	cmp	x16, #0x0
    9394:      	b.eq	0x939c <_stogir.schedule.pack+0x414>
    9398:      	b	0x93a4 <_stogir.schedule.pack+0x41c>
    939c:      	b	0x9418 <_stogir.schedule.pack+0x490>
    93a0:      	b	0x93a8 <_stogir.schedule.pack+0x420>
    93a4:      	b	0x954c <_stogir.schedule.pack+0x5c4>
    93a8:      	sxtw	x3, w4
    93ac:      	ldr	x5, [x25]
    93b0:      	add	x3, x5, x3, lsl #2
    93b4:      	ldr	w3, [x3]
    93b8:      	sxtw	x3, w3
    93bc:      	add	x16, sp, #0x60
    93c0:      	ldr	x5, [x16]
    93c4:      	add	x5, x5, x3, lsl #3
    93c8:      	ldr	x5, [x5]
    93cc:      	add	x16, sp, #0x10
    93d0:      	ldr	x6, [x16, #0x28]
    93d4:      	add	x7, x5, #0x1
    93d8:      	add	x5, x6, x5, lsl #2
    93dc:      	str	w4, [x5]
    93e0:      	add	x16, sp, #0x60
    93e4:      	ldr	x4, [x16]
    93e8:      	add	x3, x4, x3, lsl #3
    93ec:      	str	x7, [x3]
    93f0:      	cmp	x2, x1
    93f4:      	b.ge	0x9370 <_stogir.schedule.pack+0x3e8>
    93f8:      	add	x3, x2, #0x1
    93fc:      	add	x2, x0, x2, lsl #2
    9400:      	ldr	w2, [x2]
    9404:      	movn	w17, #0x0, lsl #16
    9408:      	and	w4, w2, w17
    940c:      	mov	x2, x3
    9410:      	mov	w3, #0x1                ; =1
    9414:      	b	0x9378 <_stogir.schedule.pack+0x3f0>
    9418:      	b	0x942c <_stogir.schedule.pack+0x4a4>
    941c:      	nop
    9420:      	sub	x0, x0, #0x1
    9424:      	add	x16, sp, #0x60
    9428:      	str	x0, [x16, #0x8]
    942c:      	add	x16, sp, #0x60
    9430:      	ldr	x0, [x16, #0x8]
    9434:      	cmp	x0, #0x0
    9438:      	b.ne	0x9420 <_stogir.schedule.pack+0x498>
    943c:      	add	x16, sp, #0x60
    9440:      	ldr	x0, [x16, #0x10]
    9444:      	cmp	x0, #0x0
    9448:      	b.le	0x947c <_stogir.schedule.pack+0x4f4>
    944c:      	add	x1, x27, #0x18
    9450:      	add	x16, sp, #0x60
    9454:      	ldr	x2, [x16]
    9458:      	fmov	d31, x0
    945c:      	mov	x0, x1
    9460:      	mov	x1, x2
    9464:      	fmov	x2, d31
    9468:      	adrp	x3, 0x9000 <_stogir.schedule.pack+0x78>
		0000000000009468:  ARM64_RELOC_PAGE21	l_stogir.449
    946c:      	ldr	x3, [x3]
		000000000000946c:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    9470:      	mov	x4, #0x8                ; =8
    9474:      	mov	x5, #0x8                ; =8
    9478:      	bl	0x9478 <_stogir.schedule.pack+0x4f0>
		0000000000009478:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    947c:      	add	x16, sp, #0x60
    9480:      	movz	x17, #0x0, lsl #48
    9484:      	str	x17, [x16]
    9488:      	add	x16, sp, #0x60
    948c:      	movz	x17, #0x0, lsl #48
    9490:      	str	x17, [x16, #0x8]
    9494:      	add	x16, sp, #0x60
    9498:      	movz	x17, #0x0, lsl #48
    949c:      	str	x17, [x16, #0x10]
    94a0:      	add	x16, sp, #0x10
    94a4:      	ldr	x0, [x16]
    94a8:      	add	x16, sp, #0x10
    94ac:      	ldr	x1, [x16, #0x8]
    94b0:      	add	x16, sp, #0x10
    94b4:      	ldr	x2, [x16, #0x10]
    94b8:      	add	x16, sp, #0x10
    94bc:      	ldr	x3, [x16, #0x18]
    94c0:      	add	x16, sp, #0x10
    94c4:      	ldr	x4, [x16, #0x20]
    94c8:      	add	x16, sp, #0x10
    94cc:      	ldr	x5, [x16, #0x28]
    94d0:      	add	x16, sp, #0x10
    94d4:      	ldr	x6, [x16, #0x30]
    94d8:      	add	x16, sp, #0x10
    94dc:      	ldr	x7, [x16, #0x38]
    94e0:      	add	x16, sp, #0x10
    94e4:      	ldr	x8, [x16, #0x40]
    94e8:      	add	x16, sp, #0x10
    94ec:      	ldr	x9, [x16, #0x48]
    94f0:      	str	x0, [x23]
    94f4:      	str	x1, [x23, #0x8]
    94f8:      	str	x2, [x23, #0x10]
    94fc:      	str	x3, [x23, #0x18]
    9500:      	str	x4, [x23, #0x20]
    9504:      	str	x5, [x23, #0x28]
    9508:      	str	x6, [x23, #0x30]
    950c:      	str	x7, [x23, #0x38]
    9510:      	str	x8, [x23, #0x40]
    9514:      	str	x9, [x23, #0x48]
    9518:      	ldr	x19, [sp, #0x90]
    951c:      	ldr	x20, [sp, #0x98]
    9520:      	ldr	x21, [sp, #0xa0]
    9524:      	ldr	x22, [sp, #0xa8]
    9528:      	ldr	x23, [sp, #0xb0]
    952c:      	ldr	x24, [sp, #0xb8]
    9530:      	ldr	x25, [sp, #0xc0]
    9534:      	ldr	x26, [sp, #0xc8]
    9538:      	ldr	x27, [sp, #0xd0]
    953c:      	ldr	x29, [sp]
    9540:      	ldr	x30, [sp, #0x8]
    9544:      	add	sp, sp, #0xe0
    9548:      	ret
    954c:      	brk	#0
    9550:      	b	0x954c <_stogir.schedule.pack+0x5c4>
    9554:      	brk	#0
    9558:      	b	0x9554 <_stogir.schedule.pack+0x5cc>
    955c:      	brk	#0
    9560:      	b	0x955c <_stogir.schedule.pack+0x5d4>
    9564:      	mov	x23, x8
    9568:      	mov	x24, x0
    956c:      	mov	x25, x1
    9570:      	mov	x26, x2
    9574:      	b	0x90d8 <_stogir.schedule.pack+0x150>

0000000000009578 <_stogir.checked-schedule.cluster!>:
    9578:      	sub	sp, sp, #0x270
    957c:      	str	x29, [sp]
    9580:      	str	x30, [sp, #0x8]
    9584:      	mov	x29, sp
    9588:      	str	x19, [sp, #0x220]
    958c:      	str	x20, [sp, #0x228]
    9590:      	str	x21, [sp, #0x230]
    9594:      	str	x22, [sp, #0x238]
    9598:      	str	x23, [sp, #0x240]
    959c:      	str	x24, [sp, #0x248]
    95a0:      	str	x25, [sp, #0x250]
    95a4:      	str	x26, [sp, #0x258]
    95a8:      	str	x27, [sp, #0x260]
    95ac:      	str	x28, [sp, #0x268]
    95b0:      	add	x4, x2, #0x28
    95b4:      	add	x16, sp, #0x10
    95b8:      	orr	x5, x16, xzr
    95bc:      	add	x19, x5, #0x8
    95c0:      	ldr	x5, [x2, #0x28]
    95c4:      	orr	x20, x5, xzr
    95c8:      	ldr	x4, [x4, #0x8]
    95cc:      	orr	x21, x4, xzr
    95d0:      	movz	x22, #0x0, lsl #48
    95d4:      	adrp	x23, 0x9000 <_stogir.schedule.pack+0x78>
		00000000000095d4:  ARM64_RELOC_PAGE21	l_stogir.450
    95d8:      	ldr	x23, [x23]
		00000000000095d8:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    95dc:      	movz	x24, #0x0, lsl #48
    95e0:      	movz	x25, #0x0, lsl #48
    95e4:      	b	0x9620 <_stogir.checked-schedule.cluster!+0xa8>
    95e8:      	add	x16, sp, #0x10
    95ec:      	ldr	w0, [x16, #0x8]
    95f0:      	sxtw	x0, w0
    95f4:      	cmp	x0, #0x0
    95f8:      	b.eq	0x9604 <_stogir.checked-schedule.cluster!+0x8c>
    95fc:      	add	x0, x22, #0x1
    9600:      	sxtw	x22, w0
    9604:      	mov	x8, x26
    9608:      	mov	x0, x27
    960c:      	mov	x1, x28
    9610:      	mov	x2, x20
    9614:      	mov	x3, x21
    9618:      	ldr	x20, [sp, #0x1c0]
    961c:      	ldr	x21, [sp, #0x1c8]
    9620:      	cmp	x25, x21
    9624:      	b.ge	0x9648 <_stogir.checked-schedule.cluster!+0xd0>
    9628:      	add	x4, x25, #0x1
    962c:      	add	x5, x20, x25, lsl #2
    9630:      	ldr	w5, [x5]
    9634:      	movn	w17, #0x0, lsl #16
    9638:      	and	w5, w5, w17
    963c:      	mov	x25, x4
    9640:      	mov	w4, #0x1                ; =1
    9644:      	b	0x9650 <_stogir.checked-schedule.cluster!+0xd8>
    9648:      	movz	w4, #0x0, lsl #16
    964c:      	movz	w5, #0x0, lsl #16
    9650:      	ubfx	x4, x4, #0, #32
    9654:      	lsr	x16, x4, #0
    9658:      	cmp	x16, #0x1
    965c:      	b.eq	0x968c <_stogir.checked-schedule.cluster!+0x114>
    9660:      	b.lo	0x9668 <_stogir.checked-schedule.cluster!+0xf0>
    9664:      	b	0x9690 <_stogir.checked-schedule.cluster!+0x118>
    9668:      	cmp	x16, #0x0
    966c:      	b.eq	0x9674 <_stogir.checked-schedule.cluster!+0xfc>
    9670:      	b	0x9690 <_stogir.checked-schedule.cluster!+0x118>
    9674:      	mov	x26, x8
    9678:      	mov	x27, x0
    967c:      	mov	x28, x1
    9680:      	mov	x20, x2
    9684:      	mov	x21, x3
    9688:      	b	0x971c <_stogir.checked-schedule.cluster!+0x1a4>
    968c:      	b	0x9694 <_stogir.checked-schedule.cluster!+0x11c>
    9690:      	b	0x9f88 <_stogir.checked-schedule.cluster!+0xa10>
    9694:      	sxtw	x4, w5
    9698:      	ldr	x6, [x0]
    969c:      	add	x4, x6, x4, lsl #4
    96a0:      	ldr	x4, [x4]
    96a4:      	uxtb	w4, w4
    96a8:      	cmp	x4, #0x2c
    96ac:      	b.ne	0x9fb0 <_stogir.checked-schedule.cluster!+0xa38>
    96b0:      	mov	x26, x8
    96b4:      	add	x8, sp, #0x10
    96b8:      	mov	x27, x0
    96bc:      	mov	x28, x1
    96c0:      	mov	w1, w5
    96c4:      	str	x20, [sp, #0x1c0]
    96c8:      	mov	x20, x2
    96cc:      	str	x21, [sp, #0x1c8]
    96d0:      	mov	x21, x3
    96d4:      	bl	0x96d4 <_stogir.checked-schedule.cluster!+0x15c>
		00000000000096d4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    96d8:      	add	x16, sp, #0x10
    96dc:      	ldr	w0, [x16]
    96e0:      	lsr	x16, x0, #0
    96e4:      	cmp	x16, #0x1
    96e8:      	b.eq	0x9704 <_stogir.checked-schedule.cluster!+0x18c>
    96ec:      	b.lo	0x96f4 <_stogir.checked-schedule.cluster!+0x17c>
    96f0:      	b	0x9708 <_stogir.checked-schedule.cluster!+0x190>
    96f4:      	cmp	x16, #0x0
    96f8:      	b.eq	0x9700 <_stogir.checked-schedule.cluster!+0x188>
    96fc:      	b	0x9708 <_stogir.checked-schedule.cluster!+0x190>
    9700:      	b	0x95e8 <_stogir.checked-schedule.cluster!+0x70>
    9704:      	b	0x970c <_stogir.checked-schedule.cluster!+0x194>
    9708:      	b	0x9fa0 <_stogir.checked-schedule.cluster!+0xa28>
    970c:      	add	x16, sp, #0x10
    9710:      	ldr	x23, [x16, #0x8]
    9714:      	ldr	x24, [x19, #0x8]
    9718:      	b	0x9604 <_stogir.checked-schedule.cluster!+0x8c>
    971c:      	cmp	x24, #0x0
    9720:      	b.ne	0x9758 <_stogir.checked-schedule.cluster!+0x1e0>
    9724:      	cmp	x22, #0x0
    9728:      	b.ne	0x9d7c <_stogir.checked-schedule.cluster!+0x804>
    972c:      	add	x8, sp, #0x30
    9730:      	mov	x0, x27
    9734:      	mov	x1, x20
    9738:      	bl	0x9738 <_stogir.checked-schedule.cluster!+0x1c0>
		0000000000009738:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate
    973c:      	add	x16, sp, #0x30
    9740:      	ldr	x0, [x16]
    9744:      	add	x16, sp, #0x30
    9748:      	ldr	x23, [x16, #0x8]
    974c:      	add	x16, sp, #0x30
    9750:      	ldr	x24, [x16, #0x10]
    9754:      	b	0x9b50 <_stogir.checked-schedule.cluster!+0x5d8>
    9758:      	mov	x0, #0x1                ; =1
    975c:      	b	0x9b50 <_stogir.checked-schedule.cluster!+0x5d8>
    9760:      	add	x16, sp, #0xb0
    9764:      	ldr	x2, [x16]
    9768:      	add	x1, x2, x1, lsl #2
    976c:      	str	w21, [x1]
    9770:      	add	x16, sp, #0x80
    9774:      	ldr	x1, [x16]
    9778:      	add	x0, x1, x0, lsl #2
    977c:      	str	w21, [x0]
    9780:      	add	x16, sp, #0xe0
    9784:      	ldr	x0, [x16]
    9788:      	add	x0, x0, x25
    978c:      	mov	w17, #0x1               ; =1
    9790:      	strb	w17, [x0]
    9794:      	ldr	x25, [sp, #0x200]
    9798:      	ldr	x21, [sp, #0x1f8]
    979c:      	ldr	x0, [sp, #0x1e8]
    97a0:      	ldr	x1, [sp, #0x1f0]
    97a4:      	cmp	x1, x0
    97a8:      	b.ge	0x97cc <_stogir.checked-schedule.cluster!+0x254>
    97ac:      	add	x2, x1, #0x1
    97b0:      	add	x1, x21, x1, lsl #2
    97b4:      	ldr	w1, [x1]
    97b8:      	movn	w17, #0x0, lsl #16
    97bc:      	and	w3, w1, w17
    97c0:      	mov	x1, x2
    97c4:      	mov	w2, #0x1                ; =1
    97c8:      	b	0x97d4 <_stogir.checked-schedule.cluster!+0x25c>
    97cc:      	movz	w2, #0x0, lsl #16
    97d0:      	movz	w3, #0x0, lsl #16
    97d4:      	ubfx	x2, x2, #0, #32
    97d8:      	lsr	x16, x2, #0
    97dc:      	cmp	x16, #0x1
    97e0:      	b.eq	0x9800 <_stogir.checked-schedule.cluster!+0x288>
    97e4:      	b.lo	0x97ec <_stogir.checked-schedule.cluster!+0x274>
    97e8:      	b	0x9804 <_stogir.checked-schedule.cluster!+0x28c>
    97ec:      	cmp	x16, #0x0
    97f0:      	b.eq	0x97f8 <_stogir.checked-schedule.cluster!+0x280>
    97f4:      	b	0x9804 <_stogir.checked-schedule.cluster!+0x28c>
    97f8:      	str	x25, [sp, #0x200]
    97fc:      	b	0x98a8 <_stogir.checked-schedule.cluster!+0x330>
    9800:      	b	0x9808 <_stogir.checked-schedule.cluster!+0x290>
    9804:      	b	0x9f90 <_stogir.checked-schedule.cluster!+0xa18>
    9808:      	sxtw	x2, w3
    980c:      	ldr	x4, [x27]
    9810:      	add	x4, x4, x2, lsl #4
    9814:      	ldr	x5, [x4]
    9818:      	uxtb	w6, w5
    981c:      	ldr	x4, [x4, #0x8]
    9820:      	add	x16, sp, #0x170
    9824:      	str	x5, [x16]
    9828:      	add	x16, sp, #0x170
    982c:      	str	x4, [x16, #0x8]
    9830:      	cmp	x6, #0x2c
    9834:      	b.ne	0x9fd0 <_stogir.checked-schedule.cluster!+0xa58>
    9838:      	lsr	x4, x5, #32
    983c:      	add	x8, sp, #0x180
    9840:      	str	x0, [sp, #0x1e8]
    9844:      	mov	x0, x27
    9848:      	str	x1, [sp, #0x1f0]
    984c:      	mov	w1, w4
    9850:      	str	x21, [sp, #0x1f8]
    9854:      	mov	w21, w3
    9858:      	str	x25, [sp, #0x200]
    985c:      	mov	x25, x2
    9860:      	bl	0x9860 <_stogir.checked-schedule.cluster!+0x2e8>
		0000000000009860:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    9864:      	add	x16, sp, #0x180
    9868:      	ldr	w0, [x16]
    986c:      	lsr	x16, x0, #0
    9870:      	cmp	x16, #0x1
    9874:      	b.eq	0x9890 <_stogir.checked-schedule.cluster!+0x318>
    9878:      	b.lo	0x9880 <_stogir.checked-schedule.cluster!+0x308>
    987c:      	b	0x9894 <_stogir.checked-schedule.cluster!+0x31c>
    9880:      	cmp	x16, #0x0
    9884:      	b.eq	0x988c <_stogir.checked-schedule.cluster!+0x314>
    9888:      	b	0x9894 <_stogir.checked-schedule.cluster!+0x31c>
    988c:      	b	0x9efc <_stogir.checked-schedule.cluster!+0x984>
    9890:      	b	0x9898 <_stogir.checked-schedule.cluster!+0x320>
    9894:      	b	0x9fa8 <_stogir.checked-schedule.cluster!+0xa30>
    9898:      	add	x16, sp, #0x180
    989c:      	ldr	x23, [x16, #0x8]
    98a0:      	ldr	x24, [x19, #0x8]
    98a4:      	b	0x9794 <_stogir.checked-schedule.cluster!+0x21c>
    98a8:      	add	x16, sp, #0x110
    98ac:      	orr	x19, x16, xzr
    98b0:      	add	x0, x20, #0x28
    98b4:      	ldr	x1, [x20, #0x28]
    98b8:      	orr	x21, x1, xzr
    98bc:      	ldr	x0, [x0, #0x8]
    98c0:      	orr	x25, x0, xzr
    98c4:      	movz	x28, #0x0, lsl #48
    98c8:      	b	0x9a30 <_stogir.checked-schedule.cluster!+0x4b8>
    98cc:      	ldr	x0, [sp, #0x208]
    98d0:      	bl	0x98d0 <_stogir.checked-schedule.cluster!+0x358>
		00000000000098d0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    98d4:      	mov	x0, #0x1                ; =1
    98d8:      	b	0x9b50 <_stogir.checked-schedule.cluster!+0x5d8>
    98dc:      	adrp	x23, 0x9000 <_stogir.schedule.pack+0x78>
		00000000000098dc:  ARM64_RELOC_PAGE21	l_stogir.451
    98e0:      	ldr	x23, [x23]
		00000000000098e0:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    98e4:      	mov	x24, #0x32              ; =50
    98e8:      	b	0x9a70 <_stogir.checked-schedule.cluster!+0x4f8>
    98ec:      	lsl	x3, x3, #1
    98f0:      	str	x19, [sp, #0x208]
    98f4:      	str	x21, [sp, #0x210]
    98f8:      	mov	x21, x0
    98fc:      	mov	x0, x19
    9900:      	mov	w19, w1
    9904:      	mov	x1, x3
    9908:      	str	x25, [sp, #0x218]
    990c:      	mov	x25, x2
    9910:      	bl	0x9910 <_stogir.checked-schedule.cluster!+0x398>
		0000000000009910:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9914:      	add	x0, x25, #0x1
    9918:      	add	x16, sp, #0x110
    991c:      	ldr	x1, [x16]
    9920:      	add	x1, x1, x25, lsl #2
    9924:      	str	w19, [x1]
    9928:      	add	x16, sp, #0x110
    992c:      	str	x0, [x16, #0x8]
    9930:      	add	x16, sp, #0x50
    9934:      	ldr	x0, [x16]
    9938:      	add	x0, x0, x21, lsl #2
    993c:      	ldr	w0, [x0]
    9940:      	orr	w19, w0, wzr
    9944:      	b	0x9988 <_stogir.checked-schedule.cluster!+0x410>
    9948:      	lsl	x0, x0, #1
    994c:      	mov	x1, x0
    9950:      	ldr	x0, [sp, #0x208]
    9954:      	bl	0x9954 <_stogir.checked-schedule.cluster!+0x3dc>
		0000000000009954:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9958:      	add	x0, x25, #0x1
    995c:      	add	x16, sp, #0x110
    9960:      	ldr	x1, [x16]
    9964:      	add	x1, x1, x25, lsl #2
    9968:      	str	w19, [x1]
    996c:      	add	x16, sp, #0x110
    9970:      	str	x0, [x16, #0x8]
    9974:      	add	x16, sp, #0xb0
    9978:      	ldr	x0, [x16]
    997c:      	add	x0, x0, x21, lsl #2
    9980:      	ldr	w0, [x0]
    9984:      	orr	w19, w0, wzr
    9988:      	sxtw	x21, w19
    998c:      	cmp	x21, #0x0
    9990:      	b.eq	0x9a24 <_stogir.checked-schedule.cluster!+0x4ac>
    9994:      	add	x16, sp, #0x110
    9998:      	ldr	x0, [x16, #0x8]
    999c:      	orr	x25, x0, xzr
    99a0:      	add	x16, sp, #0x110
    99a4:      	ldr	x0, [x16, #0x10]
    99a8:      	cmp	x25, x0
    99ac:      	b.lt	0x9958 <_stogir.checked-schedule.cluster!+0x3e0>
    99b0:      	cmp	x0, #0x0
    99b4:      	b.ne	0x9948 <_stogir.checked-schedule.cluster!+0x3d0>
    99b8:      	mov	x0, #0x2                ; =2
    99bc:      	b	0x994c <_stogir.checked-schedule.cluster!+0x3d4>
    99c0:      	movz	w0, #0x0, lsl #16
    99c4:      	movz	w1, #0x0, lsl #16
    99c8:      	ubfx	x0, x0, #0, #32
    99cc:      	lsr	x16, x0, #0
    99d0:      	cmp	x16, #0x1
    99d4:      	b.eq	0x99f4 <_stogir.checked-schedule.cluster!+0x47c>
    99d8:      	b.lo	0x99e0 <_stogir.checked-schedule.cluster!+0x468>
    99dc:      	b	0x99f8 <_stogir.checked-schedule.cluster!+0x480>
    99e0:      	cmp	x16, #0x0
    99e4:      	b.eq	0x99ec <_stogir.checked-schedule.cluster!+0x474>
    99e8:      	b	0x99f8 <_stogir.checked-schedule.cluster!+0x480>
    99ec:      	str	x19, [sp, #0x208]
    99f0:      	b	0x9a58 <_stogir.checked-schedule.cluster!+0x4e0>
    99f4:      	b	0x99fc <_stogir.checked-schedule.cluster!+0x484>
    99f8:      	b	0x9f80 <_stogir.checked-schedule.cluster!+0xa08>
    99fc:      	sxtw	x0, w1
    9a00:      	add	x16, sp, #0xe0
    9a04:      	ldr	x2, [x16]
    9a08:      	add	x2, x2, x0
    9a0c:      	ldrb	w2, [x2]
    9a10:      	cmp	x2, #0x0
    9a14:      	b.eq	0x9b94 <_stogir.checked-schedule.cluster!+0x61c>
    9a18:      	str	x19, [sp, #0x208]
    9a1c:      	str	x21, [sp, #0x210]
    9a20:      	str	x25, [sp, #0x218]
    9a24:      	ldr	x19, [sp, #0x208]
    9a28:      	ldr	x21, [sp, #0x210]
    9a2c:      	ldr	x25, [sp, #0x218]
    9a30:      	cmp	x28, x25
    9a34:      	b.ge	0x99c0 <_stogir.checked-schedule.cluster!+0x448>
    9a38:      	add	x0, x28, #0x1
    9a3c:      	add	x1, x21, x28, lsl #2
    9a40:      	ldr	w1, [x1]
    9a44:      	movn	w17, #0x0, lsl #16
    9a48:      	and	w1, w1, w17
    9a4c:      	mov	x28, x0
    9a50:      	mov	w0, #0x1                ; =1
    9a54:      	b	0x99c8 <_stogir.checked-schedule.cluster!+0x450>
    9a58:      	add	x0, x20, #0x28
    9a5c:      	add	x16, sp, #0x110
    9a60:      	ldr	x1, [x16, #0x8]
    9a64:      	ldr	x0, [x0, #0x8]
    9a68:      	cmp	x1, x0
    9a6c:      	b.ne	0x98dc <_stogir.checked-schedule.cluster!+0x364>
    9a70:      	cmp	x24, #0x0
    9a74:      	b.ne	0x9ad4 <_stogir.checked-schedule.cluster!+0x55c>
    9a78:      	add	x8, sp, #0x1a0
    9a7c:      	mov	x0, x27
    9a80:      	ldr	x1, [sp, #0x208]
    9a84:      	bl	0x9a84 <_stogir.checked-schedule.cluster!+0x50c>
		0000000000009a84:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    9a88:      	add	x16, sp, #0x1a0
    9a8c:      	ldr	w0, [x16]
    9a90:      	lsr	x16, x0, #0
    9a94:      	cmp	x16, #0x1
    9a98:      	b.eq	0x9ab4 <_stogir.checked-schedule.cluster!+0x53c>
    9a9c:      	b.lo	0x9aa4 <_stogir.checked-schedule.cluster!+0x52c>
    9aa0:      	b	0x9ab8 <_stogir.checked-schedule.cluster!+0x540>
    9aa4:      	cmp	x16, #0x0
    9aa8:      	b.eq	0x9ab0 <_stogir.checked-schedule.cluster!+0x538>
    9aac:      	b	0x9ab8 <_stogir.checked-schedule.cluster!+0x540>
    9ab0:      	b	0x9ad4 <_stogir.checked-schedule.cluster!+0x55c>
    9ab4:      	b	0x9abc <_stogir.checked-schedule.cluster!+0x544>
    9ab8:      	b	0x9f98 <_stogir.checked-schedule.cluster!+0xa20>
    9abc:      	add	x16, sp, #0x1a0
    9ac0:      	orr	x0, x16, xzr
    9ac4:      	add	x0, x0, #0x8
    9ac8:      	add	x16, sp, #0x1a0
    9acc:      	ldr	x23, [x16, #0x8]
    9ad0:      	ldr	x24, [x0, #0x8]
    9ad4:      	ldr	x0, [sp, #0x1d8]
    9ad8:      	bl	0x9ad8 <_stogir.checked-schedule.cluster!+0x560>
		0000000000009ad8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9adc:      	ldr	x0, [sp, #0x200]
    9ae0:      	bl	0x9ae0 <_stogir.checked-schedule.cluster!+0x568>
		0000000000009ae0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9ae4:      	ldr	x0, [sp, #0x1e0]
    9ae8:      	bl	0x9ae8 <_stogir.checked-schedule.cluster!+0x570>
		0000000000009ae8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9aec:      	ldr	x0, [sp, #0x1d0]
    9af0:      	bl	0x9af0 <_stogir.checked-schedule.cluster!+0x578>
		0000000000009af0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__bool
    9af4:      	cmp	x24, #0x0
    9af8:      	b.ne	0x98cc <_stogir.checked-schedule.cluster!+0x354>
    9afc:      	add	x19, x20, #0x28
    9b00:      	and	x23, x22, #0xffffffff
    9b04:      	mov	x0, x19
    9b08:      	bl	0x9b08 <_stogir.checked-schedule.cluster!+0x590>
		0000000000009b08:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9b0c:      	add	x16, sp, #0x110
    9b10:      	ldr	x0, [x16]
    9b14:      	add	x16, sp, #0x110
    9b18:      	ldr	x1, [x16, #0x8]
    9b1c:      	add	x16, sp, #0x110
    9b20:      	ldr	x2, [x16, #0x10]
    9b24:      	add	x16, sp, #0x110
    9b28:      	ldr	x3, [x16, #0x18]
    9b2c:      	add	x16, sp, #0x110
    9b30:      	ldr	x4, [x16, #0x20]
    9b34:      	str	x0, [x20, #0x28]
    9b38:      	str	x1, [x19, #0x8]
    9b3c:      	str	x2, [x19, #0x10]
    9b40:      	str	x3, [x19, #0x18]
    9b44:      	str	x4, [x19, #0x20]
    9b48:      	movz	x0, #0x0, lsl #48
    9b4c:      	movz	x24, #0x0, lsl #48
    9b50:      	str	x0, [x26]
    9b54:      	str	x23, [x26, #0x8]
    9b58:      	str	x24, [x26, #0x10]
    9b5c:      	ldr	x19, [sp, #0x220]
    9b60:      	ldr	x20, [sp, #0x228]
    9b64:      	ldr	x21, [sp, #0x230]
    9b68:      	ldr	x22, [sp, #0x238]
    9b6c:      	ldr	x23, [sp, #0x240]
    9b70:      	ldr	x24, [sp, #0x248]
    9b74:      	ldr	x25, [sp, #0x250]
    9b78:      	ldr	x26, [sp, #0x258]
    9b7c:      	ldr	x27, [sp, #0x260]
    9b80:      	ldr	x28, [sp, #0x268]
    9b84:      	ldr	x29, [sp]
    9b88:      	ldr	x30, [sp, #0x8]
    9b8c:      	add	sp, sp, #0x270
    9b90:      	ret
    9b94:      	add	x16, sp, #0x110
    9b98:      	ldr	x2, [x16, #0x8]
    9b9c:      	add	x16, sp, #0x110
    9ba0:      	ldr	x3, [x16, #0x10]
    9ba4:      	cmp	x2, x3
    9ba8:      	b.lt	0x9fe4 <_stogir.checked-schedule.cluster!+0xa6c>
    9bac:      	cmp	x3, #0x0
    9bb0:      	b.ne	0x98ec <_stogir.checked-schedule.cluster!+0x374>
    9bb4:      	mov	x3, #0x2                ; =2
    9bb8:      	b	0x98f0 <_stogir.checked-schedule.cluster!+0x378>
    9bbc:      	add	x16, sp, #0x180
    9bc0:      	orr	x0, x16, xzr
    9bc4:      	add	x1, x20, #0x28
    9bc8:      	add	x19, x0, #0x8
    9bcc:      	ldr	x0, [x20, #0x28]
    9bd0:      	orr	x21, x0, xzr
    9bd4:      	ldr	x0, [x1, #0x8]
    9bd8:      	movz	x1, #0x0, lsl #48
    9bdc:      	b	0x97a4 <_stogir.checked-schedule.cluster!+0x22c>
    9be0:      	lsl	x2, x2, #1
    9be4:      	str	x19, [sp, #0x1d8]
    9be8:      	str	x21, [sp, #0x1e0]
    9bec:      	mov	x21, x1
    9bf0:      	mov	x1, x2
    9bf4:      	fmov	d31, x0
    9bf8:      	mov	x0, x19
    9bfc:      	fmov	x19, d31
    9c00:      	bl	0x9c00 <_stogir.checked-schedule.cluster!+0x688>
		0000000000009c00:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9c04:      	add	x0, x21, #0x1
    9c08:      	add	x16, sp, #0x50
    9c0c:      	ldr	x1, [x16]
    9c10:      	add	x1, x1, x21, lsl #2
    9c14:      	movz	w17, #0x0, lsl #16
    9c18:      	str	w17, [x1]
    9c1c:      	add	x16, sp, #0x50
    9c20:      	str	x0, [x16, #0x8]
    9c24:      	add	x16, sp, #0x80
    9c28:      	ldr	x0, [x16, #0x8]
    9c2c:      	orr	x21, x0, xzr
    9c30:      	add	x16, sp, #0x80
    9c34:      	ldr	x0, [x16, #0x10]
    9c38:      	cmp	x21, x0
    9c3c:      	b.lt	0x9c60 <_stogir.checked-schedule.cluster!+0x6e8>
    9c40:      	cmp	x0, #0x0
    9c44:      	b.ne	0x9c50 <_stogir.checked-schedule.cluster!+0x6d8>
    9c48:      	mov	x0, #0x2                ; =2
    9c4c:      	b	0x9c54 <_stogir.checked-schedule.cluster!+0x6dc>
    9c50:      	lsl	x0, x0, #1
    9c54:      	mov	x1, x0
    9c58:      	mov	x0, x25
    9c5c:      	bl	0x9c5c <_stogir.checked-schedule.cluster!+0x6e4>
		0000000000009c5c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9c60:      	add	x0, x21, #0x1
    9c64:      	add	x16, sp, #0x80
    9c68:      	ldr	x1, [x16]
    9c6c:      	add	x1, x1, x21, lsl #2
    9c70:      	movz	w17, #0x0, lsl #16
    9c74:      	str	w17, [x1]
    9c78:      	add	x16, sp, #0x80
    9c7c:      	str	x0, [x16, #0x8]
    9c80:      	add	x16, sp, #0xb0
    9c84:      	ldr	x0, [x16, #0x8]
    9c88:      	orr	x21, x0, xzr
    9c8c:      	add	x16, sp, #0xb0
    9c90:      	ldr	x0, [x16, #0x10]
    9c94:      	cmp	x21, x0
    9c98:      	b.lt	0x9cbc <_stogir.checked-schedule.cluster!+0x744>
    9c9c:      	cmp	x0, #0x0
    9ca0:      	b.ne	0x9cac <_stogir.checked-schedule.cluster!+0x734>
    9ca4:      	mov	x0, #0x2                ; =2
    9ca8:      	b	0x9cb0 <_stogir.checked-schedule.cluster!+0x738>
    9cac:      	lsl	x0, x0, #1
    9cb0:      	mov	x1, x0
    9cb4:      	ldr	x0, [sp, #0x1e0]
    9cb8:      	bl	0x9cb8 <_stogir.checked-schedule.cluster!+0x740>
		0000000000009cb8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9cbc:      	add	x0, x21, #0x1
    9cc0:      	add	x16, sp, #0xb0
    9cc4:      	ldr	x1, [x16]
    9cc8:      	add	x1, x1, x21, lsl #2
    9ccc:      	movz	w17, #0x0, lsl #16
    9cd0:      	str	w17, [x1]
    9cd4:      	add	x16, sp, #0xb0
    9cd8:      	str	x0, [x16, #0x8]
    9cdc:      	add	x16, sp, #0xe0
    9ce0:      	ldr	x0, [x16, #0x8]
    9ce4:      	orr	x21, x0, xzr
    9ce8:      	add	x16, sp, #0xe0
    9cec:      	ldr	x0, [x16, #0x10]
    9cf0:      	cmp	x21, x0
    9cf4:      	b.lt	0x9d18 <_stogir.checked-schedule.cluster!+0x7a0>
    9cf8:      	cmp	x0, #0x0
    9cfc:      	b.ne	0x9d08 <_stogir.checked-schedule.cluster!+0x790>
    9d00:      	mov	x0, #0x2                ; =2
    9d04:      	b	0x9d0c <_stogir.checked-schedule.cluster!+0x794>
    9d08:      	lsl	x0, x0, #1
    9d0c:      	mov	x1, x0
    9d10:      	ldr	x0, [sp, #0x1d0]
    9d14:      	bl	0x9d14 <_stogir.checked-schedule.cluster!+0x79c>
		0000000000009d14:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    9d18:      	add	x19, x19, #0x1
    9d1c:      	add	x0, x21, #0x1
    9d20:      	add	x16, sp, #0xe0
    9d24:      	ldr	x1, [x16]
    9d28:      	add	x1, x1, x21
    9d2c:      	movz	w17, #0x0, lsl #16
    9d30:      	strb	w17, [x1]
    9d34:      	add	x16, sp, #0xe0
    9d38:      	str	x0, [x16, #0x8]
    9d3c:      	ldr	x21, [sp, #0x1e0]
    9d40:      	mov	x0, x19
    9d44:      	ldr	x19, [sp, #0x1d8]
    9d48:      	ldr	x1, [x27, #0x8]
    9d4c:      	cmp	x0, x1
    9d50:      	b.ge	0xa000 <_stogir.checked-schedule.cluster!+0xa88>
    9d54:      	add	x16, sp, #0x50
    9d58:      	ldr	x1, [x16, #0x8]
    9d5c:      	add	x16, sp, #0x50
    9d60:      	ldr	x2, [x16, #0x10]
    9d64:      	cmp	x1, x2
    9d68:      	b.lt	0xa00c <_stogir.checked-schedule.cluster!+0xa94>
    9d6c:      	cmp	x2, #0x0
    9d70:      	b.ne	0x9be0 <_stogir.checked-schedule.cluster!+0x668>
    9d74:      	mov	x2, #0x2                ; =2
    9d78:      	b	0x9be4 <_stogir.checked-schedule.cluster!+0x66c>
    9d7c:      	add	x16, sp, #0x50
    9d80:      	orr	x19, x16, xzr
    9d84:      	add	x16, sp, #0x80
    9d88:      	orr	x25, x16, xzr
    9d8c:      	add	x16, sp, #0xb0
    9d90:      	orr	x0, x16, xzr
    9d94:      	add	x16, sp, #0xe0
    9d98:      	orr	x1, x16, xzr
    9d9c:      	ldr	x2, [x21]
    9da0:      	ldr	x3, [x21, #0x8]
    9da4:      	add	x16, sp, #0x50
    9da8:      	movz	x17, #0x0, lsl #48
    9dac:      	str	x17, [x16]
    9db0:      	add	x16, sp, #0x50
    9db4:      	movz	x17, #0x0, lsl #48
    9db8:      	str	x17, [x16, #0x8]
    9dbc:      	add	x16, sp, #0x50
    9dc0:      	movz	x17, #0x0, lsl #48
    9dc4:      	str	x17, [x16, #0x10]
    9dc8:      	add	x16, sp, #0x50
    9dcc:      	str	x2, [x16, #0x18]
    9dd0:      	add	x16, sp, #0x50
    9dd4:      	str	x3, [x16, #0x20]
    9dd8:      	ldr	x2, [x21]
    9ddc:      	ldr	x3, [x21, #0x8]
    9de0:      	add	x16, sp, #0x80
    9de4:      	movz	x17, #0x0, lsl #48
    9de8:      	str	x17, [x16]
    9dec:      	add	x16, sp, #0x80
    9df0:      	movz	x17, #0x0, lsl #48
    9df4:      	str	x17, [x16, #0x8]
    9df8:      	add	x16, sp, #0x80
    9dfc:      	movz	x17, #0x0, lsl #48
    9e00:      	str	x17, [x16, #0x10]
    9e04:      	add	x16, sp, #0x80
    9e08:      	str	x2, [x16, #0x18]
    9e0c:      	add	x16, sp, #0x80
    9e10:      	str	x3, [x16, #0x20]
    9e14:      	ldr	x2, [x21]
    9e18:      	ldr	x3, [x21, #0x8]
    9e1c:      	add	x16, sp, #0xb0
    9e20:      	movz	x17, #0x0, lsl #48
    9e24:      	str	x17, [x16]
    9e28:      	add	x16, sp, #0xb0
    9e2c:      	movz	x17, #0x0, lsl #48
    9e30:      	str	x17, [x16, #0x8]
    9e34:      	add	x16, sp, #0xb0
    9e38:      	movz	x17, #0x0, lsl #48
    9e3c:      	str	x17, [x16, #0x10]
    9e40:      	add	x16, sp, #0xb0
    9e44:      	str	x2, [x16, #0x18]
    9e48:      	add	x16, sp, #0xb0
    9e4c:      	str	x3, [x16, #0x20]
    9e50:      	ldr	x2, [x21]
    9e54:      	ldr	x3, [x21, #0x8]
    9e58:      	add	x16, sp, #0xe0
    9e5c:      	movz	x17, #0x0, lsl #48
    9e60:      	str	x17, [x16]
    9e64:      	add	x16, sp, #0xe0
    9e68:      	movz	x17, #0x0, lsl #48
    9e6c:      	str	x17, [x16, #0x8]
    9e70:      	add	x16, sp, #0xe0
    9e74:      	movz	x17, #0x0, lsl #48
    9e78:      	str	x17, [x16, #0x10]
    9e7c:      	add	x16, sp, #0xe0
    9e80:      	str	x2, [x16, #0x18]
    9e84:      	add	x16, sp, #0xe0
    9e88:      	str	x3, [x16, #0x20]
    9e8c:      	add	x8, sp, #0x140
    9e90:      	str	x1, [sp, #0x1d0]
    9e94:      	fmov	d31, x0
    9e98:      	mov	x0, x21
    9e9c:      	fmov	x21, d31
    9ea0:      	bl	0x9ea0 <_stogir.checked-schedule.cluster!+0x928>
		0000000000009ea0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    9ea4:      	add	x16, sp, #0x140
    9ea8:      	ldr	x0, [x16]
    9eac:      	add	x16, sp, #0x110
    9eb0:      	str	x0, [x16]
    9eb4:      	add	x16, sp, #0x140
    9eb8:      	ldr	x0, [x16, #0x8]
    9ebc:      	add	x16, sp, #0x110
    9ec0:      	str	x0, [x16, #0x8]
    9ec4:      	add	x16, sp, #0x140
    9ec8:      	ldr	x0, [x16, #0x10]
    9ecc:      	add	x16, sp, #0x110
    9ed0:      	str	x0, [x16, #0x10]
    9ed4:      	add	x16, sp, #0x140
    9ed8:      	ldr	x0, [x16, #0x18]
    9edc:      	add	x16, sp, #0x110
    9ee0:      	str	x0, [x16, #0x18]
    9ee4:      	add	x16, sp, #0x140
    9ee8:      	ldr	x0, [x16, #0x20]
    9eec:      	add	x16, sp, #0x110
    9ef0:      	str	x0, [x16, #0x20]
    9ef4:      	movz	x0, #0x0, lsl #48
    9ef8:      	b	0x9d48 <_stogir.checked-schedule.cluster!+0x7d0>
    9efc:      	add	x16, sp, #0x180
    9f00:      	ldr	w0, [x16, #0x8]
    9f04:      	sxtw	x0, w0
    9f08:      	cmp	x0, #0x0
    9f0c:      	b.eq	0x9794 <_stogir.checked-schedule.cluster!+0x21c>
    9f10:      	add	x16, sp, #0x170
    9f14:      	ldr	w0, [x16, #0x4]
    9f18:      	sxtw	x0, w0
    9f1c:      	add	x16, sp, #0x80
    9f20:      	ldr	x1, [x16]
    9f24:      	add	x1, x1, x0, lsl #2
    9f28:      	ldr	w1, [x1]
    9f2c:      	ldr	x2, [x28]
    9f30:      	orr	x3, x2, xzr
    9f34:      	add	x3, x3, x0, lsl #2
    9f38:      	add	x2, x2, x25, lsl #2
    9f3c:      	ldr	w3, [x3]
    9f40:      	ldr	w2, [x2]
    9f44:      	sxtw	x3, w3
    9f48:      	sxtw	x2, w2
    9f4c:      	cmp	x3, x2
    9f50:      	b.eq	0x9f60 <_stogir.checked-schedule.cluster!+0x9e8>
    9f54:      	adrp	x23, 0x9000 <_stogir.schedule.pack+0x78>
		0000000000009f54:  ARM64_RELOC_PAGE21	l_stogir.452
    9f58:      	ldr	x23, [x23]
		0000000000009f58:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9f5c:      	mov	x24, #0x30              ; =48
    9f60:      	sxtw	x1, w1
    9f64:      	cmp	x1, #0x0
    9f68:      	b.ne	0x9760 <_stogir.checked-schedule.cluster!+0x1e8>
    9f6c:      	add	x16, sp, #0x50
    9f70:      	ldr	x1, [x16]
    9f74:      	add	x1, x1, x0, lsl #2
    9f78:      	str	w21, [x1]
    9f7c:      	b	0x9770 <_stogir.checked-schedule.cluster!+0x1f8>
    9f80:      	brk	#0
    9f84:      	b	0x9f80 <_stogir.checked-schedule.cluster!+0xa08>
    9f88:      	brk	#0
    9f8c:      	b	0x9f88 <_stogir.checked-schedule.cluster!+0xa10>
    9f90:      	brk	#0
    9f94:      	b	0x9f90 <_stogir.checked-schedule.cluster!+0xa18>
    9f98:      	brk	#0
    9f9c:      	b	0x9f98 <_stogir.checked-schedule.cluster!+0xa20>
    9fa0:      	brk	#0
    9fa4:      	b	0x9fa0 <_stogir.checked-schedule.cluster!+0xa28>
    9fa8:      	brk	#0
    9fac:      	b	0x9fa8 <_stogir.checked-schedule.cluster!+0xa30>
    9fb0:      	mov	x26, x8
    9fb4:      	mov	x27, x0
    9fb8:      	mov	x28, x1
    9fbc:      	str	x20, [sp, #0x1c0]
    9fc0:      	mov	x20, x2
    9fc4:      	str	x21, [sp, #0x1c8]
    9fc8:      	mov	x21, x3
    9fcc:      	b	0x9604 <_stogir.checked-schedule.cluster!+0x8c>
    9fd0:      	str	x25, [sp, #0x200]
    9fd4:      	str	x21, [sp, #0x1f8]
    9fd8:      	str	x0, [sp, #0x1e8]
    9fdc:      	str	x1, [sp, #0x1f0]
    9fe0:      	b	0x9794 <_stogir.checked-schedule.cluster!+0x21c>
    9fe4:      	str	x19, [sp, #0x208]
    9fe8:      	mov	w19, w1
    9fec:      	str	x21, [sp, #0x210]
    9ff0:      	mov	x21, x0
    9ff4:      	str	x25, [sp, #0x218]
    9ff8:      	mov	x25, x2
    9ffc:      	b	0x9914 <_stogir.checked-schedule.cluster!+0x39c>
    a000:      	str	x19, [sp, #0x1d8]
    a004:      	str	x21, [sp, #0x1e0]
    a008:      	b	0x9bbc <_stogir.checked-schedule.cluster!+0x644>
    a00c:      	str	x19, [sp, #0x1d8]
    a010:      	mov	x19, x0
    a014:      	str	x21, [sp, #0x1e0]
    a018:      	mov	x21, x1
    a01c:      	b	0x9c04 <_stogir.checked-schedule.cluster!+0x68c>

000000000000a020 <_stogir.adjacency.release!>:
    a020:      	sub	sp, sp, #0x20
    a024:      	str	x29, [sp]
    a028:      	str	x30, [sp, #0x8]
    a02c:      	mov	x29, sp
    a030:      	str	x19, [sp, #0x10]
    a034:      	str	x20, [sp, #0x18]
    a038:      	b	0xa048 <_stogir.adjacency.release!+0x28>
    a03c:      	nop
    a040:      	sub	x1, x1, #0x1
    a044:      	str	x1, [x0, #0x8]
    a048:      	ldr	x1, [x0, #0x8]
    a04c:      	cmp	x1, #0x0
    a050:      	b.ne	0xa040 <_stogir.adjacency.release!+0x20>
    a054:      	ldr	x1, [x0, #0x10]
    a058:      	cmp	x1, #0x0
    a05c:      	b.le	0xa12c <_stogir.adjacency.release!+0x10c>
    a060:      	add	x2, x0, #0x18
    a064:      	ldr	x3, [x0]
    a068:      	mov	x19, x0
    a06c:      	mov	x0, x2
    a070:      	mov	x2, x1
    a074:      	mov	x1, x3
    a078:      	adrp	x3, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a078:  ARM64_RELOC_PAGE21	l_stogir.453
    a07c:      	ldr	x3, [x3]
		000000000000a07c:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    a080:      	mov	x4, #0x10               ; =16
    a084:      	mov	x5, #0x8                ; =8
    a088:      	bl	0xa088 <_stogir.adjacency.release!+0x68>
		000000000000a088:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a08c:      	add	x20, x19, #0x28
    a090:      	movz	x17, #0x0, lsl #48
    a094:      	str	x17, [x19]
    a098:      	movz	x17, #0x0, lsl #48
    a09c:      	str	x17, [x19, #0x8]
    a0a0:      	movz	x17, #0x0, lsl #48
    a0a4:      	str	x17, [x19, #0x10]
    a0a8:      	b	0xa0b8 <_stogir.adjacency.release!+0x98>
    a0ac:      	nop
    a0b0:      	sub	x0, x0, #0x1
    a0b4:      	str	x0, [x20, #0x8]
    a0b8:      	ldr	x0, [x20, #0x8]
    a0bc:      	cmp	x0, #0x0
    a0c0:      	b.ne	0xa0b0 <_stogir.adjacency.release!+0x90>
    a0c4:      	ldr	x0, [x20, #0x10]
    a0c8:      	cmp	x0, #0x0
    a0cc:      	b.le	0xa0fc <_stogir.adjacency.release!+0xdc>
    a0d0:      	add	x1, x20, #0x18
    a0d4:      	ldr	x2, [x19, #0x28]
    a0d8:      	fmov	d31, x0
    a0dc:      	mov	x0, x1
    a0e0:      	mov	x1, x2
    a0e4:      	fmov	x2, d31
    a0e8:      	adrp	x3, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a0e8:  ARM64_RELOC_PAGE21	l_stogir.454
    a0ec:      	ldr	x3, [x3]
		000000000000a0ec:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    a0f0:      	mov	x4, #0x8                ; =8
    a0f4:      	mov	x5, #0x8                ; =8
    a0f8:      	bl	0xa0f8 <_stogir.adjacency.release!+0xd8>
		000000000000a0f8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a0fc:      	movz	x17, #0x0, lsl #48
    a100:      	str	x17, [x19, #0x28]
    a104:      	movz	x17, #0x0, lsl #48
    a108:      	str	x17, [x20, #0x8]
    a10c:      	movz	x17, #0x0, lsl #48
    a110:      	str	x17, [x20, #0x10]
    a114:      	ldr	x19, [sp, #0x10]
    a118:      	ldr	x20, [sp, #0x18]
    a11c:      	ldr	x29, [sp]
    a120:      	ldr	x30, [sp, #0x8]
    a124:      	add	sp, sp, #0x20
    a128:      	ret
    a12c:      	mov	x19, x0
    a130:      	b	0xa08c <_stogir.adjacency.release!+0x6c>
    a134:      	udf	#0x0

000000000000a138 <_inherent$coil.arraylist.ArrayList$free!__bool>:
    a138:      	sub	sp, sp, #0x20
    a13c:      	str	x29, [sp]
    a140:      	str	x30, [sp, #0x8]
    a144:      	mov	x29, sp
    a148:      	str	x19, [sp, #0x10]
    a14c:      	b	0xa158 <_inherent$coil.arraylist.ArrayList$free!__bool+0x20>
    a150:      	sub	x1, x1, #0x1
    a154:      	str	x1, [x0, #0x8]
    a158:      	ldr	x1, [x0, #0x8]
    a15c:      	cmp	x1, #0x0
    a160:      	b.ne	0xa150 <_inherent$coil.arraylist.ArrayList$free!__bool+0x18>
    a164:      	ldr	x1, [x0, #0x10]
    a168:      	cmp	x1, #0x0
    a16c:      	b.le	0xa1cc <_inherent$coil.arraylist.ArrayList$free!__bool+0x94>
    a170:      	add	x2, x0, #0x18
    a174:      	ldr	x3, [x0]
    a178:      	mov	x19, x0
    a17c:      	mov	x0, x2
    a180:      	mov	x2, x1
    a184:      	mov	x1, x3
    a188:      	adrp	x3, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a188:  ARM64_RELOC_PAGE21	l_stogir.455
    a18c:      	ldr	x3, [x3]
		000000000000a18c:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    a190:      	mov	x4, #0x1                ; =1
    a194:      	mov	x5, #0x1                ; =1
    a198:      	bl	0xa198 <_inherent$coil.arraylist.ArrayList$free!__bool+0x60>
		000000000000a198:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a19c:      	movz	x17, #0x0, lsl #48
    a1a0:      	str	x17, [x19]
    a1a4:      	movz	x17, #0x0, lsl #48
    a1a8:      	str	x17, [x19, #0x8]
    a1ac:      	movz	x17, #0x0, lsl #48
    a1b0:      	str	x17, [x19, #0x10]
    a1b4:      	movz	x0, #0x0, lsl #48
    a1b8:      	ldr	x19, [sp, #0x10]
    a1bc:      	ldr	x29, [sp]
    a1c0:      	ldr	x30, [sp, #0x8]
    a1c4:      	add	sp, sp, #0x20
    a1c8:      	ret
    a1cc:      	mov	x19, x0
    a1d0:      	b	0xa19c <_inherent$coil.arraylist.ArrayList$free!__bool+0x64>
    a1d4:      	udf	#0x0

000000000000a1d8 <_stogir.uses.release!>:
    a1d8:      	sub	sp, sp, #0x20
    a1dc:      	str	x29, [sp]
    a1e0:      	str	x30, [sp, #0x8]
    a1e4:      	mov	x29, sp
    a1e8:      	str	x19, [sp, #0x10]
    a1ec:      	str	x20, [sp, #0x18]
    a1f0:      	b	0xa200 <_stogir.uses.release!+0x28>
    a1f4:      	nop
    a1f8:      	sub	x1, x1, #0x1
    a1fc:      	str	x1, [x0, #0x8]
    a200:      	ldr	x1, [x0, #0x8]
    a204:      	cmp	x1, #0x0
    a208:      	b.ne	0xa1f8 <_stogir.uses.release!+0x20>
    a20c:      	ldr	x1, [x0, #0x10]
    a210:      	cmp	x1, #0x0
    a214:      	b.le	0xa2e4 <_stogir.uses.release!+0x10c>
    a218:      	add	x2, x0, #0x18
    a21c:      	ldr	x3, [x0]
    a220:      	mov	x19, x0
    a224:      	mov	x0, x2
    a228:      	mov	x2, x1
    a22c:      	mov	x1, x3
    a230:      	adrp	x3, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a230:  ARM64_RELOC_PAGE21	l_stogir.456
    a234:      	ldr	x3, [x3]
		000000000000a234:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    a238:      	mov	x4, #0x10               ; =16
    a23c:      	mov	x5, #0x8                ; =8
    a240:      	bl	0xa240 <_stogir.uses.release!+0x68>
		000000000000a240:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a244:      	add	x20, x19, #0x28
    a248:      	movz	x17, #0x0, lsl #48
    a24c:      	str	x17, [x19]
    a250:      	movz	x17, #0x0, lsl #48
    a254:      	str	x17, [x19, #0x8]
    a258:      	movz	x17, #0x0, lsl #48
    a25c:      	str	x17, [x19, #0x10]
    a260:      	b	0xa270 <_stogir.uses.release!+0x98>
    a264:      	nop
    a268:      	sub	x0, x0, #0x1
    a26c:      	str	x0, [x20, #0x8]
    a270:      	ldr	x0, [x20, #0x8]
    a274:      	cmp	x0, #0x0
    a278:      	b.ne	0xa268 <_stogir.uses.release!+0x90>
    a27c:      	ldr	x0, [x20, #0x10]
    a280:      	cmp	x0, #0x0
    a284:      	b.le	0xa2b4 <_stogir.uses.release!+0xdc>
    a288:      	add	x1, x20, #0x18
    a28c:      	ldr	x2, [x19, #0x28]
    a290:      	fmov	d31, x0
    a294:      	mov	x0, x1
    a298:      	mov	x1, x2
    a29c:      	fmov	x2, d31
    a2a0:      	adrp	x3, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a2a0:  ARM64_RELOC_PAGE21	l_stogir.457
    a2a4:      	ldr	x3, [x3]
		000000000000a2a4:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    a2a8:      	mov	x4, #0x8                ; =8
    a2ac:      	mov	x5, #0x4                ; =4
    a2b0:      	bl	0xa2b0 <_stogir.uses.release!+0xd8>
		000000000000a2b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a2b4:      	movz	x17, #0x0, lsl #48
    a2b8:      	str	x17, [x19, #0x28]
    a2bc:      	movz	x17, #0x0, lsl #48
    a2c0:      	str	x17, [x20, #0x8]
    a2c4:      	movz	x17, #0x0, lsl #48
    a2c8:      	str	x17, [x20, #0x10]
    a2cc:      	ldr	x19, [sp, #0x10]
    a2d0:      	ldr	x20, [sp, #0x18]
    a2d4:      	ldr	x29, [sp]
    a2d8:      	ldr	x30, [sp, #0x8]
    a2dc:      	add	sp, sp, #0x20
    a2e0:      	ret
    a2e4:      	mov	x19, x0
    a2e8:      	b	0xa244 <_stogir.uses.release!+0x6c>
    a2ec:      	udf	#0x0

000000000000a2f0 <_stogir.verify.structure>:
    a2f0:      	sub	sp, sp, #0x110
    a2f4:      	str	x29, [sp, #0x10]
    a2f8:      	str	x30, [sp, #0x18]
    a2fc:      	add	x29, sp, #0x10
    a300:      	str	x19, [sp, #0xb8]
    a304:      	str	x20, [sp, #0xc0]
    a308:      	str	x21, [sp, #0xc8]
    a30c:      	str	x22, [sp, #0xd0]
    a310:      	str	x23, [sp, #0xd8]
    a314:      	str	x24, [sp, #0xe0]
    a318:      	str	x25, [sp, #0xe8]
    a31c:      	str	x26, [sp, #0xf0]
    a320:      	str	x27, [sp, #0xf8]
    a324:      	str	x28, [sp, #0x100]
    a328:      	add	x1, x0, #0x78
    a32c:      	ldr	x2, [x0, #0x8]
    a330:      	ldr	x1, [x1, #0x8]
    a334:      	cmp	x2, x1
    a338:      	b.ne	0xa368 <_stogir.verify.structure+0x78>
    a33c:      	adrp	x19, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a33c:  ARM64_RELOC_PAGE21	l_stogir.458
    a340:      	ldr	x19, [x19]
		000000000000a340:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    a344:      	movz	x20, #0x0, lsl #48
    a348:      	b	0xa374 <_stogir.verify.structure+0x84>
    a34c:      	ldr	x1, [sp, #0x88]
    a350:      	ldr	x5, [sp, #0x90]
    a354:      	add	x5, x1, x5
    a358:      	ldr	x20, [sp, #0x40]
    a35c:      	add	x1, x20, #0x1
    a360:      	sxtw	x20, w1
    a364:      	b	0xa3a8 <_stogir.verify.structure+0xb8>
    a368:      	adrp	x19, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a368:  ARM64_RELOC_PAGE21	l_stogir.459
    a36c:      	ldr	x19, [x19]
		000000000000a36c:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    a370:      	mov	x20, #0x2c              ; =44
    a374:      	add	x21, x0, #0x110
    a378:      	add	x22, x0, #0x78
    a37c:      	add	x23, x0, #0x28
    a380:      	add	x24, x0, #0x50
    a384:      	add	x25, x21, #0x28
    a388:      	mov	x26, #0x1               ; =1
    a38c:      	movz	x27, #0x0, lsl #48
    a390:      	b	0xa40c <_stogir.verify.structure+0x11c>
    a394:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a394:  ARM64_RELOC_PAGE21	l_stogir.460
    a398:      	ldr	x16, [x16]
		000000000000a398:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    a39c:      	str	x16, [sp, #0x38]
    a3a0:      	mov	x16, #0x16              ; =22
    a3a4:      	str	x16, [sp, #0x80]
    a3a8:      	b	0xa3e4 <_stogir.verify.structure+0xf4>
    a3ac:      	nop
    a3b0:      	mov	x5, x26
    a3b4:      	mov	x20, x27
    a3b8:      	str	x8, [sp, #0x30]
    a3bc:      	mov	x19, x0
    a3c0:      	mov	x2, x21
    a3c4:      	mov	x0, x22
    a3c8:      	mov	x3, x23
    a3cc:      	mov	x4, x24
    a3d0:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a3d0:  ARM64_RELOC_PAGE21	l_stogir.461
    a3d4:      	ldr	x16, [x16]
		000000000000a3d4:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    a3d8:      	str	x16, [sp, #0x38]
    a3dc:      	mov	x16, #0x23              ; =35
    a3e0:      	str	x16, [sp, #0x80]
    a3e4:      	ldr	x8, [sp, #0x30]
    a3e8:      	mov	x21, x2
    a3ec:      	mov	x22, x0
    a3f0:      	mov	x0, x19
    a3f4:      	mov	x23, x3
    a3f8:      	mov	x24, x4
    a3fc:      	mov	x26, x5
    a400:      	mov	x27, x20
    a404:      	ldr	x19, [sp, #0x38]
    a408:      	ldr	x20, [sp, #0x80]
    a40c:      	cmp	x20, #0x0
    a410:      	b.ne	0xabcc <_stogir.verify.structure+0x8dc>
    a414:      	ldr	x1, [x0, #0x8]
    a418:      	cmp	x26, x1
    a41c:      	b.ge	0xabe0 <_stogir.verify.structure+0x8f0>
    a420:      	ldr	x1, [x0]
    a424:      	add	x1, x1, x26, lsl #4
    a428:      	ldr	x1, [x1]
    a42c:      	ldr	x2, [x0, #0x78]
    a430:      	add	x2, x2, x26, lsl #2
    a434:      	ldr	w2, [x2]
    a438:      	sxtw	x28, w2
    a43c:      	cmp	x28, #0x0
    a440:      	b.lt	0xa3b0 <_stogir.verify.structure+0xc0>
    a444:      	mov	x17, #0xffff            ; =65535
    a448:      	cmp	x28, x17
    a44c:      	b.gt	0xabf4 <_stogir.verify.structure+0x904>
    a450:      	uxtb	w2, w1
    a454:      	orr	x3, x2, xzr
    a458:      	cmp	x3, #0x83
    a45c:      	cset	w4, lt
    a460:      	uxtb	w16, w4
    a464:      	cmp	w16, wzr
    a468:      	b.eq	0xac18 <_stogir.verify.structure+0x928>
    a46c:      	ubfx	x1, x1, #0, #32
    a470:      	ubfx	x5, x1, #8, #8
    a474:      	orr	x6, x5, xzr
    a478:      	str	x8, [sp, #0x30]
    a47c:      	str	x19, [sp, #0x38]
    a480:      	mov	x19, x0
    a484:      	mov	w0, w6
    a488:      	str	x27, [sp, #0x40]
    a48c:      	mov	w27, w2
    a490:      	str	x24, [sp, #0x48]
    a494:      	mov	x24, x3
    a498:      	str	x23, [sp, #0x50]
    a49c:      	mov	w23, w4
    a4a0:      	str	x22, [sp, #0x58]
    a4a4:      	mov	x22, x1
    a4a8:      	str	x21, [sp, #0x60]
    a4ac:      	mov	w21, w5
    a4b0:      	bl	0xa4b0 <_stogir.verify.structure+0x1c0>
		000000000000a4b0:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    a4b4:      	cmp	x0, #0x0
    a4b8:      	b.eq	0xac3c <_stogir.verify.structure+0x94c>
    a4bc:      	adrp	x17, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a4bc:  ARM64_RELOC_PAGE21	l_stogir.462
    a4c0:      	ldr	x17, [x17]
		000000000000a4c0:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    a4c4:      	add	x0, x24, x17
    a4c8:      	ldrsb	w0, [x0]
    a4cc:      	sxtb	x0, w0
    a4d0:      	cmp	x0, #0x0
    a4d4:      	b.lt	0xa8ec <_stogir.verify.structure+0x5fc>
    a4d8:      	uxtb	w16, w23
    a4dc:      	cmp	w16, wzr
    a4e0:      	b.eq	0xa9c0 <_stogir.verify.structure+0x6d0>
    a4e4:      	adrp	x17, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a4e4:  ARM64_RELOC_PAGE21	l_stogir.462
    a4e8:      	ldr	x17, [x17]
		000000000000a4e8:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    a4ec:      	add	x0, x24, x17
    a4f0:      	ldrsb	w0, [x0]
    a4f4:      	sxtb	w0, w0
    a4f8:      	b	0xa9c4 <_stogir.verify.structure+0x6d4>
    a4fc:      	ldr	x0, [sp, #0x38]
    a500:      	ldr	x1, [sp, #0x80]
    a504:      	adrp	x2, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a504:  ARM64_RELOC_PAGE21	l_stogir.458
    a508:      	ldr	x2, [x2]
		000000000000a508:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    a50c:      	movz	x3, #0x0, lsl #48
    a510:      	bl	0xa510 <_stogir.verify.structure+0x220>
		000000000000a510:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    a514:      	cmp	x0, #0x0
    a518:      	b.eq	0xac58 <_stogir.verify.structure+0x968>
    a51c:      	and	x0, x20, #0xffffffff
    a520:      	movz	x1, #0x0, lsl #48
    a524:      	movz	x16, #0x0, lsl #48
    a528:      	str	x16, [sp, #0x80]
    a52c:      	b	0xa534 <_stogir.verify.structure+0x244>
    a530:      	mov	x1, #0x1                ; =1
    a534:      	ldr	x2, [sp, #0x30]
    a538:      	str	x1, [x2]
    a53c:      	str	x0, [x2, #0x8]
    a540:      	ldr	x0, [sp, #0x80]
    a544:      	str	x0, [x2, #0x10]
    a548:      	ldr	x19, [sp, #0xb8]
    a54c:      	ldr	x20, [sp, #0xc0]
    a550:      	ldr	x21, [sp, #0xc8]
    a554:      	ldr	x22, [sp, #0xd0]
    a558:      	ldr	x23, [sp, #0xd8]
    a55c:      	ldr	x24, [sp, #0xe0]
    a560:      	ldr	x25, [sp, #0xe8]
    a564:      	ldr	x26, [sp, #0xf0]
    a568:      	ldr	x27, [sp, #0xf8]
    a56c:      	ldr	x28, [sp, #0x100]
    a570:      	ldr	x29, [sp, #0x10]
    a574:      	ldr	x30, [sp, #0x18]
    a578:      	add	sp, sp, #0x110
    a57c:      	ret
    a580:      	mov	w9, w5
    a584:      	lsl	w9, w9, #2
    a588:      	ubfx	x9, x9, #0, #32
    a58c:      	lsr	x8, x8, x9
    a590:      	and	w8, w8, #0xf
    a594:      	b	0xa5b4 <_stogir.verify.structure+0x2c4>
    a598:      	movz	x1, #0x0, lsl #48
    a59c:      	cmp	x1, #0x0
    a5a0:      	b.eq	0xaa00 <_stogir.verify.structure+0x710>
    a5a4:      	ldr	w1, [sp, #0xb0]
    a5a8:      	ldr	w5, [sp, #0xa8]
    a5ac:      	b	0xa65c <_stogir.verify.structure+0x36c>
    a5b0:      	movz	w8, #0x0, lsl #16
    a5b4:      	b	0xa5bc <_stogir.verify.structure+0x2cc>
    a5b8:      	movz	w8, #0x0, lsl #16
    a5bc:      	str	w0, [sp, #0x68]
    a5c0:      	str	x2, [sp, #0x98]
    a5c4:      	mov	w2, w3
    a5c8:      	str	x4, [sp, #0xa0]
    a5cc:      	str	x24, [sp, #0x70]
    a5d0:      	mov	x24, x1
    a5d4:      	mov	w1, w0
    a5d8:      	mov	x0, x19
    a5dc:      	str	x28, [sp, #0x78]
    a5e0:      	mov	w28, w7
    a5e4:      	str	x20, [sp, #0x80]
    a5e8:      	mov	w20, w8
    a5ec:      	str	x22, [sp, #0x88]
    a5f0:      	mov	w22, w5
    a5f4:      	str	x26, [sp, #0x90]
    a5f8:      	mov	w26, w6
    a5fc:      	bl	0xa5fc <_stogir.verify.structure+0x30c>
		000000000000a5fc:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    a600:      	ubfx	x0, x0, #0, #32
    a604:      	lsr	x16, x0, #0
    a608:      	cmp	x16, #0x1
    a60c:      	b.eq	0xa628 <_stogir.verify.structure+0x338>
    a610:      	b.lo	0xa618 <_stogir.verify.structure+0x328>
    a614:      	b	0xa62c <_stogir.verify.structure+0x33c>
    a618:      	cmp	x16, #0x0
    a61c:      	b.eq	0xa624 <_stogir.verify.structure+0x334>
    a620:      	b	0xa62c <_stogir.verify.structure+0x33c>
    a624:      	b	0xa630 <_stogir.verify.structure+0x340>
    a628:      	b	0xa710 <_stogir.verify.structure+0x420>
    a62c:      	b	0xab34 <_stogir.verify.structure+0x844>
    a630:      	ldr	x2, [sp, #0x60]
    a634:      	ldr	x0, [sp, #0x58]
    a638:      	ldr	x3, [sp, #0x50]
    a63c:      	ldr	x4, [sp, #0x48]
    a640:      	mov	w1, w27
    a644:      	mov	w5, w21
    a648:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a648:  ARM64_RELOC_PAGE21	l_stogir.463
    a64c:      	ldr	x16, [x16]
		000000000000a64c:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    a650:      	str	x16, [sp, #0x38]
    a654:      	mov	x16, #0x17              ; =23
    a658:      	str	x16, [sp, #0x80]
    a65c:      	ldr	x6, [sp, #0x98]
    a660:      	add	x6, x6, #0x1
    a664:      	sxtw	x6, w6
    a668:      	ldr	x26, [sp, #0x90]
    a66c:      	ldr	x28, [sp, #0x78]
    a670:      	ldr	x22, [sp, #0x88]
    a674:      	str	x2, [sp, #0x60]
    a678:      	str	x0, [sp, #0x58]
    a67c:      	ldr	w0, [sp, #0x68]
    a680:      	str	x3, [sp, #0x50]
    a684:      	str	x4, [sp, #0x48]
    a688:      	mov	w27, w1
    a68c:      	mov	w21, w5
    a690:      	mov	x1, x24
    a694:      	ldr	x24, [sp, #0x70]
    a698:      	mov	x2, x6
    a69c:      	ldr	x20, [sp, #0x80]
    a6a0:      	cmp	x20, #0x0
    a6a4:      	b.ne	0xa6b8 <_stogir.verify.structure+0x3c8>
    a6a8:      	cmp	x2, x28
    a6ac:      	cset	w3, le
    a6b0:      	ubfx	x3, x3, #0, #8
    a6b4:      	b	0xa6bc <_stogir.verify.structure+0x3cc>
    a6b8:      	movz	x3, #0x0, lsl #48
    a6bc:      	cmp	x3, #0x0
    a6c0:      	b.eq	0xac60 <_stogir.verify.structure+0x970>
    a6c4:      	orr	w3, w2, wzr
    a6c8:      	sxtw	x4, w3
    a6cc:      	sub	w5, w3, #0x1
    a6d0:      	cmp	x4, #0x0
    a6d4:      	cset	w6, gt
    a6d8:      	cmp	x4, #0x4
    a6dc:      	cset	w7, gt
    a6e0:      	uxtb	w16, w23
    a6e4:      	cmp	w16, wzr
    a6e8:      	b.eq	0xa5b8 <_stogir.verify.structure+0x2c8>
    a6ec:      	ldr	w8, [x24]
    a6f0:      	uxtb	w16, w6
    a6f4:      	cmp	w16, wzr
    a6f8:      	b.eq	0xa5b0 <_stogir.verify.structure+0x2c0>
    a6fc:      	uxtb	w16, w7
    a700:      	cmp	w16, wzr
    a704:      	b.eq	0xa580 <_stogir.verify.structure+0x290>
    a708:      	mov	w9, #0x4                ; =4
    a70c:      	b	0xa584 <_stogir.verify.structure+0x294>
    a710:      	ubfx	x20, x20, #0, #32
    a714:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a714:  ARM64_RELOC_PAGE21	l_stogir.464
    a718:      	ldr	x16, [x16]
		000000000000a718:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    a71c:      	ldr	w0, [x16]
    a720:      	cmp	x20, x0
    a724:      	b.ne	0xa738 <_stogir.verify.structure+0x448>
    a728:      	mov	x0, #0x1                ; =1
    a72c:      	b	0xa750 <_stogir.verify.structure+0x460>
    a730:      	movz	x1, #0x0, lsl #48
    a734:      	b	0xa7b0 <_stogir.verify.structure+0x4c0>
    a738:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a738:  ARM64_RELOC_PAGE21	l_stogir.465
    a73c:      	ldr	x16, [x16]
		000000000000a73c:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    a740:      	ldr	w0, [x16]
    a744:      	cmp	x20, x0
    a748:      	cset	w0, eq
    a74c:      	ubfx	x0, x0, #0, #8
    a750:      	cmp	x0, #0x0
    a754:      	b.eq	0xac80 <_stogir.verify.structure+0x990>
    a758:      	str	w21, [sp, #0xa8]
    a75c:      	mov	x21, x0
    a760:      	mov	x0, x19
    a764:      	str	w27, [sp, #0xb0]
    a768:      	mov	w27, w1
    a76c:      	bl	0xa76c <_stogir.verify.structure+0x47c>
		000000000000a76c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    a770:      	cmp	x0, #0x0
    a774:      	cset	w1, eq
    a778:      	uxtb	w16, w1
    a77c:      	cmp	w16, wzr
    a780:      	cset	x1, eq
    a784:      	cmp	x1, #0x0
    a788:      	b.eq	0xa7b0 <_stogir.verify.structure+0x4c0>
    a78c:      	ldr	w0, [x0]
    a790:      	uxtb	w0, w0
    a794:      	cmp	x0, #0x48
    a798:      	b.ne	0xa7b0 <_stogir.verify.structure+0x4c0>
    a79c:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a79c:  ARM64_RELOC_PAGE21	l_stogir.466
    a7a0:      	ldr	x16, [x16]
		000000000000a7a0:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    a7a4:      	str	x16, [sp, #0x38]
    a7a8:      	mov	x16, #0x25              ; =37
    a7ac:      	str	x16, [sp, #0x80]
    a7b0:      	sxtw	x27, w27
    a7b4:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a7b4:  ARM64_RELOC_PAGE21	l_stogir.467
    a7b8:      	ldr	x16, [x16]
		000000000000a7b8:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    a7bc:      	ldr	w0, [x16]
    a7c0:      	cmp	x20, x0
    a7c4:      	b.ne	0xac94 <_stogir.verify.structure+0x9a4>
    a7c8:      	cmp	x27, #0x0
    a7cc:      	b.gt	0xa95c <_stogir.verify.structure+0x66c>
    a7d0:      	ldr	x2, [sp, #0x60]
    a7d4:      	movz	w0, #0x0, lsl #16
    a7d8:      	ubfx	x0, x0, #0, #32
    a7dc:      	lsr	x16, x0, #0
    a7e0:      	cmp	x16, #0x1
    a7e4:      	b.eq	0xa800 <_stogir.verify.structure+0x510>
    a7e8:      	b.lo	0xa7f0 <_stogir.verify.structure+0x500>
    a7ec:      	b	0xa804 <_stogir.verify.structure+0x514>
    a7f0:      	cmp	x16, #0x0
    a7f4:      	b.eq	0xa7fc <_stogir.verify.structure+0x50c>
    a7f8:      	b	0xa804 <_stogir.verify.structure+0x514>
    a7fc:      	b	0xa808 <_stogir.verify.structure+0x518>
    a800:      	b	0xa81c <_stogir.verify.structure+0x52c>
    a804:      	b	0xabc4 <_stogir.verify.structure+0x8d4>
    a808:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a808:  ARM64_RELOC_PAGE21	l_stogir.468
    a80c:      	ldr	x16, [x16]
		000000000000a80c:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    a810:      	str	x16, [sp, #0x38]
    a814:      	mov	x16, #0x21              ; =33
    a818:      	str	x16, [sp, #0x80]
    a81c:      	cmp	x20, #0xf
    a820:      	b.hs	0xac9c <_stogir.verify.structure+0x9ac>
    a824:      	mov	x16, #0x1               ; =1
    a828:      	lsl	x0, x16, x20
    a82c:      	mov	w17, #0x5e1c            ; =24092
    a830:      	and	w0, w0, w17
    a834:      	ubfx	x0, x0, #0, #32
    a838:      	cmp	x0, #0x0
    a83c:      	b.eq	0xacb4 <_stogir.verify.structure+0x9c4>
    a840:      	cmp	x21, #0x0
    a844:      	b.eq	0xaa48 <_stogir.verify.structure+0x758>
    a848:      	ldr	x0, [sp, #0x58]
    a84c:      	ldr	x3, [sp, #0x50]
    a850:      	ldr	x4, [sp, #0x48]
    a854:      	b	0xa59c <_stogir.verify.structure+0x2ac>
    a858:      	orr	w0, w26, wzr
    a85c:      	cmp	x24, #0x78
    a860:      	cset	w27, eq
    a864:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a864:  ARM64_RELOC_PAGE21	l_stogir.469
    a868:      	ldr	x16, [x16]
		000000000000a868:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a86c:      	add	x1, x16, x24, lsl #2
    a870:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a870:  ARM64_RELOC_PAGE21	l_stogir.469
    a874:      	ldr	x16, [x16]
		000000000000a874:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a878:      	add	x2, x16, x24, lsl #2
    a87c:      	cmp	x21, #0x0
    a880:      	cset	w21, eq
    a884:      	orr	x24, x1, xzr
    a888:      	orr	x1, x2, xzr
    a88c:      	mov	x2, #0x1                ; =1
    a890:      	b	0xa6a0 <_stogir.verify.structure+0x3b0>
    a894:      	nop
    a898:      	movz	x1, #0x0, lsl #48
    a89c:      	cmp	x1, #0x0
    a8a0:      	b.eq	0xa858 <_stogir.verify.structure+0x568>
    a8a4:      	add	x1, x0, x26
    a8a8:      	ldr	x2, [x19, #0x78]
    a8ac:      	add	x1, x2, x1, lsl #2
    a8b0:      	ldr	w1, [x1]
    a8b4:      	sxtw	x1, w1
    a8b8:      	cmn	x1, #0x1
    a8bc:      	b.eq	0xa8d0 <_stogir.verify.structure+0x5e0>
    a8c0:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a8c0:  ARM64_RELOC_PAGE21	l_stogir.470
    a8c4:      	ldr	x16, [x16]
		000000000000a8c4:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    a8c8:      	str	x16, [sp, #0x38]
    a8cc:      	mov	x20, #0x1b              ; =27
    a8d0:      	add	x0, x0, #0x1
    a8d4:      	cmp	x20, #0x0
    a8d8:      	b.ne	0xa898 <_stogir.verify.structure+0x5a8>
    a8dc:      	cmp	x0, x22
    a8e0:      	cset	w1, lt
    a8e4:      	ubfx	x1, x1, #0, #8
    a8e8:      	b	0xa89c <_stogir.verify.structure+0x5ac>
    a8ec:      	mov	w0, w27
    a8f0:      	bl	0xa8f0 <_stogir.verify.structure+0x600>
		000000000000a8f0:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
    a8f4:      	sxtw	x0, w0
    a8f8:      	cmn	x0, #0x1
    a8fc:      	b.ne	0xa91c <_stogir.verify.structure+0x62c>
    a900:      	ubfx	x0, x22, #16, #16
    a904:      	cmp	x28, x0
    a908:      	b.eq	0xa91c <_stogir.verify.structure+0x62c>
    a90c:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a90c:  ARM64_RELOC_PAGE21	l_stogir.471
    a910:      	ldr	x16, [x16]
		000000000000a910:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    a914:      	str	x16, [sp, #0x38]
    a918:      	mov	x20, #0x24              ; =36
    a91c:      	add	x0, x28, #0x4
    a920:      	ldr	x1, [x19, #0x8]
    a924:      	asr	x16, x0, #63
    a928:      	lsr	x16, x16, #62
    a92c:      	add	x0, x0, x16
    a930:      	asr	x0, x0, #2
    a934:      	orr	x22, x0, xzr
    a938:      	add	x0, x22, x26
    a93c:      	cmp	x0, x1
    a940:      	b.le	0xa954 <_stogir.verify.structure+0x664>
    a944:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a944:  ARM64_RELOC_PAGE21	l_stogir.472
    a948:      	ldr	x16, [x16]
		000000000000a948:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    a94c:      	str	x16, [sp, #0x38]
    a950:      	mov	x20, #0x15              ; =21
    a954:      	mov	x0, #0x1                ; =1
    a958:      	b	0xa8d4 <_stogir.verify.structure+0x5e4>
    a95c:      	ldr	x0, [x25, #0x8]
    a960:      	cmp	x27, x0
    a964:      	b.gt	0xaccc <_stogir.verify.structure+0x9dc>
    a968:      	sub	x0, x27, #0x1
    a96c:      	ldr	x2, [sp, #0x60]
    a970:      	ldr	x3, [x2, #0x28]
    a974:      	mov	x17, #0x18              ; =24
    a978:      	mul	x0, x0, x17
    a97c:      	add	x0, x0, x3
    a980:      	ldr	x3, [x0]
    a984:      	ldr	x0, [x0, #0x8]
    a988:      	ldr	x4, [x2, #0x8]
    a98c:      	cmp	x3, #0x0
    a990:      	b.lt	0xa9b8 <_stogir.verify.structure+0x6c8>
    a994:      	cmp	x3, x4
    a998:      	b.gt	0xa9b8 <_stogir.verify.structure+0x6c8>
    a99c:      	cmp	x0, #0x0
    a9a0:      	b.lt	0xa9b8 <_stogir.verify.structure+0x6c8>
    a9a4:      	sub	x3, x4, x3
    a9a8:      	cmp	x0, x3
    a9ac:      	b.gt	0xa9b8 <_stogir.verify.structure+0x6c8>
    a9b0:      	mov	w0, #0x1                ; =1
    a9b4:      	b	0xa9bc <_stogir.verify.structure+0x6cc>
    a9b8:      	movz	w0, #0x0, lsl #16
    a9bc:      	b	0xa7d8 <_stogir.verify.structure+0x4e8>
    a9c0:      	mov	w0, #-0x2               ; =-2
    a9c4:      	sxtw	x0, w0
    a9c8:      	cmp	x28, x0
    a9cc:      	b.eq	0xa8ec <_stogir.verify.structure+0x5fc>
    a9d0:      	ldr	x2, [sp, #0x60]
    a9d4:      	ldr	x0, [sp, #0x58]
    a9d8:      	ldr	x3, [sp, #0x50]
    a9dc:      	ldr	x4, [sp, #0x48]
    a9e0:      	mov	x5, x26
    a9e4:      	ldr	x20, [sp, #0x40]
    a9e8:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000a9e8:  ARM64_RELOC_PAGE21	l_stogir.473
    a9ec:      	ldr	x16, [x16]
		000000000000a9ec:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    a9f0:      	str	x16, [sp, #0x38]
    a9f4:      	mov	x16, #0x23              ; =35
    a9f8:      	str	x16, [sp, #0x80]
    a9fc:      	b	0xa364 <_stogir.verify.structure+0x74>
    aa00:      	cmp	x27, #0x0
    aa04:      	b.ne	0xacd4 <_stogir.verify.structure+0x9e4>
    aa08:      	uxtb	w16, w23
    aa0c:      	cmp	w16, wzr
    aa10:      	b.eq	0xab3c <_stogir.verify.structure+0x84c>
    aa14:      	ldr	w1, [x24]
    aa18:      	uxtb	w16, w26
    aa1c:      	cmp	w16, wzr
    aa20:      	b.eq	0xab84 <_stogir.verify.structure+0x894>
    aa24:      	uxtb	w16, w28
    aa28:      	cmp	w16, wzr
    aa2c:      	b.eq	0xaa34 <_stogir.verify.structure+0x744>
    aa30:      	mov	w22, #0x4               ; =4
    aa34:      	lsl	w5, w22, #2
    aa38:      	ubfx	x5, x5, #0, #32
    aa3c:      	lsr	x1, x1, x5
    aa40:      	and	w1, w1, #0xf
    aa44:      	b	0xab88 <_stogir.verify.structure+0x898>
    aa48:      	cmp	x27, #0x0
    aa4c:      	b.le	0xace0 <_stogir.verify.structure+0x9f0>
    aa50:      	ldr	x0, [x19, #0x8]
    aa54:      	cmp	x27, x0
    aa58:      	b.ge	0xace8 <_stogir.verify.structure+0x9f8>
    aa5c:      	ldr	x0, [sp, #0x58]
    aa60:      	ldr	x1, [x0, #0x8]
    aa64:      	cmp	x27, x1
    aa68:      	b.ge	0xab94 <_stogir.verify.structure+0x8a4>
    aa6c:      	ldr	x1, [x19, #0x78]
    aa70:      	add	x1, x1, x27, lsl #2
    aa74:      	ldr	w1, [x1]
    aa78:      	sxtw	x1, w1
    aa7c:      	cmp	x1, #0x0
    aa80:      	cset	w1, ge
    aa84:      	ubfx	x1, x1, #0, #8
    aa88:      	b	0xab98 <_stogir.verify.structure+0x8a8>
    aa8c:      	ldr	w1, [sp, #0xb0]
    aa90:      	uxtb	w16, w1
    aa94:      	cmp	w16, wzr
    aa98:      	b.eq	0xacf0 <_stogir.verify.structure+0xa00>
    aa9c:      	ldr	w5, [sp, #0xa8]
    aaa0:      	uxtb	w16, w5
    aaa4:      	cmp	w16, wzr
    aaa8:      	b.eq	0xaab8 <_stogir.verify.structure+0x7c8>
    aaac:      	ldr	x6, [sp, #0xa0]
    aab0:      	cmp	x6, #0x2
    aab4:      	b.eq	0xa5ac <_stogir.verify.structure+0x2bc>
    aab8:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000aab8:  ARM64_RELOC_PAGE21	l_stogir.474
    aabc:      	ldr	x16, [x16]
		000000000000aabc:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    aac0:      	str	x16, [sp, #0x38]
    aac4:      	mov	x16, #0x1a              ; =26
    aac8:      	str	x16, [sp, #0x80]
    aacc:      	b	0xa5ac <_stogir.verify.structure+0x2bc>
    aad0:      	movz	x1, #0x0, lsl #48
    aad4:      	ldr	x3, [sp, #0x50]
    aad8:      	ldr	x4, [sp, #0x48]
    aadc:      	b	0xa59c <_stogir.verify.structure+0x2ac>
    aae0:      	cmp	x27, #0x0
    aae4:      	b.ge	0xacf8 <_stogir.verify.structure+0xa08>
    aae8:      	ldr	x3, [sp, #0x50]
    aaec:      	ldr	x1, [x3, #0x8]
    aaf0:      	ldr	x4, [sp, #0x48]
    aaf4:      	ldr	x5, [x4, #0x8]
    aaf8:      	cmp	x1, x5
    aafc:      	b.ne	0xab8c <_stogir.verify.structure+0x89c>
    ab00:      	movz	x16, #0x0, lsl #48
    ab04:      	sub	x5, x16, x27
    ab08:      	cmp	x5, x1
    ab0c:      	b.gt	0xabbc <_stogir.verify.structure+0x8cc>
    ab10:      	sub	x1, x5, #0x1
    ab14:      	ldr	x5, [x19, #0x50]
    ab18:      	add	x1, x5, x1, lsl #2
    ab1c:      	ldr	w1, [x1]
    ab20:      	sxtw	x1, w1
    ab24:      	cmp	x1, #0x0
    ab28:      	cset	w1, gt
    ab2c:      	ubfx	x1, x1, #0, #8
    ab30:      	b	0xabc0 <_stogir.verify.structure+0x8d0>
    ab34:      	brk	#0
    ab38:      	b	0xab34 <_stogir.verify.structure+0x844>
    ab3c:      	movz	w1, #0x0, lsl #16
    ab40:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000ab40:  ARM64_RELOC_PAGE21	l_stogir.475
    ab44:      	ldr	x16, [x16]
		000000000000ab44:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    ab48:      	ldr	w5, [x16]
    ab4c:      	ubfx	x1, x1, #0, #32
    ab50:      	cmp	x1, x5
    ab54:      	b.ne	0xab64 <_stogir.verify.structure+0x874>
    ab58:      	ldr	w1, [sp, #0xb0]
    ab5c:      	ldr	w5, [sp, #0xa8]
    ab60:      	b	0xa5ac <_stogir.verify.structure+0x2bc>
    ab64:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000ab64:  ARM64_RELOC_PAGE21	l_stogir.476
    ab68:      	ldr	x16, [x16]
		000000000000ab68:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    ab6c:      	ldr	w5, [x16]
    ab70:      	cmp	x1, x5
    ab74:      	b.ne	0xab9c <_stogir.verify.structure+0x8ac>
    ab78:      	ldr	w1, [sp, #0xb0]
    ab7c:      	ldr	w5, [sp, #0xa8]
    ab80:      	b	0xa5ac <_stogir.verify.structure+0x2bc>
    ab84:      	movz	w1, #0x0, lsl #16
    ab88:      	b	0xab40 <_stogir.verify.structure+0x850>
    ab8c:      	movz	x1, #0x0, lsl #48
    ab90:      	b	0xa59c <_stogir.verify.structure+0x2ac>
    ab94:      	movz	x1, #0x0, lsl #48
    ab98:      	b	0xaad4 <_stogir.verify.structure+0x7e4>
    ab9c:      	adrp	x16, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000ab9c:  ARM64_RELOC_PAGE21	l_stogir.477
    aba0:      	ldr	x16, [x16]
		000000000000aba0:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    aba4:      	ldr	w5, [x16]
    aba8:      	cmp	x1, x5
    abac:      	b.ne	0xaa8c <_stogir.verify.structure+0x79c>
    abb0:      	ldr	w1, [sp, #0xb0]
    abb4:      	ldr	w5, [sp, #0xa8]
    abb8:      	b	0xa5ac <_stogir.verify.structure+0x2bc>
    abbc:      	movz	x1, #0x0, lsl #48
    abc0:      	b	0xab90 <_stogir.verify.structure+0x8a0>
    abc4:      	brk	#0
    abc8:      	b	0xabc4 <_stogir.verify.structure+0x8d4>
    abcc:      	str	x8, [sp, #0x30]
    abd0:      	str	x19, [sp, #0x38]
    abd4:      	str	x20, [sp, #0x80]
    abd8:      	mov	x20, x27
    abdc:      	b	0xa4fc <_stogir.verify.structure+0x20c>
    abe0:      	str	x8, [sp, #0x30]
    abe4:      	str	x19, [sp, #0x38]
    abe8:      	str	x20, [sp, #0x80]
    abec:      	mov	x20, x27
    abf0:      	b	0xa4fc <_stogir.verify.structure+0x20c>
    abf4:      	mov	x5, x26
    abf8:      	mov	x20, x27
    abfc:      	str	x8, [sp, #0x30]
    ac00:      	mov	x19, x0
    ac04:      	mov	x2, x21
    ac08:      	mov	x0, x22
    ac0c:      	mov	x3, x23
    ac10:      	mov	x4, x24
    ac14:      	b	0xa3d0 <_stogir.verify.structure+0xe0>
    ac18:      	mov	x5, x26
    ac1c:      	mov	x20, x27
    ac20:      	str	x8, [sp, #0x30]
    ac24:      	mov	x19, x0
    ac28:      	mov	x2, x21
    ac2c:      	mov	x0, x22
    ac30:      	mov	x3, x23
    ac34:      	mov	x4, x24
    ac38:      	b	0xa394 <_stogir.verify.structure+0xa4>
    ac3c:      	mov	x5, x26
    ac40:      	ldr	x20, [sp, #0x40]
    ac44:      	ldr	x2, [sp, #0x60]
    ac48:      	ldr	x0, [sp, #0x58]
    ac4c:      	ldr	x3, [sp, #0x50]
    ac50:      	ldr	x4, [sp, #0x48]
    ac54:      	b	0xa394 <_stogir.verify.structure+0xa4>
    ac58:      	ldr	x0, [sp, #0x38]
    ac5c:      	b	0xa530 <_stogir.verify.structure+0x240>
    ac60:      	str	x26, [sp, #0x90]
    ac64:      	str	x22, [sp, #0x88]
    ac68:      	ldr	x2, [sp, #0x60]
    ac6c:      	str	x20, [sp, #0x80]
    ac70:      	ldr	x0, [sp, #0x58]
    ac74:      	ldr	x3, [sp, #0x50]
    ac78:      	ldr	x4, [sp, #0x48]
    ac7c:      	b	0xa34c <_stogir.verify.structure+0x5c>
    ac80:      	str	w27, [sp, #0xb0]
    ac84:      	mov	w27, w1
    ac88:      	str	w21, [sp, #0xa8]
    ac8c:      	mov	x21, x0
    ac90:      	b	0xa730 <_stogir.verify.structure+0x440>
    ac94:      	ldr	x2, [sp, #0x60]
    ac98:      	b	0xa81c <_stogir.verify.structure+0x52c>
    ac9c:      	ldr	x0, [sp, #0x58]
    aca0:      	ldr	x3, [sp, #0x50]
    aca4:      	ldr	x4, [sp, #0x48]
    aca8:      	ldr	w1, [sp, #0xb0]
    acac:      	ldr	w5, [sp, #0xa8]
    acb0:      	b	0xa5ac <_stogir.verify.structure+0x2bc>
    acb4:      	ldr	x0, [sp, #0x58]
    acb8:      	ldr	x3, [sp, #0x50]
    acbc:      	ldr	x4, [sp, #0x48]
    acc0:      	ldr	w1, [sp, #0xb0]
    acc4:      	ldr	w5, [sp, #0xa8]
    acc8:      	b	0xa5ac <_stogir.verify.structure+0x2bc>
    accc:      	ldr	x2, [sp, #0x60]
    acd0:      	b	0xa7d4 <_stogir.verify.structure+0x4e4>
    acd4:      	ldr	w1, [sp, #0xb0]
    acd8:      	ldr	w5, [sp, #0xa8]
    acdc:      	b	0xaab8 <_stogir.verify.structure+0x7c8>
    ace0:      	ldr	x0, [sp, #0x58]
    ace4:      	b	0xaae0 <_stogir.verify.structure+0x7f0>
    ace8:      	ldr	x0, [sp, #0x58]
    acec:      	b	0xaad0 <_stogir.verify.structure+0x7e0>
    acf0:      	ldr	w5, [sp, #0xa8]
    acf4:      	b	0xaab8 <_stogir.verify.structure+0x7c8>
    acf8:      	ldr	x3, [sp, #0x50]
    acfc:      	ldr	x4, [sp, #0x48]
    ad00:      	b	0xa598 <_stogir.verify.structure+0x2a8>
    ad04:      	udf	#0x0

000000000000ad08 <_stogir.verify.schedule-input-structured>:
    ad08:      	sub	sp, sp, #0x40
    ad0c:      	str	x29, [sp]
    ad10:      	str	x30, [sp, #0x8]
    ad14:      	mov	x29, sp
    ad18:      	str	x19, [sp, #0x30]
    ad1c:      	sxtw	x1, w1
    ad20:      	cmp	x1, #0x0
    ad24:      	cset	w4, gt
    ad28:      	movz	x16, #0x0, lsl #48
    ad2c:      	sub	x5, x16, x1
    ad30:      	sub	x6, x5, #0x1
    ad34:      	uxtb	w16, w4
    ad38:      	cmp	w16, wzr
    ad3c:      	b.eq	0xad7c <_stogir.verify.schedule-input-structured+0x74>
    ad40:      	ldr	x5, [x0, #0x8]
    ad44:      	cmp	x1, x5
    ad48:      	b.ge	0xadcc <_stogir.verify.schedule-input-structured+0xc4>
    ad4c:      	add	x5, x0, #0x78
    ad50:      	ldr	x5, [x5, #0x8]
    ad54:      	cmp	x1, x5
    ad58:      	b.ge	0xafac <_stogir.verify.schedule-input-structured+0x2a4>
    ad5c:      	ldr	x5, [x0, #0x78]
    ad60:      	add	x5, x5, x1, lsl #2
    ad64:      	ldr	w5, [x5]
    ad68:      	sxtw	x5, w5
    ad6c:      	cmp	x5, #0x0
    ad70:      	cset	w5, ge
    ad74:      	ubfx	x5, x5, #0, #8
    ad78:      	b	0xafb0 <_stogir.verify.schedule-input-structured+0x2a8>
    ad7c:      	cmp	x1, #0x0
    ad80:      	b.ge	0xadd4 <_stogir.verify.schedule-input-structured+0xcc>
    ad84:      	add	x7, x0, #0x28
    ad88:      	add	x9, x0, #0x50
    ad8c:      	ldr	x7, [x7, #0x8]
    ad90:      	ldr	x9, [x9, #0x8]
    ad94:      	cmp	x7, x9
    ad98:      	b.ne	0xadc4 <_stogir.verify.schedule-input-structured+0xbc>
    ad9c:      	cmp	x5, x7
    ada0:      	b.gt	0xafb4 <_stogir.verify.schedule-input-structured+0x2ac>
    ada4:      	ldr	x5, [x0, #0x50]
    ada8:      	add	x5, x5, x6, lsl #2
    adac:      	ldr	w5, [x5]
    adb0:      	sxtw	x5, w5
    adb4:      	cmp	x5, #0x0
    adb8:      	cset	w5, gt
    adbc:      	ubfx	x5, x5, #0, #8
    adc0:      	b	0xafb8 <_stogir.verify.schedule-input-structured+0x2b0>
    adc4:      	movz	x5, #0x0, lsl #48
    adc8:      	b	0xadd8 <_stogir.verify.schedule-input-structured+0xd0>
    adcc:      	movz	x5, #0x0, lsl #48
    add0:      	b	0xadd8 <_stogir.verify.schedule-input-structured+0xd0>
    add4:      	movz	x5, #0x0, lsl #48
    add8:      	cmp	x5, #0x0
    addc:      	b.eq	0xae10 <_stogir.verify.schedule-input-structured+0x108>
    ade0:      	uxtb	w16, w4
    ade4:      	cmp	w16, wzr
    ade8:      	b.eq	0xadfc <_stogir.verify.schedule-input-structured+0xf4>
    adec:      	ldr	x4, [x0]
    adf0:      	add	x4, x4, x1, lsl #4
    adf4:      	ldr	x4, [x4]
    adf8:      	b	0xae08 <_stogir.verify.schedule-input-structured+0x100>
    adfc:      	ldr	x4, [x0, #0x28]
    ae00:      	add	x4, x4, x6, lsl #4
    ae04:      	ldr	x4, [x4]
    ae08:      	mov	w5, #0x1                ; =1
    ae0c:      	b	0xae18 <_stogir.verify.schedule-input-structured+0x110>
    ae10:      	movz	w5, #0x0, lsl #16
    ae14:      	movz	x4, #0x0, lsl #48
    ae18:      	ubfx	x5, x5, #0, #32
    ae1c:      	lsr	x16, x5, #0
    ae20:      	cmp	x16, #0x1
    ae24:      	b.eq	0xae40 <_stogir.verify.schedule-input-structured+0x138>
    ae28:      	b.lo	0xae30 <_stogir.verify.schedule-input-structured+0x128>
    ae2c:      	b	0xae44 <_stogir.verify.schedule-input-structured+0x13c>
    ae30:      	cmp	x16, #0x0
    ae34:      	b.eq	0xae3c <_stogir.verify.schedule-input-structured+0x134>
    ae38:      	b	0xae44 <_stogir.verify.schedule-input-structured+0x13c>
    ae3c:      	b	0xae48 <_stogir.verify.schedule-input-structured+0x140>
    ae40:      	b	0xaf84 <_stogir.verify.schedule-input-structured+0x27c>
    ae44:      	b	0xb004 <_stogir.verify.schedule-input-structured+0x2fc>
    ae48:      	adrp	x1, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000ae48:  ARM64_RELOC_PAGE21	l_stogir.478
    ae4c:      	ldr	x1, [x1]
		000000000000ae4c:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    ae50:      	mov	x4, #0xd                ; =13
    ae54:      	b	0xae64 <_stogir.verify.schedule-input-structured+0x15c>
    ae58:      	adrp	x1, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000ae58:  ARM64_RELOC_PAGE21	l_stogir.479
    ae5c:      	ldr	x1, [x1]
		000000000000ae5c:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    ae60:      	mov	x4, #0x1b               ; =27
    ae64:      	cmp	x3, #0x0
    ae68:      	b.ne	0xae78 <_stogir.verify.schedule-input-structured+0x170>
    ae6c:      	adrp	x1, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000ae6c:  ARM64_RELOC_PAGE21	l_stogir.480
    ae70:      	ldr	x1, [x1]
		000000000000ae70:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    ae74:      	mov	x4, #0x25               ; =37
    ae78:      	add	x5, x0, #0x78
    ae7c:      	movz	x6, #0x0, lsl #48
    ae80:      	b	0xaf08 <_stogir.verify.schedule-input-structured+0x200>
    ae84:      	nop
    ae88:      	movz	w7, #0x0, lsl #16
    ae8c:      	movz	w9, #0x0, lsl #16
    ae90:      	ubfx	x7, x7, #0, #32
    ae94:      	lsr	x16, x7, #0
    ae98:      	cmp	x16, #0x1
    ae9c:      	b.eq	0xaeb8 <_stogir.verify.schedule-input-structured+0x1b0>
    aea0:      	b.lo	0xaea8 <_stogir.verify.schedule-input-structured+0x1a0>
    aea4:      	b	0xaebc <_stogir.verify.schedule-input-structured+0x1b4>
    aea8:      	cmp	x16, #0x0
    aeac:      	b.eq	0xaeb4 <_stogir.verify.schedule-input-structured+0x1ac>
    aeb0:      	b	0xaebc <_stogir.verify.schedule-input-structured+0x1b4>
    aeb4:      	b	0xaf30 <_stogir.verify.schedule-input-structured+0x228>
    aeb8:      	b	0xaec0 <_stogir.verify.schedule-input-structured+0x1b8>
    aebc:      	b	0xaffc <_stogir.verify.schedule-input-structured+0x2f4>
    aec0:      	sxtw	x9, w9
    aec4:      	cmp	x9, #0x0
    aec8:      	b.le	0xaefc <_stogir.verify.schedule-input-structured+0x1f4>
    aecc:      	ldr	x7, [x0, #0x8]
    aed0:      	cmp	x9, x7
    aed4:      	b.ge	0xaefc <_stogir.verify.schedule-input-structured+0x1f4>
    aed8:      	ldr	x7, [x5, #0x8]
    aedc:      	cmp	x9, x7
    aee0:      	b.ge	0xaefc <_stogir.verify.schedule-input-structured+0x1f4>
    aee4:      	ldr	x7, [x0, #0x78]
    aee8:      	add	x7, x7, x9, lsl #2
    aeec:      	ldr	w7, [x7]
    aef0:      	sxtw	x7, w7
    aef4:      	cmp	x7, #0x0
    aef8:      	b.ge	0xaf08 <_stogir.verify.schedule-input-structured+0x200>
    aefc:      	adrp	x1, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000aefc:  ARM64_RELOC_PAGE21	l_stogir.481
    af00:      	ldr	x1, [x1]
		000000000000af00:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    af04:      	mov	x4, #0x16               ; =22
    af08:      	cmp	x6, x3
    af0c:      	b.ge	0xae88 <_stogir.verify.schedule-input-structured+0x180>
    af10:      	add	x7, x6, #0x1
    af14:      	add	x6, x2, x6, lsl #2
    af18:      	ldr	w6, [x6]
    af1c:      	movn	w17, #0x0, lsl #16
    af20:      	and	w9, w6, w17
    af24:      	mov	x6, x7
    af28:      	mov	w7, #0x1                ; =1
    af2c:      	b	0xae90 <_stogir.verify.schedule-input-structured+0x188>
    af30:      	cmp	x4, #0x0
    af34:      	b.ne	0xb00c <_stogir.verify.schedule-input-structured+0x304>
    af38:      	mov	x19, x8
    af3c:      	add	x8, sp, #0x10
    af40:      	bl	0xaf40 <_stogir.verify.schedule-input-structured+0x238>
		000000000000af40:  ARM64_RELOC_BRANCH26	_stogir.verify.phis-structured
    af44:      	add	x16, sp, #0x10
    af48:      	ldr	x0, [x16]
    af4c:      	add	x16, sp, #0x10
    af50:      	ldr	x1, [x16, #0x8]
    af54:      	add	x16, sp, #0x10
    af58:      	ldr	x4, [x16, #0x10]
    af5c:      	b	0xaf64 <_stogir.verify.schedule-input-structured+0x25c>
    af60:      	mov	x0, #0x1                ; =1
    af64:      	str	x0, [x19]
    af68:      	str	x1, [x19, #0x8]
    af6c:      	str	x4, [x19, #0x10]
    af70:      	ldr	x19, [sp, #0x30]
    af74:      	ldr	x29, [sp]
    af78:      	ldr	x30, [sp, #0x8]
    af7c:      	add	sp, sp, #0x40
    af80:      	ret
    af84:      	cmp	x1, #0x0
    af88:      	b.le	0xae58 <_stogir.verify.schedule-input-structured+0x150>
    af8c:      	uxtb	w4, w4
    af90:      	cmp	x4, #0x83
    af94:      	b.ge	0xafbc <_stogir.verify.schedule-input-structured+0x2b4>
    af98:      	adrp	x17, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000af98:  ARM64_RELOC_PAGE21	l_stogir.482
    af9c:      	ldr	x17, [x17]
		000000000000af9c:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    afa0:      	add	x1, x4, x17
    afa4:      	ldrb	w1, [x1]
    afa8:      	b	0xafc0 <_stogir.verify.schedule-input-structured+0x2b8>
    afac:      	movz	x5, #0x0, lsl #48
    afb0:      	b	0xadd0 <_stogir.verify.schedule-input-structured+0xc8>
    afb4:      	movz	x5, #0x0, lsl #48
    afb8:      	b	0xadc8 <_stogir.verify.schedule-input-structured+0xc0>
    afbc:      	movz	w1, #0x0, lsl #16
    afc0:      	uxtb	w16, w1
    afc4:      	and	w1, w16, #0x2
    afc8:      	uxtb	w1, w1
    afcc:      	ubfx	x1, x1, #0, #8
    afd0:      	cmp	x1, #0x0
    afd4:      	cset	w1, eq
    afd8:      	uxtb	w16, w1
    afdc:      	cmp	w16, wzr
    afe0:      	cset	x1, eq
    afe4:      	cmp	x1, #0x0
    afe8:      	b.eq	0xae58 <_stogir.verify.schedule-input-structured+0x150>
    afec:      	adrp	x1, 0xa000 <_stogir.checked-schedule.cluster!+0xa88>
		000000000000afec:  ARM64_RELOC_PAGE21	l_stogir.483
    aff0:      	ldr	x1, [x1]
		000000000000aff0:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    aff4:      	movz	x4, #0x0, lsl #48
    aff8:      	b	0xae64 <_stogir.verify.schedule-input-structured+0x15c>
    affc:      	brk	#0
    b000:      	b	0xaffc <_stogir.verify.schedule-input-structured+0x2f4>
    b004:      	brk	#0
    b008:      	b	0xb004 <_stogir.verify.schedule-input-structured+0x2fc>
    b00c:      	mov	x19, x8
    b010:      	b	0xaf60 <_stogir.verify.schedule-input-structured+0x258>

000000000000b014 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
    b014:      	ldr	x0, [x0, #0x8]
    b018:      	ret

000000000000b01c <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    b01c:      	ldr	x0, [x0, #0x8]
    b020:      	ret

000000000000b024 <_stogir.verify.control-sources>:
    b024:      	sub	sp, sp, #0x40
    b028:      	str	x29, [sp]
    b02c:      	str	x30, [sp, #0x8]
    b030:      	mov	x29, sp
    b034:      	str	x19, [sp, #0x30]
    b038:      	str	x20, [sp, #0x38]
    b03c:      	mov	x19, x8
    b040:      	add	x8, sp, #0x10
    b044:      	mov	x20, x0
    b048:      	bl	0xb048 <_stogir.verify.control-sources+0x24>
		000000000000b048:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    b04c:      	add	x16, sp, #0x10
    b050:      	ldr	w0, [x16]
    b054:      	lsr	x16, x0, #0
    b058:      	cmp	x16, #0x1
    b05c:      	b.eq	0xb078 <_stogir.verify.control-sources+0x54>
    b060:      	b.lo	0xb068 <_stogir.verify.control-sources+0x44>
    b064:      	b	0xb07c <_stogir.verify.control-sources+0x58>
    b068:      	cmp	x16, #0x0
    b06c:      	b.eq	0xb074 <_stogir.verify.control-sources+0x50>
    b070:      	b	0xb07c <_stogir.verify.control-sources+0x58>
    b074:      	b	0xb0c8 <_stogir.verify.control-sources+0xa4>
    b078:      	b	0xb080 <_stogir.verify.control-sources+0x5c>
    b07c:      	b	0xb484 <_stogir.verify.control-sources+0x460>
    b080:      	add	x16, sp, #0x10
    b084:      	orr	x0, x16, xzr
    b088:      	add	x0, x0, #0x8
    b08c:      	add	x16, sp, #0x10
    b090:      	ldr	x1, [x16, #0x8]
    b094:      	ldr	x0, [x0, #0x8]
    b098:      	mov	x2, #0x1                ; =1
    b09c:      	b	0xb0a4 <_stogir.verify.control-sources+0x80>
    b0a0:      	mov	x2, #0x1                ; =1
    b0a4:      	str	x2, [x19]
    b0a8:      	str	x1, [x19, #0x8]
    b0ac:      	str	x0, [x19, #0x10]
    b0b0:      	ldr	x19, [sp, #0x30]
    b0b4:      	ldr	x20, [sp, #0x38]
    b0b8:      	ldr	x29, [sp]
    b0bc:      	ldr	x30, [sp, #0x8]
    b0c0:      	add	sp, sp, #0x40
    b0c4:      	ret
    b0c8:      	add	x2, x20, #0x78
    b0cc:      	add	x3, x20, #0x78
    b0d0:      	mov	x4, #0x1                ; =1
    b0d4:      	movz	x5, #0x0, lsl #48
    b0d8:      	adrp	x1, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b0d8:  ARM64_RELOC_PAGE21	l_stogir.484
    b0dc:      	ldr	x1, [x1]
		000000000000b0dc:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    b0e0:      	movz	x0, #0x0, lsl #48
    b0e4:      	b	0xb354 <_stogir.verify.control-sources+0x330>
    b0e8:      	movz	w13, #0x0, lsl #16
    b0ec:      	uxtb	w16, w13
    b0f0:      	and	w13, w16, #0x1
    b0f4:      	uxtb	w13, w13
    b0f8:      	ubfx	x13, x13, #0, #8
    b0fc:      	cmp	x13, #0x0
    b100:      	b.ne	0xb110 <_stogir.verify.control-sources+0xec>
    b104:      	adrp	x1, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b104:  ARM64_RELOC_PAGE21	l_stogir.485
    b108:      	ldr	x1, [x1]
		000000000000b108:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    b10c:      	mov	x0, #0x1d               ; =29
    b110:      	b	0xb2bc <_stogir.verify.control-sources+0x298>
    b114:      	movz	x6, #0x0, lsl #48
    b118:      	cmp	x6, #0x0
    b11c:      	b.eq	0xb45c <_stogir.verify.control-sources+0x438>
    b120:      	orr	w6, w4, wzr
    b124:      	ldr	x7, [x20]
    b128:      	sxtw	x6, w6
    b12c:      	cmp	x6, #0x0
    b130:      	cset	w8, le
    b134:      	lsl	x9, x6, #2
    b138:      	add	x7, x7, x4, lsl #4
    b13c:      	ldr	x7, [x7]
    b140:      	ldr	x10, [x20, #0x78]
    b144:      	uxtb	w7, w7
    b148:      	add	x10, x10, x4, lsl #2
    b14c:      	cmp	x7, #0x83
    b150:      	cset	w11, lt
    b154:      	adrp	x16, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b154:  ARM64_RELOC_PAGE21	l_stogir.486
    b158:      	ldr	x16, [x16]
		000000000000b158:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    b15c:      	add	x7, x16, x7, lsl #2
    b160:      	ldr	w10, [x10]
    b164:      	sxtw	x10, w10
    b168:      	mov	x12, #0x1               ; =1
    b16c:      	b	0xb1e8 <_stogir.verify.control-sources+0x1c4>
    b170:      	movz	w14, #0x0, lsl #16
    b174:      	movz	w13, #0x0, lsl #16
    b178:      	b	0xb19c <_stogir.verify.control-sources+0x178>
    b17c:      	sub	w13, w13, #0x1
    b180:      	lsl	w13, w13, #2
    b184:      	ubfx	x13, x13, #0, #32
    b188:      	lsr	x13, x15, x13
    b18c:      	and	w13, w13, #0xf
    b190:      	b	0xb240 <_stogir.verify.control-sources+0x21c>
    b194:      	movz	w14, #0x0, lsl #16
    b198:      	movz	w13, #0x0, lsl #16
    b19c:      	ubfx	x14, x14, #0, #32
    b1a0:      	lsr	x16, x14, #0
    b1a4:      	cmp	x16, #0x1
    b1a8:      	b.eq	0xb1c4 <_stogir.verify.control-sources+0x1a0>
    b1ac:      	b.lo	0xb1b4 <_stogir.verify.control-sources+0x190>
    b1b0:      	b	0xb1c8 <_stogir.verify.control-sources+0x1a4>
    b1b4:      	cmp	x16, #0x0
    b1b8:      	b.eq	0xb1c0 <_stogir.verify.control-sources+0x19c>
    b1bc:      	b	0xb1c8 <_stogir.verify.control-sources+0x1a4>
    b1c0:      	b	0xb1cc <_stogir.verify.control-sources+0x1a8>
    b1c4:      	b	0xb2a4 <_stogir.verify.control-sources+0x280>
    b1c8:      	b	0xb474 <_stogir.verify.control-sources+0x450>
    b1cc:      	adrp	x1, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b1cc:  ARM64_RELOC_PAGE21	l_stogir.487
    b1d0:      	ldr	x1, [x1]
		000000000000b1d0:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b1d4:      	mov	x0, #0x16               ; =22
    b1d8:      	add	x5, x5, #0x1
    b1dc:      	sxtw	x5, w5
    b1e0:      	add	x12, x12, #0x1
    b1e4:      	sxtw	x12, w12
    b1e8:      	cmp	x0, #0x0
    b1ec:      	b.ne	0xb200 <_stogir.verify.control-sources+0x1dc>
    b1f0:      	cmp	x12, x10
    b1f4:      	cset	w13, le
    b1f8:      	ubfx	x13, x13, #0, #8
    b1fc:      	b	0xb204 <_stogir.verify.control-sources+0x1e0>
    b200:      	movz	x13, #0x0, lsl #48
    b204:      	cmp	x13, #0x0
    b208:      	b.eq	0xb33c <_stogir.verify.control-sources+0x318>
    b20c:      	orr	w13, w12, wzr
    b210:      	sxtw	x14, w13
    b214:      	uxtb	w16, w11
    b218:      	cmp	w16, wzr
    b21c:      	b.eq	0xb244 <_stogir.verify.control-sources+0x220>
    b220:      	ldr	w15, [x7]
    b224:      	cmp	x14, #0x0
    b228:      	b.le	0xb23c <_stogir.verify.control-sources+0x218>
    b22c:      	cmp	x14, #0x4
    b230:      	b.le	0xb17c <_stogir.verify.control-sources+0x158>
    b234:      	mov	w13, #0x4               ; =4
    b238:      	b	0xb180 <_stogir.verify.control-sources+0x15c>
    b23c:      	movz	w13, #0x0, lsl #16
    b240:      	b	0xb248 <_stogir.verify.control-sources+0x224>
    b244:      	movz	w13, #0x0, lsl #16
    b248:      	adrp	x16, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b248:  ARM64_RELOC_PAGE21	l_stogir.488
    b24c:      	ldr	x16, [x16]
		000000000000b24c:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    b250:      	ldr	w15, [x16]
    b254:      	ubfx	x13, x13, #0, #32
    b258:      	cmp	x13, x15
    b25c:      	b.ne	0xb1e0 <_stogir.verify.control-sources+0x1bc>
    b260:      	uxtb	w16, w8
    b264:      	cmp	w16, wzr
    b268:      	b.ne	0xb194 <_stogir.verify.control-sources+0x170>
    b26c:      	ldr	x13, [x20, #0x8]
    b270:      	cmp	x6, x13
    b274:      	b.ge	0xb2c8 <_stogir.verify.control-sources+0x2a4>
    b278:      	ldr	x13, [x2, #0x8]
    b27c:      	cmp	x6, x13
    b280:      	b.ge	0xb2c0 <_stogir.verify.control-sources+0x29c>
    b284:      	ldr	x13, [x20, #0x78]
    b288:      	add	x13, x9, x13
    b28c:      	ldr	w13, [x13]
    b290:      	sxtw	x13, w13
    b294:      	cmp	x13, #0x0
    b298:      	cset	w13, ge
    b29c:      	ubfx	x13, x13, #0, #8
    b2a0:      	b	0xb2c4 <_stogir.verify.control-sources+0x2a0>
    b2a4:      	sxtw	x13, w13
    b2a8:      	cmp	x13, #0x0
    b2ac:      	b.gt	0xb370 <_stogir.verify.control-sources+0x34c>
    b2b0:      	adrp	x1, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b2b0:  ARM64_RELOC_PAGE21	l_stogir.489
    b2b4:      	ldr	x1, [x1]
		000000000000b2b4:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    b2b8:      	mov	x0, #0x25               ; =37
    b2bc:      	b	0xb1d8 <_stogir.verify.control-sources+0x1b4>
    b2c0:      	movz	x13, #0x0, lsl #48
    b2c4:      	b	0xb2cc <_stogir.verify.control-sources+0x2a8>
    b2c8:      	movz	x13, #0x0, lsl #48
    b2cc:      	cmp	x13, #0x0
    b2d0:      	b.eq	0xb194 <_stogir.verify.control-sources+0x170>
    b2d4:      	cmp	x14, #0x1
    b2d8:      	b.lt	0xb170 <_stogir.verify.control-sources+0x14c>
    b2dc:      	ldr	x13, [x20, #0x78]
    b2e0:      	add	x13, x9, x13
    b2e4:      	ldr	w13, [x13]
    b2e8:      	sxtw	x13, w13
    b2ec:      	cmp	x14, x13
    b2f0:      	b.gt	0xb170 <_stogir.verify.control-sources+0x14c>
    b2f4:      	ldr	x13, [x20]
    b2f8:      	asr	x16, x14, #63
    b2fc:      	lsr	x16, x16, #62
    b300:      	add	x15, x14, x16
    b304:      	asr	x15, x15, #2
    b308:      	asr	x16, x14, #63
    b30c:      	lsr	x16, x16, #62
    b310:      	add	x14, x14, x16
    b314:      	and	x14, x14, #0x3
    b318:      	sub	x14, x14, x16
    b31c:      	add	x15, x15, x6
    b320:      	add	x13, x13, x15, lsl #4
    b324:      	add	x13, x13, x14, lsl #2
    b328:      	ldr	w13, [x13]
    b32c:      	movn	w17, #0x0, lsl #16
    b330:      	and	w13, w13, w17
    b334:      	mov	w14, #0x1               ; =1
    b338:      	b	0xb178 <_stogir.verify.control-sources+0x154>
    b33c:      	add	x6, x10, #0x4
    b340:      	asr	x16, x6, #63
    b344:      	lsr	x16, x16, #62
    b348:      	add	x6, x6, x16
    b34c:      	asr	x6, x6, #2
    b350:      	add	x4, x6, x4
    b354:      	cmp	x0, #0x0
    b358:      	b.ne	0xb114 <_stogir.verify.control-sources+0xf0>
    b35c:      	ldr	x6, [x20, #0x8]
    b360:      	cmp	x4, x6
    b364:      	cset	w6, lt
    b368:      	ubfx	x6, x6, #0, #8
    b36c:      	b	0xb118 <_stogir.verify.control-sources+0xf4>
    b370:      	ldr	x14, [x20, #0x8]
    b374:      	cmp	x13, x14
    b378:      	b.ge	0xb3b0 <_stogir.verify.control-sources+0x38c>
    b37c:      	ldr	x14, [x3, #0x8]
    b380:      	cmp	x13, x14
    b384:      	b.ge	0xb3a8 <_stogir.verify.control-sources+0x384>
    b388:      	ldr	x14, [x20, #0x78]
    b38c:      	add	x14, x14, x13, lsl #2
    b390:      	ldr	w14, [x14]
    b394:      	sxtw	x14, w14
    b398:      	cmp	x14, #0x0
    b39c:      	cset	w14, ge
    b3a0:      	ubfx	x14, x14, #0, #8
    b3a4:      	b	0xb3ac <_stogir.verify.control-sources+0x388>
    b3a8:      	movz	x14, #0x0, lsl #48
    b3ac:      	b	0xb3b4 <_stogir.verify.control-sources+0x390>
    b3b0:      	movz	x14, #0x0, lsl #48
    b3b4:      	cmp	x14, #0x0
    b3b8:      	b.eq	0xb3f4 <_stogir.verify.control-sources+0x3d0>
    b3bc:      	cmp	x13, #0x0
    b3c0:      	b.le	0xb3d4 <_stogir.verify.control-sources+0x3b0>
    b3c4:      	ldr	x14, [x20]
    b3c8:      	add	x13, x14, x13, lsl #4
    b3cc:      	ldr	x13, [x13]
    b3d0:      	b	0xb3ec <_stogir.verify.control-sources+0x3c8>
    b3d4:      	movz	x16, #0x0, lsl #48
    b3d8:      	sub	x13, x16, x13
    b3dc:      	ldr	x14, [x20, #0x28]
    b3e0:      	sub	x13, x13, #0x1
    b3e4:      	add	x13, x14, x13, lsl #4
    b3e8:      	ldr	x13, [x13]
    b3ec:      	mov	w14, #0x1               ; =1
    b3f0:      	b	0xb3fc <_stogir.verify.control-sources+0x3d8>
    b3f4:      	movz	w14, #0x0, lsl #16
    b3f8:      	movz	x13, #0x0, lsl #48
    b3fc:      	ubfx	x14, x14, #0, #32
    b400:      	lsr	x16, x14, #0
    b404:      	cmp	x16, #0x1
    b408:      	b.eq	0xb424 <_stogir.verify.control-sources+0x400>
    b40c:      	b.lo	0xb414 <_stogir.verify.control-sources+0x3f0>
    b410:      	b	0xb428 <_stogir.verify.control-sources+0x404>
    b414:      	cmp	x16, #0x0
    b418:      	b.eq	0xb420 <_stogir.verify.control-sources+0x3fc>
    b41c:      	b	0xb428 <_stogir.verify.control-sources+0x404>
    b420:      	b	0xb42c <_stogir.verify.control-sources+0x408>
    b424:      	b	0xb43c <_stogir.verify.control-sources+0x418>
    b428:      	b	0xb47c <_stogir.verify.control-sources+0x458>
    b42c:      	adrp	x1, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b42c:  ARM64_RELOC_PAGE21	l_stogir.487
    b430:      	ldr	x1, [x1]
		000000000000b430:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b434:      	mov	x0, #0x16               ; =22
    b438:      	b	0xb110 <_stogir.verify.control-sources+0xec>
    b43c:      	uxtb	w13, w13
    b440:      	cmp	x13, #0x83
    b444:      	b.ge	0xb0e8 <_stogir.verify.control-sources+0xc4>
    b448:      	adrp	x17, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b448:  ARM64_RELOC_PAGE21	l_stogir.490
    b44c:      	ldr	x17, [x17]
		000000000000b44c:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    b450:      	add	x13, x13, x17
    b454:      	ldrb	w13, [x13]
    b458:      	b	0xb0ec <_stogir.verify.control-sources+0xc8>
    b45c:      	cmp	x0, #0x0
    b460:      	b.ne	0xb0a0 <_stogir.verify.control-sources+0x7c>
    b464:      	and	x1, x5, #0xffffffff
    b468:      	movz	x2, #0x0, lsl #48
    b46c:      	movz	x0, #0x0, lsl #48
    b470:      	b	0xb0a4 <_stogir.verify.control-sources+0x80>
    b474:      	brk	#0
    b478:      	b	0xb474 <_stogir.verify.control-sources+0x450>
    b47c:      	brk	#0
    b480:      	b	0xb47c <_stogir.verify.control-sources+0x458>
    b484:      	brk	#0
    b488:      	b	0xb484 <_stogir.verify.control-sources+0x460>

000000000000b48c <_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge>:
    b48c:      	ldr	x1, [x0]
    b490:      	ldr	x0, [x0, #0x8]
    b494:      	movz	x17, #0x0, lsl #48
    b498:      	str	x17, [x8]
    b49c:      	movz	x17, #0x0, lsl #48
    b4a0:      	str	x17, [x8, #0x8]
    b4a4:      	movz	x17, #0x0, lsl #48
    b4a8:      	str	x17, [x8, #0x10]
    b4ac:      	str	x1, [x8, #0x18]
    b4b0:      	str	x0, [x8, #0x20]
    b4b4:      	ret

000000000000b4b8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32>:
    b4b8:      	sub	sp, sp, #0x30
    b4bc:      	str	x29, [sp]
    b4c0:      	str	x30, [sp, #0x8]
    b4c4:      	mov	x29, sp
    b4c8:      	str	x19, [sp, #0x10]
    b4cc:      	str	x20, [sp, #0x18]
    b4d0:      	str	x21, [sp, #0x20]
    b4d4:      	str	x22, [sp, #0x28]
    b4d8:      	ldr	x2, [x0, #0x8]
    b4dc:      	orr	x19, x2, xzr
    b4e0:      	ldr	x2, [x0, #0x10]
    b4e4:      	add	x20, x19, x1
    b4e8:      	cmp	x20, x2
    b4ec:      	b.le	0xb568 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0xb0>
    b4f0:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b4f4:      	cmp	x2, x17
    b4f8:      	b.gt	0xb504 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x4c>
    b4fc:      	lsl	x2, x2, #1
    b500:      	b	0xb508 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x50>
    b504:      	mov	x2, x20
    b508:      	cmp	x2, x20
    b50c:      	b.gt	0xb514 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x5c>
    b510:      	mov	x2, x20
    b514:      	mov	x21, x0
    b518:      	mov	x22, x1
    b51c:      	mov	x1, x2
    b520:      	bl	0xb520 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x68>
		000000000000b520:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b524:      	lsl	x0, x22, #2
    b528:      	ldr	x1, [x21]
    b52c:      	add	x1, x1, x19, lsl #2
    b530:      	mov	x2, x0
    b534:      	mov	x0, x1
    b538:      	movz	x1, #0x0, lsl #48
    b53c:      	bl	0xb53c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x84>
		000000000000b53c:  ARM64_RELOC_BRANCH26	_memset
    b540:      	str	x20, [x21, #0x8]
    b544:      	mov	x0, x20
    b548:      	ldr	x19, [sp, #0x10]
    b54c:      	ldr	x20, [sp, #0x18]
    b550:      	ldr	x21, [sp, #0x20]
    b554:      	ldr	x22, [sp, #0x28]
    b558:      	ldr	x29, [sp]
    b55c:      	ldr	x30, [sp, #0x8]
    b560:      	add	sp, sp, #0x30
    b564:      	ret
    b568:      	mov	x21, x0
    b56c:      	mov	x22, x1
    b570:      	b	0xb524 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x6c>

000000000000b574 <_stogir.opcode.block-start?>:
    b574:      	sxtw	x0, w0
    b578:      	cmp	x0, #0x0
    b57c:      	b.lt	0xb59c <_stogir.opcode.block-start?+0x28>
    b580:      	cmp	x0, #0x83
    b584:      	b.ge	0xb59c <_stogir.opcode.block-start?+0x28>
    b588:      	adrp	x16, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b588:  ARM64_RELOC_PAGE21	l_stogir.491
    b58c:      	ldr	x16, [x16]
		000000000000b58c:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    b590:      	add	x0, x16, x0
    b594:      	ldrb	w0, [x0]
    b598:      	b	0xb5a0 <_stogir.opcode.block-start?+0x2c>
    b59c:      	movz	w0, #0x0, lsl #16
    b5a0:      	uxtb	w16, w0
    b5a4:      	and	w0, w16, #0x2
    b5a8:      	uxtb	w0, w0
    b5ac:      	ubfx	x0, x0, #0, #8
    b5b0:      	cmp	x0, #0x0
    b5b4:      	cset	w0, eq
    b5b8:      	uxtb	w16, w0
    b5bc:      	cmp	w16, wzr
    b5c0:      	cset	x0, eq
    b5c4:      	ret

000000000000b5c8 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32>:
    b5c8:      	sub	sp, sp, #0x30
    b5cc:      	str	x29, [sp]
    b5d0:      	str	x30, [sp, #0x8]
    b5d4:      	mov	x29, sp
    b5d8:      	str	x19, [sp, #0x10]
    b5dc:      	str	x20, [sp, #0x18]
    b5e0:      	str	x21, [sp, #0x20]
    b5e4:      	ldr	x2, [x0, #0x8]
    b5e8:      	orr	x19, x2, xzr
    b5ec:      	ldr	x2, [x0, #0x10]
    b5f0:      	cmp	x19, x2
    b5f4:      	b.lt	0xb608 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x40>
    b5f8:      	cmp	x2, #0x0
    b5fc:      	b.ne	0xb614 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x4c>
    b600:      	mov	x2, #0x2                ; =2
    b604:      	b	0xb618 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x50>
    b608:      	mov	x20, x0
    b60c:      	mov	w21, w1
    b610:      	b	0xb628 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x60>
    b614:      	lsl	x2, x2, #1
    b618:      	mov	x20, x0
    b61c:      	mov	w21, w1
    b620:      	mov	x1, x2
    b624:      	bl	0xb624 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x5c>
		000000000000b624:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b628:      	add	x0, x19, #0x1
    b62c:      	ldr	x1, [x20]
    b630:      	add	x1, x1, x19, lsl #2
    b634:      	str	w21, [x1]
    b638:      	str	x0, [x20, #0x8]
    b63c:      	ldr	x19, [sp, #0x10]
    b640:      	ldr	x20, [sp, #0x18]
    b644:      	ldr	x21, [sp, #0x20]
    b648:      	ldr	x29, [sp]
    b64c:      	ldr	x30, [sp, #0x8]
    b650:      	add	sp, sp, #0x30
    b654:      	ret

000000000000b658 <_coil.core.Set$coil.arraylist.ArrayList$set!__i32>:
    b658:      	ldr	x0, [x0]
    b65c:      	add	x0, x0, x1, lsl #2
    b660:      	str	w2, [x0]
    b664:      	movz	x0, #0x0, lsl #48
    b668:      	ret

000000000000b66c <_stogir.opcode.control?>:
    b66c:      	sxtw	x0, w0
    b670:      	cmp	x0, #0x0
    b674:      	b.lt	0xb694 <_stogir.opcode.control?+0x28>
    b678:      	cmp	x0, #0x83
    b67c:      	b.ge	0xb694 <_stogir.opcode.control?+0x28>
    b680:      	adrp	x16, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b680:  ARM64_RELOC_PAGE21	l_stogir.492
    b684:      	ldr	x16, [x16]
		000000000000b684:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    b688:      	add	x0, x16, x0
    b68c:      	ldrb	w0, [x0]
    b690:      	b	0xb698 <_stogir.opcode.control?+0x2c>
    b694:      	movz	w0, #0x0, lsl #16
    b698:      	uxtb	w16, w0
    b69c:      	and	w0, w16, #0x1
    b6a0:      	uxtb	w0, w0
    b6a4:      	ubfx	x0, x0, #0, #8
    b6a8:      	ret
    b6ac:      	udf	#0x0

000000000000b6b0 <_inherent$coil.arraylist.ArrayList$clear!__i32>:
    b6b0:      	b	0xb6c0 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x10>
    b6b4:      	nop
    b6b8:      	sub	x1, x1, #0x1
    b6bc:      	str	x1, [x0, #0x8]
    b6c0:      	ldr	x1, [x0, #0x8]
    b6c4:      	cmp	x1, #0x0
    b6c8:      	b.ne	0xb6b8 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x8>
    b6cc:      	movz	x0, #0x0, lsl #48
    b6d0:      	ret

000000000000b6d4 <_stogir.graph.operand>:
    b6d4:      	sub	sp, sp, #0x10
    b6d8:      	mov	x3, sp
    b6dc:      	sxtw	x1, w1
    b6e0:      	cmp	x1, #0x0
    b6e4:      	b.le	0xb728 <_stogir.graph.operand+0x54>
    b6e8:      	lsl	x4, x1, #2
    b6ec:      	ldr	x5, [x0, #0x8]
    b6f0:      	cmp	x1, x5
    b6f4:      	b.ge	0xb75c <_stogir.graph.operand+0x88>
    b6f8:      	add	x5, x0, #0x78
    b6fc:      	ldr	x5, [x5, #0x8]
    b700:      	cmp	x1, x5
    b704:      	b.ge	0xb754 <_stogir.graph.operand+0x80>
    b708:      	ldr	x5, [x0, #0x78]
    b70c:      	add	x5, x4, x5
    b710:      	ldr	w5, [x5]
    b714:      	sxtw	x5, w5
    b718:      	cmp	x5, #0x0
    b71c:      	cset	w5, ge
    b720:      	ubfx	x5, x5, #0, #8
    b724:      	b	0xb758 <_stogir.graph.operand+0x84>
    b728:      	movz	x1, #0x0, lsl #48
    b72c:      	movz	x0, #0x0, lsl #48
    b730:      	str	x1, [x3]
    b734:      	str	x0, [x3, #0x8]
    b738:      	ldr	x0, [sp]
    b73c:      	ldr	x1, [sp, #0x8]
    b740:      	add	sp, sp, #0x10
    b744:      	ret
    b748:      	movz	x1, #0x0, lsl #48
    b74c:      	movz	x0, #0x0, lsl #48
    b750:      	b	0xb730 <_stogir.graph.operand+0x5c>
    b754:      	movz	x5, #0x0, lsl #48
    b758:      	b	0xb760 <_stogir.graph.operand+0x8c>
    b75c:      	movz	x5, #0x0, lsl #48
    b760:      	cmp	x5, #0x0
    b764:      	b.eq	0xb728 <_stogir.graph.operand+0x54>
    b768:      	sxtw	x2, w2
    b76c:      	cmp	x2, #0x1
    b770:      	b.lt	0xb748 <_stogir.graph.operand+0x74>
    b774:      	ldr	x5, [x0, #0x78]
    b778:      	add	x4, x4, x5
    b77c:      	ldr	w4, [x4]
    b780:      	sxtw	x4, w4
    b784:      	cmp	x2, x4
    b788:      	b.gt	0xb748 <_stogir.graph.operand+0x74>
    b78c:      	asr	x16, x2, #63
    b790:      	lsr	x16, x16, #62
    b794:      	add	x4, x2, x16
    b798:      	asr	x4, x4, #2
    b79c:      	asr	x16, x2, #63
    b7a0:      	lsr	x16, x16, #62
    b7a4:      	add	x2, x2, x16
    b7a8:      	and	x2, x2, #0x3
    b7ac:      	sub	x2, x2, x16
    b7b0:      	ldr	x0, [x0]
    b7b4:      	add	x1, x4, x1
    b7b8:      	add	x0, x0, x1, lsl #4
    b7bc:      	add	x0, x0, x2, lsl #2
    b7c0:      	ldr	w0, [x0]
    b7c4:      	sxtw	x0, w0
    b7c8:      	and	x0, x0, #0xffffffff
    b7cc:      	mov	x1, #0x1                ; =1
    b7d0:      	b	0xb750 <_stogir.graph.operand+0x7c>

000000000000b7d4 <_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame>:
    b7d4:      	ldr	x1, [x0]
    b7d8:      	ldr	x0, [x0, #0x8]
    b7dc:      	movz	x17, #0x0, lsl #48
    b7e0:      	str	x17, [x8]
    b7e4:      	movz	x17, #0x0, lsl #48
    b7e8:      	str	x17, [x8, #0x8]
    b7ec:      	movz	x17, #0x0, lsl #48
    b7f0:      	str	x17, [x8, #0x10]
    b7f4:      	str	x1, [x8, #0x18]
    b7f8:      	str	x0, [x8, #0x20]
    b7fc:      	ret

000000000000b800 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool>:
    b800:      	sub	sp, sp, #0x30
    b804:      	str	x29, [sp]
    b808:      	str	x30, [sp, #0x8]
    b80c:      	mov	x29, sp
    b810:      	str	x19, [sp, #0x10]
    b814:      	str	x20, [sp, #0x18]
    b818:      	str	x21, [sp, #0x20]
    b81c:      	str	x22, [sp, #0x28]
    b820:      	ldr	x2, [x0, #0x8]
    b824:      	orr	x19, x2, xzr
    b828:      	ldr	x2, [x0, #0x10]
    b82c:      	add	x20, x19, x1
    b830:      	cmp	x20, x2
    b834:      	b.le	0xb8b0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xb0>
    b838:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b83c:      	cmp	x2, x17
    b840:      	b.gt	0xb84c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x4c>
    b844:      	lsl	x2, x2, #1
    b848:      	b	0xb850 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x50>
    b84c:      	mov	x2, x20
    b850:      	cmp	x2, x20
    b854:      	b.gt	0xb85c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x5c>
    b858:      	mov	x2, x20
    b85c:      	mov	x21, x0
    b860:      	mov	x22, x1
    b864:      	mov	x1, x2
    b868:      	bl	0xb868 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x68>
		000000000000b868:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    b86c:      	lsr	x0, x22, #0
    b870:      	ldr	x1, [x21]
    b874:      	add	x1, x1, x19
    b878:      	mov	x2, x0
    b87c:      	mov	x0, x1
    b880:      	movz	x1, #0x0, lsl #48
    b884:      	bl	0xb884 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x84>
		000000000000b884:  ARM64_RELOC_BRANCH26	_memset
    b888:      	str	x20, [x21, #0x8]
    b88c:      	mov	x0, x20
    b890:      	ldr	x19, [sp, #0x10]
    b894:      	ldr	x20, [sp, #0x18]
    b898:      	ldr	x21, [sp, #0x20]
    b89c:      	ldr	x22, [sp, #0x28]
    b8a0:      	ldr	x29, [sp]
    b8a4:      	ldr	x30, [sp, #0x8]
    b8a8:      	add	sp, sp, #0x30
    b8ac:      	ret
    b8b0:      	mov	x21, x0
    b8b4:      	mov	x22, x1
    b8b8:      	b	0xb86c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x6c>

000000000000b8bc <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame>:
    b8bc:      	sub	sp, sp, #0x30
    b8c0:      	str	x29, [sp]
    b8c4:      	str	x30, [sp, #0x8]
    b8c8:      	mov	x29, sp
    b8cc:      	str	x19, [sp, #0x10]
    b8d0:      	str	x20, [sp, #0x18]
    b8d4:      	str	x21, [sp, #0x20]
    b8d8:      	str	x22, [sp, #0x28]
    b8dc:      	ldr	x3, [x0, #0x8]
    b8e0:      	orr	x19, x3, xzr
    b8e4:      	ldr	x3, [x0, #0x10]
    b8e8:      	cmp	x19, x3
    b8ec:      	b.lt	0xb900 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x44>
    b8f0:      	cmp	x3, #0x0
    b8f4:      	b.ne	0xb910 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x54>
    b8f8:      	mov	x3, #0x2                ; =2
    b8fc:      	b	0xb914 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x58>
    b900:      	mov	x20, x0
    b904:      	mov	x21, x1
    b908:      	mov	x22, x2
    b90c:      	b	0xb928 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x6c>
    b910:      	lsl	x3, x3, #1
    b914:      	mov	x20, x0
    b918:      	mov	x21, x1
    b91c:      	mov	x1, x3
    b920:      	mov	x22, x2
    b924:      	bl	0xb924 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x68>
		000000000000b924:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    b928:      	add	x0, x19, #0x1
    b92c:      	ldr	x1, [x20]
    b930:      	add	x1, x1, x19, lsl #4
    b934:      	str	x21, [x1]
    b938:      	str	x22, [x1, #0x8]
    b93c:      	str	x0, [x20, #0x8]
    b940:      	ldr	x19, [sp, #0x10]
    b944:      	ldr	x20, [sp, #0x18]
    b948:      	ldr	x21, [sp, #0x20]
    b94c:      	ldr	x22, [sp, #0x28]
    b950:      	ldr	x29, [sp]
    b954:      	ldr	x30, [sp, #0x8]
    b958:      	add	sp, sp, #0x30
    b95c:      	ret

000000000000b960 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame>:
    b960:      	sub	sp, sp, #0x20
    b964:      	str	x29, [sp]
    b968:      	str	x30, [sp, #0x8]
    b96c:      	mov	x29, sp
    b970:      	str	x19, [sp, #0x10]
    b974:      	b	0xb980 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x20>
    b978:      	sub	x1, x1, #0x1
    b97c:      	str	x1, [x0, #0x8]
    b980:      	ldr	x1, [x0, #0x8]
    b984:      	cmp	x1, #0x0
    b988:      	b.ne	0xb978 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x18>
    b98c:      	ldr	x1, [x0, #0x10]
    b990:      	cmp	x1, #0x0
    b994:      	b.le	0xb9f4 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x94>
    b998:      	add	x2, x0, #0x18
    b99c:      	ldr	x3, [x0]
    b9a0:      	mov	x19, x0
    b9a4:      	mov	x0, x2
    b9a8:      	mov	x2, x1
    b9ac:      	mov	x1, x3
    b9b0:      	adrp	x3, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000b9b0:  ARM64_RELOC_PAGE21	l_stogir.493
    b9b4:      	ldr	x3, [x3]
		000000000000b9b4:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b9b8:      	mov	x4, #0x10               ; =16
    b9bc:      	mov	x5, #0x8                ; =8
    b9c0:      	bl	0xb9c0 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x60>
		000000000000b9c0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b9c4:      	movz	x17, #0x0, lsl #48
    b9c8:      	str	x17, [x19]
    b9cc:      	movz	x17, #0x0, lsl #48
    b9d0:      	str	x17, [x19, #0x8]
    b9d4:      	movz	x17, #0x0, lsl #48
    b9d8:      	str	x17, [x19, #0x10]
    b9dc:      	movz	x0, #0x0, lsl #48
    b9e0:      	ldr	x19, [sp, #0x10]
    b9e4:      	ldr	x29, [sp]
    b9e8:      	ldr	x30, [sp, #0x8]
    b9ec:      	add	sp, sp, #0x20
    b9f0:      	ret
    b9f4:      	mov	x19, x0
    b9f8:      	b	0xb9c4 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x64>

000000000000b9fc <_inherent$coil.arraylist.ArrayList$new__i64>:
    b9fc:      	ldr	x1, [x0]
    ba00:      	ldr	x0, [x0, #0x8]
    ba04:      	movz	x17, #0x0, lsl #48
    ba08:      	str	x17, [x8]
    ba0c:      	movz	x17, #0x0, lsl #48
    ba10:      	str	x17, [x8, #0x8]
    ba14:      	movz	x17, #0x0, lsl #48
    ba18:      	str	x17, [x8, #0x10]
    ba1c:      	str	x1, [x8, #0x18]
    ba20:      	str	x0, [x8, #0x20]
    ba24:      	ret

000000000000ba28 <_inherent$coil.arraylist.ArrayList$free!__i64>:
    ba28:      	sub	sp, sp, #0x20
    ba2c:      	str	x29, [sp]
    ba30:      	str	x30, [sp, #0x8]
    ba34:      	mov	x29, sp
    ba38:      	str	x19, [sp, #0x10]
    ba3c:      	b	0xba48 <_inherent$coil.arraylist.ArrayList$free!__i64+0x20>
    ba40:      	sub	x1, x1, #0x1
    ba44:      	str	x1, [x0, #0x8]
    ba48:      	ldr	x1, [x0, #0x8]
    ba4c:      	cmp	x1, #0x0
    ba50:      	b.ne	0xba40 <_inherent$coil.arraylist.ArrayList$free!__i64+0x18>
    ba54:      	ldr	x1, [x0, #0x10]
    ba58:      	cmp	x1, #0x0
    ba5c:      	b.le	0xbabc <_inherent$coil.arraylist.ArrayList$free!__i64+0x94>
    ba60:      	add	x2, x0, #0x18
    ba64:      	ldr	x3, [x0]
    ba68:      	mov	x19, x0
    ba6c:      	mov	x0, x2
    ba70:      	mov	x2, x1
    ba74:      	mov	x1, x3
    ba78:      	adrp	x3, 0xb000 <_stogir.verify.schedule-input-structured+0x2f8>
		000000000000ba78:  ARM64_RELOC_PAGE21	l_stogir.494
    ba7c:      	ldr	x3, [x3]
		000000000000ba7c:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    ba80:      	mov	x4, #0x8                ; =8
    ba84:      	mov	x5, #0x8                ; =8
    ba88:      	bl	0xba88 <_inherent$coil.arraylist.ArrayList$free!__i64+0x60>
		000000000000ba88:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    ba8c:      	movz	x17, #0x0, lsl #48
    ba90:      	str	x17, [x19]
    ba94:      	movz	x17, #0x0, lsl #48
    ba98:      	str	x17, [x19, #0x8]
    ba9c:      	movz	x17, #0x0, lsl #48
    baa0:      	str	x17, [x19, #0x10]
    baa4:      	movz	x0, #0x0, lsl #48
    baa8:      	ldr	x19, [sp, #0x10]
    baac:      	ldr	x29, [sp]
    bab0:      	ldr	x30, [sp, #0x8]
    bab4:      	add	sp, sp, #0x20
    bab8:      	ret
    babc:      	mov	x19, x0
    bac0:      	b	0xba8c <_inherent$coil.arraylist.ArrayList$free!__i64+0x64>
    bac4:      	udf	#0x0

000000000000bac8 <_stogir.dominators.build-index>:
    bac8:      	sub	sp, sp, #0x140
    bacc:      	str	x29, [sp]
    bad0:      	str	x30, [sp, #0x8]
    bad4:      	mov	x29, sp
    bad8:      	str	x19, [sp, #0xf0]
    badc:      	str	x20, [sp, #0xf8]
    bae0:      	str	x21, [sp, #0x100]
    bae4:      	str	x22, [sp, #0x108]
    bae8:      	str	x23, [sp, #0x110]
    baec:      	str	x24, [sp, #0x118]
    baf0:      	str	x25, [sp, #0x120]
    baf4:      	str	x26, [sp, #0x128]
    baf8:      	str	x27, [sp, #0x130]
    bafc:      	str	x28, [sp, #0x138]
    bb00:      	add	x16, sp, #0x10
    bb04:      	orr	x19, x16, xzr
    bb08:      	ldr	x2, [x0, #0x8]
    bb0c:      	orr	x20, x2, xzr
    bb10:      	ldr	x2, [x1]
    bb14:      	ldr	x3, [x1, #0x8]
    bb18:      	add	x16, sp, #0x10
    bb1c:      	movz	x17, #0x0, lsl #48
    bb20:      	str	x17, [x16]
    bb24:      	add	x16, sp, #0x10
    bb28:      	movz	x17, #0x0, lsl #48
    bb2c:      	str	x17, [x16, #0x8]
    bb30:      	add	x16, sp, #0x10
    bb34:      	movz	x17, #0x0, lsl #48
    bb38:      	str	x17, [x16, #0x10]
    bb3c:      	add	x16, sp, #0x10
    bb40:      	str	x2, [x16, #0x18]
    bb44:      	add	x16, sp, #0x10
    bb48:      	str	x3, [x16, #0x20]
    bb4c:      	add	x16, sp, #0x10
    bb50:      	movz	x17, #0x0, lsl #48
    bb54:      	str	x17, [x16, #0x28]
    bb58:      	add	x16, sp, #0x10
    bb5c:      	movz	x17, #0x0, lsl #48
    bb60:      	str	x17, [x16, #0x30]
    bb64:      	add	x16, sp, #0x10
    bb68:      	movz	x17, #0x0, lsl #48
    bb6c:      	str	x17, [x16, #0x38]
    bb70:      	add	x16, sp, #0x10
    bb74:      	str	x2, [x16, #0x40]
    bb78:      	add	x16, sp, #0x10
    bb7c:      	str	x3, [x16, #0x48]
    bb80:      	ldr	x2, [x1]
    bb84:      	ldr	x3, [x1, #0x8]
    bb88:      	add	x16, sp, #0x60
    bb8c:      	movz	x17, #0x0, lsl #48
    bb90:      	str	x17, [x16]
    bb94:      	add	x16, sp, #0x60
    bb98:      	movz	x17, #0x0, lsl #48
    bb9c:      	str	x17, [x16, #0x8]
    bba0:      	add	x16, sp, #0x60
    bba4:      	movz	x17, #0x0, lsl #48
    bba8:      	str	x17, [x16, #0x10]
    bbac:      	add	x16, sp, #0x60
    bbb0:      	str	x2, [x16, #0x18]
    bbb4:      	add	x16, sp, #0x60
    bbb8:      	str	x3, [x16, #0x20]
    bbbc:      	ldr	x2, [x1]
    bbc0:      	ldr	x3, [x1, #0x8]
    bbc4:      	add	x16, sp, #0x90
    bbc8:      	movz	x17, #0x0, lsl #48
    bbcc:      	str	x17, [x16]
    bbd0:      	add	x16, sp, #0x90
    bbd4:      	movz	x17, #0x0, lsl #48
    bbd8:      	str	x17, [x16, #0x8]
    bbdc:      	add	x16, sp, #0x90
    bbe0:      	movz	x17, #0x0, lsl #48
    bbe4:      	str	x17, [x16, #0x10]
    bbe8:      	add	x16, sp, #0x90
    bbec:      	str	x2, [x16, #0x18]
    bbf0:      	add	x16, sp, #0x90
    bbf4:      	str	x3, [x16, #0x20]
    bbf8:      	ldr	x2, [x1]
    bbfc:      	ldr	x1, [x1, #0x8]
    bc00:      	add	x16, sp, #0xc0
    bc04:      	movz	x17, #0x0, lsl #48
    bc08:      	str	x17, [x16]
    bc0c:      	add	x16, sp, #0xc0
    bc10:      	movz	x17, #0x0, lsl #48
    bc14:      	str	x17, [x16, #0x8]
    bc18:      	add	x16, sp, #0xc0
    bc1c:      	movz	x17, #0x0, lsl #48
    bc20:      	str	x17, [x16, #0x10]
    bc24:      	add	x16, sp, #0xc0
    bc28:      	str	x2, [x16, #0x18]
    bc2c:      	add	x16, sp, #0xc0
    bc30:      	str	x1, [x16, #0x20]
    bc34:      	add	x16, sp, #0x10
    bc38:      	ldr	x1, [x16, #0x8]
    bc3c:      	orr	x21, x1, xzr
    bc40:      	add	x16, sp, #0x10
    bc44:      	ldr	x1, [x16, #0x10]
    bc48:      	add	x22, x21, x20
    bc4c:      	cmp	x22, x1
    bc50:      	b.le	0xc228 <_stogir.dominators.build-index+0x760>
    bc54:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    bc58:      	cmp	x1, x17
    bc5c:      	b.gt	0xbc68 <_stogir.dominators.build-index+0x1a0>
    bc60:      	lsl	x1, x1, #1
    bc64:      	b	0xbc6c <_stogir.dominators.build-index+0x1a4>
    bc68:      	mov	x1, x22
    bc6c:      	cmp	x1, x22
    bc70:      	b.gt	0xbc78 <_stogir.dominators.build-index+0x1b0>
    bc74:      	mov	x1, x22
    bc78:      	mov	x23, x8
    bc7c:      	mov	x24, x0
    bc80:      	mov	x0, x19
    bc84:      	bl	0xbc84 <_stogir.dominators.build-index+0x1bc>
		000000000000bc84:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    bc88:      	add	x19, x19, #0x28
    bc8c:      	lsl	x0, x20, #2
    bc90:      	add	x16, sp, #0x10
    bc94:      	ldr	x1, [x16]
    bc98:      	add	x1, x1, x21, lsl #2
    bc9c:      	mov	x2, x0
    bca0:      	mov	x0, x1
    bca4:      	movz	x1, #0x0, lsl #48
    bca8:      	bl	0xbca8 <_stogir.dominators.build-index+0x1e0>
		000000000000bca8:  ARM64_RELOC_BRANCH26	_memset
    bcac:      	add	x16, sp, #0x10
    bcb0:      	str	x22, [x16, #0x8]
    bcb4:      	ldr	x0, [x19, #0x8]
    bcb8:      	orr	x21, x0, xzr
    bcbc:      	ldr	x0, [x19, #0x10]
    bcc0:      	add	x22, x21, x20
    bcc4:      	cmp	x22, x0
    bcc8:      	b.le	0xbcfc <_stogir.dominators.build-index+0x234>
    bccc:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    bcd0:      	cmp	x0, x17
    bcd4:      	b.gt	0xbce0 <_stogir.dominators.build-index+0x218>
    bcd8:      	lsl	x0, x0, #1
    bcdc:      	b	0xbce4 <_stogir.dominators.build-index+0x21c>
    bce0:      	mov	x0, x22
    bce4:      	cmp	x0, x22
    bce8:      	b.gt	0xbcf0 <_stogir.dominators.build-index+0x228>
    bcec:      	mov	x0, x22
    bcf0:      	mov	x1, x0
    bcf4:      	mov	x0, x19
    bcf8:      	bl	0xbcf8 <_stogir.dominators.build-index+0x230>
		000000000000bcf8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    bcfc:      	add	x16, sp, #0x60
    bd00:      	orr	x25, x16, xzr
    bd04:      	lsl	x0, x20, #2
    bd08:      	add	x16, sp, #0x10
    bd0c:      	ldr	x1, [x16, #0x28]
    bd10:      	add	x1, x1, x21, lsl #2
    bd14:      	mov	x2, x0
    bd18:      	mov	x0, x1
    bd1c:      	movz	x1, #0x0, lsl #48
    bd20:      	bl	0xbd20 <_stogir.dominators.build-index+0x258>
		000000000000bd20:  ARM64_RELOC_BRANCH26	_memset
    bd24:      	str	x22, [x19, #0x8]
    bd28:      	add	x16, sp, #0x60
    bd2c:      	ldr	x0, [x16, #0x8]
    bd30:      	orr	x19, x0, xzr
    bd34:      	add	x16, sp, #0x60
    bd38:      	ldr	x0, [x16, #0x10]
    bd3c:      	add	x21, x19, x20
    bd40:      	cmp	x21, x0
    bd44:      	b.le	0xbd78 <_stogir.dominators.build-index+0x2b0>
    bd48:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    bd4c:      	cmp	x0, x17
    bd50:      	b.gt	0xbd5c <_stogir.dominators.build-index+0x294>
    bd54:      	lsl	x0, x0, #1
    bd58:      	b	0xbd60 <_stogir.dominators.build-index+0x298>
    bd5c:      	mov	x0, x21
    bd60:      	cmp	x0, x21
    bd64:      	b.gt	0xbd6c <_stogir.dominators.build-index+0x2a4>
    bd68:      	mov	x0, x21
    bd6c:      	mov	x1, x0
    bd70:      	mov	x0, x25
    bd74:      	bl	0xbd74 <_stogir.dominators.build-index+0x2ac>
		000000000000bd74:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    bd78:      	add	x16, sp, #0x90
    bd7c:      	orr	x22, x16, xzr
    bd80:      	lsl	x0, x20, #2
    bd84:      	add	x16, sp, #0x60
    bd88:      	ldr	x1, [x16]
    bd8c:      	add	x1, x1, x19, lsl #2
    bd90:      	mov	x2, x0
    bd94:      	mov	x0, x1
    bd98:      	movz	x1, #0x0, lsl #48
    bd9c:      	bl	0xbd9c <_stogir.dominators.build-index+0x2d4>
		000000000000bd9c:  ARM64_RELOC_BRANCH26	_memset
    bda0:      	add	x16, sp, #0x60
    bda4:      	str	x21, [x16, #0x8]
    bda8:      	mov	x0, x22
    bdac:      	mov	x1, x20
    bdb0:      	bl	0xbdb0 <_stogir.dominators.build-index+0x2e8>
		000000000000bdb0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    bdb4:      	movz	x0, #0x0, lsl #48
    bdb8:      	b	0xbdf4 <_stogir.dominators.build-index+0x32c>
    bdbc:      	nop
    bdc0:      	orr	w2, w0, wzr
    bdc4:      	add	x16, sp, #0x60
    bdc8:      	ldr	x3, [x16]
    bdcc:      	add	x3, x3, x1, lsl #2
    bdd0:      	ldr	w3, [x3]
    bdd4:      	add	x16, sp, #0x90
    bdd8:      	ldr	x4, [x16]
    bddc:      	add	x4, x4, x0, lsl #2
    bde0:      	str	w3, [x4]
    bde4:      	add	x16, sp, #0x60
    bde8:      	ldr	x3, [x16]
    bdec:      	add	x1, x3, x1, lsl #2
    bdf0:      	str	w2, [x1]
    bdf4:      	add	x0, x0, #0x1
    bdf8:      	cmp	x0, x20
    bdfc:      	b.ge	0xbe24 <_stogir.dominators.build-index+0x35c>
    be00:      	ldr	x1, [x24]
    be04:      	add	x1, x1, x0, lsl #2
    be08:      	ldr	w1, [x1]
    be0c:      	sxtw	x1, w1
    be10:      	cmp	x1, #0x0
    be14:      	b.le	0xbdf4 <_stogir.dominators.build-index+0x32c>
    be18:      	cmp	x1, x0
    be1c:      	b.ne	0xbdc0 <_stogir.dominators.build-index+0x2f8>
    be20:      	b	0xbdf4 <_stogir.dominators.build-index+0x32c>
    be24:      	add	x16, sp, #0xc0
    be28:      	orr	x19, x16, xzr
    be2c:      	movz	x21, #0x0, lsl #48
    be30:      	movz	x0, #0x0, lsl #48
    be34:      	b	0xbf78 <_stogir.dominators.build-index+0x4b0>
    be38:      	lsl	x0, x0, #1
    be3c:      	mov	x1, x0
    be40:      	mov	x0, x19
    be44:      	bl	0xbe44 <_stogir.dominators.build-index+0x37c>
		000000000000be44:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    be48:      	sxtw	x0, w26
    be4c:      	orr	w1, w21, wzr
    be50:      	add	x2, x27, #0x1
    be54:      	add	x16, sp, #0xc0
    be58:      	ldr	x3, [x16]
    be5c:      	add	x3, x3, x27, lsl #2
    be60:      	str	w1, [x3]
    be64:      	add	x16, sp, #0xc0
    be68:      	str	x2, [x16, #0x8]
    be6c:      	b	0xbea0 <_stogir.dominators.build-index+0x3d8>
    be70:      	lsl	x0, x0, #1
    be74:      	mov	x1, x0
    be78:      	mov	x0, x19
    be7c:      	bl	0xbe7c <_stogir.dominators.build-index+0x3b4>
		000000000000be7c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    be80:      	sxtw	x0, w27
    be84:      	add	x1, x28, #0x1
    be88:      	add	x16, sp, #0xc0
    be8c:      	ldr	x2, [x16]
    be90:      	add	x2, x2, x28, lsl #2
    be94:      	str	w26, [x2]
    be98:      	add	x16, sp, #0xc0
    be9c:      	str	x1, [x16, #0x8]
    bea0:      	add	x16, sp, #0xc0
    bea4:      	ldr	x1, [x16, #0x8]
    bea8:      	cmp	x1, #0x0
    beac:      	b.le	0xbf78 <_stogir.dominators.build-index+0x4b0>
    beb0:      	add	x16, sp, #0xc0
    beb4:      	ldr	x2, [x16]
    beb8:      	sub	x1, x1, #0x1
    bebc:      	add	x1, x2, x1, lsl #2
    bec0:      	ldr	w1, [x1]
    bec4:      	sxtw	x1, w1
    bec8:      	add	x16, sp, #0x60
    becc:      	ldr	x2, [x16]
    bed0:      	add	x3, x2, x1, lsl #2
    bed4:      	ldr	w26, [x3]
    bed8:      	sxtw	x3, w26
    bedc:      	cmp	x3, #0x0
    bee0:      	b.le	0xbf40 <_stogir.dominators.build-index+0x478>
    bee4:      	add	x0, x0, #0x1
    bee8:      	add	x16, sp, #0x90
    beec:      	ldr	x4, [x16]
    bef0:      	orr	w27, w0, wzr
    bef4:      	add	x0, x2, x1, lsl #2
    bef8:      	add	x1, x4, x3, lsl #2
    befc:      	ldr	w1, [x1]
    bf00:      	str	w1, [x0]
    bf04:      	add	x16, sp, #0x10
    bf08:      	ldr	x0, [x16]
    bf0c:      	add	x0, x0, x3, lsl #2
    bf10:      	str	w27, [x0]
    bf14:      	add	x16, sp, #0xc0
    bf18:      	ldr	x0, [x16, #0x8]
    bf1c:      	orr	x28, x0, xzr
    bf20:      	add	x16, sp, #0xc0
    bf24:      	ldr	x0, [x16, #0x10]
    bf28:      	cmp	x28, x0
    bf2c:      	b.lt	0xbe80 <_stogir.dominators.build-index+0x3b8>
    bf30:      	cmp	x0, #0x0
    bf34:      	b.ne	0xbe70 <_stogir.dominators.build-index+0x3a8>
    bf38:      	mov	x0, #0x2                ; =2
    bf3c:      	b	0xbe74 <_stogir.dominators.build-index+0x3ac>
    bf40:      	orr	w2, w0, wzr
    bf44:      	add	x16, sp, #0x10
    bf48:      	ldr	x3, [x16, #0x28]
    bf4c:      	add	x1, x3, x1, lsl #2
    bf50:      	str	w2, [x1]
    bf54:      	add	x16, sp, #0xc0
    bf58:      	ldr	x1, [x16, #0x8]
    bf5c:      	cmp	x1, #0x0
    bf60:      	b.eq	0xbea0 <_stogir.dominators.build-index+0x3d8>
    bf64:      	sub	x1, x1, #0x1
    bf68:      	add	x16, sp, #0xc0
    bf6c:      	str	x1, [x16, #0x8]
    bf70:      	b	0xbea0 <_stogir.dominators.build-index+0x3d8>
    bf74:      	nop
    bf78:      	add	x21, x21, #0x1
    bf7c:      	cmp	x21, x20
    bf80:      	b.ge	0xbfe0 <_stogir.dominators.build-index+0x518>
    bf84:      	ldr	x1, [x24]
    bf88:      	add	x1, x1, x21, lsl #2
    bf8c:      	ldr	w1, [x1]
    bf90:      	sxtw	x1, w1
    bf94:      	cmp	x1, x21
    bf98:      	b.ne	0xbf78 <_stogir.dominators.build-index+0x4b0>
    bf9c:      	add	x0, x0, #0x1
    bfa0:      	add	x16, sp, #0x10
    bfa4:      	ldr	x1, [x16]
    bfa8:      	orr	w26, w0, wzr
    bfac:      	add	x0, x1, x21, lsl #2
    bfb0:      	str	w26, [x0]
    bfb4:      	add	x16, sp, #0xc0
    bfb8:      	ldr	x0, [x16, #0x8]
    bfbc:      	orr	x27, x0, xzr
    bfc0:      	add	x16, sp, #0xc0
    bfc4:      	ldr	x0, [x16, #0x10]
    bfc8:      	cmp	x27, x0
    bfcc:      	b.lt	0xbe48 <_stogir.dominators.build-index+0x380>
    bfd0:      	cmp	x0, #0x0
    bfd4:      	b.ne	0xbe38 <_stogir.dominators.build-index+0x370>
    bfd8:      	mov	x0, #0x2                ; =2
    bfdc:      	b	0xbe3c <_stogir.dominators.build-index+0x374>
    bfe0:      	b	0xbff4 <_stogir.dominators.build-index+0x52c>
    bfe4:      	nop
    bfe8:      	sub	x0, x0, #0x1
    bfec:      	add	x16, sp, #0xc0
    bff0:      	str	x0, [x16, #0x8]
    bff4:      	add	x16, sp, #0xc0
    bff8:      	ldr	x0, [x16, #0x8]
    bffc:      	cmp	x0, #0x0
    c000:      	b.ne	0xbfe8 <_stogir.dominators.build-index+0x520>
    c004:      	add	x16, sp, #0xc0
    c008:      	ldr	x0, [x16, #0x10]
    c00c:      	cmp	x0, #0x0
    c010:      	b.le	0xc044 <_stogir.dominators.build-index+0x57c>
    c014:      	add	x1, x19, #0x18
    c018:      	add	x16, sp, #0xc0
    c01c:      	ldr	x2, [x16]
    c020:      	fmov	d31, x0
    c024:      	mov	x0, x1
    c028:      	mov	x1, x2
    c02c:      	fmov	x2, d31
    c030:      	adrp	x3, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c030:  ARM64_RELOC_PAGE21	l_stogir.495
    c034:      	ldr	x3, [x3]
		000000000000c034:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    c038:      	mov	x4, #0x4                ; =4
    c03c:      	mov	x5, #0x4                ; =4
    c040:      	bl	0xc040 <_stogir.dominators.build-index+0x578>
		000000000000c040:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    c044:      	add	x16, sp, #0xc0
    c048:      	movz	x17, #0x0, lsl #48
    c04c:      	str	x17, [x16]
    c050:      	add	x16, sp, #0xc0
    c054:      	movz	x17, #0x0, lsl #48
    c058:      	str	x17, [x16, #0x8]
    c05c:      	add	x16, sp, #0xc0
    c060:      	movz	x17, #0x0, lsl #48
    c064:      	str	x17, [x16, #0x10]
    c068:      	b	0xc07c <_stogir.dominators.build-index+0x5b4>
    c06c:      	nop
    c070:      	sub	x0, x0, #0x1
    c074:      	add	x16, sp, #0x90
    c078:      	str	x0, [x16, #0x8]
    c07c:      	add	x16, sp, #0x90
    c080:      	ldr	x0, [x16, #0x8]
    c084:      	cmp	x0, #0x0
    c088:      	b.ne	0xc070 <_stogir.dominators.build-index+0x5a8>
    c08c:      	add	x16, sp, #0x90
    c090:      	ldr	x0, [x16, #0x10]
    c094:      	cmp	x0, #0x0
    c098:      	b.le	0xc0cc <_stogir.dominators.build-index+0x604>
    c09c:      	add	x1, x22, #0x18
    c0a0:      	add	x16, sp, #0x90
    c0a4:      	ldr	x2, [x16]
    c0a8:      	fmov	d31, x0
    c0ac:      	mov	x0, x1
    c0b0:      	mov	x1, x2
    c0b4:      	fmov	x2, d31
    c0b8:      	adrp	x3, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c0b8:  ARM64_RELOC_PAGE21	l_stogir.495
    c0bc:      	ldr	x3, [x3]
		000000000000c0bc:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    c0c0:      	mov	x4, #0x4                ; =4
    c0c4:      	mov	x5, #0x4                ; =4
    c0c8:      	bl	0xc0c8 <_stogir.dominators.build-index+0x600>
		000000000000c0c8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    c0cc:      	add	x16, sp, #0x90
    c0d0:      	movz	x17, #0x0, lsl #48
    c0d4:      	str	x17, [x16]
    c0d8:      	add	x16, sp, #0x90
    c0dc:      	movz	x17, #0x0, lsl #48
    c0e0:      	str	x17, [x16, #0x8]
    c0e4:      	add	x16, sp, #0x90
    c0e8:      	movz	x17, #0x0, lsl #48
    c0ec:      	str	x17, [x16, #0x10]
    c0f0:      	b	0xc104 <_stogir.dominators.build-index+0x63c>
    c0f4:      	nop
    c0f8:      	sub	x0, x0, #0x1
    c0fc:      	add	x16, sp, #0x60
    c100:      	str	x0, [x16, #0x8]
    c104:      	add	x16, sp, #0x60
    c108:      	ldr	x0, [x16, #0x8]
    c10c:      	cmp	x0, #0x0
    c110:      	b.ne	0xc0f8 <_stogir.dominators.build-index+0x630>
    c114:      	add	x16, sp, #0x60
    c118:      	ldr	x0, [x16, #0x10]
    c11c:      	cmp	x0, #0x0
    c120:      	b.le	0xc154 <_stogir.dominators.build-index+0x68c>
    c124:      	add	x1, x25, #0x18
    c128:      	add	x16, sp, #0x60
    c12c:      	ldr	x2, [x16]
    c130:      	fmov	d31, x0
    c134:      	mov	x0, x1
    c138:      	mov	x1, x2
    c13c:      	fmov	x2, d31
    c140:      	adrp	x3, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c140:  ARM64_RELOC_PAGE21	l_stogir.495
    c144:      	ldr	x3, [x3]
		000000000000c144:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    c148:      	mov	x4, #0x4                ; =4
    c14c:      	mov	x5, #0x4                ; =4
    c150:      	bl	0xc150 <_stogir.dominators.build-index+0x688>
		000000000000c150:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    c154:      	add	x16, sp, #0x60
    c158:      	movz	x17, #0x0, lsl #48
    c15c:      	str	x17, [x16]
    c160:      	add	x16, sp, #0x60
    c164:      	movz	x17, #0x0, lsl #48
    c168:      	str	x17, [x16, #0x8]
    c16c:      	add	x16, sp, #0x60
    c170:      	movz	x17, #0x0, lsl #48
    c174:      	str	x17, [x16, #0x10]
    c178:      	add	x16, sp, #0x10
    c17c:      	ldr	x0, [x16]
    c180:      	add	x16, sp, #0x10
    c184:      	ldr	x1, [x16, #0x8]
    c188:      	add	x16, sp, #0x10
    c18c:      	ldr	x2, [x16, #0x10]
    c190:      	add	x16, sp, #0x10
    c194:      	ldr	x3, [x16, #0x18]
    c198:      	add	x16, sp, #0x10
    c19c:      	ldr	x4, [x16, #0x20]
    c1a0:      	add	x16, sp, #0x10
    c1a4:      	ldr	x5, [x16, #0x28]
    c1a8:      	add	x16, sp, #0x10
    c1ac:      	ldr	x6, [x16, #0x30]
    c1b0:      	add	x16, sp, #0x10
    c1b4:      	ldr	x7, [x16, #0x38]
    c1b8:      	add	x16, sp, #0x10
    c1bc:      	ldr	x8, [x16, #0x40]
    c1c0:      	add	x16, sp, #0x10
    c1c4:      	ldr	x9, [x16, #0x48]
    c1c8:      	str	x0, [x23]
    c1cc:      	str	x1, [x23, #0x8]
    c1d0:      	str	x2, [x23, #0x10]
    c1d4:      	str	x3, [x23, #0x18]
    c1d8:      	str	x4, [x23, #0x20]
    c1dc:      	str	x5, [x23, #0x28]
    c1e0:      	str	x6, [x23, #0x30]
    c1e4:      	str	x7, [x23, #0x38]
    c1e8:      	str	x8, [x23, #0x40]
    c1ec:      	str	x9, [x23, #0x48]
    c1f0:      	ldr	x19, [sp, #0xf0]
    c1f4:      	ldr	x20, [sp, #0xf8]
    c1f8:      	ldr	x21, [sp, #0x100]
    c1fc:      	ldr	x22, [sp, #0x108]
    c200:      	ldr	x23, [sp, #0x110]
    c204:      	ldr	x24, [sp, #0x118]
    c208:      	ldr	x25, [sp, #0x120]
    c20c:      	ldr	x26, [sp, #0x128]
    c210:      	ldr	x27, [sp, #0x130]
    c214:      	ldr	x28, [sp, #0x138]
    c218:      	ldr	x29, [sp]
    c21c:      	ldr	x30, [sp, #0x8]
    c220:      	add	sp, sp, #0x140
    c224:      	ret
    c228:      	mov	x23, x8
    c22c:      	mov	x24, x0
    c230:      	b	0xbc88 <_stogir.dominators.build-index+0x1c0>
    c234:      	udf	#0x0

000000000000c238 <_stogir.dominators.release-index!>:
    c238:      	sub	sp, sp, #0x20
    c23c:      	str	x29, [sp]
    c240:      	str	x30, [sp, #0x8]
    c244:      	mov	x29, sp
    c248:      	str	x19, [sp, #0x10]
    c24c:      	str	x20, [sp, #0x18]
    c250:      	b	0xc260 <_stogir.dominators.release-index!+0x28>
    c254:      	nop
    c258:      	sub	x1, x1, #0x1
    c25c:      	str	x1, [x0, #0x8]
    c260:      	ldr	x1, [x0, #0x8]
    c264:      	cmp	x1, #0x0
    c268:      	b.ne	0xc258 <_stogir.dominators.release-index!+0x20>
    c26c:      	ldr	x1, [x0, #0x10]
    c270:      	cmp	x1, #0x0
    c274:      	b.le	0xc344 <_stogir.dominators.release-index!+0x10c>
    c278:      	add	x2, x0, #0x18
    c27c:      	ldr	x3, [x0]
    c280:      	mov	x19, x0
    c284:      	mov	x0, x2
    c288:      	mov	x2, x1
    c28c:      	mov	x1, x3
    c290:      	adrp	x3, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c290:  ARM64_RELOC_PAGE21	l_stogir.496
    c294:      	ldr	x3, [x3]
		000000000000c294:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    c298:      	mov	x4, #0x4                ; =4
    c29c:      	mov	x5, #0x4                ; =4
    c2a0:      	bl	0xc2a0 <_stogir.dominators.release-index!+0x68>
		000000000000c2a0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    c2a4:      	add	x20, x19, #0x28
    c2a8:      	movz	x17, #0x0, lsl #48
    c2ac:      	str	x17, [x19]
    c2b0:      	movz	x17, #0x0, lsl #48
    c2b4:      	str	x17, [x19, #0x8]
    c2b8:      	movz	x17, #0x0, lsl #48
    c2bc:      	str	x17, [x19, #0x10]
    c2c0:      	b	0xc2d0 <_stogir.dominators.release-index!+0x98>
    c2c4:      	nop
    c2c8:      	sub	x0, x0, #0x1
    c2cc:      	str	x0, [x20, #0x8]
    c2d0:      	ldr	x0, [x20, #0x8]
    c2d4:      	cmp	x0, #0x0
    c2d8:      	b.ne	0xc2c8 <_stogir.dominators.release-index!+0x90>
    c2dc:      	ldr	x0, [x20, #0x10]
    c2e0:      	cmp	x0, #0x0
    c2e4:      	b.le	0xc314 <_stogir.dominators.release-index!+0xdc>
    c2e8:      	add	x1, x20, #0x18
    c2ec:      	ldr	x2, [x19, #0x28]
    c2f0:      	fmov	d31, x0
    c2f4:      	mov	x0, x1
    c2f8:      	mov	x1, x2
    c2fc:      	fmov	x2, d31
    c300:      	adrp	x3, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c300:  ARM64_RELOC_PAGE21	l_stogir.496
    c304:      	ldr	x3, [x3]
		000000000000c304:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    c308:      	mov	x4, #0x4                ; =4
    c30c:      	mov	x5, #0x4                ; =4
    c310:      	bl	0xc310 <_stogir.dominators.release-index!+0xd8>
		000000000000c310:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    c314:      	movz	x17, #0x0, lsl #48
    c318:      	str	x17, [x19, #0x28]
    c31c:      	movz	x17, #0x0, lsl #48
    c320:      	str	x17, [x20, #0x8]
    c324:      	movz	x17, #0x0, lsl #48
    c328:      	str	x17, [x20, #0x10]
    c32c:      	ldr	x19, [sp, #0x10]
    c330:      	ldr	x20, [sp, #0x18]
    c334:      	ldr	x29, [sp]
    c338:      	ldr	x30, [sp, #0x8]
    c33c:      	add	sp, sp, #0x20
    c340:      	ret
    c344:      	mov	x19, x0
    c348:      	b	0xc2a4 <_stogir.dominators.release-index!+0x6c>

000000000000c34c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64>:
    c34c:      	sub	sp, sp, #0x30
    c350:      	str	x29, [sp]
    c354:      	str	x30, [sp, #0x8]
    c358:      	mov	x29, sp
    c35c:      	str	x19, [sp, #0x10]
    c360:      	str	x20, [sp, #0x18]
    c364:      	str	x21, [sp, #0x20]
    c368:      	str	x22, [sp, #0x28]
    c36c:      	ldr	x2, [x0, #0x8]
    c370:      	orr	x19, x2, xzr
    c374:      	ldr	x2, [x0, #0x10]
    c378:      	add	x20, x19, x1
    c37c:      	cmp	x20, x2
    c380:      	b.le	0xc3fc <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0xb0>
    c384:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    c388:      	cmp	x2, x17
    c38c:      	b.gt	0xc398 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x4c>
    c390:      	lsl	x2, x2, #1
    c394:      	b	0xc39c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x50>
    c398:      	mov	x2, x20
    c39c:      	cmp	x2, x20
    c3a0:      	b.gt	0xc3a8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x5c>
    c3a4:      	mov	x2, x20
    c3a8:      	mov	x21, x0
    c3ac:      	mov	x22, x1
    c3b0:      	mov	x1, x2
    c3b4:      	bl	0xc3b4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x68>
		000000000000c3b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    c3b8:      	lsl	x0, x22, #3
    c3bc:      	ldr	x1, [x21]
    c3c0:      	add	x1, x1, x19, lsl #3
    c3c4:      	mov	x2, x0
    c3c8:      	mov	x0, x1
    c3cc:      	movz	x1, #0x0, lsl #48
    c3d0:      	bl	0xc3d0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x84>
		000000000000c3d0:  ARM64_RELOC_BRANCH26	_memset
    c3d4:      	str	x20, [x21, #0x8]
    c3d8:      	mov	x0, x20
    c3dc:      	ldr	x19, [sp, #0x10]
    c3e0:      	ldr	x20, [sp, #0x18]
    c3e4:      	ldr	x21, [sp, #0x20]
    c3e8:      	ldr	x22, [sp, #0x28]
    c3ec:      	ldr	x29, [sp]
    c3f0:      	ldr	x30, [sp, #0x8]
    c3f4:      	add	sp, sp, #0x30
    c3f8:      	ret
    c3fc:      	mov	x21, x0
    c400:      	mov	x22, x1
    c404:      	b	0xc3b8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x6c>

000000000000c408 <_stogir.uses.scan!__constfalse>:
    c408:      	sub	sp, sp, #0x10
    c40c:      	orr	x3, x2, xzr
    c410:      	mov	x4, #0x1                ; =1
    c414:      	b	0xc534 <_stogir.uses.scan!__constfalse+0x12c>
    c418:      	sub	w11, w9, #0x1
    c41c:      	lsl	w11, w11, #2
    c420:      	ubfx	x11, x11, #0, #32
    c424:      	lsr	x11, x6, x11
    c428:      	and	w11, w11, #0xf
    c42c:      	b	0xc434 <_stogir.uses.scan!__constfalse+0x2c>
    c430:      	movz	w11, #0x0, lsl #16
    c434:      	ubfx	x11, x11, #0, #32
    c438:      	cmp	x11, #0xf
    c43c:      	b.hs	0xc4ec <_stogir.uses.scan!__constfalse+0xe4>
    c440:      	mov	x16, #0x1               ; =1
    c444:      	lsl	x11, x16, x11
    c448:      	mov	w17, #0x5e1c            ; =24092
    c44c:      	and	w11, w11, w17
    c450:      	ubfx	x11, x11, #0, #32
    c454:      	cmp	x11, #0x0
    c458:      	b.eq	0xc4ec <_stogir.uses.scan!__constfalse+0xe4>
    c45c:      	ldr	x11, [x0]
    c460:      	asr	x16, x10, #63
    c464:      	lsr	x16, x16, #62
    c468:      	add	x12, x10, x16
    c46c:      	asr	x12, x12, #2
    c470:      	asr	x16, x10, #63
    c474:      	lsr	x16, x16, #62
    c478:      	add	x10, x10, x16
    c47c:      	and	x10, x10, #0x3
    c480:      	sub	x10, x10, x16
    c484:      	add	x12, x12, x4
    c488:      	add	x11, x11, x12, lsl #4
    c48c:      	add	x10, x11, x10, lsl #2
    c490:      	ldr	w10, [x10]
    c494:      	sxtw	x10, w10
    c498:      	cmp	x10, #0x0
    c49c:      	b.le	0xc4ec <_stogir.uses.scan!__constfalse+0xe4>
    c4a0:      	ldr	x11, [x3]
    c4a4:      	add	x11, x11, x10, lsl #3
    c4a8:      	ldr	x11, [x11]
    c4ac:      	mov	x16, sp
    c4b0:      	movz	x17, #0x0, lsl #48
    c4b4:      	str	x17, [x16]
    c4b8:      	add	x12, x11, #0x1
    c4bc:      	mov	x16, sp
    c4c0:      	str	w5, [x16]
    c4c4:      	mov	x16, sp
    c4c8:      	str	w9, [x16, #0x4]
    c4cc:      	mov	x16, sp
    c4d0:      	ldr	x9, [x16]
    c4d4:      	ldr	x13, [x1, #0x28]
    c4d8:      	add	x11, x13, x11, lsl #3
    c4dc:      	str	x9, [x11]
    c4e0:      	ldr	x9, [x2]
    c4e4:      	add	x9, x9, x10, lsl #3
    c4e8:      	str	x12, [x9]
    c4ec:      	add	x8, x8, #0x1
    c4f0:      	sxtw	x8, w8
    c4f4:      	cmp	x8, x7
    c4f8:      	b.gt	0xc51c <_stogir.uses.scan!__constfalse+0x114>
    c4fc:      	orr	w9, w8, wzr
    c500:      	sxtw	x10, w9
    c504:      	cmp	x10, #0x0
    c508:      	b.le	0xc430 <_stogir.uses.scan!__constfalse+0x28>
    c50c:      	cmp	x10, #0x4
    c510:      	b.le	0xc418 <_stogir.uses.scan!__constfalse+0x10>
    c514:      	mov	w11, #0x4               ; =4
    c518:      	b	0xc41c <_stogir.uses.scan!__constfalse+0x14>
    c51c:      	add	x5, x7, #0x4
    c520:      	asr	x16, x5, #63
    c524:      	lsr	x16, x16, #62
    c528:      	add	x5, x5, x16
    c52c:      	asr	x5, x5, #2
    c530:      	add	x4, x5, x4
    c534:      	ldr	x5, [x0, #0x8]
    c538:      	cmp	x4, x5
    c53c:      	b.ge	0xc57c <_stogir.uses.scan!__constfalse+0x174>
    c540:      	orr	w5, w4, wzr
    c544:      	ldr	x6, [x0]
    c548:      	add	x6, x6, x4, lsl #4
    c54c:      	ldr	x6, [x6]
    c550:      	ldr	x7, [x0, #0x78]
    c554:      	uxtb	w6, w6
    c558:      	add	x7, x7, x4, lsl #2
    c55c:      	adrp	x16, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c55c:  ARM64_RELOC_PAGE21	l_stogir.497
    c560:      	ldr	x16, [x16]
		000000000000c560:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    c564:      	add	x6, x16, x6, lsl #2
    c568:      	ldr	w7, [x7]
    c56c:      	sxtw	x7, w7
    c570:      	ldr	w6, [x6]
    c574:      	mov	x8, #0x1                ; =1
    c578:      	b	0xc4f4 <_stogir.uses.scan!__constfalse+0xec>
    c57c:      	add	sp, sp, #0x10
    c580:      	ret

000000000000c584 <_stogir.opcode.properties>:
    c584:      	sxtw	x0, w0
    c588:      	cmp	x0, #0x0
    c58c:      	b.lt	0xc5ac <_stogir.opcode.properties+0x28>
    c590:      	cmp	x0, #0x83
    c594:      	b.ge	0xc5ac <_stogir.opcode.properties+0x28>
    c598:      	adrp	x16, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c598:  ARM64_RELOC_PAGE21	l_stogir.498
    c59c:      	ldr	x16, [x16]
		000000000000c59c:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    c5a0:      	add	x0, x16, x0
    c5a4:      	ldrb	w0, [x0]
    c5a8:      	b	0xc5b0 <_stogir.opcode.properties+0x2c>
    c5ac:      	movz	x0, #0x0, lsl #48
    c5b0:      	ret

000000000000c5b4 <_stogir.graph.lookup>:
    c5b4:      	sxtw	x1, w1
    c5b8:      	cmp	x1, #0x0
    c5bc:      	cset	w2, gt
    c5c0:      	movz	x16, #0x0, lsl #48
    c5c4:      	sub	x3, x16, x1
    c5c8:      	sub	x4, x3, #0x1
    c5cc:      	uxtb	w16, w2
    c5d0:      	cmp	w16, wzr
    c5d4:      	b.eq	0xc614 <_stogir.graph.lookup+0x60>
    c5d8:      	ldr	x3, [x0, #0x8]
    c5dc:      	cmp	x1, x3
    c5e0:      	b.ge	0xc664 <_stogir.graph.lookup+0xb0>
    c5e4:      	add	x3, x0, #0x78
    c5e8:      	ldr	x3, [x3, #0x8]
    c5ec:      	cmp	x1, x3
    c5f0:      	b.ge	0xc6dc <_stogir.graph.lookup+0x128>
    c5f4:      	ldr	x3, [x0, #0x78]
    c5f8:      	add	x3, x3, x1, lsl #2
    c5fc:      	ldr	w3, [x3]
    c600:      	sxtw	x3, w3
    c604:      	cmp	x3, #0x0
    c608:      	cset	w3, ge
    c60c:      	ubfx	x3, x3, #0, #8
    c610:      	b	0xc6e0 <_stogir.graph.lookup+0x12c>
    c614:      	cmp	x1, #0x0
    c618:      	b.ge	0xc66c <_stogir.graph.lookup+0xb8>
    c61c:      	add	x5, x0, #0x28
    c620:      	add	x6, x0, #0x50
    c624:      	ldr	x5, [x5, #0x8]
    c628:      	ldr	x6, [x6, #0x8]
    c62c:      	cmp	x5, x6
    c630:      	b.ne	0xc65c <_stogir.graph.lookup+0xa8>
    c634:      	cmp	x3, x5
    c638:      	b.gt	0xc6e4 <_stogir.graph.lookup+0x130>
    c63c:      	ldr	x3, [x0, #0x50]
    c640:      	add	x3, x3, x4, lsl #2
    c644:      	ldr	w3, [x3]
    c648:      	sxtw	x3, w3
    c64c:      	cmp	x3, #0x0
    c650:      	cset	w3, gt
    c654:      	ubfx	x3, x3, #0, #8
    c658:      	b	0xc6e8 <_stogir.graph.lookup+0x134>
    c65c:      	movz	x3, #0x0, lsl #48
    c660:      	b	0xc670 <_stogir.graph.lookup+0xbc>
    c664:      	movz	x3, #0x0, lsl #48
    c668:      	b	0xc670 <_stogir.graph.lookup+0xbc>
    c66c:      	movz	x3, #0x0, lsl #48
    c670:      	cmp	x3, #0x0
    c674:      	b.eq	0xc6b0 <_stogir.graph.lookup+0xfc>
    c678:      	uxtb	w16, w2
    c67c:      	cmp	w16, wzr
    c680:      	b.eq	0xc698 <_stogir.graph.lookup+0xe4>
    c684:      	ldr	x0, [x0]
    c688:      	add	x0, x0, x1, lsl #4
    c68c:      	ldr	x1, [x0]
    c690:      	ldr	x0, [x0, #0x8]
    c694:      	b	0xc6a8 <_stogir.graph.lookup+0xf4>
    c698:      	ldr	x0, [x0, #0x28]
    c69c:      	add	x0, x0, x4, lsl #4
    c6a0:      	ldr	x1, [x0]
    c6a4:      	ldr	x0, [x0, #0x8]
    c6a8:      	mov	x2, #0x1                ; =1
    c6ac:      	b	0xc6bc <_stogir.graph.lookup+0x108>
    c6b0:      	movz	x2, #0x0, lsl #48
    c6b4:      	movz	x1, #0x0, lsl #48
    c6b8:      	movz	x0, #0x0, lsl #48
    c6bc:      	str	x2, [x8]
    c6c0:      	str	x1, [x8, #0x8]
    c6c4:      	str	x0, [x8, #0x10]
    c6c8:      	movz	x17, #0x0, lsl #48
    c6cc:      	str	x17, [x8, #0x18]
    c6d0:      	movz	x17, #0x0, lsl #48
    c6d4:      	str	x17, [x8, #0x20]
    c6d8:      	ret
    c6dc:      	movz	x3, #0x0, lsl #48
    c6e0:      	b	0xc668 <_stogir.graph.lookup+0xb4>
    c6e4:      	movz	x3, #0x0, lsl #48
    c6e8:      	b	0xc660 <_stogir.graph.lookup+0xac>
    c6ec:      	udf	#0x0

000000000000c6f0 <_stogir.dominators.dominates?>:
    c6f0:      	sxtw	x1, w1
    c6f4:      	sxtw	x2, w2
    c6f8:      	movz	x3, #0x0, lsl #48
    c6fc:      	movz	x4, #0x0, lsl #48
    c700:      	b	0xc714 <_stogir.dominators.dominates?+0x24>
    c704:      	mov	x2, x5
    c708:      	b	0xc714 <_stogir.dominators.dominates?+0x24>
    c70c:      	nop
    c710:      	mov	x3, #0x1                ; =1
    c714:      	cmp	x3, #0x0
    c718:      	b.ne	0xc764 <_stogir.dominators.dominates?+0x74>
    c71c:      	cmp	x2, #0x0
    c720:      	b.le	0xc710 <_stogir.dominators.dominates?+0x20>
    c724:      	ldr	x5, [x0, #0x8]
    c728:      	cmp	x2, x5
    c72c:      	b.ge	0xc710 <_stogir.dominators.dominates?+0x20>
    c730:      	ldr	x5, [x0]
    c734:      	add	x5, x5, x2, lsl #2
    c738:      	ldr	w5, [x5]
    c73c:      	sxtw	x5, w5
    c740:      	cmp	x5, #0x0
    c744:      	b.ne	0xc750 <_stogir.dominators.dominates?+0x60>
    c748:      	mov	x3, #0x1                ; =1
    c74c:      	b	0xc708 <_stogir.dominators.dominates?+0x18>
    c750:      	cmp	x2, x1
    c754:      	b.ne	0xc76c <_stogir.dominators.dominates?+0x7c>
    c758:      	mov	x3, #0x1                ; =1
    c75c:      	mov	x4, #0x1                ; =1
    c760:      	b	0xc708 <_stogir.dominators.dominates?+0x18>
    c764:      	mov	x0, x4
    c768:      	ret
    c76c:      	cmp	x2, x5
    c770:      	b.ne	0xc704 <_stogir.dominators.dominates?+0x14>
    c774:      	mov	x3, #0x1                ; =1
    c778:      	b	0xc708 <_stogir.dominators.dominates?+0x18>

000000000000c77c <_stogir.placement.use-block>:
    c77c:      	sub	sp, sp, #0x50
    c780:      	str	x29, [sp, #0x10]
    c784:      	str	x30, [sp, #0x18]
    c788:      	add	x29, sp, #0x10
    c78c:      	str	x19, [sp, #0x30]
    c790:      	str	x20, [sp, #0x38]
    c794:      	str	x21, [sp, #0x40]
    c798:      	sxtw	x2, w2
    c79c:      	lsl	x4, x2, #2
    c7a0:      	cmp	x2, #0x0
    c7a4:      	cset	w5, gt
    c7a8:      	movz	x16, #0x0, lsl #48
    c7ac:      	sub	x6, x16, x2
    c7b0:      	sub	x7, x6, #0x1
    c7b4:      	uxtb	w16, w5
    c7b8:      	cmp	w16, wzr
    c7bc:      	b.eq	0xc7fc <_stogir.placement.use-block+0x80>
    c7c0:      	ldr	x6, [x0, #0x8]
    c7c4:      	cmp	x2, x6
    c7c8:      	b.ge	0xc84c <_stogir.placement.use-block+0xd0>
    c7cc:      	add	x6, x0, #0x78
    c7d0:      	ldr	x6, [x6, #0x8]
    c7d4:      	cmp	x2, x6
    c7d8:      	b.ge	0xc928 <_stogir.placement.use-block+0x1ac>
    c7dc:      	ldr	x6, [x0, #0x78]
    c7e0:      	add	x6, x4, x6
    c7e4:      	ldr	w6, [x6]
    c7e8:      	sxtw	x6, w6
    c7ec:      	cmp	x6, #0x0
    c7f0:      	cset	w6, ge
    c7f4:      	ubfx	x6, x6, #0, #8
    c7f8:      	b	0xc92c <_stogir.placement.use-block+0x1b0>
    c7fc:      	cmp	x2, #0x0
    c800:      	b.ge	0xc854 <_stogir.placement.use-block+0xd8>
    c804:      	add	x9, x0, #0x28
    c808:      	add	x10, x0, #0x50
    c80c:      	ldr	x9, [x9, #0x8]
    c810:      	ldr	x10, [x10, #0x8]
    c814:      	cmp	x9, x10
    c818:      	b.ne	0xc844 <_stogir.placement.use-block+0xc8>
    c81c:      	cmp	x6, x9
    c820:      	b.gt	0xc944 <_stogir.placement.use-block+0x1c8>
    c824:      	ldr	x6, [x0, #0x50]
    c828:      	add	x6, x6, x7, lsl #2
    c82c:      	ldr	w6, [x6]
    c830:      	sxtw	x6, w6
    c834:      	cmp	x6, #0x0
    c838:      	cset	w6, gt
    c83c:      	ubfx	x6, x6, #0, #8
    c840:      	b	0xc948 <_stogir.placement.use-block+0x1cc>
    c844:      	movz	x6, #0x0, lsl #48
    c848:      	b	0xc858 <_stogir.placement.use-block+0xdc>
    c84c:      	movz	x6, #0x0, lsl #48
    c850:      	b	0xc858 <_stogir.placement.use-block+0xdc>
    c854:      	movz	x6, #0x0, lsl #48
    c858:      	lsl	x9, x2, #4
    c85c:      	cmp	x6, #0x0
    c860:      	b.eq	0xc894 <_stogir.placement.use-block+0x118>
    c864:      	uxtb	w16, w5
    c868:      	cmp	w16, wzr
    c86c:      	b.eq	0xc880 <_stogir.placement.use-block+0x104>
    c870:      	ldr	x5, [x0]
    c874:      	add	x5, x9, x5
    c878:      	ldr	x5, [x5]
    c87c:      	b	0xc88c <_stogir.placement.use-block+0x110>
    c880:      	ldr	x5, [x0, #0x28]
    c884:      	add	x5, x5, x7, lsl #4
    c888:      	ldr	x5, [x5]
    c88c:      	mov	w6, #0x1                ; =1
    c890:      	b	0xc89c <_stogir.placement.use-block+0x120>
    c894:      	movz	w6, #0x0, lsl #16
    c898:      	movz	x5, #0x0, lsl #48
    c89c:      	ubfx	x6, x6, #0, #32
    c8a0:      	lsr	x16, x6, #0
    c8a4:      	cmp	x16, #0x1
    c8a8:      	b.eq	0xc8c4 <_stogir.placement.use-block+0x148>
    c8ac:      	b.lo	0xc8b4 <_stogir.placement.use-block+0x138>
    c8b0:      	b	0xc8c8 <_stogir.placement.use-block+0x14c>
    c8b4:      	cmp	x16, #0x0
    c8b8:      	b.eq	0xc8c0 <_stogir.placement.use-block+0x144>
    c8bc:      	b	0xc8c8 <_stogir.placement.use-block+0x14c>
    c8c0:      	b	0xc8cc <_stogir.placement.use-block+0x150>
    c8c4:      	b	0xc908 <_stogir.placement.use-block+0x18c>
    c8c8:      	b	0xc9ec <_stogir.placement.use-block+0x270>
    c8cc:      	mov	x19, x8
    c8d0:      	mov	x1, #0x1                ; =1
    c8d4:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c8d4:  ARM64_RELOC_PAGE21	l_stogir.499
    c8d8:      	ldr	x0, [x0]
		000000000000c8d8:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    c8dc:      	mov	x2, #0x21               ; =33
    c8e0:      	str	x1, [x19]
    c8e4:      	str	x0, [x19, #0x8]
    c8e8:      	str	x2, [x19, #0x10]
    c8ec:      	ldr	x19, [sp, #0x30]
    c8f0:      	ldr	x20, [sp, #0x38]
    c8f4:      	ldr	x21, [sp, #0x40]
    c8f8:      	ldr	x29, [sp, #0x10]
    c8fc:      	ldr	x30, [sp, #0x18]
    c900:      	add	sp, sp, #0x50
    c904:      	ret
    c908:      	cmp	x2, #0x0
    c90c:      	b.gt	0xc930 <_stogir.placement.use-block+0x1b4>
    c910:      	mov	x19, x8
    c914:      	mov	x1, #0x1                ; =1
    c918:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c918:  ARM64_RELOC_PAGE21	l_stogir.500
    c91c:      	ldr	x0, [x0]
		000000000000c91c:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c920:      	mov	x2, #0x13               ; =19
    c924:      	b	0xc8e0 <_stogir.placement.use-block+0x164>
    c928:      	movz	x6, #0x0, lsl #48
    c92c:      	b	0xc850 <_stogir.placement.use-block+0xd4>
    c930:      	sxtw	x6, w3
    c934:      	cmp	x6, #0x1
    c938:      	b.ge	0xc94c <_stogir.placement.use-block+0x1d0>
    c93c:      	mov	x19, x8
    c940:      	b	0xc914 <_stogir.placement.use-block+0x198>
    c944:      	movz	x6, #0x0, lsl #48
    c948:      	b	0xc848 <_stogir.placement.use-block+0xcc>
    c94c:      	ldr	x7, [x0, #0x78]
    c950:      	add	x10, x4, x7
    c954:      	ldr	w10, [x10]
    c958:      	sxtw	x10, w10
    c95c:      	cmp	x6, x10
    c960:      	b.gt	0xcbb8 <_stogir.placement.use-block+0x43c>
    c964:      	uxtb	w5, w5
    c968:      	cmp	x5, #0x43
    c96c:      	b.ne	0xcbc0 <_stogir.placement.use-block+0x444>
    c970:      	cmp	x6, #0x2
    c974:      	b.lt	0xcbcc <_stogir.placement.use-block+0x450>
    c978:      	ldr	x5, [x0, #0x8]
    c97c:      	cmp	x2, x5
    c980:      	b.ge	0xca50 <_stogir.placement.use-block+0x2d4>
    c984:      	add	x5, x0, #0x78
    c988:      	ldr	x5, [x5, #0x8]
    c98c:      	cmp	x2, x5
    c990:      	b.ge	0xca90 <_stogir.placement.use-block+0x314>
    c994:      	add	x2, x4, x7
    c998:      	ldr	w2, [x2]
    c99c:      	sxtw	x2, w2
    c9a0:      	cmp	x2, #0x0
    c9a4:      	cset	w2, ge
    c9a8:      	ubfx	x2, x2, #0, #8
    c9ac:      	b	0xca94 <_stogir.placement.use-block+0x318>
    c9b0:      	and	x0, x0, #0xffffffff
    c9b4:      	movz	x1, #0x0, lsl #48
    c9b8:      	movz	x2, #0x0, lsl #48
    c9bc:      	b	0xc924 <_stogir.placement.use-block+0x1a8>
    c9c0:      	ldr	x0, [x21]
    c9c4:      	add	x0, x0, x2, lsl #2
    c9c8:      	ldr	w0, [x0]
    c9cc:      	sxtw	x0, w0
    c9d0:      	cmp	x0, #0x0
    c9d4:      	b.ne	0xc9b0 <_stogir.placement.use-block+0x234>
    c9d8:      	mov	x1, #0x1                ; =1
    c9dc:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000c9dc:  ARM64_RELOC_PAGE21	l_stogir.501
    c9e0:      	ldr	x0, [x0]
		000000000000c9e0:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    c9e4:      	mov	x2, #0xf                ; =15
    c9e8:      	b	0xc9bc <_stogir.placement.use-block+0x240>
    c9ec:      	brk	#0
    c9f0:      	b	0xc9ec <_stogir.placement.use-block+0x270>
    c9f4:      	movz	w4, #0x0, lsl #16
    c9f8:      	movz	w2, #0x0, lsl #16
    c9fc:      	ubfx	x4, x4, #0, #32
    ca00:      	lsr	x16, x4, #0
    ca04:      	cmp	x16, #0x1
    ca08:      	b.eq	0xca24 <_stogir.placement.use-block+0x2a8>
    ca0c:      	b.lo	0xca14 <_stogir.placement.use-block+0x298>
    ca10:      	b	0xca28 <_stogir.placement.use-block+0x2ac>
    ca14:      	cmp	x16, #0x0
    ca18:      	b.eq	0xca20 <_stogir.placement.use-block+0x2a4>
    ca1c:      	b	0xca28 <_stogir.placement.use-block+0x2ac>
    ca20:      	b	0xca2c <_stogir.placement.use-block+0x2b0>
    ca24:      	b	0xca98 <_stogir.placement.use-block+0x31c>
    ca28:      	b	0xcba8 <_stogir.placement.use-block+0x42c>
    ca2c:      	mov	x19, x8
    ca30:      	mov	x1, #0x1                ; =1
    ca34:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000ca34:  ARM64_RELOC_PAGE21	l_stogir.502
    ca38:      	ldr	x0, [x0]
		000000000000ca38:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    ca3c:      	mov	x2, #0x12               ; =18
    ca40:      	b	0xc9bc <_stogir.placement.use-block+0x240>
    ca44:      	movz	w4, #0x0, lsl #16
    ca48:      	movz	w2, #0x0, lsl #16
    ca4c:      	b	0xc9fc <_stogir.placement.use-block+0x280>
    ca50:      	movz	x2, #0x0, lsl #48
    ca54:      	cmp	x2, #0x0
    ca58:      	b.eq	0xc9f4 <_stogir.placement.use-block+0x278>
    ca5c:      	ldr	x2, [x0, #0x78]
    ca60:      	add	x2, x4, x2
    ca64:      	ldr	w2, [x2]
    ca68:      	sxtw	x2, w2
    ca6c:      	cmp	x2, #0x1
    ca70:      	b.lt	0xca44 <_stogir.placement.use-block+0x2c8>
    ca74:      	ldr	x2, [x0]
    ca78:      	add	x2, x9, x2
    ca7c:      	ldr	w2, [x2, #0x4]
    ca80:      	movn	w17, #0x0, lsl #16
    ca84:      	and	w2, w2, w17
    ca88:      	mov	w4, #0x1                ; =1
    ca8c:      	b	0xca4c <_stogir.placement.use-block+0x2d0>
    ca90:      	movz	x2, #0x0, lsl #48
    ca94:      	b	0xca54 <_stogir.placement.use-block+0x2d8>
    ca98:      	sub	w3, w3, #0x1
    ca9c:      	mov	x19, x8
    caa0:      	mov	x20, x0
    caa4:      	mov	x21, x1
    caa8:      	mov	w1, w2
    caac:      	mov	w2, w3
    cab0:      	bl	0xcab0 <_stogir.placement.use-block+0x334>
		000000000000cab0:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    cab4:      	ubfx	x0, x0, #0, #32
    cab8:      	lsr	x16, x0, #0
    cabc:      	cmp	x16, #0x1
    cac0:      	b.eq	0xcadc <_stogir.placement.use-block+0x360>
    cac4:      	b.lo	0xcacc <_stogir.placement.use-block+0x350>
    cac8:      	b	0xcae0 <_stogir.placement.use-block+0x364>
    cacc:      	cmp	x16, #0x0
    cad0:      	b.eq	0xcad8 <_stogir.placement.use-block+0x35c>
    cad4:      	b	0xcae0 <_stogir.placement.use-block+0x364>
    cad8:      	b	0xcae4 <_stogir.placement.use-block+0x368>
    cadc:      	b	0xcb0c <_stogir.placement.use-block+0x390>
    cae0:      	b	0xcbb0 <_stogir.placement.use-block+0x434>
    cae4:      	mov	x1, #0x1                ; =1
    cae8:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000cae8:  ARM64_RELOC_PAGE21	l_stogir.503
    caec:      	ldr	x0, [x0]
		000000000000caec:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    caf0:      	mov	x2, #0x17               ; =23
    caf4:      	b	0xcb08 <_stogir.placement.use-block+0x38c>
    caf8:      	mov	x1, #0x1                ; =1
    cafc:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000cafc:  ARM64_RELOC_PAGE21	l_stogir.504
    cb00:      	ldr	x0, [x0]
		000000000000cb00:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    cb04:      	mov	x2, #0x25               ; =37
    cb08:      	b	0xca40 <_stogir.placement.use-block+0x2c4>
    cb0c:      	sxtw	x1, w1
    cb10:      	cmp	x1, #0x0
    cb14:      	b.le	0xcaf8 <_stogir.placement.use-block+0x37c>
    cb18:      	lsl	x0, x1, #2
    cb1c:      	ldr	x2, [x20, #0x8]
    cb20:      	cmp	x1, x2
    cb24:      	b.ge	0xcb70 <_stogir.placement.use-block+0x3f4>
    cb28:      	add	x2, x20, #0x78
    cb2c:      	ldr	x2, [x2, #0x8]
    cb30:      	cmp	x1, x2
    cb34:      	b.ge	0xcb68 <_stogir.placement.use-block+0x3ec>
    cb38:      	ldr	x1, [x20, #0x78]
    cb3c:      	add	x1, x0, x1
    cb40:      	ldr	w1, [x1]
    cb44:      	sxtw	x1, w1
    cb48:      	cmp	x1, #0x0
    cb4c:      	cset	w1, ge
    cb50:      	ubfx	x1, x1, #0, #8
    cb54:      	b	0xcb6c <_stogir.placement.use-block+0x3f0>
    cb58:      	and	x0, x0, #0xffffffff
    cb5c:      	movz	x1, #0x0, lsl #48
    cb60:      	movz	x2, #0x0, lsl #48
    cb64:      	b	0xcb08 <_stogir.placement.use-block+0x38c>
    cb68:      	movz	x1, #0x0, lsl #48
    cb6c:      	b	0xcb74 <_stogir.placement.use-block+0x3f8>
    cb70:      	movz	x1, #0x0, lsl #48
    cb74:      	cmp	x1, #0x0
    cb78:      	b.eq	0xcaf8 <_stogir.placement.use-block+0x37c>
    cb7c:      	ldr	x1, [x21]
    cb80:      	add	x0, x0, x1
    cb84:      	ldr	w0, [x0]
    cb88:      	sxtw	x0, w0
    cb8c:      	cmp	x0, #0x0
    cb90:      	b.ne	0xcb58 <_stogir.placement.use-block+0x3dc>
    cb94:      	mov	x1, #0x1                ; =1
    cb98:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000cb98:  ARM64_RELOC_PAGE21	l_stogir.505
    cb9c:      	ldr	x0, [x0]
		000000000000cb9c:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    cba0:      	mov	x2, #0x1a               ; =26
    cba4:      	b	0xcb64 <_stogir.placement.use-block+0x3e8>
    cba8:      	brk	#0
    cbac:      	b	0xcba8 <_stogir.placement.use-block+0x42c>
    cbb0:      	brk	#0
    cbb4:      	b	0xcbb0 <_stogir.placement.use-block+0x434>
    cbb8:      	mov	x19, x8
    cbbc:      	b	0xc914 <_stogir.placement.use-block+0x198>
    cbc0:      	mov	x19, x8
    cbc4:      	mov	x21, x1
    cbc8:      	b	0xc9c0 <_stogir.placement.use-block+0x244>
    cbcc:      	mov	x19, x8
    cbd0:      	mov	x21, x1
    cbd4:      	b	0xc9c0 <_stogir.placement.use-block+0x244>

000000000000cbd8 <_stogir.placement.choose-block>:
    cbd8:      	sxtw	x2, w2
    cbdc:      	sxtw	x4, w3
    cbe0:      	mov	x6, x4
    cbe4:      	movz	x5, #0x0, lsl #48
    cbe8:      	movz	x7, #0x0, lsl #48
    cbec:      	b	0xcbfc <_stogir.placement.choose-block+0x24>
    cbf0:      	mov	x6, x9
    cbf4:      	b	0xcbfc <_stogir.placement.choose-block+0x24>
    cbf8:      	mov	x5, #0x1                ; =1
    cbfc:      	cmp	x5, #0x0
    cc00:      	b.ne	0xcc4c <_stogir.placement.choose-block+0x74>
    cc04:      	cmp	x6, #0x0
    cc08:      	b.le	0xcbf8 <_stogir.placement.choose-block+0x20>
    cc0c:      	ldr	x9, [x0, #0x8]
    cc10:      	cmp	x6, x9
    cc14:      	b.ge	0xcbf8 <_stogir.placement.choose-block+0x20>
    cc18:      	ldr	x9, [x0]
    cc1c:      	add	x9, x9, x6, lsl #2
    cc20:      	ldr	w9, [x9]
    cc24:      	sxtw	x9, w9
    cc28:      	cmp	x9, #0x0
    cc2c:      	b.ne	0xcc38 <_stogir.placement.choose-block+0x60>
    cc30:      	mov	x5, #0x1                ; =1
    cc34:      	b	0xcbf4 <_stogir.placement.choose-block+0x1c>
    cc38:      	cmp	x6, x2
    cc3c:      	b.ne	0xcc58 <_stogir.placement.choose-block+0x80>
    cc40:      	mov	x5, #0x1                ; =1
    cc44:      	mov	x7, #0x1                ; =1
    cc48:      	b	0xcbf4 <_stogir.placement.choose-block+0x1c>
    cc4c:      	cmp	x7, #0x0
    cc50:      	b.eq	0xccc4 <_stogir.placement.choose-block+0xec>
    cc54:      	b	0xcc6c <_stogir.placement.choose-block+0x94>
    cc58:      	cmp	x6, x9
    cc5c:      	b.ne	0xcbf0 <_stogir.placement.choose-block+0x18>
    cc60:      	mov	x5, #0x1                ; =1
    cc64:      	b	0xcbf4 <_stogir.placement.choose-block+0x1c>
    cc68:      	mov	x4, x5
    cc6c:      	sxtw	x3, w3
    cc70:      	cmp	x3, x2
    cc74:      	b.eq	0xccb4 <_stogir.placement.choose-block+0xdc>
    cc78:      	ldr	x5, [x0]
    cc7c:      	add	x3, x5, x3, lsl #2
    cc80:      	ldr	w3, [x3]
    cc84:      	sxtw	x5, w3
    cc88:      	ldr	x6, [x1]
    cc8c:      	orr	x7, x6, xzr
    cc90:      	add	x7, x7, x5, lsl #2
    cc94:      	add	x6, x6, x4, lsl #2
    cc98:      	ldr	w7, [x7]
    cc9c:      	sxtw	x7, w7
    cca0:      	ldr	w6, [x6]
    cca4:      	sxtw	x6, w6
    cca8:      	cmp	x7, x6
    ccac:      	b.lt	0xcc68 <_stogir.placement.choose-block+0x90>
    ccb0:      	b	0xcc6c <_stogir.placement.choose-block+0x94>
    ccb4:      	and	x0, x4, #0xffffffff
    ccb8:      	movz	x1, #0x0, lsl #48
    ccbc:      	movz	x2, #0x0, lsl #48
    ccc0:      	b	0xccd4 <_stogir.placement.choose-block+0xfc>
    ccc4:      	mov	x1, #0x1                ; =1
    ccc8:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000ccc8:  ARM64_RELOC_PAGE21	l_stogir.506
    cccc:      	ldr	x0, [x0]
		000000000000cccc:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    ccd0:      	mov	x2, #0x29               ; =41
    ccd4:      	str	x1, [x8]
    ccd8:      	str	x0, [x8, #0x8]
    ccdc:      	str	x2, [x8, #0x10]
    cce0:      	ret

000000000000cce4 <_stogir.checked.validate-projection>:
    cce4:      	sub	sp, sp, #0x40
    cce8:      	str	x29, [sp]
    ccec:      	str	x30, [sp, #0x8]
    ccf0:      	mov	x29, sp
    ccf4:      	str	x19, [sp, #0x30]
    ccf8:      	sxtw	x1, w1
    ccfc:      	lsl	x2, x1, #2
    cd00:      	cmp	x1, #0x0
    cd04:      	cset	w3, gt
    cd08:      	movz	x16, #0x0, lsl #48
    cd0c:      	sub	x4, x16, x1
    cd10:      	sub	x5, x4, #0x1
    cd14:      	uxtb	w16, w3
    cd18:      	cmp	w16, wzr
    cd1c:      	b.eq	0xcd5c <_stogir.checked.validate-projection+0x78>
    cd20:      	ldr	x4, [x0, #0x8]
    cd24:      	cmp	x1, x4
    cd28:      	b.ge	0xcdac <_stogir.checked.validate-projection+0xc8>
    cd2c:      	add	x4, x0, #0x78
    cd30:      	ldr	x4, [x4, #0x8]
    cd34:      	cmp	x1, x4
    cd38:      	b.ge	0xce7c <_stogir.checked.validate-projection+0x198>
    cd3c:      	ldr	x4, [x0, #0x78]
    cd40:      	add	x4, x2, x4
    cd44:      	ldr	w4, [x4]
    cd48:      	sxtw	x4, w4
    cd4c:      	cmp	x4, #0x0
    cd50:      	cset	w4, ge
    cd54:      	ubfx	x4, x4, #0, #8
    cd58:      	b	0xce80 <_stogir.checked.validate-projection+0x19c>
    cd5c:      	cmp	x1, #0x0
    cd60:      	b.ge	0xcdb4 <_stogir.checked.validate-projection+0xd0>
    cd64:      	add	x6, x0, #0x28
    cd68:      	add	x7, x0, #0x50
    cd6c:      	ldr	x6, [x6, #0x8]
    cd70:      	ldr	x7, [x7, #0x8]
    cd74:      	cmp	x6, x7
    cd78:      	b.ne	0xcda4 <_stogir.checked.validate-projection+0xc0>
    cd7c:      	cmp	x4, x6
    cd80:      	b.gt	0xcee8 <_stogir.checked.validate-projection+0x204>
    cd84:      	ldr	x4, [x0, #0x50]
    cd88:      	add	x4, x4, x5, lsl #2
    cd8c:      	ldr	w4, [x4]
    cd90:      	sxtw	x4, w4
    cd94:      	cmp	x4, #0x0
    cd98:      	cset	w4, gt
    cd9c:      	ubfx	x4, x4, #0, #8
    cda0:      	b	0xceec <_stogir.checked.validate-projection+0x208>
    cda4:      	movz	x4, #0x0, lsl #48
    cda8:      	b	0xcdb8 <_stogir.checked.validate-projection+0xd4>
    cdac:      	movz	x4, #0x0, lsl #48
    cdb0:      	b	0xcdb8 <_stogir.checked.validate-projection+0xd4>
    cdb4:      	movz	x4, #0x0, lsl #48
    cdb8:      	cmp	x4, #0x0
    cdbc:      	b.eq	0xcdf0 <_stogir.checked.validate-projection+0x10c>
    cdc0:      	uxtb	w16, w3
    cdc4:      	cmp	w16, wzr
    cdc8:      	b.eq	0xcddc <_stogir.checked.validate-projection+0xf8>
    cdcc:      	ldr	x3, [x0]
    cdd0:      	add	x3, x3, x1, lsl #4
    cdd4:      	ldr	x3, [x3]
    cdd8:      	b	0xcde8 <_stogir.checked.validate-projection+0x104>
    cddc:      	ldr	x3, [x0, #0x28]
    cde0:      	add	x3, x3, x5, lsl #4
    cde4:      	ldr	x3, [x3]
    cde8:      	mov	w4, #0x1                ; =1
    cdec:      	b	0xcdf8 <_stogir.checked.validate-projection+0x114>
    cdf0:      	movz	w4, #0x0, lsl #16
    cdf4:      	movz	x3, #0x0, lsl #48
    cdf8:      	ubfx	x4, x4, #0, #32
    cdfc:      	lsr	x16, x4, #0
    ce00:      	cmp	x16, #0x1
    ce04:      	b.eq	0xce20 <_stogir.checked.validate-projection+0x13c>
    ce08:      	b.lo	0xce10 <_stogir.checked.validate-projection+0x12c>
    ce0c:      	b	0xce24 <_stogir.checked.validate-projection+0x140>
    ce10:      	cmp	x16, #0x0
    ce14:      	b.eq	0xce1c <_stogir.checked.validate-projection+0x138>
    ce18:      	b	0xce24 <_stogir.checked.validate-projection+0x140>
    ce1c:      	b	0xce28 <_stogir.checked.validate-projection+0x144>
    ce20:      	b	0xce40 <_stogir.checked.validate-projection+0x15c>
    ce24:      	b	0xcef0 <_stogir.checked.validate-projection+0x20c>
    ce28:      	mov	x19, x8
    ce2c:      	mov	x0, #0x1                ; =1
    ce30:      	adrp	x1, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000ce30:  ARM64_RELOC_PAGE21	l_stogir.507
    ce34:      	ldr	x1, [x1]
		000000000000ce34:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    ce38:      	mov	x2, #0x10               ; =16
    ce3c:      	b	0xce5c <_stogir.checked.validate-projection+0x178>
    ce40:      	cmp	x1, #0x0
    ce44:      	b.gt	0xce84 <_stogir.checked.validate-projection+0x1a0>
    ce48:      	mov	x19, x8
    ce4c:      	mov	x0, #0x1                ; =1
    ce50:      	adrp	x1, 0xc000 <_stogir.dominators.build-index+0x538>
		000000000000ce50:  ARM64_RELOC_PAGE21	l_stogir.508
    ce54:      	ldr	x1, [x1]
		000000000000ce54:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    ce58:      	mov	x2, #0x1c               ; =28
    ce5c:      	str	x0, [x19]
    ce60:      	str	x1, [x19, #0x8]
    ce64:      	str	x2, [x19, #0x10]
    ce68:      	ldr	x19, [sp, #0x30]
    ce6c:      	ldr	x29, [sp]
    ce70:      	ldr	x30, [sp, #0x8]
    ce74:      	add	sp, sp, #0x40
    ce78:      	ret
    ce7c:      	movz	x4, #0x0, lsl #48
    ce80:      	b	0xcdb0 <_stogir.checked.validate-projection+0xcc>
    ce84:      	uxtb	w1, w3
    ce88:      	cmp	x1, #0x2c
    ce8c:      	b.ne	0xcef8 <_stogir.checked.validate-projection+0x214>
    ce90:      	orr	w1, w3, wzr
    ce94:      	ubfx	x1, x1, #0, #32
    ce98:      	ubfx	x1, x1, #8, #8
    ce9c:      	cmp	x1, #0x1
    cea0:      	b.ne	0xcf00 <_stogir.checked.validate-projection+0x21c>
    cea4:      	ldr	x1, [x0, #0x78]
    cea8:      	add	x1, x2, x1
    ceac:      	ldr	w1, [x1]
    ceb0:      	sxtw	x1, w1
    ceb4:      	cmp	x1, #0x1
    ceb8:      	b.ne	0xcf08 <_stogir.checked.validate-projection+0x224>
    cebc:      	lsr	x1, x3, #32
    cec0:      	mov	x19, x8
    cec4:      	add	x8, sp, #0x10
    cec8:      	bl	0xcec8 <_stogir.checked.validate-projection+0x1e4>
		000000000000cec8:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    cecc:      	add	x16, sp, #0x10
    ced0:      	ldr	x0, [x16]
    ced4:      	add	x16, sp, #0x10
    ced8:      	ldr	x1, [x16, #0x8]
    cedc:      	add	x16, sp, #0x10
    cee0:      	ldr	x2, [x16, #0x10]
    cee4:      	b	0xce5c <_stogir.checked.validate-projection+0x178>
    cee8:      	movz	x4, #0x0, lsl #48
    ceec:      	b	0xcda8 <_stogir.checked.validate-projection+0xc4>
    cef0:      	brk	#0
    cef4:      	b	0xcef0 <_stogir.checked.validate-projection+0x20c>
    cef8:      	mov	x19, x8
    cefc:      	b	0xce4c <_stogir.checked.validate-projection+0x168>
    cf00:      	mov	x19, x8
    cf04:      	b	0xce4c <_stogir.checked.validate-projection+0x168>
    cf08:      	mov	x19, x8
    cf0c:      	b	0xce4c <_stogir.checked.validate-projection+0x168>

000000000000cf10 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge>:
    cf10:      	ldr	x1, [x0]
    cf14:      	ldr	x0, [x0, #0x8]
    cf18:      	str	x1, [x8]
    cf1c:      	str	x0, [x8, #0x8]
    cf20:      	movz	x17, #0x0, lsl #48
    cf24:      	str	x17, [x8, #0x10]
    cf28:      	ret

000000000000cf2c <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64>:
    cf2c:      	ldr	x1, [x0]
    cf30:      	ldr	x0, [x0, #0x8]
    cf34:      	str	x1, [x8]
    cf38:      	str	x0, [x8, #0x8]
    cf3c:      	movz	x17, #0x0, lsl #48
    cf40:      	str	x17, [x8, #0x10]
    cf44:      	ret

000000000000cf48 <_stogir.loops.heapify!>:
    cf48:      	sub	sp, sp, #0x20
    cf4c:      	str	x19, [sp]
    cf50:      	str	x20, [sp, #0x8]
    cf54:      	str	x21, [sp, #0x10]
    cf58:      	orr	x4, x0, xzr
    cf5c:      	orr	x5, x0, xzr
    cf60:      	orr	x6, x0, xzr
    cf64:      	orr	x7, x3, xzr
    cf68:      	ldr	x8, [x1, #0x8]
    cf6c:      	asr	x16, x8, #63
    cf70:      	lsr	x16, x16, #63
    cf74:      	add	x8, x8, x16
    cf78:      	asr	x8, x8, #1
    cf7c:      	cmp	x8, #0x0
    cf80:      	b.le	0xd0fc <_stogir.loops.heapify!+0x1b4>
    cf84:      	sub	x8, x8, #0x1
    cf88:      	ldr	x9, [x1]
    cf8c:      	ldr	x10, [x1, #0x8]
    cf90:      	mov	x12, x8
    cf94:      	movz	x11, #0x0, lsl #48
    cf98:      	b	0xcfdc <_stogir.loops.heapify!+0x94>
    cf9c:      	nop
    cfa0:      	add	x12, x9, x12
    cfa4:      	add	x14, x9, x13
    cfa8:      	ldr	x15, [x6]
    cfac:      	orr	x19, x15, xzr
    cfb0:      	orr	x20, x15, xzr
    cfb4:      	add	x19, x19, x12, lsl #3
    cfb8:      	add	x20, x20, x14, lsl #3
    cfbc:      	add	x12, x15, x12, lsl #3
    cfc0:      	ldr	x15, [x19]
    cfc4:      	ldr	x19, [x20]
    cfc8:      	str	x19, [x12]
    cfcc:      	ldr	x12, [x0]
    cfd0:      	add	x12, x12, x14, lsl #3
    cfd4:      	str	x15, [x12]
    cfd8:      	mov	x12, x13
    cfdc:      	cmp	x11, #0x0
    cfe0:      	b.ne	0xcf7c <_stogir.loops.heapify!+0x34>
    cfe4:      	lsl	x13, x12, #1
    cfe8:      	add	x13, x13, #0x1
    cfec:      	cmp	x13, x10
    cff0:      	b.ge	0xcf7c <_stogir.loops.heapify!+0x34>
    cff4:      	lsl	x13, x12, #1
    cff8:      	add	x13, x13, #0x1
    cffc:      	add	x14, x13, #0x1
    d000:      	cmp	x14, x10
    d004:      	b.ge	0xd080 <_stogir.loops.heapify!+0x138>
    d008:      	add	x14, x13, x9
    d00c:      	ldr	x15, [x4]
    d010:      	add	x19, x14, #0x1
    d014:      	orr	x20, x15, xzr
    d018:      	add	x14, x15, x14, lsl #3
    d01c:      	add	x15, x20, x19, lsl #3
    d020:      	ldr	x15, [x15]
    d024:      	ldr	x14, [x14]
    d028:      	ldr	x19, [x2, #0x50]
    d02c:      	orr	x20, x19, xzr
    d030:      	add	x20, x20, x15, lsl #4
    d034:      	add	x19, x19, x14, lsl #4
    d038:      	ldr	x20, [x20]
    d03c:      	ldr	x21, [x7]
    d040:      	asr	x20, x20, #32
    d044:      	add	x20, x21, x20, lsl #2
    d048:      	ldr	w20, [x20]
    d04c:      	sxtw	x20, w20
    d050:      	ldr	x19, [x19]
    d054:      	asr	x19, x19, #32
    d058:      	add	x19, x21, x19, lsl #2
    d05c:      	ldr	w19, [x19]
    d060:      	sxtw	x19, w19
    d064:      	cmp	x20, x19
    d068:      	b.lt	0xd07c <_stogir.loops.heapify!+0x134>
    d06c:      	cmp	x20, x19
    d070:      	b.ne	0xd080 <_stogir.loops.heapify!+0x138>
    d074:      	cmp	x15, x14
    d078:      	b.le	0xd080 <_stogir.loops.heapify!+0x138>
    d07c:      	add	x13, x13, #0x1
    d080:      	add	x14, x9, x12
    d084:      	ldr	x15, [x5]
    d088:      	add	x19, x9, x13
    d08c:      	orr	x20, x15, xzr
    d090:      	add	x14, x15, x14, lsl #3
    d094:      	add	x15, x20, x19, lsl #3
    d098:      	ldr	x15, [x15]
    d09c:      	ldr	x14, [x14]
    d0a0:      	ldr	x19, [x2, #0x50]
    d0a4:      	orr	x20, x19, xzr
    d0a8:      	add	x20, x20, x15, lsl #4
    d0ac:      	add	x19, x19, x14, lsl #4
    d0b0:      	ldr	x20, [x20]
    d0b4:      	ldr	x21, [x3]
    d0b8:      	asr	x20, x20, #32
    d0bc:      	add	x20, x21, x20, lsl #2
    d0c0:      	ldr	w20, [x20]
    d0c4:      	sxtw	x20, w20
    d0c8:      	ldr	x19, [x19]
    d0cc:      	asr	x19, x19, #32
    d0d0:      	add	x19, x21, x19, lsl #2
    d0d4:      	ldr	w19, [x19]
    d0d8:      	sxtw	x19, w19
    d0dc:      	cmp	x20, x19
    d0e0:      	b.lt	0xcfa0 <_stogir.loops.heapify!+0x58>
    d0e4:      	cmp	x20, x19
    d0e8:      	b.ne	0xd0f4 <_stogir.loops.heapify!+0x1ac>
    d0ec:      	cmp	x15, x14
    d0f0:      	b.gt	0xcfa0 <_stogir.loops.heapify!+0x58>
    d0f4:      	mov	x11, #0x1               ; =1
    d0f8:      	b	0xcfdc <_stogir.loops.heapify!+0x94>
    d0fc:      	ldr	x19, [sp]
    d100:      	ldr	x20, [sp, #0x8]
    d104:      	ldr	x21, [sp, #0x10]
    d108:      	add	sp, sp, #0x20
    d10c:      	ret

000000000000d110 <_stogir.loops.sift!>:
    d110:      	sub	sp, sp, #0x10
    d114:      	str	x19, [sp]
    d118:      	orr	x6, x0, xzr
    d11c:      	orr	x7, x0, xzr
    d120:      	orr	x8, x0, xzr
    d124:      	orr	x9, x5, xzr
    d128:      	movz	x10, #0x0, lsl #48
    d12c:      	b	0xd16c <_stogir.loops.sift!+0x5c>
    d130:      	add	x3, x1, x3
    d134:      	add	x12, x1, x11
    d138:      	ldr	x13, [x8]
    d13c:      	orr	x14, x13, xzr
    d140:      	orr	x15, x13, xzr
    d144:      	add	x14, x14, x3, lsl #3
    d148:      	add	x15, x15, x12, lsl #3
    d14c:      	add	x3, x13, x3, lsl #3
    d150:      	ldr	x13, [x14]
    d154:      	ldr	x14, [x15]
    d158:      	str	x14, [x3]
    d15c:      	ldr	x3, [x0]
    d160:      	add	x3, x3, x12, lsl #3
    d164:      	str	x13, [x3]
    d168:      	mov	x3, x11
    d16c:      	cmp	x10, #0x0
    d170:      	b.ne	0xd28c <_stogir.loops.sift!+0x17c>
    d174:      	lsl	x11, x3, #1
    d178:      	add	x11, x11, #0x1
    d17c:      	cmp	x11, x2
    d180:      	b.ge	0xd28c <_stogir.loops.sift!+0x17c>
    d184:      	lsl	x11, x3, #1
    d188:      	add	x11, x11, #0x1
    d18c:      	add	x12, x11, #0x1
    d190:      	cmp	x12, x2
    d194:      	b.ge	0xd210 <_stogir.loops.sift!+0x100>
    d198:      	add	x12, x11, x1
    d19c:      	ldr	x13, [x6]
    d1a0:      	add	x14, x12, #0x1
    d1a4:      	orr	x15, x13, xzr
    d1a8:      	add	x12, x13, x12, lsl #3
    d1ac:      	add	x13, x15, x14, lsl #3
    d1b0:      	ldr	x13, [x13]
    d1b4:      	ldr	x12, [x12]
    d1b8:      	ldr	x14, [x4, #0x50]
    d1bc:      	orr	x15, x14, xzr
    d1c0:      	add	x15, x15, x13, lsl #4
    d1c4:      	add	x14, x14, x12, lsl #4
    d1c8:      	ldr	x15, [x15]
    d1cc:      	ldr	x19, [x9]
    d1d0:      	asr	x15, x15, #32
    d1d4:      	add	x15, x19, x15, lsl #2
    d1d8:      	ldr	w15, [x15]
    d1dc:      	sxtw	x15, w15
    d1e0:      	ldr	x14, [x14]
    d1e4:      	asr	x14, x14, #32
    d1e8:      	add	x14, x19, x14, lsl #2
    d1ec:      	ldr	w14, [x14]
    d1f0:      	sxtw	x14, w14
    d1f4:      	cmp	x15, x14
    d1f8:      	b.lt	0xd20c <_stogir.loops.sift!+0xfc>
    d1fc:      	cmp	x15, x14
    d200:      	b.ne	0xd210 <_stogir.loops.sift!+0x100>
    d204:      	cmp	x13, x12
    d208:      	b.le	0xd210 <_stogir.loops.sift!+0x100>
    d20c:      	add	x11, x11, #0x1
    d210:      	add	x12, x1, x3
    d214:      	ldr	x13, [x7]
    d218:      	add	x14, x1, x11
    d21c:      	orr	x15, x13, xzr
    d220:      	add	x12, x13, x12, lsl #3
    d224:      	add	x13, x15, x14, lsl #3
    d228:      	ldr	x13, [x13]
    d22c:      	ldr	x12, [x12]
    d230:      	ldr	x14, [x4, #0x50]
    d234:      	orr	x15, x14, xzr
    d238:      	add	x15, x15, x13, lsl #4
    d23c:      	add	x14, x14, x12, lsl #4
    d240:      	ldr	x15, [x15]
    d244:      	ldr	x19, [x5]
    d248:      	asr	x15, x15, #32
    d24c:      	add	x15, x19, x15, lsl #2
    d250:      	ldr	w15, [x15]
    d254:      	sxtw	x15, w15
    d258:      	ldr	x14, [x14]
    d25c:      	asr	x14, x14, #32
    d260:      	add	x14, x19, x14, lsl #2
    d264:      	ldr	w14, [x14]
    d268:      	sxtw	x14, w14
    d26c:      	cmp	x15, x14
    d270:      	b.lt	0xd130 <_stogir.loops.sift!+0x20>
    d274:      	cmp	x15, x14
    d278:      	b.ne	0xd284 <_stogir.loops.sift!+0x174>
    d27c:      	cmp	x13, x12
    d280:      	b.gt	0xd130 <_stogir.loops.sift!+0x20>
    d284:      	mov	x10, #0x1               ; =1
    d288:      	b	0xd16c <_stogir.loops.sift!+0x5c>
    d28c:      	ldr	x19, [sp]
    d290:      	add	sp, sp, #0x10
    d294:      	ret

000000000000d298 <_stogir.opcode.block-end?>:
    d298:      	sxtw	x0, w0
    d29c:      	cmp	x0, #0x0
    d2a0:      	b.lt	0xd2c0 <_stogir.opcode.block-end?+0x28>
    d2a4:      	cmp	x0, #0x83
    d2a8:      	b.ge	0xd2c0 <_stogir.opcode.block-end?+0x28>
    d2ac:      	adrp	x16, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000d2ac:  ARM64_RELOC_PAGE21	l_stogir.509
    d2b0:      	ldr	x16, [x16]
		000000000000d2b0:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    d2b4:      	add	x0, x16, x0
    d2b8:      	ldrb	w0, [x0]
    d2bc:      	b	0xd2c4 <_stogir.opcode.block-end?+0x2c>
    d2c0:      	movz	w0, #0x0, lsl #16
    d2c4:      	uxtb	w16, w0
    d2c8:      	and	w0, w16, #0x4
    d2cc:      	uxtb	w0, w0
    d2d0:      	ubfx	x0, x0, #0, #8
    d2d4:      	cmp	x0, #0x0
    d2d8:      	cset	w0, eq
    d2dc:      	uxtb	w16, w0
    d2e0:      	cmp	w16, wzr
    d2e4:      	cset	x0, eq
    d2e8:      	ret

000000000000d2ec <_stogir.schedule.entry-prefix>:
    d2ec:      	sub	sp, sp, #0x90
    d2f0:      	str	x29, [sp]
    d2f4:      	str	x30, [sp, #0x8]
    d2f8:      	mov	x29, sp
    d2fc:      	str	x19, [sp, #0x40]
    d300:      	str	x20, [sp, #0x48]
    d304:      	str	x21, [sp, #0x50]
    d308:      	str	x22, [sp, #0x58]
    d30c:      	str	x23, [sp, #0x60]
    d310:      	str	x24, [sp, #0x68]
    d314:      	str	x25, [sp, #0x70]
    d318:      	str	x26, [sp, #0x78]
    d31c:      	str	x27, [sp, #0x80]
    d320:      	str	x28, [sp, #0x88]
    d324:      	orr	x19, x0, xzr
    d328:      	add	x16, sp, #0x10
    d32c:      	orr	x20, x16, xzr
    d330:      	ldr	x0, [x2]
    d334:      	ldr	x2, [x2, #0x8]
    d338:      	add	x16, sp, #0x10
    d33c:      	movz	x17, #0x0, lsl #48
    d340:      	str	x17, [x16]
    d344:      	add	x16, sp, #0x10
    d348:      	movz	x17, #0x0, lsl #48
    d34c:      	str	x17, [x16, #0x8]
    d350:      	add	x16, sp, #0x10
    d354:      	movz	x17, #0x0, lsl #48
    d358:      	str	x17, [x16, #0x10]
    d35c:      	add	x16, sp, #0x10
    d360:      	str	x0, [x16, #0x18]
    d364:      	add	x16, sp, #0x10
    d368:      	str	x2, [x16, #0x20]
    d36c:      	movz	x21, #0x0, lsl #48
    d370:      	b	0xd454 <_stogir.schedule.entry-prefix+0x168>
    d374:      	lsl	x0, x0, #1
    d378:      	mov	x27, x8
    d37c:      	mov	x28, x1
    d380:      	mov	x1, x0
    d384:      	mov	x0, x20
    d388:      	bl	0xd388 <_stogir.schedule.entry-prefix+0x9c>
		000000000000d388:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    d38c:      	add	x0, x26, #0x1
    d390:      	add	x16, sp, #0x10
    d394:      	ldr	x1, [x16]
    d398:      	add	x1, x1, x26, lsl #2
    d39c:      	str	w25, [x1]
    d3a0:      	add	x16, sp, #0x10
    d3a4:      	str	x0, [x16, #0x8]
    d3a8:      	mov	x8, x27
    d3ac:      	mov	x1, x28
    d3b0:      	cmp	x24, x23
    d3b4:      	b.ge	0xd3d8 <_stogir.schedule.entry-prefix+0xec>
    d3b8:      	add	x0, x24, #0x1
    d3bc:      	add	x2, x22, x24, lsl #2
    d3c0:      	ldr	w2, [x2]
    d3c4:      	movn	w17, #0x0, lsl #16
    d3c8:      	and	w25, w2, w17
    d3cc:      	mov	x24, x0
    d3d0:      	mov	w0, #0x1                ; =1
    d3d4:      	b	0xd3e0 <_stogir.schedule.entry-prefix+0xf4>
    d3d8:      	movz	w0, #0x0, lsl #16
    d3dc:      	movz	w25, #0x0, lsl #16
    d3e0:      	ubfx	x0, x0, #0, #32
    d3e4:      	lsr	x16, x0, #0
    d3e8:      	cmp	x16, #0x1
    d3ec:      	b.eq	0xd410 <_stogir.schedule.entry-prefix+0x124>
    d3f0:      	b.lo	0xd3f8 <_stogir.schedule.entry-prefix+0x10c>
    d3f4:      	b	0xd414 <_stogir.schedule.entry-prefix+0x128>
    d3f8:      	cmp	x16, #0x0
    d3fc:      	b.eq	0xd404 <_stogir.schedule.entry-prefix+0x118>
    d400:      	b	0xd414 <_stogir.schedule.entry-prefix+0x128>
    d404:      	mov	x27, x8
    d408:      	mov	x28, x1
    d40c:      	b	0xd448 <_stogir.schedule.entry-prefix+0x15c>
    d410:      	b	0xd418 <_stogir.schedule.entry-prefix+0x12c>
    d414:      	b	0xd570 <_stogir.schedule.entry-prefix+0x284>
    d418:      	sxtw	x0, w25
    d41c:      	ldr	x2, [x19]
    d420:      	add	x0, x2, x0, lsl #4
    d424:      	ldr	x0, [x0]
    d428:      	uxtb	w0, w0
    d42c:      	cmp	x0, #0x83
    d430:      	b.ge	0xd474 <_stogir.schedule.entry-prefix+0x188>
    d434:      	adrp	x17, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000d434:  ARM64_RELOC_PAGE21	l_stogir.510
    d438:      	ldr	x17, [x17]
		000000000000d438:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    d43c:      	add	x2, x0, x17
    d440:      	ldrb	w2, [x2]
    d444:      	b	0xd478 <_stogir.schedule.entry-prefix+0x18c>
    d448:      	add	x21, x21, #0x1
    d44c:      	mov	x8, x27
    d450:      	mov	x1, x28
    d454:      	cmp	x21, #0x3
    d458:      	b.ge	0xd578 <_stogir.schedule.entry-prefix+0x28c>
    d45c:      	ldr	x0, [x1]
    d460:      	orr	x22, x0, xzr
    d464:      	ldr	x0, [x1, #0x8]
    d468:      	orr	x23, x0, xzr
    d46c:      	movz	x24, #0x0, lsl #48
    d470:      	b	0xd3b0 <_stogir.schedule.entry-prefix+0xc4>
    d474:      	movz	w2, #0x0, lsl #16
    d478:      	uxtb	w16, w2
    d47c:      	and	w2, w16, #0x2
    d480:      	uxtb	w2, w2
    d484:      	ubfx	x2, x2, #0, #8
    d488:      	cmp	x2, #0x0
    d48c:      	cset	w2, eq
    d490:      	uxtb	w16, w2
    d494:      	cmp	w16, wzr
    d498:      	cset	x2, eq
    d49c:      	cmp	x2, #0x0
    d4a0:      	b.eq	0xd4ac <_stogir.schedule.entry-prefix+0x1c0>
    d4a4:      	movz	x0, #0x0, lsl #48
    d4a8:      	b	0xd4c8 <_stogir.schedule.entry-prefix+0x1dc>
    d4ac:      	cmp	x0, #0x47
    d4b0:      	cset	w0, eq
    d4b4:      	uxtb	w16, w0
    d4b8:      	cmp	w16, wzr
    d4bc:      	mov	x16, #0x1               ; =1
    d4c0:      	mov	x17, #0x2               ; =2
    d4c4:      	csel	x0, x16, x17, ne
    d4c8:      	cmp	x0, x21
    d4cc:      	b.ne	0xd580 <_stogir.schedule.entry-prefix+0x294>
    d4d0:      	add	x16, sp, #0x10
    d4d4:      	ldr	x0, [x16, #0x8]
    d4d8:      	orr	x26, x0, xzr
    d4dc:      	add	x16, sp, #0x10
    d4e0:      	ldr	x0, [x16, #0x10]
    d4e4:      	cmp	x26, x0
    d4e8:      	b.lt	0xd58c <_stogir.schedule.entry-prefix+0x2a0>
    d4ec:      	cmp	x0, #0x0
    d4f0:      	b.ne	0xd374 <_stogir.schedule.entry-prefix+0x88>
    d4f4:      	mov	x0, #0x2                ; =2
    d4f8:      	b	0xd378 <_stogir.schedule.entry-prefix+0x8c>
    d4fc:      	add	x16, sp, #0x10
    d500:      	ldr	x0, [x16]
    d504:      	add	x16, sp, #0x10
    d508:      	ldr	x1, [x16, #0x8]
    d50c:      	add	x16, sp, #0x10
    d510:      	ldr	x2, [x16, #0x10]
    d514:      	add	x16, sp, #0x10
    d518:      	ldr	x3, [x16, #0x18]
    d51c:      	add	x16, sp, #0x10
    d520:      	ldr	x4, [x16, #0x20]
    d524:      	str	x0, [x27]
    d528:      	str	x1, [x27, #0x8]
    d52c:      	str	x2, [x27, #0x10]
    d530:      	str	x3, [x27, #0x18]
    d534:      	str	x4, [x27, #0x20]
    d538:      	ldr	x19, [sp, #0x40]
    d53c:      	ldr	x20, [sp, #0x48]
    d540:      	ldr	x21, [sp, #0x50]
    d544:      	ldr	x22, [sp, #0x58]
    d548:      	ldr	x23, [sp, #0x60]
    d54c:      	ldr	x24, [sp, #0x68]
    d550:      	ldr	x25, [sp, #0x70]
    d554:      	ldr	x26, [sp, #0x78]
    d558:      	ldr	x27, [sp, #0x80]
    d55c:      	ldr	x28, [sp, #0x88]
    d560:      	ldr	x29, [sp]
    d564:      	ldr	x30, [sp, #0x8]
    d568:      	add	sp, sp, #0x90
    d56c:      	ret
    d570:      	brk	#0
    d574:      	b	0xd570 <_stogir.schedule.entry-prefix+0x284>
    d578:      	mov	x27, x8
    d57c:      	b	0xd4fc <_stogir.schedule.entry-prefix+0x210>
    d580:      	mov	x27, x8
    d584:      	mov	x28, x1
    d588:      	b	0xd3a8 <_stogir.schedule.entry-prefix+0xbc>
    d58c:      	mov	x27, x8
    d590:      	mov	x28, x1
    d594:      	b	0xd38c <_stogir.schedule.entry-prefix+0xa0>

000000000000d598 <_stogir.checked-schedule.validate>:
    d598:      	sub	sp, sp, #0x40
    d59c:      	str	x29, [sp]
    d5a0:      	str	x30, [sp, #0x8]
    d5a4:      	mov	x29, sp
    d5a8:      	str	x19, [sp, #0x30]
    d5ac:      	add	x1, x1, #0x28
    d5b0:      	mov	x19, x8
    d5b4:      	add	x8, sp, #0x10
    d5b8:      	bl	0xd5b8 <_stogir.checked-schedule.validate+0x20>
		000000000000d5b8:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    d5bc:      	add	x16, sp, #0x10
    d5c0:      	ldr	x0, [x16]
    d5c4:      	str	x0, [x19]
    d5c8:      	add	x16, sp, #0x10
    d5cc:      	ldr	x0, [x16, #0x8]
    d5d0:      	str	x0, [x19, #0x8]
    d5d4:      	add	x16, sp, #0x10
    d5d8:      	ldr	x0, [x16, #0x10]
    d5dc:      	str	x0, [x19, #0x10]
    d5e0:      	ldr	x19, [sp, #0x30]
    d5e4:      	ldr	x29, [sp]
    d5e8:      	ldr	x30, [sp, #0x8]
    d5ec:      	add	sp, sp, #0x40
    d5f0:      	ret

000000000000d5f4 <_stogir.checked.projection>:
    d5f4:      	sub	sp, sp, #0x40
    d5f8:      	str	x29, [sp]
    d5fc:      	str	x30, [sp, #0x8]
    d600:      	mov	x29, sp
    d604:      	str	x19, [sp, #0x30]
    d608:      	sxtw	x2, w1
    d60c:      	cmp	x2, #0x0
    d610:      	cset	w3, gt
    d614:      	movz	x16, #0x0, lsl #48
    d618:      	sub	x4, x16, x2
    d61c:      	sub	x5, x4, #0x1
    d620:      	uxtb	w16, w3
    d624:      	cmp	w16, wzr
    d628:      	b.eq	0xd668 <_stogir.checked.projection+0x74>
    d62c:      	ldr	x4, [x0, #0x8]
    d630:      	cmp	x2, x4
    d634:      	b.ge	0xd6b8 <_stogir.checked.projection+0xc4>
    d638:      	add	x4, x0, #0x78
    d63c:      	ldr	x4, [x4, #0x8]
    d640:      	cmp	x2, x4
    d644:      	b.ge	0xd7b8 <_stogir.checked.projection+0x1c4>
    d648:      	ldr	x4, [x0, #0x78]
    d64c:      	add	x4, x4, x2, lsl #2
    d650:      	ldr	w4, [x4]
    d654:      	sxtw	x4, w4
    d658:      	cmp	x4, #0x0
    d65c:      	cset	w4, ge
    d660:      	ubfx	x4, x4, #0, #8
    d664:      	b	0xd7bc <_stogir.checked.projection+0x1c8>
    d668:      	cmp	x2, #0x0
    d66c:      	b.ge	0xd6c0 <_stogir.checked.projection+0xcc>
    d670:      	add	x6, x0, #0x28
    d674:      	add	x7, x0, #0x50
    d678:      	ldr	x6, [x6, #0x8]
    d67c:      	ldr	x7, [x7, #0x8]
    d680:      	cmp	x6, x7
    d684:      	b.ne	0xd6b0 <_stogir.checked.projection+0xbc>
    d688:      	cmp	x4, x6
    d68c:      	b.gt	0xd7e8 <_stogir.checked.projection+0x1f4>
    d690:      	ldr	x4, [x0, #0x50]
    d694:      	add	x4, x4, x5, lsl #2
    d698:      	ldr	w4, [x4]
    d69c:      	sxtw	x4, w4
    d6a0:      	cmp	x4, #0x0
    d6a4:      	cset	w4, gt
    d6a8:      	ubfx	x4, x4, #0, #8
    d6ac:      	b	0xd7ec <_stogir.checked.projection+0x1f8>
    d6b0:      	movz	x4, #0x0, lsl #48
    d6b4:      	b	0xd6c4 <_stogir.checked.projection+0xd0>
    d6b8:      	movz	x4, #0x0, lsl #48
    d6bc:      	b	0xd6c4 <_stogir.checked.projection+0xd0>
    d6c0:      	movz	x4, #0x0, lsl #48
    d6c4:      	cmp	x4, #0x0
    d6c8:      	b.eq	0xd6fc <_stogir.checked.projection+0x108>
    d6cc:      	uxtb	w16, w3
    d6d0:      	cmp	w16, wzr
    d6d4:      	b.eq	0xd6e8 <_stogir.checked.projection+0xf4>
    d6d8:      	ldr	x3, [x0]
    d6dc:      	add	x2, x3, x2, lsl #4
    d6e0:      	ldr	x2, [x2]
    d6e4:      	b	0xd6f4 <_stogir.checked.projection+0x100>
    d6e8:      	ldr	x2, [x0, #0x28]
    d6ec:      	add	x2, x2, x5, lsl #4
    d6f0:      	ldr	x2, [x2]
    d6f4:      	mov	w3, #0x1                ; =1
    d6f8:      	b	0xd704 <_stogir.checked.projection+0x110>
    d6fc:      	movz	w3, #0x0, lsl #16
    d700:      	movz	x2, #0x0, lsl #48
    d704:      	ubfx	x3, x3, #0, #32
    d708:      	lsr	x16, x3, #0
    d70c:      	cmp	x16, #0x1
    d710:      	b.eq	0xd72c <_stogir.checked.projection+0x138>
    d714:      	b.lo	0xd71c <_stogir.checked.projection+0x128>
    d718:      	b	0xd730 <_stogir.checked.projection+0x13c>
    d71c:      	cmp	x16, #0x0
    d720:      	b.eq	0xd728 <_stogir.checked.projection+0x134>
    d724:      	b	0xd730 <_stogir.checked.projection+0x13c>
    d728:      	b	0xd734 <_stogir.checked.projection+0x140>
    d72c:      	b	0xd77c <_stogir.checked.projection+0x188>
    d730:      	b	0xd7f0 <_stogir.checked.projection+0x1fc>
    d734:      	mov	x19, x8
    d738:      	mov	x0, #0x1                ; =1
    d73c:      	adrp	x1, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000d73c:  ARM64_RELOC_PAGE21	l_stogir.511
    d740:      	ldr	x1, [x1]
		000000000000d740:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    d744:      	mov	x2, #0x17               ; =23
    d748:      	b	0xd75c <_stogir.checked.projection+0x168>
    d74c:      	mov	x0, #0x1                ; =1
    d750:      	adrp	x1, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000d750:  ARM64_RELOC_PAGE21	l_stogir.512
    d754:      	ldr	x1, [x1]
		000000000000d754:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    d758:      	mov	x2, #0x20               ; =32
    d75c:      	str	x0, [x19]
    d760:      	str	x1, [x19, #0x8]
    d764:      	str	x2, [x19, #0x10]
    d768:      	ldr	x19, [sp, #0x30]
    d76c:      	ldr	x29, [sp]
    d770:      	ldr	x30, [sp, #0x8]
    d774:      	add	sp, sp, #0x40
    d778:      	ret
    d77c:      	uxtb	w3, w2
    d780:      	cmp	x3, #0x29
    d784:      	b.lt	0xd7f8 <_stogir.checked.projection+0x204>
    d788:      	cmp	x3, #0x2b
    d78c:      	b.gt	0xd800 <_stogir.checked.projection+0x20c>
    d790:      	mov	x19, x8
    d794:      	add	x8, sp, #0x10
    d798:      	bl	0xd798 <_stogir.checked.projection+0x1a4>
		000000000000d798:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    d79c:      	add	x16, sp, #0x10
    d7a0:      	ldr	x0, [x16]
    d7a4:      	add	x16, sp, #0x10
    d7a8:      	ldr	x1, [x16, #0x8]
    d7ac:      	add	x16, sp, #0x10
    d7b0:      	ldr	x2, [x16, #0x10]
    d7b4:      	b	0xd75c <_stogir.checked.projection+0x168>
    d7b8:      	movz	x4, #0x0, lsl #48
    d7bc:      	b	0xd6bc <_stogir.checked.projection+0xc8>
    d7c0:      	ubfx	x2, x2, #0, #32
    d7c4:      	ubfx	x0, x2, #8, #8
    d7c8:      	cmp	x0, #0x0
    d7cc:      	b.eq	0xd74c <_stogir.checked.projection+0x158>
    d7d0:      	cmp	x0, #0xd
    d7d4:      	b.gt	0xd74c <_stogir.checked.projection+0x158>
    d7d8:      	movz	x0, #0x0, lsl #48
    d7dc:      	movz	x1, #0x0, lsl #48
    d7e0:      	movz	x2, #0x0, lsl #48
    d7e4:      	b	0xd75c <_stogir.checked.projection+0x168>
    d7e8:      	movz	x4, #0x0, lsl #48
    d7ec:      	b	0xd6b4 <_stogir.checked.projection+0xc0>
    d7f0:      	brk	#0
    d7f4:      	b	0xd7f0 <_stogir.checked.projection+0x1fc>
    d7f8:      	mov	x19, x8
    d7fc:      	b	0xd7c0 <_stogir.checked.projection+0x1cc>
    d800:      	mov	x19, x8
    d804:      	b	0xd7c0 <_stogir.checked.projection+0x1cc>

000000000000d808 <_stogir.checked-schedule.validate-nodes>:
    d808:      	sub	sp, sp, #0xe0
    d80c:      	str	x29, [sp]
    d810:      	str	x30, [sp, #0x8]
    d814:      	mov	x29, sp
    d818:      	str	x19, [sp, #0x88]
    d81c:      	str	x20, [sp, #0x90]
    d820:      	str	x21, [sp, #0x98]
    d824:      	str	x22, [sp, #0xa0]
    d828:      	str	x23, [sp, #0xa8]
    d82c:      	str	x24, [sp, #0xb0]
    d830:      	str	x25, [sp, #0xb8]
    d834:      	str	x26, [sp, #0xc0]
    d838:      	str	x27, [sp, #0xc8]
    d83c:      	str	x28, [sp, #0xd0]
    d840:      	add	x19, x0, #0x78
    d844:      	add	x20, x0, #0x28
    d848:      	add	x21, x0, #0x50
    d84c:      	add	x16, sp, #0x20
    d850:      	orr	x2, x16, xzr
    d854:      	add	x22, x2, #0x8
    d858:      	add	x16, sp, #0x40
    d85c:      	orr	x2, x16, xzr
    d860:      	ldr	x3, [x1]
    d864:      	add	x23, x2, #0x8
    d868:      	orr	x24, x3, xzr
    d86c:      	ldr	x1, [x1, #0x8]
    d870:      	orr	x25, x1, xzr
    d874:      	movz	x26, #0x0, lsl #48
    d878:      	adrp	x27, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000d878:  ARM64_RELOC_PAGE21	l_stogir.513
    d87c:      	ldr	x27, [x27]
		000000000000d87c:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    d880:      	movz	x28, #0x0, lsl #48
    d884:      	movz	w1, #0x0, lsl #16
    d888:      	movz	x2, #0x0, lsl #48
    d88c:      	b	0xd8b4 <_stogir.checked-schedule.validate-nodes+0xac>
    d890:      	adrp	x27, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000d890:  ARM64_RELOC_PAGE21	l_stogir.514
    d894:      	ldr	x27, [x27]
		000000000000d894:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    d898:      	mov	x28, #0x24              ; =36
    d89c:      	mov	x8, x19
    d8a0:      	ldr	x0, [sp, #0x68]
    d8a4:      	ldr	x19, [sp, #0x60]
    d8a8:      	mov	w1, w20
    d8ac:      	ldr	x20, [sp, #0x70]
    d8b0:      	ldr	x2, [sp, #0x78]
    d8b4:      	cmp	x2, x25
    d8b8:      	b.ge	0xd8dc <_stogir.checked-schedule.validate-nodes+0xd4>
    d8bc:      	add	x3, x2, #0x1
    d8c0:      	add	x2, x24, x2, lsl #2
    d8c4:      	ldr	w2, [x2]
    d8c8:      	movn	w17, #0x0, lsl #16
    d8cc:      	and	w4, w2, w17
    d8d0:      	mov	x2, x3
    d8d4:      	mov	w3, #0x1                ; =1
    d8d8:      	b	0xd8e4 <_stogir.checked-schedule.validate-nodes+0xdc>
    d8dc:      	movz	w3, #0x0, lsl #16
    d8e0:      	movz	w4, #0x0, lsl #16
    d8e4:      	ubfx	x3, x3, #0, #32
    d8e8:      	lsr	x16, x3, #0
    d8ec:      	cmp	x16, #0x1
    d8f0:      	b.eq	0xd910 <_stogir.checked-schedule.validate-nodes+0x108>
    d8f4:      	b.lo	0xd8fc <_stogir.checked-schedule.validate-nodes+0xf4>
    d8f8:      	b	0xd914 <_stogir.checked-schedule.validate-nodes+0x10c>
    d8fc:      	cmp	x16, #0x0
    d900:      	b.eq	0xd908 <_stogir.checked-schedule.validate-nodes+0x100>
    d904:      	b	0xd914 <_stogir.checked-schedule.validate-nodes+0x10c>
    d908:      	mov	x19, x8
    d90c:      	b	0xd97c <_stogir.checked-schedule.validate-nodes+0x174>
    d910:      	b	0xd918 <_stogir.checked-schedule.validate-nodes+0x110>
    d914:      	b	0xdbe4 <_stogir.checked-schedule.validate-nodes+0x3dc>
    d918:      	cmp	x28, #0x0
    d91c:      	b.ne	0xdc4c <_stogir.checked-schedule.validate-nodes+0x444>
    d920:      	sxtw	x3, w4
    d924:      	cmp	x3, #0x0
    d928:      	cset	w5, gt
    d92c:      	movz	x16, #0x0, lsl #48
    d930:      	sub	x6, x16, x3
    d934:      	sub	x7, x6, #0x1
    d938:      	uxtb	w16, w5
    d93c:      	cmp	w16, wzr
    d940:      	b.eq	0xd9dc <_stogir.checked-schedule.validate-nodes+0x1d4>
    d944:      	ldr	x6, [x0, #0x8]
    d948:      	cmp	x3, x6
    d94c:      	b.ge	0xda1c <_stogir.checked-schedule.validate-nodes+0x214>
    d950:      	ldr	x6, [x19, #0x8]
    d954:      	cmp	x3, x6
    d958:      	b.ge	0xdb5c <_stogir.checked-schedule.validate-nodes+0x354>
    d95c:      	ldr	x6, [x0, #0x78]
    d960:      	add	x6, x6, x3, lsl #2
    d964:      	ldr	w6, [x6]
    d968:      	sxtw	x6, w6
    d96c:      	cmp	x6, #0x0
    d970:      	cset	w6, ge
    d974:      	ubfx	x6, x6, #0, #8
    d978:      	b	0xdb60 <_stogir.checked-schedule.validate-nodes+0x358>
    d97c:      	cmp	x28, #0x0
    d980:      	b.ne	0xd994 <_stogir.checked-schedule.validate-nodes+0x18c>
    d984:      	and	x27, x26, #0xffffffff
    d988:      	movz	x0, #0x0, lsl #48
    d98c:      	movz	x28, #0x0, lsl #48
    d990:      	b	0xd998 <_stogir.checked-schedule.validate-nodes+0x190>
    d994:      	mov	x0, #0x1                ; =1
    d998:      	str	x0, [x19]
    d99c:      	str	x27, [x19, #0x8]
    d9a0:      	str	x28, [x19, #0x10]
    d9a4:      	ldr	x19, [sp, #0x88]
    d9a8:      	ldr	x20, [sp, #0x90]
    d9ac:      	ldr	x21, [sp, #0x98]
    d9b0:      	ldr	x22, [sp, #0xa0]
    d9b4:      	ldr	x23, [sp, #0xa8]
    d9b8:      	ldr	x24, [sp, #0xb0]
    d9bc:      	ldr	x25, [sp, #0xb8]
    d9c0:      	ldr	x26, [sp, #0xc0]
    d9c4:      	ldr	x27, [sp, #0xc8]
    d9c8:      	ldr	x28, [sp, #0xd0]
    d9cc:      	ldr	x29, [sp]
    d9d0:      	ldr	x30, [sp, #0x8]
    d9d4:      	add	sp, sp, #0xe0
    d9d8:      	ret
    d9dc:      	cmp	x3, #0x0
    d9e0:      	b.ge	0xda24 <_stogir.checked-schedule.validate-nodes+0x21c>
    d9e4:      	ldr	x9, [x20, #0x8]
    d9e8:      	ldr	x10, [x21, #0x8]
    d9ec:      	cmp	x9, x10
    d9f0:      	b.ne	0xdb54 <_stogir.checked-schedule.validate-nodes+0x34c>
    d9f4:      	cmp	x6, x9
    d9f8:      	b.gt	0xdbcc <_stogir.checked-schedule.validate-nodes+0x3c4>
    d9fc:      	ldr	x6, [x0, #0x50]
    da00:      	add	x6, x6, x7, lsl #2
    da04:      	ldr	w6, [x6]
    da08:      	sxtw	x6, w6
    da0c:      	cmp	x6, #0x0
    da10:      	cset	w6, gt
    da14:      	ubfx	x6, x6, #0, #8
    da18:      	b	0xdbd0 <_stogir.checked-schedule.validate-nodes+0x3c8>
    da1c:      	movz	x6, #0x0, lsl #48
    da20:      	b	0xda28 <_stogir.checked-schedule.validate-nodes+0x220>
    da24:      	movz	x6, #0x0, lsl #48
    da28:      	cmp	x6, #0x0
    da2c:      	b.eq	0xda68 <_stogir.checked-schedule.validate-nodes+0x260>
    da30:      	uxtb	w16, w5
    da34:      	cmp	w16, wzr
    da38:      	b.eq	0xda50 <_stogir.checked-schedule.validate-nodes+0x248>
    da3c:      	ldr	x5, [x0]
    da40:      	add	x3, x5, x3, lsl #4
    da44:      	ldr	x5, [x3]
    da48:      	ldr	x3, [x3, #0x8]
    da4c:      	b	0xda60 <_stogir.checked-schedule.validate-nodes+0x258>
    da50:      	ldr	x3, [x0, #0x28]
    da54:      	add	x3, x3, x7, lsl #4
    da58:      	ldr	x5, [x3]
    da5c:      	ldr	x3, [x3, #0x8]
    da60:      	mov	w6, #0x1                ; =1
    da64:      	b	0xda74 <_stogir.checked-schedule.validate-nodes+0x26c>
    da68:      	movz	w6, #0x0, lsl #16
    da6c:      	movz	x5, #0x0, lsl #48
    da70:      	movz	x3, #0x0, lsl #48
    da74:      	ubfx	x6, x6, #0, #32
    da78:      	lsr	x16, x6, #0
    da7c:      	cmp	x16, #0x1
    da80:      	b.eq	0xdab4 <_stogir.checked-schedule.validate-nodes+0x2ac>
    da84:      	b.lo	0xda8c <_stogir.checked-schedule.validate-nodes+0x284>
    da88:      	b	0xdab8 <_stogir.checked-schedule.validate-nodes+0x2b0>
    da8c:      	cmp	x16, #0x0
    da90:      	b.eq	0xda98 <_stogir.checked-schedule.validate-nodes+0x290>
    da94:      	b	0xdab8 <_stogir.checked-schedule.validate-nodes+0x2b0>
    da98:      	str	x0, [sp, #0x68]
    da9c:      	str	x19, [sp, #0x60]
    daa0:      	mov	x19, x8
    daa4:      	str	x20, [sp, #0x70]
    daa8:      	mov	w20, w1
    daac:      	str	x2, [sp, #0x78]
    dab0:      	b	0xd890 <_stogir.checked-schedule.validate-nodes+0x88>
    dab4:      	b	0xdabc <_stogir.checked-schedule.validate-nodes+0x2b4>
    dab8:      	b	0xdc34 <_stogir.checked-schedule.validate-nodes+0x42c>
    dabc:      	uxtb	w6, w5
    dac0:      	add	x16, sp, #0x10
    dac4:      	str	x5, [x16]
    dac8:      	add	x16, sp, #0x10
    dacc:      	str	x3, [x16, #0x8]
    dad0:      	cmp	x6, #0x29
    dad4:      	b.lt	0xdc68 <_stogir.checked-schedule.validate-nodes+0x460>
    dad8:      	cmp	x6, #0x2b
    dadc:      	b.gt	0xdc88 <_stogir.checked-schedule.validate-nodes+0x480>
    dae0:      	str	x0, [sp, #0x68]
    dae4:      	str	x2, [sp, #0x78]
    dae8:      	str	w4, [sp, #0x80]
    daec:      	str	x19, [sp, #0x60]
    daf0:      	mov	x19, x8
    daf4:      	add	x8, sp, #0x20
    daf8:      	str	x20, [sp, #0x70]
    dafc:      	mov	w20, w1
    db00:      	mov	w1, w4
    db04:      	bl	0xdb04 <_stogir.checked-schedule.validate-nodes+0x2fc>
		000000000000db04:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    db08:      	add	x16, sp, #0x20
    db0c:      	ldr	w0, [x16]
    db10:      	lsr	x16, x0, #0
    db14:      	cmp	x16, #0x1
    db18:      	b.eq	0xdb34 <_stogir.checked-schedule.validate-nodes+0x32c>
    db1c:      	b.lo	0xdb24 <_stogir.checked-schedule.validate-nodes+0x31c>
    db20:      	b	0xdb38 <_stogir.checked-schedule.validate-nodes+0x330>
    db24:      	cmp	x16, #0x0
    db28:      	b.eq	0xdb30 <_stogir.checked-schedule.validate-nodes+0x328>
    db2c:      	b	0xdb38 <_stogir.checked-schedule.validate-nodes+0x330>
    db30:      	b	0xdbec <_stogir.checked-schedule.validate-nodes+0x3e4>
    db34:      	b	0xdb3c <_stogir.checked-schedule.validate-nodes+0x334>
    db38:      	b	0xdc44 <_stogir.checked-schedule.validate-nodes+0x43c>
    db3c:      	add	x16, sp, #0x20
    db40:      	ldr	x27, [x16, #0x8]
    db44:      	ldr	x28, [x22, #0x8]
    db48:      	b	0xdbf0 <_stogir.checked-schedule.validate-nodes+0x3e8>
    db4c:      	movz	w20, #0x0, lsl #16
    db50:      	b	0xd89c <_stogir.checked-schedule.validate-nodes+0x94>
    db54:      	movz	x6, #0x0, lsl #48
    db58:      	b	0xda28 <_stogir.checked-schedule.validate-nodes+0x220>
    db5c:      	movz	x6, #0x0, lsl #48
    db60:      	b	0xda20 <_stogir.checked-schedule.validate-nodes+0x218>
    db64:      	add	x16, sp, #0x10
    db68:      	ldr	w0, [x16]
    db6c:      	uxtb	w0, w0
    db70:      	cmp	x0, #0x2c
    db74:      	b.ne	0xdb4c <_stogir.checked-schedule.validate-nodes+0x344>
    db78:      	add	x8, sp, #0x40
    db7c:      	ldr	x0, [sp, #0x68]
    db80:      	ldr	w1, [sp, #0x80]
    db84:      	bl	0xdb84 <_stogir.checked-schedule.validate-nodes+0x37c>
		000000000000db84:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    db88:      	add	x16, sp, #0x40
    db8c:      	ldr	w0, [x16]
    db90:      	lsr	x16, x0, #0
    db94:      	cmp	x16, #0x1
    db98:      	b.eq	0xdbb4 <_stogir.checked-schedule.validate-nodes+0x3ac>
    db9c:      	b.lo	0xdba4 <_stogir.checked-schedule.validate-nodes+0x39c>
    dba0:      	b	0xdbb8 <_stogir.checked-schedule.validate-nodes+0x3b0>
    dba4:      	cmp	x16, #0x0
    dba8:      	b.eq	0xdbb0 <_stogir.checked-schedule.validate-nodes+0x3a8>
    dbac:      	b	0xdbb8 <_stogir.checked-schedule.validate-nodes+0x3b0>
    dbb0:      	b	0xdbf4 <_stogir.checked-schedule.validate-nodes+0x3ec>
    dbb4:      	b	0xdbbc <_stogir.checked-schedule.validate-nodes+0x3b4>
    dbb8:      	b	0xdc3c <_stogir.checked-schedule.validate-nodes+0x434>
    dbbc:      	add	x16, sp, #0x40
    dbc0:      	ldr	x27, [x16, #0x8]
    dbc4:      	ldr	x28, [x23, #0x8]
    dbc8:      	b	0xdbe0 <_stogir.checked-schedule.validate-nodes+0x3d8>
    dbcc:      	movz	x6, #0x0, lsl #48
    dbd0:      	b	0xdb58 <_stogir.checked-schedule.validate-nodes+0x350>
    dbd4:      	adrp	x27, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000dbd4:  ARM64_RELOC_PAGE21	l_stogir.515
    dbd8:      	ldr	x27, [x27]
		000000000000dbd8:  ARM64_RELOC_PAGEOFF12	l_stogir.515
    dbdc:      	mov	x28, #0x35              ; =53
    dbe0:      	b	0xdb50 <_stogir.checked-schedule.validate-nodes+0x348>
    dbe4:      	brk	#0
    dbe8:      	b	0xdbe4 <_stogir.checked-schedule.validate-nodes+0x3dc>
    dbec:      	ldr	w20, [sp, #0x80]
    dbf0:      	b	0xdb50 <_stogir.checked-schedule.validate-nodes+0x348>
    dbf4:      	add	x16, sp, #0x40
    dbf8:      	ldr	w0, [x16, #0x8]
    dbfc:      	sxtw	x0, w0
    dc00:      	cmp	x0, #0x0
    dc04:      	b.ne	0xdc10 <_stogir.checked-schedule.validate-nodes+0x408>
    dc08:      	movz	w20, #0x0, lsl #16
    dc0c:      	b	0xdbe0 <_stogir.checked-schedule.validate-nodes+0x3d8>
    dc10:      	sxtw	x0, w20
    dc14:      	add	x16, sp, #0x10
    dc18:      	ldr	w1, [x16, #0x4]
    dc1c:      	sxtw	x1, w1
    dc20:      	cmp	x0, x1
    dc24:      	b.ne	0xdbd4 <_stogir.checked-schedule.validate-nodes+0x3cc>
    dc28:      	add	x0, x26, #0x1
    dc2c:      	sxtw	x26, w0
    dc30:      	b	0xdbe0 <_stogir.checked-schedule.validate-nodes+0x3d8>
    dc34:      	brk	#0
    dc38:      	b	0xdc34 <_stogir.checked-schedule.validate-nodes+0x42c>
    dc3c:      	brk	#0
    dc40:      	b	0xdc3c <_stogir.checked-schedule.validate-nodes+0x434>
    dc44:      	brk	#0
    dc48:      	b	0xdc44 <_stogir.checked-schedule.validate-nodes+0x43c>
    dc4c:      	str	x0, [sp, #0x68]
    dc50:      	str	x19, [sp, #0x60]
    dc54:      	mov	x19, x8
    dc58:      	str	x20, [sp, #0x70]
    dc5c:      	mov	w20, w1
    dc60:      	str	x2, [sp, #0x78]
    dc64:      	b	0xd89c <_stogir.checked-schedule.validate-nodes+0x94>
    dc68:      	str	x0, [sp, #0x68]
    dc6c:      	str	w4, [sp, #0x80]
    dc70:      	str	x19, [sp, #0x60]
    dc74:      	mov	x19, x8
    dc78:      	str	x20, [sp, #0x70]
    dc7c:      	mov	w20, w1
    dc80:      	str	x2, [sp, #0x78]
    dc84:      	b	0xdb64 <_stogir.checked-schedule.validate-nodes+0x35c>
    dc88:      	str	x0, [sp, #0x68]
    dc8c:      	str	w4, [sp, #0x80]
    dc90:      	str	x19, [sp, #0x60]
    dc94:      	mov	x19, x8
    dc98:      	str	x20, [sp, #0x70]
    dc9c:      	mov	w20, w1
    dca0:      	str	x2, [sp, #0x78]
    dca4:      	b	0xdb64 <_stogir.checked-schedule.validate-nodes+0x35c>

000000000000dca8 <_coil.alloc.sized-free>:
    dca8:      	sub	sp, sp, #0x70
    dcac:      	str	x29, [sp]
    dcb0:      	str	x30, [sp, #0x8]
    dcb4:      	mov	x29, sp
    dcb8:      	str	x19, [sp, #0x60]
    dcbc:      	str	x20, [sp, #0x68]
    dcc0:      	cmp	x2, #0x0
    dcc4:      	b.ne	0xdce4 <_coil.alloc.sized-free+0x3c>
    dcc8:      	movz	x0, #0x0, lsl #48
    dccc:      	ldr	x19, [sp, #0x60]
    dcd0:      	ldr	x20, [sp, #0x68]
    dcd4:      	ldr	x29, [sp]
    dcd8:      	ldr	x30, [sp, #0x8]
    dcdc:      	add	sp, sp, #0x70
    dce0:      	ret
    dce4:      	add	x8, sp, #0x10
    dce8:      	mov	x19, x0
    dcec:      	mov	x0, x3
    dcf0:      	mov	x3, x2
    dcf4:      	mov	x2, x5
    dcf8:      	mov	x20, x1
    dcfc:      	mov	x1, x4
    dd00:      	bl	0xdd00 <_coil.alloc.sized-free+0x58>
		000000000000dd00:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    dd04:      	add	x16, sp, #0x10
    dd08:      	ldr	w0, [x16]
    dd0c:      	lsr	x16, x0, #0
    dd10:      	cmp	x16, #0x1
    dd14:      	b.eq	0xdd30 <_coil.alloc.sized-free+0x88>
    dd18:      	b.lo	0xdd20 <_coil.alloc.sized-free+0x78>
    dd1c:      	b	0xdd34 <_coil.alloc.sized-free+0x8c>
    dd20:      	cmp	x16, #0x0
    dd24:      	b.eq	0xdd2c <_coil.alloc.sized-free+0x84>
    dd28:      	b	0xdd34 <_coil.alloc.sized-free+0x8c>
    dd2c:      	b	0xdd38 <_coil.alloc.sized-free+0x90>
    dd30:      	b	0xdd40 <_coil.alloc.sized-free+0x98>
    dd34:      	b	0xdd9c <_coil.alloc.sized-free+0xf4>
    dd38:      	movz	x0, #0x0, lsl #48
    dd3c:      	b	0xdd98 <_coil.alloc.sized-free+0xf0>
    dd40:      	add	x16, sp, #0x10
    dd44:      	orr	x0, x16, xzr
    dd48:      	add	x16, sp, #0x40
    dd4c:      	orr	x1, x16, xzr
    dd50:      	add	x0, x0, #0x8
    dd54:      	add	x16, sp, #0x10
    dd58:      	ldr	x2, [x16, #0x8]
    dd5c:      	add	x16, sp, #0x40
    dd60:      	str	x2, [x16]
    dd64:      	ldr	x2, [x0, #0x8]
    dd68:      	add	x16, sp, #0x40
    dd6c:      	str	x2, [x16, #0x8]
    dd70:      	ldr	x2, [x0, #0x10]
    dd74:      	add	x16, sp, #0x40
    dd78:      	str	x2, [x16, #0x10]
    dd7c:      	ldr	x0, [x0, #0x18]
    dd80:      	add	x16, sp, #0x40
    dd84:      	str	x0, [x16, #0x18]
    dd88:      	mov	x0, x19
    dd8c:      	mov	x2, x1
    dd90:      	mov	x1, x20
    dd94:      	bl	0xdd94 <_coil.alloc.sized-free+0xec>
		000000000000dd94:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-free
    dd98:      	b	0xdccc <_coil.alloc.sized-free+0x24>
    dd9c:      	brk	#0
    dda0:      	b	0xdd9c <_coil.alloc.sized-free+0xf4>

000000000000dda4 <_stogir.types.valid?>:
    dda4:      	sxtw	x1, w0
    dda8:      	cmp	x1, #0x0
    ddac:      	b.lt	0xddc0 <_stogir.types.valid?+0x1c>
    ddb0:      	cmp	x1, #0xd
    ddb4:      	b.gt	0xddc0 <_stogir.types.valid?+0x1c>
    ddb8:      	mov	x0, #0x1                ; =1
    ddbc:      	b	0xddfc <_stogir.types.valid?+0x58>
    ddc0:      	cmp	x1, #0xf
    ddc4:      	b.le	0xddf8 <_stogir.types.valid?+0x54>
    ddc8:      	cmp	x1, #0x80
    ddcc:      	b.ge	0xddf0 <_stogir.types.valid?+0x4c>
    ddd0:      	and	w0, w0, #0xf
    ddd4:      	ubfx	x0, x0, #0, #32
    ddd8:      	cmp	x0, #0x1
    dddc:      	b.lt	0xde00 <_stogir.types.valid?+0x5c>
    dde0:      	cmp	x0, #0xd
    dde4:      	cset	w0, le
    dde8:      	ubfx	x0, x0, #0, #8
    ddec:      	b	0xde04 <_stogir.types.valid?+0x60>
    ddf0:      	movz	x0, #0x0, lsl #48
    ddf4:      	b	0xddfc <_stogir.types.valid?+0x58>
    ddf8:      	movz	x0, #0x0, lsl #48
    ddfc:      	ret
    de00:      	movz	x0, #0x0, lsl #48
    de04:      	b	0xddf4 <_stogir.types.valid?+0x50>

000000000000de08 <_stogir.opcode.input-count>:
    de08:      	sxtw	x0, w0
    de0c:      	cmp	x0, #0x0
    de10:      	b.lt	0xde34 <_stogir.opcode.input-count+0x2c>
    de14:      	cmp	x0, #0x83
    de18:      	b.ge	0xde34 <_stogir.opcode.input-count+0x2c>
    de1c:      	adrp	x16, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000de1c:  ARM64_RELOC_PAGE21	l_stogir.516
    de20:      	ldr	x16, [x16]
		000000000000de20:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    de24:      	add	x0, x16, x0
    de28:      	ldrsb	w0, [x0]
    de2c:      	sxtb	x0, w0
    de30:      	b	0xde38 <_stogir.opcode.input-count+0x30>
    de34:      	mov	x0, #-0x2               ; =-2
    de38:      	ret

000000000000de3c <_stogir.graph.borrow-node>:
    de3c:      	sxtw	x1, w1
    de40:      	cmp	x1, #0x0
    de44:      	cset	w2, gt
    de48:      	movz	x16, #0x0, lsl #48
    de4c:      	sub	x3, x16, x1
    de50:      	sub	x4, x3, #0x1
    de54:      	uxtb	w16, w2
    de58:      	cmp	w16, wzr
    de5c:      	b.eq	0xde9c <_stogir.graph.borrow-node+0x60>
    de60:      	ldr	x3, [x0, #0x8]
    de64:      	cmp	x1, x3
    de68:      	b.ge	0xdeec <_stogir.graph.borrow-node+0xb0>
    de6c:      	add	x3, x0, #0x78
    de70:      	ldr	x3, [x3, #0x8]
    de74:      	cmp	x1, x3
    de78:      	b.ge	0xdf2c <_stogir.graph.borrow-node+0xf0>
    de7c:      	ldr	x3, [x0, #0x78]
    de80:      	add	x3, x3, x1, lsl #2
    de84:      	ldr	w3, [x3]
    de88:      	sxtw	x3, w3
    de8c:      	cmp	x3, #0x0
    de90:      	cset	w3, ge
    de94:      	ubfx	x3, x3, #0, #8
    de98:      	b	0xdf30 <_stogir.graph.borrow-node+0xf4>
    de9c:      	cmp	x1, #0x0
    dea0:      	b.ge	0xdef4 <_stogir.graph.borrow-node+0xb8>
    dea4:      	add	x5, x0, #0x28
    dea8:      	add	x6, x0, #0x50
    deac:      	ldr	x5, [x5, #0x8]
    deb0:      	ldr	x6, [x6, #0x8]
    deb4:      	cmp	x5, x6
    deb8:      	b.ne	0xdee4 <_stogir.graph.borrow-node+0xa8>
    debc:      	cmp	x3, x5
    dec0:      	b.gt	0xdf34 <_stogir.graph.borrow-node+0xf8>
    dec4:      	ldr	x3, [x0, #0x50]
    dec8:      	add	x3, x3, x4, lsl #2
    decc:      	ldr	w3, [x3]
    ded0:      	sxtw	x3, w3
    ded4:      	cmp	x3, #0x0
    ded8:      	cset	w3, gt
    dedc:      	ubfx	x3, x3, #0, #8
    dee0:      	b	0xdf38 <_stogir.graph.borrow-node+0xfc>
    dee4:      	movz	x3, #0x0, lsl #48
    dee8:      	b	0xdef8 <_stogir.graph.borrow-node+0xbc>
    deec:      	movz	x3, #0x0, lsl #48
    def0:      	b	0xdef8 <_stogir.graph.borrow-node+0xbc>
    def4:      	movz	x3, #0x0, lsl #48
    def8:      	cmp	x3, #0x0
    defc:      	b.eq	0xdf24 <_stogir.graph.borrow-node+0xe8>
    df00:      	uxtb	w16, w2
    df04:      	cmp	w16, wzr
    df08:      	b.eq	0xdf18 <_stogir.graph.borrow-node+0xdc>
    df0c:      	ldr	x0, [x0]
    df10:      	add	x0, x0, x1, lsl #4
    df14:      	b	0xdf20 <_stogir.graph.borrow-node+0xe4>
    df18:      	ldr	x0, [x0, #0x28]
    df1c:      	add	x0, x0, x4, lsl #4
    df20:      	b	0xdf28 <_stogir.graph.borrow-node+0xec>
    df24:      	movz	x0, #0x0, lsl #48
    df28:      	ret
    df2c:      	movz	x3, #0x0, lsl #48
    df30:      	b	0xdef0 <_stogir.graph.borrow-node+0xb4>
    df34:      	movz	x3, #0x0, lsl #48
    df38:      	b	0xdee8 <_stogir.graph.borrow-node+0xac>

000000000000df3c <_stogir.verify.phis-structured>:
    df3c:      	sub	sp, sp, #0xd0
    df40:      	str	x29, [sp, #0x10]
    df44:      	str	x30, [sp, #0x18]
    df48:      	add	x29, sp, #0x10
    df4c:      	str	x19, [sp, #0x80]
    df50:      	str	x20, [sp, #0x88]
    df54:      	str	x21, [sp, #0x90]
    df58:      	str	x22, [sp, #0x98]
    df5c:      	str	x23, [sp, #0xa0]
    df60:      	str	x24, [sp, #0xa8]
    df64:      	str	x25, [sp, #0xb0]
    df68:      	str	x26, [sp, #0xb8]
    df6c:      	str	x27, [sp, #0xc0]
    df70:      	str	x28, [sp, #0xc8]
    df74:      	add	x19, x0, #0x78
    df78:      	add	x20, x0, #0x28
    df7c:      	add	x21, x0, #0x50
    df80:      	add	x22, x0, #0x78
    df84:      	mov	x23, #0x1               ; =1
    df88:      	movz	x24, #0x0, lsl #48
    df8c:      	adrp	x25, 0xd000 <_stogir.loops.heapify!+0xb8>
		000000000000df8c:  ARM64_RELOC_PAGE21	l_stogir.517
    df90:      	ldr	x25, [x25]
		000000000000df90:  ARM64_RELOC_PAGEOFF12	l_stogir.517
    df94:      	movz	x26, #0x0, lsl #48
    df98:      	b	0xe288 <_stogir.verify.phis-structured+0x34c>
    df9c:      	movz	x6, #0x0, lsl #48
    dfa0:      	b	0xdfb0 <_stogir.verify.phis-structured+0x74>
    dfa4:      	movz	x6, #0x0, lsl #48
    dfa8:      	b	0xdfb8 <_stogir.verify.phis-structured+0x7c>
    dfac:      	movz	x6, #0x0, lsl #48
    dfb0:      	b	0xdfc0 <_stogir.verify.phis-structured+0x84>
    dfb4:      	movz	x6, #0x0, lsl #48
    dfb8:      	b	0xdfc0 <_stogir.verify.phis-structured+0x84>
    dfbc:      	movz	x6, #0x0, lsl #48
    dfc0:      	cmp	x6, #0x0
    dfc4:      	b.eq	0xdff8 <_stogir.verify.phis-structured+0xbc>
    dfc8:      	uxtb	w16, w5
    dfcc:      	cmp	w16, wzr
    dfd0:      	b.eq	0xdfe4 <_stogir.verify.phis-structured+0xa8>
    dfd4:      	ldr	x5, [x25]
    dfd8:      	add	x4, x5, x4, lsl #4
    dfdc:      	ldr	x4, [x4]
    dfe0:      	b	0xdff0 <_stogir.verify.phis-structured+0xb4>
    dfe4:      	ldr	x4, [x25, #0x28]
    dfe8:      	add	x4, x4, x7, lsl #4
    dfec:      	ldr	x4, [x4]
    dff0:      	mov	w5, #0x1                ; =1
    dff4:      	b	0xe000 <_stogir.verify.phis-structured+0xc4>
    dff8:      	movz	w5, #0x0, lsl #16
    dffc:      	movz	x4, #0x0, lsl #48
    e000:      	ubfx	x5, x5, #0, #32
    e004:      	lsr	x16, x5, #0
    e008:      	cmp	x16, #0x1
    e00c:      	b.eq	0xe028 <_stogir.verify.phis-structured+0xec>
    e010:      	b.lo	0xe018 <_stogir.verify.phis-structured+0xdc>
    e014:      	b	0xe02c <_stogir.verify.phis-structured+0xf0>
    e018:      	cmp	x16, #0x0
    e01c:      	b.eq	0xe024 <_stogir.verify.phis-structured+0xe8>
    e020:      	b	0xe02c <_stogir.verify.phis-structured+0xf0>
    e024:      	b	0xe030 <_stogir.verify.phis-structured+0xf4>
    e028:      	b	0xe044 <_stogir.verify.phis-structured+0x108>
    e02c:      	b	0xe49c <_stogir.verify.phis-structured+0x560>
    e030:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e030:  ARM64_RELOC_PAGE21	l_stogir.518
    e034:      	ldr	x16, [x16]
		000000000000e034:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    e038:      	str	x16, [sp, #0x68]
    e03c:      	mov	x26, #0x11              ; =17
    e040:      	b	0xe064 <_stogir.verify.phis-structured+0x128>
    e044:      	ubfx	x4, x4, #0, #32
    e048:      	ubfx	x4, x4, #8, #8
    e04c:      	cmp	x4, x0
    e050:      	b.eq	0xe064 <_stogir.verify.phis-structured+0x128>
    e054:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e054:  ARM64_RELOC_PAGE21	l_stogir.519
    e058:      	ldr	x16, [x16]
		000000000000e058:  ARM64_RELOC_PAGEOFF12	l_stogir.519
    e05c:      	str	x16, [sp, #0x68]
    e060:      	mov	x26, #0x1a              ; =26
    e064:      	b	0xe0bc <_stogir.verify.phis-structured+0x180>
    e068:      	movz	w5, #0x0, lsl #16
    e06c:      	movz	w4, #0x0, lsl #16
    e070:      	b	0xe07c <_stogir.verify.phis-structured+0x140>
    e074:      	movz	w5, #0x0, lsl #16
    e078:      	movz	w4, #0x0, lsl #16
    e07c:      	ubfx	x5, x5, #0, #32
    e080:      	lsr	x16, x5, #0
    e084:      	cmp	x16, #0x1
    e088:      	b.eq	0xe0a4 <_stogir.verify.phis-structured+0x168>
    e08c:      	b.lo	0xe094 <_stogir.verify.phis-structured+0x158>
    e090:      	b	0xe0a8 <_stogir.verify.phis-structured+0x16c>
    e094:      	cmp	x16, #0x0
    e098:      	b.eq	0xe0a0 <_stogir.verify.phis-structured+0x164>
    e09c:      	b	0xe0a8 <_stogir.verify.phis-structured+0x16c>
    e0a0:      	b	0xe0ac <_stogir.verify.phis-structured+0x170>
    e0a4:      	b	0xe12c <_stogir.verify.phis-structured+0x1f0>
    e0a8:      	b	0xe494 <_stogir.verify.phis-structured+0x558>
    e0ac:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e0ac:  ARM64_RELOC_PAGE21	l_stogir.518
    e0b0:      	ldr	x16, [x16]
		000000000000e0b0:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    e0b4:      	str	x16, [sp, #0x68]
    e0b8:      	mov	x26, #0x11              ; =17
    e0bc:      	add	x3, x3, #0x1
    e0c0:      	sxtw	x3, w3
    e0c4:      	cmp	x26, #0x0
    e0c8:      	b.ne	0xe0dc <_stogir.verify.phis-structured+0x1a0>
    e0cc:      	cmp	x3, x28
    e0d0:      	cset	w4, le
    e0d4:      	ubfx	x4, x4, #0, #8
    e0d8:      	b	0xe0e0 <_stogir.verify.phis-structured+0x1a4>
    e0dc:      	movz	x4, #0x0, lsl #48
    e0e0:      	cmp	x4, #0x0
    e0e4:      	b.eq	0xe24c <_stogir.verify.phis-structured+0x310>
    e0e8:      	uxtb	w16, w1
    e0ec:      	cmp	w16, wzr
    e0f0:      	b.ne	0xe074 <_stogir.verify.phis-structured+0x138>
    e0f4:      	ldr	x4, [x25, #0x8]
    e0f8:      	cmp	x23, x4
    e0fc:      	b.ge	0xe190 <_stogir.verify.phis-structured+0x254>
    e100:      	ldr	x4, [x22, #0x8]
    e104:      	cmp	x23, x4
    e108:      	b.ge	0xe188 <_stogir.verify.phis-structured+0x24c>
    e10c:      	ldr	x4, [x25, #0x78]
    e110:      	add	x4, x2, x4
    e114:      	ldr	w4, [x4]
    e118:      	sxtw	x4, w4
    e11c:      	cmp	x4, #0x0
    e120:      	cset	w4, ge
    e124:      	ubfx	x4, x4, #0, #8
    e128:      	b	0xe18c <_stogir.verify.phis-structured+0x250>
    e12c:      	sxtw	x4, w4
    e130:      	cmp	x4, #0x0
    e134:      	cset	w5, gt
    e138:      	movz	x16, #0x0, lsl #48
    e13c:      	sub	x6, x16, x4
    e140:      	sub	x7, x6, #0x1
    e144:      	uxtb	w16, w5
    e148:      	cmp	w16, wzr
    e14c:      	b.eq	0xe20c <_stogir.verify.phis-structured+0x2d0>
    e150:      	ldr	x6, [x25, #0x8]
    e154:      	cmp	x4, x6
    e158:      	b.ge	0xdfb4 <_stogir.verify.phis-structured+0x78>
    e15c:      	ldr	x6, [x19, #0x8]
    e160:      	cmp	x4, x6
    e164:      	b.ge	0xdfa4 <_stogir.verify.phis-structured+0x68>
    e168:      	ldr	x6, [x25, #0x78]
    e16c:      	add	x6, x6, x4, lsl #2
    e170:      	ldr	w6, [x6]
    e174:      	sxtw	x6, w6
    e178:      	cmp	x6, #0x0
    e17c:      	cset	w6, ge
    e180:      	ubfx	x6, x6, #0, #8
    e184:      	b	0xdfa8 <_stogir.verify.phis-structured+0x6c>
    e188:      	movz	x4, #0x0, lsl #48
    e18c:      	b	0xe194 <_stogir.verify.phis-structured+0x258>
    e190:      	movz	x4, #0x0, lsl #48
    e194:      	cmp	x4, #0x0
    e198:      	b.eq	0xe074 <_stogir.verify.phis-structured+0x138>
    e19c:      	orr	w4, w3, wzr
    e1a0:      	sxtw	x4, w4
    e1a4:      	cmp	x4, #0x1
    e1a8:      	b.lt	0xe068 <_stogir.verify.phis-structured+0x12c>
    e1ac:      	ldr	x5, [x25, #0x78]
    e1b0:      	add	x5, x2, x5
    e1b4:      	ldr	w5, [x5]
    e1b8:      	sxtw	x5, w5
    e1bc:      	cmp	x4, x5
    e1c0:      	b.gt	0xe068 <_stogir.verify.phis-structured+0x12c>
    e1c4:      	ldr	x5, [x25]
    e1c8:      	asr	x16, x4, #63
    e1cc:      	lsr	x16, x16, #62
    e1d0:      	add	x6, x4, x16
    e1d4:      	asr	x6, x6, #2
    e1d8:      	asr	x16, x4, #63
    e1dc:      	lsr	x16, x16, #62
    e1e0:      	add	x4, x4, x16
    e1e4:      	and	x4, x4, #0x3
    e1e8:      	sub	x4, x4, x16
    e1ec:      	add	x6, x6, x23
    e1f0:      	add	x5, x5, x6, lsl #4
    e1f4:      	add	x4, x5, x4, lsl #2
    e1f8:      	ldr	w4, [x4]
    e1fc:      	movn	w17, #0x0, lsl #16
    e200:      	and	w4, w4, w17
    e204:      	mov	w5, #0x1                ; =1
    e208:      	b	0xe070 <_stogir.verify.phis-structured+0x134>
    e20c:      	cmp	x4, #0x0
    e210:      	b.ge	0xdfbc <_stogir.verify.phis-structured+0x80>
    e214:      	ldr	x8, [x20, #0x8]
    e218:      	ldr	x9, [x21, #0x8]
    e21c:      	cmp	x8, x9
    e220:      	b.ne	0xdfac <_stogir.verify.phis-structured+0x70>
    e224:      	cmp	x6, x8
    e228:      	b.gt	0xdf9c <_stogir.verify.phis-structured+0x60>
    e22c:      	ldr	x6, [x25, #0x50]
    e230:      	add	x6, x6, x7, lsl #2
    e234:      	ldr	w6, [x6]
    e238:      	sxtw	x6, w6
    e23c:      	cmp	x6, #0x0
    e240:      	cset	w6, gt
    e244:      	ubfx	x6, x6, #0, #8
    e248:      	b	0xdfa0 <_stogir.verify.phis-structured+0x64>
    e24c:      	ldr	x0, [sp, #0x78]
    e250:      	add	x0, x0, #0x1
    e254:      	sxtw	x0, w0
    e258:      	add	x1, x28, #0x4
    e25c:      	asr	x16, x1, #63
    e260:      	lsr	x16, x16, #62
    e264:      	add	x1, x1, x16
    e268:      	asr	x1, x1, #2
    e26c:      	ldr	x2, [sp, #0x70]
    e270:      	add	x2, x1, x2
    e274:      	ldr	x8, [sp, #0x60]
    e278:      	mov	x23, x2
    e27c:      	mov	x24, x0
    e280:      	mov	x0, x25
    e284:      	ldr	x25, [sp, #0x68]
    e288:      	cmp	x26, #0x0
    e28c:      	b.ne	0xe4e4 <_stogir.verify.phis-structured+0x5a8>
    e290:      	ldr	x1, [x0, #0x8]
    e294:      	cmp	x23, x1
    e298:      	b.ge	0xe4f4 <_stogir.verify.phis-structured+0x5b8>
    e29c:      	ldr	x1, [x0]
    e2a0:      	add	x1, x1, x23, lsl #4
    e2a4:      	ldr	x27, [x1]
    e2a8:      	ldr	x1, [x0, #0x78]
    e2ac:      	uxtb	w2, w27
    e2b0:      	add	x1, x1, x23, lsl #2
    e2b4:      	ldr	w1, [x1]
    e2b8:      	sxtw	x28, w1
    e2bc:      	cmp	x2, #0x43
    e2c0:      	b.ne	0xe504 <_stogir.verify.phis-structured+0x5c8>
    e2c4:      	orr	w1, w23, wzr
    e2c8:      	cmp	x28, #0x3
    e2cc:      	b.ge	0xe32c <_stogir.verify.phis-structured+0x3f0>
    e2d0:      	str	x23, [sp, #0x70]
    e2d4:      	str	x24, [sp, #0x78]
    e2d8:      	str	x8, [sp, #0x60]
    e2dc:      	mov	x25, x0
    e2e0:      	mov	w23, w1
    e2e4:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e2e4:  ARM64_RELOC_PAGE21	l_stogir.520
    e2e8:      	ldr	x16, [x16]
		000000000000e2e8:  ARM64_RELOC_PAGEOFF12	l_stogir.520
    e2ec:      	str	x16, [sp, #0x68]
    e2f0:      	mov	x26, #0x2b              ; =43
    e2f4:      	ubfx	x27, x27, #0, #32
    e2f8:      	ubfx	x0, x27, #8, #8
    e2fc:      	cmp	x0, #0x0
    e300:      	b.ne	0xe314 <_stogir.verify.phis-structured+0x3d8>
    e304:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e304:  ARM64_RELOC_PAGE21	l_stogir.521
    e308:      	ldr	x16, [x16]
		000000000000e308:  ARM64_RELOC_PAGEOFF12	l_stogir.521
    e30c:      	str	x16, [sp, #0x68]
    e310:      	mov	x26, #0x19              ; =25
    e314:      	sxtw	x23, w23
    e318:      	cmp	x23, #0x0
    e31c:      	cset	w1, le
    e320:      	lsl	x2, x23, #2
    e324:      	mov	x3, #0x2                ; =2
    e328:      	b	0xe0c4 <_stogir.verify.phis-structured+0x188>
    e32c:      	str	x8, [sp, #0x60]
    e330:      	str	x25, [sp, #0x68]
    e334:      	mov	x25, x0
    e338:      	str	x23, [sp, #0x70]
    e33c:      	mov	w23, w1
    e340:      	mov	x2, #0x1                ; =1
    e344:      	bl	0xe344 <_stogir.verify.phis-structured+0x408>
		000000000000e344:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    e348:      	ubfx	x0, x0, #0, #32
    e34c:      	lsr	x16, x0, #0
    e350:      	cmp	x16, #0x1
    e354:      	b.eq	0xe370 <_stogir.verify.phis-structured+0x434>
    e358:      	b.lo	0xe360 <_stogir.verify.phis-structured+0x424>
    e35c:      	b	0xe374 <_stogir.verify.phis-structured+0x438>
    e360:      	cmp	x16, #0x0
    e364:      	b.eq	0xe36c <_stogir.verify.phis-structured+0x430>
    e368:      	b	0xe374 <_stogir.verify.phis-structured+0x438>
    e36c:      	b	0xe378 <_stogir.verify.phis-structured+0x43c>
    e370:      	b	0xe3f4 <_stogir.verify.phis-structured+0x4b8>
    e374:      	b	0xe4d4 <_stogir.verify.phis-structured+0x598>
    e378:      	str	x24, [sp, #0x78]
    e37c:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e37c:  ARM64_RELOC_PAGE21	l_stogir.522
    e380:      	ldr	x16, [x16]
		000000000000e380:  ARM64_RELOC_PAGEOFF12	l_stogir.522
    e384:      	str	x16, [sp, #0x68]
    e388:      	mov	x26, #0x10              ; =16
    e38c:      	b	0xe2f4 <_stogir.verify.phis-structured+0x3b8>
    e390:      	cmp	x26, #0x0
    e394:      	b.ne	0xe51c <_stogir.verify.phis-structured+0x5e0>
    e398:      	and	x0, x0, #0xffffffff
    e39c:      	movz	x1, #0x0, lsl #48
    e3a0:      	movz	x26, #0x0, lsl #48
    e3a4:      	b	0xe3ac <_stogir.verify.phis-structured+0x470>
    e3a8:      	mov	x1, #0x1                ; =1
    e3ac:      	ldr	x2, [sp, #0x60]
    e3b0:      	str	x1, [x2]
    e3b4:      	str	x0, [x2, #0x8]
    e3b8:      	str	x26, [x2, #0x10]
    e3bc:      	ldr	x19, [sp, #0x80]
    e3c0:      	ldr	x20, [sp, #0x88]
    e3c4:      	ldr	x21, [sp, #0x90]
    e3c8:      	ldr	x22, [sp, #0x98]
    e3cc:      	ldr	x23, [sp, #0xa0]
    e3d0:      	ldr	x24, [sp, #0xa8]
    e3d4:      	ldr	x25, [sp, #0xb0]
    e3d8:      	ldr	x26, [sp, #0xb8]
    e3dc:      	ldr	x27, [sp, #0xc0]
    e3e0:      	ldr	x28, [sp, #0xc8]
    e3e4:      	ldr	x29, [sp, #0x10]
    e3e8:      	ldr	x30, [sp, #0x18]
    e3ec:      	add	sp, sp, #0xd0
    e3f0:      	ret
    e3f4:      	orr	w0, w1, wzr
    e3f8:      	add	x8, sp, #0x20
    e3fc:      	mov	w1, w0
    e400:      	str	x24, [sp, #0x78]
    e404:      	mov	w24, w0
    e408:      	mov	x0, x25
    e40c:      	bl	0xe40c <_stogir.verify.phis-structured+0x4d0>
		000000000000e40c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    e410:      	add	x16, sp, #0x20
    e414:      	ldr	w0, [x16]
    e418:      	lsr	x16, x0, #0
    e41c:      	cmp	x16, #0x1
    e420:      	b.eq	0xe43c <_stogir.verify.phis-structured+0x500>
    e424:      	b.lo	0xe42c <_stogir.verify.phis-structured+0x4f0>
    e428:      	b	0xe440 <_stogir.verify.phis-structured+0x504>
    e42c:      	cmp	x16, #0x0
    e430:      	b.eq	0xe438 <_stogir.verify.phis-structured+0x4fc>
    e434:      	b	0xe440 <_stogir.verify.phis-structured+0x504>
    e438:      	b	0xe444 <_stogir.verify.phis-structured+0x508>
    e43c:      	b	0xe458 <_stogir.verify.phis-structured+0x51c>
    e440:      	b	0xe4dc <_stogir.verify.phis-structured+0x5a0>
    e444:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e444:  ARM64_RELOC_PAGE21	l_stogir.523
    e448:      	ldr	x16, [x16]
		000000000000e448:  ARM64_RELOC_PAGEOFF12	l_stogir.523
    e44c:      	str	x16, [sp, #0x68]
    e450:      	mov	x26, #0x12              ; =18
    e454:      	b	0xe490 <_stogir.verify.phis-structured+0x554>
    e458:      	sxtw	x24, w24
    e45c:      	add	x16, sp, #0x20
    e460:      	ldr	x0, [x16, #0x8]
    e464:      	cmp	x24, #0x0
    e468:      	b.le	0xe480 <_stogir.verify.phis-structured+0x544>
    e46c:      	uxtb	w0, w0
    e470:      	cmp	x0, #0x70
    e474:      	b.eq	0xe4a4 <_stogir.verify.phis-structured+0x568>
    e478:      	cmp	x0, #0x71
    e47c:      	b.eq	0xe4a4 <_stogir.verify.phis-structured+0x568>
    e480:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e480:  ARM64_RELOC_PAGE21	l_stogir.524
    e484:      	ldr	x16, [x16]
		000000000000e484:  ARM64_RELOC_PAGEOFF12	l_stogir.524
    e488:      	str	x16, [sp, #0x68]
    e48c:      	mov	x26, #0x26              ; =38
    e490:      	b	0xe38c <_stogir.verify.phis-structured+0x450>
    e494:      	brk	#0
    e498:      	b	0xe494 <_stogir.verify.phis-structured+0x558>
    e49c:      	brk	#0
    e4a0:      	b	0xe49c <_stogir.verify.phis-structured+0x560>
    e4a4:      	ldr	x0, [x25, #0x78]
    e4a8:      	add	x0, x0, x24, lsl #2
    e4ac:      	ldr	w0, [x0]
    e4b0:      	add	w0, w0, #0x1
    e4b4:      	sxtw	x0, w0
    e4b8:      	cmp	x28, x0
    e4bc:      	b.eq	0xe4d0 <_stogir.verify.phis-structured+0x594>
    e4c0:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e4c0:  ARM64_RELOC_PAGE21	l_stogir.525
    e4c4:      	ldr	x16, [x16]
		000000000000e4c4:  ARM64_RELOC_PAGEOFF12	l_stogir.525
    e4c8:      	str	x16, [sp, #0x68]
    e4cc:      	mov	x26, #0x2b              ; =43
    e4d0:      	b	0xe490 <_stogir.verify.phis-structured+0x554>
    e4d4:      	brk	#0
    e4d8:      	b	0xe4d4 <_stogir.verify.phis-structured+0x598>
    e4dc:      	brk	#0
    e4e0:      	b	0xe4dc <_stogir.verify.phis-structured+0x5a0>
    e4e4:      	mov	x0, x24
    e4e8:      	str	x8, [sp, #0x60]
    e4ec:      	str	x25, [sp, #0x68]
    e4f0:      	b	0xe390 <_stogir.verify.phis-structured+0x454>
    e4f4:      	mov	x0, x24
    e4f8:      	str	x8, [sp, #0x60]
    e4fc:      	str	x25, [sp, #0x68]
    e500:      	b	0xe390 <_stogir.verify.phis-structured+0x454>
    e504:      	str	x23, [sp, #0x70]
    e508:      	str	x8, [sp, #0x60]
    e50c:      	str	x25, [sp, #0x68]
    e510:      	mov	x25, x0
    e514:      	mov	x0, x24
    e518:      	b	0xe258 <_stogir.verify.phis-structured+0x31c>
    e51c:      	ldr	x0, [sp, #0x68]
    e520:      	b	0xe3a8 <_stogir.verify.phis-structured+0x46c>

000000000000e524 <_inherent$coil.arraylist.ArrayList$reserve!__i32>:
    e524:      	sub	sp, sp, #0x50
    e528:      	str	x29, [sp]
    e52c:      	str	x30, [sp, #0x8]
    e530:      	mov	x29, sp
    e534:      	str	x19, [sp, #0x40]
    e538:      	str	x20, [sp, #0x48]
    e53c:      	add	x2, x0, #0x18
    e540:      	ldr	x3, [x0, #0x10]
    e544:      	ldr	x4, [x0, #0x18]
    e548:      	ldr	x2, [x2, #0x8]
    e54c:      	add	x16, sp, #0x10
    e550:      	str	x4, [x16]
    e554:      	add	x16, sp, #0x10
    e558:      	str	x2, [x16, #0x8]
    e55c:      	cmp	x1, x3
    e560:      	b.le	0xe5d4 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xb0>
    e564:      	add	x16, sp, #0x10
    e568:      	orr	x2, x16, xzr
    e56c:      	ldr	x4, [x0]
    e570:      	add	x8, sp, #0x20
    e574:      	mov	x19, x0
    e578:      	mov	x0, x2
    e57c:      	mov	x2, x3
    e580:      	mov	x3, x1
    e584:      	mov	x20, x1
    e588:      	mov	x1, x4
    e58c:      	bl	0xe58c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x68>
		000000000000e58c:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i32
    e590:      	add	x16, sp, #0x20
    e594:      	ldr	w0, [x16]
    e598:      	lsr	x16, x0, #0
    e59c:      	cmp	x16, #0x1
    e5a0:      	b.eq	0xe5bc <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x98>
    e5a4:      	b.lo	0xe5ac <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x88>
    e5a8:      	b	0xe5c0 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x9c>
    e5ac:      	cmp	x16, #0x0
    e5b0:      	b.eq	0xe5b8 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x94>
    e5b4:      	b	0xe5c0 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x9c>
    e5b8:      	b	0xe5f0 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xcc>
    e5bc:      	b	0xe5c4 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xa0>
    e5c0:      	b	0xe608 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe4>
    e5c4:      	add	x16, sp, #0x20
    e5c8:      	ldr	x0, [x16, #0x8]
    e5cc:      	str	x0, [x19]
    e5d0:      	str	x20, [x19, #0x10]
    e5d4:      	movz	x0, #0x0, lsl #48
    e5d8:      	ldr	x19, [sp, #0x40]
    e5dc:      	ldr	x20, [sp, #0x48]
    e5e0:      	ldr	x29, [sp]
    e5e4:      	ldr	x30, [sp, #0x8]
    e5e8:      	add	sp, sp, #0x50
    e5ec:      	ret
    e5f0:      	lsl	x0, x20, #2
    e5f4:      	mov	x1, x0
    e5f8:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e5f8:  ARM64_RELOC_PAGE21	l_stogir.526
    e5fc:      	ldr	x0, [x0]
		000000000000e5fc:  ARM64_RELOC_PAGEOFF12	l_stogir.526
    e600:      	bl	0xe600 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xdc>
		000000000000e600:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e604:      	b	0xe604 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe0>
    e608:      	brk	#0
    e60c:      	b	0xe608 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe4>

000000000000e610 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge>:
    e610:      	sub	sp, sp, #0x50
    e614:      	str	x29, [sp]
    e618:      	str	x30, [sp, #0x8]
    e61c:      	mov	x29, sp
    e620:      	str	x19, [sp, #0x40]
    e624:      	str	x20, [sp, #0x48]
    e628:      	add	x2, x0, #0x18
    e62c:      	ldr	x3, [x0, #0x10]
    e630:      	ldr	x4, [x0, #0x18]
    e634:      	ldr	x2, [x2, #0x8]
    e638:      	add	x16, sp, #0x10
    e63c:      	str	x4, [x16]
    e640:      	add	x16, sp, #0x10
    e644:      	str	x2, [x16, #0x8]
    e648:      	cmp	x1, x3
    e64c:      	b.le	0xe6c0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xb0>
    e650:      	add	x16, sp, #0x10
    e654:      	orr	x2, x16, xzr
    e658:      	ldr	x4, [x0]
    e65c:      	add	x8, sp, #0x20
    e660:      	mov	x19, x0
    e664:      	mov	x0, x2
    e668:      	mov	x2, x3
    e66c:      	mov	x3, x1
    e670:      	mov	x20, x1
    e674:      	mov	x1, x4
    e678:      	bl	0xe678 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x68>
		000000000000e678:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.cfg.Edge
    e67c:      	add	x16, sp, #0x20
    e680:      	ldr	w0, [x16]
    e684:      	lsr	x16, x0, #0
    e688:      	cmp	x16, #0x1
    e68c:      	b.eq	0xe6a8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x98>
    e690:      	b.lo	0xe698 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x88>
    e694:      	b	0xe6ac <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x9c>
    e698:      	cmp	x16, #0x0
    e69c:      	b.eq	0xe6a4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x94>
    e6a0:      	b	0xe6ac <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x9c>
    e6a4:      	b	0xe6dc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xcc>
    e6a8:      	b	0xe6b0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xa0>
    e6ac:      	b	0xe6f4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe4>
    e6b0:      	add	x16, sp, #0x20
    e6b4:      	ldr	x0, [x16, #0x8]
    e6b8:      	str	x0, [x19]
    e6bc:      	str	x20, [x19, #0x10]
    e6c0:      	movz	x0, #0x0, lsl #48
    e6c4:      	ldr	x19, [sp, #0x40]
    e6c8:      	ldr	x20, [sp, #0x48]
    e6cc:      	ldr	x29, [sp]
    e6d0:      	ldr	x30, [sp, #0x8]
    e6d4:      	add	sp, sp, #0x50
    e6d8:      	ret
    e6dc:      	lsl	x0, x20, #4
    e6e0:      	mov	x1, x0
    e6e4:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e6e4:  ARM64_RELOC_PAGE21	l_stogir.527
    e6e8:      	ldr	x0, [x0]
		000000000000e6e8:  ARM64_RELOC_PAGEOFF12	l_stogir.527
    e6ec:      	bl	0xe6ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xdc>
		000000000000e6ec:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e6f0:      	b	0xe6f0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe0>
    e6f4:      	brk	#0
    e6f8:      	b	0xe6f4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe4>

000000000000e6fc <_inherent$coil.arraylist.ArrayList$reserve!__bool>:
    e6fc:      	sub	sp, sp, #0x50
    e700:      	str	x29, [sp]
    e704:      	str	x30, [sp, #0x8]
    e708:      	mov	x29, sp
    e70c:      	str	x19, [sp, #0x40]
    e710:      	str	x20, [sp, #0x48]
    e714:      	add	x2, x0, #0x18
    e718:      	ldr	x3, [x0, #0x10]
    e71c:      	ldr	x4, [x0, #0x18]
    e720:      	ldr	x2, [x2, #0x8]
    e724:      	add	x16, sp, #0x10
    e728:      	str	x4, [x16]
    e72c:      	add	x16, sp, #0x10
    e730:      	str	x2, [x16, #0x8]
    e734:      	cmp	x1, x3
    e738:      	b.le	0xe7ac <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xb0>
    e73c:      	add	x16, sp, #0x10
    e740:      	orr	x2, x16, xzr
    e744:      	ldr	x4, [x0]
    e748:      	add	x8, sp, #0x20
    e74c:      	mov	x19, x0
    e750:      	mov	x0, x2
    e754:      	mov	x2, x3
    e758:      	mov	x3, x1
    e75c:      	mov	x20, x1
    e760:      	mov	x1, x4
    e764:      	bl	0xe764 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x68>
		000000000000e764:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__bool
    e768:      	add	x16, sp, #0x20
    e76c:      	ldr	w0, [x16]
    e770:      	lsr	x16, x0, #0
    e774:      	cmp	x16, #0x1
    e778:      	b.eq	0xe794 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x98>
    e77c:      	b.lo	0xe784 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x88>
    e780:      	b	0xe798 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x9c>
    e784:      	cmp	x16, #0x0
    e788:      	b.eq	0xe790 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x94>
    e78c:      	b	0xe798 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x9c>
    e790:      	b	0xe7c8 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xcc>
    e794:      	b	0xe79c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xa0>
    e798:      	b	0xe7e0 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe4>
    e79c:      	add	x16, sp, #0x20
    e7a0:      	ldr	x0, [x16, #0x8]
    e7a4:      	str	x0, [x19]
    e7a8:      	str	x20, [x19, #0x10]
    e7ac:      	movz	x0, #0x0, lsl #48
    e7b0:      	ldr	x19, [sp, #0x40]
    e7b4:      	ldr	x20, [sp, #0x48]
    e7b8:      	ldr	x29, [sp]
    e7bc:      	ldr	x30, [sp, #0x8]
    e7c0:      	add	sp, sp, #0x50
    e7c4:      	ret
    e7c8:      	lsr	x0, x20, #0
    e7cc:      	mov	x1, x0
    e7d0:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e7d0:  ARM64_RELOC_PAGE21	l_stogir.528
    e7d4:      	ldr	x0, [x0]
		000000000000e7d4:  ARM64_RELOC_PAGEOFF12	l_stogir.528
    e7d8:      	bl	0xe7d8 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xdc>
		000000000000e7d8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e7dc:      	b	0xe7dc <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe0>
    e7e0:      	brk	#0
    e7e4:      	b	0xe7e0 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe4>

000000000000e7e8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame>:
    e7e8:      	sub	sp, sp, #0x50
    e7ec:      	str	x29, [sp]
    e7f0:      	str	x30, [sp, #0x8]
    e7f4:      	mov	x29, sp
    e7f8:      	str	x19, [sp, #0x40]
    e7fc:      	str	x20, [sp, #0x48]
    e800:      	add	x2, x0, #0x18
    e804:      	ldr	x3, [x0, #0x10]
    e808:      	ldr	x4, [x0, #0x18]
    e80c:      	ldr	x2, [x2, #0x8]
    e810:      	add	x16, sp, #0x10
    e814:      	str	x4, [x16]
    e818:      	add	x16, sp, #0x10
    e81c:      	str	x2, [x16, #0x8]
    e820:      	cmp	x1, x3
    e824:      	b.le	0xe898 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xb0>
    e828:      	add	x16, sp, #0x10
    e82c:      	orr	x2, x16, xzr
    e830:      	ldr	x4, [x0]
    e834:      	add	x8, sp, #0x20
    e838:      	mov	x19, x0
    e83c:      	mov	x0, x2
    e840:      	mov	x2, x3
    e844:      	mov	x3, x1
    e848:      	mov	x20, x1
    e84c:      	mov	x1, x4
    e850:      	bl	0xe850 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x68>
		000000000000e850:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Frame
    e854:      	add	x16, sp, #0x20
    e858:      	ldr	w0, [x16]
    e85c:      	lsr	x16, x0, #0
    e860:      	cmp	x16, #0x1
    e864:      	b.eq	0xe880 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x98>
    e868:      	b.lo	0xe870 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x88>
    e86c:      	b	0xe884 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x9c>
    e870:      	cmp	x16, #0x0
    e874:      	b.eq	0xe87c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x94>
    e878:      	b	0xe884 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x9c>
    e87c:      	b	0xe8b4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xcc>
    e880:      	b	0xe888 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xa0>
    e884:      	b	0xe8cc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe4>
    e888:      	add	x16, sp, #0x20
    e88c:      	ldr	x0, [x16, #0x8]
    e890:      	str	x0, [x19]
    e894:      	str	x20, [x19, #0x10]
    e898:      	movz	x0, #0x0, lsl #48
    e89c:      	ldr	x19, [sp, #0x40]
    e8a0:      	ldr	x20, [sp, #0x48]
    e8a4:      	ldr	x29, [sp]
    e8a8:      	ldr	x30, [sp, #0x8]
    e8ac:      	add	sp, sp, #0x50
    e8b0:      	ret
    e8b4:      	lsl	x0, x20, #4
    e8b8:      	mov	x1, x0
    e8bc:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e8bc:  ARM64_RELOC_PAGE21	l_stogir.529
    e8c0:      	ldr	x0, [x0]
		000000000000e8c0:  ARM64_RELOC_PAGEOFF12	l_stogir.529
    e8c4:      	bl	0xe8c4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xdc>
		000000000000e8c4:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e8c8:      	b	0xe8c8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe0>
    e8cc:      	brk	#0
    e8d0:      	b	0xe8cc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe4>

000000000000e8d4 <_inherent$coil.arraylist.ArrayList$reserve!__i64>:
    e8d4:      	sub	sp, sp, #0x50
    e8d8:      	str	x29, [sp]
    e8dc:      	str	x30, [sp, #0x8]
    e8e0:      	mov	x29, sp
    e8e4:      	str	x19, [sp, #0x40]
    e8e8:      	str	x20, [sp, #0x48]
    e8ec:      	add	x2, x0, #0x18
    e8f0:      	ldr	x3, [x0, #0x10]
    e8f4:      	ldr	x4, [x0, #0x18]
    e8f8:      	ldr	x2, [x2, #0x8]
    e8fc:      	add	x16, sp, #0x10
    e900:      	str	x4, [x16]
    e904:      	add	x16, sp, #0x10
    e908:      	str	x2, [x16, #0x8]
    e90c:      	cmp	x1, x3
    e910:      	b.le	0xe984 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xb0>
    e914:      	add	x16, sp, #0x10
    e918:      	orr	x2, x16, xzr
    e91c:      	ldr	x4, [x0]
    e920:      	add	x8, sp, #0x20
    e924:      	mov	x19, x0
    e928:      	mov	x0, x2
    e92c:      	mov	x2, x3
    e930:      	mov	x3, x1
    e934:      	mov	x20, x1
    e938:      	mov	x1, x4
    e93c:      	bl	0xe93c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x68>
		000000000000e93c:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i64
    e940:      	add	x16, sp, #0x20
    e944:      	ldr	w0, [x16]
    e948:      	lsr	x16, x0, #0
    e94c:      	cmp	x16, #0x1
    e950:      	b.eq	0xe96c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x98>
    e954:      	b.lo	0xe95c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x88>
    e958:      	b	0xe970 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x9c>
    e95c:      	cmp	x16, #0x0
    e960:      	b.eq	0xe968 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
    e964:      	b	0xe970 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x9c>
    e968:      	b	0xe9a0 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xcc>
    e96c:      	b	0xe974 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xa0>
    e970:      	b	0xe9b8 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe4>
    e974:      	add	x16, sp, #0x20
    e978:      	ldr	x0, [x16, #0x8]
    e97c:      	str	x0, [x19]
    e980:      	str	x20, [x19, #0x10]
    e984:      	movz	x0, #0x0, lsl #48
    e988:      	ldr	x19, [sp, #0x40]
    e98c:      	ldr	x20, [sp, #0x48]
    e990:      	ldr	x29, [sp]
    e994:      	ldr	x30, [sp, #0x8]
    e998:      	add	sp, sp, #0x50
    e99c:      	ret
    e9a0:      	lsl	x0, x20, #3
    e9a4:      	mov	x1, x0
    e9a8:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000e9a8:  ARM64_RELOC_PAGE21	l_stogir.530
    e9ac:      	ldr	x0, [x0]
		000000000000e9ac:  ARM64_RELOC_PAGEOFF12	l_stogir.530
    e9b0:      	bl	0xe9b0 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xdc>
		000000000000e9b0:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e9b4:      	b	0xe9b4 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe0>
    e9b8:      	brk	#0
    e9bc:      	b	0xe9b8 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe4>

000000000000e9c0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range>:
    e9c0:      	sub	sp, sp, #0x50
    e9c4:      	str	x29, [sp]
    e9c8:      	str	x30, [sp, #0x8]
    e9cc:      	mov	x29, sp
    e9d0:      	str	x19, [sp, #0x40]
    e9d4:      	str	x20, [sp, #0x48]
    e9d8:      	add	x2, x0, #0x18
    e9dc:      	ldr	x3, [x0, #0x10]
    e9e0:      	ldr	x4, [x0, #0x18]
    e9e4:      	ldr	x2, [x2, #0x8]
    e9e8:      	add	x16, sp, #0x10
    e9ec:      	str	x4, [x16]
    e9f0:      	add	x16, sp, #0x10
    e9f4:      	str	x2, [x16, #0x8]
    e9f8:      	cmp	x1, x3
    e9fc:      	b.le	0xea70 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xb0>
    ea00:      	add	x16, sp, #0x10
    ea04:      	orr	x2, x16, xzr
    ea08:      	ldr	x4, [x0]
    ea0c:      	add	x8, sp, #0x20
    ea10:      	mov	x19, x0
    ea14:      	mov	x0, x2
    ea18:      	mov	x2, x3
    ea1c:      	mov	x3, x1
    ea20:      	mov	x20, x1
    ea24:      	mov	x1, x4
    ea28:      	bl	0xea28 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x68>
		000000000000ea28:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Range
    ea2c:      	add	x16, sp, #0x20
    ea30:      	ldr	w0, [x16]
    ea34:      	lsr	x16, x0, #0
    ea38:      	cmp	x16, #0x1
    ea3c:      	b.eq	0xea58 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x98>
    ea40:      	b.lo	0xea48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x88>
    ea44:      	b	0xea5c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x9c>
    ea48:      	cmp	x16, #0x0
    ea4c:      	b.eq	0xea54 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x94>
    ea50:      	b	0xea5c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x9c>
    ea54:      	b	0xea8c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xcc>
    ea58:      	b	0xea60 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xa0>
    ea5c:      	b	0xeaa4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe4>
    ea60:      	add	x16, sp, #0x20
    ea64:      	ldr	x0, [x16, #0x8]
    ea68:      	str	x0, [x19]
    ea6c:      	str	x20, [x19, #0x10]
    ea70:      	movz	x0, #0x0, lsl #48
    ea74:      	ldr	x19, [sp, #0x40]
    ea78:      	ldr	x20, [sp, #0x48]
    ea7c:      	ldr	x29, [sp]
    ea80:      	ldr	x30, [sp, #0x8]
    ea84:      	add	sp, sp, #0x50
    ea88:      	ret
    ea8c:      	lsl	x0, x20, #4
    ea90:      	mov	x1, x0
    ea94:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000ea94:  ARM64_RELOC_PAGE21	l_stogir.531
    ea98:      	ldr	x0, [x0]
		000000000000ea98:  ARM64_RELOC_PAGEOFF12	l_stogir.531
    ea9c:      	bl	0xea9c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xdc>
		000000000000ea9c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    eaa0:      	b	0xeaa0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe0>
    eaa4:      	brk	#0
    eaa8:      	b	0xeaa4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe4>

000000000000eaac <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use>:
    eaac:      	sub	sp, sp, #0x50
    eab0:      	str	x29, [sp]
    eab4:      	str	x30, [sp, #0x8]
    eab8:      	mov	x29, sp
    eabc:      	str	x19, [sp, #0x40]
    eac0:      	str	x20, [sp, #0x48]
    eac4:      	add	x2, x0, #0x18
    eac8:      	ldr	x3, [x0, #0x10]
    eacc:      	ldr	x4, [x0, #0x18]
    ead0:      	ldr	x2, [x2, #0x8]
    ead4:      	add	x16, sp, #0x10
    ead8:      	str	x4, [x16]
    eadc:      	add	x16, sp, #0x10
    eae0:      	str	x2, [x16, #0x8]
    eae4:      	cmp	x1, x3
    eae8:      	b.le	0xeb5c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xb0>
    eaec:      	add	x16, sp, #0x10
    eaf0:      	orr	x2, x16, xzr
    eaf4:      	ldr	x4, [x0]
    eaf8:      	add	x8, sp, #0x20
    eafc:      	mov	x19, x0
    eb00:      	mov	x0, x2
    eb04:      	mov	x2, x3
    eb08:      	mov	x3, x1
    eb0c:      	mov	x20, x1
    eb10:      	mov	x1, x4
    eb14:      	bl	0xeb14 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x68>
		000000000000eb14:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Use
    eb18:      	add	x16, sp, #0x20
    eb1c:      	ldr	w0, [x16]
    eb20:      	lsr	x16, x0, #0
    eb24:      	cmp	x16, #0x1
    eb28:      	b.eq	0xeb44 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x98>
    eb2c:      	b.lo	0xeb34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x88>
    eb30:      	b	0xeb48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x9c>
    eb34:      	cmp	x16, #0x0
    eb38:      	b.eq	0xeb40 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x94>
    eb3c:      	b	0xeb48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x9c>
    eb40:      	b	0xeb78 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xcc>
    eb44:      	b	0xeb4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xa0>
    eb48:      	b	0xeb90 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe4>
    eb4c:      	add	x16, sp, #0x20
    eb50:      	ldr	x0, [x16, #0x8]
    eb54:      	str	x0, [x19]
    eb58:      	str	x20, [x19, #0x10]
    eb5c:      	movz	x0, #0x0, lsl #48
    eb60:      	ldr	x19, [sp, #0x40]
    eb64:      	ldr	x20, [sp, #0x48]
    eb68:      	ldr	x29, [sp]
    eb6c:      	ldr	x30, [sp, #0x8]
    eb70:      	add	sp, sp, #0x50
    eb74:      	ret
    eb78:      	lsl	x0, x20, #3
    eb7c:      	mov	x1, x0
    eb80:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000eb80:  ARM64_RELOC_PAGE21	l_stogir.532
    eb84:      	ldr	x0, [x0]
		000000000000eb84:  ARM64_RELOC_PAGEOFF12	l_stogir.532
    eb88:      	bl	0xeb88 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xdc>
		000000000000eb88:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    eb8c:      	b	0xeb8c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe0>
    eb90:      	brk	#0
    eb94:      	b	0xeb90 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe4>

000000000000eb98 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range>:
    eb98:      	sub	sp, sp, #0x50
    eb9c:      	str	x29, [sp]
    eba0:      	str	x30, [sp, #0x8]
    eba4:      	mov	x29, sp
    eba8:      	str	x19, [sp, #0x40]
    ebac:      	str	x20, [sp, #0x48]
    ebb0:      	add	x2, x0, #0x18
    ebb4:      	ldr	x3, [x0, #0x10]
    ebb8:      	ldr	x4, [x0, #0x18]
    ebbc:      	ldr	x2, [x2, #0x8]
    ebc0:      	add	x16, sp, #0x10
    ebc4:      	str	x4, [x16]
    ebc8:      	add	x16, sp, #0x10
    ebcc:      	str	x2, [x16, #0x8]
    ebd0:      	cmp	x1, x3
    ebd4:      	b.le	0xec48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xb0>
    ebd8:      	add	x16, sp, #0x10
    ebdc:      	orr	x2, x16, xzr
    ebe0:      	ldr	x4, [x0]
    ebe4:      	add	x8, sp, #0x20
    ebe8:      	mov	x19, x0
    ebec:      	mov	x0, x2
    ebf0:      	mov	x2, x3
    ebf4:      	mov	x3, x1
    ebf8:      	mov	x20, x1
    ebfc:      	mov	x1, x4
    ec00:      	bl	0xec00 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x68>
		000000000000ec00:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.schedule.Range
    ec04:      	add	x16, sp, #0x20
    ec08:      	ldr	w0, [x16]
    ec0c:      	lsr	x16, x0, #0
    ec10:      	cmp	x16, #0x1
    ec14:      	b.eq	0xec30 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x98>
    ec18:      	b.lo	0xec20 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x88>
    ec1c:      	b	0xec34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x9c>
    ec20:      	cmp	x16, #0x0
    ec24:      	b.eq	0xec2c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x94>
    ec28:      	b	0xec34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x9c>
    ec2c:      	b	0xec64 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xcc>
    ec30:      	b	0xec38 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xa0>
    ec34:      	b	0xec7c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe4>
    ec38:      	add	x16, sp, #0x20
    ec3c:      	ldr	x0, [x16, #0x8]
    ec40:      	str	x0, [x19]
    ec44:      	str	x20, [x19, #0x10]
    ec48:      	movz	x0, #0x0, lsl #48
    ec4c:      	ldr	x19, [sp, #0x40]
    ec50:      	ldr	x20, [sp, #0x48]
    ec54:      	ldr	x29, [sp]
    ec58:      	ldr	x30, [sp, #0x8]
    ec5c:      	add	sp, sp, #0x50
    ec60:      	ret
    ec64:      	lsl	x0, x20, #4
    ec68:      	mov	x1, x0
    ec6c:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000ec6c:  ARM64_RELOC_PAGE21	l_stogir.533
    ec70:      	ldr	x0, [x0]
		000000000000ec70:  ARM64_RELOC_PAGEOFF12	l_stogir.533
    ec74:      	bl	0xec74 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xdc>
		000000000000ec74:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    ec78:      	b	0xec78 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe0>
    ec7c:      	brk	#0
    ec80:      	b	0xec7c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe4>

000000000000ec84 <_stogir.checked.validate>:
    ec84:      	sub	sp, sp, #0x20
    ec88:      	str	x29, [sp]
    ec8c:      	str	x30, [sp, #0x8]
    ec90:      	mov	x29, sp
    ec94:      	str	x19, [sp, #0x10]
    ec98:      	sxtw	x1, w1
    ec9c:      	lsl	x2, x1, #2
    eca0:      	cmp	x1, #0x0
    eca4:      	cset	w3, gt
    eca8:      	movz	x16, #0x0, lsl #48
    ecac:      	sub	x4, x16, x1
    ecb0:      	sub	x5, x4, #0x1
    ecb4:      	uxtb	w16, w3
    ecb8:      	cmp	w16, wzr
    ecbc:      	b.eq	0xecfc <_stogir.checked.validate+0x78>
    ecc0:      	ldr	x4, [x0, #0x8]
    ecc4:      	cmp	x1, x4
    ecc8:      	b.ge	0xed4c <_stogir.checked.validate+0xc8>
    eccc:      	add	x4, x0, #0x78
    ecd0:      	ldr	x4, [x4, #0x8]
    ecd4:      	cmp	x1, x4
    ecd8:      	b.ge	0xee98 <_stogir.checked.validate+0x214>
    ecdc:      	ldr	x4, [x0, #0x78]
    ece0:      	add	x4, x2, x4
    ece4:      	ldr	w4, [x4]
    ece8:      	sxtw	x4, w4
    ecec:      	cmp	x4, #0x0
    ecf0:      	cset	w4, ge
    ecf4:      	ubfx	x4, x4, #0, #8
    ecf8:      	b	0xee9c <_stogir.checked.validate+0x218>
    ecfc:      	cmp	x1, #0x0
    ed00:      	b.ge	0xed54 <_stogir.checked.validate+0xd0>
    ed04:      	add	x6, x0, #0x28
    ed08:      	add	x7, x0, #0x50
    ed0c:      	ldr	x6, [x6, #0x8]
    ed10:      	ldr	x7, [x7, #0x8]
    ed14:      	cmp	x6, x7
    ed18:      	b.ne	0xed44 <_stogir.checked.validate+0xc0>
    ed1c:      	cmp	x4, x6
    ed20:      	b.gt	0xeea0 <_stogir.checked.validate+0x21c>
    ed24:      	ldr	x4, [x0, #0x50]
    ed28:      	add	x4, x4, x5, lsl #2
    ed2c:      	ldr	w4, [x4]
    ed30:      	sxtw	x4, w4
    ed34:      	cmp	x4, #0x0
    ed38:      	cset	w4, gt
    ed3c:      	ubfx	x4, x4, #0, #8
    ed40:      	b	0xeea4 <_stogir.checked.validate+0x220>
    ed44:      	movz	x4, #0x0, lsl #48
    ed48:      	b	0xed58 <_stogir.checked.validate+0xd4>
    ed4c:      	movz	x4, #0x0, lsl #48
    ed50:      	b	0xed58 <_stogir.checked.validate+0xd4>
    ed54:      	movz	x4, #0x0, lsl #48
    ed58:      	cmp	x4, #0x0
    ed5c:      	b.eq	0xed98 <_stogir.checked.validate+0x114>
    ed60:      	uxtb	w16, w3
    ed64:      	cmp	w16, wzr
    ed68:      	b.eq	0xed80 <_stogir.checked.validate+0xfc>
    ed6c:      	ldr	x3, [x0]
    ed70:      	add	x3, x3, x1, lsl #4
    ed74:      	ldr	x4, [x3]
    ed78:      	ldr	x3, [x3, #0x8]
    ed7c:      	b	0xed90 <_stogir.checked.validate+0x10c>
    ed80:      	ldr	x3, [x0, #0x28]
    ed84:      	add	x3, x3, x5, lsl #4
    ed88:      	ldr	x4, [x3]
    ed8c:      	ldr	x3, [x3, #0x8]
    ed90:      	mov	w5, #0x1                ; =1
    ed94:      	b	0xeda4 <_stogir.checked.validate+0x120>
    ed98:      	movz	w5, #0x0, lsl #16
    ed9c:      	movz	x4, #0x0, lsl #48
    eda0:      	movz	x3, #0x0, lsl #48
    eda4:      	ubfx	x5, x5, #0, #32
    eda8:      	lsr	x16, x5, #0
    edac:      	cmp	x16, #0x1
    edb0:      	b.eq	0xedcc <_stogir.checked.validate+0x148>
    edb4:      	b.lo	0xedbc <_stogir.checked.validate+0x138>
    edb8:      	b	0xedd0 <_stogir.checked.validate+0x14c>
    edbc:      	cmp	x16, #0x0
    edc0:      	b.eq	0xedc8 <_stogir.checked.validate+0x144>
    edc4:      	b	0xedd0 <_stogir.checked.validate+0x14c>
    edc8:      	b	0xedd4 <_stogir.checked.validate+0x150>
    edcc:      	b	0xee1c <_stogir.checked.validate+0x198>
    edd0:      	b	0xf0b8 <_stogir.checked.validate+0x434>
    edd4:      	mov	x0, #0x1                ; =1
    edd8:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000edd8:  ARM64_RELOC_PAGE21	l_stogir.534
    eddc:      	ldr	x7, [x7]
		000000000000eddc:  ARM64_RELOC_PAGEOFF12	l_stogir.534
    ede0:      	mov	x9, #0x1a               ; =26
    ede4:      	b	0xedf8 <_stogir.checked.validate+0x174>
    ede8:      	mov	x0, #0x1                ; =1
    edec:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000edec:  ARM64_RELOC_PAGE21	l_stogir.535
    edf0:      	ldr	x7, [x7]
		000000000000edf0:  ARM64_RELOC_PAGEOFF12	l_stogir.535
    edf4:      	mov	x9, #0x26               ; =38
    edf8:      	str	x0, [x8]
    edfc:      	str	x7, [x8, #0x8]
    ee00:      	str	x9, [x8, #0x10]
    ee04:      	sub	sp, x29, #0x0
    ee08:      	ldr	x19, [sp, #0x10]
    ee0c:      	ldr	x29, [sp]
    ee10:      	ldr	x30, [sp, #0x8]
    ee14:      	add	sp, sp, #0x20
    ee18:      	ret
    ee1c:      	cmp	x1, #0x0
    ee20:      	b.le	0xede8 <_stogir.checked.validate+0x164>
    ee24:      	uxtb	w1, w4
    ee28:      	cmp	x1, #0x29
    ee2c:      	b.lt	0xede8 <_stogir.checked.validate+0x164>
    ee30:      	cmp	x1, #0x2b
    ee34:      	b.gt	0xede8 <_stogir.checked.validate+0x164>
    ee38:      	ldr	x1, [x0, #0x78]
    ee3c:      	add	x1, x2, x1
    ee40:      	ldr	w1, [x1]
    ee44:      	sxtw	x1, w1
    ee48:      	cmp	x1, #0x2
    ee4c:      	b.ne	0xede8 <_stogir.checked.validate+0x164>
    ee50:      	orr	w1, w4, wzr
    ee54:      	mov	x2, sp
    ee58:      	ubfx	x1, x1, #0, #32
    ee5c:      	sub	sp, sp, #0x10
    ee60:      	mov	x5, sp
    ee64:      	sub	sp, sp, #0x10
    ee68:      	mov	x6, sp
    ee6c:      	ubfx	x1, x1, #8, #8
    ee70:      	cmp	x1, #0x1
    ee74:      	b.lt	0xf070 <_stogir.checked.validate+0x3ec>
    ee78:      	cmp	x1, #0xb
    ee7c:      	b.gt	0xf070 <_stogir.checked.validate+0x3ec>
    ee80:      	cmp	x1, #0x1
    ee84:      	b.eq	0xf070 <_stogir.checked.validate+0x3ec>
    ee88:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000ee88:  ARM64_RELOC_PAGE21	l_stogir.536
    ee8c:      	ldr	x7, [x7]
		000000000000ee8c:  ARM64_RELOC_PAGEOFF12	l_stogir.536
    ee90:      	movz	x9, #0x0, lsl #48
    ee94:      	b	0xf07c <_stogir.checked.validate+0x3f8>
    ee98:      	movz	x4, #0x0, lsl #48
    ee9c:      	b	0xed50 <_stogir.checked.validate+0xcc>
    eea0:      	movz	x4, #0x0, lsl #48
    eea4:      	b	0xed48 <_stogir.checked.validate+0xc4>
    eea8:      	mov	x0, #0x1                ; =1
    eeac:      	mov	sp, x2
    eeb0:      	b	0xedf8 <_stogir.checked.validate+0x174>
    eeb4:      	movz	w5, #0x0, lsl #16
    eeb8:      	movz	x4, #0x0, lsl #48
    eebc:      	ubfx	x5, x5, #0, #32
    eec0:      	lsr	x16, x5, #0
    eec4:      	cmp	x16, #0x1
    eec8:      	b.eq	0xeee4 <_stogir.checked.validate+0x260>
    eecc:      	b.lo	0xeed4 <_stogir.checked.validate+0x250>
    eed0:      	b	0xeee8 <_stogir.checked.validate+0x264>
    eed4:      	cmp	x16, #0x0
    eed8:      	b.eq	0xeee0 <_stogir.checked.validate+0x25c>
    eedc:      	b	0xeee8 <_stogir.checked.validate+0x264>
    eee0:      	b	0xeeec <_stogir.checked.validate+0x268>
    eee4:      	b	0xf050 <_stogir.checked.validate+0x3cc>
    eee8:      	b	0xf0d0 <_stogir.checked.validate+0x44c>
    eeec:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0xc4>
		000000000000eeec:  ARM64_RELOC_PAGE21	l_stogir.537
    eef0:      	ldr	x7, [x7]
		000000000000eef0:  ARM64_RELOC_PAGEOFF12	l_stogir.537
    eef4:      	mov	x9, #0x22               ; =34
    eef8:      	cmp	x3, #0x2
    eefc:      	b.ge	0xef20 <_stogir.checked.validate+0x29c>
    ef00:      	add	x4, x3, #0x1
    ef04:      	add	x3, x10, x3, lsl #2
    ef08:      	ldr	w3, [x3]
    ef0c:      	movn	w17, #0x0, lsl #16
    ef10:      	and	w5, w3, w17
    ef14:      	mov	x3, x4
    ef18:      	mov	w4, #0x1                ; =1
    ef1c:      	b	0xef28 <_stogir.checked.validate+0x2a4>
    ef20:      	movz	w4, #0x0, lsl #16
    ef24:      	movz	w5, #0x0, lsl #16
    ef28:      	ubfx	x4, x4, #0, #32
    ef2c:      	lsr	x16, x4, #0
    ef30:      	cmp	x16, #0x1
    ef34:      	b.eq	0xef50 <_stogir.checked.validate+0x2cc>
    ef38:      	b.lo	0xef40 <_stogir.checked.validate+0x2bc>
    ef3c:      	b	0xef54 <_stogir.checked.validate+0x2d0>
    ef40:      	cmp	x16, #0x0
    ef44:      	b.eq	0xef4c <_stogir.checked.validate+0x2c8>
    ef48:      	b	0xef54 <_stogir.checked.validate+0x2d0>
    ef4c:      	b	0xefb4 <_stogir.checked.validate+0x330>
    ef50:      	b	0xef58 <_stogir.checked.validate+0x2d4>
    ef54:      	b	0xf0c8 <_stogir.checked.validate+0x444>
    ef58:      	sxtw	x5, w5
    ef5c:      	cmp	x5, #0x0
    ef60:      	cset	w4, gt
    ef64:      	movz	x16, #0x0, lsl #48
    ef68:      	sub	x6, x16, x5
    ef6c:      	sub	x14, x6, #0x1
    ef70:      	uxtb	w16, w4
    ef74:      	cmp	w16, wzr
    ef78:      	b.eq	0xf010 <_stogir.checked.validate+0x38c>
    ef7c:      	ldr	x6, [x0, #0x8]
    ef80:      	cmp	x5, x6
    ef84:      	b.ge	0xf008 <_stogir.checked.validate+0x384>
    ef88:      	ldr	x6, [x11, #0x8]
    ef8c:      	cmp	x5, x6
    ef90:      	b.ge	0xf0b0 <_stogir.checked.validate+0x42c>
    ef94:      	ldr	x6, [x0, #0x78]
    ef98:      	add	x6, x6, x5, lsl #2
    ef9c:      	ldr	w6, [x6]
    efa0:      	sxtw	x6, w6
    efa4:      	cmp	x6, #0x0
    efa8:      	cset	w6, ge
    efac:      	ubfx	x6, x6, #0, #8
    efb0:      	b	0xf0b4 <_stogir.checked.validate+0x430>
    efb4:      	cmp	x9, #0x0
    efb8:      	b.ne	0xeea8 <_stogir.checked.validate+0x224>
    efbc:      	and	x7, x1, #0xffffffff
    efc0:      	movz	x0, #0x0, lsl #48
    efc4:      	movz	x9, #0x0, lsl #48
    efc8:      	b	0xeeac <_stogir.checked.validate+0x228>
    efcc:      	ldr	x4, [x0, #0x28]
    efd0:      	add	x4, x4, x14, lsl #4
    efd4:      	ldr	x4, [x4]
    efd8:      	mov	w5, #0x1                ; =1
    efdc:      	b	0xeebc <_stogir.checked.validate+0x238>
    efe0:      	movz	x6, #0x0, lsl #48
    efe4:      	cmp	x6, #0x0
    efe8:      	b.eq	0xeeb4 <_stogir.checked.validate+0x230>
    efec:      	uxtb	w16, w4
    eff0:      	cmp	w16, wzr
    eff4:      	b.eq	0xefcc <_stogir.checked.validate+0x348>
    eff8:      	ldr	x4, [x0]
    effc:      	add	x4, x4, x5, lsl #4
    f000:      	ldr	x4, [x4]
    f004:      	b	0xefd8 <_stogir.checked.validate+0x354>
    f008:      	movz	x6, #0x0, lsl #48
    f00c:      	b	0xefe4 <_stogir.checked.validate+0x360>
    f010:      	cmp	x5, #0x0
    f014:      	b.ge	0xefe0 <_stogir.checked.validate+0x35c>
    f018:      	ldr	x15, [x12, #0x8]
    f01c:      	ldr	x19, [x13, #0x8]
    f020:      	cmp	x15, x19
    f024:      	b.ne	0xf0a8 <_stogir.checked.validate+0x424>
    f028:      	cmp	x6, x15
    f02c:      	b.gt	0xf0c0 <_stogir.checked.validate+0x43c>
    f030:      	ldr	x6, [x0, #0x50]
    f034:      	add	x6, x6, x14, lsl #2
    f038:      	ldr	w6, [x6]
    f03c:      	sxtw	x6, w6
    f040:      	cmp	x6, #0x0
    f044:      	cset	w6, gt
    f048:      	ubfx	x6, x6, #0, #8
    f04c:      	b	0xf0c4 <_stogir.checked.validate+0x440>
    f050:      	ubfx	x4, x4, #0, #32
    f054:      	ubfx	x4, x4, #8, #8
    f058:      	cmp	x4, x1
    f05c:      	b.eq	0xf06c <_stogir.checked.validate+0x3e8>
    f060:      	adrp	x7, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f060:  ARM64_RELOC_PAGE21	l_stogir.538
    f064:      	ldr	x7, [x7]
		000000000000f064:  ARM64_RELOC_PAGEOFF12	l_stogir.538
    f068:      	mov	x9, #0x28               ; =40
    f06c:      	b	0xeef8 <_stogir.checked.validate+0x274>
    f070:      	adrp	x7, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f070:  ARM64_RELOC_PAGE21	l_stogir.539
    f074:      	ldr	x7, [x7]
		000000000000f074:  ARM64_RELOC_PAGEOFF12	l_stogir.539
    f078:      	mov	x9, #0x36               ; =54
    f07c:      	orr	x10, x6, xzr
    f080:      	add	x11, x0, #0x78
    f084:      	add	x12, x0, #0x28
    f088:      	add	x13, x0, #0x50
    f08c:      	lsr	x4, x4, #32
    f090:      	str	w4, [x5]
    f094:      	str	w3, [x5, #0x4]
    f098:      	ldr	x3, [x5]
    f09c:      	str	x3, [x6]
    f0a0:      	movz	x3, #0x0, lsl #48
    f0a4:      	b	0xeef8 <_stogir.checked.validate+0x274>
    f0a8:      	movz	x6, #0x0, lsl #48
    f0ac:      	b	0xefe4 <_stogir.checked.validate+0x360>
    f0b0:      	movz	x6, #0x0, lsl #48
    f0b4:      	b	0xf00c <_stogir.checked.validate+0x388>
    f0b8:      	brk	#0
    f0bc:      	b	0xf0b8 <_stogir.checked.validate+0x434>
    f0c0:      	movz	x6, #0x0, lsl #48
    f0c4:      	b	0xf0ac <_stogir.checked.validate+0x428>
    f0c8:      	brk	#0
    f0cc:      	b	0xf0c8 <_stogir.checked.validate+0x444>
    f0d0:      	brk	#0
    f0d4:      	b	0xf0d0 <_stogir.checked.validate+0x44c>

000000000000f0d8 <_coil.alloc.sized-request>:
    f0d8:      	cmp	x3, #0x0
    f0dc:      	b.le	0xf104 <_coil.alloc.sized-request+0x2c>
    f0e0:      	cmp	x1, #0x0
    f0e4:      	b.le	0xf104 <_coil.alloc.sized-request+0x2c>
    f0e8:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    f0ec:      	sdiv	x4, x16, x1
    f0f0:      	cmp	x3, x4
    f0f4:      	b.gt	0xf104 <_coil.alloc.sized-request+0x2c>
    f0f8:      	mul	x1, x3, x1
    f0fc:      	mov	x4, #0x1                ; =1
    f100:      	b	0xf118 <_coil.alloc.sized-request+0x40>
    f104:      	movz	x4, #0x0, lsl #48
    f108:      	movz	x0, #0x0, lsl #48
    f10c:      	movz	x3, #0x0, lsl #48
    f110:      	movz	x1, #0x0, lsl #48
    f114:      	movz	x2, #0x0, lsl #48
    f118:      	str	x4, [x8]
    f11c:      	str	x0, [x8, #0x8]
    f120:      	str	x3, [x8, #0x10]
    f124:      	str	x1, [x8, #0x18]
    f128:      	str	x2, [x8, #0x20]
    f12c:      	ret

000000000000f130 <_coil.alloc.raw-free>:
    f130:      	sub	sp, sp, #0x10
    f134:      	str	x29, [sp]
    f138:      	str	x30, [sp, #0x8]
    f13c:      	mov	x29, sp
    f140:      	ldr	x3, [x2, #0x8]
    f144:      	cmp	x3, #0x0
    f148:      	b.le	0xf190 <_coil.alloc.raw-free+0x60>
    f14c:      	ldr	x3, [x2, #0x10]
    f150:      	cmp	x3, #0x0
    f154:      	b.le	0xf190 <_coil.alloc.raw-free+0x60>
    f158:      	ldr	x3, [x2, #0x18]
    f15c:      	cmp	x3, #0x0
    f160:      	b.le	0xf190 <_coil.alloc.raw-free+0x60>
    f164:      	sub	x4, x3, #0x1
    f168:      	and	x3, x4, x3
    f16c:      	cmp	x3, #0x0
    f170:      	b.ne	0xf190 <_coil.alloc.raw-free+0x60>
    f174:      	ldr	x3, [x0]
    f178:      	ldr	x0, [x0, #0x8]
    f17c:      	ldr	x0, [x0, #0x18]
    f180:      	mov	x30, x0
    f184:      	mov	x0, x3
    f188:      	blr	x30
    f18c:      	b	0xf194 <_coil.alloc.raw-free+0x64>
    f190:      	movz	x0, #0x0, lsl #48
    f194:      	ldr	x29, [sp]
    f198:      	ldr	x30, [sp, #0x8]
    f19c:      	add	sp, sp, #0x10
    f1a0:      	ret

000000000000f1a4 <_coil.alloc.reallocate__i32>:
    f1a4:      	sub	sp, sp, #0x40
    f1a8:      	str	x29, [sp, #0x10]
    f1ac:      	str	x30, [sp, #0x18]
    f1b0:      	add	x29, sp, #0x10
    f1b4:      	str	x19, [sp, #0x30]
    f1b8:      	str	x20, [sp, #0x38]
    f1bc:      	mov	x19, x8
    f1c0:      	mov	x20, x3
    f1c4:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f1c4:  ARM64_RELOC_PAGE21	l_stogir.540
    f1c8:      	ldr	x4, [x4]
		000000000000f1c8:  ARM64_RELOC_PAGEOFF12	l_stogir.540
    f1cc:      	mov	x5, #0x4                ; =4
    f1d0:      	mov	x6, #0x4                ; =4
    f1d4:      	bl	0xf1d4 <_coil.alloc.reallocate__i32+0x30>
		000000000000f1d4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f1d8:      	ubfx	x0, x0, #0, #32
    f1dc:      	lsr	x16, x0, #0
    f1e0:      	cmp	x16, #0x1
    f1e4:      	b.eq	0xf200 <_coil.alloc.reallocate__i32+0x5c>
    f1e8:      	b.lo	0xf1f0 <_coil.alloc.reallocate__i32+0x4c>
    f1ec:      	b	0xf204 <_coil.alloc.reallocate__i32+0x60>
    f1f0:      	cmp	x16, #0x0
    f1f4:      	b.eq	0xf1fc <_coil.alloc.reallocate__i32+0x58>
    f1f8:      	b	0xf204 <_coil.alloc.reallocate__i32+0x60>
    f1fc:      	b	0xf208 <_coil.alloc.reallocate__i32+0x64>
    f200:      	b	0xf218 <_coil.alloc.reallocate__i32+0x74>
    f204:      	b	0xf240 <_coil.alloc.reallocate__i32+0x9c>
    f208:      	movz	x0, #0x0, lsl #48
    f20c:      	movz	x1, #0x0, lsl #48
    f210:      	movz	x20, #0x0, lsl #48
    f214:      	b	0xf21c <_coil.alloc.reallocate__i32+0x78>
    f218:      	mov	x0, #0x1                ; =1
    f21c:      	str	x0, [x19]
    f220:      	str	x1, [x19, #0x8]
    f224:      	str	x20, [x19, #0x10]
    f228:      	ldr	x19, [sp, #0x30]
    f22c:      	ldr	x20, [sp, #0x38]
    f230:      	ldr	x29, [sp, #0x10]
    f234:      	ldr	x30, [sp, #0x18]
    f238:      	add	sp, sp, #0x40
    f23c:      	ret
    f240:      	brk	#0
    f244:      	b	0xf240 <_coil.alloc.reallocate__i32+0x9c>

000000000000f248 <_coil.alloc.oom-at>:
    f248:      	sub	sp, sp, #0x20
    f24c:      	str	x29, [sp]
    f250:      	str	x30, [sp, #0x8]
    f254:      	mov	x29, sp
    f258:      	str	x19, [sp, #0x10]
    f25c:      	str	x20, [sp, #0x18]
    f260:      	movz	x2, #0x0, lsl #48
    f264:      	b	0xf26c <_coil.alloc.oom-at+0x24>
    f268:      	add	x2, x2, #0x1
    f26c:      	adrp	x17, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f26c:  ARM64_RELOC_PAGE21	l_stogir.541
    f270:      	ldr	x17, [x17]
		000000000000f270:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    f274:      	add	x3, x2, x17
    f278:      	ldrsb	w3, [x3]
    f27c:      	sxtb	x3, w3
    f280:      	cmp	x3, #0x0
    f284:      	b.ne	0xf268 <_coil.alloc.oom-at+0x20>
    f288:      	mov	x19, x0
    f28c:      	mov	x20, x1
    f290:      	mov	x0, #0x2                ; =2
    f294:      	adrp	x1, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f294:  ARM64_RELOC_PAGE21	l_stogir.541
    f298:      	ldr	x1, [x1]
		000000000000f298:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    f29c:      	bl	0xf29c <_coil.alloc.oom-at+0x54>
		000000000000f29c:  ARM64_RELOC_BRANCH26	_write
    f2a0:      	movz	x0, #0x0, lsl #48
    f2a4:      	b	0xf2ac <_coil.alloc.oom-at+0x64>
    f2a8:      	add	x0, x0, #0x1
    f2ac:      	add	x1, x0, x19
    f2b0:      	ldrsb	w1, [x1]
    f2b4:      	sxtb	x1, w1
    f2b8:      	cmp	x1, #0x0
    f2bc:      	b.ne	0xf2a8 <_coil.alloc.oom-at+0x60>
    f2c0:      	mov	x1, x19
    f2c4:      	mov	x2, x0
    f2c8:      	mov	x0, #0x2                ; =2
    f2cc:      	bl	0xf2cc <_coil.alloc.oom-at+0x84>
		000000000000f2cc:  ARM64_RELOC_BRANCH26	_write
    f2d0:      	movz	x0, #0x0, lsl #48
    f2d4:      	b	0xf2dc <_coil.alloc.oom-at+0x94>
    f2d8:      	add	x0, x0, #0x1
    f2dc:      	adrp	x17, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f2dc:  ARM64_RELOC_PAGE21	l_stogir.542
    f2e0:      	ldr	x17, [x17]
		000000000000f2e0:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    f2e4:      	add	x1, x0, x17
    f2e8:      	ldrsb	w1, [x1]
    f2ec:      	sxtb	x1, w1
    f2f0:      	cmp	x1, #0x0
    f2f4:      	b.ne	0xf2d8 <_coil.alloc.oom-at+0x90>
    f2f8:      	mov	x2, x0
    f2fc:      	mov	x0, #0x2                ; =2
    f300:      	adrp	x1, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f300:  ARM64_RELOC_PAGE21	l_stogir.542
    f304:      	ldr	x1, [x1]
		000000000000f304:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    f308:      	bl	0xf308 <_coil.alloc.oom-at+0xc0>
		000000000000f308:  ARM64_RELOC_BRANCH26	_write
    f30c:      	cmp	x20, #0x0
    f310:      	b.lt	0xf3fc <_coil.alloc.oom-at+0x1b4>
    f314:      	movz	x0, #0x0, lsl #48
    f318:      	b	0xf324 <_coil.alloc.oom-at+0xdc>
    f31c:      	nop
    f320:      	add	x0, x0, #0x1
    f324:      	adrp	x17, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f324:  ARM64_RELOC_PAGE21	l_stogir.543
    f328:      	ldr	x17, [x17]
		000000000000f328:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    f32c:      	add	x1, x0, x17
    f330:      	ldrsb	w1, [x1]
    f334:      	sxtb	x1, w1
    f338:      	cmp	x1, #0x0
    f33c:      	b.ne	0xf320 <_coil.alloc.oom-at+0xd8>
    f340:      	mov	x2, x0
    f344:      	mov	x0, #0x2                ; =2
    f348:      	adrp	x1, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f348:  ARM64_RELOC_PAGE21	l_stogir.543
    f34c:      	ldr	x1, [x1]
		000000000000f34c:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    f350:      	bl	0xf350 <_coil.alloc.oom-at+0x108>
		000000000000f350:  ARM64_RELOC_BRANCH26	_write
    f354:      	mov	x0, #0x18               ; =24
    f358:      	sub	x0, x0, #0x1
    f35c:      	adrp	x17, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f35c:  ARM64_RELOC_PAGE21	l_stogir.544
    f360:      	ldr	x17, [x17]
		000000000000f360:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    f364:      	add	x1, x0, x17
    f368:      	mov	x17, #0xa               ; =10
    f36c:      	sdiv	x16, x20, x17
    f370:      	msub	x2, x16, x17, x20
    f374:      	mov	x17, #0xa               ; =10
    f378:      	sdiv	x3, x20, x17
    f37c:      	orr	x20, x3, xzr
    f380:      	add	x2, x2, #0x30
    f384:      	uxtb	w2, w2
    f388:      	uxtb	w2, w2
    f38c:      	strb	w2, [x1]
    f390:      	cmp	x20, #0x0
    f394:      	b.ne	0xf358 <_coil.alloc.oom-at+0x110>
    f398:      	mov	x16, #0x18              ; =24
    f39c:      	sub	x1, x16, x0
    f3a0:      	adrp	x16, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f3a0:  ARM64_RELOC_PAGE21	l_stogir.544
    f3a4:      	ldr	x16, [x16]
		000000000000f3a4:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    f3a8:      	add	x0, x16, x0
    f3ac:      	mov	x2, x1
    f3b0:      	mov	x1, x0
    f3b4:      	mov	x0, #0x2                ; =2
    f3b8:      	bl	0xf3b8 <_coil.alloc.oom-at+0x170>
		000000000000f3b8:  ARM64_RELOC_BRANCH26	_write
    f3bc:      	movz	x0, #0x0, lsl #48
    f3c0:      	b	0xf3cc <_coil.alloc.oom-at+0x184>
    f3c4:      	nop
    f3c8:      	add	x0, x0, #0x1
    f3cc:      	adrp	x17, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f3cc:  ARM64_RELOC_PAGE21	l_stogir.545
    f3d0:      	ldr	x17, [x17]
		000000000000f3d0:  ARM64_RELOC_PAGEOFF12	l_stogir.545
    f3d4:      	add	x1, x0, x17
    f3d8:      	ldrsb	w1, [x1]
    f3dc:      	sxtb	x1, w1
    f3e0:      	cmp	x1, #0x0
    f3e4:      	b.ne	0xf3c8 <_coil.alloc.oom-at+0x180>
    f3e8:      	mov	x2, x0
    f3ec:      	mov	x0, #0x2                ; =2
    f3f0:      	adrp	x1, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f3f0:  ARM64_RELOC_PAGE21	l_stogir.545
    f3f4:      	ldr	x1, [x1]
		000000000000f3f4:  ARM64_RELOC_PAGEOFF12	l_stogir.545
    f3f8:      	bl	0xf3f8 <_coil.alloc.oom-at+0x1b0>
		000000000000f3f8:  ARM64_RELOC_BRANCH26	_write
    f3fc:      	movz	x0, #0x0, lsl #48
    f400:      	b	0xf40c <_coil.alloc.oom-at+0x1c4>
    f404:      	nop
    f408:      	add	x0, x0, #0x1
    f40c:      	adrp	x17, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f40c:  ARM64_RELOC_PAGE21	l_stogir.546
    f410:      	ldr	x17, [x17]
		000000000000f410:  ARM64_RELOC_PAGEOFF12	l_stogir.546
    f414:      	add	x1, x0, x17
    f418:      	ldrsb	w1, [x1]
    f41c:      	sxtb	x1, w1
    f420:      	cmp	x1, #0x0
    f424:      	b.ne	0xf408 <_coil.alloc.oom-at+0x1c0>
    f428:      	mov	x2, x0
    f42c:      	mov	x0, #0x2                ; =2
    f430:      	adrp	x1, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f430:  ARM64_RELOC_PAGE21	l_stogir.546
    f434:      	ldr	x1, [x1]
		000000000000f434:  ARM64_RELOC_PAGEOFF12	l_stogir.546
    f438:      	bl	0xf438 <_coil.alloc.oom-at+0x1f0>
		000000000000f438:  ARM64_RELOC_BRANCH26	_write
    f43c:      	bl	0xf43c <_coil.alloc.oom-at+0x1f4>
		000000000000f43c:  ARM64_RELOC_BRANCH26	_abort
    f440:      	b	0xf440 <_coil.alloc.oom-at+0x1f8>

000000000000f444 <_coil.alloc.reallocate__stogir.cfg.Edge>:
    f444:      	sub	sp, sp, #0x40
    f448:      	str	x29, [sp, #0x10]
    f44c:      	str	x30, [sp, #0x18]
    f450:      	add	x29, sp, #0x10
    f454:      	str	x19, [sp, #0x30]
    f458:      	str	x20, [sp, #0x38]
    f45c:      	mov	x19, x8
    f460:      	mov	x20, x3
    f464:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f464:  ARM64_RELOC_PAGE21	l_stogir.547
    f468:      	ldr	x4, [x4]
		000000000000f468:  ARM64_RELOC_PAGEOFF12	l_stogir.547
    f46c:      	mov	x5, #0x10               ; =16
    f470:      	mov	x6, #0x4                ; =4
    f474:      	bl	0xf474 <_coil.alloc.reallocate__stogir.cfg.Edge+0x30>
		000000000000f474:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f478:      	ubfx	x0, x0, #0, #32
    f47c:      	lsr	x16, x0, #0
    f480:      	cmp	x16, #0x1
    f484:      	b.eq	0xf4a0 <_coil.alloc.reallocate__stogir.cfg.Edge+0x5c>
    f488:      	b.lo	0xf490 <_coil.alloc.reallocate__stogir.cfg.Edge+0x4c>
    f48c:      	b	0xf4a4 <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    f490:      	cmp	x16, #0x0
    f494:      	b.eq	0xf49c <_coil.alloc.reallocate__stogir.cfg.Edge+0x58>
    f498:      	b	0xf4a4 <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    f49c:      	b	0xf4a8 <_coil.alloc.reallocate__stogir.cfg.Edge+0x64>
    f4a0:      	b	0xf4b8 <_coil.alloc.reallocate__stogir.cfg.Edge+0x74>
    f4a4:      	b	0xf4e0 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>
    f4a8:      	movz	x0, #0x0, lsl #48
    f4ac:      	movz	x1, #0x0, lsl #48
    f4b0:      	movz	x20, #0x0, lsl #48
    f4b4:      	b	0xf4bc <_coil.alloc.reallocate__stogir.cfg.Edge+0x78>
    f4b8:      	mov	x0, #0x1                ; =1
    f4bc:      	str	x0, [x19]
    f4c0:      	str	x1, [x19, #0x8]
    f4c4:      	str	x20, [x19, #0x10]
    f4c8:      	ldr	x19, [sp, #0x30]
    f4cc:      	ldr	x20, [sp, #0x38]
    f4d0:      	ldr	x29, [sp, #0x10]
    f4d4:      	ldr	x30, [sp, #0x18]
    f4d8:      	add	sp, sp, #0x40
    f4dc:      	ret
    f4e0:      	brk	#0
    f4e4:      	b	0xf4e0 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>

000000000000f4e8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range>:
    f4e8:      	sub	sp, sp, #0x50
    f4ec:      	str	x29, [sp]
    f4f0:      	str	x30, [sp, #0x8]
    f4f4:      	mov	x29, sp
    f4f8:      	str	x19, [sp, #0x40]
    f4fc:      	str	x20, [sp, #0x48]
    f500:      	add	x2, x0, #0x18
    f504:      	ldr	x3, [x0, #0x10]
    f508:      	ldr	x4, [x0, #0x18]
    f50c:      	ldr	x2, [x2, #0x8]
    f510:      	add	x16, sp, #0x10
    f514:      	str	x4, [x16]
    f518:      	add	x16, sp, #0x10
    f51c:      	str	x2, [x16, #0x8]
    f520:      	cmp	x1, x3
    f524:      	b.le	0xf598 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xb0>
    f528:      	add	x16, sp, #0x10
    f52c:      	orr	x2, x16, xzr
    f530:      	ldr	x4, [x0]
    f534:      	add	x8, sp, #0x20
    f538:      	mov	x19, x0
    f53c:      	mov	x0, x2
    f540:      	mov	x2, x3
    f544:      	mov	x3, x1
    f548:      	mov	x20, x1
    f54c:      	mov	x1, x4
    f550:      	bl	0xf550 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x68>
		000000000000f550:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Range
    f554:      	add	x16, sp, #0x20
    f558:      	ldr	w0, [x16]
    f55c:      	lsr	x16, x0, #0
    f560:      	cmp	x16, #0x1
    f564:      	b.eq	0xf580 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x98>
    f568:      	b.lo	0xf570 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x88>
    f56c:      	b	0xf584 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x9c>
    f570:      	cmp	x16, #0x0
    f574:      	b.eq	0xf57c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x94>
    f578:      	b	0xf584 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x9c>
    f57c:      	b	0xf5b4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xcc>
    f580:      	b	0xf588 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xa0>
    f584:      	b	0xf5cc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe4>
    f588:      	add	x16, sp, #0x20
    f58c:      	ldr	x0, [x16, #0x8]
    f590:      	str	x0, [x19]
    f594:      	str	x20, [x19, #0x10]
    f598:      	movz	x0, #0x0, lsl #48
    f59c:      	ldr	x19, [sp, #0x40]
    f5a0:      	ldr	x20, [sp, #0x48]
    f5a4:      	ldr	x29, [sp]
    f5a8:      	ldr	x30, [sp, #0x8]
    f5ac:      	add	sp, sp, #0x50
    f5b0:      	ret
    f5b4:      	lsl	x0, x20, #4
    f5b8:      	mov	x1, x0
    f5bc:      	adrp	x0, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f5bc:  ARM64_RELOC_PAGE21	l_stogir.548
    f5c0:      	ldr	x0, [x0]
		000000000000f5c0:  ARM64_RELOC_PAGEOFF12	l_stogir.548
    f5c4:      	bl	0xf5c4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xdc>
		000000000000f5c4:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    f5c8:      	b	0xf5c8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe0>
    f5cc:      	brk	#0
    f5d0:      	b	0xf5cc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe4>

000000000000f5d4 <_coil.alloc.reallocate__bool>:
    f5d4:      	sub	sp, sp, #0x40
    f5d8:      	str	x29, [sp, #0x10]
    f5dc:      	str	x30, [sp, #0x18]
    f5e0:      	add	x29, sp, #0x10
    f5e4:      	str	x19, [sp, #0x30]
    f5e8:      	str	x20, [sp, #0x38]
    f5ec:      	mov	x19, x8
    f5f0:      	mov	x20, x3
    f5f4:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f5f4:  ARM64_RELOC_PAGE21	l_stogir.549
    f5f8:      	ldr	x4, [x4]
		000000000000f5f8:  ARM64_RELOC_PAGEOFF12	l_stogir.549
    f5fc:      	mov	x5, #0x1                ; =1
    f600:      	mov	x6, #0x1                ; =1
    f604:      	bl	0xf604 <_coil.alloc.reallocate__bool+0x30>
		000000000000f604:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f608:      	ubfx	x0, x0, #0, #32
    f60c:      	lsr	x16, x0, #0
    f610:      	cmp	x16, #0x1
    f614:      	b.eq	0xf630 <_coil.alloc.reallocate__bool+0x5c>
    f618:      	b.lo	0xf620 <_coil.alloc.reallocate__bool+0x4c>
    f61c:      	b	0xf634 <_coil.alloc.reallocate__bool+0x60>
    f620:      	cmp	x16, #0x0
    f624:      	b.eq	0xf62c <_coil.alloc.reallocate__bool+0x58>
    f628:      	b	0xf634 <_coil.alloc.reallocate__bool+0x60>
    f62c:      	b	0xf638 <_coil.alloc.reallocate__bool+0x64>
    f630:      	b	0xf648 <_coil.alloc.reallocate__bool+0x74>
    f634:      	b	0xf670 <_coil.alloc.reallocate__bool+0x9c>
    f638:      	movz	x0, #0x0, lsl #48
    f63c:      	movz	x1, #0x0, lsl #48
    f640:      	movz	x20, #0x0, lsl #48
    f644:      	b	0xf64c <_coil.alloc.reallocate__bool+0x78>
    f648:      	mov	x0, #0x1                ; =1
    f64c:      	str	x0, [x19]
    f650:      	str	x1, [x19, #0x8]
    f654:      	str	x20, [x19, #0x10]
    f658:      	ldr	x19, [sp, #0x30]
    f65c:      	ldr	x20, [sp, #0x38]
    f660:      	ldr	x29, [sp, #0x10]
    f664:      	ldr	x30, [sp, #0x18]
    f668:      	add	sp, sp, #0x40
    f66c:      	ret
    f670:      	brk	#0
    f674:      	b	0xf670 <_coil.alloc.reallocate__bool+0x9c>

000000000000f678 <_coil.alloc.reallocate__stogir.adjacency.Frame>:
    f678:      	sub	sp, sp, #0x40
    f67c:      	str	x29, [sp, #0x10]
    f680:      	str	x30, [sp, #0x18]
    f684:      	add	x29, sp, #0x10
    f688:      	str	x19, [sp, #0x30]
    f68c:      	str	x20, [sp, #0x38]
    f690:      	mov	x19, x8
    f694:      	mov	x20, x3
    f698:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f698:  ARM64_RELOC_PAGE21	l_stogir.550
    f69c:      	ldr	x4, [x4]
		000000000000f69c:  ARM64_RELOC_PAGEOFF12	l_stogir.550
    f6a0:      	mov	x5, #0x10               ; =16
    f6a4:      	mov	x6, #0x8                ; =8
    f6a8:      	bl	0xf6a8 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x30>
		000000000000f6a8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f6ac:      	ubfx	x0, x0, #0, #32
    f6b0:      	lsr	x16, x0, #0
    f6b4:      	cmp	x16, #0x1
    f6b8:      	b.eq	0xf6d4 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x5c>
    f6bc:      	b.lo	0xf6c4 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x4c>
    f6c0:      	b	0xf6d8 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    f6c4:      	cmp	x16, #0x0
    f6c8:      	b.eq	0xf6d0 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x58>
    f6cc:      	b	0xf6d8 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    f6d0:      	b	0xf6dc <_coil.alloc.reallocate__stogir.adjacency.Frame+0x64>
    f6d4:      	b	0xf6ec <_coil.alloc.reallocate__stogir.adjacency.Frame+0x74>
    f6d8:      	b	0xf714 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>
    f6dc:      	movz	x0, #0x0, lsl #48
    f6e0:      	movz	x1, #0x0, lsl #48
    f6e4:      	movz	x20, #0x0, lsl #48
    f6e8:      	b	0xf6f0 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x78>
    f6ec:      	mov	x0, #0x1                ; =1
    f6f0:      	str	x0, [x19]
    f6f4:      	str	x1, [x19, #0x8]
    f6f8:      	str	x20, [x19, #0x10]
    f6fc:      	ldr	x19, [sp, #0x30]
    f700:      	ldr	x20, [sp, #0x38]
    f704:      	ldr	x29, [sp, #0x10]
    f708:      	ldr	x30, [sp, #0x18]
    f70c:      	add	sp, sp, #0x40
    f710:      	ret
    f714:      	brk	#0
    f718:      	b	0xf714 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>

000000000000f71c <_coil.alloc.reallocate__i64>:
    f71c:      	sub	sp, sp, #0x40
    f720:      	str	x29, [sp, #0x10]
    f724:      	str	x30, [sp, #0x18]
    f728:      	add	x29, sp, #0x10
    f72c:      	str	x19, [sp, #0x30]
    f730:      	str	x20, [sp, #0x38]
    f734:      	mov	x19, x8
    f738:      	mov	x20, x3
    f73c:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f73c:  ARM64_RELOC_PAGE21	l_stogir.551
    f740:      	ldr	x4, [x4]
		000000000000f740:  ARM64_RELOC_PAGEOFF12	l_stogir.551
    f744:      	mov	x5, #0x8                ; =8
    f748:      	mov	x6, #0x8                ; =8
    f74c:      	bl	0xf74c <_coil.alloc.reallocate__i64+0x30>
		000000000000f74c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f750:      	ubfx	x0, x0, #0, #32
    f754:      	lsr	x16, x0, #0
    f758:      	cmp	x16, #0x1
    f75c:      	b.eq	0xf778 <_coil.alloc.reallocate__i64+0x5c>
    f760:      	b.lo	0xf768 <_coil.alloc.reallocate__i64+0x4c>
    f764:      	b	0xf77c <_coil.alloc.reallocate__i64+0x60>
    f768:      	cmp	x16, #0x0
    f76c:      	b.eq	0xf774 <_coil.alloc.reallocate__i64+0x58>
    f770:      	b	0xf77c <_coil.alloc.reallocate__i64+0x60>
    f774:      	b	0xf780 <_coil.alloc.reallocate__i64+0x64>
    f778:      	b	0xf790 <_coil.alloc.reallocate__i64+0x74>
    f77c:      	b	0xf7b8 <_coil.alloc.reallocate__i64+0x9c>
    f780:      	movz	x0, #0x0, lsl #48
    f784:      	movz	x1, #0x0, lsl #48
    f788:      	movz	x20, #0x0, lsl #48
    f78c:      	b	0xf794 <_coil.alloc.reallocate__i64+0x78>
    f790:      	mov	x0, #0x1                ; =1
    f794:      	str	x0, [x19]
    f798:      	str	x1, [x19, #0x8]
    f79c:      	str	x20, [x19, #0x10]
    f7a0:      	ldr	x19, [sp, #0x30]
    f7a4:      	ldr	x20, [sp, #0x38]
    f7a8:      	ldr	x29, [sp, #0x10]
    f7ac:      	ldr	x30, [sp, #0x18]
    f7b0:      	add	sp, sp, #0x40
    f7b4:      	ret
    f7b8:      	brk	#0
    f7bc:      	b	0xf7b8 <_coil.alloc.reallocate__i64+0x9c>

000000000000f7c0 <_coil.alloc.reallocate__stogir.uses.Range>:
    f7c0:      	sub	sp, sp, #0x40
    f7c4:      	str	x29, [sp, #0x10]
    f7c8:      	str	x30, [sp, #0x18]
    f7cc:      	add	x29, sp, #0x10
    f7d0:      	str	x19, [sp, #0x30]
    f7d4:      	str	x20, [sp, #0x38]
    f7d8:      	mov	x19, x8
    f7dc:      	mov	x20, x3
    f7e0:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f7e0:  ARM64_RELOC_PAGE21	l_stogir.552
    f7e4:      	ldr	x4, [x4]
		000000000000f7e4:  ARM64_RELOC_PAGEOFF12	l_stogir.552
    f7e8:      	mov	x5, #0x10               ; =16
    f7ec:      	mov	x6, #0x8                ; =8
    f7f0:      	bl	0xf7f0 <_coil.alloc.reallocate__stogir.uses.Range+0x30>
		000000000000f7f0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f7f4:      	ubfx	x0, x0, #0, #32
    f7f8:      	lsr	x16, x0, #0
    f7fc:      	cmp	x16, #0x1
    f800:      	b.eq	0xf81c <_coil.alloc.reallocate__stogir.uses.Range+0x5c>
    f804:      	b.lo	0xf80c <_coil.alloc.reallocate__stogir.uses.Range+0x4c>
    f808:      	b	0xf820 <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    f80c:      	cmp	x16, #0x0
    f810:      	b.eq	0xf818 <_coil.alloc.reallocate__stogir.uses.Range+0x58>
    f814:      	b	0xf820 <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    f818:      	b	0xf824 <_coil.alloc.reallocate__stogir.uses.Range+0x64>
    f81c:      	b	0xf834 <_coil.alloc.reallocate__stogir.uses.Range+0x74>
    f820:      	b	0xf85c <_coil.alloc.reallocate__stogir.uses.Range+0x9c>
    f824:      	movz	x0, #0x0, lsl #48
    f828:      	movz	x1, #0x0, lsl #48
    f82c:      	movz	x20, #0x0, lsl #48
    f830:      	b	0xf838 <_coil.alloc.reallocate__stogir.uses.Range+0x78>
    f834:      	mov	x0, #0x1                ; =1
    f838:      	str	x0, [x19]
    f83c:      	str	x1, [x19, #0x8]
    f840:      	str	x20, [x19, #0x10]
    f844:      	ldr	x19, [sp, #0x30]
    f848:      	ldr	x20, [sp, #0x38]
    f84c:      	ldr	x29, [sp, #0x10]
    f850:      	ldr	x30, [sp, #0x18]
    f854:      	add	sp, sp, #0x40
    f858:      	ret
    f85c:      	brk	#0
    f860:      	b	0xf85c <_coil.alloc.reallocate__stogir.uses.Range+0x9c>

000000000000f864 <_coil.alloc.reallocate__stogir.uses.Use>:
    f864:      	sub	sp, sp, #0x40
    f868:      	str	x29, [sp, #0x10]
    f86c:      	str	x30, [sp, #0x18]
    f870:      	add	x29, sp, #0x10
    f874:      	str	x19, [sp, #0x30]
    f878:      	str	x20, [sp, #0x38]
    f87c:      	mov	x19, x8
    f880:      	mov	x20, x3
    f884:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f884:  ARM64_RELOC_PAGE21	l_stogir.553
    f888:      	ldr	x4, [x4]
		000000000000f888:  ARM64_RELOC_PAGEOFF12	l_stogir.553
    f88c:      	mov	x5, #0x8                ; =8
    f890:      	mov	x6, #0x4                ; =4
    f894:      	bl	0xf894 <_coil.alloc.reallocate__stogir.uses.Use+0x30>
		000000000000f894:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f898:      	ubfx	x0, x0, #0, #32
    f89c:      	lsr	x16, x0, #0
    f8a0:      	cmp	x16, #0x1
    f8a4:      	b.eq	0xf8c0 <_coil.alloc.reallocate__stogir.uses.Use+0x5c>
    f8a8:      	b.lo	0xf8b0 <_coil.alloc.reallocate__stogir.uses.Use+0x4c>
    f8ac:      	b	0xf8c4 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    f8b0:      	cmp	x16, #0x0
    f8b4:      	b.eq	0xf8bc <_coil.alloc.reallocate__stogir.uses.Use+0x58>
    f8b8:      	b	0xf8c4 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    f8bc:      	b	0xf8c8 <_coil.alloc.reallocate__stogir.uses.Use+0x64>
    f8c0:      	b	0xf8d8 <_coil.alloc.reallocate__stogir.uses.Use+0x74>
    f8c4:      	b	0xf900 <_coil.alloc.reallocate__stogir.uses.Use+0x9c>
    f8c8:      	movz	x0, #0x0, lsl #48
    f8cc:      	movz	x1, #0x0, lsl #48
    f8d0:      	movz	x20, #0x0, lsl #48
    f8d4:      	b	0xf8dc <_coil.alloc.reallocate__stogir.uses.Use+0x78>
    f8d8:      	mov	x0, #0x1                ; =1
    f8dc:      	str	x0, [x19]
    f8e0:      	str	x1, [x19, #0x8]
    f8e4:      	str	x20, [x19, #0x10]
    f8e8:      	ldr	x19, [sp, #0x30]
    f8ec:      	ldr	x20, [sp, #0x38]
    f8f0:      	ldr	x29, [sp, #0x10]
    f8f4:      	ldr	x30, [sp, #0x18]
    f8f8:      	add	sp, sp, #0x40
    f8fc:      	ret
    f900:      	brk	#0
    f904:      	b	0xf900 <_coil.alloc.reallocate__stogir.uses.Use+0x9c>

000000000000f908 <_coil.alloc.reallocate__stogir.schedule.Range>:
    f908:      	sub	sp, sp, #0x40
    f90c:      	str	x29, [sp, #0x10]
    f910:      	str	x30, [sp, #0x18]
    f914:      	add	x29, sp, #0x10
    f918:      	str	x19, [sp, #0x30]
    f91c:      	str	x20, [sp, #0x38]
    f920:      	mov	x19, x8
    f924:      	mov	x20, x3
    f928:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000f928:  ARM64_RELOC_PAGE21	l_stogir.554
    f92c:      	ldr	x4, [x4]
		000000000000f92c:  ARM64_RELOC_PAGEOFF12	l_stogir.554
    f930:      	mov	x5, #0x10               ; =16
    f934:      	mov	x6, #0x8                ; =8
    f938:      	bl	0xf938 <_coil.alloc.reallocate__stogir.schedule.Range+0x30>
		000000000000f938:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f93c:      	ubfx	x0, x0, #0, #32
    f940:      	lsr	x16, x0, #0
    f944:      	cmp	x16, #0x1
    f948:      	b.eq	0xf964 <_coil.alloc.reallocate__stogir.schedule.Range+0x5c>
    f94c:      	b.lo	0xf954 <_coil.alloc.reallocate__stogir.schedule.Range+0x4c>
    f950:      	b	0xf968 <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    f954:      	cmp	x16, #0x0
    f958:      	b.eq	0xf960 <_coil.alloc.reallocate__stogir.schedule.Range+0x58>
    f95c:      	b	0xf968 <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    f960:      	b	0xf96c <_coil.alloc.reallocate__stogir.schedule.Range+0x64>
    f964:      	b	0xf97c <_coil.alloc.reallocate__stogir.schedule.Range+0x74>
    f968:      	b	0xf9a4 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>
    f96c:      	movz	x0, #0x0, lsl #48
    f970:      	movz	x1, #0x0, lsl #48
    f974:      	movz	x20, #0x0, lsl #48
    f978:      	b	0xf980 <_coil.alloc.reallocate__stogir.schedule.Range+0x78>
    f97c:      	mov	x0, #0x1                ; =1
    f980:      	str	x0, [x19]
    f984:      	str	x1, [x19, #0x8]
    f988:      	str	x20, [x19, #0x10]
    f98c:      	ldr	x19, [sp, #0x30]
    f990:      	ldr	x20, [sp, #0x38]
    f994:      	ldr	x29, [sp, #0x10]
    f998:      	ldr	x30, [sp, #0x18]
    f99c:      	add	sp, sp, #0x40
    f9a0:      	ret
    f9a4:      	brk	#0
    f9a8:      	b	0xf9a4 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>

000000000000f9ac <_coil.alloc.sized-reallocate>:
    f9ac:      	sub	sp, sp, #0x90
    f9b0:      	str	x29, [sp, #0x10]
    f9b4:      	str	x30, [sp, #0x18]
    f9b8:      	add	x29, sp, #0x10
    f9bc:      	str	x19, [sp, #0x50]
    f9c0:      	str	x20, [sp, #0x58]
    f9c4:      	str	x21, [sp, #0x60]
    f9c8:      	str	x22, [sp, #0x68]
    f9cc:      	str	x23, [sp, #0x70]
    f9d0:      	str	x24, [sp, #0x78]
    f9d4:      	str	x25, [sp, #0x80]
    f9d8:      	str	x26, [sp, #0x88]
    f9dc:      	add	x19, sp, #0x20
    f9e0:      	mov	x20, x0
    f9e4:      	mov	x21, x1
    f9e8:      	mov	x22, x2
    f9ec:      	mov	x23, x3
    f9f0:      	mov	x24, x4
    f9f4:      	mov	x25, x5
    f9f8:      	mov	x26, x6
    f9fc:      	movz	x7, #0x0, lsl #48
    fa00:      	uxtb	w7, w7
    fa04:      	bl	0xfa04 <_coil.alloc.sized-reallocate+0x58>
		000000000000fa04:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-resize
    fa08:      	ubfx	x0, x0, #0, #32
    fa0c:      	lsr	x16, x0, #0
    fa10:      	cmp	x16, #0x1
    fa14:      	b.eq	0xfa30 <_coil.alloc.sized-reallocate+0x84>
    fa18:      	b.lo	0xfa20 <_coil.alloc.sized-reallocate+0x74>
    fa1c:      	b	0xfa34 <_coil.alloc.sized-reallocate+0x88>
    fa20:      	cmp	x16, #0x0
    fa24:      	b.eq	0xfa2c <_coil.alloc.sized-reallocate+0x80>
    fa28:      	b	0xfa34 <_coil.alloc.sized-reallocate+0x88>
    fa2c:      	b	0xfa80 <_coil.alloc.sized-reallocate+0xd4>
    fa30:      	b	0xfa38 <_coil.alloc.sized-reallocate+0x8c>
    fa34:      	b	0xfb20 <_coil.alloc.sized-reallocate+0x174>
    fa38:      	mov	x23, x1
    fa3c:      	mov	x0, #0x1                ; =1
    fa40:      	str	x0, [x19]
    fa44:      	str	x23, [x19, #0x8]
    fa48:      	ldr	x0, [sp, #0x20]
    fa4c:      	ldr	x1, [sp, #0x28]
    fa50:      	ldr	x19, [sp, #0x50]
    fa54:      	ldr	x20, [sp, #0x58]
    fa58:      	ldr	x21, [sp, #0x60]
    fa5c:      	ldr	x22, [sp, #0x68]
    fa60:      	ldr	x23, [sp, #0x70]
    fa64:      	ldr	x24, [sp, #0x78]
    fa68:      	ldr	x25, [sp, #0x80]
    fa6c:      	ldr	x26, [sp, #0x88]
    fa70:      	ldr	x29, [sp, #0x10]
    fa74:      	ldr	x30, [sp, #0x18]
    fa78:      	add	sp, sp, #0x90
    fa7c:      	ret
    fa80:      	mov	x0, x20
    fa84:      	mov	x1, x24
    fa88:      	mov	x2, x25
    fa8c:      	mov	x3, x26
    fa90:      	mov	x4, x23
    fa94:      	bl	0xfa94 <_coil.alloc.sized-reallocate+0xe8>
		000000000000fa94:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    fa98:      	ubfx	x0, x0, #0, #32
    fa9c:      	lsr	x16, x0, #0
    faa0:      	cmp	x16, #0x1
    faa4:      	b.eq	0xfac0 <_coil.alloc.sized-reallocate+0x114>
    faa8:      	b.lo	0xfab0 <_coil.alloc.sized-reallocate+0x104>
    faac:      	b	0xfac4 <_coil.alloc.sized-reallocate+0x118>
    fab0:      	cmp	x16, #0x0
    fab4:      	b.eq	0xfabc <_coil.alloc.sized-reallocate+0x110>
    fab8:      	b	0xfac4 <_coil.alloc.sized-reallocate+0x118>
    fabc:      	b	0xfac8 <_coil.alloc.sized-reallocate+0x11c>
    fac0:      	b	0xfad4 <_coil.alloc.sized-reallocate+0x128>
    fac4:      	b	0xfb28 <_coil.alloc.sized-reallocate+0x17c>
    fac8:      	movz	x0, #0x0, lsl #48
    facc:      	movz	x23, #0x0, lsl #48
    fad0:      	b	0xfb1c <_coil.alloc.sized-reallocate+0x170>
    fad4:      	cmp	x22, x23
    fad8:      	b.ge	0xfae0 <_coil.alloc.sized-reallocate+0x134>
    fadc:      	mov	x23, x22
    fae0:      	mul	x0, x25, x23
    fae4:      	lsr	x0, x0, #0
    fae8:      	mov	x2, x0
    faec:      	mov	x0, x1
    faf0:      	mov	x23, x1
    faf4:      	mov	x1, x21
    faf8:      	bl	0xfaf8 <_coil.alloc.sized-reallocate+0x14c>
		000000000000faf8:  ARM64_RELOC_BRANCH26	_memcpy
    fafc:      	mov	x0, x20
    fb00:      	mov	x1, x21
    fb04:      	mov	x2, x22
    fb08:      	mov	x3, x24
    fb0c:      	mov	x4, x25
    fb10:      	mov	x5, x26
    fb14:      	bl	0xfb14 <_coil.alloc.sized-reallocate+0x168>
		000000000000fb14:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    fb18:      	mov	x0, #0x1                ; =1
    fb1c:      	b	0xfa40 <_coil.alloc.sized-reallocate+0x94>
    fb20:      	brk	#0
    fb24:      	b	0xfb20 <_coil.alloc.sized-reallocate+0x174>
    fb28:      	brk	#0
    fb2c:      	b	0xfb28 <_coil.alloc.sized-reallocate+0x17c>

000000000000fb30 <_coil.alloc.reallocate__stogir.adjacency.Range>:
    fb30:      	sub	sp, sp, #0x40
    fb34:      	str	x29, [sp, #0x10]
    fb38:      	str	x30, [sp, #0x18]
    fb3c:      	add	x29, sp, #0x10
    fb40:      	str	x19, [sp, #0x30]
    fb44:      	str	x20, [sp, #0x38]
    fb48:      	mov	x19, x8
    fb4c:      	mov	x20, x3
    fb50:      	adrp	x4, 0xf000 <_stogir.checked.validate+0x37c>
		000000000000fb50:  ARM64_RELOC_PAGE21	l_stogir.555
    fb54:      	ldr	x4, [x4]
		000000000000fb54:  ARM64_RELOC_PAGEOFF12	l_stogir.555
    fb58:      	mov	x5, #0x10               ; =16
    fb5c:      	mov	x6, #0x8                ; =8
    fb60:      	bl	0xfb60 <_coil.alloc.reallocate__stogir.adjacency.Range+0x30>
		000000000000fb60:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    fb64:      	ubfx	x0, x0, #0, #32
    fb68:      	lsr	x16, x0, #0
    fb6c:      	cmp	x16, #0x1
    fb70:      	b.eq	0xfb8c <_coil.alloc.reallocate__stogir.adjacency.Range+0x5c>
    fb74:      	b.lo	0xfb7c <_coil.alloc.reallocate__stogir.adjacency.Range+0x4c>
    fb78:      	b	0xfb90 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    fb7c:      	cmp	x16, #0x0
    fb80:      	b.eq	0xfb88 <_coil.alloc.reallocate__stogir.adjacency.Range+0x58>
    fb84:      	b	0xfb90 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    fb88:      	b	0xfb94 <_coil.alloc.reallocate__stogir.adjacency.Range+0x64>
    fb8c:      	b	0xfba4 <_coil.alloc.reallocate__stogir.adjacency.Range+0x74>
    fb90:      	b	0xfbcc <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>
    fb94:      	movz	x0, #0x0, lsl #48
    fb98:      	movz	x1, #0x0, lsl #48
    fb9c:      	movz	x20, #0x0, lsl #48
    fba0:      	b	0xfba8 <_coil.alloc.reallocate__stogir.adjacency.Range+0x78>
    fba4:      	mov	x0, #0x1                ; =1
    fba8:      	str	x0, [x19]
    fbac:      	str	x1, [x19, #0x8]
    fbb0:      	str	x20, [x19, #0x10]
    fbb4:      	ldr	x19, [sp, #0x30]
    fbb8:      	ldr	x20, [sp, #0x38]
    fbbc:      	ldr	x29, [sp, #0x10]
    fbc0:      	ldr	x30, [sp, #0x18]
    fbc4:      	add	sp, sp, #0x40
    fbc8:      	ret
    fbcc:      	brk	#0
    fbd0:      	b	0xfbcc <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>

000000000000fbd4 <_coil.alloc.sized-resize>:
    fbd4:      	sub	sp, sp, #0x130
    fbd8:      	str	x29, [sp, #0x10]
    fbdc:      	str	x30, [sp, #0x18]
    fbe0:      	add	x29, sp, #0x10
    fbe4:      	str	x19, [sp, #0xf0]
    fbe8:      	str	x20, [sp, #0xf8]
    fbec:      	str	x21, [sp, #0x100]
    fbf0:      	str	x22, [sp, #0x108]
    fbf4:      	str	x23, [sp, #0x110]
    fbf8:      	str	x24, [sp, #0x118]
    fbfc:      	str	x25, [sp, #0x120]
    fc00:      	str	x26, [sp, #0x128]
    fc04:      	add	x19, sp, #0x20
    fc08:      	cmp	x3, #0x0
    fc0c:      	b.ne	0xfc68 <_coil.alloc.sized-resize+0x94>
    fc10:      	mov	x3, x4
    fc14:      	mov	x4, x5
    fc18:      	mov	x5, x6
    fc1c:      	bl	0xfc1c <_coil.alloc.sized-resize+0x48>
		000000000000fc1c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    fc20:      	mov	x0, #0x1                ; =1
    fc24:      	movz	x1, #0x0, lsl #48
    fc28:      	str	x0, [x19]
    fc2c:      	str	x1, [x19, #0x8]
    fc30:      	ldr	x0, [sp, #0x20]
    fc34:      	ldr	x1, [sp, #0x28]
    fc38:      	ldr	x19, [sp, #0xf0]
    fc3c:      	ldr	x20, [sp, #0xf8]
    fc40:      	ldr	x21, [sp, #0x100]
    fc44:      	ldr	x22, [sp, #0x108]
    fc48:      	ldr	x23, [sp, #0x110]
    fc4c:      	ldr	x24, [sp, #0x118]
    fc50:      	ldr	x25, [sp, #0x120]
    fc54:      	ldr	x26, [sp, #0x128]
    fc58:      	ldr	x29, [sp, #0x10]
    fc5c:      	ldr	x30, [sp, #0x18]
    fc60:      	add	sp, sp, #0x130
    fc64:      	ret
    fc68:      	cmp	x2, #0x0
    fc6c:      	b.ne	0xfc88 <_coil.alloc.sized-resize+0xb4>
    fc70:      	mov	x1, x4
    fc74:      	mov	x2, x5
    fc78:      	mov	x4, x3
    fc7c:      	mov	x3, x6
    fc80:      	bl	0xfc80 <_coil.alloc.sized-resize+0xac>
		000000000000fc80:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    fc84:      	b	0xfc28 <_coil.alloc.sized-resize+0x54>
    fc88:      	add	x8, sp, #0x30
    fc8c:      	mov	x20, x0
    fc90:      	mov	x0, x4
    fc94:      	mov	x21, x1
    fc98:      	mov	x1, x5
    fc9c:      	mov	x22, x3
    fca0:      	mov	x3, x2
    fca4:      	mov	x2, x6
    fca8:      	mov	x23, x4
    fcac:      	mov	x24, x5
    fcb0:      	mov	x25, x6
    fcb4:      	mov	w26, w7
    fcb8:      	bl	0xfcb8 <_coil.alloc.sized-resize+0xe4>
		000000000000fcb8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    fcbc:      	add	x16, sp, #0x30
    fcc0:      	ldr	w0, [x16]
    fcc4:      	lsr	x16, x0, #0
    fcc8:      	cmp	x16, #0x1
    fccc:      	b.eq	0xfce8 <_coil.alloc.sized-resize+0x114>
    fcd0:      	b.lo	0xfcd8 <_coil.alloc.sized-resize+0x104>
    fcd4:      	b	0xfcec <_coil.alloc.sized-resize+0x118>
    fcd8:      	cmp	x16, #0x0
    fcdc:      	b.eq	0xfce4 <_coil.alloc.sized-resize+0x110>
    fce0:      	b	0xfcec <_coil.alloc.sized-resize+0x118>
    fce4:      	b	0xfcf0 <_coil.alloc.sized-resize+0x11c>
    fce8:      	b	0xfcfc <_coil.alloc.sized-resize+0x128>
    fcec:      	b	0xfe3c <_coil.alloc.sized-resize+0x268>
    fcf0:      	movz	x0, #0x0, lsl #48
    fcf4:      	movz	x1, #0x0, lsl #48
    fcf8:      	b	0xfc84 <_coil.alloc.sized-resize+0xb0>
    fcfc:      	add	x16, sp, #0x30
    fd00:      	orr	x0, x16, xzr
    fd04:      	add	x0, x0, #0x8
    fd08:      	add	x16, sp, #0x30
    fd0c:      	ldr	x1, [x16, #0x8]
    fd10:      	add	x16, sp, #0x60
    fd14:      	str	x1, [x16]
    fd18:      	ldr	x1, [x0, #0x8]
    fd1c:      	add	x16, sp, #0x60
    fd20:      	str	x1, [x16, #0x8]
    fd24:      	ldr	x1, [x0, #0x10]
    fd28:      	add	x16, sp, #0x60
    fd2c:      	str	x1, [x16, #0x10]
    fd30:      	ldr	x0, [x0, #0x18]
    fd34:      	add	x16, sp, #0x60
    fd38:      	str	x0, [x16, #0x18]
    fd3c:      	add	x8, sp, #0x80
    fd40:      	mov	x0, x23
    fd44:      	mov	x1, x24
    fd48:      	mov	x2, x25
    fd4c:      	mov	x3, x22
    fd50:      	bl	0xfd50 <_coil.alloc.sized-resize+0x17c>
		000000000000fd50:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    fd54:      	add	x16, sp, #0x80
    fd58:      	ldr	w0, [x16]
    fd5c:      	lsr	x16, x0, #0
    fd60:      	cmp	x16, #0x1
    fd64:      	b.eq	0xfd80 <_coil.alloc.sized-resize+0x1ac>
    fd68:      	b.lo	0xfd70 <_coil.alloc.sized-resize+0x19c>
    fd6c:      	b	0xfd84 <_coil.alloc.sized-resize+0x1b0>
    fd70:      	cmp	x16, #0x0
    fd74:      	b.eq	0xfd7c <_coil.alloc.sized-resize+0x1a8>
    fd78:      	b	0xfd84 <_coil.alloc.sized-resize+0x1b0>
    fd7c:      	b	0xfd88 <_coil.alloc.sized-resize+0x1b4>
    fd80:      	b	0xfda0 <_coil.alloc.sized-resize+0x1cc>
    fd84:      	b	0xfe44 <_coil.alloc.sized-resize+0x270>
    fd88:      	movz	x0, #0x0, lsl #48
    fd8c:      	movz	x1, #0x0, lsl #48
    fd90:      	b	0xfd9c <_coil.alloc.sized-resize+0x1c8>
    fd94:      	movz	x0, #0x0, lsl #48
    fd98:      	movz	x1, #0x0, lsl #48
    fd9c:      	b	0xfcf8 <_coil.alloc.sized-resize+0x124>
    fda0:      	ubfx	x26, x26, #0, #8
    fda4:      	add	x16, sp, #0x60
    fda8:      	orr	x0, x16, xzr
    fdac:      	add	x16, sp, #0x80
    fdb0:      	orr	x1, x16, xzr
    fdb4:      	add	x16, sp, #0xb0
    fdb8:      	orr	x2, x16, xzr
    fdbc:      	add	x1, x1, #0x8
    fdc0:      	add	x16, sp, #0x80
    fdc4:      	ldr	x3, [x16, #0x8]
    fdc8:      	add	x16, sp, #0xb0
    fdcc:      	str	x3, [x16]
    fdd0:      	ldr	x3, [x1, #0x8]
    fdd4:      	add	x16, sp, #0xb0
    fdd8:      	str	x3, [x16, #0x8]
    fddc:      	ldr	x3, [x1, #0x10]
    fde0:      	add	x16, sp, #0xb0
    fde4:      	str	x3, [x16, #0x10]
    fde8:      	ldr	x1, [x1, #0x18]
    fdec:      	add	x16, sp, #0xb0
    fdf0:      	str	x1, [x16, #0x18]
    fdf4:      	cmp	x26, #0x0
    fdf8:      	b.eq	0xfe24 <_coil.alloc.sized-resize+0x250>
    fdfc:      	mov	x1, x21
    fe00:      	mov	x3, x2
    fe04:      	mov	x2, x0
    fe08:      	mov	x0, x20
    fe0c:      	bl	0xfe0c <_coil.alloc.sized-resize+0x238>
		000000000000fe0c:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-resize
    fe10:      	cmp	x0, #0x0
    fe14:      	b.eq	0xfd94 <_coil.alloc.sized-resize+0x1c0>
    fe18:      	mov	x1, x21
    fe1c:      	mov	x0, #0x1                ; =1
    fe20:      	b	0xfd9c <_coil.alloc.sized-resize+0x1c8>
    fe24:      	mov	x1, x21
    fe28:      	mov	x3, x2
    fe2c:      	mov	x2, x0
    fe30:      	mov	x0, x20
    fe34:      	bl	0xfe34 <_coil.alloc.sized-resize+0x260>
		000000000000fe34:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-remap
    fe38:      	b	0xfd9c <_coil.alloc.sized-resize+0x1c8>
    fe3c:      	brk	#0
    fe40:      	b	0xfe3c <_coil.alloc.sized-resize+0x268>
    fe44:      	brk	#0
    fe48:      	b	0xfe44 <_coil.alloc.sized-resize+0x270>

000000000000fe4c <_coil.alloc.sized-alloc>:
    fe4c:      	sub	sp, sp, #0xa0
    fe50:      	str	x29, [sp, #0x10]
    fe54:      	str	x30, [sp, #0x18]
    fe58:      	add	x29, sp, #0x10
    fe5c:      	str	x19, [sp, #0x90]
    fe60:      	str	x20, [sp, #0x98]
    fe64:      	add	x19, sp, #0x20
    fe68:      	cmp	x4, #0x0
    fe6c:      	b.ne	0xfea0 <_coil.alloc.sized-alloc+0x54>
    fe70:      	mov	x0, #0x1                ; =1
    fe74:      	movz	x1, #0x0, lsl #48
    fe78:      	str	x0, [x19]
    fe7c:      	str	x1, [x19, #0x8]
    fe80:      	ldr	x0, [sp, #0x20]
    fe84:      	ldr	x1, [sp, #0x28]
    fe88:      	ldr	x19, [sp, #0x90]
    fe8c:      	ldr	x20, [sp, #0x98]
    fe90:      	ldr	x29, [sp, #0x10]
    fe94:      	ldr	x30, [sp, #0x18]
    fe98:      	add	sp, sp, #0xa0
    fe9c:      	ret
    fea0:      	add	x8, sp, #0x30
    fea4:      	mov	x20, x0
    fea8:      	mov	x0, x1
    feac:      	mov	x1, x2
    feb0:      	mov	x2, x3
    feb4:      	mov	x3, x4
    feb8:      	bl	0xfeb8 <_coil.alloc.sized-alloc+0x6c>
		000000000000feb8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    febc:      	add	x16, sp, #0x30
    fec0:      	ldr	w0, [x16]
    fec4:      	lsr	x16, x0, #0
    fec8:      	cmp	x16, #0x1
    fecc:      	b.eq	0xfee8 <_coil.alloc.sized-alloc+0x9c>
    fed0:      	b.lo	0xfed8 <_coil.alloc.sized-alloc+0x8c>
    fed4:      	b	0xfeec <_coil.alloc.sized-alloc+0xa0>
    fed8:      	cmp	x16, #0x0
    fedc:      	b.eq	0xfee4 <_coil.alloc.sized-alloc+0x98>
    fee0:      	b	0xfeec <_coil.alloc.sized-alloc+0xa0>
    fee4:      	b	0xfef0 <_coil.alloc.sized-alloc+0xa4>
    fee8:      	b	0xfefc <_coil.alloc.sized-alloc+0xb0>
    feec:      	b	0xff50 <_coil.alloc.sized-alloc+0x104>
    fef0:      	movz	x0, #0x0, lsl #48
    fef4:      	movz	x1, #0x0, lsl #48
    fef8:      	b	0xff4c <_coil.alloc.sized-alloc+0x100>
    fefc:      	add	x16, sp, #0x30
    ff00:      	orr	x0, x16, xzr
    ff04:      	add	x16, sp, #0x60
    ff08:      	orr	x1, x16, xzr
    ff0c:      	add	x0, x0, #0x8
    ff10:      	add	x16, sp, #0x30
    ff14:      	ldr	x2, [x16, #0x8]
    ff18:      	add	x16, sp, #0x60
    ff1c:      	str	x2, [x16]
    ff20:      	ldr	x2, [x0, #0x8]
    ff24:      	add	x16, sp, #0x60
    ff28:      	str	x2, [x16, #0x8]
    ff2c:      	ldr	x2, [x0, #0x10]
    ff30:      	add	x16, sp, #0x60
    ff34:      	str	x2, [x16, #0x10]
    ff38:      	ldr	x0, [x0, #0x18]
    ff3c:      	add	x16, sp, #0x60
    ff40:      	str	x0, [x16, #0x18]
    ff44:      	mov	x0, x20
    ff48:      	bl	0xff48 <_coil.alloc.sized-alloc+0xfc>
		000000000000ff48:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-alloc
    ff4c:      	b	0xfe78 <_coil.alloc.sized-alloc+0x2c>
    ff50:      	brk	#0
    ff54:      	b	0xff50 <_coil.alloc.sized-alloc+0x104>

000000000000ff58 <_coil.alloc.raw-resize>:
    ff58:      	sub	sp, sp, #0x10
    ff5c:      	str	x29, [sp]
    ff60:      	str	x30, [sp, #0x8]
    ff64:      	mov	x29, sp
    ff68:      	ldr	x4, [x2, #0x8]
    ff6c:      	cmp	x4, #0x0
    ff70:      	b.le	0xffec <_coil.alloc.raw-resize+0x94>
    ff74:      	ldr	x4, [x2, #0x10]
    ff78:      	cmp	x4, #0x0
    ff7c:      	b.le	0xffec <_coil.alloc.raw-resize+0x94>
    ff80:      	ldr	x4, [x2, #0x18]
    ff84:      	cmp	x4, #0x0
    ff88:      	b.le	0xffec <_coil.alloc.raw-resize+0x94>
    ff8c:      	sub	x5, x4, #0x1
    ff90:      	and	x4, x5, x4
    ff94:      	cmp	x4, #0x0
    ff98:      	b.ne	0xffec <_coil.alloc.raw-resize+0x94>
    ff9c:      	ldr	x4, [x3, #0x8]
    ffa0:      	cmp	x4, #0x0
    ffa4:      	b.le	0xffec <_coil.alloc.raw-resize+0x94>
    ffa8:      	ldr	x4, [x3, #0x10]
    ffac:      	cmp	x4, #0x0
    ffb0:      	b.le	0xffec <_coil.alloc.raw-resize+0x94>
    ffb4:      	ldr	x4, [x3, #0x18]
    ffb8:      	cmp	x4, #0x0
    ffbc:      	b.le	0xffec <_coil.alloc.raw-resize+0x94>
    ffc0:      	sub	x5, x4, #0x1
    ffc4:      	and	x4, x5, x4
    ffc8:      	cmp	x4, #0x0
    ffcc:      	b.ne	0xffec <_coil.alloc.raw-resize+0x94>
    ffd0:      	ldr	x4, [x0]
    ffd4:      	ldr	x0, [x0, #0x8]
    ffd8:      	ldr	x0, [x0, #0x8]
    ffdc:      	mov	x30, x0
    ffe0:      	mov	x0, x4
    ffe4:      	blr	x30
    ffe8:      	b	0xfff0 <_coil.alloc.raw-resize+0x98>
    ffec:      	movz	x0, #0x0, lsl #48
    fff0:      	ldr	x29, [sp]
    fff4:      	ldr	x30, [sp, #0x8]
    fff8:      	add	sp, sp, #0x10
    fffc:      	ret

0000000000010000 <_coil.alloc.raw-remap>:
   10000:      	sub	sp, sp, #0x50
   10004:      	str	x29, [sp, #0x10]
   10008:      	str	x30, [sp, #0x18]
   1000c:      	add	x29, sp, #0x10
   10010:      	str	x19, [sp, #0x40]
   10014:      	add	x19, sp, #0x20
   10018:      	ldr	x4, [x2, #0x8]
   1001c:      	cmp	x4, #0x0
   10020:      	b.le	0x1009c <_coil.alloc.raw-remap+0x9c>
   10024:      	ldr	x4, [x2, #0x10]
   10028:      	cmp	x4, #0x0
   1002c:      	b.le	0x1009c <_coil.alloc.raw-remap+0x9c>
   10030:      	ldr	x4, [x2, #0x18]
   10034:      	cmp	x4, #0x0
   10038:      	b.le	0x1009c <_coil.alloc.raw-remap+0x9c>
   1003c:      	sub	x5, x4, #0x1
   10040:      	and	x4, x5, x4
   10044:      	cmp	x4, #0x0
   10048:      	b.ne	0x1009c <_coil.alloc.raw-remap+0x9c>
   1004c:      	ldr	x4, [x3, #0x8]
   10050:      	cmp	x4, #0x0
   10054:      	b.le	0x1009c <_coil.alloc.raw-remap+0x9c>
   10058:      	ldr	x4, [x3, #0x10]
   1005c:      	cmp	x4, #0x0
   10060:      	b.le	0x1009c <_coil.alloc.raw-remap+0x9c>
   10064:      	ldr	x4, [x3, #0x18]
   10068:      	cmp	x4, #0x0
   1006c:      	b.le	0x1009c <_coil.alloc.raw-remap+0x9c>
   10070:      	sub	x5, x4, #0x1
   10074:      	and	x4, x5, x4
   10078:      	cmp	x4, #0x0
   1007c:      	b.ne	0x1009c <_coil.alloc.raw-remap+0x9c>
   10080:      	ldr	x4, [x0]
   10084:      	ldr	x0, [x0, #0x8]
   10088:      	ldr	x0, [x0, #0x10]
   1008c:      	mov	x30, x0
   10090:      	mov	x0, x4
   10094:      	blr	x30
   10098:      	b	0x100a4 <_coil.alloc.raw-remap+0xa4>
   1009c:      	movz	x0, #0x0, lsl #48
   100a0:      	movz	x1, #0x0, lsl #48
   100a4:      	str	x0, [x19]
   100a8:      	str	x1, [x19, #0x8]
   100ac:      	ldr	x0, [sp, #0x20]
   100b0:      	ldr	x1, [sp, #0x28]
   100b4:      	ldr	x19, [sp, #0x40]
   100b8:      	ldr	x29, [sp, #0x10]
   100bc:      	ldr	x30, [sp, #0x18]
   100c0:      	add	sp, sp, #0x50
   100c4:      	ret

00000000000100c8 <_coil.alloc.raw-alloc>:
   100c8:      	sub	sp, sp, #0x50
   100cc:      	str	x29, [sp, #0x10]
   100d0:      	str	x30, [sp, #0x18]
   100d4:      	add	x29, sp, #0x10
   100d8:      	str	x19, [sp, #0x40]
   100dc:      	add	x19, sp, #0x20
   100e0:      	ldr	x2, [x1, #0x8]
   100e4:      	cmp	x2, #0x0
   100e8:      	b.le	0x10130 <_coil.alloc.raw-alloc+0x68>
   100ec:      	ldr	x2, [x1, #0x10]
   100f0:      	cmp	x2, #0x0
   100f4:      	b.le	0x10130 <_coil.alloc.raw-alloc+0x68>
   100f8:      	ldr	x2, [x1, #0x18]
   100fc:      	cmp	x2, #0x0
   10100:      	b.le	0x10130 <_coil.alloc.raw-alloc+0x68>
   10104:      	sub	x3, x2, #0x1
   10108:      	and	x2, x3, x2
   1010c:      	cmp	x2, #0x0
   10110:      	b.ne	0x10130 <_coil.alloc.raw-alloc+0x68>
   10114:      	ldr	x2, [x0]
   10118:      	ldr	x0, [x0, #0x8]
   1011c:      	ldr	x0, [x0]
   10120:      	mov	x30, x0
   10124:      	mov	x0, x2
   10128:      	blr	x30
   1012c:      	b	0x10138 <_coil.alloc.raw-alloc+0x70>
   10130:      	movz	x0, #0x0, lsl #48
   10134:      	movz	x1, #0x0, lsl #48
   10138:      	str	x0, [x19]
   1013c:      	str	x1, [x19, #0x8]
   10140:      	ldr	x0, [sp, #0x20]
   10144:      	ldr	x1, [sp, #0x28]
   10148:      	ldr	x19, [sp, #0x40]
   1014c:      	ldr	x29, [sp, #0x10]
   10150:      	ldr	x30, [sp, #0x18]
   10154:      	add	sp, sp, #0x50
   10158:      	ret
