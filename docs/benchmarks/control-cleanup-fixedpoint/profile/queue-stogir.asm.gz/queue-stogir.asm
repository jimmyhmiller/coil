
build/control-cleanup-comparison/emitter/stogir-after.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000018598 <_stogir.interval-queue.take!>:
   18598: f9400401     	ldr	x1, [x0, #0x8]
   1859c: f100003f     	cmp	x1, #0x0
   185a0: 540001c1     	b.ne	0x185d8 <_stogir.interval-queue.take!+0x40>
   185a4: d2e00000     	movz	x0, #0x0, lsl #48
   185a8: d2e00004     	movz	x4, #0x0, lsl #48
   185ac: d2e00003     	movz	x3, #0x0, lsl #48
   185b0: 14000006     	b	0x185c8 <_stogir.interval-queue.take!+0x30>
   185b4: f9400000     	ldr	x0, [x0]
   185b8: 8b071000     	add	x0, x0, x7, lsl #4
   185bc: f9000005     	str	x5, [x0]
   185c0: f9000402     	str	x2, [x0, #0x8]
   185c4: d2800020     	mov	x0, #0x1                ; =1
   185c8: f9000100     	str	x0, [x8]
   185cc: f9000504     	str	x4, [x8, #0x8]
   185d0: f9000903     	str	x3, [x8, #0x10]
   185d4: d65f03c0     	ret
   185d8: aa1f0022     	orr	x2, x1, xzr
   185dc: f9400003     	ldr	x3, [x0]
   185e0: d1000442     	sub	x2, x2, #0x1
   185e4: f9400064     	ldr	x4, [x3]
   185e8: 8b021062     	add	x2, x3, x2, lsl #4
   185ec: f9400463     	ldr	x3, [x3, #0x8]
   185f0: f9400045     	ldr	x5, [x2]
   185f4: f9400442     	ldr	x2, [x2, #0x8]
   185f8: f100003f     	cmp	x1, #0x0
   185fc: 54000060     	b.eq	0x18608 <_stogir.interval-queue.take!+0x70>
   18600: d1000421     	sub	x1, x1, #0x1
   18604: f9000401     	str	x1, [x0, #0x8]
   18608: f9400401     	ldr	x1, [x0, #0x8]
   1860c: f100003f     	cmp	x1, #0x0
   18610: 54fffdad     	b.le	0x185c4 <_stogir.interval-queue.take!+0x2c>
   18614: 2a1f0041     	orr	w1, w2, wzr
   18618: 93407c21     	sxtw	x1, w1
   1861c: d2e00006     	movz	x6, #0x0, lsl #48
   18620: d2e00007     	movz	x7, #0x0, lsl #48
   18624: 14000006     	b	0x1863c <_stogir.interval-queue.take!+0xa4>
   18628: f940000c     	ldr	x12, [x0]
   1862c: 8b071187     	add	x7, x12, x7, lsl #4
   18630: f90000eb     	str	x11, [x7]
   18634: f90004ea     	str	x10, [x7, #0x8]
   18638: aa0903e7     	mov	x7, x9
   1863c: f10000df     	cmp	x6, #0x0
   18640: 54fffba1     	b.ne	0x185b4 <_stogir.interval-queue.take!+0x1c>
   18644: d37ff8e9     	lsl	x9, x7, #1
   18648: f940040a     	ldr	x10, [x0, #0x8]
   1864c: 91000529     	add	x9, x9, #0x1
   18650: eb0a013f     	cmp	x9, x10
   18654: 5400006b     	b.lt	0x18660 <_stogir.interval-queue.take!+0xc8>
   18658: d2800026     	mov	x6, #0x1                ; =1
   1865c: 17fffff8     	b	0x1863c <_stogir.interval-queue.take!+0xa4>
   18660: 9100052b     	add	x11, x9, #0x1
   18664: eb0a017f     	cmp	x11, x10
   18668: 5400024a     	b.ge	0x186b0 <_stogir.interval-queue.take!+0x118>
   1866c: f940000a     	ldr	x10, [x0]
   18670: aa1f014c     	orr	x12, x10, xzr
   18674: 8b0b118c     	add	x12, x12, x11, lsl #4
   18678: 8b09114a     	add	x10, x10, x9, lsl #4
   1867c: f940018d     	ldr	x13, [x12]
   18680: f940058c     	ldr	x12, [x12, #0x8]
   18684: f940014e     	ldr	x14, [x10]
   18688: f940054a     	ldr	x10, [x10, #0x8]
   1868c: eb0e01bf     	cmp	x13, x14
   18690: 540000eb     	b.lt	0x186ac <_stogir.interval-queue.take!+0x114>
   18694: eb0e01bf     	cmp	x13, x14
   18698: 540000c1     	b.ne	0x186b0 <_stogir.interval-queue.take!+0x118>
   1869c: 93407d8c     	sxtw	x12, w12
   186a0: 93407d4a     	sxtw	x10, w10
   186a4: eb0a019f     	cmp	x12, x10
   186a8: 5400004a     	b.ge	0x186b0 <_stogir.interval-queue.take!+0x118>
   186ac: aa0b03e9     	mov	x9, x11
   186b0: f940000a     	ldr	x10, [x0]
   186b4: 8b09114a     	add	x10, x10, x9, lsl #4
   186b8: f940014b     	ldr	x11, [x10]
   186bc: f940054a     	ldr	x10, [x10, #0x8]
   186c0: eb05017f     	cmp	x11, x5
   186c4: 54fffb2b     	b.lt	0x18628 <_stogir.interval-queue.take!+0x90>
   186c8: eb05017f     	cmp	x11, x5
   186cc: 540000a1     	b.ne	0x186e0 <_stogir.interval-queue.take!+0x148>
   186d0: 2a1f014c     	orr	w12, w10, wzr
   186d4: 93407d8c     	sxtw	x12, w12
   186d8: eb01019f     	cmp	x12, x1
   186dc: 54fffa6b     	b.lt	0x18628 <_stogir.interval-queue.take!+0x90>
   186e0: d2800026     	mov	x6, #0x1                ; =1
   186e4: 17ffffd6     	b	0x1863c <_stogir.interval-queue.take!+0xa4>
