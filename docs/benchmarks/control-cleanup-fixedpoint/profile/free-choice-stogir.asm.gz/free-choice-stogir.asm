
build/control-cleanup-comparison/emitter/stogir-after.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000001c778 <_stogir.allocation.free-decision-for-class>:
   1c778: d10383ff     	sub	sp, sp, #0xe0
   1c77c: f90003fd     	str	x29, [sp]
   1c780: f90007fe     	str	x30, [sp, #0x8]
   1c784: 910003fd     	mov	x29, sp
   1c788: f90047f3     	str	x19, [sp, #0x88]
   1c78c: f9004bf4     	str	x20, [sp, #0x90]
   1c790: f9004ff5     	str	x21, [sp, #0x98]
   1c794: f90053f6     	str	x22, [sp, #0xa0]
   1c798: f90057f7     	str	x23, [sp, #0xa8]
   1c79c: f9005bf8     	str	x24, [sp, #0xb0]
   1c7a0: f9005ff9     	str	x25, [sp, #0xb8]
   1c7a4: f90063fa     	str	x26, [sp, #0xc0]
   1c7a8: f90067fb     	str	x27, [sp, #0xc8]
   1c7ac: f9006bfc     	str	x28, [sp, #0xd0]
   1c7b0: 910043a8     	add	x8, x29, #0x10
   1c7b4: 9100a009     	add	x9, x0, #0x28
   1c7b8: f940042a     	ldr	x10, [x1, #0x8]
   1c7bc: f9402c0b     	ldr	x11, [x0, #0x58]
   1c7c0: f940052c     	ldr	x12, [x9, #0x8]
   1c7c4: d2e0000d     	movz	x13, #0x0, lsl #48
   1c7c8: 14000003     	b	0x1c7d4 <_stogir.allocation.free-decision-for-class+0x5c>
   1c7cc: d503201f     	nop
   1c7d0: aa0e03ec     	mov	x12, x14
   1c7d4: eb0c01bf     	cmp	x13, x12
   1c7d8: 540001ca     	b.ge	0x1c810 <_stogir.allocation.free-decision-for-class+0x98>
   1c7dc: cb0d018e     	sub	x14, x12, x13
   1c7e0: f940140f     	ldr	x15, [x0, #0x28]
   1c7e4: 937ffdd0     	asr	x16, x14, #63
   1c7e8: d37ffe10     	lsr	x16, x16, #63
   1c7ec: 8b1001ce     	add	x14, x14, x16
   1c7f0: 9341fdce     	asr	x14, x14, #1
   1c7f4: 8b0d01ce     	add	x14, x14, x13
   1c7f8: 8b0e11ef     	add	x15, x15, x14, lsl #4
   1c7fc: f94001ef     	ldr	x15, [x15]
   1c800: eb0201ff     	cmp	x15, x2
   1c804: 54fffe6a     	b.ge	0x1c7d0 <_stogir.allocation.free-decision-for-class+0x58>
   1c808: 910005cd     	add	x13, x14, #0x1
   1c80c: 17fffff2     	b	0x1c7d4 <_stogir.allocation.free-decision-for-class+0x5c>
   1c810: f940052c     	ldr	x12, [x9, #0x8]
   1c814: eb0c01bf     	cmp	x13, x12
   1c818: 540001ea     	b.ge	0x1c854 <_stogir.allocation.free-decision-for-class+0xdc>
   1c81c: f940140c     	ldr	x12, [x0, #0x28]
   1c820: 8b0d118e     	add	x14, x12, x13, lsl #4
   1c824: f94001ce     	ldr	x14, [x14]
   1c828: eb0201df     	cmp	x14, x2
   1c82c: 54000141     	b.ne	0x1c854 <_stogir.allocation.free-decision-for-class+0xdc>
   1c830: 8b0d118e     	add	x14, x12, x13, lsl #4
   1c834: f94005ce     	ldr	x14, [x14, #0x8]
   1c838: 93407dce     	sxtw	x14, w14
   1c83c: f10009df     	cmp	x14, #0x2
   1c840: 540000a1     	b.ne	0x1c854 <_stogir.allocation.free-decision-for-class+0xdc>
   1c844: 8b0d118c     	add	x12, x12, x13, lsl #4
   1c848: f940058c     	ldr	x12, [x12, #0x8]
   1c84c: 9360fd8c     	asr	x12, x12, #32
   1c850: 14000002     	b	0x1c858 <_stogir.allocation.free-decision-for-class+0xe0>
   1c854: 92e0000c     	movn	x12, #0x0, lsl #48
   1c858: f940040d     	ldr	x13, [x0, #0x8]
   1c85c: f10001bf     	cmp	x13, #0x0
   1c860: 54000061     	b.ne	0x1c86c <_stogir.allocation.free-decision-for-class+0xf4>
   1c864: aa0203ed     	mov	x13, x2
   1c868: 14000005     	b	0x1c87c <_stogir.allocation.free-decision-for-class+0x104>
   1c86c: f940000e     	ldr	x14, [x0]
   1c870: d10005ad     	sub	x13, x13, #0x1
   1c874: 8b0d11cd     	add	x13, x14, x13, lsl #4
   1c878: f94005ad     	ldr	x13, [x13, #0x8]
   1c87c: 910003ee     	mov	x14, sp
   1c880: d10083ff     	sub	sp, sp, #0x20
   1c884: 910003ef     	mov	x15, sp
   1c888: d10083ff     	sub	sp, sp, #0x20
   1c88c: 910003f3     	mov	x19, sp
   1c890: d2e00011     	movz	x17, #0x0, lsl #48
   1c894: f9000271     	str	x17, [x19]
   1c898: d2e00011     	movz	x17, #0x0, lsl #48
   1c89c: f9000671     	str	x17, [x19, #0x8]
   1c8a0: d2e00011     	movz	x17, #0x0, lsl #48
   1c8a4: f9000a71     	str	x17, [x19, #0x10]
   1c8a8: 12a00011     	movn	w17, #0x0, lsl #16
   1c8ac: b9000271     	str	w17, [x19]
   1c8b0: 92f00011     	mov	x17, #0x7fffffffffffffff ; =9223372036854775807
   1c8b4: f9000671     	str	x17, [x19, #0x8]
   1c8b8: 92f00011     	mov	x17, #0x7fffffffffffffff ; =9223372036854775807
   1c8bc: f9000a71     	str	x17, [x19, #0x10]
   1c8c0: f9400273     	ldr	x19, [x19]
   1c8c4: f90001f3     	str	x19, [x15]
   1c8c8: 92f00011     	mov	x17, #0x7fffffffffffffff ; =9223372036854775807
   1c8cc: f90005f1     	str	x17, [x15, #0x8]
   1c8d0: 92f00011     	mov	x17, #0x7fffffffffffffff ; =9223372036854775807
   1c8d4: f90009f1     	str	x17, [x15, #0x10]
   1c8d8: d2e00013     	movz	x19, #0x0, lsl #48
   1c8dc: d2e00014     	movz	x20, #0x0, lsl #48
   1c8e0: d2e00015     	movz	x21, #0x0, lsl #48
   1c8e4: 14000006     	b	0x1c8fc <_stogir.allocation.free-decision-for-class+0x184>
   1c8e8: d360fed5     	lsr	x21, x22, #32
   1c8ec: b90001f5     	str	w21, [x15]
   1c8f0: f90005f7     	str	x23, [x15, #0x8]
   1c8f4: d2800035     	mov	x21, #0x1               ; =1
   1c8f8: 91000673     	add	x19, x19, #0x1
   1c8fc: f9400536     	ldr	x22, [x9, #0x8]
   1c900: eb16027f     	cmp	x19, x22
   1c904: 5400034a     	b.ge	0x1c96c <_stogir.allocation.free-decision-for-class+0x1f4>
   1c908: f100029f     	cmp	x20, #0x0
   1c90c: 54000301     	b.ne	0x1c96c <_stogir.allocation.free-decision-for-class+0x1f4>
   1c910: f9401416     	ldr	x22, [x0, #0x28]
   1c914: 8b1312d6     	add	x22, x22, x19, lsl #4
   1c918: f94002d7     	ldr	x23, [x22]
   1c91c: f94006d6     	ldr	x22, [x22, #0x8]
   1c920: eb0202ff     	cmp	x23, x2
   1c924: 54fffeab     	b.lt	0x1c8f8 <_stogir.allocation.free-decision-for-class+0x180>
   1c928: 2a1f02d8     	orr	w24, w22, wzr
   1c92c: 93407f18     	sxtw	x24, w24
   1c930: f1000b1f     	cmp	x24, #0x2
   1c934: 54fffe21     	b.ne	0x1c8f8 <_stogir.allocation.free-decision-for-class+0x180>
   1c938: 92f00011     	mov	x17, #0x7fffffffffffffff ; =9223372036854775807
   1c93c: eb1102ff     	cmp	x23, x17
   1c940: 54fffdc0     	b.eq	0x1c8f8 <_stogir.allocation.free-decision-for-class+0x180>
   1c944: f10002bf     	cmp	x21, #0x0
   1c948: 54fffd00     	b.eq	0x1c8e8 <_stogir.allocation.free-decision-for-class+0x170>
   1c94c: 9360fed6     	asr	x22, x22, #32
   1c950: b94001f8     	ldr	w24, [x15]
   1c954: 93407f18     	sxtw	x24, w24
   1c958: eb1802df     	cmp	x22, x24
   1c95c: 54000060     	b.eq	0x1c968 <_stogir.allocation.free-decision-for-class+0x1f0>
   1c960: f90009f7     	str	x23, [x15, #0x10]
   1c964: d2800034     	mov	x20, #0x1               ; =1
   1c968: 17ffffe4     	b	0x1c8f8 <_stogir.allocation.free-decision-for-class+0x180>
   1c96c: 8a030163     	and	x3, x11, x3
   1c970: 93407d8c     	sxtw	x12, w12
   1c974: f94001e9     	ldr	x9, [x15]
   1c978: f94005eb     	ldr	x11, [x15, #0x8]
   1c97c: f94009ef     	ldr	x15, [x15, #0x10]
   1c980: 910001df     	mov	sp, x14
   1c984: 910083b0     	add	x16, x29, #0x20
   1c988: d2e00011     	movz	x17, #0x0, lsl #48
   1c98c: f9000211     	str	x17, [x16]
   1c990: 910083b0     	add	x16, x29, #0x20
   1c994: d2e00011     	movz	x17, #0x0, lsl #48
   1c998: f9000611     	str	x17, [x16, #0x8]
   1c99c: 910083b0     	add	x16, x29, #0x20
   1c9a0: 12a00011     	movn	w17, #0x0, lsl #16
   1c9a4: b9000211     	str	w17, [x16]
   1c9a8: 910083b0     	add	x16, x29, #0x20
   1c9ac: f9000602     	str	x2, [x16, #0x8]
   1c9b0: 910083b0     	add	x16, x29, #0x20
   1c9b4: f940020e     	ldr	x14, [x16]
   1c9b8: 9100c3b0     	add	x16, x29, #0x30
   1c9bc: d2e00011     	movz	x17, #0x0, lsl #48
   1c9c0: f9000211     	str	x17, [x16]
   1c9c4: 9100c3b0     	add	x16, x29, #0x30
   1c9c8: d2e00011     	movz	x17, #0x0, lsl #48
   1c9cc: f9000611     	str	x17, [x16, #0x8]
   1c9d0: 9100c3b0     	add	x16, x29, #0x30
   1c9d4: 12a00011     	movn	w17, #0x0, lsl #16
   1c9d8: b9000211     	str	w17, [x16]
   1c9dc: 9100c3b0     	add	x16, x29, #0x30
   1c9e0: f9000602     	str	x2, [x16, #0x8]
   1c9e4: 9100c3b0     	add	x16, x29, #0x30
   1c9e8: f9400213     	ldr	x19, [x16]
   1c9ec: 910103b0     	add	x16, x29, #0x40
   1c9f0: d2e00011     	movz	x17, #0x0, lsl #48
   1c9f4: f9000211     	str	x17, [x16]
   1c9f8: 910103b0     	add	x16, x29, #0x40
   1c9fc: d2e00011     	movz	x17, #0x0, lsl #48
   1ca00: f9000611     	str	x17, [x16, #0x8]
   1ca04: 910103b0     	add	x16, x29, #0x40
   1ca08: 12a00011     	movn	w17, #0x0, lsl #16
   1ca0c: b9000211     	str	w17, [x16]
   1ca10: 910103b0     	add	x16, x29, #0x40
   1ca14: f9000602     	str	x2, [x16, #0x8]
   1ca18: 910103b0     	add	x16, x29, #0x40
   1ca1c: f9400214     	ldr	x20, [x16]
   1ca20: f100019f     	cmp	x12, #0x0
   1ca24: 5400010b     	b.lt	0x1ca44 <_stogir.allocation.free-decision-for-class+0x2cc>
   1ca28: f101019f     	cmp	x12, #0x40
   1ca2c: 540000aa     	b.ge	0x1ca40 <_stogir.allocation.free-decision-for-class+0x2c8>
   1ca30: d2800030     	mov	x16, #0x1               ; =1
   1ca34: 9acc220c     	lsl	x12, x16, x12
   1ca38: 8a030183     	and	x3, x12, x3
   1ca3c: 14000002     	b	0x1ca44 <_stogir.allocation.free-decision-for-class+0x2cc>
   1ca40: d2e00003     	movz	x3, #0x0, lsl #48
   1ca44: 93407c84     	sxtw	x4, w4
   1ca48: 93407d29     	sxtw	x9, w9
   1ca4c: aa0203f6     	mov	x22, x2
   1ca50: aa0203ec     	mov	x12, x2
   1ca54: aa0203f5     	mov	x21, x2
   1ca58: 14000057     	b	0x1cbb4 <_stogir.allocation.free-decision-for-class+0x43c>
   1ca5c: aa0b03f9     	mov	x25, x11
   1ca60: eb1902ff     	cmp	x23, x25
   1ca64: 9a99d2f7     	csel	x23, x23, x25, le
   1ca68: eb0d02ff     	cmp	x23, x13
   1ca6c: 5400100a     	b.ge	0x1cc6c <_stogir.allocation.free-decision-for-class+0x4f4>
   1ca70: f90043a1     	str	x1, [x29, #0x80]
   1ca74: aa0703fb     	mov	x27, x7
   1ca78: d2e00019     	movz	x25, #0x0, lsl #48
   1ca7c: 14000002     	b	0x1ca84 <_stogir.allocation.free-decision-for-class+0x30c>
   1ca80: aa1c03fb     	mov	x27, x28
   1ca84: eb1b033f     	cmp	x25, x27
   1ca88: 5400018a     	b.ge	0x1cab8 <_stogir.allocation.free-decision-for-class+0x340>
   1ca8c: cb19037c     	sub	x28, x27, x25
   1ca90: 937fff90     	asr	x16, x28, #63
   1ca94: d37ffe10     	lsr	x16, x16, #63
   1ca98: 8b10039c     	add	x28, x28, x16
   1ca9c: 9341ff9c     	asr	x28, x28, #1
   1caa0: 8b19039c     	add	x28, x28, x25
   1caa4: f87c78c1     	ldr	x1, [x6, x28, lsl #3]
   1caa8: eb17003f     	cmp	x1, x23
   1caac: 54fffeaa     	b.ge	0x1ca80 <_stogir.allocation.free-decision-for-class+0x308>
   1cab0: 91000799     	add	x25, x28, #0x1
   1cab4: 17fffff4     	b	0x1ca84 <_stogir.allocation.free-decision-for-class+0x30c>
   1cab8: eb07033f     	cmp	x25, x7
   1cabc: 5400008a     	b.ge	0x1cacc <_stogir.allocation.free-decision-for-class+0x354>
   1cac0: f87978c1     	ldr	x1, [x6, x25, lsl #3]
   1cac4: eb17003f     	cmp	x1, x23
   1cac8: 540000a0     	b.eq	0x1cadc <_stogir.allocation.free-decision-for-class+0x364>
   1cacc: aa1f02e1     	orr	x1, x23, xzr
   1cad0: 9ac50c30     	sdiv	x16, x1, x5
   1cad4: 9b058601     	msub	x1, x16, x5, x1
   1cad8: cb0102f7     	sub	x23, x23, x1
   1cadc: eb1602ff     	cmp	x23, x22
   1cae0: 540001cd     	b.le	0x1cb18 <_stogir.allocation.free-decision-for-class+0x3a0>
   1cae4: 910143b0     	add	x16, x29, #0x50
   1cae8: d2e00011     	movz	x17, #0x0, lsl #48
   1caec: f9000211     	str	x17, [x16]
   1caf0: 910143b0     	add	x16, x29, #0x50
   1caf4: d2e00011     	movz	x17, #0x0, lsl #48
   1caf8: f9000611     	str	x17, [x16, #0x8]
   1cafc: 910143b0     	add	x16, x29, #0x50
   1cb00: b9000218     	str	w24, [x16]
   1cb04: 910143b0     	add	x16, x29, #0x50
   1cb08: f9000617     	str	x23, [x16, #0x8]
   1cb0c: 910143b0     	add	x16, x29, #0x50
   1cb10: f940020e     	ldr	x14, [x16]
   1cb14: aa1703f6     	mov	x22, x23
   1cb18: eb0202ff     	cmp	x23, x2
   1cb1c: 5400046d     	b.le	0x1cba8 <_stogir.allocation.free-decision-for-class+0x430>
   1cb20: eb0d02ff     	cmp	x23, x13
   1cb24: 5400042b     	b.lt	0x1cba8 <_stogir.allocation.free-decision-for-class+0x430>
   1cb28: b9407001     	ldr	w1, [x0, #0x70]
   1cb2c: 93407c21     	sxtw	x1, w1
   1cb30: eb01035f     	cmp	x26, x1
   1cb34: 540001c1     	b.ne	0x1cb6c <_stogir.allocation.free-decision-for-class+0x3f4>
   1cb38: 910183b0     	add	x16, x29, #0x60
   1cb3c: d2e00011     	movz	x17, #0x0, lsl #48
   1cb40: f9000211     	str	x17, [x16]
   1cb44: 910183b0     	add	x16, x29, #0x60
   1cb48: d2e00011     	movz	x17, #0x0, lsl #48
   1cb4c: f9000611     	str	x17, [x16, #0x8]
   1cb50: 910183b0     	add	x16, x29, #0x60
   1cb54: b9000218     	str	w24, [x16]
   1cb58: 910183b0     	add	x16, x29, #0x60
   1cb5c: f9000617     	str	x23, [x16, #0x8]
   1cb60: 910183b0     	add	x16, x29, #0x60
   1cb64: f9400213     	ldr	x19, [x16]
   1cb68: aa1703ec     	mov	x12, x23
   1cb6c: eb04035f     	cmp	x26, x4
   1cb70: 540001c1     	b.ne	0x1cba8 <_stogir.allocation.free-decision-for-class+0x430>
   1cb74: 9101c3b0     	add	x16, x29, #0x70
   1cb78: d2e00011     	movz	x17, #0x0, lsl #48
   1cb7c: f9000211     	str	x17, [x16]
   1cb80: 9101c3b0     	add	x16, x29, #0x70
   1cb84: d2e00011     	movz	x17, #0x0, lsl #48
   1cb88: f9000611     	str	x17, [x16, #0x8]
   1cb8c: 9101c3b0     	add	x16, x29, #0x70
   1cb90: b9000218     	str	w24, [x16]
   1cb94: 9101c3b0     	add	x16, x29, #0x70
   1cb98: f9000617     	str	x23, [x16, #0x8]
   1cb9c: 9101c3b0     	add	x16, x29, #0x70
   1cba0: f9400214     	ldr	x20, [x16]
   1cba4: aa1703f5     	mov	x21, x23
   1cba8: d1000461     	sub	x1, x3, #0x1
   1cbac: 8a030023     	and	x3, x1, x3
   1cbb0: f94043a1     	ldr	x1, [x29, #0x80]
   1cbb4: f100007f     	cmp	x3, #0x0
   1cbb8: 540001a0     	b.eq	0x1cbec <_stogir.allocation.free-decision-for-class+0x474>
   1cbbc: dac00077     	rbit	x23, x3
   1cbc0: dac012f7     	clz	x23, x23
   1cbc4: eb0a02ff     	cmp	x23, x10
   1cbc8: 5400056a     	b.ge	0x1cc74 <_stogir.allocation.free-decision-for-class+0x4fc>
   1cbcc: 2a1f02f8     	orr	w24, w23, wzr
   1cbd0: f9400039     	ldr	x25, [x1]
   1cbd4: 93407f1a     	sxtw	x26, w24
   1cbd8: f8777b37     	ldr	x23, [x25, x23, lsl #3]
   1cbdc: eb09035f     	cmp	x26, x9
   1cbe0: 54fff3e1     	b.ne	0x1ca5c <_stogir.allocation.free-decision-for-class+0x2e4>
   1cbe4: aa0f03f9     	mov	x25, x15
   1cbe8: 17ffff9e     	b	0x1ca60 <_stogir.allocation.free-decision-for-class+0x2e8>
   1cbec: 2a1f0260     	orr	w0, w19, wzr
   1cbf0: 93407c00     	sxtw	x0, w0
   1cbf4: f100001f     	cmp	x0, #0x0
   1cbf8: 5400008b     	b.lt	0x1cc08 <_stogir.allocation.free-decision-for-class+0x490>
   1cbfc: aa1303ee     	mov	x14, x19
   1cc00: aa0c03f6     	mov	x22, x12
   1cc04: 14000007     	b	0x1cc20 <_stogir.allocation.free-decision-for-class+0x4a8>
   1cc08: 2a1f0280     	orr	w0, w20, wzr
   1cc0c: 93407c00     	sxtw	x0, w0
   1cc10: f100001f     	cmp	x0, #0x0
   1cc14: 5400006b     	b.lt	0x1cc20 <_stogir.allocation.free-decision-for-class+0x4a8>
   1cc18: aa1403ee     	mov	x14, x20
   1cc1c: aa1503f6     	mov	x22, x21
   1cc20: f900010e     	str	x14, [x8]
   1cc24: f9000516     	str	x22, [x8, #0x8]
   1cc28: f9400ba0     	ldr	x0, [x29, #0x10]
   1cc2c: f9400fa1     	ldr	x1, [x29, #0x18]
   1cc30: d10003bf     	sub	sp, x29, #0x0
   1cc34: f94047f3     	ldr	x19, [sp, #0x88]
   1cc38: f9404bf4     	ldr	x20, [sp, #0x90]
   1cc3c: f9404ff5     	ldr	x21, [sp, #0x98]
   1cc40: f94053f6     	ldr	x22, [sp, #0xa0]
   1cc44: f94057f7     	ldr	x23, [sp, #0xa8]
   1cc48: f9405bf8     	ldr	x24, [sp, #0xb0]
   1cc4c: f9405ff9     	ldr	x25, [sp, #0xb8]
   1cc50: f94063fa     	ldr	x26, [sp, #0xc0]
   1cc54: f94067fb     	ldr	x27, [sp, #0xc8]
   1cc58: f9406bfc     	ldr	x28, [sp, #0xd0]
   1cc5c: f94003fd     	ldr	x29, [sp]
   1cc60: f94007fe     	ldr	x30, [sp, #0x8]
   1cc64: 910383ff     	add	sp, sp, #0xe0
   1cc68: d65f03c0     	ret
   1cc6c: f90043a1     	str	x1, [x29, #0x80]
   1cc70: 17ffff9b     	b	0x1cadc <_stogir.allocation.free-decision-for-class+0x364>
   1cc74: f90043a1     	str	x1, [x29, #0x80]
   1cc78: 17ffffcc     	b	0x1cba8 <_stogir.allocation.free-decision-for-class+0x430>
