
build/control-cleanup-comparison/emitter/stogir-before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000015a4 <_stogir.graph.operand>:
    15a4: 93407c21     	sxtw	x1, w1
    15a8: f100003f     	cmp	x1, #0x0
    15ac: 540001ed     	b.le	0x15e8 <_stogir.graph.operand+0x44>
    15b0: 9101e003     	add	x3, x0, #0x78
    15b4: f9400404     	ldr	x4, [x0, #0x8]
    15b8: eb04003f     	cmp	x1, x4
    15bc: 5400026a     	b.ge	0x1608 <_stogir.graph.operand+0x64>
    15c0: f9400463     	ldr	x3, [x3, #0x8]
    15c4: eb03003f     	cmp	x1, x3
    15c8: 540001ca     	b.ge	0x1600 <_stogir.graph.operand+0x5c>
    15cc: f9403c03     	ldr	x3, [x0, #0x78]
    15d0: b8617863     	ldr	w3, [x3, x1, lsl #2]
    15d4: 93407c63     	sxtw	x3, w3
    15d8: f100007f     	cmp	x3, #0x0
    15dc: 1a9fb7e3     	cset	w3, ge
    15e0: d3401c63     	ubfx	x3, x3, #0, #8
    15e4: 14000008     	b	0x1604 <_stogir.graph.operand+0x60>
    15e8: d2e00000     	movz	x0, #0x0, lsl #48
    15ec: d2e00001     	movz	x1, #0x0, lsl #48
    15f0: d65f03c0     	ret
    15f4: d2e00000     	movz	x0, #0x0, lsl #48
    15f8: d2e00001     	movz	x1, #0x0, lsl #48
    15fc: 17fffffd     	b	0x15f0 <_stogir.graph.operand+0x4c>
    1600: d2e00003     	movz	x3, #0x0, lsl #48
    1604: 14000002     	b	0x160c <_stogir.graph.operand+0x68>
    1608: d2e00003     	movz	x3, #0x0, lsl #48
    160c: f100007f     	cmp	x3, #0x0
    1610: 54fffec0     	b.eq	0x15e8 <_stogir.graph.operand+0x44>
    1614: 93407c42     	sxtw	x2, w2
    1618: f100045f     	cmp	x2, #0x1
    161c: 54fffecb     	b.lt	0x15f4 <_stogir.graph.operand+0x50>
    1620: f9403c03     	ldr	x3, [x0, #0x78]
    1624: b8617863     	ldr	w3, [x3, x1, lsl #2]
    1628: 93407c63     	sxtw	x3, w3
    162c: eb03005f     	cmp	x2, x3
    1630: 54fffe2c     	b.gt	0x15f4 <_stogir.graph.operand+0x50>
    1634: f9400000     	ldr	x0, [x0]
    1638: 937ffc50     	asr	x16, x2, #63
    163c: d37efe10     	lsr	x16, x16, #62
    1640: 8b100043     	add	x3, x2, x16
    1644: 9342fc63     	asr	x3, x3, #2
    1648: 937ffc50     	asr	x16, x2, #63
    164c: d37efe10     	lsr	x16, x16, #62
    1650: 8b100042     	add	x2, x2, x16
    1654: 92400442     	and	x2, x2, #0x3
    1658: cb100042     	sub	x2, x2, x16
    165c: 8b010061     	add	x1, x3, x1
    1660: 8b011000     	add	x0, x0, x1, lsl #4
    1664: b8627800     	ldr	w0, [x0, x2, lsl #2]
    1668: 93407c00     	sxtw	x0, w0
    166c: 92407c01     	and	x1, x0, #0xffffffff
    1670: d2800020     	mov	x0, #0x1                ; =1
    1674: 17ffffe2     	b	0x15fc <_stogir.graph.operand+0x58>
