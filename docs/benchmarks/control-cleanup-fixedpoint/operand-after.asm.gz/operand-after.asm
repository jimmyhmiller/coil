
build/control-cleanup-comparison/emitter/stogir-after.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000015a4 <_stogir.graph.operand>:
    15a4: 93407c21     	sxtw	x1, w1
    15a8: f100003f     	cmp	x1, #0x0
    15ac: 540004cd     	b.le	0x1644 <_stogir.graph.operand+0xa0>
    15b0: f9400403     	ldr	x3, [x0, #0x8]
    15b4: eb03003f     	cmp	x1, x3
    15b8: 5400046a     	b.ge	0x1644 <_stogir.graph.operand+0xa0>
    15bc: 9101e003     	add	x3, x0, #0x78
    15c0: f9400463     	ldr	x3, [x3, #0x8]
    15c4: eb03003f     	cmp	x1, x3
    15c8: 540003ea     	b.ge	0x1644 <_stogir.graph.operand+0xa0>
    15cc: f9403c03     	ldr	x3, [x0, #0x78]
    15d0: b8617863     	ldr	w3, [x3, x1, lsl #2]
    15d4: 93407c63     	sxtw	x3, w3
    15d8: f100007f     	cmp	x3, #0x0
    15dc: 5400034b     	b.lt	0x1644 <_stogir.graph.operand+0xa0>
    15e0: 93407c42     	sxtw	x2, w2
    15e4: f100045f     	cmp	x2, #0x1
    15e8: 5400034b     	b.lt	0x1650 <_stogir.graph.operand+0xac>
    15ec: f9403c03     	ldr	x3, [x0, #0x78]
    15f0: b8617863     	ldr	w3, [x3, x1, lsl #2]
    15f4: 93407c63     	sxtw	x3, w3
    15f8: eb03005f     	cmp	x2, x3
    15fc: 540002ac     	b.gt	0x1650 <_stogir.graph.operand+0xac>
    1600: f9400000     	ldr	x0, [x0]
    1604: 937ffc50     	asr	x16, x2, #63
    1608: d37efe10     	lsr	x16, x16, #62
    160c: 8b100043     	add	x3, x2, x16
    1610: 9342fc63     	asr	x3, x3, #2
    1614: 937ffc50     	asr	x16, x2, #63
    1618: d37efe10     	lsr	x16, x16, #62
    161c: 8b100042     	add	x2, x2, x16
    1620: 92400442     	and	x2, x2, #0x3
    1624: cb100042     	sub	x2, x2, x16
    1628: 8b010061     	add	x1, x3, x1
    162c: 8b011000     	add	x0, x0, x1, lsl #4
    1630: b8627800     	ldr	w0, [x0, x2, lsl #2]
    1634: 93407c00     	sxtw	x0, w0
    1638: 92407c01     	and	x1, x0, #0xffffffff
    163c: d2800020     	mov	x0, #0x1                ; =1
    1640: 14000006     	b	0x1658 <_stogir.graph.operand+0xb4>
    1644: d2e00000     	movz	x0, #0x0, lsl #48
    1648: d2e00001     	movz	x1, #0x0, lsl #48
    164c: d65f03c0     	ret
    1650: d2e00000     	movz	x0, #0x0, lsl #48
    1654: d2e00001     	movz	x1, #0x0, lsl #48
    1658: 17fffffd     	b	0x164c <_stogir.graph.operand+0xa8>
