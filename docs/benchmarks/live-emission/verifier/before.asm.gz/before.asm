
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-live-emission/build/live-snapshot-verifier/before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x134 <_stogir.verify.integer-operations-target+0x84>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x188 <_stogir.verify.integer-operations-target+0xd8>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, #0x1                ; =1
     130:      	b	0x160 <_stogir.verify.integer-operations-target+0xb0>
     134:      	lsr	w21, w21, #0
     138:      	add	x8, sp, #0x30
     13c:      	mov	x0, x20
     140:      	mov	w1, w21
     144:      	bl	0x144 <_stogir.verify.integer-operations-target+0x94>
		0000000000000144:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     148:      	add	x16, sp, #0x30
     14c:      	ldr	x2, [x16]
     150:      	add	x16, sp, #0x30
     154:      	ldr	x1, [x16, #0x8]
     158:      	add	x16, sp, #0x30
     15c:      	ldr	x0, [x16, #0x10]
     160:      	str	x2, [x19]
     164:      	str	x1, [x19, #0x8]
     168:      	str	x0, [x19, #0x10]
     16c:      	ldr	x19, [sp, #0x50]
     170:      	ldr	x20, [sp, #0x58]
     174:      	ldr	x21, [sp, #0x60]
     178:      	ldr	x29, [sp]
     17c:      	ldr	x30, [sp, #0x8]
     180:      	add	sp, sp, #0x70
     184:      	ret
     188:      	brk	#0
     18c:      	b	0x188 <_stogir.verify.integer-operations-target+0xd8>

0000000000000190 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     190:      	ldr	x0, [x0, #0x8]
     194:      	ret

0000000000000198 <_stogir.verify.structure>:
     198:      	sub	sp, sp, #0x1a0
     19c:      	str	x29, [sp, #0x10]
     1a0:      	str	x30, [sp, #0x18]
     1a4:      	add	x29, sp, #0x10
     1a8:      	str	x19, [sp, #0x150]
     1ac:      	str	x20, [sp, #0x158]
     1b0:      	str	x21, [sp, #0x160]
     1b4:      	str	x22, [sp, #0x168]
     1b8:      	str	x23, [sp, #0x170]
     1bc:      	str	x24, [sp, #0x178]
     1c0:      	str	x25, [sp, #0x180]
     1c4:      	str	x26, [sp, #0x188]
     1c8:      	str	x27, [sp, #0x190]
     1cc:      	str	x28, [sp, #0x198]
     1d0:      	add	x1, x0, #0x78
     1d4:      	ldr	x2, [x0, #0x8]
     1d8:      	ldr	x1, [x1, #0x8]
     1dc:      	cmp	x2, x1
     1e0:      	b.ne	0x218 <_stogir.verify.structure+0x80>
     1e4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001e4:  ARM64_RELOC_PAGE21	l_stogir.304
     1e8:      	ldr	x16, [x16]
		00000000000001e8:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1ec:      	orr	x19, x16, xzr
     1f0:      	movz	x20, #0x0, lsl #48
     1f4:      	b	0x228 <_stogir.verify.structure+0x90>
     1f8:      	ldr	x1, [sp, #0x120]
     1fc:      	ldr	x6, [sp, #0x128]
     200:      	add	x6, x1, x6
     204:      	ldr	x1, [sp, #0xc0]
     208:      	add	x1, x1, #0x1
     20c:      	lsr	w1, w1, #0
     210:      	sxtw	x1, w1
     214:      	b	0x2f4 <_stogir.verify.structure+0x15c>
     218:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000218:  ARM64_RELOC_PAGE21	l_stogir.305
     21c:      	ldr	x16, [x16]
		000000000000021c:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     220:      	orr	x19, x16, xzr
     224:      	mov	x20, #0x2c              ; =44
     228:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000228:  ARM64_RELOC_PAGE21	l_stogir.306
     22c:      	ldr	x16, [x16]
		000000000000022c:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     230:      	orr	x21, x16, xzr
     234:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000234:  ARM64_RELOC_PAGE21	l_stogir.307
     238:      	ldr	x16, [x16]
		0000000000000238:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     23c:      	orr	x22, x16, xzr
     240:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000240:  ARM64_RELOC_PAGE21	l_stogir.308
     244:      	ldr	x16, [x16]
		0000000000000244:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     248:      	orr	x23, x16, xzr
     24c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000024c:  ARM64_RELOC_PAGE21	l_stogir.309
     250:      	ldr	x16, [x16]
		0000000000000250:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     254:      	orr	x24, x16, xzr
     258:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000258:  ARM64_RELOC_PAGE21	l_stogir.310
     25c:      	ldr	x16, [x16]
		000000000000025c:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     260:      	orr	x25, x16, xzr
     264:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000264:  ARM64_RELOC_PAGE21	l_stogir.311
     268:      	ldr	x16, [x16]
		0000000000000268:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     26c:      	orr	x26, x16, xzr
     270:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000270:  ARM64_RELOC_PAGE21	l_stogir.312
     274:      	ldr	x16, [x16]
		0000000000000274:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     278:      	orr	x27, x16, xzr
     27c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000027c:  ARM64_RELOC_PAGE21	l_stogir.313
     280:      	ldr	x16, [x16]
		0000000000000280:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     284:      	orr	x28, x16, xzr
     288:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000288:  ARM64_RELOC_PAGE21	l_stogir.314
     28c:      	ldr	x16, [x16]
		000000000000028c:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     290:      	orr	x1, x16, xzr
     294:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000294:  ARM64_RELOC_PAGE21	l_stogir.315
     298:      	ldr	x16, [x16]
		0000000000000298:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     29c:      	orr	x2, x16, xzr
     2a0:      	add	x3, x0, #0x110
     2a4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002a4:  ARM64_RELOC_PAGE21	l_stogir.316
     2a8:      	ldr	x16, [x16]
		00000000000002a8:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     2ac:      	orr	x4, x16, xzr
     2b0:      	add	x5, x0, #0x78
     2b4:      	add	x6, x0, #0x28
     2b8:      	add	x7, x0, #0x50
     2bc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002bc:  ARM64_RELOC_PAGE21	l_stogir.316
     2c0:      	ldr	x16, [x16]
		00000000000002c0:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     2c4:      	orr	x9, x16, xzr
     2c8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002c8:  ARM64_RELOC_PAGE21	l_stogir.317
     2cc:      	ldr	x16, [x16]
		00000000000002cc:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     2d0:      	orr	x10, x16, xzr
     2d4:      	add	x11, x3, #0x28
     2d8:      	mov	x12, #0x1               ; =1
     2dc:      	movz	x13, #0x0, lsl #48
     2e0:      	b	0x3b8 <_stogir.verify.structure+0x220>
     2e4:      	ldr	x17, [sp, #0x58]
     2e8:      	str	x17, [sp, #0xa8]
     2ec:      	mov	x16, #0x16              ; =22
     2f0:      	str	x16, [sp, #0x118]
     2f4:      	b	0x35c <_stogir.verify.structure+0x1c4>
     2f8:      	str	x8, [sp, #0xa0]
     2fc:      	str	x21, [sp, #0x40]
     300:      	str	x22, [sp, #0x58]
     304:      	str	x23, [sp, #0x60]
     308:      	mov	x23, x0
     30c:      	str	x24, [sp, #0x78]
     310:      	str	x25, [sp, #0x80]
     314:      	str	x26, [sp, #0x88]
     318:      	str	x27, [sp, #0x90]
     31c:      	str	x28, [sp, #0x98]
     320:      	str	x1, [sp, #0x68]
     324:      	mov	x1, x13
     328:      	str	x2, [sp, #0x70]
     32c:      	str	x4, [sp, #0x100]
     330:      	mov	x0, x11
     334:      	mov	x2, x5
     338:      	mov	x4, x6
     33c:      	mov	x6, x12
     340:      	mov	x5, x7
     344:      	str	x9, [sp, #0xe8]
     348:      	str	x10, [sp, #0xf8]
     34c:      	ldr	x17, [sp, #0x40]
     350:      	str	x17, [sp, #0xa8]
     354:      	mov	x16, #0x23              ; =35
     358:      	str	x16, [sp, #0x118]
     35c:      	ldr	x8, [sp, #0xa0]
     360:      	ldr	x21, [sp, #0x40]
     364:      	ldr	x22, [sp, #0x58]
     368:      	ldr	x24, [sp, #0x78]
     36c:      	ldr	x25, [sp, #0x80]
     370:      	ldr	x26, [sp, #0x88]
     374:      	ldr	x27, [sp, #0x90]
     378:      	ldr	x28, [sp, #0x98]
     37c:      	mov	x11, x0
     380:      	mov	x0, x23
     384:      	ldr	x23, [sp, #0x60]
     388:      	mov	x7, x5
     38c:      	mov	x5, x2
     390:      	ldr	x2, [sp, #0x70]
     394:      	ldr	x9, [sp, #0xe8]
     398:      	ldr	x10, [sp, #0xf8]
     39c:      	mov	x12, x6
     3a0:      	mov	x6, x4
     3a4:      	ldr	x4, [sp, #0x100]
     3a8:      	mov	x13, x1
     3ac:      	ldr	x1, [sp, #0x68]
     3b0:      	ldr	x19, [sp, #0xa8]
     3b4:      	ldr	x20, [sp, #0x118]
     3b8:      	cmp	x20, #0x0
     3bc:      	b.ne	0xc00 <_stogir.verify.structure+0xa68>
     3c0:      	ldr	x14, [x0, #0x8]
     3c4:      	cmp	x12, x14
     3c8:      	b.ge	0xc14 <_stogir.verify.structure+0xa7c>
     3cc:      	ldr	x14, [x0]
     3d0:      	add	x14, x14, x12, lsl #4
     3d4:      	ldr	x14, [x14]
     3d8:      	ldr	x15, [x0, #0x78]
     3dc:      	add	x15, x15, x12, lsl #2
     3e0:      	ldr	w15, [x15]
     3e4:      	sxtw	x15, w15
     3e8:      	cmp	x15, #0x0
     3ec:      	b.lt	0x2f8 <_stogir.verify.structure+0x160>
     3f0:      	mov	x17, #0xffff            ; =65535
     3f4:      	cmp	x15, x17
     3f8:      	b.gt	0xc28 <_stogir.verify.structure+0xa90>
     3fc:      	str	x0, [sp, #0x30]
     400:      	uxtb	w0, w14
     404:      	str	w0, [sp, #0x38]
     408:      	str	x21, [sp, #0x40]
     40c:      	cmp	x0, #0x83
     410:      	cset	w21, lt
     414:      	uxtb	w16, w21
     418:      	cmp	w16, wzr
     41c:      	b.eq	0xc80 <_stogir.verify.structure+0xae8>
     420:      	lsr	w14, w14, #0
     424:      	str	x0, [sp, #0x48]
     428:      	ubfx	x0, x14, #8, #8
     42c:      	str	w0, [sp, #0x50]
     430:      	lsr	w0, w0, #0
     434:      	str	x8, [sp, #0xa0]
     438:      	str	x1, [sp, #0x68]
     43c:      	str	x2, [sp, #0x70]
     440:      	str	x3, [sp, #0xd0]
     444:      	str	x5, [sp, #0xc8]
     448:      	str	x6, [sp, #0xb8]
     44c:      	str	x7, [sp, #0xb0]
     450:      	str	x9, [sp, #0xe8]
     454:      	str	x11, [sp, #0xd8]
     458:      	str	x13, [sp, #0xc0]
     45c:      	str	x22, [sp, #0x58]
     460:      	ldr	w22, [sp, #0x50]
     464:      	str	x23, [sp, #0x60]
     468:      	ldr	x23, [sp, #0x30]
     46c:      	str	x24, [sp, #0x78]
     470:      	ldr	w24, [sp, #0x38]
     474:      	str	x25, [sp, #0x80]
     478:      	mov	x25, x4
     47c:      	str	x26, [sp, #0x88]
     480:      	mov	x26, x15
     484:      	str	x27, [sp, #0x90]
     488:      	mov	x27, x12
     48c:      	str	x28, [sp, #0x98]
     490:      	ldr	x28, [sp, #0x48]
     494:      	str	x19, [sp, #0xa8]
     498:      	mov	x19, x10
     49c:      	str	w21, [sp, #0xe0]
     4a0:      	mov	x21, x14
     4a4:      	bl	0x4a4 <_stogir.verify.structure+0x30c>
		00000000000004a4:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     4a8:      	cmp	x0, #0x0
     4ac:      	b.eq	0xcd4 <_stogir.verify.structure+0xb3c>
     4b0:      	add	x0, x28, x19
     4b4:      	lsr	w24, w24, #0
     4b8:      	ldrsb	w0, [x0]
     4bc:      	sxtb	x0, w0
     4c0:      	cmp	x0, #0x0
     4c4:      	b.lt	0x958 <_stogir.verify.structure+0x7c0>
     4c8:      	mov	w0, w24
     4cc:      	bl	0x4cc <_stogir.verify.structure+0x334>
		00000000000004cc:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4d0:      	lsr	w0, w0, #0
     4d4:      	sxtw	x0, w0
     4d8:      	cmp	x26, x0
     4dc:      	b.eq	0x958 <_stogir.verify.structure+0x7c0>
     4e0:      	ldr	x3, [sp, #0xd0]
     4e4:      	str	x25, [sp, #0x100]
     4e8:      	ldr	x0, [sp, #0xd8]
     4ec:      	ldr	x2, [sp, #0xc8]
     4f0:      	ldr	x4, [sp, #0xb8]
     4f4:      	ldr	x5, [sp, #0xb0]
     4f8:      	str	x19, [sp, #0xf8]
     4fc:      	mov	x6, x27
     500:      	ldr	x1, [sp, #0xc0]
     504:      	ldr	x17, [sp, #0x60]
     508:      	str	x17, [sp, #0xa8]
     50c:      	mov	x16, #0x23              ; =35
     510:      	str	x16, [sp, #0x118]
     514:      	b	0x214 <_stogir.verify.structure+0x7c>
     518:      	ldr	x0, [sp, #0x118]
     51c:      	cmp	x0, #0x0
     520:      	b.ne	0xcfc <_stogir.verify.structure+0xb64>
     524:      	and	x1, x1, #0xffffffff
     528:      	movz	x2, #0x0, lsl #48
     52c:      	movz	x0, #0x0, lsl #48
     530:      	b	0x538 <_stogir.verify.structure+0x3a0>
     534:      	mov	x2, #0x1                ; =1
     538:      	ldr	x3, [sp, #0xa0]
     53c:      	str	x2, [x3]
     540:      	str	x1, [x3, #0x8]
     544:      	str	x0, [x3, #0x10]
     548:      	ldr	x19, [sp, #0x150]
     54c:      	ldr	x20, [sp, #0x158]
     550:      	ldr	x21, [sp, #0x160]
     554:      	ldr	x22, [sp, #0x168]
     558:      	ldr	x23, [sp, #0x170]
     55c:      	ldr	x24, [sp, #0x178]
     560:      	ldr	x25, [sp, #0x180]
     564:      	ldr	x26, [sp, #0x188]
     568:      	ldr	x27, [sp, #0x190]
     56c:      	ldr	x28, [sp, #0x198]
     570:      	ldr	x29, [sp, #0x10]
     574:      	ldr	x30, [sp, #0x18]
     578:      	add	sp, sp, #0x1a0
     57c:      	ret
     580:      	mov	x11, x8
     584:      	lsl	x11, x11, #2
     588:      	lsr	w11, w11, #0
     58c:      	ubfx	x11, x11, #0, #32
     590:      	lsr	x10, x10, x11
     594:      	lsr	w10, w10, #0
     598:      	and	x10, x10, #0xf
     59c:      	lsr	w10, w10, #0
     5a0:      	b	0x5c0 <_stogir.verify.structure+0x428>
     5a4:      	movz	x1, #0x0, lsl #48
     5a8:      	cmp	x1, #0x0
     5ac:      	b.eq	0xa2c <_stogir.verify.structure+0x894>
     5b0:      	ldr	w1, [sp, #0x148]
     5b4:      	ldr	w6, [sp, #0x140]
     5b8:      	b	0x69c <_stogir.verify.structure+0x504>
     5bc:      	movz	x10, #0x0, lsl #48
     5c0:      	b	0x5c8 <_stogir.verify.structure+0x430>
     5c4:      	movz	x10, #0x0, lsl #48
     5c8:      	add	x16, sp, #0x20
     5cc:      	str	x16, [sp]
     5d0:      	str	w0, [sp, #0xf0]
     5d4:      	str	x2, [sp, #0xe8]
     5d8:      	mov	w2, w4
     5dc:      	str	x3, [sp, #0x130]
     5e0:      	str	x19, [sp, #0xf8]
     5e4:      	mov	x19, x1
     5e8:      	mov	w1, w0
     5ec:      	mov	x0, x23
     5f0:      	str	x25, [sp, #0x100]
     5f4:      	mov	x25, x10
     5f8:      	str	x26, [sp, #0x108]
     5fc:      	mov	x26, x5
     600:      	str	x28, [sp, #0x110]
     604:      	mov	w28, w6
     608:      	str	x20, [sp, #0x118]
     60c:      	mov	w20, w7
     610:      	str	x21, [sp, #0x120]
     614:      	mov	x21, x8
     618:      	str	x27, [sp, #0x128]
     61c:      	mov	w27, w9
     620:      	bl	0x620 <_stogir.verify.structure+0x488>
		0000000000000620:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     624:      	ldr	x16, [sp]
     628:      	str	x0, [x16]
     62c:      	str	x1, [x16, #0x8]
     630:      	add	x16, sp, #0x20
     634:      	ldr	x0, [x16]
     638:      	add	x16, sp, #0x20
     63c:      	ldr	x1, [x16, #0x8]
     640:      	lsr	w0, w0, #0
     644:      	lsr	x16, x0, #0
     648:      	cmp	x16, #0x1
     64c:      	b.eq	0x668 <_stogir.verify.structure+0x4d0>
     650:      	b.lo	0x658 <_stogir.verify.structure+0x4c0>
     654:      	b	0x66c <_stogir.verify.structure+0x4d4>
     658:      	cmp	x16, #0x0
     65c:      	b.eq	0x664 <_stogir.verify.structure+0x4cc>
     660:      	b	0x66c <_stogir.verify.structure+0x4d4>
     664:      	b	0x670 <_stogir.verify.structure+0x4d8>
     668:      	b	0x774 <_stogir.verify.structure+0x5dc>
     66c:      	b	0xb68 <_stogir.verify.structure+0x9d0>
     670:      	ldr	x3, [sp, #0xd0]
     674:      	ldr	x0, [sp, #0xd8]
     678:      	ldr	x2, [sp, #0xc8]
     67c:      	ldr	x4, [sp, #0xb8]
     680:      	ldr	x5, [sp, #0xb0]
     684:      	mov	w1, w24
     688:      	mov	w6, w22
     68c:      	ldr	x17, [sp, #0x90]
     690:      	str	x17, [sp, #0xa8]
     694:      	mov	x16, #0x17              ; =23
     698:      	str	x16, [sp, #0x118]
     69c:      	ldr	x7, [sp, #0x130]
     6a0:      	add	x7, x7, #0x1
     6a4:      	lsr	w7, w7, #0
     6a8:      	sxtw	x7, w7
     6ac:      	ldr	x26, [sp, #0x108]
     6b0:      	ldr	x21, [sp, #0x120]
     6b4:      	str	x3, [sp, #0xd0]
     6b8:      	str	w27, [sp, #0xe0]
     6bc:      	ldr	x27, [sp, #0x128]
     6c0:      	ldr	x25, [sp, #0x100]
     6c4:      	ldr	x28, [sp, #0x110]
     6c8:      	str	x0, [sp, #0xd8]
     6cc:      	ldr	w0, [sp, #0xf0]
     6d0:      	str	x2, [sp, #0xc8]
     6d4:      	str	x4, [sp, #0xb8]
     6d8:      	str	x5, [sp, #0xb0]
     6dc:      	mov	w24, w1
     6e0:      	mov	w22, w6
     6e4:      	ldr	x2, [sp, #0xe8]
     6e8:      	mov	x1, x19
     6ec:      	ldr	x19, [sp, #0xf8]
     6f0:      	mov	x3, x7
     6f4:      	ldr	x20, [sp, #0x118]
     6f8:      	cmp	x20, #0x0
     6fc:      	b.ne	0x710 <_stogir.verify.structure+0x578>
     700:      	cmp	x3, x26
     704:      	cset	w4, le
     708:      	ubfx	x4, x4, #0, #8
     70c:      	b	0x714 <_stogir.verify.structure+0x57c>
     710:      	movz	x4, #0x0, lsl #48
     714:      	cmp	x4, #0x0
     718:      	b.eq	0xd04 <_stogir.verify.structure+0xb6c>
     71c:      	lsr	w4, w3, #0
     720:      	sxtw	x5, w4
     724:      	cmp	x5, #0x0
     728:      	cset	w6, gt
     72c:      	cmp	x5, #0x4
     730:      	cset	w7, gt
     734:      	sub	x8, x5, #0x1
     738:      	lsr	w8, w8, #0
     73c:      	sxtw	x8, w8
     740:      	ldr	w9, [sp, #0xe0]
     744:      	uxtb	w16, w9
     748:      	cmp	w16, wzr
     74c:      	b.eq	0x5c4 <_stogir.verify.structure+0x42c>
     750:      	ldr	w10, [x28]
     754:      	uxtb	w16, w6
     758:      	cmp	w16, wzr
     75c:      	b.eq	0x5bc <_stogir.verify.structure+0x424>
     760:      	uxtb	w16, w7
     764:      	cmp	w16, wzr
     768:      	b.eq	0x580 <_stogir.verify.structure+0x3e8>
     76c:      	mov	x11, #0x4               ; =4
     770:      	b	0x584 <_stogir.verify.structure+0x3ec>
     774:      	lsr	w25, w25, #0
     778:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000778:  ARM64_RELOC_PAGE21	l_stogir.318
     77c:      	ldr	x16, [x16]
		000000000000077c:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     780:      	ldr	w0, [x16]
     784:      	orr	x2, x25, xzr
     788:      	cmp	x2, x0
     78c:      	b.ne	0x7a0 <_stogir.verify.structure+0x608>
     790:      	mov	x0, #0x1                ; =1
     794:      	b	0x7b8 <_stogir.verify.structure+0x620>
     798:      	movz	x1, #0x0, lsl #48
     79c:      	b	0x824 <_stogir.verify.structure+0x68c>
     7a0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007a0:  ARM64_RELOC_PAGE21	l_stogir.319
     7a4:      	ldr	x16, [x16]
		00000000000007a4:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     7a8:      	ldr	w0, [x16]
     7ac:      	cmp	x2, x0
     7b0:      	cset	w0, eq
     7b4:      	ubfx	x0, x0, #0, #8
     7b8:      	lsr	w1, w1, #0
     7bc:      	cmp	x0, #0x0
     7c0:      	b.eq	0xd34 <_stogir.verify.structure+0xb9c>
     7c4:      	lsr	w1, w1, #0
     7c8:      	str	x26, [sp, #0x138]
     7cc:      	mov	x26, x2
     7d0:      	str	w22, [sp, #0x140]
     7d4:      	mov	x22, x0
     7d8:      	mov	x0, x23
     7dc:      	str	w24, [sp, #0x148]
     7e0:      	mov	w24, w1
     7e4:      	bl	0x7e4 <_stogir.verify.structure+0x64c>
		00000000000007e4:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     7e8:      	cmp	x0, #0x0
     7ec:      	cset	w1, eq
     7f0:      	uxtb	w16, w1
     7f4:      	cmp	w16, wzr
     7f8:      	cset	x1, eq
     7fc:      	cmp	x1, #0x0
     800:      	b.eq	0x824 <_stogir.verify.structure+0x68c>
     804:      	ldr	w0, [x0]
     808:      	uxtb	w0, w0
     80c:      	cmp	x0, #0x48
     810:      	b.ne	0x824 <_stogir.verify.structure+0x68c>
     814:      	ldr	x17, [sp, #0x98]
     818:      	str	x17, [sp, #0xa8]
     81c:      	mov	x16, #0x25              ; =37
     820:      	str	x16, [sp, #0x118]
     824:      	sxtw	x24, w24
     828:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000828:  ARM64_RELOC_PAGE21	l_stogir.320
     82c:      	ldr	x16, [x16]
		000000000000082c:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     830:      	ldr	w0, [x16]
     834:      	cmp	x26, x0
     838:      	b.ne	0xd50 <_stogir.verify.structure+0xbb8>
     83c:      	cmp	x24, #0x0
     840:      	b.gt	0x9c4 <_stogir.verify.structure+0x82c>
     844:      	ldr	x3, [sp, #0xd0]
     848:      	ldr	x0, [sp, #0xd8]
     84c:      	movz	x2, #0x0, lsl #48
     850:      	lsr	w2, w2, #0
     854:      	lsr	x16, x2, #0
     858:      	cmp	x16, #0x1
     85c:      	b.eq	0x878 <_stogir.verify.structure+0x6e0>
     860:      	b.lo	0x868 <_stogir.verify.structure+0x6d0>
     864:      	b	0x87c <_stogir.verify.structure+0x6e4>
     868:      	cmp	x16, #0x0
     86c:      	b.eq	0x874 <_stogir.verify.structure+0x6dc>
     870:      	b	0x87c <_stogir.verify.structure+0x6e4>
     874:      	b	0x880 <_stogir.verify.structure+0x6e8>
     878:      	b	0x890 <_stogir.verify.structure+0x6f8>
     87c:      	b	0xbf8 <_stogir.verify.structure+0xa60>
     880:      	ldr	x17, [sp, #0x68]
     884:      	str	x17, [sp, #0xa8]
     888:      	mov	x16, #0x21              ; =33
     88c:      	str	x16, [sp, #0x118]
     890:      	cmp	x25, #0xf
     894:      	b.hs	0xd5c <_stogir.verify.structure+0xbc4>
     898:      	mov	x16, #0x1               ; =1
     89c:      	lsl	x2, x16, x25
     8a0:      	lsr	w2, w2, #0
     8a4:      	mov	x17, #0x5e1c            ; =24092
     8a8:      	and	x2, x2, x17
     8ac:      	lsr	w2, w2, #0
     8b0:      	cmp	x2, #0x0
     8b4:      	b.eq	0xd74 <_stogir.verify.structure+0xbdc>
     8b8:      	cmp	x22, #0x0
     8bc:      	b.eq	0xa80 <_stogir.verify.structure+0x8e8>
     8c0:      	ldr	x2, [sp, #0xc8]
     8c4:      	ldr	x4, [sp, #0xb8]
     8c8:      	ldr	x5, [sp, #0xb0]
     8cc:      	b	0x5a8 <_stogir.verify.structure+0x410>
     8d0:      	lsr	w0, w27, #0
     8d4:      	cmp	x28, #0x78
     8d8:      	cset	w24, eq
     8dc:      	lsr	w0, w0, #0
     8e0:      	add	x1, x25, x28, lsl #2
     8e4:      	ldr	x2, [sp, #0xe8]
     8e8:      	add	x3, x2, x28, lsl #2
     8ec:      	cmp	x22, #0x0
     8f0:      	cset	w22, eq
     8f4:      	orr	x28, x1, xzr
     8f8:      	orr	x1, x3, xzr
     8fc:      	mov	x3, #0x1                ; =1
     900:      	b	0x6f8 <_stogir.verify.structure+0x560>
     904:      	nop
     908:      	movz	x1, #0x0, lsl #48
     90c:      	cmp	x1, #0x0
     910:      	b.eq	0x8d0 <_stogir.verify.structure+0x738>
     914:      	add	x1, x0, x27
     918:      	ldr	x2, [x23, #0x78]
     91c:      	add	x1, x2, x1, lsl #2
     920:      	ldr	w1, [x1]
     924:      	sxtw	x1, w1
     928:      	cmn	x1, #0x1
     92c:      	b.eq	0x93c <_stogir.verify.structure+0x7a4>
     930:      	ldr	x17, [sp, #0x88]
     934:      	str	x17, [sp, #0xa8]
     938:      	mov	x20, #0x1b              ; =27
     93c:      	add	x0, x0, #0x1
     940:      	cmp	x20, #0x0
     944:      	b.ne	0x908 <_stogir.verify.structure+0x770>
     948:      	cmp	x0, x21
     94c:      	cset	w1, lt
     950:      	ubfx	x1, x1, #0, #8
     954:      	b	0x90c <_stogir.verify.structure+0x774>
     958:      	mov	w0, w24
     95c:      	bl	0x95c <_stogir.verify.structure+0x7c4>
		000000000000095c:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     960:      	lsr	w0, w0, #0
     964:      	sxtw	x0, w0
     968:      	cmn	x0, #0x1
     96c:      	b.ne	0x988 <_stogir.verify.structure+0x7f0>
     970:      	ubfx	x0, x21, #16, #16
     974:      	cmp	x26, x0
     978:      	b.eq	0x988 <_stogir.verify.structure+0x7f0>
     97c:      	ldr	x17, [sp, #0x78]
     980:      	str	x17, [sp, #0xa8]
     984:      	mov	x20, #0x24              ; =36
     988:      	add	x0, x26, #0x4
     98c:      	ldr	x1, [x23, #0x8]
     990:      	asr	x16, x0, #63
     994:      	lsr	x16, x16, #62
     998:      	add	x0, x0, x16
     99c:      	asr	x0, x0, #2
     9a0:      	orr	x21, x0, xzr
     9a4:      	add	x0, x21, x27
     9a8:      	cmp	x0, x1
     9ac:      	b.le	0x9bc <_stogir.verify.structure+0x824>
     9b0:      	ldr	x17, [sp, #0x80]
     9b4:      	str	x17, [sp, #0xa8]
     9b8:      	mov	x20, #0x15              ; =21
     9bc:      	mov	x0, #0x1                ; =1
     9c0:      	b	0x940 <_stogir.verify.structure+0x7a8>
     9c4:      	ldr	x0, [sp, #0xd8]
     9c8:      	ldr	x2, [x0, #0x8]
     9cc:      	cmp	x24, x2
     9d0:      	b.gt	0xd8c <_stogir.verify.structure+0xbf4>
     9d4:      	sub	x2, x24, #0x1
     9d8:      	ldr	x3, [sp, #0xd0]
     9dc:      	ldr	x4, [x3, #0x28]
     9e0:      	mov	x17, #0x18              ; =24
     9e4:      	mul	x2, x2, x17
     9e8:      	add	x2, x2, x4
     9ec:      	ldr	x4, [x2]
     9f0:      	ldr	x2, [x2, #0x8]
     9f4:      	ldr	x5, [x3, #0x8]
     9f8:      	cmp	x4, #0x0
     9fc:      	b.lt	0xa24 <_stogir.verify.structure+0x88c>
     a00:      	cmp	x4, x5
     a04:      	b.gt	0xa24 <_stogir.verify.structure+0x88c>
     a08:      	cmp	x2, #0x0
     a0c:      	b.lt	0xa24 <_stogir.verify.structure+0x88c>
     a10:      	sub	x4, x5, x4
     a14:      	cmp	x2, x4
     a18:      	b.gt	0xa24 <_stogir.verify.structure+0x88c>
     a1c:      	mov	x2, #0x1                ; =1
     a20:      	b	0xa28 <_stogir.verify.structure+0x890>
     a24:      	movz	x2, #0x0, lsl #48
     a28:      	b	0x850 <_stogir.verify.structure+0x6b8>
     a2c:      	cmp	x24, #0x0
     a30:      	b.ne	0xd94 <_stogir.verify.structure+0xbfc>
     a34:      	uxtb	w16, w27
     a38:      	cmp	w16, wzr
     a3c:      	b.eq	0xb70 <_stogir.verify.structure+0x9d8>
     a40:      	ldr	w1, [x19]
     a44:      	uxtb	w16, w28
     a48:      	cmp	w16, wzr
     a4c:      	b.eq	0xbb8 <_stogir.verify.structure+0xa20>
     a50:      	uxtb	w16, w20
     a54:      	cmp	w16, wzr
     a58:      	b.eq	0xa60 <_stogir.verify.structure+0x8c8>
     a5c:      	mov	x21, #0x4               ; =4
     a60:      	lsl	x6, x21, #2
     a64:      	lsr	w6, w6, #0
     a68:      	ubfx	x6, x6, #0, #32
     a6c:      	lsr	x1, x1, x6
     a70:      	lsr	w1, w1, #0
     a74:      	and	x1, x1, #0xf
     a78:      	lsr	w1, w1, #0
     a7c:      	b	0xbbc <_stogir.verify.structure+0xa24>
     a80:      	cmp	x24, #0x0
     a84:      	b.le	0xda0 <_stogir.verify.structure+0xc08>
     a88:      	ldr	x1, [x23, #0x8]
     a8c:      	cmp	x24, x1
     a90:      	b.ge	0xda8 <_stogir.verify.structure+0xc10>
     a94:      	ldr	x2, [sp, #0xc8]
     a98:      	ldr	x1, [x2, #0x8]
     a9c:      	cmp	x24, x1
     aa0:      	b.ge	0xbc8 <_stogir.verify.structure+0xa30>
     aa4:      	ldr	x1, [x23, #0x78]
     aa8:      	add	x1, x1, x24, lsl #2
     aac:      	ldr	w1, [x1]
     ab0:      	sxtw	x1, w1
     ab4:      	cmp	x1, #0x0
     ab8:      	cset	w1, ge
     abc:      	ubfx	x1, x1, #0, #8
     ac0:      	b	0xbcc <_stogir.verify.structure+0xa34>
     ac4:      	ldr	w1, [sp, #0x148]
     ac8:      	uxtb	w16, w1
     acc:      	cmp	w16, wzr
     ad0:      	b.eq	0xdb0 <_stogir.verify.structure+0xc18>
     ad4:      	ldr	w6, [sp, #0x140]
     ad8:      	uxtb	w16, w6
     adc:      	cmp	w16, wzr
     ae0:      	b.eq	0xaf0 <_stogir.verify.structure+0x958>
     ae4:      	ldr	x7, [sp, #0x138]
     ae8:      	cmp	x7, #0x2
     aec:      	b.eq	0x5b8 <_stogir.verify.structure+0x420>
     af0:      	ldr	x17, [sp, #0x70]
     af4:      	str	x17, [sp, #0xa8]
     af8:      	mov	x16, #0x1a              ; =26
     afc:      	str	x16, [sp, #0x118]
     b00:      	b	0x5b8 <_stogir.verify.structure+0x420>
     b04:      	movz	x1, #0x0, lsl #48
     b08:      	ldr	x4, [sp, #0xb8]
     b0c:      	ldr	x5, [sp, #0xb0]
     b10:      	b	0x5a8 <_stogir.verify.structure+0x410>
     b14:      	cmp	x24, #0x0
     b18:      	b.ge	0xdb8 <_stogir.verify.structure+0xc20>
     b1c:      	ldr	x4, [sp, #0xb8]
     b20:      	ldr	x1, [x4, #0x8]
     b24:      	ldr	x5, [sp, #0xb0]
     b28:      	ldr	x6, [x5, #0x8]
     b2c:      	cmp	x1, x6
     b30:      	b.ne	0xbc0 <_stogir.verify.structure+0xa28>
     b34:      	movz	x16, #0x0, lsl #48
     b38:      	sub	x6, x16, x24
     b3c:      	cmp	x6, x1
     b40:      	b.gt	0xbf0 <_stogir.verify.structure+0xa58>
     b44:      	sub	x1, x6, #0x1
     b48:      	ldr	x6, [x23, #0x50]
     b4c:      	add	x1, x6, x1, lsl #2
     b50:      	ldr	w1, [x1]
     b54:      	sxtw	x1, w1
     b58:      	cmp	x1, #0x0
     b5c:      	cset	w1, gt
     b60:      	ubfx	x1, x1, #0, #8
     b64:      	b	0xbf4 <_stogir.verify.structure+0xa5c>
     b68:      	brk	#0
     b6c:      	b	0xb68 <_stogir.verify.structure+0x9d0>
     b70:      	movz	x1, #0x0, lsl #48
     b74:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b74:  ARM64_RELOC_PAGE21	l_stogir.321
     b78:      	ldr	x16, [x16]
		0000000000000b78:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     b7c:      	ldr	w6, [x16]
     b80:      	lsr	w1, w1, #0
     b84:      	cmp	x1, x6
     b88:      	b.ne	0xb98 <_stogir.verify.structure+0xa00>
     b8c:      	ldr	w1, [sp, #0x148]
     b90:      	ldr	w6, [sp, #0x140]
     b94:      	b	0x5b8 <_stogir.verify.structure+0x420>
     b98:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b98:  ARM64_RELOC_PAGE21	l_stogir.322
     b9c:      	ldr	x16, [x16]
		0000000000000b9c:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     ba0:      	ldr	w6, [x16]
     ba4:      	cmp	x1, x6
     ba8:      	b.ne	0xbd0 <_stogir.verify.structure+0xa38>
     bac:      	ldr	w1, [sp, #0x148]
     bb0:      	ldr	w6, [sp, #0x140]
     bb4:      	b	0x5b8 <_stogir.verify.structure+0x420>
     bb8:      	movz	x1, #0x0, lsl #48
     bbc:      	b	0xb74 <_stogir.verify.structure+0x9dc>
     bc0:      	movz	x1, #0x0, lsl #48
     bc4:      	b	0x5a8 <_stogir.verify.structure+0x410>
     bc8:      	movz	x1, #0x0, lsl #48
     bcc:      	b	0xb08 <_stogir.verify.structure+0x970>
     bd0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bd0:  ARM64_RELOC_PAGE21	l_stogir.323
     bd4:      	ldr	x16, [x16]
		0000000000000bd4:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     bd8:      	ldr	w6, [x16]
     bdc:      	cmp	x1, x6
     be0:      	b.ne	0xac4 <_stogir.verify.structure+0x92c>
     be4:      	ldr	w1, [sp, #0x148]
     be8:      	ldr	w6, [sp, #0x140]
     bec:      	b	0x5b8 <_stogir.verify.structure+0x420>
     bf0:      	movz	x1, #0x0, lsl #48
     bf4:      	b	0xbc4 <_stogir.verify.structure+0xa2c>
     bf8:      	brk	#0
     bfc:      	b	0xbf8 <_stogir.verify.structure+0xa60>
     c00:      	mov	x1, x13
     c04:      	str	x8, [sp, #0xa0]
     c08:      	str	x19, [sp, #0xa8]
     c0c:      	str	x20, [sp, #0x118]
     c10:      	b	0x518 <_stogir.verify.structure+0x380>
     c14:      	mov	x1, x13
     c18:      	str	x8, [sp, #0xa0]
     c1c:      	str	x19, [sp, #0xa8]
     c20:      	str	x20, [sp, #0x118]
     c24:      	b	0x518 <_stogir.verify.structure+0x380>
     c28:      	str	x8, [sp, #0xa0]
     c2c:      	str	x21, [sp, #0x40]
     c30:      	str	x22, [sp, #0x58]
     c34:      	str	x23, [sp, #0x60]
     c38:      	mov	x23, x0
     c3c:      	str	x24, [sp, #0x78]
     c40:      	str	x25, [sp, #0x80]
     c44:      	str	x26, [sp, #0x88]
     c48:      	str	x27, [sp, #0x90]
     c4c:      	str	x28, [sp, #0x98]
     c50:      	str	x1, [sp, #0x68]
     c54:      	mov	x1, x13
     c58:      	str	x2, [sp, #0x70]
     c5c:      	str	x4, [sp, #0x100]
     c60:      	mov	x0, x11
     c64:      	mov	x2, x5
     c68:      	mov	x4, x6
     c6c:      	mov	x6, x12
     c70:      	mov	x5, x7
     c74:      	str	x9, [sp, #0xe8]
     c78:      	str	x10, [sp, #0xf8]
     c7c:      	b	0x34c <_stogir.verify.structure+0x1b4>
     c80:      	str	x8, [sp, #0xa0]
     c84:      	str	x22, [sp, #0x58]
     c88:      	str	x23, [sp, #0x60]
     c8c:      	ldr	x23, [sp, #0x30]
     c90:      	str	x24, [sp, #0x78]
     c94:      	str	x25, [sp, #0x80]
     c98:      	str	x26, [sp, #0x88]
     c9c:      	str	x27, [sp, #0x90]
     ca0:      	str	x28, [sp, #0x98]
     ca4:      	str	x1, [sp, #0x68]
     ca8:      	mov	x1, x13
     cac:      	str	x2, [sp, #0x70]
     cb0:      	str	x4, [sp, #0x100]
     cb4:      	mov	x0, x11
     cb8:      	mov	x2, x5
     cbc:      	mov	x4, x6
     cc0:      	mov	x6, x12
     cc4:      	mov	x5, x7
     cc8:      	str	x9, [sp, #0xe8]
     ccc:      	str	x10, [sp, #0xf8]
     cd0:      	b	0x2e4 <_stogir.verify.structure+0x14c>
     cd4:      	mov	x6, x27
     cd8:      	ldr	x1, [sp, #0xc0]
     cdc:      	ldr	x3, [sp, #0xd0]
     ce0:      	str	x25, [sp, #0x100]
     ce4:      	ldr	x0, [sp, #0xd8]
     ce8:      	ldr	x2, [sp, #0xc8]
     cec:      	ldr	x4, [sp, #0xb8]
     cf0:      	ldr	x5, [sp, #0xb0]
     cf4:      	str	x19, [sp, #0xf8]
     cf8:      	b	0x2e4 <_stogir.verify.structure+0x14c>
     cfc:      	ldr	x1, [sp, #0xa8]
     d00:      	b	0x534 <_stogir.verify.structure+0x39c>
     d04:      	str	x27, [sp, #0x128]
     d08:      	str	x21, [sp, #0x120]
     d0c:      	ldr	x3, [sp, #0xd0]
     d10:      	str	x20, [sp, #0x118]
     d14:      	str	x25, [sp, #0x100]
     d18:      	ldr	x0, [sp, #0xd8]
     d1c:      	ldr	x4, [sp, #0xb8]
     d20:      	ldr	x5, [sp, #0xb0]
     d24:      	str	x2, [sp, #0xe8]
     d28:      	ldr	x2, [sp, #0xc8]
     d2c:      	str	x19, [sp, #0xf8]
     d30:      	b	0x1f8 <_stogir.verify.structure+0x60>
     d34:      	str	x26, [sp, #0x138]
     d38:      	mov	x26, x2
     d3c:      	str	w24, [sp, #0x148]
     d40:      	mov	w24, w1
     d44:      	str	w22, [sp, #0x140]
     d48:      	mov	x22, x0
     d4c:      	b	0x798 <_stogir.verify.structure+0x600>
     d50:      	ldr	x3, [sp, #0xd0]
     d54:      	ldr	x0, [sp, #0xd8]
     d58:      	b	0x890 <_stogir.verify.structure+0x6f8>
     d5c:      	ldr	x2, [sp, #0xc8]
     d60:      	ldr	x4, [sp, #0xb8]
     d64:      	ldr	x5, [sp, #0xb0]
     d68:      	ldr	w1, [sp, #0x148]
     d6c:      	ldr	w6, [sp, #0x140]
     d70:      	b	0x5b8 <_stogir.verify.structure+0x420>
     d74:      	ldr	x2, [sp, #0xc8]
     d78:      	ldr	x4, [sp, #0xb8]
     d7c:      	ldr	x5, [sp, #0xb0]
     d80:      	ldr	w1, [sp, #0x148]
     d84:      	ldr	w6, [sp, #0x140]
     d88:      	b	0x5b8 <_stogir.verify.structure+0x420>
     d8c:      	ldr	x3, [sp, #0xd0]
     d90:      	b	0x84c <_stogir.verify.structure+0x6b4>
     d94:      	ldr	w1, [sp, #0x148]
     d98:      	ldr	w6, [sp, #0x140]
     d9c:      	b	0xaf0 <_stogir.verify.structure+0x958>
     da0:      	ldr	x2, [sp, #0xc8]
     da4:      	b	0xb14 <_stogir.verify.structure+0x97c>
     da8:      	ldr	x2, [sp, #0xc8]
     dac:      	b	0xb04 <_stogir.verify.structure+0x96c>
     db0:      	ldr	w6, [sp, #0x140]
     db4:      	b	0xaf0 <_stogir.verify.structure+0x958>
     db8:      	ldr	x4, [sp, #0xb8]
     dbc:      	ldr	x5, [sp, #0xb0]
     dc0:      	b	0x5a4 <_stogir.verify.structure+0x40c>

0000000000000dc4 <_stogir.verify.integer-operations-target-structured>:
     dc4:      	sub	sp, sp, #0x3d0
     dc8:      	str	x29, [sp, #0x10]
     dcc:      	str	x30, [sp, #0x18]
     dd0:      	add	x29, sp, #0x10
     dd4:      	str	x19, [sp, #0x380]
     dd8:      	str	x20, [sp, #0x388]
     ddc:      	str	x21, [sp, #0x390]
     de0:      	str	x22, [sp, #0x398]
     de4:      	str	x23, [sp, #0x3a0]
     de8:      	str	x24, [sp, #0x3a8]
     dec:      	str	x25, [sp, #0x3b0]
     df0:      	str	x26, [sp, #0x3b8]
     df4:      	str	x27, [sp, #0x3c0]
     df8:      	str	x28, [sp, #0x3c8]
     dfc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000dfc:  ARM64_RELOC_PAGE21	l_stogir.324
     e00:      	ldr	x16, [x16]
		0000000000000e00:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     e04:      	orr	x19, x16, xzr
     e08:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e08:  ARM64_RELOC_PAGE21	l_stogir.325
     e0c:      	ldr	x16, [x16]
		0000000000000e0c:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     e10:      	orr	x20, x16, xzr
     e14:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e14:  ARM64_RELOC_PAGE21	l_stogir.326
     e18:      	ldr	x16, [x16]
		0000000000000e18:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     e1c:      	orr	x21, x16, xzr
     e20:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e20:  ARM64_RELOC_PAGE21	l_stogir.327
     e24:      	ldr	x16, [x16]
		0000000000000e24:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     e28:      	orr	x22, x16, xzr
     e2c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e2c:  ARM64_RELOC_PAGE21	l_stogir.328
     e30:      	ldr	x16, [x16]
		0000000000000e30:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     e34:      	orr	x23, x16, xzr
     e38:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e38:  ARM64_RELOC_PAGE21	l_stogir.329
     e3c:      	ldr	x16, [x16]
		0000000000000e3c:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     e40:      	orr	x24, x16, xzr
     e44:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e44:  ARM64_RELOC_PAGE21	l_stogir.330
     e48:      	ldr	x16, [x16]
		0000000000000e48:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     e4c:      	orr	x25, x16, xzr
     e50:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e50:  ARM64_RELOC_PAGE21	l_stogir.331
     e54:      	ldr	x16, [x16]
		0000000000000e54:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     e58:      	orr	x26, x16, xzr
     e5c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e5c:  ARM64_RELOC_PAGE21	l_stogir.332
     e60:      	ldr	x16, [x16]
		0000000000000e60:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     e64:      	orr	x27, x16, xzr
     e68:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e68:  ARM64_RELOC_PAGE21	l_stogir.333
     e6c:      	ldr	x16, [x16]
		0000000000000e6c:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     e70:      	orr	x28, x16, xzr
     e74:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e74:  ARM64_RELOC_PAGE21	l_stogir.334
     e78:      	ldr	x16, [x16]
		0000000000000e78:  ARM64_RELOC_PAGEOFF12	l_stogir.334
     e7c:      	orr	x2, x16, xzr
     e80:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e80:  ARM64_RELOC_PAGE21	l_stogir.335
     e84:      	ldr	x16, [x16]
		0000000000000e84:  ARM64_RELOC_PAGEOFF12	l_stogir.335
     e88:      	orr	x3, x16, xzr
     e8c:      	lsr	w4, w1, #0
     e90:      	lsr	w5, w1, #0
     e94:      	lsr	w1, w1, #0
     e98:      	add	x16, sp, #0x20
     e9c:      	orr	x6, x16, xzr
     ea0:      	add	x16, sp, #0x30
     ea4:      	orr	x7, x16, xzr
     ea8:      	add	x7, x7, #0x8
     eac:      	add	x16, sp, #0x50
     eb0:      	orr	x9, x16, xzr
     eb4:      	add	x9, x9, #0x8
     eb8:      	add	x16, sp, #0xe0
     ebc:      	orr	x10, x16, xzr
     ec0:      	add	x10, x10, #0x8
     ec4:      	add	x16, sp, #0x100
     ec8:      	orr	x11, x16, xzr
     ecc:      	add	x11, x11, #0x8
     ed0:      	add	x16, sp, #0x120
     ed4:      	orr	x12, x16, xzr
     ed8:      	add	x12, x12, #0x8
     edc:      	add	x16, sp, #0x140
     ee0:      	orr	x13, x16, xzr
     ee4:      	add	x13, x13, #0x8
     ee8:      	add	x16, sp, #0x160
     eec:      	orr	x14, x16, xzr
     ef0:      	add	x14, x14, #0x8
     ef4:      	add	x16, sp, #0x180
     ef8:      	orr	x15, x16, xzr
     efc:      	add	x15, x15, #0x8
     f00:      	str	w1, [sp, #0x230]
     f04:      	add	x16, sp, #0x1a0
     f08:      	orr	x1, x16, xzr
     f0c:      	add	x1, x1, #0x8
     f10:      	str	x1, [sp, #0x238]
     f14:      	add	x16, sp, #0x1f0
     f18:      	orr	x1, x16, xzr
     f1c:      	add	x1, x1, #0x8
     f20:      	str	x20, [sp, #0x240]
     f24:      	str	x21, [sp, #0x248]
     f28:      	str	x22, [sp, #0x250]
     f2c:      	mov	x20, #0x1               ; =1
     f30:      	movz	x21, #0x0, lsl #48
     f34:      	movz	x22, #0x0, lsl #48
     f38:      	cmp	x22, #0x0
     f3c:      	b.ne	0x1f10 <_stogir.verify.integer-operations-target-structured+0x114c>
     f40:      	str	x1, [sp, #0x258]
     f44:      	ldr	x1, [x0, #0x8]
     f48:      	cmp	x20, x1
     f4c:      	b.ge	0x1f1c <_stogir.verify.integer-operations-target-structured+0x1158>
     f50:      	ldr	x1, [x0]
     f54:      	add	x1, x1, x20, lsl #4
     f58:      	str	x2, [sp, #0x260]
     f5c:      	ldr	x2, [x1]
     f60:      	str	x23, [sp, #0x268]
     f64:      	uxtb	w23, w2
     f68:      	ldr	x1, [x1, #0x8]
     f6c:      	str	x24, [sp, #0x270]
     f70:      	orr	x24, x23, xzr
     f74:      	add	x16, sp, #0x20
     f78:      	str	x2, [x16]
     f7c:      	add	x16, sp, #0x20
     f80:      	str	x1, [x16, #0x8]
     f84:      	ldr	x1, [x0, #0x78]
     f88:      	add	x1, x1, x20, lsl #2
     f8c:      	ldr	w1, [x1]
     f90:      	cmp	x24, #0xe
     f94:      	b.lt	0x1680 <_stogir.verify.integer-operations-target-structured+0x8bc>
     f98:      	cmp	x24, #0x17
     f9c:      	cset	w2, le
     fa0:      	ubfx	x2, x2, #0, #8
     fa4:      	str	x25, [sp, #0x278]
     fa8:      	cmp	x24, #0x1a
     fac:      	cset	w25, ge
     fb0:      	str	x26, [sp, #0x280]
     fb4:      	cmp	x24, #0x1e
     fb8:      	cset	w26, le
     fbc:      	str	x27, [sp, #0x288]
     fc0:      	cmp	x24, #0x2e
     fc4:      	cset	w27, ge
     fc8:      	str	x28, [sp, #0x290]
     fcc:      	cmp	x24, #0x35
     fd0:      	cset	w28, le
     fd4:      	str	w23, [sp, #0x298]
     fd8:      	cmp	x24, #0x3a
     fdc:      	cset	w23, eq
     fe0:      	str	x21, [sp, #0x2a0]
     fe4:      	cmp	x24, #0x3b
     fe8:      	cset	w21, eq
     fec:      	uxtb	w16, w25
     ff0:      	cmp	w16, wzr
     ff4:      	b.eq	0x1688 <_stogir.verify.integer-operations-target-structured+0x8c4>
     ff8:      	uxtb	w16, w26
     ffc:      	cmp	w16, wzr
    1000:      	b.eq	0x1688 <_stogir.verify.integer-operations-target-structured+0x8c4>
    1004:      	str	w21, [sp, #0x2a8]
    1008:      	mov	x21, #0x1               ; =1
    100c:      	cmp	x24, #0x1f
    1010:      	b.ne	0x16d0 <_stogir.verify.integer-operations-target-structured+0x90c>
    1014:      	str	x0, [sp, #0x2b0]
    1018:      	mov	x0, #0x1                ; =1
    101c:      	str	x0, [sp, #0x2b8]
    1020:      	lsr	w0, w20, #0
    1024:      	lsr	w1, w1, #0
    1028:      	lsr	w0, w0, #0
    102c:      	str	x8, [sp, #0x2c0]
    1030:      	str	w4, [sp, #0x2d0]
    1034:      	str	w5, [sp, #0x2d8]
    1038:      	str	x6, [sp, #0x2e0]
    103c:      	str	x14, [sp, #0x318]
    1040:      	str	x15, [sp, #0x320]
    1044:      	str	w1, [sp, #0x328]
    1048:      	str	x2, [sp, #0x330]
    104c:      	mov	x2, x6
    1050:      	str	w0, [sp, #0x338]
    1054:      	str	x20, [sp, #0x2c8]
    1058:      	mov	x20, x3
    105c:      	mov	w3, w1
    1060:      	mov	w1, w0
    1064:      	ldr	x0, [sp, #0x2b0]
    1068:      	str	w23, [sp, #0x2e8]
    106c:      	mov	x23, x7
    1070:      	str	w28, [sp, #0x2f0]
    1074:      	mov	x28, x9
    1078:      	str	w27, [sp, #0x2f8]
    107c:      	mov	x27, x10
    1080:      	str	w26, [sp, #0x300]
    1084:      	mov	x26, x11
    1088:      	str	w25, [sp, #0x308]
    108c:      	mov	x25, x12
    1090:      	str	x21, [sp, #0x310]
    1094:      	mov	x21, x13
    1098:      	bl	0x1098 <_stogir.verify.integer-operations-target-structured+0x2d4>
		0000000000001098:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    109c:      	uxtb	w1, w0
    10a0:      	cmp	x1, #0x0
    10a4:      	cset	w1, ne
    10a8:      	cmp	x24, #0x3d
    10ac:      	b.lt	0x1748 <_stogir.verify.integer-operations-target-structured+0x984>
    10b0:      	cmp	x24, #0x3f
    10b4:      	b.gt	0x1748 <_stogir.verify.integer-operations-target-structured+0x984>
    10b8:      	add	x8, sp, #0x30
    10bc:      	ldr	w2, [sp, #0x2d0]
    10c0:      	str	x0, [sp, #0x340]
    10c4:      	ldr	x0, [sp, #0x2b0]
    10c8:      	str	x21, [sp, #0x348]
    10cc:      	mov	w21, w1
    10d0:      	ldr	w1, [sp, #0x338]
    10d4:      	bl	0x10d4 <_stogir.verify.integer-operations-target-structured+0x310>
		00000000000010d4:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    10d8:      	add	x16, sp, #0x30
    10dc:      	ldr	w0, [x16]
    10e0:      	lsr	x16, x0, #0
    10e4:      	cmp	x16, #0x1
    10e8:      	b.eq	0x1104 <_stogir.verify.integer-operations-target-structured+0x340>
    10ec:      	b.lo	0x10f4 <_stogir.verify.integer-operations-target-structured+0x330>
    10f0:      	b	0x1108 <_stogir.verify.integer-operations-target-structured+0x344>
    10f4:      	cmp	x16, #0x0
    10f8:      	b.eq	0x1100 <_stogir.verify.integer-operations-target-structured+0x33c>
    10fc:      	b	0x1108 <_stogir.verify.integer-operations-target-structured+0x344>
    1100:      	b	0x1768 <_stogir.verify.integer-operations-target-structured+0x9a4>
    1104:      	b	0x110c <_stogir.verify.integer-operations-target-structured+0x348>
    1108:      	b	0x1ea4 <_stogir.verify.integer-operations-target-structured+0x10e0>
    110c:      	add	x16, sp, #0x30
    1110:      	ldr	x19, [x16, #0x8]
    1114:      	ldr	x22, [x23, #0x8]
    1118:      	ldr	x0, [sp, #0x2a0]
    111c:      	cmp	x24, #0x44
    1120:      	b.ne	0x1784 <_stogir.verify.integer-operations-target-structured+0x9c0>
    1124:      	uxtb	w16, w21
    1128:      	cmp	w16, wzr
    112c:      	b.eq	0x177c <_stogir.verify.integer-operations-target-structured+0x9b8>
    1130:      	movz	x1, #0x0, lsl #48
    1134:      	cmp	x1, #0x0
    1138:      	b.eq	0x1f28 <_stogir.verify.integer-operations-target-structured+0x1164>
    113c:      	add	x8, sp, #0x50
    1140:      	ldr	w1, [sp, #0x338]
    1144:      	str	x23, [sp, #0x350]
    1148:      	mov	x23, x0
    114c:      	ldr	x0, [sp, #0x2b0]
    1150:      	bl	0x1150 <_stogir.verify.integer-operations-target-structured+0x38c>
		0000000000001150:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    1154:      	add	x16, sp, #0x50
    1158:      	ldr	w0, [x16]
    115c:      	lsr	x16, x0, #0
    1160:      	cmp	x16, #0x1
    1164:      	b.eq	0x1180 <_stogir.verify.integer-operations-target-structured+0x3bc>
    1168:      	b.lo	0x1170 <_stogir.verify.integer-operations-target-structured+0x3ac>
    116c:      	b	0x1184 <_stogir.verify.integer-operations-target-structured+0x3c0>
    1170:      	cmp	x16, #0x0
    1174:      	b.eq	0x117c <_stogir.verify.integer-operations-target-structured+0x3b8>
    1178:      	b	0x1184 <_stogir.verify.integer-operations-target-structured+0x3c0>
    117c:      	b	0x178c <_stogir.verify.integer-operations-target-structured+0x9c8>
    1180:      	b	0x1188 <_stogir.verify.integer-operations-target-structured+0x3c4>
    1184:      	b	0x179c <_stogir.verify.integer-operations-target-structured+0x9d8>
    1188:      	add	x16, sp, #0x50
    118c:      	ldr	x19, [x16, #0x8]
    1190:      	ldr	x22, [x28, #0x8]
    1194:      	cmp	x24, #0x1d
    1198:      	b.ne	0x17a4 <_stogir.verify.integer-operations-target-structured+0x9e0>
    119c:      	mov	x0, #0x1                ; =1
    11a0:      	cmp	x0, #0x0
    11a4:      	b.eq	0x17bc <_stogir.verify.integer-operations-target-structured+0x9f8>
    11a8:      	add	x16, sp, #0x20
    11ac:      	ldr	w0, [x16, #0xc]
    11b0:      	sxtw	x0, w0
    11b4:      	cmp	x0, #0x0
    11b8:      	b.ne	0x17b4 <_stogir.verify.integer-operations-target-structured+0x9f0>
    11bc:      	movz	x0, #0x0, lsl #48
    11c0:      	cmp	x0, #0x0
    11c4:      	b.eq	0x1220 <_stogir.verify.integer-operations-target-structured+0x45c>
    11c8:      	add	x16, sp, #0x20
    11cc:      	ldr	w0, [x16, #0xc]
    11d0:      	lsr	w0, w0, #0
    11d4:      	add	x8, sp, #0x70
    11d8:      	mov	w1, w0
    11dc:      	ldr	x0, [sp, #0x2b0]
    11e0:      	bl	0x11e0 <_stogir.verify.integer-operations-target-structured+0x41c>
		00000000000011e0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    11e4:      	add	x16, sp, #0x70
    11e8:      	ldr	w0, [x16]
    11ec:      	lsr	x16, x0, #0
    11f0:      	cmp	x16, #0x1
    11f4:      	b.eq	0x1210 <_stogir.verify.integer-operations-target-structured+0x44c>
    11f8:      	b.lo	0x1200 <_stogir.verify.integer-operations-target-structured+0x43c>
    11fc:      	b	0x1214 <_stogir.verify.integer-operations-target-structured+0x450>
    1200:      	cmp	x16, #0x0
    1204:      	b.eq	0x120c <_stogir.verify.integer-operations-target-structured+0x448>
    1208:      	b	0x1214 <_stogir.verify.integer-operations-target-structured+0x450>
    120c:      	b	0x1218 <_stogir.verify.integer-operations-target-structured+0x454>
    1210:      	b	0x17c4 <_stogir.verify.integer-operations-target-structured+0xa00>
    1214:      	b	0x185c <_stogir.verify.integer-operations-target-structured+0xa98>
    1218:      	ldr	x19, [sp, #0x240]
    121c:      	mov	x22, #0x16              ; =22
    1220:      	cmp	x24, #0x2c
    1224:      	cset	w0, eq
    1228:      	cmp	x24, #0x29
    122c:      	b.lt	0x1864 <_stogir.verify.integer-operations-target-structured+0xaa0>
    1230:      	cmp	x24, #0x2b
    1234:      	b.gt	0x1864 <_stogir.verify.integer-operations-target-structured+0xaa0>
    1238:      	uxtb	w16, w0
    123c:      	cmp	w16, wzr
    1240:      	b.eq	0x1874 <_stogir.verify.integer-operations-target-structured+0xab0>
    1244:      	add	x8, sp, #0xa0
    1248:      	ldr	x0, [sp, #0x2b0]
    124c:      	ldr	w1, [sp, #0x338]
    1250:      	bl	0x1250 <_stogir.verify.integer-operations-target-structured+0x48c>
		0000000000001250:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    1254:      	add	x16, sp, #0xa0
    1258:      	ldr	x0, [x16]
    125c:      	add	x16, sp, #0xa0
    1260:      	ldr	x1, [x16, #0x8]
    1264:      	add	x16, sp, #0xa0
    1268:      	ldr	x2, [x16, #0x10]
    126c:      	lsr	w0, w0, #0
    1270:      	lsr	x16, x0, #0
    1274:      	cmp	x16, #0x1
    1278:      	b.eq	0x1294 <_stogir.verify.integer-operations-target-structured+0x4d0>
    127c:      	b.lo	0x1284 <_stogir.verify.integer-operations-target-structured+0x4c0>
    1280:      	b	0x1298 <_stogir.verify.integer-operations-target-structured+0x4d4>
    1284:      	cmp	x16, #0x0
    1288:      	b.eq	0x1290 <_stogir.verify.integer-operations-target-structured+0x4cc>
    128c:      	b	0x1298 <_stogir.verify.integer-operations-target-structured+0x4d4>
    1290:      	b	0x18a0 <_stogir.verify.integer-operations-target-structured+0xadc>
    1294:      	b	0x129c <_stogir.verify.integer-operations-target-structured+0x4d8>
    1298:      	b	0x1e9c <_stogir.verify.integer-operations-target-structured+0x10d8>
    129c:      	mov	x19, x1
    12a0:      	mov	x22, x2
    12a4:      	cmp	x24, #0x7e
    12a8:      	b.lt	0x1304 <_stogir.verify.integer-operations-target-structured+0x540>
    12ac:      	cmp	x24, #0x82
    12b0:      	b.gt	0x1304 <_stogir.verify.integer-operations-target-structured+0x540>
    12b4:      	add	x8, sp, #0xe0
    12b8:      	ldr	x0, [sp, #0x2b0]
    12bc:      	ldr	w1, [sp, #0x338]
    12c0:      	bl	0x12c0 <_stogir.verify.integer-operations-target-structured+0x4fc>
		00000000000012c0:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    12c4:      	add	x16, sp, #0xe0
    12c8:      	ldr	w0, [x16]
    12cc:      	lsr	x16, x0, #0
    12d0:      	cmp	x16, #0x1
    12d4:      	b.eq	0x12f0 <_stogir.verify.integer-operations-target-structured+0x52c>
    12d8:      	b.lo	0x12e0 <_stogir.verify.integer-operations-target-structured+0x51c>
    12dc:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x530>
    12e0:      	cmp	x16, #0x0
    12e4:      	b.eq	0x12ec <_stogir.verify.integer-operations-target-structured+0x528>
    12e8:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x530>
    12ec:      	b	0x18b0 <_stogir.verify.integer-operations-target-structured+0xaec>
    12f0:      	b	0x12f8 <_stogir.verify.integer-operations-target-structured+0x534>
    12f4:      	b	0x18c0 <_stogir.verify.integer-operations-target-structured+0xafc>
    12f8:      	add	x16, sp, #0xe0
    12fc:      	ldr	x19, [x16, #0x8]
    1300:      	ldr	x22, [x27, #0x8]
    1304:      	cmp	x24, #0x60
    1308:      	b.eq	0x18c8 <_stogir.verify.integer-operations-target-structured+0xb04>
    130c:      	cmp	x24, #0x79
    1310:      	b.eq	0x18c8 <_stogir.verify.integer-operations-target-structured+0xb04>
    1314:      	cmp	x24, #0x75
    1318:      	b.eq	0x192c <_stogir.verify.integer-operations-target-structured+0xb68>
    131c:      	cmp	x24, #0x6d
    1320:      	b.lt	0x132c <_stogir.verify.integer-operations-target-structured+0x568>
    1324:      	cmp	x24, #0x6f
    1328:      	b.le	0x192c <_stogir.verify.integer-operations-target-structured+0xb68>
    132c:      	cmp	x24, #0x42
    1330:      	b.eq	0x1998 <_stogir.verify.integer-operations-target-structured+0xbd4>
    1334:      	cmp	x24, #0x51
    1338:      	b.eq	0x1998 <_stogir.verify.integer-operations-target-structured+0xbd4>
    133c:      	cmp	x24, #0x52
    1340:      	b.eq	0x1998 <_stogir.verify.integer-operations-target-structured+0xbd4>
    1344:      	cmp	x24, #0x53
    1348:      	b.eq	0x1998 <_stogir.verify.integer-operations-target-structured+0xbd4>
    134c:      	cmp	x24, #0x54
    1350:      	b.eq	0x1998 <_stogir.verify.integer-operations-target-structured+0xbd4>
    1354:      	ldr	x0, [sp, #0x348]
    1358:      	cmp	x24, #0x41
    135c:      	b.eq	0x1a04 <_stogir.verify.integer-operations-target-structured+0xc40>
    1360:      	cmp	x24, #0x48
    1364:      	b.eq	0x1a04 <_stogir.verify.integer-operations-target-structured+0xc40>
    1368:      	cmp	x24, #0x55
    136c:      	b.lt	0x1f34 <_stogir.verify.integer-operations-target-structured+0x1170>
    1370:      	cmp	x24, #0x58
    1374:      	b.le	0x1a04 <_stogir.verify.integer-operations-target-structured+0xc40>
    1378:      	str	x0, [sp, #0x348]
    137c:      	ldr	x0, [sp, #0x318]
    1380:      	cmp	x24, #0x21
    1384:      	b.lt	0x1f40 <_stogir.verify.integer-operations-target-structured+0x117c>
    1388:      	cmp	x24, #0x27
    138c:      	b.gt	0x1f4c <_stogir.verify.integer-operations-target-structured+0x1188>
    1390:      	add	x8, sp, #0x180
    1394:      	ldr	w1, [sp, #0x338]
    1398:      	ldr	w2, [sp, #0x230]
    139c:      	str	x0, [sp, #0x318]
    13a0:      	ldr	x0, [sp, #0x2b0]
    13a4:      	bl	0x13a4 <_stogir.verify.integer-operations-target-structured+0x5e0>
		00000000000013a4:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    13a8:      	add	x16, sp, #0x180
    13ac:      	ldr	w0, [x16]
    13b0:      	lsr	x16, x0, #0
    13b4:      	cmp	x16, #0x1
    13b8:      	b.eq	0x13d8 <_stogir.verify.integer-operations-target-structured+0x614>
    13bc:      	b.lo	0x13c4 <_stogir.verify.integer-operations-target-structured+0x600>
    13c0:      	b	0x13dc <_stogir.verify.integer-operations-target-structured+0x618>
    13c4:      	cmp	x16, #0x0
    13c8:      	b.eq	0x13d0 <_stogir.verify.integer-operations-target-structured+0x60c>
    13cc:      	b	0x13dc <_stogir.verify.integer-operations-target-structured+0x618>
    13d0:      	ldr	x0, [sp, #0x320]
    13d4:      	b	0x1a80 <_stogir.verify.integer-operations-target-structured+0xcbc>
    13d8:      	b	0x13e0 <_stogir.verify.integer-operations-target-structured+0x61c>
    13dc:      	b	0x1a90 <_stogir.verify.integer-operations-target-structured+0xccc>
    13e0:      	add	x16, sp, #0x180
    13e4:      	ldr	x19, [x16, #0x8]
    13e8:      	ldr	x0, [sp, #0x320]
    13ec:      	ldr	x22, [x0, #0x8]
    13f0:      	cmp	x24, #0x3c
    13f4:      	b.ne	0x1f58 <_stogir.verify.integer-operations-target-structured+0x1194>
    13f8:      	add	x8, sp, #0x1a0
    13fc:      	ldr	w1, [sp, #0x338]
    1400:      	str	x0, [sp, #0x320]
    1404:      	ldr	x0, [sp, #0x2b0]
    1408:      	bl	0x1408 <_stogir.verify.integer-operations-target-structured+0x644>
		0000000000001408:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    140c:      	add	x16, sp, #0x1a0
    1410:      	ldr	w0, [x16]
    1414:      	lsr	x16, x0, #0
    1418:      	cmp	x16, #0x1
    141c:      	b.eq	0x143c <_stogir.verify.integer-operations-target-structured+0x678>
    1420:      	b.lo	0x1428 <_stogir.verify.integer-operations-target-structured+0x664>
    1424:      	b	0x1440 <_stogir.verify.integer-operations-target-structured+0x67c>
    1428:      	cmp	x16, #0x0
    142c:      	b.eq	0x1434 <_stogir.verify.integer-operations-target-structured+0x670>
    1430:      	b	0x1440 <_stogir.verify.integer-operations-target-structured+0x67c>
    1434:      	ldr	x0, [sp, #0x238]
    1438:      	b	0x1a98 <_stogir.verify.integer-operations-target-structured+0xcd4>
    143c:      	b	0x1444 <_stogir.verify.integer-operations-target-structured+0x680>
    1440:      	b	0x1aa8 <_stogir.verify.integer-operations-target-structured+0xce4>
    1444:      	add	x16, sp, #0x1a0
    1448:      	ldr	x19, [x16, #0x8]
    144c:      	ldr	x0, [sp, #0x238]
    1450:      	ldr	x22, [x0, #0x8]
    1454:      	cmp	x24, #0x78
    1458:      	b.ne	0x1f64 <_stogir.verify.integer-operations-target-structured+0x11a0>
    145c:      	add	x16, sp, #0x20
    1460:      	ldr	w1, [x16]
    1464:      	ubfx	x1, x1, #8, #8
    1468:      	cmp	x1, #0x0
    146c:      	b.ne	0x1ab0 <_stogir.verify.integer-operations-target-structured+0xcec>
    1470:      	add	x16, sp, #0x20
    1474:      	ldr	w1, [x16, #0x8]
    1478:      	sxtw	x1, w1
    147c:      	cmp	x1, #0x0
    1480:      	b.eq	0x148c <_stogir.verify.integer-operations-target-structured+0x6c8>
    1484:      	ldr	x19, [sp, #0x250]
    1488:      	mov	x22, #0x1f              ; =31
    148c:      	str	x0, [sp, #0x238]
    1490:      	add	x0, x23, #0x1
    1494:      	lsr	w0, w0, #0
    1498:      	sxtw	x23, w0
    149c:      	ldr	x0, [sp, #0x340]
    14a0:      	uxth	w0, w0
    14a4:      	mov	w17, #0x8               ; =8
    14a8:      	uxth	w16, w0
    14ac:      	ubfx	w17, w17, #0, #4
    14b0:      	lsr	w0, w16, w17
    14b4:      	uxth	w0, w0
    14b8:      	uxtb	w0, w0
    14bc:      	cmp	x0, #0x0
    14c0:      	b.eq	0x1f6c <_stogir.verify.integer-operations-target-structured+0x11a8>
    14c4:      	add	x8, sp, #0x1f0
    14c8:      	ldr	w1, [sp, #0x338]
    14cc:      	str	x20, [sp, #0x358]
    14d0:      	mov	x20, x0
    14d4:      	ldr	x0, [sp, #0x2b0]
    14d8:      	bl	0x14d8 <_stogir.verify.integer-operations-target-structured+0x714>
		00000000000014d8:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    14dc:      	add	x16, sp, #0x1f0
    14e0:      	ldr	w0, [x16]
    14e4:      	lsr	x16, x0, #0
    14e8:      	cmp	x16, #0x1
    14ec:      	b.eq	0x150c <_stogir.verify.integer-operations-target-structured+0x748>
    14f0:      	b.lo	0x14f8 <_stogir.verify.integer-operations-target-structured+0x734>
    14f4:      	b	0x1510 <_stogir.verify.integer-operations-target-structured+0x74c>
    14f8:      	cmp	x16, #0x0
    14fc:      	b.eq	0x1504 <_stogir.verify.integer-operations-target-structured+0x740>
    1500:      	b	0x1510 <_stogir.verify.integer-operations-target-structured+0x74c>
    1504:      	ldr	x0, [sp, #0x258]
    1508:      	b	0x1b44 <_stogir.verify.integer-operations-target-structured+0xd80>
    150c:      	b	0x1514 <_stogir.verify.integer-operations-target-structured+0x750>
    1510:      	b	0x1b54 <_stogir.verify.integer-operations-target-structured+0xd90>
    1514:      	add	x16, sp, #0x1f0
    1518:      	ldr	x19, [x16, #0x8]
    151c:      	ldr	x0, [sp, #0x258]
    1520:      	ldr	x22, [x0, #0x8]
    1524:      	uxtb	w16, w21
    1528:      	cmp	w16, wzr
    152c:      	b.eq	0x1b5c <_stogir.verify.integer-operations-target-structured+0xd98>
    1530:      	movz	x1, #0x0, lsl #48
    1534:      	cmp	x1, #0x0
    1538:      	b.eq	0x1f7c <_stogir.verify.integer-operations-target-structured+0x11b8>
    153c:      	cmp	x20, #0x0
    1540:      	b.eq	0x1b64 <_stogir.verify.integer-operations-target-structured+0xda0>
    1544:      	movz	x1, #0x0, lsl #48
    1548:      	cmp	x1, #0x0
    154c:      	b.eq	0x1f88 <_stogir.verify.integer-operations-target-structured+0x11c4>
    1550:      	ldr	x20, [sp, #0x330]
    1554:      	cmp	x20, #0x0
    1558:      	b.eq	0x1b6c <_stogir.verify.integer-operations-target-structured+0xda8>
    155c:      	ldr	x21, [sp, #0x310]
    1560:      	mov	x1, #0x1                ; =1
    1564:      	cmp	x1, #0x0
    1568:      	b.eq	0x1f94 <_stogir.verify.integer-operations-target-structured+0x11d0>
    156c:      	add	x16, sp, #0x210
    1570:      	str	x16, [sp]
    1574:      	ldr	w1, [sp, #0x338]
    1578:      	str	x0, [sp, #0x258]
    157c:      	ldr	x0, [sp, #0x2b0]
    1580:      	mov	x2, #0x1                ; =1
    1584:      	bl	0x1584 <_stogir.verify.integer-operations-target-structured+0x7c0>
		0000000000001584:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1588:      	ldr	x16, [sp]
    158c:      	str	x0, [x16]
    1590:      	str	x1, [x16, #0x8]
    1594:      	add	x16, sp, #0x210
    1598:      	ldr	x0, [x16]
    159c:      	add	x16, sp, #0x210
    15a0:      	ldr	x1, [x16, #0x8]
    15a4:      	lsr	w0, w0, #0
    15a8:      	lsr	x16, x0, #0
    15ac:      	cmp	x16, #0x1
    15b0:      	b.eq	0x15cc <_stogir.verify.integer-operations-target-structured+0x808>
    15b4:      	b.lo	0x15bc <_stogir.verify.integer-operations-target-structured+0x7f8>
    15b8:      	b	0x15d0 <_stogir.verify.integer-operations-target-structured+0x80c>
    15bc:      	cmp	x16, #0x0
    15c0:      	b.eq	0x15c8 <_stogir.verify.integer-operations-target-structured+0x804>
    15c4:      	b	0x15d0 <_stogir.verify.integer-operations-target-structured+0x80c>
    15c8:      	b	0x15d4 <_stogir.verify.integer-operations-target-structured+0x810>
    15cc:      	b	0x1b98 <_stogir.verify.integer-operations-target-structured+0xdd4>
    15d0:      	b	0x1e84 <_stogir.verify.integer-operations-target-structured+0x10c0>
    15d4:      	str	x28, [sp, #0x378]
    15d8:      	str	x27, [sp, #0x370]
    15dc:      	str	x26, [sp, #0x368]
    15e0:      	str	x25, [sp, #0x360]
    15e4:      	ldr	x19, [sp, #0x278]
    15e8:      	mov	x22, #0x17              ; =23
    15ec:      	add	x0, x23, #0x1
    15f0:      	lsr	w0, w0, #0
    15f4:      	sxtw	x23, w0
    15f8:      	ldr	w0, [sp, #0x328]
    15fc:      	sxtw	x0, w0
    1600:      	add	x0, x0, #0x4
    1604:      	asr	x16, x0, #63
    1608:      	lsr	x16, x16, #62
    160c:      	add	x0, x0, x16
    1610:      	asr	x0, x0, #2
    1614:      	ldr	x1, [sp, #0x2c8]
    1618:      	add	x1, x0, x1
    161c:      	ldr	x8, [sp, #0x2c0]
    1620:      	ldr	x0, [sp, #0x2b0]
    1624:      	ldr	x6, [sp, #0x2e0]
    1628:      	ldr	x24, [sp, #0x270]
    162c:      	ldr	x25, [sp, #0x278]
    1630:      	ldr	x26, [sp, #0x280]
    1634:      	ldr	x27, [sp, #0x288]
    1638:      	ldr	x28, [sp, #0x290]
    163c:      	ldr	x2, [sp, #0x260]
    1640:      	ldr	w4, [sp, #0x2d0]
    1644:      	ldr	x7, [sp, #0x350]
    1648:      	ldr	x9, [sp, #0x378]
    164c:      	ldr	x10, [sp, #0x370]
    1650:      	ldr	x11, [sp, #0x368]
    1654:      	ldr	x12, [sp, #0x360]
    1658:      	ldr	x13, [sp, #0x348]
    165c:      	ldr	w5, [sp, #0x2d8]
    1660:      	ldr	x14, [sp, #0x318]
    1664:      	ldr	x15, [sp, #0x320]
    1668:      	ldr	x3, [sp, #0x358]
    166c:      	mov	x20, x1
    1670:      	ldr	x1, [sp, #0x258]
    1674:      	mov	x21, x23
    1678:      	ldr	x23, [sp, #0x268]
    167c:      	b	0xf38 <_stogir.verify.integer-operations-target-structured+0x174>
    1680:      	movz	x2, #0x0, lsl #48
    1684:      	b	0xfa4 <_stogir.verify.integer-operations-target-structured+0x1e0>
    1688:      	uxtb	w16, w27
    168c:      	cmp	w16, wzr
    1690:      	b.eq	0x16ac <_stogir.verify.integer-operations-target-structured+0x8e8>
    1694:      	uxtb	w16, w28
    1698:      	cmp	w16, wzr
    169c:      	b.eq	0x16ac <_stogir.verify.integer-operations-target-structured+0x8e8>
    16a0:      	str	w21, [sp, #0x2a8]
    16a4:      	mov	x21, #0x1               ; =1
    16a8:      	b	0x100c <_stogir.verify.integer-operations-target-structured+0x248>
    16ac:      	uxtb	w16, w23
    16b0:      	cmp	w16, wzr
    16b4:      	b.eq	0x16c4 <_stogir.verify.integer-operations-target-structured+0x900>
    16b8:      	str	w21, [sp, #0x2a8]
    16bc:      	mov	x21, #0x1               ; =1
    16c0:      	b	0x16a8 <_stogir.verify.integer-operations-target-structured+0x8e4>
    16c4:      	str	w21, [sp, #0x2a8]
    16c8:      	ubfx	x21, x21, #0, #8
    16cc:      	b	0x16c0 <_stogir.verify.integer-operations-target-structured+0x8fc>
    16d0:      	cmp	x24, #0x20
    16d4:      	b.ne	0x16e4 <_stogir.verify.integer-operations-target-structured+0x920>
    16d8:      	str	x0, [sp, #0x2b0]
    16dc:      	mov	x0, #0x1                ; =1
    16e0:      	b	0x101c <_stogir.verify.integer-operations-target-structured+0x258>
    16e4:      	cmp	x24, #0x2d
    16e8:      	b.ne	0x16f8 <_stogir.verify.integer-operations-target-structured+0x934>
    16ec:      	str	x0, [sp, #0x2b0]
    16f0:      	mov	x0, #0x1                ; =1
    16f4:      	b	0x16e0 <_stogir.verify.integer-operations-target-structured+0x91c>
    16f8:      	cmp	x24, #0x36
    16fc:      	b.ne	0x170c <_stogir.verify.integer-operations-target-structured+0x948>
    1700:      	str	x0, [sp, #0x2b0]
    1704:      	mov	x0, #0x1                ; =1
    1708:      	b	0x16f4 <_stogir.verify.integer-operations-target-structured+0x930>
    170c:      	cmp	x24, #0x37
    1710:      	b.ne	0x1720 <_stogir.verify.integer-operations-target-structured+0x95c>
    1714:      	str	x0, [sp, #0x2b0]
    1718:      	mov	x0, #0x1                ; =1
    171c:      	b	0x1708 <_stogir.verify.integer-operations-target-structured+0x944>
    1720:      	cmp	x24, #0x38
    1724:      	b.ne	0x1734 <_stogir.verify.integer-operations-target-structured+0x970>
    1728:      	str	x0, [sp, #0x2b0]
    172c:      	mov	x0, #0x1                ; =1
    1730:      	b	0x171c <_stogir.verify.integer-operations-target-structured+0x958>
    1734:      	str	x0, [sp, #0x2b0]
    1738:      	cmp	x24, #0x39
    173c:      	cset	w0, eq
    1740:      	ubfx	x0, x0, #0, #8
    1744:      	b	0x1730 <_stogir.verify.integer-operations-target-structured+0x96c>
    1748:      	uxtb	w16, w1
    174c:      	cmp	w16, wzr
    1750:      	b.ne	0x10b8 <_stogir.verify.integer-operations-target-structured+0x2f4>
    1754:      	str	x0, [sp, #0x340]
    1758:      	str	x21, [sp, #0x348]
    175c:      	mov	w21, w1
    1760:      	ldr	x0, [sp, #0x2a0]
    1764:      	b	0x111c <_stogir.verify.integer-operations-target-structured+0x358>
    1768:      	ldr	x0, [sp, #0x2a0]
    176c:      	add	x0, x0, #0x1
    1770:      	lsr	w0, w0, #0
    1774:      	sxtw	x0, w0
    1778:      	b	0x111c <_stogir.verify.integer-operations-target-structured+0x358>
    177c:      	mov	x1, #0x1                ; =1
    1780:      	b	0x1134 <_stogir.verify.integer-operations-target-structured+0x370>
    1784:      	movz	x1, #0x0, lsl #48
    1788:      	b	0x1134 <_stogir.verify.integer-operations-target-structured+0x370>
    178c:      	add	x0, x23, #0x1
    1790:      	lsr	w0, w0, #0
    1794:      	sxtw	x23, w0
    1798:      	b	0x1194 <_stogir.verify.integer-operations-target-structured+0x3d0>
    179c:      	brk	#0
    17a0:      	b	0x179c <_stogir.verify.integer-operations-target-structured+0x9d8>
    17a4:      	cmp	x24, #0x1e
    17a8:      	cset	w0, eq
    17ac:      	ubfx	x0, x0, #0, #8
    17b0:      	b	0x11a0 <_stogir.verify.integer-operations-target-structured+0x3dc>
    17b4:      	mov	x0, #0x1                ; =1
    17b8:      	b	0x11c0 <_stogir.verify.integer-operations-target-structured+0x3fc>
    17bc:      	movz	x0, #0x0, lsl #48
    17c0:      	b	0x11c0 <_stogir.verify.integer-operations-target-structured+0x3fc>
    17c4:      	add	x16, sp, #0x70
    17c8:      	ldr	x0, [x16, #0x8]
    17cc:      	add	x16, sp, #0x20
    17d0:      	ldr	w1, [x16, #0xc]
    17d4:      	sxtw	x1, w1
    17d8:      	cmp	x1, #0x0
    17dc:      	b.ge	0x17f8 <_stogir.verify.integer-operations-target-structured+0xa34>
    17e0:      	mov	x0, #0x1                ; =1
    17e4:      	cmp	x0, #0x0
    17e8:      	b.eq	0x17f4 <_stogir.verify.integer-operations-target-structured+0xa30>
    17ec:      	ldr	x19, [sp, #0x248]
    17f0:      	mov	x22, #0x2d              ; =45
    17f4:      	b	0x1220 <_stogir.verify.integer-operations-target-structured+0x45c>
    17f8:      	uxtb	w0, w0
    17fc:      	cmp	x0, #0x83
    1800:      	b.ge	0x184c <_stogir.verify.integer-operations-target-structured+0xa88>
    1804:      	add	x1, x0, x20
    1808:      	ldrb	w1, [x1]
    180c:      	uxtb	w1, w1
    1810:      	and	x1, x1, #0x2
    1814:      	uxtb	w1, w1
    1818:      	cmp	x1, #0x0
    181c:      	cset	w1, eq
    1820:      	uxtb	w16, w1
    1824:      	cmp	w16, wzr
    1828:      	cset	x1, eq
    182c:      	cmp	x1, #0x0
    1830:      	b.ne	0x1854 <_stogir.verify.integer-operations-target-structured+0xa90>
    1834:      	cmp	x0, #0x65
    1838:      	b.eq	0x1854 <_stogir.verify.integer-operations-target-structured+0xa90>
    183c:      	cmp	x0, #0x66
    1840:      	b.eq	0x1854 <_stogir.verify.integer-operations-target-structured+0xa90>
    1844:      	mov	x0, #0x1                ; =1
    1848:      	b	0x17e4 <_stogir.verify.integer-operations-target-structured+0xa20>
    184c:      	movz	x1, #0x0, lsl #48
    1850:      	b	0x180c <_stogir.verify.integer-operations-target-structured+0xa48>
    1854:      	movz	x0, #0x0, lsl #48
    1858:      	b	0x1848 <_stogir.verify.integer-operations-target-structured+0xa84>
    185c:      	brk	#0
    1860:      	b	0x185c <_stogir.verify.integer-operations-target-structured+0xa98>
    1864:      	uxtb	w16, w0
    1868:      	cmp	w16, wzr
    186c:      	b.ne	0x1238 <_stogir.verify.integer-operations-target-structured+0x474>
    1870:      	b	0x12a4 <_stogir.verify.integer-operations-target-structured+0x4e0>
    1874:      	add	x8, sp, #0xc0
    1878:      	ldr	x0, [sp, #0x2b0]
    187c:      	ldr	w1, [sp, #0x338]
    1880:      	bl	0x1880 <_stogir.verify.integer-operations-target-structured+0xabc>
		0000000000001880:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1884:      	add	x16, sp, #0xc0
    1888:      	ldr	x0, [x16]
    188c:      	add	x16, sp, #0xc0
    1890:      	ldr	x1, [x16, #0x8]
    1894:      	add	x16, sp, #0xc0
    1898:      	ldr	x2, [x16, #0x10]
    189c:      	b	0x126c <_stogir.verify.integer-operations-target-structured+0x4a8>
    18a0:      	add	x0, x23, #0x1
    18a4:      	lsr	w0, w0, #0
    18a8:      	sxtw	x23, w0
    18ac:      	b	0x12a4 <_stogir.verify.integer-operations-target-structured+0x4e0>
    18b0:      	add	x0, x23, #0x1
    18b4:      	lsr	w0, w0, #0
    18b8:      	sxtw	x23, w0
    18bc:      	b	0x1304 <_stogir.verify.integer-operations-target-structured+0x540>
    18c0:      	brk	#0
    18c4:      	b	0x18c0 <_stogir.verify.integer-operations-target-structured+0xafc>
    18c8:      	add	x8, sp, #0x100
    18cc:      	ldr	x0, [sp, #0x2b0]
    18d0:      	ldr	w1, [sp, #0x338]
    18d4:      	bl	0x18d4 <_stogir.verify.integer-operations-target-structured+0xb10>
		00000000000018d4:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    18d8:      	add	x16, sp, #0x100
    18dc:      	ldr	w0, [x16]
    18e0:      	lsr	x16, x0, #0
    18e4:      	cmp	x16, #0x1
    18e8:      	b.eq	0x1904 <_stogir.verify.integer-operations-target-structured+0xb40>
    18ec:      	b.lo	0x18f4 <_stogir.verify.integer-operations-target-structured+0xb30>
    18f0:      	b	0x1908 <_stogir.verify.integer-operations-target-structured+0xb44>
    18f4:      	cmp	x16, #0x0
    18f8:      	b.eq	0x1900 <_stogir.verify.integer-operations-target-structured+0xb3c>
    18fc:      	b	0x1908 <_stogir.verify.integer-operations-target-structured+0xb44>
    1900:      	b	0x191c <_stogir.verify.integer-operations-target-structured+0xb58>
    1904:      	b	0x190c <_stogir.verify.integer-operations-target-structured+0xb48>
    1908:      	b	0x1e94 <_stogir.verify.integer-operations-target-structured+0x10d0>
    190c:      	add	x16, sp, #0x100
    1910:      	ldr	x19, [x16, #0x8]
    1914:      	ldr	x22, [x26, #0x8]
    1918:      	b	0x1314 <_stogir.verify.integer-operations-target-structured+0x550>
    191c:      	add	x0, x23, #0x1
    1920:      	lsr	w0, w0, #0
    1924:      	sxtw	x23, w0
    1928:      	b	0x1918 <_stogir.verify.integer-operations-target-structured+0xb54>
    192c:      	add	x8, sp, #0x120
    1930:      	ldr	x0, [sp, #0x2b0]
    1934:      	ldr	w1, [sp, #0x338]
    1938:      	bl	0x1938 <_stogir.verify.integer-operations-target-structured+0xb74>
		0000000000001938:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    193c:      	add	x16, sp, #0x120
    1940:      	ldr	w0, [x16]
    1944:      	lsr	x16, x0, #0
    1948:      	cmp	x16, #0x1
    194c:      	b.eq	0x1968 <_stogir.verify.integer-operations-target-structured+0xba4>
    1950:      	b.lo	0x1958 <_stogir.verify.integer-operations-target-structured+0xb94>
    1954:      	b	0x196c <_stogir.verify.integer-operations-target-structured+0xba8>
    1958:      	cmp	x16, #0x0
    195c:      	b.eq	0x1964 <_stogir.verify.integer-operations-target-structured+0xba0>
    1960:      	b	0x196c <_stogir.verify.integer-operations-target-structured+0xba8>
    1964:      	b	0x1980 <_stogir.verify.integer-operations-target-structured+0xbbc>
    1968:      	b	0x1970 <_stogir.verify.integer-operations-target-structured+0xbac>
    196c:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xbcc>
    1970:      	add	x16, sp, #0x120
    1974:      	ldr	x19, [x16, #0x8]
    1978:      	ldr	x22, [x25, #0x8]
    197c:      	b	0x132c <_stogir.verify.integer-operations-target-structured+0x568>
    1980:      	add	x0, x23, #0x1
    1984:      	lsr	w0, w0, #0
    1988:      	sxtw	x23, w0
    198c:      	b	0x197c <_stogir.verify.integer-operations-target-structured+0xbb8>
    1990:      	brk	#0
    1994:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xbcc>
    1998:      	add	x8, sp, #0x140
    199c:      	ldr	x0, [sp, #0x2b0]
    19a0:      	ldr	w1, [sp, #0x338]
    19a4:      	bl	0x19a4 <_stogir.verify.integer-operations-target-structured+0xbe0>
		00000000000019a4:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    19a8:      	add	x16, sp, #0x140
    19ac:      	ldr	w0, [x16]
    19b0:      	lsr	x16, x0, #0
    19b4:      	cmp	x16, #0x1
    19b8:      	b.eq	0x19d8 <_stogir.verify.integer-operations-target-structured+0xc14>
    19bc:      	b.lo	0x19c4 <_stogir.verify.integer-operations-target-structured+0xc00>
    19c0:      	b	0x19dc <_stogir.verify.integer-operations-target-structured+0xc18>
    19c4:      	cmp	x16, #0x0
    19c8:      	b.eq	0x19d0 <_stogir.verify.integer-operations-target-structured+0xc0c>
    19cc:      	b	0x19dc <_stogir.verify.integer-operations-target-structured+0xc18>
    19d0:      	ldr	x0, [sp, #0x348]
    19d4:      	b	0x19f4 <_stogir.verify.integer-operations-target-structured+0xc30>
    19d8:      	b	0x19e0 <_stogir.verify.integer-operations-target-structured+0xc1c>
    19dc:      	b	0x1e8c <_stogir.verify.integer-operations-target-structured+0x10c8>
    19e0:      	add	x16, sp, #0x140
    19e4:      	ldr	x19, [x16, #0x8]
    19e8:      	ldr	x0, [sp, #0x348]
    19ec:      	ldr	x22, [x0, #0x8]
    19f0:      	b	0x1358 <_stogir.verify.integer-operations-target-structured+0x594>
    19f4:      	add	x1, x23, #0x1
    19f8:      	lsr	w1, w1, #0
    19fc:      	sxtw	x23, w1
    1a00:      	b	0x19f0 <_stogir.verify.integer-operations-target-structured+0xc2c>
    1a04:      	add	x8, sp, #0x160
    1a08:      	ldr	w1, [sp, #0x338]
    1a0c:      	ldr	w2, [sp, #0x2d8]
    1a10:      	str	x0, [sp, #0x348]
    1a14:      	ldr	x0, [sp, #0x2b0]
    1a18:      	bl	0x1a18 <_stogir.verify.integer-operations-target-structured+0xc54>
		0000000000001a18:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1a1c:      	add	x16, sp, #0x160
    1a20:      	ldr	w0, [x16]
    1a24:      	lsr	x16, x0, #0
    1a28:      	cmp	x16, #0x1
    1a2c:      	b.eq	0x1a4c <_stogir.verify.integer-operations-target-structured+0xc88>
    1a30:      	b.lo	0x1a38 <_stogir.verify.integer-operations-target-structured+0xc74>
    1a34:      	b	0x1a50 <_stogir.verify.integer-operations-target-structured+0xc8c>
    1a38:      	cmp	x16, #0x0
    1a3c:      	b.eq	0x1a44 <_stogir.verify.integer-operations-target-structured+0xc80>
    1a40:      	b	0x1a50 <_stogir.verify.integer-operations-target-structured+0xc8c>
    1a44:      	ldr	x0, [sp, #0x318]
    1a48:      	b	0x1a68 <_stogir.verify.integer-operations-target-structured+0xca4>
    1a4c:      	b	0x1a54 <_stogir.verify.integer-operations-target-structured+0xc90>
    1a50:      	b	0x1a78 <_stogir.verify.integer-operations-target-structured+0xcb4>
    1a54:      	add	x16, sp, #0x160
    1a58:      	ldr	x19, [x16, #0x8]
    1a5c:      	ldr	x0, [sp, #0x318]
    1a60:      	ldr	x22, [x0, #0x8]
    1a64:      	b	0x1380 <_stogir.verify.integer-operations-target-structured+0x5bc>
    1a68:      	add	x1, x23, #0x1
    1a6c:      	lsr	w1, w1, #0
    1a70:      	sxtw	x23, w1
    1a74:      	b	0x1a64 <_stogir.verify.integer-operations-target-structured+0xca0>
    1a78:      	brk	#0
    1a7c:      	b	0x1a78 <_stogir.verify.integer-operations-target-structured+0xcb4>
    1a80:      	add	x1, x23, #0x1
    1a84:      	lsr	w1, w1, #0
    1a88:      	sxtw	x23, w1
    1a8c:      	b	0x13f0 <_stogir.verify.integer-operations-target-structured+0x62c>
    1a90:      	brk	#0
    1a94:      	b	0x1a90 <_stogir.verify.integer-operations-target-structured+0xccc>
    1a98:      	add	x1, x23, #0x1
    1a9c:      	lsr	w1, w1, #0
    1aa0:      	sxtw	x23, w1
    1aa4:      	b	0x1454 <_stogir.verify.integer-operations-target-structured+0x690>
    1aa8:      	brk	#0
    1aac:      	b	0x1aa8 <_stogir.verify.integer-operations-target-structured+0xce4>
    1ab0:      	add	x16, sp, #0x20
    1ab4:      	ldr	w1, [x16, #0x8]
    1ab8:      	lsr	w1, w1, #0
    1abc:      	add	x8, sp, #0x1c0
    1ac0:      	str	x0, [sp, #0x238]
    1ac4:      	ldr	x0, [sp, #0x2b0]
    1ac8:      	bl	0x1ac8 <_stogir.verify.integer-operations-target-structured+0xd04>
		0000000000001ac8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1acc:      	add	x16, sp, #0x1c0
    1ad0:      	ldr	w0, [x16]
    1ad4:      	lsr	x16, x0, #0
    1ad8:      	cmp	x16, #0x1
    1adc:      	b.eq	0x1af8 <_stogir.verify.integer-operations-target-structured+0xd34>
    1ae0:      	b.lo	0x1ae8 <_stogir.verify.integer-operations-target-structured+0xd24>
    1ae4:      	b	0x1afc <_stogir.verify.integer-operations-target-structured+0xd38>
    1ae8:      	cmp	x16, #0x0
    1aec:      	b.eq	0x1af4 <_stogir.verify.integer-operations-target-structured+0xd30>
    1af0:      	b	0x1afc <_stogir.verify.integer-operations-target-structured+0xd38>
    1af4:      	b	0x1b00 <_stogir.verify.integer-operations-target-structured+0xd3c>
    1af8:      	b	0x1b0c <_stogir.verify.integer-operations-target-structured+0xd48>
    1afc:      	b	0x1b3c <_stogir.verify.integer-operations-target-structured+0xd78>
    1b00:      	ldr	x19, [sp, #0x268]
    1b04:      	mov	x22, #0x14              ; =20
    1b08:      	b	0x1490 <_stogir.verify.integer-operations-target-structured+0x6cc>
    1b0c:      	add	x16, sp, #0x1c0
    1b10:      	ldr	x0, [x16, #0x8]
    1b14:      	add	x16, sp, #0x20
    1b18:      	ldr	w1, [x16]
    1b1c:      	lsr	w0, w0, #0
    1b20:      	ubfx	x1, x1, #8, #8
    1b24:      	ubfx	x0, x0, #8, #8
    1b28:      	cmp	x0, x1
    1b2c:      	b.eq	0x1b38 <_stogir.verify.integer-operations-target-structured+0xd74>
    1b30:      	ldr	x19, [sp, #0x270]
    1b34:      	mov	x22, #0x1a              ; =26
    1b38:      	b	0x1b08 <_stogir.verify.integer-operations-target-structured+0xd44>
    1b3c:      	brk	#0
    1b40:      	b	0x1b3c <_stogir.verify.integer-operations-target-structured+0xd78>
    1b44:      	add	x1, x23, #0x1
    1b48:      	lsr	w1, w1, #0
    1b4c:      	sxtw	x23, w1
    1b50:      	b	0x1524 <_stogir.verify.integer-operations-target-structured+0x760>
    1b54:      	brk	#0
    1b58:      	b	0x1b54 <_stogir.verify.integer-operations-target-structured+0xd90>
    1b5c:      	mov	x1, #0x1                ; =1
    1b60:      	b	0x1534 <_stogir.verify.integer-operations-target-structured+0x770>
    1b64:      	mov	x1, #0x1                ; =1
    1b68:      	b	0x1548 <_stogir.verify.integer-operations-target-structured+0x784>
    1b6c:      	ldr	x21, [sp, #0x310]
    1b70:      	cmp	x21, #0x0
    1b74:      	b.eq	0x1b80 <_stogir.verify.integer-operations-target-structured+0xdbc>
    1b78:      	mov	x1, #0x1                ; =1
    1b7c:      	b	0x1564 <_stogir.verify.integer-operations-target-structured+0x7a0>
    1b80:      	ldr	x1, [sp, #0x2b8]
    1b84:      	b	0x1b7c <_stogir.verify.integer-operations-target-structured+0xdb8>
    1b88:      	movz	x1, #0x0, lsl #48
    1b8c:      	b	0x1564 <_stogir.verify.integer-operations-target-structured+0x7a0>
    1b90:      	movz	x1, #0x0, lsl #48
    1b94:      	b	0x1564 <_stogir.verify.integer-operations-target-structured+0x7a0>
    1b98:      	lsr	w1, w1, #0
    1b9c:      	lsr	w1, w1, #0
    1ba0:      	ldr	x0, [sp, #0x2b0]
    1ba4:      	bl	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xde0>
		0000000000001ba4:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1ba8:      	cmp	x0, #0x0
    1bac:      	b.ne	0x1bcc <_stogir.verify.integer-operations-target-structured+0xe08>
    1bb0:      	str	x28, [sp, #0x378]
    1bb4:      	str	x27, [sp, #0x370]
    1bb8:      	str	x26, [sp, #0x368]
    1bbc:      	str	x25, [sp, #0x360]
    1bc0:      	ldr	x19, [sp, #0x278]
    1bc4:      	mov	x22, #0x17              ; =23
    1bc8:      	b	0x15ec <_stogir.verify.integer-operations-target-structured+0x828>
    1bcc:      	ldr	w0, [x0]
    1bd0:      	add	x16, sp, #0x20
    1bd4:      	ldr	w1, [x16]
    1bd8:      	ubfx	x0, x0, #8, #8
    1bdc:      	orr	x2, x0, xzr
    1be0:      	ubfx	x1, x1, #8, #8
    1be4:      	cmp	x1, #0x6
    1be8:      	b.ne	0x1d48 <_stogir.verify.integer-operations-target-structured+0xf84>
    1bec:      	cmp	x2, #0x6
    1bf0:      	b.ne	0x1d40 <_stogir.verify.integer-operations-target-structured+0xf7c>
    1bf4:      	cmp	x24, #0x1a
    1bf8:      	b.ne	0x1d30 <_stogir.verify.integer-operations-target-structured+0xf6c>
    1bfc:      	mov	x1, #0x1                ; =1
    1c00:      	cmp	x2, #0x1
    1c04:      	cset	w3, ge
    1c08:      	uxtb	w16, w3
    1c0c:      	cmp	w16, wzr
    1c10:      	b.eq	0x1fac <_stogir.verify.integer-operations-target-structured+0x11e8>
    1c14:      	cmp	x2, #0xb
    1c18:      	cset	w4, le
    1c1c:      	uxtb	w16, w4
    1c20:      	cmp	w16, wzr
    1c24:      	b.eq	0x1fc8 <_stogir.verify.integer-operations-target-structured+0x1204>
    1c28:      	ldr	x5, [sp, #0x2b8]
    1c2c:      	cmp	x5, #0x0
    1c30:      	b.eq	0x1fe4 <_stogir.verify.integer-operations-target-structured+0x1220>
    1c34:      	ldr	w5, [sp, #0x298]
    1c38:      	lsr	w5, w5, #0
    1c3c:      	lsr	w0, w0, #0
    1c40:      	str	x25, [sp, #0x360]
    1c44:      	mov	x25, x2
    1c48:      	str	x26, [sp, #0x368]
    1c4c:      	mov	x26, x1
    1c50:      	mov	w1, w0
    1c54:      	mov	w0, w5
    1c58:      	str	x27, [sp, #0x370]
    1c5c:      	mov	w27, w3
    1c60:      	str	x28, [sp, #0x378]
    1c64:      	mov	w28, w4
    1c68:      	bl	0x1c68 <_stogir.verify.integer-operations-target-structured+0xea4>
		0000000000001c68:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1c6c:      	cmp	x0, #0x0
    1c70:      	b.ne	0x1d50 <_stogir.verify.integer-operations-target-structured+0xf8c>
    1c74:      	ldr	x19, [sp, #0x280]
    1c78:      	mov	x22, #0x1c              ; =28
    1c7c:      	add	x16, sp, #0x20
    1c80:      	ldr	w0, [x16]
    1c84:      	cmp	x20, #0x0
    1c88:      	b.eq	0x1e18 <_stogir.verify.integer-operations-target-structured+0x1054>
    1c8c:      	mov	x1, #0x1                ; =1
    1c90:      	lsr	w1, w1, #0
    1c94:      	ubfx	x0, x0, #8, #8
    1c98:      	sxtw	x1, w1
    1c9c:      	cmp	x0, x1
    1ca0:      	b.eq	0x1cac <_stogir.verify.integer-operations-target-structured+0xee8>
    1ca4:      	ldr	x19, [sp, #0x288]
    1ca8:      	mov	x22, #0x26              ; =38
    1cac:      	cmp	x20, #0x0
    1cb0:      	b.eq	0x1cb8 <_stogir.verify.integer-operations-target-structured+0xef4>
    1cb4:      	mov	x21, #0x1               ; =1
    1cb8:      	cmp	x21, #0x0
    1cbc:      	b.eq	0x1d2c <_stogir.verify.integer-operations-target-structured+0xf68>
    1cc0:      	add	x16, sp, #0x220
    1cc4:      	str	x16, [sp]
    1cc8:      	ldr	x0, [sp, #0x2b0]
    1ccc:      	ldr	w1, [sp, #0x338]
    1cd0:      	mov	x2, #0x2                ; =2
    1cd4:      	bl	0x1cd4 <_stogir.verify.integer-operations-target-structured+0xf10>
		0000000000001cd4:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1cd8:      	ldr	x16, [sp]
    1cdc:      	str	x0, [x16]
    1ce0:      	str	x1, [x16, #0x8]
    1ce4:      	add	x16, sp, #0x220
    1ce8:      	ldr	x0, [x16]
    1cec:      	add	x16, sp, #0x220
    1cf0:      	ldr	x1, [x16, #0x8]
    1cf4:      	lsr	w0, w0, #0
    1cf8:      	lsr	x16, x0, #0
    1cfc:      	cmp	x16, #0x1
    1d00:      	b.eq	0x1d1c <_stogir.verify.integer-operations-target-structured+0xf58>
    1d04:      	b.lo	0x1d0c <_stogir.verify.integer-operations-target-structured+0xf48>
    1d08:      	b	0x1d20 <_stogir.verify.integer-operations-target-structured+0xf5c>
    1d0c:      	cmp	x16, #0x0
    1d10:      	b.eq	0x1d18 <_stogir.verify.integer-operations-target-structured+0xf54>
    1d14:      	b	0x1d20 <_stogir.verify.integer-operations-target-structured+0xf5c>
    1d18:      	b	0x1d24 <_stogir.verify.integer-operations-target-structured+0xf60>
    1d1c:      	b	0x1e20 <_stogir.verify.integer-operations-target-structured+0x105c>
    1d20:      	b	0x1e7c <_stogir.verify.integer-operations-target-structured+0x10b8>
    1d24:      	ldr	x19, [sp, #0x290]
    1d28:      	mov	x22, #0x1d              ; =29
    1d2c:      	b	0x1bc8 <_stogir.verify.integer-operations-target-structured+0xe04>
    1d30:      	cmp	x24, #0x1b
    1d34:      	cset	w1, eq
    1d38:      	ubfx	x1, x1, #0, #8
    1d3c:      	b	0x1c00 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1d40:      	movz	x1, #0x0, lsl #48
    1d44:      	b	0x1c00 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1d48:      	movz	x1, #0x0, lsl #48
    1d4c:      	b	0x1c00 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1d50:      	cmp	x21, #0x0
    1d54:      	b.eq	0x1c7c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1d58:      	ldr	w0, [sp, #0x308]
    1d5c:      	uxtb	w16, w0
    1d60:      	cmp	w16, wzr
    1d64:      	b.eq	0x1dcc <_stogir.verify.integer-operations-target-structured+0x1008>
    1d68:      	ldr	w0, [sp, #0x300]
    1d6c:      	uxtb	w16, w0
    1d70:      	cmp	w16, wzr
    1d74:      	b.eq	0x1dcc <_stogir.verify.integer-operations-target-structured+0x1008>
    1d78:      	ldr	w0, [sp, #0x2e8]
    1d7c:      	uxtb	w16, w27
    1d80:      	cmp	w16, wzr
    1d84:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1d88:      	uxtb	w16, w28
    1d8c:      	cmp	w16, wzr
    1d90:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1d94:      	cmp	x25, #0x1
    1d98:      	b.ne	0x1c7c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1d9c:      	cmp	x24, #0x2e
    1da0:      	b.eq	0x1c7c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1da4:      	cmp	x24, #0x2f
    1da8:      	b.eq	0x1c7c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1dac:      	cmp	x24, #0x30
    1db0:      	b.eq	0x1c7c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1db4:      	uxtb	w16, w0
    1db8:      	cmp	w16, wzr
    1dbc:      	b.ne	0x1c7c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1dc0:      	cmp	x24, #0x3b
    1dc4:      	b.ne	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1dc8:      	b	0x1c7c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1dcc:      	ldr	w0, [sp, #0x2f8]
    1dd0:      	uxtb	w16, w0
    1dd4:      	cmp	w16, wzr
    1dd8:      	b.eq	0x1df4 <_stogir.verify.integer-operations-target-structured+0x1030>
    1ddc:      	ldr	w0, [sp, #0x2f0]
    1de0:      	uxtb	w16, w0
    1de4:      	cmp	w16, wzr
    1de8:      	b.eq	0x1df4 <_stogir.verify.integer-operations-target-structured+0x1030>
    1dec:      	ldr	w0, [sp, #0x2e8]
    1df0:      	b	0x1d7c <_stogir.verify.integer-operations-target-structured+0xfb8>
    1df4:      	ldr	w0, [sp, #0x2e8]
    1df8:      	uxtb	w16, w0
    1dfc:      	cmp	w16, wzr
    1e00:      	b.ne	0x1d7c <_stogir.verify.integer-operations-target-structured+0xfb8>
    1e04:      	ldr	w1, [sp, #0x2a8]
    1e08:      	uxtb	w16, w1
    1e0c:      	cmp	w16, wzr
    1e10:      	b.ne	0x1d7c <_stogir.verify.integer-operations-target-structured+0xfb8>
    1e14:      	b	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1e18:      	mov	x1, x25
    1e1c:      	b	0x1c90 <_stogir.verify.integer-operations-target-structured+0xecc>
    1e20:      	lsr	w1, w1, #0
    1e24:      	lsr	w1, w1, #0
    1e28:      	ldr	x0, [sp, #0x2b0]
    1e2c:      	bl	0x1e2c <_stogir.verify.integer-operations-target-structured+0x1068>
		0000000000001e2c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1e30:      	cmp	x0, #0x0
    1e34:      	b.ne	0x1e44 <_stogir.verify.integer-operations-target-structured+0x1080>
    1e38:      	ldr	x19, [sp, #0x290]
    1e3c:      	mov	x22, #0x1d              ; =29
    1e40:      	b	0x1d2c <_stogir.verify.integer-operations-target-structured+0xf68>
    1e44:      	ldr	w0, [x0]
    1e48:      	ubfx	x0, x0, #8, #8
    1e4c:      	cmp	x25, x0
    1e50:      	b.eq	0x1e6c <_stogir.verify.integer-operations-target-structured+0x10a8>
    1e54:      	cmp	x26, #0x0
    1e58:      	b.eq	0x1e70 <_stogir.verify.integer-operations-target-structured+0x10ac>
    1e5c:      	cmp	x0, #0x5
    1e60:      	b.eq	0x1e6c <_stogir.verify.integer-operations-target-structured+0x10a8>
    1e64:      	cmp	x0, #0xb
    1e68:      	b.ne	0x1e70 <_stogir.verify.integer-operations-target-structured+0x10ac>
    1e6c:      	b	0x1e40 <_stogir.verify.integer-operations-target-structured+0x107c>
    1e70:      	ldr	x19, [sp, #0x260]
    1e74:      	mov	x22, #0x1d              ; =29
    1e78:      	b	0x1e6c <_stogir.verify.integer-operations-target-structured+0x10a8>
    1e7c:      	brk	#0
    1e80:      	b	0x1e7c <_stogir.verify.integer-operations-target-structured+0x10b8>
    1e84:      	brk	#0
    1e88:      	b	0x1e84 <_stogir.verify.integer-operations-target-structured+0x10c0>
    1e8c:      	brk	#0
    1e90:      	b	0x1e8c <_stogir.verify.integer-operations-target-structured+0x10c8>
    1e94:      	brk	#0
    1e98:      	b	0x1e94 <_stogir.verify.integer-operations-target-structured+0x10d0>
    1e9c:      	brk	#0
    1ea0:      	b	0x1e9c <_stogir.verify.integer-operations-target-structured+0x10d8>
    1ea4:      	brk	#0
    1ea8:      	b	0x1ea4 <_stogir.verify.integer-operations-target-structured+0x10e0>
    1eac:      	cmp	x22, #0x0
    1eb0:      	b.ne	0x1f08 <_stogir.verify.integer-operations-target-structured+0x1144>
    1eb4:      	and	x19, x23, #0xffffffff
    1eb8:      	movz	x0, #0x0, lsl #48
    1ebc:      	movz	x22, #0x0, lsl #48
    1ec0:      	ldr	x1, [sp, #0x2c0]
    1ec4:      	str	x0, [x1]
    1ec8:      	str	x19, [x1, #0x8]
    1ecc:      	str	x22, [x1, #0x10]
    1ed0:      	ldr	x19, [sp, #0x380]
    1ed4:      	ldr	x20, [sp, #0x388]
    1ed8:      	ldr	x21, [sp, #0x390]
    1edc:      	ldr	x22, [sp, #0x398]
    1ee0:      	ldr	x23, [sp, #0x3a0]
    1ee4:      	ldr	x24, [sp, #0x3a8]
    1ee8:      	ldr	x25, [sp, #0x3b0]
    1eec:      	ldr	x26, [sp, #0x3b8]
    1ef0:      	ldr	x27, [sp, #0x3c0]
    1ef4:      	ldr	x28, [sp, #0x3c8]
    1ef8:      	ldr	x29, [sp, #0x10]
    1efc:      	ldr	x30, [sp, #0x18]
    1f00:      	add	sp, sp, #0x3d0
    1f04:      	ret
    1f08:      	mov	x0, #0x1                ; =1
    1f0c:      	b	0x1ec0 <_stogir.verify.integer-operations-target-structured+0x10fc>
    1f10:      	mov	x23, x21
    1f14:      	str	x8, [sp, #0x2c0]
    1f18:      	b	0x1eac <_stogir.verify.integer-operations-target-structured+0x10e8>
    1f1c:      	mov	x23, x21
    1f20:      	str	x8, [sp, #0x2c0]
    1f24:      	b	0x1eac <_stogir.verify.integer-operations-target-structured+0x10e8>
    1f28:      	str	x23, [sp, #0x350]
    1f2c:      	mov	x23, x0
    1f30:      	b	0x1194 <_stogir.verify.integer-operations-target-structured+0x3d0>
    1f34:      	str	x0, [sp, #0x348]
    1f38:      	ldr	x0, [sp, #0x318]
    1f3c:      	b	0x1380 <_stogir.verify.integer-operations-target-structured+0x5bc>
    1f40:      	str	x0, [sp, #0x318]
    1f44:      	ldr	x0, [sp, #0x320]
    1f48:      	b	0x13f0 <_stogir.verify.integer-operations-target-structured+0x62c>
    1f4c:      	str	x0, [sp, #0x318]
    1f50:      	ldr	x0, [sp, #0x320]
    1f54:      	b	0x13f0 <_stogir.verify.integer-operations-target-structured+0x62c>
    1f58:      	str	x0, [sp, #0x320]
    1f5c:      	ldr	x0, [sp, #0x238]
    1f60:      	b	0x1454 <_stogir.verify.integer-operations-target-structured+0x690>
    1f64:      	str	x0, [sp, #0x238]
    1f68:      	b	0x149c <_stogir.verify.integer-operations-target-structured+0x6d8>
    1f6c:      	str	x20, [sp, #0x358]
    1f70:      	mov	x20, x0
    1f74:      	ldr	x0, [sp, #0x258]
    1f78:      	b	0x1524 <_stogir.verify.integer-operations-target-structured+0x760>
    1f7c:      	ldr	x20, [sp, #0x330]
    1f80:      	ldr	x21, [sp, #0x310]
    1f84:      	b	0x1b90 <_stogir.verify.integer-operations-target-structured+0xdcc>
    1f88:      	ldr	x20, [sp, #0x330]
    1f8c:      	ldr	x21, [sp, #0x310]
    1f90:      	b	0x1b88 <_stogir.verify.integer-operations-target-structured+0xdc4>
    1f94:      	str	x28, [sp, #0x378]
    1f98:      	str	x27, [sp, #0x370]
    1f9c:      	str	x26, [sp, #0x368]
    1fa0:      	str	x25, [sp, #0x360]
    1fa4:      	str	x0, [sp, #0x258]
    1fa8:      	b	0x15f8 <_stogir.verify.integer-operations-target-structured+0x834>
    1fac:      	str	x28, [sp, #0x378]
    1fb0:      	str	x27, [sp, #0x370]
    1fb4:      	str	x26, [sp, #0x368]
    1fb8:      	mov	x26, x1
    1fbc:      	str	x25, [sp, #0x360]
    1fc0:      	mov	x25, x2
    1fc4:      	b	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1fc8:      	str	x28, [sp, #0x378]
    1fcc:      	str	x27, [sp, #0x370]
    1fd0:      	str	x26, [sp, #0x368]
    1fd4:      	mov	x26, x1
    1fd8:      	str	x25, [sp, #0x360]
    1fdc:      	mov	x25, x2
    1fe0:      	b	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1fe4:      	str	x28, [sp, #0x378]
    1fe8:      	str	x27, [sp, #0x370]
    1fec:      	str	x26, [sp, #0x368]
    1ff0:      	mov	x26, x1
    1ff4:      	str	x25, [sp, #0x360]
    1ff8:      	mov	x25, x2
    1ffc:      	mov	w27, w3
    2000:      	mov	w28, w4
    2004:      	b	0x1d50 <_stogir.verify.integer-operations-target-structured+0xf8c>

0000000000002008 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    2008:      	ldr	x0, [x0, #0x8]
    200c:      	ret

0000000000002010 <_coil.core.Eq$slice<u8>$=>:
    2010:      	sub	sp, sp, #0x10
    2014:      	str	x29, [sp]
    2018:      	str	x30, [sp, #0x8]
    201c:      	mov	x29, sp
    2020:      	cmp	x1, x3
    2024:      	b.ne	0x2064 <_coil.core.Eq$slice<u8>$=+0x54>
    2028:      	cmp	x1, #0x0
    202c:      	b.ne	0x2038 <_coil.core.Eq$slice<u8>$=+0x28>
    2030:      	mov	x0, #0x1                ; =1
    2034:      	b	0x2060 <_coil.core.Eq$slice<u8>$=+0x50>
    2038:      	lsr	x1, x1, #0
    203c:      	fmov	d31, x1
    2040:      	mov	x1, x2
    2044:      	fmov	x2, d31
    2048:      	bl	0x2048 <_coil.core.Eq$slice<u8>$=+0x38>
		0000000000002048:  ARM64_RELOC_BRANCH26	_memcmp
    204c:      	lsr	w0, w0, #0
    2050:      	sxtw	x0, w0
    2054:      	cmp	x0, #0x0
    2058:      	cset	w0, eq
    205c:      	ubfx	x0, x0, #0, #8
    2060:      	b	0x2068 <_coil.core.Eq$slice<u8>$=+0x58>
    2064:      	movz	x0, #0x0, lsl #48
    2068:      	ldr	x29, [sp]
    206c:      	ldr	x30, [sp, #0x8]
    2070:      	add	sp, sp, #0x10
    2074:      	ret

0000000000002078 <_stogir.node.opcode>:
    2078:      	ldr	w0, [x0]
    207c:      	uxtb	w0, w0
    2080:      	ret

0000000000002084 <_stogir.opcode.valid?>:
    2084:      	sxtw	x0, w0
    2088:      	cmp	x0, #0x0
    208c:      	b.lt	0x20a0 <_stogir.opcode.valid?+0x1c>
    2090:      	cmp	x0, #0x83
    2094:      	cset	w0, lt
    2098:      	ubfx	x0, x0, #0, #8
    209c:      	b	0x20a4 <_stogir.opcode.valid?+0x20>
    20a0:      	movz	x0, #0x0, lsl #48
    20a4:      	ret

00000000000020a8 <_stogir.node.type-id>:
    20a8:      	ldr	w0, [x0]
    20ac:      	ubfx	x0, x0, #8, #8
    20b0:      	ret

00000000000020b4 <_stogir.types.valid?>:
    20b4:      	sxtw	x0, w0
    20b8:      	cmp	x0, #0x0
    20bc:      	b.lt	0x20d0 <_stogir.types.valid?+0x1c>
    20c0:      	cmp	x0, #0xd
    20c4:      	b.gt	0x20d0 <_stogir.types.valid?+0x1c>
    20c8:      	mov	x0, #0x1                ; =1
    20cc:      	b	0x2110 <_stogir.types.valid?+0x5c>
    20d0:      	cmp	x0, #0xf
    20d4:      	b.le	0x210c <_stogir.types.valid?+0x58>
    20d8:      	cmp	x0, #0x80
    20dc:      	b.ge	0x2104 <_stogir.types.valid?+0x50>
    20e0:      	and	x0, x0, #0xf
    20e4:      	lsr	w0, w0, #0
    20e8:      	sxtw	x0, w0
    20ec:      	cmp	x0, #0x1
    20f0:      	b.lt	0x2114 <_stogir.types.valid?+0x60>
    20f4:      	cmp	x0, #0xd
    20f8:      	cset	w0, le
    20fc:      	ubfx	x0, x0, #0, #8
    2100:      	b	0x2118 <_stogir.types.valid?+0x64>
    2104:      	movz	x0, #0x0, lsl #48
    2108:      	b	0x2110 <_stogir.types.valid?+0x5c>
    210c:      	movz	x0, #0x0, lsl #48
    2110:      	ret
    2114:      	movz	x0, #0x0, lsl #48
    2118:      	b	0x2108 <_stogir.types.valid?+0x54>

000000000000211c <_stogir.opcode.operand-slots>:
    211c:      	sxtw	x0, w0
    2120:      	cmp	x0, #0x0
    2124:      	b.lt	0x214c <_stogir.opcode.operand-slots+0x30>
    2128:      	cmp	x0, #0x83
    212c:      	b.ge	0x214c <_stogir.opcode.operand-slots+0x30>
    2130:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002130:  ARM64_RELOC_PAGE21	l_stogir.336
    2134:      	ldr	x16, [x16]
		0000000000002134:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    2138:      	orr	x1, x16, xzr
    213c:      	add	x0, x1, x0
    2140:      	ldrsb	w0, [x0]
    2144:      	sxtb	x0, w0
    2148:      	b	0x2150 <_stogir.opcode.operand-slots+0x34>
    214c:      	mov	x0, #-0x2               ; =-2
    2150:      	ret

0000000000002154 <_stogir.opcode.input-count>:
    2154:      	sxtw	x0, w0
    2158:      	cmp	x0, #0x0
    215c:      	b.lt	0x2184 <_stogir.opcode.input-count+0x30>
    2160:      	cmp	x0, #0x83
    2164:      	b.ge	0x2184 <_stogir.opcode.input-count+0x30>
    2168:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002168:  ARM64_RELOC_PAGE21	l_stogir.337
    216c:      	ldr	x16, [x16]
		000000000000216c:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    2170:      	orr	x1, x16, xzr
    2174:      	add	x0, x1, x0
    2178:      	ldrsb	w0, [x0]
    217c:      	sxtb	x0, w0
    2180:      	b	0x2188 <_stogir.opcode.input-count+0x34>
    2184:      	mov	x0, #-0x2               ; =-2
    2188:      	ret

000000000000218c <_stogir.node.auxiliary>:
    218c:      	ldr	w0, [x0]
    2190:      	ubfx	x0, x0, #16, #16
    2194:      	ret

0000000000002198 <_stogir.opcode.operand-code>:
    2198:      	sxtw	x0, w0
    219c:      	cmp	x0, #0x0
    21a0:      	b.lt	0x21dc <_stogir.opcode.operand-code+0x44>
    21a4:      	cmp	x0, #0x83
    21a8:      	b.ge	0x21dc <_stogir.opcode.operand-code+0x44>
    21ac:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		00000000000021ac:  ARM64_RELOC_PAGE21	l_stogir.338
    21b0:      	ldr	x16, [x16]
		00000000000021b0:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    21b4:      	orr	x2, x16, xzr
    21b8:      	sxtw	x1, w1
    21bc:      	add	x0, x2, x0, lsl #2
    21c0:      	ldr	w0, [x0]
    21c4:      	cmp	x1, #0x0
    21c8:      	b.le	0x21e4 <_stogir.opcode.operand-code+0x4c>
    21cc:      	cmp	x1, #0x4
    21d0:      	b.le	0x21ec <_stogir.opcode.operand-code+0x54>
    21d4:      	mov	x1, #0x4                ; =4
    21d8:      	b	0x21f8 <_stogir.opcode.operand-code+0x60>
    21dc:      	movz	x0, #0x0, lsl #48
    21e0:      	ret
    21e4:      	movz	x0, #0x0, lsl #48
    21e8:      	b	0x21e0 <_stogir.opcode.operand-code+0x48>
    21ec:      	sub	x1, x1, #0x1
    21f0:      	lsr	w1, w1, #0
    21f4:      	sxtw	x1, w1
    21f8:      	lsl	x1, x1, #2
    21fc:      	lsr	w1, w1, #0
    2200:      	ubfx	x1, x1, #0, #32
    2204:      	lsr	x0, x0, x1
    2208:      	lsr	w0, w0, #0
    220c:      	and	x0, x0, #0xf
    2210:      	lsr	w0, w0, #0
    2214:      	b	0x21e8 <_stogir.opcode.operand-code+0x50>

0000000000002218 <_stogir.graph.operand>:
    2218:      	sub	sp, sp, #0x10
    221c:      	mov	x3, sp
    2220:      	sxtw	x1, w1
    2224:      	cmp	x1, #0x0
    2228:      	b.le	0x226c <_stogir.graph.operand+0x54>
    222c:      	lsl	x4, x1, #2
    2230:      	ldr	x5, [x0, #0x8]
    2234:      	cmp	x1, x5
    2238:      	b.ge	0x22a0 <_stogir.graph.operand+0x88>
    223c:      	add	x5, x0, #0x78
    2240:      	ldr	x5, [x5, #0x8]
    2244:      	cmp	x1, x5
    2248:      	b.ge	0x2298 <_stogir.graph.operand+0x80>
    224c:      	ldr	x5, [x0, #0x78]
    2250:      	add	x5, x4, x5
    2254:      	ldr	w5, [x5]
    2258:      	sxtw	x5, w5
    225c:      	cmp	x5, #0x0
    2260:      	cset	w5, ge
    2264:      	ubfx	x5, x5, #0, #8
    2268:      	b	0x229c <_stogir.graph.operand+0x84>
    226c:      	movz	x1, #0x0, lsl #48
    2270:      	movz	x0, #0x0, lsl #48
    2274:      	str	x1, [x3]
    2278:      	str	x0, [x3, #0x8]
    227c:      	ldr	x0, [sp]
    2280:      	ldr	x1, [sp, #0x8]
    2284:      	add	sp, sp, #0x10
    2288:      	ret
    228c:      	movz	x1, #0x0, lsl #48
    2290:      	movz	x0, #0x0, lsl #48
    2294:      	b	0x2274 <_stogir.graph.operand+0x5c>
    2298:      	movz	x5, #0x0, lsl #48
    229c:      	b	0x22a4 <_stogir.graph.operand+0x8c>
    22a0:      	movz	x5, #0x0, lsl #48
    22a4:      	cmp	x5, #0x0
    22a8:      	b.eq	0x226c <_stogir.graph.operand+0x54>
    22ac:      	sxtw	x2, w2
    22b0:      	cmp	x2, #0x1
    22b4:      	b.lt	0x228c <_stogir.graph.operand+0x74>
    22b8:      	ldr	x5, [x0, #0x78]
    22bc:      	add	x4, x4, x5
    22c0:      	ldr	w4, [x4]
    22c4:      	sxtw	x4, w4
    22c8:      	cmp	x2, x4
    22cc:      	b.gt	0x228c <_stogir.graph.operand+0x74>
    22d0:      	asr	x16, x2, #63
    22d4:      	lsr	x16, x16, #62
    22d8:      	add	x4, x2, x16
    22dc:      	asr	x4, x4, #2
    22e0:      	asr	x16, x2, #63
    22e4:      	lsr	x16, x16, #62
    22e8:      	add	x2, x2, x16
    22ec:      	and	x2, x2, #0x3
    22f0:      	sub	x2, x2, x16
    22f4:      	ldr	x0, [x0]
    22f8:      	add	x1, x4, x1
    22fc:      	add	x0, x0, x1, lsl #4
    2300:      	add	x0, x0, x2, lsl #2
    2304:      	ldr	w0, [x0]
    2308:      	sxtw	x0, w0
    230c:      	and	x0, x0, #0xffffffff
    2310:      	mov	x1, #0x1                ; =1
    2314:      	b	0x2294 <_stogir.graph.operand+0x7c>

0000000000002318 <_stogir.graph.borrow-node>:
    2318:      	sxtw	x1, w1
    231c:      	cmp	x1, #0x0
    2320:      	cset	w2, gt
    2324:      	movz	x16, #0x0, lsl #48
    2328:      	sub	x3, x16, x1
    232c:      	sub	x4, x3, #0x1
    2330:      	uxtb	w16, w2
    2334:      	cmp	w16, wzr
    2338:      	b.eq	0x2378 <_stogir.graph.borrow-node+0x60>
    233c:      	ldr	x3, [x0, #0x8]
    2340:      	cmp	x1, x3
    2344:      	b.ge	0x23c8 <_stogir.graph.borrow-node+0xb0>
    2348:      	add	x3, x0, #0x78
    234c:      	ldr	x3, [x3, #0x8]
    2350:      	cmp	x1, x3
    2354:      	b.ge	0x2408 <_stogir.graph.borrow-node+0xf0>
    2358:      	ldr	x3, [x0, #0x78]
    235c:      	add	x3, x3, x1, lsl #2
    2360:      	ldr	w3, [x3]
    2364:      	sxtw	x3, w3
    2368:      	cmp	x3, #0x0
    236c:      	cset	w3, ge
    2370:      	ubfx	x3, x3, #0, #8
    2374:      	b	0x240c <_stogir.graph.borrow-node+0xf4>
    2378:      	cmp	x1, #0x0
    237c:      	b.ge	0x23d0 <_stogir.graph.borrow-node+0xb8>
    2380:      	add	x5, x0, #0x28
    2384:      	add	x6, x0, #0x50
    2388:      	ldr	x5, [x5, #0x8]
    238c:      	ldr	x6, [x6, #0x8]
    2390:      	cmp	x5, x6
    2394:      	b.ne	0x23c0 <_stogir.graph.borrow-node+0xa8>
    2398:      	cmp	x3, x5
    239c:      	b.gt	0x2410 <_stogir.graph.borrow-node+0xf8>
    23a0:      	ldr	x3, [x0, #0x50]
    23a4:      	add	x3, x3, x4, lsl #2
    23a8:      	ldr	w3, [x3]
    23ac:      	sxtw	x3, w3
    23b0:      	cmp	x3, #0x0
    23b4:      	cset	w3, gt
    23b8:      	ubfx	x3, x3, #0, #8
    23bc:      	b	0x2414 <_stogir.graph.borrow-node+0xfc>
    23c0:      	movz	x3, #0x0, lsl #48
    23c4:      	b	0x23d4 <_stogir.graph.borrow-node+0xbc>
    23c8:      	movz	x3, #0x0, lsl #48
    23cc:      	b	0x23d4 <_stogir.graph.borrow-node+0xbc>
    23d0:      	movz	x3, #0x0, lsl #48
    23d4:      	cmp	x3, #0x0
    23d8:      	b.eq	0x2400 <_stogir.graph.borrow-node+0xe8>
    23dc:      	uxtb	w16, w2
    23e0:      	cmp	w16, wzr
    23e4:      	b.eq	0x23f4 <_stogir.graph.borrow-node+0xdc>
    23e8:      	ldr	x0, [x0]
    23ec:      	add	x0, x0, x1, lsl #4
    23f0:      	b	0x23fc <_stogir.graph.borrow-node+0xe4>
    23f4:      	ldr	x0, [x0, #0x28]
    23f8:      	add	x0, x0, x4, lsl #4
    23fc:      	b	0x2404 <_stogir.graph.borrow-node+0xec>
    2400:      	movz	x0, #0x0, lsl #48
    2404:      	ret
    2408:      	movz	x3, #0x0, lsl #48
    240c:      	b	0x23cc <_stogir.graph.borrow-node+0xb4>
    2410:      	movz	x3, #0x0, lsl #48
    2414:      	b	0x23c4 <_stogir.graph.borrow-node+0xac>

0000000000002418 <_stogir.strings.lookup>:
    2418:      	sxtw	x1, w1
    241c:      	cmp	x1, #0x0
    2420:      	b.le	0x2490 <_stogir.strings.lookup+0x78>
    2424:      	add	x2, x0, #0x28
    2428:      	ldr	x2, [x2, #0x8]
    242c:      	cmp	x1, x2
    2430:      	b.gt	0x2490 <_stogir.strings.lookup+0x78>
    2434:      	sub	x1, x1, #0x1
    2438:      	mov	x17, #0x18              ; =24
    243c:      	mul	x1, x1, x17
    2440:      	ldr	x2, [x0, #0x28]
    2444:      	add	x1, x1, x2
    2448:      	ldr	x2, [x1]
    244c:      	ldr	x1, [x1, #0x8]
    2450:      	ldr	x3, [x0, #0x8]
    2454:      	cmp	x2, #0x0
    2458:      	b.lt	0x24ac <_stogir.strings.lookup+0x94>
    245c:      	cmp	x2, x3
    2460:      	b.gt	0x24ac <_stogir.strings.lookup+0x94>
    2464:      	cmp	x1, #0x0
    2468:      	b.lt	0x24ac <_stogir.strings.lookup+0x94>
    246c:      	sub	x3, x3, x2
    2470:      	cmp	x1, x3
    2474:      	b.gt	0x24ac <_stogir.strings.lookup+0x94>
    2478:      	add	x1, x1, x2
    247c:      	sub	x1, x1, x2
    2480:      	ldr	x0, [x0]
    2484:      	add	x0, x0, x2
    2488:      	mov	x2, #0x1                ; =1
    248c:      	b	0x24b8 <_stogir.strings.lookup+0xa0>
    2490:      	movz	x2, #0x0, lsl #48
    2494:      	movz	x0, #0x0, lsl #48
    2498:      	movz	x1, #0x0, lsl #48
    249c:      	str	x2, [x8]
    24a0:      	str	x0, [x8, #0x8]
    24a4:      	str	x1, [x8, #0x10]
    24a8:      	ret
    24ac:      	movz	x2, #0x0, lsl #48
    24b0:      	movz	x0, #0x0, lsl #48
    24b4:      	movz	x1, #0x0, lsl #48
    24b8:      	b	0x249c <_stogir.strings.lookup+0x84>

00000000000024bc <_stogir.uses.edge-code?>:
    24bc:      	ubfx	x0, x0, #0, #32
    24c0:      	cmp	x0, #0xf
    24c4:      	b.hs	0x24f8 <_stogir.uses.edge-code?+0x3c>
    24c8:      	mov	x16, #0x1               ; =1
    24cc:      	lsl	x0, x16, x0
    24d0:      	lsr	w0, w0, #0
    24d4:      	mov	x17, #0x5e1c            ; =24092
    24d8:      	and	x0, x0, x17
    24dc:      	lsr	w0, w0, #0
    24e0:      	cmp	x0, #0x0
    24e4:      	cset	w0, eq
    24e8:      	uxtb	w16, w0
    24ec:      	cmp	w16, wzr
    24f0:      	cset	x0, eq
    24f4:      	b	0x24fc <_stogir.uses.edge-code?+0x40>
    24f8:      	movz	x0, #0x0, lsl #48
    24fc:      	ret

0000000000002500 <_stogir.graph.contains?>:
    2500:      	sxtw	x1, w1
    2504:      	cmp	x1, #0x0
    2508:      	b.le	0x2548 <_stogir.graph.contains?+0x48>
    250c:      	ldr	x2, [x0, #0x8]
    2510:      	cmp	x1, x2
    2514:      	b.ge	0x25a4 <_stogir.graph.contains?+0xa4>
    2518:      	add	x2, x0, #0x78
    251c:      	ldr	x2, [x2, #0x8]
    2520:      	cmp	x1, x2
    2524:      	b.ge	0x25b4 <_stogir.graph.contains?+0xb4>
    2528:      	ldr	x0, [x0, #0x78]
    252c:      	add	x0, x0, x1, lsl #2
    2530:      	ldr	w0, [x0]
    2534:      	sxtw	x0, w0
    2538:      	cmp	x0, #0x0
    253c:      	cset	w0, ge
    2540:      	ubfx	x0, x0, #0, #8
    2544:      	b	0x25b8 <_stogir.graph.contains?+0xb8>
    2548:      	cmp	x1, #0x0
    254c:      	b.ge	0x25ac <_stogir.graph.contains?+0xac>
    2550:      	add	x2, x0, #0x28
    2554:      	add	x3, x0, #0x50
    2558:      	ldr	x2, [x2, #0x8]
    255c:      	ldr	x3, [x3, #0x8]
    2560:      	cmp	x2, x3
    2564:      	b.ne	0x25c4 <_stogir.graph.contains?+0xc4>
    2568:      	movz	x16, #0x0, lsl #48
    256c:      	sub	x3, x16, x1
    2570:      	cmp	x3, x2
    2574:      	b.gt	0x25bc <_stogir.graph.contains?+0xbc>
    2578:      	movz	x16, #0x0, lsl #48
    257c:      	sub	x1, x16, x1
    2580:      	sub	x1, x1, #0x1
    2584:      	ldr	x0, [x0, #0x50]
    2588:      	add	x0, x0, x1, lsl #2
    258c:      	ldr	w0, [x0]
    2590:      	sxtw	x0, w0
    2594:      	cmp	x0, #0x0
    2598:      	cset	w0, gt
    259c:      	ubfx	x0, x0, #0, #8
    25a0:      	b	0x25c0 <_stogir.graph.contains?+0xc0>
    25a4:      	movz	x0, #0x0, lsl #48
    25a8:      	b	0x25b8 <_stogir.graph.contains?+0xb8>
    25ac:      	movz	x0, #0x0, lsl #48
    25b0:      	b	0x25c0 <_stogir.graph.contains?+0xc0>
    25b4:      	movz	x0, #0x0, lsl #48
    25b8:      	b	0x25c0 <_stogir.graph.contains?+0xc0>
    25bc:      	movz	x0, #0x0, lsl #48
    25c0:      	ret
    25c4:      	movz	x0, #0x0, lsl #48
    25c8:      	b	0x25c0 <_stogir.graph.contains?+0xc0>

00000000000025cc <_stogir.opcode.optional-reference?>:
    25cc:      	sxtw	x0, w0
    25d0:      	sxtw	x2, w2
    25d4:      	cmp	x0, #0x0
    25d8:      	b.lt	0x2610 <_stogir.opcode.optional-reference?+0x44>
    25dc:      	cmp	x0, #0x83
    25e0:      	b.ge	0x2610 <_stogir.opcode.optional-reference?+0x44>
    25e4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		00000000000025e4:  ARM64_RELOC_PAGE21	l_stogir.339
    25e8:      	ldr	x16, [x16]
		00000000000025e8:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    25ec:      	orr	x3, x16, xzr
    25f0:      	add	x3, x3, x0, lsl #2
    25f4:      	ldr	w3, [x3]
    25f8:      	cmp	x2, #0x0
    25fc:      	b.le	0x2658 <_stogir.opcode.optional-reference?+0x8c>
    2600:      	cmp	x2, #0x4
    2604:      	b.le	0x267c <_stogir.opcode.optional-reference?+0xb0>
    2608:      	mov	x4, #0x4                ; =4
    260c:      	b	0x2688 <_stogir.opcode.optional-reference?+0xbc>
    2610:      	movz	x3, #0x0, lsl #48
    2614:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002614:  ARM64_RELOC_PAGE21	l_stogir.340
    2618:      	ldr	x16, [x16]
		0000000000002618:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    261c:      	ldr	w4, [x16]
    2620:      	lsr	w3, w3, #0
    2624:      	cmp	x3, x4
    2628:      	b.ne	0x263c <_stogir.opcode.optional-reference?+0x70>
    262c:      	mov	x0, #0x1                ; =1
    2630:      	b	0x2638 <_stogir.opcode.optional-reference?+0x6c>
    2634:      	movz	x0, #0x0, lsl #48
    2638:      	ret
    263c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		000000000000263c:  ARM64_RELOC_PAGE21	l_stogir.341
    2640:      	ldr	x16, [x16]
		0000000000002640:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    2644:      	ldr	w4, [x16]
    2648:      	cmp	x3, x4
    264c:      	b.ne	0x2660 <_stogir.opcode.optional-reference?+0x94>
    2650:      	mov	x0, #0x1                ; =1
    2654:      	b	0x2638 <_stogir.opcode.optional-reference?+0x6c>
    2658:      	movz	x3, #0x0, lsl #48
    265c:      	b	0x2614 <_stogir.opcode.optional-reference?+0x48>
    2660:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002660:  ARM64_RELOC_PAGE21	l_stogir.342
    2664:      	ldr	x16, [x16]
		0000000000002664:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    2668:      	ldr	w4, [x16]
    266c:      	cmp	x3, x4
    2670:      	b.ne	0x26a8 <_stogir.opcode.optional-reference?+0xdc>
    2674:      	mov	x0, #0x1                ; =1
    2678:      	b	0x2638 <_stogir.opcode.optional-reference?+0x6c>
    267c:      	sub	x4, x2, #0x1
    2680:      	lsr	w4, w4, #0
    2684:      	sxtw	x4, w4
    2688:      	lsl	x4, x4, #2
    268c:      	lsr	w4, w4, #0
    2690:      	ubfx	x4, x4, #0, #32
    2694:      	lsr	x3, x3, x4
    2698:      	lsr	w3, w3, #0
    269c:      	and	x3, x3, #0xf
    26a0:      	lsr	w3, w3, #0
    26a4:      	b	0x265c <_stogir.opcode.optional-reference?+0x90>
    26a8:      	cmp	x0, #0x78
    26ac:      	b.ne	0x2634 <_stogir.opcode.optional-reference?+0x68>
    26b0:      	sxtw	x1, w1
    26b4:      	cmp	x1, #0x0
    26b8:      	b.ne	0x26cc <_stogir.opcode.optional-reference?+0x100>
    26bc:      	cmp	x2, #0x2
    26c0:      	cset	w0, eq
    26c4:      	ubfx	x0, x0, #0, #8
    26c8:      	b	0x26d0 <_stogir.opcode.optional-reference?+0x104>
    26cc:      	movz	x0, #0x0, lsl #48
    26d0:      	b	0x2638 <_stogir.opcode.optional-reference?+0x6c>

00000000000026d4 <_stogir.integer-binary.operation?>:
    26d4:      	sxtw	x0, w0
    26d8:      	cmp	x0, #0x1a
    26dc:      	b.lt	0x26f0 <_stogir.integer-binary.operation?+0x1c>
    26e0:      	cmp	x0, #0x1e
    26e4:      	b.gt	0x26f0 <_stogir.integer-binary.operation?+0x1c>
    26e8:      	mov	x0, #0x1                ; =1
    26ec:      	b	0x2724 <_stogir.integer-binary.operation?+0x50>
    26f0:      	cmp	x0, #0x2e
    26f4:      	b.lt	0x2708 <_stogir.integer-binary.operation?+0x34>
    26f8:      	cmp	x0, #0x35
    26fc:      	b.gt	0x2708 <_stogir.integer-binary.operation?+0x34>
    2700:      	mov	x0, #0x1                ; =1
    2704:      	b	0x2724 <_stogir.integer-binary.operation?+0x50>
    2708:      	cmp	x0, #0x3a
    270c:      	b.ne	0x2718 <_stogir.integer-binary.operation?+0x44>
    2710:      	mov	x0, #0x1                ; =1
    2714:      	b	0x2724 <_stogir.integer-binary.operation?+0x50>
    2718:      	cmp	x0, #0x3b
    271c:      	cset	w0, eq
    2720:      	ubfx	x0, x0, #0, #8
    2724:      	ret

0000000000002728 <_stogir.integer-unary.operation?>:
    2728:      	sxtw	x0, w0
    272c:      	cmp	x0, #0x1f
    2730:      	b.ne	0x274c <_stogir.integer-unary.operation?+0x24>
    2734:      	mov	x0, #0x1                ; =1
    2738:      	b	0x2748 <_stogir.integer-unary.operation?+0x20>
    273c:      	cmp	x0, #0x39
    2740:      	cset	w0, eq
    2744:      	ubfx	x0, x0, #0, #8
    2748:      	ret
    274c:      	cmp	x0, #0x20
    2750:      	b.ne	0x275c <_stogir.integer-unary.operation?+0x34>
    2754:      	mov	x0, #0x1                ; =1
    2758:      	b	0x2748 <_stogir.integer-unary.operation?+0x20>
    275c:      	cmp	x0, #0x2d
    2760:      	b.ne	0x276c <_stogir.integer-unary.operation?+0x44>
    2764:      	mov	x0, #0x1                ; =1
    2768:      	b	0x2748 <_stogir.integer-unary.operation?+0x20>
    276c:      	cmp	x0, #0x36
    2770:      	b.ne	0x277c <_stogir.integer-unary.operation?+0x54>
    2774:      	mov	x0, #0x1                ; =1
    2778:      	b	0x2748 <_stogir.integer-unary.operation?+0x20>
    277c:      	cmp	x0, #0x37
    2780:      	b.ne	0x278c <_stogir.integer-unary.operation?+0x64>
    2784:      	mov	x0, #0x1                ; =1
    2788:      	b	0x2748 <_stogir.integer-unary.operation?+0x20>
    278c:      	cmp	x0, #0x38
    2790:      	b.ne	0x273c <_stogir.integer-unary.operation?+0x14>
    2794:      	mov	x0, #0x1                ; =1
    2798:      	b	0x2748 <_stogir.integer-unary.operation?+0x20>

000000000000279c <_stogir.verify.classifications>:
    279c:      	sub	sp, sp, #0x70
    27a0:      	str	x29, [sp]
    27a4:      	str	x30, [sp, #0x8]
    27a8:      	mov	x29, sp
    27ac:      	str	x19, [sp, #0x20]
    27b0:      	str	x20, [sp, #0x28]
    27b4:      	str	x21, [sp, #0x30]
    27b8:      	str	x22, [sp, #0x38]
    27bc:      	str	x23, [sp, #0x40]
    27c0:      	str	x24, [sp, #0x48]
    27c4:      	str	x25, [sp, #0x50]
    27c8:      	str	x26, [sp, #0x58]
    27cc:      	str	x27, [sp, #0x60]
    27d0:      	str	x28, [sp, #0x68]
    27d4:      	ldr	w4, [x2]
    27d8:      	uxtb	w19, w4
    27dc:      	orr	x5, x19, xzr
    27e0:      	lsr	w20, w5, #0
    27e4:      	ubfx	x21, x4, #8, #8
    27e8:      	orr	x4, x21, xzr
    27ec:      	lsr	w4, w4, #0
    27f0:      	mov	x22, x0
    27f4:      	mov	w0, w4
    27f8:      	mov	w23, w1
    27fc:      	mov	x24, x2
    2800:      	mov	w25, w3
    2804:      	bl	0x2804 <_stogir.verify.classifications+0x68>
		0000000000002804:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2808:      	fmov	d31, x0
    280c:      	mov	w0, w20
    2810:      	fmov	x20, d31
    2814:      	bl	0x2814 <_stogir.verify.classifications+0x78>
		0000000000002814:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2818:      	cmp	x0, #0x0
    281c:      	b.eq	0x2838 <_stogir.verify.classifications+0x9c>
    2820:      	cmp	x20, #0x0
    2824:      	cset	w0, ne
    2828:      	uxtb	w16, w0
    282c:      	cmp	w16, wzr
    2830:      	cset	x26, eq
    2834:      	b	0x283c <_stogir.verify.classifications+0xa0>
    2838:      	movz	x26, #0x0, lsl #48
    283c:      	cmp	x26, #0x0
    2840:      	cset	w27, ne
    2844:      	uxtb	w16, w27
    2848:      	cmp	w16, wzr
    284c:      	b.eq	0x2880 <_stogir.verify.classifications+0xe4>
    2850:      	ldr	w0, [x24, #0x4]
    2854:      	lsr	w0, w0, #0
    2858:      	mov	w1, w0
    285c:      	mov	x0, x22
    2860:      	bl	0x2860 <_stogir.verify.classifications+0xc4>
		0000000000002860:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2864:      	cmp	x0, #0x0
    2868:      	b.ne	0x2874 <_stogir.verify.classifications+0xd8>
    286c:      	movn	x0, #0x0, lsl #48
    2870:      	b	0x287c <_stogir.verify.classifications+0xe0>
    2874:      	ldr	w0, [x0]
    2878:      	ubfx	x0, x0, #8, #8
    287c:      	b	0x2884 <_stogir.verify.classifications+0xe8>
    2880:      	movn	x0, #0x0, lsl #48
    2884:      	lsr	w0, w0, #0
    2888:      	sxtw	x28, w0
    288c:      	cmp	x26, #0x0
    2890:      	b.eq	0x28c0 <_stogir.verify.classifications+0x124>
    2894:      	bl	0x2894 <_stogir.verify.classifications+0xf8>
		0000000000002894:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2898:      	cmp	x0, #0x0
    289c:      	b.eq	0x2cf0 <_stogir.verify.classifications+0x554>
    28a0:      	movz	x0, #0x0, lsl #48
    28a4:      	b	0x28ac <_stogir.verify.classifications+0x110>
    28a8:      	mov	x0, #0x1                ; =1
    28ac:      	b	0x28c4 <_stogir.verify.classifications+0x128>
    28b0:      	movz	x19, #0x0, lsl #48
    28b4:      	b	0x2944 <_stogir.verify.classifications+0x1a8>
    28b8:      	movz	x20, #0x0, lsl #48
    28bc:      	b	0x294c <_stogir.verify.classifications+0x1b0>
    28c0:      	movz	x0, #0x0, lsl #48
    28c4:      	sxtw	x25, w25
    28c8:      	cmp	x28, #0xf
    28cc:      	cset	w1, gt
    28d0:      	cmp	x28, #0x80
    28d4:      	cset	w2, lt
    28d8:      	and	x3, x28, #0xf
    28dc:      	cmp	x19, #0x83
    28e0:      	cset	w4, lt
    28e4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		00000000000028e4:  ARM64_RELOC_PAGE21	l_stogir.343
    28e8:      	ldr	x16, [x16]
		00000000000028e8:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    28ec:      	orr	x5, x16, xzr
    28f0:      	add	x6, x22, #0x78
    28f4:      	add	x7, x22, #0x28
    28f8:      	add	x8, x22, #0x50
    28fc:      	sxtw	x23, w23
    2900:      	add	x9, x22, #0x78
    2904:      	lsr	w3, w3, #0
    2908:      	add	x5, x5, x19, lsl #2
    290c:      	cmp	x23, #0x0
    2910:      	cset	w10, le
    2914:      	lsl	x11, x23, #2
    2918:      	sxtw	x3, w3
    291c:      	cmp	x3, #0x1
    2920:      	cset	w12, ge
    2924:      	cmp	x3, #0xd
    2928:      	cset	w3, le
    292c:      	ubfx	x3, x3, #0, #8
    2930:      	mov	x13, #0x1               ; =1
    2934:      	b	0x2a04 <_stogir.verify.classifications+0x268>
    2938:      	movz	x19, #0x0, lsl #48
    293c:      	b	0x2980 <_stogir.verify.classifications+0x1e4>
    2940:      	movz	x19, #0x0, lsl #48
    2944:      	b	0x2988 <_stogir.verify.classifications+0x1ec>
    2948:      	movz	x20, #0x0, lsl #48
    294c:      	b	0x29f8 <_stogir.verify.classifications+0x25c>
    2950:      	sub	x19, x14, #0x1
    2954:      	lsr	w19, w19, #0
    2958:      	sxtw	x19, w19
    295c:      	lsl	x19, x19, #2
    2960:      	lsr	w19, w19, #0
    2964:      	ubfx	x19, x19, #0, #32
    2968:      	lsr	x15, x15, x19
    296c:      	lsr	w15, w15, #0
    2970:      	and	x15, x15, #0xf
    2974:      	lsr	w15, w15, #0
    2978:      	b	0x2a48 <_stogir.verify.classifications+0x2ac>
    297c:      	movz	x19, #0x0, lsl #48
    2980:      	b	0x2988 <_stogir.verify.classifications+0x1ec>
    2984:      	movz	x19, #0x0, lsl #48
    2988:      	cmp	x19, #0x0
    298c:      	b.eq	0x29b4 <_stogir.verify.classifications+0x218>
    2990:      	uxtb	w16, w15
    2994:      	cmp	w16, wzr
    2998:      	b.eq	0x29a8 <_stogir.verify.classifications+0x20c>
    299c:      	ldr	x15, [x22]
    29a0:      	add	x14, x15, x14, lsl #4
    29a4:      	b	0x29b0 <_stogir.verify.classifications+0x214>
    29a8:      	ldr	x14, [x22, #0x28]
    29ac:      	add	x14, x14, x21, lsl #4
    29b0:      	b	0x29b8 <_stogir.verify.classifications+0x21c>
    29b4:      	movz	x14, #0x0, lsl #48
    29b8:      	cmp	x14, #0x0
    29bc:      	b.eq	0x29f8 <_stogir.verify.classifications+0x25c>
    29c0:      	ldr	w14, [x14]
    29c4:      	ubfx	x14, x14, #8, #8
    29c8:      	cmp	x14, #0xf
    29cc:      	b.le	0x29f8 <_stogir.verify.classifications+0x25c>
    29d0:      	cmp	x14, #0x80
    29d4:      	b.ge	0x29f8 <_stogir.verify.classifications+0x25c>
    29d8:      	and	x14, x14, #0xf
    29dc:      	lsr	w14, w14, #0
    29e0:      	sxtw	x14, w14
    29e4:      	cmp	x14, #0x1
    29e8:      	b.lt	0x29f8 <_stogir.verify.classifications+0x25c>
    29ec:      	cmp	x14, #0xd
    29f0:      	b.gt	0x29f8 <_stogir.verify.classifications+0x25c>
    29f4:      	mov	x20, #0x1               ; =1
    29f8:      	add	x13, x13, #0x1
    29fc:      	lsr	w13, w13, #0
    2a00:      	sxtw	x13, w13
    2a04:      	cmp	x20, #0x0
    2a08:      	b.ne	0x2b94 <_stogir.verify.classifications+0x3f8>
    2a0c:      	cmp	x13, x25
    2a10:      	b.gt	0x2b94 <_stogir.verify.classifications+0x3f8>
    2a14:      	lsr	w14, w13, #0
    2a18:      	sxtw	x14, w14
    2a1c:      	uxtb	w16, w4
    2a20:      	cmp	w16, wzr
    2a24:      	b.eq	0x2a4c <_stogir.verify.classifications+0x2b0>
    2a28:      	ldr	w15, [x5]
    2a2c:      	cmp	x14, #0x0
    2a30:      	b.le	0x2a44 <_stogir.verify.classifications+0x2a8>
    2a34:      	cmp	x14, #0x4
    2a38:      	b.le	0x2950 <_stogir.verify.classifications+0x1b4>
    2a3c:      	mov	x19, #0x4               ; =4
    2a40:      	b	0x295c <_stogir.verify.classifications+0x1c0>
    2a44:      	movz	x15, #0x0, lsl #48
    2a48:      	b	0x2a50 <_stogir.verify.classifications+0x2b4>
    2a4c:      	movz	x15, #0x0, lsl #48
    2a50:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002a50:  ARM64_RELOC_PAGE21	l_stogir.344
    2a54:      	ldr	x16, [x16]
		0000000000002a54:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    2a58:      	ldr	w19, [x16]
    2a5c:      	lsr	w15, w15, #0
    2a60:      	cmp	x15, x19
    2a64:      	b.eq	0x2a7c <_stogir.verify.classifications+0x2e0>
    2a68:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002a68:  ARM64_RELOC_PAGE21	l_stogir.345
    2a6c:      	ldr	x16, [x16]
		0000000000002a6c:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    2a70:      	ldr	w19, [x16]
    2a74:      	cmp	x15, x19
    2a78:      	b.ne	0x29f8 <_stogir.verify.classifications+0x25c>
    2a7c:      	cmp	x13, #0x1
    2a80:      	b.ne	0x2abc <_stogir.verify.classifications+0x320>
    2a84:      	uxtb	w16, w27
    2a88:      	cmp	w16, wzr
    2a8c:      	b.eq	0x2abc <_stogir.verify.classifications+0x320>
    2a90:      	uxtb	w16, w1
    2a94:      	cmp	w16, wzr
    2a98:      	b.eq	0x2948 <_stogir.verify.classifications+0x1ac>
    2a9c:      	uxtb	w16, w2
    2aa0:      	cmp	w16, wzr
    2aa4:      	b.eq	0x28b8 <_stogir.verify.classifications+0x11c>
    2aa8:      	uxtb	w16, w12
    2aac:      	cmp	w16, wzr
    2ab0:      	b.eq	0x2c9c <_stogir.verify.classifications+0x500>
    2ab4:      	mov	x20, x3
    2ab8:      	b	0x2ca0 <_stogir.verify.classifications+0x504>
    2abc:      	cmp	x13, #0x1
    2ac0:      	b.ne	0x2b2c <_stogir.verify.classifications+0x390>
    2ac4:      	ldr	w14, [x24, #0x4]
    2ac8:      	sxtw	x14, w14
    2acc:      	lsr	w14, w14, #0
    2ad0:      	sxtw	x14, w14
    2ad4:      	cmp	x14, #0x0
    2ad8:      	cset	w15, gt
    2adc:      	movz	x16, #0x0, lsl #48
    2ae0:      	sub	x19, x16, x14
    2ae4:      	sub	x21, x19, #0x1
    2ae8:      	uxtb	w16, w15
    2aec:      	cmp	w16, wzr
    2af0:      	b.eq	0x2b40 <_stogir.verify.classifications+0x3a4>
    2af4:      	ldr	x19, [x22, #0x8]
    2af8:      	cmp	x14, x19
    2afc:      	b.ge	0x297c <_stogir.verify.classifications+0x1e0>
    2b00:      	ldr	x19, [x6, #0x8]
    2b04:      	cmp	x14, x19
    2b08:      	b.ge	0x2938 <_stogir.verify.classifications+0x19c>
    2b0c:      	ldr	x19, [x22, #0x78]
    2b10:      	add	x19, x19, x14, lsl #2
    2b14:      	ldr	w19, [x19]
    2b18:      	sxtw	x19, w19
    2b1c:      	cmp	x19, #0x0
    2b20:      	cset	w19, ge
    2b24:      	ubfx	x19, x19, #0, #8
    2b28:      	b	0x293c <_stogir.verify.classifications+0x1a0>
    2b2c:      	cmp	x13, #0x2
    2b30:      	b.ne	0x2b80 <_stogir.verify.classifications+0x3e4>
    2b34:      	ldr	w14, [x24, #0x8]
    2b38:      	sxtw	x14, w14
    2b3c:      	b	0x2acc <_stogir.verify.classifications+0x330>
    2b40:      	cmp	x14, #0x0
    2b44:      	b.ge	0x2984 <_stogir.verify.classifications+0x1e8>
    2b48:      	ldr	x26, [x7, #0x8]
    2b4c:      	ldr	x28, [x8, #0x8]
    2b50:      	cmp	x26, x28
    2b54:      	b.ne	0x2940 <_stogir.verify.classifications+0x1a4>
    2b58:      	cmp	x19, x26
    2b5c:      	b.gt	0x28b0 <_stogir.verify.classifications+0x114>
    2b60:      	ldr	x19, [x22, #0x50]
    2b64:      	add	x19, x19, x21, lsl #2
    2b68:      	ldr	w19, [x19]
    2b6c:      	sxtw	x19, w19
    2b70:      	cmp	x19, #0x0
    2b74:      	cset	w19, gt
    2b78:      	ubfx	x19, x19, #0, #8
    2b7c:      	b	0x28b4 <_stogir.verify.classifications+0x118>
    2b80:      	cmp	x13, #0x3
    2b84:      	b.ne	0x2bf8 <_stogir.verify.classifications+0x45c>
    2b88:      	ldr	w14, [x24, #0xc]
    2b8c:      	sxtw	x14, w14
    2b90:      	b	0x2b3c <_stogir.verify.classifications+0x3a0>
    2b94:      	uxtb	w20, w20
    2b98:      	uxtb	w0, w0
    2b9c:      	add	x16, sp, #0x10
    2ba0:      	movz	w17, #0x0, lsl #16
    2ba4:      	strh	w17, [x16]
    2ba8:      	add	x16, sp, #0x10
    2bac:      	strb	w20, [x16]
    2bb0:      	add	x16, sp, #0x10
    2bb4:      	strb	w0, [x16, #0x1]
    2bb8:      	add	x16, sp, #0x10
    2bbc:      	ldrh	w0, [x16]
    2bc0:      	ldr	x19, [sp, #0x20]
    2bc4:      	ldr	x20, [sp, #0x28]
    2bc8:      	ldr	x21, [sp, #0x30]
    2bcc:      	ldr	x22, [sp, #0x38]
    2bd0:      	ldr	x23, [sp, #0x40]
    2bd4:      	ldr	x24, [sp, #0x48]
    2bd8:      	ldr	x25, [sp, #0x50]
    2bdc:      	ldr	x26, [sp, #0x58]
    2be0:      	ldr	x27, [sp, #0x60]
    2be4:      	ldr	x28, [sp, #0x68]
    2be8:      	ldr	x29, [sp]
    2bec:      	ldr	x30, [sp, #0x8]
    2bf0:      	add	sp, sp, #0x70
    2bf4:      	ret
    2bf8:      	uxtb	w16, w10
    2bfc:      	cmp	w16, wzr
    2c00:      	b.ne	0x2cb0 <_stogir.verify.classifications+0x514>
    2c04:      	ldr	x15, [x22, #0x8]
    2c08:      	cmp	x23, x15
    2c0c:      	b.ge	0x2cb0 <_stogir.verify.classifications+0x514>
    2c10:      	ldr	x15, [x9, #0x8]
    2c14:      	cmp	x23, x15
    2c18:      	b.ge	0x2cb0 <_stogir.verify.classifications+0x514>
    2c1c:      	ldr	x15, [x22, #0x78]
    2c20:      	add	x15, x11, x15
    2c24:      	ldr	w15, [x15]
    2c28:      	sxtw	x15, w15
    2c2c:      	cmp	x15, #0x0
    2c30:      	b.lt	0x2cb0 <_stogir.verify.classifications+0x514>
    2c34:      	cmp	x14, #0x1
    2c38:      	b.lt	0x2d30 <_stogir.verify.classifications+0x594>
    2c3c:      	ldr	x15, [x22, #0x78]
    2c40:      	add	x15, x11, x15
    2c44:      	ldr	w15, [x15]
    2c48:      	sxtw	x15, w15
    2c4c:      	cmp	x14, x15
    2c50:      	b.gt	0x2d30 <_stogir.verify.classifications+0x594>
    2c54:      	ldr	x15, [x22]
    2c58:      	asr	x16, x14, #63
    2c5c:      	lsr	x16, x16, #62
    2c60:      	add	x19, x14, x16
    2c64:      	asr	x19, x19, #2
    2c68:      	asr	x16, x14, #63
    2c6c:      	lsr	x16, x16, #62
    2c70:      	add	x14, x14, x16
    2c74:      	and	x14, x14, #0x3
    2c78:      	sub	x14, x14, x16
    2c7c:      	add	x19, x19, x23
    2c80:      	add	x15, x15, x19, lsl #4
    2c84:      	add	x14, x15, x14, lsl #2
    2c88:      	ldr	w14, [x14]
    2c8c:      	sxtw	x14, w14
    2c90:      	and	x14, x14, #0xffffffff
    2c94:      	mov	x15, #0x1               ; =1
    2c98:      	b	0x2d38 <_stogir.verify.classifications+0x59c>
    2c9c:      	movz	x20, #0x0, lsl #48
    2ca0:      	b	0x28bc <_stogir.verify.classifications+0x120>
    2ca4:      	lsr	w14, w14, #0
    2ca8:      	sxtw	x14, w14
    2cac:      	b	0x2b90 <_stogir.verify.classifications+0x3f4>
    2cb0:      	movz	x15, #0x0, lsl #48
    2cb4:      	movz	x14, #0x0, lsl #48
    2cb8:      	lsr	w15, w15, #0
    2cbc:      	lsr	x16, x15, #0
    2cc0:      	cmp	x16, #0x1
    2cc4:      	b.eq	0x2ce0 <_stogir.verify.classifications+0x544>
    2cc8:      	b.lo	0x2cd0 <_stogir.verify.classifications+0x534>
    2ccc:      	b	0x2ce4 <_stogir.verify.classifications+0x548>
    2cd0:      	cmp	x16, #0x0
    2cd4:      	b.eq	0x2cdc <_stogir.verify.classifications+0x540>
    2cd8:      	b	0x2ce4 <_stogir.verify.classifications+0x548>
    2cdc:      	b	0x2ce8 <_stogir.verify.classifications+0x54c>
    2ce0:      	b	0x2ca4 <_stogir.verify.classifications+0x508>
    2ce4:      	b	0x2d4c <_stogir.verify.classifications+0x5b0>
    2ce8:      	movz	x14, #0x0, lsl #48
    2cec:      	b	0x2cac <_stogir.verify.classifications+0x510>
    2cf0:      	cmp	x19, #0x18
    2cf4:      	b.ne	0x2d00 <_stogir.verify.classifications+0x564>
    2cf8:      	mov	x0, #0x1                ; =1
    2cfc:      	b	0x28ac <_stogir.verify.classifications+0x110>
    2d00:      	cmp	x19, #0x19
    2d04:      	b.ne	0x2d10 <_stogir.verify.classifications+0x574>
    2d08:      	mov	x0, #0x1                ; =1
    2d0c:      	b	0x28ac <_stogir.verify.classifications+0x110>
    2d10:      	cmp	x21, #0xc
    2d14:      	b.eq	0x28a8 <_stogir.verify.classifications+0x10c>
    2d18:      	cmp	x21, #0xd
    2d1c:      	b.eq	0x28a8 <_stogir.verify.classifications+0x10c>
    2d20:      	cmp	x28, #0xc
    2d24:      	b.ne	0x2d3c <_stogir.verify.classifications+0x5a0>
    2d28:      	mov	x0, #0x1                ; =1
    2d2c:      	b	0x2d48 <_stogir.verify.classifications+0x5ac>
    2d30:      	movz	x15, #0x0, lsl #48
    2d34:      	movz	x14, #0x0, lsl #48
    2d38:      	b	0x2cb8 <_stogir.verify.classifications+0x51c>
    2d3c:      	cmp	x28, #0xd
    2d40:      	cset	w0, eq
    2d44:      	ubfx	x0, x0, #0, #8
    2d48:      	b	0x28ac <_stogir.verify.classifications+0x110>
    2d4c:      	brk	#0
    2d50:      	b	0x2d4c <_stogir.verify.classifications+0x5b0>

0000000000002d54 <_stogir.vector-lanes.operation?>:
    2d54:      	sxtw	x0, w0
    2d58:      	cmp	x0, #0x3d
    2d5c:      	b.lt	0x2d70 <_stogir.vector-lanes.operation?+0x1c>
    2d60:      	cmp	x0, #0x3f
    2d64:      	cset	w0, le
    2d68:      	ubfx	x0, x0, #0, #8
    2d6c:      	b	0x2d74 <_stogir.vector-lanes.operation?+0x20>
    2d70:      	movz	x0, #0x0, lsl #48
    2d74:      	ret

0000000000002d78 <_stogir.vector.validate>:
    2d78:      	sub	sp, sp, #0x210
    2d7c:      	str	x29, [sp]
    2d80:      	str	x30, [sp, #0x8]
    2d84:      	mov	x29, sp
    2d88:      	str	x19, [sp, #0x1c0]
    2d8c:      	str	x20, [sp, #0x1c8]
    2d90:      	str	x21, [sp, #0x1d0]
    2d94:      	str	x22, [sp, #0x1d8]
    2d98:      	str	x23, [sp, #0x1e0]
    2d9c:      	str	x24, [sp, #0x1e8]
    2da0:      	str	x25, [sp, #0x1f0]
    2da4:      	str	x26, [sp, #0x1f8]
    2da8:      	str	x27, [sp, #0x200]
    2dac:      	str	x28, [sp, #0x208]
    2db0:      	lsr	w19, w1, #0
    2db4:      	mov	x20, x8
    2db8:      	add	x8, sp, #0x10
    2dbc:      	mov	x21, x0
    2dc0:      	mov	w22, w1
    2dc4:      	mov	w1, w19
    2dc8:      	mov	w23, w2
    2dcc:      	bl	0x2dcc <_stogir.vector.validate+0x54>
		0000000000002dcc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    2dd0:      	add	x16, sp, #0x10
    2dd4:      	ldr	w0, [x16]
    2dd8:      	lsr	x16, x0, #0
    2ddc:      	cmp	x16, #0x1
    2de0:      	b.eq	0x2dfc <_stogir.vector.validate+0x84>
    2de4:      	b.lo	0x2dec <_stogir.vector.validate+0x74>
    2de8:      	b	0x2e00 <_stogir.vector.validate+0x88>
    2dec:      	cmp	x16, #0x0
    2df0:      	b.eq	0x2df8 <_stogir.vector.validate+0x80>
    2df4:      	b	0x2e00 <_stogir.vector.validate+0x88>
    2df8:      	b	0x2e04 <_stogir.vector.validate+0x8c>
    2dfc:      	b	0x2e98 <_stogir.vector.validate+0x120>
    2e00:      	b	0x30b4 <_stogir.vector.validate+0x33c>
    2e04:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002e04:  ARM64_RELOC_PAGE21	l_stogir.346
    2e08:      	ldr	x16, [x16]
		0000000000002e08:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    2e0c:      	orr	x19, x16, xzr
    2e10:      	str	x20, [sp, #0x1a8]
    2e14:      	mov	x0, #0x1                ; =1
    2e18:      	mov	x25, #0x1a              ; =26
    2e1c:      	b	0x2e50 <_stogir.vector.validate+0xd8>
    2e20:      	lsr	w23, w23, #0
    2e24:      	add	x8, sp, #0x70
    2e28:      	mov	x0, x21
    2e2c:      	ldr	w1, [sp, #0x1a0]
    2e30:      	mov	w2, w23
    2e34:      	bl	0x2e34 <_stogir.vector.validate+0xbc>
		0000000000002e34:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    2e38:      	add	x16, sp, #0x70
    2e3c:      	ldr	x0, [x16]
    2e40:      	add	x16, sp, #0x70
    2e44:      	ldr	x19, [x16, #0x8]
    2e48:      	add	x16, sp, #0x70
    2e4c:      	ldr	x25, [x16, #0x10]
    2e50:      	ldr	x1, [sp, #0x1a8]
    2e54:      	str	x0, [x1]
    2e58:      	str	x19, [x1, #0x8]
    2e5c:      	str	x25, [x1, #0x10]
    2e60:      	ldr	x19, [sp, #0x1c0]
    2e64:      	ldr	x20, [sp, #0x1c8]
    2e68:      	ldr	x21, [sp, #0x1d0]
    2e6c:      	ldr	x22, [sp, #0x1d8]
    2e70:      	ldr	x23, [sp, #0x1e0]
    2e74:      	ldr	x24, [sp, #0x1e8]
    2e78:      	ldr	x25, [sp, #0x1f0]
    2e7c:      	ldr	x26, [sp, #0x1f8]
    2e80:      	ldr	x27, [sp, #0x200]
    2e84:      	ldr	x28, [sp, #0x208]
    2e88:      	ldr	x29, [sp]
    2e8c:      	ldr	x30, [sp, #0x8]
    2e90:      	add	sp, sp, #0x210
    2e94:      	ret
    2e98:      	sxtw	x22, w22
    2e9c:      	add	x16, sp, #0x10
    2ea0:      	orr	x0, x16, xzr
    2ea4:      	cmp	x22, #0x0
    2ea8:      	cset	w24, le
    2eac:      	add	x0, x0, #0x8
    2eb0:      	add	x16, sp, #0x10
    2eb4:      	ldr	x25, [x16, #0x8]
    2eb8:      	add	x16, sp, #0x40
    2ebc:      	str	x25, [x16]
    2ec0:      	ldr	x0, [x0, #0x8]
    2ec4:      	add	x16, sp, #0x40
    2ec8:      	str	x0, [x16, #0x8]
    2ecc:      	uxtb	w16, w24
    2ed0:      	cmp	w16, wzr
    2ed4:      	b.eq	0x2ef4 <_stogir.vector.validate+0x17c>
    2ed8:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002ed8:  ARM64_RELOC_PAGE21	l_stogir.347
    2edc:      	ldr	x16, [x16]
		0000000000002edc:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    2ee0:      	orr	x19, x16, xzr
    2ee4:      	str	x20, [sp, #0x1a8]
    2ee8:      	mov	x0, #0x1                ; =1
    2eec:      	mov	x25, #0x3b              ; =59
    2ef0:      	b	0x2e50 <_stogir.vector.validate+0xd8>
    2ef4:      	lsl	x26, x22, #2
    2ef8:      	uxtb	w0, w25
    2efc:      	orr	x27, x0, xzr
    2f00:      	ldr	x0, [x21, #0x78]
    2f04:      	cmp	x27, #0x44
    2f08:      	cset	w1, eq
    2f0c:      	add	x0, x0, x22, lsl #2
    2f10:      	ldr	w28, [x0]
    2f14:      	cmp	x27, #0x24
    2f18:      	b.ne	0x2f5c <_stogir.vector.validate+0x1e4>
    2f1c:      	str	x20, [sp, #0x1a8]
    2f20:      	str	w19, [sp, #0x1a0]
    2f24:      	uxtb	w16, w1
    2f28:      	cmp	w16, wzr
    2f2c:      	b.eq	0x2e20 <_stogir.vector.validate+0xa8>
    2f30:      	add	x8, sp, #0x50
    2f34:      	mov	x0, x21
    2f38:      	ldr	w1, [sp, #0x1a0]
    2f3c:      	bl	0x2f3c <_stogir.vector.validate+0x1c4>
		0000000000002f3c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    2f40:      	add	x16, sp, #0x50
    2f44:      	ldr	x0, [x16]
    2f48:      	add	x16, sp, #0x50
    2f4c:      	ldr	x19, [x16, #0x8]
    2f50:      	add	x16, sp, #0x50
    2f54:      	ldr	x25, [x16, #0x10]
    2f58:      	b	0x2e50 <_stogir.vector.validate+0xd8>
    2f5c:      	uxtb	w16, w1
    2f60:      	cmp	w16, wzr
    2f64:      	b.ne	0x37dc <_stogir.vector.validate+0xa64>
    2f68:      	cmp	x27, #0x3c
    2f6c:      	b.ne	0x3020 <_stogir.vector.validate+0x2a8>
    2f70:      	add	x8, sp, #0x90
    2f74:      	mov	x0, x21
    2f78:      	mov	w1, w19
    2f7c:      	bl	0x2f7c <_stogir.vector.validate+0x204>
		0000000000002f7c:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    2f80:      	add	x16, sp, #0x90
    2f84:      	ldr	x0, [x16]
    2f88:      	add	x16, sp, #0x90
    2f8c:      	ldr	x19, [x16, #0x8]
    2f90:      	add	x16, sp, #0x90
    2f94:      	ldr	x25, [x16, #0x10]
    2f98:      	str	x20, [sp, #0x1a8]
    2f9c:      	b	0x301c <_stogir.vector.validate+0x2a4>
    2fa0:      	cmp	x27, #0x41
    2fa4:      	cset	w0, eq
    2fa8:      	cmp	x27, #0x48
    2fac:      	cset	w1, eq
    2fb0:      	cmp	x27, #0x55
    2fb4:      	cset	w2, ge
    2fb8:      	cmp	x27, #0x58
    2fbc:      	cset	w3, le
    2fc0:      	cmp	x27, #0x47
    2fc4:      	b.ne	0x30bc <_stogir.vector.validate+0x344>
    2fc8:      	str	x20, [sp, #0x1a8]
    2fcc:      	str	w19, [sp, #0x1a0]
    2fd0:      	mov	w19, w0
    2fd4:      	mov	w20, w1
    2fd8:      	str	w2, [sp, #0x1b0]
    2fdc:      	str	w3, [sp, #0x1b8]
    2fe0:      	mov	x0, x21
    2fe4:      	ldr	w1, [sp, #0x1a0]
    2fe8:      	bl	0x2fe8 <_stogir.vector.validate+0x270>
		0000000000002fe8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2fec:      	cmp	x0, #0x0
    2ff0:      	b.eq	0x30e0 <_stogir.vector.validate+0x368>
    2ff4:      	add	x8, sp, #0xf0
    2ff8:      	mov	x0, x21
    2ffc:      	ldr	w1, [sp, #0x1a0]
    3000:      	bl	0x3000 <_stogir.vector.validate+0x288>
		0000000000003000:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    3004:      	add	x16, sp, #0xf0
    3008:      	ldr	x0, [x16]
    300c:      	add	x16, sp, #0xf0
    3010:      	ldr	x19, [x16, #0x8]
    3014:      	add	x16, sp, #0xf0
    3018:      	ldr	x25, [x16, #0x10]
    301c:      	b	0x2e50 <_stogir.vector.validate+0xd8>
    3020:      	cmp	x27, #0x3d
    3024:      	b.lt	0x3068 <_stogir.vector.validate+0x2f0>
    3028:      	cmp	x27, #0x3f
    302c:      	b.gt	0x3068 <_stogir.vector.validate+0x2f0>
    3030:      	lsr	w23, w23, #0
    3034:      	add	x8, sp, #0xb0
    3038:      	mov	x0, x21
    303c:      	mov	w1, w19
    3040:      	mov	w2, w23
    3044:      	bl	0x3044 <_stogir.vector.validate+0x2cc>
		0000000000003044:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    3048:      	add	x16, sp, #0xb0
    304c:      	ldr	x0, [x16]
    3050:      	add	x16, sp, #0xb0
    3054:      	ldr	x19, [x16, #0x8]
    3058:      	add	x16, sp, #0xb0
    305c:      	ldr	x25, [x16, #0x10]
    3060:      	str	x20, [sp, #0x1a8]
    3064:      	b	0x301c <_stogir.vector.validate+0x2a4>
    3068:      	mov	x0, x21
    306c:      	mov	w1, w19
    3070:      	bl	0x3070 <_stogir.vector.validate+0x2f8>
		0000000000003070:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    3074:      	cmp	x0, #0x0
    3078:      	b.eq	0x2fa0 <_stogir.vector.validate+0x228>
    307c:      	lsr	w23, w23, #0
    3080:      	add	x8, sp, #0xd0
    3084:      	mov	x0, x21
    3088:      	mov	w1, w19
    308c:      	mov	w2, w23
    3090:      	bl	0x3090 <_stogir.vector.validate+0x318>
		0000000000003090:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    3094:      	add	x16, sp, #0xd0
    3098:      	ldr	x0, [x16]
    309c:      	add	x16, sp, #0xd0
    30a0:      	ldr	x19, [x16, #0x8]
    30a4:      	add	x16, sp, #0xd0
    30a8:      	ldr	x25, [x16, #0x10]
    30ac:      	str	x20, [sp, #0x1a8]
    30b0:      	b	0x301c <_stogir.vector.validate+0x2a4>
    30b4:      	brk	#0
    30b8:      	b	0x30b4 <_stogir.vector.validate+0x33c>
    30bc:      	cmp	x27, #0x4f
    30c0:      	b.ne	0x315c <_stogir.vector.validate+0x3e4>
    30c4:      	str	x20, [sp, #0x1a8]
    30c8:      	str	w19, [sp, #0x1a0]
    30cc:      	mov	w19, w0
    30d0:      	mov	w20, w1
    30d4:      	str	w2, [sp, #0x1b0]
    30d8:      	str	w3, [sp, #0x1b8]
    30dc:      	b	0x2fe0 <_stogir.vector.validate+0x268>
    30e0:      	uxtb	w16, w19
    30e4:      	cmp	w16, wzr
    30e8:      	b.ne	0x3128 <_stogir.vector.validate+0x3b0>
    30ec:      	uxtb	w16, w20
    30f0:      	cmp	w16, wzr
    30f4:      	b.ne	0x3128 <_stogir.vector.validate+0x3b0>
    30f8:      	ldr	w0, [sp, #0x1b0]
    30fc:      	uxtb	w16, w0
    3100:      	cmp	w16, wzr
    3104:      	b.eq	0x3118 <_stogir.vector.validate+0x3a0>
    3108:      	ldr	w0, [sp, #0x1b8]
    310c:      	uxtb	w16, w0
    3110:      	cmp	w16, wzr
    3114:      	b.ne	0x3128 <_stogir.vector.validate+0x3b0>
    3118:      	movz	x0, #0x0, lsl #48
    311c:      	movz	x19, #0x0, lsl #48
    3120:      	movz	x25, #0x0, lsl #48
    3124:      	b	0x3158 <_stogir.vector.validate+0x3e0>
    3128:      	lsr	w23, w23, #0
    312c:      	add	x8, sp, #0x110
    3130:      	mov	x0, x21
    3134:      	ldr	w1, [sp, #0x1a0]
    3138:      	mov	w2, w23
    313c:      	bl	0x313c <_stogir.vector.validate+0x3c4>
		000000000000313c:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    3140:      	add	x16, sp, #0x110
    3144:      	ldr	x0, [x16]
    3148:      	add	x16, sp, #0x110
    314c:      	ldr	x19, [x16, #0x8]
    3150:      	add	x16, sp, #0x110
    3154:      	ldr	x25, [x16, #0x10]
    3158:      	b	0x301c <_stogir.vector.validate+0x2a4>
    315c:      	cmp	x27, #0x50
    3160:      	b.eq	0x37e8 <_stogir.vector.validate+0xa70>
    3164:      	cmp	x27, #0x78
    3168:      	b.ne	0x3188 <_stogir.vector.validate+0x410>
    316c:      	str	x20, [sp, #0x1a8]
    3170:      	str	w19, [sp, #0x1a0]
    3174:      	mov	w19, w0
    3178:      	mov	w20, w1
    317c:      	str	w2, [sp, #0x1b0]
    3180:      	str	w3, [sp, #0x1b8]
    3184:      	b	0x2fe0 <_stogir.vector.validate+0x268>
    3188:      	uxtb	w16, w0
    318c:      	cmp	w16, wzr
    3190:      	b.ne	0x3288 <_stogir.vector.validate+0x510>
    3194:      	uxtb	w16, w1
    3198:      	cmp	w16, wzr
    319c:      	b.ne	0x3288 <_stogir.vector.validate+0x510>
    31a0:      	uxtb	w16, w2
    31a4:      	cmp	w16, wzr
    31a8:      	b.eq	0x31b8 <_stogir.vector.validate+0x440>
    31ac:      	uxtb	w16, w3
    31b0:      	cmp	w16, wzr
    31b4:      	b.ne	0x3288 <_stogir.vector.validate+0x510>
    31b8:      	str	w2, [sp, #0x1b0]
    31bc:      	str	w3, [sp, #0x1b8]
    31c0:      	str	w19, [sp, #0x1a0]
    31c4:      	str	x20, [sp, #0x1a8]
    31c8:      	mov	w20, w1
    31cc:      	mov	w1, w19
    31d0:      	mov	w19, w0
    31d4:      	mov	x0, x21
    31d8:      	bl	0x31d8 <_stogir.vector.validate+0x460>
		00000000000031d8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    31dc:      	cmp	x0, #0x0
    31e0:      	b.ne	0x2fe0 <_stogir.vector.validate+0x268>
    31e4:      	sxtw	x28, w28
    31e8:      	lsr	w25, w25, #0
    31ec:      	ubfx	x0, x25, #8, #8
    31f0:      	orr	x1, x0, xzr
    31f4:      	lsr	w20, w1, #0
    31f8:      	cmp	x27, #0x5b
    31fc:      	b.eq	0x32bc <_stogir.vector.validate+0x544>
    3200:      	cmp	x27, #0x5c
    3204:      	b.eq	0x32bc <_stogir.vector.validate+0x544>
    3208:      	orr	x25, x0, xzr
    320c:      	cmp	x27, #0x5d
    3210:      	b.ne	0x3330 <_stogir.vector.validate+0x5b8>
    3214:      	mov	x27, x25
    3218:      	cmp	x28, #0x3
    321c:      	b.ne	0x3318 <_stogir.vector.validate+0x5a0>
    3220:      	cmp	x27, #0x0
    3224:      	b.ne	0x3318 <_stogir.vector.validate+0x5a0>
    3228:      	lsr	w23, w23, #0
    322c:      	add	x16, sp, #0x40
    3230:      	ldr	w0, [x16, #0x4]
    3234:      	add	x16, sp, #0x40
    3238:      	ldr	w1, [x16, #0x8]
    323c:      	lsr	w0, w0, #0
    3240:      	add	x16, sp, #0x40
    3244:      	ldr	w2, [x16, #0xc]
    3248:      	lsr	w1, w1, #0
    324c:      	lsr	w2, w2, #0
    3250:      	add	x8, sp, #0x150
    3254:      	mov	w3, w1
    3258:      	mov	w1, w23
    325c:      	mov	w4, w2
    3260:      	mov	w2, w0
    3264:      	mov	x0, x21
    3268:      	bl	0x3268 <_stogir.vector.validate+0x4f0>
		0000000000003268:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    326c:      	add	x16, sp, #0x150
    3270:      	ldr	x0, [x16]
    3274:      	add	x16, sp, #0x150
    3278:      	ldr	x19, [x16, #0x8]
    327c:      	add	x16, sp, #0x150
    3280:      	ldr	x25, [x16, #0x10]
    3284:      	b	0x332c <_stogir.vector.validate+0x5b4>
    3288:      	str	x20, [sp, #0x1a8]
    328c:      	str	w19, [sp, #0x1a0]
    3290:      	mov	w19, w0
    3294:      	mov	w20, w1
    3298:      	str	w2, [sp, #0x1b0]
    329c:      	str	w3, [sp, #0x1b8]
    32a0:      	b	0x2fe0 <_stogir.vector.validate+0x268>
    32a4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		00000000000032a4:  ARM64_RELOC_PAGE21	l_stogir.348
    32a8:      	ldr	x16, [x16]
		00000000000032a8:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    32ac:      	orr	x19, x16, xzr
    32b0:      	mov	x0, #0x1                ; =1
    32b4:      	mov	x25, #0x19              ; =25
    32b8:      	b	0x301c <_stogir.vector.validate+0x2a4>
    32bc:      	cmp	x28, #0x2
    32c0:      	b.ne	0x32a4 <_stogir.vector.validate+0x52c>
    32c4:      	lsr	w23, w23, #0
    32c8:      	add	x16, sp, #0x40
    32cc:      	ldr	w0, [x16, #0x4]
    32d0:      	add	x16, sp, #0x40
    32d4:      	ldr	w1, [x16, #0x8]
    32d8:      	lsr	w0, w0, #0
    32dc:      	lsr	w1, w1, #0
    32e0:      	add	x8, sp, #0x130
    32e4:      	mov	w2, w23
    32e8:      	mov	w3, w0
    32ec:      	mov	x0, x21
    32f0:      	mov	w4, w1
    32f4:      	mov	w1, w20
    32f8:      	bl	0x32f8 <_stogir.vector.validate+0x580>
		00000000000032f8:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    32fc:      	add	x16, sp, #0x130
    3300:      	ldr	x0, [x16]
    3304:      	add	x16, sp, #0x130
    3308:      	ldr	x19, [x16, #0x8]
    330c:      	add	x16, sp, #0x130
    3310:      	ldr	x25, [x16, #0x10]
    3314:      	b	0x32b8 <_stogir.vector.validate+0x540>
    3318:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003318:  ARM64_RELOC_PAGE21	l_stogir.349
    331c:      	ldr	x16, [x16]
		000000000000331c:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    3320:      	orr	x19, x16, xzr
    3324:      	mov	x0, #0x1                ; =1
    3328:      	mov	x25, #0x1a              ; =26
    332c:      	b	0x32b8 <_stogir.vector.validate+0x540>
    3330:      	cmp	x27, #0x5e
    3334:      	b.eq	0x3804 <_stogir.vector.validate+0xa8c>
    3338:      	cmp	x27, #0x43
    333c:      	b.ne	0x33b4 <_stogir.vector.validate+0x63c>
    3340:      	cmp	x25, #0xf
    3344:      	b.le	0x36f4 <_stogir.vector.validate+0x97c>
    3348:      	cmp	x25, #0x80
    334c:      	b.ge	0x36f4 <_stogir.vector.validate+0x97c>
    3350:      	and	x0, x25, #0xf
    3354:      	lsr	w0, w0, #0
    3358:      	sxtw	x0, w0
    335c:      	cmp	x0, #0x1
    3360:      	b.lt	0x36f4 <_stogir.vector.validate+0x97c>
    3364:      	cmp	x0, #0xd
    3368:      	b.gt	0x36f4 <_stogir.vector.validate+0x97c>
    336c:      	lsr	w23, w23, #0
    3370:      	mov	w0, w20
    3374:      	mov	w1, w23
    3378:      	bl	0x3378 <_stogir.vector.validate+0x600>
		0000000000003378:  ARM64_RELOC_BRANCH26	_stogir.types.size
    337c:      	lsr	w0, w0, #0
    3380:      	sxtw	x0, w0
    3384:      	cmp	x0, #0x0
    3388:      	b.le	0x36f4 <_stogir.vector.validate+0x97c>
    338c:      	cmp	x28, #0x3
    3390:      	b.lt	0x36f4 <_stogir.vector.validate+0x97c>
    3394:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003394:  ARM64_RELOC_PAGE21	l_stogir.350
    3398:      	ldr	x16, [x16]
		0000000000003398:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    339c:      	orr	x19, x16, xzr
    33a0:      	mov	x27, x25
    33a4:      	movz	x25, #0x0, lsl #48
    33a8:      	b	0x3708 <_stogir.vector.validate+0x990>
    33ac:      	mov	x0, #0x1                ; =1
    33b0:      	b	0x332c <_stogir.vector.validate+0x5b4>
    33b4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		00000000000033b4:  ARM64_RELOC_PAGE21	l_stogir.351
    33b8:      	ldr	x16, [x16]
		00000000000033b8:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    33bc:      	orr	x19, x16, xzr
    33c0:      	mov	x0, #0x1                ; =1
    33c4:      	mov	x25, #0x28              ; =40
    33c8:      	b	0x33b0 <_stogir.vector.validate+0x638>
    33cc:      	add	x16, sp, #0x40
    33d0:      	ldr	w0, [x16, #0x4]
    33d4:      	sxtw	x0, w0
    33d8:      	ldr	x1, [x21, #0x78]
    33dc:      	add	x0, x1, x0, lsl #2
    33e0:      	ldr	w0, [x0]
    33e4:      	sxtw	x0, w0
    33e8:      	add	x0, x0, #0x1
    33ec:      	lsr	w0, w0, #0
    33f0:      	sxtw	x0, w0
    33f4:      	cmp	x28, x0
    33f8:      	cset	w0, eq
    33fc:      	uxtb	w16, w0
    3400:      	cmp	w16, wzr
    3404:      	cset	x0, eq
    3408:      	cmp	x0, #0x0
    340c:      	b.eq	0x3420 <_stogir.vector.validate+0x6a8>
    3410:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003410:  ARM64_RELOC_PAGE21	l_stogir.352
    3414:      	ldr	x16, [x16]
		0000000000003414:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    3418:      	orr	x19, x16, xzr
    341c:      	mov	x25, #0x19              ; =25
    3420:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003420:  ARM64_RELOC_PAGE21	l_stogir.353
    3424:      	ldr	x16, [x16]
		0000000000003424:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    3428:      	orr	x0, x16, xzr
    342c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		000000000000342c:  ARM64_RELOC_PAGE21	l_stogir.354
    3430:      	ldr	x16, [x16]
		0000000000003430:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    3434:      	orr	x1, x16, xzr
    3438:      	add	x2, x21, #0x78
    343c:      	add	x3, x21, #0x28
    3440:      	add	x4, x21, #0x50
    3444:      	add	x5, x21, #0x78
    3448:      	mov	x6, #0x2                ; =2
    344c:      	b	0x34c4 <_stogir.vector.validate+0x74c>
    3450:      	lsr	w7, w7, #0
    3454:      	ubfx	x7, x7, #8, #8
    3458:      	cmp	x7, x27
    345c:      	b.eq	0x3468 <_stogir.vector.validate+0x6f0>
    3460:      	mov	x19, x1
    3464:      	mov	x25, #0x1e              ; =30
    3468:      	b	0x34b8 <_stogir.vector.validate+0x740>
    346c:      	movz	x8, #0x0, lsl #48
    3470:      	movz	x7, #0x0, lsl #48
    3474:      	b	0x3480 <_stogir.vector.validate+0x708>
    3478:      	movz	x8, #0x0, lsl #48
    347c:      	movz	x7, #0x0, lsl #48
    3480:      	lsr	w8, w8, #0
    3484:      	lsr	x16, x8, #0
    3488:      	cmp	x16, #0x1
    348c:      	b.eq	0x34a8 <_stogir.vector.validate+0x730>
    3490:      	b.lo	0x3498 <_stogir.vector.validate+0x720>
    3494:      	b	0x34ac <_stogir.vector.validate+0x734>
    3498:      	cmp	x16, #0x0
    349c:      	b.eq	0x34a4 <_stogir.vector.validate+0x72c>
    34a0:      	b	0x34ac <_stogir.vector.validate+0x734>
    34a4:      	b	0x34b0 <_stogir.vector.validate+0x738>
    34a8:      	b	0x3518 <_stogir.vector.validate+0x7a0>
    34ac:      	b	0x37c4 <_stogir.vector.validate+0xa4c>
    34b0:      	mov	x19, x0
    34b4:      	mov	x25, #0x18              ; =24
    34b8:      	add	x6, x6, #0x1
    34bc:      	lsr	w6, w6, #0
    34c0:      	sxtw	x6, w6
    34c4:      	cmp	x25, #0x0
    34c8:      	b.ne	0x363c <_stogir.vector.validate+0x8c4>
    34cc:      	cmp	x6, x28
    34d0:      	b.gt	0x363c <_stogir.vector.validate+0x8c4>
    34d4:      	uxtb	w16, w24
    34d8:      	cmp	w16, wzr
    34dc:      	b.ne	0x3478 <_stogir.vector.validate+0x700>
    34e0:      	ldr	x7, [x21, #0x8]
    34e4:      	cmp	x22, x7
    34e8:      	b.ge	0x3580 <_stogir.vector.validate+0x808>
    34ec:      	ldr	x7, [x5, #0x8]
    34f0:      	cmp	x22, x7
    34f4:      	b.ge	0x3578 <_stogir.vector.validate+0x800>
    34f8:      	ldr	x7, [x21, #0x78]
    34fc:      	add	x7, x26, x7
    3500:      	ldr	w7, [x7]
    3504:      	sxtw	x7, w7
    3508:      	cmp	x7, #0x0
    350c:      	cset	w7, ge
    3510:      	ubfx	x7, x7, #0, #8
    3514:      	b	0x357c <_stogir.vector.validate+0x804>
    3518:      	lsr	w7, w7, #0
    351c:      	sxtw	x7, w7
    3520:      	cmp	x7, #0x0
    3524:      	cset	w8, gt
    3528:      	movz	x16, #0x0, lsl #48
    352c:      	sub	x9, x16, x7
    3530:      	sub	x10, x9, #0x1
    3534:      	uxtb	w16, w8
    3538:      	cmp	w16, wzr
    353c:      	b.eq	0x35fc <_stogir.vector.validate+0x884>
    3540:      	ldr	x9, [x21, #0x8]
    3544:      	cmp	x7, x9
    3548:      	b.ge	0x366c <_stogir.vector.validate+0x8f4>
    354c:      	ldr	x9, [x2, #0x8]
    3550:      	cmp	x7, x9
    3554:      	b.ge	0x3774 <_stogir.vector.validate+0x9fc>
    3558:      	ldr	x9, [x21, #0x78]
    355c:      	add	x9, x9, x7, lsl #2
    3560:      	ldr	w9, [x9]
    3564:      	sxtw	x9, w9
    3568:      	cmp	x9, #0x0
    356c:      	cset	w9, ge
    3570:      	ubfx	x9, x9, #0, #8
    3574:      	b	0x3778 <_stogir.vector.validate+0xa00>
    3578:      	movz	x7, #0x0, lsl #48
    357c:      	b	0x3584 <_stogir.vector.validate+0x80c>
    3580:      	movz	x7, #0x0, lsl #48
    3584:      	cmp	x7, #0x0
    3588:      	b.eq	0x3478 <_stogir.vector.validate+0x700>
    358c:      	lsr	w7, w6, #0
    3590:      	sxtw	x7, w7
    3594:      	cmp	x7, #0x1
    3598:      	b.lt	0x346c <_stogir.vector.validate+0x6f4>
    359c:      	ldr	x8, [x21, #0x78]
    35a0:      	add	x8, x26, x8
    35a4:      	ldr	w8, [x8]
    35a8:      	sxtw	x8, w8
    35ac:      	cmp	x7, x8
    35b0:      	b.gt	0x346c <_stogir.vector.validate+0x6f4>
    35b4:      	ldr	x8, [x21]
    35b8:      	asr	x16, x7, #63
    35bc:      	lsr	x16, x16, #62
    35c0:      	add	x9, x7, x16
    35c4:      	asr	x9, x9, #2
    35c8:      	asr	x16, x7, #63
    35cc:      	lsr	x16, x16, #62
    35d0:      	add	x7, x7, x16
    35d4:      	and	x7, x7, #0x3
    35d8:      	sub	x7, x7, x16
    35dc:      	add	x9, x9, x22
    35e0:      	add	x8, x8, x9, lsl #4
    35e4:      	add	x7, x8, x7, lsl #2
    35e8:      	ldr	w7, [x7]
    35ec:      	sxtw	x7, w7
    35f0:      	and	x7, x7, #0xffffffff
    35f4:      	mov	x8, #0x1                ; =1
    35f8:      	b	0x3474 <_stogir.vector.validate+0x6fc>
    35fc:      	cmp	x7, #0x0
    3600:      	b.ge	0x3674 <_stogir.vector.validate+0x8fc>
    3604:      	ldr	x11, [x3, #0x8]
    3608:      	ldr	x12, [x4, #0x8]
    360c:      	cmp	x11, x12
    3610:      	b.ne	0x376c <_stogir.vector.validate+0x9f4>
    3614:      	cmp	x9, x11
    3618:      	b.gt	0x37a0 <_stogir.vector.validate+0xa28>
    361c:      	ldr	x9, [x21, #0x50]
    3620:      	add	x9, x9, x10, lsl #2
    3624:      	ldr	w9, [x9]
    3628:      	sxtw	x9, w9
    362c:      	cmp	x9, #0x0
    3630:      	cset	w9, gt
    3634:      	ubfx	x9, x9, #0, #8
    3638:      	b	0x37a4 <_stogir.vector.validate+0xa2c>
    363c:      	cmp	x25, #0x0
    3640:      	b.ne	0x33ac <_stogir.vector.validate+0x634>
    3644:      	lsr	w23, w23, #0
    3648:      	mov	w0, w20
    364c:      	mov	w1, w23
    3650:      	bl	0x3650 <_stogir.vector.validate+0x8d8>
		0000000000003650:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3654:      	lsr	w0, w0, #0
    3658:      	sxtw	x0, w0
    365c:      	and	x19, x0, #0xffffffff
    3660:      	movz	x0, #0x0, lsl #48
    3664:      	movz	x25, #0x0, lsl #48
    3668:      	b	0x33b0 <_stogir.vector.validate+0x638>
    366c:      	movz	x9, #0x0, lsl #48
    3670:      	b	0x3678 <_stogir.vector.validate+0x900>
    3674:      	movz	x9, #0x0, lsl #48
    3678:      	cmp	x9, #0x0
    367c:      	b.eq	0x36b0 <_stogir.vector.validate+0x938>
    3680:      	uxtb	w16, w8
    3684:      	cmp	w16, wzr
    3688:      	b.eq	0x369c <_stogir.vector.validate+0x924>
    368c:      	ldr	x8, [x21]
    3690:      	add	x7, x8, x7, lsl #4
    3694:      	ldr	x7, [x7]
    3698:      	b	0x36a8 <_stogir.vector.validate+0x930>
    369c:      	ldr	x7, [x21, #0x28]
    36a0:      	add	x7, x7, x10, lsl #4
    36a4:      	ldr	x7, [x7]
    36a8:      	mov	x8, #0x1                ; =1
    36ac:      	b	0x36b8 <_stogir.vector.validate+0x940>
    36b0:      	movz	x8, #0x0, lsl #48
    36b4:      	movz	x7, #0x0, lsl #48
    36b8:      	lsr	w8, w8, #0
    36bc:      	lsr	x16, x8, #0
    36c0:      	cmp	x16, #0x1
    36c4:      	b.eq	0x36e0 <_stogir.vector.validate+0x968>
    36c8:      	b.lo	0x36d0 <_stogir.vector.validate+0x958>
    36cc:      	b	0x36e4 <_stogir.vector.validate+0x96c>
    36d0:      	cmp	x16, #0x0
    36d4:      	b.eq	0x36dc <_stogir.vector.validate+0x964>
    36d8:      	b	0x36e4 <_stogir.vector.validate+0x96c>
    36dc:      	b	0x36e8 <_stogir.vector.validate+0x970>
    36e0:      	b	0x3450 <_stogir.vector.validate+0x6d8>
    36e4:      	b	0x37cc <_stogir.vector.validate+0xa54>
    36e8:      	mov	x19, x0
    36ec:      	mov	x25, #0x18              ; =24
    36f0:      	b	0x3468 <_stogir.vector.validate+0x6f0>
    36f4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		00000000000036f4:  ARM64_RELOC_PAGE21	l_stogir.355
    36f8:      	ldr	x16, [x16]
		00000000000036f8:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    36fc:      	orr	x19, x16, xzr
    3700:      	mov	x27, x25
    3704:      	mov	x25, #0x20              ; =32
    3708:      	add	x16, sp, #0x40
    370c:      	ldr	w0, [x16, #0x4]
    3710:      	lsr	w0, w0, #0
    3714:      	add	x8, sp, #0x170
    3718:      	mov	w1, w0
    371c:      	mov	x0, x21
    3720:      	bl	0x3720 <_stogir.vector.validate+0x9a8>
		0000000000003720:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3724:      	add	x16, sp, #0x170
    3728:      	ldr	w0, [x16]
    372c:      	lsr	x16, x0, #0
    3730:      	cmp	x16, #0x1
    3734:      	b.eq	0x3750 <_stogir.vector.validate+0x9d8>
    3738:      	b.lo	0x3740 <_stogir.vector.validate+0x9c8>
    373c:      	b	0x3754 <_stogir.vector.validate+0x9dc>
    3740:      	cmp	x16, #0x0
    3744:      	b.eq	0x374c <_stogir.vector.validate+0x9d4>
    3748:      	b	0x3754 <_stogir.vector.validate+0x9dc>
    374c:      	b	0x3758 <_stogir.vector.validate+0x9e0>
    3750:      	b	0x377c <_stogir.vector.validate+0xa04>
    3754:      	b	0x37d4 <_stogir.vector.validate+0xa5c>
    3758:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003758:  ARM64_RELOC_PAGE21	l_stogir.356
    375c:      	ldr	x16, [x16]
		000000000000375c:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    3760:      	orr	x19, x16, xzr
    3764:      	mov	x25, #0x19              ; =25
    3768:      	b	0x3420 <_stogir.vector.validate+0x6a8>
    376c:      	movz	x9, #0x0, lsl #48
    3770:      	b	0x3678 <_stogir.vector.validate+0x900>
    3774:      	movz	x9, #0x0, lsl #48
    3778:      	b	0x3670 <_stogir.vector.validate+0x8f8>
    377c:      	add	x16, sp, #0x170
    3780:      	ldr	x0, [x16, #0x8]
    3784:      	add	x16, sp, #0x40
    3788:      	ldr	w1, [x16, #0x4]
    378c:      	sxtw	x1, w1
    3790:      	cmp	x1, #0x0
    3794:      	b.gt	0x37a8 <_stogir.vector.validate+0xa30>
    3798:      	mov	x0, #0x1                ; =1
    379c:      	b	0x3408 <_stogir.vector.validate+0x690>
    37a0:      	movz	x9, #0x0, lsl #48
    37a4:      	b	0x3770 <_stogir.vector.validate+0x9f8>
    37a8:      	uxtb	w0, w0
    37ac:      	cmp	x0, #0x70
    37b0:      	b.eq	0x33cc <_stogir.vector.validate+0x654>
    37b4:      	cmp	x0, #0x71
    37b8:      	b.eq	0x33cc <_stogir.vector.validate+0x654>
    37bc:      	mov	x0, #0x1                ; =1
    37c0:      	b	0x3408 <_stogir.vector.validate+0x690>
    37c4:      	brk	#0
    37c8:      	b	0x37c4 <_stogir.vector.validate+0xa4c>
    37cc:      	brk	#0
    37d0:      	b	0x37cc <_stogir.vector.validate+0xa54>
    37d4:      	brk	#0
    37d8:      	b	0x37d4 <_stogir.vector.validate+0xa5c>
    37dc:      	str	x20, [sp, #0x1a8]
    37e0:      	str	w19, [sp, #0x1a0]
    37e4:      	b	0x2f24 <_stogir.vector.validate+0x1ac>
    37e8:      	str	x20, [sp, #0x1a8]
    37ec:      	str	w19, [sp, #0x1a0]
    37f0:      	mov	w19, w0
    37f4:      	mov	w20, w1
    37f8:      	str	w2, [sp, #0x1b0]
    37fc:      	str	w3, [sp, #0x1b8]
    3800:      	b	0x2fe0 <_stogir.vector.validate+0x268>
    3804:      	mov	x27, x25
    3808:      	b	0x3218 <_stogir.vector.validate+0x4a0>

000000000000380c <_stogir.copy.validate>:
    380c:      	sub	sp, sp, #0x10
    3810:      	sxtw	x1, w1
    3814:      	lsl	x2, x1, #2
    3818:      	cmp	x1, #0x0
    381c:      	cset	w3, gt
    3820:      	movz	x16, #0x0, lsl #48
    3824:      	sub	x4, x16, x1
    3828:      	sub	x5, x4, #0x1
    382c:      	uxtb	w16, w3
    3830:      	cmp	w16, wzr
    3834:      	b.eq	0x3874 <_stogir.copy.validate+0x68>
    3838:      	ldr	x4, [x0, #0x8]
    383c:      	cmp	x1, x4
    3840:      	b.ge	0x38dc <_stogir.copy.validate+0xd0>
    3844:      	add	x4, x0, #0x78
    3848:      	ldr	x4, [x4, #0x8]
    384c:      	cmp	x1, x4
    3850:      	b.ge	0x3a74 <_stogir.copy.validate+0x268>
    3854:      	ldr	x4, [x0, #0x78]
    3858:      	add	x4, x2, x4
    385c:      	ldr	w4, [x4]
    3860:      	sxtw	x4, w4
    3864:      	cmp	x4, #0x0
    3868:      	cset	w4, ge
    386c:      	ubfx	x4, x4, #0, #8
    3870:      	b	0x3a78 <_stogir.copy.validate+0x26c>
    3874:      	cmp	x1, #0x0
    3878:      	b.ge	0x38e4 <_stogir.copy.validate+0xd8>
    387c:      	add	x6, x0, #0x28
    3880:      	add	x7, x0, #0x50
    3884:      	ldr	x6, [x6, #0x8]
    3888:      	ldr	x7, [x7, #0x8]
    388c:      	cmp	x6, x7
    3890:      	b.ne	0x38bc <_stogir.copy.validate+0xb0>
    3894:      	cmp	x4, x6
    3898:      	b.gt	0x3a7c <_stogir.copy.validate+0x270>
    389c:      	ldr	x4, [x0, #0x50]
    38a0:      	add	x4, x4, x5, lsl #2
    38a4:      	ldr	w4, [x4]
    38a8:      	sxtw	x4, w4
    38ac:      	cmp	x4, #0x0
    38b0:      	cset	w4, gt
    38b4:      	ubfx	x4, x4, #0, #8
    38b8:      	b	0x3a80 <_stogir.copy.validate+0x274>
    38bc:      	movz	x4, #0x0, lsl #48
    38c0:      	b	0x38e8 <_stogir.copy.validate+0xdc>
    38c4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		00000000000038c4:  ARM64_RELOC_PAGE21	l_stogir.357
    38c8:      	ldr	x16, [x16]
		00000000000038c8:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    38cc:      	orr	x0, x16, xzr
    38d0:      	mov	x1, #0x1                ; =1
    38d4:      	mov	x2, #0x21               ; =33
    38d8:      	b	0x3978 <_stogir.copy.validate+0x16c>
    38dc:      	movz	x4, #0x0, lsl #48
    38e0:      	b	0x38e8 <_stogir.copy.validate+0xdc>
    38e4:      	movz	x4, #0x0, lsl #48
    38e8:      	cmp	x4, #0x0
    38ec:      	b.eq	0x3928 <_stogir.copy.validate+0x11c>
    38f0:      	uxtb	w16, w3
    38f4:      	cmp	w16, wzr
    38f8:      	b.eq	0x3910 <_stogir.copy.validate+0x104>
    38fc:      	ldr	x3, [x0]
    3900:      	add	x3, x3, x1, lsl #4
    3904:      	ldr	x4, [x3]
    3908:      	ldr	x3, [x3, #0x8]
    390c:      	b	0x3920 <_stogir.copy.validate+0x114>
    3910:      	ldr	x3, [x0, #0x28]
    3914:      	add	x3, x3, x5, lsl #4
    3918:      	ldr	x4, [x3]
    391c:      	ldr	x3, [x3, #0x8]
    3920:      	mov	x5, #0x1                ; =1
    3924:      	b	0x3934 <_stogir.copy.validate+0x128>
    3928:      	movz	x5, #0x0, lsl #48
    392c:      	movz	x4, #0x0, lsl #48
    3930:      	movz	x3, #0x0, lsl #48
    3934:      	lsr	w5, w5, #0
    3938:      	lsr	x16, x5, #0
    393c:      	cmp	x16, #0x1
    3940:      	b.eq	0x395c <_stogir.copy.validate+0x150>
    3944:      	b.lo	0x394c <_stogir.copy.validate+0x140>
    3948:      	b	0x3960 <_stogir.copy.validate+0x154>
    394c:      	cmp	x16, #0x0
    3950:      	b.eq	0x3958 <_stogir.copy.validate+0x14c>
    3954:      	b	0x3960 <_stogir.copy.validate+0x154>
    3958:      	b	0x3964 <_stogir.copy.validate+0x158>
    395c:      	b	0x398c <_stogir.copy.validate+0x180>
    3960:      	b	0x3a84 <_stogir.copy.validate+0x278>
    3964:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003964:  ARM64_RELOC_PAGE21	l_stogir.358
    3968:      	ldr	x16, [x16]
		0000000000003968:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    396c:      	orr	x0, x16, xzr
    3970:      	mov	x1, #0x1                ; =1
    3974:      	mov	x2, #0x18               ; =24
    3978:      	str	x1, [x8]
    397c:      	str	x0, [x8, #0x8]
    3980:      	str	x2, [x8, #0x10]
    3984:      	add	sp, sp, #0x10
    3988:      	ret
    398c:      	mov	x16, sp
    3990:      	str	x4, [x16]
    3994:      	mov	x16, sp
    3998:      	str	x3, [x16, #0x8]
    399c:      	cmp	x1, #0x0
    39a0:      	b.le	0x38c4 <_stogir.copy.validate+0xb8>
    39a4:      	uxtb	w1, w4
    39a8:      	cmp	x1, #0x44
    39ac:      	b.ne	0x38c4 <_stogir.copy.validate+0xb8>
    39b0:      	ldr	x1, [x0, #0x78]
    39b4:      	add	x1, x2, x1
    39b8:      	ldr	w1, [x1]
    39bc:      	sxtw	x1, w1
    39c0:      	cmp	x1, #0x2
    39c4:      	b.ne	0x38c4 <_stogir.copy.validate+0xb8>
    39c8:      	lsr	w4, w4, #0
    39cc:      	ubfx	x1, x4, #8, #8
    39d0:      	cmp	x1, #0x0
    39d4:      	b.eq	0x38c4 <_stogir.copy.validate+0xb8>
    39d8:      	cmp	x1, #0xd
    39dc:      	b.le	0x3a0c <_stogir.copy.validate+0x200>
    39e0:      	cmp	x1, #0xf
    39e4:      	b.le	0x38c4 <_stogir.copy.validate+0xb8>
    39e8:      	cmp	x1, #0x80
    39ec:      	b.ge	0x38c4 <_stogir.copy.validate+0xb8>
    39f0:      	and	x2, x1, #0xf
    39f4:      	lsr	w2, w2, #0
    39f8:      	sxtw	x2, w2
    39fc:      	cmp	x2, #0x1
    3a00:      	b.lt	0x38c4 <_stogir.copy.validate+0xb8>
    3a04:      	cmp	x2, #0xd
    3a08:      	b.gt	0x38c4 <_stogir.copy.validate+0xb8>
    3a0c:      	mov	x16, sp
    3a10:      	ldr	w2, [x16, #0x4]
    3a14:      	sxtw	x2, w2
    3a18:      	cmp	x2, #0x0
    3a1c:      	cset	w3, gt
    3a20:      	movz	x16, #0x0, lsl #48
    3a24:      	sub	x4, x16, x2
    3a28:      	sub	x5, x4, #0x1
    3a2c:      	uxtb	w16, w3
    3a30:      	cmp	w16, wzr
    3a34:      	b.eq	0x3aa4 <_stogir.copy.validate+0x298>
    3a38:      	ldr	x4, [x0, #0x8]
    3a3c:      	cmp	x2, x4
    3a40:      	b.ge	0x3aec <_stogir.copy.validate+0x2e0>
    3a44:      	add	x4, x0, #0x78
    3a48:      	ldr	x4, [x4, #0x8]
    3a4c:      	cmp	x2, x4
    3a50:      	b.ge	0x3bb4 <_stogir.copy.validate+0x3a8>
    3a54:      	ldr	x4, [x0, #0x78]
    3a58:      	add	x4, x4, x2, lsl #2
    3a5c:      	ldr	w4, [x4]
    3a60:      	sxtw	x4, w4
    3a64:      	cmp	x4, #0x0
    3a68:      	cset	w4, ge
    3a6c:      	ubfx	x4, x4, #0, #8
    3a70:      	b	0x3bb8 <_stogir.copy.validate+0x3ac>
    3a74:      	movz	x4, #0x0, lsl #48
    3a78:      	b	0x38e0 <_stogir.copy.validate+0xd4>
    3a7c:      	movz	x4, #0x0, lsl #48
    3a80:      	b	0x38c0 <_stogir.copy.validate+0xb4>
    3a84:      	brk	#0
    3a88:      	b	0x3a84 <_stogir.copy.validate+0x278>
    3a8c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003a8c:  ARM64_RELOC_PAGE21	l_stogir.359
    3a90:      	ldr	x16, [x16]
		0000000000003a90:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    3a94:      	orr	x0, x16, xzr
    3a98:      	mov	x1, #0x1                ; =1
    3a9c:      	mov	x2, #0x20               ; =32
    3aa0:      	b	0x38d8 <_stogir.copy.validate+0xcc>
    3aa4:      	cmp	x2, #0x0
    3aa8:      	b.ge	0x3af4 <_stogir.copy.validate+0x2e8>
    3aac:      	add	x6, x0, #0x28
    3ab0:      	add	x7, x0, #0x50
    3ab4:      	ldr	x6, [x6, #0x8]
    3ab8:      	ldr	x7, [x7, #0x8]
    3abc:      	cmp	x6, x7
    3ac0:      	b.ne	0x3bac <_stogir.copy.validate+0x3a0>
    3ac4:      	cmp	x4, x6
    3ac8:      	b.gt	0x3bbc <_stogir.copy.validate+0x3b0>
    3acc:      	ldr	x4, [x0, #0x50]
    3ad0:      	add	x4, x4, x5, lsl #2
    3ad4:      	ldr	w4, [x4]
    3ad8:      	sxtw	x4, w4
    3adc:      	cmp	x4, #0x0
    3ae0:      	cset	w4, gt
    3ae4:      	ubfx	x4, x4, #0, #8
    3ae8:      	b	0x3bc0 <_stogir.copy.validate+0x3b4>
    3aec:      	movz	x4, #0x0, lsl #48
    3af0:      	b	0x3af8 <_stogir.copy.validate+0x2ec>
    3af4:      	movz	x4, #0x0, lsl #48
    3af8:      	cmp	x4, #0x0
    3afc:      	b.eq	0x3b30 <_stogir.copy.validate+0x324>
    3b00:      	uxtb	w16, w3
    3b04:      	cmp	w16, wzr
    3b08:      	b.eq	0x3b1c <_stogir.copy.validate+0x310>
    3b0c:      	ldr	x0, [x0]
    3b10:      	add	x0, x0, x2, lsl #4
    3b14:      	ldr	x0, [x0]
    3b18:      	b	0x3b28 <_stogir.copy.validate+0x31c>
    3b1c:      	ldr	x0, [x0, #0x28]
    3b20:      	add	x0, x0, x5, lsl #4
    3b24:      	ldr	x0, [x0]
    3b28:      	mov	x2, #0x1                ; =1
    3b2c:      	b	0x3b38 <_stogir.copy.validate+0x32c>
    3b30:      	movz	x2, #0x0, lsl #48
    3b34:      	movz	x0, #0x0, lsl #48
    3b38:      	lsr	w2, w2, #0
    3b3c:      	lsr	x16, x2, #0
    3b40:      	cmp	x16, #0x1
    3b44:      	b.eq	0x3b60 <_stogir.copy.validate+0x354>
    3b48:      	b.lo	0x3b50 <_stogir.copy.validate+0x344>
    3b4c:      	b	0x3b64 <_stogir.copy.validate+0x358>
    3b50:      	cmp	x16, #0x0
    3b54:      	b.eq	0x3b5c <_stogir.copy.validate+0x350>
    3b58:      	b	0x3b64 <_stogir.copy.validate+0x358>
    3b5c:      	b	0x3b68 <_stogir.copy.validate+0x35c>
    3b60:      	b	0x3b80 <_stogir.copy.validate+0x374>
    3b64:      	b	0x3bc4 <_stogir.copy.validate+0x3b8>
    3b68:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003b68:  ARM64_RELOC_PAGE21	l_stogir.360
    3b6c:      	ldr	x16, [x16]
		0000000000003b6c:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    3b70:      	orr	x0, x16, xzr
    3b74:      	mov	x1, #0x1                ; =1
    3b78:      	mov	x2, #0x13               ; =19
    3b7c:      	b	0x3aa0 <_stogir.copy.validate+0x294>
    3b80:      	lsr	w0, w0, #0
    3b84:      	mov	x16, sp
    3b88:      	ldr	w2, [x16]
    3b8c:      	ubfx	x0, x0, #8, #8
    3b90:      	ubfx	x2, x2, #8, #8
    3b94:      	cmp	x0, x2
    3b98:      	b.ne	0x3a8c <_stogir.copy.validate+0x280>
    3b9c:      	and	x0, x1, #0xffffffff
    3ba0:      	movz	x1, #0x0, lsl #48
    3ba4:      	movz	x2, #0x0, lsl #48
    3ba8:      	b	0x3aa0 <_stogir.copy.validate+0x294>
    3bac:      	movz	x4, #0x0, lsl #48
    3bb0:      	b	0x3af8 <_stogir.copy.validate+0x2ec>
    3bb4:      	movz	x4, #0x0, lsl #48
    3bb8:      	b	0x3af0 <_stogir.copy.validate+0x2e4>
    3bbc:      	movz	x4, #0x0, lsl #48
    3bc0:      	b	0x3bb0 <_stogir.copy.validate+0x3a4>
    3bc4:      	brk	#0
    3bc8:      	b	0x3bc4 <_stogir.copy.validate+0x3b8>

0000000000003bcc <_stogir.graph.lookup>:
    3bcc:      	sxtw	x1, w1
    3bd0:      	cmp	x1, #0x0
    3bd4:      	cset	w2, gt
    3bd8:      	movz	x16, #0x0, lsl #48
    3bdc:      	sub	x3, x16, x1
    3be0:      	sub	x4, x3, #0x1
    3be4:      	uxtb	w16, w2
    3be8:      	cmp	w16, wzr
    3bec:      	b.eq	0x3c2c <_stogir.graph.lookup+0x60>
    3bf0:      	ldr	x3, [x0, #0x8]
    3bf4:      	cmp	x1, x3
    3bf8:      	b.ge	0x3c7c <_stogir.graph.lookup+0xb0>
    3bfc:      	add	x3, x0, #0x78
    3c00:      	ldr	x3, [x3, #0x8]
    3c04:      	cmp	x1, x3
    3c08:      	b.ge	0x3cf4 <_stogir.graph.lookup+0x128>
    3c0c:      	ldr	x3, [x0, #0x78]
    3c10:      	add	x3, x3, x1, lsl #2
    3c14:      	ldr	w3, [x3]
    3c18:      	sxtw	x3, w3
    3c1c:      	cmp	x3, #0x0
    3c20:      	cset	w3, ge
    3c24:      	ubfx	x3, x3, #0, #8
    3c28:      	b	0x3cf8 <_stogir.graph.lookup+0x12c>
    3c2c:      	cmp	x1, #0x0
    3c30:      	b.ge	0x3c84 <_stogir.graph.lookup+0xb8>
    3c34:      	add	x5, x0, #0x28
    3c38:      	add	x6, x0, #0x50
    3c3c:      	ldr	x5, [x5, #0x8]
    3c40:      	ldr	x6, [x6, #0x8]
    3c44:      	cmp	x5, x6
    3c48:      	b.ne	0x3c74 <_stogir.graph.lookup+0xa8>
    3c4c:      	cmp	x3, x5
    3c50:      	b.gt	0x3cfc <_stogir.graph.lookup+0x130>
    3c54:      	ldr	x3, [x0, #0x50]
    3c58:      	add	x3, x3, x4, lsl #2
    3c5c:      	ldr	w3, [x3]
    3c60:      	sxtw	x3, w3
    3c64:      	cmp	x3, #0x0
    3c68:      	cset	w3, gt
    3c6c:      	ubfx	x3, x3, #0, #8
    3c70:      	b	0x3d00 <_stogir.graph.lookup+0x134>
    3c74:      	movz	x3, #0x0, lsl #48
    3c78:      	b	0x3c88 <_stogir.graph.lookup+0xbc>
    3c7c:      	movz	x3, #0x0, lsl #48
    3c80:      	b	0x3c88 <_stogir.graph.lookup+0xbc>
    3c84:      	movz	x3, #0x0, lsl #48
    3c88:      	cmp	x3, #0x0
    3c8c:      	b.eq	0x3cc8 <_stogir.graph.lookup+0xfc>
    3c90:      	uxtb	w16, w2
    3c94:      	cmp	w16, wzr
    3c98:      	b.eq	0x3cb0 <_stogir.graph.lookup+0xe4>
    3c9c:      	ldr	x0, [x0]
    3ca0:      	add	x0, x0, x1, lsl #4
    3ca4:      	ldr	x1, [x0]
    3ca8:      	ldr	x0, [x0, #0x8]
    3cac:      	b	0x3cc0 <_stogir.graph.lookup+0xf4>
    3cb0:      	ldr	x0, [x0, #0x28]
    3cb4:      	add	x0, x0, x4, lsl #4
    3cb8:      	ldr	x1, [x0]
    3cbc:      	ldr	x0, [x0, #0x8]
    3cc0:      	mov	x2, #0x1                ; =1
    3cc4:      	b	0x3cd4 <_stogir.graph.lookup+0x108>
    3cc8:      	movz	x2, #0x0, lsl #48
    3ccc:      	movz	x1, #0x0, lsl #48
    3cd0:      	movz	x0, #0x0, lsl #48
    3cd4:      	str	x2, [x8]
    3cd8:      	str	x1, [x8, #0x8]
    3cdc:      	str	x0, [x8, #0x10]
    3ce0:      	movz	x17, #0x0, lsl #48
    3ce4:      	str	x17, [x8, #0x18]
    3ce8:      	movz	x17, #0x0, lsl #48
    3cec:      	str	x17, [x8, #0x20]
    3cf0:      	ret
    3cf4:      	movz	x3, #0x0, lsl #48
    3cf8:      	b	0x3c80 <_stogir.graph.lookup+0xb4>
    3cfc:      	movz	x3, #0x0, lsl #48
    3d00:      	b	0x3c78 <_stogir.graph.lookup+0xac>

0000000000003d04 <_stogir.opcode.block-start?>:
    3d04:      	sxtw	x0, w0
    3d08:      	cmp	x0, #0x0
    3d0c:      	b.lt	0x3d30 <_stogir.opcode.block-start?+0x2c>
    3d10:      	cmp	x0, #0x83
    3d14:      	b.ge	0x3d30 <_stogir.opcode.block-start?+0x2c>
    3d18:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003d18:  ARM64_RELOC_PAGE21	l_stogir.361
    3d1c:      	ldr	x16, [x16]
		0000000000003d1c:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    3d20:      	orr	x1, x16, xzr
    3d24:      	add	x0, x1, x0
    3d28:      	ldrb	w0, [x0]
    3d2c:      	b	0x3d34 <_stogir.opcode.block-start?+0x30>
    3d30:      	movz	x0, #0x0, lsl #48
    3d34:      	uxtb	w0, w0
    3d38:      	and	x0, x0, #0x2
    3d3c:      	uxtb	w0, w0
    3d40:      	cmp	x0, #0x0
    3d44:      	cset	w0, eq
    3d48:      	uxtb	w16, w0
    3d4c:      	cmp	w16, wzr
    3d50:      	cset	x0, eq
    3d54:      	ret

0000000000003d58 <_stogir.checked.operation?>:
    3d58:      	sxtw	x0, w0
    3d5c:      	cmp	x0, #0x29
    3d60:      	b.lt	0x3d74 <_stogir.checked.operation?+0x1c>
    3d64:      	cmp	x0, #0x2b
    3d68:      	cset	w0, le
    3d6c:      	ubfx	x0, x0, #0, #8
    3d70:      	b	0x3d78 <_stogir.checked.operation?+0x20>
    3d74:      	movz	x0, #0x0, lsl #48
    3d78:      	ret

0000000000003d7c <_stogir.checked.validate-projection>:
    3d7c:      	sub	sp, sp, #0x40
    3d80:      	str	x29, [sp]
    3d84:      	str	x30, [sp, #0x8]
    3d88:      	mov	x29, sp
    3d8c:      	str	x19, [sp, #0x30]
    3d90:      	sxtw	x1, w1
    3d94:      	lsl	x2, x1, #2
    3d98:      	cmp	x1, #0x0
    3d9c:      	cset	w3, gt
    3da0:      	movz	x16, #0x0, lsl #48
    3da4:      	sub	x4, x16, x1
    3da8:      	sub	x5, x4, #0x1
    3dac:      	uxtb	w16, w3
    3db0:      	cmp	w16, wzr
    3db4:      	b.eq	0x3df4 <_stogir.checked.validate-projection+0x78>
    3db8:      	ldr	x4, [x0, #0x8]
    3dbc:      	cmp	x1, x4
    3dc0:      	b.ge	0x3e44 <_stogir.checked.validate-projection+0xc8>
    3dc4:      	add	x4, x0, #0x78
    3dc8:      	ldr	x4, [x4, #0x8]
    3dcc:      	cmp	x1, x4
    3dd0:      	b.ge	0x3f1c <_stogir.checked.validate-projection+0x1a0>
    3dd4:      	ldr	x4, [x0, #0x78]
    3dd8:      	add	x4, x2, x4
    3ddc:      	ldr	w4, [x4]
    3de0:      	sxtw	x4, w4
    3de4:      	cmp	x4, #0x0
    3de8:      	cset	w4, ge
    3dec:      	ubfx	x4, x4, #0, #8
    3df0:      	b	0x3f20 <_stogir.checked.validate-projection+0x1a4>
    3df4:      	cmp	x1, #0x0
    3df8:      	b.ge	0x3e4c <_stogir.checked.validate-projection+0xd0>
    3dfc:      	add	x6, x0, #0x28
    3e00:      	add	x7, x0, #0x50
    3e04:      	ldr	x6, [x6, #0x8]
    3e08:      	ldr	x7, [x7, #0x8]
    3e0c:      	cmp	x6, x7
    3e10:      	b.ne	0x3e3c <_stogir.checked.validate-projection+0xc0>
    3e14:      	cmp	x4, x6
    3e18:      	b.gt	0x3f88 <_stogir.checked.validate-projection+0x20c>
    3e1c:      	ldr	x4, [x0, #0x50]
    3e20:      	add	x4, x4, x5, lsl #2
    3e24:      	ldr	w4, [x4]
    3e28:      	sxtw	x4, w4
    3e2c:      	cmp	x4, #0x0
    3e30:      	cset	w4, gt
    3e34:      	ubfx	x4, x4, #0, #8
    3e38:      	b	0x3f8c <_stogir.checked.validate-projection+0x210>
    3e3c:      	movz	x4, #0x0, lsl #48
    3e40:      	b	0x3e50 <_stogir.checked.validate-projection+0xd4>
    3e44:      	movz	x4, #0x0, lsl #48
    3e48:      	b	0x3e50 <_stogir.checked.validate-projection+0xd4>
    3e4c:      	movz	x4, #0x0, lsl #48
    3e50:      	cmp	x4, #0x0
    3e54:      	b.eq	0x3e88 <_stogir.checked.validate-projection+0x10c>
    3e58:      	uxtb	w16, w3
    3e5c:      	cmp	w16, wzr
    3e60:      	b.eq	0x3e74 <_stogir.checked.validate-projection+0xf8>
    3e64:      	ldr	x3, [x0]
    3e68:      	add	x3, x3, x1, lsl #4
    3e6c:      	ldr	x3, [x3]
    3e70:      	b	0x3e80 <_stogir.checked.validate-projection+0x104>
    3e74:      	ldr	x3, [x0, #0x28]
    3e78:      	add	x3, x3, x5, lsl #4
    3e7c:      	ldr	x3, [x3]
    3e80:      	mov	x4, #0x1                ; =1
    3e84:      	b	0x3e90 <_stogir.checked.validate-projection+0x114>
    3e88:      	movz	x4, #0x0, lsl #48
    3e8c:      	movz	x3, #0x0, lsl #48
    3e90:      	lsr	w4, w4, #0
    3e94:      	lsr	x16, x4, #0
    3e98:      	cmp	x16, #0x1
    3e9c:      	b.eq	0x3eb8 <_stogir.checked.validate-projection+0x13c>
    3ea0:      	b.lo	0x3ea8 <_stogir.checked.validate-projection+0x12c>
    3ea4:      	b	0x3ebc <_stogir.checked.validate-projection+0x140>
    3ea8:      	cmp	x16, #0x0
    3eac:      	b.eq	0x3eb4 <_stogir.checked.validate-projection+0x138>
    3eb0:      	b	0x3ebc <_stogir.checked.validate-projection+0x140>
    3eb4:      	b	0x3ec0 <_stogir.checked.validate-projection+0x144>
    3eb8:      	b	0x3edc <_stogir.checked.validate-projection+0x160>
    3ebc:      	b	0x3f90 <_stogir.checked.validate-projection+0x214>
    3ec0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003ec0:  ARM64_RELOC_PAGE21	l_stogir.362
    3ec4:      	ldr	x16, [x16]
		0000000000003ec4:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    3ec8:      	orr	x0, x16, xzr
    3ecc:      	mov	x19, x8
    3ed0:      	mov	x1, #0x1                ; =1
    3ed4:      	mov	x2, #0x10               ; =16
    3ed8:      	b	0x3efc <_stogir.checked.validate-projection+0x180>
    3edc:      	cmp	x1, #0x0
    3ee0:      	b.gt	0x3f24 <_stogir.checked.validate-projection+0x1a8>
    3ee4:      	mov	x19, x8
    3ee8:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x288>
		0000000000003ee8:  ARM64_RELOC_PAGE21	l_stogir.363
    3eec:      	ldr	x16, [x16]
		0000000000003eec:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    3ef0:      	orr	x0, x16, xzr
    3ef4:      	mov	x1, #0x1                ; =1
    3ef8:      	mov	x2, #0x1c               ; =28
    3efc:      	str	x1, [x19]
    3f00:      	str	x0, [x19, #0x8]
    3f04:      	str	x2, [x19, #0x10]
    3f08:      	ldr	x19, [sp, #0x30]
    3f0c:      	ldr	x29, [sp]
    3f10:      	ldr	x30, [sp, #0x8]
    3f14:      	add	sp, sp, #0x40
    3f18:      	ret
    3f1c:      	movz	x4, #0x0, lsl #48
    3f20:      	b	0x3e48 <_stogir.checked.validate-projection+0xcc>
    3f24:      	uxtb	w1, w3
    3f28:      	cmp	x1, #0x2c
    3f2c:      	b.ne	0x3f98 <_stogir.checked.validate-projection+0x21c>
    3f30:      	lsr	w1, w3, #0
    3f34:      	ubfx	x1, x1, #8, #8
    3f38:      	cmp	x1, #0x1
    3f3c:      	b.ne	0x3fa0 <_stogir.checked.validate-projection+0x224>
    3f40:      	ldr	x1, [x0, #0x78]
    3f44:      	add	x1, x2, x1
    3f48:      	ldr	w1, [x1]
    3f4c:      	sxtw	x1, w1
    3f50:      	cmp	x1, #0x1
    3f54:      	b.ne	0x3fa8 <_stogir.checked.validate-projection+0x22c>
    3f58:      	lsr	x1, x3, #32
    3f5c:      	lsr	w1, w1, #0
    3f60:      	mov	x19, x8
    3f64:      	add	x8, sp, #0x10
    3f68:      	bl	0x3f68 <_stogir.checked.validate-projection+0x1ec>
		0000000000003f68:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    3f6c:      	add	x16, sp, #0x10
    3f70:      	ldr	x1, [x16]
    3f74:      	add	x16, sp, #0x10
    3f78:      	ldr	x0, [x16, #0x8]
    3f7c:      	add	x16, sp, #0x10
    3f80:      	ldr	x2, [x16, #0x10]
    3f84:      	b	0x3efc <_stogir.checked.validate-projection+0x180>
    3f88:      	movz	x4, #0x0, lsl #48
    3f8c:      	b	0x3e40 <_stogir.checked.validate-projection+0xc4>
    3f90:      	brk	#0
    3f94:      	b	0x3f90 <_stogir.checked.validate-projection+0x214>
    3f98:      	mov	x19, x8
    3f9c:      	b	0x3ee8 <_stogir.checked.validate-projection+0x16c>
    3fa0:      	mov	x19, x8
    3fa4:      	b	0x3ee8 <_stogir.checked.validate-projection+0x16c>
    3fa8:      	mov	x19, x8
    3fac:      	b	0x3ee8 <_stogir.checked.validate-projection+0x16c>

0000000000003fb0 <_stogir.checked.validate>:
    3fb0:      	sub	sp, sp, #0x30
    3fb4:      	str	x29, [sp]
    3fb8:      	str	x30, [sp, #0x8]
    3fbc:      	mov	x29, sp
    3fc0:      	str	x19, [sp, #0x10]
    3fc4:      	str	x20, [sp, #0x18]
    3fc8:      	str	x21, [sp, #0x20]
    3fcc:      	sxtw	x1, w1
    3fd0:      	lsl	x2, x1, #2
    3fd4:      	cmp	x1, #0x0
    3fd8:      	cset	w3, gt
    3fdc:      	movz	x16, #0x0, lsl #48
    3fe0:      	sub	x4, x16, x1
    3fe4:      	sub	x5, x4, #0x1
    3fe8:      	uxtb	w16, w3
    3fec:      	cmp	w16, wzr
    3ff0:      	b.eq	0x4030 <_stogir.checked.validate+0x80>
    3ff4:      	ldr	x4, [x0, #0x8]
    3ff8:      	cmp	x1, x4
    3ffc:      	b.ge	0x4080 <_stogir.checked.validate+0xd0>
    4000:      	add	x4, x0, #0x78
    4004:      	ldr	x4, [x4, #0x8]
    4008:      	cmp	x1, x4
    400c:      	b.ge	0x41e0 <_stogir.checked.validate+0x230>
    4010:      	ldr	x4, [x0, #0x78]
    4014:      	add	x4, x2, x4
    4018:      	ldr	w4, [x4]
    401c:      	sxtw	x4, w4
    4020:      	cmp	x4, #0x0
    4024:      	cset	w4, ge
    4028:      	ubfx	x4, x4, #0, #8
    402c:      	b	0x41e4 <_stogir.checked.validate+0x234>
    4030:      	cmp	x1, #0x0
    4034:      	b.ge	0x4088 <_stogir.checked.validate+0xd8>
    4038:      	add	x6, x0, #0x28
    403c:      	add	x7, x0, #0x50
    4040:      	ldr	x6, [x6, #0x8]
    4044:      	ldr	x7, [x7, #0x8]
    4048:      	cmp	x6, x7
    404c:      	b.ne	0x4078 <_stogir.checked.validate+0xc8>
    4050:      	cmp	x4, x6
    4054:      	b.gt	0x41e8 <_stogir.checked.validate+0x238>
    4058:      	ldr	x4, [x0, #0x50]
    405c:      	add	x4, x4, x5, lsl #2
    4060:      	ldr	w4, [x4]
    4064:      	sxtw	x4, w4
    4068:      	cmp	x4, #0x0
    406c:      	cset	w4, gt
    4070:      	ubfx	x4, x4, #0, #8
    4074:      	b	0x41ec <_stogir.checked.validate+0x23c>
    4078:      	movz	x4, #0x0, lsl #48
    407c:      	b	0x408c <_stogir.checked.validate+0xdc>
    4080:      	movz	x4, #0x0, lsl #48
    4084:      	b	0x408c <_stogir.checked.validate+0xdc>
    4088:      	movz	x4, #0x0, lsl #48
    408c:      	cmp	x4, #0x0
    4090:      	b.eq	0x40cc <_stogir.checked.validate+0x11c>
    4094:      	uxtb	w16, w3
    4098:      	cmp	w16, wzr
    409c:      	b.eq	0x40b4 <_stogir.checked.validate+0x104>
    40a0:      	ldr	x3, [x0]
    40a4:      	add	x3, x3, x1, lsl #4
    40a8:      	ldr	x4, [x3]
    40ac:      	ldr	x3, [x3, #0x8]
    40b0:      	b	0x40c4 <_stogir.checked.validate+0x114>
    40b4:      	ldr	x3, [x0, #0x28]
    40b8:      	add	x3, x3, x5, lsl #4
    40bc:      	ldr	x4, [x3]
    40c0:      	ldr	x3, [x3, #0x8]
    40c4:      	mov	x5, #0x1                ; =1
    40c8:      	b	0x40d8 <_stogir.checked.validate+0x128>
    40cc:      	movz	x5, #0x0, lsl #48
    40d0:      	movz	x4, #0x0, lsl #48
    40d4:      	movz	x3, #0x0, lsl #48
    40d8:      	lsr	w5, w5, #0
    40dc:      	lsr	x16, x5, #0
    40e0:      	cmp	x16, #0x1
    40e4:      	b.eq	0x4100 <_stogir.checked.validate+0x150>
    40e8:      	b.lo	0x40f0 <_stogir.checked.validate+0x140>
    40ec:      	b	0x4104 <_stogir.checked.validate+0x154>
    40f0:      	cmp	x16, #0x0
    40f4:      	b.eq	0x40fc <_stogir.checked.validate+0x14c>
    40f8:      	b	0x4104 <_stogir.checked.validate+0x154>
    40fc:      	b	0x4108 <_stogir.checked.validate+0x158>
    4100:      	b	0x4160 <_stogir.checked.validate+0x1b0>
    4104:      	b	0x4424 <_stogir.checked.validate+0x474>
    4108:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004108:  ARM64_RELOC_PAGE21	l_stogir.364
    410c:      	ldr	x16, [x16]
		000000000000410c:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    4110:      	orr	x1, x16, xzr
    4114:      	mov	x0, #0x1                ; =1
    4118:      	mov	x9, #0x1a               ; =26
    411c:      	b	0x4134 <_stogir.checked.validate+0x184>
    4120:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004120:  ARM64_RELOC_PAGE21	l_stogir.365
    4124:      	ldr	x16, [x16]
		0000000000004124:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    4128:      	orr	x1, x16, xzr
    412c:      	mov	x0, #0x1                ; =1
    4130:      	mov	x9, #0x26               ; =38
    4134:      	str	x0, [x8]
    4138:      	str	x1, [x8, #0x8]
    413c:      	str	x9, [x8, #0x10]
    4140:      	sub	sp, x29, #0x0
    4144:      	ldr	x19, [sp, #0x10]
    4148:      	ldr	x20, [sp, #0x18]
    414c:      	ldr	x21, [sp, #0x20]
    4150:      	ldr	x29, [sp]
    4154:      	ldr	x30, [sp, #0x8]
    4158:      	add	sp, sp, #0x30
    415c:      	ret
    4160:      	cmp	x1, #0x0
    4164:      	b.le	0x4120 <_stogir.checked.validate+0x170>
    4168:      	uxtb	w1, w4
    416c:      	cmp	x1, #0x29
    4170:      	b.lt	0x4120 <_stogir.checked.validate+0x170>
    4174:      	cmp	x1, #0x2b
    4178:      	b.gt	0x4120 <_stogir.checked.validate+0x170>
    417c:      	ldr	x1, [x0, #0x78]
    4180:      	add	x1, x2, x1
    4184:      	ldr	w1, [x1]
    4188:      	sxtw	x1, w1
    418c:      	cmp	x1, #0x2
    4190:      	b.ne	0x4120 <_stogir.checked.validate+0x170>
    4194:      	lsr	w1, w4, #0
    4198:      	mov	x2, sp
    419c:      	sub	sp, sp, #0x10
    41a0:      	mov	x5, sp
    41a4:      	sub	sp, sp, #0x10
    41a8:      	mov	x6, sp
    41ac:      	ubfx	x1, x1, #8, #8
    41b0:      	orr	x7, x1, xzr
    41b4:      	cmp	x7, #0x1
    41b8:      	b.lt	0x43b4 <_stogir.checked.validate+0x404>
    41bc:      	cmp	x7, #0xb
    41c0:      	b.gt	0x43b4 <_stogir.checked.validate+0x404>
    41c4:      	cmp	x7, #0x1
    41c8:      	b.eq	0x43b4 <_stogir.checked.validate+0x404>
    41cc:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		00000000000041cc:  ARM64_RELOC_PAGE21	l_stogir.366
    41d0:      	ldr	x16, [x16]
		00000000000041d0:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    41d4:      	orr	x1, x16, xzr
    41d8:      	movz	x9, #0x0, lsl #48
    41dc:      	b	0x43c4 <_stogir.checked.validate+0x414>
    41e0:      	movz	x4, #0x0, lsl #48
    41e4:      	b	0x4084 <_stogir.checked.validate+0xd4>
    41e8:      	movz	x4, #0x0, lsl #48
    41ec:      	b	0x407c <_stogir.checked.validate+0xcc>
    41f0:      	mov	x0, #0x1                ; =1
    41f4:      	mov	sp, x2
    41f8:      	b	0x4134 <_stogir.checked.validate+0x184>
    41fc:      	movz	x5, #0x0, lsl #48
    4200:      	movz	x4, #0x0, lsl #48
    4204:      	lsr	w5, w5, #0
    4208:      	lsr	x16, x5, #0
    420c:      	cmp	x16, #0x1
    4210:      	b.eq	0x422c <_stogir.checked.validate+0x27c>
    4214:      	b.lo	0x421c <_stogir.checked.validate+0x26c>
    4218:      	b	0x4230 <_stogir.checked.validate+0x280>
    421c:      	cmp	x16, #0x0
    4220:      	b.eq	0x4228 <_stogir.checked.validate+0x278>
    4224:      	b	0x4230 <_stogir.checked.validate+0x280>
    4228:      	b	0x4234 <_stogir.checked.validate+0x284>
    422c:      	b	0x4398 <_stogir.checked.validate+0x3e8>
    4230:      	b	0x443c <_stogir.checked.validate+0x48c>
    4234:      	mov	x1, x11
    4238:      	mov	x9, #0x22               ; =34
    423c:      	cmp	x3, #0x2
    4240:      	b.ge	0x4264 <_stogir.checked.validate+0x2b4>
    4244:      	add	x4, x3, #0x1
    4248:      	add	x3, x10, x3, lsl #2
    424c:      	ldr	w3, [x3]
    4250:      	sxtw	x3, w3
    4254:      	and	x5, x3, #0xffffffff
    4258:      	mov	x3, x4
    425c:      	mov	x4, #0x1                ; =1
    4260:      	b	0x426c <_stogir.checked.validate+0x2bc>
    4264:      	movz	x4, #0x0, lsl #48
    4268:      	movz	x5, #0x0, lsl #48
    426c:      	lsr	w4, w4, #0
    4270:      	lsr	x16, x4, #0
    4274:      	cmp	x16, #0x1
    4278:      	b.eq	0x4294 <_stogir.checked.validate+0x2e4>
    427c:      	b.lo	0x4284 <_stogir.checked.validate+0x2d4>
    4280:      	b	0x4298 <_stogir.checked.validate+0x2e8>
    4284:      	cmp	x16, #0x0
    4288:      	b.eq	0x4290 <_stogir.checked.validate+0x2e0>
    428c:      	b	0x4298 <_stogir.checked.validate+0x2e8>
    4290:      	b	0x42fc <_stogir.checked.validate+0x34c>
    4294:      	b	0x429c <_stogir.checked.validate+0x2ec>
    4298:      	b	0x4434 <_stogir.checked.validate+0x484>
    429c:      	lsr	w5, w5, #0
    42a0:      	sxtw	x5, w5
    42a4:      	cmp	x5, #0x0
    42a8:      	cset	w4, gt
    42ac:      	movz	x16, #0x0, lsl #48
    42b0:      	sub	x6, x16, x5
    42b4:      	sub	x19, x6, #0x1
    42b8:      	uxtb	w16, w4
    42bc:      	cmp	w16, wzr
    42c0:      	b.eq	0x4358 <_stogir.checked.validate+0x3a8>
    42c4:      	ldr	x6, [x0, #0x8]
    42c8:      	cmp	x5, x6
    42cc:      	b.ge	0x4350 <_stogir.checked.validate+0x3a0>
    42d0:      	ldr	x6, [x13, #0x8]
    42d4:      	cmp	x5, x6
    42d8:      	b.ge	0x441c <_stogir.checked.validate+0x46c>
    42dc:      	ldr	x6, [x0, #0x78]
    42e0:      	add	x6, x6, x5, lsl #2
    42e4:      	ldr	w6, [x6]
    42e8:      	sxtw	x6, w6
    42ec:      	cmp	x6, #0x0
    42f0:      	cset	w6, ge
    42f4:      	ubfx	x6, x6, #0, #8
    42f8:      	b	0x4420 <_stogir.checked.validate+0x470>
    42fc:      	cmp	x9, #0x0
    4300:      	b.ne	0x41f0 <_stogir.checked.validate+0x240>
    4304:      	and	x1, x7, #0xffffffff
    4308:      	movz	x0, #0x0, lsl #48
    430c:      	movz	x9, #0x0, lsl #48
    4310:      	b	0x41f4 <_stogir.checked.validate+0x244>
    4314:      	ldr	x4, [x0, #0x28]
    4318:      	add	x4, x4, x19, lsl #4
    431c:      	ldr	x4, [x4]
    4320:      	mov	x5, #0x1                ; =1
    4324:      	b	0x4204 <_stogir.checked.validate+0x254>
    4328:      	movz	x6, #0x0, lsl #48
    432c:      	cmp	x6, #0x0
    4330:      	b.eq	0x41fc <_stogir.checked.validate+0x24c>
    4334:      	uxtb	w16, w4
    4338:      	cmp	w16, wzr
    433c:      	b.eq	0x4314 <_stogir.checked.validate+0x364>
    4340:      	ldr	x4, [x0]
    4344:      	add	x4, x4, x5, lsl #4
    4348:      	ldr	x4, [x4]
    434c:      	b	0x4320 <_stogir.checked.validate+0x370>
    4350:      	movz	x6, #0x0, lsl #48
    4354:      	b	0x432c <_stogir.checked.validate+0x37c>
    4358:      	cmp	x5, #0x0
    435c:      	b.ge	0x4328 <_stogir.checked.validate+0x378>
    4360:      	ldr	x20, [x14, #0x8]
    4364:      	ldr	x21, [x15, #0x8]
    4368:      	cmp	x20, x21
    436c:      	b.ne	0x4414 <_stogir.checked.validate+0x464>
    4370:      	cmp	x6, x20
    4374:      	b.gt	0x442c <_stogir.checked.validate+0x47c>
    4378:      	ldr	x6, [x0, #0x50]
    437c:      	add	x6, x6, x19, lsl #2
    4380:      	ldr	w6, [x6]
    4384:      	sxtw	x6, w6
    4388:      	cmp	x6, #0x0
    438c:      	cset	w6, gt
    4390:      	ubfx	x6, x6, #0, #8
    4394:      	b	0x4430 <_stogir.checked.validate+0x480>
    4398:      	lsr	w4, w4, #0
    439c:      	ubfx	x4, x4, #8, #8
    43a0:      	cmp	x4, x7
    43a4:      	b.eq	0x43b0 <_stogir.checked.validate+0x400>
    43a8:      	mov	x1, x12
    43ac:      	mov	x9, #0x28               ; =40
    43b0:      	b	0x423c <_stogir.checked.validate+0x28c>
    43b4:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		00000000000043b4:  ARM64_RELOC_PAGE21	l_stogir.367
    43b8:      	ldr	x16, [x16]
		00000000000043b8:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    43bc:      	orr	x1, x16, xzr
    43c0:      	mov	x9, #0x36               ; =54
    43c4:      	orr	x10, x6, xzr
    43c8:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		00000000000043c8:  ARM64_RELOC_PAGE21	l_stogir.368
    43cc:      	ldr	x16, [x16]
		00000000000043cc:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    43d0:      	orr	x11, x16, xzr
    43d4:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		00000000000043d4:  ARM64_RELOC_PAGE21	l_stogir.369
    43d8:      	ldr	x16, [x16]
		00000000000043d8:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    43dc:      	orr	x12, x16, xzr
    43e0:      	add	x13, x0, #0x78
    43e4:      	add	x14, x0, #0x28
    43e8:      	add	x15, x0, #0x50
    43ec:      	lsr	w3, w3, #0
    43f0:      	lsr	x4, x4, #32
    43f4:      	lsr	w3, w3, #0
    43f8:      	lsr	w4, w4, #0
    43fc:      	str	w4, [x5]
    4400:      	str	w3, [x5, #0x4]
    4404:      	ldr	x3, [x5]
    4408:      	str	x3, [x6]
    440c:      	movz	x3, #0x0, lsl #48
    4410:      	b	0x423c <_stogir.checked.validate+0x28c>
    4414:      	movz	x6, #0x0, lsl #48
    4418:      	b	0x432c <_stogir.checked.validate+0x37c>
    441c:      	movz	x6, #0x0, lsl #48
    4420:      	b	0x4354 <_stogir.checked.validate+0x3a4>
    4424:      	brk	#0
    4428:      	b	0x4424 <_stogir.checked.validate+0x474>
    442c:      	movz	x6, #0x0, lsl #48
    4430:      	b	0x4418 <_stogir.checked.validate+0x468>
    4434:      	brk	#0
    4438:      	b	0x4434 <_stogir.checked.validate+0x484>
    443c:      	brk	#0
    4440:      	b	0x443c <_stogir.checked.validate+0x48c>

0000000000004444 <_stogir.atomic.operation?>:
    4444:      	sxtw	x0, w0
    4448:      	cmp	x0, #0x7e
    444c:      	b.lt	0x4460 <_stogir.atomic.operation?+0x1c>
    4450:      	cmp	x0, #0x82
    4454:      	cset	w0, le
    4458:      	ubfx	x0, x0, #0, #8
    445c:      	b	0x4464 <_stogir.atomic.operation?+0x20>
    4460:      	movz	x0, #0x0, lsl #48
    4464:      	ret

0000000000004468 <_stogir.atomic.validate>:
    4468:      	sub	sp, sp, #0xf0
    446c:      	str	x29, [sp, #0x10]
    4470:      	str	x30, [sp, #0x18]
    4474:      	add	x29, sp, #0x10
    4478:      	str	x19, [sp, #0xa0]
    447c:      	str	x20, [sp, #0xa8]
    4480:      	str	x21, [sp, #0xb0]
    4484:      	str	x22, [sp, #0xb8]
    4488:      	str	x23, [sp, #0xc0]
    448c:      	str	x24, [sp, #0xc8]
    4490:      	str	x25, [sp, #0xd0]
    4494:      	str	x26, [sp, #0xd8]
    4498:      	str	x27, [sp, #0xe0]
    449c:      	sxtw	x2, w1
    44a0:      	lsl	x3, x2, #2
    44a4:      	cmp	x2, #0x0
    44a8:      	cset	w4, gt
    44ac:      	movz	x16, #0x0, lsl #48
    44b0:      	sub	x5, x16, x2
    44b4:      	sub	x6, x5, #0x1
    44b8:      	uxtb	w16, w4
    44bc:      	cmp	w16, wzr
    44c0:      	b.eq	0x4500 <_stogir.atomic.validate+0x98>
    44c4:      	ldr	x5, [x0, #0x8]
    44c8:      	cmp	x2, x5
    44cc:      	b.ge	0x4550 <_stogir.atomic.validate+0xe8>
    44d0:      	add	x5, x0, #0x78
    44d4:      	ldr	x5, [x5, #0x8]
    44d8:      	cmp	x2, x5
    44dc:      	b.ge	0x4690 <_stogir.atomic.validate+0x228>
    44e0:      	ldr	x5, [x0, #0x78]
    44e4:      	add	x5, x3, x5
    44e8:      	ldr	w5, [x5]
    44ec:      	sxtw	x5, w5
    44f0:      	cmp	x5, #0x0
    44f4:      	cset	w5, ge
    44f8:      	ubfx	x5, x5, #0, #8
    44fc:      	b	0x4694 <_stogir.atomic.validate+0x22c>
    4500:      	cmp	x2, #0x0
    4504:      	b.ge	0x4558 <_stogir.atomic.validate+0xf0>
    4508:      	add	x7, x0, #0x28
    450c:      	add	x9, x0, #0x50
    4510:      	ldr	x7, [x7, #0x8]
    4514:      	ldr	x9, [x9, #0x8]
    4518:      	cmp	x7, x9
    451c:      	b.ne	0x4548 <_stogir.atomic.validate+0xe0>
    4520:      	cmp	x5, x7
    4524:      	b.gt	0x471c <_stogir.atomic.validate+0x2b4>
    4528:      	ldr	x5, [x0, #0x50]
    452c:      	add	x5, x5, x6, lsl #2
    4530:      	ldr	w5, [x5]
    4534:      	sxtw	x5, w5
    4538:      	cmp	x5, #0x0
    453c:      	cset	w5, gt
    4540:      	ubfx	x5, x5, #0, #8
    4544:      	b	0x4720 <_stogir.atomic.validate+0x2b8>
    4548:      	movz	x5, #0x0, lsl #48
    454c:      	b	0x455c <_stogir.atomic.validate+0xf4>
    4550:      	movz	x5, #0x0, lsl #48
    4554:      	b	0x455c <_stogir.atomic.validate+0xf4>
    4558:      	movz	x5, #0x0, lsl #48
    455c:      	cmp	x5, #0x0
    4560:      	b.eq	0x459c <_stogir.atomic.validate+0x134>
    4564:      	uxtb	w16, w4
    4568:      	cmp	w16, wzr
    456c:      	b.eq	0x4584 <_stogir.atomic.validate+0x11c>
    4570:      	ldr	x4, [x0]
    4574:      	add	x4, x4, x2, lsl #4
    4578:      	ldr	x19, [x4]
    457c:      	ldr	x4, [x4, #0x8]
    4580:      	b	0x4594 <_stogir.atomic.validate+0x12c>
    4584:      	ldr	x4, [x0, #0x28]
    4588:      	add	x4, x4, x6, lsl #4
    458c:      	ldr	x19, [x4]
    4590:      	ldr	x4, [x4, #0x8]
    4594:      	mov	x5, #0x1                ; =1
    4598:      	b	0x45a8 <_stogir.atomic.validate+0x140>
    459c:      	movz	x5, #0x0, lsl #48
    45a0:      	movz	x19, #0x0, lsl #48
    45a4:      	movz	x4, #0x0, lsl #48
    45a8:      	lsr	w5, w5, #0
    45ac:      	lsr	x16, x5, #0
    45b0:      	cmp	x16, #0x1
    45b4:      	b.eq	0x45d0 <_stogir.atomic.validate+0x168>
    45b8:      	b.lo	0x45c0 <_stogir.atomic.validate+0x158>
    45bc:      	b	0x45d4 <_stogir.atomic.validate+0x16c>
    45c0:      	cmp	x16, #0x0
    45c4:      	b.eq	0x45cc <_stogir.atomic.validate+0x164>
    45c8:      	b	0x45d4 <_stogir.atomic.validate+0x16c>
    45cc:      	b	0x45d8 <_stogir.atomic.validate+0x170>
    45d0:      	b	0x4630 <_stogir.atomic.validate+0x1c8>
    45d4:      	b	0x4bfc <_stogir.atomic.validate+0x794>
    45d8:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		00000000000045d8:  ARM64_RELOC_PAGE21	l_stogir.370
    45dc:      	ldr	x16, [x16]
		00000000000045dc:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    45e0:      	orr	x20, x16, xzr
    45e4:      	mov	x23, x8
    45e8:      	mov	x0, #0x1                ; =1
    45ec:      	mov	x22, #0x1a              ; =26
    45f0:      	str	x0, [x23]
    45f4:      	str	x20, [x23, #0x8]
    45f8:      	str	x22, [x23, #0x10]
    45fc:      	ldr	x19, [sp, #0xa0]
    4600:      	ldr	x20, [sp, #0xa8]
    4604:      	ldr	x21, [sp, #0xb0]
    4608:      	ldr	x22, [sp, #0xb8]
    460c:      	ldr	x23, [sp, #0xc0]
    4610:      	ldr	x24, [sp, #0xc8]
    4614:      	ldr	x25, [sp, #0xd0]
    4618:      	ldr	x26, [sp, #0xd8]
    461c:      	ldr	x27, [sp, #0xe0]
    4620:      	ldr	x29, [sp, #0x10]
    4624:      	ldr	x30, [sp, #0x18]
    4628:      	add	sp, sp, #0xf0
    462c:      	ret
    4630:      	uxtb	w5, w19
    4634:      	add	x16, sp, #0x20
    4638:      	str	x19, [x16]
    463c:      	orr	x21, x5, xzr
    4640:      	add	x16, sp, #0x20
    4644:      	str	x4, [x16, #0x8]
    4648:      	cmp	x2, #0x0
    464c:      	b.le	0x46a0 <_stogir.atomic.validate+0x238>
    4650:      	cmp	x21, #0x7e
    4654:      	b.lt	0x46a0 <_stogir.atomic.validate+0x238>
    4658:      	cmp	x21, #0x82
    465c:      	b.gt	0x46a0 <_stogir.atomic.validate+0x238>
    4660:      	ldr	x2, [x0, #0x78]
    4664:      	add	x2, x3, x2
    4668:      	ldr	w2, [x2]
    466c:      	cmp	x21, #0x83
    4670:      	b.ge	0x4b28 <_stogir.atomic.validate+0x6c0>
    4674:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004674:  ARM64_RELOC_PAGE21	l_stogir.371
    4678:      	ldr	x16, [x16]
		0000000000004678:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    467c:      	orr	x3, x16, xzr
    4680:      	add	x3, x21, x3
    4684:      	ldrsb	w3, [x3]
    4688:      	sxtb	x3, w3
    468c:      	b	0x4b2c <_stogir.atomic.validate+0x6c4>
    4690:      	movz	x5, #0x0, lsl #48
    4694:      	b	0x4554 <_stogir.atomic.validate+0xec>
    4698:      	mov	x0, #0x1                ; =1
    469c:      	b	0x45f0 <_stogir.atomic.validate+0x188>
    46a0:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		00000000000046a0:  ARM64_RELOC_PAGE21	l_stogir.372
    46a4:      	ldr	x16, [x16]
		00000000000046a4:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    46a8:      	orr	x20, x16, xzr
    46ac:      	mov	x22, #0x20              ; =32
    46b0:      	add	x16, sp, #0x20
    46b4:      	ldr	w2, [x16, #0x4]
    46b8:      	lsr	w2, w2, #0
    46bc:      	mov	x23, x8
    46c0:      	add	x8, sp, #0x30
    46c4:      	mov	x24, x0
    46c8:      	mov	w25, w1
    46cc:      	mov	w1, w2
    46d0:      	bl	0x46d0 <_stogir.atomic.validate+0x268>
		00000000000046d0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    46d4:      	add	x16, sp, #0x30
    46d8:      	ldr	w0, [x16]
    46dc:      	lsr	x16, x0, #0
    46e0:      	cmp	x16, #0x1
    46e4:      	b.eq	0x4700 <_stogir.atomic.validate+0x298>
    46e8:      	b.lo	0x46f0 <_stogir.atomic.validate+0x288>
    46ec:      	b	0x4704 <_stogir.atomic.validate+0x29c>
    46f0:      	cmp	x16, #0x0
    46f4:      	b.eq	0x46fc <_stogir.atomic.validate+0x294>
    46f8:      	b	0x4704 <_stogir.atomic.validate+0x29c>
    46fc:      	b	0x4708 <_stogir.atomic.validate+0x2a0>
    4700:      	b	0x47d0 <_stogir.atomic.validate+0x368>
    4704:      	b	0x4c04 <_stogir.atomic.validate+0x79c>
    4708:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004708:  ARM64_RELOC_PAGE21	l_stogir.373
    470c:      	ldr	x16, [x16]
		000000000000470c:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    4710:      	orr	x20, x16, xzr
    4714:      	mov	x22, #0x16              ; =22
    4718:      	b	0x4740 <_stogir.atomic.validate+0x2d8>
    471c:      	movz	x5, #0x0, lsl #48
    4720:      	b	0x454c <_stogir.atomic.validate+0xe4>
    4724:      	mov	x0, #0x1                ; =1
    4728:      	cmp	x0, #0x0
    472c:      	b.eq	0x4740 <_stogir.atomic.validate+0x2d8>
    4730:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004730:  ARM64_RELOC_PAGE21	l_stogir.374
    4734:      	ldr	x16, [x16]
		0000000000004734:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    4738:      	orr	x20, x16, xzr
    473c:      	mov	x22, #0x16              ; =22
    4740:      	cmp	x21, #0x82
    4744:      	cset	w26, eq
    4748:      	lsr	w19, w19, #0
    474c:      	ubfx	x0, x19, #8, #8
    4750:      	orr	x19, x0, xzr
    4754:      	cmp	x19, #0x0
    4758:      	cset	w27, eq
    475c:      	uxtb	w16, w26
    4760:      	cmp	w16, wzr
    4764:      	b.eq	0x4784 <_stogir.atomic.validate+0x31c>
    4768:      	uxtb	w16, w27
    476c:      	cmp	w16, wzr
    4770:      	b.ne	0x4784 <_stogir.atomic.validate+0x31c>
    4774:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004774:  ARM64_RELOC_PAGE21	l_stogir.375
    4778:      	ldr	x16, [x16]
		0000000000004778:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    477c:      	orr	x20, x16, xzr
    4780:      	mov	x22, #0x19              ; =25
    4784:      	uxtb	w16, w26
    4788:      	cmp	w16, wzr
    478c:      	b.eq	0x4798 <_stogir.atomic.validate+0x330>
    4790:      	movz	x0, #0x0, lsl #48
    4794:      	b	0x479c <_stogir.atomic.validate+0x334>
    4798:      	mov	x0, #0x1                ; =1
    479c:      	cmp	x0, #0x0
    47a0:      	b.eq	0x4810 <_stogir.atomic.validate+0x3a8>
    47a4:      	add	x16, sp, #0x20
    47a8:      	ldr	w0, [x16, #0x8]
    47ac:      	lsr	w0, w0, #0
    47b0:      	mov	w1, w0
    47b4:      	mov	x0, x24
    47b8:      	mov	x2, #0x6                ; =6
    47bc:      	bl	0x47bc <_stogir.atomic.validate+0x354>
		00000000000047bc:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    47c0:      	cmp	x0, #0x0
    47c4:      	b.eq	0x48f4 <_stogir.atomic.validate+0x48c>
    47c8:      	movz	x0, #0x0, lsl #48
    47cc:      	b	0x48f8 <_stogir.atomic.validate+0x490>
    47d0:      	add	x16, sp, #0x30
    47d4:      	ldr	x0, [x16, #0x8]
    47d8:      	add	x16, sp, #0x20
    47dc:      	ldr	w1, [x16, #0x4]
    47e0:      	sxtw	x1, w1
    47e4:      	cmp	x1, #0x0
    47e8:      	b.gt	0x4998 <_stogir.atomic.validate+0x530>
    47ec:      	mov	x0, #0x1                ; =1
    47f0:      	b	0x4728 <_stogir.atomic.validate+0x2c0>
    47f4:      	movz	x0, #0x0, lsl #48
    47f8:      	cmp	x0, #0x0
    47fc:      	b.eq	0x4810 <_stogir.atomic.validate+0x3a8>
    4800:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004800:  ARM64_RELOC_PAGE21	l_stogir.376
    4804:      	ldr	x16, [x16]
		0000000000004804:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    4808:      	orr	x20, x16, xzr
    480c:      	mov	x22, #0x22              ; =34
    4810:      	cmp	x21, #0x80
    4814:      	cset	w27, eq
    4818:      	uxtb	w16, w27
    481c:      	cmp	w16, wzr
    4820:      	b.eq	0x482c <_stogir.atomic.validate+0x3c4>
    4824:      	mov	x0, #0x1                ; =1
    4828:      	b	0x4838 <_stogir.atomic.validate+0x3d0>
    482c:      	cmp	x21, #0x81
    4830:      	cset	w0, eq
    4834:      	ubfx	x0, x0, #0, #8
    4838:      	lsr	w19, w19, #0
    483c:      	cmp	x0, #0x0
    4840:      	b.eq	0x48bc <_stogir.atomic.validate+0x454>
    4844:      	lsr	w25, w25, #0
    4848:      	add	x16, sp, #0x90
    484c:      	str	x16, [sp]
    4850:      	mov	x0, x24
    4854:      	mov	w1, w25
    4858:      	mov	x2, #0x4                ; =4
    485c:      	bl	0x485c <_stogir.atomic.validate+0x3f4>
		000000000000485c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    4860:      	ldr	x16, [sp]
    4864:      	str	x0, [x16]
    4868:      	str	x1, [x16, #0x8]
    486c:      	add	x16, sp, #0x90
    4870:      	ldr	x0, [x16]
    4874:      	add	x16, sp, #0x90
    4878:      	ldr	x1, [x16, #0x8]
    487c:      	lsr	w0, w0, #0
    4880:      	lsr	x16, x0, #0
    4884:      	cmp	x16, #0x1
    4888:      	b.eq	0x48a4 <_stogir.atomic.validate+0x43c>
    488c:      	b.lo	0x4894 <_stogir.atomic.validate+0x42c>
    4890:      	b	0x48a8 <_stogir.atomic.validate+0x440>
    4894:      	cmp	x16, #0x0
    4898:      	b.eq	0x48a0 <_stogir.atomic.validate+0x438>
    489c:      	b	0x48a8 <_stogir.atomic.validate+0x440>
    48a0:      	b	0x48ac <_stogir.atomic.validate+0x444>
    48a4:      	b	0x4a74 <_stogir.atomic.validate+0x60c>
    48a8:      	b	0x4c14 <_stogir.atomic.validate+0x7ac>
    48ac:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		00000000000048ac:  ARM64_RELOC_PAGE21	l_stogir.377
    48b0:      	ldr	x16, [x16]
		00000000000048b0:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    48b4:      	orr	x20, x16, xzr
    48b8:      	mov	x22, #0x1d              ; =29
    48bc:      	cmp	x22, #0x0
    48c0:      	b.ne	0x4698 <_stogir.atomic.validate+0x230>
    48c4:      	uxtb	w16, w26
    48c8:      	cmp	w16, wzr
    48cc:      	b.eq	0x4a60 <_stogir.atomic.validate+0x5f8>
    48d0:      	movz	x0, #0x0, lsl #48
    48d4:      	b	0x48e4 <_stogir.atomic.validate+0x47c>
    48d8:      	mov	x0, #0x1                ; =1
    48dc:      	lsr	w0, w0, #0
    48e0:      	sxtw	x0, w0
    48e4:      	and	x20, x0, #0xffffffff
    48e8:      	movz	x0, #0x0, lsl #48
    48ec:      	movz	x22, #0x0, lsl #48
    48f0:      	b	0x469c <_stogir.atomic.validate+0x234>
    48f4:      	mov	x0, #0x1                ; =1
    48f8:      	cmp	x0, #0x0
    48fc:      	b.eq	0x4910 <_stogir.atomic.validate+0x4a8>
    4900:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004900:  ARM64_RELOC_PAGE21	l_stogir.378
    4904:      	ldr	x16, [x16]
		0000000000004904:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    4908:      	orr	x20, x16, xzr
    490c:      	mov	x22, #0x1b              ; =27
    4910:      	cmp	x21, #0x7f
    4914:      	b.ne	0x49dc <_stogir.atomic.validate+0x574>
    4918:      	uxtb	w16, w27
    491c:      	cmp	w16, wzr
    4920:      	b.ne	0x4934 <_stogir.atomic.validate+0x4cc>
    4924:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004924:  ARM64_RELOC_PAGE21	l_stogir.379
    4928:      	ldr	x16, [x16]
		0000000000004928:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    492c:      	orr	x20, x16, xzr
    4930:      	mov	x22, #0x19              ; =25
    4934:      	add	x16, sp, #0x20
    4938:      	ldr	w0, [x16, #0xc]
    493c:      	lsr	w0, w0, #0
    4940:      	add	x8, sp, #0x60
    4944:      	mov	w1, w0
    4948:      	mov	x0, x24
    494c:      	bl	0x494c <_stogir.atomic.validate+0x4e4>
		000000000000494c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4950:      	add	x16, sp, #0x60
    4954:      	ldr	w0, [x16]
    4958:      	lsr	x16, x0, #0
    495c:      	cmp	x16, #0x1
    4960:      	b.eq	0x497c <_stogir.atomic.validate+0x514>
    4964:      	b.lo	0x496c <_stogir.atomic.validate+0x504>
    4968:      	b	0x4980 <_stogir.atomic.validate+0x518>
    496c:      	cmp	x16, #0x0
    4970:      	b.eq	0x4978 <_stogir.atomic.validate+0x510>
    4974:      	b	0x4980 <_stogir.atomic.validate+0x518>
    4978:      	b	0x4984 <_stogir.atomic.validate+0x51c>
    497c:      	b	0x49c8 <_stogir.atomic.validate+0x560>
    4980:      	b	0x4c1c <_stogir.atomic.validate+0x7b4>
    4984:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004984:  ARM64_RELOC_PAGE21	l_stogir.380
    4988:      	ldr	x16, [x16]
		0000000000004988:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    498c:      	orr	x20, x16, xzr
    4990:      	mov	x22, #0x1a              ; =26
    4994:      	b	0x49dc <_stogir.atomic.validate+0x574>
    4998:      	uxtb	w0, w0
    499c:      	cmp	x0, #0x83
    49a0:      	cset	w1, lt
    49a4:      	uxtb	w16, w1
    49a8:      	cmp	w16, wzr
    49ac:      	b.eq	0x4aec <_stogir.atomic.validate+0x684>
    49b0:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		00000000000049b0:  ARM64_RELOC_PAGE21	l_stogir.381
    49b4:      	ldr	x16, [x16]
		00000000000049b4:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    49b8:      	orr	x2, x16, xzr
    49bc:      	add	x2, x0, x2
    49c0:      	ldrb	w2, [x2]
    49c4:      	b	0x4af0 <_stogir.atomic.validate+0x688>
    49c8:      	add	x16, sp, #0x60
    49cc:      	ldr	x0, [x16, #0x8]
    49d0:      	lsr	w0, w0, #0
    49d4:      	ubfx	x0, x0, #8, #8
    49d8:      	orr	x19, x0, xzr
    49dc:      	cmp	x19, #0x2
    49e0:      	b.ge	0x4a2c <_stogir.atomic.validate+0x5c4>
    49e4:      	mov	x0, #0x1                ; =1
    49e8:      	b	0x4a38 <_stogir.atomic.validate+0x5d0>
    49ec:      	mov	x0, #0x1                ; =1
    49f0:      	b	0x47f8 <_stogir.atomic.validate+0x390>
    49f4:      	mov	x0, #0x1                ; =1
    49f8:      	cmp	x0, #0x0
    49fc:      	b.eq	0x47f4 <_stogir.atomic.validate+0x38c>
    4a00:      	lsr	w0, w19, #0
    4a04:      	add	x16, sp, #0x20
    4a08:      	ldr	w1, [x16, #0xc]
    4a0c:      	lsr	w1, w1, #0
    4a10:      	mov	w2, w0
    4a14:      	mov	x0, x24
    4a18:      	bl	0x4a18 <_stogir.atomic.validate+0x5b0>
		0000000000004a18:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4a1c:      	cmp	x0, #0x0
    4a20:      	b.eq	0x49ec <_stogir.atomic.validate+0x584>
    4a24:      	movz	x0, #0x0, lsl #48
    4a28:      	b	0x49f0 <_stogir.atomic.validate+0x588>
    4a2c:      	cmp	x19, #0x5
    4a30:      	cset	w0, gt
    4a34:      	ubfx	x0, x0, #0, #8
    4a38:      	cmp	x0, #0x0
    4a3c:      	b.eq	0x4a50 <_stogir.atomic.validate+0x5e8>
    4a40:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004a40:  ARM64_RELOC_PAGE21	l_stogir.382
    4a44:      	ldr	x16, [x16]
		0000000000004a44:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    4a48:      	orr	x20, x16, xzr
    4a4c:      	mov	x22, #0x25              ; =37
    4a50:      	cmp	x21, #0x7e
    4a54:      	b.ne	0x49f4 <_stogir.atomic.validate+0x58c>
    4a58:      	movz	x0, #0x0, lsl #48
    4a5c:      	b	0x49f8 <_stogir.atomic.validate+0x590>
    4a60:      	sxtw	x19, w19
    4a64:      	cmp	x19, #0x0
    4a68:      	b.ne	0x4b54 <_stogir.atomic.validate+0x6ec>
    4a6c:      	movz	x0, #0x0, lsl #48
    4a70:      	b	0x48dc <_stogir.atomic.validate+0x474>
    4a74:      	lsr	w1, w1, #0
    4a78:      	uxtb	w16, w27
    4a7c:      	cmp	w16, wzr
    4a80:      	b.eq	0x4a98 <_stogir.atomic.validate+0x630>
    4a84:      	sxtw	x1, w1
    4a88:      	cmp	x1, #0x0
    4a8c:      	b.ge	0x4bd4 <_stogir.atomic.validate+0x76c>
    4a90:      	mov	x0, #0x1                ; =1
    4a94:      	b	0x4be0 <_stogir.atomic.validate+0x778>
    4a98:      	lsr	w1, w1, #0
    4a9c:      	mov	x0, x24
    4aa0:      	mov	w2, w19
    4aa4:      	bl	0x4aa4 <_stogir.atomic.validate+0x63c>
		0000000000004aa4:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4aa8:      	cmp	x0, #0x0
    4aac:      	b.ne	0x4ac0 <_stogir.atomic.validate+0x658>
    4ab0:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004ab0:  ARM64_RELOC_PAGE21	l_stogir.383
    4ab4:      	ldr	x16, [x16]
		0000000000004ab4:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    4ab8:      	orr	x20, x16, xzr
    4abc:      	mov	x22, #0x24              ; =36
    4ac0:      	b	0x48bc <_stogir.atomic.validate+0x454>
    4ac4:      	movz	x0, #0x0, lsl #48
    4ac8:      	uxtb	w0, w0
    4acc:      	and	x0, x0, #0x4
    4ad0:      	uxtb	w0, w0
    4ad4:      	cmp	x0, #0x0
    4ad8:      	cset	w0, eq
    4adc:      	uxtb	w16, w0
    4ae0:      	cmp	w16, wzr
    4ae4:      	cset	x0, eq
    4ae8:      	b	0x4728 <_stogir.atomic.validate+0x2c0>
    4aec:      	movz	x2, #0x0, lsl #48
    4af0:      	uxtb	w2, w2
    4af4:      	and	x2, x2, #0x1
    4af8:      	uxtb	w2, w2
    4afc:      	cmp	x2, #0x0
    4b00:      	b.eq	0x4724 <_stogir.atomic.validate+0x2bc>
    4b04:      	uxtb	w16, w1
    4b08:      	cmp	w16, wzr
    4b0c:      	b.eq	0x4ac4 <_stogir.atomic.validate+0x65c>
    4b10:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004b10:  ARM64_RELOC_PAGE21	l_stogir.381
    4b14:      	ldr	x16, [x16]
		0000000000004b14:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    4b18:      	orr	x1, x16, xzr
    4b1c:      	add	x0, x0, x1
    4b20:      	ldrb	w0, [x0]
    4b24:      	b	0x4ac8 <_stogir.atomic.validate+0x660>
    4b28:      	mov	x3, #-0x2               ; =-2
    4b2c:      	sxtw	x2, w2
    4b30:      	lsr	w3, w3, #0
    4b34:      	sxtw	x3, w3
    4b38:      	cmp	x2, x3
    4b3c:      	b.ne	0x46a0 <_stogir.atomic.validate+0x238>
    4b40:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004b40:  ARM64_RELOC_PAGE21	l_stogir.384
    4b44:      	ldr	x16, [x16]
		0000000000004b44:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    4b48:      	orr	x20, x16, xzr
    4b4c:      	movz	x22, #0x0, lsl #48
    4b50:      	b	0x46b0 <_stogir.atomic.validate+0x248>
    4b54:      	cmp	x19, #0x1
    4b58:      	b.eq	0x48d8 <_stogir.atomic.validate+0x470>
    4b5c:      	cmp	x19, #0x2
    4b60:      	b.eq	0x48d8 <_stogir.atomic.validate+0x470>
    4b64:      	cmp	x19, #0x7
    4b68:      	b.eq	0x48d8 <_stogir.atomic.validate+0x470>
    4b6c:      	cmp	x19, #0x8
    4b70:      	b.eq	0x48d8 <_stogir.atomic.validate+0x470>
    4b74:      	cmp	x19, #0x3
    4b78:      	b.eq	0x4c0c <_stogir.atomic.validate+0x7a4>
    4b7c:      	cmp	x19, #0x9
    4b80:      	b.eq	0x4c0c <_stogir.atomic.validate+0x7a4>
    4b84:      	cmp	x19, #0x4
    4b88:      	b.eq	0x4c24 <_stogir.atomic.validate+0x7bc>
    4b8c:      	cmp	x19, #0xa
    4b90:      	b.eq	0x4c24 <_stogir.atomic.validate+0x7bc>
    4b94:      	cmp	x19, #0xd
    4b98:      	b.eq	0x4c24 <_stogir.atomic.validate+0x7bc>
    4b9c:      	cmp	x19, #0x5
    4ba0:      	b.eq	0x4c2c <_stogir.atomic.validate+0x7c4>
    4ba4:      	cmp	x19, #0xb
    4ba8:      	b.eq	0x4c2c <_stogir.atomic.validate+0x7c4>
    4bac:      	cmp	x19, #0xc
    4bb0:      	b.eq	0x4c2c <_stogir.atomic.validate+0x7c4>
    4bb4:      	cmp	x19, #0x6
    4bb8:      	cset	w0, eq
    4bbc:      	uxtb	w16, w0
    4bc0:      	cmp	w16, wzr
    4bc4:      	mov	x16, #0x8               ; =8
    4bc8:      	movn	x17, #0x0, lsl #48
    4bcc:      	csel	x0, x16, x17, ne
    4bd0:      	b	0x4c30 <_stogir.atomic.validate+0x7c8>
    4bd4:      	cmp	x1, #0x9
    4bd8:      	cset	w0, gt
    4bdc:      	ubfx	x0, x0, #0, #8
    4be0:      	cmp	x0, #0x0
    4be4:      	b.eq	0x4bf8 <_stogir.atomic.validate+0x790>
    4be8:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004be8:  ARM64_RELOC_PAGE21	l_stogir.385
    4bec:      	ldr	x16, [x16]
		0000000000004bec:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    4bf0:      	orr	x20, x16, xzr
    4bf4:      	mov	x22, #0x1c              ; =28
    4bf8:      	b	0x4ac0 <_stogir.atomic.validate+0x658>
    4bfc:      	brk	#0
    4c00:      	b	0x4bfc <_stogir.atomic.validate+0x794>
    4c04:      	brk	#0
    4c08:      	b	0x4c04 <_stogir.atomic.validate+0x79c>
    4c0c:      	mov	x0, #0x2                ; =2
    4c10:      	b	0x48dc <_stogir.atomic.validate+0x474>
    4c14:      	brk	#0
    4c18:      	b	0x4c14 <_stogir.atomic.validate+0x7ac>
    4c1c:      	brk	#0
    4c20:      	b	0x4c1c <_stogir.atomic.validate+0x7b4>
    4c24:      	mov	x0, #0x4                ; =4
    4c28:      	b	0x4c10 <_stogir.atomic.validate+0x7a8>
    4c2c:      	mov	x0, #0x8                ; =8
    4c30:      	b	0x4c28 <_stogir.atomic.validate+0x7c0>

0000000000004c34 <_stogir.terminal.operation?>:
    4c34:      	sxtw	x0, w0
    4c38:      	cmp	x0, #0x60
    4c3c:      	b.ne	0x4c48 <_stogir.terminal.operation?+0x14>
    4c40:      	mov	x0, #0x1                ; =1
    4c44:      	b	0x4c54 <_stogir.terminal.operation?+0x20>
    4c48:      	cmp	x0, #0x79
    4c4c:      	cset	w0, eq
    4c50:      	ubfx	x0, x0, #0, #8
    4c54:      	ret

0000000000004c58 <_stogir.terminal.validate>:
    4c58:      	sub	sp, sp, #0x50
    4c5c:      	str	x29, [sp]
    4c60:      	str	x30, [sp, #0x8]
    4c64:      	mov	x29, sp
    4c68:      	str	x19, [sp, #0x40]
    4c6c:      	sxtw	x1, w1
    4c70:      	lsl	x2, x1, #2
    4c74:      	cmp	x1, #0x0
    4c78:      	cset	w3, gt
    4c7c:      	movz	x16, #0x0, lsl #48
    4c80:      	sub	x4, x16, x1
    4c84:      	sub	x5, x4, #0x1
    4c88:      	uxtb	w16, w3
    4c8c:      	cmp	w16, wzr
    4c90:      	b.eq	0x4cd0 <_stogir.terminal.validate+0x78>
    4c94:      	ldr	x4, [x0, #0x8]
    4c98:      	cmp	x1, x4
    4c9c:      	b.ge	0x4d20 <_stogir.terminal.validate+0xc8>
    4ca0:      	add	x4, x0, #0x78
    4ca4:      	ldr	x4, [x4, #0x8]
    4ca8:      	cmp	x1, x4
    4cac:      	b.ge	0x4e14 <_stogir.terminal.validate+0x1bc>
    4cb0:      	ldr	x4, [x0, #0x78]
    4cb4:      	add	x4, x2, x4
    4cb8:      	ldr	w4, [x4]
    4cbc:      	sxtw	x4, w4
    4cc0:      	cmp	x4, #0x0
    4cc4:      	cset	w4, ge
    4cc8:      	ubfx	x4, x4, #0, #8
    4ccc:      	b	0x4e18 <_stogir.terminal.validate+0x1c0>
    4cd0:      	cmp	x1, #0x0
    4cd4:      	b.ge	0x4d28 <_stogir.terminal.validate+0xd0>
    4cd8:      	add	x6, x0, #0x28
    4cdc:      	add	x7, x0, #0x50
    4ce0:      	ldr	x6, [x6, #0x8]
    4ce4:      	ldr	x7, [x7, #0x8]
    4ce8:      	cmp	x6, x7
    4cec:      	b.ne	0x4d18 <_stogir.terminal.validate+0xc0>
    4cf0:      	cmp	x4, x6
    4cf4:      	b.gt	0x4e54 <_stogir.terminal.validate+0x1fc>
    4cf8:      	ldr	x4, [x0, #0x50]
    4cfc:      	add	x4, x4, x5, lsl #2
    4d00:      	ldr	w4, [x4]
    4d04:      	sxtw	x4, w4
    4d08:      	cmp	x4, #0x0
    4d0c:      	cset	w4, gt
    4d10:      	ubfx	x4, x4, #0, #8
    4d14:      	b	0x4e58 <_stogir.terminal.validate+0x200>
    4d18:      	movz	x4, #0x0, lsl #48
    4d1c:      	b	0x4d2c <_stogir.terminal.validate+0xd4>
    4d20:      	movz	x4, #0x0, lsl #48
    4d24:      	b	0x4d2c <_stogir.terminal.validate+0xd4>
    4d28:      	movz	x4, #0x0, lsl #48
    4d2c:      	cmp	x4, #0x0
    4d30:      	b.eq	0x4d6c <_stogir.terminal.validate+0x114>
    4d34:      	uxtb	w16, w3
    4d38:      	cmp	w16, wzr
    4d3c:      	b.eq	0x4d54 <_stogir.terminal.validate+0xfc>
    4d40:      	ldr	x3, [x0]
    4d44:      	add	x3, x3, x1, lsl #4
    4d48:      	ldr	x4, [x3]
    4d4c:      	ldr	x3, [x3, #0x8]
    4d50:      	b	0x4d64 <_stogir.terminal.validate+0x10c>
    4d54:      	ldr	x3, [x0, #0x28]
    4d58:      	add	x3, x3, x5, lsl #4
    4d5c:      	ldr	x4, [x3]
    4d60:      	ldr	x3, [x3, #0x8]
    4d64:      	mov	x5, #0x1                ; =1
    4d68:      	b	0x4d78 <_stogir.terminal.validate+0x120>
    4d6c:      	movz	x5, #0x0, lsl #48
    4d70:      	movz	x4, #0x0, lsl #48
    4d74:      	movz	x3, #0x0, lsl #48
    4d78:      	lsr	w5, w5, #0
    4d7c:      	lsr	x16, x5, #0
    4d80:      	cmp	x16, #0x1
    4d84:      	b.eq	0x4da0 <_stogir.terminal.validate+0x148>
    4d88:      	b.lo	0x4d90 <_stogir.terminal.validate+0x138>
    4d8c:      	b	0x4da4 <_stogir.terminal.validate+0x14c>
    4d90:      	cmp	x16, #0x0
    4d94:      	b.eq	0x4d9c <_stogir.terminal.validate+0x144>
    4d98:      	b	0x4da4 <_stogir.terminal.validate+0x14c>
    4d9c:      	b	0x4da8 <_stogir.terminal.validate+0x150>
    4da0:      	b	0x4dc4 <_stogir.terminal.validate+0x16c>
    4da4:      	b	0x4f30 <_stogir.terminal.validate+0x2d8>
    4da8:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004da8:  ARM64_RELOC_PAGE21	l_stogir.386
    4dac:      	ldr	x16, [x16]
		0000000000004dac:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    4db0:      	orr	x0, x16, xzr
    4db4:      	mov	x19, x8
    4db8:      	mov	x1, #0x1                ; =1
    4dbc:      	mov	x2, #0x21               ; =33
    4dc0:      	b	0x4df4 <_stogir.terminal.validate+0x19c>
    4dc4:      	add	x16, sp, #0x10
    4dc8:      	str	x4, [x16]
    4dcc:      	add	x16, sp, #0x10
    4dd0:      	str	x3, [x16, #0x8]
    4dd4:      	cmp	x1, #0x0
    4dd8:      	b.gt	0x4e1c <_stogir.terminal.validate+0x1c4>
    4ddc:      	mov	x19, x8
    4de0:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x50>
		0000000000004de0:  ARM64_RELOC_PAGE21	l_stogir.387
    4de4:      	ldr	x16, [x16]
		0000000000004de4:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    4de8:      	orr	x0, x16, xzr
    4dec:      	mov	x1, #0x1                ; =1
    4df0:      	mov	x2, #0x1b               ; =27
    4df4:      	str	x1, [x19]
    4df8:      	str	x0, [x19, #0x8]
    4dfc:      	str	x2, [x19, #0x10]
    4e00:      	ldr	x19, [sp, #0x40]
    4e04:      	ldr	x29, [sp]
    4e08:      	ldr	x30, [sp, #0x8]
    4e0c:      	add	sp, sp, #0x50
    4e10:      	ret
    4e14:      	movz	x4, #0x0, lsl #48
    4e18:      	b	0x4d24 <_stogir.terminal.validate+0xcc>
    4e1c:      	uxtb	w4, w4
    4e20:      	orr	x1, x4, xzr
    4e24:      	cmp	x1, #0x60
    4e28:      	cset	w3, eq
    4e2c:      	cmp	x1, #0x79
    4e30:      	cset	w1, eq
    4e34:      	uxtb	w16, w3
    4e38:      	cmp	w16, wzr
    4e3c:      	b.ne	0x4e5c <_stogir.terminal.validate+0x204>
    4e40:      	uxtb	w16, w1
    4e44:      	cmp	w16, wzr
    4e48:      	b.ne	0x4e5c <_stogir.terminal.validate+0x204>
    4e4c:      	mov	x19, x8
    4e50:      	b	0x4de0 <_stogir.terminal.validate+0x188>
    4e54:      	movz	x4, #0x0, lsl #48
    4e58:      	b	0x4d1c <_stogir.terminal.validate+0xc4>
    4e5c:      	add	x16, sp, #0x10
    4e60:      	ldr	w5, [x16]
    4e64:      	ubfx	x5, x5, #8, #8
    4e68:      	cmp	x5, #0x0
    4e6c:      	b.ne	0x4f38 <_stogir.terminal.validate+0x2e0>
    4e70:      	uxtb	w16, w3
    4e74:      	cmp	w16, wzr
    4e78:      	mov	x16, #0x1               ; =1
    4e7c:      	mov	x17, #0x3               ; =3
    4e80:      	csel	x3, x16, x17, ne
    4e84:      	lsr	w3, w3, #0
    4e88:      	sxtw	x3, w3
    4e8c:      	ldr	x5, [x0, #0x78]
    4e90:      	add	x2, x2, x5
    4e94:      	ldr	w2, [x2]
    4e98:      	sxtw	x2, w2
    4e9c:      	cmp	x2, x3
    4ea0:      	b.ne	0x4f40 <_stogir.terminal.validate+0x2e8>
    4ea4:      	uxtb	w16, w1
    4ea8:      	cmp	w16, wzr
    4eac:      	b.eq	0x4f0c <_stogir.terminal.validate+0x2b4>
    4eb0:      	add	x16, sp, #0x10
    4eb4:      	ldr	w2, [x16, #0x8]
    4eb8:      	sxtw	x2, w2
    4ebc:      	cmp	x2, #0x0
    4ec0:      	b.eq	0x4f0c <_stogir.terminal.validate+0x2b4>
    4ec4:      	mov	x19, x8
    4ec8:      	b	0x4de0 <_stogir.terminal.validate+0x188>
    4ecc:      	movz	x1, #0x0, lsl #48
    4ed0:      	lsr	w2, w2, #0
    4ed4:      	lsr	w4, w4, #0
    4ed8:      	lsr	w1, w1, #0
    4edc:      	mov	w3, w1
    4ee0:      	mov	w1, w4
    4ee4:      	mov	x19, x8
    4ee8:      	add	x8, sp, #0x20
    4eec:      	bl	0x4eec <_stogir.terminal.validate+0x294>
		0000000000004eec:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    4ef0:      	add	x16, sp, #0x20
    4ef4:      	ldr	x1, [x16]
    4ef8:      	add	x16, sp, #0x20
    4efc:      	ldr	x0, [x16, #0x8]
    4f00:      	add	x16, sp, #0x20
    4f04:      	ldr	x2, [x16, #0x10]
    4f08:      	b	0x4df4 <_stogir.terminal.validate+0x19c>
    4f0c:      	add	x16, sp, #0x10
    4f10:      	ldr	w2, [x16, #0x4]
    4f14:      	uxtb	w16, w1
    4f18:      	cmp	w16, wzr
    4f1c:      	b.eq	0x4ecc <_stogir.terminal.validate+0x274>
    4f20:      	add	x16, sp, #0x10
    4f24:      	ldr	w1, [x16, #0xc]
    4f28:      	sxtw	x1, w1
    4f2c:      	b	0x4ed0 <_stogir.terminal.validate+0x278>
    4f30:      	brk	#0
    4f34:      	b	0x4f30 <_stogir.terminal.validate+0x2d8>
    4f38:      	mov	x19, x8
    4f3c:      	b	0x4de0 <_stogir.terminal.validate+0x188>
    4f40:      	mov	x19, x8
    4f44:      	b	0x4de0 <_stogir.terminal.validate+0x188>

0000000000004f48 <_stogir.switch.operation?>:
    4f48:      	sxtw	x0, w0
    4f4c:      	cmp	x0, #0x75
    4f50:      	b.ne	0x4f64 <_stogir.switch.operation?+0x1c>
    4f54:      	mov	x0, #0x1                ; =1
    4f58:      	b	0x4f60 <_stogir.switch.operation?+0x18>
    4f5c:      	movz	x0, #0x0, lsl #48
    4f60:      	ret
    4f64:      	cmp	x0, #0x6d
    4f68:      	b.lt	0x4f5c <_stogir.switch.operation?+0x14>
    4f6c:      	cmp	x0, #0x6f
    4f70:      	cset	w0, le
    4f74:      	ubfx	x0, x0, #0, #8
    4f78:      	b	0x4f60 <_stogir.switch.operation?+0x18>

0000000000004f7c <_stogir.switch.validate>:
    4f7c:      	sub	sp, sp, #0x70
    4f80:      	str	x29, [sp]
    4f84:      	str	x30, [sp, #0x8]
    4f88:      	mov	x29, sp
    4f8c:      	str	x19, [sp, #0x60]
    4f90:      	sxtw	x1, w1
    4f94:      	lsl	x2, x1, #2
    4f98:      	cmp	x1, #0x0
    4f9c:      	cset	w3, gt
    4fa0:      	movz	x16, #0x0, lsl #48
    4fa4:      	sub	x4, x16, x1
    4fa8:      	sub	x5, x4, #0x1
    4fac:      	uxtb	w16, w3
    4fb0:      	cmp	w16, wzr
    4fb4:      	b.eq	0x4ff4 <_stogir.switch.validate+0x78>
    4fb8:      	ldr	x4, [x0, #0x8]
    4fbc:      	cmp	x1, x4
    4fc0:      	b.ge	0x5044 <_stogir.switch.validate+0xc8>
    4fc4:      	add	x4, x0, #0x78
    4fc8:      	ldr	x4, [x4, #0x8]
    4fcc:      	cmp	x1, x4
    4fd0:      	b.ge	0x5138 <_stogir.switch.validate+0x1bc>
    4fd4:      	ldr	x4, [x0, #0x78]
    4fd8:      	add	x4, x2, x4
    4fdc:      	ldr	w4, [x4]
    4fe0:      	sxtw	x4, w4
    4fe4:      	cmp	x4, #0x0
    4fe8:      	cset	w4, ge
    4fec:      	ubfx	x4, x4, #0, #8
    4ff0:      	b	0x513c <_stogir.switch.validate+0x1c0>
    4ff4:      	cmp	x1, #0x0
    4ff8:      	b.ge	0x504c <_stogir.switch.validate+0xd0>
    4ffc:      	add	x6, x0, #0x28
    5000:      	add	x7, x0, #0x50
    5004:      	ldr	x6, [x6, #0x8]
    5008:      	ldr	x7, [x7, #0x8]
    500c:      	cmp	x6, x7
    5010:      	b.ne	0x503c <_stogir.switch.validate+0xc0>
    5014:      	cmp	x4, x6
    5018:      	b.gt	0x5174 <_stogir.switch.validate+0x1f8>
    501c:      	ldr	x4, [x0, #0x50]
    5020:      	add	x4, x4, x5, lsl #2
    5024:      	ldr	w4, [x4]
    5028:      	sxtw	x4, w4
    502c:      	cmp	x4, #0x0
    5030:      	cset	w4, gt
    5034:      	ubfx	x4, x4, #0, #8
    5038:      	b	0x5178 <_stogir.switch.validate+0x1fc>
    503c:      	movz	x4, #0x0, lsl #48
    5040:      	b	0x5050 <_stogir.switch.validate+0xd4>
    5044:      	movz	x4, #0x0, lsl #48
    5048:      	b	0x5050 <_stogir.switch.validate+0xd4>
    504c:      	movz	x4, #0x0, lsl #48
    5050:      	cmp	x4, #0x0
    5054:      	b.eq	0x5090 <_stogir.switch.validate+0x114>
    5058:      	uxtb	w16, w3
    505c:      	cmp	w16, wzr
    5060:      	b.eq	0x5078 <_stogir.switch.validate+0xfc>
    5064:      	ldr	x3, [x0]
    5068:      	add	x3, x3, x1, lsl #4
    506c:      	ldr	x4, [x3]
    5070:      	ldr	x3, [x3, #0x8]
    5074:      	b	0x5088 <_stogir.switch.validate+0x10c>
    5078:      	ldr	x3, [x0, #0x28]
    507c:      	add	x3, x3, x5, lsl #4
    5080:      	ldr	x4, [x3]
    5084:      	ldr	x3, [x3, #0x8]
    5088:      	mov	x5, #0x1                ; =1
    508c:      	b	0x509c <_stogir.switch.validate+0x120>
    5090:      	movz	x5, #0x0, lsl #48
    5094:      	movz	x4, #0x0, lsl #48
    5098:      	movz	x3, #0x0, lsl #48
    509c:      	lsr	w5, w5, #0
    50a0:      	lsr	x16, x5, #0
    50a4:      	cmp	x16, #0x1
    50a8:      	b.eq	0x50c4 <_stogir.switch.validate+0x148>
    50ac:      	b.lo	0x50b4 <_stogir.switch.validate+0x138>
    50b0:      	b	0x50c8 <_stogir.switch.validate+0x14c>
    50b4:      	cmp	x16, #0x0
    50b8:      	b.eq	0x50c0 <_stogir.switch.validate+0x144>
    50bc:      	b	0x50c8 <_stogir.switch.validate+0x14c>
    50c0:      	b	0x50cc <_stogir.switch.validate+0x150>
    50c4:      	b	0x50e8 <_stogir.switch.validate+0x16c>
    50c8:      	b	0x5278 <_stogir.switch.validate+0x2fc>
    50cc:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		00000000000050cc:  ARM64_RELOC_PAGE21	l_stogir.388
    50d0:      	ldr	x16, [x16]
		00000000000050d0:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    50d4:      	orr	x0, x16, xzr
    50d8:      	mov	x19, x8
    50dc:      	mov	x1, #0x1                ; =1
    50e0:      	mov	x2, #0x1a               ; =26
    50e4:      	b	0x5118 <_stogir.switch.validate+0x19c>
    50e8:      	add	x16, sp, #0x10
    50ec:      	str	x4, [x16]
    50f0:      	add	x16, sp, #0x10
    50f4:      	str	x3, [x16, #0x8]
    50f8:      	cmp	x1, #0x0
    50fc:      	b.gt	0x5140 <_stogir.switch.validate+0x1c4>
    5100:      	mov	x19, x8
    5104:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005104:  ARM64_RELOC_PAGE21	l_stogir.389
    5108:      	ldr	x16, [x16]
		0000000000005108:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    510c:      	orr	x0, x16, xzr
    5110:      	mov	x1, #0x1                ; =1
    5114:      	mov	x2, #0x20               ; =32
    5118:      	str	x1, [x19]
    511c:      	str	x0, [x19, #0x8]
    5120:      	str	x2, [x19, #0x10]
    5124:      	ldr	x19, [sp, #0x60]
    5128:      	ldr	x29, [sp]
    512c:      	ldr	x30, [sp, #0x8]
    5130:      	add	sp, sp, #0x70
    5134:      	ret
    5138:      	movz	x4, #0x0, lsl #48
    513c:      	b	0x5048 <_stogir.switch.validate+0xcc>
    5140:      	uxtb	w4, w4
    5144:      	orr	x1, x4, xzr
    5148:      	cmp	x1, #0x75
    514c:      	cset	w3, eq
    5150:      	uxtb	w16, w3
    5154:      	cmp	w16, wzr
    5158:      	b.ne	0x517c <_stogir.switch.validate+0x200>
    515c:      	cmp	x1, #0x6d
    5160:      	b.lt	0x5280 <_stogir.switch.validate+0x304>
    5164:      	cmp	x1, #0x6f
    5168:      	b.le	0x517c <_stogir.switch.validate+0x200>
    516c:      	mov	x19, x8
    5170:      	b	0x5104 <_stogir.switch.validate+0x188>
    5174:      	movz	x4, #0x0, lsl #48
    5178:      	b	0x5040 <_stogir.switch.validate+0xc4>
    517c:      	add	x16, sp, #0x10
    5180:      	ldr	w5, [x16]
    5184:      	ubfx	x5, x5, #8, #8
    5188:      	cmp	x5, #0x0
    518c:      	b.ne	0x5288 <_stogir.switch.validate+0x30c>
    5190:      	ldr	x5, [x0, #0x78]
    5194:      	add	x2, x2, x5
    5198:      	ldr	w2, [x2]
    519c:      	cmp	x1, #0x6d
    51a0:      	b.eq	0x5214 <_stogir.switch.validate+0x298>
    51a4:      	cmp	x1, #0x6e
    51a8:      	b.eq	0x5214 <_stogir.switch.validate+0x298>
    51ac:      	mov	x1, #0x2                ; =2
    51b0:      	b	0x5218 <_stogir.switch.validate+0x29c>
    51b4:      	lsr	w4, w4, #0
    51b8:      	add	x16, sp, #0x10
    51bc:      	ldr	w1, [x16, #0x4]
    51c0:      	add	x16, sp, #0x10
    51c4:      	ldr	w2, [x16, #0x8]
    51c8:      	lsr	w1, w1, #0
    51cc:      	add	x16, sp, #0x10
    51d0:      	ldr	w3, [x16, #0xc]
    51d4:      	lsr	w2, w2, #0
    51d8:      	lsr	w3, w3, #0
    51dc:      	add	x8, sp, #0x40
    51e0:      	fmov	s31, w1
    51e4:      	mov	w1, w4
    51e8:      	mov	w4, w3
    51ec:      	mov	w3, w2
    51f0:      	fmov	w2, s31
    51f4:      	bl	0x51f4 <_stogir.switch.validate+0x278>
		00000000000051f4:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    51f8:      	add	x16, sp, #0x40
    51fc:      	ldr	x1, [x16]
    5200:      	add	x16, sp, #0x40
    5204:      	ldr	x0, [x16, #0x8]
    5208:      	add	x16, sp, #0x40
    520c:      	ldr	x2, [x16, #0x10]
    5210:      	b	0x5118 <_stogir.switch.validate+0x19c>
    5214:      	mov	x1, #0x3                ; =3
    5218:      	sxtw	x2, w2
    521c:      	lsr	w1, w1, #0
    5220:      	sxtw	x1, w1
    5224:      	cmp	x2, x1
    5228:      	b.ne	0x5290 <_stogir.switch.validate+0x314>
    522c:      	uxtb	w16, w3
    5230:      	cmp	w16, wzr
    5234:      	b.eq	0x5298 <_stogir.switch.validate+0x31c>
    5238:      	add	x16, sp, #0x10
    523c:      	ldr	w1, [x16, #0x4]
    5240:      	add	x16, sp, #0x10
    5244:      	ldr	w2, [x16, #0x8]
    5248:      	lsr	w1, w1, #0
    524c:      	lsr	w2, w2, #0
    5250:      	mov	x19, x8
    5254:      	add	x8, sp, #0x20
    5258:      	bl	0x5258 <_stogir.switch.validate+0x2dc>
		0000000000005258:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    525c:      	add	x16, sp, #0x20
    5260:      	ldr	x1, [x16]
    5264:      	add	x16, sp, #0x20
    5268:      	ldr	x0, [x16, #0x8]
    526c:      	add	x16, sp, #0x20
    5270:      	ldr	x2, [x16, #0x10]
    5274:      	b	0x5210 <_stogir.switch.validate+0x294>
    5278:      	brk	#0
    527c:      	b	0x5278 <_stogir.switch.validate+0x2fc>
    5280:      	mov	x19, x8
    5284:      	b	0x5104 <_stogir.switch.validate+0x188>
    5288:      	mov	x19, x8
    528c:      	b	0x5104 <_stogir.switch.validate+0x188>
    5290:      	mov	x19, x8
    5294:      	b	0x5104 <_stogir.switch.validate+0x188>
    5298:      	mov	x19, x8
    529c:      	b	0x51b4 <_stogir.switch.validate+0x238>

00000000000052a0 <_stogir.stack.operation?>:
    52a0:      	sxtw	x0, w0
    52a4:      	cmp	x0, #0x42
    52a8:      	b.ne	0x52c4 <_stogir.stack.operation?+0x24>
    52ac:      	mov	x0, #0x1                ; =1
    52b0:      	b	0x52c0 <_stogir.stack.operation?+0x20>
    52b4:      	cmp	x0, #0x54
    52b8:      	cset	w0, eq
    52bc:      	ubfx	x0, x0, #0, #8
    52c0:      	ret
    52c4:      	cmp	x0, #0x51
    52c8:      	b.ne	0x52d4 <_stogir.stack.operation?+0x34>
    52cc:      	mov	x0, #0x1                ; =1
    52d0:      	b	0x52c0 <_stogir.stack.operation?+0x20>
    52d4:      	cmp	x0, #0x52
    52d8:      	b.ne	0x52e4 <_stogir.stack.operation?+0x44>
    52dc:      	mov	x0, #0x1                ; =1
    52e0:      	b	0x52c0 <_stogir.stack.operation?+0x20>
    52e4:      	cmp	x0, #0x53
    52e8:      	b.ne	0x52b4 <_stogir.stack.operation?+0x14>
    52ec:      	mov	x0, #0x1                ; =1
    52f0:      	b	0x52c0 <_stogir.stack.operation?+0x20>

00000000000052f4 <_stogir.stack.validate>:
    52f4:      	sub	sp, sp, #0x90
    52f8:      	str	x29, [sp]
    52fc:      	str	x30, [sp, #0x8]
    5300:      	mov	x29, sp
    5304:      	str	x19, [sp, #0x60]
    5308:      	str	x20, [sp, #0x68]
    530c:      	str	x21, [sp, #0x70]
    5310:      	str	x22, [sp, #0x78]
    5314:      	str	x23, [sp, #0x80]
    5318:      	sxtw	x1, w1
    531c:      	lsl	x2, x1, #2
    5320:      	cmp	x1, #0x0
    5324:      	cset	w3, gt
    5328:      	movz	x16, #0x0, lsl #48
    532c:      	sub	x4, x16, x1
    5330:      	cmp	x1, #0x0
    5334:      	cset	w5, lt
    5338:      	sub	x6, x4, #0x1
    533c:      	lsl	x7, x6, #2
    5340:      	uxtb	w16, w3
    5344:      	cmp	w16, wzr
    5348:      	b.eq	0x5388 <_stogir.stack.validate+0x94>
    534c:      	ldr	x9, [x0, #0x8]
    5350:      	cmp	x1, x9
    5354:      	b.ge	0x5404 <_stogir.stack.validate+0x110>
    5358:      	add	x9, x0, #0x78
    535c:      	ldr	x9, [x9, #0x8]
    5360:      	cmp	x1, x9
    5364:      	b.ge	0x554c <_stogir.stack.validate+0x258>
    5368:      	ldr	x9, [x0, #0x78]
    536c:      	add	x9, x2, x9
    5370:      	ldr	w9, [x9]
    5374:      	sxtw	x9, w9
    5378:      	cmp	x9, #0x0
    537c:      	cset	w9, ge
    5380:      	ubfx	x9, x9, #0, #8
    5384:      	b	0x5550 <_stogir.stack.validate+0x25c>
    5388:      	uxtb	w16, w5
    538c:      	cmp	w16, wzr
    5390:      	b.eq	0x540c <_stogir.stack.validate+0x118>
    5394:      	add	x9, x0, #0x28
    5398:      	add	x10, x0, #0x50
    539c:      	ldr	x9, [x9, #0x8]
    53a0:      	ldr	x10, [x10, #0x8]
    53a4:      	cmp	x9, x10
    53a8:      	b.ne	0x53d4 <_stogir.stack.validate+0xe0>
    53ac:      	cmp	x4, x9
    53b0:      	b.gt	0x5554 <_stogir.stack.validate+0x260>
    53b4:      	ldr	x9, [x0, #0x50]
    53b8:      	add	x9, x7, x9
    53bc:      	ldr	w9, [x9]
    53c0:      	sxtw	x9, w9
    53c4:      	cmp	x9, #0x0
    53c8:      	cset	w9, gt
    53cc:      	ubfx	x9, x9, #0, #8
    53d0:      	b	0x5558 <_stogir.stack.validate+0x264>
    53d4:      	movz	x9, #0x0, lsl #48
    53d8:      	b	0x5410 <_stogir.stack.validate+0x11c>
    53dc:      	uxtb	w16, w12
    53e0:      	cmp	w16, wzr
    53e4:      	b.eq	0x5578 <_stogir.stack.validate+0x284>
    53e8:      	mov	x22, x8
    53ec:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		00000000000053ec:  ARM64_RELOC_PAGE21	l_stogir.390
    53f0:      	ldr	x16, [x16]
		00000000000053f0:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    53f4:      	orr	x0, x16, xzr
    53f8:      	mov	x1, #0x1                ; =1
    53fc:      	mov	x2, #0x19               ; =25
    5400:      	b	0x54ac <_stogir.stack.validate+0x1b8>
    5404:      	movz	x9, #0x0, lsl #48
    5408:      	b	0x5410 <_stogir.stack.validate+0x11c>
    540c:      	movz	x9, #0x0, lsl #48
    5410:      	lsl	x10, x1, #4
    5414:      	lsl	x6, x6, #4
    5418:      	cmp	x9, #0x0
    541c:      	b.eq	0x5458 <_stogir.stack.validate+0x164>
    5420:      	uxtb	w16, w3
    5424:      	cmp	w16, wzr
    5428:      	b.eq	0x5440 <_stogir.stack.validate+0x14c>
    542c:      	ldr	x9, [x0]
    5430:      	add	x9, x10, x9
    5434:      	ldr	x11, [x9]
    5438:      	ldr	x9, [x9, #0x8]
    543c:      	b	0x5450 <_stogir.stack.validate+0x15c>
    5440:      	ldr	x9, [x0, #0x28]
    5444:      	add	x9, x6, x9
    5448:      	ldr	x11, [x9]
    544c:      	ldr	x9, [x9, #0x8]
    5450:      	mov	x12, #0x1               ; =1
    5454:      	b	0x5464 <_stogir.stack.validate+0x170>
    5458:      	movz	x12, #0x0, lsl #48
    545c:      	movz	x11, #0x0, lsl #48
    5460:      	movz	x9, #0x0, lsl #48
    5464:      	lsr	w12, w12, #0
    5468:      	lsr	x16, x12, #0
    546c:      	cmp	x16, #0x1
    5470:      	b.eq	0x548c <_stogir.stack.validate+0x198>
    5474:      	b.lo	0x547c <_stogir.stack.validate+0x188>
    5478:      	b	0x5490 <_stogir.stack.validate+0x19c>
    547c:      	cmp	x16, #0x0
    5480:      	b.eq	0x5488 <_stogir.stack.validate+0x194>
    5484:      	b	0x5490 <_stogir.stack.validate+0x19c>
    5488:      	b	0x5494 <_stogir.stack.validate+0x1a0>
    548c:      	b	0x54dc <_stogir.stack.validate+0x1e8>
    5490:      	b	0x58c4 <_stogir.stack.validate+0x5d0>
    5494:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005494:  ARM64_RELOC_PAGE21	l_stogir.391
    5498:      	ldr	x16, [x16]
		0000000000005498:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    549c:      	orr	x0, x16, xzr
    54a0:      	mov	x22, x8
    54a4:      	mov	x1, #0x1                ; =1
    54a8:      	mov	x2, #0x19               ; =25
    54ac:      	str	x1, [x22]
    54b0:      	str	x0, [x22, #0x8]
    54b4:      	str	x2, [x22, #0x10]
    54b8:      	ldr	x19, [sp, #0x60]
    54bc:      	ldr	x20, [sp, #0x68]
    54c0:      	ldr	x21, [sp, #0x70]
    54c4:      	ldr	x22, [sp, #0x78]
    54c8:      	ldr	x23, [sp, #0x80]
    54cc:      	ldr	x29, [sp]
    54d0:      	ldr	x30, [sp, #0x8]
    54d4:      	add	sp, sp, #0x90
    54d8:      	ret
    54dc:      	cmp	x1, #0x0
    54e0:      	cset	w12, le
    54e4:      	uxtb	w19, w11
    54e8:      	add	x16, sp, #0x10
    54ec:      	str	x11, [x16]
    54f0:      	orr	x11, x19, xzr
    54f4:      	add	x16, sp, #0x10
    54f8:      	str	x9, [x16, #0x8]
    54fc:      	cmp	x11, #0x42
    5500:      	b.ne	0x53dc <_stogir.stack.validate+0xe8>
    5504:      	uxtb	w16, w3
    5508:      	cmp	w16, wzr
    550c:      	b.eq	0x55c4 <_stogir.stack.validate+0x2d0>
    5510:      	ldr	x4, [x0, #0x8]
    5514:      	cmp	x1, x4
    5518:      	b.ge	0x5610 <_stogir.stack.validate+0x31c>
    551c:      	add	x4, x0, #0x78
    5520:      	ldr	x4, [x4, #0x8]
    5524:      	cmp	x1, x4
    5528:      	b.ge	0x56fc <_stogir.stack.validate+0x408>
    552c:      	ldr	x1, [x0, #0x78]
    5530:      	add	x1, x2, x1
    5534:      	ldr	w1, [x1]
    5538:      	sxtw	x1, w1
    553c:      	cmp	x1, #0x0
    5540:      	cset	w1, ge
    5544:      	ubfx	x1, x1, #0, #8
    5548:      	b	0x5700 <_stogir.stack.validate+0x40c>
    554c:      	movz	x9, #0x0, lsl #48
    5550:      	b	0x5408 <_stogir.stack.validate+0x114>
    5554:      	movz	x9, #0x0, lsl #48
    5558:      	b	0x53d8 <_stogir.stack.validate+0xe4>
    555c:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		000000000000555c:  ARM64_RELOC_PAGE21	l_stogir.392
    5560:      	ldr	x16, [x16]
		0000000000005560:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    5564:      	orr	x0, x16, xzr
    5568:      	mov	x1, #0x1                ; =1
    556c:      	mov	x2, #0x1e               ; =30
    5570:      	mov	x22, x8
    5574:      	b	0x5400 <_stogir.stack.validate+0x10c>
    5578:      	cmp	x11, #0x51
    557c:      	cset	w1, eq
    5580:      	cmp	x11, #0x53
    5584:      	cset	w20, eq
    5588:      	cmp	x11, #0x54
    558c:      	cset	w21, eq
    5590:      	uxtb	w16, w1
    5594:      	cmp	w16, wzr
    5598:      	b.ne	0x5704 <_stogir.stack.validate+0x410>
    559c:      	cmp	x11, #0x52
    55a0:      	b.eq	0x5704 <_stogir.stack.validate+0x410>
    55a4:      	uxtb	w16, w20
    55a8:      	cmp	w16, wzr
    55ac:      	b.ne	0x5704 <_stogir.stack.validate+0x410>
    55b0:      	uxtb	w16, w21
    55b4:      	cmp	w16, wzr
    55b8:      	b.ne	0x5704 <_stogir.stack.validate+0x410>
    55bc:      	mov	x22, x8
    55c0:      	b	0x53ec <_stogir.stack.validate+0xf8>
    55c4:      	uxtb	w16, w5
    55c8:      	cmp	w16, wzr
    55cc:      	b.eq	0x5618 <_stogir.stack.validate+0x324>
    55d0:      	add	x1, x0, #0x28
    55d4:      	add	x5, x0, #0x50
    55d8:      	ldr	x1, [x1, #0x8]
    55dc:      	ldr	x5, [x5, #0x8]
    55e0:      	cmp	x1, x5
    55e4:      	b.ne	0x56f4 <_stogir.stack.validate+0x400>
    55e8:      	cmp	x4, x1
    55ec:      	b.gt	0x5860 <_stogir.stack.validate+0x56c>
    55f0:      	ldr	x1, [x0, #0x50]
    55f4:      	add	x1, x7, x1
    55f8:      	ldr	w1, [x1]
    55fc:      	sxtw	x1, w1
    5600:      	cmp	x1, #0x0
    5604:      	cset	w1, gt
    5608:      	ubfx	x1, x1, #0, #8
    560c:      	b	0x5864 <_stogir.stack.validate+0x570>
    5610:      	movz	x1, #0x0, lsl #48
    5614:      	b	0x561c <_stogir.stack.validate+0x328>
    5618:      	movz	x1, #0x0, lsl #48
    561c:      	cmp	x1, #0x0
    5620:      	b.eq	0x5654 <_stogir.stack.validate+0x360>
    5624:      	uxtb	w16, w3
    5628:      	cmp	w16, wzr
    562c:      	b.eq	0x5640 <_stogir.stack.validate+0x34c>
    5630:      	ldr	x1, [x0]
    5634:      	add	x1, x10, x1
    5638:      	ldr	x1, [x1]
    563c:      	b	0x564c <_stogir.stack.validate+0x358>
    5640:      	ldr	x1, [x0, #0x28]
    5644:      	add	x1, x6, x1
    5648:      	ldr	x1, [x1]
    564c:      	mov	x3, #0x1                ; =1
    5650:      	b	0x565c <_stogir.stack.validate+0x368>
    5654:      	movz	x3, #0x0, lsl #48
    5658:      	movz	x1, #0x0, lsl #48
    565c:      	lsr	w3, w3, #0
    5660:      	lsr	x16, x3, #0
    5664:      	cmp	x16, #0x1
    5668:      	b.eq	0x5684 <_stogir.stack.validate+0x390>
    566c:      	b.lo	0x5674 <_stogir.stack.validate+0x380>
    5670:      	b	0x5688 <_stogir.stack.validate+0x394>
    5674:      	cmp	x16, #0x0
    5678:      	b.eq	0x5680 <_stogir.stack.validate+0x38c>
    567c:      	b	0x5688 <_stogir.stack.validate+0x394>
    5680:      	b	0x568c <_stogir.stack.validate+0x398>
    5684:      	b	0x56a4 <_stogir.stack.validate+0x3b0>
    5688:      	b	0x58cc <_stogir.stack.validate+0x5d8>
    568c:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		000000000000568c:  ARM64_RELOC_PAGE21	l_stogir.393
    5690:      	ldr	x16, [x16]
		0000000000005690:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    5694:      	orr	x0, x16, xzr
    5698:      	mov	x1, #0x1                ; =1
    569c:      	mov	x2, #0x21               ; =33
    56a0:      	b	0x5570 <_stogir.stack.validate+0x27c>
    56a4:      	uxtb	w16, w12
    56a8:      	cmp	w16, wzr
    56ac:      	b.ne	0x555c <_stogir.stack.validate+0x268>
    56b0:      	uxtb	w3, w1
    56b4:      	cmp	x3, #0x42
    56b8:      	b.ne	0x555c <_stogir.stack.validate+0x268>
    56bc:      	lsr	w1, w1, #0
    56c0:      	ubfx	x1, x1, #8, #8
    56c4:      	cmp	x1, #0x6
    56c8:      	b.ne	0x555c <_stogir.stack.validate+0x268>
    56cc:      	ldr	x0, [x0, #0x78]
    56d0:      	add	x0, x2, x0
    56d4:      	ldr	w0, [x0]
    56d8:      	sxtw	x0, w0
    56dc:      	cmp	x0, #0x0
    56e0:      	b.ne	0x555c <_stogir.stack.validate+0x268>
    56e4:      	movz	x1, #0x0, lsl #48
    56e8:      	mov	x0, #0x8                ; =8
    56ec:      	movz	x2, #0x0, lsl #48
    56f0:      	b	0x5570 <_stogir.stack.validate+0x27c>
    56f4:      	movz	x1, #0x0, lsl #48
    56f8:      	b	0x561c <_stogir.stack.validate+0x328>
    56fc:      	movz	x1, #0x0, lsl #48
    5700:      	b	0x5614 <_stogir.stack.validate+0x320>
    5704:      	ldr	x3, [x0, #0x78]
    5708:      	add	x2, x2, x3
    570c:      	ldr	w2, [x2]
    5710:      	uxtb	w16, w1
    5714:      	cmp	w16, wzr
    5718:      	b.eq	0x5784 <_stogir.stack.validate+0x490>
    571c:      	mov	x1, #0x3                ; =3
    5720:      	b	0x5798 <_stogir.stack.validate+0x4a4>
    5724:      	add	x16, sp, #0x10
    5728:      	ldr	w0, [x16]
    572c:      	add	x16, sp, #0x10
    5730:      	ldr	w1, [x16, #0x4]
    5734:      	add	x16, sp, #0x10
    5738:      	ldr	w2, [x16, #0x8]
    573c:      	lsr	w1, w1, #0
    5740:      	ubfx	x0, x0, #8, #8
    5744:      	lsr	w2, w2, #0
    5748:      	lsr	w0, w0, #0
    574c:      	add	x8, sp, #0x20
    5750:      	mov	w3, w1
    5754:      	mov	w1, w19
    5758:      	mov	w4, w2
    575c:      	mov	w2, w0
    5760:      	mov	x0, x23
    5764:      	bl	0x5764 <_stogir.stack.validate+0x470>
		0000000000005764:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    5768:      	add	x16, sp, #0x20
    576c:      	ldr	x1, [x16]
    5770:      	add	x16, sp, #0x20
    5774:      	ldr	x0, [x16, #0x8]
    5778:      	add	x16, sp, #0x20
    577c:      	ldr	x2, [x16, #0x10]
    5780:      	b	0x5400 <_stogir.stack.validate+0x10c>
    5784:      	uxtb	w16, w20
    5788:      	cmp	w16, wzr
    578c:      	mov	x16, #0x1               ; =1
    5790:      	mov	x17, #0x2               ; =2
    5794:      	csel	x1, x16, x17, ne
    5798:      	sxtw	x2, w2
    579c:      	lsr	w1, w1, #0
    57a0:      	sxtw	x1, w1
    57a4:      	cmp	x2, x1
    57a8:      	b.ne	0x58d4 <_stogir.stack.validate+0x5e0>
    57ac:      	add	x16, sp, #0x10
    57b0:      	ldr	w1, [x16]
    57b4:      	orr	x2, x1, xzr
    57b8:      	ubfx	x2, x2, #16, #16
    57bc:      	and	x2, x2, #0x8000
    57c0:      	uxth	w2, w2
    57c4:      	cmp	x2, #0x0
    57c8:      	b.ne	0x5868 <_stogir.stack.validate+0x574>
    57cc:      	mov	x22, x8
    57d0:      	mov	x23, x0
    57d4:      	lsr	w19, w19, #0
    57d8:      	uxtb	w16, w20
    57dc:      	cmp	w16, wzr
    57e0:      	b.ne	0x5724 <_stogir.stack.validate+0x430>
    57e4:      	uxtb	w16, w21
    57e8:      	cmp	w16, wzr
    57ec:      	b.ne	0x5724 <_stogir.stack.validate+0x430>
    57f0:      	add	x16, sp, #0x10
    57f4:      	ldr	w0, [x16]
    57f8:      	add	x16, sp, #0x10
    57fc:      	ldr	w1, [x16, #0x4]
    5800:      	add	x16, sp, #0x10
    5804:      	ldr	w2, [x16, #0x8]
    5808:      	lsr	w1, w1, #0
    580c:      	ubfx	x0, x0, #8, #8
    5810:      	add	x16, sp, #0x10
    5814:      	ldr	w3, [x16, #0xc]
    5818:      	lsr	w2, w2, #0
    581c:      	lsr	w3, w3, #0
    5820:      	lsr	w0, w0, #0
    5824:      	add	x8, sp, #0x40
    5828:      	mov	w4, w2
    582c:      	mov	w2, w0
    5830:      	mov	x0, x23
    5834:      	mov	w5, w3
    5838:      	mov	w3, w1
    583c:      	mov	w1, w19
    5840:      	bl	0x5840 <_stogir.stack.validate+0x54c>
		0000000000005840:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    5844:      	add	x16, sp, #0x40
    5848:      	ldr	x1, [x16]
    584c:      	add	x16, sp, #0x40
    5850:      	ldr	x0, [x16, #0x8]
    5854:      	add	x16, sp, #0x40
    5858:      	ldr	x2, [x16, #0x10]
    585c:      	b	0x5780 <_stogir.stack.validate+0x48c>
    5860:      	movz	x1, #0x0, lsl #48
    5864:      	b	0x56f8 <_stogir.stack.validate+0x404>
    5868:      	uxtb	w2, w1
    586c:      	cmp	x2, #0x51
    5870:      	b.ne	0x58dc <_stogir.stack.validate+0x5e8>
    5874:      	ubfx	x1, x1, #16, #16
    5878:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    587c:      	b.ne	0x58e4 <_stogir.stack.validate+0x5f0>
    5880:      	add	x16, sp, #0x10
    5884:      	ldr	w1, [x16, #0x4]
    5888:      	add	x16, sp, #0x10
    588c:      	ldr	w2, [x16, #0x8]
    5890:      	lsr	w1, w1, #0
    5894:      	lsr	w2, w2, #0
    5898:      	mov	x22, x8
    589c:      	mov	x23, x0
    58a0:      	bl	0x58a0 <_stogir.stack.validate+0x5ac>
		00000000000058a0:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    58a4:      	cmp	x0, #0x0
    58a8:      	b.ne	0x57d4 <_stogir.stack.validate+0x4e0>
    58ac:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		00000000000058ac:  ARM64_RELOC_PAGE21	l_stogir.394
    58b0:      	ldr	x16, [x16]
		00000000000058b0:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    58b4:      	orr	x0, x16, xzr
    58b8:      	mov	x1, #0x1                ; =1
    58bc:      	mov	x2, #0x26               ; =38
    58c0:      	b	0x5780 <_stogir.stack.validate+0x48c>
    58c4:      	brk	#0
    58c8:      	b	0x58c4 <_stogir.stack.validate+0x5d0>
    58cc:      	brk	#0
    58d0:      	b	0x58cc <_stogir.stack.validate+0x5d8>
    58d4:      	mov	x22, x8
    58d8:      	b	0x53ec <_stogir.stack.validate+0xf8>
    58dc:      	mov	x22, x8
    58e0:      	b	0x58ac <_stogir.stack.validate+0x5b8>
    58e4:      	mov	x22, x8
    58e8:      	b	0x58ac <_stogir.stack.validate+0x5b8>

00000000000058ec <_stogir.locals.operation?>:
    58ec:      	sxtw	x0, w0
    58f0:      	cmp	x0, #0x41
    58f4:      	b.ne	0x5908 <_stogir.locals.operation?+0x1c>
    58f8:      	mov	x0, #0x1                ; =1
    58fc:      	b	0x5904 <_stogir.locals.operation?+0x18>
    5900:      	movz	x0, #0x0, lsl #48
    5904:      	ret
    5908:      	cmp	x0, #0x48
    590c:      	b.ne	0x5918 <_stogir.locals.operation?+0x2c>
    5910:      	mov	x0, #0x1                ; =1
    5914:      	b	0x5904 <_stogir.locals.operation?+0x18>
    5918:      	cmp	x0, #0x55
    591c:      	b.lt	0x5900 <_stogir.locals.operation?+0x14>
    5920:      	cmp	x0, #0x58
    5924:      	cset	w0, le
    5928:      	ubfx	x0, x0, #0, #8
    592c:      	b	0x5904 <_stogir.locals.operation?+0x18>

0000000000005930 <_stogir.locals.validate>:
    5930:      	sub	sp, sp, #0xb0
    5934:      	str	x29, [sp]
    5938:      	str	x30, [sp, #0x8]
    593c:      	mov	x29, sp
    5940:      	str	x19, [sp, #0x70]
    5944:      	str	x20, [sp, #0x78]
    5948:      	str	x21, [sp, #0x80]
    594c:      	str	x22, [sp, #0x88]
    5950:      	str	x23, [sp, #0x90]
    5954:      	str	x24, [sp, #0x98]
    5958:      	str	x25, [sp, #0xa0]
    595c:      	sxtw	x1, w1
    5960:      	lsl	x3, x1, #2
    5964:      	cmp	x1, #0x0
    5968:      	cset	w4, gt
    596c:      	movz	x16, #0x0, lsl #48
    5970:      	sub	x5, x16, x1
    5974:      	sub	x6, x5, #0x1
    5978:      	uxtb	w16, w4
    597c:      	cmp	w16, wzr
    5980:      	b.eq	0x59c0 <_stogir.locals.validate+0x90>
    5984:      	ldr	x5, [x0, #0x8]
    5988:      	cmp	x1, x5
    598c:      	b.ge	0x5a58 <_stogir.locals.validate+0x128>
    5990:      	add	x5, x0, #0x78
    5994:      	ldr	x5, [x5, #0x8]
    5998:      	cmp	x1, x5
    599c:      	b.ge	0x5b54 <_stogir.locals.validate+0x224>
    59a0:      	ldr	x5, [x0, #0x78]
    59a4:      	add	x5, x3, x5
    59a8:      	ldr	w5, [x5]
    59ac:      	sxtw	x5, w5
    59b0:      	cmp	x5, #0x0
    59b4:      	cset	w5, ge
    59b8:      	ubfx	x5, x5, #0, #8
    59bc:      	b	0x5b58 <_stogir.locals.validate+0x228>
    59c0:      	cmp	x1, #0x0
    59c4:      	b.ge	0x5a60 <_stogir.locals.validate+0x130>
    59c8:      	add	x7, x0, #0x28
    59cc:      	add	x9, x0, #0x50
    59d0:      	ldr	x7, [x7, #0x8]
    59d4:      	ldr	x9, [x9, #0x8]
    59d8:      	cmp	x7, x9
    59dc:      	b.ne	0x5a08 <_stogir.locals.validate+0xd8>
    59e0:      	cmp	x5, x7
    59e4:      	b.gt	0x5bd8 <_stogir.locals.validate+0x2a8>
    59e8:      	ldr	x5, [x0, #0x50]
    59ec:      	add	x5, x5, x6, lsl #2
    59f0:      	ldr	w5, [x5]
    59f4:      	sxtw	x5, w5
    59f8:      	cmp	x5, #0x0
    59fc:      	cset	w5, gt
    5a00:      	ubfx	x5, x5, #0, #8
    5a04:      	b	0x5bdc <_stogir.locals.validate+0x2ac>
    5a08:      	movz	x5, #0x0, lsl #48
    5a0c:      	b	0x5a64 <_stogir.locals.validate+0x134>
    5a10:      	cmp	x4, #0x0
    5a14:      	cset	w4, ne
    5a18:      	uxtb	w16, w4
    5a1c:      	cmp	w16, wzr
    5a20:      	mov	x16, #0x2               ; =2
    5a24:      	mov	x17, #0x3               ; =3
    5a28:      	csel	x4, x16, x17, ne
    5a2c:      	lsr	w4, w4, #0
    5a30:      	sxtw	x4, w4
    5a34:      	cmp	x1, #0x0
    5a38:      	b.gt	0x5b5c <_stogir.locals.validate+0x22c>
    5a3c:      	mov	x23, x8
    5a40:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005a40:  ARM64_RELOC_PAGE21	l_stogir.395
    5a44:      	ldr	x16, [x16]
		0000000000005a44:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    5a48:      	orr	x0, x16, xzr
    5a4c:      	mov	x2, #0x1                ; =1
    5a50:      	mov	x1, #0x17               ; =23
    5a54:      	b	0x5af8 <_stogir.locals.validate+0x1c8>
    5a58:      	movz	x5, #0x0, lsl #48
    5a5c:      	b	0x5a64 <_stogir.locals.validate+0x134>
    5a60:      	movz	x5, #0x0, lsl #48
    5a64:      	cmp	x5, #0x0
    5a68:      	b.eq	0x5aa4 <_stogir.locals.validate+0x174>
    5a6c:      	uxtb	w16, w4
    5a70:      	cmp	w16, wzr
    5a74:      	b.eq	0x5a8c <_stogir.locals.validate+0x15c>
    5a78:      	ldr	x4, [x0]
    5a7c:      	add	x4, x4, x1, lsl #4
    5a80:      	ldr	x5, [x4]
    5a84:      	ldr	x4, [x4, #0x8]
    5a88:      	b	0x5a9c <_stogir.locals.validate+0x16c>
    5a8c:      	ldr	x4, [x0, #0x28]
    5a90:      	add	x4, x4, x6, lsl #4
    5a94:      	ldr	x5, [x4]
    5a98:      	ldr	x4, [x4, #0x8]
    5a9c:      	mov	x6, #0x1                ; =1
    5aa0:      	b	0x5ab0 <_stogir.locals.validate+0x180>
    5aa4:      	movz	x6, #0x0, lsl #48
    5aa8:      	movz	x5, #0x0, lsl #48
    5aac:      	movz	x4, #0x0, lsl #48
    5ab0:      	lsr	w6, w6, #0
    5ab4:      	lsr	x16, x6, #0
    5ab8:      	cmp	x16, #0x1
    5abc:      	b.eq	0x5ad8 <_stogir.locals.validate+0x1a8>
    5ac0:      	b.lo	0x5ac8 <_stogir.locals.validate+0x198>
    5ac4:      	b	0x5adc <_stogir.locals.validate+0x1ac>
    5ac8:      	cmp	x16, #0x0
    5acc:      	b.eq	0x5ad4 <_stogir.locals.validate+0x1a4>
    5ad0:      	b	0x5adc <_stogir.locals.validate+0x1ac>
    5ad4:      	b	0x5ae0 <_stogir.locals.validate+0x1b0>
    5ad8:      	b	0x5b30 <_stogir.locals.validate+0x200>
    5adc:      	b	0x5d10 <_stogir.locals.validate+0x3e0>
    5ae0:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005ae0:  ARM64_RELOC_PAGE21	l_stogir.396
    5ae4:      	ldr	x16, [x16]
		0000000000005ae4:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    5ae8:      	orr	x0, x16, xzr
    5aec:      	mov	x23, x8
    5af0:      	mov	x2, #0x1                ; =1
    5af4:      	mov	x1, #0x17               ; =23
    5af8:      	str	x2, [x23]
    5afc:      	str	x0, [x23, #0x8]
    5b00:      	str	x1, [x23, #0x10]
    5b04:      	ldr	x19, [sp, #0x70]
    5b08:      	ldr	x20, [sp, #0x78]
    5b0c:      	ldr	x21, [sp, #0x80]
    5b10:      	ldr	x22, [sp, #0x88]
    5b14:      	ldr	x23, [sp, #0x90]
    5b18:      	ldr	x24, [sp, #0x98]
    5b1c:      	ldr	x25, [sp, #0xa0]
    5b20:      	ldr	x29, [sp]
    5b24:      	ldr	x30, [sp, #0x8]
    5b28:      	add	sp, sp, #0xb0
    5b2c:      	ret
    5b30:      	uxtb	w6, w5
    5b34:      	add	x16, sp, #0x10
    5b38:      	str	x5, [x16]
    5b3c:      	add	x16, sp, #0x10
    5b40:      	str	x4, [x16, #0x8]
    5b44:      	cmp	x6, #0x55
    5b48:      	b.ne	0x5bbc <_stogir.locals.validate+0x28c>
    5b4c:      	mov	x4, #0x1                ; =1
    5b50:      	b	0x5bc8 <_stogir.locals.validate+0x298>
    5b54:      	movz	x5, #0x0, lsl #48
    5b58:      	b	0x5a5c <_stogir.locals.validate+0x12c>
    5b5c:      	cmp	x6, #0x48
    5b60:      	cset	w21, eq
    5b64:      	uxtb	w16, w20
    5b68:      	cmp	w16, wzr
    5b6c:      	b.ne	0x5be0 <_stogir.locals.validate+0x2b0>
    5b70:      	uxtb	w16, w21
    5b74:      	cmp	w16, wzr
    5b78:      	b.ne	0x5be0 <_stogir.locals.validate+0x2b0>
    5b7c:      	cmp	x6, #0x55
    5b80:      	b.lt	0x6074 <_stogir.locals.validate+0x744>
    5b84:      	cmp	x6, #0x58
    5b88:      	b.le	0x5be0 <_stogir.locals.validate+0x2b0>
    5b8c:      	mov	x23, x8
    5b90:      	b	0x5a40 <_stogir.locals.validate+0x110>
    5b94:      	cmp	x6, #0x58
    5b98:      	cset	w5, eq
    5b9c:      	ubfx	x19, x5, #0, #8
    5ba0:      	cmp	x6, #0x41
    5ba4:      	cset	w20, eq
    5ba8:      	uxtb	w16, w20
    5bac:      	cmp	w16, wzr
    5bb0:      	b.eq	0x5a10 <_stogir.locals.validate+0xe0>
    5bb4:      	mov	x4, #0x1                ; =1
    5bb8:      	b	0x5a34 <_stogir.locals.validate+0x104>
    5bbc:      	cmp	x6, #0x56
    5bc0:      	cset	w4, eq
    5bc4:      	ubfx	x4, x4, #0, #8
    5bc8:      	cmp	x6, #0x57
    5bcc:      	b.ne	0x5b94 <_stogir.locals.validate+0x264>
    5bd0:      	mov	x19, #0x1               ; =1
    5bd4:      	b	0x5ba0 <_stogir.locals.validate+0x270>
    5bd8:      	movz	x5, #0x0, lsl #48
    5bdc:      	b	0x5a0c <_stogir.locals.validate+0xdc>
    5be0:      	lsr	w4, w4, #0
    5be4:      	sxtw	x4, w4
    5be8:      	ldr	x5, [x0, #0x78]
    5bec:      	add	x3, x3, x5
    5bf0:      	ldr	w3, [x3]
    5bf4:      	sxtw	x3, w3
    5bf8:      	cmp	x3, x4
    5bfc:      	b.ne	0x607c <_stogir.locals.validate+0x74c>
    5c00:      	uxtb	w16, w20
    5c04:      	cmp	w16, wzr
    5c08:      	b.ne	0x5c28 <_stogir.locals.validate+0x2f8>
    5c0c:      	uxtb	w16, w21
    5c10:      	cmp	w16, wzr
    5c14:      	b.ne	0x5c28 <_stogir.locals.validate+0x2f8>
    5c18:      	add	x16, sp, #0x10
    5c1c:      	ldr	w1, [x16, #0x8]
    5c20:      	sxtw	x1, w1
    5c24:      	b	0x5c40 <_stogir.locals.validate+0x310>
    5c28:      	uxtb	w16, w21
    5c2c:      	cmp	w16, wzr
    5c30:      	b.ne	0x5c40 <_stogir.locals.validate+0x310>
    5c34:      	add	x16, sp, #0x10
    5c38:      	ldr	w1, [x16, #0x4]
    5c3c:      	sxtw	x1, w1
    5c40:      	add	x16, sp, #0x20
    5c44:      	orr	x22, x16, xzr
    5c48:      	lsr	w2, w2, #0
    5c4c:      	lsr	w1, w1, #0
    5c50:      	mov	x23, x8
    5c54:      	add	x8, sp, #0x20
    5c58:      	mov	x24, x0
    5c5c:      	mov	w25, w2
    5c60:      	bl	0x5c60 <_stogir.locals.validate+0x330>
		0000000000005c60:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    5c64:      	add	x16, sp, #0x20
    5c68:      	ldr	w0, [x16]
    5c6c:      	lsr	x16, x0, #0
    5c70:      	cmp	x16, #0x1
    5c74:      	b.eq	0x5c90 <_stogir.locals.validate+0x360>
    5c78:      	b.lo	0x5c80 <_stogir.locals.validate+0x350>
    5c7c:      	b	0x5c94 <_stogir.locals.validate+0x364>
    5c80:      	cmp	x16, #0x0
    5c84:      	b.eq	0x5c8c <_stogir.locals.validate+0x35c>
    5c88:      	b	0x5c94 <_stogir.locals.validate+0x364>
    5c8c:      	b	0x5cb0 <_stogir.locals.validate+0x380>
    5c90:      	b	0x5c98 <_stogir.locals.validate+0x368>
    5c94:      	b	0x5ee8 <_stogir.locals.validate+0x5b8>
    5c98:      	add	x1, x22, #0x8
    5c9c:      	add	x16, sp, #0x20
    5ca0:      	ldr	x0, [x16, #0x8]
    5ca4:      	ldr	x1, [x1, #0x8]
    5ca8:      	mov	x2, #0x1                ; =1
    5cac:      	b	0x5a54 <_stogir.locals.validate+0x124>
    5cb0:      	add	x16, sp, #0x20
    5cb4:      	ldr	x22, [x16, #0x8]
    5cb8:      	uxtb	w16, w21
    5cbc:      	cmp	w16, wzr
    5cc0:      	b.eq	0x5cdc <_stogir.locals.validate+0x3ac>
    5cc4:      	lsr	w22, w22, #0
    5cc8:      	sxtw	x22, w22
    5ccc:      	and	x0, x22, #0xffffffff
    5cd0:      	movz	x2, #0x0, lsl #48
    5cd4:      	movz	x1, #0x0, lsl #48
    5cd8:      	b	0x5cac <_stogir.locals.validate+0x37c>
    5cdc:      	uxtb	w16, w20
    5ce0:      	cmp	w16, wzr
    5ce4:      	b.eq	0x5d30 <_stogir.locals.validate+0x400>
    5ce8:      	add	x16, sp, #0x10
    5cec:      	ldr	w0, [x16]
    5cf0:      	ubfx	x0, x0, #8, #8
    5cf4:      	cmp	x0, #0x6
    5cf8:      	b.ne	0x5d18 <_stogir.locals.validate+0x3e8>
    5cfc:      	sxtw	x25, w25
    5d00:      	and	x0, x25, #0xffffffff
    5d04:      	movz	x2, #0x0, lsl #48
    5d08:      	movz	x1, #0x0, lsl #48
    5d0c:      	b	0x5d2c <_stogir.locals.validate+0x3fc>
    5d10:      	brk	#0
    5d14:      	b	0x5d10 <_stogir.locals.validate+0x3e0>
    5d18:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005d18:  ARM64_RELOC_PAGE21	l_stogir.397
    5d1c:      	ldr	x16, [x16]
		0000000000005d1c:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    5d20:      	orr	x0, x16, xzr
    5d24:      	mov	x2, #0x1                ; =1
    5d28:      	mov	x1, #0x21               ; =33
    5d2c:      	b	0x5cd8 <_stogir.locals.validate+0x3a8>
    5d30:      	add	x16, sp, #0x10
    5d34:      	ldr	w0, [x16, #0x4]
    5d38:      	sxtw	x0, w0
    5d3c:      	cmp	x0, #0x0
    5d40:      	cset	w1, gt
    5d44:      	movz	x16, #0x0, lsl #48
    5d48:      	sub	x2, x16, x0
    5d4c:      	sub	x3, x2, #0x1
    5d50:      	uxtb	w16, w1
    5d54:      	cmp	w16, wzr
    5d58:      	b.eq	0x5e2c <_stogir.locals.validate+0x4fc>
    5d5c:      	ldr	x2, [x24, #0x8]
    5d60:      	cmp	x0, x2
    5d64:      	b.ge	0x5e24 <_stogir.locals.validate+0x4f4>
    5d68:      	add	x2, x24, #0x78
    5d6c:      	ldr	x2, [x2, #0x8]
    5d70:      	cmp	x0, x2
    5d74:      	b.ge	0x5ed8 <_stogir.locals.validate+0x5a8>
    5d78:      	ldr	x2, [x24, #0x78]
    5d7c:      	add	x2, x2, x0, lsl #2
    5d80:      	ldr	w2, [x2]
    5d84:      	sxtw	x2, w2
    5d88:      	cmp	x2, #0x0
    5d8c:      	cset	w2, ge
    5d90:      	ubfx	x2, x2, #0, #8
    5d94:      	b	0x5edc <_stogir.locals.validate+0x5ac>
    5d98:      	movz	x1, #0x0, lsl #48
    5d9c:      	movz	x0, #0x0, lsl #48
    5da0:      	lsr	w1, w1, #0
    5da4:      	lsr	x16, x1, #0
    5da8:      	cmp	x16, #0x1
    5dac:      	b.eq	0x5dc8 <_stogir.locals.validate+0x498>
    5db0:      	b.lo	0x5db8 <_stogir.locals.validate+0x488>
    5db4:      	b	0x5dcc <_stogir.locals.validate+0x49c>
    5db8:      	cmp	x16, #0x0
    5dbc:      	b.eq	0x5dc4 <_stogir.locals.validate+0x494>
    5dc0:      	b	0x5dcc <_stogir.locals.validate+0x49c>
    5dc4:      	b	0x5dd0 <_stogir.locals.validate+0x4a0>
    5dc8:      	b	0x5e74 <_stogir.locals.validate+0x544>
    5dcc:      	b	0x6048 <_stogir.locals.validate+0x718>
    5dd0:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005dd0:  ARM64_RELOC_PAGE21	l_stogir.398
    5dd4:      	ldr	x16, [x16]
		0000000000005dd4:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    5dd8:      	orr	x0, x16, xzr
    5ddc:      	mov	x2, #0x1                ; =1
    5de0:      	mov	x1, #0x1c               ; =28
    5de4:      	b	0x5d2c <_stogir.locals.validate+0x3fc>
    5de8:      	ldr	x0, [x24, #0x28]
    5dec:      	add	x0, x0, x3, lsl #4
    5df0:      	ldr	x0, [x0]
    5df4:      	mov	x1, #0x1                ; =1
    5df8:      	b	0x5da0 <_stogir.locals.validate+0x470>
    5dfc:      	movz	x2, #0x0, lsl #48
    5e00:      	cmp	x2, #0x0
    5e04:      	b.eq	0x5d98 <_stogir.locals.validate+0x468>
    5e08:      	uxtb	w16, w1
    5e0c:      	cmp	w16, wzr
    5e10:      	b.eq	0x5de8 <_stogir.locals.validate+0x4b8>
    5e14:      	ldr	x1, [x24]
    5e18:      	add	x0, x1, x0, lsl #4
    5e1c:      	ldr	x0, [x0]
    5e20:      	b	0x5df4 <_stogir.locals.validate+0x4c4>
    5e24:      	movz	x2, #0x0, lsl #48
    5e28:      	b	0x5e00 <_stogir.locals.validate+0x4d0>
    5e2c:      	cmp	x0, #0x0
    5e30:      	b.ge	0x5dfc <_stogir.locals.validate+0x4cc>
    5e34:      	add	x4, x24, #0x28
    5e38:      	add	x5, x24, #0x50
    5e3c:      	ldr	x4, [x4, #0x8]
    5e40:      	ldr	x5, [x5, #0x8]
    5e44:      	cmp	x4, x5
    5e48:      	b.ne	0x5ed0 <_stogir.locals.validate+0x5a0>
    5e4c:      	cmp	x2, x4
    5e50:      	b.gt	0x5ee0 <_stogir.locals.validate+0x5b0>
    5e54:      	ldr	x2, [x24, #0x50]
    5e58:      	add	x2, x2, x3, lsl #2
    5e5c:      	ldr	w2, [x2]
    5e60:      	sxtw	x2, w2
    5e64:      	cmp	x2, #0x0
    5e68:      	cset	w2, gt
    5e6c:      	ubfx	x2, x2, #0, #8
    5e70:      	b	0x5ee4 <_stogir.locals.validate+0x5b4>
    5e74:      	add	x16, sp, #0x10
    5e78:      	ldr	w1, [x16, #0x4]
    5e7c:      	sxtw	x1, w1
    5e80:      	cmp	x1, #0x0
    5e84:      	b.le	0x5eb8 <_stogir.locals.validate+0x588>
    5e88:      	uxtb	w0, w0
    5e8c:      	cmp	x0, #0x83
    5e90:      	cset	w1, lt
    5e94:      	uxtb	w16, w1
    5e98:      	cmp	w16, wzr
    5e9c:      	b.eq	0x5ef0 <_stogir.locals.validate+0x5c0>
    5ea0:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005ea0:  ARM64_RELOC_PAGE21	l_stogir.399
    5ea4:      	ldr	x16, [x16]
		0000000000005ea4:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    5ea8:      	orr	x2, x16, xzr
    5eac:      	add	x2, x0, x2
    5eb0:      	ldrb	w2, [x2]
    5eb4:      	b	0x5ef4 <_stogir.locals.validate+0x5c4>
    5eb8:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005eb8:  ARM64_RELOC_PAGE21	l_stogir.400
    5ebc:      	ldr	x16, [x16]
		0000000000005ebc:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    5ec0:      	orr	x0, x16, xzr
    5ec4:      	mov	x2, #0x1                ; =1
    5ec8:      	mov	x1, #0x1c               ; =28
    5ecc:      	b	0x5de4 <_stogir.locals.validate+0x4b4>
    5ed0:      	movz	x2, #0x0, lsl #48
    5ed4:      	b	0x5e00 <_stogir.locals.validate+0x4d0>
    5ed8:      	movz	x2, #0x0, lsl #48
    5edc:      	b	0x5e28 <_stogir.locals.validate+0x4f8>
    5ee0:      	movz	x2, #0x0, lsl #48
    5ee4:      	b	0x5ed4 <_stogir.locals.validate+0x5a4>
    5ee8:      	brk	#0
    5eec:      	b	0x5ee8 <_stogir.locals.validate+0x5b8>
    5ef0:      	movz	x2, #0x0, lsl #48
    5ef4:      	uxtb	w2, w2
    5ef8:      	and	x2, x2, #0x1
    5efc:      	uxtb	w2, w2
    5f00:      	cmp	x2, #0x0
    5f04:      	b.eq	0x5eb8 <_stogir.locals.validate+0x588>
    5f08:      	uxtb	w16, w1
    5f0c:      	cmp	w16, wzr
    5f10:      	b.eq	0x5f2c <_stogir.locals.validate+0x5fc>
    5f14:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005f14:  ARM64_RELOC_PAGE21	l_stogir.399
    5f18:      	ldr	x16, [x16]
		0000000000005f18:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    5f1c:      	orr	x1, x16, xzr
    5f20:      	add	x0, x0, x1
    5f24:      	ldrb	w0, [x0]
    5f28:      	b	0x5f30 <_stogir.locals.validate+0x600>
    5f2c:      	movz	x0, #0x0, lsl #48
    5f30:      	uxtb	w0, w0
    5f34:      	and	x0, x0, #0x4
    5f38:      	uxtb	w0, w0
    5f3c:      	cmp	x0, #0x0
    5f40:      	cset	w0, eq
    5f44:      	uxtb	w16, w0
    5f48:      	cmp	w16, wzr
    5f4c:      	cset	x0, eq
    5f50:      	cmp	x0, #0x0
    5f54:      	b.ne	0x5eb8 <_stogir.locals.validate+0x588>
    5f58:      	cmp	x19, #0x0
    5f5c:      	b.eq	0x5ff4 <_stogir.locals.validate+0x6c4>
    5f60:      	add	x16, sp, #0x10
    5f64:      	ldr	w0, [x16, #0xc]
    5f68:      	lsr	w0, w0, #0
    5f6c:      	add	x8, sp, #0x40
    5f70:      	mov	w1, w0
    5f74:      	mov	x0, x24
    5f78:      	bl	0x5f78 <_stogir.locals.validate+0x648>
		0000000000005f78:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    5f7c:      	add	x16, sp, #0x40
    5f80:      	ldr	x0, [x16]
    5f84:      	add	x16, sp, #0x40
    5f88:      	ldr	x20, [x16, #0x8]
    5f8c:      	b	0x6000 <_stogir.locals.validate+0x6d0>
    5f90:      	lsr	w25, w25, #0
    5f94:      	lsr	w0, w20, #0
    5f98:      	ubfx	x0, x0, #8, #8
    5f9c:      	lsr	w0, w0, #0
    5fa0:      	mov	w1, w25
    5fa4:      	bl	0x5fa4 <_stogir.locals.validate+0x674>
		0000000000005fa4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    5fa8:      	lsr	w0, w0, #0
    5fac:      	sxtw	x0, w0
    5fb0:      	cmp	x0, #0x0
    5fb4:      	b.le	0x5fdc <_stogir.locals.validate+0x6ac>
    5fb8:      	cmp	x0, x22
    5fbc:      	b.gt	0x5fdc <_stogir.locals.validate+0x6ac>
    5fc0:      	cmp	x19, #0x0
    5fc4:      	b.eq	0x6050 <_stogir.locals.validate+0x720>
    5fc8:      	add	x16, sp, #0x10
    5fcc:      	ldr	w1, [x16]
    5fd0:      	ubfx	x1, x1, #8, #8
    5fd4:      	cmp	x1, #0x0
    5fd8:      	b.eq	0x6050 <_stogir.locals.validate+0x720>
    5fdc:      	adrp	x16, 0x5000 <_stogir.switch.validate+0x84>
		0000000000005fdc:  ARM64_RELOC_PAGE21	l_stogir.401
    5fe0:      	ldr	x16, [x16]
		0000000000005fe0:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    5fe4:      	orr	x0, x16, xzr
    5fe8:      	mov	x2, #0x1                ; =1
    5fec:      	mov	x1, #0x23               ; =35
    5ff0:      	b	0x5ecc <_stogir.locals.validate+0x59c>
    5ff4:      	add	x16, sp, #0x10
    5ff8:      	ldr	x20, [x16]
    5ffc:      	mov	x0, #0x1                ; =1
    6000:      	lsr	w0, w0, #0
    6004:      	lsr	x16, x0, #0
    6008:      	cmp	x16, #0x1
    600c:      	b.eq	0x6028 <_stogir.locals.validate+0x6f8>
    6010:      	b.lo	0x6018 <_stogir.locals.validate+0x6e8>
    6014:      	b	0x602c <_stogir.locals.validate+0x6fc>
    6018:      	cmp	x16, #0x0
    601c:      	b.eq	0x6024 <_stogir.locals.validate+0x6f4>
    6020:      	b	0x602c <_stogir.locals.validate+0x6fc>
    6024:      	b	0x6030 <_stogir.locals.validate+0x700>
    6028:      	b	0x5f90 <_stogir.locals.validate+0x660>
    602c:      	b	0x606c <_stogir.locals.validate+0x73c>
    6030:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		0000000000006030:  ARM64_RELOC_PAGE21	l_stogir.402
    6034:      	ldr	x16, [x16]
		0000000000006034:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    6038:      	orr	x0, x16, xzr
    603c:      	mov	x2, #0x1                ; =1
    6040:      	mov	x1, #0x19               ; =25
    6044:      	b	0x5ff0 <_stogir.locals.validate+0x6c0>
    6048:      	brk	#0
    604c:      	b	0x6048 <_stogir.locals.validate+0x718>
    6050:      	uxtb	w20, w20
    6054:      	cmp	x20, #0x48
    6058:      	b.eq	0x5fdc <_stogir.locals.validate+0x6ac>
    605c:      	and	x0, x0, #0xffffffff
    6060:      	movz	x2, #0x0, lsl #48
    6064:      	movz	x1, #0x0, lsl #48
    6068:      	b	0x5ff0 <_stogir.locals.validate+0x6c0>
    606c:      	brk	#0
    6070:      	b	0x606c <_stogir.locals.validate+0x73c>
    6074:      	mov	x23, x8
    6078:      	b	0x5a40 <_stogir.locals.validate+0x110>
    607c:      	mov	x23, x8
    6080:      	b	0x5a40 <_stogir.locals.validate+0x110>

0000000000006084 <_stogir.conversion.operation?>:
    6084:      	sxtw	x0, w0
    6088:      	cmp	x0, #0x21
    608c:      	b.lt	0x60a0 <_stogir.conversion.operation?+0x1c>
    6090:      	cmp	x0, #0x27
    6094:      	cset	w0, le
    6098:      	ubfx	x0, x0, #0, #8
    609c:      	b	0x60a4 <_stogir.conversion.operation?+0x20>
    60a0:      	movz	x0, #0x0, lsl #48
    60a4:      	ret

00000000000060a8 <_stogir.conversion.validate>:
    60a8:      	sub	sp, sp, #0x40
    60ac:      	str	x29, [sp]
    60b0:      	str	x30, [sp, #0x8]
    60b4:      	mov	x29, sp
    60b8:      	str	x19, [sp, #0x30]
    60bc:      	sxtw	x1, w1
    60c0:      	lsl	x3, x1, #2
    60c4:      	cmp	x1, #0x0
    60c8:      	cset	w4, gt
    60cc:      	movz	x16, #0x0, lsl #48
    60d0:      	sub	x5, x16, x1
    60d4:      	sub	x6, x5, #0x1
    60d8:      	uxtb	w16, w4
    60dc:      	cmp	w16, wzr
    60e0:      	b.eq	0x6120 <_stogir.conversion.validate+0x78>
    60e4:      	ldr	x5, [x0, #0x8]
    60e8:      	cmp	x1, x5
    60ec:      	b.ge	0x6170 <_stogir.conversion.validate+0xc8>
    60f0:      	add	x5, x0, #0x78
    60f4:      	ldr	x5, [x5, #0x8]
    60f8:      	cmp	x1, x5
    60fc:      	b.ge	0x6248 <_stogir.conversion.validate+0x1a0>
    6100:      	ldr	x5, [x0, #0x78]
    6104:      	add	x5, x3, x5
    6108:      	ldr	w5, [x5]
    610c:      	sxtw	x5, w5
    6110:      	cmp	x5, #0x0
    6114:      	cset	w5, ge
    6118:      	ubfx	x5, x5, #0, #8
    611c:      	b	0x624c <_stogir.conversion.validate+0x1a4>
    6120:      	cmp	x1, #0x0
    6124:      	b.ge	0x6178 <_stogir.conversion.validate+0xd0>
    6128:      	add	x7, x0, #0x28
    612c:      	add	x9, x0, #0x50
    6130:      	ldr	x7, [x7, #0x8]
    6134:      	ldr	x9, [x9, #0x8]
    6138:      	cmp	x7, x9
    613c:      	b.ne	0x6168 <_stogir.conversion.validate+0xc0>
    6140:      	cmp	x5, x7
    6144:      	b.gt	0x62dc <_stogir.conversion.validate+0x234>
    6148:      	ldr	x5, [x0, #0x50]
    614c:      	add	x5, x5, x6, lsl #2
    6150:      	ldr	w5, [x5]
    6154:      	sxtw	x5, w5
    6158:      	cmp	x5, #0x0
    615c:      	cset	w5, gt
    6160:      	ubfx	x5, x5, #0, #8
    6164:      	b	0x62e0 <_stogir.conversion.validate+0x238>
    6168:      	movz	x5, #0x0, lsl #48
    616c:      	b	0x617c <_stogir.conversion.validate+0xd4>
    6170:      	movz	x5, #0x0, lsl #48
    6174:      	b	0x617c <_stogir.conversion.validate+0xd4>
    6178:      	movz	x5, #0x0, lsl #48
    617c:      	cmp	x5, #0x0
    6180:      	b.eq	0x61b4 <_stogir.conversion.validate+0x10c>
    6184:      	uxtb	w16, w4
    6188:      	cmp	w16, wzr
    618c:      	b.eq	0x61a0 <_stogir.conversion.validate+0xf8>
    6190:      	ldr	x4, [x0]
    6194:      	add	x4, x4, x1, lsl #4
    6198:      	ldr	x4, [x4]
    619c:      	b	0x61ac <_stogir.conversion.validate+0x104>
    61a0:      	ldr	x4, [x0, #0x28]
    61a4:      	add	x4, x4, x6, lsl #4
    61a8:      	ldr	x4, [x4]
    61ac:      	mov	x5, #0x1                ; =1
    61b0:      	b	0x61bc <_stogir.conversion.validate+0x114>
    61b4:      	movz	x5, #0x0, lsl #48
    61b8:      	movz	x4, #0x0, lsl #48
    61bc:      	lsr	w5, w5, #0
    61c0:      	lsr	x16, x5, #0
    61c4:      	cmp	x16, #0x1
    61c8:      	b.eq	0x61e4 <_stogir.conversion.validate+0x13c>
    61cc:      	b.lo	0x61d4 <_stogir.conversion.validate+0x12c>
    61d0:      	b	0x61e8 <_stogir.conversion.validate+0x140>
    61d4:      	cmp	x16, #0x0
    61d8:      	b.eq	0x61e0 <_stogir.conversion.validate+0x138>
    61dc:      	b	0x61e8 <_stogir.conversion.validate+0x140>
    61e0:      	b	0x61ec <_stogir.conversion.validate+0x144>
    61e4:      	b	0x6224 <_stogir.conversion.validate+0x17c>
    61e8:      	b	0x6354 <_stogir.conversion.validate+0x2ac>
    61ec:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		00000000000061ec:  ARM64_RELOC_PAGE21	l_stogir.403
    61f0:      	ldr	x16, [x16]
		00000000000061f0:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    61f4:      	orr	x0, x16, xzr
    61f8:      	mov	x19, x8
    61fc:      	mov	x1, #0x1                ; =1
    6200:      	mov	x2, #0x12               ; =18
    6204:      	str	x1, [x19]
    6208:      	str	x0, [x19, #0x8]
    620c:      	str	x2, [x19, #0x10]
    6210:      	ldr	x19, [sp, #0x30]
    6214:      	ldr	x29, [sp]
    6218:      	ldr	x30, [sp, #0x8]
    621c:      	add	sp, sp, #0x40
    6220:      	ret
    6224:      	cmp	x1, #0x0
    6228:      	b.gt	0x6250 <_stogir.conversion.validate+0x1a8>
    622c:      	mov	x19, x8
    6230:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		0000000000006230:  ARM64_RELOC_PAGE21	l_stogir.404
    6234:      	ldr	x16, [x16]
		0000000000006234:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    6238:      	orr	x0, x16, xzr
    623c:      	mov	x1, #0x1                ; =1
    6240:      	mov	x2, #0x1e               ; =30
    6244:      	b	0x6204 <_stogir.conversion.validate+0x15c>
    6248:      	movz	x5, #0x0, lsl #48
    624c:      	b	0x6174 <_stogir.conversion.validate+0xcc>
    6250:      	uxtb	w1, w4
    6254:      	orr	x5, x1, xzr
    6258:      	cmp	x5, #0x21
    625c:      	b.lt	0x647c <_stogir.conversion.validate+0x3d4>
    6260:      	cmp	x5, #0x27
    6264:      	b.gt	0x6484 <_stogir.conversion.validate+0x3dc>
    6268:      	ldr	x5, [x0, #0x78]
    626c:      	add	x3, x3, x5
    6270:      	ldr	w3, [x3]
    6274:      	sxtw	x3, w3
    6278:      	cmp	x3, #0x1
    627c:      	b.ne	0x648c <_stogir.conversion.validate+0x3e4>
    6280:      	asr	x3, x4, #32
    6284:      	cmp	x3, #0x0
    6288:      	cset	w6, gt
    628c:      	movz	x16, #0x0, lsl #48
    6290:      	sub	x7, x16, x3
    6294:      	sub	x9, x7, #0x1
    6298:      	uxtb	w16, w6
    629c:      	cmp	w16, wzr
    62a0:      	b.eq	0x630c <_stogir.conversion.validate+0x264>
    62a4:      	ldr	x7, [x0, #0x8]
    62a8:      	cmp	x3, x7
    62ac:      	b.ge	0x635c <_stogir.conversion.validate+0x2b4>
    62b0:      	add	x7, x0, #0x78
    62b4:      	ldr	x7, [x7, #0x8]
    62b8:      	cmp	x3, x7
    62bc:      	b.ge	0x63fc <_stogir.conversion.validate+0x354>
    62c0:      	add	x5, x5, x3, lsl #2
    62c4:      	ldr	w5, [x5]
    62c8:      	sxtw	x5, w5
    62cc:      	cmp	x5, #0x0
    62d0:      	cset	w5, ge
    62d4:      	ubfx	x5, x5, #0, #8
    62d8:      	b	0x6400 <_stogir.conversion.validate+0x358>
    62dc:      	movz	x5, #0x0, lsl #48
    62e0:      	b	0x616c <_stogir.conversion.validate+0xc4>
    62e4:      	uxtb	w3, w0
    62e8:      	cmp	x3, #0x48
    62ec:      	b.ne	0x6404 <_stogir.conversion.validate+0x35c>
    62f0:      	mov	x19, x8
    62f4:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		00000000000062f4:  ARM64_RELOC_PAGE21	l_stogir.405
    62f8:      	ldr	x16, [x16]
		00000000000062f8:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    62fc:      	orr	x0, x16, xzr
    6300:      	mov	x1, #0x1                ; =1
    6304:      	mov	x2, #0x25               ; =37
    6308:      	b	0x6244 <_stogir.conversion.validate+0x19c>
    630c:      	cmp	x3, #0x0
    6310:      	b.ge	0x6364 <_stogir.conversion.validate+0x2bc>
    6314:      	add	x5, x0, #0x28
    6318:      	add	x10, x0, #0x50
    631c:      	ldr	x5, [x5, #0x8]
    6320:      	ldr	x10, [x10, #0x8]
    6324:      	cmp	x5, x10
    6328:      	b.ne	0x63f4 <_stogir.conversion.validate+0x34c>
    632c:      	cmp	x7, x5
    6330:      	b.gt	0x646c <_stogir.conversion.validate+0x3c4>
    6334:      	ldr	x5, [x0, #0x50]
    6338:      	add	x5, x5, x9, lsl #2
    633c:      	ldr	w5, [x5]
    6340:      	sxtw	x5, w5
    6344:      	cmp	x5, #0x0
    6348:      	cset	w5, gt
    634c:      	ubfx	x5, x5, #0, #8
    6350:      	b	0x6470 <_stogir.conversion.validate+0x3c8>
    6354:      	brk	#0
    6358:      	b	0x6354 <_stogir.conversion.validate+0x2ac>
    635c:      	movz	x5, #0x0, lsl #48
    6360:      	b	0x6368 <_stogir.conversion.validate+0x2c0>
    6364:      	movz	x5, #0x0, lsl #48
    6368:      	cmp	x5, #0x0
    636c:      	b.eq	0x63a0 <_stogir.conversion.validate+0x2f8>
    6370:      	uxtb	w16, w6
    6374:      	cmp	w16, wzr
    6378:      	b.eq	0x638c <_stogir.conversion.validate+0x2e4>
    637c:      	ldr	x0, [x0]
    6380:      	add	x0, x0, x3, lsl #4
    6384:      	ldr	x0, [x0]
    6388:      	b	0x6398 <_stogir.conversion.validate+0x2f0>
    638c:      	ldr	x0, [x0, #0x28]
    6390:      	add	x0, x0, x9, lsl #4
    6394:      	ldr	x0, [x0]
    6398:      	mov	x3, #0x1                ; =1
    639c:      	b	0x63a8 <_stogir.conversion.validate+0x300>
    63a0:      	movz	x3, #0x0, lsl #48
    63a4:      	movz	x0, #0x0, lsl #48
    63a8:      	lsr	w3, w3, #0
    63ac:      	lsr	x16, x3, #0
    63b0:      	cmp	x16, #0x1
    63b4:      	b.eq	0x63d0 <_stogir.conversion.validate+0x328>
    63b8:      	b.lo	0x63c0 <_stogir.conversion.validate+0x318>
    63bc:      	b	0x63d4 <_stogir.conversion.validate+0x32c>
    63c0:      	cmp	x16, #0x0
    63c4:      	b.eq	0x63cc <_stogir.conversion.validate+0x324>
    63c8:      	b	0x63d4 <_stogir.conversion.validate+0x32c>
    63cc:      	b	0x63d8 <_stogir.conversion.validate+0x330>
    63d0:      	b	0x62e4 <_stogir.conversion.validate+0x23c>
    63d4:      	b	0x6474 <_stogir.conversion.validate+0x3cc>
    63d8:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		00000000000063d8:  ARM64_RELOC_PAGE21	l_stogir.406
    63dc:      	ldr	x16, [x16]
		00000000000063dc:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    63e0:      	orr	x0, x16, xzr
    63e4:      	mov	x19, x8
    63e8:      	mov	x1, #0x1                ; =1
    63ec:      	mov	x2, #0x19               ; =25
    63f0:      	b	0x6308 <_stogir.conversion.validate+0x260>
    63f4:      	movz	x5, #0x0, lsl #48
    63f8:      	b	0x6368 <_stogir.conversion.validate+0x2c0>
    63fc:      	movz	x5, #0x0, lsl #48
    6400:      	b	0x6360 <_stogir.conversion.validate+0x2b8>
    6404:      	cmp	x3, #0x46
    6408:      	b.eq	0x6494 <_stogir.conversion.validate+0x3ec>
    640c:      	lsr	w2, w2, #0
    6410:      	lsr	w4, w4, #0
    6414:      	lsr	w0, w0, #0
    6418:      	lsr	w1, w1, #0
    641c:      	ubfx	x3, x4, #8, #8
    6420:      	ubfx	x0, x0, #8, #8
    6424:      	lsr	w3, w3, #0
    6428:      	lsr	w0, w0, #0
    642c:      	mov	x19, x8
    6430:      	add	x8, sp, #0x10
    6434:      	fmov	s31, w0
    6438:      	mov	w0, w1
    643c:      	fmov	w1, s31
    6440:      	fmov	s31, w2
    6444:      	mov	w2, w3
    6448:      	fmov	w3, s31
    644c:      	bl	0x644c <_stogir.conversion.validate+0x3a4>
		000000000000644c:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    6450:      	add	x16, sp, #0x10
    6454:      	ldr	x1, [x16]
    6458:      	add	x16, sp, #0x10
    645c:      	ldr	x0, [x16, #0x8]
    6460:      	add	x16, sp, #0x10
    6464:      	ldr	x2, [x16, #0x10]
    6468:      	b	0x6308 <_stogir.conversion.validate+0x260>
    646c:      	movz	x5, #0x0, lsl #48
    6470:      	b	0x63f8 <_stogir.conversion.validate+0x350>
    6474:      	brk	#0
    6478:      	b	0x6474 <_stogir.conversion.validate+0x3cc>
    647c:      	mov	x19, x8
    6480:      	b	0x6230 <_stogir.conversion.validate+0x188>
    6484:      	mov	x19, x8
    6488:      	b	0x6230 <_stogir.conversion.validate+0x188>
    648c:      	mov	x19, x8
    6490:      	b	0x6230 <_stogir.conversion.validate+0x188>
    6494:      	mov	x19, x8
    6498:      	b	0x62f4 <_stogir.conversion.validate+0x24c>

000000000000649c <_stogir.conditional.validate>:
    649c:      	sub	sp, sp, #0x40
    64a0:      	str	x29, [sp]
    64a4:      	str	x30, [sp, #0x8]
    64a8:      	mov	x29, sp
    64ac:      	str	x19, [sp, #0x30]
    64b0:      	sxtw	x1, w1
    64b4:      	lsl	x2, x1, #2
    64b8:      	cmp	x1, #0x0
    64bc:      	cset	w3, gt
    64c0:      	movz	x16, #0x0, lsl #48
    64c4:      	sub	x4, x16, x1
    64c8:      	sub	x5, x4, #0x1
    64cc:      	uxtb	w16, w3
    64d0:      	cmp	w16, wzr
    64d4:      	b.eq	0x6514 <_stogir.conditional.validate+0x78>
    64d8:      	ldr	x4, [x0, #0x8]
    64dc:      	cmp	x1, x4
    64e0:      	b.ge	0x6564 <_stogir.conditional.validate+0xc8>
    64e4:      	add	x4, x0, #0x78
    64e8:      	ldr	x4, [x4, #0x8]
    64ec:      	cmp	x1, x4
    64f0:      	b.ge	0x6648 <_stogir.conditional.validate+0x1ac>
    64f4:      	ldr	x4, [x0, #0x78]
    64f8:      	add	x4, x2, x4
    64fc:      	ldr	w4, [x4]
    6500:      	sxtw	x4, w4
    6504:      	cmp	x4, #0x0
    6508:      	cset	w4, ge
    650c:      	ubfx	x4, x4, #0, #8
    6510:      	b	0x664c <_stogir.conditional.validate+0x1b0>
    6514:      	cmp	x1, #0x0
    6518:      	b.ge	0x656c <_stogir.conditional.validate+0xd0>
    651c:      	add	x6, x0, #0x28
    6520:      	add	x7, x0, #0x50
    6524:      	ldr	x6, [x6, #0x8]
    6528:      	ldr	x7, [x7, #0x8]
    652c:      	cmp	x6, x7
    6530:      	b.ne	0x655c <_stogir.conditional.validate+0xc0>
    6534:      	cmp	x4, x6
    6538:      	b.gt	0x66d4 <_stogir.conditional.validate+0x238>
    653c:      	ldr	x4, [x0, #0x50]
    6540:      	add	x4, x4, x5, lsl #2
    6544:      	ldr	w4, [x4]
    6548:      	sxtw	x4, w4
    654c:      	cmp	x4, #0x0
    6550:      	cset	w4, gt
    6554:      	ubfx	x4, x4, #0, #8
    6558:      	b	0x66d8 <_stogir.conditional.validate+0x23c>
    655c:      	movz	x4, #0x0, lsl #48
    6560:      	b	0x6570 <_stogir.conditional.validate+0xd4>
    6564:      	movz	x4, #0x0, lsl #48
    6568:      	b	0x6570 <_stogir.conditional.validate+0xd4>
    656c:      	movz	x4, #0x0, lsl #48
    6570:      	cmp	x4, #0x0
    6574:      	b.eq	0x65b0 <_stogir.conditional.validate+0x114>
    6578:      	uxtb	w16, w3
    657c:      	cmp	w16, wzr
    6580:      	b.eq	0x6598 <_stogir.conditional.validate+0xfc>
    6584:      	ldr	x3, [x0]
    6588:      	add	x3, x3, x1, lsl #4
    658c:      	ldr	x4, [x3]
    6590:      	ldr	x3, [x3, #0x8]
    6594:      	b	0x65a8 <_stogir.conditional.validate+0x10c>
    6598:      	ldr	x3, [x0, #0x28]
    659c:      	add	x3, x3, x5, lsl #4
    65a0:      	ldr	x4, [x3]
    65a4:      	ldr	x3, [x3, #0x8]
    65a8:      	mov	x5, #0x1                ; =1
    65ac:      	b	0x65bc <_stogir.conditional.validate+0x120>
    65b0:      	movz	x5, #0x0, lsl #48
    65b4:      	movz	x4, #0x0, lsl #48
    65b8:      	movz	x3, #0x0, lsl #48
    65bc:      	lsr	w5, w5, #0
    65c0:      	lsr	x16, x5, #0
    65c4:      	cmp	x16, #0x1
    65c8:      	b.eq	0x65e4 <_stogir.conditional.validate+0x148>
    65cc:      	b.lo	0x65d4 <_stogir.conditional.validate+0x138>
    65d0:      	b	0x65e8 <_stogir.conditional.validate+0x14c>
    65d4:      	cmp	x16, #0x0
    65d8:      	b.eq	0x65e0 <_stogir.conditional.validate+0x144>
    65dc:      	b	0x65e8 <_stogir.conditional.validate+0x14c>
    65e0:      	b	0x65ec <_stogir.conditional.validate+0x150>
    65e4:      	b	0x6608 <_stogir.conditional.validate+0x16c>
    65e8:      	b	0x66dc <_stogir.conditional.validate+0x240>
    65ec:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		00000000000065ec:  ARM64_RELOC_PAGE21	l_stogir.407
    65f0:      	ldr	x16, [x16]
		00000000000065f0:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    65f4:      	orr	x0, x16, xzr
    65f8:      	mov	x19, x8
    65fc:      	mov	x1, #0x1                ; =1
    6600:      	mov	x2, #0x18               ; =24
    6604:      	b	0x6628 <_stogir.conditional.validate+0x18c>
    6608:      	cmp	x1, #0x0
    660c:      	b.gt	0x6650 <_stogir.conditional.validate+0x1b4>
    6610:      	mov	x19, x8
    6614:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		0000000000006614:  ARM64_RELOC_PAGE21	l_stogir.408
    6618:      	ldr	x16, [x16]
		0000000000006618:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    661c:      	orr	x0, x16, xzr
    6620:      	mov	x1, #0x1                ; =1
    6624:      	mov	x2, #0x18               ; =24
    6628:      	str	x1, [x19]
    662c:      	str	x0, [x19, #0x8]
    6630:      	str	x2, [x19, #0x10]
    6634:      	ldr	x19, [sp, #0x30]
    6638:      	ldr	x29, [sp]
    663c:      	ldr	x30, [sp, #0x8]
    6640:      	add	sp, sp, #0x40
    6644:      	ret
    6648:      	movz	x4, #0x0, lsl #48
    664c:      	b	0x6568 <_stogir.conditional.validate+0xcc>
    6650:      	uxtb	w1, w4
    6654:      	cmp	x1, #0x3c
    6658:      	b.ne	0x66e4 <_stogir.conditional.validate+0x248>
    665c:      	ldr	x1, [x0, #0x78]
    6660:      	add	x1, x2, x1
    6664:      	ldr	w1, [x1]
    6668:      	sxtw	x1, w1
    666c:      	cmp	x1, #0x3
    6670:      	b.ne	0x66ec <_stogir.conditional.validate+0x250>
    6674:      	lsr	w1, w3, #0
    6678:      	lsr	w2, w4, #0
    667c:      	lsr	x4, x4, #32
    6680:      	lsr	w1, w1, #0
    6684:      	lsr	x3, x3, #32
    6688:      	lsr	w4, w4, #0
    668c:      	lsr	w3, w3, #0
    6690:      	ubfx	x2, x2, #8, #8
    6694:      	lsr	w2, w2, #0
    6698:      	mov	x19, x8
    669c:      	add	x8, sp, #0x10
    66a0:      	fmov	s31, w1
    66a4:      	mov	w1, w2
    66a8:      	mov	w2, w4
    66ac:      	mov	w4, w3
    66b0:      	fmov	w3, s31
    66b4:      	bl	0x66b4 <_stogir.conditional.validate+0x218>
		00000000000066b4:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    66b8:      	add	x16, sp, #0x10
    66bc:      	ldr	x1, [x16]
    66c0:      	add	x16, sp, #0x10
    66c4:      	ldr	x0, [x16, #0x8]
    66c8:      	add	x16, sp, #0x10
    66cc:      	ldr	x2, [x16, #0x10]
    66d0:      	b	0x6628 <_stogir.conditional.validate+0x18c>
    66d4:      	movz	x4, #0x0, lsl #48
    66d8:      	b	0x6560 <_stogir.conditional.validate+0xc4>
    66dc:      	brk	#0
    66e0:      	b	0x66dc <_stogir.conditional.validate+0x240>
    66e4:      	mov	x19, x8
    66e8:      	b	0x6614 <_stogir.conditional.validate+0x178>
    66ec:      	mov	x19, x8
    66f0:      	b	0x6614 <_stogir.conditional.validate+0x178>

00000000000066f4 <_stogir.floating.validate>:
    66f4:      	sub	sp, sp, #0x50
    66f8:      	str	x29, [sp]
    66fc:      	str	x30, [sp, #0x8]
    6700:      	mov	x29, sp
    6704:      	str	x19, [sp, #0x40]
    6708:      	sxtw	x1, w1
    670c:      	lsl	x2, x1, #2
    6710:      	cmp	x1, #0x0
    6714:      	cset	w3, gt
    6718:      	movz	x16, #0x0, lsl #48
    671c:      	sub	x4, x16, x1
    6720:      	sub	x5, x4, #0x1
    6724:      	uxtb	w16, w3
    6728:      	cmp	w16, wzr
    672c:      	b.eq	0x676c <_stogir.floating.validate+0x78>
    6730:      	ldr	x4, [x0, #0x8]
    6734:      	cmp	x1, x4
    6738:      	b.ge	0x67bc <_stogir.floating.validate+0xc8>
    673c:      	add	x4, x0, #0x78
    6740:      	ldr	x4, [x4, #0x8]
    6744:      	cmp	x1, x4
    6748:      	b.ge	0x68b0 <_stogir.floating.validate+0x1bc>
    674c:      	ldr	x4, [x0, #0x78]
    6750:      	add	x4, x2, x4
    6754:      	ldr	w4, [x4]
    6758:      	sxtw	x4, w4
    675c:      	cmp	x4, #0x0
    6760:      	cset	w4, ge
    6764:      	ubfx	x4, x4, #0, #8
    6768:      	b	0x68b4 <_stogir.floating.validate+0x1c0>
    676c:      	cmp	x1, #0x0
    6770:      	b.ge	0x67c4 <_stogir.floating.validate+0xd0>
    6774:      	add	x6, x0, #0x28
    6778:      	add	x7, x0, #0x50
    677c:      	ldr	x6, [x6, #0x8]
    6780:      	ldr	x7, [x7, #0x8]
    6784:      	cmp	x6, x7
    6788:      	b.ne	0x67b4 <_stogir.floating.validate+0xc0>
    678c:      	cmp	x4, x6
    6790:      	b.gt	0x693c <_stogir.floating.validate+0x248>
    6794:      	ldr	x4, [x0, #0x50]
    6798:      	add	x4, x4, x5, lsl #2
    679c:      	ldr	w4, [x4]
    67a0:      	sxtw	x4, w4
    67a4:      	cmp	x4, #0x0
    67a8:      	cset	w4, gt
    67ac:      	ubfx	x4, x4, #0, #8
    67b0:      	b	0x6940 <_stogir.floating.validate+0x24c>
    67b4:      	movz	x4, #0x0, lsl #48
    67b8:      	b	0x67c8 <_stogir.floating.validate+0xd4>
    67bc:      	movz	x4, #0x0, lsl #48
    67c0:      	b	0x67c8 <_stogir.floating.validate+0xd4>
    67c4:      	movz	x4, #0x0, lsl #48
    67c8:      	cmp	x4, #0x0
    67cc:      	b.eq	0x6808 <_stogir.floating.validate+0x114>
    67d0:      	uxtb	w16, w3
    67d4:      	cmp	w16, wzr
    67d8:      	b.eq	0x67f0 <_stogir.floating.validate+0xfc>
    67dc:      	ldr	x3, [x0]
    67e0:      	add	x3, x3, x1, lsl #4
    67e4:      	ldr	x4, [x3]
    67e8:      	ldr	x3, [x3, #0x8]
    67ec:      	b	0x6800 <_stogir.floating.validate+0x10c>
    67f0:      	ldr	x3, [x0, #0x28]
    67f4:      	add	x3, x3, x5, lsl #4
    67f8:      	ldr	x4, [x3]
    67fc:      	ldr	x3, [x3, #0x8]
    6800:      	mov	x5, #0x1                ; =1
    6804:      	b	0x6814 <_stogir.floating.validate+0x120>
    6808:      	movz	x5, #0x0, lsl #48
    680c:      	movz	x4, #0x0, lsl #48
    6810:      	movz	x3, #0x0, lsl #48
    6814:      	lsr	w5, w5, #0
    6818:      	lsr	x16, x5, #0
    681c:      	cmp	x16, #0x1
    6820:      	b.eq	0x683c <_stogir.floating.validate+0x148>
    6824:      	b.lo	0x682c <_stogir.floating.validate+0x138>
    6828:      	b	0x6840 <_stogir.floating.validate+0x14c>
    682c:      	cmp	x16, #0x0
    6830:      	b.eq	0x6838 <_stogir.floating.validate+0x144>
    6834:      	b	0x6840 <_stogir.floating.validate+0x14c>
    6838:      	b	0x6844 <_stogir.floating.validate+0x150>
    683c:      	b	0x687c <_stogir.floating.validate+0x188>
    6840:      	b	0x6bd8 <_stogir.floating.validate+0x4e4>
    6844:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		0000000000006844:  ARM64_RELOC_PAGE21	l_stogir.409
    6848:      	ldr	x16, [x16]
		0000000000006848:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    684c:      	orr	x0, x16, xzr
    6850:      	mov	x19, x8
    6854:      	mov	x1, #0x1                ; =1
    6858:      	mov	x2, #0x1c               ; =28
    685c:      	str	x1, [x19]
    6860:      	str	x0, [x19, #0x8]
    6864:      	str	x2, [x19, #0x10]
    6868:      	ldr	x19, [sp, #0x40]
    686c:      	ldr	x29, [sp]
    6870:      	ldr	x30, [sp, #0x8]
    6874:      	add	sp, sp, #0x50
    6878:      	ret
    687c:      	add	x16, sp, #0x10
    6880:      	str	x4, [x16]
    6884:      	add	x16, sp, #0x10
    6888:      	str	x3, [x16, #0x8]
    688c:      	cmp	x1, #0x0
    6890:      	b.gt	0x68b8 <_stogir.floating.validate+0x1c4>
    6894:      	mov	x19, x8
    6898:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		0000000000006898:  ARM64_RELOC_PAGE21	l_stogir.410
    689c:      	ldr	x16, [x16]
		000000000000689c:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    68a0:      	orr	x0, x16, xzr
    68a4:      	mov	x1, #0x1                ; =1
    68a8:      	mov	x2, #0x1c               ; =28
    68ac:      	b	0x685c <_stogir.floating.validate+0x168>
    68b0:      	movz	x4, #0x0, lsl #48
    68b4:      	b	0x67c0 <_stogir.floating.validate+0xcc>
    68b8:      	uxtb	w4, w4
    68bc:      	orr	x1, x4, xzr
    68c0:      	cmp	x1, #0xe
    68c4:      	cset	w3, ge
    68c8:      	cmp	x1, #0x19
    68cc:      	cset	w5, le
    68d0:      	cmp	x1, #0x1f
    68d4:      	cset	w6, eq
    68d8:      	cmp	x1, #0x20
    68dc:      	cset	w7, eq
    68e0:      	uxtb	w16, w3
    68e4:      	cmp	w16, wzr
    68e8:      	b.eq	0x6944 <_stogir.floating.validate+0x250>
    68ec:      	uxtb	w16, w5
    68f0:      	cmp	w16, wzr
    68f4:      	b.eq	0x6944 <_stogir.floating.validate+0x250>
    68f8:      	cmp	x1, #0x1d
    68fc:      	cset	w1, eq
    6900:      	ldr	x9, [x0, #0x78]
    6904:      	add	x2, x2, x9
    6908:      	ldr	w2, [x2]
    690c:      	uxtb	w16, w6
    6910:      	cmp	w16, wzr
    6914:      	b.ne	0x6984 <_stogir.floating.validate+0x290>
    6918:      	uxtb	w16, w7
    691c:      	cmp	w16, wzr
    6920:      	b.ne	0x6984 <_stogir.floating.validate+0x290>
    6924:      	uxtb	w16, w1
    6928:      	cmp	w16, wzr
    692c:      	mov	x16, #0x3               ; =3
    6930:      	mov	x17, #0x2               ; =2
    6934:      	csel	x6, x16, x17, ne
    6938:      	b	0x6988 <_stogir.floating.validate+0x294>
    693c:      	movz	x4, #0x0, lsl #48
    6940:      	b	0x67b8 <_stogir.floating.validate+0xc4>
    6944:      	uxtb	w16, w6
    6948:      	cmp	w16, wzr
    694c:      	b.ne	0x68f8 <_stogir.floating.validate+0x204>
    6950:      	uxtb	w16, w7
    6954:      	cmp	w16, wzr
    6958:      	b.ne	0x68f8 <_stogir.floating.validate+0x204>
    695c:      	cmp	x1, #0x1a
    6960:      	b.lt	0x696c <_stogir.floating.validate+0x278>
    6964:      	cmp	x1, #0x1d
    6968:      	b.le	0x68f8 <_stogir.floating.validate+0x204>
    696c:      	cmp	x1, #0x3a
    6970:      	b.eq	0x68f8 <_stogir.floating.validate+0x204>
    6974:      	cmp	x1, #0x3b
    6978:      	b.eq	0x68f8 <_stogir.floating.validate+0x204>
    697c:      	mov	x19, x8
    6980:      	b	0x6898 <_stogir.floating.validate+0x1a4>
    6984:      	mov	x6, #0x1                ; =1
    6988:      	sxtw	x2, w2
    698c:      	lsr	w6, w6, #0
    6990:      	sxtw	x6, w6
    6994:      	cmp	x2, x6
    6998:      	b.ne	0x6be8 <_stogir.floating.validate+0x4f4>
    699c:      	add	x16, sp, #0x10
    69a0:      	ldr	w2, [x16, #0x4]
    69a4:      	sxtw	x2, w2
    69a8:      	cmp	x2, #0x0
    69ac:      	cset	w6, gt
    69b0:      	movz	x16, #0x0, lsl #48
    69b4:      	sub	x7, x16, x2
    69b8:      	sub	x9, x7, #0x1
    69bc:      	uxtb	w16, w6
    69c0:      	cmp	w16, wzr
    69c4:      	b.eq	0x6a1c <_stogir.floating.validate+0x328>
    69c8:      	ldr	x7, [x0, #0x8]
    69cc:      	cmp	x2, x7
    69d0:      	b.ge	0x6a64 <_stogir.floating.validate+0x370>
    69d4:      	add	x7, x0, #0x78
    69d8:      	ldr	x7, [x7, #0x8]
    69dc:      	cmp	x2, x7
    69e0:      	b.ge	0x6b34 <_stogir.floating.validate+0x440>
    69e4:      	ldr	x7, [x0, #0x78]
    69e8:      	add	x7, x7, x2, lsl #2
    69ec:      	ldr	w7, [x7]
    69f0:      	sxtw	x7, w7
    69f4:      	cmp	x7, #0x0
    69f8:      	cset	w7, ge
    69fc:      	ubfx	x7, x7, #0, #8
    6a00:      	b	0x6b38 <_stogir.floating.validate+0x444>
    6a04:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		0000000000006a04:  ARM64_RELOC_PAGE21	l_stogir.411
    6a08:      	ldr	x16, [x16]
		0000000000006a08:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    6a0c:      	orr	x0, x16, xzr
    6a10:      	mov	x1, #0x1                ; =1
    6a14:      	mov	x2, #0x1d               ; =29
    6a18:      	b	0x68ac <_stogir.floating.validate+0x1b8>
    6a1c:      	cmp	x2, #0x0
    6a20:      	b.ge	0x6a6c <_stogir.floating.validate+0x378>
    6a24:      	add	x10, x0, #0x28
    6a28:      	add	x11, x0, #0x50
    6a2c:      	ldr	x10, [x10, #0x8]
    6a30:      	ldr	x11, [x11, #0x8]
    6a34:      	cmp	x10, x11
    6a38:      	b.ne	0x6b2c <_stogir.floating.validate+0x438>
    6a3c:      	cmp	x7, x10
    6a40:      	b.gt	0x6bd0 <_stogir.floating.validate+0x4dc>
    6a44:      	ldr	x7, [x0, #0x50]
    6a48:      	add	x7, x7, x9, lsl #2
    6a4c:      	ldr	w7, [x7]
    6a50:      	sxtw	x7, w7
    6a54:      	cmp	x7, #0x0
    6a58:      	cset	w7, gt
    6a5c:      	ubfx	x7, x7, #0, #8
    6a60:      	b	0x6bd4 <_stogir.floating.validate+0x4e0>
    6a64:      	movz	x7, #0x0, lsl #48
    6a68:      	b	0x6a70 <_stogir.floating.validate+0x37c>
    6a6c:      	movz	x7, #0x0, lsl #48
    6a70:      	cmp	x7, #0x0
    6a74:      	b.eq	0x6aa8 <_stogir.floating.validate+0x3b4>
    6a78:      	uxtb	w16, w6
    6a7c:      	cmp	w16, wzr
    6a80:      	b.eq	0x6a94 <_stogir.floating.validate+0x3a0>
    6a84:      	ldr	x6, [x0]
    6a88:      	add	x2, x6, x2, lsl #4
    6a8c:      	ldr	x2, [x2]
    6a90:      	b	0x6aa0 <_stogir.floating.validate+0x3ac>
    6a94:      	ldr	x2, [x0, #0x28]
    6a98:      	add	x2, x2, x9, lsl #4
    6a9c:      	ldr	x2, [x2]
    6aa0:      	mov	x6, #0x1                ; =1
    6aa4:      	b	0x6ab0 <_stogir.floating.validate+0x3bc>
    6aa8:      	movz	x6, #0x0, lsl #48
    6aac:      	movz	x2, #0x0, lsl #48
    6ab0:      	lsr	w6, w6, #0
    6ab4:      	lsr	x16, x6, #0
    6ab8:      	cmp	x16, #0x1
    6abc:      	b.eq	0x6ad8 <_stogir.floating.validate+0x3e4>
    6ac0:      	b.lo	0x6ac8 <_stogir.floating.validate+0x3d4>
    6ac4:      	b	0x6adc <_stogir.floating.validate+0x3e8>
    6ac8:      	cmp	x16, #0x0
    6acc:      	b.eq	0x6ad4 <_stogir.floating.validate+0x3e0>
    6ad0:      	b	0x6adc <_stogir.floating.validate+0x3e8>
    6ad4:      	b	0x6ae0 <_stogir.floating.validate+0x3ec>
    6ad8:      	b	0x6afc <_stogir.floating.validate+0x408>
    6adc:      	b	0x6be0 <_stogir.floating.validate+0x4ec>
    6ae0:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		0000000000006ae0:  ARM64_RELOC_PAGE21	l_stogir.412
    6ae4:      	ldr	x16, [x16]
		0000000000006ae4:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    6ae8:      	orr	x0, x16, xzr
    6aec:      	mov	x19, x8
    6af0:      	mov	x1, #0x1                ; =1
    6af4:      	mov	x2, #0x18               ; =24
    6af8:      	b	0x6a18 <_stogir.floating.validate+0x324>
    6afc:      	lsr	w2, w2, #0
    6b00:      	add	x16, sp, #0x10
    6b04:      	ldr	w6, [x16]
    6b08:      	ubfx	x2, x2, #8, #8
    6b0c:      	uxtb	w16, w3
    6b10:      	cmp	w16, wzr
    6b14:      	b.eq	0x6b8c <_stogir.floating.validate+0x498>
    6b18:      	uxtb	w16, w5
    6b1c:      	cmp	w16, wzr
    6b20:      	b.eq	0x6b8c <_stogir.floating.validate+0x498>
    6b24:      	mov	x3, #0x1                ; =1
    6b28:      	b	0x6b90 <_stogir.floating.validate+0x49c>
    6b2c:      	movz	x7, #0x0, lsl #48
    6b30:      	b	0x6a70 <_stogir.floating.validate+0x37c>
    6b34:      	movz	x7, #0x0, lsl #48
    6b38:      	b	0x6a68 <_stogir.floating.validate+0x374>
    6b3c:      	movz	x1, #0x0, lsl #48
    6b40:      	lsr	w3, w3, #0
    6b44:      	lsr	w5, w5, #0
    6b48:      	lsr	w4, w4, #0
    6b4c:      	lsr	w2, w2, #0
    6b50:      	lsr	w1, w1, #0
    6b54:      	mov	x19, x8
    6b58:      	add	x8, sp, #0x20
    6b5c:      	fmov	s31, w1
    6b60:      	mov	w1, w4
    6b64:      	mov	w4, w5
    6b68:      	fmov	w5, s31
    6b6c:      	bl	0x6b6c <_stogir.floating.validate+0x478>
		0000000000006b6c:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    6b70:      	add	x16, sp, #0x20
    6b74:      	ldr	x1, [x16]
    6b78:      	add	x16, sp, #0x20
    6b7c:      	ldr	x0, [x16, #0x8]
    6b80:      	add	x16, sp, #0x20
    6b84:      	ldr	x2, [x16, #0x10]
    6b88:      	b	0x6a18 <_stogir.floating.validate+0x324>
    6b8c:      	orr	x3, x2, xzr
    6b90:      	lsr	w3, w3, #0
    6b94:      	ubfx	x5, x6, #8, #8
    6b98:      	sxtw	x3, w3
    6b9c:      	cmp	x5, x3
    6ba0:      	b.ne	0x6bf0 <_stogir.floating.validate+0x4fc>
    6ba4:      	add	x16, sp, #0x10
    6ba8:      	ldr	w3, [x16, #0x4]
    6bac:      	add	x16, sp, #0x10
    6bb0:      	ldr	w5, [x16, #0x8]
    6bb4:      	uxtb	w16, w1
    6bb8:      	cmp	w16, wzr
    6bbc:      	b.eq	0x6b3c <_stogir.floating.validate+0x448>
    6bc0:      	add	x16, sp, #0x10
    6bc4:      	ldr	w1, [x16, #0xc]
    6bc8:      	sxtw	x1, w1
    6bcc:      	b	0x6b40 <_stogir.floating.validate+0x44c>
    6bd0:      	movz	x7, #0x0, lsl #48
    6bd4:      	b	0x6b30 <_stogir.floating.validate+0x43c>
    6bd8:      	brk	#0
    6bdc:      	b	0x6bd8 <_stogir.floating.validate+0x4e4>
    6be0:      	brk	#0
    6be4:      	b	0x6be0 <_stogir.floating.validate+0x4ec>
    6be8:      	mov	x19, x8
    6bec:      	b	0x6898 <_stogir.floating.validate+0x1a4>
    6bf0:      	mov	x19, x8
    6bf4:      	b	0x6a04 <_stogir.floating.validate+0x310>

0000000000006bf8 <_stogir.types.integer?>:
    6bf8:      	sxtw	x0, w0
    6bfc:      	cmp	x0, #0x1
    6c00:      	b.lt	0x6c14 <_stogir.types.integer?+0x1c>
    6c04:      	cmp	x0, #0xb
    6c08:      	cset	w0, le
    6c0c:      	ubfx	x0, x0, #0, #8
    6c10:      	b	0x6c18 <_stogir.types.integer?+0x20>
    6c14:      	movz	x0, #0x0, lsl #48
    6c18:      	ret

0000000000006c1c <_stogir.integer-unary.valid-type?>:
    6c1c:      	sxtw	x0, w0
    6c20:      	cmp	x0, #0x2d
    6c24:      	cset	w2, eq
    6c28:      	cmp	x0, #0x1f
    6c2c:      	cset	w3, eq
    6c30:      	cmp	x0, #0x20
    6c34:      	cset	w4, eq
    6c38:      	cmp	x0, #0x36
    6c3c:      	cset	w5, eq
    6c40:      	uxtb	w16, w3
    6c44:      	cmp	w16, wzr
    6c48:      	b.ne	0x6c90 <_stogir.integer-unary.valid-type?+0x74>
    6c4c:      	uxtb	w16, w4
    6c50:      	cmp	w16, wzr
    6c54:      	b.ne	0x6c90 <_stogir.integer-unary.valid-type?+0x74>
    6c58:      	uxtb	w16, w2
    6c5c:      	cmp	w16, wzr
    6c60:      	b.ne	0x6c90 <_stogir.integer-unary.valid-type?+0x74>
    6c64:      	uxtb	w16, w5
    6c68:      	cmp	w16, wzr
    6c6c:      	b.ne	0x6c90 <_stogir.integer-unary.valid-type?+0x74>
    6c70:      	cmp	x0, #0x37
    6c74:      	b.eq	0x6c90 <_stogir.integer-unary.valid-type?+0x74>
    6c78:      	cmp	x0, #0x38
    6c7c:      	b.eq	0x6c90 <_stogir.integer-unary.valid-type?+0x74>
    6c80:      	cmp	x0, #0x39
    6c84:      	b.eq	0x6c90 <_stogir.integer-unary.valid-type?+0x74>
    6c88:      	movz	x0, #0x0, lsl #48
    6c8c:      	b	0x6cc8 <_stogir.integer-unary.valid-type?+0xac>
    6c90:      	sxtw	x1, w1
    6c94:      	cmp	x1, #0x1
    6c98:      	b.lt	0x6cc4 <_stogir.integer-unary.valid-type?+0xa8>
    6c9c:      	cmp	x1, #0xb
    6ca0:      	cset	w0, le
    6ca4:      	uxtb	w16, w0
    6ca8:      	cmp	w16, wzr
    6cac:      	b.eq	0x6cc4 <_stogir.integer-unary.valid-type?+0xa8>
    6cb0:      	uxtb	w16, w2
    6cb4:      	cmp	w16, wzr
    6cb8:      	b.eq	0x6cd4 <_stogir.integer-unary.valid-type?+0xb8>
    6cbc:      	mov	x0, #0x1                ; =1
    6cc0:      	b	0x6cd0 <_stogir.integer-unary.valid-type?+0xb4>
    6cc4:      	movz	x0, #0x0, lsl #48
    6cc8:      	ret
    6ccc:      	mov	x0, #0x1                ; =1
    6cd0:      	b	0x6cc8 <_stogir.integer-unary.valid-type?+0xac>
    6cd4:      	cmp	x1, #0x1
    6cd8:      	b.ne	0x6ce4 <_stogir.integer-unary.valid-type?+0xc8>
    6cdc:      	movz	x0, #0x0, lsl #48
    6ce0:      	b	0x6cd0 <_stogir.integer-unary.valid-type?+0xb4>
    6ce4:      	cmp	x1, #0x6
    6ce8:      	cset	w2, eq
    6cec:      	uxtb	w16, w3
    6cf0:      	cmp	w16, wzr
    6cf4:      	b.eq	0x6d08 <_stogir.integer-unary.valid-type?+0xec>
    6cf8:      	uxtb	w16, w2
    6cfc:      	cmp	w16, wzr
    6d00:      	cset	x0, eq
    6d04:      	b	0x6cd0 <_stogir.integer-unary.valid-type?+0xb4>
    6d08:      	uxtb	w16, w4
    6d0c:      	cmp	w16, wzr
    6d10:      	b.eq	0x6d2c <_stogir.integer-unary.valid-type?+0x110>
    6d14:      	cmp	x1, #0x7
    6d18:      	b.lt	0x6d24 <_stogir.integer-unary.valid-type?+0x108>
    6d1c:      	ubfx	x0, x0, #0, #8
    6d20:      	b	0x6d28 <_stogir.integer-unary.valid-type?+0x10c>
    6d24:      	movz	x0, #0x0, lsl #48
    6d28:      	b	0x6cd0 <_stogir.integer-unary.valid-type?+0xb4>
    6d2c:      	uxtb	w16, w5
    6d30:      	cmp	w16, wzr
    6d34:      	b.eq	0x6ccc <_stogir.integer-unary.valid-type?+0xb0>
    6d38:      	cmp	x1, #0x3
    6d3c:      	b.ne	0x6d58 <_stogir.integer-unary.valid-type?+0x13c>
    6d40:      	mov	x0, #0x1                ; =1
    6d44:      	b	0x6d54 <_stogir.integer-unary.valid-type?+0x138>
    6d48:      	cmp	x1, #0xb
    6d4c:      	cset	w0, eq
    6d50:      	ubfx	x0, x0, #0, #8
    6d54:      	b	0x6cd0 <_stogir.integer-unary.valid-type?+0xb4>
    6d58:      	cmp	x1, #0x4
    6d5c:      	b.ne	0x6d68 <_stogir.integer-unary.valid-type?+0x14c>
    6d60:      	mov	x0, #0x1                ; =1
    6d64:      	b	0x6d54 <_stogir.integer-unary.valid-type?+0x138>
    6d68:      	cmp	x1, #0x5
    6d6c:      	b.ne	0x6d78 <_stogir.integer-unary.valid-type?+0x15c>
    6d70:      	mov	x0, #0x1                ; =1
    6d74:      	b	0x6d54 <_stogir.integer-unary.valid-type?+0x138>
    6d78:      	uxtb	w16, w2
    6d7c:      	cmp	w16, wzr
    6d80:      	b.eq	0x6d8c <_stogir.integer-unary.valid-type?+0x170>
    6d84:      	mov	x0, #0x1                ; =1
    6d88:      	b	0x6d54 <_stogir.integer-unary.valid-type?+0x138>
    6d8c:      	cmp	x1, #0x9
    6d90:      	b.ne	0x6d9c <_stogir.integer-unary.valid-type?+0x180>
    6d94:      	mov	x0, #0x1                ; =1
    6d98:      	b	0x6d54 <_stogir.integer-unary.valid-type?+0x138>
    6d9c:      	cmp	x1, #0xa
    6da0:      	b.ne	0x6d48 <_stogir.integer-unary.valid-type?+0x12c>
    6da4:      	mov	x0, #0x1                ; =1
    6da8:      	b	0x6d54 <_stogir.integer-unary.valid-type?+0x138>

0000000000006dac <_stogir.integer-binary.valid-type?>:
    6dac:      	sxtw	x0, w0
    6db0:      	cmp	x0, #0x3a
    6db4:      	cset	w2, eq
    6db8:      	cmp	x0, #0x3b
    6dbc:      	cset	w3, eq
    6dc0:      	cmp	x0, #0x1a
    6dc4:      	b.lt	0x6e18 <_stogir.integer-binary.valid-type?+0x6c>
    6dc8:      	cmp	x0, #0x1e
    6dcc:      	b.gt	0x6e18 <_stogir.integer-binary.valid-type?+0x6c>
    6dd0:      	sxtw	x1, w1
    6dd4:      	cmp	x1, #0x1
    6dd8:      	b.lt	0x6e48 <_stogir.integer-binary.valid-type?+0x9c>
    6ddc:      	cmp	x1, #0xb
    6de0:      	b.gt	0x6e48 <_stogir.integer-binary.valid-type?+0x9c>
    6de4:      	cmp	x1, #0x1
    6de8:      	b.ne	0x6e50 <_stogir.integer-binary.valid-type?+0xa4>
    6dec:      	cmp	x0, #0x2e
    6df0:      	b.eq	0x6e58 <_stogir.integer-binary.valid-type?+0xac>
    6df4:      	cmp	x0, #0x2f
    6df8:      	b.eq	0x6e58 <_stogir.integer-binary.valid-type?+0xac>
    6dfc:      	cmp	x0, #0x30
    6e00:      	b.eq	0x6e58 <_stogir.integer-binary.valid-type?+0xac>
    6e04:      	uxtb	w16, w2
    6e08:      	cmp	w16, wzr
    6e0c:      	b.eq	0x6e60 <_stogir.integer-binary.valid-type?+0xb4>
    6e10:      	mov	x0, #0x1                ; =1
    6e14:      	b	0x6e64 <_stogir.integer-binary.valid-type?+0xb8>
    6e18:      	cmp	x0, #0x2e
    6e1c:      	b.lt	0x6e28 <_stogir.integer-binary.valid-type?+0x7c>
    6e20:      	cmp	x0, #0x35
    6e24:      	b.le	0x6dd0 <_stogir.integer-binary.valid-type?+0x24>
    6e28:      	uxtb	w16, w2
    6e2c:      	cmp	w16, wzr
    6e30:      	b.ne	0x6dd0 <_stogir.integer-binary.valid-type?+0x24>
    6e34:      	uxtb	w16, w3
    6e38:      	cmp	w16, wzr
    6e3c:      	b.ne	0x6dd0 <_stogir.integer-binary.valid-type?+0x24>
    6e40:      	movz	x0, #0x0, lsl #48
    6e44:      	b	0x6e4c <_stogir.integer-binary.valid-type?+0xa0>
    6e48:      	movz	x0, #0x0, lsl #48
    6e4c:      	ret
    6e50:      	mov	x0, #0x1                ; =1
    6e54:      	b	0x6e4c <_stogir.integer-binary.valid-type?+0xa0>
    6e58:      	mov	x0, #0x1                ; =1
    6e5c:      	b	0x6e54 <_stogir.integer-binary.valid-type?+0xa8>
    6e60:      	ubfx	x0, x3, #0, #8
    6e64:      	b	0x6e5c <_stogir.integer-binary.valid-type?+0xb0>

0000000000006e68 <_coil.core.Len$slice$len__u8>:
    6e68:      	mov	x0, x1
    6e6c:      	ret

0000000000006e70 <_inherent$slice$data__u8>:
    6e70:      	ret

0000000000006e74 <_coil.mem.eql__u8>:
    6e74:      	sub	sp, sp, #0x10
    6e78:      	str	x29, [sp]
    6e7c:      	str	x30, [sp, #0x8]
    6e80:      	mov	x29, sp
    6e84:      	cmp	x2, #0x0
    6e88:      	b.ne	0x6e94 <_coil.mem.eql__u8+0x20>
    6e8c:      	mov	x0, #0x1                ; =1
    6e90:      	b	0x6eb0 <_coil.mem.eql__u8+0x3c>
    6e94:      	lsr	x2, x2, #0
    6e98:      	bl	0x6e98 <_coil.mem.eql__u8+0x24>
		0000000000006e98:  ARM64_RELOC_BRANCH26	_memcmp
    6e9c:      	lsr	w0, w0, #0
    6ea0:      	sxtw	x0, w0
    6ea4:      	cmp	x0, #0x0
    6ea8:      	cset	w0, eq
    6eac:      	ubfx	x0, x0, #0, #8
    6eb0:      	ldr	x29, [sp]
    6eb4:      	ldr	x30, [sp, #0x8]
    6eb8:      	add	sp, sp, #0x10
    6ebc:      	ret

0000000000006ec0 <_stogir.opcode.count>:
    6ec0:      	mov	x0, #0x83               ; =131
    6ec4:      	ret

0000000000006ec8 <_stogir.types.valid-scalar?>:
    6ec8:      	sxtw	x0, w0
    6ecc:      	cmp	x0, #0x0
    6ed0:      	b.lt	0x6ee4 <_stogir.types.valid-scalar?+0x1c>
    6ed4:      	cmp	x0, #0xd
    6ed8:      	cset	w0, le
    6edc:      	ubfx	x0, x0, #0, #8
    6ee0:      	b	0x6ee8 <_stogir.types.valid-scalar?+0x20>
    6ee4:      	movz	x0, #0x0, lsl #48
    6ee8:      	ret

0000000000006eec <_stogir.types.vector?>:
    6eec:      	sxtw	x0, w0
    6ef0:      	cmp	x0, #0xf
    6ef4:      	b.le	0x6f30 <_stogir.types.vector?+0x44>
    6ef8:      	cmp	x0, #0x80
    6efc:      	b.ge	0x6f40 <_stogir.types.vector?+0x54>
    6f00:      	and	x1, x0, #0xf
    6f04:      	lsr	w1, w1, #0
    6f08:      	sxtw	x1, w1
    6f0c:      	cmp	x1, #0x1
    6f10:      	b.lt	0x6f38 <_stogir.types.vector?+0x4c>
    6f14:      	and	x0, x0, #0xf
    6f18:      	lsr	w0, w0, #0
    6f1c:      	sxtw	x0, w0
    6f20:      	cmp	x0, #0xd
    6f24:      	cset	w0, le
    6f28:      	ubfx	x0, x0, #0, #8
    6f2c:      	b	0x6f3c <_stogir.types.vector?+0x50>
    6f30:      	movz	x0, #0x0, lsl #48
    6f34:      	b	0x6f3c <_stogir.types.vector?+0x50>
    6f38:      	movz	x0, #0x0, lsl #48
    6f3c:      	ret
    6f40:      	movz	x0, #0x0, lsl #48
    6f44:      	b	0x6f3c <_stogir.types.vector?+0x50>

0000000000006f48 <_coil.core.Get$slice$get__i8>:
    6f48:      	add	x0, x0, x2
    6f4c:      	ldrsb	w0, [x0]
    6f50:      	sxtb	x0, w0
    6f54:      	ret

0000000000006f58 <_stogir.opcode.metadata>:
    6f58:      	sub	sp, sp, #0x10
    6f5c:      	mov	x0, sp
    6f60:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x6d0>
		0000000000006f60:  ARM64_RELOC_PAGE21	l_stogir.413
    6f64:      	ldr	x16, [x16]
		0000000000006f64:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    6f68:      	orr	x1, x16, xzr
    6f6c:      	str	x1, [x0]
    6f70:      	mov	x17, #0x83              ; =131
    6f74:      	str	x17, [x0, #0x8]
    6f78:      	ldr	x0, [sp]
    6f7c:      	ldr	x1, [sp, #0x8]
    6f80:      	add	sp, sp, #0x10
    6f84:      	ret

0000000000006f88 <_coil.core.Get$slice$get__u32>:
    6f88:      	add	x0, x0, x2, lsl #2
    6f8c:      	ldr	w0, [x0]
    6f90:      	ret

0000000000006f94 <_stogir.opcode.operand-code-word>:
    6f94:      	sxtw	x1, w1
    6f98:      	cmp	x1, #0x0
    6f9c:      	b.le	0x6fb0 <_stogir.opcode.operand-code-word+0x1c>
    6fa0:      	cmp	x1, #0x4
    6fa4:      	b.le	0x6fb8 <_stogir.opcode.operand-code-word+0x24>
    6fa8:      	mov	x1, #0x4                ; =4
    6fac:      	b	0x6fc4 <_stogir.opcode.operand-code-word+0x30>
    6fb0:      	movz	x0, #0x0, lsl #48
    6fb4:      	b	0x6fe4 <_stogir.opcode.operand-code-word+0x50>
    6fb8:      	sub	x1, x1, #0x1
    6fbc:      	lsr	w1, w1, #0
    6fc0:      	sxtw	x1, w1
    6fc4:      	ubfx	x0, x0, #0, #32
    6fc8:      	lsl	x1, x1, #2
    6fcc:      	lsr	w1, w1, #0
    6fd0:      	ubfx	x1, x1, #0, #32
    6fd4:      	lsr	x0, x0, x1
    6fd8:      	lsr	w0, w0, #0
    6fdc:      	and	x0, x0, #0xf
    6fe0:      	lsr	w0, w0, #0
    6fe4:      	ret

0000000000006fe8 <_inherent$coil.arraylist.ArrayList$at__stogir.node.Node>:
    6fe8:      	ldr	x0, [x0]
    6fec:      	add	x0, x0, x1, lsl #4
    6ff0:      	ret

0000000000006ff4 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.strings.Entry>:
    6ff4:      	ldr	x0, [x0, #0x8]
    6ff8:      	ret

0000000000006ffc <_coil.core.Len$coil.arraylist.ArrayList$len__u8>:
    6ffc:      	ldr	x0, [x0, #0x8]
    7000:      	ret

0000000000007004 <_inherent$coil.arraylist.ArrayList$slice__u8>:
    7004:      	sub	sp, sp, #0x10
    7008:      	mov	x1, sp
    700c:      	ldr	x2, [x0]
    7010:      	ldr	x0, [x0, #0x8]
    7014:      	str	x2, [x1]
    7018:      	str	x0, [x1, #0x8]
    701c:      	ldr	x0, [sp]
    7020:      	ldr	x1, [sp, #0x8]
    7024:      	add	sp, sp, #0x10
    7028:      	ret

000000000000702c <_coil.slice.subslice__u8>:
    702c:      	sub	sp, sp, #0x10
    7030:      	mov	x1, sp
    7034:      	sub	x3, x3, x2
    7038:      	add	x0, x0, x2
    703c:      	str	x0, [x1]
    7040:      	str	x3, [x1, #0x8]
    7044:      	ldr	x0, [sp]
    7048:      	ldr	x1, [sp, #0x8]
    704c:      	add	sp, sp, #0x10
    7050:      	ret

0000000000007054 <_stogir.floating.operation?>:
    7054:      	sxtw	x0, w0
    7058:      	cmp	x0, #0xe
    705c:      	b.lt	0x7070 <_stogir.floating.operation?+0x1c>
    7060:      	cmp	x0, #0x19
    7064:      	b.gt	0x7070 <_stogir.floating.operation?+0x1c>
    7068:      	mov	x0, #0x1                ; =1
    706c:      	b	0x709c <_stogir.floating.operation?+0x48>
    7070:      	cmp	x0, #0x1f
    7074:      	b.eq	0x7098 <_stogir.floating.operation?+0x44>
    7078:      	cmp	x0, #0x20
    707c:      	b.eq	0x7098 <_stogir.floating.operation?+0x44>
    7080:      	cmp	x0, #0x1a
    7084:      	b.lt	0x70b0 <_stogir.floating.operation?+0x5c>
    7088:      	cmp	x0, #0x1d
    708c:      	b.gt	0x70b0 <_stogir.floating.operation?+0x5c>
    7090:      	mov	x0, #0x1                ; =1
    7094:      	b	0x70ac <_stogir.floating.operation?+0x58>
    7098:      	mov	x0, #0x1                ; =1
    709c:      	ret
    70a0:      	cmp	x0, #0x3b
    70a4:      	cset	w0, eq
    70a8:      	ubfx	x0, x0, #0, #8
    70ac:      	b	0x709c <_stogir.floating.operation?+0x48>
    70b0:      	cmp	x0, #0x3a
    70b4:      	b.ne	0x70a0 <_stogir.floating.operation?+0x4c>
    70b8:      	mov	x0, #0x1                ; =1
    70bc:      	b	0x70ac <_stogir.floating.operation?+0x58>

00000000000070c0 <_stogir.types.floating?>:
    70c0:      	sxtw	x0, w0
    70c4:      	cmp	x0, #0xc
    70c8:      	b.ne	0x70d4 <_stogir.types.floating?+0x14>
    70cc:      	mov	x0, #0x1                ; =1
    70d0:      	b	0x70e0 <_stogir.types.floating?+0x20>
    70d4:      	cmp	x0, #0xd
    70d8:      	cset	w0, eq
    70dc:      	ubfx	x0, x0, #0, #8
    70e0:      	ret

00000000000070e4 <_stogir.vector-lanes.validate>:
    70e4:      	sub	sp, sp, #0x50
    70e8:      	str	x29, [sp]
    70ec:      	str	x30, [sp, #0x8]
    70f0:      	mov	x29, sp
    70f4:      	str	x19, [sp, #0x40]
    70f8:      	sxtw	x1, w1
    70fc:      	lsl	x3, x1, #2
    7100:      	cmp	x1, #0x0
    7104:      	cset	w4, gt
    7108:      	movz	x16, #0x0, lsl #48
    710c:      	sub	x5, x16, x1
    7110:      	sub	x6, x5, #0x1
    7114:      	uxtb	w16, w4
    7118:      	cmp	w16, wzr
    711c:      	b.eq	0x715c <_stogir.vector-lanes.validate+0x78>
    7120:      	ldr	x5, [x0, #0x8]
    7124:      	cmp	x1, x5
    7128:      	b.ge	0x71ac <_stogir.vector-lanes.validate+0xc8>
    712c:      	add	x5, x0, #0x78
    7130:      	ldr	x5, [x5, #0x8]
    7134:      	cmp	x1, x5
    7138:      	b.ge	0x72a0 <_stogir.vector-lanes.validate+0x1bc>
    713c:      	ldr	x5, [x0, #0x78]
    7140:      	add	x5, x3, x5
    7144:      	ldr	w5, [x5]
    7148:      	sxtw	x5, w5
    714c:      	cmp	x5, #0x0
    7150:      	cset	w5, ge
    7154:      	ubfx	x5, x5, #0, #8
    7158:      	b	0x72a4 <_stogir.vector-lanes.validate+0x1c0>
    715c:      	cmp	x1, #0x0
    7160:      	b.ge	0x71b4 <_stogir.vector-lanes.validate+0xd0>
    7164:      	add	x7, x0, #0x28
    7168:      	add	x9, x0, #0x50
    716c:      	ldr	x7, [x7, #0x8]
    7170:      	ldr	x9, [x9, #0x8]
    7174:      	cmp	x7, x9
    7178:      	b.ne	0x71a4 <_stogir.vector-lanes.validate+0xc0>
    717c:      	cmp	x5, x7
    7180:      	b.gt	0x72e4 <_stogir.vector-lanes.validate+0x200>
    7184:      	ldr	x5, [x0, #0x50]
    7188:      	add	x5, x5, x6, lsl #2
    718c:      	ldr	w5, [x5]
    7190:      	sxtw	x5, w5
    7194:      	cmp	x5, #0x0
    7198:      	cset	w5, gt
    719c:      	ubfx	x5, x5, #0, #8
    71a0:      	b	0x72e8 <_stogir.vector-lanes.validate+0x204>
    71a4:      	movz	x5, #0x0, lsl #48
    71a8:      	b	0x71b8 <_stogir.vector-lanes.validate+0xd4>
    71ac:      	movz	x5, #0x0, lsl #48
    71b0:      	b	0x71b8 <_stogir.vector-lanes.validate+0xd4>
    71b4:      	movz	x5, #0x0, lsl #48
    71b8:      	cmp	x5, #0x0
    71bc:      	b.eq	0x71f8 <_stogir.vector-lanes.validate+0x114>
    71c0:      	uxtb	w16, w4
    71c4:      	cmp	w16, wzr
    71c8:      	b.eq	0x71e0 <_stogir.vector-lanes.validate+0xfc>
    71cc:      	ldr	x4, [x0]
    71d0:      	add	x4, x4, x1, lsl #4
    71d4:      	ldr	x5, [x4]
    71d8:      	ldr	x4, [x4, #0x8]
    71dc:      	b	0x71f0 <_stogir.vector-lanes.validate+0x10c>
    71e0:      	ldr	x4, [x0, #0x28]
    71e4:      	add	x4, x4, x6, lsl #4
    71e8:      	ldr	x5, [x4]
    71ec:      	ldr	x4, [x4, #0x8]
    71f0:      	mov	x6, #0x1                ; =1
    71f4:      	b	0x7204 <_stogir.vector-lanes.validate+0x120>
    71f8:      	movz	x6, #0x0, lsl #48
    71fc:      	movz	x5, #0x0, lsl #48
    7200:      	movz	x4, #0x0, lsl #48
    7204:      	lsr	w6, w6, #0
    7208:      	lsr	x16, x6, #0
    720c:      	cmp	x16, #0x1
    7210:      	b.eq	0x722c <_stogir.vector-lanes.validate+0x148>
    7214:      	b.lo	0x721c <_stogir.vector-lanes.validate+0x138>
    7218:      	b	0x7230 <_stogir.vector-lanes.validate+0x14c>
    721c:      	cmp	x16, #0x0
    7220:      	b.eq	0x7228 <_stogir.vector-lanes.validate+0x144>
    7224:      	b	0x7230 <_stogir.vector-lanes.validate+0x14c>
    7228:      	b	0x7234 <_stogir.vector-lanes.validate+0x150>
    722c:      	b	0x7250 <_stogir.vector-lanes.validate+0x16c>
    7230:      	b	0x73c8 <_stogir.vector-lanes.validate+0x2e4>
    7234:      	adrp	x16, 0x7000 <_coil.core.Len$coil.arraylist.ArrayList$len__u8+0x4>
		0000000000007234:  ARM64_RELOC_PAGE21	l_stogir.414
    7238:      	ldr	x16, [x16]
		0000000000007238:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    723c:      	orr	x0, x16, xzr
    7240:      	mov	x19, x8
    7244:      	mov	x1, #0x1                ; =1
    7248:      	mov	x2, #0x1f               ; =31
    724c:      	b	0x7280 <_stogir.vector-lanes.validate+0x19c>
    7250:      	add	x16, sp, #0x10
    7254:      	str	x5, [x16]
    7258:      	add	x16, sp, #0x10
    725c:      	str	x4, [x16, #0x8]
    7260:      	cmp	x1, #0x0
    7264:      	b.gt	0x72a8 <_stogir.vector-lanes.validate+0x1c4>
    7268:      	mov	x19, x8
    726c:      	adrp	x16, 0x7000 <_coil.core.Len$coil.arraylist.ArrayList$len__u8+0x4>
		000000000000726c:  ARM64_RELOC_PAGE21	l_stogir.415
    7270:      	ldr	x16, [x16]
		0000000000007270:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    7274:      	orr	x0, x16, xzr
    7278:      	mov	x1, #0x1                ; =1
    727c:      	mov	x2, #0x25               ; =37
    7280:      	str	x1, [x19]
    7284:      	str	x0, [x19, #0x8]
    7288:      	str	x2, [x19, #0x10]
    728c:      	ldr	x19, [sp, #0x40]
    7290:      	ldr	x29, [sp]
    7294:      	ldr	x30, [sp, #0x8]
    7298:      	add	sp, sp, #0x50
    729c:      	ret
    72a0:      	movz	x5, #0x0, lsl #48
    72a4:      	b	0x71b0 <_stogir.vector-lanes.validate+0xcc>
    72a8:      	uxtb	w5, w5
    72ac:      	orr	x1, x5, xzr
    72b0:      	cmp	x1, #0x3d
    72b4:      	b.lt	0x73d0 <_stogir.vector-lanes.validate+0x2ec>
    72b8:      	cmp	x1, #0x3f
    72bc:      	b.gt	0x73d8 <_stogir.vector-lanes.validate+0x2f4>
    72c0:      	cmp	x1, #0x3e
    72c4:      	cset	w4, eq
    72c8:      	ldr	x6, [x0, #0x78]
    72cc:      	add	x3, x3, x6
    72d0:      	ldr	w3, [x3]
    72d4:      	cmp	x1, #0x3d
    72d8:      	b.ne	0x7358 <_stogir.vector-lanes.validate+0x274>
    72dc:      	mov	x6, #0x2                ; =2
    72e0:      	b	0x736c <_stogir.vector-lanes.validate+0x288>
    72e4:      	movz	x5, #0x0, lsl #48
    72e8:      	b	0x71a8 <_stogir.vector-lanes.validate+0xc4>
    72ec:      	movz	x4, #0x0, lsl #48
    72f0:      	lsr	w2, w2, #0
    72f4:      	lsr	w6, w6, #0
    72f8:      	lsr	w1, w1, #0
    72fc:      	lsr	w5, w5, #0
    7300:      	lsr	w4, w4, #0
    7304:      	ubfx	x3, x3, #8, #8
    7308:      	lsr	w3, w3, #0
    730c:      	mov	x19, x8
    7310:      	add	x8, sp, #0x20
    7314:      	fmov	s31, w1
    7318:      	mov	w1, w5
    731c:      	fmov	w5, s31
    7320:      	fmov	s31, w2
    7324:      	mov	w2, w3
    7328:      	fmov	w3, s31
    732c:      	fmov	s31, w4
    7330:      	mov	w4, w6
    7334:      	fmov	w6, s31
    7338:      	bl	0x7338 <_stogir.vector-lanes.validate+0x254>
		0000000000007338:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    733c:      	add	x16, sp, #0x20
    7340:      	ldr	x1, [x16]
    7344:      	add	x16, sp, #0x20
    7348:      	ldr	x0, [x16, #0x8]
    734c:      	add	x16, sp, #0x20
    7350:      	ldr	x2, [x16, #0x10]
    7354:      	b	0x7280 <_stogir.vector-lanes.validate+0x19c>
    7358:      	uxtb	w16, w4
    735c:      	cmp	w16, wzr
    7360:      	mov	x16, #0x3               ; =3
    7364:      	mov	x17, #0x1               ; =1
    7368:      	csel	x6, x16, x17, ne
    736c:      	sxtw	x3, w3
    7370:      	lsr	w6, w6, #0
    7374:      	sxtw	x6, w6
    7378:      	cmp	x3, x6
    737c:      	b.ne	0x73e0 <_stogir.vector-lanes.validate+0x2fc>
    7380:      	add	x16, sp, #0x10
    7384:      	ldr	w3, [x16]
    7388:      	add	x16, sp, #0x10
    738c:      	ldr	w6, [x16, #0x4]
    7390:      	cmp	x1, #0x3f
    7394:      	b.ne	0x73a0 <_stogir.vector-lanes.validate+0x2bc>
    7398:      	movz	x1, #0x0, lsl #48
    739c:      	b	0x73ac <_stogir.vector-lanes.validate+0x2c8>
    73a0:      	add	x16, sp, #0x10
    73a4:      	ldr	w1, [x16, #0x8]
    73a8:      	sxtw	x1, w1
    73ac:      	uxtb	w16, w4
    73b0:      	cmp	w16, wzr
    73b4:      	b.eq	0x72ec <_stogir.vector-lanes.validate+0x208>
    73b8:      	add	x16, sp, #0x10
    73bc:      	ldr	w4, [x16, #0xc]
    73c0:      	sxtw	x4, w4
    73c4:      	b	0x72f0 <_stogir.vector-lanes.validate+0x20c>
    73c8:      	brk	#0
    73cc:      	b	0x73c8 <_stogir.vector-lanes.validate+0x2e4>
    73d0:      	mov	x19, x8
    73d4:      	b	0x726c <_stogir.vector-lanes.validate+0x188>
    73d8:      	mov	x19, x8
    73dc:      	b	0x726c <_stogir.vector-lanes.validate+0x188>
    73e0:      	mov	x19, x8
    73e4:      	b	0x726c <_stogir.vector-lanes.validate+0x188>

00000000000073e8 <_stogir.vector-comparison.node?>:
    73e8:      	sxtw	x1, w1
    73ec:      	cmp	x1, #0x0
    73f0:      	cset	w2, gt
    73f4:      	movz	x16, #0x0, lsl #48
    73f8:      	sub	x3, x16, x1
    73fc:      	sub	x4, x3, #0x1
    7400:      	uxtb	w16, w2
    7404:      	cmp	w16, wzr
    7408:      	b.eq	0x7448 <_stogir.vector-comparison.node?+0x60>
    740c:      	ldr	x3, [x0, #0x8]
    7410:      	cmp	x1, x3
    7414:      	b.ge	0x7498 <_stogir.vector-comparison.node?+0xb0>
    7418:      	add	x3, x0, #0x78
    741c:      	ldr	x3, [x3, #0x8]
    7420:      	cmp	x1, x3
    7424:      	b.ge	0x7574 <_stogir.vector-comparison.node?+0x18c>
    7428:      	ldr	x3, [x0, #0x78]
    742c:      	add	x3, x3, x1, lsl #2
    7430:      	ldr	w3, [x3]
    7434:      	sxtw	x3, w3
    7438:      	cmp	x3, #0x0
    743c:      	cset	w3, ge
    7440:      	ubfx	x3, x3, #0, #8
    7444:      	b	0x7578 <_stogir.vector-comparison.node?+0x190>
    7448:      	cmp	x1, #0x0
    744c:      	b.ge	0x74a0 <_stogir.vector-comparison.node?+0xb8>
    7450:      	add	x5, x0, #0x28
    7454:      	add	x6, x0, #0x50
    7458:      	ldr	x5, [x5, #0x8]
    745c:      	ldr	x6, [x6, #0x8]
    7460:      	cmp	x5, x6
    7464:      	b.ne	0x7490 <_stogir.vector-comparison.node?+0xa8>
    7468:      	cmp	x3, x5
    746c:      	b.gt	0x757c <_stogir.vector-comparison.node?+0x194>
    7470:      	ldr	x3, [x0, #0x50]
    7474:      	add	x3, x3, x4, lsl #2
    7478:      	ldr	w3, [x3]
    747c:      	sxtw	x3, w3
    7480:      	cmp	x3, #0x0
    7484:      	cset	w3, gt
    7488:      	ubfx	x3, x3, #0, #8
    748c:      	b	0x7580 <_stogir.vector-comparison.node?+0x198>
    7490:      	movz	x3, #0x0, lsl #48
    7494:      	b	0x74a4 <_stogir.vector-comparison.node?+0xbc>
    7498:      	movz	x3, #0x0, lsl #48
    749c:      	b	0x74a4 <_stogir.vector-comparison.node?+0xbc>
    74a0:      	movz	x3, #0x0, lsl #48
    74a4:      	cmp	x3, #0x0
    74a8:      	b.eq	0x74dc <_stogir.vector-comparison.node?+0xf4>
    74ac:      	uxtb	w16, w2
    74b0:      	cmp	w16, wzr
    74b4:      	b.eq	0x74c8 <_stogir.vector-comparison.node?+0xe0>
    74b8:      	ldr	x0, [x0]
    74bc:      	add	x0, x0, x1, lsl #4
    74c0:      	ldr	x0, [x0]
    74c4:      	b	0x74d4 <_stogir.vector-comparison.node?+0xec>
    74c8:      	ldr	x0, [x0, #0x28]
    74cc:      	add	x0, x0, x4, lsl #4
    74d0:      	ldr	x0, [x0]
    74d4:      	mov	x1, #0x1                ; =1
    74d8:      	b	0x74e4 <_stogir.vector-comparison.node?+0xfc>
    74dc:      	movz	x1, #0x0, lsl #48
    74e0:      	movz	x0, #0x0, lsl #48
    74e4:      	lsr	w1, w1, #0
    74e8:      	lsr	x16, x1, #0
    74ec:      	cmp	x16, #0x1
    74f0:      	b.eq	0x750c <_stogir.vector-comparison.node?+0x124>
    74f4:      	b.lo	0x74fc <_stogir.vector-comparison.node?+0x114>
    74f8:      	b	0x7510 <_stogir.vector-comparison.node?+0x128>
    74fc:      	cmp	x16, #0x0
    7500:      	b.eq	0x7508 <_stogir.vector-comparison.node?+0x120>
    7504:      	b	0x7510 <_stogir.vector-comparison.node?+0x128>
    7508:      	b	0x7514 <_stogir.vector-comparison.node?+0x12c>
    750c:      	b	0x7524 <_stogir.vector-comparison.node?+0x13c>
    7510:      	b	0x759c <_stogir.vector-comparison.node?+0x1b4>
    7514:      	movz	x0, #0x0, lsl #48
    7518:      	b	0x7520 <_stogir.vector-comparison.node?+0x138>
    751c:      	movz	x0, #0x0, lsl #48
    7520:      	ret
    7524:      	uxtb	w1, w0
    7528:      	cmp	x1, #0xe
    752c:      	b.lt	0x751c <_stogir.vector-comparison.node?+0x134>
    7530:      	cmp	x1, #0x19
    7534:      	b.gt	0x751c <_stogir.vector-comparison.node?+0x134>
    7538:      	lsr	w0, w0, #0
    753c:      	ubfx	x0, x0, #8, #8
    7540:      	cmp	x0, #0xf
    7544:      	b.le	0x7584 <_stogir.vector-comparison.node?+0x19c>
    7548:      	cmp	x0, #0x80
    754c:      	b.ge	0x758c <_stogir.vector-comparison.node?+0x1a4>
    7550:      	and	x0, x0, #0xf
    7554:      	lsr	w0, w0, #0
    7558:      	sxtw	x0, w0
    755c:      	cmp	x0, #0x1
    7560:      	b.lt	0x7594 <_stogir.vector-comparison.node?+0x1ac>
    7564:      	cmp	x0, #0xd
    7568:      	cset	w0, le
    756c:      	ubfx	x0, x0, #0, #8
    7570:      	b	0x7598 <_stogir.vector-comparison.node?+0x1b0>
    7574:      	movz	x3, #0x0, lsl #48
    7578:      	b	0x749c <_stogir.vector-comparison.node?+0xb4>
    757c:      	movz	x3, #0x0, lsl #48
    7580:      	b	0x7494 <_stogir.vector-comparison.node?+0xac>
    7584:      	movz	x0, #0x0, lsl #48
    7588:      	b	0x7520 <_stogir.vector-comparison.node?+0x138>
    758c:      	movz	x0, #0x0, lsl #48
    7590:      	b	0x7588 <_stogir.vector-comparison.node?+0x1a0>
    7594:      	movz	x0, #0x0, lsl #48
    7598:      	b	0x7590 <_stogir.vector-comparison.node?+0x1a8>
    759c:      	brk	#0
    75a0:      	b	0x759c <_stogir.vector-comparison.node?+0x1b4>

00000000000075a4 <_stogir.vector-comparison.validate>:
    75a4:      	sub	sp, sp, #0x50
    75a8:      	str	x29, [sp]
    75ac:      	str	x30, [sp, #0x8]
    75b0:      	mov	x29, sp
    75b4:      	str	x19, [sp, #0x40]
    75b8:      	sxtw	x1, w1
    75bc:      	lsl	x3, x1, #2
    75c0:      	cmp	x1, #0x0
    75c4:      	cset	w4, gt
    75c8:      	movz	x16, #0x0, lsl #48
    75cc:      	sub	x5, x16, x1
    75d0:      	sub	x6, x5, #0x1
    75d4:      	uxtb	w16, w4
    75d8:      	cmp	w16, wzr
    75dc:      	b.eq	0x761c <_stogir.vector-comparison.validate+0x78>
    75e0:      	ldr	x5, [x0, #0x8]
    75e4:      	cmp	x1, x5
    75e8:      	b.ge	0x766c <_stogir.vector-comparison.validate+0xc8>
    75ec:      	add	x5, x0, #0x78
    75f0:      	ldr	x5, [x5, #0x8]
    75f4:      	cmp	x1, x5
    75f8:      	b.ge	0x7764 <_stogir.vector-comparison.validate+0x1c0>
    75fc:      	ldr	x5, [x0, #0x78]
    7600:      	add	x5, x3, x5
    7604:      	ldr	w5, [x5]
    7608:      	sxtw	x5, w5
    760c:      	cmp	x5, #0x0
    7610:      	cset	w5, ge
    7614:      	ubfx	x5, x5, #0, #8
    7618:      	b	0x7768 <_stogir.vector-comparison.validate+0x1c4>
    761c:      	cmp	x1, #0x0
    7620:      	b.ge	0x7674 <_stogir.vector-comparison.validate+0xd0>
    7624:      	add	x7, x0, #0x28
    7628:      	add	x9, x0, #0x50
    762c:      	ldr	x7, [x7, #0x8]
    7630:      	ldr	x9, [x9, #0x8]
    7634:      	cmp	x7, x9
    7638:      	b.ne	0x7664 <_stogir.vector-comparison.validate+0xc0>
    763c:      	cmp	x5, x7
    7640:      	b.gt	0x77b4 <_stogir.vector-comparison.validate+0x210>
    7644:      	ldr	x5, [x0, #0x50]
    7648:      	add	x5, x5, x6, lsl #2
    764c:      	ldr	w5, [x5]
    7650:      	sxtw	x5, w5
    7654:      	cmp	x5, #0x0
    7658:      	cset	w5, gt
    765c:      	ubfx	x5, x5, #0, #8
    7660:      	b	0x77b8 <_stogir.vector-comparison.validate+0x214>
    7664:      	movz	x5, #0x0, lsl #48
    7668:      	b	0x7678 <_stogir.vector-comparison.validate+0xd4>
    766c:      	movz	x5, #0x0, lsl #48
    7670:      	b	0x7678 <_stogir.vector-comparison.validate+0xd4>
    7674:      	movz	x5, #0x0, lsl #48
    7678:      	lsl	x7, x1, #4
    767c:      	cmp	x5, #0x0
    7680:      	b.eq	0x76bc <_stogir.vector-comparison.validate+0x118>
    7684:      	uxtb	w16, w4
    7688:      	cmp	w16, wzr
    768c:      	b.eq	0x76a4 <_stogir.vector-comparison.validate+0x100>
    7690:      	ldr	x4, [x0]
    7694:      	add	x4, x7, x4
    7698:      	ldr	x5, [x4]
    769c:      	ldr	x4, [x4, #0x8]
    76a0:      	b	0x76b4 <_stogir.vector-comparison.validate+0x110>
    76a4:      	ldr	x4, [x0, #0x28]
    76a8:      	add	x4, x4, x6, lsl #4
    76ac:      	ldr	x5, [x4]
    76b0:      	ldr	x4, [x4, #0x8]
    76b4:      	mov	x6, #0x1                ; =1
    76b8:      	b	0x76c8 <_stogir.vector-comparison.validate+0x124>
    76bc:      	movz	x6, #0x0, lsl #48
    76c0:      	movz	x5, #0x0, lsl #48
    76c4:      	movz	x4, #0x0, lsl #48
    76c8:      	lsr	w6, w6, #0
    76cc:      	lsr	x16, x6, #0
    76d0:      	cmp	x16, #0x1
    76d4:      	b.eq	0x76f0 <_stogir.vector-comparison.validate+0x14c>
    76d8:      	b.lo	0x76e0 <_stogir.vector-comparison.validate+0x13c>
    76dc:      	b	0x76f4 <_stogir.vector-comparison.validate+0x150>
    76e0:      	cmp	x16, #0x0
    76e4:      	b.eq	0x76ec <_stogir.vector-comparison.validate+0x148>
    76e8:      	b	0x76f4 <_stogir.vector-comparison.validate+0x150>
    76ec:      	b	0x76f8 <_stogir.vector-comparison.validate+0x154>
    76f0:      	b	0x7730 <_stogir.vector-comparison.validate+0x18c>
    76f4:      	b	0x78c8 <_stogir.vector-comparison.validate+0x324>
    76f8:      	adrp	x16, 0x7000 <_coil.core.Len$coil.arraylist.ArrayList$len__u8+0x4>
		00000000000076f8:  ARM64_RELOC_PAGE21	l_stogir.416
    76fc:      	ldr	x16, [x16]
		00000000000076fc:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    7700:      	orr	x0, x16, xzr
    7704:      	mov	x19, x8
    7708:      	mov	x1, #0x1                ; =1
    770c:      	mov	x2, #0x25               ; =37
    7710:      	str	x1, [x19]
    7714:      	str	x0, [x19, #0x8]
    7718:      	str	x2, [x19, #0x10]
    771c:      	ldr	x19, [sp, #0x40]
    7720:      	ldr	x29, [sp]
    7724:      	ldr	x30, [sp, #0x8]
    7728:      	add	sp, sp, #0x50
    772c:      	ret
    7730:      	add	x16, sp, #0x10
    7734:      	str	x5, [x16]
    7738:      	add	x16, sp, #0x10
    773c:      	str	x4, [x16, #0x8]
    7740:      	cmp	x1, #0x0
    7744:      	b.gt	0x776c <_stogir.vector-comparison.validate+0x1c8>
    7748:      	mov	x19, x8
    774c:      	adrp	x16, 0x7000 <_coil.core.Len$coil.arraylist.ArrayList$len__u8+0x4>
		000000000000774c:  ARM64_RELOC_PAGE21	l_stogir.417
    7750:      	ldr	x16, [x16]
		0000000000007750:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    7754:      	orr	x0, x16, xzr
    7758:      	mov	x1, #0x1                ; =1
    775c:      	mov	x2, #0x2b               ; =43
    7760:      	b	0x7710 <_stogir.vector-comparison.validate+0x16c>
    7764:      	movz	x5, #0x0, lsl #48
    7768:      	b	0x7670 <_stogir.vector-comparison.validate+0xcc>
    776c:      	ldr	x4, [x0, #0x8]
    7770:      	cmp	x1, x4
    7774:      	b.ge	0x77bc <_stogir.vector-comparison.validate+0x218>
    7778:      	add	x4, x0, #0x78
    777c:      	ldr	x4, [x4, #0x8]
    7780:      	cmp	x1, x4
    7784:      	b.ge	0x77bc <_stogir.vector-comparison.validate+0x218>
    7788:      	ldr	x1, [x0, #0x78]
    778c:      	add	x1, x3, x1
    7790:      	ldr	w1, [x1]
    7794:      	sxtw	x1, w1
    7798:      	cmp	x1, #0x0
    779c:      	b.lt	0x77bc <_stogir.vector-comparison.validate+0x218>
    77a0:      	ldr	x1, [x0]
    77a4:      	add	x1, x7, x1
    77a8:      	ldr	x1, [x1]
    77ac:      	mov	x4, #0x1                ; =1
    77b0:      	b	0x77c4 <_stogir.vector-comparison.validate+0x220>
    77b4:      	movz	x5, #0x0, lsl #48
    77b8:      	b	0x7668 <_stogir.vector-comparison.validate+0xc4>
    77bc:      	movz	x4, #0x0, lsl #48
    77c0:      	movz	x1, #0x0, lsl #48
    77c4:      	lsr	w4, w4, #0
    77c8:      	lsr	x16, x4, #0
    77cc:      	cmp	x16, #0x1
    77d0:      	b.eq	0x77ec <_stogir.vector-comparison.validate+0x248>
    77d4:      	b.lo	0x77dc <_stogir.vector-comparison.validate+0x238>
    77d8:      	b	0x77f0 <_stogir.vector-comparison.validate+0x24c>
    77dc:      	cmp	x16, #0x0
    77e0:      	b.eq	0x77e8 <_stogir.vector-comparison.validate+0x244>
    77e4:      	b	0x77f0 <_stogir.vector-comparison.validate+0x24c>
    77e8:      	b	0x77f4 <_stogir.vector-comparison.validate+0x250>
    77ec:      	b	0x77fc <_stogir.vector-comparison.validate+0x258>
    77f0:      	b	0x78d0 <_stogir.vector-comparison.validate+0x32c>
    77f4:      	mov	x19, x8
    77f8:      	b	0x774c <_stogir.vector-comparison.validate+0x1a8>
    77fc:      	uxtb	w4, w1
    7800:      	cmp	x4, #0xe
    7804:      	b.lt	0x78d8 <_stogir.vector-comparison.validate+0x334>
    7808:      	cmp	x4, #0x19
    780c:      	b.gt	0x78e0 <_stogir.vector-comparison.validate+0x33c>
    7810:      	lsr	w1, w1, #0
    7814:      	ubfx	x1, x1, #8, #8
    7818:      	cmp	x1, #0xf
    781c:      	b.le	0x78e8 <_stogir.vector-comparison.validate+0x344>
    7820:      	cmp	x1, #0x80
    7824:      	b.ge	0x78f0 <_stogir.vector-comparison.validate+0x34c>
    7828:      	and	x1, x1, #0xf
    782c:      	lsr	w1, w1, #0
    7830:      	sxtw	x1, w1
    7834:      	cmp	x1, #0x1
    7838:      	b.lt	0x78f8 <_stogir.vector-comparison.validate+0x354>
    783c:      	cmp	x1, #0xd
    7840:      	b.gt	0x7900 <_stogir.vector-comparison.validate+0x35c>
    7844:      	ldr	x1, [x0, #0x78]
    7848:      	add	x1, x3, x1
    784c:      	ldr	w1, [x1]
    7850:      	sxtw	x1, w1
    7854:      	cmp	x1, #0x2
    7858:      	b.ne	0x7908 <_stogir.vector-comparison.validate+0x364>
    785c:      	lsr	w2, w2, #0
    7860:      	add	x16, sp, #0x10
    7864:      	ldr	w1, [x16]
    7868:      	uxtb	w3, w1
    786c:      	add	x16, sp, #0x10
    7870:      	ldr	w4, [x16, #0x4]
    7874:      	lsr	w3, w3, #0
    7878:      	ubfx	x1, x1, #8, #8
    787c:      	add	x16, sp, #0x10
    7880:      	ldr	w5, [x16, #0x8]
    7884:      	lsr	w4, w4, #0
    7888:      	lsr	w5, w5, #0
    788c:      	lsr	w1, w1, #0
    7890:      	mov	x19, x8
    7894:      	add	x8, sp, #0x20
    7898:      	fmov	s31, w1
    789c:      	mov	w1, w3
    78a0:      	mov	w3, w2
    78a4:      	fmov	w2, s31
    78a8:      	bl	0x78a8 <_stogir.vector-comparison.validate+0x304>
		00000000000078a8:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    78ac:      	add	x16, sp, #0x20
    78b0:      	ldr	x1, [x16]
    78b4:      	add	x16, sp, #0x20
    78b8:      	ldr	x0, [x16, #0x8]
    78bc:      	add	x16, sp, #0x20
    78c0:      	ldr	x2, [x16, #0x10]
    78c4:      	b	0x7760 <_stogir.vector-comparison.validate+0x1bc>
    78c8:      	brk	#0
    78cc:      	b	0x78c8 <_stogir.vector-comparison.validate+0x324>
    78d0:      	brk	#0
    78d4:      	b	0x78d0 <_stogir.vector-comparison.validate+0x32c>
    78d8:      	mov	x19, x8
    78dc:      	b	0x774c <_stogir.vector-comparison.validate+0x1a8>
    78e0:      	mov	x19, x8
    78e4:      	b	0x774c <_stogir.vector-comparison.validate+0x1a8>
    78e8:      	mov	x19, x8
    78ec:      	b	0x774c <_stogir.vector-comparison.validate+0x1a8>
    78f0:      	mov	x19, x8
    78f4:      	b	0x774c <_stogir.vector-comparison.validate+0x1a8>
    78f8:      	mov	x19, x8
    78fc:      	b	0x774c <_stogir.vector-comparison.validate+0x1a8>
    7900:      	mov	x19, x8
    7904:      	b	0x774c <_stogir.vector-comparison.validate+0x1a8>
    7908:      	mov	x19, x8
    790c:      	b	0x774c <_stogir.vector-comparison.validate+0x1a8>

0000000000007910 <_stogir.vector-arithmetic.node?>:
    7910:      	sxtw	x1, w1
    7914:      	cmp	x1, #0x0
    7918:      	cset	w2, gt
    791c:      	movz	x16, #0x0, lsl #48
    7920:      	sub	x3, x16, x1
    7924:      	sub	x4, x3, #0x1
    7928:      	uxtb	w16, w2
    792c:      	cmp	w16, wzr
    7930:      	b.eq	0x7970 <_stogir.vector-arithmetic.node?+0x60>
    7934:      	ldr	x3, [x0, #0x8]
    7938:      	cmp	x1, x3
    793c:      	b.ge	0x79c0 <_stogir.vector-arithmetic.node?+0xb0>
    7940:      	add	x3, x0, #0x78
    7944:      	ldr	x3, [x3, #0x8]
    7948:      	cmp	x1, x3
    794c:      	b.ge	0x7ae4 <_stogir.vector-arithmetic.node?+0x1d4>
    7950:      	ldr	x3, [x0, #0x78]
    7954:      	add	x3, x3, x1, lsl #2
    7958:      	ldr	w3, [x3]
    795c:      	sxtw	x3, w3
    7960:      	cmp	x3, #0x0
    7964:      	cset	w3, ge
    7968:      	ubfx	x3, x3, #0, #8
    796c:      	b	0x7ae8 <_stogir.vector-arithmetic.node?+0x1d8>
    7970:      	cmp	x1, #0x0
    7974:      	b.ge	0x79c8 <_stogir.vector-arithmetic.node?+0xb8>
    7978:      	add	x5, x0, #0x28
    797c:      	add	x6, x0, #0x50
    7980:      	ldr	x5, [x5, #0x8]
    7984:      	ldr	x6, [x6, #0x8]
    7988:      	cmp	x5, x6
    798c:      	b.ne	0x79b8 <_stogir.vector-arithmetic.node?+0xa8>
    7990:      	cmp	x3, x5
    7994:      	b.gt	0x7af4 <_stogir.vector-arithmetic.node?+0x1e4>
    7998:      	ldr	x3, [x0, #0x50]
    799c:      	add	x3, x3, x4, lsl #2
    79a0:      	ldr	w3, [x3]
    79a4:      	sxtw	x3, w3
    79a8:      	cmp	x3, #0x0
    79ac:      	cset	w3, gt
    79b0:      	ubfx	x3, x3, #0, #8
    79b4:      	b	0x7af8 <_stogir.vector-arithmetic.node?+0x1e8>
    79b8:      	movz	x3, #0x0, lsl #48
    79bc:      	b	0x79cc <_stogir.vector-arithmetic.node?+0xbc>
    79c0:      	movz	x3, #0x0, lsl #48
    79c4:      	b	0x79cc <_stogir.vector-arithmetic.node?+0xbc>
    79c8:      	movz	x3, #0x0, lsl #48
    79cc:      	cmp	x3, #0x0
    79d0:      	b.eq	0x7a04 <_stogir.vector-arithmetic.node?+0xf4>
    79d4:      	uxtb	w16, w2
    79d8:      	cmp	w16, wzr
    79dc:      	b.eq	0x79f0 <_stogir.vector-arithmetic.node?+0xe0>
    79e0:      	ldr	x0, [x0]
    79e4:      	add	x0, x0, x1, lsl #4
    79e8:      	ldr	x0, [x0]
    79ec:      	b	0x79fc <_stogir.vector-arithmetic.node?+0xec>
    79f0:      	ldr	x0, [x0, #0x28]
    79f4:      	add	x0, x0, x4, lsl #4
    79f8:      	ldr	x0, [x0]
    79fc:      	mov	x1, #0x1                ; =1
    7a00:      	b	0x7a0c <_stogir.vector-arithmetic.node?+0xfc>
    7a04:      	movz	x1, #0x0, lsl #48
    7a08:      	movz	x0, #0x0, lsl #48
    7a0c:      	lsr	w1, w1, #0
    7a10:      	lsr	x16, x1, #0
    7a14:      	cmp	x16, #0x1
    7a18:      	b.eq	0x7a34 <_stogir.vector-arithmetic.node?+0x124>
    7a1c:      	b.lo	0x7a24 <_stogir.vector-arithmetic.node?+0x114>
    7a20:      	b	0x7a38 <_stogir.vector-arithmetic.node?+0x128>
    7a24:      	cmp	x16, #0x0
    7a28:      	b.eq	0x7a30 <_stogir.vector-arithmetic.node?+0x120>
    7a2c:      	b	0x7a38 <_stogir.vector-arithmetic.node?+0x128>
    7a30:      	b	0x7a3c <_stogir.vector-arithmetic.node?+0x12c>
    7a34:      	b	0x7a4c <_stogir.vector-arithmetic.node?+0x13c>
    7a38:      	b	0x7b04 <_stogir.vector-arithmetic.node?+0x1f4>
    7a3c:      	movz	x0, #0x0, lsl #48
    7a40:      	b	0x7a48 <_stogir.vector-arithmetic.node?+0x138>
    7a44:      	movz	x0, #0x0, lsl #48
    7a48:      	ret
    7a4c:      	uxtb	w1, w0
    7a50:      	cmp	x1, #0x1f
    7a54:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a58:      	cmp	x1, #0x20
    7a5c:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a60:      	cmp	x1, #0x2d
    7a64:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a68:      	cmp	x1, #0x36
    7a6c:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a70:      	cmp	x1, #0x37
    7a74:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a78:      	cmp	x1, #0x38
    7a7c:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a80:      	cmp	x1, #0x39
    7a84:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a88:      	cmp	x1, #0x3a
    7a8c:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a90:      	cmp	x1, #0x3b
    7a94:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7a98:      	cmp	x1, #0x31
    7a9c:      	b.lt	0x7b0c <_stogir.vector-arithmetic.node?+0x1fc>
    7aa0:      	cmp	x1, #0x35
    7aa4:      	b.gt	0x7b0c <_stogir.vector-arithmetic.node?+0x1fc>
    7aa8:      	lsr	w0, w0, #0
    7aac:      	ubfx	x0, x0, #8, #8
    7ab0:      	cmp	x0, #0xf
    7ab4:      	b.le	0x7a44 <_stogir.vector-arithmetic.node?+0x134>
    7ab8:      	cmp	x0, #0x80
    7abc:      	b.ge	0x7aec <_stogir.vector-arithmetic.node?+0x1dc>
    7ac0:      	and	x0, x0, #0xf
    7ac4:      	lsr	w0, w0, #0
    7ac8:      	sxtw	x0, w0
    7acc:      	cmp	x0, #0x1
    7ad0:      	b.lt	0x7afc <_stogir.vector-arithmetic.node?+0x1ec>
    7ad4:      	cmp	x0, #0xd
    7ad8:      	cset	w0, le
    7adc:      	ubfx	x0, x0, #0, #8
    7ae0:      	b	0x7b00 <_stogir.vector-arithmetic.node?+0x1f0>
    7ae4:      	movz	x3, #0x0, lsl #48
    7ae8:      	b	0x79c4 <_stogir.vector-arithmetic.node?+0xb4>
    7aec:      	movz	x0, #0x0, lsl #48
    7af0:      	b	0x7a48 <_stogir.vector-arithmetic.node?+0x138>
    7af4:      	movz	x3, #0x0, lsl #48
    7af8:      	b	0x79bc <_stogir.vector-arithmetic.node?+0xac>
    7afc:      	movz	x0, #0x0, lsl #48
    7b00:      	b	0x7af0 <_stogir.vector-arithmetic.node?+0x1e0>
    7b04:      	brk	#0
    7b08:      	b	0x7b04 <_stogir.vector-arithmetic.node?+0x1f4>
    7b0c:      	cmp	x1, #0x1a
    7b10:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7b14:      	cmp	x1, #0x1b
    7b18:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7b1c:      	cmp	x1, #0x1c
    7b20:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7b24:      	cmp	x1, #0x1d
    7b28:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7b2c:      	cmp	x1, #0x1e
    7b30:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7b34:      	cmp	x1, #0x2e
    7b38:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7b3c:      	cmp	x1, #0x2f
    7b40:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7b44:      	cmp	x1, #0x30
    7b48:      	b.eq	0x7aa8 <_stogir.vector-arithmetic.node?+0x198>
    7b4c:      	movz	x0, #0x0, lsl #48
    7b50:      	b	0x7a48 <_stogir.vector-arithmetic.node?+0x138>

0000000000007b54 <_stogir.vector-arithmetic.validate>:
    7b54:      	sub	sp, sp, #0x60
    7b58:      	str	x29, [sp]
    7b5c:      	str	x30, [sp, #0x8]
    7b60:      	mov	x29, sp
    7b64:      	str	x19, [sp, #0x40]
    7b68:      	str	x20, [sp, #0x48]
    7b6c:      	str	x21, [sp, #0x50]
    7b70:      	str	x22, [sp, #0x58]
    7b74:      	sxtw	x2, w1
    7b78:      	lsl	x19, x2, #2
    7b7c:      	cmp	x2, #0x0
    7b80:      	cset	w3, gt
    7b84:      	movz	x16, #0x0, lsl #48
    7b88:      	sub	x4, x16, x2
    7b8c:      	sub	x5, x4, #0x1
    7b90:      	uxtb	w16, w3
    7b94:      	cmp	w16, wzr
    7b98:      	b.eq	0x7bd8 <_stogir.vector-arithmetic.validate+0x84>
    7b9c:      	ldr	x4, [x0, #0x8]
    7ba0:      	cmp	x2, x4
    7ba4:      	b.ge	0x7c28 <_stogir.vector-arithmetic.validate+0xd4>
    7ba8:      	add	x4, x0, #0x78
    7bac:      	ldr	x4, [x4, #0x8]
    7bb0:      	cmp	x2, x4
    7bb4:      	b.ge	0x7d28 <_stogir.vector-arithmetic.validate+0x1d4>
    7bb8:      	ldr	x4, [x0, #0x78]
    7bbc:      	add	x4, x19, x4
    7bc0:      	ldr	w4, [x4]
    7bc4:      	sxtw	x4, w4
    7bc8:      	cmp	x4, #0x0
    7bcc:      	cset	w4, ge
    7bd0:      	ubfx	x4, x4, #0, #8
    7bd4:      	b	0x7d2c <_stogir.vector-arithmetic.validate+0x1d8>
    7bd8:      	cmp	x2, #0x0
    7bdc:      	b.ge	0x7c30 <_stogir.vector-arithmetic.validate+0xdc>
    7be0:      	add	x6, x0, #0x28
    7be4:      	add	x7, x0, #0x50
    7be8:      	ldr	x6, [x6, #0x8]
    7bec:      	ldr	x7, [x7, #0x8]
    7bf0:      	cmp	x6, x7
    7bf4:      	b.ne	0x7c20 <_stogir.vector-arithmetic.validate+0xcc>
    7bf8:      	cmp	x4, x6
    7bfc:      	b.gt	0x7dc4 <_stogir.vector-arithmetic.validate+0x270>
    7c00:      	ldr	x4, [x0, #0x50]
    7c04:      	add	x4, x4, x5, lsl #2
    7c08:      	ldr	w4, [x4]
    7c0c:      	sxtw	x4, w4
    7c10:      	cmp	x4, #0x0
    7c14:      	cset	w4, gt
    7c18:      	ubfx	x4, x4, #0, #8
    7c1c:      	b	0x7dc8 <_stogir.vector-arithmetic.validate+0x274>
    7c20:      	movz	x4, #0x0, lsl #48
    7c24:      	b	0x7c34 <_stogir.vector-arithmetic.validate+0xe0>
    7c28:      	movz	x4, #0x0, lsl #48
    7c2c:      	b	0x7c34 <_stogir.vector-arithmetic.validate+0xe0>
    7c30:      	movz	x4, #0x0, lsl #48
    7c34:      	cmp	x4, #0x0
    7c38:      	b.eq	0x7c74 <_stogir.vector-arithmetic.validate+0x120>
    7c3c:      	uxtb	w16, w3
    7c40:      	cmp	w16, wzr
    7c44:      	b.eq	0x7c5c <_stogir.vector-arithmetic.validate+0x108>
    7c48:      	ldr	x3, [x0]
    7c4c:      	add	x3, x3, x2, lsl #4
    7c50:      	ldr	x20, [x3]
    7c54:      	ldr	x3, [x3, #0x8]
    7c58:      	b	0x7c6c <_stogir.vector-arithmetic.validate+0x118>
    7c5c:      	ldr	x3, [x0, #0x28]
    7c60:      	add	x3, x3, x5, lsl #4
    7c64:      	ldr	x20, [x3]
    7c68:      	ldr	x3, [x3, #0x8]
    7c6c:      	mov	x4, #0x1                ; =1
    7c70:      	b	0x7c80 <_stogir.vector-arithmetic.validate+0x12c>
    7c74:      	movz	x4, #0x0, lsl #48
    7c78:      	movz	x20, #0x0, lsl #48
    7c7c:      	movz	x3, #0x0, lsl #48
    7c80:      	lsr	w4, w4, #0
    7c84:      	lsr	x16, x4, #0
    7c88:      	cmp	x16, #0x1
    7c8c:      	b.eq	0x7ca8 <_stogir.vector-arithmetic.validate+0x154>
    7c90:      	b.lo	0x7c98 <_stogir.vector-arithmetic.validate+0x144>
    7c94:      	b	0x7cac <_stogir.vector-arithmetic.validate+0x158>
    7c98:      	cmp	x16, #0x0
    7c9c:      	b.eq	0x7ca4 <_stogir.vector-arithmetic.validate+0x150>
    7ca0:      	b	0x7cac <_stogir.vector-arithmetic.validate+0x158>
    7ca4:      	b	0x7cb0 <_stogir.vector-arithmetic.validate+0x15c>
    7ca8:      	b	0x7ccc <_stogir.vector-arithmetic.validate+0x178>
    7cac:      	b	0x7e78 <_stogir.vector-arithmetic.validate+0x324>
    7cb0:      	adrp	x16, 0x7000 <_coil.core.Len$coil.arraylist.ArrayList$len__u8+0x4>
		0000000000007cb0:  ARM64_RELOC_PAGE21	l_stogir.418
    7cb4:      	ldr	x16, [x16]
		0000000000007cb4:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    7cb8:      	orr	x0, x16, xzr
    7cbc:      	mov	x21, x8
    7cc0:      	mov	x1, #0x1                ; =1
    7cc4:      	mov	x2, #0x25               ; =37
    7cc8:      	b	0x7cfc <_stogir.vector-arithmetic.validate+0x1a8>
    7ccc:      	add	x16, sp, #0x10
    7cd0:      	str	x20, [x16]
    7cd4:      	add	x16, sp, #0x10
    7cd8:      	str	x3, [x16, #0x8]
    7cdc:      	cmp	x2, #0x0
    7ce0:      	b.gt	0x7d30 <_stogir.vector-arithmetic.validate+0x1dc>
    7ce4:      	mov	x21, x8
    7ce8:      	adrp	x16, 0x7000 <_coil.core.Len$coil.arraylist.ArrayList$len__u8+0x4>
		0000000000007ce8:  ARM64_RELOC_PAGE21	l_stogir.419
    7cec:      	ldr	x16, [x16]
		0000000000007cec:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    7cf0:      	orr	x0, x16, xzr
    7cf4:      	mov	x1, #0x1                ; =1
    7cf8:      	mov	x2, #0x2b               ; =43
    7cfc:      	str	x1, [x21]
    7d00:      	str	x0, [x21, #0x8]
    7d04:      	str	x2, [x21, #0x10]
    7d08:      	ldr	x19, [sp, #0x40]
    7d0c:      	ldr	x20, [sp, #0x48]
    7d10:      	ldr	x21, [sp, #0x50]
    7d14:      	ldr	x22, [sp, #0x58]
    7d18:      	ldr	x29, [sp]
    7d1c:      	ldr	x30, [sp, #0x8]
    7d20:      	add	sp, sp, #0x60
    7d24:      	ret
    7d28:      	movz	x4, #0x0, lsl #48
    7d2c:      	b	0x7c2c <_stogir.vector-arithmetic.validate+0xd8>
    7d30:      	lsr	w1, w1, #0
    7d34:      	mov	x21, x8
    7d38:      	mov	x22, x0
    7d3c:      	bl	0x7d3c <_stogir.vector-arithmetic.validate+0x1e8>
		0000000000007d3c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    7d40:      	cmp	x0, #0x0
    7d44:      	b.eq	0x7ce8 <_stogir.vector-arithmetic.validate+0x194>
    7d48:      	uxtb	w20, w20
    7d4c:      	orr	x0, x20, xzr
    7d50:      	ldr	x1, [x22, #0x78]
    7d54:      	cmp	x0, #0x1d
    7d58:      	cset	w2, eq
    7d5c:      	cmp	x0, #0x1e
    7d60:      	cset	w3, eq
    7d64:      	add	x1, x19, x1
    7d68:      	ldr	w1, [x1]
    7d6c:      	cmp	x0, #0x1f
    7d70:      	b.eq	0x7e28 <_stogir.vector-arithmetic.validate+0x2d4>
    7d74:      	cmp	x0, #0x20
    7d78:      	b.eq	0x7e28 <_stogir.vector-arithmetic.validate+0x2d4>
    7d7c:      	cmp	x0, #0x2d
    7d80:      	b.eq	0x7e28 <_stogir.vector-arithmetic.validate+0x2d4>
    7d84:      	cmp	x0, #0x36
    7d88:      	b.eq	0x7e28 <_stogir.vector-arithmetic.validate+0x2d4>
    7d8c:      	cmp	x0, #0x37
    7d90:      	b.eq	0x7e28 <_stogir.vector-arithmetic.validate+0x2d4>
    7d94:      	cmp	x0, #0x38
    7d98:      	b.eq	0x7e28 <_stogir.vector-arithmetic.validate+0x2d4>
    7d9c:      	cmp	x0, #0x39
    7da0:      	b.eq	0x7e28 <_stogir.vector-arithmetic.validate+0x2d4>
    7da4:      	uxtb	w16, w2
    7da8:      	cmp	w16, wzr
    7dac:      	b.ne	0x7e80 <_stogir.vector-arithmetic.validate+0x32c>
    7db0:      	uxtb	w16, w3
    7db4:      	cmp	w16, wzr
    7db8:      	b.ne	0x7e80 <_stogir.vector-arithmetic.validate+0x32c>
    7dbc:      	mov	x0, #0x2                ; =2
    7dc0:      	b	0x7e84 <_stogir.vector-arithmetic.validate+0x330>
    7dc4:      	movz	x4, #0x0, lsl #48
    7dc8:      	b	0x7c24 <_stogir.vector-arithmetic.validate+0xd0>
    7dcc:      	add	x16, sp, #0x10
    7dd0:      	ldr	w2, [x16, #0xc]
    7dd4:      	sxtw	x2, w2
    7dd8:      	lsr	w1, w1, #0
    7ddc:      	lsr	w4, w4, #0
    7de0:      	lsr	w20, w20, #0
    7de4:      	lsr	w2, w2, #0
    7de8:      	ubfx	x0, x0, #8, #8
    7dec:      	lsr	w0, w0, #0
    7df0:      	add	x8, sp, #0x20
    7df4:      	mov	w3, w1
    7df8:      	mov	w1, w20
    7dfc:      	mov	w5, w2
    7e00:      	mov	w2, w0
    7e04:      	mov	x0, x22
    7e08:      	bl	0x7e08 <_stogir.vector-arithmetic.validate+0x2b4>
		0000000000007e08:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    7e0c:      	add	x16, sp, #0x20
    7e10:      	ldr	x1, [x16]
    7e14:      	add	x16, sp, #0x20
    7e18:      	ldr	x0, [x16, #0x8]
    7e1c:      	add	x16, sp, #0x20
    7e20:      	ldr	x2, [x16, #0x10]
    7e24:      	b	0x7cfc <_stogir.vector-arithmetic.validate+0x1a8>
    7e28:      	mov	x0, #0x1                ; =1
    7e2c:      	sxtw	x1, w1
    7e30:      	lsr	w0, w0, #0
    7e34:      	sxtw	x0, w0
    7e38:      	cmp	x1, x0
    7e3c:      	b.ne	0x7ce8 <_stogir.vector-arithmetic.validate+0x194>
    7e40:      	add	x16, sp, #0x10
    7e44:      	ldr	w0, [x16]
    7e48:      	add	x16, sp, #0x10
    7e4c:      	ldr	w1, [x16, #0x4]
    7e50:      	add	x16, sp, #0x10
    7e54:      	ldr	w4, [x16, #0x8]
    7e58:      	uxtb	w16, w2
    7e5c:      	cmp	w16, wzr
    7e60:      	b.ne	0x7dcc <_stogir.vector-arithmetic.validate+0x278>
    7e64:      	uxtb	w16, w3
    7e68:      	cmp	w16, wzr
    7e6c:      	b.ne	0x7dcc <_stogir.vector-arithmetic.validate+0x278>
    7e70:      	movz	x2, #0x0, lsl #48
    7e74:      	b	0x7dd8 <_stogir.vector-arithmetic.validate+0x284>
    7e78:      	brk	#0
    7e7c:      	b	0x7e78 <_stogir.vector-arithmetic.validate+0x324>
    7e80:      	mov	x0, #0x3                ; =3
    7e84:      	b	0x7e2c <_stogir.vector-arithmetic.validate+0x2d8>

0000000000007e88 <_stogir.vector.memory-inputs>:
    7e88:      	sub	sp, sp, #0x40
    7e8c:      	str	x29, [sp]
    7e90:      	str	x30, [sp, #0x8]
    7e94:      	mov	x29, sp
    7e98:      	str	x19, [sp, #0x10]
    7e9c:      	str	x20, [sp, #0x18]
    7ea0:      	str	x21, [sp, #0x20]
    7ea4:      	str	x22, [sp, #0x28]
    7ea8:      	str	x23, [sp, #0x30]
    7eac:      	str	x24, [sp, #0x38]
    7eb0:      	sxtw	x5, w1
    7eb4:      	cmp	x5, #0xf
    7eb8:      	b.le	0x8348 <_stogir.vector.memory-inputs+0x4c0>
    7ebc:      	cmp	x5, #0x80
    7ec0:      	b.ge	0x8350 <_stogir.vector.memory-inputs+0x4c8>
    7ec4:      	and	x6, x5, #0xf
    7ec8:      	lsr	w6, w6, #0
    7ecc:      	sxtw	x6, w6
    7ed0:      	cmp	x6, #0x1
    7ed4:      	b.lt	0x8358 <_stogir.vector.memory-inputs+0x4d0>
    7ed8:      	and	x5, x5, #0xf
    7edc:      	lsr	w5, w5, #0
    7ee0:      	sxtw	x5, w5
    7ee4:      	cmp	x5, #0xd
    7ee8:      	b.gt	0x8360 <_stogir.vector.memory-inputs+0x4d8>
    7eec:      	lsr	w1, w1, #0
    7ef0:      	lsr	w2, w2, #0
    7ef4:      	mov	x19, x8
    7ef8:      	mov	x20, x0
    7efc:      	mov	w0, w1
    7f00:      	mov	w21, w1
    7f04:      	mov	w1, w2
    7f08:      	mov	w22, w2
    7f0c:      	mov	w23, w3
    7f10:      	mov	w24, w4
    7f14:      	bl	0x7f14 <_stogir.vector.memory-inputs+0x8c>
		0000000000007f14:  ARM64_RELOC_BRANCH26	_stogir.types.size
    7f18:      	lsr	w0, w0, #0
    7f1c:      	sxtw	x0, w0
    7f20:      	cmp	x0, #0x0
    7f24:      	b.le	0x7f88 <_stogir.vector.memory-inputs+0x100>
    7f28:      	sxtw	x23, w23
    7f2c:      	cmp	x23, #0x0
    7f30:      	cset	w0, gt
    7f34:      	movz	x16, #0x0, lsl #48
    7f38:      	sub	x1, x16, x23
    7f3c:      	sub	x2, x1, #0x1
    7f40:      	uxtb	w16, w0
    7f44:      	cmp	w16, wzr
    7f48:      	b.eq	0x8064 <_stogir.vector.memory-inputs+0x1dc>
    7f4c:      	ldr	x1, [x20, #0x8]
    7f50:      	cmp	x23, x1
    7f54:      	b.ge	0x805c <_stogir.vector.memory-inputs+0x1d4>
    7f58:      	add	x1, x20, #0x78
    7f5c:      	ldr	x1, [x1, #0x8]
    7f60:      	cmp	x23, x1
    7f64:      	b.ge	0x8104 <_stogir.vector.memory-inputs+0x27c>
    7f68:      	ldr	x1, [x20, #0x78]
    7f6c:      	add	x1, x1, x23, lsl #2
    7f70:      	ldr	w1, [x1]
    7f74:      	sxtw	x1, w1
    7f78:      	cmp	x1, #0x0
    7f7c:      	cset	w1, ge
    7f80:      	ubfx	x1, x1, #0, #8
    7f84:      	b	0x8108 <_stogir.vector.memory-inputs+0x280>
    7f88:      	adrp	x16, 0x7000 <_coil.core.Len$coil.arraylist.ArrayList$len__u8+0x4>
		0000000000007f88:  ARM64_RELOC_PAGE21	l_stogir.420
    7f8c:      	ldr	x16, [x16]
		0000000000007f8c:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    7f90:      	orr	x0, x16, xzr
    7f94:      	mov	x1, #0x1                ; =1
    7f98:      	mov	x2, #0x32               ; =50
    7f9c:      	str	x1, [x19]
    7fa0:      	str	x0, [x19, #0x8]
    7fa4:      	str	x2, [x19, #0x10]
    7fa8:      	ldr	x19, [sp, #0x10]
    7fac:      	ldr	x20, [sp, #0x18]
    7fb0:      	ldr	x21, [sp, #0x20]
    7fb4:      	ldr	x22, [sp, #0x28]
    7fb8:      	ldr	x23, [sp, #0x30]
    7fbc:      	ldr	x24, [sp, #0x38]
    7fc0:      	ldr	x29, [sp]
    7fc4:      	ldr	x30, [sp, #0x8]
    7fc8:      	add	sp, sp, #0x40
    7fcc:      	ret
    7fd0:      	movz	x1, #0x0, lsl #48
    7fd4:      	movz	x0, #0x0, lsl #48
    7fd8:      	lsr	w1, w1, #0
    7fdc:      	lsr	x16, x1, #0
    7fe0:      	cmp	x16, #0x1
    7fe4:      	b.eq	0x8000 <_stogir.vector.memory-inputs+0x178>
    7fe8:      	b.lo	0x7ff0 <_stogir.vector.memory-inputs+0x168>
    7fec:      	b	0x8004 <_stogir.vector.memory-inputs+0x17c>
    7ff0:      	cmp	x16, #0x0
    7ff4:      	b.eq	0x7ffc <_stogir.vector.memory-inputs+0x174>
    7ff8:      	b	0x8004 <_stogir.vector.memory-inputs+0x17c>
    7ffc:      	b	0x8008 <_stogir.vector.memory-inputs+0x180>
    8000:      	b	0x80ac <_stogir.vector.memory-inputs+0x224>
    8004:      	b	0x8330 <_stogir.vector.memory-inputs+0x4a8>
    8008:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008008:  ARM64_RELOC_PAGE21	l_stogir.421
    800c:      	ldr	x16, [x16]
		000000000000800c:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    8010:      	orr	x0, x16, xzr
    8014:      	mov	x1, #0x1                ; =1
    8018:      	mov	x2, #0x1d               ; =29
    801c:      	b	0x7f9c <_stogir.vector.memory-inputs+0x114>
    8020:      	ldr	x0, [x20, #0x28]
    8024:      	add	x0, x0, x2, lsl #4
    8028:      	ldr	x0, [x0]
    802c:      	mov	x1, #0x1                ; =1
    8030:      	b	0x7fd8 <_stogir.vector.memory-inputs+0x150>
    8034:      	movz	x1, #0x0, lsl #48
    8038:      	cmp	x1, #0x0
    803c:      	b.eq	0x7fd0 <_stogir.vector.memory-inputs+0x148>
    8040:      	uxtb	w16, w0
    8044:      	cmp	w16, wzr
    8048:      	b.eq	0x8020 <_stogir.vector.memory-inputs+0x198>
    804c:      	ldr	x0, [x20]
    8050:      	add	x0, x0, x23, lsl #4
    8054:      	ldr	x0, [x0]
    8058:      	b	0x802c <_stogir.vector.memory-inputs+0x1a4>
    805c:      	movz	x1, #0x0, lsl #48
    8060:      	b	0x8038 <_stogir.vector.memory-inputs+0x1b0>
    8064:      	cmp	x23, #0x0
    8068:      	b.ge	0x8034 <_stogir.vector.memory-inputs+0x1ac>
    806c:      	add	x3, x20, #0x28
    8070:      	add	x4, x20, #0x50
    8074:      	ldr	x3, [x3, #0x8]
    8078:      	ldr	x4, [x4, #0x8]
    807c:      	cmp	x3, x4
    8080:      	b.ne	0x80fc <_stogir.vector.memory-inputs+0x274>
    8084:      	cmp	x1, x3
    8088:      	b.gt	0x810c <_stogir.vector.memory-inputs+0x284>
    808c:      	ldr	x1, [x20, #0x50]
    8090:      	add	x1, x1, x2, lsl #2
    8094:      	ldr	w1, [x1]
    8098:      	sxtw	x1, w1
    809c:      	cmp	x1, #0x0
    80a0:      	cset	w1, gt
    80a4:      	ubfx	x1, x1, #0, #8
    80a8:      	b	0x8110 <_stogir.vector.memory-inputs+0x288>
    80ac:      	cmp	x23, #0x0
    80b0:      	b.le	0x80e4 <_stogir.vector.memory-inputs+0x25c>
    80b4:      	uxtb	w0, w0
    80b8:      	cmp	x0, #0x83
    80bc:      	cset	w1, lt
    80c0:      	uxtb	w16, w1
    80c4:      	cmp	w16, wzr
    80c8:      	b.eq	0x8114 <_stogir.vector.memory-inputs+0x28c>
    80cc:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		00000000000080cc:  ARM64_RELOC_PAGE21	l_stogir.422
    80d0:      	ldr	x16, [x16]
		00000000000080d0:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    80d4:      	orr	x2, x16, xzr
    80d8:      	add	x2, x0, x2
    80dc:      	ldrb	w2, [x2]
    80e0:      	b	0x8118 <_stogir.vector.memory-inputs+0x290>
    80e4:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		00000000000080e4:  ARM64_RELOC_PAGE21	l_stogir.423
    80e8:      	ldr	x16, [x16]
		00000000000080e8:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    80ec:      	orr	x0, x16, xzr
    80f0:      	mov	x1, #0x1                ; =1
    80f4:      	mov	x2, #0x2c               ; =44
    80f8:      	b	0x801c <_stogir.vector.memory-inputs+0x194>
    80fc:      	movz	x1, #0x0, lsl #48
    8100:      	b	0x8038 <_stogir.vector.memory-inputs+0x1b0>
    8104:      	movz	x1, #0x0, lsl #48
    8108:      	b	0x8060 <_stogir.vector.memory-inputs+0x1d8>
    810c:      	movz	x1, #0x0, lsl #48
    8110:      	b	0x8100 <_stogir.vector.memory-inputs+0x278>
    8114:      	movz	x2, #0x0, lsl #48
    8118:      	uxtb	w2, w2
    811c:      	and	x2, x2, #0x1
    8120:      	uxtb	w2, w2
    8124:      	cmp	x2, #0x0
    8128:      	b.eq	0x80e4 <_stogir.vector.memory-inputs+0x25c>
    812c:      	uxtb	w16, w1
    8130:      	cmp	w16, wzr
    8134:      	b.eq	0x8150 <_stogir.vector.memory-inputs+0x2c8>
    8138:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008138:  ARM64_RELOC_PAGE21	l_stogir.422
    813c:      	ldr	x16, [x16]
		000000000000813c:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    8140:      	orr	x1, x16, xzr
    8144:      	add	x0, x0, x1
    8148:      	ldrb	w0, [x0]
    814c:      	b	0x8154 <_stogir.vector.memory-inputs+0x2cc>
    8150:      	movz	x0, #0x0, lsl #48
    8154:      	uxtb	w0, w0
    8158:      	and	x0, x0, #0x4
    815c:      	uxtb	w0, w0
    8160:      	cmp	x0, #0x0
    8164:      	cset	w0, eq
    8168:      	uxtb	w16, w0
    816c:      	cmp	w16, wzr
    8170:      	cset	x0, eq
    8174:      	cmp	x0, #0x0
    8178:      	b.ne	0x80e4 <_stogir.vector.memory-inputs+0x25c>
    817c:      	sxtw	x24, w24
    8180:      	cmp	x24, #0x0
    8184:      	cset	w0, gt
    8188:      	movz	x16, #0x0, lsl #48
    818c:      	sub	x1, x16, x24
    8190:      	sub	x2, x1, #0x1
    8194:      	uxtb	w16, w0
    8198:      	cmp	w16, wzr
    819c:      	b.eq	0x81f4 <_stogir.vector.memory-inputs+0x36c>
    81a0:      	ldr	x1, [x20, #0x8]
    81a4:      	cmp	x24, x1
    81a8:      	b.ge	0x823c <_stogir.vector.memory-inputs+0x3b4>
    81ac:      	add	x1, x20, #0x78
    81b0:      	ldr	x1, [x1, #0x8]
    81b4:      	cmp	x24, x1
    81b8:      	b.ge	0x8328 <_stogir.vector.memory-inputs+0x4a0>
    81bc:      	ldr	x1, [x20, #0x78]
    81c0:      	add	x1, x1, x24, lsl #2
    81c4:      	ldr	w1, [x1]
    81c8:      	sxtw	x1, w1
    81cc:      	cmp	x1, #0x0
    81d0:      	cset	w1, ge
    81d4:      	ubfx	x1, x1, #0, #8
    81d8:      	b	0x832c <_stogir.vector.memory-inputs+0x4a4>
    81dc:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		00000000000081dc:  ARM64_RELOC_PAGE21	l_stogir.424
    81e0:      	ldr	x16, [x16]
		00000000000081e0:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    81e4:      	orr	x0, x16, xzr
    81e8:      	mov	x1, #0x1                ; =1
    81ec:      	mov	x2, #0x2b               ; =43
    81f0:      	b	0x80f8 <_stogir.vector.memory-inputs+0x270>
    81f4:      	cmp	x24, #0x0
    81f8:      	b.ge	0x8244 <_stogir.vector.memory-inputs+0x3bc>
    81fc:      	add	x3, x20, #0x28
    8200:      	add	x4, x20, #0x50
    8204:      	ldr	x3, [x3, #0x8]
    8208:      	ldr	x4, [x4, #0x8]
    820c:      	cmp	x3, x4
    8210:      	b.ne	0x8320 <_stogir.vector.memory-inputs+0x498>
    8214:      	cmp	x1, x3
    8218:      	b.gt	0x8338 <_stogir.vector.memory-inputs+0x4b0>
    821c:      	ldr	x1, [x20, #0x50]
    8220:      	add	x1, x1, x2, lsl #2
    8224:      	ldr	w1, [x1]
    8228:      	sxtw	x1, w1
    822c:      	cmp	x1, #0x0
    8230:      	cset	w1, gt
    8234:      	ubfx	x1, x1, #0, #8
    8238:      	b	0x833c <_stogir.vector.memory-inputs+0x4b4>
    823c:      	movz	x1, #0x0, lsl #48
    8240:      	b	0x8248 <_stogir.vector.memory-inputs+0x3c0>
    8244:      	movz	x1, #0x0, lsl #48
    8248:      	cmp	x1, #0x0
    824c:      	b.eq	0x8280 <_stogir.vector.memory-inputs+0x3f8>
    8250:      	uxtb	w16, w0
    8254:      	cmp	w16, wzr
    8258:      	b.eq	0x826c <_stogir.vector.memory-inputs+0x3e4>
    825c:      	ldr	x0, [x20]
    8260:      	add	x0, x0, x24, lsl #4
    8264:      	ldr	x0, [x0]
    8268:      	b	0x8278 <_stogir.vector.memory-inputs+0x3f0>
    826c:      	ldr	x0, [x20, #0x28]
    8270:      	add	x0, x0, x2, lsl #4
    8274:      	ldr	x0, [x0]
    8278:      	mov	x1, #0x1                ; =1
    827c:      	b	0x8288 <_stogir.vector.memory-inputs+0x400>
    8280:      	movz	x1, #0x0, lsl #48
    8284:      	movz	x0, #0x0, lsl #48
    8288:      	lsr	w1, w1, #0
    828c:      	lsr	x16, x1, #0
    8290:      	cmp	x16, #0x1
    8294:      	b.eq	0x82b0 <_stogir.vector.memory-inputs+0x428>
    8298:      	b.lo	0x82a0 <_stogir.vector.memory-inputs+0x418>
    829c:      	b	0x82b4 <_stogir.vector.memory-inputs+0x42c>
    82a0:      	cmp	x16, #0x0
    82a4:      	b.eq	0x82ac <_stogir.vector.memory-inputs+0x424>
    82a8:      	b	0x82b4 <_stogir.vector.memory-inputs+0x42c>
    82ac:      	b	0x82b8 <_stogir.vector.memory-inputs+0x430>
    82b0:      	b	0x82d0 <_stogir.vector.memory-inputs+0x448>
    82b4:      	b	0x8340 <_stogir.vector.memory-inputs+0x4b8>
    82b8:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		00000000000082b8:  ARM64_RELOC_PAGE21	l_stogir.425
    82bc:      	ldr	x16, [x16]
		00000000000082bc:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    82c0:      	orr	x0, x16, xzr
    82c4:      	mov	x1, #0x1                ; =1
    82c8:      	mov	x2, #0x1d               ; =29
    82cc:      	b	0x81f0 <_stogir.vector.memory-inputs+0x368>
    82d0:      	lsr	w1, w0, #0
    82d4:      	ubfx	x1, x1, #8, #8
    82d8:      	cmp	x1, #0x6
    82dc:      	b.ne	0x81dc <_stogir.vector.memory-inputs+0x354>
    82e0:      	uxtb	w0, w0
    82e4:      	cmp	x0, #0x48
    82e8:      	b.eq	0x81dc <_stogir.vector.memory-inputs+0x354>
    82ec:      	cmp	x0, #0x46
    82f0:      	b.eq	0x81dc <_stogir.vector.memory-inputs+0x354>
    82f4:      	lsr	w21, w21, #0
    82f8:      	lsr	w22, w22, #0
    82fc:      	mov	w0, w21
    8300:      	mov	w1, w22
    8304:      	bl	0x8304 <_stogir.vector.memory-inputs+0x47c>
		0000000000008304:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8308:      	lsr	w0, w0, #0
    830c:      	sxtw	x0, w0
    8310:      	and	x0, x0, #0xffffffff
    8314:      	movz	x1, #0x0, lsl #48
    8318:      	movz	x2, #0x0, lsl #48
    831c:      	b	0x81f0 <_stogir.vector.memory-inputs+0x368>
    8320:      	movz	x1, #0x0, lsl #48
    8324:      	b	0x8248 <_stogir.vector.memory-inputs+0x3c0>
    8328:      	movz	x1, #0x0, lsl #48
    832c:      	b	0x8240 <_stogir.vector.memory-inputs+0x3b8>
    8330:      	brk	#0
    8334:      	b	0x8330 <_stogir.vector.memory-inputs+0x4a8>
    8338:      	movz	x1, #0x0, lsl #48
    833c:      	b	0x8324 <_stogir.vector.memory-inputs+0x49c>
    8340:      	brk	#0
    8344:      	b	0x8340 <_stogir.vector.memory-inputs+0x4b8>
    8348:      	mov	x19, x8
    834c:      	b	0x7f88 <_stogir.vector.memory-inputs+0x100>
    8350:      	mov	x19, x8
    8354:      	b	0x7f88 <_stogir.vector.memory-inputs+0x100>
    8358:      	mov	x19, x8
    835c:      	b	0x7f88 <_stogir.vector.memory-inputs+0x100>
    8360:      	mov	x19, x8
    8364:      	b	0x7f88 <_stogir.vector.memory-inputs+0x100>

0000000000008368 <_stogir.vector.store-inputs>:
    8368:      	sub	sp, sp, #0x40
    836c:      	str	x29, [sp]
    8370:      	str	x30, [sp, #0x8]
    8374:      	mov	x29, sp
    8378:      	str	x19, [sp, #0x30]
    837c:      	sxtw	x4, w4
    8380:      	cmp	x4, #0x0
    8384:      	cset	w5, gt
    8388:      	movz	x16, #0x0, lsl #48
    838c:      	sub	x6, x16, x4
    8390:      	sub	x7, x6, #0x1
    8394:      	uxtb	w16, w5
    8398:      	cmp	w16, wzr
    839c:      	b.eq	0x83dc <_stogir.vector.store-inputs+0x74>
    83a0:      	ldr	x6, [x0, #0x8]
    83a4:      	cmp	x4, x6
    83a8:      	b.ge	0x842c <_stogir.vector.store-inputs+0xc4>
    83ac:      	add	x6, x0, #0x78
    83b0:      	ldr	x6, [x6, #0x8]
    83b4:      	cmp	x4, x6
    83b8:      	b.ge	0x8534 <_stogir.vector.store-inputs+0x1cc>
    83bc:      	ldr	x6, [x0, #0x78]
    83c0:      	add	x6, x6, x4, lsl #2
    83c4:      	ldr	w6, [x6]
    83c8:      	sxtw	x6, w6
    83cc:      	cmp	x6, #0x0
    83d0:      	cset	w6, ge
    83d4:      	ubfx	x6, x6, #0, #8
    83d8:      	b	0x8538 <_stogir.vector.store-inputs+0x1d0>
    83dc:      	cmp	x4, #0x0
    83e0:      	b.ge	0x8434 <_stogir.vector.store-inputs+0xcc>
    83e4:      	add	x9, x0, #0x28
    83e8:      	add	x10, x0, #0x50
    83ec:      	ldr	x9, [x9, #0x8]
    83f0:      	ldr	x10, [x10, #0x8]
    83f4:      	cmp	x9, x10
    83f8:      	b.ne	0x8424 <_stogir.vector.store-inputs+0xbc>
    83fc:      	cmp	x6, x9
    8400:      	b.gt	0x853c <_stogir.vector.store-inputs+0x1d4>
    8404:      	ldr	x6, [x0, #0x50]
    8408:      	add	x6, x6, x7, lsl #2
    840c:      	ldr	w6, [x6]
    8410:      	sxtw	x6, w6
    8414:      	cmp	x6, #0x0
    8418:      	cset	w6, gt
    841c:      	ubfx	x6, x6, #0, #8
    8420:      	b	0x8540 <_stogir.vector.store-inputs+0x1d8>
    8424:      	movz	x6, #0x0, lsl #48
    8428:      	b	0x8438 <_stogir.vector.store-inputs+0xd0>
    842c:      	movz	x6, #0x0, lsl #48
    8430:      	b	0x8438 <_stogir.vector.store-inputs+0xd0>
    8434:      	movz	x6, #0x0, lsl #48
    8438:      	cmp	x6, #0x0
    843c:      	b.eq	0x8470 <_stogir.vector.store-inputs+0x108>
    8440:      	uxtb	w16, w5
    8444:      	cmp	w16, wzr
    8448:      	b.eq	0x845c <_stogir.vector.store-inputs+0xf4>
    844c:      	ldr	x5, [x0]
    8450:      	add	x4, x5, x4, lsl #4
    8454:      	ldr	x4, [x4]
    8458:      	b	0x8468 <_stogir.vector.store-inputs+0x100>
    845c:      	ldr	x4, [x0, #0x28]
    8460:      	add	x4, x4, x7, lsl #4
    8464:      	ldr	x4, [x4]
    8468:      	mov	x5, #0x1                ; =1
    846c:      	b	0x8478 <_stogir.vector.store-inputs+0x110>
    8470:      	movz	x5, #0x0, lsl #48
    8474:      	movz	x4, #0x0, lsl #48
    8478:      	lsr	w5, w5, #0
    847c:      	lsr	x16, x5, #0
    8480:      	cmp	x16, #0x1
    8484:      	b.eq	0x84a0 <_stogir.vector.store-inputs+0x138>
    8488:      	b.lo	0x8490 <_stogir.vector.store-inputs+0x128>
    848c:      	b	0x84a4 <_stogir.vector.store-inputs+0x13c>
    8490:      	cmp	x16, #0x0
    8494:      	b.eq	0x849c <_stogir.vector.store-inputs+0x134>
    8498:      	b	0x84a4 <_stogir.vector.store-inputs+0x13c>
    849c:      	b	0x84a8 <_stogir.vector.store-inputs+0x140>
    84a0:      	b	0x84c4 <_stogir.vector.store-inputs+0x15c>
    84a4:      	b	0x8544 <_stogir.vector.store-inputs+0x1dc>
    84a8:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		00000000000084a8:  ARM64_RELOC_PAGE21	l_stogir.426
    84ac:      	ldr	x16, [x16]
		00000000000084ac:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    84b0:      	orr	x0, x16, xzr
    84b4:      	mov	x19, x8
    84b8:      	mov	x1, #0x1                ; =1
    84bc:      	mov	x2, #0x1a               ; =26
    84c0:      	b	0x8514 <_stogir.vector.store-inputs+0x1ac>
    84c4:      	lsr	w1, w1, #0
    84c8:      	lsr	w2, w2, #0
    84cc:      	lsr	w3, w3, #0
    84d0:      	lsr	w4, w4, #0
    84d4:      	ubfx	x4, x4, #8, #8
    84d8:      	lsr	w4, w4, #0
    84dc:      	mov	x19, x8
    84e0:      	add	x8, sp, #0x10
    84e4:      	fmov	s31, w1
    84e8:      	mov	w1, w4
    84ec:      	mov	w4, w3
    84f0:      	mov	w3, w2
    84f4:      	fmov	w2, s31
    84f8:      	bl	0x84f8 <_stogir.vector.store-inputs+0x190>
		00000000000084f8:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    84fc:      	add	x16, sp, #0x10
    8500:      	ldr	x1, [x16]
    8504:      	add	x16, sp, #0x10
    8508:      	ldr	x0, [x16, #0x8]
    850c:      	add	x16, sp, #0x10
    8510:      	ldr	x2, [x16, #0x10]
    8514:      	str	x1, [x19]
    8518:      	str	x0, [x19, #0x8]
    851c:      	str	x2, [x19, #0x10]
    8520:      	ldr	x19, [sp, #0x30]
    8524:      	ldr	x29, [sp]
    8528:      	ldr	x30, [sp, #0x8]
    852c:      	add	sp, sp, #0x40
    8530:      	ret
    8534:      	movz	x6, #0x0, lsl #48
    8538:      	b	0x8430 <_stogir.vector.store-inputs+0xc8>
    853c:      	movz	x6, #0x0, lsl #48
    8540:      	b	0x8428 <_stogir.vector.store-inputs+0xc0>
    8544:      	brk	#0
    8548:      	b	0x8544 <_stogir.vector.store-inputs+0x1dc>

000000000000854c <_stogir.types.size>:
    854c:      	sxtw	x0, w0
    8550:      	sxtw	x1, w1
    8554:      	cmp	x0, #0xf
    8558:      	cset	w2, gt
    855c:      	cmp	x0, #0x0
    8560:      	cset	w3, eq
    8564:      	cmp	x1, #0x4
    8568:      	cset	w4, eq
    856c:      	cmp	x1, #0x8
    8570:      	cset	w5, eq
    8574:      	uxtb	w16, w2
    8578:      	cmp	w16, wzr
    857c:      	b.eq	0x8644 <_stogir.types.size+0xf8>
    8580:      	cmp	x0, #0x80
    8584:      	cset	w6, lt
    8588:      	uxtb	w16, w6
    858c:      	cmp	w16, wzr
    8590:      	b.eq	0x8644 <_stogir.types.size+0xf8>
    8594:      	and	x7, x0, #0xf
    8598:      	lsr	w7, w7, #0
    859c:      	sxtw	x7, w7
    85a0:      	cmp	x7, #0x1
    85a4:      	cset	w8, ge
    85a8:      	uxtb	w16, w8
    85ac:      	cmp	w16, wzr
    85b0:      	b.eq	0x8644 <_stogir.types.size+0xf8>
    85b4:      	cmp	x7, #0xd
    85b8:      	cset	w9, le
    85bc:      	uxtb	w16, w9
    85c0:      	cmp	w16, wzr
    85c4:      	b.eq	0x8644 <_stogir.types.size+0xf8>
    85c8:      	cmp	x0, #0x0
    85cc:      	cset	w10, ge
    85d0:      	cmp	x0, #0xd
    85d4:      	cset	w11, le
    85d8:      	uxtb	w16, w10
    85dc:      	cmp	w16, wzr
    85e0:      	b.eq	0x85f0 <_stogir.types.size+0xa4>
    85e4:      	uxtb	w16, w11
    85e8:      	cmp	w16, wzr
    85ec:      	b.ne	0x8624 <_stogir.types.size+0xd8>
    85f0:      	uxtb	w16, w2
    85f4:      	cmp	w16, wzr
    85f8:      	b.eq	0x8620 <_stogir.types.size+0xd4>
    85fc:      	uxtb	w16, w6
    8600:      	cmp	w16, wzr
    8604:      	b.eq	0x8620 <_stogir.types.size+0xd4>
    8608:      	uxtb	w16, w8
    860c:      	cmp	w16, wzr
    8610:      	b.eq	0x8620 <_stogir.types.size+0xd4>
    8614:      	uxtb	w16, w9
    8618:      	cmp	w16, wzr
    861c:      	b.ne	0x8624 <_stogir.types.size+0xd8>
    8620:      	movn	x7, #0x0, lsl #48
    8624:      	uxtb	w16, w4
    8628:      	cmp	w16, wzr
    862c:      	b.ne	0x8784 <_stogir.types.size+0x238>
    8630:      	uxtb	w16, w5
    8634:      	cmp	w16, wzr
    8638:      	b.ne	0x8784 <_stogir.types.size+0x238>
    863c:      	movn	x1, #0x0, lsl #48
    8640:      	b	0x86f8 <_stogir.types.size+0x1ac>
    8644:      	uxtb	w16, w4
    8648:      	cmp	w16, wzr
    864c:      	b.ne	0x8664 <_stogir.types.size+0x118>
    8650:      	uxtb	w16, w5
    8654:      	cmp	w16, wzr
    8658:      	b.ne	0x8664 <_stogir.types.size+0x118>
    865c:      	movn	x1, #0x0, lsl #48
    8660:      	b	0x867c <_stogir.types.size+0x130>
    8664:      	uxtb	w16, w3
    8668:      	cmp	w16, wzr
    866c:      	b.eq	0x8684 <_stogir.types.size+0x138>
    8670:      	movz	x1, #0x0, lsl #48
    8674:      	b	0x867c <_stogir.types.size+0x130>
    8678:      	mov	x1, #0x1                ; =1
    867c:      	mov	x0, x1
    8680:      	ret
    8684:      	cmp	x0, #0x1
    8688:      	b.eq	0x8678 <_stogir.types.size+0x12c>
    868c:      	cmp	x0, #0x2
    8690:      	b.eq	0x8678 <_stogir.types.size+0x12c>
    8694:      	cmp	x0, #0x7
    8698:      	b.eq	0x8678 <_stogir.types.size+0x12c>
    869c:      	cmp	x0, #0x8
    86a0:      	b.eq	0x8678 <_stogir.types.size+0x12c>
    86a4:      	cmp	x0, #0x3
    86a8:      	b.eq	0x880c <_stogir.types.size+0x2c0>
    86ac:      	cmp	x0, #0x9
    86b0:      	b.eq	0x880c <_stogir.types.size+0x2c0>
    86b4:      	cmp	x0, #0x4
    86b8:      	b.eq	0x883c <_stogir.types.size+0x2f0>
    86bc:      	cmp	x0, #0xa
    86c0:      	b.eq	0x883c <_stogir.types.size+0x2f0>
    86c4:      	cmp	x0, #0xd
    86c8:      	b.eq	0x883c <_stogir.types.size+0x2f0>
    86cc:      	cmp	x0, #0x5
    86d0:      	b.eq	0x884c <_stogir.types.size+0x300>
    86d4:      	cmp	x0, #0xb
    86d8:      	b.eq	0x884c <_stogir.types.size+0x300>
    86dc:      	cmp	x0, #0xc
    86e0:      	b.eq	0x884c <_stogir.types.size+0x300>
    86e4:      	cmp	x0, #0x6
    86e8:      	b.eq	0x86f0 <_stogir.types.size+0x1a4>
    86ec:      	movn	x1, #0x0, lsl #48
    86f0:      	b	0x8850 <_stogir.types.size+0x304>
    86f4:      	mov	x1, #0x1                ; =1
    86f8:      	lsr	w1, w1, #0
    86fc:      	sxtw	x1, w1
    8700:      	cmp	x1, #0x0
    8704:      	b.ge	0x8710 <_stogir.types.size+0x1c4>
    8708:      	movn	x1, #0x0, lsl #48
    870c:      	b	0x867c <_stogir.types.size+0x130>
    8710:      	uxtb	w16, w2
    8714:      	cmp	w16, wzr
    8718:      	b.eq	0x8814 <_stogir.types.size+0x2c8>
    871c:      	uxtb	w16, w6
    8720:      	cmp	w16, wzr
    8724:      	b.eq	0x8814 <_stogir.types.size+0x2c8>
    8728:      	uxtb	w16, w8
    872c:      	cmp	w16, wzr
    8730:      	b.eq	0x8814 <_stogir.types.size+0x2c8>
    8734:      	uxtb	w16, w9
    8738:      	cmp	w16, wzr
    873c:      	b.eq	0x8814 <_stogir.types.size+0x2c8>
    8740:      	ubfx	x0, x0, #4, #32
    8744:      	sxtw	x0, w0
    8748:      	sub	x0, x0, #0x1
    874c:      	lsr	w0, w0, #0
    8750:      	sxtw	x0, w0
    8754:      	mov	x16, #0x1               ; =1
    8758:      	lsl	x0, x16, x0
    875c:      	lsr	w0, w0, #0
    8760:      	sxtw	x0, w0
    8764:      	b	0x876c <_stogir.types.size+0x220>
    8768:      	movn	x0, #0x0, lsl #48
    876c:      	lsr	w0, w0, #0
    8770:      	sxtw	x0, w0
    8774:      	mul	x0, x0, x1
    8778:      	lsr	w0, w0, #0
    877c:      	sxtw	x1, w0
    8780:      	b	0x870c <_stogir.types.size+0x1c0>
    8784:      	lsr	w7, w7, #0
    8788:      	sxtw	x7, w7
    878c:      	cmp	x7, #0x0
    8790:      	b.ne	0x879c <_stogir.types.size+0x250>
    8794:      	movz	x1, #0x0, lsl #48
    8798:      	b	0x86f8 <_stogir.types.size+0x1ac>
    879c:      	cmp	x7, #0x1
    87a0:      	b.eq	0x86f4 <_stogir.types.size+0x1a8>
    87a4:      	cmp	x7, #0x2
    87a8:      	b.eq	0x86f4 <_stogir.types.size+0x1a8>
    87ac:      	cmp	x7, #0x7
    87b0:      	b.eq	0x86f4 <_stogir.types.size+0x1a8>
    87b4:      	cmp	x7, #0x8
    87b8:      	b.eq	0x86f4 <_stogir.types.size+0x1a8>
    87bc:      	cmp	x7, #0x3
    87c0:      	b.eq	0x8844 <_stogir.types.size+0x2f8>
    87c4:      	cmp	x7, #0x9
    87c8:      	b.eq	0x8844 <_stogir.types.size+0x2f8>
    87cc:      	cmp	x7, #0x4
    87d0:      	b.eq	0x8854 <_stogir.types.size+0x308>
    87d4:      	cmp	x7, #0xa
    87d8:      	b.eq	0x8854 <_stogir.types.size+0x308>
    87dc:      	cmp	x7, #0xd
    87e0:      	b.eq	0x8854 <_stogir.types.size+0x308>
    87e4:      	cmp	x7, #0x5
    87e8:      	b.eq	0x885c <_stogir.types.size+0x310>
    87ec:      	cmp	x7, #0xb
    87f0:      	b.eq	0x885c <_stogir.types.size+0x310>
    87f4:      	cmp	x7, #0xc
    87f8:      	b.eq	0x885c <_stogir.types.size+0x310>
    87fc:      	cmp	x7, #0x6
    8800:      	b.eq	0x8808 <_stogir.types.size+0x2bc>
    8804:      	movn	x1, #0x0, lsl #48
    8808:      	b	0x8860 <_stogir.types.size+0x314>
    880c:      	mov	x1, #0x2                ; =2
    8810:      	b	0x867c <_stogir.types.size+0x130>
    8814:      	uxtb	w16, w10
    8818:      	cmp	w16, wzr
    881c:      	b.eq	0x8768 <_stogir.types.size+0x21c>
    8820:      	uxtb	w16, w11
    8824:      	cmp	w16, wzr
    8828:      	b.eq	0x8768 <_stogir.types.size+0x21c>
    882c:      	uxtb	w16, w3
    8830:      	cmp	w16, wzr
    8834:      	cset	x0, eq
    8838:      	b	0x876c <_stogir.types.size+0x220>
    883c:      	mov	x1, #0x4                ; =4
    8840:      	b	0x8810 <_stogir.types.size+0x2c4>
    8844:      	mov	x1, #0x2                ; =2
    8848:      	b	0x86f8 <_stogir.types.size+0x1ac>
    884c:      	mov	x1, #0x8                ; =8
    8850:      	b	0x8840 <_stogir.types.size+0x2f4>
    8854:      	mov	x1, #0x4                ; =4
    8858:      	b	0x8848 <_stogir.types.size+0x2fc>
    885c:      	mov	x1, #0x8                ; =8
    8860:      	b	0x8858 <_stogir.types.size+0x30c>

0000000000008864 <_stogir.opcode.properties>:
    8864:      	sxtw	x0, w0
    8868:      	cmp	x0, #0x0
    886c:      	b.lt	0x8890 <_stogir.opcode.properties+0x2c>
    8870:      	cmp	x0, #0x83
    8874:      	b.ge	0x8890 <_stogir.opcode.properties+0x2c>
    8878:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008878:  ARM64_RELOC_PAGE21	l_stogir.427
    887c:      	ldr	x16, [x16]
		000000000000887c:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    8880:      	orr	x1, x16, xzr
    8884:      	add	x0, x1, x0
    8888:      	ldrb	w0, [x0]
    888c:      	b	0x8894 <_stogir.opcode.properties+0x30>
    8890:      	movz	x0, #0x0, lsl #48
    8894:      	ret

0000000000008898 <_stogir.checked.projection>:
    8898:      	sub	sp, sp, #0x40
    889c:      	str	x29, [sp]
    88a0:      	str	x30, [sp, #0x8]
    88a4:      	mov	x29, sp
    88a8:      	str	x19, [sp, #0x30]
    88ac:      	sxtw	x2, w1
    88b0:      	cmp	x2, #0x0
    88b4:      	cset	w3, gt
    88b8:      	movz	x16, #0x0, lsl #48
    88bc:      	sub	x4, x16, x2
    88c0:      	sub	x5, x4, #0x1
    88c4:      	uxtb	w16, w3
    88c8:      	cmp	w16, wzr
    88cc:      	b.eq	0x890c <_stogir.checked.projection+0x74>
    88d0:      	ldr	x4, [x0, #0x8]
    88d4:      	cmp	x2, x4
    88d8:      	b.ge	0x895c <_stogir.checked.projection+0xc4>
    88dc:      	add	x4, x0, #0x78
    88e0:      	ldr	x4, [x4, #0x8]
    88e4:      	cmp	x2, x4
    88e8:      	b.ge	0x8a68 <_stogir.checked.projection+0x1d0>
    88ec:      	ldr	x4, [x0, #0x78]
    88f0:      	add	x4, x4, x2, lsl #2
    88f4:      	ldr	w4, [x4]
    88f8:      	sxtw	x4, w4
    88fc:      	cmp	x4, #0x0
    8900:      	cset	w4, ge
    8904:      	ubfx	x4, x4, #0, #8
    8908:      	b	0x8a6c <_stogir.checked.projection+0x1d4>
    890c:      	cmp	x2, #0x0
    8910:      	b.ge	0x8964 <_stogir.checked.projection+0xcc>
    8914:      	add	x6, x0, #0x28
    8918:      	add	x7, x0, #0x50
    891c:      	ldr	x6, [x6, #0x8]
    8920:      	ldr	x7, [x7, #0x8]
    8924:      	cmp	x6, x7
    8928:      	b.ne	0x8954 <_stogir.checked.projection+0xbc>
    892c:      	cmp	x4, x6
    8930:      	b.gt	0x8a98 <_stogir.checked.projection+0x200>
    8934:      	ldr	x4, [x0, #0x50]
    8938:      	add	x4, x4, x5, lsl #2
    893c:      	ldr	w4, [x4]
    8940:      	sxtw	x4, w4
    8944:      	cmp	x4, #0x0
    8948:      	cset	w4, gt
    894c:      	ubfx	x4, x4, #0, #8
    8950:      	b	0x8a9c <_stogir.checked.projection+0x204>
    8954:      	movz	x4, #0x0, lsl #48
    8958:      	b	0x8968 <_stogir.checked.projection+0xd0>
    895c:      	movz	x4, #0x0, lsl #48
    8960:      	b	0x8968 <_stogir.checked.projection+0xd0>
    8964:      	movz	x4, #0x0, lsl #48
    8968:      	cmp	x4, #0x0
    896c:      	b.eq	0x89a0 <_stogir.checked.projection+0x108>
    8970:      	uxtb	w16, w3
    8974:      	cmp	w16, wzr
    8978:      	b.eq	0x898c <_stogir.checked.projection+0xf4>
    897c:      	ldr	x3, [x0]
    8980:      	add	x2, x3, x2, lsl #4
    8984:      	ldr	x2, [x2]
    8988:      	b	0x8998 <_stogir.checked.projection+0x100>
    898c:      	ldr	x2, [x0, #0x28]
    8990:      	add	x2, x2, x5, lsl #4
    8994:      	ldr	x2, [x2]
    8998:      	mov	x3, #0x1                ; =1
    899c:      	b	0x89a8 <_stogir.checked.projection+0x110>
    89a0:      	movz	x3, #0x0, lsl #48
    89a4:      	movz	x2, #0x0, lsl #48
    89a8:      	lsr	w3, w3, #0
    89ac:      	lsr	x16, x3, #0
    89b0:      	cmp	x16, #0x1
    89b4:      	b.eq	0x89d0 <_stogir.checked.projection+0x138>
    89b8:      	b.lo	0x89c0 <_stogir.checked.projection+0x128>
    89bc:      	b	0x89d4 <_stogir.checked.projection+0x13c>
    89c0:      	cmp	x16, #0x0
    89c4:      	b.eq	0x89cc <_stogir.checked.projection+0x134>
    89c8:      	b	0x89d4 <_stogir.checked.projection+0x13c>
    89cc:      	b	0x89d8 <_stogir.checked.projection+0x140>
    89d0:      	b	0x8a28 <_stogir.checked.projection+0x190>
    89d4:      	b	0x8aa0 <_stogir.checked.projection+0x208>
    89d8:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		00000000000089d8:  ARM64_RELOC_PAGE21	l_stogir.428
    89dc:      	ldr	x16, [x16]
		00000000000089dc:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    89e0:      	orr	x0, x16, xzr
    89e4:      	mov	x19, x8
    89e8:      	mov	x1, #0x1                ; =1
    89ec:      	mov	x2, #0x17               ; =23
    89f0:      	b	0x8a08 <_stogir.checked.projection+0x170>
    89f4:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		00000000000089f4:  ARM64_RELOC_PAGE21	l_stogir.429
    89f8:      	ldr	x16, [x16]
		00000000000089f8:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    89fc:      	orr	x0, x16, xzr
    8a00:      	mov	x1, #0x1                ; =1
    8a04:      	mov	x2, #0x20               ; =32
    8a08:      	str	x1, [x19]
    8a0c:      	str	x0, [x19, #0x8]
    8a10:      	str	x2, [x19, #0x10]
    8a14:      	ldr	x19, [sp, #0x30]
    8a18:      	ldr	x29, [sp]
    8a1c:      	ldr	x30, [sp, #0x8]
    8a20:      	add	sp, sp, #0x40
    8a24:      	ret
    8a28:      	uxtb	w3, w2
    8a2c:      	cmp	x3, #0x29
    8a30:      	b.lt	0x8aa8 <_stogir.checked.projection+0x210>
    8a34:      	cmp	x3, #0x2b
    8a38:      	b.gt	0x8ab0 <_stogir.checked.projection+0x218>
    8a3c:      	lsr	w1, w1, #0
    8a40:      	mov	x19, x8
    8a44:      	add	x8, sp, #0x10
    8a48:      	bl	0x8a48 <_stogir.checked.projection+0x1b0>
		0000000000008a48:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    8a4c:      	add	x16, sp, #0x10
    8a50:      	ldr	x1, [x16]
    8a54:      	add	x16, sp, #0x10
    8a58:      	ldr	x0, [x16, #0x8]
    8a5c:      	add	x16, sp, #0x10
    8a60:      	ldr	x2, [x16, #0x10]
    8a64:      	b	0x8a08 <_stogir.checked.projection+0x170>
    8a68:      	movz	x4, #0x0, lsl #48
    8a6c:      	b	0x8960 <_stogir.checked.projection+0xc8>
    8a70:      	lsr	w2, w2, #0
    8a74:      	ubfx	x0, x2, #8, #8
    8a78:      	cmp	x0, #0x0
    8a7c:      	b.eq	0x89f4 <_stogir.checked.projection+0x15c>
    8a80:      	cmp	x0, #0xd
    8a84:      	b.gt	0x89f4 <_stogir.checked.projection+0x15c>
    8a88:      	movz	x1, #0x0, lsl #48
    8a8c:      	movz	x0, #0x0, lsl #48
    8a90:      	movz	x2, #0x0, lsl #48
    8a94:      	b	0x8a08 <_stogir.checked.projection+0x170>
    8a98:      	movz	x4, #0x0, lsl #48
    8a9c:      	b	0x8958 <_stogir.checked.projection+0xc0>
    8aa0:      	brk	#0
    8aa4:      	b	0x8aa0 <_stogir.checked.projection+0x208>
    8aa8:      	mov	x19, x8
    8aac:      	b	0x8a70 <_stogir.checked.projection+0x1d8>
    8ab0:      	mov	x19, x8
    8ab4:      	b	0x8a70 <_stogir.checked.projection+0x1d8>

0000000000008ab8 <_stogir.checked.operands>:
    8ab8:      	sub	sp, sp, #0x30
    8abc:      	str	x19, [sp, #0x20]
    8ac0:      	str	x20, [sp, #0x28]
    8ac4:      	sxtw	x1, w1
    8ac8:      	sxtw	x2, w2
    8acc:      	cmp	x1, #0x29
    8ad0:      	b.lt	0x8b18 <_stogir.checked.operands+0x60>
    8ad4:      	cmp	x1, #0x2b
    8ad8:      	b.gt	0x8b18 <_stogir.checked.operands+0x60>
    8adc:      	cmp	x2, #0x1
    8ae0:      	b.lt	0x8b18 <_stogir.checked.operands+0x60>
    8ae4:      	cmp	x2, #0xb
    8ae8:      	b.gt	0x8b18 <_stogir.checked.operands+0x60>
    8aec:      	cmp	x2, #0x1
    8af0:      	b.eq	0x8b18 <_stogir.checked.operands+0x60>
    8af4:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008af4:  ARM64_RELOC_PAGE21	l_stogir.430
    8af8:      	ldr	x16, [x16]
		0000000000008af8:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    8afc:      	orr	x1, x16, xzr
    8b00:      	movz	x5, #0x0, lsl #48
    8b04:      	b	0x8b28 <_stogir.checked.operands+0x70>
    8b08:      	movz	x14, #0x0, lsl #48
    8b0c:      	b	0x8b88 <_stogir.checked.operands+0xd0>
    8b10:      	movz	x14, #0x0, lsl #48
    8b14:      	b	0x8b90 <_stogir.checked.operands+0xd8>
    8b18:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008b18:  ARM64_RELOC_PAGE21	l_stogir.431
    8b1c:      	ldr	x16, [x16]
		0000000000008b1c:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    8b20:      	orr	x1, x16, xzr
    8b24:      	mov	x5, #0x36               ; =54
    8b28:      	add	x16, sp, #0x10
    8b2c:      	orr	x6, x16, xzr
    8b30:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008b30:  ARM64_RELOC_PAGE21	l_stogir.432
    8b34:      	ldr	x16, [x16]
		0000000000008b34:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    8b38:      	orr	x7, x16, xzr
    8b3c:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008b3c:  ARM64_RELOC_PAGE21	l_stogir.433
    8b40:      	ldr	x16, [x16]
		0000000000008b40:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    8b44:      	orr	x9, x16, xzr
    8b48:      	lsr	w3, w3, #0
    8b4c:      	lsr	w4, w4, #0
    8b50:      	add	x10, x0, #0x78
    8b54:      	add	x11, x0, #0x28
    8b58:      	add	x12, x0, #0x50
    8b5c:      	mov	x16, sp
    8b60:      	str	w3, [x16]
    8b64:      	mov	x16, sp
    8b68:      	str	w4, [x16, #0x4]
    8b6c:      	mov	x16, sp
    8b70:      	ldr	x3, [x16]
    8b74:      	add	x16, sp, #0x10
    8b78:      	str	x3, [x16]
    8b7c:      	movz	x3, #0x0, lsl #48
    8b80:      	b	0x8c24 <_stogir.checked.operands+0x16c>
    8b84:      	movz	x14, #0x0, lsl #48
    8b88:      	b	0x8b90 <_stogir.checked.operands+0xd8>
    8b8c:      	movz	x14, #0x0, lsl #48
    8b90:      	cmp	x14, #0x0
    8b94:      	b.eq	0x8bc8 <_stogir.checked.operands+0x110>
    8b98:      	uxtb	w16, w4
    8b9c:      	cmp	w16, wzr
    8ba0:      	b.eq	0x8bb4 <_stogir.checked.operands+0xfc>
    8ba4:      	ldr	x4, [x0]
    8ba8:      	add	x4, x4, x13, lsl #4
    8bac:      	ldr	x4, [x4]
    8bb0:      	b	0x8bc0 <_stogir.checked.operands+0x108>
    8bb4:      	ldr	x4, [x0, #0x28]
    8bb8:      	add	x4, x4, x15, lsl #4
    8bbc:      	ldr	x4, [x4]
    8bc0:      	mov	x13, #0x1               ; =1
    8bc4:      	b	0x8bd0 <_stogir.checked.operands+0x118>
    8bc8:      	movz	x13, #0x0, lsl #48
    8bcc:      	movz	x4, #0x0, lsl #48
    8bd0:      	lsr	w13, w13, #0
    8bd4:      	lsr	x16, x13, #0
    8bd8:      	cmp	x16, #0x1
    8bdc:      	b.eq	0x8bf8 <_stogir.checked.operands+0x140>
    8be0:      	b.lo	0x8be8 <_stogir.checked.operands+0x130>
    8be4:      	b	0x8bfc <_stogir.checked.operands+0x144>
    8be8:      	cmp	x16, #0x0
    8bec:      	b.eq	0x8bf4 <_stogir.checked.operands+0x13c>
    8bf0:      	b	0x8bfc <_stogir.checked.operands+0x144>
    8bf4:      	b	0x8c00 <_stogir.checked.operands+0x148>
    8bf8:      	b	0x8c0c <_stogir.checked.operands+0x154>
    8bfc:      	b	0x8d6c <_stogir.checked.operands+0x2b4>
    8c00:      	mov	x1, x7
    8c04:      	mov	x5, #0x22               ; =34
    8c08:      	b	0x8c24 <_stogir.checked.operands+0x16c>
    8c0c:      	lsr	w4, w4, #0
    8c10:      	ubfx	x4, x4, #8, #8
    8c14:      	cmp	x4, x2
    8c18:      	b.eq	0x8c24 <_stogir.checked.operands+0x16c>
    8c1c:      	mov	x1, x9
    8c20:      	mov	x5, #0x28               ; =40
    8c24:      	cmp	x3, #0x2
    8c28:      	b.ge	0x8c4c <_stogir.checked.operands+0x194>
    8c2c:      	add	x4, x3, #0x1
    8c30:      	add	x3, x6, x3, lsl #2
    8c34:      	ldr	w3, [x3]
    8c38:      	sxtw	x3, w3
    8c3c:      	and	x13, x3, #0xffffffff
    8c40:      	mov	x3, x4
    8c44:      	mov	x4, #0x1                ; =1
    8c48:      	b	0x8c54 <_stogir.checked.operands+0x19c>
    8c4c:      	movz	x4, #0x0, lsl #48
    8c50:      	movz	x13, #0x0, lsl #48
    8c54:      	lsr	w4, w4, #0
    8c58:      	lsr	x16, x4, #0
    8c5c:      	cmp	x16, #0x1
    8c60:      	b.eq	0x8c7c <_stogir.checked.operands+0x1c4>
    8c64:      	b.lo	0x8c6c <_stogir.checked.operands+0x1b4>
    8c68:      	b	0x8c80 <_stogir.checked.operands+0x1c8>
    8c6c:      	cmp	x16, #0x0
    8c70:      	b.eq	0x8c78 <_stogir.checked.operands+0x1c0>
    8c74:      	b	0x8c80 <_stogir.checked.operands+0x1c8>
    8c78:      	b	0x8ce4 <_stogir.checked.operands+0x22c>
    8c7c:      	b	0x8c84 <_stogir.checked.operands+0x1cc>
    8c80:      	b	0x8d64 <_stogir.checked.operands+0x2ac>
    8c84:      	lsr	w13, w13, #0
    8c88:      	sxtw	x13, w13
    8c8c:      	cmp	x13, #0x0
    8c90:      	cset	w4, gt
    8c94:      	movz	x16, #0x0, lsl #48
    8c98:      	sub	x14, x16, x13
    8c9c:      	sub	x15, x14, #0x1
    8ca0:      	uxtb	w16, w4
    8ca4:      	cmp	w16, wzr
    8ca8:      	b.eq	0x8d1c <_stogir.checked.operands+0x264>
    8cac:      	ldr	x14, [x0, #0x8]
    8cb0:      	cmp	x13, x14
    8cb4:      	b.ge	0x8b84 <_stogir.checked.operands+0xcc>
    8cb8:      	ldr	x14, [x10, #0x8]
    8cbc:      	cmp	x13, x14
    8cc0:      	b.ge	0x8b08 <_stogir.checked.operands+0x50>
    8cc4:      	ldr	x14, [x0, #0x78]
    8cc8:      	add	x14, x14, x13, lsl #2
    8ccc:      	ldr	w14, [x14]
    8cd0:      	sxtw	x14, w14
    8cd4:      	cmp	x14, #0x0
    8cd8:      	cset	w14, ge
    8cdc:      	ubfx	x14, x14, #0, #8
    8ce0:      	b	0x8b0c <_stogir.checked.operands+0x54>
    8ce4:      	cmp	x5, #0x0
    8ce8:      	b.ne	0x8cfc <_stogir.checked.operands+0x244>
    8cec:      	and	x1, x2, #0xffffffff
    8cf0:      	movz	x0, #0x0, lsl #48
    8cf4:      	movz	x5, #0x0, lsl #48
    8cf8:      	b	0x8d00 <_stogir.checked.operands+0x248>
    8cfc:      	mov	x0, #0x1                ; =1
    8d00:      	str	x0, [x8]
    8d04:      	str	x1, [x8, #0x8]
    8d08:      	str	x5, [x8, #0x10]
    8d0c:      	ldr	x19, [sp, #0x20]
    8d10:      	ldr	x20, [sp, #0x28]
    8d14:      	add	sp, sp, #0x30
    8d18:      	ret
    8d1c:      	cmp	x13, #0x0
    8d20:      	b.ge	0x8b8c <_stogir.checked.operands+0xd4>
    8d24:      	ldr	x19, [x11, #0x8]
    8d28:      	ldr	x20, [x12, #0x8]
    8d2c:      	cmp	x19, x20
    8d30:      	b.ne	0x8b10 <_stogir.checked.operands+0x58>
    8d34:      	cmp	x14, x19
    8d38:      	b.gt	0x8d5c <_stogir.checked.operands+0x2a4>
    8d3c:      	ldr	x14, [x0, #0x50]
    8d40:      	add	x14, x14, x15, lsl #2
    8d44:      	ldr	w14, [x14]
    8d48:      	sxtw	x14, w14
    8d4c:      	cmp	x14, #0x0
    8d50:      	cset	w14, gt
    8d54:      	ubfx	x14, x14, #0, #8
    8d58:      	b	0x8d60 <_stogir.checked.operands+0x2a8>
    8d5c:      	movz	x14, #0x0, lsl #48
    8d60:      	b	0x8b14 <_stogir.checked.operands+0x5c>
    8d64:      	brk	#0
    8d68:      	b	0x8d64 <_stogir.checked.operands+0x2ac>
    8d6c:      	brk	#0
    8d70:      	b	0x8d6c <_stogir.checked.operands+0x2b4>

0000000000008d74 <_stogir.opcode.control?>:
    8d74:      	sxtw	x0, w0
    8d78:      	cmp	x0, #0x0
    8d7c:      	b.lt	0x8da0 <_stogir.opcode.control?+0x2c>
    8d80:      	cmp	x0, #0x83
    8d84:      	b.ge	0x8da0 <_stogir.opcode.control?+0x2c>
    8d88:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008d88:  ARM64_RELOC_PAGE21	l_stogir.434
    8d8c:      	ldr	x16, [x16]
		0000000000008d8c:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    8d90:      	orr	x1, x16, xzr
    8d94:      	add	x0, x1, x0
    8d98:      	ldrb	w0, [x0]
    8d9c:      	b	0x8da4 <_stogir.opcode.control?+0x30>
    8da0:      	movz	x0, #0x0, lsl #48
    8da4:      	uxtb	w0, w0
    8da8:      	and	x0, x0, #0x1
    8dac:      	uxtb	w0, w0
    8db0:      	ret

0000000000008db4 <_stogir.opcode.block-end?>:
    8db4:      	sxtw	x0, w0
    8db8:      	cmp	x0, #0x0
    8dbc:      	b.lt	0x8de0 <_stogir.opcode.block-end?+0x2c>
    8dc0:      	cmp	x0, #0x83
    8dc4:      	b.ge	0x8de0 <_stogir.opcode.block-end?+0x2c>
    8dc8:      	adrp	x16, 0x8000 <_stogir.vector.memory-inputs+0x178>
		0000000000008dc8:  ARM64_RELOC_PAGE21	l_stogir.435
    8dcc:      	ldr	x16, [x16]
		0000000000008dcc:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    8dd0:      	orr	x1, x16, xzr
    8dd4:      	add	x0, x1, x0
    8dd8:      	ldrb	w0, [x0]
    8ddc:      	b	0x8de4 <_stogir.opcode.block-end?+0x30>
    8de0:      	movz	x0, #0x0, lsl #48
    8de4:      	uxtb	w0, w0
    8de8:      	and	x0, x0, #0x4
    8dec:      	uxtb	w0, w0
    8df0:      	cmp	x0, #0x0
    8df4:      	cset	w0, eq
    8df8:      	uxtb	w16, w0
    8dfc:      	cmp	w16, wzr
    8e00:      	cset	x0, eq
    8e04:      	ret

0000000000008e08 <_stogir.atomic.ordinary?>:
    8e08:      	sxtw	x1, w1
    8e0c:      	cmp	x1, #0x0
    8e10:      	cset	w3, gt
    8e14:      	movz	x16, #0x0, lsl #48
    8e18:      	sub	x4, x16, x1
    8e1c:      	sub	x5, x4, #0x1
    8e20:      	uxtb	w16, w3
    8e24:      	cmp	w16, wzr
    8e28:      	b.eq	0x8e68 <_stogir.atomic.ordinary?+0x60>
    8e2c:      	ldr	x4, [x0, #0x8]
    8e30:      	cmp	x1, x4
    8e34:      	b.ge	0x8eb8 <_stogir.atomic.ordinary?+0xb0>
    8e38:      	add	x4, x0, #0x78
    8e3c:      	ldr	x4, [x4, #0x8]
    8e40:      	cmp	x1, x4
    8e44:      	b.ge	0x8f6c <_stogir.atomic.ordinary?+0x164>
    8e48:      	ldr	x4, [x0, #0x78]
    8e4c:      	add	x4, x4, x1, lsl #2
    8e50:      	ldr	w4, [x4]
    8e54:      	sxtw	x4, w4
    8e58:      	cmp	x4, #0x0
    8e5c:      	cset	w4, ge
    8e60:      	ubfx	x4, x4, #0, #8
    8e64:      	b	0x8f70 <_stogir.atomic.ordinary?+0x168>
    8e68:      	cmp	x1, #0x0
    8e6c:      	b.ge	0x8ec0 <_stogir.atomic.ordinary?+0xb8>
    8e70:      	add	x6, x0, #0x28
    8e74:      	add	x7, x0, #0x50
    8e78:      	ldr	x6, [x6, #0x8]
    8e7c:      	ldr	x7, [x7, #0x8]
    8e80:      	cmp	x6, x7
    8e84:      	b.ne	0x8eb0 <_stogir.atomic.ordinary?+0xa8>
    8e88:      	cmp	x4, x6
    8e8c:      	b.gt	0x8f8c <_stogir.atomic.ordinary?+0x184>
    8e90:      	ldr	x4, [x0, #0x50]
    8e94:      	add	x4, x4, x5, lsl #2
    8e98:      	ldr	w4, [x4]
    8e9c:      	sxtw	x4, w4
    8ea0:      	cmp	x4, #0x0
    8ea4:      	cset	w4, gt
    8ea8:      	ubfx	x4, x4, #0, #8
    8eac:      	b	0x8f90 <_stogir.atomic.ordinary?+0x188>
    8eb0:      	movz	x4, #0x0, lsl #48
    8eb4:      	b	0x8ec4 <_stogir.atomic.ordinary?+0xbc>
    8eb8:      	movz	x4, #0x0, lsl #48
    8ebc:      	b	0x8ec4 <_stogir.atomic.ordinary?+0xbc>
    8ec0:      	movz	x4, #0x0, lsl #48
    8ec4:      	cmp	x4, #0x0
    8ec8:      	b.eq	0x8efc <_stogir.atomic.ordinary?+0xf4>
    8ecc:      	uxtb	w16, w3
    8ed0:      	cmp	w16, wzr
    8ed4:      	b.eq	0x8ee8 <_stogir.atomic.ordinary?+0xe0>
    8ed8:      	ldr	x0, [x0]
    8edc:      	add	x0, x0, x1, lsl #4
    8ee0:      	ldr	x0, [x0]
    8ee4:      	b	0x8ef4 <_stogir.atomic.ordinary?+0xec>
    8ee8:      	ldr	x0, [x0, #0x28]
    8eec:      	add	x0, x0, x5, lsl #4
    8ef0:      	ldr	x0, [x0]
    8ef4:      	mov	x1, #0x1                ; =1
    8ef8:      	b	0x8f04 <_stogir.atomic.ordinary?+0xfc>
    8efc:      	movz	x1, #0x0, lsl #48
    8f00:      	movz	x0, #0x0, lsl #48
    8f04:      	lsr	w1, w1, #0
    8f08:      	lsr	x16, x1, #0
    8f0c:      	cmp	x16, #0x1
    8f10:      	b.eq	0x8f2c <_stogir.atomic.ordinary?+0x124>
    8f14:      	b.lo	0x8f1c <_stogir.atomic.ordinary?+0x114>
    8f18:      	b	0x8f30 <_stogir.atomic.ordinary?+0x128>
    8f1c:      	cmp	x16, #0x0
    8f20:      	b.eq	0x8f28 <_stogir.atomic.ordinary?+0x120>
    8f24:      	b	0x8f30 <_stogir.atomic.ordinary?+0x128>
    8f28:      	b	0x8f34 <_stogir.atomic.ordinary?+0x12c>
    8f2c:      	b	0x8f44 <_stogir.atomic.ordinary?+0x13c>
    8f30:      	b	0x8f94 <_stogir.atomic.ordinary?+0x18c>
    8f34:      	movz	x0, #0x0, lsl #48
    8f38:      	b	0x8f40 <_stogir.atomic.ordinary?+0x138>
    8f3c:      	movz	x0, #0x0, lsl #48
    8f40:      	ret
    8f44:      	sxtw	x2, w2
    8f48:      	lsr	w1, w0, #0
    8f4c:      	ubfx	x1, x1, #8, #8
    8f50:      	cmp	x1, x2
    8f54:      	b.ne	0x8f3c <_stogir.atomic.ordinary?+0x134>
    8f58:      	uxtb	w0, w0
    8f5c:      	cmp	x0, #0x46
    8f60:      	b.ne	0x8f74 <_stogir.atomic.ordinary?+0x16c>
    8f64:      	movz	x0, #0x0, lsl #48
    8f68:      	b	0x8f88 <_stogir.atomic.ordinary?+0x180>
    8f6c:      	movz	x4, #0x0, lsl #48
    8f70:      	b	0x8ebc <_stogir.atomic.ordinary?+0xb4>
    8f74:      	cmp	x0, #0x48
    8f78:      	cset	w0, eq
    8f7c:      	uxtb	w16, w0
    8f80:      	cmp	w16, wzr
    8f84:      	cset	x0, eq
    8f88:      	b	0x8f40 <_stogir.atomic.ordinary?+0x138>
    8f8c:      	movz	x4, #0x0, lsl #48
    8f90:      	b	0x8eb4 <_stogir.atomic.ordinary?+0xac>
    8f94:      	brk	#0
    8f98:      	b	0x8f94 <_stogir.atomic.ordinary?+0x18c>

0000000000008f9c <_stogir.types.scalar-size>:
    8f9c:      	sxtw	x1, w1
    8fa0:      	cmp	x1, #0x4
    8fa4:      	b.eq	0x8fb8 <_stogir.types.scalar-size+0x1c>
    8fa8:      	cmp	x1, #0x8
    8fac:      	b.eq	0x8fb8 <_stogir.types.scalar-size+0x1c>
    8fb0:      	movn	x1, #0x0, lsl #48
    8fb4:      	b	0x8fd0 <_stogir.types.scalar-size+0x34>
    8fb8:      	sxtw	x0, w0
    8fbc:      	cmp	x0, #0x0
    8fc0:      	b.ne	0x8fd8 <_stogir.types.scalar-size+0x3c>
    8fc4:      	movz	x1, #0x0, lsl #48
    8fc8:      	b	0x8fd0 <_stogir.types.scalar-size+0x34>
    8fcc:      	mov	x1, #0x1                ; =1
    8fd0:      	mov	x0, x1
    8fd4:      	ret
    8fd8:      	cmp	x0, #0x1
    8fdc:      	b.eq	0x8fcc <_stogir.types.scalar-size+0x30>
    8fe0:      	cmp	x0, #0x2
    8fe4:      	b.eq	0x8fcc <_stogir.types.scalar-size+0x30>
    8fe8:      	cmp	x0, #0x7
    8fec:      	b.eq	0x8fcc <_stogir.types.scalar-size+0x30>
    8ff0:      	cmp	x0, #0x8
    8ff4:      	b.eq	0x8fcc <_stogir.types.scalar-size+0x30>
    8ff8:      	cmp	x0, #0x3
    8ffc:      	b.eq	0x9048 <_stogir.types.scalar-size+0xac>
    9000:      	cmp	x0, #0x9
    9004:      	b.eq	0x9048 <_stogir.types.scalar-size+0xac>
    9008:      	cmp	x0, #0x4
    900c:      	b.eq	0x9050 <_stogir.types.scalar-size+0xb4>
    9010:      	cmp	x0, #0xa
    9014:      	b.eq	0x9050 <_stogir.types.scalar-size+0xb4>
    9018:      	cmp	x0, #0xd
    901c:      	b.eq	0x9050 <_stogir.types.scalar-size+0xb4>
    9020:      	cmp	x0, #0x5
    9024:      	b.eq	0x9058 <_stogir.types.scalar-size+0xbc>
    9028:      	cmp	x0, #0xb
    902c:      	b.eq	0x9058 <_stogir.types.scalar-size+0xbc>
    9030:      	cmp	x0, #0xc
    9034:      	b.eq	0x9058 <_stogir.types.scalar-size+0xbc>
    9038:      	cmp	x0, #0x6
    903c:      	b.eq	0x9044 <_stogir.types.scalar-size+0xa8>
    9040:      	movn	x1, #0x0, lsl #48
    9044:      	b	0x905c <_stogir.types.scalar-size+0xc0>
    9048:      	mov	x1, #0x2                ; =2
    904c:      	b	0x8fd0 <_stogir.types.scalar-size+0x34>
    9050:      	mov	x1, #0x4                ; =4
    9054:      	b	0x904c <_stogir.types.scalar-size+0xb0>
    9058:      	mov	x1, #0x8                ; =8
    905c:      	b	0x9054 <_stogir.types.scalar-size+0xb8>

0000000000009060 <_stogir.terminal.inputs>:
    9060:      	sxtw	x1, w1
    9064:      	cmp	x1, #0x60
    9068:      	cset	w4, eq
    906c:      	uxtb	w16, w4
    9070:      	cmp	w16, wzr
    9074:      	b.ne	0x90a4 <_stogir.terminal.inputs+0x44>
    9078:      	cmp	x1, #0x79
    907c:      	b.eq	0x90a4 <_stogir.terminal.inputs+0x44>
    9080:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009080:  ARM64_RELOC_PAGE21	l_stogir.436
    9084:      	ldr	x16, [x16]
		0000000000009084:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    9088:      	orr	x0, x16, xzr
    908c:      	mov	x1, #0x1                ; =1
    9090:      	mov	x2, #0x25               ; =37
    9094:      	str	x1, [x8]
    9098:      	str	x0, [x8, #0x8]
    909c:      	str	x2, [x8, #0x10]
    90a0:      	ret
    90a4:      	sxtw	x3, w3
    90a8:      	uxtb	w16, w4
    90ac:      	cmp	w16, wzr
    90b0:      	b.eq	0x90bc <_stogir.terminal.inputs+0x5c>
    90b4:      	cmp	x3, #0x0
    90b8:      	b.ne	0x9080 <_stogir.terminal.inputs+0x20>
    90bc:      	sxtw	x2, w2
    90c0:      	cmp	x2, #0x0
    90c4:      	cset	w1, gt
    90c8:      	movz	x16, #0x0, lsl #48
    90cc:      	sub	x4, x16, x2
    90d0:      	sub	x5, x4, #0x1
    90d4:      	uxtb	w16, w1
    90d8:      	cmp	w16, wzr
    90dc:      	b.eq	0x91b0 <_stogir.terminal.inputs+0x150>
    90e0:      	ldr	x4, [x0, #0x8]
    90e4:      	cmp	x2, x4
    90e8:      	b.ge	0x91a8 <_stogir.terminal.inputs+0x148>
    90ec:      	add	x4, x0, #0x78
    90f0:      	ldr	x4, [x4, #0x8]
    90f4:      	cmp	x2, x4
    90f8:      	b.ge	0x9250 <_stogir.terminal.inputs+0x1f0>
    90fc:      	ldr	x4, [x0, #0x78]
    9100:      	add	x4, x4, x2, lsl #2
    9104:      	ldr	w4, [x4]
    9108:      	sxtw	x4, w4
    910c:      	cmp	x4, #0x0
    9110:      	cset	w4, ge
    9114:      	ubfx	x4, x4, #0, #8
    9118:      	b	0x9254 <_stogir.terminal.inputs+0x1f4>
    911c:      	movz	x4, #0x0, lsl #48
    9120:      	movz	x1, #0x0, lsl #48
    9124:      	lsr	w4, w4, #0
    9128:      	lsr	x16, x4, #0
    912c:      	cmp	x16, #0x1
    9130:      	b.eq	0x914c <_stogir.terminal.inputs+0xec>
    9134:      	b.lo	0x913c <_stogir.terminal.inputs+0xdc>
    9138:      	b	0x9150 <_stogir.terminal.inputs+0xf0>
    913c:      	cmp	x16, #0x0
    9140:      	b.eq	0x9148 <_stogir.terminal.inputs+0xe8>
    9144:      	b	0x9150 <_stogir.terminal.inputs+0xf0>
    9148:      	b	0x9154 <_stogir.terminal.inputs+0xf4>
    914c:      	b	0x91f8 <_stogir.terminal.inputs+0x198>
    9150:      	b	0x939c <_stogir.terminal.inputs+0x33c>
    9154:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009154:  ARM64_RELOC_PAGE21	l_stogir.437
    9158:      	ldr	x16, [x16]
		0000000000009158:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    915c:      	orr	x0, x16, xzr
    9160:      	mov	x1, #0x1                ; =1
    9164:      	mov	x2, #0x1d               ; =29
    9168:      	b	0x9094 <_stogir.terminal.inputs+0x34>
    916c:      	ldr	x1, [x0, #0x28]
    9170:      	add	x1, x1, x5, lsl #4
    9174:      	ldr	x1, [x1]
    9178:      	mov	x4, #0x1                ; =1
    917c:      	b	0x9124 <_stogir.terminal.inputs+0xc4>
    9180:      	movz	x4, #0x0, lsl #48
    9184:      	cmp	x4, #0x0
    9188:      	b.eq	0x911c <_stogir.terminal.inputs+0xbc>
    918c:      	uxtb	w16, w1
    9190:      	cmp	w16, wzr
    9194:      	b.eq	0x916c <_stogir.terminal.inputs+0x10c>
    9198:      	ldr	x1, [x0]
    919c:      	add	x1, x1, x2, lsl #4
    91a0:      	ldr	x1, [x1]
    91a4:      	b	0x9178 <_stogir.terminal.inputs+0x118>
    91a8:      	movz	x4, #0x0, lsl #48
    91ac:      	b	0x9184 <_stogir.terminal.inputs+0x124>
    91b0:      	cmp	x2, #0x0
    91b4:      	b.ge	0x9180 <_stogir.terminal.inputs+0x120>
    91b8:      	add	x6, x0, #0x28
    91bc:      	add	x7, x0, #0x50
    91c0:      	ldr	x6, [x6, #0x8]
    91c4:      	ldr	x7, [x7, #0x8]
    91c8:      	cmp	x6, x7
    91cc:      	b.ne	0x9248 <_stogir.terminal.inputs+0x1e8>
    91d0:      	cmp	x4, x6
    91d4:      	b.gt	0x9258 <_stogir.terminal.inputs+0x1f8>
    91d8:      	ldr	x4, [x0, #0x50]
    91dc:      	add	x4, x4, x5, lsl #2
    91e0:      	ldr	w4, [x4]
    91e4:      	sxtw	x4, w4
    91e8:      	cmp	x4, #0x0
    91ec:      	cset	w4, gt
    91f0:      	ubfx	x4, x4, #0, #8
    91f4:      	b	0x925c <_stogir.terminal.inputs+0x1fc>
    91f8:      	cmp	x2, #0x0
    91fc:      	b.le	0x9230 <_stogir.terminal.inputs+0x1d0>
    9200:      	uxtb	w1, w1
    9204:      	cmp	x1, #0x83
    9208:      	cset	w2, lt
    920c:      	uxtb	w16, w2
    9210:      	cmp	w16, wzr
    9214:      	b.eq	0x9260 <_stogir.terminal.inputs+0x200>
    9218:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009218:  ARM64_RELOC_PAGE21	l_stogir.438
    921c:      	ldr	x16, [x16]
		000000000000921c:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9220:      	orr	x4, x16, xzr
    9224:      	add	x4, x1, x4
    9228:      	ldrb	w4, [x4]
    922c:      	b	0x9264 <_stogir.terminal.inputs+0x204>
    9230:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009230:  ARM64_RELOC_PAGE21	l_stogir.439
    9234:      	ldr	x16, [x16]
		0000000000009234:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    9238:      	orr	x0, x16, xzr
    923c:      	mov	x1, #0x1                ; =1
    9240:      	mov	x2, #0x2c               ; =44
    9244:      	b	0x9168 <_stogir.terminal.inputs+0x108>
    9248:      	movz	x4, #0x0, lsl #48
    924c:      	b	0x9184 <_stogir.terminal.inputs+0x124>
    9250:      	movz	x4, #0x0, lsl #48
    9254:      	b	0x91ac <_stogir.terminal.inputs+0x14c>
    9258:      	movz	x4, #0x0, lsl #48
    925c:      	b	0x924c <_stogir.terminal.inputs+0x1ec>
    9260:      	movz	x4, #0x0, lsl #48
    9264:      	uxtb	w4, w4
    9268:      	and	x4, x4, #0x1
    926c:      	uxtb	w4, w4
    9270:      	cmp	x4, #0x0
    9274:      	b.eq	0x9230 <_stogir.terminal.inputs+0x1d0>
    9278:      	uxtb	w16, w2
    927c:      	cmp	w16, wzr
    9280:      	b.eq	0x929c <_stogir.terminal.inputs+0x23c>
    9284:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009284:  ARM64_RELOC_PAGE21	l_stogir.438
    9288:      	ldr	x16, [x16]
		0000000000009288:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    928c:      	orr	x2, x16, xzr
    9290:      	add	x1, x1, x2
    9294:      	ldrb	w1, [x1]
    9298:      	b	0x92a0 <_stogir.terminal.inputs+0x240>
    929c:      	movz	x1, #0x0, lsl #48
    92a0:      	uxtb	w1, w1
    92a4:      	and	x1, x1, #0x4
    92a8:      	uxtb	w1, w1
    92ac:      	cmp	x1, #0x0
    92b0:      	cset	w1, eq
    92b4:      	uxtb	w16, w1
    92b8:      	cmp	w16, wzr
    92bc:      	cset	x1, eq
    92c0:      	cmp	x1, #0x0
    92c4:      	b.ne	0x9230 <_stogir.terminal.inputs+0x1d0>
    92c8:      	cmp	x3, #0x0
    92cc:      	b.ne	0x92e0 <_stogir.terminal.inputs+0x280>
    92d0:      	movz	x1, #0x0, lsl #48
    92d4:      	movz	x0, #0x0, lsl #48
    92d8:      	movz	x2, #0x0, lsl #48
    92dc:      	b	0x9244 <_stogir.terminal.inputs+0x1e4>
    92e0:      	cmp	x3, #0x0
    92e4:      	cset	w1, gt
    92e8:      	movz	x16, #0x0, lsl #48
    92ec:      	sub	x2, x16, x3
    92f0:      	sub	x4, x2, #0x1
    92f4:      	uxtb	w16, w1
    92f8:      	cmp	w16, wzr
    92fc:      	b.eq	0x9354 <_stogir.terminal.inputs+0x2f4>
    9300:      	ldr	x2, [x0, #0x8]
    9304:      	cmp	x3, x2
    9308:      	b.ge	0x93a4 <_stogir.terminal.inputs+0x344>
    930c:      	add	x2, x0, #0x78
    9310:      	ldr	x2, [x2, #0x8]
    9314:      	cmp	x3, x2
    9318:      	b.ge	0x946c <_stogir.terminal.inputs+0x40c>
    931c:      	ldr	x2, [x0, #0x78]
    9320:      	add	x2, x2, x3, lsl #2
    9324:      	ldr	w2, [x2]
    9328:      	sxtw	x2, w2
    932c:      	cmp	x2, #0x0
    9330:      	cset	w2, ge
    9334:      	ubfx	x2, x2, #0, #8
    9338:      	b	0x9470 <_stogir.terminal.inputs+0x410>
    933c:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		000000000000933c:  ARM64_RELOC_PAGE21	l_stogir.440
    9340:      	ldr	x16, [x16]
		0000000000009340:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    9344:      	orr	x0, x16, xzr
    9348:      	mov	x1, #0x1                ; =1
    934c:      	mov	x2, #0x2e               ; =46
    9350:      	b	0x92dc <_stogir.terminal.inputs+0x27c>
    9354:      	cmp	x3, #0x0
    9358:      	b.ge	0x93ac <_stogir.terminal.inputs+0x34c>
    935c:      	add	x5, x0, #0x28
    9360:      	add	x6, x0, #0x50
    9364:      	ldr	x5, [x5, #0x8]
    9368:      	ldr	x6, [x6, #0x8]
    936c:      	cmp	x5, x6
    9370:      	b.ne	0x9464 <_stogir.terminal.inputs+0x404>
    9374:      	cmp	x2, x5
    9378:      	b.gt	0x9474 <_stogir.terminal.inputs+0x414>
    937c:      	ldr	x2, [x0, #0x50]
    9380:      	add	x2, x2, x4, lsl #2
    9384:      	ldr	w2, [x2]
    9388:      	sxtw	x2, w2
    938c:      	cmp	x2, #0x0
    9390:      	cset	w2, gt
    9394:      	ubfx	x2, x2, #0, #8
    9398:      	b	0x9478 <_stogir.terminal.inputs+0x418>
    939c:      	brk	#0
    93a0:      	b	0x939c <_stogir.terminal.inputs+0x33c>
    93a4:      	movz	x2, #0x0, lsl #48
    93a8:      	b	0x93b0 <_stogir.terminal.inputs+0x350>
    93ac:      	movz	x2, #0x0, lsl #48
    93b0:      	cmp	x2, #0x0
    93b4:      	b.eq	0x93e8 <_stogir.terminal.inputs+0x388>
    93b8:      	uxtb	w16, w1
    93bc:      	cmp	w16, wzr
    93c0:      	b.eq	0x93d4 <_stogir.terminal.inputs+0x374>
    93c4:      	ldr	x0, [x0]
    93c8:      	add	x0, x0, x3, lsl #4
    93cc:      	ldr	x0, [x0]
    93d0:      	b	0x93e0 <_stogir.terminal.inputs+0x380>
    93d4:      	ldr	x0, [x0, #0x28]
    93d8:      	add	x0, x0, x4, lsl #4
    93dc:      	ldr	x0, [x0]
    93e0:      	mov	x1, #0x1                ; =1
    93e4:      	b	0x93f0 <_stogir.terminal.inputs+0x390>
    93e8:      	movz	x1, #0x0, lsl #48
    93ec:      	movz	x0, #0x0, lsl #48
    93f0:      	lsr	w1, w1, #0
    93f4:      	lsr	x16, x1, #0
    93f8:      	cmp	x16, #0x1
    93fc:      	b.eq	0x9418 <_stogir.terminal.inputs+0x3b8>
    9400:      	b.lo	0x9408 <_stogir.terminal.inputs+0x3a8>
    9404:      	b	0x941c <_stogir.terminal.inputs+0x3bc>
    9408:      	cmp	x16, #0x0
    940c:      	b.eq	0x9414 <_stogir.terminal.inputs+0x3b4>
    9410:      	b	0x941c <_stogir.terminal.inputs+0x3bc>
    9414:      	b	0x9420 <_stogir.terminal.inputs+0x3c0>
    9418:      	b	0x9438 <_stogir.terminal.inputs+0x3d8>
    941c:      	b	0x94b8 <_stogir.terminal.inputs+0x458>
    9420:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009420:  ARM64_RELOC_PAGE21	l_stogir.441
    9424:      	ldr	x16, [x16]
		0000000000009424:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    9428:      	orr	x0, x16, xzr
    942c:      	mov	x1, #0x1                ; =1
    9430:      	mov	x2, #0x1d               ; =29
    9434:      	b	0x9350 <_stogir.terminal.inputs+0x2f0>
    9438:      	cmp	x3, #0x0
    943c:      	b.le	0x933c <_stogir.terminal.inputs+0x2dc>
    9440:      	uxtb	w0, w0
    9444:      	cmp	x0, #0x83
    9448:      	b.ge	0x947c <_stogir.terminal.inputs+0x41c>
    944c:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		000000000000944c:  ARM64_RELOC_PAGE21	l_stogir.438
    9450:      	ldr	x16, [x16]
		0000000000009450:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9454:      	orr	x1, x16, xzr
    9458:      	add	x0, x0, x1
    945c:      	ldrb	w0, [x0]
    9460:      	b	0x9480 <_stogir.terminal.inputs+0x420>
    9464:      	movz	x2, #0x0, lsl #48
    9468:      	b	0x93b0 <_stogir.terminal.inputs+0x350>
    946c:      	movz	x2, #0x0, lsl #48
    9470:      	b	0x93a8 <_stogir.terminal.inputs+0x348>
    9474:      	movz	x2, #0x0, lsl #48
    9478:      	b	0x9468 <_stogir.terminal.inputs+0x408>
    947c:      	movz	x0, #0x0, lsl #48
    9480:      	uxtb	w0, w0
    9484:      	and	x0, x0, #0x8
    9488:      	uxtb	w0, w0
    948c:      	cmp	x0, #0x0
    9490:      	cset	w0, eq
    9494:      	uxtb	w16, w0
    9498:      	cmp	w16, wzr
    949c:      	cset	x0, eq
    94a0:      	cmp	x0, #0x0
    94a4:      	b.eq	0x933c <_stogir.terminal.inputs+0x2dc>
    94a8:      	and	x0, x3, #0xffffffff
    94ac:      	movz	x1, #0x0, lsl #48
    94b0:      	movz	x2, #0x0, lsl #48
    94b4:      	b	0x9350 <_stogir.terminal.inputs+0x2f0>
    94b8:      	brk	#0
    94bc:      	b	0x94b8 <_stogir.terminal.inputs+0x458>

00000000000094c0 <_stogir.switch.switch-inputs>:
    94c0:      	sxtw	x1, w1
    94c4:      	cmp	x1, #0x0
    94c8:      	cset	w3, gt
    94cc:      	movz	x16, #0x0, lsl #48
    94d0:      	sub	x4, x16, x1
    94d4:      	sub	x5, x4, #0x1
    94d8:      	uxtb	w16, w3
    94dc:      	cmp	w16, wzr
    94e0:      	b.eq	0x9520 <_stogir.switch.switch-inputs+0x60>
    94e4:      	ldr	x4, [x0, #0x8]
    94e8:      	cmp	x1, x4
    94ec:      	b.ge	0x9588 <_stogir.switch.switch-inputs+0xc8>
    94f0:      	add	x4, x0, #0x78
    94f4:      	ldr	x4, [x4, #0x8]
    94f8:      	cmp	x1, x4
    94fc:      	b.ge	0x9660 <_stogir.switch.switch-inputs+0x1a0>
    9500:      	ldr	x4, [x0, #0x78]
    9504:      	add	x4, x4, x1, lsl #2
    9508:      	ldr	w4, [x4]
    950c:      	sxtw	x4, w4
    9510:      	cmp	x4, #0x0
    9514:      	cset	w4, ge
    9518:      	ubfx	x4, x4, #0, #8
    951c:      	b	0x9664 <_stogir.switch.switch-inputs+0x1a4>
    9520:      	cmp	x1, #0x0
    9524:      	b.ge	0x9590 <_stogir.switch.switch-inputs+0xd0>
    9528:      	add	x6, x0, #0x28
    952c:      	add	x7, x0, #0x50
    9530:      	ldr	x6, [x6, #0x8]
    9534:      	ldr	x7, [x7, #0x8]
    9538:      	cmp	x6, x7
    953c:      	b.ne	0x9568 <_stogir.switch.switch-inputs+0xa8>
    9540:      	cmp	x4, x6
    9544:      	b.gt	0x9668 <_stogir.switch.switch-inputs+0x1a8>
    9548:      	ldr	x4, [x0, #0x50]
    954c:      	add	x4, x4, x5, lsl #2
    9550:      	ldr	w4, [x4]
    9554:      	sxtw	x4, w4
    9558:      	cmp	x4, #0x0
    955c:      	cset	w4, gt
    9560:      	ubfx	x4, x4, #0, #8
    9564:      	b	0x966c <_stogir.switch.switch-inputs+0x1ac>
    9568:      	movz	x4, #0x0, lsl #48
    956c:      	b	0x9594 <_stogir.switch.switch-inputs+0xd4>
    9570:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009570:  ARM64_RELOC_PAGE21	l_stogir.442
    9574:      	ldr	x16, [x16]
		0000000000009574:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    9578:      	orr	x0, x16, xzr
    957c:      	mov	x1, #0x1                ; =1
    9580:      	mov	x2, #0x16               ; =22
    9584:      	b	0x9618 <_stogir.switch.switch-inputs+0x158>
    9588:      	movz	x4, #0x0, lsl #48
    958c:      	b	0x9594 <_stogir.switch.switch-inputs+0xd4>
    9590:      	movz	x4, #0x0, lsl #48
    9594:      	cmp	x4, #0x0
    9598:      	b.eq	0x95cc <_stogir.switch.switch-inputs+0x10c>
    959c:      	uxtb	w16, w3
    95a0:      	cmp	w16, wzr
    95a4:      	b.eq	0x95b8 <_stogir.switch.switch-inputs+0xf8>
    95a8:      	ldr	x3, [x0]
    95ac:      	add	x3, x3, x1, lsl #4
    95b0:      	ldr	x3, [x3]
    95b4:      	b	0x95c4 <_stogir.switch.switch-inputs+0x104>
    95b8:      	ldr	x3, [x0, #0x28]
    95bc:      	add	x3, x3, x5, lsl #4
    95c0:      	ldr	x3, [x3]
    95c4:      	mov	x4, #0x1                ; =1
    95c8:      	b	0x95d4 <_stogir.switch.switch-inputs+0x114>
    95cc:      	movz	x4, #0x0, lsl #48
    95d0:      	movz	x3, #0x0, lsl #48
    95d4:      	lsr	w4, w4, #0
    95d8:      	lsr	x16, x4, #0
    95dc:      	cmp	x16, #0x1
    95e0:      	b.eq	0x95fc <_stogir.switch.switch-inputs+0x13c>
    95e4:      	b.lo	0x95ec <_stogir.switch.switch-inputs+0x12c>
    95e8:      	b	0x9600 <_stogir.switch.switch-inputs+0x140>
    95ec:      	cmp	x16, #0x0
    95f0:      	b.eq	0x95f8 <_stogir.switch.switch-inputs+0x138>
    95f4:      	b	0x9600 <_stogir.switch.switch-inputs+0x140>
    95f8:      	b	0x9604 <_stogir.switch.switch-inputs+0x144>
    95fc:      	b	0x9628 <_stogir.switch.switch-inputs+0x168>
    9600:      	b	0x9870 <_stogir.switch.switch-inputs+0x3b0>
    9604:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009604:  ARM64_RELOC_PAGE21	l_stogir.443
    9608:      	ldr	x16, [x16]
		0000000000009608:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    960c:      	orr	x0, x16, xzr
    9610:      	mov	x1, #0x1                ; =1
    9614:      	mov	x2, #0x16               ; =22
    9618:      	str	x1, [x8]
    961c:      	str	x0, [x8, #0x8]
    9620:      	str	x2, [x8, #0x10]
    9624:      	ret
    9628:      	cmp	x1, #0x0
    962c:      	b.le	0x9570 <_stogir.switch.switch-inputs+0xb0>
    9630:      	uxtb	w3, w3
    9634:      	cmp	x3, #0x83
    9638:      	cset	w1, lt
    963c:      	uxtb	w16, w1
    9640:      	cmp	w16, wzr
    9644:      	b.eq	0x9670 <_stogir.switch.switch-inputs+0x1b0>
    9648:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009648:  ARM64_RELOC_PAGE21	l_stogir.444
    964c:      	ldr	x16, [x16]
		000000000000964c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    9650:      	orr	x4, x16, xzr
    9654:      	add	x4, x3, x4
    9658:      	ldrb	w4, [x4]
    965c:      	b	0x9674 <_stogir.switch.switch-inputs+0x1b4>
    9660:      	movz	x4, #0x0, lsl #48
    9664:      	b	0x958c <_stogir.switch.switch-inputs+0xcc>
    9668:      	movz	x4, #0x0, lsl #48
    966c:      	b	0x956c <_stogir.switch.switch-inputs+0xac>
    9670:      	movz	x4, #0x0, lsl #48
    9674:      	uxtb	w4, w4
    9678:      	and	x4, x4, #0x1
    967c:      	uxtb	w4, w4
    9680:      	cmp	x4, #0x0
    9684:      	b.eq	0x9570 <_stogir.switch.switch-inputs+0xb0>
    9688:      	uxtb	w16, w1
    968c:      	cmp	w16, wzr
    9690:      	b.eq	0x96ac <_stogir.switch.switch-inputs+0x1ec>
    9694:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009694:  ARM64_RELOC_PAGE21	l_stogir.444
    9698:      	ldr	x16, [x16]
		0000000000009698:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    969c:      	orr	x1, x16, xzr
    96a0:      	add	x1, x3, x1
    96a4:      	ldrb	w1, [x1]
    96a8:      	b	0x96b0 <_stogir.switch.switch-inputs+0x1f0>
    96ac:      	movz	x1, #0x0, lsl #48
    96b0:      	uxtb	w1, w1
    96b4:      	and	x1, x1, #0x4
    96b8:      	uxtb	w1, w1
    96bc:      	cmp	x1, #0x0
    96c0:      	cset	w1, eq
    96c4:      	uxtb	w16, w1
    96c8:      	cmp	w16, wzr
    96cc:      	cset	x1, eq
    96d0:      	cmp	x1, #0x0
    96d4:      	b.ne	0x9570 <_stogir.switch.switch-inputs+0xb0>
    96d8:      	sxtw	x2, w2
    96dc:      	cmp	x2, #0x0
    96e0:      	cset	w1, gt
    96e4:      	movz	x16, #0x0, lsl #48
    96e8:      	sub	x3, x16, x2
    96ec:      	sub	x4, x3, #0x1
    96f0:      	uxtb	w16, w1
    96f4:      	cmp	w16, wzr
    96f8:      	b.eq	0x9750 <_stogir.switch.switch-inputs+0x290>
    96fc:      	ldr	x3, [x0, #0x8]
    9700:      	cmp	x2, x3
    9704:      	b.ge	0x9798 <_stogir.switch.switch-inputs+0x2d8>
    9708:      	add	x3, x0, #0x78
    970c:      	ldr	x3, [x3, #0x8]
    9710:      	cmp	x2, x3
    9714:      	b.ge	0x9868 <_stogir.switch.switch-inputs+0x3a8>
    9718:      	ldr	x3, [x0, #0x78]
    971c:      	add	x3, x3, x2, lsl #2
    9720:      	ldr	w3, [x3]
    9724:      	sxtw	x3, w3
    9728:      	cmp	x3, #0x0
    972c:      	cset	w3, ge
    9730:      	ubfx	x3, x3, #0, #8
    9734:      	b	0x986c <_stogir.switch.switch-inputs+0x3ac>
    9738:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009738:  ARM64_RELOC_PAGE21	l_stogir.445
    973c:      	ldr	x16, [x16]
		000000000000973c:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    9740:      	orr	x0, x16, xzr
    9744:      	mov	x1, #0x1                ; =1
    9748:      	mov	x2, #0x20               ; =32
    974c:      	b	0x9584 <_stogir.switch.switch-inputs+0xc4>
    9750:      	cmp	x2, #0x0
    9754:      	b.ge	0x97a0 <_stogir.switch.switch-inputs+0x2e0>
    9758:      	add	x5, x0, #0x28
    975c:      	add	x6, x0, #0x50
    9760:      	ldr	x5, [x5, #0x8]
    9764:      	ldr	x6, [x6, #0x8]
    9768:      	cmp	x5, x6
    976c:      	b.ne	0x9860 <_stogir.switch.switch-inputs+0x3a0>
    9770:      	cmp	x3, x5
    9774:      	b.gt	0x9878 <_stogir.switch.switch-inputs+0x3b8>
    9778:      	ldr	x3, [x0, #0x50]
    977c:      	add	x3, x3, x4, lsl #2
    9780:      	ldr	w3, [x3]
    9784:      	sxtw	x3, w3
    9788:      	cmp	x3, #0x0
    978c:      	cset	w3, gt
    9790:      	ubfx	x3, x3, #0, #8
    9794:      	b	0x987c <_stogir.switch.switch-inputs+0x3bc>
    9798:      	movz	x3, #0x0, lsl #48
    979c:      	b	0x97a4 <_stogir.switch.switch-inputs+0x2e4>
    97a0:      	movz	x3, #0x0, lsl #48
    97a4:      	cmp	x3, #0x0
    97a8:      	b.eq	0x97dc <_stogir.switch.switch-inputs+0x31c>
    97ac:      	uxtb	w16, w1
    97b0:      	cmp	w16, wzr
    97b4:      	b.eq	0x97c8 <_stogir.switch.switch-inputs+0x308>
    97b8:      	ldr	x0, [x0]
    97bc:      	add	x0, x0, x2, lsl #4
    97c0:      	ldr	x0, [x0]
    97c4:      	b	0x97d4 <_stogir.switch.switch-inputs+0x314>
    97c8:      	ldr	x0, [x0, #0x28]
    97cc:      	add	x0, x0, x4, lsl #4
    97d0:      	ldr	x0, [x0]
    97d4:      	mov	x1, #0x1                ; =1
    97d8:      	b	0x97e4 <_stogir.switch.switch-inputs+0x324>
    97dc:      	movz	x1, #0x0, lsl #48
    97e0:      	movz	x0, #0x0, lsl #48
    97e4:      	lsr	w1, w1, #0
    97e8:      	lsr	x16, x1, #0
    97ec:      	cmp	x16, #0x1
    97f0:      	b.eq	0x980c <_stogir.switch.switch-inputs+0x34c>
    97f4:      	b.lo	0x97fc <_stogir.switch.switch-inputs+0x33c>
    97f8:      	b	0x9810 <_stogir.switch.switch-inputs+0x350>
    97fc:      	cmp	x16, #0x0
    9800:      	b.eq	0x9808 <_stogir.switch.switch-inputs+0x348>
    9804:      	b	0x9810 <_stogir.switch.switch-inputs+0x350>
    9808:      	b	0x9814 <_stogir.switch.switch-inputs+0x354>
    980c:      	b	0x982c <_stogir.switch.switch-inputs+0x36c>
    9810:      	b	0x9880 <_stogir.switch.switch-inputs+0x3c0>
    9814:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009814:  ARM64_RELOC_PAGE21	l_stogir.446
    9818:      	ldr	x16, [x16]
		0000000000009818:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    981c:      	orr	x0, x16, xzr
    9820:      	mov	x1, #0x1                ; =1
    9824:      	mov	x2, #0x17               ; =23
    9828:      	b	0x974c <_stogir.switch.switch-inputs+0x28c>
    982c:      	lsr	w1, w0, #0
    9830:      	ubfx	x1, x1, #8, #8
    9834:      	cmp	x1, #0x1
    9838:      	b.lt	0x9738 <_stogir.switch.switch-inputs+0x278>
    983c:      	cmp	x1, #0xb
    9840:      	b.gt	0x9738 <_stogir.switch.switch-inputs+0x278>
    9844:      	uxtb	w0, w0
    9848:      	cmp	x0, #0x48
    984c:      	b.eq	0x9738 <_stogir.switch.switch-inputs+0x278>
    9850:      	and	x0, x1, #0xffffffff
    9854:      	movz	x1, #0x0, lsl #48
    9858:      	movz	x2, #0x0, lsl #48
    985c:      	b	0x974c <_stogir.switch.switch-inputs+0x28c>
    9860:      	movz	x3, #0x0, lsl #48
    9864:      	b	0x97a4 <_stogir.switch.switch-inputs+0x2e4>
    9868:      	movz	x3, #0x0, lsl #48
    986c:      	b	0x979c <_stogir.switch.switch-inputs+0x2dc>
    9870:      	brk	#0
    9874:      	b	0x9870 <_stogir.switch.switch-inputs+0x3b0>
    9878:      	movz	x3, #0x0, lsl #48
    987c:      	b	0x9864 <_stogir.switch.switch-inputs+0x3a4>
    9880:      	brk	#0
    9884:      	b	0x9880 <_stogir.switch.switch-inputs+0x3c0>

0000000000009888 <_stogir.switch.case-inputs>:
    9888:      	sub	sp, sp, #0xb0
    988c:      	str	x29, [sp]
    9890:      	str	x30, [sp, #0x8]
    9894:      	mov	x29, sp
    9898:      	str	x19, [sp, #0x70]
    989c:      	str	x20, [sp, #0x78]
    98a0:      	str	x21, [sp, #0x80]
    98a4:      	str	x22, [sp, #0x88]
    98a8:      	str	x23, [sp, #0x90]
    98ac:      	str	x24, [sp, #0x98]
    98b0:      	str	x25, [sp, #0xa0]
    98b4:      	str	x26, [sp, #0xa8]
    98b8:      	sxtw	x2, w2
    98bc:      	lsl	x5, x2, #2
    98c0:      	cmp	x2, #0x0
    98c4:      	cset	w6, gt
    98c8:      	movz	x16, #0x0, lsl #48
    98cc:      	sub	x7, x16, x2
    98d0:      	sub	x9, x7, #0x1
    98d4:      	uxtb	w16, w6
    98d8:      	cmp	w16, wzr
    98dc:      	b.eq	0x991c <_stogir.switch.case-inputs+0x94>
    98e0:      	ldr	x7, [x0, #0x8]
    98e4:      	cmp	x2, x7
    98e8:      	b.ge	0x996c <_stogir.switch.case-inputs+0xe4>
    98ec:      	add	x7, x0, #0x78
    98f0:      	ldr	x7, [x7, #0x8]
    98f4:      	cmp	x2, x7
    98f8:      	b.ge	0x9a6c <_stogir.switch.case-inputs+0x1e4>
    98fc:      	ldr	x7, [x0, #0x78]
    9900:      	add	x7, x5, x7
    9904:      	ldr	w7, [x7]
    9908:      	sxtw	x7, w7
    990c:      	cmp	x7, #0x0
    9910:      	cset	w7, ge
    9914:      	ubfx	x7, x7, #0, #8
    9918:      	b	0x9a70 <_stogir.switch.case-inputs+0x1e8>
    991c:      	cmp	x2, #0x0
    9920:      	b.ge	0x9974 <_stogir.switch.case-inputs+0xec>
    9924:      	add	x10, x0, #0x28
    9928:      	add	x11, x0, #0x50
    992c:      	ldr	x10, [x10, #0x8]
    9930:      	ldr	x11, [x11, #0x8]
    9934:      	cmp	x10, x11
    9938:      	b.ne	0x9964 <_stogir.switch.case-inputs+0xdc>
    993c:      	cmp	x7, x10
    9940:      	b.gt	0x9b3c <_stogir.switch.case-inputs+0x2b4>
    9944:      	ldr	x7, [x0, #0x50]
    9948:      	add	x7, x7, x9, lsl #2
    994c:      	ldr	w7, [x7]
    9950:      	sxtw	x7, w7
    9954:      	cmp	x7, #0x0
    9958:      	cset	w7, gt
    995c:      	ubfx	x7, x7, #0, #8
    9960:      	b	0x9b40 <_stogir.switch.case-inputs+0x2b8>
    9964:      	movz	x7, #0x0, lsl #48
    9968:      	b	0x9978 <_stogir.switch.case-inputs+0xf0>
    996c:      	movz	x7, #0x0, lsl #48
    9970:      	b	0x9978 <_stogir.switch.case-inputs+0xf0>
    9974:      	movz	x7, #0x0, lsl #48
    9978:      	cmp	x7, #0x0
    997c:      	b.eq	0x99b8 <_stogir.switch.case-inputs+0x130>
    9980:      	uxtb	w16, w6
    9984:      	cmp	w16, wzr
    9988:      	b.eq	0x99a0 <_stogir.switch.case-inputs+0x118>
    998c:      	ldr	x6, [x0]
    9990:      	add	x6, x6, x2, lsl #4
    9994:      	ldr	x7, [x6]
    9998:      	ldr	x6, [x6, #0x8]
    999c:      	b	0x99b0 <_stogir.switch.case-inputs+0x128>
    99a0:      	ldr	x6, [x0, #0x28]
    99a4:      	add	x6, x6, x9, lsl #4
    99a8:      	ldr	x7, [x6]
    99ac:      	ldr	x6, [x6, #0x8]
    99b0:      	mov	x9, #0x1                ; =1
    99b4:      	b	0x99c4 <_stogir.switch.case-inputs+0x13c>
    99b8:      	movz	x9, #0x0, lsl #48
    99bc:      	movz	x7, #0x0, lsl #48
    99c0:      	movz	x6, #0x0, lsl #48
    99c4:      	lsr	w9, w9, #0
    99c8:      	lsr	x16, x9, #0
    99cc:      	cmp	x16, #0x1
    99d0:      	b.eq	0x99ec <_stogir.switch.case-inputs+0x164>
    99d4:      	b.lo	0x99dc <_stogir.switch.case-inputs+0x154>
    99d8:      	b	0x99f0 <_stogir.switch.case-inputs+0x168>
    99dc:      	cmp	x16, #0x0
    99e0:      	b.eq	0x99e8 <_stogir.switch.case-inputs+0x160>
    99e4:      	b	0x99f0 <_stogir.switch.case-inputs+0x168>
    99e8:      	b	0x99f4 <_stogir.switch.case-inputs+0x16c>
    99ec:      	b	0x9a48 <_stogir.switch.case-inputs+0x1c0>
    99f0:      	b	0x9b44 <_stogir.switch.case-inputs+0x2bc>
    99f4:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		00000000000099f4:  ARM64_RELOC_PAGE21	l_stogir.447
    99f8:      	ldr	x16, [x16]
		00000000000099f8:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    99fc:      	orr	x19, x16, xzr
    9a00:      	mov	x21, x8
    9a04:      	mov	x1, #0x1                ; =1
    9a08:      	mov	x0, #0x1a               ; =26
    9a0c:      	str	x1, [x21]
    9a10:      	str	x19, [x21, #0x8]
    9a14:      	str	x0, [x21, #0x10]
    9a18:      	ldr	x19, [sp, #0x70]
    9a1c:      	ldr	x20, [sp, #0x78]
    9a20:      	ldr	x21, [sp, #0x80]
    9a24:      	ldr	x22, [sp, #0x88]
    9a28:      	ldr	x23, [sp, #0x90]
    9a2c:      	ldr	x24, [sp, #0x98]
    9a30:      	ldr	x25, [sp, #0xa0]
    9a34:      	ldr	x26, [sp, #0xa8]
    9a38:      	ldr	x29, [sp]
    9a3c:      	ldr	x30, [sp, #0x8]
    9a40:      	add	sp, sp, #0xb0
    9a44:      	ret
    9a48:      	cmp	x2, #0x0
    9a4c:      	b.gt	0x9a74 <_stogir.switch.case-inputs+0x1ec>
    9a50:      	mov	x21, x8
    9a54:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009a54:  ARM64_RELOC_PAGE21	l_stogir.448
    9a58:      	ldr	x16, [x16]
		0000000000009a58:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    9a5c:      	orr	x19, x16, xzr
    9a60:      	mov	x1, #0x1                ; =1
    9a64:      	mov	x0, #0x1f               ; =31
    9a68:      	b	0x9a0c <_stogir.switch.case-inputs+0x184>
    9a6c:      	movz	x7, #0x0, lsl #48
    9a70:      	b	0x9970 <_stogir.switch.case-inputs+0xe8>
    9a74:      	uxtb	w2, w7
    9a78:      	cmp	x2, #0x75
    9a7c:      	b.ne	0x9cb8 <_stogir.switch.case-inputs+0x430>
    9a80:      	lsr	w2, w7, #0
    9a84:      	ubfx	x2, x2, #8, #8
    9a88:      	cmp	x2, #0x0
    9a8c:      	b.ne	0x9cc0 <_stogir.switch.case-inputs+0x438>
    9a90:      	ldr	x2, [x0, #0x78]
    9a94:      	add	x2, x5, x2
    9a98:      	ldr	w2, [x2]
    9a9c:      	sxtw	x2, w2
    9aa0:      	cmp	x2, #0x2
    9aa4:      	b.ne	0x9cc8 <_stogir.switch.case-inputs+0x440>
    9aa8:      	sxtw	x20, w1
    9aac:      	cmp	x20, #0x6d
    9ab0:      	b.lt	0x9cd0 <_stogir.switch.case-inputs+0x448>
    9ab4:      	cmp	x20, #0x6f
    9ab8:      	b.gt	0x9cd8 <_stogir.switch.case-inputs+0x450>
    9abc:      	add	x16, sp, #0x10
    9ac0:      	orr	x19, x16, xzr
    9ac4:      	lsr	w6, w6, #0
    9ac8:      	lsr	x1, x7, #32
    9acc:      	lsr	w6, w6, #0
    9ad0:      	lsr	w1, w1, #0
    9ad4:      	mov	w2, w6
    9ad8:      	mov	x21, x8
    9adc:      	add	x8, sp, #0x10
    9ae0:      	mov	x22, x0
    9ae4:      	mov	w23, w3
    9ae8:      	mov	w24, w4
    9aec:      	bl	0x9aec <_stogir.switch.case-inputs+0x264>
		0000000000009aec:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    9af0:      	add	x16, sp, #0x10
    9af4:      	ldr	w0, [x16]
    9af8:      	lsr	x16, x0, #0
    9afc:      	cmp	x16, #0x1
    9b00:      	b.eq	0x9b1c <_stogir.switch.case-inputs+0x294>
    9b04:      	b.lo	0x9b0c <_stogir.switch.case-inputs+0x284>
    9b08:      	b	0x9b20 <_stogir.switch.case-inputs+0x298>
    9b0c:      	cmp	x16, #0x0
    9b10:      	b.eq	0x9b18 <_stogir.switch.case-inputs+0x290>
    9b14:      	b	0x9b20 <_stogir.switch.case-inputs+0x298>
    9b18:      	b	0x9b4c <_stogir.switch.case-inputs+0x2c4>
    9b1c:      	b	0x9b24 <_stogir.switch.case-inputs+0x29c>
    9b20:      	b	0x9ca0 <_stogir.switch.case-inputs+0x418>
    9b24:      	add	x0, x19, #0x8
    9b28:      	add	x16, sp, #0x10
    9b2c:      	ldr	x19, [x16, #0x8]
    9b30:      	ldr	x0, [x0, #0x8]
    9b34:      	mov	x1, #0x1                ; =1
    9b38:      	b	0x9a68 <_stogir.switch.case-inputs+0x1e0>
    9b3c:      	movz	x7, #0x0, lsl #48
    9b40:      	b	0x9968 <_stogir.switch.case-inputs+0xe0>
    9b44:      	brk	#0
    9b48:      	b	0x9b44 <_stogir.switch.case-inputs+0x2bc>
    9b4c:      	add	x16, sp, #0x10
    9b50:      	ldr	w25, [x16, #0x8]
    9b54:      	sxtw	x0, w25
    9b58:      	and	x19, x0, #0xffffffff
    9b5c:      	cmp	x20, #0x6f
    9b60:      	b.ne	0x9b70 <_stogir.switch.case-inputs+0x2e8>
    9b64:      	movz	x1, #0x0, lsl #48
    9b68:      	movz	x0, #0x0, lsl #48
    9b6c:      	b	0x9b38 <_stogir.switch.case-inputs+0x2b0>
    9b70:      	add	x16, sp, #0x30
    9b74:      	orr	x26, x16, xzr
    9b78:      	lsr	w23, w23, #0
    9b7c:      	lsr	w25, w25, #0
    9b80:      	add	x8, sp, #0x30
    9b84:      	mov	x0, x22
    9b88:      	mov	w1, w23
    9b8c:      	mov	w2, w25
    9b90:      	bl	0x9b90 <_stogir.switch.case-inputs+0x308>
		0000000000009b90:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    9b94:      	add	x16, sp, #0x30
    9b98:      	ldr	w0, [x16]
    9b9c:      	lsr	x16, x0, #0
    9ba0:      	cmp	x16, #0x1
    9ba4:      	b.eq	0x9bc0 <_stogir.switch.case-inputs+0x338>
    9ba8:      	b.lo	0x9bb0 <_stogir.switch.case-inputs+0x328>
    9bac:      	b	0x9bc4 <_stogir.switch.case-inputs+0x33c>
    9bb0:      	cmp	x16, #0x0
    9bb4:      	b.eq	0x9bbc <_stogir.switch.case-inputs+0x334>
    9bb8:      	b	0x9bc4 <_stogir.switch.case-inputs+0x33c>
    9bbc:      	b	0x9be0 <_stogir.switch.case-inputs+0x358>
    9bc0:      	b	0x9bc8 <_stogir.switch.case-inputs+0x340>
    9bc4:      	b	0x9ca8 <_stogir.switch.case-inputs+0x420>
    9bc8:      	add	x0, x26, #0x8
    9bcc:      	add	x16, sp, #0x30
    9bd0:      	ldr	x19, [x16, #0x8]
    9bd4:      	ldr	x0, [x0, #0x8]
    9bd8:      	mov	x1, #0x1                ; =1
    9bdc:      	b	0x9b6c <_stogir.switch.case-inputs+0x2e4>
    9be0:      	add	x16, sp, #0x30
    9be4:      	ldr	x26, [x16, #0x8]
    9be8:      	cmp	x20, #0x6d
    9bec:      	b.ne	0x9c04 <_stogir.switch.case-inputs+0x37c>
    9bf0:      	sxtw	x24, w23
    9bf4:      	b	0x9c08 <_stogir.switch.case-inputs+0x380>
    9bf8:      	movz	x1, #0x0, lsl #48
    9bfc:      	movz	x0, #0x0, lsl #48
    9c00:      	b	0x9bdc <_stogir.switch.case-inputs+0x354>
    9c04:      	sxtw	x24, w24
    9c08:      	add	x16, sp, #0x50
    9c0c:      	orr	x20, x16, xzr
    9c10:      	lsr	w25, w25, #0
    9c14:      	lsr	w24, w24, #0
    9c18:      	add	x8, sp, #0x50
    9c1c:      	mov	x0, x22
    9c20:      	mov	w1, w24
    9c24:      	mov	w2, w25
    9c28:      	bl	0x9c28 <_stogir.switch.case-inputs+0x3a0>
		0000000000009c28:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    9c2c:      	add	x16, sp, #0x50
    9c30:      	ldr	w0, [x16]
    9c34:      	lsr	x16, x0, #0
    9c38:      	cmp	x16, #0x1
    9c3c:      	b.eq	0x9c58 <_stogir.switch.case-inputs+0x3d0>
    9c40:      	b.lo	0x9c48 <_stogir.switch.case-inputs+0x3c0>
    9c44:      	b	0x9c5c <_stogir.switch.case-inputs+0x3d4>
    9c48:      	cmp	x16, #0x0
    9c4c:      	b.eq	0x9c54 <_stogir.switch.case-inputs+0x3cc>
    9c50:      	b	0x9c5c <_stogir.switch.case-inputs+0x3d4>
    9c54:      	b	0x9c78 <_stogir.switch.case-inputs+0x3f0>
    9c58:      	b	0x9c60 <_stogir.switch.case-inputs+0x3d8>
    9c5c:      	b	0x9cb0 <_stogir.switch.case-inputs+0x428>
    9c60:      	add	x0, x20, #0x8
    9c64:      	add	x16, sp, #0x50
    9c68:      	ldr	x19, [x16, #0x8]
    9c6c:      	ldr	x0, [x0, #0x8]
    9c70:      	mov	x1, #0x1                ; =1
    9c74:      	b	0x9c00 <_stogir.switch.case-inputs+0x378>
    9c78:      	add	x16, sp, #0x50
    9c7c:      	ldr	x0, [x16, #0x8]
    9c80:      	cmp	x26, x0
    9c84:      	b.ls	0x9bf8 <_stogir.switch.case-inputs+0x370>
    9c88:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009c88:  ARM64_RELOC_PAGE21	l_stogir.449
    9c8c:      	ldr	x16, [x16]
		0000000000009c8c:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    9c90:      	orr	x19, x16, xzr
    9c94:      	mov	x1, #0x1                ; =1
    9c98:      	mov	x0, #0x1a               ; =26
    9c9c:      	b	0x9c00 <_stogir.switch.case-inputs+0x378>
    9ca0:      	brk	#0
    9ca4:      	b	0x9ca0 <_stogir.switch.case-inputs+0x418>
    9ca8:      	brk	#0
    9cac:      	b	0x9ca8 <_stogir.switch.case-inputs+0x420>
    9cb0:      	brk	#0
    9cb4:      	b	0x9cb0 <_stogir.switch.case-inputs+0x428>
    9cb8:      	mov	x21, x8
    9cbc:      	b	0x9a54 <_stogir.switch.case-inputs+0x1cc>
    9cc0:      	mov	x21, x8
    9cc4:      	b	0x9a54 <_stogir.switch.case-inputs+0x1cc>
    9cc8:      	mov	x21, x8
    9ccc:      	b	0x9a54 <_stogir.switch.case-inputs+0x1cc>
    9cd0:      	mov	x21, x8
    9cd4:      	b	0x9a54 <_stogir.switch.case-inputs+0x1cc>
    9cd8:      	mov	x21, x8
    9cdc:      	b	0x9a54 <_stogir.switch.case-inputs+0x1cc>

0000000000009ce0 <_stogir.stack.validate-frame-address>:
    9ce0:      	sxtw	x1, w1
    9ce4:      	lsl	x2, x1, #2
    9ce8:      	cmp	x1, #0x0
    9cec:      	cset	w3, gt
    9cf0:      	movz	x16, #0x0, lsl #48
    9cf4:      	sub	x4, x16, x1
    9cf8:      	sub	x5, x4, #0x1
    9cfc:      	uxtb	w16, w3
    9d00:      	cmp	w16, wzr
    9d04:      	b.eq	0x9d44 <_stogir.stack.validate-frame-address+0x64>
    9d08:      	ldr	x4, [x0, #0x8]
    9d0c:      	cmp	x1, x4
    9d10:      	b.ge	0x9d94 <_stogir.stack.validate-frame-address+0xb4>
    9d14:      	add	x4, x0, #0x78
    9d18:      	ldr	x4, [x4, #0x8]
    9d1c:      	cmp	x1, x4
    9d20:      	b.ge	0x9e98 <_stogir.stack.validate-frame-address+0x1b8>
    9d24:      	ldr	x4, [x0, #0x78]
    9d28:      	add	x4, x2, x4
    9d2c:      	ldr	w4, [x4]
    9d30:      	sxtw	x4, w4
    9d34:      	cmp	x4, #0x0
    9d38:      	cset	w4, ge
    9d3c:      	ubfx	x4, x4, #0, #8
    9d40:      	b	0x9e9c <_stogir.stack.validate-frame-address+0x1bc>
    9d44:      	cmp	x1, #0x0
    9d48:      	b.ge	0x9d9c <_stogir.stack.validate-frame-address+0xbc>
    9d4c:      	add	x6, x0, #0x28
    9d50:      	add	x7, x0, #0x50
    9d54:      	ldr	x6, [x6, #0x8]
    9d58:      	ldr	x7, [x7, #0x8]
    9d5c:      	cmp	x6, x7
    9d60:      	b.ne	0x9d8c <_stogir.stack.validate-frame-address+0xac>
    9d64:      	cmp	x4, x6
    9d68:      	b.gt	0x9ea0 <_stogir.stack.validate-frame-address+0x1c0>
    9d6c:      	ldr	x4, [x0, #0x50]
    9d70:      	add	x4, x4, x5, lsl #2
    9d74:      	ldr	w4, [x4]
    9d78:      	sxtw	x4, w4
    9d7c:      	cmp	x4, #0x0
    9d80:      	cset	w4, gt
    9d84:      	ubfx	x4, x4, #0, #8
    9d88:      	b	0x9ea4 <_stogir.stack.validate-frame-address+0x1c4>
    9d8c:      	movz	x4, #0x0, lsl #48
    9d90:      	b	0x9da0 <_stogir.stack.validate-frame-address+0xc0>
    9d94:      	movz	x4, #0x0, lsl #48
    9d98:      	b	0x9da0 <_stogir.stack.validate-frame-address+0xc0>
    9d9c:      	movz	x4, #0x0, lsl #48
    9da0:      	cmp	x4, #0x0
    9da4:      	b.eq	0x9dd8 <_stogir.stack.validate-frame-address+0xf8>
    9da8:      	uxtb	w16, w3
    9dac:      	cmp	w16, wzr
    9db0:      	b.eq	0x9dc4 <_stogir.stack.validate-frame-address+0xe4>
    9db4:      	ldr	x3, [x0]
    9db8:      	add	x3, x3, x1, lsl #4
    9dbc:      	ldr	x3, [x3]
    9dc0:      	b	0x9dd0 <_stogir.stack.validate-frame-address+0xf0>
    9dc4:      	ldr	x3, [x0, #0x28]
    9dc8:      	add	x3, x3, x5, lsl #4
    9dcc:      	ldr	x3, [x3]
    9dd0:      	mov	x4, #0x1                ; =1
    9dd4:      	b	0x9de0 <_stogir.stack.validate-frame-address+0x100>
    9dd8:      	movz	x4, #0x0, lsl #48
    9ddc:      	movz	x3, #0x0, lsl #48
    9de0:      	lsr	w4, w4, #0
    9de4:      	lsr	x16, x4, #0
    9de8:      	cmp	x16, #0x1
    9dec:      	b.eq	0x9e08 <_stogir.stack.validate-frame-address+0x128>
    9df0:      	b.lo	0x9df8 <_stogir.stack.validate-frame-address+0x118>
    9df4:      	b	0x9e0c <_stogir.stack.validate-frame-address+0x12c>
    9df8:      	cmp	x16, #0x0
    9dfc:      	b.eq	0x9e04 <_stogir.stack.validate-frame-address+0x124>
    9e00:      	b	0x9e0c <_stogir.stack.validate-frame-address+0x12c>
    9e04:      	b	0x9e10 <_stogir.stack.validate-frame-address+0x130>
    9e08:      	b	0x9e4c <_stogir.stack.validate-frame-address+0x16c>
    9e0c:      	b	0x9ea8 <_stogir.stack.validate-frame-address+0x1c8>
    9e10:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009e10:  ARM64_RELOC_PAGE21	l_stogir.450
    9e14:      	ldr	x16, [x16]
		0000000000009e14:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    9e18:      	orr	x0, x16, xzr
    9e1c:      	mov	x1, #0x1                ; =1
    9e20:      	mov	x2, #0x21               ; =33
    9e24:      	b	0x9e3c <_stogir.stack.validate-frame-address+0x15c>
    9e28:      	adrp	x16, 0x9000 <_stogir.types.scalar-size+0x64>
		0000000000009e28:  ARM64_RELOC_PAGE21	l_stogir.451
    9e2c:      	ldr	x16, [x16]
		0000000000009e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    9e30:      	orr	x0, x16, xzr
    9e34:      	mov	x1, #0x1                ; =1
    9e38:      	mov	x2, #0x1e               ; =30
    9e3c:      	str	x1, [x8]
    9e40:      	str	x0, [x8, #0x8]
    9e44:      	str	x2, [x8, #0x10]
    9e48:      	ret
    9e4c:      	cmp	x1, #0x0
    9e50:      	b.le	0x9e28 <_stogir.stack.validate-frame-address+0x148>
    9e54:      	uxtb	w1, w3
    9e58:      	cmp	x1, #0x42
    9e5c:      	b.ne	0x9e28 <_stogir.stack.validate-frame-address+0x148>
    9e60:      	lsr	w3, w3, #0
    9e64:      	ubfx	x1, x3, #8, #8
    9e68:      	cmp	x1, #0x6
    9e6c:      	b.ne	0x9e28 <_stogir.stack.validate-frame-address+0x148>
    9e70:      	ldr	x0, [x0, #0x78]
    9e74:      	add	x0, x2, x0
    9e78:      	ldr	w0, [x0]
    9e7c:      	sxtw	x0, w0
    9e80:      	cmp	x0, #0x0
    9e84:      	b.ne	0x9e28 <_stogir.stack.validate-frame-address+0x148>
    9e88:      	movz	x1, #0x0, lsl #48
    9e8c:      	mov	x0, #0x8                ; =8
    9e90:      	movz	x2, #0x0, lsl #48
    9e94:      	b	0x9e3c <_stogir.stack.validate-frame-address+0x15c>
    9e98:      	movz	x4, #0x0, lsl #48
    9e9c:      	b	0x9d98 <_stogir.stack.validate-frame-address+0xb8>
    9ea0:      	movz	x4, #0x0, lsl #48
    9ea4:      	b	0x9d90 <_stogir.stack.validate-frame-address+0xb0>
    9ea8:      	brk	#0
    9eac:      	b	0x9ea8 <_stogir.stack.validate-frame-address+0x1c8>

0000000000009eb0 <_stogir.stack.frame-object?>:
    9eb0:      	ldr	w0, [x0]
    9eb4:      	uxtb	w1, w0
    9eb8:      	cmp	x1, #0x51
    9ebc:      	b.ne	0x9ed4 <_stogir.stack.frame-object?+0x24>
    9ec0:      	ubfx	x0, x0, #16, #16
    9ec4:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    9ec8:      	cset	w0, eq
    9ecc:      	ubfx	x0, x0, #0, #8
    9ed0:      	b	0x9ed8 <_stogir.stack.frame-object?+0x28>
    9ed4:      	movz	x0, #0x0, lsl #48
    9ed8:      	ret

0000000000009edc <_stogir.stack.valid-frame-object-inputs?>:
    9edc:      	sub	sp, sp, #0x50
    9ee0:      	str	x29, [sp]
    9ee4:      	str	x30, [sp, #0x8]
    9ee8:      	mov	x29, sp
    9eec:      	str	x19, [sp, #0x30]
    9ef0:      	str	x20, [sp, #0x38]
    9ef4:      	str	x21, [sp, #0x40]
    9ef8:      	add	x3, x0, #0x78
    9efc:      	add	x4, x0, #0x28
    9f00:      	add	x5, x0, #0x50
    9f04:      	add	x6, x0, #0x78
    9f08:      	add	x7, x0, #0x28
    9f0c:      	add	x8, x0, #0x50
    9f10:      	sxtw	x1, w1
    9f14:      	mov	x9, sp
    9f18:      	sub	sp, sp, #0x10
    9f1c:      	mov	x10, sp
    9f20:      	mov	x11, #0x1               ; =1
    9f24:      	movz	x12, #0x0, lsl #48
    9f28:      	b	0xa02c <_stogir.stack.valid-frame-object-inputs?+0x150>
    9f2c:      	movz	x15, #0x0, lsl #48
    9f30:      	b	0x9f9c <_stogir.stack.valid-frame-object-inputs?+0xc0>
    9f34:      	movz	x14, #0x0, lsl #48
    9f38:      	movz	x13, #0x0, lsl #48
    9f3c:      	lsr	w14, w14, #0
    9f40:      	lsr	x16, x14, #0
    9f44:      	cmp	x16, #0x1
    9f48:      	b.eq	0x9f64 <_stogir.stack.valid-frame-object-inputs?+0x88>
    9f4c:      	b.lo	0x9f54 <_stogir.stack.valid-frame-object-inputs?+0x78>
    9f50:      	b	0x9f68 <_stogir.stack.valid-frame-object-inputs?+0x8c>
    9f54:      	cmp	x16, #0x0
    9f58:      	b.eq	0x9f60 <_stogir.stack.valid-frame-object-inputs?+0x84>
    9f5c:      	b	0x9f68 <_stogir.stack.valid-frame-object-inputs?+0x8c>
    9f60:      	b	0x9f88 <_stogir.stack.valid-frame-object-inputs?+0xac>
    9f64:      	b	0x9f6c <_stogir.stack.valid-frame-object-inputs?+0x90>
    9f68:      	b	0xa2ec <_stogir.stack.valid-frame-object-inputs?+0x410>
    9f6c:      	uxtb	w14, w13
    9f70:      	lsr	w13, w13, #0
    9f74:      	ubfx	x13, x13, #8, #8
    9f78:      	cmp	x14, x13
    9f7c:      	b.eq	0xa2d8 <_stogir.stack.valid-frame-object-inputs?+0x3fc>
    9f80:      	cmp	x14, #0x49
    9f84:      	b.eq	0xa2d8 <_stogir.stack.valid-frame-object-inputs?+0x3fc>
    9f88:      	movz	x11, #0x0, lsl #48
    9f8c:      	b	0xa104 <_stogir.stack.valid-frame-object-inputs?+0x228>
    9f90:      	movz	x15, #0x0, lsl #48
    9f94:      	b	0x9fa4 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    9f98:      	movz	x15, #0x0, lsl #48
    9f9c:      	b	0x9fac <_stogir.stack.valid-frame-object-inputs?+0xd0>
    9fa0:      	movz	x15, #0x0, lsl #48
    9fa4:      	b	0x9fac <_stogir.stack.valid-frame-object-inputs?+0xd0>
    9fa8:      	movz	x15, #0x0, lsl #48
    9fac:      	cmp	x15, #0x0
    9fb0:      	b.eq	0x9fec <_stogir.stack.valid-frame-object-inputs?+0x110>
    9fb4:      	uxtb	w16, w14
    9fb8:      	cmp	w16, wzr
    9fbc:      	b.eq	0x9fd4 <_stogir.stack.valid-frame-object-inputs?+0xf8>
    9fc0:      	ldr	x14, [x0]
    9fc4:      	add	x13, x14, x13, lsl #4
    9fc8:      	ldr	x14, [x13]
    9fcc:      	ldr	x13, [x13, #0x8]
    9fd0:      	b	0x9fe4 <_stogir.stack.valid-frame-object-inputs?+0x108>
    9fd4:      	ldr	x13, [x0, #0x28]
    9fd8:      	add	x13, x13, x19, lsl #4
    9fdc:      	ldr	x14, [x13]
    9fe0:      	ldr	x13, [x13, #0x8]
    9fe4:      	mov	x15, #0x1               ; =1
    9fe8:      	b	0x9ff8 <_stogir.stack.valid-frame-object-inputs?+0x11c>
    9fec:      	movz	x15, #0x0, lsl #48
    9ff0:      	movz	x14, #0x0, lsl #48
    9ff4:      	movz	x13, #0x0, lsl #48
    9ff8:      	lsr	w15, w15, #0
    9ffc:      	lsr	x16, x15, #0
    a000:      	cmp	x16, #0x1
    a004:      	b.eq	0xa020 <_stogir.stack.valid-frame-object-inputs?+0x144>
    a008:      	b.lo	0xa010 <_stogir.stack.valid-frame-object-inputs?+0x134>
    a00c:      	b	0xa024 <_stogir.stack.valid-frame-object-inputs?+0x148>
    a010:      	cmp	x16, #0x0
    a014:      	b.eq	0xa01c <_stogir.stack.valid-frame-object-inputs?+0x140>
    a018:      	b	0xa024 <_stogir.stack.valid-frame-object-inputs?+0x148>
    a01c:      	b	0xa028 <_stogir.stack.valid-frame-object-inputs?+0x14c>
    a020:      	b	0xa0dc <_stogir.stack.valid-frame-object-inputs?+0x200>
    a024:      	b	0xa244 <_stogir.stack.valid-frame-object-inputs?+0x368>
    a028:      	movz	x11, #0x0, lsl #48
    a02c:      	cmp	x11, #0x0
    a030:      	b.eq	0xa190 <_stogir.stack.valid-frame-object-inputs?+0x2b4>
    a034:      	cmp	x12, #0x0
    a038:      	b.ne	0xa190 <_stogir.stack.valid-frame-object-inputs?+0x2b4>
    a03c:      	lsr	w13, w1, #0
    a040:      	sxtw	x13, w13
    a044:      	cmp	x13, #0x0
    a048:      	cset	w14, gt
    a04c:      	movz	x16, #0x0, lsl #48
    a050:      	sub	x15, x16, x13
    a054:      	sub	x19, x15, #0x1
    a058:      	uxtb	w16, w14
    a05c:      	cmp	w16, wzr
    a060:      	b.eq	0xa09c <_stogir.stack.valid-frame-object-inputs?+0x1c0>
    a064:      	ldr	x15, [x0, #0x8]
    a068:      	cmp	x13, x15
    a06c:      	b.ge	0x9fa0 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    a070:      	ldr	x15, [x3, #0x8]
    a074:      	cmp	x13, x15
    a078:      	b.ge	0x9f90 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    a07c:      	ldr	x15, [x0, #0x78]
    a080:      	add	x15, x15, x13, lsl #2
    a084:      	ldr	w15, [x15]
    a088:      	sxtw	x15, w15
    a08c:      	cmp	x15, #0x0
    a090:      	cset	w15, ge
    a094:      	ubfx	x15, x15, #0, #8
    a098:      	b	0x9f94 <_stogir.stack.valid-frame-object-inputs?+0xb8>
    a09c:      	cmp	x13, #0x0
    a0a0:      	b.ge	0x9fa8 <_stogir.stack.valid-frame-object-inputs?+0xcc>
    a0a4:      	ldr	x20, [x4, #0x8]
    a0a8:      	ldr	x21, [x5, #0x8]
    a0ac:      	cmp	x20, x21
    a0b0:      	b.ne	0x9f98 <_stogir.stack.valid-frame-object-inputs?+0xbc>
    a0b4:      	cmp	x15, x20
    a0b8:      	b.gt	0x9f2c <_stogir.stack.valid-frame-object-inputs?+0x50>
    a0bc:      	ldr	x15, [x0, #0x50]
    a0c0:      	add	x15, x15, x19, lsl #2
    a0c4:      	ldr	w15, [x15]
    a0c8:      	sxtw	x15, w15
    a0cc:      	cmp	x15, #0x0
    a0d0:      	cset	w15, gt
    a0d4:      	ubfx	x15, x15, #0, #8
    a0d8:      	b	0x9f30 <_stogir.stack.valid-frame-object-inputs?+0x54>
    a0dc:      	uxtb	w15, w14
    a0e0:      	asr	x19, x14, #32
    a0e4:      	str	x14, [x10]
    a0e8:      	str	x13, [x10, #0x8]
    a0ec:      	cmp	x15, #0x68
    a0f0:      	b.ne	0xa108 <_stogir.stack.valid-frame-object-inputs?+0x22c>
    a0f4:      	cmp	x19, #0x0
    a0f8:      	cset	w11, eq
    a0fc:      	ubfx	x11, x11, #0, #8
    a100:      	mov	x12, #0x1               ; =1
    a104:      	b	0xa02c <_stogir.stack.valid-frame-object-inputs?+0x150>
    a108:      	cmp	x1, #0x0
    a10c:      	b.le	0x9f88 <_stogir.stack.valid-frame-object-inputs?+0xac>
    a110:      	cmp	x15, #0x51
    a114:      	b.ne	0x9f88 <_stogir.stack.valid-frame-object-inputs?+0xac>
    a118:      	cmp	x19, #0x0
    a11c:      	b.le	0x9f88 <_stogir.stack.valid-frame-object-inputs?+0xac>
    a120:      	cmp	x19, x1
    a124:      	b.ge	0x9f88 <_stogir.stack.valid-frame-object-inputs?+0xac>
    a128:      	lsr	w13, w13, #0
    a12c:      	sxtw	x13, w13
    a130:      	cmp	x13, #0x0
    a134:      	b.ge	0x9f88 <_stogir.stack.valid-frame-object-inputs?+0xac>
    a138:      	cmp	x13, #0x0
    a13c:      	cset	w14, gt
    a140:      	movz	x16, #0x0, lsl #48
    a144:      	sub	x15, x16, x13
    a148:      	sub	x19, x15, #0x1
    a14c:      	uxtb	w16, w14
    a150:      	cmp	w16, wzr
    a154:      	b.eq	0xa290 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    a158:      	ldr	x15, [x0, #0x8]
    a15c:      	cmp	x13, x15
    a160:      	b.ge	0xa288 <_stogir.stack.valid-frame-object-inputs?+0x3ac>
    a164:      	ldr	x15, [x6, #0x8]
    a168:      	cmp	x13, x15
    a16c:      	b.ge	0xa2d0 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    a170:      	ldr	x15, [x0, #0x78]
    a174:      	add	x15, x15, x13, lsl #2
    a178:      	ldr	w15, [x15]
    a17c:      	sxtw	x15, w15
    a180:      	cmp	x15, #0x0
    a184:      	cset	w15, ge
    a188:      	ubfx	x15, x15, #0, #8
    a18c:      	b	0xa2d4 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    a190:      	cmp	x11, #0x0
    a194:      	b.ne	0xa19c <_stogir.stack.valid-frame-object-inputs?+0x2c0>
    a198:      	movz	x12, #0x0, lsl #48
    a19c:      	mov	sp, x9
    a1a0:      	cmp	x12, #0x0
    a1a4:      	b.eq	0xa200 <_stogir.stack.valid-frame-object-inputs?+0x324>
    a1a8:      	sxtw	x1, w2
    a1ac:      	cmp	x1, #0x0
    a1b0:      	b.ge	0xa224 <_stogir.stack.valid-frame-object-inputs?+0x348>
    a1b4:      	lsr	w2, w2, #0
    a1b8:      	add	x8, x29, #0x10
    a1bc:      	mov	w1, w2
    a1c0:      	bl	0xa1c0 <_stogir.stack.valid-frame-object-inputs?+0x2e4>
		000000000000a1c0:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    a1c4:      	add	x16, x29, #0x10
    a1c8:      	ldr	w0, [x16]
    a1cc:      	lsr	x16, x0, #0
    a1d0:      	cmp	x16, #0x1
    a1d4:      	b.eq	0xa1f0 <_stogir.stack.valid-frame-object-inputs?+0x314>
    a1d8:      	b.lo	0xa1e0 <_stogir.stack.valid-frame-object-inputs?+0x304>
    a1dc:      	b	0xa1f4 <_stogir.stack.valid-frame-object-inputs?+0x318>
    a1e0:      	cmp	x16, #0x0
    a1e4:      	b.eq	0xa1ec <_stogir.stack.valid-frame-object-inputs?+0x310>
    a1e8:      	b	0xa1f4 <_stogir.stack.valid-frame-object-inputs?+0x318>
    a1ec:      	b	0xa22c <_stogir.stack.valid-frame-object-inputs?+0x350>
    a1f0:      	b	0xa1f8 <_stogir.stack.valid-frame-object-inputs?+0x31c>
    a1f4:      	b	0xa2e4 <_stogir.stack.valid-frame-object-inputs?+0x408>
    a1f8:      	movz	x0, #0x0, lsl #48
    a1fc:      	b	0xa240 <_stogir.stack.valid-frame-object-inputs?+0x364>
    a200:      	movz	x0, #0x0, lsl #48
    a204:      	sub	sp, x29, #0x0
    a208:      	ldr	x19, [sp, #0x30]
    a20c:      	ldr	x20, [sp, #0x38]
    a210:      	ldr	x21, [sp, #0x40]
    a214:      	ldr	x29, [sp]
    a218:      	ldr	x30, [sp, #0x8]
    a21c:      	add	sp, sp, #0x50
    a220:      	ret
    a224:      	movz	x0, #0x0, lsl #48
    a228:      	b	0xa204 <_stogir.stack.valid-frame-object-inputs?+0x328>
    a22c:      	add	x16, x29, #0x10
    a230:      	ldr	x0, [x16, #0x8]
    a234:      	cmp	x0, #0x0
    a238:      	cset	w0, gt
    a23c:      	ubfx	x0, x0, #0, #8
    a240:      	b	0xa228 <_stogir.stack.valid-frame-object-inputs?+0x34c>
    a244:      	brk	#0
    a248:      	b	0xa244 <_stogir.stack.valid-frame-object-inputs?+0x368>
    a24c:      	ldr	x13, [x0, #0x28]
    a250:      	add	x13, x13, x19, lsl #4
    a254:      	ldr	x13, [x13]
    a258:      	mov	x14, #0x1               ; =1
    a25c:      	b	0x9f3c <_stogir.stack.valid-frame-object-inputs?+0x60>
    a260:      	movz	x15, #0x0, lsl #48
    a264:      	cmp	x15, #0x0
    a268:      	b.eq	0x9f34 <_stogir.stack.valid-frame-object-inputs?+0x58>
    a26c:      	uxtb	w16, w14
    a270:      	cmp	w16, wzr
    a274:      	b.eq	0xa24c <_stogir.stack.valid-frame-object-inputs?+0x370>
    a278:      	ldr	x14, [x0]
    a27c:      	add	x13, x14, x13, lsl #4
    a280:      	ldr	x13, [x13]
    a284:      	b	0xa258 <_stogir.stack.valid-frame-object-inputs?+0x37c>
    a288:      	movz	x15, #0x0, lsl #48
    a28c:      	b	0xa264 <_stogir.stack.valid-frame-object-inputs?+0x388>
    a290:      	ldr	x20, [x7, #0x8]
    a294:      	ldr	x21, [x8, #0x8]
    a298:      	cmp	x20, x21
    a29c:      	b.ne	0xa260 <_stogir.stack.valid-frame-object-inputs?+0x384>
    a2a0:      	cmp	x15, x20
    a2a4:      	b.gt	0xa2c8 <_stogir.stack.valid-frame-object-inputs?+0x3ec>
    a2a8:      	ldr	x15, [x0, #0x50]
    a2ac:      	add	x15, x15, x19, lsl #2
    a2b0:      	ldr	w15, [x15]
    a2b4:      	sxtw	x15, w15
    a2b8:      	cmp	x15, #0x0
    a2bc:      	cset	w15, gt
    a2c0:      	ubfx	x15, x15, #0, #8
    a2c4:      	b	0xa2cc <_stogir.stack.valid-frame-object-inputs?+0x3f0>
    a2c8:      	movz	x15, #0x0, lsl #48
    a2cc:      	b	0xa264 <_stogir.stack.valid-frame-object-inputs?+0x388>
    a2d0:      	movz	x15, #0x0, lsl #48
    a2d4:      	b	0xa28c <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    a2d8:      	ldr	w1, [x10, #0x4]
    a2dc:      	sxtw	x1, w1
    a2e0:      	b	0x9f8c <_stogir.stack.valid-frame-object-inputs?+0xb0>
    a2e4:      	brk	#0
    a2e8:      	b	0xa2e4 <_stogir.stack.valid-frame-object-inputs?+0x408>
    a2ec:      	brk	#0
    a2f0:      	b	0xa2ec <_stogir.stack.valid-frame-object-inputs?+0x410>

000000000000a2f4 <_stogir.stack.validate-scope-inputs>:
    a2f4:      	sxtw	x1, w1
    a2f8:      	cmp	x1, #0x53
    a2fc:      	cset	w5, eq
    a300:      	uxtb	w16, w5
    a304:      	cmp	w16, wzr
    a308:      	b.ne	0xa338 <_stogir.stack.validate-scope-inputs+0x44>
    a30c:      	cmp	x1, #0x54
    a310:      	b.eq	0xa338 <_stogir.stack.validate-scope-inputs+0x44>
    a314:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a314:  ARM64_RELOC_PAGE21	l_stogir.452
    a318:      	ldr	x16, [x16]
		000000000000a318:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    a31c:      	orr	x0, x16, xzr
    a320:      	mov	x1, #0x1                ; =1
    a324:      	mov	x2, #0x22               ; =34
    a328:      	str	x1, [x8]
    a32c:      	str	x0, [x8, #0x8]
    a330:      	str	x2, [x8, #0x10]
    a334:      	ret
    a338:      	uxtb	w16, w5
    a33c:      	cmp	w16, wzr
    a340:      	mov	x16, #0x6               ; =6
    a344:      	movz	x17, #0x0, lsl #48
    a348:      	csel	x1, x16, x17, ne
    a34c:      	sxtw	x2, w2
    a350:      	lsr	w1, w1, #0
    a354:      	sxtw	x1, w1
    a358:      	cmp	x2, x1
    a35c:      	b.ne	0xa314 <_stogir.stack.validate-scope-inputs+0x20>
    a360:      	sxtw	x3, w3
    a364:      	cmp	x3, #0x0
    a368:      	cset	w1, gt
    a36c:      	movz	x16, #0x0, lsl #48
    a370:      	sub	x2, x16, x3
    a374:      	sub	x6, x2, #0x1
    a378:      	uxtb	w16, w1
    a37c:      	cmp	w16, wzr
    a380:      	b.eq	0xa454 <_stogir.stack.validate-scope-inputs+0x160>
    a384:      	ldr	x2, [x0, #0x8]
    a388:      	cmp	x3, x2
    a38c:      	b.ge	0xa44c <_stogir.stack.validate-scope-inputs+0x158>
    a390:      	add	x2, x0, #0x78
    a394:      	ldr	x2, [x2, #0x8]
    a398:      	cmp	x3, x2
    a39c:      	b.ge	0xa4f4 <_stogir.stack.validate-scope-inputs+0x200>
    a3a0:      	ldr	x2, [x0, #0x78]
    a3a4:      	add	x2, x2, x3, lsl #2
    a3a8:      	ldr	w2, [x2]
    a3ac:      	sxtw	x2, w2
    a3b0:      	cmp	x2, #0x0
    a3b4:      	cset	w2, ge
    a3b8:      	ubfx	x2, x2, #0, #8
    a3bc:      	b	0xa4f8 <_stogir.stack.validate-scope-inputs+0x204>
    a3c0:      	movz	x2, #0x0, lsl #48
    a3c4:      	movz	x1, #0x0, lsl #48
    a3c8:      	lsr	w2, w2, #0
    a3cc:      	lsr	x16, x2, #0
    a3d0:      	cmp	x16, #0x1
    a3d4:      	b.eq	0xa3f0 <_stogir.stack.validate-scope-inputs+0xfc>
    a3d8:      	b.lo	0xa3e0 <_stogir.stack.validate-scope-inputs+0xec>
    a3dc:      	b	0xa3f4 <_stogir.stack.validate-scope-inputs+0x100>
    a3e0:      	cmp	x16, #0x0
    a3e4:      	b.eq	0xa3ec <_stogir.stack.validate-scope-inputs+0xf8>
    a3e8:      	b	0xa3f4 <_stogir.stack.validate-scope-inputs+0x100>
    a3ec:      	b	0xa3f8 <_stogir.stack.validate-scope-inputs+0x104>
    a3f0:      	b	0xa49c <_stogir.stack.validate-scope-inputs+0x1a8>
    a3f4:      	b	0xa6c4 <_stogir.stack.validate-scope-inputs+0x3d0>
    a3f8:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a3f8:  ARM64_RELOC_PAGE21	l_stogir.453
    a3fc:      	ldr	x16, [x16]
		000000000000a3fc:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    a400:      	orr	x0, x16, xzr
    a404:      	mov	x1, #0x1                ; =1
    a408:      	mov	x2, #0x1b               ; =27
    a40c:      	b	0xa328 <_stogir.stack.validate-scope-inputs+0x34>
    a410:      	ldr	x1, [x0, #0x28]
    a414:      	add	x1, x1, x6, lsl #4
    a418:      	ldr	x1, [x1]
    a41c:      	mov	x2, #0x1                ; =1
    a420:      	b	0xa3c8 <_stogir.stack.validate-scope-inputs+0xd4>
    a424:      	movz	x2, #0x0, lsl #48
    a428:      	cmp	x2, #0x0
    a42c:      	b.eq	0xa3c0 <_stogir.stack.validate-scope-inputs+0xcc>
    a430:      	uxtb	w16, w1
    a434:      	cmp	w16, wzr
    a438:      	b.eq	0xa410 <_stogir.stack.validate-scope-inputs+0x11c>
    a43c:      	ldr	x1, [x0]
    a440:      	add	x1, x1, x3, lsl #4
    a444:      	ldr	x1, [x1]
    a448:      	b	0xa41c <_stogir.stack.validate-scope-inputs+0x128>
    a44c:      	movz	x2, #0x0, lsl #48
    a450:      	b	0xa428 <_stogir.stack.validate-scope-inputs+0x134>
    a454:      	cmp	x3, #0x0
    a458:      	b.ge	0xa424 <_stogir.stack.validate-scope-inputs+0x130>
    a45c:      	add	x7, x0, #0x28
    a460:      	add	x9, x0, #0x50
    a464:      	ldr	x7, [x7, #0x8]
    a468:      	ldr	x9, [x9, #0x8]
    a46c:      	cmp	x7, x9
    a470:      	b.ne	0xa4ec <_stogir.stack.validate-scope-inputs+0x1f8>
    a474:      	cmp	x2, x7
    a478:      	b.gt	0xa4fc <_stogir.stack.validate-scope-inputs+0x208>
    a47c:      	ldr	x2, [x0, #0x50]
    a480:      	add	x2, x2, x6, lsl #2
    a484:      	ldr	w2, [x2]
    a488:      	sxtw	x2, w2
    a48c:      	cmp	x2, #0x0
    a490:      	cset	w2, gt
    a494:      	ubfx	x2, x2, #0, #8
    a498:      	b	0xa500 <_stogir.stack.validate-scope-inputs+0x20c>
    a49c:      	cmp	x3, #0x0
    a4a0:      	b.le	0xa4d4 <_stogir.stack.validate-scope-inputs+0x1e0>
    a4a4:      	uxtb	w1, w1
    a4a8:      	cmp	x1, #0x83
    a4ac:      	cset	w2, lt
    a4b0:      	uxtb	w16, w2
    a4b4:      	cmp	w16, wzr
    a4b8:      	b.eq	0xa504 <_stogir.stack.validate-scope-inputs+0x210>
    a4bc:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a4bc:  ARM64_RELOC_PAGE21	l_stogir.454
    a4c0:      	ldr	x16, [x16]
		000000000000a4c0:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    a4c4:      	orr	x3, x16, xzr
    a4c8:      	add	x3, x1, x3
    a4cc:      	ldrb	w3, [x3]
    a4d0:      	b	0xa508 <_stogir.stack.validate-scope-inputs+0x214>
    a4d4:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a4d4:  ARM64_RELOC_PAGE21	l_stogir.455
    a4d8:      	ldr	x16, [x16]
		000000000000a4d8:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    a4dc:      	orr	x0, x16, xzr
    a4e0:      	mov	x1, #0x1                ; =1
    a4e4:      	mov	x2, #0x1b               ; =27
    a4e8:      	b	0xa40c <_stogir.stack.validate-scope-inputs+0x118>
    a4ec:      	movz	x2, #0x0, lsl #48
    a4f0:      	b	0xa428 <_stogir.stack.validate-scope-inputs+0x134>
    a4f4:      	movz	x2, #0x0, lsl #48
    a4f8:      	b	0xa450 <_stogir.stack.validate-scope-inputs+0x15c>
    a4fc:      	movz	x2, #0x0, lsl #48
    a500:      	b	0xa4f0 <_stogir.stack.validate-scope-inputs+0x1fc>
    a504:      	movz	x3, #0x0, lsl #48
    a508:      	uxtb	w3, w3
    a50c:      	and	x3, x3, #0x1
    a510:      	uxtb	w3, w3
    a514:      	cmp	x3, #0x0
    a518:      	b.eq	0xa4d4 <_stogir.stack.validate-scope-inputs+0x1e0>
    a51c:      	uxtb	w16, w2
    a520:      	cmp	w16, wzr
    a524:      	b.eq	0xa540 <_stogir.stack.validate-scope-inputs+0x24c>
    a528:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a528:  ARM64_RELOC_PAGE21	l_stogir.454
    a52c:      	ldr	x16, [x16]
		000000000000a52c:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    a530:      	orr	x2, x16, xzr
    a534:      	add	x1, x1, x2
    a538:      	ldrb	w1, [x1]
    a53c:      	b	0xa544 <_stogir.stack.validate-scope-inputs+0x250>
    a540:      	movz	x1, #0x0, lsl #48
    a544:      	uxtb	w1, w1
    a548:      	and	x1, x1, #0x4
    a54c:      	uxtb	w1, w1
    a550:      	cmp	x1, #0x0
    a554:      	cset	w1, eq
    a558:      	uxtb	w16, w1
    a55c:      	cmp	w16, wzr
    a560:      	cset	x1, eq
    a564:      	cmp	x1, #0x0
    a568:      	b.ne	0xa4d4 <_stogir.stack.validate-scope-inputs+0x1e0>
    a56c:      	uxtb	w16, w5
    a570:      	cmp	w16, wzr
    a574:      	b.eq	0xa588 <_stogir.stack.validate-scope-inputs+0x294>
    a578:      	movz	x1, #0x0, lsl #48
    a57c:      	mov	x0, #0x8                ; =8
    a580:      	movz	x2, #0x0, lsl #48
    a584:      	b	0xa4e8 <_stogir.stack.validate-scope-inputs+0x1f4>
    a588:      	sxtw	x4, w4
    a58c:      	cmp	x4, #0x0
    a590:      	cset	w1, gt
    a594:      	movz	x16, #0x0, lsl #48
    a598:      	sub	x2, x16, x4
    a59c:      	sub	x3, x2, #0x1
    a5a0:      	uxtb	w16, w1
    a5a4:      	cmp	w16, wzr
    a5a8:      	b.eq	0xa67c <_stogir.stack.validate-scope-inputs+0x388>
    a5ac:      	ldr	x2, [x0, #0x8]
    a5b0:      	cmp	x4, x2
    a5b4:      	b.ge	0xa674 <_stogir.stack.validate-scope-inputs+0x380>
    a5b8:      	add	x2, x0, #0x78
    a5bc:      	ldr	x2, [x2, #0x8]
    a5c0:      	cmp	x4, x2
    a5c4:      	b.ge	0xa718 <_stogir.stack.validate-scope-inputs+0x424>
    a5c8:      	ldr	x2, [x0, #0x78]
    a5cc:      	add	x2, x2, x4, lsl #2
    a5d0:      	ldr	w2, [x2]
    a5d4:      	sxtw	x2, w2
    a5d8:      	cmp	x2, #0x0
    a5dc:      	cset	w2, ge
    a5e0:      	ubfx	x2, x2, #0, #8
    a5e4:      	b	0xa71c <_stogir.stack.validate-scope-inputs+0x428>
    a5e8:      	movz	x1, #0x0, lsl #48
    a5ec:      	movz	x0, #0x0, lsl #48
    a5f0:      	lsr	w1, w1, #0
    a5f4:      	lsr	x16, x1, #0
    a5f8:      	cmp	x16, #0x1
    a5fc:      	b.eq	0xa618 <_stogir.stack.validate-scope-inputs+0x324>
    a600:      	b.lo	0xa608 <_stogir.stack.validate-scope-inputs+0x314>
    a604:      	b	0xa61c <_stogir.stack.validate-scope-inputs+0x328>
    a608:      	cmp	x16, #0x0
    a60c:      	b.eq	0xa614 <_stogir.stack.validate-scope-inputs+0x320>
    a610:      	b	0xa61c <_stogir.stack.validate-scope-inputs+0x328>
    a614:      	b	0xa620 <_stogir.stack.validate-scope-inputs+0x32c>
    a618:      	b	0xa6cc <_stogir.stack.validate-scope-inputs+0x3d8>
    a61c:      	b	0xa728 <_stogir.stack.validate-scope-inputs+0x434>
    a620:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a620:  ARM64_RELOC_PAGE21	l_stogir.456
    a624:      	ldr	x16, [x16]
		000000000000a624:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    a628:      	orr	x0, x16, xzr
    a62c:      	mov	x1, #0x1                ; =1
    a630:      	mov	x2, #0x1b               ; =27
    a634:      	b	0xa584 <_stogir.stack.validate-scope-inputs+0x290>
    a638:      	ldr	x0, [x0, #0x28]
    a63c:      	add	x0, x0, x3, lsl #4
    a640:      	ldr	x0, [x0]
    a644:      	mov	x1, #0x1                ; =1
    a648:      	b	0xa5f0 <_stogir.stack.validate-scope-inputs+0x2fc>
    a64c:      	movz	x2, #0x0, lsl #48
    a650:      	cmp	x2, #0x0
    a654:      	b.eq	0xa5e8 <_stogir.stack.validate-scope-inputs+0x2f4>
    a658:      	uxtb	w16, w1
    a65c:      	cmp	w16, wzr
    a660:      	b.eq	0xa638 <_stogir.stack.validate-scope-inputs+0x344>
    a664:      	ldr	x0, [x0]
    a668:      	add	x0, x0, x4, lsl #4
    a66c:      	ldr	x0, [x0]
    a670:      	b	0xa644 <_stogir.stack.validate-scope-inputs+0x350>
    a674:      	movz	x2, #0x0, lsl #48
    a678:      	b	0xa650 <_stogir.stack.validate-scope-inputs+0x35c>
    a67c:      	cmp	x4, #0x0
    a680:      	b.ge	0xa64c <_stogir.stack.validate-scope-inputs+0x358>
    a684:      	add	x5, x0, #0x28
    a688:      	add	x6, x0, #0x50
    a68c:      	ldr	x5, [x5, #0x8]
    a690:      	ldr	x6, [x6, #0x8]
    a694:      	cmp	x5, x6
    a698:      	b.ne	0xa710 <_stogir.stack.validate-scope-inputs+0x41c>
    a69c:      	cmp	x2, x5
    a6a0:      	b.gt	0xa720 <_stogir.stack.validate-scope-inputs+0x42c>
    a6a4:      	ldr	x2, [x0, #0x50]
    a6a8:      	add	x2, x2, x3, lsl #2
    a6ac:      	ldr	w2, [x2]
    a6b0:      	sxtw	x2, w2
    a6b4:      	cmp	x2, #0x0
    a6b8:      	cset	w2, gt
    a6bc:      	ubfx	x2, x2, #0, #8
    a6c0:      	b	0xa724 <_stogir.stack.validate-scope-inputs+0x430>
    a6c4:      	brk	#0
    a6c8:      	b	0xa6c4 <_stogir.stack.validate-scope-inputs+0x3d0>
    a6cc:      	lsr	w1, w0, #0
    a6d0:      	ubfx	x1, x1, #8, #8
    a6d4:      	cmp	x1, #0x6
    a6d8:      	b.ne	0xa6f8 <_stogir.stack.validate-scope-inputs+0x404>
    a6dc:      	uxtb	w0, w0
    a6e0:      	cmp	x0, #0x48
    a6e4:      	b.eq	0xa6f8 <_stogir.stack.validate-scope-inputs+0x404>
    a6e8:      	movz	x1, #0x0, lsl #48
    a6ec:      	mov	x0, #0x8                ; =8
    a6f0:      	movz	x2, #0x0, lsl #48
    a6f4:      	b	0xa70c <_stogir.stack.validate-scope-inputs+0x418>
    a6f8:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a6f8:  ARM64_RELOC_PAGE21	l_stogir.457
    a6fc:      	ldr	x16, [x16]
		000000000000a6fc:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    a700:      	orr	x0, x16, xzr
    a704:      	mov	x1, #0x1                ; =1
    a708:      	mov	x2, #0x29               ; =41
    a70c:      	b	0xa634 <_stogir.stack.validate-scope-inputs+0x340>
    a710:      	movz	x2, #0x0, lsl #48
    a714:      	b	0xa650 <_stogir.stack.validate-scope-inputs+0x35c>
    a718:      	movz	x2, #0x0, lsl #48
    a71c:      	b	0xa678 <_stogir.stack.validate-scope-inputs+0x384>
    a720:      	movz	x2, #0x0, lsl #48
    a724:      	b	0xa714 <_stogir.stack.validate-scope-inputs+0x420>
    a728:      	brk	#0
    a72c:      	b	0xa728 <_stogir.stack.validate-scope-inputs+0x434>

000000000000a730 <_stogir.stack.validate-inputs>:
    a730:      	sub	sp, sp, #0x110
    a734:      	str	x29, [sp]
    a738:      	str	x30, [sp, #0x8]
    a73c:      	mov	x29, sp
    a740:      	str	x19, [sp, #0xb8]
    a744:      	str	x20, [sp, #0xc0]
    a748:      	str	x21, [sp, #0xc8]
    a74c:      	str	x22, [sp, #0xd0]
    a750:      	str	x23, [sp, #0xd8]
    a754:      	str	x24, [sp, #0xe0]
    a758:      	str	x25, [sp, #0xe8]
    a75c:      	str	x26, [sp, #0xf0]
    a760:      	str	x27, [sp, #0xf8]
    a764:      	str	x28, [sp, #0x100]
    a768:      	sxtw	x1, w1
    a76c:      	cmp	x1, #0x51
    a770:      	cset	w19, eq
    a774:      	uxtb	w16, w19
    a778:      	cmp	w16, wzr
    a77c:      	b.ne	0xa7e8 <_stogir.stack.validate-inputs+0xb8>
    a780:      	cmp	x1, #0x52
    a784:      	b.eq	0xa7e8 <_stogir.stack.validate-inputs+0xb8>
    a788:      	str	x8, [sp, #0x90]
    a78c:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a78c:  ARM64_RELOC_PAGE21	l_stogir.458
    a790:      	ldr	x16, [x16]
		000000000000a790:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    a794:      	orr	x0, x16, xzr
    a798:      	mov	x2, #0x1                ; =1
    a79c:      	mov	x1, #0x29               ; =41
    a7a0:      	ldr	x3, [sp, #0x90]
    a7a4:      	str	x2, [x3]
    a7a8:      	str	x0, [x3, #0x8]
    a7ac:      	str	x1, [x3, #0x10]
    a7b0:      	ldr	x19, [sp, #0xb8]
    a7b4:      	ldr	x20, [sp, #0xc0]
    a7b8:      	ldr	x21, [sp, #0xc8]
    a7bc:      	ldr	x22, [sp, #0xd0]
    a7c0:      	ldr	x23, [sp, #0xd8]
    a7c4:      	ldr	x24, [sp, #0xe0]
    a7c8:      	ldr	x25, [sp, #0xe8]
    a7cc:      	ldr	x26, [sp, #0xf0]
    a7d0:      	ldr	x27, [sp, #0xf8]
    a7d4:      	ldr	x28, [sp, #0x100]
    a7d8:      	ldr	x29, [sp]
    a7dc:      	ldr	x30, [sp, #0x8]
    a7e0:      	add	sp, sp, #0x110
    a7e4:      	ret
    a7e8:      	uxtb	w16, w19
    a7ec:      	cmp	w16, wzr
    a7f0:      	mov	x16, #0x6               ; =6
    a7f4:      	movz	x17, #0x0, lsl #48
    a7f8:      	csel	x1, x16, x17, ne
    a7fc:      	sxtw	x2, w2
    a800:      	lsr	w1, w1, #0
    a804:      	sxtw	x1, w1
    a808:      	cmp	x2, x1
    a80c:      	b.ne	0xad50 <_stogir.stack.validate-inputs+0x620>
    a810:      	sxtw	x20, w5
    a814:      	uxtb	w16, w19
    a818:      	cmp	w16, wzr
    a81c:      	b.eq	0xa840 <_stogir.stack.validate-inputs+0x110>
    a820:      	cmp	x20, #0x0
    a824:      	b.eq	0xa840 <_stogir.stack.validate-inputs+0x110>
    a828:      	cmp	x20, #0x0
    a82c:      	b.le	0xa8e0 <_stogir.stack.validate-inputs+0x1b0>
    a830:      	sub	x1, x20, #0x1
    a834:      	and	x1, x1, x20
    a838:      	cmp	x1, #0x0
    a83c:      	b.ne	0xa8e0 <_stogir.stack.validate-inputs+0x1b0>
    a840:      	lsr	w3, w3, #0
    a844:      	mov	w1, w3
    a848:      	mov	x21, x8
    a84c:      	add	x8, sp, #0x10
    a850:      	mov	x22, x0
    a854:      	mov	w23, w3
    a858:      	mov	w24, w4
    a85c:      	bl	0xa85c <_stogir.stack.validate-inputs+0x12c>
		000000000000a85c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    a860:      	add	x16, sp, #0x10
    a864:      	ldr	w0, [x16]
    a868:      	lsr	x16, x0, #0
    a86c:      	cmp	x16, #0x1
    a870:      	b.eq	0xa88c <_stogir.stack.validate-inputs+0x15c>
    a874:      	b.lo	0xa87c <_stogir.stack.validate-inputs+0x14c>
    a878:      	b	0xa890 <_stogir.stack.validate-inputs+0x160>
    a87c:      	cmp	x16, #0x0
    a880:      	b.eq	0xa888 <_stogir.stack.validate-inputs+0x158>
    a884:      	b	0xa890 <_stogir.stack.validate-inputs+0x160>
    a888:      	b	0xa894 <_stogir.stack.validate-inputs+0x164>
    a88c:      	b	0xa8b0 <_stogir.stack.validate-inputs+0x180>
    a890:      	b	0xab64 <_stogir.stack.validate-inputs+0x434>
    a894:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a894:  ARM64_RELOC_PAGE21	l_stogir.459
    a898:      	ldr	x16, [x16]
		000000000000a898:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    a89c:      	orr	x0, x16, xzr
    a8a0:      	str	x21, [sp, #0x90]
    a8a4:      	mov	x2, #0x1                ; =1
    a8a8:      	mov	x1, #0x1f               ; =31
    a8ac:      	b	0xa7a0 <_stogir.stack.validate-inputs+0x70>
    a8b0:      	sxtw	x23, w23
    a8b4:      	add	x16, sp, #0x10
    a8b8:      	ldr	x0, [x16, #0x8]
    a8bc:      	cmp	x23, #0x0
    a8c0:      	b.gt	0xa8e8 <_stogir.stack.validate-inputs+0x1b8>
    a8c4:      	str	x21, [sp, #0x90]
    a8c8:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a8c8:  ARM64_RELOC_PAGE21	l_stogir.460
    a8cc:      	ldr	x16, [x16]
		000000000000a8cc:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    a8d0:      	orr	x0, x16, xzr
    a8d4:      	mov	x2, #0x1                ; =1
    a8d8:      	mov	x1, #0x1f               ; =31
    a8dc:      	b	0xa8ac <_stogir.stack.validate-inputs+0x17c>
    a8e0:      	str	x8, [sp, #0x90]
    a8e4:      	b	0xa78c <_stogir.stack.validate-inputs+0x5c>
    a8e8:      	uxtb	w0, w0
    a8ec:      	cmp	x0, #0x83
    a8f0:      	cset	w1, lt
    a8f4:      	uxtb	w16, w1
    a8f8:      	cmp	w16, wzr
    a8fc:      	b.eq	0xa918 <_stogir.stack.validate-inputs+0x1e8>
    a900:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a900:  ARM64_RELOC_PAGE21	l_stogir.461
    a904:      	ldr	x16, [x16]
		000000000000a904:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    a908:      	orr	x2, x16, xzr
    a90c:      	add	x2, x0, x2
    a910:      	ldrb	w2, [x2]
    a914:      	b	0xa91c <_stogir.stack.validate-inputs+0x1ec>
    a918:      	movz	x2, #0x0, lsl #48
    a91c:      	uxtb	w2, w2
    a920:      	and	x2, x2, #0x1
    a924:      	uxtb	w2, w2
    a928:      	cmp	x2, #0x0
    a92c:      	b.eq	0xad58 <_stogir.stack.validate-inputs+0x628>
    a930:      	uxtb	w16, w1
    a934:      	cmp	w16, wzr
    a938:      	b.eq	0xa954 <_stogir.stack.validate-inputs+0x224>
    a93c:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a93c:  ARM64_RELOC_PAGE21	l_stogir.461
    a940:      	ldr	x16, [x16]
		000000000000a940:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    a944:      	orr	x1, x16, xzr
    a948:      	add	x0, x0, x1
    a94c:      	ldrb	w0, [x0]
    a950:      	b	0xa958 <_stogir.stack.validate-inputs+0x228>
    a954:      	movz	x0, #0x0, lsl #48
    a958:      	uxtb	w0, w0
    a95c:      	and	x0, x0, #0x4
    a960:      	uxtb	w0, w0
    a964:      	cmp	x0, #0x0
    a968:      	cset	w0, eq
    a96c:      	uxtb	w16, w0
    a970:      	cmp	w16, wzr
    a974:      	cset	x0, eq
    a978:      	cmp	x0, #0x0
    a97c:      	b.ne	0xad60 <_stogir.stack.validate-inputs+0x630>
    a980:      	lsr	w24, w24, #0
    a984:      	add	x8, sp, #0x40
    a988:      	mov	x0, x22
    a98c:      	mov	w1, w24
    a990:      	bl	0xa990 <_stogir.stack.validate-inputs+0x260>
		000000000000a990:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    a994:      	add	x16, sp, #0x40
    a998:      	ldr	w0, [x16]
    a99c:      	lsr	x16, x0, #0
    a9a0:      	cmp	x16, #0x1
    a9a4:      	b.eq	0xa9c0 <_stogir.stack.validate-inputs+0x290>
    a9a8:      	b.lo	0xa9b0 <_stogir.stack.validate-inputs+0x280>
    a9ac:      	b	0xa9c4 <_stogir.stack.validate-inputs+0x294>
    a9b0:      	cmp	x16, #0x0
    a9b4:      	b.eq	0xa9bc <_stogir.stack.validate-inputs+0x28c>
    a9b8:      	b	0xa9c4 <_stogir.stack.validate-inputs+0x294>
    a9bc:      	b	0xa9c8 <_stogir.stack.validate-inputs+0x298>
    a9c0:      	b	0xa9e4 <_stogir.stack.validate-inputs+0x2b4>
    a9c4:      	b	0xac58 <_stogir.stack.validate-inputs+0x528>
    a9c8:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000a9c8:  ARM64_RELOC_PAGE21	l_stogir.462
    a9cc:      	ldr	x16, [x16]
		000000000000a9cc:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    a9d0:      	orr	x0, x16, xzr
    a9d4:      	str	x21, [sp, #0x90]
    a9d8:      	mov	x2, #0x1                ; =1
    a9dc:      	mov	x1, #0x18               ; =24
    a9e0:      	b	0xa8dc <_stogir.stack.validate-inputs+0x1ac>
    a9e4:      	add	x16, sp, #0x40
    a9e8:      	ldr	x0, [x16, #0x8]
    a9ec:      	lsr	w1, w0, #0
    a9f0:      	ubfx	x1, x1, #8, #8
    a9f4:      	cmp	x1, #0x1
    a9f8:      	b.lt	0xad68 <_stogir.stack.validate-inputs+0x638>
    a9fc:      	cmp	x1, #0xb
    aa00:      	b.gt	0xad70 <_stogir.stack.validate-inputs+0x640>
    aa04:      	uxtb	w0, w0
    aa08:      	cmp	x0, #0x48
    aa0c:      	b.eq	0xad78 <_stogir.stack.validate-inputs+0x648>
    aa10:      	sxtw	x0, w24
    aa14:      	cmp	x1, #0x0
    aa18:      	cset	w23, eq
    aa1c:      	cmp	x1, #0x1
    aa20:      	cset	w25, eq
    aa24:      	cmp	x1, #0x2
    aa28:      	cset	w26, eq
    aa2c:      	cmp	x1, #0x7
    aa30:      	cset	w27, eq
    aa34:      	cmp	x1, #0x8
    aa38:      	cset	w28, eq
    aa3c:      	cmp	x1, #0x3
    aa40:      	cset	w2, eq
    aa44:      	cmp	x1, #0x9
    aa48:      	cset	w3, eq
    aa4c:      	cmp	x1, #0x4
    aa50:      	cset	w4, eq
    aa54:      	cmp	x1, #0xa
    aa58:      	cset	w5, eq
    aa5c:      	cmp	x1, #0xd
    aa60:      	cset	w6, eq
    aa64:      	cmp	x1, #0x5
    aa68:      	cset	w7, eq
    aa6c:      	cmp	x1, #0xb
    aa70:      	cset	w8, eq
    aa74:      	cmp	x1, #0xc
    aa78:      	cset	w9, eq
    aa7c:      	cmp	x1, #0x6
    aa80:      	cset	w1, eq
    aa84:      	uxtb	w16, w1
    aa88:      	cmp	w16, wzr
    aa8c:      	mov	x16, #0x8               ; =8
    aa90:      	movn	x17, #0x0, lsl #48
    aa94:      	csel	x1, x16, x17, ne
    aa98:      	cmp	x0, #0x0
    aa9c:      	b.ge	0xad80 <_stogir.stack.validate-inputs+0x650>
    aaa0:      	uxtb	w16, w19
    aaa4:      	cmp	w16, wzr
    aaa8:      	b.eq	0xaab4 <_stogir.stack.validate-inputs+0x384>
    aaac:      	cmp	x20, #0x10
    aab0:      	b.gt	0xaab8 <_stogir.stack.validate-inputs+0x388>
    aab4:      	mov	x20, #0x10              ; =16
    aab8:      	lsr	w24, w24, #0
    aabc:      	mov	x0, x22
    aac0:      	mov	w19, w2
    aac4:      	mov	x2, x20
    aac8:      	mov	w20, w3
    aacc:      	mov	w22, w4
    aad0:      	str	w7, [sp, #0x98]
    aad4:      	str	w8, [sp, #0xa0]
    aad8:      	add	x8, sp, #0x70
    aadc:      	str	w9, [sp, #0xa8]
    aae0:      	str	x1, [sp, #0xb0]
    aae4:      	mov	w1, w24
    aae8:      	mov	w24, w5
    aaec:      	str	x21, [sp, #0x90]
    aaf0:      	mov	w21, w6
    aaf4:      	bl	0xaaf4 <_stogir.stack.validate-inputs+0x3c4>
		000000000000aaf4:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    aaf8:      	add	x16, sp, #0x70
    aafc:      	ldr	w0, [x16]
    ab00:      	lsr	x16, x0, #0
    ab04:      	cmp	x16, #0x1
    ab08:      	b.eq	0xab24 <_stogir.stack.validate-inputs+0x3f4>
    ab0c:      	b.lo	0xab14 <_stogir.stack.validate-inputs+0x3e4>
    ab10:      	b	0xab28 <_stogir.stack.validate-inputs+0x3f8>
    ab14:      	cmp	x16, #0x0
    ab18:      	b.eq	0xab20 <_stogir.stack.validate-inputs+0x3f0>
    ab1c:      	b	0xab28 <_stogir.stack.validate-inputs+0x3f8>
    ab20:      	b	0xac60 <_stogir.stack.validate-inputs+0x530>
    ab24:      	b	0xab2c <_stogir.stack.validate-inputs+0x3fc>
    ab28:      	b	0xad34 <_stogir.stack.validate-inputs+0x604>
    ab2c:      	add	x16, sp, #0x70
    ab30:      	orr	x0, x16, xzr
    ab34:      	add	x1, x0, #0x8
    ab38:      	add	x16, sp, #0x70
    ab3c:      	ldr	x0, [x16, #0x8]
    ab40:      	ldr	x1, [x1, #0x8]
    ab44:      	mov	x2, #0x1                ; =1
    ab48:      	b	0xabbc <_stogir.stack.validate-inputs+0x48c>
    ab4c:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000ab4c:  ARM64_RELOC_PAGE21	l_stogir.463
    ab50:      	ldr	x16, [x16]
		000000000000ab50:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    ab54:      	orr	x0, x16, xzr
    ab58:      	mov	x2, #0x1                ; =1
    ab5c:      	mov	x1, #0x29               ; =41
    ab60:      	b	0xa9e0 <_stogir.stack.validate-inputs+0x2b0>
    ab64:      	brk	#0
    ab68:      	b	0xab64 <_stogir.stack.validate-inputs+0x434>
    ab6c:      	mov	x3, #0x1                ; =1
    ab70:      	lsr	w3, w3, #0
    ab74:      	sxtw	x3, w3
    ab78:      	and	x0, x3, #0xffffffff
    ab7c:      	movz	x2, #0x0, lsl #48
    ab80:      	movz	x1, #0x0, lsl #48
    ab84:      	b	0xab60 <_stogir.stack.validate-inputs+0x430>
    ab88:      	uxtb	w16, w23
    ab8c:      	cmp	w16, wzr
    ab90:      	b.eq	0xabc0 <_stogir.stack.validate-inputs+0x490>
    ab94:      	movz	x3, #0x0, lsl #48
    ab98:      	b	0xab70 <_stogir.stack.validate-inputs+0x440>
    ab9c:      	mov	x16, #0x1               ; =1
    aba0:      	str	x16, [sp, #0xb0]
    aba4:      	ldr	x3, [sp, #0xb0]
    aba8:      	lsr	w3, w3, #0
    abac:      	sxtw	x3, w3
    abb0:      	and	x0, x3, #0xffffffff
    abb4:      	movz	x2, #0x0, lsl #48
    abb8:      	movz	x1, #0x0, lsl #48
    abbc:      	b	0xab84 <_stogir.stack.validate-inputs+0x454>
    abc0:      	uxtb	w16, w25
    abc4:      	cmp	w16, wzr
    abc8:      	b.ne	0xab6c <_stogir.stack.validate-inputs+0x43c>
    abcc:      	uxtb	w16, w26
    abd0:      	cmp	w16, wzr
    abd4:      	b.ne	0xab6c <_stogir.stack.validate-inputs+0x43c>
    abd8:      	uxtb	w16, w27
    abdc:      	cmp	w16, wzr
    abe0:      	b.ne	0xab6c <_stogir.stack.validate-inputs+0x43c>
    abe4:      	uxtb	w16, w28
    abe8:      	cmp	w16, wzr
    abec:      	b.ne	0xab6c <_stogir.stack.validate-inputs+0x43c>
    abf0:      	uxtb	w16, w19
    abf4:      	cmp	w16, wzr
    abf8:      	b.ne	0xad20 <_stogir.stack.validate-inputs+0x5f0>
    abfc:      	uxtb	w16, w20
    ac00:      	cmp	w16, wzr
    ac04:      	b.ne	0xad20 <_stogir.stack.validate-inputs+0x5f0>
    ac08:      	uxtb	w16, w22
    ac0c:      	cmp	w16, wzr
    ac10:      	b.ne	0xad3c <_stogir.stack.validate-inputs+0x60c>
    ac14:      	uxtb	w16, w24
    ac18:      	cmp	w16, wzr
    ac1c:      	b.ne	0xad3c <_stogir.stack.validate-inputs+0x60c>
    ac20:      	uxtb	w16, w21
    ac24:      	cmp	w16, wzr
    ac28:      	b.ne	0xad3c <_stogir.stack.validate-inputs+0x60c>
    ac2c:      	uxtb	w16, w0
    ac30:      	cmp	w16, wzr
    ac34:      	b.ne	0xac50 <_stogir.stack.validate-inputs+0x520>
    ac38:      	uxtb	w16, w1
    ac3c:      	cmp	w16, wzr
    ac40:      	b.ne	0xac50 <_stogir.stack.validate-inputs+0x520>
    ac44:      	uxtb	w16, w2
    ac48:      	cmp	w16, wzr
    ac4c:      	b.eq	0xac54 <_stogir.stack.validate-inputs+0x524>
    ac50:      	mov	x3, #0x8                ; =8
    ac54:      	b	0xad40 <_stogir.stack.validate-inputs+0x610>
    ac58:      	brk	#0
    ac5c:      	b	0xac58 <_stogir.stack.validate-inputs+0x528>
    ac60:      	uxtb	w16, w23
    ac64:      	cmp	w16, wzr
    ac68:      	b.eq	0xac78 <_stogir.stack.validate-inputs+0x548>
    ac6c:      	movz	x16, #0x0, lsl #48
    ac70:      	str	x16, [sp, #0xb0]
    ac74:      	b	0xaba4 <_stogir.stack.validate-inputs+0x474>
    ac78:      	uxtb	w16, w25
    ac7c:      	cmp	w16, wzr
    ac80:      	b.ne	0xab9c <_stogir.stack.validate-inputs+0x46c>
    ac84:      	uxtb	w16, w26
    ac88:      	cmp	w16, wzr
    ac8c:      	b.ne	0xab9c <_stogir.stack.validate-inputs+0x46c>
    ac90:      	uxtb	w16, w27
    ac94:      	cmp	w16, wzr
    ac98:      	b.ne	0xab9c <_stogir.stack.validate-inputs+0x46c>
    ac9c:      	uxtb	w16, w28
    aca0:      	cmp	w16, wzr
    aca4:      	b.ne	0xab9c <_stogir.stack.validate-inputs+0x46c>
    aca8:      	uxtb	w16, w19
    acac:      	cmp	w16, wzr
    acb0:      	b.ne	0xad28 <_stogir.stack.validate-inputs+0x5f8>
    acb4:      	uxtb	w16, w20
    acb8:      	cmp	w16, wzr
    acbc:      	b.ne	0xad28 <_stogir.stack.validate-inputs+0x5f8>
    acc0:      	uxtb	w16, w22
    acc4:      	cmp	w16, wzr
    acc8:      	b.ne	0xad44 <_stogir.stack.validate-inputs+0x614>
    accc:      	uxtb	w16, w24
    acd0:      	cmp	w16, wzr
    acd4:      	b.ne	0xad44 <_stogir.stack.validate-inputs+0x614>
    acd8:      	uxtb	w16, w21
    acdc:      	cmp	w16, wzr
    ace0:      	b.ne	0xad44 <_stogir.stack.validate-inputs+0x614>
    ace4:      	ldr	w0, [sp, #0x98]
    ace8:      	uxtb	w16, w0
    acec:      	cmp	w16, wzr
    acf0:      	b.ne	0xad14 <_stogir.stack.validate-inputs+0x5e4>
    acf4:      	ldr	w1, [sp, #0xa0]
    acf8:      	uxtb	w16, w1
    acfc:      	cmp	w16, wzr
    ad00:      	b.ne	0xad14 <_stogir.stack.validate-inputs+0x5e4>
    ad04:      	ldr	w2, [sp, #0xa8]
    ad08:      	uxtb	w16, w2
    ad0c:      	cmp	w16, wzr
    ad10:      	b.eq	0xad1c <_stogir.stack.validate-inputs+0x5ec>
    ad14:      	mov	x16, #0x8               ; =8
    ad18:      	str	x16, [sp, #0xb0]
    ad1c:      	b	0xad4c <_stogir.stack.validate-inputs+0x61c>
    ad20:      	mov	x3, #0x2                ; =2
    ad24:      	b	0xab70 <_stogir.stack.validate-inputs+0x440>
    ad28:      	mov	x16, #0x2               ; =2
    ad2c:      	str	x16, [sp, #0xb0]
    ad30:      	b	0xaba4 <_stogir.stack.validate-inputs+0x474>
    ad34:      	brk	#0
    ad38:      	b	0xad34 <_stogir.stack.validate-inputs+0x604>
    ad3c:      	mov	x3, #0x4                ; =4
    ad40:      	b	0xad24 <_stogir.stack.validate-inputs+0x5f4>
    ad44:      	mov	x16, #0x4               ; =4
    ad48:      	str	x16, [sp, #0xb0]
    ad4c:      	b	0xad30 <_stogir.stack.validate-inputs+0x600>
    ad50:      	str	x8, [sp, #0x90]
    ad54:      	b	0xa78c <_stogir.stack.validate-inputs+0x5c>
    ad58:      	str	x21, [sp, #0x90]
    ad5c:      	b	0xa8c8 <_stogir.stack.validate-inputs+0x198>
    ad60:      	str	x21, [sp, #0x90]
    ad64:      	b	0xa8c8 <_stogir.stack.validate-inputs+0x198>
    ad68:      	str	x21, [sp, #0x90]
    ad6c:      	b	0xab4c <_stogir.stack.validate-inputs+0x41c>
    ad70:      	str	x21, [sp, #0x90]
    ad74:      	b	0xab4c <_stogir.stack.validate-inputs+0x41c>
    ad78:      	str	x21, [sp, #0x90]
    ad7c:      	b	0xab4c <_stogir.stack.validate-inputs+0x41c>
    ad80:      	str	x21, [sp, #0x90]
    ad84:      	mov	w19, w2
    ad88:      	mov	w20, w3
    ad8c:      	mov	x3, x1
    ad90:      	mov	w22, w4
    ad94:      	mov	w24, w5
    ad98:      	mov	w21, w6
    ad9c:      	mov	w0, w7
    ada0:      	mov	w1, w8
    ada4:      	mov	w2, w9
    ada8:      	b	0xab88 <_stogir.stack.validate-inputs+0x458>

000000000000adac <_stogir.locals.shape>:
    adac:      	sub	sp, sp, #0x40
    adb0:      	str	x29, [sp]
    adb4:      	str	x30, [sp, #0x8]
    adb8:      	mov	x29, sp
    adbc:      	str	x19, [sp, #0x20]
    adc0:      	str	x20, [sp, #0x28]
    adc4:      	str	x21, [sp, #0x30]
    adc8:      	str	x22, [sp, #0x38]
    adcc:      	sxtw	x19, w1
    add0:      	lsl	x20, x19, #2
    add4:      	cmp	x19, #0x0
    add8:      	cset	w1, gt
    addc:      	movz	x16, #0x0, lsl #48
    ade0:      	sub	x3, x16, x19
    ade4:      	sub	x4, x3, #0x1
    ade8:      	uxtb	w16, w1
    adec:      	cmp	w16, wzr
    adf0:      	b.eq	0xae30 <_stogir.locals.shape+0x84>
    adf4:      	ldr	x3, [x0, #0x8]
    adf8:      	cmp	x19, x3
    adfc:      	b.ge	0xae98 <_stogir.locals.shape+0xec>
    ae00:      	add	x3, x0, #0x78
    ae04:      	ldr	x3, [x3, #0x8]
    ae08:      	cmp	x19, x3
    ae0c:      	b.ge	0xb038 <_stogir.locals.shape+0x28c>
    ae10:      	ldr	x3, [x0, #0x78]
    ae14:      	add	x3, x20, x3
    ae18:      	ldr	w3, [x3]
    ae1c:      	sxtw	x3, w3
    ae20:      	cmp	x3, #0x0
    ae24:      	cset	w3, ge
    ae28:      	ubfx	x3, x3, #0, #8
    ae2c:      	b	0xb03c <_stogir.locals.shape+0x290>
    ae30:      	cmp	x19, #0x0
    ae34:      	b.ge	0xaea0 <_stogir.locals.shape+0xf4>
    ae38:      	add	x5, x0, #0x28
    ae3c:      	add	x6, x0, #0x50
    ae40:      	ldr	x5, [x5, #0x8]
    ae44:      	ldr	x6, [x6, #0x8]
    ae48:      	cmp	x5, x6
    ae4c:      	b.ne	0xae78 <_stogir.locals.shape+0xcc>
    ae50:      	cmp	x3, x5
    ae54:      	b.gt	0xb13c <_stogir.locals.shape+0x390>
    ae58:      	ldr	x3, [x0, #0x50]
    ae5c:      	add	x3, x3, x4, lsl #2
    ae60:      	ldr	w3, [x3]
    ae64:      	sxtw	x3, w3
    ae68:      	cmp	x3, #0x0
    ae6c:      	cset	w3, gt
    ae70:      	ubfx	x3, x3, #0, #8
    ae74:      	b	0xb140 <_stogir.locals.shape+0x394>
    ae78:      	movz	x3, #0x0, lsl #48
    ae7c:      	b	0xaea4 <_stogir.locals.shape+0xf8>
    ae80:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000ae80:  ARM64_RELOC_PAGE21	l_stogir.464
    ae84:      	ldr	x16, [x16]
		000000000000ae84:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    ae88:      	orr	x0, x16, xzr
    ae8c:      	mov	x2, #0x1                ; =1
    ae90:      	mov	x1, #0x1c               ; =28
    ae94:      	b	0xaf38 <_stogir.locals.shape+0x18c>
    ae98:      	movz	x3, #0x0, lsl #48
    ae9c:      	b	0xaea4 <_stogir.locals.shape+0xf8>
    aea0:      	movz	x3, #0x0, lsl #48
    aea4:      	cmp	x3, #0x0
    aea8:      	b.eq	0xaee4 <_stogir.locals.shape+0x138>
    aeac:      	uxtb	w16, w1
    aeb0:      	cmp	w16, wzr
    aeb4:      	b.eq	0xaecc <_stogir.locals.shape+0x120>
    aeb8:      	ldr	x1, [x0]
    aebc:      	add	x1, x1, x19, lsl #4
    aec0:      	ldr	x3, [x1]
    aec4:      	ldr	x1, [x1, #0x8]
    aec8:      	b	0xaedc <_stogir.locals.shape+0x130>
    aecc:      	ldr	x1, [x0, #0x28]
    aed0:      	add	x1, x1, x4, lsl #4
    aed4:      	ldr	x3, [x1]
    aed8:      	ldr	x1, [x1, #0x8]
    aedc:      	mov	x4, #0x1                ; =1
    aee0:      	b	0xaef0 <_stogir.locals.shape+0x144>
    aee4:      	movz	x4, #0x0, lsl #48
    aee8:      	movz	x3, #0x0, lsl #48
    aeec:      	movz	x1, #0x0, lsl #48
    aef0:      	lsr	w4, w4, #0
    aef4:      	lsr	x16, x4, #0
    aef8:      	cmp	x16, #0x1
    aefc:      	b.eq	0xaf18 <_stogir.locals.shape+0x16c>
    af00:      	b.lo	0xaf08 <_stogir.locals.shape+0x15c>
    af04:      	b	0xaf1c <_stogir.locals.shape+0x170>
    af08:      	cmp	x16, #0x0
    af0c:      	b.eq	0xaf14 <_stogir.locals.shape+0x168>
    af10:      	b	0xaf1c <_stogir.locals.shape+0x170>
    af14:      	b	0xaf20 <_stogir.locals.shape+0x174>
    af18:      	b	0xaf64 <_stogir.locals.shape+0x1b8>
    af1c:      	b	0xb14c <_stogir.locals.shape+0x3a0>
    af20:      	adrp	x16, 0xa000 <_stogir.stack.valid-frame-object-inputs?+0x124>
		000000000000af20:  ARM64_RELOC_PAGE21	l_stogir.465
    af24:      	ldr	x16, [x16]
		000000000000af24:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    af28:      	orr	x0, x16, xzr
    af2c:      	mov	x21, x8
    af30:      	mov	x2, #0x1                ; =1
    af34:      	mov	x1, #0x16               ; =22
    af38:      	str	x2, [x21]
    af3c:      	str	x0, [x21, #0x8]
    af40:      	str	x1, [x21, #0x10]
    af44:      	ldr	x19, [sp, #0x20]
    af48:      	ldr	x20, [sp, #0x28]
    af4c:      	ldr	x21, [sp, #0x30]
    af50:      	ldr	x22, [sp, #0x38]
    af54:      	ldr	x29, [sp]
    af58:      	ldr	x30, [sp, #0x8]
    af5c:      	add	sp, sp, #0x40
    af60:      	ret
    af64:      	lsr	w2, w2, #0
    af68:      	lsr	w4, w3, #0
    af6c:      	add	x16, sp, #0x10
    af70:      	str	x3, [x16]
    af74:      	add	x16, sp, #0x10
    af78:      	str	x1, [x16, #0x8]
    af7c:      	ubfx	x1, x4, #8, #8
    af80:      	lsr	w1, w1, #0
    af84:      	mov	x21, x8
    af88:      	mov	x22, x0
    af8c:      	mov	w0, w1
    af90:      	mov	w1, w2
    af94:      	bl	0xaf94 <_stogir.locals.shape+0x1e8>
		000000000000af94:  ARM64_RELOC_BRANCH26	_stogir.types.size
    af98:      	lsr	w0, w0, #0
    af9c:      	add	x16, sp, #0x10
    afa0:      	ldr	w1, [x16, #0xc]
    afa4:      	sxtw	x0, w0
    afa8:      	sxtw	x1, w1
    afac:      	cmp	x1, #0x0
    afb0:      	b.ne	0xafb8 <_stogir.locals.shape+0x20c>
    afb4:      	mov	x1, x0
    afb8:      	add	x16, sp, #0x10
    afbc:      	ldr	w2, [x16, #0x8]
    afc0:      	sxtw	x2, w2
    afc4:      	cmp	x2, #0x0
    afc8:      	cset	w3, eq
    afcc:      	ubfx	x3, x3, #0, #8
    afd0:      	cmp	x2, #0x0
    afd4:      	b.le	0xb078 <_stogir.locals.shape+0x2cc>
    afd8:      	add	x4, x22, #0x110
    afdc:      	add	x5, x4, #0x28
    afe0:      	ldr	x5, [x5, #0x8]
    afe4:      	cmp	x2, x5
    afe8:      	b.gt	0xb040 <_stogir.locals.shape+0x294>
    afec:      	sub	x2, x2, #0x1
    aff0:      	mov	x17, #0x18              ; =24
    aff4:      	mul	x2, x2, x17
    aff8:      	ldr	x5, [x4, #0x28]
    affc:      	add	x2, x2, x5
    b000:      	ldr	x5, [x2]
    b004:      	ldr	x2, [x2, #0x8]
    b008:      	ldr	x4, [x4, #0x8]
    b00c:      	cmp	x5, #0x0
    b010:      	b.lt	0xb144 <_stogir.locals.shape+0x398>
    b014:      	cmp	x5, x4
    b018:      	b.gt	0xb144 <_stogir.locals.shape+0x398>
    b01c:      	cmp	x2, #0x0
    b020:      	b.lt	0xb144 <_stogir.locals.shape+0x398>
    b024:      	sub	x4, x4, x5
    b028:      	cmp	x2, x4
    b02c:      	b.gt	0xb144 <_stogir.locals.shape+0x398>
    b030:      	mov	x2, #0x1                ; =1
    b034:      	b	0xb148 <_stogir.locals.shape+0x39c>
    b038:      	movz	x3, #0x0, lsl #48
    b03c:      	b	0xae9c <_stogir.locals.shape+0xf0>
    b040:      	movz	x2, #0x0, lsl #48
    b044:      	lsr	w2, w2, #0
    b048:      	lsr	x16, x2, #0
    b04c:      	cmp	x16, #0x1
    b050:      	b.eq	0xb06c <_stogir.locals.shape+0x2c0>
    b054:      	b.lo	0xb05c <_stogir.locals.shape+0x2b0>
    b058:      	b	0xb070 <_stogir.locals.shape+0x2c4>
    b05c:      	cmp	x16, #0x0
    b060:      	b.eq	0xb068 <_stogir.locals.shape+0x2bc>
    b064:      	b	0xb070 <_stogir.locals.shape+0x2c4>
    b068:      	b	0xb078 <_stogir.locals.shape+0x2cc>
    b06c:      	b	0xb074 <_stogir.locals.shape+0x2c8>
    b070:      	b	0xb154 <_stogir.locals.shape+0x3a8>
    b074:      	mov	x3, #0x1                ; =1
    b078:      	cmp	x19, #0x0
    b07c:      	b.le	0xae80 <_stogir.locals.shape+0xd4>
    b080:      	add	x16, sp, #0x10
    b084:      	ldr	w2, [x16]
    b088:      	uxtb	w2, w2
    b08c:      	cmp	x2, #0x48
    b090:      	b.ne	0xae80 <_stogir.locals.shape+0xd4>
    b094:      	ldr	x2, [x22, #0x78]
    b098:      	add	x2, x20, x2
    b09c:      	ldr	w2, [x2]
    b0a0:      	sxtw	x2, w2
    b0a4:      	cmp	x2, #0x3
    b0a8:      	b.ne	0xae80 <_stogir.locals.shape+0xd4>
    b0ac:      	cmp	x0, #0x0
    b0b0:      	b.le	0xae80 <_stogir.locals.shape+0xd4>
    b0b4:      	cmp	x3, #0x0
    b0b8:      	b.eq	0xae80 <_stogir.locals.shape+0xd4>
    b0bc:      	cmp	x1, #0x0
    b0c0:      	b.le	0xae80 <_stogir.locals.shape+0xd4>
    b0c4:      	sub	x2, x1, #0x1
    b0c8:      	and	x2, x2, x1
    b0cc:      	cmp	x2, #0x0
    b0d0:      	b.ne	0xae80 <_stogir.locals.shape+0xd4>
    b0d4:      	add	x16, sp, #0x10
    b0d8:      	ldr	w2, [x16, #0x4]
    b0dc:      	sxtw	x2, w2
    b0e0:      	cmp	x2, #0x0
    b0e4:      	cset	w3, gt
    b0e8:      	movz	x16, #0x0, lsl #48
    b0ec:      	sub	x4, x16, x2
    b0f0:      	sub	x5, x4, #0x1
    b0f4:      	uxtb	w16, w3
    b0f8:      	cmp	w16, wzr
    b0fc:      	b.eq	0xb174 <_stogir.locals.shape+0x3c8>
    b100:      	ldr	x4, [x22, #0x8]
    b104:      	cmp	x2, x4
    b108:      	b.ge	0xb1bc <_stogir.locals.shape+0x410>
    b10c:      	add	x4, x22, #0x78
    b110:      	ldr	x4, [x4, #0x8]
    b114:      	cmp	x2, x4
    b118:      	b.ge	0xb290 <_stogir.locals.shape+0x4e4>
    b11c:      	ldr	x4, [x22, #0x78]
    b120:      	add	x4, x4, x2, lsl #2
    b124:      	ldr	w4, [x4]
    b128:      	sxtw	x4, w4
    b12c:      	cmp	x4, #0x0
    b130:      	cset	w4, ge
    b134:      	ubfx	x4, x4, #0, #8
    b138:      	b	0xb294 <_stogir.locals.shape+0x4e8>
    b13c:      	movz	x3, #0x0, lsl #48
    b140:      	b	0xae7c <_stogir.locals.shape+0xd0>
    b144:      	movz	x2, #0x0, lsl #48
    b148:      	b	0xb044 <_stogir.locals.shape+0x298>
    b14c:      	brk	#0
    b150:      	b	0xb14c <_stogir.locals.shape+0x3a0>
    b154:      	brk	#0
    b158:      	b	0xb154 <_stogir.locals.shape+0x3a8>
    b15c:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000b15c:  ARM64_RELOC_PAGE21	l_stogir.466
    b160:      	ldr	x16, [x16]
		000000000000b160:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    b164:      	orr	x0, x16, xzr
    b168:      	mov	x2, #0x1                ; =1
    b16c:      	mov	x1, #0x2c               ; =44
    b170:      	b	0xae94 <_stogir.locals.shape+0xe8>
    b174:      	cmp	x2, #0x0
    b178:      	b.ge	0xb1c4 <_stogir.locals.shape+0x418>
    b17c:      	add	x6, x22, #0x28
    b180:      	add	x7, x22, #0x50
    b184:      	ldr	x6, [x6, #0x8]
    b188:      	ldr	x7, [x7, #0x8]
    b18c:      	cmp	x6, x7
    b190:      	b.ne	0xb288 <_stogir.locals.shape+0x4dc>
    b194:      	cmp	x4, x6
    b198:      	b.gt	0xb298 <_stogir.locals.shape+0x4ec>
    b19c:      	ldr	x4, [x22, #0x50]
    b1a0:      	add	x4, x4, x5, lsl #2
    b1a4:      	ldr	w4, [x4]
    b1a8:      	sxtw	x4, w4
    b1ac:      	cmp	x4, #0x0
    b1b0:      	cset	w4, gt
    b1b4:      	ubfx	x4, x4, #0, #8
    b1b8:      	b	0xb29c <_stogir.locals.shape+0x4f0>
    b1bc:      	movz	x4, #0x0, lsl #48
    b1c0:      	b	0xb1c8 <_stogir.locals.shape+0x41c>
    b1c4:      	movz	x4, #0x0, lsl #48
    b1c8:      	cmp	x4, #0x0
    b1cc:      	b.eq	0xb200 <_stogir.locals.shape+0x454>
    b1d0:      	uxtb	w16, w3
    b1d4:      	cmp	w16, wzr
    b1d8:      	b.eq	0xb1ec <_stogir.locals.shape+0x440>
    b1dc:      	ldr	x3, [x22]
    b1e0:      	add	x2, x3, x2, lsl #4
    b1e4:      	ldr	x2, [x2]
    b1e8:      	b	0xb1f8 <_stogir.locals.shape+0x44c>
    b1ec:      	ldr	x2, [x22, #0x28]
    b1f0:      	add	x2, x2, x5, lsl #4
    b1f4:      	ldr	x2, [x2]
    b1f8:      	mov	x3, #0x1                ; =1
    b1fc:      	b	0xb208 <_stogir.locals.shape+0x45c>
    b200:      	movz	x3, #0x0, lsl #48
    b204:      	movz	x2, #0x0, lsl #48
    b208:      	lsr	w3, w3, #0
    b20c:      	lsr	x16, x3, #0
    b210:      	cmp	x16, #0x1
    b214:      	b.eq	0xb230 <_stogir.locals.shape+0x484>
    b218:      	b.lo	0xb220 <_stogir.locals.shape+0x474>
    b21c:      	b	0xb234 <_stogir.locals.shape+0x488>
    b220:      	cmp	x16, #0x0
    b224:      	b.eq	0xb22c <_stogir.locals.shape+0x480>
    b228:      	b	0xb234 <_stogir.locals.shape+0x488>
    b22c:      	b	0xb238 <_stogir.locals.shape+0x48c>
    b230:      	b	0xb250 <_stogir.locals.shape+0x4a4>
    b234:      	b	0xb2d4 <_stogir.locals.shape+0x528>
    b238:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000b238:  ARM64_RELOC_PAGE21	l_stogir.467
    b23c:      	ldr	x16, [x16]
		000000000000b23c:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    b240:      	orr	x0, x16, xzr
    b244:      	mov	x2, #0x1                ; =1
    b248:      	mov	x1, #0x1d               ; =29
    b24c:      	b	0xb170 <_stogir.locals.shape+0x3c4>
    b250:      	add	x16, sp, #0x10
    b254:      	ldr	w3, [x16, #0x4]
    b258:      	sxtw	x3, w3
    b25c:      	cmp	x3, #0x0
    b260:      	b.le	0xb15c <_stogir.locals.shape+0x3b0>
    b264:      	uxtb	w2, w2
    b268:      	cmp	x2, #0x83
    b26c:      	b.ge	0xb2a0 <_stogir.locals.shape+0x4f4>
    b270:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000b270:  ARM64_RELOC_PAGE21	l_stogir.468
    b274:      	ldr	x16, [x16]
		000000000000b274:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    b278:      	orr	x3, x16, xzr
    b27c:      	add	x2, x2, x3
    b280:      	ldrb	w2, [x2]
    b284:      	b	0xb2a4 <_stogir.locals.shape+0x4f8>
    b288:      	movz	x4, #0x0, lsl #48
    b28c:      	b	0xb1c8 <_stogir.locals.shape+0x41c>
    b290:      	movz	x4, #0x0, lsl #48
    b294:      	b	0xb1c0 <_stogir.locals.shape+0x414>
    b298:      	movz	x4, #0x0, lsl #48
    b29c:      	b	0xb28c <_stogir.locals.shape+0x4e0>
    b2a0:      	movz	x2, #0x0, lsl #48
    b2a4:      	uxtb	w2, w2
    b2a8:      	and	x2, x2, #0x2
    b2ac:      	uxtb	w2, w2
    b2b0:      	cmp	x2, #0x0
    b2b4:      	cset	w2, eq
    b2b8:      	uxtb	w16, w2
    b2bc:      	cmp	w16, wzr
    b2c0:      	cset	x2, eq
    b2c4:      	cmp	x2, #0x0
    b2c8:      	b.eq	0xb15c <_stogir.locals.shape+0x3b0>
    b2cc:      	movz	x2, #0x0, lsl #48
    b2d0:      	b	0xb170 <_stogir.locals.shape+0x3c4>
    b2d4:      	brk	#0
    b2d8:      	b	0xb2d4 <_stogir.locals.shape+0x528>

000000000000b2dc <_stogir.conversion.policy>:
    b2dc:      	sub	sp, sp, #0x70
    b2e0:      	str	x29, [sp]
    b2e4:      	str	x30, [sp, #0x8]
    b2e8:      	mov	x29, sp
    b2ec:      	str	x19, [sp, #0x20]
    b2f0:      	str	x20, [sp, #0x28]
    b2f4:      	str	x21, [sp, #0x30]
    b2f8:      	str	x22, [sp, #0x38]
    b2fc:      	str	x23, [sp, #0x40]
    b300:      	str	x24, [sp, #0x48]
    b304:      	str	x25, [sp, #0x50]
    b308:      	str	x26, [sp, #0x58]
    b30c:      	str	x27, [sp, #0x60]
    b310:      	str	x28, [sp, #0x68]
    b314:      	sxtw	x19, w0
    b318:      	sxtw	x20, w1
    b31c:      	sxtw	x21, w2
    b320:      	cmp	x19, #0x24
    b324:      	b.ne	0xb364 <_stogir.conversion.policy+0x88>
    b328:      	cmp	x20, #0xf
    b32c:      	b.le	0xb580 <_stogir.conversion.policy+0x2a4>
    b330:      	cmp	x20, #0x80
    b334:      	b.ge	0xb580 <_stogir.conversion.policy+0x2a4>
    b338:      	and	x0, x20, #0xf
    b33c:      	lsr	w0, w0, #0
    b340:      	sxtw	x0, w0
    b344:      	cmp	x0, #0x1
    b348:      	b.lt	0xb580 <_stogir.conversion.policy+0x2a4>
    b34c:      	cmp	x0, #0xd
    b350:      	b.gt	0xb580 <_stogir.conversion.policy+0x2a4>
    b354:      	mov	x22, #0x1               ; =1
    b358:      	b	0xb360 <_stogir.conversion.policy+0x84>
    b35c:      	movz	x22, #0x0, lsl #48
    b360:      	b	0xb368 <_stogir.conversion.policy+0x8c>
    b364:      	movz	x22, #0x0, lsl #48
    b368:      	sxtw	x23, w3
    b36c:      	cmp	x20, #0xd
    b370:      	cset	w24, eq
    b374:      	cmp	x20, #0xc
    b378:      	cset	w25, eq
    b37c:      	cmp	x23, #0x4
    b380:      	cset	w26, eq
    b384:      	cmp	x23, #0x8
    b388:      	cset	w27, eq
    b38c:      	cmp	x22, #0x0
    b390:      	b.eq	0xb848 <_stogir.conversion.policy+0x56c>
    b394:      	lsr	w1, w1, #0
    b398:      	lsr	w3, w3, #0
    b39c:      	mov	w0, w1
    b3a0:      	mov	w1, w3
    b3a4:      	str	x8, [sp, #0x10]
    b3a8:      	mov	w28, w2
    b3ac:      	str	x19, [sp, #0x18]
    b3b0:      	mov	w19, w3
    b3b4:      	bl	0xb3b4 <_stogir.conversion.policy+0xd8>
		000000000000b3b4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    b3b8:      	lsr	w0, w0, #0
    b3bc:      	sxtw	x0, w0
    b3c0:      	b	0xb3d0 <_stogir.conversion.policy+0xf4>
    b3c4:      	mov	x0, #0x1                ; =1
    b3c8:      	lsr	w0, w0, #0
    b3cc:      	sxtw	x0, w0
    b3d0:      	cmp	x21, #0xd
    b3d4:      	cset	w1, eq
    b3d8:      	cmp	x21, #0xc
    b3dc:      	cset	w2, eq
    b3e0:      	cmp	x22, #0x0
    b3e4:      	b.eq	0xb85c <_stogir.conversion.policy+0x580>
    b3e8:      	lsr	w28, w28, #0
    b3ec:      	lsr	w19, w19, #0
    b3f0:      	mov	w22, w1
    b3f4:      	mov	w1, w19
    b3f8:      	mov	x19, x0
    b3fc:      	mov	w0, w28
    b400:      	mov	w28, w2
    b404:      	bl	0xb404 <_stogir.conversion.policy+0x128>
		000000000000b404:  ARM64_RELOC_BRANCH26	_stogir.types.size
    b408:      	lsr	w0, w0, #0
    b40c:      	sxtw	x0, w0
    b410:      	b	0xb420 <_stogir.conversion.policy+0x144>
    b414:      	mov	x23, #0x1               ; =1
    b418:      	lsr	w23, w23, #0
    b41c:      	sxtw	x0, w23
    b420:      	ldr	x1, [sp, #0x18]
    b424:      	cmp	x1, #0x21
    b428:      	b.lt	0xb504 <_stogir.conversion.policy+0x228>
    b42c:      	cmp	x1, #0x27
    b430:      	b.gt	0xb504 <_stogir.conversion.policy+0x228>
    b434:      	lsl	x2, x19, #3
    b438:      	lsr	w2, w2, #0
    b43c:      	sxtw	x2, w2
    b440:      	cmp	x2, #0x0
    b444:      	b.le	0xb504 <_stogir.conversion.policy+0x228>
    b448:      	lsl	x0, x0, #3
    b44c:      	lsr	w0, w0, #0
    b450:      	sxtw	x0, w0
    b454:      	cmp	x0, #0x0
    b458:      	b.le	0xb504 <_stogir.conversion.policy+0x228>
    b45c:      	cmp	x1, #0x26
    b460:      	cset	w3, eq
    b464:      	cmp	x20, #0x1
    b468:      	cset	w4, ge
    b46c:      	cmp	x20, #0xb
    b470:      	cset	w5, le
    b474:      	cmp	x21, #0x1
    b478:      	cset	w6, ge
    b47c:      	cmp	x21, #0xb
    b480:      	cset	w7, le
    b484:      	cmp	x1, #0x25
    b488:      	b.lt	0xb704 <_stogir.conversion.policy+0x428>
    b48c:      	ubfx	x8, x22, #0, #8
    b490:      	cmp	x1, #0x25
    b494:      	b.ne	0xb774 <_stogir.conversion.policy+0x498>
    b498:      	uxtb	w16, w4
    b49c:      	cmp	w16, wzr
    b4a0:      	b.eq	0xb76c <_stogir.conversion.policy+0x490>
    b4a4:      	uxtb	w16, w5
    b4a8:      	cmp	w16, wzr
    b4ac:      	b.eq	0xb76c <_stogir.conversion.policy+0x490>
    b4b0:      	uxtb	w16, w28
    b4b4:      	cmp	w16, wzr
    b4b8:      	b.eq	0xb4c0 <_stogir.conversion.policy+0x1e4>
    b4bc:      	mov	x8, #0x1                ; =1
    b4c0:      	b	0xb770 <_stogir.conversion.policy+0x494>
    b4c4:      	uxtb	w16, w26
    b4c8:      	cmp	w16, wzr
    b4cc:      	b.ne	0xb560 <_stogir.conversion.policy+0x284>
    b4d0:      	uxtb	w16, w27
    b4d4:      	cmp	w16, wzr
    b4d8:      	b.ne	0xb560 <_stogir.conversion.policy+0x284>
    b4dc:      	movn	x23, #0x0, lsl #48
    b4e0:      	b	0xb418 <_stogir.conversion.policy+0x13c>
    b4e4:      	uxtb	w16, w26
    b4e8:      	cmp	w16, wzr
    b4ec:      	b.ne	0xb570 <_stogir.conversion.policy+0x294>
    b4f0:      	uxtb	w16, w27
    b4f4:      	cmp	w16, wzr
    b4f8:      	b.ne	0xb570 <_stogir.conversion.policy+0x294>
    b4fc:      	movn	x0, #0x0, lsl #48
    b500:      	b	0xb3c8 <_stogir.conversion.policy+0xec>
    b504:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000b504:  ARM64_RELOC_PAGE21	l_stogir.469
    b508:      	ldr	x16, [x16]
		000000000000b508:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    b50c:      	orr	x0, x16, xzr
    b510:      	mov	x1, #0x1                ; =1
    b514:      	mov	x2, #0x22               ; =34
    b518:      	ldr	x3, [sp, #0x10]
    b51c:      	str	x1, [x3]
    b520:      	str	x0, [x3, #0x8]
    b524:      	str	x2, [x3, #0x10]
    b528:      	ldr	x19, [sp, #0x20]
    b52c:      	ldr	x20, [sp, #0x28]
    b530:      	ldr	x21, [sp, #0x30]
    b534:      	ldr	x22, [sp, #0x38]
    b538:      	ldr	x23, [sp, #0x40]
    b53c:      	ldr	x24, [sp, #0x48]
    b540:      	ldr	x25, [sp, #0x50]
    b544:      	ldr	x26, [sp, #0x58]
    b548:      	ldr	x27, [sp, #0x60]
    b54c:      	ldr	x28, [sp, #0x68]
    b550:      	ldr	x29, [sp]
    b554:      	ldr	x30, [sp, #0x8]
    b558:      	add	sp, sp, #0x70
    b55c:      	ret
    b560:      	cmp	x21, #0x0
    b564:      	b.ne	0xb5bc <_stogir.conversion.policy+0x2e0>
    b568:      	movz	x23, #0x0, lsl #48
    b56c:      	b	0xb418 <_stogir.conversion.policy+0x13c>
    b570:      	cmp	x20, #0x0
    b574:      	b.ne	0xb634 <_stogir.conversion.policy+0x358>
    b578:      	movz	x0, #0x0, lsl #48
    b57c:      	b	0xb3c8 <_stogir.conversion.policy+0xec>
    b580:      	cmp	x21, #0xf
    b584:      	b.le	0xb35c <_stogir.conversion.policy+0x80>
    b588:      	cmp	x21, #0x80
    b58c:      	b.ge	0xb5b4 <_stogir.conversion.policy+0x2d8>
    b590:      	and	x0, x21, #0xf
    b594:      	lsr	w0, w0, #0
    b598:      	sxtw	x0, w0
    b59c:      	cmp	x0, #0x1
    b5a0:      	b.lt	0xb6ac <_stogir.conversion.policy+0x3d0>
    b5a4:      	cmp	x0, #0xd
    b5a8:      	cset	w0, le
    b5ac:      	ubfx	x22, x0, #0, #8
    b5b0:      	b	0xb6b0 <_stogir.conversion.policy+0x3d4>
    b5b4:      	movz	x22, #0x0, lsl #48
    b5b8:      	b	0xb360 <_stogir.conversion.policy+0x84>
    b5bc:      	cmp	x21, #0x1
    b5c0:      	b.eq	0xb414 <_stogir.conversion.policy+0x138>
    b5c4:      	cmp	x21, #0x2
    b5c8:      	b.eq	0xb414 <_stogir.conversion.policy+0x138>
    b5cc:      	cmp	x21, #0x7
    b5d0:      	b.eq	0xb414 <_stogir.conversion.policy+0x138>
    b5d4:      	cmp	x21, #0x8
    b5d8:      	b.eq	0xb414 <_stogir.conversion.policy+0x138>
    b5dc:      	cmp	x21, #0x3
    b5e0:      	b.eq	0xb7a0 <_stogir.conversion.policy+0x4c4>
    b5e4:      	cmp	x21, #0x9
    b5e8:      	b.eq	0xb7a0 <_stogir.conversion.policy+0x4c4>
    b5ec:      	cmp	x21, #0x4
    b5f0:      	b.eq	0xb810 <_stogir.conversion.policy+0x534>
    b5f4:      	cmp	x21, #0xa
    b5f8:      	b.eq	0xb810 <_stogir.conversion.policy+0x534>
    b5fc:      	uxtb	w16, w22
    b600:      	cmp	w16, wzr
    b604:      	b.ne	0xb810 <_stogir.conversion.policy+0x534>
    b608:      	cmp	x21, #0x5
    b60c:      	b.eq	0xb830 <_stogir.conversion.policy+0x554>
    b610:      	cmp	x21, #0xb
    b614:      	b.eq	0xb830 <_stogir.conversion.policy+0x554>
    b618:      	uxtb	w16, w28
    b61c:      	cmp	w16, wzr
    b620:      	b.ne	0xb830 <_stogir.conversion.policy+0x554>
    b624:      	cmp	x21, #0x6
    b628:      	b.eq	0xb630 <_stogir.conversion.policy+0x354>
    b62c:      	movn	x23, #0x0, lsl #48
    b630:      	b	0xb834 <_stogir.conversion.policy+0x558>
    b634:      	cmp	x20, #0x1
    b638:      	b.eq	0xb3c4 <_stogir.conversion.policy+0xe8>
    b63c:      	cmp	x20, #0x2
    b640:      	b.eq	0xb3c4 <_stogir.conversion.policy+0xe8>
    b644:      	cmp	x20, #0x7
    b648:      	b.eq	0xb3c4 <_stogir.conversion.policy+0xe8>
    b64c:      	cmp	x20, #0x8
    b650:      	b.eq	0xb3c4 <_stogir.conversion.policy+0xe8>
    b654:      	cmp	x20, #0x3
    b658:      	b.eq	0xb7a8 <_stogir.conversion.policy+0x4cc>
    b65c:      	cmp	x20, #0x9
    b660:      	b.eq	0xb7a8 <_stogir.conversion.policy+0x4cc>
    b664:      	cmp	x20, #0x4
    b668:      	b.eq	0xb818 <_stogir.conversion.policy+0x53c>
    b66c:      	cmp	x20, #0xa
    b670:      	b.eq	0xb818 <_stogir.conversion.policy+0x53c>
    b674:      	uxtb	w16, w24
    b678:      	cmp	w16, wzr
    b67c:      	b.ne	0xb818 <_stogir.conversion.policy+0x53c>
    b680:      	cmp	x20, #0x5
    b684:      	b.eq	0xb838 <_stogir.conversion.policy+0x55c>
    b688:      	cmp	x20, #0xb
    b68c:      	b.eq	0xb838 <_stogir.conversion.policy+0x55c>
    b690:      	uxtb	w16, w25
    b694:      	cmp	w16, wzr
    b698:      	b.ne	0xb838 <_stogir.conversion.policy+0x55c>
    b69c:      	cmp	x20, #0x6
    b6a0:      	b.ne	0xb840 <_stogir.conversion.policy+0x564>
    b6a4:      	mov	x0, x23
    b6a8:      	b	0xb844 <_stogir.conversion.policy+0x568>
    b6ac:      	movz	x22, #0x0, lsl #48
    b6b0:      	b	0xb5b8 <_stogir.conversion.policy+0x2dc>
    b6b4:      	mov	x4, #0x1                ; =1
    b6b8:      	cmp	x4, #0x0
    b6bc:      	b.ne	0xb504 <_stogir.conversion.policy+0x228>
    b6c0:      	cmp	x1, #0x23
    b6c4:      	b.eq	0xb6d4 <_stogir.conversion.policy+0x3f8>
    b6c8:      	uxtb	w16, w3
    b6cc:      	cmp	w16, wzr
    b6d0:      	b.eq	0xb6d8 <_stogir.conversion.policy+0x3fc>
    b6d4:      	mov	x2, x0
    b6d8:      	and	x0, x2, #0xffffffff
    b6dc:      	movz	x1, #0x0, lsl #48
    b6e0:      	movz	x2, #0x0, lsl #48
    b6e4:      	b	0xb518 <_stogir.conversion.policy+0x23c>
    b6e8:      	movz	x8, #0x0, lsl #48
    b6ec:      	cmp	x8, #0x0
    b6f0:      	cset	w4, ne
    b6f4:      	uxtb	w16, w4
    b6f8:      	cmp	w16, wzr
    b6fc:      	cset	x4, eq
    b700:      	b	0xb6b8 <_stogir.conversion.policy+0x3dc>
    b704:      	cmp	x1, #0x24
    b708:      	b.ne	0xb724 <_stogir.conversion.policy+0x448>
    b70c:      	cmp	x2, x0
    b710:      	cset	w4, eq
    b714:      	uxtb	w16, w4
    b718:      	cmp	w16, wzr
    b71c:      	cset	x4, eq
    b720:      	b	0xb6b8 <_stogir.conversion.policy+0x3dc>
    b724:      	uxtb	w16, w4
    b728:      	cmp	w16, wzr
    b72c:      	b.eq	0xb6b4 <_stogir.conversion.policy+0x3d8>
    b730:      	uxtb	w16, w5
    b734:      	cmp	w16, wzr
    b738:      	b.eq	0xb6b4 <_stogir.conversion.policy+0x3d8>
    b73c:      	uxtb	w16, w6
    b740:      	cmp	w16, wzr
    b744:      	b.eq	0xb7e0 <_stogir.conversion.policy+0x504>
    b748:      	uxtb	w16, w7
    b74c:      	cmp	w16, wzr
    b750:      	b.eq	0xb7e0 <_stogir.conversion.policy+0x504>
    b754:      	cmp	x1, #0x23
    b758:      	b.ne	0xb820 <_stogir.conversion.policy+0x544>
    b75c:      	cmp	x0, x2
    b760:      	cset	w4, ge
    b764:      	ubfx	x4, x4, #0, #8
    b768:      	b	0xb82c <_stogir.conversion.policy+0x550>
    b76c:      	movz	x8, #0x0, lsl #48
    b770:      	b	0xb6ec <_stogir.conversion.policy+0x410>
    b774:      	uxtb	w16, w3
    b778:      	cmp	w16, wzr
    b77c:      	b.eq	0xb7b8 <_stogir.conversion.policy+0x4dc>
    b780:      	uxtb	w16, w25
    b784:      	cmp	w16, wzr
    b788:      	b.ne	0xb7fc <_stogir.conversion.policy+0x520>
    b78c:      	uxtb	w16, w24
    b790:      	cmp	w16, wzr
    b794:      	b.ne	0xb7fc <_stogir.conversion.policy+0x520>
    b798:      	movz	x8, #0x0, lsl #48
    b79c:      	b	0xb7b4 <_stogir.conversion.policy+0x4d8>
    b7a0:      	mov	x23, #0x2               ; =2
    b7a4:      	b	0xb418 <_stogir.conversion.policy+0x13c>
    b7a8:      	mov	x0, #0x2                ; =2
    b7ac:      	b	0xb3c8 <_stogir.conversion.policy+0xec>
    b7b0:      	movz	x8, #0x0, lsl #48
    b7b4:      	b	0xb6ec <_stogir.conversion.policy+0x410>
    b7b8:      	cmp	x1, #0x27
    b7bc:      	b.ne	0xb6e8 <_stogir.conversion.policy+0x40c>
    b7c0:      	uxtb	w16, w25
    b7c4:      	cmp	w16, wzr
    b7c8:      	b.ne	0xb7e8 <_stogir.conversion.policy+0x50c>
    b7cc:      	uxtb	w16, w24
    b7d0:      	cmp	w16, wzr
    b7d4:      	b.ne	0xb7e8 <_stogir.conversion.policy+0x50c>
    b7d8:      	movz	x8, #0x0, lsl #48
    b7dc:      	b	0xb7f8 <_stogir.conversion.policy+0x51c>
    b7e0:      	mov	x4, #0x1                ; =1
    b7e4:      	b	0xb6b8 <_stogir.conversion.policy+0x3dc>
    b7e8:      	uxtb	w16, w28
    b7ec:      	cmp	w16, wzr
    b7f0:      	b.eq	0xb7f8 <_stogir.conversion.policy+0x51c>
    b7f4:      	mov	x8, #0x1                ; =1
    b7f8:      	b	0xb6ec <_stogir.conversion.policy+0x410>
    b7fc:      	uxtb	w16, w6
    b800:      	cmp	w16, wzr
    b804:      	b.eq	0xb7b0 <_stogir.conversion.policy+0x4d4>
    b808:      	ubfx	x8, x7, #0, #8
    b80c:      	b	0xb7b4 <_stogir.conversion.policy+0x4d8>
    b810:      	mov	x23, #0x4               ; =4
    b814:      	b	0xb7a4 <_stogir.conversion.policy+0x4c8>
    b818:      	mov	x0, #0x4                ; =4
    b81c:      	b	0xb7ac <_stogir.conversion.policy+0x4d0>
    b820:      	cmp	x0, x2
    b824:      	cset	w4, le
    b828:      	ubfx	x4, x4, #0, #8
    b82c:      	b	0xb7e4 <_stogir.conversion.policy+0x508>
    b830:      	mov	x23, #0x8               ; =8
    b834:      	b	0xb814 <_stogir.conversion.policy+0x538>
    b838:      	mov	x0, #0x8                ; =8
    b83c:      	b	0xb81c <_stogir.conversion.policy+0x540>
    b840:      	movn	x0, #0x0, lsl #48
    b844:      	b	0xb83c <_stogir.conversion.policy+0x560>
    b848:      	str	x8, [sp, #0x10]
    b84c:      	str	x19, [sp, #0x18]
    b850:      	mov	w28, w2
    b854:      	mov	w19, w3
    b858:      	b	0xb4e4 <_stogir.conversion.policy+0x208>
    b85c:      	mov	x19, x0
    b860:      	mov	w22, w1
    b864:      	mov	w28, w2
    b868:      	b	0xb4c4 <_stogir.conversion.policy+0x1e8>

000000000000b86c <_stogir.conditional.operands>:
    b86c:      	sub	sp, sp, #0x30
    b870:      	str	x19, [sp, #0x20]
    b874:      	str	x20, [sp, #0x28]
    b878:      	sxtw	x1, w1
    b87c:      	cmp	x1, #0x0
    b880:      	b.eq	0xb8d4 <_stogir.conditional.operands+0x68>
    b884:      	cmp	x1, #0x0
    b888:      	b.lt	0xb8a8 <_stogir.conditional.operands+0x3c>
    b88c:      	cmp	x1, #0xd
    b890:      	b.gt	0xb8a8 <_stogir.conditional.operands+0x3c>
    b894:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000b894:  ARM64_RELOC_PAGE21	l_stogir.470
    b898:      	ldr	x16, [x16]
		000000000000b898:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    b89c:      	orr	x5, x16, xzr
    b8a0:      	movz	x6, #0x0, lsl #48
    b8a4:      	b	0xb8e4 <_stogir.conditional.operands+0x78>
    b8a8:      	cmp	x1, #0xf
    b8ac:      	b.le	0xb8d4 <_stogir.conditional.operands+0x68>
    b8b0:      	cmp	x1, #0x80
    b8b4:      	b.ge	0xb8d4 <_stogir.conditional.operands+0x68>
    b8b8:      	and	x5, x1, #0xf
    b8bc:      	lsr	w5, w5, #0
    b8c0:      	sxtw	x5, w5
    b8c4:      	cmp	x5, #0x1
    b8c8:      	b.lt	0xb8d4 <_stogir.conditional.operands+0x68>
    b8cc:      	cmp	x5, #0xd
    b8d0:      	b.le	0xb894 <_stogir.conditional.operands+0x28>
    b8d4:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000b8d4:  ARM64_RELOC_PAGE21	l_stogir.471
    b8d8:      	ldr	x16, [x16]
		000000000000b8d8:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    b8dc:      	orr	x5, x16, xzr
    b8e0:      	mov	x6, #0x2b               ; =43
    b8e4:      	sxtw	x2, w2
    b8e8:      	cmp	x2, #0x0
    b8ec:      	cset	w7, gt
    b8f0:      	movz	x16, #0x0, lsl #48
    b8f4:      	sub	x9, x16, x2
    b8f8:      	sub	x10, x9, #0x1
    b8fc:      	uxtb	w16, w7
    b900:      	cmp	w16, wzr
    b904:      	b.eq	0xb944 <_stogir.conditional.operands+0xd8>
    b908:      	ldr	x9, [x0, #0x8]
    b90c:      	cmp	x2, x9
    b910:      	b.ge	0xb99c <_stogir.conditional.operands+0x130>
    b914:      	add	x9, x0, #0x78
    b918:      	ldr	x9, [x9, #0x8]
    b91c:      	cmp	x2, x9
    b920:      	b.ge	0xbcc8 <_stogir.conditional.operands+0x45c>
    b924:      	ldr	x9, [x0, #0x78]
    b928:      	add	x9, x9, x2, lsl #2
    b92c:      	ldr	w9, [x9]
    b930:      	sxtw	x9, w9
    b934:      	cmp	x9, #0x0
    b938:      	cset	w9, ge
    b93c:      	ubfx	x9, x9, #0, #8
    b940:      	b	0xbccc <_stogir.conditional.operands+0x460>
    b944:      	cmp	x2, #0x0
    b948:      	b.ge	0xb9a4 <_stogir.conditional.operands+0x138>
    b94c:      	add	x11, x0, #0x28
    b950:      	add	x12, x0, #0x50
    b954:      	ldr	x11, [x11, #0x8]
    b958:      	ldr	x12, [x12, #0x8]
    b95c:      	cmp	x11, x12
    b960:      	b.ne	0xb98c <_stogir.conditional.operands+0x120>
    b964:      	cmp	x9, x11
    b968:      	b.gt	0xbcd0 <_stogir.conditional.operands+0x464>
    b96c:      	ldr	x9, [x0, #0x50]
    b970:      	add	x9, x9, x10, lsl #2
    b974:      	ldr	w9, [x9]
    b978:      	sxtw	x9, w9
    b97c:      	cmp	x9, #0x0
    b980:      	cset	w9, gt
    b984:      	ubfx	x9, x9, #0, #8
    b988:      	b	0xbcd4 <_stogir.conditional.operands+0x468>
    b98c:      	movz	x9, #0x0, lsl #48
    b990:      	b	0xb9a8 <_stogir.conditional.operands+0x13c>
    b994:      	movz	x14, #0x0, lsl #48
    b998:      	b	0xba38 <_stogir.conditional.operands+0x1cc>
    b99c:      	movz	x9, #0x0, lsl #48
    b9a0:      	b	0xb9a8 <_stogir.conditional.operands+0x13c>
    b9a4:      	movz	x9, #0x0, lsl #48
    b9a8:      	cmp	x9, #0x0
    b9ac:      	b.eq	0xb9e0 <_stogir.conditional.operands+0x174>
    b9b0:      	uxtb	w16, w7
    b9b4:      	cmp	w16, wzr
    b9b8:      	b.eq	0xb9cc <_stogir.conditional.operands+0x160>
    b9bc:      	ldr	x7, [x0]
    b9c0:      	add	x2, x7, x2, lsl #4
    b9c4:      	ldr	x2, [x2]
    b9c8:      	b	0xb9d8 <_stogir.conditional.operands+0x16c>
    b9cc:      	ldr	x2, [x0, #0x28]
    b9d0:      	add	x2, x2, x10, lsl #4
    b9d4:      	ldr	x2, [x2]
    b9d8:      	mov	x7, #0x1                ; =1
    b9dc:      	b	0xb9e8 <_stogir.conditional.operands+0x17c>
    b9e0:      	movz	x7, #0x0, lsl #48
    b9e4:      	movz	x2, #0x0, lsl #48
    b9e8:      	lsr	w7, w7, #0
    b9ec:      	lsr	x16, x7, #0
    b9f0:      	cmp	x16, #0x1
    b9f4:      	b.eq	0xba10 <_stogir.conditional.operands+0x1a4>
    b9f8:      	b.lo	0xba00 <_stogir.conditional.operands+0x194>
    b9fc:      	b	0xba14 <_stogir.conditional.operands+0x1a8>
    ba00:      	cmp	x16, #0x0
    ba04:      	b.eq	0xba0c <_stogir.conditional.operands+0x1a0>
    ba08:      	b	0xba14 <_stogir.conditional.operands+0x1a8>
    ba0c:      	b	0xba18 <_stogir.conditional.operands+0x1ac>
    ba10:      	b	0xba3c <_stogir.conditional.operands+0x1d0>
    ba14:      	b	0xbce8 <_stogir.conditional.operands+0x47c>
    ba18:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000ba18:  ARM64_RELOC_PAGE21	l_stogir.472
    ba1c:      	ldr	x16, [x16]
		000000000000ba1c:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    ba20:      	orr	x5, x16, xzr
    ba24:      	mov	x6, #0x16               ; =22
    ba28:      	b	0xba80 <_stogir.conditional.operands+0x214>
    ba2c:      	movz	x14, #0x0, lsl #48
    ba30:      	b	0xbae0 <_stogir.conditional.operands+0x274>
    ba34:      	movz	x14, #0x0, lsl #48
    ba38:      	b	0xbae8 <_stogir.conditional.operands+0x27c>
    ba3c:      	uxtb	w7, w2
    ba40:      	cmp	x7, #0x48
    ba44:      	b.eq	0xba70 <_stogir.conditional.operands+0x204>
    ba48:      	cmp	x7, #0x46
    ba4c:      	b.eq	0xba70 <_stogir.conditional.operands+0x204>
    ba50:      	lsr	w2, w2, #0
    ba54:      	orr	x7, x2, xzr
    ba58:      	ubfx	x7, x7, #8, #8
    ba5c:      	cmp	x7, #0x0
    ba60:      	b.eq	0xba70 <_stogir.conditional.operands+0x204>
    ba64:      	ubfx	x2, x2, #8, #8
    ba68:      	cmp	x2, #0xd
    ba6c:      	b.le	0xba80 <_stogir.conditional.operands+0x214>
    ba70:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000ba70:  ARM64_RELOC_PAGE21	l_stogir.473
    ba74:      	ldr	x16, [x16]
		000000000000ba74:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    ba78:      	orr	x5, x16, xzr
    ba7c:      	mov	x6, #0x2a               ; =42
    ba80:      	add	x16, sp, #0x10
    ba84:      	orr	x2, x16, xzr
    ba88:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000ba88:  ARM64_RELOC_PAGE21	l_stogir.474
    ba8c:      	ldr	x16, [x16]
		000000000000ba8c:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    ba90:      	orr	x7, x16, xzr
    ba94:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000ba94:  ARM64_RELOC_PAGE21	l_stogir.475
    ba98:      	ldr	x16, [x16]
		000000000000ba98:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    ba9c:      	orr	x9, x16, xzr
    baa0:      	lsr	w3, w3, #0
    baa4:      	lsr	w4, w4, #0
    baa8:      	add	x10, x0, #0x78
    baac:      	add	x11, x0, #0x28
    bab0:      	add	x12, x0, #0x50
    bab4:      	mov	x16, sp
    bab8:      	str	w3, [x16]
    babc:      	mov	x16, sp
    bac0:      	str	w4, [x16, #0x4]
    bac4:      	mov	x16, sp
    bac8:      	ldr	x3, [x16]
    bacc:      	add	x16, sp, #0x10
    bad0:      	str	x3, [x16]
    bad4:      	movz	x3, #0x0, lsl #48
    bad8:      	b	0xbb90 <_stogir.conditional.operands+0x324>
    badc:      	movz	x14, #0x0, lsl #48
    bae0:      	b	0xbae8 <_stogir.conditional.operands+0x27c>
    bae4:      	movz	x14, #0x0, lsl #48
    bae8:      	cmp	x14, #0x0
    baec:      	b.eq	0xbb20 <_stogir.conditional.operands+0x2b4>
    baf0:      	uxtb	w16, w4
    baf4:      	cmp	w16, wzr
    baf8:      	b.eq	0xbb0c <_stogir.conditional.operands+0x2a0>
    bafc:      	ldr	x4, [x0]
    bb00:      	add	x4, x4, x13, lsl #4
    bb04:      	ldr	x4, [x4]
    bb08:      	b	0xbb18 <_stogir.conditional.operands+0x2ac>
    bb0c:      	ldr	x4, [x0, #0x28]
    bb10:      	add	x4, x4, x15, lsl #4
    bb14:      	ldr	x4, [x4]
    bb18:      	mov	x13, #0x1               ; =1
    bb1c:      	b	0xbb28 <_stogir.conditional.operands+0x2bc>
    bb20:      	movz	x13, #0x0, lsl #48
    bb24:      	movz	x4, #0x0, lsl #48
    bb28:      	lsr	w13, w13, #0
    bb2c:      	lsr	x16, x13, #0
    bb30:      	cmp	x16, #0x1
    bb34:      	b.eq	0xbb50 <_stogir.conditional.operands+0x2e4>
    bb38:      	b.lo	0xbb40 <_stogir.conditional.operands+0x2d4>
    bb3c:      	b	0xbb54 <_stogir.conditional.operands+0x2e8>
    bb40:      	cmp	x16, #0x0
    bb44:      	b.eq	0xbb4c <_stogir.conditional.operands+0x2e0>
    bb48:      	b	0xbb54 <_stogir.conditional.operands+0x2e8>
    bb4c:      	b	0xbb58 <_stogir.conditional.operands+0x2ec>
    bb50:      	b	0xbb64 <_stogir.conditional.operands+0x2f8>
    bb54:      	b	0xbce0 <_stogir.conditional.operands+0x474>
    bb58:      	mov	x5, x7
    bb5c:      	mov	x6, #0x10               ; =16
    bb60:      	b	0xbb90 <_stogir.conditional.operands+0x324>
    bb64:      	uxtb	w13, w4
    bb68:      	cmp	x13, #0x48
    bb6c:      	b.eq	0xbb88 <_stogir.conditional.operands+0x31c>
    bb70:      	cmp	x13, #0x46
    bb74:      	b.eq	0xbb88 <_stogir.conditional.operands+0x31c>
    bb78:      	lsr	w4, w4, #0
    bb7c:      	ubfx	x4, x4, #8, #8
    bb80:      	cmp	x4, x1
    bb84:      	b.eq	0xbb90 <_stogir.conditional.operands+0x324>
    bb88:      	mov	x5, x9
    bb8c:      	mov	x6, #0x21               ; =33
    bb90:      	cmp	x3, #0x2
    bb94:      	b.ge	0xbbb8 <_stogir.conditional.operands+0x34c>
    bb98:      	add	x4, x3, #0x1
    bb9c:      	add	x3, x2, x3, lsl #2
    bba0:      	ldr	w3, [x3]
    bba4:      	sxtw	x3, w3
    bba8:      	and	x13, x3, #0xffffffff
    bbac:      	mov	x3, x4
    bbb0:      	mov	x4, #0x1                ; =1
    bbb4:      	b	0xbbc0 <_stogir.conditional.operands+0x354>
    bbb8:      	movz	x4, #0x0, lsl #48
    bbbc:      	movz	x13, #0x0, lsl #48
    bbc0:      	lsr	w4, w4, #0
    bbc4:      	lsr	x16, x4, #0
    bbc8:      	cmp	x16, #0x1
    bbcc:      	b.eq	0xbbe8 <_stogir.conditional.operands+0x37c>
    bbd0:      	b.lo	0xbbd8 <_stogir.conditional.operands+0x36c>
    bbd4:      	b	0xbbec <_stogir.conditional.operands+0x380>
    bbd8:      	cmp	x16, #0x0
    bbdc:      	b.eq	0xbbe4 <_stogir.conditional.operands+0x378>
    bbe0:      	b	0xbbec <_stogir.conditional.operands+0x380>
    bbe4:      	b	0xbc50 <_stogir.conditional.operands+0x3e4>
    bbe8:      	b	0xbbf0 <_stogir.conditional.operands+0x384>
    bbec:      	b	0xbcd8 <_stogir.conditional.operands+0x46c>
    bbf0:      	lsr	w13, w13, #0
    bbf4:      	sxtw	x13, w13
    bbf8:      	cmp	x13, #0x0
    bbfc:      	cset	w4, gt
    bc00:      	movz	x16, #0x0, lsl #48
    bc04:      	sub	x14, x16, x13
    bc08:      	sub	x15, x14, #0x1
    bc0c:      	uxtb	w16, w4
    bc10:      	cmp	w16, wzr
    bc14:      	b.eq	0xbc88 <_stogir.conditional.operands+0x41c>
    bc18:      	ldr	x14, [x0, #0x8]
    bc1c:      	cmp	x13, x14
    bc20:      	b.ge	0xbadc <_stogir.conditional.operands+0x270>
    bc24:      	ldr	x14, [x10, #0x8]
    bc28:      	cmp	x13, x14
    bc2c:      	b.ge	0xba2c <_stogir.conditional.operands+0x1c0>
    bc30:      	ldr	x14, [x0, #0x78]
    bc34:      	add	x14, x14, x13, lsl #2
    bc38:      	ldr	w14, [x14]
    bc3c:      	sxtw	x14, w14
    bc40:      	cmp	x14, #0x0
    bc44:      	cset	w14, ge
    bc48:      	ubfx	x14, x14, #0, #8
    bc4c:      	b	0xba30 <_stogir.conditional.operands+0x1c4>
    bc50:      	cmp	x6, #0x0
    bc54:      	b.ne	0xbc68 <_stogir.conditional.operands+0x3fc>
    bc58:      	and	x5, x1, #0xffffffff
    bc5c:      	movz	x0, #0x0, lsl #48
    bc60:      	movz	x6, #0x0, lsl #48
    bc64:      	b	0xbc6c <_stogir.conditional.operands+0x400>
    bc68:      	mov	x0, #0x1                ; =1
    bc6c:      	str	x0, [x8]
    bc70:      	str	x5, [x8, #0x8]
    bc74:      	str	x6, [x8, #0x10]
    bc78:      	ldr	x19, [sp, #0x20]
    bc7c:      	ldr	x20, [sp, #0x28]
    bc80:      	add	sp, sp, #0x30
    bc84:      	ret
    bc88:      	cmp	x13, #0x0
    bc8c:      	b.ge	0xbae4 <_stogir.conditional.operands+0x278>
    bc90:      	ldr	x19, [x11, #0x8]
    bc94:      	ldr	x20, [x12, #0x8]
    bc98:      	cmp	x19, x20
    bc9c:      	b.ne	0xba34 <_stogir.conditional.operands+0x1c8>
    bca0:      	cmp	x14, x19
    bca4:      	b.gt	0xb994 <_stogir.conditional.operands+0x128>
    bca8:      	ldr	x14, [x0, #0x50]
    bcac:      	add	x14, x14, x15, lsl #2
    bcb0:      	ldr	w14, [x14]
    bcb4:      	sxtw	x14, w14
    bcb8:      	cmp	x14, #0x0
    bcbc:      	cset	w14, gt
    bcc0:      	ubfx	x14, x14, #0, #8
    bcc4:      	b	0xb998 <_stogir.conditional.operands+0x12c>
    bcc8:      	movz	x9, #0x0, lsl #48
    bccc:      	b	0xb9a0 <_stogir.conditional.operands+0x134>
    bcd0:      	movz	x9, #0x0, lsl #48
    bcd4:      	b	0xb990 <_stogir.conditional.operands+0x124>
    bcd8:      	brk	#0
    bcdc:      	b	0xbcd8 <_stogir.conditional.operands+0x46c>
    bce0:      	brk	#0
    bce4:      	b	0xbce0 <_stogir.conditional.operands+0x474>
    bce8:      	brk	#0
    bcec:      	b	0xbce8 <_stogir.conditional.operands+0x47c>

000000000000bcf0 <_stogir.floating.unary?>:
    bcf0:      	sxtw	x0, w0
    bcf4:      	cmp	x0, #0x1f
    bcf8:      	b.ne	0xbd04 <_stogir.floating.unary?+0x14>
    bcfc:      	mov	x0, #0x1                ; =1
    bd00:      	b	0xbd10 <_stogir.floating.unary?+0x20>
    bd04:      	cmp	x0, #0x20
    bd08:      	cset	w0, eq
    bd0c:      	ubfx	x0, x0, #0, #8
    bd10:      	ret

000000000000bd14 <_stogir.floating.comparison?>:
    bd14:      	sxtw	x0, w0
    bd18:      	cmp	x0, #0xe
    bd1c:      	b.lt	0xbd30 <_stogir.floating.comparison?+0x1c>
    bd20:      	cmp	x0, #0x19
    bd24:      	cset	w0, le
    bd28:      	ubfx	x0, x0, #0, #8
    bd2c:      	b	0xbd34 <_stogir.floating.comparison?+0x20>
    bd30:      	movz	x0, #0x0, lsl #48
    bd34:      	ret

000000000000bd38 <_stogir.floating.operands>:
    bd38:      	sub	sp, sp, #0x90
    bd3c:      	str	x29, [sp]
    bd40:      	str	x30, [sp, #0x8]
    bd44:      	mov	x29, sp
    bd48:      	str	x19, [sp, #0x60]
    bd4c:      	str	x20, [sp, #0x68]
    bd50:      	str	x21, [sp, #0x70]
    bd54:      	str	x22, [sp, #0x78]
    bd58:      	str	x23, [sp, #0x80]
    bd5c:      	sxtw	x1, w1
    bd60:      	sxtw	x19, w2
    bd64:      	cmp	x1, #0x1f
    bd68:      	cset	w2, eq
    bd6c:      	cmp	x1, #0x20
    bd70:      	cset	w6, eq
    bd74:      	cmp	x1, #0xe
    bd78:      	b.lt	0xbda8 <_stogir.floating.operands+0x70>
    bd7c:      	cmp	x1, #0x19
    bd80:      	b.gt	0xbda8 <_stogir.floating.operands+0x70>
    bd84:      	cmp	x19, #0xc
    bd88:      	b.eq	0xbde4 <_stogir.floating.operands+0xac>
    bd8c:      	cmp	x19, #0xd
    bd90:      	b.eq	0xbde4 <_stogir.floating.operands+0xac>
    bd94:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000bd94:  ARM64_RELOC_PAGE21	l_stogir.476
    bd98:      	ldr	x16, [x16]
		000000000000bd98:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    bd9c:      	orr	x20, x16, xzr
    bda0:      	mov	x21, #0x22              ; =34
    bda4:      	b	0xbdf4 <_stogir.floating.operands+0xbc>
    bda8:      	uxtb	w16, w2
    bdac:      	cmp	w16, wzr
    bdb0:      	b.ne	0xbd84 <_stogir.floating.operands+0x4c>
    bdb4:      	uxtb	w16, w6
    bdb8:      	cmp	w16, wzr
    bdbc:      	b.ne	0xbd84 <_stogir.floating.operands+0x4c>
    bdc0:      	cmp	x1, #0x1a
    bdc4:      	b.lt	0xbdd0 <_stogir.floating.operands+0x98>
    bdc8:      	cmp	x1, #0x1d
    bdcc:      	b.le	0xbd84 <_stogir.floating.operands+0x4c>
    bdd0:      	cmp	x1, #0x3a
    bdd4:      	b.eq	0xbd84 <_stogir.floating.operands+0x4c>
    bdd8:      	cmp	x1, #0x3b
    bddc:      	b.eq	0xbd84 <_stogir.floating.operands+0x4c>
    bde0:      	b	0xbd94 <_stogir.floating.operands+0x5c>
    bde4:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000bde4:  ARM64_RELOC_PAGE21	l_stogir.477
    bde8:      	ldr	x16, [x16]
		000000000000bde8:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    bdec:      	orr	x20, x16, xzr
    bdf0:      	movz	x21, #0x0, lsl #48
    bdf4:      	lsr	w3, w3, #0
    bdf8:      	add	x16, sp, #0x10
    bdfc:      	str	w3, [x16]
    be00:      	uxtb	w16, w2
    be04:      	cmp	w16, wzr
    be08:      	b.ne	0xbe80 <_stogir.floating.operands+0x148>
    be0c:      	uxtb	w16, w6
    be10:      	cmp	w16, wzr
    be14:      	b.ne	0xbe80 <_stogir.floating.operands+0x148>
    be18:      	sxtw	x3, w4
    be1c:      	b	0xbe84 <_stogir.floating.operands+0x14c>
    be20:      	movz	x1, #0x0, lsl #48
    be24:      	uxtb	w1, w1
    be28:      	and	x1, x1, #0x2
    be2c:      	uxtb	w1, w1
    be30:      	cmp	x1, #0x0
    be34:      	cset	w1, eq
    be38:      	uxtb	w16, w1
    be3c:      	cmp	w16, wzr
    be40:      	cset	x1, eq
    be44:      	cmp	x1, #0x0
    be48:      	b.ne	0xbe6c <_stogir.floating.operands+0x134>
    be4c:      	cmp	x0, #0x65
    be50:      	b.eq	0xbe6c <_stogir.floating.operands+0x134>
    be54:      	cmp	x0, #0x66
    be58:      	b.eq	0xbe6c <_stogir.floating.operands+0x134>
    be5c:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000be5c:  ARM64_RELOC_PAGE21	l_stogir.478
    be60:      	ldr	x16, [x16]
		000000000000be60:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    be64:      	orr	x20, x16, xzr
    be68:      	mov	x21, #0x2d              ; =45
    be6c:      	b	0xbf6c <_stogir.floating.operands+0x234>
    be70:      	movz	x13, #0x0, lsl #48
    be74:      	b	0xbed8 <_stogir.floating.operands+0x1a0>
    be78:      	movz	x13, #0x0, lsl #48
    be7c:      	b	0xbee0 <_stogir.floating.operands+0x1a8>
    be80:      	sxtw	x3, w3
    be84:      	add	x16, sp, #0x20
    be88:      	orr	x2, x16, xzr
    be8c:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000be8c:  ARM64_RELOC_PAGE21	l_stogir.479
    be90:      	ldr	x16, [x16]
		000000000000be90:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    be94:      	orr	x4, x16, xzr
    be98:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000be98:  ARM64_RELOC_PAGE21	l_stogir.480
    be9c:      	ldr	x16, [x16]
		000000000000be9c:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    bea0:      	orr	x6, x16, xzr
    bea4:      	add	x7, x0, #0x78
    bea8:      	add	x9, x0, #0x28
    beac:      	add	x10, x0, #0x50
    beb0:      	lsr	w3, w3, #0
    beb4:      	add	x16, sp, #0x10
    beb8:      	str	w3, [x16, #0x4]
    bebc:      	add	x16, sp, #0x10
    bec0:      	ldr	x3, [x16]
    bec4:      	add	x16, sp, #0x20
    bec8:      	str	x3, [x16]
    becc:      	movz	x3, #0x0, lsl #48
    bed0:      	b	0xbf88 <_stogir.floating.operands+0x250>
    bed4:      	movz	x13, #0x0, lsl #48
    bed8:      	b	0xbee0 <_stogir.floating.operands+0x1a8>
    bedc:      	movz	x13, #0x0, lsl #48
    bee0:      	cmp	x13, #0x0
    bee4:      	b.eq	0xbf18 <_stogir.floating.operands+0x1e0>
    bee8:      	uxtb	w16, w11
    beec:      	cmp	w16, wzr
    bef0:      	b.eq	0xbf04 <_stogir.floating.operands+0x1cc>
    bef4:      	ldr	x11, [x0]
    bef8:      	add	x11, x11, x12, lsl #4
    befc:      	ldr	x11, [x11]
    bf00:      	b	0xbf10 <_stogir.floating.operands+0x1d8>
    bf04:      	ldr	x11, [x0, #0x28]
    bf08:      	add	x11, x11, x14, lsl #4
    bf0c:      	ldr	x11, [x11]
    bf10:      	mov	x12, #0x1               ; =1
    bf14:      	b	0xbf20 <_stogir.floating.operands+0x1e8>
    bf18:      	movz	x12, #0x0, lsl #48
    bf1c:      	movz	x11, #0x0, lsl #48
    bf20:      	lsr	w12, w12, #0
    bf24:      	lsr	x16, x12, #0
    bf28:      	cmp	x16, #0x1
    bf2c:      	b.eq	0xbf48 <_stogir.floating.operands+0x210>
    bf30:      	b.lo	0xbf38 <_stogir.floating.operands+0x200>
    bf34:      	b	0xbf4c <_stogir.floating.operands+0x214>
    bf38:      	cmp	x16, #0x0
    bf3c:      	b.eq	0xbf44 <_stogir.floating.operands+0x20c>
    bf40:      	b	0xbf4c <_stogir.floating.operands+0x214>
    bf44:      	b	0xbf50 <_stogir.floating.operands+0x218>
    bf48:      	b	0xbf70 <_stogir.floating.operands+0x238>
    bf4c:      	b	0xc18c <_stogir.floating.operands+0x454>
    bf50:      	mov	x20, x4
    bf54:      	mov	x21, #0x18              ; =24
    bf58:      	b	0xbf88 <_stogir.floating.operands+0x250>
    bf5c:      	adrp	x16, 0xb000 <_stogir.locals.shape+0x254>
		000000000000bf5c:  ARM64_RELOC_PAGE21	l_stogir.481
    bf60:      	ldr	x16, [x16]
		000000000000bf60:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    bf64:      	orr	x20, x16, xzr
    bf68:      	mov	x21, #0x21              ; =33
    bf6c:      	b	0xc058 <_stogir.floating.operands+0x320>
    bf70:      	lsr	w11, w11, #0
    bf74:      	ubfx	x11, x11, #8, #8
    bf78:      	cmp	x11, x19
    bf7c:      	b.eq	0xbf88 <_stogir.floating.operands+0x250>
    bf80:      	mov	x20, x6
    bf84:      	mov	x21, #0x1e              ; =30
    bf88:      	cmp	x3, #0x2
    bf8c:      	b.ge	0xbfb0 <_stogir.floating.operands+0x278>
    bf90:      	add	x11, x3, #0x1
    bf94:      	add	x3, x2, x3, lsl #2
    bf98:      	ldr	w3, [x3]
    bf9c:      	sxtw	x3, w3
    bfa0:      	and	x12, x3, #0xffffffff
    bfa4:      	mov	x3, x11
    bfa8:      	mov	x11, #0x1               ; =1
    bfac:      	b	0xbfb8 <_stogir.floating.operands+0x280>
    bfb0:      	movz	x11, #0x0, lsl #48
    bfb4:      	movz	x12, #0x0, lsl #48
    bfb8:      	lsr	w11, w11, #0
    bfbc:      	lsr	x16, x11, #0
    bfc0:      	cmp	x16, #0x1
    bfc4:      	b.eq	0xbfe0 <_stogir.floating.operands+0x2a8>
    bfc8:      	b.lo	0xbfd0 <_stogir.floating.operands+0x298>
    bfcc:      	b	0xbfe4 <_stogir.floating.operands+0x2ac>
    bfd0:      	cmp	x16, #0x0
    bfd4:      	b.eq	0xbfdc <_stogir.floating.operands+0x2a4>
    bfd8:      	b	0xbfe4 <_stogir.floating.operands+0x2ac>
    bfdc:      	b	0xc048 <_stogir.floating.operands+0x310>
    bfe0:      	b	0xbfe8 <_stogir.floating.operands+0x2b0>
    bfe4:      	b	0xc184 <_stogir.floating.operands+0x44c>
    bfe8:      	lsr	w12, w12, #0
    bfec:      	sxtw	x12, w12
    bff0:      	cmp	x12, #0x0
    bff4:      	cset	w11, gt
    bff8:      	movz	x16, #0x0, lsl #48
    bffc:      	sub	x13, x16, x12
    c000:      	sub	x14, x13, #0x1
    c004:      	uxtb	w16, w11
    c008:      	cmp	w16, wzr
    c00c:      	b.eq	0xc0d4 <_stogir.floating.operands+0x39c>
    c010:      	ldr	x13, [x0, #0x8]
    c014:      	cmp	x12, x13
    c018:      	b.ge	0xbed4 <_stogir.floating.operands+0x19c>
    c01c:      	ldr	x13, [x7, #0x8]
    c020:      	cmp	x12, x13
    c024:      	b.ge	0xbe70 <_stogir.floating.operands+0x138>
    c028:      	ldr	x13, [x0, #0x78]
    c02c:      	add	x13, x13, x12, lsl #2
    c030:      	ldr	w13, [x13]
    c034:      	sxtw	x13, w13
    c038:      	cmp	x13, #0x0
    c03c:      	cset	w13, ge
    c040:      	ubfx	x13, x13, #0, #8
    c044:      	b	0xbe74 <_stogir.floating.operands+0x13c>
    c048:      	sxtw	x22, w5
    c04c:      	cmp	x22, #0x0
    c050:      	b.ne	0xc070 <_stogir.floating.operands+0x338>
    c054:      	mov	x23, x8
    c058:      	cmp	x21, #0x0
    c05c:      	b.ne	0xc114 <_stogir.floating.operands+0x3dc>
    c060:      	and	x20, x19, #0xffffffff
    c064:      	movz	x0, #0x0, lsl #48
    c068:      	movz	x21, #0x0, lsl #48
    c06c:      	b	0xc118 <_stogir.floating.operands+0x3e0>
    c070:      	cmp	x1, #0x1d
    c074:      	b.ne	0xc19c <_stogir.floating.operands+0x464>
    c078:      	lsr	w5, w5, #0
    c07c:      	mov	w1, w5
    c080:      	mov	x23, x8
    c084:      	add	x8, sp, #0x30
    c088:      	bl	0xc088 <_stogir.floating.operands+0x350>
		000000000000c088:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    c08c:      	add	x16, sp, #0x30
    c090:      	ldr	w0, [x16]
    c094:      	lsr	x16, x0, #0
    c098:      	cmp	x16, #0x1
    c09c:      	b.eq	0xc0b8 <_stogir.floating.operands+0x380>
    c0a0:      	b.lo	0xc0a8 <_stogir.floating.operands+0x370>
    c0a4:      	b	0xc0bc <_stogir.floating.operands+0x384>
    c0a8:      	cmp	x16, #0x0
    c0ac:      	b.eq	0xc0b4 <_stogir.floating.operands+0x37c>
    c0b0:      	b	0xc0bc <_stogir.floating.operands+0x384>
    c0b4:      	b	0xc0c0 <_stogir.floating.operands+0x388>
    c0b8:      	b	0xc150 <_stogir.floating.operands+0x418>
    c0bc:      	b	0xc194 <_stogir.floating.operands+0x45c>
    c0c0:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c0c0:  ARM64_RELOC_PAGE21	l_stogir.482
    c0c4:      	ldr	x16, [x16]
		000000000000c0c4:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    c0c8:      	orr	x20, x16, xzr
    c0cc:      	mov	x21, #0x16              ; =22
    c0d0:      	b	0xbe6c <_stogir.floating.operands+0x134>
    c0d4:      	cmp	x12, #0x0
    c0d8:      	b.ge	0xbedc <_stogir.floating.operands+0x1a4>
    c0dc:      	ldr	x15, [x9, #0x8]
    c0e0:      	ldr	x22, [x10, #0x8]
    c0e4:      	cmp	x15, x22
    c0e8:      	b.ne	0xbe78 <_stogir.floating.operands+0x140>
    c0ec:      	cmp	x13, x15
    c0f0:      	b.gt	0xc148 <_stogir.floating.operands+0x410>
    c0f4:      	ldr	x13, [x0, #0x50]
    c0f8:      	add	x13, x13, x14, lsl #2
    c0fc:      	ldr	w13, [x13]
    c100:      	sxtw	x13, w13
    c104:      	cmp	x13, #0x0
    c108:      	cset	w13, gt
    c10c:      	ubfx	x13, x13, #0, #8
    c110:      	b	0xc14c <_stogir.floating.operands+0x414>
    c114:      	mov	x0, #0x1                ; =1
    c118:      	str	x0, [x23]
    c11c:      	str	x20, [x23, #0x8]
    c120:      	str	x21, [x23, #0x10]
    c124:      	ldr	x19, [sp, #0x60]
    c128:      	ldr	x20, [sp, #0x68]
    c12c:      	ldr	x21, [sp, #0x70]
    c130:      	ldr	x22, [sp, #0x78]
    c134:      	ldr	x23, [sp, #0x80]
    c138:      	ldr	x29, [sp]
    c13c:      	ldr	x30, [sp, #0x8]
    c140:      	add	sp, sp, #0x90
    c144:      	ret
    c148:      	movz	x13, #0x0, lsl #48
    c14c:      	b	0xbe7c <_stogir.floating.operands+0x144>
    c150:      	add	x16, sp, #0x30
    c154:      	ldr	x0, [x16, #0x8]
    c158:      	cmp	x22, #0x0
    c15c:      	b.lt	0xbe5c <_stogir.floating.operands+0x124>
    c160:      	uxtb	w0, w0
    c164:      	cmp	x0, #0x83
    c168:      	b.ge	0xbe20 <_stogir.floating.operands+0xe8>
    c16c:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c16c:  ARM64_RELOC_PAGE21	l_stogir.483
    c170:      	ldr	x16, [x16]
		000000000000c170:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    c174:      	orr	x1, x16, xzr
    c178:      	add	x1, x0, x1
    c17c:      	ldrb	w1, [x1]
    c180:      	b	0xbe24 <_stogir.floating.operands+0xec>
    c184:      	brk	#0
    c188:      	b	0xc184 <_stogir.floating.operands+0x44c>
    c18c:      	brk	#0
    c190:      	b	0xc18c <_stogir.floating.operands+0x454>
    c194:      	brk	#0
    c198:      	b	0xc194 <_stogir.floating.operands+0x45c>
    c19c:      	mov	x23, x8
    c1a0:      	b	0xbf5c <_stogir.floating.operands+0x224>

000000000000c1a4 <_stogir.types.signed?>:
    c1a4:      	sxtw	x0, w0
    c1a8:      	cmp	x0, #0x7
    c1ac:      	b.lt	0xc1c0 <_stogir.types.signed?+0x1c>
    c1b0:      	cmp	x0, #0xb
    c1b4:      	cset	w0, le
    c1b8:      	ubfx	x0, x0, #0, #8
    c1bc:      	b	0xc1c4 <_stogir.types.signed?+0x20>
    c1c0:      	movz	x0, #0x0, lsl #48
    c1c4:      	ret

000000000000c1c8 <_stogir.integer-binary.logical?>:
    c1c8:      	sxtw	x0, w0
    c1cc:      	cmp	x0, #0x2e
    c1d0:      	b.ne	0xc1ec <_stogir.integer-binary.logical?+0x24>
    c1d4:      	mov	x0, #0x1                ; =1
    c1d8:      	b	0xc1e8 <_stogir.integer-binary.logical?+0x20>
    c1dc:      	cmp	x0, #0x30
    c1e0:      	cset	w0, eq
    c1e4:      	ubfx	x0, x0, #0, #8
    c1e8:      	ret
    c1ec:      	cmp	x0, #0x2f
    c1f0:      	b.ne	0xc1dc <_stogir.integer-binary.logical?+0x14>
    c1f4:      	mov	x0, #0x1                ; =1
    c1f8:      	b	0xc1e8 <_stogir.integer-binary.logical?+0x20>

000000000000c1fc <_inherent$slice$data__i8>:
    c1fc:      	ret

000000000000c200 <_inherent$slice$data__u32>:
    c200:      	ret

000000000000c204 <_inherent$coil.arraylist.ArrayList$slice__stogir.node.Node>:
    c204:      	sub	sp, sp, #0x10
    c208:      	mov	x1, sp
    c20c:      	ldr	x2, [x0]
    c210:      	ldr	x0, [x0, #0x8]
    c214:      	str	x2, [x1]
    c218:      	str	x0, [x1, #0x8]
    c21c:      	ldr	x0, [sp]
    c220:      	ldr	x1, [sp, #0x8]
    c224:      	add	sp, sp, #0x10
    c228:      	ret

000000000000c22c <_inherent$slice$at__stogir.node.Node>:
    c22c:      	add	x0, x0, x2, lsl #4
    c230:      	ret

000000000000c234 <_inherent$slice$new__u8>:
    c234:      	sub	sp, sp, #0x10
    c238:      	mov	x2, sp
    c23c:      	str	x0, [x2]
    c240:      	str	x1, [x2, #0x8]
    c244:      	ldr	x0, [sp]
    c248:      	ldr	x1, [sp, #0x8]
    c24c:      	add	sp, sp, #0x10
    c250:      	ret

000000000000c254 <_stogir.vector-lanes.operands>:
    c254:      	sub	sp, sp, #0x110
    c258:      	str	x29, [sp]
    c25c:      	str	x30, [sp, #0x8]
    c260:      	mov	x29, sp
    c264:      	str	x19, [sp, #0xc0]
    c268:      	str	x20, [sp, #0xc8]
    c26c:      	str	x21, [sp, #0xd0]
    c270:      	str	x22, [sp, #0xd8]
    c274:      	str	x23, [sp, #0xe0]
    c278:      	str	x24, [sp, #0xe8]
    c27c:      	str	x25, [sp, #0xf0]
    c280:      	str	x26, [sp, #0xf8]
    c284:      	str	x27, [sp, #0x100]
    c288:      	str	x28, [sp, #0x108]
    c28c:      	sxtw	x4, w4
    c290:      	cmp	x4, #0x0
    c294:      	cset	w7, gt
    c298:      	movz	x16, #0x0, lsl #48
    c29c:      	sub	x9, x16, x4
    c2a0:      	sub	x10, x9, #0x1
    c2a4:      	uxtb	w16, w7
    c2a8:      	cmp	w16, wzr
    c2ac:      	b.eq	0xc2ec <_stogir.vector-lanes.operands+0x98>
    c2b0:      	ldr	x9, [x0, #0x8]
    c2b4:      	cmp	x4, x9
    c2b8:      	b.ge	0xc344 <_stogir.vector-lanes.operands+0xf0>
    c2bc:      	add	x9, x0, #0x78
    c2c0:      	ldr	x9, [x9, #0x8]
    c2c4:      	cmp	x4, x9
    c2c8:      	b.ge	0xc444 <_stogir.vector-lanes.operands+0x1f0>
    c2cc:      	ldr	x9, [x0, #0x78]
    c2d0:      	add	x9, x9, x4, lsl #2
    c2d4:      	ldr	w9, [x9]
    c2d8:      	sxtw	x9, w9
    c2dc:      	cmp	x9, #0x0
    c2e0:      	cset	w9, ge
    c2e4:      	ubfx	x9, x9, #0, #8
    c2e8:      	b	0xc448 <_stogir.vector-lanes.operands+0x1f4>
    c2ec:      	cmp	x4, #0x0
    c2f0:      	b.ge	0xc34c <_stogir.vector-lanes.operands+0xf8>
    c2f4:      	add	x11, x0, #0x28
    c2f8:      	add	x12, x0, #0x50
    c2fc:      	ldr	x11, [x11, #0x8]
    c300:      	ldr	x12, [x12, #0x8]
    c304:      	cmp	x11, x12
    c308:      	b.ne	0xc334 <_stogir.vector-lanes.operands+0xe0>
    c30c:      	cmp	x9, x11
    c310:      	b.gt	0xc60c <_stogir.vector-lanes.operands+0x3b8>
    c314:      	ldr	x9, [x0, #0x50]
    c318:      	add	x9, x9, x10, lsl #2
    c31c:      	ldr	w9, [x9]
    c320:      	sxtw	x9, w9
    c324:      	cmp	x9, #0x0
    c328:      	cset	w9, gt
    c32c:      	ubfx	x9, x9, #0, #8
    c330:      	b	0xc610 <_stogir.vector-lanes.operands+0x3bc>
    c334:      	movz	x9, #0x0, lsl #48
    c338:      	b	0xc350 <_stogir.vector-lanes.operands+0xfc>
    c33c:      	mov	x1, #0x1                ; =1
    c340:      	b	0xc3d8 <_stogir.vector-lanes.operands+0x184>
    c344:      	movz	x9, #0x0, lsl #48
    c348:      	b	0xc350 <_stogir.vector-lanes.operands+0xfc>
    c34c:      	movz	x9, #0x0, lsl #48
    c350:      	cmp	x9, #0x0
    c354:      	b.eq	0xc388 <_stogir.vector-lanes.operands+0x134>
    c358:      	uxtb	w16, w7
    c35c:      	cmp	w16, wzr
    c360:      	b.eq	0xc374 <_stogir.vector-lanes.operands+0x120>
    c364:      	ldr	x7, [x0]
    c368:      	add	x4, x7, x4, lsl #4
    c36c:      	ldr	x4, [x4]
    c370:      	b	0xc380 <_stogir.vector-lanes.operands+0x12c>
    c374:      	ldr	x4, [x0, #0x28]
    c378:      	add	x4, x4, x10, lsl #4
    c37c:      	ldr	x4, [x4]
    c380:      	mov	x7, #0x1                ; =1
    c384:      	b	0xc390 <_stogir.vector-lanes.operands+0x13c>
    c388:      	movz	x7, #0x0, lsl #48
    c38c:      	movz	x4, #0x0, lsl #48
    c390:      	lsr	w7, w7, #0
    c394:      	lsr	x16, x7, #0
    c398:      	cmp	x16, #0x1
    c39c:      	b.eq	0xc3b8 <_stogir.vector-lanes.operands+0x164>
    c3a0:      	b.lo	0xc3a8 <_stogir.vector-lanes.operands+0x154>
    c3a4:      	b	0xc3bc <_stogir.vector-lanes.operands+0x168>
    c3a8:      	cmp	x16, #0x0
    c3ac:      	b.eq	0xc3b4 <_stogir.vector-lanes.operands+0x160>
    c3b0:      	b	0xc3bc <_stogir.vector-lanes.operands+0x168>
    c3b4:      	b	0xc3c0 <_stogir.vector-lanes.operands+0x16c>
    c3b8:      	b	0xc420 <_stogir.vector-lanes.operands+0x1cc>
    c3bc:      	b	0xc908 <_stogir.vector-lanes.operands+0x6b4>
    c3c0:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c3c0:  ARM64_RELOC_PAGE21	l_stogir.484
    c3c4:      	ldr	x16, [x16]
		000000000000c3c4:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    c3c8:      	orr	x19, x16, xzr
    c3cc:      	str	x8, [sp, #0xa0]
    c3d0:      	mov	x1, #0x1                ; =1
    c3d4:      	mov	x0, #0x1b               ; =27
    c3d8:      	ldr	x2, [sp, #0xa0]
    c3dc:      	str	x1, [x2]
    c3e0:      	str	x19, [x2, #0x8]
    c3e4:      	str	x0, [x2, #0x10]
    c3e8:      	ldr	x19, [sp, #0xc0]
    c3ec:      	ldr	x20, [sp, #0xc8]
    c3f0:      	ldr	x21, [sp, #0xd0]
    c3f4:      	ldr	x22, [sp, #0xd8]
    c3f8:      	ldr	x23, [sp, #0xe0]
    c3fc:      	ldr	x24, [sp, #0xe8]
    c400:      	ldr	x25, [sp, #0xf0]
    c404:      	ldr	x26, [sp, #0xf8]
    c408:      	ldr	x27, [sp, #0x100]
    c40c:      	ldr	x28, [sp, #0x108]
    c410:      	ldr	x29, [sp]
    c414:      	ldr	x30, [sp, #0x8]
    c418:      	add	sp, sp, #0x110
    c41c:      	ret
    c420:      	sxtw	x20, w1
    c424:      	sxtw	x1, w2
    c428:      	lsr	w7, w4, #0
    c42c:      	ubfx	x7, x7, #8, #8
    c430:      	orr	x21, x7, xzr
    c434:      	cmp	x20, #0x3d
    c438:      	b.ne	0xc44c <_stogir.vector-lanes.operands+0x1f8>
    c43c:      	mov	x22, x21
    c440:      	b	0xc450 <_stogir.vector-lanes.operands+0x1fc>
    c444:      	movz	x9, #0x0, lsl #48
    c448:      	b	0xc348 <_stogir.vector-lanes.operands+0xf4>
    c44c:      	mov	x22, x1
    c450:      	cmp	x20, #0x3d
    c454:      	b.eq	0xc45c <_stogir.vector-lanes.operands+0x208>
    c458:      	mov	x1, x21
    c45c:      	lsr	w23, w22, #0
    c460:      	sxtw	x24, w23
    c464:      	cmp	x24, #0xf
    c468:      	cset	w25, gt
    c46c:      	cmp	x24, #0x80
    c470:      	cset	w26, lt
    c474:      	and	x7, x24, #0xf
    c478:      	lsr	w7, w7, #0
    c47c:      	sxtw	x7, w7
    c480:      	cmp	x7, #0x1
    c484:      	cset	w27, ge
    c488:      	cmp	x7, #0xd
    c48c:      	cset	w28, le
    c490:      	cmp	x20, #0x3d
    c494:      	b.lt	0xc4e4 <_stogir.vector-lanes.operands+0x290>
    c498:      	cmp	x20, #0x3f
    c49c:      	b.gt	0xc4e4 <_stogir.vector-lanes.operands+0x290>
    c4a0:      	uxtb	w16, w25
    c4a4:      	cmp	w16, wzr
    c4a8:      	b.eq	0xc4e4 <_stogir.vector-lanes.operands+0x290>
    c4ac:      	uxtb	w16, w26
    c4b0:      	cmp	w16, wzr
    c4b4:      	b.eq	0xc4e4 <_stogir.vector-lanes.operands+0x290>
    c4b8:      	uxtb	w16, w27
    c4bc:      	cmp	w16, wzr
    c4c0:      	b.eq	0xc4e4 <_stogir.vector-lanes.operands+0x290>
    c4c4:      	uxtb	w16, w28
    c4c8:      	cmp	w16, wzr
    c4cc:      	b.eq	0xc4e4 <_stogir.vector-lanes.operands+0x290>
    c4d0:      	sxtw	x7, w3
    c4d4:      	cmp	x7, #0x4
    c4d8:      	b.eq	0xc938 <_stogir.vector-lanes.operands+0x6e4>
    c4dc:      	cmp	x7, #0x8
    c4e0:      	b.eq	0xc938 <_stogir.vector-lanes.operands+0x6e4>
    c4e4:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c4e4:  ARM64_RELOC_PAGE21	l_stogir.485
    c4e8:      	ldr	x16, [x16]
		000000000000c4e8:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    c4ec:      	orr	x19, x16, xzr
    c4f0:      	mov	x4, #0x36               ; =54
    c4f4:      	sxtw	x7, w5
    c4f8:      	sxtw	x9, w6
    c4fc:      	cmp	x9, #0x0
    c500:      	cset	w9, eq
    c504:      	cmp	x20, #0x3f
    c508:      	b.ne	0xc970 <_stogir.vector-lanes.operands+0x71c>
    c50c:      	lsr	w1, w1, #0
    c510:      	lsr	w3, w3, #0
    c514:      	mov	w0, w23
    c518:      	mov	w2, w3
    c51c:      	mov	x20, x8
    c520:      	mov	x21, x4
    c524:      	mov	x23, x7
    c528:      	mov	w24, w9
    c52c:      	bl	0xc52c <_stogir.vector-lanes.operands+0x2d8>
		000000000000c52c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    c530:      	cmp	x0, #0x0
    c534:      	b.eq	0xc724 <_stogir.vector-lanes.operands+0x4d0>
    c538:      	movz	x0, #0x0, lsl #48
    c53c:      	b	0xc728 <_stogir.vector-lanes.operands+0x4d4>
    c540:      	cmp	x20, #0x3d
    c544:      	b.ne	0xc97c <_stogir.vector-lanes.operands+0x728>
    c548:      	lsr	w2, w2, #0
    c54c:      	lsr	w3, w3, #0
    c550:      	str	x0, [sp, #0x80]
    c554:      	mov	w0, w23
    c558:      	str	w3, [sp, #0x98]
    c55c:      	str	w6, [sp, #0xb0]
    c560:      	str	x1, [sp, #0xa0]
    c564:      	mov	w1, w2
    c568:      	mov	w2, w3
    c56c:      	str	x4, [sp, #0xa8]
    c570:      	str	w8, [sp, #0xb8]
    c574:      	str	w23, [sp, #0x88]
    c578:      	mov	x23, x7
    c57c:      	str	x22, [sp, #0x90]
    c580:      	mov	w22, w5
    c584:      	bl	0xc584 <_stogir.vector-lanes.operands+0x330>
		000000000000c584:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    c588:      	cmp	x0, #0x0
    c58c:      	b.ne	0xc5a4 <_stogir.vector-lanes.operands+0x350>
    c590:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c590:  ARM64_RELOC_PAGE21	l_stogir.486
    c594:      	ldr	x16, [x16]
		000000000000c594:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    c598:      	orr	x19, x16, xzr
    c59c:      	mov	x16, #0x26              ; =38
    c5a0:      	str	x16, [sp, #0xa8]
    c5a4:      	cmp	x20, #0x3e
    c5a8:      	b.ne	0xc63c <_stogir.vector-lanes.operands+0x3e8>
    c5ac:      	cmp	x21, x24
    c5b0:      	cset	w0, eq
    c5b4:      	uxtb	w16, w0
    c5b8:      	cmp	w16, wzr
    c5bc:      	cset	x0, eq
    c5c0:      	b	0xc640 <_stogir.vector-lanes.operands+0x3ec>
    c5c4:      	mov	x0, #0x1                ; =1
    c5c8:      	cmp	x0, #0x0
    c5cc:      	b.eq	0xc5e0 <_stogir.vector-lanes.operands+0x38c>
    c5d0:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c5d0:  ARM64_RELOC_PAGE21	l_stogir.487
    c5d4:      	ldr	x16, [x16]
		000000000000c5d4:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    c5d8:      	orr	x19, x16, xzr
    c5dc:      	mov	x21, #0x24              ; =36
    c5e0:      	str	x22, [sp, #0x90]
    c5e4:      	str	x20, [sp, #0xa0]
    c5e8:      	str	x21, [sp, #0xa8]
    c5ec:      	ldr	x0, [sp, #0xa8]
    c5f0:      	cmp	x0, #0x0
    c5f4:      	b.ne	0xc33c <_stogir.vector-lanes.operands+0xe8>
    c5f8:      	ldr	x0, [sp, #0x90]
    c5fc:      	and	x19, x0, #0xffffffff
    c600:      	movz	x1, #0x0, lsl #48
    c604:      	movz	x0, #0x0, lsl #48
    c608:      	b	0xc340 <_stogir.vector-lanes.operands+0xec>
    c60c:      	movz	x9, #0x0, lsl #48
    c610:      	b	0xc338 <_stogir.vector-lanes.operands+0xe4>
    c614:      	ldr	w0, [sp, #0xb8]
    c618:      	uxtb	w16, w0
    c61c:      	cmp	w16, wzr
    c620:      	b.ne	0xc638 <_stogir.vector-lanes.operands+0x3e4>
    c624:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c624:  ARM64_RELOC_PAGE21	l_stogir.488
    c628:      	ldr	x16, [x16]
		000000000000c628:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    c62c:      	orr	x19, x16, xzr
    c630:      	mov	x16, #0x20              ; =32
    c634:      	str	x16, [sp, #0xa8]
    c638:      	b	0xc5ec <_stogir.vector-lanes.operands+0x398>
    c63c:      	movz	x0, #0x0, lsl #48
    c640:      	cmp	x0, #0x0
    c644:      	b.eq	0xc65c <_stogir.vector-lanes.operands+0x408>
    c648:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c648:  ARM64_RELOC_PAGE21	l_stogir.489
    c64c:      	ldr	x16, [x16]
		000000000000c64c:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    c650:      	orr	x19, x16, xzr
    c654:      	mov	x16, #0x27              ; =39
    c658:      	str	x16, [sp, #0xa8]
    c65c:      	lsr	w22, w22, #0
    c660:      	add	x8, sp, #0x10
    c664:      	ldr	x0, [sp, #0x80]
    c668:      	mov	w1, w22
    c66c:      	bl	0xc66c <_stogir.vector-lanes.operands+0x418>
		000000000000c66c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    c670:      	add	x16, sp, #0x10
    c674:      	ldr	w0, [x16]
    c678:      	lsr	x16, x0, #0
    c67c:      	cmp	x16, #0x1
    c680:      	b.eq	0xc69c <_stogir.vector-lanes.operands+0x448>
    c684:      	b.lo	0xc68c <_stogir.vector-lanes.operands+0x438>
    c688:      	b	0xc6a0 <_stogir.vector-lanes.operands+0x44c>
    c68c:      	cmp	x16, #0x0
    c690:      	b.eq	0xc698 <_stogir.vector-lanes.operands+0x444>
    c694:      	b	0xc6a0 <_stogir.vector-lanes.operands+0x44c>
    c698:      	b	0xc6a4 <_stogir.vector-lanes.operands+0x450>
    c69c:      	b	0xc750 <_stogir.vector-lanes.operands+0x4fc>
    c6a0:      	b	0xc960 <_stogir.vector-lanes.operands+0x70c>
    c6a4:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c6a4:  ARM64_RELOC_PAGE21	l_stogir.490
    c6a8:      	ldr	x16, [x16]
		000000000000c6a8:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    c6ac:      	orr	x19, x16, xzr
    c6b0:      	mov	x16, #0x19              ; =25
    c6b4:      	str	x16, [sp, #0xa8]
    c6b8:      	cmp	x20, #0x3e
    c6bc:      	b.ne	0xc614 <_stogir.vector-lanes.operands+0x3c0>
    c6c0:      	ldr	w0, [sp, #0xb0]
    c6c4:      	lsr	w0, w0, #0
    c6c8:      	add	x8, sp, #0x50
    c6cc:      	mov	w1, w0
    c6d0:      	ldr	x0, [sp, #0x80]
    c6d4:      	bl	0xc6d4 <_stogir.vector-lanes.operands+0x480>
		000000000000c6d4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    c6d8:      	add	x16, sp, #0x50
    c6dc:      	ldr	w0, [x16]
    c6e0:      	lsr	x16, x0, #0
    c6e4:      	cmp	x16, #0x1
    c6e8:      	b.eq	0xc704 <_stogir.vector-lanes.operands+0x4b0>
    c6ec:      	b.lo	0xc6f4 <_stogir.vector-lanes.operands+0x4a0>
    c6f0:      	b	0xc708 <_stogir.vector-lanes.operands+0x4b4>
    c6f4:      	cmp	x16, #0x0
    c6f8:      	b.eq	0xc700 <_stogir.vector-lanes.operands+0x4ac>
    c6fc:      	b	0xc708 <_stogir.vector-lanes.operands+0x4b4>
    c700:      	b	0xc70c <_stogir.vector-lanes.operands+0x4b8>
    c704:      	b	0xc840 <_stogir.vector-lanes.operands+0x5ec>
    c708:      	b	0xc968 <_stogir.vector-lanes.operands+0x714>
    c70c:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c70c:  ARM64_RELOC_PAGE21	l_stogir.491
    c710:      	ldr	x16, [x16]
		000000000000c710:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    c714:      	orr	x19, x16, xzr
    c718:      	mov	x16, #0x20              ; =32
    c71c:      	str	x16, [sp, #0xa8]
    c720:      	b	0xc638 <_stogir.vector-lanes.operands+0x3e4>
    c724:      	mov	x0, #0x1                ; =1
    c728:      	cmp	x0, #0x0
    c72c:      	b.eq	0xc738 <_stogir.vector-lanes.operands+0x4e4>
    c730:      	mov	x0, #0x1                ; =1
    c734:      	b	0xc5c8 <_stogir.vector-lanes.operands+0x374>
    c738:      	cmp	x23, #0x0
    c73c:      	b.ne	0xc5c4 <_stogir.vector-lanes.operands+0x370>
    c740:      	uxtb	w16, w24
    c744:      	cmp	w16, wzr
    c748:      	cset	x0, eq
    c74c:      	b	0xc5c8 <_stogir.vector-lanes.operands+0x374>
    c750:      	add	x16, sp, #0x10
    c754:      	orr	x0, x16, xzr
    c758:      	add	x0, x0, #0x8
    c75c:      	add	x16, sp, #0x10
    c760:      	ldr	x1, [x16, #0x8]
    c764:      	add	x16, sp, #0x40
    c768:      	str	x1, [x16]
    c76c:      	lsr	w1, w1, #0
    c770:      	ldr	x0, [x0, #0x8]
    c774:      	add	x16, sp, #0x40
    c778:      	str	x0, [x16, #0x8]
    c77c:      	ubfx	x0, x1, #8, #8
    c780:      	cmp	x0, #0x1
    c784:      	b.lt	0xc7ac <_stogir.vector-lanes.operands+0x558>
    c788:      	cmp	x0, #0xb
    c78c:      	b.gt	0xc7ac <_stogir.vector-lanes.operands+0x558>
    c790:      	add	x16, sp, #0x40
    c794:      	ldr	w0, [x16]
    c798:      	uxtb	w0, w0
    c79c:      	cmp	x0, #0x48
    c7a0:      	b.eq	0xc7ac <_stogir.vector-lanes.operands+0x558>
    c7a4:      	cmp	x0, #0x46
    c7a8:      	b.ne	0xc7c0 <_stogir.vector-lanes.operands+0x56c>
    c7ac:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c7ac:  ARM64_RELOC_PAGE21	l_stogir.492
    c7b0:      	ldr	x16, [x16]
		000000000000c7b0:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    c7b4:      	orr	x19, x16, xzr
    c7b8:      	mov	x16, #0x2b              ; =43
    c7bc:      	str	x16, [sp, #0xa8]
    c7c0:      	cmp	x23, #0x0
    c7c4:      	b.ge	0xc7f0 <_stogir.vector-lanes.operands+0x59c>
    c7c8:      	add	x16, sp, #0x40
    c7cc:      	ldr	w0, [x16]
    c7d0:      	uxtb	w1, w0
    c7d4:      	ubfx	x0, x0, #8, #8
    c7d8:      	cmp	x1, x0
    c7dc:      	b.eq	0xc8a0 <_stogir.vector-lanes.operands+0x64c>
    c7e0:      	cmp	x1, #0x49
    c7e4:      	b.eq	0xc8a0 <_stogir.vector-lanes.operands+0x64c>
    c7e8:      	movz	x0, #0x0, lsl #48
    c7ec:      	b	0xc83c <_stogir.vector-lanes.operands+0x5e8>
    c7f0:      	movz	x0, #0x0, lsl #48
    c7f4:      	cmp	x0, #0x0
    c7f8:      	b.eq	0xc810 <_stogir.vector-lanes.operands+0x5bc>
    c7fc:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c7fc:  ARM64_RELOC_PAGE21	l_stogir.493
    c800:      	ldr	x16, [x16]
		000000000000c800:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    c804:      	orr	x19, x16, xzr
    c808:      	mov	x16, #0x28              ; =40
    c80c:      	str	x16, [sp, #0xa8]
    c810:      	b	0xc6b8 <_stogir.vector-lanes.operands+0x464>
    c814:      	movn	x2, #0x0, lsl #48
    c818:      	ubfx	x0, x0, #0, #32
    c81c:      	ubfx	x1, x1, #0, #32
    c820:      	lsl	x1, x1, #32
    c824:      	orr	x0, x1, x0
    c828:      	lsr	w2, w2, #0
    c82c:      	sxtw	x2, w2
    c830:      	cmp	x0, x2
    c834:      	cset	w0, hs
    c838:      	ubfx	x0, x0, #0, #8
    c83c:      	b	0xc7f4 <_stogir.vector-lanes.operands+0x5a0>
    c840:      	add	x16, sp, #0x50
    c844:      	ldr	x0, [x16, #0x8]
    c848:      	uxtb	w1, w0
    c84c:      	cmp	x1, #0x48
    c850:      	b.eq	0xc888 <_stogir.vector-lanes.operands+0x634>
    c854:      	cmp	x1, #0x46
    c858:      	b.eq	0xc888 <_stogir.vector-lanes.operands+0x634>
    c85c:      	ldr	w1, [sp, #0x98]
    c860:      	lsr	w1, w1, #0
    c864:      	lsr	w0, w0, #0
    c868:      	ubfx	x0, x0, #8, #8
    c86c:      	lsr	w0, w0, #0
    c870:      	mov	w2, w1
    c874:      	mov	w1, w0
    c878:      	ldr	w0, [sp, #0x88]
    c87c:      	bl	0xc87c <_stogir.vector-lanes.operands+0x628>
		000000000000c87c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    c880:      	cmp	x0, #0x0
    c884:      	b.ne	0xc89c <_stogir.vector-lanes.operands+0x648>
    c888:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c888:  ARM64_RELOC_PAGE21	l_stogir.494
    c88c:      	ldr	x16, [x16]
		000000000000c88c:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    c890:      	orr	x19, x16, xzr
    c894:      	mov	x16, #0x27              ; =39
    c898:      	str	x16, [sp, #0xa8]
    c89c:      	b	0xc720 <_stogir.vector-lanes.operands+0x4cc>
    c8a0:      	add	x16, sp, #0x40
    c8a4:      	ldr	w0, [x16, #0x8]
    c8a8:      	add	x16, sp, #0x40
    c8ac:      	ldr	w1, [x16, #0xc]
    c8b0:      	uxtb	w16, w25
    c8b4:      	cmp	w16, wzr
    c8b8:      	b.eq	0xc910 <_stogir.vector-lanes.operands+0x6bc>
    c8bc:      	uxtb	w16, w26
    c8c0:      	cmp	w16, wzr
    c8c4:      	b.eq	0xc910 <_stogir.vector-lanes.operands+0x6bc>
    c8c8:      	uxtb	w16, w27
    c8cc:      	cmp	w16, wzr
    c8d0:      	b.eq	0xc910 <_stogir.vector-lanes.operands+0x6bc>
    c8d4:      	uxtb	w16, w28
    c8d8:      	cmp	w16, wzr
    c8dc:      	b.eq	0xc910 <_stogir.vector-lanes.operands+0x6bc>
    c8e0:      	ubfx	x2, x24, #4, #32
    c8e4:      	sxtw	x2, w2
    c8e8:      	sub	x2, x2, #0x1
    c8ec:      	lsr	w2, w2, #0
    c8f0:      	sxtw	x2, w2
    c8f4:      	mov	x16, #0x1               ; =1
    c8f8:      	lsl	x2, x16, x2
    c8fc:      	lsr	w2, w2, #0
    c900:      	sxtw	x2, w2
    c904:      	b	0xc818 <_stogir.vector-lanes.operands+0x5c4>
    c908:      	brk	#0
    c90c:      	b	0xc908 <_stogir.vector-lanes.operands+0x6b4>
    c910:      	cmp	x24, #0x0
    c914:      	b.lt	0xc814 <_stogir.vector-lanes.operands+0x5c0>
    c918:      	cmp	x24, #0xd
    c91c:      	b.gt	0xc814 <_stogir.vector-lanes.operands+0x5c0>
    c920:      	cmp	x24, #0x0
    c924:      	cset	w2, eq
    c928:      	uxtb	w16, w2
    c92c:      	cmp	w16, wzr
    c930:      	cset	x2, eq
    c934:      	b	0xc818 <_stogir.vector-lanes.operands+0x5c4>
    c938:      	uxtb	w4, w4
    c93c:      	cmp	x4, #0x48
    c940:      	b.eq	0xc4e4 <_stogir.vector-lanes.operands+0x290>
    c944:      	cmp	x4, #0x46
    c948:      	b.eq	0xc4e4 <_stogir.vector-lanes.operands+0x290>
    c94c:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000c94c:  ARM64_RELOC_PAGE21	l_stogir.495
    c950:      	ldr	x16, [x16]
		000000000000c950:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    c954:      	orr	x19, x16, xzr
    c958:      	movz	x4, #0x0, lsl #48
    c95c:      	b	0xc4f4 <_stogir.vector-lanes.operands+0x2a0>
    c960:      	brk	#0
    c964:      	b	0xc960 <_stogir.vector-lanes.operands+0x70c>
    c968:      	brk	#0
    c96c:      	b	0xc968 <_stogir.vector-lanes.operands+0x714>
    c970:      	mov	x1, x8
    c974:      	mov	w8, w9
    c978:      	b	0xc540 <_stogir.vector-lanes.operands+0x2ec>
    c97c:      	str	x22, [sp, #0x90]
    c980:      	str	x1, [sp, #0xa0]
    c984:      	str	x0, [sp, #0x80]
    c988:      	str	w3, [sp, #0x98]
    c98c:      	mov	w22, w5
    c990:      	str	w6, [sp, #0xb0]
    c994:      	str	w23, [sp, #0x88]
    c998:      	mov	x23, x7
    c99c:      	str	w8, [sp, #0xb8]
    c9a0:      	str	x4, [sp, #0xa8]
    c9a4:      	b	0xc5a4 <_stogir.vector-lanes.operands+0x350>

000000000000c9a8 <_stogir.vector-comparison.operation?>:
    c9a8:      	sxtw	x0, w0
    c9ac:      	cmp	x0, #0xe
    c9b0:      	b.lt	0xc9c4 <_stogir.vector-comparison.operation?+0x1c>
    c9b4:      	cmp	x0, #0x19
    c9b8:      	cset	w0, le
    c9bc:      	ubfx	x0, x0, #0, #8
    c9c0:      	b	0xc9c8 <_stogir.vector-comparison.operation?+0x20>
    c9c4:      	movz	x0, #0x0, lsl #48
    c9c8:      	ret

000000000000c9cc <_stogir.vector-comparison.operands>:
    c9cc:      	sub	sp, sp, #0xc0
    c9d0:      	str	x29, [sp]
    c9d4:      	str	x30, [sp, #0x8]
    c9d8:      	mov	x29, sp
    c9dc:      	str	x19, [sp, #0x70]
    c9e0:      	str	x20, [sp, #0x78]
    c9e4:      	str	x21, [sp, #0x80]
    c9e8:      	str	x22, [sp, #0x88]
    c9ec:      	str	x23, [sp, #0x90]
    c9f0:      	str	x24, [sp, #0x98]
    c9f4:      	str	x25, [sp, #0xa0]
    c9f8:      	str	x26, [sp, #0xa8]
    c9fc:      	str	x27, [sp, #0xb0]
    ca00:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000ca00:  ARM64_RELOC_PAGE21	l_stogir.496
    ca04:      	ldr	x16, [x16]
		000000000000ca04:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    ca08:      	orr	x19, x16, xzr
    ca0c:      	lsr	w4, w4, #0
    ca10:      	mov	x20, x8
    ca14:      	add	x8, sp, #0x10
    ca18:      	mov	x21, x0
    ca1c:      	mov	w22, w1
    ca20:      	mov	w1, w4
    ca24:      	mov	w23, w2
    ca28:      	mov	w24, w3
    ca2c:      	mov	w25, w5
    ca30:      	bl	0xca30 <_stogir.vector-comparison.operands+0x64>
		000000000000ca30:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    ca34:      	add	x16, sp, #0x10
    ca38:      	ldr	w0, [x16]
    ca3c:      	lsr	x16, x0, #0
    ca40:      	cmp	x16, #0x1
    ca44:      	b.eq	0xca60 <_stogir.vector-comparison.operands+0x94>
    ca48:      	b.lo	0xca50 <_stogir.vector-comparison.operands+0x84>
    ca4c:      	b	0xca64 <_stogir.vector-comparison.operands+0x98>
    ca50:      	cmp	x16, #0x0
    ca54:      	b.eq	0xca5c <_stogir.vector-comparison.operands+0x90>
    ca58:      	b	0xca64 <_stogir.vector-comparison.operands+0x98>
    ca5c:      	b	0xca68 <_stogir.vector-comparison.operands+0x9c>
    ca60:      	b	0xcab0 <_stogir.vector-comparison.operands+0xe4>
    ca64:      	b	0xcc30 <_stogir.vector-comparison.operands+0x264>
    ca68:      	mov	x0, #0x1                ; =1
    ca6c:      	mov	x1, #0x21               ; =33
    ca70:      	str	x0, [x20]
    ca74:      	str	x19, [x20, #0x8]
    ca78:      	str	x1, [x20, #0x10]
    ca7c:      	ldr	x19, [sp, #0x70]
    ca80:      	ldr	x20, [sp, #0x78]
    ca84:      	ldr	x21, [sp, #0x80]
    ca88:      	ldr	x22, [sp, #0x88]
    ca8c:      	ldr	x23, [sp, #0x90]
    ca90:      	ldr	x24, [sp, #0x98]
    ca94:      	ldr	x25, [sp, #0xa0]
    ca98:      	ldr	x26, [sp, #0xa8]
    ca9c:      	ldr	x27, [sp, #0xb0]
    caa0:      	ldr	x29, [sp]
    caa4:      	ldr	x30, [sp, #0x8]
    caa8:      	add	sp, sp, #0xc0
    caac:      	ret
    cab0:      	lsr	w25, w25, #0
    cab4:      	add	x16, sp, #0x10
    cab8:      	ldr	x26, [x16, #0x8]
    cabc:      	add	x8, sp, #0x40
    cac0:      	mov	x0, x21
    cac4:      	mov	w1, w25
    cac8:      	bl	0xcac8 <_stogir.vector-comparison.operands+0xfc>
		000000000000cac8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    cacc:      	add	x16, sp, #0x40
    cad0:      	ldr	w0, [x16]
    cad4:      	lsr	x16, x0, #0
    cad8:      	cmp	x16, #0x1
    cadc:      	b.eq	0xcaf8 <_stogir.vector-comparison.operands+0x12c>
    cae0:      	b.lo	0xcae8 <_stogir.vector-comparison.operands+0x11c>
    cae4:      	b	0xcafc <_stogir.vector-comparison.operands+0x130>
    cae8:      	cmp	x16, #0x0
    caec:      	b.eq	0xcaf4 <_stogir.vector-comparison.operands+0x128>
    caf0:      	b	0xcafc <_stogir.vector-comparison.operands+0x130>
    caf4:      	b	0xcb00 <_stogir.vector-comparison.operands+0x134>
    caf8:      	b	0xcb0c <_stogir.vector-comparison.operands+0x140>
    cafc:      	b	0xcc38 <_stogir.vector-comparison.operands+0x26c>
    cb00:      	mov	x0, #0x1                ; =1
    cb04:      	mov	x1, #0x21               ; =33
    cb08:      	b	0xca70 <_stogir.vector-comparison.operands+0xa4>
    cb0c:      	sxtw	x0, w24
    cb10:      	add	x16, sp, #0x40
    cb14:      	ldr	x19, [x16, #0x8]
    cb18:      	cmp	x0, #0x4
    cb1c:      	b.eq	0xcb40 <_stogir.vector-comparison.operands+0x174>
    cb20:      	cmp	x0, #0x8
    cb24:      	b.eq	0xcb40 <_stogir.vector-comparison.operands+0x174>
    cb28:      	adrp	x16, 0xc000 <_stogir.floating.operands+0x2c8>
		000000000000cb28:  ARM64_RELOC_PAGE21	l_stogir.497
    cb2c:      	ldr	x16, [x16]
		000000000000cb2c:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    cb30:      	orr	x19, x16, xzr
    cb34:      	mov	x0, #0x1                ; =1
    cb38:      	mov	x1, #0x33               ; =51
    cb3c:      	b	0xcb08 <_stogir.vector-comparison.operands+0x13c>
    cb40:      	lsr	w22, w22, #0
    cb44:      	lsr	w0, w26, #0
    cb48:      	ubfx	x21, x0, #8, #8
    cb4c:      	orr	x0, x21, xzr
    cb50:      	lsr	w0, w0, #0
    cb54:      	mov	w1, w0
    cb58:      	mov	w0, w22
    cb5c:      	bl	0xcb5c <_stogir.vector-comparison.operands+0x190>
		000000000000cb5c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    cb60:      	cmp	x0, #0x0
    cb64:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cb68:      	lsr	w0, w19, #0
    cb6c:      	ubfx	x0, x0, #8, #8
    cb70:      	cmp	x21, x0
    cb74:      	b.ne	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cb78:      	uxtb	w26, w26
    cb7c:      	cmp	x26, #0x48
    cb80:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cb84:      	cmp	x26, #0x46
    cb88:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cb8c:      	uxtb	w19, w19
    cb90:      	cmp	x19, #0x48
    cb94:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cb98:      	cmp	x19, #0x46
    cb9c:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cba0:      	sxtw	x23, w23
    cba4:      	cmp	x23, #0xf
    cba8:      	cset	w0, gt
    cbac:      	uxtb	w16, w0
    cbb0:      	cmp	w16, wzr
    cbb4:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cbb8:      	cmp	x23, #0x80
    cbbc:      	cset	w1, lt
    cbc0:      	uxtb	w16, w1
    cbc4:      	cmp	w16, wzr
    cbc8:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cbcc:      	and	x2, x23, #0xf
    cbd0:      	lsr	w2, w2, #0
    cbd4:      	sxtw	x2, w2
    cbd8:      	cmp	x2, #0x1
    cbdc:      	cset	w3, ge
    cbe0:      	uxtb	w16, w3
    cbe4:      	cmp	w16, wzr
    cbe8:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cbec:      	cmp	x2, #0xd
    cbf0:      	cset	w4, le
    cbf4:      	uxtb	w16, w4
    cbf8:      	cmp	w16, wzr
    cbfc:      	b.eq	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cc00:      	cmp	x23, #0x0
    cc04:      	cset	w5, ge
    cc08:      	cmp	x23, #0xd
    cc0c:      	cset	w6, le
    cc10:      	uxtb	w16, w5
    cc14:      	cmp	w16, wzr
    cc18:      	b.eq	0xcc40 <_stogir.vector-comparison.operands+0x274>
    cc1c:      	uxtb	w16, w6
    cc20:      	cmp	w16, wzr
    cc24:      	b.eq	0xcc40 <_stogir.vector-comparison.operands+0x274>
    cc28:      	mov	x7, x2
    cc2c:      	b	0xcc74 <_stogir.vector-comparison.operands+0x2a8>
    cc30:      	brk	#0
    cc34:      	b	0xcc30 <_stogir.vector-comparison.operands+0x264>
    cc38:      	brk	#0
    cc3c:      	b	0xcc38 <_stogir.vector-comparison.operands+0x26c>
    cc40:      	uxtb	w16, w0
    cc44:      	cmp	w16, wzr
    cc48:      	b.eq	0xcc70 <_stogir.vector-comparison.operands+0x2a4>
    cc4c:      	uxtb	w16, w1
    cc50:      	cmp	w16, wzr
    cc54:      	b.eq	0xcc70 <_stogir.vector-comparison.operands+0x2a4>
    cc58:      	uxtb	w16, w3
    cc5c:      	cmp	w16, wzr
    cc60:      	b.eq	0xcc70 <_stogir.vector-comparison.operands+0x2a4>
    cc64:      	uxtb	w16, w4
    cc68:      	cmp	w16, wzr
    cc6c:      	b.ne	0xcc28 <_stogir.vector-comparison.operands+0x25c>
    cc70:      	movn	x7, #0x0, lsl #48
    cc74:      	lsr	w7, w7, #0
    cc78:      	sxtw	x7, w7
    cc7c:      	cmp	x7, #0x1
    cc80:      	b.lt	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cc84:      	cmp	x7, #0xb
    cc88:      	b.gt	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cc8c:      	uxtb	w16, w0
    cc90:      	cmp	w16, wzr
    cc94:      	b.eq	0xcce4 <_stogir.vector-comparison.operands+0x318>
    cc98:      	uxtb	w16, w1
    cc9c:      	cmp	w16, wzr
    cca0:      	b.eq	0xcce4 <_stogir.vector-comparison.operands+0x318>
    cca4:      	uxtb	w16, w3
    cca8:      	cmp	w16, wzr
    ccac:      	b.eq	0xcce4 <_stogir.vector-comparison.operands+0x318>
    ccb0:      	uxtb	w16, w4
    ccb4:      	cmp	w16, wzr
    ccb8:      	b.eq	0xcce4 <_stogir.vector-comparison.operands+0x318>
    ccbc:      	ubfx	x7, x23, #4, #32
    ccc0:      	sxtw	x7, w7
    ccc4:      	sub	x7, x7, #0x1
    ccc8:      	lsr	w7, w7, #0
    cccc:      	sxtw	x7, w7
    ccd0:      	mov	x16, #0x1               ; =1
    ccd4:      	lsl	x7, x16, x7
    ccd8:      	lsr	w7, w7, #0
    ccdc:      	sxtw	x7, w7
    cce0:      	b	0xce14 <_stogir.vector-comparison.operands+0x448>
    cce4:      	uxtb	w16, w5
    cce8:      	cmp	w16, wzr
    ccec:      	b.eq	0xce10 <_stogir.vector-comparison.operands+0x444>
    ccf0:      	uxtb	w16, w6
    ccf4:      	cmp	w16, wzr
    ccf8:      	b.eq	0xce10 <_stogir.vector-comparison.operands+0x444>
    ccfc:      	cmp	x23, #0x0
    cd00:      	cset	w7, eq
    cd04:      	uxtb	w16, w7
    cd08:      	cmp	w16, wzr
    cd0c:      	cset	x7, eq
    cd10:      	b	0xce14 <_stogir.vector-comparison.operands+0x448>
    cd14:      	movn	x8, #0x0, lsl #48
    cd18:      	lsr	w7, w7, #0
    cd1c:      	sxtw	x7, w7
    cd20:      	lsr	w8, w8, #0
    cd24:      	sxtw	x8, w8
    cd28:      	cmp	x7, x8
    cd2c:      	b.ne	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    cd30:      	uxtb	w16, w5
    cd34:      	cmp	w16, wzr
    cd38:      	b.eq	0xcd48 <_stogir.vector-comparison.operands+0x37c>
    cd3c:      	uxtb	w16, w6
    cd40:      	cmp	w16, wzr
    cd44:      	b.ne	0xcd7c <_stogir.vector-comparison.operands+0x3b0>
    cd48:      	uxtb	w16, w0
    cd4c:      	cmp	w16, wzr
    cd50:      	b.eq	0xcd78 <_stogir.vector-comparison.operands+0x3ac>
    cd54:      	uxtb	w16, w1
    cd58:      	cmp	w16, wzr
    cd5c:      	b.eq	0xcd78 <_stogir.vector-comparison.operands+0x3ac>
    cd60:      	uxtb	w16, w3
    cd64:      	cmp	w16, wzr
    cd68:      	b.eq	0xcd78 <_stogir.vector-comparison.operands+0x3ac>
    cd6c:      	uxtb	w16, w4
    cd70:      	cmp	w16, wzr
    cd74:      	b.ne	0xcd7c <_stogir.vector-comparison.operands+0x3b0>
    cd78:      	movn	x2, #0x0, lsl #48
    cd7c:      	lsr	w24, w24, #0
    cd80:      	lsr	w2, w2, #0
    cd84:      	lsr	w2, w2, #0
    cd88:      	mov	w0, w2
    cd8c:      	mov	w1, w24
    cd90:      	bl	0xcd90 <_stogir.vector-comparison.operands+0x3c4>
		000000000000cd90:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    cd94:      	uxtb	w16, w19
    cd98:      	cmp	w16, wzr
    cd9c:      	b.ne	0xcdd4 <_stogir.vector-comparison.operands+0x408>
    cda0:      	uxtb	w16, w22
    cda4:      	cmp	w16, wzr
    cda8:      	b.eq	0xcdd0 <_stogir.vector-comparison.operands+0x404>
    cdac:      	uxtb	w16, w23
    cdb0:      	cmp	w16, wzr
    cdb4:      	b.eq	0xcdd0 <_stogir.vector-comparison.operands+0x404>
    cdb8:      	uxtb	w16, w26
    cdbc:      	cmp	w16, wzr
    cdc0:      	b.eq	0xcdd0 <_stogir.vector-comparison.operands+0x404>
    cdc4:      	uxtb	w16, w27
    cdc8:      	cmp	w16, wzr
    cdcc:      	b.ne	0xcdd4 <_stogir.vector-comparison.operands+0x408>
    cdd0:      	movn	x25, #0x0, lsl #48
    cdd4:      	lsr	w0, w0, #0
    cdd8:      	sxtw	x19, w0
    cddc:      	lsr	w25, w25, #0
    cde0:      	lsr	w25, w25, #0
    cde4:      	mov	w0, w25
    cde8:      	mov	w1, w24
    cdec:      	bl	0xcdec <_stogir.vector-comparison.operands+0x420>
		000000000000cdec:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    cdf0:      	lsr	w0, w0, #0
    cdf4:      	sxtw	x0, w0
    cdf8:      	cmp	x19, x0
    cdfc:      	b.ne	0xcb28 <_stogir.vector-comparison.operands+0x15c>
    ce00:      	and	x19, x21, #0xffffffff
    ce04:      	movz	x0, #0x0, lsl #48
    ce08:      	movz	x1, #0x0, lsl #48
    ce0c:      	b	0xcb3c <_stogir.vector-comparison.operands+0x170>
    ce10:      	movn	x7, #0x0, lsl #48
    ce14:      	and	x8, x21, #0xf
    ce18:      	cmp	x21, #0xd
    ce1c:      	cset	w19, le
    ce20:      	cmp	x21, #0xf
    ce24:      	cset	w22, gt
    ce28:      	cmp	x21, #0x80
    ce2c:      	cset	w23, lt
    ce30:      	lsr	w8, w8, #0
    ce34:      	sxtw	x25, w8
    ce38:      	cmp	x25, #0x1
    ce3c:      	cset	w26, ge
    ce40:      	cmp	x25, #0xd
    ce44:      	cset	w27, le
    ce48:      	uxtb	w16, w22
    ce4c:      	cmp	w16, wzr
    ce50:      	b.eq	0xcea0 <_stogir.vector-comparison.operands+0x4d4>
    ce54:      	uxtb	w16, w23
    ce58:      	cmp	w16, wzr
    ce5c:      	b.eq	0xcea0 <_stogir.vector-comparison.operands+0x4d4>
    ce60:      	uxtb	w16, w26
    ce64:      	cmp	w16, wzr
    ce68:      	b.eq	0xcea0 <_stogir.vector-comparison.operands+0x4d4>
    ce6c:      	uxtb	w16, w27
    ce70:      	cmp	w16, wzr
    ce74:      	b.eq	0xcea0 <_stogir.vector-comparison.operands+0x4d4>
    ce78:      	ubfx	x8, x21, #4, #32
    ce7c:      	sxtw	x8, w8
    ce80:      	sub	x8, x8, #0x1
    ce84:      	lsr	w8, w8, #0
    ce88:      	sxtw	x8, w8
    ce8c:      	mov	x16, #0x1               ; =1
    ce90:      	lsl	x8, x16, x8
    ce94:      	lsr	w8, w8, #0
    ce98:      	sxtw	x8, w8
    ce9c:      	b	0xcd18 <_stogir.vector-comparison.operands+0x34c>
    cea0:      	uxtb	w16, w19
    cea4:      	cmp	w16, wzr
    cea8:      	b.eq	0xcd14 <_stogir.vector-comparison.operands+0x348>
    ceac:      	cmp	x21, #0x0
    ceb0:      	cset	w8, eq
    ceb4:      	uxtb	w16, w8
    ceb8:      	cmp	w16, wzr
    cebc:      	cset	x8, eq
    cec0:      	b	0xcd18 <_stogir.vector-comparison.operands+0x34c>

000000000000cec4 <_stogir.vector-arithmetic.operation?>:
    cec4:      	sxtw	x0, w0
    cec8:      	cmp	x0, #0x1f
    cecc:      	b.eq	0xcf28 <_stogir.vector-arithmetic.operation?+0x64>
    ced0:      	cmp	x0, #0x20
    ced4:      	b.eq	0xcf28 <_stogir.vector-arithmetic.operation?+0x64>
    ced8:      	cmp	x0, #0x2d
    cedc:      	b.eq	0xcf28 <_stogir.vector-arithmetic.operation?+0x64>
    cee0:      	cmp	x0, #0x36
    cee4:      	b.eq	0xcf28 <_stogir.vector-arithmetic.operation?+0x64>
    cee8:      	cmp	x0, #0x37
    ceec:      	b.eq	0xcf28 <_stogir.vector-arithmetic.operation?+0x64>
    cef0:      	cmp	x0, #0x38
    cef4:      	b.eq	0xcf28 <_stogir.vector-arithmetic.operation?+0x64>
    cef8:      	cmp	x0, #0x39
    cefc:      	b.eq	0xcf28 <_stogir.vector-arithmetic.operation?+0x64>
    cf00:      	cmp	x0, #0x3a
    cf04:      	b.eq	0xcf30 <_stogir.vector-arithmetic.operation?+0x6c>
    cf08:      	cmp	x0, #0x3b
    cf0c:      	b.eq	0xcf30 <_stogir.vector-arithmetic.operation?+0x6c>
    cf10:      	cmp	x0, #0x31
    cf14:      	b.lt	0xcf48 <_stogir.vector-arithmetic.operation?+0x84>
    cf18:      	cmp	x0, #0x35
    cf1c:      	b.gt	0xcf48 <_stogir.vector-arithmetic.operation?+0x84>
    cf20:      	mov	x0, #0x1                ; =1
    cf24:      	b	0xcf44 <_stogir.vector-arithmetic.operation?+0x80>
    cf28:      	mov	x0, #0x1                ; =1
    cf2c:      	ret
    cf30:      	mov	x0, #0x1                ; =1
    cf34:      	b	0xcf2c <_stogir.vector-arithmetic.operation?+0x68>
    cf38:      	cmp	x0, #0x30
    cf3c:      	cset	w0, eq
    cf40:      	ubfx	x0, x0, #0, #8
    cf44:      	b	0xcf34 <_stogir.vector-arithmetic.operation?+0x70>
    cf48:      	cmp	x0, #0x1a
    cf4c:      	b.ne	0xcf58 <_stogir.vector-arithmetic.operation?+0x94>
    cf50:      	mov	x0, #0x1                ; =1
    cf54:      	b	0xcf44 <_stogir.vector-arithmetic.operation?+0x80>
    cf58:      	cmp	x0, #0x1b
    cf5c:      	b.ne	0xcf68 <_stogir.vector-arithmetic.operation?+0xa4>
    cf60:      	mov	x0, #0x1                ; =1
    cf64:      	b	0xcf44 <_stogir.vector-arithmetic.operation?+0x80>
    cf68:      	cmp	x0, #0x1c
    cf6c:      	b.ne	0xcf78 <_stogir.vector-arithmetic.operation?+0xb4>
    cf70:      	mov	x0, #0x1                ; =1
    cf74:      	b	0xcf44 <_stogir.vector-arithmetic.operation?+0x80>
    cf78:      	cmp	x0, #0x1d
    cf7c:      	b.ne	0xcf88 <_stogir.vector-arithmetic.operation?+0xc4>
    cf80:      	mov	x0, #0x1                ; =1
    cf84:      	b	0xcf44 <_stogir.vector-arithmetic.operation?+0x80>
    cf88:      	cmp	x0, #0x1e
    cf8c:      	b.ne	0xcf98 <_stogir.vector-arithmetic.operation?+0xd4>
    cf90:      	mov	x0, #0x1                ; =1
    cf94:      	b	0xcf44 <_stogir.vector-arithmetic.operation?+0x80>
    cf98:      	cmp	x0, #0x2e
    cf9c:      	b.ne	0xcfa8 <_stogir.vector-arithmetic.operation?+0xe4>
    cfa0:      	mov	x0, #0x1                ; =1
    cfa4:      	b	0xcf44 <_stogir.vector-arithmetic.operation?+0x80>
    cfa8:      	cmp	x0, #0x2f
    cfac:      	b.ne	0xcf38 <_stogir.vector-arithmetic.operation?+0x74>
    cfb0:      	mov	x0, #0x1                ; =1
    cfb4:      	b	0xcf44 <_stogir.vector-arithmetic.operation?+0x80>

000000000000cfb8 <_stogir.vector-arithmetic.unary?>:
    cfb8:      	sxtw	x0, w0
    cfbc:      	cmp	x0, #0x1f
    cfc0:      	b.ne	0xcfdc <_stogir.vector-arithmetic.unary?+0x24>
    cfc4:      	mov	x0, #0x1                ; =1
    cfc8:      	b	0xcfd8 <_stogir.vector-arithmetic.unary?+0x20>
    cfcc:      	cmp	x0, #0x39
    cfd0:      	cset	w0, eq
    cfd4:      	ubfx	x0, x0, #0, #8
    cfd8:      	ret
    cfdc:      	cmp	x0, #0x20
    cfe0:      	b.ne	0xcfec <_stogir.vector-arithmetic.unary?+0x34>
    cfe4:      	mov	x0, #0x1                ; =1
    cfe8:      	b	0xcfd8 <_stogir.vector-arithmetic.unary?+0x20>
    cfec:      	cmp	x0, #0x2d
    cff0:      	b.ne	0xcffc <_stogir.vector-arithmetic.unary?+0x44>
    cff4:      	mov	x0, #0x1                ; =1
    cff8:      	b	0xcfd8 <_stogir.vector-arithmetic.unary?+0x20>
    cffc:      	cmp	x0, #0x36
    d000:      	b.ne	0xd00c <_stogir.vector-arithmetic.unary?+0x54>
    d004:      	mov	x0, #0x1                ; =1
    d008:      	b	0xcfd8 <_stogir.vector-arithmetic.unary?+0x20>
    d00c:      	cmp	x0, #0x37
    d010:      	b.ne	0xd01c <_stogir.vector-arithmetic.unary?+0x64>
    d014:      	mov	x0, #0x1                ; =1
    d018:      	b	0xcfd8 <_stogir.vector-arithmetic.unary?+0x20>
    d01c:      	cmp	x0, #0x38
    d020:      	b.ne	0xcfcc <_stogir.vector-arithmetic.unary?+0x14>
    d024:      	mov	x0, #0x1                ; =1
    d028:      	b	0xcfd8 <_stogir.vector-arithmetic.unary?+0x20>

000000000000d02c <_stogir.vector-arithmetic.operands>:
    d02c:      	sub	sp, sp, #0x80
    d030:      	str	x29, [sp]
    d034:      	str	x30, [sp, #0x8]
    d038:      	mov	x29, sp
    d03c:      	str	x19, [sp, #0x30]
    d040:      	str	x20, [sp, #0x38]
    d044:      	str	x21, [sp, #0x40]
    d048:      	str	x22, [sp, #0x48]
    d04c:      	str	x23, [sp, #0x50]
    d050:      	str	x24, [sp, #0x58]
    d054:      	str	x25, [sp, #0x60]
    d058:      	str	x26, [sp, #0x68]
    d05c:      	str	x27, [sp, #0x70]
    d060:      	str	x28, [sp, #0x78]
    d064:      	lsr	w1, w1, #0
    d068:      	lsr	w2, w2, #0
    d06c:      	mov	x19, x8
    d070:      	mov	x20, x0
    d074:      	mov	w0, w1
    d078:      	mov	w21, w1
    d07c:      	mov	w1, w2
    d080:      	mov	w22, w2
    d084:      	mov	w23, w3
    d088:      	mov	w24, w4
    d08c:      	mov	w25, w5
    d090:      	bl	0xd090 <_stogir.vector-arithmetic.operands+0x64>
		000000000000d090:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    d094:      	cmp	x0, #0x0
    d098:      	b.eq	0xd0b0 <_stogir.vector-arithmetic.operands+0x84>
    d09c:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d09c:  ARM64_RELOC_PAGE21	l_stogir.498
    d0a0:      	ldr	x16, [x16]
		000000000000d0a0:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    d0a4:      	orr	x0, x16, xzr
    d0a8:      	movz	x1, #0x0, lsl #48
    d0ac:      	b	0xd0c0 <_stogir.vector-arithmetic.operands+0x94>
    d0b0:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d0b0:  ARM64_RELOC_PAGE21	l_stogir.499
    d0b4:      	ldr	x16, [x16]
		000000000000d0b4:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    d0b8:      	orr	x0, x16, xzr
    d0bc:      	mov	x1, #0x37               ; =55
    d0c0:      	sxtw	x21, w21
    d0c4:      	sxtw	x22, w22
    d0c8:      	sxtw	x23, w23
    d0cc:      	sxtw	x24, w24
    d0d0:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d0d0:  ARM64_RELOC_PAGE21	l_stogir.500
    d0d4:      	ldr	x16, [x16]
		000000000000d0d4:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    d0d8:      	orr	x2, x16, xzr
    d0dc:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d0dc:  ARM64_RELOC_PAGE21	l_stogir.501
    d0e0:      	ldr	x16, [x16]
		000000000000d0e0:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    d0e4:      	orr	x3, x16, xzr
    d0e8:      	add	x4, x20, #0x78
    d0ec:      	add	x5, x20, #0x28
    d0f0:      	add	x6, x20, #0x50
    d0f4:      	cmp	x21, #0x31
    d0f8:      	cset	w7, ge
    d0fc:      	cmp	x21, #0x35
    d100:      	cset	w8, le
    d104:      	cmp	x21, #0x1f
    d108:      	cset	w9, eq
    d10c:      	cmp	x21, #0x20
    d110:      	cset	w10, eq
    d114:      	cmp	x21, #0x2d
    d118:      	cset	w11, eq
    d11c:      	cmp	x21, #0x36
    d120:      	cset	w12, eq
    d124:      	cmp	x21, #0x37
    d128:      	cset	w13, eq
    d12c:      	cmp	x21, #0x38
    d130:      	cset	w14, eq
    d134:      	cmp	x21, #0x39
    d138:      	cset	w15, eq
    d13c:      	movz	x26, #0x0, lsl #48
    d140:      	b	0xd264 <_stogir.vector-arithmetic.operands+0x238>
    d144:      	movz	x2, #0x0, lsl #48
    d148:      	b	0xd158 <_stogir.vector-arithmetic.operands+0x12c>
    d14c:      	movz	x2, #0x0, lsl #48
    d150:      	b	0xd160 <_stogir.vector-arithmetic.operands+0x134>
    d154:      	movz	x2, #0x0, lsl #48
    d158:      	b	0xd170 <_stogir.vector-arithmetic.operands+0x144>
    d15c:      	movz	x2, #0x0, lsl #48
    d160:      	str	x4, [sp, #0x20]
    d164:      	str	x5, [sp, #0x28]
    d168:      	b	0xd170 <_stogir.vector-arithmetic.operands+0x144>
    d16c:      	movz	x2, #0x0, lsl #48
    d170:      	cmp	x2, #0x0
    d174:      	b.eq	0xd1a8 <_stogir.vector-arithmetic.operands+0x17c>
    d178:      	uxtb	w16, w28
    d17c:      	cmp	w16, wzr
    d180:      	b.eq	0xd194 <_stogir.vector-arithmetic.operands+0x168>
    d184:      	ldr	x2, [x20]
    d188:      	add	x2, x2, x27, lsl #4
    d18c:      	ldr	x2, [x2]
    d190:      	b	0xd1a0 <_stogir.vector-arithmetic.operands+0x174>
    d194:      	ldr	x2, [x20, #0x28]
    d198:      	add	x2, x2, x3, lsl #4
    d19c:      	ldr	x2, [x2]
    d1a0:      	mov	x3, #0x1                ; =1
    d1a4:      	b	0xd1b0 <_stogir.vector-arithmetic.operands+0x184>
    d1a8:      	movz	x3, #0x0, lsl #48
    d1ac:      	movz	x2, #0x0, lsl #48
    d1b0:      	lsr	w3, w3, #0
    d1b4:      	lsr	x16, x3, #0
    d1b8:      	cmp	x16, #0x1
    d1bc:      	b.eq	0xd1d8 <_stogir.vector-arithmetic.operands+0x1ac>
    d1c0:      	b.lo	0xd1c8 <_stogir.vector-arithmetic.operands+0x19c>
    d1c4:      	b	0xd1dc <_stogir.vector-arithmetic.operands+0x1b0>
    d1c8:      	cmp	x16, #0x0
    d1cc:      	b.eq	0xd1d4 <_stogir.vector-arithmetic.operands+0x1a8>
    d1d0:      	b	0xd1dc <_stogir.vector-arithmetic.operands+0x1b0>
    d1d4:      	b	0xd1e0 <_stogir.vector-arithmetic.operands+0x1b4>
    d1d8:      	b	0xd1ec <_stogir.vector-arithmetic.operands+0x1c0>
    d1dc:      	b	0xd54c <_stogir.vector-arithmetic.operands+0x520>
    d1e0:      	ldr	x0, [sp, #0x10]
    d1e4:      	mov	x1, #0x21               ; =33
    d1e8:      	b	0xd248 <_stogir.vector-arithmetic.operands+0x21c>
    d1ec:      	lsr	w3, w2, #0
    d1f0:      	ubfx	x3, x3, #8, #8
    d1f4:      	cmp	x3, x22
    d1f8:      	b.eq	0xd22c <_stogir.vector-arithmetic.operands+0x200>
    d1fc:      	cmp	x26, #0x1
    d200:      	b.ne	0xd240 <_stogir.vector-arithmetic.operands+0x214>
    d204:      	uxtb	w16, w7
    d208:      	cmp	w16, wzr
    d20c:      	b.eq	0xd240 <_stogir.vector-arithmetic.operands+0x214>
    d210:      	uxtb	w16, w8
    d214:      	cmp	w16, wzr
    d218:      	b.eq	0xd240 <_stogir.vector-arithmetic.operands+0x214>
    d21c:      	cmp	x3, #0x1
    d220:      	b.lt	0xd240 <_stogir.vector-arithmetic.operands+0x214>
    d224:      	cmp	x3, #0xb
    d228:      	b.gt	0xd240 <_stogir.vector-arithmetic.operands+0x214>
    d22c:      	uxtb	w2, w2
    d230:      	cmp	x2, #0x48
    d234:      	b.eq	0xd240 <_stogir.vector-arithmetic.operands+0x214>
    d238:      	cmp	x2, #0x46
    d23c:      	b.ne	0xd248 <_stogir.vector-arithmetic.operands+0x21c>
    d240:      	ldr	x0, [sp, #0x18]
    d244:      	mov	x1, #0x32               ; =50
    d248:      	add	x2, x26, #0x1
    d24c:      	lsr	w2, w2, #0
    d250:      	sxtw	x26, w2
    d254:      	ldr	x2, [sp, #0x10]
    d258:      	ldr	x3, [sp, #0x18]
    d25c:      	ldr	x4, [sp, #0x20]
    d260:      	ldr	x5, [sp, #0x28]
    d264:      	uxtb	w16, w9
    d268:      	cmp	w16, wzr
    d26c:      	b.ne	0xd2c0 <_stogir.vector-arithmetic.operands+0x294>
    d270:      	uxtb	w16, w10
    d274:      	cmp	w16, wzr
    d278:      	b.ne	0xd2c0 <_stogir.vector-arithmetic.operands+0x294>
    d27c:      	uxtb	w16, w11
    d280:      	cmp	w16, wzr
    d284:      	b.ne	0xd2c0 <_stogir.vector-arithmetic.operands+0x294>
    d288:      	uxtb	w16, w12
    d28c:      	cmp	w16, wzr
    d290:      	b.ne	0xd2c0 <_stogir.vector-arithmetic.operands+0x294>
    d294:      	uxtb	w16, w13
    d298:      	cmp	w16, wzr
    d29c:      	b.ne	0xd2c0 <_stogir.vector-arithmetic.operands+0x294>
    d2a0:      	uxtb	w16, w14
    d2a4:      	cmp	w16, wzr
    d2a8:      	b.ne	0xd2c0 <_stogir.vector-arithmetic.operands+0x294>
    d2ac:      	uxtb	w16, w15
    d2b0:      	cmp	w16, wzr
    d2b4:      	b.ne	0xd2c0 <_stogir.vector-arithmetic.operands+0x294>
    d2b8:      	mov	x27, #0x2               ; =2
    d2bc:      	b	0xd2c4 <_stogir.vector-arithmetic.operands+0x298>
    d2c0:      	mov	x27, #0x1               ; =1
    d2c4:      	cmp	x26, x27
    d2c8:      	b.ge	0xd390 <_stogir.vector-arithmetic.operands+0x364>
    d2cc:      	cmp	x26, #0x0
    d2d0:      	b.ne	0xd2dc <_stogir.vector-arithmetic.operands+0x2b0>
    d2d4:      	mov	x27, x23
    d2d8:      	b	0xd2e0 <_stogir.vector-arithmetic.operands+0x2b4>
    d2dc:      	mov	x27, x24
    d2e0:      	lsr	w27, w27, #0
    d2e4:      	sxtw	x27, w27
    d2e8:      	cmp	x27, #0x0
    d2ec:      	cset	w28, gt
    d2f0:      	str	x2, [sp, #0x10]
    d2f4:      	movz	x16, #0x0, lsl #48
    d2f8:      	sub	x2, x16, x27
    d2fc:      	str	x3, [sp, #0x18]
    d300:      	sub	x3, x2, #0x1
    d304:      	uxtb	w16, w28
    d308:      	cmp	w16, wzr
    d30c:      	b.eq	0xd348 <_stogir.vector-arithmetic.operands+0x31c>
    d310:      	ldr	x2, [x20, #0x8]
    d314:      	cmp	x27, x2
    d318:      	b.ge	0xd15c <_stogir.vector-arithmetic.operands+0x130>
    d31c:      	ldr	x2, [x4, #0x8]
    d320:      	cmp	x27, x2
    d324:      	b.ge	0xd14c <_stogir.vector-arithmetic.operands+0x120>
    d328:      	ldr	x2, [x20, #0x78]
    d32c:      	add	x2, x2, x27, lsl #2
    d330:      	ldr	w2, [x2]
    d334:      	sxtw	x2, w2
    d338:      	cmp	x2, #0x0
    d33c:      	cset	w2, ge
    d340:      	ubfx	x2, x2, #0, #8
    d344:      	b	0xd150 <_stogir.vector-arithmetic.operands+0x124>
    d348:      	cmp	x27, #0x0
    d34c:      	b.ge	0xd630 <_stogir.vector-arithmetic.operands+0x604>
    d350:      	str	x4, [sp, #0x20]
    d354:      	ldr	x4, [x5, #0x8]
    d358:      	str	x5, [sp, #0x28]
    d35c:      	ldr	x5, [x6, #0x8]
    d360:      	cmp	x4, x5
    d364:      	b.ne	0xd154 <_stogir.vector-arithmetic.operands+0x128>
    d368:      	cmp	x2, x4
    d36c:      	b.gt	0xd144 <_stogir.vector-arithmetic.operands+0x118>
    d370:      	ldr	x2, [x20, #0x50]
    d374:      	add	x2, x2, x3, lsl #2
    d378:      	ldr	w2, [x2]
    d37c:      	sxtw	x2, w2
    d380:      	cmp	x2, #0x0
    d384:      	cset	w2, gt
    d388:      	ubfx	x2, x2, #0, #8
    d38c:      	b	0xd148 <_stogir.vector-arithmetic.operands+0x11c>
    d390:      	sxtw	x25, w25
    d394:      	cmp	x25, #0x0
    d398:      	b.ne	0xd3a4 <_stogir.vector-arithmetic.operands+0x378>
    d39c:      	movz	x2, #0x0, lsl #48
    d3a0:      	b	0xd3a8 <_stogir.vector-arithmetic.operands+0x37c>
    d3a4:      	mov	x2, #0x1                ; =1
    d3a8:      	cmp	x2, #0x0
    d3ac:      	b.eq	0xd3dc <_stogir.vector-arithmetic.operands+0x3b0>
    d3b0:      	cmp	x21, #0x1d
    d3b4:      	b.ne	0xd498 <_stogir.vector-arithmetic.operands+0x46c>
    d3b8:      	mov	x2, #0x1                ; =1
    d3bc:      	b	0xd4a4 <_stogir.vector-arithmetic.operands+0x478>
    d3c0:      	mov	x2, #0x1                ; =1
    d3c4:      	cmp	x2, #0x0
    d3c8:      	b.eq	0xd43c <_stogir.vector-arithmetic.operands+0x410>
    d3cc:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d3cc:  ARM64_RELOC_PAGE21	l_stogir.502
    d3d0:      	ldr	x16, [x16]
		000000000000d3d0:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    d3d4:      	orr	x0, x16, xzr
    d3d8:      	mov	x1, #0x23               ; =35
    d3dc:      	cmp	x1, #0x0
    d3e0:      	b.ne	0xd3f4 <_stogir.vector-arithmetic.operands+0x3c8>
    d3e4:      	and	x0, x22, #0xffffffff
    d3e8:      	movz	x2, #0x0, lsl #48
    d3ec:      	movz	x1, #0x0, lsl #48
    d3f0:      	b	0xd3f8 <_stogir.vector-arithmetic.operands+0x3cc>
    d3f4:      	mov	x2, #0x1                ; =1
    d3f8:      	str	x2, [x19]
    d3fc:      	str	x0, [x19, #0x8]
    d400:      	str	x1, [x19, #0x10]
    d404:      	ldr	x19, [sp, #0x30]
    d408:      	ldr	x20, [sp, #0x38]
    d40c:      	ldr	x21, [sp, #0x40]
    d410:      	ldr	x22, [sp, #0x48]
    d414:      	ldr	x23, [sp, #0x50]
    d418:      	ldr	x24, [sp, #0x58]
    d41c:      	ldr	x25, [sp, #0x60]
    d420:      	ldr	x26, [sp, #0x68]
    d424:      	ldr	x27, [sp, #0x70]
    d428:      	ldr	x28, [sp, #0x78]
    d42c:      	ldr	x29, [sp]
    d430:      	ldr	x30, [sp, #0x8]
    d434:      	add	sp, sp, #0x80
    d438:      	ret
    d43c:      	cmp	x25, #0x0
    d440:      	cset	w2, gt
    d444:      	movz	x16, #0x0, lsl #48
    d448:      	sub	x3, x16, x25
    d44c:      	sub	x4, x3, #0x1
    d450:      	uxtb	w16, w2
    d454:      	cmp	w16, wzr
    d458:      	b.eq	0xd504 <_stogir.vector-arithmetic.operands+0x4d8>
    d45c:      	ldr	x3, [x20, #0x8]
    d460:      	cmp	x25, x3
    d464:      	b.ge	0xd554 <_stogir.vector-arithmetic.operands+0x528>
    d468:      	add	x3, x20, #0x78
    d46c:      	ldr	x3, [x3, #0x8]
    d470:      	cmp	x25, x3
    d474:      	b.ge	0xd618 <_stogir.vector-arithmetic.operands+0x5ec>
    d478:      	ldr	x3, [x20, #0x78]
    d47c:      	add	x3, x3, x25, lsl #2
    d480:      	ldr	w3, [x3]
    d484:      	sxtw	x3, w3
    d488:      	cmp	x3, #0x0
    d48c:      	cset	w3, ge
    d490:      	ubfx	x3, x3, #0, #8
    d494:      	b	0xd61c <_stogir.vector-arithmetic.operands+0x5f0>
    d498:      	cmp	x21, #0x1e
    d49c:      	cset	w2, eq
    d4a0:      	ubfx	x2, x2, #0, #8
    d4a4:      	cmp	x2, #0x0
    d4a8:      	b.eq	0xd3c0 <_stogir.vector-arithmetic.operands+0x394>
    d4ac:      	movz	x2, #0x0, lsl #48
    d4b0:      	b	0xd3c4 <_stogir.vector-arithmetic.operands+0x398>
    d4b4:      	movz	x3, #0x0, lsl #48
    d4b8:      	uxtb	w3, w3
    d4bc:      	and	x3, x3, #0x2
    d4c0:      	uxtb	w3, w3
    d4c4:      	cmp	x3, #0x0
    d4c8:      	cset	w3, eq
    d4cc:      	uxtb	w16, w3
    d4d0:      	cmp	w16, wzr
    d4d4:      	cset	x3, eq
    d4d8:      	cmp	x3, #0x0
    d4dc:      	b.ne	0xd500 <_stogir.vector-arithmetic.operands+0x4d4>
    d4e0:      	cmp	x2, #0x65
    d4e4:      	b.eq	0xd500 <_stogir.vector-arithmetic.operands+0x4d4>
    d4e8:      	cmp	x2, #0x66
    d4ec:      	b.eq	0xd500 <_stogir.vector-arithmetic.operands+0x4d4>
    d4f0:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d4f0:  ARM64_RELOC_PAGE21	l_stogir.503
    d4f4:      	ldr	x16, [x16]
		000000000000d4f4:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    d4f8:      	orr	x0, x16, xzr
    d4fc:      	mov	x1, #0x34               ; =52
    d500:      	b	0xd3dc <_stogir.vector-arithmetic.operands+0x3b0>
    d504:      	cmp	x25, #0x0
    d508:      	b.ge	0xd55c <_stogir.vector-arithmetic.operands+0x530>
    d50c:      	add	x5, x20, #0x28
    d510:      	add	x6, x20, #0x50
    d514:      	ldr	x5, [x5, #0x8]
    d518:      	ldr	x6, [x6, #0x8]
    d51c:      	cmp	x5, x6
    d520:      	b.ne	0xd610 <_stogir.vector-arithmetic.operands+0x5e4>
    d524:      	cmp	x3, x5
    d528:      	b.gt	0xd620 <_stogir.vector-arithmetic.operands+0x5f4>
    d52c:      	ldr	x3, [x20, #0x50]
    d530:      	add	x3, x3, x4, lsl #2
    d534:      	ldr	w3, [x3]
    d538:      	sxtw	x3, w3
    d53c:      	cmp	x3, #0x0
    d540:      	cset	w3, gt
    d544:      	ubfx	x3, x3, #0, #8
    d548:      	b	0xd624 <_stogir.vector-arithmetic.operands+0x5f8>
    d54c:      	brk	#0
    d550:      	b	0xd54c <_stogir.vector-arithmetic.operands+0x520>
    d554:      	movz	x3, #0x0, lsl #48
    d558:      	b	0xd560 <_stogir.vector-arithmetic.operands+0x534>
    d55c:      	movz	x3, #0x0, lsl #48
    d560:      	cmp	x3, #0x0
    d564:      	b.eq	0xd598 <_stogir.vector-arithmetic.operands+0x56c>
    d568:      	uxtb	w16, w2
    d56c:      	cmp	w16, wzr
    d570:      	b.eq	0xd584 <_stogir.vector-arithmetic.operands+0x558>
    d574:      	ldr	x2, [x20]
    d578:      	add	x2, x2, x25, lsl #4
    d57c:      	ldr	x2, [x2]
    d580:      	b	0xd590 <_stogir.vector-arithmetic.operands+0x564>
    d584:      	ldr	x2, [x20, #0x28]
    d588:      	add	x2, x2, x4, lsl #4
    d58c:      	ldr	x2, [x2]
    d590:      	mov	x3, #0x1                ; =1
    d594:      	b	0xd5a0 <_stogir.vector-arithmetic.operands+0x574>
    d598:      	movz	x3, #0x0, lsl #48
    d59c:      	movz	x2, #0x0, lsl #48
    d5a0:      	lsr	w3, w3, #0
    d5a4:      	lsr	x16, x3, #0
    d5a8:      	cmp	x16, #0x1
    d5ac:      	b.eq	0xd5c8 <_stogir.vector-arithmetic.operands+0x59c>
    d5b0:      	b.lo	0xd5b8 <_stogir.vector-arithmetic.operands+0x58c>
    d5b4:      	b	0xd5cc <_stogir.vector-arithmetic.operands+0x5a0>
    d5b8:      	cmp	x16, #0x0
    d5bc:      	b.eq	0xd5c4 <_stogir.vector-arithmetic.operands+0x598>
    d5c0:      	b	0xd5cc <_stogir.vector-arithmetic.operands+0x5a0>
    d5c4:      	b	0xd5d0 <_stogir.vector-arithmetic.operands+0x5a4>
    d5c8:      	b	0xd5e4 <_stogir.vector-arithmetic.operands+0x5b8>
    d5cc:      	b	0xd628 <_stogir.vector-arithmetic.operands+0x5fc>
    d5d0:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d5d0:  ARM64_RELOC_PAGE21	l_stogir.504
    d5d4:      	ldr	x16, [x16]
		000000000000d5d4:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    d5d8:      	orr	x0, x16, xzr
    d5dc:      	mov	x1, #0x1d               ; =29
    d5e0:      	b	0xd500 <_stogir.vector-arithmetic.operands+0x4d4>
    d5e4:      	cmp	x25, #0x0
    d5e8:      	b.le	0xd4f0 <_stogir.vector-arithmetic.operands+0x4c4>
    d5ec:      	uxtb	w2, w2
    d5f0:      	cmp	x2, #0x83
    d5f4:      	b.ge	0xd4b4 <_stogir.vector-arithmetic.operands+0x488>
    d5f8:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d5f8:  ARM64_RELOC_PAGE21	l_stogir.505
    d5fc:      	ldr	x16, [x16]
		000000000000d5fc:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    d600:      	orr	x3, x16, xzr
    d604:      	add	x3, x2, x3
    d608:      	ldrb	w3, [x3]
    d60c:      	b	0xd4b8 <_stogir.vector-arithmetic.operands+0x48c>
    d610:      	movz	x3, #0x0, lsl #48
    d614:      	b	0xd560 <_stogir.vector-arithmetic.operands+0x534>
    d618:      	movz	x3, #0x0, lsl #48
    d61c:      	b	0xd558 <_stogir.vector-arithmetic.operands+0x52c>
    d620:      	movz	x3, #0x0, lsl #48
    d624:      	b	0xd614 <_stogir.vector-arithmetic.operands+0x5e8>
    d628:      	brk	#0
    d62c:      	b	0xd628 <_stogir.vector-arithmetic.operands+0x5fc>
    d630:      	str	x4, [sp, #0x20]
    d634:      	str	x5, [sp, #0x28]
    d638:      	b	0xd16c <_stogir.vector-arithmetic.operands+0x140>

000000000000d63c <_stogir.types.base-type>:
    d63c:      	sxtw	x0, w0
    d640:      	and	x1, x0, #0xf
    d644:      	lsr	w1, w1, #0
    d648:      	sxtw	x1, w1
    d64c:      	cmp	x0, #0x0
    d650:      	b.lt	0xd65c <_stogir.types.base-type+0x20>
    d654:      	cmp	x0, #0xd
    d658:      	b.le	0xd680 <_stogir.types.base-type+0x44>
    d65c:      	cmp	x0, #0xf
    d660:      	b.le	0xd67c <_stogir.types.base-type+0x40>
    d664:      	cmp	x0, #0x80
    d668:      	b.ge	0xd67c <_stogir.types.base-type+0x40>
    d66c:      	cmp	x1, #0x1
    d670:      	b.lt	0xd67c <_stogir.types.base-type+0x40>
    d674:      	cmp	x1, #0xd
    d678:      	b.le	0xd680 <_stogir.types.base-type+0x44>
    d67c:      	movn	x1, #0x0, lsl #48
    d680:      	mov	x0, x1
    d684:      	ret

000000000000d688 <_stogir.types.lanes>:
    d688:      	sxtw	x0, w0
    d68c:      	cmp	x0, #0xf
    d690:      	b.le	0xd6e0 <_stogir.types.lanes+0x58>
    d694:      	cmp	x0, #0x80
    d698:      	b.ge	0xd6e0 <_stogir.types.lanes+0x58>
    d69c:      	and	x1, x0, #0xf
    d6a0:      	lsr	w1, w1, #0
    d6a4:      	sxtw	x1, w1
    d6a8:      	cmp	x1, #0x1
    d6ac:      	b.lt	0xd6e0 <_stogir.types.lanes+0x58>
    d6b0:      	cmp	x1, #0xd
    d6b4:      	b.gt	0xd6e0 <_stogir.types.lanes+0x58>
    d6b8:      	ubfx	x0, x0, #4, #32
    d6bc:      	sxtw	x0, w0
    d6c0:      	sub	x0, x0, #0x1
    d6c4:      	lsr	w0, w0, #0
    d6c8:      	sxtw	x0, w0
    d6cc:      	mov	x16, #0x1               ; =1
    d6d0:      	lsl	x0, x16, x0
    d6d4:      	lsr	w0, w0, #0
    d6d8:      	sxtw	x0, w0
    d6dc:      	b	0xd70c <_stogir.types.lanes+0x84>
    d6e0:      	cmp	x0, #0x0
    d6e4:      	b.lt	0xd708 <_stogir.types.lanes+0x80>
    d6e8:      	cmp	x0, #0xd
    d6ec:      	b.gt	0xd708 <_stogir.types.lanes+0x80>
    d6f0:      	cmp	x0, #0x0
    d6f4:      	cset	w0, eq
    d6f8:      	uxtb	w16, w0
    d6fc:      	cmp	w16, wzr
    d700:      	cset	x0, eq
    d704:      	b	0xd70c <_stogir.types.lanes+0x84>
    d708:      	movn	x0, #0x0, lsl #48
    d70c:      	ret

000000000000d710 <_coil.core.Get$slice$get__u8>:
    d710:      	add	x0, x0, x2
    d714:      	ldrb	w0, [x0]
    d718:      	ret

000000000000d71c <_stogir.checked.valid-type?>:
    d71c:      	sxtw	x0, w0
    d720:      	cmp	x0, #0x1
    d724:      	b.lt	0xd748 <_stogir.checked.valid-type?+0x2c>
    d728:      	cmp	x0, #0xb
    d72c:      	b.gt	0xd748 <_stogir.checked.valid-type?+0x2c>
    d730:      	cmp	x0, #0x1
    d734:      	cset	w0, eq
    d738:      	uxtb	w16, w0
    d73c:      	cmp	w16, wzr
    d740:      	cset	x0, eq
    d744:      	b	0xd74c <_stogir.checked.valid-type?+0x30>
    d748:      	movz	x0, #0x0, lsl #48
    d74c:      	ret

000000000000d750 <_coil.core.Iterable$slice$iter__i32>:
    d750:      	str	x0, [x8]
    d754:      	str	x1, [x8, #0x8]
    d758:      	movz	x17, #0x0, lsl #48
    d75c:      	str	x17, [x8, #0x10]
    d760:      	ret

000000000000d764 <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
    d764:      	sub	sp, sp, #0x10
    d768:      	mov	x1, sp
    d76c:      	ldr	x2, [x0, #0x10]
    d770:      	ldr	x3, [x0]
    d774:      	ldr	x4, [x0, #0x8]
    d778:      	cmp	x2, x4
    d77c:      	b.ge	0xd7a0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x3c>
    d780:      	add	x4, x2, #0x1
    d784:      	add	x2, x3, x2, lsl #2
    d788:      	str	x4, [x0, #0x10]
    d78c:      	ldr	w0, [x2]
    d790:      	sxtw	x0, w0
    d794:      	and	x0, x0, #0xffffffff
    d798:      	mov	x2, #0x1                ; =1
    d79c:      	b	0xd7a8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
    d7a0:      	movz	x2, #0x0, lsl #48
    d7a4:      	movz	x0, #0x0, lsl #48
    d7a8:      	str	x2, [x1]
    d7ac:      	str	x0, [x1, #0x8]
    d7b0:      	ldr	x0, [sp]
    d7b4:      	ldr	x1, [sp, #0x8]
    d7b8:      	add	sp, sp, #0x10
    d7bc:      	ret

000000000000d7c0 <_stogir.terminal.previous-input>:
    d7c0:      	sxtw	x1, w1
    d7c4:      	cmp	x1, #0x0
    d7c8:      	b.ne	0xd7e8 <_stogir.terminal.previous-input+0x28>
    d7cc:      	movz	x1, #0x0, lsl #48
    d7d0:      	movz	x0, #0x0, lsl #48
    d7d4:      	movz	x2, #0x0, lsl #48
    d7d8:      	str	x1, [x8]
    d7dc:      	str	x0, [x8, #0x8]
    d7e0:      	str	x2, [x8, #0x10]
    d7e4:      	ret
    d7e8:      	cmp	x1, #0x0
    d7ec:      	cset	w2, gt
    d7f0:      	movz	x16, #0x0, lsl #48
    d7f4:      	sub	x3, x16, x1
    d7f8:      	sub	x4, x3, #0x1
    d7fc:      	uxtb	w16, w2
    d800:      	cmp	w16, wzr
    d804:      	b.eq	0xd85c <_stogir.terminal.previous-input+0x9c>
    d808:      	ldr	x3, [x0, #0x8]
    d80c:      	cmp	x1, x3
    d810:      	b.ge	0xd8a4 <_stogir.terminal.previous-input+0xe4>
    d814:      	add	x3, x0, #0x78
    d818:      	ldr	x3, [x3, #0x8]
    d81c:      	cmp	x1, x3
    d820:      	b.ge	0xd96c <_stogir.terminal.previous-input+0x1ac>
    d824:      	ldr	x3, [x0, #0x78]
    d828:      	add	x3, x3, x1, lsl #2
    d82c:      	ldr	w3, [x3]
    d830:      	sxtw	x3, w3
    d834:      	cmp	x3, #0x0
    d838:      	cset	w3, ge
    d83c:      	ubfx	x3, x3, #0, #8
    d840:      	b	0xd970 <_stogir.terminal.previous-input+0x1b0>
    d844:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d844:  ARM64_RELOC_PAGE21	l_stogir.506
    d848:      	ldr	x16, [x16]
		000000000000d848:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    d84c:      	orr	x0, x16, xzr
    d850:      	mov	x1, #0x1                ; =1
    d854:      	mov	x2, #0x2e               ; =46
    d858:      	b	0xd7d8 <_stogir.terminal.previous-input+0x18>
    d85c:      	cmp	x1, #0x0
    d860:      	b.ge	0xd8ac <_stogir.terminal.previous-input+0xec>
    d864:      	add	x5, x0, #0x28
    d868:      	add	x6, x0, #0x50
    d86c:      	ldr	x5, [x5, #0x8]
    d870:      	ldr	x6, [x6, #0x8]
    d874:      	cmp	x5, x6
    d878:      	b.ne	0xd964 <_stogir.terminal.previous-input+0x1a4>
    d87c:      	cmp	x3, x5
    d880:      	b.gt	0xd974 <_stogir.terminal.previous-input+0x1b4>
    d884:      	ldr	x3, [x0, #0x50]
    d888:      	add	x3, x3, x4, lsl #2
    d88c:      	ldr	w3, [x3]
    d890:      	sxtw	x3, w3
    d894:      	cmp	x3, #0x0
    d898:      	cset	w3, gt
    d89c:      	ubfx	x3, x3, #0, #8
    d8a0:      	b	0xd978 <_stogir.terminal.previous-input+0x1b8>
    d8a4:      	movz	x3, #0x0, lsl #48
    d8a8:      	b	0xd8b0 <_stogir.terminal.previous-input+0xf0>
    d8ac:      	movz	x3, #0x0, lsl #48
    d8b0:      	cmp	x3, #0x0
    d8b4:      	b.eq	0xd8e8 <_stogir.terminal.previous-input+0x128>
    d8b8:      	uxtb	w16, w2
    d8bc:      	cmp	w16, wzr
    d8c0:      	b.eq	0xd8d4 <_stogir.terminal.previous-input+0x114>
    d8c4:      	ldr	x0, [x0]
    d8c8:      	add	x0, x0, x1, lsl #4
    d8cc:      	ldr	x0, [x0]
    d8d0:      	b	0xd8e0 <_stogir.terminal.previous-input+0x120>
    d8d4:      	ldr	x0, [x0, #0x28]
    d8d8:      	add	x0, x0, x4, lsl #4
    d8dc:      	ldr	x0, [x0]
    d8e0:      	mov	x2, #0x1                ; =1
    d8e4:      	b	0xd8f0 <_stogir.terminal.previous-input+0x130>
    d8e8:      	movz	x2, #0x0, lsl #48
    d8ec:      	movz	x0, #0x0, lsl #48
    d8f0:      	lsr	w2, w2, #0
    d8f4:      	lsr	x16, x2, #0
    d8f8:      	cmp	x16, #0x1
    d8fc:      	b.eq	0xd918 <_stogir.terminal.previous-input+0x158>
    d900:      	b.lo	0xd908 <_stogir.terminal.previous-input+0x148>
    d904:      	b	0xd91c <_stogir.terminal.previous-input+0x15c>
    d908:      	cmp	x16, #0x0
    d90c:      	b.eq	0xd914 <_stogir.terminal.previous-input+0x154>
    d910:      	b	0xd91c <_stogir.terminal.previous-input+0x15c>
    d914:      	b	0xd920 <_stogir.terminal.previous-input+0x160>
    d918:      	b	0xd938 <_stogir.terminal.previous-input+0x178>
    d91c:      	b	0xd9b8 <_stogir.terminal.previous-input+0x1f8>
    d920:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d920:  ARM64_RELOC_PAGE21	l_stogir.507
    d924:      	ldr	x16, [x16]
		000000000000d924:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    d928:      	orr	x0, x16, xzr
    d92c:      	mov	x1, #0x1                ; =1
    d930:      	mov	x2, #0x1d               ; =29
    d934:      	b	0xd858 <_stogir.terminal.previous-input+0x98>
    d938:      	cmp	x1, #0x0
    d93c:      	b.le	0xd844 <_stogir.terminal.previous-input+0x84>
    d940:      	uxtb	w0, w0
    d944:      	cmp	x0, #0x83
    d948:      	b.ge	0xd97c <_stogir.terminal.previous-input+0x1bc>
    d94c:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000d94c:  ARM64_RELOC_PAGE21	l_stogir.508
    d950:      	ldr	x16, [x16]
		000000000000d950:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    d954:      	orr	x2, x16, xzr
    d958:      	add	x0, x0, x2
    d95c:      	ldrb	w0, [x0]
    d960:      	b	0xd980 <_stogir.terminal.previous-input+0x1c0>
    d964:      	movz	x3, #0x0, lsl #48
    d968:      	b	0xd8b0 <_stogir.terminal.previous-input+0xf0>
    d96c:      	movz	x3, #0x0, lsl #48
    d970:      	b	0xd8a8 <_stogir.terminal.previous-input+0xe8>
    d974:      	movz	x3, #0x0, lsl #48
    d978:      	b	0xd968 <_stogir.terminal.previous-input+0x1a8>
    d97c:      	movz	x0, #0x0, lsl #48
    d980:      	uxtb	w0, w0
    d984:      	and	x0, x0, #0x8
    d988:      	uxtb	w0, w0
    d98c:      	cmp	x0, #0x0
    d990:      	cset	w0, eq
    d994:      	uxtb	w16, w0
    d998:      	cmp	w16, wzr
    d99c:      	cset	x0, eq
    d9a0:      	cmp	x0, #0x0
    d9a4:      	b.eq	0xd844 <_stogir.terminal.previous-input+0x84>
    d9a8:      	and	x0, x1, #0xffffffff
    d9ac:      	movz	x1, #0x0, lsl #48
    d9b0:      	movz	x2, #0x0, lsl #48
    d9b4:      	b	0xd858 <_stogir.terminal.previous-input+0x98>
    d9b8:      	brk	#0
    d9bc:      	b	0xd9b8 <_stogir.terminal.previous-input+0x1f8>

000000000000d9c0 <_stogir.switch.selector-type>:
    d9c0:      	sxtw	x1, w1
    d9c4:      	cmp	x1, #0x0
    d9c8:      	cset	w2, gt
    d9cc:      	movz	x16, #0x0, lsl #48
    d9d0:      	sub	x3, x16, x1
    d9d4:      	sub	x4, x3, #0x1
    d9d8:      	uxtb	w16, w2
    d9dc:      	cmp	w16, wzr
    d9e0:      	b.eq	0xda20 <_stogir.switch.selector-type+0x60>
    d9e4:      	ldr	x3, [x0, #0x8]
    d9e8:      	cmp	x1, x3
    d9ec:      	b.ge	0xda70 <_stogir.switch.selector-type+0xb0>
    d9f0:      	add	x3, x0, #0x78
    d9f4:      	ldr	x3, [x3, #0x8]
    d9f8:      	cmp	x1, x3
    d9fc:      	b.ge	0xdb5c <_stogir.switch.selector-type+0x19c>
    da00:      	ldr	x3, [x0, #0x78]
    da04:      	add	x3, x3, x1, lsl #2
    da08:      	ldr	w3, [x3]
    da0c:      	sxtw	x3, w3
    da10:      	cmp	x3, #0x0
    da14:      	cset	w3, ge
    da18:      	ubfx	x3, x3, #0, #8
    da1c:      	b	0xdb60 <_stogir.switch.selector-type+0x1a0>
    da20:      	cmp	x1, #0x0
    da24:      	b.ge	0xda78 <_stogir.switch.selector-type+0xb8>
    da28:      	add	x5, x0, #0x28
    da2c:      	add	x6, x0, #0x50
    da30:      	ldr	x5, [x5, #0x8]
    da34:      	ldr	x6, [x6, #0x8]
    da38:      	cmp	x5, x6
    da3c:      	b.ne	0xda68 <_stogir.switch.selector-type+0xa8>
    da40:      	cmp	x3, x5
    da44:      	b.gt	0xdb64 <_stogir.switch.selector-type+0x1a4>
    da48:      	ldr	x3, [x0, #0x50]
    da4c:      	add	x3, x3, x4, lsl #2
    da50:      	ldr	w3, [x3]
    da54:      	sxtw	x3, w3
    da58:      	cmp	x3, #0x0
    da5c:      	cset	w3, gt
    da60:      	ubfx	x3, x3, #0, #8
    da64:      	b	0xdb68 <_stogir.switch.selector-type+0x1a8>
    da68:      	movz	x3, #0x0, lsl #48
    da6c:      	b	0xda7c <_stogir.switch.selector-type+0xbc>
    da70:      	movz	x3, #0x0, lsl #48
    da74:      	b	0xda7c <_stogir.switch.selector-type+0xbc>
    da78:      	movz	x3, #0x0, lsl #48
    da7c:      	cmp	x3, #0x0
    da80:      	b.eq	0xdab4 <_stogir.switch.selector-type+0xf4>
    da84:      	uxtb	w16, w2
    da88:      	cmp	w16, wzr
    da8c:      	b.eq	0xdaa0 <_stogir.switch.selector-type+0xe0>
    da90:      	ldr	x0, [x0]
    da94:      	add	x0, x0, x1, lsl #4
    da98:      	ldr	x0, [x0]
    da9c:      	b	0xdaac <_stogir.switch.selector-type+0xec>
    daa0:      	ldr	x0, [x0, #0x28]
    daa4:      	add	x0, x0, x4, lsl #4
    daa8:      	ldr	x0, [x0]
    daac:      	mov	x1, #0x1                ; =1
    dab0:      	b	0xdabc <_stogir.switch.selector-type+0xfc>
    dab4:      	movz	x1, #0x0, lsl #48
    dab8:      	movz	x0, #0x0, lsl #48
    dabc:      	lsr	w1, w1, #0
    dac0:      	lsr	x16, x1, #0
    dac4:      	cmp	x16, #0x1
    dac8:      	b.eq	0xdae4 <_stogir.switch.selector-type+0x124>
    dacc:      	b.lo	0xdad4 <_stogir.switch.selector-type+0x114>
    dad0:      	b	0xdae8 <_stogir.switch.selector-type+0x128>
    dad4:      	cmp	x16, #0x0
    dad8:      	b.eq	0xdae0 <_stogir.switch.selector-type+0x120>
    dadc:      	b	0xdae8 <_stogir.switch.selector-type+0x128>
    dae0:      	b	0xdaec <_stogir.switch.selector-type+0x12c>
    dae4:      	b	0xdb28 <_stogir.switch.selector-type+0x168>
    dae8:      	b	0xdb6c <_stogir.switch.selector-type+0x1ac>
    daec:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000daec:  ARM64_RELOC_PAGE21	l_stogir.509
    daf0:      	ldr	x16, [x16]
		000000000000daf0:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    daf4:      	orr	x0, x16, xzr
    daf8:      	mov	x1, #0x1                ; =1
    dafc:      	mov	x2, #0x17               ; =23
    db00:      	b	0xdb18 <_stogir.switch.selector-type+0x158>
    db04:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000db04:  ARM64_RELOC_PAGE21	l_stogir.510
    db08:      	ldr	x16, [x16]
		000000000000db08:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    db0c:      	orr	x0, x16, xzr
    db10:      	mov	x1, #0x1                ; =1
    db14:      	mov	x2, #0x20               ; =32
    db18:      	str	x1, [x8]
    db1c:      	str	x0, [x8, #0x8]
    db20:      	str	x2, [x8, #0x10]
    db24:      	ret
    db28:      	lsr	w1, w0, #0
    db2c:      	ubfx	x1, x1, #8, #8
    db30:      	cmp	x1, #0x1
    db34:      	b.lt	0xdb04 <_stogir.switch.selector-type+0x144>
    db38:      	cmp	x1, #0xb
    db3c:      	b.gt	0xdb04 <_stogir.switch.selector-type+0x144>
    db40:      	uxtb	w0, w0
    db44:      	cmp	x0, #0x48
    db48:      	b.eq	0xdb04 <_stogir.switch.selector-type+0x144>
    db4c:      	and	x0, x1, #0xffffffff
    db50:      	movz	x1, #0x0, lsl #48
    db54:      	movz	x2, #0x0, lsl #48
    db58:      	b	0xdb18 <_stogir.switch.selector-type+0x158>
    db5c:      	movz	x3, #0x0, lsl #48
    db60:      	b	0xda74 <_stogir.switch.selector-type+0xb4>
    db64:      	movz	x3, #0x0, lsl #48
    db68:      	b	0xda6c <_stogir.switch.selector-type+0xac>
    db6c:      	brk	#0
    db70:      	b	0xdb6c <_stogir.switch.selector-type+0x1ac>

000000000000db74 <_stogir.switch.key>:
    db74:      	sub	sp, sp, #0x30
    db78:      	str	x19, [sp]
    db7c:      	str	x20, [sp, #0x8]
    db80:      	str	x21, [sp, #0x10]
    db84:      	str	x22, [sp, #0x18]
    db88:      	str	x23, [sp, #0x20]
    db8c:      	sxtw	x2, w2
    db90:      	cmp	x2, #0x1
    db94:      	b.lt	0xdc0c <_stogir.switch.key+0x98>
    db98:      	cmp	x2, #0xb
    db9c:      	cset	w3, le
    dba0:      	uxtb	w16, w3
    dba4:      	cmp	w16, wzr
    dba8:      	b.eq	0xdc0c <_stogir.switch.key+0x98>
    dbac:      	sxtw	x1, w1
    dbb0:      	cmp	x1, #0x0
    dbb4:      	cset	w4, gt
    dbb8:      	movz	x16, #0x0, lsl #48
    dbbc:      	sub	x5, x16, x1
    dbc0:      	sub	x6, x5, #0x1
    dbc4:      	uxtb	w16, w4
    dbc8:      	cmp	w16, wzr
    dbcc:      	b.eq	0xdc88 <_stogir.switch.key+0x114>
    dbd0:      	ldr	x5, [x0, #0x8]
    dbd4:      	cmp	x1, x5
    dbd8:      	b.ge	0xdcd0 <_stogir.switch.key+0x15c>
    dbdc:      	add	x5, x0, #0x78
    dbe0:      	ldr	x5, [x5, #0x8]
    dbe4:      	cmp	x1, x5
    dbe8:      	b.ge	0xde10 <_stogir.switch.key+0x29c>
    dbec:      	ldr	x5, [x0, #0x78]
    dbf0:      	add	x5, x5, x1, lsl #2
    dbf4:      	ldr	w5, [x5]
    dbf8:      	sxtw	x5, w5
    dbfc:      	cmp	x5, #0x0
    dc00:      	cset	w5, ge
    dc04:      	ubfx	x5, x5, #0, #8
    dc08:      	b	0xde14 <_stogir.switch.key+0x2a0>
    dc0c:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000dc0c:  ARM64_RELOC_PAGE21	l_stogir.511
    dc10:      	ldr	x16, [x16]
		000000000000dc10:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    dc14:      	orr	x0, x16, xzr
    dc18:      	mov	x1, #0x1                ; =1
    dc1c:      	mov	x2, #0x24               ; =36
    dc20:      	str	x1, [x8]
    dc24:      	str	x0, [x8, #0x8]
    dc28:      	str	x2, [x8, #0x10]
    dc2c:      	ldr	x19, [sp]
    dc30:      	ldr	x20, [sp, #0x8]
    dc34:      	ldr	x21, [sp, #0x10]
    dc38:      	ldr	x22, [sp, #0x18]
    dc3c:      	ldr	x23, [sp, #0x20]
    dc40:      	add	sp, sp, #0x30
    dc44:      	ret
    dc48:      	mov	x23, #0x1               ; =1
    dc4c:      	cmp	x1, #0x0
    dc50:      	b.ge	0xdc70 <_stogir.switch.key+0xfc>
    dc54:      	lsr	w1, w4, #0
    dc58:      	uxtb	w4, w4
    dc5c:      	ubfx	x1, x1, #8, #8
    dc60:      	cmp	x4, x1
    dc64:      	b.eq	0xdeb8 <_stogir.switch.key+0x344>
    dc68:      	cmp	x4, #0x49
    dc6c:      	b.eq	0xdeb8 <_stogir.switch.key+0x344>
    dc70:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000dc70:  ARM64_RELOC_PAGE21	l_stogir.512
    dc74:      	ldr	x16, [x16]
		000000000000dc74:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    dc78:      	orr	x0, x16, xzr
    dc7c:      	mov	x1, #0x1                ; =1
    dc80:      	mov	x2, #0x30               ; =48
    dc84:      	b	0xdc20 <_stogir.switch.key+0xac>
    dc88:      	cmp	x1, #0x0
    dc8c:      	b.ge	0xdcd8 <_stogir.switch.key+0x164>
    dc90:      	add	x7, x0, #0x28
    dc94:      	add	x9, x0, #0x50
    dc98:      	ldr	x7, [x7, #0x8]
    dc9c:      	ldr	x9, [x9, #0x8]
    dca0:      	cmp	x7, x9
    dca4:      	b.ne	0xde08 <_stogir.switch.key+0x294>
    dca8:      	cmp	x5, x7
    dcac:      	b.gt	0xdeb0 <_stogir.switch.key+0x33c>
    dcb0:      	ldr	x5, [x0, #0x50]
    dcb4:      	add	x5, x5, x6, lsl #2
    dcb8:      	ldr	w5, [x5]
    dcbc:      	sxtw	x5, w5
    dcc0:      	cmp	x5, #0x0
    dcc4:      	cset	w5, gt
    dcc8:      	ubfx	x5, x5, #0, #8
    dccc:      	b	0xdeb4 <_stogir.switch.key+0x340>
    dcd0:      	movz	x5, #0x0, lsl #48
    dcd4:      	b	0xdcdc <_stogir.switch.key+0x168>
    dcd8:      	movz	x5, #0x0, lsl #48
    dcdc:      	cmp	x5, #0x0
    dce0:      	b.eq	0xdd1c <_stogir.switch.key+0x1a8>
    dce4:      	uxtb	w16, w4
    dce8:      	cmp	w16, wzr
    dcec:      	b.eq	0xdd04 <_stogir.switch.key+0x190>
    dcf0:      	ldr	x0, [x0]
    dcf4:      	add	x0, x0, x1, lsl #4
    dcf8:      	ldr	x4, [x0]
    dcfc:      	ldr	x0, [x0, #0x8]
    dd00:      	b	0xdd14 <_stogir.switch.key+0x1a0>
    dd04:      	ldr	x0, [x0, #0x28]
    dd08:      	add	x0, x0, x6, lsl #4
    dd0c:      	ldr	x4, [x0]
    dd10:      	ldr	x0, [x0, #0x8]
    dd14:      	mov	x5, #0x1                ; =1
    dd18:      	b	0xdd28 <_stogir.switch.key+0x1b4>
    dd1c:      	movz	x5, #0x0, lsl #48
    dd20:      	movz	x4, #0x0, lsl #48
    dd24:      	movz	x0, #0x0, lsl #48
    dd28:      	lsr	w5, w5, #0
    dd2c:      	lsr	x16, x5, #0
    dd30:      	cmp	x16, #0x1
    dd34:      	b.eq	0xdd50 <_stogir.switch.key+0x1dc>
    dd38:      	b.lo	0xdd40 <_stogir.switch.key+0x1cc>
    dd3c:      	b	0xdd54 <_stogir.switch.key+0x1e0>
    dd40:      	cmp	x16, #0x0
    dd44:      	b.eq	0xdd4c <_stogir.switch.key+0x1d8>
    dd48:      	b	0xdd54 <_stogir.switch.key+0x1e0>
    dd4c:      	b	0xdd58 <_stogir.switch.key+0x1e4>
    dd50:      	b	0xdd70 <_stogir.switch.key+0x1fc>
    dd54:      	b	0xdf58 <_stogir.switch.key+0x3e4>
    dd58:      	adrp	x16, 0xd000 <_stogir.vector-arithmetic.unary?+0x48>
		000000000000dd58:  ARM64_RELOC_PAGE21	l_stogir.513
    dd5c:      	ldr	x16, [x16]
		000000000000dd5c:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    dd60:      	orr	x0, x16, xzr
    dd64:      	mov	x1, #0x1                ; =1
    dd68:      	mov	x2, #0x1c               ; =28
    dd6c:      	b	0xdc84 <_stogir.switch.key+0x110>
    dd70:      	cmp	x2, #0x1
    dd74:      	cset	w5, eq
    dd78:      	cmp	x2, #0x0
    dd7c:      	cset	w6, eq
    dd80:      	cmp	x2, #0x2
    dd84:      	cset	w7, eq
    dd88:      	cmp	x2, #0x7
    dd8c:      	cset	w9, eq
    dd90:      	cmp	x2, #0x8
    dd94:      	cset	w10, eq
    dd98:      	cmp	x2, #0x3
    dd9c:      	cset	w11, eq
    dda0:      	cmp	x2, #0x9
    dda4:      	cset	w12, eq
    dda8:      	cmp	x2, #0x4
    ddac:      	cset	w13, eq
    ddb0:      	cmp	x2, #0xa
    ddb4:      	cset	w14, eq
    ddb8:      	cmp	x2, #0xd
    ddbc:      	cset	w15, eq
    ddc0:      	cmp	x2, #0x5
    ddc4:      	cset	w19, eq
    ddc8:      	cmp	x2, #0xb
    ddcc:      	cset	w20, eq
    ddd0:      	cmp	x2, #0xc
    ddd4:      	cset	w21, eq
    ddd8:      	cmp	x2, #0x6
    dddc:      	cset	w22, eq
    dde0:      	uxtb	w16, w22
    dde4:      	cmp	w16, wzr
    dde8:      	mov	x16, #0x8               ; =8
    ddec:      	movn	x17, #0x0, lsl #48
    ddf0:      	csel	x22, x16, x17, ne
    ddf4:      	uxtb	w16, w6
    ddf8:      	cmp	w16, wzr
    ddfc:      	b.eq	0xde18 <_stogir.switch.key+0x2a4>
    de00:      	movz	x23, #0x0, lsl #48
    de04:      	b	0xdc4c <_stogir.switch.key+0xd8>
    de08:      	movz	x5, #0x0, lsl #48
    de0c:      	b	0xdcdc <_stogir.switch.key+0x168>
    de10:      	movz	x5, #0x0, lsl #48
    de14:      	b	0xdcd4 <_stogir.switch.key+0x160>
    de18:      	uxtb	w16, w5
    de1c:      	cmp	w16, wzr
    de20:      	b.ne	0xdc48 <_stogir.switch.key+0xd4>
    de24:      	uxtb	w16, w7
    de28:      	cmp	w16, wzr
    de2c:      	b.ne	0xdc48 <_stogir.switch.key+0xd4>
    de30:      	uxtb	w16, w9
    de34:      	cmp	w16, wzr
    de38:      	b.ne	0xdc48 <_stogir.switch.key+0xd4>
    de3c:      	uxtb	w16, w10
    de40:      	cmp	w16, wzr
    de44:      	b.ne	0xdc48 <_stogir.switch.key+0xd4>
    de48:      	uxtb	w16, w11
    de4c:      	cmp	w16, wzr
    de50:      	b.ne	0xdf50 <_stogir.switch.key+0x3dc>
    de54:      	uxtb	w16, w12
    de58:      	cmp	w16, wzr
    de5c:      	b.ne	0xdf50 <_stogir.switch.key+0x3dc>
    de60:      	uxtb	w16, w13
    de64:      	cmp	w16, wzr
    de68:      	b.ne	0xe028 <_stogir.switch.key+0x4b4>
    de6c:      	uxtb	w16, w14
    de70:      	cmp	w16, wzr
    de74:      	b.ne	0xe028 <_stogir.switch.key+0x4b4>
    de78:      	uxtb	w16, w15
    de7c:      	cmp	w16, wzr
    de80:      	b.ne	0xe028 <_stogir.switch.key+0x4b4>
    de84:      	uxtb	w16, w19
    de88:      	cmp	w16, wzr
    de8c:      	b.ne	0xe030 <_stogir.switch.key+0x4bc>
    de90:      	uxtb	w16, w20
    de94:      	cmp	w16, wzr
    de98:      	b.ne	0xe030 <_stogir.switch.key+0x4bc>
    de9c:      	uxtb	w16, w21
    dea0:      	cmp	w16, wzr
    dea4:      	b.ne	0xe030 <_stogir.switch.key+0x4bc>
    dea8:      	mov	x23, x22
    deac:      	b	0xe034 <_stogir.switch.key+0x4c0>
    deb0:      	movz	x5, #0x0, lsl #48
    deb4:      	b	0xde0c <_stogir.switch.key+0x298>
    deb8:      	cmp	x1, x2
    debc:      	b.ne	0xdc70 <_stogir.switch.key+0xfc>
    dec0:      	lsr	w23, w23, #0
    dec4:      	lsr	w1, w0, #0
    dec8:      	sxtw	x23, w23
    decc:      	ubfx	x1, x1, #0, #32
    ded0:      	lsr	x0, x0, #32
    ded4:      	lsl	x4, x23, #3
    ded8:      	ubfx	x0, x0, #0, #32
    dedc:      	lsr	w4, w4, #0
    dee0:      	lsl	x0, x0, #32
    dee4:      	sxtw	x4, w4
    dee8:      	orr	x0, x0, x1
    deec:      	cmp	x4, #0x40
    def0:      	b.ge	0xdf00 <_stogir.switch.key+0x38c>
    def4:      	lsr	x1, x0, x4
    def8:      	cmp	x1, #0x0
    defc:      	b.ne	0xdc70 <_stogir.switch.key+0xfc>
    df00:      	uxtb	w16, w5
    df04:      	cmp	w16, wzr
    df08:      	b.eq	0xdf14 <_stogir.switch.key+0x3a0>
    df0c:      	cmp	x0, #0x1
    df10:      	b.hi	0xdc70 <_stogir.switch.key+0xfc>
    df14:      	cmp	x2, #0x7
    df18:      	b.lt	0xdf3c <_stogir.switch.key+0x3c8>
    df1c:      	uxtb	w16, w3
    df20:      	cmp	w16, wzr
    df24:      	b.eq	0xdf3c <_stogir.switch.key+0x3c8>
    df28:      	uxtb	w16, w6
    df2c:      	cmp	w16, wzr
    df30:      	b.eq	0xdf90 <_stogir.switch.key+0x41c>
    df34:      	movz	x22, #0x0, lsl #48
    df38:      	b	0xdf64 <_stogir.switch.key+0x3f0>
    df3c:      	movz	x1, #0x0, lsl #48
    df40:      	eor	x0, x1, x0
    df44:      	movz	x1, #0x0, lsl #48
    df48:      	movz	x2, #0x0, lsl #48
    df4c:      	b	0xdc84 <_stogir.switch.key+0x110>
    df50:      	mov	x23, #0x2               ; =2
    df54:      	b	0xdc4c <_stogir.switch.key+0xd8>
    df58:      	brk	#0
    df5c:      	b	0xdf58 <_stogir.switch.key+0x3e4>
    df60:      	mov	x22, #0x1               ; =1
    df64:      	lsr	w22, w22, #0
    df68:      	sxtw	x22, w22
    df6c:      	lsl	x1, x22, #3
    df70:      	lsr	w1, w1, #0
    df74:      	sxtw	x1, w1
    df78:      	sub	x1, x1, #0x1
    df7c:      	lsr	w1, w1, #0
    df80:      	sxtw	x1, w1
    df84:      	mov	x16, #0x1               ; =1
    df88:      	lsl	x1, x16, x1
    df8c:      	b	0xdf40 <_stogir.switch.key+0x3cc>
    df90:      	uxtb	w16, w5
    df94:      	cmp	w16, wzr
    df98:      	b.ne	0xdf60 <_stogir.switch.key+0x3ec>
    df9c:      	uxtb	w16, w7
    dfa0:      	cmp	w16, wzr
    dfa4:      	b.ne	0xdf60 <_stogir.switch.key+0x3ec>
    dfa8:      	uxtb	w16, w9
    dfac:      	cmp	w16, wzr
    dfb0:      	b.ne	0xdf60 <_stogir.switch.key+0x3ec>
    dfb4:      	uxtb	w16, w10
    dfb8:      	cmp	w16, wzr
    dfbc:      	b.ne	0xdf60 <_stogir.switch.key+0x3ec>
    dfc0:      	uxtb	w16, w11
    dfc4:      	cmp	w16, wzr
    dfc8:      	b.ne	0xe038 <_stogir.switch.key+0x4c4>
    dfcc:      	uxtb	w16, w12
    dfd0:      	cmp	w16, wzr
    dfd4:      	b.ne	0xe038 <_stogir.switch.key+0x4c4>
    dfd8:      	uxtb	w16, w13
    dfdc:      	cmp	w16, wzr
    dfe0:      	b.ne	0xe040 <_stogir.switch.key+0x4cc>
    dfe4:      	uxtb	w16, w14
    dfe8:      	cmp	w16, wzr
    dfec:      	b.ne	0xe040 <_stogir.switch.key+0x4cc>
    dff0:      	uxtb	w16, w15
    dff4:      	cmp	w16, wzr
    dff8:      	b.ne	0xe040 <_stogir.switch.key+0x4cc>
    dffc:      	uxtb	w16, w19
    e000:      	cmp	w16, wzr
    e004:      	b.ne	0xe020 <_stogir.switch.key+0x4ac>
    e008:      	uxtb	w16, w20
    e00c:      	cmp	w16, wzr
    e010:      	b.ne	0xe020 <_stogir.switch.key+0x4ac>
    e014:      	uxtb	w16, w21
    e018:      	cmp	w16, wzr
    e01c:      	b.eq	0xe024 <_stogir.switch.key+0x4b0>
    e020:      	mov	x22, #0x8               ; =8
    e024:      	b	0xe044 <_stogir.switch.key+0x4d0>
    e028:      	mov	x23, #0x4               ; =4
    e02c:      	b	0xdf54 <_stogir.switch.key+0x3e0>
    e030:      	mov	x23, #0x8               ; =8
    e034:      	b	0xe02c <_stogir.switch.key+0x4b8>
    e038:      	mov	x22, #0x2               ; =2
    e03c:      	b	0xdf64 <_stogir.switch.key+0x3f0>
    e040:      	mov	x22, #0x4               ; =4
    e044:      	b	0xe03c <_stogir.switch.key+0x4c8>

000000000000e048 <_stogir.stack.entry-allocation?>:
    e048:      	sub	sp, sp, #0x10
    e04c:      	add	x2, x0, #0x78
    e050:      	add	x3, x0, #0x28
    e054:      	add	x4, x0, #0x50
    e058:      	add	x5, x0, #0x78
    e05c:      	add	x6, x0, #0x28
    e060:      	add	x7, x0, #0x50
    e064:      	sxtw	x1, w1
    e068:      	mov	x8, #0x1                ; =1
    e06c:      	movz	x9, #0x0, lsl #48
    e070:      	b	0xe174 <_stogir.stack.entry-allocation?+0x12c>
    e074:      	movz	x12, #0x0, lsl #48
    e078:      	b	0xe0e4 <_stogir.stack.entry-allocation?+0x9c>
    e07c:      	movz	x11, #0x0, lsl #48
    e080:      	movz	x10, #0x0, lsl #48
    e084:      	lsr	w11, w11, #0
    e088:      	lsr	x16, x11, #0
    e08c:      	cmp	x16, #0x1
    e090:      	b.eq	0xe0ac <_stogir.stack.entry-allocation?+0x64>
    e094:      	b.lo	0xe09c <_stogir.stack.entry-allocation?+0x54>
    e098:      	b	0xe0b0 <_stogir.stack.entry-allocation?+0x68>
    e09c:      	cmp	x16, #0x0
    e0a0:      	b.eq	0xe0a8 <_stogir.stack.entry-allocation?+0x60>
    e0a4:      	b	0xe0b0 <_stogir.stack.entry-allocation?+0x68>
    e0a8:      	b	0xe0d0 <_stogir.stack.entry-allocation?+0x88>
    e0ac:      	b	0xe0b4 <_stogir.stack.entry-allocation?+0x6c>
    e0b0:      	b	0xe39c <_stogir.stack.entry-allocation?+0x354>
    e0b4:      	uxtb	w11, w10
    e0b8:      	lsr	w10, w10, #0
    e0bc:      	ubfx	x10, x10, #8, #8
    e0c0:      	cmp	x11, x10
    e0c4:      	b.eq	0xe38c <_stogir.stack.entry-allocation?+0x344>
    e0c8:      	cmp	x11, #0x49
    e0cc:      	b.eq	0xe38c <_stogir.stack.entry-allocation?+0x344>
    e0d0:      	movz	x8, #0x0, lsl #48
    e0d4:      	b	0xe254 <_stogir.stack.entry-allocation?+0x20c>
    e0d8:      	movz	x12, #0x0, lsl #48
    e0dc:      	b	0xe0ec <_stogir.stack.entry-allocation?+0xa4>
    e0e0:      	movz	x12, #0x0, lsl #48
    e0e4:      	b	0xe0f4 <_stogir.stack.entry-allocation?+0xac>
    e0e8:      	movz	x12, #0x0, lsl #48
    e0ec:      	b	0xe0f4 <_stogir.stack.entry-allocation?+0xac>
    e0f0:      	movz	x12, #0x0, lsl #48
    e0f4:      	cmp	x12, #0x0
    e0f8:      	b.eq	0xe134 <_stogir.stack.entry-allocation?+0xec>
    e0fc:      	uxtb	w16, w11
    e100:      	cmp	w16, wzr
    e104:      	b.eq	0xe11c <_stogir.stack.entry-allocation?+0xd4>
    e108:      	ldr	x11, [x0]
    e10c:      	add	x10, x11, x10, lsl #4
    e110:      	ldr	x11, [x10]
    e114:      	ldr	x10, [x10, #0x8]
    e118:      	b	0xe12c <_stogir.stack.entry-allocation?+0xe4>
    e11c:      	ldr	x10, [x0, #0x28]
    e120:      	add	x10, x10, x13, lsl #4
    e124:      	ldr	x11, [x10]
    e128:      	ldr	x10, [x10, #0x8]
    e12c:      	mov	x12, #0x1               ; =1
    e130:      	b	0xe140 <_stogir.stack.entry-allocation?+0xf8>
    e134:      	movz	x12, #0x0, lsl #48
    e138:      	movz	x11, #0x0, lsl #48
    e13c:      	movz	x10, #0x0, lsl #48
    e140:      	lsr	w12, w12, #0
    e144:      	lsr	x16, x12, #0
    e148:      	cmp	x16, #0x1
    e14c:      	b.eq	0xe168 <_stogir.stack.entry-allocation?+0x120>
    e150:      	b.lo	0xe158 <_stogir.stack.entry-allocation?+0x110>
    e154:      	b	0xe16c <_stogir.stack.entry-allocation?+0x124>
    e158:      	cmp	x16, #0x0
    e15c:      	b.eq	0xe164 <_stogir.stack.entry-allocation?+0x11c>
    e160:      	b	0xe16c <_stogir.stack.entry-allocation?+0x124>
    e164:      	b	0xe170 <_stogir.stack.entry-allocation?+0x128>
    e168:      	b	0xe224 <_stogir.stack.entry-allocation?+0x1dc>
    e16c:      	b	0xe2f8 <_stogir.stack.entry-allocation?+0x2b0>
    e170:      	movz	x8, #0x0, lsl #48
    e174:      	cmp	x8, #0x0
    e178:      	b.eq	0xe2e0 <_stogir.stack.entry-allocation?+0x298>
    e17c:      	cmp	x9, #0x0
    e180:      	b.ne	0xe2e0 <_stogir.stack.entry-allocation?+0x298>
    e184:      	lsr	w10, w1, #0
    e188:      	sxtw	x10, w10
    e18c:      	cmp	x10, #0x0
    e190:      	cset	w11, gt
    e194:      	movz	x16, #0x0, lsl #48
    e198:      	sub	x12, x16, x10
    e19c:      	sub	x13, x12, #0x1
    e1a0:      	uxtb	w16, w11
    e1a4:      	cmp	w16, wzr
    e1a8:      	b.eq	0xe1e4 <_stogir.stack.entry-allocation?+0x19c>
    e1ac:      	ldr	x12, [x0, #0x8]
    e1b0:      	cmp	x10, x12
    e1b4:      	b.ge	0xe0e8 <_stogir.stack.entry-allocation?+0xa0>
    e1b8:      	ldr	x12, [x2, #0x8]
    e1bc:      	cmp	x10, x12
    e1c0:      	b.ge	0xe0d8 <_stogir.stack.entry-allocation?+0x90>
    e1c4:      	ldr	x12, [x0, #0x78]
    e1c8:      	add	x12, x12, x10, lsl #2
    e1cc:      	ldr	w12, [x12]
    e1d0:      	sxtw	x12, w12
    e1d4:      	cmp	x12, #0x0
    e1d8:      	cset	w12, ge
    e1dc:      	ubfx	x12, x12, #0, #8
    e1e0:      	b	0xe0dc <_stogir.stack.entry-allocation?+0x94>
    e1e4:      	cmp	x10, #0x0
    e1e8:      	b.ge	0xe0f0 <_stogir.stack.entry-allocation?+0xa8>
    e1ec:      	ldr	x14, [x3, #0x8]
    e1f0:      	ldr	x15, [x4, #0x8]
    e1f4:      	cmp	x14, x15
    e1f8:      	b.ne	0xe0e0 <_stogir.stack.entry-allocation?+0x98>
    e1fc:      	cmp	x12, x14
    e200:      	b.gt	0xe074 <_stogir.stack.entry-allocation?+0x2c>
    e204:      	ldr	x12, [x0, #0x50]
    e208:      	add	x12, x12, x13, lsl #2
    e20c:      	ldr	w12, [x12]
    e210:      	sxtw	x12, w12
    e214:      	cmp	x12, #0x0
    e218:      	cset	w12, gt
    e21c:      	ubfx	x12, x12, #0, #8
    e220:      	b	0xe078 <_stogir.stack.entry-allocation?+0x30>
    e224:      	uxtb	w12, w11
    e228:      	asr	x13, x11, #32
    e22c:      	mov	x16, sp
    e230:      	str	x11, [x16]
    e234:      	mov	x16, sp
    e238:      	str	x10, [x16, #0x8]
    e23c:      	cmp	x12, #0x68
    e240:      	b.ne	0xe258 <_stogir.stack.entry-allocation?+0x210>
    e244:      	cmp	x13, #0x0
    e248:      	cset	w8, eq
    e24c:      	ubfx	x8, x8, #0, #8
    e250:      	mov	x9, #0x1                ; =1
    e254:      	b	0xe174 <_stogir.stack.entry-allocation?+0x12c>
    e258:      	cmp	x1, #0x0
    e25c:      	b.le	0xe0d0 <_stogir.stack.entry-allocation?+0x88>
    e260:      	cmp	x12, #0x51
    e264:      	b.ne	0xe0d0 <_stogir.stack.entry-allocation?+0x88>
    e268:      	cmp	x13, #0x0
    e26c:      	b.le	0xe0d0 <_stogir.stack.entry-allocation?+0x88>
    e270:      	cmp	x13, x1
    e274:      	b.ge	0xe0d0 <_stogir.stack.entry-allocation?+0x88>
    e278:      	lsr	w10, w10, #0
    e27c:      	sxtw	x10, w10
    e280:      	cmp	x10, #0x0
    e284:      	b.ge	0xe0d0 <_stogir.stack.entry-allocation?+0x88>
    e288:      	cmp	x10, #0x0
    e28c:      	cset	w11, gt
    e290:      	movz	x16, #0x0, lsl #48
    e294:      	sub	x12, x16, x10
    e298:      	sub	x13, x12, #0x1
    e29c:      	uxtb	w16, w11
    e2a0:      	cmp	w16, wzr
    e2a4:      	b.eq	0xe344 <_stogir.stack.entry-allocation?+0x2fc>
    e2a8:      	ldr	x12, [x0, #0x8]
    e2ac:      	cmp	x10, x12
    e2b0:      	b.ge	0xe33c <_stogir.stack.entry-allocation?+0x2f4>
    e2b4:      	ldr	x12, [x5, #0x8]
    e2b8:      	cmp	x10, x12
    e2bc:      	b.ge	0xe384 <_stogir.stack.entry-allocation?+0x33c>
    e2c0:      	ldr	x12, [x0, #0x78]
    e2c4:      	add	x12, x12, x10, lsl #2
    e2c8:      	ldr	w12, [x12]
    e2cc:      	sxtw	x12, w12
    e2d0:      	cmp	x12, #0x0
    e2d4:      	cset	w12, ge
    e2d8:      	ubfx	x12, x12, #0, #8
    e2dc:      	b	0xe388 <_stogir.stack.entry-allocation?+0x340>
    e2e0:      	cmp	x8, #0x0
    e2e4:      	b.ne	0xe2ec <_stogir.stack.entry-allocation?+0x2a4>
    e2e8:      	movz	x9, #0x0, lsl #48
    e2ec:      	mov	x0, x9
    e2f0:      	add	sp, sp, #0x10
    e2f4:      	ret
    e2f8:      	brk	#0
    e2fc:      	b	0xe2f8 <_stogir.stack.entry-allocation?+0x2b0>
    e300:      	ldr	x10, [x0, #0x28]
    e304:      	add	x10, x10, x13, lsl #4
    e308:      	ldr	x10, [x10]
    e30c:      	mov	x11, #0x1               ; =1
    e310:      	b	0xe084 <_stogir.stack.entry-allocation?+0x3c>
    e314:      	movz	x12, #0x0, lsl #48
    e318:      	cmp	x12, #0x0
    e31c:      	b.eq	0xe07c <_stogir.stack.entry-allocation?+0x34>
    e320:      	uxtb	w16, w11
    e324:      	cmp	w16, wzr
    e328:      	b.eq	0xe300 <_stogir.stack.entry-allocation?+0x2b8>
    e32c:      	ldr	x11, [x0]
    e330:      	add	x10, x11, x10, lsl #4
    e334:      	ldr	x10, [x10]
    e338:      	b	0xe30c <_stogir.stack.entry-allocation?+0x2c4>
    e33c:      	movz	x12, #0x0, lsl #48
    e340:      	b	0xe318 <_stogir.stack.entry-allocation?+0x2d0>
    e344:      	ldr	x14, [x6, #0x8]
    e348:      	ldr	x15, [x7, #0x8]
    e34c:      	cmp	x14, x15
    e350:      	b.ne	0xe314 <_stogir.stack.entry-allocation?+0x2cc>
    e354:      	cmp	x12, x14
    e358:      	b.gt	0xe37c <_stogir.stack.entry-allocation?+0x334>
    e35c:      	ldr	x12, [x0, #0x50]
    e360:      	add	x12, x12, x13, lsl #2
    e364:      	ldr	w12, [x12]
    e368:      	sxtw	x12, w12
    e36c:      	cmp	x12, #0x0
    e370:      	cset	w12, gt
    e374:      	ubfx	x12, x12, #0, #8
    e378:      	b	0xe380 <_stogir.stack.entry-allocation?+0x338>
    e37c:      	movz	x12, #0x0, lsl #48
    e380:      	b	0xe318 <_stogir.stack.entry-allocation?+0x2d0>
    e384:      	movz	x12, #0x0, lsl #48
    e388:      	b	0xe340 <_stogir.stack.entry-allocation?+0x2f8>
    e38c:      	mov	x16, sp
    e390:      	ldr	w1, [x16, #0x4]
    e394:      	sxtw	x1, w1
    e398:      	b	0xe0d4 <_stogir.stack.entry-allocation?+0x8c>
    e39c:      	brk	#0
    e3a0:      	b	0xe39c <_stogir.stack.entry-allocation?+0x354>

000000000000e3a4 <_stogir.stack.constant-size>:
    e3a4:      	sub	sp, sp, #0x10
    e3a8:      	str	x29, [sp]
    e3ac:      	str	x30, [sp, #0x8]
    e3b0:      	mov	x29, sp
    e3b4:      	mov	x2, sp
    e3b8:      	sxtw	x1, w1
    e3bc:      	sub	sp, sp, #0x10
    e3c0:      	mov	x3, sp
    e3c4:      	cmp	x1, #0x0
    e3c8:      	cset	w4, gt
    e3cc:      	movz	x16, #0x0, lsl #48
    e3d0:      	sub	x5, x16, x1
    e3d4:      	sub	x6, x5, #0x1
    e3d8:      	uxtb	w16, w4
    e3dc:      	cmp	w16, wzr
    e3e0:      	b.eq	0xe420 <_stogir.stack.constant-size+0x7c>
    e3e4:      	ldr	x5, [x0, #0x8]
    e3e8:      	cmp	x1, x5
    e3ec:      	b.ge	0xe470 <_stogir.stack.constant-size+0xcc>
    e3f0:      	add	x5, x0, #0x78
    e3f4:      	ldr	x5, [x5, #0x8]
    e3f8:      	cmp	x1, x5
    e3fc:      	b.ge	0xe5b4 <_stogir.stack.constant-size+0x210>
    e400:      	ldr	x5, [x0, #0x78]
    e404:      	add	x5, x5, x1, lsl #2
    e408:      	ldr	w5, [x5]
    e40c:      	sxtw	x5, w5
    e410:      	cmp	x5, #0x0
    e414:      	cset	w5, ge
    e418:      	ubfx	x5, x5, #0, #8
    e41c:      	b	0xe5b8 <_stogir.stack.constant-size+0x214>
    e420:      	cmp	x1, #0x0
    e424:      	b.ge	0xe478 <_stogir.stack.constant-size+0xd4>
    e428:      	add	x7, x0, #0x28
    e42c:      	add	x9, x0, #0x50
    e430:      	ldr	x7, [x7, #0x8]
    e434:      	ldr	x9, [x9, #0x8]
    e438:      	cmp	x7, x9
    e43c:      	b.ne	0xe468 <_stogir.stack.constant-size+0xc4>
    e440:      	cmp	x5, x7
    e444:      	b.gt	0xe63c <_stogir.stack.constant-size+0x298>
    e448:      	ldr	x5, [x0, #0x50]
    e44c:      	add	x5, x5, x6, lsl #2
    e450:      	ldr	w5, [x5]
    e454:      	sxtw	x5, w5
    e458:      	cmp	x5, #0x0
    e45c:      	cset	w5, gt
    e460:      	ubfx	x5, x5, #0, #8
    e464:      	b	0xe640 <_stogir.stack.constant-size+0x29c>
    e468:      	movz	x5, #0x0, lsl #48
    e46c:      	b	0xe47c <_stogir.stack.constant-size+0xd8>
    e470:      	movz	x5, #0x0, lsl #48
    e474:      	b	0xe47c <_stogir.stack.constant-size+0xd8>
    e478:      	movz	x5, #0x0, lsl #48
    e47c:      	cmp	x5, #0x0
    e480:      	b.eq	0xe4bc <_stogir.stack.constant-size+0x118>
    e484:      	uxtb	w16, w4
    e488:      	cmp	w16, wzr
    e48c:      	b.eq	0xe4a4 <_stogir.stack.constant-size+0x100>
    e490:      	ldr	x0, [x0]
    e494:      	add	x0, x0, x1, lsl #4
    e498:      	ldr	x4, [x0]
    e49c:      	ldr	x0, [x0, #0x8]
    e4a0:      	b	0xe4b4 <_stogir.stack.constant-size+0x110>
    e4a4:      	ldr	x0, [x0, #0x28]
    e4a8:      	add	x0, x0, x6, lsl #4
    e4ac:      	ldr	x4, [x0]
    e4b0:      	ldr	x0, [x0, #0x8]
    e4b4:      	mov	x5, #0x1                ; =1
    e4b8:      	b	0xe4c8 <_stogir.stack.constant-size+0x124>
    e4bc:      	movz	x5, #0x0, lsl #48
    e4c0:      	movz	x4, #0x0, lsl #48
    e4c4:      	movz	x0, #0x0, lsl #48
    e4c8:      	lsr	w5, w5, #0
    e4cc:      	lsr	x16, x5, #0
    e4d0:      	cmp	x16, #0x1
    e4d4:      	b.eq	0xe4f0 <_stogir.stack.constant-size+0x14c>
    e4d8:      	b.lo	0xe4e0 <_stogir.stack.constant-size+0x13c>
    e4dc:      	b	0xe4f4 <_stogir.stack.constant-size+0x150>
    e4e0:      	cmp	x16, #0x0
    e4e4:      	b.eq	0xe4ec <_stogir.stack.constant-size+0x148>
    e4e8:      	b	0xe4f4 <_stogir.stack.constant-size+0x150>
    e4ec:      	b	0xe4f8 <_stogir.stack.constant-size+0x154>
    e4f0:      	b	0xe594 <_stogir.stack.constant-size+0x1f0>
    e4f4:      	b	0xe6f0 <_stogir.stack.constant-size+0x34c>
    e4f8:      	adrp	x16, 0xe000 <_stogir.switch.key+0x48c>
		000000000000e4f8:  ARM64_RELOC_PAGE21	l_stogir.514
    e4fc:      	ldr	x16, [x16]
		000000000000e4fc:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    e500:      	orr	x0, x16, xzr
    e504:      	mov	x1, #0x1                ; =1
    e508:      	mov	x3, #0x18               ; =24
    e50c:      	b	0xe570 <_stogir.stack.constant-size+0x1cc>
    e510:      	mov	x4, #0x1                ; =1
    e514:      	ldr	w5, [x3, #0x8]
    e518:      	ldr	w6, [x3, #0xc]
    e51c:      	cmp	x1, #0x0
    e520:      	b.ge	0xe55c <_stogir.stack.constant-size+0x1b8>
    e524:      	cmp	x0, #0x1
    e528:      	b.lt	0xe55c <_stogir.stack.constant-size+0x1b8>
    e52c:      	cmp	x0, #0xb
    e530:      	cset	w1, le
    e534:      	uxtb	w16, w1
    e538:      	cmp	w16, wzr
    e53c:      	b.eq	0xe55c <_stogir.stack.constant-size+0x1b8>
    e540:      	ldr	w3, [x3]
    e544:      	uxtb	w7, w3
    e548:      	ubfx	x3, x3, #8, #8
    e54c:      	cmp	x7, x3
    e550:      	b.eq	0xe644 <_stogir.stack.constant-size+0x2a0>
    e554:      	cmp	x7, #0x49
    e558:      	b.eq	0xe644 <_stogir.stack.constant-size+0x2a0>
    e55c:      	adrp	x16, 0xe000 <_stogir.switch.key+0x48c>
		000000000000e55c:  ARM64_RELOC_PAGE21	l_stogir.515
    e560:      	ldr	x16, [x16]
		000000000000e560:  ARM64_RELOC_PAGEOFF12	l_stogir.515
    e564:      	orr	x0, x16, xzr
    e568:      	mov	x1, #0x1                ; =1
    e56c:      	mov	x3, #0x30               ; =48
    e570:      	mov	sp, x2
    e574:      	str	x1, [x8]
    e578:      	str	x0, [x8, #0x8]
    e57c:      	str	x3, [x8, #0x10]
    e580:      	sub	sp, x29, #0x0
    e584:      	ldr	x29, [sp]
    e588:      	ldr	x30, [sp, #0x8]
    e58c:      	add	sp, sp, #0x10
    e590:      	ret
    e594:      	lsr	w5, w4, #0
    e598:      	str	x4, [x3]
    e59c:      	str	x0, [x3, #0x8]
    e5a0:      	ubfx	x0, x5, #8, #8
    e5a4:      	cmp	x0, #0x0
    e5a8:      	b.ne	0xe5bc <_stogir.stack.constant-size+0x218>
    e5ac:      	movz	x4, #0x0, lsl #48
    e5b0:      	b	0xe514 <_stogir.stack.constant-size+0x170>
    e5b4:      	movz	x5, #0x0, lsl #48
    e5b8:      	b	0xe474 <_stogir.stack.constant-size+0xd0>
    e5bc:      	cmp	x0, #0x1
    e5c0:      	b.eq	0xe510 <_stogir.stack.constant-size+0x16c>
    e5c4:      	cmp	x0, #0x2
    e5c8:      	b.eq	0xe510 <_stogir.stack.constant-size+0x16c>
    e5cc:      	cmp	x0, #0x7
    e5d0:      	b.eq	0xe510 <_stogir.stack.constant-size+0x16c>
    e5d4:      	cmp	x0, #0x8
    e5d8:      	b.eq	0xe510 <_stogir.stack.constant-size+0x16c>
    e5dc:      	cmp	x0, #0x3
    e5e0:      	b.eq	0xe6e8 <_stogir.stack.constant-size+0x344>
    e5e4:      	cmp	x0, #0x9
    e5e8:      	b.eq	0xe6e8 <_stogir.stack.constant-size+0x344>
    e5ec:      	cmp	x0, #0x4
    e5f0:      	b.eq	0xe6f8 <_stogir.stack.constant-size+0x354>
    e5f4:      	cmp	x0, #0xa
    e5f8:      	b.eq	0xe6f8 <_stogir.stack.constant-size+0x354>
    e5fc:      	cmp	x0, #0xd
    e600:      	b.eq	0xe6f8 <_stogir.stack.constant-size+0x354>
    e604:      	cmp	x0, #0x5
    e608:      	b.eq	0xe700 <_stogir.stack.constant-size+0x35c>
    e60c:      	cmp	x0, #0xb
    e610:      	b.eq	0xe700 <_stogir.stack.constant-size+0x35c>
    e614:      	cmp	x0, #0xc
    e618:      	b.eq	0xe700 <_stogir.stack.constant-size+0x35c>
    e61c:      	cmp	x0, #0x6
    e620:      	cset	w4, eq
    e624:      	uxtb	w16, w4
    e628:      	cmp	w16, wzr
    e62c:      	mov	x16, #0x8               ; =8
    e630:      	movn	x17, #0x0, lsl #48
    e634:      	csel	x4, x16, x17, ne
    e638:      	b	0xe704 <_stogir.stack.constant-size+0x360>
    e63c:      	movz	x5, #0x0, lsl #48
    e640:      	b	0xe46c <_stogir.stack.constant-size+0xc8>
    e644:      	lsr	w4, w4, #0
    e648:      	sxtw	x4, w4
    e64c:      	cmp	x4, #0x0
    e650:      	b.le	0xe55c <_stogir.stack.constant-size+0x1b8>
    e654:      	ubfx	x5, x5, #0, #32
    e658:      	ubfx	x6, x6, #0, #32
    e65c:      	lsl	x3, x6, #32
    e660:      	orr	x3, x3, x5
    e664:      	cmp	x4, #0x8
    e668:      	b.ge	0xe684 <_stogir.stack.constant-size+0x2e0>
    e66c:      	lsl	x5, x4, #3
    e670:      	lsr	w5, w5, #0
    e674:      	sxtw	x5, w5
    e678:      	lsr	x5, x3, x5
    e67c:      	cmp	x5, #0x0
    e680:      	b.ne	0xe55c <_stogir.stack.constant-size+0x1b8>
    e684:      	cmp	x0, #0x7
    e688:      	b.lt	0xe6c4 <_stogir.stack.constant-size+0x320>
    e68c:      	uxtb	w16, w1
    e690:      	cmp	w16, wzr
    e694:      	b.eq	0xe6c4 <_stogir.stack.constant-size+0x320>
    e698:      	lsl	x0, x4, #3
    e69c:      	lsr	w0, w0, #0
    e6a0:      	sxtw	x0, w0
    e6a4:      	sub	x0, x0, #0x1
    e6a8:      	lsr	w0, w0, #0
    e6ac:      	sxtw	x0, w0
    e6b0:      	mov	x16, #0x1               ; =1
    e6b4:      	lsl	x0, x16, x0
    e6b8:      	and	x0, x0, x3
    e6bc:      	cmp	x0, #0x0
    e6c0:      	b.ne	0xe55c <_stogir.stack.constant-size+0x1b8>
    e6c4:      	mov	x17, #-0x10             ; =-16
    e6c8:      	movk	x17, #0x7fff, lsl #48
    e6cc:      	cmp	x3, x17
    e6d0:      	b.hi	0xe55c <_stogir.stack.constant-size+0x1b8>
    e6d4:      	add	x0, x3, #0xf
    e6d8:      	and	x0, x0, #0xfffffffffffffff0
    e6dc:      	movz	x1, #0x0, lsl #48
    e6e0:      	movz	x3, #0x0, lsl #48
    e6e4:      	b	0xe570 <_stogir.stack.constant-size+0x1cc>
    e6e8:      	mov	x4, #0x2                ; =2
    e6ec:      	b	0xe514 <_stogir.stack.constant-size+0x170>
    e6f0:      	brk	#0
    e6f4:      	b	0xe6f0 <_stogir.stack.constant-size+0x34c>
    e6f8:      	mov	x4, #0x4                ; =4
    e6fc:      	b	0xe6ec <_stogir.stack.constant-size+0x348>
    e700:      	mov	x4, #0x8                ; =8
    e704:      	b	0xe6fc <_stogir.stack.constant-size+0x358>

000000000000e708 <_stogir.frame.valid-alignment?>:
    e708:      	cmp	x0, #0x0
    e70c:      	b.le	0xe728 <_stogir.frame.valid-alignment?+0x20>
    e710:      	sub	x1, x0, #0x1
    e714:      	and	x0, x1, x0
    e718:      	cmp	x0, #0x0
    e71c:      	cset	w0, eq
    e720:      	ubfx	x0, x0, #0, #8
    e724:      	b	0xe72c <_stogir.frame.valid-alignment?+0x24>
    e728:      	movz	x0, #0x0, lsl #48
    e72c:      	ret

000000000000e730 <_stogir.stack.constant-size-aligned>:
    e730:      	sub	sp, sp, #0x10
    e734:      	cmp	x2, #0x10
    e738:      	b.lt	0xe7b4 <_stogir.stack.constant-size-aligned+0x84>
    e73c:      	cmp	x2, #0x0
    e740:      	b.le	0xe7b4 <_stogir.stack.constant-size-aligned+0x84>
    e744:      	sub	x3, x2, #0x1
    e748:      	and	x3, x3, x2
    e74c:      	cmp	x3, #0x0
    e750:      	b.ne	0xe7b4 <_stogir.stack.constant-size-aligned+0x84>
    e754:      	sxtw	x1, w1
    e758:      	cmp	x1, #0x0
    e75c:      	cset	w3, gt
    e760:      	movz	x16, #0x0, lsl #48
    e764:      	sub	x4, x16, x1
    e768:      	sub	x5, x4, #0x1
    e76c:      	uxtb	w16, w3
    e770:      	cmp	w16, wzr
    e774:      	b.eq	0xe84c <_stogir.stack.constant-size-aligned+0x11c>
    e778:      	ldr	x4, [x0, #0x8]
    e77c:      	cmp	x1, x4
    e780:      	b.ge	0xe894 <_stogir.stack.constant-size-aligned+0x164>
    e784:      	add	x4, x0, #0x78
    e788:      	ldr	x4, [x4, #0x8]
    e78c:      	cmp	x1, x4
    e790:      	b.ge	0xe964 <_stogir.stack.constant-size-aligned+0x234>
    e794:      	ldr	x4, [x0, #0x78]
    e798:      	add	x4, x4, x1, lsl #2
    e79c:      	ldr	w4, [x4]
    e7a0:      	sxtw	x4, w4
    e7a4:      	cmp	x4, #0x0
    e7a8:      	cset	w4, ge
    e7ac:      	ubfx	x4, x4, #0, #8
    e7b0:      	b	0xe968 <_stogir.stack.constant-size-aligned+0x238>
    e7b4:      	adrp	x16, 0xe000 <_stogir.switch.key+0x48c>
		000000000000e7b4:  ARM64_RELOC_PAGE21	l_stogir.516
    e7b8:      	ldr	x16, [x16]
		000000000000e7b8:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    e7bc:      	orr	x0, x16, xzr
    e7c0:      	mov	x1, #0x1                ; =1
    e7c4:      	mov	x2, #0x20               ; =32
    e7c8:      	str	x1, [x8]
    e7cc:      	str	x0, [x8, #0x8]
    e7d0:      	str	x2, [x8, #0x10]
    e7d4:      	add	sp, sp, #0x10
    e7d8:      	ret
    e7dc:      	mov	x3, #0x1                ; =1
    e7e0:      	mov	x16, sp
    e7e4:      	ldr	w4, [x16, #0x8]
    e7e8:      	mov	x16, sp
    e7ec:      	ldr	w5, [x16, #0xc]
    e7f0:      	cmp	x1, #0x0
    e7f4:      	b.ge	0xe834 <_stogir.stack.constant-size-aligned+0x104>
    e7f8:      	cmp	x0, #0x1
    e7fc:      	b.lt	0xe834 <_stogir.stack.constant-size-aligned+0x104>
    e800:      	cmp	x0, #0xb
    e804:      	cset	w1, le
    e808:      	uxtb	w16, w1
    e80c:      	cmp	w16, wzr
    e810:      	b.eq	0xe834 <_stogir.stack.constant-size-aligned+0x104>
    e814:      	mov	x16, sp
    e818:      	ldr	w6, [x16]
    e81c:      	uxtb	w7, w6
    e820:      	ubfx	x6, x6, #8, #8
    e824:      	cmp	x7, x6
    e828:      	b.eq	0xe9f4 <_stogir.stack.constant-size-aligned+0x2c4>
    e82c:      	cmp	x7, #0x49
    e830:      	b.eq	0xe9f4 <_stogir.stack.constant-size-aligned+0x2c4>
    e834:      	adrp	x16, 0xe000 <_stogir.switch.key+0x48c>
		000000000000e834:  ARM64_RELOC_PAGE21	l_stogir.517
    e838:      	ldr	x16, [x16]
		000000000000e838:  ARM64_RELOC_PAGEOFF12	l_stogir.517
    e83c:      	orr	x0, x16, xzr
    e840:      	mov	x1, #0x1                ; =1
    e844:      	mov	x2, #0x30               ; =48
    e848:      	b	0xe7c8 <_stogir.stack.constant-size-aligned+0x98>
    e84c:      	cmp	x1, #0x0
    e850:      	b.ge	0xe89c <_stogir.stack.constant-size-aligned+0x16c>
    e854:      	add	x6, x0, #0x28
    e858:      	add	x7, x0, #0x50
    e85c:      	ldr	x6, [x6, #0x8]
    e860:      	ldr	x7, [x7, #0x8]
    e864:      	cmp	x6, x7
    e868:      	b.ne	0xe95c <_stogir.stack.constant-size-aligned+0x22c>
    e86c:      	cmp	x4, x6
    e870:      	b.gt	0xe9ec <_stogir.stack.constant-size-aligned+0x2bc>
    e874:      	ldr	x4, [x0, #0x50]
    e878:      	add	x4, x4, x5, lsl #2
    e87c:      	ldr	w4, [x4]
    e880:      	sxtw	x4, w4
    e884:      	cmp	x4, #0x0
    e888:      	cset	w4, gt
    e88c:      	ubfx	x4, x4, #0, #8
    e890:      	b	0xe9f0 <_stogir.stack.constant-size-aligned+0x2c0>
    e894:      	movz	x4, #0x0, lsl #48
    e898:      	b	0xe8a0 <_stogir.stack.constant-size-aligned+0x170>
    e89c:      	movz	x4, #0x0, lsl #48
    e8a0:      	cmp	x4, #0x0
    e8a4:      	b.eq	0xe8e0 <_stogir.stack.constant-size-aligned+0x1b0>
    e8a8:      	uxtb	w16, w3
    e8ac:      	cmp	w16, wzr
    e8b0:      	b.eq	0xe8c8 <_stogir.stack.constant-size-aligned+0x198>
    e8b4:      	ldr	x0, [x0]
    e8b8:      	add	x0, x0, x1, lsl #4
    e8bc:      	ldr	x3, [x0]
    e8c0:      	ldr	x0, [x0, #0x8]
    e8c4:      	b	0xe8d8 <_stogir.stack.constant-size-aligned+0x1a8>
    e8c8:      	ldr	x0, [x0, #0x28]
    e8cc:      	add	x0, x0, x5, lsl #4
    e8d0:      	ldr	x3, [x0]
    e8d4:      	ldr	x0, [x0, #0x8]
    e8d8:      	mov	x4, #0x1                ; =1
    e8dc:      	b	0xe8ec <_stogir.stack.constant-size-aligned+0x1bc>
    e8e0:      	movz	x4, #0x0, lsl #48
    e8e4:      	movz	x3, #0x0, lsl #48
    e8e8:      	movz	x0, #0x0, lsl #48
    e8ec:      	lsr	w4, w4, #0
    e8f0:      	lsr	x16, x4, #0
    e8f4:      	cmp	x16, #0x1
    e8f8:      	b.eq	0xe914 <_stogir.stack.constant-size-aligned+0x1e4>
    e8fc:      	b.lo	0xe904 <_stogir.stack.constant-size-aligned+0x1d4>
    e900:      	b	0xe918 <_stogir.stack.constant-size-aligned+0x1e8>
    e904:      	cmp	x16, #0x0
    e908:      	b.eq	0xe910 <_stogir.stack.constant-size-aligned+0x1e0>
    e90c:      	b	0xe918 <_stogir.stack.constant-size-aligned+0x1e8>
    e910:      	b	0xe91c <_stogir.stack.constant-size-aligned+0x1ec>
    e914:      	b	0xe934 <_stogir.stack.constant-size-aligned+0x204>
    e918:      	b	0xeab0 <_stogir.stack.constant-size-aligned+0x380>
    e91c:      	adrp	x16, 0xe000 <_stogir.switch.key+0x48c>
		000000000000e91c:  ARM64_RELOC_PAGE21	l_stogir.518
    e920:      	ldr	x16, [x16]
		000000000000e920:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    e924:      	orr	x0, x16, xzr
    e928:      	mov	x1, #0x1                ; =1
    e92c:      	mov	x2, #0x18               ; =24
    e930:      	b	0xe848 <_stogir.stack.constant-size-aligned+0x118>
    e934:      	lsr	w4, w3, #0
    e938:      	mov	x16, sp
    e93c:      	str	x3, [x16]
    e940:      	mov	x16, sp
    e944:      	str	x0, [x16, #0x8]
    e948:      	ubfx	x0, x4, #8, #8
    e94c:      	cmp	x0, #0x0
    e950:      	b.ne	0xe96c <_stogir.stack.constant-size-aligned+0x23c>
    e954:      	movz	x3, #0x0, lsl #48
    e958:      	b	0xe7e0 <_stogir.stack.constant-size-aligned+0xb0>
    e95c:      	movz	x4, #0x0, lsl #48
    e960:      	b	0xe8a0 <_stogir.stack.constant-size-aligned+0x170>
    e964:      	movz	x4, #0x0, lsl #48
    e968:      	b	0xe898 <_stogir.stack.constant-size-aligned+0x168>
    e96c:      	cmp	x0, #0x1
    e970:      	b.eq	0xe7dc <_stogir.stack.constant-size-aligned+0xac>
    e974:      	cmp	x0, #0x2
    e978:      	b.eq	0xe7dc <_stogir.stack.constant-size-aligned+0xac>
    e97c:      	cmp	x0, #0x7
    e980:      	b.eq	0xe7dc <_stogir.stack.constant-size-aligned+0xac>
    e984:      	cmp	x0, #0x8
    e988:      	b.eq	0xe7dc <_stogir.stack.constant-size-aligned+0xac>
    e98c:      	cmp	x0, #0x3
    e990:      	b.eq	0xeaa8 <_stogir.stack.constant-size-aligned+0x378>
    e994:      	cmp	x0, #0x9
    e998:      	b.eq	0xeaa8 <_stogir.stack.constant-size-aligned+0x378>
    e99c:      	cmp	x0, #0x4
    e9a0:      	b.eq	0xeab8 <_stogir.stack.constant-size-aligned+0x388>
    e9a4:      	cmp	x0, #0xa
    e9a8:      	b.eq	0xeab8 <_stogir.stack.constant-size-aligned+0x388>
    e9ac:      	cmp	x0, #0xd
    e9b0:      	b.eq	0xeab8 <_stogir.stack.constant-size-aligned+0x388>
    e9b4:      	cmp	x0, #0x5
    e9b8:      	b.eq	0xeac0 <_stogir.stack.constant-size-aligned+0x390>
    e9bc:      	cmp	x0, #0xb
    e9c0:      	b.eq	0xeac0 <_stogir.stack.constant-size-aligned+0x390>
    e9c4:      	cmp	x0, #0xc
    e9c8:      	b.eq	0xeac0 <_stogir.stack.constant-size-aligned+0x390>
    e9cc:      	cmp	x0, #0x6
    e9d0:      	cset	w3, eq
    e9d4:      	uxtb	w16, w3
    e9d8:      	cmp	w16, wzr
    e9dc:      	mov	x16, #0x8               ; =8
    e9e0:      	movn	x17, #0x0, lsl #48
    e9e4:      	csel	x3, x16, x17, ne
    e9e8:      	b	0xeac4 <_stogir.stack.constant-size-aligned+0x394>
    e9ec:      	movz	x4, #0x0, lsl #48
    e9f0:      	b	0xe960 <_stogir.stack.constant-size-aligned+0x230>
    e9f4:      	lsr	w3, w3, #0
    e9f8:      	sxtw	x3, w3
    e9fc:      	cmp	x3, #0x0
    ea00:      	b.le	0xe834 <_stogir.stack.constant-size-aligned+0x104>
    ea04:      	ubfx	x4, x4, #0, #32
    ea08:      	ubfx	x5, x5, #0, #32
    ea0c:      	lsl	x5, x5, #32
    ea10:      	orr	x4, x5, x4
    ea14:      	cmp	x3, #0x8
    ea18:      	b.ge	0xea34 <_stogir.stack.constant-size-aligned+0x304>
    ea1c:      	lsl	x5, x3, #3
    ea20:      	lsr	w5, w5, #0
    ea24:      	sxtw	x5, w5
    ea28:      	lsr	x5, x4, x5
    ea2c:      	cmp	x5, #0x0
    ea30:      	b.ne	0xe834 <_stogir.stack.constant-size-aligned+0x104>
    ea34:      	cmp	x0, #0x7
    ea38:      	b.lt	0xea74 <_stogir.stack.constant-size-aligned+0x344>
    ea3c:      	uxtb	w16, w1
    ea40:      	cmp	w16, wzr
    ea44:      	b.eq	0xea74 <_stogir.stack.constant-size-aligned+0x344>
    ea48:      	lsl	x0, x3, #3
    ea4c:      	lsr	w0, w0, #0
    ea50:      	sxtw	x0, w0
    ea54:      	sub	x0, x0, #0x1
    ea58:      	lsr	w0, w0, #0
    ea5c:      	sxtw	x0, w0
    ea60:      	mov	x16, #0x1               ; =1
    ea64:      	lsl	x0, x16, x0
    ea68:      	and	x0, x0, x4
    ea6c:      	cmp	x0, #0x0
    ea70:      	b.ne	0xe834 <_stogir.stack.constant-size-aligned+0x104>
    ea74:      	sub	x0, x2, #0x1
    ea78:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    ea7c:      	sub	x0, x16, x0
    ea80:      	cmp	x4, x0
    ea84:      	b.hi	0xe834 <_stogir.stack.constant-size-aligned+0x104>
    ea88:      	sub	x0, x2, #0x1
    ea8c:      	movz	x16, #0x0, lsl #48
    ea90:      	sub	x1, x16, x2
    ea94:      	add	x0, x0, x4
    ea98:      	and	x0, x1, x0
    ea9c:      	movz	x1, #0x0, lsl #48
    eaa0:      	movz	x2, #0x0, lsl #48
    eaa4:      	b	0xe848 <_stogir.stack.constant-size-aligned+0x118>
    eaa8:      	mov	x3, #0x2                ; =2
    eaac:      	b	0xe7e0 <_stogir.stack.constant-size-aligned+0xb0>
    eab0:      	brk	#0
    eab4:      	b	0xeab0 <_stogir.stack.constant-size-aligned+0x380>
    eab8:      	mov	x3, #0x4                ; =4
    eabc:      	b	0xeaac <_stogir.stack.constant-size-aligned+0x37c>
    eac0:      	mov	x3, #0x8                ; =8
    eac4:      	b	0xeabc <_stogir.stack.constant-size-aligned+0x38c>

000000000000eac8 <_stogir.numeric-conversion.operation?>:
    eac8:      	sxtw	x0, w0
    eacc:      	cmp	x0, #0x25
    ead0:      	b.lt	0xeae4 <_stogir.numeric-conversion.operation?+0x1c>
    ead4:      	cmp	x0, #0x27
    ead8:      	cset	w0, le
    eadc:      	ubfx	x0, x0, #0, #8
    eae0:      	b	0xeae8 <_stogir.numeric-conversion.operation?+0x20>
    eae4:      	movz	x0, #0x0, lsl #48
    eae8:      	ret

000000000000eaec <_stogir.numeric-conversion.valid-types?>:
    eaec:      	sxtw	x0, w0
    eaf0:      	sxtw	x1, w1
    eaf4:      	sxtw	x2, w2
    eaf8:      	cmp	x2, #0xc
    eafc:      	cset	w3, eq
    eb00:      	cmp	x2, #0xd
    eb04:      	cset	w4, eq
    eb08:      	ubfx	x4, x4, #0, #8
    eb0c:      	cmp	x0, #0x25
    eb10:      	b.ne	0xeb38 <_stogir.numeric-conversion.valid-types?+0x4c>
    eb14:      	cmp	x1, #0x1
    eb18:      	b.lt	0xeba0 <_stogir.numeric-conversion.valid-types?+0xb4>
    eb1c:      	cmp	x1, #0xb
    eb20:      	b.gt	0xeba0 <_stogir.numeric-conversion.valid-types?+0xb4>
    eb24:      	uxtb	w16, w3
    eb28:      	cmp	w16, wzr
    eb2c:      	b.eq	0xeb34 <_stogir.numeric-conversion.valid-types?+0x48>
    eb30:      	mov	x4, #0x1                ; =1
    eb34:      	b	0xeba4 <_stogir.numeric-conversion.valid-types?+0xb8>
    eb38:      	cmp	x1, #0xc
    eb3c:      	cset	w5, eq
    eb40:      	cmp	x1, #0xd
    eb44:      	cset	w1, eq
    eb48:      	cmp	x0, #0x26
    eb4c:      	b.ne	0xeb70 <_stogir.numeric-conversion.valid-types?+0x84>
    eb50:      	uxtb	w16, w5
    eb54:      	cmp	w16, wzr
    eb58:      	b.ne	0xebc8 <_stogir.numeric-conversion.valid-types?+0xdc>
    eb5c:      	uxtb	w16, w1
    eb60:      	cmp	w16, wzr
    eb64:      	b.ne	0xebc8 <_stogir.numeric-conversion.valid-types?+0xdc>
    eb68:      	movz	x4, #0x0, lsl #48
    eb6c:      	b	0xeb9c <_stogir.numeric-conversion.valid-types?+0xb0>
    eb70:      	cmp	x0, #0x27
    eb74:      	b.ne	0xeba8 <_stogir.numeric-conversion.valid-types?+0xbc>
    eb78:      	uxtb	w16, w5
    eb7c:      	cmp	w16, wzr
    eb80:      	b.ne	0xebb4 <_stogir.numeric-conversion.valid-types?+0xc8>
    eb84:      	uxtb	w16, w1
    eb88:      	cmp	w16, wzr
    eb8c:      	b.ne	0xebb4 <_stogir.numeric-conversion.valid-types?+0xc8>
    eb90:      	movz	x4, #0x0, lsl #48
    eb94:      	b	0xebc4 <_stogir.numeric-conversion.valid-types?+0xd8>
    eb98:      	movz	x4, #0x0, lsl #48
    eb9c:      	b	0xebac <_stogir.numeric-conversion.valid-types?+0xc0>
    eba0:      	movz	x4, #0x0, lsl #48
    eba4:      	b	0xebac <_stogir.numeric-conversion.valid-types?+0xc0>
    eba8:      	movz	x4, #0x0, lsl #48
    ebac:      	mov	x0, x4
    ebb0:      	ret
    ebb4:      	uxtb	w16, w3
    ebb8:      	cmp	w16, wzr
    ebbc:      	b.eq	0xebc4 <_stogir.numeric-conversion.valid-types?+0xd8>
    ebc0:      	mov	x4, #0x1                ; =1
    ebc4:      	b	0xebac <_stogir.numeric-conversion.valid-types?+0xc0>
    ebc8:      	cmp	x2, #0x1
    ebcc:      	b.lt	0xeb98 <_stogir.numeric-conversion.valid-types?+0xac>
    ebd0:      	cmp	x2, #0xb
    ebd4:      	cset	w0, le
    ebd8:      	ubfx	x4, x0, #0, #8
    ebdc:      	b	0xeb9c <_stogir.numeric-conversion.valid-types?+0xb0>

000000000000ebe0 <_inherent$slice$new__stogir.node.Node>:
    ebe0:      	sub	sp, sp, #0x10
    ebe4:      	mov	x2, sp
    ebe8:      	str	x0, [x2]
    ebec:      	str	x1, [x2, #0x8]
    ebf0:      	ldr	x0, [sp]
    ebf4:      	ldr	x1, [sp, #0x8]
    ebf8:      	add	sp, sp, #0x10
    ebfc:      	ret

000000000000ec00 <_inherent$slice$data__stogir.node.Node>:
    ec00:      	ret

000000000000ec04 <_coil.slice.element-ref__stogir.node.Node>:
    ec04:      	ret

000000000000ec08 <_stogir.vector-lanes.ordinary?>:
    ec08:      	ldr	w0, [x0]
    ec0c:      	uxtb	w0, w0
    ec10:      	cmp	x0, #0x48
    ec14:      	b.ne	0xec20 <_stogir.vector-lanes.ordinary?+0x18>
    ec18:      	movz	x0, #0x0, lsl #48
    ec1c:      	b	0xec34 <_stogir.vector-lanes.ordinary?+0x2c>
    ec20:      	cmp	x0, #0x46
    ec24:      	cset	w0, eq
    ec28:      	uxtb	w16, w0
    ec2c:      	cmp	w16, wzr
    ec30:      	cset	x0, eq
    ec34:      	ret

000000000000ec38 <_stogir.vector-lanes.compatible?>:
    ec38:      	sxtw	x0, w0
    ec3c:      	and	x3, x0, #0xf
    ec40:      	cmp	x0, #0xf
    ec44:      	cset	w4, gt
    ec48:      	cmp	x0, #0x80
    ec4c:      	cset	w5, lt
    ec50:      	lsr	w3, w3, #0
    ec54:      	sxtw	x3, w3
    ec58:      	cmp	x3, #0x1
    ec5c:      	cset	w6, ge
    ec60:      	cmp	x3, #0xd
    ec64:      	cset	w7, le
    ec68:      	cmp	x0, #0x0
    ec6c:      	b.lt	0xec78 <_stogir.vector-lanes.compatible?+0x40>
    ec70:      	cmp	x0, #0xd
    ec74:      	b.le	0xecac <_stogir.vector-lanes.compatible?+0x74>
    ec78:      	uxtb	w16, w4
    ec7c:      	cmp	w16, wzr
    ec80:      	b.eq	0xeca8 <_stogir.vector-lanes.compatible?+0x70>
    ec84:      	uxtb	w16, w5
    ec88:      	cmp	w16, wzr
    ec8c:      	b.eq	0xeca8 <_stogir.vector-lanes.compatible?+0x70>
    ec90:      	uxtb	w16, w6
    ec94:      	cmp	w16, wzr
    ec98:      	b.eq	0xeca8 <_stogir.vector-lanes.compatible?+0x70>
    ec9c:      	uxtb	w16, w7
    eca0:      	cmp	w16, wzr
    eca4:      	b.ne	0xecac <_stogir.vector-lanes.compatible?+0x74>
    eca8:      	movn	x3, #0x0, lsl #48
    ecac:      	uxtb	w16, w4
    ecb0:      	cmp	w16, wzr
    ecb4:      	b.eq	0xed10 <_stogir.vector-lanes.compatible?+0xd8>
    ecb8:      	uxtb	w16, w5
    ecbc:      	cmp	w16, wzr
    ecc0:      	b.eq	0xed10 <_stogir.vector-lanes.compatible?+0xd8>
    ecc4:      	uxtb	w16, w6
    ecc8:      	cmp	w16, wzr
    eccc:      	b.eq	0xed10 <_stogir.vector-lanes.compatible?+0xd8>
    ecd0:      	uxtb	w16, w7
    ecd4:      	cmp	w16, wzr
    ecd8:      	b.eq	0xed10 <_stogir.vector-lanes.compatible?+0xd8>
    ecdc:      	sxtw	x2, w2
    ece0:      	cmp	x2, #0x4
    ece4:      	cset	w0, eq
    ece8:      	cmp	x2, #0x8
    ecec:      	cset	w4, eq
    ecf0:      	uxtb	w16, w0
    ecf4:      	cmp	w16, wzr
    ecf8:      	b.ne	0xed20 <_stogir.vector-lanes.compatible?+0xe8>
    ecfc:      	uxtb	w16, w4
    ed00:      	cmp	w16, wzr
    ed04:      	b.ne	0xed20 <_stogir.vector-lanes.compatible?+0xe8>
    ed08:      	movz	x0, #0x0, lsl #48
    ed0c:      	b	0xed1c <_stogir.vector-lanes.compatible?+0xe4>
    ed10:      	movz	x0, #0x0, lsl #48
    ed14:      	ret
    ed18:      	movz	x0, #0x0, lsl #48
    ed1c:      	b	0xed14 <_stogir.vector-lanes.compatible?+0xdc>
    ed20:      	sxtw	x1, w1
    ed24:      	cmp	x1, #0x0
    ed28:      	b.lt	0xed18 <_stogir.vector-lanes.compatible?+0xe0>
    ed2c:      	cmp	x1, #0xd
    ed30:      	b.gt	0xed18 <_stogir.vector-lanes.compatible?+0xe0>
    ed34:      	cmp	x1, #0x0
    ed38:      	b.le	0xed54 <_stogir.vector-lanes.compatible?+0x11c>
    ed3c:      	lsr	w3, w3, #0
    ed40:      	sxtw	x3, w3
    ed44:      	cmp	x3, x1
    ed48:      	b.ne	0xed5c <_stogir.vector-lanes.compatible?+0x124>
    ed4c:      	mov	x0, #0x1                ; =1
    ed50:      	b	0xed58 <_stogir.vector-lanes.compatible?+0x120>
    ed54:      	movz	x0, #0x0, lsl #48
    ed58:      	b	0xed1c <_stogir.vector-lanes.compatible?+0xe4>
    ed5c:      	cmp	x3, #0x1
    ed60:      	b.lt	0xed9c <_stogir.vector-lanes.compatible?+0x164>
    ed64:      	cmp	x3, #0xb
    ed68:      	b.gt	0xed9c <_stogir.vector-lanes.compatible?+0x164>
    ed6c:      	cmp	x1, #0x1
    ed70:      	b.lt	0xeda4 <_stogir.vector-lanes.compatible?+0x16c>
    ed74:      	cmp	x1, #0xb
    ed78:      	b.gt	0xeda4 <_stogir.vector-lanes.compatible?+0x16c>
    ed7c:      	uxtb	w16, w0
    ed80:      	cmp	w16, wzr
    ed84:      	b.ne	0xedd0 <_stogir.vector-lanes.compatible?+0x198>
    ed88:      	uxtb	w16, w4
    ed8c:      	cmp	w16, wzr
    ed90:      	b.ne	0xedd0 <_stogir.vector-lanes.compatible?+0x198>
    ed94:      	movn	x3, #0x0, lsl #48
    ed98:      	b	0xede4 <_stogir.vector-lanes.compatible?+0x1ac>
    ed9c:      	movz	x0, #0x0, lsl #48
    eda0:      	b	0xed50 <_stogir.vector-lanes.compatible?+0x118>
    eda4:      	movz	x0, #0x0, lsl #48
    eda8:      	b	0xeda0 <_stogir.vector-lanes.compatible?+0x168>
    edac:      	mov	x2, #0x1                ; =1
    edb0:      	lsr	w3, w3, #0
    edb4:      	sxtw	x3, w3
    edb8:      	lsr	w2, w2, #0
    edbc:      	sxtw	x2, w2
    edc0:      	cmp	x3, x2
    edc4:      	cset	w0, eq
    edc8:      	ubfx	x0, x0, #0, #8
    edcc:      	b	0xeda8 <_stogir.vector-lanes.compatible?+0x170>
    edd0:      	cmp	x3, #0x0
    edd4:      	b.ne	0xee84 <_stogir.vector-lanes.compatible?+0x24c>
    edd8:      	movz	x3, #0x0, lsl #48
    eddc:      	b	0xede4 <_stogir.vector-lanes.compatible?+0x1ac>
    ede0:      	mov	x3, #0x1                ; =1
    ede4:      	uxtb	w16, w0
    ede8:      	cmp	w16, wzr
    edec:      	b.ne	0xee04 <_stogir.vector-lanes.compatible?+0x1cc>
    edf0:      	uxtb	w16, w4
    edf4:      	cmp	w16, wzr
    edf8:      	b.ne	0xee04 <_stogir.vector-lanes.compatible?+0x1cc>
    edfc:      	movn	x2, #0x0, lsl #48
    ee00:      	b	0xedb0 <_stogir.vector-lanes.compatible?+0x178>
    ee04:      	cmp	x1, #0x0
    ee08:      	b.ne	0xee14 <_stogir.vector-lanes.compatible?+0x1dc>
    ee0c:      	movz	x2, #0x0, lsl #48
    ee10:      	b	0xedb0 <_stogir.vector-lanes.compatible?+0x178>
    ee14:      	cmp	x1, #0x1
    ee18:      	b.eq	0xedac <_stogir.vector-lanes.compatible?+0x174>
    ee1c:      	cmp	x1, #0x2
    ee20:      	b.eq	0xedac <_stogir.vector-lanes.compatible?+0x174>
    ee24:      	cmp	x1, #0x7
    ee28:      	b.eq	0xedac <_stogir.vector-lanes.compatible?+0x174>
    ee2c:      	cmp	x1, #0x8
    ee30:      	b.eq	0xedac <_stogir.vector-lanes.compatible?+0x174>
    ee34:      	cmp	x1, #0x3
    ee38:      	b.eq	0xeef4 <_stogir.vector-lanes.compatible?+0x2bc>
    ee3c:      	cmp	x1, #0x9
    ee40:      	b.eq	0xeef4 <_stogir.vector-lanes.compatible?+0x2bc>
    ee44:      	cmp	x1, #0x4
    ee48:      	b.eq	0xef04 <_stogir.vector-lanes.compatible?+0x2cc>
    ee4c:      	cmp	x1, #0xa
    ee50:      	b.eq	0xef04 <_stogir.vector-lanes.compatible?+0x2cc>
    ee54:      	cmp	x1, #0xd
    ee58:      	b.eq	0xef04 <_stogir.vector-lanes.compatible?+0x2cc>
    ee5c:      	cmp	x1, #0x5
    ee60:      	b.eq	0xef14 <_stogir.vector-lanes.compatible?+0x2dc>
    ee64:      	cmp	x1, #0xb
    ee68:      	b.eq	0xef14 <_stogir.vector-lanes.compatible?+0x2dc>
    ee6c:      	cmp	x1, #0xc
    ee70:      	b.eq	0xef14 <_stogir.vector-lanes.compatible?+0x2dc>
    ee74:      	cmp	x1, #0x6
    ee78:      	b.eq	0xee80 <_stogir.vector-lanes.compatible?+0x248>
    ee7c:      	movn	x2, #0x0, lsl #48
    ee80:      	b	0xef18 <_stogir.vector-lanes.compatible?+0x2e0>
    ee84:      	cmp	x3, #0x1
    ee88:      	b.eq	0xede0 <_stogir.vector-lanes.compatible?+0x1a8>
    ee8c:      	cmp	x3, #0x2
    ee90:      	b.eq	0xede0 <_stogir.vector-lanes.compatible?+0x1a8>
    ee94:      	cmp	x3, #0x7
    ee98:      	b.eq	0xede0 <_stogir.vector-lanes.compatible?+0x1a8>
    ee9c:      	cmp	x3, #0x8
    eea0:      	b.eq	0xede0 <_stogir.vector-lanes.compatible?+0x1a8>
    eea4:      	cmp	x3, #0x3
    eea8:      	b.eq	0xeefc <_stogir.vector-lanes.compatible?+0x2c4>
    eeac:      	cmp	x3, #0x9
    eeb0:      	b.eq	0xeefc <_stogir.vector-lanes.compatible?+0x2c4>
    eeb4:      	cmp	x3, #0x4
    eeb8:      	b.eq	0xef0c <_stogir.vector-lanes.compatible?+0x2d4>
    eebc:      	cmp	x3, #0xa
    eec0:      	b.eq	0xef0c <_stogir.vector-lanes.compatible?+0x2d4>
    eec4:      	cmp	x3, #0xd
    eec8:      	b.eq	0xef0c <_stogir.vector-lanes.compatible?+0x2d4>
    eecc:      	cmp	x3, #0x5
    eed0:      	b.eq	0xef1c <_stogir.vector-lanes.compatible?+0x2e4>
    eed4:      	cmp	x3, #0xb
    eed8:      	b.eq	0xef1c <_stogir.vector-lanes.compatible?+0x2e4>
    eedc:      	cmp	x3, #0xc
    eee0:      	b.eq	0xef1c <_stogir.vector-lanes.compatible?+0x2e4>
    eee4:      	cmp	x3, #0x6
    eee8:      	b.ne	0xef24 <_stogir.vector-lanes.compatible?+0x2ec>
    eeec:      	mov	x3, x2
    eef0:      	b	0xef28 <_stogir.vector-lanes.compatible?+0x2f0>
    eef4:      	mov	x2, #0x2                ; =2
    eef8:      	b	0xedb0 <_stogir.vector-lanes.compatible?+0x178>
    eefc:      	mov	x3, #0x2                ; =2
    ef00:      	b	0xede4 <_stogir.vector-lanes.compatible?+0x1ac>
    ef04:      	mov	x2, #0x4                ; =4
    ef08:      	b	0xeef8 <_stogir.vector-lanes.compatible?+0x2c0>
    ef0c:      	mov	x3, #0x4                ; =4
    ef10:      	b	0xef00 <_stogir.vector-lanes.compatible?+0x2c8>
    ef14:      	mov	x2, #0x8                ; =8
    ef18:      	b	0xef08 <_stogir.vector-lanes.compatible?+0x2d0>
    ef1c:      	mov	x3, #0x8                ; =8
    ef20:      	b	0xef10 <_stogir.vector-lanes.compatible?+0x2d8>
    ef24:      	movn	x3, #0x0, lsl #48
    ef28:      	b	0xef20 <_stogir.vector-lanes.compatible?+0x2e8>

000000000000ef2c <_stogir.symbols.numeric?>:
    ef2c:      	ldr	w0, [x0]
    ef30:      	uxtb	w1, w0
    ef34:      	ubfx	x0, x0, #8, #8
    ef38:      	cmp	x1, x0
    ef3c:      	b.ne	0xef48 <_stogir.symbols.numeric?+0x1c>
    ef40:      	mov	x0, #0x1                ; =1
    ef44:      	b	0xef54 <_stogir.symbols.numeric?+0x28>
    ef48:      	cmp	x1, #0x49
    ef4c:      	cset	w0, eq
    ef50:      	ubfx	x0, x0, #0, #8
    ef54:      	ret

000000000000ef58 <_stogir.node.constant-bits>:
    ef58:      	ldr	w1, [x0, #0x8]
    ef5c:      	ubfx	x1, x1, #0, #32
    ef60:      	ldr	w0, [x0, #0xc]
    ef64:      	ubfx	x0, x0, #0, #32
    ef68:      	lsl	x0, x0, #32
    ef6c:      	orr	x0, x0, x1
    ef70:      	ret

000000000000ef74 <_stogir.vector-comparison.valid-type?>:
    ef74:      	sxtw	x0, w0
    ef78:      	cmp	x0, #0xe
    ef7c:      	b.lt	0xf018 <_stogir.vector-comparison.valid-type?+0xa4>
    ef80:      	cmp	x0, #0x19
    ef84:      	b.gt	0xf018 <_stogir.vector-comparison.valid-type?+0xa4>
    ef88:      	sxtw	x1, w1
    ef8c:      	cmp	x1, #0xf
    ef90:      	cset	w2, gt
    ef94:      	uxtb	w16, w2
    ef98:      	cmp	w16, wzr
    ef9c:      	b.eq	0xf020 <_stogir.vector-comparison.valid-type?+0xac>
    efa0:      	cmp	x1, #0x80
    efa4:      	cset	w3, lt
    efa8:      	uxtb	w16, w3
    efac:      	cmp	w16, wzr
    efb0:      	b.eq	0xf020 <_stogir.vector-comparison.valid-type?+0xac>
    efb4:      	and	x4, x1, #0xf
    efb8:      	lsr	w4, w4, #0
    efbc:      	sxtw	x4, w4
    efc0:      	cmp	x4, #0x1
    efc4:      	cset	w5, ge
    efc8:      	uxtb	w16, w5
    efcc:      	cmp	w16, wzr
    efd0:      	b.eq	0xf020 <_stogir.vector-comparison.valid-type?+0xac>
    efd4:      	cmp	x4, #0xd
    efd8:      	cset	w6, le
    efdc:      	uxtb	w16, w6
    efe0:      	cmp	w16, wzr
    efe4:      	b.eq	0xf020 <_stogir.vector-comparison.valid-type?+0xac>
    efe8:      	cmp	x1, #0x0
    efec:      	cset	w7, ge
    eff0:      	cmp	x1, #0xd
    eff4:      	cset	w1, le
    eff8:      	uxtb	w16, w7
    effc:      	cmp	w16, wzr
    f000:      	b.eq	0xf030 <_stogir.vector-comparison.valid-type?+0xbc>
    f004:      	uxtb	w16, w1
    f008:      	cmp	w16, wzr
    f00c:      	b.eq	0xf030 <_stogir.vector-comparison.valid-type?+0xbc>
    f010:      	mov	x8, x4
    f014:      	b	0xf064 <_stogir.vector-comparison.valid-type?+0xf0>
    f018:      	movz	x0, #0x0, lsl #48
    f01c:      	ret
    f020:      	movz	x0, #0x0, lsl #48
    f024:      	b	0xf01c <_stogir.vector-comparison.valid-type?+0xa8>
    f028:      	mov	x0, #0x1                ; =1
    f02c:      	b	0xf024 <_stogir.vector-comparison.valid-type?+0xb0>
    f030:      	uxtb	w16, w2
    f034:      	cmp	w16, wzr
    f038:      	b.eq	0xf060 <_stogir.vector-comparison.valid-type?+0xec>
    f03c:      	uxtb	w16, w3
    f040:      	cmp	w16, wzr
    f044:      	b.eq	0xf060 <_stogir.vector-comparison.valid-type?+0xec>
    f048:      	uxtb	w16, w5
    f04c:      	cmp	w16, wzr
    f050:      	b.eq	0xf060 <_stogir.vector-comparison.valid-type?+0xec>
    f054:      	uxtb	w16, w6
    f058:      	cmp	w16, wzr
    f05c:      	b.ne	0xf010 <_stogir.vector-comparison.valid-type?+0x9c>
    f060:      	movn	x8, #0x0, lsl #48
    f064:      	lsr	w8, w8, #0
    f068:      	sxtw	x8, w8
    f06c:      	cmp	x8, #0xc
    f070:      	b.eq	0xf028 <_stogir.vector-comparison.valid-type?+0xb4>
    f074:      	cmp	x8, #0xd
    f078:      	b.eq	0xf028 <_stogir.vector-comparison.valid-type?+0xb4>
    f07c:      	uxtb	w16, w7
    f080:      	cmp	w16, wzr
    f084:      	b.eq	0xf094 <_stogir.vector-comparison.valid-type?+0x120>
    f088:      	uxtb	w16, w1
    f08c:      	cmp	w16, wzr
    f090:      	b.ne	0xf0c8 <_stogir.vector-comparison.valid-type?+0x154>
    f094:      	uxtb	w16, w2
    f098:      	cmp	w16, wzr
    f09c:      	b.eq	0xf0c4 <_stogir.vector-comparison.valid-type?+0x150>
    f0a0:      	uxtb	w16, w3
    f0a4:      	cmp	w16, wzr
    f0a8:      	b.eq	0xf0c4 <_stogir.vector-comparison.valid-type?+0x150>
    f0ac:      	uxtb	w16, w5
    f0b0:      	cmp	w16, wzr
    f0b4:      	b.eq	0xf0c4 <_stogir.vector-comparison.valid-type?+0x150>
    f0b8:      	uxtb	w16, w6
    f0bc:      	cmp	w16, wzr
    f0c0:      	b.ne	0xf0c8 <_stogir.vector-comparison.valid-type?+0x154>
    f0c4:      	movn	x4, #0x0, lsl #48
    f0c8:      	lsr	w4, w4, #0
    f0cc:      	sxtw	x4, w4
    f0d0:      	cmp	x4, #0x1
    f0d4:      	b.lt	0xf0f0 <_stogir.vector-comparison.valid-type?+0x17c>
    f0d8:      	cmp	x4, #0xb
    f0dc:      	b.gt	0xf0f0 <_stogir.vector-comparison.valid-type?+0x17c>
    f0e0:      	cmp	x0, #0x17
    f0e4:      	cset	w0, le
    f0e8:      	ubfx	x0, x0, #0, #8
    f0ec:      	b	0xf0f4 <_stogir.vector-comparison.valid-type?+0x180>
    f0f0:      	movz	x0, #0x0, lsl #48
    f0f4:      	b	0xf02c <_stogir.vector-comparison.valid-type?+0xb8>

000000000000f0f8 <_stogir.vector-arithmetic.extrema?>:
    f0f8:      	sxtw	x0, w0
    f0fc:      	cmp	x0, #0x3a
    f100:      	b.ne	0xf10c <_stogir.vector-arithmetic.extrema?+0x14>
    f104:      	mov	x0, #0x1                ; =1
    f108:      	b	0xf118 <_stogir.vector-arithmetic.extrema?+0x20>
    f10c:      	cmp	x0, #0x3b
    f110:      	cset	w0, eq
    f114:      	ubfx	x0, x0, #0, #8
    f118:      	ret

000000000000f11c <_stogir.vector-arithmetic.shift?>:
    f11c:      	sxtw	x0, w0
    f120:      	cmp	x0, #0x31
    f124:      	b.lt	0xf138 <_stogir.vector-arithmetic.shift?+0x1c>
    f128:      	cmp	x0, #0x35
    f12c:      	cset	w0, le
    f130:      	ubfx	x0, x0, #0, #8
    f134:      	b	0xf13c <_stogir.vector-arithmetic.shift?+0x20>
    f138:      	movz	x0, #0x0, lsl #48
    f13c:      	ret

000000000000f140 <_stogir.vector-arithmetic.valid-type?>:
    f140:      	sub	sp, sp, #0x30
    f144:      	str	x29, [sp]
    f148:      	str	x30, [sp, #0x8]
    f14c:      	mov	x29, sp
    f150:      	str	x19, [sp, #0x10]
    f154:      	str	x20, [sp, #0x18]
    f158:      	str	x21, [sp, #0x20]
    f15c:      	str	x22, [sp, #0x28]
    f160:      	sxtw	x1, w1
    f164:      	cmp	x1, #0xf
    f168:      	cset	w2, gt
    f16c:      	cmp	x1, #0x80
    f170:      	cset	w3, lt
    f174:      	and	x4, x1, #0xf
    f178:      	lsr	w4, w4, #0
    f17c:      	sxtw	x4, w4
    f180:      	cmp	x4, #0x1
    f184:      	cset	w5, ge
    f188:      	cmp	x4, #0xd
    f18c:      	cset	w6, le
    f190:      	cmp	x1, #0x0
    f194:      	b.lt	0xf1a0 <_stogir.vector-arithmetic.valid-type?+0x60>
    f198:      	cmp	x1, #0xd
    f19c:      	b.le	0xf1d4 <_stogir.vector-arithmetic.valid-type?+0x94>
    f1a0:      	uxtb	w16, w2
    f1a4:      	cmp	w16, wzr
    f1a8:      	b.eq	0xf1d0 <_stogir.vector-arithmetic.valid-type?+0x90>
    f1ac:      	uxtb	w16, w3
    f1b0:      	cmp	w16, wzr
    f1b4:      	b.eq	0xf1d0 <_stogir.vector-arithmetic.valid-type?+0x90>
    f1b8:      	uxtb	w16, w5
    f1bc:      	cmp	w16, wzr
    f1c0:      	b.eq	0xf1d0 <_stogir.vector-arithmetic.valid-type?+0x90>
    f1c4:      	uxtb	w16, w6
    f1c8:      	cmp	w16, wzr
    f1cc:      	b.ne	0xf1d4 <_stogir.vector-arithmetic.valid-type?+0x94>
    f1d0:      	movn	x4, #0x0, lsl #48
    f1d4:      	uxtb	w16, w2
    f1d8:      	cmp	w16, wzr
    f1dc:      	b.eq	0xf3c8 <_stogir.vector-arithmetic.valid-type?+0x288>
    f1e0:      	uxtb	w16, w3
    f1e4:      	cmp	w16, wzr
    f1e8:      	b.eq	0xf3c8 <_stogir.vector-arithmetic.valid-type?+0x288>
    f1ec:      	uxtb	w16, w5
    f1f0:      	cmp	w16, wzr
    f1f4:      	b.eq	0xf3c8 <_stogir.vector-arithmetic.valid-type?+0x288>
    f1f8:      	uxtb	w16, w6
    f1fc:      	cmp	w16, wzr
    f200:      	b.eq	0xf3c8 <_stogir.vector-arithmetic.valid-type?+0x288>
    f204:      	sxtw	x1, w0
    f208:      	cmp	x1, #0x1f
    f20c:      	cset	w19, eq
    f210:      	cmp	x1, #0x20
    f214:      	cset	w20, eq
    f218:      	cmp	x1, #0x2e
    f21c:      	cset	w2, eq
    f220:      	cmp	x1, #0x2f
    f224:      	cset	w3, eq
    f228:      	cmp	x1, #0x30
    f22c:      	cset	w5, eq
    f230:      	cmp	x1, #0x1e
    f234:      	cset	w6, eq
    f238:      	cmp	x1, #0x31
    f23c:      	cset	w7, ge
    f240:      	cmp	x1, #0x35
    f244:      	cset	w8, le
    f248:      	cmp	x1, #0x3a
    f24c:      	cset	w9, eq
    f250:      	cmp	x1, #0x3b
    f254:      	cset	w10, eq
    f258:      	cmp	x1, #0x2d
    f25c:      	cset	w11, eq
    f260:      	cmp	x1, #0x36
    f264:      	cset	w12, eq
    f268:      	cmp	x1, #0x37
    f26c:      	cset	w13, eq
    f270:      	cmp	x1, #0x38
    f274:      	cset	w14, eq
    f278:      	cmp	x1, #0x39
    f27c:      	cset	w15, eq
    f280:      	uxtb	w16, w19
    f284:      	cmp	w16, wzr
    f288:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f28c:      	uxtb	w16, w20
    f290:      	cmp	w16, wzr
    f294:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f298:      	uxtb	w16, w11
    f29c:      	cmp	w16, wzr
    f2a0:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f2a4:      	uxtb	w16, w12
    f2a8:      	cmp	w16, wzr
    f2ac:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f2b0:      	uxtb	w16, w13
    f2b4:      	cmp	w16, wzr
    f2b8:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f2bc:      	uxtb	w16, w14
    f2c0:      	cmp	w16, wzr
    f2c4:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f2c8:      	uxtb	w16, w15
    f2cc:      	cmp	w16, wzr
    f2d0:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f2d4:      	uxtb	w16, w9
    f2d8:      	cmp	w16, wzr
    f2dc:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f2e0:      	uxtb	w16, w10
    f2e4:      	cmp	w16, wzr
    f2e8:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f2ec:      	uxtb	w16, w7
    f2f0:      	cmp	w16, wzr
    f2f4:      	b.eq	0xf4e0 <_stogir.vector-arithmetic.valid-type?+0x3a0>
    f2f8:      	uxtb	w16, w8
    f2fc:      	cmp	w16, wzr
    f300:      	b.eq	0xf4e0 <_stogir.vector-arithmetic.valid-type?+0x3a0>
    f304:      	lsr	w4, w4, #0
    f308:      	sxtw	x1, w4
    f30c:      	cmp	x1, #0xc
    f310:      	cset	w21, eq
    f314:      	cmp	x1, #0xd
    f318:      	cset	w22, eq
    f31c:      	uxtb	w16, w19
    f320:      	cmp	w16, wzr
    f324:      	b.ne	0xf3f4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    f328:      	uxtb	w16, w20
    f32c:      	cmp	w16, wzr
    f330:      	b.ne	0xf3f4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    f334:      	uxtb	w16, w11
    f338:      	cmp	w16, wzr
    f33c:      	b.ne	0xf3f4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    f340:      	uxtb	w16, w12
    f344:      	cmp	w16, wzr
    f348:      	b.ne	0xf3f4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    f34c:      	uxtb	w16, w13
    f350:      	cmp	w16, wzr
    f354:      	b.ne	0xf3f4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    f358:      	uxtb	w16, w14
    f35c:      	cmp	w16, wzr
    f360:      	b.ne	0xf3f4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    f364:      	uxtb	w16, w15
    f368:      	cmp	w16, wzr
    f36c:      	b.ne	0xf3f4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    f370:      	cmp	x1, #0x1
    f374:      	cset	w0, eq
    f378:      	cmp	x1, #0x1
    f37c:      	cset	w4, ge
    f380:      	cmp	x1, #0xb
    f384:      	cset	w1, le
    f388:      	uxtb	w16, w7
    f38c:      	cmp	w16, wzr
    f390:      	b.eq	0xf450 <_stogir.vector-arithmetic.valid-type?+0x310>
    f394:      	uxtb	w16, w8
    f398:      	cmp	w16, wzr
    f39c:      	b.eq	0xf450 <_stogir.vector-arithmetic.valid-type?+0x310>
    f3a0:      	uxtb	w16, w4
    f3a4:      	cmp	w16, wzr
    f3a8:      	b.eq	0xf4d8 <_stogir.vector-arithmetic.valid-type?+0x398>
    f3ac:      	uxtb	w16, w1
    f3b0:      	cmp	w16, wzr
    f3b4:      	b.eq	0xf4d8 <_stogir.vector-arithmetic.valid-type?+0x398>
    f3b8:      	uxtb	w16, w0
    f3bc:      	cmp	w16, wzr
    f3c0:      	cset	x0, eq
    f3c4:      	b	0xf4dc <_stogir.vector-arithmetic.valid-type?+0x39c>
    f3c8:      	movz	x0, #0x0, lsl #48
    f3cc:      	ldr	x19, [sp, #0x10]
    f3d0:      	ldr	x20, [sp, #0x18]
    f3d4:      	ldr	x21, [sp, #0x20]
    f3d8:      	ldr	x22, [sp, #0x28]
    f3dc:      	ldr	x29, [sp]
    f3e0:      	ldr	x30, [sp, #0x8]
    f3e4:      	add	sp, sp, #0x30
    f3e8:      	ret
    f3ec:      	ubfx	x0, x20, #0, #8
    f3f0:      	b	0xf3cc <_stogir.vector-arithmetic.valid-type?+0x28c>
    f3f4:      	lsr	w0, w0, #0
    f3f8:      	lsr	w4, w4, #0
    f3fc:      	mov	w1, w4
    f400:      	bl	0xf400 <_stogir.vector-arithmetic.valid-type?+0x2c0>
		000000000000f400:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    f404:      	cmp	x0, #0x0
    f408:      	b.eq	0xf414 <_stogir.vector-arithmetic.valid-type?+0x2d4>
    f40c:      	mov	x0, #0x1                ; =1
    f410:      	b	0xf3f0 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    f414:      	uxtb	w16, w21
    f418:      	cmp	w16, wzr
    f41c:      	b.ne	0xf434 <_stogir.vector-arithmetic.valid-type?+0x2f4>
    f420:      	uxtb	w16, w22
    f424:      	cmp	w16, wzr
    f428:      	b.ne	0xf434 <_stogir.vector-arithmetic.valid-type?+0x2f4>
    f42c:      	movz	x0, #0x0, lsl #48
    f430:      	b	0xf3f0 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    f434:      	uxtb	w16, w19
    f438:      	cmp	w16, wzr
    f43c:      	b.eq	0xf3ec <_stogir.vector-arithmetic.valid-type?+0x2ac>
    f440:      	mov	x0, #0x1                ; =1
    f444:      	b	0xf3f0 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    f448:      	movz	x0, #0x0, lsl #48
    f44c:      	b	0xf3f0 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    f450:      	uxtb	w16, w2
    f454:      	cmp	w16, wzr
    f458:      	b.ne	0xf4c4 <_stogir.vector-arithmetic.valid-type?+0x384>
    f45c:      	uxtb	w16, w3
    f460:      	cmp	w16, wzr
    f464:      	b.ne	0xf4c4 <_stogir.vector-arithmetic.valid-type?+0x384>
    f468:      	uxtb	w16, w5
    f46c:      	cmp	w16, wzr
    f470:      	b.ne	0xf4c4 <_stogir.vector-arithmetic.valid-type?+0x384>
    f474:      	uxtb	w16, w21
    f478:      	cmp	w16, wzr
    f47c:      	b.ne	0xf538 <_stogir.vector-arithmetic.valid-type?+0x3f8>
    f480:      	uxtb	w16, w22
    f484:      	cmp	w16, wzr
    f488:      	b.ne	0xf538 <_stogir.vector-arithmetic.valid-type?+0x3f8>
    f48c:      	uxtb	w16, w4
    f490:      	cmp	w16, wzr
    f494:      	b.eq	0xf548 <_stogir.vector-arithmetic.valid-type?+0x408>
    f498:      	uxtb	w16, w1
    f49c:      	cmp	w16, wzr
    f4a0:      	b.eq	0xf548 <_stogir.vector-arithmetic.valid-type?+0x408>
    f4a4:      	uxtb	w16, w0
    f4a8:      	cmp	w16, wzr
    f4ac:      	b.eq	0xf550 <_stogir.vector-arithmetic.valid-type?+0x410>
    f4b0:      	uxtb	w16, w9
    f4b4:      	cmp	w16, wzr
    f4b8:      	b.eq	0xf558 <_stogir.vector-arithmetic.valid-type?+0x418>
    f4bc:      	mov	x0, #0x1                ; =1
    f4c0:      	b	0xf55c <_stogir.vector-arithmetic.valid-type?+0x41c>
    f4c4:      	uxtb	w16, w4
    f4c8:      	cmp	w16, wzr
    f4cc:      	b.eq	0xf448 <_stogir.vector-arithmetic.valid-type?+0x308>
    f4d0:      	ubfx	x0, x1, #0, #8
    f4d4:      	b	0xf44c <_stogir.vector-arithmetic.valid-type?+0x30c>
    f4d8:      	movz	x0, #0x0, lsl #48
    f4dc:      	b	0xf44c <_stogir.vector-arithmetic.valid-type?+0x30c>
    f4e0:      	cmp	x1, #0x1a
    f4e4:      	b.eq	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f4e8:      	cmp	x1, #0x1b
    f4ec:      	b.eq	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f4f0:      	cmp	x1, #0x1c
    f4f4:      	b.eq	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f4f8:      	cmp	x1, #0x1d
    f4fc:      	b.eq	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f500:      	uxtb	w16, w6
    f504:      	cmp	w16, wzr
    f508:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f50c:      	uxtb	w16, w2
    f510:      	cmp	w16, wzr
    f514:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f518:      	uxtb	w16, w3
    f51c:      	cmp	w16, wzr
    f520:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f524:      	uxtb	w16, w5
    f528:      	cmp	w16, wzr
    f52c:      	b.ne	0xf304 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    f530:      	movz	x0, #0x0, lsl #48
    f534:      	b	0xf3f0 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    f538:      	uxtb	w16, w6
    f53c:      	cmp	w16, wzr
    f540:      	cset	x0, eq
    f544:      	b	0xf44c <_stogir.vector-arithmetic.valid-type?+0x30c>
    f548:      	movz	x0, #0x0, lsl #48
    f54c:      	b	0xf544 <_stogir.vector-arithmetic.valid-type?+0x404>
    f550:      	mov	x0, #0x1                ; =1
    f554:      	b	0xf54c <_stogir.vector-arithmetic.valid-type?+0x40c>
    f558:      	ubfx	x0, x10, #0, #8
    f55c:      	b	0xf554 <_stogir.vector-arithmetic.valid-type?+0x414>

000000000000f560 <_coil.core.Len$slice$len__i32>:
    f560:      	mov	x0, x1
    f564:      	ret

000000000000f568 <_inherent$slice$data__i32>:
    f568:      	ret

000000000000f56c <_stogir.opcode.terminator?>:
    f56c:      	sxtw	x0, w0
    f570:      	cmp	x0, #0x0
    f574:      	b.lt	0xf598 <_stogir.opcode.terminator?+0x2c>
    f578:      	cmp	x0, #0x83
    f57c:      	b.ge	0xf598 <_stogir.opcode.terminator?+0x2c>
    f580:      	adrp	x16, 0xf000 <_stogir.vector-comparison.valid-type?+0x8c>
		000000000000f580:  ARM64_RELOC_PAGE21	l_stogir.519
    f584:      	ldr	x16, [x16]
		000000000000f584:  ARM64_RELOC_PAGEOFF12	l_stogir.519
    f588:      	orr	x1, x16, xzr
    f58c:      	add	x0, x1, x0
    f590:      	ldrb	w0, [x0]
    f594:      	b	0xf59c <_stogir.opcode.terminator?+0x30>
    f598:      	movz	x0, #0x0, lsl #48
    f59c:      	uxtb	w0, w0
    f5a0:      	and	x0, x0, #0x8
    f5a4:      	uxtb	w0, w0
    f5a8:      	cmp	x0, #0x0
    f5ac:      	cset	w0, eq
    f5b0:      	uxtb	w16, w0
    f5b4:      	cmp	w16, wzr
    f5b8:      	cset	x0, eq
    f5bc:      	ret

000000000000f5c0 <_stogir.switch.sign-mask>:
    f5c0:      	sxtw	x0, w0
    f5c4:      	cmp	x0, #0x7
    f5c8:      	b.lt	0xf5e4 <_stogir.switch.sign-mask+0x24>
    f5cc:      	cmp	x0, #0xb
    f5d0:      	b.gt	0xf5e4 <_stogir.switch.sign-mask+0x24>
    f5d4:      	cmp	x0, #0x0
    f5d8:      	b.ne	0xf61c <_stogir.switch.sign-mask+0x5c>
    f5dc:      	movz	x0, #0x0, lsl #48
    f5e0:      	b	0xf5f0 <_stogir.switch.sign-mask+0x30>
    f5e4:      	movz	x0, #0x0, lsl #48
    f5e8:      	ret
    f5ec:      	mov	x0, #0x1                ; =1
    f5f0:      	lsr	w0, w0, #0
    f5f4:      	sxtw	x0, w0
    f5f8:      	lsl	x0, x0, #3
    f5fc:      	lsr	w0, w0, #0
    f600:      	sxtw	x0, w0
    f604:      	sub	x0, x0, #0x1
    f608:      	lsr	w0, w0, #0
    f60c:      	sxtw	x0, w0
    f610:      	mov	x16, #0x1               ; =1
    f614:      	lsl	x0, x16, x0
    f618:      	b	0xf5e8 <_stogir.switch.sign-mask+0x28>
    f61c:      	cmp	x0, #0x1
    f620:      	b.eq	0xf5ec <_stogir.switch.sign-mask+0x2c>
    f624:      	cmp	x0, #0x2
    f628:      	b.eq	0xf5ec <_stogir.switch.sign-mask+0x2c>
    f62c:      	cmp	x0, #0x7
    f630:      	b.eq	0xf5ec <_stogir.switch.sign-mask+0x2c>
    f634:      	cmp	x0, #0x8
    f638:      	b.eq	0xf5ec <_stogir.switch.sign-mask+0x2c>
    f63c:      	cmp	x0, #0x3
    f640:      	b.eq	0xf69c <_stogir.switch.sign-mask+0xdc>
    f644:      	cmp	x0, #0x9
    f648:      	b.eq	0xf69c <_stogir.switch.sign-mask+0xdc>
    f64c:      	cmp	x0, #0x4
    f650:      	b.eq	0xf6a4 <_stogir.switch.sign-mask+0xe4>
    f654:      	cmp	x0, #0xa
    f658:      	b.eq	0xf6a4 <_stogir.switch.sign-mask+0xe4>
    f65c:      	cmp	x0, #0xd
    f660:      	b.eq	0xf6a4 <_stogir.switch.sign-mask+0xe4>
    f664:      	cmp	x0, #0x5
    f668:      	b.eq	0xf6ac <_stogir.switch.sign-mask+0xec>
    f66c:      	cmp	x0, #0xb
    f670:      	b.eq	0xf6ac <_stogir.switch.sign-mask+0xec>
    f674:      	cmp	x0, #0xc
    f678:      	b.eq	0xf6ac <_stogir.switch.sign-mask+0xec>
    f67c:      	cmp	x0, #0x6
    f680:      	cset	w0, eq
    f684:      	uxtb	w16, w0
    f688:      	cmp	w16, wzr
    f68c:      	mov	x16, #0x8               ; =8
    f690:      	movn	x17, #0x0, lsl #48
    f694:      	csel	x0, x16, x17, ne
    f698:      	b	0xf6b0 <_stogir.switch.sign-mask+0xf0>
    f69c:      	mov	x0, #0x2                ; =2
    f6a0:      	b	0xf5f0 <_stogir.switch.sign-mask+0x30>
    f6a4:      	mov	x0, #0x4                ; =4
    f6a8:      	b	0xf6a0 <_stogir.switch.sign-mask+0xe0>
    f6ac:      	mov	x0, #0x8                ; =8
    f6b0:      	b	0xf6a8 <_stogir.switch.sign-mask+0xe8>
