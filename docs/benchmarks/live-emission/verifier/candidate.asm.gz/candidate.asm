
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-live-emission/build/live-snapshot-verifier/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x134 <_stogir.verify.integer-operations-target+0x84>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x188 <_stogir.verify.integer-operations-target+0xd8>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, #0x1                ; =1
     130:      	b	0x160 <_stogir.verify.integer-operations-target+0xb0>
     134:      	lsr	w21, w21, #0
     138:      	add	x8, sp, #0x30
     13c:      	mov	x0, x20
     140:      	mov	w1, w21
     144:      	bl	0x144 <_stogir.verify.integer-operations-target+0x94>
		0000000000000144:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     148:      	add	x16, sp, #0x30
     14c:      	ldr	x2, [x16]
     150:      	add	x16, sp, #0x30
     154:      	ldr	x1, [x16, #0x8]
     158:      	add	x16, sp, #0x30
     15c:      	ldr	x0, [x16, #0x10]
     160:      	str	x2, [x19]
     164:      	str	x1, [x19, #0x8]
     168:      	str	x0, [x19, #0x10]
     16c:      	ldr	x19, [sp, #0x50]
     170:      	ldr	x20, [sp, #0x58]
     174:      	ldr	x21, [sp, #0x60]
     178:      	ldr	x29, [sp]
     17c:      	ldr	x30, [sp, #0x8]
     180:      	add	sp, sp, #0x70
     184:      	ret
     188:      	brk	#0
     18c:      	b	0x188 <_stogir.verify.integer-operations-target+0xd8>

0000000000000190 <_stogir.verify.structure>:
     190:      	sub	sp, sp, #0x1a0
     194:      	str	x29, [sp, #0x10]
     198:      	str	x30, [sp, #0x18]
     19c:      	add	x29, sp, #0x10
     1a0:      	str	x19, [sp, #0x150]
     1a4:      	str	x20, [sp, #0x158]
     1a8:      	str	x21, [sp, #0x160]
     1ac:      	str	x22, [sp, #0x168]
     1b0:      	str	x23, [sp, #0x170]
     1b4:      	str	x24, [sp, #0x178]
     1b8:      	str	x25, [sp, #0x180]
     1bc:      	str	x26, [sp, #0x188]
     1c0:      	str	x27, [sp, #0x190]
     1c4:      	str	x28, [sp, #0x198]
     1c8:      	add	x1, x0, #0x78
     1cc:      	ldr	x2, [x0, #0x8]
     1d0:      	ldr	x1, [x1, #0x8]
     1d4:      	cmp	x2, x1
     1d8:      	b.ne	0x210 <_stogir.verify.structure+0x80>
     1dc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001dc:  ARM64_RELOC_PAGE21	l_stogir.304
     1e0:      	ldr	x16, [x16]
		00000000000001e0:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1e4:      	orr	x19, x16, xzr
     1e8:      	movz	x20, #0x0, lsl #48
     1ec:      	b	0x220 <_stogir.verify.structure+0x90>
     1f0:      	ldr	x1, [sp, #0x120]
     1f4:      	ldr	x6, [sp, #0x128]
     1f8:      	add	x6, x1, x6
     1fc:      	ldr	x1, [sp, #0xc0]
     200:      	add	x1, x1, #0x1
     204:      	lsr	w1, w1, #0
     208:      	sxtw	x1, w1
     20c:      	b	0x2ec <_stogir.verify.structure+0x15c>
     210:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000210:  ARM64_RELOC_PAGE21	l_stogir.305
     214:      	ldr	x16, [x16]
		0000000000000214:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     218:      	orr	x19, x16, xzr
     21c:      	mov	x20, #0x2c              ; =44
     220:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000220:  ARM64_RELOC_PAGE21	l_stogir.306
     224:      	ldr	x16, [x16]
		0000000000000224:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     228:      	orr	x21, x16, xzr
     22c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000022c:  ARM64_RELOC_PAGE21	l_stogir.307
     230:      	ldr	x16, [x16]
		0000000000000230:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     234:      	orr	x22, x16, xzr
     238:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000238:  ARM64_RELOC_PAGE21	l_stogir.308
     23c:      	ldr	x16, [x16]
		000000000000023c:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     240:      	orr	x23, x16, xzr
     244:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000244:  ARM64_RELOC_PAGE21	l_stogir.309
     248:      	ldr	x16, [x16]
		0000000000000248:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     24c:      	orr	x24, x16, xzr
     250:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000250:  ARM64_RELOC_PAGE21	l_stogir.310
     254:      	ldr	x16, [x16]
		0000000000000254:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     258:      	orr	x25, x16, xzr
     25c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000025c:  ARM64_RELOC_PAGE21	l_stogir.311
     260:      	ldr	x16, [x16]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     264:      	orr	x26, x16, xzr
     268:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000268:  ARM64_RELOC_PAGE21	l_stogir.312
     26c:      	ldr	x16, [x16]
		000000000000026c:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     270:      	orr	x27, x16, xzr
     274:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000274:  ARM64_RELOC_PAGE21	l_stogir.313
     278:      	ldr	x16, [x16]
		0000000000000278:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     27c:      	orr	x28, x16, xzr
     280:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000280:  ARM64_RELOC_PAGE21	l_stogir.314
     284:      	ldr	x16, [x16]
		0000000000000284:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     288:      	orr	x1, x16, xzr
     28c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000028c:  ARM64_RELOC_PAGE21	l_stogir.315
     290:      	ldr	x16, [x16]
		0000000000000290:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     294:      	orr	x2, x16, xzr
     298:      	add	x3, x0, #0x110
     29c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000029c:  ARM64_RELOC_PAGE21	l_stogir.316
     2a0:      	ldr	x16, [x16]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     2a4:      	orr	x4, x16, xzr
     2a8:      	add	x5, x0, #0x78
     2ac:      	add	x6, x0, #0x28
     2b0:      	add	x7, x0, #0x50
     2b4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002b4:  ARM64_RELOC_PAGE21	l_stogir.316
     2b8:      	ldr	x16, [x16]
		00000000000002b8:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     2bc:      	orr	x9, x16, xzr
     2c0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002c0:  ARM64_RELOC_PAGE21	l_stogir.317
     2c4:      	ldr	x16, [x16]
		00000000000002c4:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     2c8:      	orr	x10, x16, xzr
     2cc:      	add	x11, x3, #0x28
     2d0:      	mov	x12, #0x1               ; =1
     2d4:      	movz	x13, #0x0, lsl #48
     2d8:      	b	0x3b0 <_stogir.verify.structure+0x220>
     2dc:      	ldr	x17, [sp, #0x58]
     2e0:      	str	x17, [sp, #0xa8]
     2e4:      	mov	x16, #0x16              ; =22
     2e8:      	str	x16, [sp, #0x118]
     2ec:      	b	0x354 <_stogir.verify.structure+0x1c4>
     2f0:      	str	x8, [sp, #0xa0]
     2f4:      	str	x21, [sp, #0x40]
     2f8:      	str	x22, [sp, #0x58]
     2fc:      	str	x23, [sp, #0x60]
     300:      	mov	x23, x0
     304:      	str	x24, [sp, #0x78]
     308:      	str	x25, [sp, #0x80]
     30c:      	str	x26, [sp, #0x88]
     310:      	str	x27, [sp, #0x90]
     314:      	str	x28, [sp, #0x98]
     318:      	str	x1, [sp, #0x68]
     31c:      	mov	x1, x13
     320:      	str	x2, [sp, #0x70]
     324:      	str	x4, [sp, #0x100]
     328:      	mov	x0, x11
     32c:      	mov	x2, x5
     330:      	mov	x4, x6
     334:      	mov	x6, x12
     338:      	mov	x5, x7
     33c:      	str	x9, [sp, #0xe8]
     340:      	str	x10, [sp, #0xf8]
     344:      	ldr	x17, [sp, #0x40]
     348:      	str	x17, [sp, #0xa8]
     34c:      	mov	x16, #0x23              ; =35
     350:      	str	x16, [sp, #0x118]
     354:      	ldr	x8, [sp, #0xa0]
     358:      	ldr	x21, [sp, #0x40]
     35c:      	ldr	x22, [sp, #0x58]
     360:      	ldr	x24, [sp, #0x78]
     364:      	ldr	x25, [sp, #0x80]
     368:      	ldr	x26, [sp, #0x88]
     36c:      	ldr	x27, [sp, #0x90]
     370:      	ldr	x28, [sp, #0x98]
     374:      	mov	x11, x0
     378:      	mov	x0, x23
     37c:      	ldr	x23, [sp, #0x60]
     380:      	mov	x7, x5
     384:      	mov	x5, x2
     388:      	ldr	x2, [sp, #0x70]
     38c:      	ldr	x9, [sp, #0xe8]
     390:      	ldr	x10, [sp, #0xf8]
     394:      	mov	x12, x6
     398:      	mov	x6, x4
     39c:      	ldr	x4, [sp, #0x100]
     3a0:      	mov	x13, x1
     3a4:      	ldr	x1, [sp, #0x68]
     3a8:      	ldr	x19, [sp, #0xa8]
     3ac:      	ldr	x20, [sp, #0x118]
     3b0:      	cmp	x20, #0x0
     3b4:      	b.ne	0xbf8 <_stogir.verify.structure+0xa68>
     3b8:      	ldr	x14, [x0, #0x8]
     3bc:      	cmp	x12, x14
     3c0:      	b.ge	0xc0c <_stogir.verify.structure+0xa7c>
     3c4:      	ldr	x14, [x0]
     3c8:      	add	x14, x14, x12, lsl #4
     3cc:      	ldr	x14, [x14]
     3d0:      	ldr	x15, [x0, #0x78]
     3d4:      	add	x15, x15, x12, lsl #2
     3d8:      	ldr	w15, [x15]
     3dc:      	sxtw	x15, w15
     3e0:      	cmp	x15, #0x0
     3e4:      	b.lt	0x2f0 <_stogir.verify.structure+0x160>
     3e8:      	mov	x17, #0xffff            ; =65535
     3ec:      	cmp	x15, x17
     3f0:      	b.gt	0xc20 <_stogir.verify.structure+0xa90>
     3f4:      	str	x0, [sp, #0x30]
     3f8:      	uxtb	w0, w14
     3fc:      	str	w0, [sp, #0x38]
     400:      	str	x21, [sp, #0x40]
     404:      	cmp	x0, #0x83
     408:      	cset	w21, lt
     40c:      	uxtb	w16, w21
     410:      	cmp	w16, wzr
     414:      	b.eq	0xc78 <_stogir.verify.structure+0xae8>
     418:      	lsr	w14, w14, #0
     41c:      	str	x0, [sp, #0x48]
     420:      	ubfx	x0, x14, #8, #8
     424:      	str	w0, [sp, #0x50]
     428:      	lsr	w0, w0, #0
     42c:      	str	x8, [sp, #0xa0]
     430:      	str	x1, [sp, #0x68]
     434:      	str	x2, [sp, #0x70]
     438:      	str	x3, [sp, #0xd0]
     43c:      	str	x5, [sp, #0xc8]
     440:      	str	x6, [sp, #0xb8]
     444:      	str	x7, [sp, #0xb0]
     448:      	str	x9, [sp, #0xe8]
     44c:      	str	x11, [sp, #0xd8]
     450:      	str	x13, [sp, #0xc0]
     454:      	str	x22, [sp, #0x58]
     458:      	ldr	w22, [sp, #0x50]
     45c:      	str	x23, [sp, #0x60]
     460:      	ldr	x23, [sp, #0x30]
     464:      	str	x24, [sp, #0x78]
     468:      	ldr	w24, [sp, #0x38]
     46c:      	str	x25, [sp, #0x80]
     470:      	mov	x25, x4
     474:      	str	x26, [sp, #0x88]
     478:      	mov	x26, x15
     47c:      	str	x27, [sp, #0x90]
     480:      	mov	x27, x12
     484:      	str	x28, [sp, #0x98]
     488:      	ldr	x28, [sp, #0x48]
     48c:      	str	x19, [sp, #0xa8]
     490:      	mov	x19, x10
     494:      	str	w21, [sp, #0xe0]
     498:      	mov	x21, x14
     49c:      	bl	0x49c <_stogir.verify.structure+0x30c>
		000000000000049c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     4a0:      	cmp	x0, #0x0
     4a4:      	b.eq	0xccc <_stogir.verify.structure+0xb3c>
     4a8:      	add	x0, x28, x19
     4ac:      	lsr	w24, w24, #0
     4b0:      	ldrsb	w0, [x0]
     4b4:      	sxtb	x0, w0
     4b8:      	cmp	x0, #0x0
     4bc:      	b.lt	0x950 <_stogir.verify.structure+0x7c0>
     4c0:      	mov	w0, w24
     4c4:      	bl	0x4c4 <_stogir.verify.structure+0x334>
		00000000000004c4:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4c8:      	lsr	w0, w0, #0
     4cc:      	sxtw	x0, w0
     4d0:      	cmp	x26, x0
     4d4:      	b.eq	0x950 <_stogir.verify.structure+0x7c0>
     4d8:      	ldr	x3, [sp, #0xd0]
     4dc:      	str	x25, [sp, #0x100]
     4e0:      	ldr	x0, [sp, #0xd8]
     4e4:      	ldr	x2, [sp, #0xc8]
     4e8:      	ldr	x4, [sp, #0xb8]
     4ec:      	ldr	x5, [sp, #0xb0]
     4f0:      	str	x19, [sp, #0xf8]
     4f4:      	mov	x6, x27
     4f8:      	ldr	x1, [sp, #0xc0]
     4fc:      	ldr	x17, [sp, #0x60]
     500:      	str	x17, [sp, #0xa8]
     504:      	mov	x16, #0x23              ; =35
     508:      	str	x16, [sp, #0x118]
     50c:      	b	0x20c <_stogir.verify.structure+0x7c>
     510:      	ldr	x0, [sp, #0x118]
     514:      	cmp	x0, #0x0
     518:      	b.ne	0xcf4 <_stogir.verify.structure+0xb64>
     51c:      	and	x1, x1, #0xffffffff
     520:      	movz	x2, #0x0, lsl #48
     524:      	movz	x0, #0x0, lsl #48
     528:      	b	0x530 <_stogir.verify.structure+0x3a0>
     52c:      	mov	x2, #0x1                ; =1
     530:      	ldr	x3, [sp, #0xa0]
     534:      	str	x2, [x3]
     538:      	str	x1, [x3, #0x8]
     53c:      	str	x0, [x3, #0x10]
     540:      	ldr	x19, [sp, #0x150]
     544:      	ldr	x20, [sp, #0x158]
     548:      	ldr	x21, [sp, #0x160]
     54c:      	ldr	x22, [sp, #0x168]
     550:      	ldr	x23, [sp, #0x170]
     554:      	ldr	x24, [sp, #0x178]
     558:      	ldr	x25, [sp, #0x180]
     55c:      	ldr	x26, [sp, #0x188]
     560:      	ldr	x27, [sp, #0x190]
     564:      	ldr	x28, [sp, #0x198]
     568:      	ldr	x29, [sp, #0x10]
     56c:      	ldr	x30, [sp, #0x18]
     570:      	add	sp, sp, #0x1a0
     574:      	ret
     578:      	mov	x11, x8
     57c:      	lsl	x11, x11, #2
     580:      	lsr	w11, w11, #0
     584:      	ubfx	x11, x11, #0, #32
     588:      	lsr	x10, x10, x11
     58c:      	lsr	w10, w10, #0
     590:      	and	x10, x10, #0xf
     594:      	lsr	w10, w10, #0
     598:      	b	0x5b8 <_stogir.verify.structure+0x428>
     59c:      	movz	x1, #0x0, lsl #48
     5a0:      	cmp	x1, #0x0
     5a4:      	b.eq	0xa24 <_stogir.verify.structure+0x894>
     5a8:      	ldr	w1, [sp, #0x148]
     5ac:      	ldr	w6, [sp, #0x140]
     5b0:      	b	0x694 <_stogir.verify.structure+0x504>
     5b4:      	movz	x10, #0x0, lsl #48
     5b8:      	b	0x5c0 <_stogir.verify.structure+0x430>
     5bc:      	movz	x10, #0x0, lsl #48
     5c0:      	add	x16, sp, #0x20
     5c4:      	str	x16, [sp]
     5c8:      	str	w0, [sp, #0xf0]
     5cc:      	str	x2, [sp, #0xe8]
     5d0:      	mov	w2, w4
     5d4:      	str	x3, [sp, #0x130]
     5d8:      	str	x19, [sp, #0xf8]
     5dc:      	mov	x19, x1
     5e0:      	mov	w1, w0
     5e4:      	mov	x0, x23
     5e8:      	str	x25, [sp, #0x100]
     5ec:      	mov	x25, x10
     5f0:      	str	x26, [sp, #0x108]
     5f4:      	mov	x26, x5
     5f8:      	str	x28, [sp, #0x110]
     5fc:      	mov	w28, w6
     600:      	str	x20, [sp, #0x118]
     604:      	mov	w20, w7
     608:      	str	x21, [sp, #0x120]
     60c:      	mov	x21, x8
     610:      	str	x27, [sp, #0x128]
     614:      	mov	w27, w9
     618:      	bl	0x618 <_stogir.verify.structure+0x488>
		0000000000000618:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     61c:      	ldr	x16, [sp]
     620:      	str	x0, [x16]
     624:      	str	x1, [x16, #0x8]
     628:      	add	x16, sp, #0x20
     62c:      	ldr	x0, [x16]
     630:      	add	x16, sp, #0x20
     634:      	ldr	x1, [x16, #0x8]
     638:      	lsr	w0, w0, #0
     63c:      	lsr	x16, x0, #0
     640:      	cmp	x16, #0x1
     644:      	b.eq	0x660 <_stogir.verify.structure+0x4d0>
     648:      	b.lo	0x650 <_stogir.verify.structure+0x4c0>
     64c:      	b	0x664 <_stogir.verify.structure+0x4d4>
     650:      	cmp	x16, #0x0
     654:      	b.eq	0x65c <_stogir.verify.structure+0x4cc>
     658:      	b	0x664 <_stogir.verify.structure+0x4d4>
     65c:      	b	0x668 <_stogir.verify.structure+0x4d8>
     660:      	b	0x76c <_stogir.verify.structure+0x5dc>
     664:      	b	0xb60 <_stogir.verify.structure+0x9d0>
     668:      	ldr	x3, [sp, #0xd0]
     66c:      	ldr	x0, [sp, #0xd8]
     670:      	ldr	x2, [sp, #0xc8]
     674:      	ldr	x4, [sp, #0xb8]
     678:      	ldr	x5, [sp, #0xb0]
     67c:      	mov	w1, w24
     680:      	mov	w6, w22
     684:      	ldr	x17, [sp, #0x90]
     688:      	str	x17, [sp, #0xa8]
     68c:      	mov	x16, #0x17              ; =23
     690:      	str	x16, [sp, #0x118]
     694:      	ldr	x7, [sp, #0x130]
     698:      	add	x7, x7, #0x1
     69c:      	lsr	w7, w7, #0
     6a0:      	sxtw	x7, w7
     6a4:      	ldr	x26, [sp, #0x108]
     6a8:      	ldr	x21, [sp, #0x120]
     6ac:      	str	x3, [sp, #0xd0]
     6b0:      	str	w27, [sp, #0xe0]
     6b4:      	ldr	x27, [sp, #0x128]
     6b8:      	ldr	x25, [sp, #0x100]
     6bc:      	ldr	x28, [sp, #0x110]
     6c0:      	str	x0, [sp, #0xd8]
     6c4:      	ldr	w0, [sp, #0xf0]
     6c8:      	str	x2, [sp, #0xc8]
     6cc:      	str	x4, [sp, #0xb8]
     6d0:      	str	x5, [sp, #0xb0]
     6d4:      	mov	w24, w1
     6d8:      	mov	w22, w6
     6dc:      	ldr	x2, [sp, #0xe8]
     6e0:      	mov	x1, x19
     6e4:      	ldr	x19, [sp, #0xf8]
     6e8:      	mov	x3, x7
     6ec:      	ldr	x20, [sp, #0x118]
     6f0:      	cmp	x20, #0x0
     6f4:      	b.ne	0x708 <_stogir.verify.structure+0x578>
     6f8:      	cmp	x3, x26
     6fc:      	cset	w4, le
     700:      	ubfx	x4, x4, #0, #8
     704:      	b	0x70c <_stogir.verify.structure+0x57c>
     708:      	movz	x4, #0x0, lsl #48
     70c:      	cmp	x4, #0x0
     710:      	b.eq	0xcfc <_stogir.verify.structure+0xb6c>
     714:      	lsr	w4, w3, #0
     718:      	sxtw	x5, w4
     71c:      	cmp	x5, #0x0
     720:      	cset	w6, gt
     724:      	cmp	x5, #0x4
     728:      	cset	w7, gt
     72c:      	sub	x8, x5, #0x1
     730:      	lsr	w8, w8, #0
     734:      	sxtw	x8, w8
     738:      	ldr	w9, [sp, #0xe0]
     73c:      	uxtb	w16, w9
     740:      	cmp	w16, wzr
     744:      	b.eq	0x5bc <_stogir.verify.structure+0x42c>
     748:      	ldr	w10, [x28]
     74c:      	uxtb	w16, w6
     750:      	cmp	w16, wzr
     754:      	b.eq	0x5b4 <_stogir.verify.structure+0x424>
     758:      	uxtb	w16, w7
     75c:      	cmp	w16, wzr
     760:      	b.eq	0x578 <_stogir.verify.structure+0x3e8>
     764:      	mov	x11, #0x4               ; =4
     768:      	b	0x57c <_stogir.verify.structure+0x3ec>
     76c:      	lsr	w25, w25, #0
     770:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000770:  ARM64_RELOC_PAGE21	l_stogir.318
     774:      	ldr	x16, [x16]
		0000000000000774:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     778:      	ldr	w0, [x16]
     77c:      	orr	x2, x25, xzr
     780:      	cmp	x2, x0
     784:      	b.ne	0x798 <_stogir.verify.structure+0x608>
     788:      	mov	x0, #0x1                ; =1
     78c:      	b	0x7b0 <_stogir.verify.structure+0x620>
     790:      	movz	x1, #0x0, lsl #48
     794:      	b	0x81c <_stogir.verify.structure+0x68c>
     798:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000798:  ARM64_RELOC_PAGE21	l_stogir.319
     79c:      	ldr	x16, [x16]
		000000000000079c:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     7a0:      	ldr	w0, [x16]
     7a4:      	cmp	x2, x0
     7a8:      	cset	w0, eq
     7ac:      	ubfx	x0, x0, #0, #8
     7b0:      	lsr	w1, w1, #0
     7b4:      	cmp	x0, #0x0
     7b8:      	b.eq	0xd2c <_stogir.verify.structure+0xb9c>
     7bc:      	lsr	w1, w1, #0
     7c0:      	str	x26, [sp, #0x138]
     7c4:      	mov	x26, x2
     7c8:      	str	w22, [sp, #0x140]
     7cc:      	mov	x22, x0
     7d0:      	mov	x0, x23
     7d4:      	str	w24, [sp, #0x148]
     7d8:      	mov	w24, w1
     7dc:      	bl	0x7dc <_stogir.verify.structure+0x64c>
		00000000000007dc:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     7e0:      	cmp	x0, #0x0
     7e4:      	cset	w1, eq
     7e8:      	uxtb	w16, w1
     7ec:      	cmp	w16, wzr
     7f0:      	cset	x1, eq
     7f4:      	cmp	x1, #0x0
     7f8:      	b.eq	0x81c <_stogir.verify.structure+0x68c>
     7fc:      	ldr	w0, [x0]
     800:      	uxtb	w0, w0
     804:      	cmp	x0, #0x48
     808:      	b.ne	0x81c <_stogir.verify.structure+0x68c>
     80c:      	ldr	x17, [sp, #0x98]
     810:      	str	x17, [sp, #0xa8]
     814:      	mov	x16, #0x25              ; =37
     818:      	str	x16, [sp, #0x118]
     81c:      	sxtw	x24, w24
     820:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000820:  ARM64_RELOC_PAGE21	l_stogir.320
     824:      	ldr	x16, [x16]
		0000000000000824:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     828:      	ldr	w0, [x16]
     82c:      	cmp	x26, x0
     830:      	b.ne	0xd48 <_stogir.verify.structure+0xbb8>
     834:      	cmp	x24, #0x0
     838:      	b.gt	0x9bc <_stogir.verify.structure+0x82c>
     83c:      	ldr	x3, [sp, #0xd0]
     840:      	ldr	x0, [sp, #0xd8]
     844:      	movz	x2, #0x0, lsl #48
     848:      	lsr	w2, w2, #0
     84c:      	lsr	x16, x2, #0
     850:      	cmp	x16, #0x1
     854:      	b.eq	0x870 <_stogir.verify.structure+0x6e0>
     858:      	b.lo	0x860 <_stogir.verify.structure+0x6d0>
     85c:      	b	0x874 <_stogir.verify.structure+0x6e4>
     860:      	cmp	x16, #0x0
     864:      	b.eq	0x86c <_stogir.verify.structure+0x6dc>
     868:      	b	0x874 <_stogir.verify.structure+0x6e4>
     86c:      	b	0x878 <_stogir.verify.structure+0x6e8>
     870:      	b	0x888 <_stogir.verify.structure+0x6f8>
     874:      	b	0xbf0 <_stogir.verify.structure+0xa60>
     878:      	ldr	x17, [sp, #0x68]
     87c:      	str	x17, [sp, #0xa8]
     880:      	mov	x16, #0x21              ; =33
     884:      	str	x16, [sp, #0x118]
     888:      	cmp	x25, #0xf
     88c:      	b.hs	0xd54 <_stogir.verify.structure+0xbc4>
     890:      	mov	x16, #0x1               ; =1
     894:      	lsl	x2, x16, x25
     898:      	lsr	w2, w2, #0
     89c:      	mov	x17, #0x5e1c            ; =24092
     8a0:      	and	x2, x2, x17
     8a4:      	lsr	w2, w2, #0
     8a8:      	cmp	x2, #0x0
     8ac:      	b.eq	0xd6c <_stogir.verify.structure+0xbdc>
     8b0:      	cmp	x22, #0x0
     8b4:      	b.eq	0xa78 <_stogir.verify.structure+0x8e8>
     8b8:      	ldr	x2, [sp, #0xc8]
     8bc:      	ldr	x4, [sp, #0xb8]
     8c0:      	ldr	x5, [sp, #0xb0]
     8c4:      	b	0x5a0 <_stogir.verify.structure+0x410>
     8c8:      	lsr	w0, w27, #0
     8cc:      	cmp	x28, #0x78
     8d0:      	cset	w24, eq
     8d4:      	lsr	w0, w0, #0
     8d8:      	add	x1, x25, x28, lsl #2
     8dc:      	ldr	x2, [sp, #0xe8]
     8e0:      	add	x3, x2, x28, lsl #2
     8e4:      	cmp	x22, #0x0
     8e8:      	cset	w22, eq
     8ec:      	orr	x28, x1, xzr
     8f0:      	orr	x1, x3, xzr
     8f4:      	mov	x3, #0x1                ; =1
     8f8:      	b	0x6f0 <_stogir.verify.structure+0x560>
     8fc:      	nop
     900:      	movz	x1, #0x0, lsl #48
     904:      	cmp	x1, #0x0
     908:      	b.eq	0x8c8 <_stogir.verify.structure+0x738>
     90c:      	add	x1, x0, x27
     910:      	ldr	x2, [x23, #0x78]
     914:      	add	x1, x2, x1, lsl #2
     918:      	ldr	w1, [x1]
     91c:      	sxtw	x1, w1
     920:      	cmn	x1, #0x1
     924:      	b.eq	0x934 <_stogir.verify.structure+0x7a4>
     928:      	ldr	x17, [sp, #0x88]
     92c:      	str	x17, [sp, #0xa8]
     930:      	mov	x20, #0x1b              ; =27
     934:      	add	x0, x0, #0x1
     938:      	cmp	x20, #0x0
     93c:      	b.ne	0x900 <_stogir.verify.structure+0x770>
     940:      	cmp	x0, x21
     944:      	cset	w1, lt
     948:      	ubfx	x1, x1, #0, #8
     94c:      	b	0x904 <_stogir.verify.structure+0x774>
     950:      	mov	w0, w24
     954:      	bl	0x954 <_stogir.verify.structure+0x7c4>
		0000000000000954:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     958:      	lsr	w0, w0, #0
     95c:      	sxtw	x0, w0
     960:      	cmn	x0, #0x1
     964:      	b.ne	0x980 <_stogir.verify.structure+0x7f0>
     968:      	ubfx	x0, x21, #16, #16
     96c:      	cmp	x26, x0
     970:      	b.eq	0x980 <_stogir.verify.structure+0x7f0>
     974:      	ldr	x17, [sp, #0x78]
     978:      	str	x17, [sp, #0xa8]
     97c:      	mov	x20, #0x24              ; =36
     980:      	add	x0, x26, #0x4
     984:      	ldr	x1, [x23, #0x8]
     988:      	asr	x16, x0, #63
     98c:      	lsr	x16, x16, #62
     990:      	add	x0, x0, x16
     994:      	asr	x0, x0, #2
     998:      	orr	x21, x0, xzr
     99c:      	add	x0, x21, x27
     9a0:      	cmp	x0, x1
     9a4:      	b.le	0x9b4 <_stogir.verify.structure+0x824>
     9a8:      	ldr	x17, [sp, #0x80]
     9ac:      	str	x17, [sp, #0xa8]
     9b0:      	mov	x20, #0x15              ; =21
     9b4:      	mov	x0, #0x1                ; =1
     9b8:      	b	0x938 <_stogir.verify.structure+0x7a8>
     9bc:      	ldr	x0, [sp, #0xd8]
     9c0:      	ldr	x2, [x0, #0x8]
     9c4:      	cmp	x24, x2
     9c8:      	b.gt	0xd84 <_stogir.verify.structure+0xbf4>
     9cc:      	sub	x2, x24, #0x1
     9d0:      	ldr	x3, [sp, #0xd0]
     9d4:      	ldr	x4, [x3, #0x28]
     9d8:      	mov	x17, #0x18              ; =24
     9dc:      	mul	x2, x2, x17
     9e0:      	add	x2, x2, x4
     9e4:      	ldr	x4, [x2]
     9e8:      	ldr	x2, [x2, #0x8]
     9ec:      	ldr	x5, [x3, #0x8]
     9f0:      	cmp	x4, #0x0
     9f4:      	b.lt	0xa1c <_stogir.verify.structure+0x88c>
     9f8:      	cmp	x4, x5
     9fc:      	b.gt	0xa1c <_stogir.verify.structure+0x88c>
     a00:      	cmp	x2, #0x0
     a04:      	b.lt	0xa1c <_stogir.verify.structure+0x88c>
     a08:      	sub	x4, x5, x4
     a0c:      	cmp	x2, x4
     a10:      	b.gt	0xa1c <_stogir.verify.structure+0x88c>
     a14:      	mov	x2, #0x1                ; =1
     a18:      	b	0xa20 <_stogir.verify.structure+0x890>
     a1c:      	movz	x2, #0x0, lsl #48
     a20:      	b	0x848 <_stogir.verify.structure+0x6b8>
     a24:      	cmp	x24, #0x0
     a28:      	b.ne	0xd8c <_stogir.verify.structure+0xbfc>
     a2c:      	uxtb	w16, w27
     a30:      	cmp	w16, wzr
     a34:      	b.eq	0xb68 <_stogir.verify.structure+0x9d8>
     a38:      	ldr	w1, [x19]
     a3c:      	uxtb	w16, w28
     a40:      	cmp	w16, wzr
     a44:      	b.eq	0xbb0 <_stogir.verify.structure+0xa20>
     a48:      	uxtb	w16, w20
     a4c:      	cmp	w16, wzr
     a50:      	b.eq	0xa58 <_stogir.verify.structure+0x8c8>
     a54:      	mov	x21, #0x4               ; =4
     a58:      	lsl	x6, x21, #2
     a5c:      	lsr	w6, w6, #0
     a60:      	ubfx	x6, x6, #0, #32
     a64:      	lsr	x1, x1, x6
     a68:      	lsr	w1, w1, #0
     a6c:      	and	x1, x1, #0xf
     a70:      	lsr	w1, w1, #0
     a74:      	b	0xbb4 <_stogir.verify.structure+0xa24>
     a78:      	cmp	x24, #0x0
     a7c:      	b.le	0xd98 <_stogir.verify.structure+0xc08>
     a80:      	ldr	x1, [x23, #0x8]
     a84:      	cmp	x24, x1
     a88:      	b.ge	0xda0 <_stogir.verify.structure+0xc10>
     a8c:      	ldr	x2, [sp, #0xc8]
     a90:      	ldr	x1, [x2, #0x8]
     a94:      	cmp	x24, x1
     a98:      	b.ge	0xbc0 <_stogir.verify.structure+0xa30>
     a9c:      	ldr	x1, [x23, #0x78]
     aa0:      	add	x1, x1, x24, lsl #2
     aa4:      	ldr	w1, [x1]
     aa8:      	sxtw	x1, w1
     aac:      	cmp	x1, #0x0
     ab0:      	cset	w1, ge
     ab4:      	ubfx	x1, x1, #0, #8
     ab8:      	b	0xbc4 <_stogir.verify.structure+0xa34>
     abc:      	ldr	w1, [sp, #0x148]
     ac0:      	uxtb	w16, w1
     ac4:      	cmp	w16, wzr
     ac8:      	b.eq	0xda8 <_stogir.verify.structure+0xc18>
     acc:      	ldr	w6, [sp, #0x140]
     ad0:      	uxtb	w16, w6
     ad4:      	cmp	w16, wzr
     ad8:      	b.eq	0xae8 <_stogir.verify.structure+0x958>
     adc:      	ldr	x7, [sp, #0x138]
     ae0:      	cmp	x7, #0x2
     ae4:      	b.eq	0x5b0 <_stogir.verify.structure+0x420>
     ae8:      	ldr	x17, [sp, #0x70]
     aec:      	str	x17, [sp, #0xa8]
     af0:      	mov	x16, #0x1a              ; =26
     af4:      	str	x16, [sp, #0x118]
     af8:      	b	0x5b0 <_stogir.verify.structure+0x420>
     afc:      	movz	x1, #0x0, lsl #48
     b00:      	ldr	x4, [sp, #0xb8]
     b04:      	ldr	x5, [sp, #0xb0]
     b08:      	b	0x5a0 <_stogir.verify.structure+0x410>
     b0c:      	cmp	x24, #0x0
     b10:      	b.ge	0xdb0 <_stogir.verify.structure+0xc20>
     b14:      	ldr	x4, [sp, #0xb8]
     b18:      	ldr	x1, [x4, #0x8]
     b1c:      	ldr	x5, [sp, #0xb0]
     b20:      	ldr	x6, [x5, #0x8]
     b24:      	cmp	x1, x6
     b28:      	b.ne	0xbb8 <_stogir.verify.structure+0xa28>
     b2c:      	movz	x16, #0x0, lsl #48
     b30:      	sub	x6, x16, x24
     b34:      	cmp	x6, x1
     b38:      	b.gt	0xbe8 <_stogir.verify.structure+0xa58>
     b3c:      	sub	x1, x6, #0x1
     b40:      	ldr	x6, [x23, #0x50]
     b44:      	add	x1, x6, x1, lsl #2
     b48:      	ldr	w1, [x1]
     b4c:      	sxtw	x1, w1
     b50:      	cmp	x1, #0x0
     b54:      	cset	w1, gt
     b58:      	ubfx	x1, x1, #0, #8
     b5c:      	b	0xbec <_stogir.verify.structure+0xa5c>
     b60:      	brk	#0
     b64:      	b	0xb60 <_stogir.verify.structure+0x9d0>
     b68:      	movz	x1, #0x0, lsl #48
     b6c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b6c:  ARM64_RELOC_PAGE21	l_stogir.321
     b70:      	ldr	x16, [x16]
		0000000000000b70:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     b74:      	ldr	w6, [x16]
     b78:      	lsr	w1, w1, #0
     b7c:      	cmp	x1, x6
     b80:      	b.ne	0xb90 <_stogir.verify.structure+0xa00>
     b84:      	ldr	w1, [sp, #0x148]
     b88:      	ldr	w6, [sp, #0x140]
     b8c:      	b	0x5b0 <_stogir.verify.structure+0x420>
     b90:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b90:  ARM64_RELOC_PAGE21	l_stogir.322
     b94:      	ldr	x16, [x16]
		0000000000000b94:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     b98:      	ldr	w6, [x16]
     b9c:      	cmp	x1, x6
     ba0:      	b.ne	0xbc8 <_stogir.verify.structure+0xa38>
     ba4:      	ldr	w1, [sp, #0x148]
     ba8:      	ldr	w6, [sp, #0x140]
     bac:      	b	0x5b0 <_stogir.verify.structure+0x420>
     bb0:      	movz	x1, #0x0, lsl #48
     bb4:      	b	0xb6c <_stogir.verify.structure+0x9dc>
     bb8:      	movz	x1, #0x0, lsl #48
     bbc:      	b	0x5a0 <_stogir.verify.structure+0x410>
     bc0:      	movz	x1, #0x0, lsl #48
     bc4:      	b	0xb00 <_stogir.verify.structure+0x970>
     bc8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bc8:  ARM64_RELOC_PAGE21	l_stogir.323
     bcc:      	ldr	x16, [x16]
		0000000000000bcc:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     bd0:      	ldr	w6, [x16]
     bd4:      	cmp	x1, x6
     bd8:      	b.ne	0xabc <_stogir.verify.structure+0x92c>
     bdc:      	ldr	w1, [sp, #0x148]
     be0:      	ldr	w6, [sp, #0x140]
     be4:      	b	0x5b0 <_stogir.verify.structure+0x420>
     be8:      	movz	x1, #0x0, lsl #48
     bec:      	b	0xbbc <_stogir.verify.structure+0xa2c>
     bf0:      	brk	#0
     bf4:      	b	0xbf0 <_stogir.verify.structure+0xa60>
     bf8:      	mov	x1, x13
     bfc:      	str	x8, [sp, #0xa0]
     c00:      	str	x19, [sp, #0xa8]
     c04:      	str	x20, [sp, #0x118]
     c08:      	b	0x510 <_stogir.verify.structure+0x380>
     c0c:      	mov	x1, x13
     c10:      	str	x8, [sp, #0xa0]
     c14:      	str	x19, [sp, #0xa8]
     c18:      	str	x20, [sp, #0x118]
     c1c:      	b	0x510 <_stogir.verify.structure+0x380>
     c20:      	str	x8, [sp, #0xa0]
     c24:      	str	x21, [sp, #0x40]
     c28:      	str	x22, [sp, #0x58]
     c2c:      	str	x23, [sp, #0x60]
     c30:      	mov	x23, x0
     c34:      	str	x24, [sp, #0x78]
     c38:      	str	x25, [sp, #0x80]
     c3c:      	str	x26, [sp, #0x88]
     c40:      	str	x27, [sp, #0x90]
     c44:      	str	x28, [sp, #0x98]
     c48:      	str	x1, [sp, #0x68]
     c4c:      	mov	x1, x13
     c50:      	str	x2, [sp, #0x70]
     c54:      	str	x4, [sp, #0x100]
     c58:      	mov	x0, x11
     c5c:      	mov	x2, x5
     c60:      	mov	x4, x6
     c64:      	mov	x6, x12
     c68:      	mov	x5, x7
     c6c:      	str	x9, [sp, #0xe8]
     c70:      	str	x10, [sp, #0xf8]
     c74:      	b	0x344 <_stogir.verify.structure+0x1b4>
     c78:      	str	x8, [sp, #0xa0]
     c7c:      	str	x22, [sp, #0x58]
     c80:      	str	x23, [sp, #0x60]
     c84:      	ldr	x23, [sp, #0x30]
     c88:      	str	x24, [sp, #0x78]
     c8c:      	str	x25, [sp, #0x80]
     c90:      	str	x26, [sp, #0x88]
     c94:      	str	x27, [sp, #0x90]
     c98:      	str	x28, [sp, #0x98]
     c9c:      	str	x1, [sp, #0x68]
     ca0:      	mov	x1, x13
     ca4:      	str	x2, [sp, #0x70]
     ca8:      	str	x4, [sp, #0x100]
     cac:      	mov	x0, x11
     cb0:      	mov	x2, x5
     cb4:      	mov	x4, x6
     cb8:      	mov	x6, x12
     cbc:      	mov	x5, x7
     cc0:      	str	x9, [sp, #0xe8]
     cc4:      	str	x10, [sp, #0xf8]
     cc8:      	b	0x2dc <_stogir.verify.structure+0x14c>
     ccc:      	mov	x6, x27
     cd0:      	ldr	x1, [sp, #0xc0]
     cd4:      	ldr	x3, [sp, #0xd0]
     cd8:      	str	x25, [sp, #0x100]
     cdc:      	ldr	x0, [sp, #0xd8]
     ce0:      	ldr	x2, [sp, #0xc8]
     ce4:      	ldr	x4, [sp, #0xb8]
     ce8:      	ldr	x5, [sp, #0xb0]
     cec:      	str	x19, [sp, #0xf8]
     cf0:      	b	0x2dc <_stogir.verify.structure+0x14c>
     cf4:      	ldr	x1, [sp, #0xa8]
     cf8:      	b	0x52c <_stogir.verify.structure+0x39c>
     cfc:      	str	x27, [sp, #0x128]
     d00:      	str	x21, [sp, #0x120]
     d04:      	ldr	x3, [sp, #0xd0]
     d08:      	str	x20, [sp, #0x118]
     d0c:      	str	x25, [sp, #0x100]
     d10:      	ldr	x0, [sp, #0xd8]
     d14:      	ldr	x4, [sp, #0xb8]
     d18:      	ldr	x5, [sp, #0xb0]
     d1c:      	str	x2, [sp, #0xe8]
     d20:      	ldr	x2, [sp, #0xc8]
     d24:      	str	x19, [sp, #0xf8]
     d28:      	b	0x1f0 <_stogir.verify.structure+0x60>
     d2c:      	str	x26, [sp, #0x138]
     d30:      	mov	x26, x2
     d34:      	str	w24, [sp, #0x148]
     d38:      	mov	w24, w1
     d3c:      	str	w22, [sp, #0x140]
     d40:      	mov	x22, x0
     d44:      	b	0x790 <_stogir.verify.structure+0x600>
     d48:      	ldr	x3, [sp, #0xd0]
     d4c:      	ldr	x0, [sp, #0xd8]
     d50:      	b	0x888 <_stogir.verify.structure+0x6f8>
     d54:      	ldr	x2, [sp, #0xc8]
     d58:      	ldr	x4, [sp, #0xb8]
     d5c:      	ldr	x5, [sp, #0xb0]
     d60:      	ldr	w1, [sp, #0x148]
     d64:      	ldr	w6, [sp, #0x140]
     d68:      	b	0x5b0 <_stogir.verify.structure+0x420>
     d6c:      	ldr	x2, [sp, #0xc8]
     d70:      	ldr	x4, [sp, #0xb8]
     d74:      	ldr	x5, [sp, #0xb0]
     d78:      	ldr	w1, [sp, #0x148]
     d7c:      	ldr	w6, [sp, #0x140]
     d80:      	b	0x5b0 <_stogir.verify.structure+0x420>
     d84:      	ldr	x3, [sp, #0xd0]
     d88:      	b	0x844 <_stogir.verify.structure+0x6b4>
     d8c:      	ldr	w1, [sp, #0x148]
     d90:      	ldr	w6, [sp, #0x140]
     d94:      	b	0xae8 <_stogir.verify.structure+0x958>
     d98:      	ldr	x2, [sp, #0xc8]
     d9c:      	b	0xb0c <_stogir.verify.structure+0x97c>
     da0:      	ldr	x2, [sp, #0xc8]
     da4:      	b	0xafc <_stogir.verify.structure+0x96c>
     da8:      	ldr	w6, [sp, #0x140]
     dac:      	b	0xae8 <_stogir.verify.structure+0x958>
     db0:      	ldr	x4, [sp, #0xb8]
     db4:      	ldr	x5, [sp, #0xb0]
     db8:      	b	0x59c <_stogir.verify.structure+0x40c>

0000000000000dbc <_stogir.verify.integer-operations-target-structured>:
     dbc:      	sub	sp, sp, #0x3d0
     dc0:      	str	x29, [sp, #0x10]
     dc4:      	str	x30, [sp, #0x18]
     dc8:      	add	x29, sp, #0x10
     dcc:      	str	x19, [sp, #0x380]
     dd0:      	str	x20, [sp, #0x388]
     dd4:      	str	x21, [sp, #0x390]
     dd8:      	str	x22, [sp, #0x398]
     ddc:      	str	x23, [sp, #0x3a0]
     de0:      	str	x24, [sp, #0x3a8]
     de4:      	str	x25, [sp, #0x3b0]
     de8:      	str	x26, [sp, #0x3b8]
     dec:      	str	x27, [sp, #0x3c0]
     df0:      	str	x28, [sp, #0x3c8]
     df4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000df4:  ARM64_RELOC_PAGE21	l_stogir.324
     df8:      	ldr	x16, [x16]
		0000000000000df8:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     dfc:      	orr	x19, x16, xzr
     e00:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e00:  ARM64_RELOC_PAGE21	l_stogir.325
     e04:      	ldr	x16, [x16]
		0000000000000e04:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     e08:      	orr	x20, x16, xzr
     e0c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e0c:  ARM64_RELOC_PAGE21	l_stogir.326
     e10:      	ldr	x16, [x16]
		0000000000000e10:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     e14:      	orr	x21, x16, xzr
     e18:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e18:  ARM64_RELOC_PAGE21	l_stogir.327
     e1c:      	ldr	x16, [x16]
		0000000000000e1c:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     e20:      	orr	x22, x16, xzr
     e24:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e24:  ARM64_RELOC_PAGE21	l_stogir.328
     e28:      	ldr	x16, [x16]
		0000000000000e28:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     e2c:      	orr	x23, x16, xzr
     e30:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e30:  ARM64_RELOC_PAGE21	l_stogir.329
     e34:      	ldr	x16, [x16]
		0000000000000e34:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     e38:      	orr	x24, x16, xzr
     e3c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e3c:  ARM64_RELOC_PAGE21	l_stogir.330
     e40:      	ldr	x16, [x16]
		0000000000000e40:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     e44:      	orr	x25, x16, xzr
     e48:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e48:  ARM64_RELOC_PAGE21	l_stogir.331
     e4c:      	ldr	x16, [x16]
		0000000000000e4c:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     e50:      	orr	x26, x16, xzr
     e54:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e54:  ARM64_RELOC_PAGE21	l_stogir.332
     e58:      	ldr	x16, [x16]
		0000000000000e58:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     e5c:      	orr	x27, x16, xzr
     e60:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e60:  ARM64_RELOC_PAGE21	l_stogir.333
     e64:      	ldr	x16, [x16]
		0000000000000e64:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     e68:      	orr	x28, x16, xzr
     e6c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e6c:  ARM64_RELOC_PAGE21	l_stogir.334
     e70:      	ldr	x16, [x16]
		0000000000000e70:  ARM64_RELOC_PAGEOFF12	l_stogir.334
     e74:      	orr	x2, x16, xzr
     e78:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e78:  ARM64_RELOC_PAGE21	l_stogir.335
     e7c:      	ldr	x16, [x16]
		0000000000000e7c:  ARM64_RELOC_PAGEOFF12	l_stogir.335
     e80:      	orr	x3, x16, xzr
     e84:      	lsr	w4, w1, #0
     e88:      	lsr	w5, w1, #0
     e8c:      	lsr	w1, w1, #0
     e90:      	add	x16, sp, #0x20
     e94:      	orr	x6, x16, xzr
     e98:      	add	x16, sp, #0x30
     e9c:      	orr	x7, x16, xzr
     ea0:      	add	x7, x7, #0x8
     ea4:      	add	x16, sp, #0x50
     ea8:      	orr	x9, x16, xzr
     eac:      	add	x9, x9, #0x8
     eb0:      	add	x16, sp, #0xe0
     eb4:      	orr	x10, x16, xzr
     eb8:      	add	x10, x10, #0x8
     ebc:      	add	x16, sp, #0x100
     ec0:      	orr	x11, x16, xzr
     ec4:      	add	x11, x11, #0x8
     ec8:      	add	x16, sp, #0x120
     ecc:      	orr	x12, x16, xzr
     ed0:      	add	x12, x12, #0x8
     ed4:      	add	x16, sp, #0x140
     ed8:      	orr	x13, x16, xzr
     edc:      	add	x13, x13, #0x8
     ee0:      	add	x16, sp, #0x160
     ee4:      	orr	x14, x16, xzr
     ee8:      	add	x14, x14, #0x8
     eec:      	add	x16, sp, #0x180
     ef0:      	orr	x15, x16, xzr
     ef4:      	add	x15, x15, #0x8
     ef8:      	str	w1, [sp, #0x230]
     efc:      	add	x16, sp, #0x1a0
     f00:      	orr	x1, x16, xzr
     f04:      	add	x1, x1, #0x8
     f08:      	str	x1, [sp, #0x238]
     f0c:      	add	x16, sp, #0x1f0
     f10:      	orr	x1, x16, xzr
     f14:      	add	x1, x1, #0x8
     f18:      	str	x20, [sp, #0x240]
     f1c:      	str	x21, [sp, #0x248]
     f20:      	str	x22, [sp, #0x250]
     f24:      	mov	x20, #0x1               ; =1
     f28:      	movz	x21, #0x0, lsl #48
     f2c:      	movz	x22, #0x0, lsl #48
     f30:      	cmp	x22, #0x0
     f34:      	b.ne	0x1f08 <_stogir.verify.integer-operations-target-structured+0x114c>
     f38:      	str	x1, [sp, #0x258]
     f3c:      	ldr	x1, [x0, #0x8]
     f40:      	cmp	x20, x1
     f44:      	b.ge	0x1f14 <_stogir.verify.integer-operations-target-structured+0x1158>
     f48:      	ldr	x1, [x0]
     f4c:      	add	x1, x1, x20, lsl #4
     f50:      	str	x2, [sp, #0x260]
     f54:      	ldr	x2, [x1]
     f58:      	str	x23, [sp, #0x268]
     f5c:      	uxtb	w23, w2
     f60:      	ldr	x1, [x1, #0x8]
     f64:      	str	x24, [sp, #0x270]
     f68:      	orr	x24, x23, xzr
     f6c:      	add	x16, sp, #0x20
     f70:      	str	x2, [x16]
     f74:      	add	x16, sp, #0x20
     f78:      	str	x1, [x16, #0x8]
     f7c:      	ldr	x1, [x0, #0x78]
     f80:      	add	x1, x1, x20, lsl #2
     f84:      	ldr	w1, [x1]
     f88:      	cmp	x24, #0xe
     f8c:      	b.lt	0x1678 <_stogir.verify.integer-operations-target-structured+0x8bc>
     f90:      	cmp	x24, #0x17
     f94:      	cset	w2, le
     f98:      	ubfx	x2, x2, #0, #8
     f9c:      	str	x25, [sp, #0x278]
     fa0:      	cmp	x24, #0x1a
     fa4:      	cset	w25, ge
     fa8:      	str	x26, [sp, #0x280]
     fac:      	cmp	x24, #0x1e
     fb0:      	cset	w26, le
     fb4:      	str	x27, [sp, #0x288]
     fb8:      	cmp	x24, #0x2e
     fbc:      	cset	w27, ge
     fc0:      	str	x28, [sp, #0x290]
     fc4:      	cmp	x24, #0x35
     fc8:      	cset	w28, le
     fcc:      	str	w23, [sp, #0x298]
     fd0:      	cmp	x24, #0x3a
     fd4:      	cset	w23, eq
     fd8:      	str	x21, [sp, #0x2a0]
     fdc:      	cmp	x24, #0x3b
     fe0:      	cset	w21, eq
     fe4:      	uxtb	w16, w25
     fe8:      	cmp	w16, wzr
     fec:      	b.eq	0x1680 <_stogir.verify.integer-operations-target-structured+0x8c4>
     ff0:      	uxtb	w16, w26
     ff4:      	cmp	w16, wzr
     ff8:      	b.eq	0x1680 <_stogir.verify.integer-operations-target-structured+0x8c4>
     ffc:      	str	w21, [sp, #0x2a8]
    1000:      	mov	x21, #0x1               ; =1
    1004:      	cmp	x24, #0x1f
    1008:      	b.ne	0x16c8 <_stogir.verify.integer-operations-target-structured+0x90c>
    100c:      	str	x0, [sp, #0x2b0]
    1010:      	mov	x0, #0x1                ; =1
    1014:      	str	x0, [sp, #0x2b8]
    1018:      	lsr	w0, w20, #0
    101c:      	lsr	w1, w1, #0
    1020:      	lsr	w0, w0, #0
    1024:      	str	x8, [sp, #0x2c0]
    1028:      	str	w4, [sp, #0x2d0]
    102c:      	str	w5, [sp, #0x2d8]
    1030:      	str	x6, [sp, #0x2e0]
    1034:      	str	x14, [sp, #0x318]
    1038:      	str	x15, [sp, #0x320]
    103c:      	str	w1, [sp, #0x328]
    1040:      	str	x2, [sp, #0x330]
    1044:      	mov	x2, x6
    1048:      	str	w0, [sp, #0x338]
    104c:      	str	x20, [sp, #0x2c8]
    1050:      	mov	x20, x3
    1054:      	mov	w3, w1
    1058:      	mov	w1, w0
    105c:      	ldr	x0, [sp, #0x2b0]
    1060:      	str	w23, [sp, #0x2e8]
    1064:      	mov	x23, x7
    1068:      	str	w28, [sp, #0x2f0]
    106c:      	mov	x28, x9
    1070:      	str	w27, [sp, #0x2f8]
    1074:      	mov	x27, x10
    1078:      	str	w26, [sp, #0x300]
    107c:      	mov	x26, x11
    1080:      	str	w25, [sp, #0x308]
    1084:      	mov	x25, x12
    1088:      	str	x21, [sp, #0x310]
    108c:      	mov	x21, x13
    1090:      	bl	0x1090 <_stogir.verify.integer-operations-target-structured+0x2d4>
		0000000000001090:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    1094:      	uxtb	w1, w0
    1098:      	cmp	x1, #0x0
    109c:      	cset	w1, ne
    10a0:      	cmp	x24, #0x3d
    10a4:      	b.lt	0x1740 <_stogir.verify.integer-operations-target-structured+0x984>
    10a8:      	cmp	x24, #0x3f
    10ac:      	b.gt	0x1740 <_stogir.verify.integer-operations-target-structured+0x984>
    10b0:      	add	x8, sp, #0x30
    10b4:      	ldr	w2, [sp, #0x2d0]
    10b8:      	str	x0, [sp, #0x340]
    10bc:      	ldr	x0, [sp, #0x2b0]
    10c0:      	str	x21, [sp, #0x348]
    10c4:      	mov	w21, w1
    10c8:      	ldr	w1, [sp, #0x338]
    10cc:      	bl	0x10cc <_stogir.verify.integer-operations-target-structured+0x310>
		00000000000010cc:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    10d0:      	add	x16, sp, #0x30
    10d4:      	ldr	w0, [x16]
    10d8:      	lsr	x16, x0, #0
    10dc:      	cmp	x16, #0x1
    10e0:      	b.eq	0x10fc <_stogir.verify.integer-operations-target-structured+0x340>
    10e4:      	b.lo	0x10ec <_stogir.verify.integer-operations-target-structured+0x330>
    10e8:      	b	0x1100 <_stogir.verify.integer-operations-target-structured+0x344>
    10ec:      	cmp	x16, #0x0
    10f0:      	b.eq	0x10f8 <_stogir.verify.integer-operations-target-structured+0x33c>
    10f4:      	b	0x1100 <_stogir.verify.integer-operations-target-structured+0x344>
    10f8:      	b	0x1760 <_stogir.verify.integer-operations-target-structured+0x9a4>
    10fc:      	b	0x1104 <_stogir.verify.integer-operations-target-structured+0x348>
    1100:      	b	0x1e9c <_stogir.verify.integer-operations-target-structured+0x10e0>
    1104:      	add	x16, sp, #0x30
    1108:      	ldr	x19, [x16, #0x8]
    110c:      	ldr	x22, [x23, #0x8]
    1110:      	ldr	x0, [sp, #0x2a0]
    1114:      	cmp	x24, #0x44
    1118:      	b.ne	0x177c <_stogir.verify.integer-operations-target-structured+0x9c0>
    111c:      	uxtb	w16, w21
    1120:      	cmp	w16, wzr
    1124:      	b.eq	0x1774 <_stogir.verify.integer-operations-target-structured+0x9b8>
    1128:      	movz	x1, #0x0, lsl #48
    112c:      	cmp	x1, #0x0
    1130:      	b.eq	0x1f20 <_stogir.verify.integer-operations-target-structured+0x1164>
    1134:      	add	x8, sp, #0x50
    1138:      	ldr	w1, [sp, #0x338]
    113c:      	str	x23, [sp, #0x350]
    1140:      	mov	x23, x0
    1144:      	ldr	x0, [sp, #0x2b0]
    1148:      	bl	0x1148 <_stogir.verify.integer-operations-target-structured+0x38c>
		0000000000001148:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    114c:      	add	x16, sp, #0x50
    1150:      	ldr	w0, [x16]
    1154:      	lsr	x16, x0, #0
    1158:      	cmp	x16, #0x1
    115c:      	b.eq	0x1178 <_stogir.verify.integer-operations-target-structured+0x3bc>
    1160:      	b.lo	0x1168 <_stogir.verify.integer-operations-target-structured+0x3ac>
    1164:      	b	0x117c <_stogir.verify.integer-operations-target-structured+0x3c0>
    1168:      	cmp	x16, #0x0
    116c:      	b.eq	0x1174 <_stogir.verify.integer-operations-target-structured+0x3b8>
    1170:      	b	0x117c <_stogir.verify.integer-operations-target-structured+0x3c0>
    1174:      	b	0x1784 <_stogir.verify.integer-operations-target-structured+0x9c8>
    1178:      	b	0x1180 <_stogir.verify.integer-operations-target-structured+0x3c4>
    117c:      	b	0x1794 <_stogir.verify.integer-operations-target-structured+0x9d8>
    1180:      	add	x16, sp, #0x50
    1184:      	ldr	x19, [x16, #0x8]
    1188:      	ldr	x22, [x28, #0x8]
    118c:      	cmp	x24, #0x1d
    1190:      	b.ne	0x179c <_stogir.verify.integer-operations-target-structured+0x9e0>
    1194:      	mov	x0, #0x1                ; =1
    1198:      	cmp	x0, #0x0
    119c:      	b.eq	0x17b4 <_stogir.verify.integer-operations-target-structured+0x9f8>
    11a0:      	add	x16, sp, #0x20
    11a4:      	ldr	w0, [x16, #0xc]
    11a8:      	sxtw	x0, w0
    11ac:      	cmp	x0, #0x0
    11b0:      	b.ne	0x17ac <_stogir.verify.integer-operations-target-structured+0x9f0>
    11b4:      	movz	x0, #0x0, lsl #48
    11b8:      	cmp	x0, #0x0
    11bc:      	b.eq	0x1218 <_stogir.verify.integer-operations-target-structured+0x45c>
    11c0:      	add	x16, sp, #0x20
    11c4:      	ldr	w0, [x16, #0xc]
    11c8:      	lsr	w0, w0, #0
    11cc:      	add	x8, sp, #0x70
    11d0:      	mov	w1, w0
    11d4:      	ldr	x0, [sp, #0x2b0]
    11d8:      	bl	0x11d8 <_stogir.verify.integer-operations-target-structured+0x41c>
		00000000000011d8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    11dc:      	add	x16, sp, #0x70
    11e0:      	ldr	w0, [x16]
    11e4:      	lsr	x16, x0, #0
    11e8:      	cmp	x16, #0x1
    11ec:      	b.eq	0x1208 <_stogir.verify.integer-operations-target-structured+0x44c>
    11f0:      	b.lo	0x11f8 <_stogir.verify.integer-operations-target-structured+0x43c>
    11f4:      	b	0x120c <_stogir.verify.integer-operations-target-structured+0x450>
    11f8:      	cmp	x16, #0x0
    11fc:      	b.eq	0x1204 <_stogir.verify.integer-operations-target-structured+0x448>
    1200:      	b	0x120c <_stogir.verify.integer-operations-target-structured+0x450>
    1204:      	b	0x1210 <_stogir.verify.integer-operations-target-structured+0x454>
    1208:      	b	0x17bc <_stogir.verify.integer-operations-target-structured+0xa00>
    120c:      	b	0x1854 <_stogir.verify.integer-operations-target-structured+0xa98>
    1210:      	ldr	x19, [sp, #0x240]
    1214:      	mov	x22, #0x16              ; =22
    1218:      	cmp	x24, #0x2c
    121c:      	cset	w0, eq
    1220:      	cmp	x24, #0x29
    1224:      	b.lt	0x185c <_stogir.verify.integer-operations-target-structured+0xaa0>
    1228:      	cmp	x24, #0x2b
    122c:      	b.gt	0x185c <_stogir.verify.integer-operations-target-structured+0xaa0>
    1230:      	uxtb	w16, w0
    1234:      	cmp	w16, wzr
    1238:      	b.eq	0x186c <_stogir.verify.integer-operations-target-structured+0xab0>
    123c:      	add	x8, sp, #0xa0
    1240:      	ldr	x0, [sp, #0x2b0]
    1244:      	ldr	w1, [sp, #0x338]
    1248:      	bl	0x1248 <_stogir.verify.integer-operations-target-structured+0x48c>
		0000000000001248:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    124c:      	add	x16, sp, #0xa0
    1250:      	ldr	x0, [x16]
    1254:      	add	x16, sp, #0xa0
    1258:      	ldr	x1, [x16, #0x8]
    125c:      	add	x16, sp, #0xa0
    1260:      	ldr	x2, [x16, #0x10]
    1264:      	lsr	w0, w0, #0
    1268:      	lsr	x16, x0, #0
    126c:      	cmp	x16, #0x1
    1270:      	b.eq	0x128c <_stogir.verify.integer-operations-target-structured+0x4d0>
    1274:      	b.lo	0x127c <_stogir.verify.integer-operations-target-structured+0x4c0>
    1278:      	b	0x1290 <_stogir.verify.integer-operations-target-structured+0x4d4>
    127c:      	cmp	x16, #0x0
    1280:      	b.eq	0x1288 <_stogir.verify.integer-operations-target-structured+0x4cc>
    1284:      	b	0x1290 <_stogir.verify.integer-operations-target-structured+0x4d4>
    1288:      	b	0x1898 <_stogir.verify.integer-operations-target-structured+0xadc>
    128c:      	b	0x1294 <_stogir.verify.integer-operations-target-structured+0x4d8>
    1290:      	b	0x1e94 <_stogir.verify.integer-operations-target-structured+0x10d8>
    1294:      	mov	x19, x1
    1298:      	mov	x22, x2
    129c:      	cmp	x24, #0x7e
    12a0:      	b.lt	0x12fc <_stogir.verify.integer-operations-target-structured+0x540>
    12a4:      	cmp	x24, #0x82
    12a8:      	b.gt	0x12fc <_stogir.verify.integer-operations-target-structured+0x540>
    12ac:      	add	x8, sp, #0xe0
    12b0:      	ldr	x0, [sp, #0x2b0]
    12b4:      	ldr	w1, [sp, #0x338]
    12b8:      	bl	0x12b8 <_stogir.verify.integer-operations-target-structured+0x4fc>
		00000000000012b8:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    12bc:      	add	x16, sp, #0xe0
    12c0:      	ldr	w0, [x16]
    12c4:      	lsr	x16, x0, #0
    12c8:      	cmp	x16, #0x1
    12cc:      	b.eq	0x12e8 <_stogir.verify.integer-operations-target-structured+0x52c>
    12d0:      	b.lo	0x12d8 <_stogir.verify.integer-operations-target-structured+0x51c>
    12d4:      	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x530>
    12d8:      	cmp	x16, #0x0
    12dc:      	b.eq	0x12e4 <_stogir.verify.integer-operations-target-structured+0x528>
    12e0:      	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x530>
    12e4:      	b	0x18a8 <_stogir.verify.integer-operations-target-structured+0xaec>
    12e8:      	b	0x12f0 <_stogir.verify.integer-operations-target-structured+0x534>
    12ec:      	b	0x18b8 <_stogir.verify.integer-operations-target-structured+0xafc>
    12f0:      	add	x16, sp, #0xe0
    12f4:      	ldr	x19, [x16, #0x8]
    12f8:      	ldr	x22, [x27, #0x8]
    12fc:      	cmp	x24, #0x60
    1300:      	b.eq	0x18c0 <_stogir.verify.integer-operations-target-structured+0xb04>
    1304:      	cmp	x24, #0x79
    1308:      	b.eq	0x18c0 <_stogir.verify.integer-operations-target-structured+0xb04>
    130c:      	cmp	x24, #0x75
    1310:      	b.eq	0x1924 <_stogir.verify.integer-operations-target-structured+0xb68>
    1314:      	cmp	x24, #0x6d
    1318:      	b.lt	0x1324 <_stogir.verify.integer-operations-target-structured+0x568>
    131c:      	cmp	x24, #0x6f
    1320:      	b.le	0x1924 <_stogir.verify.integer-operations-target-structured+0xb68>
    1324:      	cmp	x24, #0x42
    1328:      	b.eq	0x1990 <_stogir.verify.integer-operations-target-structured+0xbd4>
    132c:      	cmp	x24, #0x51
    1330:      	b.eq	0x1990 <_stogir.verify.integer-operations-target-structured+0xbd4>
    1334:      	cmp	x24, #0x52
    1338:      	b.eq	0x1990 <_stogir.verify.integer-operations-target-structured+0xbd4>
    133c:      	cmp	x24, #0x53
    1340:      	b.eq	0x1990 <_stogir.verify.integer-operations-target-structured+0xbd4>
    1344:      	cmp	x24, #0x54
    1348:      	b.eq	0x1990 <_stogir.verify.integer-operations-target-structured+0xbd4>
    134c:      	ldr	x0, [sp, #0x348]
    1350:      	cmp	x24, #0x41
    1354:      	b.eq	0x19fc <_stogir.verify.integer-operations-target-structured+0xc40>
    1358:      	cmp	x24, #0x48
    135c:      	b.eq	0x19fc <_stogir.verify.integer-operations-target-structured+0xc40>
    1360:      	cmp	x24, #0x55
    1364:      	b.lt	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1170>
    1368:      	cmp	x24, #0x58
    136c:      	b.le	0x19fc <_stogir.verify.integer-operations-target-structured+0xc40>
    1370:      	str	x0, [sp, #0x348]
    1374:      	ldr	x0, [sp, #0x318]
    1378:      	cmp	x24, #0x21
    137c:      	b.lt	0x1f38 <_stogir.verify.integer-operations-target-structured+0x117c>
    1380:      	cmp	x24, #0x27
    1384:      	b.gt	0x1f44 <_stogir.verify.integer-operations-target-structured+0x1188>
    1388:      	add	x8, sp, #0x180
    138c:      	ldr	w1, [sp, #0x338]
    1390:      	ldr	w2, [sp, #0x230]
    1394:      	str	x0, [sp, #0x318]
    1398:      	ldr	x0, [sp, #0x2b0]
    139c:      	bl	0x139c <_stogir.verify.integer-operations-target-structured+0x5e0>
		000000000000139c:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    13a0:      	add	x16, sp, #0x180
    13a4:      	ldr	w0, [x16]
    13a8:      	lsr	x16, x0, #0
    13ac:      	cmp	x16, #0x1
    13b0:      	b.eq	0x13d0 <_stogir.verify.integer-operations-target-structured+0x614>
    13b4:      	b.lo	0x13bc <_stogir.verify.integer-operations-target-structured+0x600>
    13b8:      	b	0x13d4 <_stogir.verify.integer-operations-target-structured+0x618>
    13bc:      	cmp	x16, #0x0
    13c0:      	b.eq	0x13c8 <_stogir.verify.integer-operations-target-structured+0x60c>
    13c4:      	b	0x13d4 <_stogir.verify.integer-operations-target-structured+0x618>
    13c8:      	ldr	x0, [sp, #0x320]
    13cc:      	b	0x1a78 <_stogir.verify.integer-operations-target-structured+0xcbc>
    13d0:      	b	0x13d8 <_stogir.verify.integer-operations-target-structured+0x61c>
    13d4:      	b	0x1a88 <_stogir.verify.integer-operations-target-structured+0xccc>
    13d8:      	add	x16, sp, #0x180
    13dc:      	ldr	x19, [x16, #0x8]
    13e0:      	ldr	x0, [sp, #0x320]
    13e4:      	ldr	x22, [x0, #0x8]
    13e8:      	cmp	x24, #0x3c
    13ec:      	b.ne	0x1f50 <_stogir.verify.integer-operations-target-structured+0x1194>
    13f0:      	add	x8, sp, #0x1a0
    13f4:      	ldr	w1, [sp, #0x338]
    13f8:      	str	x0, [sp, #0x320]
    13fc:      	ldr	x0, [sp, #0x2b0]
    1400:      	bl	0x1400 <_stogir.verify.integer-operations-target-structured+0x644>
		0000000000001400:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    1404:      	add	x16, sp, #0x1a0
    1408:      	ldr	w0, [x16]
    140c:      	lsr	x16, x0, #0
    1410:      	cmp	x16, #0x1
    1414:      	b.eq	0x1434 <_stogir.verify.integer-operations-target-structured+0x678>
    1418:      	b.lo	0x1420 <_stogir.verify.integer-operations-target-structured+0x664>
    141c:      	b	0x1438 <_stogir.verify.integer-operations-target-structured+0x67c>
    1420:      	cmp	x16, #0x0
    1424:      	b.eq	0x142c <_stogir.verify.integer-operations-target-structured+0x670>
    1428:      	b	0x1438 <_stogir.verify.integer-operations-target-structured+0x67c>
    142c:      	ldr	x0, [sp, #0x238]
    1430:      	b	0x1a90 <_stogir.verify.integer-operations-target-structured+0xcd4>
    1434:      	b	0x143c <_stogir.verify.integer-operations-target-structured+0x680>
    1438:      	b	0x1aa0 <_stogir.verify.integer-operations-target-structured+0xce4>
    143c:      	add	x16, sp, #0x1a0
    1440:      	ldr	x19, [x16, #0x8]
    1444:      	ldr	x0, [sp, #0x238]
    1448:      	ldr	x22, [x0, #0x8]
    144c:      	cmp	x24, #0x78
    1450:      	b.ne	0x1f5c <_stogir.verify.integer-operations-target-structured+0x11a0>
    1454:      	add	x16, sp, #0x20
    1458:      	ldr	w1, [x16]
    145c:      	ubfx	x1, x1, #8, #8
    1460:      	cmp	x1, #0x0
    1464:      	b.ne	0x1aa8 <_stogir.verify.integer-operations-target-structured+0xcec>
    1468:      	add	x16, sp, #0x20
    146c:      	ldr	w1, [x16, #0x8]
    1470:      	sxtw	x1, w1
    1474:      	cmp	x1, #0x0
    1478:      	b.eq	0x1484 <_stogir.verify.integer-operations-target-structured+0x6c8>
    147c:      	ldr	x19, [sp, #0x250]
    1480:      	mov	x22, #0x1f              ; =31
    1484:      	str	x0, [sp, #0x238]
    1488:      	add	x0, x23, #0x1
    148c:      	lsr	w0, w0, #0
    1490:      	sxtw	x23, w0
    1494:      	ldr	x0, [sp, #0x340]
    1498:      	uxth	w0, w0
    149c:      	mov	w17, #0x8               ; =8
    14a0:      	uxth	w16, w0
    14a4:      	ubfx	w17, w17, #0, #4
    14a8:      	lsr	w0, w16, w17
    14ac:      	uxth	w0, w0
    14b0:      	uxtb	w0, w0
    14b4:      	cmp	x0, #0x0
    14b8:      	b.eq	0x1f64 <_stogir.verify.integer-operations-target-structured+0x11a8>
    14bc:      	add	x8, sp, #0x1f0
    14c0:      	ldr	w1, [sp, #0x338]
    14c4:      	str	x20, [sp, #0x358]
    14c8:      	mov	x20, x0
    14cc:      	ldr	x0, [sp, #0x2b0]
    14d0:      	bl	0x14d0 <_stogir.verify.integer-operations-target-structured+0x714>
		00000000000014d0:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    14d4:      	add	x16, sp, #0x1f0
    14d8:      	ldr	w0, [x16]
    14dc:      	lsr	x16, x0, #0
    14e0:      	cmp	x16, #0x1
    14e4:      	b.eq	0x1504 <_stogir.verify.integer-operations-target-structured+0x748>
    14e8:      	b.lo	0x14f0 <_stogir.verify.integer-operations-target-structured+0x734>
    14ec:      	b	0x1508 <_stogir.verify.integer-operations-target-structured+0x74c>
    14f0:      	cmp	x16, #0x0
    14f4:      	b.eq	0x14fc <_stogir.verify.integer-operations-target-structured+0x740>
    14f8:      	b	0x1508 <_stogir.verify.integer-operations-target-structured+0x74c>
    14fc:      	ldr	x0, [sp, #0x258]
    1500:      	b	0x1b3c <_stogir.verify.integer-operations-target-structured+0xd80>
    1504:      	b	0x150c <_stogir.verify.integer-operations-target-structured+0x750>
    1508:      	b	0x1b4c <_stogir.verify.integer-operations-target-structured+0xd90>
    150c:      	add	x16, sp, #0x1f0
    1510:      	ldr	x19, [x16, #0x8]
    1514:      	ldr	x0, [sp, #0x258]
    1518:      	ldr	x22, [x0, #0x8]
    151c:      	uxtb	w16, w21
    1520:      	cmp	w16, wzr
    1524:      	b.eq	0x1b54 <_stogir.verify.integer-operations-target-structured+0xd98>
    1528:      	movz	x1, #0x0, lsl #48
    152c:      	cmp	x1, #0x0
    1530:      	b.eq	0x1f74 <_stogir.verify.integer-operations-target-structured+0x11b8>
    1534:      	cmp	x20, #0x0
    1538:      	b.eq	0x1b5c <_stogir.verify.integer-operations-target-structured+0xda0>
    153c:      	movz	x1, #0x0, lsl #48
    1540:      	cmp	x1, #0x0
    1544:      	b.eq	0x1f80 <_stogir.verify.integer-operations-target-structured+0x11c4>
    1548:      	ldr	x20, [sp, #0x330]
    154c:      	cmp	x20, #0x0
    1550:      	b.eq	0x1b64 <_stogir.verify.integer-operations-target-structured+0xda8>
    1554:      	ldr	x21, [sp, #0x310]
    1558:      	mov	x1, #0x1                ; =1
    155c:      	cmp	x1, #0x0
    1560:      	b.eq	0x1f8c <_stogir.verify.integer-operations-target-structured+0x11d0>
    1564:      	add	x16, sp, #0x210
    1568:      	str	x16, [sp]
    156c:      	ldr	w1, [sp, #0x338]
    1570:      	str	x0, [sp, #0x258]
    1574:      	ldr	x0, [sp, #0x2b0]
    1578:      	mov	x2, #0x1                ; =1
    157c:      	bl	0x157c <_stogir.verify.integer-operations-target-structured+0x7c0>
		000000000000157c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1580:      	ldr	x16, [sp]
    1584:      	str	x0, [x16]
    1588:      	str	x1, [x16, #0x8]
    158c:      	add	x16, sp, #0x210
    1590:      	ldr	x0, [x16]
    1594:      	add	x16, sp, #0x210
    1598:      	ldr	x1, [x16, #0x8]
    159c:      	lsr	w0, w0, #0
    15a0:      	lsr	x16, x0, #0
    15a4:      	cmp	x16, #0x1
    15a8:      	b.eq	0x15c4 <_stogir.verify.integer-operations-target-structured+0x808>
    15ac:      	b.lo	0x15b4 <_stogir.verify.integer-operations-target-structured+0x7f8>
    15b0:      	b	0x15c8 <_stogir.verify.integer-operations-target-structured+0x80c>
    15b4:      	cmp	x16, #0x0
    15b8:      	b.eq	0x15c0 <_stogir.verify.integer-operations-target-structured+0x804>
    15bc:      	b	0x15c8 <_stogir.verify.integer-operations-target-structured+0x80c>
    15c0:      	b	0x15cc <_stogir.verify.integer-operations-target-structured+0x810>
    15c4:      	b	0x1b90 <_stogir.verify.integer-operations-target-structured+0xdd4>
    15c8:      	b	0x1e7c <_stogir.verify.integer-operations-target-structured+0x10c0>
    15cc:      	str	x28, [sp, #0x378]
    15d0:      	str	x27, [sp, #0x370]
    15d4:      	str	x26, [sp, #0x368]
    15d8:      	str	x25, [sp, #0x360]
    15dc:      	ldr	x19, [sp, #0x278]
    15e0:      	mov	x22, #0x17              ; =23
    15e4:      	add	x0, x23, #0x1
    15e8:      	lsr	w0, w0, #0
    15ec:      	sxtw	x23, w0
    15f0:      	ldr	w0, [sp, #0x328]
    15f4:      	sxtw	x0, w0
    15f8:      	add	x0, x0, #0x4
    15fc:      	asr	x16, x0, #63
    1600:      	lsr	x16, x16, #62
    1604:      	add	x0, x0, x16
    1608:      	asr	x0, x0, #2
    160c:      	ldr	x1, [sp, #0x2c8]
    1610:      	add	x1, x0, x1
    1614:      	ldr	x8, [sp, #0x2c0]
    1618:      	ldr	x0, [sp, #0x2b0]
    161c:      	ldr	x6, [sp, #0x2e0]
    1620:      	ldr	x24, [sp, #0x270]
    1624:      	ldr	x25, [sp, #0x278]
    1628:      	ldr	x26, [sp, #0x280]
    162c:      	ldr	x27, [sp, #0x288]
    1630:      	ldr	x28, [sp, #0x290]
    1634:      	ldr	x2, [sp, #0x260]
    1638:      	ldr	w4, [sp, #0x2d0]
    163c:      	ldr	x7, [sp, #0x350]
    1640:      	ldr	x9, [sp, #0x378]
    1644:      	ldr	x10, [sp, #0x370]
    1648:      	ldr	x11, [sp, #0x368]
    164c:      	ldr	x12, [sp, #0x360]
    1650:      	ldr	x13, [sp, #0x348]
    1654:      	ldr	w5, [sp, #0x2d8]
    1658:      	ldr	x14, [sp, #0x318]
    165c:      	ldr	x15, [sp, #0x320]
    1660:      	ldr	x3, [sp, #0x358]
    1664:      	mov	x20, x1
    1668:      	ldr	x1, [sp, #0x258]
    166c:      	mov	x21, x23
    1670:      	ldr	x23, [sp, #0x268]
    1674:      	b	0xf30 <_stogir.verify.integer-operations-target-structured+0x174>
    1678:      	movz	x2, #0x0, lsl #48
    167c:      	b	0xf9c <_stogir.verify.integer-operations-target-structured+0x1e0>
    1680:      	uxtb	w16, w27
    1684:      	cmp	w16, wzr
    1688:      	b.eq	0x16a4 <_stogir.verify.integer-operations-target-structured+0x8e8>
    168c:      	uxtb	w16, w28
    1690:      	cmp	w16, wzr
    1694:      	b.eq	0x16a4 <_stogir.verify.integer-operations-target-structured+0x8e8>
    1698:      	str	w21, [sp, #0x2a8]
    169c:      	mov	x21, #0x1               ; =1
    16a0:      	b	0x1004 <_stogir.verify.integer-operations-target-structured+0x248>
    16a4:      	uxtb	w16, w23
    16a8:      	cmp	w16, wzr
    16ac:      	b.eq	0x16bc <_stogir.verify.integer-operations-target-structured+0x900>
    16b0:      	str	w21, [sp, #0x2a8]
    16b4:      	mov	x21, #0x1               ; =1
    16b8:      	b	0x16a0 <_stogir.verify.integer-operations-target-structured+0x8e4>
    16bc:      	str	w21, [sp, #0x2a8]
    16c0:      	ubfx	x21, x21, #0, #8
    16c4:      	b	0x16b8 <_stogir.verify.integer-operations-target-structured+0x8fc>
    16c8:      	cmp	x24, #0x20
    16cc:      	b.ne	0x16dc <_stogir.verify.integer-operations-target-structured+0x920>
    16d0:      	str	x0, [sp, #0x2b0]
    16d4:      	mov	x0, #0x1                ; =1
    16d8:      	b	0x1014 <_stogir.verify.integer-operations-target-structured+0x258>
    16dc:      	cmp	x24, #0x2d
    16e0:      	b.ne	0x16f0 <_stogir.verify.integer-operations-target-structured+0x934>
    16e4:      	str	x0, [sp, #0x2b0]
    16e8:      	mov	x0, #0x1                ; =1
    16ec:      	b	0x16d8 <_stogir.verify.integer-operations-target-structured+0x91c>
    16f0:      	cmp	x24, #0x36
    16f4:      	b.ne	0x1704 <_stogir.verify.integer-operations-target-structured+0x948>
    16f8:      	str	x0, [sp, #0x2b0]
    16fc:      	mov	x0, #0x1                ; =1
    1700:      	b	0x16ec <_stogir.verify.integer-operations-target-structured+0x930>
    1704:      	cmp	x24, #0x37
    1708:      	b.ne	0x1718 <_stogir.verify.integer-operations-target-structured+0x95c>
    170c:      	str	x0, [sp, #0x2b0]
    1710:      	mov	x0, #0x1                ; =1
    1714:      	b	0x1700 <_stogir.verify.integer-operations-target-structured+0x944>
    1718:      	cmp	x24, #0x38
    171c:      	b.ne	0x172c <_stogir.verify.integer-operations-target-structured+0x970>
    1720:      	str	x0, [sp, #0x2b0]
    1724:      	mov	x0, #0x1                ; =1
    1728:      	b	0x1714 <_stogir.verify.integer-operations-target-structured+0x958>
    172c:      	str	x0, [sp, #0x2b0]
    1730:      	cmp	x24, #0x39
    1734:      	cset	w0, eq
    1738:      	ubfx	x0, x0, #0, #8
    173c:      	b	0x1728 <_stogir.verify.integer-operations-target-structured+0x96c>
    1740:      	uxtb	w16, w1
    1744:      	cmp	w16, wzr
    1748:      	b.ne	0x10b0 <_stogir.verify.integer-operations-target-structured+0x2f4>
    174c:      	str	x0, [sp, #0x340]
    1750:      	str	x21, [sp, #0x348]
    1754:      	mov	w21, w1
    1758:      	ldr	x0, [sp, #0x2a0]
    175c:      	b	0x1114 <_stogir.verify.integer-operations-target-structured+0x358>
    1760:      	ldr	x0, [sp, #0x2a0]
    1764:      	add	x0, x0, #0x1
    1768:      	lsr	w0, w0, #0
    176c:      	sxtw	x0, w0
    1770:      	b	0x1114 <_stogir.verify.integer-operations-target-structured+0x358>
    1774:      	mov	x1, #0x1                ; =1
    1778:      	b	0x112c <_stogir.verify.integer-operations-target-structured+0x370>
    177c:      	movz	x1, #0x0, lsl #48
    1780:      	b	0x112c <_stogir.verify.integer-operations-target-structured+0x370>
    1784:      	add	x0, x23, #0x1
    1788:      	lsr	w0, w0, #0
    178c:      	sxtw	x23, w0
    1790:      	b	0x118c <_stogir.verify.integer-operations-target-structured+0x3d0>
    1794:      	brk	#0
    1798:      	b	0x1794 <_stogir.verify.integer-operations-target-structured+0x9d8>
    179c:      	cmp	x24, #0x1e
    17a0:      	cset	w0, eq
    17a4:      	ubfx	x0, x0, #0, #8
    17a8:      	b	0x1198 <_stogir.verify.integer-operations-target-structured+0x3dc>
    17ac:      	mov	x0, #0x1                ; =1
    17b0:      	b	0x11b8 <_stogir.verify.integer-operations-target-structured+0x3fc>
    17b4:      	movz	x0, #0x0, lsl #48
    17b8:      	b	0x11b8 <_stogir.verify.integer-operations-target-structured+0x3fc>
    17bc:      	add	x16, sp, #0x70
    17c0:      	ldr	x0, [x16, #0x8]
    17c4:      	add	x16, sp, #0x20
    17c8:      	ldr	w1, [x16, #0xc]
    17cc:      	sxtw	x1, w1
    17d0:      	cmp	x1, #0x0
    17d4:      	b.ge	0x17f0 <_stogir.verify.integer-operations-target-structured+0xa34>
    17d8:      	mov	x0, #0x1                ; =1
    17dc:      	cmp	x0, #0x0
    17e0:      	b.eq	0x17ec <_stogir.verify.integer-operations-target-structured+0xa30>
    17e4:      	ldr	x19, [sp, #0x248]
    17e8:      	mov	x22, #0x2d              ; =45
    17ec:      	b	0x1218 <_stogir.verify.integer-operations-target-structured+0x45c>
    17f0:      	uxtb	w0, w0
    17f4:      	cmp	x0, #0x83
    17f8:      	b.ge	0x1844 <_stogir.verify.integer-operations-target-structured+0xa88>
    17fc:      	add	x1, x0, x20
    1800:      	ldrb	w1, [x1]
    1804:      	uxtb	w1, w1
    1808:      	and	x1, x1, #0x2
    180c:      	uxtb	w1, w1
    1810:      	cmp	x1, #0x0
    1814:      	cset	w1, eq
    1818:      	uxtb	w16, w1
    181c:      	cmp	w16, wzr
    1820:      	cset	x1, eq
    1824:      	cmp	x1, #0x0
    1828:      	b.ne	0x184c <_stogir.verify.integer-operations-target-structured+0xa90>
    182c:      	cmp	x0, #0x65
    1830:      	b.eq	0x184c <_stogir.verify.integer-operations-target-structured+0xa90>
    1834:      	cmp	x0, #0x66
    1838:      	b.eq	0x184c <_stogir.verify.integer-operations-target-structured+0xa90>
    183c:      	mov	x0, #0x1                ; =1
    1840:      	b	0x17dc <_stogir.verify.integer-operations-target-structured+0xa20>
    1844:      	movz	x1, #0x0, lsl #48
    1848:      	b	0x1804 <_stogir.verify.integer-operations-target-structured+0xa48>
    184c:      	movz	x0, #0x0, lsl #48
    1850:      	b	0x1840 <_stogir.verify.integer-operations-target-structured+0xa84>
    1854:      	brk	#0
    1858:      	b	0x1854 <_stogir.verify.integer-operations-target-structured+0xa98>
    185c:      	uxtb	w16, w0
    1860:      	cmp	w16, wzr
    1864:      	b.ne	0x1230 <_stogir.verify.integer-operations-target-structured+0x474>
    1868:      	b	0x129c <_stogir.verify.integer-operations-target-structured+0x4e0>
    186c:      	add	x8, sp, #0xc0
    1870:      	ldr	x0, [sp, #0x2b0]
    1874:      	ldr	w1, [sp, #0x338]
    1878:      	bl	0x1878 <_stogir.verify.integer-operations-target-structured+0xabc>
		0000000000001878:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    187c:      	add	x16, sp, #0xc0
    1880:      	ldr	x0, [x16]
    1884:      	add	x16, sp, #0xc0
    1888:      	ldr	x1, [x16, #0x8]
    188c:      	add	x16, sp, #0xc0
    1890:      	ldr	x2, [x16, #0x10]
    1894:      	b	0x1264 <_stogir.verify.integer-operations-target-structured+0x4a8>
    1898:      	add	x0, x23, #0x1
    189c:      	lsr	w0, w0, #0
    18a0:      	sxtw	x23, w0
    18a4:      	b	0x129c <_stogir.verify.integer-operations-target-structured+0x4e0>
    18a8:      	add	x0, x23, #0x1
    18ac:      	lsr	w0, w0, #0
    18b0:      	sxtw	x23, w0
    18b4:      	b	0x12fc <_stogir.verify.integer-operations-target-structured+0x540>
    18b8:      	brk	#0
    18bc:      	b	0x18b8 <_stogir.verify.integer-operations-target-structured+0xafc>
    18c0:      	add	x8, sp, #0x100
    18c4:      	ldr	x0, [sp, #0x2b0]
    18c8:      	ldr	w1, [sp, #0x338]
    18cc:      	bl	0x18cc <_stogir.verify.integer-operations-target-structured+0xb10>
		00000000000018cc:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    18d0:      	add	x16, sp, #0x100
    18d4:      	ldr	w0, [x16]
    18d8:      	lsr	x16, x0, #0
    18dc:      	cmp	x16, #0x1
    18e0:      	b.eq	0x18fc <_stogir.verify.integer-operations-target-structured+0xb40>
    18e4:      	b.lo	0x18ec <_stogir.verify.integer-operations-target-structured+0xb30>
    18e8:      	b	0x1900 <_stogir.verify.integer-operations-target-structured+0xb44>
    18ec:      	cmp	x16, #0x0
    18f0:      	b.eq	0x18f8 <_stogir.verify.integer-operations-target-structured+0xb3c>
    18f4:      	b	0x1900 <_stogir.verify.integer-operations-target-structured+0xb44>
    18f8:      	b	0x1914 <_stogir.verify.integer-operations-target-structured+0xb58>
    18fc:      	b	0x1904 <_stogir.verify.integer-operations-target-structured+0xb48>
    1900:      	b	0x1e8c <_stogir.verify.integer-operations-target-structured+0x10d0>
    1904:      	add	x16, sp, #0x100
    1908:      	ldr	x19, [x16, #0x8]
    190c:      	ldr	x22, [x26, #0x8]
    1910:      	b	0x130c <_stogir.verify.integer-operations-target-structured+0x550>
    1914:      	add	x0, x23, #0x1
    1918:      	lsr	w0, w0, #0
    191c:      	sxtw	x23, w0
    1920:      	b	0x1910 <_stogir.verify.integer-operations-target-structured+0xb54>
    1924:      	add	x8, sp, #0x120
    1928:      	ldr	x0, [sp, #0x2b0]
    192c:      	ldr	w1, [sp, #0x338]
    1930:      	bl	0x1930 <_stogir.verify.integer-operations-target-structured+0xb74>
		0000000000001930:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    1934:      	add	x16, sp, #0x120
    1938:      	ldr	w0, [x16]
    193c:      	lsr	x16, x0, #0
    1940:      	cmp	x16, #0x1
    1944:      	b.eq	0x1960 <_stogir.verify.integer-operations-target-structured+0xba4>
    1948:      	b.lo	0x1950 <_stogir.verify.integer-operations-target-structured+0xb94>
    194c:      	b	0x1964 <_stogir.verify.integer-operations-target-structured+0xba8>
    1950:      	cmp	x16, #0x0
    1954:      	b.eq	0x195c <_stogir.verify.integer-operations-target-structured+0xba0>
    1958:      	b	0x1964 <_stogir.verify.integer-operations-target-structured+0xba8>
    195c:      	b	0x1978 <_stogir.verify.integer-operations-target-structured+0xbbc>
    1960:      	b	0x1968 <_stogir.verify.integer-operations-target-structured+0xbac>
    1964:      	b	0x1988 <_stogir.verify.integer-operations-target-structured+0xbcc>
    1968:      	add	x16, sp, #0x120
    196c:      	ldr	x19, [x16, #0x8]
    1970:      	ldr	x22, [x25, #0x8]
    1974:      	b	0x1324 <_stogir.verify.integer-operations-target-structured+0x568>
    1978:      	add	x0, x23, #0x1
    197c:      	lsr	w0, w0, #0
    1980:      	sxtw	x23, w0
    1984:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xbb8>
    1988:      	brk	#0
    198c:      	b	0x1988 <_stogir.verify.integer-operations-target-structured+0xbcc>
    1990:      	add	x8, sp, #0x140
    1994:      	ldr	x0, [sp, #0x2b0]
    1998:      	ldr	w1, [sp, #0x338]
    199c:      	bl	0x199c <_stogir.verify.integer-operations-target-structured+0xbe0>
		000000000000199c:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    19a0:      	add	x16, sp, #0x140
    19a4:      	ldr	w0, [x16]
    19a8:      	lsr	x16, x0, #0
    19ac:      	cmp	x16, #0x1
    19b0:      	b.eq	0x19d0 <_stogir.verify.integer-operations-target-structured+0xc14>
    19b4:      	b.lo	0x19bc <_stogir.verify.integer-operations-target-structured+0xc00>
    19b8:      	b	0x19d4 <_stogir.verify.integer-operations-target-structured+0xc18>
    19bc:      	cmp	x16, #0x0
    19c0:      	b.eq	0x19c8 <_stogir.verify.integer-operations-target-structured+0xc0c>
    19c4:      	b	0x19d4 <_stogir.verify.integer-operations-target-structured+0xc18>
    19c8:      	ldr	x0, [sp, #0x348]
    19cc:      	b	0x19ec <_stogir.verify.integer-operations-target-structured+0xc30>
    19d0:      	b	0x19d8 <_stogir.verify.integer-operations-target-structured+0xc1c>
    19d4:      	b	0x1e84 <_stogir.verify.integer-operations-target-structured+0x10c8>
    19d8:      	add	x16, sp, #0x140
    19dc:      	ldr	x19, [x16, #0x8]
    19e0:      	ldr	x0, [sp, #0x348]
    19e4:      	ldr	x22, [x0, #0x8]
    19e8:      	b	0x1350 <_stogir.verify.integer-operations-target-structured+0x594>
    19ec:      	add	x1, x23, #0x1
    19f0:      	lsr	w1, w1, #0
    19f4:      	sxtw	x23, w1
    19f8:      	b	0x19e8 <_stogir.verify.integer-operations-target-structured+0xc2c>
    19fc:      	add	x8, sp, #0x160
    1a00:      	ldr	w1, [sp, #0x338]
    1a04:      	ldr	w2, [sp, #0x2d8]
    1a08:      	str	x0, [sp, #0x348]
    1a0c:      	ldr	x0, [sp, #0x2b0]
    1a10:      	bl	0x1a10 <_stogir.verify.integer-operations-target-structured+0xc54>
		0000000000001a10:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1a14:      	add	x16, sp, #0x160
    1a18:      	ldr	w0, [x16]
    1a1c:      	lsr	x16, x0, #0
    1a20:      	cmp	x16, #0x1
    1a24:      	b.eq	0x1a44 <_stogir.verify.integer-operations-target-structured+0xc88>
    1a28:      	b.lo	0x1a30 <_stogir.verify.integer-operations-target-structured+0xc74>
    1a2c:      	b	0x1a48 <_stogir.verify.integer-operations-target-structured+0xc8c>
    1a30:      	cmp	x16, #0x0
    1a34:      	b.eq	0x1a3c <_stogir.verify.integer-operations-target-structured+0xc80>
    1a38:      	b	0x1a48 <_stogir.verify.integer-operations-target-structured+0xc8c>
    1a3c:      	ldr	x0, [sp, #0x318]
    1a40:      	b	0x1a60 <_stogir.verify.integer-operations-target-structured+0xca4>
    1a44:      	b	0x1a4c <_stogir.verify.integer-operations-target-structured+0xc90>
    1a48:      	b	0x1a70 <_stogir.verify.integer-operations-target-structured+0xcb4>
    1a4c:      	add	x16, sp, #0x160
    1a50:      	ldr	x19, [x16, #0x8]
    1a54:      	ldr	x0, [sp, #0x318]
    1a58:      	ldr	x22, [x0, #0x8]
    1a5c:      	b	0x1378 <_stogir.verify.integer-operations-target-structured+0x5bc>
    1a60:      	add	x1, x23, #0x1
    1a64:      	lsr	w1, w1, #0
    1a68:      	sxtw	x23, w1
    1a6c:      	b	0x1a5c <_stogir.verify.integer-operations-target-structured+0xca0>
    1a70:      	brk	#0
    1a74:      	b	0x1a70 <_stogir.verify.integer-operations-target-structured+0xcb4>
    1a78:      	add	x1, x23, #0x1
    1a7c:      	lsr	w1, w1, #0
    1a80:      	sxtw	x23, w1
    1a84:      	b	0x13e8 <_stogir.verify.integer-operations-target-structured+0x62c>
    1a88:      	brk	#0
    1a8c:      	b	0x1a88 <_stogir.verify.integer-operations-target-structured+0xccc>
    1a90:      	add	x1, x23, #0x1
    1a94:      	lsr	w1, w1, #0
    1a98:      	sxtw	x23, w1
    1a9c:      	b	0x144c <_stogir.verify.integer-operations-target-structured+0x690>
    1aa0:      	brk	#0
    1aa4:      	b	0x1aa0 <_stogir.verify.integer-operations-target-structured+0xce4>
    1aa8:      	add	x16, sp, #0x20
    1aac:      	ldr	w1, [x16, #0x8]
    1ab0:      	lsr	w1, w1, #0
    1ab4:      	add	x8, sp, #0x1c0
    1ab8:      	str	x0, [sp, #0x238]
    1abc:      	ldr	x0, [sp, #0x2b0]
    1ac0:      	bl	0x1ac0 <_stogir.verify.integer-operations-target-structured+0xd04>
		0000000000001ac0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1ac4:      	add	x16, sp, #0x1c0
    1ac8:      	ldr	w0, [x16]
    1acc:      	lsr	x16, x0, #0
    1ad0:      	cmp	x16, #0x1
    1ad4:      	b.eq	0x1af0 <_stogir.verify.integer-operations-target-structured+0xd34>
    1ad8:      	b.lo	0x1ae0 <_stogir.verify.integer-operations-target-structured+0xd24>
    1adc:      	b	0x1af4 <_stogir.verify.integer-operations-target-structured+0xd38>
    1ae0:      	cmp	x16, #0x0
    1ae4:      	b.eq	0x1aec <_stogir.verify.integer-operations-target-structured+0xd30>
    1ae8:      	b	0x1af4 <_stogir.verify.integer-operations-target-structured+0xd38>
    1aec:      	b	0x1af8 <_stogir.verify.integer-operations-target-structured+0xd3c>
    1af0:      	b	0x1b04 <_stogir.verify.integer-operations-target-structured+0xd48>
    1af4:      	b	0x1b34 <_stogir.verify.integer-operations-target-structured+0xd78>
    1af8:      	ldr	x19, [sp, #0x268]
    1afc:      	mov	x22, #0x14              ; =20
    1b00:      	b	0x1488 <_stogir.verify.integer-operations-target-structured+0x6cc>
    1b04:      	add	x16, sp, #0x1c0
    1b08:      	ldr	x0, [x16, #0x8]
    1b0c:      	add	x16, sp, #0x20
    1b10:      	ldr	w1, [x16]
    1b14:      	lsr	w0, w0, #0
    1b18:      	ubfx	x1, x1, #8, #8
    1b1c:      	ubfx	x0, x0, #8, #8
    1b20:      	cmp	x0, x1
    1b24:      	b.eq	0x1b30 <_stogir.verify.integer-operations-target-structured+0xd74>
    1b28:      	ldr	x19, [sp, #0x270]
    1b2c:      	mov	x22, #0x1a              ; =26
    1b30:      	b	0x1b00 <_stogir.verify.integer-operations-target-structured+0xd44>
    1b34:      	brk	#0
    1b38:      	b	0x1b34 <_stogir.verify.integer-operations-target-structured+0xd78>
    1b3c:      	add	x1, x23, #0x1
    1b40:      	lsr	w1, w1, #0
    1b44:      	sxtw	x23, w1
    1b48:      	b	0x151c <_stogir.verify.integer-operations-target-structured+0x760>
    1b4c:      	brk	#0
    1b50:      	b	0x1b4c <_stogir.verify.integer-operations-target-structured+0xd90>
    1b54:      	mov	x1, #0x1                ; =1
    1b58:      	b	0x152c <_stogir.verify.integer-operations-target-structured+0x770>
    1b5c:      	mov	x1, #0x1                ; =1
    1b60:      	b	0x1540 <_stogir.verify.integer-operations-target-structured+0x784>
    1b64:      	ldr	x21, [sp, #0x310]
    1b68:      	cmp	x21, #0x0
    1b6c:      	b.eq	0x1b78 <_stogir.verify.integer-operations-target-structured+0xdbc>
    1b70:      	mov	x1, #0x1                ; =1
    1b74:      	b	0x155c <_stogir.verify.integer-operations-target-structured+0x7a0>
    1b78:      	ldr	x1, [sp, #0x2b8]
    1b7c:      	b	0x1b74 <_stogir.verify.integer-operations-target-structured+0xdb8>
    1b80:      	movz	x1, #0x0, lsl #48
    1b84:      	b	0x155c <_stogir.verify.integer-operations-target-structured+0x7a0>
    1b88:      	movz	x1, #0x0, lsl #48
    1b8c:      	b	0x155c <_stogir.verify.integer-operations-target-structured+0x7a0>
    1b90:      	lsr	w1, w1, #0
    1b94:      	lsr	w1, w1, #0
    1b98:      	ldr	x0, [sp, #0x2b0]
    1b9c:      	bl	0x1b9c <_stogir.verify.integer-operations-target-structured+0xde0>
		0000000000001b9c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1ba0:      	cmp	x0, #0x0
    1ba4:      	b.ne	0x1bc4 <_stogir.verify.integer-operations-target-structured+0xe08>
    1ba8:      	str	x28, [sp, #0x378]
    1bac:      	str	x27, [sp, #0x370]
    1bb0:      	str	x26, [sp, #0x368]
    1bb4:      	str	x25, [sp, #0x360]
    1bb8:      	ldr	x19, [sp, #0x278]
    1bbc:      	mov	x22, #0x17              ; =23
    1bc0:      	b	0x15e4 <_stogir.verify.integer-operations-target-structured+0x828>
    1bc4:      	ldr	w0, [x0]
    1bc8:      	add	x16, sp, #0x20
    1bcc:      	ldr	w1, [x16]
    1bd0:      	ubfx	x0, x0, #8, #8
    1bd4:      	orr	x2, x0, xzr
    1bd8:      	ubfx	x1, x1, #8, #8
    1bdc:      	cmp	x1, #0x6
    1be0:      	b.ne	0x1d40 <_stogir.verify.integer-operations-target-structured+0xf84>
    1be4:      	cmp	x2, #0x6
    1be8:      	b.ne	0x1d38 <_stogir.verify.integer-operations-target-structured+0xf7c>
    1bec:      	cmp	x24, #0x1a
    1bf0:      	b.ne	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf6c>
    1bf4:      	mov	x1, #0x1                ; =1
    1bf8:      	cmp	x2, #0x1
    1bfc:      	cset	w3, ge
    1c00:      	uxtb	w16, w3
    1c04:      	cmp	w16, wzr
    1c08:      	b.eq	0x1fa4 <_stogir.verify.integer-operations-target-structured+0x11e8>
    1c0c:      	cmp	x2, #0xb
    1c10:      	cset	w4, le
    1c14:      	uxtb	w16, w4
    1c18:      	cmp	w16, wzr
    1c1c:      	b.eq	0x1fc0 <_stogir.verify.integer-operations-target-structured+0x1204>
    1c20:      	ldr	x5, [sp, #0x2b8]
    1c24:      	cmp	x5, #0x0
    1c28:      	b.eq	0x1fdc <_stogir.verify.integer-operations-target-structured+0x1220>
    1c2c:      	ldr	w5, [sp, #0x298]
    1c30:      	lsr	w5, w5, #0
    1c34:      	lsr	w0, w0, #0
    1c38:      	str	x25, [sp, #0x360]
    1c3c:      	mov	x25, x2
    1c40:      	str	x26, [sp, #0x368]
    1c44:      	mov	x26, x1
    1c48:      	mov	w1, w0
    1c4c:      	mov	w0, w5
    1c50:      	str	x27, [sp, #0x370]
    1c54:      	mov	w27, w3
    1c58:      	str	x28, [sp, #0x378]
    1c5c:      	mov	w28, w4
    1c60:      	bl	0x1c60 <_stogir.verify.integer-operations-target-structured+0xea4>
		0000000000001c60:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1c64:      	cmp	x0, #0x0
    1c68:      	b.ne	0x1d48 <_stogir.verify.integer-operations-target-structured+0xf8c>
    1c6c:      	ldr	x19, [sp, #0x280]
    1c70:      	mov	x22, #0x1c              ; =28
    1c74:      	add	x16, sp, #0x20
    1c78:      	ldr	w0, [x16]
    1c7c:      	cmp	x20, #0x0
    1c80:      	b.eq	0x1e10 <_stogir.verify.integer-operations-target-structured+0x1054>
    1c84:      	mov	x1, #0x1                ; =1
    1c88:      	lsr	w1, w1, #0
    1c8c:      	ubfx	x0, x0, #8, #8
    1c90:      	sxtw	x1, w1
    1c94:      	cmp	x0, x1
    1c98:      	b.eq	0x1ca4 <_stogir.verify.integer-operations-target-structured+0xee8>
    1c9c:      	ldr	x19, [sp, #0x288]
    1ca0:      	mov	x22, #0x26              ; =38
    1ca4:      	cmp	x20, #0x0
    1ca8:      	b.eq	0x1cb0 <_stogir.verify.integer-operations-target-structured+0xef4>
    1cac:      	mov	x21, #0x1               ; =1
    1cb0:      	cmp	x21, #0x0
    1cb4:      	b.eq	0x1d24 <_stogir.verify.integer-operations-target-structured+0xf68>
    1cb8:      	add	x16, sp, #0x220
    1cbc:      	str	x16, [sp]
    1cc0:      	ldr	x0, [sp, #0x2b0]
    1cc4:      	ldr	w1, [sp, #0x338]
    1cc8:      	mov	x2, #0x2                ; =2
    1ccc:      	bl	0x1ccc <_stogir.verify.integer-operations-target-structured+0xf10>
		0000000000001ccc:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1cd0:      	ldr	x16, [sp]
    1cd4:      	str	x0, [x16]
    1cd8:      	str	x1, [x16, #0x8]
    1cdc:      	add	x16, sp, #0x220
    1ce0:      	ldr	x0, [x16]
    1ce4:      	add	x16, sp, #0x220
    1ce8:      	ldr	x1, [x16, #0x8]
    1cec:      	lsr	w0, w0, #0
    1cf0:      	lsr	x16, x0, #0
    1cf4:      	cmp	x16, #0x1
    1cf8:      	b.eq	0x1d14 <_stogir.verify.integer-operations-target-structured+0xf58>
    1cfc:      	b.lo	0x1d04 <_stogir.verify.integer-operations-target-structured+0xf48>
    1d00:      	b	0x1d18 <_stogir.verify.integer-operations-target-structured+0xf5c>
    1d04:      	cmp	x16, #0x0
    1d08:      	b.eq	0x1d10 <_stogir.verify.integer-operations-target-structured+0xf54>
    1d0c:      	b	0x1d18 <_stogir.verify.integer-operations-target-structured+0xf5c>
    1d10:      	b	0x1d1c <_stogir.verify.integer-operations-target-structured+0xf60>
    1d14:      	b	0x1e18 <_stogir.verify.integer-operations-target-structured+0x105c>
    1d18:      	b	0x1e74 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1d1c:      	ldr	x19, [sp, #0x290]
    1d20:      	mov	x22, #0x1d              ; =29
    1d24:      	b	0x1bc0 <_stogir.verify.integer-operations-target-structured+0xe04>
    1d28:      	cmp	x24, #0x1b
    1d2c:      	cset	w1, eq
    1d30:      	ubfx	x1, x1, #0, #8
    1d34:      	b	0x1bf8 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1d38:      	movz	x1, #0x0, lsl #48
    1d3c:      	b	0x1bf8 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1d40:      	movz	x1, #0x0, lsl #48
    1d44:      	b	0x1bf8 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1d48:      	cmp	x21, #0x0
    1d4c:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1d50:      	ldr	w0, [sp, #0x308]
    1d54:      	uxtb	w16, w0
    1d58:      	cmp	w16, wzr
    1d5c:      	b.eq	0x1dc4 <_stogir.verify.integer-operations-target-structured+0x1008>
    1d60:      	ldr	w0, [sp, #0x300]
    1d64:      	uxtb	w16, w0
    1d68:      	cmp	w16, wzr
    1d6c:      	b.eq	0x1dc4 <_stogir.verify.integer-operations-target-structured+0x1008>
    1d70:      	ldr	w0, [sp, #0x2e8]
    1d74:      	uxtb	w16, w27
    1d78:      	cmp	w16, wzr
    1d7c:      	b.eq	0x1c6c <_stogir.verify.integer-operations-target-structured+0xeb0>
    1d80:      	uxtb	w16, w28
    1d84:      	cmp	w16, wzr
    1d88:      	b.eq	0x1c6c <_stogir.verify.integer-operations-target-structured+0xeb0>
    1d8c:      	cmp	x25, #0x1
    1d90:      	b.ne	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1d94:      	cmp	x24, #0x2e
    1d98:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1d9c:      	cmp	x24, #0x2f
    1da0:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1da4:      	cmp	x24, #0x30
    1da8:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1dac:      	uxtb	w16, w0
    1db0:      	cmp	w16, wzr
    1db4:      	b.ne	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1db8:      	cmp	x24, #0x3b
    1dbc:      	b.ne	0x1c6c <_stogir.verify.integer-operations-target-structured+0xeb0>
    1dc0:      	b	0x1c74 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1dc4:      	ldr	w0, [sp, #0x2f8]
    1dc8:      	uxtb	w16, w0
    1dcc:      	cmp	w16, wzr
    1dd0:      	b.eq	0x1dec <_stogir.verify.integer-operations-target-structured+0x1030>
    1dd4:      	ldr	w0, [sp, #0x2f0]
    1dd8:      	uxtb	w16, w0
    1ddc:      	cmp	w16, wzr
    1de0:      	b.eq	0x1dec <_stogir.verify.integer-operations-target-structured+0x1030>
    1de4:      	ldr	w0, [sp, #0x2e8]
    1de8:      	b	0x1d74 <_stogir.verify.integer-operations-target-structured+0xfb8>
    1dec:      	ldr	w0, [sp, #0x2e8]
    1df0:      	uxtb	w16, w0
    1df4:      	cmp	w16, wzr
    1df8:      	b.ne	0x1d74 <_stogir.verify.integer-operations-target-structured+0xfb8>
    1dfc:      	ldr	w1, [sp, #0x2a8]
    1e00:      	uxtb	w16, w1
    1e04:      	cmp	w16, wzr
    1e08:      	b.ne	0x1d74 <_stogir.verify.integer-operations-target-structured+0xfb8>
    1e0c:      	b	0x1c6c <_stogir.verify.integer-operations-target-structured+0xeb0>
    1e10:      	mov	x1, x25
    1e14:      	b	0x1c88 <_stogir.verify.integer-operations-target-structured+0xecc>
    1e18:      	lsr	w1, w1, #0
    1e1c:      	lsr	w1, w1, #0
    1e20:      	ldr	x0, [sp, #0x2b0]
    1e24:      	bl	0x1e24 <_stogir.verify.integer-operations-target-structured+0x1068>
		0000000000001e24:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1e28:      	cmp	x0, #0x0
    1e2c:      	b.ne	0x1e3c <_stogir.verify.integer-operations-target-structured+0x1080>
    1e30:      	ldr	x19, [sp, #0x290]
    1e34:      	mov	x22, #0x1d              ; =29
    1e38:      	b	0x1d24 <_stogir.verify.integer-operations-target-structured+0xf68>
    1e3c:      	ldr	w0, [x0]
    1e40:      	ubfx	x0, x0, #8, #8
    1e44:      	cmp	x25, x0
    1e48:      	b.eq	0x1e64 <_stogir.verify.integer-operations-target-structured+0x10a8>
    1e4c:      	cmp	x26, #0x0
    1e50:      	b.eq	0x1e68 <_stogir.verify.integer-operations-target-structured+0x10ac>
    1e54:      	cmp	x0, #0x5
    1e58:      	b.eq	0x1e64 <_stogir.verify.integer-operations-target-structured+0x10a8>
    1e5c:      	cmp	x0, #0xb
    1e60:      	b.ne	0x1e68 <_stogir.verify.integer-operations-target-structured+0x10ac>
    1e64:      	b	0x1e38 <_stogir.verify.integer-operations-target-structured+0x107c>
    1e68:      	ldr	x19, [sp, #0x260]
    1e6c:      	mov	x22, #0x1d              ; =29
    1e70:      	b	0x1e64 <_stogir.verify.integer-operations-target-structured+0x10a8>
    1e74:      	brk	#0
    1e78:      	b	0x1e74 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1e7c:      	brk	#0
    1e80:      	b	0x1e7c <_stogir.verify.integer-operations-target-structured+0x10c0>
    1e84:      	brk	#0
    1e88:      	b	0x1e84 <_stogir.verify.integer-operations-target-structured+0x10c8>
    1e8c:      	brk	#0
    1e90:      	b	0x1e8c <_stogir.verify.integer-operations-target-structured+0x10d0>
    1e94:      	brk	#0
    1e98:      	b	0x1e94 <_stogir.verify.integer-operations-target-structured+0x10d8>
    1e9c:      	brk	#0
    1ea0:      	b	0x1e9c <_stogir.verify.integer-operations-target-structured+0x10e0>
    1ea4:      	cmp	x22, #0x0
    1ea8:      	b.ne	0x1f00 <_stogir.verify.integer-operations-target-structured+0x1144>
    1eac:      	and	x19, x23, #0xffffffff
    1eb0:      	movz	x0, #0x0, lsl #48
    1eb4:      	movz	x22, #0x0, lsl #48
    1eb8:      	ldr	x1, [sp, #0x2c0]
    1ebc:      	str	x0, [x1]
    1ec0:      	str	x19, [x1, #0x8]
    1ec4:      	str	x22, [x1, #0x10]
    1ec8:      	ldr	x19, [sp, #0x380]
    1ecc:      	ldr	x20, [sp, #0x388]
    1ed0:      	ldr	x21, [sp, #0x390]
    1ed4:      	ldr	x22, [sp, #0x398]
    1ed8:      	ldr	x23, [sp, #0x3a0]
    1edc:      	ldr	x24, [sp, #0x3a8]
    1ee0:      	ldr	x25, [sp, #0x3b0]
    1ee4:      	ldr	x26, [sp, #0x3b8]
    1ee8:      	ldr	x27, [sp, #0x3c0]
    1eec:      	ldr	x28, [sp, #0x3c8]
    1ef0:      	ldr	x29, [sp, #0x10]
    1ef4:      	ldr	x30, [sp, #0x18]
    1ef8:      	add	sp, sp, #0x3d0
    1efc:      	ret
    1f00:      	mov	x0, #0x1                ; =1
    1f04:      	b	0x1eb8 <_stogir.verify.integer-operations-target-structured+0x10fc>
    1f08:      	mov	x23, x21
    1f0c:      	str	x8, [sp, #0x2c0]
    1f10:      	b	0x1ea4 <_stogir.verify.integer-operations-target-structured+0x10e8>
    1f14:      	mov	x23, x21
    1f18:      	str	x8, [sp, #0x2c0]
    1f1c:      	b	0x1ea4 <_stogir.verify.integer-operations-target-structured+0x10e8>
    1f20:      	str	x23, [sp, #0x350]
    1f24:      	mov	x23, x0
    1f28:      	b	0x118c <_stogir.verify.integer-operations-target-structured+0x3d0>
    1f2c:      	str	x0, [sp, #0x348]
    1f30:      	ldr	x0, [sp, #0x318]
    1f34:      	b	0x1378 <_stogir.verify.integer-operations-target-structured+0x5bc>
    1f38:      	str	x0, [sp, #0x318]
    1f3c:      	ldr	x0, [sp, #0x320]
    1f40:      	b	0x13e8 <_stogir.verify.integer-operations-target-structured+0x62c>
    1f44:      	str	x0, [sp, #0x318]
    1f48:      	ldr	x0, [sp, #0x320]
    1f4c:      	b	0x13e8 <_stogir.verify.integer-operations-target-structured+0x62c>
    1f50:      	str	x0, [sp, #0x320]
    1f54:      	ldr	x0, [sp, #0x238]
    1f58:      	b	0x144c <_stogir.verify.integer-operations-target-structured+0x690>
    1f5c:      	str	x0, [sp, #0x238]
    1f60:      	b	0x1494 <_stogir.verify.integer-operations-target-structured+0x6d8>
    1f64:      	str	x20, [sp, #0x358]
    1f68:      	mov	x20, x0
    1f6c:      	ldr	x0, [sp, #0x258]
    1f70:      	b	0x151c <_stogir.verify.integer-operations-target-structured+0x760>
    1f74:      	ldr	x20, [sp, #0x330]
    1f78:      	ldr	x21, [sp, #0x310]
    1f7c:      	b	0x1b88 <_stogir.verify.integer-operations-target-structured+0xdcc>
    1f80:      	ldr	x20, [sp, #0x330]
    1f84:      	ldr	x21, [sp, #0x310]
    1f88:      	b	0x1b80 <_stogir.verify.integer-operations-target-structured+0xdc4>
    1f8c:      	str	x28, [sp, #0x378]
    1f90:      	str	x27, [sp, #0x370]
    1f94:      	str	x26, [sp, #0x368]
    1f98:      	str	x25, [sp, #0x360]
    1f9c:      	str	x0, [sp, #0x258]
    1fa0:      	b	0x15f0 <_stogir.verify.integer-operations-target-structured+0x834>
    1fa4:      	str	x28, [sp, #0x378]
    1fa8:      	str	x27, [sp, #0x370]
    1fac:      	str	x26, [sp, #0x368]
    1fb0:      	mov	x26, x1
    1fb4:      	str	x25, [sp, #0x360]
    1fb8:      	mov	x25, x2
    1fbc:      	b	0x1c6c <_stogir.verify.integer-operations-target-structured+0xeb0>
    1fc0:      	str	x28, [sp, #0x378]
    1fc4:      	str	x27, [sp, #0x370]
    1fc8:      	str	x26, [sp, #0x368]
    1fcc:      	mov	x26, x1
    1fd0:      	str	x25, [sp, #0x360]
    1fd4:      	mov	x25, x2
    1fd8:      	b	0x1c6c <_stogir.verify.integer-operations-target-structured+0xeb0>
    1fdc:      	str	x28, [sp, #0x378]
    1fe0:      	str	x27, [sp, #0x370]
    1fe4:      	str	x26, [sp, #0x368]
    1fe8:      	mov	x26, x1
    1fec:      	str	x25, [sp, #0x360]
    1ff0:      	mov	x25, x2
    1ff4:      	mov	w27, w3
    1ff8:      	mov	w28, w4
    1ffc:      	b	0x1d48 <_stogir.verify.integer-operations-target-structured+0xf8c>

0000000000002000 <_stogir.types.valid?>:
    2000:      	sxtw	x0, w0
    2004:      	cmp	x0, #0x0
    2008:      	b.lt	0x201c <_stogir.types.valid?+0x1c>
    200c:      	cmp	x0, #0xd
    2010:      	b.gt	0x201c <_stogir.types.valid?+0x1c>
    2014:      	mov	x0, #0x1                ; =1
    2018:      	b	0x205c <_stogir.types.valid?+0x5c>
    201c:      	cmp	x0, #0xf
    2020:      	b.le	0x2058 <_stogir.types.valid?+0x58>
    2024:      	cmp	x0, #0x80
    2028:      	b.ge	0x2050 <_stogir.types.valid?+0x50>
    202c:      	and	x0, x0, #0xf
    2030:      	lsr	w0, w0, #0
    2034:      	sxtw	x0, w0
    2038:      	cmp	x0, #0x1
    203c:      	b.lt	0x2060 <_stogir.types.valid?+0x60>
    2040:      	cmp	x0, #0xd
    2044:      	cset	w0, le
    2048:      	ubfx	x0, x0, #0, #8
    204c:      	b	0x2064 <_stogir.types.valid?+0x64>
    2050:      	movz	x0, #0x0, lsl #48
    2054:      	b	0x205c <_stogir.types.valid?+0x5c>
    2058:      	movz	x0, #0x0, lsl #48
    205c:      	ret
    2060:      	movz	x0, #0x0, lsl #48
    2064:      	b	0x2054 <_stogir.types.valid?+0x54>

0000000000002068 <_stogir.opcode.operand-slots>:
    2068:      	sxtw	x0, w0
    206c:      	cmp	x0, #0x0
    2070:      	b.lt	0x2098 <_stogir.opcode.operand-slots+0x30>
    2074:      	cmp	x0, #0x83
    2078:      	b.ge	0x2098 <_stogir.opcode.operand-slots+0x30>
    207c:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		000000000000207c:  ARM64_RELOC_PAGE21	l_stogir.336
    2080:      	ldr	x16, [x16]
		0000000000002080:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    2084:      	orr	x1, x16, xzr
    2088:      	add	x0, x1, x0
    208c:      	ldrsb	w0, [x0]
    2090:      	sxtb	x0, w0
    2094:      	b	0x209c <_stogir.opcode.operand-slots+0x34>
    2098:      	mov	x0, #-0x2               ; =-2
    209c:      	ret

00000000000020a0 <_stogir.opcode.input-count>:
    20a0:      	sxtw	x0, w0
    20a4:      	cmp	x0, #0x0
    20a8:      	b.lt	0x20d0 <_stogir.opcode.input-count+0x30>
    20ac:      	cmp	x0, #0x83
    20b0:      	b.ge	0x20d0 <_stogir.opcode.input-count+0x30>
    20b4:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		00000000000020b4:  ARM64_RELOC_PAGE21	l_stogir.337
    20b8:      	ldr	x16, [x16]
		00000000000020b8:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    20bc:      	orr	x1, x16, xzr
    20c0:      	add	x0, x1, x0
    20c4:      	ldrsb	w0, [x0]
    20c8:      	sxtb	x0, w0
    20cc:      	b	0x20d4 <_stogir.opcode.input-count+0x34>
    20d0:      	mov	x0, #-0x2               ; =-2
    20d4:      	ret

00000000000020d8 <_stogir.graph.operand>:
    20d8:      	sub	sp, sp, #0x10
    20dc:      	mov	x3, sp
    20e0:      	sxtw	x1, w1
    20e4:      	cmp	x1, #0x0
    20e8:      	b.le	0x212c <_stogir.graph.operand+0x54>
    20ec:      	lsl	x4, x1, #2
    20f0:      	ldr	x5, [x0, #0x8]
    20f4:      	cmp	x1, x5
    20f8:      	b.ge	0x2160 <_stogir.graph.operand+0x88>
    20fc:      	add	x5, x0, #0x78
    2100:      	ldr	x5, [x5, #0x8]
    2104:      	cmp	x1, x5
    2108:      	b.ge	0x2158 <_stogir.graph.operand+0x80>
    210c:      	ldr	x5, [x0, #0x78]
    2110:      	add	x5, x4, x5
    2114:      	ldr	w5, [x5]
    2118:      	sxtw	x5, w5
    211c:      	cmp	x5, #0x0
    2120:      	cset	w5, ge
    2124:      	ubfx	x5, x5, #0, #8
    2128:      	b	0x215c <_stogir.graph.operand+0x84>
    212c:      	movz	x1, #0x0, lsl #48
    2130:      	movz	x0, #0x0, lsl #48
    2134:      	str	x1, [x3]
    2138:      	str	x0, [x3, #0x8]
    213c:      	ldr	x0, [sp]
    2140:      	ldr	x1, [sp, #0x8]
    2144:      	add	sp, sp, #0x10
    2148:      	ret
    214c:      	movz	x1, #0x0, lsl #48
    2150:      	movz	x0, #0x0, lsl #48
    2154:      	b	0x2134 <_stogir.graph.operand+0x5c>
    2158:      	movz	x5, #0x0, lsl #48
    215c:      	b	0x2164 <_stogir.graph.operand+0x8c>
    2160:      	movz	x5, #0x0, lsl #48
    2164:      	cmp	x5, #0x0
    2168:      	b.eq	0x212c <_stogir.graph.operand+0x54>
    216c:      	sxtw	x2, w2
    2170:      	cmp	x2, #0x1
    2174:      	b.lt	0x214c <_stogir.graph.operand+0x74>
    2178:      	ldr	x5, [x0, #0x78]
    217c:      	add	x4, x4, x5
    2180:      	ldr	w4, [x4]
    2184:      	sxtw	x4, w4
    2188:      	cmp	x2, x4
    218c:      	b.gt	0x214c <_stogir.graph.operand+0x74>
    2190:      	asr	x16, x2, #63
    2194:      	lsr	x16, x16, #62
    2198:      	add	x4, x2, x16
    219c:      	asr	x4, x4, #2
    21a0:      	asr	x16, x2, #63
    21a4:      	lsr	x16, x16, #62
    21a8:      	add	x2, x2, x16
    21ac:      	and	x2, x2, #0x3
    21b0:      	sub	x2, x2, x16
    21b4:      	ldr	x0, [x0]
    21b8:      	add	x1, x4, x1
    21bc:      	add	x0, x0, x1, lsl #4
    21c0:      	add	x0, x0, x2, lsl #2
    21c4:      	ldr	w0, [x0]
    21c8:      	sxtw	x0, w0
    21cc:      	and	x0, x0, #0xffffffff
    21d0:      	mov	x1, #0x1                ; =1
    21d4:      	b	0x2154 <_stogir.graph.operand+0x7c>

00000000000021d8 <_stogir.graph.borrow-node>:
    21d8:      	sxtw	x1, w1
    21dc:      	cmp	x1, #0x0
    21e0:      	cset	w2, gt
    21e4:      	movz	x16, #0x0, lsl #48
    21e8:      	sub	x3, x16, x1
    21ec:      	sub	x4, x3, #0x1
    21f0:      	uxtb	w16, w2
    21f4:      	cmp	w16, wzr
    21f8:      	b.eq	0x2238 <_stogir.graph.borrow-node+0x60>
    21fc:      	ldr	x3, [x0, #0x8]
    2200:      	cmp	x1, x3
    2204:      	b.ge	0x2288 <_stogir.graph.borrow-node+0xb0>
    2208:      	add	x3, x0, #0x78
    220c:      	ldr	x3, [x3, #0x8]
    2210:      	cmp	x1, x3
    2214:      	b.ge	0x22c8 <_stogir.graph.borrow-node+0xf0>
    2218:      	ldr	x3, [x0, #0x78]
    221c:      	add	x3, x3, x1, lsl #2
    2220:      	ldr	w3, [x3]
    2224:      	sxtw	x3, w3
    2228:      	cmp	x3, #0x0
    222c:      	cset	w3, ge
    2230:      	ubfx	x3, x3, #0, #8
    2234:      	b	0x22cc <_stogir.graph.borrow-node+0xf4>
    2238:      	cmp	x1, #0x0
    223c:      	b.ge	0x2290 <_stogir.graph.borrow-node+0xb8>
    2240:      	add	x5, x0, #0x28
    2244:      	add	x6, x0, #0x50
    2248:      	ldr	x5, [x5, #0x8]
    224c:      	ldr	x6, [x6, #0x8]
    2250:      	cmp	x5, x6
    2254:      	b.ne	0x2280 <_stogir.graph.borrow-node+0xa8>
    2258:      	cmp	x3, x5
    225c:      	b.gt	0x22d0 <_stogir.graph.borrow-node+0xf8>
    2260:      	ldr	x3, [x0, #0x50]
    2264:      	add	x3, x3, x4, lsl #2
    2268:      	ldr	w3, [x3]
    226c:      	sxtw	x3, w3
    2270:      	cmp	x3, #0x0
    2274:      	cset	w3, gt
    2278:      	ubfx	x3, x3, #0, #8
    227c:      	b	0x22d4 <_stogir.graph.borrow-node+0xfc>
    2280:      	movz	x3, #0x0, lsl #48
    2284:      	b	0x2294 <_stogir.graph.borrow-node+0xbc>
    2288:      	movz	x3, #0x0, lsl #48
    228c:      	b	0x2294 <_stogir.graph.borrow-node+0xbc>
    2290:      	movz	x3, #0x0, lsl #48
    2294:      	cmp	x3, #0x0
    2298:      	b.eq	0x22c0 <_stogir.graph.borrow-node+0xe8>
    229c:      	uxtb	w16, w2
    22a0:      	cmp	w16, wzr
    22a4:      	b.eq	0x22b4 <_stogir.graph.borrow-node+0xdc>
    22a8:      	ldr	x0, [x0]
    22ac:      	add	x0, x0, x1, lsl #4
    22b0:      	b	0x22bc <_stogir.graph.borrow-node+0xe4>
    22b4:      	ldr	x0, [x0, #0x28]
    22b8:      	add	x0, x0, x4, lsl #4
    22bc:      	b	0x22c4 <_stogir.graph.borrow-node+0xec>
    22c0:      	movz	x0, #0x0, lsl #48
    22c4:      	ret
    22c8:      	movz	x3, #0x0, lsl #48
    22cc:      	b	0x228c <_stogir.graph.borrow-node+0xb4>
    22d0:      	movz	x3, #0x0, lsl #48
    22d4:      	b	0x2284 <_stogir.graph.borrow-node+0xac>

00000000000022d8 <_stogir.verify.classifications>:
    22d8:      	sub	sp, sp, #0x70
    22dc:      	str	x29, [sp]
    22e0:      	str	x30, [sp, #0x8]
    22e4:      	mov	x29, sp
    22e8:      	str	x19, [sp, #0x20]
    22ec:      	str	x20, [sp, #0x28]
    22f0:      	str	x21, [sp, #0x30]
    22f4:      	str	x22, [sp, #0x38]
    22f8:      	str	x23, [sp, #0x40]
    22fc:      	str	x24, [sp, #0x48]
    2300:      	str	x25, [sp, #0x50]
    2304:      	str	x26, [sp, #0x58]
    2308:      	str	x27, [sp, #0x60]
    230c:      	str	x28, [sp, #0x68]
    2310:      	ldr	w4, [x2]
    2314:      	uxtb	w19, w4
    2318:      	orr	x5, x19, xzr
    231c:      	lsr	w20, w5, #0
    2320:      	ubfx	x21, x4, #8, #8
    2324:      	orr	x4, x21, xzr
    2328:      	lsr	w4, w4, #0
    232c:      	mov	x22, x0
    2330:      	mov	w0, w4
    2334:      	mov	w23, w1
    2338:      	mov	x24, x2
    233c:      	mov	w25, w3
    2340:      	bl	0x2340 <_stogir.verify.classifications+0x68>
		0000000000002340:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2344:      	fmov	d31, x0
    2348:      	mov	w0, w20
    234c:      	fmov	x20, d31
    2350:      	bl	0x2350 <_stogir.verify.classifications+0x78>
		0000000000002350:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2354:      	cmp	x0, #0x0
    2358:      	b.eq	0x2374 <_stogir.verify.classifications+0x9c>
    235c:      	cmp	x20, #0x0
    2360:      	cset	w0, ne
    2364:      	uxtb	w16, w0
    2368:      	cmp	w16, wzr
    236c:      	cset	x26, eq
    2370:      	b	0x2378 <_stogir.verify.classifications+0xa0>
    2374:      	movz	x26, #0x0, lsl #48
    2378:      	cmp	x26, #0x0
    237c:      	cset	w27, ne
    2380:      	uxtb	w16, w27
    2384:      	cmp	w16, wzr
    2388:      	b.eq	0x23bc <_stogir.verify.classifications+0xe4>
    238c:      	ldr	w0, [x24, #0x4]
    2390:      	lsr	w0, w0, #0
    2394:      	mov	w1, w0
    2398:      	mov	x0, x22
    239c:      	bl	0x239c <_stogir.verify.classifications+0xc4>
		000000000000239c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    23a0:      	cmp	x0, #0x0
    23a4:      	b.ne	0x23b0 <_stogir.verify.classifications+0xd8>
    23a8:      	movn	x0, #0x0, lsl #48
    23ac:      	b	0x23b8 <_stogir.verify.classifications+0xe0>
    23b0:      	ldr	w0, [x0]
    23b4:      	ubfx	x0, x0, #8, #8
    23b8:      	b	0x23c0 <_stogir.verify.classifications+0xe8>
    23bc:      	movn	x0, #0x0, lsl #48
    23c0:      	lsr	w0, w0, #0
    23c4:      	sxtw	x28, w0
    23c8:      	cmp	x26, #0x0
    23cc:      	b.eq	0x23fc <_stogir.verify.classifications+0x124>
    23d0:      	bl	0x23d0 <_stogir.verify.classifications+0xf8>
		00000000000023d0:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    23d4:      	cmp	x0, #0x0
    23d8:      	b.eq	0x282c <_stogir.verify.classifications+0x554>
    23dc:      	movz	x0, #0x0, lsl #48
    23e0:      	b	0x23e8 <_stogir.verify.classifications+0x110>
    23e4:      	mov	x0, #0x1                ; =1
    23e8:      	b	0x2400 <_stogir.verify.classifications+0x128>
    23ec:      	movz	x19, #0x0, lsl #48
    23f0:      	b	0x2480 <_stogir.verify.classifications+0x1a8>
    23f4:      	movz	x20, #0x0, lsl #48
    23f8:      	b	0x2488 <_stogir.verify.classifications+0x1b0>
    23fc:      	movz	x0, #0x0, lsl #48
    2400:      	sxtw	x25, w25
    2404:      	cmp	x28, #0xf
    2408:      	cset	w1, gt
    240c:      	cmp	x28, #0x80
    2410:      	cset	w2, lt
    2414:      	and	x3, x28, #0xf
    2418:      	cmp	x19, #0x83
    241c:      	cset	w4, lt
    2420:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		0000000000002420:  ARM64_RELOC_PAGE21	l_stogir.338
    2424:      	ldr	x16, [x16]
		0000000000002424:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    2428:      	orr	x5, x16, xzr
    242c:      	add	x6, x22, #0x78
    2430:      	add	x7, x22, #0x28
    2434:      	add	x8, x22, #0x50
    2438:      	sxtw	x23, w23
    243c:      	add	x9, x22, #0x78
    2440:      	lsr	w3, w3, #0
    2444:      	add	x5, x5, x19, lsl #2
    2448:      	cmp	x23, #0x0
    244c:      	cset	w10, le
    2450:      	lsl	x11, x23, #2
    2454:      	sxtw	x3, w3
    2458:      	cmp	x3, #0x1
    245c:      	cset	w12, ge
    2460:      	cmp	x3, #0xd
    2464:      	cset	w3, le
    2468:      	ubfx	x3, x3, #0, #8
    246c:      	mov	x13, #0x1               ; =1
    2470:      	b	0x2540 <_stogir.verify.classifications+0x268>
    2474:      	movz	x19, #0x0, lsl #48
    2478:      	b	0x24bc <_stogir.verify.classifications+0x1e4>
    247c:      	movz	x19, #0x0, lsl #48
    2480:      	b	0x24c4 <_stogir.verify.classifications+0x1ec>
    2484:      	movz	x20, #0x0, lsl #48
    2488:      	b	0x2534 <_stogir.verify.classifications+0x25c>
    248c:      	sub	x19, x14, #0x1
    2490:      	lsr	w19, w19, #0
    2494:      	sxtw	x19, w19
    2498:      	lsl	x19, x19, #2
    249c:      	lsr	w19, w19, #0
    24a0:      	ubfx	x19, x19, #0, #32
    24a4:      	lsr	x15, x15, x19
    24a8:      	lsr	w15, w15, #0
    24ac:      	and	x15, x15, #0xf
    24b0:      	lsr	w15, w15, #0
    24b4:      	b	0x2584 <_stogir.verify.classifications+0x2ac>
    24b8:      	movz	x19, #0x0, lsl #48
    24bc:      	b	0x24c4 <_stogir.verify.classifications+0x1ec>
    24c0:      	movz	x19, #0x0, lsl #48
    24c4:      	cmp	x19, #0x0
    24c8:      	b.eq	0x24f0 <_stogir.verify.classifications+0x218>
    24cc:      	uxtb	w16, w15
    24d0:      	cmp	w16, wzr
    24d4:      	b.eq	0x24e4 <_stogir.verify.classifications+0x20c>
    24d8:      	ldr	x15, [x22]
    24dc:      	add	x14, x15, x14, lsl #4
    24e0:      	b	0x24ec <_stogir.verify.classifications+0x214>
    24e4:      	ldr	x14, [x22, #0x28]
    24e8:      	add	x14, x14, x21, lsl #4
    24ec:      	b	0x24f4 <_stogir.verify.classifications+0x21c>
    24f0:      	movz	x14, #0x0, lsl #48
    24f4:      	cmp	x14, #0x0
    24f8:      	b.eq	0x2534 <_stogir.verify.classifications+0x25c>
    24fc:      	ldr	w14, [x14]
    2500:      	ubfx	x14, x14, #8, #8
    2504:      	cmp	x14, #0xf
    2508:      	b.le	0x2534 <_stogir.verify.classifications+0x25c>
    250c:      	cmp	x14, #0x80
    2510:      	b.ge	0x2534 <_stogir.verify.classifications+0x25c>
    2514:      	and	x14, x14, #0xf
    2518:      	lsr	w14, w14, #0
    251c:      	sxtw	x14, w14
    2520:      	cmp	x14, #0x1
    2524:      	b.lt	0x2534 <_stogir.verify.classifications+0x25c>
    2528:      	cmp	x14, #0xd
    252c:      	b.gt	0x2534 <_stogir.verify.classifications+0x25c>
    2530:      	mov	x20, #0x1               ; =1
    2534:      	add	x13, x13, #0x1
    2538:      	lsr	w13, w13, #0
    253c:      	sxtw	x13, w13
    2540:      	cmp	x20, #0x0
    2544:      	b.ne	0x26d0 <_stogir.verify.classifications+0x3f8>
    2548:      	cmp	x13, x25
    254c:      	b.gt	0x26d0 <_stogir.verify.classifications+0x3f8>
    2550:      	lsr	w14, w13, #0
    2554:      	sxtw	x14, w14
    2558:      	uxtb	w16, w4
    255c:      	cmp	w16, wzr
    2560:      	b.eq	0x2588 <_stogir.verify.classifications+0x2b0>
    2564:      	ldr	w15, [x5]
    2568:      	cmp	x14, #0x0
    256c:      	b.le	0x2580 <_stogir.verify.classifications+0x2a8>
    2570:      	cmp	x14, #0x4
    2574:      	b.le	0x248c <_stogir.verify.classifications+0x1b4>
    2578:      	mov	x19, #0x4               ; =4
    257c:      	b	0x2498 <_stogir.verify.classifications+0x1c0>
    2580:      	movz	x15, #0x0, lsl #48
    2584:      	b	0x258c <_stogir.verify.classifications+0x2b4>
    2588:      	movz	x15, #0x0, lsl #48
    258c:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		000000000000258c:  ARM64_RELOC_PAGE21	l_stogir.339
    2590:      	ldr	x16, [x16]
		0000000000002590:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    2594:      	ldr	w19, [x16]
    2598:      	lsr	w15, w15, #0
    259c:      	cmp	x15, x19
    25a0:      	b.eq	0x25b8 <_stogir.verify.classifications+0x2e0>
    25a4:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		00000000000025a4:  ARM64_RELOC_PAGE21	l_stogir.340
    25a8:      	ldr	x16, [x16]
		00000000000025a8:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    25ac:      	ldr	w19, [x16]
    25b0:      	cmp	x15, x19
    25b4:      	b.ne	0x2534 <_stogir.verify.classifications+0x25c>
    25b8:      	cmp	x13, #0x1
    25bc:      	b.ne	0x25f8 <_stogir.verify.classifications+0x320>
    25c0:      	uxtb	w16, w27
    25c4:      	cmp	w16, wzr
    25c8:      	b.eq	0x25f8 <_stogir.verify.classifications+0x320>
    25cc:      	uxtb	w16, w1
    25d0:      	cmp	w16, wzr
    25d4:      	b.eq	0x2484 <_stogir.verify.classifications+0x1ac>
    25d8:      	uxtb	w16, w2
    25dc:      	cmp	w16, wzr
    25e0:      	b.eq	0x23f4 <_stogir.verify.classifications+0x11c>
    25e4:      	uxtb	w16, w12
    25e8:      	cmp	w16, wzr
    25ec:      	b.eq	0x27d8 <_stogir.verify.classifications+0x500>
    25f0:      	mov	x20, x3
    25f4:      	b	0x27dc <_stogir.verify.classifications+0x504>
    25f8:      	cmp	x13, #0x1
    25fc:      	b.ne	0x2668 <_stogir.verify.classifications+0x390>
    2600:      	ldr	w14, [x24, #0x4]
    2604:      	sxtw	x14, w14
    2608:      	lsr	w14, w14, #0
    260c:      	sxtw	x14, w14
    2610:      	cmp	x14, #0x0
    2614:      	cset	w15, gt
    2618:      	movz	x16, #0x0, lsl #48
    261c:      	sub	x19, x16, x14
    2620:      	sub	x21, x19, #0x1
    2624:      	uxtb	w16, w15
    2628:      	cmp	w16, wzr
    262c:      	b.eq	0x267c <_stogir.verify.classifications+0x3a4>
    2630:      	ldr	x19, [x22, #0x8]
    2634:      	cmp	x14, x19
    2638:      	b.ge	0x24b8 <_stogir.verify.classifications+0x1e0>
    263c:      	ldr	x19, [x6, #0x8]
    2640:      	cmp	x14, x19
    2644:      	b.ge	0x2474 <_stogir.verify.classifications+0x19c>
    2648:      	ldr	x19, [x22, #0x78]
    264c:      	add	x19, x19, x14, lsl #2
    2650:      	ldr	w19, [x19]
    2654:      	sxtw	x19, w19
    2658:      	cmp	x19, #0x0
    265c:      	cset	w19, ge
    2660:      	ubfx	x19, x19, #0, #8
    2664:      	b	0x2478 <_stogir.verify.classifications+0x1a0>
    2668:      	cmp	x13, #0x2
    266c:      	b.ne	0x26bc <_stogir.verify.classifications+0x3e4>
    2670:      	ldr	w14, [x24, #0x8]
    2674:      	sxtw	x14, w14
    2678:      	b	0x2608 <_stogir.verify.classifications+0x330>
    267c:      	cmp	x14, #0x0
    2680:      	b.ge	0x24c0 <_stogir.verify.classifications+0x1e8>
    2684:      	ldr	x26, [x7, #0x8]
    2688:      	ldr	x28, [x8, #0x8]
    268c:      	cmp	x26, x28
    2690:      	b.ne	0x247c <_stogir.verify.classifications+0x1a4>
    2694:      	cmp	x19, x26
    2698:      	b.gt	0x23ec <_stogir.verify.classifications+0x114>
    269c:      	ldr	x19, [x22, #0x50]
    26a0:      	add	x19, x19, x21, lsl #2
    26a4:      	ldr	w19, [x19]
    26a8:      	sxtw	x19, w19
    26ac:      	cmp	x19, #0x0
    26b0:      	cset	w19, gt
    26b4:      	ubfx	x19, x19, #0, #8
    26b8:      	b	0x23f0 <_stogir.verify.classifications+0x118>
    26bc:      	cmp	x13, #0x3
    26c0:      	b.ne	0x2734 <_stogir.verify.classifications+0x45c>
    26c4:      	ldr	w14, [x24, #0xc]
    26c8:      	sxtw	x14, w14
    26cc:      	b	0x2678 <_stogir.verify.classifications+0x3a0>
    26d0:      	uxtb	w20, w20
    26d4:      	uxtb	w0, w0
    26d8:      	add	x16, sp, #0x10
    26dc:      	movz	w17, #0x0, lsl #16
    26e0:      	strh	w17, [x16]
    26e4:      	add	x16, sp, #0x10
    26e8:      	strb	w20, [x16]
    26ec:      	add	x16, sp, #0x10
    26f0:      	strb	w0, [x16, #0x1]
    26f4:      	add	x16, sp, #0x10
    26f8:      	ldrh	w0, [x16]
    26fc:      	ldr	x19, [sp, #0x20]
    2700:      	ldr	x20, [sp, #0x28]
    2704:      	ldr	x21, [sp, #0x30]
    2708:      	ldr	x22, [sp, #0x38]
    270c:      	ldr	x23, [sp, #0x40]
    2710:      	ldr	x24, [sp, #0x48]
    2714:      	ldr	x25, [sp, #0x50]
    2718:      	ldr	x26, [sp, #0x58]
    271c:      	ldr	x27, [sp, #0x60]
    2720:      	ldr	x28, [sp, #0x68]
    2724:      	ldr	x29, [sp]
    2728:      	ldr	x30, [sp, #0x8]
    272c:      	add	sp, sp, #0x70
    2730:      	ret
    2734:      	uxtb	w16, w10
    2738:      	cmp	w16, wzr
    273c:      	b.ne	0x27ec <_stogir.verify.classifications+0x514>
    2740:      	ldr	x15, [x22, #0x8]
    2744:      	cmp	x23, x15
    2748:      	b.ge	0x27ec <_stogir.verify.classifications+0x514>
    274c:      	ldr	x15, [x9, #0x8]
    2750:      	cmp	x23, x15
    2754:      	b.ge	0x27ec <_stogir.verify.classifications+0x514>
    2758:      	ldr	x15, [x22, #0x78]
    275c:      	add	x15, x11, x15
    2760:      	ldr	w15, [x15]
    2764:      	sxtw	x15, w15
    2768:      	cmp	x15, #0x0
    276c:      	b.lt	0x27ec <_stogir.verify.classifications+0x514>
    2770:      	cmp	x14, #0x1
    2774:      	b.lt	0x286c <_stogir.verify.classifications+0x594>
    2778:      	ldr	x15, [x22, #0x78]
    277c:      	add	x15, x11, x15
    2780:      	ldr	w15, [x15]
    2784:      	sxtw	x15, w15
    2788:      	cmp	x14, x15
    278c:      	b.gt	0x286c <_stogir.verify.classifications+0x594>
    2790:      	ldr	x15, [x22]
    2794:      	asr	x16, x14, #63
    2798:      	lsr	x16, x16, #62
    279c:      	add	x19, x14, x16
    27a0:      	asr	x19, x19, #2
    27a4:      	asr	x16, x14, #63
    27a8:      	lsr	x16, x16, #62
    27ac:      	add	x14, x14, x16
    27b0:      	and	x14, x14, #0x3
    27b4:      	sub	x14, x14, x16
    27b8:      	add	x19, x19, x23
    27bc:      	add	x15, x15, x19, lsl #4
    27c0:      	add	x14, x15, x14, lsl #2
    27c4:      	ldr	w14, [x14]
    27c8:      	sxtw	x14, w14
    27cc:      	and	x14, x14, #0xffffffff
    27d0:      	mov	x15, #0x1               ; =1
    27d4:      	b	0x2874 <_stogir.verify.classifications+0x59c>
    27d8:      	movz	x20, #0x0, lsl #48
    27dc:      	b	0x23f8 <_stogir.verify.classifications+0x120>
    27e0:      	lsr	w14, w14, #0
    27e4:      	sxtw	x14, w14
    27e8:      	b	0x26cc <_stogir.verify.classifications+0x3f4>
    27ec:      	movz	x15, #0x0, lsl #48
    27f0:      	movz	x14, #0x0, lsl #48
    27f4:      	lsr	w15, w15, #0
    27f8:      	lsr	x16, x15, #0
    27fc:      	cmp	x16, #0x1
    2800:      	b.eq	0x281c <_stogir.verify.classifications+0x544>
    2804:      	b.lo	0x280c <_stogir.verify.classifications+0x534>
    2808:      	b	0x2820 <_stogir.verify.classifications+0x548>
    280c:      	cmp	x16, #0x0
    2810:      	b.eq	0x2818 <_stogir.verify.classifications+0x540>
    2814:      	b	0x2820 <_stogir.verify.classifications+0x548>
    2818:      	b	0x2824 <_stogir.verify.classifications+0x54c>
    281c:      	b	0x27e0 <_stogir.verify.classifications+0x508>
    2820:      	b	0x2888 <_stogir.verify.classifications+0x5b0>
    2824:      	movz	x14, #0x0, lsl #48
    2828:      	b	0x27e8 <_stogir.verify.classifications+0x510>
    282c:      	cmp	x19, #0x18
    2830:      	b.ne	0x283c <_stogir.verify.classifications+0x564>
    2834:      	mov	x0, #0x1                ; =1
    2838:      	b	0x23e8 <_stogir.verify.classifications+0x110>
    283c:      	cmp	x19, #0x19
    2840:      	b.ne	0x284c <_stogir.verify.classifications+0x574>
    2844:      	mov	x0, #0x1                ; =1
    2848:      	b	0x23e8 <_stogir.verify.classifications+0x110>
    284c:      	cmp	x21, #0xc
    2850:      	b.eq	0x23e4 <_stogir.verify.classifications+0x10c>
    2854:      	cmp	x21, #0xd
    2858:      	b.eq	0x23e4 <_stogir.verify.classifications+0x10c>
    285c:      	cmp	x28, #0xc
    2860:      	b.ne	0x2878 <_stogir.verify.classifications+0x5a0>
    2864:      	mov	x0, #0x1                ; =1
    2868:      	b	0x2884 <_stogir.verify.classifications+0x5ac>
    286c:      	movz	x15, #0x0, lsl #48
    2870:      	movz	x14, #0x0, lsl #48
    2874:      	b	0x27f4 <_stogir.verify.classifications+0x51c>
    2878:      	cmp	x28, #0xd
    287c:      	cset	w0, eq
    2880:      	ubfx	x0, x0, #0, #8
    2884:      	b	0x23e8 <_stogir.verify.classifications+0x110>
    2888:      	brk	#0
    288c:      	b	0x2888 <_stogir.verify.classifications+0x5b0>

0000000000002890 <_stogir.vector.validate>:
    2890:      	sub	sp, sp, #0x210
    2894:      	str	x29, [sp]
    2898:      	str	x30, [sp, #0x8]
    289c:      	mov	x29, sp
    28a0:      	str	x19, [sp, #0x1c0]
    28a4:      	str	x20, [sp, #0x1c8]
    28a8:      	str	x21, [sp, #0x1d0]
    28ac:      	str	x22, [sp, #0x1d8]
    28b0:      	str	x23, [sp, #0x1e0]
    28b4:      	str	x24, [sp, #0x1e8]
    28b8:      	str	x25, [sp, #0x1f0]
    28bc:      	str	x26, [sp, #0x1f8]
    28c0:      	str	x27, [sp, #0x200]
    28c4:      	str	x28, [sp, #0x208]
    28c8:      	lsr	w19, w1, #0
    28cc:      	mov	x20, x8
    28d0:      	add	x8, sp, #0x10
    28d4:      	mov	x21, x0
    28d8:      	mov	w22, w1
    28dc:      	mov	w1, w19
    28e0:      	mov	w23, w2
    28e4:      	bl	0x28e4 <_stogir.vector.validate+0x54>
		00000000000028e4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    28e8:      	add	x16, sp, #0x10
    28ec:      	ldr	w0, [x16]
    28f0:      	lsr	x16, x0, #0
    28f4:      	cmp	x16, #0x1
    28f8:      	b.eq	0x2914 <_stogir.vector.validate+0x84>
    28fc:      	b.lo	0x2904 <_stogir.vector.validate+0x74>
    2900:      	b	0x2918 <_stogir.vector.validate+0x88>
    2904:      	cmp	x16, #0x0
    2908:      	b.eq	0x2910 <_stogir.vector.validate+0x80>
    290c:      	b	0x2918 <_stogir.vector.validate+0x88>
    2910:      	b	0x291c <_stogir.vector.validate+0x8c>
    2914:      	b	0x29b0 <_stogir.vector.validate+0x120>
    2918:      	b	0x2bcc <_stogir.vector.validate+0x33c>
    291c:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		000000000000291c:  ARM64_RELOC_PAGE21	l_stogir.341
    2920:      	ldr	x16, [x16]
		0000000000002920:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    2924:      	orr	x19, x16, xzr
    2928:      	str	x20, [sp, #0x1a8]
    292c:      	mov	x0, #0x1                ; =1
    2930:      	mov	x25, #0x1a              ; =26
    2934:      	b	0x2968 <_stogir.vector.validate+0xd8>
    2938:      	lsr	w23, w23, #0
    293c:      	add	x8, sp, #0x70
    2940:      	mov	x0, x21
    2944:      	ldr	w1, [sp, #0x1a0]
    2948:      	mov	w2, w23
    294c:      	bl	0x294c <_stogir.vector.validate+0xbc>
		000000000000294c:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    2950:      	add	x16, sp, #0x70
    2954:      	ldr	x0, [x16]
    2958:      	add	x16, sp, #0x70
    295c:      	ldr	x19, [x16, #0x8]
    2960:      	add	x16, sp, #0x70
    2964:      	ldr	x25, [x16, #0x10]
    2968:      	ldr	x1, [sp, #0x1a8]
    296c:      	str	x0, [x1]
    2970:      	str	x19, [x1, #0x8]
    2974:      	str	x25, [x1, #0x10]
    2978:      	ldr	x19, [sp, #0x1c0]
    297c:      	ldr	x20, [sp, #0x1c8]
    2980:      	ldr	x21, [sp, #0x1d0]
    2984:      	ldr	x22, [sp, #0x1d8]
    2988:      	ldr	x23, [sp, #0x1e0]
    298c:      	ldr	x24, [sp, #0x1e8]
    2990:      	ldr	x25, [sp, #0x1f0]
    2994:      	ldr	x26, [sp, #0x1f8]
    2998:      	ldr	x27, [sp, #0x200]
    299c:      	ldr	x28, [sp, #0x208]
    29a0:      	ldr	x29, [sp]
    29a4:      	ldr	x30, [sp, #0x8]
    29a8:      	add	sp, sp, #0x210
    29ac:      	ret
    29b0:      	sxtw	x22, w22
    29b4:      	add	x16, sp, #0x10
    29b8:      	orr	x0, x16, xzr
    29bc:      	cmp	x22, #0x0
    29c0:      	cset	w24, le
    29c4:      	add	x0, x0, #0x8
    29c8:      	add	x16, sp, #0x10
    29cc:      	ldr	x25, [x16, #0x8]
    29d0:      	add	x16, sp, #0x40
    29d4:      	str	x25, [x16]
    29d8:      	ldr	x0, [x0, #0x8]
    29dc:      	add	x16, sp, #0x40
    29e0:      	str	x0, [x16, #0x8]
    29e4:      	uxtb	w16, w24
    29e8:      	cmp	w16, wzr
    29ec:      	b.eq	0x2a0c <_stogir.vector.validate+0x17c>
    29f0:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		00000000000029f0:  ARM64_RELOC_PAGE21	l_stogir.342
    29f4:      	ldr	x16, [x16]
		00000000000029f4:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    29f8:      	orr	x19, x16, xzr
    29fc:      	str	x20, [sp, #0x1a8]
    2a00:      	mov	x0, #0x1                ; =1
    2a04:      	mov	x25, #0x3b              ; =59
    2a08:      	b	0x2968 <_stogir.vector.validate+0xd8>
    2a0c:      	lsl	x26, x22, #2
    2a10:      	uxtb	w0, w25
    2a14:      	orr	x27, x0, xzr
    2a18:      	ldr	x0, [x21, #0x78]
    2a1c:      	cmp	x27, #0x44
    2a20:      	cset	w1, eq
    2a24:      	add	x0, x0, x22, lsl #2
    2a28:      	ldr	w28, [x0]
    2a2c:      	cmp	x27, #0x24
    2a30:      	b.ne	0x2a74 <_stogir.vector.validate+0x1e4>
    2a34:      	str	x20, [sp, #0x1a8]
    2a38:      	str	w19, [sp, #0x1a0]
    2a3c:      	uxtb	w16, w1
    2a40:      	cmp	w16, wzr
    2a44:      	b.eq	0x2938 <_stogir.vector.validate+0xa8>
    2a48:      	add	x8, sp, #0x50
    2a4c:      	mov	x0, x21
    2a50:      	ldr	w1, [sp, #0x1a0]
    2a54:      	bl	0x2a54 <_stogir.vector.validate+0x1c4>
		0000000000002a54:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    2a58:      	add	x16, sp, #0x50
    2a5c:      	ldr	x0, [x16]
    2a60:      	add	x16, sp, #0x50
    2a64:      	ldr	x19, [x16, #0x8]
    2a68:      	add	x16, sp, #0x50
    2a6c:      	ldr	x25, [x16, #0x10]
    2a70:      	b	0x2968 <_stogir.vector.validate+0xd8>
    2a74:      	uxtb	w16, w1
    2a78:      	cmp	w16, wzr
    2a7c:      	b.ne	0x32f4 <_stogir.vector.validate+0xa64>
    2a80:      	cmp	x27, #0x3c
    2a84:      	b.ne	0x2b38 <_stogir.vector.validate+0x2a8>
    2a88:      	add	x8, sp, #0x90
    2a8c:      	mov	x0, x21
    2a90:      	mov	w1, w19
    2a94:      	bl	0x2a94 <_stogir.vector.validate+0x204>
		0000000000002a94:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    2a98:      	add	x16, sp, #0x90
    2a9c:      	ldr	x0, [x16]
    2aa0:      	add	x16, sp, #0x90
    2aa4:      	ldr	x19, [x16, #0x8]
    2aa8:      	add	x16, sp, #0x90
    2aac:      	ldr	x25, [x16, #0x10]
    2ab0:      	str	x20, [sp, #0x1a8]
    2ab4:      	b	0x2b34 <_stogir.vector.validate+0x2a4>
    2ab8:      	cmp	x27, #0x41
    2abc:      	cset	w0, eq
    2ac0:      	cmp	x27, #0x48
    2ac4:      	cset	w1, eq
    2ac8:      	cmp	x27, #0x55
    2acc:      	cset	w2, ge
    2ad0:      	cmp	x27, #0x58
    2ad4:      	cset	w3, le
    2ad8:      	cmp	x27, #0x47
    2adc:      	b.ne	0x2bd4 <_stogir.vector.validate+0x344>
    2ae0:      	str	x20, [sp, #0x1a8]
    2ae4:      	str	w19, [sp, #0x1a0]
    2ae8:      	mov	w19, w0
    2aec:      	mov	w20, w1
    2af0:      	str	w2, [sp, #0x1b0]
    2af4:      	str	w3, [sp, #0x1b8]
    2af8:      	mov	x0, x21
    2afc:      	ldr	w1, [sp, #0x1a0]
    2b00:      	bl	0x2b00 <_stogir.vector.validate+0x270>
		0000000000002b00:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2b04:      	cmp	x0, #0x0
    2b08:      	b.eq	0x2bf8 <_stogir.vector.validate+0x368>
    2b0c:      	add	x8, sp, #0xf0
    2b10:      	mov	x0, x21
    2b14:      	ldr	w1, [sp, #0x1a0]
    2b18:      	bl	0x2b18 <_stogir.vector.validate+0x288>
		0000000000002b18:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    2b1c:      	add	x16, sp, #0xf0
    2b20:      	ldr	x0, [x16]
    2b24:      	add	x16, sp, #0xf0
    2b28:      	ldr	x19, [x16, #0x8]
    2b2c:      	add	x16, sp, #0xf0
    2b30:      	ldr	x25, [x16, #0x10]
    2b34:      	b	0x2968 <_stogir.vector.validate+0xd8>
    2b38:      	cmp	x27, #0x3d
    2b3c:      	b.lt	0x2b80 <_stogir.vector.validate+0x2f0>
    2b40:      	cmp	x27, #0x3f
    2b44:      	b.gt	0x2b80 <_stogir.vector.validate+0x2f0>
    2b48:      	lsr	w23, w23, #0
    2b4c:      	add	x8, sp, #0xb0
    2b50:      	mov	x0, x21
    2b54:      	mov	w1, w19
    2b58:      	mov	w2, w23
    2b5c:      	bl	0x2b5c <_stogir.vector.validate+0x2cc>
		0000000000002b5c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    2b60:      	add	x16, sp, #0xb0
    2b64:      	ldr	x0, [x16]
    2b68:      	add	x16, sp, #0xb0
    2b6c:      	ldr	x19, [x16, #0x8]
    2b70:      	add	x16, sp, #0xb0
    2b74:      	ldr	x25, [x16, #0x10]
    2b78:      	str	x20, [sp, #0x1a8]
    2b7c:      	b	0x2b34 <_stogir.vector.validate+0x2a4>
    2b80:      	mov	x0, x21
    2b84:      	mov	w1, w19
    2b88:      	bl	0x2b88 <_stogir.vector.validate+0x2f8>
		0000000000002b88:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    2b8c:      	cmp	x0, #0x0
    2b90:      	b.eq	0x2ab8 <_stogir.vector.validate+0x228>
    2b94:      	lsr	w23, w23, #0
    2b98:      	add	x8, sp, #0xd0
    2b9c:      	mov	x0, x21
    2ba0:      	mov	w1, w19
    2ba4:      	mov	w2, w23
    2ba8:      	bl	0x2ba8 <_stogir.vector.validate+0x318>
		0000000000002ba8:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    2bac:      	add	x16, sp, #0xd0
    2bb0:      	ldr	x0, [x16]
    2bb4:      	add	x16, sp, #0xd0
    2bb8:      	ldr	x19, [x16, #0x8]
    2bbc:      	add	x16, sp, #0xd0
    2bc0:      	ldr	x25, [x16, #0x10]
    2bc4:      	str	x20, [sp, #0x1a8]
    2bc8:      	b	0x2b34 <_stogir.vector.validate+0x2a4>
    2bcc:      	brk	#0
    2bd0:      	b	0x2bcc <_stogir.vector.validate+0x33c>
    2bd4:      	cmp	x27, #0x4f
    2bd8:      	b.ne	0x2c74 <_stogir.vector.validate+0x3e4>
    2bdc:      	str	x20, [sp, #0x1a8]
    2be0:      	str	w19, [sp, #0x1a0]
    2be4:      	mov	w19, w0
    2be8:      	mov	w20, w1
    2bec:      	str	w2, [sp, #0x1b0]
    2bf0:      	str	w3, [sp, #0x1b8]
    2bf4:      	b	0x2af8 <_stogir.vector.validate+0x268>
    2bf8:      	uxtb	w16, w19
    2bfc:      	cmp	w16, wzr
    2c00:      	b.ne	0x2c40 <_stogir.vector.validate+0x3b0>
    2c04:      	uxtb	w16, w20
    2c08:      	cmp	w16, wzr
    2c0c:      	b.ne	0x2c40 <_stogir.vector.validate+0x3b0>
    2c10:      	ldr	w0, [sp, #0x1b0]
    2c14:      	uxtb	w16, w0
    2c18:      	cmp	w16, wzr
    2c1c:      	b.eq	0x2c30 <_stogir.vector.validate+0x3a0>
    2c20:      	ldr	w0, [sp, #0x1b8]
    2c24:      	uxtb	w16, w0
    2c28:      	cmp	w16, wzr
    2c2c:      	b.ne	0x2c40 <_stogir.vector.validate+0x3b0>
    2c30:      	movz	x0, #0x0, lsl #48
    2c34:      	movz	x19, #0x0, lsl #48
    2c38:      	movz	x25, #0x0, lsl #48
    2c3c:      	b	0x2c70 <_stogir.vector.validate+0x3e0>
    2c40:      	lsr	w23, w23, #0
    2c44:      	add	x8, sp, #0x110
    2c48:      	mov	x0, x21
    2c4c:      	ldr	w1, [sp, #0x1a0]
    2c50:      	mov	w2, w23
    2c54:      	bl	0x2c54 <_stogir.vector.validate+0x3c4>
		0000000000002c54:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    2c58:      	add	x16, sp, #0x110
    2c5c:      	ldr	x0, [x16]
    2c60:      	add	x16, sp, #0x110
    2c64:      	ldr	x19, [x16, #0x8]
    2c68:      	add	x16, sp, #0x110
    2c6c:      	ldr	x25, [x16, #0x10]
    2c70:      	b	0x2b34 <_stogir.vector.validate+0x2a4>
    2c74:      	cmp	x27, #0x50
    2c78:      	b.eq	0x3300 <_stogir.vector.validate+0xa70>
    2c7c:      	cmp	x27, #0x78
    2c80:      	b.ne	0x2ca0 <_stogir.vector.validate+0x410>
    2c84:      	str	x20, [sp, #0x1a8]
    2c88:      	str	w19, [sp, #0x1a0]
    2c8c:      	mov	w19, w0
    2c90:      	mov	w20, w1
    2c94:      	str	w2, [sp, #0x1b0]
    2c98:      	str	w3, [sp, #0x1b8]
    2c9c:      	b	0x2af8 <_stogir.vector.validate+0x268>
    2ca0:      	uxtb	w16, w0
    2ca4:      	cmp	w16, wzr
    2ca8:      	b.ne	0x2da0 <_stogir.vector.validate+0x510>
    2cac:      	uxtb	w16, w1
    2cb0:      	cmp	w16, wzr
    2cb4:      	b.ne	0x2da0 <_stogir.vector.validate+0x510>
    2cb8:      	uxtb	w16, w2
    2cbc:      	cmp	w16, wzr
    2cc0:      	b.eq	0x2cd0 <_stogir.vector.validate+0x440>
    2cc4:      	uxtb	w16, w3
    2cc8:      	cmp	w16, wzr
    2ccc:      	b.ne	0x2da0 <_stogir.vector.validate+0x510>
    2cd0:      	str	w2, [sp, #0x1b0]
    2cd4:      	str	w3, [sp, #0x1b8]
    2cd8:      	str	w19, [sp, #0x1a0]
    2cdc:      	str	x20, [sp, #0x1a8]
    2ce0:      	mov	w20, w1
    2ce4:      	mov	w1, w19
    2ce8:      	mov	w19, w0
    2cec:      	mov	x0, x21
    2cf0:      	bl	0x2cf0 <_stogir.vector.validate+0x460>
		0000000000002cf0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2cf4:      	cmp	x0, #0x0
    2cf8:      	b.ne	0x2af8 <_stogir.vector.validate+0x268>
    2cfc:      	sxtw	x28, w28
    2d00:      	lsr	w25, w25, #0
    2d04:      	ubfx	x0, x25, #8, #8
    2d08:      	orr	x1, x0, xzr
    2d0c:      	lsr	w20, w1, #0
    2d10:      	cmp	x27, #0x5b
    2d14:      	b.eq	0x2dd4 <_stogir.vector.validate+0x544>
    2d18:      	cmp	x27, #0x5c
    2d1c:      	b.eq	0x2dd4 <_stogir.vector.validate+0x544>
    2d20:      	orr	x25, x0, xzr
    2d24:      	cmp	x27, #0x5d
    2d28:      	b.ne	0x2e48 <_stogir.vector.validate+0x5b8>
    2d2c:      	mov	x27, x25
    2d30:      	cmp	x28, #0x3
    2d34:      	b.ne	0x2e30 <_stogir.vector.validate+0x5a0>
    2d38:      	cmp	x27, #0x0
    2d3c:      	b.ne	0x2e30 <_stogir.vector.validate+0x5a0>
    2d40:      	lsr	w23, w23, #0
    2d44:      	add	x16, sp, #0x40
    2d48:      	ldr	w0, [x16, #0x4]
    2d4c:      	add	x16, sp, #0x40
    2d50:      	ldr	w1, [x16, #0x8]
    2d54:      	lsr	w0, w0, #0
    2d58:      	add	x16, sp, #0x40
    2d5c:      	ldr	w2, [x16, #0xc]
    2d60:      	lsr	w1, w1, #0
    2d64:      	lsr	w2, w2, #0
    2d68:      	add	x8, sp, #0x150
    2d6c:      	mov	w3, w1
    2d70:      	mov	w1, w23
    2d74:      	mov	w4, w2
    2d78:      	mov	w2, w0
    2d7c:      	mov	x0, x21
    2d80:      	bl	0x2d80 <_stogir.vector.validate+0x4f0>
		0000000000002d80:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    2d84:      	add	x16, sp, #0x150
    2d88:      	ldr	x0, [x16]
    2d8c:      	add	x16, sp, #0x150
    2d90:      	ldr	x19, [x16, #0x8]
    2d94:      	add	x16, sp, #0x150
    2d98:      	ldr	x25, [x16, #0x10]
    2d9c:      	b	0x2e44 <_stogir.vector.validate+0x5b4>
    2da0:      	str	x20, [sp, #0x1a8]
    2da4:      	str	w19, [sp, #0x1a0]
    2da8:      	mov	w19, w0
    2dac:      	mov	w20, w1
    2db0:      	str	w2, [sp, #0x1b0]
    2db4:      	str	w3, [sp, #0x1b8]
    2db8:      	b	0x2af8 <_stogir.vector.validate+0x268>
    2dbc:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		0000000000002dbc:  ARM64_RELOC_PAGE21	l_stogir.343
    2dc0:      	ldr	x16, [x16]
		0000000000002dc0:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    2dc4:      	orr	x19, x16, xzr
    2dc8:      	mov	x0, #0x1                ; =1
    2dcc:      	mov	x25, #0x19              ; =25
    2dd0:      	b	0x2b34 <_stogir.vector.validate+0x2a4>
    2dd4:      	cmp	x28, #0x2
    2dd8:      	b.ne	0x2dbc <_stogir.vector.validate+0x52c>
    2ddc:      	lsr	w23, w23, #0
    2de0:      	add	x16, sp, #0x40
    2de4:      	ldr	w0, [x16, #0x4]
    2de8:      	add	x16, sp, #0x40
    2dec:      	ldr	w1, [x16, #0x8]
    2df0:      	lsr	w0, w0, #0
    2df4:      	lsr	w1, w1, #0
    2df8:      	add	x8, sp, #0x130
    2dfc:      	mov	w2, w23
    2e00:      	mov	w3, w0
    2e04:      	mov	x0, x21
    2e08:      	mov	w4, w1
    2e0c:      	mov	w1, w20
    2e10:      	bl	0x2e10 <_stogir.vector.validate+0x580>
		0000000000002e10:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    2e14:      	add	x16, sp, #0x130
    2e18:      	ldr	x0, [x16]
    2e1c:      	add	x16, sp, #0x130
    2e20:      	ldr	x19, [x16, #0x8]
    2e24:      	add	x16, sp, #0x130
    2e28:      	ldr	x25, [x16, #0x10]
    2e2c:      	b	0x2dd0 <_stogir.vector.validate+0x540>
    2e30:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		0000000000002e30:  ARM64_RELOC_PAGE21	l_stogir.344
    2e34:      	ldr	x16, [x16]
		0000000000002e34:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    2e38:      	orr	x19, x16, xzr
    2e3c:      	mov	x0, #0x1                ; =1
    2e40:      	mov	x25, #0x1a              ; =26
    2e44:      	b	0x2dd0 <_stogir.vector.validate+0x540>
    2e48:      	cmp	x27, #0x5e
    2e4c:      	b.eq	0x331c <_stogir.vector.validate+0xa8c>
    2e50:      	cmp	x27, #0x43
    2e54:      	b.ne	0x2ecc <_stogir.vector.validate+0x63c>
    2e58:      	cmp	x25, #0xf
    2e5c:      	b.le	0x320c <_stogir.vector.validate+0x97c>
    2e60:      	cmp	x25, #0x80
    2e64:      	b.ge	0x320c <_stogir.vector.validate+0x97c>
    2e68:      	and	x0, x25, #0xf
    2e6c:      	lsr	w0, w0, #0
    2e70:      	sxtw	x0, w0
    2e74:      	cmp	x0, #0x1
    2e78:      	b.lt	0x320c <_stogir.vector.validate+0x97c>
    2e7c:      	cmp	x0, #0xd
    2e80:      	b.gt	0x320c <_stogir.vector.validate+0x97c>
    2e84:      	lsr	w23, w23, #0
    2e88:      	mov	w0, w20
    2e8c:      	mov	w1, w23
    2e90:      	bl	0x2e90 <_stogir.vector.validate+0x600>
		0000000000002e90:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2e94:      	lsr	w0, w0, #0
    2e98:      	sxtw	x0, w0
    2e9c:      	cmp	x0, #0x0
    2ea0:      	b.le	0x320c <_stogir.vector.validate+0x97c>
    2ea4:      	cmp	x28, #0x3
    2ea8:      	b.lt	0x320c <_stogir.vector.validate+0x97c>
    2eac:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		0000000000002eac:  ARM64_RELOC_PAGE21	l_stogir.345
    2eb0:      	ldr	x16, [x16]
		0000000000002eb0:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    2eb4:      	orr	x19, x16, xzr
    2eb8:      	mov	x27, x25
    2ebc:      	movz	x25, #0x0, lsl #48
    2ec0:      	b	0x3220 <_stogir.vector.validate+0x990>
    2ec4:      	mov	x0, #0x1                ; =1
    2ec8:      	b	0x2e44 <_stogir.vector.validate+0x5b4>
    2ecc:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		0000000000002ecc:  ARM64_RELOC_PAGE21	l_stogir.346
    2ed0:      	ldr	x16, [x16]
		0000000000002ed0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    2ed4:      	orr	x19, x16, xzr
    2ed8:      	mov	x0, #0x1                ; =1
    2edc:      	mov	x25, #0x28              ; =40
    2ee0:      	b	0x2ec8 <_stogir.vector.validate+0x638>
    2ee4:      	add	x16, sp, #0x40
    2ee8:      	ldr	w0, [x16, #0x4]
    2eec:      	sxtw	x0, w0
    2ef0:      	ldr	x1, [x21, #0x78]
    2ef4:      	add	x0, x1, x0, lsl #2
    2ef8:      	ldr	w0, [x0]
    2efc:      	sxtw	x0, w0
    2f00:      	add	x0, x0, #0x1
    2f04:      	lsr	w0, w0, #0
    2f08:      	sxtw	x0, w0
    2f0c:      	cmp	x28, x0
    2f10:      	cset	w0, eq
    2f14:      	uxtb	w16, w0
    2f18:      	cmp	w16, wzr
    2f1c:      	cset	x0, eq
    2f20:      	cmp	x0, #0x0
    2f24:      	b.eq	0x2f38 <_stogir.vector.validate+0x6a8>
    2f28:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		0000000000002f28:  ARM64_RELOC_PAGE21	l_stogir.347
    2f2c:      	ldr	x16, [x16]
		0000000000002f2c:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    2f30:      	orr	x19, x16, xzr
    2f34:      	mov	x25, #0x19              ; =25
    2f38:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		0000000000002f38:  ARM64_RELOC_PAGE21	l_stogir.348
    2f3c:      	ldr	x16, [x16]
		0000000000002f3c:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    2f40:      	orr	x0, x16, xzr
    2f44:      	adrp	x16, 0x2000 <_stogir.types.valid?>
		0000000000002f44:  ARM64_RELOC_PAGE21	l_stogir.349
    2f48:      	ldr	x16, [x16]
		0000000000002f48:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    2f4c:      	orr	x1, x16, xzr
    2f50:      	add	x2, x21, #0x78
    2f54:      	add	x3, x21, #0x28
    2f58:      	add	x4, x21, #0x50
    2f5c:      	add	x5, x21, #0x78
    2f60:      	mov	x6, #0x2                ; =2
    2f64:      	b	0x2fdc <_stogir.vector.validate+0x74c>
    2f68:      	lsr	w7, w7, #0
    2f6c:      	ubfx	x7, x7, #8, #8
    2f70:      	cmp	x7, x27
    2f74:      	b.eq	0x2f80 <_stogir.vector.validate+0x6f0>
    2f78:      	mov	x19, x1
    2f7c:      	mov	x25, #0x1e              ; =30
    2f80:      	b	0x2fd0 <_stogir.vector.validate+0x740>
    2f84:      	movz	x8, #0x0, lsl #48
    2f88:      	movz	x7, #0x0, lsl #48
    2f8c:      	b	0x2f98 <_stogir.vector.validate+0x708>
    2f90:      	movz	x8, #0x0, lsl #48
    2f94:      	movz	x7, #0x0, lsl #48
    2f98:      	lsr	w8, w8, #0
    2f9c:      	lsr	x16, x8, #0
    2fa0:      	cmp	x16, #0x1
    2fa4:      	b.eq	0x2fc0 <_stogir.vector.validate+0x730>
    2fa8:      	b.lo	0x2fb0 <_stogir.vector.validate+0x720>
    2fac:      	b	0x2fc4 <_stogir.vector.validate+0x734>
    2fb0:      	cmp	x16, #0x0
    2fb4:      	b.eq	0x2fbc <_stogir.vector.validate+0x72c>
    2fb8:      	b	0x2fc4 <_stogir.vector.validate+0x734>
    2fbc:      	b	0x2fc8 <_stogir.vector.validate+0x738>
    2fc0:      	b	0x3030 <_stogir.vector.validate+0x7a0>
    2fc4:      	b	0x32dc <_stogir.vector.validate+0xa4c>
    2fc8:      	mov	x19, x0
    2fcc:      	mov	x25, #0x18              ; =24
    2fd0:      	add	x6, x6, #0x1
    2fd4:      	lsr	w6, w6, #0
    2fd8:      	sxtw	x6, w6
    2fdc:      	cmp	x25, #0x0
    2fe0:      	b.ne	0x3154 <_stogir.vector.validate+0x8c4>
    2fe4:      	cmp	x6, x28
    2fe8:      	b.gt	0x3154 <_stogir.vector.validate+0x8c4>
    2fec:      	uxtb	w16, w24
    2ff0:      	cmp	w16, wzr
    2ff4:      	b.ne	0x2f90 <_stogir.vector.validate+0x700>
    2ff8:      	ldr	x7, [x21, #0x8]
    2ffc:      	cmp	x22, x7
    3000:      	b.ge	0x3098 <_stogir.vector.validate+0x808>
    3004:      	ldr	x7, [x5, #0x8]
    3008:      	cmp	x22, x7
    300c:      	b.ge	0x3090 <_stogir.vector.validate+0x800>
    3010:      	ldr	x7, [x21, #0x78]
    3014:      	add	x7, x26, x7
    3018:      	ldr	w7, [x7]
    301c:      	sxtw	x7, w7
    3020:      	cmp	x7, #0x0
    3024:      	cset	w7, ge
    3028:      	ubfx	x7, x7, #0, #8
    302c:      	b	0x3094 <_stogir.vector.validate+0x804>
    3030:      	lsr	w7, w7, #0
    3034:      	sxtw	x7, w7
    3038:      	cmp	x7, #0x0
    303c:      	cset	w8, gt
    3040:      	movz	x16, #0x0, lsl #48
    3044:      	sub	x9, x16, x7
    3048:      	sub	x10, x9, #0x1
    304c:      	uxtb	w16, w8
    3050:      	cmp	w16, wzr
    3054:      	b.eq	0x3114 <_stogir.vector.validate+0x884>
    3058:      	ldr	x9, [x21, #0x8]
    305c:      	cmp	x7, x9
    3060:      	b.ge	0x3184 <_stogir.vector.validate+0x8f4>
    3064:      	ldr	x9, [x2, #0x8]
    3068:      	cmp	x7, x9
    306c:      	b.ge	0x328c <_stogir.vector.validate+0x9fc>
    3070:      	ldr	x9, [x21, #0x78]
    3074:      	add	x9, x9, x7, lsl #2
    3078:      	ldr	w9, [x9]
    307c:      	sxtw	x9, w9
    3080:      	cmp	x9, #0x0
    3084:      	cset	w9, ge
    3088:      	ubfx	x9, x9, #0, #8
    308c:      	b	0x3290 <_stogir.vector.validate+0xa00>
    3090:      	movz	x7, #0x0, lsl #48
    3094:      	b	0x309c <_stogir.vector.validate+0x80c>
    3098:      	movz	x7, #0x0, lsl #48
    309c:      	cmp	x7, #0x0
    30a0:      	b.eq	0x2f90 <_stogir.vector.validate+0x700>
    30a4:      	lsr	w7, w6, #0
    30a8:      	sxtw	x7, w7
    30ac:      	cmp	x7, #0x1
    30b0:      	b.lt	0x2f84 <_stogir.vector.validate+0x6f4>
    30b4:      	ldr	x8, [x21, #0x78]
    30b8:      	add	x8, x26, x8
    30bc:      	ldr	w8, [x8]
    30c0:      	sxtw	x8, w8
    30c4:      	cmp	x7, x8
    30c8:      	b.gt	0x2f84 <_stogir.vector.validate+0x6f4>
    30cc:      	ldr	x8, [x21]
    30d0:      	asr	x16, x7, #63
    30d4:      	lsr	x16, x16, #62
    30d8:      	add	x9, x7, x16
    30dc:      	asr	x9, x9, #2
    30e0:      	asr	x16, x7, #63
    30e4:      	lsr	x16, x16, #62
    30e8:      	add	x7, x7, x16
    30ec:      	and	x7, x7, #0x3
    30f0:      	sub	x7, x7, x16
    30f4:      	add	x9, x9, x22
    30f8:      	add	x8, x8, x9, lsl #4
    30fc:      	add	x7, x8, x7, lsl #2
    3100:      	ldr	w7, [x7]
    3104:      	sxtw	x7, w7
    3108:      	and	x7, x7, #0xffffffff
    310c:      	mov	x8, #0x1                ; =1
    3110:      	b	0x2f8c <_stogir.vector.validate+0x6fc>
    3114:      	cmp	x7, #0x0
    3118:      	b.ge	0x318c <_stogir.vector.validate+0x8fc>
    311c:      	ldr	x11, [x3, #0x8]
    3120:      	ldr	x12, [x4, #0x8]
    3124:      	cmp	x11, x12
    3128:      	b.ne	0x3284 <_stogir.vector.validate+0x9f4>
    312c:      	cmp	x9, x11
    3130:      	b.gt	0x32b8 <_stogir.vector.validate+0xa28>
    3134:      	ldr	x9, [x21, #0x50]
    3138:      	add	x9, x9, x10, lsl #2
    313c:      	ldr	w9, [x9]
    3140:      	sxtw	x9, w9
    3144:      	cmp	x9, #0x0
    3148:      	cset	w9, gt
    314c:      	ubfx	x9, x9, #0, #8
    3150:      	b	0x32bc <_stogir.vector.validate+0xa2c>
    3154:      	cmp	x25, #0x0
    3158:      	b.ne	0x2ec4 <_stogir.vector.validate+0x634>
    315c:      	lsr	w23, w23, #0
    3160:      	mov	w0, w20
    3164:      	mov	w1, w23
    3168:      	bl	0x3168 <_stogir.vector.validate+0x8d8>
		0000000000003168:  ARM64_RELOC_BRANCH26	_stogir.types.size
    316c:      	lsr	w0, w0, #0
    3170:      	sxtw	x0, w0
    3174:      	and	x19, x0, #0xffffffff
    3178:      	movz	x0, #0x0, lsl #48
    317c:      	movz	x25, #0x0, lsl #48
    3180:      	b	0x2ec8 <_stogir.vector.validate+0x638>
    3184:      	movz	x9, #0x0, lsl #48
    3188:      	b	0x3190 <_stogir.vector.validate+0x900>
    318c:      	movz	x9, #0x0, lsl #48
    3190:      	cmp	x9, #0x0
    3194:      	b.eq	0x31c8 <_stogir.vector.validate+0x938>
    3198:      	uxtb	w16, w8
    319c:      	cmp	w16, wzr
    31a0:      	b.eq	0x31b4 <_stogir.vector.validate+0x924>
    31a4:      	ldr	x8, [x21]
    31a8:      	add	x7, x8, x7, lsl #4
    31ac:      	ldr	x7, [x7]
    31b0:      	b	0x31c0 <_stogir.vector.validate+0x930>
    31b4:      	ldr	x7, [x21, #0x28]
    31b8:      	add	x7, x7, x10, lsl #4
    31bc:      	ldr	x7, [x7]
    31c0:      	mov	x8, #0x1                ; =1
    31c4:      	b	0x31d0 <_stogir.vector.validate+0x940>
    31c8:      	movz	x8, #0x0, lsl #48
    31cc:      	movz	x7, #0x0, lsl #48
    31d0:      	lsr	w8, w8, #0
    31d4:      	lsr	x16, x8, #0
    31d8:      	cmp	x16, #0x1
    31dc:      	b.eq	0x31f8 <_stogir.vector.validate+0x968>
    31e0:      	b.lo	0x31e8 <_stogir.vector.validate+0x958>
    31e4:      	b	0x31fc <_stogir.vector.validate+0x96c>
    31e8:      	cmp	x16, #0x0
    31ec:      	b.eq	0x31f4 <_stogir.vector.validate+0x964>
    31f0:      	b	0x31fc <_stogir.vector.validate+0x96c>
    31f4:      	b	0x3200 <_stogir.vector.validate+0x970>
    31f8:      	b	0x2f68 <_stogir.vector.validate+0x6d8>
    31fc:      	b	0x32e4 <_stogir.vector.validate+0xa54>
    3200:      	mov	x19, x0
    3204:      	mov	x25, #0x18              ; =24
    3208:      	b	0x2f80 <_stogir.vector.validate+0x6f0>
    320c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		000000000000320c:  ARM64_RELOC_PAGE21	l_stogir.350
    3210:      	ldr	x16, [x16]
		0000000000003210:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    3214:      	orr	x19, x16, xzr
    3218:      	mov	x27, x25
    321c:      	mov	x25, #0x20              ; =32
    3220:      	add	x16, sp, #0x40
    3224:      	ldr	w0, [x16, #0x4]
    3228:      	lsr	w0, w0, #0
    322c:      	add	x8, sp, #0x170
    3230:      	mov	w1, w0
    3234:      	mov	x0, x21
    3238:      	bl	0x3238 <_stogir.vector.validate+0x9a8>
		0000000000003238:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    323c:      	add	x16, sp, #0x170
    3240:      	ldr	w0, [x16]
    3244:      	lsr	x16, x0, #0
    3248:      	cmp	x16, #0x1
    324c:      	b.eq	0x3268 <_stogir.vector.validate+0x9d8>
    3250:      	b.lo	0x3258 <_stogir.vector.validate+0x9c8>
    3254:      	b	0x326c <_stogir.vector.validate+0x9dc>
    3258:      	cmp	x16, #0x0
    325c:      	b.eq	0x3264 <_stogir.vector.validate+0x9d4>
    3260:      	b	0x326c <_stogir.vector.validate+0x9dc>
    3264:      	b	0x3270 <_stogir.vector.validate+0x9e0>
    3268:      	b	0x3294 <_stogir.vector.validate+0xa04>
    326c:      	b	0x32ec <_stogir.vector.validate+0xa5c>
    3270:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003270:  ARM64_RELOC_PAGE21	l_stogir.351
    3274:      	ldr	x16, [x16]
		0000000000003274:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    3278:      	orr	x19, x16, xzr
    327c:      	mov	x25, #0x19              ; =25
    3280:      	b	0x2f38 <_stogir.vector.validate+0x6a8>
    3284:      	movz	x9, #0x0, lsl #48
    3288:      	b	0x3190 <_stogir.vector.validate+0x900>
    328c:      	movz	x9, #0x0, lsl #48
    3290:      	b	0x3188 <_stogir.vector.validate+0x8f8>
    3294:      	add	x16, sp, #0x170
    3298:      	ldr	x0, [x16, #0x8]
    329c:      	add	x16, sp, #0x40
    32a0:      	ldr	w1, [x16, #0x4]
    32a4:      	sxtw	x1, w1
    32a8:      	cmp	x1, #0x0
    32ac:      	b.gt	0x32c0 <_stogir.vector.validate+0xa30>
    32b0:      	mov	x0, #0x1                ; =1
    32b4:      	b	0x2f20 <_stogir.vector.validate+0x690>
    32b8:      	movz	x9, #0x0, lsl #48
    32bc:      	b	0x3288 <_stogir.vector.validate+0x9f8>
    32c0:      	uxtb	w0, w0
    32c4:      	cmp	x0, #0x70
    32c8:      	b.eq	0x2ee4 <_stogir.vector.validate+0x654>
    32cc:      	cmp	x0, #0x71
    32d0:      	b.eq	0x2ee4 <_stogir.vector.validate+0x654>
    32d4:      	mov	x0, #0x1                ; =1
    32d8:      	b	0x2f20 <_stogir.vector.validate+0x690>
    32dc:      	brk	#0
    32e0:      	b	0x32dc <_stogir.vector.validate+0xa4c>
    32e4:      	brk	#0
    32e8:      	b	0x32e4 <_stogir.vector.validate+0xa54>
    32ec:      	brk	#0
    32f0:      	b	0x32ec <_stogir.vector.validate+0xa5c>
    32f4:      	str	x20, [sp, #0x1a8]
    32f8:      	str	w19, [sp, #0x1a0]
    32fc:      	b	0x2a3c <_stogir.vector.validate+0x1ac>
    3300:      	str	x20, [sp, #0x1a8]
    3304:      	str	w19, [sp, #0x1a0]
    3308:      	mov	w19, w0
    330c:      	mov	w20, w1
    3310:      	str	w2, [sp, #0x1b0]
    3314:      	str	w3, [sp, #0x1b8]
    3318:      	b	0x2af8 <_stogir.vector.validate+0x268>
    331c:      	mov	x27, x25
    3320:      	b	0x2d30 <_stogir.vector.validate+0x4a0>

0000000000003324 <_stogir.copy.validate>:
    3324:      	sub	sp, sp, #0x10
    3328:      	sxtw	x1, w1
    332c:      	lsl	x2, x1, #2
    3330:      	cmp	x1, #0x0
    3334:      	cset	w3, gt
    3338:      	movz	x16, #0x0, lsl #48
    333c:      	sub	x4, x16, x1
    3340:      	sub	x5, x4, #0x1
    3344:      	uxtb	w16, w3
    3348:      	cmp	w16, wzr
    334c:      	b.eq	0x338c <_stogir.copy.validate+0x68>
    3350:      	ldr	x4, [x0, #0x8]
    3354:      	cmp	x1, x4
    3358:      	b.ge	0x33f4 <_stogir.copy.validate+0xd0>
    335c:      	add	x4, x0, #0x78
    3360:      	ldr	x4, [x4, #0x8]
    3364:      	cmp	x1, x4
    3368:      	b.ge	0x358c <_stogir.copy.validate+0x268>
    336c:      	ldr	x4, [x0, #0x78]
    3370:      	add	x4, x2, x4
    3374:      	ldr	w4, [x4]
    3378:      	sxtw	x4, w4
    337c:      	cmp	x4, #0x0
    3380:      	cset	w4, ge
    3384:      	ubfx	x4, x4, #0, #8
    3388:      	b	0x3590 <_stogir.copy.validate+0x26c>
    338c:      	cmp	x1, #0x0
    3390:      	b.ge	0x33fc <_stogir.copy.validate+0xd8>
    3394:      	add	x6, x0, #0x28
    3398:      	add	x7, x0, #0x50
    339c:      	ldr	x6, [x6, #0x8]
    33a0:      	ldr	x7, [x7, #0x8]
    33a4:      	cmp	x6, x7
    33a8:      	b.ne	0x33d4 <_stogir.copy.validate+0xb0>
    33ac:      	cmp	x4, x6
    33b0:      	b.gt	0x3594 <_stogir.copy.validate+0x270>
    33b4:      	ldr	x4, [x0, #0x50]
    33b8:      	add	x4, x4, x5, lsl #2
    33bc:      	ldr	w4, [x4]
    33c0:      	sxtw	x4, w4
    33c4:      	cmp	x4, #0x0
    33c8:      	cset	w4, gt
    33cc:      	ubfx	x4, x4, #0, #8
    33d0:      	b	0x3598 <_stogir.copy.validate+0x274>
    33d4:      	movz	x4, #0x0, lsl #48
    33d8:      	b	0x3400 <_stogir.copy.validate+0xdc>
    33dc:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		00000000000033dc:  ARM64_RELOC_PAGE21	l_stogir.352
    33e0:      	ldr	x16, [x16]
		00000000000033e0:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    33e4:      	orr	x0, x16, xzr
    33e8:      	mov	x1, #0x1                ; =1
    33ec:      	mov	x2, #0x21               ; =33
    33f0:      	b	0x3490 <_stogir.copy.validate+0x16c>
    33f4:      	movz	x4, #0x0, lsl #48
    33f8:      	b	0x3400 <_stogir.copy.validate+0xdc>
    33fc:      	movz	x4, #0x0, lsl #48
    3400:      	cmp	x4, #0x0
    3404:      	b.eq	0x3440 <_stogir.copy.validate+0x11c>
    3408:      	uxtb	w16, w3
    340c:      	cmp	w16, wzr
    3410:      	b.eq	0x3428 <_stogir.copy.validate+0x104>
    3414:      	ldr	x3, [x0]
    3418:      	add	x3, x3, x1, lsl #4
    341c:      	ldr	x4, [x3]
    3420:      	ldr	x3, [x3, #0x8]
    3424:      	b	0x3438 <_stogir.copy.validate+0x114>
    3428:      	ldr	x3, [x0, #0x28]
    342c:      	add	x3, x3, x5, lsl #4
    3430:      	ldr	x4, [x3]
    3434:      	ldr	x3, [x3, #0x8]
    3438:      	mov	x5, #0x1                ; =1
    343c:      	b	0x344c <_stogir.copy.validate+0x128>
    3440:      	movz	x5, #0x0, lsl #48
    3444:      	movz	x4, #0x0, lsl #48
    3448:      	movz	x3, #0x0, lsl #48
    344c:      	lsr	w5, w5, #0
    3450:      	lsr	x16, x5, #0
    3454:      	cmp	x16, #0x1
    3458:      	b.eq	0x3474 <_stogir.copy.validate+0x150>
    345c:      	b.lo	0x3464 <_stogir.copy.validate+0x140>
    3460:      	b	0x3478 <_stogir.copy.validate+0x154>
    3464:      	cmp	x16, #0x0
    3468:      	b.eq	0x3470 <_stogir.copy.validate+0x14c>
    346c:      	b	0x3478 <_stogir.copy.validate+0x154>
    3470:      	b	0x347c <_stogir.copy.validate+0x158>
    3474:      	b	0x34a4 <_stogir.copy.validate+0x180>
    3478:      	b	0x359c <_stogir.copy.validate+0x278>
    347c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		000000000000347c:  ARM64_RELOC_PAGE21	l_stogir.353
    3480:      	ldr	x16, [x16]
		0000000000003480:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    3484:      	orr	x0, x16, xzr
    3488:      	mov	x1, #0x1                ; =1
    348c:      	mov	x2, #0x18               ; =24
    3490:      	str	x1, [x8]
    3494:      	str	x0, [x8, #0x8]
    3498:      	str	x2, [x8, #0x10]
    349c:      	add	sp, sp, #0x10
    34a0:      	ret
    34a4:      	mov	x16, sp
    34a8:      	str	x4, [x16]
    34ac:      	mov	x16, sp
    34b0:      	str	x3, [x16, #0x8]
    34b4:      	cmp	x1, #0x0
    34b8:      	b.le	0x33dc <_stogir.copy.validate+0xb8>
    34bc:      	uxtb	w1, w4
    34c0:      	cmp	x1, #0x44
    34c4:      	b.ne	0x33dc <_stogir.copy.validate+0xb8>
    34c8:      	ldr	x1, [x0, #0x78]
    34cc:      	add	x1, x2, x1
    34d0:      	ldr	w1, [x1]
    34d4:      	sxtw	x1, w1
    34d8:      	cmp	x1, #0x2
    34dc:      	b.ne	0x33dc <_stogir.copy.validate+0xb8>
    34e0:      	lsr	w4, w4, #0
    34e4:      	ubfx	x1, x4, #8, #8
    34e8:      	cmp	x1, #0x0
    34ec:      	b.eq	0x33dc <_stogir.copy.validate+0xb8>
    34f0:      	cmp	x1, #0xd
    34f4:      	b.le	0x3524 <_stogir.copy.validate+0x200>
    34f8:      	cmp	x1, #0xf
    34fc:      	b.le	0x33dc <_stogir.copy.validate+0xb8>
    3500:      	cmp	x1, #0x80
    3504:      	b.ge	0x33dc <_stogir.copy.validate+0xb8>
    3508:      	and	x2, x1, #0xf
    350c:      	lsr	w2, w2, #0
    3510:      	sxtw	x2, w2
    3514:      	cmp	x2, #0x1
    3518:      	b.lt	0x33dc <_stogir.copy.validate+0xb8>
    351c:      	cmp	x2, #0xd
    3520:      	b.gt	0x33dc <_stogir.copy.validate+0xb8>
    3524:      	mov	x16, sp
    3528:      	ldr	w2, [x16, #0x4]
    352c:      	sxtw	x2, w2
    3530:      	cmp	x2, #0x0
    3534:      	cset	w3, gt
    3538:      	movz	x16, #0x0, lsl #48
    353c:      	sub	x4, x16, x2
    3540:      	sub	x5, x4, #0x1
    3544:      	uxtb	w16, w3
    3548:      	cmp	w16, wzr
    354c:      	b.eq	0x35bc <_stogir.copy.validate+0x298>
    3550:      	ldr	x4, [x0, #0x8]
    3554:      	cmp	x2, x4
    3558:      	b.ge	0x3604 <_stogir.copy.validate+0x2e0>
    355c:      	add	x4, x0, #0x78
    3560:      	ldr	x4, [x4, #0x8]
    3564:      	cmp	x2, x4
    3568:      	b.ge	0x36cc <_stogir.copy.validate+0x3a8>
    356c:      	ldr	x4, [x0, #0x78]
    3570:      	add	x4, x4, x2, lsl #2
    3574:      	ldr	w4, [x4]
    3578:      	sxtw	x4, w4
    357c:      	cmp	x4, #0x0
    3580:      	cset	w4, ge
    3584:      	ubfx	x4, x4, #0, #8
    3588:      	b	0x36d0 <_stogir.copy.validate+0x3ac>
    358c:      	movz	x4, #0x0, lsl #48
    3590:      	b	0x33f8 <_stogir.copy.validate+0xd4>
    3594:      	movz	x4, #0x0, lsl #48
    3598:      	b	0x33d8 <_stogir.copy.validate+0xb4>
    359c:      	brk	#0
    35a0:      	b	0x359c <_stogir.copy.validate+0x278>
    35a4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		00000000000035a4:  ARM64_RELOC_PAGE21	l_stogir.354
    35a8:      	ldr	x16, [x16]
		00000000000035a8:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    35ac:      	orr	x0, x16, xzr
    35b0:      	mov	x1, #0x1                ; =1
    35b4:      	mov	x2, #0x20               ; =32
    35b8:      	b	0x33f0 <_stogir.copy.validate+0xcc>
    35bc:      	cmp	x2, #0x0
    35c0:      	b.ge	0x360c <_stogir.copy.validate+0x2e8>
    35c4:      	add	x6, x0, #0x28
    35c8:      	add	x7, x0, #0x50
    35cc:      	ldr	x6, [x6, #0x8]
    35d0:      	ldr	x7, [x7, #0x8]
    35d4:      	cmp	x6, x7
    35d8:      	b.ne	0x36c4 <_stogir.copy.validate+0x3a0>
    35dc:      	cmp	x4, x6
    35e0:      	b.gt	0x36d4 <_stogir.copy.validate+0x3b0>
    35e4:      	ldr	x4, [x0, #0x50]
    35e8:      	add	x4, x4, x5, lsl #2
    35ec:      	ldr	w4, [x4]
    35f0:      	sxtw	x4, w4
    35f4:      	cmp	x4, #0x0
    35f8:      	cset	w4, gt
    35fc:      	ubfx	x4, x4, #0, #8
    3600:      	b	0x36d8 <_stogir.copy.validate+0x3b4>
    3604:      	movz	x4, #0x0, lsl #48
    3608:      	b	0x3610 <_stogir.copy.validate+0x2ec>
    360c:      	movz	x4, #0x0, lsl #48
    3610:      	cmp	x4, #0x0
    3614:      	b.eq	0x3648 <_stogir.copy.validate+0x324>
    3618:      	uxtb	w16, w3
    361c:      	cmp	w16, wzr
    3620:      	b.eq	0x3634 <_stogir.copy.validate+0x310>
    3624:      	ldr	x0, [x0]
    3628:      	add	x0, x0, x2, lsl #4
    362c:      	ldr	x0, [x0]
    3630:      	b	0x3640 <_stogir.copy.validate+0x31c>
    3634:      	ldr	x0, [x0, #0x28]
    3638:      	add	x0, x0, x5, lsl #4
    363c:      	ldr	x0, [x0]
    3640:      	mov	x2, #0x1                ; =1
    3644:      	b	0x3650 <_stogir.copy.validate+0x32c>
    3648:      	movz	x2, #0x0, lsl #48
    364c:      	movz	x0, #0x0, lsl #48
    3650:      	lsr	w2, w2, #0
    3654:      	lsr	x16, x2, #0
    3658:      	cmp	x16, #0x1
    365c:      	b.eq	0x3678 <_stogir.copy.validate+0x354>
    3660:      	b.lo	0x3668 <_stogir.copy.validate+0x344>
    3664:      	b	0x367c <_stogir.copy.validate+0x358>
    3668:      	cmp	x16, #0x0
    366c:      	b.eq	0x3674 <_stogir.copy.validate+0x350>
    3670:      	b	0x367c <_stogir.copy.validate+0x358>
    3674:      	b	0x3680 <_stogir.copy.validate+0x35c>
    3678:      	b	0x3698 <_stogir.copy.validate+0x374>
    367c:      	b	0x36dc <_stogir.copy.validate+0x3b8>
    3680:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003680:  ARM64_RELOC_PAGE21	l_stogir.355
    3684:      	ldr	x16, [x16]
		0000000000003684:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    3688:      	orr	x0, x16, xzr
    368c:      	mov	x1, #0x1                ; =1
    3690:      	mov	x2, #0x13               ; =19
    3694:      	b	0x35b8 <_stogir.copy.validate+0x294>
    3698:      	lsr	w0, w0, #0
    369c:      	mov	x16, sp
    36a0:      	ldr	w2, [x16]
    36a4:      	ubfx	x0, x0, #8, #8
    36a8:      	ubfx	x2, x2, #8, #8
    36ac:      	cmp	x0, x2
    36b0:      	b.ne	0x35a4 <_stogir.copy.validate+0x280>
    36b4:      	and	x0, x1, #0xffffffff
    36b8:      	movz	x1, #0x0, lsl #48
    36bc:      	movz	x2, #0x0, lsl #48
    36c0:      	b	0x35b8 <_stogir.copy.validate+0x294>
    36c4:      	movz	x4, #0x0, lsl #48
    36c8:      	b	0x3610 <_stogir.copy.validate+0x2ec>
    36cc:      	movz	x4, #0x0, lsl #48
    36d0:      	b	0x3608 <_stogir.copy.validate+0x2e4>
    36d4:      	movz	x4, #0x0, lsl #48
    36d8:      	b	0x36c8 <_stogir.copy.validate+0x3a4>
    36dc:      	brk	#0
    36e0:      	b	0x36dc <_stogir.copy.validate+0x3b8>

00000000000036e4 <_stogir.graph.lookup>:
    36e4:      	sxtw	x1, w1
    36e8:      	cmp	x1, #0x0
    36ec:      	cset	w2, gt
    36f0:      	movz	x16, #0x0, lsl #48
    36f4:      	sub	x3, x16, x1
    36f8:      	sub	x4, x3, #0x1
    36fc:      	uxtb	w16, w2
    3700:      	cmp	w16, wzr
    3704:      	b.eq	0x3744 <_stogir.graph.lookup+0x60>
    3708:      	ldr	x3, [x0, #0x8]
    370c:      	cmp	x1, x3
    3710:      	b.ge	0x3794 <_stogir.graph.lookup+0xb0>
    3714:      	add	x3, x0, #0x78
    3718:      	ldr	x3, [x3, #0x8]
    371c:      	cmp	x1, x3
    3720:      	b.ge	0x380c <_stogir.graph.lookup+0x128>
    3724:      	ldr	x3, [x0, #0x78]
    3728:      	add	x3, x3, x1, lsl #2
    372c:      	ldr	w3, [x3]
    3730:      	sxtw	x3, w3
    3734:      	cmp	x3, #0x0
    3738:      	cset	w3, ge
    373c:      	ubfx	x3, x3, #0, #8
    3740:      	b	0x3810 <_stogir.graph.lookup+0x12c>
    3744:      	cmp	x1, #0x0
    3748:      	b.ge	0x379c <_stogir.graph.lookup+0xb8>
    374c:      	add	x5, x0, #0x28
    3750:      	add	x6, x0, #0x50
    3754:      	ldr	x5, [x5, #0x8]
    3758:      	ldr	x6, [x6, #0x8]
    375c:      	cmp	x5, x6
    3760:      	b.ne	0x378c <_stogir.graph.lookup+0xa8>
    3764:      	cmp	x3, x5
    3768:      	b.gt	0x3814 <_stogir.graph.lookup+0x130>
    376c:      	ldr	x3, [x0, #0x50]
    3770:      	add	x3, x3, x4, lsl #2
    3774:      	ldr	w3, [x3]
    3778:      	sxtw	x3, w3
    377c:      	cmp	x3, #0x0
    3780:      	cset	w3, gt
    3784:      	ubfx	x3, x3, #0, #8
    3788:      	b	0x3818 <_stogir.graph.lookup+0x134>
    378c:      	movz	x3, #0x0, lsl #48
    3790:      	b	0x37a0 <_stogir.graph.lookup+0xbc>
    3794:      	movz	x3, #0x0, lsl #48
    3798:      	b	0x37a0 <_stogir.graph.lookup+0xbc>
    379c:      	movz	x3, #0x0, lsl #48
    37a0:      	cmp	x3, #0x0
    37a4:      	b.eq	0x37e0 <_stogir.graph.lookup+0xfc>
    37a8:      	uxtb	w16, w2
    37ac:      	cmp	w16, wzr
    37b0:      	b.eq	0x37c8 <_stogir.graph.lookup+0xe4>
    37b4:      	ldr	x0, [x0]
    37b8:      	add	x0, x0, x1, lsl #4
    37bc:      	ldr	x1, [x0]
    37c0:      	ldr	x0, [x0, #0x8]
    37c4:      	b	0x37d8 <_stogir.graph.lookup+0xf4>
    37c8:      	ldr	x0, [x0, #0x28]
    37cc:      	add	x0, x0, x4, lsl #4
    37d0:      	ldr	x1, [x0]
    37d4:      	ldr	x0, [x0, #0x8]
    37d8:      	mov	x2, #0x1                ; =1
    37dc:      	b	0x37ec <_stogir.graph.lookup+0x108>
    37e0:      	movz	x2, #0x0, lsl #48
    37e4:      	movz	x1, #0x0, lsl #48
    37e8:      	movz	x0, #0x0, lsl #48
    37ec:      	str	x2, [x8]
    37f0:      	str	x1, [x8, #0x8]
    37f4:      	str	x0, [x8, #0x10]
    37f8:      	movz	x17, #0x0, lsl #48
    37fc:      	str	x17, [x8, #0x18]
    3800:      	movz	x17, #0x0, lsl #48
    3804:      	str	x17, [x8, #0x20]
    3808:      	ret
    380c:      	movz	x3, #0x0, lsl #48
    3810:      	b	0x3798 <_stogir.graph.lookup+0xb4>
    3814:      	movz	x3, #0x0, lsl #48
    3818:      	b	0x3790 <_stogir.graph.lookup+0xac>

000000000000381c <_stogir.checked.validate-projection>:
    381c:      	sub	sp, sp, #0x40
    3820:      	str	x29, [sp]
    3824:      	str	x30, [sp, #0x8]
    3828:      	mov	x29, sp
    382c:      	str	x19, [sp, #0x30]
    3830:      	sxtw	x1, w1
    3834:      	lsl	x2, x1, #2
    3838:      	cmp	x1, #0x0
    383c:      	cset	w3, gt
    3840:      	movz	x16, #0x0, lsl #48
    3844:      	sub	x4, x16, x1
    3848:      	sub	x5, x4, #0x1
    384c:      	uxtb	w16, w3
    3850:      	cmp	w16, wzr
    3854:      	b.eq	0x3894 <_stogir.checked.validate-projection+0x78>
    3858:      	ldr	x4, [x0, #0x8]
    385c:      	cmp	x1, x4
    3860:      	b.ge	0x38e4 <_stogir.checked.validate-projection+0xc8>
    3864:      	add	x4, x0, #0x78
    3868:      	ldr	x4, [x4, #0x8]
    386c:      	cmp	x1, x4
    3870:      	b.ge	0x39bc <_stogir.checked.validate-projection+0x1a0>
    3874:      	ldr	x4, [x0, #0x78]
    3878:      	add	x4, x2, x4
    387c:      	ldr	w4, [x4]
    3880:      	sxtw	x4, w4
    3884:      	cmp	x4, #0x0
    3888:      	cset	w4, ge
    388c:      	ubfx	x4, x4, #0, #8
    3890:      	b	0x39c0 <_stogir.checked.validate-projection+0x1a4>
    3894:      	cmp	x1, #0x0
    3898:      	b.ge	0x38ec <_stogir.checked.validate-projection+0xd0>
    389c:      	add	x6, x0, #0x28
    38a0:      	add	x7, x0, #0x50
    38a4:      	ldr	x6, [x6, #0x8]
    38a8:      	ldr	x7, [x7, #0x8]
    38ac:      	cmp	x6, x7
    38b0:      	b.ne	0x38dc <_stogir.checked.validate-projection+0xc0>
    38b4:      	cmp	x4, x6
    38b8:      	b.gt	0x3a28 <_stogir.checked.validate-projection+0x20c>
    38bc:      	ldr	x4, [x0, #0x50]
    38c0:      	add	x4, x4, x5, lsl #2
    38c4:      	ldr	w4, [x4]
    38c8:      	sxtw	x4, w4
    38cc:      	cmp	x4, #0x0
    38d0:      	cset	w4, gt
    38d4:      	ubfx	x4, x4, #0, #8
    38d8:      	b	0x3a2c <_stogir.checked.validate-projection+0x210>
    38dc:      	movz	x4, #0x0, lsl #48
    38e0:      	b	0x38f0 <_stogir.checked.validate-projection+0xd4>
    38e4:      	movz	x4, #0x0, lsl #48
    38e8:      	b	0x38f0 <_stogir.checked.validate-projection+0xd4>
    38ec:      	movz	x4, #0x0, lsl #48
    38f0:      	cmp	x4, #0x0
    38f4:      	b.eq	0x3928 <_stogir.checked.validate-projection+0x10c>
    38f8:      	uxtb	w16, w3
    38fc:      	cmp	w16, wzr
    3900:      	b.eq	0x3914 <_stogir.checked.validate-projection+0xf8>
    3904:      	ldr	x3, [x0]
    3908:      	add	x3, x3, x1, lsl #4
    390c:      	ldr	x3, [x3]
    3910:      	b	0x3920 <_stogir.checked.validate-projection+0x104>
    3914:      	ldr	x3, [x0, #0x28]
    3918:      	add	x3, x3, x5, lsl #4
    391c:      	ldr	x3, [x3]
    3920:      	mov	x4, #0x1                ; =1
    3924:      	b	0x3930 <_stogir.checked.validate-projection+0x114>
    3928:      	movz	x4, #0x0, lsl #48
    392c:      	movz	x3, #0x0, lsl #48
    3930:      	lsr	w4, w4, #0
    3934:      	lsr	x16, x4, #0
    3938:      	cmp	x16, #0x1
    393c:      	b.eq	0x3958 <_stogir.checked.validate-projection+0x13c>
    3940:      	b.lo	0x3948 <_stogir.checked.validate-projection+0x12c>
    3944:      	b	0x395c <_stogir.checked.validate-projection+0x140>
    3948:      	cmp	x16, #0x0
    394c:      	b.eq	0x3954 <_stogir.checked.validate-projection+0x138>
    3950:      	b	0x395c <_stogir.checked.validate-projection+0x140>
    3954:      	b	0x3960 <_stogir.checked.validate-projection+0x144>
    3958:      	b	0x397c <_stogir.checked.validate-projection+0x160>
    395c:      	b	0x3a30 <_stogir.checked.validate-projection+0x214>
    3960:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003960:  ARM64_RELOC_PAGE21	l_stogir.356
    3964:      	ldr	x16, [x16]
		0000000000003964:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    3968:      	orr	x0, x16, xzr
    396c:      	mov	x19, x8
    3970:      	mov	x1, #0x1                ; =1
    3974:      	mov	x2, #0x10               ; =16
    3978:      	b	0x399c <_stogir.checked.validate-projection+0x180>
    397c:      	cmp	x1, #0x0
    3980:      	b.gt	0x39c4 <_stogir.checked.validate-projection+0x1a8>
    3984:      	mov	x19, x8
    3988:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003988:  ARM64_RELOC_PAGE21	l_stogir.357
    398c:      	ldr	x16, [x16]
		000000000000398c:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    3990:      	orr	x0, x16, xzr
    3994:      	mov	x1, #0x1                ; =1
    3998:      	mov	x2, #0x1c               ; =28
    399c:      	str	x1, [x19]
    39a0:      	str	x0, [x19, #0x8]
    39a4:      	str	x2, [x19, #0x10]
    39a8:      	ldr	x19, [sp, #0x30]
    39ac:      	ldr	x29, [sp]
    39b0:      	ldr	x30, [sp, #0x8]
    39b4:      	add	sp, sp, #0x40
    39b8:      	ret
    39bc:      	movz	x4, #0x0, lsl #48
    39c0:      	b	0x38e8 <_stogir.checked.validate-projection+0xcc>
    39c4:      	uxtb	w1, w3
    39c8:      	cmp	x1, #0x2c
    39cc:      	b.ne	0x3a38 <_stogir.checked.validate-projection+0x21c>
    39d0:      	lsr	w1, w3, #0
    39d4:      	ubfx	x1, x1, #8, #8
    39d8:      	cmp	x1, #0x1
    39dc:      	b.ne	0x3a40 <_stogir.checked.validate-projection+0x224>
    39e0:      	ldr	x1, [x0, #0x78]
    39e4:      	add	x1, x2, x1
    39e8:      	ldr	w1, [x1]
    39ec:      	sxtw	x1, w1
    39f0:      	cmp	x1, #0x1
    39f4:      	b.ne	0x3a48 <_stogir.checked.validate-projection+0x22c>
    39f8:      	lsr	x1, x3, #32
    39fc:      	lsr	w1, w1, #0
    3a00:      	mov	x19, x8
    3a04:      	add	x8, sp, #0x10
    3a08:      	bl	0x3a08 <_stogir.checked.validate-projection+0x1ec>
		0000000000003a08:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    3a0c:      	add	x16, sp, #0x10
    3a10:      	ldr	x1, [x16]
    3a14:      	add	x16, sp, #0x10
    3a18:      	ldr	x0, [x16, #0x8]
    3a1c:      	add	x16, sp, #0x10
    3a20:      	ldr	x2, [x16, #0x10]
    3a24:      	b	0x399c <_stogir.checked.validate-projection+0x180>
    3a28:      	movz	x4, #0x0, lsl #48
    3a2c:      	b	0x38e0 <_stogir.checked.validate-projection+0xc4>
    3a30:      	brk	#0
    3a34:      	b	0x3a30 <_stogir.checked.validate-projection+0x214>
    3a38:      	mov	x19, x8
    3a3c:      	b	0x3988 <_stogir.checked.validate-projection+0x16c>
    3a40:      	mov	x19, x8
    3a44:      	b	0x3988 <_stogir.checked.validate-projection+0x16c>
    3a48:      	mov	x19, x8
    3a4c:      	b	0x3988 <_stogir.checked.validate-projection+0x16c>

0000000000003a50 <_stogir.checked.validate>:
    3a50:      	sub	sp, sp, #0x30
    3a54:      	str	x29, [sp]
    3a58:      	str	x30, [sp, #0x8]
    3a5c:      	mov	x29, sp
    3a60:      	str	x19, [sp, #0x10]
    3a64:      	str	x20, [sp, #0x18]
    3a68:      	str	x21, [sp, #0x20]
    3a6c:      	sxtw	x1, w1
    3a70:      	lsl	x2, x1, #2
    3a74:      	cmp	x1, #0x0
    3a78:      	cset	w3, gt
    3a7c:      	movz	x16, #0x0, lsl #48
    3a80:      	sub	x4, x16, x1
    3a84:      	sub	x5, x4, #0x1
    3a88:      	uxtb	w16, w3
    3a8c:      	cmp	w16, wzr
    3a90:      	b.eq	0x3ad0 <_stogir.checked.validate+0x80>
    3a94:      	ldr	x4, [x0, #0x8]
    3a98:      	cmp	x1, x4
    3a9c:      	b.ge	0x3b20 <_stogir.checked.validate+0xd0>
    3aa0:      	add	x4, x0, #0x78
    3aa4:      	ldr	x4, [x4, #0x8]
    3aa8:      	cmp	x1, x4
    3aac:      	b.ge	0x3c80 <_stogir.checked.validate+0x230>
    3ab0:      	ldr	x4, [x0, #0x78]
    3ab4:      	add	x4, x2, x4
    3ab8:      	ldr	w4, [x4]
    3abc:      	sxtw	x4, w4
    3ac0:      	cmp	x4, #0x0
    3ac4:      	cset	w4, ge
    3ac8:      	ubfx	x4, x4, #0, #8
    3acc:      	b	0x3c84 <_stogir.checked.validate+0x234>
    3ad0:      	cmp	x1, #0x0
    3ad4:      	b.ge	0x3b28 <_stogir.checked.validate+0xd8>
    3ad8:      	add	x6, x0, #0x28
    3adc:      	add	x7, x0, #0x50
    3ae0:      	ldr	x6, [x6, #0x8]
    3ae4:      	ldr	x7, [x7, #0x8]
    3ae8:      	cmp	x6, x7
    3aec:      	b.ne	0x3b18 <_stogir.checked.validate+0xc8>
    3af0:      	cmp	x4, x6
    3af4:      	b.gt	0x3c88 <_stogir.checked.validate+0x238>
    3af8:      	ldr	x4, [x0, #0x50]
    3afc:      	add	x4, x4, x5, lsl #2
    3b00:      	ldr	w4, [x4]
    3b04:      	sxtw	x4, w4
    3b08:      	cmp	x4, #0x0
    3b0c:      	cset	w4, gt
    3b10:      	ubfx	x4, x4, #0, #8
    3b14:      	b	0x3c8c <_stogir.checked.validate+0x23c>
    3b18:      	movz	x4, #0x0, lsl #48
    3b1c:      	b	0x3b2c <_stogir.checked.validate+0xdc>
    3b20:      	movz	x4, #0x0, lsl #48
    3b24:      	b	0x3b2c <_stogir.checked.validate+0xdc>
    3b28:      	movz	x4, #0x0, lsl #48
    3b2c:      	cmp	x4, #0x0
    3b30:      	b.eq	0x3b6c <_stogir.checked.validate+0x11c>
    3b34:      	uxtb	w16, w3
    3b38:      	cmp	w16, wzr
    3b3c:      	b.eq	0x3b54 <_stogir.checked.validate+0x104>
    3b40:      	ldr	x3, [x0]
    3b44:      	add	x3, x3, x1, lsl #4
    3b48:      	ldr	x4, [x3]
    3b4c:      	ldr	x3, [x3, #0x8]
    3b50:      	b	0x3b64 <_stogir.checked.validate+0x114>
    3b54:      	ldr	x3, [x0, #0x28]
    3b58:      	add	x3, x3, x5, lsl #4
    3b5c:      	ldr	x4, [x3]
    3b60:      	ldr	x3, [x3, #0x8]
    3b64:      	mov	x5, #0x1                ; =1
    3b68:      	b	0x3b78 <_stogir.checked.validate+0x128>
    3b6c:      	movz	x5, #0x0, lsl #48
    3b70:      	movz	x4, #0x0, lsl #48
    3b74:      	movz	x3, #0x0, lsl #48
    3b78:      	lsr	w5, w5, #0
    3b7c:      	lsr	x16, x5, #0
    3b80:      	cmp	x16, #0x1
    3b84:      	b.eq	0x3ba0 <_stogir.checked.validate+0x150>
    3b88:      	b.lo	0x3b90 <_stogir.checked.validate+0x140>
    3b8c:      	b	0x3ba4 <_stogir.checked.validate+0x154>
    3b90:      	cmp	x16, #0x0
    3b94:      	b.eq	0x3b9c <_stogir.checked.validate+0x14c>
    3b98:      	b	0x3ba4 <_stogir.checked.validate+0x154>
    3b9c:      	b	0x3ba8 <_stogir.checked.validate+0x158>
    3ba0:      	b	0x3c00 <_stogir.checked.validate+0x1b0>
    3ba4:      	b	0x3ec4 <_stogir.checked.validate+0x474>
    3ba8:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003ba8:  ARM64_RELOC_PAGE21	l_stogir.358
    3bac:      	ldr	x16, [x16]
		0000000000003bac:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    3bb0:      	orr	x1, x16, xzr
    3bb4:      	mov	x0, #0x1                ; =1
    3bb8:      	mov	x9, #0x1a               ; =26
    3bbc:      	b	0x3bd4 <_stogir.checked.validate+0x184>
    3bc0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003bc0:  ARM64_RELOC_PAGE21	l_stogir.359
    3bc4:      	ldr	x16, [x16]
		0000000000003bc4:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    3bc8:      	orr	x1, x16, xzr
    3bcc:      	mov	x0, #0x1                ; =1
    3bd0:      	mov	x9, #0x26               ; =38
    3bd4:      	str	x0, [x8]
    3bd8:      	str	x1, [x8, #0x8]
    3bdc:      	str	x9, [x8, #0x10]
    3be0:      	sub	sp, x29, #0x0
    3be4:      	ldr	x19, [sp, #0x10]
    3be8:      	ldr	x20, [sp, #0x18]
    3bec:      	ldr	x21, [sp, #0x20]
    3bf0:      	ldr	x29, [sp]
    3bf4:      	ldr	x30, [sp, #0x8]
    3bf8:      	add	sp, sp, #0x30
    3bfc:      	ret
    3c00:      	cmp	x1, #0x0
    3c04:      	b.le	0x3bc0 <_stogir.checked.validate+0x170>
    3c08:      	uxtb	w1, w4
    3c0c:      	cmp	x1, #0x29
    3c10:      	b.lt	0x3bc0 <_stogir.checked.validate+0x170>
    3c14:      	cmp	x1, #0x2b
    3c18:      	b.gt	0x3bc0 <_stogir.checked.validate+0x170>
    3c1c:      	ldr	x1, [x0, #0x78]
    3c20:      	add	x1, x2, x1
    3c24:      	ldr	w1, [x1]
    3c28:      	sxtw	x1, w1
    3c2c:      	cmp	x1, #0x2
    3c30:      	b.ne	0x3bc0 <_stogir.checked.validate+0x170>
    3c34:      	lsr	w1, w4, #0
    3c38:      	mov	x2, sp
    3c3c:      	sub	sp, sp, #0x10
    3c40:      	mov	x5, sp
    3c44:      	sub	sp, sp, #0x10
    3c48:      	mov	x6, sp
    3c4c:      	ubfx	x1, x1, #8, #8
    3c50:      	orr	x7, x1, xzr
    3c54:      	cmp	x7, #0x1
    3c58:      	b.lt	0x3e54 <_stogir.checked.validate+0x404>
    3c5c:      	cmp	x7, #0xb
    3c60:      	b.gt	0x3e54 <_stogir.checked.validate+0x404>
    3c64:      	cmp	x7, #0x1
    3c68:      	b.eq	0x3e54 <_stogir.checked.validate+0x404>
    3c6c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003c6c:  ARM64_RELOC_PAGE21	l_stogir.360
    3c70:      	ldr	x16, [x16]
		0000000000003c70:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    3c74:      	orr	x1, x16, xzr
    3c78:      	movz	x9, #0x0, lsl #48
    3c7c:      	b	0x3e64 <_stogir.checked.validate+0x414>
    3c80:      	movz	x4, #0x0, lsl #48
    3c84:      	b	0x3b24 <_stogir.checked.validate+0xd4>
    3c88:      	movz	x4, #0x0, lsl #48
    3c8c:      	b	0x3b1c <_stogir.checked.validate+0xcc>
    3c90:      	mov	x0, #0x1                ; =1
    3c94:      	mov	sp, x2
    3c98:      	b	0x3bd4 <_stogir.checked.validate+0x184>
    3c9c:      	movz	x5, #0x0, lsl #48
    3ca0:      	movz	x4, #0x0, lsl #48
    3ca4:      	lsr	w5, w5, #0
    3ca8:      	lsr	x16, x5, #0
    3cac:      	cmp	x16, #0x1
    3cb0:      	b.eq	0x3ccc <_stogir.checked.validate+0x27c>
    3cb4:      	b.lo	0x3cbc <_stogir.checked.validate+0x26c>
    3cb8:      	b	0x3cd0 <_stogir.checked.validate+0x280>
    3cbc:      	cmp	x16, #0x0
    3cc0:      	b.eq	0x3cc8 <_stogir.checked.validate+0x278>
    3cc4:      	b	0x3cd0 <_stogir.checked.validate+0x280>
    3cc8:      	b	0x3cd4 <_stogir.checked.validate+0x284>
    3ccc:      	b	0x3e38 <_stogir.checked.validate+0x3e8>
    3cd0:      	b	0x3edc <_stogir.checked.validate+0x48c>
    3cd4:      	mov	x1, x11
    3cd8:      	mov	x9, #0x22               ; =34
    3cdc:      	cmp	x3, #0x2
    3ce0:      	b.ge	0x3d04 <_stogir.checked.validate+0x2b4>
    3ce4:      	add	x4, x3, #0x1
    3ce8:      	add	x3, x10, x3, lsl #2
    3cec:      	ldr	w3, [x3]
    3cf0:      	sxtw	x3, w3
    3cf4:      	and	x5, x3, #0xffffffff
    3cf8:      	mov	x3, x4
    3cfc:      	mov	x4, #0x1                ; =1
    3d00:      	b	0x3d0c <_stogir.checked.validate+0x2bc>
    3d04:      	movz	x4, #0x0, lsl #48
    3d08:      	movz	x5, #0x0, lsl #48
    3d0c:      	lsr	w4, w4, #0
    3d10:      	lsr	x16, x4, #0
    3d14:      	cmp	x16, #0x1
    3d18:      	b.eq	0x3d34 <_stogir.checked.validate+0x2e4>
    3d1c:      	b.lo	0x3d24 <_stogir.checked.validate+0x2d4>
    3d20:      	b	0x3d38 <_stogir.checked.validate+0x2e8>
    3d24:      	cmp	x16, #0x0
    3d28:      	b.eq	0x3d30 <_stogir.checked.validate+0x2e0>
    3d2c:      	b	0x3d38 <_stogir.checked.validate+0x2e8>
    3d30:      	b	0x3d9c <_stogir.checked.validate+0x34c>
    3d34:      	b	0x3d3c <_stogir.checked.validate+0x2ec>
    3d38:      	b	0x3ed4 <_stogir.checked.validate+0x484>
    3d3c:      	lsr	w5, w5, #0
    3d40:      	sxtw	x5, w5
    3d44:      	cmp	x5, #0x0
    3d48:      	cset	w4, gt
    3d4c:      	movz	x16, #0x0, lsl #48
    3d50:      	sub	x6, x16, x5
    3d54:      	sub	x19, x6, #0x1
    3d58:      	uxtb	w16, w4
    3d5c:      	cmp	w16, wzr
    3d60:      	b.eq	0x3df8 <_stogir.checked.validate+0x3a8>
    3d64:      	ldr	x6, [x0, #0x8]
    3d68:      	cmp	x5, x6
    3d6c:      	b.ge	0x3df0 <_stogir.checked.validate+0x3a0>
    3d70:      	ldr	x6, [x13, #0x8]
    3d74:      	cmp	x5, x6
    3d78:      	b.ge	0x3ebc <_stogir.checked.validate+0x46c>
    3d7c:      	ldr	x6, [x0, #0x78]
    3d80:      	add	x6, x6, x5, lsl #2
    3d84:      	ldr	w6, [x6]
    3d88:      	sxtw	x6, w6
    3d8c:      	cmp	x6, #0x0
    3d90:      	cset	w6, ge
    3d94:      	ubfx	x6, x6, #0, #8
    3d98:      	b	0x3ec0 <_stogir.checked.validate+0x470>
    3d9c:      	cmp	x9, #0x0
    3da0:      	b.ne	0x3c90 <_stogir.checked.validate+0x240>
    3da4:      	and	x1, x7, #0xffffffff
    3da8:      	movz	x0, #0x0, lsl #48
    3dac:      	movz	x9, #0x0, lsl #48
    3db0:      	b	0x3c94 <_stogir.checked.validate+0x244>
    3db4:      	ldr	x4, [x0, #0x28]
    3db8:      	add	x4, x4, x19, lsl #4
    3dbc:      	ldr	x4, [x4]
    3dc0:      	mov	x5, #0x1                ; =1
    3dc4:      	b	0x3ca4 <_stogir.checked.validate+0x254>
    3dc8:      	movz	x6, #0x0, lsl #48
    3dcc:      	cmp	x6, #0x0
    3dd0:      	b.eq	0x3c9c <_stogir.checked.validate+0x24c>
    3dd4:      	uxtb	w16, w4
    3dd8:      	cmp	w16, wzr
    3ddc:      	b.eq	0x3db4 <_stogir.checked.validate+0x364>
    3de0:      	ldr	x4, [x0]
    3de4:      	add	x4, x4, x5, lsl #4
    3de8:      	ldr	x4, [x4]
    3dec:      	b	0x3dc0 <_stogir.checked.validate+0x370>
    3df0:      	movz	x6, #0x0, lsl #48
    3df4:      	b	0x3dcc <_stogir.checked.validate+0x37c>
    3df8:      	cmp	x5, #0x0
    3dfc:      	b.ge	0x3dc8 <_stogir.checked.validate+0x378>
    3e00:      	ldr	x20, [x14, #0x8]
    3e04:      	ldr	x21, [x15, #0x8]
    3e08:      	cmp	x20, x21
    3e0c:      	b.ne	0x3eb4 <_stogir.checked.validate+0x464>
    3e10:      	cmp	x6, x20
    3e14:      	b.gt	0x3ecc <_stogir.checked.validate+0x47c>
    3e18:      	ldr	x6, [x0, #0x50]
    3e1c:      	add	x6, x6, x19, lsl #2
    3e20:      	ldr	w6, [x6]
    3e24:      	sxtw	x6, w6
    3e28:      	cmp	x6, #0x0
    3e2c:      	cset	w6, gt
    3e30:      	ubfx	x6, x6, #0, #8
    3e34:      	b	0x3ed0 <_stogir.checked.validate+0x480>
    3e38:      	lsr	w4, w4, #0
    3e3c:      	ubfx	x4, x4, #8, #8
    3e40:      	cmp	x4, x7
    3e44:      	b.eq	0x3e50 <_stogir.checked.validate+0x400>
    3e48:      	mov	x1, x12
    3e4c:      	mov	x9, #0x28               ; =40
    3e50:      	b	0x3cdc <_stogir.checked.validate+0x28c>
    3e54:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003e54:  ARM64_RELOC_PAGE21	l_stogir.361
    3e58:      	ldr	x16, [x16]
		0000000000003e58:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    3e5c:      	orr	x1, x16, xzr
    3e60:      	mov	x9, #0x36               ; =54
    3e64:      	orr	x10, x6, xzr
    3e68:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003e68:  ARM64_RELOC_PAGE21	l_stogir.362
    3e6c:      	ldr	x16, [x16]
		0000000000003e6c:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    3e70:      	orr	x11, x16, xzr
    3e74:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x770>
		0000000000003e74:  ARM64_RELOC_PAGE21	l_stogir.363
    3e78:      	ldr	x16, [x16]
		0000000000003e78:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    3e7c:      	orr	x12, x16, xzr
    3e80:      	add	x13, x0, #0x78
    3e84:      	add	x14, x0, #0x28
    3e88:      	add	x15, x0, #0x50
    3e8c:      	lsr	w3, w3, #0
    3e90:      	lsr	x4, x4, #32
    3e94:      	lsr	w3, w3, #0
    3e98:      	lsr	w4, w4, #0
    3e9c:      	str	w4, [x5]
    3ea0:      	str	w3, [x5, #0x4]
    3ea4:      	ldr	x3, [x5]
    3ea8:      	str	x3, [x6]
    3eac:      	movz	x3, #0x0, lsl #48
    3eb0:      	b	0x3cdc <_stogir.checked.validate+0x28c>
    3eb4:      	movz	x6, #0x0, lsl #48
    3eb8:      	b	0x3dcc <_stogir.checked.validate+0x37c>
    3ebc:      	movz	x6, #0x0, lsl #48
    3ec0:      	b	0x3df4 <_stogir.checked.validate+0x3a4>
    3ec4:      	brk	#0
    3ec8:      	b	0x3ec4 <_stogir.checked.validate+0x474>
    3ecc:      	movz	x6, #0x0, lsl #48
    3ed0:      	b	0x3eb8 <_stogir.checked.validate+0x468>
    3ed4:      	brk	#0
    3ed8:      	b	0x3ed4 <_stogir.checked.validate+0x484>
    3edc:      	brk	#0
    3ee0:      	b	0x3edc <_stogir.checked.validate+0x48c>

0000000000003ee4 <_stogir.atomic.validate>:
    3ee4:      	sub	sp, sp, #0xf0
    3ee8:      	str	x29, [sp, #0x10]
    3eec:      	str	x30, [sp, #0x18]
    3ef0:      	add	x29, sp, #0x10
    3ef4:      	str	x19, [sp, #0xa0]
    3ef8:      	str	x20, [sp, #0xa8]
    3efc:      	str	x21, [sp, #0xb0]
    3f00:      	str	x22, [sp, #0xb8]
    3f04:      	str	x23, [sp, #0xc0]
    3f08:      	str	x24, [sp, #0xc8]
    3f0c:      	str	x25, [sp, #0xd0]
    3f10:      	str	x26, [sp, #0xd8]
    3f14:      	str	x27, [sp, #0xe0]
    3f18:      	sxtw	x2, w1
    3f1c:      	lsl	x3, x2, #2
    3f20:      	cmp	x2, #0x0
    3f24:      	cset	w4, gt
    3f28:      	movz	x16, #0x0, lsl #48
    3f2c:      	sub	x5, x16, x2
    3f30:      	sub	x6, x5, #0x1
    3f34:      	uxtb	w16, w4
    3f38:      	cmp	w16, wzr
    3f3c:      	b.eq	0x3f7c <_stogir.atomic.validate+0x98>
    3f40:      	ldr	x5, [x0, #0x8]
    3f44:      	cmp	x2, x5
    3f48:      	b.ge	0x3fcc <_stogir.atomic.validate+0xe8>
    3f4c:      	add	x5, x0, #0x78
    3f50:      	ldr	x5, [x5, #0x8]
    3f54:      	cmp	x2, x5
    3f58:      	b.ge	0x410c <_stogir.atomic.validate+0x228>
    3f5c:      	ldr	x5, [x0, #0x78]
    3f60:      	add	x5, x3, x5
    3f64:      	ldr	w5, [x5]
    3f68:      	sxtw	x5, w5
    3f6c:      	cmp	x5, #0x0
    3f70:      	cset	w5, ge
    3f74:      	ubfx	x5, x5, #0, #8
    3f78:      	b	0x4110 <_stogir.atomic.validate+0x22c>
    3f7c:      	cmp	x2, #0x0
    3f80:      	b.ge	0x3fd4 <_stogir.atomic.validate+0xf0>
    3f84:      	add	x7, x0, #0x28
    3f88:      	add	x9, x0, #0x50
    3f8c:      	ldr	x7, [x7, #0x8]
    3f90:      	ldr	x9, [x9, #0x8]
    3f94:      	cmp	x7, x9
    3f98:      	b.ne	0x3fc4 <_stogir.atomic.validate+0xe0>
    3f9c:      	cmp	x5, x7
    3fa0:      	b.gt	0x4198 <_stogir.atomic.validate+0x2b4>
    3fa4:      	ldr	x5, [x0, #0x50]
    3fa8:      	add	x5, x5, x6, lsl #2
    3fac:      	ldr	w5, [x5]
    3fb0:      	sxtw	x5, w5
    3fb4:      	cmp	x5, #0x0
    3fb8:      	cset	w5, gt
    3fbc:      	ubfx	x5, x5, #0, #8
    3fc0:      	b	0x419c <_stogir.atomic.validate+0x2b8>
    3fc4:      	movz	x5, #0x0, lsl #48
    3fc8:      	b	0x3fd8 <_stogir.atomic.validate+0xf4>
    3fcc:      	movz	x5, #0x0, lsl #48
    3fd0:      	b	0x3fd8 <_stogir.atomic.validate+0xf4>
    3fd4:      	movz	x5, #0x0, lsl #48
    3fd8:      	cmp	x5, #0x0
    3fdc:      	b.eq	0x4018 <_stogir.atomic.validate+0x134>
    3fe0:      	uxtb	w16, w4
    3fe4:      	cmp	w16, wzr
    3fe8:      	b.eq	0x4000 <_stogir.atomic.validate+0x11c>
    3fec:      	ldr	x4, [x0]
    3ff0:      	add	x4, x4, x2, lsl #4
    3ff4:      	ldr	x19, [x4]
    3ff8:      	ldr	x4, [x4, #0x8]
    3ffc:      	b	0x4010 <_stogir.atomic.validate+0x12c>
    4000:      	ldr	x4, [x0, #0x28]
    4004:      	add	x4, x4, x6, lsl #4
    4008:      	ldr	x19, [x4]
    400c:      	ldr	x4, [x4, #0x8]
    4010:      	mov	x5, #0x1                ; =1
    4014:      	b	0x4024 <_stogir.atomic.validate+0x140>
    4018:      	movz	x5, #0x0, lsl #48
    401c:      	movz	x19, #0x0, lsl #48
    4020:      	movz	x4, #0x0, lsl #48
    4024:      	lsr	w5, w5, #0
    4028:      	lsr	x16, x5, #0
    402c:      	cmp	x16, #0x1
    4030:      	b.eq	0x404c <_stogir.atomic.validate+0x168>
    4034:      	b.lo	0x403c <_stogir.atomic.validate+0x158>
    4038:      	b	0x4050 <_stogir.atomic.validate+0x16c>
    403c:      	cmp	x16, #0x0
    4040:      	b.eq	0x4048 <_stogir.atomic.validate+0x164>
    4044:      	b	0x4050 <_stogir.atomic.validate+0x16c>
    4048:      	b	0x4054 <_stogir.atomic.validate+0x170>
    404c:      	b	0x40ac <_stogir.atomic.validate+0x1c8>
    4050:      	b	0x4678 <_stogir.atomic.validate+0x794>
    4054:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004054:  ARM64_RELOC_PAGE21	l_stogir.364
    4058:      	ldr	x16, [x16]
		0000000000004058:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    405c:      	orr	x20, x16, xzr
    4060:      	mov	x23, x8
    4064:      	mov	x0, #0x1                ; =1
    4068:      	mov	x22, #0x1a              ; =26
    406c:      	str	x0, [x23]
    4070:      	str	x20, [x23, #0x8]
    4074:      	str	x22, [x23, #0x10]
    4078:      	ldr	x19, [sp, #0xa0]
    407c:      	ldr	x20, [sp, #0xa8]
    4080:      	ldr	x21, [sp, #0xb0]
    4084:      	ldr	x22, [sp, #0xb8]
    4088:      	ldr	x23, [sp, #0xc0]
    408c:      	ldr	x24, [sp, #0xc8]
    4090:      	ldr	x25, [sp, #0xd0]
    4094:      	ldr	x26, [sp, #0xd8]
    4098:      	ldr	x27, [sp, #0xe0]
    409c:      	ldr	x29, [sp, #0x10]
    40a0:      	ldr	x30, [sp, #0x18]
    40a4:      	add	sp, sp, #0xf0
    40a8:      	ret
    40ac:      	uxtb	w5, w19
    40b0:      	add	x16, sp, #0x20
    40b4:      	str	x19, [x16]
    40b8:      	orr	x21, x5, xzr
    40bc:      	add	x16, sp, #0x20
    40c0:      	str	x4, [x16, #0x8]
    40c4:      	cmp	x2, #0x0
    40c8:      	b.le	0x411c <_stogir.atomic.validate+0x238>
    40cc:      	cmp	x21, #0x7e
    40d0:      	b.lt	0x411c <_stogir.atomic.validate+0x238>
    40d4:      	cmp	x21, #0x82
    40d8:      	b.gt	0x411c <_stogir.atomic.validate+0x238>
    40dc:      	ldr	x2, [x0, #0x78]
    40e0:      	add	x2, x3, x2
    40e4:      	ldr	w2, [x2]
    40e8:      	cmp	x21, #0x83
    40ec:      	b.ge	0x45a4 <_stogir.atomic.validate+0x6c0>
    40f0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		00000000000040f0:  ARM64_RELOC_PAGE21	l_stogir.365
    40f4:      	ldr	x16, [x16]
		00000000000040f4:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    40f8:      	orr	x3, x16, xzr
    40fc:      	add	x3, x21, x3
    4100:      	ldrsb	w3, [x3]
    4104:      	sxtb	x3, w3
    4108:      	b	0x45a8 <_stogir.atomic.validate+0x6c4>
    410c:      	movz	x5, #0x0, lsl #48
    4110:      	b	0x3fd0 <_stogir.atomic.validate+0xec>
    4114:      	mov	x0, #0x1                ; =1
    4118:      	b	0x406c <_stogir.atomic.validate+0x188>
    411c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		000000000000411c:  ARM64_RELOC_PAGE21	l_stogir.366
    4120:      	ldr	x16, [x16]
		0000000000004120:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    4124:      	orr	x20, x16, xzr
    4128:      	mov	x22, #0x20              ; =32
    412c:      	add	x16, sp, #0x20
    4130:      	ldr	w2, [x16, #0x4]
    4134:      	lsr	w2, w2, #0
    4138:      	mov	x23, x8
    413c:      	add	x8, sp, #0x30
    4140:      	mov	x24, x0
    4144:      	mov	w25, w1
    4148:      	mov	w1, w2
    414c:      	bl	0x414c <_stogir.atomic.validate+0x268>
		000000000000414c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4150:      	add	x16, sp, #0x30
    4154:      	ldr	w0, [x16]
    4158:      	lsr	x16, x0, #0
    415c:      	cmp	x16, #0x1
    4160:      	b.eq	0x417c <_stogir.atomic.validate+0x298>
    4164:      	b.lo	0x416c <_stogir.atomic.validate+0x288>
    4168:      	b	0x4180 <_stogir.atomic.validate+0x29c>
    416c:      	cmp	x16, #0x0
    4170:      	b.eq	0x4178 <_stogir.atomic.validate+0x294>
    4174:      	b	0x4180 <_stogir.atomic.validate+0x29c>
    4178:      	b	0x4184 <_stogir.atomic.validate+0x2a0>
    417c:      	b	0x424c <_stogir.atomic.validate+0x368>
    4180:      	b	0x4680 <_stogir.atomic.validate+0x79c>
    4184:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004184:  ARM64_RELOC_PAGE21	l_stogir.367
    4188:      	ldr	x16, [x16]
		0000000000004188:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    418c:      	orr	x20, x16, xzr
    4190:      	mov	x22, #0x16              ; =22
    4194:      	b	0x41bc <_stogir.atomic.validate+0x2d8>
    4198:      	movz	x5, #0x0, lsl #48
    419c:      	b	0x3fc8 <_stogir.atomic.validate+0xe4>
    41a0:      	mov	x0, #0x1                ; =1
    41a4:      	cmp	x0, #0x0
    41a8:      	b.eq	0x41bc <_stogir.atomic.validate+0x2d8>
    41ac:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		00000000000041ac:  ARM64_RELOC_PAGE21	l_stogir.368
    41b0:      	ldr	x16, [x16]
		00000000000041b0:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    41b4:      	orr	x20, x16, xzr
    41b8:      	mov	x22, #0x16              ; =22
    41bc:      	cmp	x21, #0x82
    41c0:      	cset	w26, eq
    41c4:      	lsr	w19, w19, #0
    41c8:      	ubfx	x0, x19, #8, #8
    41cc:      	orr	x19, x0, xzr
    41d0:      	cmp	x19, #0x0
    41d4:      	cset	w27, eq
    41d8:      	uxtb	w16, w26
    41dc:      	cmp	w16, wzr
    41e0:      	b.eq	0x4200 <_stogir.atomic.validate+0x31c>
    41e4:      	uxtb	w16, w27
    41e8:      	cmp	w16, wzr
    41ec:      	b.ne	0x4200 <_stogir.atomic.validate+0x31c>
    41f0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		00000000000041f0:  ARM64_RELOC_PAGE21	l_stogir.369
    41f4:      	ldr	x16, [x16]
		00000000000041f4:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    41f8:      	orr	x20, x16, xzr
    41fc:      	mov	x22, #0x19              ; =25
    4200:      	uxtb	w16, w26
    4204:      	cmp	w16, wzr
    4208:      	b.eq	0x4214 <_stogir.atomic.validate+0x330>
    420c:      	movz	x0, #0x0, lsl #48
    4210:      	b	0x4218 <_stogir.atomic.validate+0x334>
    4214:      	mov	x0, #0x1                ; =1
    4218:      	cmp	x0, #0x0
    421c:      	b.eq	0x428c <_stogir.atomic.validate+0x3a8>
    4220:      	add	x16, sp, #0x20
    4224:      	ldr	w0, [x16, #0x8]
    4228:      	lsr	w0, w0, #0
    422c:      	mov	w1, w0
    4230:      	mov	x0, x24
    4234:      	mov	x2, #0x6                ; =6
    4238:      	bl	0x4238 <_stogir.atomic.validate+0x354>
		0000000000004238:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    423c:      	cmp	x0, #0x0
    4240:      	b.eq	0x4370 <_stogir.atomic.validate+0x48c>
    4244:      	movz	x0, #0x0, lsl #48
    4248:      	b	0x4374 <_stogir.atomic.validate+0x490>
    424c:      	add	x16, sp, #0x30
    4250:      	ldr	x0, [x16, #0x8]
    4254:      	add	x16, sp, #0x20
    4258:      	ldr	w1, [x16, #0x4]
    425c:      	sxtw	x1, w1
    4260:      	cmp	x1, #0x0
    4264:      	b.gt	0x4414 <_stogir.atomic.validate+0x530>
    4268:      	mov	x0, #0x1                ; =1
    426c:      	b	0x41a4 <_stogir.atomic.validate+0x2c0>
    4270:      	movz	x0, #0x0, lsl #48
    4274:      	cmp	x0, #0x0
    4278:      	b.eq	0x428c <_stogir.atomic.validate+0x3a8>
    427c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		000000000000427c:  ARM64_RELOC_PAGE21	l_stogir.370
    4280:      	ldr	x16, [x16]
		0000000000004280:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    4284:      	orr	x20, x16, xzr
    4288:      	mov	x22, #0x22              ; =34
    428c:      	cmp	x21, #0x80
    4290:      	cset	w27, eq
    4294:      	uxtb	w16, w27
    4298:      	cmp	w16, wzr
    429c:      	b.eq	0x42a8 <_stogir.atomic.validate+0x3c4>
    42a0:      	mov	x0, #0x1                ; =1
    42a4:      	b	0x42b4 <_stogir.atomic.validate+0x3d0>
    42a8:      	cmp	x21, #0x81
    42ac:      	cset	w0, eq
    42b0:      	ubfx	x0, x0, #0, #8
    42b4:      	lsr	w19, w19, #0
    42b8:      	cmp	x0, #0x0
    42bc:      	b.eq	0x4338 <_stogir.atomic.validate+0x454>
    42c0:      	lsr	w25, w25, #0
    42c4:      	add	x16, sp, #0x90
    42c8:      	str	x16, [sp]
    42cc:      	mov	x0, x24
    42d0:      	mov	w1, w25
    42d4:      	mov	x2, #0x4                ; =4
    42d8:      	bl	0x42d8 <_stogir.atomic.validate+0x3f4>
		00000000000042d8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    42dc:      	ldr	x16, [sp]
    42e0:      	str	x0, [x16]
    42e4:      	str	x1, [x16, #0x8]
    42e8:      	add	x16, sp, #0x90
    42ec:      	ldr	x0, [x16]
    42f0:      	add	x16, sp, #0x90
    42f4:      	ldr	x1, [x16, #0x8]
    42f8:      	lsr	w0, w0, #0
    42fc:      	lsr	x16, x0, #0
    4300:      	cmp	x16, #0x1
    4304:      	b.eq	0x4320 <_stogir.atomic.validate+0x43c>
    4308:      	b.lo	0x4310 <_stogir.atomic.validate+0x42c>
    430c:      	b	0x4324 <_stogir.atomic.validate+0x440>
    4310:      	cmp	x16, #0x0
    4314:      	b.eq	0x431c <_stogir.atomic.validate+0x438>
    4318:      	b	0x4324 <_stogir.atomic.validate+0x440>
    431c:      	b	0x4328 <_stogir.atomic.validate+0x444>
    4320:      	b	0x44f0 <_stogir.atomic.validate+0x60c>
    4324:      	b	0x4690 <_stogir.atomic.validate+0x7ac>
    4328:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004328:  ARM64_RELOC_PAGE21	l_stogir.371
    432c:      	ldr	x16, [x16]
		000000000000432c:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    4330:      	orr	x20, x16, xzr
    4334:      	mov	x22, #0x1d              ; =29
    4338:      	cmp	x22, #0x0
    433c:      	b.ne	0x4114 <_stogir.atomic.validate+0x230>
    4340:      	uxtb	w16, w26
    4344:      	cmp	w16, wzr
    4348:      	b.eq	0x44dc <_stogir.atomic.validate+0x5f8>
    434c:      	movz	x0, #0x0, lsl #48
    4350:      	b	0x4360 <_stogir.atomic.validate+0x47c>
    4354:      	mov	x0, #0x1                ; =1
    4358:      	lsr	w0, w0, #0
    435c:      	sxtw	x0, w0
    4360:      	and	x20, x0, #0xffffffff
    4364:      	movz	x0, #0x0, lsl #48
    4368:      	movz	x22, #0x0, lsl #48
    436c:      	b	0x4118 <_stogir.atomic.validate+0x234>
    4370:      	mov	x0, #0x1                ; =1
    4374:      	cmp	x0, #0x0
    4378:      	b.eq	0x438c <_stogir.atomic.validate+0x4a8>
    437c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		000000000000437c:  ARM64_RELOC_PAGE21	l_stogir.372
    4380:      	ldr	x16, [x16]
		0000000000004380:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    4384:      	orr	x20, x16, xzr
    4388:      	mov	x22, #0x1b              ; =27
    438c:      	cmp	x21, #0x7f
    4390:      	b.ne	0x4458 <_stogir.atomic.validate+0x574>
    4394:      	uxtb	w16, w27
    4398:      	cmp	w16, wzr
    439c:      	b.ne	0x43b0 <_stogir.atomic.validate+0x4cc>
    43a0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		00000000000043a0:  ARM64_RELOC_PAGE21	l_stogir.373
    43a4:      	ldr	x16, [x16]
		00000000000043a4:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    43a8:      	orr	x20, x16, xzr
    43ac:      	mov	x22, #0x19              ; =25
    43b0:      	add	x16, sp, #0x20
    43b4:      	ldr	w0, [x16, #0xc]
    43b8:      	lsr	w0, w0, #0
    43bc:      	add	x8, sp, #0x60
    43c0:      	mov	w1, w0
    43c4:      	mov	x0, x24
    43c8:      	bl	0x43c8 <_stogir.atomic.validate+0x4e4>
		00000000000043c8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    43cc:      	add	x16, sp, #0x60
    43d0:      	ldr	w0, [x16]
    43d4:      	lsr	x16, x0, #0
    43d8:      	cmp	x16, #0x1
    43dc:      	b.eq	0x43f8 <_stogir.atomic.validate+0x514>
    43e0:      	b.lo	0x43e8 <_stogir.atomic.validate+0x504>
    43e4:      	b	0x43fc <_stogir.atomic.validate+0x518>
    43e8:      	cmp	x16, #0x0
    43ec:      	b.eq	0x43f4 <_stogir.atomic.validate+0x510>
    43f0:      	b	0x43fc <_stogir.atomic.validate+0x518>
    43f4:      	b	0x4400 <_stogir.atomic.validate+0x51c>
    43f8:      	b	0x4444 <_stogir.atomic.validate+0x560>
    43fc:      	b	0x4698 <_stogir.atomic.validate+0x7b4>
    4400:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004400:  ARM64_RELOC_PAGE21	l_stogir.374
    4404:      	ldr	x16, [x16]
		0000000000004404:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    4408:      	orr	x20, x16, xzr
    440c:      	mov	x22, #0x1a              ; =26
    4410:      	b	0x4458 <_stogir.atomic.validate+0x574>
    4414:      	uxtb	w0, w0
    4418:      	cmp	x0, #0x83
    441c:      	cset	w1, lt
    4420:      	uxtb	w16, w1
    4424:      	cmp	w16, wzr
    4428:      	b.eq	0x4568 <_stogir.atomic.validate+0x684>
    442c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		000000000000442c:  ARM64_RELOC_PAGE21	l_stogir.375
    4430:      	ldr	x16, [x16]
		0000000000004430:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    4434:      	orr	x2, x16, xzr
    4438:      	add	x2, x0, x2
    443c:      	ldrb	w2, [x2]
    4440:      	b	0x456c <_stogir.atomic.validate+0x688>
    4444:      	add	x16, sp, #0x60
    4448:      	ldr	x0, [x16, #0x8]
    444c:      	lsr	w0, w0, #0
    4450:      	ubfx	x0, x0, #8, #8
    4454:      	orr	x19, x0, xzr
    4458:      	cmp	x19, #0x2
    445c:      	b.ge	0x44a8 <_stogir.atomic.validate+0x5c4>
    4460:      	mov	x0, #0x1                ; =1
    4464:      	b	0x44b4 <_stogir.atomic.validate+0x5d0>
    4468:      	mov	x0, #0x1                ; =1
    446c:      	b	0x4274 <_stogir.atomic.validate+0x390>
    4470:      	mov	x0, #0x1                ; =1
    4474:      	cmp	x0, #0x0
    4478:      	b.eq	0x4270 <_stogir.atomic.validate+0x38c>
    447c:      	lsr	w0, w19, #0
    4480:      	add	x16, sp, #0x20
    4484:      	ldr	w1, [x16, #0xc]
    4488:      	lsr	w1, w1, #0
    448c:      	mov	w2, w0
    4490:      	mov	x0, x24
    4494:      	bl	0x4494 <_stogir.atomic.validate+0x5b0>
		0000000000004494:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4498:      	cmp	x0, #0x0
    449c:      	b.eq	0x4468 <_stogir.atomic.validate+0x584>
    44a0:      	movz	x0, #0x0, lsl #48
    44a4:      	b	0x446c <_stogir.atomic.validate+0x588>
    44a8:      	cmp	x19, #0x5
    44ac:      	cset	w0, gt
    44b0:      	ubfx	x0, x0, #0, #8
    44b4:      	cmp	x0, #0x0
    44b8:      	b.eq	0x44cc <_stogir.atomic.validate+0x5e8>
    44bc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		00000000000044bc:  ARM64_RELOC_PAGE21	l_stogir.376
    44c0:      	ldr	x16, [x16]
		00000000000044c0:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    44c4:      	orr	x20, x16, xzr
    44c8:      	mov	x22, #0x25              ; =37
    44cc:      	cmp	x21, #0x7e
    44d0:      	b.ne	0x4470 <_stogir.atomic.validate+0x58c>
    44d4:      	movz	x0, #0x0, lsl #48
    44d8:      	b	0x4474 <_stogir.atomic.validate+0x590>
    44dc:      	sxtw	x19, w19
    44e0:      	cmp	x19, #0x0
    44e4:      	b.ne	0x45d0 <_stogir.atomic.validate+0x6ec>
    44e8:      	movz	x0, #0x0, lsl #48
    44ec:      	b	0x4358 <_stogir.atomic.validate+0x474>
    44f0:      	lsr	w1, w1, #0
    44f4:      	uxtb	w16, w27
    44f8:      	cmp	w16, wzr
    44fc:      	b.eq	0x4514 <_stogir.atomic.validate+0x630>
    4500:      	sxtw	x1, w1
    4504:      	cmp	x1, #0x0
    4508:      	b.ge	0x4650 <_stogir.atomic.validate+0x76c>
    450c:      	mov	x0, #0x1                ; =1
    4510:      	b	0x465c <_stogir.atomic.validate+0x778>
    4514:      	lsr	w1, w1, #0
    4518:      	mov	x0, x24
    451c:      	mov	w2, w19
    4520:      	bl	0x4520 <_stogir.atomic.validate+0x63c>
		0000000000004520:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4524:      	cmp	x0, #0x0
    4528:      	b.ne	0x453c <_stogir.atomic.validate+0x658>
    452c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		000000000000452c:  ARM64_RELOC_PAGE21	l_stogir.377
    4530:      	ldr	x16, [x16]
		0000000000004530:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    4534:      	orr	x20, x16, xzr
    4538:      	mov	x22, #0x24              ; =36
    453c:      	b	0x4338 <_stogir.atomic.validate+0x454>
    4540:      	movz	x0, #0x0, lsl #48
    4544:      	uxtb	w0, w0
    4548:      	and	x0, x0, #0x4
    454c:      	uxtb	w0, w0
    4550:      	cmp	x0, #0x0
    4554:      	cset	w0, eq
    4558:      	uxtb	w16, w0
    455c:      	cmp	w16, wzr
    4560:      	cset	x0, eq
    4564:      	b	0x41a4 <_stogir.atomic.validate+0x2c0>
    4568:      	movz	x2, #0x0, lsl #48
    456c:      	uxtb	w2, w2
    4570:      	and	x2, x2, #0x1
    4574:      	uxtb	w2, w2
    4578:      	cmp	x2, #0x0
    457c:      	b.eq	0x41a0 <_stogir.atomic.validate+0x2bc>
    4580:      	uxtb	w16, w1
    4584:      	cmp	w16, wzr
    4588:      	b.eq	0x4540 <_stogir.atomic.validate+0x65c>
    458c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		000000000000458c:  ARM64_RELOC_PAGE21	l_stogir.375
    4590:      	ldr	x16, [x16]
		0000000000004590:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    4594:      	orr	x1, x16, xzr
    4598:      	add	x0, x0, x1
    459c:      	ldrb	w0, [x0]
    45a0:      	b	0x4544 <_stogir.atomic.validate+0x660>
    45a4:      	mov	x3, #-0x2               ; =-2
    45a8:      	sxtw	x2, w2
    45ac:      	lsr	w3, w3, #0
    45b0:      	sxtw	x3, w3
    45b4:      	cmp	x2, x3
    45b8:      	b.ne	0x411c <_stogir.atomic.validate+0x238>
    45bc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		00000000000045bc:  ARM64_RELOC_PAGE21	l_stogir.378
    45c0:      	ldr	x16, [x16]
		00000000000045c0:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    45c4:      	orr	x20, x16, xzr
    45c8:      	movz	x22, #0x0, lsl #48
    45cc:      	b	0x412c <_stogir.atomic.validate+0x248>
    45d0:      	cmp	x19, #0x1
    45d4:      	b.eq	0x4354 <_stogir.atomic.validate+0x470>
    45d8:      	cmp	x19, #0x2
    45dc:      	b.eq	0x4354 <_stogir.atomic.validate+0x470>
    45e0:      	cmp	x19, #0x7
    45e4:      	b.eq	0x4354 <_stogir.atomic.validate+0x470>
    45e8:      	cmp	x19, #0x8
    45ec:      	b.eq	0x4354 <_stogir.atomic.validate+0x470>
    45f0:      	cmp	x19, #0x3
    45f4:      	b.eq	0x4688 <_stogir.atomic.validate+0x7a4>
    45f8:      	cmp	x19, #0x9
    45fc:      	b.eq	0x4688 <_stogir.atomic.validate+0x7a4>
    4600:      	cmp	x19, #0x4
    4604:      	b.eq	0x46a0 <_stogir.atomic.validate+0x7bc>
    4608:      	cmp	x19, #0xa
    460c:      	b.eq	0x46a0 <_stogir.atomic.validate+0x7bc>
    4610:      	cmp	x19, #0xd
    4614:      	b.eq	0x46a0 <_stogir.atomic.validate+0x7bc>
    4618:      	cmp	x19, #0x5
    461c:      	b.eq	0x46a8 <_stogir.atomic.validate+0x7c4>
    4620:      	cmp	x19, #0xb
    4624:      	b.eq	0x46a8 <_stogir.atomic.validate+0x7c4>
    4628:      	cmp	x19, #0xc
    462c:      	b.eq	0x46a8 <_stogir.atomic.validate+0x7c4>
    4630:      	cmp	x19, #0x6
    4634:      	cset	w0, eq
    4638:      	uxtb	w16, w0
    463c:      	cmp	w16, wzr
    4640:      	mov	x16, #0x8               ; =8
    4644:      	movn	x17, #0x0, lsl #48
    4648:      	csel	x0, x16, x17, ne
    464c:      	b	0x46ac <_stogir.atomic.validate+0x7c8>
    4650:      	cmp	x1, #0x9
    4654:      	cset	w0, gt
    4658:      	ubfx	x0, x0, #0, #8
    465c:      	cmp	x0, #0x0
    4660:      	b.eq	0x4674 <_stogir.atomic.validate+0x790>
    4664:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004664:  ARM64_RELOC_PAGE21	l_stogir.379
    4668:      	ldr	x16, [x16]
		0000000000004668:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    466c:      	orr	x20, x16, xzr
    4670:      	mov	x22, #0x1c              ; =28
    4674:      	b	0x453c <_stogir.atomic.validate+0x658>
    4678:      	brk	#0
    467c:      	b	0x4678 <_stogir.atomic.validate+0x794>
    4680:      	brk	#0
    4684:      	b	0x4680 <_stogir.atomic.validate+0x79c>
    4688:      	mov	x0, #0x2                ; =2
    468c:      	b	0x4358 <_stogir.atomic.validate+0x474>
    4690:      	brk	#0
    4694:      	b	0x4690 <_stogir.atomic.validate+0x7ac>
    4698:      	brk	#0
    469c:      	b	0x4698 <_stogir.atomic.validate+0x7b4>
    46a0:      	mov	x0, #0x4                ; =4
    46a4:      	b	0x468c <_stogir.atomic.validate+0x7a8>
    46a8:      	mov	x0, #0x8                ; =8
    46ac:      	b	0x46a4 <_stogir.atomic.validate+0x7c0>

00000000000046b0 <_stogir.terminal.validate>:
    46b0:      	sub	sp, sp, #0x50
    46b4:      	str	x29, [sp]
    46b8:      	str	x30, [sp, #0x8]
    46bc:      	mov	x29, sp
    46c0:      	str	x19, [sp, #0x40]
    46c4:      	sxtw	x1, w1
    46c8:      	lsl	x2, x1, #2
    46cc:      	cmp	x1, #0x0
    46d0:      	cset	w3, gt
    46d4:      	movz	x16, #0x0, lsl #48
    46d8:      	sub	x4, x16, x1
    46dc:      	sub	x5, x4, #0x1
    46e0:      	uxtb	w16, w3
    46e4:      	cmp	w16, wzr
    46e8:      	b.eq	0x4728 <_stogir.terminal.validate+0x78>
    46ec:      	ldr	x4, [x0, #0x8]
    46f0:      	cmp	x1, x4
    46f4:      	b.ge	0x4778 <_stogir.terminal.validate+0xc8>
    46f8:      	add	x4, x0, #0x78
    46fc:      	ldr	x4, [x4, #0x8]
    4700:      	cmp	x1, x4
    4704:      	b.ge	0x486c <_stogir.terminal.validate+0x1bc>
    4708:      	ldr	x4, [x0, #0x78]
    470c:      	add	x4, x2, x4
    4710:      	ldr	w4, [x4]
    4714:      	sxtw	x4, w4
    4718:      	cmp	x4, #0x0
    471c:      	cset	w4, ge
    4720:      	ubfx	x4, x4, #0, #8
    4724:      	b	0x4870 <_stogir.terminal.validate+0x1c0>
    4728:      	cmp	x1, #0x0
    472c:      	b.ge	0x4780 <_stogir.terminal.validate+0xd0>
    4730:      	add	x6, x0, #0x28
    4734:      	add	x7, x0, #0x50
    4738:      	ldr	x6, [x6, #0x8]
    473c:      	ldr	x7, [x7, #0x8]
    4740:      	cmp	x6, x7
    4744:      	b.ne	0x4770 <_stogir.terminal.validate+0xc0>
    4748:      	cmp	x4, x6
    474c:      	b.gt	0x48ac <_stogir.terminal.validate+0x1fc>
    4750:      	ldr	x4, [x0, #0x50]
    4754:      	add	x4, x4, x5, lsl #2
    4758:      	ldr	w4, [x4]
    475c:      	sxtw	x4, w4
    4760:      	cmp	x4, #0x0
    4764:      	cset	w4, gt
    4768:      	ubfx	x4, x4, #0, #8
    476c:      	b	0x48b0 <_stogir.terminal.validate+0x200>
    4770:      	movz	x4, #0x0, lsl #48
    4774:      	b	0x4784 <_stogir.terminal.validate+0xd4>
    4778:      	movz	x4, #0x0, lsl #48
    477c:      	b	0x4784 <_stogir.terminal.validate+0xd4>
    4780:      	movz	x4, #0x0, lsl #48
    4784:      	cmp	x4, #0x0
    4788:      	b.eq	0x47c4 <_stogir.terminal.validate+0x114>
    478c:      	uxtb	w16, w3
    4790:      	cmp	w16, wzr
    4794:      	b.eq	0x47ac <_stogir.terminal.validate+0xfc>
    4798:      	ldr	x3, [x0]
    479c:      	add	x3, x3, x1, lsl #4
    47a0:      	ldr	x4, [x3]
    47a4:      	ldr	x3, [x3, #0x8]
    47a8:      	b	0x47bc <_stogir.terminal.validate+0x10c>
    47ac:      	ldr	x3, [x0, #0x28]
    47b0:      	add	x3, x3, x5, lsl #4
    47b4:      	ldr	x4, [x3]
    47b8:      	ldr	x3, [x3, #0x8]
    47bc:      	mov	x5, #0x1                ; =1
    47c0:      	b	0x47d0 <_stogir.terminal.validate+0x120>
    47c4:      	movz	x5, #0x0, lsl #48
    47c8:      	movz	x4, #0x0, lsl #48
    47cc:      	movz	x3, #0x0, lsl #48
    47d0:      	lsr	w5, w5, #0
    47d4:      	lsr	x16, x5, #0
    47d8:      	cmp	x16, #0x1
    47dc:      	b.eq	0x47f8 <_stogir.terminal.validate+0x148>
    47e0:      	b.lo	0x47e8 <_stogir.terminal.validate+0x138>
    47e4:      	b	0x47fc <_stogir.terminal.validate+0x14c>
    47e8:      	cmp	x16, #0x0
    47ec:      	b.eq	0x47f4 <_stogir.terminal.validate+0x144>
    47f0:      	b	0x47fc <_stogir.terminal.validate+0x14c>
    47f4:      	b	0x4800 <_stogir.terminal.validate+0x150>
    47f8:      	b	0x481c <_stogir.terminal.validate+0x16c>
    47fc:      	b	0x4988 <_stogir.terminal.validate+0x2d8>
    4800:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004800:  ARM64_RELOC_PAGE21	l_stogir.380
    4804:      	ldr	x16, [x16]
		0000000000004804:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    4808:      	orr	x0, x16, xzr
    480c:      	mov	x19, x8
    4810:      	mov	x1, #0x1                ; =1
    4814:      	mov	x2, #0x21               ; =33
    4818:      	b	0x484c <_stogir.terminal.validate+0x19c>
    481c:      	add	x16, sp, #0x10
    4820:      	str	x4, [x16]
    4824:      	add	x16, sp, #0x10
    4828:      	str	x3, [x16, #0x8]
    482c:      	cmp	x1, #0x0
    4830:      	b.gt	0x4874 <_stogir.terminal.validate+0x1c4>
    4834:      	mov	x19, x8
    4838:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004838:  ARM64_RELOC_PAGE21	l_stogir.381
    483c:      	ldr	x16, [x16]
		000000000000483c:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    4840:      	orr	x0, x16, xzr
    4844:      	mov	x1, #0x1                ; =1
    4848:      	mov	x2, #0x1b               ; =27
    484c:      	str	x1, [x19]
    4850:      	str	x0, [x19, #0x8]
    4854:      	str	x2, [x19, #0x10]
    4858:      	ldr	x19, [sp, #0x40]
    485c:      	ldr	x29, [sp]
    4860:      	ldr	x30, [sp, #0x8]
    4864:      	add	sp, sp, #0x50
    4868:      	ret
    486c:      	movz	x4, #0x0, lsl #48
    4870:      	b	0x477c <_stogir.terminal.validate+0xcc>
    4874:      	uxtb	w4, w4
    4878:      	orr	x1, x4, xzr
    487c:      	cmp	x1, #0x60
    4880:      	cset	w3, eq
    4884:      	cmp	x1, #0x79
    4888:      	cset	w1, eq
    488c:      	uxtb	w16, w3
    4890:      	cmp	w16, wzr
    4894:      	b.ne	0x48b4 <_stogir.terminal.validate+0x204>
    4898:      	uxtb	w16, w1
    489c:      	cmp	w16, wzr
    48a0:      	b.ne	0x48b4 <_stogir.terminal.validate+0x204>
    48a4:      	mov	x19, x8
    48a8:      	b	0x4838 <_stogir.terminal.validate+0x188>
    48ac:      	movz	x4, #0x0, lsl #48
    48b0:      	b	0x4774 <_stogir.terminal.validate+0xc4>
    48b4:      	add	x16, sp, #0x10
    48b8:      	ldr	w5, [x16]
    48bc:      	ubfx	x5, x5, #8, #8
    48c0:      	cmp	x5, #0x0
    48c4:      	b.ne	0x4990 <_stogir.terminal.validate+0x2e0>
    48c8:      	uxtb	w16, w3
    48cc:      	cmp	w16, wzr
    48d0:      	mov	x16, #0x1               ; =1
    48d4:      	mov	x17, #0x3               ; =3
    48d8:      	csel	x3, x16, x17, ne
    48dc:      	lsr	w3, w3, #0
    48e0:      	sxtw	x3, w3
    48e4:      	ldr	x5, [x0, #0x78]
    48e8:      	add	x2, x2, x5
    48ec:      	ldr	w2, [x2]
    48f0:      	sxtw	x2, w2
    48f4:      	cmp	x2, x3
    48f8:      	b.ne	0x4998 <_stogir.terminal.validate+0x2e8>
    48fc:      	uxtb	w16, w1
    4900:      	cmp	w16, wzr
    4904:      	b.eq	0x4964 <_stogir.terminal.validate+0x2b4>
    4908:      	add	x16, sp, #0x10
    490c:      	ldr	w2, [x16, #0x8]
    4910:      	sxtw	x2, w2
    4914:      	cmp	x2, #0x0
    4918:      	b.eq	0x4964 <_stogir.terminal.validate+0x2b4>
    491c:      	mov	x19, x8
    4920:      	b	0x4838 <_stogir.terminal.validate+0x188>
    4924:      	movz	x1, #0x0, lsl #48
    4928:      	lsr	w2, w2, #0
    492c:      	lsr	w4, w4, #0
    4930:      	lsr	w1, w1, #0
    4934:      	mov	w3, w1
    4938:      	mov	w1, w4
    493c:      	mov	x19, x8
    4940:      	add	x8, sp, #0x20
    4944:      	bl	0x4944 <_stogir.terminal.validate+0x294>
		0000000000004944:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    4948:      	add	x16, sp, #0x20
    494c:      	ldr	x1, [x16]
    4950:      	add	x16, sp, #0x20
    4954:      	ldr	x0, [x16, #0x8]
    4958:      	add	x16, sp, #0x20
    495c:      	ldr	x2, [x16, #0x10]
    4960:      	b	0x484c <_stogir.terminal.validate+0x19c>
    4964:      	add	x16, sp, #0x10
    4968:      	ldr	w2, [x16, #0x4]
    496c:      	uxtb	w16, w1
    4970:      	cmp	w16, wzr
    4974:      	b.eq	0x4924 <_stogir.terminal.validate+0x274>
    4978:      	add	x16, sp, #0x10
    497c:      	ldr	w1, [x16, #0xc]
    4980:      	sxtw	x1, w1
    4984:      	b	0x4928 <_stogir.terminal.validate+0x278>
    4988:      	brk	#0
    498c:      	b	0x4988 <_stogir.terminal.validate+0x2d8>
    4990:      	mov	x19, x8
    4994:      	b	0x4838 <_stogir.terminal.validate+0x188>
    4998:      	mov	x19, x8
    499c:      	b	0x4838 <_stogir.terminal.validate+0x188>

00000000000049a0 <_stogir.switch.validate>:
    49a0:      	sub	sp, sp, #0x70
    49a4:      	str	x29, [sp]
    49a8:      	str	x30, [sp, #0x8]
    49ac:      	mov	x29, sp
    49b0:      	str	x19, [sp, #0x60]
    49b4:      	sxtw	x1, w1
    49b8:      	lsl	x2, x1, #2
    49bc:      	cmp	x1, #0x0
    49c0:      	cset	w3, gt
    49c4:      	movz	x16, #0x0, lsl #48
    49c8:      	sub	x4, x16, x1
    49cc:      	sub	x5, x4, #0x1
    49d0:      	uxtb	w16, w3
    49d4:      	cmp	w16, wzr
    49d8:      	b.eq	0x4a18 <_stogir.switch.validate+0x78>
    49dc:      	ldr	x4, [x0, #0x8]
    49e0:      	cmp	x1, x4
    49e4:      	b.ge	0x4a68 <_stogir.switch.validate+0xc8>
    49e8:      	add	x4, x0, #0x78
    49ec:      	ldr	x4, [x4, #0x8]
    49f0:      	cmp	x1, x4
    49f4:      	b.ge	0x4b5c <_stogir.switch.validate+0x1bc>
    49f8:      	ldr	x4, [x0, #0x78]
    49fc:      	add	x4, x2, x4
    4a00:      	ldr	w4, [x4]
    4a04:      	sxtw	x4, w4
    4a08:      	cmp	x4, #0x0
    4a0c:      	cset	w4, ge
    4a10:      	ubfx	x4, x4, #0, #8
    4a14:      	b	0x4b60 <_stogir.switch.validate+0x1c0>
    4a18:      	cmp	x1, #0x0
    4a1c:      	b.ge	0x4a70 <_stogir.switch.validate+0xd0>
    4a20:      	add	x6, x0, #0x28
    4a24:      	add	x7, x0, #0x50
    4a28:      	ldr	x6, [x6, #0x8]
    4a2c:      	ldr	x7, [x7, #0x8]
    4a30:      	cmp	x6, x7
    4a34:      	b.ne	0x4a60 <_stogir.switch.validate+0xc0>
    4a38:      	cmp	x4, x6
    4a3c:      	b.gt	0x4b98 <_stogir.switch.validate+0x1f8>
    4a40:      	ldr	x4, [x0, #0x50]
    4a44:      	add	x4, x4, x5, lsl #2
    4a48:      	ldr	w4, [x4]
    4a4c:      	sxtw	x4, w4
    4a50:      	cmp	x4, #0x0
    4a54:      	cset	w4, gt
    4a58:      	ubfx	x4, x4, #0, #8
    4a5c:      	b	0x4b9c <_stogir.switch.validate+0x1fc>
    4a60:      	movz	x4, #0x0, lsl #48
    4a64:      	b	0x4a74 <_stogir.switch.validate+0xd4>
    4a68:      	movz	x4, #0x0, lsl #48
    4a6c:      	b	0x4a74 <_stogir.switch.validate+0xd4>
    4a70:      	movz	x4, #0x0, lsl #48
    4a74:      	cmp	x4, #0x0
    4a78:      	b.eq	0x4ab4 <_stogir.switch.validate+0x114>
    4a7c:      	uxtb	w16, w3
    4a80:      	cmp	w16, wzr
    4a84:      	b.eq	0x4a9c <_stogir.switch.validate+0xfc>
    4a88:      	ldr	x3, [x0]
    4a8c:      	add	x3, x3, x1, lsl #4
    4a90:      	ldr	x4, [x3]
    4a94:      	ldr	x3, [x3, #0x8]
    4a98:      	b	0x4aac <_stogir.switch.validate+0x10c>
    4a9c:      	ldr	x3, [x0, #0x28]
    4aa0:      	add	x3, x3, x5, lsl #4
    4aa4:      	ldr	x4, [x3]
    4aa8:      	ldr	x3, [x3, #0x8]
    4aac:      	mov	x5, #0x1                ; =1
    4ab0:      	b	0x4ac0 <_stogir.switch.validate+0x120>
    4ab4:      	movz	x5, #0x0, lsl #48
    4ab8:      	movz	x4, #0x0, lsl #48
    4abc:      	movz	x3, #0x0, lsl #48
    4ac0:      	lsr	w5, w5, #0
    4ac4:      	lsr	x16, x5, #0
    4ac8:      	cmp	x16, #0x1
    4acc:      	b.eq	0x4ae8 <_stogir.switch.validate+0x148>
    4ad0:      	b.lo	0x4ad8 <_stogir.switch.validate+0x138>
    4ad4:      	b	0x4aec <_stogir.switch.validate+0x14c>
    4ad8:      	cmp	x16, #0x0
    4adc:      	b.eq	0x4ae4 <_stogir.switch.validate+0x144>
    4ae0:      	b	0x4aec <_stogir.switch.validate+0x14c>
    4ae4:      	b	0x4af0 <_stogir.switch.validate+0x150>
    4ae8:      	b	0x4b0c <_stogir.switch.validate+0x16c>
    4aec:      	b	0x4c9c <_stogir.switch.validate+0x2fc>
    4af0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004af0:  ARM64_RELOC_PAGE21	l_stogir.382
    4af4:      	ldr	x16, [x16]
		0000000000004af4:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    4af8:      	orr	x0, x16, xzr
    4afc:      	mov	x19, x8
    4b00:      	mov	x1, #0x1                ; =1
    4b04:      	mov	x2, #0x1a               ; =26
    4b08:      	b	0x4b3c <_stogir.switch.validate+0x19c>
    4b0c:      	add	x16, sp, #0x10
    4b10:      	str	x4, [x16]
    4b14:      	add	x16, sp, #0x10
    4b18:      	str	x3, [x16, #0x8]
    4b1c:      	cmp	x1, #0x0
    4b20:      	b.gt	0x4b64 <_stogir.switch.validate+0x1c4>
    4b24:      	mov	x19, x8
    4b28:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004b28:  ARM64_RELOC_PAGE21	l_stogir.383
    4b2c:      	ldr	x16, [x16]
		0000000000004b2c:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    4b30:      	orr	x0, x16, xzr
    4b34:      	mov	x1, #0x1                ; =1
    4b38:      	mov	x2, #0x20               ; =32
    4b3c:      	str	x1, [x19]
    4b40:      	str	x0, [x19, #0x8]
    4b44:      	str	x2, [x19, #0x10]
    4b48:      	ldr	x19, [sp, #0x60]
    4b4c:      	ldr	x29, [sp]
    4b50:      	ldr	x30, [sp, #0x8]
    4b54:      	add	sp, sp, #0x70
    4b58:      	ret
    4b5c:      	movz	x4, #0x0, lsl #48
    4b60:      	b	0x4a6c <_stogir.switch.validate+0xcc>
    4b64:      	uxtb	w4, w4
    4b68:      	orr	x1, x4, xzr
    4b6c:      	cmp	x1, #0x75
    4b70:      	cset	w3, eq
    4b74:      	uxtb	w16, w3
    4b78:      	cmp	w16, wzr
    4b7c:      	b.ne	0x4ba0 <_stogir.switch.validate+0x200>
    4b80:      	cmp	x1, #0x6d
    4b84:      	b.lt	0x4ca4 <_stogir.switch.validate+0x304>
    4b88:      	cmp	x1, #0x6f
    4b8c:      	b.le	0x4ba0 <_stogir.switch.validate+0x200>
    4b90:      	mov	x19, x8
    4b94:      	b	0x4b28 <_stogir.switch.validate+0x188>
    4b98:      	movz	x4, #0x0, lsl #48
    4b9c:      	b	0x4a64 <_stogir.switch.validate+0xc4>
    4ba0:      	add	x16, sp, #0x10
    4ba4:      	ldr	w5, [x16]
    4ba8:      	ubfx	x5, x5, #8, #8
    4bac:      	cmp	x5, #0x0
    4bb0:      	b.ne	0x4cac <_stogir.switch.validate+0x30c>
    4bb4:      	ldr	x5, [x0, #0x78]
    4bb8:      	add	x2, x2, x5
    4bbc:      	ldr	w2, [x2]
    4bc0:      	cmp	x1, #0x6d
    4bc4:      	b.eq	0x4c38 <_stogir.switch.validate+0x298>
    4bc8:      	cmp	x1, #0x6e
    4bcc:      	b.eq	0x4c38 <_stogir.switch.validate+0x298>
    4bd0:      	mov	x1, #0x2                ; =2
    4bd4:      	b	0x4c3c <_stogir.switch.validate+0x29c>
    4bd8:      	lsr	w4, w4, #0
    4bdc:      	add	x16, sp, #0x10
    4be0:      	ldr	w1, [x16, #0x4]
    4be4:      	add	x16, sp, #0x10
    4be8:      	ldr	w2, [x16, #0x8]
    4bec:      	lsr	w1, w1, #0
    4bf0:      	add	x16, sp, #0x10
    4bf4:      	ldr	w3, [x16, #0xc]
    4bf8:      	lsr	w2, w2, #0
    4bfc:      	lsr	w3, w3, #0
    4c00:      	add	x8, sp, #0x40
    4c04:      	fmov	s31, w1
    4c08:      	mov	w1, w4
    4c0c:      	mov	w4, w3
    4c10:      	mov	w3, w2
    4c14:      	fmov	w2, s31
    4c18:      	bl	0x4c18 <_stogir.switch.validate+0x278>
		0000000000004c18:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    4c1c:      	add	x16, sp, #0x40
    4c20:      	ldr	x1, [x16]
    4c24:      	add	x16, sp, #0x40
    4c28:      	ldr	x0, [x16, #0x8]
    4c2c:      	add	x16, sp, #0x40
    4c30:      	ldr	x2, [x16, #0x10]
    4c34:      	b	0x4b3c <_stogir.switch.validate+0x19c>
    4c38:      	mov	x1, #0x3                ; =3
    4c3c:      	sxtw	x2, w2
    4c40:      	lsr	w1, w1, #0
    4c44:      	sxtw	x1, w1
    4c48:      	cmp	x2, x1
    4c4c:      	b.ne	0x4cb4 <_stogir.switch.validate+0x314>
    4c50:      	uxtb	w16, w3
    4c54:      	cmp	w16, wzr
    4c58:      	b.eq	0x4cbc <_stogir.switch.validate+0x31c>
    4c5c:      	add	x16, sp, #0x10
    4c60:      	ldr	w1, [x16, #0x4]
    4c64:      	add	x16, sp, #0x10
    4c68:      	ldr	w2, [x16, #0x8]
    4c6c:      	lsr	w1, w1, #0
    4c70:      	lsr	w2, w2, #0
    4c74:      	mov	x19, x8
    4c78:      	add	x8, sp, #0x20
    4c7c:      	bl	0x4c7c <_stogir.switch.validate+0x2dc>
		0000000000004c7c:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    4c80:      	add	x16, sp, #0x20
    4c84:      	ldr	x1, [x16]
    4c88:      	add	x16, sp, #0x20
    4c8c:      	ldr	x0, [x16, #0x8]
    4c90:      	add	x16, sp, #0x20
    4c94:      	ldr	x2, [x16, #0x10]
    4c98:      	b	0x4c34 <_stogir.switch.validate+0x294>
    4c9c:      	brk	#0
    4ca0:      	b	0x4c9c <_stogir.switch.validate+0x2fc>
    4ca4:      	mov	x19, x8
    4ca8:      	b	0x4b28 <_stogir.switch.validate+0x188>
    4cac:      	mov	x19, x8
    4cb0:      	b	0x4b28 <_stogir.switch.validate+0x188>
    4cb4:      	mov	x19, x8
    4cb8:      	b	0x4b28 <_stogir.switch.validate+0x188>
    4cbc:      	mov	x19, x8
    4cc0:      	b	0x4bd8 <_stogir.switch.validate+0x238>

0000000000004cc4 <_stogir.stack.validate>:
    4cc4:      	sub	sp, sp, #0x90
    4cc8:      	str	x29, [sp]
    4ccc:      	str	x30, [sp, #0x8]
    4cd0:      	mov	x29, sp
    4cd4:      	str	x19, [sp, #0x60]
    4cd8:      	str	x20, [sp, #0x68]
    4cdc:      	str	x21, [sp, #0x70]
    4ce0:      	str	x22, [sp, #0x78]
    4ce4:      	str	x23, [sp, #0x80]
    4ce8:      	sxtw	x1, w1
    4cec:      	lsl	x2, x1, #2
    4cf0:      	cmp	x1, #0x0
    4cf4:      	cset	w3, gt
    4cf8:      	movz	x16, #0x0, lsl #48
    4cfc:      	sub	x4, x16, x1
    4d00:      	cmp	x1, #0x0
    4d04:      	cset	w5, lt
    4d08:      	sub	x6, x4, #0x1
    4d0c:      	lsl	x7, x6, #2
    4d10:      	uxtb	w16, w3
    4d14:      	cmp	w16, wzr
    4d18:      	b.eq	0x4d58 <_stogir.stack.validate+0x94>
    4d1c:      	ldr	x9, [x0, #0x8]
    4d20:      	cmp	x1, x9
    4d24:      	b.ge	0x4dd4 <_stogir.stack.validate+0x110>
    4d28:      	add	x9, x0, #0x78
    4d2c:      	ldr	x9, [x9, #0x8]
    4d30:      	cmp	x1, x9
    4d34:      	b.ge	0x4f1c <_stogir.stack.validate+0x258>
    4d38:      	ldr	x9, [x0, #0x78]
    4d3c:      	add	x9, x2, x9
    4d40:      	ldr	w9, [x9]
    4d44:      	sxtw	x9, w9
    4d48:      	cmp	x9, #0x0
    4d4c:      	cset	w9, ge
    4d50:      	ubfx	x9, x9, #0, #8
    4d54:      	b	0x4f20 <_stogir.stack.validate+0x25c>
    4d58:      	uxtb	w16, w5
    4d5c:      	cmp	w16, wzr
    4d60:      	b.eq	0x4ddc <_stogir.stack.validate+0x118>
    4d64:      	add	x9, x0, #0x28
    4d68:      	add	x10, x0, #0x50
    4d6c:      	ldr	x9, [x9, #0x8]
    4d70:      	ldr	x10, [x10, #0x8]
    4d74:      	cmp	x9, x10
    4d78:      	b.ne	0x4da4 <_stogir.stack.validate+0xe0>
    4d7c:      	cmp	x4, x9
    4d80:      	b.gt	0x4f24 <_stogir.stack.validate+0x260>
    4d84:      	ldr	x9, [x0, #0x50]
    4d88:      	add	x9, x7, x9
    4d8c:      	ldr	w9, [x9]
    4d90:      	sxtw	x9, w9
    4d94:      	cmp	x9, #0x0
    4d98:      	cset	w9, gt
    4d9c:      	ubfx	x9, x9, #0, #8
    4da0:      	b	0x4f28 <_stogir.stack.validate+0x264>
    4da4:      	movz	x9, #0x0, lsl #48
    4da8:      	b	0x4de0 <_stogir.stack.validate+0x11c>
    4dac:      	uxtb	w16, w12
    4db0:      	cmp	w16, wzr
    4db4:      	b.eq	0x4f48 <_stogir.stack.validate+0x284>
    4db8:      	mov	x22, x8
    4dbc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004dbc:  ARM64_RELOC_PAGE21	l_stogir.384
    4dc0:      	ldr	x16, [x16]
		0000000000004dc0:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    4dc4:      	orr	x0, x16, xzr
    4dc8:      	mov	x1, #0x1                ; =1
    4dcc:      	mov	x2, #0x19               ; =25
    4dd0:      	b	0x4e7c <_stogir.stack.validate+0x1b8>
    4dd4:      	movz	x9, #0x0, lsl #48
    4dd8:      	b	0x4de0 <_stogir.stack.validate+0x11c>
    4ddc:      	movz	x9, #0x0, lsl #48
    4de0:      	lsl	x10, x1, #4
    4de4:      	lsl	x6, x6, #4
    4de8:      	cmp	x9, #0x0
    4dec:      	b.eq	0x4e28 <_stogir.stack.validate+0x164>
    4df0:      	uxtb	w16, w3
    4df4:      	cmp	w16, wzr
    4df8:      	b.eq	0x4e10 <_stogir.stack.validate+0x14c>
    4dfc:      	ldr	x9, [x0]
    4e00:      	add	x9, x10, x9
    4e04:      	ldr	x11, [x9]
    4e08:      	ldr	x9, [x9, #0x8]
    4e0c:      	b	0x4e20 <_stogir.stack.validate+0x15c>
    4e10:      	ldr	x9, [x0, #0x28]
    4e14:      	add	x9, x6, x9
    4e18:      	ldr	x11, [x9]
    4e1c:      	ldr	x9, [x9, #0x8]
    4e20:      	mov	x12, #0x1               ; =1
    4e24:      	b	0x4e34 <_stogir.stack.validate+0x170>
    4e28:      	movz	x12, #0x0, lsl #48
    4e2c:      	movz	x11, #0x0, lsl #48
    4e30:      	movz	x9, #0x0, lsl #48
    4e34:      	lsr	w12, w12, #0
    4e38:      	lsr	x16, x12, #0
    4e3c:      	cmp	x16, #0x1
    4e40:      	b.eq	0x4e5c <_stogir.stack.validate+0x198>
    4e44:      	b.lo	0x4e4c <_stogir.stack.validate+0x188>
    4e48:      	b	0x4e60 <_stogir.stack.validate+0x19c>
    4e4c:      	cmp	x16, #0x0
    4e50:      	b.eq	0x4e58 <_stogir.stack.validate+0x194>
    4e54:      	b	0x4e60 <_stogir.stack.validate+0x19c>
    4e58:      	b	0x4e64 <_stogir.stack.validate+0x1a0>
    4e5c:      	b	0x4eac <_stogir.stack.validate+0x1e8>
    4e60:      	b	0x5294 <_stogir.stack.validate+0x5d0>
    4e64:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004e64:  ARM64_RELOC_PAGE21	l_stogir.385
    4e68:      	ldr	x16, [x16]
		0000000000004e68:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    4e6c:      	orr	x0, x16, xzr
    4e70:      	mov	x22, x8
    4e74:      	mov	x1, #0x1                ; =1
    4e78:      	mov	x2, #0x19               ; =25
    4e7c:      	str	x1, [x22]
    4e80:      	str	x0, [x22, #0x8]
    4e84:      	str	x2, [x22, #0x10]
    4e88:      	ldr	x19, [sp, #0x60]
    4e8c:      	ldr	x20, [sp, #0x68]
    4e90:      	ldr	x21, [sp, #0x70]
    4e94:      	ldr	x22, [sp, #0x78]
    4e98:      	ldr	x23, [sp, #0x80]
    4e9c:      	ldr	x29, [sp]
    4ea0:      	ldr	x30, [sp, #0x8]
    4ea4:      	add	sp, sp, #0x90
    4ea8:      	ret
    4eac:      	cmp	x1, #0x0
    4eb0:      	cset	w12, le
    4eb4:      	uxtb	w19, w11
    4eb8:      	add	x16, sp, #0x10
    4ebc:      	str	x11, [x16]
    4ec0:      	orr	x11, x19, xzr
    4ec4:      	add	x16, sp, #0x10
    4ec8:      	str	x9, [x16, #0x8]
    4ecc:      	cmp	x11, #0x42
    4ed0:      	b.ne	0x4dac <_stogir.stack.validate+0xe8>
    4ed4:      	uxtb	w16, w3
    4ed8:      	cmp	w16, wzr
    4edc:      	b.eq	0x4f94 <_stogir.stack.validate+0x2d0>
    4ee0:      	ldr	x4, [x0, #0x8]
    4ee4:      	cmp	x1, x4
    4ee8:      	b.ge	0x4fe0 <_stogir.stack.validate+0x31c>
    4eec:      	add	x4, x0, #0x78
    4ef0:      	ldr	x4, [x4, #0x8]
    4ef4:      	cmp	x1, x4
    4ef8:      	b.ge	0x50cc <_stogir.stack.validate+0x408>
    4efc:      	ldr	x1, [x0, #0x78]
    4f00:      	add	x1, x2, x1
    4f04:      	ldr	w1, [x1]
    4f08:      	sxtw	x1, w1
    4f0c:      	cmp	x1, #0x0
    4f10:      	cset	w1, ge
    4f14:      	ubfx	x1, x1, #0, #8
    4f18:      	b	0x50d0 <_stogir.stack.validate+0x40c>
    4f1c:      	movz	x9, #0x0, lsl #48
    4f20:      	b	0x4dd8 <_stogir.stack.validate+0x114>
    4f24:      	movz	x9, #0x0, lsl #48
    4f28:      	b	0x4da8 <_stogir.stack.validate+0xe4>
    4f2c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x11c>
		0000000000004f2c:  ARM64_RELOC_PAGE21	l_stogir.386
    4f30:      	ldr	x16, [x16]
		0000000000004f30:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    4f34:      	orr	x0, x16, xzr
    4f38:      	mov	x1, #0x1                ; =1
    4f3c:      	mov	x2, #0x1e               ; =30
    4f40:      	mov	x22, x8
    4f44:      	b	0x4dd0 <_stogir.stack.validate+0x10c>
    4f48:      	cmp	x11, #0x51
    4f4c:      	cset	w1, eq
    4f50:      	cmp	x11, #0x53
    4f54:      	cset	w20, eq
    4f58:      	cmp	x11, #0x54
    4f5c:      	cset	w21, eq
    4f60:      	uxtb	w16, w1
    4f64:      	cmp	w16, wzr
    4f68:      	b.ne	0x50d4 <_stogir.stack.validate+0x410>
    4f6c:      	cmp	x11, #0x52
    4f70:      	b.eq	0x50d4 <_stogir.stack.validate+0x410>
    4f74:      	uxtb	w16, w20
    4f78:      	cmp	w16, wzr
    4f7c:      	b.ne	0x50d4 <_stogir.stack.validate+0x410>
    4f80:      	uxtb	w16, w21
    4f84:      	cmp	w16, wzr
    4f88:      	b.ne	0x50d4 <_stogir.stack.validate+0x410>
    4f8c:      	mov	x22, x8
    4f90:      	b	0x4dbc <_stogir.stack.validate+0xf8>
    4f94:      	uxtb	w16, w5
    4f98:      	cmp	w16, wzr
    4f9c:      	b.eq	0x4fe8 <_stogir.stack.validate+0x324>
    4fa0:      	add	x1, x0, #0x28
    4fa4:      	add	x5, x0, #0x50
    4fa8:      	ldr	x1, [x1, #0x8]
    4fac:      	ldr	x5, [x5, #0x8]
    4fb0:      	cmp	x1, x5
    4fb4:      	b.ne	0x50c4 <_stogir.stack.validate+0x400>
    4fb8:      	cmp	x4, x1
    4fbc:      	b.gt	0x5230 <_stogir.stack.validate+0x56c>
    4fc0:      	ldr	x1, [x0, #0x50]
    4fc4:      	add	x1, x7, x1
    4fc8:      	ldr	w1, [x1]
    4fcc:      	sxtw	x1, w1
    4fd0:      	cmp	x1, #0x0
    4fd4:      	cset	w1, gt
    4fd8:      	ubfx	x1, x1, #0, #8
    4fdc:      	b	0x5234 <_stogir.stack.validate+0x570>
    4fe0:      	movz	x1, #0x0, lsl #48
    4fe4:      	b	0x4fec <_stogir.stack.validate+0x328>
    4fe8:      	movz	x1, #0x0, lsl #48
    4fec:      	cmp	x1, #0x0
    4ff0:      	b.eq	0x5024 <_stogir.stack.validate+0x360>
    4ff4:      	uxtb	w16, w3
    4ff8:      	cmp	w16, wzr
    4ffc:      	b.eq	0x5010 <_stogir.stack.validate+0x34c>
    5000:      	ldr	x1, [x0]
    5004:      	add	x1, x10, x1
    5008:      	ldr	x1, [x1]
    500c:      	b	0x501c <_stogir.stack.validate+0x358>
    5010:      	ldr	x1, [x0, #0x28]
    5014:      	add	x1, x6, x1
    5018:      	ldr	x1, [x1]
    501c:      	mov	x3, #0x1                ; =1
    5020:      	b	0x502c <_stogir.stack.validate+0x368>
    5024:      	movz	x3, #0x0, lsl #48
    5028:      	movz	x1, #0x0, lsl #48
    502c:      	lsr	w3, w3, #0
    5030:      	lsr	x16, x3, #0
    5034:      	cmp	x16, #0x1
    5038:      	b.eq	0x5054 <_stogir.stack.validate+0x390>
    503c:      	b.lo	0x5044 <_stogir.stack.validate+0x380>
    5040:      	b	0x5058 <_stogir.stack.validate+0x394>
    5044:      	cmp	x16, #0x0
    5048:      	b.eq	0x5050 <_stogir.stack.validate+0x38c>
    504c:      	b	0x5058 <_stogir.stack.validate+0x394>
    5050:      	b	0x505c <_stogir.stack.validate+0x398>
    5054:      	b	0x5074 <_stogir.stack.validate+0x3b0>
    5058:      	b	0x529c <_stogir.stack.validate+0x5d8>
    505c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		000000000000505c:  ARM64_RELOC_PAGE21	l_stogir.387
    5060:      	ldr	x16, [x16]
		0000000000005060:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    5064:      	orr	x0, x16, xzr
    5068:      	mov	x1, #0x1                ; =1
    506c:      	mov	x2, #0x21               ; =33
    5070:      	b	0x4f40 <_stogir.stack.validate+0x27c>
    5074:      	uxtb	w16, w12
    5078:      	cmp	w16, wzr
    507c:      	b.ne	0x4f2c <_stogir.stack.validate+0x268>
    5080:      	uxtb	w3, w1
    5084:      	cmp	x3, #0x42
    5088:      	b.ne	0x4f2c <_stogir.stack.validate+0x268>
    508c:      	lsr	w1, w1, #0
    5090:      	ubfx	x1, x1, #8, #8
    5094:      	cmp	x1, #0x6
    5098:      	b.ne	0x4f2c <_stogir.stack.validate+0x268>
    509c:      	ldr	x0, [x0, #0x78]
    50a0:      	add	x0, x2, x0
    50a4:      	ldr	w0, [x0]
    50a8:      	sxtw	x0, w0
    50ac:      	cmp	x0, #0x0
    50b0:      	b.ne	0x4f2c <_stogir.stack.validate+0x268>
    50b4:      	movz	x1, #0x0, lsl #48
    50b8:      	mov	x0, #0x8                ; =8
    50bc:      	movz	x2, #0x0, lsl #48
    50c0:      	b	0x4f40 <_stogir.stack.validate+0x27c>
    50c4:      	movz	x1, #0x0, lsl #48
    50c8:      	b	0x4fec <_stogir.stack.validate+0x328>
    50cc:      	movz	x1, #0x0, lsl #48
    50d0:      	b	0x4fe4 <_stogir.stack.validate+0x320>
    50d4:      	ldr	x3, [x0, #0x78]
    50d8:      	add	x2, x2, x3
    50dc:      	ldr	w2, [x2]
    50e0:      	uxtb	w16, w1
    50e4:      	cmp	w16, wzr
    50e8:      	b.eq	0x5154 <_stogir.stack.validate+0x490>
    50ec:      	mov	x1, #0x3                ; =3
    50f0:      	b	0x5168 <_stogir.stack.validate+0x4a4>
    50f4:      	add	x16, sp, #0x10
    50f8:      	ldr	w0, [x16]
    50fc:      	add	x16, sp, #0x10
    5100:      	ldr	w1, [x16, #0x4]
    5104:      	add	x16, sp, #0x10
    5108:      	ldr	w2, [x16, #0x8]
    510c:      	lsr	w1, w1, #0
    5110:      	ubfx	x0, x0, #8, #8
    5114:      	lsr	w2, w2, #0
    5118:      	lsr	w0, w0, #0
    511c:      	add	x8, sp, #0x20
    5120:      	mov	w3, w1
    5124:      	mov	w1, w19
    5128:      	mov	w4, w2
    512c:      	mov	w2, w0
    5130:      	mov	x0, x23
    5134:      	bl	0x5134 <_stogir.stack.validate+0x470>
		0000000000005134:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    5138:      	add	x16, sp, #0x20
    513c:      	ldr	x1, [x16]
    5140:      	add	x16, sp, #0x20
    5144:      	ldr	x0, [x16, #0x8]
    5148:      	add	x16, sp, #0x20
    514c:      	ldr	x2, [x16, #0x10]
    5150:      	b	0x4dd0 <_stogir.stack.validate+0x10c>
    5154:      	uxtb	w16, w20
    5158:      	cmp	w16, wzr
    515c:      	mov	x16, #0x1               ; =1
    5160:      	mov	x17, #0x2               ; =2
    5164:      	csel	x1, x16, x17, ne
    5168:      	sxtw	x2, w2
    516c:      	lsr	w1, w1, #0
    5170:      	sxtw	x1, w1
    5174:      	cmp	x2, x1
    5178:      	b.ne	0x52a4 <_stogir.stack.validate+0x5e0>
    517c:      	add	x16, sp, #0x10
    5180:      	ldr	w1, [x16]
    5184:      	orr	x2, x1, xzr
    5188:      	ubfx	x2, x2, #16, #16
    518c:      	and	x2, x2, #0x8000
    5190:      	uxth	w2, w2
    5194:      	cmp	x2, #0x0
    5198:      	b.ne	0x5238 <_stogir.stack.validate+0x574>
    519c:      	mov	x22, x8
    51a0:      	mov	x23, x0
    51a4:      	lsr	w19, w19, #0
    51a8:      	uxtb	w16, w20
    51ac:      	cmp	w16, wzr
    51b0:      	b.ne	0x50f4 <_stogir.stack.validate+0x430>
    51b4:      	uxtb	w16, w21
    51b8:      	cmp	w16, wzr
    51bc:      	b.ne	0x50f4 <_stogir.stack.validate+0x430>
    51c0:      	add	x16, sp, #0x10
    51c4:      	ldr	w0, [x16]
    51c8:      	add	x16, sp, #0x10
    51cc:      	ldr	w1, [x16, #0x4]
    51d0:      	add	x16, sp, #0x10
    51d4:      	ldr	w2, [x16, #0x8]
    51d8:      	lsr	w1, w1, #0
    51dc:      	ubfx	x0, x0, #8, #8
    51e0:      	add	x16, sp, #0x10
    51e4:      	ldr	w3, [x16, #0xc]
    51e8:      	lsr	w2, w2, #0
    51ec:      	lsr	w3, w3, #0
    51f0:      	lsr	w0, w0, #0
    51f4:      	add	x8, sp, #0x40
    51f8:      	mov	w4, w2
    51fc:      	mov	w2, w0
    5200:      	mov	x0, x23
    5204:      	mov	w5, w3
    5208:      	mov	w3, w1
    520c:      	mov	w1, w19
    5210:      	bl	0x5210 <_stogir.stack.validate+0x54c>
		0000000000005210:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    5214:      	add	x16, sp, #0x40
    5218:      	ldr	x1, [x16]
    521c:      	add	x16, sp, #0x40
    5220:      	ldr	x0, [x16, #0x8]
    5224:      	add	x16, sp, #0x40
    5228:      	ldr	x2, [x16, #0x10]
    522c:      	b	0x5150 <_stogir.stack.validate+0x48c>
    5230:      	movz	x1, #0x0, lsl #48
    5234:      	b	0x50c8 <_stogir.stack.validate+0x404>
    5238:      	uxtb	w2, w1
    523c:      	cmp	x2, #0x51
    5240:      	b.ne	0x52ac <_stogir.stack.validate+0x5e8>
    5244:      	ubfx	x1, x1, #16, #16
    5248:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    524c:      	b.ne	0x52b4 <_stogir.stack.validate+0x5f0>
    5250:      	add	x16, sp, #0x10
    5254:      	ldr	w1, [x16, #0x4]
    5258:      	add	x16, sp, #0x10
    525c:      	ldr	w2, [x16, #0x8]
    5260:      	lsr	w1, w1, #0
    5264:      	lsr	w2, w2, #0
    5268:      	mov	x22, x8
    526c:      	mov	x23, x0
    5270:      	bl	0x5270 <_stogir.stack.validate+0x5ac>
		0000000000005270:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    5274:      	cmp	x0, #0x0
    5278:      	b.ne	0x51a4 <_stogir.stack.validate+0x4e0>
    527c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		000000000000527c:  ARM64_RELOC_PAGE21	l_stogir.388
    5280:      	ldr	x16, [x16]
		0000000000005280:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    5284:      	orr	x0, x16, xzr
    5288:      	mov	x1, #0x1                ; =1
    528c:      	mov	x2, #0x26               ; =38
    5290:      	b	0x5150 <_stogir.stack.validate+0x48c>
    5294:      	brk	#0
    5298:      	b	0x5294 <_stogir.stack.validate+0x5d0>
    529c:      	brk	#0
    52a0:      	b	0x529c <_stogir.stack.validate+0x5d8>
    52a4:      	mov	x22, x8
    52a8:      	b	0x4dbc <_stogir.stack.validate+0xf8>
    52ac:      	mov	x22, x8
    52b0:      	b	0x527c <_stogir.stack.validate+0x5b8>
    52b4:      	mov	x22, x8
    52b8:      	b	0x527c <_stogir.stack.validate+0x5b8>

00000000000052bc <_stogir.locals.validate>:
    52bc:      	sub	sp, sp, #0xb0
    52c0:      	str	x29, [sp]
    52c4:      	str	x30, [sp, #0x8]
    52c8:      	mov	x29, sp
    52cc:      	str	x19, [sp, #0x70]
    52d0:      	str	x20, [sp, #0x78]
    52d4:      	str	x21, [sp, #0x80]
    52d8:      	str	x22, [sp, #0x88]
    52dc:      	str	x23, [sp, #0x90]
    52e0:      	str	x24, [sp, #0x98]
    52e4:      	str	x25, [sp, #0xa0]
    52e8:      	sxtw	x1, w1
    52ec:      	lsl	x3, x1, #2
    52f0:      	cmp	x1, #0x0
    52f4:      	cset	w4, gt
    52f8:      	movz	x16, #0x0, lsl #48
    52fc:      	sub	x5, x16, x1
    5300:      	sub	x6, x5, #0x1
    5304:      	uxtb	w16, w4
    5308:      	cmp	w16, wzr
    530c:      	b.eq	0x534c <_stogir.locals.validate+0x90>
    5310:      	ldr	x5, [x0, #0x8]
    5314:      	cmp	x1, x5
    5318:      	b.ge	0x53e4 <_stogir.locals.validate+0x128>
    531c:      	add	x5, x0, #0x78
    5320:      	ldr	x5, [x5, #0x8]
    5324:      	cmp	x1, x5
    5328:      	b.ge	0x54e0 <_stogir.locals.validate+0x224>
    532c:      	ldr	x5, [x0, #0x78]
    5330:      	add	x5, x3, x5
    5334:      	ldr	w5, [x5]
    5338:      	sxtw	x5, w5
    533c:      	cmp	x5, #0x0
    5340:      	cset	w5, ge
    5344:      	ubfx	x5, x5, #0, #8
    5348:      	b	0x54e4 <_stogir.locals.validate+0x228>
    534c:      	cmp	x1, #0x0
    5350:      	b.ge	0x53ec <_stogir.locals.validate+0x130>
    5354:      	add	x7, x0, #0x28
    5358:      	add	x9, x0, #0x50
    535c:      	ldr	x7, [x7, #0x8]
    5360:      	ldr	x9, [x9, #0x8]
    5364:      	cmp	x7, x9
    5368:      	b.ne	0x5394 <_stogir.locals.validate+0xd8>
    536c:      	cmp	x5, x7
    5370:      	b.gt	0x5564 <_stogir.locals.validate+0x2a8>
    5374:      	ldr	x5, [x0, #0x50]
    5378:      	add	x5, x5, x6, lsl #2
    537c:      	ldr	w5, [x5]
    5380:      	sxtw	x5, w5
    5384:      	cmp	x5, #0x0
    5388:      	cset	w5, gt
    538c:      	ubfx	x5, x5, #0, #8
    5390:      	b	0x5568 <_stogir.locals.validate+0x2ac>
    5394:      	movz	x5, #0x0, lsl #48
    5398:      	b	0x53f0 <_stogir.locals.validate+0x134>
    539c:      	cmp	x4, #0x0
    53a0:      	cset	w4, ne
    53a4:      	uxtb	w16, w4
    53a8:      	cmp	w16, wzr
    53ac:      	mov	x16, #0x2               ; =2
    53b0:      	mov	x17, #0x3               ; =3
    53b4:      	csel	x4, x16, x17, ne
    53b8:      	lsr	w4, w4, #0
    53bc:      	sxtw	x4, w4
    53c0:      	cmp	x1, #0x0
    53c4:      	b.gt	0x54e8 <_stogir.locals.validate+0x22c>
    53c8:      	mov	x23, x8
    53cc:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		00000000000053cc:  ARM64_RELOC_PAGE21	l_stogir.389
    53d0:      	ldr	x16, [x16]
		00000000000053d0:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    53d4:      	orr	x0, x16, xzr
    53d8:      	mov	x2, #0x1                ; =1
    53dc:      	mov	x1, #0x17               ; =23
    53e0:      	b	0x5484 <_stogir.locals.validate+0x1c8>
    53e4:      	movz	x5, #0x0, lsl #48
    53e8:      	b	0x53f0 <_stogir.locals.validate+0x134>
    53ec:      	movz	x5, #0x0, lsl #48
    53f0:      	cmp	x5, #0x0
    53f4:      	b.eq	0x5430 <_stogir.locals.validate+0x174>
    53f8:      	uxtb	w16, w4
    53fc:      	cmp	w16, wzr
    5400:      	b.eq	0x5418 <_stogir.locals.validate+0x15c>
    5404:      	ldr	x4, [x0]
    5408:      	add	x4, x4, x1, lsl #4
    540c:      	ldr	x5, [x4]
    5410:      	ldr	x4, [x4, #0x8]
    5414:      	b	0x5428 <_stogir.locals.validate+0x16c>
    5418:      	ldr	x4, [x0, #0x28]
    541c:      	add	x4, x4, x6, lsl #4
    5420:      	ldr	x5, [x4]
    5424:      	ldr	x4, [x4, #0x8]
    5428:      	mov	x6, #0x1                ; =1
    542c:      	b	0x543c <_stogir.locals.validate+0x180>
    5430:      	movz	x6, #0x0, lsl #48
    5434:      	movz	x5, #0x0, lsl #48
    5438:      	movz	x4, #0x0, lsl #48
    543c:      	lsr	w6, w6, #0
    5440:      	lsr	x16, x6, #0
    5444:      	cmp	x16, #0x1
    5448:      	b.eq	0x5464 <_stogir.locals.validate+0x1a8>
    544c:      	b.lo	0x5454 <_stogir.locals.validate+0x198>
    5450:      	b	0x5468 <_stogir.locals.validate+0x1ac>
    5454:      	cmp	x16, #0x0
    5458:      	b.eq	0x5460 <_stogir.locals.validate+0x1a4>
    545c:      	b	0x5468 <_stogir.locals.validate+0x1ac>
    5460:      	b	0x546c <_stogir.locals.validate+0x1b0>
    5464:      	b	0x54bc <_stogir.locals.validate+0x200>
    5468:      	b	0x569c <_stogir.locals.validate+0x3e0>
    546c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		000000000000546c:  ARM64_RELOC_PAGE21	l_stogir.390
    5470:      	ldr	x16, [x16]
		0000000000005470:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    5474:      	orr	x0, x16, xzr
    5478:      	mov	x23, x8
    547c:      	mov	x2, #0x1                ; =1
    5480:      	mov	x1, #0x17               ; =23
    5484:      	str	x2, [x23]
    5488:      	str	x0, [x23, #0x8]
    548c:      	str	x1, [x23, #0x10]
    5490:      	ldr	x19, [sp, #0x70]
    5494:      	ldr	x20, [sp, #0x78]
    5498:      	ldr	x21, [sp, #0x80]
    549c:      	ldr	x22, [sp, #0x88]
    54a0:      	ldr	x23, [sp, #0x90]
    54a4:      	ldr	x24, [sp, #0x98]
    54a8:      	ldr	x25, [sp, #0xa0]
    54ac:      	ldr	x29, [sp]
    54b0:      	ldr	x30, [sp, #0x8]
    54b4:      	add	sp, sp, #0xb0
    54b8:      	ret
    54bc:      	uxtb	w6, w5
    54c0:      	add	x16, sp, #0x10
    54c4:      	str	x5, [x16]
    54c8:      	add	x16, sp, #0x10
    54cc:      	str	x4, [x16, #0x8]
    54d0:      	cmp	x6, #0x55
    54d4:      	b.ne	0x5548 <_stogir.locals.validate+0x28c>
    54d8:      	mov	x4, #0x1                ; =1
    54dc:      	b	0x5554 <_stogir.locals.validate+0x298>
    54e0:      	movz	x5, #0x0, lsl #48
    54e4:      	b	0x53e8 <_stogir.locals.validate+0x12c>
    54e8:      	cmp	x6, #0x48
    54ec:      	cset	w21, eq
    54f0:      	uxtb	w16, w20
    54f4:      	cmp	w16, wzr
    54f8:      	b.ne	0x556c <_stogir.locals.validate+0x2b0>
    54fc:      	uxtb	w16, w21
    5500:      	cmp	w16, wzr
    5504:      	b.ne	0x556c <_stogir.locals.validate+0x2b0>
    5508:      	cmp	x6, #0x55
    550c:      	b.lt	0x5a00 <_stogir.locals.validate+0x744>
    5510:      	cmp	x6, #0x58
    5514:      	b.le	0x556c <_stogir.locals.validate+0x2b0>
    5518:      	mov	x23, x8
    551c:      	b	0x53cc <_stogir.locals.validate+0x110>
    5520:      	cmp	x6, #0x58
    5524:      	cset	w5, eq
    5528:      	ubfx	x19, x5, #0, #8
    552c:      	cmp	x6, #0x41
    5530:      	cset	w20, eq
    5534:      	uxtb	w16, w20
    5538:      	cmp	w16, wzr
    553c:      	b.eq	0x539c <_stogir.locals.validate+0xe0>
    5540:      	mov	x4, #0x1                ; =1
    5544:      	b	0x53c0 <_stogir.locals.validate+0x104>
    5548:      	cmp	x6, #0x56
    554c:      	cset	w4, eq
    5550:      	ubfx	x4, x4, #0, #8
    5554:      	cmp	x6, #0x57
    5558:      	b.ne	0x5520 <_stogir.locals.validate+0x264>
    555c:      	mov	x19, #0x1               ; =1
    5560:      	b	0x552c <_stogir.locals.validate+0x270>
    5564:      	movz	x5, #0x0, lsl #48
    5568:      	b	0x5398 <_stogir.locals.validate+0xdc>
    556c:      	lsr	w4, w4, #0
    5570:      	sxtw	x4, w4
    5574:      	ldr	x5, [x0, #0x78]
    5578:      	add	x3, x3, x5
    557c:      	ldr	w3, [x3]
    5580:      	sxtw	x3, w3
    5584:      	cmp	x3, x4
    5588:      	b.ne	0x5a08 <_stogir.locals.validate+0x74c>
    558c:      	uxtb	w16, w20
    5590:      	cmp	w16, wzr
    5594:      	b.ne	0x55b4 <_stogir.locals.validate+0x2f8>
    5598:      	uxtb	w16, w21
    559c:      	cmp	w16, wzr
    55a0:      	b.ne	0x55b4 <_stogir.locals.validate+0x2f8>
    55a4:      	add	x16, sp, #0x10
    55a8:      	ldr	w1, [x16, #0x8]
    55ac:      	sxtw	x1, w1
    55b0:      	b	0x55cc <_stogir.locals.validate+0x310>
    55b4:      	uxtb	w16, w21
    55b8:      	cmp	w16, wzr
    55bc:      	b.ne	0x55cc <_stogir.locals.validate+0x310>
    55c0:      	add	x16, sp, #0x10
    55c4:      	ldr	w1, [x16, #0x4]
    55c8:      	sxtw	x1, w1
    55cc:      	add	x16, sp, #0x20
    55d0:      	orr	x22, x16, xzr
    55d4:      	lsr	w2, w2, #0
    55d8:      	lsr	w1, w1, #0
    55dc:      	mov	x23, x8
    55e0:      	add	x8, sp, #0x20
    55e4:      	mov	x24, x0
    55e8:      	mov	w25, w2
    55ec:      	bl	0x55ec <_stogir.locals.validate+0x330>
		00000000000055ec:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    55f0:      	add	x16, sp, #0x20
    55f4:      	ldr	w0, [x16]
    55f8:      	lsr	x16, x0, #0
    55fc:      	cmp	x16, #0x1
    5600:      	b.eq	0x561c <_stogir.locals.validate+0x360>
    5604:      	b.lo	0x560c <_stogir.locals.validate+0x350>
    5608:      	b	0x5620 <_stogir.locals.validate+0x364>
    560c:      	cmp	x16, #0x0
    5610:      	b.eq	0x5618 <_stogir.locals.validate+0x35c>
    5614:      	b	0x5620 <_stogir.locals.validate+0x364>
    5618:      	b	0x563c <_stogir.locals.validate+0x380>
    561c:      	b	0x5624 <_stogir.locals.validate+0x368>
    5620:      	b	0x5874 <_stogir.locals.validate+0x5b8>
    5624:      	add	x1, x22, #0x8
    5628:      	add	x16, sp, #0x20
    562c:      	ldr	x0, [x16, #0x8]
    5630:      	ldr	x1, [x1, #0x8]
    5634:      	mov	x2, #0x1                ; =1
    5638:      	b	0x53e0 <_stogir.locals.validate+0x124>
    563c:      	add	x16, sp, #0x20
    5640:      	ldr	x22, [x16, #0x8]
    5644:      	uxtb	w16, w21
    5648:      	cmp	w16, wzr
    564c:      	b.eq	0x5668 <_stogir.locals.validate+0x3ac>
    5650:      	lsr	w22, w22, #0
    5654:      	sxtw	x22, w22
    5658:      	and	x0, x22, #0xffffffff
    565c:      	movz	x2, #0x0, lsl #48
    5660:      	movz	x1, #0x0, lsl #48
    5664:      	b	0x5638 <_stogir.locals.validate+0x37c>
    5668:      	uxtb	w16, w20
    566c:      	cmp	w16, wzr
    5670:      	b.eq	0x56bc <_stogir.locals.validate+0x400>
    5674:      	add	x16, sp, #0x10
    5678:      	ldr	w0, [x16]
    567c:      	ubfx	x0, x0, #8, #8
    5680:      	cmp	x0, #0x6
    5684:      	b.ne	0x56a4 <_stogir.locals.validate+0x3e8>
    5688:      	sxtw	x25, w25
    568c:      	and	x0, x25, #0xffffffff
    5690:      	movz	x2, #0x0, lsl #48
    5694:      	movz	x1, #0x0, lsl #48
    5698:      	b	0x56b8 <_stogir.locals.validate+0x3fc>
    569c:      	brk	#0
    56a0:      	b	0x569c <_stogir.locals.validate+0x3e0>
    56a4:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		00000000000056a4:  ARM64_RELOC_PAGE21	l_stogir.391
    56a8:      	ldr	x16, [x16]
		00000000000056a8:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    56ac:      	orr	x0, x16, xzr
    56b0:      	mov	x2, #0x1                ; =1
    56b4:      	mov	x1, #0x21               ; =33
    56b8:      	b	0x5664 <_stogir.locals.validate+0x3a8>
    56bc:      	add	x16, sp, #0x10
    56c0:      	ldr	w0, [x16, #0x4]
    56c4:      	sxtw	x0, w0
    56c8:      	cmp	x0, #0x0
    56cc:      	cset	w1, gt
    56d0:      	movz	x16, #0x0, lsl #48
    56d4:      	sub	x2, x16, x0
    56d8:      	sub	x3, x2, #0x1
    56dc:      	uxtb	w16, w1
    56e0:      	cmp	w16, wzr
    56e4:      	b.eq	0x57b8 <_stogir.locals.validate+0x4fc>
    56e8:      	ldr	x2, [x24, #0x8]
    56ec:      	cmp	x0, x2
    56f0:      	b.ge	0x57b0 <_stogir.locals.validate+0x4f4>
    56f4:      	add	x2, x24, #0x78
    56f8:      	ldr	x2, [x2, #0x8]
    56fc:      	cmp	x0, x2
    5700:      	b.ge	0x5864 <_stogir.locals.validate+0x5a8>
    5704:      	ldr	x2, [x24, #0x78]
    5708:      	add	x2, x2, x0, lsl #2
    570c:      	ldr	w2, [x2]
    5710:      	sxtw	x2, w2
    5714:      	cmp	x2, #0x0
    5718:      	cset	w2, ge
    571c:      	ubfx	x2, x2, #0, #8
    5720:      	b	0x5868 <_stogir.locals.validate+0x5ac>
    5724:      	movz	x1, #0x0, lsl #48
    5728:      	movz	x0, #0x0, lsl #48
    572c:      	lsr	w1, w1, #0
    5730:      	lsr	x16, x1, #0
    5734:      	cmp	x16, #0x1
    5738:      	b.eq	0x5754 <_stogir.locals.validate+0x498>
    573c:      	b.lo	0x5744 <_stogir.locals.validate+0x488>
    5740:      	b	0x5758 <_stogir.locals.validate+0x49c>
    5744:      	cmp	x16, #0x0
    5748:      	b.eq	0x5750 <_stogir.locals.validate+0x494>
    574c:      	b	0x5758 <_stogir.locals.validate+0x49c>
    5750:      	b	0x575c <_stogir.locals.validate+0x4a0>
    5754:      	b	0x5800 <_stogir.locals.validate+0x544>
    5758:      	b	0x59d4 <_stogir.locals.validate+0x718>
    575c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		000000000000575c:  ARM64_RELOC_PAGE21	l_stogir.392
    5760:      	ldr	x16, [x16]
		0000000000005760:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    5764:      	orr	x0, x16, xzr
    5768:      	mov	x2, #0x1                ; =1
    576c:      	mov	x1, #0x1c               ; =28
    5770:      	b	0x56b8 <_stogir.locals.validate+0x3fc>
    5774:      	ldr	x0, [x24, #0x28]
    5778:      	add	x0, x0, x3, lsl #4
    577c:      	ldr	x0, [x0]
    5780:      	mov	x1, #0x1                ; =1
    5784:      	b	0x572c <_stogir.locals.validate+0x470>
    5788:      	movz	x2, #0x0, lsl #48
    578c:      	cmp	x2, #0x0
    5790:      	b.eq	0x5724 <_stogir.locals.validate+0x468>
    5794:      	uxtb	w16, w1
    5798:      	cmp	w16, wzr
    579c:      	b.eq	0x5774 <_stogir.locals.validate+0x4b8>
    57a0:      	ldr	x1, [x24]
    57a4:      	add	x0, x1, x0, lsl #4
    57a8:      	ldr	x0, [x0]
    57ac:      	b	0x5780 <_stogir.locals.validate+0x4c4>
    57b0:      	movz	x2, #0x0, lsl #48
    57b4:      	b	0x578c <_stogir.locals.validate+0x4d0>
    57b8:      	cmp	x0, #0x0
    57bc:      	b.ge	0x5788 <_stogir.locals.validate+0x4cc>
    57c0:      	add	x4, x24, #0x28
    57c4:      	add	x5, x24, #0x50
    57c8:      	ldr	x4, [x4, #0x8]
    57cc:      	ldr	x5, [x5, #0x8]
    57d0:      	cmp	x4, x5
    57d4:      	b.ne	0x585c <_stogir.locals.validate+0x5a0>
    57d8:      	cmp	x2, x4
    57dc:      	b.gt	0x586c <_stogir.locals.validate+0x5b0>
    57e0:      	ldr	x2, [x24, #0x50]
    57e4:      	add	x2, x2, x3, lsl #2
    57e8:      	ldr	w2, [x2]
    57ec:      	sxtw	x2, w2
    57f0:      	cmp	x2, #0x0
    57f4:      	cset	w2, gt
    57f8:      	ubfx	x2, x2, #0, #8
    57fc:      	b	0x5870 <_stogir.locals.validate+0x5b4>
    5800:      	add	x16, sp, #0x10
    5804:      	ldr	w1, [x16, #0x4]
    5808:      	sxtw	x1, w1
    580c:      	cmp	x1, #0x0
    5810:      	b.le	0x5844 <_stogir.locals.validate+0x588>
    5814:      	uxtb	w0, w0
    5818:      	cmp	x0, #0x83
    581c:      	cset	w1, lt
    5820:      	uxtb	w16, w1
    5824:      	cmp	w16, wzr
    5828:      	b.eq	0x587c <_stogir.locals.validate+0x5c0>
    582c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		000000000000582c:  ARM64_RELOC_PAGE21	l_stogir.393
    5830:      	ldr	x16, [x16]
		0000000000005830:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    5834:      	orr	x2, x16, xzr
    5838:      	add	x2, x0, x2
    583c:      	ldrb	w2, [x2]
    5840:      	b	0x5880 <_stogir.locals.validate+0x5c4>
    5844:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		0000000000005844:  ARM64_RELOC_PAGE21	l_stogir.394
    5848:      	ldr	x16, [x16]
		0000000000005848:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    584c:      	orr	x0, x16, xzr
    5850:      	mov	x2, #0x1                ; =1
    5854:      	mov	x1, #0x1c               ; =28
    5858:      	b	0x5770 <_stogir.locals.validate+0x4b4>
    585c:      	movz	x2, #0x0, lsl #48
    5860:      	b	0x578c <_stogir.locals.validate+0x4d0>
    5864:      	movz	x2, #0x0, lsl #48
    5868:      	b	0x57b4 <_stogir.locals.validate+0x4f8>
    586c:      	movz	x2, #0x0, lsl #48
    5870:      	b	0x5860 <_stogir.locals.validate+0x5a4>
    5874:      	brk	#0
    5878:      	b	0x5874 <_stogir.locals.validate+0x5b8>
    587c:      	movz	x2, #0x0, lsl #48
    5880:      	uxtb	w2, w2
    5884:      	and	x2, x2, #0x1
    5888:      	uxtb	w2, w2
    588c:      	cmp	x2, #0x0
    5890:      	b.eq	0x5844 <_stogir.locals.validate+0x588>
    5894:      	uxtb	w16, w1
    5898:      	cmp	w16, wzr
    589c:      	b.eq	0x58b8 <_stogir.locals.validate+0x5fc>
    58a0:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		00000000000058a0:  ARM64_RELOC_PAGE21	l_stogir.393
    58a4:      	ldr	x16, [x16]
		00000000000058a4:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    58a8:      	orr	x1, x16, xzr
    58ac:      	add	x0, x0, x1
    58b0:      	ldrb	w0, [x0]
    58b4:      	b	0x58bc <_stogir.locals.validate+0x600>
    58b8:      	movz	x0, #0x0, lsl #48
    58bc:      	uxtb	w0, w0
    58c0:      	and	x0, x0, #0x4
    58c4:      	uxtb	w0, w0
    58c8:      	cmp	x0, #0x0
    58cc:      	cset	w0, eq
    58d0:      	uxtb	w16, w0
    58d4:      	cmp	w16, wzr
    58d8:      	cset	x0, eq
    58dc:      	cmp	x0, #0x0
    58e0:      	b.ne	0x5844 <_stogir.locals.validate+0x588>
    58e4:      	cmp	x19, #0x0
    58e8:      	b.eq	0x5980 <_stogir.locals.validate+0x6c4>
    58ec:      	add	x16, sp, #0x10
    58f0:      	ldr	w0, [x16, #0xc]
    58f4:      	lsr	w0, w0, #0
    58f8:      	add	x8, sp, #0x40
    58fc:      	mov	w1, w0
    5900:      	mov	x0, x24
    5904:      	bl	0x5904 <_stogir.locals.validate+0x648>
		0000000000005904:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    5908:      	add	x16, sp, #0x40
    590c:      	ldr	x0, [x16]
    5910:      	add	x16, sp, #0x40
    5914:      	ldr	x20, [x16, #0x8]
    5918:      	b	0x598c <_stogir.locals.validate+0x6d0>
    591c:      	lsr	w25, w25, #0
    5920:      	lsr	w0, w20, #0
    5924:      	ubfx	x0, x0, #8, #8
    5928:      	lsr	w0, w0, #0
    592c:      	mov	w1, w25
    5930:      	bl	0x5930 <_stogir.locals.validate+0x674>
		0000000000005930:  ARM64_RELOC_BRANCH26	_stogir.types.size
    5934:      	lsr	w0, w0, #0
    5938:      	sxtw	x0, w0
    593c:      	cmp	x0, #0x0
    5940:      	b.le	0x5968 <_stogir.locals.validate+0x6ac>
    5944:      	cmp	x0, x22
    5948:      	b.gt	0x5968 <_stogir.locals.validate+0x6ac>
    594c:      	cmp	x19, #0x0
    5950:      	b.eq	0x59dc <_stogir.locals.validate+0x720>
    5954:      	add	x16, sp, #0x10
    5958:      	ldr	w1, [x16]
    595c:      	ubfx	x1, x1, #8, #8
    5960:      	cmp	x1, #0x0
    5964:      	b.eq	0x59dc <_stogir.locals.validate+0x720>
    5968:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		0000000000005968:  ARM64_RELOC_PAGE21	l_stogir.395
    596c:      	ldr	x16, [x16]
		000000000000596c:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    5970:      	orr	x0, x16, xzr
    5974:      	mov	x2, #0x1                ; =1
    5978:      	mov	x1, #0x23               ; =35
    597c:      	b	0x5858 <_stogir.locals.validate+0x59c>
    5980:      	add	x16, sp, #0x10
    5984:      	ldr	x20, [x16]
    5988:      	mov	x0, #0x1                ; =1
    598c:      	lsr	w0, w0, #0
    5990:      	lsr	x16, x0, #0
    5994:      	cmp	x16, #0x1
    5998:      	b.eq	0x59b4 <_stogir.locals.validate+0x6f8>
    599c:      	b.lo	0x59a4 <_stogir.locals.validate+0x6e8>
    59a0:      	b	0x59b8 <_stogir.locals.validate+0x6fc>
    59a4:      	cmp	x16, #0x0
    59a8:      	b.eq	0x59b0 <_stogir.locals.validate+0x6f4>
    59ac:      	b	0x59b8 <_stogir.locals.validate+0x6fc>
    59b0:      	b	0x59bc <_stogir.locals.validate+0x700>
    59b4:      	b	0x591c <_stogir.locals.validate+0x660>
    59b8:      	b	0x59f8 <_stogir.locals.validate+0x73c>
    59bc:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		00000000000059bc:  ARM64_RELOC_PAGE21	l_stogir.396
    59c0:      	ldr	x16, [x16]
		00000000000059c0:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    59c4:      	orr	x0, x16, xzr
    59c8:      	mov	x2, #0x1                ; =1
    59cc:      	mov	x1, #0x19               ; =25
    59d0:      	b	0x597c <_stogir.locals.validate+0x6c0>
    59d4:      	brk	#0
    59d8:      	b	0x59d4 <_stogir.locals.validate+0x718>
    59dc:      	uxtb	w20, w20
    59e0:      	cmp	x20, #0x48
    59e4:      	b.eq	0x5968 <_stogir.locals.validate+0x6ac>
    59e8:      	and	x0, x0, #0xffffffff
    59ec:      	movz	x2, #0x0, lsl #48
    59f0:      	movz	x1, #0x0, lsl #48
    59f4:      	b	0x597c <_stogir.locals.validate+0x6c0>
    59f8:      	brk	#0
    59fc:      	b	0x59f8 <_stogir.locals.validate+0x73c>
    5a00:      	mov	x23, x8
    5a04:      	b	0x53cc <_stogir.locals.validate+0x110>
    5a08:      	mov	x23, x8
    5a0c:      	b	0x53cc <_stogir.locals.validate+0x110>

0000000000005a10 <_stogir.conversion.validate>:
    5a10:      	sub	sp, sp, #0x40
    5a14:      	str	x29, [sp]
    5a18:      	str	x30, [sp, #0x8]
    5a1c:      	mov	x29, sp
    5a20:      	str	x19, [sp, #0x30]
    5a24:      	sxtw	x1, w1
    5a28:      	lsl	x3, x1, #2
    5a2c:      	cmp	x1, #0x0
    5a30:      	cset	w4, gt
    5a34:      	movz	x16, #0x0, lsl #48
    5a38:      	sub	x5, x16, x1
    5a3c:      	sub	x6, x5, #0x1
    5a40:      	uxtb	w16, w4
    5a44:      	cmp	w16, wzr
    5a48:      	b.eq	0x5a88 <_stogir.conversion.validate+0x78>
    5a4c:      	ldr	x5, [x0, #0x8]
    5a50:      	cmp	x1, x5
    5a54:      	b.ge	0x5ad8 <_stogir.conversion.validate+0xc8>
    5a58:      	add	x5, x0, #0x78
    5a5c:      	ldr	x5, [x5, #0x8]
    5a60:      	cmp	x1, x5
    5a64:      	b.ge	0x5bb0 <_stogir.conversion.validate+0x1a0>
    5a68:      	ldr	x5, [x0, #0x78]
    5a6c:      	add	x5, x3, x5
    5a70:      	ldr	w5, [x5]
    5a74:      	sxtw	x5, w5
    5a78:      	cmp	x5, #0x0
    5a7c:      	cset	w5, ge
    5a80:      	ubfx	x5, x5, #0, #8
    5a84:      	b	0x5bb4 <_stogir.conversion.validate+0x1a4>
    5a88:      	cmp	x1, #0x0
    5a8c:      	b.ge	0x5ae0 <_stogir.conversion.validate+0xd0>
    5a90:      	add	x7, x0, #0x28
    5a94:      	add	x9, x0, #0x50
    5a98:      	ldr	x7, [x7, #0x8]
    5a9c:      	ldr	x9, [x9, #0x8]
    5aa0:      	cmp	x7, x9
    5aa4:      	b.ne	0x5ad0 <_stogir.conversion.validate+0xc0>
    5aa8:      	cmp	x5, x7
    5aac:      	b.gt	0x5c44 <_stogir.conversion.validate+0x234>
    5ab0:      	ldr	x5, [x0, #0x50]
    5ab4:      	add	x5, x5, x6, lsl #2
    5ab8:      	ldr	w5, [x5]
    5abc:      	sxtw	x5, w5
    5ac0:      	cmp	x5, #0x0
    5ac4:      	cset	w5, gt
    5ac8:      	ubfx	x5, x5, #0, #8
    5acc:      	b	0x5c48 <_stogir.conversion.validate+0x238>
    5ad0:      	movz	x5, #0x0, lsl #48
    5ad4:      	b	0x5ae4 <_stogir.conversion.validate+0xd4>
    5ad8:      	movz	x5, #0x0, lsl #48
    5adc:      	b	0x5ae4 <_stogir.conversion.validate+0xd4>
    5ae0:      	movz	x5, #0x0, lsl #48
    5ae4:      	cmp	x5, #0x0
    5ae8:      	b.eq	0x5b1c <_stogir.conversion.validate+0x10c>
    5aec:      	uxtb	w16, w4
    5af0:      	cmp	w16, wzr
    5af4:      	b.eq	0x5b08 <_stogir.conversion.validate+0xf8>
    5af8:      	ldr	x4, [x0]
    5afc:      	add	x4, x4, x1, lsl #4
    5b00:      	ldr	x4, [x4]
    5b04:      	b	0x5b14 <_stogir.conversion.validate+0x104>
    5b08:      	ldr	x4, [x0, #0x28]
    5b0c:      	add	x4, x4, x6, lsl #4
    5b10:      	ldr	x4, [x4]
    5b14:      	mov	x5, #0x1                ; =1
    5b18:      	b	0x5b24 <_stogir.conversion.validate+0x114>
    5b1c:      	movz	x5, #0x0, lsl #48
    5b20:      	movz	x4, #0x0, lsl #48
    5b24:      	lsr	w5, w5, #0
    5b28:      	lsr	x16, x5, #0
    5b2c:      	cmp	x16, #0x1
    5b30:      	b.eq	0x5b4c <_stogir.conversion.validate+0x13c>
    5b34:      	b.lo	0x5b3c <_stogir.conversion.validate+0x12c>
    5b38:      	b	0x5b50 <_stogir.conversion.validate+0x140>
    5b3c:      	cmp	x16, #0x0
    5b40:      	b.eq	0x5b48 <_stogir.conversion.validate+0x138>
    5b44:      	b	0x5b50 <_stogir.conversion.validate+0x140>
    5b48:      	b	0x5b54 <_stogir.conversion.validate+0x144>
    5b4c:      	b	0x5b8c <_stogir.conversion.validate+0x17c>
    5b50:      	b	0x5cbc <_stogir.conversion.validate+0x2ac>
    5b54:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		0000000000005b54:  ARM64_RELOC_PAGE21	l_stogir.397
    5b58:      	ldr	x16, [x16]
		0000000000005b58:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    5b5c:      	orr	x0, x16, xzr
    5b60:      	mov	x19, x8
    5b64:      	mov	x1, #0x1                ; =1
    5b68:      	mov	x2, #0x12               ; =18
    5b6c:      	str	x1, [x19]
    5b70:      	str	x0, [x19, #0x8]
    5b74:      	str	x2, [x19, #0x10]
    5b78:      	ldr	x19, [sp, #0x30]
    5b7c:      	ldr	x29, [sp]
    5b80:      	ldr	x30, [sp, #0x8]
    5b84:      	add	sp, sp, #0x40
    5b88:      	ret
    5b8c:      	cmp	x1, #0x0
    5b90:      	b.gt	0x5bb8 <_stogir.conversion.validate+0x1a8>
    5b94:      	mov	x19, x8
    5b98:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		0000000000005b98:  ARM64_RELOC_PAGE21	l_stogir.398
    5b9c:      	ldr	x16, [x16]
		0000000000005b9c:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    5ba0:      	orr	x0, x16, xzr
    5ba4:      	mov	x1, #0x1                ; =1
    5ba8:      	mov	x2, #0x1e               ; =30
    5bac:      	b	0x5b6c <_stogir.conversion.validate+0x15c>
    5bb0:      	movz	x5, #0x0, lsl #48
    5bb4:      	b	0x5adc <_stogir.conversion.validate+0xcc>
    5bb8:      	uxtb	w1, w4
    5bbc:      	orr	x5, x1, xzr
    5bc0:      	cmp	x5, #0x21
    5bc4:      	b.lt	0x5de4 <_stogir.conversion.validate+0x3d4>
    5bc8:      	cmp	x5, #0x27
    5bcc:      	b.gt	0x5dec <_stogir.conversion.validate+0x3dc>
    5bd0:      	ldr	x5, [x0, #0x78]
    5bd4:      	add	x3, x3, x5
    5bd8:      	ldr	w3, [x3]
    5bdc:      	sxtw	x3, w3
    5be0:      	cmp	x3, #0x1
    5be4:      	b.ne	0x5df4 <_stogir.conversion.validate+0x3e4>
    5be8:      	asr	x3, x4, #32
    5bec:      	cmp	x3, #0x0
    5bf0:      	cset	w6, gt
    5bf4:      	movz	x16, #0x0, lsl #48
    5bf8:      	sub	x7, x16, x3
    5bfc:      	sub	x9, x7, #0x1
    5c00:      	uxtb	w16, w6
    5c04:      	cmp	w16, wzr
    5c08:      	b.eq	0x5c74 <_stogir.conversion.validate+0x264>
    5c0c:      	ldr	x7, [x0, #0x8]
    5c10:      	cmp	x3, x7
    5c14:      	b.ge	0x5cc4 <_stogir.conversion.validate+0x2b4>
    5c18:      	add	x7, x0, #0x78
    5c1c:      	ldr	x7, [x7, #0x8]
    5c20:      	cmp	x3, x7
    5c24:      	b.ge	0x5d64 <_stogir.conversion.validate+0x354>
    5c28:      	add	x5, x5, x3, lsl #2
    5c2c:      	ldr	w5, [x5]
    5c30:      	sxtw	x5, w5
    5c34:      	cmp	x5, #0x0
    5c38:      	cset	w5, ge
    5c3c:      	ubfx	x5, x5, #0, #8
    5c40:      	b	0x5d68 <_stogir.conversion.validate+0x358>
    5c44:      	movz	x5, #0x0, lsl #48
    5c48:      	b	0x5ad4 <_stogir.conversion.validate+0xc4>
    5c4c:      	uxtb	w3, w0
    5c50:      	cmp	x3, #0x48
    5c54:      	b.ne	0x5d6c <_stogir.conversion.validate+0x35c>
    5c58:      	mov	x19, x8
    5c5c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		0000000000005c5c:  ARM64_RELOC_PAGE21	l_stogir.399
    5c60:      	ldr	x16, [x16]
		0000000000005c60:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    5c64:      	orr	x0, x16, xzr
    5c68:      	mov	x1, #0x1                ; =1
    5c6c:      	mov	x2, #0x25               ; =37
    5c70:      	b	0x5bac <_stogir.conversion.validate+0x19c>
    5c74:      	cmp	x3, #0x0
    5c78:      	b.ge	0x5ccc <_stogir.conversion.validate+0x2bc>
    5c7c:      	add	x5, x0, #0x28
    5c80:      	add	x10, x0, #0x50
    5c84:      	ldr	x5, [x5, #0x8]
    5c88:      	ldr	x10, [x10, #0x8]
    5c8c:      	cmp	x5, x10
    5c90:      	b.ne	0x5d5c <_stogir.conversion.validate+0x34c>
    5c94:      	cmp	x7, x5
    5c98:      	b.gt	0x5dd4 <_stogir.conversion.validate+0x3c4>
    5c9c:      	ldr	x5, [x0, #0x50]
    5ca0:      	add	x5, x5, x9, lsl #2
    5ca4:      	ldr	w5, [x5]
    5ca8:      	sxtw	x5, w5
    5cac:      	cmp	x5, #0x0
    5cb0:      	cset	w5, gt
    5cb4:      	ubfx	x5, x5, #0, #8
    5cb8:      	b	0x5dd8 <_stogir.conversion.validate+0x3c8>
    5cbc:      	brk	#0
    5cc0:      	b	0x5cbc <_stogir.conversion.validate+0x2ac>
    5cc4:      	movz	x5, #0x0, lsl #48
    5cc8:      	b	0x5cd0 <_stogir.conversion.validate+0x2c0>
    5ccc:      	movz	x5, #0x0, lsl #48
    5cd0:      	cmp	x5, #0x0
    5cd4:      	b.eq	0x5d08 <_stogir.conversion.validate+0x2f8>
    5cd8:      	uxtb	w16, w6
    5cdc:      	cmp	w16, wzr
    5ce0:      	b.eq	0x5cf4 <_stogir.conversion.validate+0x2e4>
    5ce4:      	ldr	x0, [x0]
    5ce8:      	add	x0, x0, x3, lsl #4
    5cec:      	ldr	x0, [x0]
    5cf0:      	b	0x5d00 <_stogir.conversion.validate+0x2f0>
    5cf4:      	ldr	x0, [x0, #0x28]
    5cf8:      	add	x0, x0, x9, lsl #4
    5cfc:      	ldr	x0, [x0]
    5d00:      	mov	x3, #0x1                ; =1
    5d04:      	b	0x5d10 <_stogir.conversion.validate+0x300>
    5d08:      	movz	x3, #0x0, lsl #48
    5d0c:      	movz	x0, #0x0, lsl #48
    5d10:      	lsr	w3, w3, #0
    5d14:      	lsr	x16, x3, #0
    5d18:      	cmp	x16, #0x1
    5d1c:      	b.eq	0x5d38 <_stogir.conversion.validate+0x328>
    5d20:      	b.lo	0x5d28 <_stogir.conversion.validate+0x318>
    5d24:      	b	0x5d3c <_stogir.conversion.validate+0x32c>
    5d28:      	cmp	x16, #0x0
    5d2c:      	b.eq	0x5d34 <_stogir.conversion.validate+0x324>
    5d30:      	b	0x5d3c <_stogir.conversion.validate+0x32c>
    5d34:      	b	0x5d40 <_stogir.conversion.validate+0x330>
    5d38:      	b	0x5c4c <_stogir.conversion.validate+0x23c>
    5d3c:      	b	0x5ddc <_stogir.conversion.validate+0x3cc>
    5d40:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		0000000000005d40:  ARM64_RELOC_PAGE21	l_stogir.400
    5d44:      	ldr	x16, [x16]
		0000000000005d44:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    5d48:      	orr	x0, x16, xzr
    5d4c:      	mov	x19, x8
    5d50:      	mov	x1, #0x1                ; =1
    5d54:      	mov	x2, #0x19               ; =25
    5d58:      	b	0x5c70 <_stogir.conversion.validate+0x260>
    5d5c:      	movz	x5, #0x0, lsl #48
    5d60:      	b	0x5cd0 <_stogir.conversion.validate+0x2c0>
    5d64:      	movz	x5, #0x0, lsl #48
    5d68:      	b	0x5cc8 <_stogir.conversion.validate+0x2b8>
    5d6c:      	cmp	x3, #0x46
    5d70:      	b.eq	0x5dfc <_stogir.conversion.validate+0x3ec>
    5d74:      	lsr	w2, w2, #0
    5d78:      	lsr	w4, w4, #0
    5d7c:      	lsr	w0, w0, #0
    5d80:      	lsr	w1, w1, #0
    5d84:      	ubfx	x3, x4, #8, #8
    5d88:      	ubfx	x0, x0, #8, #8
    5d8c:      	lsr	w3, w3, #0
    5d90:      	lsr	w0, w0, #0
    5d94:      	mov	x19, x8
    5d98:      	add	x8, sp, #0x10
    5d9c:      	fmov	s31, w0
    5da0:      	mov	w0, w1
    5da4:      	fmov	w1, s31
    5da8:      	fmov	s31, w2
    5dac:      	mov	w2, w3
    5db0:      	fmov	w3, s31
    5db4:      	bl	0x5db4 <_stogir.conversion.validate+0x3a4>
		0000000000005db4:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    5db8:      	add	x16, sp, #0x10
    5dbc:      	ldr	x1, [x16]
    5dc0:      	add	x16, sp, #0x10
    5dc4:      	ldr	x0, [x16, #0x8]
    5dc8:      	add	x16, sp, #0x10
    5dcc:      	ldr	x2, [x16, #0x10]
    5dd0:      	b	0x5c70 <_stogir.conversion.validate+0x260>
    5dd4:      	movz	x5, #0x0, lsl #48
    5dd8:      	b	0x5d60 <_stogir.conversion.validate+0x350>
    5ddc:      	brk	#0
    5de0:      	b	0x5ddc <_stogir.conversion.validate+0x3cc>
    5de4:      	mov	x19, x8
    5de8:      	b	0x5b98 <_stogir.conversion.validate+0x188>
    5dec:      	mov	x19, x8
    5df0:      	b	0x5b98 <_stogir.conversion.validate+0x188>
    5df4:      	mov	x19, x8
    5df8:      	b	0x5b98 <_stogir.conversion.validate+0x188>
    5dfc:      	mov	x19, x8
    5e00:      	b	0x5c5c <_stogir.conversion.validate+0x24c>

0000000000005e04 <_stogir.conditional.validate>:
    5e04:      	sub	sp, sp, #0x40
    5e08:      	str	x29, [sp]
    5e0c:      	str	x30, [sp, #0x8]
    5e10:      	mov	x29, sp
    5e14:      	str	x19, [sp, #0x30]
    5e18:      	sxtw	x1, w1
    5e1c:      	lsl	x2, x1, #2
    5e20:      	cmp	x1, #0x0
    5e24:      	cset	w3, gt
    5e28:      	movz	x16, #0x0, lsl #48
    5e2c:      	sub	x4, x16, x1
    5e30:      	sub	x5, x4, #0x1
    5e34:      	uxtb	w16, w3
    5e38:      	cmp	w16, wzr
    5e3c:      	b.eq	0x5e7c <_stogir.conditional.validate+0x78>
    5e40:      	ldr	x4, [x0, #0x8]
    5e44:      	cmp	x1, x4
    5e48:      	b.ge	0x5ecc <_stogir.conditional.validate+0xc8>
    5e4c:      	add	x4, x0, #0x78
    5e50:      	ldr	x4, [x4, #0x8]
    5e54:      	cmp	x1, x4
    5e58:      	b.ge	0x5fb0 <_stogir.conditional.validate+0x1ac>
    5e5c:      	ldr	x4, [x0, #0x78]
    5e60:      	add	x4, x2, x4
    5e64:      	ldr	w4, [x4]
    5e68:      	sxtw	x4, w4
    5e6c:      	cmp	x4, #0x0
    5e70:      	cset	w4, ge
    5e74:      	ubfx	x4, x4, #0, #8
    5e78:      	b	0x5fb4 <_stogir.conditional.validate+0x1b0>
    5e7c:      	cmp	x1, #0x0
    5e80:      	b.ge	0x5ed4 <_stogir.conditional.validate+0xd0>
    5e84:      	add	x6, x0, #0x28
    5e88:      	add	x7, x0, #0x50
    5e8c:      	ldr	x6, [x6, #0x8]
    5e90:      	ldr	x7, [x7, #0x8]
    5e94:      	cmp	x6, x7
    5e98:      	b.ne	0x5ec4 <_stogir.conditional.validate+0xc0>
    5e9c:      	cmp	x4, x6
    5ea0:      	b.gt	0x603c <_stogir.conditional.validate+0x238>
    5ea4:      	ldr	x4, [x0, #0x50]
    5ea8:      	add	x4, x4, x5, lsl #2
    5eac:      	ldr	w4, [x4]
    5eb0:      	sxtw	x4, w4
    5eb4:      	cmp	x4, #0x0
    5eb8:      	cset	w4, gt
    5ebc:      	ubfx	x4, x4, #0, #8
    5ec0:      	b	0x6040 <_stogir.conditional.validate+0x23c>
    5ec4:      	movz	x4, #0x0, lsl #48
    5ec8:      	b	0x5ed8 <_stogir.conditional.validate+0xd4>
    5ecc:      	movz	x4, #0x0, lsl #48
    5ed0:      	b	0x5ed8 <_stogir.conditional.validate+0xd4>
    5ed4:      	movz	x4, #0x0, lsl #48
    5ed8:      	cmp	x4, #0x0
    5edc:      	b.eq	0x5f18 <_stogir.conditional.validate+0x114>
    5ee0:      	uxtb	w16, w3
    5ee4:      	cmp	w16, wzr
    5ee8:      	b.eq	0x5f00 <_stogir.conditional.validate+0xfc>
    5eec:      	ldr	x3, [x0]
    5ef0:      	add	x3, x3, x1, lsl #4
    5ef4:      	ldr	x4, [x3]
    5ef8:      	ldr	x3, [x3, #0x8]
    5efc:      	b	0x5f10 <_stogir.conditional.validate+0x10c>
    5f00:      	ldr	x3, [x0, #0x28]
    5f04:      	add	x3, x3, x5, lsl #4
    5f08:      	ldr	x4, [x3]
    5f0c:      	ldr	x3, [x3, #0x8]
    5f10:      	mov	x5, #0x1                ; =1
    5f14:      	b	0x5f24 <_stogir.conditional.validate+0x120>
    5f18:      	movz	x5, #0x0, lsl #48
    5f1c:      	movz	x4, #0x0, lsl #48
    5f20:      	movz	x3, #0x0, lsl #48
    5f24:      	lsr	w5, w5, #0
    5f28:      	lsr	x16, x5, #0
    5f2c:      	cmp	x16, #0x1
    5f30:      	b.eq	0x5f4c <_stogir.conditional.validate+0x148>
    5f34:      	b.lo	0x5f3c <_stogir.conditional.validate+0x138>
    5f38:      	b	0x5f50 <_stogir.conditional.validate+0x14c>
    5f3c:      	cmp	x16, #0x0
    5f40:      	b.eq	0x5f48 <_stogir.conditional.validate+0x144>
    5f44:      	b	0x5f50 <_stogir.conditional.validate+0x14c>
    5f48:      	b	0x5f54 <_stogir.conditional.validate+0x150>
    5f4c:      	b	0x5f70 <_stogir.conditional.validate+0x16c>
    5f50:      	b	0x6044 <_stogir.conditional.validate+0x240>
    5f54:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		0000000000005f54:  ARM64_RELOC_PAGE21	l_stogir.401
    5f58:      	ldr	x16, [x16]
		0000000000005f58:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    5f5c:      	orr	x0, x16, xzr
    5f60:      	mov	x19, x8
    5f64:      	mov	x1, #0x1                ; =1
    5f68:      	mov	x2, #0x18               ; =24
    5f6c:      	b	0x5f90 <_stogir.conditional.validate+0x18c>
    5f70:      	cmp	x1, #0x0
    5f74:      	b.gt	0x5fb8 <_stogir.conditional.validate+0x1b4>
    5f78:      	mov	x19, x8
    5f7c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x33c>
		0000000000005f7c:  ARM64_RELOC_PAGE21	l_stogir.402
    5f80:      	ldr	x16, [x16]
		0000000000005f80:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    5f84:      	orr	x0, x16, xzr
    5f88:      	mov	x1, #0x1                ; =1
    5f8c:      	mov	x2, #0x18               ; =24
    5f90:      	str	x1, [x19]
    5f94:      	str	x0, [x19, #0x8]
    5f98:      	str	x2, [x19, #0x10]
    5f9c:      	ldr	x19, [sp, #0x30]
    5fa0:      	ldr	x29, [sp]
    5fa4:      	ldr	x30, [sp, #0x8]
    5fa8:      	add	sp, sp, #0x40
    5fac:      	ret
    5fb0:      	movz	x4, #0x0, lsl #48
    5fb4:      	b	0x5ed0 <_stogir.conditional.validate+0xcc>
    5fb8:      	uxtb	w1, w4
    5fbc:      	cmp	x1, #0x3c
    5fc0:      	b.ne	0x604c <_stogir.conditional.validate+0x248>
    5fc4:      	ldr	x1, [x0, #0x78]
    5fc8:      	add	x1, x2, x1
    5fcc:      	ldr	w1, [x1]
    5fd0:      	sxtw	x1, w1
    5fd4:      	cmp	x1, #0x3
    5fd8:      	b.ne	0x6054 <_stogir.conditional.validate+0x250>
    5fdc:      	lsr	w1, w3, #0
    5fe0:      	lsr	w2, w4, #0
    5fe4:      	lsr	x4, x4, #32
    5fe8:      	lsr	w1, w1, #0
    5fec:      	lsr	x3, x3, #32
    5ff0:      	lsr	w4, w4, #0
    5ff4:      	lsr	w3, w3, #0
    5ff8:      	ubfx	x2, x2, #8, #8
    5ffc:      	lsr	w2, w2, #0
    6000:      	mov	x19, x8
    6004:      	add	x8, sp, #0x10
    6008:      	fmov	s31, w1
    600c:      	mov	w1, w2
    6010:      	mov	w2, w4
    6014:      	mov	w4, w3
    6018:      	fmov	w3, s31
    601c:      	bl	0x601c <_stogir.conditional.validate+0x218>
		000000000000601c:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    6020:      	add	x16, sp, #0x10
    6024:      	ldr	x1, [x16]
    6028:      	add	x16, sp, #0x10
    602c:      	ldr	x0, [x16, #0x8]
    6030:      	add	x16, sp, #0x10
    6034:      	ldr	x2, [x16, #0x10]
    6038:      	b	0x5f90 <_stogir.conditional.validate+0x18c>
    603c:      	movz	x4, #0x0, lsl #48
    6040:      	b	0x5ec8 <_stogir.conditional.validate+0xc4>
    6044:      	brk	#0
    6048:      	b	0x6044 <_stogir.conditional.validate+0x240>
    604c:      	mov	x19, x8
    6050:      	b	0x5f7c <_stogir.conditional.validate+0x178>
    6054:      	mov	x19, x8
    6058:      	b	0x5f7c <_stogir.conditional.validate+0x178>

000000000000605c <_stogir.floating.validate>:
    605c:      	sub	sp, sp, #0x50
    6060:      	str	x29, [sp]
    6064:      	str	x30, [sp, #0x8]
    6068:      	mov	x29, sp
    606c:      	str	x19, [sp, #0x40]
    6070:      	sxtw	x1, w1
    6074:      	lsl	x2, x1, #2
    6078:      	cmp	x1, #0x0
    607c:      	cset	w3, gt
    6080:      	movz	x16, #0x0, lsl #48
    6084:      	sub	x4, x16, x1
    6088:      	sub	x5, x4, #0x1
    608c:      	uxtb	w16, w3
    6090:      	cmp	w16, wzr
    6094:      	b.eq	0x60d4 <_stogir.floating.validate+0x78>
    6098:      	ldr	x4, [x0, #0x8]
    609c:      	cmp	x1, x4
    60a0:      	b.ge	0x6124 <_stogir.floating.validate+0xc8>
    60a4:      	add	x4, x0, #0x78
    60a8:      	ldr	x4, [x4, #0x8]
    60ac:      	cmp	x1, x4
    60b0:      	b.ge	0x6218 <_stogir.floating.validate+0x1bc>
    60b4:      	ldr	x4, [x0, #0x78]
    60b8:      	add	x4, x2, x4
    60bc:      	ldr	w4, [x4]
    60c0:      	sxtw	x4, w4
    60c4:      	cmp	x4, #0x0
    60c8:      	cset	w4, ge
    60cc:      	ubfx	x4, x4, #0, #8
    60d0:      	b	0x621c <_stogir.floating.validate+0x1c0>
    60d4:      	cmp	x1, #0x0
    60d8:      	b.ge	0x612c <_stogir.floating.validate+0xd0>
    60dc:      	add	x6, x0, #0x28
    60e0:      	add	x7, x0, #0x50
    60e4:      	ldr	x6, [x6, #0x8]
    60e8:      	ldr	x7, [x7, #0x8]
    60ec:      	cmp	x6, x7
    60f0:      	b.ne	0x611c <_stogir.floating.validate+0xc0>
    60f4:      	cmp	x4, x6
    60f8:      	b.gt	0x62a4 <_stogir.floating.validate+0x248>
    60fc:      	ldr	x4, [x0, #0x50]
    6100:      	add	x4, x4, x5, lsl #2
    6104:      	ldr	w4, [x4]
    6108:      	sxtw	x4, w4
    610c:      	cmp	x4, #0x0
    6110:      	cset	w4, gt
    6114:      	ubfx	x4, x4, #0, #8
    6118:      	b	0x62a8 <_stogir.floating.validate+0x24c>
    611c:      	movz	x4, #0x0, lsl #48
    6120:      	b	0x6130 <_stogir.floating.validate+0xd4>
    6124:      	movz	x4, #0x0, lsl #48
    6128:      	b	0x6130 <_stogir.floating.validate+0xd4>
    612c:      	movz	x4, #0x0, lsl #48
    6130:      	cmp	x4, #0x0
    6134:      	b.eq	0x6170 <_stogir.floating.validate+0x114>
    6138:      	uxtb	w16, w3
    613c:      	cmp	w16, wzr
    6140:      	b.eq	0x6158 <_stogir.floating.validate+0xfc>
    6144:      	ldr	x3, [x0]
    6148:      	add	x3, x3, x1, lsl #4
    614c:      	ldr	x4, [x3]
    6150:      	ldr	x3, [x3, #0x8]
    6154:      	b	0x6168 <_stogir.floating.validate+0x10c>
    6158:      	ldr	x3, [x0, #0x28]
    615c:      	add	x3, x3, x5, lsl #4
    6160:      	ldr	x4, [x3]
    6164:      	ldr	x3, [x3, #0x8]
    6168:      	mov	x5, #0x1                ; =1
    616c:      	b	0x617c <_stogir.floating.validate+0x120>
    6170:      	movz	x5, #0x0, lsl #48
    6174:      	movz	x4, #0x0, lsl #48
    6178:      	movz	x3, #0x0, lsl #48
    617c:      	lsr	w5, w5, #0
    6180:      	lsr	x16, x5, #0
    6184:      	cmp	x16, #0x1
    6188:      	b.eq	0x61a4 <_stogir.floating.validate+0x148>
    618c:      	b.lo	0x6194 <_stogir.floating.validate+0x138>
    6190:      	b	0x61a8 <_stogir.floating.validate+0x14c>
    6194:      	cmp	x16, #0x0
    6198:      	b.eq	0x61a0 <_stogir.floating.validate+0x144>
    619c:      	b	0x61a8 <_stogir.floating.validate+0x14c>
    61a0:      	b	0x61ac <_stogir.floating.validate+0x150>
    61a4:      	b	0x61e4 <_stogir.floating.validate+0x188>
    61a8:      	b	0x6540 <_stogir.floating.validate+0x4e4>
    61ac:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x1fc>
		00000000000061ac:  ARM64_RELOC_PAGE21	l_stogir.403
    61b0:      	ldr	x16, [x16]
		00000000000061b0:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    61b4:      	orr	x0, x16, xzr
    61b8:      	mov	x19, x8
    61bc:      	mov	x1, #0x1                ; =1
    61c0:      	mov	x2, #0x1c               ; =28
    61c4:      	str	x1, [x19]
    61c8:      	str	x0, [x19, #0x8]
    61cc:      	str	x2, [x19, #0x10]
    61d0:      	ldr	x19, [sp, #0x40]
    61d4:      	ldr	x29, [sp]
    61d8:      	ldr	x30, [sp, #0x8]
    61dc:      	add	sp, sp, #0x50
    61e0:      	ret
    61e4:      	add	x16, sp, #0x10
    61e8:      	str	x4, [x16]
    61ec:      	add	x16, sp, #0x10
    61f0:      	str	x3, [x16, #0x8]
    61f4:      	cmp	x1, #0x0
    61f8:      	b.gt	0x6220 <_stogir.floating.validate+0x1c4>
    61fc:      	mov	x19, x8
    6200:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x1fc>
		0000000000006200:  ARM64_RELOC_PAGE21	l_stogir.404
    6204:      	ldr	x16, [x16]
		0000000000006204:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    6208:      	orr	x0, x16, xzr
    620c:      	mov	x1, #0x1                ; =1
    6210:      	mov	x2, #0x1c               ; =28
    6214:      	b	0x61c4 <_stogir.floating.validate+0x168>
    6218:      	movz	x4, #0x0, lsl #48
    621c:      	b	0x6128 <_stogir.floating.validate+0xcc>
    6220:      	uxtb	w4, w4
    6224:      	orr	x1, x4, xzr
    6228:      	cmp	x1, #0xe
    622c:      	cset	w3, ge
    6230:      	cmp	x1, #0x19
    6234:      	cset	w5, le
    6238:      	cmp	x1, #0x1f
    623c:      	cset	w6, eq
    6240:      	cmp	x1, #0x20
    6244:      	cset	w7, eq
    6248:      	uxtb	w16, w3
    624c:      	cmp	w16, wzr
    6250:      	b.eq	0x62ac <_stogir.floating.validate+0x250>
    6254:      	uxtb	w16, w5
    6258:      	cmp	w16, wzr
    625c:      	b.eq	0x62ac <_stogir.floating.validate+0x250>
    6260:      	cmp	x1, #0x1d
    6264:      	cset	w1, eq
    6268:      	ldr	x9, [x0, #0x78]
    626c:      	add	x2, x2, x9
    6270:      	ldr	w2, [x2]
    6274:      	uxtb	w16, w6
    6278:      	cmp	w16, wzr
    627c:      	b.ne	0x62ec <_stogir.floating.validate+0x290>
    6280:      	uxtb	w16, w7
    6284:      	cmp	w16, wzr
    6288:      	b.ne	0x62ec <_stogir.floating.validate+0x290>
    628c:      	uxtb	w16, w1
    6290:      	cmp	w16, wzr
    6294:      	mov	x16, #0x3               ; =3
    6298:      	mov	x17, #0x2               ; =2
    629c:      	csel	x6, x16, x17, ne
    62a0:      	b	0x62f0 <_stogir.floating.validate+0x294>
    62a4:      	movz	x4, #0x0, lsl #48
    62a8:      	b	0x6120 <_stogir.floating.validate+0xc4>
    62ac:      	uxtb	w16, w6
    62b0:      	cmp	w16, wzr
    62b4:      	b.ne	0x6260 <_stogir.floating.validate+0x204>
    62b8:      	uxtb	w16, w7
    62bc:      	cmp	w16, wzr
    62c0:      	b.ne	0x6260 <_stogir.floating.validate+0x204>
    62c4:      	cmp	x1, #0x1a
    62c8:      	b.lt	0x62d4 <_stogir.floating.validate+0x278>
    62cc:      	cmp	x1, #0x1d
    62d0:      	b.le	0x6260 <_stogir.floating.validate+0x204>
    62d4:      	cmp	x1, #0x3a
    62d8:      	b.eq	0x6260 <_stogir.floating.validate+0x204>
    62dc:      	cmp	x1, #0x3b
    62e0:      	b.eq	0x6260 <_stogir.floating.validate+0x204>
    62e4:      	mov	x19, x8
    62e8:      	b	0x6200 <_stogir.floating.validate+0x1a4>
    62ec:      	mov	x6, #0x1                ; =1
    62f0:      	sxtw	x2, w2
    62f4:      	lsr	w6, w6, #0
    62f8:      	sxtw	x6, w6
    62fc:      	cmp	x2, x6
    6300:      	b.ne	0x6550 <_stogir.floating.validate+0x4f4>
    6304:      	add	x16, sp, #0x10
    6308:      	ldr	w2, [x16, #0x4]
    630c:      	sxtw	x2, w2
    6310:      	cmp	x2, #0x0
    6314:      	cset	w6, gt
    6318:      	movz	x16, #0x0, lsl #48
    631c:      	sub	x7, x16, x2
    6320:      	sub	x9, x7, #0x1
    6324:      	uxtb	w16, w6
    6328:      	cmp	w16, wzr
    632c:      	b.eq	0x6384 <_stogir.floating.validate+0x328>
    6330:      	ldr	x7, [x0, #0x8]
    6334:      	cmp	x2, x7
    6338:      	b.ge	0x63cc <_stogir.floating.validate+0x370>
    633c:      	add	x7, x0, #0x78
    6340:      	ldr	x7, [x7, #0x8]
    6344:      	cmp	x2, x7
    6348:      	b.ge	0x649c <_stogir.floating.validate+0x440>
    634c:      	ldr	x7, [x0, #0x78]
    6350:      	add	x7, x7, x2, lsl #2
    6354:      	ldr	w7, [x7]
    6358:      	sxtw	x7, w7
    635c:      	cmp	x7, #0x0
    6360:      	cset	w7, ge
    6364:      	ubfx	x7, x7, #0, #8
    6368:      	b	0x64a0 <_stogir.floating.validate+0x444>
    636c:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x1fc>
		000000000000636c:  ARM64_RELOC_PAGE21	l_stogir.405
    6370:      	ldr	x16, [x16]
		0000000000006370:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    6374:      	orr	x0, x16, xzr
    6378:      	mov	x1, #0x1                ; =1
    637c:      	mov	x2, #0x1d               ; =29
    6380:      	b	0x6214 <_stogir.floating.validate+0x1b8>
    6384:      	cmp	x2, #0x0
    6388:      	b.ge	0x63d4 <_stogir.floating.validate+0x378>
    638c:      	add	x10, x0, #0x28
    6390:      	add	x11, x0, #0x50
    6394:      	ldr	x10, [x10, #0x8]
    6398:      	ldr	x11, [x11, #0x8]
    639c:      	cmp	x10, x11
    63a0:      	b.ne	0x6494 <_stogir.floating.validate+0x438>
    63a4:      	cmp	x7, x10
    63a8:      	b.gt	0x6538 <_stogir.floating.validate+0x4dc>
    63ac:      	ldr	x7, [x0, #0x50]
    63b0:      	add	x7, x7, x9, lsl #2
    63b4:      	ldr	w7, [x7]
    63b8:      	sxtw	x7, w7
    63bc:      	cmp	x7, #0x0
    63c0:      	cset	w7, gt
    63c4:      	ubfx	x7, x7, #0, #8
    63c8:      	b	0x653c <_stogir.floating.validate+0x4e0>
    63cc:      	movz	x7, #0x0, lsl #48
    63d0:      	b	0x63d8 <_stogir.floating.validate+0x37c>
    63d4:      	movz	x7, #0x0, lsl #48
    63d8:      	cmp	x7, #0x0
    63dc:      	b.eq	0x6410 <_stogir.floating.validate+0x3b4>
    63e0:      	uxtb	w16, w6
    63e4:      	cmp	w16, wzr
    63e8:      	b.eq	0x63fc <_stogir.floating.validate+0x3a0>
    63ec:      	ldr	x6, [x0]
    63f0:      	add	x2, x6, x2, lsl #4
    63f4:      	ldr	x2, [x2]
    63f8:      	b	0x6408 <_stogir.floating.validate+0x3ac>
    63fc:      	ldr	x2, [x0, #0x28]
    6400:      	add	x2, x2, x9, lsl #4
    6404:      	ldr	x2, [x2]
    6408:      	mov	x6, #0x1                ; =1
    640c:      	b	0x6418 <_stogir.floating.validate+0x3bc>
    6410:      	movz	x6, #0x0, lsl #48
    6414:      	movz	x2, #0x0, lsl #48
    6418:      	lsr	w6, w6, #0
    641c:      	lsr	x16, x6, #0
    6420:      	cmp	x16, #0x1
    6424:      	b.eq	0x6440 <_stogir.floating.validate+0x3e4>
    6428:      	b.lo	0x6430 <_stogir.floating.validate+0x3d4>
    642c:      	b	0x6444 <_stogir.floating.validate+0x3e8>
    6430:      	cmp	x16, #0x0
    6434:      	b.eq	0x643c <_stogir.floating.validate+0x3e0>
    6438:      	b	0x6444 <_stogir.floating.validate+0x3e8>
    643c:      	b	0x6448 <_stogir.floating.validate+0x3ec>
    6440:      	b	0x6464 <_stogir.floating.validate+0x408>
    6444:      	b	0x6548 <_stogir.floating.validate+0x4ec>
    6448:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x1fc>
		0000000000006448:  ARM64_RELOC_PAGE21	l_stogir.406
    644c:      	ldr	x16, [x16]
		000000000000644c:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    6450:      	orr	x0, x16, xzr
    6454:      	mov	x19, x8
    6458:      	mov	x1, #0x1                ; =1
    645c:      	mov	x2, #0x18               ; =24
    6460:      	b	0x6380 <_stogir.floating.validate+0x324>
    6464:      	lsr	w2, w2, #0
    6468:      	add	x16, sp, #0x10
    646c:      	ldr	w6, [x16]
    6470:      	ubfx	x2, x2, #8, #8
    6474:      	uxtb	w16, w3
    6478:      	cmp	w16, wzr
    647c:      	b.eq	0x64f4 <_stogir.floating.validate+0x498>
    6480:      	uxtb	w16, w5
    6484:      	cmp	w16, wzr
    6488:      	b.eq	0x64f4 <_stogir.floating.validate+0x498>
    648c:      	mov	x3, #0x1                ; =1
    6490:      	b	0x64f8 <_stogir.floating.validate+0x49c>
    6494:      	movz	x7, #0x0, lsl #48
    6498:      	b	0x63d8 <_stogir.floating.validate+0x37c>
    649c:      	movz	x7, #0x0, lsl #48
    64a0:      	b	0x63d0 <_stogir.floating.validate+0x374>
    64a4:      	movz	x1, #0x0, lsl #48
    64a8:      	lsr	w3, w3, #0
    64ac:      	lsr	w5, w5, #0
    64b0:      	lsr	w4, w4, #0
    64b4:      	lsr	w2, w2, #0
    64b8:      	lsr	w1, w1, #0
    64bc:      	mov	x19, x8
    64c0:      	add	x8, sp, #0x20
    64c4:      	fmov	s31, w1
    64c8:      	mov	w1, w4
    64cc:      	mov	w4, w5
    64d0:      	fmov	w5, s31
    64d4:      	bl	0x64d4 <_stogir.floating.validate+0x478>
		00000000000064d4:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    64d8:      	add	x16, sp, #0x20
    64dc:      	ldr	x1, [x16]
    64e0:      	add	x16, sp, #0x20
    64e4:      	ldr	x0, [x16, #0x8]
    64e8:      	add	x16, sp, #0x20
    64ec:      	ldr	x2, [x16, #0x10]
    64f0:      	b	0x6380 <_stogir.floating.validate+0x324>
    64f4:      	orr	x3, x2, xzr
    64f8:      	lsr	w3, w3, #0
    64fc:      	ubfx	x5, x6, #8, #8
    6500:      	sxtw	x3, w3
    6504:      	cmp	x5, x3
    6508:      	b.ne	0x6558 <_stogir.floating.validate+0x4fc>
    650c:      	add	x16, sp, #0x10
    6510:      	ldr	w3, [x16, #0x4]
    6514:      	add	x16, sp, #0x10
    6518:      	ldr	w5, [x16, #0x8]
    651c:      	uxtb	w16, w1
    6520:      	cmp	w16, wzr
    6524:      	b.eq	0x64a4 <_stogir.floating.validate+0x448>
    6528:      	add	x16, sp, #0x10
    652c:      	ldr	w1, [x16, #0xc]
    6530:      	sxtw	x1, w1
    6534:      	b	0x64a8 <_stogir.floating.validate+0x44c>
    6538:      	movz	x7, #0x0, lsl #48
    653c:      	b	0x6498 <_stogir.floating.validate+0x43c>
    6540:      	brk	#0
    6544:      	b	0x6540 <_stogir.floating.validate+0x4e4>
    6548:      	brk	#0
    654c:      	b	0x6548 <_stogir.floating.validate+0x4ec>
    6550:      	mov	x19, x8
    6554:      	b	0x6200 <_stogir.floating.validate+0x1a4>
    6558:      	mov	x19, x8
    655c:      	b	0x636c <_stogir.floating.validate+0x310>

0000000000006560 <_stogir.integer-unary.valid-type?>:
    6560:      	sxtw	x0, w0
    6564:      	cmp	x0, #0x2d
    6568:      	cset	w2, eq
    656c:      	cmp	x0, #0x1f
    6570:      	cset	w3, eq
    6574:      	cmp	x0, #0x20
    6578:      	cset	w4, eq
    657c:      	cmp	x0, #0x36
    6580:      	cset	w5, eq
    6584:      	uxtb	w16, w3
    6588:      	cmp	w16, wzr
    658c:      	b.ne	0x65d4 <_stogir.integer-unary.valid-type?+0x74>
    6590:      	uxtb	w16, w4
    6594:      	cmp	w16, wzr
    6598:      	b.ne	0x65d4 <_stogir.integer-unary.valid-type?+0x74>
    659c:      	uxtb	w16, w2
    65a0:      	cmp	w16, wzr
    65a4:      	b.ne	0x65d4 <_stogir.integer-unary.valid-type?+0x74>
    65a8:      	uxtb	w16, w5
    65ac:      	cmp	w16, wzr
    65b0:      	b.ne	0x65d4 <_stogir.integer-unary.valid-type?+0x74>
    65b4:      	cmp	x0, #0x37
    65b8:      	b.eq	0x65d4 <_stogir.integer-unary.valid-type?+0x74>
    65bc:      	cmp	x0, #0x38
    65c0:      	b.eq	0x65d4 <_stogir.integer-unary.valid-type?+0x74>
    65c4:      	cmp	x0, #0x39
    65c8:      	b.eq	0x65d4 <_stogir.integer-unary.valid-type?+0x74>
    65cc:      	movz	x0, #0x0, lsl #48
    65d0:      	b	0x660c <_stogir.integer-unary.valid-type?+0xac>
    65d4:      	sxtw	x1, w1
    65d8:      	cmp	x1, #0x1
    65dc:      	b.lt	0x6608 <_stogir.integer-unary.valid-type?+0xa8>
    65e0:      	cmp	x1, #0xb
    65e4:      	cset	w0, le
    65e8:      	uxtb	w16, w0
    65ec:      	cmp	w16, wzr
    65f0:      	b.eq	0x6608 <_stogir.integer-unary.valid-type?+0xa8>
    65f4:      	uxtb	w16, w2
    65f8:      	cmp	w16, wzr
    65fc:      	b.eq	0x6618 <_stogir.integer-unary.valid-type?+0xb8>
    6600:      	mov	x0, #0x1                ; =1
    6604:      	b	0x6614 <_stogir.integer-unary.valid-type?+0xb4>
    6608:      	movz	x0, #0x0, lsl #48
    660c:      	ret
    6610:      	mov	x0, #0x1                ; =1
    6614:      	b	0x660c <_stogir.integer-unary.valid-type?+0xac>
    6618:      	cmp	x1, #0x1
    661c:      	b.ne	0x6628 <_stogir.integer-unary.valid-type?+0xc8>
    6620:      	movz	x0, #0x0, lsl #48
    6624:      	b	0x6614 <_stogir.integer-unary.valid-type?+0xb4>
    6628:      	cmp	x1, #0x6
    662c:      	cset	w2, eq
    6630:      	uxtb	w16, w3
    6634:      	cmp	w16, wzr
    6638:      	b.eq	0x664c <_stogir.integer-unary.valid-type?+0xec>
    663c:      	uxtb	w16, w2
    6640:      	cmp	w16, wzr
    6644:      	cset	x0, eq
    6648:      	b	0x6614 <_stogir.integer-unary.valid-type?+0xb4>
    664c:      	uxtb	w16, w4
    6650:      	cmp	w16, wzr
    6654:      	b.eq	0x6670 <_stogir.integer-unary.valid-type?+0x110>
    6658:      	cmp	x1, #0x7
    665c:      	b.lt	0x6668 <_stogir.integer-unary.valid-type?+0x108>
    6660:      	ubfx	x0, x0, #0, #8
    6664:      	b	0x666c <_stogir.integer-unary.valid-type?+0x10c>
    6668:      	movz	x0, #0x0, lsl #48
    666c:      	b	0x6614 <_stogir.integer-unary.valid-type?+0xb4>
    6670:      	uxtb	w16, w5
    6674:      	cmp	w16, wzr
    6678:      	b.eq	0x6610 <_stogir.integer-unary.valid-type?+0xb0>
    667c:      	cmp	x1, #0x3
    6680:      	b.ne	0x669c <_stogir.integer-unary.valid-type?+0x13c>
    6684:      	mov	x0, #0x1                ; =1
    6688:      	b	0x6698 <_stogir.integer-unary.valid-type?+0x138>
    668c:      	cmp	x1, #0xb
    6690:      	cset	w0, eq
    6694:      	ubfx	x0, x0, #0, #8
    6698:      	b	0x6614 <_stogir.integer-unary.valid-type?+0xb4>
    669c:      	cmp	x1, #0x4
    66a0:      	b.ne	0x66ac <_stogir.integer-unary.valid-type?+0x14c>
    66a4:      	mov	x0, #0x1                ; =1
    66a8:      	b	0x6698 <_stogir.integer-unary.valid-type?+0x138>
    66ac:      	cmp	x1, #0x5
    66b0:      	b.ne	0x66bc <_stogir.integer-unary.valid-type?+0x15c>
    66b4:      	mov	x0, #0x1                ; =1
    66b8:      	b	0x6698 <_stogir.integer-unary.valid-type?+0x138>
    66bc:      	uxtb	w16, w2
    66c0:      	cmp	w16, wzr
    66c4:      	b.eq	0x66d0 <_stogir.integer-unary.valid-type?+0x170>
    66c8:      	mov	x0, #0x1                ; =1
    66cc:      	b	0x6698 <_stogir.integer-unary.valid-type?+0x138>
    66d0:      	cmp	x1, #0x9
    66d4:      	b.ne	0x66e0 <_stogir.integer-unary.valid-type?+0x180>
    66d8:      	mov	x0, #0x1                ; =1
    66dc:      	b	0x6698 <_stogir.integer-unary.valid-type?+0x138>
    66e0:      	cmp	x1, #0xa
    66e4:      	b.ne	0x668c <_stogir.integer-unary.valid-type?+0x12c>
    66e8:      	mov	x0, #0x1                ; =1
    66ec:      	b	0x6698 <_stogir.integer-unary.valid-type?+0x138>

00000000000066f0 <_stogir.types.vector?>:
    66f0:      	sxtw	x0, w0
    66f4:      	cmp	x0, #0xf
    66f8:      	b.le	0x6734 <_stogir.types.vector?+0x44>
    66fc:      	cmp	x0, #0x80
    6700:      	b.ge	0x6744 <_stogir.types.vector?+0x54>
    6704:      	and	x1, x0, #0xf
    6708:      	lsr	w1, w1, #0
    670c:      	sxtw	x1, w1
    6710:      	cmp	x1, #0x1
    6714:      	b.lt	0x673c <_stogir.types.vector?+0x4c>
    6718:      	and	x0, x0, #0xf
    671c:      	lsr	w0, w0, #0
    6720:      	sxtw	x0, w0
    6724:      	cmp	x0, #0xd
    6728:      	cset	w0, le
    672c:      	ubfx	x0, x0, #0, #8
    6730:      	b	0x6740 <_stogir.types.vector?+0x50>
    6734:      	movz	x0, #0x0, lsl #48
    6738:      	b	0x6740 <_stogir.types.vector?+0x50>
    673c:      	movz	x0, #0x0, lsl #48
    6740:      	ret
    6744:      	movz	x0, #0x0, lsl #48
    6748:      	b	0x6740 <_stogir.types.vector?+0x50>

000000000000674c <_stogir.floating.operation?>:
    674c:      	sxtw	x0, w0
    6750:      	cmp	x0, #0xe
    6754:      	b.lt	0x6768 <_stogir.floating.operation?+0x1c>
    6758:      	cmp	x0, #0x19
    675c:      	b.gt	0x6768 <_stogir.floating.operation?+0x1c>
    6760:      	mov	x0, #0x1                ; =1
    6764:      	b	0x6794 <_stogir.floating.operation?+0x48>
    6768:      	cmp	x0, #0x1f
    676c:      	b.eq	0x6790 <_stogir.floating.operation?+0x44>
    6770:      	cmp	x0, #0x20
    6774:      	b.eq	0x6790 <_stogir.floating.operation?+0x44>
    6778:      	cmp	x0, #0x1a
    677c:      	b.lt	0x67a8 <_stogir.floating.operation?+0x5c>
    6780:      	cmp	x0, #0x1d
    6784:      	b.gt	0x67a8 <_stogir.floating.operation?+0x5c>
    6788:      	mov	x0, #0x1                ; =1
    678c:      	b	0x67a4 <_stogir.floating.operation?+0x58>
    6790:      	mov	x0, #0x1                ; =1
    6794:      	ret
    6798:      	cmp	x0, #0x3b
    679c:      	cset	w0, eq
    67a0:      	ubfx	x0, x0, #0, #8
    67a4:      	b	0x6794 <_stogir.floating.operation?+0x48>
    67a8:      	cmp	x0, #0x3a
    67ac:      	b.ne	0x6798 <_stogir.floating.operation?+0x4c>
    67b0:      	mov	x0, #0x1                ; =1
    67b4:      	b	0x67a4 <_stogir.floating.operation?+0x58>

00000000000067b8 <_stogir.vector-lanes.validate>:
    67b8:      	sub	sp, sp, #0x50
    67bc:      	str	x29, [sp]
    67c0:      	str	x30, [sp, #0x8]
    67c4:      	mov	x29, sp
    67c8:      	str	x19, [sp, #0x40]
    67cc:      	sxtw	x1, w1
    67d0:      	lsl	x3, x1, #2
    67d4:      	cmp	x1, #0x0
    67d8:      	cset	w4, gt
    67dc:      	movz	x16, #0x0, lsl #48
    67e0:      	sub	x5, x16, x1
    67e4:      	sub	x6, x5, #0x1
    67e8:      	uxtb	w16, w4
    67ec:      	cmp	w16, wzr
    67f0:      	b.eq	0x6830 <_stogir.vector-lanes.validate+0x78>
    67f4:      	ldr	x5, [x0, #0x8]
    67f8:      	cmp	x1, x5
    67fc:      	b.ge	0x6880 <_stogir.vector-lanes.validate+0xc8>
    6800:      	add	x5, x0, #0x78
    6804:      	ldr	x5, [x5, #0x8]
    6808:      	cmp	x1, x5
    680c:      	b.ge	0x6974 <_stogir.vector-lanes.validate+0x1bc>
    6810:      	ldr	x5, [x0, #0x78]
    6814:      	add	x5, x3, x5
    6818:      	ldr	w5, [x5]
    681c:      	sxtw	x5, w5
    6820:      	cmp	x5, #0x0
    6824:      	cset	w5, ge
    6828:      	ubfx	x5, x5, #0, #8
    682c:      	b	0x6978 <_stogir.vector-lanes.validate+0x1c0>
    6830:      	cmp	x1, #0x0
    6834:      	b.ge	0x6888 <_stogir.vector-lanes.validate+0xd0>
    6838:      	add	x7, x0, #0x28
    683c:      	add	x9, x0, #0x50
    6840:      	ldr	x7, [x7, #0x8]
    6844:      	ldr	x9, [x9, #0x8]
    6848:      	cmp	x7, x9
    684c:      	b.ne	0x6878 <_stogir.vector-lanes.validate+0xc0>
    6850:      	cmp	x5, x7
    6854:      	b.gt	0x69b8 <_stogir.vector-lanes.validate+0x200>
    6858:      	ldr	x5, [x0, #0x50]
    685c:      	add	x5, x5, x6, lsl #2
    6860:      	ldr	w5, [x5]
    6864:      	sxtw	x5, w5
    6868:      	cmp	x5, #0x0
    686c:      	cset	w5, gt
    6870:      	ubfx	x5, x5, #0, #8
    6874:      	b	0x69bc <_stogir.vector-lanes.validate+0x204>
    6878:      	movz	x5, #0x0, lsl #48
    687c:      	b	0x688c <_stogir.vector-lanes.validate+0xd4>
    6880:      	movz	x5, #0x0, lsl #48
    6884:      	b	0x688c <_stogir.vector-lanes.validate+0xd4>
    6888:      	movz	x5, #0x0, lsl #48
    688c:      	cmp	x5, #0x0
    6890:      	b.eq	0x68cc <_stogir.vector-lanes.validate+0x114>
    6894:      	uxtb	w16, w4
    6898:      	cmp	w16, wzr
    689c:      	b.eq	0x68b4 <_stogir.vector-lanes.validate+0xfc>
    68a0:      	ldr	x4, [x0]
    68a4:      	add	x4, x4, x1, lsl #4
    68a8:      	ldr	x5, [x4]
    68ac:      	ldr	x4, [x4, #0x8]
    68b0:      	b	0x68c4 <_stogir.vector-lanes.validate+0x10c>
    68b4:      	ldr	x4, [x0, #0x28]
    68b8:      	add	x4, x4, x6, lsl #4
    68bc:      	ldr	x5, [x4]
    68c0:      	ldr	x4, [x4, #0x8]
    68c4:      	mov	x6, #0x1                ; =1
    68c8:      	b	0x68d8 <_stogir.vector-lanes.validate+0x120>
    68cc:      	movz	x6, #0x0, lsl #48
    68d0:      	movz	x5, #0x0, lsl #48
    68d4:      	movz	x4, #0x0, lsl #48
    68d8:      	lsr	w6, w6, #0
    68dc:      	lsr	x16, x6, #0
    68e0:      	cmp	x16, #0x1
    68e4:      	b.eq	0x6900 <_stogir.vector-lanes.validate+0x148>
    68e8:      	b.lo	0x68f0 <_stogir.vector-lanes.validate+0x138>
    68ec:      	b	0x6904 <_stogir.vector-lanes.validate+0x14c>
    68f0:      	cmp	x16, #0x0
    68f4:      	b.eq	0x68fc <_stogir.vector-lanes.validate+0x144>
    68f8:      	b	0x6904 <_stogir.vector-lanes.validate+0x14c>
    68fc:      	b	0x6908 <_stogir.vector-lanes.validate+0x150>
    6900:      	b	0x6924 <_stogir.vector-lanes.validate+0x16c>
    6904:      	b	0x6a9c <_stogir.vector-lanes.validate+0x2e4>
    6908:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x1fc>
		0000000000006908:  ARM64_RELOC_PAGE21	l_stogir.407
    690c:      	ldr	x16, [x16]
		000000000000690c:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    6910:      	orr	x0, x16, xzr
    6914:      	mov	x19, x8
    6918:      	mov	x1, #0x1                ; =1
    691c:      	mov	x2, #0x1f               ; =31
    6920:      	b	0x6954 <_stogir.vector-lanes.validate+0x19c>
    6924:      	add	x16, sp, #0x10
    6928:      	str	x5, [x16]
    692c:      	add	x16, sp, #0x10
    6930:      	str	x4, [x16, #0x8]
    6934:      	cmp	x1, #0x0
    6938:      	b.gt	0x697c <_stogir.vector-lanes.validate+0x1c4>
    693c:      	mov	x19, x8
    6940:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x1fc>
		0000000000006940:  ARM64_RELOC_PAGE21	l_stogir.408
    6944:      	ldr	x16, [x16]
		0000000000006944:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    6948:      	orr	x0, x16, xzr
    694c:      	mov	x1, #0x1                ; =1
    6950:      	mov	x2, #0x25               ; =37
    6954:      	str	x1, [x19]
    6958:      	str	x0, [x19, #0x8]
    695c:      	str	x2, [x19, #0x10]
    6960:      	ldr	x19, [sp, #0x40]
    6964:      	ldr	x29, [sp]
    6968:      	ldr	x30, [sp, #0x8]
    696c:      	add	sp, sp, #0x50
    6970:      	ret
    6974:      	movz	x5, #0x0, lsl #48
    6978:      	b	0x6884 <_stogir.vector-lanes.validate+0xcc>
    697c:      	uxtb	w5, w5
    6980:      	orr	x1, x5, xzr
    6984:      	cmp	x1, #0x3d
    6988:      	b.lt	0x6aa4 <_stogir.vector-lanes.validate+0x2ec>
    698c:      	cmp	x1, #0x3f
    6990:      	b.gt	0x6aac <_stogir.vector-lanes.validate+0x2f4>
    6994:      	cmp	x1, #0x3e
    6998:      	cset	w4, eq
    699c:      	ldr	x6, [x0, #0x78]
    69a0:      	add	x3, x3, x6
    69a4:      	ldr	w3, [x3]
    69a8:      	cmp	x1, #0x3d
    69ac:      	b.ne	0x6a2c <_stogir.vector-lanes.validate+0x274>
    69b0:      	mov	x6, #0x2                ; =2
    69b4:      	b	0x6a40 <_stogir.vector-lanes.validate+0x288>
    69b8:      	movz	x5, #0x0, lsl #48
    69bc:      	b	0x687c <_stogir.vector-lanes.validate+0xc4>
    69c0:      	movz	x4, #0x0, lsl #48
    69c4:      	lsr	w2, w2, #0
    69c8:      	lsr	w6, w6, #0
    69cc:      	lsr	w1, w1, #0
    69d0:      	lsr	w5, w5, #0
    69d4:      	lsr	w4, w4, #0
    69d8:      	ubfx	x3, x3, #8, #8
    69dc:      	lsr	w3, w3, #0
    69e0:      	mov	x19, x8
    69e4:      	add	x8, sp, #0x20
    69e8:      	fmov	s31, w1
    69ec:      	mov	w1, w5
    69f0:      	fmov	w5, s31
    69f4:      	fmov	s31, w2
    69f8:      	mov	w2, w3
    69fc:      	fmov	w3, s31
    6a00:      	fmov	s31, w4
    6a04:      	mov	w4, w6
    6a08:      	fmov	w6, s31
    6a0c:      	bl	0x6a0c <_stogir.vector-lanes.validate+0x254>
		0000000000006a0c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    6a10:      	add	x16, sp, #0x20
    6a14:      	ldr	x1, [x16]
    6a18:      	add	x16, sp, #0x20
    6a1c:      	ldr	x0, [x16, #0x8]
    6a20:      	add	x16, sp, #0x20
    6a24:      	ldr	x2, [x16, #0x10]
    6a28:      	b	0x6954 <_stogir.vector-lanes.validate+0x19c>
    6a2c:      	uxtb	w16, w4
    6a30:      	cmp	w16, wzr
    6a34:      	mov	x16, #0x3               ; =3
    6a38:      	mov	x17, #0x1               ; =1
    6a3c:      	csel	x6, x16, x17, ne
    6a40:      	sxtw	x3, w3
    6a44:      	lsr	w6, w6, #0
    6a48:      	sxtw	x6, w6
    6a4c:      	cmp	x3, x6
    6a50:      	b.ne	0x6ab4 <_stogir.vector-lanes.validate+0x2fc>
    6a54:      	add	x16, sp, #0x10
    6a58:      	ldr	w3, [x16]
    6a5c:      	add	x16, sp, #0x10
    6a60:      	ldr	w6, [x16, #0x4]
    6a64:      	cmp	x1, #0x3f
    6a68:      	b.ne	0x6a74 <_stogir.vector-lanes.validate+0x2bc>
    6a6c:      	movz	x1, #0x0, lsl #48
    6a70:      	b	0x6a80 <_stogir.vector-lanes.validate+0x2c8>
    6a74:      	add	x16, sp, #0x10
    6a78:      	ldr	w1, [x16, #0x8]
    6a7c:      	sxtw	x1, w1
    6a80:      	uxtb	w16, w4
    6a84:      	cmp	w16, wzr
    6a88:      	b.eq	0x69c0 <_stogir.vector-lanes.validate+0x208>
    6a8c:      	add	x16, sp, #0x10
    6a90:      	ldr	w4, [x16, #0xc]
    6a94:      	sxtw	x4, w4
    6a98:      	b	0x69c4 <_stogir.vector-lanes.validate+0x20c>
    6a9c:      	brk	#0
    6aa0:      	b	0x6a9c <_stogir.vector-lanes.validate+0x2e4>
    6aa4:      	mov	x19, x8
    6aa8:      	b	0x6940 <_stogir.vector-lanes.validate+0x188>
    6aac:      	mov	x19, x8
    6ab0:      	b	0x6940 <_stogir.vector-lanes.validate+0x188>
    6ab4:      	mov	x19, x8
    6ab8:      	b	0x6940 <_stogir.vector-lanes.validate+0x188>

0000000000006abc <_stogir.vector-comparison.node?>:
    6abc:      	sxtw	x1, w1
    6ac0:      	cmp	x1, #0x0
    6ac4:      	cset	w2, gt
    6ac8:      	movz	x16, #0x0, lsl #48
    6acc:      	sub	x3, x16, x1
    6ad0:      	sub	x4, x3, #0x1
    6ad4:      	uxtb	w16, w2
    6ad8:      	cmp	w16, wzr
    6adc:      	b.eq	0x6b1c <_stogir.vector-comparison.node?+0x60>
    6ae0:      	ldr	x3, [x0, #0x8]
    6ae4:      	cmp	x1, x3
    6ae8:      	b.ge	0x6b6c <_stogir.vector-comparison.node?+0xb0>
    6aec:      	add	x3, x0, #0x78
    6af0:      	ldr	x3, [x3, #0x8]
    6af4:      	cmp	x1, x3
    6af8:      	b.ge	0x6c48 <_stogir.vector-comparison.node?+0x18c>
    6afc:      	ldr	x3, [x0, #0x78]
    6b00:      	add	x3, x3, x1, lsl #2
    6b04:      	ldr	w3, [x3]
    6b08:      	sxtw	x3, w3
    6b0c:      	cmp	x3, #0x0
    6b10:      	cset	w3, ge
    6b14:      	ubfx	x3, x3, #0, #8
    6b18:      	b	0x6c4c <_stogir.vector-comparison.node?+0x190>
    6b1c:      	cmp	x1, #0x0
    6b20:      	b.ge	0x6b74 <_stogir.vector-comparison.node?+0xb8>
    6b24:      	add	x5, x0, #0x28
    6b28:      	add	x6, x0, #0x50
    6b2c:      	ldr	x5, [x5, #0x8]
    6b30:      	ldr	x6, [x6, #0x8]
    6b34:      	cmp	x5, x6
    6b38:      	b.ne	0x6b64 <_stogir.vector-comparison.node?+0xa8>
    6b3c:      	cmp	x3, x5
    6b40:      	b.gt	0x6c50 <_stogir.vector-comparison.node?+0x194>
    6b44:      	ldr	x3, [x0, #0x50]
    6b48:      	add	x3, x3, x4, lsl #2
    6b4c:      	ldr	w3, [x3]
    6b50:      	sxtw	x3, w3
    6b54:      	cmp	x3, #0x0
    6b58:      	cset	w3, gt
    6b5c:      	ubfx	x3, x3, #0, #8
    6b60:      	b	0x6c54 <_stogir.vector-comparison.node?+0x198>
    6b64:      	movz	x3, #0x0, lsl #48
    6b68:      	b	0x6b78 <_stogir.vector-comparison.node?+0xbc>
    6b6c:      	movz	x3, #0x0, lsl #48
    6b70:      	b	0x6b78 <_stogir.vector-comparison.node?+0xbc>
    6b74:      	movz	x3, #0x0, lsl #48
    6b78:      	cmp	x3, #0x0
    6b7c:      	b.eq	0x6bb0 <_stogir.vector-comparison.node?+0xf4>
    6b80:      	uxtb	w16, w2
    6b84:      	cmp	w16, wzr
    6b88:      	b.eq	0x6b9c <_stogir.vector-comparison.node?+0xe0>
    6b8c:      	ldr	x0, [x0]
    6b90:      	add	x0, x0, x1, lsl #4
    6b94:      	ldr	x0, [x0]
    6b98:      	b	0x6ba8 <_stogir.vector-comparison.node?+0xec>
    6b9c:      	ldr	x0, [x0, #0x28]
    6ba0:      	add	x0, x0, x4, lsl #4
    6ba4:      	ldr	x0, [x0]
    6ba8:      	mov	x1, #0x1                ; =1
    6bac:      	b	0x6bb8 <_stogir.vector-comparison.node?+0xfc>
    6bb0:      	movz	x1, #0x0, lsl #48
    6bb4:      	movz	x0, #0x0, lsl #48
    6bb8:      	lsr	w1, w1, #0
    6bbc:      	lsr	x16, x1, #0
    6bc0:      	cmp	x16, #0x1
    6bc4:      	b.eq	0x6be0 <_stogir.vector-comparison.node?+0x124>
    6bc8:      	b.lo	0x6bd0 <_stogir.vector-comparison.node?+0x114>
    6bcc:      	b	0x6be4 <_stogir.vector-comparison.node?+0x128>
    6bd0:      	cmp	x16, #0x0
    6bd4:      	b.eq	0x6bdc <_stogir.vector-comparison.node?+0x120>
    6bd8:      	b	0x6be4 <_stogir.vector-comparison.node?+0x128>
    6bdc:      	b	0x6be8 <_stogir.vector-comparison.node?+0x12c>
    6be0:      	b	0x6bf8 <_stogir.vector-comparison.node?+0x13c>
    6be4:      	b	0x6c70 <_stogir.vector-comparison.node?+0x1b4>
    6be8:      	movz	x0, #0x0, lsl #48
    6bec:      	b	0x6bf4 <_stogir.vector-comparison.node?+0x138>
    6bf0:      	movz	x0, #0x0, lsl #48
    6bf4:      	ret
    6bf8:      	uxtb	w1, w0
    6bfc:      	cmp	x1, #0xe
    6c00:      	b.lt	0x6bf0 <_stogir.vector-comparison.node?+0x134>
    6c04:      	cmp	x1, #0x19
    6c08:      	b.gt	0x6bf0 <_stogir.vector-comparison.node?+0x134>
    6c0c:      	lsr	w0, w0, #0
    6c10:      	ubfx	x0, x0, #8, #8
    6c14:      	cmp	x0, #0xf
    6c18:      	b.le	0x6c58 <_stogir.vector-comparison.node?+0x19c>
    6c1c:      	cmp	x0, #0x80
    6c20:      	b.ge	0x6c60 <_stogir.vector-comparison.node?+0x1a4>
    6c24:      	and	x0, x0, #0xf
    6c28:      	lsr	w0, w0, #0
    6c2c:      	sxtw	x0, w0
    6c30:      	cmp	x0, #0x1
    6c34:      	b.lt	0x6c68 <_stogir.vector-comparison.node?+0x1ac>
    6c38:      	cmp	x0, #0xd
    6c3c:      	cset	w0, le
    6c40:      	ubfx	x0, x0, #0, #8
    6c44:      	b	0x6c6c <_stogir.vector-comparison.node?+0x1b0>
    6c48:      	movz	x3, #0x0, lsl #48
    6c4c:      	b	0x6b70 <_stogir.vector-comparison.node?+0xb4>
    6c50:      	movz	x3, #0x0, lsl #48
    6c54:      	b	0x6b68 <_stogir.vector-comparison.node?+0xac>
    6c58:      	movz	x0, #0x0, lsl #48
    6c5c:      	b	0x6bf4 <_stogir.vector-comparison.node?+0x138>
    6c60:      	movz	x0, #0x0, lsl #48
    6c64:      	b	0x6c5c <_stogir.vector-comparison.node?+0x1a0>
    6c68:      	movz	x0, #0x0, lsl #48
    6c6c:      	b	0x6c64 <_stogir.vector-comparison.node?+0x1a8>
    6c70:      	brk	#0
    6c74:      	b	0x6c70 <_stogir.vector-comparison.node?+0x1b4>

0000000000006c78 <_stogir.vector-comparison.validate>:
    6c78:      	sub	sp, sp, #0x50
    6c7c:      	str	x29, [sp]
    6c80:      	str	x30, [sp, #0x8]
    6c84:      	mov	x29, sp
    6c88:      	str	x19, [sp, #0x40]
    6c8c:      	sxtw	x1, w1
    6c90:      	lsl	x3, x1, #2
    6c94:      	cmp	x1, #0x0
    6c98:      	cset	w4, gt
    6c9c:      	movz	x16, #0x0, lsl #48
    6ca0:      	sub	x5, x16, x1
    6ca4:      	sub	x6, x5, #0x1
    6ca8:      	uxtb	w16, w4
    6cac:      	cmp	w16, wzr
    6cb0:      	b.eq	0x6cf0 <_stogir.vector-comparison.validate+0x78>
    6cb4:      	ldr	x5, [x0, #0x8]
    6cb8:      	cmp	x1, x5
    6cbc:      	b.ge	0x6d40 <_stogir.vector-comparison.validate+0xc8>
    6cc0:      	add	x5, x0, #0x78
    6cc4:      	ldr	x5, [x5, #0x8]
    6cc8:      	cmp	x1, x5
    6ccc:      	b.ge	0x6e38 <_stogir.vector-comparison.validate+0x1c0>
    6cd0:      	ldr	x5, [x0, #0x78]
    6cd4:      	add	x5, x3, x5
    6cd8:      	ldr	w5, [x5]
    6cdc:      	sxtw	x5, w5
    6ce0:      	cmp	x5, #0x0
    6ce4:      	cset	w5, ge
    6ce8:      	ubfx	x5, x5, #0, #8
    6cec:      	b	0x6e3c <_stogir.vector-comparison.validate+0x1c4>
    6cf0:      	cmp	x1, #0x0
    6cf4:      	b.ge	0x6d48 <_stogir.vector-comparison.validate+0xd0>
    6cf8:      	add	x7, x0, #0x28
    6cfc:      	add	x9, x0, #0x50
    6d00:      	ldr	x7, [x7, #0x8]
    6d04:      	ldr	x9, [x9, #0x8]
    6d08:      	cmp	x7, x9
    6d0c:      	b.ne	0x6d38 <_stogir.vector-comparison.validate+0xc0>
    6d10:      	cmp	x5, x7
    6d14:      	b.gt	0x6e88 <_stogir.vector-comparison.validate+0x210>
    6d18:      	ldr	x5, [x0, #0x50]
    6d1c:      	add	x5, x5, x6, lsl #2
    6d20:      	ldr	w5, [x5]
    6d24:      	sxtw	x5, w5
    6d28:      	cmp	x5, #0x0
    6d2c:      	cset	w5, gt
    6d30:      	ubfx	x5, x5, #0, #8
    6d34:      	b	0x6e8c <_stogir.vector-comparison.validate+0x214>
    6d38:      	movz	x5, #0x0, lsl #48
    6d3c:      	b	0x6d4c <_stogir.vector-comparison.validate+0xd4>
    6d40:      	movz	x5, #0x0, lsl #48
    6d44:      	b	0x6d4c <_stogir.vector-comparison.validate+0xd4>
    6d48:      	movz	x5, #0x0, lsl #48
    6d4c:      	lsl	x7, x1, #4
    6d50:      	cmp	x5, #0x0
    6d54:      	b.eq	0x6d90 <_stogir.vector-comparison.validate+0x118>
    6d58:      	uxtb	w16, w4
    6d5c:      	cmp	w16, wzr
    6d60:      	b.eq	0x6d78 <_stogir.vector-comparison.validate+0x100>
    6d64:      	ldr	x4, [x0]
    6d68:      	add	x4, x7, x4
    6d6c:      	ldr	x5, [x4]
    6d70:      	ldr	x4, [x4, #0x8]
    6d74:      	b	0x6d88 <_stogir.vector-comparison.validate+0x110>
    6d78:      	ldr	x4, [x0, #0x28]
    6d7c:      	add	x4, x4, x6, lsl #4
    6d80:      	ldr	x5, [x4]
    6d84:      	ldr	x4, [x4, #0x8]
    6d88:      	mov	x6, #0x1                ; =1
    6d8c:      	b	0x6d9c <_stogir.vector-comparison.validate+0x124>
    6d90:      	movz	x6, #0x0, lsl #48
    6d94:      	movz	x5, #0x0, lsl #48
    6d98:      	movz	x4, #0x0, lsl #48
    6d9c:      	lsr	w6, w6, #0
    6da0:      	lsr	x16, x6, #0
    6da4:      	cmp	x16, #0x1
    6da8:      	b.eq	0x6dc4 <_stogir.vector-comparison.validate+0x14c>
    6dac:      	b.lo	0x6db4 <_stogir.vector-comparison.validate+0x13c>
    6db0:      	b	0x6dc8 <_stogir.vector-comparison.validate+0x150>
    6db4:      	cmp	x16, #0x0
    6db8:      	b.eq	0x6dc0 <_stogir.vector-comparison.validate+0x148>
    6dbc:      	b	0x6dc8 <_stogir.vector-comparison.validate+0x150>
    6dc0:      	b	0x6dcc <_stogir.vector-comparison.validate+0x154>
    6dc4:      	b	0x6e04 <_stogir.vector-comparison.validate+0x18c>
    6dc8:      	b	0x6f9c <_stogir.vector-comparison.validate+0x324>
    6dcc:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x1fc>
		0000000000006dcc:  ARM64_RELOC_PAGE21	l_stogir.409
    6dd0:      	ldr	x16, [x16]
		0000000000006dd0:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    6dd4:      	orr	x0, x16, xzr
    6dd8:      	mov	x19, x8
    6ddc:      	mov	x1, #0x1                ; =1
    6de0:      	mov	x2, #0x25               ; =37
    6de4:      	str	x1, [x19]
    6de8:      	str	x0, [x19, #0x8]
    6dec:      	str	x2, [x19, #0x10]
    6df0:      	ldr	x19, [sp, #0x40]
    6df4:      	ldr	x29, [sp]
    6df8:      	ldr	x30, [sp, #0x8]
    6dfc:      	add	sp, sp, #0x50
    6e00:      	ret
    6e04:      	add	x16, sp, #0x10
    6e08:      	str	x5, [x16]
    6e0c:      	add	x16, sp, #0x10
    6e10:      	str	x4, [x16, #0x8]
    6e14:      	cmp	x1, #0x0
    6e18:      	b.gt	0x6e40 <_stogir.vector-comparison.validate+0x1c8>
    6e1c:      	mov	x19, x8
    6e20:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x1fc>
		0000000000006e20:  ARM64_RELOC_PAGE21	l_stogir.410
    6e24:      	ldr	x16, [x16]
		0000000000006e24:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    6e28:      	orr	x0, x16, xzr
    6e2c:      	mov	x1, #0x1                ; =1
    6e30:      	mov	x2, #0x2b               ; =43
    6e34:      	b	0x6de4 <_stogir.vector-comparison.validate+0x16c>
    6e38:      	movz	x5, #0x0, lsl #48
    6e3c:      	b	0x6d44 <_stogir.vector-comparison.validate+0xcc>
    6e40:      	ldr	x4, [x0, #0x8]
    6e44:      	cmp	x1, x4
    6e48:      	b.ge	0x6e90 <_stogir.vector-comparison.validate+0x218>
    6e4c:      	add	x4, x0, #0x78
    6e50:      	ldr	x4, [x4, #0x8]
    6e54:      	cmp	x1, x4
    6e58:      	b.ge	0x6e90 <_stogir.vector-comparison.validate+0x218>
    6e5c:      	ldr	x1, [x0, #0x78]
    6e60:      	add	x1, x3, x1
    6e64:      	ldr	w1, [x1]
    6e68:      	sxtw	x1, w1
    6e6c:      	cmp	x1, #0x0
    6e70:      	b.lt	0x6e90 <_stogir.vector-comparison.validate+0x218>
    6e74:      	ldr	x1, [x0]
    6e78:      	add	x1, x7, x1
    6e7c:      	ldr	x1, [x1]
    6e80:      	mov	x4, #0x1                ; =1
    6e84:      	b	0x6e98 <_stogir.vector-comparison.validate+0x220>
    6e88:      	movz	x5, #0x0, lsl #48
    6e8c:      	b	0x6d3c <_stogir.vector-comparison.validate+0xc4>
    6e90:      	movz	x4, #0x0, lsl #48
    6e94:      	movz	x1, #0x0, lsl #48
    6e98:      	lsr	w4, w4, #0
    6e9c:      	lsr	x16, x4, #0
    6ea0:      	cmp	x16, #0x1
    6ea4:      	b.eq	0x6ec0 <_stogir.vector-comparison.validate+0x248>
    6ea8:      	b.lo	0x6eb0 <_stogir.vector-comparison.validate+0x238>
    6eac:      	b	0x6ec4 <_stogir.vector-comparison.validate+0x24c>
    6eb0:      	cmp	x16, #0x0
    6eb4:      	b.eq	0x6ebc <_stogir.vector-comparison.validate+0x244>
    6eb8:      	b	0x6ec4 <_stogir.vector-comparison.validate+0x24c>
    6ebc:      	b	0x6ec8 <_stogir.vector-comparison.validate+0x250>
    6ec0:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x258>
    6ec4:      	b	0x6fa4 <_stogir.vector-comparison.validate+0x32c>
    6ec8:      	mov	x19, x8
    6ecc:      	b	0x6e20 <_stogir.vector-comparison.validate+0x1a8>
    6ed0:      	uxtb	w4, w1
    6ed4:      	cmp	x4, #0xe
    6ed8:      	b.lt	0x6fac <_stogir.vector-comparison.validate+0x334>
    6edc:      	cmp	x4, #0x19
    6ee0:      	b.gt	0x6fb4 <_stogir.vector-comparison.validate+0x33c>
    6ee4:      	lsr	w1, w1, #0
    6ee8:      	ubfx	x1, x1, #8, #8
    6eec:      	cmp	x1, #0xf
    6ef0:      	b.le	0x6fbc <_stogir.vector-comparison.validate+0x344>
    6ef4:      	cmp	x1, #0x80
    6ef8:      	b.ge	0x6fc4 <_stogir.vector-comparison.validate+0x34c>
    6efc:      	and	x1, x1, #0xf
    6f00:      	lsr	w1, w1, #0
    6f04:      	sxtw	x1, w1
    6f08:      	cmp	x1, #0x1
    6f0c:      	b.lt	0x6fcc <_stogir.vector-comparison.validate+0x354>
    6f10:      	cmp	x1, #0xd
    6f14:      	b.gt	0x6fd4 <_stogir.vector-comparison.validate+0x35c>
    6f18:      	ldr	x1, [x0, #0x78]
    6f1c:      	add	x1, x3, x1
    6f20:      	ldr	w1, [x1]
    6f24:      	sxtw	x1, w1
    6f28:      	cmp	x1, #0x2
    6f2c:      	b.ne	0x6fdc <_stogir.vector-comparison.validate+0x364>
    6f30:      	lsr	w2, w2, #0
    6f34:      	add	x16, sp, #0x10
    6f38:      	ldr	w1, [x16]
    6f3c:      	uxtb	w3, w1
    6f40:      	add	x16, sp, #0x10
    6f44:      	ldr	w4, [x16, #0x4]
    6f48:      	lsr	w3, w3, #0
    6f4c:      	ubfx	x1, x1, #8, #8
    6f50:      	add	x16, sp, #0x10
    6f54:      	ldr	w5, [x16, #0x8]
    6f58:      	lsr	w4, w4, #0
    6f5c:      	lsr	w5, w5, #0
    6f60:      	lsr	w1, w1, #0
    6f64:      	mov	x19, x8
    6f68:      	add	x8, sp, #0x20
    6f6c:      	fmov	s31, w1
    6f70:      	mov	w1, w3
    6f74:      	mov	w3, w2
    6f78:      	fmov	w2, s31
    6f7c:      	bl	0x6f7c <_stogir.vector-comparison.validate+0x304>
		0000000000006f7c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    6f80:      	add	x16, sp, #0x20
    6f84:      	ldr	x1, [x16]
    6f88:      	add	x16, sp, #0x20
    6f8c:      	ldr	x0, [x16, #0x8]
    6f90:      	add	x16, sp, #0x20
    6f94:      	ldr	x2, [x16, #0x10]
    6f98:      	b	0x6e34 <_stogir.vector-comparison.validate+0x1bc>
    6f9c:      	brk	#0
    6fa0:      	b	0x6f9c <_stogir.vector-comparison.validate+0x324>
    6fa4:      	brk	#0
    6fa8:      	b	0x6fa4 <_stogir.vector-comparison.validate+0x32c>
    6fac:      	mov	x19, x8
    6fb0:      	b	0x6e20 <_stogir.vector-comparison.validate+0x1a8>
    6fb4:      	mov	x19, x8
    6fb8:      	b	0x6e20 <_stogir.vector-comparison.validate+0x1a8>
    6fbc:      	mov	x19, x8
    6fc0:      	b	0x6e20 <_stogir.vector-comparison.validate+0x1a8>
    6fc4:      	mov	x19, x8
    6fc8:      	b	0x6e20 <_stogir.vector-comparison.validate+0x1a8>
    6fcc:      	mov	x19, x8
    6fd0:      	b	0x6e20 <_stogir.vector-comparison.validate+0x1a8>
    6fd4:      	mov	x19, x8
    6fd8:      	b	0x6e20 <_stogir.vector-comparison.validate+0x1a8>
    6fdc:      	mov	x19, x8
    6fe0:      	b	0x6e20 <_stogir.vector-comparison.validate+0x1a8>

0000000000006fe4 <_stogir.vector-arithmetic.node?>:
    6fe4:      	sxtw	x1, w1
    6fe8:      	cmp	x1, #0x0
    6fec:      	cset	w2, gt
    6ff0:      	movz	x16, #0x0, lsl #48
    6ff4:      	sub	x3, x16, x1
    6ff8:      	sub	x4, x3, #0x1
    6ffc:      	uxtb	w16, w2
    7000:      	cmp	w16, wzr
    7004:      	b.eq	0x7044 <_stogir.vector-arithmetic.node?+0x60>
    7008:      	ldr	x3, [x0, #0x8]
    700c:      	cmp	x1, x3
    7010:      	b.ge	0x7094 <_stogir.vector-arithmetic.node?+0xb0>
    7014:      	add	x3, x0, #0x78
    7018:      	ldr	x3, [x3, #0x8]
    701c:      	cmp	x1, x3
    7020:      	b.ge	0x71b8 <_stogir.vector-arithmetic.node?+0x1d4>
    7024:      	ldr	x3, [x0, #0x78]
    7028:      	add	x3, x3, x1, lsl #2
    702c:      	ldr	w3, [x3]
    7030:      	sxtw	x3, w3
    7034:      	cmp	x3, #0x0
    7038:      	cset	w3, ge
    703c:      	ubfx	x3, x3, #0, #8
    7040:      	b	0x71bc <_stogir.vector-arithmetic.node?+0x1d8>
    7044:      	cmp	x1, #0x0
    7048:      	b.ge	0x709c <_stogir.vector-arithmetic.node?+0xb8>
    704c:      	add	x5, x0, #0x28
    7050:      	add	x6, x0, #0x50
    7054:      	ldr	x5, [x5, #0x8]
    7058:      	ldr	x6, [x6, #0x8]
    705c:      	cmp	x5, x6
    7060:      	b.ne	0x708c <_stogir.vector-arithmetic.node?+0xa8>
    7064:      	cmp	x3, x5
    7068:      	b.gt	0x71c8 <_stogir.vector-arithmetic.node?+0x1e4>
    706c:      	ldr	x3, [x0, #0x50]
    7070:      	add	x3, x3, x4, lsl #2
    7074:      	ldr	w3, [x3]
    7078:      	sxtw	x3, w3
    707c:      	cmp	x3, #0x0
    7080:      	cset	w3, gt
    7084:      	ubfx	x3, x3, #0, #8
    7088:      	b	0x71cc <_stogir.vector-arithmetic.node?+0x1e8>
    708c:      	movz	x3, #0x0, lsl #48
    7090:      	b	0x70a0 <_stogir.vector-arithmetic.node?+0xbc>
    7094:      	movz	x3, #0x0, lsl #48
    7098:      	b	0x70a0 <_stogir.vector-arithmetic.node?+0xbc>
    709c:      	movz	x3, #0x0, lsl #48
    70a0:      	cmp	x3, #0x0
    70a4:      	b.eq	0x70d8 <_stogir.vector-arithmetic.node?+0xf4>
    70a8:      	uxtb	w16, w2
    70ac:      	cmp	w16, wzr
    70b0:      	b.eq	0x70c4 <_stogir.vector-arithmetic.node?+0xe0>
    70b4:      	ldr	x0, [x0]
    70b8:      	add	x0, x0, x1, lsl #4
    70bc:      	ldr	x0, [x0]
    70c0:      	b	0x70d0 <_stogir.vector-arithmetic.node?+0xec>
    70c4:      	ldr	x0, [x0, #0x28]
    70c8:      	add	x0, x0, x4, lsl #4
    70cc:      	ldr	x0, [x0]
    70d0:      	mov	x1, #0x1                ; =1
    70d4:      	b	0x70e0 <_stogir.vector-arithmetic.node?+0xfc>
    70d8:      	movz	x1, #0x0, lsl #48
    70dc:      	movz	x0, #0x0, lsl #48
    70e0:      	lsr	w1, w1, #0
    70e4:      	lsr	x16, x1, #0
    70e8:      	cmp	x16, #0x1
    70ec:      	b.eq	0x7108 <_stogir.vector-arithmetic.node?+0x124>
    70f0:      	b.lo	0x70f8 <_stogir.vector-arithmetic.node?+0x114>
    70f4:      	b	0x710c <_stogir.vector-arithmetic.node?+0x128>
    70f8:      	cmp	x16, #0x0
    70fc:      	b.eq	0x7104 <_stogir.vector-arithmetic.node?+0x120>
    7100:      	b	0x710c <_stogir.vector-arithmetic.node?+0x128>
    7104:      	b	0x7110 <_stogir.vector-arithmetic.node?+0x12c>
    7108:      	b	0x7120 <_stogir.vector-arithmetic.node?+0x13c>
    710c:      	b	0x71d8 <_stogir.vector-arithmetic.node?+0x1f4>
    7110:      	movz	x0, #0x0, lsl #48
    7114:      	b	0x711c <_stogir.vector-arithmetic.node?+0x138>
    7118:      	movz	x0, #0x0, lsl #48
    711c:      	ret
    7120:      	uxtb	w1, w0
    7124:      	cmp	x1, #0x1f
    7128:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    712c:      	cmp	x1, #0x20
    7130:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7134:      	cmp	x1, #0x2d
    7138:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    713c:      	cmp	x1, #0x36
    7140:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7144:      	cmp	x1, #0x37
    7148:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    714c:      	cmp	x1, #0x38
    7150:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7154:      	cmp	x1, #0x39
    7158:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    715c:      	cmp	x1, #0x3a
    7160:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7164:      	cmp	x1, #0x3b
    7168:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    716c:      	cmp	x1, #0x31
    7170:      	b.lt	0x71e0 <_stogir.vector-arithmetic.node?+0x1fc>
    7174:      	cmp	x1, #0x35
    7178:      	b.gt	0x71e0 <_stogir.vector-arithmetic.node?+0x1fc>
    717c:      	lsr	w0, w0, #0
    7180:      	ubfx	x0, x0, #8, #8
    7184:      	cmp	x0, #0xf
    7188:      	b.le	0x7118 <_stogir.vector-arithmetic.node?+0x134>
    718c:      	cmp	x0, #0x80
    7190:      	b.ge	0x71c0 <_stogir.vector-arithmetic.node?+0x1dc>
    7194:      	and	x0, x0, #0xf
    7198:      	lsr	w0, w0, #0
    719c:      	sxtw	x0, w0
    71a0:      	cmp	x0, #0x1
    71a4:      	b.lt	0x71d0 <_stogir.vector-arithmetic.node?+0x1ec>
    71a8:      	cmp	x0, #0xd
    71ac:      	cset	w0, le
    71b0:      	ubfx	x0, x0, #0, #8
    71b4:      	b	0x71d4 <_stogir.vector-arithmetic.node?+0x1f0>
    71b8:      	movz	x3, #0x0, lsl #48
    71bc:      	b	0x7098 <_stogir.vector-arithmetic.node?+0xb4>
    71c0:      	movz	x0, #0x0, lsl #48
    71c4:      	b	0x711c <_stogir.vector-arithmetic.node?+0x138>
    71c8:      	movz	x3, #0x0, lsl #48
    71cc:      	b	0x7090 <_stogir.vector-arithmetic.node?+0xac>
    71d0:      	movz	x0, #0x0, lsl #48
    71d4:      	b	0x71c4 <_stogir.vector-arithmetic.node?+0x1e0>
    71d8:      	brk	#0
    71dc:      	b	0x71d8 <_stogir.vector-arithmetic.node?+0x1f4>
    71e0:      	cmp	x1, #0x1a
    71e4:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    71e8:      	cmp	x1, #0x1b
    71ec:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    71f0:      	cmp	x1, #0x1c
    71f4:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    71f8:      	cmp	x1, #0x1d
    71fc:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7200:      	cmp	x1, #0x1e
    7204:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7208:      	cmp	x1, #0x2e
    720c:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7210:      	cmp	x1, #0x2f
    7214:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7218:      	cmp	x1, #0x30
    721c:      	b.eq	0x717c <_stogir.vector-arithmetic.node?+0x198>
    7220:      	movz	x0, #0x0, lsl #48
    7224:      	b	0x711c <_stogir.vector-arithmetic.node?+0x138>

0000000000007228 <_stogir.vector-arithmetic.validate>:
    7228:      	sub	sp, sp, #0x60
    722c:      	str	x29, [sp]
    7230:      	str	x30, [sp, #0x8]
    7234:      	mov	x29, sp
    7238:      	str	x19, [sp, #0x40]
    723c:      	str	x20, [sp, #0x48]
    7240:      	str	x21, [sp, #0x50]
    7244:      	str	x22, [sp, #0x58]
    7248:      	sxtw	x2, w1
    724c:      	lsl	x19, x2, #2
    7250:      	cmp	x2, #0x0
    7254:      	cset	w3, gt
    7258:      	movz	x16, #0x0, lsl #48
    725c:      	sub	x4, x16, x2
    7260:      	sub	x5, x4, #0x1
    7264:      	uxtb	w16, w3
    7268:      	cmp	w16, wzr
    726c:      	b.eq	0x72ac <_stogir.vector-arithmetic.validate+0x84>
    7270:      	ldr	x4, [x0, #0x8]
    7274:      	cmp	x2, x4
    7278:      	b.ge	0x72fc <_stogir.vector-arithmetic.validate+0xd4>
    727c:      	add	x4, x0, #0x78
    7280:      	ldr	x4, [x4, #0x8]
    7284:      	cmp	x2, x4
    7288:      	b.ge	0x73fc <_stogir.vector-arithmetic.validate+0x1d4>
    728c:      	ldr	x4, [x0, #0x78]
    7290:      	add	x4, x19, x4
    7294:      	ldr	w4, [x4]
    7298:      	sxtw	x4, w4
    729c:      	cmp	x4, #0x0
    72a0:      	cset	w4, ge
    72a4:      	ubfx	x4, x4, #0, #8
    72a8:      	b	0x7400 <_stogir.vector-arithmetic.validate+0x1d8>
    72ac:      	cmp	x2, #0x0
    72b0:      	b.ge	0x7304 <_stogir.vector-arithmetic.validate+0xdc>
    72b4:      	add	x6, x0, #0x28
    72b8:      	add	x7, x0, #0x50
    72bc:      	ldr	x6, [x6, #0x8]
    72c0:      	ldr	x7, [x7, #0x8]
    72c4:      	cmp	x6, x7
    72c8:      	b.ne	0x72f4 <_stogir.vector-arithmetic.validate+0xcc>
    72cc:      	cmp	x4, x6
    72d0:      	b.gt	0x7498 <_stogir.vector-arithmetic.validate+0x270>
    72d4:      	ldr	x4, [x0, #0x50]
    72d8:      	add	x4, x4, x5, lsl #2
    72dc:      	ldr	w4, [x4]
    72e0:      	sxtw	x4, w4
    72e4:      	cmp	x4, #0x0
    72e8:      	cset	w4, gt
    72ec:      	ubfx	x4, x4, #0, #8
    72f0:      	b	0x749c <_stogir.vector-arithmetic.validate+0x274>
    72f4:      	movz	x4, #0x0, lsl #48
    72f8:      	b	0x7308 <_stogir.vector-arithmetic.validate+0xe0>
    72fc:      	movz	x4, #0x0, lsl #48
    7300:      	b	0x7308 <_stogir.vector-arithmetic.validate+0xe0>
    7304:      	movz	x4, #0x0, lsl #48
    7308:      	cmp	x4, #0x0
    730c:      	b.eq	0x7348 <_stogir.vector-arithmetic.validate+0x120>
    7310:      	uxtb	w16, w3
    7314:      	cmp	w16, wzr
    7318:      	b.eq	0x7330 <_stogir.vector-arithmetic.validate+0x108>
    731c:      	ldr	x3, [x0]
    7320:      	add	x3, x3, x2, lsl #4
    7324:      	ldr	x20, [x3]
    7328:      	ldr	x3, [x3, #0x8]
    732c:      	b	0x7340 <_stogir.vector-arithmetic.validate+0x118>
    7330:      	ldr	x3, [x0, #0x28]
    7334:      	add	x3, x3, x5, lsl #4
    7338:      	ldr	x20, [x3]
    733c:      	ldr	x3, [x3, #0x8]
    7340:      	mov	x4, #0x1                ; =1
    7344:      	b	0x7354 <_stogir.vector-arithmetic.validate+0x12c>
    7348:      	movz	x4, #0x0, lsl #48
    734c:      	movz	x20, #0x0, lsl #48
    7350:      	movz	x3, #0x0, lsl #48
    7354:      	lsr	w4, w4, #0
    7358:      	lsr	x16, x4, #0
    735c:      	cmp	x16, #0x1
    7360:      	b.eq	0x737c <_stogir.vector-arithmetic.validate+0x154>
    7364:      	b.lo	0x736c <_stogir.vector-arithmetic.validate+0x144>
    7368:      	b	0x7380 <_stogir.vector-arithmetic.validate+0x158>
    736c:      	cmp	x16, #0x0
    7370:      	b.eq	0x7378 <_stogir.vector-arithmetic.validate+0x150>
    7374:      	b	0x7380 <_stogir.vector-arithmetic.validate+0x158>
    7378:      	b	0x7384 <_stogir.vector-arithmetic.validate+0x15c>
    737c:      	b	0x73a0 <_stogir.vector-arithmetic.validate+0x178>
    7380:      	b	0x754c <_stogir.vector-arithmetic.validate+0x324>
    7384:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		0000000000007384:  ARM64_RELOC_PAGE21	l_stogir.411
    7388:      	ldr	x16, [x16]
		0000000000007388:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    738c:      	orr	x0, x16, xzr
    7390:      	mov	x21, x8
    7394:      	mov	x1, #0x1                ; =1
    7398:      	mov	x2, #0x25               ; =37
    739c:      	b	0x73d0 <_stogir.vector-arithmetic.validate+0x1a8>
    73a0:      	add	x16, sp, #0x10
    73a4:      	str	x20, [x16]
    73a8:      	add	x16, sp, #0x10
    73ac:      	str	x3, [x16, #0x8]
    73b0:      	cmp	x2, #0x0
    73b4:      	b.gt	0x7404 <_stogir.vector-arithmetic.validate+0x1dc>
    73b8:      	mov	x21, x8
    73bc:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		00000000000073bc:  ARM64_RELOC_PAGE21	l_stogir.412
    73c0:      	ldr	x16, [x16]
		00000000000073c0:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    73c4:      	orr	x0, x16, xzr
    73c8:      	mov	x1, #0x1                ; =1
    73cc:      	mov	x2, #0x2b               ; =43
    73d0:      	str	x1, [x21]
    73d4:      	str	x0, [x21, #0x8]
    73d8:      	str	x2, [x21, #0x10]
    73dc:      	ldr	x19, [sp, #0x40]
    73e0:      	ldr	x20, [sp, #0x48]
    73e4:      	ldr	x21, [sp, #0x50]
    73e8:      	ldr	x22, [sp, #0x58]
    73ec:      	ldr	x29, [sp]
    73f0:      	ldr	x30, [sp, #0x8]
    73f4:      	add	sp, sp, #0x60
    73f8:      	ret
    73fc:      	movz	x4, #0x0, lsl #48
    7400:      	b	0x7300 <_stogir.vector-arithmetic.validate+0xd8>
    7404:      	lsr	w1, w1, #0
    7408:      	mov	x21, x8
    740c:      	mov	x22, x0
    7410:      	bl	0x7410 <_stogir.vector-arithmetic.validate+0x1e8>
		0000000000007410:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    7414:      	cmp	x0, #0x0
    7418:      	b.eq	0x73bc <_stogir.vector-arithmetic.validate+0x194>
    741c:      	uxtb	w20, w20
    7420:      	orr	x0, x20, xzr
    7424:      	ldr	x1, [x22, #0x78]
    7428:      	cmp	x0, #0x1d
    742c:      	cset	w2, eq
    7430:      	cmp	x0, #0x1e
    7434:      	cset	w3, eq
    7438:      	add	x1, x19, x1
    743c:      	ldr	w1, [x1]
    7440:      	cmp	x0, #0x1f
    7444:      	b.eq	0x74fc <_stogir.vector-arithmetic.validate+0x2d4>
    7448:      	cmp	x0, #0x20
    744c:      	b.eq	0x74fc <_stogir.vector-arithmetic.validate+0x2d4>
    7450:      	cmp	x0, #0x2d
    7454:      	b.eq	0x74fc <_stogir.vector-arithmetic.validate+0x2d4>
    7458:      	cmp	x0, #0x36
    745c:      	b.eq	0x74fc <_stogir.vector-arithmetic.validate+0x2d4>
    7460:      	cmp	x0, #0x37
    7464:      	b.eq	0x74fc <_stogir.vector-arithmetic.validate+0x2d4>
    7468:      	cmp	x0, #0x38
    746c:      	b.eq	0x74fc <_stogir.vector-arithmetic.validate+0x2d4>
    7470:      	cmp	x0, #0x39
    7474:      	b.eq	0x74fc <_stogir.vector-arithmetic.validate+0x2d4>
    7478:      	uxtb	w16, w2
    747c:      	cmp	w16, wzr
    7480:      	b.ne	0x7554 <_stogir.vector-arithmetic.validate+0x32c>
    7484:      	uxtb	w16, w3
    7488:      	cmp	w16, wzr
    748c:      	b.ne	0x7554 <_stogir.vector-arithmetic.validate+0x32c>
    7490:      	mov	x0, #0x2                ; =2
    7494:      	b	0x7558 <_stogir.vector-arithmetic.validate+0x330>
    7498:      	movz	x4, #0x0, lsl #48
    749c:      	b	0x72f8 <_stogir.vector-arithmetic.validate+0xd0>
    74a0:      	add	x16, sp, #0x10
    74a4:      	ldr	w2, [x16, #0xc]
    74a8:      	sxtw	x2, w2
    74ac:      	lsr	w1, w1, #0
    74b0:      	lsr	w4, w4, #0
    74b4:      	lsr	w20, w20, #0
    74b8:      	lsr	w2, w2, #0
    74bc:      	ubfx	x0, x0, #8, #8
    74c0:      	lsr	w0, w0, #0
    74c4:      	add	x8, sp, #0x20
    74c8:      	mov	w3, w1
    74cc:      	mov	w1, w20
    74d0:      	mov	w5, w2
    74d4:      	mov	w2, w0
    74d8:      	mov	x0, x22
    74dc:      	bl	0x74dc <_stogir.vector-arithmetic.validate+0x2b4>
		00000000000074dc:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    74e0:      	add	x16, sp, #0x20
    74e4:      	ldr	x1, [x16]
    74e8:      	add	x16, sp, #0x20
    74ec:      	ldr	x0, [x16, #0x8]
    74f0:      	add	x16, sp, #0x20
    74f4:      	ldr	x2, [x16, #0x10]
    74f8:      	b	0x73d0 <_stogir.vector-arithmetic.validate+0x1a8>
    74fc:      	mov	x0, #0x1                ; =1
    7500:      	sxtw	x1, w1
    7504:      	lsr	w0, w0, #0
    7508:      	sxtw	x0, w0
    750c:      	cmp	x1, x0
    7510:      	b.ne	0x73bc <_stogir.vector-arithmetic.validate+0x194>
    7514:      	add	x16, sp, #0x10
    7518:      	ldr	w0, [x16]
    751c:      	add	x16, sp, #0x10
    7520:      	ldr	w1, [x16, #0x4]
    7524:      	add	x16, sp, #0x10
    7528:      	ldr	w4, [x16, #0x8]
    752c:      	uxtb	w16, w2
    7530:      	cmp	w16, wzr
    7534:      	b.ne	0x74a0 <_stogir.vector-arithmetic.validate+0x278>
    7538:      	uxtb	w16, w3
    753c:      	cmp	w16, wzr
    7540:      	b.ne	0x74a0 <_stogir.vector-arithmetic.validate+0x278>
    7544:      	movz	x2, #0x0, lsl #48
    7548:      	b	0x74ac <_stogir.vector-arithmetic.validate+0x284>
    754c:      	brk	#0
    7550:      	b	0x754c <_stogir.vector-arithmetic.validate+0x324>
    7554:      	mov	x0, #0x3                ; =3
    7558:      	b	0x7500 <_stogir.vector-arithmetic.validate+0x2d8>

000000000000755c <_stogir.vector.memory-inputs>:
    755c:      	sub	sp, sp, #0x40
    7560:      	str	x29, [sp]
    7564:      	str	x30, [sp, #0x8]
    7568:      	mov	x29, sp
    756c:      	str	x19, [sp, #0x10]
    7570:      	str	x20, [sp, #0x18]
    7574:      	str	x21, [sp, #0x20]
    7578:      	str	x22, [sp, #0x28]
    757c:      	str	x23, [sp, #0x30]
    7580:      	str	x24, [sp, #0x38]
    7584:      	sxtw	x5, w1
    7588:      	cmp	x5, #0xf
    758c:      	b.le	0x7a1c <_stogir.vector.memory-inputs+0x4c0>
    7590:      	cmp	x5, #0x80
    7594:      	b.ge	0x7a24 <_stogir.vector.memory-inputs+0x4c8>
    7598:      	and	x6, x5, #0xf
    759c:      	lsr	w6, w6, #0
    75a0:      	sxtw	x6, w6
    75a4:      	cmp	x6, #0x1
    75a8:      	b.lt	0x7a2c <_stogir.vector.memory-inputs+0x4d0>
    75ac:      	and	x5, x5, #0xf
    75b0:      	lsr	w5, w5, #0
    75b4:      	sxtw	x5, w5
    75b8:      	cmp	x5, #0xd
    75bc:      	b.gt	0x7a34 <_stogir.vector.memory-inputs+0x4d8>
    75c0:      	lsr	w1, w1, #0
    75c4:      	lsr	w2, w2, #0
    75c8:      	mov	x19, x8
    75cc:      	mov	x20, x0
    75d0:      	mov	w0, w1
    75d4:      	mov	w21, w1
    75d8:      	mov	w1, w2
    75dc:      	mov	w22, w2
    75e0:      	mov	w23, w3
    75e4:      	mov	w24, w4
    75e8:      	bl	0x75e8 <_stogir.vector.memory-inputs+0x8c>
		00000000000075e8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    75ec:      	lsr	w0, w0, #0
    75f0:      	sxtw	x0, w0
    75f4:      	cmp	x0, #0x0
    75f8:      	b.le	0x765c <_stogir.vector.memory-inputs+0x100>
    75fc:      	sxtw	x23, w23
    7600:      	cmp	x23, #0x0
    7604:      	cset	w0, gt
    7608:      	movz	x16, #0x0, lsl #48
    760c:      	sub	x1, x16, x23
    7610:      	sub	x2, x1, #0x1
    7614:      	uxtb	w16, w0
    7618:      	cmp	w16, wzr
    761c:      	b.eq	0x7738 <_stogir.vector.memory-inputs+0x1dc>
    7620:      	ldr	x1, [x20, #0x8]
    7624:      	cmp	x23, x1
    7628:      	b.ge	0x7730 <_stogir.vector.memory-inputs+0x1d4>
    762c:      	add	x1, x20, #0x78
    7630:      	ldr	x1, [x1, #0x8]
    7634:      	cmp	x23, x1
    7638:      	b.ge	0x77d8 <_stogir.vector.memory-inputs+0x27c>
    763c:      	ldr	x1, [x20, #0x78]
    7640:      	add	x1, x1, x23, lsl #2
    7644:      	ldr	w1, [x1]
    7648:      	sxtw	x1, w1
    764c:      	cmp	x1, #0x0
    7650:      	cset	w1, ge
    7654:      	ubfx	x1, x1, #0, #8
    7658:      	b	0x77dc <_stogir.vector.memory-inputs+0x280>
    765c:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		000000000000765c:  ARM64_RELOC_PAGE21	l_stogir.413
    7660:      	ldr	x16, [x16]
		0000000000007660:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    7664:      	orr	x0, x16, xzr
    7668:      	mov	x1, #0x1                ; =1
    766c:      	mov	x2, #0x32               ; =50
    7670:      	str	x1, [x19]
    7674:      	str	x0, [x19, #0x8]
    7678:      	str	x2, [x19, #0x10]
    767c:      	ldr	x19, [sp, #0x10]
    7680:      	ldr	x20, [sp, #0x18]
    7684:      	ldr	x21, [sp, #0x20]
    7688:      	ldr	x22, [sp, #0x28]
    768c:      	ldr	x23, [sp, #0x30]
    7690:      	ldr	x24, [sp, #0x38]
    7694:      	ldr	x29, [sp]
    7698:      	ldr	x30, [sp, #0x8]
    769c:      	add	sp, sp, #0x40
    76a0:      	ret
    76a4:      	movz	x1, #0x0, lsl #48
    76a8:      	movz	x0, #0x0, lsl #48
    76ac:      	lsr	w1, w1, #0
    76b0:      	lsr	x16, x1, #0
    76b4:      	cmp	x16, #0x1
    76b8:      	b.eq	0x76d4 <_stogir.vector.memory-inputs+0x178>
    76bc:      	b.lo	0x76c4 <_stogir.vector.memory-inputs+0x168>
    76c0:      	b	0x76d8 <_stogir.vector.memory-inputs+0x17c>
    76c4:      	cmp	x16, #0x0
    76c8:      	b.eq	0x76d0 <_stogir.vector.memory-inputs+0x174>
    76cc:      	b	0x76d8 <_stogir.vector.memory-inputs+0x17c>
    76d0:      	b	0x76dc <_stogir.vector.memory-inputs+0x180>
    76d4:      	b	0x7780 <_stogir.vector.memory-inputs+0x224>
    76d8:      	b	0x7a04 <_stogir.vector.memory-inputs+0x4a8>
    76dc:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		00000000000076dc:  ARM64_RELOC_PAGE21	l_stogir.414
    76e0:      	ldr	x16, [x16]
		00000000000076e0:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    76e4:      	orr	x0, x16, xzr
    76e8:      	mov	x1, #0x1                ; =1
    76ec:      	mov	x2, #0x1d               ; =29
    76f0:      	b	0x7670 <_stogir.vector.memory-inputs+0x114>
    76f4:      	ldr	x0, [x20, #0x28]
    76f8:      	add	x0, x0, x2, lsl #4
    76fc:      	ldr	x0, [x0]
    7700:      	mov	x1, #0x1                ; =1
    7704:      	b	0x76ac <_stogir.vector.memory-inputs+0x150>
    7708:      	movz	x1, #0x0, lsl #48
    770c:      	cmp	x1, #0x0
    7710:      	b.eq	0x76a4 <_stogir.vector.memory-inputs+0x148>
    7714:      	uxtb	w16, w0
    7718:      	cmp	w16, wzr
    771c:      	b.eq	0x76f4 <_stogir.vector.memory-inputs+0x198>
    7720:      	ldr	x0, [x20]
    7724:      	add	x0, x0, x23, lsl #4
    7728:      	ldr	x0, [x0]
    772c:      	b	0x7700 <_stogir.vector.memory-inputs+0x1a4>
    7730:      	movz	x1, #0x0, lsl #48
    7734:      	b	0x770c <_stogir.vector.memory-inputs+0x1b0>
    7738:      	cmp	x23, #0x0
    773c:      	b.ge	0x7708 <_stogir.vector.memory-inputs+0x1ac>
    7740:      	add	x3, x20, #0x28
    7744:      	add	x4, x20, #0x50
    7748:      	ldr	x3, [x3, #0x8]
    774c:      	ldr	x4, [x4, #0x8]
    7750:      	cmp	x3, x4
    7754:      	b.ne	0x77d0 <_stogir.vector.memory-inputs+0x274>
    7758:      	cmp	x1, x3
    775c:      	b.gt	0x77e0 <_stogir.vector.memory-inputs+0x284>
    7760:      	ldr	x1, [x20, #0x50]
    7764:      	add	x1, x1, x2, lsl #2
    7768:      	ldr	w1, [x1]
    776c:      	sxtw	x1, w1
    7770:      	cmp	x1, #0x0
    7774:      	cset	w1, gt
    7778:      	ubfx	x1, x1, #0, #8
    777c:      	b	0x77e4 <_stogir.vector.memory-inputs+0x288>
    7780:      	cmp	x23, #0x0
    7784:      	b.le	0x77b8 <_stogir.vector.memory-inputs+0x25c>
    7788:      	uxtb	w0, w0
    778c:      	cmp	x0, #0x83
    7790:      	cset	w1, lt
    7794:      	uxtb	w16, w1
    7798:      	cmp	w16, wzr
    779c:      	b.eq	0x77e8 <_stogir.vector.memory-inputs+0x28c>
    77a0:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		00000000000077a0:  ARM64_RELOC_PAGE21	l_stogir.415
    77a4:      	ldr	x16, [x16]
		00000000000077a4:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    77a8:      	orr	x2, x16, xzr
    77ac:      	add	x2, x0, x2
    77b0:      	ldrb	w2, [x2]
    77b4:      	b	0x77ec <_stogir.vector.memory-inputs+0x290>
    77b8:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		00000000000077b8:  ARM64_RELOC_PAGE21	l_stogir.416
    77bc:      	ldr	x16, [x16]
		00000000000077bc:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    77c0:      	orr	x0, x16, xzr
    77c4:      	mov	x1, #0x1                ; =1
    77c8:      	mov	x2, #0x2c               ; =44
    77cc:      	b	0x76f0 <_stogir.vector.memory-inputs+0x194>
    77d0:      	movz	x1, #0x0, lsl #48
    77d4:      	b	0x770c <_stogir.vector.memory-inputs+0x1b0>
    77d8:      	movz	x1, #0x0, lsl #48
    77dc:      	b	0x7734 <_stogir.vector.memory-inputs+0x1d8>
    77e0:      	movz	x1, #0x0, lsl #48
    77e4:      	b	0x77d4 <_stogir.vector.memory-inputs+0x278>
    77e8:      	movz	x2, #0x0, lsl #48
    77ec:      	uxtb	w2, w2
    77f0:      	and	x2, x2, #0x1
    77f4:      	uxtb	w2, w2
    77f8:      	cmp	x2, #0x0
    77fc:      	b.eq	0x77b8 <_stogir.vector.memory-inputs+0x25c>
    7800:      	uxtb	w16, w1
    7804:      	cmp	w16, wzr
    7808:      	b.eq	0x7824 <_stogir.vector.memory-inputs+0x2c8>
    780c:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		000000000000780c:  ARM64_RELOC_PAGE21	l_stogir.415
    7810:      	ldr	x16, [x16]
		0000000000007810:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    7814:      	orr	x1, x16, xzr
    7818:      	add	x0, x0, x1
    781c:      	ldrb	w0, [x0]
    7820:      	b	0x7828 <_stogir.vector.memory-inputs+0x2cc>
    7824:      	movz	x0, #0x0, lsl #48
    7828:      	uxtb	w0, w0
    782c:      	and	x0, x0, #0x4
    7830:      	uxtb	w0, w0
    7834:      	cmp	x0, #0x0
    7838:      	cset	w0, eq
    783c:      	uxtb	w16, w0
    7840:      	cmp	w16, wzr
    7844:      	cset	x0, eq
    7848:      	cmp	x0, #0x0
    784c:      	b.ne	0x77b8 <_stogir.vector.memory-inputs+0x25c>
    7850:      	sxtw	x24, w24
    7854:      	cmp	x24, #0x0
    7858:      	cset	w0, gt
    785c:      	movz	x16, #0x0, lsl #48
    7860:      	sub	x1, x16, x24
    7864:      	sub	x2, x1, #0x1
    7868:      	uxtb	w16, w0
    786c:      	cmp	w16, wzr
    7870:      	b.eq	0x78c8 <_stogir.vector.memory-inputs+0x36c>
    7874:      	ldr	x1, [x20, #0x8]
    7878:      	cmp	x24, x1
    787c:      	b.ge	0x7910 <_stogir.vector.memory-inputs+0x3b4>
    7880:      	add	x1, x20, #0x78
    7884:      	ldr	x1, [x1, #0x8]
    7888:      	cmp	x24, x1
    788c:      	b.ge	0x79fc <_stogir.vector.memory-inputs+0x4a0>
    7890:      	ldr	x1, [x20, #0x78]
    7894:      	add	x1, x1, x24, lsl #2
    7898:      	ldr	w1, [x1]
    789c:      	sxtw	x1, w1
    78a0:      	cmp	x1, #0x0
    78a4:      	cset	w1, ge
    78a8:      	ubfx	x1, x1, #0, #8
    78ac:      	b	0x7a00 <_stogir.vector.memory-inputs+0x4a4>
    78b0:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		00000000000078b0:  ARM64_RELOC_PAGE21	l_stogir.417
    78b4:      	ldr	x16, [x16]
		00000000000078b4:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    78b8:      	orr	x0, x16, xzr
    78bc:      	mov	x1, #0x1                ; =1
    78c0:      	mov	x2, #0x2b               ; =43
    78c4:      	b	0x77cc <_stogir.vector.memory-inputs+0x270>
    78c8:      	cmp	x24, #0x0
    78cc:      	b.ge	0x7918 <_stogir.vector.memory-inputs+0x3bc>
    78d0:      	add	x3, x20, #0x28
    78d4:      	add	x4, x20, #0x50
    78d8:      	ldr	x3, [x3, #0x8]
    78dc:      	ldr	x4, [x4, #0x8]
    78e0:      	cmp	x3, x4
    78e4:      	b.ne	0x79f4 <_stogir.vector.memory-inputs+0x498>
    78e8:      	cmp	x1, x3
    78ec:      	b.gt	0x7a0c <_stogir.vector.memory-inputs+0x4b0>
    78f0:      	ldr	x1, [x20, #0x50]
    78f4:      	add	x1, x1, x2, lsl #2
    78f8:      	ldr	w1, [x1]
    78fc:      	sxtw	x1, w1
    7900:      	cmp	x1, #0x0
    7904:      	cset	w1, gt
    7908:      	ubfx	x1, x1, #0, #8
    790c:      	b	0x7a10 <_stogir.vector.memory-inputs+0x4b4>
    7910:      	movz	x1, #0x0, lsl #48
    7914:      	b	0x791c <_stogir.vector.memory-inputs+0x3c0>
    7918:      	movz	x1, #0x0, lsl #48
    791c:      	cmp	x1, #0x0
    7920:      	b.eq	0x7954 <_stogir.vector.memory-inputs+0x3f8>
    7924:      	uxtb	w16, w0
    7928:      	cmp	w16, wzr
    792c:      	b.eq	0x7940 <_stogir.vector.memory-inputs+0x3e4>
    7930:      	ldr	x0, [x20]
    7934:      	add	x0, x0, x24, lsl #4
    7938:      	ldr	x0, [x0]
    793c:      	b	0x794c <_stogir.vector.memory-inputs+0x3f0>
    7940:      	ldr	x0, [x20, #0x28]
    7944:      	add	x0, x0, x2, lsl #4
    7948:      	ldr	x0, [x0]
    794c:      	mov	x1, #0x1                ; =1
    7950:      	b	0x795c <_stogir.vector.memory-inputs+0x400>
    7954:      	movz	x1, #0x0, lsl #48
    7958:      	movz	x0, #0x0, lsl #48
    795c:      	lsr	w1, w1, #0
    7960:      	lsr	x16, x1, #0
    7964:      	cmp	x16, #0x1
    7968:      	b.eq	0x7984 <_stogir.vector.memory-inputs+0x428>
    796c:      	b.lo	0x7974 <_stogir.vector.memory-inputs+0x418>
    7970:      	b	0x7988 <_stogir.vector.memory-inputs+0x42c>
    7974:      	cmp	x16, #0x0
    7978:      	b.eq	0x7980 <_stogir.vector.memory-inputs+0x424>
    797c:      	b	0x7988 <_stogir.vector.memory-inputs+0x42c>
    7980:      	b	0x798c <_stogir.vector.memory-inputs+0x430>
    7984:      	b	0x79a4 <_stogir.vector.memory-inputs+0x448>
    7988:      	b	0x7a14 <_stogir.vector.memory-inputs+0x4b8>
    798c:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		000000000000798c:  ARM64_RELOC_PAGE21	l_stogir.418
    7990:      	ldr	x16, [x16]
		0000000000007990:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    7994:      	orr	x0, x16, xzr
    7998:      	mov	x1, #0x1                ; =1
    799c:      	mov	x2, #0x1d               ; =29
    79a0:      	b	0x78c4 <_stogir.vector.memory-inputs+0x368>
    79a4:      	lsr	w1, w0, #0
    79a8:      	ubfx	x1, x1, #8, #8
    79ac:      	cmp	x1, #0x6
    79b0:      	b.ne	0x78b0 <_stogir.vector.memory-inputs+0x354>
    79b4:      	uxtb	w0, w0
    79b8:      	cmp	x0, #0x48
    79bc:      	b.eq	0x78b0 <_stogir.vector.memory-inputs+0x354>
    79c0:      	cmp	x0, #0x46
    79c4:      	b.eq	0x78b0 <_stogir.vector.memory-inputs+0x354>
    79c8:      	lsr	w21, w21, #0
    79cc:      	lsr	w22, w22, #0
    79d0:      	mov	w0, w21
    79d4:      	mov	w1, w22
    79d8:      	bl	0x79d8 <_stogir.vector.memory-inputs+0x47c>
		00000000000079d8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    79dc:      	lsr	w0, w0, #0
    79e0:      	sxtw	x0, w0
    79e4:      	and	x0, x0, #0xffffffff
    79e8:      	movz	x1, #0x0, lsl #48
    79ec:      	movz	x2, #0x0, lsl #48
    79f0:      	b	0x78c4 <_stogir.vector.memory-inputs+0x368>
    79f4:      	movz	x1, #0x0, lsl #48
    79f8:      	b	0x791c <_stogir.vector.memory-inputs+0x3c0>
    79fc:      	movz	x1, #0x0, lsl #48
    7a00:      	b	0x7914 <_stogir.vector.memory-inputs+0x3b8>
    7a04:      	brk	#0
    7a08:      	b	0x7a04 <_stogir.vector.memory-inputs+0x4a8>
    7a0c:      	movz	x1, #0x0, lsl #48
    7a10:      	b	0x79f8 <_stogir.vector.memory-inputs+0x49c>
    7a14:      	brk	#0
    7a18:      	b	0x7a14 <_stogir.vector.memory-inputs+0x4b8>
    7a1c:      	mov	x19, x8
    7a20:      	b	0x765c <_stogir.vector.memory-inputs+0x100>
    7a24:      	mov	x19, x8
    7a28:      	b	0x765c <_stogir.vector.memory-inputs+0x100>
    7a2c:      	mov	x19, x8
    7a30:      	b	0x765c <_stogir.vector.memory-inputs+0x100>
    7a34:      	mov	x19, x8
    7a38:      	b	0x765c <_stogir.vector.memory-inputs+0x100>

0000000000007a3c <_stogir.vector.store-inputs>:
    7a3c:      	sub	sp, sp, #0x40
    7a40:      	str	x29, [sp]
    7a44:      	str	x30, [sp, #0x8]
    7a48:      	mov	x29, sp
    7a4c:      	str	x19, [sp, #0x30]
    7a50:      	sxtw	x4, w4
    7a54:      	cmp	x4, #0x0
    7a58:      	cset	w5, gt
    7a5c:      	movz	x16, #0x0, lsl #48
    7a60:      	sub	x6, x16, x4
    7a64:      	sub	x7, x6, #0x1
    7a68:      	uxtb	w16, w5
    7a6c:      	cmp	w16, wzr
    7a70:      	b.eq	0x7ab0 <_stogir.vector.store-inputs+0x74>
    7a74:      	ldr	x6, [x0, #0x8]
    7a78:      	cmp	x4, x6
    7a7c:      	b.ge	0x7b00 <_stogir.vector.store-inputs+0xc4>
    7a80:      	add	x6, x0, #0x78
    7a84:      	ldr	x6, [x6, #0x8]
    7a88:      	cmp	x4, x6
    7a8c:      	b.ge	0x7c08 <_stogir.vector.store-inputs+0x1cc>
    7a90:      	ldr	x6, [x0, #0x78]
    7a94:      	add	x6, x6, x4, lsl #2
    7a98:      	ldr	w6, [x6]
    7a9c:      	sxtw	x6, w6
    7aa0:      	cmp	x6, #0x0
    7aa4:      	cset	w6, ge
    7aa8:      	ubfx	x6, x6, #0, #8
    7aac:      	b	0x7c0c <_stogir.vector.store-inputs+0x1d0>
    7ab0:      	cmp	x4, #0x0
    7ab4:      	b.ge	0x7b08 <_stogir.vector.store-inputs+0xcc>
    7ab8:      	add	x9, x0, #0x28
    7abc:      	add	x10, x0, #0x50
    7ac0:      	ldr	x9, [x9, #0x8]
    7ac4:      	ldr	x10, [x10, #0x8]
    7ac8:      	cmp	x9, x10
    7acc:      	b.ne	0x7af8 <_stogir.vector.store-inputs+0xbc>
    7ad0:      	cmp	x6, x9
    7ad4:      	b.gt	0x7c10 <_stogir.vector.store-inputs+0x1d4>
    7ad8:      	ldr	x6, [x0, #0x50]
    7adc:      	add	x6, x6, x7, lsl #2
    7ae0:      	ldr	w6, [x6]
    7ae4:      	sxtw	x6, w6
    7ae8:      	cmp	x6, #0x0
    7aec:      	cset	w6, gt
    7af0:      	ubfx	x6, x6, #0, #8
    7af4:      	b	0x7c14 <_stogir.vector.store-inputs+0x1d8>
    7af8:      	movz	x6, #0x0, lsl #48
    7afc:      	b	0x7b0c <_stogir.vector.store-inputs+0xd0>
    7b00:      	movz	x6, #0x0, lsl #48
    7b04:      	b	0x7b0c <_stogir.vector.store-inputs+0xd0>
    7b08:      	movz	x6, #0x0, lsl #48
    7b0c:      	cmp	x6, #0x0
    7b10:      	b.eq	0x7b44 <_stogir.vector.store-inputs+0x108>
    7b14:      	uxtb	w16, w5
    7b18:      	cmp	w16, wzr
    7b1c:      	b.eq	0x7b30 <_stogir.vector.store-inputs+0xf4>
    7b20:      	ldr	x5, [x0]
    7b24:      	add	x4, x5, x4, lsl #4
    7b28:      	ldr	x4, [x4]
    7b2c:      	b	0x7b3c <_stogir.vector.store-inputs+0x100>
    7b30:      	ldr	x4, [x0, #0x28]
    7b34:      	add	x4, x4, x7, lsl #4
    7b38:      	ldr	x4, [x4]
    7b3c:      	mov	x5, #0x1                ; =1
    7b40:      	b	0x7b4c <_stogir.vector.store-inputs+0x110>
    7b44:      	movz	x5, #0x0, lsl #48
    7b48:      	movz	x4, #0x0, lsl #48
    7b4c:      	lsr	w5, w5, #0
    7b50:      	lsr	x16, x5, #0
    7b54:      	cmp	x16, #0x1
    7b58:      	b.eq	0x7b74 <_stogir.vector.store-inputs+0x138>
    7b5c:      	b.lo	0x7b64 <_stogir.vector.store-inputs+0x128>
    7b60:      	b	0x7b78 <_stogir.vector.store-inputs+0x13c>
    7b64:      	cmp	x16, #0x0
    7b68:      	b.eq	0x7b70 <_stogir.vector.store-inputs+0x134>
    7b6c:      	b	0x7b78 <_stogir.vector.store-inputs+0x13c>
    7b70:      	b	0x7b7c <_stogir.vector.store-inputs+0x140>
    7b74:      	b	0x7b98 <_stogir.vector.store-inputs+0x15c>
    7b78:      	b	0x7c18 <_stogir.vector.store-inputs+0x1dc>
    7b7c:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1c>
		0000000000007b7c:  ARM64_RELOC_PAGE21	l_stogir.419
    7b80:      	ldr	x16, [x16]
		0000000000007b80:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    7b84:      	orr	x0, x16, xzr
    7b88:      	mov	x19, x8
    7b8c:      	mov	x1, #0x1                ; =1
    7b90:      	mov	x2, #0x1a               ; =26
    7b94:      	b	0x7be8 <_stogir.vector.store-inputs+0x1ac>
    7b98:      	lsr	w1, w1, #0
    7b9c:      	lsr	w2, w2, #0
    7ba0:      	lsr	w3, w3, #0
    7ba4:      	lsr	w4, w4, #0
    7ba8:      	ubfx	x4, x4, #8, #8
    7bac:      	lsr	w4, w4, #0
    7bb0:      	mov	x19, x8
    7bb4:      	add	x8, sp, #0x10
    7bb8:      	fmov	s31, w1
    7bbc:      	mov	w1, w4
    7bc0:      	mov	w4, w3
    7bc4:      	mov	w3, w2
    7bc8:      	fmov	w2, s31
    7bcc:      	bl	0x7bcc <_stogir.vector.store-inputs+0x190>
		0000000000007bcc:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    7bd0:      	add	x16, sp, #0x10
    7bd4:      	ldr	x1, [x16]
    7bd8:      	add	x16, sp, #0x10
    7bdc:      	ldr	x0, [x16, #0x8]
    7be0:      	add	x16, sp, #0x10
    7be4:      	ldr	x2, [x16, #0x10]
    7be8:      	str	x1, [x19]
    7bec:      	str	x0, [x19, #0x8]
    7bf0:      	str	x2, [x19, #0x10]
    7bf4:      	ldr	x19, [sp, #0x30]
    7bf8:      	ldr	x29, [sp]
    7bfc:      	ldr	x30, [sp, #0x8]
    7c00:      	add	sp, sp, #0x40
    7c04:      	ret
    7c08:      	movz	x6, #0x0, lsl #48
    7c0c:      	b	0x7b04 <_stogir.vector.store-inputs+0xc8>
    7c10:      	movz	x6, #0x0, lsl #48
    7c14:      	b	0x7afc <_stogir.vector.store-inputs+0xc0>
    7c18:      	brk	#0
    7c1c:      	b	0x7c18 <_stogir.vector.store-inputs+0x1dc>

0000000000007c20 <_stogir.types.size>:
    7c20:      	sxtw	x0, w0
    7c24:      	sxtw	x1, w1
    7c28:      	cmp	x0, #0xf
    7c2c:      	cset	w2, gt
    7c30:      	cmp	x0, #0x0
    7c34:      	cset	w3, eq
    7c38:      	cmp	x1, #0x4
    7c3c:      	cset	w4, eq
    7c40:      	cmp	x1, #0x8
    7c44:      	cset	w5, eq
    7c48:      	uxtb	w16, w2
    7c4c:      	cmp	w16, wzr
    7c50:      	b.eq	0x7d18 <_stogir.types.size+0xf8>
    7c54:      	cmp	x0, #0x80
    7c58:      	cset	w6, lt
    7c5c:      	uxtb	w16, w6
    7c60:      	cmp	w16, wzr
    7c64:      	b.eq	0x7d18 <_stogir.types.size+0xf8>
    7c68:      	and	x7, x0, #0xf
    7c6c:      	lsr	w7, w7, #0
    7c70:      	sxtw	x7, w7
    7c74:      	cmp	x7, #0x1
    7c78:      	cset	w8, ge
    7c7c:      	uxtb	w16, w8
    7c80:      	cmp	w16, wzr
    7c84:      	b.eq	0x7d18 <_stogir.types.size+0xf8>
    7c88:      	cmp	x7, #0xd
    7c8c:      	cset	w9, le
    7c90:      	uxtb	w16, w9
    7c94:      	cmp	w16, wzr
    7c98:      	b.eq	0x7d18 <_stogir.types.size+0xf8>
    7c9c:      	cmp	x0, #0x0
    7ca0:      	cset	w10, ge
    7ca4:      	cmp	x0, #0xd
    7ca8:      	cset	w11, le
    7cac:      	uxtb	w16, w10
    7cb0:      	cmp	w16, wzr
    7cb4:      	b.eq	0x7cc4 <_stogir.types.size+0xa4>
    7cb8:      	uxtb	w16, w11
    7cbc:      	cmp	w16, wzr
    7cc0:      	b.ne	0x7cf8 <_stogir.types.size+0xd8>
    7cc4:      	uxtb	w16, w2
    7cc8:      	cmp	w16, wzr
    7ccc:      	b.eq	0x7cf4 <_stogir.types.size+0xd4>
    7cd0:      	uxtb	w16, w6
    7cd4:      	cmp	w16, wzr
    7cd8:      	b.eq	0x7cf4 <_stogir.types.size+0xd4>
    7cdc:      	uxtb	w16, w8
    7ce0:      	cmp	w16, wzr
    7ce4:      	b.eq	0x7cf4 <_stogir.types.size+0xd4>
    7ce8:      	uxtb	w16, w9
    7cec:      	cmp	w16, wzr
    7cf0:      	b.ne	0x7cf8 <_stogir.types.size+0xd8>
    7cf4:      	movn	x7, #0x0, lsl #48
    7cf8:      	uxtb	w16, w4
    7cfc:      	cmp	w16, wzr
    7d00:      	b.ne	0x7e58 <_stogir.types.size+0x238>
    7d04:      	uxtb	w16, w5
    7d08:      	cmp	w16, wzr
    7d0c:      	b.ne	0x7e58 <_stogir.types.size+0x238>
    7d10:      	movn	x1, #0x0, lsl #48
    7d14:      	b	0x7dcc <_stogir.types.size+0x1ac>
    7d18:      	uxtb	w16, w4
    7d1c:      	cmp	w16, wzr
    7d20:      	b.ne	0x7d38 <_stogir.types.size+0x118>
    7d24:      	uxtb	w16, w5
    7d28:      	cmp	w16, wzr
    7d2c:      	b.ne	0x7d38 <_stogir.types.size+0x118>
    7d30:      	movn	x1, #0x0, lsl #48
    7d34:      	b	0x7d50 <_stogir.types.size+0x130>
    7d38:      	uxtb	w16, w3
    7d3c:      	cmp	w16, wzr
    7d40:      	b.eq	0x7d58 <_stogir.types.size+0x138>
    7d44:      	movz	x1, #0x0, lsl #48
    7d48:      	b	0x7d50 <_stogir.types.size+0x130>
    7d4c:      	mov	x1, #0x1                ; =1
    7d50:      	mov	x0, x1
    7d54:      	ret
    7d58:      	cmp	x0, #0x1
    7d5c:      	b.eq	0x7d4c <_stogir.types.size+0x12c>
    7d60:      	cmp	x0, #0x2
    7d64:      	b.eq	0x7d4c <_stogir.types.size+0x12c>
    7d68:      	cmp	x0, #0x7
    7d6c:      	b.eq	0x7d4c <_stogir.types.size+0x12c>
    7d70:      	cmp	x0, #0x8
    7d74:      	b.eq	0x7d4c <_stogir.types.size+0x12c>
    7d78:      	cmp	x0, #0x3
    7d7c:      	b.eq	0x7ee0 <_stogir.types.size+0x2c0>
    7d80:      	cmp	x0, #0x9
    7d84:      	b.eq	0x7ee0 <_stogir.types.size+0x2c0>
    7d88:      	cmp	x0, #0x4
    7d8c:      	b.eq	0x7f10 <_stogir.types.size+0x2f0>
    7d90:      	cmp	x0, #0xa
    7d94:      	b.eq	0x7f10 <_stogir.types.size+0x2f0>
    7d98:      	cmp	x0, #0xd
    7d9c:      	b.eq	0x7f10 <_stogir.types.size+0x2f0>
    7da0:      	cmp	x0, #0x5
    7da4:      	b.eq	0x7f20 <_stogir.types.size+0x300>
    7da8:      	cmp	x0, #0xb
    7dac:      	b.eq	0x7f20 <_stogir.types.size+0x300>
    7db0:      	cmp	x0, #0xc
    7db4:      	b.eq	0x7f20 <_stogir.types.size+0x300>
    7db8:      	cmp	x0, #0x6
    7dbc:      	b.eq	0x7dc4 <_stogir.types.size+0x1a4>
    7dc0:      	movn	x1, #0x0, lsl #48
    7dc4:      	b	0x7f24 <_stogir.types.size+0x304>
    7dc8:      	mov	x1, #0x1                ; =1
    7dcc:      	lsr	w1, w1, #0
    7dd0:      	sxtw	x1, w1
    7dd4:      	cmp	x1, #0x0
    7dd8:      	b.ge	0x7de4 <_stogir.types.size+0x1c4>
    7ddc:      	movn	x1, #0x0, lsl #48
    7de0:      	b	0x7d50 <_stogir.types.size+0x130>
    7de4:      	uxtb	w16, w2
    7de8:      	cmp	w16, wzr
    7dec:      	b.eq	0x7ee8 <_stogir.types.size+0x2c8>
    7df0:      	uxtb	w16, w6
    7df4:      	cmp	w16, wzr
    7df8:      	b.eq	0x7ee8 <_stogir.types.size+0x2c8>
    7dfc:      	uxtb	w16, w8
    7e00:      	cmp	w16, wzr
    7e04:      	b.eq	0x7ee8 <_stogir.types.size+0x2c8>
    7e08:      	uxtb	w16, w9
    7e0c:      	cmp	w16, wzr
    7e10:      	b.eq	0x7ee8 <_stogir.types.size+0x2c8>
    7e14:      	ubfx	x0, x0, #4, #32
    7e18:      	sxtw	x0, w0
    7e1c:      	sub	x0, x0, #0x1
    7e20:      	lsr	w0, w0, #0
    7e24:      	sxtw	x0, w0
    7e28:      	mov	x16, #0x1               ; =1
    7e2c:      	lsl	x0, x16, x0
    7e30:      	lsr	w0, w0, #0
    7e34:      	sxtw	x0, w0
    7e38:      	b	0x7e40 <_stogir.types.size+0x220>
    7e3c:      	movn	x0, #0x0, lsl #48
    7e40:      	lsr	w0, w0, #0
    7e44:      	sxtw	x0, w0
    7e48:      	mul	x0, x0, x1
    7e4c:      	lsr	w0, w0, #0
    7e50:      	sxtw	x1, w0
    7e54:      	b	0x7de0 <_stogir.types.size+0x1c0>
    7e58:      	lsr	w7, w7, #0
    7e5c:      	sxtw	x7, w7
    7e60:      	cmp	x7, #0x0
    7e64:      	b.ne	0x7e70 <_stogir.types.size+0x250>
    7e68:      	movz	x1, #0x0, lsl #48
    7e6c:      	b	0x7dcc <_stogir.types.size+0x1ac>
    7e70:      	cmp	x7, #0x1
    7e74:      	b.eq	0x7dc8 <_stogir.types.size+0x1a8>
    7e78:      	cmp	x7, #0x2
    7e7c:      	b.eq	0x7dc8 <_stogir.types.size+0x1a8>
    7e80:      	cmp	x7, #0x7
    7e84:      	b.eq	0x7dc8 <_stogir.types.size+0x1a8>
    7e88:      	cmp	x7, #0x8
    7e8c:      	b.eq	0x7dc8 <_stogir.types.size+0x1a8>
    7e90:      	cmp	x7, #0x3
    7e94:      	b.eq	0x7f18 <_stogir.types.size+0x2f8>
    7e98:      	cmp	x7, #0x9
    7e9c:      	b.eq	0x7f18 <_stogir.types.size+0x2f8>
    7ea0:      	cmp	x7, #0x4
    7ea4:      	b.eq	0x7f28 <_stogir.types.size+0x308>
    7ea8:      	cmp	x7, #0xa
    7eac:      	b.eq	0x7f28 <_stogir.types.size+0x308>
    7eb0:      	cmp	x7, #0xd
    7eb4:      	b.eq	0x7f28 <_stogir.types.size+0x308>
    7eb8:      	cmp	x7, #0x5
    7ebc:      	b.eq	0x7f30 <_stogir.types.size+0x310>
    7ec0:      	cmp	x7, #0xb
    7ec4:      	b.eq	0x7f30 <_stogir.types.size+0x310>
    7ec8:      	cmp	x7, #0xc
    7ecc:      	b.eq	0x7f30 <_stogir.types.size+0x310>
    7ed0:      	cmp	x7, #0x6
    7ed4:      	b.eq	0x7edc <_stogir.types.size+0x2bc>
    7ed8:      	movn	x1, #0x0, lsl #48
    7edc:      	b	0x7f34 <_stogir.types.size+0x314>
    7ee0:      	mov	x1, #0x2                ; =2
    7ee4:      	b	0x7d50 <_stogir.types.size+0x130>
    7ee8:      	uxtb	w16, w10
    7eec:      	cmp	w16, wzr
    7ef0:      	b.eq	0x7e3c <_stogir.types.size+0x21c>
    7ef4:      	uxtb	w16, w11
    7ef8:      	cmp	w16, wzr
    7efc:      	b.eq	0x7e3c <_stogir.types.size+0x21c>
    7f00:      	uxtb	w16, w3
    7f04:      	cmp	w16, wzr
    7f08:      	cset	x0, eq
    7f0c:      	b	0x7e40 <_stogir.types.size+0x220>
    7f10:      	mov	x1, #0x4                ; =4
    7f14:      	b	0x7ee4 <_stogir.types.size+0x2c4>
    7f18:      	mov	x1, #0x2                ; =2
    7f1c:      	b	0x7dcc <_stogir.types.size+0x1ac>
    7f20:      	mov	x1, #0x8                ; =8
    7f24:      	b	0x7f14 <_stogir.types.size+0x2f4>
    7f28:      	mov	x1, #0x4                ; =4
    7f2c:      	b	0x7f1c <_stogir.types.size+0x2fc>
    7f30:      	mov	x1, #0x8                ; =8
    7f34:      	b	0x7f2c <_stogir.types.size+0x30c>

0000000000007f38 <_stogir.checked.projection>:
    7f38:      	sub	sp, sp, #0x40
    7f3c:      	str	x29, [sp]
    7f40:      	str	x30, [sp, #0x8]
    7f44:      	mov	x29, sp
    7f48:      	str	x19, [sp, #0x30]
    7f4c:      	sxtw	x2, w1
    7f50:      	cmp	x2, #0x0
    7f54:      	cset	w3, gt
    7f58:      	movz	x16, #0x0, lsl #48
    7f5c:      	sub	x4, x16, x2
    7f60:      	sub	x5, x4, #0x1
    7f64:      	uxtb	w16, w3
    7f68:      	cmp	w16, wzr
    7f6c:      	b.eq	0x7fac <_stogir.checked.projection+0x74>
    7f70:      	ldr	x4, [x0, #0x8]
    7f74:      	cmp	x2, x4
    7f78:      	b.ge	0x7ffc <_stogir.checked.projection+0xc4>
    7f7c:      	add	x4, x0, #0x78
    7f80:      	ldr	x4, [x4, #0x8]
    7f84:      	cmp	x2, x4
    7f88:      	b.ge	0x8108 <_stogir.checked.projection+0x1d0>
    7f8c:      	ldr	x4, [x0, #0x78]
    7f90:      	add	x4, x4, x2, lsl #2
    7f94:      	ldr	w4, [x4]
    7f98:      	sxtw	x4, w4
    7f9c:      	cmp	x4, #0x0
    7fa0:      	cset	w4, ge
    7fa4:      	ubfx	x4, x4, #0, #8
    7fa8:      	b	0x810c <_stogir.checked.projection+0x1d4>
    7fac:      	cmp	x2, #0x0
    7fb0:      	b.ge	0x8004 <_stogir.checked.projection+0xcc>
    7fb4:      	add	x6, x0, #0x28
    7fb8:      	add	x7, x0, #0x50
    7fbc:      	ldr	x6, [x6, #0x8]
    7fc0:      	ldr	x7, [x7, #0x8]
    7fc4:      	cmp	x6, x7
    7fc8:      	b.ne	0x7ff4 <_stogir.checked.projection+0xbc>
    7fcc:      	cmp	x4, x6
    7fd0:      	b.gt	0x8138 <_stogir.checked.projection+0x200>
    7fd4:      	ldr	x4, [x0, #0x50]
    7fd8:      	add	x4, x4, x5, lsl #2
    7fdc:      	ldr	w4, [x4]
    7fe0:      	sxtw	x4, w4
    7fe4:      	cmp	x4, #0x0
    7fe8:      	cset	w4, gt
    7fec:      	ubfx	x4, x4, #0, #8
    7ff0:      	b	0x813c <_stogir.checked.projection+0x204>
    7ff4:      	movz	x4, #0x0, lsl #48
    7ff8:      	b	0x8008 <_stogir.checked.projection+0xd0>
    7ffc:      	movz	x4, #0x0, lsl #48
    8000:      	b	0x8008 <_stogir.checked.projection+0xd0>
    8004:      	movz	x4, #0x0, lsl #48
    8008:      	cmp	x4, #0x0
    800c:      	b.eq	0x8040 <_stogir.checked.projection+0x108>
    8010:      	uxtb	w16, w3
    8014:      	cmp	w16, wzr
    8018:      	b.eq	0x802c <_stogir.checked.projection+0xf4>
    801c:      	ldr	x3, [x0]
    8020:      	add	x2, x3, x2, lsl #4
    8024:      	ldr	x2, [x2]
    8028:      	b	0x8038 <_stogir.checked.projection+0x100>
    802c:      	ldr	x2, [x0, #0x28]
    8030:      	add	x2, x2, x5, lsl #4
    8034:      	ldr	x2, [x2]
    8038:      	mov	x3, #0x1                ; =1
    803c:      	b	0x8048 <_stogir.checked.projection+0x110>
    8040:      	movz	x3, #0x0, lsl #48
    8044:      	movz	x2, #0x0, lsl #48
    8048:      	lsr	w3, w3, #0
    804c:      	lsr	x16, x3, #0
    8050:      	cmp	x16, #0x1
    8054:      	b.eq	0x8070 <_stogir.checked.projection+0x138>
    8058:      	b.lo	0x8060 <_stogir.checked.projection+0x128>
    805c:      	b	0x8074 <_stogir.checked.projection+0x13c>
    8060:      	cmp	x16, #0x0
    8064:      	b.eq	0x806c <_stogir.checked.projection+0x134>
    8068:      	b	0x8074 <_stogir.checked.projection+0x13c>
    806c:      	b	0x8078 <_stogir.checked.projection+0x140>
    8070:      	b	0x80c8 <_stogir.checked.projection+0x190>
    8074:      	b	0x8140 <_stogir.checked.projection+0x208>
    8078:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008078:  ARM64_RELOC_PAGE21	l_stogir.420
    807c:      	ldr	x16, [x16]
		000000000000807c:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    8080:      	orr	x0, x16, xzr
    8084:      	mov	x19, x8
    8088:      	mov	x1, #0x1                ; =1
    808c:      	mov	x2, #0x17               ; =23
    8090:      	b	0x80a8 <_stogir.checked.projection+0x170>
    8094:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008094:  ARM64_RELOC_PAGE21	l_stogir.421
    8098:      	ldr	x16, [x16]
		0000000000008098:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    809c:      	orr	x0, x16, xzr
    80a0:      	mov	x1, #0x1                ; =1
    80a4:      	mov	x2, #0x20               ; =32
    80a8:      	str	x1, [x19]
    80ac:      	str	x0, [x19, #0x8]
    80b0:      	str	x2, [x19, #0x10]
    80b4:      	ldr	x19, [sp, #0x30]
    80b8:      	ldr	x29, [sp]
    80bc:      	ldr	x30, [sp, #0x8]
    80c0:      	add	sp, sp, #0x40
    80c4:      	ret
    80c8:      	uxtb	w3, w2
    80cc:      	cmp	x3, #0x29
    80d0:      	b.lt	0x8148 <_stogir.checked.projection+0x210>
    80d4:      	cmp	x3, #0x2b
    80d8:      	b.gt	0x8150 <_stogir.checked.projection+0x218>
    80dc:      	lsr	w1, w1, #0
    80e0:      	mov	x19, x8
    80e4:      	add	x8, sp, #0x10
    80e8:      	bl	0x80e8 <_stogir.checked.projection+0x1b0>
		00000000000080e8:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    80ec:      	add	x16, sp, #0x10
    80f0:      	ldr	x1, [x16]
    80f4:      	add	x16, sp, #0x10
    80f8:      	ldr	x0, [x16, #0x8]
    80fc:      	add	x16, sp, #0x10
    8100:      	ldr	x2, [x16, #0x10]
    8104:      	b	0x80a8 <_stogir.checked.projection+0x170>
    8108:      	movz	x4, #0x0, lsl #48
    810c:      	b	0x8000 <_stogir.checked.projection+0xc8>
    8110:      	lsr	w2, w2, #0
    8114:      	ubfx	x0, x2, #8, #8
    8118:      	cmp	x0, #0x0
    811c:      	b.eq	0x8094 <_stogir.checked.projection+0x15c>
    8120:      	cmp	x0, #0xd
    8124:      	b.gt	0x8094 <_stogir.checked.projection+0x15c>
    8128:      	movz	x1, #0x0, lsl #48
    812c:      	movz	x0, #0x0, lsl #48
    8130:      	movz	x2, #0x0, lsl #48
    8134:      	b	0x80a8 <_stogir.checked.projection+0x170>
    8138:      	movz	x4, #0x0, lsl #48
    813c:      	b	0x7ff8 <_stogir.checked.projection+0xc0>
    8140:      	brk	#0
    8144:      	b	0x8140 <_stogir.checked.projection+0x208>
    8148:      	mov	x19, x8
    814c:      	b	0x8110 <_stogir.checked.projection+0x1d8>
    8150:      	mov	x19, x8
    8154:      	b	0x8110 <_stogir.checked.projection+0x1d8>

0000000000008158 <_stogir.atomic.ordinary?>:
    8158:      	sxtw	x1, w1
    815c:      	cmp	x1, #0x0
    8160:      	cset	w3, gt
    8164:      	movz	x16, #0x0, lsl #48
    8168:      	sub	x4, x16, x1
    816c:      	sub	x5, x4, #0x1
    8170:      	uxtb	w16, w3
    8174:      	cmp	w16, wzr
    8178:      	b.eq	0x81b8 <_stogir.atomic.ordinary?+0x60>
    817c:      	ldr	x4, [x0, #0x8]
    8180:      	cmp	x1, x4
    8184:      	b.ge	0x8208 <_stogir.atomic.ordinary?+0xb0>
    8188:      	add	x4, x0, #0x78
    818c:      	ldr	x4, [x4, #0x8]
    8190:      	cmp	x1, x4
    8194:      	b.ge	0x82bc <_stogir.atomic.ordinary?+0x164>
    8198:      	ldr	x4, [x0, #0x78]
    819c:      	add	x4, x4, x1, lsl #2
    81a0:      	ldr	w4, [x4]
    81a4:      	sxtw	x4, w4
    81a8:      	cmp	x4, #0x0
    81ac:      	cset	w4, ge
    81b0:      	ubfx	x4, x4, #0, #8
    81b4:      	b	0x82c0 <_stogir.atomic.ordinary?+0x168>
    81b8:      	cmp	x1, #0x0
    81bc:      	b.ge	0x8210 <_stogir.atomic.ordinary?+0xb8>
    81c0:      	add	x6, x0, #0x28
    81c4:      	add	x7, x0, #0x50
    81c8:      	ldr	x6, [x6, #0x8]
    81cc:      	ldr	x7, [x7, #0x8]
    81d0:      	cmp	x6, x7
    81d4:      	b.ne	0x8200 <_stogir.atomic.ordinary?+0xa8>
    81d8:      	cmp	x4, x6
    81dc:      	b.gt	0x82dc <_stogir.atomic.ordinary?+0x184>
    81e0:      	ldr	x4, [x0, #0x50]
    81e4:      	add	x4, x4, x5, lsl #2
    81e8:      	ldr	w4, [x4]
    81ec:      	sxtw	x4, w4
    81f0:      	cmp	x4, #0x0
    81f4:      	cset	w4, gt
    81f8:      	ubfx	x4, x4, #0, #8
    81fc:      	b	0x82e0 <_stogir.atomic.ordinary?+0x188>
    8200:      	movz	x4, #0x0, lsl #48
    8204:      	b	0x8214 <_stogir.atomic.ordinary?+0xbc>
    8208:      	movz	x4, #0x0, lsl #48
    820c:      	b	0x8214 <_stogir.atomic.ordinary?+0xbc>
    8210:      	movz	x4, #0x0, lsl #48
    8214:      	cmp	x4, #0x0
    8218:      	b.eq	0x824c <_stogir.atomic.ordinary?+0xf4>
    821c:      	uxtb	w16, w3
    8220:      	cmp	w16, wzr
    8224:      	b.eq	0x8238 <_stogir.atomic.ordinary?+0xe0>
    8228:      	ldr	x0, [x0]
    822c:      	add	x0, x0, x1, lsl #4
    8230:      	ldr	x0, [x0]
    8234:      	b	0x8244 <_stogir.atomic.ordinary?+0xec>
    8238:      	ldr	x0, [x0, #0x28]
    823c:      	add	x0, x0, x5, lsl #4
    8240:      	ldr	x0, [x0]
    8244:      	mov	x1, #0x1                ; =1
    8248:      	b	0x8254 <_stogir.atomic.ordinary?+0xfc>
    824c:      	movz	x1, #0x0, lsl #48
    8250:      	movz	x0, #0x0, lsl #48
    8254:      	lsr	w1, w1, #0
    8258:      	lsr	x16, x1, #0
    825c:      	cmp	x16, #0x1
    8260:      	b.eq	0x827c <_stogir.atomic.ordinary?+0x124>
    8264:      	b.lo	0x826c <_stogir.atomic.ordinary?+0x114>
    8268:      	b	0x8280 <_stogir.atomic.ordinary?+0x128>
    826c:      	cmp	x16, #0x0
    8270:      	b.eq	0x8278 <_stogir.atomic.ordinary?+0x120>
    8274:      	b	0x8280 <_stogir.atomic.ordinary?+0x128>
    8278:      	b	0x8284 <_stogir.atomic.ordinary?+0x12c>
    827c:      	b	0x8294 <_stogir.atomic.ordinary?+0x13c>
    8280:      	b	0x82e4 <_stogir.atomic.ordinary?+0x18c>
    8284:      	movz	x0, #0x0, lsl #48
    8288:      	b	0x8290 <_stogir.atomic.ordinary?+0x138>
    828c:      	movz	x0, #0x0, lsl #48
    8290:      	ret
    8294:      	sxtw	x2, w2
    8298:      	lsr	w1, w0, #0
    829c:      	ubfx	x1, x1, #8, #8
    82a0:      	cmp	x1, x2
    82a4:      	b.ne	0x828c <_stogir.atomic.ordinary?+0x134>
    82a8:      	uxtb	w0, w0
    82ac:      	cmp	x0, #0x46
    82b0:      	b.ne	0x82c4 <_stogir.atomic.ordinary?+0x16c>
    82b4:      	movz	x0, #0x0, lsl #48
    82b8:      	b	0x82d8 <_stogir.atomic.ordinary?+0x180>
    82bc:      	movz	x4, #0x0, lsl #48
    82c0:      	b	0x820c <_stogir.atomic.ordinary?+0xb4>
    82c4:      	cmp	x0, #0x48
    82c8:      	cset	w0, eq
    82cc:      	uxtb	w16, w0
    82d0:      	cmp	w16, wzr
    82d4:      	cset	x0, eq
    82d8:      	b	0x8290 <_stogir.atomic.ordinary?+0x138>
    82dc:      	movz	x4, #0x0, lsl #48
    82e0:      	b	0x8204 <_stogir.atomic.ordinary?+0xac>
    82e4:      	brk	#0
    82e8:      	b	0x82e4 <_stogir.atomic.ordinary?+0x18c>

00000000000082ec <_stogir.types.scalar-size>:
    82ec:      	sxtw	x1, w1
    82f0:      	cmp	x1, #0x4
    82f4:      	b.eq	0x8308 <_stogir.types.scalar-size+0x1c>
    82f8:      	cmp	x1, #0x8
    82fc:      	b.eq	0x8308 <_stogir.types.scalar-size+0x1c>
    8300:      	movn	x1, #0x0, lsl #48
    8304:      	b	0x8320 <_stogir.types.scalar-size+0x34>
    8308:      	sxtw	x0, w0
    830c:      	cmp	x0, #0x0
    8310:      	b.ne	0x8328 <_stogir.types.scalar-size+0x3c>
    8314:      	movz	x1, #0x0, lsl #48
    8318:      	b	0x8320 <_stogir.types.scalar-size+0x34>
    831c:      	mov	x1, #0x1                ; =1
    8320:      	mov	x0, x1
    8324:      	ret
    8328:      	cmp	x0, #0x1
    832c:      	b.eq	0x831c <_stogir.types.scalar-size+0x30>
    8330:      	cmp	x0, #0x2
    8334:      	b.eq	0x831c <_stogir.types.scalar-size+0x30>
    8338:      	cmp	x0, #0x7
    833c:      	b.eq	0x831c <_stogir.types.scalar-size+0x30>
    8340:      	cmp	x0, #0x8
    8344:      	b.eq	0x831c <_stogir.types.scalar-size+0x30>
    8348:      	cmp	x0, #0x3
    834c:      	b.eq	0x8398 <_stogir.types.scalar-size+0xac>
    8350:      	cmp	x0, #0x9
    8354:      	b.eq	0x8398 <_stogir.types.scalar-size+0xac>
    8358:      	cmp	x0, #0x4
    835c:      	b.eq	0x83a0 <_stogir.types.scalar-size+0xb4>
    8360:      	cmp	x0, #0xa
    8364:      	b.eq	0x83a0 <_stogir.types.scalar-size+0xb4>
    8368:      	cmp	x0, #0xd
    836c:      	b.eq	0x83a0 <_stogir.types.scalar-size+0xb4>
    8370:      	cmp	x0, #0x5
    8374:      	b.eq	0x83a8 <_stogir.types.scalar-size+0xbc>
    8378:      	cmp	x0, #0xb
    837c:      	b.eq	0x83a8 <_stogir.types.scalar-size+0xbc>
    8380:      	cmp	x0, #0xc
    8384:      	b.eq	0x83a8 <_stogir.types.scalar-size+0xbc>
    8388:      	cmp	x0, #0x6
    838c:      	b.eq	0x8394 <_stogir.types.scalar-size+0xa8>
    8390:      	movn	x1, #0x0, lsl #48
    8394:      	b	0x83ac <_stogir.types.scalar-size+0xc0>
    8398:      	mov	x1, #0x2                ; =2
    839c:      	b	0x8320 <_stogir.types.scalar-size+0x34>
    83a0:      	mov	x1, #0x4                ; =4
    83a4:      	b	0x839c <_stogir.types.scalar-size+0xb0>
    83a8:      	mov	x1, #0x8                ; =8
    83ac:      	b	0x83a4 <_stogir.types.scalar-size+0xb8>

00000000000083b0 <_stogir.terminal.inputs>:
    83b0:      	sxtw	x1, w1
    83b4:      	cmp	x1, #0x60
    83b8:      	cset	w4, eq
    83bc:      	uxtb	w16, w4
    83c0:      	cmp	w16, wzr
    83c4:      	b.ne	0x83f4 <_stogir.terminal.inputs+0x44>
    83c8:      	cmp	x1, #0x79
    83cc:      	b.eq	0x83f4 <_stogir.terminal.inputs+0x44>
    83d0:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		00000000000083d0:  ARM64_RELOC_PAGE21	l_stogir.422
    83d4:      	ldr	x16, [x16]
		00000000000083d4:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    83d8:      	orr	x0, x16, xzr
    83dc:      	mov	x1, #0x1                ; =1
    83e0:      	mov	x2, #0x25               ; =37
    83e4:      	str	x1, [x8]
    83e8:      	str	x0, [x8, #0x8]
    83ec:      	str	x2, [x8, #0x10]
    83f0:      	ret
    83f4:      	sxtw	x3, w3
    83f8:      	uxtb	w16, w4
    83fc:      	cmp	w16, wzr
    8400:      	b.eq	0x840c <_stogir.terminal.inputs+0x5c>
    8404:      	cmp	x3, #0x0
    8408:      	b.ne	0x83d0 <_stogir.terminal.inputs+0x20>
    840c:      	sxtw	x2, w2
    8410:      	cmp	x2, #0x0
    8414:      	cset	w1, gt
    8418:      	movz	x16, #0x0, lsl #48
    841c:      	sub	x4, x16, x2
    8420:      	sub	x5, x4, #0x1
    8424:      	uxtb	w16, w1
    8428:      	cmp	w16, wzr
    842c:      	b.eq	0x8500 <_stogir.terminal.inputs+0x150>
    8430:      	ldr	x4, [x0, #0x8]
    8434:      	cmp	x2, x4
    8438:      	b.ge	0x84f8 <_stogir.terminal.inputs+0x148>
    843c:      	add	x4, x0, #0x78
    8440:      	ldr	x4, [x4, #0x8]
    8444:      	cmp	x2, x4
    8448:      	b.ge	0x85a0 <_stogir.terminal.inputs+0x1f0>
    844c:      	ldr	x4, [x0, #0x78]
    8450:      	add	x4, x4, x2, lsl #2
    8454:      	ldr	w4, [x4]
    8458:      	sxtw	x4, w4
    845c:      	cmp	x4, #0x0
    8460:      	cset	w4, ge
    8464:      	ubfx	x4, x4, #0, #8
    8468:      	b	0x85a4 <_stogir.terminal.inputs+0x1f4>
    846c:      	movz	x4, #0x0, lsl #48
    8470:      	movz	x1, #0x0, lsl #48
    8474:      	lsr	w4, w4, #0
    8478:      	lsr	x16, x4, #0
    847c:      	cmp	x16, #0x1
    8480:      	b.eq	0x849c <_stogir.terminal.inputs+0xec>
    8484:      	b.lo	0x848c <_stogir.terminal.inputs+0xdc>
    8488:      	b	0x84a0 <_stogir.terminal.inputs+0xf0>
    848c:      	cmp	x16, #0x0
    8490:      	b.eq	0x8498 <_stogir.terminal.inputs+0xe8>
    8494:      	b	0x84a0 <_stogir.terminal.inputs+0xf0>
    8498:      	b	0x84a4 <_stogir.terminal.inputs+0xf4>
    849c:      	b	0x8548 <_stogir.terminal.inputs+0x198>
    84a0:      	b	0x86ec <_stogir.terminal.inputs+0x33c>
    84a4:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		00000000000084a4:  ARM64_RELOC_PAGE21	l_stogir.423
    84a8:      	ldr	x16, [x16]
		00000000000084a8:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    84ac:      	orr	x0, x16, xzr
    84b0:      	mov	x1, #0x1                ; =1
    84b4:      	mov	x2, #0x1d               ; =29
    84b8:      	b	0x83e4 <_stogir.terminal.inputs+0x34>
    84bc:      	ldr	x1, [x0, #0x28]
    84c0:      	add	x1, x1, x5, lsl #4
    84c4:      	ldr	x1, [x1]
    84c8:      	mov	x4, #0x1                ; =1
    84cc:      	b	0x8474 <_stogir.terminal.inputs+0xc4>
    84d0:      	movz	x4, #0x0, lsl #48
    84d4:      	cmp	x4, #0x0
    84d8:      	b.eq	0x846c <_stogir.terminal.inputs+0xbc>
    84dc:      	uxtb	w16, w1
    84e0:      	cmp	w16, wzr
    84e4:      	b.eq	0x84bc <_stogir.terminal.inputs+0x10c>
    84e8:      	ldr	x1, [x0]
    84ec:      	add	x1, x1, x2, lsl #4
    84f0:      	ldr	x1, [x1]
    84f4:      	b	0x84c8 <_stogir.terminal.inputs+0x118>
    84f8:      	movz	x4, #0x0, lsl #48
    84fc:      	b	0x84d4 <_stogir.terminal.inputs+0x124>
    8500:      	cmp	x2, #0x0
    8504:      	b.ge	0x84d0 <_stogir.terminal.inputs+0x120>
    8508:      	add	x6, x0, #0x28
    850c:      	add	x7, x0, #0x50
    8510:      	ldr	x6, [x6, #0x8]
    8514:      	ldr	x7, [x7, #0x8]
    8518:      	cmp	x6, x7
    851c:      	b.ne	0x8598 <_stogir.terminal.inputs+0x1e8>
    8520:      	cmp	x4, x6
    8524:      	b.gt	0x85a8 <_stogir.terminal.inputs+0x1f8>
    8528:      	ldr	x4, [x0, #0x50]
    852c:      	add	x4, x4, x5, lsl #2
    8530:      	ldr	w4, [x4]
    8534:      	sxtw	x4, w4
    8538:      	cmp	x4, #0x0
    853c:      	cset	w4, gt
    8540:      	ubfx	x4, x4, #0, #8
    8544:      	b	0x85ac <_stogir.terminal.inputs+0x1fc>
    8548:      	cmp	x2, #0x0
    854c:      	b.le	0x8580 <_stogir.terminal.inputs+0x1d0>
    8550:      	uxtb	w1, w1
    8554:      	cmp	x1, #0x83
    8558:      	cset	w2, lt
    855c:      	uxtb	w16, w2
    8560:      	cmp	w16, wzr
    8564:      	b.eq	0x85b0 <_stogir.terminal.inputs+0x200>
    8568:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008568:  ARM64_RELOC_PAGE21	l_stogir.424
    856c:      	ldr	x16, [x16]
		000000000000856c:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    8570:      	orr	x4, x16, xzr
    8574:      	add	x4, x1, x4
    8578:      	ldrb	w4, [x4]
    857c:      	b	0x85b4 <_stogir.terminal.inputs+0x204>
    8580:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008580:  ARM64_RELOC_PAGE21	l_stogir.425
    8584:      	ldr	x16, [x16]
		0000000000008584:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    8588:      	orr	x0, x16, xzr
    858c:      	mov	x1, #0x1                ; =1
    8590:      	mov	x2, #0x2c               ; =44
    8594:      	b	0x84b8 <_stogir.terminal.inputs+0x108>
    8598:      	movz	x4, #0x0, lsl #48
    859c:      	b	0x84d4 <_stogir.terminal.inputs+0x124>
    85a0:      	movz	x4, #0x0, lsl #48
    85a4:      	b	0x84fc <_stogir.terminal.inputs+0x14c>
    85a8:      	movz	x4, #0x0, lsl #48
    85ac:      	b	0x859c <_stogir.terminal.inputs+0x1ec>
    85b0:      	movz	x4, #0x0, lsl #48
    85b4:      	uxtb	w4, w4
    85b8:      	and	x4, x4, #0x1
    85bc:      	uxtb	w4, w4
    85c0:      	cmp	x4, #0x0
    85c4:      	b.eq	0x8580 <_stogir.terminal.inputs+0x1d0>
    85c8:      	uxtb	w16, w2
    85cc:      	cmp	w16, wzr
    85d0:      	b.eq	0x85ec <_stogir.terminal.inputs+0x23c>
    85d4:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		00000000000085d4:  ARM64_RELOC_PAGE21	l_stogir.424
    85d8:      	ldr	x16, [x16]
		00000000000085d8:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    85dc:      	orr	x2, x16, xzr
    85e0:      	add	x1, x1, x2
    85e4:      	ldrb	w1, [x1]
    85e8:      	b	0x85f0 <_stogir.terminal.inputs+0x240>
    85ec:      	movz	x1, #0x0, lsl #48
    85f0:      	uxtb	w1, w1
    85f4:      	and	x1, x1, #0x4
    85f8:      	uxtb	w1, w1
    85fc:      	cmp	x1, #0x0
    8600:      	cset	w1, eq
    8604:      	uxtb	w16, w1
    8608:      	cmp	w16, wzr
    860c:      	cset	x1, eq
    8610:      	cmp	x1, #0x0
    8614:      	b.ne	0x8580 <_stogir.terminal.inputs+0x1d0>
    8618:      	cmp	x3, #0x0
    861c:      	b.ne	0x8630 <_stogir.terminal.inputs+0x280>
    8620:      	movz	x1, #0x0, lsl #48
    8624:      	movz	x0, #0x0, lsl #48
    8628:      	movz	x2, #0x0, lsl #48
    862c:      	b	0x8594 <_stogir.terminal.inputs+0x1e4>
    8630:      	cmp	x3, #0x0
    8634:      	cset	w1, gt
    8638:      	movz	x16, #0x0, lsl #48
    863c:      	sub	x2, x16, x3
    8640:      	sub	x4, x2, #0x1
    8644:      	uxtb	w16, w1
    8648:      	cmp	w16, wzr
    864c:      	b.eq	0x86a4 <_stogir.terminal.inputs+0x2f4>
    8650:      	ldr	x2, [x0, #0x8]
    8654:      	cmp	x3, x2
    8658:      	b.ge	0x86f4 <_stogir.terminal.inputs+0x344>
    865c:      	add	x2, x0, #0x78
    8660:      	ldr	x2, [x2, #0x8]
    8664:      	cmp	x3, x2
    8668:      	b.ge	0x87bc <_stogir.terminal.inputs+0x40c>
    866c:      	ldr	x2, [x0, #0x78]
    8670:      	add	x2, x2, x3, lsl #2
    8674:      	ldr	w2, [x2]
    8678:      	sxtw	x2, w2
    867c:      	cmp	x2, #0x0
    8680:      	cset	w2, ge
    8684:      	ubfx	x2, x2, #0, #8
    8688:      	b	0x87c0 <_stogir.terminal.inputs+0x410>
    868c:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		000000000000868c:  ARM64_RELOC_PAGE21	l_stogir.426
    8690:      	ldr	x16, [x16]
		0000000000008690:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    8694:      	orr	x0, x16, xzr
    8698:      	mov	x1, #0x1                ; =1
    869c:      	mov	x2, #0x2e               ; =46
    86a0:      	b	0x862c <_stogir.terminal.inputs+0x27c>
    86a4:      	cmp	x3, #0x0
    86a8:      	b.ge	0x86fc <_stogir.terminal.inputs+0x34c>
    86ac:      	add	x5, x0, #0x28
    86b0:      	add	x6, x0, #0x50
    86b4:      	ldr	x5, [x5, #0x8]
    86b8:      	ldr	x6, [x6, #0x8]
    86bc:      	cmp	x5, x6
    86c0:      	b.ne	0x87b4 <_stogir.terminal.inputs+0x404>
    86c4:      	cmp	x2, x5
    86c8:      	b.gt	0x87c4 <_stogir.terminal.inputs+0x414>
    86cc:      	ldr	x2, [x0, #0x50]
    86d0:      	add	x2, x2, x4, lsl #2
    86d4:      	ldr	w2, [x2]
    86d8:      	sxtw	x2, w2
    86dc:      	cmp	x2, #0x0
    86e0:      	cset	w2, gt
    86e4:      	ubfx	x2, x2, #0, #8
    86e8:      	b	0x87c8 <_stogir.terminal.inputs+0x418>
    86ec:      	brk	#0
    86f0:      	b	0x86ec <_stogir.terminal.inputs+0x33c>
    86f4:      	movz	x2, #0x0, lsl #48
    86f8:      	b	0x8700 <_stogir.terminal.inputs+0x350>
    86fc:      	movz	x2, #0x0, lsl #48
    8700:      	cmp	x2, #0x0
    8704:      	b.eq	0x8738 <_stogir.terminal.inputs+0x388>
    8708:      	uxtb	w16, w1
    870c:      	cmp	w16, wzr
    8710:      	b.eq	0x8724 <_stogir.terminal.inputs+0x374>
    8714:      	ldr	x0, [x0]
    8718:      	add	x0, x0, x3, lsl #4
    871c:      	ldr	x0, [x0]
    8720:      	b	0x8730 <_stogir.terminal.inputs+0x380>
    8724:      	ldr	x0, [x0, #0x28]
    8728:      	add	x0, x0, x4, lsl #4
    872c:      	ldr	x0, [x0]
    8730:      	mov	x1, #0x1                ; =1
    8734:      	b	0x8740 <_stogir.terminal.inputs+0x390>
    8738:      	movz	x1, #0x0, lsl #48
    873c:      	movz	x0, #0x0, lsl #48
    8740:      	lsr	w1, w1, #0
    8744:      	lsr	x16, x1, #0
    8748:      	cmp	x16, #0x1
    874c:      	b.eq	0x8768 <_stogir.terminal.inputs+0x3b8>
    8750:      	b.lo	0x8758 <_stogir.terminal.inputs+0x3a8>
    8754:      	b	0x876c <_stogir.terminal.inputs+0x3bc>
    8758:      	cmp	x16, #0x0
    875c:      	b.eq	0x8764 <_stogir.terminal.inputs+0x3b4>
    8760:      	b	0x876c <_stogir.terminal.inputs+0x3bc>
    8764:      	b	0x8770 <_stogir.terminal.inputs+0x3c0>
    8768:      	b	0x8788 <_stogir.terminal.inputs+0x3d8>
    876c:      	b	0x8808 <_stogir.terminal.inputs+0x458>
    8770:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008770:  ARM64_RELOC_PAGE21	l_stogir.427
    8774:      	ldr	x16, [x16]
		0000000000008774:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    8778:      	orr	x0, x16, xzr
    877c:      	mov	x1, #0x1                ; =1
    8780:      	mov	x2, #0x1d               ; =29
    8784:      	b	0x86a0 <_stogir.terminal.inputs+0x2f0>
    8788:      	cmp	x3, #0x0
    878c:      	b.le	0x868c <_stogir.terminal.inputs+0x2dc>
    8790:      	uxtb	w0, w0
    8794:      	cmp	x0, #0x83
    8798:      	b.ge	0x87cc <_stogir.terminal.inputs+0x41c>
    879c:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		000000000000879c:  ARM64_RELOC_PAGE21	l_stogir.424
    87a0:      	ldr	x16, [x16]
		00000000000087a0:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    87a4:      	orr	x1, x16, xzr
    87a8:      	add	x0, x0, x1
    87ac:      	ldrb	w0, [x0]
    87b0:      	b	0x87d0 <_stogir.terminal.inputs+0x420>
    87b4:      	movz	x2, #0x0, lsl #48
    87b8:      	b	0x8700 <_stogir.terminal.inputs+0x350>
    87bc:      	movz	x2, #0x0, lsl #48
    87c0:      	b	0x86f8 <_stogir.terminal.inputs+0x348>
    87c4:      	movz	x2, #0x0, lsl #48
    87c8:      	b	0x87b8 <_stogir.terminal.inputs+0x408>
    87cc:      	movz	x0, #0x0, lsl #48
    87d0:      	uxtb	w0, w0
    87d4:      	and	x0, x0, #0x8
    87d8:      	uxtb	w0, w0
    87dc:      	cmp	x0, #0x0
    87e0:      	cset	w0, eq
    87e4:      	uxtb	w16, w0
    87e8:      	cmp	w16, wzr
    87ec:      	cset	x0, eq
    87f0:      	cmp	x0, #0x0
    87f4:      	b.eq	0x868c <_stogir.terminal.inputs+0x2dc>
    87f8:      	and	x0, x3, #0xffffffff
    87fc:      	movz	x1, #0x0, lsl #48
    8800:      	movz	x2, #0x0, lsl #48
    8804:      	b	0x86a0 <_stogir.terminal.inputs+0x2f0>
    8808:      	brk	#0
    880c:      	b	0x8808 <_stogir.terminal.inputs+0x458>

0000000000008810 <_stogir.switch.switch-inputs>:
    8810:      	sxtw	x1, w1
    8814:      	cmp	x1, #0x0
    8818:      	cset	w3, gt
    881c:      	movz	x16, #0x0, lsl #48
    8820:      	sub	x4, x16, x1
    8824:      	sub	x5, x4, #0x1
    8828:      	uxtb	w16, w3
    882c:      	cmp	w16, wzr
    8830:      	b.eq	0x8870 <_stogir.switch.switch-inputs+0x60>
    8834:      	ldr	x4, [x0, #0x8]
    8838:      	cmp	x1, x4
    883c:      	b.ge	0x88d8 <_stogir.switch.switch-inputs+0xc8>
    8840:      	add	x4, x0, #0x78
    8844:      	ldr	x4, [x4, #0x8]
    8848:      	cmp	x1, x4
    884c:      	b.ge	0x89b0 <_stogir.switch.switch-inputs+0x1a0>
    8850:      	ldr	x4, [x0, #0x78]
    8854:      	add	x4, x4, x1, lsl #2
    8858:      	ldr	w4, [x4]
    885c:      	sxtw	x4, w4
    8860:      	cmp	x4, #0x0
    8864:      	cset	w4, ge
    8868:      	ubfx	x4, x4, #0, #8
    886c:      	b	0x89b4 <_stogir.switch.switch-inputs+0x1a4>
    8870:      	cmp	x1, #0x0
    8874:      	b.ge	0x88e0 <_stogir.switch.switch-inputs+0xd0>
    8878:      	add	x6, x0, #0x28
    887c:      	add	x7, x0, #0x50
    8880:      	ldr	x6, [x6, #0x8]
    8884:      	ldr	x7, [x7, #0x8]
    8888:      	cmp	x6, x7
    888c:      	b.ne	0x88b8 <_stogir.switch.switch-inputs+0xa8>
    8890:      	cmp	x4, x6
    8894:      	b.gt	0x89b8 <_stogir.switch.switch-inputs+0x1a8>
    8898:      	ldr	x4, [x0, #0x50]
    889c:      	add	x4, x4, x5, lsl #2
    88a0:      	ldr	w4, [x4]
    88a4:      	sxtw	x4, w4
    88a8:      	cmp	x4, #0x0
    88ac:      	cset	w4, gt
    88b0:      	ubfx	x4, x4, #0, #8
    88b4:      	b	0x89bc <_stogir.switch.switch-inputs+0x1ac>
    88b8:      	movz	x4, #0x0, lsl #48
    88bc:      	b	0x88e4 <_stogir.switch.switch-inputs+0xd4>
    88c0:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		00000000000088c0:  ARM64_RELOC_PAGE21	l_stogir.428
    88c4:      	ldr	x16, [x16]
		00000000000088c4:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    88c8:      	orr	x0, x16, xzr
    88cc:      	mov	x1, #0x1                ; =1
    88d0:      	mov	x2, #0x16               ; =22
    88d4:      	b	0x8968 <_stogir.switch.switch-inputs+0x158>
    88d8:      	movz	x4, #0x0, lsl #48
    88dc:      	b	0x88e4 <_stogir.switch.switch-inputs+0xd4>
    88e0:      	movz	x4, #0x0, lsl #48
    88e4:      	cmp	x4, #0x0
    88e8:      	b.eq	0x891c <_stogir.switch.switch-inputs+0x10c>
    88ec:      	uxtb	w16, w3
    88f0:      	cmp	w16, wzr
    88f4:      	b.eq	0x8908 <_stogir.switch.switch-inputs+0xf8>
    88f8:      	ldr	x3, [x0]
    88fc:      	add	x3, x3, x1, lsl #4
    8900:      	ldr	x3, [x3]
    8904:      	b	0x8914 <_stogir.switch.switch-inputs+0x104>
    8908:      	ldr	x3, [x0, #0x28]
    890c:      	add	x3, x3, x5, lsl #4
    8910:      	ldr	x3, [x3]
    8914:      	mov	x4, #0x1                ; =1
    8918:      	b	0x8924 <_stogir.switch.switch-inputs+0x114>
    891c:      	movz	x4, #0x0, lsl #48
    8920:      	movz	x3, #0x0, lsl #48
    8924:      	lsr	w4, w4, #0
    8928:      	lsr	x16, x4, #0
    892c:      	cmp	x16, #0x1
    8930:      	b.eq	0x894c <_stogir.switch.switch-inputs+0x13c>
    8934:      	b.lo	0x893c <_stogir.switch.switch-inputs+0x12c>
    8938:      	b	0x8950 <_stogir.switch.switch-inputs+0x140>
    893c:      	cmp	x16, #0x0
    8940:      	b.eq	0x8948 <_stogir.switch.switch-inputs+0x138>
    8944:      	b	0x8950 <_stogir.switch.switch-inputs+0x140>
    8948:      	b	0x8954 <_stogir.switch.switch-inputs+0x144>
    894c:      	b	0x8978 <_stogir.switch.switch-inputs+0x168>
    8950:      	b	0x8bc0 <_stogir.switch.switch-inputs+0x3b0>
    8954:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008954:  ARM64_RELOC_PAGE21	l_stogir.429
    8958:      	ldr	x16, [x16]
		0000000000008958:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    895c:      	orr	x0, x16, xzr
    8960:      	mov	x1, #0x1                ; =1
    8964:      	mov	x2, #0x16               ; =22
    8968:      	str	x1, [x8]
    896c:      	str	x0, [x8, #0x8]
    8970:      	str	x2, [x8, #0x10]
    8974:      	ret
    8978:      	cmp	x1, #0x0
    897c:      	b.le	0x88c0 <_stogir.switch.switch-inputs+0xb0>
    8980:      	uxtb	w3, w3
    8984:      	cmp	x3, #0x83
    8988:      	cset	w1, lt
    898c:      	uxtb	w16, w1
    8990:      	cmp	w16, wzr
    8994:      	b.eq	0x89c0 <_stogir.switch.switch-inputs+0x1b0>
    8998:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008998:  ARM64_RELOC_PAGE21	l_stogir.430
    899c:      	ldr	x16, [x16]
		000000000000899c:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    89a0:      	orr	x4, x16, xzr
    89a4:      	add	x4, x3, x4
    89a8:      	ldrb	w4, [x4]
    89ac:      	b	0x89c4 <_stogir.switch.switch-inputs+0x1b4>
    89b0:      	movz	x4, #0x0, lsl #48
    89b4:      	b	0x88dc <_stogir.switch.switch-inputs+0xcc>
    89b8:      	movz	x4, #0x0, lsl #48
    89bc:      	b	0x88bc <_stogir.switch.switch-inputs+0xac>
    89c0:      	movz	x4, #0x0, lsl #48
    89c4:      	uxtb	w4, w4
    89c8:      	and	x4, x4, #0x1
    89cc:      	uxtb	w4, w4
    89d0:      	cmp	x4, #0x0
    89d4:      	b.eq	0x88c0 <_stogir.switch.switch-inputs+0xb0>
    89d8:      	uxtb	w16, w1
    89dc:      	cmp	w16, wzr
    89e0:      	b.eq	0x89fc <_stogir.switch.switch-inputs+0x1ec>
    89e4:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		00000000000089e4:  ARM64_RELOC_PAGE21	l_stogir.430
    89e8:      	ldr	x16, [x16]
		00000000000089e8:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    89ec:      	orr	x1, x16, xzr
    89f0:      	add	x1, x3, x1
    89f4:      	ldrb	w1, [x1]
    89f8:      	b	0x8a00 <_stogir.switch.switch-inputs+0x1f0>
    89fc:      	movz	x1, #0x0, lsl #48
    8a00:      	uxtb	w1, w1
    8a04:      	and	x1, x1, #0x4
    8a08:      	uxtb	w1, w1
    8a0c:      	cmp	x1, #0x0
    8a10:      	cset	w1, eq
    8a14:      	uxtb	w16, w1
    8a18:      	cmp	w16, wzr
    8a1c:      	cset	x1, eq
    8a20:      	cmp	x1, #0x0
    8a24:      	b.ne	0x88c0 <_stogir.switch.switch-inputs+0xb0>
    8a28:      	sxtw	x2, w2
    8a2c:      	cmp	x2, #0x0
    8a30:      	cset	w1, gt
    8a34:      	movz	x16, #0x0, lsl #48
    8a38:      	sub	x3, x16, x2
    8a3c:      	sub	x4, x3, #0x1
    8a40:      	uxtb	w16, w1
    8a44:      	cmp	w16, wzr
    8a48:      	b.eq	0x8aa0 <_stogir.switch.switch-inputs+0x290>
    8a4c:      	ldr	x3, [x0, #0x8]
    8a50:      	cmp	x2, x3
    8a54:      	b.ge	0x8ae8 <_stogir.switch.switch-inputs+0x2d8>
    8a58:      	add	x3, x0, #0x78
    8a5c:      	ldr	x3, [x3, #0x8]
    8a60:      	cmp	x2, x3
    8a64:      	b.ge	0x8bb8 <_stogir.switch.switch-inputs+0x3a8>
    8a68:      	ldr	x3, [x0, #0x78]
    8a6c:      	add	x3, x3, x2, lsl #2
    8a70:      	ldr	w3, [x3]
    8a74:      	sxtw	x3, w3
    8a78:      	cmp	x3, #0x0
    8a7c:      	cset	w3, ge
    8a80:      	ubfx	x3, x3, #0, #8
    8a84:      	b	0x8bbc <_stogir.switch.switch-inputs+0x3ac>
    8a88:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008a88:  ARM64_RELOC_PAGE21	l_stogir.431
    8a8c:      	ldr	x16, [x16]
		0000000000008a8c:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    8a90:      	orr	x0, x16, xzr
    8a94:      	mov	x1, #0x1                ; =1
    8a98:      	mov	x2, #0x20               ; =32
    8a9c:      	b	0x88d4 <_stogir.switch.switch-inputs+0xc4>
    8aa0:      	cmp	x2, #0x0
    8aa4:      	b.ge	0x8af0 <_stogir.switch.switch-inputs+0x2e0>
    8aa8:      	add	x5, x0, #0x28
    8aac:      	add	x6, x0, #0x50
    8ab0:      	ldr	x5, [x5, #0x8]
    8ab4:      	ldr	x6, [x6, #0x8]
    8ab8:      	cmp	x5, x6
    8abc:      	b.ne	0x8bb0 <_stogir.switch.switch-inputs+0x3a0>
    8ac0:      	cmp	x3, x5
    8ac4:      	b.gt	0x8bc8 <_stogir.switch.switch-inputs+0x3b8>
    8ac8:      	ldr	x3, [x0, #0x50]
    8acc:      	add	x3, x3, x4, lsl #2
    8ad0:      	ldr	w3, [x3]
    8ad4:      	sxtw	x3, w3
    8ad8:      	cmp	x3, #0x0
    8adc:      	cset	w3, gt
    8ae0:      	ubfx	x3, x3, #0, #8
    8ae4:      	b	0x8bcc <_stogir.switch.switch-inputs+0x3bc>
    8ae8:      	movz	x3, #0x0, lsl #48
    8aec:      	b	0x8af4 <_stogir.switch.switch-inputs+0x2e4>
    8af0:      	movz	x3, #0x0, lsl #48
    8af4:      	cmp	x3, #0x0
    8af8:      	b.eq	0x8b2c <_stogir.switch.switch-inputs+0x31c>
    8afc:      	uxtb	w16, w1
    8b00:      	cmp	w16, wzr
    8b04:      	b.eq	0x8b18 <_stogir.switch.switch-inputs+0x308>
    8b08:      	ldr	x0, [x0]
    8b0c:      	add	x0, x0, x2, lsl #4
    8b10:      	ldr	x0, [x0]
    8b14:      	b	0x8b24 <_stogir.switch.switch-inputs+0x314>
    8b18:      	ldr	x0, [x0, #0x28]
    8b1c:      	add	x0, x0, x4, lsl #4
    8b20:      	ldr	x0, [x0]
    8b24:      	mov	x1, #0x1                ; =1
    8b28:      	b	0x8b34 <_stogir.switch.switch-inputs+0x324>
    8b2c:      	movz	x1, #0x0, lsl #48
    8b30:      	movz	x0, #0x0, lsl #48
    8b34:      	lsr	w1, w1, #0
    8b38:      	lsr	x16, x1, #0
    8b3c:      	cmp	x16, #0x1
    8b40:      	b.eq	0x8b5c <_stogir.switch.switch-inputs+0x34c>
    8b44:      	b.lo	0x8b4c <_stogir.switch.switch-inputs+0x33c>
    8b48:      	b	0x8b60 <_stogir.switch.switch-inputs+0x350>
    8b4c:      	cmp	x16, #0x0
    8b50:      	b.eq	0x8b58 <_stogir.switch.switch-inputs+0x348>
    8b54:      	b	0x8b60 <_stogir.switch.switch-inputs+0x350>
    8b58:      	b	0x8b64 <_stogir.switch.switch-inputs+0x354>
    8b5c:      	b	0x8b7c <_stogir.switch.switch-inputs+0x36c>
    8b60:      	b	0x8bd0 <_stogir.switch.switch-inputs+0x3c0>
    8b64:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008b64:  ARM64_RELOC_PAGE21	l_stogir.432
    8b68:      	ldr	x16, [x16]
		0000000000008b68:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    8b6c:      	orr	x0, x16, xzr
    8b70:      	mov	x1, #0x1                ; =1
    8b74:      	mov	x2, #0x17               ; =23
    8b78:      	b	0x8a9c <_stogir.switch.switch-inputs+0x28c>
    8b7c:      	lsr	w1, w0, #0
    8b80:      	ubfx	x1, x1, #8, #8
    8b84:      	cmp	x1, #0x1
    8b88:      	b.lt	0x8a88 <_stogir.switch.switch-inputs+0x278>
    8b8c:      	cmp	x1, #0xb
    8b90:      	b.gt	0x8a88 <_stogir.switch.switch-inputs+0x278>
    8b94:      	uxtb	w0, w0
    8b98:      	cmp	x0, #0x48
    8b9c:      	b.eq	0x8a88 <_stogir.switch.switch-inputs+0x278>
    8ba0:      	and	x0, x1, #0xffffffff
    8ba4:      	movz	x1, #0x0, lsl #48
    8ba8:      	movz	x2, #0x0, lsl #48
    8bac:      	b	0x8a9c <_stogir.switch.switch-inputs+0x28c>
    8bb0:      	movz	x3, #0x0, lsl #48
    8bb4:      	b	0x8af4 <_stogir.switch.switch-inputs+0x2e4>
    8bb8:      	movz	x3, #0x0, lsl #48
    8bbc:      	b	0x8aec <_stogir.switch.switch-inputs+0x2dc>
    8bc0:      	brk	#0
    8bc4:      	b	0x8bc0 <_stogir.switch.switch-inputs+0x3b0>
    8bc8:      	movz	x3, #0x0, lsl #48
    8bcc:      	b	0x8bb4 <_stogir.switch.switch-inputs+0x3a4>
    8bd0:      	brk	#0
    8bd4:      	b	0x8bd0 <_stogir.switch.switch-inputs+0x3c0>

0000000000008bd8 <_stogir.switch.case-inputs>:
    8bd8:      	sub	sp, sp, #0xb0
    8bdc:      	str	x29, [sp]
    8be0:      	str	x30, [sp, #0x8]
    8be4:      	mov	x29, sp
    8be8:      	str	x19, [sp, #0x70]
    8bec:      	str	x20, [sp, #0x78]
    8bf0:      	str	x21, [sp, #0x80]
    8bf4:      	str	x22, [sp, #0x88]
    8bf8:      	str	x23, [sp, #0x90]
    8bfc:      	str	x24, [sp, #0x98]
    8c00:      	str	x25, [sp, #0xa0]
    8c04:      	str	x26, [sp, #0xa8]
    8c08:      	sxtw	x2, w2
    8c0c:      	lsl	x5, x2, #2
    8c10:      	cmp	x2, #0x0
    8c14:      	cset	w6, gt
    8c18:      	movz	x16, #0x0, lsl #48
    8c1c:      	sub	x7, x16, x2
    8c20:      	sub	x9, x7, #0x1
    8c24:      	uxtb	w16, w6
    8c28:      	cmp	w16, wzr
    8c2c:      	b.eq	0x8c6c <_stogir.switch.case-inputs+0x94>
    8c30:      	ldr	x7, [x0, #0x8]
    8c34:      	cmp	x2, x7
    8c38:      	b.ge	0x8cbc <_stogir.switch.case-inputs+0xe4>
    8c3c:      	add	x7, x0, #0x78
    8c40:      	ldr	x7, [x7, #0x8]
    8c44:      	cmp	x2, x7
    8c48:      	b.ge	0x8dbc <_stogir.switch.case-inputs+0x1e4>
    8c4c:      	ldr	x7, [x0, #0x78]
    8c50:      	add	x7, x5, x7
    8c54:      	ldr	w7, [x7]
    8c58:      	sxtw	x7, w7
    8c5c:      	cmp	x7, #0x0
    8c60:      	cset	w7, ge
    8c64:      	ubfx	x7, x7, #0, #8
    8c68:      	b	0x8dc0 <_stogir.switch.case-inputs+0x1e8>
    8c6c:      	cmp	x2, #0x0
    8c70:      	b.ge	0x8cc4 <_stogir.switch.case-inputs+0xec>
    8c74:      	add	x10, x0, #0x28
    8c78:      	add	x11, x0, #0x50
    8c7c:      	ldr	x10, [x10, #0x8]
    8c80:      	ldr	x11, [x11, #0x8]
    8c84:      	cmp	x10, x11
    8c88:      	b.ne	0x8cb4 <_stogir.switch.case-inputs+0xdc>
    8c8c:      	cmp	x7, x10
    8c90:      	b.gt	0x8e8c <_stogir.switch.case-inputs+0x2b4>
    8c94:      	ldr	x7, [x0, #0x50]
    8c98:      	add	x7, x7, x9, lsl #2
    8c9c:      	ldr	w7, [x7]
    8ca0:      	sxtw	x7, w7
    8ca4:      	cmp	x7, #0x0
    8ca8:      	cset	w7, gt
    8cac:      	ubfx	x7, x7, #0, #8
    8cb0:      	b	0x8e90 <_stogir.switch.case-inputs+0x2b8>
    8cb4:      	movz	x7, #0x0, lsl #48
    8cb8:      	b	0x8cc8 <_stogir.switch.case-inputs+0xf0>
    8cbc:      	movz	x7, #0x0, lsl #48
    8cc0:      	b	0x8cc8 <_stogir.switch.case-inputs+0xf0>
    8cc4:      	movz	x7, #0x0, lsl #48
    8cc8:      	cmp	x7, #0x0
    8ccc:      	b.eq	0x8d08 <_stogir.switch.case-inputs+0x130>
    8cd0:      	uxtb	w16, w6
    8cd4:      	cmp	w16, wzr
    8cd8:      	b.eq	0x8cf0 <_stogir.switch.case-inputs+0x118>
    8cdc:      	ldr	x6, [x0]
    8ce0:      	add	x6, x6, x2, lsl #4
    8ce4:      	ldr	x7, [x6]
    8ce8:      	ldr	x6, [x6, #0x8]
    8cec:      	b	0x8d00 <_stogir.switch.case-inputs+0x128>
    8cf0:      	ldr	x6, [x0, #0x28]
    8cf4:      	add	x6, x6, x9, lsl #4
    8cf8:      	ldr	x7, [x6]
    8cfc:      	ldr	x6, [x6, #0x8]
    8d00:      	mov	x9, #0x1                ; =1
    8d04:      	b	0x8d14 <_stogir.switch.case-inputs+0x13c>
    8d08:      	movz	x9, #0x0, lsl #48
    8d0c:      	movz	x7, #0x0, lsl #48
    8d10:      	movz	x6, #0x0, lsl #48
    8d14:      	lsr	w9, w9, #0
    8d18:      	lsr	x16, x9, #0
    8d1c:      	cmp	x16, #0x1
    8d20:      	b.eq	0x8d3c <_stogir.switch.case-inputs+0x164>
    8d24:      	b.lo	0x8d2c <_stogir.switch.case-inputs+0x154>
    8d28:      	b	0x8d40 <_stogir.switch.case-inputs+0x168>
    8d2c:      	cmp	x16, #0x0
    8d30:      	b.eq	0x8d38 <_stogir.switch.case-inputs+0x160>
    8d34:      	b	0x8d40 <_stogir.switch.case-inputs+0x168>
    8d38:      	b	0x8d44 <_stogir.switch.case-inputs+0x16c>
    8d3c:      	b	0x8d98 <_stogir.switch.case-inputs+0x1c0>
    8d40:      	b	0x8e94 <_stogir.switch.case-inputs+0x2bc>
    8d44:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008d44:  ARM64_RELOC_PAGE21	l_stogir.433
    8d48:      	ldr	x16, [x16]
		0000000000008d48:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    8d4c:      	orr	x19, x16, xzr
    8d50:      	mov	x21, x8
    8d54:      	mov	x1, #0x1                ; =1
    8d58:      	mov	x0, #0x1a               ; =26
    8d5c:      	str	x1, [x21]
    8d60:      	str	x19, [x21, #0x8]
    8d64:      	str	x0, [x21, #0x10]
    8d68:      	ldr	x19, [sp, #0x70]
    8d6c:      	ldr	x20, [sp, #0x78]
    8d70:      	ldr	x21, [sp, #0x80]
    8d74:      	ldr	x22, [sp, #0x88]
    8d78:      	ldr	x23, [sp, #0x90]
    8d7c:      	ldr	x24, [sp, #0x98]
    8d80:      	ldr	x25, [sp, #0xa0]
    8d84:      	ldr	x26, [sp, #0xa8]
    8d88:      	ldr	x29, [sp]
    8d8c:      	ldr	x30, [sp, #0x8]
    8d90:      	add	sp, sp, #0xb0
    8d94:      	ret
    8d98:      	cmp	x2, #0x0
    8d9c:      	b.gt	0x8dc4 <_stogir.switch.case-inputs+0x1ec>
    8da0:      	mov	x21, x8
    8da4:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008da4:  ARM64_RELOC_PAGE21	l_stogir.434
    8da8:      	ldr	x16, [x16]
		0000000000008da8:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    8dac:      	orr	x19, x16, xzr
    8db0:      	mov	x1, #0x1                ; =1
    8db4:      	mov	x0, #0x1f               ; =31
    8db8:      	b	0x8d5c <_stogir.switch.case-inputs+0x184>
    8dbc:      	movz	x7, #0x0, lsl #48
    8dc0:      	b	0x8cc0 <_stogir.switch.case-inputs+0xe8>
    8dc4:      	uxtb	w2, w7
    8dc8:      	cmp	x2, #0x75
    8dcc:      	b.ne	0x9008 <_stogir.switch.case-inputs+0x430>
    8dd0:      	lsr	w2, w7, #0
    8dd4:      	ubfx	x2, x2, #8, #8
    8dd8:      	cmp	x2, #0x0
    8ddc:      	b.ne	0x9010 <_stogir.switch.case-inputs+0x438>
    8de0:      	ldr	x2, [x0, #0x78]
    8de4:      	add	x2, x5, x2
    8de8:      	ldr	w2, [x2]
    8dec:      	sxtw	x2, w2
    8df0:      	cmp	x2, #0x2
    8df4:      	b.ne	0x9018 <_stogir.switch.case-inputs+0x440>
    8df8:      	sxtw	x20, w1
    8dfc:      	cmp	x20, #0x6d
    8e00:      	b.lt	0x9020 <_stogir.switch.case-inputs+0x448>
    8e04:      	cmp	x20, #0x6f
    8e08:      	b.gt	0x9028 <_stogir.switch.case-inputs+0x450>
    8e0c:      	add	x16, sp, #0x10
    8e10:      	orr	x19, x16, xzr
    8e14:      	lsr	w6, w6, #0
    8e18:      	lsr	x1, x7, #32
    8e1c:      	lsr	w6, w6, #0
    8e20:      	lsr	w1, w1, #0
    8e24:      	mov	w2, w6
    8e28:      	mov	x21, x8
    8e2c:      	add	x8, sp, #0x10
    8e30:      	mov	x22, x0
    8e34:      	mov	w23, w3
    8e38:      	mov	w24, w4
    8e3c:      	bl	0x8e3c <_stogir.switch.case-inputs+0x264>
		0000000000008e3c:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    8e40:      	add	x16, sp, #0x10
    8e44:      	ldr	w0, [x16]
    8e48:      	lsr	x16, x0, #0
    8e4c:      	cmp	x16, #0x1
    8e50:      	b.eq	0x8e6c <_stogir.switch.case-inputs+0x294>
    8e54:      	b.lo	0x8e5c <_stogir.switch.case-inputs+0x284>
    8e58:      	b	0x8e70 <_stogir.switch.case-inputs+0x298>
    8e5c:      	cmp	x16, #0x0
    8e60:      	b.eq	0x8e68 <_stogir.switch.case-inputs+0x290>
    8e64:      	b	0x8e70 <_stogir.switch.case-inputs+0x298>
    8e68:      	b	0x8e9c <_stogir.switch.case-inputs+0x2c4>
    8e6c:      	b	0x8e74 <_stogir.switch.case-inputs+0x29c>
    8e70:      	b	0x8ff0 <_stogir.switch.case-inputs+0x418>
    8e74:      	add	x0, x19, #0x8
    8e78:      	add	x16, sp, #0x10
    8e7c:      	ldr	x19, [x16, #0x8]
    8e80:      	ldr	x0, [x0, #0x8]
    8e84:      	mov	x1, #0x1                ; =1
    8e88:      	b	0x8db8 <_stogir.switch.case-inputs+0x1e0>
    8e8c:      	movz	x7, #0x0, lsl #48
    8e90:      	b	0x8cb8 <_stogir.switch.case-inputs+0xe0>
    8e94:      	brk	#0
    8e98:      	b	0x8e94 <_stogir.switch.case-inputs+0x2bc>
    8e9c:      	add	x16, sp, #0x10
    8ea0:      	ldr	w25, [x16, #0x8]
    8ea4:      	sxtw	x0, w25
    8ea8:      	and	x19, x0, #0xffffffff
    8eac:      	cmp	x20, #0x6f
    8eb0:      	b.ne	0x8ec0 <_stogir.switch.case-inputs+0x2e8>
    8eb4:      	movz	x1, #0x0, lsl #48
    8eb8:      	movz	x0, #0x0, lsl #48
    8ebc:      	b	0x8e88 <_stogir.switch.case-inputs+0x2b0>
    8ec0:      	add	x16, sp, #0x30
    8ec4:      	orr	x26, x16, xzr
    8ec8:      	lsr	w23, w23, #0
    8ecc:      	lsr	w25, w25, #0
    8ed0:      	add	x8, sp, #0x30
    8ed4:      	mov	x0, x22
    8ed8:      	mov	w1, w23
    8edc:      	mov	w2, w25
    8ee0:      	bl	0x8ee0 <_stogir.switch.case-inputs+0x308>
		0000000000008ee0:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    8ee4:      	add	x16, sp, #0x30
    8ee8:      	ldr	w0, [x16]
    8eec:      	lsr	x16, x0, #0
    8ef0:      	cmp	x16, #0x1
    8ef4:      	b.eq	0x8f10 <_stogir.switch.case-inputs+0x338>
    8ef8:      	b.lo	0x8f00 <_stogir.switch.case-inputs+0x328>
    8efc:      	b	0x8f14 <_stogir.switch.case-inputs+0x33c>
    8f00:      	cmp	x16, #0x0
    8f04:      	b.eq	0x8f0c <_stogir.switch.case-inputs+0x334>
    8f08:      	b	0x8f14 <_stogir.switch.case-inputs+0x33c>
    8f0c:      	b	0x8f30 <_stogir.switch.case-inputs+0x358>
    8f10:      	b	0x8f18 <_stogir.switch.case-inputs+0x340>
    8f14:      	b	0x8ff8 <_stogir.switch.case-inputs+0x420>
    8f18:      	add	x0, x26, #0x8
    8f1c:      	add	x16, sp, #0x30
    8f20:      	ldr	x19, [x16, #0x8]
    8f24:      	ldr	x0, [x0, #0x8]
    8f28:      	mov	x1, #0x1                ; =1
    8f2c:      	b	0x8ebc <_stogir.switch.case-inputs+0x2e4>
    8f30:      	add	x16, sp, #0x30
    8f34:      	ldr	x26, [x16, #0x8]
    8f38:      	cmp	x20, #0x6d
    8f3c:      	b.ne	0x8f54 <_stogir.switch.case-inputs+0x37c>
    8f40:      	sxtw	x24, w23
    8f44:      	b	0x8f58 <_stogir.switch.case-inputs+0x380>
    8f48:      	movz	x1, #0x0, lsl #48
    8f4c:      	movz	x0, #0x0, lsl #48
    8f50:      	b	0x8f2c <_stogir.switch.case-inputs+0x354>
    8f54:      	sxtw	x24, w24
    8f58:      	add	x16, sp, #0x50
    8f5c:      	orr	x20, x16, xzr
    8f60:      	lsr	w25, w25, #0
    8f64:      	lsr	w24, w24, #0
    8f68:      	add	x8, sp, #0x50
    8f6c:      	mov	x0, x22
    8f70:      	mov	w1, w24
    8f74:      	mov	w2, w25
    8f78:      	bl	0x8f78 <_stogir.switch.case-inputs+0x3a0>
		0000000000008f78:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    8f7c:      	add	x16, sp, #0x50
    8f80:      	ldr	w0, [x16]
    8f84:      	lsr	x16, x0, #0
    8f88:      	cmp	x16, #0x1
    8f8c:      	b.eq	0x8fa8 <_stogir.switch.case-inputs+0x3d0>
    8f90:      	b.lo	0x8f98 <_stogir.switch.case-inputs+0x3c0>
    8f94:      	b	0x8fac <_stogir.switch.case-inputs+0x3d4>
    8f98:      	cmp	x16, #0x0
    8f9c:      	b.eq	0x8fa4 <_stogir.switch.case-inputs+0x3cc>
    8fa0:      	b	0x8fac <_stogir.switch.case-inputs+0x3d4>
    8fa4:      	b	0x8fc8 <_stogir.switch.case-inputs+0x3f0>
    8fa8:      	b	0x8fb0 <_stogir.switch.case-inputs+0x3d8>
    8fac:      	b	0x9000 <_stogir.switch.case-inputs+0x428>
    8fb0:      	add	x0, x20, #0x8
    8fb4:      	add	x16, sp, #0x50
    8fb8:      	ldr	x19, [x16, #0x8]
    8fbc:      	ldr	x0, [x0, #0x8]
    8fc0:      	mov	x1, #0x1                ; =1
    8fc4:      	b	0x8f50 <_stogir.switch.case-inputs+0x378>
    8fc8:      	add	x16, sp, #0x50
    8fcc:      	ldr	x0, [x16, #0x8]
    8fd0:      	cmp	x26, x0
    8fd4:      	b.ls	0x8f48 <_stogir.switch.case-inputs+0x370>
    8fd8:      	adrp	x16, 0x8000 <_stogir.checked.projection+0xc8>
		0000000000008fd8:  ARM64_RELOC_PAGE21	l_stogir.435
    8fdc:      	ldr	x16, [x16]
		0000000000008fdc:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    8fe0:      	orr	x19, x16, xzr
    8fe4:      	mov	x1, #0x1                ; =1
    8fe8:      	mov	x0, #0x1a               ; =26
    8fec:      	b	0x8f50 <_stogir.switch.case-inputs+0x378>
    8ff0:      	brk	#0
    8ff4:      	b	0x8ff0 <_stogir.switch.case-inputs+0x418>
    8ff8:      	brk	#0
    8ffc:      	b	0x8ff8 <_stogir.switch.case-inputs+0x420>
    9000:      	brk	#0
    9004:      	b	0x9000 <_stogir.switch.case-inputs+0x428>
    9008:      	mov	x21, x8
    900c:      	b	0x8da4 <_stogir.switch.case-inputs+0x1cc>
    9010:      	mov	x21, x8
    9014:      	b	0x8da4 <_stogir.switch.case-inputs+0x1cc>
    9018:      	mov	x21, x8
    901c:      	b	0x8da4 <_stogir.switch.case-inputs+0x1cc>
    9020:      	mov	x21, x8
    9024:      	b	0x8da4 <_stogir.switch.case-inputs+0x1cc>
    9028:      	mov	x21, x8
    902c:      	b	0x8da4 <_stogir.switch.case-inputs+0x1cc>

0000000000009030 <_stogir.stack.valid-frame-object-inputs?>:
    9030:      	sub	sp, sp, #0x50
    9034:      	str	x29, [sp]
    9038:      	str	x30, [sp, #0x8]
    903c:      	mov	x29, sp
    9040:      	str	x19, [sp, #0x30]
    9044:      	str	x20, [sp, #0x38]
    9048:      	str	x21, [sp, #0x40]
    904c:      	add	x3, x0, #0x78
    9050:      	add	x4, x0, #0x28
    9054:      	add	x5, x0, #0x50
    9058:      	add	x6, x0, #0x78
    905c:      	add	x7, x0, #0x28
    9060:      	add	x8, x0, #0x50
    9064:      	sxtw	x1, w1
    9068:      	mov	x9, sp
    906c:      	sub	sp, sp, #0x10
    9070:      	mov	x10, sp
    9074:      	mov	x11, #0x1               ; =1
    9078:      	movz	x12, #0x0, lsl #48
    907c:      	b	0x9180 <_stogir.stack.valid-frame-object-inputs?+0x150>
    9080:      	movz	x15, #0x0, lsl #48
    9084:      	b	0x90f0 <_stogir.stack.valid-frame-object-inputs?+0xc0>
    9088:      	movz	x14, #0x0, lsl #48
    908c:      	movz	x13, #0x0, lsl #48
    9090:      	lsr	w14, w14, #0
    9094:      	lsr	x16, x14, #0
    9098:      	cmp	x16, #0x1
    909c:      	b.eq	0x90b8 <_stogir.stack.valid-frame-object-inputs?+0x88>
    90a0:      	b.lo	0x90a8 <_stogir.stack.valid-frame-object-inputs?+0x78>
    90a4:      	b	0x90bc <_stogir.stack.valid-frame-object-inputs?+0x8c>
    90a8:      	cmp	x16, #0x0
    90ac:      	b.eq	0x90b4 <_stogir.stack.valid-frame-object-inputs?+0x84>
    90b0:      	b	0x90bc <_stogir.stack.valid-frame-object-inputs?+0x8c>
    90b4:      	b	0x90dc <_stogir.stack.valid-frame-object-inputs?+0xac>
    90b8:      	b	0x90c0 <_stogir.stack.valid-frame-object-inputs?+0x90>
    90bc:      	b	0x9440 <_stogir.stack.valid-frame-object-inputs?+0x410>
    90c0:      	uxtb	w14, w13
    90c4:      	lsr	w13, w13, #0
    90c8:      	ubfx	x13, x13, #8, #8
    90cc:      	cmp	x14, x13
    90d0:      	b.eq	0x942c <_stogir.stack.valid-frame-object-inputs?+0x3fc>
    90d4:      	cmp	x14, #0x49
    90d8:      	b.eq	0x942c <_stogir.stack.valid-frame-object-inputs?+0x3fc>
    90dc:      	movz	x11, #0x0, lsl #48
    90e0:      	b	0x9258 <_stogir.stack.valid-frame-object-inputs?+0x228>
    90e4:      	movz	x15, #0x0, lsl #48
    90e8:      	b	0x90f8 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    90ec:      	movz	x15, #0x0, lsl #48
    90f0:      	b	0x9100 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    90f4:      	movz	x15, #0x0, lsl #48
    90f8:      	b	0x9100 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    90fc:      	movz	x15, #0x0, lsl #48
    9100:      	cmp	x15, #0x0
    9104:      	b.eq	0x9140 <_stogir.stack.valid-frame-object-inputs?+0x110>
    9108:      	uxtb	w16, w14
    910c:      	cmp	w16, wzr
    9110:      	b.eq	0x9128 <_stogir.stack.valid-frame-object-inputs?+0xf8>
    9114:      	ldr	x14, [x0]
    9118:      	add	x13, x14, x13, lsl #4
    911c:      	ldr	x14, [x13]
    9120:      	ldr	x13, [x13, #0x8]
    9124:      	b	0x9138 <_stogir.stack.valid-frame-object-inputs?+0x108>
    9128:      	ldr	x13, [x0, #0x28]
    912c:      	add	x13, x13, x19, lsl #4
    9130:      	ldr	x14, [x13]
    9134:      	ldr	x13, [x13, #0x8]
    9138:      	mov	x15, #0x1               ; =1
    913c:      	b	0x914c <_stogir.stack.valid-frame-object-inputs?+0x11c>
    9140:      	movz	x15, #0x0, lsl #48
    9144:      	movz	x14, #0x0, lsl #48
    9148:      	movz	x13, #0x0, lsl #48
    914c:      	lsr	w15, w15, #0
    9150:      	lsr	x16, x15, #0
    9154:      	cmp	x16, #0x1
    9158:      	b.eq	0x9174 <_stogir.stack.valid-frame-object-inputs?+0x144>
    915c:      	b.lo	0x9164 <_stogir.stack.valid-frame-object-inputs?+0x134>
    9160:      	b	0x9178 <_stogir.stack.valid-frame-object-inputs?+0x148>
    9164:      	cmp	x16, #0x0
    9168:      	b.eq	0x9170 <_stogir.stack.valid-frame-object-inputs?+0x140>
    916c:      	b	0x9178 <_stogir.stack.valid-frame-object-inputs?+0x148>
    9170:      	b	0x917c <_stogir.stack.valid-frame-object-inputs?+0x14c>
    9174:      	b	0x9230 <_stogir.stack.valid-frame-object-inputs?+0x200>
    9178:      	b	0x9398 <_stogir.stack.valid-frame-object-inputs?+0x368>
    917c:      	movz	x11, #0x0, lsl #48
    9180:      	cmp	x11, #0x0
    9184:      	b.eq	0x92e4 <_stogir.stack.valid-frame-object-inputs?+0x2b4>
    9188:      	cmp	x12, #0x0
    918c:      	b.ne	0x92e4 <_stogir.stack.valid-frame-object-inputs?+0x2b4>
    9190:      	lsr	w13, w1, #0
    9194:      	sxtw	x13, w13
    9198:      	cmp	x13, #0x0
    919c:      	cset	w14, gt
    91a0:      	movz	x16, #0x0, lsl #48
    91a4:      	sub	x15, x16, x13
    91a8:      	sub	x19, x15, #0x1
    91ac:      	uxtb	w16, w14
    91b0:      	cmp	w16, wzr
    91b4:      	b.eq	0x91f0 <_stogir.stack.valid-frame-object-inputs?+0x1c0>
    91b8:      	ldr	x15, [x0, #0x8]
    91bc:      	cmp	x13, x15
    91c0:      	b.ge	0x90f4 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    91c4:      	ldr	x15, [x3, #0x8]
    91c8:      	cmp	x13, x15
    91cc:      	b.ge	0x90e4 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    91d0:      	ldr	x15, [x0, #0x78]
    91d4:      	add	x15, x15, x13, lsl #2
    91d8:      	ldr	w15, [x15]
    91dc:      	sxtw	x15, w15
    91e0:      	cmp	x15, #0x0
    91e4:      	cset	w15, ge
    91e8:      	ubfx	x15, x15, #0, #8
    91ec:      	b	0x90e8 <_stogir.stack.valid-frame-object-inputs?+0xb8>
    91f0:      	cmp	x13, #0x0
    91f4:      	b.ge	0x90fc <_stogir.stack.valid-frame-object-inputs?+0xcc>
    91f8:      	ldr	x20, [x4, #0x8]
    91fc:      	ldr	x21, [x5, #0x8]
    9200:      	cmp	x20, x21
    9204:      	b.ne	0x90ec <_stogir.stack.valid-frame-object-inputs?+0xbc>
    9208:      	cmp	x15, x20
    920c:      	b.gt	0x9080 <_stogir.stack.valid-frame-object-inputs?+0x50>
    9210:      	ldr	x15, [x0, #0x50]
    9214:      	add	x15, x15, x19, lsl #2
    9218:      	ldr	w15, [x15]
    921c:      	sxtw	x15, w15
    9220:      	cmp	x15, #0x0
    9224:      	cset	w15, gt
    9228:      	ubfx	x15, x15, #0, #8
    922c:      	b	0x9084 <_stogir.stack.valid-frame-object-inputs?+0x54>
    9230:      	uxtb	w15, w14
    9234:      	asr	x19, x14, #32
    9238:      	str	x14, [x10]
    923c:      	str	x13, [x10, #0x8]
    9240:      	cmp	x15, #0x68
    9244:      	b.ne	0x925c <_stogir.stack.valid-frame-object-inputs?+0x22c>
    9248:      	cmp	x19, #0x0
    924c:      	cset	w11, eq
    9250:      	ubfx	x11, x11, #0, #8
    9254:      	mov	x12, #0x1               ; =1
    9258:      	b	0x9180 <_stogir.stack.valid-frame-object-inputs?+0x150>
    925c:      	cmp	x1, #0x0
    9260:      	b.le	0x90dc <_stogir.stack.valid-frame-object-inputs?+0xac>
    9264:      	cmp	x15, #0x51
    9268:      	b.ne	0x90dc <_stogir.stack.valid-frame-object-inputs?+0xac>
    926c:      	cmp	x19, #0x0
    9270:      	b.le	0x90dc <_stogir.stack.valid-frame-object-inputs?+0xac>
    9274:      	cmp	x19, x1
    9278:      	b.ge	0x90dc <_stogir.stack.valid-frame-object-inputs?+0xac>
    927c:      	lsr	w13, w13, #0
    9280:      	sxtw	x13, w13
    9284:      	cmp	x13, #0x0
    9288:      	b.ge	0x90dc <_stogir.stack.valid-frame-object-inputs?+0xac>
    928c:      	cmp	x13, #0x0
    9290:      	cset	w14, gt
    9294:      	movz	x16, #0x0, lsl #48
    9298:      	sub	x15, x16, x13
    929c:      	sub	x19, x15, #0x1
    92a0:      	uxtb	w16, w14
    92a4:      	cmp	w16, wzr
    92a8:      	b.eq	0x93e4 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    92ac:      	ldr	x15, [x0, #0x8]
    92b0:      	cmp	x13, x15
    92b4:      	b.ge	0x93dc <_stogir.stack.valid-frame-object-inputs?+0x3ac>
    92b8:      	ldr	x15, [x6, #0x8]
    92bc:      	cmp	x13, x15
    92c0:      	b.ge	0x9424 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    92c4:      	ldr	x15, [x0, #0x78]
    92c8:      	add	x15, x15, x13, lsl #2
    92cc:      	ldr	w15, [x15]
    92d0:      	sxtw	x15, w15
    92d4:      	cmp	x15, #0x0
    92d8:      	cset	w15, ge
    92dc:      	ubfx	x15, x15, #0, #8
    92e0:      	b	0x9428 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    92e4:      	cmp	x11, #0x0
    92e8:      	b.ne	0x92f0 <_stogir.stack.valid-frame-object-inputs?+0x2c0>
    92ec:      	movz	x12, #0x0, lsl #48
    92f0:      	mov	sp, x9
    92f4:      	cmp	x12, #0x0
    92f8:      	b.eq	0x9354 <_stogir.stack.valid-frame-object-inputs?+0x324>
    92fc:      	sxtw	x1, w2
    9300:      	cmp	x1, #0x0
    9304:      	b.ge	0x9378 <_stogir.stack.valid-frame-object-inputs?+0x348>
    9308:      	lsr	w2, w2, #0
    930c:      	add	x8, x29, #0x10
    9310:      	mov	w1, w2
    9314:      	bl	0x9314 <_stogir.stack.valid-frame-object-inputs?+0x2e4>
		0000000000009314:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    9318:      	add	x16, x29, #0x10
    931c:      	ldr	w0, [x16]
    9320:      	lsr	x16, x0, #0
    9324:      	cmp	x16, #0x1
    9328:      	b.eq	0x9344 <_stogir.stack.valid-frame-object-inputs?+0x314>
    932c:      	b.lo	0x9334 <_stogir.stack.valid-frame-object-inputs?+0x304>
    9330:      	b	0x9348 <_stogir.stack.valid-frame-object-inputs?+0x318>
    9334:      	cmp	x16, #0x0
    9338:      	b.eq	0x9340 <_stogir.stack.valid-frame-object-inputs?+0x310>
    933c:      	b	0x9348 <_stogir.stack.valid-frame-object-inputs?+0x318>
    9340:      	b	0x9380 <_stogir.stack.valid-frame-object-inputs?+0x350>
    9344:      	b	0x934c <_stogir.stack.valid-frame-object-inputs?+0x31c>
    9348:      	b	0x9438 <_stogir.stack.valid-frame-object-inputs?+0x408>
    934c:      	movz	x0, #0x0, lsl #48
    9350:      	b	0x9394 <_stogir.stack.valid-frame-object-inputs?+0x364>
    9354:      	movz	x0, #0x0, lsl #48
    9358:      	sub	sp, x29, #0x0
    935c:      	ldr	x19, [sp, #0x30]
    9360:      	ldr	x20, [sp, #0x38]
    9364:      	ldr	x21, [sp, #0x40]
    9368:      	ldr	x29, [sp]
    936c:      	ldr	x30, [sp, #0x8]
    9370:      	add	sp, sp, #0x50
    9374:      	ret
    9378:      	movz	x0, #0x0, lsl #48
    937c:      	b	0x9358 <_stogir.stack.valid-frame-object-inputs?+0x328>
    9380:      	add	x16, x29, #0x10
    9384:      	ldr	x0, [x16, #0x8]
    9388:      	cmp	x0, #0x0
    938c:      	cset	w0, gt
    9390:      	ubfx	x0, x0, #0, #8
    9394:      	b	0x937c <_stogir.stack.valid-frame-object-inputs?+0x34c>
    9398:      	brk	#0
    939c:      	b	0x9398 <_stogir.stack.valid-frame-object-inputs?+0x368>
    93a0:      	ldr	x13, [x0, #0x28]
    93a4:      	add	x13, x13, x19, lsl #4
    93a8:      	ldr	x13, [x13]
    93ac:      	mov	x14, #0x1               ; =1
    93b0:      	b	0x9090 <_stogir.stack.valid-frame-object-inputs?+0x60>
    93b4:      	movz	x15, #0x0, lsl #48
    93b8:      	cmp	x15, #0x0
    93bc:      	b.eq	0x9088 <_stogir.stack.valid-frame-object-inputs?+0x58>
    93c0:      	uxtb	w16, w14
    93c4:      	cmp	w16, wzr
    93c8:      	b.eq	0x93a0 <_stogir.stack.valid-frame-object-inputs?+0x370>
    93cc:      	ldr	x14, [x0]
    93d0:      	add	x13, x14, x13, lsl #4
    93d4:      	ldr	x13, [x13]
    93d8:      	b	0x93ac <_stogir.stack.valid-frame-object-inputs?+0x37c>
    93dc:      	movz	x15, #0x0, lsl #48
    93e0:      	b	0x93b8 <_stogir.stack.valid-frame-object-inputs?+0x388>
    93e4:      	ldr	x20, [x7, #0x8]
    93e8:      	ldr	x21, [x8, #0x8]
    93ec:      	cmp	x20, x21
    93f0:      	b.ne	0x93b4 <_stogir.stack.valid-frame-object-inputs?+0x384>
    93f4:      	cmp	x15, x20
    93f8:      	b.gt	0x941c <_stogir.stack.valid-frame-object-inputs?+0x3ec>
    93fc:      	ldr	x15, [x0, #0x50]
    9400:      	add	x15, x15, x19, lsl #2
    9404:      	ldr	w15, [x15]
    9408:      	sxtw	x15, w15
    940c:      	cmp	x15, #0x0
    9410:      	cset	w15, gt
    9414:      	ubfx	x15, x15, #0, #8
    9418:      	b	0x9420 <_stogir.stack.valid-frame-object-inputs?+0x3f0>
    941c:      	movz	x15, #0x0, lsl #48
    9420:      	b	0x93b8 <_stogir.stack.valid-frame-object-inputs?+0x388>
    9424:      	movz	x15, #0x0, lsl #48
    9428:      	b	0x93e0 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    942c:      	ldr	w1, [x10, #0x4]
    9430:      	sxtw	x1, w1
    9434:      	b	0x90e0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    9438:      	brk	#0
    943c:      	b	0x9438 <_stogir.stack.valid-frame-object-inputs?+0x408>
    9440:      	brk	#0
    9444:      	b	0x9440 <_stogir.stack.valid-frame-object-inputs?+0x410>

0000000000009448 <_stogir.stack.validate-scope-inputs>:
    9448:      	sxtw	x1, w1
    944c:      	cmp	x1, #0x53
    9450:      	cset	w5, eq
    9454:      	uxtb	w16, w5
    9458:      	cmp	w16, wzr
    945c:      	b.ne	0x948c <_stogir.stack.validate-scope-inputs+0x44>
    9460:      	cmp	x1, #0x54
    9464:      	b.eq	0x948c <_stogir.stack.validate-scope-inputs+0x44>
    9468:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009468:  ARM64_RELOC_PAGE21	l_stogir.436
    946c:      	ldr	x16, [x16]
		000000000000946c:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    9470:      	orr	x0, x16, xzr
    9474:      	mov	x1, #0x1                ; =1
    9478:      	mov	x2, #0x22               ; =34
    947c:      	str	x1, [x8]
    9480:      	str	x0, [x8, #0x8]
    9484:      	str	x2, [x8, #0x10]
    9488:      	ret
    948c:      	uxtb	w16, w5
    9490:      	cmp	w16, wzr
    9494:      	mov	x16, #0x6               ; =6
    9498:      	movz	x17, #0x0, lsl #48
    949c:      	csel	x1, x16, x17, ne
    94a0:      	sxtw	x2, w2
    94a4:      	lsr	w1, w1, #0
    94a8:      	sxtw	x1, w1
    94ac:      	cmp	x2, x1
    94b0:      	b.ne	0x9468 <_stogir.stack.validate-scope-inputs+0x20>
    94b4:      	sxtw	x3, w3
    94b8:      	cmp	x3, #0x0
    94bc:      	cset	w1, gt
    94c0:      	movz	x16, #0x0, lsl #48
    94c4:      	sub	x2, x16, x3
    94c8:      	sub	x6, x2, #0x1
    94cc:      	uxtb	w16, w1
    94d0:      	cmp	w16, wzr
    94d4:      	b.eq	0x95a8 <_stogir.stack.validate-scope-inputs+0x160>
    94d8:      	ldr	x2, [x0, #0x8]
    94dc:      	cmp	x3, x2
    94e0:      	b.ge	0x95a0 <_stogir.stack.validate-scope-inputs+0x158>
    94e4:      	add	x2, x0, #0x78
    94e8:      	ldr	x2, [x2, #0x8]
    94ec:      	cmp	x3, x2
    94f0:      	b.ge	0x9648 <_stogir.stack.validate-scope-inputs+0x200>
    94f4:      	ldr	x2, [x0, #0x78]
    94f8:      	add	x2, x2, x3, lsl #2
    94fc:      	ldr	w2, [x2]
    9500:      	sxtw	x2, w2
    9504:      	cmp	x2, #0x0
    9508:      	cset	w2, ge
    950c:      	ubfx	x2, x2, #0, #8
    9510:      	b	0x964c <_stogir.stack.validate-scope-inputs+0x204>
    9514:      	movz	x2, #0x0, lsl #48
    9518:      	movz	x1, #0x0, lsl #48
    951c:      	lsr	w2, w2, #0
    9520:      	lsr	x16, x2, #0
    9524:      	cmp	x16, #0x1
    9528:      	b.eq	0x9544 <_stogir.stack.validate-scope-inputs+0xfc>
    952c:      	b.lo	0x9534 <_stogir.stack.validate-scope-inputs+0xec>
    9530:      	b	0x9548 <_stogir.stack.validate-scope-inputs+0x100>
    9534:      	cmp	x16, #0x0
    9538:      	b.eq	0x9540 <_stogir.stack.validate-scope-inputs+0xf8>
    953c:      	b	0x9548 <_stogir.stack.validate-scope-inputs+0x100>
    9540:      	b	0x954c <_stogir.stack.validate-scope-inputs+0x104>
    9544:      	b	0x95f0 <_stogir.stack.validate-scope-inputs+0x1a8>
    9548:      	b	0x9818 <_stogir.stack.validate-scope-inputs+0x3d0>
    954c:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		000000000000954c:  ARM64_RELOC_PAGE21	l_stogir.437
    9550:      	ldr	x16, [x16]
		0000000000009550:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    9554:      	orr	x0, x16, xzr
    9558:      	mov	x1, #0x1                ; =1
    955c:      	mov	x2, #0x1b               ; =27
    9560:      	b	0x947c <_stogir.stack.validate-scope-inputs+0x34>
    9564:      	ldr	x1, [x0, #0x28]
    9568:      	add	x1, x1, x6, lsl #4
    956c:      	ldr	x1, [x1]
    9570:      	mov	x2, #0x1                ; =1
    9574:      	b	0x951c <_stogir.stack.validate-scope-inputs+0xd4>
    9578:      	movz	x2, #0x0, lsl #48
    957c:      	cmp	x2, #0x0
    9580:      	b.eq	0x9514 <_stogir.stack.validate-scope-inputs+0xcc>
    9584:      	uxtb	w16, w1
    9588:      	cmp	w16, wzr
    958c:      	b.eq	0x9564 <_stogir.stack.validate-scope-inputs+0x11c>
    9590:      	ldr	x1, [x0]
    9594:      	add	x1, x1, x3, lsl #4
    9598:      	ldr	x1, [x1]
    959c:      	b	0x9570 <_stogir.stack.validate-scope-inputs+0x128>
    95a0:      	movz	x2, #0x0, lsl #48
    95a4:      	b	0x957c <_stogir.stack.validate-scope-inputs+0x134>
    95a8:      	cmp	x3, #0x0
    95ac:      	b.ge	0x9578 <_stogir.stack.validate-scope-inputs+0x130>
    95b0:      	add	x7, x0, #0x28
    95b4:      	add	x9, x0, #0x50
    95b8:      	ldr	x7, [x7, #0x8]
    95bc:      	ldr	x9, [x9, #0x8]
    95c0:      	cmp	x7, x9
    95c4:      	b.ne	0x9640 <_stogir.stack.validate-scope-inputs+0x1f8>
    95c8:      	cmp	x2, x7
    95cc:      	b.gt	0x9650 <_stogir.stack.validate-scope-inputs+0x208>
    95d0:      	ldr	x2, [x0, #0x50]
    95d4:      	add	x2, x2, x6, lsl #2
    95d8:      	ldr	w2, [x2]
    95dc:      	sxtw	x2, w2
    95e0:      	cmp	x2, #0x0
    95e4:      	cset	w2, gt
    95e8:      	ubfx	x2, x2, #0, #8
    95ec:      	b	0x9654 <_stogir.stack.validate-scope-inputs+0x20c>
    95f0:      	cmp	x3, #0x0
    95f4:      	b.le	0x9628 <_stogir.stack.validate-scope-inputs+0x1e0>
    95f8:      	uxtb	w1, w1
    95fc:      	cmp	x1, #0x83
    9600:      	cset	w2, lt
    9604:      	uxtb	w16, w2
    9608:      	cmp	w16, wzr
    960c:      	b.eq	0x9658 <_stogir.stack.validate-scope-inputs+0x210>
    9610:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009610:  ARM64_RELOC_PAGE21	l_stogir.438
    9614:      	ldr	x16, [x16]
		0000000000009614:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9618:      	orr	x3, x16, xzr
    961c:      	add	x3, x1, x3
    9620:      	ldrb	w3, [x3]
    9624:      	b	0x965c <_stogir.stack.validate-scope-inputs+0x214>
    9628:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009628:  ARM64_RELOC_PAGE21	l_stogir.439
    962c:      	ldr	x16, [x16]
		000000000000962c:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    9630:      	orr	x0, x16, xzr
    9634:      	mov	x1, #0x1                ; =1
    9638:      	mov	x2, #0x1b               ; =27
    963c:      	b	0x9560 <_stogir.stack.validate-scope-inputs+0x118>
    9640:      	movz	x2, #0x0, lsl #48
    9644:      	b	0x957c <_stogir.stack.validate-scope-inputs+0x134>
    9648:      	movz	x2, #0x0, lsl #48
    964c:      	b	0x95a4 <_stogir.stack.validate-scope-inputs+0x15c>
    9650:      	movz	x2, #0x0, lsl #48
    9654:      	b	0x9644 <_stogir.stack.validate-scope-inputs+0x1fc>
    9658:      	movz	x3, #0x0, lsl #48
    965c:      	uxtb	w3, w3
    9660:      	and	x3, x3, #0x1
    9664:      	uxtb	w3, w3
    9668:      	cmp	x3, #0x0
    966c:      	b.eq	0x9628 <_stogir.stack.validate-scope-inputs+0x1e0>
    9670:      	uxtb	w16, w2
    9674:      	cmp	w16, wzr
    9678:      	b.eq	0x9694 <_stogir.stack.validate-scope-inputs+0x24c>
    967c:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		000000000000967c:  ARM64_RELOC_PAGE21	l_stogir.438
    9680:      	ldr	x16, [x16]
		0000000000009680:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9684:      	orr	x2, x16, xzr
    9688:      	add	x1, x1, x2
    968c:      	ldrb	w1, [x1]
    9690:      	b	0x9698 <_stogir.stack.validate-scope-inputs+0x250>
    9694:      	movz	x1, #0x0, lsl #48
    9698:      	uxtb	w1, w1
    969c:      	and	x1, x1, #0x4
    96a0:      	uxtb	w1, w1
    96a4:      	cmp	x1, #0x0
    96a8:      	cset	w1, eq
    96ac:      	uxtb	w16, w1
    96b0:      	cmp	w16, wzr
    96b4:      	cset	x1, eq
    96b8:      	cmp	x1, #0x0
    96bc:      	b.ne	0x9628 <_stogir.stack.validate-scope-inputs+0x1e0>
    96c0:      	uxtb	w16, w5
    96c4:      	cmp	w16, wzr
    96c8:      	b.eq	0x96dc <_stogir.stack.validate-scope-inputs+0x294>
    96cc:      	movz	x1, #0x0, lsl #48
    96d0:      	mov	x0, #0x8                ; =8
    96d4:      	movz	x2, #0x0, lsl #48
    96d8:      	b	0x963c <_stogir.stack.validate-scope-inputs+0x1f4>
    96dc:      	sxtw	x4, w4
    96e0:      	cmp	x4, #0x0
    96e4:      	cset	w1, gt
    96e8:      	movz	x16, #0x0, lsl #48
    96ec:      	sub	x2, x16, x4
    96f0:      	sub	x3, x2, #0x1
    96f4:      	uxtb	w16, w1
    96f8:      	cmp	w16, wzr
    96fc:      	b.eq	0x97d0 <_stogir.stack.validate-scope-inputs+0x388>
    9700:      	ldr	x2, [x0, #0x8]
    9704:      	cmp	x4, x2
    9708:      	b.ge	0x97c8 <_stogir.stack.validate-scope-inputs+0x380>
    970c:      	add	x2, x0, #0x78
    9710:      	ldr	x2, [x2, #0x8]
    9714:      	cmp	x4, x2
    9718:      	b.ge	0x986c <_stogir.stack.validate-scope-inputs+0x424>
    971c:      	ldr	x2, [x0, #0x78]
    9720:      	add	x2, x2, x4, lsl #2
    9724:      	ldr	w2, [x2]
    9728:      	sxtw	x2, w2
    972c:      	cmp	x2, #0x0
    9730:      	cset	w2, ge
    9734:      	ubfx	x2, x2, #0, #8
    9738:      	b	0x9870 <_stogir.stack.validate-scope-inputs+0x428>
    973c:      	movz	x1, #0x0, lsl #48
    9740:      	movz	x0, #0x0, lsl #48
    9744:      	lsr	w1, w1, #0
    9748:      	lsr	x16, x1, #0
    974c:      	cmp	x16, #0x1
    9750:      	b.eq	0x976c <_stogir.stack.validate-scope-inputs+0x324>
    9754:      	b.lo	0x975c <_stogir.stack.validate-scope-inputs+0x314>
    9758:      	b	0x9770 <_stogir.stack.validate-scope-inputs+0x328>
    975c:      	cmp	x16, #0x0
    9760:      	b.eq	0x9768 <_stogir.stack.validate-scope-inputs+0x320>
    9764:      	b	0x9770 <_stogir.stack.validate-scope-inputs+0x328>
    9768:      	b	0x9774 <_stogir.stack.validate-scope-inputs+0x32c>
    976c:      	b	0x9820 <_stogir.stack.validate-scope-inputs+0x3d8>
    9770:      	b	0x987c <_stogir.stack.validate-scope-inputs+0x434>
    9774:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009774:  ARM64_RELOC_PAGE21	l_stogir.440
    9778:      	ldr	x16, [x16]
		0000000000009778:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    977c:      	orr	x0, x16, xzr
    9780:      	mov	x1, #0x1                ; =1
    9784:      	mov	x2, #0x1b               ; =27
    9788:      	b	0x96d8 <_stogir.stack.validate-scope-inputs+0x290>
    978c:      	ldr	x0, [x0, #0x28]
    9790:      	add	x0, x0, x3, lsl #4
    9794:      	ldr	x0, [x0]
    9798:      	mov	x1, #0x1                ; =1
    979c:      	b	0x9744 <_stogir.stack.validate-scope-inputs+0x2fc>
    97a0:      	movz	x2, #0x0, lsl #48
    97a4:      	cmp	x2, #0x0
    97a8:      	b.eq	0x973c <_stogir.stack.validate-scope-inputs+0x2f4>
    97ac:      	uxtb	w16, w1
    97b0:      	cmp	w16, wzr
    97b4:      	b.eq	0x978c <_stogir.stack.validate-scope-inputs+0x344>
    97b8:      	ldr	x0, [x0]
    97bc:      	add	x0, x0, x4, lsl #4
    97c0:      	ldr	x0, [x0]
    97c4:      	b	0x9798 <_stogir.stack.validate-scope-inputs+0x350>
    97c8:      	movz	x2, #0x0, lsl #48
    97cc:      	b	0x97a4 <_stogir.stack.validate-scope-inputs+0x35c>
    97d0:      	cmp	x4, #0x0
    97d4:      	b.ge	0x97a0 <_stogir.stack.validate-scope-inputs+0x358>
    97d8:      	add	x5, x0, #0x28
    97dc:      	add	x6, x0, #0x50
    97e0:      	ldr	x5, [x5, #0x8]
    97e4:      	ldr	x6, [x6, #0x8]
    97e8:      	cmp	x5, x6
    97ec:      	b.ne	0x9864 <_stogir.stack.validate-scope-inputs+0x41c>
    97f0:      	cmp	x2, x5
    97f4:      	b.gt	0x9874 <_stogir.stack.validate-scope-inputs+0x42c>
    97f8:      	ldr	x2, [x0, #0x50]
    97fc:      	add	x2, x2, x3, lsl #2
    9800:      	ldr	w2, [x2]
    9804:      	sxtw	x2, w2
    9808:      	cmp	x2, #0x0
    980c:      	cset	w2, gt
    9810:      	ubfx	x2, x2, #0, #8
    9814:      	b	0x9878 <_stogir.stack.validate-scope-inputs+0x430>
    9818:      	brk	#0
    981c:      	b	0x9818 <_stogir.stack.validate-scope-inputs+0x3d0>
    9820:      	lsr	w1, w0, #0
    9824:      	ubfx	x1, x1, #8, #8
    9828:      	cmp	x1, #0x6
    982c:      	b.ne	0x984c <_stogir.stack.validate-scope-inputs+0x404>
    9830:      	uxtb	w0, w0
    9834:      	cmp	x0, #0x48
    9838:      	b.eq	0x984c <_stogir.stack.validate-scope-inputs+0x404>
    983c:      	movz	x1, #0x0, lsl #48
    9840:      	mov	x0, #0x8                ; =8
    9844:      	movz	x2, #0x0, lsl #48
    9848:      	b	0x9860 <_stogir.stack.validate-scope-inputs+0x418>
    984c:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		000000000000984c:  ARM64_RELOC_PAGE21	l_stogir.441
    9850:      	ldr	x16, [x16]
		0000000000009850:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    9854:      	orr	x0, x16, xzr
    9858:      	mov	x1, #0x1                ; =1
    985c:      	mov	x2, #0x29               ; =41
    9860:      	b	0x9788 <_stogir.stack.validate-scope-inputs+0x340>
    9864:      	movz	x2, #0x0, lsl #48
    9868:      	b	0x97a4 <_stogir.stack.validate-scope-inputs+0x35c>
    986c:      	movz	x2, #0x0, lsl #48
    9870:      	b	0x97cc <_stogir.stack.validate-scope-inputs+0x384>
    9874:      	movz	x2, #0x0, lsl #48
    9878:      	b	0x9868 <_stogir.stack.validate-scope-inputs+0x420>
    987c:      	brk	#0
    9880:      	b	0x987c <_stogir.stack.validate-scope-inputs+0x434>

0000000000009884 <_stogir.stack.validate-inputs>:
    9884:      	sub	sp, sp, #0x110
    9888:      	str	x29, [sp]
    988c:      	str	x30, [sp, #0x8]
    9890:      	mov	x29, sp
    9894:      	str	x19, [sp, #0xb8]
    9898:      	str	x20, [sp, #0xc0]
    989c:      	str	x21, [sp, #0xc8]
    98a0:      	str	x22, [sp, #0xd0]
    98a4:      	str	x23, [sp, #0xd8]
    98a8:      	str	x24, [sp, #0xe0]
    98ac:      	str	x25, [sp, #0xe8]
    98b0:      	str	x26, [sp, #0xf0]
    98b4:      	str	x27, [sp, #0xf8]
    98b8:      	str	x28, [sp, #0x100]
    98bc:      	sxtw	x1, w1
    98c0:      	cmp	x1, #0x51
    98c4:      	cset	w19, eq
    98c8:      	uxtb	w16, w19
    98cc:      	cmp	w16, wzr
    98d0:      	b.ne	0x993c <_stogir.stack.validate-inputs+0xb8>
    98d4:      	cmp	x1, #0x52
    98d8:      	b.eq	0x993c <_stogir.stack.validate-inputs+0xb8>
    98dc:      	str	x8, [sp, #0x90]
    98e0:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		00000000000098e0:  ARM64_RELOC_PAGE21	l_stogir.442
    98e4:      	ldr	x16, [x16]
		00000000000098e4:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    98e8:      	orr	x0, x16, xzr
    98ec:      	mov	x2, #0x1                ; =1
    98f0:      	mov	x1, #0x29               ; =41
    98f4:      	ldr	x3, [sp, #0x90]
    98f8:      	str	x2, [x3]
    98fc:      	str	x0, [x3, #0x8]
    9900:      	str	x1, [x3, #0x10]
    9904:      	ldr	x19, [sp, #0xb8]
    9908:      	ldr	x20, [sp, #0xc0]
    990c:      	ldr	x21, [sp, #0xc8]
    9910:      	ldr	x22, [sp, #0xd0]
    9914:      	ldr	x23, [sp, #0xd8]
    9918:      	ldr	x24, [sp, #0xe0]
    991c:      	ldr	x25, [sp, #0xe8]
    9920:      	ldr	x26, [sp, #0xf0]
    9924:      	ldr	x27, [sp, #0xf8]
    9928:      	ldr	x28, [sp, #0x100]
    992c:      	ldr	x29, [sp]
    9930:      	ldr	x30, [sp, #0x8]
    9934:      	add	sp, sp, #0x110
    9938:      	ret
    993c:      	uxtb	w16, w19
    9940:      	cmp	w16, wzr
    9944:      	mov	x16, #0x6               ; =6
    9948:      	movz	x17, #0x0, lsl #48
    994c:      	csel	x1, x16, x17, ne
    9950:      	sxtw	x2, w2
    9954:      	lsr	w1, w1, #0
    9958:      	sxtw	x1, w1
    995c:      	cmp	x2, x1
    9960:      	b.ne	0x9ea4 <_stogir.stack.validate-inputs+0x620>
    9964:      	sxtw	x20, w5
    9968:      	uxtb	w16, w19
    996c:      	cmp	w16, wzr
    9970:      	b.eq	0x9994 <_stogir.stack.validate-inputs+0x110>
    9974:      	cmp	x20, #0x0
    9978:      	b.eq	0x9994 <_stogir.stack.validate-inputs+0x110>
    997c:      	cmp	x20, #0x0
    9980:      	b.le	0x9a34 <_stogir.stack.validate-inputs+0x1b0>
    9984:      	sub	x1, x20, #0x1
    9988:      	and	x1, x1, x20
    998c:      	cmp	x1, #0x0
    9990:      	b.ne	0x9a34 <_stogir.stack.validate-inputs+0x1b0>
    9994:      	lsr	w3, w3, #0
    9998:      	mov	w1, w3
    999c:      	mov	x21, x8
    99a0:      	add	x8, sp, #0x10
    99a4:      	mov	x22, x0
    99a8:      	mov	w23, w3
    99ac:      	mov	w24, w4
    99b0:      	bl	0x99b0 <_stogir.stack.validate-inputs+0x12c>
		00000000000099b0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    99b4:      	add	x16, sp, #0x10
    99b8:      	ldr	w0, [x16]
    99bc:      	lsr	x16, x0, #0
    99c0:      	cmp	x16, #0x1
    99c4:      	b.eq	0x99e0 <_stogir.stack.validate-inputs+0x15c>
    99c8:      	b.lo	0x99d0 <_stogir.stack.validate-inputs+0x14c>
    99cc:      	b	0x99e4 <_stogir.stack.validate-inputs+0x160>
    99d0:      	cmp	x16, #0x0
    99d4:      	b.eq	0x99dc <_stogir.stack.validate-inputs+0x158>
    99d8:      	b	0x99e4 <_stogir.stack.validate-inputs+0x160>
    99dc:      	b	0x99e8 <_stogir.stack.validate-inputs+0x164>
    99e0:      	b	0x9a04 <_stogir.stack.validate-inputs+0x180>
    99e4:      	b	0x9cb8 <_stogir.stack.validate-inputs+0x434>
    99e8:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		00000000000099e8:  ARM64_RELOC_PAGE21	l_stogir.443
    99ec:      	ldr	x16, [x16]
		00000000000099ec:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    99f0:      	orr	x0, x16, xzr
    99f4:      	str	x21, [sp, #0x90]
    99f8:      	mov	x2, #0x1                ; =1
    99fc:      	mov	x1, #0x1f               ; =31
    9a00:      	b	0x98f4 <_stogir.stack.validate-inputs+0x70>
    9a04:      	sxtw	x23, w23
    9a08:      	add	x16, sp, #0x10
    9a0c:      	ldr	x0, [x16, #0x8]
    9a10:      	cmp	x23, #0x0
    9a14:      	b.gt	0x9a3c <_stogir.stack.validate-inputs+0x1b8>
    9a18:      	str	x21, [sp, #0x90]
    9a1c:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009a1c:  ARM64_RELOC_PAGE21	l_stogir.444
    9a20:      	ldr	x16, [x16]
		0000000000009a20:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    9a24:      	orr	x0, x16, xzr
    9a28:      	mov	x2, #0x1                ; =1
    9a2c:      	mov	x1, #0x1f               ; =31
    9a30:      	b	0x9a00 <_stogir.stack.validate-inputs+0x17c>
    9a34:      	str	x8, [sp, #0x90]
    9a38:      	b	0x98e0 <_stogir.stack.validate-inputs+0x5c>
    9a3c:      	uxtb	w0, w0
    9a40:      	cmp	x0, #0x83
    9a44:      	cset	w1, lt
    9a48:      	uxtb	w16, w1
    9a4c:      	cmp	w16, wzr
    9a50:      	b.eq	0x9a6c <_stogir.stack.validate-inputs+0x1e8>
    9a54:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009a54:  ARM64_RELOC_PAGE21	l_stogir.445
    9a58:      	ldr	x16, [x16]
		0000000000009a58:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    9a5c:      	orr	x2, x16, xzr
    9a60:      	add	x2, x0, x2
    9a64:      	ldrb	w2, [x2]
    9a68:      	b	0x9a70 <_stogir.stack.validate-inputs+0x1ec>
    9a6c:      	movz	x2, #0x0, lsl #48
    9a70:      	uxtb	w2, w2
    9a74:      	and	x2, x2, #0x1
    9a78:      	uxtb	w2, w2
    9a7c:      	cmp	x2, #0x0
    9a80:      	b.eq	0x9eac <_stogir.stack.validate-inputs+0x628>
    9a84:      	uxtb	w16, w1
    9a88:      	cmp	w16, wzr
    9a8c:      	b.eq	0x9aa8 <_stogir.stack.validate-inputs+0x224>
    9a90:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009a90:  ARM64_RELOC_PAGE21	l_stogir.445
    9a94:      	ldr	x16, [x16]
		0000000000009a94:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    9a98:      	orr	x1, x16, xzr
    9a9c:      	add	x0, x0, x1
    9aa0:      	ldrb	w0, [x0]
    9aa4:      	b	0x9aac <_stogir.stack.validate-inputs+0x228>
    9aa8:      	movz	x0, #0x0, lsl #48
    9aac:      	uxtb	w0, w0
    9ab0:      	and	x0, x0, #0x4
    9ab4:      	uxtb	w0, w0
    9ab8:      	cmp	x0, #0x0
    9abc:      	cset	w0, eq
    9ac0:      	uxtb	w16, w0
    9ac4:      	cmp	w16, wzr
    9ac8:      	cset	x0, eq
    9acc:      	cmp	x0, #0x0
    9ad0:      	b.ne	0x9eb4 <_stogir.stack.validate-inputs+0x630>
    9ad4:      	lsr	w24, w24, #0
    9ad8:      	add	x8, sp, #0x40
    9adc:      	mov	x0, x22
    9ae0:      	mov	w1, w24
    9ae4:      	bl	0x9ae4 <_stogir.stack.validate-inputs+0x260>
		0000000000009ae4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    9ae8:      	add	x16, sp, #0x40
    9aec:      	ldr	w0, [x16]
    9af0:      	lsr	x16, x0, #0
    9af4:      	cmp	x16, #0x1
    9af8:      	b.eq	0x9b14 <_stogir.stack.validate-inputs+0x290>
    9afc:      	b.lo	0x9b04 <_stogir.stack.validate-inputs+0x280>
    9b00:      	b	0x9b18 <_stogir.stack.validate-inputs+0x294>
    9b04:      	cmp	x16, #0x0
    9b08:      	b.eq	0x9b10 <_stogir.stack.validate-inputs+0x28c>
    9b0c:      	b	0x9b18 <_stogir.stack.validate-inputs+0x294>
    9b10:      	b	0x9b1c <_stogir.stack.validate-inputs+0x298>
    9b14:      	b	0x9b38 <_stogir.stack.validate-inputs+0x2b4>
    9b18:      	b	0x9dac <_stogir.stack.validate-inputs+0x528>
    9b1c:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009b1c:  ARM64_RELOC_PAGE21	l_stogir.446
    9b20:      	ldr	x16, [x16]
		0000000000009b20:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    9b24:      	orr	x0, x16, xzr
    9b28:      	str	x21, [sp, #0x90]
    9b2c:      	mov	x2, #0x1                ; =1
    9b30:      	mov	x1, #0x18               ; =24
    9b34:      	b	0x9a30 <_stogir.stack.validate-inputs+0x1ac>
    9b38:      	add	x16, sp, #0x40
    9b3c:      	ldr	x0, [x16, #0x8]
    9b40:      	lsr	w1, w0, #0
    9b44:      	ubfx	x1, x1, #8, #8
    9b48:      	cmp	x1, #0x1
    9b4c:      	b.lt	0x9ebc <_stogir.stack.validate-inputs+0x638>
    9b50:      	cmp	x1, #0xb
    9b54:      	b.gt	0x9ec4 <_stogir.stack.validate-inputs+0x640>
    9b58:      	uxtb	w0, w0
    9b5c:      	cmp	x0, #0x48
    9b60:      	b.eq	0x9ecc <_stogir.stack.validate-inputs+0x648>
    9b64:      	sxtw	x0, w24
    9b68:      	cmp	x1, #0x0
    9b6c:      	cset	w23, eq
    9b70:      	cmp	x1, #0x1
    9b74:      	cset	w25, eq
    9b78:      	cmp	x1, #0x2
    9b7c:      	cset	w26, eq
    9b80:      	cmp	x1, #0x7
    9b84:      	cset	w27, eq
    9b88:      	cmp	x1, #0x8
    9b8c:      	cset	w28, eq
    9b90:      	cmp	x1, #0x3
    9b94:      	cset	w2, eq
    9b98:      	cmp	x1, #0x9
    9b9c:      	cset	w3, eq
    9ba0:      	cmp	x1, #0x4
    9ba4:      	cset	w4, eq
    9ba8:      	cmp	x1, #0xa
    9bac:      	cset	w5, eq
    9bb0:      	cmp	x1, #0xd
    9bb4:      	cset	w6, eq
    9bb8:      	cmp	x1, #0x5
    9bbc:      	cset	w7, eq
    9bc0:      	cmp	x1, #0xb
    9bc4:      	cset	w8, eq
    9bc8:      	cmp	x1, #0xc
    9bcc:      	cset	w9, eq
    9bd0:      	cmp	x1, #0x6
    9bd4:      	cset	w1, eq
    9bd8:      	uxtb	w16, w1
    9bdc:      	cmp	w16, wzr
    9be0:      	mov	x16, #0x8               ; =8
    9be4:      	movn	x17, #0x0, lsl #48
    9be8:      	csel	x1, x16, x17, ne
    9bec:      	cmp	x0, #0x0
    9bf0:      	b.ge	0x9ed4 <_stogir.stack.validate-inputs+0x650>
    9bf4:      	uxtb	w16, w19
    9bf8:      	cmp	w16, wzr
    9bfc:      	b.eq	0x9c08 <_stogir.stack.validate-inputs+0x384>
    9c00:      	cmp	x20, #0x10
    9c04:      	b.gt	0x9c0c <_stogir.stack.validate-inputs+0x388>
    9c08:      	mov	x20, #0x10              ; =16
    9c0c:      	lsr	w24, w24, #0
    9c10:      	mov	x0, x22
    9c14:      	mov	w19, w2
    9c18:      	mov	x2, x20
    9c1c:      	mov	w20, w3
    9c20:      	mov	w22, w4
    9c24:      	str	w7, [sp, #0x98]
    9c28:      	str	w8, [sp, #0xa0]
    9c2c:      	add	x8, sp, #0x70
    9c30:      	str	w9, [sp, #0xa8]
    9c34:      	str	x1, [sp, #0xb0]
    9c38:      	mov	w1, w24
    9c3c:      	mov	w24, w5
    9c40:      	str	x21, [sp, #0x90]
    9c44:      	mov	w21, w6
    9c48:      	bl	0x9c48 <_stogir.stack.validate-inputs+0x3c4>
		0000000000009c48:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    9c4c:      	add	x16, sp, #0x70
    9c50:      	ldr	w0, [x16]
    9c54:      	lsr	x16, x0, #0
    9c58:      	cmp	x16, #0x1
    9c5c:      	b.eq	0x9c78 <_stogir.stack.validate-inputs+0x3f4>
    9c60:      	b.lo	0x9c68 <_stogir.stack.validate-inputs+0x3e4>
    9c64:      	b	0x9c7c <_stogir.stack.validate-inputs+0x3f8>
    9c68:      	cmp	x16, #0x0
    9c6c:      	b.eq	0x9c74 <_stogir.stack.validate-inputs+0x3f0>
    9c70:      	b	0x9c7c <_stogir.stack.validate-inputs+0x3f8>
    9c74:      	b	0x9db4 <_stogir.stack.validate-inputs+0x530>
    9c78:      	b	0x9c80 <_stogir.stack.validate-inputs+0x3fc>
    9c7c:      	b	0x9e88 <_stogir.stack.validate-inputs+0x604>
    9c80:      	add	x16, sp, #0x70
    9c84:      	orr	x0, x16, xzr
    9c88:      	add	x1, x0, #0x8
    9c8c:      	add	x16, sp, #0x70
    9c90:      	ldr	x0, [x16, #0x8]
    9c94:      	ldr	x1, [x1, #0x8]
    9c98:      	mov	x2, #0x1                ; =1
    9c9c:      	b	0x9d10 <_stogir.stack.validate-inputs+0x48c>
    9ca0:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009ca0:  ARM64_RELOC_PAGE21	l_stogir.447
    9ca4:      	ldr	x16, [x16]
		0000000000009ca4:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    9ca8:      	orr	x0, x16, xzr
    9cac:      	mov	x2, #0x1                ; =1
    9cb0:      	mov	x1, #0x29               ; =41
    9cb4:      	b	0x9b34 <_stogir.stack.validate-inputs+0x2b0>
    9cb8:      	brk	#0
    9cbc:      	b	0x9cb8 <_stogir.stack.validate-inputs+0x434>
    9cc0:      	mov	x3, #0x1                ; =1
    9cc4:      	lsr	w3, w3, #0
    9cc8:      	sxtw	x3, w3
    9ccc:      	and	x0, x3, #0xffffffff
    9cd0:      	movz	x2, #0x0, lsl #48
    9cd4:      	movz	x1, #0x0, lsl #48
    9cd8:      	b	0x9cb4 <_stogir.stack.validate-inputs+0x430>
    9cdc:      	uxtb	w16, w23
    9ce0:      	cmp	w16, wzr
    9ce4:      	b.eq	0x9d14 <_stogir.stack.validate-inputs+0x490>
    9ce8:      	movz	x3, #0x0, lsl #48
    9cec:      	b	0x9cc4 <_stogir.stack.validate-inputs+0x440>
    9cf0:      	mov	x16, #0x1               ; =1
    9cf4:      	str	x16, [sp, #0xb0]
    9cf8:      	ldr	x3, [sp, #0xb0]
    9cfc:      	lsr	w3, w3, #0
    9d00:      	sxtw	x3, w3
    9d04:      	and	x0, x3, #0xffffffff
    9d08:      	movz	x2, #0x0, lsl #48
    9d0c:      	movz	x1, #0x0, lsl #48
    9d10:      	b	0x9cd8 <_stogir.stack.validate-inputs+0x454>
    9d14:      	uxtb	w16, w25
    9d18:      	cmp	w16, wzr
    9d1c:      	b.ne	0x9cc0 <_stogir.stack.validate-inputs+0x43c>
    9d20:      	uxtb	w16, w26
    9d24:      	cmp	w16, wzr
    9d28:      	b.ne	0x9cc0 <_stogir.stack.validate-inputs+0x43c>
    9d2c:      	uxtb	w16, w27
    9d30:      	cmp	w16, wzr
    9d34:      	b.ne	0x9cc0 <_stogir.stack.validate-inputs+0x43c>
    9d38:      	uxtb	w16, w28
    9d3c:      	cmp	w16, wzr
    9d40:      	b.ne	0x9cc0 <_stogir.stack.validate-inputs+0x43c>
    9d44:      	uxtb	w16, w19
    9d48:      	cmp	w16, wzr
    9d4c:      	b.ne	0x9e74 <_stogir.stack.validate-inputs+0x5f0>
    9d50:      	uxtb	w16, w20
    9d54:      	cmp	w16, wzr
    9d58:      	b.ne	0x9e74 <_stogir.stack.validate-inputs+0x5f0>
    9d5c:      	uxtb	w16, w22
    9d60:      	cmp	w16, wzr
    9d64:      	b.ne	0x9e90 <_stogir.stack.validate-inputs+0x60c>
    9d68:      	uxtb	w16, w24
    9d6c:      	cmp	w16, wzr
    9d70:      	b.ne	0x9e90 <_stogir.stack.validate-inputs+0x60c>
    9d74:      	uxtb	w16, w21
    9d78:      	cmp	w16, wzr
    9d7c:      	b.ne	0x9e90 <_stogir.stack.validate-inputs+0x60c>
    9d80:      	uxtb	w16, w0
    9d84:      	cmp	w16, wzr
    9d88:      	b.ne	0x9da4 <_stogir.stack.validate-inputs+0x520>
    9d8c:      	uxtb	w16, w1
    9d90:      	cmp	w16, wzr
    9d94:      	b.ne	0x9da4 <_stogir.stack.validate-inputs+0x520>
    9d98:      	uxtb	w16, w2
    9d9c:      	cmp	w16, wzr
    9da0:      	b.eq	0x9da8 <_stogir.stack.validate-inputs+0x524>
    9da4:      	mov	x3, #0x8                ; =8
    9da8:      	b	0x9e94 <_stogir.stack.validate-inputs+0x610>
    9dac:      	brk	#0
    9db0:      	b	0x9dac <_stogir.stack.validate-inputs+0x528>
    9db4:      	uxtb	w16, w23
    9db8:      	cmp	w16, wzr
    9dbc:      	b.eq	0x9dcc <_stogir.stack.validate-inputs+0x548>
    9dc0:      	movz	x16, #0x0, lsl #48
    9dc4:      	str	x16, [sp, #0xb0]
    9dc8:      	b	0x9cf8 <_stogir.stack.validate-inputs+0x474>
    9dcc:      	uxtb	w16, w25
    9dd0:      	cmp	w16, wzr
    9dd4:      	b.ne	0x9cf0 <_stogir.stack.validate-inputs+0x46c>
    9dd8:      	uxtb	w16, w26
    9ddc:      	cmp	w16, wzr
    9de0:      	b.ne	0x9cf0 <_stogir.stack.validate-inputs+0x46c>
    9de4:      	uxtb	w16, w27
    9de8:      	cmp	w16, wzr
    9dec:      	b.ne	0x9cf0 <_stogir.stack.validate-inputs+0x46c>
    9df0:      	uxtb	w16, w28
    9df4:      	cmp	w16, wzr
    9df8:      	b.ne	0x9cf0 <_stogir.stack.validate-inputs+0x46c>
    9dfc:      	uxtb	w16, w19
    9e00:      	cmp	w16, wzr
    9e04:      	b.ne	0x9e7c <_stogir.stack.validate-inputs+0x5f8>
    9e08:      	uxtb	w16, w20
    9e0c:      	cmp	w16, wzr
    9e10:      	b.ne	0x9e7c <_stogir.stack.validate-inputs+0x5f8>
    9e14:      	uxtb	w16, w22
    9e18:      	cmp	w16, wzr
    9e1c:      	b.ne	0x9e98 <_stogir.stack.validate-inputs+0x614>
    9e20:      	uxtb	w16, w24
    9e24:      	cmp	w16, wzr
    9e28:      	b.ne	0x9e98 <_stogir.stack.validate-inputs+0x614>
    9e2c:      	uxtb	w16, w21
    9e30:      	cmp	w16, wzr
    9e34:      	b.ne	0x9e98 <_stogir.stack.validate-inputs+0x614>
    9e38:      	ldr	w0, [sp, #0x98]
    9e3c:      	uxtb	w16, w0
    9e40:      	cmp	w16, wzr
    9e44:      	b.ne	0x9e68 <_stogir.stack.validate-inputs+0x5e4>
    9e48:      	ldr	w1, [sp, #0xa0]
    9e4c:      	uxtb	w16, w1
    9e50:      	cmp	w16, wzr
    9e54:      	b.ne	0x9e68 <_stogir.stack.validate-inputs+0x5e4>
    9e58:      	ldr	w2, [sp, #0xa8]
    9e5c:      	uxtb	w16, w2
    9e60:      	cmp	w16, wzr
    9e64:      	b.eq	0x9e70 <_stogir.stack.validate-inputs+0x5ec>
    9e68:      	mov	x16, #0x8               ; =8
    9e6c:      	str	x16, [sp, #0xb0]
    9e70:      	b	0x9ea0 <_stogir.stack.validate-inputs+0x61c>
    9e74:      	mov	x3, #0x2                ; =2
    9e78:      	b	0x9cc4 <_stogir.stack.validate-inputs+0x440>
    9e7c:      	mov	x16, #0x2               ; =2
    9e80:      	str	x16, [sp, #0xb0]
    9e84:      	b	0x9cf8 <_stogir.stack.validate-inputs+0x474>
    9e88:      	brk	#0
    9e8c:      	b	0x9e88 <_stogir.stack.validate-inputs+0x604>
    9e90:      	mov	x3, #0x4                ; =4
    9e94:      	b	0x9e78 <_stogir.stack.validate-inputs+0x5f4>
    9e98:      	mov	x16, #0x4               ; =4
    9e9c:      	str	x16, [sp, #0xb0]
    9ea0:      	b	0x9e84 <_stogir.stack.validate-inputs+0x600>
    9ea4:      	str	x8, [sp, #0x90]
    9ea8:      	b	0x98e0 <_stogir.stack.validate-inputs+0x5c>
    9eac:      	str	x21, [sp, #0x90]
    9eb0:      	b	0x9a1c <_stogir.stack.validate-inputs+0x198>
    9eb4:      	str	x21, [sp, #0x90]
    9eb8:      	b	0x9a1c <_stogir.stack.validate-inputs+0x198>
    9ebc:      	str	x21, [sp, #0x90]
    9ec0:      	b	0x9ca0 <_stogir.stack.validate-inputs+0x41c>
    9ec4:      	str	x21, [sp, #0x90]
    9ec8:      	b	0x9ca0 <_stogir.stack.validate-inputs+0x41c>
    9ecc:      	str	x21, [sp, #0x90]
    9ed0:      	b	0x9ca0 <_stogir.stack.validate-inputs+0x41c>
    9ed4:      	str	x21, [sp, #0x90]
    9ed8:      	mov	w19, w2
    9edc:      	mov	w20, w3
    9ee0:      	mov	x3, x1
    9ee4:      	mov	w22, w4
    9ee8:      	mov	w24, w5
    9eec:      	mov	w21, w6
    9ef0:      	mov	w0, w7
    9ef4:      	mov	w1, w8
    9ef8:      	mov	w2, w9
    9efc:      	b	0x9cdc <_stogir.stack.validate-inputs+0x458>

0000000000009f00 <_stogir.locals.shape>:
    9f00:      	sub	sp, sp, #0x40
    9f04:      	str	x29, [sp]
    9f08:      	str	x30, [sp, #0x8]
    9f0c:      	mov	x29, sp
    9f10:      	str	x19, [sp, #0x20]
    9f14:      	str	x20, [sp, #0x28]
    9f18:      	str	x21, [sp, #0x30]
    9f1c:      	str	x22, [sp, #0x38]
    9f20:      	sxtw	x19, w1
    9f24:      	lsl	x20, x19, #2
    9f28:      	cmp	x19, #0x0
    9f2c:      	cset	w1, gt
    9f30:      	movz	x16, #0x0, lsl #48
    9f34:      	sub	x3, x16, x19
    9f38:      	sub	x4, x3, #0x1
    9f3c:      	uxtb	w16, w1
    9f40:      	cmp	w16, wzr
    9f44:      	b.eq	0x9f84 <_stogir.locals.shape+0x84>
    9f48:      	ldr	x3, [x0, #0x8]
    9f4c:      	cmp	x19, x3
    9f50:      	b.ge	0x9fec <_stogir.locals.shape+0xec>
    9f54:      	add	x3, x0, #0x78
    9f58:      	ldr	x3, [x3, #0x8]
    9f5c:      	cmp	x19, x3
    9f60:      	b.ge	0xa18c <_stogir.locals.shape+0x28c>
    9f64:      	ldr	x3, [x0, #0x78]
    9f68:      	add	x3, x20, x3
    9f6c:      	ldr	w3, [x3]
    9f70:      	sxtw	x3, w3
    9f74:      	cmp	x3, #0x0
    9f78:      	cset	w3, ge
    9f7c:      	ubfx	x3, x3, #0, #8
    9f80:      	b	0xa190 <_stogir.locals.shape+0x290>
    9f84:      	cmp	x19, #0x0
    9f88:      	b.ge	0x9ff4 <_stogir.locals.shape+0xf4>
    9f8c:      	add	x5, x0, #0x28
    9f90:      	add	x6, x0, #0x50
    9f94:      	ldr	x5, [x5, #0x8]
    9f98:      	ldr	x6, [x6, #0x8]
    9f9c:      	cmp	x5, x6
    9fa0:      	b.ne	0x9fcc <_stogir.locals.shape+0xcc>
    9fa4:      	cmp	x3, x5
    9fa8:      	b.gt	0xa290 <_stogir.locals.shape+0x390>
    9fac:      	ldr	x3, [x0, #0x50]
    9fb0:      	add	x3, x3, x4, lsl #2
    9fb4:      	ldr	w3, [x3]
    9fb8:      	sxtw	x3, w3
    9fbc:      	cmp	x3, #0x0
    9fc0:      	cset	w3, gt
    9fc4:      	ubfx	x3, x3, #0, #8
    9fc8:      	b	0xa294 <_stogir.locals.shape+0x394>
    9fcc:      	movz	x3, #0x0, lsl #48
    9fd0:      	b	0x9ff8 <_stogir.locals.shape+0xf8>
    9fd4:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x428>
		0000000000009fd4:  ARM64_RELOC_PAGE21	l_stogir.448
    9fd8:      	ldr	x16, [x16]
		0000000000009fd8:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    9fdc:      	orr	x0, x16, xzr
    9fe0:      	mov	x2, #0x1                ; =1
    9fe4:      	mov	x1, #0x1c               ; =28
    9fe8:      	b	0xa08c <_stogir.locals.shape+0x18c>
    9fec:      	movz	x3, #0x0, lsl #48
    9ff0:      	b	0x9ff8 <_stogir.locals.shape+0xf8>
    9ff4:      	movz	x3, #0x0, lsl #48
    9ff8:      	cmp	x3, #0x0
    9ffc:      	b.eq	0xa038 <_stogir.locals.shape+0x138>
    a000:      	uxtb	w16, w1
    a004:      	cmp	w16, wzr
    a008:      	b.eq	0xa020 <_stogir.locals.shape+0x120>
    a00c:      	ldr	x1, [x0]
    a010:      	add	x1, x1, x19, lsl #4
    a014:      	ldr	x3, [x1]
    a018:      	ldr	x1, [x1, #0x8]
    a01c:      	b	0xa030 <_stogir.locals.shape+0x130>
    a020:      	ldr	x1, [x0, #0x28]
    a024:      	add	x1, x1, x4, lsl #4
    a028:      	ldr	x3, [x1]
    a02c:      	ldr	x1, [x1, #0x8]
    a030:      	mov	x4, #0x1                ; =1
    a034:      	b	0xa044 <_stogir.locals.shape+0x144>
    a038:      	movz	x4, #0x0, lsl #48
    a03c:      	movz	x3, #0x0, lsl #48
    a040:      	movz	x1, #0x0, lsl #48
    a044:      	lsr	w4, w4, #0
    a048:      	lsr	x16, x4, #0
    a04c:      	cmp	x16, #0x1
    a050:      	b.eq	0xa06c <_stogir.locals.shape+0x16c>
    a054:      	b.lo	0xa05c <_stogir.locals.shape+0x15c>
    a058:      	b	0xa070 <_stogir.locals.shape+0x170>
    a05c:      	cmp	x16, #0x0
    a060:      	b.eq	0xa068 <_stogir.locals.shape+0x168>
    a064:      	b	0xa070 <_stogir.locals.shape+0x170>
    a068:      	b	0xa074 <_stogir.locals.shape+0x174>
    a06c:      	b	0xa0b8 <_stogir.locals.shape+0x1b8>
    a070:      	b	0xa2a0 <_stogir.locals.shape+0x3a0>
    a074:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000a074:  ARM64_RELOC_PAGE21	l_stogir.449
    a078:      	ldr	x16, [x16]
		000000000000a078:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    a07c:      	orr	x0, x16, xzr
    a080:      	mov	x21, x8
    a084:      	mov	x2, #0x1                ; =1
    a088:      	mov	x1, #0x16               ; =22
    a08c:      	str	x2, [x21]
    a090:      	str	x0, [x21, #0x8]
    a094:      	str	x1, [x21, #0x10]
    a098:      	ldr	x19, [sp, #0x20]
    a09c:      	ldr	x20, [sp, #0x28]
    a0a0:      	ldr	x21, [sp, #0x30]
    a0a4:      	ldr	x22, [sp, #0x38]
    a0a8:      	ldr	x29, [sp]
    a0ac:      	ldr	x30, [sp, #0x8]
    a0b0:      	add	sp, sp, #0x40
    a0b4:      	ret
    a0b8:      	lsr	w2, w2, #0
    a0bc:      	lsr	w4, w3, #0
    a0c0:      	add	x16, sp, #0x10
    a0c4:      	str	x3, [x16]
    a0c8:      	add	x16, sp, #0x10
    a0cc:      	str	x1, [x16, #0x8]
    a0d0:      	ubfx	x1, x4, #8, #8
    a0d4:      	lsr	w1, w1, #0
    a0d8:      	mov	x21, x8
    a0dc:      	mov	x22, x0
    a0e0:      	mov	w0, w1
    a0e4:      	mov	w1, w2
    a0e8:      	bl	0xa0e8 <_stogir.locals.shape+0x1e8>
		000000000000a0e8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a0ec:      	lsr	w0, w0, #0
    a0f0:      	add	x16, sp, #0x10
    a0f4:      	ldr	w1, [x16, #0xc]
    a0f8:      	sxtw	x0, w0
    a0fc:      	sxtw	x1, w1
    a100:      	cmp	x1, #0x0
    a104:      	b.ne	0xa10c <_stogir.locals.shape+0x20c>
    a108:      	mov	x1, x0
    a10c:      	add	x16, sp, #0x10
    a110:      	ldr	w2, [x16, #0x8]
    a114:      	sxtw	x2, w2
    a118:      	cmp	x2, #0x0
    a11c:      	cset	w3, eq
    a120:      	ubfx	x3, x3, #0, #8
    a124:      	cmp	x2, #0x0
    a128:      	b.le	0xa1cc <_stogir.locals.shape+0x2cc>
    a12c:      	add	x4, x22, #0x110
    a130:      	add	x5, x4, #0x28
    a134:      	ldr	x5, [x5, #0x8]
    a138:      	cmp	x2, x5
    a13c:      	b.gt	0xa194 <_stogir.locals.shape+0x294>
    a140:      	sub	x2, x2, #0x1
    a144:      	mov	x17, #0x18              ; =24
    a148:      	mul	x2, x2, x17
    a14c:      	ldr	x5, [x4, #0x28]
    a150:      	add	x2, x2, x5
    a154:      	ldr	x5, [x2]
    a158:      	ldr	x2, [x2, #0x8]
    a15c:      	ldr	x4, [x4, #0x8]
    a160:      	cmp	x5, #0x0
    a164:      	b.lt	0xa298 <_stogir.locals.shape+0x398>
    a168:      	cmp	x5, x4
    a16c:      	b.gt	0xa298 <_stogir.locals.shape+0x398>
    a170:      	cmp	x2, #0x0
    a174:      	b.lt	0xa298 <_stogir.locals.shape+0x398>
    a178:      	sub	x4, x4, x5
    a17c:      	cmp	x2, x4
    a180:      	b.gt	0xa298 <_stogir.locals.shape+0x398>
    a184:      	mov	x2, #0x1                ; =1
    a188:      	b	0xa29c <_stogir.locals.shape+0x39c>
    a18c:      	movz	x3, #0x0, lsl #48
    a190:      	b	0x9ff0 <_stogir.locals.shape+0xf0>
    a194:      	movz	x2, #0x0, lsl #48
    a198:      	lsr	w2, w2, #0
    a19c:      	lsr	x16, x2, #0
    a1a0:      	cmp	x16, #0x1
    a1a4:      	b.eq	0xa1c0 <_stogir.locals.shape+0x2c0>
    a1a8:      	b.lo	0xa1b0 <_stogir.locals.shape+0x2b0>
    a1ac:      	b	0xa1c4 <_stogir.locals.shape+0x2c4>
    a1b0:      	cmp	x16, #0x0
    a1b4:      	b.eq	0xa1bc <_stogir.locals.shape+0x2bc>
    a1b8:      	b	0xa1c4 <_stogir.locals.shape+0x2c4>
    a1bc:      	b	0xa1cc <_stogir.locals.shape+0x2cc>
    a1c0:      	b	0xa1c8 <_stogir.locals.shape+0x2c8>
    a1c4:      	b	0xa2a8 <_stogir.locals.shape+0x3a8>
    a1c8:      	mov	x3, #0x1                ; =1
    a1cc:      	cmp	x19, #0x0
    a1d0:      	b.le	0x9fd4 <_stogir.locals.shape+0xd4>
    a1d4:      	add	x16, sp, #0x10
    a1d8:      	ldr	w2, [x16]
    a1dc:      	uxtb	w2, w2
    a1e0:      	cmp	x2, #0x48
    a1e4:      	b.ne	0x9fd4 <_stogir.locals.shape+0xd4>
    a1e8:      	ldr	x2, [x22, #0x78]
    a1ec:      	add	x2, x20, x2
    a1f0:      	ldr	w2, [x2]
    a1f4:      	sxtw	x2, w2
    a1f8:      	cmp	x2, #0x3
    a1fc:      	b.ne	0x9fd4 <_stogir.locals.shape+0xd4>
    a200:      	cmp	x0, #0x0
    a204:      	b.le	0x9fd4 <_stogir.locals.shape+0xd4>
    a208:      	cmp	x3, #0x0
    a20c:      	b.eq	0x9fd4 <_stogir.locals.shape+0xd4>
    a210:      	cmp	x1, #0x0
    a214:      	b.le	0x9fd4 <_stogir.locals.shape+0xd4>
    a218:      	sub	x2, x1, #0x1
    a21c:      	and	x2, x2, x1
    a220:      	cmp	x2, #0x0
    a224:      	b.ne	0x9fd4 <_stogir.locals.shape+0xd4>
    a228:      	add	x16, sp, #0x10
    a22c:      	ldr	w2, [x16, #0x4]
    a230:      	sxtw	x2, w2
    a234:      	cmp	x2, #0x0
    a238:      	cset	w3, gt
    a23c:      	movz	x16, #0x0, lsl #48
    a240:      	sub	x4, x16, x2
    a244:      	sub	x5, x4, #0x1
    a248:      	uxtb	w16, w3
    a24c:      	cmp	w16, wzr
    a250:      	b.eq	0xa2c8 <_stogir.locals.shape+0x3c8>
    a254:      	ldr	x4, [x22, #0x8]
    a258:      	cmp	x2, x4
    a25c:      	b.ge	0xa310 <_stogir.locals.shape+0x410>
    a260:      	add	x4, x22, #0x78
    a264:      	ldr	x4, [x4, #0x8]
    a268:      	cmp	x2, x4
    a26c:      	b.ge	0xa3e4 <_stogir.locals.shape+0x4e4>
    a270:      	ldr	x4, [x22, #0x78]
    a274:      	add	x4, x4, x2, lsl #2
    a278:      	ldr	w4, [x4]
    a27c:      	sxtw	x4, w4
    a280:      	cmp	x4, #0x0
    a284:      	cset	w4, ge
    a288:      	ubfx	x4, x4, #0, #8
    a28c:      	b	0xa3e8 <_stogir.locals.shape+0x4e8>
    a290:      	movz	x3, #0x0, lsl #48
    a294:      	b	0x9fd0 <_stogir.locals.shape+0xd0>
    a298:      	movz	x2, #0x0, lsl #48
    a29c:      	b	0xa198 <_stogir.locals.shape+0x298>
    a2a0:      	brk	#0
    a2a4:      	b	0xa2a0 <_stogir.locals.shape+0x3a0>
    a2a8:      	brk	#0
    a2ac:      	b	0xa2a8 <_stogir.locals.shape+0x3a8>
    a2b0:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000a2b0:  ARM64_RELOC_PAGE21	l_stogir.450
    a2b4:      	ldr	x16, [x16]
		000000000000a2b4:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    a2b8:      	orr	x0, x16, xzr
    a2bc:      	mov	x2, #0x1                ; =1
    a2c0:      	mov	x1, #0x2c               ; =44
    a2c4:      	b	0x9fe8 <_stogir.locals.shape+0xe8>
    a2c8:      	cmp	x2, #0x0
    a2cc:      	b.ge	0xa318 <_stogir.locals.shape+0x418>
    a2d0:      	add	x6, x22, #0x28
    a2d4:      	add	x7, x22, #0x50
    a2d8:      	ldr	x6, [x6, #0x8]
    a2dc:      	ldr	x7, [x7, #0x8]
    a2e0:      	cmp	x6, x7
    a2e4:      	b.ne	0xa3dc <_stogir.locals.shape+0x4dc>
    a2e8:      	cmp	x4, x6
    a2ec:      	b.gt	0xa3ec <_stogir.locals.shape+0x4ec>
    a2f0:      	ldr	x4, [x22, #0x50]
    a2f4:      	add	x4, x4, x5, lsl #2
    a2f8:      	ldr	w4, [x4]
    a2fc:      	sxtw	x4, w4
    a300:      	cmp	x4, #0x0
    a304:      	cset	w4, gt
    a308:      	ubfx	x4, x4, #0, #8
    a30c:      	b	0xa3f0 <_stogir.locals.shape+0x4f0>
    a310:      	movz	x4, #0x0, lsl #48
    a314:      	b	0xa31c <_stogir.locals.shape+0x41c>
    a318:      	movz	x4, #0x0, lsl #48
    a31c:      	cmp	x4, #0x0
    a320:      	b.eq	0xa354 <_stogir.locals.shape+0x454>
    a324:      	uxtb	w16, w3
    a328:      	cmp	w16, wzr
    a32c:      	b.eq	0xa340 <_stogir.locals.shape+0x440>
    a330:      	ldr	x3, [x22]
    a334:      	add	x2, x3, x2, lsl #4
    a338:      	ldr	x2, [x2]
    a33c:      	b	0xa34c <_stogir.locals.shape+0x44c>
    a340:      	ldr	x2, [x22, #0x28]
    a344:      	add	x2, x2, x5, lsl #4
    a348:      	ldr	x2, [x2]
    a34c:      	mov	x3, #0x1                ; =1
    a350:      	b	0xa35c <_stogir.locals.shape+0x45c>
    a354:      	movz	x3, #0x0, lsl #48
    a358:      	movz	x2, #0x0, lsl #48
    a35c:      	lsr	w3, w3, #0
    a360:      	lsr	x16, x3, #0
    a364:      	cmp	x16, #0x1
    a368:      	b.eq	0xa384 <_stogir.locals.shape+0x484>
    a36c:      	b.lo	0xa374 <_stogir.locals.shape+0x474>
    a370:      	b	0xa388 <_stogir.locals.shape+0x488>
    a374:      	cmp	x16, #0x0
    a378:      	b.eq	0xa380 <_stogir.locals.shape+0x480>
    a37c:      	b	0xa388 <_stogir.locals.shape+0x488>
    a380:      	b	0xa38c <_stogir.locals.shape+0x48c>
    a384:      	b	0xa3a4 <_stogir.locals.shape+0x4a4>
    a388:      	b	0xa428 <_stogir.locals.shape+0x528>
    a38c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000a38c:  ARM64_RELOC_PAGE21	l_stogir.451
    a390:      	ldr	x16, [x16]
		000000000000a390:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    a394:      	orr	x0, x16, xzr
    a398:      	mov	x2, #0x1                ; =1
    a39c:      	mov	x1, #0x1d               ; =29
    a3a0:      	b	0xa2c4 <_stogir.locals.shape+0x3c4>
    a3a4:      	add	x16, sp, #0x10
    a3a8:      	ldr	w3, [x16, #0x4]
    a3ac:      	sxtw	x3, w3
    a3b0:      	cmp	x3, #0x0
    a3b4:      	b.le	0xa2b0 <_stogir.locals.shape+0x3b0>
    a3b8:      	uxtb	w2, w2
    a3bc:      	cmp	x2, #0x83
    a3c0:      	b.ge	0xa3f4 <_stogir.locals.shape+0x4f4>
    a3c4:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000a3c4:  ARM64_RELOC_PAGE21	l_stogir.452
    a3c8:      	ldr	x16, [x16]
		000000000000a3c8:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    a3cc:      	orr	x3, x16, xzr
    a3d0:      	add	x2, x2, x3
    a3d4:      	ldrb	w2, [x2]
    a3d8:      	b	0xa3f8 <_stogir.locals.shape+0x4f8>
    a3dc:      	movz	x4, #0x0, lsl #48
    a3e0:      	b	0xa31c <_stogir.locals.shape+0x41c>
    a3e4:      	movz	x4, #0x0, lsl #48
    a3e8:      	b	0xa314 <_stogir.locals.shape+0x414>
    a3ec:      	movz	x4, #0x0, lsl #48
    a3f0:      	b	0xa3e0 <_stogir.locals.shape+0x4e0>
    a3f4:      	movz	x2, #0x0, lsl #48
    a3f8:      	uxtb	w2, w2
    a3fc:      	and	x2, x2, #0x2
    a400:      	uxtb	w2, w2
    a404:      	cmp	x2, #0x0
    a408:      	cset	w2, eq
    a40c:      	uxtb	w16, w2
    a410:      	cmp	w16, wzr
    a414:      	cset	x2, eq
    a418:      	cmp	x2, #0x0
    a41c:      	b.eq	0xa2b0 <_stogir.locals.shape+0x3b0>
    a420:      	movz	x2, #0x0, lsl #48
    a424:      	b	0xa2c4 <_stogir.locals.shape+0x3c4>
    a428:      	brk	#0
    a42c:      	b	0xa428 <_stogir.locals.shape+0x528>

000000000000a430 <_stogir.conversion.policy>:
    a430:      	sub	sp, sp, #0x70
    a434:      	str	x29, [sp]
    a438:      	str	x30, [sp, #0x8]
    a43c:      	mov	x29, sp
    a440:      	str	x19, [sp, #0x20]
    a444:      	str	x20, [sp, #0x28]
    a448:      	str	x21, [sp, #0x30]
    a44c:      	str	x22, [sp, #0x38]
    a450:      	str	x23, [sp, #0x40]
    a454:      	str	x24, [sp, #0x48]
    a458:      	str	x25, [sp, #0x50]
    a45c:      	str	x26, [sp, #0x58]
    a460:      	str	x27, [sp, #0x60]
    a464:      	str	x28, [sp, #0x68]
    a468:      	sxtw	x19, w0
    a46c:      	sxtw	x20, w1
    a470:      	sxtw	x21, w2
    a474:      	cmp	x19, #0x24
    a478:      	b.ne	0xa4b8 <_stogir.conversion.policy+0x88>
    a47c:      	cmp	x20, #0xf
    a480:      	b.le	0xa6d4 <_stogir.conversion.policy+0x2a4>
    a484:      	cmp	x20, #0x80
    a488:      	b.ge	0xa6d4 <_stogir.conversion.policy+0x2a4>
    a48c:      	and	x0, x20, #0xf
    a490:      	lsr	w0, w0, #0
    a494:      	sxtw	x0, w0
    a498:      	cmp	x0, #0x1
    a49c:      	b.lt	0xa6d4 <_stogir.conversion.policy+0x2a4>
    a4a0:      	cmp	x0, #0xd
    a4a4:      	b.gt	0xa6d4 <_stogir.conversion.policy+0x2a4>
    a4a8:      	mov	x22, #0x1               ; =1
    a4ac:      	b	0xa4b4 <_stogir.conversion.policy+0x84>
    a4b0:      	movz	x22, #0x0, lsl #48
    a4b4:      	b	0xa4bc <_stogir.conversion.policy+0x8c>
    a4b8:      	movz	x22, #0x0, lsl #48
    a4bc:      	sxtw	x23, w3
    a4c0:      	cmp	x20, #0xd
    a4c4:      	cset	w24, eq
    a4c8:      	cmp	x20, #0xc
    a4cc:      	cset	w25, eq
    a4d0:      	cmp	x23, #0x4
    a4d4:      	cset	w26, eq
    a4d8:      	cmp	x23, #0x8
    a4dc:      	cset	w27, eq
    a4e0:      	cmp	x22, #0x0
    a4e4:      	b.eq	0xa99c <_stogir.conversion.policy+0x56c>
    a4e8:      	lsr	w1, w1, #0
    a4ec:      	lsr	w3, w3, #0
    a4f0:      	mov	w0, w1
    a4f4:      	mov	w1, w3
    a4f8:      	str	x8, [sp, #0x10]
    a4fc:      	mov	w28, w2
    a500:      	str	x19, [sp, #0x18]
    a504:      	mov	w19, w3
    a508:      	bl	0xa508 <_stogir.conversion.policy+0xd8>
		000000000000a508:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a50c:      	lsr	w0, w0, #0
    a510:      	sxtw	x0, w0
    a514:      	b	0xa524 <_stogir.conversion.policy+0xf4>
    a518:      	mov	x0, #0x1                ; =1
    a51c:      	lsr	w0, w0, #0
    a520:      	sxtw	x0, w0
    a524:      	cmp	x21, #0xd
    a528:      	cset	w1, eq
    a52c:      	cmp	x21, #0xc
    a530:      	cset	w2, eq
    a534:      	cmp	x22, #0x0
    a538:      	b.eq	0xa9b0 <_stogir.conversion.policy+0x580>
    a53c:      	lsr	w28, w28, #0
    a540:      	lsr	w19, w19, #0
    a544:      	mov	w22, w1
    a548:      	mov	w1, w19
    a54c:      	mov	x19, x0
    a550:      	mov	w0, w28
    a554:      	mov	w28, w2
    a558:      	bl	0xa558 <_stogir.conversion.policy+0x128>
		000000000000a558:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a55c:      	lsr	w0, w0, #0
    a560:      	sxtw	x0, w0
    a564:      	b	0xa574 <_stogir.conversion.policy+0x144>
    a568:      	mov	x23, #0x1               ; =1
    a56c:      	lsr	w23, w23, #0
    a570:      	sxtw	x0, w23
    a574:      	ldr	x1, [sp, #0x18]
    a578:      	cmp	x1, #0x21
    a57c:      	b.lt	0xa658 <_stogir.conversion.policy+0x228>
    a580:      	cmp	x1, #0x27
    a584:      	b.gt	0xa658 <_stogir.conversion.policy+0x228>
    a588:      	lsl	x2, x19, #3
    a58c:      	lsr	w2, w2, #0
    a590:      	sxtw	x2, w2
    a594:      	cmp	x2, #0x0
    a598:      	b.le	0xa658 <_stogir.conversion.policy+0x228>
    a59c:      	lsl	x0, x0, #3
    a5a0:      	lsr	w0, w0, #0
    a5a4:      	sxtw	x0, w0
    a5a8:      	cmp	x0, #0x0
    a5ac:      	b.le	0xa658 <_stogir.conversion.policy+0x228>
    a5b0:      	cmp	x1, #0x26
    a5b4:      	cset	w3, eq
    a5b8:      	cmp	x20, #0x1
    a5bc:      	cset	w4, ge
    a5c0:      	cmp	x20, #0xb
    a5c4:      	cset	w5, le
    a5c8:      	cmp	x21, #0x1
    a5cc:      	cset	w6, ge
    a5d0:      	cmp	x21, #0xb
    a5d4:      	cset	w7, le
    a5d8:      	cmp	x1, #0x25
    a5dc:      	b.lt	0xa858 <_stogir.conversion.policy+0x428>
    a5e0:      	ubfx	x8, x22, #0, #8
    a5e4:      	cmp	x1, #0x25
    a5e8:      	b.ne	0xa8c8 <_stogir.conversion.policy+0x498>
    a5ec:      	uxtb	w16, w4
    a5f0:      	cmp	w16, wzr
    a5f4:      	b.eq	0xa8c0 <_stogir.conversion.policy+0x490>
    a5f8:      	uxtb	w16, w5
    a5fc:      	cmp	w16, wzr
    a600:      	b.eq	0xa8c0 <_stogir.conversion.policy+0x490>
    a604:      	uxtb	w16, w28
    a608:      	cmp	w16, wzr
    a60c:      	b.eq	0xa614 <_stogir.conversion.policy+0x1e4>
    a610:      	mov	x8, #0x1                ; =1
    a614:      	b	0xa8c4 <_stogir.conversion.policy+0x494>
    a618:      	uxtb	w16, w26
    a61c:      	cmp	w16, wzr
    a620:      	b.ne	0xa6b4 <_stogir.conversion.policy+0x284>
    a624:      	uxtb	w16, w27
    a628:      	cmp	w16, wzr
    a62c:      	b.ne	0xa6b4 <_stogir.conversion.policy+0x284>
    a630:      	movn	x23, #0x0, lsl #48
    a634:      	b	0xa56c <_stogir.conversion.policy+0x13c>
    a638:      	uxtb	w16, w26
    a63c:      	cmp	w16, wzr
    a640:      	b.ne	0xa6c4 <_stogir.conversion.policy+0x294>
    a644:      	uxtb	w16, w27
    a648:      	cmp	w16, wzr
    a64c:      	b.ne	0xa6c4 <_stogir.conversion.policy+0x294>
    a650:      	movn	x0, #0x0, lsl #48
    a654:      	b	0xa51c <_stogir.conversion.policy+0xec>
    a658:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000a658:  ARM64_RELOC_PAGE21	l_stogir.453
    a65c:      	ldr	x16, [x16]
		000000000000a65c:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    a660:      	orr	x0, x16, xzr
    a664:      	mov	x1, #0x1                ; =1
    a668:      	mov	x2, #0x22               ; =34
    a66c:      	ldr	x3, [sp, #0x10]
    a670:      	str	x1, [x3]
    a674:      	str	x0, [x3, #0x8]
    a678:      	str	x2, [x3, #0x10]
    a67c:      	ldr	x19, [sp, #0x20]
    a680:      	ldr	x20, [sp, #0x28]
    a684:      	ldr	x21, [sp, #0x30]
    a688:      	ldr	x22, [sp, #0x38]
    a68c:      	ldr	x23, [sp, #0x40]
    a690:      	ldr	x24, [sp, #0x48]
    a694:      	ldr	x25, [sp, #0x50]
    a698:      	ldr	x26, [sp, #0x58]
    a69c:      	ldr	x27, [sp, #0x60]
    a6a0:      	ldr	x28, [sp, #0x68]
    a6a4:      	ldr	x29, [sp]
    a6a8:      	ldr	x30, [sp, #0x8]
    a6ac:      	add	sp, sp, #0x70
    a6b0:      	ret
    a6b4:      	cmp	x21, #0x0
    a6b8:      	b.ne	0xa710 <_stogir.conversion.policy+0x2e0>
    a6bc:      	movz	x23, #0x0, lsl #48
    a6c0:      	b	0xa56c <_stogir.conversion.policy+0x13c>
    a6c4:      	cmp	x20, #0x0
    a6c8:      	b.ne	0xa788 <_stogir.conversion.policy+0x358>
    a6cc:      	movz	x0, #0x0, lsl #48
    a6d0:      	b	0xa51c <_stogir.conversion.policy+0xec>
    a6d4:      	cmp	x21, #0xf
    a6d8:      	b.le	0xa4b0 <_stogir.conversion.policy+0x80>
    a6dc:      	cmp	x21, #0x80
    a6e0:      	b.ge	0xa708 <_stogir.conversion.policy+0x2d8>
    a6e4:      	and	x0, x21, #0xf
    a6e8:      	lsr	w0, w0, #0
    a6ec:      	sxtw	x0, w0
    a6f0:      	cmp	x0, #0x1
    a6f4:      	b.lt	0xa800 <_stogir.conversion.policy+0x3d0>
    a6f8:      	cmp	x0, #0xd
    a6fc:      	cset	w0, le
    a700:      	ubfx	x22, x0, #0, #8
    a704:      	b	0xa804 <_stogir.conversion.policy+0x3d4>
    a708:      	movz	x22, #0x0, lsl #48
    a70c:      	b	0xa4b4 <_stogir.conversion.policy+0x84>
    a710:      	cmp	x21, #0x1
    a714:      	b.eq	0xa568 <_stogir.conversion.policy+0x138>
    a718:      	cmp	x21, #0x2
    a71c:      	b.eq	0xa568 <_stogir.conversion.policy+0x138>
    a720:      	cmp	x21, #0x7
    a724:      	b.eq	0xa568 <_stogir.conversion.policy+0x138>
    a728:      	cmp	x21, #0x8
    a72c:      	b.eq	0xa568 <_stogir.conversion.policy+0x138>
    a730:      	cmp	x21, #0x3
    a734:      	b.eq	0xa8f4 <_stogir.conversion.policy+0x4c4>
    a738:      	cmp	x21, #0x9
    a73c:      	b.eq	0xa8f4 <_stogir.conversion.policy+0x4c4>
    a740:      	cmp	x21, #0x4
    a744:      	b.eq	0xa964 <_stogir.conversion.policy+0x534>
    a748:      	cmp	x21, #0xa
    a74c:      	b.eq	0xa964 <_stogir.conversion.policy+0x534>
    a750:      	uxtb	w16, w22
    a754:      	cmp	w16, wzr
    a758:      	b.ne	0xa964 <_stogir.conversion.policy+0x534>
    a75c:      	cmp	x21, #0x5
    a760:      	b.eq	0xa984 <_stogir.conversion.policy+0x554>
    a764:      	cmp	x21, #0xb
    a768:      	b.eq	0xa984 <_stogir.conversion.policy+0x554>
    a76c:      	uxtb	w16, w28
    a770:      	cmp	w16, wzr
    a774:      	b.ne	0xa984 <_stogir.conversion.policy+0x554>
    a778:      	cmp	x21, #0x6
    a77c:      	b.eq	0xa784 <_stogir.conversion.policy+0x354>
    a780:      	movn	x23, #0x0, lsl #48
    a784:      	b	0xa988 <_stogir.conversion.policy+0x558>
    a788:      	cmp	x20, #0x1
    a78c:      	b.eq	0xa518 <_stogir.conversion.policy+0xe8>
    a790:      	cmp	x20, #0x2
    a794:      	b.eq	0xa518 <_stogir.conversion.policy+0xe8>
    a798:      	cmp	x20, #0x7
    a79c:      	b.eq	0xa518 <_stogir.conversion.policy+0xe8>
    a7a0:      	cmp	x20, #0x8
    a7a4:      	b.eq	0xa518 <_stogir.conversion.policy+0xe8>
    a7a8:      	cmp	x20, #0x3
    a7ac:      	b.eq	0xa8fc <_stogir.conversion.policy+0x4cc>
    a7b0:      	cmp	x20, #0x9
    a7b4:      	b.eq	0xa8fc <_stogir.conversion.policy+0x4cc>
    a7b8:      	cmp	x20, #0x4
    a7bc:      	b.eq	0xa96c <_stogir.conversion.policy+0x53c>
    a7c0:      	cmp	x20, #0xa
    a7c4:      	b.eq	0xa96c <_stogir.conversion.policy+0x53c>
    a7c8:      	uxtb	w16, w24
    a7cc:      	cmp	w16, wzr
    a7d0:      	b.ne	0xa96c <_stogir.conversion.policy+0x53c>
    a7d4:      	cmp	x20, #0x5
    a7d8:      	b.eq	0xa98c <_stogir.conversion.policy+0x55c>
    a7dc:      	cmp	x20, #0xb
    a7e0:      	b.eq	0xa98c <_stogir.conversion.policy+0x55c>
    a7e4:      	uxtb	w16, w25
    a7e8:      	cmp	w16, wzr
    a7ec:      	b.ne	0xa98c <_stogir.conversion.policy+0x55c>
    a7f0:      	cmp	x20, #0x6
    a7f4:      	b.ne	0xa994 <_stogir.conversion.policy+0x564>
    a7f8:      	mov	x0, x23
    a7fc:      	b	0xa998 <_stogir.conversion.policy+0x568>
    a800:      	movz	x22, #0x0, lsl #48
    a804:      	b	0xa70c <_stogir.conversion.policy+0x2dc>
    a808:      	mov	x4, #0x1                ; =1
    a80c:      	cmp	x4, #0x0
    a810:      	b.ne	0xa658 <_stogir.conversion.policy+0x228>
    a814:      	cmp	x1, #0x23
    a818:      	b.eq	0xa828 <_stogir.conversion.policy+0x3f8>
    a81c:      	uxtb	w16, w3
    a820:      	cmp	w16, wzr
    a824:      	b.eq	0xa82c <_stogir.conversion.policy+0x3fc>
    a828:      	mov	x2, x0
    a82c:      	and	x0, x2, #0xffffffff
    a830:      	movz	x1, #0x0, lsl #48
    a834:      	movz	x2, #0x0, lsl #48
    a838:      	b	0xa66c <_stogir.conversion.policy+0x23c>
    a83c:      	movz	x8, #0x0, lsl #48
    a840:      	cmp	x8, #0x0
    a844:      	cset	w4, ne
    a848:      	uxtb	w16, w4
    a84c:      	cmp	w16, wzr
    a850:      	cset	x4, eq
    a854:      	b	0xa80c <_stogir.conversion.policy+0x3dc>
    a858:      	cmp	x1, #0x24
    a85c:      	b.ne	0xa878 <_stogir.conversion.policy+0x448>
    a860:      	cmp	x2, x0
    a864:      	cset	w4, eq
    a868:      	uxtb	w16, w4
    a86c:      	cmp	w16, wzr
    a870:      	cset	x4, eq
    a874:      	b	0xa80c <_stogir.conversion.policy+0x3dc>
    a878:      	uxtb	w16, w4
    a87c:      	cmp	w16, wzr
    a880:      	b.eq	0xa808 <_stogir.conversion.policy+0x3d8>
    a884:      	uxtb	w16, w5
    a888:      	cmp	w16, wzr
    a88c:      	b.eq	0xa808 <_stogir.conversion.policy+0x3d8>
    a890:      	uxtb	w16, w6
    a894:      	cmp	w16, wzr
    a898:      	b.eq	0xa934 <_stogir.conversion.policy+0x504>
    a89c:      	uxtb	w16, w7
    a8a0:      	cmp	w16, wzr
    a8a4:      	b.eq	0xa934 <_stogir.conversion.policy+0x504>
    a8a8:      	cmp	x1, #0x23
    a8ac:      	b.ne	0xa974 <_stogir.conversion.policy+0x544>
    a8b0:      	cmp	x0, x2
    a8b4:      	cset	w4, ge
    a8b8:      	ubfx	x4, x4, #0, #8
    a8bc:      	b	0xa980 <_stogir.conversion.policy+0x550>
    a8c0:      	movz	x8, #0x0, lsl #48
    a8c4:      	b	0xa840 <_stogir.conversion.policy+0x410>
    a8c8:      	uxtb	w16, w3
    a8cc:      	cmp	w16, wzr
    a8d0:      	b.eq	0xa90c <_stogir.conversion.policy+0x4dc>
    a8d4:      	uxtb	w16, w25
    a8d8:      	cmp	w16, wzr
    a8dc:      	b.ne	0xa950 <_stogir.conversion.policy+0x520>
    a8e0:      	uxtb	w16, w24
    a8e4:      	cmp	w16, wzr
    a8e8:      	b.ne	0xa950 <_stogir.conversion.policy+0x520>
    a8ec:      	movz	x8, #0x0, lsl #48
    a8f0:      	b	0xa908 <_stogir.conversion.policy+0x4d8>
    a8f4:      	mov	x23, #0x2               ; =2
    a8f8:      	b	0xa56c <_stogir.conversion.policy+0x13c>
    a8fc:      	mov	x0, #0x2                ; =2
    a900:      	b	0xa51c <_stogir.conversion.policy+0xec>
    a904:      	movz	x8, #0x0, lsl #48
    a908:      	b	0xa840 <_stogir.conversion.policy+0x410>
    a90c:      	cmp	x1, #0x27
    a910:      	b.ne	0xa83c <_stogir.conversion.policy+0x40c>
    a914:      	uxtb	w16, w25
    a918:      	cmp	w16, wzr
    a91c:      	b.ne	0xa93c <_stogir.conversion.policy+0x50c>
    a920:      	uxtb	w16, w24
    a924:      	cmp	w16, wzr
    a928:      	b.ne	0xa93c <_stogir.conversion.policy+0x50c>
    a92c:      	movz	x8, #0x0, lsl #48
    a930:      	b	0xa94c <_stogir.conversion.policy+0x51c>
    a934:      	mov	x4, #0x1                ; =1
    a938:      	b	0xa80c <_stogir.conversion.policy+0x3dc>
    a93c:      	uxtb	w16, w28
    a940:      	cmp	w16, wzr
    a944:      	b.eq	0xa94c <_stogir.conversion.policy+0x51c>
    a948:      	mov	x8, #0x1                ; =1
    a94c:      	b	0xa840 <_stogir.conversion.policy+0x410>
    a950:      	uxtb	w16, w6
    a954:      	cmp	w16, wzr
    a958:      	b.eq	0xa904 <_stogir.conversion.policy+0x4d4>
    a95c:      	ubfx	x8, x7, #0, #8
    a960:      	b	0xa908 <_stogir.conversion.policy+0x4d8>
    a964:      	mov	x23, #0x4               ; =4
    a968:      	b	0xa8f8 <_stogir.conversion.policy+0x4c8>
    a96c:      	mov	x0, #0x4                ; =4
    a970:      	b	0xa900 <_stogir.conversion.policy+0x4d0>
    a974:      	cmp	x0, x2
    a978:      	cset	w4, le
    a97c:      	ubfx	x4, x4, #0, #8
    a980:      	b	0xa938 <_stogir.conversion.policy+0x508>
    a984:      	mov	x23, #0x8               ; =8
    a988:      	b	0xa968 <_stogir.conversion.policy+0x538>
    a98c:      	mov	x0, #0x8                ; =8
    a990:      	b	0xa970 <_stogir.conversion.policy+0x540>
    a994:      	movn	x0, #0x0, lsl #48
    a998:      	b	0xa990 <_stogir.conversion.policy+0x560>
    a99c:      	str	x8, [sp, #0x10]
    a9a0:      	str	x19, [sp, #0x18]
    a9a4:      	mov	w28, w2
    a9a8:      	mov	w19, w3
    a9ac:      	b	0xa638 <_stogir.conversion.policy+0x208>
    a9b0:      	mov	x19, x0
    a9b4:      	mov	w22, w1
    a9b8:      	mov	w28, w2
    a9bc:      	b	0xa618 <_stogir.conversion.policy+0x1e8>

000000000000a9c0 <_stogir.conditional.operands>:
    a9c0:      	sub	sp, sp, #0x30
    a9c4:      	str	x19, [sp, #0x20]
    a9c8:      	str	x20, [sp, #0x28]
    a9cc:      	sxtw	x1, w1
    a9d0:      	cmp	x1, #0x0
    a9d4:      	b.eq	0xaa28 <_stogir.conditional.operands+0x68>
    a9d8:      	cmp	x1, #0x0
    a9dc:      	b.lt	0xa9fc <_stogir.conditional.operands+0x3c>
    a9e0:      	cmp	x1, #0xd
    a9e4:      	b.gt	0xa9fc <_stogir.conditional.operands+0x3c>
    a9e8:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000a9e8:  ARM64_RELOC_PAGE21	l_stogir.454
    a9ec:      	ldr	x16, [x16]
		000000000000a9ec:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    a9f0:      	orr	x5, x16, xzr
    a9f4:      	movz	x6, #0x0, lsl #48
    a9f8:      	b	0xaa38 <_stogir.conditional.operands+0x78>
    a9fc:      	cmp	x1, #0xf
    aa00:      	b.le	0xaa28 <_stogir.conditional.operands+0x68>
    aa04:      	cmp	x1, #0x80
    aa08:      	b.ge	0xaa28 <_stogir.conditional.operands+0x68>
    aa0c:      	and	x5, x1, #0xf
    aa10:      	lsr	w5, w5, #0
    aa14:      	sxtw	x5, w5
    aa18:      	cmp	x5, #0x1
    aa1c:      	b.lt	0xaa28 <_stogir.conditional.operands+0x68>
    aa20:      	cmp	x5, #0xd
    aa24:      	b.le	0xa9e8 <_stogir.conditional.operands+0x28>
    aa28:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000aa28:  ARM64_RELOC_PAGE21	l_stogir.455
    aa2c:      	ldr	x16, [x16]
		000000000000aa2c:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    aa30:      	orr	x5, x16, xzr
    aa34:      	mov	x6, #0x2b               ; =43
    aa38:      	sxtw	x2, w2
    aa3c:      	cmp	x2, #0x0
    aa40:      	cset	w7, gt
    aa44:      	movz	x16, #0x0, lsl #48
    aa48:      	sub	x9, x16, x2
    aa4c:      	sub	x10, x9, #0x1
    aa50:      	uxtb	w16, w7
    aa54:      	cmp	w16, wzr
    aa58:      	b.eq	0xaa98 <_stogir.conditional.operands+0xd8>
    aa5c:      	ldr	x9, [x0, #0x8]
    aa60:      	cmp	x2, x9
    aa64:      	b.ge	0xaaf0 <_stogir.conditional.operands+0x130>
    aa68:      	add	x9, x0, #0x78
    aa6c:      	ldr	x9, [x9, #0x8]
    aa70:      	cmp	x2, x9
    aa74:      	b.ge	0xae1c <_stogir.conditional.operands+0x45c>
    aa78:      	ldr	x9, [x0, #0x78]
    aa7c:      	add	x9, x9, x2, lsl #2
    aa80:      	ldr	w9, [x9]
    aa84:      	sxtw	x9, w9
    aa88:      	cmp	x9, #0x0
    aa8c:      	cset	w9, ge
    aa90:      	ubfx	x9, x9, #0, #8
    aa94:      	b	0xae20 <_stogir.conditional.operands+0x460>
    aa98:      	cmp	x2, #0x0
    aa9c:      	b.ge	0xaaf8 <_stogir.conditional.operands+0x138>
    aaa0:      	add	x11, x0, #0x28
    aaa4:      	add	x12, x0, #0x50
    aaa8:      	ldr	x11, [x11, #0x8]
    aaac:      	ldr	x12, [x12, #0x8]
    aab0:      	cmp	x11, x12
    aab4:      	b.ne	0xaae0 <_stogir.conditional.operands+0x120>
    aab8:      	cmp	x9, x11
    aabc:      	b.gt	0xae24 <_stogir.conditional.operands+0x464>
    aac0:      	ldr	x9, [x0, #0x50]
    aac4:      	add	x9, x9, x10, lsl #2
    aac8:      	ldr	w9, [x9]
    aacc:      	sxtw	x9, w9
    aad0:      	cmp	x9, #0x0
    aad4:      	cset	w9, gt
    aad8:      	ubfx	x9, x9, #0, #8
    aadc:      	b	0xae28 <_stogir.conditional.operands+0x468>
    aae0:      	movz	x9, #0x0, lsl #48
    aae4:      	b	0xaafc <_stogir.conditional.operands+0x13c>
    aae8:      	movz	x14, #0x0, lsl #48
    aaec:      	b	0xab8c <_stogir.conditional.operands+0x1cc>
    aaf0:      	movz	x9, #0x0, lsl #48
    aaf4:      	b	0xaafc <_stogir.conditional.operands+0x13c>
    aaf8:      	movz	x9, #0x0, lsl #48
    aafc:      	cmp	x9, #0x0
    ab00:      	b.eq	0xab34 <_stogir.conditional.operands+0x174>
    ab04:      	uxtb	w16, w7
    ab08:      	cmp	w16, wzr
    ab0c:      	b.eq	0xab20 <_stogir.conditional.operands+0x160>
    ab10:      	ldr	x7, [x0]
    ab14:      	add	x2, x7, x2, lsl #4
    ab18:      	ldr	x2, [x2]
    ab1c:      	b	0xab2c <_stogir.conditional.operands+0x16c>
    ab20:      	ldr	x2, [x0, #0x28]
    ab24:      	add	x2, x2, x10, lsl #4
    ab28:      	ldr	x2, [x2]
    ab2c:      	mov	x7, #0x1                ; =1
    ab30:      	b	0xab3c <_stogir.conditional.operands+0x17c>
    ab34:      	movz	x7, #0x0, lsl #48
    ab38:      	movz	x2, #0x0, lsl #48
    ab3c:      	lsr	w7, w7, #0
    ab40:      	lsr	x16, x7, #0
    ab44:      	cmp	x16, #0x1
    ab48:      	b.eq	0xab64 <_stogir.conditional.operands+0x1a4>
    ab4c:      	b.lo	0xab54 <_stogir.conditional.operands+0x194>
    ab50:      	b	0xab68 <_stogir.conditional.operands+0x1a8>
    ab54:      	cmp	x16, #0x0
    ab58:      	b.eq	0xab60 <_stogir.conditional.operands+0x1a0>
    ab5c:      	b	0xab68 <_stogir.conditional.operands+0x1a8>
    ab60:      	b	0xab6c <_stogir.conditional.operands+0x1ac>
    ab64:      	b	0xab90 <_stogir.conditional.operands+0x1d0>
    ab68:      	b	0xae3c <_stogir.conditional.operands+0x47c>
    ab6c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000ab6c:  ARM64_RELOC_PAGE21	l_stogir.456
    ab70:      	ldr	x16, [x16]
		000000000000ab70:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    ab74:      	orr	x5, x16, xzr
    ab78:      	mov	x6, #0x16               ; =22
    ab7c:      	b	0xabd4 <_stogir.conditional.operands+0x214>
    ab80:      	movz	x14, #0x0, lsl #48
    ab84:      	b	0xac34 <_stogir.conditional.operands+0x274>
    ab88:      	movz	x14, #0x0, lsl #48
    ab8c:      	b	0xac3c <_stogir.conditional.operands+0x27c>
    ab90:      	uxtb	w7, w2
    ab94:      	cmp	x7, #0x48
    ab98:      	b.eq	0xabc4 <_stogir.conditional.operands+0x204>
    ab9c:      	cmp	x7, #0x46
    aba0:      	b.eq	0xabc4 <_stogir.conditional.operands+0x204>
    aba4:      	lsr	w2, w2, #0
    aba8:      	orr	x7, x2, xzr
    abac:      	ubfx	x7, x7, #8, #8
    abb0:      	cmp	x7, #0x0
    abb4:      	b.eq	0xabc4 <_stogir.conditional.operands+0x204>
    abb8:      	ubfx	x2, x2, #8, #8
    abbc:      	cmp	x2, #0xd
    abc0:      	b.le	0xabd4 <_stogir.conditional.operands+0x214>
    abc4:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000abc4:  ARM64_RELOC_PAGE21	l_stogir.457
    abc8:      	ldr	x16, [x16]
		000000000000abc8:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    abcc:      	orr	x5, x16, xzr
    abd0:      	mov	x6, #0x2a               ; =42
    abd4:      	add	x16, sp, #0x10
    abd8:      	orr	x2, x16, xzr
    abdc:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000abdc:  ARM64_RELOC_PAGE21	l_stogir.458
    abe0:      	ldr	x16, [x16]
		000000000000abe0:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    abe4:      	orr	x7, x16, xzr
    abe8:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000abe8:  ARM64_RELOC_PAGE21	l_stogir.459
    abec:      	ldr	x16, [x16]
		000000000000abec:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    abf0:      	orr	x9, x16, xzr
    abf4:      	lsr	w3, w3, #0
    abf8:      	lsr	w4, w4, #0
    abfc:      	add	x10, x0, #0x78
    ac00:      	add	x11, x0, #0x28
    ac04:      	add	x12, x0, #0x50
    ac08:      	mov	x16, sp
    ac0c:      	str	w3, [x16]
    ac10:      	mov	x16, sp
    ac14:      	str	w4, [x16, #0x4]
    ac18:      	mov	x16, sp
    ac1c:      	ldr	x3, [x16]
    ac20:      	add	x16, sp, #0x10
    ac24:      	str	x3, [x16]
    ac28:      	movz	x3, #0x0, lsl #48
    ac2c:      	b	0xace4 <_stogir.conditional.operands+0x324>
    ac30:      	movz	x14, #0x0, lsl #48
    ac34:      	b	0xac3c <_stogir.conditional.operands+0x27c>
    ac38:      	movz	x14, #0x0, lsl #48
    ac3c:      	cmp	x14, #0x0
    ac40:      	b.eq	0xac74 <_stogir.conditional.operands+0x2b4>
    ac44:      	uxtb	w16, w4
    ac48:      	cmp	w16, wzr
    ac4c:      	b.eq	0xac60 <_stogir.conditional.operands+0x2a0>
    ac50:      	ldr	x4, [x0]
    ac54:      	add	x4, x4, x13, lsl #4
    ac58:      	ldr	x4, [x4]
    ac5c:      	b	0xac6c <_stogir.conditional.operands+0x2ac>
    ac60:      	ldr	x4, [x0, #0x28]
    ac64:      	add	x4, x4, x15, lsl #4
    ac68:      	ldr	x4, [x4]
    ac6c:      	mov	x13, #0x1               ; =1
    ac70:      	b	0xac7c <_stogir.conditional.operands+0x2bc>
    ac74:      	movz	x13, #0x0, lsl #48
    ac78:      	movz	x4, #0x0, lsl #48
    ac7c:      	lsr	w13, w13, #0
    ac80:      	lsr	x16, x13, #0
    ac84:      	cmp	x16, #0x1
    ac88:      	b.eq	0xaca4 <_stogir.conditional.operands+0x2e4>
    ac8c:      	b.lo	0xac94 <_stogir.conditional.operands+0x2d4>
    ac90:      	b	0xaca8 <_stogir.conditional.operands+0x2e8>
    ac94:      	cmp	x16, #0x0
    ac98:      	b.eq	0xaca0 <_stogir.conditional.operands+0x2e0>
    ac9c:      	b	0xaca8 <_stogir.conditional.operands+0x2e8>
    aca0:      	b	0xacac <_stogir.conditional.operands+0x2ec>
    aca4:      	b	0xacb8 <_stogir.conditional.operands+0x2f8>
    aca8:      	b	0xae34 <_stogir.conditional.operands+0x474>
    acac:      	mov	x5, x7
    acb0:      	mov	x6, #0x10               ; =16
    acb4:      	b	0xace4 <_stogir.conditional.operands+0x324>
    acb8:      	uxtb	w13, w4
    acbc:      	cmp	x13, #0x48
    acc0:      	b.eq	0xacdc <_stogir.conditional.operands+0x31c>
    acc4:      	cmp	x13, #0x46
    acc8:      	b.eq	0xacdc <_stogir.conditional.operands+0x31c>
    accc:      	lsr	w4, w4, #0
    acd0:      	ubfx	x4, x4, #8, #8
    acd4:      	cmp	x4, x1
    acd8:      	b.eq	0xace4 <_stogir.conditional.operands+0x324>
    acdc:      	mov	x5, x9
    ace0:      	mov	x6, #0x21               ; =33
    ace4:      	cmp	x3, #0x2
    ace8:      	b.ge	0xad0c <_stogir.conditional.operands+0x34c>
    acec:      	add	x4, x3, #0x1
    acf0:      	add	x3, x2, x3, lsl #2
    acf4:      	ldr	w3, [x3]
    acf8:      	sxtw	x3, w3
    acfc:      	and	x13, x3, #0xffffffff
    ad00:      	mov	x3, x4
    ad04:      	mov	x4, #0x1                ; =1
    ad08:      	b	0xad14 <_stogir.conditional.operands+0x354>
    ad0c:      	movz	x4, #0x0, lsl #48
    ad10:      	movz	x13, #0x0, lsl #48
    ad14:      	lsr	w4, w4, #0
    ad18:      	lsr	x16, x4, #0
    ad1c:      	cmp	x16, #0x1
    ad20:      	b.eq	0xad3c <_stogir.conditional.operands+0x37c>
    ad24:      	b.lo	0xad2c <_stogir.conditional.operands+0x36c>
    ad28:      	b	0xad40 <_stogir.conditional.operands+0x380>
    ad2c:      	cmp	x16, #0x0
    ad30:      	b.eq	0xad38 <_stogir.conditional.operands+0x378>
    ad34:      	b	0xad40 <_stogir.conditional.operands+0x380>
    ad38:      	b	0xada4 <_stogir.conditional.operands+0x3e4>
    ad3c:      	b	0xad44 <_stogir.conditional.operands+0x384>
    ad40:      	b	0xae2c <_stogir.conditional.operands+0x46c>
    ad44:      	lsr	w13, w13, #0
    ad48:      	sxtw	x13, w13
    ad4c:      	cmp	x13, #0x0
    ad50:      	cset	w4, gt
    ad54:      	movz	x16, #0x0, lsl #48
    ad58:      	sub	x14, x16, x13
    ad5c:      	sub	x15, x14, #0x1
    ad60:      	uxtb	w16, w4
    ad64:      	cmp	w16, wzr
    ad68:      	b.eq	0xaddc <_stogir.conditional.operands+0x41c>
    ad6c:      	ldr	x14, [x0, #0x8]
    ad70:      	cmp	x13, x14
    ad74:      	b.ge	0xac30 <_stogir.conditional.operands+0x270>
    ad78:      	ldr	x14, [x10, #0x8]
    ad7c:      	cmp	x13, x14
    ad80:      	b.ge	0xab80 <_stogir.conditional.operands+0x1c0>
    ad84:      	ldr	x14, [x0, #0x78]
    ad88:      	add	x14, x14, x13, lsl #2
    ad8c:      	ldr	w14, [x14]
    ad90:      	sxtw	x14, w14
    ad94:      	cmp	x14, #0x0
    ad98:      	cset	w14, ge
    ad9c:      	ubfx	x14, x14, #0, #8
    ada0:      	b	0xab84 <_stogir.conditional.operands+0x1c4>
    ada4:      	cmp	x6, #0x0
    ada8:      	b.ne	0xadbc <_stogir.conditional.operands+0x3fc>
    adac:      	and	x5, x1, #0xffffffff
    adb0:      	movz	x0, #0x0, lsl #48
    adb4:      	movz	x6, #0x0, lsl #48
    adb8:      	b	0xadc0 <_stogir.conditional.operands+0x400>
    adbc:      	mov	x0, #0x1                ; =1
    adc0:      	str	x0, [x8]
    adc4:      	str	x5, [x8, #0x8]
    adc8:      	str	x6, [x8, #0x10]
    adcc:      	ldr	x19, [sp, #0x20]
    add0:      	ldr	x20, [sp, #0x28]
    add4:      	add	sp, sp, #0x30
    add8:      	ret
    addc:      	cmp	x13, #0x0
    ade0:      	b.ge	0xac38 <_stogir.conditional.operands+0x278>
    ade4:      	ldr	x19, [x11, #0x8]
    ade8:      	ldr	x20, [x12, #0x8]
    adec:      	cmp	x19, x20
    adf0:      	b.ne	0xab88 <_stogir.conditional.operands+0x1c8>
    adf4:      	cmp	x14, x19
    adf8:      	b.gt	0xaae8 <_stogir.conditional.operands+0x128>
    adfc:      	ldr	x14, [x0, #0x50]
    ae00:      	add	x14, x14, x15, lsl #2
    ae04:      	ldr	w14, [x14]
    ae08:      	sxtw	x14, w14
    ae0c:      	cmp	x14, #0x0
    ae10:      	cset	w14, gt
    ae14:      	ubfx	x14, x14, #0, #8
    ae18:      	b	0xaaec <_stogir.conditional.operands+0x12c>
    ae1c:      	movz	x9, #0x0, lsl #48
    ae20:      	b	0xaaf4 <_stogir.conditional.operands+0x134>
    ae24:      	movz	x9, #0x0, lsl #48
    ae28:      	b	0xaae4 <_stogir.conditional.operands+0x124>
    ae2c:      	brk	#0
    ae30:      	b	0xae2c <_stogir.conditional.operands+0x46c>
    ae34:      	brk	#0
    ae38:      	b	0xae34 <_stogir.conditional.operands+0x474>
    ae3c:      	brk	#0
    ae40:      	b	0xae3c <_stogir.conditional.operands+0x47c>

000000000000ae44 <_stogir.floating.operands>:
    ae44:      	sub	sp, sp, #0x90
    ae48:      	str	x29, [sp]
    ae4c:      	str	x30, [sp, #0x8]
    ae50:      	mov	x29, sp
    ae54:      	str	x19, [sp, #0x60]
    ae58:      	str	x20, [sp, #0x68]
    ae5c:      	str	x21, [sp, #0x70]
    ae60:      	str	x22, [sp, #0x78]
    ae64:      	str	x23, [sp, #0x80]
    ae68:      	sxtw	x1, w1
    ae6c:      	sxtw	x19, w2
    ae70:      	cmp	x1, #0x1f
    ae74:      	cset	w2, eq
    ae78:      	cmp	x1, #0x20
    ae7c:      	cset	w6, eq
    ae80:      	cmp	x1, #0xe
    ae84:      	b.lt	0xaeb4 <_stogir.floating.operands+0x70>
    ae88:      	cmp	x1, #0x19
    ae8c:      	b.gt	0xaeb4 <_stogir.floating.operands+0x70>
    ae90:      	cmp	x19, #0xc
    ae94:      	b.eq	0xaef0 <_stogir.floating.operands+0xac>
    ae98:      	cmp	x19, #0xd
    ae9c:      	b.eq	0xaef0 <_stogir.floating.operands+0xac>
    aea0:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000aea0:  ARM64_RELOC_PAGE21	l_stogir.460
    aea4:      	ldr	x16, [x16]
		000000000000aea4:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    aea8:      	orr	x20, x16, xzr
    aeac:      	mov	x21, #0x22              ; =34
    aeb0:      	b	0xaf00 <_stogir.floating.operands+0xbc>
    aeb4:      	uxtb	w16, w2
    aeb8:      	cmp	w16, wzr
    aebc:      	b.ne	0xae90 <_stogir.floating.operands+0x4c>
    aec0:      	uxtb	w16, w6
    aec4:      	cmp	w16, wzr
    aec8:      	b.ne	0xae90 <_stogir.floating.operands+0x4c>
    aecc:      	cmp	x1, #0x1a
    aed0:      	b.lt	0xaedc <_stogir.floating.operands+0x98>
    aed4:      	cmp	x1, #0x1d
    aed8:      	b.le	0xae90 <_stogir.floating.operands+0x4c>
    aedc:      	cmp	x1, #0x3a
    aee0:      	b.eq	0xae90 <_stogir.floating.operands+0x4c>
    aee4:      	cmp	x1, #0x3b
    aee8:      	b.eq	0xae90 <_stogir.floating.operands+0x4c>
    aeec:      	b	0xaea0 <_stogir.floating.operands+0x5c>
    aef0:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000aef0:  ARM64_RELOC_PAGE21	l_stogir.461
    aef4:      	ldr	x16, [x16]
		000000000000aef4:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    aef8:      	orr	x20, x16, xzr
    aefc:      	movz	x21, #0x0, lsl #48
    af00:      	lsr	w3, w3, #0
    af04:      	add	x16, sp, #0x10
    af08:      	str	w3, [x16]
    af0c:      	uxtb	w16, w2
    af10:      	cmp	w16, wzr
    af14:      	b.ne	0xaf8c <_stogir.floating.operands+0x148>
    af18:      	uxtb	w16, w6
    af1c:      	cmp	w16, wzr
    af20:      	b.ne	0xaf8c <_stogir.floating.operands+0x148>
    af24:      	sxtw	x3, w4
    af28:      	b	0xaf90 <_stogir.floating.operands+0x14c>
    af2c:      	movz	x1, #0x0, lsl #48
    af30:      	uxtb	w1, w1
    af34:      	and	x1, x1, #0x2
    af38:      	uxtb	w1, w1
    af3c:      	cmp	x1, #0x0
    af40:      	cset	w1, eq
    af44:      	uxtb	w16, w1
    af48:      	cmp	w16, wzr
    af4c:      	cset	x1, eq
    af50:      	cmp	x1, #0x0
    af54:      	b.ne	0xaf78 <_stogir.floating.operands+0x134>
    af58:      	cmp	x0, #0x65
    af5c:      	b.eq	0xaf78 <_stogir.floating.operands+0x134>
    af60:      	cmp	x0, #0x66
    af64:      	b.eq	0xaf78 <_stogir.floating.operands+0x134>
    af68:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000af68:  ARM64_RELOC_PAGE21	l_stogir.462
    af6c:      	ldr	x16, [x16]
		000000000000af6c:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    af70:      	orr	x20, x16, xzr
    af74:      	mov	x21, #0x2d              ; =45
    af78:      	b	0xb078 <_stogir.floating.operands+0x234>
    af7c:      	movz	x13, #0x0, lsl #48
    af80:      	b	0xafe4 <_stogir.floating.operands+0x1a0>
    af84:      	movz	x13, #0x0, lsl #48
    af88:      	b	0xafec <_stogir.floating.operands+0x1a8>
    af8c:      	sxtw	x3, w3
    af90:      	add	x16, sp, #0x20
    af94:      	orr	x2, x16, xzr
    af98:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000af98:  ARM64_RELOC_PAGE21	l_stogir.463
    af9c:      	ldr	x16, [x16]
		000000000000af9c:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    afa0:      	orr	x4, x16, xzr
    afa4:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x100>
		000000000000afa4:  ARM64_RELOC_PAGE21	l_stogir.464
    afa8:      	ldr	x16, [x16]
		000000000000afa8:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    afac:      	orr	x6, x16, xzr
    afb0:      	add	x7, x0, #0x78
    afb4:      	add	x9, x0, #0x28
    afb8:      	add	x10, x0, #0x50
    afbc:      	lsr	w3, w3, #0
    afc0:      	add	x16, sp, #0x10
    afc4:      	str	w3, [x16, #0x4]
    afc8:      	add	x16, sp, #0x10
    afcc:      	ldr	x3, [x16]
    afd0:      	add	x16, sp, #0x20
    afd4:      	str	x3, [x16]
    afd8:      	movz	x3, #0x0, lsl #48
    afdc:      	b	0xb094 <_stogir.floating.operands+0x250>
    afe0:      	movz	x13, #0x0, lsl #48
    afe4:      	b	0xafec <_stogir.floating.operands+0x1a8>
    afe8:      	movz	x13, #0x0, lsl #48
    afec:      	cmp	x13, #0x0
    aff0:      	b.eq	0xb024 <_stogir.floating.operands+0x1e0>
    aff4:      	uxtb	w16, w11
    aff8:      	cmp	w16, wzr
    affc:      	b.eq	0xb010 <_stogir.floating.operands+0x1cc>
    b000:      	ldr	x11, [x0]
    b004:      	add	x11, x11, x12, lsl #4
    b008:      	ldr	x11, [x11]
    b00c:      	b	0xb01c <_stogir.floating.operands+0x1d8>
    b010:      	ldr	x11, [x0, #0x28]
    b014:      	add	x11, x11, x14, lsl #4
    b018:      	ldr	x11, [x11]
    b01c:      	mov	x12, #0x1               ; =1
    b020:      	b	0xb02c <_stogir.floating.operands+0x1e8>
    b024:      	movz	x12, #0x0, lsl #48
    b028:      	movz	x11, #0x0, lsl #48
    b02c:      	lsr	w12, w12, #0
    b030:      	lsr	x16, x12, #0
    b034:      	cmp	x16, #0x1
    b038:      	b.eq	0xb054 <_stogir.floating.operands+0x210>
    b03c:      	b.lo	0xb044 <_stogir.floating.operands+0x200>
    b040:      	b	0xb058 <_stogir.floating.operands+0x214>
    b044:      	cmp	x16, #0x0
    b048:      	b.eq	0xb050 <_stogir.floating.operands+0x20c>
    b04c:      	b	0xb058 <_stogir.floating.operands+0x214>
    b050:      	b	0xb05c <_stogir.floating.operands+0x218>
    b054:      	b	0xb07c <_stogir.floating.operands+0x238>
    b058:      	b	0xb298 <_stogir.floating.operands+0x454>
    b05c:      	mov	x20, x4
    b060:      	mov	x21, #0x18              ; =24
    b064:      	b	0xb094 <_stogir.floating.operands+0x250>
    b068:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b068:  ARM64_RELOC_PAGE21	l_stogir.465
    b06c:      	ldr	x16, [x16]
		000000000000b06c:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    b070:      	orr	x20, x16, xzr
    b074:      	mov	x21, #0x21              ; =33
    b078:      	b	0xb164 <_stogir.floating.operands+0x320>
    b07c:      	lsr	w11, w11, #0
    b080:      	ubfx	x11, x11, #8, #8
    b084:      	cmp	x11, x19
    b088:      	b.eq	0xb094 <_stogir.floating.operands+0x250>
    b08c:      	mov	x20, x6
    b090:      	mov	x21, #0x1e              ; =30
    b094:      	cmp	x3, #0x2
    b098:      	b.ge	0xb0bc <_stogir.floating.operands+0x278>
    b09c:      	add	x11, x3, #0x1
    b0a0:      	add	x3, x2, x3, lsl #2
    b0a4:      	ldr	w3, [x3]
    b0a8:      	sxtw	x3, w3
    b0ac:      	and	x12, x3, #0xffffffff
    b0b0:      	mov	x3, x11
    b0b4:      	mov	x11, #0x1               ; =1
    b0b8:      	b	0xb0c4 <_stogir.floating.operands+0x280>
    b0bc:      	movz	x11, #0x0, lsl #48
    b0c0:      	movz	x12, #0x0, lsl #48
    b0c4:      	lsr	w11, w11, #0
    b0c8:      	lsr	x16, x11, #0
    b0cc:      	cmp	x16, #0x1
    b0d0:      	b.eq	0xb0ec <_stogir.floating.operands+0x2a8>
    b0d4:      	b.lo	0xb0dc <_stogir.floating.operands+0x298>
    b0d8:      	b	0xb0f0 <_stogir.floating.operands+0x2ac>
    b0dc:      	cmp	x16, #0x0
    b0e0:      	b.eq	0xb0e8 <_stogir.floating.operands+0x2a4>
    b0e4:      	b	0xb0f0 <_stogir.floating.operands+0x2ac>
    b0e8:      	b	0xb154 <_stogir.floating.operands+0x310>
    b0ec:      	b	0xb0f4 <_stogir.floating.operands+0x2b0>
    b0f0:      	b	0xb290 <_stogir.floating.operands+0x44c>
    b0f4:      	lsr	w12, w12, #0
    b0f8:      	sxtw	x12, w12
    b0fc:      	cmp	x12, #0x0
    b100:      	cset	w11, gt
    b104:      	movz	x16, #0x0, lsl #48
    b108:      	sub	x13, x16, x12
    b10c:      	sub	x14, x13, #0x1
    b110:      	uxtb	w16, w11
    b114:      	cmp	w16, wzr
    b118:      	b.eq	0xb1e0 <_stogir.floating.operands+0x39c>
    b11c:      	ldr	x13, [x0, #0x8]
    b120:      	cmp	x12, x13
    b124:      	b.ge	0xafe0 <_stogir.floating.operands+0x19c>
    b128:      	ldr	x13, [x7, #0x8]
    b12c:      	cmp	x12, x13
    b130:      	b.ge	0xaf7c <_stogir.floating.operands+0x138>
    b134:      	ldr	x13, [x0, #0x78]
    b138:      	add	x13, x13, x12, lsl #2
    b13c:      	ldr	w13, [x13]
    b140:      	sxtw	x13, w13
    b144:      	cmp	x13, #0x0
    b148:      	cset	w13, ge
    b14c:      	ubfx	x13, x13, #0, #8
    b150:      	b	0xaf80 <_stogir.floating.operands+0x13c>
    b154:      	sxtw	x22, w5
    b158:      	cmp	x22, #0x0
    b15c:      	b.ne	0xb17c <_stogir.floating.operands+0x338>
    b160:      	mov	x23, x8
    b164:      	cmp	x21, #0x0
    b168:      	b.ne	0xb220 <_stogir.floating.operands+0x3dc>
    b16c:      	and	x20, x19, #0xffffffff
    b170:      	movz	x0, #0x0, lsl #48
    b174:      	movz	x21, #0x0, lsl #48
    b178:      	b	0xb224 <_stogir.floating.operands+0x3e0>
    b17c:      	cmp	x1, #0x1d
    b180:      	b.ne	0xb2a8 <_stogir.floating.operands+0x464>
    b184:      	lsr	w5, w5, #0
    b188:      	mov	w1, w5
    b18c:      	mov	x23, x8
    b190:      	add	x8, sp, #0x30
    b194:      	bl	0xb194 <_stogir.floating.operands+0x350>
		000000000000b194:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b198:      	add	x16, sp, #0x30
    b19c:      	ldr	w0, [x16]
    b1a0:      	lsr	x16, x0, #0
    b1a4:      	cmp	x16, #0x1
    b1a8:      	b.eq	0xb1c4 <_stogir.floating.operands+0x380>
    b1ac:      	b.lo	0xb1b4 <_stogir.floating.operands+0x370>
    b1b0:      	b	0xb1c8 <_stogir.floating.operands+0x384>
    b1b4:      	cmp	x16, #0x0
    b1b8:      	b.eq	0xb1c0 <_stogir.floating.operands+0x37c>
    b1bc:      	b	0xb1c8 <_stogir.floating.operands+0x384>
    b1c0:      	b	0xb1cc <_stogir.floating.operands+0x388>
    b1c4:      	b	0xb25c <_stogir.floating.operands+0x418>
    b1c8:      	b	0xb2a0 <_stogir.floating.operands+0x45c>
    b1cc:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b1cc:  ARM64_RELOC_PAGE21	l_stogir.466
    b1d0:      	ldr	x16, [x16]
		000000000000b1d0:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    b1d4:      	orr	x20, x16, xzr
    b1d8:      	mov	x21, #0x16              ; =22
    b1dc:      	b	0xaf78 <_stogir.floating.operands+0x134>
    b1e0:      	cmp	x12, #0x0
    b1e4:      	b.ge	0xafe8 <_stogir.floating.operands+0x1a4>
    b1e8:      	ldr	x15, [x9, #0x8]
    b1ec:      	ldr	x22, [x10, #0x8]
    b1f0:      	cmp	x15, x22
    b1f4:      	b.ne	0xaf84 <_stogir.floating.operands+0x140>
    b1f8:      	cmp	x13, x15
    b1fc:      	b.gt	0xb254 <_stogir.floating.operands+0x410>
    b200:      	ldr	x13, [x0, #0x50]
    b204:      	add	x13, x13, x14, lsl #2
    b208:      	ldr	w13, [x13]
    b20c:      	sxtw	x13, w13
    b210:      	cmp	x13, #0x0
    b214:      	cset	w13, gt
    b218:      	ubfx	x13, x13, #0, #8
    b21c:      	b	0xb258 <_stogir.floating.operands+0x414>
    b220:      	mov	x0, #0x1                ; =1
    b224:      	str	x0, [x23]
    b228:      	str	x20, [x23, #0x8]
    b22c:      	str	x21, [x23, #0x10]
    b230:      	ldr	x19, [sp, #0x60]
    b234:      	ldr	x20, [sp, #0x68]
    b238:      	ldr	x21, [sp, #0x70]
    b23c:      	ldr	x22, [sp, #0x78]
    b240:      	ldr	x23, [sp, #0x80]
    b244:      	ldr	x29, [sp]
    b248:      	ldr	x30, [sp, #0x8]
    b24c:      	add	sp, sp, #0x90
    b250:      	ret
    b254:      	movz	x13, #0x0, lsl #48
    b258:      	b	0xaf88 <_stogir.floating.operands+0x144>
    b25c:      	add	x16, sp, #0x30
    b260:      	ldr	x0, [x16, #0x8]
    b264:      	cmp	x22, #0x0
    b268:      	b.lt	0xaf68 <_stogir.floating.operands+0x124>
    b26c:      	uxtb	w0, w0
    b270:      	cmp	x0, #0x83
    b274:      	b.ge	0xaf2c <_stogir.floating.operands+0xe8>
    b278:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b278:  ARM64_RELOC_PAGE21	l_stogir.467
    b27c:      	ldr	x16, [x16]
		000000000000b27c:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    b280:      	orr	x1, x16, xzr
    b284:      	add	x1, x0, x1
    b288:      	ldrb	w1, [x1]
    b28c:      	b	0xaf30 <_stogir.floating.operands+0xec>
    b290:      	brk	#0
    b294:      	b	0xb290 <_stogir.floating.operands+0x44c>
    b298:      	brk	#0
    b29c:      	b	0xb298 <_stogir.floating.operands+0x454>
    b2a0:      	brk	#0
    b2a4:      	b	0xb2a0 <_stogir.floating.operands+0x45c>
    b2a8:      	mov	x23, x8
    b2ac:      	b	0xb068 <_stogir.floating.operands+0x224>

000000000000b2b0 <_stogir.vector-lanes.operands>:
    b2b0:      	sub	sp, sp, #0x110
    b2b4:      	str	x29, [sp]
    b2b8:      	str	x30, [sp, #0x8]
    b2bc:      	mov	x29, sp
    b2c0:      	str	x19, [sp, #0xc0]
    b2c4:      	str	x20, [sp, #0xc8]
    b2c8:      	str	x21, [sp, #0xd0]
    b2cc:      	str	x22, [sp, #0xd8]
    b2d0:      	str	x23, [sp, #0xe0]
    b2d4:      	str	x24, [sp, #0xe8]
    b2d8:      	str	x25, [sp, #0xf0]
    b2dc:      	str	x26, [sp, #0xf8]
    b2e0:      	str	x27, [sp, #0x100]
    b2e4:      	str	x28, [sp, #0x108]
    b2e8:      	sxtw	x4, w4
    b2ec:      	cmp	x4, #0x0
    b2f0:      	cset	w7, gt
    b2f4:      	movz	x16, #0x0, lsl #48
    b2f8:      	sub	x9, x16, x4
    b2fc:      	sub	x10, x9, #0x1
    b300:      	uxtb	w16, w7
    b304:      	cmp	w16, wzr
    b308:      	b.eq	0xb348 <_stogir.vector-lanes.operands+0x98>
    b30c:      	ldr	x9, [x0, #0x8]
    b310:      	cmp	x4, x9
    b314:      	b.ge	0xb3a0 <_stogir.vector-lanes.operands+0xf0>
    b318:      	add	x9, x0, #0x78
    b31c:      	ldr	x9, [x9, #0x8]
    b320:      	cmp	x4, x9
    b324:      	b.ge	0xb4a0 <_stogir.vector-lanes.operands+0x1f0>
    b328:      	ldr	x9, [x0, #0x78]
    b32c:      	add	x9, x9, x4, lsl #2
    b330:      	ldr	w9, [x9]
    b334:      	sxtw	x9, w9
    b338:      	cmp	x9, #0x0
    b33c:      	cset	w9, ge
    b340:      	ubfx	x9, x9, #0, #8
    b344:      	b	0xb4a4 <_stogir.vector-lanes.operands+0x1f4>
    b348:      	cmp	x4, #0x0
    b34c:      	b.ge	0xb3a8 <_stogir.vector-lanes.operands+0xf8>
    b350:      	add	x11, x0, #0x28
    b354:      	add	x12, x0, #0x50
    b358:      	ldr	x11, [x11, #0x8]
    b35c:      	ldr	x12, [x12, #0x8]
    b360:      	cmp	x11, x12
    b364:      	b.ne	0xb390 <_stogir.vector-lanes.operands+0xe0>
    b368:      	cmp	x9, x11
    b36c:      	b.gt	0xb668 <_stogir.vector-lanes.operands+0x3b8>
    b370:      	ldr	x9, [x0, #0x50]
    b374:      	add	x9, x9, x10, lsl #2
    b378:      	ldr	w9, [x9]
    b37c:      	sxtw	x9, w9
    b380:      	cmp	x9, #0x0
    b384:      	cset	w9, gt
    b388:      	ubfx	x9, x9, #0, #8
    b38c:      	b	0xb66c <_stogir.vector-lanes.operands+0x3bc>
    b390:      	movz	x9, #0x0, lsl #48
    b394:      	b	0xb3ac <_stogir.vector-lanes.operands+0xfc>
    b398:      	mov	x1, #0x1                ; =1
    b39c:      	b	0xb434 <_stogir.vector-lanes.operands+0x184>
    b3a0:      	movz	x9, #0x0, lsl #48
    b3a4:      	b	0xb3ac <_stogir.vector-lanes.operands+0xfc>
    b3a8:      	movz	x9, #0x0, lsl #48
    b3ac:      	cmp	x9, #0x0
    b3b0:      	b.eq	0xb3e4 <_stogir.vector-lanes.operands+0x134>
    b3b4:      	uxtb	w16, w7
    b3b8:      	cmp	w16, wzr
    b3bc:      	b.eq	0xb3d0 <_stogir.vector-lanes.operands+0x120>
    b3c0:      	ldr	x7, [x0]
    b3c4:      	add	x4, x7, x4, lsl #4
    b3c8:      	ldr	x4, [x4]
    b3cc:      	b	0xb3dc <_stogir.vector-lanes.operands+0x12c>
    b3d0:      	ldr	x4, [x0, #0x28]
    b3d4:      	add	x4, x4, x10, lsl #4
    b3d8:      	ldr	x4, [x4]
    b3dc:      	mov	x7, #0x1                ; =1
    b3e0:      	b	0xb3ec <_stogir.vector-lanes.operands+0x13c>
    b3e4:      	movz	x7, #0x0, lsl #48
    b3e8:      	movz	x4, #0x0, lsl #48
    b3ec:      	lsr	w7, w7, #0
    b3f0:      	lsr	x16, x7, #0
    b3f4:      	cmp	x16, #0x1
    b3f8:      	b.eq	0xb414 <_stogir.vector-lanes.operands+0x164>
    b3fc:      	b.lo	0xb404 <_stogir.vector-lanes.operands+0x154>
    b400:      	b	0xb418 <_stogir.vector-lanes.operands+0x168>
    b404:      	cmp	x16, #0x0
    b408:      	b.eq	0xb410 <_stogir.vector-lanes.operands+0x160>
    b40c:      	b	0xb418 <_stogir.vector-lanes.operands+0x168>
    b410:      	b	0xb41c <_stogir.vector-lanes.operands+0x16c>
    b414:      	b	0xb47c <_stogir.vector-lanes.operands+0x1cc>
    b418:      	b	0xb964 <_stogir.vector-lanes.operands+0x6b4>
    b41c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b41c:  ARM64_RELOC_PAGE21	l_stogir.468
    b420:      	ldr	x16, [x16]
		000000000000b420:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    b424:      	orr	x19, x16, xzr
    b428:      	str	x8, [sp, #0xa0]
    b42c:      	mov	x1, #0x1                ; =1
    b430:      	mov	x0, #0x1b               ; =27
    b434:      	ldr	x2, [sp, #0xa0]
    b438:      	str	x1, [x2]
    b43c:      	str	x19, [x2, #0x8]
    b440:      	str	x0, [x2, #0x10]
    b444:      	ldr	x19, [sp, #0xc0]
    b448:      	ldr	x20, [sp, #0xc8]
    b44c:      	ldr	x21, [sp, #0xd0]
    b450:      	ldr	x22, [sp, #0xd8]
    b454:      	ldr	x23, [sp, #0xe0]
    b458:      	ldr	x24, [sp, #0xe8]
    b45c:      	ldr	x25, [sp, #0xf0]
    b460:      	ldr	x26, [sp, #0xf8]
    b464:      	ldr	x27, [sp, #0x100]
    b468:      	ldr	x28, [sp, #0x108]
    b46c:      	ldr	x29, [sp]
    b470:      	ldr	x30, [sp, #0x8]
    b474:      	add	sp, sp, #0x110
    b478:      	ret
    b47c:      	sxtw	x20, w1
    b480:      	sxtw	x1, w2
    b484:      	lsr	w7, w4, #0
    b488:      	ubfx	x7, x7, #8, #8
    b48c:      	orr	x21, x7, xzr
    b490:      	cmp	x20, #0x3d
    b494:      	b.ne	0xb4a8 <_stogir.vector-lanes.operands+0x1f8>
    b498:      	mov	x22, x21
    b49c:      	b	0xb4ac <_stogir.vector-lanes.operands+0x1fc>
    b4a0:      	movz	x9, #0x0, lsl #48
    b4a4:      	b	0xb3a4 <_stogir.vector-lanes.operands+0xf4>
    b4a8:      	mov	x22, x1
    b4ac:      	cmp	x20, #0x3d
    b4b0:      	b.eq	0xb4b8 <_stogir.vector-lanes.operands+0x208>
    b4b4:      	mov	x1, x21
    b4b8:      	lsr	w23, w22, #0
    b4bc:      	sxtw	x24, w23
    b4c0:      	cmp	x24, #0xf
    b4c4:      	cset	w25, gt
    b4c8:      	cmp	x24, #0x80
    b4cc:      	cset	w26, lt
    b4d0:      	and	x7, x24, #0xf
    b4d4:      	lsr	w7, w7, #0
    b4d8:      	sxtw	x7, w7
    b4dc:      	cmp	x7, #0x1
    b4e0:      	cset	w27, ge
    b4e4:      	cmp	x7, #0xd
    b4e8:      	cset	w28, le
    b4ec:      	cmp	x20, #0x3d
    b4f0:      	b.lt	0xb540 <_stogir.vector-lanes.operands+0x290>
    b4f4:      	cmp	x20, #0x3f
    b4f8:      	b.gt	0xb540 <_stogir.vector-lanes.operands+0x290>
    b4fc:      	uxtb	w16, w25
    b500:      	cmp	w16, wzr
    b504:      	b.eq	0xb540 <_stogir.vector-lanes.operands+0x290>
    b508:      	uxtb	w16, w26
    b50c:      	cmp	w16, wzr
    b510:      	b.eq	0xb540 <_stogir.vector-lanes.operands+0x290>
    b514:      	uxtb	w16, w27
    b518:      	cmp	w16, wzr
    b51c:      	b.eq	0xb540 <_stogir.vector-lanes.operands+0x290>
    b520:      	uxtb	w16, w28
    b524:      	cmp	w16, wzr
    b528:      	b.eq	0xb540 <_stogir.vector-lanes.operands+0x290>
    b52c:      	sxtw	x7, w3
    b530:      	cmp	x7, #0x4
    b534:      	b.eq	0xb994 <_stogir.vector-lanes.operands+0x6e4>
    b538:      	cmp	x7, #0x8
    b53c:      	b.eq	0xb994 <_stogir.vector-lanes.operands+0x6e4>
    b540:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b540:  ARM64_RELOC_PAGE21	l_stogir.469
    b544:      	ldr	x16, [x16]
		000000000000b544:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    b548:      	orr	x19, x16, xzr
    b54c:      	mov	x4, #0x36               ; =54
    b550:      	sxtw	x7, w5
    b554:      	sxtw	x9, w6
    b558:      	cmp	x9, #0x0
    b55c:      	cset	w9, eq
    b560:      	cmp	x20, #0x3f
    b564:      	b.ne	0xb9cc <_stogir.vector-lanes.operands+0x71c>
    b568:      	lsr	w1, w1, #0
    b56c:      	lsr	w3, w3, #0
    b570:      	mov	w0, w23
    b574:      	mov	w2, w3
    b578:      	mov	x20, x8
    b57c:      	mov	x21, x4
    b580:      	mov	x23, x7
    b584:      	mov	w24, w9
    b588:      	bl	0xb588 <_stogir.vector-lanes.operands+0x2d8>
		000000000000b588:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b58c:      	cmp	x0, #0x0
    b590:      	b.eq	0xb780 <_stogir.vector-lanes.operands+0x4d0>
    b594:      	movz	x0, #0x0, lsl #48
    b598:      	b	0xb784 <_stogir.vector-lanes.operands+0x4d4>
    b59c:      	cmp	x20, #0x3d
    b5a0:      	b.ne	0xb9d8 <_stogir.vector-lanes.operands+0x728>
    b5a4:      	lsr	w2, w2, #0
    b5a8:      	lsr	w3, w3, #0
    b5ac:      	str	x0, [sp, #0x80]
    b5b0:      	mov	w0, w23
    b5b4:      	str	w3, [sp, #0x98]
    b5b8:      	str	w6, [sp, #0xb0]
    b5bc:      	str	x1, [sp, #0xa0]
    b5c0:      	mov	w1, w2
    b5c4:      	mov	w2, w3
    b5c8:      	str	x4, [sp, #0xa8]
    b5cc:      	str	w8, [sp, #0xb8]
    b5d0:      	str	w23, [sp, #0x88]
    b5d4:      	mov	x23, x7
    b5d8:      	str	x22, [sp, #0x90]
    b5dc:      	mov	w22, w5
    b5e0:      	bl	0xb5e0 <_stogir.vector-lanes.operands+0x330>
		000000000000b5e0:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b5e4:      	cmp	x0, #0x0
    b5e8:      	b.ne	0xb600 <_stogir.vector-lanes.operands+0x350>
    b5ec:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b5ec:  ARM64_RELOC_PAGE21	l_stogir.470
    b5f0:      	ldr	x16, [x16]
		000000000000b5f0:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    b5f4:      	orr	x19, x16, xzr
    b5f8:      	mov	x16, #0x26              ; =38
    b5fc:      	str	x16, [sp, #0xa8]
    b600:      	cmp	x20, #0x3e
    b604:      	b.ne	0xb698 <_stogir.vector-lanes.operands+0x3e8>
    b608:      	cmp	x21, x24
    b60c:      	cset	w0, eq
    b610:      	uxtb	w16, w0
    b614:      	cmp	w16, wzr
    b618:      	cset	x0, eq
    b61c:      	b	0xb69c <_stogir.vector-lanes.operands+0x3ec>
    b620:      	mov	x0, #0x1                ; =1
    b624:      	cmp	x0, #0x0
    b628:      	b.eq	0xb63c <_stogir.vector-lanes.operands+0x38c>
    b62c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b62c:  ARM64_RELOC_PAGE21	l_stogir.471
    b630:      	ldr	x16, [x16]
		000000000000b630:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    b634:      	orr	x19, x16, xzr
    b638:      	mov	x21, #0x24              ; =36
    b63c:      	str	x22, [sp, #0x90]
    b640:      	str	x20, [sp, #0xa0]
    b644:      	str	x21, [sp, #0xa8]
    b648:      	ldr	x0, [sp, #0xa8]
    b64c:      	cmp	x0, #0x0
    b650:      	b.ne	0xb398 <_stogir.vector-lanes.operands+0xe8>
    b654:      	ldr	x0, [sp, #0x90]
    b658:      	and	x19, x0, #0xffffffff
    b65c:      	movz	x1, #0x0, lsl #48
    b660:      	movz	x0, #0x0, lsl #48
    b664:      	b	0xb39c <_stogir.vector-lanes.operands+0xec>
    b668:      	movz	x9, #0x0, lsl #48
    b66c:      	b	0xb394 <_stogir.vector-lanes.operands+0xe4>
    b670:      	ldr	w0, [sp, #0xb8]
    b674:      	uxtb	w16, w0
    b678:      	cmp	w16, wzr
    b67c:      	b.ne	0xb694 <_stogir.vector-lanes.operands+0x3e4>
    b680:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b680:  ARM64_RELOC_PAGE21	l_stogir.472
    b684:      	ldr	x16, [x16]
		000000000000b684:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    b688:      	orr	x19, x16, xzr
    b68c:      	mov	x16, #0x20              ; =32
    b690:      	str	x16, [sp, #0xa8]
    b694:      	b	0xb648 <_stogir.vector-lanes.operands+0x398>
    b698:      	movz	x0, #0x0, lsl #48
    b69c:      	cmp	x0, #0x0
    b6a0:      	b.eq	0xb6b8 <_stogir.vector-lanes.operands+0x408>
    b6a4:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b6a4:  ARM64_RELOC_PAGE21	l_stogir.473
    b6a8:      	ldr	x16, [x16]
		000000000000b6a8:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    b6ac:      	orr	x19, x16, xzr
    b6b0:      	mov	x16, #0x27              ; =39
    b6b4:      	str	x16, [sp, #0xa8]
    b6b8:      	lsr	w22, w22, #0
    b6bc:      	add	x8, sp, #0x10
    b6c0:      	ldr	x0, [sp, #0x80]
    b6c4:      	mov	w1, w22
    b6c8:      	bl	0xb6c8 <_stogir.vector-lanes.operands+0x418>
		000000000000b6c8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b6cc:      	add	x16, sp, #0x10
    b6d0:      	ldr	w0, [x16]
    b6d4:      	lsr	x16, x0, #0
    b6d8:      	cmp	x16, #0x1
    b6dc:      	b.eq	0xb6f8 <_stogir.vector-lanes.operands+0x448>
    b6e0:      	b.lo	0xb6e8 <_stogir.vector-lanes.operands+0x438>
    b6e4:      	b	0xb6fc <_stogir.vector-lanes.operands+0x44c>
    b6e8:      	cmp	x16, #0x0
    b6ec:      	b.eq	0xb6f4 <_stogir.vector-lanes.operands+0x444>
    b6f0:      	b	0xb6fc <_stogir.vector-lanes.operands+0x44c>
    b6f4:      	b	0xb700 <_stogir.vector-lanes.operands+0x450>
    b6f8:      	b	0xb7ac <_stogir.vector-lanes.operands+0x4fc>
    b6fc:      	b	0xb9bc <_stogir.vector-lanes.operands+0x70c>
    b700:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b700:  ARM64_RELOC_PAGE21	l_stogir.474
    b704:      	ldr	x16, [x16]
		000000000000b704:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    b708:      	orr	x19, x16, xzr
    b70c:      	mov	x16, #0x19              ; =25
    b710:      	str	x16, [sp, #0xa8]
    b714:      	cmp	x20, #0x3e
    b718:      	b.ne	0xb670 <_stogir.vector-lanes.operands+0x3c0>
    b71c:      	ldr	w0, [sp, #0xb0]
    b720:      	lsr	w0, w0, #0
    b724:      	add	x8, sp, #0x50
    b728:      	mov	w1, w0
    b72c:      	ldr	x0, [sp, #0x80]
    b730:      	bl	0xb730 <_stogir.vector-lanes.operands+0x480>
		000000000000b730:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b734:      	add	x16, sp, #0x50
    b738:      	ldr	w0, [x16]
    b73c:      	lsr	x16, x0, #0
    b740:      	cmp	x16, #0x1
    b744:      	b.eq	0xb760 <_stogir.vector-lanes.operands+0x4b0>
    b748:      	b.lo	0xb750 <_stogir.vector-lanes.operands+0x4a0>
    b74c:      	b	0xb764 <_stogir.vector-lanes.operands+0x4b4>
    b750:      	cmp	x16, #0x0
    b754:      	b.eq	0xb75c <_stogir.vector-lanes.operands+0x4ac>
    b758:      	b	0xb764 <_stogir.vector-lanes.operands+0x4b4>
    b75c:      	b	0xb768 <_stogir.vector-lanes.operands+0x4b8>
    b760:      	b	0xb89c <_stogir.vector-lanes.operands+0x5ec>
    b764:      	b	0xb9c4 <_stogir.vector-lanes.operands+0x714>
    b768:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b768:  ARM64_RELOC_PAGE21	l_stogir.475
    b76c:      	ldr	x16, [x16]
		000000000000b76c:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    b770:      	orr	x19, x16, xzr
    b774:      	mov	x16, #0x20              ; =32
    b778:      	str	x16, [sp, #0xa8]
    b77c:      	b	0xb694 <_stogir.vector-lanes.operands+0x3e4>
    b780:      	mov	x0, #0x1                ; =1
    b784:      	cmp	x0, #0x0
    b788:      	b.eq	0xb794 <_stogir.vector-lanes.operands+0x4e4>
    b78c:      	mov	x0, #0x1                ; =1
    b790:      	b	0xb624 <_stogir.vector-lanes.operands+0x374>
    b794:      	cmp	x23, #0x0
    b798:      	b.ne	0xb620 <_stogir.vector-lanes.operands+0x370>
    b79c:      	uxtb	w16, w24
    b7a0:      	cmp	w16, wzr
    b7a4:      	cset	x0, eq
    b7a8:      	b	0xb624 <_stogir.vector-lanes.operands+0x374>
    b7ac:      	add	x16, sp, #0x10
    b7b0:      	orr	x0, x16, xzr
    b7b4:      	add	x0, x0, #0x8
    b7b8:      	add	x16, sp, #0x10
    b7bc:      	ldr	x1, [x16, #0x8]
    b7c0:      	add	x16, sp, #0x40
    b7c4:      	str	x1, [x16]
    b7c8:      	lsr	w1, w1, #0
    b7cc:      	ldr	x0, [x0, #0x8]
    b7d0:      	add	x16, sp, #0x40
    b7d4:      	str	x0, [x16, #0x8]
    b7d8:      	ubfx	x0, x1, #8, #8
    b7dc:      	cmp	x0, #0x1
    b7e0:      	b.lt	0xb808 <_stogir.vector-lanes.operands+0x558>
    b7e4:      	cmp	x0, #0xb
    b7e8:      	b.gt	0xb808 <_stogir.vector-lanes.operands+0x558>
    b7ec:      	add	x16, sp, #0x40
    b7f0:      	ldr	w0, [x16]
    b7f4:      	uxtb	w0, w0
    b7f8:      	cmp	x0, #0x48
    b7fc:      	b.eq	0xb808 <_stogir.vector-lanes.operands+0x558>
    b800:      	cmp	x0, #0x46
    b804:      	b.ne	0xb81c <_stogir.vector-lanes.operands+0x56c>
    b808:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b808:  ARM64_RELOC_PAGE21	l_stogir.476
    b80c:      	ldr	x16, [x16]
		000000000000b80c:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    b810:      	orr	x19, x16, xzr
    b814:      	mov	x16, #0x2b              ; =43
    b818:      	str	x16, [sp, #0xa8]
    b81c:      	cmp	x23, #0x0
    b820:      	b.ge	0xb84c <_stogir.vector-lanes.operands+0x59c>
    b824:      	add	x16, sp, #0x40
    b828:      	ldr	w0, [x16]
    b82c:      	uxtb	w1, w0
    b830:      	ubfx	x0, x0, #8, #8
    b834:      	cmp	x1, x0
    b838:      	b.eq	0xb8fc <_stogir.vector-lanes.operands+0x64c>
    b83c:      	cmp	x1, #0x49
    b840:      	b.eq	0xb8fc <_stogir.vector-lanes.operands+0x64c>
    b844:      	movz	x0, #0x0, lsl #48
    b848:      	b	0xb898 <_stogir.vector-lanes.operands+0x5e8>
    b84c:      	movz	x0, #0x0, lsl #48
    b850:      	cmp	x0, #0x0
    b854:      	b.eq	0xb86c <_stogir.vector-lanes.operands+0x5bc>
    b858:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b858:  ARM64_RELOC_PAGE21	l_stogir.477
    b85c:      	ldr	x16, [x16]
		000000000000b85c:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    b860:      	orr	x19, x16, xzr
    b864:      	mov	x16, #0x28              ; =40
    b868:      	str	x16, [sp, #0xa8]
    b86c:      	b	0xb714 <_stogir.vector-lanes.operands+0x464>
    b870:      	movn	x2, #0x0, lsl #48
    b874:      	ubfx	x0, x0, #0, #32
    b878:      	ubfx	x1, x1, #0, #32
    b87c:      	lsl	x1, x1, #32
    b880:      	orr	x0, x1, x0
    b884:      	lsr	w2, w2, #0
    b888:      	sxtw	x2, w2
    b88c:      	cmp	x0, x2
    b890:      	cset	w0, hs
    b894:      	ubfx	x0, x0, #0, #8
    b898:      	b	0xb850 <_stogir.vector-lanes.operands+0x5a0>
    b89c:      	add	x16, sp, #0x50
    b8a0:      	ldr	x0, [x16, #0x8]
    b8a4:      	uxtb	w1, w0
    b8a8:      	cmp	x1, #0x48
    b8ac:      	b.eq	0xb8e4 <_stogir.vector-lanes.operands+0x634>
    b8b0:      	cmp	x1, #0x46
    b8b4:      	b.eq	0xb8e4 <_stogir.vector-lanes.operands+0x634>
    b8b8:      	ldr	w1, [sp, #0x98]
    b8bc:      	lsr	w1, w1, #0
    b8c0:      	lsr	w0, w0, #0
    b8c4:      	ubfx	x0, x0, #8, #8
    b8c8:      	lsr	w0, w0, #0
    b8cc:      	mov	w2, w1
    b8d0:      	mov	w1, w0
    b8d4:      	ldr	w0, [sp, #0x88]
    b8d8:      	bl	0xb8d8 <_stogir.vector-lanes.operands+0x628>
		000000000000b8d8:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b8dc:      	cmp	x0, #0x0
    b8e0:      	b.ne	0xb8f8 <_stogir.vector-lanes.operands+0x648>
    b8e4:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b8e4:  ARM64_RELOC_PAGE21	l_stogir.478
    b8e8:      	ldr	x16, [x16]
		000000000000b8e8:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    b8ec:      	orr	x19, x16, xzr
    b8f0:      	mov	x16, #0x27              ; =39
    b8f4:      	str	x16, [sp, #0xa8]
    b8f8:      	b	0xb77c <_stogir.vector-lanes.operands+0x4cc>
    b8fc:      	add	x16, sp, #0x40
    b900:      	ldr	w0, [x16, #0x8]
    b904:      	add	x16, sp, #0x40
    b908:      	ldr	w1, [x16, #0xc]
    b90c:      	uxtb	w16, w25
    b910:      	cmp	w16, wzr
    b914:      	b.eq	0xb96c <_stogir.vector-lanes.operands+0x6bc>
    b918:      	uxtb	w16, w26
    b91c:      	cmp	w16, wzr
    b920:      	b.eq	0xb96c <_stogir.vector-lanes.operands+0x6bc>
    b924:      	uxtb	w16, w27
    b928:      	cmp	w16, wzr
    b92c:      	b.eq	0xb96c <_stogir.vector-lanes.operands+0x6bc>
    b930:      	uxtb	w16, w28
    b934:      	cmp	w16, wzr
    b938:      	b.eq	0xb96c <_stogir.vector-lanes.operands+0x6bc>
    b93c:      	ubfx	x2, x24, #4, #32
    b940:      	sxtw	x2, w2
    b944:      	sub	x2, x2, #0x1
    b948:      	lsr	w2, w2, #0
    b94c:      	sxtw	x2, w2
    b950:      	mov	x16, #0x1               ; =1
    b954:      	lsl	x2, x16, x2
    b958:      	lsr	w2, w2, #0
    b95c:      	sxtw	x2, w2
    b960:      	b	0xb874 <_stogir.vector-lanes.operands+0x5c4>
    b964:      	brk	#0
    b968:      	b	0xb964 <_stogir.vector-lanes.operands+0x6b4>
    b96c:      	cmp	x24, #0x0
    b970:      	b.lt	0xb870 <_stogir.vector-lanes.operands+0x5c0>
    b974:      	cmp	x24, #0xd
    b978:      	b.gt	0xb870 <_stogir.vector-lanes.operands+0x5c0>
    b97c:      	cmp	x24, #0x0
    b980:      	cset	w2, eq
    b984:      	uxtb	w16, w2
    b988:      	cmp	w16, wzr
    b98c:      	cset	x2, eq
    b990:      	b	0xb874 <_stogir.vector-lanes.operands+0x5c4>
    b994:      	uxtb	w4, w4
    b998:      	cmp	x4, #0x48
    b99c:      	b.eq	0xb540 <_stogir.vector-lanes.operands+0x290>
    b9a0:      	cmp	x4, #0x46
    b9a4:      	b.eq	0xb540 <_stogir.vector-lanes.operands+0x290>
    b9a8:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000b9a8:  ARM64_RELOC_PAGE21	l_stogir.479
    b9ac:      	ldr	x16, [x16]
		000000000000b9ac:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    b9b0:      	orr	x19, x16, xzr
    b9b4:      	movz	x4, #0x0, lsl #48
    b9b8:      	b	0xb550 <_stogir.vector-lanes.operands+0x2a0>
    b9bc:      	brk	#0
    b9c0:      	b	0xb9bc <_stogir.vector-lanes.operands+0x70c>
    b9c4:      	brk	#0
    b9c8:      	b	0xb9c4 <_stogir.vector-lanes.operands+0x714>
    b9cc:      	mov	x1, x8
    b9d0:      	mov	w8, w9
    b9d4:      	b	0xb59c <_stogir.vector-lanes.operands+0x2ec>
    b9d8:      	str	x22, [sp, #0x90]
    b9dc:      	str	x1, [sp, #0xa0]
    b9e0:      	str	x0, [sp, #0x80]
    b9e4:      	str	w3, [sp, #0x98]
    b9e8:      	mov	w22, w5
    b9ec:      	str	w6, [sp, #0xb0]
    b9f0:      	str	w23, [sp, #0x88]
    b9f4:      	mov	x23, x7
    b9f8:      	str	w8, [sp, #0xb8]
    b9fc:      	str	x4, [sp, #0xa8]
    ba00:      	b	0xb600 <_stogir.vector-lanes.operands+0x350>

000000000000ba04 <_stogir.vector-comparison.operands>:
    ba04:      	sub	sp, sp, #0xc0
    ba08:      	str	x29, [sp]
    ba0c:      	str	x30, [sp, #0x8]
    ba10:      	mov	x29, sp
    ba14:      	str	x19, [sp, #0x70]
    ba18:      	str	x20, [sp, #0x78]
    ba1c:      	str	x21, [sp, #0x80]
    ba20:      	str	x22, [sp, #0x88]
    ba24:      	str	x23, [sp, #0x90]
    ba28:      	str	x24, [sp, #0x98]
    ba2c:      	str	x25, [sp, #0xa0]
    ba30:      	str	x26, [sp, #0xa8]
    ba34:      	str	x27, [sp, #0xb0]
    ba38:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000ba38:  ARM64_RELOC_PAGE21	l_stogir.480
    ba3c:      	ldr	x16, [x16]
		000000000000ba3c:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    ba40:      	orr	x19, x16, xzr
    ba44:      	lsr	w4, w4, #0
    ba48:      	mov	x20, x8
    ba4c:      	add	x8, sp, #0x10
    ba50:      	mov	x21, x0
    ba54:      	mov	w22, w1
    ba58:      	mov	w1, w4
    ba5c:      	mov	w23, w2
    ba60:      	mov	w24, w3
    ba64:      	mov	w25, w5
    ba68:      	bl	0xba68 <_stogir.vector-comparison.operands+0x64>
		000000000000ba68:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    ba6c:      	add	x16, sp, #0x10
    ba70:      	ldr	w0, [x16]
    ba74:      	lsr	x16, x0, #0
    ba78:      	cmp	x16, #0x1
    ba7c:      	b.eq	0xba98 <_stogir.vector-comparison.operands+0x94>
    ba80:      	b.lo	0xba88 <_stogir.vector-comparison.operands+0x84>
    ba84:      	b	0xba9c <_stogir.vector-comparison.operands+0x98>
    ba88:      	cmp	x16, #0x0
    ba8c:      	b.eq	0xba94 <_stogir.vector-comparison.operands+0x90>
    ba90:      	b	0xba9c <_stogir.vector-comparison.operands+0x98>
    ba94:      	b	0xbaa0 <_stogir.vector-comparison.operands+0x9c>
    ba98:      	b	0xbae8 <_stogir.vector-comparison.operands+0xe4>
    ba9c:      	b	0xbc68 <_stogir.vector-comparison.operands+0x264>
    baa0:      	mov	x0, #0x1                ; =1
    baa4:      	mov	x1, #0x21               ; =33
    baa8:      	str	x0, [x20]
    baac:      	str	x19, [x20, #0x8]
    bab0:      	str	x1, [x20, #0x10]
    bab4:      	ldr	x19, [sp, #0x70]
    bab8:      	ldr	x20, [sp, #0x78]
    babc:      	ldr	x21, [sp, #0x80]
    bac0:      	ldr	x22, [sp, #0x88]
    bac4:      	ldr	x23, [sp, #0x90]
    bac8:      	ldr	x24, [sp, #0x98]
    bacc:      	ldr	x25, [sp, #0xa0]
    bad0:      	ldr	x26, [sp, #0xa8]
    bad4:      	ldr	x27, [sp, #0xb0]
    bad8:      	ldr	x29, [sp]
    badc:      	ldr	x30, [sp, #0x8]
    bae0:      	add	sp, sp, #0xc0
    bae4:      	ret
    bae8:      	lsr	w25, w25, #0
    baec:      	add	x16, sp, #0x10
    baf0:      	ldr	x26, [x16, #0x8]
    baf4:      	add	x8, sp, #0x40
    baf8:      	mov	x0, x21
    bafc:      	mov	w1, w25
    bb00:      	bl	0xbb00 <_stogir.vector-comparison.operands+0xfc>
		000000000000bb00:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    bb04:      	add	x16, sp, #0x40
    bb08:      	ldr	w0, [x16]
    bb0c:      	lsr	x16, x0, #0
    bb10:      	cmp	x16, #0x1
    bb14:      	b.eq	0xbb30 <_stogir.vector-comparison.operands+0x12c>
    bb18:      	b.lo	0xbb20 <_stogir.vector-comparison.operands+0x11c>
    bb1c:      	b	0xbb34 <_stogir.vector-comparison.operands+0x130>
    bb20:      	cmp	x16, #0x0
    bb24:      	b.eq	0xbb2c <_stogir.vector-comparison.operands+0x128>
    bb28:      	b	0xbb34 <_stogir.vector-comparison.operands+0x130>
    bb2c:      	b	0xbb38 <_stogir.vector-comparison.operands+0x134>
    bb30:      	b	0xbb44 <_stogir.vector-comparison.operands+0x140>
    bb34:      	b	0xbc70 <_stogir.vector-comparison.operands+0x26c>
    bb38:      	mov	x0, #0x1                ; =1
    bb3c:      	mov	x1, #0x21               ; =33
    bb40:      	b	0xbaa8 <_stogir.vector-comparison.operands+0xa4>
    bb44:      	sxtw	x0, w24
    bb48:      	add	x16, sp, #0x40
    bb4c:      	ldr	x19, [x16, #0x8]
    bb50:      	cmp	x0, #0x4
    bb54:      	b.eq	0xbb78 <_stogir.vector-comparison.operands+0x174>
    bb58:      	cmp	x0, #0x8
    bb5c:      	b.eq	0xbb78 <_stogir.vector-comparison.operands+0x174>
    bb60:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000bb60:  ARM64_RELOC_PAGE21	l_stogir.481
    bb64:      	ldr	x16, [x16]
		000000000000bb64:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    bb68:      	orr	x19, x16, xzr
    bb6c:      	mov	x0, #0x1                ; =1
    bb70:      	mov	x1, #0x33               ; =51
    bb74:      	b	0xbb40 <_stogir.vector-comparison.operands+0x13c>
    bb78:      	lsr	w22, w22, #0
    bb7c:      	lsr	w0, w26, #0
    bb80:      	ubfx	x21, x0, #8, #8
    bb84:      	orr	x0, x21, xzr
    bb88:      	lsr	w0, w0, #0
    bb8c:      	mov	w1, w0
    bb90:      	mov	w0, w22
    bb94:      	bl	0xbb94 <_stogir.vector-comparison.operands+0x190>
		000000000000bb94:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    bb98:      	cmp	x0, #0x0
    bb9c:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bba0:      	lsr	w0, w19, #0
    bba4:      	ubfx	x0, x0, #8, #8
    bba8:      	cmp	x21, x0
    bbac:      	b.ne	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bbb0:      	uxtb	w26, w26
    bbb4:      	cmp	x26, #0x48
    bbb8:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bbbc:      	cmp	x26, #0x46
    bbc0:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bbc4:      	uxtb	w19, w19
    bbc8:      	cmp	x19, #0x48
    bbcc:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bbd0:      	cmp	x19, #0x46
    bbd4:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bbd8:      	sxtw	x23, w23
    bbdc:      	cmp	x23, #0xf
    bbe0:      	cset	w0, gt
    bbe4:      	uxtb	w16, w0
    bbe8:      	cmp	w16, wzr
    bbec:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bbf0:      	cmp	x23, #0x80
    bbf4:      	cset	w1, lt
    bbf8:      	uxtb	w16, w1
    bbfc:      	cmp	w16, wzr
    bc00:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bc04:      	and	x2, x23, #0xf
    bc08:      	lsr	w2, w2, #0
    bc0c:      	sxtw	x2, w2
    bc10:      	cmp	x2, #0x1
    bc14:      	cset	w3, ge
    bc18:      	uxtb	w16, w3
    bc1c:      	cmp	w16, wzr
    bc20:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bc24:      	cmp	x2, #0xd
    bc28:      	cset	w4, le
    bc2c:      	uxtb	w16, w4
    bc30:      	cmp	w16, wzr
    bc34:      	b.eq	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bc38:      	cmp	x23, #0x0
    bc3c:      	cset	w5, ge
    bc40:      	cmp	x23, #0xd
    bc44:      	cset	w6, le
    bc48:      	uxtb	w16, w5
    bc4c:      	cmp	w16, wzr
    bc50:      	b.eq	0xbc78 <_stogir.vector-comparison.operands+0x274>
    bc54:      	uxtb	w16, w6
    bc58:      	cmp	w16, wzr
    bc5c:      	b.eq	0xbc78 <_stogir.vector-comparison.operands+0x274>
    bc60:      	mov	x7, x2
    bc64:      	b	0xbcac <_stogir.vector-comparison.operands+0x2a8>
    bc68:      	brk	#0
    bc6c:      	b	0xbc68 <_stogir.vector-comparison.operands+0x264>
    bc70:      	brk	#0
    bc74:      	b	0xbc70 <_stogir.vector-comparison.operands+0x26c>
    bc78:      	uxtb	w16, w0
    bc7c:      	cmp	w16, wzr
    bc80:      	b.eq	0xbca8 <_stogir.vector-comparison.operands+0x2a4>
    bc84:      	uxtb	w16, w1
    bc88:      	cmp	w16, wzr
    bc8c:      	b.eq	0xbca8 <_stogir.vector-comparison.operands+0x2a4>
    bc90:      	uxtb	w16, w3
    bc94:      	cmp	w16, wzr
    bc98:      	b.eq	0xbca8 <_stogir.vector-comparison.operands+0x2a4>
    bc9c:      	uxtb	w16, w4
    bca0:      	cmp	w16, wzr
    bca4:      	b.ne	0xbc60 <_stogir.vector-comparison.operands+0x25c>
    bca8:      	movn	x7, #0x0, lsl #48
    bcac:      	lsr	w7, w7, #0
    bcb0:      	sxtw	x7, w7
    bcb4:      	cmp	x7, #0x1
    bcb8:      	b.lt	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bcbc:      	cmp	x7, #0xb
    bcc0:      	b.gt	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bcc4:      	uxtb	w16, w0
    bcc8:      	cmp	w16, wzr
    bccc:      	b.eq	0xbd1c <_stogir.vector-comparison.operands+0x318>
    bcd0:      	uxtb	w16, w1
    bcd4:      	cmp	w16, wzr
    bcd8:      	b.eq	0xbd1c <_stogir.vector-comparison.operands+0x318>
    bcdc:      	uxtb	w16, w3
    bce0:      	cmp	w16, wzr
    bce4:      	b.eq	0xbd1c <_stogir.vector-comparison.operands+0x318>
    bce8:      	uxtb	w16, w4
    bcec:      	cmp	w16, wzr
    bcf0:      	b.eq	0xbd1c <_stogir.vector-comparison.operands+0x318>
    bcf4:      	ubfx	x7, x23, #4, #32
    bcf8:      	sxtw	x7, w7
    bcfc:      	sub	x7, x7, #0x1
    bd00:      	lsr	w7, w7, #0
    bd04:      	sxtw	x7, w7
    bd08:      	mov	x16, #0x1               ; =1
    bd0c:      	lsl	x7, x16, x7
    bd10:      	lsr	w7, w7, #0
    bd14:      	sxtw	x7, w7
    bd18:      	b	0xbe4c <_stogir.vector-comparison.operands+0x448>
    bd1c:      	uxtb	w16, w5
    bd20:      	cmp	w16, wzr
    bd24:      	b.eq	0xbe48 <_stogir.vector-comparison.operands+0x444>
    bd28:      	uxtb	w16, w6
    bd2c:      	cmp	w16, wzr
    bd30:      	b.eq	0xbe48 <_stogir.vector-comparison.operands+0x444>
    bd34:      	cmp	x23, #0x0
    bd38:      	cset	w7, eq
    bd3c:      	uxtb	w16, w7
    bd40:      	cmp	w16, wzr
    bd44:      	cset	x7, eq
    bd48:      	b	0xbe4c <_stogir.vector-comparison.operands+0x448>
    bd4c:      	movn	x8, #0x0, lsl #48
    bd50:      	lsr	w7, w7, #0
    bd54:      	sxtw	x7, w7
    bd58:      	lsr	w8, w8, #0
    bd5c:      	sxtw	x8, w8
    bd60:      	cmp	x7, x8
    bd64:      	b.ne	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    bd68:      	uxtb	w16, w5
    bd6c:      	cmp	w16, wzr
    bd70:      	b.eq	0xbd80 <_stogir.vector-comparison.operands+0x37c>
    bd74:      	uxtb	w16, w6
    bd78:      	cmp	w16, wzr
    bd7c:      	b.ne	0xbdb4 <_stogir.vector-comparison.operands+0x3b0>
    bd80:      	uxtb	w16, w0
    bd84:      	cmp	w16, wzr
    bd88:      	b.eq	0xbdb0 <_stogir.vector-comparison.operands+0x3ac>
    bd8c:      	uxtb	w16, w1
    bd90:      	cmp	w16, wzr
    bd94:      	b.eq	0xbdb0 <_stogir.vector-comparison.operands+0x3ac>
    bd98:      	uxtb	w16, w3
    bd9c:      	cmp	w16, wzr
    bda0:      	b.eq	0xbdb0 <_stogir.vector-comparison.operands+0x3ac>
    bda4:      	uxtb	w16, w4
    bda8:      	cmp	w16, wzr
    bdac:      	b.ne	0xbdb4 <_stogir.vector-comparison.operands+0x3b0>
    bdb0:      	movn	x2, #0x0, lsl #48
    bdb4:      	lsr	w24, w24, #0
    bdb8:      	lsr	w2, w2, #0
    bdbc:      	lsr	w2, w2, #0
    bdc0:      	mov	w0, w2
    bdc4:      	mov	w1, w24
    bdc8:      	bl	0xbdc8 <_stogir.vector-comparison.operands+0x3c4>
		000000000000bdc8:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    bdcc:      	uxtb	w16, w19
    bdd0:      	cmp	w16, wzr
    bdd4:      	b.ne	0xbe0c <_stogir.vector-comparison.operands+0x408>
    bdd8:      	uxtb	w16, w22
    bddc:      	cmp	w16, wzr
    bde0:      	b.eq	0xbe08 <_stogir.vector-comparison.operands+0x404>
    bde4:      	uxtb	w16, w23
    bde8:      	cmp	w16, wzr
    bdec:      	b.eq	0xbe08 <_stogir.vector-comparison.operands+0x404>
    bdf0:      	uxtb	w16, w26
    bdf4:      	cmp	w16, wzr
    bdf8:      	b.eq	0xbe08 <_stogir.vector-comparison.operands+0x404>
    bdfc:      	uxtb	w16, w27
    be00:      	cmp	w16, wzr
    be04:      	b.ne	0xbe0c <_stogir.vector-comparison.operands+0x408>
    be08:      	movn	x25, #0x0, lsl #48
    be0c:      	lsr	w0, w0, #0
    be10:      	sxtw	x19, w0
    be14:      	lsr	w25, w25, #0
    be18:      	lsr	w25, w25, #0
    be1c:      	mov	w0, w25
    be20:      	mov	w1, w24
    be24:      	bl	0xbe24 <_stogir.vector-comparison.operands+0x420>
		000000000000be24:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    be28:      	lsr	w0, w0, #0
    be2c:      	sxtw	x0, w0
    be30:      	cmp	x19, x0
    be34:      	b.ne	0xbb60 <_stogir.vector-comparison.operands+0x15c>
    be38:      	and	x19, x21, #0xffffffff
    be3c:      	movz	x0, #0x0, lsl #48
    be40:      	movz	x1, #0x0, lsl #48
    be44:      	b	0xbb74 <_stogir.vector-comparison.operands+0x170>
    be48:      	movn	x7, #0x0, lsl #48
    be4c:      	and	x8, x21, #0xf
    be50:      	cmp	x21, #0xd
    be54:      	cset	w19, le
    be58:      	cmp	x21, #0xf
    be5c:      	cset	w22, gt
    be60:      	cmp	x21, #0x80
    be64:      	cset	w23, lt
    be68:      	lsr	w8, w8, #0
    be6c:      	sxtw	x25, w8
    be70:      	cmp	x25, #0x1
    be74:      	cset	w26, ge
    be78:      	cmp	x25, #0xd
    be7c:      	cset	w27, le
    be80:      	uxtb	w16, w22
    be84:      	cmp	w16, wzr
    be88:      	b.eq	0xbed8 <_stogir.vector-comparison.operands+0x4d4>
    be8c:      	uxtb	w16, w23
    be90:      	cmp	w16, wzr
    be94:      	b.eq	0xbed8 <_stogir.vector-comparison.operands+0x4d4>
    be98:      	uxtb	w16, w26
    be9c:      	cmp	w16, wzr
    bea0:      	b.eq	0xbed8 <_stogir.vector-comparison.operands+0x4d4>
    bea4:      	uxtb	w16, w27
    bea8:      	cmp	w16, wzr
    beac:      	b.eq	0xbed8 <_stogir.vector-comparison.operands+0x4d4>
    beb0:      	ubfx	x8, x21, #4, #32
    beb4:      	sxtw	x8, w8
    beb8:      	sub	x8, x8, #0x1
    bebc:      	lsr	w8, w8, #0
    bec0:      	sxtw	x8, w8
    bec4:      	mov	x16, #0x1               ; =1
    bec8:      	lsl	x8, x16, x8
    becc:      	lsr	w8, w8, #0
    bed0:      	sxtw	x8, w8
    bed4:      	b	0xbd50 <_stogir.vector-comparison.operands+0x34c>
    bed8:      	uxtb	w16, w19
    bedc:      	cmp	w16, wzr
    bee0:      	b.eq	0xbd4c <_stogir.vector-comparison.operands+0x348>
    bee4:      	cmp	x21, #0x0
    bee8:      	cset	w8, eq
    beec:      	uxtb	w16, w8
    bef0:      	cmp	w16, wzr
    bef4:      	cset	x8, eq
    bef8:      	b	0xbd50 <_stogir.vector-comparison.operands+0x34c>

000000000000befc <_stogir.vector-arithmetic.operands>:
    befc:      	sub	sp, sp, #0x80
    bf00:      	str	x29, [sp]
    bf04:      	str	x30, [sp, #0x8]
    bf08:      	mov	x29, sp
    bf0c:      	str	x19, [sp, #0x30]
    bf10:      	str	x20, [sp, #0x38]
    bf14:      	str	x21, [sp, #0x40]
    bf18:      	str	x22, [sp, #0x48]
    bf1c:      	str	x23, [sp, #0x50]
    bf20:      	str	x24, [sp, #0x58]
    bf24:      	str	x25, [sp, #0x60]
    bf28:      	str	x26, [sp, #0x68]
    bf2c:      	str	x27, [sp, #0x70]
    bf30:      	str	x28, [sp, #0x78]
    bf34:      	lsr	w1, w1, #0
    bf38:      	lsr	w2, w2, #0
    bf3c:      	mov	x19, x8
    bf40:      	mov	x20, x0
    bf44:      	mov	w0, w1
    bf48:      	mov	w21, w1
    bf4c:      	mov	w1, w2
    bf50:      	mov	w22, w2
    bf54:      	mov	w23, w3
    bf58:      	mov	w24, w4
    bf5c:      	mov	w25, w5
    bf60:      	bl	0xbf60 <_stogir.vector-arithmetic.operands+0x64>
		000000000000bf60:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    bf64:      	cmp	x0, #0x0
    bf68:      	b.eq	0xbf80 <_stogir.vector-arithmetic.operands+0x84>
    bf6c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000bf6c:  ARM64_RELOC_PAGE21	l_stogir.482
    bf70:      	ldr	x16, [x16]
		000000000000bf70:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    bf74:      	orr	x0, x16, xzr
    bf78:      	movz	x1, #0x0, lsl #48
    bf7c:      	b	0xbf90 <_stogir.vector-arithmetic.operands+0x94>
    bf80:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000bf80:  ARM64_RELOC_PAGE21	l_stogir.483
    bf84:      	ldr	x16, [x16]
		000000000000bf84:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    bf88:      	orr	x0, x16, xzr
    bf8c:      	mov	x1, #0x37               ; =55
    bf90:      	sxtw	x21, w21
    bf94:      	sxtw	x22, w22
    bf98:      	sxtw	x23, w23
    bf9c:      	sxtw	x24, w24
    bfa0:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000bfa0:  ARM64_RELOC_PAGE21	l_stogir.484
    bfa4:      	ldr	x16, [x16]
		000000000000bfa4:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    bfa8:      	orr	x2, x16, xzr
    bfac:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x1bc>
		000000000000bfac:  ARM64_RELOC_PAGE21	l_stogir.485
    bfb0:      	ldr	x16, [x16]
		000000000000bfb0:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    bfb4:      	orr	x3, x16, xzr
    bfb8:      	add	x4, x20, #0x78
    bfbc:      	add	x5, x20, #0x28
    bfc0:      	add	x6, x20, #0x50
    bfc4:      	cmp	x21, #0x31
    bfc8:      	cset	w7, ge
    bfcc:      	cmp	x21, #0x35
    bfd0:      	cset	w8, le
    bfd4:      	cmp	x21, #0x1f
    bfd8:      	cset	w9, eq
    bfdc:      	cmp	x21, #0x20
    bfe0:      	cset	w10, eq
    bfe4:      	cmp	x21, #0x2d
    bfe8:      	cset	w11, eq
    bfec:      	cmp	x21, #0x36
    bff0:      	cset	w12, eq
    bff4:      	cmp	x21, #0x37
    bff8:      	cset	w13, eq
    bffc:      	cmp	x21, #0x38
    c000:      	cset	w14, eq
    c004:      	cmp	x21, #0x39
    c008:      	cset	w15, eq
    c00c:      	movz	x26, #0x0, lsl #48
    c010:      	b	0xc134 <_stogir.vector-arithmetic.operands+0x238>
    c014:      	movz	x2, #0x0, lsl #48
    c018:      	b	0xc028 <_stogir.vector-arithmetic.operands+0x12c>
    c01c:      	movz	x2, #0x0, lsl #48
    c020:      	b	0xc030 <_stogir.vector-arithmetic.operands+0x134>
    c024:      	movz	x2, #0x0, lsl #48
    c028:      	b	0xc040 <_stogir.vector-arithmetic.operands+0x144>
    c02c:      	movz	x2, #0x0, lsl #48
    c030:      	str	x4, [sp, #0x20]
    c034:      	str	x5, [sp, #0x28]
    c038:      	b	0xc040 <_stogir.vector-arithmetic.operands+0x144>
    c03c:      	movz	x2, #0x0, lsl #48
    c040:      	cmp	x2, #0x0
    c044:      	b.eq	0xc078 <_stogir.vector-arithmetic.operands+0x17c>
    c048:      	uxtb	w16, w28
    c04c:      	cmp	w16, wzr
    c050:      	b.eq	0xc064 <_stogir.vector-arithmetic.operands+0x168>
    c054:      	ldr	x2, [x20]
    c058:      	add	x2, x2, x27, lsl #4
    c05c:      	ldr	x2, [x2]
    c060:      	b	0xc070 <_stogir.vector-arithmetic.operands+0x174>
    c064:      	ldr	x2, [x20, #0x28]
    c068:      	add	x2, x2, x3, lsl #4
    c06c:      	ldr	x2, [x2]
    c070:      	mov	x3, #0x1                ; =1
    c074:      	b	0xc080 <_stogir.vector-arithmetic.operands+0x184>
    c078:      	movz	x3, #0x0, lsl #48
    c07c:      	movz	x2, #0x0, lsl #48
    c080:      	lsr	w3, w3, #0
    c084:      	lsr	x16, x3, #0
    c088:      	cmp	x16, #0x1
    c08c:      	b.eq	0xc0a8 <_stogir.vector-arithmetic.operands+0x1ac>
    c090:      	b.lo	0xc098 <_stogir.vector-arithmetic.operands+0x19c>
    c094:      	b	0xc0ac <_stogir.vector-arithmetic.operands+0x1b0>
    c098:      	cmp	x16, #0x0
    c09c:      	b.eq	0xc0a4 <_stogir.vector-arithmetic.operands+0x1a8>
    c0a0:      	b	0xc0ac <_stogir.vector-arithmetic.operands+0x1b0>
    c0a4:      	b	0xc0b0 <_stogir.vector-arithmetic.operands+0x1b4>
    c0a8:      	b	0xc0bc <_stogir.vector-arithmetic.operands+0x1c0>
    c0ac:      	b	0xc41c <_stogir.vector-arithmetic.operands+0x520>
    c0b0:      	ldr	x0, [sp, #0x10]
    c0b4:      	mov	x1, #0x21               ; =33
    c0b8:      	b	0xc118 <_stogir.vector-arithmetic.operands+0x21c>
    c0bc:      	lsr	w3, w2, #0
    c0c0:      	ubfx	x3, x3, #8, #8
    c0c4:      	cmp	x3, x22
    c0c8:      	b.eq	0xc0fc <_stogir.vector-arithmetic.operands+0x200>
    c0cc:      	cmp	x26, #0x1
    c0d0:      	b.ne	0xc110 <_stogir.vector-arithmetic.operands+0x214>
    c0d4:      	uxtb	w16, w7
    c0d8:      	cmp	w16, wzr
    c0dc:      	b.eq	0xc110 <_stogir.vector-arithmetic.operands+0x214>
    c0e0:      	uxtb	w16, w8
    c0e4:      	cmp	w16, wzr
    c0e8:      	b.eq	0xc110 <_stogir.vector-arithmetic.operands+0x214>
    c0ec:      	cmp	x3, #0x1
    c0f0:      	b.lt	0xc110 <_stogir.vector-arithmetic.operands+0x214>
    c0f4:      	cmp	x3, #0xb
    c0f8:      	b.gt	0xc110 <_stogir.vector-arithmetic.operands+0x214>
    c0fc:      	uxtb	w2, w2
    c100:      	cmp	x2, #0x48
    c104:      	b.eq	0xc110 <_stogir.vector-arithmetic.operands+0x214>
    c108:      	cmp	x2, #0x46
    c10c:      	b.ne	0xc118 <_stogir.vector-arithmetic.operands+0x21c>
    c110:      	ldr	x0, [sp, #0x18]
    c114:      	mov	x1, #0x32               ; =50
    c118:      	add	x2, x26, #0x1
    c11c:      	lsr	w2, w2, #0
    c120:      	sxtw	x26, w2
    c124:      	ldr	x2, [sp, #0x10]
    c128:      	ldr	x3, [sp, #0x18]
    c12c:      	ldr	x4, [sp, #0x20]
    c130:      	ldr	x5, [sp, #0x28]
    c134:      	uxtb	w16, w9
    c138:      	cmp	w16, wzr
    c13c:      	b.ne	0xc190 <_stogir.vector-arithmetic.operands+0x294>
    c140:      	uxtb	w16, w10
    c144:      	cmp	w16, wzr
    c148:      	b.ne	0xc190 <_stogir.vector-arithmetic.operands+0x294>
    c14c:      	uxtb	w16, w11
    c150:      	cmp	w16, wzr
    c154:      	b.ne	0xc190 <_stogir.vector-arithmetic.operands+0x294>
    c158:      	uxtb	w16, w12
    c15c:      	cmp	w16, wzr
    c160:      	b.ne	0xc190 <_stogir.vector-arithmetic.operands+0x294>
    c164:      	uxtb	w16, w13
    c168:      	cmp	w16, wzr
    c16c:      	b.ne	0xc190 <_stogir.vector-arithmetic.operands+0x294>
    c170:      	uxtb	w16, w14
    c174:      	cmp	w16, wzr
    c178:      	b.ne	0xc190 <_stogir.vector-arithmetic.operands+0x294>
    c17c:      	uxtb	w16, w15
    c180:      	cmp	w16, wzr
    c184:      	b.ne	0xc190 <_stogir.vector-arithmetic.operands+0x294>
    c188:      	mov	x27, #0x2               ; =2
    c18c:      	b	0xc194 <_stogir.vector-arithmetic.operands+0x298>
    c190:      	mov	x27, #0x1               ; =1
    c194:      	cmp	x26, x27
    c198:      	b.ge	0xc260 <_stogir.vector-arithmetic.operands+0x364>
    c19c:      	cmp	x26, #0x0
    c1a0:      	b.ne	0xc1ac <_stogir.vector-arithmetic.operands+0x2b0>
    c1a4:      	mov	x27, x23
    c1a8:      	b	0xc1b0 <_stogir.vector-arithmetic.operands+0x2b4>
    c1ac:      	mov	x27, x24
    c1b0:      	lsr	w27, w27, #0
    c1b4:      	sxtw	x27, w27
    c1b8:      	cmp	x27, #0x0
    c1bc:      	cset	w28, gt
    c1c0:      	str	x2, [sp, #0x10]
    c1c4:      	movz	x16, #0x0, lsl #48
    c1c8:      	sub	x2, x16, x27
    c1cc:      	str	x3, [sp, #0x18]
    c1d0:      	sub	x3, x2, #0x1
    c1d4:      	uxtb	w16, w28
    c1d8:      	cmp	w16, wzr
    c1dc:      	b.eq	0xc218 <_stogir.vector-arithmetic.operands+0x31c>
    c1e0:      	ldr	x2, [x20, #0x8]
    c1e4:      	cmp	x27, x2
    c1e8:      	b.ge	0xc02c <_stogir.vector-arithmetic.operands+0x130>
    c1ec:      	ldr	x2, [x4, #0x8]
    c1f0:      	cmp	x27, x2
    c1f4:      	b.ge	0xc01c <_stogir.vector-arithmetic.operands+0x120>
    c1f8:      	ldr	x2, [x20, #0x78]
    c1fc:      	add	x2, x2, x27, lsl #2
    c200:      	ldr	w2, [x2]
    c204:      	sxtw	x2, w2
    c208:      	cmp	x2, #0x0
    c20c:      	cset	w2, ge
    c210:      	ubfx	x2, x2, #0, #8
    c214:      	b	0xc020 <_stogir.vector-arithmetic.operands+0x124>
    c218:      	cmp	x27, #0x0
    c21c:      	b.ge	0xc500 <_stogir.vector-arithmetic.operands+0x604>
    c220:      	str	x4, [sp, #0x20]
    c224:      	ldr	x4, [x5, #0x8]
    c228:      	str	x5, [sp, #0x28]
    c22c:      	ldr	x5, [x6, #0x8]
    c230:      	cmp	x4, x5
    c234:      	b.ne	0xc024 <_stogir.vector-arithmetic.operands+0x128>
    c238:      	cmp	x2, x4
    c23c:      	b.gt	0xc014 <_stogir.vector-arithmetic.operands+0x118>
    c240:      	ldr	x2, [x20, #0x50]
    c244:      	add	x2, x2, x3, lsl #2
    c248:      	ldr	w2, [x2]
    c24c:      	sxtw	x2, w2
    c250:      	cmp	x2, #0x0
    c254:      	cset	w2, gt
    c258:      	ubfx	x2, x2, #0, #8
    c25c:      	b	0xc018 <_stogir.vector-arithmetic.operands+0x11c>
    c260:      	sxtw	x25, w25
    c264:      	cmp	x25, #0x0
    c268:      	b.ne	0xc274 <_stogir.vector-arithmetic.operands+0x378>
    c26c:      	movz	x2, #0x0, lsl #48
    c270:      	b	0xc278 <_stogir.vector-arithmetic.operands+0x37c>
    c274:      	mov	x2, #0x1                ; =1
    c278:      	cmp	x2, #0x0
    c27c:      	b.eq	0xc2ac <_stogir.vector-arithmetic.operands+0x3b0>
    c280:      	cmp	x21, #0x1d
    c284:      	b.ne	0xc368 <_stogir.vector-arithmetic.operands+0x46c>
    c288:      	mov	x2, #0x1                ; =1
    c28c:      	b	0xc374 <_stogir.vector-arithmetic.operands+0x478>
    c290:      	mov	x2, #0x1                ; =1
    c294:      	cmp	x2, #0x0
    c298:      	b.eq	0xc30c <_stogir.vector-arithmetic.operands+0x410>
    c29c:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000c29c:  ARM64_RELOC_PAGE21	l_stogir.486
    c2a0:      	ldr	x16, [x16]
		000000000000c2a0:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    c2a4:      	orr	x0, x16, xzr
    c2a8:      	mov	x1, #0x23               ; =35
    c2ac:      	cmp	x1, #0x0
    c2b0:      	b.ne	0xc2c4 <_stogir.vector-arithmetic.operands+0x3c8>
    c2b4:      	and	x0, x22, #0xffffffff
    c2b8:      	movz	x2, #0x0, lsl #48
    c2bc:      	movz	x1, #0x0, lsl #48
    c2c0:      	b	0xc2c8 <_stogir.vector-arithmetic.operands+0x3cc>
    c2c4:      	mov	x2, #0x1                ; =1
    c2c8:      	str	x2, [x19]
    c2cc:      	str	x0, [x19, #0x8]
    c2d0:      	str	x1, [x19, #0x10]
    c2d4:      	ldr	x19, [sp, #0x30]
    c2d8:      	ldr	x20, [sp, #0x38]
    c2dc:      	ldr	x21, [sp, #0x40]
    c2e0:      	ldr	x22, [sp, #0x48]
    c2e4:      	ldr	x23, [sp, #0x50]
    c2e8:      	ldr	x24, [sp, #0x58]
    c2ec:      	ldr	x25, [sp, #0x60]
    c2f0:      	ldr	x26, [sp, #0x68]
    c2f4:      	ldr	x27, [sp, #0x70]
    c2f8:      	ldr	x28, [sp, #0x78]
    c2fc:      	ldr	x29, [sp]
    c300:      	ldr	x30, [sp, #0x8]
    c304:      	add	sp, sp, #0x80
    c308:      	ret
    c30c:      	cmp	x25, #0x0
    c310:      	cset	w2, gt
    c314:      	movz	x16, #0x0, lsl #48
    c318:      	sub	x3, x16, x25
    c31c:      	sub	x4, x3, #0x1
    c320:      	uxtb	w16, w2
    c324:      	cmp	w16, wzr
    c328:      	b.eq	0xc3d4 <_stogir.vector-arithmetic.operands+0x4d8>
    c32c:      	ldr	x3, [x20, #0x8]
    c330:      	cmp	x25, x3
    c334:      	b.ge	0xc424 <_stogir.vector-arithmetic.operands+0x528>
    c338:      	add	x3, x20, #0x78
    c33c:      	ldr	x3, [x3, #0x8]
    c340:      	cmp	x25, x3
    c344:      	b.ge	0xc4e8 <_stogir.vector-arithmetic.operands+0x5ec>
    c348:      	ldr	x3, [x20, #0x78]
    c34c:      	add	x3, x3, x25, lsl #2
    c350:      	ldr	w3, [x3]
    c354:      	sxtw	x3, w3
    c358:      	cmp	x3, #0x0
    c35c:      	cset	w3, ge
    c360:      	ubfx	x3, x3, #0, #8
    c364:      	b	0xc4ec <_stogir.vector-arithmetic.operands+0x5f0>
    c368:      	cmp	x21, #0x1e
    c36c:      	cset	w2, eq
    c370:      	ubfx	x2, x2, #0, #8
    c374:      	cmp	x2, #0x0
    c378:      	b.eq	0xc290 <_stogir.vector-arithmetic.operands+0x394>
    c37c:      	movz	x2, #0x0, lsl #48
    c380:      	b	0xc294 <_stogir.vector-arithmetic.operands+0x398>
    c384:      	movz	x3, #0x0, lsl #48
    c388:      	uxtb	w3, w3
    c38c:      	and	x3, x3, #0x2
    c390:      	uxtb	w3, w3
    c394:      	cmp	x3, #0x0
    c398:      	cset	w3, eq
    c39c:      	uxtb	w16, w3
    c3a0:      	cmp	w16, wzr
    c3a4:      	cset	x3, eq
    c3a8:      	cmp	x3, #0x0
    c3ac:      	b.ne	0xc3d0 <_stogir.vector-arithmetic.operands+0x4d4>
    c3b0:      	cmp	x2, #0x65
    c3b4:      	b.eq	0xc3d0 <_stogir.vector-arithmetic.operands+0x4d4>
    c3b8:      	cmp	x2, #0x66
    c3bc:      	b.eq	0xc3d0 <_stogir.vector-arithmetic.operands+0x4d4>
    c3c0:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000c3c0:  ARM64_RELOC_PAGE21	l_stogir.487
    c3c4:      	ldr	x16, [x16]
		000000000000c3c4:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    c3c8:      	orr	x0, x16, xzr
    c3cc:      	mov	x1, #0x34               ; =52
    c3d0:      	b	0xc2ac <_stogir.vector-arithmetic.operands+0x3b0>
    c3d4:      	cmp	x25, #0x0
    c3d8:      	b.ge	0xc42c <_stogir.vector-arithmetic.operands+0x530>
    c3dc:      	add	x5, x20, #0x28
    c3e0:      	add	x6, x20, #0x50
    c3e4:      	ldr	x5, [x5, #0x8]
    c3e8:      	ldr	x6, [x6, #0x8]
    c3ec:      	cmp	x5, x6
    c3f0:      	b.ne	0xc4e0 <_stogir.vector-arithmetic.operands+0x5e4>
    c3f4:      	cmp	x3, x5
    c3f8:      	b.gt	0xc4f0 <_stogir.vector-arithmetic.operands+0x5f4>
    c3fc:      	ldr	x3, [x20, #0x50]
    c400:      	add	x3, x3, x4, lsl #2
    c404:      	ldr	w3, [x3]
    c408:      	sxtw	x3, w3
    c40c:      	cmp	x3, #0x0
    c410:      	cset	w3, gt
    c414:      	ubfx	x3, x3, #0, #8
    c418:      	b	0xc4f4 <_stogir.vector-arithmetic.operands+0x5f8>
    c41c:      	brk	#0
    c420:      	b	0xc41c <_stogir.vector-arithmetic.operands+0x520>
    c424:      	movz	x3, #0x0, lsl #48
    c428:      	b	0xc430 <_stogir.vector-arithmetic.operands+0x534>
    c42c:      	movz	x3, #0x0, lsl #48
    c430:      	cmp	x3, #0x0
    c434:      	b.eq	0xc468 <_stogir.vector-arithmetic.operands+0x56c>
    c438:      	uxtb	w16, w2
    c43c:      	cmp	w16, wzr
    c440:      	b.eq	0xc454 <_stogir.vector-arithmetic.operands+0x558>
    c444:      	ldr	x2, [x20]
    c448:      	add	x2, x2, x25, lsl #4
    c44c:      	ldr	x2, [x2]
    c450:      	b	0xc460 <_stogir.vector-arithmetic.operands+0x564>
    c454:      	ldr	x2, [x20, #0x28]
    c458:      	add	x2, x2, x4, lsl #4
    c45c:      	ldr	x2, [x2]
    c460:      	mov	x3, #0x1                ; =1
    c464:      	b	0xc470 <_stogir.vector-arithmetic.operands+0x574>
    c468:      	movz	x3, #0x0, lsl #48
    c46c:      	movz	x2, #0x0, lsl #48
    c470:      	lsr	w3, w3, #0
    c474:      	lsr	x16, x3, #0
    c478:      	cmp	x16, #0x1
    c47c:      	b.eq	0xc498 <_stogir.vector-arithmetic.operands+0x59c>
    c480:      	b.lo	0xc488 <_stogir.vector-arithmetic.operands+0x58c>
    c484:      	b	0xc49c <_stogir.vector-arithmetic.operands+0x5a0>
    c488:      	cmp	x16, #0x0
    c48c:      	b.eq	0xc494 <_stogir.vector-arithmetic.operands+0x598>
    c490:      	b	0xc49c <_stogir.vector-arithmetic.operands+0x5a0>
    c494:      	b	0xc4a0 <_stogir.vector-arithmetic.operands+0x5a4>
    c498:      	b	0xc4b4 <_stogir.vector-arithmetic.operands+0x5b8>
    c49c:      	b	0xc4f8 <_stogir.vector-arithmetic.operands+0x5fc>
    c4a0:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000c4a0:  ARM64_RELOC_PAGE21	l_stogir.488
    c4a4:      	ldr	x16, [x16]
		000000000000c4a4:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    c4a8:      	orr	x0, x16, xzr
    c4ac:      	mov	x1, #0x1d               ; =29
    c4b0:      	b	0xc3d0 <_stogir.vector-arithmetic.operands+0x4d4>
    c4b4:      	cmp	x25, #0x0
    c4b8:      	b.le	0xc3c0 <_stogir.vector-arithmetic.operands+0x4c4>
    c4bc:      	uxtb	w2, w2
    c4c0:      	cmp	x2, #0x83
    c4c4:      	b.ge	0xc384 <_stogir.vector-arithmetic.operands+0x488>
    c4c8:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000c4c8:  ARM64_RELOC_PAGE21	l_stogir.489
    c4cc:      	ldr	x16, [x16]
		000000000000c4cc:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    c4d0:      	orr	x3, x16, xzr
    c4d4:      	add	x3, x2, x3
    c4d8:      	ldrb	w3, [x3]
    c4dc:      	b	0xc388 <_stogir.vector-arithmetic.operands+0x48c>
    c4e0:      	movz	x3, #0x0, lsl #48
    c4e4:      	b	0xc430 <_stogir.vector-arithmetic.operands+0x534>
    c4e8:      	movz	x3, #0x0, lsl #48
    c4ec:      	b	0xc428 <_stogir.vector-arithmetic.operands+0x52c>
    c4f0:      	movz	x3, #0x0, lsl #48
    c4f4:      	b	0xc4e4 <_stogir.vector-arithmetic.operands+0x5e8>
    c4f8:      	brk	#0
    c4fc:      	b	0xc4f8 <_stogir.vector-arithmetic.operands+0x5fc>
    c500:      	str	x4, [sp, #0x20]
    c504:      	str	x5, [sp, #0x28]
    c508:      	b	0xc03c <_stogir.vector-arithmetic.operands+0x140>

000000000000c50c <_stogir.switch.key>:
    c50c:      	sub	sp, sp, #0x30
    c510:      	str	x19, [sp]
    c514:      	str	x20, [sp, #0x8]
    c518:      	str	x21, [sp, #0x10]
    c51c:      	str	x22, [sp, #0x18]
    c520:      	str	x23, [sp, #0x20]
    c524:      	sxtw	x2, w2
    c528:      	cmp	x2, #0x1
    c52c:      	b.lt	0xc5a4 <_stogir.switch.key+0x98>
    c530:      	cmp	x2, #0xb
    c534:      	cset	w3, le
    c538:      	uxtb	w16, w3
    c53c:      	cmp	w16, wzr
    c540:      	b.eq	0xc5a4 <_stogir.switch.key+0x98>
    c544:      	sxtw	x1, w1
    c548:      	cmp	x1, #0x0
    c54c:      	cset	w4, gt
    c550:      	movz	x16, #0x0, lsl #48
    c554:      	sub	x5, x16, x1
    c558:      	sub	x6, x5, #0x1
    c55c:      	uxtb	w16, w4
    c560:      	cmp	w16, wzr
    c564:      	b.eq	0xc620 <_stogir.switch.key+0x114>
    c568:      	ldr	x5, [x0, #0x8]
    c56c:      	cmp	x1, x5
    c570:      	b.ge	0xc668 <_stogir.switch.key+0x15c>
    c574:      	add	x5, x0, #0x78
    c578:      	ldr	x5, [x5, #0x8]
    c57c:      	cmp	x1, x5
    c580:      	b.ge	0xc7a8 <_stogir.switch.key+0x29c>
    c584:      	ldr	x5, [x0, #0x78]
    c588:      	add	x5, x5, x1, lsl #2
    c58c:      	ldr	w5, [x5]
    c590:      	sxtw	x5, w5
    c594:      	cmp	x5, #0x0
    c598:      	cset	w5, ge
    c59c:      	ubfx	x5, x5, #0, #8
    c5a0:      	b	0xc7ac <_stogir.switch.key+0x2a0>
    c5a4:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000c5a4:  ARM64_RELOC_PAGE21	l_stogir.490
    c5a8:      	ldr	x16, [x16]
		000000000000c5a8:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    c5ac:      	orr	x0, x16, xzr
    c5b0:      	mov	x1, #0x1                ; =1
    c5b4:      	mov	x2, #0x24               ; =36
    c5b8:      	str	x1, [x8]
    c5bc:      	str	x0, [x8, #0x8]
    c5c0:      	str	x2, [x8, #0x10]
    c5c4:      	ldr	x19, [sp]
    c5c8:      	ldr	x20, [sp, #0x8]
    c5cc:      	ldr	x21, [sp, #0x10]
    c5d0:      	ldr	x22, [sp, #0x18]
    c5d4:      	ldr	x23, [sp, #0x20]
    c5d8:      	add	sp, sp, #0x30
    c5dc:      	ret
    c5e0:      	mov	x23, #0x1               ; =1
    c5e4:      	cmp	x1, #0x0
    c5e8:      	b.ge	0xc608 <_stogir.switch.key+0xfc>
    c5ec:      	lsr	w1, w4, #0
    c5f0:      	uxtb	w4, w4
    c5f4:      	ubfx	x1, x1, #8, #8
    c5f8:      	cmp	x4, x1
    c5fc:      	b.eq	0xc850 <_stogir.switch.key+0x344>
    c600:      	cmp	x4, #0x49
    c604:      	b.eq	0xc850 <_stogir.switch.key+0x344>
    c608:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000c608:  ARM64_RELOC_PAGE21	l_stogir.491
    c60c:      	ldr	x16, [x16]
		000000000000c60c:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    c610:      	orr	x0, x16, xzr
    c614:      	mov	x1, #0x1                ; =1
    c618:      	mov	x2, #0x30               ; =48
    c61c:      	b	0xc5b8 <_stogir.switch.key+0xac>
    c620:      	cmp	x1, #0x0
    c624:      	b.ge	0xc670 <_stogir.switch.key+0x164>
    c628:      	add	x7, x0, #0x28
    c62c:      	add	x9, x0, #0x50
    c630:      	ldr	x7, [x7, #0x8]
    c634:      	ldr	x9, [x9, #0x8]
    c638:      	cmp	x7, x9
    c63c:      	b.ne	0xc7a0 <_stogir.switch.key+0x294>
    c640:      	cmp	x5, x7
    c644:      	b.gt	0xc848 <_stogir.switch.key+0x33c>
    c648:      	ldr	x5, [x0, #0x50]
    c64c:      	add	x5, x5, x6, lsl #2
    c650:      	ldr	w5, [x5]
    c654:      	sxtw	x5, w5
    c658:      	cmp	x5, #0x0
    c65c:      	cset	w5, gt
    c660:      	ubfx	x5, x5, #0, #8
    c664:      	b	0xc84c <_stogir.switch.key+0x340>
    c668:      	movz	x5, #0x0, lsl #48
    c66c:      	b	0xc674 <_stogir.switch.key+0x168>
    c670:      	movz	x5, #0x0, lsl #48
    c674:      	cmp	x5, #0x0
    c678:      	b.eq	0xc6b4 <_stogir.switch.key+0x1a8>
    c67c:      	uxtb	w16, w4
    c680:      	cmp	w16, wzr
    c684:      	b.eq	0xc69c <_stogir.switch.key+0x190>
    c688:      	ldr	x0, [x0]
    c68c:      	add	x0, x0, x1, lsl #4
    c690:      	ldr	x4, [x0]
    c694:      	ldr	x0, [x0, #0x8]
    c698:      	b	0xc6ac <_stogir.switch.key+0x1a0>
    c69c:      	ldr	x0, [x0, #0x28]
    c6a0:      	add	x0, x0, x6, lsl #4
    c6a4:      	ldr	x4, [x0]
    c6a8:      	ldr	x0, [x0, #0x8]
    c6ac:      	mov	x5, #0x1                ; =1
    c6b0:      	b	0xc6c0 <_stogir.switch.key+0x1b4>
    c6b4:      	movz	x5, #0x0, lsl #48
    c6b8:      	movz	x4, #0x0, lsl #48
    c6bc:      	movz	x0, #0x0, lsl #48
    c6c0:      	lsr	w5, w5, #0
    c6c4:      	lsr	x16, x5, #0
    c6c8:      	cmp	x16, #0x1
    c6cc:      	b.eq	0xc6e8 <_stogir.switch.key+0x1dc>
    c6d0:      	b.lo	0xc6d8 <_stogir.switch.key+0x1cc>
    c6d4:      	b	0xc6ec <_stogir.switch.key+0x1e0>
    c6d8:      	cmp	x16, #0x0
    c6dc:      	b.eq	0xc6e4 <_stogir.switch.key+0x1d8>
    c6e0:      	b	0xc6ec <_stogir.switch.key+0x1e0>
    c6e4:      	b	0xc6f0 <_stogir.switch.key+0x1e4>
    c6e8:      	b	0xc708 <_stogir.switch.key+0x1fc>
    c6ec:      	b	0xc8f0 <_stogir.switch.key+0x3e4>
    c6f0:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000c6f0:  ARM64_RELOC_PAGE21	l_stogir.492
    c6f4:      	ldr	x16, [x16]
		000000000000c6f4:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    c6f8:      	orr	x0, x16, xzr
    c6fc:      	mov	x1, #0x1                ; =1
    c700:      	mov	x2, #0x1c               ; =28
    c704:      	b	0xc61c <_stogir.switch.key+0x110>
    c708:      	cmp	x2, #0x1
    c70c:      	cset	w5, eq
    c710:      	cmp	x2, #0x0
    c714:      	cset	w6, eq
    c718:      	cmp	x2, #0x2
    c71c:      	cset	w7, eq
    c720:      	cmp	x2, #0x7
    c724:      	cset	w9, eq
    c728:      	cmp	x2, #0x8
    c72c:      	cset	w10, eq
    c730:      	cmp	x2, #0x3
    c734:      	cset	w11, eq
    c738:      	cmp	x2, #0x9
    c73c:      	cset	w12, eq
    c740:      	cmp	x2, #0x4
    c744:      	cset	w13, eq
    c748:      	cmp	x2, #0xa
    c74c:      	cset	w14, eq
    c750:      	cmp	x2, #0xd
    c754:      	cset	w15, eq
    c758:      	cmp	x2, #0x5
    c75c:      	cset	w19, eq
    c760:      	cmp	x2, #0xb
    c764:      	cset	w20, eq
    c768:      	cmp	x2, #0xc
    c76c:      	cset	w21, eq
    c770:      	cmp	x2, #0x6
    c774:      	cset	w22, eq
    c778:      	uxtb	w16, w22
    c77c:      	cmp	w16, wzr
    c780:      	mov	x16, #0x8               ; =8
    c784:      	movn	x17, #0x0, lsl #48
    c788:      	csel	x22, x16, x17, ne
    c78c:      	uxtb	w16, w6
    c790:      	cmp	w16, wzr
    c794:      	b.eq	0xc7b0 <_stogir.switch.key+0x2a4>
    c798:      	movz	x23, #0x0, lsl #48
    c79c:      	b	0xc5e4 <_stogir.switch.key+0xd8>
    c7a0:      	movz	x5, #0x0, lsl #48
    c7a4:      	b	0xc674 <_stogir.switch.key+0x168>
    c7a8:      	movz	x5, #0x0, lsl #48
    c7ac:      	b	0xc66c <_stogir.switch.key+0x160>
    c7b0:      	uxtb	w16, w5
    c7b4:      	cmp	w16, wzr
    c7b8:      	b.ne	0xc5e0 <_stogir.switch.key+0xd4>
    c7bc:      	uxtb	w16, w7
    c7c0:      	cmp	w16, wzr
    c7c4:      	b.ne	0xc5e0 <_stogir.switch.key+0xd4>
    c7c8:      	uxtb	w16, w9
    c7cc:      	cmp	w16, wzr
    c7d0:      	b.ne	0xc5e0 <_stogir.switch.key+0xd4>
    c7d4:      	uxtb	w16, w10
    c7d8:      	cmp	w16, wzr
    c7dc:      	b.ne	0xc5e0 <_stogir.switch.key+0xd4>
    c7e0:      	uxtb	w16, w11
    c7e4:      	cmp	w16, wzr
    c7e8:      	b.ne	0xc8e8 <_stogir.switch.key+0x3dc>
    c7ec:      	uxtb	w16, w12
    c7f0:      	cmp	w16, wzr
    c7f4:      	b.ne	0xc8e8 <_stogir.switch.key+0x3dc>
    c7f8:      	uxtb	w16, w13
    c7fc:      	cmp	w16, wzr
    c800:      	b.ne	0xc9c0 <_stogir.switch.key+0x4b4>
    c804:      	uxtb	w16, w14
    c808:      	cmp	w16, wzr
    c80c:      	b.ne	0xc9c0 <_stogir.switch.key+0x4b4>
    c810:      	uxtb	w16, w15
    c814:      	cmp	w16, wzr
    c818:      	b.ne	0xc9c0 <_stogir.switch.key+0x4b4>
    c81c:      	uxtb	w16, w19
    c820:      	cmp	w16, wzr
    c824:      	b.ne	0xc9c8 <_stogir.switch.key+0x4bc>
    c828:      	uxtb	w16, w20
    c82c:      	cmp	w16, wzr
    c830:      	b.ne	0xc9c8 <_stogir.switch.key+0x4bc>
    c834:      	uxtb	w16, w21
    c838:      	cmp	w16, wzr
    c83c:      	b.ne	0xc9c8 <_stogir.switch.key+0x4bc>
    c840:      	mov	x23, x22
    c844:      	b	0xc9cc <_stogir.switch.key+0x4c0>
    c848:      	movz	x5, #0x0, lsl #48
    c84c:      	b	0xc7a4 <_stogir.switch.key+0x298>
    c850:      	cmp	x1, x2
    c854:      	b.ne	0xc608 <_stogir.switch.key+0xfc>
    c858:      	lsr	w23, w23, #0
    c85c:      	lsr	w1, w0, #0
    c860:      	sxtw	x23, w23
    c864:      	ubfx	x1, x1, #0, #32
    c868:      	lsr	x0, x0, #32
    c86c:      	lsl	x4, x23, #3
    c870:      	ubfx	x0, x0, #0, #32
    c874:      	lsr	w4, w4, #0
    c878:      	lsl	x0, x0, #32
    c87c:      	sxtw	x4, w4
    c880:      	orr	x0, x0, x1
    c884:      	cmp	x4, #0x40
    c888:      	b.ge	0xc898 <_stogir.switch.key+0x38c>
    c88c:      	lsr	x1, x0, x4
    c890:      	cmp	x1, #0x0
    c894:      	b.ne	0xc608 <_stogir.switch.key+0xfc>
    c898:      	uxtb	w16, w5
    c89c:      	cmp	w16, wzr
    c8a0:      	b.eq	0xc8ac <_stogir.switch.key+0x3a0>
    c8a4:      	cmp	x0, #0x1
    c8a8:      	b.hi	0xc608 <_stogir.switch.key+0xfc>
    c8ac:      	cmp	x2, #0x7
    c8b0:      	b.lt	0xc8d4 <_stogir.switch.key+0x3c8>
    c8b4:      	uxtb	w16, w3
    c8b8:      	cmp	w16, wzr
    c8bc:      	b.eq	0xc8d4 <_stogir.switch.key+0x3c8>
    c8c0:      	uxtb	w16, w6
    c8c4:      	cmp	w16, wzr
    c8c8:      	b.eq	0xc928 <_stogir.switch.key+0x41c>
    c8cc:      	movz	x22, #0x0, lsl #48
    c8d0:      	b	0xc8fc <_stogir.switch.key+0x3f0>
    c8d4:      	movz	x1, #0x0, lsl #48
    c8d8:      	eor	x0, x1, x0
    c8dc:      	movz	x1, #0x0, lsl #48
    c8e0:      	movz	x2, #0x0, lsl #48
    c8e4:      	b	0xc61c <_stogir.switch.key+0x110>
    c8e8:      	mov	x23, #0x2               ; =2
    c8ec:      	b	0xc5e4 <_stogir.switch.key+0xd8>
    c8f0:      	brk	#0
    c8f4:      	b	0xc8f0 <_stogir.switch.key+0x3e4>
    c8f8:      	mov	x22, #0x1               ; =1
    c8fc:      	lsr	w22, w22, #0
    c900:      	sxtw	x22, w22
    c904:      	lsl	x1, x22, #3
    c908:      	lsr	w1, w1, #0
    c90c:      	sxtw	x1, w1
    c910:      	sub	x1, x1, #0x1
    c914:      	lsr	w1, w1, #0
    c918:      	sxtw	x1, w1
    c91c:      	mov	x16, #0x1               ; =1
    c920:      	lsl	x1, x16, x1
    c924:      	b	0xc8d8 <_stogir.switch.key+0x3cc>
    c928:      	uxtb	w16, w5
    c92c:      	cmp	w16, wzr
    c930:      	b.ne	0xc8f8 <_stogir.switch.key+0x3ec>
    c934:      	uxtb	w16, w7
    c938:      	cmp	w16, wzr
    c93c:      	b.ne	0xc8f8 <_stogir.switch.key+0x3ec>
    c940:      	uxtb	w16, w9
    c944:      	cmp	w16, wzr
    c948:      	b.ne	0xc8f8 <_stogir.switch.key+0x3ec>
    c94c:      	uxtb	w16, w10
    c950:      	cmp	w16, wzr
    c954:      	b.ne	0xc8f8 <_stogir.switch.key+0x3ec>
    c958:      	uxtb	w16, w11
    c95c:      	cmp	w16, wzr
    c960:      	b.ne	0xc9d0 <_stogir.switch.key+0x4c4>
    c964:      	uxtb	w16, w12
    c968:      	cmp	w16, wzr
    c96c:      	b.ne	0xc9d0 <_stogir.switch.key+0x4c4>
    c970:      	uxtb	w16, w13
    c974:      	cmp	w16, wzr
    c978:      	b.ne	0xc9d8 <_stogir.switch.key+0x4cc>
    c97c:      	uxtb	w16, w14
    c980:      	cmp	w16, wzr
    c984:      	b.ne	0xc9d8 <_stogir.switch.key+0x4cc>
    c988:      	uxtb	w16, w15
    c98c:      	cmp	w16, wzr
    c990:      	b.ne	0xc9d8 <_stogir.switch.key+0x4cc>
    c994:      	uxtb	w16, w19
    c998:      	cmp	w16, wzr
    c99c:      	b.ne	0xc9b8 <_stogir.switch.key+0x4ac>
    c9a0:      	uxtb	w16, w20
    c9a4:      	cmp	w16, wzr
    c9a8:      	b.ne	0xc9b8 <_stogir.switch.key+0x4ac>
    c9ac:      	uxtb	w16, w21
    c9b0:      	cmp	w16, wzr
    c9b4:      	b.eq	0xc9bc <_stogir.switch.key+0x4b0>
    c9b8:      	mov	x22, #0x8               ; =8
    c9bc:      	b	0xc9dc <_stogir.switch.key+0x4d0>
    c9c0:      	mov	x23, #0x4               ; =4
    c9c4:      	b	0xc8ec <_stogir.switch.key+0x3e0>
    c9c8:      	mov	x23, #0x8               ; =8
    c9cc:      	b	0xc9c4 <_stogir.switch.key+0x4b8>
    c9d0:      	mov	x22, #0x2               ; =2
    c9d4:      	b	0xc8fc <_stogir.switch.key+0x3f0>
    c9d8:      	mov	x22, #0x4               ; =4
    c9dc:      	b	0xc9d4 <_stogir.switch.key+0x4c8>

000000000000c9e0 <_stogir.stack.constant-size>:
    c9e0:      	sub	sp, sp, #0x10
    c9e4:      	str	x29, [sp]
    c9e8:      	str	x30, [sp, #0x8]
    c9ec:      	mov	x29, sp
    c9f0:      	mov	x2, sp
    c9f4:      	sxtw	x1, w1
    c9f8:      	sub	sp, sp, #0x10
    c9fc:      	mov	x3, sp
    ca00:      	cmp	x1, #0x0
    ca04:      	cset	w4, gt
    ca08:      	movz	x16, #0x0, lsl #48
    ca0c:      	sub	x5, x16, x1
    ca10:      	sub	x6, x5, #0x1
    ca14:      	uxtb	w16, w4
    ca18:      	cmp	w16, wzr
    ca1c:      	b.eq	0xca5c <_stogir.stack.constant-size+0x7c>
    ca20:      	ldr	x5, [x0, #0x8]
    ca24:      	cmp	x1, x5
    ca28:      	b.ge	0xcaac <_stogir.stack.constant-size+0xcc>
    ca2c:      	add	x5, x0, #0x78
    ca30:      	ldr	x5, [x5, #0x8]
    ca34:      	cmp	x1, x5
    ca38:      	b.ge	0xcbf0 <_stogir.stack.constant-size+0x210>
    ca3c:      	ldr	x5, [x0, #0x78]
    ca40:      	add	x5, x5, x1, lsl #2
    ca44:      	ldr	w5, [x5]
    ca48:      	sxtw	x5, w5
    ca4c:      	cmp	x5, #0x0
    ca50:      	cset	w5, ge
    ca54:      	ubfx	x5, x5, #0, #8
    ca58:      	b	0xcbf4 <_stogir.stack.constant-size+0x214>
    ca5c:      	cmp	x1, #0x0
    ca60:      	b.ge	0xcab4 <_stogir.stack.constant-size+0xd4>
    ca64:      	add	x7, x0, #0x28
    ca68:      	add	x9, x0, #0x50
    ca6c:      	ldr	x7, [x7, #0x8]
    ca70:      	ldr	x9, [x9, #0x8]
    ca74:      	cmp	x7, x9
    ca78:      	b.ne	0xcaa4 <_stogir.stack.constant-size+0xc4>
    ca7c:      	cmp	x5, x7
    ca80:      	b.gt	0xcc78 <_stogir.stack.constant-size+0x298>
    ca84:      	ldr	x5, [x0, #0x50]
    ca88:      	add	x5, x5, x6, lsl #2
    ca8c:      	ldr	w5, [x5]
    ca90:      	sxtw	x5, w5
    ca94:      	cmp	x5, #0x0
    ca98:      	cset	w5, gt
    ca9c:      	ubfx	x5, x5, #0, #8
    caa0:      	b	0xcc7c <_stogir.stack.constant-size+0x29c>
    caa4:      	movz	x5, #0x0, lsl #48
    caa8:      	b	0xcab8 <_stogir.stack.constant-size+0xd8>
    caac:      	movz	x5, #0x0, lsl #48
    cab0:      	b	0xcab8 <_stogir.stack.constant-size+0xd8>
    cab4:      	movz	x5, #0x0, lsl #48
    cab8:      	cmp	x5, #0x0
    cabc:      	b.eq	0xcaf8 <_stogir.stack.constant-size+0x118>
    cac0:      	uxtb	w16, w4
    cac4:      	cmp	w16, wzr
    cac8:      	b.eq	0xcae0 <_stogir.stack.constant-size+0x100>
    cacc:      	ldr	x0, [x0]
    cad0:      	add	x0, x0, x1, lsl #4
    cad4:      	ldr	x4, [x0]
    cad8:      	ldr	x0, [x0, #0x8]
    cadc:      	b	0xcaf0 <_stogir.stack.constant-size+0x110>
    cae0:      	ldr	x0, [x0, #0x28]
    cae4:      	add	x0, x0, x6, lsl #4
    cae8:      	ldr	x4, [x0]
    caec:      	ldr	x0, [x0, #0x8]
    caf0:      	mov	x5, #0x1                ; =1
    caf4:      	b	0xcb04 <_stogir.stack.constant-size+0x124>
    caf8:      	movz	x5, #0x0, lsl #48
    cafc:      	movz	x4, #0x0, lsl #48
    cb00:      	movz	x0, #0x0, lsl #48
    cb04:      	lsr	w5, w5, #0
    cb08:      	lsr	x16, x5, #0
    cb0c:      	cmp	x16, #0x1
    cb10:      	b.eq	0xcb2c <_stogir.stack.constant-size+0x14c>
    cb14:      	b.lo	0xcb1c <_stogir.stack.constant-size+0x13c>
    cb18:      	b	0xcb30 <_stogir.stack.constant-size+0x150>
    cb1c:      	cmp	x16, #0x0
    cb20:      	b.eq	0xcb28 <_stogir.stack.constant-size+0x148>
    cb24:      	b	0xcb30 <_stogir.stack.constant-size+0x150>
    cb28:      	b	0xcb34 <_stogir.stack.constant-size+0x154>
    cb2c:      	b	0xcbd0 <_stogir.stack.constant-size+0x1f0>
    cb30:      	b	0xcd2c <_stogir.stack.constant-size+0x34c>
    cb34:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000cb34:  ARM64_RELOC_PAGE21	l_stogir.493
    cb38:      	ldr	x16, [x16]
		000000000000cb38:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    cb3c:      	orr	x0, x16, xzr
    cb40:      	mov	x1, #0x1                ; =1
    cb44:      	mov	x3, #0x18               ; =24
    cb48:      	b	0xcbac <_stogir.stack.constant-size+0x1cc>
    cb4c:      	mov	x4, #0x1                ; =1
    cb50:      	ldr	w5, [x3, #0x8]
    cb54:      	ldr	w6, [x3, #0xc]
    cb58:      	cmp	x1, #0x0
    cb5c:      	b.ge	0xcb98 <_stogir.stack.constant-size+0x1b8>
    cb60:      	cmp	x0, #0x1
    cb64:      	b.lt	0xcb98 <_stogir.stack.constant-size+0x1b8>
    cb68:      	cmp	x0, #0xb
    cb6c:      	cset	w1, le
    cb70:      	uxtb	w16, w1
    cb74:      	cmp	w16, wzr
    cb78:      	b.eq	0xcb98 <_stogir.stack.constant-size+0x1b8>
    cb7c:      	ldr	w3, [x3]
    cb80:      	uxtb	w7, w3
    cb84:      	ubfx	x3, x3, #8, #8
    cb88:      	cmp	x7, x3
    cb8c:      	b.eq	0xcc80 <_stogir.stack.constant-size+0x2a0>
    cb90:      	cmp	x7, #0x49
    cb94:      	b.eq	0xcc80 <_stogir.stack.constant-size+0x2a0>
    cb98:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000cb98:  ARM64_RELOC_PAGE21	l_stogir.494
    cb9c:      	ldr	x16, [x16]
		000000000000cb9c:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    cba0:      	orr	x0, x16, xzr
    cba4:      	mov	x1, #0x1                ; =1
    cba8:      	mov	x3, #0x30               ; =48
    cbac:      	mov	sp, x2
    cbb0:      	str	x1, [x8]
    cbb4:      	str	x0, [x8, #0x8]
    cbb8:      	str	x3, [x8, #0x10]
    cbbc:      	sub	sp, x29, #0x0
    cbc0:      	ldr	x29, [sp]
    cbc4:      	ldr	x30, [sp, #0x8]
    cbc8:      	add	sp, sp, #0x10
    cbcc:      	ret
    cbd0:      	lsr	w5, w4, #0
    cbd4:      	str	x4, [x3]
    cbd8:      	str	x0, [x3, #0x8]
    cbdc:      	ubfx	x0, x5, #8, #8
    cbe0:      	cmp	x0, #0x0
    cbe4:      	b.ne	0xcbf8 <_stogir.stack.constant-size+0x218>
    cbe8:      	movz	x4, #0x0, lsl #48
    cbec:      	b	0xcb50 <_stogir.stack.constant-size+0x170>
    cbf0:      	movz	x5, #0x0, lsl #48
    cbf4:      	b	0xcab0 <_stogir.stack.constant-size+0xd0>
    cbf8:      	cmp	x0, #0x1
    cbfc:      	b.eq	0xcb4c <_stogir.stack.constant-size+0x16c>
    cc00:      	cmp	x0, #0x2
    cc04:      	b.eq	0xcb4c <_stogir.stack.constant-size+0x16c>
    cc08:      	cmp	x0, #0x7
    cc0c:      	b.eq	0xcb4c <_stogir.stack.constant-size+0x16c>
    cc10:      	cmp	x0, #0x8
    cc14:      	b.eq	0xcb4c <_stogir.stack.constant-size+0x16c>
    cc18:      	cmp	x0, #0x3
    cc1c:      	b.eq	0xcd24 <_stogir.stack.constant-size+0x344>
    cc20:      	cmp	x0, #0x9
    cc24:      	b.eq	0xcd24 <_stogir.stack.constant-size+0x344>
    cc28:      	cmp	x0, #0x4
    cc2c:      	b.eq	0xcd34 <_stogir.stack.constant-size+0x354>
    cc30:      	cmp	x0, #0xa
    cc34:      	b.eq	0xcd34 <_stogir.stack.constant-size+0x354>
    cc38:      	cmp	x0, #0xd
    cc3c:      	b.eq	0xcd34 <_stogir.stack.constant-size+0x354>
    cc40:      	cmp	x0, #0x5
    cc44:      	b.eq	0xcd3c <_stogir.stack.constant-size+0x35c>
    cc48:      	cmp	x0, #0xb
    cc4c:      	b.eq	0xcd3c <_stogir.stack.constant-size+0x35c>
    cc50:      	cmp	x0, #0xc
    cc54:      	b.eq	0xcd3c <_stogir.stack.constant-size+0x35c>
    cc58:      	cmp	x0, #0x6
    cc5c:      	cset	w4, eq
    cc60:      	uxtb	w16, w4
    cc64:      	cmp	w16, wzr
    cc68:      	mov	x16, #0x8               ; =8
    cc6c:      	movn	x17, #0x0, lsl #48
    cc70:      	csel	x4, x16, x17, ne
    cc74:      	b	0xcd40 <_stogir.stack.constant-size+0x360>
    cc78:      	movz	x5, #0x0, lsl #48
    cc7c:      	b	0xcaa8 <_stogir.stack.constant-size+0xc8>
    cc80:      	lsr	w4, w4, #0
    cc84:      	sxtw	x4, w4
    cc88:      	cmp	x4, #0x0
    cc8c:      	b.le	0xcb98 <_stogir.stack.constant-size+0x1b8>
    cc90:      	ubfx	x5, x5, #0, #32
    cc94:      	ubfx	x6, x6, #0, #32
    cc98:      	lsl	x3, x6, #32
    cc9c:      	orr	x3, x3, x5
    cca0:      	cmp	x4, #0x8
    cca4:      	b.ge	0xccc0 <_stogir.stack.constant-size+0x2e0>
    cca8:      	lsl	x5, x4, #3
    ccac:      	lsr	w5, w5, #0
    ccb0:      	sxtw	x5, w5
    ccb4:      	lsr	x5, x3, x5
    ccb8:      	cmp	x5, #0x0
    ccbc:      	b.ne	0xcb98 <_stogir.stack.constant-size+0x1b8>
    ccc0:      	cmp	x0, #0x7
    ccc4:      	b.lt	0xcd00 <_stogir.stack.constant-size+0x320>
    ccc8:      	uxtb	w16, w1
    cccc:      	cmp	w16, wzr
    ccd0:      	b.eq	0xcd00 <_stogir.stack.constant-size+0x320>
    ccd4:      	lsl	x0, x4, #3
    ccd8:      	lsr	w0, w0, #0
    ccdc:      	sxtw	x0, w0
    cce0:      	sub	x0, x0, #0x1
    cce4:      	lsr	w0, w0, #0
    cce8:      	sxtw	x0, w0
    ccec:      	mov	x16, #0x1               ; =1
    ccf0:      	lsl	x0, x16, x0
    ccf4:      	and	x0, x0, x3
    ccf8:      	cmp	x0, #0x0
    ccfc:      	b.ne	0xcb98 <_stogir.stack.constant-size+0x1b8>
    cd00:      	mov	x17, #-0x10             ; =-16
    cd04:      	movk	x17, #0x7fff, lsl #48
    cd08:      	cmp	x3, x17
    cd0c:      	b.hi	0xcb98 <_stogir.stack.constant-size+0x1b8>
    cd10:      	add	x0, x3, #0xf
    cd14:      	and	x0, x0, #0xfffffffffffffff0
    cd18:      	movz	x1, #0x0, lsl #48
    cd1c:      	movz	x3, #0x0, lsl #48
    cd20:      	b	0xcbac <_stogir.stack.constant-size+0x1cc>
    cd24:      	mov	x4, #0x2                ; =2
    cd28:      	b	0xcb50 <_stogir.stack.constant-size+0x170>
    cd2c:      	brk	#0
    cd30:      	b	0xcd2c <_stogir.stack.constant-size+0x34c>
    cd34:      	mov	x4, #0x4                ; =4
    cd38:      	b	0xcd28 <_stogir.stack.constant-size+0x348>
    cd3c:      	mov	x4, #0x8                ; =8
    cd40:      	b	0xcd38 <_stogir.stack.constant-size+0x358>

000000000000cd44 <_stogir.stack.constant-size-aligned>:
    cd44:      	sub	sp, sp, #0x10
    cd48:      	cmp	x2, #0x10
    cd4c:      	b.lt	0xcdc8 <_stogir.stack.constant-size-aligned+0x84>
    cd50:      	cmp	x2, #0x0
    cd54:      	b.le	0xcdc8 <_stogir.stack.constant-size-aligned+0x84>
    cd58:      	sub	x3, x2, #0x1
    cd5c:      	and	x3, x3, x2
    cd60:      	cmp	x3, #0x0
    cd64:      	b.ne	0xcdc8 <_stogir.stack.constant-size-aligned+0x84>
    cd68:      	sxtw	x1, w1
    cd6c:      	cmp	x1, #0x0
    cd70:      	cset	w3, gt
    cd74:      	movz	x16, #0x0, lsl #48
    cd78:      	sub	x4, x16, x1
    cd7c:      	sub	x5, x4, #0x1
    cd80:      	uxtb	w16, w3
    cd84:      	cmp	w16, wzr
    cd88:      	b.eq	0xce60 <_stogir.stack.constant-size-aligned+0x11c>
    cd8c:      	ldr	x4, [x0, #0x8]
    cd90:      	cmp	x1, x4
    cd94:      	b.ge	0xcea8 <_stogir.stack.constant-size-aligned+0x164>
    cd98:      	add	x4, x0, #0x78
    cd9c:      	ldr	x4, [x4, #0x8]
    cda0:      	cmp	x1, x4
    cda4:      	b.ge	0xcf78 <_stogir.stack.constant-size-aligned+0x234>
    cda8:      	ldr	x4, [x0, #0x78]
    cdac:      	add	x4, x4, x1, lsl #2
    cdb0:      	ldr	w4, [x4]
    cdb4:      	sxtw	x4, w4
    cdb8:      	cmp	x4, #0x0
    cdbc:      	cset	w4, ge
    cdc0:      	ubfx	x4, x4, #0, #8
    cdc4:      	b	0xcf7c <_stogir.stack.constant-size-aligned+0x238>
    cdc8:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000cdc8:  ARM64_RELOC_PAGE21	l_stogir.495
    cdcc:      	ldr	x16, [x16]
		000000000000cdcc:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    cdd0:      	orr	x0, x16, xzr
    cdd4:      	mov	x1, #0x1                ; =1
    cdd8:      	mov	x2, #0x20               ; =32
    cddc:      	str	x1, [x8]
    cde0:      	str	x0, [x8, #0x8]
    cde4:      	str	x2, [x8, #0x10]
    cde8:      	add	sp, sp, #0x10
    cdec:      	ret
    cdf0:      	mov	x3, #0x1                ; =1
    cdf4:      	mov	x16, sp
    cdf8:      	ldr	w4, [x16, #0x8]
    cdfc:      	mov	x16, sp
    ce00:      	ldr	w5, [x16, #0xc]
    ce04:      	cmp	x1, #0x0
    ce08:      	b.ge	0xce48 <_stogir.stack.constant-size-aligned+0x104>
    ce0c:      	cmp	x0, #0x1
    ce10:      	b.lt	0xce48 <_stogir.stack.constant-size-aligned+0x104>
    ce14:      	cmp	x0, #0xb
    ce18:      	cset	w1, le
    ce1c:      	uxtb	w16, w1
    ce20:      	cmp	w16, wzr
    ce24:      	b.eq	0xce48 <_stogir.stack.constant-size-aligned+0x104>
    ce28:      	mov	x16, sp
    ce2c:      	ldr	w6, [x16]
    ce30:      	uxtb	w7, w6
    ce34:      	ubfx	x6, x6, #8, #8
    ce38:      	cmp	x7, x6
    ce3c:      	b.eq	0xd008 <_stogir.stack.constant-size-aligned+0x2c4>
    ce40:      	cmp	x7, #0x49
    ce44:      	b.eq	0xd008 <_stogir.stack.constant-size-aligned+0x2c4>
    ce48:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000ce48:  ARM64_RELOC_PAGE21	l_stogir.496
    ce4c:      	ldr	x16, [x16]
		000000000000ce4c:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    ce50:      	orr	x0, x16, xzr
    ce54:      	mov	x1, #0x1                ; =1
    ce58:      	mov	x2, #0x30               ; =48
    ce5c:      	b	0xcddc <_stogir.stack.constant-size-aligned+0x98>
    ce60:      	cmp	x1, #0x0
    ce64:      	b.ge	0xceb0 <_stogir.stack.constant-size-aligned+0x16c>
    ce68:      	add	x6, x0, #0x28
    ce6c:      	add	x7, x0, #0x50
    ce70:      	ldr	x6, [x6, #0x8]
    ce74:      	ldr	x7, [x7, #0x8]
    ce78:      	cmp	x6, x7
    ce7c:      	b.ne	0xcf70 <_stogir.stack.constant-size-aligned+0x22c>
    ce80:      	cmp	x4, x6
    ce84:      	b.gt	0xd000 <_stogir.stack.constant-size-aligned+0x2bc>
    ce88:      	ldr	x4, [x0, #0x50]
    ce8c:      	add	x4, x4, x5, lsl #2
    ce90:      	ldr	w4, [x4]
    ce94:      	sxtw	x4, w4
    ce98:      	cmp	x4, #0x0
    ce9c:      	cset	w4, gt
    cea0:      	ubfx	x4, x4, #0, #8
    cea4:      	b	0xd004 <_stogir.stack.constant-size-aligned+0x2c0>
    cea8:      	movz	x4, #0x0, lsl #48
    ceac:      	b	0xceb4 <_stogir.stack.constant-size-aligned+0x170>
    ceb0:      	movz	x4, #0x0, lsl #48
    ceb4:      	cmp	x4, #0x0
    ceb8:      	b.eq	0xcef4 <_stogir.stack.constant-size-aligned+0x1b0>
    cebc:      	uxtb	w16, w3
    cec0:      	cmp	w16, wzr
    cec4:      	b.eq	0xcedc <_stogir.stack.constant-size-aligned+0x198>
    cec8:      	ldr	x0, [x0]
    cecc:      	add	x0, x0, x1, lsl #4
    ced0:      	ldr	x3, [x0]
    ced4:      	ldr	x0, [x0, #0x8]
    ced8:      	b	0xceec <_stogir.stack.constant-size-aligned+0x1a8>
    cedc:      	ldr	x0, [x0, #0x28]
    cee0:      	add	x0, x0, x5, lsl #4
    cee4:      	ldr	x3, [x0]
    cee8:      	ldr	x0, [x0, #0x8]
    ceec:      	mov	x4, #0x1                ; =1
    cef0:      	b	0xcf00 <_stogir.stack.constant-size-aligned+0x1bc>
    cef4:      	movz	x4, #0x0, lsl #48
    cef8:      	movz	x3, #0x0, lsl #48
    cefc:      	movz	x0, #0x0, lsl #48
    cf00:      	lsr	w4, w4, #0
    cf04:      	lsr	x16, x4, #0
    cf08:      	cmp	x16, #0x1
    cf0c:      	b.eq	0xcf28 <_stogir.stack.constant-size-aligned+0x1e4>
    cf10:      	b.lo	0xcf18 <_stogir.stack.constant-size-aligned+0x1d4>
    cf14:      	b	0xcf2c <_stogir.stack.constant-size-aligned+0x1e8>
    cf18:      	cmp	x16, #0x0
    cf1c:      	b.eq	0xcf24 <_stogir.stack.constant-size-aligned+0x1e0>
    cf20:      	b	0xcf2c <_stogir.stack.constant-size-aligned+0x1e8>
    cf24:      	b	0xcf30 <_stogir.stack.constant-size-aligned+0x1ec>
    cf28:      	b	0xcf48 <_stogir.stack.constant-size-aligned+0x204>
    cf2c:      	b	0xd0c4 <_stogir.stack.constant-size-aligned+0x380>
    cf30:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x104>
		000000000000cf30:  ARM64_RELOC_PAGE21	l_stogir.497
    cf34:      	ldr	x16, [x16]
		000000000000cf34:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    cf38:      	orr	x0, x16, xzr
    cf3c:      	mov	x1, #0x1                ; =1
    cf40:      	mov	x2, #0x18               ; =24
    cf44:      	b	0xce5c <_stogir.stack.constant-size-aligned+0x118>
    cf48:      	lsr	w4, w3, #0
    cf4c:      	mov	x16, sp
    cf50:      	str	x3, [x16]
    cf54:      	mov	x16, sp
    cf58:      	str	x0, [x16, #0x8]
    cf5c:      	ubfx	x0, x4, #8, #8
    cf60:      	cmp	x0, #0x0
    cf64:      	b.ne	0xcf80 <_stogir.stack.constant-size-aligned+0x23c>
    cf68:      	movz	x3, #0x0, lsl #48
    cf6c:      	b	0xcdf4 <_stogir.stack.constant-size-aligned+0xb0>
    cf70:      	movz	x4, #0x0, lsl #48
    cf74:      	b	0xceb4 <_stogir.stack.constant-size-aligned+0x170>
    cf78:      	movz	x4, #0x0, lsl #48
    cf7c:      	b	0xceac <_stogir.stack.constant-size-aligned+0x168>
    cf80:      	cmp	x0, #0x1
    cf84:      	b.eq	0xcdf0 <_stogir.stack.constant-size-aligned+0xac>
    cf88:      	cmp	x0, #0x2
    cf8c:      	b.eq	0xcdf0 <_stogir.stack.constant-size-aligned+0xac>
    cf90:      	cmp	x0, #0x7
    cf94:      	b.eq	0xcdf0 <_stogir.stack.constant-size-aligned+0xac>
    cf98:      	cmp	x0, #0x8
    cf9c:      	b.eq	0xcdf0 <_stogir.stack.constant-size-aligned+0xac>
    cfa0:      	cmp	x0, #0x3
    cfa4:      	b.eq	0xd0bc <_stogir.stack.constant-size-aligned+0x378>
    cfa8:      	cmp	x0, #0x9
    cfac:      	b.eq	0xd0bc <_stogir.stack.constant-size-aligned+0x378>
    cfb0:      	cmp	x0, #0x4
    cfb4:      	b.eq	0xd0cc <_stogir.stack.constant-size-aligned+0x388>
    cfb8:      	cmp	x0, #0xa
    cfbc:      	b.eq	0xd0cc <_stogir.stack.constant-size-aligned+0x388>
    cfc0:      	cmp	x0, #0xd
    cfc4:      	b.eq	0xd0cc <_stogir.stack.constant-size-aligned+0x388>
    cfc8:      	cmp	x0, #0x5
    cfcc:      	b.eq	0xd0d4 <_stogir.stack.constant-size-aligned+0x390>
    cfd0:      	cmp	x0, #0xb
    cfd4:      	b.eq	0xd0d4 <_stogir.stack.constant-size-aligned+0x390>
    cfd8:      	cmp	x0, #0xc
    cfdc:      	b.eq	0xd0d4 <_stogir.stack.constant-size-aligned+0x390>
    cfe0:      	cmp	x0, #0x6
    cfe4:      	cset	w3, eq
    cfe8:      	uxtb	w16, w3
    cfec:      	cmp	w16, wzr
    cff0:      	mov	x16, #0x8               ; =8
    cff4:      	movn	x17, #0x0, lsl #48
    cff8:      	csel	x3, x16, x17, ne
    cffc:      	b	0xd0d8 <_stogir.stack.constant-size-aligned+0x394>
    d000:      	movz	x4, #0x0, lsl #48
    d004:      	b	0xcf74 <_stogir.stack.constant-size-aligned+0x230>
    d008:      	lsr	w3, w3, #0
    d00c:      	sxtw	x3, w3
    d010:      	cmp	x3, #0x0
    d014:      	b.le	0xce48 <_stogir.stack.constant-size-aligned+0x104>
    d018:      	ubfx	x4, x4, #0, #32
    d01c:      	ubfx	x5, x5, #0, #32
    d020:      	lsl	x5, x5, #32
    d024:      	orr	x4, x5, x4
    d028:      	cmp	x3, #0x8
    d02c:      	b.ge	0xd048 <_stogir.stack.constant-size-aligned+0x304>
    d030:      	lsl	x5, x3, #3
    d034:      	lsr	w5, w5, #0
    d038:      	sxtw	x5, w5
    d03c:      	lsr	x5, x4, x5
    d040:      	cmp	x5, #0x0
    d044:      	b.ne	0xce48 <_stogir.stack.constant-size-aligned+0x104>
    d048:      	cmp	x0, #0x7
    d04c:      	b.lt	0xd088 <_stogir.stack.constant-size-aligned+0x344>
    d050:      	uxtb	w16, w1
    d054:      	cmp	w16, wzr
    d058:      	b.eq	0xd088 <_stogir.stack.constant-size-aligned+0x344>
    d05c:      	lsl	x0, x3, #3
    d060:      	lsr	w0, w0, #0
    d064:      	sxtw	x0, w0
    d068:      	sub	x0, x0, #0x1
    d06c:      	lsr	w0, w0, #0
    d070:      	sxtw	x0, w0
    d074:      	mov	x16, #0x1               ; =1
    d078:      	lsl	x0, x16, x0
    d07c:      	and	x0, x0, x4
    d080:      	cmp	x0, #0x0
    d084:      	b.ne	0xce48 <_stogir.stack.constant-size-aligned+0x104>
    d088:      	sub	x0, x2, #0x1
    d08c:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    d090:      	sub	x0, x16, x0
    d094:      	cmp	x4, x0
    d098:      	b.hi	0xce48 <_stogir.stack.constant-size-aligned+0x104>
    d09c:      	sub	x0, x2, #0x1
    d0a0:      	movz	x16, #0x0, lsl #48
    d0a4:      	sub	x1, x16, x2
    d0a8:      	add	x0, x0, x4
    d0ac:      	and	x0, x1, x0
    d0b0:      	movz	x1, #0x0, lsl #48
    d0b4:      	movz	x2, #0x0, lsl #48
    d0b8:      	b	0xce5c <_stogir.stack.constant-size-aligned+0x118>
    d0bc:      	mov	x3, #0x2                ; =2
    d0c0:      	b	0xcdf4 <_stogir.stack.constant-size-aligned+0xb0>
    d0c4:      	brk	#0
    d0c8:      	b	0xd0c4 <_stogir.stack.constant-size-aligned+0x380>
    d0cc:      	mov	x3, #0x4                ; =4
    d0d0:      	b	0xd0c0 <_stogir.stack.constant-size-aligned+0x37c>
    d0d4:      	mov	x3, #0x8                ; =8
    d0d8:      	b	0xd0d0 <_stogir.stack.constant-size-aligned+0x38c>

000000000000d0dc <_stogir.vector-lanes.compatible?>:
    d0dc:      	sxtw	x0, w0
    d0e0:      	and	x3, x0, #0xf
    d0e4:      	cmp	x0, #0xf
    d0e8:      	cset	w4, gt
    d0ec:      	cmp	x0, #0x80
    d0f0:      	cset	w5, lt
    d0f4:      	lsr	w3, w3, #0
    d0f8:      	sxtw	x3, w3
    d0fc:      	cmp	x3, #0x1
    d100:      	cset	w6, ge
    d104:      	cmp	x3, #0xd
    d108:      	cset	w7, le
    d10c:      	cmp	x0, #0x0
    d110:      	b.lt	0xd11c <_stogir.vector-lanes.compatible?+0x40>
    d114:      	cmp	x0, #0xd
    d118:      	b.le	0xd150 <_stogir.vector-lanes.compatible?+0x74>
    d11c:      	uxtb	w16, w4
    d120:      	cmp	w16, wzr
    d124:      	b.eq	0xd14c <_stogir.vector-lanes.compatible?+0x70>
    d128:      	uxtb	w16, w5
    d12c:      	cmp	w16, wzr
    d130:      	b.eq	0xd14c <_stogir.vector-lanes.compatible?+0x70>
    d134:      	uxtb	w16, w6
    d138:      	cmp	w16, wzr
    d13c:      	b.eq	0xd14c <_stogir.vector-lanes.compatible?+0x70>
    d140:      	uxtb	w16, w7
    d144:      	cmp	w16, wzr
    d148:      	b.ne	0xd150 <_stogir.vector-lanes.compatible?+0x74>
    d14c:      	movn	x3, #0x0, lsl #48
    d150:      	uxtb	w16, w4
    d154:      	cmp	w16, wzr
    d158:      	b.eq	0xd1b4 <_stogir.vector-lanes.compatible?+0xd8>
    d15c:      	uxtb	w16, w5
    d160:      	cmp	w16, wzr
    d164:      	b.eq	0xd1b4 <_stogir.vector-lanes.compatible?+0xd8>
    d168:      	uxtb	w16, w6
    d16c:      	cmp	w16, wzr
    d170:      	b.eq	0xd1b4 <_stogir.vector-lanes.compatible?+0xd8>
    d174:      	uxtb	w16, w7
    d178:      	cmp	w16, wzr
    d17c:      	b.eq	0xd1b4 <_stogir.vector-lanes.compatible?+0xd8>
    d180:      	sxtw	x2, w2
    d184:      	cmp	x2, #0x4
    d188:      	cset	w0, eq
    d18c:      	cmp	x2, #0x8
    d190:      	cset	w4, eq
    d194:      	uxtb	w16, w0
    d198:      	cmp	w16, wzr
    d19c:      	b.ne	0xd1c4 <_stogir.vector-lanes.compatible?+0xe8>
    d1a0:      	uxtb	w16, w4
    d1a4:      	cmp	w16, wzr
    d1a8:      	b.ne	0xd1c4 <_stogir.vector-lanes.compatible?+0xe8>
    d1ac:      	movz	x0, #0x0, lsl #48
    d1b0:      	b	0xd1c0 <_stogir.vector-lanes.compatible?+0xe4>
    d1b4:      	movz	x0, #0x0, lsl #48
    d1b8:      	ret
    d1bc:      	movz	x0, #0x0, lsl #48
    d1c0:      	b	0xd1b8 <_stogir.vector-lanes.compatible?+0xdc>
    d1c4:      	sxtw	x1, w1
    d1c8:      	cmp	x1, #0x0
    d1cc:      	b.lt	0xd1bc <_stogir.vector-lanes.compatible?+0xe0>
    d1d0:      	cmp	x1, #0xd
    d1d4:      	b.gt	0xd1bc <_stogir.vector-lanes.compatible?+0xe0>
    d1d8:      	cmp	x1, #0x0
    d1dc:      	b.le	0xd1f8 <_stogir.vector-lanes.compatible?+0x11c>
    d1e0:      	lsr	w3, w3, #0
    d1e4:      	sxtw	x3, w3
    d1e8:      	cmp	x3, x1
    d1ec:      	b.ne	0xd200 <_stogir.vector-lanes.compatible?+0x124>
    d1f0:      	mov	x0, #0x1                ; =1
    d1f4:      	b	0xd1fc <_stogir.vector-lanes.compatible?+0x120>
    d1f8:      	movz	x0, #0x0, lsl #48
    d1fc:      	b	0xd1c0 <_stogir.vector-lanes.compatible?+0xe4>
    d200:      	cmp	x3, #0x1
    d204:      	b.lt	0xd240 <_stogir.vector-lanes.compatible?+0x164>
    d208:      	cmp	x3, #0xb
    d20c:      	b.gt	0xd240 <_stogir.vector-lanes.compatible?+0x164>
    d210:      	cmp	x1, #0x1
    d214:      	b.lt	0xd248 <_stogir.vector-lanes.compatible?+0x16c>
    d218:      	cmp	x1, #0xb
    d21c:      	b.gt	0xd248 <_stogir.vector-lanes.compatible?+0x16c>
    d220:      	uxtb	w16, w0
    d224:      	cmp	w16, wzr
    d228:      	b.ne	0xd274 <_stogir.vector-lanes.compatible?+0x198>
    d22c:      	uxtb	w16, w4
    d230:      	cmp	w16, wzr
    d234:      	b.ne	0xd274 <_stogir.vector-lanes.compatible?+0x198>
    d238:      	movn	x3, #0x0, lsl #48
    d23c:      	b	0xd288 <_stogir.vector-lanes.compatible?+0x1ac>
    d240:      	movz	x0, #0x0, lsl #48
    d244:      	b	0xd1f4 <_stogir.vector-lanes.compatible?+0x118>
    d248:      	movz	x0, #0x0, lsl #48
    d24c:      	b	0xd244 <_stogir.vector-lanes.compatible?+0x168>
    d250:      	mov	x2, #0x1                ; =1
    d254:      	lsr	w3, w3, #0
    d258:      	sxtw	x3, w3
    d25c:      	lsr	w2, w2, #0
    d260:      	sxtw	x2, w2
    d264:      	cmp	x3, x2
    d268:      	cset	w0, eq
    d26c:      	ubfx	x0, x0, #0, #8
    d270:      	b	0xd24c <_stogir.vector-lanes.compatible?+0x170>
    d274:      	cmp	x3, #0x0
    d278:      	b.ne	0xd328 <_stogir.vector-lanes.compatible?+0x24c>
    d27c:      	movz	x3, #0x0, lsl #48
    d280:      	b	0xd288 <_stogir.vector-lanes.compatible?+0x1ac>
    d284:      	mov	x3, #0x1                ; =1
    d288:      	uxtb	w16, w0
    d28c:      	cmp	w16, wzr
    d290:      	b.ne	0xd2a8 <_stogir.vector-lanes.compatible?+0x1cc>
    d294:      	uxtb	w16, w4
    d298:      	cmp	w16, wzr
    d29c:      	b.ne	0xd2a8 <_stogir.vector-lanes.compatible?+0x1cc>
    d2a0:      	movn	x2, #0x0, lsl #48
    d2a4:      	b	0xd254 <_stogir.vector-lanes.compatible?+0x178>
    d2a8:      	cmp	x1, #0x0
    d2ac:      	b.ne	0xd2b8 <_stogir.vector-lanes.compatible?+0x1dc>
    d2b0:      	movz	x2, #0x0, lsl #48
    d2b4:      	b	0xd254 <_stogir.vector-lanes.compatible?+0x178>
    d2b8:      	cmp	x1, #0x1
    d2bc:      	b.eq	0xd250 <_stogir.vector-lanes.compatible?+0x174>
    d2c0:      	cmp	x1, #0x2
    d2c4:      	b.eq	0xd250 <_stogir.vector-lanes.compatible?+0x174>
    d2c8:      	cmp	x1, #0x7
    d2cc:      	b.eq	0xd250 <_stogir.vector-lanes.compatible?+0x174>
    d2d0:      	cmp	x1, #0x8
    d2d4:      	b.eq	0xd250 <_stogir.vector-lanes.compatible?+0x174>
    d2d8:      	cmp	x1, #0x3
    d2dc:      	b.eq	0xd398 <_stogir.vector-lanes.compatible?+0x2bc>
    d2e0:      	cmp	x1, #0x9
    d2e4:      	b.eq	0xd398 <_stogir.vector-lanes.compatible?+0x2bc>
    d2e8:      	cmp	x1, #0x4
    d2ec:      	b.eq	0xd3a8 <_stogir.vector-lanes.compatible?+0x2cc>
    d2f0:      	cmp	x1, #0xa
    d2f4:      	b.eq	0xd3a8 <_stogir.vector-lanes.compatible?+0x2cc>
    d2f8:      	cmp	x1, #0xd
    d2fc:      	b.eq	0xd3a8 <_stogir.vector-lanes.compatible?+0x2cc>
    d300:      	cmp	x1, #0x5
    d304:      	b.eq	0xd3b8 <_stogir.vector-lanes.compatible?+0x2dc>
    d308:      	cmp	x1, #0xb
    d30c:      	b.eq	0xd3b8 <_stogir.vector-lanes.compatible?+0x2dc>
    d310:      	cmp	x1, #0xc
    d314:      	b.eq	0xd3b8 <_stogir.vector-lanes.compatible?+0x2dc>
    d318:      	cmp	x1, #0x6
    d31c:      	b.eq	0xd324 <_stogir.vector-lanes.compatible?+0x248>
    d320:      	movn	x2, #0x0, lsl #48
    d324:      	b	0xd3bc <_stogir.vector-lanes.compatible?+0x2e0>
    d328:      	cmp	x3, #0x1
    d32c:      	b.eq	0xd284 <_stogir.vector-lanes.compatible?+0x1a8>
    d330:      	cmp	x3, #0x2
    d334:      	b.eq	0xd284 <_stogir.vector-lanes.compatible?+0x1a8>
    d338:      	cmp	x3, #0x7
    d33c:      	b.eq	0xd284 <_stogir.vector-lanes.compatible?+0x1a8>
    d340:      	cmp	x3, #0x8
    d344:      	b.eq	0xd284 <_stogir.vector-lanes.compatible?+0x1a8>
    d348:      	cmp	x3, #0x3
    d34c:      	b.eq	0xd3a0 <_stogir.vector-lanes.compatible?+0x2c4>
    d350:      	cmp	x3, #0x9
    d354:      	b.eq	0xd3a0 <_stogir.vector-lanes.compatible?+0x2c4>
    d358:      	cmp	x3, #0x4
    d35c:      	b.eq	0xd3b0 <_stogir.vector-lanes.compatible?+0x2d4>
    d360:      	cmp	x3, #0xa
    d364:      	b.eq	0xd3b0 <_stogir.vector-lanes.compatible?+0x2d4>
    d368:      	cmp	x3, #0xd
    d36c:      	b.eq	0xd3b0 <_stogir.vector-lanes.compatible?+0x2d4>
    d370:      	cmp	x3, #0x5
    d374:      	b.eq	0xd3c0 <_stogir.vector-lanes.compatible?+0x2e4>
    d378:      	cmp	x3, #0xb
    d37c:      	b.eq	0xd3c0 <_stogir.vector-lanes.compatible?+0x2e4>
    d380:      	cmp	x3, #0xc
    d384:      	b.eq	0xd3c0 <_stogir.vector-lanes.compatible?+0x2e4>
    d388:      	cmp	x3, #0x6
    d38c:      	b.ne	0xd3c8 <_stogir.vector-lanes.compatible?+0x2ec>
    d390:      	mov	x3, x2
    d394:      	b	0xd3cc <_stogir.vector-lanes.compatible?+0x2f0>
    d398:      	mov	x2, #0x2                ; =2
    d39c:      	b	0xd254 <_stogir.vector-lanes.compatible?+0x178>
    d3a0:      	mov	x3, #0x2                ; =2
    d3a4:      	b	0xd288 <_stogir.vector-lanes.compatible?+0x1ac>
    d3a8:      	mov	x2, #0x4                ; =4
    d3ac:      	b	0xd39c <_stogir.vector-lanes.compatible?+0x2c0>
    d3b0:      	mov	x3, #0x4                ; =4
    d3b4:      	b	0xd3a4 <_stogir.vector-lanes.compatible?+0x2c8>
    d3b8:      	mov	x2, #0x8                ; =8
    d3bc:      	b	0xd3ac <_stogir.vector-lanes.compatible?+0x2d0>
    d3c0:      	mov	x3, #0x8                ; =8
    d3c4:      	b	0xd3b4 <_stogir.vector-lanes.compatible?+0x2d8>
    d3c8:      	movn	x3, #0x0, lsl #48
    d3cc:      	b	0xd3c4 <_stogir.vector-lanes.compatible?+0x2e8>

000000000000d3d0 <_stogir.vector-comparison.valid-type?>:
    d3d0:      	sxtw	x0, w0
    d3d4:      	cmp	x0, #0xe
    d3d8:      	b.lt	0xd474 <_stogir.vector-comparison.valid-type?+0xa4>
    d3dc:      	cmp	x0, #0x19
    d3e0:      	b.gt	0xd474 <_stogir.vector-comparison.valid-type?+0xa4>
    d3e4:      	sxtw	x1, w1
    d3e8:      	cmp	x1, #0xf
    d3ec:      	cset	w2, gt
    d3f0:      	uxtb	w16, w2
    d3f4:      	cmp	w16, wzr
    d3f8:      	b.eq	0xd47c <_stogir.vector-comparison.valid-type?+0xac>
    d3fc:      	cmp	x1, #0x80
    d400:      	cset	w3, lt
    d404:      	uxtb	w16, w3
    d408:      	cmp	w16, wzr
    d40c:      	b.eq	0xd47c <_stogir.vector-comparison.valid-type?+0xac>
    d410:      	and	x4, x1, #0xf
    d414:      	lsr	w4, w4, #0
    d418:      	sxtw	x4, w4
    d41c:      	cmp	x4, #0x1
    d420:      	cset	w5, ge
    d424:      	uxtb	w16, w5
    d428:      	cmp	w16, wzr
    d42c:      	b.eq	0xd47c <_stogir.vector-comparison.valid-type?+0xac>
    d430:      	cmp	x4, #0xd
    d434:      	cset	w6, le
    d438:      	uxtb	w16, w6
    d43c:      	cmp	w16, wzr
    d440:      	b.eq	0xd47c <_stogir.vector-comparison.valid-type?+0xac>
    d444:      	cmp	x1, #0x0
    d448:      	cset	w7, ge
    d44c:      	cmp	x1, #0xd
    d450:      	cset	w1, le
    d454:      	uxtb	w16, w7
    d458:      	cmp	w16, wzr
    d45c:      	b.eq	0xd48c <_stogir.vector-comparison.valid-type?+0xbc>
    d460:      	uxtb	w16, w1
    d464:      	cmp	w16, wzr
    d468:      	b.eq	0xd48c <_stogir.vector-comparison.valid-type?+0xbc>
    d46c:      	mov	x8, x4
    d470:      	b	0xd4c0 <_stogir.vector-comparison.valid-type?+0xf0>
    d474:      	movz	x0, #0x0, lsl #48
    d478:      	ret
    d47c:      	movz	x0, #0x0, lsl #48
    d480:      	b	0xd478 <_stogir.vector-comparison.valid-type?+0xa8>
    d484:      	mov	x0, #0x1                ; =1
    d488:      	b	0xd480 <_stogir.vector-comparison.valid-type?+0xb0>
    d48c:      	uxtb	w16, w2
    d490:      	cmp	w16, wzr
    d494:      	b.eq	0xd4bc <_stogir.vector-comparison.valid-type?+0xec>
    d498:      	uxtb	w16, w3
    d49c:      	cmp	w16, wzr
    d4a0:      	b.eq	0xd4bc <_stogir.vector-comparison.valid-type?+0xec>
    d4a4:      	uxtb	w16, w5
    d4a8:      	cmp	w16, wzr
    d4ac:      	b.eq	0xd4bc <_stogir.vector-comparison.valid-type?+0xec>
    d4b0:      	uxtb	w16, w6
    d4b4:      	cmp	w16, wzr
    d4b8:      	b.ne	0xd46c <_stogir.vector-comparison.valid-type?+0x9c>
    d4bc:      	movn	x8, #0x0, lsl #48
    d4c0:      	lsr	w8, w8, #0
    d4c4:      	sxtw	x8, w8
    d4c8:      	cmp	x8, #0xc
    d4cc:      	b.eq	0xd484 <_stogir.vector-comparison.valid-type?+0xb4>
    d4d0:      	cmp	x8, #0xd
    d4d4:      	b.eq	0xd484 <_stogir.vector-comparison.valid-type?+0xb4>
    d4d8:      	uxtb	w16, w7
    d4dc:      	cmp	w16, wzr
    d4e0:      	b.eq	0xd4f0 <_stogir.vector-comparison.valid-type?+0x120>
    d4e4:      	uxtb	w16, w1
    d4e8:      	cmp	w16, wzr
    d4ec:      	b.ne	0xd524 <_stogir.vector-comparison.valid-type?+0x154>
    d4f0:      	uxtb	w16, w2
    d4f4:      	cmp	w16, wzr
    d4f8:      	b.eq	0xd520 <_stogir.vector-comparison.valid-type?+0x150>
    d4fc:      	uxtb	w16, w3
    d500:      	cmp	w16, wzr
    d504:      	b.eq	0xd520 <_stogir.vector-comparison.valid-type?+0x150>
    d508:      	uxtb	w16, w5
    d50c:      	cmp	w16, wzr
    d510:      	b.eq	0xd520 <_stogir.vector-comparison.valid-type?+0x150>
    d514:      	uxtb	w16, w6
    d518:      	cmp	w16, wzr
    d51c:      	b.ne	0xd524 <_stogir.vector-comparison.valid-type?+0x154>
    d520:      	movn	x4, #0x0, lsl #48
    d524:      	lsr	w4, w4, #0
    d528:      	sxtw	x4, w4
    d52c:      	cmp	x4, #0x1
    d530:      	b.lt	0xd54c <_stogir.vector-comparison.valid-type?+0x17c>
    d534:      	cmp	x4, #0xb
    d538:      	b.gt	0xd54c <_stogir.vector-comparison.valid-type?+0x17c>
    d53c:      	cmp	x0, #0x17
    d540:      	cset	w0, le
    d544:      	ubfx	x0, x0, #0, #8
    d548:      	b	0xd550 <_stogir.vector-comparison.valid-type?+0x180>
    d54c:      	movz	x0, #0x0, lsl #48
    d550:      	b	0xd488 <_stogir.vector-comparison.valid-type?+0xb8>

000000000000d554 <_stogir.vector-arithmetic.valid-type?>:
    d554:      	sub	sp, sp, #0x30
    d558:      	str	x29, [sp]
    d55c:      	str	x30, [sp, #0x8]
    d560:      	mov	x29, sp
    d564:      	str	x19, [sp, #0x10]
    d568:      	str	x20, [sp, #0x18]
    d56c:      	str	x21, [sp, #0x20]
    d570:      	str	x22, [sp, #0x28]
    d574:      	sxtw	x1, w1
    d578:      	cmp	x1, #0xf
    d57c:      	cset	w2, gt
    d580:      	cmp	x1, #0x80
    d584:      	cset	w3, lt
    d588:      	and	x4, x1, #0xf
    d58c:      	lsr	w4, w4, #0
    d590:      	sxtw	x4, w4
    d594:      	cmp	x4, #0x1
    d598:      	cset	w5, ge
    d59c:      	cmp	x4, #0xd
    d5a0:      	cset	w6, le
    d5a4:      	cmp	x1, #0x0
    d5a8:      	b.lt	0xd5b4 <_stogir.vector-arithmetic.valid-type?+0x60>
    d5ac:      	cmp	x1, #0xd
    d5b0:      	b.le	0xd5e8 <_stogir.vector-arithmetic.valid-type?+0x94>
    d5b4:      	uxtb	w16, w2
    d5b8:      	cmp	w16, wzr
    d5bc:      	b.eq	0xd5e4 <_stogir.vector-arithmetic.valid-type?+0x90>
    d5c0:      	uxtb	w16, w3
    d5c4:      	cmp	w16, wzr
    d5c8:      	b.eq	0xd5e4 <_stogir.vector-arithmetic.valid-type?+0x90>
    d5cc:      	uxtb	w16, w5
    d5d0:      	cmp	w16, wzr
    d5d4:      	b.eq	0xd5e4 <_stogir.vector-arithmetic.valid-type?+0x90>
    d5d8:      	uxtb	w16, w6
    d5dc:      	cmp	w16, wzr
    d5e0:      	b.ne	0xd5e8 <_stogir.vector-arithmetic.valid-type?+0x94>
    d5e4:      	movn	x4, #0x0, lsl #48
    d5e8:      	uxtb	w16, w2
    d5ec:      	cmp	w16, wzr
    d5f0:      	b.eq	0xd7dc <_stogir.vector-arithmetic.valid-type?+0x288>
    d5f4:      	uxtb	w16, w3
    d5f8:      	cmp	w16, wzr
    d5fc:      	b.eq	0xd7dc <_stogir.vector-arithmetic.valid-type?+0x288>
    d600:      	uxtb	w16, w5
    d604:      	cmp	w16, wzr
    d608:      	b.eq	0xd7dc <_stogir.vector-arithmetic.valid-type?+0x288>
    d60c:      	uxtb	w16, w6
    d610:      	cmp	w16, wzr
    d614:      	b.eq	0xd7dc <_stogir.vector-arithmetic.valid-type?+0x288>
    d618:      	sxtw	x1, w0
    d61c:      	cmp	x1, #0x1f
    d620:      	cset	w19, eq
    d624:      	cmp	x1, #0x20
    d628:      	cset	w20, eq
    d62c:      	cmp	x1, #0x2e
    d630:      	cset	w2, eq
    d634:      	cmp	x1, #0x2f
    d638:      	cset	w3, eq
    d63c:      	cmp	x1, #0x30
    d640:      	cset	w5, eq
    d644:      	cmp	x1, #0x1e
    d648:      	cset	w6, eq
    d64c:      	cmp	x1, #0x31
    d650:      	cset	w7, ge
    d654:      	cmp	x1, #0x35
    d658:      	cset	w8, le
    d65c:      	cmp	x1, #0x3a
    d660:      	cset	w9, eq
    d664:      	cmp	x1, #0x3b
    d668:      	cset	w10, eq
    d66c:      	cmp	x1, #0x2d
    d670:      	cset	w11, eq
    d674:      	cmp	x1, #0x36
    d678:      	cset	w12, eq
    d67c:      	cmp	x1, #0x37
    d680:      	cset	w13, eq
    d684:      	cmp	x1, #0x38
    d688:      	cset	w14, eq
    d68c:      	cmp	x1, #0x39
    d690:      	cset	w15, eq
    d694:      	uxtb	w16, w19
    d698:      	cmp	w16, wzr
    d69c:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d6a0:      	uxtb	w16, w20
    d6a4:      	cmp	w16, wzr
    d6a8:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d6ac:      	uxtb	w16, w11
    d6b0:      	cmp	w16, wzr
    d6b4:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d6b8:      	uxtb	w16, w12
    d6bc:      	cmp	w16, wzr
    d6c0:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d6c4:      	uxtb	w16, w13
    d6c8:      	cmp	w16, wzr
    d6cc:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d6d0:      	uxtb	w16, w14
    d6d4:      	cmp	w16, wzr
    d6d8:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d6dc:      	uxtb	w16, w15
    d6e0:      	cmp	w16, wzr
    d6e4:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d6e8:      	uxtb	w16, w9
    d6ec:      	cmp	w16, wzr
    d6f0:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d6f4:      	uxtb	w16, w10
    d6f8:      	cmp	w16, wzr
    d6fc:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d700:      	uxtb	w16, w7
    d704:      	cmp	w16, wzr
    d708:      	b.eq	0xd8f4 <_stogir.vector-arithmetic.valid-type?+0x3a0>
    d70c:      	uxtb	w16, w8
    d710:      	cmp	w16, wzr
    d714:      	b.eq	0xd8f4 <_stogir.vector-arithmetic.valid-type?+0x3a0>
    d718:      	lsr	w4, w4, #0
    d71c:      	sxtw	x1, w4
    d720:      	cmp	x1, #0xc
    d724:      	cset	w21, eq
    d728:      	cmp	x1, #0xd
    d72c:      	cset	w22, eq
    d730:      	uxtb	w16, w19
    d734:      	cmp	w16, wzr
    d738:      	b.ne	0xd808 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d73c:      	uxtb	w16, w20
    d740:      	cmp	w16, wzr
    d744:      	b.ne	0xd808 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d748:      	uxtb	w16, w11
    d74c:      	cmp	w16, wzr
    d750:      	b.ne	0xd808 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d754:      	uxtb	w16, w12
    d758:      	cmp	w16, wzr
    d75c:      	b.ne	0xd808 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d760:      	uxtb	w16, w13
    d764:      	cmp	w16, wzr
    d768:      	b.ne	0xd808 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d76c:      	uxtb	w16, w14
    d770:      	cmp	w16, wzr
    d774:      	b.ne	0xd808 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d778:      	uxtb	w16, w15
    d77c:      	cmp	w16, wzr
    d780:      	b.ne	0xd808 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d784:      	cmp	x1, #0x1
    d788:      	cset	w0, eq
    d78c:      	cmp	x1, #0x1
    d790:      	cset	w4, ge
    d794:      	cmp	x1, #0xb
    d798:      	cset	w1, le
    d79c:      	uxtb	w16, w7
    d7a0:      	cmp	w16, wzr
    d7a4:      	b.eq	0xd864 <_stogir.vector-arithmetic.valid-type?+0x310>
    d7a8:      	uxtb	w16, w8
    d7ac:      	cmp	w16, wzr
    d7b0:      	b.eq	0xd864 <_stogir.vector-arithmetic.valid-type?+0x310>
    d7b4:      	uxtb	w16, w4
    d7b8:      	cmp	w16, wzr
    d7bc:      	b.eq	0xd8ec <_stogir.vector-arithmetic.valid-type?+0x398>
    d7c0:      	uxtb	w16, w1
    d7c4:      	cmp	w16, wzr
    d7c8:      	b.eq	0xd8ec <_stogir.vector-arithmetic.valid-type?+0x398>
    d7cc:      	uxtb	w16, w0
    d7d0:      	cmp	w16, wzr
    d7d4:      	cset	x0, eq
    d7d8:      	b	0xd8f0 <_stogir.vector-arithmetic.valid-type?+0x39c>
    d7dc:      	movz	x0, #0x0, lsl #48
    d7e0:      	ldr	x19, [sp, #0x10]
    d7e4:      	ldr	x20, [sp, #0x18]
    d7e8:      	ldr	x21, [sp, #0x20]
    d7ec:      	ldr	x22, [sp, #0x28]
    d7f0:      	ldr	x29, [sp]
    d7f4:      	ldr	x30, [sp, #0x8]
    d7f8:      	add	sp, sp, #0x30
    d7fc:      	ret
    d800:      	ubfx	x0, x20, #0, #8
    d804:      	b	0xd7e0 <_stogir.vector-arithmetic.valid-type?+0x28c>
    d808:      	lsr	w0, w0, #0
    d80c:      	lsr	w4, w4, #0
    d810:      	mov	w1, w4
    d814:      	bl	0xd814 <_stogir.vector-arithmetic.valid-type?+0x2c0>
		000000000000d814:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    d818:      	cmp	x0, #0x0
    d81c:      	b.eq	0xd828 <_stogir.vector-arithmetic.valid-type?+0x2d4>
    d820:      	mov	x0, #0x1                ; =1
    d824:      	b	0xd804 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d828:      	uxtb	w16, w21
    d82c:      	cmp	w16, wzr
    d830:      	b.ne	0xd848 <_stogir.vector-arithmetic.valid-type?+0x2f4>
    d834:      	uxtb	w16, w22
    d838:      	cmp	w16, wzr
    d83c:      	b.ne	0xd848 <_stogir.vector-arithmetic.valid-type?+0x2f4>
    d840:      	movz	x0, #0x0, lsl #48
    d844:      	b	0xd804 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d848:      	uxtb	w16, w19
    d84c:      	cmp	w16, wzr
    d850:      	b.eq	0xd800 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d854:      	mov	x0, #0x1                ; =1
    d858:      	b	0xd804 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d85c:      	movz	x0, #0x0, lsl #48
    d860:      	b	0xd804 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d864:      	uxtb	w16, w2
    d868:      	cmp	w16, wzr
    d86c:      	b.ne	0xd8d8 <_stogir.vector-arithmetic.valid-type?+0x384>
    d870:      	uxtb	w16, w3
    d874:      	cmp	w16, wzr
    d878:      	b.ne	0xd8d8 <_stogir.vector-arithmetic.valid-type?+0x384>
    d87c:      	uxtb	w16, w5
    d880:      	cmp	w16, wzr
    d884:      	b.ne	0xd8d8 <_stogir.vector-arithmetic.valid-type?+0x384>
    d888:      	uxtb	w16, w21
    d88c:      	cmp	w16, wzr
    d890:      	b.ne	0xd94c <_stogir.vector-arithmetic.valid-type?+0x3f8>
    d894:      	uxtb	w16, w22
    d898:      	cmp	w16, wzr
    d89c:      	b.ne	0xd94c <_stogir.vector-arithmetic.valid-type?+0x3f8>
    d8a0:      	uxtb	w16, w4
    d8a4:      	cmp	w16, wzr
    d8a8:      	b.eq	0xd95c <_stogir.vector-arithmetic.valid-type?+0x408>
    d8ac:      	uxtb	w16, w1
    d8b0:      	cmp	w16, wzr
    d8b4:      	b.eq	0xd95c <_stogir.vector-arithmetic.valid-type?+0x408>
    d8b8:      	uxtb	w16, w0
    d8bc:      	cmp	w16, wzr
    d8c0:      	b.eq	0xd964 <_stogir.vector-arithmetic.valid-type?+0x410>
    d8c4:      	uxtb	w16, w9
    d8c8:      	cmp	w16, wzr
    d8cc:      	b.eq	0xd96c <_stogir.vector-arithmetic.valid-type?+0x418>
    d8d0:      	mov	x0, #0x1                ; =1
    d8d4:      	b	0xd970 <_stogir.vector-arithmetic.valid-type?+0x41c>
    d8d8:      	uxtb	w16, w4
    d8dc:      	cmp	w16, wzr
    d8e0:      	b.eq	0xd85c <_stogir.vector-arithmetic.valid-type?+0x308>
    d8e4:      	ubfx	x0, x1, #0, #8
    d8e8:      	b	0xd860 <_stogir.vector-arithmetic.valid-type?+0x30c>
    d8ec:      	movz	x0, #0x0, lsl #48
    d8f0:      	b	0xd860 <_stogir.vector-arithmetic.valid-type?+0x30c>
    d8f4:      	cmp	x1, #0x1a
    d8f8:      	b.eq	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d8fc:      	cmp	x1, #0x1b
    d900:      	b.eq	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d904:      	cmp	x1, #0x1c
    d908:      	b.eq	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d90c:      	cmp	x1, #0x1d
    d910:      	b.eq	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d914:      	uxtb	w16, w6
    d918:      	cmp	w16, wzr
    d91c:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d920:      	uxtb	w16, w2
    d924:      	cmp	w16, wzr
    d928:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d92c:      	uxtb	w16, w3
    d930:      	cmp	w16, wzr
    d934:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d938:      	uxtb	w16, w5
    d93c:      	cmp	w16, wzr
    d940:      	b.ne	0xd718 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d944:      	movz	x0, #0x0, lsl #48
    d948:      	b	0xd804 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d94c:      	uxtb	w16, w6
    d950:      	cmp	w16, wzr
    d954:      	cset	x0, eq
    d958:      	b	0xd860 <_stogir.vector-arithmetic.valid-type?+0x30c>
    d95c:      	movz	x0, #0x0, lsl #48
    d960:      	b	0xd958 <_stogir.vector-arithmetic.valid-type?+0x404>
    d964:      	mov	x0, #0x1                ; =1
    d968:      	b	0xd960 <_stogir.vector-arithmetic.valid-type?+0x40c>
    d96c:      	ubfx	x0, x10, #0, #8
    d970:      	b	0xd968 <_stogir.vector-arithmetic.valid-type?+0x414>
