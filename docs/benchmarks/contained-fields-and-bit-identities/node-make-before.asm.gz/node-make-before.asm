
build/contained-field-comparison/emitter/stogir-before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000039fc <_stogir.node.make>:
    39fc: d10043ff     	sub	sp, sp, #0x10
    3a00: 53001c00     	uxtb	w0, w0
    3a04: 53001c21     	uxtb	w1, w1
    3a08: 53003c42     	uxth	w2, w2
    3a0c: 910003f0     	mov	x16, sp
    3a10: d2e00011     	movz	x17, #0x0, lsl #48
    3a14: f9000211     	str	x17, [x16]
    3a18: 53185c21     	lsl	w1, w1, #8
    3a1c: 53103c42     	lsl	w2, w2, #16
    3a20: 910003f0     	mov	x16, sp
    3a24: d2e00011     	movz	x17, #0x0, lsl #48
    3a28: f9000611     	str	x17, [x16, #0x8]
    3a2c: 2a000020     	orr	w0, w1, w0
    3a30: 2a000040     	orr	w0, w2, w0
    3a34: 910003f0     	mov	x16, sp
    3a38: b9000200     	str	w0, [x16]
    3a3c: 910003f0     	mov	x16, sp
    3a40: b9000603     	str	w3, [x16, #0x4]
    3a44: 910003f0     	mov	x16, sp
    3a48: b9000a04     	str	w4, [x16, #0x8]
    3a4c: 910003f0     	mov	x16, sp
    3a50: b9000e05     	str	w5, [x16, #0xc]
    3a54: 910003f0     	mov	x16, sp
    3a58: f9400200     	ldr	x0, [x16]
    3a5c: 910003f0     	mov	x16, sp
    3a60: f9400601     	ldr	x1, [x16, #0x8]
    3a64: 910043ff     	add	sp, sp, #0x10
    3a68: d65f03c0     	ret
