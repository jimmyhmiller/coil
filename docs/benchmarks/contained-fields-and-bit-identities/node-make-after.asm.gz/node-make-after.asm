
build/contained-field-comparison/emitter/stogir-after.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000039f4 <_stogir.node.make>:
    39f4: 53001c00     	uxtb	w0, w0
    39f8: 53001c21     	uxtb	w1, w1
    39fc: 53003c42     	uxth	w2, w2
    3a00: d3407c63     	ubfx	x3, x3, #0, #32
    3a04: d3407c84     	ubfx	x4, x4, #0, #32
    3a08: d3407ca5     	ubfx	x5, x5, #0, #32
    3a0c: 53185c21     	lsl	w1, w1, #8
    3a10: 53103c42     	lsl	w2, w2, #16
    3a14: d3607c63     	lsl	x3, x3, #32
    3a18: d3607ca5     	lsl	x5, x5, #32
    3a1c: 2a000020     	orr	w0, w1, w0
    3a20: aa050081     	orr	x1, x4, x5
    3a24: 2a000040     	orr	w0, w2, w0
    3a28: d3407c00     	ubfx	x0, x0, #0, #32
    3a2c: aa030000     	orr	x0, x0, x3
    3a30: d65f03c0     	ret
