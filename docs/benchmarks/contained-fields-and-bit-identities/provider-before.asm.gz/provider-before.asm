
build/contained-field-comparison/providers/stogir-before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000000a140 <_coil.compiler.resolve.primitive-providers-in>:
    a140: d10483ff     	sub	sp, sp, #0x120
    a144: f90003fd     	str	x29, [sp]
    a148: f90007fe     	str	x30, [sp, #0x8]
    a14c: 910003fd     	mov	x29, sp
    a150: f90067f3     	str	x19, [sp, #0xc8]
    a154: f9006bf4     	str	x20, [sp, #0xd0]
    a158: f9006ff5     	str	x21, [sp, #0xd8]
    a15c: f90073f6     	str	x22, [sp, #0xe0]
    a160: f90077f7     	str	x23, [sp, #0xe8]
    a164: f9007bf8     	str	x24, [sp, #0xf0]
    a168: f9007ff9     	str	x25, [sp, #0xf8]
    a16c: f90083fa     	str	x26, [sp, #0x100]
    a170: f90087fb     	str	x27, [sp, #0x108]
    a174: f9008bfc     	str	x28, [sp, #0x110]
    a178: 910103f0     	add	x16, sp, #0x40
    a17c: aa1f0207     	orr	x7, x16, xzr
    a180: f9400009     	ldr	x9, [x0]
    a184: 910020f3     	add	x19, x7, #0x8
    a188: f9400400     	ldr	x0, [x0, #0x8]
    a18c: 910043f0     	add	x16, sp, #0x10
    a190: d2e00011     	movz	x17, #0x0, lsl #48
    a194: f9000211     	str	x17, [x16]
    a198: 910043f0     	add	x16, sp, #0x10
    a19c: d2e00011     	movz	x17, #0x0, lsl #48
    a1a0: f9000611     	str	x17, [x16, #0x8]
    a1a4: 910043f0     	add	x16, sp, #0x10
    a1a8: d2e00011     	movz	x17, #0x0, lsl #48
    a1ac: f9000a11     	str	x17, [x16, #0x10]
    a1b0: 910043f0     	add	x16, sp, #0x10
    a1b4: f9000e09     	str	x9, [x16, #0x18]
    a1b8: 910043f0     	add	x16, sp, #0x10
    a1bc: f9001200     	str	x0, [x16, #0x20]
    a1c0: 910043e0     	add	x0, sp, #0x10
    a1c4: f90063e8     	str	x8, [sp, #0xc0]
    a1c8: aa0103f5     	mov	x21, x1
    a1cc: aa0203f6     	mov	x22, x2
    a1d0: aa0303f7     	mov	x23, x3
    a1d4: aa0403f8     	mov	x24, x4
    a1d8: aa0503f9     	mov	x25, x5
    a1dc: aa0603fa     	mov	x26, x6
    a1e0: d2800041     	mov	x1, #0x2                ; =2
    a1e4: 94000000     	bl	0xa1e4 <_coil.compiler.resolve.primitive-providers-in+0xa4>
    a1e8: 910043f0     	add	x16, sp, #0x10
    a1ec: f9400200     	ldr	x0, [x16]
    a1f0: f9000017     	str	x23, [x0]
    a1f4: f9000418     	str	x24, [x0, #0x8]
    a1f8: f9000819     	str	x25, [x0, #0x10]
    a1fc: f9000c1a     	str	x26, [x0, #0x18]
    a200: 910043f0     	add	x16, sp, #0x10
    a204: d2800031     	mov	x17, #0x1               ; =1
    a208: f9000611     	str	x17, [x16, #0x8]
    a20c: d2e00017     	movz	x23, #0x0, lsl #48
    a210: 140000db     	b	0xa57c <_coil.compiler.resolve.primitive-providers-in+0x43c>
    a214: d1000400     	sub	x0, x0, #0x1
    a218: 9345fc00     	asr	x0, x0, #5
    a21c: d37be800     	lsl	x0, x0, #5
    a220: eb00039f     	cmp	x28, x0
    a224: 5400006b     	b.lt	0xa230 <_coil.compiler.resolve.primitive-providers-in+0xf0>
    a228: f94006a0     	ldr	x0, [x21, #0x8]
    a22c: 1400001a     	b	0xa294 <_coil.compiler.resolve.primitive-providers-in+0x154>
    a230: f94002a0     	ldr	x0, [x21]
    a234: f9400ea1     	ldr	x1, [x21, #0x18]
    a238: 14000015     	b	0xa28c <_coil.compiler.resolve.primitive-providers-in+0x14c>
    a23c: d37ff800     	lsl	x0, x0, #1
    a240: aa0003e1     	mov	x1, x0
    a244: 910043e0     	add	x0, sp, #0x10
    a248: 94000000     	bl	0xa248 <_coil.compiler.resolve.primitive-providers-in+0x108>
    a24c: 91000680     	add	x0, x20, #0x1
    a250: 910043f0     	add	x16, sp, #0x10
    a254: f9400201     	ldr	x1, [x16]
    a258: 8b141421     	add	x1, x1, x20, lsl #5
    a25c: f900003b     	str	x27, [x1]
    a260: f900043c     	str	x28, [x1, #0x8]
    a264: f9000833     	str	x19, [x1, #0x10]
    a268: f9000c3a     	str	x26, [x1, #0x18]
    a26c: 910043f0     	add	x16, sp, #0x10
    a270: f9000600     	str	x0, [x16, #0x8]
    a274: 14000026     	b	0xa30c <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    a278: 9ac12b82     	asr	x2, x28, x1
    a27c: d1001421     	sub	x1, x1, #0x5
    a280: 92401042     	and	x2, x2, #0x1f
    a284: f9401000     	ldr	x0, [x0, #0x20]
    a288: f8627800     	ldr	x0, [x0, x2, lsl #3]
    a28c: f100003f     	cmp	x1, #0x0
    a290: 54ffff4c     	b.gt	0xa278 <_coil.compiler.resolve.primitive-providers-in+0x138>
    a294: 92401381     	and	x1, x28, #0x1f
    a298: d2801e11     	mov	x17, #0xf0              ; =240
    a29c: 9b117c21     	mul	x1, x1, x17
    a2a0: f9400c00     	ldr	x0, [x0, #0x18]
    a2a4: 8b000022     	add	x2, x1, x0
    a2a8: 91004043     	add	x3, x2, #0x10
    a2ac: 91014064     	add	x4, x3, #0x50
    a2b0: f9005ffc     	str	x28, [sp, #0xb8]
    a2b4: 92e00005     	movn	x5, #0x0, lsl #48
    a2b8: 14000020     	b	0xa338 <_coil.compiler.resolve.primitive-providers-in+0x1f8>
    a2bc: d503201f     	nop
    a2c0: d340fce7     	lsr	x7, x7, #0
    a2c4: aa0103f6     	mov	x22, x1
    a2c8: aa1803e1     	mov	x1, x24
    a2cc: aa0203f9     	mov	x25, x2
    a2d0: aa0703e2     	mov	x2, x7
    a2d4: f9003fe3     	str	x3, [sp, #0x78]
    a2d8: f90043e4     	str	x4, [sp, #0x80]
    a2dc: f90047e5     	str	x5, [sp, #0x88]
    a2e0: f9004be9     	str	x9, [sp, #0x90]
    a2e4: f90037f8     	str	x24, [sp, #0x68]
    a2e8: aa0003f8     	mov	x24, x0
    a2ec: aa0603e0     	mov	x0, x6
    a2f0: 94000000     	bl	0xa2f0 <_coil.compiler.resolve.primitive-providers-in+0x1b0>
    a2f4: 93407c00     	sxtw	x0, w0
    a2f8: f100001f     	cmp	x0, #0x0
    a2fc: 540004e0     	b.eq	0xa398 <_coil.compiler.resolve.primitive-providers-in+0x258>
    a300: f90053fa     	str	x26, [sp, #0xa0]
    a304: f9005bfb     	str	x27, [sp, #0xb0]
    a308: f9004ff3     	str	x19, [sp, #0x98]
    a30c: f94053fa     	ldr	x26, [sp, #0xa0]
    a310: f9405bfb     	ldr	x27, [sp, #0xb0]
    a314: f9403fe3     	ldr	x3, [sp, #0x78]
    a318: f94043e4     	ldr	x4, [sp, #0x80]
    a31c: f9404ff3     	ldr	x19, [sp, #0x98]
    a320: aa1803e0     	mov	x0, x24
    a324: f94037f8     	ldr	x24, [sp, #0x68]
    a328: aa1603e1     	mov	x1, x22
    a32c: aa1903e2     	mov	x2, x25
    a330: f9403bf9     	ldr	x25, [sp, #0x70]
    a334: f94047e5     	ldr	x5, [sp, #0x88]
    a338: f9400486     	ldr	x6, [x4, #0x8]
    a33c: 910004a5     	add	x5, x5, #0x1
    a340: eb0600bf     	cmp	x5, x6
    a344: 540018ea     	b.ge	0xa660 <_coil.compiler.resolve.primitive-providers-in+0x520>
    a348: d2800611     	mov	x17, #0x30              ; =48
    a34c: 9b117ca6     	mul	x6, x5, x17
    a350: f9402867     	ldr	x7, [x3, #0x50]
    a354: 8b0700c8     	add	x8, x6, x7
    a358: aa1f0109     	orr	x9, x8, xzr
    a35c: f86768c6     	ldr	x6, [x6, x7]
    a360: f9400507     	ldr	x7, [x8, #0x8]
    a364: eb1900ff     	cmp	x7, x25
    a368: 54001881     	b.ne	0xa678 <_coil.compiler.resolve.primitive-providers-in+0x538>
    a36c: f10000ff     	cmp	x7, #0x0
    a370: 540019c1     	b.ne	0xa6a8 <_coil.compiler.resolve.primitive-providers-in+0x568>
    a374: f9003bf9     	str	x25, [sp, #0x70]
    a378: f9003fe3     	str	x3, [sp, #0x78]
    a37c: f90043e4     	str	x4, [sp, #0x80]
    a380: f90047e5     	str	x5, [sp, #0x88]
    a384: f9004be9     	str	x9, [sp, #0x90]
    a388: f90037f8     	str	x24, [sp, #0x68]
    a38c: aa0003f8     	mov	x24, x0
    a390: aa0103f6     	mov	x22, x1
    a394: aa0203f9     	mov	x25, x2
    a398: 910103e8     	add	x8, sp, #0x40
    a39c: f9404be0     	ldr	x0, [sp, #0x90]
    a3a0: aa1a03e1     	mov	x1, x26
    a3a4: aa1b03e2     	mov	x2, x27
    a3a8: 94000000     	bl	0xa3a8 <_coil.compiler.resolve.primitive-providers-in+0x268>
    a3ac: 910103f0     	add	x16, sp, #0x40
    a3b0: b9400200     	ldr	w0, [x16]
    a3b4: d340fc10     	lsr	x16, x0, #0
    a3b8: f100061f     	cmp	x16, #0x1
    a3bc: 54000140     	b.eq	0xa3e4 <_coil.compiler.resolve.primitive-providers-in+0x2a4>
    a3c0: 54000043     	b.lo	0xa3c8 <_coil.compiler.resolve.primitive-providers-in+0x288>
    a3c4: 14000009     	b	0xa3e8 <_coil.compiler.resolve.primitive-providers-in+0x2a8>
    a3c8: f100021f     	cmp	x16, #0x0
    a3cc: 54000040     	b.eq	0xa3d4 <_coil.compiler.resolve.primitive-providers-in+0x294>
    a3d0: 14000006     	b	0xa3e8 <_coil.compiler.resolve.primitive-providers-in+0x2a8>
    a3d4: f90053fa     	str	x26, [sp, #0xa0]
    a3d8: f9005bfb     	str	x27, [sp, #0xb0]
    a3dc: f9004ff3     	str	x19, [sp, #0x98]
    a3e0: 17ffffcb     	b	0xa30c <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    a3e4: 14000002     	b	0xa3ec <_coil.compiler.resolve.primitive-providers-in+0x2ac>
    a3e8: 14000080     	b	0xa5e8 <_coil.compiler.resolve.primitive-providers-in+0x4a8>
    a3ec: 910103f0     	add	x16, sp, #0x40
    a3f0: f9400600     	ldr	x0, [x16, #0x8]
    a3f4: f9400661     	ldr	x1, [x19, #0x8]
    a3f8: f9004ff3     	str	x19, [sp, #0x98]
    a3fc: f90053fa     	str	x26, [sp, #0xa0]
    a400: f9005bfb     	str	x27, [sp, #0xb0]
    a404: 92e00002     	movn	x2, #0x0, lsl #48
    a408: d2e00003     	movz	x3, #0x0, lsl #48
    a40c: 14000006     	b	0xa424 <_coil.compiler.resolve.primitive-providers-in+0x2e4>
    a410: d280003b     	mov	x27, #0x1               ; =1
    a414: aa1303e0     	mov	x0, x19
    a418: aa1a03e1     	mov	x1, x26
    a41c: f94057e2     	ldr	x2, [sp, #0xa8]
    a420: aa1b03e3     	mov	x3, x27
    a424: 910043f0     	add	x16, sp, #0x10
    a428: f9400604     	ldr	x4, [x16, #0x8]
    a42c: 91000442     	add	x2, x2, #0x1
    a430: eb04005f     	cmp	x2, x4
    a434: 540013ea     	b.ge	0xa6b0 <_coil.compiler.resolve.primitive-providers-in+0x570>
    a438: 910043f0     	add	x16, sp, #0x10
    a43c: f9400204     	ldr	x4, [x16]
    a440: 8b021484     	add	x4, x4, x2, lsl #5
    a444: f9400085     	ldr	x5, [x4]
    a448: f9400486     	ldr	x6, [x4, #0x8]
    a44c: f9400887     	ldr	x7, [x4, #0x10]
    a450: f9400c84     	ldr	x4, [x4, #0x18]
    a454: f8786ac8     	ldr	x8, [x22, x24]
    a458: f9400729     	ldr	x9, [x25, #0x8]
    a45c: eb0900df     	cmp	x6, x9
    a460: 54001301     	b.ne	0xa6c0 <_coil.compiler.resolve.primitive-providers-in+0x580>
    a464: f10000df     	cmp	x6, #0x0
    a468: 54000281     	b.ne	0xa4b8 <_coil.compiler.resolve.primitive-providers-in+0x378>
    a46c: aa0303fb     	mov	x27, x3
    a470: aa0003f3     	mov	x19, x0
    a474: aa0103fa     	mov	x26, x1
    a478: f90057e2     	str	x2, [sp, #0xa8]
    a47c: aa0703fc     	mov	x28, x7
    a480: aa0403f4     	mov	x20, x4
    a484: eb1a029f     	cmp	x20, x26
    a488: 54fffc61     	b.ne	0xa414 <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    a48c: f100029f     	cmp	x20, #0x0
    a490: 54fffc00     	b.eq	0xa410 <_coil.compiler.resolve.primitive-providers-in+0x2d0>
    a494: d340fe80     	lsr	x0, x20, #0
    a498: aa1303e1     	mov	x1, x19
    a49c: aa0003e2     	mov	x2, x0
    a4a0: aa1c03e0     	mov	x0, x28
    a4a4: 94000000     	bl	0xa4a4 <_coil.compiler.resolve.primitive-providers-in+0x364>
    a4a8: 93407c00     	sxtw	x0, w0
    a4ac: f100001f     	cmp	x0, #0x0
    a4b0: 54fffb00     	b.eq	0xa410 <_coil.compiler.resolve.primitive-providers-in+0x2d0>
    a4b4: 17ffffd8     	b	0xa414 <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    a4b8: d340fcc6     	lsr	x6, x6, #0
    a4bc: aa0003f3     	mov	x19, x0
    a4c0: aa0503e0     	mov	x0, x5
    a4c4: aa0103fa     	mov	x26, x1
    a4c8: aa0803e1     	mov	x1, x8
    a4cc: f90057e2     	str	x2, [sp, #0xa8]
    a4d0: aa0603e2     	mov	x2, x6
    a4d4: aa0303fb     	mov	x27, x3
    a4d8: aa0703fc     	mov	x28, x7
    a4dc: aa0403f4     	mov	x20, x4
    a4e0: 94000000     	bl	0xa4e0 <_coil.compiler.resolve.primitive-providers-in+0x3a0>
    a4e4: 93407c00     	sxtw	x0, w0
    a4e8: f100001f     	cmp	x0, #0x0
    a4ec: 54fffcc0     	b.eq	0xa484 <_coil.compiler.resolve.primitive-providers-in+0x344>
    a4f0: 17ffffc9     	b	0xa414 <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    a4f4: f100037f     	cmp	x27, #0x0
    a4f8: 54fff0a1     	b.ne	0xa30c <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    a4fc: aa1f0094     	orr	x20, x4, xzr
    a500: f8786adb     	ldr	x27, [x22, x24]
    a504: f940073c     	ldr	x28, [x25, #0x8]
    a508: 910043f0     	add	x16, sp, #0x10
    a50c: f9400a00     	ldr	x0, [x16, #0x10]
    a510: eb00029f     	cmp	x20, x0
    a514: 54ffe9cb     	b.lt	0xa24c <_coil.compiler.resolve.primitive-providers-in+0x10c>
    a518: f100001f     	cmp	x0, #0x0
    a51c: 54ffe901     	b.ne	0xa23c <_coil.compiler.resolve.primitive-providers-in+0xfc>
    a520: d2800040     	mov	x0, #0x2                ; =2
    a524: 17ffff47     	b	0xa240 <_coil.compiler.resolve.primitive-providers-in+0x100>
    a528: f9403bf9     	ldr	x25, [sp, #0x70]
    a52c: f94053fa     	ldr	x26, [sp, #0xa0]
    a530: f9405bfb     	ldr	x27, [sp, #0xb0]
    a534: f9404ff3     	ldr	x19, [sp, #0x98]
    a538: f94037f8     	ldr	x24, [sp, #0x68]
    a53c: f9405ffc     	ldr	x28, [sp, #0xb8]
    a540: f9400aa0     	ldr	x0, [x21, #0x10]
    a544: 9100079c     	add	x28, x28, #0x1
    a548: eb00039f     	cmp	x28, x0
    a54c: 54000c4a     	b.ge	0xa6d4 <_coil.compiler.resolve.primitive-providers-in+0x594>
    a550: f100039f     	cmp	x28, #0x0
    a554: 54000c4b     	b.lt	0xa6dc <_coil.compiler.resolve.primitive-providers-in+0x59c>
    a558: eb00039f     	cmp	x28, x0
    a55c: 54000c4a     	b.ge	0xa6e4 <_coil.compiler.resolve.primitive-providers-in+0x5a4>
    a560: f100801f     	cmp	x0, #0x20
    a564: 54ffe58a     	b.ge	0xa214 <_coil.compiler.resolve.primitive-providers-in+0xd4>
    a568: d2e00000     	movz	x0, #0x0, lsl #48
    a56c: 17ffff2d     	b	0xa220 <_coil.compiler.resolve.primitive-providers-in+0xe0>
    a570: 910006f7     	add	x23, x23, #0x1
    a574: f94033f6     	ldr	x22, [sp, #0x60]
    a578: f9404ff3     	ldr	x19, [sp, #0x98]
    a57c: 910043f0     	add	x16, sp, #0x10
    a580: f9400600     	ldr	x0, [x16, #0x8]
    a584: eb0002ff     	cmp	x23, x0
    a588: 5400034a     	b.ge	0xa5f0 <_coil.compiler.resolve.primitive-providers-in+0x4b0>
    a58c: 910043f0     	add	x16, sp, #0x10
    a590: f9400200     	ldr	x0, [x16]
    a594: 8b171400     	add	x0, x0, x23, lsl #5
    a598: f9400018     	ldr	x24, [x0]
    a59c: f9400419     	ldr	x25, [x0, #0x8]
    a5a0: f940081a     	ldr	x26, [x0, #0x10]
    a5a4: f9400c1b     	ldr	x27, [x0, #0x18]
    a5a8: aa1603e0     	mov	x0, x22
    a5ac: aa1803e1     	mov	x1, x24
    a5b0: aa1903e2     	mov	x2, x25
    a5b4: aa1a03e3     	mov	x3, x26
    a5b8: aa1b03e4     	mov	x4, x27
    a5bc: 94000000     	bl	0xa5bc <_coil.compiler.resolve.primitive-providers-in+0x47c>
    a5c0: f100001f     	cmp	x0, #0x0
    a5c4: 54000940     	b.eq	0xa6ec <_coil.compiler.resolve.primitive-providers-in+0x5ac>
    a5c8: f90033f6     	str	x22, [sp, #0x60]
    a5cc: 92e0001c     	movn	x28, #0x0, lsl #48
    a5d0: 17ffffdc     	b	0xa540 <_coil.compiler.resolve.primitive-providers-in+0x400>
    a5d4: f9400aa0     	ldr	x0, [x21, #0x10]
    a5d8: aa0003e1     	mov	x1, x0
    a5dc: f9405fe0     	ldr	x0, [sp, #0xb8]
    a5e0: 94000000     	bl	0xa5e0 <_coil.compiler.resolve.primitive-providers-in+0x4a0>
    a5e4: 14000000     	b	0xa5e4 <_coil.compiler.resolve.primitive-providers-in+0x4a4>
    a5e8: d4200000     	brk	#0
    a5ec: 17ffffff     	b	0xa5e8 <_coil.compiler.resolve.primitive-providers-in+0x4a8>
    a5f0: 910043f0     	add	x16, sp, #0x10
    a5f4: f9400201     	ldr	x1, [x16]
    a5f8: 910043f0     	add	x16, sp, #0x10
    a5fc: f9400a02     	ldr	x2, [x16, #0x10]
    a600: 910043f0     	add	x16, sp, #0x10
    a604: f9400e03     	ldr	x3, [x16, #0x18]
    a608: 910043f0     	add	x16, sp, #0x10
    a60c: f9401204     	ldr	x4, [x16, #0x20]
    a610: f94063e5     	ldr	x5, [sp, #0xc0]
    a614: f90000a1     	str	x1, [x5]
    a618: f90004a0     	str	x0, [x5, #0x8]
    a61c: f90008a2     	str	x2, [x5, #0x10]
    a620: f9000ca3     	str	x3, [x5, #0x18]
    a624: f90010a4     	str	x4, [x5, #0x20]
    a628: f94067f3     	ldr	x19, [sp, #0xc8]
    a62c: f9406bf4     	ldr	x20, [sp, #0xd0]
    a630: f9406ff5     	ldr	x21, [sp, #0xd8]
    a634: f94073f6     	ldr	x22, [sp, #0xe0]
    a638: f94077f7     	ldr	x23, [sp, #0xe8]
    a63c: f9407bf8     	ldr	x24, [sp, #0xf0]
    a640: f9407ff9     	ldr	x25, [sp, #0xf8]
    a644: f94083fa     	ldr	x26, [sp, #0x100]
    a648: f94087fb     	ldr	x27, [sp, #0x108]
    a64c: f9408bfc     	ldr	x28, [sp, #0x110]
    a650: f94003fd     	ldr	x29, [sp]
    a654: f94007fe     	ldr	x30, [sp, #0x8]
    a658: 910483ff     	add	sp, sp, #0x120
    a65c: d65f03c0     	ret
    a660: f9003bf9     	str	x25, [sp, #0x70]
    a664: f90053fa     	str	x26, [sp, #0xa0]
    a668: f9005bfb     	str	x27, [sp, #0xb0]
    a66c: f9004ff3     	str	x19, [sp, #0x98]
    a670: f90037f8     	str	x24, [sp, #0x68]
    a674: 17ffffad     	b	0xa528 <_coil.compiler.resolve.primitive-providers-in+0x3e8>
    a678: f9003bf9     	str	x25, [sp, #0x70]
    a67c: f90053fa     	str	x26, [sp, #0xa0]
    a680: f9005bfb     	str	x27, [sp, #0xb0]
    a684: f9003fe3     	str	x3, [sp, #0x78]
    a688: f90043e4     	str	x4, [sp, #0x80]
    a68c: f90047e5     	str	x5, [sp, #0x88]
    a690: f9004ff3     	str	x19, [sp, #0x98]
    a694: f90037f8     	str	x24, [sp, #0x68]
    a698: aa0003f8     	mov	x24, x0
    a69c: aa0103f6     	mov	x22, x1
    a6a0: aa0203f9     	mov	x25, x2
    a6a4: 17ffff1a     	b	0xa30c <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    a6a8: f9003bf9     	str	x25, [sp, #0x70]
    a6ac: 17ffff05     	b	0xa2c0 <_coil.compiler.resolve.primitive-providers-in+0x180>
    a6b0: aa0303fb     	mov	x27, x3
    a6b4: aa0003f3     	mov	x19, x0
    a6b8: aa0103fa     	mov	x26, x1
    a6bc: 17ffff8e     	b	0xa4f4 <_coil.compiler.resolve.primitive-providers-in+0x3b4>
    a6c0: aa0303fb     	mov	x27, x3
    a6c4: aa0003f3     	mov	x19, x0
    a6c8: aa0103fa     	mov	x26, x1
    a6cc: f90057e2     	str	x2, [sp, #0xa8]
    a6d0: 17ffff51     	b	0xa414 <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    a6d4: f9004ff3     	str	x19, [sp, #0x98]
    a6d8: 17ffffa6     	b	0xa570 <_coil.compiler.resolve.primitive-providers-in+0x430>
    a6dc: f9005ffc     	str	x28, [sp, #0xb8]
    a6e0: 17ffffbd     	b	0xa5d4 <_coil.compiler.resolve.primitive-providers-in+0x494>
    a6e4: f9005ffc     	str	x28, [sp, #0xb8]
    a6e8: 17ffffbb     	b	0xa5d4 <_coil.compiler.resolve.primitive-providers-in+0x494>
    a6ec: f90033f6     	str	x22, [sp, #0x60]
    a6f0: f9004ff3     	str	x19, [sp, #0x98]
    a6f4: 17ffff9f     	b	0xa570 <_coil.compiler.resolve.primitive-providers-in+0x430>
