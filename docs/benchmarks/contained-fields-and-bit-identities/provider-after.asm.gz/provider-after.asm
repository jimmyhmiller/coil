
build/contained-field-comparison/providers/stogir-after.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000000a0c8 <_coil.compiler.resolve.primitive-providers-in>:
    a0c8: d10483ff     	sub	sp, sp, #0x120
    a0cc: f90003fd     	str	x29, [sp]
    a0d0: f90007fe     	str	x30, [sp, #0x8]
    a0d4: 910003fd     	mov	x29, sp
    a0d8: f90067f3     	str	x19, [sp, #0xc8]
    a0dc: f9006bf4     	str	x20, [sp, #0xd0]
    a0e0: f9006ff5     	str	x21, [sp, #0xd8]
    a0e4: f90073f6     	str	x22, [sp, #0xe0]
    a0e8: f90077f7     	str	x23, [sp, #0xe8]
    a0ec: f9007bf8     	str	x24, [sp, #0xf0]
    a0f0: f9007ff9     	str	x25, [sp, #0xf8]
    a0f4: f90083fa     	str	x26, [sp, #0x100]
    a0f8: f90087fb     	str	x27, [sp, #0x108]
    a0fc: f9008bfc     	str	x28, [sp, #0x110]
    a100: 910103f0     	add	x16, sp, #0x40
    a104: aa1f0207     	orr	x7, x16, xzr
    a108: f9400009     	ldr	x9, [x0]
    a10c: 910020f3     	add	x19, x7, #0x8
    a110: f9400400     	ldr	x0, [x0, #0x8]
    a114: 910043f0     	add	x16, sp, #0x10
    a118: d2e00011     	movz	x17, #0x0, lsl #48
    a11c: f9000211     	str	x17, [x16]
    a120: 910043f0     	add	x16, sp, #0x10
    a124: d2e00011     	movz	x17, #0x0, lsl #48
    a128: f9000611     	str	x17, [x16, #0x8]
    a12c: 910043f0     	add	x16, sp, #0x10
    a130: d2e00011     	movz	x17, #0x0, lsl #48
    a134: f9000a11     	str	x17, [x16, #0x10]
    a138: 910043f0     	add	x16, sp, #0x10
    a13c: f9000e09     	str	x9, [x16, #0x18]
    a140: 910043f0     	add	x16, sp, #0x10
    a144: f9001200     	str	x0, [x16, #0x20]
    a148: 910043e0     	add	x0, sp, #0x10
    a14c: f90063e8     	str	x8, [sp, #0xc0]
    a150: aa0103f5     	mov	x21, x1
    a154: aa0203f6     	mov	x22, x2
    a158: aa0303f7     	mov	x23, x3
    a15c: aa0403f8     	mov	x24, x4
    a160: aa0503f9     	mov	x25, x5
    a164: aa0603fa     	mov	x26, x6
    a168: d2800041     	mov	x1, #0x2                ; =2
    a16c: 94000000     	bl	0xa16c <_coil.compiler.resolve.primitive-providers-in+0xa4>
    a170: 910043f0     	add	x16, sp, #0x10
    a174: f9400200     	ldr	x0, [x16]
    a178: f9000017     	str	x23, [x0]
    a17c: f9000418     	str	x24, [x0, #0x8]
    a180: f9000819     	str	x25, [x0, #0x10]
    a184: f9000c1a     	str	x26, [x0, #0x18]
    a188: 910043f0     	add	x16, sp, #0x10
    a18c: d2800031     	mov	x17, #0x1               ; =1
    a190: f9000611     	str	x17, [x16, #0x8]
    a194: d2e00017     	movz	x23, #0x0, lsl #48
    a198: 140000db     	b	0xa504 <_coil.compiler.resolve.primitive-providers-in+0x43c>
    a19c: d1000400     	sub	x0, x0, #0x1
    a1a0: 9345fc00     	asr	x0, x0, #5
    a1a4: d37be800     	lsl	x0, x0, #5
    a1a8: eb00039f     	cmp	x28, x0
    a1ac: 5400006b     	b.lt	0xa1b8 <_coil.compiler.resolve.primitive-providers-in+0xf0>
    a1b0: f94006a0     	ldr	x0, [x21, #0x8]
    a1b4: 1400001a     	b	0xa21c <_coil.compiler.resolve.primitive-providers-in+0x154>
    a1b8: f94002a0     	ldr	x0, [x21]
    a1bc: f9400ea1     	ldr	x1, [x21, #0x18]
    a1c0: 14000015     	b	0xa214 <_coil.compiler.resolve.primitive-providers-in+0x14c>
    a1c4: d37ff800     	lsl	x0, x0, #1
    a1c8: aa0003e1     	mov	x1, x0
    a1cc: 910043e0     	add	x0, sp, #0x10
    a1d0: 94000000     	bl	0xa1d0 <_coil.compiler.resolve.primitive-providers-in+0x108>
    a1d4: 91000680     	add	x0, x20, #0x1
    a1d8: 910043f0     	add	x16, sp, #0x10
    a1dc: f9400201     	ldr	x1, [x16]
    a1e0: 8b141421     	add	x1, x1, x20, lsl #5
    a1e4: f900003b     	str	x27, [x1]
    a1e8: f900043c     	str	x28, [x1, #0x8]
    a1ec: f9000833     	str	x19, [x1, #0x10]
    a1f0: f9000c3a     	str	x26, [x1, #0x18]
    a1f4: 910043f0     	add	x16, sp, #0x10
    a1f8: f9000600     	str	x0, [x16, #0x8]
    a1fc: 14000026     	b	0xa294 <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    a200: 9ac12b82     	asr	x2, x28, x1
    a204: d1001421     	sub	x1, x1, #0x5
    a208: 92401042     	and	x2, x2, #0x1f
    a20c: f9401000     	ldr	x0, [x0, #0x20]
    a210: f8627800     	ldr	x0, [x0, x2, lsl #3]
    a214: f100003f     	cmp	x1, #0x0
    a218: 54ffff4c     	b.gt	0xa200 <_coil.compiler.resolve.primitive-providers-in+0x138>
    a21c: 92401381     	and	x1, x28, #0x1f
    a220: d2801e11     	mov	x17, #0xf0              ; =240
    a224: 9b117c21     	mul	x1, x1, x17
    a228: f9400c00     	ldr	x0, [x0, #0x18]
    a22c: 8b000022     	add	x2, x1, x0
    a230: 91004043     	add	x3, x2, #0x10
    a234: 91014064     	add	x4, x3, #0x50
    a238: f9005ffc     	str	x28, [sp, #0xb8]
    a23c: 92e00005     	movn	x5, #0x0, lsl #48
    a240: 14000020     	b	0xa2c0 <_coil.compiler.resolve.primitive-providers-in+0x1f8>
    a244: d503201f     	nop
    a248: d340fce7     	lsr	x7, x7, #0
    a24c: aa0103f6     	mov	x22, x1
    a250: aa1803e1     	mov	x1, x24
    a254: aa0203f9     	mov	x25, x2
    a258: aa0703e2     	mov	x2, x7
    a25c: f9003fe3     	str	x3, [sp, #0x78]
    a260: f90043e4     	str	x4, [sp, #0x80]
    a264: f90047e5     	str	x5, [sp, #0x88]
    a268: f9004be9     	str	x9, [sp, #0x90]
    a26c: f90037f8     	str	x24, [sp, #0x68]
    a270: aa0003f8     	mov	x24, x0
    a274: aa0603e0     	mov	x0, x6
    a278: 94000000     	bl	0xa278 <_coil.compiler.resolve.primitive-providers-in+0x1b0>
    a27c: 93407c00     	sxtw	x0, w0
    a280: f100001f     	cmp	x0, #0x0
    a284: 540004e0     	b.eq	0xa320 <_coil.compiler.resolve.primitive-providers-in+0x258>
    a288: f90053fa     	str	x26, [sp, #0xa0]
    a28c: f9005bfb     	str	x27, [sp, #0xb0]
    a290: f9004ff3     	str	x19, [sp, #0x98]
    a294: f94053fa     	ldr	x26, [sp, #0xa0]
    a298: f9405bfb     	ldr	x27, [sp, #0xb0]
    a29c: f9403fe3     	ldr	x3, [sp, #0x78]
    a2a0: f94043e4     	ldr	x4, [sp, #0x80]
    a2a4: f9404ff3     	ldr	x19, [sp, #0x98]
    a2a8: aa1803e0     	mov	x0, x24
    a2ac: f94037f8     	ldr	x24, [sp, #0x68]
    a2b0: aa1603e1     	mov	x1, x22
    a2b4: aa1903e2     	mov	x2, x25
    a2b8: f9403bf9     	ldr	x25, [sp, #0x70]
    a2bc: f94047e5     	ldr	x5, [sp, #0x88]
    a2c0: f9400486     	ldr	x6, [x4, #0x8]
    a2c4: 910004a5     	add	x5, x5, #0x1
    a2c8: eb0600bf     	cmp	x5, x6
    a2cc: 540018ea     	b.ge	0xa5e8 <_coil.compiler.resolve.primitive-providers-in+0x520>
    a2d0: d2800611     	mov	x17, #0x30              ; =48
    a2d4: 9b117ca6     	mul	x6, x5, x17
    a2d8: f9402867     	ldr	x7, [x3, #0x50]
    a2dc: 8b0700c8     	add	x8, x6, x7
    a2e0: aa1f0109     	orr	x9, x8, xzr
    a2e4: f86768c6     	ldr	x6, [x6, x7]
    a2e8: f9400507     	ldr	x7, [x8, #0x8]
    a2ec: eb1900ff     	cmp	x7, x25
    a2f0: 54001881     	b.ne	0xa600 <_coil.compiler.resolve.primitive-providers-in+0x538>
    a2f4: f10000ff     	cmp	x7, #0x0
    a2f8: 540019c1     	b.ne	0xa630 <_coil.compiler.resolve.primitive-providers-in+0x568>
    a2fc: f9003bf9     	str	x25, [sp, #0x70]
    a300: f9003fe3     	str	x3, [sp, #0x78]
    a304: f90043e4     	str	x4, [sp, #0x80]
    a308: f90047e5     	str	x5, [sp, #0x88]
    a30c: f9004be9     	str	x9, [sp, #0x90]
    a310: f90037f8     	str	x24, [sp, #0x68]
    a314: aa0003f8     	mov	x24, x0
    a318: aa0103f6     	mov	x22, x1
    a31c: aa0203f9     	mov	x25, x2
    a320: 910103e8     	add	x8, sp, #0x40
    a324: f9404be0     	ldr	x0, [sp, #0x90]
    a328: aa1a03e1     	mov	x1, x26
    a32c: aa1b03e2     	mov	x2, x27
    a330: 94000000     	bl	0xa330 <_coil.compiler.resolve.primitive-providers-in+0x268>
    a334: 910103f0     	add	x16, sp, #0x40
    a338: b9400200     	ldr	w0, [x16]
    a33c: d340fc10     	lsr	x16, x0, #0
    a340: f100061f     	cmp	x16, #0x1
    a344: 54000140     	b.eq	0xa36c <_coil.compiler.resolve.primitive-providers-in+0x2a4>
    a348: 54000043     	b.lo	0xa350 <_coil.compiler.resolve.primitive-providers-in+0x288>
    a34c: 14000009     	b	0xa370 <_coil.compiler.resolve.primitive-providers-in+0x2a8>
    a350: f100021f     	cmp	x16, #0x0
    a354: 54000040     	b.eq	0xa35c <_coil.compiler.resolve.primitive-providers-in+0x294>
    a358: 14000006     	b	0xa370 <_coil.compiler.resolve.primitive-providers-in+0x2a8>
    a35c: f90053fa     	str	x26, [sp, #0xa0]
    a360: f9005bfb     	str	x27, [sp, #0xb0]
    a364: f9004ff3     	str	x19, [sp, #0x98]
    a368: 17ffffcb     	b	0xa294 <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    a36c: 14000002     	b	0xa374 <_coil.compiler.resolve.primitive-providers-in+0x2ac>
    a370: 14000080     	b	0xa570 <_coil.compiler.resolve.primitive-providers-in+0x4a8>
    a374: 910103f0     	add	x16, sp, #0x40
    a378: f9400600     	ldr	x0, [x16, #0x8]
    a37c: f9400661     	ldr	x1, [x19, #0x8]
    a380: f9004ff3     	str	x19, [sp, #0x98]
    a384: f90053fa     	str	x26, [sp, #0xa0]
    a388: f9005bfb     	str	x27, [sp, #0xb0]
    a38c: 92e00002     	movn	x2, #0x0, lsl #48
    a390: d2e00003     	movz	x3, #0x0, lsl #48
    a394: 14000006     	b	0xa3ac <_coil.compiler.resolve.primitive-providers-in+0x2e4>
    a398: d280003b     	mov	x27, #0x1               ; =1
    a39c: aa1303e0     	mov	x0, x19
    a3a0: aa1a03e1     	mov	x1, x26
    a3a4: f94057e2     	ldr	x2, [sp, #0xa8]
    a3a8: aa1b03e3     	mov	x3, x27
    a3ac: 910043f0     	add	x16, sp, #0x10
    a3b0: f9400604     	ldr	x4, [x16, #0x8]
    a3b4: 91000442     	add	x2, x2, #0x1
    a3b8: eb04005f     	cmp	x2, x4
    a3bc: 540013ea     	b.ge	0xa638 <_coil.compiler.resolve.primitive-providers-in+0x570>
    a3c0: 910043f0     	add	x16, sp, #0x10
    a3c4: f9400204     	ldr	x4, [x16]
    a3c8: 8b021484     	add	x4, x4, x2, lsl #5
    a3cc: f9400085     	ldr	x5, [x4]
    a3d0: f9400486     	ldr	x6, [x4, #0x8]
    a3d4: f9400887     	ldr	x7, [x4, #0x10]
    a3d8: f9400c84     	ldr	x4, [x4, #0x18]
    a3dc: f8786ac8     	ldr	x8, [x22, x24]
    a3e0: f9400729     	ldr	x9, [x25, #0x8]
    a3e4: eb0900df     	cmp	x6, x9
    a3e8: 54001301     	b.ne	0xa648 <_coil.compiler.resolve.primitive-providers-in+0x580>
    a3ec: f10000df     	cmp	x6, #0x0
    a3f0: 54000281     	b.ne	0xa440 <_coil.compiler.resolve.primitive-providers-in+0x378>
    a3f4: aa0303fb     	mov	x27, x3
    a3f8: aa0003f3     	mov	x19, x0
    a3fc: aa0103fa     	mov	x26, x1
    a400: f90057e2     	str	x2, [sp, #0xa8]
    a404: aa0703fc     	mov	x28, x7
    a408: aa0403f4     	mov	x20, x4
    a40c: eb1a029f     	cmp	x20, x26
    a410: 54fffc61     	b.ne	0xa39c <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    a414: f100029f     	cmp	x20, #0x0
    a418: 54fffc00     	b.eq	0xa398 <_coil.compiler.resolve.primitive-providers-in+0x2d0>
    a41c: d340fe80     	lsr	x0, x20, #0
    a420: aa1303e1     	mov	x1, x19
    a424: aa0003e2     	mov	x2, x0
    a428: aa1c03e0     	mov	x0, x28
    a42c: 94000000     	bl	0xa42c <_coil.compiler.resolve.primitive-providers-in+0x364>
    a430: 93407c00     	sxtw	x0, w0
    a434: f100001f     	cmp	x0, #0x0
    a438: 54fffb00     	b.eq	0xa398 <_coil.compiler.resolve.primitive-providers-in+0x2d0>
    a43c: 17ffffd8     	b	0xa39c <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    a440: d340fcc6     	lsr	x6, x6, #0
    a444: aa0003f3     	mov	x19, x0
    a448: aa0503e0     	mov	x0, x5
    a44c: aa0103fa     	mov	x26, x1
    a450: aa0803e1     	mov	x1, x8
    a454: f90057e2     	str	x2, [sp, #0xa8]
    a458: aa0603e2     	mov	x2, x6
    a45c: aa0303fb     	mov	x27, x3
    a460: aa0703fc     	mov	x28, x7
    a464: aa0403f4     	mov	x20, x4
    a468: 94000000     	bl	0xa468 <_coil.compiler.resolve.primitive-providers-in+0x3a0>
    a46c: 93407c00     	sxtw	x0, w0
    a470: f100001f     	cmp	x0, #0x0
    a474: 54fffcc0     	b.eq	0xa40c <_coil.compiler.resolve.primitive-providers-in+0x344>
    a478: 17ffffc9     	b	0xa39c <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    a47c: f100037f     	cmp	x27, #0x0
    a480: 54fff0a1     	b.ne	0xa294 <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    a484: aa1f0094     	orr	x20, x4, xzr
    a488: f8786adb     	ldr	x27, [x22, x24]
    a48c: f940073c     	ldr	x28, [x25, #0x8]
    a490: 910043f0     	add	x16, sp, #0x10
    a494: f9400a00     	ldr	x0, [x16, #0x10]
    a498: eb00029f     	cmp	x20, x0
    a49c: 54ffe9cb     	b.lt	0xa1d4 <_coil.compiler.resolve.primitive-providers-in+0x10c>
    a4a0: f100001f     	cmp	x0, #0x0
    a4a4: 54ffe901     	b.ne	0xa1c4 <_coil.compiler.resolve.primitive-providers-in+0xfc>
    a4a8: d2800040     	mov	x0, #0x2                ; =2
    a4ac: 17ffff47     	b	0xa1c8 <_coil.compiler.resolve.primitive-providers-in+0x100>
    a4b0: f9403bf9     	ldr	x25, [sp, #0x70]
    a4b4: f94053fa     	ldr	x26, [sp, #0xa0]
    a4b8: f9405bfb     	ldr	x27, [sp, #0xb0]
    a4bc: f9404ff3     	ldr	x19, [sp, #0x98]
    a4c0: f94037f8     	ldr	x24, [sp, #0x68]
    a4c4: f9405ffc     	ldr	x28, [sp, #0xb8]
    a4c8: f9400aa0     	ldr	x0, [x21, #0x10]
    a4cc: 9100079c     	add	x28, x28, #0x1
    a4d0: eb00039f     	cmp	x28, x0
    a4d4: 54000c4a     	b.ge	0xa65c <_coil.compiler.resolve.primitive-providers-in+0x594>
    a4d8: f100039f     	cmp	x28, #0x0
    a4dc: 54000c4b     	b.lt	0xa664 <_coil.compiler.resolve.primitive-providers-in+0x59c>
    a4e0: eb00039f     	cmp	x28, x0
    a4e4: 54000c4a     	b.ge	0xa66c <_coil.compiler.resolve.primitive-providers-in+0x5a4>
    a4e8: f100801f     	cmp	x0, #0x20
    a4ec: 54ffe58a     	b.ge	0xa19c <_coil.compiler.resolve.primitive-providers-in+0xd4>
    a4f0: d2e00000     	movz	x0, #0x0, lsl #48
    a4f4: 17ffff2d     	b	0xa1a8 <_coil.compiler.resolve.primitive-providers-in+0xe0>
    a4f8: 910006f7     	add	x23, x23, #0x1
    a4fc: f94033f6     	ldr	x22, [sp, #0x60]
    a500: f9404ff3     	ldr	x19, [sp, #0x98]
    a504: 910043f0     	add	x16, sp, #0x10
    a508: f9400600     	ldr	x0, [x16, #0x8]
    a50c: eb0002ff     	cmp	x23, x0
    a510: 5400034a     	b.ge	0xa578 <_coil.compiler.resolve.primitive-providers-in+0x4b0>
    a514: 910043f0     	add	x16, sp, #0x10
    a518: f9400200     	ldr	x0, [x16]
    a51c: 8b171400     	add	x0, x0, x23, lsl #5
    a520: f9400018     	ldr	x24, [x0]
    a524: f9400419     	ldr	x25, [x0, #0x8]
    a528: f940081a     	ldr	x26, [x0, #0x10]
    a52c: f9400c1b     	ldr	x27, [x0, #0x18]
    a530: aa1603e0     	mov	x0, x22
    a534: aa1803e1     	mov	x1, x24
    a538: aa1903e2     	mov	x2, x25
    a53c: aa1a03e3     	mov	x3, x26
    a540: aa1b03e4     	mov	x4, x27
    a544: 94000000     	bl	0xa544 <_coil.compiler.resolve.primitive-providers-in+0x47c>
    a548: f100001f     	cmp	x0, #0x0
    a54c: 54000940     	b.eq	0xa674 <_coil.compiler.resolve.primitive-providers-in+0x5ac>
    a550: f90033f6     	str	x22, [sp, #0x60]
    a554: 92e0001c     	movn	x28, #0x0, lsl #48
    a558: 17ffffdc     	b	0xa4c8 <_coil.compiler.resolve.primitive-providers-in+0x400>
    a55c: f9400aa0     	ldr	x0, [x21, #0x10]
    a560: aa0003e1     	mov	x1, x0
    a564: f9405fe0     	ldr	x0, [sp, #0xb8]
    a568: 94000000     	bl	0xa568 <_coil.compiler.resolve.primitive-providers-in+0x4a0>
    a56c: 14000000     	b	0xa56c <_coil.compiler.resolve.primitive-providers-in+0x4a4>
    a570: d4200000     	brk	#0
    a574: 17ffffff     	b	0xa570 <_coil.compiler.resolve.primitive-providers-in+0x4a8>
    a578: 910043f0     	add	x16, sp, #0x10
    a57c: f9400201     	ldr	x1, [x16]
    a580: 910043f0     	add	x16, sp, #0x10
    a584: f9400a02     	ldr	x2, [x16, #0x10]
    a588: 910043f0     	add	x16, sp, #0x10
    a58c: f9400e03     	ldr	x3, [x16, #0x18]
    a590: 910043f0     	add	x16, sp, #0x10
    a594: f9401204     	ldr	x4, [x16, #0x20]
    a598: f94063e5     	ldr	x5, [sp, #0xc0]
    a59c: f90000a1     	str	x1, [x5]
    a5a0: f90004a0     	str	x0, [x5, #0x8]
    a5a4: f90008a2     	str	x2, [x5, #0x10]
    a5a8: f9000ca3     	str	x3, [x5, #0x18]
    a5ac: f90010a4     	str	x4, [x5, #0x20]
    a5b0: f94067f3     	ldr	x19, [sp, #0xc8]
    a5b4: f9406bf4     	ldr	x20, [sp, #0xd0]
    a5b8: f9406ff5     	ldr	x21, [sp, #0xd8]
    a5bc: f94073f6     	ldr	x22, [sp, #0xe0]
    a5c0: f94077f7     	ldr	x23, [sp, #0xe8]
    a5c4: f9407bf8     	ldr	x24, [sp, #0xf0]
    a5c8: f9407ff9     	ldr	x25, [sp, #0xf8]
    a5cc: f94083fa     	ldr	x26, [sp, #0x100]
    a5d0: f94087fb     	ldr	x27, [sp, #0x108]
    a5d4: f9408bfc     	ldr	x28, [sp, #0x110]
    a5d8: f94003fd     	ldr	x29, [sp]
    a5dc: f94007fe     	ldr	x30, [sp, #0x8]
    a5e0: 910483ff     	add	sp, sp, #0x120
    a5e4: d65f03c0     	ret
    a5e8: f9003bf9     	str	x25, [sp, #0x70]
    a5ec: f90053fa     	str	x26, [sp, #0xa0]
    a5f0: f9005bfb     	str	x27, [sp, #0xb0]
    a5f4: f9004ff3     	str	x19, [sp, #0x98]
    a5f8: f90037f8     	str	x24, [sp, #0x68]
    a5fc: 17ffffad     	b	0xa4b0 <_coil.compiler.resolve.primitive-providers-in+0x3e8>
    a600: f9003bf9     	str	x25, [sp, #0x70]
    a604: f90053fa     	str	x26, [sp, #0xa0]
    a608: f9005bfb     	str	x27, [sp, #0xb0]
    a60c: f9003fe3     	str	x3, [sp, #0x78]
    a610: f90043e4     	str	x4, [sp, #0x80]
    a614: f90047e5     	str	x5, [sp, #0x88]
    a618: f9004ff3     	str	x19, [sp, #0x98]
    a61c: f90037f8     	str	x24, [sp, #0x68]
    a620: aa0003f8     	mov	x24, x0
    a624: aa0103f6     	mov	x22, x1
    a628: aa0203f9     	mov	x25, x2
    a62c: 17ffff1a     	b	0xa294 <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    a630: f9003bf9     	str	x25, [sp, #0x70]
    a634: 17ffff05     	b	0xa248 <_coil.compiler.resolve.primitive-providers-in+0x180>
    a638: aa0303fb     	mov	x27, x3
    a63c: aa0003f3     	mov	x19, x0
    a640: aa0103fa     	mov	x26, x1
    a644: 17ffff8e     	b	0xa47c <_coil.compiler.resolve.primitive-providers-in+0x3b4>
    a648: aa0303fb     	mov	x27, x3
    a64c: aa0003f3     	mov	x19, x0
    a650: aa0103fa     	mov	x26, x1
    a654: f90057e2     	str	x2, [sp, #0xa8]
    a658: 17ffff51     	b	0xa39c <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    a65c: f9004ff3     	str	x19, [sp, #0x98]
    a660: 17ffffa6     	b	0xa4f8 <_coil.compiler.resolve.primitive-providers-in+0x430>
    a664: f9005ffc     	str	x28, [sp, #0xb8]
    a668: 17ffffbd     	b	0xa55c <_coil.compiler.resolve.primitive-providers-in+0x494>
    a66c: f9005ffc     	str	x28, [sp, #0xb8]
    a670: 17ffffbb     	b	0xa55c <_coil.compiler.resolve.primitive-providers-in+0x494>
    a674: f90033f6     	str	x22, [sp, #0x60]
    a678: f9004ff3     	str	x19, [sp, #0x98]
    a67c: 17ffff9f     	b	0xa4f8 <_coil.compiler.resolve.primitive-providers-in+0x430>
