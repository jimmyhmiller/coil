
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-callee-return-values/build/callee-return-comparison/verify-graph/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0x8c <_gap_verify_graph+0x8c>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x78 <_gap_verify_graph+0x78>
      60:      	add	x0, sp, #0x30
      64:      	mov	x1, x19
      68:      	mov	x2, #0x1a0              ; =416
      6c:      	bl	0x6c <_gap_verify_graph+0x6c>
		000000000000006c:  ARM64_RELOC_BRANCH26	_memmove
      70:      	add	x16, sp, #0x30
      74:      	ldr	x0, [x16, #0x8]
      78:      	ldr	x19, [sp, #0x1d0]
      7c:      	ldr	x29, [sp]
      80:      	ldr	x30, [sp, #0x8]
      84:      	add	sp, sp, #0x1e0
      88:      	ret
      8c:      	brk	#0
      90:      	b	0x8c <_gap_verify_graph+0x8c>

0000000000000094 <_stogir.verify.integer-operations-target>:
      94:      	sub	sp, sp, #0x70
      98:      	str	x29, [sp]
      9c:      	str	x30, [sp, #0x8]
      a0:      	mov	x29, sp
      a4:      	str	x19, [sp, #0x50]
      a8:      	str	x20, [sp, #0x58]
      ac:      	str	x21, [sp, #0x60]
      b0:      	mov	x19, x8
      b4:      	add	x8, sp, #0x10
      b8:      	mov	x20, x0
      bc:      	mov	w21, w1
      c0:      	bl	0xc0 <_stogir.verify.integer-operations-target+0x2c>
		00000000000000c0:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      c4:      	add	x16, sp, #0x10
      c8:      	ldr	w0, [x16]
      cc:      	lsr	x16, x0, #0
      d0:      	cmp	x16, #0x1
      d4:      	b.eq	0xf0 <_stogir.verify.integer-operations-target+0x5c>
      d8:      	b.lo	0xe0 <_stogir.verify.integer-operations-target+0x4c>
      dc:      	b	0xf4 <_stogir.verify.integer-operations-target+0x60>
      e0:      	cmp	x16, #0x0
      e4:      	b.eq	0xec <_stogir.verify.integer-operations-target+0x58>
      e8:      	b	0xf4 <_stogir.verify.integer-operations-target+0x60>
      ec:      	b	0x118 <_stogir.verify.integer-operations-target+0x84>
      f0:      	b	0xf8 <_stogir.verify.integer-operations-target+0x64>
      f4:      	b	0x168 <_stogir.verify.integer-operations-target+0xd4>
      f8:      	add	x16, sp, #0x10
      fc:      	orr	x0, x16, xzr
     100:      	add	x0, x0, #0x8
     104:      	add	x16, sp, #0x10
     108:      	ldr	x1, [x16, #0x8]
     10c:      	ldr	x0, [x0, #0x8]
     110:      	mov	x2, #0x1                ; =1
     114:      	b	0x140 <_stogir.verify.integer-operations-target+0xac>
     118:      	add	x8, sp, #0x30
     11c:      	mov	x0, x20
     120:      	mov	w1, w21
     124:      	bl	0x124 <_stogir.verify.integer-operations-target+0x90>
		0000000000000124:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     128:      	add	x16, sp, #0x30
     12c:      	ldr	x2, [x16]
     130:      	add	x16, sp, #0x30
     134:      	ldr	x1, [x16, #0x8]
     138:      	add	x16, sp, #0x30
     13c:      	ldr	x0, [x16, #0x10]
     140:      	str	x2, [x19]
     144:      	str	x1, [x19, #0x8]
     148:      	str	x0, [x19, #0x10]
     14c:      	ldr	x19, [sp, #0x50]
     150:      	ldr	x20, [sp, #0x58]
     154:      	ldr	x21, [sp, #0x60]
     158:      	ldr	x29, [sp]
     15c:      	ldr	x30, [sp, #0x8]
     160:      	add	sp, sp, #0x70
     164:      	ret
     168:      	brk	#0
     16c:      	b	0x168 <_stogir.verify.integer-operations-target+0xd4>

0000000000000170 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     170:      	ldr	x0, [x0, #0x8]
     174:      	ret

0000000000000178 <_stogir.verify.structure>:
     178:      	sub	sp, sp, #0x110
     17c:      	str	x29, [sp, #0x10]
     180:      	str	x30, [sp, #0x18]
     184:      	add	x29, sp, #0x10
     188:      	str	x19, [sp, #0xb8]
     18c:      	str	x20, [sp, #0xc0]
     190:      	str	x21, [sp, #0xc8]
     194:      	str	x22, [sp, #0xd0]
     198:      	str	x23, [sp, #0xd8]
     19c:      	str	x24, [sp, #0xe0]
     1a0:      	str	x25, [sp, #0xe8]
     1a4:      	str	x26, [sp, #0xf0]
     1a8:      	str	x27, [sp, #0xf8]
     1ac:      	str	x28, [sp, #0x100]
     1b0:      	mov	x19, x8
     1b4:      	mov	x20, x0
     1b8:      	bl	0x1b8 <_stogir.verify.structure+0x40>
		00000000000001b8:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
     1bc:      	add	x21, x20, #0x78
     1c0:      	mov	x22, x0
     1c4:      	mov	x0, x21
     1c8:      	bl	0x1c8 <_stogir.verify.structure+0x50>
		00000000000001c8:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
     1cc:      	cmp	x22, x0
     1d0:      	b.ne	0x200 <_stogir.verify.structure+0x88>
     1d4:      	adrp	x22, 0x0 <_gap_verify_graph>
		00000000000001d4:  ARM64_RELOC_PAGE21	l_stogir.311
     1d8:      	ldr	x22, [x22]
		00000000000001d8:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     1dc:      	movz	x23, #0x0, lsl #48
     1e0:      	b	0x20c <_stogir.verify.structure+0x94>
     1e4:      	ldr	x1, [sp, #0x88]
     1e8:      	ldr	x5, [sp, #0x90]
     1ec:      	add	x5, x1, x5
     1f0:      	ldr	x19, [sp, #0x40]
     1f4:      	add	x1, x19, #0x1
     1f8:      	sxtw	x19, w1
     1fc:      	b	0x23c <_stogir.verify.structure+0xc4>
     200:      	adrp	x22, 0x0 <_gap_verify_graph>
		0000000000000200:  ARM64_RELOC_PAGE21	l_stogir.312
     204:      	ldr	x22, [x22]
		0000000000000204:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     208:      	mov	x23, #0x2c              ; =44
     20c:      	add	x24, x20, #0x110
     210:      	add	x25, x20, #0x28
     214:      	add	x26, x20, #0x50
     218:      	add	x27, x24, #0x28
     21c:      	mov	x28, #0x1               ; =1
     220:      	movz	x0, #0x0, lsl #48
     224:      	b	0x294 <_stogir.verify.structure+0x11c>
     228:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000228:  ARM64_RELOC_PAGE21	l_stogir.313
     22c:      	ldr	x16, [x16]
		000000000000022c:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     230:      	str	x16, [sp, #0x38]
     234:      	mov	x16, #0x16              ; =22
     238:      	str	x16, [sp, #0x80]
     23c:      	b	0x270 <_stogir.verify.structure+0xf8>
     240:      	mov	x5, x28
     244:      	str	x19, [sp, #0x30]
     248:      	mov	x19, x0
     24c:      	mov	x0, x21
     250:      	mov	x2, x24
     254:      	mov	x3, x25
     258:      	mov	x4, x26
     25c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000025c:  ARM64_RELOC_PAGE21	l_stogir.314
     260:      	ldr	x16, [x16]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     264:      	str	x16, [sp, #0x38]
     268:      	mov	x16, #0x23              ; =35
     26c:      	str	x16, [sp, #0x80]
     270:      	mov	x21, x0
     274:      	mov	x24, x2
     278:      	mov	x25, x3
     27c:      	mov	x26, x4
     280:      	mov	x28, x5
     284:      	mov	x0, x19
     288:      	ldr	x19, [sp, #0x30]
     28c:      	ldr	x22, [sp, #0x38]
     290:      	ldr	x23, [sp, #0x80]
     294:      	cmp	x23, #0x0
     298:      	b.ne	0xa54 <_stogir.verify.structure+0x8dc>
     29c:      	ldr	x1, [x20, #0x8]
     2a0:      	cmp	x28, x1
     2a4:      	b.ge	0xa68 <_stogir.verify.structure+0x8f0>
     2a8:      	ldr	x1, [x20]
     2ac:      	add	x1, x1, x28, lsl #4
     2b0:      	ldr	x1, [x1]
     2b4:      	ldr	x2, [x20, #0x78]
     2b8:      	add	x2, x2, x28, lsl #2
     2bc:      	ldr	w2, [x2]
     2c0:      	sxtw	x2, w2
     2c4:      	cmp	x2, #0x0
     2c8:      	b.lt	0x240 <_stogir.verify.structure+0xc8>
     2cc:      	mov	x17, #0xffff            ; =65535
     2d0:      	cmp	x2, x17
     2d4:      	b.gt	0xa7c <_stogir.verify.structure+0x904>
     2d8:      	uxtb	w3, w1
     2dc:      	orr	x4, x3, xzr
     2e0:      	cmp	x4, #0x83
     2e4:      	cset	w5, lt
     2e8:      	uxtb	w16, w5
     2ec:      	cmp	w16, wzr
     2f0:      	b.eq	0xa9c <_stogir.verify.structure+0x924>
     2f4:      	ubfx	x1, x1, #0, #32
     2f8:      	ubfx	x6, x1, #8, #8
     2fc:      	orr	x7, x6, xzr
     300:      	str	x0, [sp, #0x40]
     304:      	mov	w0, w7
     308:      	str	x19, [sp, #0x30]
     30c:      	mov	w19, w3
     310:      	str	x22, [sp, #0x38]
     314:      	mov	x22, x2
     318:      	str	x26, [sp, #0x48]
     31c:      	mov	x26, x4
     320:      	str	x25, [sp, #0x50]
     324:      	mov	w25, w5
     328:      	str	x21, [sp, #0x58]
     32c:      	mov	x21, x1
     330:      	str	x24, [sp, #0x60]
     334:      	mov	w24, w6
     338:      	bl	0x338 <_stogir.verify.structure+0x1c0>
		0000000000000338:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     33c:      	cmp	x0, #0x0
     340:      	b.eq	0xabc <_stogir.verify.structure+0x944>
     344:      	adrp	x17, 0x0 <_gap_verify_graph>
		0000000000000344:  ARM64_RELOC_PAGE21	l_stogir.315
     348:      	ldr	x17, [x17]
		0000000000000348:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     34c:      	add	x0, x26, x17
     350:      	ldrsb	w0, [x0]
     354:      	sxtb	x0, w0
     358:      	cmp	x0, #0x0
     35c:      	b.lt	0x774 <_stogir.verify.structure+0x5fc>
     360:      	uxtb	w16, w25
     364:      	cmp	w16, wzr
     368:      	b.eq	0x848 <_stogir.verify.structure+0x6d0>
     36c:      	adrp	x17, 0x0 <_gap_verify_graph>
		000000000000036c:  ARM64_RELOC_PAGE21	l_stogir.315
     370:      	ldr	x17, [x17]
		0000000000000370:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     374:      	add	x0, x26, x17
     378:      	ldrsb	w0, [x0]
     37c:      	sxtb	w0, w0
     380:      	b	0x84c <_stogir.verify.structure+0x6d4>
     384:      	ldr	x0, [sp, #0x38]
     388:      	ldr	x1, [sp, #0x80]
     38c:      	adrp	x2, 0x0 <_gap_verify_graph>
		000000000000038c:  ARM64_RELOC_PAGE21	l_stogir.311
     390:      	ldr	x2, [x2]
		0000000000000390:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     394:      	movz	x3, #0x0, lsl #48
     398:      	bl	0x398 <_stogir.verify.structure+0x220>
		0000000000000398:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
     39c:      	cmp	x0, #0x0
     3a0:      	b.eq	0xad8 <_stogir.verify.structure+0x960>
     3a4:      	and	x0, x19, #0xffffffff
     3a8:      	movz	x1, #0x0, lsl #48
     3ac:      	movz	x16, #0x0, lsl #48
     3b0:      	str	x16, [sp, #0x80]
     3b4:      	b	0x3bc <_stogir.verify.structure+0x244>
     3b8:      	mov	x1, #0x1                ; =1
     3bc:      	ldr	x2, [sp, #0x30]
     3c0:      	str	x1, [x2]
     3c4:      	str	x0, [x2, #0x8]
     3c8:      	ldr	x0, [sp, #0x80]
     3cc:      	str	x0, [x2, #0x10]
     3d0:      	ldr	x19, [sp, #0xb8]
     3d4:      	ldr	x20, [sp, #0xc0]
     3d8:      	ldr	x21, [sp, #0xc8]
     3dc:      	ldr	x22, [sp, #0xd0]
     3e0:      	ldr	x23, [sp, #0xd8]
     3e4:      	ldr	x24, [sp, #0xe0]
     3e8:      	ldr	x25, [sp, #0xe8]
     3ec:      	ldr	x26, [sp, #0xf0]
     3f0:      	ldr	x27, [sp, #0xf8]
     3f4:      	ldr	x28, [sp, #0x100]
     3f8:      	ldr	x29, [sp, #0x10]
     3fc:      	ldr	x30, [sp, #0x18]
     400:      	add	sp, sp, #0x110
     404:      	ret
     408:      	mov	w9, w5
     40c:      	lsl	w9, w9, #2
     410:      	ubfx	x9, x9, #0, #32
     414:      	lsr	x8, x8, x9
     418:      	and	w8, w8, #0xf
     41c:      	b	0x43c <_stogir.verify.structure+0x2c4>
     420:      	movz	x1, #0x0, lsl #48
     424:      	cmp	x1, #0x0
     428:      	b.eq	0x888 <_stogir.verify.structure+0x710>
     42c:      	ldr	w1, [sp, #0xb0]
     430:      	ldr	w5, [sp, #0xa8]
     434:      	b	0x4e4 <_stogir.verify.structure+0x36c>
     438:      	movz	w8, #0x0, lsl #16
     43c:      	b	0x444 <_stogir.verify.structure+0x2cc>
     440:      	movz	w8, #0x0, lsl #16
     444:      	str	w0, [sp, #0x68]
     448:      	str	x2, [sp, #0x98]
     44c:      	mov	w2, w3
     450:      	str	x4, [sp, #0xa0]
     454:      	str	x22, [sp, #0x70]
     458:      	mov	x22, x1
     45c:      	mov	w1, w0
     460:      	mov	x0, x20
     464:      	str	x26, [sp, #0x78]
     468:      	mov	w26, w7
     46c:      	str	x23, [sp, #0x80]
     470:      	mov	w23, w8
     474:      	str	x19, [sp, #0x88]
     478:      	mov	w19, w5
     47c:      	str	x28, [sp, #0x90]
     480:      	mov	w28, w6
     484:      	bl	0x484 <_stogir.verify.structure+0x30c>
		0000000000000484:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     488:      	ubfx	x0, x0, #0, #32
     48c:      	lsr	x16, x0, #0
     490:      	cmp	x16, #0x1
     494:      	b.eq	0x4b0 <_stogir.verify.structure+0x338>
     498:      	b.lo	0x4a0 <_stogir.verify.structure+0x328>
     49c:      	b	0x4b4 <_stogir.verify.structure+0x33c>
     4a0:      	cmp	x16, #0x0
     4a4:      	b.eq	0x4ac <_stogir.verify.structure+0x334>
     4a8:      	b	0x4b4 <_stogir.verify.structure+0x33c>
     4ac:      	b	0x4b8 <_stogir.verify.structure+0x340>
     4b0:      	b	0x598 <_stogir.verify.structure+0x420>
     4b4:      	b	0x9bc <_stogir.verify.structure+0x844>
     4b8:      	ldr	x0, [sp, #0x58]
     4bc:      	ldr	x2, [sp, #0x60]
     4c0:      	mov	w1, w21
     4c4:      	mov	w5, w24
     4c8:      	ldr	x3, [sp, #0x50]
     4cc:      	ldr	x4, [sp, #0x48]
     4d0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000004d0:  ARM64_RELOC_PAGE21	l_stogir.316
     4d4:      	ldr	x16, [x16]
		00000000000004d4:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     4d8:      	str	x16, [sp, #0x38]
     4dc:      	mov	x16, #0x17              ; =23
     4e0:      	str	x16, [sp, #0x80]
     4e4:      	ldr	x6, [sp, #0x98]
     4e8:      	add	x6, x6, #0x1
     4ec:      	sxtw	x6, w6
     4f0:      	ldr	x28, [sp, #0x90]
     4f4:      	str	x0, [sp, #0x58]
     4f8:      	ldr	x19, [sp, #0x88]
     4fc:      	ldr	w0, [sp, #0x68]
     500:      	str	x2, [sp, #0x60]
     504:      	ldr	x26, [sp, #0x78]
     508:      	mov	w21, w1
     50c:      	mov	w24, w5
     510:      	mov	x1, x22
     514:      	ldr	x22, [sp, #0x70]
     518:      	str	x3, [sp, #0x50]
     51c:      	str	x4, [sp, #0x48]
     520:      	mov	x2, x6
     524:      	ldr	x23, [sp, #0x80]
     528:      	cmp	x23, #0x0
     52c:      	b.ne	0x540 <_stogir.verify.structure+0x3c8>
     530:      	cmp	x2, x22
     534:      	cset	w3, le
     538:      	ubfx	x3, x3, #0, #8
     53c:      	b	0x544 <_stogir.verify.structure+0x3cc>
     540:      	movz	x3, #0x0, lsl #48
     544:      	cmp	x3, #0x0
     548:      	b.eq	0xae0 <_stogir.verify.structure+0x968>
     54c:      	orr	w3, w2, wzr
     550:      	sxtw	x4, w3
     554:      	sub	w5, w3, #0x1
     558:      	cmp	x4, #0x0
     55c:      	cset	w6, gt
     560:      	cmp	x4, #0x4
     564:      	cset	w7, gt
     568:      	uxtb	w16, w25
     56c:      	cmp	w16, wzr
     570:      	b.eq	0x440 <_stogir.verify.structure+0x2c8>
     574:      	ldr	w8, [x26]
     578:      	uxtb	w16, w6
     57c:      	cmp	w16, wzr
     580:      	b.eq	0x438 <_stogir.verify.structure+0x2c0>
     584:      	uxtb	w16, w7
     588:      	cmp	w16, wzr
     58c:      	b.eq	0x408 <_stogir.verify.structure+0x290>
     590:      	mov	w9, #0x4                ; =4
     594:      	b	0x40c <_stogir.verify.structure+0x294>
     598:      	ubfx	x23, x23, #0, #32
     59c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000059c:  ARM64_RELOC_PAGE21	l_stogir.317
     5a0:      	ldr	x16, [x16]
		00000000000005a0:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     5a4:      	ldr	w0, [x16]
     5a8:      	cmp	x23, x0
     5ac:      	b.ne	0x5c0 <_stogir.verify.structure+0x448>
     5b0:      	mov	x0, #0x1                ; =1
     5b4:      	b	0x5d8 <_stogir.verify.structure+0x460>
     5b8:      	movz	x1, #0x0, lsl #48
     5bc:      	b	0x638 <_stogir.verify.structure+0x4c0>
     5c0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000005c0:  ARM64_RELOC_PAGE21	l_stogir.318
     5c4:      	ldr	x16, [x16]
		00000000000005c4:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     5c8:      	ldr	w0, [x16]
     5cc:      	cmp	x23, x0
     5d0:      	cset	w0, eq
     5d4:      	ubfx	x0, x0, #0, #8
     5d8:      	cmp	x0, #0x0
     5dc:      	b.eq	0xb00 <_stogir.verify.structure+0x988>
     5e0:      	str	w24, [sp, #0xa8]
     5e4:      	mov	x24, x0
     5e8:      	mov	x0, x20
     5ec:      	str	w21, [sp, #0xb0]
     5f0:      	mov	w21, w1
     5f4:      	bl	0x5f4 <_stogir.verify.structure+0x47c>
		00000000000005f4:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     5f8:      	cmp	x0, #0x0
     5fc:      	cset	w1, eq
     600:      	uxtb	w16, w1
     604:      	cmp	w16, wzr
     608:      	cset	x1, eq
     60c:      	cmp	x1, #0x0
     610:      	b.eq	0x638 <_stogir.verify.structure+0x4c0>
     614:      	ldr	w0, [x0]
     618:      	uxtb	w0, w0
     61c:      	cmp	x0, #0x48
     620:      	b.ne	0x638 <_stogir.verify.structure+0x4c0>
     624:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000624:  ARM64_RELOC_PAGE21	l_stogir.319
     628:      	ldr	x16, [x16]
		0000000000000628:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     62c:      	str	x16, [sp, #0x38]
     630:      	mov	x16, #0x25              ; =37
     634:      	str	x16, [sp, #0x80]
     638:      	sxtw	x21, w21
     63c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000063c:  ARM64_RELOC_PAGE21	l_stogir.320
     640:      	ldr	x16, [x16]
		0000000000000640:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     644:      	ldr	w0, [x16]
     648:      	cmp	x23, x0
     64c:      	b.ne	0xb14 <_stogir.verify.structure+0x99c>
     650:      	cmp	x21, #0x0
     654:      	b.gt	0x7e4 <_stogir.verify.structure+0x66c>
     658:      	ldr	x2, [sp, #0x60]
     65c:      	movz	w0, #0x0, lsl #16
     660:      	ubfx	x0, x0, #0, #32
     664:      	lsr	x16, x0, #0
     668:      	cmp	x16, #0x1
     66c:      	b.eq	0x688 <_stogir.verify.structure+0x510>
     670:      	b.lo	0x678 <_stogir.verify.structure+0x500>
     674:      	b	0x68c <_stogir.verify.structure+0x514>
     678:      	cmp	x16, #0x0
     67c:      	b.eq	0x684 <_stogir.verify.structure+0x50c>
     680:      	b	0x68c <_stogir.verify.structure+0x514>
     684:      	b	0x690 <_stogir.verify.structure+0x518>
     688:      	b	0x6a4 <_stogir.verify.structure+0x52c>
     68c:      	b	0xa4c <_stogir.verify.structure+0x8d4>
     690:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000690:  ARM64_RELOC_PAGE21	l_stogir.321
     694:      	ldr	x16, [x16]
		0000000000000694:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     698:      	str	x16, [sp, #0x38]
     69c:      	mov	x16, #0x21              ; =33
     6a0:      	str	x16, [sp, #0x80]
     6a4:      	cmp	x23, #0xf
     6a8:      	b.hs	0xb1c <_stogir.verify.structure+0x9a4>
     6ac:      	mov	x16, #0x1               ; =1
     6b0:      	lsl	x0, x16, x23
     6b4:      	mov	w17, #0x5e1c            ; =24092
     6b8:      	and	w0, w0, w17
     6bc:      	ubfx	x0, x0, #0, #32
     6c0:      	cmp	x0, #0x0
     6c4:      	b.eq	0xb34 <_stogir.verify.structure+0x9bc>
     6c8:      	cmp	x24, #0x0
     6cc:      	b.eq	0x8d0 <_stogir.verify.structure+0x758>
     6d0:      	ldr	x0, [sp, #0x58]
     6d4:      	ldr	x3, [sp, #0x50]
     6d8:      	ldr	x4, [sp, #0x48]
     6dc:      	b	0x424 <_stogir.verify.structure+0x2ac>
     6e0:      	orr	w0, w28, wzr
     6e4:      	cmp	x26, #0x78
     6e8:      	cset	w21, eq
     6ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000006ec:  ARM64_RELOC_PAGE21	l_stogir.322
     6f0:      	ldr	x16, [x16]
		00000000000006f0:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     6f4:      	add	x1, x16, x26, lsl #2
     6f8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000006f8:  ARM64_RELOC_PAGE21	l_stogir.322
     6fc:      	ldr	x16, [x16]
		00000000000006fc:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     700:      	add	x2, x16, x26, lsl #2
     704:      	cmp	x24, #0x0
     708:      	cset	w24, eq
     70c:      	orr	x26, x1, xzr
     710:      	orr	x1, x2, xzr
     714:      	mov	x2, #0x1                ; =1
     718:      	b	0x528 <_stogir.verify.structure+0x3b0>
     71c:      	nop
     720:      	movz	x1, #0x0, lsl #48
     724:      	cmp	x1, #0x0
     728:      	b.eq	0x6e0 <_stogir.verify.structure+0x568>
     72c:      	add	x1, x0, x28
     730:      	ldr	x2, [x20, #0x78]
     734:      	add	x1, x2, x1, lsl #2
     738:      	ldr	w1, [x1]
     73c:      	sxtw	x1, w1
     740:      	cmn	x1, #0x1
     744:      	b.eq	0x758 <_stogir.verify.structure+0x5e0>
     748:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000748:  ARM64_RELOC_PAGE21	l_stogir.323
     74c:      	ldr	x16, [x16]
		000000000000074c:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     750:      	str	x16, [sp, #0x38]
     754:      	mov	x23, #0x1b              ; =27
     758:      	add	x0, x0, #0x1
     75c:      	cmp	x23, #0x0
     760:      	b.ne	0x720 <_stogir.verify.structure+0x5a8>
     764:      	cmp	x0, x19
     768:      	cset	w1, lt
     76c:      	ubfx	x1, x1, #0, #8
     770:      	b	0x724 <_stogir.verify.structure+0x5ac>
     774:      	mov	w0, w19
     778:      	bl	0x778 <_stogir.verify.structure+0x600>
		0000000000000778:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     77c:      	sxtw	x0, w0
     780:      	cmn	x0, #0x1
     784:      	b.ne	0x7a4 <_stogir.verify.structure+0x62c>
     788:      	ubfx	x0, x21, #16, #16
     78c:      	cmp	x22, x0
     790:      	b.eq	0x7a4 <_stogir.verify.structure+0x62c>
     794:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000794:  ARM64_RELOC_PAGE21	l_stogir.324
     798:      	ldr	x16, [x16]
		0000000000000798:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     79c:      	str	x16, [sp, #0x38]
     7a0:      	mov	x23, #0x24              ; =36
     7a4:      	add	x0, x22, #0x4
     7a8:      	ldr	x1, [x20, #0x8]
     7ac:      	asr	x16, x0, #63
     7b0:      	lsr	x16, x16, #62
     7b4:      	add	x0, x0, x16
     7b8:      	asr	x0, x0, #2
     7bc:      	orr	x19, x0, xzr
     7c0:      	add	x0, x19, x28
     7c4:      	cmp	x0, x1
     7c8:      	b.le	0x7dc <_stogir.verify.structure+0x664>
     7cc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007cc:  ARM64_RELOC_PAGE21	l_stogir.325
     7d0:      	ldr	x16, [x16]
		00000000000007d0:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     7d4:      	str	x16, [sp, #0x38]
     7d8:      	mov	x23, #0x15              ; =21
     7dc:      	mov	x0, #0x1                ; =1
     7e0:      	b	0x75c <_stogir.verify.structure+0x5e4>
     7e4:      	ldr	x0, [x27, #0x8]
     7e8:      	cmp	x21, x0
     7ec:      	b.gt	0xb4c <_stogir.verify.structure+0x9d4>
     7f0:      	sub	x0, x21, #0x1
     7f4:      	ldr	x2, [sp, #0x60]
     7f8:      	ldr	x3, [x2, #0x28]
     7fc:      	mov	x17, #0x18              ; =24
     800:      	mul	x0, x0, x17
     804:      	add	x0, x0, x3
     808:      	ldr	x3, [x0]
     80c:      	ldr	x0, [x0, #0x8]
     810:      	ldr	x4, [x2, #0x8]
     814:      	cmp	x3, #0x0
     818:      	b.lt	0x840 <_stogir.verify.structure+0x6c8>
     81c:      	cmp	x3, x4
     820:      	b.gt	0x840 <_stogir.verify.structure+0x6c8>
     824:      	cmp	x0, #0x0
     828:      	b.lt	0x840 <_stogir.verify.structure+0x6c8>
     82c:      	sub	x3, x4, x3
     830:      	cmp	x0, x3
     834:      	b.gt	0x840 <_stogir.verify.structure+0x6c8>
     838:      	mov	w0, #0x1                ; =1
     83c:      	b	0x844 <_stogir.verify.structure+0x6cc>
     840:      	movz	w0, #0x0, lsl #16
     844:      	b	0x660 <_stogir.verify.structure+0x4e8>
     848:      	mov	w0, #-0x2               ; =-2
     84c:      	sxtw	x0, w0
     850:      	cmp	x22, x0
     854:      	b.eq	0x774 <_stogir.verify.structure+0x5fc>
     858:      	ldr	x0, [sp, #0x58]
     85c:      	ldr	x2, [sp, #0x60]
     860:      	ldr	x3, [sp, #0x50]
     864:      	ldr	x4, [sp, #0x48]
     868:      	mov	x5, x28
     86c:      	ldr	x19, [sp, #0x40]
     870:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000870:  ARM64_RELOC_PAGE21	l_stogir.326
     874:      	ldr	x16, [x16]
		0000000000000874:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     878:      	str	x16, [sp, #0x38]
     87c:      	mov	x16, #0x23              ; =35
     880:      	str	x16, [sp, #0x80]
     884:      	b	0x1fc <_stogir.verify.structure+0x84>
     888:      	cmp	x21, #0x0
     88c:      	b.ne	0xb54 <_stogir.verify.structure+0x9dc>
     890:      	uxtb	w16, w25
     894:      	cmp	w16, wzr
     898:      	b.eq	0x9c4 <_stogir.verify.structure+0x84c>
     89c:      	ldr	w1, [x22]
     8a0:      	uxtb	w16, w28
     8a4:      	cmp	w16, wzr
     8a8:      	b.eq	0xa0c <_stogir.verify.structure+0x894>
     8ac:      	uxtb	w16, w26
     8b0:      	cmp	w16, wzr
     8b4:      	b.eq	0x8bc <_stogir.verify.structure+0x744>
     8b8:      	mov	w19, #0x4               ; =4
     8bc:      	lsl	w5, w19, #2
     8c0:      	ubfx	x5, x5, #0, #32
     8c4:      	lsr	x1, x1, x5
     8c8:      	and	w1, w1, #0xf
     8cc:      	b	0xa10 <_stogir.verify.structure+0x898>
     8d0:      	cmp	x21, #0x0
     8d4:      	b.le	0xb60 <_stogir.verify.structure+0x9e8>
     8d8:      	ldr	x0, [x20, #0x8]
     8dc:      	cmp	x21, x0
     8e0:      	b.ge	0xb68 <_stogir.verify.structure+0x9f0>
     8e4:      	ldr	x0, [sp, #0x58]
     8e8:      	ldr	x1, [x0, #0x8]
     8ec:      	cmp	x21, x1
     8f0:      	b.ge	0xa1c <_stogir.verify.structure+0x8a4>
     8f4:      	ldr	x1, [x20, #0x78]
     8f8:      	add	x1, x1, x21, lsl #2
     8fc:      	ldr	w1, [x1]
     900:      	sxtw	x1, w1
     904:      	cmp	x1, #0x0
     908:      	cset	w1, ge
     90c:      	ubfx	x1, x1, #0, #8
     910:      	b	0xa20 <_stogir.verify.structure+0x8a8>
     914:      	ldr	w1, [sp, #0xb0]
     918:      	uxtb	w16, w1
     91c:      	cmp	w16, wzr
     920:      	b.eq	0xb70 <_stogir.verify.structure+0x9f8>
     924:      	ldr	w5, [sp, #0xa8]
     928:      	uxtb	w16, w5
     92c:      	cmp	w16, wzr
     930:      	b.eq	0x940 <_stogir.verify.structure+0x7c8>
     934:      	ldr	x6, [sp, #0xa0]
     938:      	cmp	x6, #0x2
     93c:      	b.eq	0x434 <_stogir.verify.structure+0x2bc>
     940:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000940:  ARM64_RELOC_PAGE21	l_stogir.327
     944:      	ldr	x16, [x16]
		0000000000000944:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     948:      	str	x16, [sp, #0x38]
     94c:      	mov	x16, #0x1a              ; =26
     950:      	str	x16, [sp, #0x80]
     954:      	b	0x434 <_stogir.verify.structure+0x2bc>
     958:      	movz	x1, #0x0, lsl #48
     95c:      	ldr	x3, [sp, #0x50]
     960:      	ldr	x4, [sp, #0x48]
     964:      	b	0x424 <_stogir.verify.structure+0x2ac>
     968:      	cmp	x21, #0x0
     96c:      	b.ge	0xb78 <_stogir.verify.structure+0xa00>
     970:      	ldr	x3, [sp, #0x50]
     974:      	ldr	x1, [x3, #0x8]
     978:      	ldr	x4, [sp, #0x48]
     97c:      	ldr	x5, [x4, #0x8]
     980:      	cmp	x1, x5
     984:      	b.ne	0xa14 <_stogir.verify.structure+0x89c>
     988:      	movz	x16, #0x0, lsl #48
     98c:      	sub	x5, x16, x21
     990:      	cmp	x5, x1
     994:      	b.gt	0xa44 <_stogir.verify.structure+0x8cc>
     998:      	sub	x1, x5, #0x1
     99c:      	ldr	x5, [x20, #0x50]
     9a0:      	add	x1, x5, x1, lsl #2
     9a4:      	ldr	w1, [x1]
     9a8:      	sxtw	x1, w1
     9ac:      	cmp	x1, #0x0
     9b0:      	cset	w1, gt
     9b4:      	ubfx	x1, x1, #0, #8
     9b8:      	b	0xa48 <_stogir.verify.structure+0x8d0>
     9bc:      	brk	#0
     9c0:      	b	0x9bc <_stogir.verify.structure+0x844>
     9c4:      	movz	w1, #0x0, lsl #16
     9c8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000009c8:  ARM64_RELOC_PAGE21	l_stogir.328
     9cc:      	ldr	x16, [x16]
		00000000000009cc:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     9d0:      	ldr	w5, [x16]
     9d4:      	ubfx	x1, x1, #0, #32
     9d8:      	cmp	x1, x5
     9dc:      	b.ne	0x9ec <_stogir.verify.structure+0x874>
     9e0:      	ldr	w1, [sp, #0xb0]
     9e4:      	ldr	w5, [sp, #0xa8]
     9e8:      	b	0x434 <_stogir.verify.structure+0x2bc>
     9ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000009ec:  ARM64_RELOC_PAGE21	l_stogir.329
     9f0:      	ldr	x16, [x16]
		00000000000009f0:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     9f4:      	ldr	w5, [x16]
     9f8:      	cmp	x1, x5
     9fc:      	b.ne	0xa24 <_stogir.verify.structure+0x8ac>
     a00:      	ldr	w1, [sp, #0xb0]
     a04:      	ldr	w5, [sp, #0xa8]
     a08:      	b	0x434 <_stogir.verify.structure+0x2bc>
     a0c:      	movz	w1, #0x0, lsl #16
     a10:      	b	0x9c8 <_stogir.verify.structure+0x850>
     a14:      	movz	x1, #0x0, lsl #48
     a18:      	b	0x424 <_stogir.verify.structure+0x2ac>
     a1c:      	movz	x1, #0x0, lsl #48
     a20:      	b	0x95c <_stogir.verify.structure+0x7e4>
     a24:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000a24:  ARM64_RELOC_PAGE21	l_stogir.330
     a28:      	ldr	x16, [x16]
		0000000000000a28:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     a2c:      	ldr	w5, [x16]
     a30:      	cmp	x1, x5
     a34:      	b.ne	0x914 <_stogir.verify.structure+0x79c>
     a38:      	ldr	w1, [sp, #0xb0]
     a3c:      	ldr	w5, [sp, #0xa8]
     a40:      	b	0x434 <_stogir.verify.structure+0x2bc>
     a44:      	movz	x1, #0x0, lsl #48
     a48:      	b	0xa18 <_stogir.verify.structure+0x8a0>
     a4c:      	brk	#0
     a50:      	b	0xa4c <_stogir.verify.structure+0x8d4>
     a54:      	str	x19, [sp, #0x30]
     a58:      	mov	x19, x0
     a5c:      	str	x22, [sp, #0x38]
     a60:      	str	x23, [sp, #0x80]
     a64:      	b	0x384 <_stogir.verify.structure+0x20c>
     a68:      	str	x19, [sp, #0x30]
     a6c:      	mov	x19, x0
     a70:      	str	x22, [sp, #0x38]
     a74:      	str	x23, [sp, #0x80]
     a78:      	b	0x384 <_stogir.verify.structure+0x20c>
     a7c:      	mov	x5, x28
     a80:      	str	x19, [sp, #0x30]
     a84:      	mov	x19, x0
     a88:      	mov	x0, x21
     a8c:      	mov	x2, x24
     a90:      	mov	x3, x25
     a94:      	mov	x4, x26
     a98:      	b	0x25c <_stogir.verify.structure+0xe4>
     a9c:      	mov	x5, x28
     aa0:      	str	x19, [sp, #0x30]
     aa4:      	mov	x19, x0
     aa8:      	mov	x0, x21
     aac:      	mov	x2, x24
     ab0:      	mov	x3, x25
     ab4:      	mov	x4, x26
     ab8:      	b	0x228 <_stogir.verify.structure+0xb0>
     abc:      	mov	x5, x28
     ac0:      	ldr	x19, [sp, #0x40]
     ac4:      	ldr	x0, [sp, #0x58]
     ac8:      	ldr	x2, [sp, #0x60]
     acc:      	ldr	x3, [sp, #0x50]
     ad0:      	ldr	x4, [sp, #0x48]
     ad4:      	b	0x228 <_stogir.verify.structure+0xb0>
     ad8:      	ldr	x0, [sp, #0x38]
     adc:      	b	0x3b8 <_stogir.verify.structure+0x240>
     ae0:      	str	x28, [sp, #0x90]
     ae4:      	ldr	x0, [sp, #0x58]
     ae8:      	str	x19, [sp, #0x88]
     aec:      	ldr	x2, [sp, #0x60]
     af0:      	str	x23, [sp, #0x80]
     af4:      	ldr	x3, [sp, #0x50]
     af8:      	ldr	x4, [sp, #0x48]
     afc:      	b	0x1e4 <_stogir.verify.structure+0x6c>
     b00:      	str	w21, [sp, #0xb0]
     b04:      	mov	w21, w1
     b08:      	str	w24, [sp, #0xa8]
     b0c:      	mov	x24, x0
     b10:      	b	0x5b8 <_stogir.verify.structure+0x440>
     b14:      	ldr	x2, [sp, #0x60]
     b18:      	b	0x6a4 <_stogir.verify.structure+0x52c>
     b1c:      	ldr	x0, [sp, #0x58]
     b20:      	ldr	w1, [sp, #0xb0]
     b24:      	ldr	w5, [sp, #0xa8]
     b28:      	ldr	x3, [sp, #0x50]
     b2c:      	ldr	x4, [sp, #0x48]
     b30:      	b	0x434 <_stogir.verify.structure+0x2bc>
     b34:      	ldr	x0, [sp, #0x58]
     b38:      	ldr	w1, [sp, #0xb0]
     b3c:      	ldr	w5, [sp, #0xa8]
     b40:      	ldr	x3, [sp, #0x50]
     b44:      	ldr	x4, [sp, #0x48]
     b48:      	b	0x434 <_stogir.verify.structure+0x2bc>
     b4c:      	ldr	x2, [sp, #0x60]
     b50:      	b	0x65c <_stogir.verify.structure+0x4e4>
     b54:      	ldr	w1, [sp, #0xb0]
     b58:      	ldr	w5, [sp, #0xa8]
     b5c:      	b	0x940 <_stogir.verify.structure+0x7c8>
     b60:      	ldr	x0, [sp, #0x58]
     b64:      	b	0x968 <_stogir.verify.structure+0x7f0>
     b68:      	ldr	x0, [sp, #0x58]
     b6c:      	b	0x958 <_stogir.verify.structure+0x7e0>
     b70:      	ldr	w5, [sp, #0xa8]
     b74:      	b	0x940 <_stogir.verify.structure+0x7c8>
     b78:      	ldr	x3, [sp, #0x50]
     b7c:      	ldr	x4, [sp, #0x48]
     b80:      	b	0x420 <_stogir.verify.structure+0x2a8>

0000000000000b84 <_stogir.verify.integer-operations-target-structured>:
     b84:      	sub	sp, sp, #0x340
     b88:      	str	x29, [sp, #0x10]
     b8c:      	str	x30, [sp, #0x18]
     b90:      	add	x29, sp, #0x10
     b94:      	str	x19, [sp, #0x2f0]
     b98:      	str	x20, [sp, #0x2f8]
     b9c:      	str	x21, [sp, #0x300]
     ba0:      	str	x22, [sp, #0x308]
     ba4:      	str	x23, [sp, #0x310]
     ba8:      	str	x24, [sp, #0x318]
     bac:      	str	x25, [sp, #0x320]
     bb0:      	str	x26, [sp, #0x328]
     bb4:      	str	x27, [sp, #0x330]
     bb8:      	str	x28, [sp, #0x338]
     bbc:      	orr	w19, w1, wzr
     bc0:      	orr	w20, w1, wzr
     bc4:      	orr	w21, w1, wzr
     bc8:      	add	x22, x0, #0x78
     bcc:      	add	x23, x0, #0x28
     bd0:      	add	x24, x0, #0x50
     bd4:      	add	x16, sp, #0x30
     bd8:      	orr	x1, x16, xzr
     bdc:      	add	x25, x1, #0x8
     be0:      	add	x16, sp, #0x50
     be4:      	orr	x1, x16, xzr
     be8:      	add	x26, x1, #0x8
     bec:      	add	x16, sp, #0xe0
     bf0:      	orr	x1, x16, xzr
     bf4:      	add	x27, x1, #0x8
     bf8:      	add	x16, sp, #0x100
     bfc:      	orr	x1, x16, xzr
     c00:      	add	x28, x1, #0x8
     c04:      	add	x16, sp, #0x120
     c08:      	orr	x1, x16, xzr
     c0c:      	add	x1, x1, #0x8
     c10:      	add	x16, sp, #0x140
     c14:      	orr	x2, x16, xzr
     c18:      	add	x2, x2, #0x8
     c1c:      	add	x16, sp, #0x160
     c20:      	orr	x3, x16, xzr
     c24:      	add	x3, x3, #0x8
     c28:      	add	x16, sp, #0x180
     c2c:      	orr	x4, x16, xzr
     c30:      	add	x4, x4, #0x8
     c34:      	add	x16, sp, #0x1a0
     c38:      	orr	x5, x16, xzr
     c3c:      	add	x5, x5, #0x8
     c40:      	add	x16, sp, #0x1f0
     c44:      	orr	x6, x16, xzr
     c48:      	add	x6, x6, #0x8
     c4c:      	mov	x7, #0x1                ; =1
     c50:      	movz	x9, #0x0, lsl #48
     c54:      	adrp	x10, 0x0 <_gap_verify_graph>
		0000000000000c54:  ARM64_RELOC_PAGE21	l_stogir.331
     c58:      	ldr	x10, [x10]
		0000000000000c58:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     c5c:      	movz	x11, #0x0, lsl #48
     c60:      	cmp	x11, #0x0
     c64:      	b.ne	0x1be4 <_stogir.verify.integer-operations-target-structured+0x1060>
     c68:      	ldr	x12, [x0, #0x8]
     c6c:      	cmp	x7, x12
     c70:      	b.ge	0x1bf8 <_stogir.verify.integer-operations-target-structured+0x1074>
     c74:      	ldr	x12, [x0]
     c78:      	add	x12, x12, x7, lsl #4
     c7c:      	ldr	x13, [x12]
     c80:      	uxtb	w14, w13
     c84:      	ldr	x12, [x12, #0x8]
     c88:      	orr	x15, x14, xzr
     c8c:      	add	x16, sp, #0x20
     c90:      	str	x13, [x16]
     c94:      	add	x16, sp, #0x20
     c98:      	str	x12, [x16, #0x8]
     c9c:      	ldr	x12, [x0, #0x78]
     ca0:      	add	x12, x12, x7, lsl #2
     ca4:      	ldr	w12, [x12]
     ca8:      	cmp	x15, #0x83
     cac:      	b.ge	0x1468 <_stogir.verify.integer-operations-target-structured+0x8e4>
     cb0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cb0:  ARM64_RELOC_PAGE21	l_stogir.332
     cb4:      	ldr	x16, [x16]
		0000000000000cb4:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     cb8:      	add	x13, x16, x15, lsl #1
     cbc:      	ldrh	w13, [x13]
     cc0:      	cmp	x15, #0xe
     cc4:      	b.lt	0x1c0c <_stogir.verify.integer-operations-target-structured+0x1088>
     cc8:      	str	x0, [sp, #0x230]
     ccc:      	cmp	x15, #0x17
     cd0:      	cset	w0, le
     cd4:      	ubfx	x0, x0, #0, #8
     cd8:      	str	x0, [sp, #0x238]
     cdc:      	orr	w0, w7, wzr
     ce0:      	str	x1, [sp, #0x240]
     ce4:      	and	w1, w13, #0x4
     ce8:      	ubfx	x1, x1, #0, #32
     cec:      	str	x8, [sp, #0x260]
     cf0:      	str	x2, [sp, #0x2b8]
     cf4:      	add	x2, sp, #0x20
     cf8:      	str	x3, [sp, #0x2a8]
     cfc:      	mov	w3, w12
     d00:      	str	x4, [sp, #0x298]
     d04:      	str	x5, [sp, #0x290]
     d08:      	str	x6, [sp, #0x288]
     d0c:      	str	x7, [sp, #0x280]
     d10:      	str	w14, [sp, #0x2a0]
     d14:      	str	w12, [sp, #0x2b0]
     d18:      	str	w0, [sp, #0x2c0]
     d1c:      	str	w19, [sp, #0x248]
     d20:      	mov	w19, w13
     d24:      	str	w20, [sp, #0x250]
     d28:      	mov	x20, x9
     d2c:      	str	w21, [sp, #0x258]
     d30:      	mov	x21, x1
     d34:      	mov	w1, w0
     d38:      	ldr	x0, [sp, #0x230]
     d3c:      	str	x24, [sp, #0x268]
     d40:      	mov	x24, x15
     d44:      	str	x23, [sp, #0x270]
     d48:      	mov	x23, x11
     d4c:      	str	x22, [sp, #0x278]
     d50:      	mov	x22, x10
     d54:      	bl	0xd54 <_stogir.verify.integer-operations-target-structured+0x1d0>
		0000000000000d54:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
     d58:      	uxtb	w1, w0
     d5c:      	cmp	x1, #0x0
     d60:      	cset	w1, ne
     d64:      	cmp	x21, #0x0
     d68:      	b.ne	0x1478 <_stogir.verify.integer-operations-target-structured+0x8f4>
     d6c:      	uxtb	w16, w1
     d70:      	cmp	w16, wzr
     d74:      	b.ne	0x1478 <_stogir.verify.integer-operations-target-structured+0x8f4>
     d78:      	str	x0, [sp, #0x2c8]
     d7c:      	mov	w21, w1
     d80:      	cmp	x24, #0x44
     d84:      	b.ne	0x14ec <_stogir.verify.integer-operations-target-structured+0x968>
     d88:      	uxtb	w16, w21
     d8c:      	cmp	w16, wzr
     d90:      	b.eq	0x14e4 <_stogir.verify.integer-operations-target-structured+0x960>
     d94:      	movz	x0, #0x0, lsl #48
     d98:      	cmp	x0, #0x0
     d9c:      	b.eq	0xdf0 <_stogir.verify.integer-operations-target-structured+0x26c>
     da0:      	add	x8, sp, #0x50
     da4:      	ldr	x0, [sp, #0x230]
     da8:      	ldr	w1, [sp, #0x2c0]
     dac:      	bl	0xdac <_stogir.verify.integer-operations-target-structured+0x228>
		0000000000000dac:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
     db0:      	add	x16, sp, #0x50
     db4:      	ldr	w0, [x16]
     db8:      	lsr	x16, x0, #0
     dbc:      	cmp	x16, #0x1
     dc0:      	b.eq	0xddc <_stogir.verify.integer-operations-target-structured+0x258>
     dc4:      	b.lo	0xdcc <_stogir.verify.integer-operations-target-structured+0x248>
     dc8:      	b	0xde0 <_stogir.verify.integer-operations-target-structured+0x25c>
     dcc:      	cmp	x16, #0x0
     dd0:      	b.eq	0xdd8 <_stogir.verify.integer-operations-target-structured+0x254>
     dd4:      	b	0xde0 <_stogir.verify.integer-operations-target-structured+0x25c>
     dd8:      	b	0x14f4 <_stogir.verify.integer-operations-target-structured+0x970>
     ddc:      	b	0xde4 <_stogir.verify.integer-operations-target-structured+0x260>
     de0:      	b	0x1500 <_stogir.verify.integer-operations-target-structured+0x97c>
     de4:      	add	x16, sp, #0x50
     de8:      	ldr	x22, [x16, #0x8]
     dec:      	ldr	x23, [x26, #0x8]
     df0:      	cmp	x24, #0x1d
     df4:      	b.ne	0x1508 <_stogir.verify.integer-operations-target-structured+0x984>
     df8:      	mov	x0, #0x1                ; =1
     dfc:      	cmp	x0, #0x0
     e00:      	b.eq	0x1520 <_stogir.verify.integer-operations-target-structured+0x99c>
     e04:      	add	x16, sp, #0x20
     e08:      	ldr	w0, [x16, #0xc]
     e0c:      	sxtw	x0, w0
     e10:      	cmp	x0, #0x0
     e14:      	b.ne	0x1518 <_stogir.verify.integer-operations-target-structured+0x994>
     e18:      	movz	x0, #0x0, lsl #48
     e1c:      	cmp	x0, #0x0
     e20:      	b.eq	0xe7c <_stogir.verify.integer-operations-target-structured+0x2f8>
     e24:      	add	x16, sp, #0x20
     e28:      	ldr	w0, [x16, #0xc]
     e2c:      	add	x8, sp, #0x70
     e30:      	mov	w1, w0
     e34:      	ldr	x0, [sp, #0x230]
     e38:      	bl	0xe38 <_stogir.verify.integer-operations-target-structured+0x2b4>
		0000000000000e38:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
     e3c:      	add	x16, sp, #0x70
     e40:      	ldr	w0, [x16]
     e44:      	lsr	x16, x0, #0
     e48:      	cmp	x16, #0x1
     e4c:      	b.eq	0xe68 <_stogir.verify.integer-operations-target-structured+0x2e4>
     e50:      	b.lo	0xe58 <_stogir.verify.integer-operations-target-structured+0x2d4>
     e54:      	b	0xe6c <_stogir.verify.integer-operations-target-structured+0x2e8>
     e58:      	cmp	x16, #0x0
     e5c:      	b.eq	0xe64 <_stogir.verify.integer-operations-target-structured+0x2e0>
     e60:      	b	0xe6c <_stogir.verify.integer-operations-target-structured+0x2e8>
     e64:      	b	0xe70 <_stogir.verify.integer-operations-target-structured+0x2ec>
     e68:      	b	0x1528 <_stogir.verify.integer-operations-target-structured+0x9a4>
     e6c:      	b	0x15d0 <_stogir.verify.integer-operations-target-structured+0xa4c>
     e70:      	adrp	x22, 0x0 <_gap_verify_graph>
		0000000000000e70:  ARM64_RELOC_PAGE21	l_stogir.333
     e74:      	ldr	x22, [x22]
		0000000000000e74:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     e78:      	mov	x23, #0x16              ; =22
     e7c:      	and	w0, w19, #0x8
     e80:      	ubfx	x0, x0, #0, #32
     e84:      	cmp	x0, #0x0
     e88:      	b.ne	0x15d8 <_stogir.verify.integer-operations-target-structured+0xa54>
     e8c:      	movz	x0, #0x0, lsl #48
     e90:      	cmp	x24, #0x2c
     e94:      	cset	w1, eq
     e98:      	cmp	x0, #0x0
     e9c:      	b.eq	0x15e0 <_stogir.verify.integer-operations-target-structured+0xa5c>
     ea0:      	mov	x0, #0x1                ; =1
     ea4:      	cmp	x0, #0x0
     ea8:      	b.eq	0xf18 <_stogir.verify.integer-operations-target-structured+0x394>
     eac:      	uxtb	w16, w1
     eb0:      	cmp	w16, wzr
     eb4:      	b.eq	0x15e8 <_stogir.verify.integer-operations-target-structured+0xa64>
     eb8:      	add	x8, sp, #0xa0
     ebc:      	ldr	x0, [sp, #0x230]
     ec0:      	ldr	w1, [sp, #0x2c0]
     ec4:      	bl	0xec4 <_stogir.verify.integer-operations-target-structured+0x340>
		0000000000000ec4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
     ec8:      	add	x16, sp, #0xa0
     ecc:      	ldr	x0, [x16]
     ed0:      	add	x16, sp, #0xa0
     ed4:      	ldr	x1, [x16, #0x8]
     ed8:      	add	x16, sp, #0xa0
     edc:      	ldr	x2, [x16, #0x10]
     ee0:      	ubfx	x0, x0, #0, #32
     ee4:      	lsr	x16, x0, #0
     ee8:      	cmp	x16, #0x1
     eec:      	b.eq	0xf08 <_stogir.verify.integer-operations-target-structured+0x384>
     ef0:      	b.lo	0xef8 <_stogir.verify.integer-operations-target-structured+0x374>
     ef4:      	b	0xf0c <_stogir.verify.integer-operations-target-structured+0x388>
     ef8:      	cmp	x16, #0x0
     efc:      	b.eq	0xf04 <_stogir.verify.integer-operations-target-structured+0x380>
     f00:      	b	0xf0c <_stogir.verify.integer-operations-target-structured+0x388>
     f04:      	b	0x1614 <_stogir.verify.integer-operations-target-structured+0xa90>
     f08:      	b	0xf10 <_stogir.verify.integer-operations-target-structured+0x38c>
     f0c:      	b	0x1620 <_stogir.verify.integer-operations-target-structured+0xa9c>
     f10:      	mov	x22, x1
     f14:      	mov	x23, x2
     f18:      	and	w0, w19, #0x10
     f1c:      	ubfx	x0, x0, #0, #32
     f20:      	cmp	x0, #0x0
     f24:      	b.ne	0x1628 <_stogir.verify.integer-operations-target-structured+0xaa4>
     f28:      	movz	x0, #0x0, lsl #48
     f2c:      	cmp	x0, #0x0
     f30:      	b.eq	0xf84 <_stogir.verify.integer-operations-target-structured+0x400>
     f34:      	add	x8, sp, #0xe0
     f38:      	ldr	x0, [sp, #0x230]
     f3c:      	ldr	w1, [sp, #0x2c0]
     f40:      	bl	0xf40 <_stogir.verify.integer-operations-target-structured+0x3bc>
		0000000000000f40:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
     f44:      	add	x16, sp, #0xe0
     f48:      	ldr	w0, [x16]
     f4c:      	lsr	x16, x0, #0
     f50:      	cmp	x16, #0x1
     f54:      	b.eq	0xf70 <_stogir.verify.integer-operations-target-structured+0x3ec>
     f58:      	b.lo	0xf60 <_stogir.verify.integer-operations-target-structured+0x3dc>
     f5c:      	b	0xf74 <_stogir.verify.integer-operations-target-structured+0x3f0>
     f60:      	cmp	x16, #0x0
     f64:      	b.eq	0xf6c <_stogir.verify.integer-operations-target-structured+0x3e8>
     f68:      	b	0xf74 <_stogir.verify.integer-operations-target-structured+0x3f0>
     f6c:      	b	0x1630 <_stogir.verify.integer-operations-target-structured+0xaac>
     f70:      	b	0xf78 <_stogir.verify.integer-operations-target-structured+0x3f4>
     f74:      	b	0x163c <_stogir.verify.integer-operations-target-structured+0xab8>
     f78:      	add	x16, sp, #0xe0
     f7c:      	ldr	x22, [x16, #0x8]
     f80:      	ldr	x23, [x27, #0x8]
     f84:      	and	w0, w19, #0x20
     f88:      	ubfx	x0, x0, #0, #32
     f8c:      	cmp	x0, #0x0
     f90:      	b.ne	0x1644 <_stogir.verify.integer-operations-target-structured+0xac0>
     f94:      	movz	x0, #0x0, lsl #48
     f98:      	cmp	x0, #0x0
     f9c:      	b.eq	0xff0 <_stogir.verify.integer-operations-target-structured+0x46c>
     fa0:      	add	x8, sp, #0x100
     fa4:      	ldr	x0, [sp, #0x230]
     fa8:      	ldr	w1, [sp, #0x2c0]
     fac:      	bl	0xfac <_stogir.verify.integer-operations-target-structured+0x428>
		0000000000000fac:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
     fb0:      	add	x16, sp, #0x100
     fb4:      	ldr	w0, [x16]
     fb8:      	lsr	x16, x0, #0
     fbc:      	cmp	x16, #0x1
     fc0:      	b.eq	0xfdc <_stogir.verify.integer-operations-target-structured+0x458>
     fc4:      	b.lo	0xfcc <_stogir.verify.integer-operations-target-structured+0x448>
     fc8:      	b	0xfe0 <_stogir.verify.integer-operations-target-structured+0x45c>
     fcc:      	cmp	x16, #0x0
     fd0:      	b.eq	0xfd8 <_stogir.verify.integer-operations-target-structured+0x454>
     fd4:      	b	0xfe0 <_stogir.verify.integer-operations-target-structured+0x45c>
     fd8:      	b	0x164c <_stogir.verify.integer-operations-target-structured+0xac8>
     fdc:      	b	0xfe4 <_stogir.verify.integer-operations-target-structured+0x460>
     fe0:      	b	0x1658 <_stogir.verify.integer-operations-target-structured+0xad4>
     fe4:      	add	x16, sp, #0x100
     fe8:      	ldr	x22, [x16, #0x8]
     fec:      	ldr	x23, [x28, #0x8]
     ff0:      	and	w0, w19, #0x40
     ff4:      	ubfx	x0, x0, #0, #32
     ff8:      	cmp	x0, #0x0
     ffc:      	b.ne	0x1660 <_stogir.verify.integer-operations-target-structured+0xadc>
    1000:      	movz	x0, #0x0, lsl #48
    1004:      	cmp	x0, #0x0
    1008:      	b.eq	0x1c14 <_stogir.verify.integer-operations-target-structured+0x1090>
    100c:      	add	x8, sp, #0x120
    1010:      	ldr	x0, [sp, #0x230]
    1014:      	ldr	w1, [sp, #0x2c0]
    1018:      	bl	0x1018 <_stogir.verify.integer-operations-target-structured+0x494>
		0000000000001018:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    101c:      	add	x16, sp, #0x120
    1020:      	ldr	w0, [x16]
    1024:      	lsr	x16, x0, #0
    1028:      	cmp	x16, #0x1
    102c:      	b.eq	0x104c <_stogir.verify.integer-operations-target-structured+0x4c8>
    1030:      	b.lo	0x1038 <_stogir.verify.integer-operations-target-structured+0x4b4>
    1034:      	b	0x1050 <_stogir.verify.integer-operations-target-structured+0x4cc>
    1038:      	cmp	x16, #0x0
    103c:      	b.eq	0x1044 <_stogir.verify.integer-operations-target-structured+0x4c0>
    1040:      	b	0x1050 <_stogir.verify.integer-operations-target-structured+0x4cc>
    1044:      	ldr	x0, [sp, #0x240]
    1048:      	b	0x1668 <_stogir.verify.integer-operations-target-structured+0xae4>
    104c:      	b	0x1054 <_stogir.verify.integer-operations-target-structured+0x4d0>
    1050:      	b	0x1674 <_stogir.verify.integer-operations-target-structured+0xaf0>
    1054:      	add	x16, sp, #0x120
    1058:      	ldr	x22, [x16, #0x8]
    105c:      	ldr	x0, [sp, #0x240]
    1060:      	ldr	x23, [x0, #0x8]
    1064:      	and	w1, w19, #0x80
    1068:      	ubfx	x1, x1, #0, #32
    106c:      	cmp	x1, #0x0
    1070:      	b.ne	0x167c <_stogir.verify.integer-operations-target-structured+0xaf8>
    1074:      	movz	x1, #0x0, lsl #48
    1078:      	cmp	x1, #0x0
    107c:      	b.eq	0x1c1c <_stogir.verify.integer-operations-target-structured+0x1098>
    1080:      	add	x8, sp, #0x140
    1084:      	ldr	w1, [sp, #0x2c0]
    1088:      	str	x0, [sp, #0x240]
    108c:      	ldr	x0, [sp, #0x230]
    1090:      	bl	0x1090 <_stogir.verify.integer-operations-target-structured+0x50c>
		0000000000001090:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    1094:      	add	x16, sp, #0x140
    1098:      	ldr	w0, [x16]
    109c:      	lsr	x16, x0, #0
    10a0:      	cmp	x16, #0x1
    10a4:      	b.eq	0x10c4 <_stogir.verify.integer-operations-target-structured+0x540>
    10a8:      	b.lo	0x10b0 <_stogir.verify.integer-operations-target-structured+0x52c>
    10ac:      	b	0x10c8 <_stogir.verify.integer-operations-target-structured+0x544>
    10b0:      	cmp	x16, #0x0
    10b4:      	b.eq	0x10bc <_stogir.verify.integer-operations-target-structured+0x538>
    10b8:      	b	0x10c8 <_stogir.verify.integer-operations-target-structured+0x544>
    10bc:      	ldr	x0, [sp, #0x2b8]
    10c0:      	b	0x1684 <_stogir.verify.integer-operations-target-structured+0xb00>
    10c4:      	b	0x10cc <_stogir.verify.integer-operations-target-structured+0x548>
    10c8:      	b	0x1690 <_stogir.verify.integer-operations-target-structured+0xb0c>
    10cc:      	add	x16, sp, #0x140
    10d0:      	ldr	x22, [x16, #0x8]
    10d4:      	ldr	x0, [sp, #0x2b8]
    10d8:      	ldr	x23, [x0, #0x8]
    10dc:      	and	w1, w19, #0x100
    10e0:      	ubfx	x1, x1, #0, #32
    10e4:      	cmp	x1, #0x0
    10e8:      	b.ne	0x1698 <_stogir.verify.integer-operations-target-structured+0xb14>
    10ec:      	movz	x1, #0x0, lsl #48
    10f0:      	cmp	x1, #0x0
    10f4:      	b.eq	0x1c28 <_stogir.verify.integer-operations-target-structured+0x10a4>
    10f8:      	add	x8, sp, #0x160
    10fc:      	ldr	w1, [sp, #0x2c0]
    1100:      	ldr	w2, [sp, #0x250]
    1104:      	str	x0, [sp, #0x2b8]
    1108:      	ldr	x0, [sp, #0x230]
    110c:      	bl	0x110c <_stogir.verify.integer-operations-target-structured+0x588>
		000000000000110c:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1110:      	add	x16, sp, #0x160
    1114:      	ldr	w0, [x16]
    1118:      	lsr	x16, x0, #0
    111c:      	cmp	x16, #0x1
    1120:      	b.eq	0x1140 <_stogir.verify.integer-operations-target-structured+0x5bc>
    1124:      	b.lo	0x112c <_stogir.verify.integer-operations-target-structured+0x5a8>
    1128:      	b	0x1144 <_stogir.verify.integer-operations-target-structured+0x5c0>
    112c:      	cmp	x16, #0x0
    1130:      	b.eq	0x1138 <_stogir.verify.integer-operations-target-structured+0x5b4>
    1134:      	b	0x1144 <_stogir.verify.integer-operations-target-structured+0x5c0>
    1138:      	ldr	x0, [sp, #0x2a8]
    113c:      	b	0x16a0 <_stogir.verify.integer-operations-target-structured+0xb1c>
    1140:      	b	0x1148 <_stogir.verify.integer-operations-target-structured+0x5c4>
    1144:      	b	0x16ac <_stogir.verify.integer-operations-target-structured+0xb28>
    1148:      	add	x16, sp, #0x160
    114c:      	ldr	x22, [x16, #0x8]
    1150:      	ldr	x0, [sp, #0x2a8]
    1154:      	ldr	x23, [x0, #0x8]
    1158:      	and	w1, w19, #0x200
    115c:      	ubfx	x1, x1, #0, #32
    1160:      	cmp	x1, #0x0
    1164:      	b.ne	0x16b4 <_stogir.verify.integer-operations-target-structured+0xb30>
    1168:      	movz	x1, #0x0, lsl #48
    116c:      	cmp	x1, #0x0
    1170:      	b.eq	0x1c34 <_stogir.verify.integer-operations-target-structured+0x10b0>
    1174:      	add	x8, sp, #0x180
    1178:      	ldr	w1, [sp, #0x2c0]
    117c:      	ldr	w2, [sp, #0x258]
    1180:      	str	x0, [sp, #0x2a8]
    1184:      	ldr	x0, [sp, #0x230]
    1188:      	bl	0x1188 <_stogir.verify.integer-operations-target-structured+0x604>
		0000000000001188:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    118c:      	add	x16, sp, #0x180
    1190:      	ldr	w0, [x16]
    1194:      	lsr	x16, x0, #0
    1198:      	cmp	x16, #0x1
    119c:      	b.eq	0x11bc <_stogir.verify.integer-operations-target-structured+0x638>
    11a0:      	b.lo	0x11a8 <_stogir.verify.integer-operations-target-structured+0x624>
    11a4:      	b	0x11c0 <_stogir.verify.integer-operations-target-structured+0x63c>
    11a8:      	cmp	x16, #0x0
    11ac:      	b.eq	0x11b4 <_stogir.verify.integer-operations-target-structured+0x630>
    11b0:      	b	0x11c0 <_stogir.verify.integer-operations-target-structured+0x63c>
    11b4:      	ldr	x0, [sp, #0x298]
    11b8:      	b	0x16bc <_stogir.verify.integer-operations-target-structured+0xb38>
    11bc:      	b	0x11c4 <_stogir.verify.integer-operations-target-structured+0x640>
    11c0:      	b	0x16c8 <_stogir.verify.integer-operations-target-structured+0xb44>
    11c4:      	add	x16, sp, #0x180
    11c8:      	ldr	x22, [x16, #0x8]
    11cc:      	ldr	x0, [sp, #0x298]
    11d0:      	ldr	x23, [x0, #0x8]
    11d4:      	cmp	x24, #0x3c
    11d8:      	b.ne	0x1c40 <_stogir.verify.integer-operations-target-structured+0x10bc>
    11dc:      	add	x8, sp, #0x1a0
    11e0:      	ldr	w1, [sp, #0x2c0]
    11e4:      	str	x0, [sp, #0x298]
    11e8:      	ldr	x0, [sp, #0x230]
    11ec:      	bl	0x11ec <_stogir.verify.integer-operations-target-structured+0x668>
		00000000000011ec:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    11f0:      	add	x16, sp, #0x1a0
    11f4:      	ldr	w0, [x16]
    11f8:      	lsr	x16, x0, #0
    11fc:      	cmp	x16, #0x1
    1200:      	b.eq	0x1220 <_stogir.verify.integer-operations-target-structured+0x69c>
    1204:      	b.lo	0x120c <_stogir.verify.integer-operations-target-structured+0x688>
    1208:      	b	0x1224 <_stogir.verify.integer-operations-target-structured+0x6a0>
    120c:      	cmp	x16, #0x0
    1210:      	b.eq	0x1218 <_stogir.verify.integer-operations-target-structured+0x694>
    1214:      	b	0x1224 <_stogir.verify.integer-operations-target-structured+0x6a0>
    1218:      	ldr	x0, [sp, #0x290]
    121c:      	b	0x16d0 <_stogir.verify.integer-operations-target-structured+0xb4c>
    1220:      	b	0x1228 <_stogir.verify.integer-operations-target-structured+0x6a4>
    1224:      	b	0x16dc <_stogir.verify.integer-operations-target-structured+0xb58>
    1228:      	add	x16, sp, #0x1a0
    122c:      	ldr	x22, [x16, #0x8]
    1230:      	ldr	x0, [sp, #0x290]
    1234:      	ldr	x23, [x0, #0x8]
    1238:      	cmp	x24, #0x78
    123c:      	b.ne	0x1c4c <_stogir.verify.integer-operations-target-structured+0x10c8>
    1240:      	add	x16, sp, #0x20
    1244:      	ldr	w1, [x16]
    1248:      	ubfx	x1, x1, #8, #8
    124c:      	cmp	x1, #0x0
    1250:      	b.ne	0x16e4 <_stogir.verify.integer-operations-target-structured+0xb60>
    1254:      	add	x16, sp, #0x20
    1258:      	ldr	w1, [x16, #0x8]
    125c:      	sxtw	x1, w1
    1260:      	cmp	x1, #0x0
    1264:      	b.eq	0x1274 <_stogir.verify.integer-operations-target-structured+0x6f0>
    1268:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001268:  ARM64_RELOC_PAGE21	l_stogir.334
    126c:      	ldr	x22, [x22]
		000000000000126c:  ARM64_RELOC_PAGEOFF12	l_stogir.334
    1270:      	mov	x23, #0x1f              ; =31
    1274:      	str	x0, [sp, #0x290]
    1278:      	add	x0, x20, #0x1
    127c:      	sxtw	x20, w0
    1280:      	ldr	x0, [sp, #0x2c8]
    1284:      	uxth	w0, w0
    1288:      	mov	w17, #0x8               ; =8
    128c:      	uxth	w16, w0
    1290:      	ubfx	w17, w17, #0, #4
    1294:      	lsr	w0, w16, w17
    1298:      	uxth	w0, w0
    129c:      	uxtb	w0, w0
    12a0:      	cmp	x0, #0x0
    12a4:      	b.eq	0x1c54 <_stogir.verify.integer-operations-target-structured+0x10d0>
    12a8:      	add	x8, sp, #0x1f0
    12ac:      	ldr	w1, [sp, #0x2c0]
    12b0:      	str	x25, [sp, #0x2d0]
    12b4:      	mov	x25, x0
    12b8:      	ldr	x0, [sp, #0x230]
    12bc:      	bl	0x12bc <_stogir.verify.integer-operations-target-structured+0x738>
		00000000000012bc:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    12c0:      	add	x16, sp, #0x1f0
    12c4:      	ldr	w0, [x16]
    12c8:      	lsr	x16, x0, #0
    12cc:      	cmp	x16, #0x1
    12d0:      	b.eq	0x12f0 <_stogir.verify.integer-operations-target-structured+0x76c>
    12d4:      	b.lo	0x12dc <_stogir.verify.integer-operations-target-structured+0x758>
    12d8:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x770>
    12dc:      	cmp	x16, #0x0
    12e0:      	b.eq	0x12e8 <_stogir.verify.integer-operations-target-structured+0x764>
    12e4:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x770>
    12e8:      	ldr	x0, [sp, #0x288]
    12ec:      	b	0x177c <_stogir.verify.integer-operations-target-structured+0xbf8>
    12f0:      	b	0x12f8 <_stogir.verify.integer-operations-target-structured+0x774>
    12f4:      	b	0x1788 <_stogir.verify.integer-operations-target-structured+0xc04>
    12f8:      	add	x16, sp, #0x1f0
    12fc:      	ldr	x22, [x16, #0x8]
    1300:      	ldr	x0, [sp, #0x288]
    1304:      	ldr	x23, [x0, #0x8]
    1308:      	uxtb	w16, w21
    130c:      	cmp	w16, wzr
    1310:      	b.eq	0x1790 <_stogir.verify.integer-operations-target-structured+0xc0c>
    1314:      	movz	x1, #0x0, lsl #48
    1318:      	and	w2, w19, #0x1
    131c:      	and	w3, w19, #0x2
    1320:      	ubfx	x2, x2, #0, #32
    1324:      	ubfx	x3, x3, #0, #32
    1328:      	cmp	x2, #0x0
    132c:      	cset	w2, eq
    1330:      	cmp	x3, #0x0
    1334:      	cset	w3, eq
    1338:      	uxtb	w16, w2
    133c:      	cmp	w16, wzr
    1340:      	cset	x19, eq
    1344:      	uxtb	w16, w3
    1348:      	cmp	w16, wzr
    134c:      	cset	x21, eq
    1350:      	cmp	x1, #0x0
    1354:      	b.eq	0x1c64 <_stogir.verify.integer-operations-target-structured+0x10e0>
    1358:      	cmp	x25, #0x0
    135c:      	b.eq	0x1798 <_stogir.verify.integer-operations-target-structured+0xc14>
    1360:      	movz	x1, #0x0, lsl #48
    1364:      	cmp	x1, #0x0
    1368:      	b.eq	0x1c6c <_stogir.verify.integer-operations-target-structured+0x10e8>
    136c:      	ldr	x25, [sp, #0x238]
    1370:      	cmp	x25, #0x0
    1374:      	b.eq	0x17a0 <_stogir.verify.integer-operations-target-structured+0xc1c>
    1378:      	mov	x1, #0x1                ; =1
    137c:      	cmp	x1, #0x0
    1380:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0x10f0>
    1384:      	ldr	w1, [sp, #0x2c0]
    1388:      	str	x0, [sp, #0x288]
    138c:      	ldr	x0, [sp, #0x230]
    1390:      	mov	x2, #0x1                ; =1
    1394:      	bl	0x1394 <_stogir.verify.integer-operations-target-structured+0x810>
		0000000000001394:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1398:      	ubfx	x0, x0, #0, #32
    139c:      	lsr	x16, x0, #0
    13a0:      	cmp	x16, #0x1
    13a4:      	b.eq	0x13c0 <_stogir.verify.integer-operations-target-structured+0x83c>
    13a8:      	b.lo	0x13b0 <_stogir.verify.integer-operations-target-structured+0x82c>
    13ac:      	b	0x13c4 <_stogir.verify.integer-operations-target-structured+0x840>
    13b0:      	cmp	x16, #0x0
    13b4:      	b.eq	0x13bc <_stogir.verify.integer-operations-target-structured+0x838>
    13b8:      	b	0x13c4 <_stogir.verify.integer-operations-target-structured+0x840>
    13bc:      	b	0x13c8 <_stogir.verify.integer-operations-target-structured+0x844>
    13c0:      	b	0x17c8 <_stogir.verify.integer-operations-target-structured+0xc44>
    13c4:      	b	0x1b70 <_stogir.verify.integer-operations-target-structured+0xfec>
    13c8:      	str	x26, [sp, #0x2d8]
    13cc:      	str	x27, [sp, #0x2e0]
    13d0:      	str	x28, [sp, #0x2e8]
    13d4:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		00000000000013d4:  ARM64_RELOC_PAGE21	l_stogir.335
    13d8:      	ldr	x22, [x22]
		00000000000013d8:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    13dc:      	mov	x23, #0x17              ; =23
    13e0:      	add	x0, x20, #0x1
    13e4:      	sxtw	x20, w0
    13e8:      	ldr	w0, [sp, #0x2b0]
    13ec:      	sxtw	x0, w0
    13f0:      	add	x0, x0, #0x4
    13f4:      	asr	x16, x0, #63
    13f8:      	lsr	x16, x16, #62
    13fc:      	add	x0, x0, x16
    1400:      	asr	x0, x0, #2
    1404:      	ldr	x1, [sp, #0x280]
    1408:      	add	x1, x0, x1
    140c:      	ldr	x8, [sp, #0x260]
    1410:      	ldr	x0, [sp, #0x230]
    1414:      	ldr	w19, [sp, #0x248]
    1418:      	ldr	x25, [sp, #0x2d0]
    141c:      	ldr	x26, [sp, #0x2d8]
    1420:      	ldr	x27, [sp, #0x2e0]
    1424:      	ldr	x28, [sp, #0x2e8]
    1428:      	ldr	x2, [sp, #0x2b8]
    142c:      	ldr	x3, [sp, #0x2a8]
    1430:      	ldr	w21, [sp, #0x258]
    1434:      	ldr	x4, [sp, #0x298]
    1438:      	ldr	x5, [sp, #0x290]
    143c:      	ldr	x6, [sp, #0x288]
    1440:      	ldr	x24, [sp, #0x268]
    1444:      	mov	x7, x1
    1448:      	ldr	x1, [sp, #0x240]
    144c:      	mov	x9, x20
    1450:      	ldr	w20, [sp, #0x250]
    1454:      	mov	x10, x22
    1458:      	ldr	x22, [sp, #0x278]
    145c:      	mov	x11, x23
    1460:      	ldr	x23, [sp, #0x270]
    1464:      	b	0xc60 <_stogir.verify.integer-operations-target-structured+0xdc>
    1468:      	movz	w13, #0x0, lsl #16
    146c:      	b	0xcc0 <_stogir.verify.integer-operations-target-structured+0x13c>
    1470:      	movz	x0, #0x0, lsl #48
    1474:      	b	0xcd8 <_stogir.verify.integer-operations-target-structured+0x154>
    1478:      	add	x8, sp, #0x30
    147c:      	ldr	w2, [sp, #0x248]
    1480:      	str	x0, [sp, #0x2c8]
    1484:      	ldr	x0, [sp, #0x230]
    1488:      	mov	w21, w1
    148c:      	ldr	w1, [sp, #0x2c0]
    1490:      	bl	0x1490 <_stogir.verify.integer-operations-target-structured+0x90c>
		0000000000001490:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    1494:      	add	x16, sp, #0x30
    1498:      	ldr	w0, [x16]
    149c:      	lsr	x16, x0, #0
    14a0:      	cmp	x16, #0x1
    14a4:      	b.eq	0x14c0 <_stogir.verify.integer-operations-target-structured+0x93c>
    14a8:      	b.lo	0x14b0 <_stogir.verify.integer-operations-target-structured+0x92c>
    14ac:      	b	0x14c4 <_stogir.verify.integer-operations-target-structured+0x940>
    14b0:      	cmp	x16, #0x0
    14b4:      	b.eq	0x14bc <_stogir.verify.integer-operations-target-structured+0x938>
    14b8:      	b	0x14c4 <_stogir.verify.integer-operations-target-structured+0x940>
    14bc:      	b	0x14d8 <_stogir.verify.integer-operations-target-structured+0x954>
    14c0:      	b	0x14c8 <_stogir.verify.integer-operations-target-structured+0x944>
    14c4:      	b	0x1b78 <_stogir.verify.integer-operations-target-structured+0xff4>
    14c8:      	add	x16, sp, #0x30
    14cc:      	ldr	x22, [x16, #0x8]
    14d0:      	ldr	x23, [x25, #0x8]
    14d4:      	b	0xd80 <_stogir.verify.integer-operations-target-structured+0x1fc>
    14d8:      	add	x0, x20, #0x1
    14dc:      	sxtw	x20, w0
    14e0:      	b	0x14d4 <_stogir.verify.integer-operations-target-structured+0x950>
    14e4:      	mov	x0, #0x1                ; =1
    14e8:      	b	0xd98 <_stogir.verify.integer-operations-target-structured+0x214>
    14ec:      	movz	x0, #0x0, lsl #48
    14f0:      	b	0xd98 <_stogir.verify.integer-operations-target-structured+0x214>
    14f4:      	add	x0, x20, #0x1
    14f8:      	sxtw	x20, w0
    14fc:      	b	0xdf0 <_stogir.verify.integer-operations-target-structured+0x26c>
    1500:      	brk	#0
    1504:      	b	0x1500 <_stogir.verify.integer-operations-target-structured+0x97c>
    1508:      	cmp	x24, #0x1e
    150c:      	cset	w0, eq
    1510:      	ubfx	x0, x0, #0, #8
    1514:      	b	0xdfc <_stogir.verify.integer-operations-target-structured+0x278>
    1518:      	mov	x0, #0x1                ; =1
    151c:      	b	0xe1c <_stogir.verify.integer-operations-target-structured+0x298>
    1520:      	movz	x0, #0x0, lsl #48
    1524:      	b	0xe1c <_stogir.verify.integer-operations-target-structured+0x298>
    1528:      	add	x16, sp, #0x70
    152c:      	ldr	x0, [x16, #0x8]
    1530:      	add	x16, sp, #0x20
    1534:      	ldr	w1, [x16, #0xc]
    1538:      	sxtw	x1, w1
    153c:      	cmp	x1, #0x0
    1540:      	b.ge	0x1560 <_stogir.verify.integer-operations-target-structured+0x9dc>
    1544:      	mov	x0, #0x1                ; =1
    1548:      	cmp	x0, #0x0
    154c:      	b.eq	0x155c <_stogir.verify.integer-operations-target-structured+0x9d8>
    1550:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001550:  ARM64_RELOC_PAGE21	l_stogir.336
    1554:      	ldr	x22, [x22]
		0000000000001554:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    1558:      	mov	x23, #0x2d              ; =45
    155c:      	b	0xe7c <_stogir.verify.integer-operations-target-structured+0x2f8>
    1560:      	uxtb	w0, w0
    1564:      	cmp	x0, #0x83
    1568:      	b.ge	0x15c0 <_stogir.verify.integer-operations-target-structured+0xa3c>
    156c:      	adrp	x17, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		000000000000156c:  ARM64_RELOC_PAGE21	l_stogir.337
    1570:      	ldr	x17, [x17]
		0000000000001570:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    1574:      	add	x1, x0, x17
    1578:      	ldrb	w1, [x1]
    157c:      	uxtb	w16, w1
    1580:      	and	w1, w16, #0x2
    1584:      	uxtb	w1, w1
    1588:      	ubfx	x1, x1, #0, #8
    158c:      	cmp	x1, #0x0
    1590:      	cset	w1, eq
    1594:      	uxtb	w16, w1
    1598:      	cmp	w16, wzr
    159c:      	cset	x1, eq
    15a0:      	cmp	x1, #0x0
    15a4:      	b.ne	0x15c8 <_stogir.verify.integer-operations-target-structured+0xa44>
    15a8:      	cmp	x0, #0x65
    15ac:      	b.eq	0x15c8 <_stogir.verify.integer-operations-target-structured+0xa44>
    15b0:      	cmp	x0, #0x66
    15b4:      	b.eq	0x15c8 <_stogir.verify.integer-operations-target-structured+0xa44>
    15b8:      	mov	x0, #0x1                ; =1
    15bc:      	b	0x1548 <_stogir.verify.integer-operations-target-structured+0x9c4>
    15c0:      	movz	w1, #0x0, lsl #16
    15c4:      	b	0x157c <_stogir.verify.integer-operations-target-structured+0x9f8>
    15c8:      	movz	x0, #0x0, lsl #48
    15cc:      	b	0x15bc <_stogir.verify.integer-operations-target-structured+0xa38>
    15d0:      	brk	#0
    15d4:      	b	0x15d0 <_stogir.verify.integer-operations-target-structured+0xa4c>
    15d8:      	mov	x0, #0x1                ; =1
    15dc:      	b	0xe90 <_stogir.verify.integer-operations-target-structured+0x30c>
    15e0:      	ubfx	x0, x1, #0, #8
    15e4:      	b	0xea4 <_stogir.verify.integer-operations-target-structured+0x320>
    15e8:      	add	x8, sp, #0xc0
    15ec:      	ldr	x0, [sp, #0x230]
    15f0:      	ldr	w1, [sp, #0x2c0]
    15f4:      	bl	0x15f4 <_stogir.verify.integer-operations-target-structured+0xa70>
		00000000000015f4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    15f8:      	add	x16, sp, #0xc0
    15fc:      	ldr	x0, [x16]
    1600:      	add	x16, sp, #0xc0
    1604:      	ldr	x1, [x16, #0x8]
    1608:      	add	x16, sp, #0xc0
    160c:      	ldr	x2, [x16, #0x10]
    1610:      	b	0xee0 <_stogir.verify.integer-operations-target-structured+0x35c>
    1614:      	add	x0, x20, #0x1
    1618:      	sxtw	x20, w0
    161c:      	b	0xf18 <_stogir.verify.integer-operations-target-structured+0x394>
    1620:      	brk	#0
    1624:      	b	0x1620 <_stogir.verify.integer-operations-target-structured+0xa9c>
    1628:      	mov	x0, #0x1                ; =1
    162c:      	b	0xf2c <_stogir.verify.integer-operations-target-structured+0x3a8>
    1630:      	add	x0, x20, #0x1
    1634:      	sxtw	x20, w0
    1638:      	b	0xf84 <_stogir.verify.integer-operations-target-structured+0x400>
    163c:      	brk	#0
    1640:      	b	0x163c <_stogir.verify.integer-operations-target-structured+0xab8>
    1644:      	mov	x0, #0x1                ; =1
    1648:      	b	0xf98 <_stogir.verify.integer-operations-target-structured+0x414>
    164c:      	add	x0, x20, #0x1
    1650:      	sxtw	x20, w0
    1654:      	b	0xff0 <_stogir.verify.integer-operations-target-structured+0x46c>
    1658:      	brk	#0
    165c:      	b	0x1658 <_stogir.verify.integer-operations-target-structured+0xad4>
    1660:      	mov	x0, #0x1                ; =1
    1664:      	b	0x1004 <_stogir.verify.integer-operations-target-structured+0x480>
    1668:      	add	x1, x20, #0x1
    166c:      	sxtw	x20, w1
    1670:      	b	0x1064 <_stogir.verify.integer-operations-target-structured+0x4e0>
    1674:      	brk	#0
    1678:      	b	0x1674 <_stogir.verify.integer-operations-target-structured+0xaf0>
    167c:      	mov	x1, #0x1                ; =1
    1680:      	b	0x1078 <_stogir.verify.integer-operations-target-structured+0x4f4>
    1684:      	add	x1, x20, #0x1
    1688:      	sxtw	x20, w1
    168c:      	b	0x10dc <_stogir.verify.integer-operations-target-structured+0x558>
    1690:      	brk	#0
    1694:      	b	0x1690 <_stogir.verify.integer-operations-target-structured+0xb0c>
    1698:      	mov	x1, #0x1                ; =1
    169c:      	b	0x10f0 <_stogir.verify.integer-operations-target-structured+0x56c>
    16a0:      	add	x1, x20, #0x1
    16a4:      	sxtw	x20, w1
    16a8:      	b	0x1158 <_stogir.verify.integer-operations-target-structured+0x5d4>
    16ac:      	brk	#0
    16b0:      	b	0x16ac <_stogir.verify.integer-operations-target-structured+0xb28>
    16b4:      	mov	x1, #0x1                ; =1
    16b8:      	b	0x116c <_stogir.verify.integer-operations-target-structured+0x5e8>
    16bc:      	add	x1, x20, #0x1
    16c0:      	sxtw	x20, w1
    16c4:      	b	0x11d4 <_stogir.verify.integer-operations-target-structured+0x650>
    16c8:      	brk	#0
    16cc:      	b	0x16c8 <_stogir.verify.integer-operations-target-structured+0xb44>
    16d0:      	add	x1, x20, #0x1
    16d4:      	sxtw	x20, w1
    16d8:      	b	0x1238 <_stogir.verify.integer-operations-target-structured+0x6b4>
    16dc:      	brk	#0
    16e0:      	b	0x16dc <_stogir.verify.integer-operations-target-structured+0xb58>
    16e4:      	add	x16, sp, #0x20
    16e8:      	ldr	w1, [x16, #0x8]
    16ec:      	add	x8, sp, #0x1c0
    16f0:      	str	x0, [sp, #0x290]
    16f4:      	ldr	x0, [sp, #0x230]
    16f8:      	bl	0x16f8 <_stogir.verify.integer-operations-target-structured+0xb74>
		00000000000016f8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    16fc:      	add	x16, sp, #0x1c0
    1700:      	ldr	w0, [x16]
    1704:      	lsr	x16, x0, #0
    1708:      	cmp	x16, #0x1
    170c:      	b.eq	0x1728 <_stogir.verify.integer-operations-target-structured+0xba4>
    1710:      	b.lo	0x1718 <_stogir.verify.integer-operations-target-structured+0xb94>
    1714:      	b	0x172c <_stogir.verify.integer-operations-target-structured+0xba8>
    1718:      	cmp	x16, #0x0
    171c:      	b.eq	0x1724 <_stogir.verify.integer-operations-target-structured+0xba0>
    1720:      	b	0x172c <_stogir.verify.integer-operations-target-structured+0xba8>
    1724:      	b	0x1730 <_stogir.verify.integer-operations-target-structured+0xbac>
    1728:      	b	0x1740 <_stogir.verify.integer-operations-target-structured+0xbbc>
    172c:      	b	0x1774 <_stogir.verify.integer-operations-target-structured+0xbf0>
    1730:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001730:  ARM64_RELOC_PAGE21	l_stogir.338
    1734:      	ldr	x22, [x22]
		0000000000001734:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    1738:      	mov	x23, #0x14              ; =20
    173c:      	b	0x1278 <_stogir.verify.integer-operations-target-structured+0x6f4>
    1740:      	add	x16, sp, #0x1c0
    1744:      	ldr	x0, [x16, #0x8]
    1748:      	add	x16, sp, #0x20
    174c:      	ldr	w1, [x16]
    1750:      	ubfx	x0, x0, #0, #32
    1754:      	ubfx	x1, x1, #8, #8
    1758:      	ubfx	x0, x0, #8, #8
    175c:      	cmp	x0, x1
    1760:      	b.eq	0x1770 <_stogir.verify.integer-operations-target-structured+0xbec>
    1764:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001764:  ARM64_RELOC_PAGE21	l_stogir.339
    1768:      	ldr	x22, [x22]
		0000000000001768:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    176c:      	mov	x23, #0x1a              ; =26
    1770:      	b	0x173c <_stogir.verify.integer-operations-target-structured+0xbb8>
    1774:      	brk	#0
    1778:      	b	0x1774 <_stogir.verify.integer-operations-target-structured+0xbf0>
    177c:      	add	x1, x20, #0x1
    1780:      	sxtw	x20, w1
    1784:      	b	0x1308 <_stogir.verify.integer-operations-target-structured+0x784>
    1788:      	brk	#0
    178c:      	b	0x1788 <_stogir.verify.integer-operations-target-structured+0xc04>
    1790:      	mov	x1, #0x1                ; =1
    1794:      	b	0x1318 <_stogir.verify.integer-operations-target-structured+0x794>
    1798:      	mov	x1, #0x1                ; =1
    179c:      	b	0x1364 <_stogir.verify.integer-operations-target-structured+0x7e0>
    17a0:      	cmp	x19, #0x0
    17a4:      	b.eq	0x17b0 <_stogir.verify.integer-operations-target-structured+0xc2c>
    17a8:      	mov	x1, #0x1                ; =1
    17ac:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x7f8>
    17b0:      	mov	x1, x21
    17b4:      	b	0x17ac <_stogir.verify.integer-operations-target-structured+0xc28>
    17b8:      	movz	x1, #0x0, lsl #48
    17bc:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x7f8>
    17c0:      	movz	x1, #0x0, lsl #48
    17c4:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x7f8>
    17c8:      	sxtw	x1, w1
    17cc:      	cmp	x1, #0x0
    17d0:      	cset	w0, gt
    17d4:      	movz	x16, #0x0, lsl #48
    17d8:      	sub	x2, x16, x1
    17dc:      	sub	x3, x2, #0x1
    17e0:      	uxtb	w16, w0
    17e4:      	cmp	w16, wzr
    17e8:      	b.eq	0x1c88 <_stogir.verify.integer-operations-target-structured+0x1104>
    17ec:      	ldr	x4, [sp, #0x230]
    17f0:      	ldr	x2, [x4, #0x8]
    17f4:      	cmp	x1, x2
    17f8:      	b.ge	0x1c94 <_stogir.verify.integer-operations-target-structured+0x1110>
    17fc:      	ldr	x5, [sp, #0x278]
    1800:      	ldr	x2, [x5, #0x8]
    1804:      	cmp	x1, x2
    1808:      	b.ge	0x1880 <_stogir.verify.integer-operations-target-structured+0xcfc>
    180c:      	ldr	x2, [x4, #0x78]
    1810:      	add	x2, x2, x1, lsl #2
    1814:      	ldr	w2, [x2]
    1818:      	sxtw	x2, w2
    181c:      	cmp	x2, #0x0
    1820:      	cset	w2, ge
    1824:      	ubfx	x2, x2, #0, #8
    1828:      	ldr	x6, [sp, #0x270]
    182c:      	ldr	x8, [sp, #0x268]
    1830:      	cmp	x2, #0x0
    1834:      	b.eq	0x18fc <_stogir.verify.integer-operations-target-structured+0xd78>
    1838:      	uxtb	w16, w0
    183c:      	cmp	w16, wzr
    1840:      	b.eq	0x18f0 <_stogir.verify.integer-operations-target-structured+0xd6c>
    1844:      	ldr	x0, [x4]
    1848:      	add	x0, x0, x1, lsl #4
    184c:      	cmp	x0, #0x0
    1850:      	b.ne	0x1904 <_stogir.verify.integer-operations-target-structured+0xd80>
    1854:      	str	x4, [sp, #0x230]
    1858:      	str	x5, [sp, #0x278]
    185c:      	str	x26, [sp, #0x2d8]
    1860:      	str	x27, [sp, #0x2e0]
    1864:      	str	x28, [sp, #0x2e8]
    1868:      	str	x6, [sp, #0x270]
    186c:      	str	x8, [sp, #0x268]
    1870:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001870:  ARM64_RELOC_PAGE21	l_stogir.335
    1874:      	ldr	x22, [x22]
		0000000000001874:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    1878:      	mov	x23, #0x17              ; =23
    187c:      	b	0x13e0 <_stogir.verify.integer-operations-target-structured+0x85c>
    1880:      	movz	x2, #0x0, lsl #48
    1884:      	b	0x1828 <_stogir.verify.integer-operations-target-structured+0xca4>
    1888:      	movz	x2, #0x0, lsl #48
    188c:      	b	0x1828 <_stogir.verify.integer-operations-target-structured+0xca4>
    1890:      	cmp	x1, #0x0
    1894:      	b.ge	0x1c9c <_stogir.verify.integer-operations-target-structured+0x1118>
    1898:      	ldr	x6, [sp, #0x270]
    189c:      	ldr	x7, [x6, #0x8]
    18a0:      	ldr	x8, [sp, #0x268]
    18a4:      	ldr	x9, [x8, #0x8]
    18a8:      	cmp	x7, x9
    18ac:      	b.ne	0x18e0 <_stogir.verify.integer-operations-target-structured+0xd5c>
    18b0:      	cmp	x2, x7
    18b4:      	b.gt	0x18d8 <_stogir.verify.integer-operations-target-structured+0xd54>
    18b8:      	ldr	x2, [x4, #0x50]
    18bc:      	add	x2, x2, x3, lsl #2
    18c0:      	ldr	w2, [x2]
    18c4:      	sxtw	x2, w2
    18c8:      	cmp	x2, #0x0
    18cc:      	cset	w2, gt
    18d0:      	ubfx	x2, x2, #0, #8
    18d4:      	b	0x1830 <_stogir.verify.integer-operations-target-structured+0xcac>
    18d8:      	movz	x2, #0x0, lsl #48
    18dc:      	b	0x18d4 <_stogir.verify.integer-operations-target-structured+0xd50>
    18e0:      	movz	x2, #0x0, lsl #48
    18e4:      	b	0x18d4 <_stogir.verify.integer-operations-target-structured+0xd50>
    18e8:      	movz	x2, #0x0, lsl #48
    18ec:      	b	0x18d4 <_stogir.verify.integer-operations-target-structured+0xd50>
    18f0:      	ldr	x0, [x4, #0x28]
    18f4:      	add	x0, x0, x3, lsl #4
    18f8:      	b	0x184c <_stogir.verify.integer-operations-target-structured+0xcc8>
    18fc:      	movz	x0, #0x0, lsl #48
    1900:      	b	0x184c <_stogir.verify.integer-operations-target-structured+0xcc8>
    1904:      	ldr	w0, [x0]
    1908:      	add	x16, sp, #0x20
    190c:      	ldr	w1, [x16]
    1910:      	ubfx	x0, x0, #8, #8
    1914:      	orr	x2, x0, xzr
    1918:      	ubfx	x1, x1, #8, #8
    191c:      	cmp	x1, #0x6
    1920:      	b.ne	0x1a64 <_stogir.verify.integer-operations-target-structured+0xee0>
    1924:      	cmp	x2, #0x6
    1928:      	b.ne	0x1a5c <_stogir.verify.integer-operations-target-structured+0xed8>
    192c:      	cmp	x24, #0x1a
    1930:      	b.ne	0x1a4c <_stogir.verify.integer-operations-target-structured+0xec8>
    1934:      	mov	x1, #0x1                ; =1
    1938:      	cmp	x2, #0x1
    193c:      	cset	w3, ge
    1940:      	uxtb	w16, w3
    1944:      	cmp	w16, wzr
    1948:      	b.eq	0x1ca8 <_stogir.verify.integer-operations-target-structured+0x1124>
    194c:      	cmp	x2, #0xb
    1950:      	cset	w7, le
    1954:      	uxtb	w16, w7
    1958:      	cmp	w16, wzr
    195c:      	b.eq	0x1cd0 <_stogir.verify.integer-operations-target-structured+0x114c>
    1960:      	cmp	x21, #0x0
    1964:      	b.eq	0x1cf8 <_stogir.verify.integer-operations-target-structured+0x1174>
    1968:      	ldr	w13, [sp, #0x2a0]
    196c:      	str	x4, [sp, #0x230]
    1970:      	str	x5, [sp, #0x278]
    1974:      	str	x6, [sp, #0x270]
    1978:      	str	x8, [sp, #0x268]
    197c:      	mov	x21, x2
    1980:      	str	x26, [sp, #0x2d8]
    1984:      	mov	x26, x1
    1988:      	mov	w1, w0
    198c:      	mov	w0, w13
    1990:      	str	x27, [sp, #0x2e0]
    1994:      	mov	w27, w3
    1998:      	str	x28, [sp, #0x2e8]
    199c:      	mov	w28, w7
    19a0:      	bl	0x19a0 <_stogir.verify.integer-operations-target-structured+0xe1c>
		00000000000019a0:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    19a4:      	cmp	x0, #0x0
    19a8:      	b.ne	0x1a6c <_stogir.verify.integer-operations-target-structured+0xee8>
    19ac:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		00000000000019ac:  ARM64_RELOC_PAGE21	l_stogir.340
    19b0:      	ldr	x22, [x22]
		00000000000019b0:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    19b4:      	mov	x23, #0x1c              ; =28
    19b8:      	add	x16, sp, #0x20
    19bc:      	ldr	w0, [x16]
    19c0:      	cmp	x25, #0x0
    19c4:      	b.eq	0x1b04 <_stogir.verify.integer-operations-target-structured+0xf80>
    19c8:      	mov	x1, #0x1                ; =1
    19cc:      	ubfx	x0, x0, #8, #8
    19d0:      	sxtw	x1, w1
    19d4:      	cmp	x0, x1
    19d8:      	b.eq	0x19e8 <_stogir.verify.integer-operations-target-structured+0xe64>
    19dc:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		00000000000019dc:  ARM64_RELOC_PAGE21	l_stogir.341
    19e0:      	ldr	x22, [x22]
		00000000000019e0:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    19e4:      	mov	x23, #0x26              ; =38
    19e8:      	cmp	x25, #0x0
    19ec:      	b.eq	0x19f4 <_stogir.verify.integer-operations-target-structured+0xe70>
    19f0:      	mov	x19, #0x1               ; =1
    19f4:      	cmp	x19, #0x0
    19f8:      	b.eq	0x1a48 <_stogir.verify.integer-operations-target-structured+0xec4>
    19fc:      	ldr	x0, [sp, #0x230]
    1a00:      	ldr	w1, [sp, #0x2c0]
    1a04:      	mov	x2, #0x2                ; =2
    1a08:      	bl	0x1a08 <_stogir.verify.integer-operations-target-structured+0xe84>
		0000000000001a08:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1a0c:      	ubfx	x0, x0, #0, #32
    1a10:      	lsr	x16, x0, #0
    1a14:      	cmp	x16, #0x1
    1a18:      	b.eq	0x1a34 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1a1c:      	b.lo	0x1a24 <_stogir.verify.integer-operations-target-structured+0xea0>
    1a20:      	b	0x1a38 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1a24:      	cmp	x16, #0x0
    1a28:      	b.eq	0x1a30 <_stogir.verify.integer-operations-target-structured+0xeac>
    1a2c:      	b	0x1a38 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1a30:      	b	0x1a3c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1a34:      	b	0x1b0c <_stogir.verify.integer-operations-target-structured+0xf88>
    1a38:      	b	0x1b68 <_stogir.verify.integer-operations-target-structured+0xfe4>
    1a3c:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001a3c:  ARM64_RELOC_PAGE21	l_stogir.342
    1a40:      	ldr	x22, [x22]
		0000000000001a40:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    1a44:      	mov	x23, #0x1d              ; =29
    1a48:      	b	0x187c <_stogir.verify.integer-operations-target-structured+0xcf8>
    1a4c:      	cmp	x24, #0x1b
    1a50:      	cset	w1, eq
    1a54:      	ubfx	x1, x1, #0, #8
    1a58:      	b	0x1938 <_stogir.verify.integer-operations-target-structured+0xdb4>
    1a5c:      	movz	x1, #0x0, lsl #48
    1a60:      	b	0x1938 <_stogir.verify.integer-operations-target-structured+0xdb4>
    1a64:      	movz	x1, #0x0, lsl #48
    1a68:      	b	0x1938 <_stogir.verify.integer-operations-target-structured+0xdb4>
    1a6c:      	cmp	x19, #0x0
    1a70:      	b.eq	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1a74:      	cmp	x24, #0x3a
    1a78:      	cset	w0, eq
    1a7c:      	cmp	x24, #0x1a
    1a80:      	b.lt	0x1adc <_stogir.verify.integer-operations-target-structured+0xf58>
    1a84:      	cmp	x24, #0x1e
    1a88:      	b.gt	0x1adc <_stogir.verify.integer-operations-target-structured+0xf58>
    1a8c:      	uxtb	w16, w27
    1a90:      	cmp	w16, wzr
    1a94:      	b.eq	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1a98:      	uxtb	w16, w28
    1a9c:      	cmp	w16, wzr
    1aa0:      	b.eq	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1aa4:      	cmp	x21, #0x1
    1aa8:      	b.ne	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1aac:      	cmp	x24, #0x2e
    1ab0:      	b.eq	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1ab4:      	cmp	x24, #0x2f
    1ab8:      	b.eq	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1abc:      	cmp	x24, #0x30
    1ac0:      	b.eq	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1ac4:      	uxtb	w16, w0
    1ac8:      	cmp	w16, wzr
    1acc:      	b.ne	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1ad0:      	cmp	x24, #0x3b
    1ad4:      	b.ne	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1ad8:      	b	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1adc:      	cmp	x24, #0x2e
    1ae0:      	b.lt	0x1aec <_stogir.verify.integer-operations-target-structured+0xf68>
    1ae4:      	cmp	x24, #0x35
    1ae8:      	b.le	0x1a8c <_stogir.verify.integer-operations-target-structured+0xf08>
    1aec:      	uxtb	w16, w0
    1af0:      	cmp	w16, wzr
    1af4:      	b.ne	0x1a8c <_stogir.verify.integer-operations-target-structured+0xf08>
    1af8:      	cmp	x24, #0x3b
    1afc:      	b.eq	0x1a8c <_stogir.verify.integer-operations-target-structured+0xf08>
    1b00:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1b04:      	mov	x1, x21
    1b08:      	b	0x19cc <_stogir.verify.integer-operations-target-structured+0xe48>
    1b0c:      	ldr	x0, [sp, #0x230]
    1b10:      	bl	0x1b10 <_stogir.verify.integer-operations-target-structured+0xf8c>
		0000000000001b10:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1b14:      	cmp	x0, #0x0
    1b18:      	b.ne	0x1b2c <_stogir.verify.integer-operations-target-structured+0xfa8>
    1b1c:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001b1c:  ARM64_RELOC_PAGE21	l_stogir.342
    1b20:      	ldr	x22, [x22]
		0000000000001b20:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    1b24:      	mov	x23, #0x1d              ; =29
    1b28:      	b	0x1a48 <_stogir.verify.integer-operations-target-structured+0xec4>
    1b2c:      	ldr	w0, [x0]
    1b30:      	ubfx	x0, x0, #8, #8
    1b34:      	cmp	x21, x0
    1b38:      	b.eq	0x1b54 <_stogir.verify.integer-operations-target-structured+0xfd0>
    1b3c:      	cmp	x26, #0x0
    1b40:      	b.eq	0x1b58 <_stogir.verify.integer-operations-target-structured+0xfd4>
    1b44:      	cmp	x0, #0x5
    1b48:      	b.eq	0x1b54 <_stogir.verify.integer-operations-target-structured+0xfd0>
    1b4c:      	cmp	x0, #0xb
    1b50:      	b.ne	0x1b58 <_stogir.verify.integer-operations-target-structured+0xfd4>
    1b54:      	b	0x1b28 <_stogir.verify.integer-operations-target-structured+0xfa4>
    1b58:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001b58:  ARM64_RELOC_PAGE21	l_stogir.343
    1b5c:      	ldr	x22, [x22]
		0000000000001b5c:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    1b60:      	mov	x23, #0x1d              ; =29
    1b64:      	b	0x1b54 <_stogir.verify.integer-operations-target-structured+0xfd0>
    1b68:      	brk	#0
    1b6c:      	b	0x1b68 <_stogir.verify.integer-operations-target-structured+0xfe4>
    1b70:      	brk	#0
    1b74:      	b	0x1b70 <_stogir.verify.integer-operations-target-structured+0xfec>
    1b78:      	brk	#0
    1b7c:      	b	0x1b78 <_stogir.verify.integer-operations-target-structured+0xff4>
    1b80:      	cmp	x23, #0x0
    1b84:      	b.ne	0x1bdc <_stogir.verify.integer-operations-target-structured+0x1058>
    1b88:      	and	x22, x20, #0xffffffff
    1b8c:      	movz	x0, #0x0, lsl #48
    1b90:      	movz	x23, #0x0, lsl #48
    1b94:      	ldr	x1, [sp, #0x260]
    1b98:      	str	x0, [x1]
    1b9c:      	str	x22, [x1, #0x8]
    1ba0:      	str	x23, [x1, #0x10]
    1ba4:      	ldr	x19, [sp, #0x2f0]
    1ba8:      	ldr	x20, [sp, #0x2f8]
    1bac:      	ldr	x21, [sp, #0x300]
    1bb0:      	ldr	x22, [sp, #0x308]
    1bb4:      	ldr	x23, [sp, #0x310]
    1bb8:      	ldr	x24, [sp, #0x318]
    1bbc:      	ldr	x25, [sp, #0x320]
    1bc0:      	ldr	x26, [sp, #0x328]
    1bc4:      	ldr	x27, [sp, #0x330]
    1bc8:      	ldr	x28, [sp, #0x338]
    1bcc:      	ldr	x29, [sp, #0x10]
    1bd0:      	ldr	x30, [sp, #0x18]
    1bd4:      	add	sp, sp, #0x340
    1bd8:      	ret
    1bdc:      	mov	x0, #0x1                ; =1
    1be0:      	b	0x1b94 <_stogir.verify.integer-operations-target-structured+0x1010>
    1be4:      	mov	x20, x9
    1be8:      	str	x8, [sp, #0x260]
    1bec:      	mov	x22, x10
    1bf0:      	mov	x23, x11
    1bf4:      	b	0x1b80 <_stogir.verify.integer-operations-target-structured+0xffc>
    1bf8:      	mov	x20, x9
    1bfc:      	str	x8, [sp, #0x260]
    1c00:      	mov	x22, x10
    1c04:      	mov	x23, x11
    1c08:      	b	0x1b80 <_stogir.verify.integer-operations-target-structured+0xffc>
    1c0c:      	str	x0, [sp, #0x230]
    1c10:      	b	0x1470 <_stogir.verify.integer-operations-target-structured+0x8ec>
    1c14:      	ldr	x0, [sp, #0x240]
    1c18:      	b	0x1064 <_stogir.verify.integer-operations-target-structured+0x4e0>
    1c1c:      	str	x0, [sp, #0x240]
    1c20:      	ldr	x0, [sp, #0x2b8]
    1c24:      	b	0x10dc <_stogir.verify.integer-operations-target-structured+0x558>
    1c28:      	str	x0, [sp, #0x2b8]
    1c2c:      	ldr	x0, [sp, #0x2a8]
    1c30:      	b	0x1158 <_stogir.verify.integer-operations-target-structured+0x5d4>
    1c34:      	str	x0, [sp, #0x2a8]
    1c38:      	ldr	x0, [sp, #0x298]
    1c3c:      	b	0x11d4 <_stogir.verify.integer-operations-target-structured+0x650>
    1c40:      	str	x0, [sp, #0x298]
    1c44:      	ldr	x0, [sp, #0x290]
    1c48:      	b	0x1238 <_stogir.verify.integer-operations-target-structured+0x6b4>
    1c4c:      	str	x0, [sp, #0x290]
    1c50:      	b	0x1280 <_stogir.verify.integer-operations-target-structured+0x6fc>
    1c54:      	str	x25, [sp, #0x2d0]
    1c58:      	mov	x25, x0
    1c5c:      	ldr	x0, [sp, #0x288]
    1c60:      	b	0x1308 <_stogir.verify.integer-operations-target-structured+0x784>
    1c64:      	ldr	x25, [sp, #0x238]
    1c68:      	b	0x17c0 <_stogir.verify.integer-operations-target-structured+0xc3c>
    1c6c:      	ldr	x25, [sp, #0x238]
    1c70:      	b	0x17b8 <_stogir.verify.integer-operations-target-structured+0xc34>
    1c74:      	str	x26, [sp, #0x2d8]
    1c78:      	str	x27, [sp, #0x2e0]
    1c7c:      	str	x28, [sp, #0x2e8]
    1c80:      	str	x0, [sp, #0x288]
    1c84:      	b	0x13e8 <_stogir.verify.integer-operations-target-structured+0x864>
    1c88:      	ldr	x4, [sp, #0x230]
    1c8c:      	ldr	x5, [sp, #0x278]
    1c90:      	b	0x1890 <_stogir.verify.integer-operations-target-structured+0xd0c>
    1c94:      	ldr	x5, [sp, #0x278]
    1c98:      	b	0x1888 <_stogir.verify.integer-operations-target-structured+0xd04>
    1c9c:      	ldr	x6, [sp, #0x270]
    1ca0:      	ldr	x8, [sp, #0x268]
    1ca4:      	b	0x18e8 <_stogir.verify.integer-operations-target-structured+0xd64>
    1ca8:      	str	x4, [sp, #0x230]
    1cac:      	str	x5, [sp, #0x278]
    1cb0:      	str	x26, [sp, #0x2d8]
    1cb4:      	mov	x26, x1
    1cb8:      	str	x27, [sp, #0x2e0]
    1cbc:      	str	x28, [sp, #0x2e8]
    1cc0:      	mov	x21, x2
    1cc4:      	str	x6, [sp, #0x270]
    1cc8:      	str	x8, [sp, #0x268]
    1ccc:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1cd0:      	str	x4, [sp, #0x230]
    1cd4:      	str	x5, [sp, #0x278]
    1cd8:      	str	x26, [sp, #0x2d8]
    1cdc:      	mov	x26, x1
    1ce0:      	str	x27, [sp, #0x2e0]
    1ce4:      	str	x28, [sp, #0x2e8]
    1ce8:      	mov	x21, x2
    1cec:      	str	x6, [sp, #0x270]
    1cf0:      	str	x8, [sp, #0x268]
    1cf4:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1cf8:      	str	x4, [sp, #0x230]
    1cfc:      	str	x5, [sp, #0x278]
    1d00:      	str	x26, [sp, #0x2d8]
    1d04:      	mov	x26, x1
    1d08:      	str	x27, [sp, #0x2e0]
    1d0c:      	str	x28, [sp, #0x2e8]
    1d10:      	mov	x21, x2
    1d14:      	mov	w27, w3
    1d18:      	mov	w28, w7
    1d1c:      	str	x6, [sp, #0x270]
    1d20:      	str	x8, [sp, #0x268]
    1d24:      	b	0x1a6c <_stogir.verify.integer-operations-target-structured+0xee8>

0000000000001d28 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    1d28:      	ldr	x0, [x0, #0x8]
    1d2c:      	ret

0000000000001d30 <_coil.core.Eq$slice<u8>$=>:
    1d30:      	sub	sp, sp, #0x10
    1d34:      	str	x29, [sp]
    1d38:      	str	x30, [sp, #0x8]
    1d3c:      	mov	x29, sp
    1d40:      	cmp	x1, x3
    1d44:      	b.ne	0x1d80 <_coil.core.Eq$slice<u8>$=+0x50>
    1d48:      	cmp	x1, #0x0
    1d4c:      	b.ne	0x1d58 <_coil.core.Eq$slice<u8>$=+0x28>
    1d50:      	mov	x0, #0x1                ; =1
    1d54:      	b	0x1d7c <_coil.core.Eq$slice<u8>$=+0x4c>
    1d58:      	lsr	x1, x1, #0
    1d5c:      	fmov	d31, x1
    1d60:      	mov	x1, x2
    1d64:      	fmov	x2, d31
    1d68:      	bl	0x1d68 <_coil.core.Eq$slice<u8>$=+0x38>
		0000000000001d68:  ARM64_RELOC_BRANCH26	_memcmp
    1d6c:      	sxtw	x0, w0
    1d70:      	cmp	x0, #0x0
    1d74:      	cset	w0, eq
    1d78:      	ubfx	x0, x0, #0, #8
    1d7c:      	b	0x1d84 <_coil.core.Eq$slice<u8>$=+0x54>
    1d80:      	movz	x0, #0x0, lsl #48
    1d84:      	ldr	x29, [sp]
    1d88:      	ldr	x30, [sp, #0x8]
    1d8c:      	add	sp, sp, #0x10
    1d90:      	ret

0000000000001d94 <_stogir.types.valid?>:
    1d94:      	sxtw	x1, w0
    1d98:      	cmp	x1, #0x0
    1d9c:      	b.lt	0x1db0 <_stogir.types.valid?+0x1c>
    1da0:      	cmp	x1, #0xd
    1da4:      	b.gt	0x1db0 <_stogir.types.valid?+0x1c>
    1da8:      	mov	x0, #0x1                ; =1
    1dac:      	b	0x1dec <_stogir.types.valid?+0x58>
    1db0:      	cmp	x1, #0xf
    1db4:      	b.le	0x1de8 <_stogir.types.valid?+0x54>
    1db8:      	cmp	x1, #0x80
    1dbc:      	b.ge	0x1de0 <_stogir.types.valid?+0x4c>
    1dc0:      	and	w0, w0, #0xf
    1dc4:      	ubfx	x0, x0, #0, #32
    1dc8:      	cmp	x0, #0x1
    1dcc:      	b.lt	0x1df0 <_stogir.types.valid?+0x5c>
    1dd0:      	cmp	x0, #0xd
    1dd4:      	cset	w0, le
    1dd8:      	ubfx	x0, x0, #0, #8
    1ddc:      	b	0x1df4 <_stogir.types.valid?+0x60>
    1de0:      	movz	x0, #0x0, lsl #48
    1de4:      	b	0x1dec <_stogir.types.valid?+0x58>
    1de8:      	movz	x0, #0x0, lsl #48
    1dec:      	ret
    1df0:      	movz	x0, #0x0, lsl #48
    1df4:      	b	0x1de4 <_stogir.types.valid?+0x50>

0000000000001df8 <_stogir.opcode.input-count>:
    1df8:      	sxtw	x0, w0
    1dfc:      	cmp	x0, #0x0
    1e00:      	b.lt	0x1e24 <_stogir.opcode.input-count+0x2c>
    1e04:      	cmp	x0, #0x83
    1e08:      	b.ge	0x1e24 <_stogir.opcode.input-count+0x2c>
    1e0c:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001e0c:  ARM64_RELOC_PAGE21	l_stogir.344
    1e10:      	ldr	x16, [x16]
		0000000000001e10:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    1e14:      	add	x0, x16, x0
    1e18:      	ldrsb	w0, [x0]
    1e1c:      	sxtb	x0, w0
    1e20:      	b	0x1e28 <_stogir.opcode.input-count+0x30>
    1e24:      	mov	x0, #-0x2               ; =-2
    1e28:      	ret

0000000000001e2c <_stogir.graph.operand>:
    1e2c:      	sxtw	x1, w1
    1e30:      	cmp	x1, #0x0
    1e34:      	b.le	0x1e78 <_stogir.graph.operand+0x4c>
    1e38:      	lsl	x3, x1, #2
    1e3c:      	add	x4, x0, #0x78
    1e40:      	ldr	x5, [x0, #0x8]
    1e44:      	cmp	x1, x5
    1e48:      	b.ge	0x1ea4 <_stogir.graph.operand+0x78>
    1e4c:      	ldr	x4, [x4, #0x8]
    1e50:      	cmp	x1, x4
    1e54:      	b.ge	0x1e9c <_stogir.graph.operand+0x70>
    1e58:      	ldr	x4, [x0, #0x78]
    1e5c:      	add	x4, x3, x4
    1e60:      	ldr	w4, [x4]
    1e64:      	sxtw	x4, w4
    1e68:      	cmp	x4, #0x0
    1e6c:      	cset	w4, ge
    1e70:      	ubfx	x4, x4, #0, #8
    1e74:      	b	0x1ea0 <_stogir.graph.operand+0x74>
    1e78:      	movz	x1, #0x0, lsl #48
    1e7c:      	movz	x0, #0x0, lsl #48
    1e80:      	fmov	d31, x0
    1e84:      	mov	x0, x1
    1e88:      	fmov	x1, d31
    1e8c:      	ret
    1e90:      	movz	x1, #0x0, lsl #48
    1e94:      	movz	x0, #0x0, lsl #48
    1e98:      	b	0x1e80 <_stogir.graph.operand+0x54>
    1e9c:      	movz	x4, #0x0, lsl #48
    1ea0:      	b	0x1ea8 <_stogir.graph.operand+0x7c>
    1ea4:      	movz	x4, #0x0, lsl #48
    1ea8:      	cmp	x4, #0x0
    1eac:      	b.eq	0x1e78 <_stogir.graph.operand+0x4c>
    1eb0:      	sxtw	x2, w2
    1eb4:      	cmp	x2, #0x1
    1eb8:      	b.lt	0x1e90 <_stogir.graph.operand+0x64>
    1ebc:      	ldr	x4, [x0, #0x78]
    1ec0:      	add	x3, x3, x4
    1ec4:      	ldr	w3, [x3]
    1ec8:      	sxtw	x3, w3
    1ecc:      	cmp	x2, x3
    1ed0:      	b.gt	0x1e90 <_stogir.graph.operand+0x64>
    1ed4:      	ldr	x0, [x0]
    1ed8:      	asr	x16, x2, #63
    1edc:      	lsr	x16, x16, #62
    1ee0:      	add	x3, x2, x16
    1ee4:      	asr	x3, x3, #2
    1ee8:      	asr	x16, x2, #63
    1eec:      	lsr	x16, x16, #62
    1ef0:      	add	x2, x2, x16
    1ef4:      	and	x2, x2, #0x3
    1ef8:      	sub	x2, x2, x16
    1efc:      	add	x1, x3, x1
    1f00:      	add	x0, x0, x1, lsl #4
    1f04:      	add	x0, x0, x2, lsl #2
    1f08:      	ldr	w0, [x0]
    1f0c:      	sxtw	x0, w0
    1f10:      	and	x0, x0, #0xffffffff
    1f14:      	mov	x1, #0x1                ; =1
    1f18:      	b	0x1e98 <_stogir.graph.operand+0x6c>

0000000000001f1c <_stogir.graph.borrow-node>:
    1f1c:      	sxtw	x1, w1
    1f20:      	add	x2, x0, #0x28
    1f24:      	cmp	x1, #0x0
    1f28:      	cset	w3, gt
    1f2c:      	movz	x16, #0x0, lsl #48
    1f30:      	sub	x4, x16, x1
    1f34:      	sub	x5, x4, #0x1
    1f38:      	uxtb	w16, w3
    1f3c:      	cmp	w16, wzr
    1f40:      	b.eq	0x1f80 <_stogir.graph.borrow-node+0x64>
    1f44:      	ldr	x2, [x0, #0x8]
    1f48:      	cmp	x1, x2
    1f4c:      	b.ge	0x1fcc <_stogir.graph.borrow-node+0xb0>
    1f50:      	add	x2, x0, #0x78
    1f54:      	ldr	x2, [x2, #0x8]
    1f58:      	cmp	x1, x2
    1f5c:      	b.ge	0x200c <_stogir.graph.borrow-node+0xf0>
    1f60:      	ldr	x2, [x0, #0x78]
    1f64:      	add	x2, x2, x1, lsl #2
    1f68:      	ldr	w2, [x2]
    1f6c:      	sxtw	x2, w2
    1f70:      	cmp	x2, #0x0
    1f74:      	cset	w2, ge
    1f78:      	ubfx	x2, x2, #0, #8
    1f7c:      	b	0x2010 <_stogir.graph.borrow-node+0xf4>
    1f80:      	cmp	x1, #0x0
    1f84:      	b.ge	0x1fd4 <_stogir.graph.borrow-node+0xb8>
    1f88:      	add	x6, x0, #0x50
    1f8c:      	ldr	x2, [x2, #0x8]
    1f90:      	ldr	x6, [x6, #0x8]
    1f94:      	cmp	x2, x6
    1f98:      	b.ne	0x1fc4 <_stogir.graph.borrow-node+0xa8>
    1f9c:      	cmp	x4, x2
    1fa0:      	b.gt	0x2014 <_stogir.graph.borrow-node+0xf8>
    1fa4:      	ldr	x2, [x0, #0x50]
    1fa8:      	add	x2, x2, x5, lsl #2
    1fac:      	ldr	w2, [x2]
    1fb0:      	sxtw	x2, w2
    1fb4:      	cmp	x2, #0x0
    1fb8:      	cset	w2, gt
    1fbc:      	ubfx	x2, x2, #0, #8
    1fc0:      	b	0x2018 <_stogir.graph.borrow-node+0xfc>
    1fc4:      	movz	x2, #0x0, lsl #48
    1fc8:      	b	0x1fd8 <_stogir.graph.borrow-node+0xbc>
    1fcc:      	movz	x2, #0x0, lsl #48
    1fd0:      	b	0x1fd8 <_stogir.graph.borrow-node+0xbc>
    1fd4:      	movz	x2, #0x0, lsl #48
    1fd8:      	cmp	x2, #0x0
    1fdc:      	b.eq	0x2004 <_stogir.graph.borrow-node+0xe8>
    1fe0:      	uxtb	w16, w3
    1fe4:      	cmp	w16, wzr
    1fe8:      	b.eq	0x1ff8 <_stogir.graph.borrow-node+0xdc>
    1fec:      	ldr	x0, [x0]
    1ff0:      	add	x0, x0, x1, lsl #4
    1ff4:      	b	0x2000 <_stogir.graph.borrow-node+0xe4>
    1ff8:      	ldr	x0, [x0, #0x28]
    1ffc:      	add	x0, x0, x5, lsl #4
    2000:      	b	0x2008 <_stogir.graph.borrow-node+0xec>
    2004:      	movz	x0, #0x0, lsl #48
    2008:      	ret
    200c:      	movz	x2, #0x0, lsl #48
    2010:      	b	0x1fd0 <_stogir.graph.borrow-node+0xb4>
    2014:      	movz	x2, #0x0, lsl #48
    2018:      	b	0x1fc8 <_stogir.graph.borrow-node+0xac>

000000000000201c <_stogir.verify.classifications>:
    201c:      	sub	sp, sp, #0x70
    2020:      	str	x29, [sp]
    2024:      	str	x30, [sp, #0x8]
    2028:      	mov	x29, sp
    202c:      	str	x19, [sp, #0x20]
    2030:      	str	x20, [sp, #0x28]
    2034:      	str	x21, [sp, #0x30]
    2038:      	str	x22, [sp, #0x38]
    203c:      	str	x23, [sp, #0x40]
    2040:      	str	x24, [sp, #0x48]
    2044:      	str	x25, [sp, #0x50]
    2048:      	str	x26, [sp, #0x58]
    204c:      	str	x27, [sp, #0x60]
    2050:      	str	x28, [sp, #0x68]
    2054:      	ldr	w4, [x2]
    2058:      	uxtb	w19, w4
    205c:      	orr	x5, x19, xzr
    2060:      	orr	w20, w5, wzr
    2064:      	ubfx	x21, x4, #8, #8
    2068:      	orr	x4, x21, xzr
    206c:      	mov	x22, x0
    2070:      	mov	w0, w4
    2074:      	mov	w23, w1
    2078:      	mov	x24, x2
    207c:      	mov	w25, w3
    2080:      	bl	0x2080 <_stogir.verify.classifications+0x64>
		0000000000002080:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2084:      	fmov	d31, x0
    2088:      	mov	w0, w20
    208c:      	fmov	x20, d31
    2090:      	bl	0x2090 <_stogir.verify.classifications+0x74>
		0000000000002090:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2094:      	cmp	x0, #0x0
    2098:      	b.eq	0x20b4 <_stogir.verify.classifications+0x98>
    209c:      	cmp	x20, #0x0
    20a0:      	cset	w0, ne
    20a4:      	uxtb	w16, w0
    20a8:      	cmp	w16, wzr
    20ac:      	cset	x26, eq
    20b0:      	b	0x20b8 <_stogir.verify.classifications+0x9c>
    20b4:      	movz	x26, #0x0, lsl #48
    20b8:      	cmp	x26, #0x0
    20bc:      	cset	w27, ne
    20c0:      	uxtb	w16, w27
    20c4:      	cmp	w16, wzr
    20c8:      	b.eq	0x20fc <_stogir.verify.classifications+0xe0>
    20cc:      	ldr	w0, [x24, #0x4]
    20d0:      	mov	w1, w0
    20d4:      	mov	x0, x22
    20d8:      	bl	0x20d8 <_stogir.verify.classifications+0xbc>
		00000000000020d8:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    20dc:      	cmp	x0, #0x0
    20e0:      	b.ne	0x20ec <_stogir.verify.classifications+0xd0>
    20e4:      	movn	w28, #0x0, lsl #16
    20e8:      	b	0x20f8 <_stogir.verify.classifications+0xdc>
    20ec:      	ldr	w0, [x0]
    20f0:      	ubfx	x0, x0, #8, #8
    20f4:      	orr	x28, x0, xzr
    20f8:      	b	0x2100 <_stogir.verify.classifications+0xe4>
    20fc:      	movn	w28, #0x0, lsl #16
    2100:      	sxtw	x0, w28
    2104:      	cmp	x26, #0x0
    2108:      	b.eq	0x2598 <_stogir.verify.classifications+0x57c>
    210c:      	mov	x26, x0
    2110:      	mov	w0, w28
    2114:      	bl	0x2114 <_stogir.verify.classifications+0xf8>
		0000000000002114:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2118:      	cmp	x0, #0x0
    211c:      	b.eq	0x2534 <_stogir.verify.classifications+0x518>
    2120:      	movz	x0, #0x0, lsl #48
    2124:      	b	0x212c <_stogir.verify.classifications+0x110>
    2128:      	mov	x0, #0x1                ; =1
    212c:      	b	0x2144 <_stogir.verify.classifications+0x128>
    2130:      	movz	x15, #0x0, lsl #48
    2134:      	b	0x21b8 <_stogir.verify.classifications+0x19c>
    2138:      	movz	x20, #0x0, lsl #48
    213c:      	b	0x21c0 <_stogir.verify.classifications+0x1a4>
    2140:      	movz	x0, #0x0, lsl #48
    2144:      	sxtw	x25, w25
    2148:      	cmp	x26, #0xf
    214c:      	cset	w1, gt
    2150:      	cmp	x26, #0x80
    2154:      	cset	w2, lt
    2158:      	cmp	x19, #0x83
    215c:      	cset	w3, lt
    2160:      	sxtw	x23, w23
    2164:      	and	w4, w28, #0xf
    2168:      	adrp	x16, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002168:  ARM64_RELOC_PAGE21	l_stogir.345
    216c:      	ldr	x16, [x16]
		000000000000216c:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    2170:      	add	x5, x16, x19, lsl #2
    2174:      	add	x6, x22, #0x28
    2178:      	add	x7, x22, #0x78
    217c:      	add	x8, x22, #0x50
    2180:      	cmp	x23, #0x0
    2184:      	cset	w9, le
    2188:      	lsl	x10, x23, #2
    218c:      	ubfx	x4, x4, #0, #32
    2190:      	cmp	x4, #0x1
    2194:      	cset	w11, ge
    2198:      	cmp	x4, #0xd
    219c:      	cset	w4, le
    21a0:      	ubfx	x4, x4, #0, #8
    21a4:      	mov	x12, #0x1               ; =1
    21a8:      	b	0x2260 <_stogir.verify.classifications+0x244>
    21ac:      	movz	x15, #0x0, lsl #48
    21b0:      	b	0x21e0 <_stogir.verify.classifications+0x1c4>
    21b4:      	movz	x15, #0x0, lsl #48
    21b8:      	b	0x21e8 <_stogir.verify.classifications+0x1cc>
    21bc:      	movz	x20, #0x0, lsl #48
    21c0:      	b	0x2258 <_stogir.verify.classifications+0x23c>
    21c4:      	sub	w13, w13, #0x1
    21c8:      	lsl	w13, w13, #2
    21cc:      	ubfx	x13, x13, #0, #32
    21d0:      	lsr	x13, x15, x13
    21d4:      	and	w13, w13, #0xf
    21d8:      	b	0x22a4 <_stogir.verify.classifications+0x288>
    21dc:      	movz	x15, #0x0, lsl #48
    21e0:      	b	0x21e8 <_stogir.verify.classifications+0x1cc>
    21e4:      	movz	x15, #0x0, lsl #48
    21e8:      	cmp	x15, #0x0
    21ec:      	b.eq	0x2214 <_stogir.verify.classifications+0x1f8>
    21f0:      	uxtb	w16, w14
    21f4:      	cmp	w16, wzr
    21f8:      	b.eq	0x2208 <_stogir.verify.classifications+0x1ec>
    21fc:      	ldr	x14, [x22]
    2200:      	add	x13, x14, x13, lsl #4
    2204:      	b	0x2210 <_stogir.verify.classifications+0x1f4>
    2208:      	ldr	x13, [x22, #0x28]
    220c:      	add	x13, x13, x19, lsl #4
    2210:      	b	0x2218 <_stogir.verify.classifications+0x1fc>
    2214:      	movz	x13, #0x0, lsl #48
    2218:      	cmp	x13, #0x0
    221c:      	b.eq	0x2258 <_stogir.verify.classifications+0x23c>
    2220:      	ldr	w13, [x13]
    2224:      	ubfx	x13, x13, #8, #8
    2228:      	orr	x14, x13, xzr
    222c:      	cmp	x14, #0xf
    2230:      	b.le	0x2258 <_stogir.verify.classifications+0x23c>
    2234:      	cmp	x14, #0x80
    2238:      	b.ge	0x2258 <_stogir.verify.classifications+0x23c>
    223c:      	and	w13, w13, #0xf
    2240:      	ubfx	x13, x13, #0, #32
    2244:      	cmp	x13, #0x1
    2248:      	b.lt	0x2258 <_stogir.verify.classifications+0x23c>
    224c:      	cmp	x13, #0xd
    2250:      	b.gt	0x2258 <_stogir.verify.classifications+0x23c>
    2254:      	mov	x20, #0x1               ; =1
    2258:      	add	x12, x12, #0x1
    225c:      	sxtw	x12, w12
    2260:      	cmp	x20, #0x0
    2264:      	b.ne	0x23e0 <_stogir.verify.classifications+0x3c4>
    2268:      	cmp	x12, x25
    226c:      	b.gt	0x23e0 <_stogir.verify.classifications+0x3c4>
    2270:      	orr	w13, w12, wzr
    2274:      	sxtw	x14, w13
    2278:      	uxtb	w16, w3
    227c:      	cmp	w16, wzr
    2280:      	b.eq	0x22a8 <_stogir.verify.classifications+0x28c>
    2284:      	ldr	w15, [x5]
    2288:      	cmp	x14, #0x0
    228c:      	b.le	0x22a0 <_stogir.verify.classifications+0x284>
    2290:      	cmp	x14, #0x4
    2294:      	b.le	0x21c4 <_stogir.verify.classifications+0x1a8>
    2298:      	mov	w13, #0x4               ; =4
    229c:      	b	0x21c8 <_stogir.verify.classifications+0x1ac>
    22a0:      	movz	w13, #0x0, lsl #16
    22a4:      	b	0x22ac <_stogir.verify.classifications+0x290>
    22a8:      	movz	w13, #0x0, lsl #16
    22ac:      	adrp	x16, 0x2000 <_stogir.graph.borrow-node+0xe4>
		00000000000022ac:  ARM64_RELOC_PAGE21	l_stogir.346
    22b0:      	ldr	x16, [x16]
		00000000000022b0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    22b4:      	ldr	w15, [x16]
    22b8:      	ubfx	x13, x13, #0, #32
    22bc:      	cmp	x13, x15
    22c0:      	b.eq	0x22d8 <_stogir.verify.classifications+0x2bc>
    22c4:      	adrp	x16, 0x2000 <_stogir.graph.borrow-node+0xe4>
		00000000000022c4:  ARM64_RELOC_PAGE21	l_stogir.347
    22c8:      	ldr	x16, [x16]
		00000000000022c8:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    22cc:      	ldr	w15, [x16]
    22d0:      	cmp	x13, x15
    22d4:      	b.ne	0x2258 <_stogir.verify.classifications+0x23c>
    22d8:      	cmp	x12, #0x1
    22dc:      	b.ne	0x2318 <_stogir.verify.classifications+0x2fc>
    22e0:      	uxtb	w16, w27
    22e4:      	cmp	w16, wzr
    22e8:      	b.eq	0x2318 <_stogir.verify.classifications+0x2fc>
    22ec:      	uxtb	w16, w1
    22f0:      	cmp	w16, wzr
    22f4:      	b.eq	0x21bc <_stogir.verify.classifications+0x1a0>
    22f8:      	uxtb	w16, w2
    22fc:      	cmp	w16, wzr
    2300:      	b.eq	0x2138 <_stogir.verify.classifications+0x11c>
    2304:      	uxtb	w16, w11
    2308:      	cmp	w16, wzr
    230c:      	b.eq	0x24e8 <_stogir.verify.classifications+0x4cc>
    2310:      	mov	x20, x4
    2314:      	b	0x24ec <_stogir.verify.classifications+0x4d0>
    2318:      	cmp	x12, #0x1
    231c:      	b.ne	0x2380 <_stogir.verify.classifications+0x364>
    2320:      	ldr	w13, [x24, #0x4]
    2324:      	sxtw	x13, w13
    2328:      	cmp	x13, #0x0
    232c:      	cset	w14, gt
    2330:      	movz	x16, #0x0, lsl #48
    2334:      	sub	x15, x16, x13
    2338:      	sub	x19, x15, #0x1
    233c:      	uxtb	w16, w14
    2340:      	cmp	w16, wzr
    2344:      	b.eq	0x2390 <_stogir.verify.classifications+0x374>
    2348:      	ldr	x15, [x22, #0x8]
    234c:      	cmp	x13, x15
    2350:      	b.ge	0x21dc <_stogir.verify.classifications+0x1c0>
    2354:      	ldr	x15, [x7, #0x8]
    2358:      	cmp	x13, x15
    235c:      	b.ge	0x21ac <_stogir.verify.classifications+0x190>
    2360:      	ldr	x15, [x22, #0x78]
    2364:      	add	x15, x15, x13, lsl #2
    2368:      	ldr	w15, [x15]
    236c:      	sxtw	x15, w15
    2370:      	cmp	x15, #0x0
    2374:      	cset	w15, ge
    2378:      	ubfx	x15, x15, #0, #8
    237c:      	b	0x21b0 <_stogir.verify.classifications+0x194>
    2380:      	cmp	x12, #0x2
    2384:      	b.ne	0x23d0 <_stogir.verify.classifications+0x3b4>
    2388:      	ldr	w13, [x24, #0x8]
    238c:      	b	0x2324 <_stogir.verify.classifications+0x308>
    2390:      	cmp	x13, #0x0
    2394:      	b.ge	0x21e4 <_stogir.verify.classifications+0x1c8>
    2398:      	ldr	x21, [x6, #0x8]
    239c:      	ldr	x26, [x8, #0x8]
    23a0:      	cmp	x21, x26
    23a4:      	b.ne	0x21b4 <_stogir.verify.classifications+0x198>
    23a8:      	cmp	x15, x21
    23ac:      	b.gt	0x2130 <_stogir.verify.classifications+0x114>
    23b0:      	ldr	x15, [x22, #0x50]
    23b4:      	add	x15, x15, x19, lsl #2
    23b8:      	ldr	w15, [x15]
    23bc:      	sxtw	x15, w15
    23c0:      	cmp	x15, #0x0
    23c4:      	cset	w15, gt
    23c8:      	ubfx	x15, x15, #0, #8
    23cc:      	b	0x2134 <_stogir.verify.classifications+0x118>
    23d0:      	cmp	x12, #0x3
    23d4:      	b.ne	0x2444 <_stogir.verify.classifications+0x428>
    23d8:      	ldr	w13, [x24, #0xc]
    23dc:      	b	0x238c <_stogir.verify.classifications+0x370>
    23e0:      	uxtb	w20, w20
    23e4:      	uxtb	w0, w0
    23e8:      	add	x16, sp, #0x10
    23ec:      	movz	w17, #0x0, lsl #16
    23f0:      	strh	w17, [x16]
    23f4:      	add	x16, sp, #0x10
    23f8:      	strb	w20, [x16]
    23fc:      	add	x16, sp, #0x10
    2400:      	strb	w0, [x16, #0x1]
    2404:      	add	x16, sp, #0x10
    2408:      	ldrh	w0, [x16]
    240c:      	ldr	x19, [sp, #0x20]
    2410:      	ldr	x20, [sp, #0x28]
    2414:      	ldr	x21, [sp, #0x30]
    2418:      	ldr	x22, [sp, #0x38]
    241c:      	ldr	x23, [sp, #0x40]
    2420:      	ldr	x24, [sp, #0x48]
    2424:      	ldr	x25, [sp, #0x50]
    2428:      	ldr	x26, [sp, #0x58]
    242c:      	ldr	x27, [sp, #0x60]
    2430:      	ldr	x28, [sp, #0x68]
    2434:      	ldr	x29, [sp]
    2438:      	ldr	x30, [sp, #0x8]
    243c:      	add	sp, sp, #0x70
    2440:      	ret
    2444:      	uxtb	w16, w9
    2448:      	cmp	w16, wzr
    244c:      	b.ne	0x24f4 <_stogir.verify.classifications+0x4d8>
    2450:      	ldr	x13, [x22, #0x8]
    2454:      	cmp	x23, x13
    2458:      	b.ge	0x24f4 <_stogir.verify.classifications+0x4d8>
    245c:      	ldr	x13, [x7, #0x8]
    2460:      	cmp	x23, x13
    2464:      	b.ge	0x24f4 <_stogir.verify.classifications+0x4d8>
    2468:      	ldr	x13, [x22, #0x78]
    246c:      	add	x13, x10, x13
    2470:      	ldr	w13, [x13]
    2474:      	sxtw	x13, w13
    2478:      	cmp	x13, #0x0
    247c:      	b.lt	0x24f4 <_stogir.verify.classifications+0x4d8>
    2480:      	cmp	x14, #0x1
    2484:      	b.lt	0x2574 <_stogir.verify.classifications+0x558>
    2488:      	ldr	x13, [x22, #0x78]
    248c:      	add	x13, x10, x13
    2490:      	ldr	w13, [x13]
    2494:      	sxtw	x13, w13
    2498:      	cmp	x14, x13
    249c:      	b.gt	0x2574 <_stogir.verify.classifications+0x558>
    24a0:      	ldr	x13, [x22]
    24a4:      	asr	x16, x14, #63
    24a8:      	lsr	x16, x16, #62
    24ac:      	add	x15, x14, x16
    24b0:      	asr	x15, x15, #2
    24b4:      	asr	x16, x14, #63
    24b8:      	lsr	x16, x16, #62
    24bc:      	add	x14, x14, x16
    24c0:      	and	x14, x14, #0x3
    24c4:      	sub	x14, x14, x16
    24c8:      	add	x15, x15, x23
    24cc:      	add	x13, x13, x15, lsl #4
    24d0:      	add	x13, x13, x14, lsl #2
    24d4:      	ldr	w13, [x13]
    24d8:      	movn	w17, #0x0, lsl #16
    24dc:      	and	w13, w13, w17
    24e0:      	mov	w14, #0x1               ; =1
    24e4:      	b	0x257c <_stogir.verify.classifications+0x560>
    24e8:      	movz	x20, #0x0, lsl #48
    24ec:      	b	0x213c <_stogir.verify.classifications+0x120>
    24f0:      	b	0x23dc <_stogir.verify.classifications+0x3c0>
    24f4:      	movz	w14, #0x0, lsl #16
    24f8:      	movz	w13, #0x0, lsl #16
    24fc:      	ubfx	x14, x14, #0, #32
    2500:      	lsr	x16, x14, #0
    2504:      	cmp	x16, #0x1
    2508:      	b.eq	0x2524 <_stogir.verify.classifications+0x508>
    250c:      	b.lo	0x2514 <_stogir.verify.classifications+0x4f8>
    2510:      	b	0x2528 <_stogir.verify.classifications+0x50c>
    2514:      	cmp	x16, #0x0
    2518:      	b.eq	0x2520 <_stogir.verify.classifications+0x504>
    251c:      	b	0x2528 <_stogir.verify.classifications+0x50c>
    2520:      	b	0x252c <_stogir.verify.classifications+0x510>
    2524:      	b	0x24f0 <_stogir.verify.classifications+0x4d4>
    2528:      	b	0x2590 <_stogir.verify.classifications+0x574>
    252c:      	movz	w13, #0x0, lsl #16
    2530:      	b	0x24f0 <_stogir.verify.classifications+0x4d4>
    2534:      	cmp	x19, #0x18
    2538:      	b.ne	0x2544 <_stogir.verify.classifications+0x528>
    253c:      	mov	x0, #0x1                ; =1
    2540:      	b	0x212c <_stogir.verify.classifications+0x110>
    2544:      	cmp	x19, #0x19
    2548:      	b.ne	0x2554 <_stogir.verify.classifications+0x538>
    254c:      	mov	x0, #0x1                ; =1
    2550:      	b	0x212c <_stogir.verify.classifications+0x110>
    2554:      	cmp	x21, #0xc
    2558:      	b.eq	0x2128 <_stogir.verify.classifications+0x10c>
    255c:      	cmp	x21, #0xd
    2560:      	b.eq	0x2128 <_stogir.verify.classifications+0x10c>
    2564:      	cmp	x26, #0xc
    2568:      	b.ne	0x2580 <_stogir.verify.classifications+0x564>
    256c:      	mov	x0, #0x1                ; =1
    2570:      	b	0x258c <_stogir.verify.classifications+0x570>
    2574:      	movz	w14, #0x0, lsl #16
    2578:      	movz	w13, #0x0, lsl #16
    257c:      	b	0x24fc <_stogir.verify.classifications+0x4e0>
    2580:      	cmp	x26, #0xd
    2584:      	cset	w0, eq
    2588:      	ubfx	x0, x0, #0, #8
    258c:      	b	0x212c <_stogir.verify.classifications+0x110>
    2590:      	brk	#0
    2594:      	b	0x2590 <_stogir.verify.classifications+0x574>
    2598:      	mov	x26, x0
    259c:      	b	0x2140 <_stogir.verify.classifications+0x124>

00000000000025a0 <_stogir.vector.validate>:
    25a0:      	sub	sp, sp, #0x220
    25a4:      	str	x29, [sp]
    25a8:      	str	x30, [sp, #0x8]
    25ac:      	mov	x29, sp
    25b0:      	str	x19, [sp, #0x1d0]
    25b4:      	str	x20, [sp, #0x1d8]
    25b8:      	str	x21, [sp, #0x1e0]
    25bc:      	str	x22, [sp, #0x1e8]
    25c0:      	str	x23, [sp, #0x1f0]
    25c4:      	str	x24, [sp, #0x1f8]
    25c8:      	str	x25, [sp, #0x200]
    25cc:      	str	x26, [sp, #0x208]
    25d0:      	str	x27, [sp, #0x210]
    25d4:      	str	x28, [sp, #0x218]
    25d8:      	orr	w19, w1, wzr
    25dc:      	mov	x20, x8
    25e0:      	add	x8, sp, #0x10
    25e4:      	mov	x21, x0
    25e8:      	mov	w22, w1
    25ec:      	mov	w1, w19
    25f0:      	mov	w23, w2
    25f4:      	bl	0x25f4 <_stogir.vector.validate+0x54>
		00000000000025f4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    25f8:      	add	x16, sp, #0x10
    25fc:      	ldr	w0, [x16]
    2600:      	lsr	x16, x0, #0
    2604:      	cmp	x16, #0x1
    2608:      	b.eq	0x2624 <_stogir.vector.validate+0x84>
    260c:      	b.lo	0x2614 <_stogir.vector.validate+0x74>
    2610:      	b	0x2628 <_stogir.vector.validate+0x88>
    2614:      	cmp	x16, #0x0
    2618:      	b.eq	0x2620 <_stogir.vector.validate+0x80>
    261c:      	b	0x2628 <_stogir.vector.validate+0x88>
    2620:      	b	0x262c <_stogir.vector.validate+0x8c>
    2624:      	b	0x26b8 <_stogir.vector.validate+0x118>
    2628:      	b	0x28d4 <_stogir.vector.validate+0x334>
    262c:      	str	x20, [sp, #0x1a8]
    2630:      	mov	x0, #0x1                ; =1
    2634:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002634:  ARM64_RELOC_PAGE21	l_stogir.348
    2638:      	ldr	x19, [x19]
		0000000000002638:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    263c:      	mov	x25, #0x1a              ; =26
    2640:      	b	0x2670 <_stogir.vector.validate+0xd0>
    2644:      	add	x8, sp, #0x70
    2648:      	mov	x0, x21
    264c:      	ldr	w1, [sp, #0x1a0]
    2650:      	mov	w2, w23
    2654:      	bl	0x2654 <_stogir.vector.validate+0xb4>
		0000000000002654:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    2658:      	add	x16, sp, #0x70
    265c:      	ldr	x0, [x16]
    2660:      	add	x16, sp, #0x70
    2664:      	ldr	x19, [x16, #0x8]
    2668:      	add	x16, sp, #0x70
    266c:      	ldr	x25, [x16, #0x10]
    2670:      	ldr	x1, [sp, #0x1a8]
    2674:      	str	x0, [x1]
    2678:      	str	x19, [x1, #0x8]
    267c:      	str	x25, [x1, #0x10]
    2680:      	ldr	x19, [sp, #0x1d0]
    2684:      	ldr	x20, [sp, #0x1d8]
    2688:      	ldr	x21, [sp, #0x1e0]
    268c:      	ldr	x22, [sp, #0x1e8]
    2690:      	ldr	x23, [sp, #0x1f0]
    2694:      	ldr	x24, [sp, #0x1f8]
    2698:      	ldr	x25, [sp, #0x200]
    269c:      	ldr	x26, [sp, #0x208]
    26a0:      	ldr	x27, [sp, #0x210]
    26a4:      	ldr	x28, [sp, #0x218]
    26a8:      	ldr	x29, [sp]
    26ac:      	ldr	x30, [sp, #0x8]
    26b0:      	add	sp, sp, #0x220
    26b4:      	ret
    26b8:      	sxtw	x22, w22
    26bc:      	add	x16, sp, #0x10
    26c0:      	orr	x0, x16, xzr
    26c4:      	cmp	x22, #0x0
    26c8:      	cset	w24, le
    26cc:      	add	x0, x0, #0x8
    26d0:      	add	x16, sp, #0x10
    26d4:      	ldr	x25, [x16, #0x8]
    26d8:      	add	x16, sp, #0x40
    26dc:      	str	x25, [x16]
    26e0:      	ldr	x0, [x0, #0x8]
    26e4:      	add	x16, sp, #0x40
    26e8:      	str	x0, [x16, #0x8]
    26ec:      	uxtb	w16, w24
    26f0:      	cmp	w16, wzr
    26f4:      	b.eq	0x2710 <_stogir.vector.validate+0x170>
    26f8:      	str	x20, [sp, #0x1a8]
    26fc:      	mov	x0, #0x1                ; =1
    2700:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002700:  ARM64_RELOC_PAGE21	l_stogir.349
    2704:      	ldr	x19, [x19]
		0000000000002704:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    2708:      	mov	x25, #0x3b              ; =59
    270c:      	b	0x2670 <_stogir.vector.validate+0xd0>
    2710:      	lsl	x26, x22, #2
    2714:      	uxtb	w0, w25
    2718:      	add	x27, x21, #0x78
    271c:      	orr	x28, x0, xzr
    2720:      	cmp	x28, #0x44
    2724:      	cset	w0, eq
    2728:      	ldr	x1, [x21, #0x78]
    272c:      	add	x1, x1, x22, lsl #2
    2730:      	ldr	w1, [x1]
    2734:      	cmp	x28, #0x24
    2738:      	b.ne	0x277c <_stogir.vector.validate+0x1dc>
    273c:      	str	x20, [sp, #0x1a8]
    2740:      	str	w19, [sp, #0x1a0]
    2744:      	uxtb	w16, w0
    2748:      	cmp	w16, wzr
    274c:      	b.eq	0x2644 <_stogir.vector.validate+0xa4>
    2750:      	add	x8, sp, #0x50
    2754:      	mov	x0, x21
    2758:      	ldr	w1, [sp, #0x1a0]
    275c:      	bl	0x275c <_stogir.vector.validate+0x1bc>
		000000000000275c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    2760:      	add	x16, sp, #0x50
    2764:      	ldr	x0, [x16]
    2768:      	add	x16, sp, #0x50
    276c:      	ldr	x19, [x16, #0x8]
    2770:      	add	x16, sp, #0x50
    2774:      	ldr	x25, [x16, #0x10]
    2778:      	b	0x2670 <_stogir.vector.validate+0xd0>
    277c:      	uxtb	w16, w0
    2780:      	cmp	w16, wzr
    2784:      	b.ne	0x2f8c <_stogir.vector.validate+0x9ec>
    2788:      	cmp	x28, #0x3c
    278c:      	b.ne	0x283c <_stogir.vector.validate+0x29c>
    2790:      	add	x8, sp, #0x90
    2794:      	mov	x0, x21
    2798:      	mov	w1, w19
    279c:      	bl	0x279c <_stogir.vector.validate+0x1fc>
		000000000000279c:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    27a0:      	add	x16, sp, #0x90
    27a4:      	ldr	x0, [x16]
    27a8:      	add	x16, sp, #0x90
    27ac:      	ldr	x19, [x16, #0x8]
    27b0:      	add	x16, sp, #0x90
    27b4:      	ldr	x25, [x16, #0x10]
    27b8:      	str	x20, [sp, #0x1a8]
    27bc:      	b	0x2838 <_stogir.vector.validate+0x298>
    27c0:      	cmp	x28, #0x41
    27c4:      	cset	w0, eq
    27c8:      	cmp	x28, #0x48
    27cc:      	cset	w1, eq
    27d0:      	cmp	x28, #0x55
    27d4:      	cset	w2, ge
    27d8:      	cmp	x28, #0x58
    27dc:      	cset	w3, le
    27e0:      	cmp	x28, #0x47
    27e4:      	b.ne	0x28dc <_stogir.vector.validate+0x33c>
    27e8:      	str	x20, [sp, #0x1a8]
    27ec:      	mov	w20, w0
    27f0:      	str	w1, [sp, #0x1b0]
    27f4:      	str	w2, [sp, #0x1b8]
    27f8:      	str	w3, [sp, #0x1c0]
    27fc:      	mov	x0, x21
    2800:      	ldr	w1, [sp, #0x1a0]
    2804:      	bl	0x2804 <_stogir.vector.validate+0x264>
		0000000000002804:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2808:      	cmp	x0, #0x0
    280c:      	b.eq	0x28fc <_stogir.vector.validate+0x35c>
    2810:      	add	x8, sp, #0xf0
    2814:      	mov	x0, x21
    2818:      	ldr	w1, [sp, #0x1a0]
    281c:      	bl	0x281c <_stogir.vector.validate+0x27c>
		000000000000281c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    2820:      	add	x16, sp, #0xf0
    2824:      	ldr	x0, [x16]
    2828:      	add	x16, sp, #0xf0
    282c:      	ldr	x19, [x16, #0x8]
    2830:      	add	x16, sp, #0xf0
    2834:      	ldr	x25, [x16, #0x10]
    2838:      	b	0x2670 <_stogir.vector.validate+0xd0>
    283c:      	cmp	x28, #0x3d
    2840:      	b.lt	0x2880 <_stogir.vector.validate+0x2e0>
    2844:      	cmp	x28, #0x3f
    2848:      	b.gt	0x2880 <_stogir.vector.validate+0x2e0>
    284c:      	add	x8, sp, #0xb0
    2850:      	mov	x0, x21
    2854:      	mov	w1, w19
    2858:      	mov	w2, w23
    285c:      	bl	0x285c <_stogir.vector.validate+0x2bc>
		000000000000285c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    2860:      	add	x16, sp, #0xb0
    2864:      	ldr	x0, [x16]
    2868:      	add	x16, sp, #0xb0
    286c:      	ldr	x19, [x16, #0x8]
    2870:      	add	x16, sp, #0xb0
    2874:      	ldr	x25, [x16, #0x10]
    2878:      	str	x20, [sp, #0x1a8]
    287c:      	b	0x2838 <_stogir.vector.validate+0x298>
    2880:      	mov	x0, x21
    2884:      	str	w19, [sp, #0x1a0]
    2888:      	fmov	s31, w1
    288c:      	mov	w1, w19
    2890:      	fmov	w19, s31
    2894:      	bl	0x2894 <_stogir.vector.validate+0x2f4>
		0000000000002894:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    2898:      	cmp	x0, #0x0
    289c:      	b.eq	0x27c0 <_stogir.vector.validate+0x220>
    28a0:      	add	x8, sp, #0xd0
    28a4:      	mov	x0, x21
    28a8:      	ldr	w1, [sp, #0x1a0]
    28ac:      	mov	w2, w23
    28b0:      	bl	0x28b0 <_stogir.vector.validate+0x310>
		00000000000028b0:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    28b4:      	add	x16, sp, #0xd0
    28b8:      	ldr	x0, [x16]
    28bc:      	add	x16, sp, #0xd0
    28c0:      	ldr	x19, [x16, #0x8]
    28c4:      	add	x16, sp, #0xd0
    28c8:      	ldr	x25, [x16, #0x10]
    28cc:      	str	x20, [sp, #0x1a8]
    28d0:      	b	0x2838 <_stogir.vector.validate+0x298>
    28d4:      	brk	#0
    28d8:      	b	0x28d4 <_stogir.vector.validate+0x334>
    28dc:      	cmp	x28, #0x4f
    28e0:      	b.ne	0x2978 <_stogir.vector.validate+0x3d8>
    28e4:      	str	x20, [sp, #0x1a8]
    28e8:      	mov	w20, w0
    28ec:      	str	w1, [sp, #0x1b0]
    28f0:      	str	w2, [sp, #0x1b8]
    28f4:      	str	w3, [sp, #0x1c0]
    28f8:      	b	0x27fc <_stogir.vector.validate+0x25c>
    28fc:      	uxtb	w16, w20
    2900:      	cmp	w16, wzr
    2904:      	b.ne	0x2948 <_stogir.vector.validate+0x3a8>
    2908:      	ldr	w0, [sp, #0x1b0]
    290c:      	uxtb	w16, w0
    2910:      	cmp	w16, wzr
    2914:      	b.ne	0x2948 <_stogir.vector.validate+0x3a8>
    2918:      	ldr	w0, [sp, #0x1b8]
    291c:      	uxtb	w16, w0
    2920:      	cmp	w16, wzr
    2924:      	b.eq	0x2938 <_stogir.vector.validate+0x398>
    2928:      	ldr	w0, [sp, #0x1c0]
    292c:      	uxtb	w16, w0
    2930:      	cmp	w16, wzr
    2934:      	b.ne	0x2948 <_stogir.vector.validate+0x3a8>
    2938:      	movz	x0, #0x0, lsl #48
    293c:      	movz	x19, #0x0, lsl #48
    2940:      	movz	x25, #0x0, lsl #48
    2944:      	b	0x2974 <_stogir.vector.validate+0x3d4>
    2948:      	add	x8, sp, #0x110
    294c:      	mov	x0, x21
    2950:      	ldr	w1, [sp, #0x1a0]
    2954:      	mov	w2, w23
    2958:      	bl	0x2958 <_stogir.vector.validate+0x3b8>
		0000000000002958:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    295c:      	add	x16, sp, #0x110
    2960:      	ldr	x0, [x16]
    2964:      	add	x16, sp, #0x110
    2968:      	ldr	x19, [x16, #0x8]
    296c:      	add	x16, sp, #0x110
    2970:      	ldr	x25, [x16, #0x10]
    2974:      	b	0x2838 <_stogir.vector.validate+0x298>
    2978:      	cmp	x28, #0x50
    297c:      	b.eq	0x2f98 <_stogir.vector.validate+0x9f8>
    2980:      	cmp	x28, #0x78
    2984:      	b.ne	0x29a0 <_stogir.vector.validate+0x400>
    2988:      	str	x20, [sp, #0x1a8]
    298c:      	mov	w20, w0
    2990:      	str	w1, [sp, #0x1b0]
    2994:      	str	w2, [sp, #0x1b8]
    2998:      	str	w3, [sp, #0x1c0]
    299c:      	b	0x27fc <_stogir.vector.validate+0x25c>
    29a0:      	uxtb	w16, w0
    29a4:      	cmp	w16, wzr
    29a8:      	b.ne	0x2a68 <_stogir.vector.validate+0x4c8>
    29ac:      	uxtb	w16, w1
    29b0:      	cmp	w16, wzr
    29b4:      	b.ne	0x2a68 <_stogir.vector.validate+0x4c8>
    29b8:      	uxtb	w16, w2
    29bc:      	cmp	w16, wzr
    29c0:      	b.eq	0x29d0 <_stogir.vector.validate+0x430>
    29c4:      	uxtb	w16, w3
    29c8:      	cmp	w16, wzr
    29cc:      	b.ne	0x2a68 <_stogir.vector.validate+0x4c8>
    29d0:      	str	w1, [sp, #0x1b0]
    29d4:      	ldr	w1, [sp, #0x1a0]
    29d8:      	str	w2, [sp, #0x1b8]
    29dc:      	str	w3, [sp, #0x1c0]
    29e0:      	str	x20, [sp, #0x1a8]
    29e4:      	mov	w20, w0
    29e8:      	mov	x0, x21
    29ec:      	bl	0x29ec <_stogir.vector.validate+0x44c>
		00000000000029ec:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    29f0:      	cmp	x0, #0x0
    29f4:      	b.ne	0x27fc <_stogir.vector.validate+0x25c>
    29f8:      	sxtw	x20, w19
    29fc:      	ubfx	x25, x25, #0, #32
    2a00:      	ubfx	x0, x25, #8, #8
    2a04:      	orr	x1, x0, xzr
    2a08:      	orr	w19, w1, wzr
    2a0c:      	cmp	x28, #0x5b
    2a10:      	b.ne	0x2a94 <_stogir.vector.validate+0x4f4>
    2a14:      	str	w19, [sp, #0x1c8]
    2a18:      	cmp	x20, #0x2
    2a1c:      	b.ne	0x2a80 <_stogir.vector.validate+0x4e0>
    2a20:      	add	x16, sp, #0x40
    2a24:      	ldr	w0, [x16, #0x4]
    2a28:      	add	x16, sp, #0x40
    2a2c:      	ldr	w1, [x16, #0x8]
    2a30:      	add	x8, sp, #0x130
    2a34:      	mov	w2, w23
    2a38:      	mov	w3, w0
    2a3c:      	mov	x0, x21
    2a40:      	mov	w4, w1
    2a44:      	ldr	w1, [sp, #0x1c8]
    2a48:      	bl	0x2a48 <_stogir.vector.validate+0x4a8>
		0000000000002a48:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    2a4c:      	add	x16, sp, #0x130
    2a50:      	ldr	x0, [x16]
    2a54:      	add	x16, sp, #0x130
    2a58:      	ldr	x19, [x16, #0x8]
    2a5c:      	add	x16, sp, #0x130
    2a60:      	ldr	x25, [x16, #0x10]
    2a64:      	b	0x2a90 <_stogir.vector.validate+0x4f0>
    2a68:      	str	x20, [sp, #0x1a8]
    2a6c:      	mov	w20, w0
    2a70:      	str	w1, [sp, #0x1b0]
    2a74:      	str	w2, [sp, #0x1b8]
    2a78:      	str	w3, [sp, #0x1c0]
    2a7c:      	b	0x27fc <_stogir.vector.validate+0x25c>
    2a80:      	mov	x0, #0x1                ; =1
    2a84:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002a84:  ARM64_RELOC_PAGE21	l_stogir.350
    2a88:      	ldr	x19, [x19]
		0000000000002a88:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    2a8c:      	mov	x25, #0x19              ; =25
    2a90:      	b	0x2838 <_stogir.vector.validate+0x298>
    2a94:      	cmp	x28, #0x5c
    2a98:      	b.eq	0x2fb0 <_stogir.vector.validate+0xa10>
    2a9c:      	orr	x25, x0, xzr
    2aa0:      	cmp	x28, #0x5d
    2aa4:      	b.ne	0x2b20 <_stogir.vector.validate+0x580>
    2aa8:      	mov	x28, x25
    2aac:      	cmp	x20, #0x3
    2ab0:      	b.ne	0x2b0c <_stogir.vector.validate+0x56c>
    2ab4:      	cmp	x28, #0x0
    2ab8:      	b.ne	0x2b0c <_stogir.vector.validate+0x56c>
    2abc:      	add	x16, sp, #0x40
    2ac0:      	ldr	w0, [x16, #0x4]
    2ac4:      	add	x16, sp, #0x40
    2ac8:      	ldr	w1, [x16, #0x8]
    2acc:      	add	x16, sp, #0x40
    2ad0:      	ldr	w2, [x16, #0xc]
    2ad4:      	add	x8, sp, #0x150
    2ad8:      	mov	w3, w1
    2adc:      	mov	w1, w23
    2ae0:      	mov	w4, w2
    2ae4:      	mov	w2, w0
    2ae8:      	mov	x0, x21
    2aec:      	bl	0x2aec <_stogir.vector.validate+0x54c>
		0000000000002aec:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    2af0:      	add	x16, sp, #0x150
    2af4:      	ldr	x0, [x16]
    2af8:      	add	x16, sp, #0x150
    2afc:      	ldr	x19, [x16, #0x8]
    2b00:      	add	x16, sp, #0x150
    2b04:      	ldr	x25, [x16, #0x10]
    2b08:      	b	0x2b1c <_stogir.vector.validate+0x57c>
    2b0c:      	mov	x0, #0x1                ; =1
    2b10:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002b10:  ARM64_RELOC_PAGE21	l_stogir.351
    2b14:      	ldr	x19, [x19]
		0000000000002b14:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    2b18:      	mov	x25, #0x1a              ; =26
    2b1c:      	b	0x2a90 <_stogir.vector.validate+0x4f0>
    2b20:      	cmp	x28, #0x5e
    2b24:      	b.eq	0x2fb8 <_stogir.vector.validate+0xa18>
    2b28:      	cmp	x28, #0x43
    2b2c:      	b.ne	0x2b98 <_stogir.vector.validate+0x5f8>
    2b30:      	cmp	x25, #0xf
    2b34:      	b.le	0x2ea8 <_stogir.vector.validate+0x908>
    2b38:      	cmp	x25, #0x80
    2b3c:      	b.ge	0x2ea8 <_stogir.vector.validate+0x908>
    2b40:      	and	w0, w1, #0xf
    2b44:      	ubfx	x0, x0, #0, #32
    2b48:      	cmp	x0, #0x1
    2b4c:      	b.lt	0x2ea8 <_stogir.vector.validate+0x908>
    2b50:      	cmp	x0, #0xd
    2b54:      	b.gt	0x2ea8 <_stogir.vector.validate+0x908>
    2b58:      	mov	w0, w19
    2b5c:      	mov	w1, w23
    2b60:      	bl	0x2b60 <_stogir.vector.validate+0x5c0>
		0000000000002b60:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2b64:      	sxtw	x0, w0
    2b68:      	cmp	x0, #0x0
    2b6c:      	b.le	0x2ea8 <_stogir.vector.validate+0x908>
    2b70:      	cmp	x20, #0x3
    2b74:      	b.lt	0x2ea8 <_stogir.vector.validate+0x908>
    2b78:      	mov	w28, w19
    2b7c:      	mov	x0, x25
    2b80:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002b80:  ARM64_RELOC_PAGE21	l_stogir.352
    2b84:      	ldr	x19, [x19]
		0000000000002b84:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    2b88:      	movz	x25, #0x0, lsl #48
    2b8c:      	b	0x2ebc <_stogir.vector.validate+0x91c>
    2b90:      	mov	x0, #0x1                ; =1
    2b94:      	b	0x2b1c <_stogir.vector.validate+0x57c>
    2b98:      	mov	x0, #0x1                ; =1
    2b9c:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002b9c:  ARM64_RELOC_PAGE21	l_stogir.353
    2ba0:      	ldr	x19, [x19]
		0000000000002ba0:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    2ba4:      	mov	x25, #0x28              ; =40
    2ba8:      	b	0x2b94 <_stogir.vector.validate+0x5f4>
    2bac:      	add	x16, sp, #0x40
    2bb0:      	ldr	w0, [x16, #0x4]
    2bb4:      	sxtw	x0, w0
    2bb8:      	ldr	x1, [x21, #0x78]
    2bbc:      	add	x0, x1, x0, lsl #2
    2bc0:      	ldr	w0, [x0]
    2bc4:      	add	w0, w0, #0x1
    2bc8:      	sxtw	x0, w0
    2bcc:      	cmp	x20, x0
    2bd0:      	cset	w0, eq
    2bd4:      	uxtb	w16, w0
    2bd8:      	cmp	w16, wzr
    2bdc:      	cset	x0, eq
    2be0:      	cmp	x0, #0x0
    2be4:      	b.eq	0x2bf4 <_stogir.vector.validate+0x654>
    2be8:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002be8:  ARM64_RELOC_PAGE21	l_stogir.354
    2bec:      	ldr	x19, [x19]
		0000000000002bec:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    2bf0:      	mov	x25, #0x19              ; =25
    2bf4:      	add	x0, x21, #0x28
    2bf8:      	add	x1, x21, #0x50
    2bfc:      	mov	x2, #0x2                ; =2
    2c00:      	b	0x2cec <_stogir.vector.validate+0x74c>
    2c04:      	movz	x5, #0x0, lsl #48
    2c08:      	b	0x2c10 <_stogir.vector.validate+0x670>
    2c0c:      	movz	x5, #0x0, lsl #48
    2c10:      	cmp	x5, #0x0
    2c14:      	b.eq	0x2c48 <_stogir.vector.validate+0x6a8>
    2c18:      	uxtb	w16, w4
    2c1c:      	cmp	w16, wzr
    2c20:      	b.eq	0x2c34 <_stogir.vector.validate+0x694>
    2c24:      	ldr	x4, [x21]
    2c28:      	add	x3, x4, x3, lsl #4
    2c2c:      	ldr	x3, [x3]
    2c30:      	b	0x2c40 <_stogir.vector.validate+0x6a0>
    2c34:      	ldr	x3, [x21, #0x28]
    2c38:      	add	x3, x3, x6, lsl #4
    2c3c:      	ldr	x3, [x3]
    2c40:      	mov	w4, #0x1                ; =1
    2c44:      	b	0x2c50 <_stogir.vector.validate+0x6b0>
    2c48:      	movz	w4, #0x0, lsl #16
    2c4c:      	movz	x3, #0x0, lsl #48
    2c50:      	ubfx	x4, x4, #0, #32
    2c54:      	lsr	x16, x4, #0
    2c58:      	cmp	x16, #0x1
    2c5c:      	b.eq	0x2c78 <_stogir.vector.validate+0x6d8>
    2c60:      	b.lo	0x2c68 <_stogir.vector.validate+0x6c8>
    2c64:      	b	0x2c7c <_stogir.vector.validate+0x6dc>
    2c68:      	cmp	x16, #0x0
    2c6c:      	b.eq	0x2c74 <_stogir.vector.validate+0x6d4>
    2c70:      	b	0x2c7c <_stogir.vector.validate+0x6dc>
    2c74:      	b	0x2c80 <_stogir.vector.validate+0x6e0>
    2c78:      	b	0x2e88 <_stogir.vector.validate+0x8e8>
    2c7c:      	b	0x2f7c <_stogir.vector.validate+0x9dc>
    2c80:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002c80:  ARM64_RELOC_PAGE21	l_stogir.355
    2c84:      	ldr	x19, [x19]
		0000000000002c84:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    2c88:      	mov	x25, #0x18              ; =24
    2c8c:      	b	0x2ce4 <_stogir.vector.validate+0x744>
    2c90:      	movz	w4, #0x0, lsl #16
    2c94:      	movz	w3, #0x0, lsl #16
    2c98:      	b	0x2ca8 <_stogir.vector.validate+0x708>
    2c9c:      	nop
    2ca0:      	movz	w4, #0x0, lsl #16
    2ca4:      	movz	w3, #0x0, lsl #16
    2ca8:      	ubfx	x4, x4, #0, #32
    2cac:      	lsr	x16, x4, #0
    2cb0:      	cmp	x16, #0x1
    2cb4:      	b.eq	0x2cd0 <_stogir.vector.validate+0x730>
    2cb8:      	b.lo	0x2cc0 <_stogir.vector.validate+0x720>
    2cbc:      	b	0x2cd4 <_stogir.vector.validate+0x734>
    2cc0:      	cmp	x16, #0x0
    2cc4:      	b.eq	0x2ccc <_stogir.vector.validate+0x72c>
    2cc8:      	b	0x2cd4 <_stogir.vector.validate+0x734>
    2ccc:      	b	0x2cd8 <_stogir.vector.validate+0x738>
    2cd0:      	b	0x2d40 <_stogir.vector.validate+0x7a0>
    2cd4:      	b	0x2f74 <_stogir.vector.validate+0x9d4>
    2cd8:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002cd8:  ARM64_RELOC_PAGE21	l_stogir.355
    2cdc:      	ldr	x19, [x19]
		0000000000002cdc:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    2ce0:      	mov	x25, #0x18              ; =24
    2ce4:      	add	x2, x2, #0x1
    2ce8:      	sxtw	x2, w2
    2cec:      	cmp	x25, #0x0
    2cf0:      	b.ne	0x2e60 <_stogir.vector.validate+0x8c0>
    2cf4:      	cmp	x2, x20
    2cf8:      	b.gt	0x2e60 <_stogir.vector.validate+0x8c0>
    2cfc:      	uxtb	w16, w24
    2d00:      	cmp	w16, wzr
    2d04:      	b.ne	0x2ca0 <_stogir.vector.validate+0x700>
    2d08:      	ldr	x3, [x21, #0x8]
    2d0c:      	cmp	x22, x3
    2d10:      	b.ge	0x2da4 <_stogir.vector.validate+0x804>
    2d14:      	ldr	x3, [x27, #0x8]
    2d18:      	cmp	x22, x3
    2d1c:      	b.ge	0x2d9c <_stogir.vector.validate+0x7fc>
    2d20:      	ldr	x3, [x21, #0x78]
    2d24:      	add	x3, x26, x3
    2d28:      	ldr	w3, [x3]
    2d2c:      	sxtw	x3, w3
    2d30:      	cmp	x3, #0x0
    2d34:      	cset	w3, ge
    2d38:      	ubfx	x3, x3, #0, #8
    2d3c:      	b	0x2da0 <_stogir.vector.validate+0x800>
    2d40:      	sxtw	x3, w3
    2d44:      	cmp	x3, #0x0
    2d48:      	cset	w4, gt
    2d4c:      	movz	x16, #0x0, lsl #48
    2d50:      	sub	x5, x16, x3
    2d54:      	sub	x6, x5, #0x1
    2d58:      	uxtb	w16, w4
    2d5c:      	cmp	w16, wzr
    2d60:      	b.eq	0x2e20 <_stogir.vector.validate+0x880>
    2d64:      	ldr	x5, [x21, #0x8]
    2d68:      	cmp	x3, x5
    2d6c:      	b.ge	0x2c04 <_stogir.vector.validate+0x664>
    2d70:      	ldr	x5, [x27, #0x8]
    2d74:      	cmp	x3, x5
    2d78:      	b.ge	0x2f24 <_stogir.vector.validate+0x984>
    2d7c:      	ldr	x5, [x21, #0x78]
    2d80:      	add	x5, x5, x3, lsl #2
    2d84:      	ldr	w5, [x5]
    2d88:      	sxtw	x5, w5
    2d8c:      	cmp	x5, #0x0
    2d90:      	cset	w5, ge
    2d94:      	ubfx	x5, x5, #0, #8
    2d98:      	b	0x2f28 <_stogir.vector.validate+0x988>
    2d9c:      	movz	x3, #0x0, lsl #48
    2da0:      	b	0x2da8 <_stogir.vector.validate+0x808>
    2da4:      	movz	x3, #0x0, lsl #48
    2da8:      	cmp	x3, #0x0
    2dac:      	b.eq	0x2ca0 <_stogir.vector.validate+0x700>
    2db0:      	orr	w3, w2, wzr
    2db4:      	sxtw	x3, w3
    2db8:      	cmp	x3, #0x1
    2dbc:      	b.lt	0x2c90 <_stogir.vector.validate+0x6f0>
    2dc0:      	ldr	x4, [x21, #0x78]
    2dc4:      	add	x4, x26, x4
    2dc8:      	ldr	w4, [x4]
    2dcc:      	sxtw	x4, w4
    2dd0:      	cmp	x3, x4
    2dd4:      	b.gt	0x2c90 <_stogir.vector.validate+0x6f0>
    2dd8:      	ldr	x4, [x21]
    2ddc:      	asr	x16, x3, #63
    2de0:      	lsr	x16, x16, #62
    2de4:      	add	x5, x3, x16
    2de8:      	asr	x5, x5, #2
    2dec:      	asr	x16, x3, #63
    2df0:      	lsr	x16, x16, #62
    2df4:      	add	x3, x3, x16
    2df8:      	and	x3, x3, #0x3
    2dfc:      	sub	x3, x3, x16
    2e00:      	add	x5, x5, x22
    2e04:      	add	x4, x4, x5, lsl #4
    2e08:      	add	x3, x4, x3, lsl #2
    2e0c:      	ldr	w3, [x3]
    2e10:      	movn	w17, #0x0, lsl #16
    2e14:      	and	w3, w3, w17
    2e18:      	mov	w4, #0x1                ; =1
    2e1c:      	b	0x2c98 <_stogir.vector.validate+0x6f8>
    2e20:      	cmp	x3, #0x0
    2e24:      	b.ge	0x2c0c <_stogir.vector.validate+0x66c>
    2e28:      	ldr	x7, [x0, #0x8]
    2e2c:      	ldr	x8, [x1, #0x8]
    2e30:      	cmp	x7, x8
    2e34:      	b.ne	0x2f1c <_stogir.vector.validate+0x97c>
    2e38:      	cmp	x5, x7
    2e3c:      	b.gt	0x2f50 <_stogir.vector.validate+0x9b0>
    2e40:      	ldr	x5, [x21, #0x50]
    2e44:      	add	x5, x5, x6, lsl #2
    2e48:      	ldr	w5, [x5]
    2e4c:      	sxtw	x5, w5
    2e50:      	cmp	x5, #0x0
    2e54:      	cset	w5, gt
    2e58:      	ubfx	x5, x5, #0, #8
    2e5c:      	b	0x2f54 <_stogir.vector.validate+0x9b4>
    2e60:      	cmp	x25, #0x0
    2e64:      	b.ne	0x2b90 <_stogir.vector.validate+0x5f0>
    2e68:      	ldr	w0, [sp, #0x1c8]
    2e6c:      	mov	w1, w23
    2e70:      	bl	0x2e70 <_stogir.vector.validate+0x8d0>
		0000000000002e70:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2e74:      	sxtw	x0, w0
    2e78:      	and	x19, x0, #0xffffffff
    2e7c:      	movz	x0, #0x0, lsl #48
    2e80:      	movz	x25, #0x0, lsl #48
    2e84:      	b	0x2b94 <_stogir.vector.validate+0x5f4>
    2e88:      	ubfx	x3, x3, #0, #32
    2e8c:      	ubfx	x3, x3, #8, #8
    2e90:      	cmp	x3, x28
    2e94:      	b.eq	0x2ea4 <_stogir.vector.validate+0x904>
    2e98:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002e98:  ARM64_RELOC_PAGE21	l_stogir.356
    2e9c:      	ldr	x19, [x19]
		0000000000002e9c:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    2ea0:      	mov	x25, #0x1e              ; =30
    2ea4:      	b	0x2c8c <_stogir.vector.validate+0x6ec>
    2ea8:      	mov	w28, w19
    2eac:      	mov	x0, x25
    2eb0:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002eb0:  ARM64_RELOC_PAGE21	l_stogir.357
    2eb4:      	ldr	x19, [x19]
		0000000000002eb4:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    2eb8:      	mov	x25, #0x20              ; =32
    2ebc:      	add	x16, sp, #0x40
    2ec0:      	ldr	w1, [x16, #0x4]
    2ec4:      	add	x8, sp, #0x170
    2ec8:      	str	w28, [sp, #0x1c8]
    2ecc:      	mov	x28, x0
    2ed0:      	mov	x0, x21
    2ed4:      	bl	0x2ed4 <_stogir.vector.validate+0x934>
		0000000000002ed4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    2ed8:      	add	x16, sp, #0x170
    2edc:      	ldr	w0, [x16]
    2ee0:      	lsr	x16, x0, #0
    2ee4:      	cmp	x16, #0x1
    2ee8:      	b.eq	0x2f04 <_stogir.vector.validate+0x964>
    2eec:      	b.lo	0x2ef4 <_stogir.vector.validate+0x954>
    2ef0:      	b	0x2f08 <_stogir.vector.validate+0x968>
    2ef4:      	cmp	x16, #0x0
    2ef8:      	b.eq	0x2f00 <_stogir.vector.validate+0x960>
    2efc:      	b	0x2f08 <_stogir.vector.validate+0x968>
    2f00:      	b	0x2f0c <_stogir.vector.validate+0x96c>
    2f04:      	b	0x2f2c <_stogir.vector.validate+0x98c>
    2f08:      	b	0x2f84 <_stogir.vector.validate+0x9e4>
    2f0c:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xe4>
		0000000000002f0c:  ARM64_RELOC_PAGE21	l_stogir.358
    2f10:      	ldr	x19, [x19]
		0000000000002f10:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    2f14:      	mov	x25, #0x19              ; =25
    2f18:      	b	0x2bf4 <_stogir.vector.validate+0x654>
    2f1c:      	movz	x5, #0x0, lsl #48
    2f20:      	b	0x2c10 <_stogir.vector.validate+0x670>
    2f24:      	movz	x5, #0x0, lsl #48
    2f28:      	b	0x2c08 <_stogir.vector.validate+0x668>
    2f2c:      	add	x16, sp, #0x170
    2f30:      	ldr	x0, [x16, #0x8]
    2f34:      	add	x16, sp, #0x40
    2f38:      	ldr	w1, [x16, #0x4]
    2f3c:      	sxtw	x1, w1
    2f40:      	cmp	x1, #0x0
    2f44:      	b.gt	0x2f58 <_stogir.vector.validate+0x9b8>
    2f48:      	mov	x0, #0x1                ; =1
    2f4c:      	b	0x2be0 <_stogir.vector.validate+0x640>
    2f50:      	movz	x5, #0x0, lsl #48
    2f54:      	b	0x2f20 <_stogir.vector.validate+0x980>
    2f58:      	uxtb	w0, w0
    2f5c:      	cmp	x0, #0x70
    2f60:      	b.eq	0x2bac <_stogir.vector.validate+0x60c>
    2f64:      	cmp	x0, #0x71
    2f68:      	b.eq	0x2bac <_stogir.vector.validate+0x60c>
    2f6c:      	mov	x0, #0x1                ; =1
    2f70:      	b	0x2be0 <_stogir.vector.validate+0x640>
    2f74:      	brk	#0
    2f78:      	b	0x2f74 <_stogir.vector.validate+0x9d4>
    2f7c:      	brk	#0
    2f80:      	b	0x2f7c <_stogir.vector.validate+0x9dc>
    2f84:      	brk	#0
    2f88:      	b	0x2f84 <_stogir.vector.validate+0x9e4>
    2f8c:      	str	x20, [sp, #0x1a8]
    2f90:      	str	w19, [sp, #0x1a0]
    2f94:      	b	0x2744 <_stogir.vector.validate+0x1a4>
    2f98:      	str	x20, [sp, #0x1a8]
    2f9c:      	mov	w20, w0
    2fa0:      	str	w1, [sp, #0x1b0]
    2fa4:      	str	w2, [sp, #0x1b8]
    2fa8:      	str	w3, [sp, #0x1c0]
    2fac:      	b	0x27fc <_stogir.vector.validate+0x25c>
    2fb0:      	str	w19, [sp, #0x1c8]
    2fb4:      	b	0x2a18 <_stogir.vector.validate+0x478>
    2fb8:      	mov	x28, x25
    2fbc:      	b	0x2aac <_stogir.vector.validate+0x50c>

0000000000002fc0 <_stogir.copy.validate>:
    2fc0:      	sub	sp, sp, #0x10
    2fc4:      	sxtw	x1, w1
    2fc8:      	add	x2, x0, #0x78
    2fcc:      	add	x3, x0, #0x28
    2fd0:      	add	x4, x0, #0x50
    2fd4:      	lsl	x5, x1, #2
    2fd8:      	cmp	x1, #0x0
    2fdc:      	cset	w6, gt
    2fe0:      	movz	x16, #0x0, lsl #48
    2fe4:      	sub	x7, x16, x1
    2fe8:      	sub	x9, x7, #0x1
    2fec:      	uxtb	w16, w6
    2ff0:      	cmp	w16, wzr
    2ff4:      	b.eq	0x3030 <_stogir.copy.validate+0x70>
    2ff8:      	ldr	x7, [x0, #0x8]
    2ffc:      	cmp	x1, x7
    3000:      	b.ge	0x308c <_stogir.copy.validate+0xcc>
    3004:      	ldr	x7, [x2, #0x8]
    3008:      	cmp	x1, x7
    300c:      	b.ge	0x321c <_stogir.copy.validate+0x25c>
    3010:      	ldr	x7, [x0, #0x78]
    3014:      	add	x7, x5, x7
    3018:      	ldr	w7, [x7]
    301c:      	sxtw	x7, w7
    3020:      	cmp	x7, #0x0
    3024:      	cset	w7, ge
    3028:      	ubfx	x7, x7, #0, #8
    302c:      	b	0x3220 <_stogir.copy.validate+0x260>
    3030:      	cmp	x1, #0x0
    3034:      	b.ge	0x3094 <_stogir.copy.validate+0xd4>
    3038:      	ldr	x10, [x3, #0x8]
    303c:      	ldr	x11, [x4, #0x8]
    3040:      	cmp	x10, x11
    3044:      	b.ne	0x3070 <_stogir.copy.validate+0xb0>
    3048:      	cmp	x7, x10
    304c:      	b.gt	0x3224 <_stogir.copy.validate+0x264>
    3050:      	ldr	x7, [x0, #0x50]
    3054:      	add	x7, x7, x9, lsl #2
    3058:      	ldr	w7, [x7]
    305c:      	sxtw	x7, w7
    3060:      	cmp	x7, #0x0
    3064:      	cset	w7, gt
    3068:      	ubfx	x7, x7, #0, #8
    306c:      	b	0x3228 <_stogir.copy.validate+0x268>
    3070:      	movz	x7, #0x0, lsl #48
    3074:      	b	0x3098 <_stogir.copy.validate+0xd8>
    3078:      	mov	x1, #0x1                ; =1
    307c:      	adrp	x0, 0x3000 <_stogir.copy.validate+0x40>
		000000000000307c:  ARM64_RELOC_PAGE21	l_stogir.359
    3080:      	ldr	x0, [x0]
		0000000000003080:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    3084:      	mov	x2, #0x21               ; =33
    3088:      	b	0x3124 <_stogir.copy.validate+0x164>
    308c:      	movz	x7, #0x0, lsl #48
    3090:      	b	0x3098 <_stogir.copy.validate+0xd8>
    3094:      	movz	x7, #0x0, lsl #48
    3098:      	cmp	x7, #0x0
    309c:      	b.eq	0x30d8 <_stogir.copy.validate+0x118>
    30a0:      	uxtb	w16, w6
    30a4:      	cmp	w16, wzr
    30a8:      	b.eq	0x30c0 <_stogir.copy.validate+0x100>
    30ac:      	ldr	x6, [x0]
    30b0:      	add	x6, x6, x1, lsl #4
    30b4:      	ldr	x7, [x6]
    30b8:      	ldr	x6, [x6, #0x8]
    30bc:      	b	0x30d0 <_stogir.copy.validate+0x110>
    30c0:      	ldr	x6, [x0, #0x28]
    30c4:      	add	x6, x6, x9, lsl #4
    30c8:      	ldr	x7, [x6]
    30cc:      	ldr	x6, [x6, #0x8]
    30d0:      	mov	w9, #0x1                ; =1
    30d4:      	b	0x30e4 <_stogir.copy.validate+0x124>
    30d8:      	movz	w9, #0x0, lsl #16
    30dc:      	movz	x7, #0x0, lsl #48
    30e0:      	movz	x6, #0x0, lsl #48
    30e4:      	ubfx	x9, x9, #0, #32
    30e8:      	lsr	x16, x9, #0
    30ec:      	cmp	x16, #0x1
    30f0:      	b.eq	0x310c <_stogir.copy.validate+0x14c>
    30f4:      	b.lo	0x30fc <_stogir.copy.validate+0x13c>
    30f8:      	b	0x3110 <_stogir.copy.validate+0x150>
    30fc:      	cmp	x16, #0x0
    3100:      	b.eq	0x3108 <_stogir.copy.validate+0x148>
    3104:      	b	0x3110 <_stogir.copy.validate+0x150>
    3108:      	b	0x3114 <_stogir.copy.validate+0x154>
    310c:      	b	0x3138 <_stogir.copy.validate+0x178>
    3110:      	b	0x322c <_stogir.copy.validate+0x26c>
    3114:      	mov	x1, #0x1                ; =1
    3118:      	adrp	x0, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003118:  ARM64_RELOC_PAGE21	l_stogir.360
    311c:      	ldr	x0, [x0]
		000000000000311c:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    3120:      	mov	x2, #0x18               ; =24
    3124:      	str	x1, [x8]
    3128:      	str	x0, [x8, #0x8]
    312c:      	str	x2, [x8, #0x10]
    3130:      	add	sp, sp, #0x10
    3134:      	ret
    3138:      	mov	x16, sp
    313c:      	str	x7, [x16]
    3140:      	mov	x16, sp
    3144:      	str	x6, [x16, #0x8]
    3148:      	cmp	x1, #0x0
    314c:      	b.le	0x3078 <_stogir.copy.validate+0xb8>
    3150:      	uxtb	w1, w7
    3154:      	cmp	x1, #0x44
    3158:      	b.ne	0x3078 <_stogir.copy.validate+0xb8>
    315c:      	ldr	x1, [x0, #0x78]
    3160:      	add	x1, x5, x1
    3164:      	ldr	w1, [x1]
    3168:      	sxtw	x1, w1
    316c:      	cmp	x1, #0x2
    3170:      	b.ne	0x3078 <_stogir.copy.validate+0xb8>
    3174:      	ubfx	x7, x7, #0, #32
    3178:      	ubfx	x1, x7, #8, #8
    317c:      	orr	x5, x1, xzr
    3180:      	cmp	x5, #0x0
    3184:      	b.eq	0x3078 <_stogir.copy.validate+0xb8>
    3188:      	cmp	x5, #0xd
    318c:      	b.le	0x31b8 <_stogir.copy.validate+0x1f8>
    3190:      	cmp	x5, #0xf
    3194:      	b.le	0x3078 <_stogir.copy.validate+0xb8>
    3198:      	cmp	x5, #0x80
    319c:      	b.ge	0x3078 <_stogir.copy.validate+0xb8>
    31a0:      	and	w1, w1, #0xf
    31a4:      	ubfx	x1, x1, #0, #32
    31a8:      	cmp	x1, #0x1
    31ac:      	b.lt	0x3078 <_stogir.copy.validate+0xb8>
    31b0:      	cmp	x1, #0xd
    31b4:      	b.gt	0x3078 <_stogir.copy.validate+0xb8>
    31b8:      	mov	x16, sp
    31bc:      	ldr	w1, [x16, #0x4]
    31c0:      	sxtw	x1, w1
    31c4:      	cmp	x1, #0x0
    31c8:      	cset	w6, gt
    31cc:      	movz	x16, #0x0, lsl #48
    31d0:      	sub	x7, x16, x1
    31d4:      	sub	x9, x7, #0x1
    31d8:      	uxtb	w16, w6
    31dc:      	cmp	w16, wzr
    31e0:      	b.eq	0x3248 <_stogir.copy.validate+0x288>
    31e4:      	ldr	x3, [x0, #0x8]
    31e8:      	cmp	x1, x3
    31ec:      	b.ge	0x3288 <_stogir.copy.validate+0x2c8>
    31f0:      	ldr	x2, [x2, #0x8]
    31f4:      	cmp	x1, x2
    31f8:      	b.ge	0x334c <_stogir.copy.validate+0x38c>
    31fc:      	ldr	x2, [x0, #0x78]
    3200:      	add	x2, x2, x1, lsl #2
    3204:      	ldr	w2, [x2]
    3208:      	sxtw	x2, w2
    320c:      	cmp	x2, #0x0
    3210:      	cset	w2, ge
    3214:      	ubfx	x2, x2, #0, #8
    3218:      	b	0x3350 <_stogir.copy.validate+0x390>
    321c:      	movz	x7, #0x0, lsl #48
    3220:      	b	0x3090 <_stogir.copy.validate+0xd0>
    3224:      	movz	x7, #0x0, lsl #48
    3228:      	b	0x3074 <_stogir.copy.validate+0xb4>
    322c:      	brk	#0
    3230:      	b	0x322c <_stogir.copy.validate+0x26c>
    3234:      	mov	x1, #0x1                ; =1
    3238:      	adrp	x0, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003238:  ARM64_RELOC_PAGE21	l_stogir.361
    323c:      	ldr	x0, [x0]
		000000000000323c:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    3240:      	mov	x2, #0x20               ; =32
    3244:      	b	0x3088 <_stogir.copy.validate+0xc8>
    3248:      	cmp	x1, #0x0
    324c:      	b.ge	0x3290 <_stogir.copy.validate+0x2d0>
    3250:      	ldr	x2, [x3, #0x8]
    3254:      	ldr	x3, [x4, #0x8]
    3258:      	cmp	x2, x3
    325c:      	b.ne	0x3344 <_stogir.copy.validate+0x384>
    3260:      	cmp	x7, x2
    3264:      	b.gt	0x3354 <_stogir.copy.validate+0x394>
    3268:      	ldr	x2, [x0, #0x50]
    326c:      	add	x2, x2, x9, lsl #2
    3270:      	ldr	w2, [x2]
    3274:      	sxtw	x2, w2
    3278:      	cmp	x2, #0x0
    327c:      	cset	w2, gt
    3280:      	ubfx	x2, x2, #0, #8
    3284:      	b	0x3358 <_stogir.copy.validate+0x398>
    3288:      	movz	x2, #0x0, lsl #48
    328c:      	b	0x3294 <_stogir.copy.validate+0x2d4>
    3290:      	movz	x2, #0x0, lsl #48
    3294:      	cmp	x2, #0x0
    3298:      	b.eq	0x32cc <_stogir.copy.validate+0x30c>
    329c:      	uxtb	w16, w6
    32a0:      	cmp	w16, wzr
    32a4:      	b.eq	0x32b8 <_stogir.copy.validate+0x2f8>
    32a8:      	ldr	x0, [x0]
    32ac:      	add	x0, x0, x1, lsl #4
    32b0:      	ldr	x0, [x0]
    32b4:      	b	0x32c4 <_stogir.copy.validate+0x304>
    32b8:      	ldr	x0, [x0, #0x28]
    32bc:      	add	x0, x0, x9, lsl #4
    32c0:      	ldr	x0, [x0]
    32c4:      	mov	w1, #0x1                ; =1
    32c8:      	b	0x32d4 <_stogir.copy.validate+0x314>
    32cc:      	movz	w1, #0x0, lsl #16
    32d0:      	movz	x0, #0x0, lsl #48
    32d4:      	ubfx	x1, x1, #0, #32
    32d8:      	lsr	x16, x1, #0
    32dc:      	cmp	x16, #0x1
    32e0:      	b.eq	0x32fc <_stogir.copy.validate+0x33c>
    32e4:      	b.lo	0x32ec <_stogir.copy.validate+0x32c>
    32e8:      	b	0x3300 <_stogir.copy.validate+0x340>
    32ec:      	cmp	x16, #0x0
    32f0:      	b.eq	0x32f8 <_stogir.copy.validate+0x338>
    32f4:      	b	0x3300 <_stogir.copy.validate+0x340>
    32f8:      	b	0x3304 <_stogir.copy.validate+0x344>
    32fc:      	b	0x3318 <_stogir.copy.validate+0x358>
    3300:      	b	0x335c <_stogir.copy.validate+0x39c>
    3304:      	mov	x1, #0x1                ; =1
    3308:      	adrp	x0, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003308:  ARM64_RELOC_PAGE21	l_stogir.362
    330c:      	ldr	x0, [x0]
		000000000000330c:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    3310:      	mov	x2, #0x13               ; =19
    3314:      	b	0x3244 <_stogir.copy.validate+0x284>
    3318:      	mov	x16, sp
    331c:      	ldr	w1, [x16]
    3320:      	ubfx	x0, x0, #0, #32
    3324:      	ubfx	x0, x0, #8, #8
    3328:      	ubfx	x1, x1, #8, #8
    332c:      	cmp	x0, x1
    3330:      	b.ne	0x3234 <_stogir.copy.validate+0x274>
    3334:      	and	x0, x5, #0xffffffff
    3338:      	movz	x1, #0x0, lsl #48
    333c:      	movz	x2, #0x0, lsl #48
    3340:      	b	0x3244 <_stogir.copy.validate+0x284>
    3344:      	movz	x2, #0x0, lsl #48
    3348:      	b	0x3294 <_stogir.copy.validate+0x2d4>
    334c:      	movz	x2, #0x0, lsl #48
    3350:      	b	0x328c <_stogir.copy.validate+0x2cc>
    3354:      	movz	x2, #0x0, lsl #48
    3358:      	b	0x3348 <_stogir.copy.validate+0x388>
    335c:      	brk	#0
    3360:      	b	0x335c <_stogir.copy.validate+0x39c>

0000000000003364 <_stogir.graph.lookup>:
    3364:      	sxtw	x1, w1
    3368:      	add	x2, x0, #0x28
    336c:      	cmp	x1, #0x0
    3370:      	cset	w3, gt
    3374:      	movz	x16, #0x0, lsl #48
    3378:      	sub	x4, x16, x1
    337c:      	sub	x5, x4, #0x1
    3380:      	uxtb	w16, w3
    3384:      	cmp	w16, wzr
    3388:      	b.eq	0x33c8 <_stogir.graph.lookup+0x64>
    338c:      	ldr	x2, [x0, #0x8]
    3390:      	cmp	x1, x2
    3394:      	b.ge	0x3414 <_stogir.graph.lookup+0xb0>
    3398:      	add	x2, x0, #0x78
    339c:      	ldr	x2, [x2, #0x8]
    33a0:      	cmp	x1, x2
    33a4:      	b.ge	0x348c <_stogir.graph.lookup+0x128>
    33a8:      	ldr	x2, [x0, #0x78]
    33ac:      	add	x2, x2, x1, lsl #2
    33b0:      	ldr	w2, [x2]
    33b4:      	sxtw	x2, w2
    33b8:      	cmp	x2, #0x0
    33bc:      	cset	w2, ge
    33c0:      	ubfx	x2, x2, #0, #8
    33c4:      	b	0x3490 <_stogir.graph.lookup+0x12c>
    33c8:      	cmp	x1, #0x0
    33cc:      	b.ge	0x341c <_stogir.graph.lookup+0xb8>
    33d0:      	add	x6, x0, #0x50
    33d4:      	ldr	x2, [x2, #0x8]
    33d8:      	ldr	x6, [x6, #0x8]
    33dc:      	cmp	x2, x6
    33e0:      	b.ne	0x340c <_stogir.graph.lookup+0xa8>
    33e4:      	cmp	x4, x2
    33e8:      	b.gt	0x3494 <_stogir.graph.lookup+0x130>
    33ec:      	ldr	x2, [x0, #0x50]
    33f0:      	add	x2, x2, x5, lsl #2
    33f4:      	ldr	w2, [x2]
    33f8:      	sxtw	x2, w2
    33fc:      	cmp	x2, #0x0
    3400:      	cset	w2, gt
    3404:      	ubfx	x2, x2, #0, #8
    3408:      	b	0x3498 <_stogir.graph.lookup+0x134>
    340c:      	movz	x2, #0x0, lsl #48
    3410:      	b	0x3420 <_stogir.graph.lookup+0xbc>
    3414:      	movz	x2, #0x0, lsl #48
    3418:      	b	0x3420 <_stogir.graph.lookup+0xbc>
    341c:      	movz	x2, #0x0, lsl #48
    3420:      	cmp	x2, #0x0
    3424:      	b.eq	0x3460 <_stogir.graph.lookup+0xfc>
    3428:      	uxtb	w16, w3
    342c:      	cmp	w16, wzr
    3430:      	b.eq	0x3448 <_stogir.graph.lookup+0xe4>
    3434:      	ldr	x0, [x0]
    3438:      	add	x0, x0, x1, lsl #4
    343c:      	ldr	x1, [x0]
    3440:      	ldr	x0, [x0, #0x8]
    3444:      	b	0x3458 <_stogir.graph.lookup+0xf4>
    3448:      	ldr	x0, [x0, #0x28]
    344c:      	add	x0, x0, x5, lsl #4
    3450:      	ldr	x1, [x0]
    3454:      	ldr	x0, [x0, #0x8]
    3458:      	mov	x2, #0x1                ; =1
    345c:      	b	0x346c <_stogir.graph.lookup+0x108>
    3460:      	movz	x2, #0x0, lsl #48
    3464:      	movz	x1, #0x0, lsl #48
    3468:      	movz	x0, #0x0, lsl #48
    346c:      	str	x2, [x8]
    3470:      	str	x1, [x8, #0x8]
    3474:      	str	x0, [x8, #0x10]
    3478:      	movz	x17, #0x0, lsl #48
    347c:      	str	x17, [x8, #0x18]
    3480:      	movz	x17, #0x0, lsl #48
    3484:      	str	x17, [x8, #0x20]
    3488:      	ret
    348c:      	movz	x2, #0x0, lsl #48
    3490:      	b	0x3418 <_stogir.graph.lookup+0xb4>
    3494:      	movz	x2, #0x0, lsl #48
    3498:      	b	0x3410 <_stogir.graph.lookup+0xac>

000000000000349c <_stogir.checked.validate-projection>:
    349c:      	sub	sp, sp, #0x40
    34a0:      	str	x29, [sp]
    34a4:      	str	x30, [sp, #0x8]
    34a8:      	mov	x29, sp
    34ac:      	str	x19, [sp, #0x30]
    34b0:      	sxtw	x1, w1
    34b4:      	add	x2, x0, #0x78
    34b8:      	add	x3, x0, #0x28
    34bc:      	lsl	x4, x1, #2
    34c0:      	cmp	x1, #0x0
    34c4:      	cset	w5, gt
    34c8:      	movz	x16, #0x0, lsl #48
    34cc:      	sub	x6, x16, x1
    34d0:      	sub	x7, x6, #0x1
    34d4:      	uxtb	w16, w5
    34d8:      	cmp	w16, wzr
    34dc:      	b.eq	0x3518 <_stogir.checked.validate-projection+0x7c>
    34e0:      	ldr	x3, [x0, #0x8]
    34e4:      	cmp	x1, x3
    34e8:      	b.ge	0x3564 <_stogir.checked.validate-projection+0xc8>
    34ec:      	ldr	x2, [x2, #0x8]
    34f0:      	cmp	x1, x2
    34f4:      	b.ge	0x3634 <_stogir.checked.validate-projection+0x198>
    34f8:      	ldr	x2, [x0, #0x78]
    34fc:      	add	x2, x4, x2
    3500:      	ldr	w2, [x2]
    3504:      	sxtw	x2, w2
    3508:      	cmp	x2, #0x0
    350c:      	cset	w2, ge
    3510:      	ubfx	x2, x2, #0, #8
    3514:      	b	0x3638 <_stogir.checked.validate-projection+0x19c>
    3518:      	cmp	x1, #0x0
    351c:      	b.ge	0x356c <_stogir.checked.validate-projection+0xd0>
    3520:      	add	x2, x0, #0x50
    3524:      	ldr	x3, [x3, #0x8]
    3528:      	ldr	x2, [x2, #0x8]
    352c:      	cmp	x3, x2
    3530:      	b.ne	0x355c <_stogir.checked.validate-projection+0xc0>
    3534:      	cmp	x6, x3
    3538:      	b.gt	0x36a0 <_stogir.checked.validate-projection+0x204>
    353c:      	ldr	x2, [x0, #0x50]
    3540:      	add	x2, x2, x7, lsl #2
    3544:      	ldr	w2, [x2]
    3548:      	sxtw	x2, w2
    354c:      	cmp	x2, #0x0
    3550:      	cset	w2, gt
    3554:      	ubfx	x2, x2, #0, #8
    3558:      	b	0x36a4 <_stogir.checked.validate-projection+0x208>
    355c:      	movz	x2, #0x0, lsl #48
    3560:      	b	0x3570 <_stogir.checked.validate-projection+0xd4>
    3564:      	movz	x2, #0x0, lsl #48
    3568:      	b	0x3570 <_stogir.checked.validate-projection+0xd4>
    356c:      	movz	x2, #0x0, lsl #48
    3570:      	cmp	x2, #0x0
    3574:      	b.eq	0x35a8 <_stogir.checked.validate-projection+0x10c>
    3578:      	uxtb	w16, w5
    357c:      	cmp	w16, wzr
    3580:      	b.eq	0x3594 <_stogir.checked.validate-projection+0xf8>
    3584:      	ldr	x2, [x0]
    3588:      	add	x2, x2, x1, lsl #4
    358c:      	ldr	x2, [x2]
    3590:      	b	0x35a0 <_stogir.checked.validate-projection+0x104>
    3594:      	ldr	x2, [x0, #0x28]
    3598:      	add	x2, x2, x7, lsl #4
    359c:      	ldr	x2, [x2]
    35a0:      	mov	w3, #0x1                ; =1
    35a4:      	b	0x35b0 <_stogir.checked.validate-projection+0x114>
    35a8:      	movz	w3, #0x0, lsl #16
    35ac:      	movz	x2, #0x0, lsl #48
    35b0:      	ubfx	x3, x3, #0, #32
    35b4:      	lsr	x16, x3, #0
    35b8:      	cmp	x16, #0x1
    35bc:      	b.eq	0x35d8 <_stogir.checked.validate-projection+0x13c>
    35c0:      	b.lo	0x35c8 <_stogir.checked.validate-projection+0x12c>
    35c4:      	b	0x35dc <_stogir.checked.validate-projection+0x140>
    35c8:      	cmp	x16, #0x0
    35cc:      	b.eq	0x35d4 <_stogir.checked.validate-projection+0x138>
    35d0:      	b	0x35dc <_stogir.checked.validate-projection+0x140>
    35d4:      	b	0x35e0 <_stogir.checked.validate-projection+0x144>
    35d8:      	b	0x35f8 <_stogir.checked.validate-projection+0x15c>
    35dc:      	b	0x36a8 <_stogir.checked.validate-projection+0x20c>
    35e0:      	mov	x19, x8
    35e4:      	mov	x0, #0x1                ; =1
    35e8:      	adrp	x1, 0x3000 <_stogir.copy.validate+0x40>
		00000000000035e8:  ARM64_RELOC_PAGE21	l_stogir.363
    35ec:      	ldr	x1, [x1]
		00000000000035ec:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    35f0:      	mov	x2, #0x10               ; =16
    35f4:      	b	0x3614 <_stogir.checked.validate-projection+0x178>
    35f8:      	cmp	x1, #0x0
    35fc:      	b.gt	0x363c <_stogir.checked.validate-projection+0x1a0>
    3600:      	mov	x19, x8
    3604:      	mov	x0, #0x1                ; =1
    3608:      	adrp	x1, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003608:  ARM64_RELOC_PAGE21	l_stogir.364
    360c:      	ldr	x1, [x1]
		000000000000360c:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    3610:      	mov	x2, #0x1c               ; =28
    3614:      	str	x0, [x19]
    3618:      	str	x1, [x19, #0x8]
    361c:      	str	x2, [x19, #0x10]
    3620:      	ldr	x19, [sp, #0x30]
    3624:      	ldr	x29, [sp]
    3628:      	ldr	x30, [sp, #0x8]
    362c:      	add	sp, sp, #0x40
    3630:      	ret
    3634:      	movz	x2, #0x0, lsl #48
    3638:      	b	0x3568 <_stogir.checked.validate-projection+0xcc>
    363c:      	uxtb	w1, w2
    3640:      	cmp	x1, #0x2c
    3644:      	b.ne	0x36b0 <_stogir.checked.validate-projection+0x214>
    3648:      	orr	w1, w2, wzr
    364c:      	ubfx	x1, x1, #0, #32
    3650:      	ubfx	x1, x1, #8, #8
    3654:      	cmp	x1, #0x1
    3658:      	b.ne	0x36b8 <_stogir.checked.validate-projection+0x21c>
    365c:      	ldr	x1, [x0, #0x78]
    3660:      	add	x1, x4, x1
    3664:      	ldr	w1, [x1]
    3668:      	sxtw	x1, w1
    366c:      	cmp	x1, #0x1
    3670:      	b.ne	0x36c0 <_stogir.checked.validate-projection+0x224>
    3674:      	lsr	x1, x2, #32
    3678:      	mov	x19, x8
    367c:      	add	x8, sp, #0x10
    3680:      	bl	0x3680 <_stogir.checked.validate-projection+0x1e4>
		0000000000003680:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    3684:      	add	x16, sp, #0x10
    3688:      	ldr	x0, [x16]
    368c:      	add	x16, sp, #0x10
    3690:      	ldr	x1, [x16, #0x8]
    3694:      	add	x16, sp, #0x10
    3698:      	ldr	x2, [x16, #0x10]
    369c:      	b	0x3614 <_stogir.checked.validate-projection+0x178>
    36a0:      	movz	x2, #0x0, lsl #48
    36a4:      	b	0x3560 <_stogir.checked.validate-projection+0xc4>
    36a8:      	brk	#0
    36ac:      	b	0x36a8 <_stogir.checked.validate-projection+0x20c>
    36b0:      	mov	x19, x8
    36b4:      	b	0x3604 <_stogir.checked.validate-projection+0x168>
    36b8:      	mov	x19, x8
    36bc:      	b	0x3604 <_stogir.checked.validate-projection+0x168>
    36c0:      	mov	x19, x8
    36c4:      	b	0x3604 <_stogir.checked.validate-projection+0x168>

00000000000036c8 <_stogir.checked.validate>:
    36c8:      	sub	sp, sp, #0x20
    36cc:      	str	x29, [sp]
    36d0:      	str	x30, [sp, #0x8]
    36d4:      	mov	x29, sp
    36d8:      	str	x19, [sp, #0x10]
    36dc:      	sxtw	x1, w1
    36e0:      	add	x2, x0, #0x78
    36e4:      	add	x3, x0, #0x28
    36e8:      	add	x4, x0, #0x50
    36ec:      	lsl	x5, x1, #2
    36f0:      	cmp	x1, #0x0
    36f4:      	cset	w6, gt
    36f8:      	movz	x16, #0x0, lsl #48
    36fc:      	sub	x7, x16, x1
    3700:      	sub	x9, x7, #0x1
    3704:      	uxtb	w16, w6
    3708:      	cmp	w16, wzr
    370c:      	b.eq	0x3748 <_stogir.checked.validate+0x80>
    3710:      	ldr	x7, [x0, #0x8]
    3714:      	cmp	x1, x7
    3718:      	b.ge	0x3790 <_stogir.checked.validate+0xc8>
    371c:      	ldr	x7, [x2, #0x8]
    3720:      	cmp	x1, x7
    3724:      	b.ge	0x38dc <_stogir.checked.validate+0x214>
    3728:      	ldr	x7, [x0, #0x78]
    372c:      	add	x7, x5, x7
    3730:      	ldr	w7, [x7]
    3734:      	sxtw	x7, w7
    3738:      	cmp	x7, #0x0
    373c:      	cset	w7, ge
    3740:      	ubfx	x7, x7, #0, #8
    3744:      	b	0x38e0 <_stogir.checked.validate+0x218>
    3748:      	cmp	x1, #0x0
    374c:      	b.ge	0x3798 <_stogir.checked.validate+0xd0>
    3750:      	ldr	x10, [x3, #0x8]
    3754:      	ldr	x11, [x4, #0x8]
    3758:      	cmp	x10, x11
    375c:      	b.ne	0x3788 <_stogir.checked.validate+0xc0>
    3760:      	cmp	x7, x10
    3764:      	b.gt	0x38e4 <_stogir.checked.validate+0x21c>
    3768:      	ldr	x7, [x0, #0x50]
    376c:      	add	x7, x7, x9, lsl #2
    3770:      	ldr	w7, [x7]
    3774:      	sxtw	x7, w7
    3778:      	cmp	x7, #0x0
    377c:      	cset	w7, gt
    3780:      	ubfx	x7, x7, #0, #8
    3784:      	b	0x38e8 <_stogir.checked.validate+0x220>
    3788:      	movz	x7, #0x0, lsl #48
    378c:      	b	0x379c <_stogir.checked.validate+0xd4>
    3790:      	movz	x7, #0x0, lsl #48
    3794:      	b	0x379c <_stogir.checked.validate+0xd4>
    3798:      	movz	x7, #0x0, lsl #48
    379c:      	cmp	x7, #0x0
    37a0:      	b.eq	0x37dc <_stogir.checked.validate+0x114>
    37a4:      	uxtb	w16, w6
    37a8:      	cmp	w16, wzr
    37ac:      	b.eq	0x37c4 <_stogir.checked.validate+0xfc>
    37b0:      	ldr	x6, [x0]
    37b4:      	add	x6, x6, x1, lsl #4
    37b8:      	ldr	x7, [x6]
    37bc:      	ldr	x6, [x6, #0x8]
    37c0:      	b	0x37d4 <_stogir.checked.validate+0x10c>
    37c4:      	ldr	x6, [x0, #0x28]
    37c8:      	add	x6, x6, x9, lsl #4
    37cc:      	ldr	x7, [x6]
    37d0:      	ldr	x6, [x6, #0x8]
    37d4:      	mov	w9, #0x1                ; =1
    37d8:      	b	0x37e8 <_stogir.checked.validate+0x120>
    37dc:      	movz	w9, #0x0, lsl #16
    37e0:      	movz	x7, #0x0, lsl #48
    37e4:      	movz	x6, #0x0, lsl #48
    37e8:      	ubfx	x9, x9, #0, #32
    37ec:      	lsr	x16, x9, #0
    37f0:      	cmp	x16, #0x1
    37f4:      	b.eq	0x3810 <_stogir.checked.validate+0x148>
    37f8:      	b.lo	0x3800 <_stogir.checked.validate+0x138>
    37fc:      	b	0x3814 <_stogir.checked.validate+0x14c>
    3800:      	cmp	x16, #0x0
    3804:      	b.eq	0x380c <_stogir.checked.validate+0x144>
    3808:      	b	0x3814 <_stogir.checked.validate+0x14c>
    380c:      	b	0x3818 <_stogir.checked.validate+0x150>
    3810:      	b	0x3860 <_stogir.checked.validate+0x198>
    3814:      	b	0x3af0 <_stogir.checked.validate+0x428>
    3818:      	mov	x0, #0x1                ; =1
    381c:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x40>
		000000000000381c:  ARM64_RELOC_PAGE21	l_stogir.365
    3820:      	ldr	x11, [x11]
		0000000000003820:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    3824:      	mov	x12, #0x1a              ; =26
    3828:      	b	0x383c <_stogir.checked.validate+0x174>
    382c:      	mov	x0, #0x1                ; =1
    3830:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003830:  ARM64_RELOC_PAGE21	l_stogir.366
    3834:      	ldr	x11, [x11]
		0000000000003834:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    3838:      	mov	x12, #0x26              ; =38
    383c:      	str	x0, [x8]
    3840:      	str	x11, [x8, #0x8]
    3844:      	str	x12, [x8, #0x10]
    3848:      	sub	sp, x29, #0x0
    384c:      	ldr	x19, [sp, #0x10]
    3850:      	ldr	x29, [sp]
    3854:      	ldr	x30, [sp, #0x8]
    3858:      	add	sp, sp, #0x20
    385c:      	ret
    3860:      	cmp	x1, #0x0
    3864:      	b.le	0x382c <_stogir.checked.validate+0x164>
    3868:      	uxtb	w1, w7
    386c:      	cmp	x1, #0x29
    3870:      	b.lt	0x382c <_stogir.checked.validate+0x164>
    3874:      	cmp	x1, #0x2b
    3878:      	b.gt	0x382c <_stogir.checked.validate+0x164>
    387c:      	ldr	x1, [x0, #0x78]
    3880:      	add	x1, x5, x1
    3884:      	ldr	w1, [x1]
    3888:      	sxtw	x1, w1
    388c:      	cmp	x1, #0x2
    3890:      	b.ne	0x382c <_stogir.checked.validate+0x164>
    3894:      	orr	w1, w7, wzr
    3898:      	mov	x5, sp
    389c:      	ubfx	x1, x1, #0, #32
    38a0:      	sub	sp, sp, #0x10
    38a4:      	mov	x9, sp
    38a8:      	sub	sp, sp, #0x10
    38ac:      	mov	x10, sp
    38b0:      	ubfx	x1, x1, #8, #8
    38b4:      	cmp	x1, #0x1
    38b8:      	b.lt	0x3ab4 <_stogir.checked.validate+0x3ec>
    38bc:      	cmp	x1, #0xb
    38c0:      	b.gt	0x3ab4 <_stogir.checked.validate+0x3ec>
    38c4:      	cmp	x1, #0x1
    38c8:      	b.eq	0x3ab4 <_stogir.checked.validate+0x3ec>
    38cc:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x40>
		00000000000038cc:  ARM64_RELOC_PAGE21	l_stogir.367
    38d0:      	ldr	x11, [x11]
		00000000000038d0:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    38d4:      	movz	x12, #0x0, lsl #48
    38d8:      	b	0x3ac0 <_stogir.checked.validate+0x3f8>
    38dc:      	movz	x7, #0x0, lsl #48
    38e0:      	b	0x3794 <_stogir.checked.validate+0xcc>
    38e4:      	movz	x7, #0x0, lsl #48
    38e8:      	b	0x378c <_stogir.checked.validate+0xc4>
    38ec:      	mov	x0, #0x1                ; =1
    38f0:      	mov	sp, x5
    38f4:      	b	0x383c <_stogir.checked.validate+0x174>
    38f8:      	movz	w9, #0x0, lsl #16
    38fc:      	movz	x7, #0x0, lsl #48
    3900:      	ubfx	x9, x9, #0, #32
    3904:      	lsr	x16, x9, #0
    3908:      	cmp	x16, #0x1
    390c:      	b.eq	0x3928 <_stogir.checked.validate+0x260>
    3910:      	b.lo	0x3918 <_stogir.checked.validate+0x250>
    3914:      	b	0x392c <_stogir.checked.validate+0x264>
    3918:      	cmp	x16, #0x0
    391c:      	b.eq	0x3924 <_stogir.checked.validate+0x25c>
    3920:      	b	0x392c <_stogir.checked.validate+0x264>
    3924:      	b	0x3930 <_stogir.checked.validate+0x268>
    3928:      	b	0x3a94 <_stogir.checked.validate+0x3cc>
    392c:      	b	0x3b08 <_stogir.checked.validate+0x440>
    3930:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003930:  ARM64_RELOC_PAGE21	l_stogir.368
    3934:      	ldr	x11, [x11]
		0000000000003934:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    3938:      	mov	x12, #0x22              ; =34
    393c:      	cmp	x6, #0x2
    3940:      	b.ge	0x3964 <_stogir.checked.validate+0x29c>
    3944:      	add	x7, x6, #0x1
    3948:      	add	x6, x13, x6, lsl #2
    394c:      	ldr	w6, [x6]
    3950:      	movn	w17, #0x0, lsl #16
    3954:      	and	w9, w6, w17
    3958:      	mov	x6, x7
    395c:      	mov	w7, #0x1                ; =1
    3960:      	b	0x396c <_stogir.checked.validate+0x2a4>
    3964:      	movz	w7, #0x0, lsl #16
    3968:      	movz	w9, #0x0, lsl #16
    396c:      	ubfx	x7, x7, #0, #32
    3970:      	lsr	x16, x7, #0
    3974:      	cmp	x16, #0x1
    3978:      	b.eq	0x3994 <_stogir.checked.validate+0x2cc>
    397c:      	b.lo	0x3984 <_stogir.checked.validate+0x2bc>
    3980:      	b	0x3998 <_stogir.checked.validate+0x2d0>
    3984:      	cmp	x16, #0x0
    3988:      	b.eq	0x3990 <_stogir.checked.validate+0x2c8>
    398c:      	b	0x3998 <_stogir.checked.validate+0x2d0>
    3990:      	b	0x39f8 <_stogir.checked.validate+0x330>
    3994:      	b	0x399c <_stogir.checked.validate+0x2d4>
    3998:      	b	0x3b00 <_stogir.checked.validate+0x438>
    399c:      	sxtw	x9, w9
    39a0:      	cmp	x9, #0x0
    39a4:      	cset	w7, gt
    39a8:      	movz	x16, #0x0, lsl #48
    39ac:      	sub	x10, x16, x9
    39b0:      	sub	x14, x10, #0x1
    39b4:      	uxtb	w16, w7
    39b8:      	cmp	w16, wzr
    39bc:      	b.eq	0x3a54 <_stogir.checked.validate+0x38c>
    39c0:      	ldr	x10, [x0, #0x8]
    39c4:      	cmp	x9, x10
    39c8:      	b.ge	0x3a4c <_stogir.checked.validate+0x384>
    39cc:      	ldr	x10, [x2, #0x8]
    39d0:      	cmp	x9, x10
    39d4:      	b.ge	0x3ae8 <_stogir.checked.validate+0x420>
    39d8:      	ldr	x10, [x0, #0x78]
    39dc:      	add	x10, x10, x9, lsl #2
    39e0:      	ldr	w10, [x10]
    39e4:      	sxtw	x10, w10
    39e8:      	cmp	x10, #0x0
    39ec:      	cset	w10, ge
    39f0:      	ubfx	x10, x10, #0, #8
    39f4:      	b	0x3aec <_stogir.checked.validate+0x424>
    39f8:      	cmp	x12, #0x0
    39fc:      	b.ne	0x38ec <_stogir.checked.validate+0x224>
    3a00:      	and	x11, x1, #0xffffffff
    3a04:      	movz	x0, #0x0, lsl #48
    3a08:      	movz	x12, #0x0, lsl #48
    3a0c:      	b	0x38f0 <_stogir.checked.validate+0x228>
    3a10:      	ldr	x7, [x0, #0x28]
    3a14:      	add	x7, x7, x14, lsl #4
    3a18:      	ldr	x7, [x7]
    3a1c:      	mov	w9, #0x1                ; =1
    3a20:      	b	0x3900 <_stogir.checked.validate+0x238>
    3a24:      	movz	x10, #0x0, lsl #48
    3a28:      	cmp	x10, #0x0
    3a2c:      	b.eq	0x38f8 <_stogir.checked.validate+0x230>
    3a30:      	uxtb	w16, w7
    3a34:      	cmp	w16, wzr
    3a38:      	b.eq	0x3a10 <_stogir.checked.validate+0x348>
    3a3c:      	ldr	x7, [x0]
    3a40:      	add	x7, x7, x9, lsl #4
    3a44:      	ldr	x7, [x7]
    3a48:      	b	0x3a1c <_stogir.checked.validate+0x354>
    3a4c:      	movz	x10, #0x0, lsl #48
    3a50:      	b	0x3a28 <_stogir.checked.validate+0x360>
    3a54:      	cmp	x9, #0x0
    3a58:      	b.ge	0x3a24 <_stogir.checked.validate+0x35c>
    3a5c:      	ldr	x15, [x3, #0x8]
    3a60:      	ldr	x19, [x4, #0x8]
    3a64:      	cmp	x15, x19
    3a68:      	b.ne	0x3ae0 <_stogir.checked.validate+0x418>
    3a6c:      	cmp	x10, x15
    3a70:      	b.gt	0x3af8 <_stogir.checked.validate+0x430>
    3a74:      	ldr	x10, [x0, #0x50]
    3a78:      	add	x10, x10, x14, lsl #2
    3a7c:      	ldr	w10, [x10]
    3a80:      	sxtw	x10, w10
    3a84:      	cmp	x10, #0x0
    3a88:      	cset	w10, gt
    3a8c:      	ubfx	x10, x10, #0, #8
    3a90:      	b	0x3afc <_stogir.checked.validate+0x434>
    3a94:      	ubfx	x7, x7, #0, #32
    3a98:      	ubfx	x7, x7, #8, #8
    3a9c:      	cmp	x7, x1
    3aa0:      	b.eq	0x3ab0 <_stogir.checked.validate+0x3e8>
    3aa4:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003aa4:  ARM64_RELOC_PAGE21	l_stogir.369
    3aa8:      	ldr	x11, [x11]
		0000000000003aa8:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    3aac:      	mov	x12, #0x28              ; =40
    3ab0:      	b	0x393c <_stogir.checked.validate+0x274>
    3ab4:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003ab4:  ARM64_RELOC_PAGE21	l_stogir.370
    3ab8:      	ldr	x11, [x11]
		0000000000003ab8:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    3abc:      	mov	x12, #0x36              ; =54
    3ac0:      	orr	x13, x10, xzr
    3ac4:      	lsr	x7, x7, #32
    3ac8:      	str	w7, [x9]
    3acc:      	str	w6, [x9, #0x4]
    3ad0:      	ldr	x6, [x9]
    3ad4:      	str	x6, [x10]
    3ad8:      	movz	x6, #0x0, lsl #48
    3adc:      	b	0x393c <_stogir.checked.validate+0x274>
    3ae0:      	movz	x10, #0x0, lsl #48
    3ae4:      	b	0x3a28 <_stogir.checked.validate+0x360>
    3ae8:      	movz	x10, #0x0, lsl #48
    3aec:      	b	0x3a50 <_stogir.checked.validate+0x388>
    3af0:      	brk	#0
    3af4:      	b	0x3af0 <_stogir.checked.validate+0x428>
    3af8:      	movz	x10, #0x0, lsl #48
    3afc:      	b	0x3ae4 <_stogir.checked.validate+0x41c>
    3b00:      	brk	#0
    3b04:      	b	0x3b00 <_stogir.checked.validate+0x438>
    3b08:      	brk	#0
    3b0c:      	b	0x3b08 <_stogir.checked.validate+0x440>

0000000000003b10 <_stogir.atomic.validate>:
    3b10:      	sub	sp, sp, #0x120
    3b14:      	str	x29, [sp, #0x10]
    3b18:      	str	x30, [sp, #0x18]
    3b1c:      	add	x29, sp, #0x10
    3b20:      	str	x19, [sp, #0xd0]
    3b24:      	str	x20, [sp, #0xd8]
    3b28:      	str	x21, [sp, #0xe0]
    3b2c:      	str	x22, [sp, #0xe8]
    3b30:      	str	x23, [sp, #0xf0]
    3b34:      	str	x24, [sp, #0xf8]
    3b38:      	str	x25, [sp, #0x100]
    3b3c:      	str	x26, [sp, #0x108]
    3b40:      	str	x27, [sp, #0x110]
    3b44:      	mov	x19, x8
    3b48:      	add	x8, sp, #0x20
    3b4c:      	mov	x20, x0
    3b50:      	mov	w21, w1
    3b54:      	bl	0x3b54 <_stogir.atomic.validate+0x44>
		0000000000003b54:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3b58:      	add	x16, sp, #0x20
    3b5c:      	ldr	w0, [x16]
    3b60:      	lsr	x16, x0, #0
    3b64:      	cmp	x16, #0x1
    3b68:      	b.eq	0x3b84 <_stogir.atomic.validate+0x74>
    3b6c:      	b.lo	0x3b74 <_stogir.atomic.validate+0x64>
    3b70:      	b	0x3b88 <_stogir.atomic.validate+0x78>
    3b74:      	cmp	x16, #0x0
    3b78:      	b.eq	0x3b80 <_stogir.atomic.validate+0x70>
    3b7c:      	b	0x3b88 <_stogir.atomic.validate+0x78>
    3b80:      	b	0x3b8c <_stogir.atomic.validate+0x7c>
    3b84:      	b	0x3bdc <_stogir.atomic.validate+0xcc>
    3b88:      	b	0x4274 <_stogir.atomic.validate+0x764>
    3b8c:      	mov	x0, #0x1                ; =1
    3b90:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003b90:  ARM64_RELOC_PAGE21	l_stogir.371
    3b94:      	ldr	x24, [x24]
		0000000000003b94:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    3b98:      	mov	x25, #0x1a              ; =26
    3b9c:      	str	x0, [x19]
    3ba0:      	str	x24, [x19, #0x8]
    3ba4:      	str	x25, [x19, #0x10]
    3ba8:      	ldr	x19, [sp, #0xd0]
    3bac:      	ldr	x20, [sp, #0xd8]
    3bb0:      	ldr	x21, [sp, #0xe0]
    3bb4:      	ldr	x22, [sp, #0xe8]
    3bb8:      	ldr	x23, [sp, #0xf0]
    3bbc:      	ldr	x24, [sp, #0xf8]
    3bc0:      	ldr	x25, [sp, #0x100]
    3bc4:      	ldr	x26, [sp, #0x108]
    3bc8:      	ldr	x27, [sp, #0x110]
    3bcc:      	ldr	x29, [sp, #0x10]
    3bd0:      	ldr	x30, [sp, #0x18]
    3bd4:      	add	sp, sp, #0x120
    3bd8:      	ret
    3bdc:      	sxtw	x0, w21
    3be0:      	add	x16, sp, #0x20
    3be4:      	orr	x1, x16, xzr
    3be8:      	add	x1, x1, #0x8
    3bec:      	add	x16, sp, #0x20
    3bf0:      	ldr	x22, [x16, #0x8]
    3bf4:      	add	x16, sp, #0x50
    3bf8:      	str	x22, [x16]
    3bfc:      	uxtb	w2, w22
    3c00:      	ldr	x1, [x1, #0x8]
    3c04:      	orr	x23, x2, xzr
    3c08:      	add	x16, sp, #0x50
    3c0c:      	str	x1, [x16, #0x8]
    3c10:      	cmp	x0, #0x0
    3c14:      	b.le	0x3c54 <_stogir.atomic.validate+0x144>
    3c18:      	cmp	x23, #0x7e
    3c1c:      	b.lt	0x3c54 <_stogir.atomic.validate+0x144>
    3c20:      	cmp	x23, #0x82
    3c24:      	b.gt	0x3c54 <_stogir.atomic.validate+0x144>
    3c28:      	ldr	x1, [x20, #0x78]
    3c2c:      	add	x0, x1, x0, lsl #2
    3c30:      	ldr	w0, [x0]
    3c34:      	cmp	x23, #0x83
    3c38:      	b.ge	0x4130 <_stogir.atomic.validate+0x620>
    3c3c:      	adrp	x17, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003c3c:  ARM64_RELOC_PAGE21	l_stogir.372
    3c40:      	ldr	x17, [x17]
		0000000000003c40:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    3c44:      	add	x1, x23, x17
    3c48:      	ldrsb	w1, [x1]
    3c4c:      	sxtb	w1, w1
    3c50:      	b	0x4134 <_stogir.atomic.validate+0x624>
    3c54:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003c54:  ARM64_RELOC_PAGE21	l_stogir.373
    3c58:      	ldr	x24, [x24]
		0000000000003c58:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    3c5c:      	mov	x25, #0x20              ; =32
    3c60:      	add	x16, sp, #0x50
    3c64:      	ldr	w0, [x16, #0x4]
    3c68:      	add	x8, sp, #0x60
    3c6c:      	mov	w1, w0
    3c70:      	mov	x0, x20
    3c74:      	bl	0x3c74 <_stogir.atomic.validate+0x164>
		0000000000003c74:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3c78:      	add	x16, sp, #0x60
    3c7c:      	ldr	w0, [x16]
    3c80:      	lsr	x16, x0, #0
    3c84:      	cmp	x16, #0x1
    3c88:      	b.eq	0x3ca4 <_stogir.atomic.validate+0x194>
    3c8c:      	b.lo	0x3c94 <_stogir.atomic.validate+0x184>
    3c90:      	b	0x3ca8 <_stogir.atomic.validate+0x198>
    3c94:      	cmp	x16, #0x0
    3c98:      	b.eq	0x3ca0 <_stogir.atomic.validate+0x190>
    3c9c:      	b	0x3ca8 <_stogir.atomic.validate+0x198>
    3ca0:      	b	0x3cac <_stogir.atomic.validate+0x19c>
    3ca4:      	b	0x3da8 <_stogir.atomic.validate+0x298>
    3ca8:      	b	0x427c <_stogir.atomic.validate+0x76c>
    3cac:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003cac:  ARM64_RELOC_PAGE21	l_stogir.374
    3cb0:      	ldr	x24, [x24]
		0000000000003cb0:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    3cb4:      	mov	x25, #0x16              ; =22
    3cb8:      	b	0x3cdc <_stogir.atomic.validate+0x1cc>
    3cbc:      	mov	x0, #0x1                ; =1
    3cc0:      	b	0x3b9c <_stogir.atomic.validate+0x8c>
    3cc4:      	mov	x0, #0x1                ; =1
    3cc8:      	cmp	x0, #0x0
    3ccc:      	b.eq	0x3cdc <_stogir.atomic.validate+0x1cc>
    3cd0:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003cd0:  ARM64_RELOC_PAGE21	l_stogir.375
    3cd4:      	ldr	x24, [x24]
		0000000000003cd4:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    3cd8:      	mov	x25, #0x16              ; =22
    3cdc:      	cmp	x23, #0x82
    3ce0:      	cset	w26, eq
    3ce4:      	ubfx	x22, x22, #0, #32
    3ce8:      	ubfx	x0, x22, #8, #8
    3cec:      	orr	x22, x0, xzr
    3cf0:      	cmp	x22, #0x0
    3cf4:      	cset	w0, eq
    3cf8:      	uxtb	w16, w26
    3cfc:      	cmp	w16, wzr
    3d00:      	b.eq	0x3d1c <_stogir.atomic.validate+0x20c>
    3d04:      	uxtb	w16, w0
    3d08:      	cmp	w16, wzr
    3d0c:      	b.ne	0x3d1c <_stogir.atomic.validate+0x20c>
    3d10:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003d10:  ARM64_RELOC_PAGE21	l_stogir.376
    3d14:      	ldr	x24, [x24]
		0000000000003d14:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    3d18:      	mov	x25, #0x19              ; =25
    3d1c:      	uxtb	w16, w26
    3d20:      	cmp	w16, wzr
    3d24:      	b.eq	0x3d30 <_stogir.atomic.validate+0x220>
    3d28:      	movz	x1, #0x0, lsl #48
    3d2c:      	b	0x3d34 <_stogir.atomic.validate+0x224>
    3d30:      	mov	x1, #0x1                ; =1
    3d34:      	cmp	x1, #0x0
    3d38:      	b.eq	0x3de4 <_stogir.atomic.validate+0x2d4>
    3d3c:      	add	x1, x20, #0x28
    3d40:      	add	x16, sp, #0x50
    3d44:      	ldr	w2, [x16, #0x8]
    3d48:      	sxtw	x2, w2
    3d4c:      	cmp	x2, #0x0
    3d50:      	cset	w3, gt
    3d54:      	movz	x16, #0x0, lsl #48
    3d58:      	sub	x4, x16, x2
    3d5c:      	sub	x5, x4, #0x1
    3d60:      	uxtb	w16, w3
    3d64:      	cmp	w16, wzr
    3d68:      	b.eq	0x3eb8 <_stogir.atomic.validate+0x3a8>
    3d6c:      	ldr	x1, [x20, #0x8]
    3d70:      	cmp	x2, x1
    3d74:      	b.ge	0x3fa8 <_stogir.atomic.validate+0x498>
    3d78:      	add	x1, x20, #0x78
    3d7c:      	ldr	x1, [x1, #0x8]
    3d80:      	cmp	x2, x1
    3d84:      	b.ge	0x40c0 <_stogir.atomic.validate+0x5b0>
    3d88:      	ldr	x1, [x20, #0x78]
    3d8c:      	add	x1, x1, x2, lsl #2
    3d90:      	ldr	w1, [x1]
    3d94:      	sxtw	x1, w1
    3d98:      	cmp	x1, #0x0
    3d9c:      	cset	w1, ge
    3da0:      	ubfx	x1, x1, #0, #8
    3da4:      	b	0x40c4 <_stogir.atomic.validate+0x5b4>
    3da8:      	add	x16, sp, #0x60
    3dac:      	ldr	x0, [x16, #0x8]
    3db0:      	add	x16, sp, #0x50
    3db4:      	ldr	w1, [x16, #0x4]
    3db8:      	sxtw	x1, w1
    3dbc:      	cmp	x1, #0x0
    3dc0:      	b.gt	0x3efc <_stogir.atomic.validate+0x3ec>
    3dc4:      	mov	x0, #0x1                ; =1
    3dc8:      	b	0x3cc8 <_stogir.atomic.validate+0x1b8>
    3dcc:      	movz	x0, #0x0, lsl #48
    3dd0:      	cmp	x0, #0x0
    3dd4:      	b.eq	0x3de4 <_stogir.atomic.validate+0x2d4>
    3dd8:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003dd8:  ARM64_RELOC_PAGE21	l_stogir.377
    3ddc:      	ldr	x24, [x24]
		0000000000003ddc:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    3de0:      	mov	x25, #0x22              ; =34
    3de4:      	cmp	x23, #0x80
    3de8:      	cset	w27, eq
    3dec:      	uxtb	w16, w27
    3df0:      	cmp	w16, wzr
    3df4:      	b.eq	0x3e00 <_stogir.atomic.validate+0x2f0>
    3df8:      	mov	x0, #0x1                ; =1
    3dfc:      	b	0x3e0c <_stogir.atomic.validate+0x2fc>
    3e00:      	cmp	x23, #0x81
    3e04:      	cset	w0, eq
    3e08:      	ubfx	x0, x0, #0, #8
    3e0c:      	cmp	x0, #0x0
    3e10:      	b.eq	0x3e84 <_stogir.atomic.validate+0x374>
    3e14:      	mov	x0, x20
    3e18:      	mov	w1, w21
    3e1c:      	mov	x2, #0x4                ; =4
    3e20:      	bl	0x3e20 <_stogir.atomic.validate+0x310>
		0000000000003e20:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    3e24:      	ubfx	x0, x0, #0, #32
    3e28:      	lsr	x16, x0, #0
    3e2c:      	cmp	x16, #0x1
    3e30:      	b.eq	0x3e4c <_stogir.atomic.validate+0x33c>
    3e34:      	b.lo	0x3e3c <_stogir.atomic.validate+0x32c>
    3e38:      	b	0x3e50 <_stogir.atomic.validate+0x340>
    3e3c:      	cmp	x16, #0x0
    3e40:      	b.eq	0x3e48 <_stogir.atomic.validate+0x338>
    3e44:      	b	0x3e50 <_stogir.atomic.validate+0x340>
    3e48:      	b	0x3e54 <_stogir.atomic.validate+0x344>
    3e4c:      	b	0x4098 <_stogir.atomic.validate+0x588>
    3e50:      	b	0x4294 <_stogir.atomic.validate+0x784>
    3e54:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003e54:  ARM64_RELOC_PAGE21	l_stogir.378
    3e58:      	ldr	x24, [x24]
		0000000000003e58:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    3e5c:      	mov	x25, #0x1d              ; =29
    3e60:      	b	0x3e84 <_stogir.atomic.validate+0x374>
    3e64:      	mov	x0, x20
    3e68:      	mov	w2, w22
    3e6c:      	bl	0x3e6c <_stogir.atomic.validate+0x35c>
		0000000000003e6c:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    3e70:      	cmp	x0, #0x0
    3e74:      	b.ne	0x3e84 <_stogir.atomic.validate+0x374>
    3e78:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003e78:  ARM64_RELOC_PAGE21	l_stogir.379
    3e7c:      	ldr	x24, [x24]
		0000000000003e7c:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    3e80:      	mov	x25, #0x24              ; =36
    3e84:      	cmp	x25, #0x0
    3e88:      	b.ne	0x3cbc <_stogir.atomic.validate+0x1ac>
    3e8c:      	uxtb	w16, w26
    3e90:      	cmp	w16, wzr
    3e94:      	b.eq	0x3f28 <_stogir.atomic.validate+0x418>
    3e98:      	movz	x0, #0x0, lsl #48
    3e9c:      	b	0x3ea8 <_stogir.atomic.validate+0x398>
    3ea0:      	mov	w0, #0x1                ; =1
    3ea4:      	sxtw	x0, w0
    3ea8:      	and	x24, x0, #0xffffffff
    3eac:      	movz	x0, #0x0, lsl #48
    3eb0:      	movz	x25, #0x0, lsl #48
    3eb4:      	b	0x3cc0 <_stogir.atomic.validate+0x1b0>
    3eb8:      	cmp	x2, #0x0
    3ebc:      	b.ge	0x3fb0 <_stogir.atomic.validate+0x4a0>
    3ec0:      	add	x6, x20, #0x50
    3ec4:      	ldr	x1, [x1, #0x8]
    3ec8:      	ldr	x6, [x6, #0x8]
    3ecc:      	cmp	x1, x6
    3ed0:      	b.ne	0x40b8 <_stogir.atomic.validate+0x5a8>
    3ed4:      	cmp	x4, x1
    3ed8:      	b.gt	0x426c <_stogir.atomic.validate+0x75c>
    3edc:      	ldr	x1, [x20, #0x50]
    3ee0:      	add	x1, x1, x5, lsl #2
    3ee4:      	ldr	w1, [x1]
    3ee8:      	sxtw	x1, w1
    3eec:      	cmp	x1, #0x0
    3ef0:      	cset	w1, gt
    3ef4:      	ubfx	x1, x1, #0, #8
    3ef8:      	b	0x4270 <_stogir.atomic.validate+0x760>
    3efc:      	uxtb	w0, w0
    3f00:      	cmp	x0, #0x83
    3f04:      	cset	w1, lt
    3f08:      	uxtb	w16, w1
    3f0c:      	cmp	w16, wzr
    3f10:      	b.eq	0x40f4 <_stogir.atomic.validate+0x5e4>
    3f14:      	adrp	x17, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003f14:  ARM64_RELOC_PAGE21	l_stogir.380
    3f18:      	ldr	x17, [x17]
		0000000000003f18:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    3f1c:      	add	x2, x0, x17
    3f20:      	ldrb	w2, [x2]
    3f24:      	b	0x40f8 <_stogir.atomic.validate+0x5e8>
    3f28:      	sxtw	x22, w22
    3f2c:      	cmp	x22, #0x0
    3f30:      	b.ne	0x41c8 <_stogir.atomic.validate+0x6b8>
    3f34:      	movz	w0, #0x0, lsl #16
    3f38:      	b	0x3ea4 <_stogir.atomic.validate+0x394>
    3f3c:      	mov	x0, #0x1                ; =1
    3f40:      	b	0x3dd0 <_stogir.atomic.validate+0x2c0>
    3f44:      	mov	x0, #0x1                ; =1
    3f48:      	cmp	x0, #0x0
    3f4c:      	b.eq	0x3dcc <_stogir.atomic.validate+0x2bc>
    3f50:      	orr	w0, w22, wzr
    3f54:      	add	x16, sp, #0x50
    3f58:      	ldr	w1, [x16, #0xc]
    3f5c:      	mov	w2, w0
    3f60:      	mov	x0, x20
    3f64:      	bl	0x3f64 <_stogir.atomic.validate+0x454>
		0000000000003f64:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    3f68:      	cmp	x0, #0x0
    3f6c:      	b.eq	0x3f3c <_stogir.atomic.validate+0x42c>
    3f70:      	movz	x0, #0x0, lsl #48
    3f74:      	b	0x3f40 <_stogir.atomic.validate+0x430>
    3f78:      	cmp	x22, #0x5
    3f7c:      	cset	w0, gt
    3f80:      	ubfx	x0, x0, #0, #8
    3f84:      	cmp	x0, #0x0
    3f88:      	b.eq	0x3f98 <_stogir.atomic.validate+0x488>
    3f8c:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x40>
		0000000000003f8c:  ARM64_RELOC_PAGE21	l_stogir.381
    3f90:      	ldr	x24, [x24]
		0000000000003f90:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    3f94:      	mov	x25, #0x25              ; =37
    3f98:      	cmp	x23, #0x7e
    3f9c:      	b.ne	0x3f44 <_stogir.atomic.validate+0x434>
    3fa0:      	movz	x0, #0x0, lsl #48
    3fa4:      	b	0x3f48 <_stogir.atomic.validate+0x438>
    3fa8:      	movz	x1, #0x0, lsl #48
    3fac:      	b	0x3fb4 <_stogir.atomic.validate+0x4a4>
    3fb0:      	movz	x1, #0x0, lsl #48
    3fb4:      	cmp	x1, #0x0
    3fb8:      	b.eq	0x3fec <_stogir.atomic.validate+0x4dc>
    3fbc:      	uxtb	w16, w3
    3fc0:      	cmp	w16, wzr
    3fc4:      	b.eq	0x3fd8 <_stogir.atomic.validate+0x4c8>
    3fc8:      	ldr	x1, [x20]
    3fcc:      	add	x1, x1, x2, lsl #4
    3fd0:      	ldr	x1, [x1]
    3fd4:      	b	0x3fe4 <_stogir.atomic.validate+0x4d4>
    3fd8:      	ldr	x1, [x20, #0x28]
    3fdc:      	add	x1, x1, x5, lsl #4
    3fe0:      	ldr	x1, [x1]
    3fe4:      	mov	w2, #0x1                ; =1
    3fe8:      	b	0x3ff4 <_stogir.atomic.validate+0x4e4>
    3fec:      	movz	w2, #0x0, lsl #16
    3ff0:      	movz	x1, #0x0, lsl #48
    3ff4:      	ubfx	x2, x2, #0, #32
    3ff8:      	lsr	x16, x2, #0
    3ffc:      	cmp	x16, #0x1
    4000:      	b.eq	0x401c <_stogir.atomic.validate+0x50c>
    4004:      	b.lo	0x400c <_stogir.atomic.validate+0x4fc>
    4008:      	b	0x4020 <_stogir.atomic.validate+0x510>
    400c:      	cmp	x16, #0x0
    4010:      	b.eq	0x4018 <_stogir.atomic.validate+0x508>
    4014:      	b	0x4020 <_stogir.atomic.validate+0x510>
    4018:      	b	0x404c <_stogir.atomic.validate+0x53c>
    401c:      	b	0x4024 <_stogir.atomic.validate+0x514>
    4020:      	b	0x428c <_stogir.atomic.validate+0x77c>
    4024:      	orr	w2, w1, wzr
    4028:      	ubfx	x2, x2, #0, #32
    402c:      	ubfx	x2, x2, #8, #8
    4030:      	cmp	x2, #0x6
    4034:      	b.ne	0x404c <_stogir.atomic.validate+0x53c>
    4038:      	uxtb	w1, w1
    403c:      	cmp	x1, #0x46
    4040:      	b.eq	0x404c <_stogir.atomic.validate+0x53c>
    4044:      	cmp	x1, #0x48
    4048:      	b.ne	0x4058 <_stogir.atomic.validate+0x548>
    404c:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4f0>
		000000000000404c:  ARM64_RELOC_PAGE21	l_stogir.382
    4050:      	ldr	x24, [x24]
		0000000000004050:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    4054:      	mov	x25, #0x1b              ; =27
    4058:      	cmp	x23, #0x7f
    405c:      	b.ne	0x4088 <_stogir.atomic.validate+0x578>
    4060:      	uxtb	w16, w0
    4064:      	cmp	w16, wzr
    4068:      	b.eq	0x4154 <_stogir.atomic.validate+0x644>
    406c:      	movz	x0, #0x0, lsl #48
    4070:      	b	0x4158 <_stogir.atomic.validate+0x648>
    4074:      	add	x16, sp, #0x90
    4078:      	ldr	x0, [x16, #0x8]
    407c:      	ubfx	x0, x0, #0, #32
    4080:      	ubfx	x0, x0, #8, #8
    4084:      	orr	x22, x0, xzr
    4088:      	cmp	x22, #0x2
    408c:      	b.ge	0x3f78 <_stogir.atomic.validate+0x468>
    4090:      	mov	x0, #0x1                ; =1
    4094:      	b	0x3f84 <_stogir.atomic.validate+0x474>
    4098:      	uxtb	w16, w27
    409c:      	cmp	w16, wzr
    40a0:      	b.eq	0x3e64 <_stogir.atomic.validate+0x354>
    40a4:      	sxtw	x1, w1
    40a8:      	cmp	x1, #0x0
    40ac:      	b.ge	0x4248 <_stogir.atomic.validate+0x738>
    40b0:      	mov	x0, #0x1                ; =1
    40b4:      	b	0x4254 <_stogir.atomic.validate+0x744>
    40b8:      	movz	x1, #0x0, lsl #48
    40bc:      	b	0x3fb4 <_stogir.atomic.validate+0x4a4>
    40c0:      	movz	x1, #0x0, lsl #48
    40c4:      	b	0x3fac <_stogir.atomic.validate+0x49c>
    40c8:      	movz	w0, #0x0, lsl #16
    40cc:      	uxtb	w16, w0
    40d0:      	and	w0, w16, #0x4
    40d4:      	uxtb	w0, w0
    40d8:      	ubfx	x0, x0, #0, #8
    40dc:      	cmp	x0, #0x0
    40e0:      	cset	w0, eq
    40e4:      	uxtb	w16, w0
    40e8:      	cmp	w16, wzr
    40ec:      	cset	x0, eq
    40f0:      	b	0x3cc8 <_stogir.atomic.validate+0x1b8>
    40f4:      	movz	w2, #0x0, lsl #16
    40f8:      	uxtb	w16, w2
    40fc:      	and	w2, w16, #0x1
    4100:      	uxtb	w2, w2
    4104:      	ubfx	x2, x2, #0, #8
    4108:      	cmp	x2, #0x0
    410c:      	b.eq	0x3cc4 <_stogir.atomic.validate+0x1b4>
    4110:      	uxtb	w16, w1
    4114:      	cmp	w16, wzr
    4118:      	b.eq	0x40c8 <_stogir.atomic.validate+0x5b8>
    411c:      	adrp	x17, 0x4000 <_stogir.atomic.validate+0x4f0>
		000000000000411c:  ARM64_RELOC_PAGE21	l_stogir.380
    4120:      	ldr	x17, [x17]
		0000000000004120:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    4124:      	add	x0, x0, x17
    4128:      	ldrb	w0, [x0]
    412c:      	b	0x40cc <_stogir.atomic.validate+0x5bc>
    4130:      	mov	w1, #-0x2               ; =-2
    4134:      	sxtw	x0, w0
    4138:      	sxtw	x1, w1
    413c:      	cmp	x0, x1
    4140:      	b.ne	0x3c54 <_stogir.atomic.validate+0x144>
    4144:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004144:  ARM64_RELOC_PAGE21	l_stogir.383
    4148:      	ldr	x24, [x24]
		0000000000004148:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    414c:      	movz	x25, #0x0, lsl #48
    4150:      	b	0x3c60 <_stogir.atomic.validate+0x150>
    4154:      	mov	x0, #0x1                ; =1
    4158:      	cmp	x0, #0x0
    415c:      	b.eq	0x416c <_stogir.atomic.validate+0x65c>
    4160:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004160:  ARM64_RELOC_PAGE21	l_stogir.384
    4164:      	ldr	x24, [x24]
		0000000000004164:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    4168:      	mov	x25, #0x19              ; =25
    416c:      	add	x16, sp, #0x50
    4170:      	ldr	w0, [x16, #0xc]
    4174:      	add	x8, sp, #0x90
    4178:      	mov	w1, w0
    417c:      	mov	x0, x20
    4180:      	bl	0x4180 <_stogir.atomic.validate+0x670>
		0000000000004180:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4184:      	add	x16, sp, #0x90
    4188:      	ldr	w0, [x16]
    418c:      	lsr	x16, x0, #0
    4190:      	cmp	x16, #0x1
    4194:      	b.eq	0x41b0 <_stogir.atomic.validate+0x6a0>
    4198:      	b.lo	0x41a0 <_stogir.atomic.validate+0x690>
    419c:      	b	0x41b4 <_stogir.atomic.validate+0x6a4>
    41a0:      	cmp	x16, #0x0
    41a4:      	b.eq	0x41ac <_stogir.atomic.validate+0x69c>
    41a8:      	b	0x41b4 <_stogir.atomic.validate+0x6a4>
    41ac:      	b	0x41b8 <_stogir.atomic.validate+0x6a8>
    41b0:      	b	0x4074 <_stogir.atomic.validate+0x564>
    41b4:      	b	0x429c <_stogir.atomic.validate+0x78c>
    41b8:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4f0>
		00000000000041b8:  ARM64_RELOC_PAGE21	l_stogir.385
    41bc:      	ldr	x24, [x24]
		00000000000041bc:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    41c0:      	mov	x25, #0x1a              ; =26
    41c4:      	b	0x4088 <_stogir.atomic.validate+0x578>
    41c8:      	cmp	x22, #0x1
    41cc:      	b.eq	0x3ea0 <_stogir.atomic.validate+0x390>
    41d0:      	cmp	x22, #0x2
    41d4:      	b.eq	0x3ea0 <_stogir.atomic.validate+0x390>
    41d8:      	cmp	x22, #0x7
    41dc:      	b.eq	0x3ea0 <_stogir.atomic.validate+0x390>
    41e0:      	cmp	x22, #0x8
    41e4:      	b.eq	0x3ea0 <_stogir.atomic.validate+0x390>
    41e8:      	cmp	x22, #0x3
    41ec:      	b.eq	0x4284 <_stogir.atomic.validate+0x774>
    41f0:      	cmp	x22, #0x9
    41f4:      	b.eq	0x4284 <_stogir.atomic.validate+0x774>
    41f8:      	cmp	x22, #0x4
    41fc:      	b.eq	0x42a4 <_stogir.atomic.validate+0x794>
    4200:      	cmp	x22, #0xa
    4204:      	b.eq	0x42a4 <_stogir.atomic.validate+0x794>
    4208:      	cmp	x22, #0xd
    420c:      	b.eq	0x42a4 <_stogir.atomic.validate+0x794>
    4210:      	cmp	x22, #0x5
    4214:      	b.eq	0x42ac <_stogir.atomic.validate+0x79c>
    4218:      	cmp	x22, #0xb
    421c:      	b.eq	0x42ac <_stogir.atomic.validate+0x79c>
    4220:      	cmp	x22, #0xc
    4224:      	b.eq	0x42ac <_stogir.atomic.validate+0x79c>
    4228:      	cmp	x22, #0x6
    422c:      	cset	w0, eq
    4230:      	uxtb	w16, w0
    4234:      	cmp	w16, wzr
    4238:      	mov	w16, #0x8               ; =8
    423c:      	movn	w17, #0x0, lsl #16
    4240:      	csel	w0, w16, w17, ne
    4244:      	b	0x42b0 <_stogir.atomic.validate+0x7a0>
    4248:      	cmp	x1, #0x9
    424c:      	cset	w0, gt
    4250:      	ubfx	x0, x0, #0, #8
    4254:      	cmp	x0, #0x0
    4258:      	b.eq	0x4268 <_stogir.atomic.validate+0x758>
    425c:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4f0>
		000000000000425c:  ARM64_RELOC_PAGE21	l_stogir.386
    4260:      	ldr	x24, [x24]
		0000000000004260:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    4264:      	mov	x25, #0x1c              ; =28
    4268:      	b	0x3e84 <_stogir.atomic.validate+0x374>
    426c:      	movz	x1, #0x0, lsl #48
    4270:      	b	0x40bc <_stogir.atomic.validate+0x5ac>
    4274:      	brk	#0
    4278:      	b	0x4274 <_stogir.atomic.validate+0x764>
    427c:      	brk	#0
    4280:      	b	0x427c <_stogir.atomic.validate+0x76c>
    4284:      	mov	w0, #0x2                ; =2
    4288:      	b	0x3ea4 <_stogir.atomic.validate+0x394>
    428c:      	brk	#0
    4290:      	b	0x428c <_stogir.atomic.validate+0x77c>
    4294:      	brk	#0
    4298:      	b	0x4294 <_stogir.atomic.validate+0x784>
    429c:      	brk	#0
    42a0:      	b	0x429c <_stogir.atomic.validate+0x78c>
    42a4:      	mov	w0, #0x4                ; =4
    42a8:      	b	0x4288 <_stogir.atomic.validate+0x778>
    42ac:      	mov	w0, #0x8                ; =8
    42b0:      	b	0x42a8 <_stogir.atomic.validate+0x798>

00000000000042b4 <_stogir.terminal.validate>:
    42b4:      	sub	sp, sp, #0x50
    42b8:      	str	x29, [sp]
    42bc:      	str	x30, [sp, #0x8]
    42c0:      	mov	x29, sp
    42c4:      	str	x19, [sp, #0x40]
    42c8:      	sxtw	x1, w1
    42cc:      	add	x2, x0, #0x78
    42d0:      	add	x3, x0, #0x28
    42d4:      	lsl	x4, x1, #2
    42d8:      	cmp	x1, #0x0
    42dc:      	cset	w5, gt
    42e0:      	movz	x16, #0x0, lsl #48
    42e4:      	sub	x6, x16, x1
    42e8:      	sub	x7, x6, #0x1
    42ec:      	uxtb	w16, w5
    42f0:      	cmp	w16, wzr
    42f4:      	b.eq	0x4330 <_stogir.terminal.validate+0x7c>
    42f8:      	ldr	x3, [x0, #0x8]
    42fc:      	cmp	x1, x3
    4300:      	b.ge	0x437c <_stogir.terminal.validate+0xc8>
    4304:      	ldr	x2, [x2, #0x8]
    4308:      	cmp	x1, x2
    430c:      	b.ge	0x4468 <_stogir.terminal.validate+0x1b4>
    4310:      	ldr	x2, [x0, #0x78]
    4314:      	add	x2, x4, x2
    4318:      	ldr	w2, [x2]
    431c:      	sxtw	x2, w2
    4320:      	cmp	x2, #0x0
    4324:      	cset	w2, ge
    4328:      	ubfx	x2, x2, #0, #8
    432c:      	b	0x446c <_stogir.terminal.validate+0x1b8>
    4330:      	cmp	x1, #0x0
    4334:      	b.ge	0x4384 <_stogir.terminal.validate+0xd0>
    4338:      	add	x2, x0, #0x50
    433c:      	ldr	x3, [x3, #0x8]
    4340:      	ldr	x2, [x2, #0x8]
    4344:      	cmp	x3, x2
    4348:      	b.ne	0x4374 <_stogir.terminal.validate+0xc0>
    434c:      	cmp	x6, x3
    4350:      	b.gt	0x44a8 <_stogir.terminal.validate+0x1f4>
    4354:      	ldr	x2, [x0, #0x50]
    4358:      	add	x2, x2, x7, lsl #2
    435c:      	ldr	w2, [x2]
    4360:      	sxtw	x2, w2
    4364:      	cmp	x2, #0x0
    4368:      	cset	w2, gt
    436c:      	ubfx	x2, x2, #0, #8
    4370:      	b	0x44ac <_stogir.terminal.validate+0x1f8>
    4374:      	movz	x2, #0x0, lsl #48
    4378:      	b	0x4388 <_stogir.terminal.validate+0xd4>
    437c:      	movz	x2, #0x0, lsl #48
    4380:      	b	0x4388 <_stogir.terminal.validate+0xd4>
    4384:      	movz	x2, #0x0, lsl #48
    4388:      	cmp	x2, #0x0
    438c:      	b.eq	0x43c8 <_stogir.terminal.validate+0x114>
    4390:      	uxtb	w16, w5
    4394:      	cmp	w16, wzr
    4398:      	b.eq	0x43b0 <_stogir.terminal.validate+0xfc>
    439c:      	ldr	x2, [x0]
    43a0:      	add	x2, x2, x1, lsl #4
    43a4:      	ldr	x3, [x2]
    43a8:      	ldr	x2, [x2, #0x8]
    43ac:      	b	0x43c0 <_stogir.terminal.validate+0x10c>
    43b0:      	ldr	x2, [x0, #0x28]
    43b4:      	add	x2, x2, x7, lsl #4
    43b8:      	ldr	x3, [x2]
    43bc:      	ldr	x2, [x2, #0x8]
    43c0:      	mov	w5, #0x1                ; =1
    43c4:      	b	0x43d4 <_stogir.terminal.validate+0x120>
    43c8:      	movz	w5, #0x0, lsl #16
    43cc:      	movz	x3, #0x0, lsl #48
    43d0:      	movz	x2, #0x0, lsl #48
    43d4:      	ubfx	x5, x5, #0, #32
    43d8:      	lsr	x16, x5, #0
    43dc:      	cmp	x16, #0x1
    43e0:      	b.eq	0x43fc <_stogir.terminal.validate+0x148>
    43e4:      	b.lo	0x43ec <_stogir.terminal.validate+0x138>
    43e8:      	b	0x4400 <_stogir.terminal.validate+0x14c>
    43ec:      	cmp	x16, #0x0
    43f0:      	b.eq	0x43f8 <_stogir.terminal.validate+0x144>
    43f4:      	b	0x4400 <_stogir.terminal.validate+0x14c>
    43f8:      	b	0x4404 <_stogir.terminal.validate+0x150>
    43fc:      	b	0x441c <_stogir.terminal.validate+0x168>
    4400:      	b	0x4574 <_stogir.terminal.validate+0x2c0>
    4404:      	mov	x19, x8
    4408:      	mov	x0, #0x1                ; =1
    440c:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		000000000000440c:  ARM64_RELOC_PAGE21	l_stogir.387
    4410:      	ldr	x1, [x1]
		0000000000004410:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    4414:      	mov	x2, #0x21               ; =33
    4418:      	b	0x4448 <_stogir.terminal.validate+0x194>
    441c:      	add	x16, sp, #0x10
    4420:      	str	x3, [x16]
    4424:      	add	x16, sp, #0x10
    4428:      	str	x2, [x16, #0x8]
    442c:      	cmp	x1, #0x0
    4430:      	b.gt	0x4470 <_stogir.terminal.validate+0x1bc>
    4434:      	mov	x19, x8
    4438:      	mov	x0, #0x1                ; =1
    443c:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		000000000000443c:  ARM64_RELOC_PAGE21	l_stogir.388
    4440:      	ldr	x1, [x1]
		0000000000004440:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    4444:      	mov	x2, #0x1b               ; =27
    4448:      	str	x0, [x19]
    444c:      	str	x1, [x19, #0x8]
    4450:      	str	x2, [x19, #0x10]
    4454:      	ldr	x19, [sp, #0x40]
    4458:      	ldr	x29, [sp]
    445c:      	ldr	x30, [sp, #0x8]
    4460:      	add	sp, sp, #0x50
    4464:      	ret
    4468:      	movz	x2, #0x0, lsl #48
    446c:      	b	0x4380 <_stogir.terminal.validate+0xcc>
    4470:      	uxtb	w3, w3
    4474:      	orr	x1, x3, xzr
    4478:      	cmp	x1, #0x60
    447c:      	cset	w2, eq
    4480:      	cmp	x1, #0x79
    4484:      	cset	w1, eq
    4488:      	uxtb	w16, w2
    448c:      	cmp	w16, wzr
    4490:      	b.ne	0x44b0 <_stogir.terminal.validate+0x1fc>
    4494:      	uxtb	w16, w1
    4498:      	cmp	w16, wzr
    449c:      	b.ne	0x44b0 <_stogir.terminal.validate+0x1fc>
    44a0:      	mov	x19, x8
    44a4:      	b	0x4438 <_stogir.terminal.validate+0x184>
    44a8:      	movz	x2, #0x0, lsl #48
    44ac:      	b	0x4378 <_stogir.terminal.validate+0xc4>
    44b0:      	add	x16, sp, #0x10
    44b4:      	ldr	w5, [x16]
    44b8:      	ubfx	x5, x5, #8, #8
    44bc:      	cmp	x5, #0x0
    44c0:      	b.ne	0x457c <_stogir.terminal.validate+0x2c8>
    44c4:      	uxtb	w16, w2
    44c8:      	cmp	w16, wzr
    44cc:      	mov	w16, #0x1               ; =1
    44d0:      	mov	w17, #0x3               ; =3
    44d4:      	csel	w2, w16, w17, ne
    44d8:      	ldr	x5, [x0, #0x78]
    44dc:      	sxtw	x2, w2
    44e0:      	add	x4, x4, x5
    44e4:      	ldr	w4, [x4]
    44e8:      	sxtw	x4, w4
    44ec:      	cmp	x4, x2
    44f0:      	b.ne	0x4584 <_stogir.terminal.validate+0x2d0>
    44f4:      	uxtb	w16, w1
    44f8:      	cmp	w16, wzr
    44fc:      	b.eq	0x4554 <_stogir.terminal.validate+0x2a0>
    4500:      	add	x16, sp, #0x10
    4504:      	ldr	w2, [x16, #0x8]
    4508:      	sxtw	x2, w2
    450c:      	cmp	x2, #0x0
    4510:      	b.eq	0x4554 <_stogir.terminal.validate+0x2a0>
    4514:      	mov	x19, x8
    4518:      	b	0x4438 <_stogir.terminal.validate+0x184>
    451c:      	movz	w1, #0x0, lsl #16
    4520:      	mov	x19, x8
    4524:      	add	x8, sp, #0x20
    4528:      	fmov	s31, w1
    452c:      	mov	w1, w3
    4530:      	fmov	w3, s31
    4534:      	bl	0x4534 <_stogir.terminal.validate+0x280>
		0000000000004534:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    4538:      	add	x16, sp, #0x20
    453c:      	ldr	x0, [x16]
    4540:      	add	x16, sp, #0x20
    4544:      	ldr	x1, [x16, #0x8]
    4548:      	add	x16, sp, #0x20
    454c:      	ldr	x2, [x16, #0x10]
    4550:      	b	0x4448 <_stogir.terminal.validate+0x194>
    4554:      	add	x16, sp, #0x10
    4558:      	ldr	w2, [x16, #0x4]
    455c:      	uxtb	w16, w1
    4560:      	cmp	w16, wzr
    4564:      	b.eq	0x451c <_stogir.terminal.validate+0x268>
    4568:      	add	x16, sp, #0x10
    456c:      	ldr	w1, [x16, #0xc]
    4570:      	b	0x4520 <_stogir.terminal.validate+0x26c>
    4574:      	brk	#0
    4578:      	b	0x4574 <_stogir.terminal.validate+0x2c0>
    457c:      	mov	x19, x8
    4580:      	b	0x4438 <_stogir.terminal.validate+0x184>
    4584:      	mov	x19, x8
    4588:      	b	0x4438 <_stogir.terminal.validate+0x184>

000000000000458c <_stogir.switch.validate>:
    458c:      	sub	sp, sp, #0x70
    4590:      	str	x29, [sp]
    4594:      	str	x30, [sp, #0x8]
    4598:      	mov	x29, sp
    459c:      	str	x19, [sp, #0x60]
    45a0:      	sxtw	x1, w1
    45a4:      	add	x2, x0, #0x78
    45a8:      	add	x3, x0, #0x28
    45ac:      	lsl	x4, x1, #2
    45b0:      	cmp	x1, #0x0
    45b4:      	cset	w5, gt
    45b8:      	movz	x16, #0x0, lsl #48
    45bc:      	sub	x6, x16, x1
    45c0:      	sub	x7, x6, #0x1
    45c4:      	uxtb	w16, w5
    45c8:      	cmp	w16, wzr
    45cc:      	b.eq	0x4608 <_stogir.switch.validate+0x7c>
    45d0:      	ldr	x3, [x0, #0x8]
    45d4:      	cmp	x1, x3
    45d8:      	b.ge	0x4654 <_stogir.switch.validate+0xc8>
    45dc:      	ldr	x2, [x2, #0x8]
    45e0:      	cmp	x1, x2
    45e4:      	b.ge	0x4740 <_stogir.switch.validate+0x1b4>
    45e8:      	ldr	x2, [x0, #0x78]
    45ec:      	add	x2, x4, x2
    45f0:      	ldr	w2, [x2]
    45f4:      	sxtw	x2, w2
    45f8:      	cmp	x2, #0x0
    45fc:      	cset	w2, ge
    4600:      	ubfx	x2, x2, #0, #8
    4604:      	b	0x4744 <_stogir.switch.validate+0x1b8>
    4608:      	cmp	x1, #0x0
    460c:      	b.ge	0x465c <_stogir.switch.validate+0xd0>
    4610:      	add	x2, x0, #0x50
    4614:      	ldr	x3, [x3, #0x8]
    4618:      	ldr	x2, [x2, #0x8]
    461c:      	cmp	x3, x2
    4620:      	b.ne	0x464c <_stogir.switch.validate+0xc0>
    4624:      	cmp	x6, x3
    4628:      	b.gt	0x477c <_stogir.switch.validate+0x1f0>
    462c:      	ldr	x2, [x0, #0x50]
    4630:      	add	x2, x2, x7, lsl #2
    4634:      	ldr	w2, [x2]
    4638:      	sxtw	x2, w2
    463c:      	cmp	x2, #0x0
    4640:      	cset	w2, gt
    4644:      	ubfx	x2, x2, #0, #8
    4648:      	b	0x4780 <_stogir.switch.validate+0x1f4>
    464c:      	movz	x2, #0x0, lsl #48
    4650:      	b	0x4660 <_stogir.switch.validate+0xd4>
    4654:      	movz	x2, #0x0, lsl #48
    4658:      	b	0x4660 <_stogir.switch.validate+0xd4>
    465c:      	movz	x2, #0x0, lsl #48
    4660:      	cmp	x2, #0x0
    4664:      	b.eq	0x46a0 <_stogir.switch.validate+0x114>
    4668:      	uxtb	w16, w5
    466c:      	cmp	w16, wzr
    4670:      	b.eq	0x4688 <_stogir.switch.validate+0xfc>
    4674:      	ldr	x2, [x0]
    4678:      	add	x2, x2, x1, lsl #4
    467c:      	ldr	x3, [x2]
    4680:      	ldr	x2, [x2, #0x8]
    4684:      	b	0x4698 <_stogir.switch.validate+0x10c>
    4688:      	ldr	x2, [x0, #0x28]
    468c:      	add	x2, x2, x7, lsl #4
    4690:      	ldr	x3, [x2]
    4694:      	ldr	x2, [x2, #0x8]
    4698:      	mov	w5, #0x1                ; =1
    469c:      	b	0x46ac <_stogir.switch.validate+0x120>
    46a0:      	movz	w5, #0x0, lsl #16
    46a4:      	movz	x3, #0x0, lsl #48
    46a8:      	movz	x2, #0x0, lsl #48
    46ac:      	ubfx	x5, x5, #0, #32
    46b0:      	lsr	x16, x5, #0
    46b4:      	cmp	x16, #0x1
    46b8:      	b.eq	0x46d4 <_stogir.switch.validate+0x148>
    46bc:      	b.lo	0x46c4 <_stogir.switch.validate+0x138>
    46c0:      	b	0x46d8 <_stogir.switch.validate+0x14c>
    46c4:      	cmp	x16, #0x0
    46c8:      	b.eq	0x46d0 <_stogir.switch.validate+0x144>
    46cc:      	b	0x46d8 <_stogir.switch.validate+0x14c>
    46d0:      	b	0x46dc <_stogir.switch.validate+0x150>
    46d4:      	b	0x46f4 <_stogir.switch.validate+0x168>
    46d8:      	b	0x4860 <_stogir.switch.validate+0x2d4>
    46dc:      	mov	x19, x8
    46e0:      	mov	x0, #0x1                ; =1
    46e4:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		00000000000046e4:  ARM64_RELOC_PAGE21	l_stogir.389
    46e8:      	ldr	x1, [x1]
		00000000000046e8:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    46ec:      	mov	x2, #0x1a               ; =26
    46f0:      	b	0x4720 <_stogir.switch.validate+0x194>
    46f4:      	add	x16, sp, #0x10
    46f8:      	str	x3, [x16]
    46fc:      	add	x16, sp, #0x10
    4700:      	str	x2, [x16, #0x8]
    4704:      	cmp	x1, #0x0
    4708:      	b.gt	0x4748 <_stogir.switch.validate+0x1bc>
    470c:      	mov	x19, x8
    4710:      	mov	x0, #0x1                ; =1
    4714:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004714:  ARM64_RELOC_PAGE21	l_stogir.390
    4718:      	ldr	x1, [x1]
		0000000000004718:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    471c:      	mov	x2, #0x20               ; =32
    4720:      	str	x0, [x19]
    4724:      	str	x1, [x19, #0x8]
    4728:      	str	x2, [x19, #0x10]
    472c:      	ldr	x19, [sp, #0x60]
    4730:      	ldr	x29, [sp]
    4734:      	ldr	x30, [sp, #0x8]
    4738:      	add	sp, sp, #0x70
    473c:      	ret
    4740:      	movz	x2, #0x0, lsl #48
    4744:      	b	0x4658 <_stogir.switch.validate+0xcc>
    4748:      	uxtb	w3, w3
    474c:      	orr	x1, x3, xzr
    4750:      	cmp	x1, #0x75
    4754:      	cset	w2, eq
    4758:      	uxtb	w16, w2
    475c:      	cmp	w16, wzr
    4760:      	b.ne	0x4784 <_stogir.switch.validate+0x1f8>
    4764:      	cmp	x1, #0x6d
    4768:      	b.lt	0x4868 <_stogir.switch.validate+0x2dc>
    476c:      	cmp	x1, #0x6f
    4770:      	b.le	0x4784 <_stogir.switch.validate+0x1f8>
    4774:      	mov	x19, x8
    4778:      	b	0x4710 <_stogir.switch.validate+0x184>
    477c:      	movz	x2, #0x0, lsl #48
    4780:      	b	0x4650 <_stogir.switch.validate+0xc4>
    4784:      	add	x16, sp, #0x10
    4788:      	ldr	w5, [x16]
    478c:      	ubfx	x5, x5, #8, #8
    4790:      	cmp	x5, #0x0
    4794:      	b.ne	0x4870 <_stogir.switch.validate+0x2e4>
    4798:      	ldr	x5, [x0, #0x78]
    479c:      	add	x4, x4, x5
    47a0:      	ldr	w4, [x4]
    47a4:      	cmp	x1, #0x6d
    47a8:      	b.eq	0x4808 <_stogir.switch.validate+0x27c>
    47ac:      	cmp	x1, #0x6e
    47b0:      	b.eq	0x4808 <_stogir.switch.validate+0x27c>
    47b4:      	mov	w1, #0x2                ; =2
    47b8:      	b	0x480c <_stogir.switch.validate+0x280>
    47bc:      	add	x16, sp, #0x10
    47c0:      	ldr	w1, [x16, #0x4]
    47c4:      	add	x16, sp, #0x10
    47c8:      	ldr	w2, [x16, #0x8]
    47cc:      	add	x16, sp, #0x10
    47d0:      	ldr	w4, [x16, #0xc]
    47d4:      	add	x8, sp, #0x40
    47d8:      	fmov	s31, w1
    47dc:      	mov	w1, w3
    47e0:      	mov	w3, w2
    47e4:      	fmov	w2, s31
    47e8:      	bl	0x47e8 <_stogir.switch.validate+0x25c>
		00000000000047e8:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    47ec:      	add	x16, sp, #0x40
    47f0:      	ldr	x0, [x16]
    47f4:      	add	x16, sp, #0x40
    47f8:      	ldr	x1, [x16, #0x8]
    47fc:      	add	x16, sp, #0x40
    4800:      	ldr	x2, [x16, #0x10]
    4804:      	b	0x4720 <_stogir.switch.validate+0x194>
    4808:      	mov	w1, #0x3                ; =3
    480c:      	sxtw	x4, w4
    4810:      	sxtw	x1, w1
    4814:      	cmp	x4, x1
    4818:      	b.ne	0x4878 <_stogir.switch.validate+0x2ec>
    481c:      	uxtb	w16, w2
    4820:      	cmp	w16, wzr
    4824:      	b.eq	0x4880 <_stogir.switch.validate+0x2f4>
    4828:      	add	x16, sp, #0x10
    482c:      	ldr	w1, [x16, #0x4]
    4830:      	add	x16, sp, #0x10
    4834:      	ldr	w2, [x16, #0x8]
    4838:      	mov	x19, x8
    483c:      	add	x8, sp, #0x20
    4840:      	bl	0x4840 <_stogir.switch.validate+0x2b4>
		0000000000004840:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    4844:      	add	x16, sp, #0x20
    4848:      	ldr	x0, [x16]
    484c:      	add	x16, sp, #0x20
    4850:      	ldr	x1, [x16, #0x8]
    4854:      	add	x16, sp, #0x20
    4858:      	ldr	x2, [x16, #0x10]
    485c:      	b	0x4804 <_stogir.switch.validate+0x278>
    4860:      	brk	#0
    4864:      	b	0x4860 <_stogir.switch.validate+0x2d4>
    4868:      	mov	x19, x8
    486c:      	b	0x4710 <_stogir.switch.validate+0x184>
    4870:      	mov	x19, x8
    4874:      	b	0x4710 <_stogir.switch.validate+0x184>
    4878:      	mov	x19, x8
    487c:      	b	0x4710 <_stogir.switch.validate+0x184>
    4880:      	mov	x19, x8
    4884:      	b	0x47bc <_stogir.switch.validate+0x230>

0000000000004888 <_stogir.stack.validate>:
    4888:      	sub	sp, sp, #0x90
    488c:      	str	x29, [sp]
    4890:      	str	x30, [sp, #0x8]
    4894:      	mov	x29, sp
    4898:      	str	x19, [sp, #0x60]
    489c:      	str	x20, [sp, #0x68]
    48a0:      	str	x21, [sp, #0x70]
    48a4:      	str	x22, [sp, #0x78]
    48a8:      	str	x23, [sp, #0x80]
    48ac:      	sxtw	x1, w1
    48b0:      	add	x2, x0, #0x78
    48b4:      	add	x3, x0, #0x28
    48b8:      	add	x4, x0, #0x50
    48bc:      	lsl	x5, x1, #2
    48c0:      	cmp	x1, #0x0
    48c4:      	cset	w6, gt
    48c8:      	movz	x16, #0x0, lsl #48
    48cc:      	sub	x7, x16, x1
    48d0:      	cmp	x1, #0x0
    48d4:      	cset	w9, lt
    48d8:      	sub	x10, x7, #0x1
    48dc:      	lsl	x11, x10, #2
    48e0:      	uxtb	w16, w6
    48e4:      	cmp	w16, wzr
    48e8:      	b.eq	0x4924 <_stogir.stack.validate+0x9c>
    48ec:      	ldr	x12, [x0, #0x8]
    48f0:      	cmp	x1, x12
    48f4:      	b.ge	0x4994 <_stogir.stack.validate+0x10c>
    48f8:      	ldr	x12, [x2, #0x8]
    48fc:      	cmp	x1, x12
    4900:      	b.ge	0x4ad4 <_stogir.stack.validate+0x24c>
    4904:      	ldr	x12, [x0, #0x78]
    4908:      	add	x12, x5, x12
    490c:      	ldr	w12, [x12]
    4910:      	sxtw	x12, w12
    4914:      	cmp	x12, #0x0
    4918:      	cset	w12, ge
    491c:      	ubfx	x12, x12, #0, #8
    4920:      	b	0x4ad8 <_stogir.stack.validate+0x250>
    4924:      	uxtb	w16, w9
    4928:      	cmp	w16, wzr
    492c:      	b.eq	0x499c <_stogir.stack.validate+0x114>
    4930:      	ldr	x12, [x3, #0x8]
    4934:      	ldr	x13, [x4, #0x8]
    4938:      	cmp	x12, x13
    493c:      	b.ne	0x4968 <_stogir.stack.validate+0xe0>
    4940:      	cmp	x7, x12
    4944:      	b.gt	0x4adc <_stogir.stack.validate+0x254>
    4948:      	ldr	x12, [x0, #0x50]
    494c:      	add	x12, x11, x12
    4950:      	ldr	w12, [x12]
    4954:      	sxtw	x12, w12
    4958:      	cmp	x12, #0x0
    495c:      	cset	w12, gt
    4960:      	ubfx	x12, x12, #0, #8
    4964:      	b	0x4ae0 <_stogir.stack.validate+0x258>
    4968:      	movz	x12, #0x0, lsl #48
    496c:      	b	0x49a0 <_stogir.stack.validate+0x118>
    4970:      	uxtb	w16, w15
    4974:      	cmp	w16, wzr
    4978:      	b.eq	0x4afc <_stogir.stack.validate+0x274>
    497c:      	mov	x22, x8
    4980:      	mov	x0, #0x1                ; =1
    4984:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004984:  ARM64_RELOC_PAGE21	l_stogir.391
    4988:      	ldr	x1, [x1]
		0000000000004988:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    498c:      	mov	x2, #0x19               ; =25
    4990:      	b	0x4a38 <_stogir.stack.validate+0x1b0>
    4994:      	movz	x12, #0x0, lsl #48
    4998:      	b	0x49a0 <_stogir.stack.validate+0x118>
    499c:      	movz	x12, #0x0, lsl #48
    49a0:      	lsl	x13, x1, #4
    49a4:      	lsl	x10, x10, #4
    49a8:      	cmp	x12, #0x0
    49ac:      	b.eq	0x49e8 <_stogir.stack.validate+0x160>
    49b0:      	uxtb	w16, w6
    49b4:      	cmp	w16, wzr
    49b8:      	b.eq	0x49d0 <_stogir.stack.validate+0x148>
    49bc:      	ldr	x12, [x0]
    49c0:      	add	x12, x13, x12
    49c4:      	ldr	x14, [x12]
    49c8:      	ldr	x12, [x12, #0x8]
    49cc:      	b	0x49e0 <_stogir.stack.validate+0x158>
    49d0:      	ldr	x12, [x0, #0x28]
    49d4:      	add	x12, x10, x12
    49d8:      	ldr	x14, [x12]
    49dc:      	ldr	x12, [x12, #0x8]
    49e0:      	mov	w15, #0x1               ; =1
    49e4:      	b	0x49f4 <_stogir.stack.validate+0x16c>
    49e8:      	movz	w15, #0x0, lsl #16
    49ec:      	movz	x14, #0x0, lsl #48
    49f0:      	movz	x12, #0x0, lsl #48
    49f4:      	ubfx	x15, x15, #0, #32
    49f8:      	lsr	x16, x15, #0
    49fc:      	cmp	x16, #0x1
    4a00:      	b.eq	0x4a1c <_stogir.stack.validate+0x194>
    4a04:      	b.lo	0x4a0c <_stogir.stack.validate+0x184>
    4a08:      	b	0x4a20 <_stogir.stack.validate+0x198>
    4a0c:      	cmp	x16, #0x0
    4a10:      	b.eq	0x4a18 <_stogir.stack.validate+0x190>
    4a14:      	b	0x4a20 <_stogir.stack.validate+0x198>
    4a18:      	b	0x4a24 <_stogir.stack.validate+0x19c>
    4a1c:      	b	0x4a68 <_stogir.stack.validate+0x1e0>
    4a20:      	b	0x4e14 <_stogir.stack.validate+0x58c>
    4a24:      	mov	x22, x8
    4a28:      	mov	x0, #0x1                ; =1
    4a2c:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004a2c:  ARM64_RELOC_PAGE21	l_stogir.392
    4a30:      	ldr	x1, [x1]
		0000000000004a30:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    4a34:      	mov	x2, #0x19               ; =25
    4a38:      	str	x0, [x22]
    4a3c:      	str	x1, [x22, #0x8]
    4a40:      	str	x2, [x22, #0x10]
    4a44:      	ldr	x19, [sp, #0x60]
    4a48:      	ldr	x20, [sp, #0x68]
    4a4c:      	ldr	x21, [sp, #0x70]
    4a50:      	ldr	x22, [sp, #0x78]
    4a54:      	ldr	x23, [sp, #0x80]
    4a58:      	ldr	x29, [sp]
    4a5c:      	ldr	x30, [sp, #0x8]
    4a60:      	add	sp, sp, #0x90
    4a64:      	ret
    4a68:      	cmp	x1, #0x0
    4a6c:      	cset	w15, le
    4a70:      	uxtb	w19, w14
    4a74:      	add	x16, sp, #0x10
    4a78:      	str	x14, [x16]
    4a7c:      	orr	x14, x19, xzr
    4a80:      	add	x16, sp, #0x10
    4a84:      	str	x12, [x16, #0x8]
    4a88:      	cmp	x14, #0x42
    4a8c:      	b.ne	0x4970 <_stogir.stack.validate+0xe8>
    4a90:      	uxtb	w16, w6
    4a94:      	cmp	w16, wzr
    4a98:      	b.eq	0x4b48 <_stogir.stack.validate+0x2c0>
    4a9c:      	ldr	x3, [x0, #0x8]
    4aa0:      	cmp	x1, x3
    4aa4:      	b.ge	0x4b8c <_stogir.stack.validate+0x304>
    4aa8:      	ldr	x2, [x2, #0x8]
    4aac:      	cmp	x1, x2
    4ab0:      	b.ge	0x4c74 <_stogir.stack.validate+0x3ec>
    4ab4:      	ldr	x1, [x0, #0x78]
    4ab8:      	add	x1, x5, x1
    4abc:      	ldr	w1, [x1]
    4ac0:      	sxtw	x1, w1
    4ac4:      	cmp	x1, #0x0
    4ac8:      	cset	w1, ge
    4acc:      	ubfx	x1, x1, #0, #8
    4ad0:      	b	0x4c78 <_stogir.stack.validate+0x3f0>
    4ad4:      	movz	x12, #0x0, lsl #48
    4ad8:      	b	0x4998 <_stogir.stack.validate+0x110>
    4adc:      	movz	x12, #0x0, lsl #48
    4ae0:      	b	0x496c <_stogir.stack.validate+0xe4>
    4ae4:      	mov	x0, #0x1                ; =1
    4ae8:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004ae8:  ARM64_RELOC_PAGE21	l_stogir.393
    4aec:      	ldr	x1, [x1]
		0000000000004aec:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    4af0:      	mov	x2, #0x1e               ; =30
    4af4:      	mov	x22, x8
    4af8:      	b	0x4990 <_stogir.stack.validate+0x108>
    4afc:      	cmp	x14, #0x51
    4b00:      	cset	w1, eq
    4b04:      	cmp	x14, #0x53
    4b08:      	cset	w20, eq
    4b0c:      	cmp	x14, #0x54
    4b10:      	cset	w21, eq
    4b14:      	uxtb	w16, w1
    4b18:      	cmp	w16, wzr
    4b1c:      	b.ne	0x4c7c <_stogir.stack.validate+0x3f4>
    4b20:      	cmp	x14, #0x52
    4b24:      	b.eq	0x4c7c <_stogir.stack.validate+0x3f4>
    4b28:      	uxtb	w16, w20
    4b2c:      	cmp	w16, wzr
    4b30:      	b.ne	0x4c7c <_stogir.stack.validate+0x3f4>
    4b34:      	uxtb	w16, w21
    4b38:      	cmp	w16, wzr
    4b3c:      	b.ne	0x4c7c <_stogir.stack.validate+0x3f4>
    4b40:      	mov	x22, x8
    4b44:      	b	0x4980 <_stogir.stack.validate+0xf8>
    4b48:      	uxtb	w16, w9
    4b4c:      	cmp	w16, wzr
    4b50:      	b.eq	0x4b94 <_stogir.stack.validate+0x30c>
    4b54:      	ldr	x1, [x3, #0x8]
    4b58:      	ldr	x2, [x4, #0x8]
    4b5c:      	cmp	x1, x2
    4b60:      	b.ne	0x4c6c <_stogir.stack.validate+0x3e4>
    4b64:      	cmp	x7, x1
    4b68:      	b.gt	0x4dbc <_stogir.stack.validate+0x534>
    4b6c:      	ldr	x1, [x0, #0x50]
    4b70:      	add	x1, x11, x1
    4b74:      	ldr	w1, [x1]
    4b78:      	sxtw	x1, w1
    4b7c:      	cmp	x1, #0x0
    4b80:      	cset	w1, gt
    4b84:      	ubfx	x1, x1, #0, #8
    4b88:      	b	0x4dc0 <_stogir.stack.validate+0x538>
    4b8c:      	movz	x1, #0x0, lsl #48
    4b90:      	b	0x4b98 <_stogir.stack.validate+0x310>
    4b94:      	movz	x1, #0x0, lsl #48
    4b98:      	cmp	x1, #0x0
    4b9c:      	b.eq	0x4bd0 <_stogir.stack.validate+0x348>
    4ba0:      	uxtb	w16, w6
    4ba4:      	cmp	w16, wzr
    4ba8:      	b.eq	0x4bbc <_stogir.stack.validate+0x334>
    4bac:      	ldr	x1, [x0]
    4bb0:      	add	x1, x13, x1
    4bb4:      	ldr	x1, [x1]
    4bb8:      	b	0x4bc8 <_stogir.stack.validate+0x340>
    4bbc:      	ldr	x1, [x0, #0x28]
    4bc0:      	add	x1, x10, x1
    4bc4:      	ldr	x1, [x1]
    4bc8:      	mov	w2, #0x1                ; =1
    4bcc:      	b	0x4bd8 <_stogir.stack.validate+0x350>
    4bd0:      	movz	w2, #0x0, lsl #16
    4bd4:      	movz	x1, #0x0, lsl #48
    4bd8:      	ubfx	x2, x2, #0, #32
    4bdc:      	lsr	x16, x2, #0
    4be0:      	cmp	x16, #0x1
    4be4:      	b.eq	0x4c00 <_stogir.stack.validate+0x378>
    4be8:      	b.lo	0x4bf0 <_stogir.stack.validate+0x368>
    4bec:      	b	0x4c04 <_stogir.stack.validate+0x37c>
    4bf0:      	cmp	x16, #0x0
    4bf4:      	b.eq	0x4bfc <_stogir.stack.validate+0x374>
    4bf8:      	b	0x4c04 <_stogir.stack.validate+0x37c>
    4bfc:      	b	0x4c08 <_stogir.stack.validate+0x380>
    4c00:      	b	0x4c1c <_stogir.stack.validate+0x394>
    4c04:      	b	0x4e1c <_stogir.stack.validate+0x594>
    4c08:      	mov	x0, #0x1                ; =1
    4c0c:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004c0c:  ARM64_RELOC_PAGE21	l_stogir.394
    4c10:      	ldr	x1, [x1]
		0000000000004c10:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    4c14:      	mov	x2, #0x21               ; =33
    4c18:      	b	0x4af4 <_stogir.stack.validate+0x26c>
    4c1c:      	uxtb	w16, w15
    4c20:      	cmp	w16, wzr
    4c24:      	b.ne	0x4ae4 <_stogir.stack.validate+0x25c>
    4c28:      	uxtb	w2, w1
    4c2c:      	cmp	x2, #0x42
    4c30:      	b.ne	0x4ae4 <_stogir.stack.validate+0x25c>
    4c34:      	ubfx	x1, x1, #0, #32
    4c38:      	ubfx	x1, x1, #8, #8
    4c3c:      	cmp	x1, #0x6
    4c40:      	b.ne	0x4ae4 <_stogir.stack.validate+0x25c>
    4c44:      	ldr	x0, [x0, #0x78]
    4c48:      	add	x0, x5, x0
    4c4c:      	ldr	w0, [x0]
    4c50:      	sxtw	x0, w0
    4c54:      	cmp	x0, #0x0
    4c58:      	b.ne	0x4ae4 <_stogir.stack.validate+0x25c>
    4c5c:      	movz	x0, #0x0, lsl #48
    4c60:      	mov	x1, #0x8                ; =8
    4c64:      	movz	x2, #0x0, lsl #48
    4c68:      	b	0x4af4 <_stogir.stack.validate+0x26c>
    4c6c:      	movz	x1, #0x0, lsl #48
    4c70:      	b	0x4b98 <_stogir.stack.validate+0x310>
    4c74:      	movz	x1, #0x0, lsl #48
    4c78:      	b	0x4b90 <_stogir.stack.validate+0x308>
    4c7c:      	ldr	x2, [x0, #0x78]
    4c80:      	add	x2, x5, x2
    4c84:      	ldr	w2, [x2]
    4c88:      	uxtb	w16, w1
    4c8c:      	cmp	w16, wzr
    4c90:      	b.eq	0x4cf0 <_stogir.stack.validate+0x468>
    4c94:      	mov	w1, #0x3                ; =3
    4c98:      	b	0x4d04 <_stogir.stack.validate+0x47c>
    4c9c:      	add	x16, sp, #0x10
    4ca0:      	ldr	w0, [x16]
    4ca4:      	add	x16, sp, #0x10
    4ca8:      	ldr	w1, [x16, #0x4]
    4cac:      	add	x16, sp, #0x10
    4cb0:      	ldr	w2, [x16, #0x8]
    4cb4:      	ubfx	x0, x0, #8, #8
    4cb8:      	add	x8, sp, #0x20
    4cbc:      	mov	w3, w1
    4cc0:      	mov	w1, w19
    4cc4:      	mov	w4, w2
    4cc8:      	mov	w2, w0
    4ccc:      	mov	x0, x23
    4cd0:      	bl	0x4cd0 <_stogir.stack.validate+0x448>
		0000000000004cd0:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    4cd4:      	add	x16, sp, #0x20
    4cd8:      	ldr	x0, [x16]
    4cdc:      	add	x16, sp, #0x20
    4ce0:      	ldr	x1, [x16, #0x8]
    4ce4:      	add	x16, sp, #0x20
    4ce8:      	ldr	x2, [x16, #0x10]
    4cec:      	b	0x4990 <_stogir.stack.validate+0x108>
    4cf0:      	uxtb	w16, w20
    4cf4:      	cmp	w16, wzr
    4cf8:      	mov	w16, #0x1               ; =1
    4cfc:      	mov	w17, #0x2               ; =2
    4d00:      	csel	w1, w16, w17, ne
    4d04:      	sxtw	x2, w2
    4d08:      	sxtw	x1, w1
    4d0c:      	cmp	x2, x1
    4d10:      	b.ne	0x4e24 <_stogir.stack.validate+0x59c>
    4d14:      	add	x16, sp, #0x10
    4d18:      	ldr	w1, [x16]
    4d1c:      	orr	x2, x1, xzr
    4d20:      	ubfx	x2, x2, #16, #16
    4d24:      	uxth	w16, w2
    4d28:      	and	w2, w16, #0x8000
    4d2c:      	uxth	w2, w2
    4d30:      	ubfx	x2, x2, #0, #16
    4d34:      	cmp	x2, #0x0
    4d38:      	b.ne	0x4dc4 <_stogir.stack.validate+0x53c>
    4d3c:      	mov	x22, x8
    4d40:      	mov	x23, x0
    4d44:      	uxtb	w16, w20
    4d48:      	cmp	w16, wzr
    4d4c:      	b.ne	0x4c9c <_stogir.stack.validate+0x414>
    4d50:      	uxtb	w16, w21
    4d54:      	cmp	w16, wzr
    4d58:      	b.ne	0x4c9c <_stogir.stack.validate+0x414>
    4d5c:      	add	x16, sp, #0x10
    4d60:      	ldr	w0, [x16]
    4d64:      	add	x16, sp, #0x10
    4d68:      	ldr	w1, [x16, #0x4]
    4d6c:      	add	x16, sp, #0x10
    4d70:      	ldr	w2, [x16, #0x8]
    4d74:      	ubfx	x0, x0, #8, #8
    4d78:      	add	x16, sp, #0x10
    4d7c:      	ldr	w3, [x16, #0xc]
    4d80:      	add	x8, sp, #0x40
    4d84:      	mov	w4, w2
    4d88:      	mov	w2, w0
    4d8c:      	mov	x0, x23
    4d90:      	mov	w5, w3
    4d94:      	mov	w3, w1
    4d98:      	mov	w1, w19
    4d9c:      	bl	0x4d9c <_stogir.stack.validate+0x514>
		0000000000004d9c:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    4da0:      	add	x16, sp, #0x40
    4da4:      	ldr	x0, [x16]
    4da8:      	add	x16, sp, #0x40
    4dac:      	ldr	x1, [x16, #0x8]
    4db0:      	add	x16, sp, #0x40
    4db4:      	ldr	x2, [x16, #0x10]
    4db8:      	b	0x4cec <_stogir.stack.validate+0x464>
    4dbc:      	movz	x1, #0x0, lsl #48
    4dc0:      	b	0x4c70 <_stogir.stack.validate+0x3e8>
    4dc4:      	uxtb	w2, w1
    4dc8:      	cmp	x2, #0x51
    4dcc:      	b.ne	0x4e2c <_stogir.stack.validate+0x5a4>
    4dd0:      	ubfx	x1, x1, #16, #16
    4dd4:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    4dd8:      	b.ne	0x4e34 <_stogir.stack.validate+0x5ac>
    4ddc:      	add	x16, sp, #0x10
    4de0:      	ldr	w1, [x16, #0x4]
    4de4:      	add	x16, sp, #0x10
    4de8:      	ldr	w2, [x16, #0x8]
    4dec:      	mov	x22, x8
    4df0:      	mov	x23, x0
    4df4:      	bl	0x4df4 <_stogir.stack.validate+0x56c>
		0000000000004df4:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    4df8:      	cmp	x0, #0x0
    4dfc:      	b.ne	0x4d44 <_stogir.stack.validate+0x4bc>
    4e00:      	mov	x0, #0x1                ; =1
    4e04:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004e04:  ARM64_RELOC_PAGE21	l_stogir.395
    4e08:      	ldr	x1, [x1]
		0000000000004e08:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    4e0c:      	mov	x2, #0x26               ; =38
    4e10:      	b	0x4cec <_stogir.stack.validate+0x464>
    4e14:      	brk	#0
    4e18:      	b	0x4e14 <_stogir.stack.validate+0x58c>
    4e1c:      	brk	#0
    4e20:      	b	0x4e1c <_stogir.stack.validate+0x594>
    4e24:      	mov	x22, x8
    4e28:      	b	0x4980 <_stogir.stack.validate+0xf8>
    4e2c:      	mov	x22, x8
    4e30:      	b	0x4e00 <_stogir.stack.validate+0x578>
    4e34:      	mov	x22, x8
    4e38:      	b	0x4e00 <_stogir.stack.validate+0x578>

0000000000004e3c <_stogir.locals.validate>:
    4e3c:      	sub	sp, sp, #0xc0
    4e40:      	str	x29, [sp]
    4e44:      	str	x30, [sp, #0x8]
    4e48:      	mov	x29, sp
    4e4c:      	str	x19, [sp, #0x70]
    4e50:      	str	x20, [sp, #0x78]
    4e54:      	str	x21, [sp, #0x80]
    4e58:      	str	x22, [sp, #0x88]
    4e5c:      	str	x23, [sp, #0x90]
    4e60:      	str	x24, [sp, #0x98]
    4e64:      	str	x25, [sp, #0xa0]
    4e68:      	str	x26, [sp, #0xa8]
    4e6c:      	str	x27, [sp, #0xb0]
    4e70:      	str	x28, [sp, #0xb8]
    4e74:      	sxtw	x1, w1
    4e78:      	add	x19, x0, #0x78
    4e7c:      	add	x20, x0, #0x28
    4e80:      	add	x21, x0, #0x50
    4e84:      	lsl	x3, x1, #2
    4e88:      	cmp	x1, #0x0
    4e8c:      	cset	w4, gt
    4e90:      	movz	x16, #0x0, lsl #48
    4e94:      	sub	x5, x16, x1
    4e98:      	sub	x6, x5, #0x1
    4e9c:      	uxtb	w16, w4
    4ea0:      	cmp	w16, wzr
    4ea4:      	b.eq	0x4ee0 <_stogir.locals.validate+0xa4>
    4ea8:      	ldr	x5, [x0, #0x8]
    4eac:      	cmp	x1, x5
    4eb0:      	b.ge	0x4f64 <_stogir.locals.validate+0x128>
    4eb4:      	ldr	x5, [x19, #0x8]
    4eb8:      	cmp	x1, x5
    4ebc:      	b.ge	0x5068 <_stogir.locals.validate+0x22c>
    4ec0:      	ldr	x5, [x0, #0x78]
    4ec4:      	add	x5, x3, x5
    4ec8:      	ldr	w5, [x5]
    4ecc:      	sxtw	x5, w5
    4ed0:      	cmp	x5, #0x0
    4ed4:      	cset	w5, ge
    4ed8:      	ubfx	x5, x5, #0, #8
    4edc:      	b	0x506c <_stogir.locals.validate+0x230>
    4ee0:      	cmp	x1, #0x0
    4ee4:      	b.ge	0x4f6c <_stogir.locals.validate+0x130>
    4ee8:      	ldr	x7, [x20, #0x8]
    4eec:      	ldr	x9, [x21, #0x8]
    4ef0:      	cmp	x7, x9
    4ef4:      	b.ne	0x4f20 <_stogir.locals.validate+0xe4>
    4ef8:      	cmp	x5, x7
    4efc:      	b.gt	0x50ec <_stogir.locals.validate+0x2b0>
    4f00:      	ldr	x5, [x0, #0x50]
    4f04:      	add	x5, x5, x6, lsl #2
    4f08:      	ldr	w5, [x5]
    4f0c:      	sxtw	x5, w5
    4f10:      	cmp	x5, #0x0
    4f14:      	cset	w5, gt
    4f18:      	ubfx	x5, x5, #0, #8
    4f1c:      	b	0x50f0 <_stogir.locals.validate+0x2b4>
    4f20:      	movz	x5, #0x0, lsl #48
    4f24:      	b	0x4f70 <_stogir.locals.validate+0x134>
    4f28:      	cmp	x4, #0x0
    4f2c:      	cset	w4, ne
    4f30:      	uxtb	w16, w4
    4f34:      	cmp	w16, wzr
    4f38:      	mov	w16, #0x2               ; =2
    4f3c:      	mov	w17, #0x3               ; =3
    4f40:      	csel	w4, w16, w17, ne
    4f44:      	cmp	x1, #0x0
    4f48:      	b.gt	0x5070 <_stogir.locals.validate+0x234>
    4f4c:      	mov	x26, x8
    4f50:      	mov	x2, #0x1                ; =1
    4f54:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004f54:  ARM64_RELOC_PAGE21	l_stogir.396
    4f58:      	ldr	x1, [x1]
		0000000000004f58:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    4f5c:      	mov	x0, #0x17               ; =23
    4f60:      	b	0x5000 <_stogir.locals.validate+0x1c4>
    4f64:      	movz	x5, #0x0, lsl #48
    4f68:      	b	0x4f70 <_stogir.locals.validate+0x134>
    4f6c:      	movz	x5, #0x0, lsl #48
    4f70:      	cmp	x5, #0x0
    4f74:      	b.eq	0x4fb0 <_stogir.locals.validate+0x174>
    4f78:      	uxtb	w16, w4
    4f7c:      	cmp	w16, wzr
    4f80:      	b.eq	0x4f98 <_stogir.locals.validate+0x15c>
    4f84:      	ldr	x4, [x0]
    4f88:      	add	x4, x4, x1, lsl #4
    4f8c:      	ldr	x5, [x4]
    4f90:      	ldr	x4, [x4, #0x8]
    4f94:      	b	0x4fa8 <_stogir.locals.validate+0x16c>
    4f98:      	ldr	x4, [x0, #0x28]
    4f9c:      	add	x4, x4, x6, lsl #4
    4fa0:      	ldr	x5, [x4]
    4fa4:      	ldr	x4, [x4, #0x8]
    4fa8:      	mov	w6, #0x1                ; =1
    4fac:      	b	0x4fbc <_stogir.locals.validate+0x180>
    4fb0:      	movz	w6, #0x0, lsl #16
    4fb4:      	movz	x5, #0x0, lsl #48
    4fb8:      	movz	x4, #0x0, lsl #48
    4fbc:      	ubfx	x6, x6, #0, #32
    4fc0:      	lsr	x16, x6, #0
    4fc4:      	cmp	x16, #0x1
    4fc8:      	b.eq	0x4fe4 <_stogir.locals.validate+0x1a8>
    4fcc:      	b.lo	0x4fd4 <_stogir.locals.validate+0x198>
    4fd0:      	b	0x4fe8 <_stogir.locals.validate+0x1ac>
    4fd4:      	cmp	x16, #0x0
    4fd8:      	b.eq	0x4fe0 <_stogir.locals.validate+0x1a4>
    4fdc:      	b	0x4fe8 <_stogir.locals.validate+0x1ac>
    4fe0:      	b	0x4fec <_stogir.locals.validate+0x1b0>
    4fe4:      	b	0x5044 <_stogir.locals.validate+0x208>
    4fe8:      	b	0x5214 <_stogir.locals.validate+0x3d8>
    4fec:      	mov	x26, x8
    4ff0:      	mov	x2, #0x1                ; =1
    4ff4:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4f0>
		0000000000004ff4:  ARM64_RELOC_PAGE21	l_stogir.397
    4ff8:      	ldr	x1, [x1]
		0000000000004ff8:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    4ffc:      	mov	x0, #0x17               ; =23
    5000:      	str	x2, [x26]
    5004:      	str	x1, [x26, #0x8]
    5008:      	str	x0, [x26, #0x10]
    500c:      	ldr	x19, [sp, #0x70]
    5010:      	ldr	x20, [sp, #0x78]
    5014:      	ldr	x21, [sp, #0x80]
    5018:      	ldr	x22, [sp, #0x88]
    501c:      	ldr	x23, [sp, #0x90]
    5020:      	ldr	x24, [sp, #0x98]
    5024:      	ldr	x25, [sp, #0xa0]
    5028:      	ldr	x26, [sp, #0xa8]
    502c:      	ldr	x27, [sp, #0xb0]
    5030:      	ldr	x28, [sp, #0xb8]
    5034:      	ldr	x29, [sp]
    5038:      	ldr	x30, [sp, #0x8]
    503c:      	add	sp, sp, #0xc0
    5040:      	ret
    5044:      	uxtb	w6, w5
    5048:      	add	x16, sp, #0x10
    504c:      	str	x5, [x16]
    5050:      	add	x16, sp, #0x10
    5054:      	str	x4, [x16, #0x8]
    5058:      	cmp	x6, #0x55
    505c:      	b.ne	0x50d0 <_stogir.locals.validate+0x294>
    5060:      	mov	x4, #0x1                ; =1
    5064:      	b	0x50dc <_stogir.locals.validate+0x2a0>
    5068:      	movz	x5, #0x0, lsl #48
    506c:      	b	0x4f68 <_stogir.locals.validate+0x12c>
    5070:      	cmp	x6, #0x48
    5074:      	cset	w24, eq
    5078:      	uxtb	w16, w23
    507c:      	cmp	w16, wzr
    5080:      	b.ne	0x50f4 <_stogir.locals.validate+0x2b8>
    5084:      	uxtb	w16, w24
    5088:      	cmp	w16, wzr
    508c:      	b.ne	0x50f4 <_stogir.locals.validate+0x2b8>
    5090:      	cmp	x6, #0x55
    5094:      	b.lt	0x554c <_stogir.locals.validate+0x710>
    5098:      	cmp	x6, #0x58
    509c:      	b.le	0x50f4 <_stogir.locals.validate+0x2b8>
    50a0:      	mov	x26, x8
    50a4:      	b	0x4f50 <_stogir.locals.validate+0x114>
    50a8:      	cmp	x6, #0x58
    50ac:      	cset	w5, eq
    50b0:      	ubfx	x22, x5, #0, #8
    50b4:      	cmp	x6, #0x41
    50b8:      	cset	w23, eq
    50bc:      	uxtb	w16, w23
    50c0:      	cmp	w16, wzr
    50c4:      	b.eq	0x4f28 <_stogir.locals.validate+0xec>
    50c8:      	mov	w4, #0x1                ; =1
    50cc:      	b	0x4f44 <_stogir.locals.validate+0x108>
    50d0:      	cmp	x6, #0x56
    50d4:      	cset	w4, eq
    50d8:      	ubfx	x4, x4, #0, #8
    50dc:      	cmp	x6, #0x57
    50e0:      	b.ne	0x50a8 <_stogir.locals.validate+0x26c>
    50e4:      	mov	x22, #0x1               ; =1
    50e8:      	b	0x50b4 <_stogir.locals.validate+0x278>
    50ec:      	movz	x5, #0x0, lsl #48
    50f0:      	b	0x4f24 <_stogir.locals.validate+0xe8>
    50f4:      	sxtw	x4, w4
    50f8:      	ldr	x5, [x0, #0x78]
    50fc:      	add	x3, x3, x5
    5100:      	ldr	w3, [x3]
    5104:      	sxtw	x3, w3
    5108:      	cmp	x3, x4
    510c:      	b.ne	0x5554 <_stogir.locals.validate+0x718>
    5110:      	uxtb	w16, w23
    5114:      	cmp	w16, wzr
    5118:      	b.ne	0x5138 <_stogir.locals.validate+0x2fc>
    511c:      	uxtb	w16, w24
    5120:      	cmp	w16, wzr
    5124:      	b.ne	0x5138 <_stogir.locals.validate+0x2fc>
    5128:      	add	x16, sp, #0x10
    512c:      	ldr	w1, [x16, #0x8]
    5130:      	sxtw	x1, w1
    5134:      	b	0x5150 <_stogir.locals.validate+0x314>
    5138:      	uxtb	w16, w24
    513c:      	cmp	w16, wzr
    5140:      	b.ne	0x5150 <_stogir.locals.validate+0x314>
    5144:      	add	x16, sp, #0x10
    5148:      	ldr	w1, [x16, #0x4]
    514c:      	sxtw	x1, w1
    5150:      	add	x16, sp, #0x20
    5154:      	orr	x25, x16, xzr
    5158:      	mov	x26, x8
    515c:      	add	x8, sp, #0x20
    5160:      	mov	x27, x0
    5164:      	mov	w28, w2
    5168:      	bl	0x5168 <_stogir.locals.validate+0x32c>
		0000000000005168:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    516c:      	add	x16, sp, #0x20
    5170:      	ldr	w0, [x16]
    5174:      	lsr	x16, x0, #0
    5178:      	cmp	x16, #0x1
    517c:      	b.eq	0x5198 <_stogir.locals.validate+0x35c>
    5180:      	b.lo	0x5188 <_stogir.locals.validate+0x34c>
    5184:      	b	0x519c <_stogir.locals.validate+0x360>
    5188:      	cmp	x16, #0x0
    518c:      	b.eq	0x5194 <_stogir.locals.validate+0x358>
    5190:      	b	0x519c <_stogir.locals.validate+0x360>
    5194:      	b	0x51b8 <_stogir.locals.validate+0x37c>
    5198:      	b	0x51a0 <_stogir.locals.validate+0x364>
    519c:      	b	0x53d0 <_stogir.locals.validate+0x594>
    51a0:      	add	x0, x25, #0x8
    51a4:      	add	x16, sp, #0x20
    51a8:      	ldr	x1, [x16, #0x8]
    51ac:      	ldr	x0, [x0, #0x8]
    51b0:      	mov	x2, #0x1                ; =1
    51b4:      	b	0x4f60 <_stogir.locals.validate+0x124>
    51b8:      	add	x16, sp, #0x20
    51bc:      	ldr	x25, [x16, #0x8]
    51c0:      	uxtb	w16, w24
    51c4:      	cmp	w16, wzr
    51c8:      	b.eq	0x51e0 <_stogir.locals.validate+0x3a4>
    51cc:      	sxtw	x25, w25
    51d0:      	and	x1, x25, #0xffffffff
    51d4:      	movz	x2, #0x0, lsl #48
    51d8:      	movz	x0, #0x0, lsl #48
    51dc:      	b	0x51b4 <_stogir.locals.validate+0x378>
    51e0:      	uxtb	w16, w23
    51e4:      	cmp	w16, wzr
    51e8:      	b.eq	0x5230 <_stogir.locals.validate+0x3f4>
    51ec:      	add	x16, sp, #0x10
    51f0:      	ldr	w0, [x16]
    51f4:      	ubfx	x0, x0, #8, #8
    51f8:      	cmp	x0, #0x6
    51fc:      	b.ne	0x521c <_stogir.locals.validate+0x3e0>
    5200:      	sxtw	x28, w28
    5204:      	and	x1, x28, #0xffffffff
    5208:      	movz	x2, #0x0, lsl #48
    520c:      	movz	x0, #0x0, lsl #48
    5210:      	b	0x522c <_stogir.locals.validate+0x3f0>
    5214:      	brk	#0
    5218:      	b	0x5214 <_stogir.locals.validate+0x3d8>
    521c:      	mov	x2, #0x1                ; =1
    5220:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005220:  ARM64_RELOC_PAGE21	l_stogir.398
    5224:      	ldr	x1, [x1]
		0000000000005224:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    5228:      	mov	x0, #0x21               ; =33
    522c:      	b	0x51dc <_stogir.locals.validate+0x3a0>
    5230:      	add	x16, sp, #0x10
    5234:      	ldr	w0, [x16, #0x4]
    5238:      	sxtw	x0, w0
    523c:      	cmp	x0, #0x0
    5240:      	cset	w1, gt
    5244:      	movz	x16, #0x0, lsl #48
    5248:      	sub	x2, x16, x0
    524c:      	sub	x3, x2, #0x1
    5250:      	uxtb	w16, w1
    5254:      	cmp	w16, wzr
    5258:      	b.eq	0x5324 <_stogir.locals.validate+0x4e8>
    525c:      	ldr	x2, [x27, #0x8]
    5260:      	cmp	x0, x2
    5264:      	b.ge	0x531c <_stogir.locals.validate+0x4e0>
    5268:      	ldr	x2, [x19, #0x8]
    526c:      	cmp	x0, x2
    5270:      	b.ge	0x53c0 <_stogir.locals.validate+0x584>
    5274:      	ldr	x2, [x27, #0x78]
    5278:      	add	x2, x2, x0, lsl #2
    527c:      	ldr	w2, [x2]
    5280:      	sxtw	x2, w2
    5284:      	cmp	x2, #0x0
    5288:      	cset	w2, ge
    528c:      	ubfx	x2, x2, #0, #8
    5290:      	b	0x53c4 <_stogir.locals.validate+0x588>
    5294:      	movz	w1, #0x0, lsl #16
    5298:      	movz	x0, #0x0, lsl #48
    529c:      	ubfx	x1, x1, #0, #32
    52a0:      	lsr	x16, x1, #0
    52a4:      	cmp	x16, #0x1
    52a8:      	b.eq	0x52c4 <_stogir.locals.validate+0x488>
    52ac:      	b.lo	0x52b4 <_stogir.locals.validate+0x478>
    52b0:      	b	0x52c8 <_stogir.locals.validate+0x48c>
    52b4:      	cmp	x16, #0x0
    52b8:      	b.eq	0x52c0 <_stogir.locals.validate+0x484>
    52bc:      	b	0x52c8 <_stogir.locals.validate+0x48c>
    52c0:      	b	0x52cc <_stogir.locals.validate+0x490>
    52c4:      	b	0x5364 <_stogir.locals.validate+0x528>
    52c8:      	b	0x5520 <_stogir.locals.validate+0x6e4>
    52cc:      	mov	x2, #0x1                ; =1
    52d0:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		00000000000052d0:  ARM64_RELOC_PAGE21	l_stogir.399
    52d4:      	ldr	x1, [x1]
		00000000000052d4:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    52d8:      	mov	x0, #0x1c               ; =28
    52dc:      	b	0x522c <_stogir.locals.validate+0x3f0>
    52e0:      	ldr	x0, [x27, #0x28]
    52e4:      	add	x0, x0, x3, lsl #4
    52e8:      	ldr	x0, [x0]
    52ec:      	mov	w1, #0x1                ; =1
    52f0:      	b	0x529c <_stogir.locals.validate+0x460>
    52f4:      	movz	x2, #0x0, lsl #48
    52f8:      	cmp	x2, #0x0
    52fc:      	b.eq	0x5294 <_stogir.locals.validate+0x458>
    5300:      	uxtb	w16, w1
    5304:      	cmp	w16, wzr
    5308:      	b.eq	0x52e0 <_stogir.locals.validate+0x4a4>
    530c:      	ldr	x1, [x27]
    5310:      	add	x0, x1, x0, lsl #4
    5314:      	ldr	x0, [x0]
    5318:      	b	0x52ec <_stogir.locals.validate+0x4b0>
    531c:      	movz	x2, #0x0, lsl #48
    5320:      	b	0x52f8 <_stogir.locals.validate+0x4bc>
    5324:      	cmp	x0, #0x0
    5328:      	b.ge	0x52f4 <_stogir.locals.validate+0x4b8>
    532c:      	ldr	x4, [x20, #0x8]
    5330:      	ldr	x5, [x21, #0x8]
    5334:      	cmp	x4, x5
    5338:      	b.ne	0x53b8 <_stogir.locals.validate+0x57c>
    533c:      	cmp	x2, x4
    5340:      	b.gt	0x53c8 <_stogir.locals.validate+0x58c>
    5344:      	ldr	x2, [x27, #0x50]
    5348:      	add	x2, x2, x3, lsl #2
    534c:      	ldr	w2, [x2]
    5350:      	sxtw	x2, w2
    5354:      	cmp	x2, #0x0
    5358:      	cset	w2, gt
    535c:      	ubfx	x2, x2, #0, #8
    5360:      	b	0x53cc <_stogir.locals.validate+0x590>
    5364:      	add	x16, sp, #0x10
    5368:      	ldr	w1, [x16, #0x4]
    536c:      	sxtw	x1, w1
    5370:      	cmp	x1, #0x0
    5374:      	b.le	0x53a4 <_stogir.locals.validate+0x568>
    5378:      	uxtb	w0, w0
    537c:      	cmp	x0, #0x83
    5380:      	cset	w1, lt
    5384:      	uxtb	w16, w1
    5388:      	cmp	w16, wzr
    538c:      	b.eq	0x53d8 <_stogir.locals.validate+0x59c>
    5390:      	adrp	x17, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005390:  ARM64_RELOC_PAGE21	l_stogir.400
    5394:      	ldr	x17, [x17]
		0000000000005394:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    5398:      	add	x2, x0, x17
    539c:      	ldrb	w2, [x2]
    53a0:      	b	0x53dc <_stogir.locals.validate+0x5a0>
    53a4:      	mov	x2, #0x1                ; =1
    53a8:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		00000000000053a8:  ARM64_RELOC_PAGE21	l_stogir.401
    53ac:      	ldr	x1, [x1]
		00000000000053ac:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    53b0:      	mov	x0, #0x1c               ; =28
    53b4:      	b	0x52dc <_stogir.locals.validate+0x4a0>
    53b8:      	movz	x2, #0x0, lsl #48
    53bc:      	b	0x52f8 <_stogir.locals.validate+0x4bc>
    53c0:      	movz	x2, #0x0, lsl #48
    53c4:      	b	0x5320 <_stogir.locals.validate+0x4e4>
    53c8:      	movz	x2, #0x0, lsl #48
    53cc:      	b	0x53bc <_stogir.locals.validate+0x580>
    53d0:      	brk	#0
    53d4:      	b	0x53d0 <_stogir.locals.validate+0x594>
    53d8:      	movz	w2, #0x0, lsl #16
    53dc:      	uxtb	w16, w2
    53e0:      	and	w2, w16, #0x1
    53e4:      	uxtb	w2, w2
    53e8:      	ubfx	x2, x2, #0, #8
    53ec:      	cmp	x2, #0x0
    53f0:      	b.eq	0x53a4 <_stogir.locals.validate+0x568>
    53f4:      	uxtb	w16, w1
    53f8:      	cmp	w16, wzr
    53fc:      	b.eq	0x5414 <_stogir.locals.validate+0x5d8>
    5400:      	adrp	x17, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005400:  ARM64_RELOC_PAGE21	l_stogir.400
    5404:      	ldr	x17, [x17]
		0000000000005404:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    5408:      	add	x0, x0, x17
    540c:      	ldrb	w0, [x0]
    5410:      	b	0x5418 <_stogir.locals.validate+0x5dc>
    5414:      	movz	w0, #0x0, lsl #16
    5418:      	uxtb	w16, w0
    541c:      	and	w0, w16, #0x4
    5420:      	uxtb	w0, w0
    5424:      	ubfx	x0, x0, #0, #8
    5428:      	cmp	x0, #0x0
    542c:      	cset	w0, eq
    5430:      	uxtb	w16, w0
    5434:      	cmp	w16, wzr
    5438:      	cset	x0, eq
    543c:      	cmp	x0, #0x0
    5440:      	b.ne	0x53a4 <_stogir.locals.validate+0x568>
    5444:      	cmp	x22, #0x0
    5448:      	b.eq	0x54d0 <_stogir.locals.validate+0x694>
    544c:      	add	x16, sp, #0x10
    5450:      	ldr	w0, [x16, #0xc]
    5454:      	add	x8, sp, #0x40
    5458:      	mov	w1, w0
    545c:      	mov	x0, x27
    5460:      	bl	0x5460 <_stogir.locals.validate+0x624>
		0000000000005460:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    5464:      	add	x16, sp, #0x40
    5468:      	ldr	x0, [x16]
    546c:      	add	x16, sp, #0x40
    5470:      	ldr	x19, [x16, #0x8]
    5474:      	b	0x54dc <_stogir.locals.validate+0x6a0>
    5478:      	orr	w0, w19, wzr
    547c:      	ubfx	x0, x0, #0, #32
    5480:      	ubfx	x0, x0, #8, #8
    5484:      	mov	w1, w28
    5488:      	bl	0x5488 <_stogir.locals.validate+0x64c>
		0000000000005488:  ARM64_RELOC_BRANCH26	_stogir.types.size
    548c:      	sxtw	x0, w0
    5490:      	cmp	x0, #0x0
    5494:      	b.le	0x54bc <_stogir.locals.validate+0x680>
    5498:      	cmp	x0, x25
    549c:      	b.gt	0x54bc <_stogir.locals.validate+0x680>
    54a0:      	cmp	x22, #0x0
    54a4:      	b.eq	0x5528 <_stogir.locals.validate+0x6ec>
    54a8:      	add	x16, sp, #0x10
    54ac:      	ldr	w1, [x16]
    54b0:      	ubfx	x1, x1, #8, #8
    54b4:      	cmp	x1, #0x0
    54b8:      	b.eq	0x5528 <_stogir.locals.validate+0x6ec>
    54bc:      	mov	x2, #0x1                ; =1
    54c0:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		00000000000054c0:  ARM64_RELOC_PAGE21	l_stogir.402
    54c4:      	ldr	x1, [x1]
		00000000000054c4:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    54c8:      	mov	x0, #0x23               ; =35
    54cc:      	b	0x53b4 <_stogir.locals.validate+0x578>
    54d0:      	add	x16, sp, #0x10
    54d4:      	ldr	x19, [x16]
    54d8:      	mov	x0, #0x1                ; =1
    54dc:      	ubfx	x0, x0, #0, #32
    54e0:      	lsr	x16, x0, #0
    54e4:      	cmp	x16, #0x1
    54e8:      	b.eq	0x5504 <_stogir.locals.validate+0x6c8>
    54ec:      	b.lo	0x54f4 <_stogir.locals.validate+0x6b8>
    54f0:      	b	0x5508 <_stogir.locals.validate+0x6cc>
    54f4:      	cmp	x16, #0x0
    54f8:      	b.eq	0x5500 <_stogir.locals.validate+0x6c4>
    54fc:      	b	0x5508 <_stogir.locals.validate+0x6cc>
    5500:      	b	0x550c <_stogir.locals.validate+0x6d0>
    5504:      	b	0x5478 <_stogir.locals.validate+0x63c>
    5508:      	b	0x5544 <_stogir.locals.validate+0x708>
    550c:      	mov	x2, #0x1                ; =1
    5510:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005510:  ARM64_RELOC_PAGE21	l_stogir.403
    5514:      	ldr	x1, [x1]
		0000000000005514:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    5518:      	mov	x0, #0x19               ; =25
    551c:      	b	0x54cc <_stogir.locals.validate+0x690>
    5520:      	brk	#0
    5524:      	b	0x5520 <_stogir.locals.validate+0x6e4>
    5528:      	uxtb	w19, w19
    552c:      	cmp	x19, #0x48
    5530:      	b.eq	0x54bc <_stogir.locals.validate+0x680>
    5534:      	and	x1, x0, #0xffffffff
    5538:      	movz	x2, #0x0, lsl #48
    553c:      	movz	x0, #0x0, lsl #48
    5540:      	b	0x54cc <_stogir.locals.validate+0x690>
    5544:      	brk	#0
    5548:      	b	0x5544 <_stogir.locals.validate+0x708>
    554c:      	mov	x26, x8
    5550:      	b	0x4f50 <_stogir.locals.validate+0x114>
    5554:      	mov	x26, x8
    5558:      	b	0x4f50 <_stogir.locals.validate+0x114>

000000000000555c <_stogir.conversion.validate>:
    555c:      	sub	sp, sp, #0x40
    5560:      	str	x29, [sp]
    5564:      	str	x30, [sp, #0x8]
    5568:      	mov	x29, sp
    556c:      	str	x19, [sp, #0x30]
    5570:      	sxtw	x1, w1
    5574:      	add	x3, x0, #0x78
    5578:      	add	x4, x0, #0x28
    557c:      	add	x5, x0, #0x50
    5580:      	lsl	x6, x1, #2
    5584:      	cmp	x1, #0x0
    5588:      	cset	w7, gt
    558c:      	movz	x16, #0x0, lsl #48
    5590:      	sub	x9, x16, x1
    5594:      	sub	x10, x9, #0x1
    5598:      	uxtb	w16, w7
    559c:      	cmp	w16, wzr
    55a0:      	b.eq	0x55dc <_stogir.conversion.validate+0x80>
    55a4:      	ldr	x9, [x0, #0x8]
    55a8:      	cmp	x1, x9
    55ac:      	b.ge	0x5624 <_stogir.conversion.validate+0xc8>
    55b0:      	ldr	x9, [x3, #0x8]
    55b4:      	cmp	x1, x9
    55b8:      	b.ge	0x56f4 <_stogir.conversion.validate+0x198>
    55bc:      	ldr	x9, [x0, #0x78]
    55c0:      	add	x9, x6, x9
    55c4:      	ldr	w9, [x9]
    55c8:      	sxtw	x9, w9
    55cc:      	cmp	x9, #0x0
    55d0:      	cset	w9, ge
    55d4:      	ubfx	x9, x9, #0, #8
    55d8:      	b	0x56f8 <_stogir.conversion.validate+0x19c>
    55dc:      	cmp	x1, #0x0
    55e0:      	b.ge	0x562c <_stogir.conversion.validate+0xd0>
    55e4:      	ldr	x11, [x4, #0x8]
    55e8:      	ldr	x12, [x5, #0x8]
    55ec:      	cmp	x11, x12
    55f0:      	b.ne	0x561c <_stogir.conversion.validate+0xc0>
    55f4:      	cmp	x9, x11
    55f8:      	b.gt	0x5784 <_stogir.conversion.validate+0x228>
    55fc:      	ldr	x9, [x0, #0x50]
    5600:      	add	x9, x9, x10, lsl #2
    5604:      	ldr	w9, [x9]
    5608:      	sxtw	x9, w9
    560c:      	cmp	x9, #0x0
    5610:      	cset	w9, gt
    5614:      	ubfx	x9, x9, #0, #8
    5618:      	b	0x5788 <_stogir.conversion.validate+0x22c>
    561c:      	movz	x9, #0x0, lsl #48
    5620:      	b	0x5630 <_stogir.conversion.validate+0xd4>
    5624:      	movz	x9, #0x0, lsl #48
    5628:      	b	0x5630 <_stogir.conversion.validate+0xd4>
    562c:      	movz	x9, #0x0, lsl #48
    5630:      	cmp	x9, #0x0
    5634:      	b.eq	0x5668 <_stogir.conversion.validate+0x10c>
    5638:      	uxtb	w16, w7
    563c:      	cmp	w16, wzr
    5640:      	b.eq	0x5654 <_stogir.conversion.validate+0xf8>
    5644:      	ldr	x7, [x0]
    5648:      	add	x7, x7, x1, lsl #4
    564c:      	ldr	x7, [x7]
    5650:      	b	0x5660 <_stogir.conversion.validate+0x104>
    5654:      	ldr	x7, [x0, #0x28]
    5658:      	add	x7, x7, x10, lsl #4
    565c:      	ldr	x7, [x7]
    5660:      	mov	w9, #0x1                ; =1
    5664:      	b	0x5670 <_stogir.conversion.validate+0x114>
    5668:      	movz	w9, #0x0, lsl #16
    566c:      	movz	x7, #0x0, lsl #48
    5670:      	ubfx	x9, x9, #0, #32
    5674:      	lsr	x16, x9, #0
    5678:      	cmp	x16, #0x1
    567c:      	b.eq	0x5698 <_stogir.conversion.validate+0x13c>
    5680:      	b.lo	0x5688 <_stogir.conversion.validate+0x12c>
    5684:      	b	0x569c <_stogir.conversion.validate+0x140>
    5688:      	cmp	x16, #0x0
    568c:      	b.eq	0x5694 <_stogir.conversion.validate+0x138>
    5690:      	b	0x569c <_stogir.conversion.validate+0x140>
    5694:      	b	0x56a0 <_stogir.conversion.validate+0x144>
    5698:      	b	0x56d4 <_stogir.conversion.validate+0x178>
    569c:      	b	0x57f0 <_stogir.conversion.validate+0x294>
    56a0:      	mov	x19, x8
    56a4:      	mov	x0, #0x1                ; =1
    56a8:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		00000000000056a8:  ARM64_RELOC_PAGE21	l_stogir.404
    56ac:      	ldr	x1, [x1]
		00000000000056ac:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    56b0:      	mov	x2, #0x12               ; =18
    56b4:      	str	x0, [x19]
    56b8:      	str	x1, [x19, #0x8]
    56bc:      	str	x2, [x19, #0x10]
    56c0:      	ldr	x19, [sp, #0x30]
    56c4:      	ldr	x29, [sp]
    56c8:      	ldr	x30, [sp, #0x8]
    56cc:      	add	sp, sp, #0x40
    56d0:      	ret
    56d4:      	cmp	x1, #0x0
    56d8:      	b.gt	0x56fc <_stogir.conversion.validate+0x1a0>
    56dc:      	mov	x19, x8
    56e0:      	mov	x0, #0x1                ; =1
    56e4:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		00000000000056e4:  ARM64_RELOC_PAGE21	l_stogir.405
    56e8:      	ldr	x1, [x1]
		00000000000056e8:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    56ec:      	mov	x2, #0x1e               ; =30
    56f0:      	b	0x56b4 <_stogir.conversion.validate+0x158>
    56f4:      	movz	x9, #0x0, lsl #48
    56f8:      	b	0x5628 <_stogir.conversion.validate+0xcc>
    56fc:      	uxtb	w1, w7
    5700:      	orr	x9, x1, xzr
    5704:      	cmp	x9, #0x21
    5708:      	b.lt	0x5904 <_stogir.conversion.validate+0x3a8>
    570c:      	cmp	x9, #0x27
    5710:      	b.gt	0x590c <_stogir.conversion.validate+0x3b0>
    5714:      	ldr	x9, [x0, #0x78]
    5718:      	add	x6, x6, x9
    571c:      	ldr	w6, [x6]
    5720:      	sxtw	x6, w6
    5724:      	cmp	x6, #0x1
    5728:      	b.ne	0x5914 <_stogir.conversion.validate+0x3b8>
    572c:      	asr	x6, x7, #32
    5730:      	cmp	x6, #0x0
    5734:      	cset	w10, gt
    5738:      	movz	x16, #0x0, lsl #48
    573c:      	sub	x11, x16, x6
    5740:      	sub	x12, x11, #0x1
    5744:      	uxtb	w16, w10
    5748:      	cmp	w16, wzr
    574c:      	b.eq	0x57b0 <_stogir.conversion.validate+0x254>
    5750:      	ldr	x4, [x0, #0x8]
    5754:      	cmp	x6, x4
    5758:      	b.ge	0x57f8 <_stogir.conversion.validate+0x29c>
    575c:      	ldr	x3, [x3, #0x8]
    5760:      	cmp	x6, x3
    5764:      	b.ge	0x5894 <_stogir.conversion.validate+0x338>
    5768:      	add	x3, x9, x6, lsl #2
    576c:      	ldr	w3, [x3]
    5770:      	sxtw	x3, w3
    5774:      	cmp	x3, #0x0
    5778:      	cset	w3, ge
    577c:      	ubfx	x3, x3, #0, #8
    5780:      	b	0x5898 <_stogir.conversion.validate+0x33c>
    5784:      	movz	x9, #0x0, lsl #48
    5788:      	b	0x5620 <_stogir.conversion.validate+0xc4>
    578c:      	uxtb	w3, w0
    5790:      	cmp	x3, #0x48
    5794:      	b.ne	0x589c <_stogir.conversion.validate+0x340>
    5798:      	mov	x19, x8
    579c:      	mov	x0, #0x1                ; =1
    57a0:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		00000000000057a0:  ARM64_RELOC_PAGE21	l_stogir.406
    57a4:      	ldr	x1, [x1]
		00000000000057a4:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    57a8:      	mov	x2, #0x25               ; =37
    57ac:      	b	0x56f0 <_stogir.conversion.validate+0x194>
    57b0:      	cmp	x6, #0x0
    57b4:      	b.ge	0x5800 <_stogir.conversion.validate+0x2a4>
    57b8:      	ldr	x3, [x4, #0x8]
    57bc:      	ldr	x4, [x5, #0x8]
    57c0:      	cmp	x3, x4
    57c4:      	b.ne	0x588c <_stogir.conversion.validate+0x330>
    57c8:      	cmp	x11, x3
    57cc:      	b.gt	0x58f4 <_stogir.conversion.validate+0x398>
    57d0:      	ldr	x3, [x0, #0x50]
    57d4:      	add	x3, x3, x12, lsl #2
    57d8:      	ldr	w3, [x3]
    57dc:      	sxtw	x3, w3
    57e0:      	cmp	x3, #0x0
    57e4:      	cset	w3, gt
    57e8:      	ubfx	x3, x3, #0, #8
    57ec:      	b	0x58f8 <_stogir.conversion.validate+0x39c>
    57f0:      	brk	#0
    57f4:      	b	0x57f0 <_stogir.conversion.validate+0x294>
    57f8:      	movz	x3, #0x0, lsl #48
    57fc:      	b	0x5804 <_stogir.conversion.validate+0x2a8>
    5800:      	movz	x3, #0x0, lsl #48
    5804:      	cmp	x3, #0x0
    5808:      	b.eq	0x583c <_stogir.conversion.validate+0x2e0>
    580c:      	uxtb	w16, w10
    5810:      	cmp	w16, wzr
    5814:      	b.eq	0x5828 <_stogir.conversion.validate+0x2cc>
    5818:      	ldr	x0, [x0]
    581c:      	add	x0, x0, x6, lsl #4
    5820:      	ldr	x0, [x0]
    5824:      	b	0x5834 <_stogir.conversion.validate+0x2d8>
    5828:      	ldr	x0, [x0, #0x28]
    582c:      	add	x0, x0, x12, lsl #4
    5830:      	ldr	x0, [x0]
    5834:      	mov	w3, #0x1                ; =1
    5838:      	b	0x5844 <_stogir.conversion.validate+0x2e8>
    583c:      	movz	w3, #0x0, lsl #16
    5840:      	movz	x0, #0x0, lsl #48
    5844:      	ubfx	x3, x3, #0, #32
    5848:      	lsr	x16, x3, #0
    584c:      	cmp	x16, #0x1
    5850:      	b.eq	0x586c <_stogir.conversion.validate+0x310>
    5854:      	b.lo	0x585c <_stogir.conversion.validate+0x300>
    5858:      	b	0x5870 <_stogir.conversion.validate+0x314>
    585c:      	cmp	x16, #0x0
    5860:      	b.eq	0x5868 <_stogir.conversion.validate+0x30c>
    5864:      	b	0x5870 <_stogir.conversion.validate+0x314>
    5868:      	b	0x5874 <_stogir.conversion.validate+0x318>
    586c:      	b	0x578c <_stogir.conversion.validate+0x230>
    5870:      	b	0x58fc <_stogir.conversion.validate+0x3a0>
    5874:      	mov	x19, x8
    5878:      	mov	x0, #0x1                ; =1
    587c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		000000000000587c:  ARM64_RELOC_PAGE21	l_stogir.407
    5880:      	ldr	x1, [x1]
		0000000000005880:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    5884:      	mov	x2, #0x19               ; =25
    5888:      	b	0x57ac <_stogir.conversion.validate+0x250>
    588c:      	movz	x3, #0x0, lsl #48
    5890:      	b	0x5804 <_stogir.conversion.validate+0x2a8>
    5894:      	movz	x3, #0x0, lsl #48
    5898:      	b	0x57fc <_stogir.conversion.validate+0x2a0>
    589c:      	cmp	x3, #0x46
    58a0:      	b.eq	0x591c <_stogir.conversion.validate+0x3c0>
    58a4:      	ubfx	x7, x7, #0, #32
    58a8:      	ubfx	x0, x0, #0, #32
    58ac:      	ubfx	x3, x7, #8, #8
    58b0:      	ubfx	x0, x0, #8, #8
    58b4:      	mov	x19, x8
    58b8:      	add	x8, sp, #0x10
    58bc:      	fmov	s31, w0
    58c0:      	mov	w0, w1
    58c4:      	fmov	w1, s31
    58c8:      	fmov	s31, w2
    58cc:      	mov	w2, w3
    58d0:      	fmov	w3, s31
    58d4:      	bl	0x58d4 <_stogir.conversion.validate+0x378>
		00000000000058d4:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    58d8:      	add	x16, sp, #0x10
    58dc:      	ldr	x0, [x16]
    58e0:      	add	x16, sp, #0x10
    58e4:      	ldr	x1, [x16, #0x8]
    58e8:      	add	x16, sp, #0x10
    58ec:      	ldr	x2, [x16, #0x10]
    58f0:      	b	0x57ac <_stogir.conversion.validate+0x250>
    58f4:      	movz	x3, #0x0, lsl #48
    58f8:      	b	0x5890 <_stogir.conversion.validate+0x334>
    58fc:      	brk	#0
    5900:      	b	0x58fc <_stogir.conversion.validate+0x3a0>
    5904:      	mov	x19, x8
    5908:      	b	0x56e0 <_stogir.conversion.validate+0x184>
    590c:      	mov	x19, x8
    5910:      	b	0x56e0 <_stogir.conversion.validate+0x184>
    5914:      	mov	x19, x8
    5918:      	b	0x56e0 <_stogir.conversion.validate+0x184>
    591c:      	mov	x19, x8
    5920:      	b	0x579c <_stogir.conversion.validate+0x240>

0000000000005924 <_stogir.conditional.validate>:
    5924:      	sub	sp, sp, #0x40
    5928:      	str	x29, [sp]
    592c:      	str	x30, [sp, #0x8]
    5930:      	mov	x29, sp
    5934:      	str	x19, [sp, #0x30]
    5938:      	sxtw	x1, w1
    593c:      	add	x2, x0, #0x78
    5940:      	add	x3, x0, #0x28
    5944:      	lsl	x4, x1, #2
    5948:      	cmp	x1, #0x0
    594c:      	cset	w5, gt
    5950:      	movz	x16, #0x0, lsl #48
    5954:      	sub	x6, x16, x1
    5958:      	sub	x7, x6, #0x1
    595c:      	uxtb	w16, w5
    5960:      	cmp	w16, wzr
    5964:      	b.eq	0x59a0 <_stogir.conditional.validate+0x7c>
    5968:      	ldr	x3, [x0, #0x8]
    596c:      	cmp	x1, x3
    5970:      	b.ge	0x59ec <_stogir.conditional.validate+0xc8>
    5974:      	ldr	x2, [x2, #0x8]
    5978:      	cmp	x1, x2
    597c:      	b.ge	0x5ac8 <_stogir.conditional.validate+0x1a4>
    5980:      	ldr	x2, [x0, #0x78]
    5984:      	add	x2, x4, x2
    5988:      	ldr	w2, [x2]
    598c:      	sxtw	x2, w2
    5990:      	cmp	x2, #0x0
    5994:      	cset	w2, ge
    5998:      	ubfx	x2, x2, #0, #8
    599c:      	b	0x5acc <_stogir.conditional.validate+0x1a8>
    59a0:      	cmp	x1, #0x0
    59a4:      	b.ge	0x59f4 <_stogir.conditional.validate+0xd0>
    59a8:      	add	x2, x0, #0x50
    59ac:      	ldr	x3, [x3, #0x8]
    59b0:      	ldr	x2, [x2, #0x8]
    59b4:      	cmp	x3, x2
    59b8:      	b.ne	0x59e4 <_stogir.conditional.validate+0xc0>
    59bc:      	cmp	x6, x3
    59c0:      	b.gt	0x5b48 <_stogir.conditional.validate+0x224>
    59c4:      	ldr	x2, [x0, #0x50]
    59c8:      	add	x2, x2, x7, lsl #2
    59cc:      	ldr	w2, [x2]
    59d0:      	sxtw	x2, w2
    59d4:      	cmp	x2, #0x0
    59d8:      	cset	w2, gt
    59dc:      	ubfx	x2, x2, #0, #8
    59e0:      	b	0x5b4c <_stogir.conditional.validate+0x228>
    59e4:      	movz	x2, #0x0, lsl #48
    59e8:      	b	0x59f8 <_stogir.conditional.validate+0xd4>
    59ec:      	movz	x2, #0x0, lsl #48
    59f0:      	b	0x59f8 <_stogir.conditional.validate+0xd4>
    59f4:      	movz	x2, #0x0, lsl #48
    59f8:      	cmp	x2, #0x0
    59fc:      	b.eq	0x5a38 <_stogir.conditional.validate+0x114>
    5a00:      	uxtb	w16, w5
    5a04:      	cmp	w16, wzr
    5a08:      	b.eq	0x5a20 <_stogir.conditional.validate+0xfc>
    5a0c:      	ldr	x2, [x0]
    5a10:      	add	x2, x2, x1, lsl #4
    5a14:      	ldr	x3, [x2]
    5a18:      	ldr	x2, [x2, #0x8]
    5a1c:      	b	0x5a30 <_stogir.conditional.validate+0x10c>
    5a20:      	ldr	x2, [x0, #0x28]
    5a24:      	add	x2, x2, x7, lsl #4
    5a28:      	ldr	x3, [x2]
    5a2c:      	ldr	x2, [x2, #0x8]
    5a30:      	mov	w5, #0x1                ; =1
    5a34:      	b	0x5a44 <_stogir.conditional.validate+0x120>
    5a38:      	movz	w5, #0x0, lsl #16
    5a3c:      	movz	x3, #0x0, lsl #48
    5a40:      	movz	x2, #0x0, lsl #48
    5a44:      	ubfx	x5, x5, #0, #32
    5a48:      	lsr	x16, x5, #0
    5a4c:      	cmp	x16, #0x1
    5a50:      	b.eq	0x5a6c <_stogir.conditional.validate+0x148>
    5a54:      	b.lo	0x5a5c <_stogir.conditional.validate+0x138>
    5a58:      	b	0x5a70 <_stogir.conditional.validate+0x14c>
    5a5c:      	cmp	x16, #0x0
    5a60:      	b.eq	0x5a68 <_stogir.conditional.validate+0x144>
    5a64:      	b	0x5a70 <_stogir.conditional.validate+0x14c>
    5a68:      	b	0x5a74 <_stogir.conditional.validate+0x150>
    5a6c:      	b	0x5a8c <_stogir.conditional.validate+0x168>
    5a70:      	b	0x5b50 <_stogir.conditional.validate+0x22c>
    5a74:      	mov	x19, x8
    5a78:      	mov	x0, #0x1                ; =1
    5a7c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005a7c:  ARM64_RELOC_PAGE21	l_stogir.408
    5a80:      	ldr	x1, [x1]
		0000000000005a80:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    5a84:      	mov	x2, #0x18               ; =24
    5a88:      	b	0x5aa8 <_stogir.conditional.validate+0x184>
    5a8c:      	cmp	x1, #0x0
    5a90:      	b.gt	0x5ad0 <_stogir.conditional.validate+0x1ac>
    5a94:      	mov	x19, x8
    5a98:      	mov	x0, #0x1                ; =1
    5a9c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005a9c:  ARM64_RELOC_PAGE21	l_stogir.409
    5aa0:      	ldr	x1, [x1]
		0000000000005aa0:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    5aa4:      	mov	x2, #0x18               ; =24
    5aa8:      	str	x0, [x19]
    5aac:      	str	x1, [x19, #0x8]
    5ab0:      	str	x2, [x19, #0x10]
    5ab4:      	ldr	x19, [sp, #0x30]
    5ab8:      	ldr	x29, [sp]
    5abc:      	ldr	x30, [sp, #0x8]
    5ac0:      	add	sp, sp, #0x40
    5ac4:      	ret
    5ac8:      	movz	x2, #0x0, lsl #48
    5acc:      	b	0x59f0 <_stogir.conditional.validate+0xcc>
    5ad0:      	uxtb	w1, w3
    5ad4:      	cmp	x1, #0x3c
    5ad8:      	b.ne	0x5b58 <_stogir.conditional.validate+0x234>
    5adc:      	ldr	x1, [x0, #0x78]
    5ae0:      	add	x1, x4, x1
    5ae4:      	ldr	w1, [x1]
    5ae8:      	sxtw	x1, w1
    5aec:      	cmp	x1, #0x3
    5af0:      	b.ne	0x5b60 <_stogir.conditional.validate+0x23c>
    5af4:      	orr	w1, w2, wzr
    5af8:      	orr	w4, w3, wzr
    5afc:      	lsr	x3, x3, #32
    5b00:      	lsr	x2, x2, #32
    5b04:      	ubfx	x4, x4, #0, #32
    5b08:      	ubfx	x4, x4, #8, #8
    5b0c:      	mov	x19, x8
    5b10:      	add	x8, sp, #0x10
    5b14:      	fmov	s31, w1
    5b18:      	mov	w1, w4
    5b1c:      	mov	w4, w2
    5b20:      	mov	w2, w3
    5b24:      	fmov	w3, s31
    5b28:      	bl	0x5b28 <_stogir.conditional.validate+0x204>
		0000000000005b28:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    5b2c:      	add	x16, sp, #0x10
    5b30:      	ldr	x0, [x16]
    5b34:      	add	x16, sp, #0x10
    5b38:      	ldr	x1, [x16, #0x8]
    5b3c:      	add	x16, sp, #0x10
    5b40:      	ldr	x2, [x16, #0x10]
    5b44:      	b	0x5aa8 <_stogir.conditional.validate+0x184>
    5b48:      	movz	x2, #0x0, lsl #48
    5b4c:      	b	0x59e8 <_stogir.conditional.validate+0xc4>
    5b50:      	brk	#0
    5b54:      	b	0x5b50 <_stogir.conditional.validate+0x22c>
    5b58:      	mov	x19, x8
    5b5c:      	b	0x5a98 <_stogir.conditional.validate+0x174>
    5b60:      	mov	x19, x8
    5b64:      	b	0x5a98 <_stogir.conditional.validate+0x174>

0000000000005b68 <_stogir.floating.validate>:
    5b68:      	sub	sp, sp, #0x50
    5b6c:      	str	x29, [sp]
    5b70:      	str	x30, [sp, #0x8]
    5b74:      	mov	x29, sp
    5b78:      	str	x19, [sp, #0x40]
    5b7c:      	sxtw	x1, w1
    5b80:      	add	x2, x0, #0x78
    5b84:      	add	x3, x0, #0x28
    5b88:      	add	x4, x0, #0x50
    5b8c:      	lsl	x5, x1, #2
    5b90:      	cmp	x1, #0x0
    5b94:      	cset	w6, gt
    5b98:      	movz	x16, #0x0, lsl #48
    5b9c:      	sub	x7, x16, x1
    5ba0:      	sub	x9, x7, #0x1
    5ba4:      	uxtb	w16, w6
    5ba8:      	cmp	w16, wzr
    5bac:      	b.eq	0x5be8 <_stogir.floating.validate+0x80>
    5bb0:      	ldr	x7, [x0, #0x8]
    5bb4:      	cmp	x1, x7
    5bb8:      	b.ge	0x5c30 <_stogir.floating.validate+0xc8>
    5bbc:      	ldr	x7, [x2, #0x8]
    5bc0:      	cmp	x1, x7
    5bc4:      	b.ge	0x5d1c <_stogir.floating.validate+0x1b4>
    5bc8:      	ldr	x7, [x0, #0x78]
    5bcc:      	add	x7, x5, x7
    5bd0:      	ldr	w7, [x7]
    5bd4:      	sxtw	x7, w7
    5bd8:      	cmp	x7, #0x0
    5bdc:      	cset	w7, ge
    5be0:      	ubfx	x7, x7, #0, #8
    5be4:      	b	0x5d20 <_stogir.floating.validate+0x1b8>
    5be8:      	cmp	x1, #0x0
    5bec:      	b.ge	0x5c38 <_stogir.floating.validate+0xd0>
    5bf0:      	ldr	x10, [x3, #0x8]
    5bf4:      	ldr	x11, [x4, #0x8]
    5bf8:      	cmp	x10, x11
    5bfc:      	b.ne	0x5c28 <_stogir.floating.validate+0xc0>
    5c00:      	cmp	x7, x10
    5c04:      	b.gt	0x5da8 <_stogir.floating.validate+0x240>
    5c08:      	ldr	x7, [x0, #0x50]
    5c0c:      	add	x7, x7, x9, lsl #2
    5c10:      	ldr	w7, [x7]
    5c14:      	sxtw	x7, w7
    5c18:      	cmp	x7, #0x0
    5c1c:      	cset	w7, gt
    5c20:      	ubfx	x7, x7, #0, #8
    5c24:      	b	0x5dac <_stogir.floating.validate+0x244>
    5c28:      	movz	x7, #0x0, lsl #48
    5c2c:      	b	0x5c3c <_stogir.floating.validate+0xd4>
    5c30:      	movz	x7, #0x0, lsl #48
    5c34:      	b	0x5c3c <_stogir.floating.validate+0xd4>
    5c38:      	movz	x7, #0x0, lsl #48
    5c3c:      	cmp	x7, #0x0
    5c40:      	b.eq	0x5c7c <_stogir.floating.validate+0x114>
    5c44:      	uxtb	w16, w6
    5c48:      	cmp	w16, wzr
    5c4c:      	b.eq	0x5c64 <_stogir.floating.validate+0xfc>
    5c50:      	ldr	x6, [x0]
    5c54:      	add	x6, x6, x1, lsl #4
    5c58:      	ldr	x7, [x6]
    5c5c:      	ldr	x6, [x6, #0x8]
    5c60:      	b	0x5c74 <_stogir.floating.validate+0x10c>
    5c64:      	ldr	x6, [x0, #0x28]
    5c68:      	add	x6, x6, x9, lsl #4
    5c6c:      	ldr	x7, [x6]
    5c70:      	ldr	x6, [x6, #0x8]
    5c74:      	mov	w9, #0x1                ; =1
    5c78:      	b	0x5c88 <_stogir.floating.validate+0x120>
    5c7c:      	movz	w9, #0x0, lsl #16
    5c80:      	movz	x7, #0x0, lsl #48
    5c84:      	movz	x6, #0x0, lsl #48
    5c88:      	ubfx	x9, x9, #0, #32
    5c8c:      	lsr	x16, x9, #0
    5c90:      	cmp	x16, #0x1
    5c94:      	b.eq	0x5cb0 <_stogir.floating.validate+0x148>
    5c98:      	b.lo	0x5ca0 <_stogir.floating.validate+0x138>
    5c9c:      	b	0x5cb4 <_stogir.floating.validate+0x14c>
    5ca0:      	cmp	x16, #0x0
    5ca4:      	b.eq	0x5cac <_stogir.floating.validate+0x144>
    5ca8:      	b	0x5cb4 <_stogir.floating.validate+0x14c>
    5cac:      	b	0x5cb8 <_stogir.floating.validate+0x150>
    5cb0:      	b	0x5cec <_stogir.floating.validate+0x184>
    5cb4:      	b	0x6008 <_stogir.floating.validate+0x4a0>
    5cb8:      	mov	x19, x8
    5cbc:      	mov	x0, #0x1                ; =1
    5cc0:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005cc0:  ARM64_RELOC_PAGE21	l_stogir.410
    5cc4:      	ldr	x1, [x1]
		0000000000005cc4:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    5cc8:      	mov	x2, #0x1c               ; =28
    5ccc:      	str	x0, [x19]
    5cd0:      	str	x1, [x19, #0x8]
    5cd4:      	str	x2, [x19, #0x10]
    5cd8:      	ldr	x19, [sp, #0x40]
    5cdc:      	ldr	x29, [sp]
    5ce0:      	ldr	x30, [sp, #0x8]
    5ce4:      	add	sp, sp, #0x50
    5ce8:      	ret
    5cec:      	add	x16, sp, #0x10
    5cf0:      	str	x7, [x16]
    5cf4:      	add	x16, sp, #0x10
    5cf8:      	str	x6, [x16, #0x8]
    5cfc:      	cmp	x1, #0x0
    5d00:      	b.gt	0x5d24 <_stogir.floating.validate+0x1bc>
    5d04:      	mov	x19, x8
    5d08:      	mov	x0, #0x1                ; =1
    5d0c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005d0c:  ARM64_RELOC_PAGE21	l_stogir.411
    5d10:      	ldr	x1, [x1]
		0000000000005d10:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    5d14:      	mov	x2, #0x1c               ; =28
    5d18:      	b	0x5ccc <_stogir.floating.validate+0x164>
    5d1c:      	movz	x7, #0x0, lsl #48
    5d20:      	b	0x5c34 <_stogir.floating.validate+0xcc>
    5d24:      	uxtb	w7, w7
    5d28:      	orr	x1, x7, xzr
    5d2c:      	cmp	x1, #0xe
    5d30:      	cset	w6, ge
    5d34:      	cmp	x1, #0x19
    5d38:      	cset	w9, le
    5d3c:      	cmp	x1, #0x1f
    5d40:      	cset	w10, eq
    5d44:      	cmp	x1, #0x20
    5d48:      	cset	w11, eq
    5d4c:      	uxtb	w16, w6
    5d50:      	cmp	w16, wzr
    5d54:      	b.eq	0x5db0 <_stogir.floating.validate+0x248>
    5d58:      	uxtb	w16, w9
    5d5c:      	cmp	w16, wzr
    5d60:      	b.eq	0x5db0 <_stogir.floating.validate+0x248>
    5d64:      	cmp	x1, #0x1d
    5d68:      	cset	w1, eq
    5d6c:      	ldr	x12, [x0, #0x78]
    5d70:      	add	x5, x5, x12
    5d74:      	ldr	w5, [x5]
    5d78:      	uxtb	w16, w10
    5d7c:      	cmp	w16, wzr
    5d80:      	b.ne	0x5df0 <_stogir.floating.validate+0x288>
    5d84:      	uxtb	w16, w11
    5d88:      	cmp	w16, wzr
    5d8c:      	b.ne	0x5df0 <_stogir.floating.validate+0x288>
    5d90:      	uxtb	w16, w1
    5d94:      	cmp	w16, wzr
    5d98:      	mov	w16, #0x3               ; =3
    5d9c:      	mov	w17, #0x2               ; =2
    5da0:      	csel	w10, w16, w17, ne
    5da4:      	b	0x5df4 <_stogir.floating.validate+0x28c>
    5da8:      	movz	x7, #0x0, lsl #48
    5dac:      	b	0x5c2c <_stogir.floating.validate+0xc4>
    5db0:      	uxtb	w16, w10
    5db4:      	cmp	w16, wzr
    5db8:      	b.ne	0x5d64 <_stogir.floating.validate+0x1fc>
    5dbc:      	uxtb	w16, w11
    5dc0:      	cmp	w16, wzr
    5dc4:      	b.ne	0x5d64 <_stogir.floating.validate+0x1fc>
    5dc8:      	cmp	x1, #0x1a
    5dcc:      	b.lt	0x5dd8 <_stogir.floating.validate+0x270>
    5dd0:      	cmp	x1, #0x1d
    5dd4:      	b.le	0x5d64 <_stogir.floating.validate+0x1fc>
    5dd8:      	cmp	x1, #0x3a
    5ddc:      	b.eq	0x5d64 <_stogir.floating.validate+0x1fc>
    5de0:      	cmp	x1, #0x3b
    5de4:      	b.eq	0x5d64 <_stogir.floating.validate+0x1fc>
    5de8:      	mov	x19, x8
    5dec:      	b	0x5d08 <_stogir.floating.validate+0x1a0>
    5df0:      	mov	w10, #0x1               ; =1
    5df4:      	sxtw	x5, w5
    5df8:      	sxtw	x10, w10
    5dfc:      	cmp	x5, x10
    5e00:      	b.ne	0x6018 <_stogir.floating.validate+0x4b0>
    5e04:      	add	x16, sp, #0x10
    5e08:      	ldr	w5, [x16, #0x4]
    5e0c:      	sxtw	x5, w5
    5e10:      	cmp	x5, #0x0
    5e14:      	cset	w10, gt
    5e18:      	movz	x16, #0x0, lsl #48
    5e1c:      	sub	x11, x16, x5
    5e20:      	sub	x12, x11, #0x1
    5e24:      	uxtb	w16, w10
    5e28:      	cmp	w16, wzr
    5e2c:      	b.eq	0x5e7c <_stogir.floating.validate+0x314>
    5e30:      	ldr	x3, [x0, #0x8]
    5e34:      	cmp	x5, x3
    5e38:      	b.ge	0x5ebc <_stogir.floating.validate+0x354>
    5e3c:      	ldr	x2, [x2, #0x8]
    5e40:      	cmp	x5, x2
    5e44:      	b.ge	0x5f88 <_stogir.floating.validate+0x420>
    5e48:      	ldr	x2, [x0, #0x78]
    5e4c:      	add	x2, x2, x5, lsl #2
    5e50:      	ldr	w2, [x2]
    5e54:      	sxtw	x2, w2
    5e58:      	cmp	x2, #0x0
    5e5c:      	cset	w2, ge
    5e60:      	ubfx	x2, x2, #0, #8
    5e64:      	b	0x5f8c <_stogir.floating.validate+0x424>
    5e68:      	mov	x0, #0x1                ; =1
    5e6c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005e6c:  ARM64_RELOC_PAGE21	l_stogir.412
    5e70:      	ldr	x1, [x1]
		0000000000005e70:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    5e74:      	mov	x2, #0x1d               ; =29
    5e78:      	b	0x5d18 <_stogir.floating.validate+0x1b0>
    5e7c:      	cmp	x5, #0x0
    5e80:      	b.ge	0x5ec4 <_stogir.floating.validate+0x35c>
    5e84:      	ldr	x2, [x3, #0x8]
    5e88:      	ldr	x3, [x4, #0x8]
    5e8c:      	cmp	x2, x3
    5e90:      	b.ne	0x5f80 <_stogir.floating.validate+0x418>
    5e94:      	cmp	x11, x2
    5e98:      	b.gt	0x6000 <_stogir.floating.validate+0x498>
    5e9c:      	ldr	x2, [x0, #0x50]
    5ea0:      	add	x2, x2, x12, lsl #2
    5ea4:      	ldr	w2, [x2]
    5ea8:      	sxtw	x2, w2
    5eac:      	cmp	x2, #0x0
    5eb0:      	cset	w2, gt
    5eb4:      	ubfx	x2, x2, #0, #8
    5eb8:      	b	0x6004 <_stogir.floating.validate+0x49c>
    5ebc:      	movz	x2, #0x0, lsl #48
    5ec0:      	b	0x5ec8 <_stogir.floating.validate+0x360>
    5ec4:      	movz	x2, #0x0, lsl #48
    5ec8:      	cmp	x2, #0x0
    5ecc:      	b.eq	0x5f00 <_stogir.floating.validate+0x398>
    5ed0:      	uxtb	w16, w10
    5ed4:      	cmp	w16, wzr
    5ed8:      	b.eq	0x5eec <_stogir.floating.validate+0x384>
    5edc:      	ldr	x2, [x0]
    5ee0:      	add	x2, x2, x5, lsl #4
    5ee4:      	ldr	x2, [x2]
    5ee8:      	b	0x5ef8 <_stogir.floating.validate+0x390>
    5eec:      	ldr	x2, [x0, #0x28]
    5ef0:      	add	x2, x2, x12, lsl #4
    5ef4:      	ldr	x2, [x2]
    5ef8:      	mov	w3, #0x1                ; =1
    5efc:      	b	0x5f08 <_stogir.floating.validate+0x3a0>
    5f00:      	movz	w3, #0x0, lsl #16
    5f04:      	movz	x2, #0x0, lsl #48
    5f08:      	ubfx	x3, x3, #0, #32
    5f0c:      	lsr	x16, x3, #0
    5f10:      	cmp	x16, #0x1
    5f14:      	b.eq	0x5f30 <_stogir.floating.validate+0x3c8>
    5f18:      	b.lo	0x5f20 <_stogir.floating.validate+0x3b8>
    5f1c:      	b	0x5f34 <_stogir.floating.validate+0x3cc>
    5f20:      	cmp	x16, #0x0
    5f24:      	b.eq	0x5f2c <_stogir.floating.validate+0x3c4>
    5f28:      	b	0x5f34 <_stogir.floating.validate+0x3cc>
    5f2c:      	b	0x5f38 <_stogir.floating.validate+0x3d0>
    5f30:      	b	0x5f50 <_stogir.floating.validate+0x3e8>
    5f34:      	b	0x6010 <_stogir.floating.validate+0x4a8>
    5f38:      	mov	x19, x8
    5f3c:      	mov	x0, #0x1                ; =1
    5f40:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1c4>
		0000000000005f40:  ARM64_RELOC_PAGE21	l_stogir.413
    5f44:      	ldr	x1, [x1]
		0000000000005f44:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    5f48:      	mov	x2, #0x18               ; =24
    5f4c:      	b	0x5e78 <_stogir.floating.validate+0x310>
    5f50:      	add	x16, sp, #0x10
    5f54:      	ldr	w3, [x16]
    5f58:      	ubfx	x2, x2, #0, #32
    5f5c:      	ubfx	x2, x2, #8, #8
    5f60:      	uxtb	w16, w6
    5f64:      	cmp	w16, wzr
    5f68:      	b.eq	0x5fc4 <_stogir.floating.validate+0x45c>
    5f6c:      	uxtb	w16, w9
    5f70:      	cmp	w16, wzr
    5f74:      	b.eq	0x5fc4 <_stogir.floating.validate+0x45c>
    5f78:      	mov	w4, #0x1                ; =1
    5f7c:      	b	0x5fc8 <_stogir.floating.validate+0x460>
    5f80:      	movz	x2, #0x0, lsl #48
    5f84:      	b	0x5ec8 <_stogir.floating.validate+0x360>
    5f88:      	movz	x2, #0x0, lsl #48
    5f8c:      	b	0x5ec0 <_stogir.floating.validate+0x358>
    5f90:      	movz	w1, #0x0, lsl #16
    5f94:      	mov	w5, w1
    5f98:      	mov	w1, w7
    5f9c:      	mov	x19, x8
    5fa0:      	add	x8, sp, #0x20
    5fa4:      	bl	0x5fa4 <_stogir.floating.validate+0x43c>
		0000000000005fa4:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    5fa8:      	add	x16, sp, #0x20
    5fac:      	ldr	x0, [x16]
    5fb0:      	add	x16, sp, #0x20
    5fb4:      	ldr	x1, [x16, #0x8]
    5fb8:      	add	x16, sp, #0x20
    5fbc:      	ldr	x2, [x16, #0x10]
    5fc0:      	b	0x5e78 <_stogir.floating.validate+0x310>
    5fc4:      	orr	x4, x2, xzr
    5fc8:      	sxtw	x4, w4
    5fcc:      	ubfx	x3, x3, #8, #8
    5fd0:      	cmp	x3, x4
    5fd4:      	b.ne	0x6020 <_stogir.floating.validate+0x4b8>
    5fd8:      	add	x16, sp, #0x10
    5fdc:      	ldr	w3, [x16, #0x4]
    5fe0:      	add	x16, sp, #0x10
    5fe4:      	ldr	w4, [x16, #0x8]
    5fe8:      	uxtb	w16, w1
    5fec:      	cmp	w16, wzr
    5ff0:      	b.eq	0x5f90 <_stogir.floating.validate+0x428>
    5ff4:      	add	x16, sp, #0x10
    5ff8:      	ldr	w1, [x16, #0xc]
    5ffc:      	b	0x5f94 <_stogir.floating.validate+0x42c>
    6000:      	movz	x2, #0x0, lsl #48
    6004:      	b	0x5f84 <_stogir.floating.validate+0x41c>
    6008:      	brk	#0
    600c:      	b	0x6008 <_stogir.floating.validate+0x4a0>
    6010:      	brk	#0
    6014:      	b	0x6010 <_stogir.floating.validate+0x4a8>
    6018:      	mov	x19, x8
    601c:      	b	0x5d08 <_stogir.floating.validate+0x1a0>
    6020:      	mov	x19, x8
    6024:      	b	0x5e68 <_stogir.floating.validate+0x300>

0000000000006028 <_stogir.integer-unary.valid-type?>:
    6028:      	sxtw	x0, w0
    602c:      	cmp	x0, #0x2d
    6030:      	cset	w2, eq
    6034:      	cmp	x0, #0x1f
    6038:      	cset	w3, eq
    603c:      	cmp	x0, #0x20
    6040:      	cset	w4, eq
    6044:      	cmp	x0, #0x36
    6048:      	cset	w5, eq
    604c:      	uxtb	w16, w3
    6050:      	cmp	w16, wzr
    6054:      	b.ne	0x609c <_stogir.integer-unary.valid-type?+0x74>
    6058:      	uxtb	w16, w4
    605c:      	cmp	w16, wzr
    6060:      	b.ne	0x609c <_stogir.integer-unary.valid-type?+0x74>
    6064:      	uxtb	w16, w2
    6068:      	cmp	w16, wzr
    606c:      	b.ne	0x609c <_stogir.integer-unary.valid-type?+0x74>
    6070:      	uxtb	w16, w5
    6074:      	cmp	w16, wzr
    6078:      	b.ne	0x609c <_stogir.integer-unary.valid-type?+0x74>
    607c:      	cmp	x0, #0x37
    6080:      	b.eq	0x609c <_stogir.integer-unary.valid-type?+0x74>
    6084:      	cmp	x0, #0x38
    6088:      	b.eq	0x609c <_stogir.integer-unary.valid-type?+0x74>
    608c:      	cmp	x0, #0x39
    6090:      	b.eq	0x609c <_stogir.integer-unary.valid-type?+0x74>
    6094:      	movz	x0, #0x0, lsl #48
    6098:      	b	0x60d4 <_stogir.integer-unary.valid-type?+0xac>
    609c:      	sxtw	x1, w1
    60a0:      	cmp	x1, #0x1
    60a4:      	b.lt	0x60d0 <_stogir.integer-unary.valid-type?+0xa8>
    60a8:      	cmp	x1, #0xb
    60ac:      	cset	w0, le
    60b0:      	uxtb	w16, w0
    60b4:      	cmp	w16, wzr
    60b8:      	b.eq	0x60d0 <_stogir.integer-unary.valid-type?+0xa8>
    60bc:      	uxtb	w16, w2
    60c0:      	cmp	w16, wzr
    60c4:      	b.eq	0x60e0 <_stogir.integer-unary.valid-type?+0xb8>
    60c8:      	mov	x0, #0x1                ; =1
    60cc:      	b	0x60dc <_stogir.integer-unary.valid-type?+0xb4>
    60d0:      	movz	x0, #0x0, lsl #48
    60d4:      	ret
    60d8:      	mov	x0, #0x1                ; =1
    60dc:      	b	0x60d4 <_stogir.integer-unary.valid-type?+0xac>
    60e0:      	cmp	x1, #0x1
    60e4:      	b.ne	0x60f0 <_stogir.integer-unary.valid-type?+0xc8>
    60e8:      	movz	x0, #0x0, lsl #48
    60ec:      	b	0x60dc <_stogir.integer-unary.valid-type?+0xb4>
    60f0:      	cmp	x1, #0x6
    60f4:      	cset	w2, eq
    60f8:      	uxtb	w16, w3
    60fc:      	cmp	w16, wzr
    6100:      	b.eq	0x6114 <_stogir.integer-unary.valid-type?+0xec>
    6104:      	uxtb	w16, w2
    6108:      	cmp	w16, wzr
    610c:      	cset	x0, eq
    6110:      	b	0x60dc <_stogir.integer-unary.valid-type?+0xb4>
    6114:      	uxtb	w16, w4
    6118:      	cmp	w16, wzr
    611c:      	b.eq	0x6138 <_stogir.integer-unary.valid-type?+0x110>
    6120:      	cmp	x1, #0x7
    6124:      	b.lt	0x6130 <_stogir.integer-unary.valid-type?+0x108>
    6128:      	ubfx	x0, x0, #0, #8
    612c:      	b	0x6134 <_stogir.integer-unary.valid-type?+0x10c>
    6130:      	movz	x0, #0x0, lsl #48
    6134:      	b	0x60dc <_stogir.integer-unary.valid-type?+0xb4>
    6138:      	uxtb	w16, w5
    613c:      	cmp	w16, wzr
    6140:      	b.eq	0x60d8 <_stogir.integer-unary.valid-type?+0xb0>
    6144:      	cmp	x1, #0x3
    6148:      	b.ne	0x6164 <_stogir.integer-unary.valid-type?+0x13c>
    614c:      	mov	x0, #0x1                ; =1
    6150:      	b	0x6160 <_stogir.integer-unary.valid-type?+0x138>
    6154:      	cmp	x1, #0xb
    6158:      	cset	w0, eq
    615c:      	ubfx	x0, x0, #0, #8
    6160:      	b	0x60dc <_stogir.integer-unary.valid-type?+0xb4>
    6164:      	cmp	x1, #0x4
    6168:      	b.ne	0x6174 <_stogir.integer-unary.valid-type?+0x14c>
    616c:      	mov	x0, #0x1                ; =1
    6170:      	b	0x6160 <_stogir.integer-unary.valid-type?+0x138>
    6174:      	cmp	x1, #0x5
    6178:      	b.ne	0x6184 <_stogir.integer-unary.valid-type?+0x15c>
    617c:      	mov	x0, #0x1                ; =1
    6180:      	b	0x6160 <_stogir.integer-unary.valid-type?+0x138>
    6184:      	uxtb	w16, w2
    6188:      	cmp	w16, wzr
    618c:      	b.eq	0x6198 <_stogir.integer-unary.valid-type?+0x170>
    6190:      	mov	x0, #0x1                ; =1
    6194:      	b	0x6160 <_stogir.integer-unary.valid-type?+0x138>
    6198:      	cmp	x1, #0x9
    619c:      	b.ne	0x61a8 <_stogir.integer-unary.valid-type?+0x180>
    61a0:      	mov	x0, #0x1                ; =1
    61a4:      	b	0x6160 <_stogir.integer-unary.valid-type?+0x138>
    61a8:      	cmp	x1, #0xa
    61ac:      	b.ne	0x6154 <_stogir.integer-unary.valid-type?+0x12c>
    61b0:      	mov	x0, #0x1                ; =1
    61b4:      	b	0x6160 <_stogir.integer-unary.valid-type?+0x138>

00000000000061b8 <_stogir.types.vector?>:
    61b8:      	sxtw	x1, w0
    61bc:      	cmp	x1, #0xf
    61c0:      	b.le	0x61ec <_stogir.types.vector?+0x34>
    61c4:      	cmp	x1, #0x80
    61c8:      	b.ge	0x61fc <_stogir.types.vector?+0x44>
    61cc:      	and	w0, w0, #0xf
    61d0:      	ubfx	x0, x0, #0, #32
    61d4:      	cmp	x0, #0x1
    61d8:      	b.lt	0x61f4 <_stogir.types.vector?+0x3c>
    61dc:      	cmp	x0, #0xd
    61e0:      	cset	w0, le
    61e4:      	ubfx	x0, x0, #0, #8
    61e8:      	b	0x61f8 <_stogir.types.vector?+0x40>
    61ec:      	movz	x0, #0x0, lsl #48
    61f0:      	b	0x61f8 <_stogir.types.vector?+0x40>
    61f4:      	movz	x0, #0x0, lsl #48
    61f8:      	ret
    61fc:      	movz	x0, #0x0, lsl #48
    6200:      	b	0x61f8 <_stogir.types.vector?+0x40>

0000000000006204 <_stogir.floating.operation?>:
    6204:      	sxtw	x0, w0
    6208:      	cmp	x0, #0xe
    620c:      	b.lt	0x6220 <_stogir.floating.operation?+0x1c>
    6210:      	cmp	x0, #0x19
    6214:      	b.gt	0x6220 <_stogir.floating.operation?+0x1c>
    6218:      	mov	x0, #0x1                ; =1
    621c:      	b	0x624c <_stogir.floating.operation?+0x48>
    6220:      	cmp	x0, #0x1f
    6224:      	b.eq	0x6248 <_stogir.floating.operation?+0x44>
    6228:      	cmp	x0, #0x20
    622c:      	b.eq	0x6248 <_stogir.floating.operation?+0x44>
    6230:      	cmp	x0, #0x1a
    6234:      	b.lt	0x6260 <_stogir.floating.operation?+0x5c>
    6238:      	cmp	x0, #0x1d
    623c:      	b.gt	0x6260 <_stogir.floating.operation?+0x5c>
    6240:      	mov	x0, #0x1                ; =1
    6244:      	b	0x625c <_stogir.floating.operation?+0x58>
    6248:      	mov	x0, #0x1                ; =1
    624c:      	ret
    6250:      	cmp	x0, #0x3b
    6254:      	cset	w0, eq
    6258:      	ubfx	x0, x0, #0, #8
    625c:      	b	0x624c <_stogir.floating.operation?+0x48>
    6260:      	cmp	x0, #0x3a
    6264:      	b.ne	0x6250 <_stogir.floating.operation?+0x4c>
    6268:      	mov	x0, #0x1                ; =1
    626c:      	b	0x625c <_stogir.floating.operation?+0x58>

0000000000006270 <_stogir.vector-lanes.validate>:
    6270:      	sub	sp, sp, #0x50
    6274:      	str	x29, [sp]
    6278:      	str	x30, [sp, #0x8]
    627c:      	mov	x29, sp
    6280:      	str	x19, [sp, #0x40]
    6284:      	sxtw	x1, w1
    6288:      	add	x3, x0, #0x78
    628c:      	add	x4, x0, #0x28
    6290:      	lsl	x5, x1, #2
    6294:      	cmp	x1, #0x0
    6298:      	cset	w6, gt
    629c:      	movz	x16, #0x0, lsl #48
    62a0:      	sub	x7, x16, x1
    62a4:      	sub	x9, x7, #0x1
    62a8:      	uxtb	w16, w6
    62ac:      	cmp	w16, wzr
    62b0:      	b.eq	0x62ec <_stogir.vector-lanes.validate+0x7c>
    62b4:      	ldr	x4, [x0, #0x8]
    62b8:      	cmp	x1, x4
    62bc:      	b.ge	0x6338 <_stogir.vector-lanes.validate+0xc8>
    62c0:      	ldr	x3, [x3, #0x8]
    62c4:      	cmp	x1, x3
    62c8:      	b.ge	0x6424 <_stogir.vector-lanes.validate+0x1b4>
    62cc:      	ldr	x3, [x0, #0x78]
    62d0:      	add	x3, x5, x3
    62d4:      	ldr	w3, [x3]
    62d8:      	sxtw	x3, w3
    62dc:      	cmp	x3, #0x0
    62e0:      	cset	w3, ge
    62e4:      	ubfx	x3, x3, #0, #8
    62e8:      	b	0x6428 <_stogir.vector-lanes.validate+0x1b8>
    62ec:      	cmp	x1, #0x0
    62f0:      	b.ge	0x6340 <_stogir.vector-lanes.validate+0xd0>
    62f4:      	add	x3, x0, #0x50
    62f8:      	ldr	x4, [x4, #0x8]
    62fc:      	ldr	x3, [x3, #0x8]
    6300:      	cmp	x4, x3
    6304:      	b.ne	0x6330 <_stogir.vector-lanes.validate+0xc0>
    6308:      	cmp	x7, x4
    630c:      	b.gt	0x6468 <_stogir.vector-lanes.validate+0x1f8>
    6310:      	ldr	x3, [x0, #0x50]
    6314:      	add	x3, x3, x9, lsl #2
    6318:      	ldr	w3, [x3]
    631c:      	sxtw	x3, w3
    6320:      	cmp	x3, #0x0
    6324:      	cset	w3, gt
    6328:      	ubfx	x3, x3, #0, #8
    632c:      	b	0x646c <_stogir.vector-lanes.validate+0x1fc>
    6330:      	movz	x3, #0x0, lsl #48
    6334:      	b	0x6344 <_stogir.vector-lanes.validate+0xd4>
    6338:      	movz	x3, #0x0, lsl #48
    633c:      	b	0x6344 <_stogir.vector-lanes.validate+0xd4>
    6340:      	movz	x3, #0x0, lsl #48
    6344:      	cmp	x3, #0x0
    6348:      	b.eq	0x6384 <_stogir.vector-lanes.validate+0x114>
    634c:      	uxtb	w16, w6
    6350:      	cmp	w16, wzr
    6354:      	b.eq	0x636c <_stogir.vector-lanes.validate+0xfc>
    6358:      	ldr	x3, [x0]
    635c:      	add	x3, x3, x1, lsl #4
    6360:      	ldr	x4, [x3]
    6364:      	ldr	x3, [x3, #0x8]
    6368:      	b	0x637c <_stogir.vector-lanes.validate+0x10c>
    636c:      	ldr	x3, [x0, #0x28]
    6370:      	add	x3, x3, x9, lsl #4
    6374:      	ldr	x4, [x3]
    6378:      	ldr	x3, [x3, #0x8]
    637c:      	mov	w6, #0x1                ; =1
    6380:      	b	0x6390 <_stogir.vector-lanes.validate+0x120>
    6384:      	movz	w6, #0x0, lsl #16
    6388:      	movz	x4, #0x0, lsl #48
    638c:      	movz	x3, #0x0, lsl #48
    6390:      	ubfx	x6, x6, #0, #32
    6394:      	lsr	x16, x6, #0
    6398:      	cmp	x16, #0x1
    639c:      	b.eq	0x63b8 <_stogir.vector-lanes.validate+0x148>
    63a0:      	b.lo	0x63a8 <_stogir.vector-lanes.validate+0x138>
    63a4:      	b	0x63bc <_stogir.vector-lanes.validate+0x14c>
    63a8:      	cmp	x16, #0x0
    63ac:      	b.eq	0x63b4 <_stogir.vector-lanes.validate+0x144>
    63b0:      	b	0x63bc <_stogir.vector-lanes.validate+0x14c>
    63b4:      	b	0x63c0 <_stogir.vector-lanes.validate+0x150>
    63b8:      	b	0x63d8 <_stogir.vector-lanes.validate+0x168>
    63bc:      	b	0x6520 <_stogir.vector-lanes.validate+0x2b0>
    63c0:      	mov	x19, x8
    63c4:      	mov	x0, #0x1                ; =1
    63c8:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x498>
		00000000000063c8:  ARM64_RELOC_PAGE21	l_stogir.414
    63cc:      	ldr	x1, [x1]
		00000000000063cc:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    63d0:      	mov	x2, #0x1f               ; =31
    63d4:      	b	0x6404 <_stogir.vector-lanes.validate+0x194>
    63d8:      	add	x16, sp, #0x10
    63dc:      	str	x4, [x16]
    63e0:      	add	x16, sp, #0x10
    63e4:      	str	x3, [x16, #0x8]
    63e8:      	cmp	x1, #0x0
    63ec:      	b.gt	0x642c <_stogir.vector-lanes.validate+0x1bc>
    63f0:      	mov	x19, x8
    63f4:      	mov	x0, #0x1                ; =1
    63f8:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x498>
		00000000000063f8:  ARM64_RELOC_PAGE21	l_stogir.415
    63fc:      	ldr	x1, [x1]
		00000000000063fc:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    6400:      	mov	x2, #0x25               ; =37
    6404:      	str	x0, [x19]
    6408:      	str	x1, [x19, #0x8]
    640c:      	str	x2, [x19, #0x10]
    6410:      	ldr	x19, [sp, #0x40]
    6414:      	ldr	x29, [sp]
    6418:      	ldr	x30, [sp, #0x8]
    641c:      	add	sp, sp, #0x50
    6420:      	ret
    6424:      	movz	x3, #0x0, lsl #48
    6428:      	b	0x633c <_stogir.vector-lanes.validate+0xcc>
    642c:      	uxtb	w4, w4
    6430:      	orr	x1, x4, xzr
    6434:      	cmp	x1, #0x3d
    6438:      	b.lt	0x6528 <_stogir.vector-lanes.validate+0x2b8>
    643c:      	cmp	x1, #0x3f
    6440:      	b.gt	0x6530 <_stogir.vector-lanes.validate+0x2c0>
    6444:      	cmp	x1, #0x3e
    6448:      	cset	w3, eq
    644c:      	ldr	x6, [x0, #0x78]
    6450:      	add	x5, x5, x6
    6454:      	ldr	w5, [x5]
    6458:      	cmp	x1, #0x3d
    645c:      	b.ne	0x64bc <_stogir.vector-lanes.validate+0x24c>
    6460:      	mov	w6, #0x2                ; =2
    6464:      	b	0x64d0 <_stogir.vector-lanes.validate+0x260>
    6468:      	movz	x3, #0x0, lsl #48
    646c:      	b	0x6334 <_stogir.vector-lanes.validate+0xc4>
    6470:      	movz	w3, #0x0, lsl #16
    6474:      	ubfx	x5, x5, #8, #8
    6478:      	mov	x19, x8
    647c:      	add	x8, sp, #0x20
    6480:      	fmov	s31, w1
    6484:      	mov	w1, w4
    6488:      	mov	w4, w6
    648c:      	mov	w6, w3
    6490:      	mov	w3, w2
    6494:      	mov	w2, w5
    6498:      	fmov	w5, s31
    649c:      	bl	0x649c <_stogir.vector-lanes.validate+0x22c>
		000000000000649c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    64a0:      	add	x16, sp, #0x20
    64a4:      	ldr	x0, [x16]
    64a8:      	add	x16, sp, #0x20
    64ac:      	ldr	x1, [x16, #0x8]
    64b0:      	add	x16, sp, #0x20
    64b4:      	ldr	x2, [x16, #0x10]
    64b8:      	b	0x6404 <_stogir.vector-lanes.validate+0x194>
    64bc:      	uxtb	w16, w3
    64c0:      	cmp	w16, wzr
    64c4:      	mov	w16, #0x3               ; =3
    64c8:      	mov	w17, #0x1               ; =1
    64cc:      	csel	w6, w16, w17, ne
    64d0:      	sxtw	x5, w5
    64d4:      	sxtw	x6, w6
    64d8:      	cmp	x5, x6
    64dc:      	b.ne	0x6538 <_stogir.vector-lanes.validate+0x2c8>
    64e0:      	add	x16, sp, #0x10
    64e4:      	ldr	w5, [x16]
    64e8:      	add	x16, sp, #0x10
    64ec:      	ldr	w6, [x16, #0x4]
    64f0:      	cmp	x1, #0x3f
    64f4:      	b.ne	0x6500 <_stogir.vector-lanes.validate+0x290>
    64f8:      	movz	w1, #0x0, lsl #16
    64fc:      	b	0x6508 <_stogir.vector-lanes.validate+0x298>
    6500:      	add	x16, sp, #0x10
    6504:      	ldr	w1, [x16, #0x8]
    6508:      	uxtb	w16, w3
    650c:      	cmp	w16, wzr
    6510:      	b.eq	0x6470 <_stogir.vector-lanes.validate+0x200>
    6514:      	add	x16, sp, #0x10
    6518:      	ldr	w3, [x16, #0xc]
    651c:      	b	0x6474 <_stogir.vector-lanes.validate+0x204>
    6520:      	brk	#0
    6524:      	b	0x6520 <_stogir.vector-lanes.validate+0x2b0>
    6528:      	mov	x19, x8
    652c:      	b	0x63f4 <_stogir.vector-lanes.validate+0x184>
    6530:      	mov	x19, x8
    6534:      	b	0x63f4 <_stogir.vector-lanes.validate+0x184>
    6538:      	mov	x19, x8
    653c:      	b	0x63f4 <_stogir.vector-lanes.validate+0x184>

0000000000006540 <_stogir.vector-comparison.node?>:
    6540:      	sxtw	x1, w1
    6544:      	add	x2, x0, #0x28
    6548:      	cmp	x1, #0x0
    654c:      	cset	w3, gt
    6550:      	movz	x16, #0x0, lsl #48
    6554:      	sub	x4, x16, x1
    6558:      	sub	x5, x4, #0x1
    655c:      	uxtb	w16, w3
    6560:      	cmp	w16, wzr
    6564:      	b.eq	0x65a4 <_stogir.vector-comparison.node?+0x64>
    6568:      	ldr	x2, [x0, #0x8]
    656c:      	cmp	x1, x2
    6570:      	b.ge	0x65f0 <_stogir.vector-comparison.node?+0xb0>
    6574:      	add	x2, x0, #0x78
    6578:      	ldr	x2, [x2, #0x8]
    657c:      	cmp	x1, x2
    6580:      	b.ge	0x66cc <_stogir.vector-comparison.node?+0x18c>
    6584:      	ldr	x2, [x0, #0x78]
    6588:      	add	x2, x2, x1, lsl #2
    658c:      	ldr	w2, [x2]
    6590:      	sxtw	x2, w2
    6594:      	cmp	x2, #0x0
    6598:      	cset	w2, ge
    659c:      	ubfx	x2, x2, #0, #8
    65a0:      	b	0x66d0 <_stogir.vector-comparison.node?+0x190>
    65a4:      	cmp	x1, #0x0
    65a8:      	b.ge	0x65f8 <_stogir.vector-comparison.node?+0xb8>
    65ac:      	add	x6, x0, #0x50
    65b0:      	ldr	x2, [x2, #0x8]
    65b4:      	ldr	x6, [x6, #0x8]
    65b8:      	cmp	x2, x6
    65bc:      	b.ne	0x65e8 <_stogir.vector-comparison.node?+0xa8>
    65c0:      	cmp	x4, x2
    65c4:      	b.gt	0x66d4 <_stogir.vector-comparison.node?+0x194>
    65c8:      	ldr	x2, [x0, #0x50]
    65cc:      	add	x2, x2, x5, lsl #2
    65d0:      	ldr	w2, [x2]
    65d4:      	sxtw	x2, w2
    65d8:      	cmp	x2, #0x0
    65dc:      	cset	w2, gt
    65e0:      	ubfx	x2, x2, #0, #8
    65e4:      	b	0x66d8 <_stogir.vector-comparison.node?+0x198>
    65e8:      	movz	x2, #0x0, lsl #48
    65ec:      	b	0x65fc <_stogir.vector-comparison.node?+0xbc>
    65f0:      	movz	x2, #0x0, lsl #48
    65f4:      	b	0x65fc <_stogir.vector-comparison.node?+0xbc>
    65f8:      	movz	x2, #0x0, lsl #48
    65fc:      	cmp	x2, #0x0
    6600:      	b.eq	0x6634 <_stogir.vector-comparison.node?+0xf4>
    6604:      	uxtb	w16, w3
    6608:      	cmp	w16, wzr
    660c:      	b.eq	0x6620 <_stogir.vector-comparison.node?+0xe0>
    6610:      	ldr	x0, [x0]
    6614:      	add	x0, x0, x1, lsl #4
    6618:      	ldr	x0, [x0]
    661c:      	b	0x662c <_stogir.vector-comparison.node?+0xec>
    6620:      	ldr	x0, [x0, #0x28]
    6624:      	add	x0, x0, x5, lsl #4
    6628:      	ldr	x0, [x0]
    662c:      	mov	w1, #0x1                ; =1
    6630:      	b	0x663c <_stogir.vector-comparison.node?+0xfc>
    6634:      	movz	w1, #0x0, lsl #16
    6638:      	movz	x0, #0x0, lsl #48
    663c:      	ubfx	x1, x1, #0, #32
    6640:      	lsr	x16, x1, #0
    6644:      	cmp	x16, #0x1
    6648:      	b.eq	0x6664 <_stogir.vector-comparison.node?+0x124>
    664c:      	b.lo	0x6654 <_stogir.vector-comparison.node?+0x114>
    6650:      	b	0x6668 <_stogir.vector-comparison.node?+0x128>
    6654:      	cmp	x16, #0x0
    6658:      	b.eq	0x6660 <_stogir.vector-comparison.node?+0x120>
    665c:      	b	0x6668 <_stogir.vector-comparison.node?+0x128>
    6660:      	b	0x666c <_stogir.vector-comparison.node?+0x12c>
    6664:      	b	0x667c <_stogir.vector-comparison.node?+0x13c>
    6668:      	b	0x66f4 <_stogir.vector-comparison.node?+0x1b4>
    666c:      	movz	x0, #0x0, lsl #48
    6670:      	b	0x6678 <_stogir.vector-comparison.node?+0x138>
    6674:      	movz	x0, #0x0, lsl #48
    6678:      	ret
    667c:      	uxtb	w1, w0
    6680:      	cmp	x1, #0xe
    6684:      	b.lt	0x6674 <_stogir.vector-comparison.node?+0x134>
    6688:      	cmp	x1, #0x19
    668c:      	b.gt	0x6674 <_stogir.vector-comparison.node?+0x134>
    6690:      	ubfx	x0, x0, #0, #32
    6694:      	ubfx	x0, x0, #8, #8
    6698:      	orr	x1, x0, xzr
    669c:      	cmp	x1, #0xf
    66a0:      	b.le	0x66dc <_stogir.vector-comparison.node?+0x19c>
    66a4:      	cmp	x1, #0x80
    66a8:      	b.ge	0x66e4 <_stogir.vector-comparison.node?+0x1a4>
    66ac:      	and	w0, w0, #0xf
    66b0:      	ubfx	x0, x0, #0, #32
    66b4:      	cmp	x0, #0x1
    66b8:      	b.lt	0x66ec <_stogir.vector-comparison.node?+0x1ac>
    66bc:      	cmp	x0, #0xd
    66c0:      	cset	w0, le
    66c4:      	ubfx	x0, x0, #0, #8
    66c8:      	b	0x66f0 <_stogir.vector-comparison.node?+0x1b0>
    66cc:      	movz	x2, #0x0, lsl #48
    66d0:      	b	0x65f4 <_stogir.vector-comparison.node?+0xb4>
    66d4:      	movz	x2, #0x0, lsl #48
    66d8:      	b	0x65ec <_stogir.vector-comparison.node?+0xac>
    66dc:      	movz	x0, #0x0, lsl #48
    66e0:      	b	0x6678 <_stogir.vector-comparison.node?+0x138>
    66e4:      	movz	x0, #0x0, lsl #48
    66e8:      	b	0x66e0 <_stogir.vector-comparison.node?+0x1a0>
    66ec:      	movz	x0, #0x0, lsl #48
    66f0:      	b	0x66e8 <_stogir.vector-comparison.node?+0x1a8>
    66f4:      	brk	#0
    66f8:      	b	0x66f4 <_stogir.vector-comparison.node?+0x1b4>

00000000000066fc <_stogir.vector-comparison.validate>:
    66fc:      	sub	sp, sp, #0x50
    6700:      	str	x29, [sp]
    6704:      	str	x30, [sp, #0x8]
    6708:      	mov	x29, sp
    670c:      	str	x19, [sp, #0x40]
    6710:      	sxtw	x1, w1
    6714:      	add	x3, x0, #0x78
    6718:      	add	x4, x0, #0x28
    671c:      	lsl	x5, x1, #2
    6720:      	cmp	x1, #0x0
    6724:      	cset	w6, gt
    6728:      	movz	x16, #0x0, lsl #48
    672c:      	sub	x7, x16, x1
    6730:      	sub	x9, x7, #0x1
    6734:      	uxtb	w16, w6
    6738:      	cmp	w16, wzr
    673c:      	b.eq	0x6778 <_stogir.vector-comparison.validate+0x7c>
    6740:      	ldr	x4, [x0, #0x8]
    6744:      	cmp	x1, x4
    6748:      	b.ge	0x67c4 <_stogir.vector-comparison.validate+0xc8>
    674c:      	ldr	x4, [x3, #0x8]
    6750:      	cmp	x1, x4
    6754:      	b.ge	0x68b4 <_stogir.vector-comparison.validate+0x1b8>
    6758:      	ldr	x4, [x0, #0x78]
    675c:      	add	x4, x5, x4
    6760:      	ldr	w4, [x4]
    6764:      	sxtw	x4, w4
    6768:      	cmp	x4, #0x0
    676c:      	cset	w4, ge
    6770:      	ubfx	x4, x4, #0, #8
    6774:      	b	0x68b8 <_stogir.vector-comparison.validate+0x1bc>
    6778:      	cmp	x1, #0x0
    677c:      	b.ge	0x67cc <_stogir.vector-comparison.validate+0xd0>
    6780:      	add	x10, x0, #0x50
    6784:      	ldr	x4, [x4, #0x8]
    6788:      	ldr	x10, [x10, #0x8]
    678c:      	cmp	x4, x10
    6790:      	b.ne	0x67bc <_stogir.vector-comparison.validate+0xc0>
    6794:      	cmp	x7, x4
    6798:      	b.gt	0x6900 <_stogir.vector-comparison.validate+0x204>
    679c:      	ldr	x4, [x0, #0x50]
    67a0:      	add	x4, x4, x9, lsl #2
    67a4:      	ldr	w4, [x4]
    67a8:      	sxtw	x4, w4
    67ac:      	cmp	x4, #0x0
    67b0:      	cset	w4, gt
    67b4:      	ubfx	x4, x4, #0, #8
    67b8:      	b	0x6904 <_stogir.vector-comparison.validate+0x208>
    67bc:      	movz	x4, #0x0, lsl #48
    67c0:      	b	0x67d0 <_stogir.vector-comparison.validate+0xd4>
    67c4:      	movz	x4, #0x0, lsl #48
    67c8:      	b	0x67d0 <_stogir.vector-comparison.validate+0xd4>
    67cc:      	movz	x4, #0x0, lsl #48
    67d0:      	lsl	x7, x1, #4
    67d4:      	cmp	x4, #0x0
    67d8:      	b.eq	0x6814 <_stogir.vector-comparison.validate+0x118>
    67dc:      	uxtb	w16, w6
    67e0:      	cmp	w16, wzr
    67e4:      	b.eq	0x67fc <_stogir.vector-comparison.validate+0x100>
    67e8:      	ldr	x4, [x0]
    67ec:      	add	x4, x7, x4
    67f0:      	ldr	x6, [x4]
    67f4:      	ldr	x4, [x4, #0x8]
    67f8:      	b	0x680c <_stogir.vector-comparison.validate+0x110>
    67fc:      	ldr	x4, [x0, #0x28]
    6800:      	add	x4, x4, x9, lsl #4
    6804:      	ldr	x6, [x4]
    6808:      	ldr	x4, [x4, #0x8]
    680c:      	mov	w9, #0x1                ; =1
    6810:      	b	0x6820 <_stogir.vector-comparison.validate+0x124>
    6814:      	movz	w9, #0x0, lsl #16
    6818:      	movz	x6, #0x0, lsl #48
    681c:      	movz	x4, #0x0, lsl #48
    6820:      	ubfx	x9, x9, #0, #32
    6824:      	lsr	x16, x9, #0
    6828:      	cmp	x16, #0x1
    682c:      	b.eq	0x6848 <_stogir.vector-comparison.validate+0x14c>
    6830:      	b.lo	0x6838 <_stogir.vector-comparison.validate+0x13c>
    6834:      	b	0x684c <_stogir.vector-comparison.validate+0x150>
    6838:      	cmp	x16, #0x0
    683c:      	b.eq	0x6844 <_stogir.vector-comparison.validate+0x148>
    6840:      	b	0x684c <_stogir.vector-comparison.validate+0x150>
    6844:      	b	0x6850 <_stogir.vector-comparison.validate+0x154>
    6848:      	b	0x6884 <_stogir.vector-comparison.validate+0x188>
    684c:      	b	0x6a00 <_stogir.vector-comparison.validate+0x304>
    6850:      	mov	x19, x8
    6854:      	mov	x0, #0x1                ; =1
    6858:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x498>
		0000000000006858:  ARM64_RELOC_PAGE21	l_stogir.416
    685c:      	ldr	x1, [x1]
		000000000000685c:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    6860:      	mov	x2, #0x25               ; =37
    6864:      	str	x0, [x19]
    6868:      	str	x1, [x19, #0x8]
    686c:      	str	x2, [x19, #0x10]
    6870:      	ldr	x19, [sp, #0x40]
    6874:      	ldr	x29, [sp]
    6878:      	ldr	x30, [sp, #0x8]
    687c:      	add	sp, sp, #0x50
    6880:      	ret
    6884:      	add	x16, sp, #0x10
    6888:      	str	x6, [x16]
    688c:      	add	x16, sp, #0x10
    6890:      	str	x4, [x16, #0x8]
    6894:      	cmp	x1, #0x0
    6898:      	b.gt	0x68bc <_stogir.vector-comparison.validate+0x1c0>
    689c:      	mov	x19, x8
    68a0:      	mov	x0, #0x1                ; =1
    68a4:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x498>
		00000000000068a4:  ARM64_RELOC_PAGE21	l_stogir.417
    68a8:      	ldr	x1, [x1]
		00000000000068a8:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    68ac:      	mov	x2, #0x2b               ; =43
    68b0:      	b	0x6864 <_stogir.vector-comparison.validate+0x168>
    68b4:      	movz	x4, #0x0, lsl #48
    68b8:      	b	0x67c8 <_stogir.vector-comparison.validate+0xcc>
    68bc:      	ldr	x4, [x0, #0x8]
    68c0:      	cmp	x1, x4
    68c4:      	b.ge	0x6908 <_stogir.vector-comparison.validate+0x20c>
    68c8:      	ldr	x3, [x3, #0x8]
    68cc:      	cmp	x1, x3
    68d0:      	b.ge	0x6908 <_stogir.vector-comparison.validate+0x20c>
    68d4:      	ldr	x1, [x0, #0x78]
    68d8:      	add	x1, x5, x1
    68dc:      	ldr	w1, [x1]
    68e0:      	sxtw	x1, w1
    68e4:      	cmp	x1, #0x0
    68e8:      	b.lt	0x6908 <_stogir.vector-comparison.validate+0x20c>
    68ec:      	ldr	x1, [x0]
    68f0:      	add	x1, x7, x1
    68f4:      	ldr	x1, [x1]
    68f8:      	mov	w3, #0x1                ; =1
    68fc:      	b	0x6910 <_stogir.vector-comparison.validate+0x214>
    6900:      	movz	x4, #0x0, lsl #48
    6904:      	b	0x67c0 <_stogir.vector-comparison.validate+0xc4>
    6908:      	movz	w3, #0x0, lsl #16
    690c:      	movz	x1, #0x0, lsl #48
    6910:      	ubfx	x3, x3, #0, #32
    6914:      	lsr	x16, x3, #0
    6918:      	cmp	x16, #0x1
    691c:      	b.eq	0x6938 <_stogir.vector-comparison.validate+0x23c>
    6920:      	b.lo	0x6928 <_stogir.vector-comparison.validate+0x22c>
    6924:      	b	0x693c <_stogir.vector-comparison.validate+0x240>
    6928:      	cmp	x16, #0x0
    692c:      	b.eq	0x6934 <_stogir.vector-comparison.validate+0x238>
    6930:      	b	0x693c <_stogir.vector-comparison.validate+0x240>
    6934:      	b	0x6940 <_stogir.vector-comparison.validate+0x244>
    6938:      	b	0x6948 <_stogir.vector-comparison.validate+0x24c>
    693c:      	b	0x6a08 <_stogir.vector-comparison.validate+0x30c>
    6940:      	mov	x19, x8
    6944:      	b	0x68a0 <_stogir.vector-comparison.validate+0x1a4>
    6948:      	uxtb	w3, w1
    694c:      	cmp	x3, #0xe
    6950:      	b.lt	0x6a10 <_stogir.vector-comparison.validate+0x314>
    6954:      	cmp	x3, #0x19
    6958:      	b.gt	0x6a18 <_stogir.vector-comparison.validate+0x31c>
    695c:      	ubfx	x1, x1, #0, #32
    6960:      	ubfx	x1, x1, #8, #8
    6964:      	orr	x3, x1, xzr
    6968:      	cmp	x3, #0xf
    696c:      	b.le	0x6a20 <_stogir.vector-comparison.validate+0x324>
    6970:      	cmp	x3, #0x80
    6974:      	b.ge	0x6a28 <_stogir.vector-comparison.validate+0x32c>
    6978:      	and	w1, w1, #0xf
    697c:      	ubfx	x1, x1, #0, #32
    6980:      	cmp	x1, #0x1
    6984:      	b.lt	0x6a30 <_stogir.vector-comparison.validate+0x334>
    6988:      	cmp	x1, #0xd
    698c:      	b.gt	0x6a38 <_stogir.vector-comparison.validate+0x33c>
    6990:      	ldr	x1, [x0, #0x78]
    6994:      	add	x1, x5, x1
    6998:      	ldr	w1, [x1]
    699c:      	sxtw	x1, w1
    69a0:      	cmp	x1, #0x2
    69a4:      	b.ne	0x6a40 <_stogir.vector-comparison.validate+0x344>
    69a8:      	add	x16, sp, #0x10
    69ac:      	ldr	w1, [x16]
    69b0:      	uxtb	w3, w1
    69b4:      	add	x16, sp, #0x10
    69b8:      	ldr	w4, [x16, #0x4]
    69bc:      	ubfx	x1, x1, #8, #8
    69c0:      	add	x16, sp, #0x10
    69c4:      	ldr	w5, [x16, #0x8]
    69c8:      	mov	x19, x8
    69cc:      	add	x8, sp, #0x20
    69d0:      	fmov	s31, w1
    69d4:      	mov	w1, w3
    69d8:      	mov	w3, w2
    69dc:      	fmov	w2, s31
    69e0:      	bl	0x69e0 <_stogir.vector-comparison.validate+0x2e4>
		00000000000069e0:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    69e4:      	add	x16, sp, #0x20
    69e8:      	ldr	x0, [x16]
    69ec:      	add	x16, sp, #0x20
    69f0:      	ldr	x1, [x16, #0x8]
    69f4:      	add	x16, sp, #0x20
    69f8:      	ldr	x2, [x16, #0x10]
    69fc:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1b4>
    6a00:      	brk	#0
    6a04:      	b	0x6a00 <_stogir.vector-comparison.validate+0x304>
    6a08:      	brk	#0
    6a0c:      	b	0x6a08 <_stogir.vector-comparison.validate+0x30c>
    6a10:      	mov	x19, x8
    6a14:      	b	0x68a0 <_stogir.vector-comparison.validate+0x1a4>
    6a18:      	mov	x19, x8
    6a1c:      	b	0x68a0 <_stogir.vector-comparison.validate+0x1a4>
    6a20:      	mov	x19, x8
    6a24:      	b	0x68a0 <_stogir.vector-comparison.validate+0x1a4>
    6a28:      	mov	x19, x8
    6a2c:      	b	0x68a0 <_stogir.vector-comparison.validate+0x1a4>
    6a30:      	mov	x19, x8
    6a34:      	b	0x68a0 <_stogir.vector-comparison.validate+0x1a4>
    6a38:      	mov	x19, x8
    6a3c:      	b	0x68a0 <_stogir.vector-comparison.validate+0x1a4>
    6a40:      	mov	x19, x8
    6a44:      	b	0x68a0 <_stogir.vector-comparison.validate+0x1a4>

0000000000006a48 <_stogir.vector-arithmetic.node?>:
    6a48:      	sxtw	x1, w1
    6a4c:      	add	x2, x0, #0x28
    6a50:      	cmp	x1, #0x0
    6a54:      	cset	w3, gt
    6a58:      	movz	x16, #0x0, lsl #48
    6a5c:      	sub	x4, x16, x1
    6a60:      	sub	x5, x4, #0x1
    6a64:      	uxtb	w16, w3
    6a68:      	cmp	w16, wzr
    6a6c:      	b.eq	0x6aac <_stogir.vector-arithmetic.node?+0x64>
    6a70:      	ldr	x2, [x0, #0x8]
    6a74:      	cmp	x1, x2
    6a78:      	b.ge	0x6af8 <_stogir.vector-arithmetic.node?+0xb0>
    6a7c:      	add	x2, x0, #0x78
    6a80:      	ldr	x2, [x2, #0x8]
    6a84:      	cmp	x1, x2
    6a88:      	b.ge	0x6c1c <_stogir.vector-arithmetic.node?+0x1d4>
    6a8c:      	ldr	x2, [x0, #0x78]
    6a90:      	add	x2, x2, x1, lsl #2
    6a94:      	ldr	w2, [x2]
    6a98:      	sxtw	x2, w2
    6a9c:      	cmp	x2, #0x0
    6aa0:      	cset	w2, ge
    6aa4:      	ubfx	x2, x2, #0, #8
    6aa8:      	b	0x6c20 <_stogir.vector-arithmetic.node?+0x1d8>
    6aac:      	cmp	x1, #0x0
    6ab0:      	b.ge	0x6b00 <_stogir.vector-arithmetic.node?+0xb8>
    6ab4:      	add	x6, x0, #0x50
    6ab8:      	ldr	x2, [x2, #0x8]
    6abc:      	ldr	x6, [x6, #0x8]
    6ac0:      	cmp	x2, x6
    6ac4:      	b.ne	0x6af0 <_stogir.vector-arithmetic.node?+0xa8>
    6ac8:      	cmp	x4, x2
    6acc:      	b.gt	0x6c2c <_stogir.vector-arithmetic.node?+0x1e4>
    6ad0:      	ldr	x2, [x0, #0x50]
    6ad4:      	add	x2, x2, x5, lsl #2
    6ad8:      	ldr	w2, [x2]
    6adc:      	sxtw	x2, w2
    6ae0:      	cmp	x2, #0x0
    6ae4:      	cset	w2, gt
    6ae8:      	ubfx	x2, x2, #0, #8
    6aec:      	b	0x6c30 <_stogir.vector-arithmetic.node?+0x1e8>
    6af0:      	movz	x2, #0x0, lsl #48
    6af4:      	b	0x6b04 <_stogir.vector-arithmetic.node?+0xbc>
    6af8:      	movz	x2, #0x0, lsl #48
    6afc:      	b	0x6b04 <_stogir.vector-arithmetic.node?+0xbc>
    6b00:      	movz	x2, #0x0, lsl #48
    6b04:      	cmp	x2, #0x0
    6b08:      	b.eq	0x6b3c <_stogir.vector-arithmetic.node?+0xf4>
    6b0c:      	uxtb	w16, w3
    6b10:      	cmp	w16, wzr
    6b14:      	b.eq	0x6b28 <_stogir.vector-arithmetic.node?+0xe0>
    6b18:      	ldr	x0, [x0]
    6b1c:      	add	x0, x0, x1, lsl #4
    6b20:      	ldr	x0, [x0]
    6b24:      	b	0x6b34 <_stogir.vector-arithmetic.node?+0xec>
    6b28:      	ldr	x0, [x0, #0x28]
    6b2c:      	add	x0, x0, x5, lsl #4
    6b30:      	ldr	x0, [x0]
    6b34:      	mov	w1, #0x1                ; =1
    6b38:      	b	0x6b44 <_stogir.vector-arithmetic.node?+0xfc>
    6b3c:      	movz	w1, #0x0, lsl #16
    6b40:      	movz	x0, #0x0, lsl #48
    6b44:      	ubfx	x1, x1, #0, #32
    6b48:      	lsr	x16, x1, #0
    6b4c:      	cmp	x16, #0x1
    6b50:      	b.eq	0x6b6c <_stogir.vector-arithmetic.node?+0x124>
    6b54:      	b.lo	0x6b5c <_stogir.vector-arithmetic.node?+0x114>
    6b58:      	b	0x6b70 <_stogir.vector-arithmetic.node?+0x128>
    6b5c:      	cmp	x16, #0x0
    6b60:      	b.eq	0x6b68 <_stogir.vector-arithmetic.node?+0x120>
    6b64:      	b	0x6b70 <_stogir.vector-arithmetic.node?+0x128>
    6b68:      	b	0x6b74 <_stogir.vector-arithmetic.node?+0x12c>
    6b6c:      	b	0x6b84 <_stogir.vector-arithmetic.node?+0x13c>
    6b70:      	b	0x6c3c <_stogir.vector-arithmetic.node?+0x1f4>
    6b74:      	movz	x0, #0x0, lsl #48
    6b78:      	b	0x6b80 <_stogir.vector-arithmetic.node?+0x138>
    6b7c:      	movz	x0, #0x0, lsl #48
    6b80:      	ret
    6b84:      	uxtb	w1, w0
    6b88:      	cmp	x1, #0x1f
    6b8c:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6b90:      	cmp	x1, #0x20
    6b94:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6b98:      	cmp	x1, #0x2d
    6b9c:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6ba0:      	cmp	x1, #0x36
    6ba4:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6ba8:      	cmp	x1, #0x37
    6bac:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6bb0:      	cmp	x1, #0x38
    6bb4:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6bb8:      	cmp	x1, #0x39
    6bbc:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6bc0:      	cmp	x1, #0x3a
    6bc4:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6bc8:      	cmp	x1, #0x3b
    6bcc:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6bd0:      	cmp	x1, #0x31
    6bd4:      	b.lt	0x6c44 <_stogir.vector-arithmetic.node?+0x1fc>
    6bd8:      	cmp	x1, #0x35
    6bdc:      	b.gt	0x6c44 <_stogir.vector-arithmetic.node?+0x1fc>
    6be0:      	ubfx	x0, x0, #0, #32
    6be4:      	ubfx	x0, x0, #8, #8
    6be8:      	orr	x1, x0, xzr
    6bec:      	cmp	x1, #0xf
    6bf0:      	b.le	0x6b7c <_stogir.vector-arithmetic.node?+0x134>
    6bf4:      	cmp	x1, #0x80
    6bf8:      	b.ge	0x6c24 <_stogir.vector-arithmetic.node?+0x1dc>
    6bfc:      	and	w0, w0, #0xf
    6c00:      	ubfx	x0, x0, #0, #32
    6c04:      	cmp	x0, #0x1
    6c08:      	b.lt	0x6c34 <_stogir.vector-arithmetic.node?+0x1ec>
    6c0c:      	cmp	x0, #0xd
    6c10:      	cset	w0, le
    6c14:      	ubfx	x0, x0, #0, #8
    6c18:      	b	0x6c38 <_stogir.vector-arithmetic.node?+0x1f0>
    6c1c:      	movz	x2, #0x0, lsl #48
    6c20:      	b	0x6afc <_stogir.vector-arithmetic.node?+0xb4>
    6c24:      	movz	x0, #0x0, lsl #48
    6c28:      	b	0x6b80 <_stogir.vector-arithmetic.node?+0x138>
    6c2c:      	movz	x2, #0x0, lsl #48
    6c30:      	b	0x6af4 <_stogir.vector-arithmetic.node?+0xac>
    6c34:      	movz	x0, #0x0, lsl #48
    6c38:      	b	0x6c28 <_stogir.vector-arithmetic.node?+0x1e0>
    6c3c:      	brk	#0
    6c40:      	b	0x6c3c <_stogir.vector-arithmetic.node?+0x1f4>
    6c44:      	cmp	x1, #0x1a
    6c48:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6c4c:      	cmp	x1, #0x1b
    6c50:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6c54:      	cmp	x1, #0x1c
    6c58:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6c5c:      	cmp	x1, #0x1d
    6c60:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6c64:      	cmp	x1, #0x1e
    6c68:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6c6c:      	cmp	x1, #0x2e
    6c70:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6c74:      	cmp	x1, #0x2f
    6c78:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6c7c:      	cmp	x1, #0x30
    6c80:      	b.eq	0x6be0 <_stogir.vector-arithmetic.node?+0x198>
    6c84:      	movz	x0, #0x0, lsl #48
    6c88:      	b	0x6b80 <_stogir.vector-arithmetic.node?+0x138>

0000000000006c8c <_stogir.vector-arithmetic.validate>:
    6c8c:      	sub	sp, sp, #0x60
    6c90:      	str	x29, [sp]
    6c94:      	str	x30, [sp, #0x8]
    6c98:      	mov	x29, sp
    6c9c:      	str	x19, [sp, #0x40]
    6ca0:      	str	x20, [sp, #0x48]
    6ca4:      	str	x21, [sp, #0x50]
    6ca8:      	str	x22, [sp, #0x58]
    6cac:      	sxtw	x2, w1
    6cb0:      	add	x3, x0, #0x78
    6cb4:      	add	x4, x0, #0x28
    6cb8:      	lsl	x19, x2, #2
    6cbc:      	cmp	x2, #0x0
    6cc0:      	cset	w5, gt
    6cc4:      	movz	x16, #0x0, lsl #48
    6cc8:      	sub	x6, x16, x2
    6ccc:      	sub	x7, x6, #0x1
    6cd0:      	uxtb	w16, w5
    6cd4:      	cmp	w16, wzr
    6cd8:      	b.eq	0x6d14 <_stogir.vector-arithmetic.validate+0x88>
    6cdc:      	ldr	x4, [x0, #0x8]
    6ce0:      	cmp	x2, x4
    6ce4:      	b.ge	0x6d60 <_stogir.vector-arithmetic.validate+0xd4>
    6ce8:      	ldr	x3, [x3, #0x8]
    6cec:      	cmp	x2, x3
    6cf0:      	b.ge	0x6e58 <_stogir.vector-arithmetic.validate+0x1cc>
    6cf4:      	ldr	x3, [x0, #0x78]
    6cf8:      	add	x3, x19, x3
    6cfc:      	ldr	w3, [x3]
    6d00:      	sxtw	x3, w3
    6d04:      	cmp	x3, #0x0
    6d08:      	cset	w3, ge
    6d0c:      	ubfx	x3, x3, #0, #8
    6d10:      	b	0x6e5c <_stogir.vector-arithmetic.validate+0x1d0>
    6d14:      	cmp	x2, #0x0
    6d18:      	b.ge	0x6d68 <_stogir.vector-arithmetic.validate+0xdc>
    6d1c:      	add	x3, x0, #0x50
    6d20:      	ldr	x4, [x4, #0x8]
    6d24:      	ldr	x3, [x3, #0x8]
    6d28:      	cmp	x4, x3
    6d2c:      	b.ne	0x6d58 <_stogir.vector-arithmetic.validate+0xcc>
    6d30:      	cmp	x6, x4
    6d34:      	b.gt	0x6ef0 <_stogir.vector-arithmetic.validate+0x264>
    6d38:      	ldr	x3, [x0, #0x50]
    6d3c:      	add	x3, x3, x7, lsl #2
    6d40:      	ldr	w3, [x3]
    6d44:      	sxtw	x3, w3
    6d48:      	cmp	x3, #0x0
    6d4c:      	cset	w3, gt
    6d50:      	ubfx	x3, x3, #0, #8
    6d54:      	b	0x6ef4 <_stogir.vector-arithmetic.validate+0x268>
    6d58:      	movz	x3, #0x0, lsl #48
    6d5c:      	b	0x6d6c <_stogir.vector-arithmetic.validate+0xe0>
    6d60:      	movz	x3, #0x0, lsl #48
    6d64:      	b	0x6d6c <_stogir.vector-arithmetic.validate+0xe0>
    6d68:      	movz	x3, #0x0, lsl #48
    6d6c:      	cmp	x3, #0x0
    6d70:      	b.eq	0x6dac <_stogir.vector-arithmetic.validate+0x120>
    6d74:      	uxtb	w16, w5
    6d78:      	cmp	w16, wzr
    6d7c:      	b.eq	0x6d94 <_stogir.vector-arithmetic.validate+0x108>
    6d80:      	ldr	x3, [x0]
    6d84:      	add	x3, x3, x2, lsl #4
    6d88:      	ldr	x20, [x3]
    6d8c:      	ldr	x3, [x3, #0x8]
    6d90:      	b	0x6da4 <_stogir.vector-arithmetic.validate+0x118>
    6d94:      	ldr	x3, [x0, #0x28]
    6d98:      	add	x3, x3, x7, lsl #4
    6d9c:      	ldr	x20, [x3]
    6da0:      	ldr	x3, [x3, #0x8]
    6da4:      	mov	w4, #0x1                ; =1
    6da8:      	b	0x6db8 <_stogir.vector-arithmetic.validate+0x12c>
    6dac:      	movz	w4, #0x0, lsl #16
    6db0:      	movz	x20, #0x0, lsl #48
    6db4:      	movz	x3, #0x0, lsl #48
    6db8:      	ubfx	x4, x4, #0, #32
    6dbc:      	lsr	x16, x4, #0
    6dc0:      	cmp	x16, #0x1
    6dc4:      	b.eq	0x6de0 <_stogir.vector-arithmetic.validate+0x154>
    6dc8:      	b.lo	0x6dd0 <_stogir.vector-arithmetic.validate+0x144>
    6dcc:      	b	0x6de4 <_stogir.vector-arithmetic.validate+0x158>
    6dd0:      	cmp	x16, #0x0
    6dd4:      	b.eq	0x6ddc <_stogir.vector-arithmetic.validate+0x150>
    6dd8:      	b	0x6de4 <_stogir.vector-arithmetic.validate+0x158>
    6ddc:      	b	0x6de8 <_stogir.vector-arithmetic.validate+0x15c>
    6de0:      	b	0x6e00 <_stogir.vector-arithmetic.validate+0x174>
    6de4:      	b	0x6f88 <_stogir.vector-arithmetic.validate+0x2fc>
    6de8:      	mov	x21, x8
    6dec:      	mov	x0, #0x1                ; =1
    6df0:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x498>
		0000000000006df0:  ARM64_RELOC_PAGE21	l_stogir.418
    6df4:      	ldr	x1, [x1]
		0000000000006df4:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    6df8:      	mov	x2, #0x25               ; =37
    6dfc:      	b	0x6e2c <_stogir.vector-arithmetic.validate+0x1a0>
    6e00:      	add	x16, sp, #0x10
    6e04:      	str	x20, [x16]
    6e08:      	add	x16, sp, #0x10
    6e0c:      	str	x3, [x16, #0x8]
    6e10:      	cmp	x2, #0x0
    6e14:      	b.gt	0x6e60 <_stogir.vector-arithmetic.validate+0x1d4>
    6e18:      	mov	x21, x8
    6e1c:      	mov	x0, #0x1                ; =1
    6e20:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x498>
		0000000000006e20:  ARM64_RELOC_PAGE21	l_stogir.419
    6e24:      	ldr	x1, [x1]
		0000000000006e24:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    6e28:      	mov	x2, #0x2b               ; =43
    6e2c:      	str	x0, [x21]
    6e30:      	str	x1, [x21, #0x8]
    6e34:      	str	x2, [x21, #0x10]
    6e38:      	ldr	x19, [sp, #0x40]
    6e3c:      	ldr	x20, [sp, #0x48]
    6e40:      	ldr	x21, [sp, #0x50]
    6e44:      	ldr	x22, [sp, #0x58]
    6e48:      	ldr	x29, [sp]
    6e4c:      	ldr	x30, [sp, #0x8]
    6e50:      	add	sp, sp, #0x60
    6e54:      	ret
    6e58:      	movz	x3, #0x0, lsl #48
    6e5c:      	b	0x6d64 <_stogir.vector-arithmetic.validate+0xd8>
    6e60:      	mov	x21, x8
    6e64:      	mov	x22, x0
    6e68:      	bl	0x6e68 <_stogir.vector-arithmetic.validate+0x1dc>
		0000000000006e68:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    6e6c:      	cmp	x0, #0x0
    6e70:      	b.eq	0x6e1c <_stogir.vector-arithmetic.validate+0x190>
    6e74:      	uxtb	w20, w20
    6e78:      	ldr	x0, [x22, #0x78]
    6e7c:      	orr	x1, x20, xzr
    6e80:      	cmp	x1, #0x1d
    6e84:      	cset	w2, eq
    6e88:      	cmp	x1, #0x1e
    6e8c:      	cset	w3, eq
    6e90:      	add	x0, x19, x0
    6e94:      	ldr	w0, [x0]
    6e98:      	cmp	x1, #0x1f
    6e9c:      	b.eq	0x6f3c <_stogir.vector-arithmetic.validate+0x2b0>
    6ea0:      	cmp	x1, #0x20
    6ea4:      	b.eq	0x6f3c <_stogir.vector-arithmetic.validate+0x2b0>
    6ea8:      	cmp	x1, #0x2d
    6eac:      	b.eq	0x6f3c <_stogir.vector-arithmetic.validate+0x2b0>
    6eb0:      	cmp	x1, #0x36
    6eb4:      	b.eq	0x6f3c <_stogir.vector-arithmetic.validate+0x2b0>
    6eb8:      	cmp	x1, #0x37
    6ebc:      	b.eq	0x6f3c <_stogir.vector-arithmetic.validate+0x2b0>
    6ec0:      	cmp	x1, #0x38
    6ec4:      	b.eq	0x6f3c <_stogir.vector-arithmetic.validate+0x2b0>
    6ec8:      	cmp	x1, #0x39
    6ecc:      	b.eq	0x6f3c <_stogir.vector-arithmetic.validate+0x2b0>
    6ed0:      	uxtb	w16, w2
    6ed4:      	cmp	w16, wzr
    6ed8:      	b.ne	0x6f90 <_stogir.vector-arithmetic.validate+0x304>
    6edc:      	uxtb	w16, w3
    6ee0:      	cmp	w16, wzr
    6ee4:      	b.ne	0x6f90 <_stogir.vector-arithmetic.validate+0x304>
    6ee8:      	mov	w1, #0x2                ; =2
    6eec:      	b	0x6f94 <_stogir.vector-arithmetic.validate+0x308>
    6ef0:      	movz	x3, #0x0, lsl #48
    6ef4:      	b	0x6d5c <_stogir.vector-arithmetic.validate+0xd0>
    6ef8:      	add	x16, sp, #0x10
    6efc:      	ldr	w2, [x16, #0xc]
    6f00:      	ubfx	x0, x0, #8, #8
    6f04:      	add	x8, sp, #0x20
    6f08:      	mov	w3, w1
    6f0c:      	mov	w1, w20
    6f10:      	mov	w5, w2
    6f14:      	mov	w2, w0
    6f18:      	mov	x0, x22
    6f1c:      	bl	0x6f1c <_stogir.vector-arithmetic.validate+0x290>
		0000000000006f1c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    6f20:      	add	x16, sp, #0x20
    6f24:      	ldr	x0, [x16]
    6f28:      	add	x16, sp, #0x20
    6f2c:      	ldr	x1, [x16, #0x8]
    6f30:      	add	x16, sp, #0x20
    6f34:      	ldr	x2, [x16, #0x10]
    6f38:      	b	0x6e2c <_stogir.vector-arithmetic.validate+0x1a0>
    6f3c:      	mov	w1, #0x1                ; =1
    6f40:      	sxtw	x0, w0
    6f44:      	sxtw	x1, w1
    6f48:      	cmp	x0, x1
    6f4c:      	b.ne	0x6e1c <_stogir.vector-arithmetic.validate+0x190>
    6f50:      	add	x16, sp, #0x10
    6f54:      	ldr	w0, [x16]
    6f58:      	add	x16, sp, #0x10
    6f5c:      	ldr	w1, [x16, #0x4]
    6f60:      	add	x16, sp, #0x10
    6f64:      	ldr	w4, [x16, #0x8]
    6f68:      	uxtb	w16, w2
    6f6c:      	cmp	w16, wzr
    6f70:      	b.ne	0x6ef8 <_stogir.vector-arithmetic.validate+0x26c>
    6f74:      	uxtb	w16, w3
    6f78:      	cmp	w16, wzr
    6f7c:      	b.ne	0x6ef8 <_stogir.vector-arithmetic.validate+0x26c>
    6f80:      	movz	w2, #0x0, lsl #16
    6f84:      	b	0x6f00 <_stogir.vector-arithmetic.validate+0x274>
    6f88:      	brk	#0
    6f8c:      	b	0x6f88 <_stogir.vector-arithmetic.validate+0x2fc>
    6f90:      	mov	w1, #0x3                ; =3
    6f94:      	b	0x6f40 <_stogir.vector-arithmetic.validate+0x2b4>

0000000000006f98 <_stogir.vector.memory-inputs>:
    6f98:      	sub	sp, sp, #0x40
    6f9c:      	str	x29, [sp]
    6fa0:      	str	x30, [sp, #0x8]
    6fa4:      	mov	x29, sp
    6fa8:      	str	x19, [sp, #0x10]
    6fac:      	str	x20, [sp, #0x18]
    6fb0:      	str	x21, [sp, #0x20]
    6fb4:      	str	x22, [sp, #0x28]
    6fb8:      	str	x23, [sp, #0x30]
    6fbc:      	str	x24, [sp, #0x38]
    6fc0:      	sxtw	x5, w1
    6fc4:      	cmp	x5, #0xf
    6fc8:      	b.le	0x7414 <_stogir.vector.memory-inputs+0x47c>
    6fcc:      	cmp	x5, #0x80
    6fd0:      	b.ge	0x741c <_stogir.vector.memory-inputs+0x484>
    6fd4:      	and	w5, w1, #0xf
    6fd8:      	ubfx	x5, x5, #0, #32
    6fdc:      	cmp	x5, #0x1
    6fe0:      	b.lt	0x7424 <_stogir.vector.memory-inputs+0x48c>
    6fe4:      	cmp	x5, #0xd
    6fe8:      	b.gt	0x742c <_stogir.vector.memory-inputs+0x494>
    6fec:      	mov	x19, x8
    6ff0:      	mov	x20, x0
    6ff4:      	mov	w0, w1
    6ff8:      	mov	w21, w1
    6ffc:      	mov	w1, w2
    7000:      	mov	w22, w2
    7004:      	mov	w23, w3
    7008:      	mov	w24, w4
    700c:      	bl	0x700c <_stogir.vector.memory-inputs+0x74>
		000000000000700c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    7010:      	sxtw	x0, w0
    7014:      	cmp	x0, #0x0
    7018:      	b.le	0x7084 <_stogir.vector.memory-inputs+0xec>
    701c:      	sxtw	x23, w23
    7020:      	cmp	x23, #0x0
    7024:      	cset	w0, gt
    7028:      	movz	x16, #0x0, lsl #48
    702c:      	sub	x1, x16, x23
    7030:      	add	x2, x20, #0x28
    7034:      	add	x3, x20, #0x78
    7038:      	add	x4, x20, #0x50
    703c:      	sub	x5, x1, #0x1
    7040:      	uxtb	w16, w0
    7044:      	cmp	w16, wzr
    7048:      	b.eq	0x7158 <_stogir.vector.memory-inputs+0x1c0>
    704c:      	ldr	x1, [x20, #0x8]
    7050:      	cmp	x23, x1
    7054:      	b.ge	0x7150 <_stogir.vector.memory-inputs+0x1b8>
    7058:      	ldr	x1, [x3, #0x8]
    705c:      	cmp	x23, x1
    7060:      	b.ge	0x71e8 <_stogir.vector.memory-inputs+0x250>
    7064:      	ldr	x1, [x20, #0x78]
    7068:      	add	x1, x1, x23, lsl #2
    706c:      	ldr	w1, [x1]
    7070:      	sxtw	x1, w1
    7074:      	cmp	x1, #0x0
    7078:      	cset	w1, ge
    707c:      	ubfx	x1, x1, #0, #8
    7080:      	b	0x71ec <_stogir.vector.memory-inputs+0x254>
    7084:      	mov	x1, #0x1                ; =1
    7088:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007088:  ARM64_RELOC_PAGE21	l_stogir.420
    708c:      	ldr	x0, [x0]
		000000000000708c:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    7090:      	mov	x2, #0x32               ; =50
    7094:      	str	x1, [x19]
    7098:      	str	x0, [x19, #0x8]
    709c:      	str	x2, [x19, #0x10]
    70a0:      	ldr	x19, [sp, #0x10]
    70a4:      	ldr	x20, [sp, #0x18]
    70a8:      	ldr	x21, [sp, #0x20]
    70ac:      	ldr	x22, [sp, #0x28]
    70b0:      	ldr	x23, [sp, #0x30]
    70b4:      	ldr	x24, [sp, #0x38]
    70b8:      	ldr	x29, [sp]
    70bc:      	ldr	x30, [sp, #0x8]
    70c0:      	add	sp, sp, #0x40
    70c4:      	ret
    70c8:      	movz	w1, #0x0, lsl #16
    70cc:      	movz	x0, #0x0, lsl #48
    70d0:      	ubfx	x1, x1, #0, #32
    70d4:      	lsr	x16, x1, #0
    70d8:      	cmp	x16, #0x1
    70dc:      	b.eq	0x70f8 <_stogir.vector.memory-inputs+0x160>
    70e0:      	b.lo	0x70e8 <_stogir.vector.memory-inputs+0x150>
    70e4:      	b	0x70fc <_stogir.vector.memory-inputs+0x164>
    70e8:      	cmp	x16, #0x0
    70ec:      	b.eq	0x70f4 <_stogir.vector.memory-inputs+0x15c>
    70f0:      	b	0x70fc <_stogir.vector.memory-inputs+0x164>
    70f4:      	b	0x7100 <_stogir.vector.memory-inputs+0x168>
    70f8:      	b	0x7198 <_stogir.vector.memory-inputs+0x200>
    70fc:      	b	0x73fc <_stogir.vector.memory-inputs+0x464>
    7100:      	mov	x1, #0x1                ; =1
    7104:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007104:  ARM64_RELOC_PAGE21	l_stogir.421
    7108:      	ldr	x0, [x0]
		0000000000007108:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    710c:      	mov	x2, #0x1d               ; =29
    7110:      	b	0x7094 <_stogir.vector.memory-inputs+0xfc>
    7114:      	ldr	x0, [x20, #0x28]
    7118:      	add	x0, x0, x5, lsl #4
    711c:      	ldr	x0, [x0]
    7120:      	mov	w1, #0x1                ; =1
    7124:      	b	0x70d0 <_stogir.vector.memory-inputs+0x138>
    7128:      	movz	x1, #0x0, lsl #48
    712c:      	cmp	x1, #0x0
    7130:      	b.eq	0x70c8 <_stogir.vector.memory-inputs+0x130>
    7134:      	uxtb	w16, w0
    7138:      	cmp	w16, wzr
    713c:      	b.eq	0x7114 <_stogir.vector.memory-inputs+0x17c>
    7140:      	ldr	x0, [x20]
    7144:      	add	x0, x0, x23, lsl #4
    7148:      	ldr	x0, [x0]
    714c:      	b	0x7120 <_stogir.vector.memory-inputs+0x188>
    7150:      	movz	x1, #0x0, lsl #48
    7154:      	b	0x712c <_stogir.vector.memory-inputs+0x194>
    7158:      	cmp	x23, #0x0
    715c:      	b.ge	0x7128 <_stogir.vector.memory-inputs+0x190>
    7160:      	ldr	x6, [x2, #0x8]
    7164:      	ldr	x7, [x4, #0x8]
    7168:      	cmp	x6, x7
    716c:      	b.ne	0x71e0 <_stogir.vector.memory-inputs+0x248>
    7170:      	cmp	x1, x6
    7174:      	b.gt	0x71f0 <_stogir.vector.memory-inputs+0x258>
    7178:      	ldr	x1, [x20, #0x50]
    717c:      	add	x1, x1, x5, lsl #2
    7180:      	ldr	w1, [x1]
    7184:      	sxtw	x1, w1
    7188:      	cmp	x1, #0x0
    718c:      	cset	w1, gt
    7190:      	ubfx	x1, x1, #0, #8
    7194:      	b	0x71f4 <_stogir.vector.memory-inputs+0x25c>
    7198:      	cmp	x23, #0x0
    719c:      	b.le	0x71cc <_stogir.vector.memory-inputs+0x234>
    71a0:      	uxtb	w0, w0
    71a4:      	cmp	x0, #0x83
    71a8:      	cset	w1, lt
    71ac:      	uxtb	w16, w1
    71b0:      	cmp	w16, wzr
    71b4:      	b.eq	0x71f8 <_stogir.vector.memory-inputs+0x260>
    71b8:      	adrp	x17, 0x7000 <_stogir.vector.memory-inputs+0x68>
		00000000000071b8:  ARM64_RELOC_PAGE21	l_stogir.422
    71bc:      	ldr	x17, [x17]
		00000000000071bc:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    71c0:      	add	x5, x0, x17
    71c4:      	ldrb	w5, [x5]
    71c8:      	b	0x71fc <_stogir.vector.memory-inputs+0x264>
    71cc:      	mov	x1, #0x1                ; =1
    71d0:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x68>
		00000000000071d0:  ARM64_RELOC_PAGE21	l_stogir.423
    71d4:      	ldr	x0, [x0]
		00000000000071d4:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    71d8:      	mov	x2, #0x2c               ; =44
    71dc:      	b	0x7110 <_stogir.vector.memory-inputs+0x178>
    71e0:      	movz	x1, #0x0, lsl #48
    71e4:      	b	0x712c <_stogir.vector.memory-inputs+0x194>
    71e8:      	movz	x1, #0x0, lsl #48
    71ec:      	b	0x7154 <_stogir.vector.memory-inputs+0x1bc>
    71f0:      	movz	x1, #0x0, lsl #48
    71f4:      	b	0x71e4 <_stogir.vector.memory-inputs+0x24c>
    71f8:      	movz	w5, #0x0, lsl #16
    71fc:      	uxtb	w16, w5
    7200:      	and	w5, w16, #0x1
    7204:      	uxtb	w5, w5
    7208:      	ubfx	x5, x5, #0, #8
    720c:      	cmp	x5, #0x0
    7210:      	b.eq	0x71cc <_stogir.vector.memory-inputs+0x234>
    7214:      	uxtb	w16, w1
    7218:      	cmp	w16, wzr
    721c:      	b.eq	0x7234 <_stogir.vector.memory-inputs+0x29c>
    7220:      	adrp	x17, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007220:  ARM64_RELOC_PAGE21	l_stogir.422
    7224:      	ldr	x17, [x17]
		0000000000007224:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    7228:      	add	x0, x0, x17
    722c:      	ldrb	w0, [x0]
    7230:      	b	0x7238 <_stogir.vector.memory-inputs+0x2a0>
    7234:      	movz	w0, #0x0, lsl #16
    7238:      	uxtb	w16, w0
    723c:      	and	w0, w16, #0x4
    7240:      	uxtb	w0, w0
    7244:      	ubfx	x0, x0, #0, #8
    7248:      	cmp	x0, #0x0
    724c:      	cset	w0, eq
    7250:      	uxtb	w16, w0
    7254:      	cmp	w16, wzr
    7258:      	cset	x0, eq
    725c:      	cmp	x0, #0x0
    7260:      	b.ne	0x71cc <_stogir.vector.memory-inputs+0x234>
    7264:      	sxtw	x24, w24
    7268:      	cmp	x24, #0x0
    726c:      	cset	w0, gt
    7270:      	movz	x16, #0x0, lsl #48
    7274:      	sub	x1, x16, x24
    7278:      	sub	x5, x1, #0x1
    727c:      	uxtb	w16, w0
    7280:      	cmp	w16, wzr
    7284:      	b.eq	0x72d4 <_stogir.vector.memory-inputs+0x33c>
    7288:      	ldr	x1, [x20, #0x8]
    728c:      	cmp	x24, x1
    7290:      	b.ge	0x7314 <_stogir.vector.memory-inputs+0x37c>
    7294:      	ldr	x1, [x3, #0x8]
    7298:      	cmp	x24, x1
    729c:      	b.ge	0x73f4 <_stogir.vector.memory-inputs+0x45c>
    72a0:      	ldr	x1, [x20, #0x78]
    72a4:      	add	x1, x1, x24, lsl #2
    72a8:      	ldr	w1, [x1]
    72ac:      	sxtw	x1, w1
    72b0:      	cmp	x1, #0x0
    72b4:      	cset	w1, ge
    72b8:      	ubfx	x1, x1, #0, #8
    72bc:      	b	0x73f8 <_stogir.vector.memory-inputs+0x460>
    72c0:      	mov	x1, #0x1                ; =1
    72c4:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x68>
		00000000000072c4:  ARM64_RELOC_PAGE21	l_stogir.424
    72c8:      	ldr	x0, [x0]
		00000000000072c8:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    72cc:      	mov	x2, #0x2b               ; =43
    72d0:      	b	0x71dc <_stogir.vector.memory-inputs+0x244>
    72d4:      	cmp	x24, #0x0
    72d8:      	b.ge	0x731c <_stogir.vector.memory-inputs+0x384>
    72dc:      	ldr	x2, [x2, #0x8]
    72e0:      	ldr	x3, [x4, #0x8]
    72e4:      	cmp	x2, x3
    72e8:      	b.ne	0x73ec <_stogir.vector.memory-inputs+0x454>
    72ec:      	cmp	x1, x2
    72f0:      	b.gt	0x7404 <_stogir.vector.memory-inputs+0x46c>
    72f4:      	ldr	x1, [x20, #0x50]
    72f8:      	add	x1, x1, x5, lsl #2
    72fc:      	ldr	w1, [x1]
    7300:      	sxtw	x1, w1
    7304:      	cmp	x1, #0x0
    7308:      	cset	w1, gt
    730c:      	ubfx	x1, x1, #0, #8
    7310:      	b	0x7408 <_stogir.vector.memory-inputs+0x470>
    7314:      	movz	x1, #0x0, lsl #48
    7318:      	b	0x7320 <_stogir.vector.memory-inputs+0x388>
    731c:      	movz	x1, #0x0, lsl #48
    7320:      	cmp	x1, #0x0
    7324:      	b.eq	0x7358 <_stogir.vector.memory-inputs+0x3c0>
    7328:      	uxtb	w16, w0
    732c:      	cmp	w16, wzr
    7330:      	b.eq	0x7344 <_stogir.vector.memory-inputs+0x3ac>
    7334:      	ldr	x0, [x20]
    7338:      	add	x0, x0, x24, lsl #4
    733c:      	ldr	x0, [x0]
    7340:      	b	0x7350 <_stogir.vector.memory-inputs+0x3b8>
    7344:      	ldr	x0, [x20, #0x28]
    7348:      	add	x0, x0, x5, lsl #4
    734c:      	ldr	x0, [x0]
    7350:      	mov	w1, #0x1                ; =1
    7354:      	b	0x7360 <_stogir.vector.memory-inputs+0x3c8>
    7358:      	movz	w1, #0x0, lsl #16
    735c:      	movz	x0, #0x0, lsl #48
    7360:      	ubfx	x1, x1, #0, #32
    7364:      	lsr	x16, x1, #0
    7368:      	cmp	x16, #0x1
    736c:      	b.eq	0x7388 <_stogir.vector.memory-inputs+0x3f0>
    7370:      	b.lo	0x7378 <_stogir.vector.memory-inputs+0x3e0>
    7374:      	b	0x738c <_stogir.vector.memory-inputs+0x3f4>
    7378:      	cmp	x16, #0x0
    737c:      	b.eq	0x7384 <_stogir.vector.memory-inputs+0x3ec>
    7380:      	b	0x738c <_stogir.vector.memory-inputs+0x3f4>
    7384:      	b	0x7390 <_stogir.vector.memory-inputs+0x3f8>
    7388:      	b	0x73a4 <_stogir.vector.memory-inputs+0x40c>
    738c:      	b	0x740c <_stogir.vector.memory-inputs+0x474>
    7390:      	mov	x1, #0x1                ; =1
    7394:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007394:  ARM64_RELOC_PAGE21	l_stogir.425
    7398:      	ldr	x0, [x0]
		0000000000007398:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    739c:      	mov	x2, #0x1d               ; =29
    73a0:      	b	0x72d0 <_stogir.vector.memory-inputs+0x338>
    73a4:      	orr	w1, w0, wzr
    73a8:      	ubfx	x1, x1, #0, #32
    73ac:      	ubfx	x1, x1, #8, #8
    73b0:      	cmp	x1, #0x6
    73b4:      	b.ne	0x72c0 <_stogir.vector.memory-inputs+0x328>
    73b8:      	uxtb	w0, w0
    73bc:      	cmp	x0, #0x48
    73c0:      	b.eq	0x72c0 <_stogir.vector.memory-inputs+0x328>
    73c4:      	cmp	x0, #0x46
    73c8:      	b.eq	0x72c0 <_stogir.vector.memory-inputs+0x328>
    73cc:      	mov	w0, w21
    73d0:      	mov	w1, w22
    73d4:      	bl	0x73d4 <_stogir.vector.memory-inputs+0x43c>
		00000000000073d4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    73d8:      	sxtw	x0, w0
    73dc:      	and	x0, x0, #0xffffffff
    73e0:      	movz	x1, #0x0, lsl #48
    73e4:      	movz	x2, #0x0, lsl #48
    73e8:      	b	0x72d0 <_stogir.vector.memory-inputs+0x338>
    73ec:      	movz	x1, #0x0, lsl #48
    73f0:      	b	0x7320 <_stogir.vector.memory-inputs+0x388>
    73f4:      	movz	x1, #0x0, lsl #48
    73f8:      	b	0x7318 <_stogir.vector.memory-inputs+0x380>
    73fc:      	brk	#0
    7400:      	b	0x73fc <_stogir.vector.memory-inputs+0x464>
    7404:      	movz	x1, #0x0, lsl #48
    7408:      	b	0x73f0 <_stogir.vector.memory-inputs+0x458>
    740c:      	brk	#0
    7410:      	b	0x740c <_stogir.vector.memory-inputs+0x474>
    7414:      	mov	x19, x8
    7418:      	b	0x7084 <_stogir.vector.memory-inputs+0xec>
    741c:      	mov	x19, x8
    7420:      	b	0x7084 <_stogir.vector.memory-inputs+0xec>
    7424:      	mov	x19, x8
    7428:      	b	0x7084 <_stogir.vector.memory-inputs+0xec>
    742c:      	mov	x19, x8
    7430:      	b	0x7084 <_stogir.vector.memory-inputs+0xec>

0000000000007434 <_stogir.vector.store-inputs>:
    7434:      	sub	sp, sp, #0x40
    7438:      	str	x29, [sp]
    743c:      	str	x30, [sp, #0x8]
    7440:      	mov	x29, sp
    7444:      	str	x19, [sp, #0x30]
    7448:      	sxtw	x4, w4
    744c:      	add	x5, x0, #0x28
    7450:      	cmp	x4, #0x0
    7454:      	cset	w6, gt
    7458:      	movz	x16, #0x0, lsl #48
    745c:      	sub	x7, x16, x4
    7460:      	sub	x9, x7, #0x1
    7464:      	uxtb	w16, w6
    7468:      	cmp	w16, wzr
    746c:      	b.eq	0x74ac <_stogir.vector.store-inputs+0x78>
    7470:      	ldr	x5, [x0, #0x8]
    7474:      	cmp	x4, x5
    7478:      	b.ge	0x74f8 <_stogir.vector.store-inputs+0xc4>
    747c:      	add	x5, x0, #0x78
    7480:      	ldr	x5, [x5, #0x8]
    7484:      	cmp	x4, x5
    7488:      	b.ge	0x75ec <_stogir.vector.store-inputs+0x1b8>
    748c:      	ldr	x5, [x0, #0x78]
    7490:      	add	x5, x5, x4, lsl #2
    7494:      	ldr	w5, [x5]
    7498:      	sxtw	x5, w5
    749c:      	cmp	x5, #0x0
    74a0:      	cset	w5, ge
    74a4:      	ubfx	x5, x5, #0, #8
    74a8:      	b	0x75f0 <_stogir.vector.store-inputs+0x1bc>
    74ac:      	cmp	x4, #0x0
    74b0:      	b.ge	0x7500 <_stogir.vector.store-inputs+0xcc>
    74b4:      	add	x10, x0, #0x50
    74b8:      	ldr	x5, [x5, #0x8]
    74bc:      	ldr	x10, [x10, #0x8]
    74c0:      	cmp	x5, x10
    74c4:      	b.ne	0x74f0 <_stogir.vector.store-inputs+0xbc>
    74c8:      	cmp	x7, x5
    74cc:      	b.gt	0x75f4 <_stogir.vector.store-inputs+0x1c0>
    74d0:      	ldr	x5, [x0, #0x50]
    74d4:      	add	x5, x5, x9, lsl #2
    74d8:      	ldr	w5, [x5]
    74dc:      	sxtw	x5, w5
    74e0:      	cmp	x5, #0x0
    74e4:      	cset	w5, gt
    74e8:      	ubfx	x5, x5, #0, #8
    74ec:      	b	0x75f8 <_stogir.vector.store-inputs+0x1c4>
    74f0:      	movz	x5, #0x0, lsl #48
    74f4:      	b	0x7504 <_stogir.vector.store-inputs+0xd0>
    74f8:      	movz	x5, #0x0, lsl #48
    74fc:      	b	0x7504 <_stogir.vector.store-inputs+0xd0>
    7500:      	movz	x5, #0x0, lsl #48
    7504:      	cmp	x5, #0x0
    7508:      	b.eq	0x753c <_stogir.vector.store-inputs+0x108>
    750c:      	uxtb	w16, w6
    7510:      	cmp	w16, wzr
    7514:      	b.eq	0x7528 <_stogir.vector.store-inputs+0xf4>
    7518:      	ldr	x5, [x0]
    751c:      	add	x4, x5, x4, lsl #4
    7520:      	ldr	x4, [x4]
    7524:      	b	0x7534 <_stogir.vector.store-inputs+0x100>
    7528:      	ldr	x4, [x0, #0x28]
    752c:      	add	x4, x4, x9, lsl #4
    7530:      	ldr	x4, [x4]
    7534:      	mov	w5, #0x1                ; =1
    7538:      	b	0x7544 <_stogir.vector.store-inputs+0x110>
    753c:      	movz	w5, #0x0, lsl #16
    7540:      	movz	x4, #0x0, lsl #48
    7544:      	ubfx	x5, x5, #0, #32
    7548:      	lsr	x16, x5, #0
    754c:      	cmp	x16, #0x1
    7550:      	b.eq	0x756c <_stogir.vector.store-inputs+0x138>
    7554:      	b.lo	0x755c <_stogir.vector.store-inputs+0x128>
    7558:      	b	0x7570 <_stogir.vector.store-inputs+0x13c>
    755c:      	cmp	x16, #0x0
    7560:      	b.eq	0x7568 <_stogir.vector.store-inputs+0x134>
    7564:      	b	0x7570 <_stogir.vector.store-inputs+0x13c>
    7568:      	b	0x7574 <_stogir.vector.store-inputs+0x140>
    756c:      	b	0x758c <_stogir.vector.store-inputs+0x158>
    7570:      	b	0x75fc <_stogir.vector.store-inputs+0x1c8>
    7574:      	mov	x19, x8
    7578:      	mov	x0, #0x1                ; =1
    757c:      	adrp	x1, 0x7000 <_stogir.vector.memory-inputs+0x68>
		000000000000757c:  ARM64_RELOC_PAGE21	l_stogir.426
    7580:      	ldr	x1, [x1]
		0000000000007580:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    7584:      	mov	x2, #0x1a               ; =26
    7588:      	b	0x75cc <_stogir.vector.store-inputs+0x198>
    758c:      	ubfx	x4, x4, #0, #32
    7590:      	ubfx	x4, x4, #8, #8
    7594:      	mov	x19, x8
    7598:      	add	x8, sp, #0x10
    759c:      	fmov	s31, w1
    75a0:      	mov	w1, w4
    75a4:      	mov	w4, w3
    75a8:      	mov	w3, w2
    75ac:      	fmov	w2, s31
    75b0:      	bl	0x75b0 <_stogir.vector.store-inputs+0x17c>
		00000000000075b0:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    75b4:      	add	x16, sp, #0x10
    75b8:      	ldr	x0, [x16]
    75bc:      	add	x16, sp, #0x10
    75c0:      	ldr	x1, [x16, #0x8]
    75c4:      	add	x16, sp, #0x10
    75c8:      	ldr	x2, [x16, #0x10]
    75cc:      	str	x0, [x19]
    75d0:      	str	x1, [x19, #0x8]
    75d4:      	str	x2, [x19, #0x10]
    75d8:      	ldr	x19, [sp, #0x30]
    75dc:      	ldr	x29, [sp]
    75e0:      	ldr	x30, [sp, #0x8]
    75e4:      	add	sp, sp, #0x40
    75e8:      	ret
    75ec:      	movz	x5, #0x0, lsl #48
    75f0:      	b	0x74fc <_stogir.vector.store-inputs+0xc8>
    75f4:      	movz	x5, #0x0, lsl #48
    75f8:      	b	0x74f4 <_stogir.vector.store-inputs+0xc0>
    75fc:      	brk	#0
    7600:      	b	0x75fc <_stogir.vector.store-inputs+0x1c8>

0000000000007604 <_stogir.types.size>:
    7604:      	sxtw	x2, w0
    7608:      	sxtw	x3, w1
    760c:      	cmp	x2, #0xf
    7610:      	cset	w4, gt
    7614:      	cmp	x2, #0x0
    7618:      	cset	w5, eq
    761c:      	cmp	x3, #0x4
    7620:      	cset	w6, eq
    7624:      	cmp	x3, #0x8
    7628:      	cset	w7, eq
    762c:      	uxtb	w16, w4
    7630:      	cmp	w16, wzr
    7634:      	b.eq	0x76f8 <_stogir.types.size+0xf4>
    7638:      	cmp	x2, #0x80
    763c:      	cset	w8, lt
    7640:      	uxtb	w16, w8
    7644:      	cmp	w16, wzr
    7648:      	b.eq	0x76f8 <_stogir.types.size+0xf4>
    764c:      	and	w0, w0, #0xf
    7650:      	ubfx	x9, x0, #0, #32
    7654:      	cmp	x9, #0x1
    7658:      	cset	w10, ge
    765c:      	uxtb	w16, w10
    7660:      	cmp	w16, wzr
    7664:      	b.eq	0x76f8 <_stogir.types.size+0xf4>
    7668:      	cmp	x9, #0xd
    766c:      	cset	w9, le
    7670:      	uxtb	w16, w9
    7674:      	cmp	w16, wzr
    7678:      	b.eq	0x76f8 <_stogir.types.size+0xf4>
    767c:      	cmp	x2, #0x0
    7680:      	cset	w3, ge
    7684:      	cmp	x2, #0xd
    7688:      	cset	w11, le
    768c:      	uxtb	w16, w3
    7690:      	cmp	w16, wzr
    7694:      	b.eq	0x76a4 <_stogir.types.size+0xa0>
    7698:      	uxtb	w16, w11
    769c:      	cmp	w16, wzr
    76a0:      	b.ne	0x76d8 <_stogir.types.size+0xd4>
    76a4:      	uxtb	w16, w4
    76a8:      	cmp	w16, wzr
    76ac:      	b.eq	0x76d4 <_stogir.types.size+0xd0>
    76b0:      	uxtb	w16, w8
    76b4:      	cmp	w16, wzr
    76b8:      	b.eq	0x76d4 <_stogir.types.size+0xd0>
    76bc:      	uxtb	w16, w10
    76c0:      	cmp	w16, wzr
    76c4:      	b.eq	0x76d4 <_stogir.types.size+0xd0>
    76c8:      	uxtb	w16, w9
    76cc:      	cmp	w16, wzr
    76d0:      	b.ne	0x76d8 <_stogir.types.size+0xd4>
    76d4:      	movn	w0, #0x0, lsl #16
    76d8:      	uxtb	w16, w6
    76dc:      	cmp	w16, wzr
    76e0:      	b.ne	0x7818 <_stogir.types.size+0x214>
    76e4:      	uxtb	w16, w7
    76e8:      	cmp	w16, wzr
    76ec:      	b.ne	0x7818 <_stogir.types.size+0x214>
    76f0:      	movn	w1, #0x0, lsl #16
    76f4:      	b	0x77ac <_stogir.types.size+0x1a8>
    76f8:      	uxtb	w16, w6
    76fc:      	cmp	w16, wzr
    7700:      	b.ne	0x7718 <_stogir.types.size+0x114>
    7704:      	uxtb	w16, w7
    7708:      	cmp	w16, wzr
    770c:      	b.ne	0x7718 <_stogir.types.size+0x114>
    7710:      	movn	x3, #0x0, lsl #48
    7714:      	b	0x7730 <_stogir.types.size+0x12c>
    7718:      	uxtb	w16, w5
    771c:      	cmp	w16, wzr
    7720:      	b.eq	0x7738 <_stogir.types.size+0x134>
    7724:      	movz	x3, #0x0, lsl #48
    7728:      	b	0x7730 <_stogir.types.size+0x12c>
    772c:      	mov	x3, #0x1                ; =1
    7730:      	mov	x0, x3
    7734:      	ret
    7738:      	cmp	x2, #0x1
    773c:      	b.eq	0x772c <_stogir.types.size+0x128>
    7740:      	cmp	x2, #0x2
    7744:      	b.eq	0x772c <_stogir.types.size+0x128>
    7748:      	cmp	x2, #0x7
    774c:      	b.eq	0x772c <_stogir.types.size+0x128>
    7750:      	cmp	x2, #0x8
    7754:      	b.eq	0x772c <_stogir.types.size+0x128>
    7758:      	cmp	x2, #0x3
    775c:      	b.eq	0x789c <_stogir.types.size+0x298>
    7760:      	cmp	x2, #0x9
    7764:      	b.eq	0x789c <_stogir.types.size+0x298>
    7768:      	cmp	x2, #0x4
    776c:      	b.eq	0x78cc <_stogir.types.size+0x2c8>
    7770:      	cmp	x2, #0xa
    7774:      	b.eq	0x78cc <_stogir.types.size+0x2c8>
    7778:      	cmp	x2, #0xd
    777c:      	b.eq	0x78cc <_stogir.types.size+0x2c8>
    7780:      	cmp	x2, #0x5
    7784:      	b.eq	0x78dc <_stogir.types.size+0x2d8>
    7788:      	cmp	x2, #0xb
    778c:      	b.eq	0x78dc <_stogir.types.size+0x2d8>
    7790:      	cmp	x2, #0xc
    7794:      	b.eq	0x78dc <_stogir.types.size+0x2d8>
    7798:      	cmp	x2, #0x6
    779c:      	b.eq	0x77a4 <_stogir.types.size+0x1a0>
    77a0:      	movn	x3, #0x0, lsl #48
    77a4:      	b	0x78e0 <_stogir.types.size+0x2dc>
    77a8:      	mov	w1, #0x1                ; =1
    77ac:      	sxtw	x0, w1
    77b0:      	cmp	x0, #0x0
    77b4:      	b.ge	0x77c0 <_stogir.types.size+0x1bc>
    77b8:      	movn	x3, #0x0, lsl #48
    77bc:      	b	0x7730 <_stogir.types.size+0x12c>
    77c0:      	uxtb	w16, w4
    77c4:      	cmp	w16, wzr
    77c8:      	b.eq	0x78a4 <_stogir.types.size+0x2a0>
    77cc:      	uxtb	w16, w8
    77d0:      	cmp	w16, wzr
    77d4:      	b.eq	0x78a4 <_stogir.types.size+0x2a0>
    77d8:      	uxtb	w16, w10
    77dc:      	cmp	w16, wzr
    77e0:      	b.eq	0x78a4 <_stogir.types.size+0x2a0>
    77e4:      	uxtb	w16, w9
    77e8:      	cmp	w16, wzr
    77ec:      	b.eq	0x78a4 <_stogir.types.size+0x2a0>
    77f0:      	ubfx	x0, x2, #4, #32
    77f4:      	sub	w0, w0, #0x1
    77f8:      	sxtw	x0, w0
    77fc:      	mov	x16, #0x1               ; =1
    7800:      	lsl	x0, x16, x0
    7804:      	b	0x780c <_stogir.types.size+0x208>
    7808:      	movn	w0, #0x0, lsl #16
    780c:      	mul	w0, w0, w1
    7810:      	sxtw	x3, w0
    7814:      	b	0x77bc <_stogir.types.size+0x1b8>
    7818:      	sxtw	x0, w0
    781c:      	cmp	x0, #0x0
    7820:      	b.ne	0x782c <_stogir.types.size+0x228>
    7824:      	movz	w1, #0x0, lsl #16
    7828:      	b	0x77ac <_stogir.types.size+0x1a8>
    782c:      	cmp	x0, #0x1
    7830:      	b.eq	0x77a8 <_stogir.types.size+0x1a4>
    7834:      	cmp	x0, #0x2
    7838:      	b.eq	0x77a8 <_stogir.types.size+0x1a4>
    783c:      	cmp	x0, #0x7
    7840:      	b.eq	0x77a8 <_stogir.types.size+0x1a4>
    7844:      	cmp	x0, #0x8
    7848:      	b.eq	0x77a8 <_stogir.types.size+0x1a4>
    784c:      	cmp	x0, #0x3
    7850:      	b.eq	0x78d4 <_stogir.types.size+0x2d0>
    7854:      	cmp	x0, #0x9
    7858:      	b.eq	0x78d4 <_stogir.types.size+0x2d0>
    785c:      	cmp	x0, #0x4
    7860:      	b.eq	0x78e4 <_stogir.types.size+0x2e0>
    7864:      	cmp	x0, #0xa
    7868:      	b.eq	0x78e4 <_stogir.types.size+0x2e0>
    786c:      	cmp	x0, #0xd
    7870:      	b.eq	0x78e4 <_stogir.types.size+0x2e0>
    7874:      	cmp	x0, #0x5
    7878:      	b.eq	0x78ec <_stogir.types.size+0x2e8>
    787c:      	cmp	x0, #0xb
    7880:      	b.eq	0x78ec <_stogir.types.size+0x2e8>
    7884:      	cmp	x0, #0xc
    7888:      	b.eq	0x78ec <_stogir.types.size+0x2e8>
    788c:      	cmp	x0, #0x6
    7890:      	b.eq	0x7898 <_stogir.types.size+0x294>
    7894:      	movn	w1, #0x0, lsl #16
    7898:      	b	0x78f0 <_stogir.types.size+0x2ec>
    789c:      	mov	x3, #0x2                ; =2
    78a0:      	b	0x7730 <_stogir.types.size+0x12c>
    78a4:      	uxtb	w16, w3
    78a8:      	cmp	w16, wzr
    78ac:      	b.eq	0x7808 <_stogir.types.size+0x204>
    78b0:      	uxtb	w16, w11
    78b4:      	cmp	w16, wzr
    78b8:      	b.eq	0x7808 <_stogir.types.size+0x204>
    78bc:      	uxtb	w16, w5
    78c0:      	cmp	w16, wzr
    78c4:      	cset	w0, eq
    78c8:      	b	0x780c <_stogir.types.size+0x208>
    78cc:      	mov	x3, #0x4                ; =4
    78d0:      	b	0x78a0 <_stogir.types.size+0x29c>
    78d4:      	mov	w1, #0x2                ; =2
    78d8:      	b	0x77ac <_stogir.types.size+0x1a8>
    78dc:      	mov	x3, #0x8                ; =8
    78e0:      	b	0x78d0 <_stogir.types.size+0x2cc>
    78e4:      	mov	w1, #0x4                ; =4
    78e8:      	b	0x78d8 <_stogir.types.size+0x2d4>
    78ec:      	mov	w1, #0x8                ; =8
    78f0:      	b	0x78e8 <_stogir.types.size+0x2e4>

00000000000078f4 <_stogir.checked.projection>:
    78f4:      	sub	sp, sp, #0x40
    78f8:      	str	x29, [sp]
    78fc:      	str	x30, [sp, #0x8]
    7900:      	mov	x29, sp
    7904:      	str	x19, [sp, #0x30]
    7908:      	sxtw	x2, w1
    790c:      	add	x3, x0, #0x28
    7910:      	cmp	x2, #0x0
    7914:      	cset	w4, gt
    7918:      	movz	x16, #0x0, lsl #48
    791c:      	sub	x5, x16, x2
    7920:      	sub	x6, x5, #0x1
    7924:      	uxtb	w16, w4
    7928:      	cmp	w16, wzr
    792c:      	b.eq	0x796c <_stogir.checked.projection+0x78>
    7930:      	ldr	x3, [x0, #0x8]
    7934:      	cmp	x2, x3
    7938:      	b.ge	0x79b8 <_stogir.checked.projection+0xc4>
    793c:      	add	x3, x0, #0x78
    7940:      	ldr	x3, [x3, #0x8]
    7944:      	cmp	x2, x3
    7948:      	b.ge	0x7ab8 <_stogir.checked.projection+0x1c4>
    794c:      	ldr	x3, [x0, #0x78]
    7950:      	add	x3, x3, x2, lsl #2
    7954:      	ldr	w3, [x3]
    7958:      	sxtw	x3, w3
    795c:      	cmp	x3, #0x0
    7960:      	cset	w3, ge
    7964:      	ubfx	x3, x3, #0, #8
    7968:      	b	0x7abc <_stogir.checked.projection+0x1c8>
    796c:      	cmp	x2, #0x0
    7970:      	b.ge	0x79c0 <_stogir.checked.projection+0xcc>
    7974:      	add	x7, x0, #0x50
    7978:      	ldr	x3, [x3, #0x8]
    797c:      	ldr	x7, [x7, #0x8]
    7980:      	cmp	x3, x7
    7984:      	b.ne	0x79b0 <_stogir.checked.projection+0xbc>
    7988:      	cmp	x5, x3
    798c:      	b.gt	0x7ae8 <_stogir.checked.projection+0x1f4>
    7990:      	ldr	x3, [x0, #0x50]
    7994:      	add	x3, x3, x6, lsl #2
    7998:      	ldr	w3, [x3]
    799c:      	sxtw	x3, w3
    79a0:      	cmp	x3, #0x0
    79a4:      	cset	w3, gt
    79a8:      	ubfx	x3, x3, #0, #8
    79ac:      	b	0x7aec <_stogir.checked.projection+0x1f8>
    79b0:      	movz	x3, #0x0, lsl #48
    79b4:      	b	0x79c4 <_stogir.checked.projection+0xd0>
    79b8:      	movz	x3, #0x0, lsl #48
    79bc:      	b	0x79c4 <_stogir.checked.projection+0xd0>
    79c0:      	movz	x3, #0x0, lsl #48
    79c4:      	cmp	x3, #0x0
    79c8:      	b.eq	0x79fc <_stogir.checked.projection+0x108>
    79cc:      	uxtb	w16, w4
    79d0:      	cmp	w16, wzr
    79d4:      	b.eq	0x79e8 <_stogir.checked.projection+0xf4>
    79d8:      	ldr	x3, [x0]
    79dc:      	add	x2, x3, x2, lsl #4
    79e0:      	ldr	x2, [x2]
    79e4:      	b	0x79f4 <_stogir.checked.projection+0x100>
    79e8:      	ldr	x2, [x0, #0x28]
    79ec:      	add	x2, x2, x6, lsl #4
    79f0:      	ldr	x2, [x2]
    79f4:      	mov	w3, #0x1                ; =1
    79f8:      	b	0x7a04 <_stogir.checked.projection+0x110>
    79fc:      	movz	w3, #0x0, lsl #16
    7a00:      	movz	x2, #0x0, lsl #48
    7a04:      	ubfx	x3, x3, #0, #32
    7a08:      	lsr	x16, x3, #0
    7a0c:      	cmp	x16, #0x1
    7a10:      	b.eq	0x7a2c <_stogir.checked.projection+0x138>
    7a14:      	b.lo	0x7a1c <_stogir.checked.projection+0x128>
    7a18:      	b	0x7a30 <_stogir.checked.projection+0x13c>
    7a1c:      	cmp	x16, #0x0
    7a20:      	b.eq	0x7a28 <_stogir.checked.projection+0x134>
    7a24:      	b	0x7a30 <_stogir.checked.projection+0x13c>
    7a28:      	b	0x7a34 <_stogir.checked.projection+0x140>
    7a2c:      	b	0x7a7c <_stogir.checked.projection+0x188>
    7a30:      	b	0x7af0 <_stogir.checked.projection+0x1fc>
    7a34:      	mov	x19, x8
    7a38:      	mov	x0, #0x1                ; =1
    7a3c:      	adrp	x1, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007a3c:  ARM64_RELOC_PAGE21	l_stogir.427
    7a40:      	ldr	x1, [x1]
		0000000000007a40:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    7a44:      	mov	x2, #0x17               ; =23
    7a48:      	b	0x7a5c <_stogir.checked.projection+0x168>
    7a4c:      	mov	x0, #0x1                ; =1
    7a50:      	adrp	x1, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007a50:  ARM64_RELOC_PAGE21	l_stogir.428
    7a54:      	ldr	x1, [x1]
		0000000000007a54:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    7a58:      	mov	x2, #0x20               ; =32
    7a5c:      	str	x0, [x19]
    7a60:      	str	x1, [x19, #0x8]
    7a64:      	str	x2, [x19, #0x10]
    7a68:      	ldr	x19, [sp, #0x30]
    7a6c:      	ldr	x29, [sp]
    7a70:      	ldr	x30, [sp, #0x8]
    7a74:      	add	sp, sp, #0x40
    7a78:      	ret
    7a7c:      	uxtb	w3, w2
    7a80:      	cmp	x3, #0x29
    7a84:      	b.lt	0x7af8 <_stogir.checked.projection+0x204>
    7a88:      	cmp	x3, #0x2b
    7a8c:      	b.gt	0x7b00 <_stogir.checked.projection+0x20c>
    7a90:      	mov	x19, x8
    7a94:      	add	x8, sp, #0x10
    7a98:      	bl	0x7a98 <_stogir.checked.projection+0x1a4>
		0000000000007a98:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    7a9c:      	add	x16, sp, #0x10
    7aa0:      	ldr	x0, [x16]
    7aa4:      	add	x16, sp, #0x10
    7aa8:      	ldr	x1, [x16, #0x8]
    7aac:      	add	x16, sp, #0x10
    7ab0:      	ldr	x2, [x16, #0x10]
    7ab4:      	b	0x7a5c <_stogir.checked.projection+0x168>
    7ab8:      	movz	x3, #0x0, lsl #48
    7abc:      	b	0x79bc <_stogir.checked.projection+0xc8>
    7ac0:      	ubfx	x2, x2, #0, #32
    7ac4:      	ubfx	x0, x2, #8, #8
    7ac8:      	cmp	x0, #0x0
    7acc:      	b.eq	0x7a4c <_stogir.checked.projection+0x158>
    7ad0:      	cmp	x0, #0xd
    7ad4:      	b.gt	0x7a4c <_stogir.checked.projection+0x158>
    7ad8:      	movz	x0, #0x0, lsl #48
    7adc:      	movz	x1, #0x0, lsl #48
    7ae0:      	movz	x2, #0x0, lsl #48
    7ae4:      	b	0x7a5c <_stogir.checked.projection+0x168>
    7ae8:      	movz	x3, #0x0, lsl #48
    7aec:      	b	0x79b4 <_stogir.checked.projection+0xc0>
    7af0:      	brk	#0
    7af4:      	b	0x7af0 <_stogir.checked.projection+0x1fc>
    7af8:      	mov	x19, x8
    7afc:      	b	0x7ac0 <_stogir.checked.projection+0x1cc>
    7b00:      	mov	x19, x8
    7b04:      	b	0x7ac0 <_stogir.checked.projection+0x1cc>

0000000000007b08 <_stogir.atomic.ordinary?>:
    7b08:      	sxtw	x1, w1
    7b0c:      	add	x3, x0, #0x28
    7b10:      	cmp	x1, #0x0
    7b14:      	cset	w4, gt
    7b18:      	movz	x16, #0x0, lsl #48
    7b1c:      	sub	x5, x16, x1
    7b20:      	sub	x6, x5, #0x1
    7b24:      	uxtb	w16, w4
    7b28:      	cmp	w16, wzr
    7b2c:      	b.eq	0x7b6c <_stogir.atomic.ordinary?+0x64>
    7b30:      	ldr	x3, [x0, #0x8]
    7b34:      	cmp	x1, x3
    7b38:      	b.ge	0x7bb8 <_stogir.atomic.ordinary?+0xb0>
    7b3c:      	add	x3, x0, #0x78
    7b40:      	ldr	x3, [x3, #0x8]
    7b44:      	cmp	x1, x3
    7b48:      	b.ge	0x7c70 <_stogir.atomic.ordinary?+0x168>
    7b4c:      	ldr	x3, [x0, #0x78]
    7b50:      	add	x3, x3, x1, lsl #2
    7b54:      	ldr	w3, [x3]
    7b58:      	sxtw	x3, w3
    7b5c:      	cmp	x3, #0x0
    7b60:      	cset	w3, ge
    7b64:      	ubfx	x3, x3, #0, #8
    7b68:      	b	0x7c74 <_stogir.atomic.ordinary?+0x16c>
    7b6c:      	cmp	x1, #0x0
    7b70:      	b.ge	0x7bc0 <_stogir.atomic.ordinary?+0xb8>
    7b74:      	add	x7, x0, #0x50
    7b78:      	ldr	x3, [x3, #0x8]
    7b7c:      	ldr	x7, [x7, #0x8]
    7b80:      	cmp	x3, x7
    7b84:      	b.ne	0x7bb0 <_stogir.atomic.ordinary?+0xa8>
    7b88:      	cmp	x5, x3
    7b8c:      	b.gt	0x7c90 <_stogir.atomic.ordinary?+0x188>
    7b90:      	ldr	x3, [x0, #0x50]
    7b94:      	add	x3, x3, x6, lsl #2
    7b98:      	ldr	w3, [x3]
    7b9c:      	sxtw	x3, w3
    7ba0:      	cmp	x3, #0x0
    7ba4:      	cset	w3, gt
    7ba8:      	ubfx	x3, x3, #0, #8
    7bac:      	b	0x7c94 <_stogir.atomic.ordinary?+0x18c>
    7bb0:      	movz	x3, #0x0, lsl #48
    7bb4:      	b	0x7bc4 <_stogir.atomic.ordinary?+0xbc>
    7bb8:      	movz	x3, #0x0, lsl #48
    7bbc:      	b	0x7bc4 <_stogir.atomic.ordinary?+0xbc>
    7bc0:      	movz	x3, #0x0, lsl #48
    7bc4:      	cmp	x3, #0x0
    7bc8:      	b.eq	0x7bfc <_stogir.atomic.ordinary?+0xf4>
    7bcc:      	uxtb	w16, w4
    7bd0:      	cmp	w16, wzr
    7bd4:      	b.eq	0x7be8 <_stogir.atomic.ordinary?+0xe0>
    7bd8:      	ldr	x0, [x0]
    7bdc:      	add	x0, x0, x1, lsl #4
    7be0:      	ldr	x0, [x0]
    7be4:      	b	0x7bf4 <_stogir.atomic.ordinary?+0xec>
    7be8:      	ldr	x0, [x0, #0x28]
    7bec:      	add	x0, x0, x6, lsl #4
    7bf0:      	ldr	x0, [x0]
    7bf4:      	mov	w1, #0x1                ; =1
    7bf8:      	b	0x7c04 <_stogir.atomic.ordinary?+0xfc>
    7bfc:      	movz	w1, #0x0, lsl #16
    7c00:      	movz	x0, #0x0, lsl #48
    7c04:      	ubfx	x1, x1, #0, #32
    7c08:      	lsr	x16, x1, #0
    7c0c:      	cmp	x16, #0x1
    7c10:      	b.eq	0x7c2c <_stogir.atomic.ordinary?+0x124>
    7c14:      	b.lo	0x7c1c <_stogir.atomic.ordinary?+0x114>
    7c18:      	b	0x7c30 <_stogir.atomic.ordinary?+0x128>
    7c1c:      	cmp	x16, #0x0
    7c20:      	b.eq	0x7c28 <_stogir.atomic.ordinary?+0x120>
    7c24:      	b	0x7c30 <_stogir.atomic.ordinary?+0x128>
    7c28:      	b	0x7c34 <_stogir.atomic.ordinary?+0x12c>
    7c2c:      	b	0x7c44 <_stogir.atomic.ordinary?+0x13c>
    7c30:      	b	0x7c98 <_stogir.atomic.ordinary?+0x190>
    7c34:      	movz	x0, #0x0, lsl #48
    7c38:      	b	0x7c40 <_stogir.atomic.ordinary?+0x138>
    7c3c:      	movz	x0, #0x0, lsl #48
    7c40:      	ret
    7c44:      	sxtw	x2, w2
    7c48:      	orr	w1, w0, wzr
    7c4c:      	ubfx	x1, x1, #0, #32
    7c50:      	ubfx	x1, x1, #8, #8
    7c54:      	cmp	x1, x2
    7c58:      	b.ne	0x7c3c <_stogir.atomic.ordinary?+0x134>
    7c5c:      	uxtb	w0, w0
    7c60:      	cmp	x0, #0x46
    7c64:      	b.ne	0x7c78 <_stogir.atomic.ordinary?+0x170>
    7c68:      	movz	x0, #0x0, lsl #48
    7c6c:      	b	0x7c8c <_stogir.atomic.ordinary?+0x184>
    7c70:      	movz	x3, #0x0, lsl #48
    7c74:      	b	0x7bbc <_stogir.atomic.ordinary?+0xb4>
    7c78:      	cmp	x0, #0x48
    7c7c:      	cset	w0, eq
    7c80:      	uxtb	w16, w0
    7c84:      	cmp	w16, wzr
    7c88:      	cset	x0, eq
    7c8c:      	b	0x7c40 <_stogir.atomic.ordinary?+0x138>
    7c90:      	movz	x3, #0x0, lsl #48
    7c94:      	b	0x7bb4 <_stogir.atomic.ordinary?+0xac>
    7c98:      	brk	#0
    7c9c:      	b	0x7c98 <_stogir.atomic.ordinary?+0x190>

0000000000007ca0 <_stogir.types.scalar-size>:
    7ca0:      	sxtw	x1, w1
    7ca4:      	cmp	x1, #0x4
    7ca8:      	b.eq	0x7cbc <_stogir.types.scalar-size+0x1c>
    7cac:      	cmp	x1, #0x8
    7cb0:      	b.eq	0x7cbc <_stogir.types.scalar-size+0x1c>
    7cb4:      	movn	x1, #0x0, lsl #48
    7cb8:      	b	0x7cd4 <_stogir.types.scalar-size+0x34>
    7cbc:      	sxtw	x0, w0
    7cc0:      	cmp	x0, #0x0
    7cc4:      	b.ne	0x7cdc <_stogir.types.scalar-size+0x3c>
    7cc8:      	movz	x1, #0x0, lsl #48
    7ccc:      	b	0x7cd4 <_stogir.types.scalar-size+0x34>
    7cd0:      	mov	x1, #0x1                ; =1
    7cd4:      	mov	x0, x1
    7cd8:      	ret
    7cdc:      	cmp	x0, #0x1
    7ce0:      	b.eq	0x7cd0 <_stogir.types.scalar-size+0x30>
    7ce4:      	cmp	x0, #0x2
    7ce8:      	b.eq	0x7cd0 <_stogir.types.scalar-size+0x30>
    7cec:      	cmp	x0, #0x7
    7cf0:      	b.eq	0x7cd0 <_stogir.types.scalar-size+0x30>
    7cf4:      	cmp	x0, #0x8
    7cf8:      	b.eq	0x7cd0 <_stogir.types.scalar-size+0x30>
    7cfc:      	cmp	x0, #0x3
    7d00:      	b.eq	0x7d4c <_stogir.types.scalar-size+0xac>
    7d04:      	cmp	x0, #0x9
    7d08:      	b.eq	0x7d4c <_stogir.types.scalar-size+0xac>
    7d0c:      	cmp	x0, #0x4
    7d10:      	b.eq	0x7d54 <_stogir.types.scalar-size+0xb4>
    7d14:      	cmp	x0, #0xa
    7d18:      	b.eq	0x7d54 <_stogir.types.scalar-size+0xb4>
    7d1c:      	cmp	x0, #0xd
    7d20:      	b.eq	0x7d54 <_stogir.types.scalar-size+0xb4>
    7d24:      	cmp	x0, #0x5
    7d28:      	b.eq	0x7d5c <_stogir.types.scalar-size+0xbc>
    7d2c:      	cmp	x0, #0xb
    7d30:      	b.eq	0x7d5c <_stogir.types.scalar-size+0xbc>
    7d34:      	cmp	x0, #0xc
    7d38:      	b.eq	0x7d5c <_stogir.types.scalar-size+0xbc>
    7d3c:      	cmp	x0, #0x6
    7d40:      	b.eq	0x7d48 <_stogir.types.scalar-size+0xa8>
    7d44:      	movn	x1, #0x0, lsl #48
    7d48:      	b	0x7d60 <_stogir.types.scalar-size+0xc0>
    7d4c:      	mov	x1, #0x2                ; =2
    7d50:      	b	0x7cd4 <_stogir.types.scalar-size+0x34>
    7d54:      	mov	x1, #0x4                ; =4
    7d58:      	b	0x7d50 <_stogir.types.scalar-size+0xb0>
    7d5c:      	mov	x1, #0x8                ; =8
    7d60:      	b	0x7d58 <_stogir.types.scalar-size+0xb8>

0000000000007d64 <_stogir.terminal.inputs>:
    7d64:      	sxtw	x1, w1
    7d68:      	cmp	x1, #0x60
    7d6c:      	cset	w4, eq
    7d70:      	uxtb	w16, w4
    7d74:      	cmp	w16, wzr
    7d78:      	b.ne	0x7da4 <_stogir.terminal.inputs+0x40>
    7d7c:      	cmp	x1, #0x79
    7d80:      	b.eq	0x7da4 <_stogir.terminal.inputs+0x40>
    7d84:      	mov	x1, #0x1                ; =1
    7d88:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007d88:  ARM64_RELOC_PAGE21	l_stogir.429
    7d8c:      	ldr	x0, [x0]
		0000000000007d8c:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    7d90:      	mov	x2, #0x25               ; =37
    7d94:      	str	x1, [x8]
    7d98:      	str	x0, [x8, #0x8]
    7d9c:      	str	x2, [x8, #0x10]
    7da0:      	ret
    7da4:      	sxtw	x3, w3
    7da8:      	uxtb	w16, w4
    7dac:      	cmp	w16, wzr
    7db0:      	b.eq	0x7dbc <_stogir.terminal.inputs+0x58>
    7db4:      	cmp	x3, #0x0
    7db8:      	b.ne	0x7d84 <_stogir.terminal.inputs+0x20>
    7dbc:      	sxtw	x2, w2
    7dc0:      	cmp	x2, #0x0
    7dc4:      	cset	w1, gt
    7dc8:      	movz	x16, #0x0, lsl #48
    7dcc:      	sub	x4, x16, x2
    7dd0:      	add	x5, x0, #0x28
    7dd4:      	add	x6, x0, #0x78
    7dd8:      	add	x7, x0, #0x50
    7ddc:      	sub	x9, x4, #0x1
    7de0:      	uxtb	w16, w1
    7de4:      	cmp	w16, wzr
    7de8:      	b.eq	0x7eb4 <_stogir.terminal.inputs+0x150>
    7dec:      	ldr	x4, [x0, #0x8]
    7df0:      	cmp	x2, x4
    7df4:      	b.ge	0x7eac <_stogir.terminal.inputs+0x148>
    7df8:      	ldr	x4, [x6, #0x8]
    7dfc:      	cmp	x2, x4
    7e00:      	b.ge	0x7f44 <_stogir.terminal.inputs+0x1e0>
    7e04:      	ldr	x4, [x0, #0x78]
    7e08:      	add	x4, x4, x2, lsl #2
    7e0c:      	ldr	w4, [x4]
    7e10:      	sxtw	x4, w4
    7e14:      	cmp	x4, #0x0
    7e18:      	cset	w4, ge
    7e1c:      	ubfx	x4, x4, #0, #8
    7e20:      	b	0x7f48 <_stogir.terminal.inputs+0x1e4>
    7e24:      	movz	w4, #0x0, lsl #16
    7e28:      	movz	x1, #0x0, lsl #48
    7e2c:      	ubfx	x4, x4, #0, #32
    7e30:      	lsr	x16, x4, #0
    7e34:      	cmp	x16, #0x1
    7e38:      	b.eq	0x7e54 <_stogir.terminal.inputs+0xf0>
    7e3c:      	b.lo	0x7e44 <_stogir.terminal.inputs+0xe0>
    7e40:      	b	0x7e58 <_stogir.terminal.inputs+0xf4>
    7e44:      	cmp	x16, #0x0
    7e48:      	b.eq	0x7e50 <_stogir.terminal.inputs+0xec>
    7e4c:      	b	0x7e58 <_stogir.terminal.inputs+0xf4>
    7e50:      	b	0x7e5c <_stogir.terminal.inputs+0xf8>
    7e54:      	b	0x7ef4 <_stogir.terminal.inputs+0x190>
    7e58:      	b	0x8084 <_stogir.terminal.inputs+0x320>
    7e5c:      	mov	x1, #0x1                ; =1
    7e60:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007e60:  ARM64_RELOC_PAGE21	l_stogir.430
    7e64:      	ldr	x0, [x0]
		0000000000007e64:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    7e68:      	mov	x2, #0x1d               ; =29
    7e6c:      	b	0x7d94 <_stogir.terminal.inputs+0x30>
    7e70:      	ldr	x1, [x0, #0x28]
    7e74:      	add	x1, x1, x9, lsl #4
    7e78:      	ldr	x1, [x1]
    7e7c:      	mov	w4, #0x1                ; =1
    7e80:      	b	0x7e2c <_stogir.terminal.inputs+0xc8>
    7e84:      	movz	x4, #0x0, lsl #48
    7e88:      	cmp	x4, #0x0
    7e8c:      	b.eq	0x7e24 <_stogir.terminal.inputs+0xc0>
    7e90:      	uxtb	w16, w1
    7e94:      	cmp	w16, wzr
    7e98:      	b.eq	0x7e70 <_stogir.terminal.inputs+0x10c>
    7e9c:      	ldr	x1, [x0]
    7ea0:      	add	x1, x1, x2, lsl #4
    7ea4:      	ldr	x1, [x1]
    7ea8:      	b	0x7e7c <_stogir.terminal.inputs+0x118>
    7eac:      	movz	x4, #0x0, lsl #48
    7eb0:      	b	0x7e88 <_stogir.terminal.inputs+0x124>
    7eb4:      	cmp	x2, #0x0
    7eb8:      	b.ge	0x7e84 <_stogir.terminal.inputs+0x120>
    7ebc:      	ldr	x10, [x5, #0x8]
    7ec0:      	ldr	x11, [x7, #0x8]
    7ec4:      	cmp	x10, x11
    7ec8:      	b.ne	0x7f3c <_stogir.terminal.inputs+0x1d8>
    7ecc:      	cmp	x4, x10
    7ed0:      	b.gt	0x7f4c <_stogir.terminal.inputs+0x1e8>
    7ed4:      	ldr	x4, [x0, #0x50]
    7ed8:      	add	x4, x4, x9, lsl #2
    7edc:      	ldr	w4, [x4]
    7ee0:      	sxtw	x4, w4
    7ee4:      	cmp	x4, #0x0
    7ee8:      	cset	w4, gt
    7eec:      	ubfx	x4, x4, #0, #8
    7ef0:      	b	0x7f50 <_stogir.terminal.inputs+0x1ec>
    7ef4:      	cmp	x2, #0x0
    7ef8:      	b.le	0x7f28 <_stogir.terminal.inputs+0x1c4>
    7efc:      	uxtb	w1, w1
    7f00:      	cmp	x1, #0x83
    7f04:      	cset	w2, lt
    7f08:      	uxtb	w16, w2
    7f0c:      	cmp	w16, wzr
    7f10:      	b.eq	0x7f54 <_stogir.terminal.inputs+0x1f0>
    7f14:      	adrp	x17, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007f14:  ARM64_RELOC_PAGE21	l_stogir.431
    7f18:      	ldr	x17, [x17]
		0000000000007f18:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    7f1c:      	add	x4, x1, x17
    7f20:      	ldrb	w4, [x4]
    7f24:      	b	0x7f58 <_stogir.terminal.inputs+0x1f4>
    7f28:      	mov	x1, #0x1                ; =1
    7f2c:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007f2c:  ARM64_RELOC_PAGE21	l_stogir.432
    7f30:      	ldr	x0, [x0]
		0000000000007f30:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    7f34:      	mov	x2, #0x2c               ; =44
    7f38:      	b	0x7e6c <_stogir.terminal.inputs+0x108>
    7f3c:      	movz	x4, #0x0, lsl #48
    7f40:      	b	0x7e88 <_stogir.terminal.inputs+0x124>
    7f44:      	movz	x4, #0x0, lsl #48
    7f48:      	b	0x7eb0 <_stogir.terminal.inputs+0x14c>
    7f4c:      	movz	x4, #0x0, lsl #48
    7f50:      	b	0x7f40 <_stogir.terminal.inputs+0x1dc>
    7f54:      	movz	w4, #0x0, lsl #16
    7f58:      	uxtb	w16, w4
    7f5c:      	and	w4, w16, #0x1
    7f60:      	uxtb	w4, w4
    7f64:      	ubfx	x4, x4, #0, #8
    7f68:      	cmp	x4, #0x0
    7f6c:      	b.eq	0x7f28 <_stogir.terminal.inputs+0x1c4>
    7f70:      	uxtb	w16, w2
    7f74:      	cmp	w16, wzr
    7f78:      	b.eq	0x7f90 <_stogir.terminal.inputs+0x22c>
    7f7c:      	adrp	x17, 0x7000 <_stogir.vector.memory-inputs+0x68>
		0000000000007f7c:  ARM64_RELOC_PAGE21	l_stogir.431
    7f80:      	ldr	x17, [x17]
		0000000000007f80:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    7f84:      	add	x1, x1, x17
    7f88:      	ldrb	w1, [x1]
    7f8c:      	b	0x7f94 <_stogir.terminal.inputs+0x230>
    7f90:      	movz	w1, #0x0, lsl #16
    7f94:      	uxtb	w16, w1
    7f98:      	and	w1, w16, #0x4
    7f9c:      	uxtb	w1, w1
    7fa0:      	ubfx	x1, x1, #0, #8
    7fa4:      	cmp	x1, #0x0
    7fa8:      	cset	w1, eq
    7fac:      	uxtb	w16, w1
    7fb0:      	cmp	w16, wzr
    7fb4:      	cset	x1, eq
    7fb8:      	cmp	x1, #0x0
    7fbc:      	b.ne	0x7f28 <_stogir.terminal.inputs+0x1c4>
    7fc0:      	cmp	x3, #0x0
    7fc4:      	b.ne	0x7fd8 <_stogir.terminal.inputs+0x274>
    7fc8:      	movz	x1, #0x0, lsl #48
    7fcc:      	movz	x0, #0x0, lsl #48
    7fd0:      	movz	x2, #0x0, lsl #48
    7fd4:      	b	0x7f38 <_stogir.terminal.inputs+0x1d4>
    7fd8:      	cmp	x3, #0x0
    7fdc:      	cset	w1, gt
    7fe0:      	movz	x16, #0x0, lsl #48
    7fe4:      	sub	x2, x16, x3
    7fe8:      	sub	x4, x2, #0x1
    7fec:      	uxtb	w16, w1
    7ff0:      	cmp	w16, wzr
    7ff4:      	b.eq	0x8044 <_stogir.terminal.inputs+0x2e0>
    7ff8:      	ldr	x2, [x0, #0x8]
    7ffc:      	cmp	x3, x2
    8000:      	b.ge	0x808c <_stogir.terminal.inputs+0x328>
    8004:      	ldr	x2, [x6, #0x8]
    8008:      	cmp	x3, x2
    800c:      	b.ge	0x814c <_stogir.terminal.inputs+0x3e8>
    8010:      	ldr	x2, [x0, #0x78]
    8014:      	add	x2, x2, x3, lsl #2
    8018:      	ldr	w2, [x2]
    801c:      	sxtw	x2, w2
    8020:      	cmp	x2, #0x0
    8024:      	cset	w2, ge
    8028:      	ubfx	x2, x2, #0, #8
    802c:      	b	0x8150 <_stogir.terminal.inputs+0x3ec>
    8030:      	mov	x1, #0x1                ; =1
    8034:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008034:  ARM64_RELOC_PAGE21	l_stogir.433
    8038:      	ldr	x0, [x0]
		0000000000008038:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    803c:      	mov	x2, #0x2e               ; =46
    8040:      	b	0x7fd4 <_stogir.terminal.inputs+0x270>
    8044:      	cmp	x3, #0x0
    8048:      	b.ge	0x8094 <_stogir.terminal.inputs+0x330>
    804c:      	ldr	x5, [x5, #0x8]
    8050:      	ldr	x6, [x7, #0x8]
    8054:      	cmp	x5, x6
    8058:      	b.ne	0x8144 <_stogir.terminal.inputs+0x3e0>
    805c:      	cmp	x2, x5
    8060:      	b.gt	0x8154 <_stogir.terminal.inputs+0x3f0>
    8064:      	ldr	x2, [x0, #0x50]
    8068:      	add	x2, x2, x4, lsl #2
    806c:      	ldr	w2, [x2]
    8070:      	sxtw	x2, w2
    8074:      	cmp	x2, #0x0
    8078:      	cset	w2, gt
    807c:      	ubfx	x2, x2, #0, #8
    8080:      	b	0x8158 <_stogir.terminal.inputs+0x3f4>
    8084:      	brk	#0
    8088:      	b	0x8084 <_stogir.terminal.inputs+0x320>
    808c:      	movz	x2, #0x0, lsl #48
    8090:      	b	0x8098 <_stogir.terminal.inputs+0x334>
    8094:      	movz	x2, #0x0, lsl #48
    8098:      	cmp	x2, #0x0
    809c:      	b.eq	0x80d0 <_stogir.terminal.inputs+0x36c>
    80a0:      	uxtb	w16, w1
    80a4:      	cmp	w16, wzr
    80a8:      	b.eq	0x80bc <_stogir.terminal.inputs+0x358>
    80ac:      	ldr	x0, [x0]
    80b0:      	add	x0, x0, x3, lsl #4
    80b4:      	ldr	x0, [x0]
    80b8:      	b	0x80c8 <_stogir.terminal.inputs+0x364>
    80bc:      	ldr	x0, [x0, #0x28]
    80c0:      	add	x0, x0, x4, lsl #4
    80c4:      	ldr	x0, [x0]
    80c8:      	mov	w1, #0x1                ; =1
    80cc:      	b	0x80d8 <_stogir.terminal.inputs+0x374>
    80d0:      	movz	w1, #0x0, lsl #16
    80d4:      	movz	x0, #0x0, lsl #48
    80d8:      	ubfx	x1, x1, #0, #32
    80dc:      	lsr	x16, x1, #0
    80e0:      	cmp	x16, #0x1
    80e4:      	b.eq	0x8100 <_stogir.terminal.inputs+0x39c>
    80e8:      	b.lo	0x80f0 <_stogir.terminal.inputs+0x38c>
    80ec:      	b	0x8104 <_stogir.terminal.inputs+0x3a0>
    80f0:      	cmp	x16, #0x0
    80f4:      	b.eq	0x80fc <_stogir.terminal.inputs+0x398>
    80f8:      	b	0x8104 <_stogir.terminal.inputs+0x3a0>
    80fc:      	b	0x8108 <_stogir.terminal.inputs+0x3a4>
    8100:      	b	0x811c <_stogir.terminal.inputs+0x3b8>
    8104:      	b	0x819c <_stogir.terminal.inputs+0x438>
    8108:      	mov	x1, #0x1                ; =1
    810c:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x29c>
		000000000000810c:  ARM64_RELOC_PAGE21	l_stogir.434
    8110:      	ldr	x0, [x0]
		0000000000008110:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    8114:      	mov	x2, #0x1d               ; =29
    8118:      	b	0x8040 <_stogir.terminal.inputs+0x2dc>
    811c:      	cmp	x3, #0x0
    8120:      	b.le	0x8030 <_stogir.terminal.inputs+0x2cc>
    8124:      	uxtb	w0, w0
    8128:      	cmp	x0, #0x83
    812c:      	b.ge	0x815c <_stogir.terminal.inputs+0x3f8>
    8130:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008130:  ARM64_RELOC_PAGE21	l_stogir.431
    8134:      	ldr	x17, [x17]
		0000000000008134:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    8138:      	add	x0, x0, x17
    813c:      	ldrb	w0, [x0]
    8140:      	b	0x8160 <_stogir.terminal.inputs+0x3fc>
    8144:      	movz	x2, #0x0, lsl #48
    8148:      	b	0x8098 <_stogir.terminal.inputs+0x334>
    814c:      	movz	x2, #0x0, lsl #48
    8150:      	b	0x8090 <_stogir.terminal.inputs+0x32c>
    8154:      	movz	x2, #0x0, lsl #48
    8158:      	b	0x8148 <_stogir.terminal.inputs+0x3e4>
    815c:      	movz	w0, #0x0, lsl #16
    8160:      	uxtb	w16, w0
    8164:      	and	w0, w16, #0x8
    8168:      	uxtb	w0, w0
    816c:      	ubfx	x0, x0, #0, #8
    8170:      	cmp	x0, #0x0
    8174:      	cset	w0, eq
    8178:      	uxtb	w16, w0
    817c:      	cmp	w16, wzr
    8180:      	cset	x0, eq
    8184:      	cmp	x0, #0x0
    8188:      	b.eq	0x8030 <_stogir.terminal.inputs+0x2cc>
    818c:      	and	x0, x3, #0xffffffff
    8190:      	movz	x1, #0x0, lsl #48
    8194:      	movz	x2, #0x0, lsl #48
    8198:      	b	0x8040 <_stogir.terminal.inputs+0x2dc>
    819c:      	brk	#0
    81a0:      	b	0x819c <_stogir.terminal.inputs+0x438>

00000000000081a4 <_stogir.switch.switch-inputs>:
    81a4:      	sxtw	x1, w1
    81a8:      	add	x3, x0, #0x28
    81ac:      	add	x4, x0, #0x78
    81b0:      	add	x5, x0, #0x50
    81b4:      	cmp	x1, #0x0
    81b8:      	cset	w6, gt
    81bc:      	movz	x16, #0x0, lsl #48
    81c0:      	sub	x7, x16, x1
    81c4:      	sub	x9, x7, #0x1
    81c8:      	uxtb	w16, w6
    81cc:      	cmp	w16, wzr
    81d0:      	b.eq	0x820c <_stogir.switch.switch-inputs+0x68>
    81d4:      	ldr	x7, [x0, #0x8]
    81d8:      	cmp	x1, x7
    81dc:      	b.ge	0x8268 <_stogir.switch.switch-inputs+0xc4>
    81e0:      	ldr	x7, [x4, #0x8]
    81e4:      	cmp	x1, x7
    81e8:      	b.ge	0x8338 <_stogir.switch.switch-inputs+0x194>
    81ec:      	ldr	x7, [x0, #0x78]
    81f0:      	add	x7, x7, x1, lsl #2
    81f4:      	ldr	w7, [x7]
    81f8:      	sxtw	x7, w7
    81fc:      	cmp	x7, #0x0
    8200:      	cset	w7, ge
    8204:      	ubfx	x7, x7, #0, #8
    8208:      	b	0x833c <_stogir.switch.switch-inputs+0x198>
    820c:      	cmp	x1, #0x0
    8210:      	b.ge	0x8270 <_stogir.switch.switch-inputs+0xcc>
    8214:      	ldr	x10, [x3, #0x8]
    8218:      	ldr	x11, [x5, #0x8]
    821c:      	cmp	x10, x11
    8220:      	b.ne	0x824c <_stogir.switch.switch-inputs+0xa8>
    8224:      	cmp	x7, x10
    8228:      	b.gt	0x8340 <_stogir.switch.switch-inputs+0x19c>
    822c:      	ldr	x7, [x0, #0x50]
    8230:      	add	x7, x7, x9, lsl #2
    8234:      	ldr	w7, [x7]
    8238:      	sxtw	x7, w7
    823c:      	cmp	x7, #0x0
    8240:      	cset	w7, gt
    8244:      	ubfx	x7, x7, #0, #8
    8248:      	b	0x8344 <_stogir.switch.switch-inputs+0x1a0>
    824c:      	movz	x7, #0x0, lsl #48
    8250:      	b	0x8274 <_stogir.switch.switch-inputs+0xd0>
    8254:      	mov	x1, #0x1                ; =1
    8258:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008258:  ARM64_RELOC_PAGE21	l_stogir.435
    825c:      	ldr	x0, [x0]
		000000000000825c:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    8260:      	mov	x2, #0x16               ; =22
    8264:      	b	0x82f4 <_stogir.switch.switch-inputs+0x150>
    8268:      	movz	x7, #0x0, lsl #48
    826c:      	b	0x8274 <_stogir.switch.switch-inputs+0xd0>
    8270:      	movz	x7, #0x0, lsl #48
    8274:      	cmp	x7, #0x0
    8278:      	b.eq	0x82ac <_stogir.switch.switch-inputs+0x108>
    827c:      	uxtb	w16, w6
    8280:      	cmp	w16, wzr
    8284:      	b.eq	0x8298 <_stogir.switch.switch-inputs+0xf4>
    8288:      	ldr	x6, [x0]
    828c:      	add	x6, x6, x1, lsl #4
    8290:      	ldr	x6, [x6]
    8294:      	b	0x82a4 <_stogir.switch.switch-inputs+0x100>
    8298:      	ldr	x6, [x0, #0x28]
    829c:      	add	x6, x6, x9, lsl #4
    82a0:      	ldr	x6, [x6]
    82a4:      	mov	w7, #0x1                ; =1
    82a8:      	b	0x82b4 <_stogir.switch.switch-inputs+0x110>
    82ac:      	movz	w7, #0x0, lsl #16
    82b0:      	movz	x6, #0x0, lsl #48
    82b4:      	ubfx	x7, x7, #0, #32
    82b8:      	lsr	x16, x7, #0
    82bc:      	cmp	x16, #0x1
    82c0:      	b.eq	0x82dc <_stogir.switch.switch-inputs+0x138>
    82c4:      	b.lo	0x82cc <_stogir.switch.switch-inputs+0x128>
    82c8:      	b	0x82e0 <_stogir.switch.switch-inputs+0x13c>
    82cc:      	cmp	x16, #0x0
    82d0:      	b.eq	0x82d8 <_stogir.switch.switch-inputs+0x134>
    82d4:      	b	0x82e0 <_stogir.switch.switch-inputs+0x13c>
    82d8:      	b	0x82e4 <_stogir.switch.switch-inputs+0x140>
    82dc:      	b	0x8304 <_stogir.switch.switch-inputs+0x160>
    82e0:      	b	0x853c <_stogir.switch.switch-inputs+0x398>
    82e4:      	mov	x1, #0x1                ; =1
    82e8:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x29c>
		00000000000082e8:  ARM64_RELOC_PAGE21	l_stogir.436
    82ec:      	ldr	x0, [x0]
		00000000000082ec:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    82f0:      	mov	x2, #0x16               ; =22
    82f4:      	str	x1, [x8]
    82f8:      	str	x0, [x8, #0x8]
    82fc:      	str	x2, [x8, #0x10]
    8300:      	ret
    8304:      	cmp	x1, #0x0
    8308:      	b.le	0x8254 <_stogir.switch.switch-inputs+0xb0>
    830c:      	uxtb	w6, w6
    8310:      	cmp	x6, #0x83
    8314:      	cset	w1, lt
    8318:      	uxtb	w16, w1
    831c:      	cmp	w16, wzr
    8320:      	b.eq	0x8348 <_stogir.switch.switch-inputs+0x1a4>
    8324:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008324:  ARM64_RELOC_PAGE21	l_stogir.437
    8328:      	ldr	x17, [x17]
		0000000000008328:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    832c:      	add	x7, x6, x17
    8330:      	ldrb	w7, [x7]
    8334:      	b	0x834c <_stogir.switch.switch-inputs+0x1a8>
    8338:      	movz	x7, #0x0, lsl #48
    833c:      	b	0x826c <_stogir.switch.switch-inputs+0xc8>
    8340:      	movz	x7, #0x0, lsl #48
    8344:      	b	0x8250 <_stogir.switch.switch-inputs+0xac>
    8348:      	movz	w7, #0x0, lsl #16
    834c:      	uxtb	w16, w7
    8350:      	and	w7, w16, #0x1
    8354:      	uxtb	w7, w7
    8358:      	ubfx	x7, x7, #0, #8
    835c:      	cmp	x7, #0x0
    8360:      	b.eq	0x8254 <_stogir.switch.switch-inputs+0xb0>
    8364:      	uxtb	w16, w1
    8368:      	cmp	w16, wzr
    836c:      	b.eq	0x8384 <_stogir.switch.switch-inputs+0x1e0>
    8370:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008370:  ARM64_RELOC_PAGE21	l_stogir.437
    8374:      	ldr	x17, [x17]
		0000000000008374:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    8378:      	add	x1, x6, x17
    837c:      	ldrb	w1, [x1]
    8380:      	b	0x8388 <_stogir.switch.switch-inputs+0x1e4>
    8384:      	movz	w1, #0x0, lsl #16
    8388:      	uxtb	w16, w1
    838c:      	and	w1, w16, #0x4
    8390:      	uxtb	w1, w1
    8394:      	ubfx	x1, x1, #0, #8
    8398:      	cmp	x1, #0x0
    839c:      	cset	w1, eq
    83a0:      	uxtb	w16, w1
    83a4:      	cmp	w16, wzr
    83a8:      	cset	x1, eq
    83ac:      	cmp	x1, #0x0
    83b0:      	b.ne	0x8254 <_stogir.switch.switch-inputs+0xb0>
    83b4:      	sxtw	x2, w2
    83b8:      	cmp	x2, #0x0
    83bc:      	cset	w1, gt
    83c0:      	movz	x16, #0x0, lsl #48
    83c4:      	sub	x6, x16, x2
    83c8:      	sub	x7, x6, #0x1
    83cc:      	uxtb	w16, w1
    83d0:      	cmp	w16, wzr
    83d4:      	b.eq	0x8424 <_stogir.switch.switch-inputs+0x280>
    83d8:      	ldr	x3, [x0, #0x8]
    83dc:      	cmp	x2, x3
    83e0:      	b.ge	0x8464 <_stogir.switch.switch-inputs+0x2c0>
    83e4:      	ldr	x3, [x4, #0x8]
    83e8:      	cmp	x2, x3
    83ec:      	b.ge	0x8534 <_stogir.switch.switch-inputs+0x390>
    83f0:      	ldr	x3, [x0, #0x78]
    83f4:      	add	x3, x3, x2, lsl #2
    83f8:      	ldr	w3, [x3]
    83fc:      	sxtw	x3, w3
    8400:      	cmp	x3, #0x0
    8404:      	cset	w3, ge
    8408:      	ubfx	x3, x3, #0, #8
    840c:      	b	0x8538 <_stogir.switch.switch-inputs+0x394>
    8410:      	mov	x1, #0x1                ; =1
    8414:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008414:  ARM64_RELOC_PAGE21	l_stogir.438
    8418:      	ldr	x0, [x0]
		0000000000008418:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    841c:      	mov	x2, #0x20               ; =32
    8420:      	b	0x8264 <_stogir.switch.switch-inputs+0xc0>
    8424:      	cmp	x2, #0x0
    8428:      	b.ge	0x846c <_stogir.switch.switch-inputs+0x2c8>
    842c:      	ldr	x3, [x3, #0x8]
    8430:      	ldr	x4, [x5, #0x8]
    8434:      	cmp	x3, x4
    8438:      	b.ne	0x852c <_stogir.switch.switch-inputs+0x388>
    843c:      	cmp	x6, x3
    8440:      	b.gt	0x8544 <_stogir.switch.switch-inputs+0x3a0>
    8444:      	ldr	x3, [x0, #0x50]
    8448:      	add	x3, x3, x7, lsl #2
    844c:      	ldr	w3, [x3]
    8450:      	sxtw	x3, w3
    8454:      	cmp	x3, #0x0
    8458:      	cset	w3, gt
    845c:      	ubfx	x3, x3, #0, #8
    8460:      	b	0x8548 <_stogir.switch.switch-inputs+0x3a4>
    8464:      	movz	x3, #0x0, lsl #48
    8468:      	b	0x8470 <_stogir.switch.switch-inputs+0x2cc>
    846c:      	movz	x3, #0x0, lsl #48
    8470:      	cmp	x3, #0x0
    8474:      	b.eq	0x84a8 <_stogir.switch.switch-inputs+0x304>
    8478:      	uxtb	w16, w1
    847c:      	cmp	w16, wzr
    8480:      	b.eq	0x8494 <_stogir.switch.switch-inputs+0x2f0>
    8484:      	ldr	x0, [x0]
    8488:      	add	x0, x0, x2, lsl #4
    848c:      	ldr	x0, [x0]
    8490:      	b	0x84a0 <_stogir.switch.switch-inputs+0x2fc>
    8494:      	ldr	x0, [x0, #0x28]
    8498:      	add	x0, x0, x7, lsl #4
    849c:      	ldr	x0, [x0]
    84a0:      	mov	w1, #0x1                ; =1
    84a4:      	b	0x84b0 <_stogir.switch.switch-inputs+0x30c>
    84a8:      	movz	w1, #0x0, lsl #16
    84ac:      	movz	x0, #0x0, lsl #48
    84b0:      	ubfx	x1, x1, #0, #32
    84b4:      	lsr	x16, x1, #0
    84b8:      	cmp	x16, #0x1
    84bc:      	b.eq	0x84d8 <_stogir.switch.switch-inputs+0x334>
    84c0:      	b.lo	0x84c8 <_stogir.switch.switch-inputs+0x324>
    84c4:      	b	0x84dc <_stogir.switch.switch-inputs+0x338>
    84c8:      	cmp	x16, #0x0
    84cc:      	b.eq	0x84d4 <_stogir.switch.switch-inputs+0x330>
    84d0:      	b	0x84dc <_stogir.switch.switch-inputs+0x338>
    84d4:      	b	0x84e0 <_stogir.switch.switch-inputs+0x33c>
    84d8:      	b	0x84f4 <_stogir.switch.switch-inputs+0x350>
    84dc:      	b	0x854c <_stogir.switch.switch-inputs+0x3a8>
    84e0:      	mov	x1, #0x1                ; =1
    84e4:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x29c>
		00000000000084e4:  ARM64_RELOC_PAGE21	l_stogir.439
    84e8:      	ldr	x0, [x0]
		00000000000084e8:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    84ec:      	mov	x2, #0x17               ; =23
    84f0:      	b	0x8420 <_stogir.switch.switch-inputs+0x27c>
    84f4:      	orr	w1, w0, wzr
    84f8:      	ubfx	x1, x1, #0, #32
    84fc:      	ubfx	x1, x1, #8, #8
    8500:      	cmp	x1, #0x1
    8504:      	b.lt	0x8410 <_stogir.switch.switch-inputs+0x26c>
    8508:      	cmp	x1, #0xb
    850c:      	b.gt	0x8410 <_stogir.switch.switch-inputs+0x26c>
    8510:      	uxtb	w0, w0
    8514:      	cmp	x0, #0x48
    8518:      	b.eq	0x8410 <_stogir.switch.switch-inputs+0x26c>
    851c:      	and	x0, x1, #0xffffffff
    8520:      	movz	x1, #0x0, lsl #48
    8524:      	movz	x2, #0x0, lsl #48
    8528:      	b	0x8420 <_stogir.switch.switch-inputs+0x27c>
    852c:      	movz	x3, #0x0, lsl #48
    8530:      	b	0x8470 <_stogir.switch.switch-inputs+0x2cc>
    8534:      	movz	x3, #0x0, lsl #48
    8538:      	b	0x8468 <_stogir.switch.switch-inputs+0x2c4>
    853c:      	brk	#0
    8540:      	b	0x853c <_stogir.switch.switch-inputs+0x398>
    8544:      	movz	x3, #0x0, lsl #48
    8548:      	b	0x8530 <_stogir.switch.switch-inputs+0x38c>
    854c:      	brk	#0
    8550:      	b	0x854c <_stogir.switch.switch-inputs+0x3a8>

0000000000008554 <_stogir.switch.case-inputs>:
    8554:      	sub	sp, sp, #0xb0
    8558:      	str	x29, [sp]
    855c:      	str	x30, [sp, #0x8]
    8560:      	mov	x29, sp
    8564:      	str	x19, [sp, #0x70]
    8568:      	str	x20, [sp, #0x78]
    856c:      	str	x21, [sp, #0x80]
    8570:      	str	x22, [sp, #0x88]
    8574:      	str	x23, [sp, #0x90]
    8578:      	str	x24, [sp, #0x98]
    857c:      	str	x25, [sp, #0xa0]
    8580:      	str	x26, [sp, #0xa8]
    8584:      	sxtw	x2, w2
    8588:      	add	x5, x0, #0x78
    858c:      	add	x6, x0, #0x28
    8590:      	lsl	x7, x2, #2
    8594:      	cmp	x2, #0x0
    8598:      	cset	w9, gt
    859c:      	movz	x16, #0x0, lsl #48
    85a0:      	sub	x10, x16, x2
    85a4:      	sub	x11, x10, #0x1
    85a8:      	uxtb	w16, w9
    85ac:      	cmp	w16, wzr
    85b0:      	b.eq	0x85ec <_stogir.switch.case-inputs+0x98>
    85b4:      	ldr	x6, [x0, #0x8]
    85b8:      	cmp	x2, x6
    85bc:      	b.ge	0x8638 <_stogir.switch.case-inputs+0xe4>
    85c0:      	ldr	x5, [x5, #0x8]
    85c4:      	cmp	x2, x5
    85c8:      	b.ge	0x8730 <_stogir.switch.case-inputs+0x1dc>
    85cc:      	ldr	x5, [x0, #0x78]
    85d0:      	add	x5, x7, x5
    85d4:      	ldr	w5, [x5]
    85d8:      	sxtw	x5, w5
    85dc:      	cmp	x5, #0x0
    85e0:      	cset	w5, ge
    85e4:      	ubfx	x5, x5, #0, #8
    85e8:      	b	0x8734 <_stogir.switch.case-inputs+0x1e0>
    85ec:      	cmp	x2, #0x0
    85f0:      	b.ge	0x8640 <_stogir.switch.case-inputs+0xec>
    85f4:      	add	x5, x0, #0x50
    85f8:      	ldr	x6, [x6, #0x8]
    85fc:      	ldr	x5, [x5, #0x8]
    8600:      	cmp	x6, x5
    8604:      	b.ne	0x8630 <_stogir.switch.case-inputs+0xdc>
    8608:      	cmp	x10, x6
    860c:      	b.gt	0x87f8 <_stogir.switch.case-inputs+0x2a4>
    8610:      	ldr	x5, [x0, #0x50]
    8614:      	add	x5, x5, x11, lsl #2
    8618:      	ldr	w5, [x5]
    861c:      	sxtw	x5, w5
    8620:      	cmp	x5, #0x0
    8624:      	cset	w5, gt
    8628:      	ubfx	x5, x5, #0, #8
    862c:      	b	0x87fc <_stogir.switch.case-inputs+0x2a8>
    8630:      	movz	x5, #0x0, lsl #48
    8634:      	b	0x8644 <_stogir.switch.case-inputs+0xf0>
    8638:      	movz	x5, #0x0, lsl #48
    863c:      	b	0x8644 <_stogir.switch.case-inputs+0xf0>
    8640:      	movz	x5, #0x0, lsl #48
    8644:      	cmp	x5, #0x0
    8648:      	b.eq	0x8684 <_stogir.switch.case-inputs+0x130>
    864c:      	uxtb	w16, w9
    8650:      	cmp	w16, wzr
    8654:      	b.eq	0x866c <_stogir.switch.case-inputs+0x118>
    8658:      	ldr	x5, [x0]
    865c:      	add	x5, x5, x2, lsl #4
    8660:      	ldr	x6, [x5]
    8664:      	ldr	x5, [x5, #0x8]
    8668:      	b	0x867c <_stogir.switch.case-inputs+0x128>
    866c:      	ldr	x5, [x0, #0x28]
    8670:      	add	x5, x5, x11, lsl #4
    8674:      	ldr	x6, [x5]
    8678:      	ldr	x5, [x5, #0x8]
    867c:      	mov	w9, #0x1                ; =1
    8680:      	b	0x8690 <_stogir.switch.case-inputs+0x13c>
    8684:      	movz	w9, #0x0, lsl #16
    8688:      	movz	x6, #0x0, lsl #48
    868c:      	movz	x5, #0x0, lsl #48
    8690:      	ubfx	x9, x9, #0, #32
    8694:      	lsr	x16, x9, #0
    8698:      	cmp	x16, #0x1
    869c:      	b.eq	0x86b8 <_stogir.switch.case-inputs+0x164>
    86a0:      	b.lo	0x86a8 <_stogir.switch.case-inputs+0x154>
    86a4:      	b	0x86bc <_stogir.switch.case-inputs+0x168>
    86a8:      	cmp	x16, #0x0
    86ac:      	b.eq	0x86b4 <_stogir.switch.case-inputs+0x160>
    86b0:      	b	0x86bc <_stogir.switch.case-inputs+0x168>
    86b4:      	b	0x86c0 <_stogir.switch.case-inputs+0x16c>
    86b8:      	b	0x8710 <_stogir.switch.case-inputs+0x1bc>
    86bc:      	b	0x8800 <_stogir.switch.case-inputs+0x2ac>
    86c0:      	mov	x21, x8
    86c4:      	mov	x2, #0x1                ; =1
    86c8:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x29c>
		00000000000086c8:  ARM64_RELOC_PAGE21	l_stogir.440
    86cc:      	ldr	x1, [x1]
		00000000000086cc:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    86d0:      	mov	x0, #0x1a               ; =26
    86d4:      	str	x2, [x21]
    86d8:      	str	x1, [x21, #0x8]
    86dc:      	str	x0, [x21, #0x10]
    86e0:      	ldr	x19, [sp, #0x70]
    86e4:      	ldr	x20, [sp, #0x78]
    86e8:      	ldr	x21, [sp, #0x80]
    86ec:      	ldr	x22, [sp, #0x88]
    86f0:      	ldr	x23, [sp, #0x90]
    86f4:      	ldr	x24, [sp, #0x98]
    86f8:      	ldr	x25, [sp, #0xa0]
    86fc:      	ldr	x26, [sp, #0xa8]
    8700:      	ldr	x29, [sp]
    8704:      	ldr	x30, [sp, #0x8]
    8708:      	add	sp, sp, #0xb0
    870c:      	ret
    8710:      	cmp	x2, #0x0
    8714:      	b.gt	0x8738 <_stogir.switch.case-inputs+0x1e4>
    8718:      	mov	x21, x8
    871c:      	mov	x2, #0x1                ; =1
    8720:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008720:  ARM64_RELOC_PAGE21	l_stogir.441
    8724:      	ldr	x1, [x1]
		0000000000008724:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    8728:      	mov	x0, #0x1f               ; =31
    872c:      	b	0x86d4 <_stogir.switch.case-inputs+0x180>
    8730:      	movz	x5, #0x0, lsl #48
    8734:      	b	0x863c <_stogir.switch.case-inputs+0xe8>
    8738:      	uxtb	w2, w6
    873c:      	cmp	x2, #0x75
    8740:      	b.ne	0x895c <_stogir.switch.case-inputs+0x408>
    8744:      	orr	w2, w6, wzr
    8748:      	ubfx	x2, x2, #0, #32
    874c:      	ubfx	x2, x2, #8, #8
    8750:      	cmp	x2, #0x0
    8754:      	b.ne	0x8964 <_stogir.switch.case-inputs+0x410>
    8758:      	ldr	x2, [x0, #0x78]
    875c:      	add	x2, x7, x2
    8760:      	ldr	w2, [x2]
    8764:      	sxtw	x2, w2
    8768:      	cmp	x2, #0x2
    876c:      	b.ne	0x896c <_stogir.switch.case-inputs+0x418>
    8770:      	sxtw	x19, w1
    8774:      	cmp	x19, #0x6d
    8778:      	b.lt	0x8974 <_stogir.switch.case-inputs+0x420>
    877c:      	cmp	x19, #0x6f
    8780:      	b.gt	0x897c <_stogir.switch.case-inputs+0x428>
    8784:      	add	x16, sp, #0x10
    8788:      	orr	x20, x16, xzr
    878c:      	lsr	x1, x6, #32
    8790:      	mov	w2, w5
    8794:      	mov	x21, x8
    8798:      	add	x8, sp, #0x10
    879c:      	mov	x22, x0
    87a0:      	mov	w23, w3
    87a4:      	mov	w24, w4
    87a8:      	bl	0x87a8 <_stogir.switch.case-inputs+0x254>
		00000000000087a8:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    87ac:      	add	x16, sp, #0x10
    87b0:      	ldr	w0, [x16]
    87b4:      	lsr	x16, x0, #0
    87b8:      	cmp	x16, #0x1
    87bc:      	b.eq	0x87d8 <_stogir.switch.case-inputs+0x284>
    87c0:      	b.lo	0x87c8 <_stogir.switch.case-inputs+0x274>
    87c4:      	b	0x87dc <_stogir.switch.case-inputs+0x288>
    87c8:      	cmp	x16, #0x0
    87cc:      	b.eq	0x87d4 <_stogir.switch.case-inputs+0x280>
    87d0:      	b	0x87dc <_stogir.switch.case-inputs+0x288>
    87d4:      	b	0x8808 <_stogir.switch.case-inputs+0x2b4>
    87d8:      	b	0x87e0 <_stogir.switch.case-inputs+0x28c>
    87dc:      	b	0x8944 <_stogir.switch.case-inputs+0x3f0>
    87e0:      	add	x0, x20, #0x8
    87e4:      	add	x16, sp, #0x10
    87e8:      	ldr	x1, [x16, #0x8]
    87ec:      	ldr	x0, [x0, #0x8]
    87f0:      	mov	x2, #0x1                ; =1
    87f4:      	b	0x872c <_stogir.switch.case-inputs+0x1d8>
    87f8:      	movz	x5, #0x0, lsl #48
    87fc:      	b	0x8634 <_stogir.switch.case-inputs+0xe0>
    8800:      	brk	#0
    8804:      	b	0x8800 <_stogir.switch.case-inputs+0x2ac>
    8808:      	add	x16, sp, #0x10
    880c:      	ldr	w20, [x16, #0x8]
    8810:      	sxtw	x25, w20
    8814:      	cmp	x19, #0x6f
    8818:      	b.ne	0x882c <_stogir.switch.case-inputs+0x2d8>
    881c:      	and	x1, x25, #0xffffffff
    8820:      	movz	x2, #0x0, lsl #48
    8824:      	movz	x0, #0x0, lsl #48
    8828:      	b	0x87f4 <_stogir.switch.case-inputs+0x2a0>
    882c:      	add	x16, sp, #0x30
    8830:      	orr	x26, x16, xzr
    8834:      	add	x8, sp, #0x30
    8838:      	mov	x0, x22
    883c:      	mov	w1, w23
    8840:      	mov	w2, w20
    8844:      	bl	0x8844 <_stogir.switch.case-inputs+0x2f0>
		0000000000008844:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    8848:      	add	x16, sp, #0x30
    884c:      	ldr	w0, [x16]
    8850:      	lsr	x16, x0, #0
    8854:      	cmp	x16, #0x1
    8858:      	b.eq	0x8874 <_stogir.switch.case-inputs+0x320>
    885c:      	b.lo	0x8864 <_stogir.switch.case-inputs+0x310>
    8860:      	b	0x8878 <_stogir.switch.case-inputs+0x324>
    8864:      	cmp	x16, #0x0
    8868:      	b.eq	0x8870 <_stogir.switch.case-inputs+0x31c>
    886c:      	b	0x8878 <_stogir.switch.case-inputs+0x324>
    8870:      	b	0x8894 <_stogir.switch.case-inputs+0x340>
    8874:      	b	0x887c <_stogir.switch.case-inputs+0x328>
    8878:      	b	0x894c <_stogir.switch.case-inputs+0x3f8>
    887c:      	add	x0, x26, #0x8
    8880:      	add	x16, sp, #0x30
    8884:      	ldr	x1, [x16, #0x8]
    8888:      	ldr	x0, [x0, #0x8]
    888c:      	mov	x2, #0x1                ; =1
    8890:      	b	0x8828 <_stogir.switch.case-inputs+0x2d4>
    8894:      	add	x16, sp, #0x30
    8898:      	ldr	x26, [x16, #0x8]
    889c:      	cmp	x19, #0x6d
    88a0:      	b.eq	0x88a8 <_stogir.switch.case-inputs+0x354>
    88a4:      	orr	w23, w24, wzr
    88a8:      	add	x16, sp, #0x50
    88ac:      	orr	x19, x16, xzr
    88b0:      	add	x8, sp, #0x50
    88b4:      	mov	x0, x22
    88b8:      	mov	w1, w23
    88bc:      	mov	w2, w20
    88c0:      	bl	0x88c0 <_stogir.switch.case-inputs+0x36c>
		00000000000088c0:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    88c4:      	add	x16, sp, #0x50
    88c8:      	ldr	w0, [x16]
    88cc:      	lsr	x16, x0, #0
    88d0:      	cmp	x16, #0x1
    88d4:      	b.eq	0x88f0 <_stogir.switch.case-inputs+0x39c>
    88d8:      	b.lo	0x88e0 <_stogir.switch.case-inputs+0x38c>
    88dc:      	b	0x88f4 <_stogir.switch.case-inputs+0x3a0>
    88e0:      	cmp	x16, #0x0
    88e4:      	b.eq	0x88ec <_stogir.switch.case-inputs+0x398>
    88e8:      	b	0x88f4 <_stogir.switch.case-inputs+0x3a0>
    88ec:      	b	0x8920 <_stogir.switch.case-inputs+0x3cc>
    88f0:      	b	0x88f8 <_stogir.switch.case-inputs+0x3a4>
    88f4:      	b	0x8954 <_stogir.switch.case-inputs+0x400>
    88f8:      	add	x0, x19, #0x8
    88fc:      	add	x16, sp, #0x50
    8900:      	ldr	x1, [x16, #0x8]
    8904:      	ldr	x0, [x0, #0x8]
    8908:      	mov	x2, #0x1                ; =1
    890c:      	b	0x891c <_stogir.switch.case-inputs+0x3c8>
    8910:      	and	x1, x25, #0xffffffff
    8914:      	movz	x2, #0x0, lsl #48
    8918:      	movz	x0, #0x0, lsl #48
    891c:      	b	0x8890 <_stogir.switch.case-inputs+0x33c>
    8920:      	add	x16, sp, #0x50
    8924:      	ldr	x0, [x16, #0x8]
    8928:      	cmp	x26, x0
    892c:      	b.ls	0x8910 <_stogir.switch.case-inputs+0x3bc>
    8930:      	mov	x2, #0x1                ; =1
    8934:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008934:  ARM64_RELOC_PAGE21	l_stogir.442
    8938:      	ldr	x1, [x1]
		0000000000008938:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    893c:      	mov	x0, #0x1a               ; =26
    8940:      	b	0x891c <_stogir.switch.case-inputs+0x3c8>
    8944:      	brk	#0
    8948:      	b	0x8944 <_stogir.switch.case-inputs+0x3f0>
    894c:      	brk	#0
    8950:      	b	0x894c <_stogir.switch.case-inputs+0x3f8>
    8954:      	brk	#0
    8958:      	b	0x8954 <_stogir.switch.case-inputs+0x400>
    895c:      	mov	x21, x8
    8960:      	b	0x871c <_stogir.switch.case-inputs+0x1c8>
    8964:      	mov	x21, x8
    8968:      	b	0x871c <_stogir.switch.case-inputs+0x1c8>
    896c:      	mov	x21, x8
    8970:      	b	0x871c <_stogir.switch.case-inputs+0x1c8>
    8974:      	mov	x21, x8
    8978:      	b	0x871c <_stogir.switch.case-inputs+0x1c8>
    897c:      	mov	x21, x8
    8980:      	b	0x871c <_stogir.switch.case-inputs+0x1c8>

0000000000008984 <_stogir.stack.valid-frame-object-inputs?>:
    8984:      	sub	sp, sp, #0x30
    8988:      	str	x29, [sp]
    898c:      	str	x30, [sp, #0x8]
    8990:      	mov	x29, sp
    8994:      	sxtw	x1, w1
    8998:      	mov	x3, sp
    899c:      	add	x4, x0, #0x28
    89a0:      	add	x5, x0, #0x78
    89a4:      	add	x6, x0, #0x50
    89a8:      	sub	sp, sp, #0x10
    89ac:      	mov	x7, sp
    89b0:      	mov	x8, #0x1                ; =1
    89b4:      	movz	x9, #0x0, lsl #48
    89b8:      	b	0x8abc <_stogir.stack.valid-frame-object-inputs?+0x138>
    89bc:      	movz	x12, #0x0, lsl #48
    89c0:      	b	0x8a2c <_stogir.stack.valid-frame-object-inputs?+0xa8>
    89c4:      	movz	w11, #0x0, lsl #16
    89c8:      	movz	x10, #0x0, lsl #48
    89cc:      	ubfx	x11, x11, #0, #32
    89d0:      	lsr	x16, x11, #0
    89d4:      	cmp	x16, #0x1
    89d8:      	b.eq	0x89f4 <_stogir.stack.valid-frame-object-inputs?+0x70>
    89dc:      	b.lo	0x89e4 <_stogir.stack.valid-frame-object-inputs?+0x60>
    89e0:      	b	0x89f8 <_stogir.stack.valid-frame-object-inputs?+0x74>
    89e4:      	cmp	x16, #0x0
    89e8:      	b.eq	0x89f0 <_stogir.stack.valid-frame-object-inputs?+0x6c>
    89ec:      	b	0x89f8 <_stogir.stack.valid-frame-object-inputs?+0x74>
    89f0:      	b	0x8a18 <_stogir.stack.valid-frame-object-inputs?+0x94>
    89f4:      	b	0x89fc <_stogir.stack.valid-frame-object-inputs?+0x78>
    89f8:      	b	0x8d68 <_stogir.stack.valid-frame-object-inputs?+0x3e4>
    89fc:      	uxtb	w11, w10
    8a00:      	ubfx	x10, x10, #0, #32
    8a04:      	ubfx	x10, x10, #8, #8
    8a08:      	cmp	x11, x10
    8a0c:      	b.eq	0x8d54 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    8a10:      	cmp	x11, #0x49
    8a14:      	b.eq	0x8d54 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    8a18:      	movz	x8, #0x0, lsl #48
    8a1c:      	b	0x8b94 <_stogir.stack.valid-frame-object-inputs?+0x210>
    8a20:      	movz	x12, #0x0, lsl #48
    8a24:      	b	0x8a34 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    8a28:      	movz	x12, #0x0, lsl #48
    8a2c:      	b	0x8a3c <_stogir.stack.valid-frame-object-inputs?+0xb8>
    8a30:      	movz	x12, #0x0, lsl #48
    8a34:      	b	0x8a3c <_stogir.stack.valid-frame-object-inputs?+0xb8>
    8a38:      	movz	x12, #0x0, lsl #48
    8a3c:      	cmp	x12, #0x0
    8a40:      	b.eq	0x8a7c <_stogir.stack.valid-frame-object-inputs?+0xf8>
    8a44:      	uxtb	w16, w11
    8a48:      	cmp	w16, wzr
    8a4c:      	b.eq	0x8a64 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    8a50:      	ldr	x11, [x0]
    8a54:      	add	x10, x11, x10, lsl #4
    8a58:      	ldr	x11, [x10]
    8a5c:      	ldr	x10, [x10, #0x8]
    8a60:      	b	0x8a74 <_stogir.stack.valid-frame-object-inputs?+0xf0>
    8a64:      	ldr	x10, [x0, #0x28]
    8a68:      	add	x10, x10, x13, lsl #4
    8a6c:      	ldr	x11, [x10]
    8a70:      	ldr	x10, [x10, #0x8]
    8a74:      	mov	w12, #0x1               ; =1
    8a78:      	b	0x8a88 <_stogir.stack.valid-frame-object-inputs?+0x104>
    8a7c:      	movz	w12, #0x0, lsl #16
    8a80:      	movz	x11, #0x0, lsl #48
    8a84:      	movz	x10, #0x0, lsl #48
    8a88:      	ubfx	x12, x12, #0, #32
    8a8c:      	lsr	x16, x12, #0
    8a90:      	cmp	x16, #0x1
    8a94:      	b.eq	0x8ab0 <_stogir.stack.valid-frame-object-inputs?+0x12c>
    8a98:      	b.lo	0x8aa0 <_stogir.stack.valid-frame-object-inputs?+0x11c>
    8a9c:      	b	0x8ab4 <_stogir.stack.valid-frame-object-inputs?+0x130>
    8aa0:      	cmp	x16, #0x0
    8aa4:      	b.eq	0x8aac <_stogir.stack.valid-frame-object-inputs?+0x128>
    8aa8:      	b	0x8ab4 <_stogir.stack.valid-frame-object-inputs?+0x130>
    8aac:      	b	0x8ab8 <_stogir.stack.valid-frame-object-inputs?+0x134>
    8ab0:      	b	0x8b6c <_stogir.stack.valid-frame-object-inputs?+0x1e8>
    8ab4:      	b	0x8cc0 <_stogir.stack.valid-frame-object-inputs?+0x33c>
    8ab8:      	movz	x8, #0x0, lsl #48
    8abc:      	cmp	x8, #0x0
    8ac0:      	b.eq	0x8c1c <_stogir.stack.valid-frame-object-inputs?+0x298>
    8ac4:      	cmp	x9, #0x0
    8ac8:      	b.ne	0x8c1c <_stogir.stack.valid-frame-object-inputs?+0x298>
    8acc:      	orr	w10, w1, wzr
    8ad0:      	sxtw	x10, w10
    8ad4:      	cmp	x10, #0x0
    8ad8:      	cset	w11, gt
    8adc:      	movz	x16, #0x0, lsl #48
    8ae0:      	sub	x12, x16, x10
    8ae4:      	sub	x13, x12, #0x1
    8ae8:      	uxtb	w16, w11
    8aec:      	cmp	w16, wzr
    8af0:      	b.eq	0x8b2c <_stogir.stack.valid-frame-object-inputs?+0x1a8>
    8af4:      	ldr	x12, [x0, #0x8]
    8af8:      	cmp	x10, x12
    8afc:      	b.ge	0x8a30 <_stogir.stack.valid-frame-object-inputs?+0xac>
    8b00:      	ldr	x12, [x5, #0x8]
    8b04:      	cmp	x10, x12
    8b08:      	b.ge	0x8a20 <_stogir.stack.valid-frame-object-inputs?+0x9c>
    8b0c:      	ldr	x12, [x0, #0x78]
    8b10:      	add	x12, x12, x10, lsl #2
    8b14:      	ldr	w12, [x12]
    8b18:      	sxtw	x12, w12
    8b1c:      	cmp	x12, #0x0
    8b20:      	cset	w12, ge
    8b24:      	ubfx	x12, x12, #0, #8
    8b28:      	b	0x8a24 <_stogir.stack.valid-frame-object-inputs?+0xa0>
    8b2c:      	cmp	x10, #0x0
    8b30:      	b.ge	0x8a38 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    8b34:      	ldr	x14, [x4, #0x8]
    8b38:      	ldr	x15, [x6, #0x8]
    8b3c:      	cmp	x14, x15
    8b40:      	b.ne	0x8a28 <_stogir.stack.valid-frame-object-inputs?+0xa4>
    8b44:      	cmp	x12, x14
    8b48:      	b.gt	0x89bc <_stogir.stack.valid-frame-object-inputs?+0x38>
    8b4c:      	ldr	x12, [x0, #0x50]
    8b50:      	add	x12, x12, x13, lsl #2
    8b54:      	ldr	w12, [x12]
    8b58:      	sxtw	x12, w12
    8b5c:      	cmp	x12, #0x0
    8b60:      	cset	w12, gt
    8b64:      	ubfx	x12, x12, #0, #8
    8b68:      	b	0x89c0 <_stogir.stack.valid-frame-object-inputs?+0x3c>
    8b6c:      	uxtb	w12, w11
    8b70:      	asr	x13, x11, #32
    8b74:      	str	x11, [x7]
    8b78:      	str	x10, [x7, #0x8]
    8b7c:      	cmp	x12, #0x68
    8b80:      	b.ne	0x8b98 <_stogir.stack.valid-frame-object-inputs?+0x214>
    8b84:      	cmp	x13, #0x0
    8b88:      	cset	w8, eq
    8b8c:      	ubfx	x8, x8, #0, #8
    8b90:      	mov	x9, #0x1                ; =1
    8b94:      	b	0x8abc <_stogir.stack.valid-frame-object-inputs?+0x138>
    8b98:      	cmp	x1, #0x0
    8b9c:      	b.le	0x8a18 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8ba0:      	cmp	x12, #0x51
    8ba4:      	b.ne	0x8a18 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8ba8:      	cmp	x13, #0x0
    8bac:      	b.le	0x8a18 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8bb0:      	cmp	x13, x1
    8bb4:      	b.ge	0x8a18 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8bb8:      	sxtw	x10, w10
    8bbc:      	cmp	x10, #0x0
    8bc0:      	b.ge	0x8a18 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8bc4:      	cmp	x10, #0x0
    8bc8:      	cset	w11, gt
    8bcc:      	movz	x16, #0x0, lsl #48
    8bd0:      	sub	x12, x16, x10
    8bd4:      	sub	x13, x12, #0x1
    8bd8:      	uxtb	w16, w11
    8bdc:      	cmp	w16, wzr
    8be0:      	b.eq	0x8d0c <_stogir.stack.valid-frame-object-inputs?+0x388>
    8be4:      	ldr	x12, [x0, #0x8]
    8be8:      	cmp	x10, x12
    8bec:      	b.ge	0x8d04 <_stogir.stack.valid-frame-object-inputs?+0x380>
    8bf0:      	ldr	x12, [x5, #0x8]
    8bf4:      	cmp	x10, x12
    8bf8:      	b.ge	0x8d4c <_stogir.stack.valid-frame-object-inputs?+0x3c8>
    8bfc:      	ldr	x12, [x0, #0x78]
    8c00:      	add	x12, x12, x10, lsl #2
    8c04:      	ldr	w12, [x12]
    8c08:      	sxtw	x12, w12
    8c0c:      	cmp	x12, #0x0
    8c10:      	cset	w12, ge
    8c14:      	ubfx	x12, x12, #0, #8
    8c18:      	b	0x8d50 <_stogir.stack.valid-frame-object-inputs?+0x3cc>
    8c1c:      	cmp	x8, #0x0
    8c20:      	b.ne	0x8c28 <_stogir.stack.valid-frame-object-inputs?+0x2a4>
    8c24:      	movz	x9, #0x0, lsl #48
    8c28:      	mov	sp, x3
    8c2c:      	cmp	x9, #0x0
    8c30:      	b.eq	0x8c88 <_stogir.stack.valid-frame-object-inputs?+0x304>
    8c34:      	sxtw	x1, w2
    8c38:      	cmp	x1, #0x0
    8c3c:      	b.ge	0x8ca0 <_stogir.stack.valid-frame-object-inputs?+0x31c>
    8c40:      	add	x8, x29, #0x10
    8c44:      	mov	w1, w2
    8c48:      	bl	0x8c48 <_stogir.stack.valid-frame-object-inputs?+0x2c4>
		0000000000008c48:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    8c4c:      	add	x16, x29, #0x10
    8c50:      	ldr	w0, [x16]
    8c54:      	lsr	x16, x0, #0
    8c58:      	cmp	x16, #0x1
    8c5c:      	b.eq	0x8c78 <_stogir.stack.valid-frame-object-inputs?+0x2f4>
    8c60:      	b.lo	0x8c68 <_stogir.stack.valid-frame-object-inputs?+0x2e4>
    8c64:      	b	0x8c7c <_stogir.stack.valid-frame-object-inputs?+0x2f8>
    8c68:      	cmp	x16, #0x0
    8c6c:      	b.eq	0x8c74 <_stogir.stack.valid-frame-object-inputs?+0x2f0>
    8c70:      	b	0x8c7c <_stogir.stack.valid-frame-object-inputs?+0x2f8>
    8c74:      	b	0x8ca8 <_stogir.stack.valid-frame-object-inputs?+0x324>
    8c78:      	b	0x8c80 <_stogir.stack.valid-frame-object-inputs?+0x2fc>
    8c7c:      	b	0x8d60 <_stogir.stack.valid-frame-object-inputs?+0x3dc>
    8c80:      	movz	x0, #0x0, lsl #48
    8c84:      	b	0x8cbc <_stogir.stack.valid-frame-object-inputs?+0x338>
    8c88:      	movz	x0, #0x0, lsl #48
    8c8c:      	sub	sp, x29, #0x0
    8c90:      	ldr	x29, [sp]
    8c94:      	ldr	x30, [sp, #0x8]
    8c98:      	add	sp, sp, #0x30
    8c9c:      	ret
    8ca0:      	movz	x0, #0x0, lsl #48
    8ca4:      	b	0x8c8c <_stogir.stack.valid-frame-object-inputs?+0x308>
    8ca8:      	add	x16, x29, #0x10
    8cac:      	ldr	x0, [x16, #0x8]
    8cb0:      	cmp	x0, #0x0
    8cb4:      	cset	w0, gt
    8cb8:      	ubfx	x0, x0, #0, #8
    8cbc:      	b	0x8ca4 <_stogir.stack.valid-frame-object-inputs?+0x320>
    8cc0:      	brk	#0
    8cc4:      	b	0x8cc0 <_stogir.stack.valid-frame-object-inputs?+0x33c>
    8cc8:      	ldr	x10, [x0, #0x28]
    8ccc:      	add	x10, x10, x13, lsl #4
    8cd0:      	ldr	x10, [x10]
    8cd4:      	mov	w11, #0x1               ; =1
    8cd8:      	b	0x89cc <_stogir.stack.valid-frame-object-inputs?+0x48>
    8cdc:      	movz	x12, #0x0, lsl #48
    8ce0:      	cmp	x12, #0x0
    8ce4:      	b.eq	0x89c4 <_stogir.stack.valid-frame-object-inputs?+0x40>
    8ce8:      	uxtb	w16, w11
    8cec:      	cmp	w16, wzr
    8cf0:      	b.eq	0x8cc8 <_stogir.stack.valid-frame-object-inputs?+0x344>
    8cf4:      	ldr	x11, [x0]
    8cf8:      	add	x10, x11, x10, lsl #4
    8cfc:      	ldr	x10, [x10]
    8d00:      	b	0x8cd4 <_stogir.stack.valid-frame-object-inputs?+0x350>
    8d04:      	movz	x12, #0x0, lsl #48
    8d08:      	b	0x8ce0 <_stogir.stack.valid-frame-object-inputs?+0x35c>
    8d0c:      	ldr	x14, [x4, #0x8]
    8d10:      	ldr	x15, [x6, #0x8]
    8d14:      	cmp	x14, x15
    8d18:      	b.ne	0x8cdc <_stogir.stack.valid-frame-object-inputs?+0x358>
    8d1c:      	cmp	x12, x14
    8d20:      	b.gt	0x8d44 <_stogir.stack.valid-frame-object-inputs?+0x3c0>
    8d24:      	ldr	x12, [x0, #0x50]
    8d28:      	add	x12, x12, x13, lsl #2
    8d2c:      	ldr	w12, [x12]
    8d30:      	sxtw	x12, w12
    8d34:      	cmp	x12, #0x0
    8d38:      	cset	w12, gt
    8d3c:      	ubfx	x12, x12, #0, #8
    8d40:      	b	0x8d48 <_stogir.stack.valid-frame-object-inputs?+0x3c4>
    8d44:      	movz	x12, #0x0, lsl #48
    8d48:      	b	0x8ce0 <_stogir.stack.valid-frame-object-inputs?+0x35c>
    8d4c:      	movz	x12, #0x0, lsl #48
    8d50:      	b	0x8d08 <_stogir.stack.valid-frame-object-inputs?+0x384>
    8d54:      	ldr	w1, [x7, #0x4]
    8d58:      	sxtw	x1, w1
    8d5c:      	b	0x8a1c <_stogir.stack.valid-frame-object-inputs?+0x98>
    8d60:      	brk	#0
    8d64:      	b	0x8d60 <_stogir.stack.valid-frame-object-inputs?+0x3dc>
    8d68:      	brk	#0
    8d6c:      	b	0x8d68 <_stogir.stack.valid-frame-object-inputs?+0x3e4>

0000000000008d70 <_stogir.stack.validate-scope-inputs>:
    8d70:      	sxtw	x1, w1
    8d74:      	cmp	x1, #0x53
    8d78:      	cset	w5, eq
    8d7c:      	uxtb	w16, w5
    8d80:      	cmp	w16, wzr
    8d84:      	b.ne	0x8db0 <_stogir.stack.validate-scope-inputs+0x40>
    8d88:      	cmp	x1, #0x54
    8d8c:      	b.eq	0x8db0 <_stogir.stack.validate-scope-inputs+0x40>
    8d90:      	mov	x0, #0x1                ; =1
    8d94:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008d94:  ARM64_RELOC_PAGE21	l_stogir.443
    8d98:      	ldr	x1, [x1]
		0000000000008d98:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    8d9c:      	mov	x2, #0x22               ; =34
    8da0:      	str	x0, [x8]
    8da4:      	str	x1, [x8, #0x8]
    8da8:      	str	x2, [x8, #0x10]
    8dac:      	ret
    8db0:      	uxtb	w16, w5
    8db4:      	cmp	w16, wzr
    8db8:      	mov	w16, #0x6               ; =6
    8dbc:      	movz	w17, #0x0, lsl #16
    8dc0:      	csel	w1, w16, w17, ne
    8dc4:      	sxtw	x2, w2
    8dc8:      	sxtw	x1, w1
    8dcc:      	cmp	x2, x1
    8dd0:      	b.ne	0x8d90 <_stogir.stack.validate-scope-inputs+0x20>
    8dd4:      	sxtw	x3, w3
    8dd8:      	cmp	x3, #0x0
    8ddc:      	cset	w1, gt
    8de0:      	movz	x16, #0x0, lsl #48
    8de4:      	sub	x2, x16, x3
    8de8:      	add	x6, x0, #0x28
    8dec:      	add	x7, x0, #0x78
    8df0:      	add	x9, x0, #0x50
    8df4:      	sub	x10, x2, #0x1
    8df8:      	uxtb	w16, w1
    8dfc:      	cmp	w16, wzr
    8e00:      	b.eq	0x8ecc <_stogir.stack.validate-scope-inputs+0x15c>
    8e04:      	ldr	x2, [x0, #0x8]
    8e08:      	cmp	x3, x2
    8e0c:      	b.ge	0x8ec4 <_stogir.stack.validate-scope-inputs+0x154>
    8e10:      	ldr	x2, [x7, #0x8]
    8e14:      	cmp	x3, x2
    8e18:      	b.ge	0x8f5c <_stogir.stack.validate-scope-inputs+0x1ec>
    8e1c:      	ldr	x2, [x0, #0x78]
    8e20:      	add	x2, x2, x3, lsl #2
    8e24:      	ldr	w2, [x2]
    8e28:      	sxtw	x2, w2
    8e2c:      	cmp	x2, #0x0
    8e30:      	cset	w2, ge
    8e34:      	ubfx	x2, x2, #0, #8
    8e38:      	b	0x8f60 <_stogir.stack.validate-scope-inputs+0x1f0>
    8e3c:      	movz	w2, #0x0, lsl #16
    8e40:      	movz	x1, #0x0, lsl #48
    8e44:      	ubfx	x2, x2, #0, #32
    8e48:      	lsr	x16, x2, #0
    8e4c:      	cmp	x16, #0x1
    8e50:      	b.eq	0x8e6c <_stogir.stack.validate-scope-inputs+0xfc>
    8e54:      	b.lo	0x8e5c <_stogir.stack.validate-scope-inputs+0xec>
    8e58:      	b	0x8e70 <_stogir.stack.validate-scope-inputs+0x100>
    8e5c:      	cmp	x16, #0x0
    8e60:      	b.eq	0x8e68 <_stogir.stack.validate-scope-inputs+0xf8>
    8e64:      	b	0x8e70 <_stogir.stack.validate-scope-inputs+0x100>
    8e68:      	b	0x8e74 <_stogir.stack.validate-scope-inputs+0x104>
    8e6c:      	b	0x8f0c <_stogir.stack.validate-scope-inputs+0x19c>
    8e70:      	b	0x9120 <_stogir.stack.validate-scope-inputs+0x3b0>
    8e74:      	mov	x0, #0x1                ; =1
    8e78:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008e78:  ARM64_RELOC_PAGE21	l_stogir.444
    8e7c:      	ldr	x1, [x1]
		0000000000008e7c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    8e80:      	mov	x2, #0x1b               ; =27
    8e84:      	b	0x8da0 <_stogir.stack.validate-scope-inputs+0x30>
    8e88:      	ldr	x1, [x0, #0x28]
    8e8c:      	add	x1, x1, x10, lsl #4
    8e90:      	ldr	x1, [x1]
    8e94:      	mov	w2, #0x1                ; =1
    8e98:      	b	0x8e44 <_stogir.stack.validate-scope-inputs+0xd4>
    8e9c:      	movz	x2, #0x0, lsl #48
    8ea0:      	cmp	x2, #0x0
    8ea4:      	b.eq	0x8e3c <_stogir.stack.validate-scope-inputs+0xcc>
    8ea8:      	uxtb	w16, w1
    8eac:      	cmp	w16, wzr
    8eb0:      	b.eq	0x8e88 <_stogir.stack.validate-scope-inputs+0x118>
    8eb4:      	ldr	x1, [x0]
    8eb8:      	add	x1, x1, x3, lsl #4
    8ebc:      	ldr	x1, [x1]
    8ec0:      	b	0x8e94 <_stogir.stack.validate-scope-inputs+0x124>
    8ec4:      	movz	x2, #0x0, lsl #48
    8ec8:      	b	0x8ea0 <_stogir.stack.validate-scope-inputs+0x130>
    8ecc:      	cmp	x3, #0x0
    8ed0:      	b.ge	0x8e9c <_stogir.stack.validate-scope-inputs+0x12c>
    8ed4:      	ldr	x11, [x6, #0x8]
    8ed8:      	ldr	x12, [x9, #0x8]
    8edc:      	cmp	x11, x12
    8ee0:      	b.ne	0x8f54 <_stogir.stack.validate-scope-inputs+0x1e4>
    8ee4:      	cmp	x2, x11
    8ee8:      	b.gt	0x8f64 <_stogir.stack.validate-scope-inputs+0x1f4>
    8eec:      	ldr	x2, [x0, #0x50]
    8ef0:      	add	x2, x2, x10, lsl #2
    8ef4:      	ldr	w2, [x2]
    8ef8:      	sxtw	x2, w2
    8efc:      	cmp	x2, #0x0
    8f00:      	cset	w2, gt
    8f04:      	ubfx	x2, x2, #0, #8
    8f08:      	b	0x8f68 <_stogir.stack.validate-scope-inputs+0x1f8>
    8f0c:      	cmp	x3, #0x0
    8f10:      	b.le	0x8f40 <_stogir.stack.validate-scope-inputs+0x1d0>
    8f14:      	uxtb	w1, w1
    8f18:      	cmp	x1, #0x83
    8f1c:      	cset	w2, lt
    8f20:      	uxtb	w16, w2
    8f24:      	cmp	w16, wzr
    8f28:      	b.eq	0x8f6c <_stogir.stack.validate-scope-inputs+0x1fc>
    8f2c:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008f2c:  ARM64_RELOC_PAGE21	l_stogir.445
    8f30:      	ldr	x17, [x17]
		0000000000008f30:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    8f34:      	add	x3, x1, x17
    8f38:      	ldrb	w3, [x3]
    8f3c:      	b	0x8f70 <_stogir.stack.validate-scope-inputs+0x200>
    8f40:      	mov	x0, #0x1                ; =1
    8f44:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008f44:  ARM64_RELOC_PAGE21	l_stogir.446
    8f48:      	ldr	x1, [x1]
		0000000000008f48:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    8f4c:      	mov	x2, #0x1b               ; =27
    8f50:      	b	0x8e84 <_stogir.stack.validate-scope-inputs+0x114>
    8f54:      	movz	x2, #0x0, lsl #48
    8f58:      	b	0x8ea0 <_stogir.stack.validate-scope-inputs+0x130>
    8f5c:      	movz	x2, #0x0, lsl #48
    8f60:      	b	0x8ec8 <_stogir.stack.validate-scope-inputs+0x158>
    8f64:      	movz	x2, #0x0, lsl #48
    8f68:      	b	0x8f58 <_stogir.stack.validate-scope-inputs+0x1e8>
    8f6c:      	movz	w3, #0x0, lsl #16
    8f70:      	uxtb	w16, w3
    8f74:      	and	w3, w16, #0x1
    8f78:      	uxtb	w3, w3
    8f7c:      	ubfx	x3, x3, #0, #8
    8f80:      	cmp	x3, #0x0
    8f84:      	b.eq	0x8f40 <_stogir.stack.validate-scope-inputs+0x1d0>
    8f88:      	uxtb	w16, w2
    8f8c:      	cmp	w16, wzr
    8f90:      	b.eq	0x8fa8 <_stogir.stack.validate-scope-inputs+0x238>
    8f94:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x29c>
		0000000000008f94:  ARM64_RELOC_PAGE21	l_stogir.445
    8f98:      	ldr	x17, [x17]
		0000000000008f98:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    8f9c:      	add	x1, x1, x17
    8fa0:      	ldrb	w1, [x1]
    8fa4:      	b	0x8fac <_stogir.stack.validate-scope-inputs+0x23c>
    8fa8:      	movz	w1, #0x0, lsl #16
    8fac:      	uxtb	w16, w1
    8fb0:      	and	w1, w16, #0x4
    8fb4:      	uxtb	w1, w1
    8fb8:      	ubfx	x1, x1, #0, #8
    8fbc:      	cmp	x1, #0x0
    8fc0:      	cset	w1, eq
    8fc4:      	uxtb	w16, w1
    8fc8:      	cmp	w16, wzr
    8fcc:      	cset	x1, eq
    8fd0:      	cmp	x1, #0x0
    8fd4:      	b.ne	0x8f40 <_stogir.stack.validate-scope-inputs+0x1d0>
    8fd8:      	uxtb	w16, w5
    8fdc:      	cmp	w16, wzr
    8fe0:      	b.eq	0x8ff4 <_stogir.stack.validate-scope-inputs+0x284>
    8fe4:      	movz	x0, #0x0, lsl #48
    8fe8:      	mov	x1, #0x8                ; =8
    8fec:      	movz	x2, #0x0, lsl #48
    8ff0:      	b	0x8f50 <_stogir.stack.validate-scope-inputs+0x1e0>
    8ff4:      	sxtw	x4, w4
    8ff8:      	cmp	x4, #0x0
    8ffc:      	cset	w1, gt
    9000:      	movz	x16, #0x0, lsl #48
    9004:      	sub	x2, x16, x4
    9008:      	sub	x3, x2, #0x1
    900c:      	uxtb	w16, w1
    9010:      	cmp	w16, wzr
    9014:      	b.eq	0x90e0 <_stogir.stack.validate-scope-inputs+0x370>
    9018:      	ldr	x2, [x0, #0x8]
    901c:      	cmp	x4, x2
    9020:      	b.ge	0x90d8 <_stogir.stack.validate-scope-inputs+0x368>
    9024:      	ldr	x2, [x7, #0x8]
    9028:      	cmp	x4, x2
    902c:      	b.ge	0x9174 <_stogir.stack.validate-scope-inputs+0x404>
    9030:      	ldr	x2, [x0, #0x78]
    9034:      	add	x2, x2, x4, lsl #2
    9038:      	ldr	w2, [x2]
    903c:      	sxtw	x2, w2
    9040:      	cmp	x2, #0x0
    9044:      	cset	w2, ge
    9048:      	ubfx	x2, x2, #0, #8
    904c:      	b	0x9178 <_stogir.stack.validate-scope-inputs+0x408>
    9050:      	movz	w1, #0x0, lsl #16
    9054:      	movz	x0, #0x0, lsl #48
    9058:      	ubfx	x1, x1, #0, #32
    905c:      	lsr	x16, x1, #0
    9060:      	cmp	x16, #0x1
    9064:      	b.eq	0x9080 <_stogir.stack.validate-scope-inputs+0x310>
    9068:      	b.lo	0x9070 <_stogir.stack.validate-scope-inputs+0x300>
    906c:      	b	0x9084 <_stogir.stack.validate-scope-inputs+0x314>
    9070:      	cmp	x16, #0x0
    9074:      	b.eq	0x907c <_stogir.stack.validate-scope-inputs+0x30c>
    9078:      	b	0x9084 <_stogir.stack.validate-scope-inputs+0x314>
    907c:      	b	0x9088 <_stogir.stack.validate-scope-inputs+0x318>
    9080:      	b	0x9128 <_stogir.stack.validate-scope-inputs+0x3b8>
    9084:      	b	0x9184 <_stogir.stack.validate-scope-inputs+0x414>
    9088:      	mov	x0, #0x1                ; =1
    908c:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		000000000000908c:  ARM64_RELOC_PAGE21	l_stogir.447
    9090:      	ldr	x1, [x1]
		0000000000009090:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    9094:      	mov	x2, #0x1b               ; =27
    9098:      	b	0x8ff0 <_stogir.stack.validate-scope-inputs+0x280>
    909c:      	ldr	x0, [x0, #0x28]
    90a0:      	add	x0, x0, x3, lsl #4
    90a4:      	ldr	x0, [x0]
    90a8:      	mov	w1, #0x1                ; =1
    90ac:      	b	0x9058 <_stogir.stack.validate-scope-inputs+0x2e8>
    90b0:      	movz	x2, #0x0, lsl #48
    90b4:      	cmp	x2, #0x0
    90b8:      	b.eq	0x9050 <_stogir.stack.validate-scope-inputs+0x2e0>
    90bc:      	uxtb	w16, w1
    90c0:      	cmp	w16, wzr
    90c4:      	b.eq	0x909c <_stogir.stack.validate-scope-inputs+0x32c>
    90c8:      	ldr	x0, [x0]
    90cc:      	add	x0, x0, x4, lsl #4
    90d0:      	ldr	x0, [x0]
    90d4:      	b	0x90a8 <_stogir.stack.validate-scope-inputs+0x338>
    90d8:      	movz	x2, #0x0, lsl #48
    90dc:      	b	0x90b4 <_stogir.stack.validate-scope-inputs+0x344>
    90e0:      	cmp	x4, #0x0
    90e4:      	b.ge	0x90b0 <_stogir.stack.validate-scope-inputs+0x340>
    90e8:      	ldr	x5, [x6, #0x8]
    90ec:      	ldr	x6, [x9, #0x8]
    90f0:      	cmp	x5, x6
    90f4:      	b.ne	0x916c <_stogir.stack.validate-scope-inputs+0x3fc>
    90f8:      	cmp	x2, x5
    90fc:      	b.gt	0x917c <_stogir.stack.validate-scope-inputs+0x40c>
    9100:      	ldr	x2, [x0, #0x50]
    9104:      	add	x2, x2, x3, lsl #2
    9108:      	ldr	w2, [x2]
    910c:      	sxtw	x2, w2
    9110:      	cmp	x2, #0x0
    9114:      	cset	w2, gt
    9118:      	ubfx	x2, x2, #0, #8
    911c:      	b	0x9180 <_stogir.stack.validate-scope-inputs+0x410>
    9120:      	brk	#0
    9124:      	b	0x9120 <_stogir.stack.validate-scope-inputs+0x3b0>
    9128:      	orr	w1, w0, wzr
    912c:      	ubfx	x1, x1, #0, #32
    9130:      	ubfx	x1, x1, #8, #8
    9134:      	cmp	x1, #0x6
    9138:      	b.ne	0x9158 <_stogir.stack.validate-scope-inputs+0x3e8>
    913c:      	uxtb	w0, w0
    9140:      	cmp	x0, #0x48
    9144:      	b.eq	0x9158 <_stogir.stack.validate-scope-inputs+0x3e8>
    9148:      	movz	x0, #0x0, lsl #48
    914c:      	mov	x1, #0x8                ; =8
    9150:      	movz	x2, #0x0, lsl #48
    9154:      	b	0x9168 <_stogir.stack.validate-scope-inputs+0x3f8>
    9158:      	mov	x0, #0x1                ; =1
    915c:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		000000000000915c:  ARM64_RELOC_PAGE21	l_stogir.448
    9160:      	ldr	x1, [x1]
		0000000000009160:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    9164:      	mov	x2, #0x29               ; =41
    9168:      	b	0x9098 <_stogir.stack.validate-scope-inputs+0x328>
    916c:      	movz	x2, #0x0, lsl #48
    9170:      	b	0x90b4 <_stogir.stack.validate-scope-inputs+0x344>
    9174:      	movz	x2, #0x0, lsl #48
    9178:      	b	0x90dc <_stogir.stack.validate-scope-inputs+0x36c>
    917c:      	movz	x2, #0x0, lsl #48
    9180:      	b	0x9170 <_stogir.stack.validate-scope-inputs+0x400>
    9184:      	brk	#0
    9188:      	b	0x9184 <_stogir.stack.validate-scope-inputs+0x414>

000000000000918c <_stogir.stack.validate-inputs>:
    918c:      	sub	sp, sp, #0x110
    9190:      	str	x29, [sp]
    9194:      	str	x30, [sp, #0x8]
    9198:      	mov	x29, sp
    919c:      	str	x19, [sp, #0xb8]
    91a0:      	str	x20, [sp, #0xc0]
    91a4:      	str	x21, [sp, #0xc8]
    91a8:      	str	x22, [sp, #0xd0]
    91ac:      	str	x23, [sp, #0xd8]
    91b0:      	str	x24, [sp, #0xe0]
    91b4:      	str	x25, [sp, #0xe8]
    91b8:      	str	x26, [sp, #0xf0]
    91bc:      	str	x27, [sp, #0xf8]
    91c0:      	str	x28, [sp, #0x100]
    91c4:      	sxtw	x1, w1
    91c8:      	cmp	x1, #0x51
    91cc:      	cset	w19, eq
    91d0:      	uxtb	w16, w19
    91d4:      	cmp	w16, wzr
    91d8:      	b.ne	0x9240 <_stogir.stack.validate-inputs+0xb4>
    91dc:      	cmp	x1, #0x52
    91e0:      	b.eq	0x9240 <_stogir.stack.validate-inputs+0xb4>
    91e4:      	str	x8, [sp, #0x90]
    91e8:      	mov	x2, #0x1                ; =1
    91ec:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		00000000000091ec:  ARM64_RELOC_PAGE21	l_stogir.449
    91f0:      	ldr	x1, [x1]
		00000000000091f0:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    91f4:      	mov	x0, #0x29               ; =41
    91f8:      	ldr	x3, [sp, #0x90]
    91fc:      	str	x2, [x3]
    9200:      	str	x1, [x3, #0x8]
    9204:      	str	x0, [x3, #0x10]
    9208:      	ldr	x19, [sp, #0xb8]
    920c:      	ldr	x20, [sp, #0xc0]
    9210:      	ldr	x21, [sp, #0xc8]
    9214:      	ldr	x22, [sp, #0xd0]
    9218:      	ldr	x23, [sp, #0xd8]
    921c:      	ldr	x24, [sp, #0xe0]
    9220:      	ldr	x25, [sp, #0xe8]
    9224:      	ldr	x26, [sp, #0xf0]
    9228:      	ldr	x27, [sp, #0xf8]
    922c:      	ldr	x28, [sp, #0x100]
    9230:      	ldr	x29, [sp]
    9234:      	ldr	x30, [sp, #0x8]
    9238:      	add	sp, sp, #0x110
    923c:      	ret
    9240:      	uxtb	w16, w19
    9244:      	cmp	w16, wzr
    9248:      	mov	w16, #0x6               ; =6
    924c:      	movz	w17, #0x0, lsl #16
    9250:      	csel	w1, w16, w17, ne
    9254:      	sxtw	x2, w2
    9258:      	sxtw	x1, w1
    925c:      	cmp	x2, x1
    9260:      	b.ne	0x9784 <_stogir.stack.validate-inputs+0x5f8>
    9264:      	sxtw	x20, w5
    9268:      	uxtb	w16, w19
    926c:      	cmp	w16, wzr
    9270:      	b.eq	0x9294 <_stogir.stack.validate-inputs+0x108>
    9274:      	cmp	x20, #0x0
    9278:      	b.eq	0x9294 <_stogir.stack.validate-inputs+0x108>
    927c:      	cmp	x20, #0x0
    9280:      	b.le	0x9328 <_stogir.stack.validate-inputs+0x19c>
    9284:      	sub	x1, x20, #0x1
    9288:      	and	x1, x1, x20
    928c:      	cmp	x1, #0x0
    9290:      	b.ne	0x9328 <_stogir.stack.validate-inputs+0x19c>
    9294:      	mov	w1, w3
    9298:      	mov	x21, x8
    929c:      	add	x8, sp, #0x10
    92a0:      	mov	x22, x0
    92a4:      	mov	w23, w3
    92a8:      	mov	w24, w4
    92ac:      	bl	0x92ac <_stogir.stack.validate-inputs+0x120>
		00000000000092ac:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    92b0:      	add	x16, sp, #0x10
    92b4:      	ldr	w0, [x16]
    92b8:      	lsr	x16, x0, #0
    92bc:      	cmp	x16, #0x1
    92c0:      	b.eq	0x92dc <_stogir.stack.validate-inputs+0x150>
    92c4:      	b.lo	0x92cc <_stogir.stack.validate-inputs+0x140>
    92c8:      	b	0x92e0 <_stogir.stack.validate-inputs+0x154>
    92cc:      	cmp	x16, #0x0
    92d0:      	b.eq	0x92d8 <_stogir.stack.validate-inputs+0x14c>
    92d4:      	b	0x92e0 <_stogir.stack.validate-inputs+0x154>
    92d8:      	b	0x92e4 <_stogir.stack.validate-inputs+0x158>
    92dc:      	b	0x92fc <_stogir.stack.validate-inputs+0x170>
    92e0:      	b	0x95a0 <_stogir.stack.validate-inputs+0x414>
    92e4:      	str	x21, [sp, #0x90]
    92e8:      	mov	x2, #0x1                ; =1
    92ec:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		00000000000092ec:  ARM64_RELOC_PAGE21	l_stogir.450
    92f0:      	ldr	x1, [x1]
		00000000000092f0:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    92f4:      	mov	x0, #0x1f               ; =31
    92f8:      	b	0x91f8 <_stogir.stack.validate-inputs+0x6c>
    92fc:      	sxtw	x23, w23
    9300:      	add	x16, sp, #0x10
    9304:      	ldr	x0, [x16, #0x8]
    9308:      	cmp	x23, #0x0
    930c:      	b.gt	0x9330 <_stogir.stack.validate-inputs+0x1a4>
    9310:      	str	x21, [sp, #0x90]
    9314:      	mov	x2, #0x1                ; =1
    9318:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009318:  ARM64_RELOC_PAGE21	l_stogir.451
    931c:      	ldr	x1, [x1]
		000000000000931c:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    9320:      	mov	x0, #0x1f               ; =31
    9324:      	b	0x92f8 <_stogir.stack.validate-inputs+0x16c>
    9328:      	str	x8, [sp, #0x90]
    932c:      	b	0x91e8 <_stogir.stack.validate-inputs+0x5c>
    9330:      	uxtb	w0, w0
    9334:      	cmp	x0, #0x83
    9338:      	cset	w1, lt
    933c:      	uxtb	w16, w1
    9340:      	cmp	w16, wzr
    9344:      	b.eq	0x935c <_stogir.stack.validate-inputs+0x1d0>
    9348:      	adrp	x17, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009348:  ARM64_RELOC_PAGE21	l_stogir.452
    934c:      	ldr	x17, [x17]
		000000000000934c:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9350:      	add	x2, x0, x17
    9354:      	ldrb	w2, [x2]
    9358:      	b	0x9360 <_stogir.stack.validate-inputs+0x1d4>
    935c:      	movz	w2, #0x0, lsl #16
    9360:      	uxtb	w16, w2
    9364:      	and	w2, w16, #0x1
    9368:      	uxtb	w2, w2
    936c:      	ubfx	x2, x2, #0, #8
    9370:      	cmp	x2, #0x0
    9374:      	b.eq	0x978c <_stogir.stack.validate-inputs+0x600>
    9378:      	uxtb	w16, w1
    937c:      	cmp	w16, wzr
    9380:      	b.eq	0x9398 <_stogir.stack.validate-inputs+0x20c>
    9384:      	adrp	x17, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009384:  ARM64_RELOC_PAGE21	l_stogir.452
    9388:      	ldr	x17, [x17]
		0000000000009388:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    938c:      	add	x0, x0, x17
    9390:      	ldrb	w0, [x0]
    9394:      	b	0x939c <_stogir.stack.validate-inputs+0x210>
    9398:      	movz	w0, #0x0, lsl #16
    939c:      	uxtb	w16, w0
    93a0:      	and	w0, w16, #0x4
    93a4:      	uxtb	w0, w0
    93a8:      	ubfx	x0, x0, #0, #8
    93ac:      	cmp	x0, #0x0
    93b0:      	cset	w0, eq
    93b4:      	uxtb	w16, w0
    93b8:      	cmp	w16, wzr
    93bc:      	cset	x0, eq
    93c0:      	cmp	x0, #0x0
    93c4:      	b.ne	0x9794 <_stogir.stack.validate-inputs+0x608>
    93c8:      	add	x8, sp, #0x40
    93cc:      	mov	x0, x22
    93d0:      	mov	w1, w24
    93d4:      	bl	0x93d4 <_stogir.stack.validate-inputs+0x248>
		00000000000093d4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    93d8:      	add	x16, sp, #0x40
    93dc:      	ldr	w0, [x16]
    93e0:      	lsr	x16, x0, #0
    93e4:      	cmp	x16, #0x1
    93e8:      	b.eq	0x9404 <_stogir.stack.validate-inputs+0x278>
    93ec:      	b.lo	0x93f4 <_stogir.stack.validate-inputs+0x268>
    93f0:      	b	0x9408 <_stogir.stack.validate-inputs+0x27c>
    93f4:      	cmp	x16, #0x0
    93f8:      	b.eq	0x9400 <_stogir.stack.validate-inputs+0x274>
    93fc:      	b	0x9408 <_stogir.stack.validate-inputs+0x27c>
    9400:      	b	0x940c <_stogir.stack.validate-inputs+0x280>
    9404:      	b	0x9424 <_stogir.stack.validate-inputs+0x298>
    9408:      	b	0x968c <_stogir.stack.validate-inputs+0x500>
    940c:      	str	x21, [sp, #0x90]
    9410:      	mov	x2, #0x1                ; =1
    9414:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009414:  ARM64_RELOC_PAGE21	l_stogir.453
    9418:      	ldr	x1, [x1]
		0000000000009418:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    941c:      	mov	x0, #0x18               ; =24
    9420:      	b	0x9324 <_stogir.stack.validate-inputs+0x198>
    9424:      	add	x16, sp, #0x40
    9428:      	ldr	x0, [x16, #0x8]
    942c:      	orr	w1, w0, wzr
    9430:      	ubfx	x1, x1, #0, #32
    9434:      	ubfx	x1, x1, #8, #8
    9438:      	cmp	x1, #0x1
    943c:      	b.lt	0x979c <_stogir.stack.validate-inputs+0x610>
    9440:      	cmp	x1, #0xb
    9444:      	b.gt	0x97a4 <_stogir.stack.validate-inputs+0x618>
    9448:      	uxtb	w0, w0
    944c:      	cmp	x0, #0x48
    9450:      	b.eq	0x97ac <_stogir.stack.validate-inputs+0x620>
    9454:      	sxtw	x0, w24
    9458:      	cmp	x1, #0x0
    945c:      	cset	w23, eq
    9460:      	cmp	x1, #0x1
    9464:      	cset	w25, eq
    9468:      	cmp	x1, #0x2
    946c:      	cset	w26, eq
    9470:      	cmp	x1, #0x7
    9474:      	cset	w27, eq
    9478:      	cmp	x1, #0x8
    947c:      	cset	w28, eq
    9480:      	cmp	x1, #0x3
    9484:      	cset	w2, eq
    9488:      	cmp	x1, #0x9
    948c:      	cset	w3, eq
    9490:      	cmp	x1, #0x4
    9494:      	cset	w4, eq
    9498:      	cmp	x1, #0xa
    949c:      	cset	w5, eq
    94a0:      	cmp	x1, #0xd
    94a4:      	cset	w6, eq
    94a8:      	cmp	x1, #0x5
    94ac:      	cset	w7, eq
    94b0:      	cmp	x1, #0xb
    94b4:      	cset	w8, eq
    94b8:      	cmp	x1, #0xc
    94bc:      	cset	w9, eq
    94c0:      	cmp	x1, #0x6
    94c4:      	cset	w1, eq
    94c8:      	uxtb	w16, w1
    94cc:      	cmp	w16, wzr
    94d0:      	mov	w16, #0x8               ; =8
    94d4:      	movn	w17, #0x0, lsl #16
    94d8:      	csel	w1, w16, w17, ne
    94dc:      	cmp	x0, #0x0
    94e0:      	b.ge	0x97b4 <_stogir.stack.validate-inputs+0x628>
    94e4:      	uxtb	w16, w19
    94e8:      	cmp	w16, wzr
    94ec:      	b.eq	0x94f8 <_stogir.stack.validate-inputs+0x36c>
    94f0:      	cmp	x20, #0x10
    94f4:      	b.gt	0x94fc <_stogir.stack.validate-inputs+0x370>
    94f8:      	mov	x20, #0x10              ; =16
    94fc:      	mov	x0, x22
    9500:      	mov	w19, w2
    9504:      	mov	x2, x20
    9508:      	mov	w20, w3
    950c:      	mov	w22, w4
    9510:      	str	w7, [sp, #0x98]
    9514:      	str	w8, [sp, #0xa0]
    9518:      	add	x8, sp, #0x70
    951c:      	str	w9, [sp, #0xa8]
    9520:      	str	w1, [sp, #0xb0]
    9524:      	mov	w1, w24
    9528:      	mov	w24, w5
    952c:      	str	x21, [sp, #0x90]
    9530:      	mov	w21, w6
    9534:      	bl	0x9534 <_stogir.stack.validate-inputs+0x3a8>
		0000000000009534:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    9538:      	add	x16, sp, #0x70
    953c:      	ldr	w0, [x16]
    9540:      	lsr	x16, x0, #0
    9544:      	cmp	x16, #0x1
    9548:      	b.eq	0x9564 <_stogir.stack.validate-inputs+0x3d8>
    954c:      	b.lo	0x9554 <_stogir.stack.validate-inputs+0x3c8>
    9550:      	b	0x9568 <_stogir.stack.validate-inputs+0x3dc>
    9554:      	cmp	x16, #0x0
    9558:      	b.eq	0x9560 <_stogir.stack.validate-inputs+0x3d4>
    955c:      	b	0x9568 <_stogir.stack.validate-inputs+0x3dc>
    9560:      	b	0x9694 <_stogir.stack.validate-inputs+0x508>
    9564:      	b	0x956c <_stogir.stack.validate-inputs+0x3e0>
    9568:      	b	0x9768 <_stogir.stack.validate-inputs+0x5dc>
    956c:      	add	x16, sp, #0x70
    9570:      	orr	x0, x16, xzr
    9574:      	add	x0, x0, #0x8
    9578:      	add	x16, sp, #0x70
    957c:      	ldr	x1, [x16, #0x8]
    9580:      	ldr	x0, [x0, #0x8]
    9584:      	mov	x2, #0x1                ; =1
    9588:      	b	0x95f0 <_stogir.stack.validate-inputs+0x464>
    958c:      	mov	x2, #0x1                ; =1
    9590:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009590:  ARM64_RELOC_PAGE21	l_stogir.454
    9594:      	ldr	x1, [x1]
		0000000000009594:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    9598:      	mov	x0, #0x29               ; =41
    959c:      	b	0x9420 <_stogir.stack.validate-inputs+0x294>
    95a0:      	brk	#0
    95a4:      	b	0x95a0 <_stogir.stack.validate-inputs+0x414>
    95a8:      	mov	w3, #0x1                ; =1
    95ac:      	sxtw	x3, w3
    95b0:      	and	x1, x3, #0xffffffff
    95b4:      	movz	x2, #0x0, lsl #48
    95b8:      	movz	x0, #0x0, lsl #48
    95bc:      	b	0x959c <_stogir.stack.validate-inputs+0x410>
    95c0:      	uxtb	w16, w23
    95c4:      	cmp	w16, wzr
    95c8:      	b.eq	0x95f4 <_stogir.stack.validate-inputs+0x468>
    95cc:      	movz	w3, #0x0, lsl #16
    95d0:      	b	0x95ac <_stogir.stack.validate-inputs+0x420>
    95d4:      	mov	w16, #0x1               ; =1
    95d8:      	str	w16, [sp, #0xb0]
    95dc:      	ldr	w3, [sp, #0xb0]
    95e0:      	sxtw	x3, w3
    95e4:      	and	x1, x3, #0xffffffff
    95e8:      	movz	x2, #0x0, lsl #48
    95ec:      	movz	x0, #0x0, lsl #48
    95f0:      	b	0x95bc <_stogir.stack.validate-inputs+0x430>
    95f4:      	uxtb	w16, w25
    95f8:      	cmp	w16, wzr
    95fc:      	b.ne	0x95a8 <_stogir.stack.validate-inputs+0x41c>
    9600:      	uxtb	w16, w26
    9604:      	cmp	w16, wzr
    9608:      	b.ne	0x95a8 <_stogir.stack.validate-inputs+0x41c>
    960c:      	uxtb	w16, w27
    9610:      	cmp	w16, wzr
    9614:      	b.ne	0x95a8 <_stogir.stack.validate-inputs+0x41c>
    9618:      	uxtb	w16, w28
    961c:      	cmp	w16, wzr
    9620:      	b.ne	0x95a8 <_stogir.stack.validate-inputs+0x41c>
    9624:      	uxtb	w16, w19
    9628:      	cmp	w16, wzr
    962c:      	b.ne	0x9754 <_stogir.stack.validate-inputs+0x5c8>
    9630:      	uxtb	w16, w20
    9634:      	cmp	w16, wzr
    9638:      	b.ne	0x9754 <_stogir.stack.validate-inputs+0x5c8>
    963c:      	uxtb	w16, w22
    9640:      	cmp	w16, wzr
    9644:      	b.ne	0x9770 <_stogir.stack.validate-inputs+0x5e4>
    9648:      	uxtb	w16, w24
    964c:      	cmp	w16, wzr
    9650:      	b.ne	0x9770 <_stogir.stack.validate-inputs+0x5e4>
    9654:      	uxtb	w16, w21
    9658:      	cmp	w16, wzr
    965c:      	b.ne	0x9770 <_stogir.stack.validate-inputs+0x5e4>
    9660:      	uxtb	w16, w0
    9664:      	cmp	w16, wzr
    9668:      	b.ne	0x9684 <_stogir.stack.validate-inputs+0x4f8>
    966c:      	uxtb	w16, w1
    9670:      	cmp	w16, wzr
    9674:      	b.ne	0x9684 <_stogir.stack.validate-inputs+0x4f8>
    9678:      	uxtb	w16, w2
    967c:      	cmp	w16, wzr
    9680:      	b.eq	0x9688 <_stogir.stack.validate-inputs+0x4fc>
    9684:      	mov	w3, #0x8                ; =8
    9688:      	b	0x9774 <_stogir.stack.validate-inputs+0x5e8>
    968c:      	brk	#0
    9690:      	b	0x968c <_stogir.stack.validate-inputs+0x500>
    9694:      	uxtb	w16, w23
    9698:      	cmp	w16, wzr
    969c:      	b.eq	0x96ac <_stogir.stack.validate-inputs+0x520>
    96a0:      	movz	w16, #0x0, lsl #16
    96a4:      	str	w16, [sp, #0xb0]
    96a8:      	b	0x95dc <_stogir.stack.validate-inputs+0x450>
    96ac:      	uxtb	w16, w25
    96b0:      	cmp	w16, wzr
    96b4:      	b.ne	0x95d4 <_stogir.stack.validate-inputs+0x448>
    96b8:      	uxtb	w16, w26
    96bc:      	cmp	w16, wzr
    96c0:      	b.ne	0x95d4 <_stogir.stack.validate-inputs+0x448>
    96c4:      	uxtb	w16, w27
    96c8:      	cmp	w16, wzr
    96cc:      	b.ne	0x95d4 <_stogir.stack.validate-inputs+0x448>
    96d0:      	uxtb	w16, w28
    96d4:      	cmp	w16, wzr
    96d8:      	b.ne	0x95d4 <_stogir.stack.validate-inputs+0x448>
    96dc:      	uxtb	w16, w19
    96e0:      	cmp	w16, wzr
    96e4:      	b.ne	0x975c <_stogir.stack.validate-inputs+0x5d0>
    96e8:      	uxtb	w16, w20
    96ec:      	cmp	w16, wzr
    96f0:      	b.ne	0x975c <_stogir.stack.validate-inputs+0x5d0>
    96f4:      	uxtb	w16, w22
    96f8:      	cmp	w16, wzr
    96fc:      	b.ne	0x9778 <_stogir.stack.validate-inputs+0x5ec>
    9700:      	uxtb	w16, w24
    9704:      	cmp	w16, wzr
    9708:      	b.ne	0x9778 <_stogir.stack.validate-inputs+0x5ec>
    970c:      	uxtb	w16, w21
    9710:      	cmp	w16, wzr
    9714:      	b.ne	0x9778 <_stogir.stack.validate-inputs+0x5ec>
    9718:      	ldr	w0, [sp, #0x98]
    971c:      	uxtb	w16, w0
    9720:      	cmp	w16, wzr
    9724:      	b.ne	0x9748 <_stogir.stack.validate-inputs+0x5bc>
    9728:      	ldr	w1, [sp, #0xa0]
    972c:      	uxtb	w16, w1
    9730:      	cmp	w16, wzr
    9734:      	b.ne	0x9748 <_stogir.stack.validate-inputs+0x5bc>
    9738:      	ldr	w2, [sp, #0xa8]
    973c:      	uxtb	w16, w2
    9740:      	cmp	w16, wzr
    9744:      	b.eq	0x9750 <_stogir.stack.validate-inputs+0x5c4>
    9748:      	mov	w16, #0x8               ; =8
    974c:      	str	w16, [sp, #0xb0]
    9750:      	b	0x9780 <_stogir.stack.validate-inputs+0x5f4>
    9754:      	mov	w3, #0x2                ; =2
    9758:      	b	0x95ac <_stogir.stack.validate-inputs+0x420>
    975c:      	mov	w16, #0x2               ; =2
    9760:      	str	w16, [sp, #0xb0]
    9764:      	b	0x95dc <_stogir.stack.validate-inputs+0x450>
    9768:      	brk	#0
    976c:      	b	0x9768 <_stogir.stack.validate-inputs+0x5dc>
    9770:      	mov	w3, #0x4                ; =4
    9774:      	b	0x9758 <_stogir.stack.validate-inputs+0x5cc>
    9778:      	mov	w16, #0x4               ; =4
    977c:      	str	w16, [sp, #0xb0]
    9780:      	b	0x9764 <_stogir.stack.validate-inputs+0x5d8>
    9784:      	str	x8, [sp, #0x90]
    9788:      	b	0x91e8 <_stogir.stack.validate-inputs+0x5c>
    978c:      	str	x21, [sp, #0x90]
    9790:      	b	0x9314 <_stogir.stack.validate-inputs+0x188>
    9794:      	str	x21, [sp, #0x90]
    9798:      	b	0x9314 <_stogir.stack.validate-inputs+0x188>
    979c:      	str	x21, [sp, #0x90]
    97a0:      	b	0x958c <_stogir.stack.validate-inputs+0x400>
    97a4:      	str	x21, [sp, #0x90]
    97a8:      	b	0x958c <_stogir.stack.validate-inputs+0x400>
    97ac:      	str	x21, [sp, #0x90]
    97b0:      	b	0x958c <_stogir.stack.validate-inputs+0x400>
    97b4:      	str	x21, [sp, #0x90]
    97b8:      	mov	w19, w2
    97bc:      	mov	w20, w3
    97c0:      	mov	w3, w1
    97c4:      	mov	w22, w4
    97c8:      	mov	w24, w5
    97cc:      	mov	w21, w6
    97d0:      	mov	w0, w7
    97d4:      	mov	w1, w8
    97d8:      	mov	w2, w9
    97dc:      	b	0x95c0 <_stogir.stack.validate-inputs+0x434>

00000000000097e0 <_stogir.locals.shape>:
    97e0:      	sub	sp, sp, #0x60
    97e4:      	str	x29, [sp]
    97e8:      	str	x30, [sp, #0x8]
    97ec:      	mov	x29, sp
    97f0:      	str	x19, [sp, #0x20]
    97f4:      	str	x20, [sp, #0x28]
    97f8:      	str	x21, [sp, #0x30]
    97fc:      	str	x22, [sp, #0x38]
    9800:      	str	x23, [sp, #0x40]
    9804:      	str	x24, [sp, #0x48]
    9808:      	str	x25, [sp, #0x50]
    980c:      	str	x26, [sp, #0x58]
    9810:      	sxtw	x19, w1
    9814:      	add	x20, x0, #0x78
    9818:      	add	x21, x0, #0x28
    981c:      	add	x22, x0, #0x50
    9820:      	lsl	x23, x19, #2
    9824:      	cmp	x19, #0x0
    9828:      	cset	w1, gt
    982c:      	movz	x16, #0x0, lsl #48
    9830:      	sub	x3, x16, x19
    9834:      	sub	x4, x3, #0x1
    9838:      	uxtb	w16, w1
    983c:      	cmp	w16, wzr
    9840:      	b.eq	0x987c <_stogir.locals.shape+0x9c>
    9844:      	ldr	x3, [x0, #0x8]
    9848:      	cmp	x19, x3
    984c:      	b.ge	0x98d8 <_stogir.locals.shape+0xf8>
    9850:      	ldr	x3, [x20, #0x8]
    9854:      	cmp	x19, x3
    9858:      	b.ge	0x9a74 <_stogir.locals.shape+0x294>
    985c:      	ldr	x3, [x0, #0x78]
    9860:      	add	x3, x23, x3
    9864:      	ldr	w3, [x3]
    9868:      	sxtw	x3, w3
    986c:      	cmp	x3, #0x0
    9870:      	cset	w3, ge
    9874:      	ubfx	x3, x3, #0, #8
    9878:      	b	0x9a78 <_stogir.locals.shape+0x298>
    987c:      	cmp	x19, #0x0
    9880:      	b.ge	0x98e0 <_stogir.locals.shape+0x100>
    9884:      	ldr	x5, [x21, #0x8]
    9888:      	ldr	x6, [x22, #0x8]
    988c:      	cmp	x5, x6
    9890:      	b.ne	0x98bc <_stogir.locals.shape+0xdc>
    9894:      	cmp	x3, x5
    9898:      	b.gt	0x9b70 <_stogir.locals.shape+0x390>
    989c:      	ldr	x3, [x0, #0x50]
    98a0:      	add	x3, x3, x4, lsl #2
    98a4:      	ldr	w3, [x3]
    98a8:      	sxtw	x3, w3
    98ac:      	cmp	x3, #0x0
    98b0:      	cset	w3, gt
    98b4:      	ubfx	x3, x3, #0, #8
    98b8:      	b	0x9b74 <_stogir.locals.shape+0x394>
    98bc:      	movz	x3, #0x0, lsl #48
    98c0:      	b	0x98e4 <_stogir.locals.shape+0x104>
    98c4:      	mov	x1, #0x1                ; =1
    98c8:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		00000000000098c8:  ARM64_RELOC_PAGE21	l_stogir.455
    98cc:      	ldr	x0, [x0]
		00000000000098cc:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    98d0:      	mov	x24, #0x1c              ; =28
    98d4:      	b	0x9974 <_stogir.locals.shape+0x194>
    98d8:      	movz	x3, #0x0, lsl #48
    98dc:      	b	0x98e4 <_stogir.locals.shape+0x104>
    98e0:      	movz	x3, #0x0, lsl #48
    98e4:      	cmp	x3, #0x0
    98e8:      	b.eq	0x9924 <_stogir.locals.shape+0x144>
    98ec:      	uxtb	w16, w1
    98f0:      	cmp	w16, wzr
    98f4:      	b.eq	0x990c <_stogir.locals.shape+0x12c>
    98f8:      	ldr	x1, [x0]
    98fc:      	add	x1, x1, x19, lsl #4
    9900:      	ldr	x3, [x1]
    9904:      	ldr	x1, [x1, #0x8]
    9908:      	b	0x991c <_stogir.locals.shape+0x13c>
    990c:      	ldr	x1, [x0, #0x28]
    9910:      	add	x1, x1, x4, lsl #4
    9914:      	ldr	x3, [x1]
    9918:      	ldr	x1, [x1, #0x8]
    991c:      	mov	w4, #0x1                ; =1
    9920:      	b	0x9930 <_stogir.locals.shape+0x150>
    9924:      	movz	w4, #0x0, lsl #16
    9928:      	movz	x3, #0x0, lsl #48
    992c:      	movz	x1, #0x0, lsl #48
    9930:      	ubfx	x4, x4, #0, #32
    9934:      	lsr	x16, x4, #0
    9938:      	cmp	x16, #0x1
    993c:      	b.eq	0x9958 <_stogir.locals.shape+0x178>
    9940:      	b.lo	0x9948 <_stogir.locals.shape+0x168>
    9944:      	b	0x995c <_stogir.locals.shape+0x17c>
    9948:      	cmp	x16, #0x0
    994c:      	b.eq	0x9954 <_stogir.locals.shape+0x174>
    9950:      	b	0x995c <_stogir.locals.shape+0x17c>
    9954:      	b	0x9960 <_stogir.locals.shape+0x180>
    9958:      	b	0x99b0 <_stogir.locals.shape+0x1d0>
    995c:      	b	0x9b80 <_stogir.locals.shape+0x3a0>
    9960:      	mov	x25, x8
    9964:      	mov	x1, #0x1                ; =1
    9968:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009968:  ARM64_RELOC_PAGE21	l_stogir.456
    996c:      	ldr	x0, [x0]
		000000000000996c:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9970:      	mov	x24, #0x16              ; =22
    9974:      	str	x1, [x25]
    9978:      	str	x0, [x25, #0x8]
    997c:      	str	x24, [x25, #0x10]
    9980:      	ldr	x19, [sp, #0x20]
    9984:      	ldr	x20, [sp, #0x28]
    9988:      	ldr	x21, [sp, #0x30]
    998c:      	ldr	x22, [sp, #0x38]
    9990:      	ldr	x23, [sp, #0x40]
    9994:      	ldr	x24, [sp, #0x48]
    9998:      	ldr	x25, [sp, #0x50]
    999c:      	ldr	x26, [sp, #0x58]
    99a0:      	ldr	x29, [sp]
    99a4:      	ldr	x30, [sp, #0x8]
    99a8:      	add	sp, sp, #0x60
    99ac:      	ret
    99b0:      	asr	x24, x1, #32
    99b4:      	orr	w4, w3, wzr
    99b8:      	add	x16, sp, #0x10
    99bc:      	str	x3, [x16]
    99c0:      	ubfx	x4, x4, #0, #32
    99c4:      	add	x16, sp, #0x10
    99c8:      	str	x1, [x16, #0x8]
    99cc:      	ubfx	x1, x4, #8, #8
    99d0:      	mov	x25, x8
    99d4:      	mov	x26, x0
    99d8:      	mov	w0, w1
    99dc:      	mov	w1, w2
    99e0:      	bl	0x99e0 <_stogir.locals.shape+0x200>
		00000000000099e0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    99e4:      	sxtw	x0, w0
    99e8:      	cmp	x24, #0x0
    99ec:      	b.ne	0x99f4 <_stogir.locals.shape+0x214>
    99f0:      	mov	x24, x0
    99f4:      	add	x16, sp, #0x10
    99f8:      	ldr	w1, [x16, #0x8]
    99fc:      	sxtw	x1, w1
    9a00:      	cmp	x1, #0x0
    9a04:      	cset	w2, eq
    9a08:      	ubfx	x2, x2, #0, #8
    9a0c:      	cmp	x1, #0x0
    9a10:      	b.le	0x9ab4 <_stogir.locals.shape+0x2d4>
    9a14:      	add	x3, x26, #0x110
    9a18:      	add	x4, x3, #0x28
    9a1c:      	ldr	x4, [x4, #0x8]
    9a20:      	cmp	x1, x4
    9a24:      	b.gt	0x9a7c <_stogir.locals.shape+0x29c>
    9a28:      	sub	x1, x1, #0x1
    9a2c:      	mov	x17, #0x18              ; =24
    9a30:      	mul	x1, x1, x17
    9a34:      	ldr	x4, [x3, #0x28]
    9a38:      	add	x1, x1, x4
    9a3c:      	ldr	x4, [x1]
    9a40:      	ldr	x1, [x1, #0x8]
    9a44:      	ldr	x3, [x3, #0x8]
    9a48:      	cmp	x4, #0x0
    9a4c:      	b.lt	0x9b78 <_stogir.locals.shape+0x398>
    9a50:      	cmp	x4, x3
    9a54:      	b.gt	0x9b78 <_stogir.locals.shape+0x398>
    9a58:      	cmp	x1, #0x0
    9a5c:      	b.lt	0x9b78 <_stogir.locals.shape+0x398>
    9a60:      	sub	x3, x3, x4
    9a64:      	cmp	x1, x3
    9a68:      	b.gt	0x9b78 <_stogir.locals.shape+0x398>
    9a6c:      	mov	w1, #0x1                ; =1
    9a70:      	b	0x9b7c <_stogir.locals.shape+0x39c>
    9a74:      	movz	x3, #0x0, lsl #48
    9a78:      	b	0x98dc <_stogir.locals.shape+0xfc>
    9a7c:      	movz	w1, #0x0, lsl #16
    9a80:      	ubfx	x1, x1, #0, #32
    9a84:      	lsr	x16, x1, #0
    9a88:      	cmp	x16, #0x1
    9a8c:      	b.eq	0x9aa8 <_stogir.locals.shape+0x2c8>
    9a90:      	b.lo	0x9a98 <_stogir.locals.shape+0x2b8>
    9a94:      	b	0x9aac <_stogir.locals.shape+0x2cc>
    9a98:      	cmp	x16, #0x0
    9a9c:      	b.eq	0x9aa4 <_stogir.locals.shape+0x2c4>
    9aa0:      	b	0x9aac <_stogir.locals.shape+0x2cc>
    9aa4:      	b	0x9ab4 <_stogir.locals.shape+0x2d4>
    9aa8:      	b	0x9ab0 <_stogir.locals.shape+0x2d0>
    9aac:      	b	0x9b88 <_stogir.locals.shape+0x3a8>
    9ab0:      	mov	x2, #0x1                ; =1
    9ab4:      	cmp	x19, #0x0
    9ab8:      	b.le	0x98c4 <_stogir.locals.shape+0xe4>
    9abc:      	add	x16, sp, #0x10
    9ac0:      	ldr	w1, [x16]
    9ac4:      	uxtb	w1, w1
    9ac8:      	cmp	x1, #0x48
    9acc:      	b.ne	0x98c4 <_stogir.locals.shape+0xe4>
    9ad0:      	ldr	x1, [x26, #0x78]
    9ad4:      	add	x3, x23, x1
    9ad8:      	ldr	w3, [x3]
    9adc:      	sxtw	x3, w3
    9ae0:      	cmp	x3, #0x3
    9ae4:      	b.ne	0x98c4 <_stogir.locals.shape+0xe4>
    9ae8:      	cmp	x0, #0x0
    9aec:      	b.le	0x98c4 <_stogir.locals.shape+0xe4>
    9af0:      	cmp	x2, #0x0
    9af4:      	b.eq	0x98c4 <_stogir.locals.shape+0xe4>
    9af8:      	cmp	x24, #0x0
    9afc:      	b.le	0x98c4 <_stogir.locals.shape+0xe4>
    9b00:      	sub	x2, x24, #0x1
    9b04:      	and	x2, x2, x24
    9b08:      	cmp	x2, #0x0
    9b0c:      	b.ne	0x98c4 <_stogir.locals.shape+0xe4>
    9b10:      	add	x16, sp, #0x10
    9b14:      	ldr	w2, [x16, #0x4]
    9b18:      	sxtw	x2, w2
    9b1c:      	cmp	x2, #0x0
    9b20:      	cset	w3, gt
    9b24:      	movz	x16, #0x0, lsl #48
    9b28:      	sub	x4, x16, x2
    9b2c:      	sub	x5, x4, #0x1
    9b30:      	uxtb	w16, w3
    9b34:      	cmp	w16, wzr
    9b38:      	b.eq	0x9ba4 <_stogir.locals.shape+0x3c4>
    9b3c:      	ldr	x4, [x26, #0x8]
    9b40:      	cmp	x2, x4
    9b44:      	b.ge	0x9be4 <_stogir.locals.shape+0x404>
    9b48:      	ldr	x4, [x20, #0x8]
    9b4c:      	cmp	x2, x4
    9b50:      	b.ge	0x9cb0 <_stogir.locals.shape+0x4d0>
    9b54:      	add	x1, x1, x2, lsl #2
    9b58:      	ldr	w1, [x1]
    9b5c:      	sxtw	x1, w1
    9b60:      	cmp	x1, #0x0
    9b64:      	cset	w1, ge
    9b68:      	ubfx	x1, x1, #0, #8
    9b6c:      	b	0x9cb4 <_stogir.locals.shape+0x4d4>
    9b70:      	movz	x3, #0x0, lsl #48
    9b74:      	b	0x98c0 <_stogir.locals.shape+0xe0>
    9b78:      	movz	w1, #0x0, lsl #16
    9b7c:      	b	0x9a80 <_stogir.locals.shape+0x2a0>
    9b80:      	brk	#0
    9b84:      	b	0x9b80 <_stogir.locals.shape+0x3a0>
    9b88:      	brk	#0
    9b8c:      	b	0x9b88 <_stogir.locals.shape+0x3a8>
    9b90:      	mov	x1, #0x1                ; =1
    9b94:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009b94:  ARM64_RELOC_PAGE21	l_stogir.457
    9b98:      	ldr	x0, [x0]
		0000000000009b98:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    9b9c:      	mov	x24, #0x2c              ; =44
    9ba0:      	b	0x98d4 <_stogir.locals.shape+0xf4>
    9ba4:      	cmp	x2, #0x0
    9ba8:      	b.ge	0x9bec <_stogir.locals.shape+0x40c>
    9bac:      	ldr	x1, [x21, #0x8]
    9bb0:      	ldr	x6, [x22, #0x8]
    9bb4:      	cmp	x1, x6
    9bb8:      	b.ne	0x9ca8 <_stogir.locals.shape+0x4c8>
    9bbc:      	cmp	x4, x1
    9bc0:      	b.gt	0x9cb8 <_stogir.locals.shape+0x4d8>
    9bc4:      	ldr	x1, [x26, #0x50]
    9bc8:      	add	x1, x1, x5, lsl #2
    9bcc:      	ldr	w1, [x1]
    9bd0:      	sxtw	x1, w1
    9bd4:      	cmp	x1, #0x0
    9bd8:      	cset	w1, gt
    9bdc:      	ubfx	x1, x1, #0, #8
    9be0:      	b	0x9cbc <_stogir.locals.shape+0x4dc>
    9be4:      	movz	x1, #0x0, lsl #48
    9be8:      	b	0x9bf0 <_stogir.locals.shape+0x410>
    9bec:      	movz	x1, #0x0, lsl #48
    9bf0:      	cmp	x1, #0x0
    9bf4:      	b.eq	0x9c28 <_stogir.locals.shape+0x448>
    9bf8:      	uxtb	w16, w3
    9bfc:      	cmp	w16, wzr
    9c00:      	b.eq	0x9c14 <_stogir.locals.shape+0x434>
    9c04:      	ldr	x1, [x26]
    9c08:      	add	x1, x1, x2, lsl #4
    9c0c:      	ldr	x1, [x1]
    9c10:      	b	0x9c20 <_stogir.locals.shape+0x440>
    9c14:      	ldr	x1, [x26, #0x28]
    9c18:      	add	x1, x1, x5, lsl #4
    9c1c:      	ldr	x1, [x1]
    9c20:      	mov	w2, #0x1                ; =1
    9c24:      	b	0x9c30 <_stogir.locals.shape+0x450>
    9c28:      	movz	w2, #0x0, lsl #16
    9c2c:      	movz	x1, #0x0, lsl #48
    9c30:      	ubfx	x2, x2, #0, #32
    9c34:      	lsr	x16, x2, #0
    9c38:      	cmp	x16, #0x1
    9c3c:      	b.eq	0x9c58 <_stogir.locals.shape+0x478>
    9c40:      	b.lo	0x9c48 <_stogir.locals.shape+0x468>
    9c44:      	b	0x9c5c <_stogir.locals.shape+0x47c>
    9c48:      	cmp	x16, #0x0
    9c4c:      	b.eq	0x9c54 <_stogir.locals.shape+0x474>
    9c50:      	b	0x9c5c <_stogir.locals.shape+0x47c>
    9c54:      	b	0x9c60 <_stogir.locals.shape+0x480>
    9c58:      	b	0x9c74 <_stogir.locals.shape+0x494>
    9c5c:      	b	0x9cf8 <_stogir.locals.shape+0x518>
    9c60:      	mov	x1, #0x1                ; =1
    9c64:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009c64:  ARM64_RELOC_PAGE21	l_stogir.458
    9c68:      	ldr	x0, [x0]
		0000000000009c68:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    9c6c:      	mov	x24, #0x1d              ; =29
    9c70:      	b	0x9ba0 <_stogir.locals.shape+0x3c0>
    9c74:      	add	x16, sp, #0x10
    9c78:      	ldr	w2, [x16, #0x4]
    9c7c:      	sxtw	x2, w2
    9c80:      	cmp	x2, #0x0
    9c84:      	b.le	0x9b90 <_stogir.locals.shape+0x3b0>
    9c88:      	uxtb	w1, w1
    9c8c:      	cmp	x1, #0x83
    9c90:      	b.ge	0x9cc0 <_stogir.locals.shape+0x4e0>
    9c94:      	adrp	x17, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009c94:  ARM64_RELOC_PAGE21	l_stogir.459
    9c98:      	ldr	x17, [x17]
		0000000000009c98:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    9c9c:      	add	x1, x1, x17
    9ca0:      	ldrb	w1, [x1]
    9ca4:      	b	0x9cc4 <_stogir.locals.shape+0x4e4>
    9ca8:      	movz	x1, #0x0, lsl #48
    9cac:      	b	0x9bf0 <_stogir.locals.shape+0x410>
    9cb0:      	movz	x1, #0x0, lsl #48
    9cb4:      	b	0x9be8 <_stogir.locals.shape+0x408>
    9cb8:      	movz	x1, #0x0, lsl #48
    9cbc:      	b	0x9cac <_stogir.locals.shape+0x4cc>
    9cc0:      	movz	w1, #0x0, lsl #16
    9cc4:      	uxtb	w16, w1
    9cc8:      	and	w1, w16, #0x2
    9ccc:      	uxtb	w1, w1
    9cd0:      	ubfx	x1, x1, #0, #8
    9cd4:      	cmp	x1, #0x0
    9cd8:      	cset	w1, eq
    9cdc:      	uxtb	w16, w1
    9ce0:      	cmp	w16, wzr
    9ce4:      	cset	x1, eq
    9ce8:      	cmp	x1, #0x0
    9cec:      	b.eq	0x9b90 <_stogir.locals.shape+0x3b0>
    9cf0:      	movz	x1, #0x0, lsl #48
    9cf4:      	b	0x9ba0 <_stogir.locals.shape+0x3c0>
    9cf8:      	brk	#0
    9cfc:      	b	0x9cf8 <_stogir.locals.shape+0x518>

0000000000009d00 <_stogir.conversion.policy>:
    9d00:      	sub	sp, sp, #0x70
    9d04:      	str	x29, [sp]
    9d08:      	str	x30, [sp, #0x8]
    9d0c:      	mov	x29, sp
    9d10:      	str	x19, [sp, #0x18]
    9d14:      	str	x20, [sp, #0x20]
    9d18:      	str	x21, [sp, #0x28]
    9d1c:      	str	x22, [sp, #0x30]
    9d20:      	str	x23, [sp, #0x38]
    9d24:      	str	x24, [sp, #0x40]
    9d28:      	str	x25, [sp, #0x48]
    9d2c:      	str	x26, [sp, #0x50]
    9d30:      	str	x27, [sp, #0x58]
    9d34:      	str	x28, [sp, #0x60]
    9d38:      	sxtw	x19, w0
    9d3c:      	sxtw	x20, w1
    9d40:      	sxtw	x21, w2
    9d44:      	cmp	x19, #0x24
    9d48:      	b.ne	0x9d84 <_stogir.conversion.policy+0x84>
    9d4c:      	cmp	x20, #0xf
    9d50:      	b.le	0x9f6c <_stogir.conversion.policy+0x26c>
    9d54:      	cmp	x20, #0x80
    9d58:      	b.ge	0x9f6c <_stogir.conversion.policy+0x26c>
    9d5c:      	and	w0, w1, #0xf
    9d60:      	ubfx	x0, x0, #0, #32
    9d64:      	cmp	x0, #0x1
    9d68:      	b.lt	0x9f6c <_stogir.conversion.policy+0x26c>
    9d6c:      	cmp	x0, #0xd
    9d70:      	b.gt	0x9f6c <_stogir.conversion.policy+0x26c>
    9d74:      	mov	x22, #0x1               ; =1
    9d78:      	b	0x9d80 <_stogir.conversion.policy+0x80>
    9d7c:      	movz	x22, #0x0, lsl #48
    9d80:      	b	0x9d88 <_stogir.conversion.policy+0x88>
    9d84:      	movz	x22, #0x0, lsl #48
    9d88:      	sxtw	x0, w3
    9d8c:      	cmp	x20, #0xd
    9d90:      	cset	w23, eq
    9d94:      	cmp	x20, #0xc
    9d98:      	cset	w24, eq
    9d9c:      	cmp	x0, #0x4
    9da0:      	cset	w25, eq
    9da4:      	cmp	x0, #0x8
    9da8:      	cset	w26, eq
    9dac:      	cmp	x22, #0x0
    9db0:      	b.eq	0xa230 <_stogir.conversion.policy+0x530>
    9db4:      	orr	w0, w3, wzr
    9db8:      	str	x8, [sp, #0x10]
    9dbc:      	mov	w28, w2
    9dc0:      	mov	w27, w3
    9dc4:      	fmov	s31, w0
    9dc8:      	mov	w0, w1
    9dcc:      	fmov	w1, s31
    9dd0:      	bl	0x9dd0 <_stogir.conversion.policy+0xd0>
		0000000000009dd0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    9dd4:      	b	0x9ddc <_stogir.conversion.policy+0xdc>
    9dd8:      	mov	w0, #0x1                ; =1
    9ddc:      	cmp	x21, #0xd
    9de0:      	cset	w1, eq
    9de4:      	cmp	x21, #0xc
    9de8:      	cset	w2, eq
    9dec:      	cmp	x22, #0x0
    9df0:      	b.eq	0xa240 <_stogir.conversion.policy+0x540>
    9df4:      	mov	w22, w0
    9df8:      	mov	w0, w28
    9dfc:      	mov	w28, w1
    9e00:      	mov	w1, w27
    9e04:      	mov	w25, w2
    9e08:      	bl	0x9e08 <_stogir.conversion.policy+0x108>
		0000000000009e08:  ARM64_RELOC_BRANCH26	_stogir.types.size
    9e0c:      	orr	w27, w0, wzr
    9e10:      	mov	w0, w25
    9e14:      	b	0x9e1c <_stogir.conversion.policy+0x11c>
    9e18:      	mov	w27, #0x1               ; =1
    9e1c:      	cmp	x19, #0x21
    9e20:      	b.lt	0x9ef4 <_stogir.conversion.policy+0x1f4>
    9e24:      	cmp	x19, #0x27
    9e28:      	b.gt	0x9ef4 <_stogir.conversion.policy+0x1f4>
    9e2c:      	lsl	w1, w22, #3
    9e30:      	sxtw	x1, w1
    9e34:      	cmp	x1, #0x0
    9e38:      	b.le	0x9ef4 <_stogir.conversion.policy+0x1f4>
    9e3c:      	lsl	w2, w27, #3
    9e40:      	sxtw	x2, w2
    9e44:      	cmp	x2, #0x0
    9e48:      	b.le	0x9ef4 <_stogir.conversion.policy+0x1f4>
    9e4c:      	cmp	x19, #0x26
    9e50:      	cset	w3, eq
    9e54:      	cmp	x20, #0x1
    9e58:      	cset	w4, ge
    9e5c:      	cmp	x20, #0xb
    9e60:      	cset	w5, le
    9e64:      	cmp	x21, #0x1
    9e68:      	cset	w6, ge
    9e6c:      	cmp	x21, #0xb
    9e70:      	cset	w7, le
    9e74:      	cmp	x19, #0x25
    9e78:      	b.lt	0xa0ec <_stogir.conversion.policy+0x3ec>
    9e7c:      	ubfx	x8, x28, #0, #8
    9e80:      	cmp	x19, #0x25
    9e84:      	b.ne	0xa15c <_stogir.conversion.policy+0x45c>
    9e88:      	uxtb	w16, w4
    9e8c:      	cmp	w16, wzr
    9e90:      	b.eq	0xa154 <_stogir.conversion.policy+0x454>
    9e94:      	uxtb	w16, w5
    9e98:      	cmp	w16, wzr
    9e9c:      	b.eq	0xa154 <_stogir.conversion.policy+0x454>
    9ea0:      	uxtb	w16, w0
    9ea4:      	cmp	w16, wzr
    9ea8:      	b.eq	0x9eb0 <_stogir.conversion.policy+0x1b0>
    9eac:      	mov	x8, #0x1                ; =1
    9eb0:      	b	0xa158 <_stogir.conversion.policy+0x458>
    9eb4:      	uxtb	w16, w25
    9eb8:      	cmp	w16, wzr
    9ebc:      	b.ne	0x9f4c <_stogir.conversion.policy+0x24c>
    9ec0:      	uxtb	w16, w26
    9ec4:      	cmp	w16, wzr
    9ec8:      	b.ne	0x9f4c <_stogir.conversion.policy+0x24c>
    9ecc:      	movn	w27, #0x0, lsl #16
    9ed0:      	b	0x9e1c <_stogir.conversion.policy+0x11c>
    9ed4:      	uxtb	w16, w25
    9ed8:      	cmp	w16, wzr
    9edc:      	b.ne	0x9f5c <_stogir.conversion.policy+0x25c>
    9ee0:      	uxtb	w16, w26
    9ee4:      	cmp	w16, wzr
    9ee8:      	b.ne	0x9f5c <_stogir.conversion.policy+0x25c>
    9eec:      	movn	w0, #0x0, lsl #16
    9ef0:      	b	0x9ddc <_stogir.conversion.policy+0xdc>
    9ef4:      	mov	x1, #0x1                ; =1
    9ef8:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x290>
		0000000000009ef8:  ARM64_RELOC_PAGE21	l_stogir.460
    9efc:      	ldr	x0, [x0]
		0000000000009efc:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    9f00:      	mov	x2, #0x22               ; =34
    9f04:      	ldr	x3, [sp, #0x10]
    9f08:      	str	x1, [x3]
    9f0c:      	str	x0, [x3, #0x8]
    9f10:      	str	x2, [x3, #0x10]
    9f14:      	ldr	x19, [sp, #0x18]
    9f18:      	ldr	x20, [sp, #0x20]
    9f1c:      	ldr	x21, [sp, #0x28]
    9f20:      	ldr	x22, [sp, #0x30]
    9f24:      	ldr	x23, [sp, #0x38]
    9f28:      	ldr	x24, [sp, #0x40]
    9f2c:      	ldr	x25, [sp, #0x48]
    9f30:      	ldr	x26, [sp, #0x50]
    9f34:      	ldr	x27, [sp, #0x58]
    9f38:      	ldr	x28, [sp, #0x60]
    9f3c:      	ldr	x29, [sp]
    9f40:      	ldr	x30, [sp, #0x8]
    9f44:      	add	sp, sp, #0x70
    9f48:      	ret
    9f4c:      	cmp	x21, #0x0
    9f50:      	b.ne	0x9fa4 <_stogir.conversion.policy+0x2a4>
    9f54:      	movz	w27, #0x0, lsl #16
    9f58:      	b	0x9e1c <_stogir.conversion.policy+0x11c>
    9f5c:      	cmp	x20, #0x0
    9f60:      	b.ne	0xa01c <_stogir.conversion.policy+0x31c>
    9f64:      	movz	w0, #0x0, lsl #16
    9f68:      	b	0x9ddc <_stogir.conversion.policy+0xdc>
    9f6c:      	cmp	x21, #0xf
    9f70:      	b.le	0x9d7c <_stogir.conversion.policy+0x7c>
    9f74:      	cmp	x21, #0x80
    9f78:      	b.ge	0x9f9c <_stogir.conversion.policy+0x29c>
    9f7c:      	and	w0, w2, #0xf
    9f80:      	ubfx	x0, x0, #0, #32
    9f84:      	cmp	x0, #0x1
    9f88:      	b.lt	0xa094 <_stogir.conversion.policy+0x394>
    9f8c:      	cmp	x0, #0xd
    9f90:      	cset	w0, le
    9f94:      	ubfx	x22, x0, #0, #8
    9f98:      	b	0xa098 <_stogir.conversion.policy+0x398>
    9f9c:      	movz	x22, #0x0, lsl #48
    9fa0:      	b	0x9d80 <_stogir.conversion.policy+0x80>
    9fa4:      	cmp	x21, #0x1
    9fa8:      	b.eq	0x9e18 <_stogir.conversion.policy+0x118>
    9fac:      	cmp	x21, #0x2
    9fb0:      	b.eq	0x9e18 <_stogir.conversion.policy+0x118>
    9fb4:      	cmp	x21, #0x7
    9fb8:      	b.eq	0x9e18 <_stogir.conversion.policy+0x118>
    9fbc:      	cmp	x21, #0x8
    9fc0:      	b.eq	0x9e18 <_stogir.conversion.policy+0x118>
    9fc4:      	cmp	x21, #0x3
    9fc8:      	b.eq	0xa188 <_stogir.conversion.policy+0x488>
    9fcc:      	cmp	x21, #0x9
    9fd0:      	b.eq	0xa188 <_stogir.conversion.policy+0x488>
    9fd4:      	cmp	x21, #0x4
    9fd8:      	b.eq	0xa1f8 <_stogir.conversion.policy+0x4f8>
    9fdc:      	cmp	x21, #0xa
    9fe0:      	b.eq	0xa1f8 <_stogir.conversion.policy+0x4f8>
    9fe4:      	uxtb	w16, w28
    9fe8:      	cmp	w16, wzr
    9fec:      	b.ne	0xa1f8 <_stogir.conversion.policy+0x4f8>
    9ff0:      	cmp	x21, #0x5
    9ff4:      	b.eq	0xa218 <_stogir.conversion.policy+0x518>
    9ff8:      	cmp	x21, #0xb
    9ffc:      	b.eq	0xa218 <_stogir.conversion.policy+0x518>
    a000:      	uxtb	w16, w0
    a004:      	cmp	w16, wzr
    a008:      	b.ne	0xa218 <_stogir.conversion.policy+0x518>
    a00c:      	cmp	x21, #0x6
    a010:      	b.eq	0xa018 <_stogir.conversion.policy+0x318>
    a014:      	movn	w27, #0x0, lsl #16
    a018:      	b	0xa21c <_stogir.conversion.policy+0x51c>
    a01c:      	cmp	x20, #0x1
    a020:      	b.eq	0x9dd8 <_stogir.conversion.policy+0xd8>
    a024:      	cmp	x20, #0x2
    a028:      	b.eq	0x9dd8 <_stogir.conversion.policy+0xd8>
    a02c:      	cmp	x20, #0x7
    a030:      	b.eq	0x9dd8 <_stogir.conversion.policy+0xd8>
    a034:      	cmp	x20, #0x8
    a038:      	b.eq	0x9dd8 <_stogir.conversion.policy+0xd8>
    a03c:      	cmp	x20, #0x3
    a040:      	b.eq	0xa190 <_stogir.conversion.policy+0x490>
    a044:      	cmp	x20, #0x9
    a048:      	b.eq	0xa190 <_stogir.conversion.policy+0x490>
    a04c:      	cmp	x20, #0x4
    a050:      	b.eq	0xa200 <_stogir.conversion.policy+0x500>
    a054:      	cmp	x20, #0xa
    a058:      	b.eq	0xa200 <_stogir.conversion.policy+0x500>
    a05c:      	uxtb	w16, w23
    a060:      	cmp	w16, wzr
    a064:      	b.ne	0xa200 <_stogir.conversion.policy+0x500>
    a068:      	cmp	x20, #0x5
    a06c:      	b.eq	0xa220 <_stogir.conversion.policy+0x520>
    a070:      	cmp	x20, #0xb
    a074:      	b.eq	0xa220 <_stogir.conversion.policy+0x520>
    a078:      	uxtb	w16, w24
    a07c:      	cmp	w16, wzr
    a080:      	b.ne	0xa220 <_stogir.conversion.policy+0x520>
    a084:      	cmp	x20, #0x6
    a088:      	b.ne	0xa228 <_stogir.conversion.policy+0x528>
    a08c:      	mov	w0, w27
    a090:      	b	0xa22c <_stogir.conversion.policy+0x52c>
    a094:      	movz	x22, #0x0, lsl #48
    a098:      	b	0x9fa0 <_stogir.conversion.policy+0x2a0>
    a09c:      	mov	x0, #0x1                ; =1
    a0a0:      	cmp	x0, #0x0
    a0a4:      	b.ne	0x9ef4 <_stogir.conversion.policy+0x1f4>
    a0a8:      	cmp	x19, #0x23
    a0ac:      	b.eq	0xa0bc <_stogir.conversion.policy+0x3bc>
    a0b0:      	uxtb	w16, w3
    a0b4:      	cmp	w16, wzr
    a0b8:      	b.eq	0xa0c0 <_stogir.conversion.policy+0x3c0>
    a0bc:      	mov	x1, x2
    a0c0:      	and	x0, x1, #0xffffffff
    a0c4:      	movz	x1, #0x0, lsl #48
    a0c8:      	movz	x2, #0x0, lsl #48
    a0cc:      	b	0x9f04 <_stogir.conversion.policy+0x204>
    a0d0:      	movz	x8, #0x0, lsl #48
    a0d4:      	cmp	x8, #0x0
    a0d8:      	cset	w0, ne
    a0dc:      	uxtb	w16, w0
    a0e0:      	cmp	w16, wzr
    a0e4:      	cset	x0, eq
    a0e8:      	b	0xa0a0 <_stogir.conversion.policy+0x3a0>
    a0ec:      	cmp	x19, #0x24
    a0f0:      	b.ne	0xa10c <_stogir.conversion.policy+0x40c>
    a0f4:      	cmp	x1, x2
    a0f8:      	cset	w0, eq
    a0fc:      	uxtb	w16, w0
    a100:      	cmp	w16, wzr
    a104:      	cset	x0, eq
    a108:      	b	0xa0a0 <_stogir.conversion.policy+0x3a0>
    a10c:      	uxtb	w16, w4
    a110:      	cmp	w16, wzr
    a114:      	b.eq	0xa09c <_stogir.conversion.policy+0x39c>
    a118:      	uxtb	w16, w5
    a11c:      	cmp	w16, wzr
    a120:      	b.eq	0xa09c <_stogir.conversion.policy+0x39c>
    a124:      	uxtb	w16, w6
    a128:      	cmp	w16, wzr
    a12c:      	b.eq	0xa1c8 <_stogir.conversion.policy+0x4c8>
    a130:      	uxtb	w16, w7
    a134:      	cmp	w16, wzr
    a138:      	b.eq	0xa1c8 <_stogir.conversion.policy+0x4c8>
    a13c:      	cmp	x19, #0x23
    a140:      	b.ne	0xa208 <_stogir.conversion.policy+0x508>
    a144:      	cmp	x2, x1
    a148:      	cset	w0, ge
    a14c:      	ubfx	x0, x0, #0, #8
    a150:      	b	0xa214 <_stogir.conversion.policy+0x514>
    a154:      	movz	x8, #0x0, lsl #48
    a158:      	b	0xa0d4 <_stogir.conversion.policy+0x3d4>
    a15c:      	uxtb	w16, w3
    a160:      	cmp	w16, wzr
    a164:      	b.eq	0xa1a0 <_stogir.conversion.policy+0x4a0>
    a168:      	uxtb	w16, w24
    a16c:      	cmp	w16, wzr
    a170:      	b.ne	0xa1e4 <_stogir.conversion.policy+0x4e4>
    a174:      	uxtb	w16, w23
    a178:      	cmp	w16, wzr
    a17c:      	b.ne	0xa1e4 <_stogir.conversion.policy+0x4e4>
    a180:      	movz	x8, #0x0, lsl #48
    a184:      	b	0xa19c <_stogir.conversion.policy+0x49c>
    a188:      	mov	w27, #0x2               ; =2
    a18c:      	b	0x9e1c <_stogir.conversion.policy+0x11c>
    a190:      	mov	w0, #0x2                ; =2
    a194:      	b	0x9ddc <_stogir.conversion.policy+0xdc>
    a198:      	movz	x8, #0x0, lsl #48
    a19c:      	b	0xa0d4 <_stogir.conversion.policy+0x3d4>
    a1a0:      	cmp	x19, #0x27
    a1a4:      	b.ne	0xa0d0 <_stogir.conversion.policy+0x3d0>
    a1a8:      	uxtb	w16, w24
    a1ac:      	cmp	w16, wzr
    a1b0:      	b.ne	0xa1d0 <_stogir.conversion.policy+0x4d0>
    a1b4:      	uxtb	w16, w23
    a1b8:      	cmp	w16, wzr
    a1bc:      	b.ne	0xa1d0 <_stogir.conversion.policy+0x4d0>
    a1c0:      	movz	x8, #0x0, lsl #48
    a1c4:      	b	0xa1e0 <_stogir.conversion.policy+0x4e0>
    a1c8:      	mov	x0, #0x1                ; =1
    a1cc:      	b	0xa0a0 <_stogir.conversion.policy+0x3a0>
    a1d0:      	uxtb	w16, w0
    a1d4:      	cmp	w16, wzr
    a1d8:      	b.eq	0xa1e0 <_stogir.conversion.policy+0x4e0>
    a1dc:      	mov	x8, #0x1                ; =1
    a1e0:      	b	0xa0d4 <_stogir.conversion.policy+0x3d4>
    a1e4:      	uxtb	w16, w6
    a1e8:      	cmp	w16, wzr
    a1ec:      	b.eq	0xa198 <_stogir.conversion.policy+0x498>
    a1f0:      	ubfx	x8, x7, #0, #8
    a1f4:      	b	0xa19c <_stogir.conversion.policy+0x49c>
    a1f8:      	mov	w27, #0x4               ; =4
    a1fc:      	b	0xa18c <_stogir.conversion.policy+0x48c>
    a200:      	mov	w0, #0x4                ; =4
    a204:      	b	0xa194 <_stogir.conversion.policy+0x494>
    a208:      	cmp	x2, x1
    a20c:      	cset	w0, le
    a210:      	ubfx	x0, x0, #0, #8
    a214:      	b	0xa1cc <_stogir.conversion.policy+0x4cc>
    a218:      	mov	w27, #0x8               ; =8
    a21c:      	b	0xa1fc <_stogir.conversion.policy+0x4fc>
    a220:      	mov	w0, #0x8                ; =8
    a224:      	b	0xa204 <_stogir.conversion.policy+0x504>
    a228:      	movn	w0, #0x0, lsl #16
    a22c:      	b	0xa224 <_stogir.conversion.policy+0x524>
    a230:      	str	x8, [sp, #0x10]
    a234:      	mov	w28, w2
    a238:      	mov	w27, w3
    a23c:      	b	0x9ed4 <_stogir.conversion.policy+0x1d4>
    a240:      	mov	w22, w0
    a244:      	mov	w28, w1
    a248:      	mov	w0, w2
    a24c:      	b	0x9eb4 <_stogir.conversion.policy+0x1b4>

000000000000a250 <_stogir.conditional.operands>:
    a250:      	sub	sp, sp, #0x20
    a254:      	sxtw	x5, w1
    a258:      	cmp	x5, #0x0
    a25c:      	b.eq	0xa2a8 <_stogir.conditional.operands+0x58>
    a260:      	cmp	x5, #0x0
    a264:      	b.lt	0xa280 <_stogir.conditional.operands+0x30>
    a268:      	cmp	x5, #0xd
    a26c:      	b.gt	0xa280 <_stogir.conditional.operands+0x30>
    a270:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a270:  ARM64_RELOC_PAGE21	l_stogir.461
    a274:      	ldr	x1, [x1]
		000000000000a274:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    a278:      	movz	x6, #0x0, lsl #48
    a27c:      	b	0xa2b4 <_stogir.conditional.operands+0x64>
    a280:      	cmp	x5, #0xf
    a284:      	b.le	0xa2a8 <_stogir.conditional.operands+0x58>
    a288:      	cmp	x5, #0x80
    a28c:      	b.ge	0xa2a8 <_stogir.conditional.operands+0x58>
    a290:      	and	w1, w1, #0xf
    a294:      	ubfx	x1, x1, #0, #32
    a298:      	cmp	x1, #0x1
    a29c:      	b.lt	0xa2a8 <_stogir.conditional.operands+0x58>
    a2a0:      	cmp	x1, #0xd
    a2a4:      	b.le	0xa270 <_stogir.conditional.operands+0x20>
    a2a8:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a2a8:  ARM64_RELOC_PAGE21	l_stogir.462
    a2ac:      	ldr	x1, [x1]
		000000000000a2ac:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    a2b0:      	mov	x6, #0x2b               ; =43
    a2b4:      	sxtw	x2, w2
    a2b8:      	add	x7, x0, #0x28
    a2bc:      	add	x9, x0, #0x78
    a2c0:      	add	x10, x0, #0x50
    a2c4:      	cmp	x2, #0x0
    a2c8:      	cset	w11, gt
    a2cc:      	movz	x16, #0x0, lsl #48
    a2d0:      	sub	x12, x16, x2
    a2d4:      	sub	x13, x12, #0x1
    a2d8:      	uxtb	w16, w11
    a2dc:      	cmp	w16, wzr
    a2e0:      	b.eq	0xa31c <_stogir.conditional.operands+0xcc>
    a2e4:      	ldr	x12, [x0, #0x8]
    a2e8:      	cmp	x2, x12
    a2ec:      	b.ge	0xa36c <_stogir.conditional.operands+0x11c>
    a2f0:      	ldr	x12, [x9, #0x8]
    a2f4:      	cmp	x2, x12
    a2f8:      	b.ge	0xa660 <_stogir.conditional.operands+0x410>
    a2fc:      	ldr	x12, [x0, #0x78]
    a300:      	add	x12, x12, x2, lsl #2
    a304:      	ldr	w12, [x12]
    a308:      	sxtw	x12, w12
    a30c:      	cmp	x12, #0x0
    a310:      	cset	w12, ge
    a314:      	ubfx	x12, x12, #0, #8
    a318:      	b	0xa664 <_stogir.conditional.operands+0x414>
    a31c:      	cmp	x2, #0x0
    a320:      	b.ge	0xa374 <_stogir.conditional.operands+0x124>
    a324:      	ldr	x14, [x7, #0x8]
    a328:      	ldr	x15, [x10, #0x8]
    a32c:      	cmp	x14, x15
    a330:      	b.ne	0xa35c <_stogir.conditional.operands+0x10c>
    a334:      	cmp	x12, x14
    a338:      	b.gt	0xa668 <_stogir.conditional.operands+0x418>
    a33c:      	ldr	x12, [x0, #0x50]
    a340:      	add	x12, x12, x13, lsl #2
    a344:      	ldr	w12, [x12]
    a348:      	sxtw	x12, w12
    a34c:      	cmp	x12, #0x0
    a350:      	cset	w12, gt
    a354:      	ubfx	x12, x12, #0, #8
    a358:      	b	0xa66c <_stogir.conditional.operands+0x41c>
    a35c:      	movz	x12, #0x0, lsl #48
    a360:      	b	0xa378 <_stogir.conditional.operands+0x128>
    a364:      	movz	x12, #0x0, lsl #48
    a368:      	b	0xa404 <_stogir.conditional.operands+0x1b4>
    a36c:      	movz	x12, #0x0, lsl #48
    a370:      	b	0xa378 <_stogir.conditional.operands+0x128>
    a374:      	movz	x12, #0x0, lsl #48
    a378:      	cmp	x12, #0x0
    a37c:      	b.eq	0xa3b0 <_stogir.conditional.operands+0x160>
    a380:      	uxtb	w16, w11
    a384:      	cmp	w16, wzr
    a388:      	b.eq	0xa39c <_stogir.conditional.operands+0x14c>
    a38c:      	ldr	x11, [x0]
    a390:      	add	x2, x11, x2, lsl #4
    a394:      	ldr	x2, [x2]
    a398:      	b	0xa3a8 <_stogir.conditional.operands+0x158>
    a39c:      	ldr	x2, [x0, #0x28]
    a3a0:      	add	x2, x2, x13, lsl #4
    a3a4:      	ldr	x2, [x2]
    a3a8:      	mov	w11, #0x1               ; =1
    a3ac:      	b	0xa3b8 <_stogir.conditional.operands+0x168>
    a3b0:      	movz	w11, #0x0, lsl #16
    a3b4:      	movz	x2, #0x0, lsl #48
    a3b8:      	ubfx	x11, x11, #0, #32
    a3bc:      	lsr	x16, x11, #0
    a3c0:      	cmp	x16, #0x1
    a3c4:      	b.eq	0xa3e0 <_stogir.conditional.operands+0x190>
    a3c8:      	b.lo	0xa3d0 <_stogir.conditional.operands+0x180>
    a3cc:      	b	0xa3e4 <_stogir.conditional.operands+0x194>
    a3d0:      	cmp	x16, #0x0
    a3d4:      	b.eq	0xa3dc <_stogir.conditional.operands+0x18c>
    a3d8:      	b	0xa3e4 <_stogir.conditional.operands+0x194>
    a3dc:      	b	0xa3e8 <_stogir.conditional.operands+0x198>
    a3e0:      	b	0xa408 <_stogir.conditional.operands+0x1b8>
    a3e4:      	b	0xa680 <_stogir.conditional.operands+0x430>
    a3e8:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a3e8:  ARM64_RELOC_PAGE21	l_stogir.463
    a3ec:      	ldr	x1, [x1]
		000000000000a3ec:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    a3f0:      	mov	x6, #0x16               ; =22
    a3f4:      	b	0xa448 <_stogir.conditional.operands+0x1f8>
    a3f8:      	movz	x12, #0x0, lsl #48
    a3fc:      	b	0xa47c <_stogir.conditional.operands+0x22c>
    a400:      	movz	x12, #0x0, lsl #48
    a404:      	b	0xa484 <_stogir.conditional.operands+0x234>
    a408:      	uxtb	w11, w2
    a40c:      	cmp	x11, #0x48
    a410:      	b.eq	0xa43c <_stogir.conditional.operands+0x1ec>
    a414:      	cmp	x11, #0x46
    a418:      	b.eq	0xa43c <_stogir.conditional.operands+0x1ec>
    a41c:      	ubfx	x11, x2, #0, #32
    a420:      	ubfx	x11, x11, #8, #8
    a424:      	cmp	x11, #0x0
    a428:      	b.eq	0xa43c <_stogir.conditional.operands+0x1ec>
    a42c:      	ubfx	x2, x2, #0, #32
    a430:      	ubfx	x2, x2, #8, #8
    a434:      	cmp	x2, #0xd
    a438:      	b.le	0xa448 <_stogir.conditional.operands+0x1f8>
    a43c:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a43c:  ARM64_RELOC_PAGE21	l_stogir.464
    a440:      	ldr	x1, [x1]
		000000000000a440:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    a444:      	mov	x6, #0x2a               ; =42
    a448:      	add	x16, sp, #0x10
    a44c:      	orr	x2, x16, xzr
    a450:      	mov	x16, sp
    a454:      	str	w3, [x16]
    a458:      	mov	x16, sp
    a45c:      	str	w4, [x16, #0x4]
    a460:      	mov	x16, sp
    a464:      	ldr	x3, [x16]
    a468:      	add	x16, sp, #0x10
    a46c:      	str	x3, [x16]
    a470:      	movz	x3, #0x0, lsl #48
    a474:      	b	0xa534 <_stogir.conditional.operands+0x2e4>
    a478:      	movz	x12, #0x0, lsl #48
    a47c:      	b	0xa484 <_stogir.conditional.operands+0x234>
    a480:      	movz	x12, #0x0, lsl #48
    a484:      	cmp	x12, #0x0
    a488:      	b.eq	0xa4bc <_stogir.conditional.operands+0x26c>
    a48c:      	uxtb	w16, w4
    a490:      	cmp	w16, wzr
    a494:      	b.eq	0xa4a8 <_stogir.conditional.operands+0x258>
    a498:      	ldr	x4, [x0]
    a49c:      	add	x4, x4, x11, lsl #4
    a4a0:      	ldr	x4, [x4]
    a4a4:      	b	0xa4b4 <_stogir.conditional.operands+0x264>
    a4a8:      	ldr	x4, [x0, #0x28]
    a4ac:      	add	x4, x4, x13, lsl #4
    a4b0:      	ldr	x4, [x4]
    a4b4:      	mov	w11, #0x1               ; =1
    a4b8:      	b	0xa4c4 <_stogir.conditional.operands+0x274>
    a4bc:      	movz	w11, #0x0, lsl #16
    a4c0:      	movz	x4, #0x0, lsl #48
    a4c4:      	ubfx	x11, x11, #0, #32
    a4c8:      	lsr	x16, x11, #0
    a4cc:      	cmp	x16, #0x1
    a4d0:      	b.eq	0xa4ec <_stogir.conditional.operands+0x29c>
    a4d4:      	b.lo	0xa4dc <_stogir.conditional.operands+0x28c>
    a4d8:      	b	0xa4f0 <_stogir.conditional.operands+0x2a0>
    a4dc:      	cmp	x16, #0x0
    a4e0:      	b.eq	0xa4e8 <_stogir.conditional.operands+0x298>
    a4e4:      	b	0xa4f0 <_stogir.conditional.operands+0x2a0>
    a4e8:      	b	0xa4f4 <_stogir.conditional.operands+0x2a4>
    a4ec:      	b	0xa504 <_stogir.conditional.operands+0x2b4>
    a4f0:      	b	0xa678 <_stogir.conditional.operands+0x428>
    a4f4:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a4f4:  ARM64_RELOC_PAGE21	l_stogir.465
    a4f8:      	ldr	x1, [x1]
		000000000000a4f8:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    a4fc:      	mov	x6, #0x10               ; =16
    a500:      	b	0xa534 <_stogir.conditional.operands+0x2e4>
    a504:      	uxtb	w11, w4
    a508:      	cmp	x11, #0x48
    a50c:      	b.eq	0xa528 <_stogir.conditional.operands+0x2d8>
    a510:      	cmp	x11, #0x46
    a514:      	b.eq	0xa528 <_stogir.conditional.operands+0x2d8>
    a518:      	ubfx	x4, x4, #0, #32
    a51c:      	ubfx	x4, x4, #8, #8
    a520:      	cmp	x4, x5
    a524:      	b.eq	0xa534 <_stogir.conditional.operands+0x2e4>
    a528:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a528:  ARM64_RELOC_PAGE21	l_stogir.466
    a52c:      	ldr	x1, [x1]
		000000000000a52c:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    a530:      	mov	x6, #0x21               ; =33
    a534:      	cmp	x3, #0x2
    a538:      	b.ge	0xa55c <_stogir.conditional.operands+0x30c>
    a53c:      	add	x4, x3, #0x1
    a540:      	add	x3, x2, x3, lsl #2
    a544:      	ldr	w3, [x3]
    a548:      	movn	w17, #0x0, lsl #16
    a54c:      	and	w11, w3, w17
    a550:      	mov	x3, x4
    a554:      	mov	w4, #0x1                ; =1
    a558:      	b	0xa564 <_stogir.conditional.operands+0x314>
    a55c:      	movz	w4, #0x0, lsl #16
    a560:      	movz	w11, #0x0, lsl #16
    a564:      	ubfx	x4, x4, #0, #32
    a568:      	lsr	x16, x4, #0
    a56c:      	cmp	x16, #0x1
    a570:      	b.eq	0xa58c <_stogir.conditional.operands+0x33c>
    a574:      	b.lo	0xa57c <_stogir.conditional.operands+0x32c>
    a578:      	b	0xa590 <_stogir.conditional.operands+0x340>
    a57c:      	cmp	x16, #0x0
    a580:      	b.eq	0xa588 <_stogir.conditional.operands+0x338>
    a584:      	b	0xa590 <_stogir.conditional.operands+0x340>
    a588:      	b	0xa5f0 <_stogir.conditional.operands+0x3a0>
    a58c:      	b	0xa594 <_stogir.conditional.operands+0x344>
    a590:      	b	0xa670 <_stogir.conditional.operands+0x420>
    a594:      	sxtw	x11, w11
    a598:      	cmp	x11, #0x0
    a59c:      	cset	w4, gt
    a5a0:      	movz	x16, #0x0, lsl #48
    a5a4:      	sub	x12, x16, x11
    a5a8:      	sub	x13, x12, #0x1
    a5ac:      	uxtb	w16, w4
    a5b0:      	cmp	w16, wzr
    a5b4:      	b.eq	0xa620 <_stogir.conditional.operands+0x3d0>
    a5b8:      	ldr	x12, [x0, #0x8]
    a5bc:      	cmp	x11, x12
    a5c0:      	b.ge	0xa478 <_stogir.conditional.operands+0x228>
    a5c4:      	ldr	x12, [x9, #0x8]
    a5c8:      	cmp	x11, x12
    a5cc:      	b.ge	0xa3f8 <_stogir.conditional.operands+0x1a8>
    a5d0:      	ldr	x12, [x0, #0x78]
    a5d4:      	add	x12, x12, x11, lsl #2
    a5d8:      	ldr	w12, [x12]
    a5dc:      	sxtw	x12, w12
    a5e0:      	cmp	x12, #0x0
    a5e4:      	cset	w12, ge
    a5e8:      	ubfx	x12, x12, #0, #8
    a5ec:      	b	0xa3fc <_stogir.conditional.operands+0x1ac>
    a5f0:      	cmp	x6, #0x0
    a5f4:      	b.ne	0xa608 <_stogir.conditional.operands+0x3b8>
    a5f8:      	and	x1, x5, #0xffffffff
    a5fc:      	movz	x0, #0x0, lsl #48
    a600:      	movz	x6, #0x0, lsl #48
    a604:      	b	0xa60c <_stogir.conditional.operands+0x3bc>
    a608:      	mov	x0, #0x1                ; =1
    a60c:      	str	x0, [x8]
    a610:      	str	x1, [x8, #0x8]
    a614:      	str	x6, [x8, #0x10]
    a618:      	add	sp, sp, #0x20
    a61c:      	ret
    a620:      	cmp	x11, #0x0
    a624:      	b.ge	0xa480 <_stogir.conditional.operands+0x230>
    a628:      	ldr	x14, [x7, #0x8]
    a62c:      	ldr	x15, [x10, #0x8]
    a630:      	cmp	x14, x15
    a634:      	b.ne	0xa400 <_stogir.conditional.operands+0x1b0>
    a638:      	cmp	x12, x14
    a63c:      	b.gt	0xa364 <_stogir.conditional.operands+0x114>
    a640:      	ldr	x12, [x0, #0x50]
    a644:      	add	x12, x12, x13, lsl #2
    a648:      	ldr	w12, [x12]
    a64c:      	sxtw	x12, w12
    a650:      	cmp	x12, #0x0
    a654:      	cset	w12, gt
    a658:      	ubfx	x12, x12, #0, #8
    a65c:      	b	0xa368 <_stogir.conditional.operands+0x118>
    a660:      	movz	x12, #0x0, lsl #48
    a664:      	b	0xa370 <_stogir.conditional.operands+0x120>
    a668:      	movz	x12, #0x0, lsl #48
    a66c:      	b	0xa360 <_stogir.conditional.operands+0x110>
    a670:      	brk	#0
    a674:      	b	0xa670 <_stogir.conditional.operands+0x420>
    a678:      	brk	#0
    a67c:      	b	0xa678 <_stogir.conditional.operands+0x428>
    a680:      	brk	#0
    a684:      	b	0xa680 <_stogir.conditional.operands+0x430>

000000000000a688 <_stogir.floating.operands>:
    a688:      	sub	sp, sp, #0x90
    a68c:      	str	x29, [sp]
    a690:      	str	x30, [sp, #0x8]
    a694:      	mov	x29, sp
    a698:      	str	x19, [sp, #0x60]
    a69c:      	str	x20, [sp, #0x68]
    a6a0:      	str	x21, [sp, #0x70]
    a6a4:      	str	x22, [sp, #0x78]
    a6a8:      	str	x23, [sp, #0x80]
    a6ac:      	sxtw	x1, w1
    a6b0:      	sxtw	x19, w2
    a6b4:      	cmp	x1, #0x1f
    a6b8:      	cset	w2, eq
    a6bc:      	cmp	x1, #0x20
    a6c0:      	cset	w6, eq
    a6c4:      	cmp	x1, #0xe
    a6c8:      	b.lt	0xa6f4 <_stogir.floating.operands+0x6c>
    a6cc:      	cmp	x1, #0x19
    a6d0:      	b.gt	0xa6f4 <_stogir.floating.operands+0x6c>
    a6d4:      	cmp	x19, #0xc
    a6d8:      	b.eq	0xa790 <_stogir.floating.operands+0x108>
    a6dc:      	cmp	x19, #0xd
    a6e0:      	b.eq	0xa790 <_stogir.floating.operands+0x108>
    a6e4:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a6e4:  ARM64_RELOC_PAGE21	l_stogir.467
    a6e8:      	ldr	x20, [x20]
		000000000000a6e8:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    a6ec:      	mov	x21, #0x22              ; =34
    a6f0:      	b	0xa79c <_stogir.floating.operands+0x114>
    a6f4:      	uxtb	w16, w2
    a6f8:      	cmp	w16, wzr
    a6fc:      	b.ne	0xa6d4 <_stogir.floating.operands+0x4c>
    a700:      	uxtb	w16, w6
    a704:      	cmp	w16, wzr
    a708:      	b.ne	0xa6d4 <_stogir.floating.operands+0x4c>
    a70c:      	cmp	x1, #0x1a
    a710:      	b.lt	0xa71c <_stogir.floating.operands+0x94>
    a714:      	cmp	x1, #0x1d
    a718:      	b.le	0xa6d4 <_stogir.floating.operands+0x4c>
    a71c:      	cmp	x1, #0x3a
    a720:      	b.eq	0xa6d4 <_stogir.floating.operands+0x4c>
    a724:      	cmp	x1, #0x3b
    a728:      	b.eq	0xa6d4 <_stogir.floating.operands+0x4c>
    a72c:      	b	0xa6e4 <_stogir.floating.operands+0x5c>
    a730:      	movz	w1, #0x0, lsl #16
    a734:      	uxtb	w16, w1
    a738:      	and	w1, w16, #0x2
    a73c:      	uxtb	w1, w1
    a740:      	ubfx	x1, x1, #0, #8
    a744:      	cmp	x1, #0x0
    a748:      	cset	w1, eq
    a74c:      	uxtb	w16, w1
    a750:      	cmp	w16, wzr
    a754:      	cset	x1, eq
    a758:      	cmp	x1, #0x0
    a75c:      	b.ne	0xa77c <_stogir.floating.operands+0xf4>
    a760:      	cmp	x0, #0x65
    a764:      	b.eq	0xa77c <_stogir.floating.operands+0xf4>
    a768:      	cmp	x0, #0x66
    a76c:      	b.eq	0xa77c <_stogir.floating.operands+0xf4>
    a770:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a770:  ARM64_RELOC_PAGE21	l_stogir.468
    a774:      	ldr	x20, [x20]
		000000000000a774:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    a778:      	mov	x21, #0x2d              ; =45
    a77c:      	b	0xa88c <_stogir.floating.operands+0x204>
    a780:      	movz	x11, #0x0, lsl #48
    a784:      	b	0xa7f8 <_stogir.floating.operands+0x170>
    a788:      	movz	x11, #0x0, lsl #48
    a78c:      	b	0xa800 <_stogir.floating.operands+0x178>
    a790:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a790:  ARM64_RELOC_PAGE21	l_stogir.469
    a794:      	ldr	x20, [x20]
		000000000000a794:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a798:      	movz	x21, #0x0, lsl #48
    a79c:      	add	x16, sp, #0x10
    a7a0:      	str	w3, [x16]
    a7a4:      	uxtb	w16, w2
    a7a8:      	cmp	w16, wzr
    a7ac:      	b.ne	0xa7c0 <_stogir.floating.operands+0x138>
    a7b0:      	uxtb	w16, w6
    a7b4:      	cmp	w16, wzr
    a7b8:      	b.ne	0xa7c0 <_stogir.floating.operands+0x138>
    a7bc:      	orr	w3, w4, wzr
    a7c0:      	add	x16, sp, #0x20
    a7c4:      	orr	x2, x16, xzr
    a7c8:      	add	x4, x0, #0x28
    a7cc:      	add	x6, x0, #0x78
    a7d0:      	add	x7, x0, #0x50
    a7d4:      	add	x16, sp, #0x10
    a7d8:      	str	w3, [x16, #0x4]
    a7dc:      	add	x16, sp, #0x10
    a7e0:      	ldr	x3, [x16]
    a7e4:      	add	x16, sp, #0x20
    a7e8:      	str	x3, [x16]
    a7ec:      	movz	x3, #0x0, lsl #48
    a7f0:      	b	0xa8ac <_stogir.floating.operands+0x224>
    a7f4:      	movz	x11, #0x0, lsl #48
    a7f8:      	b	0xa800 <_stogir.floating.operands+0x178>
    a7fc:      	movz	x11, #0x0, lsl #48
    a800:      	cmp	x11, #0x0
    a804:      	b.eq	0xa838 <_stogir.floating.operands+0x1b0>
    a808:      	uxtb	w16, w9
    a80c:      	cmp	w16, wzr
    a810:      	b.eq	0xa824 <_stogir.floating.operands+0x19c>
    a814:      	ldr	x9, [x0]
    a818:      	add	x9, x9, x10, lsl #4
    a81c:      	ldr	x9, [x9]
    a820:      	b	0xa830 <_stogir.floating.operands+0x1a8>
    a824:      	ldr	x9, [x0, #0x28]
    a828:      	add	x9, x9, x12, lsl #4
    a82c:      	ldr	x9, [x9]
    a830:      	mov	w10, #0x1               ; =1
    a834:      	b	0xa840 <_stogir.floating.operands+0x1b8>
    a838:      	movz	w10, #0x0, lsl #16
    a83c:      	movz	x9, #0x0, lsl #48
    a840:      	ubfx	x10, x10, #0, #32
    a844:      	lsr	x16, x10, #0
    a848:      	cmp	x16, #0x1
    a84c:      	b.eq	0xa868 <_stogir.floating.operands+0x1e0>
    a850:      	b.lo	0xa858 <_stogir.floating.operands+0x1d0>
    a854:      	b	0xa86c <_stogir.floating.operands+0x1e4>
    a858:      	cmp	x16, #0x0
    a85c:      	b.eq	0xa864 <_stogir.floating.operands+0x1dc>
    a860:      	b	0xa86c <_stogir.floating.operands+0x1e4>
    a864:      	b	0xa870 <_stogir.floating.operands+0x1e8>
    a868:      	b	0xa890 <_stogir.floating.operands+0x208>
    a86c:      	b	0xaaa0 <_stogir.floating.operands+0x418>
    a870:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a870:  ARM64_RELOC_PAGE21	l_stogir.470
    a874:      	ldr	x20, [x20]
		000000000000a874:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    a878:      	mov	x21, #0x18              ; =24
    a87c:      	b	0xa8ac <_stogir.floating.operands+0x224>
    a880:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a880:  ARM64_RELOC_PAGE21	l_stogir.471
    a884:      	ldr	x20, [x20]
		000000000000a884:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    a888:      	mov	x21, #0x21              ; =33
    a88c:      	b	0xa978 <_stogir.floating.operands+0x2f0>
    a890:      	ubfx	x9, x9, #0, #32
    a894:      	ubfx	x9, x9, #8, #8
    a898:      	cmp	x9, x19
    a89c:      	b.eq	0xa8ac <_stogir.floating.operands+0x224>
    a8a0:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a8a0:  ARM64_RELOC_PAGE21	l_stogir.472
    a8a4:      	ldr	x20, [x20]
		000000000000a8a4:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    a8a8:      	mov	x21, #0x1e              ; =30
    a8ac:      	cmp	x3, #0x2
    a8b0:      	b.ge	0xa8d4 <_stogir.floating.operands+0x24c>
    a8b4:      	add	x9, x3, #0x1
    a8b8:      	add	x3, x2, x3, lsl #2
    a8bc:      	ldr	w3, [x3]
    a8c0:      	movn	w17, #0x0, lsl #16
    a8c4:      	and	w10, w3, w17
    a8c8:      	mov	x3, x9
    a8cc:      	mov	w9, #0x1                ; =1
    a8d0:      	b	0xa8dc <_stogir.floating.operands+0x254>
    a8d4:      	movz	w9, #0x0, lsl #16
    a8d8:      	movz	w10, #0x0, lsl #16
    a8dc:      	ubfx	x9, x9, #0, #32
    a8e0:      	lsr	x16, x9, #0
    a8e4:      	cmp	x16, #0x1
    a8e8:      	b.eq	0xa904 <_stogir.floating.operands+0x27c>
    a8ec:      	b.lo	0xa8f4 <_stogir.floating.operands+0x26c>
    a8f0:      	b	0xa908 <_stogir.floating.operands+0x280>
    a8f4:      	cmp	x16, #0x0
    a8f8:      	b.eq	0xa900 <_stogir.floating.operands+0x278>
    a8fc:      	b	0xa908 <_stogir.floating.operands+0x280>
    a900:      	b	0xa968 <_stogir.floating.operands+0x2e0>
    a904:      	b	0xa90c <_stogir.floating.operands+0x284>
    a908:      	b	0xaa98 <_stogir.floating.operands+0x410>
    a90c:      	sxtw	x10, w10
    a910:      	cmp	x10, #0x0
    a914:      	cset	w9, gt
    a918:      	movz	x16, #0x0, lsl #48
    a91c:      	sub	x11, x16, x10
    a920:      	sub	x12, x11, #0x1
    a924:      	uxtb	w16, w9
    a928:      	cmp	w16, wzr
    a92c:      	b.eq	0xa9ec <_stogir.floating.operands+0x364>
    a930:      	ldr	x11, [x0, #0x8]
    a934:      	cmp	x10, x11
    a938:      	b.ge	0xa7f4 <_stogir.floating.operands+0x16c>
    a93c:      	ldr	x11, [x6, #0x8]
    a940:      	cmp	x10, x11
    a944:      	b.ge	0xa780 <_stogir.floating.operands+0xf8>
    a948:      	ldr	x11, [x0, #0x78]
    a94c:      	add	x11, x11, x10, lsl #2
    a950:      	ldr	w11, [x11]
    a954:      	sxtw	x11, w11
    a958:      	cmp	x11, #0x0
    a95c:      	cset	w11, ge
    a960:      	ubfx	x11, x11, #0, #8
    a964:      	b	0xa784 <_stogir.floating.operands+0xfc>
    a968:      	sxtw	x22, w5
    a96c:      	cmp	x22, #0x0
    a970:      	b.ne	0xa990 <_stogir.floating.operands+0x308>
    a974:      	mov	x23, x8
    a978:      	cmp	x21, #0x0
    a97c:      	b.ne	0xaa2c <_stogir.floating.operands+0x3a4>
    a980:      	and	x20, x19, #0xffffffff
    a984:      	movz	x0, #0x0, lsl #48
    a988:      	movz	x21, #0x0, lsl #48
    a98c:      	b	0xaa30 <_stogir.floating.operands+0x3a8>
    a990:      	cmp	x1, #0x1d
    a994:      	b.ne	0xaab0 <_stogir.floating.operands+0x428>
    a998:      	mov	w1, w5
    a99c:      	mov	x23, x8
    a9a0:      	add	x8, sp, #0x30
    a9a4:      	bl	0xa9a4 <_stogir.floating.operands+0x31c>
		000000000000a9a4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    a9a8:      	add	x16, sp, #0x30
    a9ac:      	ldr	w0, [x16]
    a9b0:      	lsr	x16, x0, #0
    a9b4:      	cmp	x16, #0x1
    a9b8:      	b.eq	0xa9d4 <_stogir.floating.operands+0x34c>
    a9bc:      	b.lo	0xa9c4 <_stogir.floating.operands+0x33c>
    a9c0:      	b	0xa9d8 <_stogir.floating.operands+0x350>
    a9c4:      	cmp	x16, #0x0
    a9c8:      	b.eq	0xa9d0 <_stogir.floating.operands+0x348>
    a9cc:      	b	0xa9d8 <_stogir.floating.operands+0x350>
    a9d0:      	b	0xa9dc <_stogir.floating.operands+0x354>
    a9d4:      	b	0xaa68 <_stogir.floating.operands+0x3e0>
    a9d8:      	b	0xaaa8 <_stogir.floating.operands+0x420>
    a9dc:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000a9dc:  ARM64_RELOC_PAGE21	l_stogir.473
    a9e0:      	ldr	x20, [x20]
		000000000000a9e0:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    a9e4:      	mov	x21, #0x16              ; =22
    a9e8:      	b	0xa77c <_stogir.floating.operands+0xf4>
    a9ec:      	cmp	x10, #0x0
    a9f0:      	b.ge	0xa7fc <_stogir.floating.operands+0x174>
    a9f4:      	ldr	x13, [x4, #0x8]
    a9f8:      	ldr	x14, [x7, #0x8]
    a9fc:      	cmp	x13, x14
    aa00:      	b.ne	0xa788 <_stogir.floating.operands+0x100>
    aa04:      	cmp	x11, x13
    aa08:      	b.gt	0xaa60 <_stogir.floating.operands+0x3d8>
    aa0c:      	ldr	x11, [x0, #0x50]
    aa10:      	add	x11, x11, x12, lsl #2
    aa14:      	ldr	w11, [x11]
    aa18:      	sxtw	x11, w11
    aa1c:      	cmp	x11, #0x0
    aa20:      	cset	w11, gt
    aa24:      	ubfx	x11, x11, #0, #8
    aa28:      	b	0xaa64 <_stogir.floating.operands+0x3dc>
    aa2c:      	mov	x0, #0x1                ; =1
    aa30:      	str	x0, [x23]
    aa34:      	str	x20, [x23, #0x8]
    aa38:      	str	x21, [x23, #0x10]
    aa3c:      	ldr	x19, [sp, #0x60]
    aa40:      	ldr	x20, [sp, #0x68]
    aa44:      	ldr	x21, [sp, #0x70]
    aa48:      	ldr	x22, [sp, #0x78]
    aa4c:      	ldr	x23, [sp, #0x80]
    aa50:      	ldr	x29, [sp]
    aa54:      	ldr	x30, [sp, #0x8]
    aa58:      	add	sp, sp, #0x90
    aa5c:      	ret
    aa60:      	movz	x11, #0x0, lsl #48
    aa64:      	b	0xa78c <_stogir.floating.operands+0x104>
    aa68:      	add	x16, sp, #0x30
    aa6c:      	ldr	x0, [x16, #0x8]
    aa70:      	cmp	x22, #0x0
    aa74:      	b.lt	0xa770 <_stogir.floating.operands+0xe8>
    aa78:      	uxtb	w0, w0
    aa7c:      	cmp	x0, #0x83
    aa80:      	b.ge	0xa730 <_stogir.floating.operands+0xa8>
    aa84:      	adrp	x17, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000aa84:  ARM64_RELOC_PAGE21	l_stogir.474
    aa88:      	ldr	x17, [x17]
		000000000000aa88:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    aa8c:      	add	x1, x0, x17
    aa90:      	ldrb	w1, [x1]
    aa94:      	b	0xa734 <_stogir.floating.operands+0xac>
    aa98:      	brk	#0
    aa9c:      	b	0xaa98 <_stogir.floating.operands+0x410>
    aaa0:      	brk	#0
    aaa4:      	b	0xaaa0 <_stogir.floating.operands+0x418>
    aaa8:      	brk	#0
    aaac:      	b	0xaaa8 <_stogir.floating.operands+0x420>
    aab0:      	mov	x23, x8
    aab4:      	b	0xa880 <_stogir.floating.operands+0x1f8>

000000000000aab8 <_stogir.vector-lanes.operands>:
    aab8:      	sub	sp, sp, #0x110
    aabc:      	str	x29, [sp]
    aac0:      	str	x30, [sp, #0x8]
    aac4:      	mov	x29, sp
    aac8:      	str	x19, [sp, #0xc0]
    aacc:      	str	x20, [sp, #0xc8]
    aad0:      	str	x21, [sp, #0xd0]
    aad4:      	str	x22, [sp, #0xd8]
    aad8:      	str	x23, [sp, #0xe0]
    aadc:      	str	x24, [sp, #0xe8]
    aae0:      	str	x25, [sp, #0xf0]
    aae4:      	str	x26, [sp, #0xf8]
    aae8:      	str	x27, [sp, #0x100]
    aaec:      	str	x28, [sp, #0x108]
    aaf0:      	sxtw	x4, w4
    aaf4:      	add	x7, x0, #0x28
    aaf8:      	cmp	x4, #0x0
    aafc:      	cset	w9, gt
    ab00:      	movz	x16, #0x0, lsl #48
    ab04:      	sub	x10, x16, x4
    ab08:      	sub	x11, x10, #0x1
    ab0c:      	uxtb	w16, w9
    ab10:      	cmp	w16, wzr
    ab14:      	b.eq	0xab54 <_stogir.vector-lanes.operands+0x9c>
    ab18:      	ldr	x7, [x0, #0x8]
    ab1c:      	cmp	x4, x7
    ab20:      	b.ge	0xaba8 <_stogir.vector-lanes.operands+0xf0>
    ab24:      	add	x7, x0, #0x78
    ab28:      	ldr	x7, [x7, #0x8]
    ab2c:      	cmp	x4, x7
    ab30:      	b.ge	0xaca8 <_stogir.vector-lanes.operands+0x1f0>
    ab34:      	ldr	x7, [x0, #0x78]
    ab38:      	add	x7, x7, x4, lsl #2
    ab3c:      	ldr	w7, [x7]
    ab40:      	sxtw	x7, w7
    ab44:      	cmp	x7, #0x0
    ab48:      	cset	w7, ge
    ab4c:      	ubfx	x7, x7, #0, #8
    ab50:      	b	0xacac <_stogir.vector-lanes.operands+0x1f4>
    ab54:      	cmp	x4, #0x0
    ab58:      	b.ge	0xabb0 <_stogir.vector-lanes.operands+0xf8>
    ab5c:      	add	x12, x0, #0x50
    ab60:      	ldr	x7, [x7, #0x8]
    ab64:      	ldr	x12, [x12, #0x8]
    ab68:      	cmp	x7, x12
    ab6c:      	b.ne	0xab98 <_stogir.vector-lanes.operands+0xe0>
    ab70:      	cmp	x10, x7
    ab74:      	b.gt	0xae5c <_stogir.vector-lanes.operands+0x3a4>
    ab78:      	ldr	x7, [x0, #0x50]
    ab7c:      	add	x7, x7, x11, lsl #2
    ab80:      	ldr	w7, [x7]
    ab84:      	sxtw	x7, w7
    ab88:      	cmp	x7, #0x0
    ab8c:      	cset	w7, gt
    ab90:      	ubfx	x7, x7, #0, #8
    ab94:      	b	0xae60 <_stogir.vector-lanes.operands+0x3a8>
    ab98:      	movz	x7, #0x0, lsl #48
    ab9c:      	b	0xabb4 <_stogir.vector-lanes.operands+0xfc>
    aba0:      	mov	x2, #0x1                ; =1
    aba4:      	b	0xac38 <_stogir.vector-lanes.operands+0x180>
    aba8:      	movz	x7, #0x0, lsl #48
    abac:      	b	0xabb4 <_stogir.vector-lanes.operands+0xfc>
    abb0:      	movz	x7, #0x0, lsl #48
    abb4:      	cmp	x7, #0x0
    abb8:      	b.eq	0xabec <_stogir.vector-lanes.operands+0x134>
    abbc:      	uxtb	w16, w9
    abc0:      	cmp	w16, wzr
    abc4:      	b.eq	0xabd8 <_stogir.vector-lanes.operands+0x120>
    abc8:      	ldr	x7, [x0]
    abcc:      	add	x4, x7, x4, lsl #4
    abd0:      	ldr	x4, [x4]
    abd4:      	b	0xabe4 <_stogir.vector-lanes.operands+0x12c>
    abd8:      	ldr	x4, [x0, #0x28]
    abdc:      	add	x4, x4, x11, lsl #4
    abe0:      	ldr	x4, [x4]
    abe4:      	mov	w7, #0x1                ; =1
    abe8:      	b	0xabf4 <_stogir.vector-lanes.operands+0x13c>
    abec:      	movz	w7, #0x0, lsl #16
    abf0:      	movz	x4, #0x0, lsl #48
    abf4:      	ubfx	x7, x7, #0, #32
    abf8:      	lsr	x16, x7, #0
    abfc:      	cmp	x16, #0x1
    ac00:      	b.eq	0xac1c <_stogir.vector-lanes.operands+0x164>
    ac04:      	b.lo	0xac0c <_stogir.vector-lanes.operands+0x154>
    ac08:      	b	0xac20 <_stogir.vector-lanes.operands+0x168>
    ac0c:      	cmp	x16, #0x0
    ac10:      	b.eq	0xac18 <_stogir.vector-lanes.operands+0x160>
    ac14:      	b	0xac20 <_stogir.vector-lanes.operands+0x168>
    ac18:      	b	0xac24 <_stogir.vector-lanes.operands+0x16c>
    ac1c:      	b	0xac80 <_stogir.vector-lanes.operands+0x1c8>
    ac20:      	b	0xb130 <_stogir.vector-lanes.operands+0x678>
    ac24:      	str	x8, [sp, #0xa0]
    ac28:      	mov	x2, #0x1                ; =1
    ac2c:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000ac2c:  ARM64_RELOC_PAGE21	l_stogir.475
    ac30:      	ldr	x1, [x1]
		000000000000ac30:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    ac34:      	mov	x0, #0x1b               ; =27
    ac38:      	ldr	x3, [sp, #0xa0]
    ac3c:      	str	x2, [x3]
    ac40:      	str	x1, [x3, #0x8]
    ac44:      	str	x0, [x3, #0x10]
    ac48:      	ldr	x19, [sp, #0xc0]
    ac4c:      	ldr	x20, [sp, #0xc8]
    ac50:      	ldr	x21, [sp, #0xd0]
    ac54:      	ldr	x22, [sp, #0xd8]
    ac58:      	ldr	x23, [sp, #0xe0]
    ac5c:      	ldr	x24, [sp, #0xe8]
    ac60:      	ldr	x25, [sp, #0xf0]
    ac64:      	ldr	x26, [sp, #0xf8]
    ac68:      	ldr	x27, [sp, #0x100]
    ac6c:      	ldr	x28, [sp, #0x108]
    ac70:      	ldr	x29, [sp]
    ac74:      	ldr	x30, [sp, #0x8]
    ac78:      	add	sp, sp, #0x110
    ac7c:      	ret
    ac80:      	sxtw	x19, w1
    ac84:      	sxtw	x1, w2
    ac88:      	orr	w7, w4, wzr
    ac8c:      	ubfx	x7, x7, #0, #32
    ac90:      	ubfx	x7, x7, #8, #8
    ac94:      	orr	x20, x7, xzr
    ac98:      	cmp	x19, #0x3d
    ac9c:      	b.ne	0xacb0 <_stogir.vector-lanes.operands+0x1f8>
    aca0:      	mov	x21, x20
    aca4:      	b	0xacb4 <_stogir.vector-lanes.operands+0x1fc>
    aca8:      	movz	x7, #0x0, lsl #48
    acac:      	b	0xabac <_stogir.vector-lanes.operands+0xf4>
    acb0:      	mov	x21, x1
    acb4:      	cmp	x19, #0x3d
    acb8:      	b.eq	0xacc0 <_stogir.vector-lanes.operands+0x208>
    acbc:      	mov	x1, x20
    acc0:      	orr	w22, w21, wzr
    acc4:      	sxtw	x23, w22
    acc8:      	cmp	x23, #0xf
    accc:      	cset	w24, gt
    acd0:      	cmp	x23, #0x80
    acd4:      	cset	w25, lt
    acd8:      	and	w7, w22, #0xf
    acdc:      	ubfx	x7, x7, #0, #32
    ace0:      	cmp	x7, #0x1
    ace4:      	cset	w26, ge
    ace8:      	cmp	x7, #0xd
    acec:      	cset	w27, le
    acf0:      	cmp	x19, #0x3d
    acf4:      	b.lt	0xad44 <_stogir.vector-lanes.operands+0x28c>
    acf8:      	cmp	x19, #0x3f
    acfc:      	b.gt	0xad44 <_stogir.vector-lanes.operands+0x28c>
    ad00:      	uxtb	w16, w24
    ad04:      	cmp	w16, wzr
    ad08:      	b.eq	0xad44 <_stogir.vector-lanes.operands+0x28c>
    ad0c:      	uxtb	w16, w25
    ad10:      	cmp	w16, wzr
    ad14:      	b.eq	0xad44 <_stogir.vector-lanes.operands+0x28c>
    ad18:      	uxtb	w16, w26
    ad1c:      	cmp	w16, wzr
    ad20:      	b.eq	0xad44 <_stogir.vector-lanes.operands+0x28c>
    ad24:      	uxtb	w16, w27
    ad28:      	cmp	w16, wzr
    ad2c:      	b.eq	0xad44 <_stogir.vector-lanes.operands+0x28c>
    ad30:      	sxtw	x7, w3
    ad34:      	cmp	x7, #0x4
    ad38:      	b.eq	0xb160 <_stogir.vector-lanes.operands+0x6a8>
    ad3c:      	cmp	x7, #0x8
    ad40:      	b.eq	0xb160 <_stogir.vector-lanes.operands+0x6a8>
    ad44:      	adrp	x28, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000ad44:  ARM64_RELOC_PAGE21	l_stogir.476
    ad48:      	ldr	x28, [x28]
		000000000000ad48:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    ad4c:      	mov	x4, #0x36               ; =54
    ad50:      	sxtw	x7, w5
    ad54:      	sxtw	x9, w6
    ad58:      	cmp	x9, #0x0
    ad5c:      	cset	w9, eq
    ad60:      	cmp	x19, #0x3f
    ad64:      	b.ne	0xb194 <_stogir.vector-lanes.operands+0x6dc>
    ad68:      	mov	w0, w22
    ad6c:      	mov	w2, w3
    ad70:      	mov	x19, x8
    ad74:      	mov	x20, x4
    ad78:      	mov	x22, x7
    ad7c:      	mov	w23, w9
    ad80:      	bl	0xad80 <_stogir.vector-lanes.operands+0x2c8>
		000000000000ad80:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    ad84:      	cmp	x0, #0x0
    ad88:      	b.eq	0xaf68 <_stogir.vector-lanes.operands+0x4b0>
    ad8c:      	movz	x0, #0x0, lsl #48
    ad90:      	b	0xaf6c <_stogir.vector-lanes.operands+0x4b4>
    ad94:      	cmp	x19, #0x3d
    ad98:      	b.ne	0xb1a0 <_stogir.vector-lanes.operands+0x6e8>
    ad9c:      	str	x0, [sp, #0x80]
    ada0:      	mov	w0, w22
    ada4:      	str	w3, [sp, #0xb0]
    ada8:      	str	x1, [sp, #0xa0]
    adac:      	mov	w1, w2
    adb0:      	mov	w2, w3
    adb4:      	str	x4, [sp, #0xa8]
    adb8:      	str	w8, [sp, #0xb8]
    adbc:      	str	w22, [sp, #0x88]
    adc0:      	mov	x22, x7
    adc4:      	str	x28, [sp, #0x90]
    adc8:      	mov	w28, w5
    adcc:      	str	x21, [sp, #0x98]
    add0:      	mov	w21, w6
    add4:      	bl	0xadd4 <_stogir.vector-lanes.operands+0x31c>
		000000000000add4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    add8:      	cmp	x0, #0x0
    addc:      	b.ne	0xadf4 <_stogir.vector-lanes.operands+0x33c>
    ade0:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000ade0:  ARM64_RELOC_PAGE21	l_stogir.477
    ade4:      	ldr	x16, [x16]
		000000000000ade4:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    ade8:      	str	x16, [sp, #0x90]
    adec:      	mov	x16, #0x26              ; =38
    adf0:      	str	x16, [sp, #0xa8]
    adf4:      	cmp	x19, #0x3e
    adf8:      	b.ne	0xae8c <_stogir.vector-lanes.operands+0x3d4>
    adfc:      	cmp	x20, x23
    ae00:      	cset	w0, eq
    ae04:      	uxtb	w16, w0
    ae08:      	cmp	w16, wzr
    ae0c:      	cset	x0, eq
    ae10:      	b	0xae90 <_stogir.vector-lanes.operands+0x3d8>
    ae14:      	mov	x0, #0x1                ; =1
    ae18:      	cmp	x0, #0x0
    ae1c:      	b.eq	0xae2c <_stogir.vector-lanes.operands+0x374>
    ae20:      	adrp	x28, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000ae20:  ARM64_RELOC_PAGE21	l_stogir.478
    ae24:      	ldr	x28, [x28]
		000000000000ae24:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    ae28:      	mov	x20, #0x24              ; =36
    ae2c:      	str	x21, [sp, #0x98]
    ae30:      	str	x19, [sp, #0xa0]
    ae34:      	str	x28, [sp, #0x90]
    ae38:      	str	x20, [sp, #0xa8]
    ae3c:      	ldr	x0, [sp, #0xa8]
    ae40:      	cmp	x0, #0x0
    ae44:      	b.ne	0xb1d0 <_stogir.vector-lanes.operands+0x718>
    ae48:      	ldr	x0, [sp, #0x98]
    ae4c:      	and	x1, x0, #0xffffffff
    ae50:      	movz	x2, #0x0, lsl #48
    ae54:      	movz	x0, #0x0, lsl #48
    ae58:      	b	0xaba4 <_stogir.vector-lanes.operands+0xec>
    ae5c:      	movz	x7, #0x0, lsl #48
    ae60:      	b	0xab9c <_stogir.vector-lanes.operands+0xe4>
    ae64:      	ldr	w0, [sp, #0xb8]
    ae68:      	uxtb	w16, w0
    ae6c:      	cmp	w16, wzr
    ae70:      	b.ne	0xae88 <_stogir.vector-lanes.operands+0x3d0>
    ae74:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000ae74:  ARM64_RELOC_PAGE21	l_stogir.479
    ae78:      	ldr	x16, [x16]
		000000000000ae78:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    ae7c:      	str	x16, [sp, #0x90]
    ae80:      	mov	x16, #0x20              ; =32
    ae84:      	str	x16, [sp, #0xa8]
    ae88:      	b	0xae3c <_stogir.vector-lanes.operands+0x384>
    ae8c:      	movz	x0, #0x0, lsl #48
    ae90:      	cmp	x0, #0x0
    ae94:      	b.eq	0xaeac <_stogir.vector-lanes.operands+0x3f4>
    ae98:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000ae98:  ARM64_RELOC_PAGE21	l_stogir.480
    ae9c:      	ldr	x16, [x16]
		000000000000ae9c:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    aea0:      	str	x16, [sp, #0x90]
    aea4:      	mov	x16, #0x27              ; =39
    aea8:      	str	x16, [sp, #0xa8]
    aeac:      	add	x8, sp, #0x10
    aeb0:      	ldr	x0, [sp, #0x80]
    aeb4:      	mov	w1, w28
    aeb8:      	bl	0xaeb8 <_stogir.vector-lanes.operands+0x400>
		000000000000aeb8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    aebc:      	add	x16, sp, #0x10
    aec0:      	ldr	w0, [x16]
    aec4:      	lsr	x16, x0, #0
    aec8:      	cmp	x16, #0x1
    aecc:      	b.eq	0xaee8 <_stogir.vector-lanes.operands+0x430>
    aed0:      	b.lo	0xaed8 <_stogir.vector-lanes.operands+0x420>
    aed4:      	b	0xaeec <_stogir.vector-lanes.operands+0x434>
    aed8:      	cmp	x16, #0x0
    aedc:      	b.eq	0xaee4 <_stogir.vector-lanes.operands+0x42c>
    aee0:      	b	0xaeec <_stogir.vector-lanes.operands+0x434>
    aee4:      	b	0xaef0 <_stogir.vector-lanes.operands+0x438>
    aee8:      	b	0xaf94 <_stogir.vector-lanes.operands+0x4dc>
    aeec:      	b	0xb184 <_stogir.vector-lanes.operands+0x6cc>
    aef0:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000aef0:  ARM64_RELOC_PAGE21	l_stogir.481
    aef4:      	ldr	x16, [x16]
		000000000000aef4:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    aef8:      	str	x16, [sp, #0x90]
    aefc:      	mov	x16, #0x19              ; =25
    af00:      	str	x16, [sp, #0xa8]
    af04:      	cmp	x19, #0x3e
    af08:      	b.ne	0xae64 <_stogir.vector-lanes.operands+0x3ac>
    af0c:      	add	x8, sp, #0x50
    af10:      	ldr	x0, [sp, #0x80]
    af14:      	mov	w1, w21
    af18:      	bl	0xaf18 <_stogir.vector-lanes.operands+0x460>
		000000000000af18:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    af1c:      	add	x16, sp, #0x50
    af20:      	ldr	w0, [x16]
    af24:      	lsr	x16, x0, #0
    af28:      	cmp	x16, #0x1
    af2c:      	b.eq	0xaf48 <_stogir.vector-lanes.operands+0x490>
    af30:      	b.lo	0xaf38 <_stogir.vector-lanes.operands+0x480>
    af34:      	b	0xaf4c <_stogir.vector-lanes.operands+0x494>
    af38:      	cmp	x16, #0x0
    af3c:      	b.eq	0xaf44 <_stogir.vector-lanes.operands+0x48c>
    af40:      	b	0xaf4c <_stogir.vector-lanes.operands+0x494>
    af44:      	b	0xaf50 <_stogir.vector-lanes.operands+0x498>
    af48:      	b	0xb080 <_stogir.vector-lanes.operands+0x5c8>
    af4c:      	b	0xb18c <_stogir.vector-lanes.operands+0x6d4>
    af50:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000af50:  ARM64_RELOC_PAGE21	l_stogir.482
    af54:      	ldr	x16, [x16]
		000000000000af54:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    af58:      	str	x16, [sp, #0x90]
    af5c:      	mov	x16, #0x20              ; =32
    af60:      	str	x16, [sp, #0xa8]
    af64:      	b	0xae88 <_stogir.vector-lanes.operands+0x3d0>
    af68:      	mov	x0, #0x1                ; =1
    af6c:      	cmp	x0, #0x0
    af70:      	b.eq	0xaf7c <_stogir.vector-lanes.operands+0x4c4>
    af74:      	mov	x0, #0x1                ; =1
    af78:      	b	0xae18 <_stogir.vector-lanes.operands+0x360>
    af7c:      	cmp	x22, #0x0
    af80:      	b.ne	0xae14 <_stogir.vector-lanes.operands+0x35c>
    af84:      	uxtb	w16, w23
    af88:      	cmp	w16, wzr
    af8c:      	cset	x0, eq
    af90:      	b	0xae18 <_stogir.vector-lanes.operands+0x360>
    af94:      	add	x16, sp, #0x10
    af98:      	orr	x0, x16, xzr
    af9c:      	add	x0, x0, #0x8
    afa0:      	add	x16, sp, #0x10
    afa4:      	ldr	x1, [x16, #0x8]
    afa8:      	add	x16, sp, #0x40
    afac:      	str	x1, [x16]
    afb0:      	ldr	x0, [x0, #0x8]
    afb4:      	ubfx	x1, x1, #0, #32
    afb8:      	add	x16, sp, #0x40
    afbc:      	str	x0, [x16, #0x8]
    afc0:      	ubfx	x0, x1, #8, #8
    afc4:      	cmp	x0, #0x1
    afc8:      	b.lt	0xaff0 <_stogir.vector-lanes.operands+0x538>
    afcc:      	cmp	x0, #0xb
    afd0:      	b.gt	0xaff0 <_stogir.vector-lanes.operands+0x538>
    afd4:      	add	x16, sp, #0x40
    afd8:      	ldr	w0, [x16]
    afdc:      	uxtb	w0, w0
    afe0:      	cmp	x0, #0x48
    afe4:      	b.eq	0xaff0 <_stogir.vector-lanes.operands+0x538>
    afe8:      	cmp	x0, #0x46
    afec:      	b.ne	0xb004 <_stogir.vector-lanes.operands+0x54c>
    aff0:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x300>
		000000000000aff0:  ARM64_RELOC_PAGE21	l_stogir.483
    aff4:      	ldr	x16, [x16]
		000000000000aff4:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    aff8:      	str	x16, [sp, #0x90]
    affc:      	mov	x16, #0x2b              ; =43
    b000:      	str	x16, [sp, #0xa8]
    b004:      	cmp	x22, #0x0
    b008:      	b.ge	0xb034 <_stogir.vector-lanes.operands+0x57c>
    b00c:      	add	x16, sp, #0x40
    b010:      	ldr	w0, [x16]
    b014:      	uxtb	w1, w0
    b018:      	ubfx	x0, x0, #8, #8
    b01c:      	cmp	x1, x0
    b020:      	b.eq	0xb0d8 <_stogir.vector-lanes.operands+0x620>
    b024:      	cmp	x1, #0x49
    b028:      	b.eq	0xb0d8 <_stogir.vector-lanes.operands+0x620>
    b02c:      	movz	x0, #0x0, lsl #48
    b030:      	b	0xb07c <_stogir.vector-lanes.operands+0x5c4>
    b034:      	movz	x0, #0x0, lsl #48
    b038:      	cmp	x0, #0x0
    b03c:      	b.eq	0xb054 <_stogir.vector-lanes.operands+0x59c>
    b040:      	adrp	x16, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b040:  ARM64_RELOC_PAGE21	l_stogir.484
    b044:      	ldr	x16, [x16]
		000000000000b044:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    b048:      	str	x16, [sp, #0x90]
    b04c:      	mov	x16, #0x28              ; =40
    b050:      	str	x16, [sp, #0xa8]
    b054:      	b	0xaf04 <_stogir.vector-lanes.operands+0x44c>
    b058:      	movn	w2, #0x0, lsl #16
    b05c:      	ubfx	x0, x0, #0, #32
    b060:      	ubfx	x1, x1, #0, #32
    b064:      	lsl	x1, x1, #32
    b068:      	orr	x0, x1, x0
    b06c:      	sxtw	x2, w2
    b070:      	cmp	x0, x2
    b074:      	cset	w0, hs
    b078:      	ubfx	x0, x0, #0, #8
    b07c:      	b	0xb038 <_stogir.vector-lanes.operands+0x580>
    b080:      	add	x16, sp, #0x50
    b084:      	ldr	x0, [x16, #0x8]
    b088:      	uxtb	w1, w0
    b08c:      	cmp	x1, #0x48
    b090:      	b.eq	0xb0c0 <_stogir.vector-lanes.operands+0x608>
    b094:      	cmp	x1, #0x46
    b098:      	b.eq	0xb0c0 <_stogir.vector-lanes.operands+0x608>
    b09c:      	ldr	w1, [sp, #0xb0]
    b0a0:      	ubfx	x0, x0, #0, #32
    b0a4:      	ubfx	x0, x0, #8, #8
    b0a8:      	mov	w2, w1
    b0ac:      	mov	w1, w0
    b0b0:      	ldr	w0, [sp, #0x88]
    b0b4:      	bl	0xb0b4 <_stogir.vector-lanes.operands+0x5fc>
		000000000000b0b4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b0b8:      	cmp	x0, #0x0
    b0bc:      	b.ne	0xb0d4 <_stogir.vector-lanes.operands+0x61c>
    b0c0:      	adrp	x16, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b0c0:  ARM64_RELOC_PAGE21	l_stogir.485
    b0c4:      	ldr	x16, [x16]
		000000000000b0c4:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    b0c8:      	str	x16, [sp, #0x90]
    b0cc:      	mov	x16, #0x27              ; =39
    b0d0:      	str	x16, [sp, #0xa8]
    b0d4:      	b	0xaf64 <_stogir.vector-lanes.operands+0x4ac>
    b0d8:      	add	x16, sp, #0x40
    b0dc:      	ldr	w0, [x16, #0x8]
    b0e0:      	add	x16, sp, #0x40
    b0e4:      	ldr	w1, [x16, #0xc]
    b0e8:      	uxtb	w16, w24
    b0ec:      	cmp	w16, wzr
    b0f0:      	b.eq	0xb138 <_stogir.vector-lanes.operands+0x680>
    b0f4:      	uxtb	w16, w25
    b0f8:      	cmp	w16, wzr
    b0fc:      	b.eq	0xb138 <_stogir.vector-lanes.operands+0x680>
    b100:      	uxtb	w16, w26
    b104:      	cmp	w16, wzr
    b108:      	b.eq	0xb138 <_stogir.vector-lanes.operands+0x680>
    b10c:      	uxtb	w16, w27
    b110:      	cmp	w16, wzr
    b114:      	b.eq	0xb138 <_stogir.vector-lanes.operands+0x680>
    b118:      	ubfx	x2, x23, #4, #32
    b11c:      	sub	w2, w2, #0x1
    b120:      	sxtw	x2, w2
    b124:      	mov	x16, #0x1               ; =1
    b128:      	lsl	x2, x16, x2
    b12c:      	b	0xb05c <_stogir.vector-lanes.operands+0x5a4>
    b130:      	brk	#0
    b134:      	b	0xb130 <_stogir.vector-lanes.operands+0x678>
    b138:      	cmp	x23, #0x0
    b13c:      	b.lt	0xb058 <_stogir.vector-lanes.operands+0x5a0>
    b140:      	cmp	x23, #0xd
    b144:      	b.gt	0xb058 <_stogir.vector-lanes.operands+0x5a0>
    b148:      	cmp	x23, #0x0
    b14c:      	cset	w2, eq
    b150:      	uxtb	w16, w2
    b154:      	cmp	w16, wzr
    b158:      	cset	w2, eq
    b15c:      	b	0xb05c <_stogir.vector-lanes.operands+0x5a4>
    b160:      	uxtb	w4, w4
    b164:      	cmp	x4, #0x48
    b168:      	b.eq	0xad44 <_stogir.vector-lanes.operands+0x28c>
    b16c:      	cmp	x4, #0x46
    b170:      	b.eq	0xad44 <_stogir.vector-lanes.operands+0x28c>
    b174:      	adrp	x28, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b174:  ARM64_RELOC_PAGE21	l_stogir.486
    b178:      	ldr	x28, [x28]
		000000000000b178:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    b17c:      	movz	x4, #0x0, lsl #48
    b180:      	b	0xad50 <_stogir.vector-lanes.operands+0x298>
    b184:      	brk	#0
    b188:      	b	0xb184 <_stogir.vector-lanes.operands+0x6cc>
    b18c:      	brk	#0
    b190:      	b	0xb18c <_stogir.vector-lanes.operands+0x6d4>
    b194:      	mov	x1, x8
    b198:      	mov	w8, w9
    b19c:      	b	0xad94 <_stogir.vector-lanes.operands+0x2dc>
    b1a0:      	str	x21, [sp, #0x98]
    b1a4:      	str	x1, [sp, #0xa0]
    b1a8:      	str	x0, [sp, #0x80]
    b1ac:      	str	w3, [sp, #0xb0]
    b1b0:      	mov	w21, w6
    b1b4:      	str	w22, [sp, #0x88]
    b1b8:      	mov	x22, x7
    b1bc:      	str	w8, [sp, #0xb8]
    b1c0:      	str	x28, [sp, #0x90]
    b1c4:      	mov	w28, w5
    b1c8:      	str	x4, [sp, #0xa8]
    b1cc:      	b	0xadf4 <_stogir.vector-lanes.operands+0x33c>
    b1d0:      	ldr	x1, [sp, #0x90]
    b1d4:      	b	0xaba0 <_stogir.vector-lanes.operands+0xe8>

000000000000b1d8 <_stogir.vector-comparison.operands>:
    b1d8:      	sub	sp, sp, #0xc0
    b1dc:      	str	x29, [sp]
    b1e0:      	str	x30, [sp, #0x8]
    b1e4:      	mov	x29, sp
    b1e8:      	str	x19, [sp, #0x70]
    b1ec:      	str	x20, [sp, #0x78]
    b1f0:      	str	x21, [sp, #0x80]
    b1f4:      	str	x22, [sp, #0x88]
    b1f8:      	str	x23, [sp, #0x90]
    b1fc:      	str	x24, [sp, #0x98]
    b200:      	str	x25, [sp, #0xa0]
    b204:      	str	x26, [sp, #0xa8]
    b208:      	str	x27, [sp, #0xb0]
    b20c:      	mov	x19, x8
    b210:      	add	x8, sp, #0x10
    b214:      	mov	x20, x0
    b218:      	mov	w21, w1
    b21c:      	mov	w1, w4
    b220:      	mov	w22, w2
    b224:      	mov	w23, w3
    b228:      	mov	w24, w5
    b22c:      	bl	0xb22c <_stogir.vector-comparison.operands+0x54>
		000000000000b22c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b230:      	add	x16, sp, #0x10
    b234:      	ldr	w0, [x16]
    b238:      	lsr	x16, x0, #0
    b23c:      	cmp	x16, #0x1
    b240:      	b.eq	0xb25c <_stogir.vector-comparison.operands+0x84>
    b244:      	b.lo	0xb24c <_stogir.vector-comparison.operands+0x74>
    b248:      	b	0xb260 <_stogir.vector-comparison.operands+0x88>
    b24c:      	cmp	x16, #0x0
    b250:      	b.eq	0xb258 <_stogir.vector-comparison.operands+0x80>
    b254:      	b	0xb260 <_stogir.vector-comparison.operands+0x88>
    b258:      	b	0xb264 <_stogir.vector-comparison.operands+0x8c>
    b25c:      	b	0xb2b4 <_stogir.vector-comparison.operands+0xdc>
    b260:      	b	0xb430 <_stogir.vector-comparison.operands+0x258>
    b264:      	mov	x1, #0x1                ; =1
    b268:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b268:  ARM64_RELOC_PAGE21	l_stogir.487
    b26c:      	ldr	x0, [x0]
		000000000000b26c:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b270:      	mov	x2, #0x21               ; =33
    b274:      	str	x1, [x19]
    b278:      	str	x0, [x19, #0x8]
    b27c:      	str	x2, [x19, #0x10]
    b280:      	ldr	x19, [sp, #0x70]
    b284:      	ldr	x20, [sp, #0x78]
    b288:      	ldr	x21, [sp, #0x80]
    b28c:      	ldr	x22, [sp, #0x88]
    b290:      	ldr	x23, [sp, #0x90]
    b294:      	ldr	x24, [sp, #0x98]
    b298:      	ldr	x25, [sp, #0xa0]
    b29c:      	ldr	x26, [sp, #0xa8]
    b2a0:      	ldr	x27, [sp, #0xb0]
    b2a4:      	ldr	x29, [sp]
    b2a8:      	ldr	x30, [sp, #0x8]
    b2ac:      	add	sp, sp, #0xc0
    b2b0:      	ret
    b2b4:      	add	x16, sp, #0x10
    b2b8:      	ldr	x25, [x16, #0x8]
    b2bc:      	add	x8, sp, #0x40
    b2c0:      	mov	x0, x20
    b2c4:      	mov	w1, w24
    b2c8:      	bl	0xb2c8 <_stogir.vector-comparison.operands+0xf0>
		000000000000b2c8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b2cc:      	add	x16, sp, #0x40
    b2d0:      	ldr	w0, [x16]
    b2d4:      	lsr	x16, x0, #0
    b2d8:      	cmp	x16, #0x1
    b2dc:      	b.eq	0xb2f8 <_stogir.vector-comparison.operands+0x120>
    b2e0:      	b.lo	0xb2e8 <_stogir.vector-comparison.operands+0x110>
    b2e4:      	b	0xb2fc <_stogir.vector-comparison.operands+0x124>
    b2e8:      	cmp	x16, #0x0
    b2ec:      	b.eq	0xb2f4 <_stogir.vector-comparison.operands+0x11c>
    b2f0:      	b	0xb2fc <_stogir.vector-comparison.operands+0x124>
    b2f4:      	b	0xb300 <_stogir.vector-comparison.operands+0x128>
    b2f8:      	b	0xb314 <_stogir.vector-comparison.operands+0x13c>
    b2fc:      	b	0xb438 <_stogir.vector-comparison.operands+0x260>
    b300:      	mov	x1, #0x1                ; =1
    b304:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b304:  ARM64_RELOC_PAGE21	l_stogir.487
    b308:      	ldr	x0, [x0]
		000000000000b308:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b30c:      	mov	x2, #0x21               ; =33
    b310:      	b	0xb274 <_stogir.vector-comparison.operands+0x9c>
    b314:      	sxtw	x0, w23
    b318:      	add	x16, sp, #0x40
    b31c:      	ldr	x20, [x16, #0x8]
    b320:      	cmp	x0, #0x4
    b324:      	b.eq	0xb344 <_stogir.vector-comparison.operands+0x16c>
    b328:      	cmp	x0, #0x8
    b32c:      	b.eq	0xb344 <_stogir.vector-comparison.operands+0x16c>
    b330:      	mov	x1, #0x1                ; =1
    b334:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b334:  ARM64_RELOC_PAGE21	l_stogir.488
    b338:      	ldr	x0, [x0]
		000000000000b338:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    b33c:      	mov	x2, #0x33               ; =51
    b340:      	b	0xb310 <_stogir.vector-comparison.operands+0x138>
    b344:      	orr	w0, w25, wzr
    b348:      	ubfx	x0, x0, #0, #32
    b34c:      	ubfx	x24, x0, #8, #8
    b350:      	orr	x26, x24, xzr
    b354:      	mov	w0, w21
    b358:      	mov	w1, w26
    b35c:      	bl	0xb35c <_stogir.vector-comparison.operands+0x184>
		000000000000b35c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    b360:      	cmp	x0, #0x0
    b364:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b368:      	orr	w0, w20, wzr
    b36c:      	ubfx	x0, x0, #0, #32
    b370:      	ubfx	x0, x0, #8, #8
    b374:      	cmp	x24, x0
    b378:      	b.ne	0xb330 <_stogir.vector-comparison.operands+0x158>
    b37c:      	uxtb	w25, w25
    b380:      	cmp	x25, #0x48
    b384:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b388:      	cmp	x25, #0x46
    b38c:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b390:      	uxtb	w20, w20
    b394:      	cmp	x20, #0x48
    b398:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b39c:      	cmp	x20, #0x46
    b3a0:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b3a4:      	sxtw	x0, w22
    b3a8:      	cmp	x0, #0xf
    b3ac:      	cset	w1, gt
    b3b0:      	uxtb	w16, w1
    b3b4:      	cmp	w16, wzr
    b3b8:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b3bc:      	cmp	x0, #0x80
    b3c0:      	cset	w2, lt
    b3c4:      	uxtb	w16, w2
    b3c8:      	cmp	w16, wzr
    b3cc:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b3d0:      	and	w3, w22, #0xf
    b3d4:      	ubfx	x4, x3, #0, #32
    b3d8:      	cmp	x4, #0x1
    b3dc:      	cset	w5, ge
    b3e0:      	uxtb	w16, w5
    b3e4:      	cmp	w16, wzr
    b3e8:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b3ec:      	cmp	x4, #0xd
    b3f0:      	cset	w4, le
    b3f4:      	uxtb	w16, w4
    b3f8:      	cmp	w16, wzr
    b3fc:      	b.eq	0xb330 <_stogir.vector-comparison.operands+0x158>
    b400:      	cmp	x0, #0x0
    b404:      	cset	w6, ge
    b408:      	cmp	x0, #0xd
    b40c:      	cset	w7, le
    b410:      	uxtb	w16, w6
    b414:      	cmp	w16, wzr
    b418:      	b.eq	0xb440 <_stogir.vector-comparison.operands+0x268>
    b41c:      	uxtb	w16, w7
    b420:      	cmp	w16, wzr
    b424:      	b.eq	0xb440 <_stogir.vector-comparison.operands+0x268>
    b428:      	mov	w8, w3
    b42c:      	b	0xb474 <_stogir.vector-comparison.operands+0x29c>
    b430:      	brk	#0
    b434:      	b	0xb430 <_stogir.vector-comparison.operands+0x258>
    b438:      	brk	#0
    b43c:      	b	0xb438 <_stogir.vector-comparison.operands+0x260>
    b440:      	uxtb	w16, w1
    b444:      	cmp	w16, wzr
    b448:      	b.eq	0xb470 <_stogir.vector-comparison.operands+0x298>
    b44c:      	uxtb	w16, w2
    b450:      	cmp	w16, wzr
    b454:      	b.eq	0xb470 <_stogir.vector-comparison.operands+0x298>
    b458:      	uxtb	w16, w5
    b45c:      	cmp	w16, wzr
    b460:      	b.eq	0xb470 <_stogir.vector-comparison.operands+0x298>
    b464:      	uxtb	w16, w4
    b468:      	cmp	w16, wzr
    b46c:      	b.ne	0xb428 <_stogir.vector-comparison.operands+0x250>
    b470:      	movn	w8, #0x0, lsl #16
    b474:      	sxtw	x8, w8
    b478:      	cmp	x8, #0x1
    b47c:      	b.lt	0xb330 <_stogir.vector-comparison.operands+0x158>
    b480:      	cmp	x8, #0xb
    b484:      	b.gt	0xb330 <_stogir.vector-comparison.operands+0x158>
    b488:      	uxtb	w16, w1
    b48c:      	cmp	w16, wzr
    b490:      	b.eq	0xb4d0 <_stogir.vector-comparison.operands+0x2f8>
    b494:      	uxtb	w16, w2
    b498:      	cmp	w16, wzr
    b49c:      	b.eq	0xb4d0 <_stogir.vector-comparison.operands+0x2f8>
    b4a0:      	uxtb	w16, w5
    b4a4:      	cmp	w16, wzr
    b4a8:      	b.eq	0xb4d0 <_stogir.vector-comparison.operands+0x2f8>
    b4ac:      	uxtb	w16, w4
    b4b0:      	cmp	w16, wzr
    b4b4:      	b.eq	0xb4d0 <_stogir.vector-comparison.operands+0x2f8>
    b4b8:      	ubfx	x0, x0, #4, #32
    b4bc:      	sub	w0, w0, #0x1
    b4c0:      	sxtw	x0, w0
    b4c4:      	mov	x16, #0x1               ; =1
    b4c8:      	lsl	x0, x16, x0
    b4cc:      	b	0xb5dc <_stogir.vector-comparison.operands+0x404>
    b4d0:      	uxtb	w16, w6
    b4d4:      	cmp	w16, wzr
    b4d8:      	b.eq	0xb5d8 <_stogir.vector-comparison.operands+0x400>
    b4dc:      	uxtb	w16, w7
    b4e0:      	cmp	w16, wzr
    b4e4:      	b.eq	0xb5d8 <_stogir.vector-comparison.operands+0x400>
    b4e8:      	cmp	x0, #0x0
    b4ec:      	cset	w0, eq
    b4f0:      	uxtb	w16, w0
    b4f4:      	cmp	w16, wzr
    b4f8:      	cset	w0, eq
    b4fc:      	b	0xb5dc <_stogir.vector-comparison.operands+0x404>
    b500:      	movn	w8, #0x0, lsl #16
    b504:      	sxtw	x0, w0
    b508:      	sxtw	x8, w8
    b50c:      	cmp	x0, x8
    b510:      	b.ne	0xb330 <_stogir.vector-comparison.operands+0x158>
    b514:      	uxtb	w16, w6
    b518:      	cmp	w16, wzr
    b51c:      	b.eq	0xb52c <_stogir.vector-comparison.operands+0x354>
    b520:      	uxtb	w16, w7
    b524:      	cmp	w16, wzr
    b528:      	b.ne	0xb560 <_stogir.vector-comparison.operands+0x388>
    b52c:      	uxtb	w16, w1
    b530:      	cmp	w16, wzr
    b534:      	b.eq	0xb55c <_stogir.vector-comparison.operands+0x384>
    b538:      	uxtb	w16, w2
    b53c:      	cmp	w16, wzr
    b540:      	b.eq	0xb55c <_stogir.vector-comparison.operands+0x384>
    b544:      	uxtb	w16, w5
    b548:      	cmp	w16, wzr
    b54c:      	b.eq	0xb55c <_stogir.vector-comparison.operands+0x384>
    b550:      	uxtb	w16, w4
    b554:      	cmp	w16, wzr
    b558:      	b.ne	0xb560 <_stogir.vector-comparison.operands+0x388>
    b55c:      	movn	w3, #0x0, lsl #16
    b560:      	mov	w0, w3
    b564:      	mov	w1, w23
    b568:      	bl	0xb568 <_stogir.vector-comparison.operands+0x390>
		000000000000b568:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    b56c:      	uxtb	w16, w21
    b570:      	cmp	w16, wzr
    b574:      	b.ne	0xb5ac <_stogir.vector-comparison.operands+0x3d4>
    b578:      	uxtb	w16, w22
    b57c:      	cmp	w16, wzr
    b580:      	b.eq	0xb5a8 <_stogir.vector-comparison.operands+0x3d0>
    b584:      	uxtb	w16, w25
    b588:      	cmp	w16, wzr
    b58c:      	b.eq	0xb5a8 <_stogir.vector-comparison.operands+0x3d0>
    b590:      	uxtb	w16, w26
    b594:      	cmp	w16, wzr
    b598:      	b.eq	0xb5a8 <_stogir.vector-comparison.operands+0x3d0>
    b59c:      	uxtb	w16, w27
    b5a0:      	cmp	w16, wzr
    b5a4:      	b.ne	0xb5ac <_stogir.vector-comparison.operands+0x3d4>
    b5a8:      	movn	w20, #0x0, lsl #16
    b5ac:      	sxtw	x21, w0
    b5b0:      	mov	w0, w20
    b5b4:      	mov	w1, w23
    b5b8:      	bl	0xb5b8 <_stogir.vector-comparison.operands+0x3e0>
		000000000000b5b8:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    b5bc:      	sxtw	x0, w0
    b5c0:      	cmp	x21, x0
    b5c4:      	b.ne	0xb330 <_stogir.vector-comparison.operands+0x158>
    b5c8:      	and	x0, x24, #0xffffffff
    b5cc:      	movz	x1, #0x0, lsl #48
    b5d0:      	movz	x2, #0x0, lsl #48
    b5d4:      	b	0xb340 <_stogir.vector-comparison.operands+0x168>
    b5d8:      	movn	w0, #0x0, lsl #16
    b5dc:      	and	w20, w26, #0xf
    b5e0:      	cmp	x24, #0xd
    b5e4:      	cset	w21, le
    b5e8:      	cmp	x24, #0xf
    b5ec:      	cset	w22, gt
    b5f0:      	cmp	x24, #0x80
    b5f4:      	cset	w25, lt
    b5f8:      	ubfx	x8, x20, #0, #32
    b5fc:      	cmp	x8, #0x1
    b600:      	cset	w26, ge
    b604:      	cmp	x8, #0xd
    b608:      	cset	w27, le
    b60c:      	uxtb	w16, w22
    b610:      	cmp	w16, wzr
    b614:      	b.eq	0xb654 <_stogir.vector-comparison.operands+0x47c>
    b618:      	uxtb	w16, w25
    b61c:      	cmp	w16, wzr
    b620:      	b.eq	0xb654 <_stogir.vector-comparison.operands+0x47c>
    b624:      	uxtb	w16, w26
    b628:      	cmp	w16, wzr
    b62c:      	b.eq	0xb654 <_stogir.vector-comparison.operands+0x47c>
    b630:      	uxtb	w16, w27
    b634:      	cmp	w16, wzr
    b638:      	b.eq	0xb654 <_stogir.vector-comparison.operands+0x47c>
    b63c:      	ubfx	x8, x24, #4, #32
    b640:      	sub	w8, w8, #0x1
    b644:      	sxtw	x8, w8
    b648:      	mov	x16, #0x1               ; =1
    b64c:      	lsl	x8, x16, x8
    b650:      	b	0xb504 <_stogir.vector-comparison.operands+0x32c>
    b654:      	uxtb	w16, w21
    b658:      	cmp	w16, wzr
    b65c:      	b.eq	0xb500 <_stogir.vector-comparison.operands+0x328>
    b660:      	cmp	x24, #0x0
    b664:      	cset	w8, eq
    b668:      	uxtb	w16, w8
    b66c:      	cmp	w16, wzr
    b670:      	cset	w8, eq
    b674:      	b	0xb504 <_stogir.vector-comparison.operands+0x32c>

000000000000b678 <_stogir.vector-arithmetic.operands>:
    b678:      	sub	sp, sp, #0x70
    b67c:      	str	x29, [sp]
    b680:      	str	x30, [sp, #0x8]
    b684:      	mov	x29, sp
    b688:      	str	x19, [sp, #0x20]
    b68c:      	str	x20, [sp, #0x28]
    b690:      	str	x21, [sp, #0x30]
    b694:      	str	x22, [sp, #0x38]
    b698:      	str	x23, [sp, #0x40]
    b69c:      	str	x24, [sp, #0x48]
    b6a0:      	str	x25, [sp, #0x50]
    b6a4:      	str	x26, [sp, #0x58]
    b6a8:      	str	x27, [sp, #0x60]
    b6ac:      	str	x28, [sp, #0x68]
    b6b0:      	mov	x19, x8
    b6b4:      	mov	x20, x0
    b6b8:      	mov	w0, w1
    b6bc:      	mov	w21, w1
    b6c0:      	mov	w1, w2
    b6c4:      	mov	w22, w2
    b6c8:      	mov	w23, w3
    b6cc:      	mov	w24, w4
    b6d0:      	mov	w25, w5
    b6d4:      	bl	0xb6d4 <_stogir.vector-arithmetic.operands+0x5c>
		000000000000b6d4:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    b6d8:      	cmp	x0, #0x0
    b6dc:      	b.eq	0xb6f0 <_stogir.vector-arithmetic.operands+0x78>
    b6e0:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b6e0:  ARM64_RELOC_PAGE21	l_stogir.489
    b6e4:      	ldr	x0, [x0]
		000000000000b6e4:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    b6e8:      	movz	x1, #0x0, lsl #48
    b6ec:      	b	0xb6fc <_stogir.vector-arithmetic.operands+0x84>
    b6f0:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b6f0:  ARM64_RELOC_PAGE21	l_stogir.490
    b6f4:      	ldr	x0, [x0]
		000000000000b6f4:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    b6f8:      	mov	x1, #0x37               ; =55
    b6fc:      	sxtw	x21, w21
    b700:      	sxtw	x22, w22
    b704:      	cmp	x21, #0x31
    b708:      	cset	w2, ge
    b70c:      	cmp	x21, #0x35
    b710:      	cset	w3, le
    b714:      	cmp	x21, #0x1f
    b718:      	cset	w4, eq
    b71c:      	cmp	x21, #0x20
    b720:      	cset	w5, eq
    b724:      	cmp	x21, #0x2d
    b728:      	cset	w6, eq
    b72c:      	cmp	x21, #0x36
    b730:      	cset	w7, eq
    b734:      	cmp	x21, #0x37
    b738:      	cset	w8, eq
    b73c:      	cmp	x21, #0x38
    b740:      	cset	w9, eq
    b744:      	cmp	x21, #0x39
    b748:      	cset	w10, eq
    b74c:      	add	x11, x20, #0x28
    b750:      	add	x12, x20, #0x78
    b754:      	add	x13, x20, #0x50
    b758:      	movz	x14, #0x0, lsl #48
    b75c:      	b	0xb880 <_stogir.vector-arithmetic.operands+0x208>
    b760:      	movz	x27, #0x0, lsl #48
    b764:      	b	0xb774 <_stogir.vector-arithmetic.operands+0xfc>
    b768:      	movz	x27, #0x0, lsl #48
    b76c:      	b	0xb77c <_stogir.vector-arithmetic.operands+0x104>
    b770:      	movz	x27, #0x0, lsl #48
    b774:      	b	0xb78c <_stogir.vector-arithmetic.operands+0x114>
    b778:      	movz	x27, #0x0, lsl #48
    b77c:      	str	w4, [sp, #0x10]
    b780:      	str	w5, [sp, #0x18]
    b784:      	b	0xb78c <_stogir.vector-arithmetic.operands+0x114>
    b788:      	movz	x27, #0x0, lsl #48
    b78c:      	cmp	x27, #0x0
    b790:      	b.eq	0xb7c4 <_stogir.vector-arithmetic.operands+0x14c>
    b794:      	uxtb	w16, w26
    b798:      	cmp	w16, wzr
    b79c:      	b.eq	0xb7b0 <_stogir.vector-arithmetic.operands+0x138>
    b7a0:      	ldr	x4, [x20]
    b7a4:      	add	x4, x4, x15, lsl #4
    b7a8:      	ldr	x4, [x4]
    b7ac:      	b	0xb7bc <_stogir.vector-arithmetic.operands+0x144>
    b7b0:      	ldr	x4, [x20, #0x28]
    b7b4:      	add	x4, x4, x28, lsl #4
    b7b8:      	ldr	x4, [x4]
    b7bc:      	mov	w5, #0x1                ; =1
    b7c0:      	b	0xb7cc <_stogir.vector-arithmetic.operands+0x154>
    b7c4:      	movz	w5, #0x0, lsl #16
    b7c8:      	movz	x4, #0x0, lsl #48
    b7cc:      	ubfx	x5, x5, #0, #32
    b7d0:      	lsr	x16, x5, #0
    b7d4:      	cmp	x16, #0x1
    b7d8:      	b.eq	0xb7f4 <_stogir.vector-arithmetic.operands+0x17c>
    b7dc:      	b.lo	0xb7e4 <_stogir.vector-arithmetic.operands+0x16c>
    b7e0:      	b	0xb7f8 <_stogir.vector-arithmetic.operands+0x180>
    b7e4:      	cmp	x16, #0x0
    b7e8:      	b.eq	0xb7f0 <_stogir.vector-arithmetic.operands+0x178>
    b7ec:      	b	0xb7f8 <_stogir.vector-arithmetic.operands+0x180>
    b7f0:      	b	0xb7fc <_stogir.vector-arithmetic.operands+0x184>
    b7f4:      	b	0xb80c <_stogir.vector-arithmetic.operands+0x194>
    b7f8:      	b	0xbb4c <_stogir.vector-arithmetic.operands+0x4d4>
    b7fc:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b7fc:  ARM64_RELOC_PAGE21	l_stogir.491
    b800:      	ldr	x0, [x0]
		000000000000b800:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    b804:      	mov	x1, #0x21               ; =33
    b808:      	b	0xb870 <_stogir.vector-arithmetic.operands+0x1f8>
    b80c:      	orr	w5, w4, wzr
    b810:      	ubfx	x5, x5, #0, #32
    b814:      	ubfx	x5, x5, #8, #8
    b818:      	cmp	x5, x22
    b81c:      	b.eq	0xb850 <_stogir.vector-arithmetic.operands+0x1d8>
    b820:      	cmp	x14, #0x1
    b824:      	b.ne	0xb864 <_stogir.vector-arithmetic.operands+0x1ec>
    b828:      	uxtb	w16, w2
    b82c:      	cmp	w16, wzr
    b830:      	b.eq	0xb864 <_stogir.vector-arithmetic.operands+0x1ec>
    b834:      	uxtb	w16, w3
    b838:      	cmp	w16, wzr
    b83c:      	b.eq	0xb864 <_stogir.vector-arithmetic.operands+0x1ec>
    b840:      	cmp	x5, #0x1
    b844:      	b.lt	0xb864 <_stogir.vector-arithmetic.operands+0x1ec>
    b848:      	cmp	x5, #0xb
    b84c:      	b.gt	0xb864 <_stogir.vector-arithmetic.operands+0x1ec>
    b850:      	uxtb	w4, w4
    b854:      	cmp	x4, #0x48
    b858:      	b.eq	0xb864 <_stogir.vector-arithmetic.operands+0x1ec>
    b85c:      	cmp	x4, #0x46
    b860:      	b.ne	0xb870 <_stogir.vector-arithmetic.operands+0x1f8>
    b864:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b864:  ARM64_RELOC_PAGE21	l_stogir.492
    b868:      	ldr	x0, [x0]
		000000000000b868:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    b86c:      	mov	x1, #0x32               ; =50
    b870:      	add	x4, x14, #0x1
    b874:      	sxtw	x14, w4
    b878:      	ldr	w4, [sp, #0x10]
    b87c:      	ldr	w5, [sp, #0x18]
    b880:      	uxtb	w16, w4
    b884:      	cmp	w16, wzr
    b888:      	b.ne	0xb8dc <_stogir.vector-arithmetic.operands+0x264>
    b88c:      	uxtb	w16, w5
    b890:      	cmp	w16, wzr
    b894:      	b.ne	0xb8dc <_stogir.vector-arithmetic.operands+0x264>
    b898:      	uxtb	w16, w6
    b89c:      	cmp	w16, wzr
    b8a0:      	b.ne	0xb8dc <_stogir.vector-arithmetic.operands+0x264>
    b8a4:      	uxtb	w16, w7
    b8a8:      	cmp	w16, wzr
    b8ac:      	b.ne	0xb8dc <_stogir.vector-arithmetic.operands+0x264>
    b8b0:      	uxtb	w16, w8
    b8b4:      	cmp	w16, wzr
    b8b8:      	b.ne	0xb8dc <_stogir.vector-arithmetic.operands+0x264>
    b8bc:      	uxtb	w16, w9
    b8c0:      	cmp	w16, wzr
    b8c4:      	b.ne	0xb8dc <_stogir.vector-arithmetic.operands+0x264>
    b8c8:      	uxtb	w16, w10
    b8cc:      	cmp	w16, wzr
    b8d0:      	b.ne	0xb8dc <_stogir.vector-arithmetic.operands+0x264>
    b8d4:      	mov	x15, #0x2               ; =2
    b8d8:      	b	0xb8e0 <_stogir.vector-arithmetic.operands+0x268>
    b8dc:      	mov	x15, #0x1               ; =1
    b8e0:      	cmp	x14, x15
    b8e4:      	b.ge	0xb9a0 <_stogir.vector-arithmetic.operands+0x328>
    b8e8:      	cmp	x14, #0x0
    b8ec:      	b.ne	0xb8f8 <_stogir.vector-arithmetic.operands+0x280>
    b8f0:      	mov	w15, w23
    b8f4:      	b	0xb8fc <_stogir.vector-arithmetic.operands+0x284>
    b8f8:      	mov	w15, w24
    b8fc:      	sxtw	x15, w15
    b900:      	cmp	x15, #0x0
    b904:      	cset	w26, gt
    b908:      	movz	x16, #0x0, lsl #48
    b90c:      	sub	x27, x16, x15
    b910:      	sub	x28, x27, #0x1
    b914:      	uxtb	w16, w26
    b918:      	cmp	w16, wzr
    b91c:      	b.eq	0xb958 <_stogir.vector-arithmetic.operands+0x2e0>
    b920:      	ldr	x27, [x20, #0x8]
    b924:      	cmp	x15, x27
    b928:      	b.ge	0xb778 <_stogir.vector-arithmetic.operands+0x100>
    b92c:      	ldr	x27, [x12, #0x8]
    b930:      	cmp	x15, x27
    b934:      	b.ge	0xb768 <_stogir.vector-arithmetic.operands+0xf0>
    b938:      	ldr	x27, [x20, #0x78]
    b93c:      	add	x27, x27, x15, lsl #2
    b940:      	ldr	w27, [x27]
    b944:      	sxtw	x27, w27
    b948:      	cmp	x27, #0x0
    b94c:      	cset	w27, ge
    b950:      	ubfx	x27, x27, #0, #8
    b954:      	b	0xb76c <_stogir.vector-arithmetic.operands+0xf4>
    b958:      	cmp	x15, #0x0
    b95c:      	b.ge	0xbc28 <_stogir.vector-arithmetic.operands+0x5b0>
    b960:      	str	w4, [sp, #0x10]
    b964:      	ldr	x4, [x11, #0x8]
    b968:      	str	w5, [sp, #0x18]
    b96c:      	ldr	x5, [x13, #0x8]
    b970:      	cmp	x4, x5
    b974:      	b.ne	0xb770 <_stogir.vector-arithmetic.operands+0xf8>
    b978:      	cmp	x27, x4
    b97c:      	b.gt	0xb760 <_stogir.vector-arithmetic.operands+0xe8>
    b980:      	ldr	x4, [x20, #0x50]
    b984:      	add	x4, x4, x28, lsl #2
    b988:      	ldr	w4, [x4]
    b98c:      	sxtw	x4, w4
    b990:      	cmp	x4, #0x0
    b994:      	cset	w4, gt
    b998:      	ubfx	x27, x4, #0, #8
    b99c:      	b	0xb764 <_stogir.vector-arithmetic.operands+0xec>
    b9a0:      	sxtw	x25, w25
    b9a4:      	cmp	x25, #0x0
    b9a8:      	b.ne	0xb9b4 <_stogir.vector-arithmetic.operands+0x33c>
    b9ac:      	movz	x2, #0x0, lsl #48
    b9b0:      	b	0xb9b8 <_stogir.vector-arithmetic.operands+0x340>
    b9b4:      	mov	x2, #0x1                ; =1
    b9b8:      	cmp	x2, #0x0
    b9bc:      	b.eq	0xb9e8 <_stogir.vector-arithmetic.operands+0x370>
    b9c0:      	cmp	x21, #0x1d
    b9c4:      	b.ne	0xbaa0 <_stogir.vector-arithmetic.operands+0x428>
    b9c8:      	mov	x2, #0x1                ; =1
    b9cc:      	b	0xbaac <_stogir.vector-arithmetic.operands+0x434>
    b9d0:      	mov	x2, #0x1                ; =1
    b9d4:      	cmp	x2, #0x0
    b9d8:      	b.eq	0xba48 <_stogir.vector-arithmetic.operands+0x3d0>
    b9dc:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000b9dc:  ARM64_RELOC_PAGE21	l_stogir.493
    b9e0:      	ldr	x0, [x0]
		000000000000b9e0:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b9e4:      	mov	x1, #0x23               ; =35
    b9e8:      	cmp	x1, #0x0
    b9ec:      	b.ne	0xba00 <_stogir.vector-arithmetic.operands+0x388>
    b9f0:      	and	x0, x22, #0xffffffff
    b9f4:      	movz	x2, #0x0, lsl #48
    b9f8:      	movz	x1, #0x0, lsl #48
    b9fc:      	b	0xba04 <_stogir.vector-arithmetic.operands+0x38c>
    ba00:      	mov	x2, #0x1                ; =1
    ba04:      	str	x2, [x19]
    ba08:      	str	x0, [x19, #0x8]
    ba0c:      	str	x1, [x19, #0x10]
    ba10:      	ldr	x19, [sp, #0x20]
    ba14:      	ldr	x20, [sp, #0x28]
    ba18:      	ldr	x21, [sp, #0x30]
    ba1c:      	ldr	x22, [sp, #0x38]
    ba20:      	ldr	x23, [sp, #0x40]
    ba24:      	ldr	x24, [sp, #0x48]
    ba28:      	ldr	x25, [sp, #0x50]
    ba2c:      	ldr	x26, [sp, #0x58]
    ba30:      	ldr	x27, [sp, #0x60]
    ba34:      	ldr	x28, [sp, #0x68]
    ba38:      	ldr	x29, [sp]
    ba3c:      	ldr	x30, [sp, #0x8]
    ba40:      	add	sp, sp, #0x70
    ba44:      	ret
    ba48:      	cmp	x25, #0x0
    ba4c:      	cset	w2, gt
    ba50:      	movz	x16, #0x0, lsl #48
    ba54:      	sub	x3, x16, x25
    ba58:      	sub	x4, x3, #0x1
    ba5c:      	uxtb	w16, w2
    ba60:      	cmp	w16, wzr
    ba64:      	b.eq	0xbb0c <_stogir.vector-arithmetic.operands+0x494>
    ba68:      	ldr	x3, [x20, #0x8]
    ba6c:      	cmp	x25, x3
    ba70:      	b.ge	0xbb54 <_stogir.vector-arithmetic.operands+0x4dc>
    ba74:      	ldr	x3, [x12, #0x8]
    ba78:      	cmp	x25, x3
    ba7c:      	b.ge	0xbc10 <_stogir.vector-arithmetic.operands+0x598>
    ba80:      	ldr	x3, [x20, #0x78]
    ba84:      	add	x3, x3, x25, lsl #2
    ba88:      	ldr	w3, [x3]
    ba8c:      	sxtw	x3, w3
    ba90:      	cmp	x3, #0x0
    ba94:      	cset	w3, ge
    ba98:      	ubfx	x3, x3, #0, #8
    ba9c:      	b	0xbc14 <_stogir.vector-arithmetic.operands+0x59c>
    baa0:      	cmp	x21, #0x1e
    baa4:      	cset	w2, eq
    baa8:      	ubfx	x2, x2, #0, #8
    baac:      	cmp	x2, #0x0
    bab0:      	b.eq	0xb9d0 <_stogir.vector-arithmetic.operands+0x358>
    bab4:      	movz	x2, #0x0, lsl #48
    bab8:      	b	0xb9d4 <_stogir.vector-arithmetic.operands+0x35c>
    babc:      	movz	w3, #0x0, lsl #16
    bac0:      	uxtb	w16, w3
    bac4:      	and	w3, w16, #0x2
    bac8:      	uxtb	w3, w3
    bacc:      	ubfx	x3, x3, #0, #8
    bad0:      	cmp	x3, #0x0
    bad4:      	cset	w3, eq
    bad8:      	uxtb	w16, w3
    badc:      	cmp	w16, wzr
    bae0:      	cset	x3, eq
    bae4:      	cmp	x3, #0x0
    bae8:      	b.ne	0xbb08 <_stogir.vector-arithmetic.operands+0x490>
    baec:      	cmp	x2, #0x65
    baf0:      	b.eq	0xbb08 <_stogir.vector-arithmetic.operands+0x490>
    baf4:      	cmp	x2, #0x66
    baf8:      	b.eq	0xbb08 <_stogir.vector-arithmetic.operands+0x490>
    bafc:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000bafc:  ARM64_RELOC_PAGE21	l_stogir.494
    bb00:      	ldr	x0, [x0]
		000000000000bb00:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    bb04:      	mov	x1, #0x34               ; =52
    bb08:      	b	0xb9e8 <_stogir.vector-arithmetic.operands+0x370>
    bb0c:      	cmp	x25, #0x0
    bb10:      	b.ge	0xbb5c <_stogir.vector-arithmetic.operands+0x4e4>
    bb14:      	ldr	x5, [x11, #0x8]
    bb18:      	ldr	x6, [x13, #0x8]
    bb1c:      	cmp	x5, x6
    bb20:      	b.ne	0xbc08 <_stogir.vector-arithmetic.operands+0x590>
    bb24:      	cmp	x3, x5
    bb28:      	b.gt	0xbc18 <_stogir.vector-arithmetic.operands+0x5a0>
    bb2c:      	ldr	x3, [x20, #0x50]
    bb30:      	add	x3, x3, x4, lsl #2
    bb34:      	ldr	w3, [x3]
    bb38:      	sxtw	x3, w3
    bb3c:      	cmp	x3, #0x0
    bb40:      	cset	w3, gt
    bb44:      	ubfx	x3, x3, #0, #8
    bb48:      	b	0xbc1c <_stogir.vector-arithmetic.operands+0x5a4>
    bb4c:      	brk	#0
    bb50:      	b	0xbb4c <_stogir.vector-arithmetic.operands+0x4d4>
    bb54:      	movz	x3, #0x0, lsl #48
    bb58:      	b	0xbb60 <_stogir.vector-arithmetic.operands+0x4e8>
    bb5c:      	movz	x3, #0x0, lsl #48
    bb60:      	cmp	x3, #0x0
    bb64:      	b.eq	0xbb98 <_stogir.vector-arithmetic.operands+0x520>
    bb68:      	uxtb	w16, w2
    bb6c:      	cmp	w16, wzr
    bb70:      	b.eq	0xbb84 <_stogir.vector-arithmetic.operands+0x50c>
    bb74:      	ldr	x2, [x20]
    bb78:      	add	x2, x2, x25, lsl #4
    bb7c:      	ldr	x2, [x2]
    bb80:      	b	0xbb90 <_stogir.vector-arithmetic.operands+0x518>
    bb84:      	ldr	x2, [x20, #0x28]
    bb88:      	add	x2, x2, x4, lsl #4
    bb8c:      	ldr	x2, [x2]
    bb90:      	mov	w3, #0x1                ; =1
    bb94:      	b	0xbba0 <_stogir.vector-arithmetic.operands+0x528>
    bb98:      	movz	w3, #0x0, lsl #16
    bb9c:      	movz	x2, #0x0, lsl #48
    bba0:      	ubfx	x3, x3, #0, #32
    bba4:      	lsr	x16, x3, #0
    bba8:      	cmp	x16, #0x1
    bbac:      	b.eq	0xbbc8 <_stogir.vector-arithmetic.operands+0x550>
    bbb0:      	b.lo	0xbbb8 <_stogir.vector-arithmetic.operands+0x540>
    bbb4:      	b	0xbbcc <_stogir.vector-arithmetic.operands+0x554>
    bbb8:      	cmp	x16, #0x0
    bbbc:      	b.eq	0xbbc4 <_stogir.vector-arithmetic.operands+0x54c>
    bbc0:      	b	0xbbcc <_stogir.vector-arithmetic.operands+0x554>
    bbc4:      	b	0xbbd0 <_stogir.vector-arithmetic.operands+0x558>
    bbc8:      	b	0xbbe0 <_stogir.vector-arithmetic.operands+0x568>
    bbcc:      	b	0xbc20 <_stogir.vector-arithmetic.operands+0x5a8>
    bbd0:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000bbd0:  ARM64_RELOC_PAGE21	l_stogir.495
    bbd4:      	ldr	x0, [x0]
		000000000000bbd4:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    bbd8:      	mov	x1, #0x1d               ; =29
    bbdc:      	b	0xbb08 <_stogir.vector-arithmetic.operands+0x490>
    bbe0:      	cmp	x25, #0x0
    bbe4:      	b.le	0xbafc <_stogir.vector-arithmetic.operands+0x484>
    bbe8:      	uxtb	w2, w2
    bbec:      	cmp	x2, #0x83
    bbf0:      	b.ge	0xbabc <_stogir.vector-arithmetic.operands+0x444>
    bbf4:      	adrp	x17, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000bbf4:  ARM64_RELOC_PAGE21	l_stogir.496
    bbf8:      	ldr	x17, [x17]
		000000000000bbf8:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    bbfc:      	add	x3, x2, x17
    bc00:      	ldrb	w3, [x3]
    bc04:      	b	0xbac0 <_stogir.vector-arithmetic.operands+0x448>
    bc08:      	movz	x3, #0x0, lsl #48
    bc0c:      	b	0xbb60 <_stogir.vector-arithmetic.operands+0x4e8>
    bc10:      	movz	x3, #0x0, lsl #48
    bc14:      	b	0xbb58 <_stogir.vector-arithmetic.operands+0x4e0>
    bc18:      	movz	x3, #0x0, lsl #48
    bc1c:      	b	0xbc0c <_stogir.vector-arithmetic.operands+0x594>
    bc20:      	brk	#0
    bc24:      	b	0xbc20 <_stogir.vector-arithmetic.operands+0x5a8>
    bc28:      	str	w4, [sp, #0x10]
    bc2c:      	str	w5, [sp, #0x18]
    bc30:      	b	0xb788 <_stogir.vector-arithmetic.operands+0x110>

000000000000bc34 <_stogir.switch.key>:
    bc34:      	sub	sp, sp, #0x20
    bc38:      	str	x29, [sp]
    bc3c:      	str	x30, [sp, #0x8]
    bc40:      	mov	x29, sp
    bc44:      	str	x19, [sp, #0x10]
    bc48:      	str	x20, [sp, #0x18]
    bc4c:      	sxtw	x3, w2
    bc50:      	cmp	x3, #0x1
    bc54:      	b.lt	0xbf70 <_stogir.switch.key+0x33c>
    bc58:      	cmp	x3, #0xb
    bc5c:      	b.gt	0xbf78 <_stogir.switch.key+0x344>
    bc60:      	sxtw	x1, w1
    bc64:      	cmp	x1, #0x0
    bc68:      	cset	w4, gt
    bc6c:      	movz	x16, #0x0, lsl #48
    bc70:      	sub	x5, x16, x1
    bc74:      	add	x6, x0, #0x28
    bc78:      	sub	x7, x5, #0x1
    bc7c:      	uxtb	w16, w4
    bc80:      	cmp	w16, wzr
    bc84:      	b.eq	0xbd1c <_stogir.switch.key+0xe8>
    bc88:      	ldr	x5, [x0, #0x8]
    bc8c:      	cmp	x1, x5
    bc90:      	b.ge	0xbd60 <_stogir.switch.key+0x12c>
    bc94:      	add	x5, x0, #0x78
    bc98:      	ldr	x5, [x5, #0x8]
    bc9c:      	cmp	x1, x5
    bca0:      	b.ge	0xbe20 <_stogir.switch.key+0x1ec>
    bca4:      	ldr	x5, [x0, #0x78]
    bca8:      	add	x5, x5, x1, lsl #2
    bcac:      	ldr	w5, [x5]
    bcb0:      	sxtw	x5, w5
    bcb4:      	cmp	x5, #0x0
    bcb8:      	cset	w5, ge
    bcbc:      	ubfx	x5, x5, #0, #8
    bcc0:      	b	0xbe24 <_stogir.switch.key+0x1f0>
    bcc4:      	mov	x1, #0x1                ; =1
    bcc8:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000bcc8:  ARM64_RELOC_PAGE21	l_stogir.497
    bccc:      	ldr	x0, [x0]
		000000000000bccc:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    bcd0:      	mov	x2, #0x24               ; =36
    bcd4:      	str	x1, [x20]
    bcd8:      	str	x0, [x20, #0x8]
    bcdc:      	str	x2, [x20, #0x10]
    bce0:      	ldr	x19, [sp, #0x10]
    bce4:      	ldr	x20, [sp, #0x18]
    bce8:      	ldr	x29, [sp]
    bcec:      	ldr	x30, [sp, #0x8]
    bcf0:      	add	sp, sp, #0x20
    bcf4:      	ret
    bcf8:      	mov	w6, #0x1                ; =1
    bcfc:      	cmp	x1, #0x0
    bd00:      	b.lt	0xbe28 <_stogir.switch.key+0x1f4>
    bd04:      	mov	x20, x8
    bd08:      	mov	x1, #0x1                ; =1
    bd0c:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000bd0c:  ARM64_RELOC_PAGE21	l_stogir.498
    bd10:      	ldr	x0, [x0]
		000000000000bd10:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    bd14:      	mov	x2, #0x30               ; =48
    bd18:      	b	0xbcd4 <_stogir.switch.key+0xa0>
    bd1c:      	cmp	x1, #0x0
    bd20:      	b.ge	0xbd68 <_stogir.switch.key+0x134>
    bd24:      	add	x9, x0, #0x50
    bd28:      	ldr	x6, [x6, #0x8]
    bd2c:      	ldr	x9, [x9, #0x8]
    bd30:      	cmp	x6, x9
    bd34:      	b.ne	0xbe18 <_stogir.switch.key+0x1e4>
    bd38:      	cmp	x5, x6
    bd3c:      	b.gt	0xbed4 <_stogir.switch.key+0x2a0>
    bd40:      	ldr	x5, [x0, #0x50]
    bd44:      	add	x5, x5, x7, lsl #2
    bd48:      	ldr	w5, [x5]
    bd4c:      	sxtw	x5, w5
    bd50:      	cmp	x5, #0x0
    bd54:      	cset	w5, gt
    bd58:      	ubfx	x5, x5, #0, #8
    bd5c:      	b	0xbed8 <_stogir.switch.key+0x2a4>
    bd60:      	movz	x5, #0x0, lsl #48
    bd64:      	b	0xbd6c <_stogir.switch.key+0x138>
    bd68:      	movz	x5, #0x0, lsl #48
    bd6c:      	cmp	x5, #0x0
    bd70:      	b.eq	0xbdac <_stogir.switch.key+0x178>
    bd74:      	uxtb	w16, w4
    bd78:      	cmp	w16, wzr
    bd7c:      	b.eq	0xbd94 <_stogir.switch.key+0x160>
    bd80:      	ldr	x0, [x0]
    bd84:      	add	x0, x0, x1, lsl #4
    bd88:      	ldr	x4, [x0]
    bd8c:      	ldr	x0, [x0, #0x8]
    bd90:      	b	0xbda4 <_stogir.switch.key+0x170>
    bd94:      	ldr	x0, [x0, #0x28]
    bd98:      	add	x0, x0, x7, lsl #4
    bd9c:      	ldr	x4, [x0]
    bda0:      	ldr	x0, [x0, #0x8]
    bda4:      	mov	w5, #0x1                ; =1
    bda8:      	b	0xbdb8 <_stogir.switch.key+0x184>
    bdac:      	movz	w5, #0x0, lsl #16
    bdb0:      	movz	x4, #0x0, lsl #48
    bdb4:      	movz	x0, #0x0, lsl #48
    bdb8:      	ubfx	x5, x5, #0, #32
    bdbc:      	lsr	x16, x5, #0
    bdc0:      	cmp	x16, #0x1
    bdc4:      	b.eq	0xbde0 <_stogir.switch.key+0x1ac>
    bdc8:      	b.lo	0xbdd0 <_stogir.switch.key+0x19c>
    bdcc:      	b	0xbde4 <_stogir.switch.key+0x1b0>
    bdd0:      	cmp	x16, #0x0
    bdd4:      	b.eq	0xbddc <_stogir.switch.key+0x1a8>
    bdd8:      	b	0xbde4 <_stogir.switch.key+0x1b0>
    bddc:      	b	0xbde8 <_stogir.switch.key+0x1b4>
    bde0:      	b	0xbe00 <_stogir.switch.key+0x1cc>
    bde4:      	b	0xbf58 <_stogir.switch.key+0x324>
    bde8:      	mov	x20, x8
    bdec:      	mov	x1, #0x1                ; =1
    bdf0:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x548>
		000000000000bdf0:  ARM64_RELOC_PAGE21	l_stogir.499
    bdf4:      	ldr	x0, [x0]
		000000000000bdf4:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    bdf8:      	mov	x2, #0x1c               ; =28
    bdfc:      	b	0xbd18 <_stogir.switch.key+0xe4>
    be00:      	cmp	x3, #0x1
    be04:      	cset	w5, eq
    be08:      	cmp	x3, #0x0
    be0c:      	b.ne	0xbe50 <_stogir.switch.key+0x21c>
    be10:      	movz	w6, #0x0, lsl #16
    be14:      	b	0xbcfc <_stogir.switch.key+0xc8>
    be18:      	movz	x5, #0x0, lsl #48
    be1c:      	b	0xbd6c <_stogir.switch.key+0x138>
    be20:      	movz	x5, #0x0, lsl #48
    be24:      	b	0xbd64 <_stogir.switch.key+0x130>
    be28:      	orr	w1, w4, wzr
    be2c:      	uxtb	w4, w4
    be30:      	ubfx	x1, x1, #0, #32
    be34:      	ubfx	x1, x1, #8, #8
    be38:      	cmp	x4, x1
    be3c:      	b.eq	0xbedc <_stogir.switch.key+0x2a8>
    be40:      	cmp	x4, #0x49
    be44:      	b.eq	0xbedc <_stogir.switch.key+0x2a8>
    be48:      	mov	x20, x8
    be4c:      	b	0xbd08 <_stogir.switch.key+0xd4>
    be50:      	uxtb	w16, w5
    be54:      	cmp	w16, wzr
    be58:      	b.ne	0xbcf8 <_stogir.switch.key+0xc4>
    be5c:      	cmp	x3, #0x2
    be60:      	b.eq	0xbcf8 <_stogir.switch.key+0xc4>
    be64:      	cmp	x3, #0x7
    be68:      	b.eq	0xbcf8 <_stogir.switch.key+0xc4>
    be6c:      	cmp	x3, #0x8
    be70:      	b.eq	0xbcf8 <_stogir.switch.key+0xc4>
    be74:      	cmp	x3, #0x3
    be78:      	b.eq	0xbf50 <_stogir.switch.key+0x31c>
    be7c:      	cmp	x3, #0x9
    be80:      	b.eq	0xbf50 <_stogir.switch.key+0x31c>
    be84:      	cmp	x3, #0x4
    be88:      	b.eq	0xbf60 <_stogir.switch.key+0x32c>
    be8c:      	cmp	x3, #0xa
    be90:      	b.eq	0xbf60 <_stogir.switch.key+0x32c>
    be94:      	cmp	x3, #0xd
    be98:      	b.eq	0xbf60 <_stogir.switch.key+0x32c>
    be9c:      	cmp	x3, #0x5
    bea0:      	b.eq	0xbf68 <_stogir.switch.key+0x334>
    bea4:      	cmp	x3, #0xb
    bea8:      	b.eq	0xbf68 <_stogir.switch.key+0x334>
    beac:      	cmp	x3, #0xc
    beb0:      	b.eq	0xbf68 <_stogir.switch.key+0x334>
    beb4:      	cmp	x3, #0x6
    beb8:      	cset	w6, eq
    bebc:      	uxtb	w16, w6
    bec0:      	cmp	w16, wzr
    bec4:      	mov	w16, #0x8               ; =8
    bec8:      	movn	w17, #0x0, lsl #16
    becc:      	csel	w6, w16, w17, ne
    bed0:      	b	0xbf6c <_stogir.switch.key+0x338>
    bed4:      	movz	x5, #0x0, lsl #48
    bed8:      	b	0xbe1c <_stogir.switch.key+0x1e8>
    bedc:      	cmp	x1, x3
    bee0:      	b.ne	0xbf80 <_stogir.switch.key+0x34c>
    bee4:      	lsl	w1, w6, #3
    bee8:      	orr	w3, w0, wzr
    beec:      	sxtw	x1, w1
    bef0:      	ubfx	x3, x3, #0, #32
    bef4:      	lsr	x0, x0, #32
    bef8:      	ubfx	x0, x0, #0, #32
    befc:      	lsl	x0, x0, #32
    bf00:      	orr	x19, x0, x3
    bf04:      	cmp	x1, #0x40
    bf08:      	b.ge	0xbf20 <_stogir.switch.key+0x2ec>
    bf0c:      	lsr	x0, x19, x1
    bf10:      	cmp	x0, #0x0
    bf14:      	b.eq	0xbf20 <_stogir.switch.key+0x2ec>
    bf18:      	mov	x20, x8
    bf1c:      	b	0xbd08 <_stogir.switch.key+0xd4>
    bf20:      	uxtb	w16, w5
    bf24:      	cmp	w16, wzr
    bf28:      	b.eq	0xbf34 <_stogir.switch.key+0x300>
    bf2c:      	cmp	x19, #0x1
    bf30:      	b.hi	0xbf18 <_stogir.switch.key+0x2e4>
    bf34:      	mov	w0, w2
    bf38:      	mov	x20, x8
    bf3c:      	bl	0xbf3c <_stogir.switch.key+0x308>
		000000000000bf3c:  ARM64_RELOC_BRANCH26	_stogir.switch.sign-mask
    bf40:      	eor	x0, x0, x19
    bf44:      	movz	x1, #0x0, lsl #48
    bf48:      	movz	x2, #0x0, lsl #48
    bf4c:      	b	0xbd18 <_stogir.switch.key+0xe4>
    bf50:      	mov	w6, #0x2                ; =2
    bf54:      	b	0xbcfc <_stogir.switch.key+0xc8>
    bf58:      	brk	#0
    bf5c:      	b	0xbf58 <_stogir.switch.key+0x324>
    bf60:      	mov	w6, #0x4                ; =4
    bf64:      	b	0xbf54 <_stogir.switch.key+0x320>
    bf68:      	mov	w6, #0x8                ; =8
    bf6c:      	b	0xbf64 <_stogir.switch.key+0x330>
    bf70:      	mov	x20, x8
    bf74:      	b	0xbcc4 <_stogir.switch.key+0x90>
    bf78:      	mov	x20, x8
    bf7c:      	b	0xbcc4 <_stogir.switch.key+0x90>
    bf80:      	mov	x20, x8
    bf84:      	b	0xbd08 <_stogir.switch.key+0xd4>

000000000000bf88 <_stogir.stack.constant-size>:
    bf88:      	sub	sp, sp, #0x10
    bf8c:      	str	x29, [sp]
    bf90:      	str	x30, [sp, #0x8]
    bf94:      	mov	x29, sp
    bf98:      	mov	x2, sp
    bf9c:      	sxtw	x1, w1
    bfa0:      	sub	sp, sp, #0x10
    bfa4:      	mov	x3, sp
    bfa8:      	add	x4, x0, #0x28
    bfac:      	cmp	x1, #0x0
    bfb0:      	cset	w5, gt
    bfb4:      	movz	x16, #0x0, lsl #48
    bfb8:      	sub	x6, x16, x1
    bfbc:      	sub	x7, x6, #0x1
    bfc0:      	uxtb	w16, w5
    bfc4:      	cmp	w16, wzr
    bfc8:      	b.eq	0xc008 <_stogir.stack.constant-size+0x80>
    bfcc:      	ldr	x4, [x0, #0x8]
    bfd0:      	cmp	x1, x4
    bfd4:      	b.ge	0xc054 <_stogir.stack.constant-size+0xcc>
    bfd8:      	add	x4, x0, #0x78
    bfdc:      	ldr	x4, [x4, #0x8]
    bfe0:      	cmp	x1, x4
    bfe4:      	b.ge	0xc194 <_stogir.stack.constant-size+0x20c>
    bfe8:      	ldr	x4, [x0, #0x78]
    bfec:      	add	x4, x4, x1, lsl #2
    bff0:      	ldr	w4, [x4]
    bff4:      	sxtw	x4, w4
    bff8:      	cmp	x4, #0x0
    bffc:      	cset	w4, ge
    c000:      	ubfx	x4, x4, #0, #8
    c004:      	b	0xc198 <_stogir.stack.constant-size+0x210>
    c008:      	cmp	x1, #0x0
    c00c:      	b.ge	0xc05c <_stogir.stack.constant-size+0xd4>
    c010:      	add	x9, x0, #0x50
    c014:      	ldr	x4, [x4, #0x8]
    c018:      	ldr	x9, [x9, #0x8]
    c01c:      	cmp	x4, x9
    c020:      	b.ne	0xc04c <_stogir.stack.constant-size+0xc4>
    c024:      	cmp	x6, x4
    c028:      	b.gt	0xc21c <_stogir.stack.constant-size+0x294>
    c02c:      	ldr	x4, [x0, #0x50]
    c030:      	add	x4, x4, x7, lsl #2
    c034:      	ldr	w4, [x4]
    c038:      	sxtw	x4, w4
    c03c:      	cmp	x4, #0x0
    c040:      	cset	w4, gt
    c044:      	ubfx	x4, x4, #0, #8
    c048:      	b	0xc220 <_stogir.stack.constant-size+0x298>
    c04c:      	movz	x4, #0x0, lsl #48
    c050:      	b	0xc060 <_stogir.stack.constant-size+0xd8>
    c054:      	movz	x4, #0x0, lsl #48
    c058:      	b	0xc060 <_stogir.stack.constant-size+0xd8>
    c05c:      	movz	x4, #0x0, lsl #48
    c060:      	cmp	x4, #0x0
    c064:      	b.eq	0xc0a0 <_stogir.stack.constant-size+0x118>
    c068:      	uxtb	w16, w5
    c06c:      	cmp	w16, wzr
    c070:      	b.eq	0xc088 <_stogir.stack.constant-size+0x100>
    c074:      	ldr	x0, [x0]
    c078:      	add	x0, x0, x1, lsl #4
    c07c:      	ldr	x4, [x0]
    c080:      	ldr	x0, [x0, #0x8]
    c084:      	b	0xc098 <_stogir.stack.constant-size+0x110>
    c088:      	ldr	x0, [x0, #0x28]
    c08c:      	add	x0, x0, x7, lsl #4
    c090:      	ldr	x4, [x0]
    c094:      	ldr	x0, [x0, #0x8]
    c098:      	mov	w5, #0x1                ; =1
    c09c:      	b	0xc0ac <_stogir.stack.constant-size+0x124>
    c0a0:      	movz	w5, #0x0, lsl #16
    c0a4:      	movz	x4, #0x0, lsl #48
    c0a8:      	movz	x0, #0x0, lsl #48
    c0ac:      	ubfx	x5, x5, #0, #32
    c0b0:      	lsr	x16, x5, #0
    c0b4:      	cmp	x16, #0x1
    c0b8:      	b.eq	0xc0d4 <_stogir.stack.constant-size+0x14c>
    c0bc:      	b.lo	0xc0c4 <_stogir.stack.constant-size+0x13c>
    c0c0:      	b	0xc0d8 <_stogir.stack.constant-size+0x150>
    c0c4:      	cmp	x16, #0x0
    c0c8:      	b.eq	0xc0d0 <_stogir.stack.constant-size+0x148>
    c0cc:      	b	0xc0d8 <_stogir.stack.constant-size+0x150>
    c0d0:      	b	0xc0dc <_stogir.stack.constant-size+0x154>
    c0d4:      	b	0xc170 <_stogir.stack.constant-size+0x1e8>
    c0d8:      	b	0xc2b8 <_stogir.stack.constant-size+0x330>
    c0dc:      	mov	x1, #0x1                ; =1
    c0e0:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x78>
		000000000000c0e0:  ARM64_RELOC_PAGE21	l_stogir.500
    c0e4:      	ldr	x0, [x0]
		000000000000c0e4:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c0e8:      	mov	x3, #0x18               ; =24
    c0ec:      	b	0xc14c <_stogir.stack.constant-size+0x1c4>
    c0f0:      	mov	w4, #0x1                ; =1
    c0f4:      	ldr	w5, [x3, #0x8]
    c0f8:      	ldr	w6, [x3, #0xc]
    c0fc:      	cmp	x1, #0x0
    c100:      	b.ge	0xc13c <_stogir.stack.constant-size+0x1b4>
    c104:      	cmp	x0, #0x1
    c108:      	b.lt	0xc13c <_stogir.stack.constant-size+0x1b4>
    c10c:      	cmp	x0, #0xb
    c110:      	cset	w1, le
    c114:      	uxtb	w16, w1
    c118:      	cmp	w16, wzr
    c11c:      	b.eq	0xc13c <_stogir.stack.constant-size+0x1b4>
    c120:      	ldr	w3, [x3]
    c124:      	uxtb	w7, w3
    c128:      	ubfx	x3, x3, #8, #8
    c12c:      	cmp	x7, x3
    c130:      	b.eq	0xc224 <_stogir.stack.constant-size+0x29c>
    c134:      	cmp	x7, #0x49
    c138:      	b.eq	0xc224 <_stogir.stack.constant-size+0x29c>
    c13c:      	mov	x1, #0x1                ; =1
    c140:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x78>
		000000000000c140:  ARM64_RELOC_PAGE21	l_stogir.501
    c144:      	ldr	x0, [x0]
		000000000000c144:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    c148:      	mov	x3, #0x30               ; =48
    c14c:      	mov	sp, x2
    c150:      	str	x1, [x8]
    c154:      	str	x0, [x8, #0x8]
    c158:      	str	x3, [x8, #0x10]
    c15c:      	sub	sp, x29, #0x0
    c160:      	ldr	x29, [sp]
    c164:      	ldr	x30, [sp, #0x8]
    c168:      	add	sp, sp, #0x10
    c16c:      	ret
    c170:      	orr	w5, w4, wzr
    c174:      	str	x4, [x3]
    c178:      	ubfx	x5, x5, #0, #32
    c17c:      	str	x0, [x3, #0x8]
    c180:      	ubfx	x0, x5, #8, #8
    c184:      	cmp	x0, #0x0
    c188:      	b.ne	0xc19c <_stogir.stack.constant-size+0x214>
    c18c:      	movz	w4, #0x0, lsl #16
    c190:      	b	0xc0f4 <_stogir.stack.constant-size+0x16c>
    c194:      	movz	x4, #0x0, lsl #48
    c198:      	b	0xc058 <_stogir.stack.constant-size+0xd0>
    c19c:      	cmp	x0, #0x1
    c1a0:      	b.eq	0xc0f0 <_stogir.stack.constant-size+0x168>
    c1a4:      	cmp	x0, #0x2
    c1a8:      	b.eq	0xc0f0 <_stogir.stack.constant-size+0x168>
    c1ac:      	cmp	x0, #0x7
    c1b0:      	b.eq	0xc0f0 <_stogir.stack.constant-size+0x168>
    c1b4:      	cmp	x0, #0x8
    c1b8:      	b.eq	0xc0f0 <_stogir.stack.constant-size+0x168>
    c1bc:      	cmp	x0, #0x3
    c1c0:      	b.eq	0xc2b0 <_stogir.stack.constant-size+0x328>
    c1c4:      	cmp	x0, #0x9
    c1c8:      	b.eq	0xc2b0 <_stogir.stack.constant-size+0x328>
    c1cc:      	cmp	x0, #0x4
    c1d0:      	b.eq	0xc2c0 <_stogir.stack.constant-size+0x338>
    c1d4:      	cmp	x0, #0xa
    c1d8:      	b.eq	0xc2c0 <_stogir.stack.constant-size+0x338>
    c1dc:      	cmp	x0, #0xd
    c1e0:      	b.eq	0xc2c0 <_stogir.stack.constant-size+0x338>
    c1e4:      	cmp	x0, #0x5
    c1e8:      	b.eq	0xc2c8 <_stogir.stack.constant-size+0x340>
    c1ec:      	cmp	x0, #0xb
    c1f0:      	b.eq	0xc2c8 <_stogir.stack.constant-size+0x340>
    c1f4:      	cmp	x0, #0xc
    c1f8:      	b.eq	0xc2c8 <_stogir.stack.constant-size+0x340>
    c1fc:      	cmp	x0, #0x6
    c200:      	cset	w4, eq
    c204:      	uxtb	w16, w4
    c208:      	cmp	w16, wzr
    c20c:      	mov	w16, #0x8               ; =8
    c210:      	movn	w17, #0x0, lsl #16
    c214:      	csel	w4, w16, w17, ne
    c218:      	b	0xc2cc <_stogir.stack.constant-size+0x344>
    c21c:      	movz	x4, #0x0, lsl #48
    c220:      	b	0xc050 <_stogir.stack.constant-size+0xc8>
    c224:      	sxtw	x3, w4
    c228:      	cmp	x3, #0x0
    c22c:      	b.le	0xc13c <_stogir.stack.constant-size+0x1b4>
    c230:      	lsl	w4, w4, #3
    c234:      	ubfx	x5, x5, #0, #32
    c238:      	ubfx	x6, x6, #0, #32
    c23c:      	lsl	x6, x6, #32
    c240:      	orr	x5, x6, x5
    c244:      	cmp	x3, #0x8
    c248:      	b.ge	0xc25c <_stogir.stack.constant-size+0x2d4>
    c24c:      	sxtw	x3, w4
    c250:      	lsr	x3, x5, x3
    c254:      	cmp	x3, #0x0
    c258:      	b.ne	0xc13c <_stogir.stack.constant-size+0x1b4>
    c25c:      	cmp	x0, #0x7
    c260:      	b.lt	0xc28c <_stogir.stack.constant-size+0x304>
    c264:      	uxtb	w16, w1
    c268:      	cmp	w16, wzr
    c26c:      	b.eq	0xc28c <_stogir.stack.constant-size+0x304>
    c270:      	sub	w0, w4, #0x1
    c274:      	sxtw	x0, w0
    c278:      	mov	x16, #0x1               ; =1
    c27c:      	lsl	x0, x16, x0
    c280:      	and	x0, x0, x5
    c284:      	cmp	x0, #0x0
    c288:      	b.ne	0xc13c <_stogir.stack.constant-size+0x1b4>
    c28c:      	mov	x17, #-0x10             ; =-16
    c290:      	movk	x17, #0x7fff, lsl #48
    c294:      	cmp	x5, x17
    c298:      	b.hi	0xc13c <_stogir.stack.constant-size+0x1b4>
    c29c:      	add	x0, x5, #0xf
    c2a0:      	and	x0, x0, #0xfffffffffffffff0
    c2a4:      	movz	x1, #0x0, lsl #48
    c2a8:      	movz	x3, #0x0, lsl #48
    c2ac:      	b	0xc14c <_stogir.stack.constant-size+0x1c4>
    c2b0:      	mov	w4, #0x2                ; =2
    c2b4:      	b	0xc0f4 <_stogir.stack.constant-size+0x16c>
    c2b8:      	brk	#0
    c2bc:      	b	0xc2b8 <_stogir.stack.constant-size+0x330>
    c2c0:      	mov	w4, #0x4                ; =4
    c2c4:      	b	0xc2b4 <_stogir.stack.constant-size+0x32c>
    c2c8:      	mov	w4, #0x8                ; =8
    c2cc:      	b	0xc2c4 <_stogir.stack.constant-size+0x33c>

000000000000c2d0 <_stogir.stack.constant-size-aligned>:
    c2d0:      	sub	sp, sp, #0x10
    c2d4:      	cmp	x2, #0x10
    c2d8:      	b.lt	0xc358 <_stogir.stack.constant-size-aligned+0x88>
    c2dc:      	cmp	x2, #0x0
    c2e0:      	b.le	0xc358 <_stogir.stack.constant-size-aligned+0x88>
    c2e4:      	sub	x3, x2, #0x1
    c2e8:      	and	x3, x3, x2
    c2ec:      	cmp	x3, #0x0
    c2f0:      	b.ne	0xc358 <_stogir.stack.constant-size-aligned+0x88>
    c2f4:      	sxtw	x1, w1
    c2f8:      	cmp	x1, #0x0
    c2fc:      	cset	w3, gt
    c300:      	movz	x16, #0x0, lsl #48
    c304:      	sub	x4, x16, x1
    c308:      	add	x5, x0, #0x28
    c30c:      	sub	x6, x4, #0x1
    c310:      	uxtb	w16, w3
    c314:      	cmp	w16, wzr
    c318:      	b.eq	0xc3e8 <_stogir.stack.constant-size-aligned+0x118>
    c31c:      	ldr	x4, [x0, #0x8]
    c320:      	cmp	x1, x4
    c324:      	b.ge	0xc42c <_stogir.stack.constant-size-aligned+0x15c>
    c328:      	add	x4, x0, #0x78
    c32c:      	ldr	x4, [x4, #0x8]
    c330:      	cmp	x1, x4
    c334:      	b.ge	0xc4fc <_stogir.stack.constant-size-aligned+0x22c>
    c338:      	ldr	x4, [x0, #0x78]
    c33c:      	add	x4, x4, x1, lsl #2
    c340:      	ldr	w4, [x4]
    c344:      	sxtw	x4, w4
    c348:      	cmp	x4, #0x0
    c34c:      	cset	w4, ge
    c350:      	ubfx	x4, x4, #0, #8
    c354:      	b	0xc500 <_stogir.stack.constant-size-aligned+0x230>
    c358:      	mov	x1, #0x1                ; =1
    c35c:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x78>
		000000000000c35c:  ARM64_RELOC_PAGE21	l_stogir.502
    c360:      	ldr	x0, [x0]
		000000000000c360:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    c364:      	mov	x2, #0x20               ; =32
    c368:      	str	x1, [x8]
    c36c:      	str	x0, [x8, #0x8]
    c370:      	str	x2, [x8, #0x10]
    c374:      	add	sp, sp, #0x10
    c378:      	ret
    c37c:      	mov	w3, #0x1                ; =1
    c380:      	mov	x16, sp
    c384:      	ldr	w4, [x16, #0x8]
    c388:      	mov	x16, sp
    c38c:      	ldr	w5, [x16, #0xc]
    c390:      	cmp	x1, #0x0
    c394:      	b.ge	0xc3d4 <_stogir.stack.constant-size-aligned+0x104>
    c398:      	cmp	x0, #0x1
    c39c:      	b.lt	0xc3d4 <_stogir.stack.constant-size-aligned+0x104>
    c3a0:      	cmp	x0, #0xb
    c3a4:      	cset	w1, le
    c3a8:      	uxtb	w16, w1
    c3ac:      	cmp	w16, wzr
    c3b0:      	b.eq	0xc3d4 <_stogir.stack.constant-size-aligned+0x104>
    c3b4:      	mov	x16, sp
    c3b8:      	ldr	w6, [x16]
    c3bc:      	uxtb	w7, w6
    c3c0:      	ubfx	x6, x6, #8, #8
    c3c4:      	cmp	x7, x6
    c3c8:      	b.eq	0xc58c <_stogir.stack.constant-size-aligned+0x2bc>
    c3cc:      	cmp	x7, #0x49
    c3d0:      	b.eq	0xc58c <_stogir.stack.constant-size-aligned+0x2bc>
    c3d4:      	mov	x1, #0x1                ; =1
    c3d8:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x78>
		000000000000c3d8:  ARM64_RELOC_PAGE21	l_stogir.503
    c3dc:      	ldr	x0, [x0]
		000000000000c3dc:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    c3e0:      	mov	x2, #0x30               ; =48
    c3e4:      	b	0xc368 <_stogir.stack.constant-size-aligned+0x98>
    c3e8:      	cmp	x1, #0x0
    c3ec:      	b.ge	0xc434 <_stogir.stack.constant-size-aligned+0x164>
    c3f0:      	add	x7, x0, #0x50
    c3f4:      	ldr	x5, [x5, #0x8]
    c3f8:      	ldr	x7, [x7, #0x8]
    c3fc:      	cmp	x5, x7
    c400:      	b.ne	0xc4f4 <_stogir.stack.constant-size-aligned+0x224>
    c404:      	cmp	x4, x5
    c408:      	b.gt	0xc584 <_stogir.stack.constant-size-aligned+0x2b4>
    c40c:      	ldr	x4, [x0, #0x50]
    c410:      	add	x4, x4, x6, lsl #2
    c414:      	ldr	w4, [x4]
    c418:      	sxtw	x4, w4
    c41c:      	cmp	x4, #0x0
    c420:      	cset	w4, gt
    c424:      	ubfx	x4, x4, #0, #8
    c428:      	b	0xc588 <_stogir.stack.constant-size-aligned+0x2b8>
    c42c:      	movz	x4, #0x0, lsl #48
    c430:      	b	0xc438 <_stogir.stack.constant-size-aligned+0x168>
    c434:      	movz	x4, #0x0, lsl #48
    c438:      	cmp	x4, #0x0
    c43c:      	b.eq	0xc478 <_stogir.stack.constant-size-aligned+0x1a8>
    c440:      	uxtb	w16, w3
    c444:      	cmp	w16, wzr
    c448:      	b.eq	0xc460 <_stogir.stack.constant-size-aligned+0x190>
    c44c:      	ldr	x0, [x0]
    c450:      	add	x0, x0, x1, lsl #4
    c454:      	ldr	x3, [x0]
    c458:      	ldr	x0, [x0, #0x8]
    c45c:      	b	0xc470 <_stogir.stack.constant-size-aligned+0x1a0>
    c460:      	ldr	x0, [x0, #0x28]
    c464:      	add	x0, x0, x6, lsl #4
    c468:      	ldr	x3, [x0]
    c46c:      	ldr	x0, [x0, #0x8]
    c470:      	mov	w4, #0x1                ; =1
    c474:      	b	0xc484 <_stogir.stack.constant-size-aligned+0x1b4>
    c478:      	movz	w4, #0x0, lsl #16
    c47c:      	movz	x3, #0x0, lsl #48
    c480:      	movz	x0, #0x0, lsl #48
    c484:      	ubfx	x4, x4, #0, #32
    c488:      	lsr	x16, x4, #0
    c48c:      	cmp	x16, #0x1
    c490:      	b.eq	0xc4ac <_stogir.stack.constant-size-aligned+0x1dc>
    c494:      	b.lo	0xc49c <_stogir.stack.constant-size-aligned+0x1cc>
    c498:      	b	0xc4b0 <_stogir.stack.constant-size-aligned+0x1e0>
    c49c:      	cmp	x16, #0x0
    c4a0:      	b.eq	0xc4a8 <_stogir.stack.constant-size-aligned+0x1d8>
    c4a4:      	b	0xc4b0 <_stogir.stack.constant-size-aligned+0x1e0>
    c4a8:      	b	0xc4b4 <_stogir.stack.constant-size-aligned+0x1e4>
    c4ac:      	b	0xc4c8 <_stogir.stack.constant-size-aligned+0x1f8>
    c4b0:      	b	0xc630 <_stogir.stack.constant-size-aligned+0x360>
    c4b4:      	mov	x1, #0x1                ; =1
    c4b8:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x78>
		000000000000c4b8:  ARM64_RELOC_PAGE21	l_stogir.504
    c4bc:      	ldr	x0, [x0]
		000000000000c4bc:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    c4c0:      	mov	x2, #0x18               ; =24
    c4c4:      	b	0xc3e4 <_stogir.stack.constant-size-aligned+0x114>
    c4c8:      	orr	w4, w3, wzr
    c4cc:      	mov	x16, sp
    c4d0:      	str	x3, [x16]
    c4d4:      	ubfx	x4, x4, #0, #32
    c4d8:      	mov	x16, sp
    c4dc:      	str	x0, [x16, #0x8]
    c4e0:      	ubfx	x0, x4, #8, #8
    c4e4:      	cmp	x0, #0x0
    c4e8:      	b.ne	0xc504 <_stogir.stack.constant-size-aligned+0x234>
    c4ec:      	movz	w3, #0x0, lsl #16
    c4f0:      	b	0xc380 <_stogir.stack.constant-size-aligned+0xb0>
    c4f4:      	movz	x4, #0x0, lsl #48
    c4f8:      	b	0xc438 <_stogir.stack.constant-size-aligned+0x168>
    c4fc:      	movz	x4, #0x0, lsl #48
    c500:      	b	0xc430 <_stogir.stack.constant-size-aligned+0x160>
    c504:      	cmp	x0, #0x1
    c508:      	b.eq	0xc37c <_stogir.stack.constant-size-aligned+0xac>
    c50c:      	cmp	x0, #0x2
    c510:      	b.eq	0xc37c <_stogir.stack.constant-size-aligned+0xac>
    c514:      	cmp	x0, #0x7
    c518:      	b.eq	0xc37c <_stogir.stack.constant-size-aligned+0xac>
    c51c:      	cmp	x0, #0x8
    c520:      	b.eq	0xc37c <_stogir.stack.constant-size-aligned+0xac>
    c524:      	cmp	x0, #0x3
    c528:      	b.eq	0xc628 <_stogir.stack.constant-size-aligned+0x358>
    c52c:      	cmp	x0, #0x9
    c530:      	b.eq	0xc628 <_stogir.stack.constant-size-aligned+0x358>
    c534:      	cmp	x0, #0x4
    c538:      	b.eq	0xc638 <_stogir.stack.constant-size-aligned+0x368>
    c53c:      	cmp	x0, #0xa
    c540:      	b.eq	0xc638 <_stogir.stack.constant-size-aligned+0x368>
    c544:      	cmp	x0, #0xd
    c548:      	b.eq	0xc638 <_stogir.stack.constant-size-aligned+0x368>
    c54c:      	cmp	x0, #0x5
    c550:      	b.eq	0xc640 <_stogir.stack.constant-size-aligned+0x370>
    c554:      	cmp	x0, #0xb
    c558:      	b.eq	0xc640 <_stogir.stack.constant-size-aligned+0x370>
    c55c:      	cmp	x0, #0xc
    c560:      	b.eq	0xc640 <_stogir.stack.constant-size-aligned+0x370>
    c564:      	cmp	x0, #0x6
    c568:      	cset	w3, eq
    c56c:      	uxtb	w16, w3
    c570:      	cmp	w16, wzr
    c574:      	mov	w16, #0x8               ; =8
    c578:      	movn	w17, #0x0, lsl #16
    c57c:      	csel	w3, w16, w17, ne
    c580:      	b	0xc644 <_stogir.stack.constant-size-aligned+0x374>
    c584:      	movz	x4, #0x0, lsl #48
    c588:      	b	0xc4f8 <_stogir.stack.constant-size-aligned+0x228>
    c58c:      	sxtw	x6, w3
    c590:      	cmp	x6, #0x0
    c594:      	b.le	0xc3d4 <_stogir.stack.constant-size-aligned+0x104>
    c598:      	lsl	w3, w3, #3
    c59c:      	ubfx	x4, x4, #0, #32
    c5a0:      	ubfx	x5, x5, #0, #32
    c5a4:      	lsl	x5, x5, #32
    c5a8:      	orr	x4, x5, x4
    c5ac:      	cmp	x6, #0x8
    c5b0:      	b.ge	0xc5c4 <_stogir.stack.constant-size-aligned+0x2f4>
    c5b4:      	sxtw	x5, w3
    c5b8:      	lsr	x5, x4, x5
    c5bc:      	cmp	x5, #0x0
    c5c0:      	b.ne	0xc3d4 <_stogir.stack.constant-size-aligned+0x104>
    c5c4:      	cmp	x0, #0x7
    c5c8:      	b.lt	0xc5f4 <_stogir.stack.constant-size-aligned+0x324>
    c5cc:      	uxtb	w16, w1
    c5d0:      	cmp	w16, wzr
    c5d4:      	b.eq	0xc5f4 <_stogir.stack.constant-size-aligned+0x324>
    c5d8:      	sub	w0, w3, #0x1
    c5dc:      	sxtw	x0, w0
    c5e0:      	mov	x16, #0x1               ; =1
    c5e4:      	lsl	x0, x16, x0
    c5e8:      	and	x0, x0, x4
    c5ec:      	cmp	x0, #0x0
    c5f0:      	b.ne	0xc3d4 <_stogir.stack.constant-size-aligned+0x104>
    c5f4:      	sub	x0, x2, #0x1
    c5f8:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    c5fc:      	sub	x0, x16, x0
    c600:      	cmp	x4, x0
    c604:      	b.hi	0xc3d4 <_stogir.stack.constant-size-aligned+0x104>
    c608:      	sub	x0, x2, #0x1
    c60c:      	movz	x16, #0x0, lsl #48
    c610:      	sub	x1, x16, x2
    c614:      	add	x0, x0, x4
    c618:      	and	x0, x1, x0
    c61c:      	movz	x1, #0x0, lsl #48
    c620:      	movz	x2, #0x0, lsl #48
    c624:      	b	0xc3e4 <_stogir.stack.constant-size-aligned+0x114>
    c628:      	mov	w3, #0x2                ; =2
    c62c:      	b	0xc380 <_stogir.stack.constant-size-aligned+0xb0>
    c630:      	brk	#0
    c634:      	b	0xc630 <_stogir.stack.constant-size-aligned+0x360>
    c638:      	mov	w3, #0x4                ; =4
    c63c:      	b	0xc62c <_stogir.stack.constant-size-aligned+0x35c>
    c640:      	mov	w3, #0x8                ; =8
    c644:      	b	0xc63c <_stogir.stack.constant-size-aligned+0x36c>

000000000000c648 <_stogir.vector-lanes.compatible?>:
    c648:      	and	w3, w0, #0xf
    c64c:      	sxtw	x0, w0
    c650:      	ubfx	x4, x3, #0, #32
    c654:      	cmp	x0, #0xf
    c658:      	cset	w5, gt
    c65c:      	cmp	x0, #0x80
    c660:      	cset	w6, lt
    c664:      	cmp	x4, #0x1
    c668:      	cset	w7, ge
    c66c:      	cmp	x4, #0xd
    c670:      	cset	w4, le
    c674:      	cmp	x0, #0x0
    c678:      	b.lt	0xc684 <_stogir.vector-lanes.compatible?+0x3c>
    c67c:      	cmp	x0, #0xd
    c680:      	b.le	0xc6b8 <_stogir.vector-lanes.compatible?+0x70>
    c684:      	uxtb	w16, w5
    c688:      	cmp	w16, wzr
    c68c:      	b.eq	0xc6b4 <_stogir.vector-lanes.compatible?+0x6c>
    c690:      	uxtb	w16, w6
    c694:      	cmp	w16, wzr
    c698:      	b.eq	0xc6b4 <_stogir.vector-lanes.compatible?+0x6c>
    c69c:      	uxtb	w16, w7
    c6a0:      	cmp	w16, wzr
    c6a4:      	b.eq	0xc6b4 <_stogir.vector-lanes.compatible?+0x6c>
    c6a8:      	uxtb	w16, w4
    c6ac:      	cmp	w16, wzr
    c6b0:      	b.ne	0xc6b8 <_stogir.vector-lanes.compatible?+0x70>
    c6b4:      	movn	w3, #0x0, lsl #16
    c6b8:      	uxtb	w16, w5
    c6bc:      	cmp	w16, wzr
    c6c0:      	b.eq	0xc71c <_stogir.vector-lanes.compatible?+0xd4>
    c6c4:      	uxtb	w16, w6
    c6c8:      	cmp	w16, wzr
    c6cc:      	b.eq	0xc71c <_stogir.vector-lanes.compatible?+0xd4>
    c6d0:      	uxtb	w16, w7
    c6d4:      	cmp	w16, wzr
    c6d8:      	b.eq	0xc71c <_stogir.vector-lanes.compatible?+0xd4>
    c6dc:      	uxtb	w16, w4
    c6e0:      	cmp	w16, wzr
    c6e4:      	b.eq	0xc71c <_stogir.vector-lanes.compatible?+0xd4>
    c6e8:      	sxtw	x0, w2
    c6ec:      	cmp	x0, #0x4
    c6f0:      	cset	w4, eq
    c6f4:      	cmp	x0, #0x8
    c6f8:      	cset	w0, eq
    c6fc:      	uxtb	w16, w4
    c700:      	cmp	w16, wzr
    c704:      	b.ne	0xc72c <_stogir.vector-lanes.compatible?+0xe4>
    c708:      	uxtb	w16, w0
    c70c:      	cmp	w16, wzr
    c710:      	b.ne	0xc72c <_stogir.vector-lanes.compatible?+0xe4>
    c714:      	movz	x0, #0x0, lsl #48
    c718:      	b	0xc728 <_stogir.vector-lanes.compatible?+0xe0>
    c71c:      	movz	x0, #0x0, lsl #48
    c720:      	ret
    c724:      	movz	x0, #0x0, lsl #48
    c728:      	b	0xc720 <_stogir.vector-lanes.compatible?+0xd8>
    c72c:      	sxtw	x1, w1
    c730:      	cmp	x1, #0x0
    c734:      	b.lt	0xc724 <_stogir.vector-lanes.compatible?+0xdc>
    c738:      	cmp	x1, #0xd
    c73c:      	b.gt	0xc724 <_stogir.vector-lanes.compatible?+0xdc>
    c740:      	cmp	x1, #0x0
    c744:      	b.le	0xc75c <_stogir.vector-lanes.compatible?+0x114>
    c748:      	sxtw	x3, w3
    c74c:      	cmp	x3, x1
    c750:      	b.ne	0xc764 <_stogir.vector-lanes.compatible?+0x11c>
    c754:      	mov	x0, #0x1                ; =1
    c758:      	b	0xc760 <_stogir.vector-lanes.compatible?+0x118>
    c75c:      	movz	x0, #0x0, lsl #48
    c760:      	b	0xc728 <_stogir.vector-lanes.compatible?+0xe0>
    c764:      	cmp	x3, #0x1
    c768:      	b.lt	0xc7a4 <_stogir.vector-lanes.compatible?+0x15c>
    c76c:      	cmp	x3, #0xb
    c770:      	b.gt	0xc7a4 <_stogir.vector-lanes.compatible?+0x15c>
    c774:      	cmp	x1, #0x1
    c778:      	b.lt	0xc7ac <_stogir.vector-lanes.compatible?+0x164>
    c77c:      	cmp	x1, #0xb
    c780:      	b.gt	0xc7ac <_stogir.vector-lanes.compatible?+0x164>
    c784:      	uxtb	w16, w4
    c788:      	cmp	w16, wzr
    c78c:      	b.ne	0xc7d0 <_stogir.vector-lanes.compatible?+0x188>
    c790:      	uxtb	w16, w0
    c794:      	cmp	w16, wzr
    c798:      	b.ne	0xc7d0 <_stogir.vector-lanes.compatible?+0x188>
    c79c:      	movn	w3, #0x0, lsl #16
    c7a0:      	b	0xc7e4 <_stogir.vector-lanes.compatible?+0x19c>
    c7a4:      	movz	x0, #0x0, lsl #48
    c7a8:      	b	0xc758 <_stogir.vector-lanes.compatible?+0x110>
    c7ac:      	movz	x0, #0x0, lsl #48
    c7b0:      	b	0xc7a8 <_stogir.vector-lanes.compatible?+0x160>
    c7b4:      	mov	w2, #0x1                ; =1
    c7b8:      	sxtw	x3, w3
    c7bc:      	sxtw	x2, w2
    c7c0:      	cmp	x3, x2
    c7c4:      	cset	w0, eq
    c7c8:      	ubfx	x0, x0, #0, #8
    c7cc:      	b	0xc7b0 <_stogir.vector-lanes.compatible?+0x168>
    c7d0:      	cmp	x3, #0x0
    c7d4:      	b.ne	0xc884 <_stogir.vector-lanes.compatible?+0x23c>
    c7d8:      	movz	w3, #0x0, lsl #16
    c7dc:      	b	0xc7e4 <_stogir.vector-lanes.compatible?+0x19c>
    c7e0:      	mov	w3, #0x1                ; =1
    c7e4:      	uxtb	w16, w4
    c7e8:      	cmp	w16, wzr
    c7ec:      	b.ne	0xc804 <_stogir.vector-lanes.compatible?+0x1bc>
    c7f0:      	uxtb	w16, w0
    c7f4:      	cmp	w16, wzr
    c7f8:      	b.ne	0xc804 <_stogir.vector-lanes.compatible?+0x1bc>
    c7fc:      	movn	w2, #0x0, lsl #16
    c800:      	b	0xc7b8 <_stogir.vector-lanes.compatible?+0x170>
    c804:      	cmp	x1, #0x0
    c808:      	b.ne	0xc814 <_stogir.vector-lanes.compatible?+0x1cc>
    c80c:      	movz	w2, #0x0, lsl #16
    c810:      	b	0xc7b8 <_stogir.vector-lanes.compatible?+0x170>
    c814:      	cmp	x1, #0x1
    c818:      	b.eq	0xc7b4 <_stogir.vector-lanes.compatible?+0x16c>
    c81c:      	cmp	x1, #0x2
    c820:      	b.eq	0xc7b4 <_stogir.vector-lanes.compatible?+0x16c>
    c824:      	cmp	x1, #0x7
    c828:      	b.eq	0xc7b4 <_stogir.vector-lanes.compatible?+0x16c>
    c82c:      	cmp	x1, #0x8
    c830:      	b.eq	0xc7b4 <_stogir.vector-lanes.compatible?+0x16c>
    c834:      	cmp	x1, #0x3
    c838:      	b.eq	0xc8f4 <_stogir.vector-lanes.compatible?+0x2ac>
    c83c:      	cmp	x1, #0x9
    c840:      	b.eq	0xc8f4 <_stogir.vector-lanes.compatible?+0x2ac>
    c844:      	cmp	x1, #0x4
    c848:      	b.eq	0xc904 <_stogir.vector-lanes.compatible?+0x2bc>
    c84c:      	cmp	x1, #0xa
    c850:      	b.eq	0xc904 <_stogir.vector-lanes.compatible?+0x2bc>
    c854:      	cmp	x1, #0xd
    c858:      	b.eq	0xc904 <_stogir.vector-lanes.compatible?+0x2bc>
    c85c:      	cmp	x1, #0x5
    c860:      	b.eq	0xc914 <_stogir.vector-lanes.compatible?+0x2cc>
    c864:      	cmp	x1, #0xb
    c868:      	b.eq	0xc914 <_stogir.vector-lanes.compatible?+0x2cc>
    c86c:      	cmp	x1, #0xc
    c870:      	b.eq	0xc914 <_stogir.vector-lanes.compatible?+0x2cc>
    c874:      	cmp	x1, #0x6
    c878:      	b.eq	0xc880 <_stogir.vector-lanes.compatible?+0x238>
    c87c:      	movn	w2, #0x0, lsl #16
    c880:      	b	0xc918 <_stogir.vector-lanes.compatible?+0x2d0>
    c884:      	cmp	x3, #0x1
    c888:      	b.eq	0xc7e0 <_stogir.vector-lanes.compatible?+0x198>
    c88c:      	cmp	x3, #0x2
    c890:      	b.eq	0xc7e0 <_stogir.vector-lanes.compatible?+0x198>
    c894:      	cmp	x3, #0x7
    c898:      	b.eq	0xc7e0 <_stogir.vector-lanes.compatible?+0x198>
    c89c:      	cmp	x3, #0x8
    c8a0:      	b.eq	0xc7e0 <_stogir.vector-lanes.compatible?+0x198>
    c8a4:      	cmp	x3, #0x3
    c8a8:      	b.eq	0xc8fc <_stogir.vector-lanes.compatible?+0x2b4>
    c8ac:      	cmp	x3, #0x9
    c8b0:      	b.eq	0xc8fc <_stogir.vector-lanes.compatible?+0x2b4>
    c8b4:      	cmp	x3, #0x4
    c8b8:      	b.eq	0xc90c <_stogir.vector-lanes.compatible?+0x2c4>
    c8bc:      	cmp	x3, #0xa
    c8c0:      	b.eq	0xc90c <_stogir.vector-lanes.compatible?+0x2c4>
    c8c4:      	cmp	x3, #0xd
    c8c8:      	b.eq	0xc90c <_stogir.vector-lanes.compatible?+0x2c4>
    c8cc:      	cmp	x3, #0x5
    c8d0:      	b.eq	0xc91c <_stogir.vector-lanes.compatible?+0x2d4>
    c8d4:      	cmp	x3, #0xb
    c8d8:      	b.eq	0xc91c <_stogir.vector-lanes.compatible?+0x2d4>
    c8dc:      	cmp	x3, #0xc
    c8e0:      	b.eq	0xc91c <_stogir.vector-lanes.compatible?+0x2d4>
    c8e4:      	cmp	x3, #0x6
    c8e8:      	b.ne	0xc924 <_stogir.vector-lanes.compatible?+0x2dc>
    c8ec:      	mov	w3, w2
    c8f0:      	b	0xc928 <_stogir.vector-lanes.compatible?+0x2e0>
    c8f4:      	mov	w2, #0x2                ; =2
    c8f8:      	b	0xc7b8 <_stogir.vector-lanes.compatible?+0x170>
    c8fc:      	mov	w3, #0x2                ; =2
    c900:      	b	0xc7e4 <_stogir.vector-lanes.compatible?+0x19c>
    c904:      	mov	w2, #0x4                ; =4
    c908:      	b	0xc8f8 <_stogir.vector-lanes.compatible?+0x2b0>
    c90c:      	mov	w3, #0x4                ; =4
    c910:      	b	0xc900 <_stogir.vector-lanes.compatible?+0x2b8>
    c914:      	mov	w2, #0x8                ; =8
    c918:      	b	0xc908 <_stogir.vector-lanes.compatible?+0x2c0>
    c91c:      	mov	w3, #0x8                ; =8
    c920:      	b	0xc910 <_stogir.vector-lanes.compatible?+0x2c8>
    c924:      	movn	w3, #0x0, lsl #16
    c928:      	b	0xc920 <_stogir.vector-lanes.compatible?+0x2d8>

000000000000c92c <_stogir.vector-comparison.valid-type?>:
    c92c:      	sxtw	x0, w0
    c930:      	cmp	x0, #0xe
    c934:      	b.lt	0xc9cc <_stogir.vector-comparison.valid-type?+0xa0>
    c938:      	cmp	x0, #0x19
    c93c:      	b.gt	0xc9cc <_stogir.vector-comparison.valid-type?+0xa0>
    c940:      	sxtw	x2, w1
    c944:      	cmp	x2, #0xf
    c948:      	cset	w3, gt
    c94c:      	uxtb	w16, w3
    c950:      	cmp	w16, wzr
    c954:      	b.eq	0xc9d4 <_stogir.vector-comparison.valid-type?+0xa8>
    c958:      	cmp	x2, #0x80
    c95c:      	cset	w4, lt
    c960:      	uxtb	w16, w4
    c964:      	cmp	w16, wzr
    c968:      	b.eq	0xc9d4 <_stogir.vector-comparison.valid-type?+0xa8>
    c96c:      	and	w1, w1, #0xf
    c970:      	ubfx	x5, x1, #0, #32
    c974:      	cmp	x5, #0x1
    c978:      	cset	w6, ge
    c97c:      	uxtb	w16, w6
    c980:      	cmp	w16, wzr
    c984:      	b.eq	0xc9d4 <_stogir.vector-comparison.valid-type?+0xa8>
    c988:      	cmp	x5, #0xd
    c98c:      	cset	w5, le
    c990:      	uxtb	w16, w5
    c994:      	cmp	w16, wzr
    c998:      	b.eq	0xc9d4 <_stogir.vector-comparison.valid-type?+0xa8>
    c99c:      	cmp	x2, #0x0
    c9a0:      	cset	w7, ge
    c9a4:      	cmp	x2, #0xd
    c9a8:      	cset	w2, le
    c9ac:      	uxtb	w16, w7
    c9b0:      	cmp	w16, wzr
    c9b4:      	b.eq	0xc9e4 <_stogir.vector-comparison.valid-type?+0xb8>
    c9b8:      	uxtb	w16, w2
    c9bc:      	cmp	w16, wzr
    c9c0:      	b.eq	0xc9e4 <_stogir.vector-comparison.valid-type?+0xb8>
    c9c4:      	mov	w8, w1
    c9c8:      	b	0xca18 <_stogir.vector-comparison.valid-type?+0xec>
    c9cc:      	movz	x0, #0x0, lsl #48
    c9d0:      	ret
    c9d4:      	movz	x0, #0x0, lsl #48
    c9d8:      	b	0xc9d0 <_stogir.vector-comparison.valid-type?+0xa4>
    c9dc:      	mov	x0, #0x1                ; =1
    c9e0:      	b	0xc9d8 <_stogir.vector-comparison.valid-type?+0xac>
    c9e4:      	uxtb	w16, w3
    c9e8:      	cmp	w16, wzr
    c9ec:      	b.eq	0xca14 <_stogir.vector-comparison.valid-type?+0xe8>
    c9f0:      	uxtb	w16, w4
    c9f4:      	cmp	w16, wzr
    c9f8:      	b.eq	0xca14 <_stogir.vector-comparison.valid-type?+0xe8>
    c9fc:      	uxtb	w16, w6
    ca00:      	cmp	w16, wzr
    ca04:      	b.eq	0xca14 <_stogir.vector-comparison.valid-type?+0xe8>
    ca08:      	uxtb	w16, w5
    ca0c:      	cmp	w16, wzr
    ca10:      	b.ne	0xc9c4 <_stogir.vector-comparison.valid-type?+0x98>
    ca14:      	movn	w8, #0x0, lsl #16
    ca18:      	sxtw	x8, w8
    ca1c:      	cmp	x8, #0xc
    ca20:      	b.eq	0xc9dc <_stogir.vector-comparison.valid-type?+0xb0>
    ca24:      	cmp	x8, #0xd
    ca28:      	b.eq	0xc9dc <_stogir.vector-comparison.valid-type?+0xb0>
    ca2c:      	uxtb	w16, w7
    ca30:      	cmp	w16, wzr
    ca34:      	b.eq	0xca44 <_stogir.vector-comparison.valid-type?+0x118>
    ca38:      	uxtb	w16, w2
    ca3c:      	cmp	w16, wzr
    ca40:      	b.ne	0xca78 <_stogir.vector-comparison.valid-type?+0x14c>
    ca44:      	uxtb	w16, w3
    ca48:      	cmp	w16, wzr
    ca4c:      	b.eq	0xca74 <_stogir.vector-comparison.valid-type?+0x148>
    ca50:      	uxtb	w16, w4
    ca54:      	cmp	w16, wzr
    ca58:      	b.eq	0xca74 <_stogir.vector-comparison.valid-type?+0x148>
    ca5c:      	uxtb	w16, w6
    ca60:      	cmp	w16, wzr
    ca64:      	b.eq	0xca74 <_stogir.vector-comparison.valid-type?+0x148>
    ca68:      	uxtb	w16, w5
    ca6c:      	cmp	w16, wzr
    ca70:      	b.ne	0xca78 <_stogir.vector-comparison.valid-type?+0x14c>
    ca74:      	movn	w1, #0x0, lsl #16
    ca78:      	sxtw	x1, w1
    ca7c:      	cmp	x1, #0x1
    ca80:      	b.lt	0xca9c <_stogir.vector-comparison.valid-type?+0x170>
    ca84:      	cmp	x1, #0xb
    ca88:      	b.gt	0xca9c <_stogir.vector-comparison.valid-type?+0x170>
    ca8c:      	cmp	x0, #0x17
    ca90:      	cset	w0, le
    ca94:      	ubfx	x0, x0, #0, #8
    ca98:      	b	0xcaa0 <_stogir.vector-comparison.valid-type?+0x174>
    ca9c:      	movz	x0, #0x0, lsl #48
    caa0:      	b	0xc9e0 <_stogir.vector-comparison.valid-type?+0xb4>

000000000000caa4 <_stogir.vector-arithmetic.valid-type?>:
    caa4:      	sub	sp, sp, #0x30
    caa8:      	str	x29, [sp]
    caac:      	str	x30, [sp, #0x8]
    cab0:      	mov	x29, sp
    cab4:      	str	x19, [sp, #0x10]
    cab8:      	str	x20, [sp, #0x18]
    cabc:      	str	x21, [sp, #0x20]
    cac0:      	str	x22, [sp, #0x28]
    cac4:      	sxtw	x2, w1
    cac8:      	and	w1, w1, #0xf
    cacc:      	cmp	x2, #0xf
    cad0:      	cset	w3, gt
    cad4:      	cmp	x2, #0x80
    cad8:      	cset	w4, lt
    cadc:      	ubfx	x5, x1, #0, #32
    cae0:      	cmp	x5, #0x1
    cae4:      	cset	w6, ge
    cae8:      	cmp	x5, #0xd
    caec:      	cset	w5, le
    caf0:      	cmp	x2, #0x0
    caf4:      	b.lt	0xcb00 <_stogir.vector-arithmetic.valid-type?+0x5c>
    caf8:      	cmp	x2, #0xd
    cafc:      	b.le	0xcb34 <_stogir.vector-arithmetic.valid-type?+0x90>
    cb00:      	uxtb	w16, w3
    cb04:      	cmp	w16, wzr
    cb08:      	b.eq	0xcb30 <_stogir.vector-arithmetic.valid-type?+0x8c>
    cb0c:      	uxtb	w16, w4
    cb10:      	cmp	w16, wzr
    cb14:      	b.eq	0xcb30 <_stogir.vector-arithmetic.valid-type?+0x8c>
    cb18:      	uxtb	w16, w6
    cb1c:      	cmp	w16, wzr
    cb20:      	b.eq	0xcb30 <_stogir.vector-arithmetic.valid-type?+0x8c>
    cb24:      	uxtb	w16, w5
    cb28:      	cmp	w16, wzr
    cb2c:      	b.ne	0xcb34 <_stogir.vector-arithmetic.valid-type?+0x90>
    cb30:      	movn	w1, #0x0, lsl #16
    cb34:      	uxtb	w16, w3
    cb38:      	cmp	w16, wzr
    cb3c:      	b.eq	0xcd24 <_stogir.vector-arithmetic.valid-type?+0x280>
    cb40:      	uxtb	w16, w4
    cb44:      	cmp	w16, wzr
    cb48:      	b.eq	0xcd24 <_stogir.vector-arithmetic.valid-type?+0x280>
    cb4c:      	uxtb	w16, w6
    cb50:      	cmp	w16, wzr
    cb54:      	b.eq	0xcd24 <_stogir.vector-arithmetic.valid-type?+0x280>
    cb58:      	uxtb	w16, w5
    cb5c:      	cmp	w16, wzr
    cb60:      	b.eq	0xcd24 <_stogir.vector-arithmetic.valid-type?+0x280>
    cb64:      	sxtw	x2, w0
    cb68:      	cmp	x2, #0x1f
    cb6c:      	cset	w19, eq
    cb70:      	cmp	x2, #0x20
    cb74:      	cset	w20, eq
    cb78:      	cmp	x2, #0x2e
    cb7c:      	cset	w3, eq
    cb80:      	cmp	x2, #0x2f
    cb84:      	cset	w4, eq
    cb88:      	cmp	x2, #0x30
    cb8c:      	cset	w5, eq
    cb90:      	cmp	x2, #0x1e
    cb94:      	cset	w6, eq
    cb98:      	cmp	x2, #0x31
    cb9c:      	cset	w7, ge
    cba0:      	cmp	x2, #0x35
    cba4:      	cset	w8, le
    cba8:      	cmp	x2, #0x3a
    cbac:      	cset	w9, eq
    cbb0:      	cmp	x2, #0x3b
    cbb4:      	cset	w10, eq
    cbb8:      	cmp	x2, #0x2d
    cbbc:      	cset	w11, eq
    cbc0:      	cmp	x2, #0x36
    cbc4:      	cset	w12, eq
    cbc8:      	cmp	x2, #0x37
    cbcc:      	cset	w13, eq
    cbd0:      	cmp	x2, #0x38
    cbd4:      	cset	w14, eq
    cbd8:      	cmp	x2, #0x39
    cbdc:      	cset	w15, eq
    cbe0:      	uxtb	w16, w19
    cbe4:      	cmp	w16, wzr
    cbe8:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cbec:      	uxtb	w16, w20
    cbf0:      	cmp	w16, wzr
    cbf4:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cbf8:      	uxtb	w16, w11
    cbfc:      	cmp	w16, wzr
    cc00:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc04:      	uxtb	w16, w12
    cc08:      	cmp	w16, wzr
    cc0c:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc10:      	uxtb	w16, w13
    cc14:      	cmp	w16, wzr
    cc18:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc1c:      	uxtb	w16, w14
    cc20:      	cmp	w16, wzr
    cc24:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc28:      	uxtb	w16, w15
    cc2c:      	cmp	w16, wzr
    cc30:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc34:      	uxtb	w16, w9
    cc38:      	cmp	w16, wzr
    cc3c:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc40:      	uxtb	w16, w10
    cc44:      	cmp	w16, wzr
    cc48:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc4c:      	uxtb	w16, w7
    cc50:      	cmp	w16, wzr
    cc54:      	b.eq	0xce30 <_stogir.vector-arithmetic.valid-type?+0x38c>
    cc58:      	uxtb	w16, w8
    cc5c:      	cmp	w16, wzr
    cc60:      	b.eq	0xce30 <_stogir.vector-arithmetic.valid-type?+0x38c>
    cc64:      	sxtw	x2, w1
    cc68:      	cmp	x2, #0xc
    cc6c:      	cset	w21, eq
    cc70:      	cmp	x2, #0xd
    cc74:      	cset	w22, eq
    cc78:      	uxtb	w16, w19
    cc7c:      	cmp	w16, wzr
    cc80:      	b.ne	0xcd50 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    cc84:      	uxtb	w16, w20
    cc88:      	cmp	w16, wzr
    cc8c:      	b.ne	0xcd50 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    cc90:      	uxtb	w16, w11
    cc94:      	cmp	w16, wzr
    cc98:      	b.ne	0xcd50 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    cc9c:      	uxtb	w16, w12
    cca0:      	cmp	w16, wzr
    cca4:      	b.ne	0xcd50 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    cca8:      	uxtb	w16, w13
    ccac:      	cmp	w16, wzr
    ccb0:      	b.ne	0xcd50 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    ccb4:      	uxtb	w16, w14
    ccb8:      	cmp	w16, wzr
    ccbc:      	b.ne	0xcd50 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    ccc0:      	uxtb	w16, w15
    ccc4:      	cmp	w16, wzr
    ccc8:      	b.ne	0xcd50 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    cccc:      	cmp	x2, #0x1
    ccd0:      	cset	w0, eq
    ccd4:      	cmp	x2, #0x1
    ccd8:      	cset	w1, ge
    ccdc:      	cmp	x2, #0xb
    cce0:      	cset	w2, le
    cce4:      	uxtb	w16, w7
    cce8:      	cmp	w16, wzr
    ccec:      	b.eq	0xcda0 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    ccf0:      	uxtb	w16, w8
    ccf4:      	cmp	w16, wzr
    ccf8:      	b.eq	0xcda0 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    ccfc:      	uxtb	w16, w1
    cd00:      	cmp	w16, wzr
    cd04:      	b.eq	0xce28 <_stogir.vector-arithmetic.valid-type?+0x384>
    cd08:      	uxtb	w16, w2
    cd0c:      	cmp	w16, wzr
    cd10:      	b.eq	0xce28 <_stogir.vector-arithmetic.valid-type?+0x384>
    cd14:      	uxtb	w16, w0
    cd18:      	cmp	w16, wzr
    cd1c:      	cset	x0, eq
    cd20:      	b	0xce2c <_stogir.vector-arithmetic.valid-type?+0x388>
    cd24:      	movz	x0, #0x0, lsl #48
    cd28:      	ldr	x19, [sp, #0x10]
    cd2c:      	ldr	x20, [sp, #0x18]
    cd30:      	ldr	x21, [sp, #0x20]
    cd34:      	ldr	x22, [sp, #0x28]
    cd38:      	ldr	x29, [sp]
    cd3c:      	ldr	x30, [sp, #0x8]
    cd40:      	add	sp, sp, #0x30
    cd44:      	ret
    cd48:      	ubfx	x0, x20, #0, #8
    cd4c:      	b	0xcd28 <_stogir.vector-arithmetic.valid-type?+0x284>
    cd50:      	bl	0xcd50 <_stogir.vector-arithmetic.valid-type?+0x2ac>
		000000000000cd50:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    cd54:      	cmp	x0, #0x0
    cd58:      	b.eq	0xcd64 <_stogir.vector-arithmetic.valid-type?+0x2c0>
    cd5c:      	mov	x0, #0x1                ; =1
    cd60:      	b	0xcd4c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    cd64:      	uxtb	w16, w21
    cd68:      	cmp	w16, wzr
    cd6c:      	b.ne	0xcd84 <_stogir.vector-arithmetic.valid-type?+0x2e0>
    cd70:      	uxtb	w16, w22
    cd74:      	cmp	w16, wzr
    cd78:      	b.ne	0xcd84 <_stogir.vector-arithmetic.valid-type?+0x2e0>
    cd7c:      	movz	x0, #0x0, lsl #48
    cd80:      	b	0xcd4c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    cd84:      	uxtb	w16, w19
    cd88:      	cmp	w16, wzr
    cd8c:      	b.eq	0xcd48 <_stogir.vector-arithmetic.valid-type?+0x2a4>
    cd90:      	mov	x0, #0x1                ; =1
    cd94:      	b	0xcd4c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    cd98:      	movz	x0, #0x0, lsl #48
    cd9c:      	b	0xcd4c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    cda0:      	uxtb	w16, w3
    cda4:      	cmp	w16, wzr
    cda8:      	b.ne	0xce14 <_stogir.vector-arithmetic.valid-type?+0x370>
    cdac:      	uxtb	w16, w4
    cdb0:      	cmp	w16, wzr
    cdb4:      	b.ne	0xce14 <_stogir.vector-arithmetic.valid-type?+0x370>
    cdb8:      	uxtb	w16, w5
    cdbc:      	cmp	w16, wzr
    cdc0:      	b.ne	0xce14 <_stogir.vector-arithmetic.valid-type?+0x370>
    cdc4:      	uxtb	w16, w21
    cdc8:      	cmp	w16, wzr
    cdcc:      	b.ne	0xce88 <_stogir.vector-arithmetic.valid-type?+0x3e4>
    cdd0:      	uxtb	w16, w22
    cdd4:      	cmp	w16, wzr
    cdd8:      	b.ne	0xce88 <_stogir.vector-arithmetic.valid-type?+0x3e4>
    cddc:      	uxtb	w16, w1
    cde0:      	cmp	w16, wzr
    cde4:      	b.eq	0xce98 <_stogir.vector-arithmetic.valid-type?+0x3f4>
    cde8:      	uxtb	w16, w2
    cdec:      	cmp	w16, wzr
    cdf0:      	b.eq	0xce98 <_stogir.vector-arithmetic.valid-type?+0x3f4>
    cdf4:      	uxtb	w16, w0
    cdf8:      	cmp	w16, wzr
    cdfc:      	b.eq	0xcea0 <_stogir.vector-arithmetic.valid-type?+0x3fc>
    ce00:      	uxtb	w16, w9
    ce04:      	cmp	w16, wzr
    ce08:      	b.eq	0xcea8 <_stogir.vector-arithmetic.valid-type?+0x404>
    ce0c:      	mov	x0, #0x1                ; =1
    ce10:      	b	0xceac <_stogir.vector-arithmetic.valid-type?+0x408>
    ce14:      	uxtb	w16, w1
    ce18:      	cmp	w16, wzr
    ce1c:      	b.eq	0xcd98 <_stogir.vector-arithmetic.valid-type?+0x2f4>
    ce20:      	ubfx	x0, x2, #0, #8
    ce24:      	b	0xcd9c <_stogir.vector-arithmetic.valid-type?+0x2f8>
    ce28:      	movz	x0, #0x0, lsl #48
    ce2c:      	b	0xcd9c <_stogir.vector-arithmetic.valid-type?+0x2f8>
    ce30:      	cmp	x2, #0x1a
    ce34:      	b.eq	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce38:      	cmp	x2, #0x1b
    ce3c:      	b.eq	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce40:      	cmp	x2, #0x1c
    ce44:      	b.eq	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce48:      	cmp	x2, #0x1d
    ce4c:      	b.eq	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce50:      	uxtb	w16, w6
    ce54:      	cmp	w16, wzr
    ce58:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce5c:      	uxtb	w16, w3
    ce60:      	cmp	w16, wzr
    ce64:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce68:      	uxtb	w16, w4
    ce6c:      	cmp	w16, wzr
    ce70:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce74:      	uxtb	w16, w5
    ce78:      	cmp	w16, wzr
    ce7c:      	b.ne	0xcc64 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce80:      	movz	x0, #0x0, lsl #48
    ce84:      	b	0xcd4c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    ce88:      	uxtb	w16, w6
    ce8c:      	cmp	w16, wzr
    ce90:      	cset	x0, eq
    ce94:      	b	0xcd9c <_stogir.vector-arithmetic.valid-type?+0x2f8>
    ce98:      	movz	x0, #0x0, lsl #48
    ce9c:      	b	0xce94 <_stogir.vector-arithmetic.valid-type?+0x3f0>
    cea0:      	mov	x0, #0x1                ; =1
    cea4:      	b	0xce9c <_stogir.vector-arithmetic.valid-type?+0x3f8>
    cea8:      	ubfx	x0, x10, #0, #8
    ceac:      	b	0xcea4 <_stogir.vector-arithmetic.valid-type?+0x400>

000000000000ceb0 <_stogir.switch.sign-mask>:
    ceb0:      	sxtw	x0, w0
    ceb4:      	cmp	x0, #0x7
    ceb8:      	b.lt	0xced4 <_stogir.switch.sign-mask+0x24>
    cebc:      	cmp	x0, #0xb
    cec0:      	b.gt	0xced4 <_stogir.switch.sign-mask+0x24>
    cec4:      	cmp	x0, #0x0
    cec8:      	b.ne	0xcef8 <_stogir.switch.sign-mask+0x48>
    cecc:      	movz	w0, #0x0, lsl #16
    ced0:      	b	0xcee0 <_stogir.switch.sign-mask+0x30>
    ced4:      	movz	x0, #0x0, lsl #48
    ced8:      	ret
    cedc:      	mov	w0, #0x1                ; =1
    cee0:      	lsl	w0, w0, #3
    cee4:      	sub	w0, w0, #0x1
    cee8:      	sxtw	x0, w0
    ceec:      	mov	x16, #0x1               ; =1
    cef0:      	lsl	x0, x16, x0
    cef4:      	b	0xced8 <_stogir.switch.sign-mask+0x28>
    cef8:      	cmp	x0, #0x1
    cefc:      	b.eq	0xcedc <_stogir.switch.sign-mask+0x2c>
    cf00:      	cmp	x0, #0x2
    cf04:      	b.eq	0xcedc <_stogir.switch.sign-mask+0x2c>
    cf08:      	cmp	x0, #0x7
    cf0c:      	b.eq	0xcedc <_stogir.switch.sign-mask+0x2c>
    cf10:      	cmp	x0, #0x8
    cf14:      	b.eq	0xcedc <_stogir.switch.sign-mask+0x2c>
    cf18:      	cmp	x0, #0x3
    cf1c:      	b.eq	0xcf78 <_stogir.switch.sign-mask+0xc8>
    cf20:      	cmp	x0, #0x9
    cf24:      	b.eq	0xcf78 <_stogir.switch.sign-mask+0xc8>
    cf28:      	cmp	x0, #0x4
    cf2c:      	b.eq	0xcf80 <_stogir.switch.sign-mask+0xd0>
    cf30:      	cmp	x0, #0xa
    cf34:      	b.eq	0xcf80 <_stogir.switch.sign-mask+0xd0>
    cf38:      	cmp	x0, #0xd
    cf3c:      	b.eq	0xcf80 <_stogir.switch.sign-mask+0xd0>
    cf40:      	cmp	x0, #0x5
    cf44:      	b.eq	0xcf88 <_stogir.switch.sign-mask+0xd8>
    cf48:      	cmp	x0, #0xb
    cf4c:      	b.eq	0xcf88 <_stogir.switch.sign-mask+0xd8>
    cf50:      	cmp	x0, #0xc
    cf54:      	b.eq	0xcf88 <_stogir.switch.sign-mask+0xd8>
    cf58:      	cmp	x0, #0x6
    cf5c:      	cset	w0, eq
    cf60:      	uxtb	w16, w0
    cf64:      	cmp	w16, wzr
    cf68:      	mov	w16, #0x8               ; =8
    cf6c:      	movn	w17, #0x0, lsl #16
    cf70:      	csel	w0, w16, w17, ne
    cf74:      	b	0xcf8c <_stogir.switch.sign-mask+0xdc>
    cf78:      	mov	w0, #0x2                ; =2
    cf7c:      	b	0xcee0 <_stogir.switch.sign-mask+0x30>
    cf80:      	mov	w0, #0x4                ; =4
    cf84:      	b	0xcf7c <_stogir.switch.sign-mask+0xcc>
    cf88:      	mov	w0, #0x8                ; =8
    cf8c:      	b	0xcf84 <_stogir.switch.sign-mask+0xd4>
