
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-callee-return-values/build/callee-return-comparison/prepare-graph/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_prepare_graph>:
       0:      	sub	sp, sp, #0x2e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x2c0]
      14:      	str	x20, [sp, #0x2c8]
      18:      	str	x21, [sp, #0x2d0]
      1c:      	str	x22, [sp, #0x2d8]
      20:      	add	x16, sp, #0x10
      24:      	orr	x3, x16, xzr
      28:      	add	x16, sp, #0x10
      2c:      	str	w2, [x16]
      30:      	add	x16, sp, #0x20
      34:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000034:  ARM64_RELOC_PAGE21	l_stogir.388
      38:      	ldr	x17, [x17]
		0000000000000038:  ARM64_RELOC_PAGEOFF12	l_stogir.388
      3c:      	str	x17, [x16]
      40:      	add	x16, sp, #0x20
      44:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000044:  ARM64_RELOC_PAGE21	l_stogir.389
      48:      	ldr	x17, [x17]
		0000000000000048:  ARM64_RELOC_PAGEOFF12	l_stogir.389
      4c:      	str	x17, [x16, #0x8]
      50:      	add	x8, sp, #0x30
      54:      	mov	x2, x3
      58:      	add	x4, sp, #0x20
      5c:      	mov	x3, #0x1                ; =1
      60:      	bl	0x60 <_gap_prepare_graph+0x60>
		0000000000000060:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare
      64:      	add	x16, sp, #0x30
      68:      	ldr	w0, [x16]
      6c:      	lsr	x16, x0, #0
      70:      	cmp	x16, #0x1
      74:      	b.eq	0x90 <_gap_prepare_graph+0x90>
      78:      	b.lo	0x80 <_gap_prepare_graph+0x80>
      7c:      	b	0x94 <_gap_prepare_graph+0x94>
      80:      	cmp	x16, #0x0
      84:      	b.eq	0x8c <_gap_prepare_graph+0x8c>
      88:      	b	0x94 <_gap_prepare_graph+0x94>
      8c:      	b	0xa0 <_gap_prepare_graph+0xa0>
      90:      	b	0x98 <_gap_prepare_graph+0x98>
      94:      	b	0x550 <_gap_prepare_graph+0x550>
      98:      	movz	x19, #0x0, lsl #48
      9c:      	b	0x524 <_gap_prepare_graph+0x524>
      a0:      	add	x16, sp, #0x30
      a4:      	orr	x0, x16, xzr
      a8:      	add	x16, sp, #0x180
      ac:      	orr	x1, x16, xzr
      b0:      	add	x0, x0, #0x8
      b4:      	add	x19, x1, #0xa0
      b8:      	add	x20, x19, #0x28
      bc:      	mov	x1, x0
      c0:      	add	x0, sp, #0x180
      c4:      	mov	x2, #0x140              ; =320
      c8:      	bl	0xc8 <_gap_prepare_graph+0xc8>
		00000000000000c8:  ARM64_RELOC_BRANCH26	_memmove
      cc:      	ldr	x0, [x19, #0x28]
      d0:      	ldr	x1, [x20, #0x8]
      d4:      	movz	x19, #0x0, lsl #48
      d8:      	movz	x2, #0x0, lsl #48
      dc:      	b	0x120 <_gap_prepare_graph+0x120>
      e0:      	movz	w3, #0x0, lsl #16
      e4:      	movz	w4, #0x0, lsl #16
      e8:      	ubfx	x3, x3, #0, #32
      ec:      	lsr	x16, x3, #0
      f0:      	cmp	x16, #0x1
      f4:      	b.eq	0x110 <_gap_prepare_graph+0x110>
      f8:      	b.lo	0x100 <_gap_prepare_graph+0x100>
      fc:      	b	0x114 <_gap_prepare_graph+0x114>
     100:      	cmp	x16, #0x0
     104:      	b.eq	0x10c <_gap_prepare_graph+0x10c>
     108:      	b	0x114 <_gap_prepare_graph+0x114>
     10c:      	b	0x148 <_gap_prepare_graph+0x148>
     110:      	b	0x118 <_gap_prepare_graph+0x118>
     114:      	b	0x548 <_gap_prepare_graph+0x548>
     118:      	sxtw	x4, w4
     11c:      	add	x19, x4, x19
     120:      	cmp	x2, x1
     124:      	b.ge	0xe0 <_gap_prepare_graph+0xe0>
     128:      	add	x3, x2, #0x1
     12c:      	add	x2, x0, x2, lsl #2
     130:      	ldr	w2, [x2]
     134:      	movn	w17, #0x0, lsl #16
     138:      	and	w4, w2, w17
     13c:      	mov	x2, x3
     140:      	mov	w3, #0x1                ; =1
     144:      	b	0xe8 <_gap_prepare_graph+0xe8>
     148:      	b	0x15c <_gap_prepare_graph+0x15c>
     14c:      	nop
     150:      	sub	x0, x0, #0x1
     154:      	add	x16, sp, #0x180
     158:      	str	x0, [x16, #0x8]
     15c:      	add	x16, sp, #0x180
     160:      	ldr	x0, [x16, #0x8]
     164:      	cmp	x0, #0x0
     168:      	b.ne	0x150 <_gap_prepare_graph+0x150>
     16c:      	add	x16, sp, #0x180
     170:      	orr	x0, x16, xzr
     174:      	add	x16, sp, #0x180
     178:      	ldr	x1, [x16, #0x10]
     17c:      	cmp	x1, #0x0
     180:      	b.le	0x1b0 <_gap_prepare_graph+0x1b0>
     184:      	add	x0, x0, #0x18
     188:      	add	x16, sp, #0x180
     18c:      	ldr	x2, [x16]
     190:      	fmov	d31, x1
     194:      	mov	x1, x2
     198:      	fmov	x2, d31
     19c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000019c:  ARM64_RELOC_PAGE21	l_stogir.390
     1a0:      	ldr	x3, [x3]
		00000000000001a0:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     1a4:      	mov	x4, #0x4                ; =4
     1a8:      	mov	x5, #0x4                ; =4
     1ac:      	bl	0x1ac <_gap_prepare_graph+0x1ac>
		00000000000001ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     1b0:      	add	x16, sp, #0x180
     1b4:      	orr	x20, x16, xzr
     1b8:      	add	x21, x20, #0x28
     1bc:      	add	x16, sp, #0x180
     1c0:      	movz	x17, #0x0, lsl #48
     1c4:      	str	x17, [x16]
     1c8:      	add	x16, sp, #0x180
     1cc:      	movz	x17, #0x0, lsl #48
     1d0:      	str	x17, [x16, #0x8]
     1d4:      	add	x16, sp, #0x180
     1d8:      	movz	x17, #0x0, lsl #48
     1dc:      	str	x17, [x16, #0x10]
     1e0:      	b	0x1f0 <_gap_prepare_graph+0x1f0>
     1e4:      	nop
     1e8:      	sub	x0, x0, #0x1
     1ec:      	str	x0, [x21, #0x8]
     1f0:      	ldr	x0, [x21, #0x8]
     1f4:      	cmp	x0, #0x0
     1f8:      	b.ne	0x1e8 <_gap_prepare_graph+0x1e8>
     1fc:      	ldr	x0, [x21, #0x10]
     200:      	cmp	x0, #0x0
     204:      	b.le	0x238 <_gap_prepare_graph+0x238>
     208:      	add	x1, x21, #0x18
     20c:      	add	x16, sp, #0x180
     210:      	ldr	x2, [x16, #0x28]
     214:      	fmov	d31, x0
     218:      	mov	x0, x1
     21c:      	mov	x1, x2
     220:      	fmov	x2, d31
     224:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000224:  ARM64_RELOC_PAGE21	l_stogir.390
     228:      	ldr	x3, [x3]
		0000000000000228:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     22c:      	mov	x4, #0x4                ; =4
     230:      	mov	x5, #0x4                ; =4
     234:      	bl	0x234 <_gap_prepare_graph+0x234>
		0000000000000234:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     238:      	add	x20, x20, #0x50
     23c:      	add	x16, sp, #0x180
     240:      	movz	x17, #0x0, lsl #48
     244:      	str	x17, [x16, #0x28]
     248:      	movz	x17, #0x0, lsl #48
     24c:      	str	x17, [x21, #0x8]
     250:      	movz	x17, #0x0, lsl #48
     254:      	str	x17, [x21, #0x10]
     258:      	b	0x268 <_gap_prepare_graph+0x268>
     25c:      	nop
     260:      	sub	x0, x0, #0x1
     264:      	str	x0, [x20, #0x8]
     268:      	ldr	x0, [x20, #0x8]
     26c:      	cmp	x0, #0x0
     270:      	b.ne	0x260 <_gap_prepare_graph+0x260>
     274:      	ldr	x0, [x20, #0x10]
     278:      	cmp	x0, #0x0
     27c:      	b.le	0x2b0 <_gap_prepare_graph+0x2b0>
     280:      	add	x1, x20, #0x18
     284:      	add	x16, sp, #0x180
     288:      	ldr	x2, [x16, #0x50]
     28c:      	fmov	d31, x0
     290:      	mov	x0, x1
     294:      	mov	x1, x2
     298:      	fmov	x2, d31
     29c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000029c:  ARM64_RELOC_PAGE21	l_stogir.391
     2a0:      	ldr	x3, [x3]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	l_stogir.391
     2a4:      	mov	x4, #0x10               ; =16
     2a8:      	mov	x5, #0x4                ; =4
     2ac:      	bl	0x2ac <_gap_prepare_graph+0x2ac>
		00000000000002ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     2b0:      	add	x16, sp, #0x180
     2b4:      	orr	x21, x16, xzr
     2b8:      	add	x22, x21, #0x78
     2bc:      	add	x16, sp, #0x180
     2c0:      	movz	x17, #0x0, lsl #48
     2c4:      	str	x17, [x16, #0x50]
     2c8:      	movz	x17, #0x0, lsl #48
     2cc:      	str	x17, [x20, #0x8]
     2d0:      	movz	x17, #0x0, lsl #48
     2d4:      	str	x17, [x20, #0x10]
     2d8:      	b	0x2e8 <_gap_prepare_graph+0x2e8>
     2dc:      	nop
     2e0:      	sub	x0, x0, #0x1
     2e4:      	str	x0, [x22, #0x8]
     2e8:      	ldr	x0, [x22, #0x8]
     2ec:      	cmp	x0, #0x0
     2f0:      	b.ne	0x2e0 <_gap_prepare_graph+0x2e0>
     2f4:      	ldr	x0, [x22, #0x10]
     2f8:      	cmp	x0, #0x0
     2fc:      	b.le	0x330 <_gap_prepare_graph+0x330>
     300:      	add	x1, x22, #0x18
     304:      	add	x16, sp, #0x180
     308:      	ldr	x2, [x16, #0x78]
     30c:      	fmov	d31, x0
     310:      	mov	x0, x1
     314:      	mov	x1, x2
     318:      	fmov	x2, d31
     31c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000031c:  ARM64_RELOC_PAGE21	l_stogir.390
     320:      	ldr	x3, [x3]
		0000000000000320:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     324:      	mov	x4, #0x4                ; =4
     328:      	mov	x5, #0x4                ; =4
     32c:      	bl	0x32c <_gap_prepare_graph+0x32c>
		000000000000032c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     330:      	add	x20, x21, #0xf0
     334:      	add	x16, sp, #0x180
     338:      	movz	x17, #0x0, lsl #48
     33c:      	str	x17, [x16, #0x78]
     340:      	movz	x17, #0x0, lsl #48
     344:      	str	x17, [x22, #0x8]
     348:      	movz	x17, #0x0, lsl #48
     34c:      	str	x17, [x22, #0x10]
     350:      	b	0x360 <_gap_prepare_graph+0x360>
     354:      	nop
     358:      	sub	x0, x0, #0x1
     35c:      	str	x0, [x20, #0x8]
     360:      	ldr	x0, [x20, #0x8]
     364:      	cmp	x0, #0x0
     368:      	b.ne	0x358 <_gap_prepare_graph+0x358>
     36c:      	ldr	x0, [x20, #0x10]
     370:      	cmp	x0, #0x0
     374:      	b.le	0x3a8 <_gap_prepare_graph+0x3a8>
     378:      	add	x1, x20, #0x18
     37c:      	add	x16, sp, #0x180
     380:      	ldr	x2, [x16, #0xf0]
     384:      	fmov	d31, x0
     388:      	mov	x0, x1
     38c:      	mov	x1, x2
     390:      	fmov	x2, d31
     394:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000394:  ARM64_RELOC_PAGE21	l_stogir.390
     398:      	ldr	x3, [x3]
		0000000000000398:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     39c:      	mov	x4, #0x4                ; =4
     3a0:      	mov	x5, #0x4                ; =4
     3a4:      	bl	0x3a4 <_gap_prepare_graph+0x3a4>
		00000000000003a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     3a8:      	add	x22, x21, #0x118
     3ac:      	add	x16, sp, #0x180
     3b0:      	movz	x17, #0x0, lsl #48
     3b4:      	str	x17, [x16, #0xf0]
     3b8:      	movz	x17, #0x0, lsl #48
     3bc:      	str	x17, [x20, #0x8]
     3c0:      	movz	x17, #0x0, lsl #48
     3c4:      	str	x17, [x20, #0x10]
     3c8:      	b	0x3d8 <_gap_prepare_graph+0x3d8>
     3cc:      	nop
     3d0:      	sub	x0, x0, #0x1
     3d4:      	str	x0, [x22, #0x8]
     3d8:      	ldr	x0, [x22, #0x8]
     3dc:      	cmp	x0, #0x0
     3e0:      	b.ne	0x3d0 <_gap_prepare_graph+0x3d0>
     3e4:      	ldr	x0, [x22, #0x10]
     3e8:      	cmp	x0, #0x0
     3ec:      	b.le	0x420 <_gap_prepare_graph+0x420>
     3f0:      	add	x1, x22, #0x18
     3f4:      	add	x16, sp, #0x180
     3f8:      	ldr	x2, [x16, #0x118]
     3fc:      	fmov	d31, x0
     400:      	mov	x0, x1
     404:      	mov	x1, x2
     408:      	fmov	x2, d31
     40c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000040c:  ARM64_RELOC_PAGE21	l_stogir.390
     410:      	ldr	x3, [x3]
		0000000000000410:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     414:      	mov	x4, #0x4                ; =4
     418:      	mov	x5, #0x4                ; =4
     41c:      	bl	0x41c <_gap_prepare_graph+0x41c>
		000000000000041c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     420:      	add	x20, x21, #0xa0
     424:      	add	x16, sp, #0x180
     428:      	movz	x17, #0x0, lsl #48
     42c:      	str	x17, [x16, #0x118]
     430:      	movz	x17, #0x0, lsl #48
     434:      	str	x17, [x22, #0x8]
     438:      	movz	x17, #0x0, lsl #48
     43c:      	str	x17, [x22, #0x10]
     440:      	b	0x450 <_gap_prepare_graph+0x450>
     444:      	nop
     448:      	sub	x0, x0, #0x1
     44c:      	str	x0, [x20, #0x8]
     450:      	ldr	x0, [x20, #0x8]
     454:      	cmp	x0, #0x0
     458:      	b.ne	0x448 <_gap_prepare_graph+0x448>
     45c:      	ldr	x0, [x20, #0x10]
     460:      	cmp	x0, #0x0
     464:      	b.le	0x498 <_gap_prepare_graph+0x498>
     468:      	add	x1, x20, #0x18
     46c:      	add	x16, sp, #0x180
     470:      	ldr	x2, [x16, #0xa0]
     474:      	fmov	d31, x0
     478:      	mov	x0, x1
     47c:      	mov	x1, x2
     480:      	fmov	x2, d31
     484:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000484:  ARM64_RELOC_PAGE21	l_stogir.392
     488:      	ldr	x3, [x3]
		0000000000000488:  ARM64_RELOC_PAGEOFF12	l_stogir.392
     48c:      	mov	x4, #0x10               ; =16
     490:      	mov	x5, #0x8                ; =8
     494:      	bl	0x494 <_gap_prepare_graph+0x494>
		0000000000000494:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     498:      	add	x21, x20, #0x28
     49c:      	add	x16, sp, #0x180
     4a0:      	movz	x17, #0x0, lsl #48
     4a4:      	str	x17, [x16, #0xa0]
     4a8:      	movz	x17, #0x0, lsl #48
     4ac:      	str	x17, [x20, #0x8]
     4b0:      	movz	x17, #0x0, lsl #48
     4b4:      	str	x17, [x20, #0x10]
     4b8:      	b	0x4c8 <_gap_prepare_graph+0x4c8>
     4bc:      	nop
     4c0:      	sub	x0, x0, #0x1
     4c4:      	str	x0, [x21, #0x8]
     4c8:      	ldr	x0, [x21, #0x8]
     4cc:      	cmp	x0, #0x0
     4d0:      	b.ne	0x4c0 <_gap_prepare_graph+0x4c0>
     4d4:      	ldr	x0, [x21, #0x10]
     4d8:      	cmp	x0, #0x0
     4dc:      	b.le	0x50c <_gap_prepare_graph+0x50c>
     4e0:      	add	x1, x21, #0x18
     4e4:      	ldr	x2, [x20, #0x28]
     4e8:      	fmov	d31, x0
     4ec:      	mov	x0, x1
     4f0:      	mov	x1, x2
     4f4:      	fmov	x2, d31
     4f8:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000004f8:  ARM64_RELOC_PAGE21	l_stogir.390
     4fc:      	ldr	x3, [x3]
		00000000000004fc:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     500:      	mov	x4, #0x4                ; =4
     504:      	mov	x5, #0x4                ; =4
     508:      	bl	0x508 <_gap_prepare_graph+0x508>
		0000000000000508:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     50c:      	movz	x17, #0x0, lsl #48
     510:      	str	x17, [x20, #0x28]
     514:      	movz	x17, #0x0, lsl #48
     518:      	str	x17, [x21, #0x8]
     51c:      	movz	x17, #0x0, lsl #48
     520:      	str	x17, [x21, #0x10]
     524:      	mov	x0, x19
     528:      	ldr	x19, [sp, #0x2c0]
     52c:      	ldr	x20, [sp, #0x2c8]
     530:      	ldr	x21, [sp, #0x2d0]
     534:      	ldr	x22, [sp, #0x2d8]
     538:      	ldr	x29, [sp]
     53c:      	ldr	x30, [sp, #0x8]
     540:      	add	sp, sp, #0x2e0
     544:      	ret
     548:      	brk	#0
     54c:      	b	0x548 <_gap_prepare_graph+0x548>
     550:      	brk	#0
     554:      	b	0x550 <_gap_prepare_graph+0x550>

0000000000000558 <_stogir.pipeline.prepare>:
     558:      	sub	sp, sp, #0x310
     55c:      	str	x29, [sp]
     560:      	str	x30, [sp, #0x8]
     564:      	mov	x29, sp
     568:      	str	x19, [sp, #0x2d0]
     56c:      	str	x20, [sp, #0x2d8]
     570:      	str	x21, [sp, #0x2e0]
     574:      	str	x22, [sp, #0x2e8]
     578:      	str	x23, [sp, #0x2f0]
     57c:      	str	x24, [sp, #0x2f8]
     580:      	str	x25, [sp, #0x300]
     584:      	mov	x19, x8
     588:      	add	x8, sp, #0x10
     58c:      	mov	x20, x0
     590:      	mov	w21, w1
     594:      	mov	x22, x2
     598:      	mov	x23, x3
     59c:      	mov	x24, x4
     5a0:      	bl	0x5a0 <_stogir.pipeline.prepare+0x48>
		00000000000005a0:  ARM64_RELOC_BRANCH26	_stogir.pipeline.validate-input
     5a4:      	add	x16, sp, #0x10
     5a8:      	ldr	w0, [x16]
     5ac:      	lsr	x16, x0, #0
     5b0:      	cmp	x16, #0x1
     5b4:      	b.eq	0x5d0 <_stogir.pipeline.prepare+0x78>
     5b8:      	b.lo	0x5c0 <_stogir.pipeline.prepare+0x68>
     5bc:      	b	0x5d4 <_stogir.pipeline.prepare+0x7c>
     5c0:      	cmp	x16, #0x0
     5c4:      	b.eq	0x5cc <_stogir.pipeline.prepare+0x74>
     5c8:      	b	0x5d4 <_stogir.pipeline.prepare+0x7c>
     5cc:      	b	0x618 <_stogir.pipeline.prepare+0xc0>
     5d0:      	b	0x5d8 <_stogir.pipeline.prepare+0x80>
     5d4:      	b	0x678 <_stogir.pipeline.prepare+0x120>
     5d8:      	add	x16, sp, #0x10
     5dc:      	orr	x0, x16, xzr
     5e0:      	add	x16, sp, #0x30
     5e4:      	orr	x25, x16, xzr
     5e8:      	add	x0, x0, #0x8
     5ec:      	add	x1, x25, #0x8
     5f0:      	add	x16, sp, #0x10
     5f4:      	ldr	x2, [x16, #0x8]
     5f8:      	ldr	x0, [x0, #0x8]
     5fc:      	add	x16, sp, #0x30
     600:      	mov	w17, #0x1               ; =1
     604:      	str	w17, [x16]
     608:      	add	x16, sp, #0x30
     60c:      	str	x2, [x16, #0x8]
     610:      	str	x0, [x1, #0x8]
     614:      	b	0x63c <_stogir.pipeline.prepare+0xe4>
     618:      	add	x16, sp, #0x180
     61c:      	orr	x25, x16, xzr
     620:      	add	x8, sp, #0x180
     624:      	mov	x0, x20
     628:      	mov	w1, w21
     62c:      	mov	x2, x22
     630:      	mov	x3, x23
     634:      	mov	x4, x24
     638:      	bl	0x638 <_stogir.pipeline.prepare+0xe0>
		0000000000000638:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare-checked
     63c:      	mov	x0, x19
     640:      	mov	x1, x25
     644:      	mov	x2, #0x148              ; =328
     648:      	bl	0x648 <_stogir.pipeline.prepare+0xf0>
		0000000000000648:  ARM64_RELOC_BRANCH26	_memmove
     64c:      	ldr	x19, [sp, #0x2d0]
     650:      	ldr	x20, [sp, #0x2d8]
     654:      	ldr	x21, [sp, #0x2e0]
     658:      	ldr	x22, [sp, #0x2e8]
     65c:      	ldr	x23, [sp, #0x2f0]
     660:      	ldr	x24, [sp, #0x2f8]
     664:      	ldr	x25, [sp, #0x300]
     668:      	ldr	x29, [sp]
     66c:      	ldr	x30, [sp, #0x8]
     670:      	add	sp, sp, #0x310
     674:      	ret
     678:      	brk	#0
     67c:      	b	0x678 <_stogir.pipeline.prepare+0x120>

0000000000000680 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32>:
     680:      	ldr	x1, [x0]
     684:      	ldr	x0, [x0, #0x8]
     688:      	str	x1, [x8]
     68c:      	str	x0, [x8, #0x8]
     690:      	movz	x17, #0x0, lsl #48
     694:      	str	x17, [x8, #0x10]
     698:      	ret

000000000000069c <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
     69c:      	ldr	x1, [x0, #0x10]
     6a0:      	ldr	x2, [x0]
     6a4:      	ldr	x3, [x0, #0x8]
     6a8:      	cmp	x1, x3
     6ac:      	b.ge	0x6d0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x34>
     6b0:      	add	x3, x1, #0x1
     6b4:      	add	x1, x2, x1, lsl #2
     6b8:      	str	x3, [x0, #0x10]
     6bc:      	ldr	w0, [x1]
     6c0:      	sxtw	x0, w0
     6c4:      	and	x0, x0, #0xffffffff
     6c8:      	mov	x1, #0x1                ; =1
     6cc:      	b	0x6d8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x3c>
     6d0:      	movz	x1, #0x0, lsl #48
     6d4:      	movz	x0, #0x0, lsl #48
     6d8:      	fmov	d31, x0
     6dc:      	mov	x0, x1
     6e0:      	fmov	x1, d31
     6e4:      	ret

00000000000006e8 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate>:
     6e8:      	sub	sp, sp, #0x40
     6ec:      	str	x29, [sp]
     6f0:      	str	x30, [sp, #0x8]
     6f4:      	mov	x29, sp
     6f8:      	str	x19, [sp, #0x20]
     6fc:      	str	x20, [sp, #0x28]
     700:      	str	x21, [sp, #0x30]
     704:      	add	x19, x29, #0x10
     708:      	mov	x20, sp
     70c:      	sub	sp, sp, #0x10
     710:      	mov	x21, sp
     714:      	ldr	x0, [x1, #0x18]
     718:      	ldr	x1, [x1, #0x10]
     71c:      	cmp	x0, #0x10
     720:      	b.gt	0x740 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x58>
     724:      	mov	x0, x1
     728:      	bl	0x728 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x40>
		0000000000000728:  ARM64_RELOC_BRANCH26	_malloc
     72c:      	cmp	x0, #0x0
     730:      	b.ne	0x770 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x88>
     734:      	movz	x1, #0x0, lsl #48
     738:      	movz	x0, #0x0, lsl #48
     73c:      	b	0x774 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x8c>
     740:      	movz	x17, #0x0, lsl #48
     744:      	str	x17, [x21]
     748:      	mov	x2, x1
     74c:      	mov	x1, x0
     750:      	mov	x0, x21
     754:      	bl	0x754 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x6c>
		0000000000000754:  ARM64_RELOC_BRANCH26	_posix_memalign
     758:      	sxtw	x0, w0
     75c:      	cmp	x0, #0x0
     760:      	b.ne	0x778 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x90>
     764:      	ldr	x0, [x21]
     768:      	mov	x1, #0x1                ; =1
     76c:      	b	0x780 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     770:      	mov	x1, #0x1                ; =1
     774:      	b	0x780 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     778:      	movz	x1, #0x0, lsl #48
     77c:      	movz	x0, #0x0, lsl #48
     780:      	mov	sp, x20
     784:      	str	x1, [x19]
     788:      	str	x0, [x19, #0x8]
     78c:      	ldr	x0, [x29, #0x10]
     790:      	ldr	x1, [x29, #0x18]
     794:      	sub	sp, x29, #0x0
     798:      	ldr	x19, [sp, #0x20]
     79c:      	ldr	x20, [sp, #0x28]
     7a0:      	ldr	x21, [sp, #0x30]
     7a4:      	ldr	x29, [sp]
     7a8:      	ldr	x30, [sp, #0x8]
     7ac:      	add	sp, sp, #0x40
     7b0:      	ret

00000000000007b4 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$resize>:
     7b4:      	ldr	x0, [x3, #0x10]
     7b8:      	ldr	x1, [x2, #0x10]
     7bc:      	cmp	x0, x1
     7c0:      	cset	w0, le
     7c4:      	ubfx	x0, x0, #0, #8
     7c8:      	ret

00000000000007cc <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap>:
     7cc:      	sub	sp, sp, #0x10
     7d0:      	str	x29, [sp]
     7d4:      	str	x30, [sp, #0x8]
     7d8:      	mov	x29, sp
     7dc:      	ldr	x0, [x3, #0x18]
     7e0:      	cmp	x0, #0x10
     7e4:      	b.le	0x814 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x48>
     7e8:      	movz	x1, #0x0, lsl #48
     7ec:      	movz	x0, #0x0, lsl #48
     7f0:      	b	0x7f8 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x2c>
     7f4:      	mov	x1, #0x1                ; =1
     7f8:      	fmov	d31, x0
     7fc:      	mov	x0, x1
     800:      	fmov	x1, d31
     804:      	ldr	x29, [sp]
     808:      	ldr	x30, [sp, #0x8]
     80c:      	add	sp, sp, #0x10
     810:      	ret
     814:      	ldr	x0, [x3, #0x10]
     818:      	fmov	d31, x0
     81c:      	mov	x0, x1
     820:      	fmov	x1, d31
     824:      	bl	0x824 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x58>
		0000000000000824:  ARM64_RELOC_BRANCH26	_realloc
     828:      	cmp	x0, #0x0
     82c:      	b.ne	0x7f4 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x28>
     830:      	movz	x1, #0x0, lsl #48
     834:      	movz	x0, #0x0, lsl #48
     838:      	b	0x7f8 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x2c>

000000000000083c <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate>:
     83c:      	sub	sp, sp, #0x10
     840:      	str	x29, [sp]
     844:      	str	x30, [sp, #0x8]
     848:      	mov	x29, sp
     84c:      	mov	x0, x1
     850:      	bl	0x850 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate+0x14>
		0000000000000850:  ARM64_RELOC_BRANCH26	_free
     854:      	movz	x0, #0x0, lsl #48
     858:      	ldr	x29, [sp]
     85c:      	ldr	x30, [sp, #0x8]
     860:      	add	sp, sp, #0x10
     864:      	ret

0000000000000868 <_stogir.pipeline.validate-input>:
     868:      	sub	sp, sp, #0x40
     86c:      	str	x29, [sp]
     870:      	str	x30, [sp, #0x8]
     874:      	mov	x29, sp
     878:      	str	x19, [sp, #0x30]
     87c:      	mov	x19, x8
     880:      	add	x8, sp, #0x10
     884:      	bl	0x884 <_stogir.pipeline.validate-input+0x1c>
		0000000000000884:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input
     888:      	add	x16, sp, #0x10
     88c:      	ldr	x0, [x16]
     890:      	str	x0, [x19]
     894:      	add	x16, sp, #0x10
     898:      	ldr	x0, [x16, #0x8]
     89c:      	str	x0, [x19, #0x8]
     8a0:      	add	x16, sp, #0x10
     8a4:      	ldr	x0, [x16, #0x10]
     8a8:      	str	x0, [x19, #0x10]
     8ac:      	ldr	x19, [sp, #0x30]
     8b0:      	ldr	x29, [sp]
     8b4:      	ldr	x30, [sp, #0x8]
     8b8:      	add	sp, sp, #0x40
     8bc:      	ret

00000000000008c0 <_stogir.pipeline.prepare-checked>:
     8c0:      	sub	sp, sp, #0xfb0
     8c4:      	str	x29, [sp]
     8c8:      	str	x30, [sp, #0x8]
     8cc:      	mov	x29, sp
     8d0:      	str	x19, [sp, #0xf60]
     8d4:      	str	x20, [sp, #0xf68]
     8d8:      	str	x21, [sp, #0xf70]
     8dc:      	str	x22, [sp, #0xf78]
     8e0:      	str	x23, [sp, #0xf80]
     8e4:      	str	x24, [sp, #0xf88]
     8e8:      	str	x25, [sp, #0xf90]
     8ec:      	str	x26, [sp, #0xf98]
     8f0:      	str	x27, [sp, #0xfa0]
     8f4:      	str	x28, [sp, #0xfa8]
     8f8:      	sxtw	x5, w1
     8fc:      	cmp	x5, #0x0
     900:      	b.gt	0x980 <_stogir.pipeline.prepare-checked+0xc0>
     904:      	str	x8, [sp, #0xed8]
     908:      	add	x16, sp, #0x10
     90c:      	orr	x19, x16, xzr
     910:      	add	x16, sp, #0x10
     914:      	mov	w17, #0x1               ; =1
     918:      	str	w17, [x16]
     91c:      	add	x0, x19, #0x8
     920:      	add	x16, sp, #0x10
     924:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000924:  ARM64_RELOC_PAGE21	l_stogir.393
     928:      	ldr	x17, [x17]
		0000000000000928:  ARM64_RELOC_PAGEOFF12	l_stogir.393
     92c:      	str	x17, [x16, #0x8]
     930:      	mov	x17, #0x17              ; =23
     934:      	str	x17, [x0, #0x8]
     938:      	ldr	x0, [sp, #0xed8]
     93c:      	mov	x1, x19
     940:      	mov	x2, #0x148              ; =328
     944:      	bl	0x944 <_stogir.pipeline.prepare-checked+0x84>
		0000000000000944:  ARM64_RELOC_BRANCH26	_memmove
     948:      	ldr	x19, [sp, #0xf60]
     94c:      	ldr	x20, [sp, #0xf68]
     950:      	ldr	x21, [sp, #0xf70]
     954:      	ldr	x22, [sp, #0xf78]
     958:      	ldr	x23, [sp, #0xf80]
     95c:      	ldr	x24, [sp, #0xf88]
     960:      	ldr	x25, [sp, #0xf90]
     964:      	ldr	x26, [sp, #0xf98]
     968:      	ldr	x27, [sp, #0xfa0]
     96c:      	ldr	x28, [sp, #0xfa8]
     970:      	ldr	x29, [sp]
     974:      	ldr	x30, [sp, #0x8]
     978:      	add	sp, sp, #0xfb0
     97c:      	ret
     980:      	mov	x19, x8
     984:      	mov	x20, x0
     988:      	mov	w21, w1
     98c:      	mov	x22, x2
     990:      	mov	x23, x3
     994:      	mov	x24, x4
     998:      	bl	0x998 <_stogir.pipeline.prepare-checked+0xd8>
		0000000000000998:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
     99c:      	cmp	x0, #0x0
     9a0:      	b.eq	0x1c20 <_stogir.pipeline.prepare-checked+0x1360>
     9a4:      	add	x16, sp, #0x160
     9a8:      	orr	x25, x16, xzr
     9ac:      	add	x8, sp, #0x160
     9b0:      	mov	x0, x20
     9b4:      	mov	x1, x24
     9b8:      	bl	0x9b8 <_stogir.pipeline.prepare-checked+0xf8>
		00000000000009b8:  ARM64_RELOC_BRANCH26	_stogir.cfg.build
     9bc:      	add	x16, sp, #0x160
     9c0:      	ldr	w0, [x16]
     9c4:      	lsr	x16, x0, #0
     9c8:      	cmp	x16, #0x1
     9cc:      	b.eq	0x9e8 <_stogir.pipeline.prepare-checked+0x128>
     9d0:      	b.lo	0x9d8 <_stogir.pipeline.prepare-checked+0x118>
     9d4:      	b	0x9ec <_stogir.pipeline.prepare-checked+0x12c>
     9d8:      	cmp	x16, #0x0
     9dc:      	b.eq	0x9e4 <_stogir.pipeline.prepare-checked+0x124>
     9e0:      	b	0x9ec <_stogir.pipeline.prepare-checked+0x12c>
     9e4:      	b	0xa30 <_stogir.pipeline.prepare-checked+0x170>
     9e8:      	b	0x9f0 <_stogir.pipeline.prepare-checked+0x130>
     9ec:      	b	0x18e8 <_stogir.pipeline.prepare-checked+0x1028>
     9f0:      	add	x16, sp, #0x1e0
     9f4:      	orr	x20, x16, xzr
     9f8:      	add	x0, x25, #0x8
     9fc:      	add	x1, x20, #0x8
     a00:      	add	x16, sp, #0x160
     a04:      	ldr	x2, [x16, #0x8]
     a08:      	ldr	x0, [x0, #0x8]
     a0c:      	add	x16, sp, #0x1e0
     a10:      	mov	w17, #0x1               ; =1
     a14:      	str	w17, [x16]
     a18:      	add	x16, sp, #0x1e0
     a1c:      	str	x2, [x16, #0x8]
     a20:      	str	x0, [x1, #0x8]
     a24:      	str	x19, [sp, #0xed8]
     a28:      	mov	x19, x20
     a2c:      	b	0x938 <_stogir.pipeline.prepare-checked+0x78>
     a30:      	add	x16, sp, #0x760
     a34:      	orr	x26, x16, xzr
     a38:      	add	x0, x25, #0x8
     a3c:      	add	x16, sp, #0x160
     a40:      	ldr	x1, [x16, #0x8]
     a44:      	ldr	x2, [x0, #0x8]
     a48:      	ldr	x3, [x0, #0x10]
     a4c:      	ldr	x4, [x0, #0x18]
     a50:      	ldr	x5, [x0, #0x20]
     a54:      	ldr	x6, [x0, #0x28]
     a58:      	ldr	x7, [x0, #0x30]
     a5c:      	ldr	x8, [x0, #0x38]
     a60:      	ldr	x9, [x0, #0x40]
     a64:      	ldr	x10, [x0, #0x48]
     a68:      	ldr	x11, [x0, #0x50]
     a6c:      	ldr	x12, [x0, #0x58]
     a70:      	ldr	x13, [x0, #0x60]
     a74:      	ldr	x14, [x0, #0x68]
     a78:      	ldr	x0, [x0, #0x70]
     a7c:      	add	x16, sp, #0x330
     a80:      	str	x1, [x16]
     a84:      	add	x16, sp, #0x330
     a88:      	str	x2, [x16, #0x8]
     a8c:      	add	x16, sp, #0x330
     a90:      	str	x3, [x16, #0x10]
     a94:      	add	x16, sp, #0x330
     a98:      	str	x4, [x16, #0x18]
     a9c:      	add	x16, sp, #0x330
     aa0:      	str	x5, [x16, #0x20]
     aa4:      	add	x16, sp, #0x330
     aa8:      	str	x6, [x16, #0x28]
     aac:      	add	x16, sp, #0x330
     ab0:      	str	x7, [x16, #0x30]
     ab4:      	add	x16, sp, #0x330
     ab8:      	str	x8, [x16, #0x38]
     abc:      	add	x16, sp, #0x330
     ac0:      	str	x9, [x16, #0x40]
     ac4:      	add	x16, sp, #0x330
     ac8:      	str	x10, [x16, #0x48]
     acc:      	add	x16, sp, #0x330
     ad0:      	str	x11, [x16, #0x50]
     ad4:      	add	x16, sp, #0x330
     ad8:      	str	x12, [x16, #0x58]
     adc:      	add	x16, sp, #0x330
     ae0:      	str	x13, [x16, #0x60]
     ae4:      	add	x16, sp, #0x330
     ae8:      	str	x14, [x16, #0x68]
     aec:      	add	x16, sp, #0x330
     af0:      	str	x0, [x16, #0x70]
     af4:      	add	x8, sp, #0x400
     af8:      	add	x0, sp, #0x330
     afc:      	mov	x2, x24
     b00:      	mov	x1, #0x1                ; =1
     b04:      	uxtb	w1, w1
     b08:      	bl	0xb08 <_stogir.pipeline.prepare-checked+0x248>
		0000000000000b08:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     b0c:      	add	x16, sp, #0x400
     b10:      	ldr	x0, [x16]
     b14:      	add	x16, sp, #0x3b0
     b18:      	str	x0, [x16]
     b1c:      	add	x16, sp, #0x400
     b20:      	ldr	x0, [x16, #0x8]
     b24:      	add	x16, sp, #0x3b0
     b28:      	str	x0, [x16, #0x8]
     b2c:      	add	x16, sp, #0x400
     b30:      	ldr	x0, [x16, #0x10]
     b34:      	add	x16, sp, #0x3b0
     b38:      	str	x0, [x16, #0x10]
     b3c:      	add	x16, sp, #0x400
     b40:      	ldr	x0, [x16, #0x18]
     b44:      	add	x16, sp, #0x3b0
     b48:      	str	x0, [x16, #0x18]
     b4c:      	add	x16, sp, #0x400
     b50:      	ldr	x0, [x16, #0x20]
     b54:      	add	x16, sp, #0x3b0
     b58:      	str	x0, [x16, #0x20]
     b5c:      	add	x16, sp, #0x400
     b60:      	ldr	x0, [x16, #0x28]
     b64:      	add	x16, sp, #0x3b0
     b68:      	str	x0, [x16, #0x28]
     b6c:      	add	x16, sp, #0x400
     b70:      	ldr	x0, [x16, #0x30]
     b74:      	add	x16, sp, #0x3b0
     b78:      	str	x0, [x16, #0x30]
     b7c:      	add	x16, sp, #0x400
     b80:      	ldr	x0, [x16, #0x38]
     b84:      	add	x16, sp, #0x3b0
     b88:      	str	x0, [x16, #0x38]
     b8c:      	add	x16, sp, #0x400
     b90:      	ldr	x0, [x16, #0x40]
     b94:      	add	x16, sp, #0x3b0
     b98:      	str	x0, [x16, #0x40]
     b9c:      	add	x16, sp, #0x400
     ba0:      	ldr	x0, [x16, #0x48]
     ba4:      	add	x16, sp, #0x3b0
     ba8:      	str	x0, [x16, #0x48]
     bac:      	add	x8, sp, #0x4a0
     bb0:      	add	x0, sp, #0x330
     bb4:      	mov	x2, x24
     bb8:      	movz	x1, #0x0, lsl #48
     bbc:      	uxtb	w1, w1
     bc0:      	bl	0xbc0 <_stogir.pipeline.prepare-checked+0x300>
		0000000000000bc0:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     bc4:      	add	x16, sp, #0x4a0
     bc8:      	ldr	x0, [x16]
     bcc:      	add	x16, sp, #0x450
     bd0:      	str	x0, [x16]
     bd4:      	add	x16, sp, #0x4a0
     bd8:      	ldr	x0, [x16, #0x8]
     bdc:      	add	x16, sp, #0x450
     be0:      	str	x0, [x16, #0x8]
     be4:      	add	x16, sp, #0x4a0
     be8:      	ldr	x0, [x16, #0x10]
     bec:      	add	x16, sp, #0x450
     bf0:      	str	x0, [x16, #0x10]
     bf4:      	add	x16, sp, #0x4a0
     bf8:      	ldr	x0, [x16, #0x18]
     bfc:      	add	x16, sp, #0x450
     c00:      	str	x0, [x16, #0x18]
     c04:      	add	x16, sp, #0x4a0
     c08:      	ldr	x0, [x16, #0x20]
     c0c:      	add	x16, sp, #0x450
     c10:      	str	x0, [x16, #0x20]
     c14:      	add	x16, sp, #0x4a0
     c18:      	ldr	x0, [x16, #0x28]
     c1c:      	add	x16, sp, #0x450
     c20:      	str	x0, [x16, #0x28]
     c24:      	add	x16, sp, #0x4a0
     c28:      	ldr	x0, [x16, #0x30]
     c2c:      	add	x16, sp, #0x450
     c30:      	str	x0, [x16, #0x30]
     c34:      	add	x16, sp, #0x4a0
     c38:      	ldr	x0, [x16, #0x38]
     c3c:      	add	x16, sp, #0x450
     c40:      	str	x0, [x16, #0x38]
     c44:      	add	x16, sp, #0x4a0
     c48:      	ldr	x0, [x16, #0x40]
     c4c:      	add	x16, sp, #0x450
     c50:      	str	x0, [x16, #0x40]
     c54:      	add	x16, sp, #0x4a0
     c58:      	ldr	x0, [x16, #0x48]
     c5c:      	add	x16, sp, #0x450
     c60:      	str	x0, [x16, #0x48]
     c64:      	add	x8, sp, #0x520
     c68:      	add	x0, sp, #0x330
     c6c:      	add	x1, sp, #0x450
     c70:      	mov	w2, w21
     c74:      	mov	x3, x24
     c78:      	bl	0xc78 <_stogir.pipeline.prepare-checked+0x3b8>
		0000000000000c78:  ARM64_RELOC_BRANCH26	_stogir.adjacency.reverse-postorder
     c7c:      	add	x16, sp, #0x520
     c80:      	ldr	x0, [x16]
     c84:      	add	x16, sp, #0x4f0
     c88:      	str	x0, [x16]
     c8c:      	add	x16, sp, #0x520
     c90:      	ldr	x0, [x16, #0x8]
     c94:      	add	x16, sp, #0x4f0
     c98:      	str	x0, [x16, #0x8]
     c9c:      	add	x16, sp, #0x520
     ca0:      	ldr	x0, [x16, #0x10]
     ca4:      	add	x16, sp, #0x4f0
     ca8:      	str	x0, [x16, #0x10]
     cac:      	add	x16, sp, #0x520
     cb0:      	ldr	x0, [x16, #0x18]
     cb4:      	add	x16, sp, #0x4f0
     cb8:      	str	x0, [x16, #0x18]
     cbc:      	add	x16, sp, #0x520
     cc0:      	ldr	x0, [x16, #0x20]
     cc4:      	add	x16, sp, #0x4f0
     cc8:      	str	x0, [x16, #0x20]
     ccc:      	add	x8, sp, #0x580
     cd0:      	add	x0, sp, #0x330
     cd4:      	add	x1, sp, #0x3b0
     cd8:      	add	x2, sp, #0x4f0
     cdc:      	mov	x3, x24
     ce0:      	bl	0xce0 <_stogir.pipeline.prepare-checked+0x420>
		0000000000000ce0:  ARM64_RELOC_BRANCH26	_stogir.dominators.build
     ce4:      	add	x16, sp, #0x580
     ce8:      	ldr	x0, [x16]
     cec:      	add	x16, sp, #0x550
     cf0:      	str	x0, [x16]
     cf4:      	add	x16, sp, #0x580
     cf8:      	ldr	x0, [x16, #0x8]
     cfc:      	add	x16, sp, #0x550
     d00:      	str	x0, [x16, #0x8]
     d04:      	add	x16, sp, #0x580
     d08:      	ldr	x0, [x16, #0x10]
     d0c:      	add	x16, sp, #0x550
     d10:      	str	x0, [x16, #0x10]
     d14:      	add	x16, sp, #0x580
     d18:      	ldr	x0, [x16, #0x18]
     d1c:      	add	x16, sp, #0x550
     d20:      	str	x0, [x16, #0x18]
     d24:      	add	x16, sp, #0x580
     d28:      	ldr	x0, [x16, #0x20]
     d2c:      	add	x16, sp, #0x550
     d30:      	str	x0, [x16, #0x20]
     d34:      	add	x8, sp, #0x5e0
     d38:      	add	x0, sp, #0x330
     d3c:      	add	x1, sp, #0x3b0
     d40:      	add	x2, sp, #0x550
     d44:      	mov	x3, x24
     d48:      	bl	0xd48 <_stogir.pipeline.prepare-checked+0x488>
		0000000000000d48:  ARM64_RELOC_BRANCH26	_stogir.loops.depths
     d4c:      	add	x16, sp, #0x5e0
     d50:      	ldr	x0, [x16]
     d54:      	add	x16, sp, #0x5b0
     d58:      	str	x0, [x16]
     d5c:      	add	x16, sp, #0x5e0
     d60:      	ldr	x0, [x16, #0x8]
     d64:      	add	x16, sp, #0x5b0
     d68:      	str	x0, [x16, #0x8]
     d6c:      	add	x16, sp, #0x5e0
     d70:      	ldr	x0, [x16, #0x10]
     d74:      	add	x16, sp, #0x5b0
     d78:      	str	x0, [x16, #0x10]
     d7c:      	add	x16, sp, #0x5e0
     d80:      	ldr	x0, [x16, #0x18]
     d84:      	add	x16, sp, #0x5b0
     d88:      	str	x0, [x16, #0x18]
     d8c:      	add	x16, sp, #0x5e0
     d90:      	ldr	x0, [x16, #0x20]
     d94:      	add	x16, sp, #0x5b0
     d98:      	str	x0, [x16, #0x20]
     d9c:      	add	x8, sp, #0x640
     da0:      	mov	x0, x20
     da4:      	mov	x1, x22
     da8:      	mov	x2, x23
     dac:      	mov	x3, x24
     db0:      	bl	0xdb0 <_stogir.pipeline.prepare-checked+0x4f0>
		0000000000000db0:  ARM64_RELOC_BRANCH26	_stogir.liveness.mark
     db4:      	add	x16, sp, #0x640
     db8:      	ldr	x0, [x16]
     dbc:      	add	x16, sp, #0x610
     dc0:      	str	x0, [x16]
     dc4:      	add	x16, sp, #0x640
     dc8:      	ldr	x0, [x16, #0x8]
     dcc:      	add	x16, sp, #0x610
     dd0:      	str	x0, [x16, #0x8]
     dd4:      	add	x16, sp, #0x640
     dd8:      	ldr	x0, [x16, #0x10]
     ddc:      	add	x16, sp, #0x610
     de0:      	str	x0, [x16, #0x10]
     de4:      	add	x16, sp, #0x640
     de8:      	ldr	x0, [x16, #0x18]
     dec:      	add	x16, sp, #0x610
     df0:      	str	x0, [x16, #0x18]
     df4:      	add	x16, sp, #0x640
     df8:      	ldr	x0, [x16, #0x20]
     dfc:      	add	x16, sp, #0x610
     e00:      	str	x0, [x16, #0x20]
     e04:      	add	x8, sp, #0x6c0
     e08:      	mov	x0, x20
     e0c:      	mov	x1, x24
     e10:      	bl	0xe10 <_stogir.pipeline.prepare-checked+0x550>
		0000000000000e10:  ARM64_RELOC_BRANCH26	_stogir.uses.build
     e14:      	add	x16, sp, #0x6c0
     e18:      	ldr	x0, [x16]
     e1c:      	add	x16, sp, #0x670
     e20:      	str	x0, [x16]
     e24:      	add	x16, sp, #0x6c0
     e28:      	ldr	x0, [x16, #0x8]
     e2c:      	add	x16, sp, #0x670
     e30:      	str	x0, [x16, #0x8]
     e34:      	add	x16, sp, #0x6c0
     e38:      	ldr	x0, [x16, #0x10]
     e3c:      	add	x16, sp, #0x670
     e40:      	str	x0, [x16, #0x10]
     e44:      	add	x16, sp, #0x6c0
     e48:      	ldr	x0, [x16, #0x18]
     e4c:      	add	x16, sp, #0x670
     e50:      	str	x0, [x16, #0x18]
     e54:      	add	x16, sp, #0x6c0
     e58:      	ldr	x0, [x16, #0x20]
     e5c:      	add	x16, sp, #0x670
     e60:      	str	x0, [x16, #0x20]
     e64:      	add	x16, sp, #0x6c0
     e68:      	ldr	x0, [x16, #0x28]
     e6c:      	add	x16, sp, #0x670
     e70:      	str	x0, [x16, #0x28]
     e74:      	add	x16, sp, #0x6c0
     e78:      	ldr	x0, [x16, #0x30]
     e7c:      	add	x16, sp, #0x670
     e80:      	str	x0, [x16, #0x30]
     e84:      	add	x16, sp, #0x6c0
     e88:      	ldr	x0, [x16, #0x38]
     e8c:      	add	x16, sp, #0x670
     e90:      	str	x0, [x16, #0x38]
     e94:      	add	x16, sp, #0x6c0
     e98:      	ldr	x0, [x16, #0x40]
     e9c:      	add	x16, sp, #0x670
     ea0:      	str	x0, [x16, #0x40]
     ea4:      	add	x16, sp, #0x6c0
     ea8:      	ldr	x0, [x16, #0x48]
     eac:      	add	x16, sp, #0x670
     eb0:      	str	x0, [x16, #0x48]
     eb4:      	ldr	x0, [x24]
     eb8:      	ldr	x1, [x24, #0x8]
     ebc:      	add	x16, sp, #0x710
     ec0:      	movz	x17, #0x0, lsl #48
     ec4:      	str	x17, [x16]
     ec8:      	add	x16, sp, #0x710
     ecc:      	movz	x17, #0x0, lsl #48
     ed0:      	str	x17, [x16, #0x8]
     ed4:      	add	x16, sp, #0x710
     ed8:      	movz	x17, #0x0, lsl #48
     edc:      	str	x17, [x16, #0x10]
     ee0:      	add	x16, sp, #0x710
     ee4:      	str	x0, [x16, #0x18]
     ee8:      	add	x16, sp, #0x710
     eec:      	str	x1, [x16, #0x20]
     ef0:      	add	x16, sp, #0x710
     ef4:      	movz	x17, #0x0, lsl #48
     ef8:      	str	x17, [x16, #0x28]
     efc:      	add	x16, sp, #0x710
     f00:      	movz	x17, #0x0, lsl #48
     f04:      	str	x17, [x16, #0x30]
     f08:      	add	x16, sp, #0x710
     f0c:      	movz	x17, #0x0, lsl #48
     f10:      	str	x17, [x16, #0x38]
     f14:      	add	x16, sp, #0x710
     f18:      	str	x0, [x16, #0x40]
     f1c:      	add	x16, sp, #0x710
     f20:      	str	x1, [x16, #0x48]
     f24:      	add	x8, sp, #0x760
     f28:      	mov	x0, x20
     f2c:      	add	x1, sp, #0x330
     f30:      	mov	x2, x24
     f34:      	bl	0xf34 <_stogir.pipeline.prepare-checked+0x674>
		0000000000000f34:  ARM64_RELOC_BRANCH26	_stogir.placement.pinned
     f38:      	add	x16, sp, #0x760
     f3c:      	ldr	w0, [x16]
     f40:      	lsr	x16, x0, #0
     f44:      	cmp	x16, #0x1
     f48:      	b.eq	0xf64 <_stogir.pipeline.prepare-checked+0x6a4>
     f4c:      	b.lo	0xf54 <_stogir.pipeline.prepare-checked+0x694>
     f50:      	b	0xf68 <_stogir.pipeline.prepare-checked+0x6a8>
     f54:      	cmp	x16, #0x0
     f58:      	b.eq	0xf60 <_stogir.pipeline.prepare-checked+0x6a0>
     f5c:      	b	0xf68 <_stogir.pipeline.prepare-checked+0x6a8>
     f60:      	b	0x1404 <_stogir.pipeline.prepare-checked+0xb44>
     f64:      	b	0xf6c <_stogir.pipeline.prepare-checked+0x6ac>
     f68:      	b	0x1be8 <_stogir.pipeline.prepare-checked+0x1328>
     f6c:      	add	x0, x26, #0x8
     f70:      	add	x16, sp, #0x760
     f74:      	ldr	x21, [x16, #0x8]
     f78:      	ldr	x22, [x0, #0x8]
     f7c:      	add	x0, sp, #0x3b0
     f80:      	bl	0xf80 <_stogir.pipeline.prepare-checked+0x6c0>
		0000000000000f80:  ARM64_RELOC_BRANCH26	_stogir.adjacency.release!
     f84:      	add	x0, sp, #0x450
     f88:      	bl	0xf88 <_stogir.pipeline.prepare-checked+0x6c8>
		0000000000000f88:  ARM64_RELOC_BRANCH26	_stogir.adjacency.release!
     f8c:      	b	0xf9c <_stogir.pipeline.prepare-checked+0x6dc>
     f90:      	sub	x0, x0, #0x1
     f94:      	add	x16, sp, #0x610
     f98:      	str	x0, [x16, #0x8]
     f9c:      	add	x16, sp, #0x610
     fa0:      	ldr	x0, [x16, #0x8]
     fa4:      	cmp	x0, #0x0
     fa8:      	b.ne	0xf90 <_stogir.pipeline.prepare-checked+0x6d0>
     fac:      	add	x16, sp, #0x610
     fb0:      	orr	x0, x16, xzr
     fb4:      	add	x16, sp, #0x610
     fb8:      	ldr	x1, [x16, #0x10]
     fbc:      	cmp	x1, #0x0
     fc0:      	b.le	0xff0 <_stogir.pipeline.prepare-checked+0x730>
     fc4:      	add	x0, x0, #0x18
     fc8:      	add	x16, sp, #0x610
     fcc:      	ldr	x2, [x16]
     fd0:      	fmov	d31, x1
     fd4:      	mov	x1, x2
     fd8:      	fmov	x2, d31
     fdc:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000fdc:  ARM64_RELOC_PAGE21	l_stogir.394
     fe0:      	ldr	x3, [x3]
		0000000000000fe0:  ARM64_RELOC_PAGEOFF12	l_stogir.394
     fe4:      	mov	x4, #0x1                ; =1
     fe8:      	mov	x5, #0x1                ; =1
     fec:      	bl	0xfec <_stogir.pipeline.prepare-checked+0x72c>
		0000000000000fec:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     ff0:      	add	x16, sp, #0x610
     ff4:      	movz	x17, #0x0, lsl #48
     ff8:      	str	x17, [x16]
     ffc:      	add	x16, sp, #0x610
    1000:      	movz	x17, #0x0, lsl #48
    1004:      	str	x17, [x16, #0x8]
    1008:      	add	x16, sp, #0x610
    100c:      	movz	x17, #0x0, lsl #48
    1010:      	str	x17, [x16, #0x10]
    1014:      	add	x0, sp, #0x670
    1018:      	bl	0x1018 <_stogir.pipeline.prepare-checked+0x758>
		0000000000001018:  ARM64_RELOC_BRANCH26	_stogir.uses.release!
    101c:      	cmp	x22, #0x0
    1020:      	b.ne	0x1c28 <_stogir.pipeline.prepare-checked+0x1368>
    1024:      	add	x16, sp, #0xa60
    1028:      	orr	x20, x16, xzr
    102c:      	add	x16, sp, #0xbb0
    1030:      	orr	x0, x16, xzr
    1034:      	add	x16, sp, #0xa60
    1038:      	movz	w17, #0x0, lsl #16
    103c:      	str	w17, [x16]
    1040:      	add	x1, x20, #0x8
    1044:      	add	x21, x0, #0x78
    1048:      	add	x22, x0, #0xa0
    104c:      	add	x23, x0, #0xf0
    1050:      	add	x24, x0, #0x118
    1054:      	add	x16, sp, #0x550
    1058:      	ldr	x25, [x16]
    105c:      	orr	x26, x1, xzr
    1060:      	add	x16, sp, #0x550
    1064:      	ldr	x27, [x16, #0x8]
    1068:      	add	x16, sp, #0x550
    106c:      	ldr	x28, [x16, #0x10]
    1070:      	add	x16, sp, #0x550
    1074:      	ldr	x0, [x16, #0x18]
    1078:      	add	x16, sp, #0x550
    107c:      	ldr	x1, [x16, #0x20]
    1080:      	add	x16, sp, #0x5b0
    1084:      	ldr	x2, [x16]
    1088:      	add	x16, sp, #0x5b0
    108c:      	ldr	x3, [x16, #0x8]
    1090:      	add	x16, sp, #0x5b0
    1094:      	ldr	x4, [x16, #0x10]
    1098:      	add	x16, sp, #0x5b0
    109c:      	ldr	x5, [x16, #0x18]
    10a0:      	add	x16, sp, #0x5b0
    10a4:      	ldr	x6, [x16, #0x20]
    10a8:      	add	x16, sp, #0x330
    10ac:      	ldr	x7, [x16]
    10b0:      	add	x16, sp, #0x330
    10b4:      	ldr	x8, [x16, #0x8]
    10b8:      	add	x16, sp, #0x330
    10bc:      	ldr	x9, [x16, #0x10]
    10c0:      	add	x16, sp, #0x330
    10c4:      	ldr	x10, [x16, #0x18]
    10c8:      	add	x16, sp, #0x330
    10cc:      	ldr	x11, [x16, #0x20]
    10d0:      	add	x16, sp, #0x330
    10d4:      	ldr	x12, [x16, #0x28]
    10d8:      	add	x16, sp, #0x330
    10dc:      	ldr	x13, [x16, #0x30]
    10e0:      	add	x16, sp, #0x330
    10e4:      	ldr	x14, [x16, #0x38]
    10e8:      	add	x16, sp, #0x330
    10ec:      	ldr	x15, [x16, #0x40]
    10f0:      	str	x0, [sp, #0xe30]
    10f4:      	add	x16, sp, #0x330
    10f8:      	ldr	x0, [x16, #0x48]
    10fc:      	str	x0, [sp, #0xe38]
    1100:      	add	x16, sp, #0x330
    1104:      	ldr	x0, [x16, #0x50]
    1108:      	str	x0, [sp, #0xe40]
    110c:      	add	x16, sp, #0x330
    1110:      	ldr	x0, [x16, #0x58]
    1114:      	str	x0, [sp, #0xe48]
    1118:      	add	x16, sp, #0x330
    111c:      	ldr	x0, [x16, #0x60]
    1120:      	str	x0, [sp, #0xe50]
    1124:      	add	x16, sp, #0x330
    1128:      	ldr	x0, [x16, #0x68]
    112c:      	str	x0, [sp, #0xe58]
    1130:      	add	x16, sp, #0x330
    1134:      	ldr	x0, [x16, #0x70]
    1138:      	str	x0, [sp, #0xe60]
    113c:      	add	x16, sp, #0x4f0
    1140:      	ldr	x0, [x16]
    1144:      	str	x0, [sp, #0xe68]
    1148:      	add	x16, sp, #0x4f0
    114c:      	ldr	x0, [x16, #0x8]
    1150:      	str	x0, [sp, #0xe70]
    1154:      	add	x16, sp, #0x4f0
    1158:      	ldr	x0, [x16, #0x10]
    115c:      	str	x0, [sp, #0xe78]
    1160:      	add	x16, sp, #0x4f0
    1164:      	ldr	x0, [x16, #0x18]
    1168:      	str	x0, [sp, #0xe80]
    116c:      	add	x16, sp, #0x4f0
    1170:      	ldr	x0, [x16, #0x20]
    1174:      	str	x0, [sp, #0xe88]
    1178:      	add	x16, sp, #0x710
    117c:      	ldr	x0, [x16]
    1180:      	str	x0, [sp, #0xe90]
    1184:      	add	x16, sp, #0x710
    1188:      	ldr	x0, [x16, #0x8]
    118c:      	str	x0, [sp, #0xe98]
    1190:      	add	x16, sp, #0x710
    1194:      	ldr	x0, [x16, #0x10]
    1198:      	str	x0, [sp, #0xea0]
    119c:      	add	x16, sp, #0x710
    11a0:      	ldr	x0, [x16, #0x18]
    11a4:      	str	x0, [sp, #0xea8]
    11a8:      	add	x16, sp, #0x710
    11ac:      	ldr	x0, [x16, #0x20]
    11b0:      	str	x0, [sp, #0xeb0]
    11b4:      	add	x16, sp, #0x710
    11b8:      	ldr	x0, [x16, #0x28]
    11bc:      	str	x0, [sp, #0xeb8]
    11c0:      	add	x16, sp, #0x710
    11c4:      	ldr	x0, [x16, #0x30]
    11c8:      	str	x0, [sp, #0xec0]
    11cc:      	add	x16, sp, #0x710
    11d0:      	ldr	x0, [x16, #0x38]
    11d4:      	str	x0, [sp, #0xec8]
    11d8:      	add	x16, sp, #0x710
    11dc:      	ldr	x0, [x16, #0x40]
    11e0:      	str	x0, [sp, #0xed0]
    11e4:      	add	x16, sp, #0x710
    11e8:      	ldr	x0, [x16, #0x48]
    11ec:      	str	x1, [sp, #0xf20]
    11f0:      	str	x2, [sp, #0xf18]
    11f4:      	str	x3, [sp, #0xef0]
    11f8:      	str	x4, [sp, #0xef8]
    11fc:      	str	x5, [sp, #0xf00]
    1200:      	str	x6, [sp, #0xf08]
    1204:      	str	x0, [sp, #0xf58]
    1208:      	add	x0, sp, #0xbb0
    120c:      	str	x19, [sp, #0xed8]
    1210:      	mov	x19, x10
    1214:      	str	x26, [sp, #0xee0]
    1218:      	mov	x26, x9
    121c:      	str	x20, [sp, #0xee8]
    1220:      	mov	x20, x8
    1224:      	str	x24, [sp, #0xf10]
    1228:      	mov	x24, x7
    122c:      	str	x28, [sp, #0xf28]
    1230:      	mov	x28, x11
    1234:      	str	x23, [sp, #0xf30]
    1238:      	mov	x23, x12
    123c:      	str	x27, [sp, #0xf38]
    1240:      	mov	x27, x13
    1244:      	str	x25, [sp, #0xf40]
    1248:      	mov	x25, x14
    124c:      	str	x22, [sp, #0xf48]
    1250:      	mov	x22, x15
    1254:      	str	x21, [sp, #0xf50]
    1258:      	ldr	x21, [sp, #0xe38]
    125c:      	movz	x1, #0x0, lsl #48
    1260:      	mov	x2, #0x140              ; =320
    1264:      	bl	0x1264 <_stogir.pipeline.prepare-checked+0x9a4>
		0000000000001264:  ARM64_RELOC_BRANCH26	_memset
    1268:      	add	x16, sp, #0xbb0
    126c:      	str	x24, [x16]
    1270:      	add	x16, sp, #0xbb0
    1274:      	str	x20, [x16, #0x8]
    1278:      	add	x16, sp, #0xbb0
    127c:      	str	x26, [x16, #0x10]
    1280:      	add	x16, sp, #0xbb0
    1284:      	str	x19, [x16, #0x18]
    1288:      	add	x16, sp, #0xbb0
    128c:      	str	x28, [x16, #0x20]
    1290:      	add	x16, sp, #0xbb0
    1294:      	str	x23, [x16, #0x28]
    1298:      	add	x16, sp, #0xbb0
    129c:      	str	x27, [x16, #0x30]
    12a0:      	add	x16, sp, #0xbb0
    12a4:      	str	x25, [x16, #0x38]
    12a8:      	add	x16, sp, #0xbb0
    12ac:      	str	x22, [x16, #0x40]
    12b0:      	add	x16, sp, #0xbb0
    12b4:      	str	x21, [x16, #0x48]
    12b8:      	ldr	x0, [sp, #0xe40]
    12bc:      	add	x16, sp, #0xbb0
    12c0:      	str	x0, [x16, #0x50]
    12c4:      	ldr	x0, [sp, #0xe48]
    12c8:      	add	x16, sp, #0xbb0
    12cc:      	str	x0, [x16, #0x58]
    12d0:      	ldr	x0, [sp, #0xe50]
    12d4:      	add	x16, sp, #0xbb0
    12d8:      	str	x0, [x16, #0x60]
    12dc:      	ldr	x0, [sp, #0xe58]
    12e0:      	add	x16, sp, #0xbb0
    12e4:      	str	x0, [x16, #0x68]
    12e8:      	ldr	x0, [sp, #0xe60]
    12ec:      	add	x16, sp, #0xbb0
    12f0:      	str	x0, [x16, #0x70]
    12f4:      	ldr	x0, [sp, #0xe68]
    12f8:      	add	x16, sp, #0xbb0
    12fc:      	str	x0, [x16, #0x78]
    1300:      	ldr	x0, [sp, #0xf50]
    1304:      	ldr	x1, [sp, #0xe70]
    1308:      	str	x1, [x0, #0x8]
    130c:      	ldr	x1, [sp, #0xe78]
    1310:      	str	x1, [x0, #0x10]
    1314:      	ldr	x1, [sp, #0xe80]
    1318:      	str	x1, [x0, #0x18]
    131c:      	ldr	x1, [sp, #0xe88]
    1320:      	str	x1, [x0, #0x20]
    1324:      	ldr	x0, [sp, #0xe90]
    1328:      	add	x16, sp, #0xbb0
    132c:      	str	x0, [x16, #0xa0]
    1330:      	ldr	x0, [sp, #0xf48]
    1334:      	ldr	x1, [sp, #0xe98]
    1338:      	str	x1, [x0, #0x8]
    133c:      	ldr	x1, [sp, #0xea0]
    1340:      	str	x1, [x0, #0x10]
    1344:      	ldr	x1, [sp, #0xea8]
    1348:      	str	x1, [x0, #0x18]
    134c:      	ldr	x1, [sp, #0xeb0]
    1350:      	str	x1, [x0, #0x20]
    1354:      	ldr	x1, [sp, #0xeb8]
    1358:      	str	x1, [x0, #0x28]
    135c:      	ldr	x1, [sp, #0xec0]
    1360:      	str	x1, [x0, #0x30]
    1364:      	ldr	x1, [sp, #0xec8]
    1368:      	str	x1, [x0, #0x38]
    136c:      	ldr	x1, [sp, #0xed0]
    1370:      	str	x1, [x0, #0x40]
    1374:      	ldr	x1, [sp, #0xf58]
    1378:      	str	x1, [x0, #0x48]
    137c:      	ldr	x0, [sp, #0xf40]
    1380:      	add	x16, sp, #0xbb0
    1384:      	str	x0, [x16, #0xf0]
    1388:      	ldr	x0, [sp, #0xf30]
    138c:      	ldr	x1, [sp, #0xf38]
    1390:      	str	x1, [x0, #0x8]
    1394:      	ldr	x1, [sp, #0xf28]
    1398:      	str	x1, [x0, #0x10]
    139c:      	ldr	x1, [sp, #0xe30]
    13a0:      	str	x1, [x0, #0x18]
    13a4:      	ldr	x1, [sp, #0xf20]
    13a8:      	str	x1, [x0, #0x20]
    13ac:      	ldr	x0, [sp, #0xf18]
    13b0:      	add	x16, sp, #0xbb0
    13b4:      	str	x0, [x16, #0x118]
    13b8:      	ldr	x0, [sp, #0xef0]
    13bc:      	ldr	x1, [sp, #0xf10]
    13c0:      	str	x0, [x1, #0x8]
    13c4:      	ldr	x0, [sp, #0xef8]
    13c8:      	str	x0, [x1, #0x10]
    13cc:      	ldr	x0, [sp, #0xf00]
    13d0:      	str	x0, [x1, #0x18]
    13d4:      	ldr	x0, [sp, #0xf08]
    13d8:      	str	x0, [x1, #0x20]
    13dc:      	add	x0, sp, #0xcf0
    13e0:      	add	x1, sp, #0xbb0
    13e4:      	mov	x2, #0x140              ; =320
    13e8:      	bl	0x13e8 <_stogir.pipeline.prepare-checked+0xb28>
		00000000000013e8:  ARM64_RELOC_BRANCH26	_memmove
    13ec:      	ldr	x0, [sp, #0xee0]
    13f0:      	add	x1, sp, #0xcf0
    13f4:      	mov	x2, #0x140              ; =320
    13f8:      	bl	0x13f8 <_stogir.pipeline.prepare-checked+0xb38>
		00000000000013f8:  ARM64_RELOC_BRANCH26	_memmove
    13fc:      	ldr	x19, [sp, #0xee8]
    1400:      	b	0xa2c <_stogir.pipeline.prepare-checked+0x16c>
    1404:      	add	x0, x26, #0x8
    1408:      	add	x16, sp, #0x760
    140c:      	ldr	x1, [x16, #0x8]
    1410:      	ldr	x2, [x0, #0x8]
    1414:      	ldr	x3, [x0, #0x10]
    1418:      	ldr	x4, [x0, #0x18]
    141c:      	ldr	x0, [x0, #0x20]
    1420:      	add	x16, sp, #0x790
    1424:      	str	x1, [x16]
    1428:      	add	x16, sp, #0x790
    142c:      	str	x2, [x16, #0x8]
    1430:      	add	x16, sp, #0x790
    1434:      	str	x3, [x16, #0x10]
    1438:      	add	x16, sp, #0x790
    143c:      	str	x4, [x16, #0x18]
    1440:      	add	x16, sp, #0x790
    1444:      	str	x0, [x16, #0x20]
    1448:      	add	x8, sp, #0x7c0
    144c:      	mov	x0, x20
    1450:      	add	x1, sp, #0x790
    1454:      	add	x2, sp, #0x550
    1458:      	mov	w3, w21
    145c:      	add	x4, sp, #0x670
    1460:      	mov	x5, x24
    1464:      	bl	0x1464 <_stogir.pipeline.prepare-checked+0xba4>
		0000000000001464:  ARM64_RELOC_BRANCH26	_stogir.placement.early-with-uses!
    1468:      	add	x16, sp, #0x7c0
    146c:      	ldr	w0, [x16]
    1470:      	lsr	x16, x0, #0
    1474:      	cmp	x16, #0x1
    1478:      	b.eq	0x1494 <_stogir.pipeline.prepare-checked+0xbd4>
    147c:      	b.lo	0x1484 <_stogir.pipeline.prepare-checked+0xbc4>
    1480:      	b	0x1498 <_stogir.pipeline.prepare-checked+0xbd8>
    1484:      	cmp	x16, #0x0
    1488:      	b.eq	0x1490 <_stogir.pipeline.prepare-checked+0xbd0>
    148c:      	b	0x1498 <_stogir.pipeline.prepare-checked+0xbd8>
    1490:      	b	0x168c <_stogir.pipeline.prepare-checked+0xdcc>
    1494:      	b	0x149c <_stogir.pipeline.prepare-checked+0xbdc>
    1498:      	b	0x1bf0 <_stogir.pipeline.prepare-checked+0x1330>
    149c:      	add	x16, sp, #0x7c0
    14a0:      	orr	x0, x16, xzr
    14a4:      	add	x0, x0, #0x8
    14a8:      	add	x16, sp, #0x7c0
    14ac:      	ldr	x21, [x16, #0x8]
    14b0:      	ldr	x22, [x0, #0x8]
    14b4:      	b	0x1698 <_stogir.pipeline.prepare-checked+0xdd8>
    14b8:      	sub	x0, x0, #0x1
    14bc:      	add	x16, sp, #0x4f0
    14c0:      	str	x0, [x16, #0x8]
    14c4:      	add	x16, sp, #0x4f0
    14c8:      	ldr	x0, [x16, #0x8]
    14cc:      	cmp	x0, #0x0
    14d0:      	b.ne	0x14b8 <_stogir.pipeline.prepare-checked+0xbf8>
    14d4:      	add	x16, sp, #0x4f0
    14d8:      	orr	x0, x16, xzr
    14dc:      	add	x16, sp, #0x4f0
    14e0:      	ldr	x1, [x16, #0x10]
    14e4:      	cmp	x1, #0x0
    14e8:      	b.le	0x1518 <_stogir.pipeline.prepare-checked+0xc58>
    14ec:      	add	x0, x0, #0x18
    14f0:      	add	x16, sp, #0x4f0
    14f4:      	ldr	x2, [x16]
    14f8:      	fmov	d31, x1
    14fc:      	mov	x1, x2
    1500:      	fmov	x2, d31
    1504:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001504:  ARM64_RELOC_PAGE21	l_stogir.395
    1508:      	ldr	x3, [x3]
		0000000000001508:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    150c:      	mov	x4, #0x4                ; =4
    1510:      	mov	x5, #0x4                ; =4
    1514:      	bl	0x1514 <_stogir.pipeline.prepare-checked+0xc54>
		0000000000001514:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1518:      	add	x16, sp, #0x910
    151c:      	orr	x19, x16, xzr
    1520:      	add	x20, x19, #0x8
    1524:      	add	x16, sp, #0x4f0
    1528:      	movz	x17, #0x0, lsl #48
    152c:      	str	x17, [x16]
    1530:      	add	x16, sp, #0x4f0
    1534:      	movz	x17, #0x0, lsl #48
    1538:      	str	x17, [x16, #0x8]
    153c:      	add	x16, sp, #0x4f0
    1540:      	movz	x17, #0x0, lsl #48
    1544:      	str	x17, [x16, #0x10]
    1548:      	add	x0, sp, #0x710
    154c:      	bl	0x154c <_stogir.pipeline.prepare-checked+0xc8c>
		000000000000154c:  ARM64_RELOC_BRANCH26	_stogir.schedule.release!
    1550:      	add	x16, sp, #0x910
    1554:      	mov	w17, #0x1               ; =1
    1558:      	str	w17, [x16]
    155c:      	add	x16, sp, #0x910
    1560:      	str	x21, [x16, #0x8]
    1564:      	str	x22, [x20, #0x8]
    1568:      	b	0x1400 <_stogir.pipeline.prepare-checked+0xb40>
    156c:      	nop
    1570:      	sub	x0, x0, #0x1
    1574:      	add	x16, sp, #0x5b0
    1578:      	str	x0, [x16, #0x8]
    157c:      	add	x16, sp, #0x5b0
    1580:      	ldr	x0, [x16, #0x8]
    1584:      	cmp	x0, #0x0
    1588:      	b.ne	0x1570 <_stogir.pipeline.prepare-checked+0xcb0>
    158c:      	add	x16, sp, #0x5b0
    1590:      	orr	x0, x16, xzr
    1594:      	add	x16, sp, #0x5b0
    1598:      	ldr	x1, [x16, #0x10]
    159c:      	cmp	x1, #0x0
    15a0:      	b.le	0x15d0 <_stogir.pipeline.prepare-checked+0xd10>
    15a4:      	add	x0, x0, #0x18
    15a8:      	add	x16, sp, #0x5b0
    15ac:      	ldr	x2, [x16]
    15b0:      	fmov	d31, x1
    15b4:      	mov	x1, x2
    15b8:      	fmov	x2, d31
    15bc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		00000000000015bc:  ARM64_RELOC_PAGE21	l_stogir.395
    15c0:      	ldr	x3, [x3]
		00000000000015c0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    15c4:      	mov	x4, #0x4                ; =4
    15c8:      	mov	x5, #0x4                ; =4
    15cc:      	bl	0x15cc <_stogir.pipeline.prepare-checked+0xd0c>
		00000000000015cc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    15d0:      	add	x16, sp, #0x5b0
    15d4:      	movz	x17, #0x0, lsl #48
    15d8:      	str	x17, [x16]
    15dc:      	add	x16, sp, #0x5b0
    15e0:      	movz	x17, #0x0, lsl #48
    15e4:      	str	x17, [x16, #0x8]
    15e8:      	add	x16, sp, #0x5b0
    15ec:      	movz	x17, #0x0, lsl #48
    15f0:      	str	x17, [x16, #0x10]
    15f4:      	add	x0, sp, #0x330
    15f8:      	bl	0x15f8 <_stogir.pipeline.prepare-checked+0xd38>
		00000000000015f8:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    15fc:      	b	0x14c4 <_stogir.pipeline.prepare-checked+0xc04>
    1600:      	sub	x0, x0, #0x1
    1604:      	add	x16, sp, #0x550
    1608:      	str	x0, [x16, #0x8]
    160c:      	add	x16, sp, #0x550
    1610:      	ldr	x0, [x16, #0x8]
    1614:      	cmp	x0, #0x0
    1618:      	b.ne	0x1600 <_stogir.pipeline.prepare-checked+0xd40>
    161c:      	add	x16, sp, #0x550
    1620:      	orr	x0, x16, xzr
    1624:      	add	x16, sp, #0x550
    1628:      	ldr	x1, [x16, #0x10]
    162c:      	cmp	x1, #0x0
    1630:      	b.le	0x1660 <_stogir.pipeline.prepare-checked+0xda0>
    1634:      	add	x0, x0, #0x18
    1638:      	add	x16, sp, #0x550
    163c:      	ldr	x2, [x16]
    1640:      	fmov	d31, x1
    1644:      	mov	x1, x2
    1648:      	fmov	x2, d31
    164c:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		000000000000164c:  ARM64_RELOC_PAGE21	l_stogir.395
    1650:      	ldr	x3, [x3]
		0000000000001650:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1654:      	mov	x4, #0x4                ; =4
    1658:      	mov	x5, #0x4                ; =4
    165c:      	bl	0x165c <_stogir.pipeline.prepare-checked+0xd9c>
		000000000000165c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1660:      	add	x16, sp, #0x550
    1664:      	movz	x17, #0x0, lsl #48
    1668:      	str	x17, [x16]
    166c:      	add	x16, sp, #0x550
    1670:      	movz	x17, #0x0, lsl #48
    1674:      	str	x17, [x16, #0x8]
    1678:      	add	x16, sp, #0x550
    167c:      	movz	x17, #0x0, lsl #48
    1680:      	str	x17, [x16, #0x10]
    1684:      	b	0x157c <_stogir.pipeline.prepare-checked+0xcbc>
    1688:      	b	0x160c <_stogir.pipeline.prepare-checked+0xd4c>
    168c:      	adrp	x21, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		000000000000168c:  ARM64_RELOC_PAGE21	l_stogir.396
    1690:      	ldr	x21, [x21]
		0000000000001690:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    1694:      	movz	x22, #0x0, lsl #48
    1698:      	cmp	x22, #0x0
    169c:      	b.ne	0x1710 <_stogir.pipeline.prepare-checked+0xe50>
    16a0:      	add	x8, sp, #0x7e0
    16a4:      	mov	x0, x20
    16a8:      	add	x1, sp, #0x790
    16ac:      	add	x2, sp, #0x550
    16b0:      	add	x3, sp, #0x5b0
    16b4:      	add	x4, sp, #0x610
    16b8:      	add	x5, sp, #0x670
    16bc:      	mov	x6, x24
    16c0:      	bl	0x16c0 <_stogir.pipeline.prepare-checked+0xe00>
		00000000000016c0:  ARM64_RELOC_BRANCH26	_stogir.placement.late-with-uses!
    16c4:      	add	x16, sp, #0x7e0
    16c8:      	ldr	w0, [x16]
    16cc:      	lsr	x16, x0, #0
    16d0:      	cmp	x16, #0x1
    16d4:      	b.eq	0x16f0 <_stogir.pipeline.prepare-checked+0xe30>
    16d8:      	b.lo	0x16e0 <_stogir.pipeline.prepare-checked+0xe20>
    16dc:      	b	0x16f4 <_stogir.pipeline.prepare-checked+0xe34>
    16e0:      	cmp	x16, #0x0
    16e4:      	b.eq	0x16ec <_stogir.pipeline.prepare-checked+0xe2c>
    16e8:      	b	0x16f4 <_stogir.pipeline.prepare-checked+0xe34>
    16ec:      	b	0x1710 <_stogir.pipeline.prepare-checked+0xe50>
    16f0:      	b	0x16f8 <_stogir.pipeline.prepare-checked+0xe38>
    16f4:      	b	0x1bf8 <_stogir.pipeline.prepare-checked+0x1338>
    16f8:      	add	x16, sp, #0x7e0
    16fc:      	orr	x0, x16, xzr
    1700:      	add	x0, x0, #0x8
    1704:      	add	x16, sp, #0x7e0
    1708:      	ldr	x21, [x16, #0x8]
    170c:      	ldr	x22, [x0, #0x8]
    1710:      	cmp	x22, #0x0
    1714:      	b.ne	0x1778 <_stogir.pipeline.prepare-checked+0xeb8>
    1718:      	add	x8, sp, #0x800
    171c:      	mov	x0, x20
    1720:      	add	x1, sp, #0x790
    1724:      	add	x2, sp, #0x610
    1728:      	bl	0x1728 <_stogir.pipeline.prepare-checked+0xe68>
		0000000000001728:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.place!
    172c:      	add	x16, sp, #0x800
    1730:      	ldr	w0, [x16]
    1734:      	lsr	x16, x0, #0
    1738:      	cmp	x16, #0x1
    173c:      	b.eq	0x1758 <_stogir.pipeline.prepare-checked+0xe98>
    1740:      	b.lo	0x1748 <_stogir.pipeline.prepare-checked+0xe88>
    1744:      	b	0x175c <_stogir.pipeline.prepare-checked+0xe9c>
    1748:      	cmp	x16, #0x0
    174c:      	b.eq	0x1754 <_stogir.pipeline.prepare-checked+0xe94>
    1750:      	b	0x175c <_stogir.pipeline.prepare-checked+0xe9c>
    1754:      	b	0x1778 <_stogir.pipeline.prepare-checked+0xeb8>
    1758:      	b	0x1760 <_stogir.pipeline.prepare-checked+0xea0>
    175c:      	b	0x1c00 <_stogir.pipeline.prepare-checked+0x1340>
    1760:      	add	x16, sp, #0x800
    1764:      	orr	x0, x16, xzr
    1768:      	add	x0, x0, #0x8
    176c:      	add	x16, sp, #0x800
    1770:      	ldr	x21, [x16, #0x8]
    1774:      	ldr	x22, [x0, #0x8]
    1778:      	cmp	x22, #0x0
    177c:      	b.ne	0x17ec <_stogir.pipeline.prepare-checked+0xf2c>
    1780:      	add	x8, sp, #0x820
    1784:      	add	x0, sp, #0x330
    1788:      	add	x1, sp, #0x450
    178c:      	add	x2, sp, #0x550
    1790:      	add	x3, sp, #0x5b0
    1794:      	add	x4, sp, #0x4f0
    1798:      	mov	x5, x24
    179c:      	bl	0x179c <_stogir.pipeline.prepare-checked+0xedc>
		000000000000179c:  ARM64_RELOC_BRANCH26	_stogir.loops.reorder!
    17a0:      	add	x16, sp, #0x820
    17a4:      	ldr	w0, [x16]
    17a8:      	lsr	x16, x0, #0
    17ac:      	cmp	x16, #0x1
    17b0:      	b.eq	0x17cc <_stogir.pipeline.prepare-checked+0xf0c>
    17b4:      	b.lo	0x17bc <_stogir.pipeline.prepare-checked+0xefc>
    17b8:      	b	0x17d0 <_stogir.pipeline.prepare-checked+0xf10>
    17bc:      	cmp	x16, #0x0
    17c0:      	b.eq	0x17c8 <_stogir.pipeline.prepare-checked+0xf08>
    17c4:      	b	0x17d0 <_stogir.pipeline.prepare-checked+0xf10>
    17c8:      	b	0x17ec <_stogir.pipeline.prepare-checked+0xf2c>
    17cc:      	b	0x17d4 <_stogir.pipeline.prepare-checked+0xf14>
    17d0:      	b	0x1c08 <_stogir.pipeline.prepare-checked+0x1348>
    17d4:      	add	x16, sp, #0x820
    17d8:      	orr	x0, x16, xzr
    17dc:      	add	x0, x0, #0x8
    17e0:      	add	x16, sp, #0x820
    17e4:      	ldr	x21, [x16, #0x8]
    17e8:      	ldr	x22, [x0, #0x8]
    17ec:      	cmp	x22, #0x0
    17f0:      	b.ne	0x185c <_stogir.pipeline.prepare-checked+0xf9c>
    17f4:      	add	x16, sp, #0x840
    17f8:      	orr	x23, x16, xzr
    17fc:      	add	x8, sp, #0x840
    1800:      	mov	x0, x20
    1804:      	add	x1, sp, #0x790
    1808:      	add	x2, sp, #0x610
    180c:      	add	x3, sp, #0x670
    1810:      	mov	x4, x24
    1814:      	bl	0x1814 <_stogir.pipeline.prepare-checked+0xf54>
		0000000000001814:  ARM64_RELOC_BRANCH26	_stogir.schedule.order-with-uses
    1818:      	add	x16, sp, #0x840
    181c:      	ldr	w0, [x16]
    1820:      	lsr	x16, x0, #0
    1824:      	cmp	x16, #0x1
    1828:      	b.eq	0x1844 <_stogir.pipeline.prepare-checked+0xf84>
    182c:      	b.lo	0x1834 <_stogir.pipeline.prepare-checked+0xf74>
    1830:      	b	0x1848 <_stogir.pipeline.prepare-checked+0xf88>
    1834:      	cmp	x16, #0x0
    1838:      	b.eq	0x1840 <_stogir.pipeline.prepare-checked+0xf80>
    183c:      	b	0x1848 <_stogir.pipeline.prepare-checked+0xf88>
    1840:      	b	0x18f0 <_stogir.pipeline.prepare-checked+0x1030>
    1844:      	b	0x184c <_stogir.pipeline.prepare-checked+0xf8c>
    1848:      	b	0x1c10 <_stogir.pipeline.prepare-checked+0x1350>
    184c:      	add	x0, x23, #0x8
    1850:      	add	x16, sp, #0x840
    1854:      	ldr	x21, [x16, #0x8]
    1858:      	ldr	x22, [x0, #0x8]
    185c:      	b	0x186c <_stogir.pipeline.prepare-checked+0xfac>
    1860:      	sub	x0, x0, #0x1
    1864:      	add	x16, sp, #0x790
    1868:      	str	x0, [x16, #0x8]
    186c:      	add	x16, sp, #0x790
    1870:      	ldr	x0, [x16, #0x8]
    1874:      	cmp	x0, #0x0
    1878:      	b.ne	0x1860 <_stogir.pipeline.prepare-checked+0xfa0>
    187c:      	add	x16, sp, #0x790
    1880:      	orr	x0, x16, xzr
    1884:      	add	x16, sp, #0x790
    1888:      	ldr	x1, [x16, #0x10]
    188c:      	cmp	x1, #0x0
    1890:      	b.le	0x18c0 <_stogir.pipeline.prepare-checked+0x1000>
    1894:      	add	x0, x0, #0x18
    1898:      	add	x16, sp, #0x790
    189c:      	ldr	x2, [x16]
    18a0:      	fmov	d31, x1
    18a4:      	mov	x1, x2
    18a8:      	fmov	x2, d31
    18ac:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		00000000000018ac:  ARM64_RELOC_PAGE21	l_stogir.395
    18b0:      	ldr	x3, [x3]
		00000000000018b0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    18b4:      	mov	x4, #0x4                ; =4
    18b8:      	mov	x5, #0x4                ; =4
    18bc:      	bl	0x18bc <_stogir.pipeline.prepare-checked+0xffc>
		00000000000018bc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    18c0:      	add	x16, sp, #0x790
    18c4:      	movz	x17, #0x0, lsl #48
    18c8:      	str	x17, [x16]
    18cc:      	add	x16, sp, #0x790
    18d0:      	movz	x17, #0x0, lsl #48
    18d4:      	str	x17, [x16, #0x8]
    18d8:      	add	x16, sp, #0x790
    18dc:      	movz	x17, #0x0, lsl #48
    18e0:      	str	x17, [x16, #0x10]
    18e4:      	b	0xf7c <_stogir.pipeline.prepare-checked+0x6bc>
    18e8:      	brk	#0
    18ec:      	b	0x18e8 <_stogir.pipeline.prepare-checked+0x1028>
    18f0:      	add	x0, x23, #0x8
    18f4:      	add	x16, sp, #0x840
    18f8:      	ldr	x1, [x16, #0x8]
    18fc:      	ldr	x2, [x0, #0x8]
    1900:      	ldr	x3, [x0, #0x10]
    1904:      	ldr	x4, [x0, #0x18]
    1908:      	ldr	x0, [x0, #0x20]
    190c:      	add	x16, sp, #0x870
    1910:      	str	x1, [x16]
    1914:      	add	x16, sp, #0x870
    1918:      	str	x2, [x16, #0x8]
    191c:      	add	x16, sp, #0x870
    1920:      	str	x3, [x16, #0x10]
    1924:      	add	x16, sp, #0x870
    1928:      	str	x4, [x16, #0x18]
    192c:      	add	x16, sp, #0x870
    1930:      	str	x0, [x16, #0x20]
    1934:      	b	0x1944 <_stogir.pipeline.prepare-checked+0x1084>
    1938:      	sub	x0, x0, #0x1
    193c:      	add	x16, sp, #0x710
    1940:      	str	x0, [x16, #0x8]
    1944:      	add	x16, sp, #0x710
    1948:      	ldr	x0, [x16, #0x8]
    194c:      	cmp	x0, #0x0
    1950:      	b.ne	0x1938 <_stogir.pipeline.prepare-checked+0x1078>
    1954:      	add	x16, sp, #0x710
    1958:      	orr	x0, x16, xzr
    195c:      	add	x16, sp, #0x710
    1960:      	ldr	x1, [x16, #0x10]
    1964:      	cmp	x1, #0x0
    1968:      	b.le	0x1998 <_stogir.pipeline.prepare-checked+0x10d8>
    196c:      	add	x0, x0, #0x18
    1970:      	add	x16, sp, #0x710
    1974:      	ldr	x2, [x16]
    1978:      	fmov	d31, x1
    197c:      	mov	x1, x2
    1980:      	fmov	x2, d31
    1984:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001984:  ARM64_RELOC_PAGE21	l_stogir.397
    1988:      	ldr	x3, [x3]
		0000000000001988:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    198c:      	mov	x4, #0x10               ; =16
    1990:      	mov	x5, #0x8                ; =8
    1994:      	bl	0x1994 <_stogir.pipeline.prepare-checked+0x10d4>
		0000000000001994:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1998:      	add	x16, sp, #0x710
    199c:      	orr	x0, x16, xzr
    19a0:      	add	x23, x0, #0x28
    19a4:      	add	x16, sp, #0x710
    19a8:      	movz	x17, #0x0, lsl #48
    19ac:      	str	x17, [x16]
    19b0:      	add	x16, sp, #0x710
    19b4:      	movz	x17, #0x0, lsl #48
    19b8:      	str	x17, [x16, #0x8]
    19bc:      	add	x16, sp, #0x710
    19c0:      	movz	x17, #0x0, lsl #48
    19c4:      	str	x17, [x16, #0x10]
    19c8:      	b	0x19d8 <_stogir.pipeline.prepare-checked+0x1118>
    19cc:      	nop
    19d0:      	sub	x0, x0, #0x1
    19d4:      	str	x0, [x23, #0x8]
    19d8:      	ldr	x0, [x23, #0x8]
    19dc:      	cmp	x0, #0x0
    19e0:      	b.ne	0x19d0 <_stogir.pipeline.prepare-checked+0x1110>
    19e4:      	ldr	x0, [x23, #0x10]
    19e8:      	cmp	x0, #0x0
    19ec:      	b.le	0x1a20 <_stogir.pipeline.prepare-checked+0x1160>
    19f0:      	add	x1, x23, #0x18
    19f4:      	add	x16, sp, #0x710
    19f8:      	ldr	x2, [x16, #0x28]
    19fc:      	fmov	d31, x0
    1a00:      	mov	x0, x1
    1a04:      	mov	x1, x2
    1a08:      	fmov	x2, d31
    1a0c:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001a0c:  ARM64_RELOC_PAGE21	l_stogir.395
    1a10:      	ldr	x3, [x3]
		0000000000001a10:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1a14:      	mov	x4, #0x4                ; =4
    1a18:      	mov	x5, #0x4                ; =4
    1a1c:      	bl	0x1a1c <_stogir.pipeline.prepare-checked+0x115c>
		0000000000001a1c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1a20:      	add	x16, sp, #0x710
    1a24:      	movz	x17, #0x0, lsl #48
    1a28:      	str	x17, [x16, #0x28]
    1a2c:      	movz	x17, #0x0, lsl #48
    1a30:      	str	x17, [x23, #0x8]
    1a34:      	movz	x17, #0x0, lsl #48
    1a38:      	str	x17, [x23, #0x10]
    1a3c:      	add	x8, sp, #0x8a0
    1a40:      	add	x0, sp, #0x870
    1a44:      	add	x1, sp, #0x790
    1a48:      	add	x2, sp, #0x4f0
    1a4c:      	mov	x3, x24
    1a50:      	bl	0x1a50 <_stogir.pipeline.prepare-checked+0x1190>
		0000000000001a50:  ARM64_RELOC_BRANCH26	_stogir.schedule.pack
    1a54:      	add	x16, sp, #0x8a0
    1a58:      	ldr	x0, [x16]
    1a5c:      	add	x16, sp, #0x710
    1a60:      	str	x0, [x16]
    1a64:      	add	x16, sp, #0x8a0
    1a68:      	ldr	x0, [x16, #0x8]
    1a6c:      	add	x16, sp, #0x710
    1a70:      	str	x0, [x16, #0x8]
    1a74:      	add	x16, sp, #0x8a0
    1a78:      	ldr	x0, [x16, #0x10]
    1a7c:      	add	x16, sp, #0x710
    1a80:      	str	x0, [x16, #0x10]
    1a84:      	add	x16, sp, #0x8a0
    1a88:      	ldr	x0, [x16, #0x18]
    1a8c:      	add	x16, sp, #0x710
    1a90:      	str	x0, [x16, #0x18]
    1a94:      	add	x16, sp, #0x8a0
    1a98:      	ldr	x0, [x16, #0x20]
    1a9c:      	add	x16, sp, #0x710
    1aa0:      	str	x0, [x16, #0x20]
    1aa4:      	add	x16, sp, #0x8a0
    1aa8:      	ldr	x0, [x16, #0x28]
    1aac:      	add	x16, sp, #0x710
    1ab0:      	str	x0, [x16, #0x28]
    1ab4:      	add	x16, sp, #0x8a0
    1ab8:      	ldr	x0, [x16, #0x30]
    1abc:      	add	x16, sp, #0x710
    1ac0:      	str	x0, [x16, #0x30]
    1ac4:      	add	x16, sp, #0x8a0
    1ac8:      	ldr	x0, [x16, #0x38]
    1acc:      	add	x16, sp, #0x710
    1ad0:      	str	x0, [x16, #0x38]
    1ad4:      	add	x16, sp, #0x8a0
    1ad8:      	ldr	x0, [x16, #0x40]
    1adc:      	add	x16, sp, #0x710
    1ae0:      	str	x0, [x16, #0x40]
    1ae4:      	add	x16, sp, #0x8a0
    1ae8:      	ldr	x0, [x16, #0x48]
    1aec:      	add	x16, sp, #0x710
    1af0:      	str	x0, [x16, #0x48]
    1af4:      	add	x8, sp, #0x8f0
    1af8:      	mov	x0, x20
    1afc:      	add	x1, sp, #0x790
    1b00:      	add	x2, sp, #0x710
    1b04:      	mov	x3, x24
    1b08:      	bl	0x1b08 <_stogir.pipeline.prepare-checked+0x1248>
		0000000000001b08:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.cluster!
    1b0c:      	add	x16, sp, #0x8f0
    1b10:      	ldr	w0, [x16]
    1b14:      	lsr	x16, x0, #0
    1b18:      	cmp	x16, #0x1
    1b1c:      	b.eq	0x1b38 <_stogir.pipeline.prepare-checked+0x1278>
    1b20:      	b.lo	0x1b28 <_stogir.pipeline.prepare-checked+0x1268>
    1b24:      	b	0x1b3c <_stogir.pipeline.prepare-checked+0x127c>
    1b28:      	cmp	x16, #0x0
    1b2c:      	b.eq	0x1b34 <_stogir.pipeline.prepare-checked+0x1274>
    1b30:      	b	0x1b3c <_stogir.pipeline.prepare-checked+0x127c>
    1b34:      	b	0x1b58 <_stogir.pipeline.prepare-checked+0x1298>
    1b38:      	b	0x1b40 <_stogir.pipeline.prepare-checked+0x1280>
    1b3c:      	b	0x1c18 <_stogir.pipeline.prepare-checked+0x1358>
    1b40:      	add	x16, sp, #0x8f0
    1b44:      	orr	x0, x16, xzr
    1b48:      	add	x0, x0, #0x8
    1b4c:      	add	x16, sp, #0x8f0
    1b50:      	ldr	x21, [x16, #0x8]
    1b54:      	ldr	x22, [x0, #0x8]
    1b58:      	b	0x1b6c <_stogir.pipeline.prepare-checked+0x12ac>
    1b5c:      	nop
    1b60:      	sub	x0, x0, #0x1
    1b64:      	add	x16, sp, #0x870
    1b68:      	str	x0, [x16, #0x8]
    1b6c:      	add	x16, sp, #0x870
    1b70:      	ldr	x0, [x16, #0x8]
    1b74:      	cmp	x0, #0x0
    1b78:      	b.ne	0x1b60 <_stogir.pipeline.prepare-checked+0x12a0>
    1b7c:      	add	x16, sp, #0x870
    1b80:      	orr	x0, x16, xzr
    1b84:      	add	x16, sp, #0x870
    1b88:      	ldr	x1, [x16, #0x10]
    1b8c:      	cmp	x1, #0x0
    1b90:      	b.le	0x1bc0 <_stogir.pipeline.prepare-checked+0x1300>
    1b94:      	add	x0, x0, #0x18
    1b98:      	add	x16, sp, #0x870
    1b9c:      	ldr	x2, [x16]
    1ba0:      	fmov	d31, x1
    1ba4:      	mov	x1, x2
    1ba8:      	fmov	x2, d31
    1bac:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001bac:  ARM64_RELOC_PAGE21	l_stogir.395
    1bb0:      	ldr	x3, [x3]
		0000000000001bb0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1bb4:      	mov	x4, #0x4                ; =4
    1bb8:      	mov	x5, #0x4                ; =4
    1bbc:      	bl	0x1bbc <_stogir.pipeline.prepare-checked+0x12fc>
		0000000000001bbc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1bc0:      	add	x16, sp, #0x870
    1bc4:      	movz	x17, #0x0, lsl #48
    1bc8:      	str	x17, [x16]
    1bcc:      	add	x16, sp, #0x870
    1bd0:      	movz	x17, #0x0, lsl #48
    1bd4:      	str	x17, [x16, #0x8]
    1bd8:      	add	x16, sp, #0x870
    1bdc:      	movz	x17, #0x0, lsl #48
    1be0:      	str	x17, [x16, #0x10]
    1be4:      	b	0x185c <_stogir.pipeline.prepare-checked+0xf9c>
    1be8:      	brk	#0
    1bec:      	b	0x1be8 <_stogir.pipeline.prepare-checked+0x1328>
    1bf0:      	brk	#0
    1bf4:      	b	0x1bf0 <_stogir.pipeline.prepare-checked+0x1330>
    1bf8:      	brk	#0
    1bfc:      	b	0x1bf8 <_stogir.pipeline.prepare-checked+0x1338>
    1c00:      	brk	#0
    1c04:      	b	0x1c00 <_stogir.pipeline.prepare-checked+0x1340>
    1c08:      	brk	#0
    1c0c:      	b	0x1c08 <_stogir.pipeline.prepare-checked+0x1348>
    1c10:      	brk	#0
    1c14:      	b	0x1c10 <_stogir.pipeline.prepare-checked+0x1350>
    1c18:      	brk	#0
    1c1c:      	b	0x1c18 <_stogir.pipeline.prepare-checked+0x1358>
    1c20:      	str	x19, [sp, #0xed8]
    1c24:      	b	0x908 <_stogir.pipeline.prepare-checked+0x48>
    1c28:      	str	x19, [sp, #0xed8]
    1c2c:      	b	0x1688 <_stogir.pipeline.prepare-checked+0xdc8>

0000000000001c30 <_stogir.cfg.release!>:
    1c30:      	sub	sp, sp, #0x30
    1c34:      	str	x29, [sp]
    1c38:      	str	x30, [sp, #0x8]
    1c3c:      	mov	x29, sp
    1c40:      	str	x19, [sp, #0x10]
    1c44:      	str	x20, [sp, #0x18]
    1c48:      	str	x21, [sp, #0x20]
    1c4c:      	b	0x1c58 <_stogir.cfg.release!+0x28>
    1c50:      	sub	x1, x1, #0x1
    1c54:      	str	x1, [x0, #0x8]
    1c58:      	ldr	x1, [x0, #0x8]
    1c5c:      	cmp	x1, #0x0
    1c60:      	b.ne	0x1c50 <_stogir.cfg.release!+0x20>
    1c64:      	ldr	x1, [x0, #0x10]
    1c68:      	cmp	x1, #0x0
    1c6c:      	b.le	0x1db0 <_stogir.cfg.release!+0x180>
    1c70:      	add	x2, x0, #0x18
    1c74:      	ldr	x3, [x0]
    1c78:      	mov	x19, x0
    1c7c:      	mov	x0, x2
    1c80:      	mov	x2, x1
    1c84:      	mov	x1, x3
    1c88:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001c88:  ARM64_RELOC_PAGE21	l_stogir.398
    1c8c:      	ldr	x3, [x3]
		0000000000001c8c:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    1c90:      	mov	x4, #0x4                ; =4
    1c94:      	mov	x5, #0x4                ; =4
    1c98:      	bl	0x1c98 <_stogir.cfg.release!+0x68>
		0000000000001c98:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1c9c:      	add	x20, x19, #0x28
    1ca0:      	movz	x17, #0x0, lsl #48
    1ca4:      	str	x17, [x19]
    1ca8:      	movz	x17, #0x0, lsl #48
    1cac:      	str	x17, [x19, #0x8]
    1cb0:      	movz	x17, #0x0, lsl #48
    1cb4:      	str	x17, [x19, #0x10]
    1cb8:      	b	0x1cc8 <_stogir.cfg.release!+0x98>
    1cbc:      	nop
    1cc0:      	sub	x0, x0, #0x1
    1cc4:      	str	x0, [x20, #0x8]
    1cc8:      	ldr	x0, [x20, #0x8]
    1ccc:      	cmp	x0, #0x0
    1cd0:      	b.ne	0x1cc0 <_stogir.cfg.release!+0x90>
    1cd4:      	ldr	x0, [x20, #0x10]
    1cd8:      	cmp	x0, #0x0
    1cdc:      	b.le	0x1d0c <_stogir.cfg.release!+0xdc>
    1ce0:      	add	x1, x20, #0x18
    1ce4:      	ldr	x2, [x19, #0x28]
    1ce8:      	fmov	d31, x0
    1cec:      	mov	x0, x1
    1cf0:      	mov	x1, x2
    1cf4:      	fmov	x2, d31
    1cf8:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001cf8:  ARM64_RELOC_PAGE21	l_stogir.398
    1cfc:      	ldr	x3, [x3]
		0000000000001cfc:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    1d00:      	mov	x4, #0x4                ; =4
    1d04:      	mov	x5, #0x4                ; =4
    1d08:      	bl	0x1d08 <_stogir.cfg.release!+0xd8>
		0000000000001d08:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1d0c:      	add	x21, x19, #0x50
    1d10:      	movz	x17, #0x0, lsl #48
    1d14:      	str	x17, [x19, #0x28]
    1d18:      	movz	x17, #0x0, lsl #48
    1d1c:      	str	x17, [x20, #0x8]
    1d20:      	movz	x17, #0x0, lsl #48
    1d24:      	str	x17, [x20, #0x10]
    1d28:      	b	0x1d38 <_stogir.cfg.release!+0x108>
    1d2c:      	nop
    1d30:      	sub	x0, x0, #0x1
    1d34:      	str	x0, [x21, #0x8]
    1d38:      	ldr	x0, [x21, #0x8]
    1d3c:      	cmp	x0, #0x0
    1d40:      	b.ne	0x1d30 <_stogir.cfg.release!+0x100>
    1d44:      	ldr	x0, [x21, #0x10]
    1d48:      	cmp	x0, #0x0
    1d4c:      	b.le	0x1d7c <_stogir.cfg.release!+0x14c>
    1d50:      	add	x1, x21, #0x18
    1d54:      	ldr	x2, [x19, #0x50]
    1d58:      	fmov	d31, x0
    1d5c:      	mov	x0, x1
    1d60:      	mov	x1, x2
    1d64:      	fmov	x2, d31
    1d68:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001d68:  ARM64_RELOC_PAGE21	l_stogir.399
    1d6c:      	ldr	x3, [x3]
		0000000000001d6c:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    1d70:      	mov	x4, #0x10               ; =16
    1d74:      	mov	x5, #0x4                ; =4
    1d78:      	bl	0x1d78 <_stogir.cfg.release!+0x148>
		0000000000001d78:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1d7c:      	movz	x17, #0x0, lsl #48
    1d80:      	str	x17, [x19, #0x50]
    1d84:      	movz	x17, #0x0, lsl #48
    1d88:      	str	x17, [x21, #0x8]
    1d8c:      	movz	x17, #0x0, lsl #48
    1d90:      	str	x17, [x21, #0x10]
    1d94:      	ldr	x19, [sp, #0x10]
    1d98:      	ldr	x20, [sp, #0x18]
    1d9c:      	ldr	x21, [sp, #0x20]
    1da0:      	ldr	x29, [sp]
    1da4:      	ldr	x30, [sp, #0x8]
    1da8:      	add	sp, sp, #0x30
    1dac:      	ret
    1db0:      	mov	x19, x0
    1db4:      	b	0x1c9c <_stogir.cfg.release!+0x6c>

0000000000001db8 <_inherent$coil.arraylist.ArrayList$free!__i32>:
    1db8:      	sub	sp, sp, #0x20
    1dbc:      	str	x29, [sp]
    1dc0:      	str	x30, [sp, #0x8]
    1dc4:      	mov	x29, sp
    1dc8:      	str	x19, [sp, #0x10]
    1dcc:      	b	0x1dd8 <_inherent$coil.arraylist.ArrayList$free!__i32+0x20>
    1dd0:      	sub	x1, x1, #0x1
    1dd4:      	str	x1, [x0, #0x8]
    1dd8:      	ldr	x1, [x0, #0x8]
    1ddc:      	cmp	x1, #0x0
    1de0:      	b.ne	0x1dd0 <_inherent$coil.arraylist.ArrayList$free!__i32+0x18>
    1de4:      	ldr	x1, [x0, #0x10]
    1de8:      	cmp	x1, #0x0
    1dec:      	b.le	0x1e4c <_inherent$coil.arraylist.ArrayList$free!__i32+0x94>
    1df0:      	add	x2, x0, #0x18
    1df4:      	ldr	x3, [x0]
    1df8:      	mov	x19, x0
    1dfc:      	mov	x0, x2
    1e00:      	mov	x2, x1
    1e04:      	mov	x1, x3
    1e08:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001e08:  ARM64_RELOC_PAGE21	l_stogir.400
    1e0c:      	ldr	x3, [x3]
		0000000000001e0c:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    1e10:      	mov	x4, #0x4                ; =4
    1e14:      	mov	x5, #0x4                ; =4
    1e18:      	bl	0x1e18 <_inherent$coil.arraylist.ArrayList$free!__i32+0x60>
		0000000000001e18:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1e1c:      	movz	x17, #0x0, lsl #48
    1e20:      	str	x17, [x19]
    1e24:      	movz	x17, #0x0, lsl #48
    1e28:      	str	x17, [x19, #0x8]
    1e2c:      	movz	x17, #0x0, lsl #48
    1e30:      	str	x17, [x19, #0x10]
    1e34:      	movz	x0, #0x0, lsl #48
    1e38:      	ldr	x19, [sp, #0x10]
    1e3c:      	ldr	x29, [sp]
    1e40:      	ldr	x30, [sp, #0x8]
    1e44:      	add	sp, sp, #0x20
    1e48:      	ret
    1e4c:      	mov	x19, x0
    1e50:      	b	0x1e1c <_inherent$coil.arraylist.ArrayList$free!__i32+0x64>
    1e54:      	udf	#0x0

0000000000001e58 <_stogir.schedule.release!>:
    1e58:      	sub	sp, sp, #0x20
    1e5c:      	str	x29, [sp]
    1e60:      	str	x30, [sp, #0x8]
    1e64:      	mov	x29, sp
    1e68:      	str	x19, [sp, #0x10]
    1e6c:      	str	x20, [sp, #0x18]
    1e70:      	b	0x1e80 <_stogir.schedule.release!+0x28>
    1e74:      	nop
    1e78:      	sub	x1, x1, #0x1
    1e7c:      	str	x1, [x0, #0x8]
    1e80:      	ldr	x1, [x0, #0x8]
    1e84:      	cmp	x1, #0x0
    1e88:      	b.ne	0x1e78 <_stogir.schedule.release!+0x20>
    1e8c:      	ldr	x1, [x0, #0x10]
    1e90:      	cmp	x1, #0x0
    1e94:      	b.le	0x1f64 <_stogir.schedule.release!+0x10c>
    1e98:      	add	x2, x0, #0x18
    1e9c:      	ldr	x3, [x0]
    1ea0:      	mov	x19, x0
    1ea4:      	mov	x0, x2
    1ea8:      	mov	x2, x1
    1eac:      	mov	x1, x3
    1eb0:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001eb0:  ARM64_RELOC_PAGE21	l_stogir.401
    1eb4:      	ldr	x3, [x3]
		0000000000001eb4:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    1eb8:      	mov	x4, #0x10               ; =16
    1ebc:      	mov	x5, #0x8                ; =8
    1ec0:      	bl	0x1ec0 <_stogir.schedule.release!+0x68>
		0000000000001ec0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1ec4:      	add	x20, x19, #0x28
    1ec8:      	movz	x17, #0x0, lsl #48
    1ecc:      	str	x17, [x19]
    1ed0:      	movz	x17, #0x0, lsl #48
    1ed4:      	str	x17, [x19, #0x8]
    1ed8:      	movz	x17, #0x0, lsl #48
    1edc:      	str	x17, [x19, #0x10]
    1ee0:      	b	0x1ef0 <_stogir.schedule.release!+0x98>
    1ee4:      	nop
    1ee8:      	sub	x0, x0, #0x1
    1eec:      	str	x0, [x20, #0x8]
    1ef0:      	ldr	x0, [x20, #0x8]
    1ef4:      	cmp	x0, #0x0
    1ef8:      	b.ne	0x1ee8 <_stogir.schedule.release!+0x90>
    1efc:      	ldr	x0, [x20, #0x10]
    1f00:      	cmp	x0, #0x0
    1f04:      	b.le	0x1f34 <_stogir.schedule.release!+0xdc>
    1f08:      	add	x1, x20, #0x18
    1f0c:      	ldr	x2, [x19, #0x28]
    1f10:      	fmov	d31, x0
    1f14:      	mov	x0, x1
    1f18:      	mov	x1, x2
    1f1c:      	fmov	x2, d31
    1f20:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x740>
		0000000000001f20:  ARM64_RELOC_PAGE21	l_stogir.402
    1f24:      	ldr	x3, [x3]
		0000000000001f24:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    1f28:      	mov	x4, #0x4                ; =4
    1f2c:      	mov	x5, #0x4                ; =4
    1f30:      	bl	0x1f30 <_stogir.schedule.release!+0xd8>
		0000000000001f30:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1f34:      	movz	x17, #0x0, lsl #48
    1f38:      	str	x17, [x19, #0x28]
    1f3c:      	movz	x17, #0x0, lsl #48
    1f40:      	str	x17, [x20, #0x8]
    1f44:      	movz	x17, #0x0, lsl #48
    1f48:      	str	x17, [x20, #0x10]
    1f4c:      	ldr	x19, [sp, #0x10]
    1f50:      	ldr	x20, [sp, #0x18]
    1f54:      	ldr	x29, [sp]
    1f58:      	ldr	x30, [sp, #0x8]
    1f5c:      	add	sp, sp, #0x20
    1f60:      	ret
    1f64:      	mov	x19, x0
    1f68:      	b	0x1ec4 <_stogir.schedule.release!+0x6c>

0000000000001f6c <_stogir.verify.schedule-input>:
    1f6c:      	sub	sp, sp, #0x80
    1f70:      	str	x29, [sp]
    1f74:      	str	x30, [sp, #0x8]
    1f78:      	mov	x29, sp
    1f7c:      	str	x19, [sp, #0x50]
    1f80:      	str	x20, [sp, #0x58]
    1f84:      	str	x21, [sp, #0x60]
    1f88:      	str	x22, [sp, #0x68]
    1f8c:      	str	x23, [sp, #0x70]
    1f90:      	mov	x19, x8
    1f94:      	add	x8, sp, #0x10
    1f98:      	mov	x20, x0
    1f9c:      	mov	w21, w1
    1fa0:      	mov	x22, x2
    1fa4:      	mov	x23, x3
    1fa8:      	bl	0x1fa8 <_stogir.verify.schedule-input+0x3c>
		0000000000001fa8:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    1fac:      	add	x16, sp, #0x10
    1fb0:      	ldr	w0, [x16]
    1fb4:      	lsr	x16, x0, #0
    1fb8:      	cmp	x16, #0x1
    1fbc:      	b.eq	0x1fd8 <_stogir.verify.schedule-input+0x6c>
    1fc0:      	b.lo	0x1fc8 <_stogir.verify.schedule-input+0x5c>
    1fc4:      	b	0x1fdc <_stogir.verify.schedule-input+0x70>
    1fc8:      	cmp	x16, #0x0
    1fcc:      	b.eq	0x1fd4 <_stogir.verify.schedule-input+0x68>
    1fd0:      	b	0x1fdc <_stogir.verify.schedule-input+0x70>
    1fd4:      	b	0x2000 <_stogir.verify.schedule-input+0x94>
    1fd8:      	b	0x1fe0 <_stogir.verify.schedule-input+0x74>
    1fdc:      	b	0x2060 <_stogir.verify.schedule-input+0xf4>
    1fe0:      	add	x16, sp, #0x10
    1fe4:      	orr	x0, x16, xzr
    1fe8:      	add	x0, x0, #0x8
    1fec:      	add	x16, sp, #0x10
    1ff0:      	ldr	x1, [x16, #0x8]
    1ff4:      	ldr	x0, [x0, #0x8]
    1ff8:      	mov	x2, #0x1                ; =1
    1ffc:      	b	0x2030 <_stogir.verify.schedule-input+0xc4>
    2000:      	add	x8, sp, #0x30
    2004:      	mov	x0, x20
    2008:      	mov	w1, w21
    200c:      	mov	x2, x22
    2010:      	mov	x3, x23
    2014:      	bl	0x2014 <_stogir.verify.schedule-input+0xa8>
		0000000000002014:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input-structured
    2018:      	add	x16, sp, #0x30
    201c:      	ldr	x2, [x16]
    2020:      	add	x16, sp, #0x30
    2024:      	ldr	x1, [x16, #0x8]
    2028:      	add	x16, sp, #0x30
    202c:      	ldr	x0, [x16, #0x10]
    2030:      	str	x2, [x19]
    2034:      	str	x1, [x19, #0x8]
    2038:      	str	x0, [x19, #0x10]
    203c:      	ldr	x19, [sp, #0x50]
    2040:      	ldr	x20, [sp, #0x58]
    2044:      	ldr	x21, [sp, #0x60]
    2048:      	ldr	x22, [sp, #0x68]
    204c:      	ldr	x23, [sp, #0x70]
    2050:      	ldr	x29, [sp]
    2054:      	ldr	x30, [sp, #0x8]
    2058:      	add	sp, sp, #0x80
    205c:      	ret
    2060:      	brk	#0
    2064:      	b	0x2060 <_stogir.verify.schedule-input+0xf4>

0000000000002068 <_stogir.graph.contains?>:
    2068:      	sxtw	x1, w1
    206c:      	cmp	x1, #0x0
    2070:      	b.le	0x20b0 <_stogir.graph.contains?+0x48>
    2074:      	ldr	x2, [x0, #0x8]
    2078:      	cmp	x1, x2
    207c:      	b.ge	0x210c <_stogir.graph.contains?+0xa4>
    2080:      	add	x2, x0, #0x78
    2084:      	ldr	x2, [x2, #0x8]
    2088:      	cmp	x1, x2
    208c:      	b.ge	0x211c <_stogir.graph.contains?+0xb4>
    2090:      	ldr	x0, [x0, #0x78]
    2094:      	add	x0, x0, x1, lsl #2
    2098:      	ldr	w0, [x0]
    209c:      	sxtw	x0, w0
    20a0:      	cmp	x0, #0x0
    20a4:      	cset	w0, ge
    20a8:      	ubfx	x0, x0, #0, #8
    20ac:      	b	0x2120 <_stogir.graph.contains?+0xb8>
    20b0:      	cmp	x1, #0x0
    20b4:      	b.ge	0x2114 <_stogir.graph.contains?+0xac>
    20b8:      	add	x2, x0, #0x28
    20bc:      	add	x3, x0, #0x50
    20c0:      	ldr	x2, [x2, #0x8]
    20c4:      	ldr	x3, [x3, #0x8]
    20c8:      	cmp	x2, x3
    20cc:      	b.ne	0x212c <_stogir.graph.contains?+0xc4>
    20d0:      	movz	x16, #0x0, lsl #48
    20d4:      	sub	x3, x16, x1
    20d8:      	cmp	x3, x2
    20dc:      	b.gt	0x2124 <_stogir.graph.contains?+0xbc>
    20e0:      	movz	x16, #0x0, lsl #48
    20e4:      	sub	x1, x16, x1
    20e8:      	sub	x1, x1, #0x1
    20ec:      	ldr	x0, [x0, #0x50]
    20f0:      	add	x0, x0, x1, lsl #2
    20f4:      	ldr	w0, [x0]
    20f8:      	sxtw	x0, w0
    20fc:      	cmp	x0, #0x0
    2100:      	cset	w0, gt
    2104:      	ubfx	x0, x0, #0, #8
    2108:      	b	0x2128 <_stogir.graph.contains?+0xc0>
    210c:      	movz	x0, #0x0, lsl #48
    2110:      	b	0x2120 <_stogir.graph.contains?+0xb8>
    2114:      	movz	x0, #0x0, lsl #48
    2118:      	b	0x2128 <_stogir.graph.contains?+0xc0>
    211c:      	movz	x0, #0x0, lsl #48
    2120:      	b	0x2128 <_stogir.graph.contains?+0xc0>
    2124:      	movz	x0, #0x0, lsl #48
    2128:      	ret
    212c:      	movz	x0, #0x0, lsl #48
    2130:      	b	0x2128 <_stogir.graph.contains?+0xc0>
    2134:      	udf	#0x0

0000000000002138 <_stogir.cfg.build>:
    2138:      	sub	sp, sp, #0x2e0
    213c:      	str	x29, [sp, #0x10]
    2140:      	str	x30, [sp, #0x18]
    2144:      	add	x29, sp, #0x10
    2148:      	str	x19, [sp, #0x288]
    214c:      	str	x20, [sp, #0x290]
    2150:      	str	x21, [sp, #0x298]
    2154:      	str	x22, [sp, #0x2a0]
    2158:      	str	x23, [sp, #0x2a8]
    215c:      	str	x24, [sp, #0x2b0]
    2160:      	str	x25, [sp, #0x2b8]
    2164:      	str	x26, [sp, #0x2c0]
    2168:      	str	x27, [sp, #0x2c8]
    216c:      	str	x28, [sp, #0x2d0]
    2170:      	mov	x19, x8
    2174:      	add	x8, sp, #0x20
    2178:      	mov	x20, x0
    217c:      	mov	x21, x1
    2180:      	bl	0x2180 <_stogir.cfg.build+0x48>
		0000000000002180:  ARM64_RELOC_BRANCH26	_stogir.verify.control-sources
    2184:      	add	x16, sp, #0x20
    2188:      	ldr	w0, [x16]
    218c:      	lsr	x16, x0, #0
    2190:      	cmp	x16, #0x1
    2194:      	b.eq	0x21b0 <_stogir.cfg.build+0x78>
    2198:      	b.lo	0x21a0 <_stogir.cfg.build+0x68>
    219c:      	b	0x21b4 <_stogir.cfg.build+0x7c>
    21a0:      	cmp	x16, #0x0
    21a4:      	b.eq	0x21ac <_stogir.cfg.build+0x74>
    21a8:      	b	0x21b4 <_stogir.cfg.build+0x7c>
    21ac:      	b	0x25e0 <_stogir.cfg.build+0x4a8>
    21b0:      	b	0x21b8 <_stogir.cfg.build+0x80>
    21b4:      	b	0x2c8c <_stogir.cfg.build+0xb54>
    21b8:      	add	x16, sp, #0x20
    21bc:      	orr	x0, x16, xzr
    21c0:      	add	x0, x0, #0x8
    21c4:      	add	x16, sp, #0x20
    21c8:      	ldr	x21, [x16, #0x8]
    21cc:      	ldr	x22, [x0, #0x8]
    21d0:      	str	x19, [sp, #0x258]
    21d4:      	mov	x13, #0x1               ; =1
    21d8:      	movz	x0, #0x0, lsl #48
    21dc:      	movz	x1, #0x0, lsl #48
    21e0:      	movz	x2, #0x0, lsl #48
    21e4:      	movz	x3, #0x0, lsl #48
    21e8:      	movz	x4, #0x0, lsl #48
    21ec:      	movz	x5, #0x0, lsl #48
    21f0:      	movz	x6, #0x0, lsl #48
    21f4:      	movz	x7, #0x0, lsl #48
    21f8:      	movz	x8, #0x0, lsl #48
    21fc:      	movz	x9, #0x0, lsl #48
    2200:      	movz	x10, #0x0, lsl #48
    2204:      	movz	x11, #0x0, lsl #48
    2208:      	movz	x12, #0x0, lsl #48
    220c:      	b	0x2564 <_stogir.cfg.build+0x42c>
    2210:      	sub	w1, w0, #0x1
    2214:      	lsl	w1, w1, #2
    2218:      	ubfx	x1, x1, #0, #32
    221c:      	lsr	x1, x2, x1
    2220:      	and	w1, w1, #0xf
    2224:      	b	0x22d0 <_stogir.cfg.build+0x198>
    2228:      	lsl	x2, x2, #1
    222c:      	str	w23, [sp, #0x278]
    2230:      	mov	x23, x0
    2234:      	mov	x0, x19
    2238:      	str	w24, [sp, #0x280]
    223c:      	mov	x24, x1
    2240:      	mov	x1, x2
    2244:      	bl	0x2244 <_stogir.cfg.build+0x10c>
		0000000000002244:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge
    2248:      	add	x0, x24, #0x1
    224c:      	add	x16, sp, #0x40
    2250:      	ldr	x1, [x16, #0x50]
    2254:      	add	x1, x1, x24, lsl #4
    2258:      	str	x20, [x1]
    225c:      	str	x23, [x1, #0x8]
    2260:      	str	x0, [x19, #0x8]
    2264:      	add	x0, x28, #0x1
    2268:      	sxtw	x28, w0
    226c:      	ldr	x20, [sp, #0x270]
    2270:      	ldr	w23, [sp, #0x278]
    2274:      	ldr	w24, [sp, #0x280]
    2278:      	cmp	x22, #0x0
    227c:      	b.ne	0x2290 <_stogir.cfg.build+0x158>
    2280:      	cmp	x28, x27
    2284:      	cset	w0, le
    2288:      	ubfx	x0, x0, #0, #8
    228c:      	b	0x2294 <_stogir.cfg.build+0x15c>
    2290:      	movz	x0, #0x0, lsl #48
    2294:      	cmp	x0, #0x0
    2298:      	b.eq	0x2c94 <_stogir.cfg.build+0xb5c>
    229c:      	orr	w0, w28, wzr
    22a0:      	uxtb	w16, w25
    22a4:      	cmp	w16, wzr
    22a8:      	b.eq	0x22d4 <_stogir.cfg.build+0x19c>
    22ac:      	sxtw	x1, w0
    22b0:      	ldr	w2, [x26]
    22b4:      	cmp	x1, #0x0
    22b8:      	b.le	0x22cc <_stogir.cfg.build+0x194>
    22bc:      	cmp	x1, #0x4
    22c0:      	b.le	0x2210 <_stogir.cfg.build+0xd8>
    22c4:      	mov	w1, #0x4                ; =4
    22c8:      	b	0x2214 <_stogir.cfg.build+0xdc>
    22cc:      	movz	w1, #0x0, lsl #16
    22d0:      	b	0x22d8 <_stogir.cfg.build+0x1a0>
    22d4:      	movz	w1, #0x0, lsl #16
    22d8:      	adrp	x16, 0x2000 <_stogir.verify.schedule-input+0x94>
		00000000000022d8:  ARM64_RELOC_PAGE21	l_stogir.403
    22dc:      	ldr	x16, [x16]
		00000000000022dc:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    22e0:      	ldr	w2, [x16]
    22e4:      	ubfx	x1, x1, #0, #32
    22e8:      	cmp	x1, x2
    22ec:      	b.ne	0x2c9c <_stogir.cfg.build+0xb64>
    22f0:      	mov	w1, w23
    22f4:      	mov	w2, w0
    22f8:      	str	x20, [sp, #0x270]
    22fc:      	fmov	s31, w0
    2300:      	mov	x0, x20
    2304:      	fmov	w20, s31
    2308:      	bl	0x2308 <_stogir.cfg.build+0x1d0>
		0000000000002308:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    230c:      	ubfx	x0, x0, #0, #32
    2310:      	lsr	x16, x0, #0
    2314:      	cmp	x16, #0x1
    2318:      	b.eq	0x2334 <_stogir.cfg.build+0x1fc>
    231c:      	b.lo	0x2324 <_stogir.cfg.build+0x1ec>
    2320:      	b	0x2338 <_stogir.cfg.build+0x200>
    2324:      	cmp	x16, #0x0
    2328:      	b.eq	0x2330 <_stogir.cfg.build+0x1f8>
    232c:      	b	0x2338 <_stogir.cfg.build+0x200>
    2330:      	b	0x233c <_stogir.cfg.build+0x204>
    2334:      	b	0x2354 <_stogir.cfg.build+0x21c>
    2338:      	b	0x2c7c <_stogir.cfg.build+0xb44>
    233c:      	str	w23, [sp, #0x278]
    2340:      	str	w24, [sp, #0x280]
    2344:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x94>
		0000000000002344:  ARM64_RELOC_PAGE21	l_stogir.404
    2348:      	ldr	x21, [x21]
		0000000000002348:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    234c:      	mov	x22, #0x19              ; =25
    2350:      	b	0x2264 <_stogir.cfg.build+0x12c>
    2354:      	add	x16, sp, #0x40
    2358:      	ldr	x0, [x16, #0x28]
    235c:      	sxtw	x2, w1
    2360:      	add	x0, x0, x2, lsl #2
    2364:      	ldr	w0, [x0]
    2368:      	sxtw	x2, w0
    236c:      	cmp	x2, #0x0
    2370:      	b.ne	0x24bc <_stogir.cfg.build+0x384>
    2374:      	str	w23, [sp, #0x278]
    2378:      	str	w24, [sp, #0x280]
    237c:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x94>
		000000000000237c:  ARM64_RELOC_PAGE21	l_stogir.405
    2380:      	ldr	x21, [x21]
		0000000000002380:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    2384:      	mov	x22, #0x1e              ; =30
    2388:      	b	0x2264 <_stogir.cfg.build+0x12c>
    238c:      	ldr	x20, [sp, #0x270]
    2390:      	add	x0, sp, #0x1d0
    2394:      	bl	0x2394 <_stogir.cfg.build+0x25c>
		0000000000002394:  ARM64_RELOC_BRANCH26	_coil.core.Iterator$coil.slice.SliceIter$next__i32
    2398:      	ubfx	x0, x0, #0, #32
    239c:      	lsr	x16, x0, #0
    23a0:      	cmp	x16, #0x1
    23a4:      	b.eq	0x23c0 <_stogir.cfg.build+0x288>
    23a8:      	b.lo	0x23b0 <_stogir.cfg.build+0x278>
    23ac:      	b	0x23c4 <_stogir.cfg.build+0x28c>
    23b0:      	cmp	x16, #0x0
    23b4:      	b.eq	0x23bc <_stogir.cfg.build+0x284>
    23b8:      	b	0x23c4 <_stogir.cfg.build+0x28c>
    23bc:      	b	0x2414 <_stogir.cfg.build+0x2dc>
    23c0:      	b	0x23c8 <_stogir.cfg.build+0x290>
    23c4:      	b	0x2c84 <_stogir.cfg.build+0xb4c>
    23c8:      	ldr	x0, [x20]
    23cc:      	sxtw	x2, w1
    23d0:      	orr	w23, w1, wzr
    23d4:      	orr	w24, w1, wzr
    23d8:      	add	x0, x0, x2, lsl #4
    23dc:      	ldr	x0, [x0]
    23e0:      	ldr	x1, [x20, #0x78]
    23e4:      	uxtb	w0, w0
    23e8:      	add	x1, x1, x2, lsl #2
    23ec:      	cmp	x0, #0x83
    23f0:      	cset	w25, lt
    23f4:      	adrp	x16, 0x2000 <_stogir.verify.schedule-input+0x94>
		00000000000023f4:  ARM64_RELOC_PAGE21	l_stogir.406
    23f8:      	ldr	x16, [x16]
		00000000000023f8:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    23fc:      	add	x0, x16, x0, lsl #2
    2400:      	ldr	w1, [x1]
    2404:      	orr	x26, x0, xzr
    2408:      	sxtw	x27, w1
    240c:      	mov	x28, #0x1               ; =1
    2410:      	b	0x2278 <_stogir.cfg.build+0x140>
    2414:      	add	x0, sp, #0x150
    2418:      	bl	0x2418 <_stogir.cfg.build+0x2e0>
		0000000000002418:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    241c:      	mov	x0, x21
    2420:      	mov	x1, x22
    2424:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x94>
		0000000000002424:  ARM64_RELOC_PAGE21	l_stogir.407
    2428:      	ldr	x2, [x2]
		0000000000002428:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    242c:      	movz	x3, #0x0, lsl #48
    2430:      	bl	0x2430 <_stogir.cfg.build+0x2f8>
		0000000000002430:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2434:      	cmp	x0, #0x0
    2438:      	b.eq	0x2524 <_stogir.cfg.build+0x3ec>
    243c:      	add	x16, sp, #0x40
    2440:      	ldr	x21, [x16]
    2444:      	add	x16, sp, #0x40
    2448:      	ldr	x22, [x16, #0x8]
    244c:      	add	x16, sp, #0x40
    2450:      	ldr	x0, [x16, #0x10]
    2454:      	add	x16, sp, #0x40
    2458:      	ldr	x1, [x16, #0x18]
    245c:      	add	x16, sp, #0x40
    2460:      	ldr	x2, [x16, #0x20]
    2464:      	add	x16, sp, #0x40
    2468:      	ldr	x3, [x16, #0x28]
    246c:      	add	x16, sp, #0x40
    2470:      	ldr	x4, [x16, #0x30]
    2474:      	add	x16, sp, #0x40
    2478:      	ldr	x5, [x16, #0x38]
    247c:      	add	x16, sp, #0x40
    2480:      	ldr	x6, [x16, #0x40]
    2484:      	add	x16, sp, #0x40
    2488:      	ldr	x7, [x16, #0x48]
    248c:      	add	x16, sp, #0x40
    2490:      	ldr	x8, [x16, #0x50]
    2494:      	add	x16, sp, #0x40
    2498:      	ldr	x9, [x16, #0x58]
    249c:      	add	x16, sp, #0x40
    24a0:      	ldr	x10, [x16, #0x60]
    24a4:      	add	x16, sp, #0x40
    24a8:      	ldr	x11, [x16, #0x68]
    24ac:      	add	x16, sp, #0x40
    24b0:      	ldr	x12, [x16, #0x70]
    24b4:      	movz	x13, #0x0, lsl #48
    24b8:      	b	0x2564 <_stogir.cfg.build+0x42c>
    24bc:      	add	x16, sp, #0x210
    24c0:      	movz	x17, #0x0, lsl #48
    24c4:      	str	x17, [x16]
    24c8:      	add	x16, sp, #0x210
    24cc:      	movz	x17, #0x0, lsl #48
    24d0:      	str	x17, [x16, #0x8]
    24d4:      	add	x16, sp, #0x210
    24d8:      	str	w0, [x16]
    24dc:      	add	x16, sp, #0x210
    24e0:      	str	w24, [x16, #0x4]
    24e4:      	add	x16, sp, #0x210
    24e8:      	str	w1, [x16, #0x8]
    24ec:      	add	x16, sp, #0x210
    24f0:      	str	w20, [x16, #0xc]
    24f4:      	add	x16, sp, #0x210
    24f8:      	ldr	x20, [x16]
    24fc:      	add	x16, sp, #0x210
    2500:      	ldr	x0, [x16, #0x8]
    2504:      	ldr	x1, [x19, #0x8]
    2508:      	ldr	x2, [x19, #0x10]
    250c:      	cmp	x1, x2
    2510:      	b.lt	0x2cac <_stogir.cfg.build+0xb74>
    2514:      	cmp	x2, #0x0
    2518:      	b.ne	0x2228 <_stogir.cfg.build+0xf0>
    251c:      	mov	x2, #0x2                ; =2
    2520:      	b	0x222c <_stogir.cfg.build+0xf4>
    2524:      	add	x0, sp, #0x40
    2528:      	bl	0x2528 <_stogir.cfg.build+0x3f0>
		0000000000002528:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    252c:      	mov	x13, #0x1               ; =1
    2530:      	movz	x0, #0x0, lsl #48
    2534:      	movz	x1, #0x0, lsl #48
    2538:      	movz	x2, #0x0, lsl #48
    253c:      	movz	x3, #0x0, lsl #48
    2540:      	movz	x4, #0x0, lsl #48
    2544:      	movz	x5, #0x0, lsl #48
    2548:      	movz	x6, #0x0, lsl #48
    254c:      	movz	x7, #0x0, lsl #48
    2550:      	movz	x8, #0x0, lsl #48
    2554:      	movz	x9, #0x0, lsl #48
    2558:      	movz	x10, #0x0, lsl #48
    255c:      	movz	x11, #0x0, lsl #48
    2560:      	movz	x12, #0x0, lsl #48
    2564:      	ldr	x14, [sp, #0x258]
    2568:      	str	x13, [x14]
    256c:      	str	x21, [x14, #0x8]
    2570:      	str	x22, [x14, #0x10]
    2574:      	str	x0, [x14, #0x18]
    2578:      	str	x1, [x14, #0x20]
    257c:      	str	x2, [x14, #0x28]
    2580:      	str	x3, [x14, #0x30]
    2584:      	str	x4, [x14, #0x38]
    2588:      	str	x5, [x14, #0x40]
    258c:      	str	x6, [x14, #0x48]
    2590:      	str	x7, [x14, #0x50]
    2594:      	str	x8, [x14, #0x58]
    2598:      	str	x9, [x14, #0x60]
    259c:      	str	x10, [x14, #0x68]
    25a0:      	str	x11, [x14, #0x70]
    25a4:      	str	x12, [x14, #0x78]
    25a8:      	ldr	x19, [sp, #0x288]
    25ac:      	ldr	x20, [sp, #0x290]
    25b0:      	ldr	x21, [sp, #0x298]
    25b4:      	ldr	x22, [sp, #0x2a0]
    25b8:      	ldr	x23, [sp, #0x2a8]
    25bc:      	ldr	x24, [sp, #0x2b0]
    25c0:      	ldr	x25, [sp, #0x2b8]
    25c4:      	ldr	x26, [sp, #0x2c0]
    25c8:      	ldr	x27, [sp, #0x2c8]
    25cc:      	ldr	x28, [sp, #0x2d0]
    25d0:      	ldr	x29, [sp, #0x10]
    25d4:      	ldr	x30, [sp, #0x18]
    25d8:      	add	sp, sp, #0x2e0
    25dc:      	ret
    25e0:      	add	x16, sp, #0x40
    25e4:      	orr	x23, x16, xzr
    25e8:      	add	x8, sp, #0xc0
    25ec:      	mov	x0, x21
    25f0:      	bl	0x25f0 <_stogir.cfg.build+0x4b8>
		00000000000025f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    25f4:      	add	x24, x20, #0x78
    25f8:      	add	x0, x23, #0x28
    25fc:      	add	x1, x23, #0x28
    2600:      	add	x16, sp, #0xc0
    2604:      	ldr	x22, [x16]
    2608:      	orr	x25, x0, xzr
    260c:      	orr	x26, x1, xzr
    2610:      	add	x16, sp, #0xc0
    2614:      	ldr	x27, [x16, #0x8]
    2618:      	add	x16, sp, #0xc0
    261c:      	ldr	x28, [x16, #0x10]
    2620:      	add	x16, sp, #0xc0
    2624:      	ldr	x0, [x16, #0x18]
    2628:      	add	x16, sp, #0xc0
    262c:      	ldr	x1, [x16, #0x20]
    2630:      	add	x8, sp, #0xf0
    2634:      	str	x21, [sp, #0x240]
    2638:      	str	x25, [sp, #0x248]
    263c:      	mov	x25, x1
    2640:      	fmov	d31, x0
    2644:      	mov	x0, x21
    2648:      	fmov	x21, d31
    264c:      	bl	0x264c <_stogir.cfg.build+0x514>
		000000000000264c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    2650:      	add	x16, sp, #0xf0
    2654:      	ldr	x0, [x16]
    2658:      	add	x16, sp, #0xf0
    265c:      	ldr	x1, [x16, #0x8]
    2660:      	add	x16, sp, #0xf0
    2664:      	ldr	x2, [x16, #0x10]
    2668:      	add	x16, sp, #0xf0
    266c:      	ldr	x3, [x16, #0x18]
    2670:      	add	x16, sp, #0xf0
    2674:      	ldr	x4, [x16, #0x20]
    2678:      	add	x8, sp, #0x120
    267c:      	str	x26, [sp, #0x250]
    2680:      	mov	x26, x0
    2684:      	ldr	x0, [sp, #0x240]
    2688:      	str	x19, [sp, #0x258]
    268c:      	mov	x19, x1
    2690:      	str	x23, [sp, #0x260]
    2694:      	mov	x23, x2
    2698:      	str	x24, [sp, #0x268]
    269c:      	mov	x24, x3
    26a0:      	str	x20, [sp, #0x270]
    26a4:      	mov	x20, x4
    26a8:      	bl	0x26a8 <_stogir.cfg.build+0x570>
		00000000000026a8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge
    26ac:      	add	x16, sp, #0x120
    26b0:      	ldr	x0, [x16]
    26b4:      	add	x16, sp, #0x120
    26b8:      	ldr	x1, [x16, #0x8]
    26bc:      	add	x16, sp, #0x120
    26c0:      	ldr	x2, [x16, #0x10]
    26c4:      	add	x16, sp, #0x120
    26c8:      	ldr	x3, [x16, #0x18]
    26cc:      	add	x16, sp, #0x120
    26d0:      	ldr	x4, [x16, #0x20]
    26d4:      	add	x16, sp, #0x40
    26d8:      	str	x22, [x16]
    26dc:      	add	x16, sp, #0x40
    26e0:      	str	x27, [x16, #0x8]
    26e4:      	add	x16, sp, #0x40
    26e8:      	str	x28, [x16, #0x10]
    26ec:      	add	x16, sp, #0x40
    26f0:      	str	x21, [x16, #0x18]
    26f4:      	add	x16, sp, #0x40
    26f8:      	str	x25, [x16, #0x20]
    26fc:      	add	x16, sp, #0x40
    2700:      	str	x26, [x16, #0x28]
    2704:      	add	x16, sp, #0x40
    2708:      	str	x19, [x16, #0x30]
    270c:      	add	x16, sp, #0x40
    2710:      	str	x23, [x16, #0x38]
    2714:      	add	x16, sp, #0x40
    2718:      	str	x24, [x16, #0x40]
    271c:      	add	x16, sp, #0x40
    2720:      	str	x20, [x16, #0x48]
    2724:      	add	x16, sp, #0x40
    2728:      	str	x0, [x16, #0x50]
    272c:      	add	x16, sp, #0x40
    2730:      	str	x1, [x16, #0x58]
    2734:      	add	x16, sp, #0x40
    2738:      	str	x2, [x16, #0x60]
    273c:      	add	x16, sp, #0x40
    2740:      	str	x3, [x16, #0x68]
    2744:      	add	x16, sp, #0x40
    2748:      	str	x4, [x16, #0x70]
    274c:      	add	x8, sp, #0x180
    2750:      	ldr	x0, [sp, #0x240]
    2754:      	bl	0x2754 <_stogir.cfg.build+0x61c>
		0000000000002754:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    2758:      	add	x16, sp, #0x180
    275c:      	ldr	x0, [x16]
    2760:      	add	x16, sp, #0x150
    2764:      	str	x0, [x16]
    2768:      	add	x16, sp, #0x180
    276c:      	ldr	x0, [x16, #0x8]
    2770:      	add	x16, sp, #0x150
    2774:      	str	x0, [x16, #0x8]
    2778:      	add	x16, sp, #0x180
    277c:      	ldr	x0, [x16, #0x10]
    2780:      	add	x16, sp, #0x150
    2784:      	str	x0, [x16, #0x10]
    2788:      	add	x16, sp, #0x180
    278c:      	ldr	x0, [x16, #0x18]
    2790:      	add	x16, sp, #0x150
    2794:      	str	x0, [x16, #0x18]
    2798:      	add	x16, sp, #0x180
    279c:      	ldr	x0, [x16, #0x20]
    27a0:      	add	x16, sp, #0x150
    27a4:      	str	x0, [x16, #0x20]
    27a8:      	ldr	x0, [sp, #0x270]
    27ac:      	bl	0x27ac <_stogir.cfg.build+0x674>
		00000000000027ac:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    27b0:      	mov	x1, x0
    27b4:      	ldr	x0, [sp, #0x248]
    27b8:      	bl	0x27b8 <_stogir.cfg.build+0x680>
		00000000000027b8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    27bc:      	mov	x19, #0x1               ; =1
    27c0:      	b	0x280c <_stogir.cfg.build+0x6d4>
    27c4:      	nop
    27c8:      	orr	w0, w19, wzr
    27cc:      	orr	w22, w0, wzr
    27d0:      	add	x0, sp, #0x40
    27d4:      	mov	w1, w22
    27d8:      	bl	0x27d8 <_stogir.cfg.build+0x6a0>
		00000000000027d8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    27dc:      	ldr	x0, [sp, #0x250]
    27e0:      	mov	x1, x19
    27e4:      	mov	w2, w22
    27e8:      	bl	0x27e8 <_stogir.cfg.build+0x6b0>
		00000000000027e8:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    27ec:      	sxtw	x21, w21
    27f0:      	add	x0, x21, #0x4
    27f4:      	asr	x16, x0, #63
    27f8:      	lsr	x16, x16, #62
    27fc:      	add	x0, x0, x16
    2800:      	asr	x0, x0, #2
    2804:      	add	x19, x0, x19
    2808:      	str	x20, [sp, #0x270]
    280c:      	ldr	x20, [sp, #0x270]
    2810:      	ldr	x0, [x20, #0x8]
    2814:      	cmp	x19, x0
    2818:      	b.ge	0x2848 <_stogir.cfg.build+0x710>
    281c:      	ldr	x0, [x20]
    2820:      	add	x0, x0, x19, lsl #4
    2824:      	ldr	x0, [x0]
    2828:      	ldr	x1, [x20, #0x78]
    282c:      	uxtb	w0, w0
    2830:      	add	x1, x1, x19, lsl #2
    2834:      	ldr	w21, [x1]
    2838:      	bl	0x2838 <_stogir.cfg.build+0x700>
		0000000000002838:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-start?
    283c:      	cmp	x0, #0x0
    2840:      	b.ne	0x27c8 <_stogir.cfg.build+0x690>
    2844:      	b	0x27ec <_stogir.cfg.build+0x6b4>
    2848:      	mov	x19, #0x1               ; =1
    284c:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x94>
		000000000000284c:  ARM64_RELOC_PAGE21	l_stogir.407
    2850:      	ldr	x21, [x21]
		0000000000002850:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2854:      	movz	x22, #0x0, lsl #48
    2858:      	b	0x28fc <_stogir.cfg.build+0x7c4>
    285c:      	movz	w1, #0x0, lsl #16
    2860:      	movz	w0, #0x0, lsl #16
    2864:      	b	0x2a94 <_stogir.cfg.build+0x95c>
    2868:      	movz	w3, #0x0, lsl #16
    286c:      	movz	w4, #0x0, lsl #16
    2870:      	ubfx	x3, x3, #0, #32
    2874:      	lsr	x16, x3, #0
    2878:      	cmp	x16, #0x1
    287c:      	b.eq	0x2898 <_stogir.cfg.build+0x760>
    2880:      	b.lo	0x2888 <_stogir.cfg.build+0x750>
    2884:      	b	0x289c <_stogir.cfg.build+0x764>
    2888:      	cmp	x16, #0x0
    288c:      	b.eq	0x2894 <_stogir.cfg.build+0x75c>
    2890:      	b	0x289c <_stogir.cfg.build+0x764>
    2894:      	b	0x28dc <_stogir.cfg.build+0x7a4>
    2898:      	b	0x28a0 <_stogir.cfg.build+0x768>
    289c:      	b	0x2c6c <_stogir.cfg.build+0xb34>
    28a0:      	sxtw	x4, w4
    28a4:      	add	x16, sp, #0x40
    28a8:      	ldr	x3, [x16, #0x28]
    28ac:      	add	x3, x3, x4, lsl #2
    28b0:      	str	w25, [x3]
    28b4:      	cmp	x2, x1
    28b8:      	b.ge	0x2868 <_stogir.cfg.build+0x730>
    28bc:      	add	x3, x2, #0x1
    28c0:      	add	x2, x0, x2, lsl #2
    28c4:      	ldr	w2, [x2]
    28c8:      	movn	w17, #0x0, lsl #16
    28cc:      	and	w4, w2, w17
    28d0:      	mov	x2, x3
    28d4:      	mov	w3, #0x1                ; =1
    28d8:      	b	0x2870 <_stogir.cfg.build+0x738>
    28dc:      	sxtw	x23, w23
    28e0:      	add	x0, x23, #0x4
    28e4:      	asr	x16, x0, #63
    28e8:      	lsr	x16, x16, #62
    28ec:      	add	x0, x0, x16
    28f0:      	asr	x0, x0, #2
    28f4:      	add	x19, x0, x19
    28f8:      	str	x26, [sp, #0x268]
    28fc:      	mov	x0, x21
    2900:      	mov	x1, x22
    2904:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x94>
		0000000000002904:  ARM64_RELOC_PAGE21	l_stogir.407
    2908:      	ldr	x2, [x2]
		0000000000002908:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    290c:      	movz	x3, #0x0, lsl #48
    2910:      	bl	0x2910 <_stogir.cfg.build+0x7d8>
		0000000000002910:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2914:      	cmp	x0, #0x0
    2918:      	b.eq	0x2930 <_stogir.cfg.build+0x7f8>
    291c:      	ldr	x0, [x20, #0x8]
    2920:      	cmp	x19, x0
    2924:      	cset	w0, lt
    2928:      	ubfx	x0, x0, #0, #8
    292c:      	b	0x2934 <_stogir.cfg.build+0x7fc>
    2930:      	movz	x0, #0x0, lsl #48
    2934:      	cmp	x0, #0x0
    2938:      	b.eq	0x2be8 <_stogir.cfg.build+0xab0>
    293c:      	ldr	x0, [x20]
    2940:      	add	x0, x0, x19, lsl #4
    2944:      	ldr	x0, [x0]
    2948:      	ldr	x1, [x20, #0x78]
    294c:      	uxtb	w0, w0
    2950:      	add	x1, x1, x19, lsl #2
    2954:      	ldr	w23, [x1]
    2958:      	bl	0x2958 <_stogir.cfg.build+0x820>
		0000000000002958:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    295c:      	cmp	x0, #0x0
    2960:      	b.eq	0x2988 <_stogir.cfg.build+0x850>
    2964:      	add	x16, sp, #0x40
    2968:      	ldr	x0, [x16, #0x28]
    296c:      	add	x0, x0, x19, lsl #2
    2970:      	ldr	w0, [x0]
    2974:      	sxtw	x0, w0
    2978:      	cmp	x0, #0x0
    297c:      	cset	w0, eq
    2980:      	ubfx	x0, x0, #0, #8
    2984:      	b	0x298c <_stogir.cfg.build+0x854>
    2988:      	movz	x0, #0x0, lsl #48
    298c:      	cmp	x0, #0x0
    2990:      	b.eq	0x2cc0 <_stogir.cfg.build+0xb88>
    2994:      	orr	w24, w19, wzr
    2998:      	add	x0, sp, #0x150
    299c:      	bl	0x299c <_stogir.cfg.build+0x864>
		000000000000299c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$clear!__i32
    29a0:      	sxtw	x24, w24
    29a4:      	movz	x25, #0x0, lsl #48
    29a8:      	b	0x2a10 <_stogir.cfg.build+0x8d8>
    29ac:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x94>
		00000000000029ac:  ARM64_RELOC_PAGE21	l_stogir.408
    29b0:      	ldr	x21, [x21]
		00000000000029b0:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    29b4:      	mov	x22, #0x1b              ; =27
    29b8:      	b	0x2a0c <_stogir.cfg.build+0x8d4>
    29bc:      	nop
    29c0:      	movz	x0, #0x0, lsl #48
    29c4:      	cmp	x0, #0x0
    29c8:      	b.eq	0x2cc8 <_stogir.cfg.build+0xb90>
    29cc:      	add	x16, sp, #0x40
    29d0:      	ldr	x0, [x16, #0x28]
    29d4:      	add	x0, x0, x24, lsl #2
    29d8:      	ldr	w0, [x0]
    29dc:      	sxtw	x25, w0
    29e0:      	cmp	x25, #0x0
    29e4:      	b.ne	0x2cd0 <_stogir.cfg.build+0xb98>
    29e8:      	add	x16, sp, #0x150
    29ec:      	ldr	x0, [x16, #0x8]
    29f0:      	ldr	x1, [x20, #0x8]
    29f4:      	cmp	x0, x1
    29f8:      	b.lt	0x2a28 <_stogir.cfg.build+0x8f0>
    29fc:      	ldr	x26, [sp, #0x268]
    2a00:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x94>
		0000000000002a00:  ARM64_RELOC_PAGE21	l_stogir.409
    2a04:      	ldr	x21, [x21]
		0000000000002a04:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    2a08:      	mov	x22, #0x27              ; =39
    2a0c:      	str	x26, [sp, #0x268]
    2a10:      	cmp	x22, #0x0
    2a14:      	b.ne	0x29c0 <_stogir.cfg.build+0x888>
    2a18:      	cmp	x25, #0x0
    2a1c:      	cset	w0, eq
    2a20:      	ubfx	x0, x0, #0, #8
    2a24:      	b	0x29c4 <_stogir.cfg.build+0x88c>
    2a28:      	orr	x26, x0, xzr
    2a2c:      	add	x16, sp, #0x150
    2a30:      	ldr	x0, [x16, #0x10]
    2a34:      	cmp	x26, x0
    2a38:      	b.lt	0x2a5c <_stogir.cfg.build+0x924>
    2a3c:      	cmp	x0, #0x0
    2a40:      	b.ne	0x2a4c <_stogir.cfg.build+0x914>
    2a44:      	mov	x0, #0x2                ; =2
    2a48:      	b	0x2a50 <_stogir.cfg.build+0x918>
    2a4c:      	lsl	x0, x0, #1
    2a50:      	mov	x1, x0
    2a54:      	add	x0, sp, #0x150
    2a58:      	bl	0x2a58 <_stogir.cfg.build+0x920>
		0000000000002a58:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    2a5c:      	orr	w0, w24, wzr
    2a60:      	add	x1, x26, #0x1
    2a64:      	sxtw	x2, w0
    2a68:      	add	x16, sp, #0x150
    2a6c:      	ldr	x3, [x16]
    2a70:      	add	x3, x3, x26, lsl #2
    2a74:      	str	w0, [x3]
    2a78:      	add	x16, sp, #0x150
    2a7c:      	str	x1, [x16, #0x8]
    2a80:      	cmp	x2, #0x0
    2a84:      	b.gt	0x2ad4 <_stogir.cfg.build+0x99c>
    2a88:      	ldr	x26, [sp, #0x268]
    2a8c:      	movz	w1, #0x0, lsl #16
    2a90:      	movz	w0, #0x0, lsl #16
    2a94:      	ubfx	x1, x1, #0, #32
    2a98:      	lsr	x16, x1, #0
    2a9c:      	cmp	x16, #0x1
    2aa0:      	b.eq	0x2abc <_stogir.cfg.build+0x984>
    2aa4:      	b.lo	0x2aac <_stogir.cfg.build+0x974>
    2aa8:      	b	0x2ac0 <_stogir.cfg.build+0x988>
    2aac:      	cmp	x16, #0x0
    2ab0:      	b.eq	0x2ab8 <_stogir.cfg.build+0x980>
    2ab4:      	b	0x2ac0 <_stogir.cfg.build+0x988>
    2ab8:      	b	0x2ac4 <_stogir.cfg.build+0x98c>
    2abc:      	b	0x2b5c <_stogir.cfg.build+0xa24>
    2ac0:      	b	0x2c74 <_stogir.cfg.build+0xb3c>
    2ac4:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x94>
		0000000000002ac4:  ARM64_RELOC_PAGE21	l_stogir.410
    2ac8:      	ldr	x21, [x21]
		0000000000002ac8:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    2acc:      	mov	x22, #0x1e              ; =30
    2ad0:      	b	0x29b8 <_stogir.cfg.build+0x880>
    2ad4:      	lsl	x0, x2, #2
    2ad8:      	ldr	x1, [x20, #0x8]
    2adc:      	cmp	x2, x1
    2ae0:      	b.ge	0x2cd8 <_stogir.cfg.build+0xba0>
    2ae4:      	ldr	x26, [sp, #0x268]
    2ae8:      	ldr	x1, [x26, #0x8]
    2aec:      	cmp	x2, x1
    2af0:      	b.ge	0x2ba0 <_stogir.cfg.build+0xa68>
    2af4:      	ldr	x1, [x20, #0x78]
    2af8:      	add	x1, x0, x1
    2afc:      	ldr	w1, [x1]
    2b00:      	sxtw	x1, w1
    2b04:      	cmp	x1, #0x0
    2b08:      	cset	w1, ge
    2b0c:      	ubfx	x1, x1, #0, #8
    2b10:      	b	0x2ba4 <_stogir.cfg.build+0xa6c>
    2b14:      	mov	x0, x21
    2b18:      	mov	x1, x22
    2b1c:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x94>
		0000000000002b1c:  ARM64_RELOC_PAGE21	l_stogir.407
    2b20:      	ldr	x2, [x2]
		0000000000002b20:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2b24:      	movz	x3, #0x0, lsl #48
    2b28:      	bl	0x2b28 <_stogir.cfg.build+0x9f0>
		0000000000002b28:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2b2c:      	cmp	x0, #0x0
    2b30:      	b.eq	0x28dc <_stogir.cfg.build+0x7a4>
    2b34:      	add	x8, sp, #0x1b0
    2b38:      	add	x0, sp, #0x150
    2b3c:      	bl	0x2b3c <_stogir.cfg.build+0xa04>
		0000000000002b3c:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2b40:      	add	x16, sp, #0x1b0
    2b44:      	ldr	x0, [x16]
    2b48:      	add	x16, sp, #0x1b0
    2b4c:      	ldr	x1, [x16, #0x8]
    2b50:      	add	x16, sp, #0x1b0
    2b54:      	ldr	x2, [x16, #0x10]
    2b58:      	b	0x28b4 <_stogir.cfg.build+0x77c>
    2b5c:      	sxtw	x0, w0
    2b60:      	cmp	x0, #0x0
    2b64:      	b.le	0x29ac <_stogir.cfg.build+0x874>
    2b68:      	ldr	x1, [x20, #0x8]
    2b6c:      	cmp	x0, x1
    2b70:      	b.ge	0x2c50 <_stogir.cfg.build+0xb18>
    2b74:      	ldr	x1, [x26, #0x8]
    2b78:      	cmp	x0, x1
    2b7c:      	b.ge	0x2c64 <_stogir.cfg.build+0xb2c>
    2b80:      	ldr	x1, [x20, #0x78]
    2b84:      	add	x1, x1, x0, lsl #2
    2b88:      	ldr	w1, [x1]
    2b8c:      	sxtw	x1, w1
    2b90:      	cmp	x1, #0x0
    2b94:      	cset	w1, ge
    2b98:      	ubfx	x1, x1, #0, #8
    2b9c:      	b	0x2c68 <_stogir.cfg.build+0xb30>
    2ba0:      	movz	x1, #0x0, lsl #48
    2ba4:      	b	0x2bac <_stogir.cfg.build+0xa74>
    2ba8:      	movz	x1, #0x0, lsl #48
    2bac:      	cmp	x1, #0x0
    2bb0:      	b.eq	0x2a8c <_stogir.cfg.build+0x954>
    2bb4:      	ldr	x1, [x20, #0x78]
    2bb8:      	add	x0, x0, x1
    2bbc:      	ldr	w0, [x0]
    2bc0:      	sxtw	x0, w0
    2bc4:      	cmp	x0, #0x1
    2bc8:      	b.lt	0x285c <_stogir.cfg.build+0x724>
    2bcc:      	ldr	x0, [x20]
    2bd0:      	add	x0, x0, x2, lsl #4
    2bd4:      	ldr	w0, [x0, #0x4]
    2bd8:      	movn	w17, #0x0, lsl #16
    2bdc:      	and	w0, w0, w17
    2be0:      	mov	w1, #0x1                ; =1
    2be4:      	b	0x2864 <_stogir.cfg.build+0x72c>
    2be8:      	mov	x0, x21
    2bec:      	mov	x1, x22
    2bf0:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x94>
		0000000000002bf0:  ARM64_RELOC_PAGE21	l_stogir.407
    2bf4:      	ldr	x2, [x2]
		0000000000002bf4:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2bf8:      	movz	x3, #0x0, lsl #48
    2bfc:      	bl	0x2bfc <_stogir.cfg.build+0xac4>
		0000000000002bfc:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2c00:      	cmp	x0, #0x0
    2c04:      	b.eq	0x2414 <_stogir.cfg.build+0x2dc>
    2c08:      	ldr	x0, [sp, #0x260]
    2c0c:      	add	x19, x0, #0x50
    2c10:      	add	x8, sp, #0x1f0
    2c14:      	add	x0, sp, #0x40
    2c18:      	bl	0x2c18 <_stogir.cfg.build+0xae0>
		0000000000002c18:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2c1c:      	add	x16, sp, #0x1f0
    2c20:      	ldr	x0, [x16]
    2c24:      	add	x16, sp, #0x1d0
    2c28:      	str	x0, [x16]
    2c2c:      	add	x16, sp, #0x1f0
    2c30:      	ldr	x0, [x16, #0x8]
    2c34:      	add	x16, sp, #0x1d0
    2c38:      	str	x0, [x16, #0x8]
    2c3c:      	add	x16, sp, #0x1f0
    2c40:      	ldr	x0, [x16, #0x10]
    2c44:      	add	x16, sp, #0x1d0
    2c48:      	str	x0, [x16, #0x10]
    2c4c:      	b	0x2390 <_stogir.cfg.build+0x258>
    2c50:      	movz	x1, #0x0, lsl #48
    2c54:      	cmp	x1, #0x0
    2c58:      	b.eq	0x29ac <_stogir.cfg.build+0x874>
    2c5c:      	mov	x24, x0
    2c60:      	b	0x29b8 <_stogir.cfg.build+0x880>
    2c64:      	movz	x1, #0x0, lsl #48
    2c68:      	b	0x2c54 <_stogir.cfg.build+0xb1c>
    2c6c:      	brk	#0
    2c70:      	b	0x2c6c <_stogir.cfg.build+0xb34>
    2c74:      	brk	#0
    2c78:      	b	0x2c74 <_stogir.cfg.build+0xb3c>
    2c7c:      	brk	#0
    2c80:      	b	0x2c7c <_stogir.cfg.build+0xb44>
    2c84:      	brk	#0
    2c88:      	b	0x2c84 <_stogir.cfg.build+0xb4c>
    2c8c:      	brk	#0
    2c90:      	b	0x2c8c <_stogir.cfg.build+0xb54>
    2c94:      	str	x20, [sp, #0x270]
    2c98:      	b	0x238c <_stogir.cfg.build+0x254>
    2c9c:      	str	x20, [sp, #0x270]
    2ca0:      	str	w23, [sp, #0x278]
    2ca4:      	str	w24, [sp, #0x280]
    2ca8:      	b	0x2264 <_stogir.cfg.build+0x12c>
    2cac:      	str	w23, [sp, #0x278]
    2cb0:      	str	w24, [sp, #0x280]
    2cb4:      	mov	x23, x0
    2cb8:      	mov	x24, x1
    2cbc:      	b	0x2248 <_stogir.cfg.build+0x110>
    2cc0:      	ldr	x26, [sp, #0x268]
    2cc4:      	b	0x28dc <_stogir.cfg.build+0x7a4>
    2cc8:      	ldr	x26, [sp, #0x268]
    2ccc:      	b	0x2b14 <_stogir.cfg.build+0x9dc>
    2cd0:      	ldr	x26, [sp, #0x268]
    2cd4:      	b	0x2a0c <_stogir.cfg.build+0x8d4>
    2cd8:      	ldr	x26, [sp, #0x268]
    2cdc:      	b	0x2ba8 <_stogir.cfg.build+0xa70>

0000000000002ce0 <_stogir.adjacency.build>:
    2ce0:      	sub	sp, sp, #0x70
    2ce4:      	str	x29, [sp]
    2ce8:      	str	x30, [sp, #0x8]
    2cec:      	mov	x29, sp
    2cf0:      	str	x19, [sp, #0x18]
    2cf4:      	str	x20, [sp, #0x20]
    2cf8:      	str	x21, [sp, #0x28]
    2cfc:      	str	x22, [sp, #0x30]
    2d00:      	str	x23, [sp, #0x38]
    2d04:      	str	x24, [sp, #0x40]
    2d08:      	str	x25, [sp, #0x48]
    2d0c:      	str	x26, [sp, #0x50]
    2d10:      	str	x27, [sp, #0x58]
    2d14:      	str	x28, [sp, #0x60]
    2d18:      	add	x3, x0, #0x28
    2d1c:      	ldr	x3, [x3, #0x8]
    2d20:      	orr	x19, x3, xzr
    2d24:      	mov	x20, sp
    2d28:      	sub	sp, sp, #0x50
    2d2c:      	mov	x21, sp
    2d30:      	sub	sp, sp, #0x30
    2d34:      	mov	x22, sp
    2d38:      	ldr	x3, [x2]
    2d3c:      	ldr	x2, [x2, #0x8]
    2d40:      	movz	x17, #0x0, lsl #48
    2d44:      	str	x17, [x21]
    2d48:      	movz	x17, #0x0, lsl #48
    2d4c:      	str	x17, [x21, #0x8]
    2d50:      	movz	x17, #0x0, lsl #48
    2d54:      	str	x17, [x21, #0x10]
    2d58:      	str	x3, [x21, #0x18]
    2d5c:      	str	x2, [x21, #0x20]
    2d60:      	movz	x17, #0x0, lsl #48
    2d64:      	str	x17, [x21, #0x28]
    2d68:      	movz	x17, #0x0, lsl #48
    2d6c:      	str	x17, [x21, #0x30]
    2d70:      	movz	x17, #0x0, lsl #48
    2d74:      	str	x17, [x21, #0x38]
    2d78:      	str	x3, [x21, #0x40]
    2d7c:      	str	x2, [x21, #0x48]
    2d80:      	movz	x17, #0x0, lsl #48
    2d84:      	str	x17, [x22]
    2d88:      	movz	x17, #0x0, lsl #48
    2d8c:      	str	x17, [x22, #0x8]
    2d90:      	movz	x17, #0x0, lsl #48
    2d94:      	str	x17, [x22, #0x10]
    2d98:      	str	x3, [x22, #0x18]
    2d9c:      	str	x2, [x22, #0x20]
    2da0:      	cmp	x19, #0x0
    2da4:      	b.le	0x3150 <_stogir.adjacency.build+0x470>
    2da8:      	cmp	x19, #0x0
    2dac:      	b.ge	0x2db8 <_stogir.adjacency.build+0xd8>
    2db0:      	movz	x2, #0x0, lsl #48
    2db4:      	b	0x2dbc <_stogir.adjacency.build+0xdc>
    2db8:      	mov	x2, x19
    2dbc:      	mov	x23, x8
    2dc0:      	mov	x24, x0
    2dc4:      	mov	x0, x21
    2dc8:      	mov	w25, w1
    2dcc:      	mov	x1, x2
    2dd0:      	bl	0x2dd0 <_stogir.adjacency.build+0xf0>
		0000000000002dd0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range
    2dd4:      	lsl	x0, x19, #4
    2dd8:      	ldr	x1, [x21]
    2ddc:      	mov	x2, x0
    2de0:      	mov	x0, x1
    2de4:      	movz	x1, #0x0, lsl #48
    2de8:      	bl	0x2de8 <_stogir.adjacency.build+0x108>
		0000000000002de8:  ARM64_RELOC_BRANCH26	_memset
    2dec:      	str	x19, [x21, #0x8]
    2df0:      	ldr	x0, [x22, #0x8]
    2df4:      	orr	x26, x0, xzr
    2df8:      	ldr	x0, [x22, #0x10]
    2dfc:      	add	x27, x26, x19
    2e00:      	cmp	x27, x0
    2e04:      	b.le	0x2e38 <_stogir.adjacency.build+0x158>
    2e08:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2e0c:      	cmp	x0, x17
    2e10:      	b.gt	0x2e1c <_stogir.adjacency.build+0x13c>
    2e14:      	lsl	x0, x0, #1
    2e18:      	b	0x2e20 <_stogir.adjacency.build+0x140>
    2e1c:      	mov	x0, x27
    2e20:      	cmp	x0, x27
    2e24:      	b.gt	0x2e2c <_stogir.adjacency.build+0x14c>
    2e28:      	mov	x0, x27
    2e2c:      	mov	x1, x0
    2e30:      	mov	x0, x22
    2e34:      	bl	0x2e34 <_stogir.adjacency.build+0x154>
		0000000000002e34:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    2e38:      	add	x28, x24, #0x50
    2e3c:      	ubfx	x25, x25, #0, #8
    2e40:      	lsl	x0, x19, #3
    2e44:      	cmp	x25, #0x0
    2e48:      	cset	w19, ne
    2e4c:      	ldr	x1, [x22]
    2e50:      	add	x1, x1, x26, lsl #3
    2e54:      	mov	x2, x0
    2e58:      	mov	x0, x1
    2e5c:      	movz	x1, #0x0, lsl #48
    2e60:      	bl	0x2e60 <_stogir.adjacency.build+0x180>
		0000000000002e60:  ARM64_RELOC_BRANCH26	_memset
    2e64:      	str	x27, [x22, #0x8]
    2e68:      	ldr	x0, [x24, #0x50]
    2e6c:      	ldr	x1, [x28, #0x8]
    2e70:      	movz	x2, #0x0, lsl #48
    2e74:      	b	0x2ea0 <_stogir.adjacency.build+0x1c0>
    2e78:      	sxtw	x3, w4
    2e7c:      	ldr	x4, [x21]
    2e80:      	orr	x5, x4, xzr
    2e84:      	add	x5, x5, x3, lsl #4
    2e88:      	add	x3, x4, x3, lsl #4
    2e8c:      	ldr	x4, [x5]
    2e90:      	ldr	x5, [x5, #0x8]
    2e94:      	add	x5, x5, #0x1
    2e98:      	str	x4, [x3]
    2e9c:      	str	x5, [x3, #0x8]
    2ea0:      	cmp	x2, x1
    2ea4:      	b.ge	0x2ec0 <_stogir.adjacency.build+0x1e0>
    2ea8:      	add	x3, x2, #0x1
    2eac:      	add	x2, x0, x2, lsl #4
    2eb0:      	ldr	x4, [x2]
    2eb4:      	mov	x2, x3
    2eb8:      	mov	w3, #0x1                ; =1
    2ebc:      	b	0x2ec8 <_stogir.adjacency.build+0x1e8>
    2ec0:      	movz	w3, #0x0, lsl #16
    2ec4:      	movz	x4, #0x0, lsl #48
    2ec8:      	ubfx	x3, x3, #0, #32
    2ecc:      	lsr	x16, x3, #0
    2ed0:      	cmp	x16, #0x1
    2ed4:      	b.eq	0x2ef0 <_stogir.adjacency.build+0x210>
    2ed8:      	b.lo	0x2ee0 <_stogir.adjacency.build+0x200>
    2edc:      	b	0x2ef4 <_stogir.adjacency.build+0x214>
    2ee0:      	cmp	x16, #0x0
    2ee4:      	b.eq	0x2eec <_stogir.adjacency.build+0x20c>
    2ee8:      	b	0x2ef4 <_stogir.adjacency.build+0x214>
    2eec:      	b	0x2f0c <_stogir.adjacency.build+0x22c>
    2ef0:      	b	0x2ef8 <_stogir.adjacency.build+0x218>
    2ef4:      	b	0x3148 <_stogir.adjacency.build+0x468>
    2ef8:      	uxtb	w16, w19
    2efc:      	cmp	w16, wzr
    2f00:      	b.eq	0x2e78 <_stogir.adjacency.build+0x198>
    2f04:      	asr	x3, x4, #32
    2f08:      	b	0x2e7c <_stogir.adjacency.build+0x19c>
    2f0c:      	movz	x0, #0x0, lsl #48
    2f10:      	movz	x1, #0x0, lsl #48
    2f14:      	b	0x2f50 <_stogir.adjacency.build+0x270>
    2f18:      	add	x2, x0, #0x1
    2f1c:      	ldr	x3, [x21]
    2f20:      	orr	x4, x3, xzr
    2f24:      	add	x4, x4, x0, lsl #4
    2f28:      	add	x3, x3, x0, lsl #4
    2f2c:      	ldr	x4, [x4, #0x8]
    2f30:      	add	x5, x4, x1
    2f34:      	str	x1, [x3]
    2f38:      	str	x4, [x3, #0x8]
    2f3c:      	ldr	x3, [x22]
    2f40:      	add	x0, x3, x0, lsl #3
    2f44:      	str	x1, [x0]
    2f48:      	mov	x0, x2
    2f4c:      	mov	x1, x5
    2f50:      	ldr	x2, [x21, #0x8]
    2f54:      	cmp	x0, x2
    2f58:      	b.lt	0x2f18 <_stogir.adjacency.build+0x238>
    2f5c:      	add	x19, x21, #0x28
    2f60:      	ldr	x0, [x28, #0x8]
    2f64:      	orr	x26, x0, xzr
    2f68:      	ldr	x0, [x19, #0x8]
    2f6c:      	orr	x27, x0, xzr
    2f70:      	ldr	x0, [x19, #0x10]
    2f74:      	add	x1, x27, x26
    2f78:      	cmp	x1, x0
    2f7c:      	b.le	0x3160 <_stogir.adjacency.build+0x480>
    2f80:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2f84:      	cmp	x0, x17
    2f88:      	b.gt	0x2f94 <_stogir.adjacency.build+0x2b4>
    2f8c:      	lsl	x0, x0, #1
    2f90:      	b	0x2f98 <_stogir.adjacency.build+0x2b8>
    2f94:      	mov	x0, x1
    2f98:      	cmp	x0, x1
    2f9c:      	b.gt	0x2fa4 <_stogir.adjacency.build+0x2c4>
    2fa0:      	mov	x0, x1
    2fa4:      	str	x23, [x29, #0x10]
    2fa8:      	mov	x23, x1
    2fac:      	mov	x1, x0
    2fb0:      	mov	x0, x19
    2fb4:      	bl	0x2fb4 <_stogir.adjacency.build+0x2d4>
		0000000000002fb4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    2fb8:      	cmp	x25, #0x0
    2fbc:      	cset	w25, ne
    2fc0:      	lsl	x0, x26, #3
    2fc4:      	ldr	x1, [x21, #0x28]
    2fc8:      	add	x1, x1, x27, lsl #3
    2fcc:      	mov	x2, x0
    2fd0:      	mov	x0, x1
    2fd4:      	movz	x1, #0x0, lsl #48
    2fd8:      	bl	0x2fd8 <_stogir.adjacency.build+0x2f8>
		0000000000002fd8:  ARM64_RELOC_BRANCH26	_memset
    2fdc:      	str	x23, [x19, #0x8]
    2fe0:      	movz	x0, #0x0, lsl #48
    2fe4:      	b	0x301c <_stogir.adjacency.build+0x33c>
    2fe8:      	sxtw	x1, w1
    2fec:      	add	x2, x0, #0x1
    2ff0:      	ldr	x3, [x22]
    2ff4:      	add	x3, x3, x1, lsl #3
    2ff8:      	ldr	x3, [x3]
    2ffc:      	ldr	x4, [x21, #0x28]
    3000:      	add	x5, x3, #0x1
    3004:      	add	x3, x4, x3, lsl #3
    3008:      	str	x0, [x3]
    300c:      	ldr	x0, [x22]
    3010:      	add	x0, x0, x1, lsl #3
    3014:      	str	x5, [x0]
    3018:      	mov	x0, x2
    301c:      	ldr	x1, [x28, #0x8]
    3020:      	cmp	x0, x1
    3024:      	b.ge	0x3048 <_stogir.adjacency.build+0x368>
    3028:      	ldr	x1, [x24, #0x50]
    302c:      	add	x1, x1, x0, lsl #4
    3030:      	ldr	x1, [x1]
    3034:      	uxtb	w16, w25
    3038:      	cmp	w16, wzr
    303c:      	b.eq	0x2fe8 <_stogir.adjacency.build+0x308>
    3040:      	asr	x1, x1, #32
    3044:      	b	0x2fec <_stogir.adjacency.build+0x30c>
    3048:      	b	0x3058 <_stogir.adjacency.build+0x378>
    304c:      	nop
    3050:      	sub	x0, x0, #0x1
    3054:      	str	x0, [x22, #0x8]
    3058:      	ldr	x0, [x22, #0x8]
    305c:      	cmp	x0, #0x0
    3060:      	b.ne	0x3050 <_stogir.adjacency.build+0x370>
    3064:      	ldr	x0, [x22, #0x10]
    3068:      	cmp	x0, #0x0
    306c:      	b.le	0x309c <_stogir.adjacency.build+0x3bc>
    3070:      	add	x1, x22, #0x18
    3074:      	ldr	x2, [x22]
    3078:      	fmov	d31, x0
    307c:      	mov	x0, x1
    3080:      	mov	x1, x2
    3084:      	fmov	x2, d31
    3088:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x320>
		0000000000003088:  ARM64_RELOC_PAGE21	l_stogir.411
    308c:      	ldr	x3, [x3]
		000000000000308c:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    3090:      	mov	x4, #0x8                ; =8
    3094:      	mov	x5, #0x8                ; =8
    3098:      	bl	0x3098 <_stogir.adjacency.build+0x3b8>
		0000000000003098:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    309c:      	movz	x17, #0x0, lsl #48
    30a0:      	str	x17, [x22]
    30a4:      	movz	x17, #0x0, lsl #48
    30a8:      	str	x17, [x22, #0x8]
    30ac:      	movz	x17, #0x0, lsl #48
    30b0:      	str	x17, [x22, #0x10]
    30b4:      	ldr	x0, [x21]
    30b8:      	ldr	x1, [x21, #0x8]
    30bc:      	ldr	x2, [x21, #0x10]
    30c0:      	ldr	x3, [x21, #0x18]
    30c4:      	ldr	x4, [x21, #0x20]
    30c8:      	ldr	x5, [x21, #0x28]
    30cc:      	ldr	x6, [x21, #0x30]
    30d0:      	ldr	x7, [x21, #0x38]
    30d4:      	ldr	x8, [x21, #0x40]
    30d8:      	ldr	x9, [x21, #0x48]
    30dc:      	mov	sp, x20
    30e0:      	ldr	x10, [x29, #0x10]
    30e4:      	str	x0, [x10]
    30e8:      	str	x1, [x10, #0x8]
    30ec:      	str	x2, [x10, #0x10]
    30f0:      	str	x3, [x10, #0x18]
    30f4:      	str	x4, [x10, #0x20]
    30f8:      	str	x5, [x10, #0x28]
    30fc:      	str	x6, [x10, #0x30]
    3100:      	str	x7, [x10, #0x38]
    3104:      	str	x8, [x10, #0x40]
    3108:      	str	x9, [x10, #0x48]
    310c:      	sub	sp, x29, #0x0
    3110:      	ldr	x19, [sp, #0x18]
    3114:      	ldr	x20, [sp, #0x20]
    3118:      	ldr	x21, [sp, #0x28]
    311c:      	ldr	x22, [sp, #0x30]
    3120:      	ldr	x23, [sp, #0x38]
    3124:      	ldr	x24, [sp, #0x40]
    3128:      	ldr	x25, [sp, #0x48]
    312c:      	ldr	x26, [sp, #0x50]
    3130:      	ldr	x27, [sp, #0x58]
    3134:      	ldr	x28, [sp, #0x60]
    3138:      	ldr	x29, [sp]
    313c:      	ldr	x30, [sp, #0x8]
    3140:      	add	sp, sp, #0x70
    3144:      	ret
    3148:      	brk	#0
    314c:      	b	0x3148 <_stogir.adjacency.build+0x468>
    3150:      	mov	x23, x8
    3154:      	mov	x24, x0
    3158:      	mov	w25, w1
    315c:      	b	0x2dd4 <_stogir.adjacency.build+0xf4>
    3160:      	str	x23, [x29, #0x10]
    3164:      	mov	x23, x1
    3168:      	b	0x2fb8 <_stogir.adjacency.build+0x2d8>
    316c:      	udf	#0x0

0000000000003170 <_stogir.adjacency.reverse-postorder>:
    3170:      	sub	sp, sp, #0x120
    3174:      	str	x29, [sp]
    3178:      	str	x30, [sp, #0x8]
    317c:      	mov	x29, sp
    3180:      	str	x19, [sp, #0xf0]
    3184:      	str	x20, [sp, #0xf8]
    3188:      	str	x21, [sp, #0x100]
    318c:      	str	x22, [sp, #0x108]
    3190:      	str	x23, [sp, #0x110]
    3194:      	str	x24, [sp, #0x118]
    3198:      	add	x4, x0, #0x28
    319c:      	ldr	x5, [x3]
    31a0:      	ldr	x3, [x3, #0x8]
    31a4:      	add	x16, sp, #0x10
    31a8:      	movz	x17, #0x0, lsl #48
    31ac:      	str	x17, [x16]
    31b0:      	add	x16, sp, #0x10
    31b4:      	movz	x17, #0x0, lsl #48
    31b8:      	str	x17, [x16, #0x8]
    31bc:      	add	x16, sp, #0x10
    31c0:      	movz	x17, #0x0, lsl #48
    31c4:      	str	x17, [x16, #0x10]
    31c8:      	add	x16, sp, #0x10
    31cc:      	str	x5, [x16, #0x18]
    31d0:      	add	x16, sp, #0x10
    31d4:      	str	x3, [x16, #0x20]
    31d8:      	add	x16, sp, #0x40
    31dc:      	movz	x17, #0x0, lsl #48
    31e0:      	str	x17, [x16]
    31e4:      	add	x16, sp, #0x40
    31e8:      	movz	x17, #0x0, lsl #48
    31ec:      	str	x17, [x16, #0x8]
    31f0:      	add	x16, sp, #0x40
    31f4:      	movz	x17, #0x0, lsl #48
    31f8:      	str	x17, [x16, #0x10]
    31fc:      	add	x16, sp, #0x40
    3200:      	str	x5, [x16, #0x18]
    3204:      	add	x16, sp, #0x40
    3208:      	str	x3, [x16, #0x20]
    320c:      	add	x16, sp, #0x70
    3210:      	movz	x17, #0x0, lsl #48
    3214:      	str	x17, [x16]
    3218:      	add	x16, sp, #0x70
    321c:      	movz	x17, #0x0, lsl #48
    3220:      	str	x17, [x16, #0x8]
    3224:      	add	x16, sp, #0x70
    3228:      	movz	x17, #0x0, lsl #48
    322c:      	str	x17, [x16, #0x10]
    3230:      	add	x16, sp, #0x70
    3234:      	str	x5, [x16, #0x18]
    3238:      	add	x16, sp, #0x70
    323c:      	str	x3, [x16, #0x20]
    3240:      	add	x16, sp, #0xa0
    3244:      	movz	x17, #0x0, lsl #48
    3248:      	str	x17, [x16]
    324c:      	add	x16, sp, #0xa0
    3250:      	movz	x17, #0x0, lsl #48
    3254:      	str	x17, [x16, #0x8]
    3258:      	add	x16, sp, #0xa0
    325c:      	movz	x17, #0x0, lsl #48
    3260:      	str	x17, [x16, #0x10]
    3264:      	add	x16, sp, #0xa0
    3268:      	str	x5, [x16, #0x18]
    326c:      	add	x16, sp, #0xa0
    3270:      	str	x3, [x16, #0x20]
    3274:      	ldr	x3, [x4, #0x8]
    3278:      	orr	x19, x3, xzr
    327c:      	cmp	x19, #0x0
    3280:      	b.le	0x37b8 <_stogir.adjacency.reverse-postorder+0x648>
    3284:      	cmp	x19, #0x0
    3288:      	b.ge	0x3294 <_stogir.adjacency.reverse-postorder+0x124>
    328c:      	movz	x3, #0x0, lsl #48
    3290:      	b	0x3298 <_stogir.adjacency.reverse-postorder+0x128>
    3294:      	mov	x3, x19
    3298:      	mov	x20, x8
    329c:      	mov	x21, x0
    32a0:      	add	x0, sp, #0x10
    32a4:      	mov	x22, x1
    32a8:      	mov	x1, x3
    32ac:      	mov	w23, w2
    32b0:      	bl	0x32b0 <_stogir.adjacency.reverse-postorder+0x140>
		00000000000032b0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    32b4:      	lsr	x0, x19, #0
    32b8:      	add	x16, sp, #0x10
    32bc:      	ldr	x1, [x16]
    32c0:      	mov	x2, x0
    32c4:      	mov	x0, x1
    32c8:      	movz	x1, #0x0, lsl #48
    32cc:      	bl	0x32cc <_stogir.adjacency.reverse-postorder+0x15c>
		00000000000032cc:  ARM64_RELOC_BRANCH26	_memset
    32d0:      	add	x16, sp, #0x10
    32d4:      	str	x19, [x16, #0x8]
    32d8:      	add	x16, sp, #0xd0
    32dc:      	movz	x17, #0x0, lsl #48
    32e0:      	str	x17, [x16]
    32e4:      	add	x16, sp, #0xd0
    32e8:      	movz	x17, #0x0, lsl #48
    32ec:      	str	x17, [x16, #0x8]
    32f0:      	add	x16, sp, #0xd0
    32f4:      	str	w23, [x16]
    32f8:      	add	x16, sp, #0xd0
    32fc:      	movz	x17, #0x0, lsl #48
    3300:      	str	x17, [x16, #0x8]
    3304:      	add	x16, sp, #0xd0
    3308:      	ldr	x19, [x16]
    330c:      	add	x16, sp, #0x40
    3310:      	ldr	x0, [x16, #0x8]
    3314:      	orr	x24, x0, xzr
    3318:      	add	x16, sp, #0x40
    331c:      	ldr	x0, [x16, #0x10]
    3320:      	cmp	x24, x0
    3324:      	b.lt	0x3348 <_stogir.adjacency.reverse-postorder+0x1d8>
    3328:      	cmp	x0, #0x0
    332c:      	b.ne	0x3338 <_stogir.adjacency.reverse-postorder+0x1c8>
    3330:      	mov	x0, #0x2                ; =2
    3334:      	b	0x333c <_stogir.adjacency.reverse-postorder+0x1cc>
    3338:      	lsl	x0, x0, #1
    333c:      	mov	x1, x0
    3340:      	add	x0, sp, #0x40
    3344:      	bl	0x3344 <_stogir.adjacency.reverse-postorder+0x1d4>
		0000000000003344:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    3348:      	sxtw	x23, w23
    334c:      	add	x0, x24, #0x1
    3350:      	add	x16, sp, #0x40
    3354:      	ldr	x1, [x16]
    3358:      	add	x1, x1, x24, lsl #4
    335c:      	str	x19, [x1]
    3360:      	movz	x17, #0x0, lsl #48
    3364:      	str	x17, [x1, #0x8]
    3368:      	add	x16, sp, #0x40
    336c:      	str	x0, [x16, #0x8]
    3370:      	add	x16, sp, #0x10
    3374:      	ldr	x0, [x16]
    3378:      	add	x0, x0, x23
    337c:      	mov	w17, #0x1               ; =1
    3380:      	strb	w17, [x0]
    3384:      	b	0x3408 <_stogir.adjacency.reverse-postorder+0x298>
    3388:      	lsl	x0, x0, #1
    338c:      	mov	x1, x0
    3390:      	add	x0, sp, #0x70
    3394:      	bl	0x3394 <_stogir.adjacency.reverse-postorder+0x224>
		0000000000003394:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3398:      	add	x0, x23, #0x1
    339c:      	add	x16, sp, #0x70
    33a0:      	ldr	x1, [x16]
    33a4:      	add	x1, x1, x23, lsl #2
    33a8:      	str	w19, [x1]
    33ac:      	add	x16, sp, #0x70
    33b0:      	str	x0, [x16, #0x8]
    33b4:      	add	x16, sp, #0x40
    33b8:      	ldr	x0, [x16, #0x8]
    33bc:      	cmp	x0, #0x0
    33c0:      	b.eq	0x3408 <_stogir.adjacency.reverse-postorder+0x298>
    33c4:      	sub	x0, x0, #0x1
    33c8:      	add	x16, sp, #0x40
    33cc:      	str	x0, [x16, #0x8]
    33d0:      	b	0x3408 <_stogir.adjacency.reverse-postorder+0x298>
    33d4:      	lsl	x0, x0, #1
    33d8:      	mov	x1, x0
    33dc:      	add	x0, sp, #0x40
    33e0:      	bl	0x33e0 <_stogir.adjacency.reverse-postorder+0x270>
		00000000000033e0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    33e4:      	add	x0, x23, #0x1
    33e8:      	add	x16, sp, #0x40
    33ec:      	ldr	x1, [x16]
    33f0:      	add	x1, x1, x23, lsl #4
    33f4:      	str	x19, [x1]
    33f8:      	movz	x17, #0x0, lsl #48
    33fc:      	str	x17, [x1, #0x8]
    3400:      	add	x16, sp, #0x40
    3404:      	str	x0, [x16, #0x8]
    3408:      	add	x16, sp, #0x40
    340c:      	ldr	x0, [x16, #0x8]
    3410:      	cmp	x0, #0x0
    3414:      	b.le	0x3534 <_stogir.adjacency.reverse-postorder+0x3c4>
    3418:      	add	x16, sp, #0x40
    341c:      	ldr	x1, [x16]
    3420:      	sub	x0, x0, #0x1
    3424:      	add	x2, x1, x0, lsl #4
    3428:      	ldr	x3, [x2]
    342c:      	orr	w19, w3, wzr
    3430:      	ldr	x2, [x2, #0x8]
    3434:      	sxtw	x4, w19
    3438:      	ldr	x5, [x22]
    343c:      	add	x4, x5, x4, lsl #4
    3440:      	ldr	x5, [x4]
    3444:      	ldr	x4, [x4, #0x8]
    3448:      	cmp	x2, x4
    344c:      	b.lt	0x347c <_stogir.adjacency.reverse-postorder+0x30c>
    3450:      	add	x16, sp, #0x70
    3454:      	ldr	x0, [x16, #0x8]
    3458:      	orr	x23, x0, xzr
    345c:      	add	x16, sp, #0x70
    3460:      	ldr	x0, [x16, #0x10]
    3464:      	cmp	x23, x0
    3468:      	b.lt	0x3398 <_stogir.adjacency.reverse-postorder+0x228>
    346c:      	cmp	x0, #0x0
    3470:      	b.ne	0x3388 <_stogir.adjacency.reverse-postorder+0x218>
    3474:      	mov	x0, #0x2                ; =2
    3478:      	b	0x338c <_stogir.adjacency.reverse-postorder+0x21c>
    347c:      	add	x4, x2, x5
    3480:      	add	x2, x2, #0x1
    3484:      	ldr	x5, [x22, #0x28]
    3488:      	add	x0, x1, x0, lsl #4
    348c:      	add	x1, x5, x4, lsl #3
    3490:      	ldr	x1, [x1]
    3494:      	ldr	x4, [x21, #0x50]
    3498:      	add	x1, x4, x1, lsl #4
    349c:      	ldr	x1, [x1]
    34a0:      	str	x3, [x0]
    34a4:      	lsr	x1, x1, #32
    34a8:      	str	x2, [x0, #0x8]
    34ac:      	sxtw	x0, w1
    34b0:      	add	x16, sp, #0x10
    34b4:      	ldr	x2, [x16]
    34b8:      	add	x3, x2, x0
    34bc:      	ldrb	w3, [x3]
    34c0:      	cmp	x3, #0x0
    34c4:      	b.ne	0x3408 <_stogir.adjacency.reverse-postorder+0x298>
    34c8:      	add	x0, x2, x0
    34cc:      	mov	w17, #0x1               ; =1
    34d0:      	strb	w17, [x0]
    34d4:      	add	x16, sp, #0xe0
    34d8:      	movz	x17, #0x0, lsl #48
    34dc:      	str	x17, [x16]
    34e0:      	add	x16, sp, #0xe0
    34e4:      	movz	x17, #0x0, lsl #48
    34e8:      	str	x17, [x16, #0x8]
    34ec:      	add	x16, sp, #0xe0
    34f0:      	str	w1, [x16]
    34f4:      	add	x16, sp, #0xe0
    34f8:      	movz	x17, #0x0, lsl #48
    34fc:      	str	x17, [x16, #0x8]
    3500:      	add	x16, sp, #0xe0
    3504:      	ldr	x19, [x16]
    3508:      	add	x16, sp, #0x40
    350c:      	ldr	x0, [x16, #0x8]
    3510:      	orr	x23, x0, xzr
    3514:      	add	x16, sp, #0x40
    3518:      	ldr	x0, [x16, #0x10]
    351c:      	cmp	x23, x0
    3520:      	b.lt	0x33e4 <_stogir.adjacency.reverse-postorder+0x274>
    3524:      	cmp	x0, #0x0
    3528:      	b.ne	0x33d4 <_stogir.adjacency.reverse-postorder+0x264>
    352c:      	mov	x0, #0x2                ; =2
    3530:      	b	0x33d8 <_stogir.adjacency.reverse-postorder+0x268>
    3534:      	add	x16, sp, #0x70
    3538:      	ldr	x0, [x16, #0x8]
    353c:      	orr	x19, x0, xzr
    3540:      	b	0x3574 <_stogir.adjacency.reverse-postorder+0x404>
    3544:      	nop
    3548:      	lsl	x0, x0, #1
    354c:      	mov	x1, x0
    3550:      	add	x0, sp, #0xa0
    3554:      	bl	0x3554 <_stogir.adjacency.reverse-postorder+0x3e4>
		0000000000003554:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3558:      	add	x0, x22, #0x1
    355c:      	add	x16, sp, #0xa0
    3560:      	ldr	x1, [x16]
    3564:      	add	x1, x1, x22, lsl #2
    3568:      	str	w21, [x1]
    356c:      	add	x16, sp, #0xa0
    3570:      	str	x0, [x16, #0x8]
    3574:      	cmp	x19, #0x0
    3578:      	b.le	0x35bc <_stogir.adjacency.reverse-postorder+0x44c>
    357c:      	sub	x19, x19, #0x1
    3580:      	add	x16, sp, #0x70
    3584:      	ldr	x0, [x16]
    3588:      	add	x0, x0, x19, lsl #2
    358c:      	ldr	w21, [x0]
    3590:      	add	x16, sp, #0xa0
    3594:      	ldr	x0, [x16, #0x8]
    3598:      	orr	x22, x0, xzr
    359c:      	add	x16, sp, #0xa0
    35a0:      	ldr	x0, [x16, #0x10]
    35a4:      	cmp	x22, x0
    35a8:      	b.lt	0x3558 <_stogir.adjacency.reverse-postorder+0x3e8>
    35ac:      	cmp	x0, #0x0
    35b0:      	b.ne	0x3548 <_stogir.adjacency.reverse-postorder+0x3d8>
    35b4:      	mov	x0, #0x2                ; =2
    35b8:      	b	0x354c <_stogir.adjacency.reverse-postorder+0x3dc>
    35bc:      	b	0x35cc <_stogir.adjacency.reverse-postorder+0x45c>
    35c0:      	sub	x0, x0, #0x1
    35c4:      	add	x16, sp, #0x10
    35c8:      	str	x0, [x16, #0x8]
    35cc:      	add	x16, sp, #0x10
    35d0:      	ldr	x0, [x16, #0x8]
    35d4:      	cmp	x0, #0x0
    35d8:      	b.ne	0x35c0 <_stogir.adjacency.reverse-postorder+0x450>
    35dc:      	add	x16, sp, #0x10
    35e0:      	orr	x0, x16, xzr
    35e4:      	add	x16, sp, #0x10
    35e8:      	ldr	x1, [x16, #0x10]
    35ec:      	cmp	x1, #0x0
    35f0:      	b.le	0x3620 <_stogir.adjacency.reverse-postorder+0x4b0>
    35f4:      	add	x0, x0, #0x18
    35f8:      	add	x16, sp, #0x10
    35fc:      	ldr	x2, [x16]
    3600:      	fmov	d31, x1
    3604:      	mov	x1, x2
    3608:      	fmov	x2, d31
    360c:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x320>
		000000000000360c:  ARM64_RELOC_PAGE21	l_stogir.412
    3610:      	ldr	x3, [x3]
		0000000000003610:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    3614:      	mov	x4, #0x1                ; =1
    3618:      	mov	x5, #0x1                ; =1
    361c:      	bl	0x361c <_stogir.adjacency.reverse-postorder+0x4ac>
		000000000000361c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3620:      	add	x16, sp, #0x10
    3624:      	movz	x17, #0x0, lsl #48
    3628:      	str	x17, [x16]
    362c:      	add	x16, sp, #0x10
    3630:      	movz	x17, #0x0, lsl #48
    3634:      	str	x17, [x16, #0x8]
    3638:      	add	x16, sp, #0x10
    363c:      	movz	x17, #0x0, lsl #48
    3640:      	str	x17, [x16, #0x10]
    3644:      	b	0x3654 <_stogir.adjacency.reverse-postorder+0x4e4>
    3648:      	sub	x0, x0, #0x1
    364c:      	add	x16, sp, #0x40
    3650:      	str	x0, [x16, #0x8]
    3654:      	add	x16, sp, #0x40
    3658:      	ldr	x0, [x16, #0x8]
    365c:      	cmp	x0, #0x0
    3660:      	b.ne	0x3648 <_stogir.adjacency.reverse-postorder+0x4d8>
    3664:      	add	x16, sp, #0x40
    3668:      	orr	x0, x16, xzr
    366c:      	add	x16, sp, #0x40
    3670:      	ldr	x1, [x16, #0x10]
    3674:      	cmp	x1, #0x0
    3678:      	b.le	0x36a8 <_stogir.adjacency.reverse-postorder+0x538>
    367c:      	add	x0, x0, #0x18
    3680:      	add	x16, sp, #0x40
    3684:      	ldr	x2, [x16]
    3688:      	fmov	d31, x1
    368c:      	mov	x1, x2
    3690:      	fmov	x2, d31
    3694:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x320>
		0000000000003694:  ARM64_RELOC_PAGE21	l_stogir.413
    3698:      	ldr	x3, [x3]
		0000000000003698:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    369c:      	mov	x4, #0x10               ; =16
    36a0:      	mov	x5, #0x8                ; =8
    36a4:      	bl	0x36a4 <_stogir.adjacency.reverse-postorder+0x534>
		00000000000036a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    36a8:      	add	x16, sp, #0x40
    36ac:      	movz	x17, #0x0, lsl #48
    36b0:      	str	x17, [x16]
    36b4:      	add	x16, sp, #0x40
    36b8:      	movz	x17, #0x0, lsl #48
    36bc:      	str	x17, [x16, #0x8]
    36c0:      	add	x16, sp, #0x40
    36c4:      	movz	x17, #0x0, lsl #48
    36c8:      	str	x17, [x16, #0x10]
    36cc:      	b	0x36dc <_stogir.adjacency.reverse-postorder+0x56c>
    36d0:      	sub	x0, x0, #0x1
    36d4:      	add	x16, sp, #0x70
    36d8:      	str	x0, [x16, #0x8]
    36dc:      	add	x16, sp, #0x70
    36e0:      	ldr	x0, [x16, #0x8]
    36e4:      	cmp	x0, #0x0
    36e8:      	b.ne	0x36d0 <_stogir.adjacency.reverse-postorder+0x560>
    36ec:      	add	x16, sp, #0x70
    36f0:      	orr	x0, x16, xzr
    36f4:      	add	x16, sp, #0x70
    36f8:      	ldr	x1, [x16, #0x10]
    36fc:      	cmp	x1, #0x0
    3700:      	b.le	0x3730 <_stogir.adjacency.reverse-postorder+0x5c0>
    3704:      	add	x0, x0, #0x18
    3708:      	add	x16, sp, #0x70
    370c:      	ldr	x2, [x16]
    3710:      	fmov	d31, x1
    3714:      	mov	x1, x2
    3718:      	fmov	x2, d31
    371c:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x320>
		000000000000371c:  ARM64_RELOC_PAGE21	l_stogir.414
    3720:      	ldr	x3, [x3]
		0000000000003720:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    3724:      	mov	x4, #0x4                ; =4
    3728:      	mov	x5, #0x4                ; =4
    372c:      	bl	0x372c <_stogir.adjacency.reverse-postorder+0x5bc>
		000000000000372c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3730:      	add	x16, sp, #0x70
    3734:      	movz	x17, #0x0, lsl #48
    3738:      	str	x17, [x16]
    373c:      	add	x16, sp, #0x70
    3740:      	movz	x17, #0x0, lsl #48
    3744:      	str	x17, [x16, #0x8]
    3748:      	add	x16, sp, #0x70
    374c:      	movz	x17, #0x0, lsl #48
    3750:      	str	x17, [x16, #0x10]
    3754:      	add	x16, sp, #0xa0
    3758:      	ldr	x0, [x16]
    375c:      	add	x16, sp, #0xa0
    3760:      	ldr	x1, [x16, #0x8]
    3764:      	add	x16, sp, #0xa0
    3768:      	ldr	x2, [x16, #0x10]
    376c:      	add	x16, sp, #0xa0
    3770:      	ldr	x3, [x16, #0x18]
    3774:      	add	x16, sp, #0xa0
    3778:      	ldr	x4, [x16, #0x20]
    377c:      	str	x0, [x20]
    3780:      	str	x1, [x20, #0x8]
    3784:      	str	x2, [x20, #0x10]
    3788:      	str	x3, [x20, #0x18]
    378c:      	str	x4, [x20, #0x20]
    3790:      	ldr	x19, [sp, #0xf0]
    3794:      	ldr	x20, [sp, #0xf8]
    3798:      	ldr	x21, [sp, #0x100]
    379c:      	ldr	x22, [sp, #0x108]
    37a0:      	ldr	x23, [sp, #0x110]
    37a4:      	ldr	x24, [sp, #0x118]
    37a8:      	ldr	x29, [sp]
    37ac:      	ldr	x30, [sp, #0x8]
    37b0:      	add	sp, sp, #0x120
    37b4:      	ret
    37b8:      	mov	x20, x8
    37bc:      	mov	x21, x0
    37c0:      	mov	x22, x1
    37c4:      	mov	w23, w2
    37c8:      	b	0x32b4 <_stogir.adjacency.reverse-postorder+0x144>
    37cc:      	udf	#0x0

00000000000037d0 <_stogir.dominators.build>:
    37d0:      	sub	sp, sp, #0xb0
    37d4:      	str	x29, [sp]
    37d8:      	str	x30, [sp, #0x8]
    37dc:      	mov	x29, sp
    37e0:      	str	x19, [sp, #0x70]
    37e4:      	str	x20, [sp, #0x78]
    37e8:      	str	x21, [sp, #0x80]
    37ec:      	str	x22, [sp, #0x88]
    37f0:      	str	x23, [sp, #0x90]
    37f4:      	str	x24, [sp, #0x98]
    37f8:      	str	x25, [sp, #0xa0]
    37fc:      	add	x19, x0, #0x28
    3800:      	ldr	x4, [x3]
    3804:      	ldr	x3, [x3, #0x8]
    3808:      	add	x16, sp, #0x10
    380c:      	movz	x17, #0x0, lsl #48
    3810:      	str	x17, [x16]
    3814:      	add	x16, sp, #0x10
    3818:      	movz	x17, #0x0, lsl #48
    381c:      	str	x17, [x16, #0x8]
    3820:      	add	x16, sp, #0x10
    3824:      	movz	x17, #0x0, lsl #48
    3828:      	str	x17, [x16, #0x10]
    382c:      	add	x16, sp, #0x10
    3830:      	str	x4, [x16, #0x18]
    3834:      	add	x16, sp, #0x10
    3838:      	str	x3, [x16, #0x20]
    383c:      	add	x16, sp, #0x40
    3840:      	movz	x17, #0x0, lsl #48
    3844:      	str	x17, [x16]
    3848:      	add	x16, sp, #0x40
    384c:      	movz	x17, #0x0, lsl #48
    3850:      	str	x17, [x16, #0x8]
    3854:      	add	x16, sp, #0x40
    3858:      	movz	x17, #0x0, lsl #48
    385c:      	str	x17, [x16, #0x10]
    3860:      	add	x16, sp, #0x40
    3864:      	str	x4, [x16, #0x18]
    3868:      	add	x16, sp, #0x40
    386c:      	str	x3, [x16, #0x20]
    3870:      	ldr	x3, [x19, #0x8]
    3874:      	orr	x20, x3, xzr
    3878:      	cmp	x20, #0x0
    387c:      	b.le	0x3c14 <_stogir.dominators.build+0x444>
    3880:      	cmp	x20, #0x0
    3884:      	b.ge	0x3890 <_stogir.dominators.build+0xc0>
    3888:      	movz	x3, #0x0, lsl #48
    388c:      	b	0x3894 <_stogir.dominators.build+0xc4>
    3890:      	mov	x3, x20
    3894:      	mov	x21, x8
    3898:      	mov	x22, x0
    389c:      	add	x0, sp, #0x10
    38a0:      	mov	x23, x1
    38a4:      	mov	x1, x3
    38a8:      	mov	x24, x2
    38ac:      	bl	0x38ac <_stogir.dominators.build+0xdc>
		00000000000038ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    38b0:      	lsl	x0, x20, #2
    38b4:      	add	x16, sp, #0x10
    38b8:      	ldr	x1, [x16]
    38bc:      	mov	x2, x0
    38c0:      	mov	x0, x1
    38c4:      	movz	x1, #0x0, lsl #48
    38c8:      	bl	0x38c8 <_stogir.dominators.build+0xf8>
		00000000000038c8:  ARM64_RELOC_BRANCH26	_memset
    38cc:      	add	x16, sp, #0x10
    38d0:      	str	x20, [x16, #0x8]
    38d4:      	movz	x20, #0x0, lsl #48
    38d8:      	b	0x3914 <_stogir.dominators.build+0x144>
    38dc:      	nop
    38e0:      	lsl	x0, x0, #1
    38e4:      	mov	x1, x0
    38e8:      	add	x0, sp, #0x40
    38ec:      	bl	0x38ec <_stogir.dominators.build+0x11c>
		00000000000038ec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    38f0:      	add	x20, x20, #0x1
    38f4:      	add	x0, x25, #0x1
    38f8:      	add	x16, sp, #0x40
    38fc:      	ldr	x1, [x16]
    3900:      	add	x1, x1, x25, lsl #3
    3904:      	movn	x17, #0x0, lsl #48
    3908:      	str	x17, [x1]
    390c:      	add	x16, sp, #0x40
    3910:      	str	x0, [x16, #0x8]
    3914:      	ldr	x0, [x19, #0x8]
    3918:      	cmp	x20, x0
    391c:      	b.ge	0x394c <_stogir.dominators.build+0x17c>
    3920:      	add	x16, sp, #0x40
    3924:      	ldr	x0, [x16, #0x8]
    3928:      	orr	x25, x0, xzr
    392c:      	add	x16, sp, #0x40
    3930:      	ldr	x0, [x16, #0x10]
    3934:      	cmp	x25, x0
    3938:      	b.lt	0x38f0 <_stogir.dominators.build+0x120>
    393c:      	cmp	x0, #0x0
    3940:      	b.ne	0x38e0 <_stogir.dominators.build+0x110>
    3944:      	mov	x0, #0x2                ; =2
    3948:      	b	0x38e4 <_stogir.dominators.build+0x114>
    394c:      	movz	x0, #0x0, lsl #48
    3950:      	b	0x3980 <_stogir.dominators.build+0x1b0>
    3954:      	nop
    3958:      	add	x1, x0, #0x1
    395c:      	ldr	x2, [x24]
    3960:      	add	x2, x2, x0, lsl #2
    3964:      	ldr	w2, [x2]
    3968:      	sxtw	x2, w2
    396c:      	add	x16, sp, #0x40
    3970:      	ldr	x3, [x16]
    3974:      	add	x2, x3, x2, lsl #3
    3978:      	str	x0, [x2]
    397c:      	mov	x0, x1
    3980:      	ldr	x1, [x24, #0x8]
    3984:      	cmp	x0, x1
    3988:      	b.lt	0x3958 <_stogir.dominators.build+0x188>
    398c:      	cmp	x1, #0x0
    3990:      	b.le	0x3b20 <_stogir.dominators.build+0x350>
    3994:      	ldr	x0, [x24]
    3998:      	ldr	w0, [x0]
    399c:      	sxtw	x1, w0
    39a0:      	add	x16, sp, #0x10
    39a4:      	ldr	x2, [x16]
    39a8:      	add	x1, x2, x1, lsl #2
    39ac:      	str	w0, [x1]
    39b0:      	b	0x3b14 <_stogir.dominators.build+0x344>
    39b4:      	nop
    39b8:      	add	x16, sp, #0x10
    39bc:      	ldr	x6, [x16]
    39c0:      	add	x6, x6, x11, lsl #2
    39c4:      	ldr	w6, [x6]
    39c8:      	add	x16, sp, #0x40
    39cc:      	ldr	x9, [x16]
    39d0:      	orr	x10, x9, xzr
    39d4:      	sxtw	x11, w6
    39d8:      	add	x9, x8, x9
    39dc:      	lsl	x12, x11, #3
    39e0:      	add	x10, x10, x11, lsl #3
    39e4:      	ldr	x10, [x10]
    39e8:      	ldr	x9, [x9]
    39ec:      	cmp	x10, x9
    39f0:      	b.gt	0x39b8 <_stogir.dominators.build+0x1e8>
    39f4:      	b	0x3a08 <_stogir.dominators.build+0x238>
    39f8:      	add	x16, sp, #0x10
    39fc:      	ldr	x7, [x16]
    3a00:      	add	x7, x7, x10, lsl #2
    3a04:      	ldr	w7, [x7]
    3a08:      	add	x16, sp, #0x40
    3a0c:      	ldr	x8, [x16]
    3a10:      	orr	x9, x8, xzr
    3a14:      	sxtw	x10, w7
    3a18:      	add	x8, x12, x8
    3a1c:      	add	x9, x9, x10, lsl #3
    3a20:      	ldr	x9, [x9]
    3a24:      	ldr	x8, [x8]
    3a28:      	cmp	x9, x8
    3a2c:      	b.gt	0x39f8 <_stogir.dominators.build+0x228>
    3a30:      	sxtw	x10, w6
    3a34:      	sxtw	x8, w7
    3a38:      	cmp	x10, x8
    3a3c:      	b.eq	0x3a48 <_stogir.dominators.build+0x278>
    3a40:      	lsl	x8, x8, #3
    3a44:      	b	0x39c8 <_stogir.dominators.build+0x1f8>
    3a48:      	orr	w6, w10, wzr
    3a4c:      	add	x5, x5, #0x1
    3a50:      	sxtw	x7, w6
    3a54:      	cmp	x5, x3
    3a58:      	b.ge	0x3aa8 <_stogir.dominators.build+0x2d8>
    3a5c:      	add	x8, x4, x5
    3a60:      	ldr	x9, [x23, #0x28]
    3a64:      	add	x8, x9, x8, lsl #3
    3a68:      	ldr	x8, [x8]
    3a6c:      	ldr	x9, [x22, #0x50]
    3a70:      	add	x8, x9, x8, lsl #4
    3a74:      	ldr	x8, [x8]
    3a78:      	add	x16, sp, #0x10
    3a7c:      	ldr	x9, [x16]
    3a80:      	sxtw	x10, w8
    3a84:      	add	x9, x9, x10, lsl #2
    3a88:      	ldr	w9, [x9]
    3a8c:      	sxtw	x9, w9
    3a90:      	cmp	x9, #0x0
    3a94:      	b.eq	0x3a4c <_stogir.dominators.build+0x27c>
    3a98:      	cmp	x7, #0x0
    3a9c:      	b.eq	0x3a48 <_stogir.dominators.build+0x278>
    3aa0:      	orr	w7, w8, wzr
    3aa4:      	b	0x3a30 <_stogir.dominators.build+0x260>
    3aa8:      	add	x16, sp, #0x10
    3aac:      	ldr	x3, [x16]
    3ab0:      	add	x4, x3, x2, lsl #2
    3ab4:      	ldr	w4, [x4]
    3ab8:      	sxtw	x4, w4
    3abc:      	cmp	x4, x7
    3ac0:      	b.eq	0x3ad0 <_stogir.dominators.build+0x300>
    3ac4:      	add	x1, x3, x2, lsl #2
    3ac8:      	str	w6, [x1]
    3acc:      	mov	x1, #0x1                ; =1
    3ad0:      	add	x0, x0, #0x1
    3ad4:      	ldr	x2, [x24, #0x8]
    3ad8:      	cmp	x0, x2
    3adc:      	b.ge	0x3b0c <_stogir.dominators.build+0x33c>
    3ae0:      	ldr	x2, [x24]
    3ae4:      	add	x2, x2, x0, lsl #2
    3ae8:      	ldr	w2, [x2]
    3aec:      	sxtw	x2, w2
    3af0:      	ldr	x3, [x23]
    3af4:      	add	x3, x3, x2, lsl #4
    3af8:      	ldr	x4, [x3]
    3afc:      	ldr	x3, [x3, #0x8]
    3b00:      	movz	x5, #0x0, lsl #48
    3b04:      	movz	w6, #0x0, lsl #16
    3b08:      	b	0x3a50 <_stogir.dominators.build+0x280>
    3b0c:      	cmp	x1, #0x0
    3b10:      	b.eq	0x3b20 <_stogir.dominators.build+0x350>
    3b14:      	mov	x0, #0x1                ; =1
    3b18:      	movz	x1, #0x0, lsl #48
    3b1c:      	b	0x3ad4 <_stogir.dominators.build+0x304>
    3b20:      	b	0x3b34 <_stogir.dominators.build+0x364>
    3b24:      	nop
    3b28:      	sub	x0, x0, #0x1
    3b2c:      	add	x16, sp, #0x40
    3b30:      	str	x0, [x16, #0x8]
    3b34:      	add	x16, sp, #0x40
    3b38:      	ldr	x0, [x16, #0x8]
    3b3c:      	cmp	x0, #0x0
    3b40:      	b.ne	0x3b28 <_stogir.dominators.build+0x358>
    3b44:      	add	x16, sp, #0x40
    3b48:      	orr	x0, x16, xzr
    3b4c:      	add	x16, sp, #0x40
    3b50:      	ldr	x1, [x16, #0x10]
    3b54:      	cmp	x1, #0x0
    3b58:      	b.le	0x3b88 <_stogir.dominators.build+0x3b8>
    3b5c:      	add	x0, x0, #0x18
    3b60:      	add	x16, sp, #0x40
    3b64:      	ldr	x2, [x16]
    3b68:      	fmov	d31, x1
    3b6c:      	mov	x1, x2
    3b70:      	fmov	x2, d31
    3b74:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x320>
		0000000000003b74:  ARM64_RELOC_PAGE21	l_stogir.415
    3b78:      	ldr	x3, [x3]
		0000000000003b78:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    3b7c:      	mov	x4, #0x8                ; =8
    3b80:      	mov	x5, #0x8                ; =8
    3b84:      	bl	0x3b84 <_stogir.dominators.build+0x3b4>
		0000000000003b84:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3b88:      	add	x16, sp, #0x40
    3b8c:      	movz	x17, #0x0, lsl #48
    3b90:      	str	x17, [x16]
    3b94:      	add	x16, sp, #0x40
    3b98:      	movz	x17, #0x0, lsl #48
    3b9c:      	str	x17, [x16, #0x8]
    3ba0:      	add	x16, sp, #0x40
    3ba4:      	movz	x17, #0x0, lsl #48
    3ba8:      	str	x17, [x16, #0x10]
    3bac:      	add	x16, sp, #0x10
    3bb0:      	ldr	x0, [x16]
    3bb4:      	add	x16, sp, #0x10
    3bb8:      	ldr	x1, [x16, #0x8]
    3bbc:      	add	x16, sp, #0x10
    3bc0:      	ldr	x2, [x16, #0x10]
    3bc4:      	add	x16, sp, #0x10
    3bc8:      	ldr	x3, [x16, #0x18]
    3bcc:      	add	x16, sp, #0x10
    3bd0:      	ldr	x4, [x16, #0x20]
    3bd4:      	str	x0, [x21]
    3bd8:      	str	x1, [x21, #0x8]
    3bdc:      	str	x2, [x21, #0x10]
    3be0:      	str	x3, [x21, #0x18]
    3be4:      	str	x4, [x21, #0x20]
    3be8:      	ldr	x19, [sp, #0x70]
    3bec:      	ldr	x20, [sp, #0x78]
    3bf0:      	ldr	x21, [sp, #0x80]
    3bf4:      	ldr	x22, [sp, #0x88]
    3bf8:      	ldr	x23, [sp, #0x90]
    3bfc:      	ldr	x24, [sp, #0x98]
    3c00:      	ldr	x25, [sp, #0xa0]
    3c04:      	ldr	x29, [sp]
    3c08:      	ldr	x30, [sp, #0x8]
    3c0c:      	add	sp, sp, #0xb0
    3c10:      	ret
    3c14:      	mov	x21, x8
    3c18:      	mov	x22, x0
    3c1c:      	mov	x23, x1
    3c20:      	mov	x24, x2
    3c24:      	b	0x38b0 <_stogir.dominators.build+0xe0>

0000000000003c28 <_stogir.loops.depths>:
    3c28:      	sub	sp, sp, #0x1d0
    3c2c:      	str	x29, [sp]
    3c30:      	str	x30, [sp, #0x8]
    3c34:      	mov	x29, sp
    3c38:      	str	x19, [sp, #0x180]
    3c3c:      	str	x20, [sp, #0x188]
    3c40:      	str	x21, [sp, #0x190]
    3c44:      	str	x22, [sp, #0x198]
    3c48:      	str	x23, [sp, #0x1a0]
    3c4c:      	str	x24, [sp, #0x1a8]
    3c50:      	str	x25, [sp, #0x1b0]
    3c54:      	str	x26, [sp, #0x1b8]
    3c58:      	str	x27, [sp, #0x1c0]
    3c5c:      	str	x28, [sp, #0x1c8]
    3c60:      	add	x19, x0, #0x28
    3c64:      	mov	x20, x8
    3c68:      	add	x8, sp, #0x60
    3c6c:      	mov	x21, x0
    3c70:      	mov	x0, x2
    3c74:      	mov	x22, x1
    3c78:      	mov	x1, x3
    3c7c:      	mov	x23, x2
    3c80:      	mov	x24, x3
    3c84:      	bl	0x3c84 <_stogir.loops.depths+0x5c>
		0000000000003c84:  ARM64_RELOC_BRANCH26	_stogir.dominators.build-index
    3c88:      	add	x16, sp, #0x60
    3c8c:      	ldr	x0, [x16]
    3c90:      	add	x16, sp, #0x10
    3c94:      	str	x0, [x16]
    3c98:      	add	x16, sp, #0x60
    3c9c:      	ldr	x0, [x16, #0x8]
    3ca0:      	add	x16, sp, #0x10
    3ca4:      	str	x0, [x16, #0x8]
    3ca8:      	add	x16, sp, #0x60
    3cac:      	ldr	x0, [x16, #0x10]
    3cb0:      	add	x16, sp, #0x10
    3cb4:      	str	x0, [x16, #0x10]
    3cb8:      	add	x16, sp, #0x60
    3cbc:      	ldr	x0, [x16, #0x18]
    3cc0:      	add	x16, sp, #0x10
    3cc4:      	str	x0, [x16, #0x18]
    3cc8:      	add	x16, sp, #0x60
    3ccc:      	ldr	x0, [x16, #0x20]
    3cd0:      	add	x16, sp, #0x10
    3cd4:      	str	x0, [x16, #0x20]
    3cd8:      	add	x16, sp, #0x60
    3cdc:      	ldr	x0, [x16, #0x28]
    3ce0:      	add	x16, sp, #0x10
    3ce4:      	str	x0, [x16, #0x28]
    3ce8:      	add	x16, sp, #0x60
    3cec:      	ldr	x0, [x16, #0x30]
    3cf0:      	add	x16, sp, #0x10
    3cf4:      	str	x0, [x16, #0x30]
    3cf8:      	add	x16, sp, #0x60
    3cfc:      	ldr	x0, [x16, #0x38]
    3d00:      	add	x16, sp, #0x10
    3d04:      	str	x0, [x16, #0x38]
    3d08:      	add	x16, sp, #0x60
    3d0c:      	ldr	x0, [x16, #0x40]
    3d10:      	add	x16, sp, #0x10
    3d14:      	str	x0, [x16, #0x40]
    3d18:      	add	x16, sp, #0x60
    3d1c:      	ldr	x0, [x16, #0x48]
    3d20:      	add	x16, sp, #0x10
    3d24:      	str	x0, [x16, #0x48]
    3d28:      	ldr	x0, [x24]
    3d2c:      	ldr	x1, [x24, #0x8]
    3d30:      	add	x16, sp, #0xb0
    3d34:      	movz	x17, #0x0, lsl #48
    3d38:      	str	x17, [x16]
    3d3c:      	add	x16, sp, #0xb0
    3d40:      	movz	x17, #0x0, lsl #48
    3d44:      	str	x17, [x16, #0x8]
    3d48:      	add	x16, sp, #0xb0
    3d4c:      	movz	x17, #0x0, lsl #48
    3d50:      	str	x17, [x16, #0x10]
    3d54:      	add	x16, sp, #0xb0
    3d58:      	str	x0, [x16, #0x18]
    3d5c:      	add	x16, sp, #0xb0
    3d60:      	str	x1, [x16, #0x20]
    3d64:      	add	x16, sp, #0xe0
    3d68:      	movz	x17, #0x0, lsl #48
    3d6c:      	str	x17, [x16]
    3d70:      	add	x16, sp, #0xe0
    3d74:      	movz	x17, #0x0, lsl #48
    3d78:      	str	x17, [x16, #0x8]
    3d7c:      	add	x16, sp, #0xe0
    3d80:      	movz	x17, #0x0, lsl #48
    3d84:      	str	x17, [x16, #0x10]
    3d88:      	add	x16, sp, #0xe0
    3d8c:      	str	x0, [x16, #0x18]
    3d90:      	add	x16, sp, #0xe0
    3d94:      	str	x1, [x16, #0x20]
    3d98:      	add	x16, sp, #0x110
    3d9c:      	movz	x17, #0x0, lsl #48
    3da0:      	str	x17, [x16]
    3da4:      	add	x16, sp, #0x110
    3da8:      	movz	x17, #0x0, lsl #48
    3dac:      	str	x17, [x16, #0x8]
    3db0:      	add	x16, sp, #0x110
    3db4:      	movz	x17, #0x0, lsl #48
    3db8:      	str	x17, [x16, #0x10]
    3dbc:      	add	x16, sp, #0x110
    3dc0:      	str	x0, [x16, #0x18]
    3dc4:      	add	x16, sp, #0x110
    3dc8:      	str	x1, [x16, #0x20]
    3dcc:      	ldr	x0, [x19, #0x8]
    3dd0:      	orr	x24, x0, xzr
    3dd4:      	add	x16, sp, #0xb0
    3dd8:      	ldr	x0, [x16, #0x8]
    3ddc:      	orr	x25, x0, xzr
    3de0:      	add	x16, sp, #0xb0
    3de4:      	ldr	x0, [x16, #0x10]
    3de8:      	add	x26, x25, x24
    3dec:      	cmp	x26, x0
    3df0:      	b.le	0x3e24 <_stogir.loops.depths+0x1fc>
    3df4:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    3df8:      	cmp	x0, x17
    3dfc:      	b.gt	0x3e08 <_stogir.loops.depths+0x1e0>
    3e00:      	lsl	x0, x0, #1
    3e04:      	b	0x3e0c <_stogir.loops.depths+0x1e4>
    3e08:      	mov	x0, x26
    3e0c:      	cmp	x0, x26
    3e10:      	b.gt	0x3e18 <_stogir.loops.depths+0x1f0>
    3e14:      	mov	x0, x26
    3e18:      	mov	x1, x0
    3e1c:      	add	x0, sp, #0xb0
    3e20:      	bl	0x3e20 <_stogir.loops.depths+0x1f8>
		0000000000003e20:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3e24:      	lsl	x0, x24, #2
    3e28:      	add	x16, sp, #0xb0
    3e2c:      	ldr	x1, [x16]
    3e30:      	add	x1, x1, x25, lsl #2
    3e34:      	mov	x2, x0
    3e38:      	mov	x0, x1
    3e3c:      	movz	x1, #0x0, lsl #48
    3e40:      	bl	0x3e40 <_stogir.loops.depths+0x218>
		0000000000003e40:  ARM64_RELOC_BRANCH26	_memset
    3e44:      	add	x16, sp, #0xb0
    3e48:      	str	x26, [x16, #0x8]
    3e4c:      	ldr	x0, [x19, #0x8]
    3e50:      	mov	x1, x0
    3e54:      	add	x0, sp, #0xe0
    3e58:      	bl	0x3e58 <_stogir.loops.depths+0x230>
		0000000000003e58:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    3e5c:      	ldr	x0, [x21]
    3e60:      	ldr	x1, [x21, #0x8]
    3e64:      	orr	x19, x0, xzr
    3e68:      	orr	x24, x1, xzr
    3e6c:      	movz	x25, #0x0, lsl #48
    3e70:      	b	0x3fd4 <_stogir.loops.depths+0x3ac>
    3e74:      	lsl	x2, x2, #1
    3e78:      	str	x21, [sp, #0x170]
    3e7c:      	mov	w21, w0
    3e80:      	add	x0, sp, #0x110
    3e84:      	str	x22, [sp, #0x178]
    3e88:      	mov	x22, x1
    3e8c:      	mov	x1, x2
    3e90:      	bl	0x3e90 <_stogir.loops.depths+0x268>
		0000000000003e90:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3e94:      	add	x0, x22, #0x1
    3e98:      	add	x16, sp, #0x110
    3e9c:      	ldr	x1, [x16]
    3ea0:      	add	x1, x1, x22, lsl #2
    3ea4:      	str	w21, [x1]
    3ea8:      	add	x16, sp, #0x110
    3eac:      	str	x0, [x16, #0x8]
    3eb0:      	b	0x3ec0 <_stogir.loops.depths+0x298>
    3eb4:      	nop
    3eb8:      	str	x21, [sp, #0x170]
    3ebc:      	str	x22, [sp, #0x178]
    3ec0:      	add	x28, x28, #0x1
    3ec4:      	ldr	x21, [sp, #0x170]
    3ec8:      	ldr	x22, [sp, #0x178]
    3ecc:      	cmp	x28, x25
    3ed0:      	b.ge	0x4418 <_stogir.loops.depths+0x7f0>
    3ed4:      	add	x0, x24, x28
    3ed8:      	ldr	x1, [x22, #0x28]
    3edc:      	add	x0, x1, x0, lsl #3
    3ee0:      	ldr	x0, [x0]
    3ee4:      	ldr	x1, [x21, #0x50]
    3ee8:      	add	x0, x1, x0, lsl #4
    3eec:      	ldr	x0, [x0]
    3ef0:      	ldr	x1, [x23]
    3ef4:      	sxtw	x2, w0
    3ef8:      	add	x1, x1, x2, lsl #2
    3efc:      	ldr	w1, [x1]
    3f00:      	sxtw	x1, w1
    3f04:      	cmp	x1, #0x0
    3f08:      	b.eq	0x3eb8 <_stogir.loops.depths+0x290>
    3f0c:      	add	x16, sp, #0xe0
    3f10:      	ldr	x1, [x16]
    3f14:      	add	x3, x1, x2, lsl #2
    3f18:      	ldr	w3, [x3]
    3f1c:      	sxtw	x3, w3
    3f20:      	cmp	x3, x26
    3f24:      	b.eq	0x4424 <_stogir.loops.depths+0x7fc>
    3f28:      	add	x1, x1, x2, lsl #2
    3f2c:      	str	w27, [x1]
    3f30:      	add	x16, sp, #0xb0
    3f34:      	ldr	x1, [x16]
    3f38:      	orr	x3, x1, xzr
    3f3c:      	add	x3, x3, x2, lsl #2
    3f40:      	add	x1, x1, x2, lsl #2
    3f44:      	ldr	w2, [x3]
    3f48:      	add	w2, w2, #0x1
    3f4c:      	str	w2, [x1]
    3f50:      	add	x16, sp, #0x110
    3f54:      	ldr	x1, [x16, #0x8]
    3f58:      	add	x16, sp, #0x110
    3f5c:      	ldr	x2, [x16, #0x10]
    3f60:      	cmp	x1, x2
    3f64:      	b.lt	0x4430 <_stogir.loops.depths+0x808>
    3f68:      	cmp	x2, #0x0
    3f6c:      	b.ne	0x3e74 <_stogir.loops.depths+0x24c>
    3f70:      	mov	x2, #0x2                ; =2
    3f74:      	b	0x3e78 <_stogir.loops.depths+0x250>
    3f78:      	add	x19, x19, #0x1
    3f7c:      	ldr	x21, [sp, #0x170]
    3f80:      	ldr	x22, [sp, #0x178]
    3f84:      	add	x16, sp, #0x110
    3f88:      	ldr	x0, [x16, #0x8]
    3f8c:      	cmp	x19, x0
    3f90:      	b.ge	0x4444 <_stogir.loops.depths+0x81c>
    3f94:      	add	x16, sp, #0x110
    3f98:      	ldr	x0, [x16]
    3f9c:      	add	x0, x0, x19, lsl #2
    3fa0:      	ldr	w0, [x0]
    3fa4:      	sxtw	x0, w0
    3fa8:      	ldr	x1, [x22]
    3fac:      	add	x0, x1, x0, lsl #4
    3fb0:      	ldr	x24, [x0]
    3fb4:      	ldr	x25, [x0, #0x8]
    3fb8:      	movz	x28, #0x0, lsl #48
    3fbc:      	b	0x3ecc <_stogir.loops.depths+0x2a4>
    3fc0:      	ldr	x21, [sp, #0x170]
    3fc4:      	ldr	x22, [sp, #0x178]
    3fc8:      	ldr	x24, [sp, #0x160]
    3fcc:      	ldr	x19, [sp, #0x158]
    3fd0:      	ldr	x25, [sp, #0x168]
    3fd4:      	cmp	x25, x24
    3fd8:      	b.ge	0x3ffc <_stogir.loops.depths+0x3d4>
    3fdc:      	add	x0, x25, #0x1
    3fe0:      	add	x1, x19, x25, lsl #2
    3fe4:      	ldr	w1, [x1]
    3fe8:      	movn	w17, #0x0, lsl #16
    3fec:      	and	w1, w1, w17
    3ff0:      	mov	x25, x0
    3ff4:      	mov	w0, #0x1                ; =1
    3ff8:      	b	0x4004 <_stogir.loops.depths+0x3dc>
    3ffc:      	movz	w0, #0x0, lsl #16
    4000:      	movz	w1, #0x0, lsl #16
    4004:      	ubfx	x0, x0, #0, #32
    4008:      	lsr	x16, x0, #0
    400c:      	cmp	x16, #0x1
    4010:      	b.eq	0x402c <_stogir.loops.depths+0x404>
    4014:      	b.lo	0x401c <_stogir.loops.depths+0x3f4>
    4018:      	b	0x4030 <_stogir.loops.depths+0x408>
    401c:      	cmp	x16, #0x0
    4020:      	b.eq	0x4028 <_stogir.loops.depths+0x400>
    4024:      	b	0x4030 <_stogir.loops.depths+0x408>
    4028:      	b	0x4034 <_stogir.loops.depths+0x40c>
    402c:      	b	0x41cc <_stogir.loops.depths+0x5a4>
    4030:      	b	0x43c0 <_stogir.loops.depths+0x798>
    4034:      	add	x0, sp, #0x10
    4038:      	bl	0x4038 <_stogir.loops.depths+0x410>
		0000000000004038:  ARM64_RELOC_BRANCH26	_stogir.dominators.release-index!
    403c:      	b	0x404c <_stogir.loops.depths+0x424>
    4040:      	sub	x0, x0, #0x1
    4044:      	add	x16, sp, #0xe0
    4048:      	str	x0, [x16, #0x8]
    404c:      	add	x16, sp, #0xe0
    4050:      	ldr	x0, [x16, #0x8]
    4054:      	cmp	x0, #0x0
    4058:      	b.ne	0x4040 <_stogir.loops.depths+0x418>
    405c:      	add	x16, sp, #0xe0
    4060:      	orr	x0, x16, xzr
    4064:      	add	x16, sp, #0xe0
    4068:      	ldr	x1, [x16, #0x10]
    406c:      	cmp	x1, #0x0
    4070:      	b.le	0x40a0 <_stogir.loops.depths+0x478>
    4074:      	add	x0, x0, #0x18
    4078:      	add	x16, sp, #0xe0
    407c:      	ldr	x2, [x16]
    4080:      	fmov	d31, x1
    4084:      	mov	x1, x2
    4088:      	fmov	x2, d31
    408c:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3d8>
		000000000000408c:  ARM64_RELOC_PAGE21	l_stogir.416
    4090:      	ldr	x3, [x3]
		0000000000004090:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    4094:      	mov	x4, #0x4                ; =4
    4098:      	mov	x5, #0x4                ; =4
    409c:      	bl	0x409c <_stogir.loops.depths+0x474>
		000000000000409c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    40a0:      	add	x16, sp, #0xe0
    40a4:      	movz	x17, #0x0, lsl #48
    40a8:      	str	x17, [x16]
    40ac:      	add	x16, sp, #0xe0
    40b0:      	movz	x17, #0x0, lsl #48
    40b4:      	str	x17, [x16, #0x8]
    40b8:      	add	x16, sp, #0xe0
    40bc:      	movz	x17, #0x0, lsl #48
    40c0:      	str	x17, [x16, #0x10]
    40c4:      	b	0x40d4 <_stogir.loops.depths+0x4ac>
    40c8:      	sub	x0, x0, #0x1
    40cc:      	add	x16, sp, #0x110
    40d0:      	str	x0, [x16, #0x8]
    40d4:      	add	x16, sp, #0x110
    40d8:      	ldr	x0, [x16, #0x8]
    40dc:      	cmp	x0, #0x0
    40e0:      	b.ne	0x40c8 <_stogir.loops.depths+0x4a0>
    40e4:      	add	x16, sp, #0x110
    40e8:      	orr	x0, x16, xzr
    40ec:      	add	x16, sp, #0x110
    40f0:      	ldr	x1, [x16, #0x10]
    40f4:      	cmp	x1, #0x0
    40f8:      	b.le	0x4128 <_stogir.loops.depths+0x500>
    40fc:      	add	x0, x0, #0x18
    4100:      	add	x16, sp, #0x110
    4104:      	ldr	x2, [x16]
    4108:      	fmov	d31, x1
    410c:      	mov	x1, x2
    4110:      	fmov	x2, d31
    4114:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3d8>
		0000000000004114:  ARM64_RELOC_PAGE21	l_stogir.416
    4118:      	ldr	x3, [x3]
		0000000000004118:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    411c:      	mov	x4, #0x4                ; =4
    4120:      	mov	x5, #0x4                ; =4
    4124:      	bl	0x4124 <_stogir.loops.depths+0x4fc>
		0000000000004124:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4128:      	add	x16, sp, #0x110
    412c:      	movz	x17, #0x0, lsl #48
    4130:      	str	x17, [x16]
    4134:      	add	x16, sp, #0x110
    4138:      	movz	x17, #0x0, lsl #48
    413c:      	str	x17, [x16, #0x8]
    4140:      	add	x16, sp, #0x110
    4144:      	movz	x17, #0x0, lsl #48
    4148:      	str	x17, [x16, #0x10]
    414c:      	add	x16, sp, #0xb0
    4150:      	ldr	x0, [x16]
    4154:      	add	x16, sp, #0xb0
    4158:      	ldr	x1, [x16, #0x8]
    415c:      	add	x16, sp, #0xb0
    4160:      	ldr	x2, [x16, #0x10]
    4164:      	add	x16, sp, #0xb0
    4168:      	ldr	x3, [x16, #0x18]
    416c:      	add	x16, sp, #0xb0
    4170:      	ldr	x4, [x16, #0x20]
    4174:      	str	x0, [x20]
    4178:      	str	x1, [x20, #0x8]
    417c:      	str	x2, [x20, #0x10]
    4180:      	str	x3, [x20, #0x18]
    4184:      	str	x4, [x20, #0x20]
    4188:      	ldr	x19, [sp, #0x180]
    418c:      	ldr	x20, [sp, #0x188]
    4190:      	ldr	x21, [sp, #0x190]
    4194:      	ldr	x22, [sp, #0x198]
    4198:      	ldr	x23, [sp, #0x1a0]
    419c:      	ldr	x24, [sp, #0x1a8]
    41a0:      	ldr	x25, [sp, #0x1b0]
    41a4:      	ldr	x26, [sp, #0x1b8]
    41a8:      	ldr	x27, [sp, #0x1c0]
    41ac:      	ldr	x28, [sp, #0x1c8]
    41b0:      	ldr	x29, [sp]
    41b4:      	ldr	x30, [sp, #0x8]
    41b8:      	add	sp, sp, #0x1d0
    41bc:      	ret
    41c0:      	sub	x0, x0, #0x1
    41c4:      	add	x16, sp, #0x110
    41c8:      	str	x0, [x16, #0x8]
    41cc:      	add	x16, sp, #0x110
    41d0:      	ldr	x0, [x16, #0x8]
    41d4:      	cmp	x0, #0x0
    41d8:      	b.ne	0x41c0 <_stogir.loops.depths+0x598>
    41dc:      	sxtw	x26, w1
    41e0:      	orr	w27, w1, wzr
    41e4:      	lsl	x28, x26, #2
    41e8:      	cmp	x26, #0x0
    41ec:      	cset	w0, gt
    41f0:      	add	x16, sp, #0xe0
    41f4:      	ldr	x1, [x16]
    41f8:      	add	x1, x1, x26, lsl #2
    41fc:      	str	w27, [x1]
    4200:      	ldr	x1, [x22]
    4204:      	add	x1, x1, x26, lsl #4
    4208:      	ldr	x2, [x1]
    420c:      	ldr	x1, [x1, #0x8]
    4210:      	movz	x3, #0x0, lsl #48
    4214:      	movz	x4, #0x0, lsl #48
    4218:      	b	0x4290 <_stogir.loops.depths+0x668>
    421c:      	lsl	x6, x6, #1
    4220:      	str	w0, [sp, #0x140]
    4224:      	add	x0, sp, #0x110
    4228:      	str	x2, [sp, #0x148]
    422c:      	str	x1, [sp, #0x150]
    4230:      	mov	x1, x6
    4234:      	str	x19, [sp, #0x158]
    4238:      	mov	x19, x3
    423c:      	str	x24, [sp, #0x160]
    4240:      	mov	w24, w5
    4244:      	str	x25, [sp, #0x168]
    4248:      	mov	x25, x4
    424c:      	bl	0x424c <_stogir.loops.depths+0x624>
		000000000000424c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4250:      	add	x0, x25, #0x1
    4254:      	add	x16, sp, #0x110
    4258:      	ldr	x1, [x16]
    425c:      	add	x1, x1, x25, lsl #2
    4260:      	str	w24, [x1]
    4264:      	add	x16, sp, #0x110
    4268:      	str	x0, [x16, #0x8]
    426c:      	mov	x4, #0x1                ; =1
    4270:      	add	x19, x19, #0x1
    4274:      	ldr	x2, [sp, #0x148]
    4278:      	ldr	x1, [sp, #0x150]
    427c:      	ldr	w0, [sp, #0x140]
    4280:      	ldr	x24, [sp, #0x160]
    4284:      	ldr	x25, [sp, #0x168]
    4288:      	mov	x3, x19
    428c:      	ldr	x19, [sp, #0x158]
    4290:      	cmp	x3, x1
    4294:      	b.ge	0x4450 <_stogir.loops.depths+0x828>
    4298:      	add	x5, x2, x3
    429c:      	ldr	x6, [x22, #0x28]
    42a0:      	add	x5, x6, x5, lsl #3
    42a4:      	ldr	x5, [x5]
    42a8:      	ldr	x6, [x21, #0x50]
    42ac:      	add	x5, x6, x5, lsl #4
    42b0:      	ldr	x5, [x5]
    42b4:      	uxtb	w16, w0
    42b8:      	cmp	w16, wzr
    42bc:      	b.eq	0x4460 <_stogir.loops.depths+0x838>
    42c0:      	sxtw	x6, w5
    42c4:      	cmp	x6, #0x0
    42c8:      	b.le	0x4480 <_stogir.loops.depths+0x858>
    42cc:      	add	x16, sp, #0x10
    42d0:      	ldr	x7, [x16, #0x8]
    42d4:      	cmp	x26, x7
    42d8:      	b.ge	0x44a0 <_stogir.loops.depths+0x878>
    42dc:      	cmp	x6, x7
    42e0:      	b.ge	0x44c0 <_stogir.loops.depths+0x898>
    42e4:      	add	x16, sp, #0x10
    42e8:      	ldr	x7, [x16]
    42ec:      	add	x8, x28, x7
    42f0:      	ldr	w8, [x8]
    42f4:      	sxtw	x8, w8
    42f8:      	cmp	x8, #0x0
    42fc:      	b.le	0x44e0 <_stogir.loops.depths+0x8b8>
    4300:      	lsl	x9, x6, #2
    4304:      	add	x6, x7, x6, lsl #2
    4308:      	ldr	w6, [x6]
    430c:      	sxtw	x6, w6
    4310:      	cmp	x6, #0x0
    4314:      	b.le	0x4500 <_stogir.loops.depths+0x8d8>
    4318:      	cmp	x8, x6
    431c:      	b.gt	0x4520 <_stogir.loops.depths+0x8f8>
    4320:      	add	x16, sp, #0x10
    4324:      	ldr	x6, [x16, #0x28]
    4328:      	orr	x7, x6, xzr
    432c:      	add	x7, x28, x7
    4330:      	add	x6, x9, x6
    4334:      	ldr	w7, [x7]
    4338:      	sxtw	x7, w7
    433c:      	ldr	w6, [x6]
    4340:      	sxtw	x6, w6
    4344:      	cmp	x7, x6
    4348:      	b.lt	0x4540 <_stogir.loops.depths+0x918>
    434c:      	cmp	x4, #0x0
    4350:      	b.ne	0x4374 <_stogir.loops.depths+0x74c>
    4354:      	add	x16, sp, #0xb0
    4358:      	ldr	x4, [x16]
    435c:      	orr	x6, x4, xzr
    4360:      	add	x6, x28, x6
    4364:      	add	x4, x28, x4
    4368:      	ldr	w6, [x6]
    436c:      	add	w6, w6, #0x1
    4370:      	str	w6, [x4]
    4374:      	add	x16, sp, #0xe0
    4378:      	ldr	x4, [x16]
    437c:      	add	x6, x9, x4
    4380:      	ldr	w6, [x6]
    4384:      	sxtw	x6, w6
    4388:      	cmp	x6, x26
    438c:      	b.ne	0x43c8 <_stogir.loops.depths+0x7a0>
    4390:      	str	x2, [sp, #0x148]
    4394:      	str	x1, [sp, #0x150]
    4398:      	str	w0, [sp, #0x140]
    439c:      	str	x24, [sp, #0x160]
    43a0:      	str	x19, [sp, #0x158]
    43a4:      	mov	x19, x3
    43a8:      	str	x25, [sp, #0x168]
    43ac:      	b	0x426c <_stogir.loops.depths+0x644>
    43b0:      	cmp	x4, #0x0
    43b4:      	b.eq	0x4560 <_stogir.loops.depths+0x938>
    43b8:      	movz	x19, #0x0, lsl #48
    43bc:      	b	0x3f84 <_stogir.loops.depths+0x35c>
    43c0:      	brk	#0
    43c4:      	b	0x43c0 <_stogir.loops.depths+0x798>
    43c8:      	add	x4, x9, x4
    43cc:      	str	w27, [x4]
    43d0:      	add	x16, sp, #0xb0
    43d4:      	ldr	x4, [x16]
    43d8:      	orr	x6, x4, xzr
    43dc:      	add	x6, x9, x6
    43e0:      	add	x4, x9, x4
    43e4:      	ldr	w6, [x6]
    43e8:      	add	w6, w6, #0x1
    43ec:      	str	w6, [x4]
    43f0:      	add	x16, sp, #0x110
    43f4:      	ldr	x4, [x16, #0x8]
    43f8:      	add	x16, sp, #0x110
    43fc:      	ldr	x6, [x16, #0x10]
    4400:      	cmp	x4, x6
    4404:      	b.lt	0x456c <_stogir.loops.depths+0x944>
    4408:      	cmp	x6, #0x0
    440c:      	b.ne	0x421c <_stogir.loops.depths+0x5f4>
    4410:      	mov	x6, #0x2                ; =2
    4414:      	b	0x4220 <_stogir.loops.depths+0x5f8>
    4418:      	str	x21, [sp, #0x170]
    441c:      	str	x22, [sp, #0x178]
    4420:      	b	0x3f78 <_stogir.loops.depths+0x350>
    4424:      	str	x21, [sp, #0x170]
    4428:      	str	x22, [sp, #0x178]
    442c:      	b	0x3ec0 <_stogir.loops.depths+0x298>
    4430:      	str	x21, [sp, #0x170]
    4434:      	str	x22, [sp, #0x178]
    4438:      	mov	w21, w0
    443c:      	mov	x22, x1
    4440:      	b	0x3e94 <_stogir.loops.depths+0x26c>
    4444:      	str	x21, [sp, #0x170]
    4448:      	str	x22, [sp, #0x178]
    444c:      	b	0x3fc0 <_stogir.loops.depths+0x398>
    4450:      	str	x24, [sp, #0x160]
    4454:      	str	x19, [sp, #0x158]
    4458:      	str	x25, [sp, #0x168]
    445c:      	b	0x43b0 <_stogir.loops.depths+0x788>
    4460:      	str	x2, [sp, #0x148]
    4464:      	str	x1, [sp, #0x150]
    4468:      	str	w0, [sp, #0x140]
    446c:      	str	x24, [sp, #0x160]
    4470:      	str	x19, [sp, #0x158]
    4474:      	mov	x19, x3
    4478:      	str	x25, [sp, #0x168]
    447c:      	b	0x4270 <_stogir.loops.depths+0x648>
    4480:      	str	x2, [sp, #0x148]
    4484:      	str	x1, [sp, #0x150]
    4488:      	str	w0, [sp, #0x140]
    448c:      	str	x24, [sp, #0x160]
    4490:      	str	x19, [sp, #0x158]
    4494:      	mov	x19, x3
    4498:      	str	x25, [sp, #0x168]
    449c:      	b	0x4270 <_stogir.loops.depths+0x648>
    44a0:      	str	x2, [sp, #0x148]
    44a4:      	str	x1, [sp, #0x150]
    44a8:      	str	w0, [sp, #0x140]
    44ac:      	str	x24, [sp, #0x160]
    44b0:      	str	x19, [sp, #0x158]
    44b4:      	mov	x19, x3
    44b8:      	str	x25, [sp, #0x168]
    44bc:      	b	0x4270 <_stogir.loops.depths+0x648>
    44c0:      	str	x2, [sp, #0x148]
    44c4:      	str	x1, [sp, #0x150]
    44c8:      	str	w0, [sp, #0x140]
    44cc:      	str	x24, [sp, #0x160]
    44d0:      	str	x19, [sp, #0x158]
    44d4:      	mov	x19, x3
    44d8:      	str	x25, [sp, #0x168]
    44dc:      	b	0x4270 <_stogir.loops.depths+0x648>
    44e0:      	str	x2, [sp, #0x148]
    44e4:      	str	x1, [sp, #0x150]
    44e8:      	str	w0, [sp, #0x140]
    44ec:      	str	x24, [sp, #0x160]
    44f0:      	str	x19, [sp, #0x158]
    44f4:      	mov	x19, x3
    44f8:      	str	x25, [sp, #0x168]
    44fc:      	b	0x4270 <_stogir.loops.depths+0x648>
    4500:      	str	x2, [sp, #0x148]
    4504:      	str	x1, [sp, #0x150]
    4508:      	str	w0, [sp, #0x140]
    450c:      	str	x24, [sp, #0x160]
    4510:      	str	x19, [sp, #0x158]
    4514:      	mov	x19, x3
    4518:      	str	x25, [sp, #0x168]
    451c:      	b	0x4270 <_stogir.loops.depths+0x648>
    4520:      	str	x2, [sp, #0x148]
    4524:      	str	x1, [sp, #0x150]
    4528:      	str	w0, [sp, #0x140]
    452c:      	str	x24, [sp, #0x160]
    4530:      	str	x19, [sp, #0x158]
    4534:      	mov	x19, x3
    4538:      	str	x25, [sp, #0x168]
    453c:      	b	0x4270 <_stogir.loops.depths+0x648>
    4540:      	str	x2, [sp, #0x148]
    4544:      	str	x1, [sp, #0x150]
    4548:      	str	w0, [sp, #0x140]
    454c:      	str	x24, [sp, #0x160]
    4550:      	str	x19, [sp, #0x158]
    4554:      	mov	x19, x3
    4558:      	str	x25, [sp, #0x168]
    455c:      	b	0x4270 <_stogir.loops.depths+0x648>
    4560:      	str	x21, [sp, #0x170]
    4564:      	str	x22, [sp, #0x178]
    4568:      	b	0x3fc0 <_stogir.loops.depths+0x398>
    456c:      	str	x2, [sp, #0x148]
    4570:      	str	x1, [sp, #0x150]
    4574:      	str	w0, [sp, #0x140]
    4578:      	str	x24, [sp, #0x160]
    457c:      	mov	w24, w5
    4580:      	str	x19, [sp, #0x158]
    4584:      	mov	x19, x3
    4588:      	str	x25, [sp, #0x168]
    458c:      	mov	x25, x4
    4590:      	b	0x4250 <_stogir.loops.depths+0x628>

0000000000004594 <_stogir.liveness.mark>:
    4594:      	sub	sp, sp, #0x140
    4598:      	str	x29, [sp]
    459c:      	str	x30, [sp, #0x8]
    45a0:      	mov	x29, sp
    45a4:      	str	x19, [sp, #0xe8]
    45a8:      	str	x20, [sp, #0xf0]
    45ac:      	str	x21, [sp, #0xf8]
    45b0:      	str	x22, [sp, #0x100]
    45b4:      	str	x23, [sp, #0x108]
    45b8:      	str	x24, [sp, #0x110]
    45bc:      	str	x25, [sp, #0x118]
    45c0:      	str	x26, [sp, #0x120]
    45c4:      	str	x27, [sp, #0x128]
    45c8:      	str	x28, [sp, #0x130]
    45cc:      	add	x19, x0, #0x78
    45d0:      	mov	x20, x8
    45d4:      	add	x8, sp, #0x40
    45d8:      	mov	x21, x0
    45dc:      	mov	x0, x3
    45e0:      	mov	x22, x1
    45e4:      	mov	x23, x2
    45e8:      	mov	x24, x3
    45ec:      	bl	0x45ec <_stogir.liveness.mark+0x58>
		00000000000045ec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__bool
    45f0:      	add	x16, sp, #0x40
    45f4:      	ldr	x0, [x16]
    45f8:      	add	x16, sp, #0x10
    45fc:      	str	x0, [x16]
    4600:      	add	x16, sp, #0x40
    4604:      	ldr	x0, [x16, #0x8]
    4608:      	add	x16, sp, #0x10
    460c:      	str	x0, [x16, #0x8]
    4610:      	add	x16, sp, #0x40
    4614:      	ldr	x0, [x16, #0x10]
    4618:      	add	x16, sp, #0x10
    461c:      	str	x0, [x16, #0x10]
    4620:      	add	x16, sp, #0x40
    4624:      	ldr	x0, [x16, #0x18]
    4628:      	add	x16, sp, #0x10
    462c:      	str	x0, [x16, #0x18]
    4630:      	add	x16, sp, #0x40
    4634:      	ldr	x0, [x16, #0x20]
    4638:      	add	x16, sp, #0x10
    463c:      	str	x0, [x16, #0x20]
    4640:      	add	x8, sp, #0xa0
    4644:      	mov	x0, x24
    4648:      	bl	0x4648 <_stogir.liveness.mark+0xb4>
		0000000000004648:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    464c:      	add	x16, sp, #0xa0
    4650:      	ldr	x0, [x16]
    4654:      	add	x16, sp, #0x70
    4658:      	str	x0, [x16]
    465c:      	add	x16, sp, #0xa0
    4660:      	ldr	x0, [x16, #0x8]
    4664:      	add	x16, sp, #0x70
    4668:      	str	x0, [x16, #0x8]
    466c:      	add	x16, sp, #0xa0
    4670:      	ldr	x0, [x16, #0x10]
    4674:      	add	x16, sp, #0x70
    4678:      	str	x0, [x16, #0x10]
    467c:      	add	x16, sp, #0xa0
    4680:      	ldr	x0, [x16, #0x18]
    4684:      	add	x16, sp, #0x70
    4688:      	str	x0, [x16, #0x18]
    468c:      	add	x16, sp, #0xa0
    4690:      	ldr	x0, [x16, #0x20]
    4694:      	add	x16, sp, #0x70
    4698:      	str	x0, [x16, #0x20]
    469c:      	ldr	x0, [x21, #0x8]
    46a0:      	mov	x1, x0
    46a4:      	add	x0, sp, #0x10
    46a8:      	bl	0x46a8 <_stogir.liveness.mark+0x114>
		00000000000046a8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool
    46ac:      	movz	x24, #0x0, lsl #48
    46b0:      	cmp	x24, x23
    46b4:      	b.ge	0x46d8 <_stogir.liveness.mark+0x144>
    46b8:      	add	x0, x24, #0x1
    46bc:      	add	x1, x22, x24, lsl #2
    46c0:      	ldr	w1, [x1]
    46c4:      	movn	w17, #0x0, lsl #16
    46c8:      	and	w25, w1, w17
    46cc:      	mov	x24, x0
    46d0:      	mov	w0, #0x1                ; =1
    46d4:      	b	0x46e0 <_stogir.liveness.mark+0x14c>
    46d8:      	movz	w0, #0x0, lsl #16
    46dc:      	movz	w25, #0x0, lsl #16
    46e0:      	ubfx	x0, x0, #0, #32
    46e4:      	lsr	x16, x0, #0
    46e8:      	cmp	x16, #0x1
    46ec:      	b.eq	0x4708 <_stogir.liveness.mark+0x174>
    46f0:      	b.lo	0x46f8 <_stogir.liveness.mark+0x164>
    46f4:      	b	0x470c <_stogir.liveness.mark+0x178>
    46f8:      	cmp	x16, #0x0
    46fc:      	b.eq	0x4704 <_stogir.liveness.mark+0x170>
    4700:      	b	0x470c <_stogir.liveness.mark+0x178>
    4704:      	b	0x479c <_stogir.liveness.mark+0x208>
    4708:      	b	0x4710 <_stogir.liveness.mark+0x17c>
    470c:      	b	0x4b14 <_stogir.liveness.mark+0x580>
    4710:      	sxtw	x0, w25
    4714:      	cmp	x0, #0x0
    4718:      	b.le	0x46b0 <_stogir.liveness.mark+0x11c>
    471c:      	ldr	x1, [x21, #0x8]
    4720:      	cmp	x0, x1
    4724:      	b.ge	0x46b0 <_stogir.liveness.mark+0x11c>
    4728:      	ldr	x1, [x19, #0x8]
    472c:      	cmp	x0, x1
    4730:      	b.ge	0x46b0 <_stogir.liveness.mark+0x11c>
    4734:      	ldr	x1, [x21, #0x78]
    4738:      	add	x1, x1, x0, lsl #2
    473c:      	ldr	w1, [x1]
    4740:      	sxtw	x1, w1
    4744:      	cmp	x1, #0x0
    4748:      	b.lt	0x46b0 <_stogir.liveness.mark+0x11c>
    474c:      	add	x16, sp, #0x10
    4750:      	ldr	x1, [x16]
    4754:      	add	x2, x1, x0
    4758:      	ldrb	w2, [x2]
    475c:      	cmp	x2, #0x0
    4760:      	b.ne	0x46b0 <_stogir.liveness.mark+0x11c>
    4764:      	add	x0, x1, x0
    4768:      	mov	w17, #0x1               ; =1
    476c:      	strb	w17, [x0]
    4770:      	add	x16, sp, #0x70
    4774:      	ldr	x0, [x16, #0x8]
    4778:      	orr	x26, x0, xzr
    477c:      	add	x16, sp, #0x70
    4780:      	ldr	x0, [x16, #0x10]
    4784:      	cmp	x26, x0
    4788:      	b.lt	0x4af4 <_stogir.liveness.mark+0x560>
    478c:      	cmp	x0, #0x0
    4790:      	b.ne	0x4ae4 <_stogir.liveness.mark+0x550>
    4794:      	mov	x0, #0x2                ; =2
    4798:      	b	0x4ae8 <_stogir.liveness.mark+0x554>
    479c:      	movz	x22, #0x0, lsl #48
    47a0:      	b	0x49c0 <_stogir.liveness.mark+0x42c>
    47a4:      	movz	w2, #0x0, lsl #16
    47a8:      	movz	w1, #0x0, lsl #16
    47ac:      	b	0x493c <_stogir.liveness.mark+0x3a8>
    47b0:      	sub	w1, w1, #0x1
    47b4:      	lsl	w1, w1, #2
    47b8:      	ubfx	x1, x1, #0, #32
    47bc:      	lsr	x1, x3, x1
    47c0:      	and	w1, w1, #0xf
    47c4:      	b	0x4860 <_stogir.liveness.mark+0x2cc>
    47c8:      	lsl	x3, x3, #1
    47cc:      	str	x19, [sp, #0xd0]
    47d0:      	mov	x19, x0
    47d4:      	add	x0, sp, #0x70
    47d8:      	str	x21, [sp, #0xd8]
    47dc:      	mov	w21, w1
    47e0:      	mov	x1, x3
    47e4:      	str	x23, [sp, #0xe0]
    47e8:      	mov	x23, x2
    47ec:      	bl	0x47ec <_stogir.liveness.mark+0x258>
		00000000000047ec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    47f0:      	add	x0, x23, #0x1
    47f4:      	add	x16, sp, #0x70
    47f8:      	ldr	x1, [x16]
    47fc:      	add	x1, x1, x23, lsl #2
    4800:      	str	w21, [x1]
    4804:      	add	x16, sp, #0x70
    4808:      	str	x0, [x16, #0x8]
    480c:      	add	x0, x19, #0x1
    4810:      	sxtw	x19, w0
    4814:      	ldr	x21, [sp, #0xd8]
    4818:      	ldr	x23, [sp, #0xe0]
    481c:      	mov	x0, x19
    4820:      	ldr	x19, [sp, #0xd0]
    4824:      	cmp	x0, x28
    4828:      	b.gt	0x4b1c <_stogir.liveness.mark+0x588>
    482c:      	orr	w1, w0, wzr
    4830:      	sxtw	x2, w1
    4834:      	uxtb	w16, w26
    4838:      	cmp	w16, wzr
    483c:      	b.eq	0x4864 <_stogir.liveness.mark+0x2d0>
    4840:      	ldr	w3, [x27]
    4844:      	cmp	x2, #0x0
    4848:      	b.le	0x485c <_stogir.liveness.mark+0x2c8>
    484c:      	cmp	x2, #0x4
    4850:      	b.le	0x47b0 <_stogir.liveness.mark+0x21c>
    4854:      	mov	w1, #0x4                ; =4
    4858:      	b	0x47b4 <_stogir.liveness.mark+0x220>
    485c:      	movz	w1, #0x0, lsl #16
    4860:      	b	0x4868 <_stogir.liveness.mark+0x2d4>
    4864:      	movz	w1, #0x0, lsl #16
    4868:      	ubfx	x1, x1, #0, #32
    486c:      	cmp	x1, #0xf
    4870:      	b.hs	0x4b28 <_stogir.liveness.mark+0x594>
    4874:      	mov	x16, #0x1               ; =1
    4878:      	lsl	x1, x16, x1
    487c:      	mov	w17, #0x5e1c            ; =24092
    4880:      	and	w1, w1, w17
    4884:      	ubfx	x1, x1, #0, #32
    4888:      	cmp	x1, #0x0
    488c:      	b.eq	0x4b3c <_stogir.liveness.mark+0x5a8>
    4890:      	uxtb	w16, w25
    4894:      	cmp	w16, wzr
    4898:      	b.ne	0x4934 <_stogir.liveness.mark+0x3a0>
    489c:      	ldr	x1, [x21, #0x8]
    48a0:      	cmp	x23, x1
    48a4:      	b.ge	0x4934 <_stogir.liveness.mark+0x3a0>
    48a8:      	ldr	x1, [x19, #0x8]
    48ac:      	cmp	x23, x1
    48b0:      	b.ge	0x4934 <_stogir.liveness.mark+0x3a0>
    48b4:      	ldr	x1, [x21, #0x78]
    48b8:      	add	x1, x24, x1
    48bc:      	ldr	w1, [x1]
    48c0:      	sxtw	x1, w1
    48c4:      	cmp	x1, #0x0
    48c8:      	b.lt	0x4934 <_stogir.liveness.mark+0x3a0>
    48cc:      	cmp	x2, #0x1
    48d0:      	b.lt	0x47a4 <_stogir.liveness.mark+0x210>
    48d4:      	ldr	x1, [x21, #0x78]
    48d8:      	add	x1, x24, x1
    48dc:      	ldr	w1, [x1]
    48e0:      	sxtw	x1, w1
    48e4:      	cmp	x2, x1
    48e8:      	b.gt	0x47a4 <_stogir.liveness.mark+0x210>
    48ec:      	ldr	x1, [x21]
    48f0:      	asr	x16, x2, #63
    48f4:      	lsr	x16, x16, #62
    48f8:      	add	x3, x2, x16
    48fc:      	asr	x3, x3, #2
    4900:      	asr	x16, x2, #63
    4904:      	lsr	x16, x16, #62
    4908:      	add	x2, x2, x16
    490c:      	and	x2, x2, #0x3
    4910:      	sub	x2, x2, x16
    4914:      	add	x3, x3, x23
    4918:      	add	x1, x1, x3, lsl #4
    491c:      	add	x1, x1, x2, lsl #2
    4920:      	ldr	w1, [x1]
    4924:      	movn	w17, #0x0, lsl #16
    4928:      	and	w1, w1, w17
    492c:      	mov	w2, #0x1                ; =1
    4930:      	b	0x47ac <_stogir.liveness.mark+0x218>
    4934:      	movz	w2, #0x0, lsl #16
    4938:      	movz	w1, #0x0, lsl #16
    493c:      	ubfx	x2, x2, #0, #32
    4940:      	lsr	x16, x2, #0
    4944:      	cmp	x16, #0x1
    4948:      	b.eq	0x4974 <_stogir.liveness.mark+0x3e0>
    494c:      	b.lo	0x4954 <_stogir.liveness.mark+0x3c0>
    4950:      	b	0x4978 <_stogir.liveness.mark+0x3e4>
    4954:      	cmp	x16, #0x0
    4958:      	b.eq	0x4960 <_stogir.liveness.mark+0x3cc>
    495c:      	b	0x4978 <_stogir.liveness.mark+0x3e4>
    4960:      	str	x21, [sp, #0xd8]
    4964:      	str	x23, [sp, #0xe0]
    4968:      	str	x19, [sp, #0xd0]
    496c:      	mov	x19, x0
    4970:      	b	0x480c <_stogir.liveness.mark+0x278>
    4974:      	b	0x497c <_stogir.liveness.mark+0x3e8>
    4978:      	b	0x4adc <_stogir.liveness.mark+0x548>
    497c:      	sxtw	x2, w1
    4980:      	cmp	x2, #0x0
    4984:      	b.le	0x4b50 <_stogir.liveness.mark+0x5bc>
    4988:      	add	x16, sp, #0x10
    498c:      	ldr	x3, [x16]
    4990:      	add	x2, x2, x3
    4994:      	ldrb	w3, [x2]
    4998:      	cmp	x3, #0x0
    499c:      	b.eq	0x4a30 <_stogir.liveness.mark+0x49c>
    49a0:      	str	x21, [sp, #0xd8]
    49a4:      	str	x23, [sp, #0xe0]
    49a8:      	str	x19, [sp, #0xd0]
    49ac:      	mov	x19, x0
    49b0:      	b	0x480c <_stogir.liveness.mark+0x278>
    49b4:      	add	x22, x22, #0x1
    49b8:      	ldr	x21, [sp, #0xd8]
    49bc:      	ldr	x19, [sp, #0xd0]
    49c0:      	add	x16, sp, #0x70
    49c4:      	ldr	x0, [x16, #0x8]
    49c8:      	cmp	x22, x0
    49cc:      	b.ge	0x4a60 <_stogir.liveness.mark+0x4cc>
    49d0:      	add	x16, sp, #0x70
    49d4:      	ldr	x0, [x16]
    49d8:      	add	x0, x0, x22, lsl #2
    49dc:      	ldr	w0, [x0]
    49e0:      	sxtw	x23, w0
    49e4:      	ldr	x0, [x21]
    49e8:      	lsl	x24, x23, #2
    49ec:      	cmp	x23, #0x0
    49f0:      	cset	w25, le
    49f4:      	add	x0, x0, x23, lsl #4
    49f8:      	ldr	x0, [x0]
    49fc:      	ldr	x1, [x21, #0x78]
    4a00:      	uxtb	w0, w0
    4a04:      	add	x1, x1, x23, lsl #2
    4a08:      	cmp	x0, #0x83
    4a0c:      	cset	w26, lt
    4a10:      	adrp	x16, 0x4000 <_stogir.loops.depths+0x3d8>
		0000000000004a10:  ARM64_RELOC_PAGE21	l_stogir.417
    4a14:      	ldr	x16, [x16]
		0000000000004a14:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    4a18:      	add	x0, x16, x0, lsl #2
    4a1c:      	ldr	w1, [x1]
    4a20:      	orr	x27, x0, xzr
    4a24:      	sxtw	x28, w1
    4a28:      	mov	x0, #0x1                ; =1
    4a2c:      	b	0x4824 <_stogir.liveness.mark+0x290>
    4a30:      	mov	w17, #0x1               ; =1
    4a34:      	strb	w17, [x2]
    4a38:      	add	x16, sp, #0x70
    4a3c:      	ldr	x2, [x16, #0x8]
    4a40:      	add	x16, sp, #0x70
    4a44:      	ldr	x3, [x16, #0x10]
    4a48:      	cmp	x2, x3
    4a4c:      	b.lt	0x4b64 <_stogir.liveness.mark+0x5d0>
    4a50:      	cmp	x3, #0x0
    4a54:      	b.ne	0x47c8 <_stogir.liveness.mark+0x234>
    4a58:      	mov	x3, #0x2                ; =2
    4a5c:      	b	0x47cc <_stogir.liveness.mark+0x238>
    4a60:      	add	x0, sp, #0x70
    4a64:      	bl	0x4a64 <_stogir.liveness.mark+0x4d0>
		0000000000004a64:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    4a68:      	add	x16, sp, #0x10
    4a6c:      	ldr	x0, [x16]
    4a70:      	add	x16, sp, #0x10
    4a74:      	ldr	x1, [x16, #0x8]
    4a78:      	add	x16, sp, #0x10
    4a7c:      	ldr	x2, [x16, #0x10]
    4a80:      	add	x16, sp, #0x10
    4a84:      	ldr	x3, [x16, #0x18]
    4a88:      	add	x16, sp, #0x10
    4a8c:      	ldr	x4, [x16, #0x20]
    4a90:      	str	x0, [x20]
    4a94:      	str	x1, [x20, #0x8]
    4a98:      	str	x2, [x20, #0x10]
    4a9c:      	str	x3, [x20, #0x18]
    4aa0:      	str	x4, [x20, #0x20]
    4aa4:      	ldr	x19, [sp, #0xe8]
    4aa8:      	ldr	x20, [sp, #0xf0]
    4aac:      	ldr	x21, [sp, #0xf8]
    4ab0:      	ldr	x22, [sp, #0x100]
    4ab4:      	ldr	x23, [sp, #0x108]
    4ab8:      	ldr	x24, [sp, #0x110]
    4abc:      	ldr	x25, [sp, #0x118]
    4ac0:      	ldr	x26, [sp, #0x120]
    4ac4:      	ldr	x27, [sp, #0x128]
    4ac8:      	ldr	x28, [sp, #0x130]
    4acc:      	ldr	x29, [sp]
    4ad0:      	ldr	x30, [sp, #0x8]
    4ad4:      	add	sp, sp, #0x140
    4ad8:      	ret
    4adc:      	brk	#0
    4ae0:      	b	0x4adc <_stogir.liveness.mark+0x548>
    4ae4:      	lsl	x0, x0, #1
    4ae8:      	mov	x1, x0
    4aec:      	add	x0, sp, #0x70
    4af0:      	bl	0x4af0 <_stogir.liveness.mark+0x55c>
		0000000000004af0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4af4:      	add	x0, x26, #0x1
    4af8:      	add	x16, sp, #0x70
    4afc:      	ldr	x1, [x16]
    4b00:      	add	x1, x1, x26, lsl #2
    4b04:      	str	w25, [x1]
    4b08:      	add	x16, sp, #0x70
    4b0c:      	str	x0, [x16, #0x8]
    4b10:      	b	0x46b0 <_stogir.liveness.mark+0x11c>
    4b14:      	brk	#0
    4b18:      	b	0x4b14 <_stogir.liveness.mark+0x580>
    4b1c:      	str	x21, [sp, #0xd8]
    4b20:      	str	x19, [sp, #0xd0]
    4b24:      	b	0x49b4 <_stogir.liveness.mark+0x420>
    4b28:      	str	x21, [sp, #0xd8]
    4b2c:      	str	x23, [sp, #0xe0]
    4b30:      	str	x19, [sp, #0xd0]
    4b34:      	mov	x19, x0
    4b38:      	b	0x480c <_stogir.liveness.mark+0x278>
    4b3c:      	str	x21, [sp, #0xd8]
    4b40:      	str	x23, [sp, #0xe0]
    4b44:      	str	x19, [sp, #0xd0]
    4b48:      	mov	x19, x0
    4b4c:      	b	0x480c <_stogir.liveness.mark+0x278>
    4b50:      	str	x21, [sp, #0xd8]
    4b54:      	str	x23, [sp, #0xe0]
    4b58:      	str	x19, [sp, #0xd0]
    4b5c:      	mov	x19, x0
    4b60:      	b	0x480c <_stogir.liveness.mark+0x278>
    4b64:      	str	x21, [sp, #0xd8]
    4b68:      	str	x23, [sp, #0xe0]
    4b6c:      	str	x19, [sp, #0xd0]
    4b70:      	mov	x19, x0
    4b74:      	mov	x23, x2
    4b78:      	mov	w21, w1
    4b7c:      	b	0x47f0 <_stogir.liveness.mark+0x25c>

0000000000004b80 <_stogir.uses.build>:
    4b80:      	sub	sp, sp, #0xc0
    4b84:      	str	x29, [sp]
    4b88:      	str	x30, [sp, #0x8]
    4b8c:      	mov	x29, sp
    4b90:      	str	x19, [sp, #0x90]
    4b94:      	str	x20, [sp, #0x98]
    4b98:      	str	x21, [sp, #0xa0]
    4b9c:      	str	x22, [sp, #0xa8]
    4ba0:      	str	x23, [sp, #0xb0]
    4ba4:      	str	x24, [sp, #0xb8]
    4ba8:      	ldr	x2, [x1]
    4bac:      	ldr	x1, [x1, #0x8]
    4bb0:      	add	x16, sp, #0x10
    4bb4:      	movz	x17, #0x0, lsl #48
    4bb8:      	str	x17, [x16]
    4bbc:      	add	x16, sp, #0x10
    4bc0:      	movz	x17, #0x0, lsl #48
    4bc4:      	str	x17, [x16, #0x8]
    4bc8:      	add	x16, sp, #0x10
    4bcc:      	movz	x17, #0x0, lsl #48
    4bd0:      	str	x17, [x16, #0x10]
    4bd4:      	add	x16, sp, #0x10
    4bd8:      	str	x2, [x16, #0x18]
    4bdc:      	add	x16, sp, #0x10
    4be0:      	str	x1, [x16, #0x20]
    4be4:      	add	x16, sp, #0x10
    4be8:      	movz	x17, #0x0, lsl #48
    4bec:      	str	x17, [x16, #0x28]
    4bf0:      	add	x16, sp, #0x10
    4bf4:      	movz	x17, #0x0, lsl #48
    4bf8:      	str	x17, [x16, #0x30]
    4bfc:      	add	x16, sp, #0x10
    4c00:      	movz	x17, #0x0, lsl #48
    4c04:      	str	x17, [x16, #0x38]
    4c08:      	add	x16, sp, #0x10
    4c0c:      	str	x2, [x16, #0x40]
    4c10:      	add	x16, sp, #0x10
    4c14:      	str	x1, [x16, #0x48]
    4c18:      	add	x16, sp, #0x60
    4c1c:      	movz	x17, #0x0, lsl #48
    4c20:      	str	x17, [x16]
    4c24:      	add	x16, sp, #0x60
    4c28:      	movz	x17, #0x0, lsl #48
    4c2c:      	str	x17, [x16, #0x8]
    4c30:      	add	x16, sp, #0x60
    4c34:      	movz	x17, #0x0, lsl #48
    4c38:      	str	x17, [x16, #0x10]
    4c3c:      	add	x16, sp, #0x60
    4c40:      	str	x2, [x16, #0x18]
    4c44:      	add	x16, sp, #0x60
    4c48:      	str	x1, [x16, #0x20]
    4c4c:      	ldr	x1, [x0, #0x8]
    4c50:      	orr	x19, x1, xzr
    4c54:      	cmp	x19, #0x0
    4c58:      	b.le	0x5074 <_stogir.uses.build+0x4f4>
    4c5c:      	cmp	x19, #0x0
    4c60:      	b.ge	0x4c6c <_stogir.uses.build+0xec>
    4c64:      	movz	x1, #0x0, lsl #48
    4c68:      	b	0x4c70 <_stogir.uses.build+0xf0>
    4c6c:      	mov	x1, x19
    4c70:      	mov	x20, x8
    4c74:      	mov	x21, x0
    4c78:      	add	x0, sp, #0x10
    4c7c:      	bl	0x4c7c <_stogir.uses.build+0xfc>
		0000000000004c7c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range
    4c80:      	lsl	x0, x19, #4
    4c84:      	add	x16, sp, #0x10
    4c88:      	ldr	x1, [x16]
    4c8c:      	mov	x2, x0
    4c90:      	mov	x0, x1
    4c94:      	movz	x1, #0x0, lsl #48
    4c98:      	bl	0x4c98 <_stogir.uses.build+0x118>
		0000000000004c98:  ARM64_RELOC_BRANCH26	_memset
    4c9c:      	add	x16, sp, #0x10
    4ca0:      	str	x19, [x16, #0x8]
    4ca4:      	ldr	x0, [x21, #0x8]
    4ca8:      	orr	x19, x0, xzr
    4cac:      	add	x16, sp, #0x60
    4cb0:      	ldr	x0, [x16, #0x8]
    4cb4:      	orr	x22, x0, xzr
    4cb8:      	add	x16, sp, #0x60
    4cbc:      	ldr	x0, [x16, #0x10]
    4cc0:      	add	x23, x22, x19
    4cc4:      	cmp	x23, x0
    4cc8:      	b.le	0x4cfc <_stogir.uses.build+0x17c>
    4ccc:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    4cd0:      	cmp	x0, x17
    4cd4:      	b.gt	0x4ce0 <_stogir.uses.build+0x160>
    4cd8:      	lsl	x0, x0, #1
    4cdc:      	b	0x4ce4 <_stogir.uses.build+0x164>
    4ce0:      	mov	x0, x23
    4ce4:      	cmp	x0, x23
    4ce8:      	b.gt	0x4cf0 <_stogir.uses.build+0x170>
    4cec:      	mov	x0, x23
    4cf0:      	mov	x1, x0
    4cf4:      	add	x0, sp, #0x60
    4cf8:      	bl	0x4cf8 <_stogir.uses.build+0x178>
		0000000000004cf8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    4cfc:      	lsl	x0, x19, #3
    4d00:      	add	x16, sp, #0x60
    4d04:      	ldr	x1, [x16]
    4d08:      	add	x1, x1, x22, lsl #3
    4d0c:      	mov	x2, x0
    4d10:      	mov	x0, x1
    4d14:      	movz	x1, #0x0, lsl #48
    4d18:      	bl	0x4d18 <_stogir.uses.build+0x198>
		0000000000004d18:  ARM64_RELOC_BRANCH26	_memset
    4d1c:      	add	x16, sp, #0x60
    4d20:      	str	x23, [x16, #0x8]
    4d24:      	mov	x0, #0x1                ; =1
    4d28:      	b	0x4e28 <_stogir.uses.build+0x2a8>
    4d2c:      	sub	w4, w4, #0x1
    4d30:      	lsl	w4, w4, #2
    4d34:      	ubfx	x4, x4, #0, #32
    4d38:      	lsr	x4, x1, x4
    4d3c:      	and	w4, w4, #0xf
    4d40:      	b	0x4d4c <_stogir.uses.build+0x1cc>
    4d44:      	nop
    4d48:      	movz	w4, #0x0, lsl #16
    4d4c:      	ubfx	x4, x4, #0, #32
    4d50:      	cmp	x4, #0xf
    4d54:      	b.hs	0x4de0 <_stogir.uses.build+0x260>
    4d58:      	mov	x16, #0x1               ; =1
    4d5c:      	lsl	x4, x16, x4
    4d60:      	mov	w17, #0x5e1c            ; =24092
    4d64:      	and	w4, w4, w17
    4d68:      	ubfx	x4, x4, #0, #32
    4d6c:      	cmp	x4, #0x0
    4d70:      	b.eq	0x4de0 <_stogir.uses.build+0x260>
    4d74:      	ldr	x4, [x21]
    4d78:      	asr	x16, x5, #63
    4d7c:      	lsr	x16, x16, #62
    4d80:      	add	x6, x5, x16
    4d84:      	asr	x6, x6, #2
    4d88:      	asr	x16, x5, #63
    4d8c:      	lsr	x16, x16, #62
    4d90:      	add	x5, x5, x16
    4d94:      	and	x5, x5, #0x3
    4d98:      	sub	x5, x5, x16
    4d9c:      	add	x6, x6, x0
    4da0:      	add	x4, x4, x6, lsl #4
    4da4:      	add	x4, x4, x5, lsl #2
    4da8:      	ldr	w4, [x4]
    4dac:      	sxtw	x4, w4
    4db0:      	cmp	x4, #0x0
    4db4:      	b.le	0x4de0 <_stogir.uses.build+0x260>
    4db8:      	add	x16, sp, #0x10
    4dbc:      	ldr	x5, [x16]
    4dc0:      	orr	x6, x5, xzr
    4dc4:      	add	x6, x6, x4, lsl #4
    4dc8:      	add	x4, x5, x4, lsl #4
    4dcc:      	ldr	x5, [x6]
    4dd0:      	ldr	x6, [x6, #0x8]
    4dd4:      	add	x6, x6, #0x1
    4dd8:      	str	x5, [x4]
    4ddc:      	str	x6, [x4, #0x8]
    4de0:      	add	x3, x3, #0x1
    4de4:      	sxtw	x3, w3
    4de8:      	cmp	x3, x2
    4dec:      	b.gt	0x4e10 <_stogir.uses.build+0x290>
    4df0:      	orr	w4, w3, wzr
    4df4:      	sxtw	x5, w4
    4df8:      	cmp	x5, #0x0
    4dfc:      	b.le	0x4d48 <_stogir.uses.build+0x1c8>
    4e00:      	cmp	x5, #0x4
    4e04:      	b.le	0x4d2c <_stogir.uses.build+0x1ac>
    4e08:      	mov	w4, #0x4                ; =4
    4e0c:      	b	0x4d30 <_stogir.uses.build+0x1b0>
    4e10:      	add	x1, x2, #0x4
    4e14:      	asr	x16, x1, #63
    4e18:      	lsr	x16, x16, #62
    4e1c:      	add	x1, x1, x16
    4e20:      	asr	x1, x1, #2
    4e24:      	add	x0, x1, x0
    4e28:      	ldr	x1, [x21, #0x8]
    4e2c:      	cmp	x0, x1
    4e30:      	b.ge	0x4e6c <_stogir.uses.build+0x2ec>
    4e34:      	ldr	x1, [x21]
    4e38:      	add	x1, x1, x0, lsl #4
    4e3c:      	ldr	x1, [x1]
    4e40:      	ldr	x2, [x21, #0x78]
    4e44:      	uxtb	w1, w1
    4e48:      	add	x2, x2, x0, lsl #2
    4e4c:      	adrp	x16, 0x4000 <_stogir.loops.depths+0x3d8>
		0000000000004e4c:  ARM64_RELOC_PAGE21	l_stogir.418
    4e50:      	ldr	x16, [x16]
		0000000000004e50:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    4e54:      	add	x1, x16, x1, lsl #2
    4e58:      	ldr	w2, [x2]
    4e5c:      	sxtw	x2, w2
    4e60:      	ldr	w1, [x1]
    4e64:      	mov	x3, #0x1                ; =1
    4e68:      	b	0x4de8 <_stogir.uses.build+0x268>
    4e6c:      	movn	x0, #0x0, lsl #48
    4e70:      	movz	x19, #0x0, lsl #48
    4e74:      	b	0x4eb0 <_stogir.uses.build+0x330>
    4e78:      	add	x16, sp, #0x10
    4e7c:      	ldr	x1, [x16]
    4e80:      	orr	x2, x1, xzr
    4e84:      	add	x2, x2, x0, lsl #4
    4e88:      	add	x1, x1, x0, lsl #4
    4e8c:      	ldr	x2, [x2, #0x8]
    4e90:      	add	x3, x2, x19
    4e94:      	str	x19, [x1]
    4e98:      	str	x2, [x1, #0x8]
    4e9c:      	add	x16, sp, #0x60
    4ea0:      	ldr	x1, [x16]
    4ea4:      	add	x1, x1, x0, lsl #3
    4ea8:      	str	x19, [x1]
    4eac:      	mov	x19, x3
    4eb0:      	add	x16, sp, #0x10
    4eb4:      	ldr	x1, [x16, #0x8]
    4eb8:      	add	x0, x0, #0x1
    4ebc:      	cmp	x0, x1
    4ec0:      	b.lt	0x4e78 <_stogir.uses.build+0x2f8>
    4ec4:      	add	x16, sp, #0x10
    4ec8:      	orr	x0, x16, xzr
    4ecc:      	add	x22, x0, #0x28
    4ed0:      	ldr	x0, [x22, #0x8]
    4ed4:      	orr	x23, x0, xzr
    4ed8:      	ldr	x0, [x22, #0x10]
    4edc:      	add	x24, x23, x19
    4ee0:      	cmp	x24, x0
    4ee4:      	b.le	0x4f18 <_stogir.uses.build+0x398>
    4ee8:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    4eec:      	cmp	x0, x17
    4ef0:      	b.gt	0x4efc <_stogir.uses.build+0x37c>
    4ef4:      	lsl	x0, x0, #1
    4ef8:      	b	0x4f00 <_stogir.uses.build+0x380>
    4efc:      	mov	x0, x24
    4f00:      	cmp	x0, x24
    4f04:      	b.gt	0x4f0c <_stogir.uses.build+0x38c>
    4f08:      	mov	x0, x24
    4f0c:      	mov	x1, x0
    4f10:      	mov	x0, x22
    4f14:      	bl	0x4f14 <_stogir.uses.build+0x394>
		0000000000004f14:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use
    4f18:      	lsl	x0, x19, #3
    4f1c:      	add	x16, sp, #0x10
    4f20:      	ldr	x1, [x16, #0x28]
    4f24:      	add	x1, x1, x23, lsl #3
    4f28:      	mov	x2, x0
    4f2c:      	mov	x0, x1
    4f30:      	movz	x1, #0x0, lsl #48
    4f34:      	bl	0x4f34 <_stogir.uses.build+0x3b4>
		0000000000004f34:  ARM64_RELOC_BRANCH26	_memset
    4f38:      	str	x24, [x22, #0x8]
    4f3c:      	mov	x0, x21
    4f40:      	add	x1, sp, #0x10
    4f44:      	add	x2, sp, #0x60
    4f48:      	bl	0x4f48 <_stogir.uses.build+0x3c8>
		0000000000004f48:  ARM64_RELOC_BRANCH26	_stogir.uses.scan!__constfalse
    4f4c:      	b	0x4f5c <_stogir.uses.build+0x3dc>
    4f50:      	sub	x0, x0, #0x1
    4f54:      	add	x16, sp, #0x60
    4f58:      	str	x0, [x16, #0x8]
    4f5c:      	add	x16, sp, #0x60
    4f60:      	ldr	x0, [x16, #0x8]
    4f64:      	cmp	x0, #0x0
    4f68:      	b.ne	0x4f50 <_stogir.uses.build+0x3d0>
    4f6c:      	add	x16, sp, #0x60
    4f70:      	orr	x0, x16, xzr
    4f74:      	add	x16, sp, #0x60
    4f78:      	ldr	x1, [x16, #0x10]
    4f7c:      	cmp	x1, #0x0
    4f80:      	b.le	0x4fb0 <_stogir.uses.build+0x430>
    4f84:      	add	x0, x0, #0x18
    4f88:      	add	x16, sp, #0x60
    4f8c:      	ldr	x2, [x16]
    4f90:      	fmov	d31, x1
    4f94:      	mov	x1, x2
    4f98:      	fmov	x2, d31
    4f9c:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3d8>
		0000000000004f9c:  ARM64_RELOC_PAGE21	l_stogir.419
    4fa0:      	ldr	x3, [x3]
		0000000000004fa0:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    4fa4:      	mov	x4, #0x8                ; =8
    4fa8:      	mov	x5, #0x8                ; =8
    4fac:      	bl	0x4fac <_stogir.uses.build+0x42c>
		0000000000004fac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4fb0:      	add	x16, sp, #0x60
    4fb4:      	movz	x17, #0x0, lsl #48
    4fb8:      	str	x17, [x16]
    4fbc:      	add	x16, sp, #0x60
    4fc0:      	movz	x17, #0x0, lsl #48
    4fc4:      	str	x17, [x16, #0x8]
    4fc8:      	add	x16, sp, #0x60
    4fcc:      	movz	x17, #0x0, lsl #48
    4fd0:      	str	x17, [x16, #0x10]
    4fd4:      	add	x16, sp, #0x10
    4fd8:      	ldr	x0, [x16]
    4fdc:      	add	x16, sp, #0x10
    4fe0:      	ldr	x1, [x16, #0x8]
    4fe4:      	add	x16, sp, #0x10
    4fe8:      	ldr	x2, [x16, #0x10]
    4fec:      	add	x16, sp, #0x10
    4ff0:      	ldr	x3, [x16, #0x18]
    4ff4:      	add	x16, sp, #0x10
    4ff8:      	ldr	x4, [x16, #0x20]
    4ffc:      	add	x16, sp, #0x10
    5000:      	ldr	x5, [x16, #0x28]
    5004:      	add	x16, sp, #0x10
    5008:      	ldr	x6, [x16, #0x30]
    500c:      	add	x16, sp, #0x10
    5010:      	ldr	x7, [x16, #0x38]
    5014:      	add	x16, sp, #0x10
    5018:      	ldr	x8, [x16, #0x40]
    501c:      	add	x16, sp, #0x10
    5020:      	ldr	x9, [x16, #0x48]
    5024:      	str	x0, [x20]
    5028:      	str	x1, [x20, #0x8]
    502c:      	str	x2, [x20, #0x10]
    5030:      	str	x3, [x20, #0x18]
    5034:      	str	x4, [x20, #0x20]
    5038:      	str	x5, [x20, #0x28]
    503c:      	str	x6, [x20, #0x30]
    5040:      	str	x7, [x20, #0x38]
    5044:      	str	x8, [x20, #0x40]
    5048:      	str	x9, [x20, #0x48]
    504c:      	ldr	x19, [sp, #0x90]
    5050:      	ldr	x20, [sp, #0x98]
    5054:      	ldr	x21, [sp, #0xa0]
    5058:      	ldr	x22, [sp, #0xa8]
    505c:      	ldr	x23, [sp, #0xb0]
    5060:      	ldr	x24, [sp, #0xb8]
    5064:      	ldr	x29, [sp]
    5068:      	ldr	x30, [sp, #0x8]
    506c:      	add	sp, sp, #0xc0
    5070:      	ret
    5074:      	mov	x20, x8
    5078:      	mov	x21, x0
    507c:      	b	0x4c80 <_stogir.uses.build+0x100>

0000000000005080 <_inherent$coil.arraylist.ArrayList$new__i32>:
    5080:      	ldr	x1, [x0]
    5084:      	ldr	x0, [x0, #0x8]
    5088:      	movz	x17, #0x0, lsl #48
    508c:      	str	x17, [x8]
    5090:      	movz	x17, #0x0, lsl #48
    5094:      	str	x17, [x8, #0x8]
    5098:      	movz	x17, #0x0, lsl #48
    509c:      	str	x17, [x8, #0x10]
    50a0:      	str	x1, [x8, #0x18]
    50a4:      	str	x0, [x8, #0x20]
    50a8:      	ret
    50ac:      	udf	#0x0

00000000000050b0 <_stogir.placement.pinned>:
    50b0:      	sub	sp, sp, #0xb0
    50b4:      	str	x29, [sp, #0x10]
    50b8:      	str	x30, [sp, #0x18]
    50bc:      	add	x29, sp, #0x10
    50c0:      	str	x19, [sp, #0x60]
    50c4:      	str	x20, [sp, #0x68]
    50c8:      	str	x21, [sp, #0x70]
    50cc:      	str	x22, [sp, #0x78]
    50d0:      	str	x23, [sp, #0x80]
    50d4:      	str	x24, [sp, #0x88]
    50d8:      	str	x25, [sp, #0x90]
    50dc:      	str	x26, [sp, #0x98]
    50e0:      	str	x27, [sp, #0xa0]
    50e4:      	add	x19, x1, #0x28
    50e8:      	ldr	x3, [x2]
    50ec:      	ldr	x2, [x2, #0x8]
    50f0:      	add	x16, sp, #0x20
    50f4:      	movz	x17, #0x0, lsl #48
    50f8:      	str	x17, [x16]
    50fc:      	add	x16, sp, #0x20
    5100:      	movz	x17, #0x0, lsl #48
    5104:      	str	x17, [x16, #0x8]
    5108:      	add	x16, sp, #0x20
    510c:      	movz	x17, #0x0, lsl #48
    5110:      	str	x17, [x16, #0x10]
    5114:      	add	x16, sp, #0x20
    5118:      	str	x3, [x16, #0x18]
    511c:      	add	x16, sp, #0x20
    5120:      	str	x2, [x16, #0x20]
    5124:      	movz	x20, #0x0, lsl #48
    5128:      	b	0x5178 <_stogir.placement.pinned+0xc8>
    512c:      	nop
    5130:      	lsl	x2, x2, #1
    5134:      	mov	x23, x8
    5138:      	mov	x24, x0
    513c:      	add	x0, sp, #0x20
    5140:      	mov	x25, x1
    5144:      	mov	x1, x2
    5148:      	bl	0x5148 <_stogir.placement.pinned+0x98>
		0000000000005148:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    514c:      	add	x20, x20, #0x1
    5150:      	add	x0, x22, #0x1
    5154:      	add	x16, sp, #0x20
    5158:      	ldr	x1, [x16]
    515c:      	add	x1, x1, x22, lsl #2
    5160:      	str	w21, [x1]
    5164:      	add	x16, sp, #0x20
    5168:      	str	x0, [x16, #0x8]
    516c:      	mov	x8, x23
    5170:      	mov	x0, x24
    5174:      	mov	x1, x25
    5178:      	ldr	x2, [x19, #0x8]
    517c:      	cmp	x20, x2
    5180:      	b.ge	0x55fc <_stogir.placement.pinned+0x54c>
    5184:      	ldr	x2, [x1, #0x28]
    5188:      	add	x2, x2, x20, lsl #2
    518c:      	ldr	w21, [x2]
    5190:      	add	x16, sp, #0x20
    5194:      	ldr	x2, [x16, #0x8]
    5198:      	orr	x22, x2, xzr
    519c:      	add	x16, sp, #0x20
    51a0:      	ldr	x2, [x16, #0x10]
    51a4:      	cmp	x22, x2
    51a8:      	b.lt	0x5608 <_stogir.placement.pinned+0x558>
    51ac:      	cmp	x2, #0x0
    51b0:      	b.ne	0x5130 <_stogir.placement.pinned+0x80>
    51b4:      	mov	x2, #0x2                ; =2
    51b8:      	b	0x5134 <_stogir.placement.pinned+0x84>
    51bc:      	add	x19, x24, #0x78
    51c0:      	add	x20, x24, #0x28
    51c4:      	add	x21, x24, #0x50
    51c8:      	mov	x22, #0x1               ; =1
    51cc:      	adrp	x25, 0x5000 <_stogir.uses.build+0x480>
		00000000000051cc:  ARM64_RELOC_PAGE21	l_stogir.420
    51d0:      	ldr	x25, [x25]
		00000000000051d0:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    51d4:      	movz	x26, #0x0, lsl #48
    51d8:      	b	0x5278 <_stogir.placement.pinned+0x1c8>
    51dc:      	adrp	x25, 0x5000 <_stogir.uses.build+0x480>
		00000000000051dc:  ARM64_RELOC_PAGE21	l_stogir.421
    51e0:      	ldr	x25, [x25]
		00000000000051e0:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    51e4:      	mov	x26, #0x15              ; =21
    51e8:      	b	0x525c <_stogir.placement.pinned+0x1ac>
    51ec:      	nop
    51f0:      	movz	w0, #0x0, lsl #16
    51f4:      	uxtb	w16, w0
    51f8:      	and	w0, w16, #0x20
    51fc:      	uxtb	w0, w0
    5200:      	ubfx	x0, x0, #0, #8
    5204:      	cmp	x0, #0x0
    5208:      	b.eq	0x525c <_stogir.placement.pinned+0x1ac>
    520c:      	orr	w0, w22, wzr
    5210:      	mov	w1, w0
    5214:      	mov	x0, x24
    5218:      	mov	x2, #0x1                ; =1
    521c:      	bl	0x521c <_stogir.placement.pinned+0x16c>
		000000000000521c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5220:      	ubfx	x0, x0, #0, #32
    5224:      	lsr	x16, x0, #0
    5228:      	cmp	x16, #0x1
    522c:      	b.eq	0x5248 <_stogir.placement.pinned+0x198>
    5230:      	b.lo	0x5238 <_stogir.placement.pinned+0x188>
    5234:      	b	0x524c <_stogir.placement.pinned+0x19c>
    5238:      	cmp	x16, #0x0
    523c:      	b.eq	0x5244 <_stogir.placement.pinned+0x194>
    5240:      	b	0x524c <_stogir.placement.pinned+0x19c>
    5244:      	b	0x5250 <_stogir.placement.pinned+0x1a0>
    5248:      	b	0x52c4 <_stogir.placement.pinned+0x214>
    524c:      	b	0x55ec <_stogir.placement.pinned+0x53c>
    5250:      	adrp	x25, 0x5000 <_stogir.uses.build+0x480>
		0000000000005250:  ARM64_RELOC_PAGE21	l_stogir.422
    5254:      	ldr	x25, [x25]
		0000000000005254:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    5258:      	mov	x26, #0x19              ; =25
    525c:      	sxtw	x27, w27
    5260:      	add	x0, x27, #0x4
    5264:      	asr	x16, x0, #63
    5268:      	lsr	x16, x16, #62
    526c:      	add	x0, x0, x16
    5270:      	asr	x0, x0, #2
    5274:      	add	x22, x0, x22
    5278:      	cmp	x26, #0x0
    527c:      	b.ne	0x530c <_stogir.placement.pinned+0x25c>
    5280:      	ldr	x0, [x24, #0x8]
    5284:      	cmp	x22, x0
    5288:      	b.ge	0x530c <_stogir.placement.pinned+0x25c>
    528c:      	ldr	x0, [x24]
    5290:      	add	x0, x0, x22, lsl #4
    5294:      	ldr	x0, [x0]
    5298:      	ldr	x1, [x24, #0x78]
    529c:      	uxtb	w0, w0
    52a0:      	add	x1, x1, x22, lsl #2
    52a4:      	ldr	w27, [x1]
    52a8:      	cmp	x0, #0x83
    52ac:      	b.ge	0x51f0 <_stogir.placement.pinned+0x140>
    52b0:      	adrp	x17, 0x5000 <_stogir.uses.build+0x480>
		00000000000052b0:  ARM64_RELOC_PAGE21	l_stogir.423
    52b4:      	ldr	x17, [x17]
		00000000000052b4:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    52b8:      	add	x0, x0, x17
    52bc:      	ldrb	w0, [x0]
    52c0:      	b	0x51f4 <_stogir.placement.pinned+0x144>
    52c4:      	sxtw	x0, w1
    52c8:      	cmp	x0, #0x0
    52cc:      	b.le	0x51dc <_stogir.placement.pinned+0x12c>
    52d0:      	lsl	x2, x0, #2
    52d4:      	ldr	x3, [x24, #0x8]
    52d8:      	cmp	x0, x3
    52dc:      	b.ge	0x5430 <_stogir.placement.pinned+0x380>
    52e0:      	ldr	x3, [x19, #0x8]
    52e4:      	cmp	x0, x3
    52e8:      	b.ge	0x5428 <_stogir.placement.pinned+0x378>
    52ec:      	ldr	x3, [x24, #0x78]
    52f0:      	add	x3, x2, x3
    52f4:      	ldr	w3, [x3]
    52f8:      	sxtw	x3, w3
    52fc:      	cmp	x3, #0x0
    5300:      	cset	w3, ge
    5304:      	ubfx	x3, x3, #0, #8
    5308:      	b	0x542c <_stogir.placement.pinned+0x37c>
    530c:      	cmp	x26, #0x0
    5310:      	b.ne	0x5344 <_stogir.placement.pinned+0x294>
    5314:      	add	x16, sp, #0x20
    5318:      	ldr	x25, [x16]
    531c:      	add	x16, sp, #0x20
    5320:      	ldr	x26, [x16, #0x8]
    5324:      	add	x16, sp, #0x20
    5328:      	ldr	x0, [x16, #0x10]
    532c:      	add	x16, sp, #0x20
    5330:      	ldr	x1, [x16, #0x18]
    5334:      	add	x16, sp, #0x20
    5338:      	ldr	x2, [x16, #0x20]
    533c:      	movz	x3, #0x0, lsl #48
    5340:      	b	0x53dc <_stogir.placement.pinned+0x32c>
    5344:      	b	0x5354 <_stogir.placement.pinned+0x2a4>
    5348:      	sub	x0, x0, #0x1
    534c:      	add	x16, sp, #0x20
    5350:      	str	x0, [x16, #0x8]
    5354:      	add	x16, sp, #0x20
    5358:      	ldr	x0, [x16, #0x8]
    535c:      	cmp	x0, #0x0
    5360:      	b.ne	0x5348 <_stogir.placement.pinned+0x298>
    5364:      	add	x16, sp, #0x20
    5368:      	orr	x0, x16, xzr
    536c:      	add	x16, sp, #0x20
    5370:      	ldr	x1, [x16, #0x10]
    5374:      	cmp	x1, #0x0
    5378:      	b.le	0x53a8 <_stogir.placement.pinned+0x2f8>
    537c:      	add	x0, x0, #0x18
    5380:      	add	x16, sp, #0x20
    5384:      	ldr	x2, [x16]
    5388:      	fmov	d31, x1
    538c:      	mov	x1, x2
    5390:      	fmov	x2, d31
    5394:      	adrp	x3, 0x5000 <_stogir.uses.build+0x480>
		0000000000005394:  ARM64_RELOC_PAGE21	l_stogir.424
    5398:      	ldr	x3, [x3]
		0000000000005398:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    539c:      	mov	x4, #0x4                ; =4
    53a0:      	mov	x5, #0x4                ; =4
    53a4:      	bl	0x53a4 <_stogir.placement.pinned+0x2f4>
		00000000000053a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    53a8:      	add	x16, sp, #0x20
    53ac:      	movz	x17, #0x0, lsl #48
    53b0:      	str	x17, [x16]
    53b4:      	add	x16, sp, #0x20
    53b8:      	movz	x17, #0x0, lsl #48
    53bc:      	str	x17, [x16, #0x8]
    53c0:      	add	x16, sp, #0x20
    53c4:      	movz	x17, #0x0, lsl #48
    53c8:      	str	x17, [x16, #0x10]
    53cc:      	mov	x3, #0x1                ; =1
    53d0:      	movz	x0, #0x0, lsl #48
    53d4:      	movz	x1, #0x0, lsl #48
    53d8:      	movz	x2, #0x0, lsl #48
    53dc:      	str	x3, [x23]
    53e0:      	str	x25, [x23, #0x8]
    53e4:      	str	x26, [x23, #0x10]
    53e8:      	str	x0, [x23, #0x18]
    53ec:      	str	x1, [x23, #0x20]
    53f0:      	str	x2, [x23, #0x28]
    53f4:      	ldr	x19, [sp, #0x60]
    53f8:      	ldr	x20, [sp, #0x68]
    53fc:      	ldr	x21, [sp, #0x70]
    5400:      	ldr	x22, [sp, #0x78]
    5404:      	ldr	x23, [sp, #0x80]
    5408:      	ldr	x24, [sp, #0x88]
    540c:      	ldr	x25, [sp, #0x90]
    5410:      	ldr	x26, [sp, #0x98]
    5414:      	ldr	x27, [sp, #0xa0]
    5418:      	ldr	x29, [sp, #0x10]
    541c:      	ldr	x30, [sp, #0x18]
    5420:      	add	sp, sp, #0xb0
    5424:      	ret
    5428:      	movz	x3, #0x0, lsl #48
    542c:      	b	0x5434 <_stogir.placement.pinned+0x384>
    5430:      	movz	x3, #0x0, lsl #48
    5434:      	cmp	x3, #0x0
    5438:      	b.eq	0x51dc <_stogir.placement.pinned+0x12c>
    543c:      	movz	x16, #0x0, lsl #48
    5440:      	sub	x3, x16, x0
    5444:      	cmp	x0, #0x0
    5448:      	cset	w4, gt
    544c:      	sub	x5, x3, #0x1
    5450:      	uxtb	w16, w4
    5454:      	cmp	w16, wzr
    5458:      	b.eq	0x54a4 <_stogir.placement.pinned+0x3f4>
    545c:      	ldr	x3, [x24, #0x8]
    5460:      	cmp	x0, x3
    5464:      	b.ge	0x54e4 <_stogir.placement.pinned+0x434>
    5468:      	ldr	x3, [x19, #0x8]
    546c:      	cmp	x0, x3
    5470:      	b.ge	0x5598 <_stogir.placement.pinned+0x4e8>
    5474:      	ldr	x3, [x24, #0x78]
    5478:      	add	x2, x2, x3
    547c:      	ldr	w2, [x2]
    5480:      	sxtw	x2, w2
    5484:      	cmp	x2, #0x0
    5488:      	cset	w2, ge
    548c:      	ubfx	x2, x2, #0, #8
    5490:      	b	0x559c <_stogir.placement.pinned+0x4ec>
    5494:      	adrp	x25, 0x5000 <_stogir.uses.build+0x480>
		0000000000005494:  ARM64_RELOC_PAGE21	l_stogir.425
    5498:      	ldr	x25, [x25]
		0000000000005498:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    549c:      	mov	x26, #0x20              ; =32
    54a0:      	b	0x51e8 <_stogir.placement.pinned+0x138>
    54a4:      	cmp	x0, #0x0
    54a8:      	b.ge	0x54ec <_stogir.placement.pinned+0x43c>
    54ac:      	ldr	x2, [x20, #0x8]
    54b0:      	ldr	x6, [x21, #0x8]
    54b4:      	cmp	x2, x6
    54b8:      	b.ne	0x5590 <_stogir.placement.pinned+0x4e0>
    54bc:      	cmp	x3, x2
    54c0:      	b.gt	0x55e4 <_stogir.placement.pinned+0x534>
    54c4:      	ldr	x2, [x24, #0x50]
    54c8:      	add	x2, x2, x5, lsl #2
    54cc:      	ldr	w2, [x2]
    54d0:      	sxtw	x2, w2
    54d4:      	cmp	x2, #0x0
    54d8:      	cset	w2, gt
    54dc:      	ubfx	x2, x2, #0, #8
    54e0:      	b	0x55e8 <_stogir.placement.pinned+0x538>
    54e4:      	movz	x2, #0x0, lsl #48
    54e8:      	b	0x54f0 <_stogir.placement.pinned+0x440>
    54ec:      	movz	x2, #0x0, lsl #48
    54f0:      	cmp	x2, #0x0
    54f4:      	b.eq	0x5528 <_stogir.placement.pinned+0x478>
    54f8:      	uxtb	w16, w4
    54fc:      	cmp	w16, wzr
    5500:      	b.eq	0x5514 <_stogir.placement.pinned+0x464>
    5504:      	ldr	x2, [x24]
    5508:      	add	x0, x2, x0, lsl #4
    550c:      	ldr	x0, [x0]
    5510:      	b	0x5520 <_stogir.placement.pinned+0x470>
    5514:      	ldr	x0, [x24, #0x28]
    5518:      	add	x0, x0, x5, lsl #4
    551c:      	ldr	x0, [x0]
    5520:      	mov	w2, #0x1                ; =1
    5524:      	b	0x5530 <_stogir.placement.pinned+0x480>
    5528:      	movz	w2, #0x0, lsl #16
    552c:      	movz	x0, #0x0, lsl #48
    5530:      	ubfx	x2, x2, #0, #32
    5534:      	lsr	x16, x2, #0
    5538:      	cmp	x16, #0x1
    553c:      	b.eq	0x5558 <_stogir.placement.pinned+0x4a8>
    5540:      	b.lo	0x5548 <_stogir.placement.pinned+0x498>
    5544:      	b	0x555c <_stogir.placement.pinned+0x4ac>
    5548:      	cmp	x16, #0x0
    554c:      	b.eq	0x5554 <_stogir.placement.pinned+0x4a4>
    5550:      	b	0x555c <_stogir.placement.pinned+0x4ac>
    5554:      	b	0x5560 <_stogir.placement.pinned+0x4b0>
    5558:      	b	0x5570 <_stogir.placement.pinned+0x4c0>
    555c:      	b	0x55f4 <_stogir.placement.pinned+0x544>
    5560:      	adrp	x25, 0x5000 <_stogir.uses.build+0x480>
		0000000000005560:  ARM64_RELOC_PAGE21	l_stogir.421
    5564:      	ldr	x25, [x25]
		0000000000005564:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    5568:      	mov	x26, #0x15              ; =21
    556c:      	b	0x54a0 <_stogir.placement.pinned+0x3f0>
    5570:      	uxtb	w0, w0
    5574:      	cmp	x0, #0x83
    5578:      	b.ge	0x55a0 <_stogir.placement.pinned+0x4f0>
    557c:      	adrp	x17, 0x5000 <_stogir.uses.build+0x480>
		000000000000557c:  ARM64_RELOC_PAGE21	l_stogir.423
    5580:      	ldr	x17, [x17]
		0000000000005580:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    5584:      	add	x0, x0, x17
    5588:      	ldrb	w0, [x0]
    558c:      	b	0x55a4 <_stogir.placement.pinned+0x4f4>
    5590:      	movz	x2, #0x0, lsl #48
    5594:      	b	0x54f0 <_stogir.placement.pinned+0x440>
    5598:      	movz	x2, #0x0, lsl #48
    559c:      	b	0x54e8 <_stogir.placement.pinned+0x438>
    55a0:      	movz	w0, #0x0, lsl #16
    55a4:      	uxtb	w16, w0
    55a8:      	and	w0, w16, #0x2
    55ac:      	uxtb	w0, w0
    55b0:      	ubfx	x0, x0, #0, #8
    55b4:      	cmp	x0, #0x0
    55b8:      	cset	w0, eq
    55bc:      	uxtb	w16, w0
    55c0:      	cmp	w16, wzr
    55c4:      	cset	x0, eq
    55c8:      	cmp	x0, #0x0
    55cc:      	b.eq	0x5494 <_stogir.placement.pinned+0x3e4>
    55d0:      	add	x16, sp, #0x20
    55d4:      	ldr	x0, [x16]
    55d8:      	add	x0, x0, x22, lsl #2
    55dc:      	str	w1, [x0]
    55e0:      	b	0x54a0 <_stogir.placement.pinned+0x3f0>
    55e4:      	movz	x2, #0x0, lsl #48
    55e8:      	b	0x5594 <_stogir.placement.pinned+0x4e4>
    55ec:      	brk	#0
    55f0:      	b	0x55ec <_stogir.placement.pinned+0x53c>
    55f4:      	brk	#0
    55f8:      	b	0x55f4 <_stogir.placement.pinned+0x544>
    55fc:      	mov	x23, x8
    5600:      	mov	x24, x0
    5604:      	b	0x51bc <_stogir.placement.pinned+0x10c>
    5608:      	mov	x23, x8
    560c:      	mov	x24, x0
    5610:      	mov	x25, x1
    5614:      	b	0x514c <_stogir.placement.pinned+0x9c>

0000000000005618 <_stogir.placement.early-with-uses!>:
    5618:      	sub	sp, sp, #0x1b0
    561c:      	str	x29, [sp, #0x10]
    5620:      	str	x30, [sp, #0x18]
    5624:      	add	x29, sp, #0x10
    5628:      	str	x19, [sp, #0x158]
    562c:      	str	x20, [sp, #0x160]
    5630:      	str	x21, [sp, #0x168]
    5634:      	str	x22, [sp, #0x170]
    5638:      	str	x23, [sp, #0x178]
    563c:      	str	x24, [sp, #0x180]
    5640:      	str	x25, [sp, #0x188]
    5644:      	str	x26, [sp, #0x190]
    5648:      	str	x27, [sp, #0x198]
    564c:      	str	x28, [sp, #0x1a0]
    5650:      	mov	x19, x8
    5654:      	add	x8, sp, #0x50
    5658:      	mov	x20, x0
    565c:      	mov	x0, x5
    5660:      	mov	x21, x1
    5664:      	mov	x22, x2
    5668:      	mov	w23, w3
    566c:      	mov	x24, x4
    5670:      	mov	x25, x5
    5674:      	bl	0x5674 <_stogir.placement.early-with-uses!+0x5c>
		0000000000005674:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    5678:      	add	x16, sp, #0x50
    567c:      	ldr	x0, [x16]
    5680:      	add	x16, sp, #0x20
    5684:      	str	x0, [x16]
    5688:      	add	x16, sp, #0x50
    568c:      	ldr	x0, [x16, #0x8]
    5690:      	add	x16, sp, #0x20
    5694:      	str	x0, [x16, #0x8]
    5698:      	add	x16, sp, #0x50
    569c:      	ldr	x0, [x16, #0x10]
    56a0:      	add	x16, sp, #0x20
    56a4:      	str	x0, [x16, #0x10]
    56a8:      	add	x16, sp, #0x50
    56ac:      	ldr	x0, [x16, #0x18]
    56b0:      	add	x16, sp, #0x20
    56b4:      	str	x0, [x16, #0x18]
    56b8:      	add	x16, sp, #0x50
    56bc:      	ldr	x0, [x16, #0x20]
    56c0:      	add	x16, sp, #0x20
    56c4:      	str	x0, [x16, #0x20]
    56c8:      	add	x8, sp, #0xb0
    56cc:      	mov	x0, x25
    56d0:      	bl	0x56d0 <_stogir.placement.early-with-uses!+0xb8>
		00000000000056d0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    56d4:      	add	x16, sp, #0xb0
    56d8:      	ldr	x0, [x16]
    56dc:      	add	x16, sp, #0x80
    56e0:      	str	x0, [x16]
    56e4:      	add	x16, sp, #0xb0
    56e8:      	ldr	x0, [x16, #0x8]
    56ec:      	add	x16, sp, #0x80
    56f0:      	str	x0, [x16, #0x8]
    56f4:      	add	x16, sp, #0xb0
    56f8:      	ldr	x0, [x16, #0x10]
    56fc:      	add	x16, sp, #0x80
    5700:      	str	x0, [x16, #0x10]
    5704:      	add	x16, sp, #0xb0
    5708:      	ldr	x0, [x16, #0x18]
    570c:      	add	x16, sp, #0x80
    5710:      	str	x0, [x16, #0x18]
    5714:      	add	x16, sp, #0xb0
    5718:      	ldr	x0, [x16, #0x20]
    571c:      	add	x16, sp, #0x80
    5720:      	str	x0, [x16, #0x20]
    5724:      	movz	x25, #0x0, lsl #48
    5728:      	b	0x5764 <_stogir.placement.early-with-uses!+0x14c>
    572c:      	nop
    5730:      	lsl	x0, x0, #1
    5734:      	mov	x1, x0
    5738:      	add	x0, sp, #0x20
    573c:      	bl	0x573c <_stogir.placement.early-with-uses!+0x124>
		000000000000573c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5740:      	add	x25, x25, #0x1
    5744:      	add	x0, x26, #0x1
    5748:      	add	x16, sp, #0x20
    574c:      	ldr	x1, [x16]
    5750:      	add	x1, x1, x26, lsl #2
    5754:      	movn	w17, #0x0, lsl #16
    5758:      	str	w17, [x1]
    575c:      	add	x16, sp, #0x20
    5760:      	str	x0, [x16, #0x8]
    5764:      	ldr	x0, [x20, #0x8]
    5768:      	cmp	x25, x0
    576c:      	b.ge	0x579c <_stogir.placement.early-with-uses!+0x184>
    5770:      	add	x16, sp, #0x20
    5774:      	ldr	x0, [x16, #0x8]
    5778:      	orr	x26, x0, xzr
    577c:      	add	x16, sp, #0x20
    5780:      	ldr	x0, [x16, #0x10]
    5784:      	cmp	x26, x0
    5788:      	b.lt	0x5740 <_stogir.placement.early-with-uses!+0x128>
    578c:      	cmp	x0, #0x0
    5790:      	b.ne	0x5730 <_stogir.placement.early-with-uses!+0x118>
    5794:      	mov	x0, #0x2                ; =2
    5798:      	b	0x5734 <_stogir.placement.early-with-uses!+0x11c>
    579c:      	mov	x25, #0x1               ; =1
    57a0:      	movz	x26, #0x0, lsl #48
    57a4:      	adrp	x27, 0x5000 <_stogir.uses.build+0x480>
		00000000000057a4:  ARM64_RELOC_PAGE21	l_stogir.426
    57a8:      	ldr	x27, [x27]
		00000000000057a8:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    57ac:      	movz	x28, #0x0, lsl #48
    57b0:      	b	0x5810 <_stogir.placement.early-with-uses!+0x1f8>
    57b4:      	lsl	x0, x0, #1
    57b8:      	mov	x1, x0
    57bc:      	add	x0, sp, #0x80
    57c0:      	bl	0x57c0 <_stogir.placement.early-with-uses!+0x1a8>
		00000000000057c0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    57c4:      	add	x0, x22, #0x1
    57c8:      	add	x16, sp, #0x80
    57cc:      	ldr	x1, [x16]
    57d0:      	add	x1, x1, x22, lsl #2
    57d4:      	str	w27, [x1]
    57d8:      	add	x16, sp, #0x80
    57dc:      	str	x0, [x16, #0x8]
    57e0:      	add	x0, x26, #0x1
    57e4:      	sxtw	x26, w0
    57e8:      	add	x0, x19, #0x4
    57ec:      	asr	x16, x0, #63
    57f0:      	lsr	x16, x16, #62
    57f4:      	add	x0, x0, x16
    57f8:      	asr	x0, x0, #2
    57fc:      	add	x25, x0, x25
    5800:      	ldr	x19, [sp, #0x108]
    5804:      	ldr	x22, [sp, #0x128]
    5808:      	ldr	x24, [sp, #0x120]
    580c:      	ldr	x27, [sp, #0x110]
    5810:      	ldr	x0, [x20, #0x8]
    5814:      	cmp	x25, x0
    5818:      	b.ge	0x5f40 <_stogir.placement.early-with-uses!+0x928>
    581c:      	lsl	x0, x25, #2
    5820:      	ldr	x1, [x20]
    5824:      	add	x1, x1, x25, lsl #4
    5828:      	ldr	x1, [x1]
    582c:      	ldr	x2, [x20, #0x78]
    5830:      	uxtb	w1, w1
    5834:      	add	x2, x2, x25, lsl #2
    5838:      	cmp	x1, #0x83
    583c:      	cset	w3, lt
    5840:      	ldr	w2, [x2]
    5844:      	uxtb	w16, w3
    5848:      	cmp	w16, wzr
    584c:      	b.eq	0x5864 <_stogir.placement.early-with-uses!+0x24c>
    5850:      	adrp	x17, 0x5000 <_stogir.uses.build+0x480>
		0000000000005850:  ARM64_RELOC_PAGE21	l_stogir.427
    5854:      	ldr	x17, [x17]
		0000000000005854:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    5858:      	add	x4, x1, x17
    585c:      	ldrb	w4, [x4]
    5860:      	b	0x5868 <_stogir.placement.early-with-uses!+0x250>
    5864:      	movz	w4, #0x0, lsl #16
    5868:      	ldr	x5, [x21]
    586c:      	add	x0, x5, x0
    5870:      	ldr	w0, [x0]
    5874:      	sxtw	x0, w0
    5878:      	cmp	x0, #0x0
    587c:      	b.ne	0x58a8 <_stogir.placement.early-with-uses!+0x290>
    5880:      	uxtb	w16, w4
    5884:      	and	w0, w16, #0x40
    5888:      	uxtb	w0, w0
    588c:      	ubfx	x0, x0, #0, #8
    5890:      	cmp	x0, #0x0
    5894:      	b.ne	0x58a0 <_stogir.placement.early-with-uses!+0x288>
    5898:      	movz	x0, #0x0, lsl #48
    589c:      	b	0x58a4 <_stogir.placement.early-with-uses!+0x28c>
    58a0:      	mov	x0, #0x1                ; =1
    58a4:      	b	0x58ac <_stogir.placement.early-with-uses!+0x294>
    58a8:      	movz	x0, #0x0, lsl #48
    58ac:      	sxtw	x2, w2
    58b0:      	cmp	x0, #0x0
    58b4:      	b.eq	0x5f54 <_stogir.placement.early-with-uses!+0x93c>
    58b8:      	orr	w0, w25, wzr
    58bc:      	adrp	x16, 0x5000 <_stogir.uses.build+0x480>
		00000000000058bc:  ARM64_RELOC_PAGE21	l_stogir.428
    58c0:      	ldr	x16, [x16]
		00000000000058c0:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    58c4:      	add	x1, x16, x1, lsl #2
    58c8:      	mov	x4, #0x1                ; =1
    58cc:      	movz	x5, #0x0, lsl #48
    58d0:      	b	0x5948 <_stogir.placement.early-with-uses!+0x330>
    58d4:      	sub	w7, w6, #0x1
    58d8:      	lsl	w7, w7, #2
    58dc:      	ubfx	x7, x7, #0, #32
    58e0:      	lsr	x7, x8, x7
    58e4:      	and	w7, w7, #0xf
    58e8:      	b	0x5984 <_stogir.placement.early-with-uses!+0x36c>
    58ec:      	sxtw	x1, w1
    58f0:      	cmp	x1, #0x0
    58f4:      	b.le	0x5918 <_stogir.placement.early-with-uses!+0x300>
    58f8:      	ldr	x0, [x21]
    58fc:      	add	x0, x0, x1, lsl #2
    5900:      	ldr	w0, [x0]
    5904:      	sxtw	x0, w0
    5908:      	cmp	x0, #0x0
    590c:      	b.ne	0x5918 <_stogir.placement.early-with-uses!+0x300>
    5910:      	add	x0, x22, #0x1
    5914:      	sxtw	x22, w0
    5918:      	add	x0, x24, #0x1
    591c:      	sxtw	x24, w0
    5920:      	mov	x2, x19
    5924:      	ldr	x19, [sp, #0x108]
    5928:      	mov	w0, w27
    592c:      	ldr	w3, [sp, #0x100]
    5930:      	ldr	x1, [sp, #0x118]
    5934:      	mov	x4, x24
    5938:      	ldr	x24, [sp, #0x120]
    593c:      	mov	x5, x22
    5940:      	ldr	x22, [sp, #0x128]
    5944:      	ldr	x27, [sp, #0x110]
    5948:      	cmp	x4, x2
    594c:      	b.gt	0x5f6c <_stogir.placement.early-with-uses!+0x954>
    5950:      	orr	w6, w4, wzr
    5954:      	uxtb	w16, w3
    5958:      	cmp	w16, wzr
    595c:      	b.eq	0x5988 <_stogir.placement.early-with-uses!+0x370>
    5960:      	sxtw	x7, w6
    5964:      	ldr	w8, [x1]
    5968:      	cmp	x7, #0x0
    596c:      	b.le	0x5980 <_stogir.placement.early-with-uses!+0x368>
    5970:      	cmp	x7, #0x4
    5974:      	b.le	0x58d4 <_stogir.placement.early-with-uses!+0x2bc>
    5978:      	mov	w7, #0x4                ; =4
    597c:      	b	0x58d8 <_stogir.placement.early-with-uses!+0x2c0>
    5980:      	movz	w7, #0x0, lsl #16
    5984:      	b	0x598c <_stogir.placement.early-with-uses!+0x374>
    5988:      	movz	w7, #0x0, lsl #16
    598c:      	ubfx	x7, x7, #0, #32
    5990:      	cmp	x7, #0xf
    5994:      	b.hs	0x5f8c <_stogir.placement.early-with-uses!+0x974>
    5998:      	mov	x16, #0x1               ; =1
    599c:      	lsl	x7, x16, x7
    59a0:      	mov	w17, #0x5e1c            ; =24092
    59a4:      	and	w7, w7, w17
    59a8:      	ubfx	x7, x7, #0, #32
    59ac:      	cmp	x7, #0x0
    59b0:      	b.eq	0x5fb8 <_stogir.placement.early-with-uses!+0x9a0>
    59b4:      	str	w3, [sp, #0x100]
    59b8:      	str	x1, [sp, #0x118]
    59bc:      	mov	w1, w0
    59c0:      	str	x19, [sp, #0x108]
    59c4:      	mov	x19, x2
    59c8:      	mov	w2, w6
    59cc:      	str	x27, [sp, #0x110]
    59d0:      	mov	w27, w0
    59d4:      	mov	x0, x20
    59d8:      	str	x24, [sp, #0x120]
    59dc:      	mov	x24, x4
    59e0:      	str	x22, [sp, #0x128]
    59e4:      	mov	x22, x5
    59e8:      	bl	0x59e8 <_stogir.placement.early-with-uses!+0x3d0>
		00000000000059e8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    59ec:      	ubfx	x0, x0, #0, #32
    59f0:      	lsr	x16, x0, #0
    59f4:      	cmp	x16, #0x1
    59f8:      	b.eq	0x5a14 <_stogir.placement.early-with-uses!+0x3fc>
    59fc:      	b.lo	0x5a04 <_stogir.placement.early-with-uses!+0x3ec>
    5a00:      	b	0x5a18 <_stogir.placement.early-with-uses!+0x400>
    5a04:      	cmp	x16, #0x0
    5a08:      	b.eq	0x5a10 <_stogir.placement.early-with-uses!+0x3f8>
    5a0c:      	b	0x5a18 <_stogir.placement.early-with-uses!+0x400>
    5a10:      	b	0x5a1c <_stogir.placement.early-with-uses!+0x404>
    5a14:      	b	0x58ec <_stogir.placement.early-with-uses!+0x2d4>
    5a18:      	b	0x5f38 <_stogir.placement.early-with-uses!+0x920>
    5a1c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x480>
		0000000000005a1c:  ARM64_RELOC_PAGE21	l_stogir.429
    5a20:      	ldr	x16, [x16]
		0000000000005a20:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    5a24:      	str	x16, [sp, #0x110]
    5a28:      	mov	x28, #0x18              ; =24
    5a2c:      	b	0x5918 <_stogir.placement.early-with-uses!+0x300>
    5a30:      	orr	w0, w22, wzr
    5a34:      	add	x16, sp, #0x20
    5a38:      	ldr	x1, [x16]
    5a3c:      	add	x1, x1, x25, lsl #2
    5a40:      	str	w0, [x1]
    5a44:      	cmp	x22, #0x0
    5a48:      	b.ne	0x57e0 <_stogir.placement.early-with-uses!+0x1c8>
    5a4c:      	add	x16, sp, #0x80
    5a50:      	ldr	x0, [x16, #0x8]
    5a54:      	orr	x22, x0, xzr
    5a58:      	add	x16, sp, #0x80
    5a5c:      	ldr	x0, [x16, #0x10]
    5a60:      	cmp	x22, x0
    5a64:      	b.lt	0x57c4 <_stogir.placement.early-with-uses!+0x1ac>
    5a68:      	cmp	x0, #0x0
    5a6c:      	b.ne	0x57b4 <_stogir.placement.early-with-uses!+0x19c>
    5a70:      	mov	x0, #0x2                ; =2
    5a74:      	b	0x57b8 <_stogir.placement.early-with-uses!+0x1a0>
    5a78:      	sxtw	x23, w23
    5a7c:      	movz	x19, #0x0, lsl #48
    5a80:      	movz	x22, #0x0, lsl #48
    5a84:      	b	0x5bcc <_stogir.placement.early-with-uses!+0x5b4>
    5a88:      	movz	x1, #0x0, lsl #48
    5a8c:      	movz	x2, #0x0, lsl #48
    5a90:      	b	0x5aa4 <_stogir.placement.early-with-uses!+0x48c>
    5a94:      	mov	x23, x3
    5a98:      	b	0x5aa4 <_stogir.placement.early-with-uses!+0x48c>
    5a9c:      	nop
    5aa0:      	mov	x1, #0x1                ; =1
    5aa4:      	cmp	x1, #0x0
    5aa8:      	b.ne	0x5c54 <_stogir.placement.early-with-uses!+0x63c>
    5aac:      	cmp	x23, #0x0
    5ab0:      	b.le	0x5aa0 <_stogir.placement.early-with-uses!+0x488>
    5ab4:      	ldr	x3, [x4, #0x8]
    5ab8:      	cmp	x23, x3
    5abc:      	b.ge	0x5aa0 <_stogir.placement.early-with-uses!+0x488>
    5ac0:      	ldr	x3, [x4]
    5ac4:      	add	x3, x3, x23, lsl #2
    5ac8:      	ldr	w3, [x3]
    5acc:      	sxtw	x3, w3
    5ad0:      	cmp	x3, #0x0
    5ad4:      	b.ne	0x5ae0 <_stogir.placement.early-with-uses!+0x4c8>
    5ad8:      	mov	x1, #0x1                ; =1
    5adc:      	b	0x5a98 <_stogir.placement.early-with-uses!+0x480>
    5ae0:      	cmp	x23, x0
    5ae4:      	b.ne	0x5f20 <_stogir.placement.early-with-uses!+0x908>
    5ae8:      	mov	x1, #0x1                ; =1
    5aec:      	mov	x2, #0x1                ; =1
    5af0:      	b	0x5a98 <_stogir.placement.early-with-uses!+0x480>
    5af4:      	nop
    5af8:      	lsl	x1, x1, #1
    5afc:      	str	x4, [sp, #0x128]
    5b00:      	str	x20, [sp, #0x120]
    5b04:      	mov	x20, x0
    5b08:      	add	x0, sp, #0x80
    5b0c:      	bl	0x5b0c <_stogir.placement.early-with-uses!+0x4f4>
		0000000000005b0c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5b10:      	add	x0, x20, #0x1
    5b14:      	add	x16, sp, #0x80
    5b18:      	ldr	x1, [x16]
    5b1c:      	add	x1, x1, x20, lsl #2
    5b20:      	str	w27, [x1]
    5b24:      	add	x16, sp, #0x80
    5b28:      	str	x0, [x16, #0x8]
    5b2c:      	add	x25, x25, #0x1
    5b30:      	ldr	x4, [sp, #0x128]
    5b34:      	ldr	x20, [sp, #0x120]
    5b38:      	cmp	x25, x24
    5b3c:      	b.ge	0x5fe4 <_stogir.placement.early-with-uses!+0x9cc>
    5b40:      	add	x0, x23, x25
    5b44:      	ldr	x1, [x20, #0x28]
    5b48:      	add	x0, x1, x0, lsl #3
    5b4c:      	ldr	x0, [x0]
    5b50:      	add	x16, sp, #0x20
    5b54:      	ldr	x1, [x16]
    5b58:      	orr	w27, w0, wzr
    5b5c:      	sxtw	x0, w27
    5b60:      	add	x2, x1, x0, lsl #2
    5b64:      	ldr	w2, [x2]
    5b68:      	sxtw	x3, w2
    5b6c:      	cmp	x3, #0x0
    5b70:      	b.le	0x5ff0 <_stogir.placement.early-with-uses!+0x9d8>
    5b74:      	sub	w2, w2, #0x1
    5b78:      	add	x0, x1, x0, lsl #2
    5b7c:      	str	w2, [x0]
    5b80:      	cmp	x3, #0x1
    5b84:      	b.ne	0x5ffc <_stogir.placement.early-with-uses!+0x9e4>
    5b88:      	add	x16, sp, #0x80
    5b8c:      	ldr	x0, [x16, #0x8]
    5b90:      	add	x16, sp, #0x80
    5b94:      	ldr	x1, [x16, #0x10]
    5b98:      	cmp	x0, x1
    5b9c:      	b.lt	0x6008 <_stogir.placement.early-with-uses!+0x9f0>
    5ba0:      	cmp	x1, #0x0
    5ba4:      	b.ne	0x5af8 <_stogir.placement.early-with-uses!+0x4e0>
    5ba8:      	mov	x1, #0x2                ; =2
    5bac:      	b	0x5afc <_stogir.placement.early-with-uses!+0x4e4>
    5bb0:      	add	x0, x22, #0x1
    5bb4:      	sub	x1, x26, #0x1
    5bb8:      	sxtw	x22, w0
    5bbc:      	sxtw	x26, w1
    5bc0:      	add	x19, x19, #0x1
    5bc4:      	ldr	x20, [sp, #0x140]
    5bc8:      	ldr	x23, [sp, #0x150]
    5bcc:      	cmp	x28, #0x0
    5bd0:      	b.ne	0x5e78 <_stogir.placement.early-with-uses!+0x860>
    5bd4:      	add	x16, sp, #0x80
    5bd8:      	ldr	x0, [x16, #0x8]
    5bdc:      	cmp	x19, x0
    5be0:      	b.ge	0x5e78 <_stogir.placement.early-with-uses!+0x860>
    5be4:      	add	x16, sp, #0x80
    5be8:      	ldr	x0, [x16]
    5bec:      	add	x0, x0, x19, lsl #2
    5bf0:      	ldr	w0, [x0]
    5bf4:      	sxtw	x24, w0
    5bf8:      	ldr	x1, [x20]
    5bfc:      	orr	w25, w0, wzr
    5c00:      	add	x0, x1, x24, lsl #4
    5c04:      	ldr	x0, [x0]
    5c08:      	ldr	x1, [x20, #0x78]
    5c0c:      	uxtb	w0, w0
    5c10:      	add	x1, x1, x24, lsl #2
    5c14:      	cmp	x0, #0x83
    5c18:      	cset	w27, lt
    5c1c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x480>
		0000000000005c1c:  ARM64_RELOC_PAGE21	l_stogir.428
    5c20:      	ldr	x16, [x16]
		0000000000005c20:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    5c24:      	add	x0, x16, x0, lsl #2
    5c28:      	ldr	w1, [x1]
    5c2c:      	sxtw	x1, w1
    5c30:      	mov	x3, x23
    5c34:      	mov	x2, #0x1                ; =1
    5c38:      	b	0x5c90 <_stogir.placement.early-with-uses!+0x678>
    5c3c:      	sub	w6, w4, #0x1
    5c40:      	lsl	w6, w6, #2
    5c44:      	ubfx	x6, x6, #0, #32
    5c48:      	lsr	x6, x7, x6
    5c4c:      	and	w6, w6, #0xf
    5c50:      	b	0x5cec <_stogir.placement.early-with-uses!+0x6d4>
    5c54:      	cmp	x2, #0x0
    5c58:      	b.ne	0x5c6c <_stogir.placement.early-with-uses!+0x654>
    5c5c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x480>
		0000000000005c5c:  ARM64_RELOC_PAGE21	l_stogir.430
    5c60:      	ldr	x16, [x16]
		0000000000005c60:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    5c64:      	str	x16, [sp, #0x110]
    5c68:      	mov	x28, #0x2b              ; =43
    5c6c:      	add	x0, x20, #0x1
    5c70:      	sxtw	x20, w0
    5c74:      	str	x4, [sp, #0x128]
    5c78:      	ldr	x23, [sp, #0x150]
    5c7c:      	ldr	x1, [sp, #0x138]
    5c80:      	ldr	x0, [sp, #0x130]
    5c84:      	mov	x2, x20
    5c88:      	ldr	x20, [sp, #0x140]
    5c8c:      	ldr	x3, [sp, #0x148]
    5c90:      	cmp	x28, #0x0
    5c94:      	b.ne	0x5ca8 <_stogir.placement.early-with-uses!+0x690>
    5c98:      	cmp	x2, x1
    5c9c:      	cset	w4, le
    5ca0:      	ubfx	x4, x4, #0, #8
    5ca4:      	b	0x5cac <_stogir.placement.early-with-uses!+0x694>
    5ca8:      	movz	x4, #0x0, lsl #48
    5cac:      	orr	w5, w3, wzr
    5cb0:      	cmp	x4, #0x0
    5cb4:      	b.eq	0x6018 <_stogir.placement.early-with-uses!+0xa00>
    5cb8:      	orr	w4, w2, wzr
    5cbc:      	uxtb	w16, w27
    5cc0:      	cmp	w16, wzr
    5cc4:      	b.eq	0x5cf0 <_stogir.placement.early-with-uses!+0x6d8>
    5cc8:      	sxtw	x6, w4
    5ccc:      	ldr	w7, [x0]
    5cd0:      	cmp	x6, #0x0
    5cd4:      	b.le	0x5ce8 <_stogir.placement.early-with-uses!+0x6d0>
    5cd8:      	cmp	x6, #0x4
    5cdc:      	b.le	0x5c3c <_stogir.placement.early-with-uses!+0x624>
    5ce0:      	mov	w6, #0x4                ; =4
    5ce4:      	b	0x5c40 <_stogir.placement.early-with-uses!+0x628>
    5ce8:      	movz	w6, #0x0, lsl #16
    5cec:      	b	0x5cf4 <_stogir.placement.early-with-uses!+0x6dc>
    5cf0:      	movz	w6, #0x0, lsl #16
    5cf4:      	ubfx	x6, x6, #0, #32
    5cf8:      	cmp	x6, #0xf
    5cfc:      	b.hs	0x602c <_stogir.placement.early-with-uses!+0xa14>
    5d00:      	mov	x16, #0x1               ; =1
    5d04:      	lsl	x6, x16, x6
    5d08:      	mov	w17, #0x5e1c            ; =24092
    5d0c:      	and	w6, w6, w17
    5d10:      	ubfx	x6, x6, #0, #32
    5d14:      	cmp	x6, #0x0
    5d18:      	b.eq	0x604c <_stogir.placement.early-with-uses!+0xa34>
    5d1c:      	str	x0, [sp, #0x130]
    5d20:      	mov	x0, x20
    5d24:      	str	x1, [sp, #0x138]
    5d28:      	mov	w1, w25
    5d2c:      	str	x3, [sp, #0x148]
    5d30:      	str	x20, [sp, #0x140]
    5d34:      	mov	x20, x2
    5d38:      	mov	w2, w4
    5d3c:      	str	x23, [sp, #0x150]
    5d40:      	mov	w23, w5
    5d44:      	bl	0x5d44 <_stogir.placement.early-with-uses!+0x72c>
		0000000000005d44:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5d48:      	ubfx	x0, x0, #0, #32
    5d4c:      	lsr	x16, x0, #0
    5d50:      	cmp	x16, #0x1
    5d54:      	b.eq	0x5d70 <_stogir.placement.early-with-uses!+0x758>
    5d58:      	b.lo	0x5d60 <_stogir.placement.early-with-uses!+0x748>
    5d5c:      	b	0x5d74 <_stogir.placement.early-with-uses!+0x75c>
    5d60:      	cmp	x16, #0x0
    5d64:      	b.eq	0x5d6c <_stogir.placement.early-with-uses!+0x754>
    5d68:      	b	0x5d74 <_stogir.placement.early-with-uses!+0x75c>
    5d6c:      	b	0x5d78 <_stogir.placement.early-with-uses!+0x760>
    5d70:      	b	0x5dc0 <_stogir.placement.early-with-uses!+0x7a8>
    5d74:      	b	0x5f30 <_stogir.placement.early-with-uses!+0x918>
    5d78:      	ldr	x4, [sp, #0x128]
    5d7c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x480>
		0000000000005d7c:  ARM64_RELOC_PAGE21	l_stogir.429
    5d80:      	ldr	x16, [x16]
		0000000000005d80:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    5d84:      	str	x16, [sp, #0x110]
    5d88:      	mov	x28, #0x18              ; =24
    5d8c:      	b	0x5c6c <_stogir.placement.early-with-uses!+0x654>
    5d90:      	cmp	x28, #0x0
    5d94:      	b.ne	0x606c <_stogir.placement.early-with-uses!+0xa54>
    5d98:      	ldr	x0, [x21]
    5d9c:      	add	x0, x0, x24, lsl #2
    5da0:      	str	w23, [x0]
    5da4:      	ldr	x20, [sp, #0x120]
    5da8:      	ldr	x0, [x20]
    5dac:      	add	x0, x0, x24, lsl #4
    5db0:      	ldr	x23, [x0]
    5db4:      	ldr	x24, [x0, #0x8]
    5db8:      	movz	x25, #0x0, lsl #48
    5dbc:      	b	0x5b38 <_stogir.placement.early-with-uses!+0x520>
    5dc0:      	sxtw	x1, w1
    5dc4:      	cmp	x1, #0x0
    5dc8:      	b.le	0x6074 <_stogir.placement.early-with-uses!+0xa5c>
    5dcc:      	sxtw	x23, w23
    5dd0:      	ldr	x0, [x21]
    5dd4:      	add	x0, x0, x1, lsl #2
    5dd8:      	ldr	w0, [x0]
    5ddc:      	sxtw	x0, w0
    5de0:      	mov	x2, x0
    5de4:      	movz	x1, #0x0, lsl #48
    5de8:      	movz	x3, #0x0, lsl #48
    5dec:      	b	0x5e04 <_stogir.placement.early-with-uses!+0x7ec>
    5df0:      	mov	x2, x5
    5df4:      	b	0x5e00 <_stogir.placement.early-with-uses!+0x7e8>
    5df8:      	ldr	x4, [sp, #0x128]
    5dfc:      	mov	x1, #0x1                ; =1
    5e00:      	str	x4, [sp, #0x128]
    5e04:      	cmp	x1, #0x0
    5e08:      	b.ne	0x607c <_stogir.placement.early-with-uses!+0xa64>
    5e0c:      	cmp	x2, #0x0
    5e10:      	b.le	0x5df8 <_stogir.placement.early-with-uses!+0x7e0>
    5e14:      	ldr	x4, [sp, #0x128]
    5e18:      	ldr	x5, [x4, #0x8]
    5e1c:      	cmp	x2, x5
    5e20:      	b.ge	0x5dfc <_stogir.placement.early-with-uses!+0x7e4>
    5e24:      	ldr	x5, [x4]
    5e28:      	add	x5, x5, x2, lsl #2
    5e2c:      	ldr	w5, [x5]
    5e30:      	sxtw	x5, w5
    5e34:      	cmp	x5, #0x0
    5e38:      	b.ne	0x5e44 <_stogir.placement.early-with-uses!+0x82c>
    5e3c:      	mov	x1, #0x1                ; =1
    5e40:      	b	0x5df4 <_stogir.placement.early-with-uses!+0x7dc>
    5e44:      	cmp	x2, x23
    5e48:      	b.ne	0x5e68 <_stogir.placement.early-with-uses!+0x850>
    5e4c:      	mov	x1, #0x1                ; =1
    5e50:      	mov	x3, #0x1                ; =1
    5e54:      	b	0x5df4 <_stogir.placement.early-with-uses!+0x7dc>
    5e58:      	cmp	x3, #0x0
    5e5c:      	b.eq	0x5a88 <_stogir.placement.early-with-uses!+0x470>
    5e60:      	str	x0, [sp, #0x148]
    5e64:      	b	0x5c6c <_stogir.placement.early-with-uses!+0x654>
    5e68:      	cmp	x2, x5
    5e6c:      	b.ne	0x5df0 <_stogir.placement.early-with-uses!+0x7d8>
    5e70:      	mov	x1, #0x1                ; =1
    5e74:      	b	0x5df4 <_stogir.placement.early-with-uses!+0x7dc>
    5e78:      	add	x0, sp, #0x20
    5e7c:      	bl	0x5e7c <_stogir.placement.early-with-uses!+0x864>
		0000000000005e7c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    5e80:      	add	x0, sp, #0x80
    5e84:      	bl	0x5e84 <_stogir.placement.early-with-uses!+0x86c>
		0000000000005e84:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    5e88:      	ldr	x0, [sp, #0x110]
    5e8c:      	mov	x1, x28
    5e90:      	adrp	x2, 0x5000 <_stogir.uses.build+0x480>
		0000000000005e90:  ARM64_RELOC_PAGE21	l_stogir.426
    5e94:      	ldr	x2, [x2]
		0000000000005e94:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    5e98:      	movz	x3, #0x0, lsl #48
    5e9c:      	bl	0x5e9c <_stogir.placement.early-with-uses!+0x884>
		0000000000005e9c:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    5ea0:      	cmp	x0, #0x0
    5ea4:      	b.eq	0x6084 <_stogir.placement.early-with-uses!+0xa6c>
    5ea8:      	cmp	x26, #0x0
    5eac:      	b.le	0x5ec4 <_stogir.placement.early-with-uses!+0x8ac>
    5eb0:      	mov	x1, #0x1                ; =1
    5eb4:      	adrp	x0, 0x5000 <_stogir.uses.build+0x480>
		0000000000005eb4:  ARM64_RELOC_PAGE21	l_stogir.431
    5eb8:      	ldr	x0, [x0]
		0000000000005eb8:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    5ebc:      	mov	x28, #0x39              ; =57
    5ec0:      	b	0x5ed0 <_stogir.placement.early-with-uses!+0x8b8>
    5ec4:      	and	x0, x22, #0xffffffff
    5ec8:      	movz	x1, #0x0, lsl #48
    5ecc:      	movz	x28, #0x0, lsl #48
    5ed0:      	b	0x5ed8 <_stogir.placement.early-with-uses!+0x8c0>
    5ed4:      	mov	x1, #0x1                ; =1
    5ed8:      	ldr	x2, [sp, #0x108]
    5edc:      	str	x1, [x2]
    5ee0:      	str	x0, [x2, #0x8]
    5ee4:      	str	x28, [x2, #0x10]
    5ee8:      	ldr	x19, [sp, #0x158]
    5eec:      	ldr	x20, [sp, #0x160]
    5ef0:      	ldr	x21, [sp, #0x168]
    5ef4:      	ldr	x22, [sp, #0x170]
    5ef8:      	ldr	x23, [sp, #0x178]
    5efc:      	ldr	x24, [sp, #0x180]
    5f00:      	ldr	x25, [sp, #0x188]
    5f04:      	ldr	x26, [sp, #0x190]
    5f08:      	ldr	x27, [sp, #0x198]
    5f0c:      	ldr	x28, [sp, #0x1a0]
    5f10:      	ldr	x29, [sp, #0x10]
    5f14:      	ldr	x30, [sp, #0x18]
    5f18:      	add	sp, sp, #0x1b0
    5f1c:      	ret
    5f20:      	cmp	x23, x3
    5f24:      	b.ne	0x5a94 <_stogir.placement.early-with-uses!+0x47c>
    5f28:      	mov	x1, #0x1                ; =1
    5f2c:      	b	0x5a98 <_stogir.placement.early-with-uses!+0x480>
    5f30:      	brk	#0
    5f34:      	b	0x5f30 <_stogir.placement.early-with-uses!+0x918>
    5f38:      	brk	#0
    5f3c:      	b	0x5f38 <_stogir.placement.early-with-uses!+0x920>
    5f40:      	str	x19, [sp, #0x108]
    5f44:      	str	x22, [sp, #0x128]
    5f48:      	str	x24, [sp, #0x120]
    5f4c:      	str	x27, [sp, #0x110]
    5f50:      	b	0x5a78 <_stogir.placement.early-with-uses!+0x460>
    5f54:      	str	x19, [sp, #0x108]
    5f58:      	str	x22, [sp, #0x128]
    5f5c:      	str	x24, [sp, #0x120]
    5f60:      	mov	x19, x2
    5f64:      	str	x27, [sp, #0x110]
    5f68:      	b	0x57e8 <_stogir.placement.early-with-uses!+0x1d0>
    5f6c:      	str	x19, [sp, #0x108]
    5f70:      	str	x22, [sp, #0x128]
    5f74:      	mov	x22, x5
    5f78:      	str	x24, [sp, #0x120]
    5f7c:      	mov	x19, x2
    5f80:      	str	x27, [sp, #0x110]
    5f84:      	mov	w27, w0
    5f88:      	b	0x5a30 <_stogir.placement.early-with-uses!+0x418>
    5f8c:      	str	x19, [sp, #0x108]
    5f90:      	str	x22, [sp, #0x128]
    5f94:      	mov	x22, x5
    5f98:      	str	x24, [sp, #0x120]
    5f9c:      	mov	x24, x4
    5fa0:      	mov	x19, x2
    5fa4:      	str	x27, [sp, #0x110]
    5fa8:      	mov	w27, w0
    5fac:      	str	w3, [sp, #0x100]
    5fb0:      	str	x1, [sp, #0x118]
    5fb4:      	b	0x5918 <_stogir.placement.early-with-uses!+0x300>
    5fb8:      	str	x19, [sp, #0x108]
    5fbc:      	str	x22, [sp, #0x128]
    5fc0:      	mov	x22, x5
    5fc4:      	str	x24, [sp, #0x120]
    5fc8:      	mov	x24, x4
    5fcc:      	mov	x19, x2
    5fd0:      	str	x27, [sp, #0x110]
    5fd4:      	mov	w27, w0
    5fd8:      	str	w3, [sp, #0x100]
    5fdc:      	str	x1, [sp, #0x118]
    5fe0:      	b	0x5918 <_stogir.placement.early-with-uses!+0x300>
    5fe4:      	str	x4, [sp, #0x128]
    5fe8:      	str	x20, [sp, #0x120]
    5fec:      	b	0x5bb0 <_stogir.placement.early-with-uses!+0x598>
    5ff0:      	str	x4, [sp, #0x128]
    5ff4:      	str	x20, [sp, #0x120]
    5ff8:      	b	0x5b2c <_stogir.placement.early-with-uses!+0x514>
    5ffc:      	str	x4, [sp, #0x128]
    6000:      	str	x20, [sp, #0x120]
    6004:      	b	0x5b2c <_stogir.placement.early-with-uses!+0x514>
    6008:      	str	x4, [sp, #0x128]
    600c:      	str	x20, [sp, #0x120]
    6010:      	mov	x20, x0
    6014:      	b	0x5b10 <_stogir.placement.early-with-uses!+0x4f8>
    6018:      	str	x20, [sp, #0x140]
    601c:      	ldr	x4, [sp, #0x128]
    6020:      	str	x23, [sp, #0x150]
    6024:      	mov	w23, w5
    6028:      	b	0x5d90 <_stogir.placement.early-with-uses!+0x778>
    602c:      	str	x3, [sp, #0x148]
    6030:      	str	x20, [sp, #0x140]
    6034:      	mov	x20, x2
    6038:      	ldr	x4, [sp, #0x128]
    603c:      	str	x23, [sp, #0x150]
    6040:      	str	x1, [sp, #0x138]
    6044:      	str	x0, [sp, #0x130]
    6048:      	b	0x5c6c <_stogir.placement.early-with-uses!+0x654>
    604c:      	str	x3, [sp, #0x148]
    6050:      	str	x20, [sp, #0x140]
    6054:      	mov	x20, x2
    6058:      	ldr	x4, [sp, #0x128]
    605c:      	str	x23, [sp, #0x150]
    6060:      	str	x1, [sp, #0x138]
    6064:      	str	x0, [sp, #0x130]
    6068:      	b	0x5c6c <_stogir.placement.early-with-uses!+0x654>
    606c:      	str	x4, [sp, #0x128]
    6070:      	b	0x5bc0 <_stogir.placement.early-with-uses!+0x5a8>
    6074:      	ldr	x4, [sp, #0x128]
    6078:      	b	0x5c6c <_stogir.placement.early-with-uses!+0x654>
    607c:      	ldr	x4, [sp, #0x128]
    6080:      	b	0x5e58 <_stogir.placement.early-with-uses!+0x840>
    6084:      	ldr	x0, [sp, #0x110]
    6088:      	b	0x5ed4 <_stogir.placement.early-with-uses!+0x8bc>

000000000000608c <_coil.core.Eq$slice<u8>$=>:
    608c:      	sub	sp, sp, #0x10
    6090:      	str	x29, [sp]
    6094:      	str	x30, [sp, #0x8]
    6098:      	mov	x29, sp
    609c:      	cmp	x1, x3
    60a0:      	b.ne	0x60dc <_coil.core.Eq$slice<u8>$=+0x50>
    60a4:      	cmp	x1, #0x0
    60a8:      	b.ne	0x60b4 <_coil.core.Eq$slice<u8>$=+0x28>
    60ac:      	mov	x0, #0x1                ; =1
    60b0:      	b	0x60d8 <_coil.core.Eq$slice<u8>$=+0x4c>
    60b4:      	lsr	x1, x1, #0
    60b8:      	fmov	d31, x1
    60bc:      	mov	x1, x2
    60c0:      	fmov	x2, d31
    60c4:      	bl	0x60c4 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000060c4:  ARM64_RELOC_BRANCH26	_memcmp
    60c8:      	sxtw	x0, w0
    60cc:      	cmp	x0, #0x0
    60d0:      	cset	w0, eq
    60d4:      	ubfx	x0, x0, #0, #8
    60d8:      	b	0x60e0 <_coil.core.Eq$slice<u8>$=+0x54>
    60dc:      	movz	x0, #0x0, lsl #48
    60e0:      	ldr	x29, [sp]
    60e4:      	ldr	x30, [sp, #0x8]
    60e8:      	add	sp, sp, #0x10
    60ec:      	ret

00000000000060f0 <_stogir.placement.late-with-uses!>:
    60f0:      	sub	sp, sp, #0x1e0
    60f4:      	str	x29, [sp]
    60f8:      	str	x30, [sp, #0x8]
    60fc:      	mov	x29, sp
    6100:      	str	x19, [sp, #0x190]
    6104:      	str	x20, [sp, #0x198]
    6108:      	str	x21, [sp, #0x1a0]
    610c:      	str	x22, [sp, #0x1a8]
    6110:      	str	x23, [sp, #0x1b0]
    6114:      	str	x24, [sp, #0x1b8]
    6118:      	str	x25, [sp, #0x1c0]
    611c:      	str	x26, [sp, #0x1c8]
    6120:      	str	x27, [sp, #0x1d0]
    6124:      	str	x28, [sp, #0x1d8]
    6128:      	mov	x19, x8
    612c:      	add	x8, sp, #0x40
    6130:      	mov	x20, x0
    6134:      	mov	x0, x6
    6138:      	mov	x21, x1
    613c:      	mov	x22, x2
    6140:      	mov	x23, x3
    6144:      	mov	x24, x4
    6148:      	mov	x25, x5
    614c:      	mov	x26, x6
    6150:      	bl	0x6150 <_stogir.placement.late-with-uses!+0x60>
		0000000000006150:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    6154:      	add	x16, sp, #0x40
    6158:      	ldr	x0, [x16]
    615c:      	add	x16, sp, #0x10
    6160:      	str	x0, [x16]
    6164:      	add	x16, sp, #0x40
    6168:      	ldr	x0, [x16, #0x8]
    616c:      	add	x16, sp, #0x10
    6170:      	str	x0, [x16, #0x8]
    6174:      	add	x16, sp, #0x40
    6178:      	ldr	x0, [x16, #0x10]
    617c:      	add	x16, sp, #0x10
    6180:      	str	x0, [x16, #0x10]
    6184:      	add	x16, sp, #0x40
    6188:      	ldr	x0, [x16, #0x18]
    618c:      	add	x16, sp, #0x10
    6190:      	str	x0, [x16, #0x18]
    6194:      	add	x16, sp, #0x40
    6198:      	ldr	x0, [x16, #0x20]
    619c:      	add	x16, sp, #0x10
    61a0:      	str	x0, [x16, #0x20]
    61a4:      	add	x8, sp, #0xa0
    61a8:      	mov	x0, x26
    61ac:      	bl	0x61ac <_stogir.placement.late-with-uses!+0xbc>
		00000000000061ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    61b0:      	add	x16, sp, #0xa0
    61b4:      	ldr	x0, [x16]
    61b8:      	add	x16, sp, #0x70
    61bc:      	str	x0, [x16]
    61c0:      	add	x16, sp, #0xa0
    61c4:      	ldr	x0, [x16, #0x8]
    61c8:      	add	x16, sp, #0x70
    61cc:      	str	x0, [x16, #0x8]
    61d0:      	add	x16, sp, #0xa0
    61d4:      	ldr	x0, [x16, #0x10]
    61d8:      	add	x16, sp, #0x70
    61dc:      	str	x0, [x16, #0x10]
    61e0:      	add	x16, sp, #0xa0
    61e4:      	ldr	x0, [x16, #0x18]
    61e8:      	add	x16, sp, #0x70
    61ec:      	str	x0, [x16, #0x18]
    61f0:      	add	x16, sp, #0xa0
    61f4:      	ldr	x0, [x16, #0x20]
    61f8:      	add	x16, sp, #0x70
    61fc:      	str	x0, [x16, #0x20]
    6200:      	movz	x26, #0x0, lsl #48
    6204:      	b	0x621c <_stogir.placement.late-with-uses!+0x12c>
    6208:      	add	x26, x26, #0x1
    620c:      	add	x0, sp, #0x10
    6210:      	mov	x1, #0xffff             ; =65535
    6214:      	movk	x1, #0xffff, lsl #16
    6218:      	bl	0x6218 <_stogir.placement.late-with-uses!+0x128>
		0000000000006218:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    621c:      	ldr	x0, [x20, #0x8]
    6220:      	cmp	x26, x0
    6224:      	b.lt	0x6208 <_stogir.placement.late-with-uses!+0x118>
    6228:      	add	x26, x20, #0x78
    622c:      	mov	x27, #0x1               ; =1
    6230:      	movz	x28, #0x0, lsl #48
    6234:      	b	0x6270 <_stogir.placement.late-with-uses!+0x180>
    6238:      	add	x28, x28, #0x1
    623c:      	add	x0, sp, #0x10
    6240:      	mov	x1, x27
    6244:      	movz	x2, #0x0, lsl #48
    6248:      	bl	0x6248 <_stogir.placement.late-with-uses!+0x158>
		0000000000006248:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    624c:      	sxtw	x28, w28
    6250:      	sxtw	x23, w23
    6254:      	add	x0, x23, #0x4
    6258:      	asr	x16, x0, #63
    625c:      	lsr	x16, x16, #62
    6260:      	add	x0, x0, x16
    6264:      	asr	x0, x0, #2
    6268:      	add	x27, x0, x27
    626c:      	ldr	x23, [sp, #0x110]
    6270:      	ldr	x0, [x20, #0x8]
    6274:      	cmp	x27, x0
    6278:      	b.ge	0x6ba0 <_stogir.placement.late-with-uses!+0xab0>
    627c:      	ldr	x0, [x20]
    6280:      	add	x0, x0, x27, lsl #4
    6284:      	ldr	x0, [x0]
    6288:      	ldr	x1, [x20, #0x78]
    628c:      	uxtb	w0, w0
    6290:      	add	x1, x1, x27, lsl #2
    6294:      	ldr	w1, [x1]
    6298:      	str	x23, [sp, #0x110]
    629c:      	mov	w23, w1
    62a0:      	bl	0x62a0 <_stogir.placement.late-with-uses!+0x1b0>
		00000000000062a0:  ARM64_RELOC_BRANCH26	_stogir.opcode.properties
    62a4:      	ldr	x1, [x24]
    62a8:      	add	x1, x27, x1
    62ac:      	ldrb	w1, [x1]
    62b0:      	cmp	x1, #0x0
    62b4:      	b.eq	0x6250 <_stogir.placement.late-with-uses!+0x160>
    62b8:      	uxtb	w0, w0
    62bc:      	uxtb	w16, w0
    62c0:      	and	w0, w16, #0x40
    62c4:      	uxtb	w0, w0
    62c8:      	ubfx	x0, x0, #0, #8
    62cc:      	cmp	x0, #0x0
    62d0:      	b.ne	0x6238 <_stogir.placement.late-with-uses!+0x148>
    62d4:      	b	0x6250 <_stogir.placement.late-with-uses!+0x160>
    62d8:      	mov	x23, #0x1               ; =1
    62dc:      	b	0x6358 <_stogir.placement.late-with-uses!+0x268>
    62e0:      	add	x3, x27, #0x1
    62e4:      	sxtw	x27, w3
    62e8:      	add	x2, x2, #0x1
    62ec:      	cmp	x2, x0
    62f0:      	b.ge	0x6328 <_stogir.placement.late-with-uses!+0x238>
    62f4:      	add	x3, x1, x2
    62f8:      	ldr	x4, [x25, #0x28]
    62fc:      	add	x3, x4, x3, lsl #3
    6300:      	ldr	x3, [x3]
    6304:      	add	x16, sp, #0x10
    6308:      	ldr	x4, [x16]
    630c:      	sxtw	x3, w3
    6310:      	add	x3, x4, x3, lsl #2
    6314:      	ldr	w3, [x3]
    6318:      	sxtw	x3, w3
    631c:      	cmp	x3, #0x0
    6320:      	b.ge	0x62e0 <_stogir.placement.late-with-uses!+0x1f0>
    6324:      	b	0x62e8 <_stogir.placement.late-with-uses!+0x1f8>
    6328:      	orr	w0, w27, wzr
    632c:      	mov	x1, x23
    6330:      	mov	w2, w0
    6334:      	add	x0, sp, #0x10
    6338:      	bl	0x6338 <_stogir.placement.late-with-uses!+0x248>
		0000000000006338:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    633c:      	cmp	x27, #0x0
    6340:      	b.ne	0x6354 <_stogir.placement.late-with-uses!+0x264>
    6344:      	orr	w0, w23, wzr
    6348:      	mov	w1, w0
    634c:      	add	x0, sp, #0x70
    6350:      	bl	0x6350 <_stogir.placement.late-with-uses!+0x260>
		0000000000006350:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    6354:      	add	x23, x23, #0x1
    6358:      	add	x16, sp, #0x10
    635c:      	ldr	x0, [x16, #0x8]
    6360:      	cmp	x23, x0
    6364:      	b.ge	0x63a0 <_stogir.placement.late-with-uses!+0x2b0>
    6368:      	add	x16, sp, #0x10
    636c:      	ldr	x0, [x16]
    6370:      	add	x0, x0, x23, lsl #2
    6374:      	ldr	w0, [x0]
    6378:      	sxtw	x0, w0
    637c:      	cmp	x0, #0x0
    6380:      	b.ne	0x6354 <_stogir.placement.late-with-uses!+0x264>
    6384:      	ldr	x0, [x25]
    6388:      	add	x0, x0, x23, lsl #4
    638c:      	ldr	x1, [x0]
    6390:      	ldr	x0, [x0, #0x8]
    6394:      	movz	x2, #0x0, lsl #48
    6398:      	movz	x27, #0x0, lsl #48
    639c:      	b	0x62ec <_stogir.placement.late-with-uses!+0x1fc>
    63a0:      	add	x16, sp, #0xd0
    63a4:      	orr	x0, x16, xzr
    63a8:      	add	x16, sp, #0xf0
    63ac:      	orr	x1, x16, xzr
    63b0:      	add	x23, x0, #0x8
    63b4:      	add	x27, x1, #0x8
    63b8:      	movz	x0, #0x0, lsl #48
    63bc:      	adrp	x1, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		00000000000063bc:  ARM64_RELOC_PAGE21	l_stogir.432
    63c0:      	ldr	x1, [x1]
		00000000000063c0:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    63c4:      	movz	x2, #0x0, lsl #48
    63c8:      	b	0x6414 <_stogir.placement.late-with-uses!+0x324>
    63cc:      	movz	w6, #0x0, lsl #16
    63d0:      	movz	w5, #0x0, lsl #16
    63d4:      	b	0x67d4 <_stogir.placement.late-with-uses!+0x6e4>
    63d8:      	ldr	x19, [sp, #0x120]
    63dc:      	sub	x0, x19, #0x1
    63e0:      	sxtw	x19, w0
    63e4:      	ldr	x0, [sp, #0x150]
    63e8:      	add	x0, x0, #0x1
    63ec:      	mov	x20, x27
    63f0:      	ldr	x21, [sp, #0x188]
    63f4:      	ldr	x24, [sp, #0x130]
    63f8:      	ldr	x25, [sp, #0x148]
    63fc:      	ldr	x27, [sp, #0x160]
    6400:      	mov	x1, x28
    6404:      	mov	x28, x19
    6408:      	ldr	x19, [sp, #0x118]
    640c:      	mov	x2, x26
    6410:      	ldr	x26, [sp, #0x128]
    6414:      	str	x19, [sp, #0x118]
    6418:      	mov	x19, x0
    641c:      	mov	x0, x1
    6420:      	str	x28, [sp, #0x120]
    6424:      	mov	x28, x1
    6428:      	mov	x1, x2
    642c:      	str	x26, [sp, #0x128]
    6430:      	mov	x26, x2
    6434:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		0000000000006434:  ARM64_RELOC_PAGE21	l_stogir.432
    6438:      	ldr	x2, [x2]
		0000000000006438:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    643c:      	movz	x3, #0x0, lsl #48
    6440:      	bl	0x6440 <_stogir.placement.late-with-uses!+0x350>
		0000000000006440:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6444:      	cmp	x0, #0x0
    6448:      	b.eq	0x6464 <_stogir.placement.late-with-uses!+0x374>
    644c:      	add	x0, sp, #0x70
    6450:      	bl	0x6450 <_stogir.placement.late-with-uses!+0x360>
		0000000000006450:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    6454:      	cmp	x19, x0
    6458:      	cset	w0, lt
    645c:      	ubfx	x0, x0, #0, #8
    6460:      	b	0x6468 <_stogir.placement.late-with-uses!+0x378>
    6464:      	movz	x0, #0x0, lsl #48
    6468:      	cmp	x0, #0x0
    646c:      	b.eq	0x6ba8 <_stogir.placement.late-with-uses!+0xab8>
    6470:      	add	x16, sp, #0x70
    6474:      	ldr	x0, [x16]
    6478:      	add	x0, x0, x19, lsl #2
    647c:      	ldr	w0, [x0]
    6480:      	sxtw	x0, w0
    6484:      	ldr	x1, [x25]
    6488:      	add	x1, x1, x0, lsl #4
    648c:      	ldr	x2, [x1]
    6490:      	ldr	x1, [x1, #0x8]
    6494:      	movz	x3, #0x0, lsl #48
    6498:      	movz	w4, #0x0, lsl #16
    649c:      	b	0x64d0 <_stogir.placement.late-with-uses!+0x3e0>
    64a0:      	movz	x19, #0x0, lsl #48
    64a4:      	add	x25, x25, #0x1
    64a8:      	ldr	x20, [sp, #0x158]
    64ac:      	mov	x0, x24
    64b0:      	ldr	x24, [sp, #0x130]
    64b4:      	ldr	x2, [sp, #0x138]
    64b8:      	ldr	x1, [sp, #0x140]
    64bc:      	ldr	x27, [sp, #0x160]
    64c0:      	mov	x3, x25
    64c4:      	ldr	x25, [sp, #0x148]
    64c8:      	mov	w4, w19
    64cc:      	ldr	x19, [sp, #0x150]
    64d0:      	cmp	x26, #0x0
    64d4:      	b.ne	0x64e8 <_stogir.placement.late-with-uses!+0x3f8>
    64d8:      	cmp	x3, x1
    64dc:      	cset	w5, lt
    64e0:      	ubfx	x5, x5, #0, #8
    64e4:      	b	0x64ec <_stogir.placement.late-with-uses!+0x3fc>
    64e8:      	movz	x5, #0x0, lsl #48
    64ec:      	sxtw	x6, w4
    64f0:      	cmp	x6, #0x0
    64f4:      	cset	w7, eq
    64f8:      	cmp	x5, #0x0
    64fc:      	b.eq	0x6bb0 <_stogir.placement.late-with-uses!+0xac0>
    6500:      	add	x5, x2, x3
    6504:      	ldr	x8, [x25, #0x28]
    6508:      	add	x5, x8, x5, lsl #3
    650c:      	ldr	x5, [x5]
    6510:      	ldr	x8, [x24]
    6514:      	orr	w9, w5, wzr
    6518:      	sxtw	x10, w9
    651c:      	add	x8, x8, x10
    6520:      	ldrb	w8, [x8]
    6524:      	cmp	x8, #0x0
    6528:      	b.eq	0x6bd4 <_stogir.placement.late-with-uses!+0xae4>
    652c:      	lsr	x5, x5, #32
    6530:      	add	x8, sp, #0xd0
    6534:      	str	x2, [sp, #0x138]
    6538:      	mov	w2, w9
    653c:      	str	x1, [sp, #0x140]
    6540:      	mov	x1, x21
    6544:      	str	x24, [sp, #0x130]
    6548:      	mov	x24, x0
    654c:      	mov	x0, x20
    6550:      	str	x25, [sp, #0x148]
    6554:      	mov	x25, x3
    6558:      	mov	w3, w5
    655c:      	str	x19, [sp, #0x150]
    6560:      	mov	w19, w4
    6564:      	str	x20, [sp, #0x158]
    6568:      	mov	x20, x6
    656c:      	str	x27, [sp, #0x160]
    6570:      	mov	w27, w7
    6574:      	bl	0x6574 <_stogir.placement.late-with-uses!+0x484>
		0000000000006574:  ARM64_RELOC_BRANCH26	_stogir.placement.use-block
    6578:      	add	x16, sp, #0xd0
    657c:      	ldr	w0, [x16]
    6580:      	lsr	x16, x0, #0
    6584:      	cmp	x16, #0x1
    6588:      	b.eq	0x65a4 <_stogir.placement.late-with-uses!+0x4b4>
    658c:      	b.lo	0x6594 <_stogir.placement.late-with-uses!+0x4a4>
    6590:      	b	0x65a8 <_stogir.placement.late-with-uses!+0x4b8>
    6594:      	cmp	x16, #0x0
    6598:      	b.eq	0x65a0 <_stogir.placement.late-with-uses!+0x4b0>
    659c:      	b	0x65a8 <_stogir.placement.late-with-uses!+0x4b8>
    65a0:      	b	0x65bc <_stogir.placement.late-with-uses!+0x4cc>
    65a4:      	b	0x65ac <_stogir.placement.late-with-uses!+0x4bc>
    65a8:      	b	0x6a58 <_stogir.placement.late-with-uses!+0x968>
    65ac:      	add	x16, sp, #0xd0
    65b0:      	ldr	x28, [x16, #0x8]
    65b4:      	ldr	x26, [x23, #0x8]
    65b8:      	b	0x64a4 <_stogir.placement.late-with-uses!+0x3b4>
    65bc:      	add	x16, sp, #0xd0
    65c0:      	ldr	w0, [x16, #0x8]
    65c4:      	orr	w1, w0, wzr
    65c8:      	uxtb	w16, w27
    65cc:      	cmp	w16, wzr
    65d0:      	b.eq	0x660c <_stogir.placement.late-with-uses!+0x51c>
    65d4:      	mov	w19, w1
    65d8:      	b	0x64a4 <_stogir.placement.late-with-uses!+0x3b4>
    65dc:      	mov	x0, x28
    65e0:      	mov	x1, x26
    65e4:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		00000000000065e4:  ARM64_RELOC_PAGE21	l_stogir.432
    65e8:      	ldr	x2, [x2]
		00000000000065e8:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    65ec:      	movz	x3, #0x0, lsl #48
    65f0:      	bl	0x65f0 <_stogir.placement.late-with-uses!+0x500>
		00000000000065f0:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    65f4:      	cmp	x0, #0x0
    65f8:      	b.eq	0x666c <_stogir.placement.late-with-uses!+0x57c>
    65fc:      	uxtb	w16, w27
    6600:      	cmp	w16, wzr
    6604:      	cset	x0, eq
    6608:      	b	0x6670 <_stogir.placement.late-with-uses!+0x580>
    660c:      	cmp	x20, #0x0
    6610:      	b.le	0x64a0 <_stogir.placement.late-with-uses!+0x3b0>
    6614:      	sxtw	x0, w0
    6618:      	cmp	x0, #0x0
    661c:      	b.le	0x64a0 <_stogir.placement.late-with-uses!+0x3b0>
    6620:      	ldr	x2, [x22, #0x8]
    6624:      	cmp	x20, x2
    6628:      	b.ge	0x64a0 <_stogir.placement.late-with-uses!+0x3b0>
    662c:      	cmp	x0, x2
    6630:      	b.ge	0x64a0 <_stogir.placement.late-with-uses!+0x3b0>
    6634:      	ldr	x2, [x22]
    6638:      	add	x3, x2, x20, lsl #2
    663c:      	ldr	w3, [x3]
    6640:      	sxtw	x3, w3
    6644:      	cmp	x3, #0x0
    6648:      	b.eq	0x6a50 <_stogir.placement.late-with-uses!+0x960>
    664c:      	add	x0, x2, x0, lsl #2
    6650:      	ldr	w0, [x0]
    6654:      	sxtw	x0, w0
    6658:      	cmp	x0, #0x0
    665c:      	b.eq	0x6a50 <_stogir.placement.late-with-uses!+0x960>
    6660:      	mov	w2, w19
    6664:      	movz	x0, #0x0, lsl #48
    6668:      	b	0x6b68 <_stogir.placement.late-with-uses!+0xa78>
    666c:      	movz	x0, #0x0, lsl #48
    6670:      	lsl	x20, x24, #2
    6674:      	cmp	x0, #0x0
    6678:      	b.eq	0x6c00 <_stogir.placement.late-with-uses!+0xb10>
    667c:      	ldr	x0, [x21]
    6680:      	add	x0, x20, x0
    6684:      	ldr	w0, [x0]
    6688:      	add	x8, sp, #0xf0
    668c:      	ldr	x1, [sp, #0x110]
    6690:      	mov	w2, w0
    6694:      	mov	x0, x22
    6698:      	mov	w3, w19
    669c:      	bl	0x669c <_stogir.placement.late-with-uses!+0x5ac>
		000000000000669c:  ARM64_RELOC_BRANCH26	_stogir.placement.choose-block
    66a0:      	add	x16, sp, #0xf0
    66a4:      	ldr	w0, [x16]
    66a8:      	lsr	x16, x0, #0
    66ac:      	cmp	x16, #0x1
    66b0:      	b.eq	0x66d0 <_stogir.placement.late-with-uses!+0x5e0>
    66b4:      	b.lo	0x66bc <_stogir.placement.late-with-uses!+0x5cc>
    66b8:      	b	0x66d4 <_stogir.placement.late-with-uses!+0x5e4>
    66bc:      	cmp	x16, #0x0
    66c0:      	b.eq	0x66c8 <_stogir.placement.late-with-uses!+0x5d8>
    66c4:      	b	0x66d4 <_stogir.placement.late-with-uses!+0x5e4>
    66c8:      	ldr	x19, [sp, #0x160]
    66cc:      	b	0x66ec <_stogir.placement.late-with-uses!+0x5fc>
    66d0:      	b	0x66d8 <_stogir.placement.late-with-uses!+0x5e8>
    66d4:      	b	0x6b98 <_stogir.placement.late-with-uses!+0xaa8>
    66d8:      	add	x16, sp, #0xf0
    66dc:      	ldr	x28, [x16, #0x8]
    66e0:      	ldr	x19, [sp, #0x160]
    66e4:      	ldr	x26, [x19, #0x8]
    66e8:      	b	0x6704 <_stogir.placement.late-with-uses!+0x614>
    66ec:      	add	x16, sp, #0xf0
    66f0:      	ldr	w0, [x16, #0x8]
    66f4:      	mov	x1, x24
    66f8:      	mov	w2, w0
    66fc:      	mov	x0, x21
    6700:      	bl	0x6700 <_stogir.placement.late-with-uses!+0x610>
		0000000000006700:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    6704:      	mov	x0, x28
    6708:      	mov	x1, x26
    670c:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		000000000000670c:  ARM64_RELOC_PAGE21	l_stogir.432
    6710:      	ldr	x2, [x2]
		0000000000006710:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    6714:      	movz	x3, #0x0, lsl #48
    6718:      	bl	0x6718 <_stogir.placement.late-with-uses!+0x628>
		0000000000006718:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    671c:      	cmp	x0, #0x0
    6720:      	b.eq	0x6c08 <_stogir.placement.late-with-uses!+0xb18>
    6724:      	cmp	x24, #0x0
    6728:      	cset	w25, le
    672c:      	ldr	x27, [sp, #0x158]
    6730:      	ldr	x0, [x27]
    6734:      	add	x0, x0, x24, lsl #4
    6738:      	ldr	x0, [x0]
    673c:      	ldr	x1, [x27, #0x78]
    6740:      	uxtb	w0, w0
    6744:      	add	x1, x1, x24, lsl #2
    6748:      	cmp	x0, #0x83
    674c:      	cset	w2, lt
    6750:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		0000000000006750:  ARM64_RELOC_PAGE21	l_stogir.433
    6754:      	ldr	x16, [x16]
		0000000000006754:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    6758:      	add	x0, x16, x0, lsl #2
    675c:      	ldr	w1, [x1]
    6760:      	sxtw	x1, w1
    6764:      	mov	x3, #0x1                ; =1
    6768:      	b	0x6854 <_stogir.placement.late-with-uses!+0x764>
    676c:      	sub	w4, w4, #0x1
    6770:      	lsl	w4, w4, #2
    6774:      	ubfx	x4, x4, #0, #32
    6778:      	lsr	x4, x6, x4
    677c:      	and	w4, w4, #0xf
    6780:      	b	0x6788 <_stogir.placement.late-with-uses!+0x698>
    6784:      	movz	w4, #0x0, lsl #16
    6788:      	b	0x6794 <_stogir.placement.late-with-uses!+0x6a4>
    678c:      	nop
    6790:      	movz	w4, #0x0, lsl #16
    6794:      	ubfx	x4, x4, #0, #32
    6798:      	cmp	x4, #0xf
    679c:      	b.hs	0x6c1c <_stogir.placement.late-with-uses!+0xb2c>
    67a0:      	mov	x16, #0x1               ; =1
    67a4:      	lsl	x4, x16, x4
    67a8:      	mov	w17, #0x5e1c            ; =24092
    67ac:      	and	w4, w4, w17
    67b0:      	ubfx	x4, x4, #0, #32
    67b4:      	cmp	x4, #0x0
    67b8:      	b.eq	0x6c3c <_stogir.placement.late-with-uses!+0xb4c>
    67bc:      	uxtb	w16, w25
    67c0:      	cmp	w16, wzr
    67c4:      	b.eq	0x688c <_stogir.placement.late-with-uses!+0x79c>
    67c8:      	ldr	x4, [sp, #0x128]
    67cc:      	movz	w6, #0x0, lsl #16
    67d0:      	movz	w5, #0x0, lsl #16
    67d4:      	ubfx	x6, x6, #0, #32
    67d8:      	lsr	x16, x6, #0
    67dc:      	cmp	x16, #0x1
    67e0:      	b.eq	0x67fc <_stogir.placement.late-with-uses!+0x70c>
    67e4:      	b.lo	0x67ec <_stogir.placement.late-with-uses!+0x6fc>
    67e8:      	b	0x6800 <_stogir.placement.late-with-uses!+0x710>
    67ec:      	cmp	x16, #0x0
    67f0:      	b.eq	0x67f8 <_stogir.placement.late-with-uses!+0x708>
    67f4:      	b	0x6800 <_stogir.placement.late-with-uses!+0x710>
    67f8:      	b	0x6804 <_stogir.placement.late-with-uses!+0x714>
    67fc:      	b	0x68c8 <_stogir.placement.late-with-uses!+0x7d8>
    6800:      	b	0x6b90 <_stogir.placement.late-with-uses!+0xaa0>
    6804:      	str	x21, [sp, #0x188]
    6808:      	str	x4, [sp, #0x128]
    680c:      	str	x20, [sp, #0x180]
    6810:      	str	x19, [sp, #0x160]
    6814:      	mov	x19, x3
    6818:      	str	x1, [sp, #0x178]
    681c:      	str	w2, [sp, #0x168]
    6820:      	str	x0, [sp, #0x170]
    6824:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		0000000000006824:  ARM64_RELOC_PAGE21	l_stogir.434
    6828:      	ldr	x28, [x28]
		0000000000006828:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    682c:      	mov	x26, #0x1e              ; =30
    6830:      	add	x0, x19, #0x1
    6834:      	sxtw	x19, w0
    6838:      	ldr	x21, [sp, #0x188]
    683c:      	ldr	x20, [sp, #0x180]
    6840:      	ldr	x1, [sp, #0x178]
    6844:      	ldr	w2, [sp, #0x168]
    6848:      	ldr	x0, [sp, #0x170]
    684c:      	mov	x3, x19
    6850:      	ldr	x19, [sp, #0x160]
    6854:      	cmp	x3, x1
    6858:      	b.gt	0x6c5c <_stogir.placement.late-with-uses!+0xb6c>
    685c:      	orr	w4, w3, wzr
    6860:      	sxtw	x5, w4
    6864:      	uxtb	w16, w2
    6868:      	cmp	w16, wzr
    686c:      	b.eq	0x6790 <_stogir.placement.late-with-uses!+0x6a0>
    6870:      	ldr	w6, [x0]
    6874:      	cmp	x5, #0x0
    6878:      	b.le	0x6784 <_stogir.placement.late-with-uses!+0x694>
    687c:      	cmp	x5, #0x4
    6880:      	b.le	0x676c <_stogir.placement.late-with-uses!+0x67c>
    6884:      	mov	w4, #0x4                ; =4
    6888:      	b	0x6770 <_stogir.placement.late-with-uses!+0x680>
    688c:      	ldr	x4, [x27, #0x8]
    6890:      	cmp	x24, x4
    6894:      	b.ge	0x6c68 <_stogir.placement.late-with-uses!+0xb78>
    6898:      	ldr	x4, [sp, #0x128]
    689c:      	ldr	x6, [x4, #0x8]
    68a0:      	cmp	x24, x6
    68a4:      	b.ge	0x692c <_stogir.placement.late-with-uses!+0x83c>
    68a8:      	ldr	x6, [x27, #0x78]
    68ac:      	add	x6, x20, x6
    68b0:      	ldr	w6, [x6]
    68b4:      	sxtw	x6, w6
    68b8:      	cmp	x6, #0x0
    68bc:      	cset	w6, ge
    68c0:      	ubfx	x6, x6, #0, #8
    68c4:      	b	0x6930 <_stogir.placement.late-with-uses!+0x840>
    68c8:      	sxtw	x6, w5
    68cc:      	cmp	x6, #0x0
    68d0:      	b.le	0x6c70 <_stogir.placement.late-with-uses!+0xb80>
    68d4:      	add	x16, sp, #0x10
    68d8:      	ldr	x7, [x16]
    68dc:      	add	x8, x7, x6, lsl #2
    68e0:      	ldr	w8, [x8]
    68e4:      	sxtw	x9, w8
    68e8:      	cmp	x9, #0x0
    68ec:      	b.le	0x6c94 <_stogir.placement.late-with-uses!+0xba4>
    68f0:      	sub	w8, w8, #0x1
    68f4:      	add	x6, x7, x6, lsl #2
    68f8:      	str	w8, [x6]
    68fc:      	cmp	x9, #0x1
    6900:      	b.ne	0x6cb8 <_stogir.placement.late-with-uses!+0xbc8>
    6904:      	add	x16, sp, #0x70
    6908:      	ldr	x6, [x16, #0x8]
    690c:      	add	x16, sp, #0x70
    6910:      	ldr	x7, [x16, #0x10]
    6914:      	cmp	x6, x7
    6918:      	b.lt	0x6cdc <_stogir.placement.late-with-uses!+0xbec>
    691c:      	cmp	x7, #0x0
    6920:      	b.ne	0x6a60 <_stogir.placement.late-with-uses!+0x970>
    6924:      	mov	x7, #0x2                ; =2
    6928:      	b	0x6a64 <_stogir.placement.late-with-uses!+0x974>
    692c:      	movz	x6, #0x0, lsl #48
    6930:      	b	0x6938 <_stogir.placement.late-with-uses!+0x848>
    6934:      	movz	x6, #0x0, lsl #48
    6938:      	cmp	x6, #0x0
    693c:      	b.eq	0x67cc <_stogir.placement.late-with-uses!+0x6dc>
    6940:      	cmp	x5, #0x1
    6944:      	b.lt	0x63cc <_stogir.placement.late-with-uses!+0x2dc>
    6948:      	ldr	x6, [x27, #0x78]
    694c:      	add	x6, x20, x6
    6950:      	ldr	w6, [x6]
    6954:      	sxtw	x6, w6
    6958:      	cmp	x5, x6
    695c:      	b.gt	0x63cc <_stogir.placement.late-with-uses!+0x2dc>
    6960:      	ldr	x6, [x27]
    6964:      	asr	x16, x5, #63
    6968:      	lsr	x16, x16, #62
    696c:      	add	x7, x5, x16
    6970:      	asr	x7, x7, #2
    6974:      	asr	x16, x5, #63
    6978:      	lsr	x16, x16, #62
    697c:      	add	x5, x5, x16
    6980:      	and	x5, x5, #0x3
    6984:      	sub	x5, x5, x16
    6988:      	add	x7, x7, x24
    698c:      	add	x6, x6, x7, lsl #4
    6990:      	add	x5, x6, x5, lsl #2
    6994:      	ldr	w5, [x5]
    6998:      	movn	w17, #0x0, lsl #16
    699c:      	and	w5, w5, w17
    69a0:      	mov	w6, #0x1                ; =1
    69a4:      	b	0x63d4 <_stogir.placement.late-with-uses!+0x2e4>
    69a8:      	add	x0, sp, #0x10
    69ac:      	bl	0x69ac <_stogir.placement.late-with-uses!+0x8bc>
		00000000000069ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    69b0:      	add	x0, sp, #0x70
    69b4:      	bl	0x69b4 <_stogir.placement.late-with-uses!+0x8c4>
		00000000000069b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    69b8:      	mov	x0, x28
    69bc:      	mov	x1, x26
    69c0:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		00000000000069c0:  ARM64_RELOC_PAGE21	l_stogir.432
    69c4:      	ldr	x2, [x2]
		00000000000069c4:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    69c8:      	movz	x3, #0x0, lsl #48
    69cc:      	bl	0x69cc <_stogir.placement.late-with-uses!+0x8dc>
		00000000000069cc:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    69d0:      	cmp	x0, #0x0
    69d4:      	b.eq	0x6a04 <_stogir.placement.late-with-uses!+0x914>
    69d8:      	cmp	x19, #0x0
    69dc:      	b.le	0x69f4 <_stogir.placement.late-with-uses!+0x904>
    69e0:      	mov	x0, #0x1                ; =1
    69e4:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		00000000000069e4:  ARM64_RELOC_PAGE21	l_stogir.435
    69e8:      	ldr	x28, [x28]
		00000000000069e8:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    69ec:      	mov	x26, #0x26              ; =38
    69f0:      	b	0x6a00 <_stogir.placement.late-with-uses!+0x910>
    69f4:      	movz	x0, #0x0, lsl #48
    69f8:      	movz	x28, #0x0, lsl #48
    69fc:      	movz	x26, #0x0, lsl #48
    6a00:      	b	0x6a08 <_stogir.placement.late-with-uses!+0x918>
    6a04:      	mov	x0, #0x1                ; =1
    6a08:      	ldr	x1, [sp, #0x118]
    6a0c:      	str	x0, [x1]
    6a10:      	str	x28, [x1, #0x8]
    6a14:      	str	x26, [x1, #0x10]
    6a18:      	ldr	x19, [sp, #0x190]
    6a1c:      	ldr	x20, [sp, #0x198]
    6a20:      	ldr	x21, [sp, #0x1a0]
    6a24:      	ldr	x22, [sp, #0x1a8]
    6a28:      	ldr	x23, [sp, #0x1b0]
    6a2c:      	ldr	x24, [sp, #0x1b8]
    6a30:      	ldr	x25, [sp, #0x1c0]
    6a34:      	ldr	x26, [sp, #0x1c8]
    6a38:      	ldr	x27, [sp, #0x1d0]
    6a3c:      	ldr	x28, [sp, #0x1d8]
    6a40:      	ldr	x29, [sp]
    6a44:      	ldr	x30, [sp, #0x8]
    6a48:      	add	sp, sp, #0x1e0
    6a4c:      	ret
    6a50:      	movz	x19, #0x0, lsl #48
    6a54:      	b	0x64a4 <_stogir.placement.late-with-uses!+0x3b4>
    6a58:      	brk	#0
    6a5c:      	b	0x6a58 <_stogir.placement.late-with-uses!+0x968>
    6a60:      	lsl	x7, x7, #1
    6a64:      	str	w2, [sp, #0x168]
    6a68:      	str	x0, [sp, #0x170]
    6a6c:      	add	x0, sp, #0x70
    6a70:      	str	x1, [sp, #0x178]
    6a74:      	mov	x1, x7
    6a78:      	str	x4, [sp, #0x128]
    6a7c:      	str	x19, [sp, #0x160]
    6a80:      	mov	x19, x3
    6a84:      	str	x20, [sp, #0x180]
    6a88:      	mov	w20, w5
    6a8c:      	str	x21, [sp, #0x188]
    6a90:      	mov	x21, x6
    6a94:      	bl	0x6a94 <_stogir.placement.late-with-uses!+0x9a4>
		0000000000006a94:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    6a98:      	add	x0, x21, #0x1
    6a9c:      	add	x16, sp, #0x70
    6aa0:      	ldr	x1, [x16]
    6aa4:      	add	x1, x1, x21, lsl #2
    6aa8:      	str	w20, [x1]
    6aac:      	add	x16, sp, #0x70
    6ab0:      	str	x0, [x16, #0x8]
    6ab4:      	b	0x6830 <_stogir.placement.late-with-uses!+0x740>
    6ab8:      	ldr	x0, [x22]
    6abc:      	orr	x2, x0, xzr
    6ac0:      	add	x2, x2, x19, lsl #2
    6ac4:      	add	x0, x0, x1, lsl #2
    6ac8:      	ldr	w1, [x2]
    6acc:      	orr	w19, w1, wzr
    6ad0:      	ldr	w0, [x0]
    6ad4:      	orr	w1, w0, wzr
    6ad8:      	sxtw	x19, w19
    6adc:      	sxtw	x1, w1
    6ae0:      	cmp	x19, x1
    6ae4:      	b.eq	0x6a54 <_stogir.placement.late-with-uses!+0x964>
    6ae8:      	b	0x6ab8 <_stogir.placement.late-with-uses!+0x9c8>
    6aec:      	nop
    6af0:      	sxtw	x1, w1
    6af4:      	sub	x2, x2, #0x1
    6af8:      	ldr	x3, [x22]
    6afc:      	add	x1, x3, x1, lsl #2
    6b00:      	ldr	w1, [x1]
    6b04:      	cmp	x2, x0
    6b08:      	b.gt	0x6af0 <_stogir.placement.late-with-uses!+0xa00>
    6b0c:      	b	0x6ad8 <_stogir.placement.late-with-uses!+0x9e8>
    6b10:      	sxtw	x19, w19
    6b14:      	sub	x0, x0, #0x1
    6b18:      	ldr	x3, [x22]
    6b1c:      	add	x3, x3, x19, lsl #2
    6b20:      	ldr	w3, [x3]
    6b24:      	orr	w19, w3, wzr
    6b28:      	cmp	x0, x2
    6b2c:      	b.gt	0x6b10 <_stogir.placement.late-with-uses!+0xa20>
    6b30:      	b	0x6b04 <_stogir.placement.late-with-uses!+0xa14>
    6b34:      	nop
    6b38:      	orr	w3, w4, wzr
    6b3c:      	add	x2, x2, #0x1
    6b40:      	ldr	x4, [x22]
    6b44:      	sxtw	x3, w3
    6b48:      	add	x4, x4, x3, lsl #2
    6b4c:      	ldr	w4, [x4]
    6b50:      	sxtw	x5, w4
    6b54:      	cmp	x3, x5
    6b58:      	b.eq	0x6b28 <_stogir.placement.late-with-uses!+0xa38>
    6b5c:      	b	0x6b38 <_stogir.placement.late-with-uses!+0xa48>
    6b60:      	orr	w2, w3, wzr
    6b64:      	add	x0, x0, #0x1
    6b68:      	ldr	x3, [x22]
    6b6c:      	sxtw	x2, w2
    6b70:      	add	x3, x3, x2, lsl #2
    6b74:      	ldr	w3, [x3]
    6b78:      	sxtw	x4, w3
    6b7c:      	cmp	x2, x4
    6b80:      	b.ne	0x6b60 <_stogir.placement.late-with-uses!+0xa70>
    6b84:      	mov	w3, w1
    6b88:      	movz	x2, #0x0, lsl #48
    6b8c:      	b	0x6b40 <_stogir.placement.late-with-uses!+0xa50>
    6b90:      	brk	#0
    6b94:      	b	0x6b90 <_stogir.placement.late-with-uses!+0xaa0>
    6b98:      	brk	#0
    6b9c:      	b	0x6b98 <_stogir.placement.late-with-uses!+0xaa8>
    6ba0:      	str	x23, [sp, #0x110]
    6ba4:      	b	0x62d8 <_stogir.placement.late-with-uses!+0x1e8>
    6ba8:      	ldr	x19, [sp, #0x120]
    6bac:      	b	0x69a8 <_stogir.placement.late-with-uses!+0x8b8>
    6bb0:      	str	x19, [sp, #0x150]
    6bb4:      	str	x20, [sp, #0x158]
    6bb8:      	str	x24, [sp, #0x130]
    6bbc:      	str	x25, [sp, #0x148]
    6bc0:      	mov	x24, x0
    6bc4:      	str	x27, [sp, #0x160]
    6bc8:      	mov	w27, w7
    6bcc:      	mov	w19, w4
    6bd0:      	b	0x65dc <_stogir.placement.late-with-uses!+0x4ec>
    6bd4:      	str	x19, [sp, #0x150]
    6bd8:      	str	x20, [sp, #0x158]
    6bdc:      	str	x24, [sp, #0x130]
    6be0:      	str	x25, [sp, #0x148]
    6be4:      	mov	x25, x3
    6be8:      	mov	x24, x0
    6bec:      	str	x2, [sp, #0x138]
    6bf0:      	str	x1, [sp, #0x140]
    6bf4:      	str	x27, [sp, #0x160]
    6bf8:      	mov	w19, w4
    6bfc:      	b	0x64a4 <_stogir.placement.late-with-uses!+0x3b4>
    6c00:      	ldr	x19, [sp, #0x160]
    6c04:      	b	0x6704 <_stogir.placement.late-with-uses!+0x614>
    6c08:      	ldr	x27, [sp, #0x158]
    6c0c:      	str	x21, [sp, #0x188]
    6c10:      	str	x19, [sp, #0x160]
    6c14:      	ldr	x19, [sp, #0x120]
    6c18:      	b	0x63e4 <_stogir.placement.late-with-uses!+0x2f4>
    6c1c:      	str	x21, [sp, #0x188]
    6c20:      	str	x20, [sp, #0x180]
    6c24:      	str	x19, [sp, #0x160]
    6c28:      	mov	x19, x3
    6c2c:      	str	x1, [sp, #0x178]
    6c30:      	str	w2, [sp, #0x168]
    6c34:      	str	x0, [sp, #0x170]
    6c38:      	b	0x6830 <_stogir.placement.late-with-uses!+0x740>
    6c3c:      	str	x21, [sp, #0x188]
    6c40:      	str	x20, [sp, #0x180]
    6c44:      	str	x19, [sp, #0x160]
    6c48:      	mov	x19, x3
    6c4c:      	str	x1, [sp, #0x178]
    6c50:      	str	w2, [sp, #0x168]
    6c54:      	str	x0, [sp, #0x170]
    6c58:      	b	0x6830 <_stogir.placement.late-with-uses!+0x740>
    6c5c:      	str	x21, [sp, #0x188]
    6c60:      	str	x19, [sp, #0x160]
    6c64:      	b	0x63d8 <_stogir.placement.late-with-uses!+0x2e8>
    6c68:      	ldr	x4, [sp, #0x128]
    6c6c:      	b	0x6934 <_stogir.placement.late-with-uses!+0x844>
    6c70:      	str	x21, [sp, #0x188]
    6c74:      	str	x4, [sp, #0x128]
    6c78:      	str	x20, [sp, #0x180]
    6c7c:      	str	x19, [sp, #0x160]
    6c80:      	mov	x19, x3
    6c84:      	str	x1, [sp, #0x178]
    6c88:      	str	w2, [sp, #0x168]
    6c8c:      	str	x0, [sp, #0x170]
    6c90:      	b	0x6830 <_stogir.placement.late-with-uses!+0x740>
    6c94:      	str	x21, [sp, #0x188]
    6c98:      	str	x4, [sp, #0x128]
    6c9c:      	str	x20, [sp, #0x180]
    6ca0:      	str	x19, [sp, #0x160]
    6ca4:      	mov	x19, x3
    6ca8:      	str	x1, [sp, #0x178]
    6cac:      	str	w2, [sp, #0x168]
    6cb0:      	str	x0, [sp, #0x170]
    6cb4:      	b	0x6830 <_stogir.placement.late-with-uses!+0x740>
    6cb8:      	str	x21, [sp, #0x188]
    6cbc:      	str	x4, [sp, #0x128]
    6cc0:      	str	x20, [sp, #0x180]
    6cc4:      	str	x19, [sp, #0x160]
    6cc8:      	mov	x19, x3
    6ccc:      	str	x1, [sp, #0x178]
    6cd0:      	str	w2, [sp, #0x168]
    6cd4:      	str	x0, [sp, #0x170]
    6cd8:      	b	0x6830 <_stogir.placement.late-with-uses!+0x740>
    6cdc:      	str	x21, [sp, #0x188]
    6ce0:      	str	x4, [sp, #0x128]
    6ce4:      	str	x20, [sp, #0x180]
    6ce8:      	str	x19, [sp, #0x160]
    6cec:      	mov	x19, x3
    6cf0:      	str	x1, [sp, #0x178]
    6cf4:      	mov	x21, x6
    6cf8:      	str	w2, [sp, #0x168]
    6cfc:      	str	x0, [sp, #0x170]
    6d00:      	mov	w20, w5
    6d04:      	b	0x6a98 <_stogir.placement.late-with-uses!+0x9a8>

0000000000006d08 <_stogir.checked-schedule.place!>:
    6d08:      	sub	sp, sp, #0x90
    6d0c:      	str	x29, [sp]
    6d10:      	str	x30, [sp, #0x8]
    6d14:      	mov	x29, sp
    6d18:      	str	x19, [sp, #0x40]
    6d1c:      	str	x20, [sp, #0x48]
    6d20:      	str	x21, [sp, #0x50]
    6d24:      	str	x22, [sp, #0x58]
    6d28:      	str	x23, [sp, #0x60]
    6d2c:      	str	x24, [sp, #0x68]
    6d30:      	str	x25, [sp, #0x70]
    6d34:      	str	x26, [sp, #0x78]
    6d38:      	str	x27, [sp, #0x80]
    6d3c:      	str	x28, [sp, #0x88]
    6d40:      	add	x16, sp, #0x20
    6d44:      	orr	x3, x16, xzr
    6d48:      	add	x19, x3, #0x8
    6d4c:      	mov	x20, #0x1               ; =1
    6d50:      	movz	x21, #0x0, lsl #48
    6d54:      	adrp	x22, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		0000000000006d54:  ARM64_RELOC_PAGE21	l_stogir.436
    6d58:      	ldr	x22, [x22]
		0000000000006d58:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    6d5c:      	movz	x23, #0x0, lsl #48
    6d60:      	b	0x6da0 <_stogir.checked-schedule.place!+0x98>
    6d64:      	nop
    6d68:      	add	x16, sp, #0x20
    6d6c:      	ldr	x22, [x16, #0x8]
    6d70:      	ldr	x23, [x19, #0x8]
    6d74:      	sxtw	x24, w24
    6d78:      	add	x0, x24, #0x4
    6d7c:      	asr	x16, x0, #63
    6d80:      	lsr	x16, x16, #62
    6d84:      	add	x0, x0, x16
    6d88:      	asr	x0, x0, #2
    6d8c:      	add	x20, x0, x20
    6d90:      	mov	x8, x25
    6d94:      	mov	x0, x26
    6d98:      	mov	x1, x27
    6d9c:      	mov	x2, x28
    6da0:      	cmp	x23, #0x0
    6da4:      	b.ne	0x6f18 <_stogir.checked-schedule.place!+0x210>
    6da8:      	ldr	x3, [x0, #0x8]
    6dac:      	cmp	x20, x3
    6db0:      	b.ge	0x6f20 <_stogir.checked-schedule.place!+0x218>
    6db4:      	ldr	x3, [x0]
    6db8:      	add	x3, x3, x20, lsl #4
    6dbc:      	ldr	x4, [x3]
    6dc0:      	uxtb	w5, w4
    6dc4:      	ldr	x3, [x3, #0x8]
    6dc8:      	add	x16, sp, #0x10
    6dcc:      	str	x4, [x16]
    6dd0:      	add	x16, sp, #0x10
    6dd4:      	str	x3, [x16, #0x8]
    6dd8:      	ldr	x3, [x0, #0x78]
    6ddc:      	add	x3, x3, x20, lsl #2
    6de0:      	ldr	w24, [x3]
    6de4:      	cmp	x5, #0x2c
    6de8:      	b.ne	0x6f28 <_stogir.checked-schedule.place!+0x220>
    6dec:      	ldr	x3, [x2]
    6df0:      	add	x3, x20, x3
    6df4:      	ldrb	w3, [x3]
    6df8:      	cmp	x3, #0x0
    6dfc:      	b.eq	0x6f3c <_stogir.checked-schedule.place!+0x234>
    6e00:      	orr	w3, w20, wzr
    6e04:      	mov	x25, x8
    6e08:      	add	x8, sp, #0x20
    6e0c:      	mov	x26, x0
    6e10:      	mov	x27, x1
    6e14:      	mov	w1, w3
    6e18:      	mov	x28, x2
    6e1c:      	bl	0x6e1c <_stogir.checked-schedule.place!+0x114>
		0000000000006e1c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    6e20:      	add	x16, sp, #0x20
    6e24:      	ldr	w0, [x16]
    6e28:      	lsr	x16, x0, #0
    6e2c:      	cmp	x16, #0x1
    6e30:      	b.eq	0x6e4c <_stogir.checked-schedule.place!+0x144>
    6e34:      	b.lo	0x6e3c <_stogir.checked-schedule.place!+0x134>
    6e38:      	b	0x6e50 <_stogir.checked-schedule.place!+0x148>
    6e3c:      	cmp	x16, #0x0
    6e40:      	b.eq	0x6e48 <_stogir.checked-schedule.place!+0x140>
    6e44:      	b	0x6e50 <_stogir.checked-schedule.place!+0x148>
    6e48:      	b	0x6e54 <_stogir.checked-schedule.place!+0x14c>
    6e4c:      	b	0x6d68 <_stogir.checked-schedule.place!+0x60>
    6e50:      	b	0x6f10 <_stogir.checked-schedule.place!+0x208>
    6e54:      	add	x16, sp, #0x20
    6e58:      	ldr	w0, [x16, #0x8]
    6e5c:      	sxtw	x0, w0
    6e60:      	cmp	x0, #0x0
    6e64:      	b.eq	0x6f0c <_stogir.checked-schedule.place!+0x204>
    6e68:      	add	x16, sp, #0x10
    6e6c:      	ldr	w0, [x16, #0x4]
    6e70:      	sxtw	x0, w0
    6e74:      	ldr	x1, [x27]
    6e78:      	add	x0, x1, x0, lsl #2
    6e7c:      	ldr	w0, [x0]
    6e80:      	sxtw	x2, w0
    6e84:      	cmp	x2, #0x0
    6e88:      	b.gt	0x6efc <_stogir.checked-schedule.place!+0x1f4>
    6e8c:      	adrp	x22, 0x6000 <_stogir.placement.early-with-uses!+0x9e8>
		0000000000006e8c:  ARM64_RELOC_PAGE21	l_stogir.437
    6e90:      	ldr	x22, [x22]
		0000000000006e90:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    6e94:      	mov	x23, #0x21              ; =33
    6e98:      	b	0x6f0c <_stogir.checked-schedule.place!+0x204>
    6e9c:      	cmp	x23, #0x0
    6ea0:      	b.ne	0x6eb4 <_stogir.checked-schedule.place!+0x1ac>
    6ea4:      	and	x22, x21, #0xffffffff
    6ea8:      	movz	x0, #0x0, lsl #48
    6eac:      	movz	x23, #0x0, lsl #48
    6eb0:      	b	0x6eb8 <_stogir.checked-schedule.place!+0x1b0>
    6eb4:      	mov	x0, #0x1                ; =1
    6eb8:      	str	x0, [x25]
    6ebc:      	str	x22, [x25, #0x8]
    6ec0:      	str	x23, [x25, #0x10]
    6ec4:      	ldr	x19, [sp, #0x40]
    6ec8:      	ldr	x20, [sp, #0x48]
    6ecc:      	ldr	x21, [sp, #0x50]
    6ed0:      	ldr	x22, [sp, #0x58]
    6ed4:      	ldr	x23, [sp, #0x60]
    6ed8:      	ldr	x24, [sp, #0x68]
    6edc:      	ldr	x25, [sp, #0x70]
    6ee0:      	ldr	x26, [sp, #0x78]
    6ee4:      	ldr	x27, [sp, #0x80]
    6ee8:      	ldr	x28, [sp, #0x88]
    6eec:      	ldr	x29, [sp]
    6ef0:      	ldr	x30, [sp, #0x8]
    6ef4:      	add	sp, sp, #0x90
    6ef8:      	ret
    6efc:      	add	x2, x21, #0x1
    6f00:      	add	x1, x1, x20, lsl #2
    6f04:      	sxtw	x21, w2
    6f08:      	str	w0, [x1]
    6f0c:      	b	0x6d74 <_stogir.checked-schedule.place!+0x6c>
    6f10:      	brk	#0
    6f14:      	b	0x6f10 <_stogir.checked-schedule.place!+0x208>
    6f18:      	mov	x25, x8
    6f1c:      	b	0x6e9c <_stogir.checked-schedule.place!+0x194>
    6f20:      	mov	x25, x8
    6f24:      	b	0x6e9c <_stogir.checked-schedule.place!+0x194>
    6f28:      	mov	x25, x8
    6f2c:      	mov	x26, x0
    6f30:      	mov	x27, x1
    6f34:      	mov	x28, x2
    6f38:      	b	0x6d74 <_stogir.checked-schedule.place!+0x6c>
    6f3c:      	mov	x25, x8
    6f40:      	mov	x26, x0
    6f44:      	mov	x27, x1
    6f48:      	mov	x28, x2
    6f4c:      	b	0x6d74 <_stogir.checked-schedule.place!+0x6c>

0000000000006f50 <_stogir.loops.reorder!>:
    6f50:      	sub	sp, sp, #0x2b0
    6f54:      	str	x29, [sp]
    6f58:      	str	x30, [sp, #0x8]
    6f5c:      	mov	x29, sp
    6f60:      	str	x19, [sp, #0x260]
    6f64:      	str	x20, [sp, #0x268]
    6f68:      	str	x21, [sp, #0x270]
    6f6c:      	str	x22, [sp, #0x278]
    6f70:      	str	x23, [sp, #0x280]
    6f74:      	str	x24, [sp, #0x288]
    6f78:      	str	x25, [sp, #0x290]
    6f7c:      	str	x26, [sp, #0x298]
    6f80:      	str	x27, [sp, #0x2a0]
    6f84:      	str	x28, [sp, #0x2a8]
    6f88:      	add	x6, x0, #0x50
    6f8c:      	ldr	x7, [x0, #0x50]
    6f90:      	ldr	x6, [x6, #0x8]
    6f94:      	orr	x19, x7, xzr
    6f98:      	orr	x20, x6, xzr
    6f9c:      	movz	x21, #0x0, lsl #48
    6fa0:      	movz	x22, #0x0, lsl #48
    6fa4:      	b	0x73b4 <_stogir.loops.reorder!+0x464>
    6fa8:      	movz	w0, #0x0, lsl #16
    6fac:      	movz	x1, #0x0, lsl #48
    6fb0:      	ubfx	x0, x0, #0, #32
    6fb4:      	lsr	x16, x0, #0
    6fb8:      	cmp	x16, #0x1
    6fbc:      	b.eq	0x6fd8 <_stogir.loops.reorder!+0x88>
    6fc0:      	b.lo	0x6fc8 <_stogir.loops.reorder!+0x78>
    6fc4:      	b	0x6fdc <_stogir.loops.reorder!+0x8c>
    6fc8:      	cmp	x16, #0x0
    6fcc:      	b.eq	0x6fd4 <_stogir.loops.reorder!+0x84>
    6fd0:      	b	0x6fdc <_stogir.loops.reorder!+0x8c>
    6fd4:      	b	0x7064 <_stogir.loops.reorder!+0x114>
    6fd8:      	b	0x6fe0 <_stogir.loops.reorder!+0x90>
    6fdc:      	b	0x7acc <_stogir.loops.reorder!+0xb7c>
    6fe0:      	orr	w0, w1, wzr
    6fe4:      	asr	x2, x1, #32
    6fe8:      	add	x16, sp, #0x50
    6fec:      	ldr	x3, [x16]
    6ff0:      	sxtw	x4, w0
    6ff4:      	orr	x5, x3, xzr
    6ff8:      	add	x2, x3, x2, lsl #2
    6ffc:      	add	x3, x5, x4, lsl #2
    7000:      	ldr	w3, [x3]
    7004:      	sxtw	x3, w3
    7008:      	ldr	w2, [x2]
    700c:      	cmp	x3, #0x0
    7010:      	b.lt	0x7044 <_stogir.loops.reorder!+0xf4>
    7014:      	sxtw	x2, w2
    7018:      	cmp	x2, #0x0
    701c:      	b.lt	0x7044 <_stogir.loops.reorder!+0xf4>
    7020:      	cmp	x3, x2
    7024:      	b.lt	0x7044 <_stogir.loops.reorder!+0xf4>
    7028:      	lsr	x1, x1, #32
    702c:      	mov	w2, w0
    7030:      	mov	x0, x26
    7034:      	bl	0x7034 <_stogir.loops.reorder!+0xe4>
		0000000000007034:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    7038:      	cmp	x0, #0x0
    703c:      	b.ne	0x7044 <_stogir.loops.reorder!+0xf4>
    7040:      	movz	x22, #0x0, lsl #48
    7044:      	cmp	x21, x20
    7048:      	b.ge	0x6fa8 <_stogir.loops.reorder!+0x58>
    704c:      	add	x0, x21, #0x1
    7050:      	add	x1, x19, x21, lsl #4
    7054:      	ldr	x1, [x1]
    7058:      	mov	x21, x0
    705c:      	mov	w0, #0x1                ; =1
    7060:      	b	0x6fb0 <_stogir.loops.reorder!+0x60>
    7064:      	cmp	x22, #0x0
    7068:      	b.eq	0x71e0 <_stogir.loops.reorder!+0x290>
    706c:      	add	x8, sp, #0x100
    7070:      	ldr	x0, [sp, #0x250]
    7074:      	bl	0x7074 <_stogir.loops.reorder!+0x124>
		0000000000007074:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7078:      	add	x16, sp, #0x100
    707c:      	ldr	x0, [x16]
    7080:      	add	x16, sp, #0xd0
    7084:      	str	x0, [x16]
    7088:      	add	x16, sp, #0x100
    708c:      	ldr	x0, [x16, #0x8]
    7090:      	add	x16, sp, #0xd0
    7094:      	str	x0, [x16, #0x8]
    7098:      	add	x16, sp, #0x100
    709c:      	ldr	x0, [x16, #0x10]
    70a0:      	add	x16, sp, #0xd0
    70a4:      	str	x0, [x16, #0x10]
    70a8:      	add	x16, sp, #0x100
    70ac:      	ldr	x0, [x16, #0x18]
    70b0:      	add	x16, sp, #0xd0
    70b4:      	str	x0, [x16, #0x18]
    70b8:      	add	x16, sp, #0x100
    70bc:      	ldr	x0, [x16, #0x20]
    70c0:      	add	x16, sp, #0xd0
    70c4:      	str	x0, [x16, #0x20]
    70c8:      	add	x8, sp, #0x160
    70cc:      	ldr	x0, [sp, #0x250]
    70d0:      	bl	0x70d0 <_stogir.loops.reorder!+0x180>
		00000000000070d0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame
    70d4:      	add	x16, sp, #0x160
    70d8:      	ldr	x0, [x16]
    70dc:      	add	x16, sp, #0x130
    70e0:      	str	x0, [x16]
    70e4:      	add	x16, sp, #0x160
    70e8:      	ldr	x0, [x16, #0x8]
    70ec:      	add	x16, sp, #0x130
    70f0:      	str	x0, [x16, #0x8]
    70f4:      	add	x16, sp, #0x160
    70f8:      	ldr	x0, [x16, #0x10]
    70fc:      	add	x16, sp, #0x130
    7100:      	str	x0, [x16, #0x10]
    7104:      	add	x16, sp, #0x160
    7108:      	ldr	x0, [x16, #0x18]
    710c:      	add	x16, sp, #0x130
    7110:      	str	x0, [x16, #0x18]
    7114:      	add	x16, sp, #0x160
    7118:      	ldr	x0, [x16, #0x20]
    711c:      	add	x16, sp, #0x130
    7120:      	str	x0, [x16, #0x20]
    7124:      	add	x8, sp, #0x1c0
    7128:      	ldr	x0, [sp, #0x250]
    712c:      	bl	0x712c <_stogir.loops.reorder!+0x1dc>
		000000000000712c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7130:      	add	x16, sp, #0x1c0
    7134:      	ldr	x0, [x16]
    7138:      	add	x16, sp, #0x190
    713c:      	str	x0, [x16]
    7140:      	add	x16, sp, #0x1c0
    7144:      	ldr	x0, [x16, #0x8]
    7148:      	add	x16, sp, #0x190
    714c:      	str	x0, [x16, #0x8]
    7150:      	add	x16, sp, #0x1c0
    7154:      	ldr	x0, [x16, #0x10]
    7158:      	add	x16, sp, #0x190
    715c:      	str	x0, [x16, #0x10]
    7160:      	add	x16, sp, #0x1c0
    7164:      	ldr	x0, [x16, #0x18]
    7168:      	add	x16, sp, #0x190
    716c:      	str	x0, [x16, #0x18]
    7170:      	add	x16, sp, #0x1c0
    7174:      	ldr	x0, [x16, #0x20]
    7178:      	add	x16, sp, #0x190
    717c:      	str	x0, [x16, #0x20]
    7180:      	ldr	x0, [x28]
    7184:      	ldr	w19, [x0]
    7188:      	movn	x0, #0x0, lsl #48
    718c:      	b	0x71a4 <_stogir.loops.reorder!+0x254>
    7190:      	add	x16, sp, #0x50
    7194:      	ldr	x1, [x16]
    7198:      	add	x1, x1, x0, lsl #2
    719c:      	movz	w17, #0x0, lsl #16
    71a0:      	str	w17, [x1]
    71a4:      	add	x16, sp, #0x50
    71a8:      	ldr	x1, [x16, #0x8]
    71ac:      	add	x0, x0, #0x1
    71b0:      	cmp	x0, x1
    71b4:      	b.lt	0x7190 <_stogir.loops.reorder!+0x240>
    71b8:      	add	x0, x25, #0x28
    71bc:      	add	x8, sp, #0x1f0
    71c0:      	bl	0x71c0 <_stogir.loops.reorder!+0x270>
		00000000000071c0:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64
    71c4:      	add	x16, sp, #0x1f0
    71c8:      	ldr	x20, [x16]
    71cc:      	add	x16, sp, #0x1f0
    71d0:      	ldr	x21, [x16, #0x8]
    71d4:      	add	x16, sp, #0x1f0
    71d8:      	ldr	x22, [x16, #0x10]
    71dc:      	b	0x7424 <_stogir.loops.reorder!+0x4d4>
    71e0:      	add	x0, sp, #0x50
    71e4:      	bl	0x71e4 <_stogir.loops.reorder!+0x294>
		00000000000071e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    71e8:      	movz	x1, #0x0, lsl #48
    71ec:      	movz	x0, #0x0, lsl #48
    71f0:      	movz	x2, #0x0, lsl #48
    71f4:      	b	0x78ec <_stogir.loops.reorder!+0x99c>
    71f8:      	movz	w4, #0x0, lsl #16
    71fc:      	movz	w5, #0x0, lsl #16
    7200:      	ubfx	x4, x4, #0, #32
    7204:      	lsr	x16, x4, #0
    7208:      	cmp	x16, #0x1
    720c:      	b.eq	0x7228 <_stogir.loops.reorder!+0x2d8>
    7210:      	b.lo	0x7218 <_stogir.loops.reorder!+0x2c8>
    7214:      	b	0x722c <_stogir.loops.reorder!+0x2dc>
    7218:      	cmp	x16, #0x0
    721c:      	b.eq	0x7224 <_stogir.loops.reorder!+0x2d4>
    7220:      	b	0x722c <_stogir.loops.reorder!+0x2dc>
    7224:      	b	0x7278 <_stogir.loops.reorder!+0x328>
    7228:      	b	0x7230 <_stogir.loops.reorder!+0x2e0>
    722c:      	b	0x7ac4 <_stogir.loops.reorder!+0xb74>
    7230:      	sxtw	x5, w5
    7234:      	ldr	x4, [x26]
    7238:      	add	x4, x4, x5, lsl #2
    723c:      	ldr	w4, [x4]
    7240:      	sxtw	x4, w4
    7244:      	cmp	x4, #0x0
    7248:      	b.le	0x7250 <_stogir.loops.reorder!+0x300>
    724c:      	add	x3, x3, #0x1
    7250:      	cmp	x2, x1
    7254:      	b.ge	0x71f8 <_stogir.loops.reorder!+0x2a8>
    7258:      	add	x4, x2, #0x1
    725c:      	add	x2, x0, x2, lsl #2
    7260:      	ldr	w2, [x2]
    7264:      	movn	w17, #0x0, lsl #16
    7268:      	and	w5, w2, w17
    726c:      	mov	x2, x4
    7270:      	mov	w4, #0x1                ; =1
    7274:      	b	0x7200 <_stogir.loops.reorder!+0x2b0>
    7278:      	ldr	x0, [x28, #0x8]
    727c:      	cmp	x3, x0
    7280:      	b.ne	0x72b4 <_stogir.loops.reorder!+0x364>
    7284:      	add	x8, sp, #0x30
    7288:      	mov	x0, x24
    728c:      	bl	0x728c <_stogir.loops.reorder!+0x33c>
		000000000000728c:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    7290:      	add	x16, sp, #0x30
    7294:      	ldr	x0, [x16]
    7298:      	add	x16, sp, #0x30
    729c:      	ldr	x1, [x16, #0x8]
    72a0:      	add	x16, sp, #0x30
    72a4:      	ldr	x2, [x16, #0x10]
    72a8:      	movz	x3, #0x0, lsl #48
    72ac:      	movz	x4, #0x0, lsl #48
    72b0:      	b	0x78b4 <_stogir.loops.reorder!+0x964>
    72b4:      	mov	x1, #0x1                ; =1
    72b8:      	adrp	x0, 0x7000 <_stogir.loops.reorder!+0xb0>
		00000000000072b8:  ARM64_RELOC_PAGE21	l_stogir.438
    72bc:      	ldr	x0, [x0]
		00000000000072bc:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    72c0:      	mov	x2, #0x32               ; =50
    72c4:      	b	0x78fc <_stogir.loops.reorder!+0x9ac>
    72c8:      	movz	w6, #0x0, lsl #16
    72cc:      	movz	x7, #0x0, lsl #48
    72d0:      	ubfx	x6, x6, #0, #32
    72d4:      	lsr	x16, x6, #0
    72d8:      	cmp	x16, #0x1
    72dc:      	b.eq	0x7314 <_stogir.loops.reorder!+0x3c4>
    72e0:      	b.lo	0x72e8 <_stogir.loops.reorder!+0x398>
    72e4:      	b	0x7318 <_stogir.loops.reorder!+0x3c8>
    72e8:      	cmp	x16, #0x0
    72ec:      	b.eq	0x72f4 <_stogir.loops.reorder!+0x3a4>
    72f0:      	b	0x7318 <_stogir.loops.reorder!+0x3c8>
    72f4:      	mov	x23, x8
    72f8:      	mov	x24, x0
    72fc:      	mov	x25, x1
    7300:      	mov	x26, x2
    7304:      	mov	x27, x3
    7308:      	mov	x28, x4
    730c:      	str	x5, [sp, #0x250]
    7310:      	b	0x73d4 <_stogir.loops.reorder!+0x484>
    7314:      	b	0x731c <_stogir.loops.reorder!+0x3cc>
    7318:      	b	0x7abc <_stogir.loops.reorder!+0xb6c>
    731c:      	orr	w6, w7, wzr
    7320:      	ldr	x9, [x2]
    7324:      	sxtw	x10, w6
    7328:      	add	x11, x9, x10, lsl #2
    732c:      	ldr	w11, [x11]
    7330:      	sxtw	x11, w11
    7334:      	cmp	x11, #0x0
    7338:      	b.le	0x7ad4 <_stogir.loops.reorder!+0xb84>
    733c:      	lsr	x7, x7, #32
    7340:      	sxtw	x11, w7
    7344:      	add	x9, x9, x11, lsl #2
    7348:      	ldr	w9, [x9]
    734c:      	sxtw	x9, w9
    7350:      	cmp	x9, #0x0
    7354:      	b.le	0x7af4 <_stogir.loops.reorder!+0xba4>
    7358:      	cmp	x10, x11
    735c:      	b.lt	0x7b14 <_stogir.loops.reorder!+0xbc4>
    7360:      	mov	x23, x8
    7364:      	mov	x24, x0
    7368:      	mov	x0, x2
    736c:      	mov	x25, x1
    7370:      	mov	w1, w7
    7374:      	mov	x26, x2
    7378:      	mov	w2, w6
    737c:      	mov	x27, x3
    7380:      	mov	x28, x4
    7384:      	str	x5, [sp, #0x250]
    7388:      	bl	0x7388 <_stogir.loops.reorder!+0x438>
		0000000000007388:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    738c:      	cmp	x0, #0x0
    7390:      	b.ne	0x7398 <_stogir.loops.reorder!+0x448>
    7394:      	mov	x21, #0x1               ; =1
    7398:      	mov	x8, x23
    739c:      	mov	x0, x24
    73a0:      	mov	x1, x25
    73a4:      	mov	x2, x26
    73a8:      	mov	x3, x27
    73ac:      	mov	x4, x28
    73b0:      	ldr	x5, [sp, #0x250]
    73b4:      	cmp	x22, x20
    73b8:      	b.ge	0x72c8 <_stogir.loops.reorder!+0x378>
    73bc:      	add	x6, x22, #0x1
    73c0:      	add	x7, x19, x22, lsl #4
    73c4:      	ldr	x7, [x7]
    73c8:      	mov	x22, x6
    73cc:      	mov	w6, #0x1                ; =1
    73d0:      	b	0x72d0 <_stogir.loops.reorder!+0x380>
    73d4:      	ldr	x0, [x28, #0x8]
    73d8:      	cmp	x0, #0x0
    73dc:      	b.ne	0x7940 <_stogir.loops.reorder!+0x9f0>
    73e0:      	movz	x1, #0x0, lsl #48
    73e4:      	movz	x0, #0x0, lsl #48
    73e8:      	movz	x2, #0x0, lsl #48
    73ec:      	b	0x78fc <_stogir.loops.reorder!+0x9ac>
    73f0:      	lsl	x1, x1, #1
    73f4:      	str	x20, [sp, #0x258]
    73f8:      	mov	x20, x0
    73fc:      	add	x0, sp, #0xd0
    7400:      	bl	0x7400 <_stogir.loops.reorder!+0x4b0>
		0000000000007400:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    7404:      	add	x0, x20, #0x1
    7408:      	add	x16, sp, #0xd0
    740c:      	ldr	x1, [x16]
    7410:      	add	x1, x1, x20, lsl #3
    7414:      	str	x26, [x1]
    7418:      	add	x16, sp, #0xd0
    741c:      	str	x0, [x16, #0x8]
    7420:      	ldr	x20, [sp, #0x258]
    7424:      	cmp	x22, x21
    7428:      	b.ge	0x7448 <_stogir.loops.reorder!+0x4f8>
    742c:      	add	x0, x22, #0x1
    7430:      	add	x1, x20, x22, lsl #3
    7434:      	ldr	x1, [x1]
    7438:      	orr	x26, x1, xzr
    743c:      	mov	x22, x0
    7440:      	mov	w0, #0x1                ; =1
    7444:      	b	0x7450 <_stogir.loops.reorder!+0x500>
    7448:      	movz	w0, #0x0, lsl #16
    744c:      	movz	x26, #0x0, lsl #48
    7450:      	ubfx	x0, x0, #0, #32
    7454:      	lsr	x16, x0, #0
    7458:      	cmp	x16, #0x1
    745c:      	b.eq	0x7478 <_stogir.loops.reorder!+0x528>
    7460:      	b.lo	0x7468 <_stogir.loops.reorder!+0x518>
    7464:      	b	0x747c <_stogir.loops.reorder!+0x52c>
    7468:      	cmp	x16, #0x0
    746c:      	b.eq	0x7474 <_stogir.loops.reorder!+0x524>
    7470:      	b	0x747c <_stogir.loops.reorder!+0x52c>
    7474:      	b	0x74a8 <_stogir.loops.reorder!+0x558>
    7478:      	b	0x7480 <_stogir.loops.reorder!+0x530>
    747c:      	b	0x7ab4 <_stogir.loops.reorder!+0xb64>
    7480:      	add	x16, sp, #0xd0
    7484:      	ldr	x0, [x16, #0x8]
    7488:      	add	x16, sp, #0xd0
    748c:      	ldr	x1, [x16, #0x10]
    7490:      	cmp	x0, x1
    7494:      	b.lt	0x7b34 <_stogir.loops.reorder!+0xbe4>
    7498:      	cmp	x1, #0x0
    749c:      	b.ne	0x73f0 <_stogir.loops.reorder!+0x4a0>
    74a0:      	mov	x1, #0x2                ; =2
    74a4:      	b	0x73f4 <_stogir.loops.reorder!+0x4a4>
    74a8:      	sxtw	x20, w19
    74ac:      	ldr	x0, [x25]
    74b0:      	add	x0, x0, x20, lsl #4
    74b4:      	ldr	x1, [x0]
    74b8:      	ldr	x0, [x0, #0x8]
    74bc:      	add	x16, sp, #0x210
    74c0:      	str	x1, [x16]
    74c4:      	add	x16, sp, #0x210
    74c8:      	str	x0, [x16, #0x8]
    74cc:      	add	x0, sp, #0xd0
    74d0:      	add	x1, sp, #0x210
    74d4:      	mov	x2, x24
    74d8:      	mov	x3, x27
    74dc:      	bl	0x74dc <_stogir.loops.reorder!+0x58c>
		00000000000074dc:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    74e0:      	add	x16, sp, #0x220
    74e4:      	movz	x17, #0x0, lsl #48
    74e8:      	str	x17, [x16]
    74ec:      	add	x16, sp, #0x220
    74f0:      	movz	x17, #0x0, lsl #48
    74f4:      	str	x17, [x16, #0x8]
    74f8:      	add	x16, sp, #0x220
    74fc:      	str	w19, [x16]
    7500:      	add	x16, sp, #0x210
    7504:      	ldr	x0, [x16, #0x8]
    7508:      	add	x16, sp, #0x220
    750c:      	str	x0, [x16, #0x8]
    7510:      	add	x16, sp, #0x220
    7514:      	ldr	x1, [x16]
    7518:      	mov	x2, x0
    751c:      	add	x0, sp, #0x130
    7520:      	bl	0x7520 <_stogir.loops.reorder!+0x5d0>
		0000000000007520:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame
    7524:      	add	x16, sp, #0x50
    7528:      	ldr	x0, [x16]
    752c:      	add	x0, x0, x20, lsl #2
    7530:      	mov	w17, #0x1               ; =1
    7534:      	str	w17, [x0]
    7538:      	b	0x75cc <_stogir.loops.reorder!+0x67c>
    753c:      	lsl	x0, x0, #1
    7540:      	mov	x1, x0
    7544:      	add	x0, sp, #0x190
    7548:      	bl	0x7548 <_stogir.loops.reorder!+0x5f8>
		0000000000007548:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    754c:      	add	x0, x19, #0x1
    7550:      	add	x16, sp, #0x190
    7554:      	ldr	x1, [x16]
    7558:      	add	x1, x1, x19, lsl #2
    755c:      	str	w21, [x1]
    7560:      	add	x16, sp, #0x190
    7564:      	str	x0, [x16, #0x8]
    7568:      	add	x16, sp, #0x130
    756c:      	ldr	x0, [x16, #0x8]
    7570:      	cmp	x0, #0x0
    7574:      	b.eq	0x75cc <_stogir.loops.reorder!+0x67c>
    7578:      	sub	x0, x0, #0x1
    757c:      	add	x16, sp, #0x130
    7580:      	str	x0, [x16, #0x8]
    7584:      	b	0x75cc <_stogir.loops.reorder!+0x67c>
    7588:      	lsl	x0, x0, #1
    758c:      	mov	x1, x0
    7590:      	add	x0, sp, #0x130
    7594:      	bl	0x7594 <_stogir.loops.reorder!+0x644>
		0000000000007594:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    7598:      	add	x0, x21, #0x1
    759c:      	add	x16, sp, #0x130
    75a0:      	ldr	x1, [x16]
    75a4:      	add	x1, x1, x21, lsl #4
    75a8:      	str	x20, [x1]
    75ac:      	str	x19, [x1, #0x8]
    75b0:      	add	x16, sp, #0x130
    75b4:      	str	x0, [x16, #0x8]
    75b8:      	add	x16, sp, #0x50
    75bc:      	ldr	x0, [x16]
    75c0:      	add	x0, x0, x26, lsl #2
    75c4:      	mov	w17, #0x1               ; =1
    75c8:      	str	w17, [x0]
    75cc:      	add	x16, sp, #0x130
    75d0:      	ldr	x0, [x16, #0x8]
    75d4:      	cmp	x0, #0x0
    75d8:      	b.le	0x7764 <_stogir.loops.reorder!+0x814>
    75dc:      	add	x16, sp, #0x130
    75e0:      	ldr	x1, [x16]
    75e4:      	sub	x19, x0, #0x1
    75e8:      	add	x0, x1, x19, lsl #4
    75ec:      	ldr	x20, [x0]
    75f0:      	orr	w21, w20, wzr
    75f4:      	ldr	x0, [x0, #0x8]
    75f8:      	sxtw	x1, w21
    75fc:      	ldr	x2, [x25]
    7600:      	add	x1, x2, x1, lsl #4
    7604:      	ldr	x1, [x1]
    7608:      	cmp	x0, #0x0
    760c:      	b.ne	0x763c <_stogir.loops.reorder!+0x6ec>
    7610:      	add	x16, sp, #0x190
    7614:      	ldr	x0, [x16, #0x8]
    7618:      	orr	x19, x0, xzr
    761c:      	add	x16, sp, #0x190
    7620:      	ldr	x0, [x16, #0x10]
    7624:      	cmp	x19, x0
    7628:      	b.lt	0x754c <_stogir.loops.reorder!+0x5fc>
    762c:      	cmp	x0, #0x0
    7630:      	b.ne	0x753c <_stogir.loops.reorder!+0x5ec>
    7634:      	mov	x0, #0x2                ; =2
    7638:      	b	0x7540 <_stogir.loops.reorder!+0x5f0>
    763c:      	sub	x21, x0, #0x1
    7640:      	add	x16, sp, #0xd0
    7644:      	ldr	x0, [x16]
    7648:      	add	x2, x21, x1
    764c:      	orr	x3, x0, xzr
    7650:      	orr	x4, x0, xzr
    7654:      	add	x3, x3, x1, lsl #3
    7658:      	add	x0, x0, x1, lsl #3
    765c:      	add	x2, x4, x2, lsl #3
    7660:      	ldr	x3, [x3]
    7664:      	ldr	x4, [x24, #0x50]
    7668:      	add	x3, x4, x3, lsl #4
    766c:      	ldr	x3, [x3]
    7670:      	ldr	x2, [x2]
    7674:      	lsr	x22, x3, #32
    7678:      	str	x2, [x0]
    767c:      	sxtw	x26, w22
    7680:      	add	x0, sp, #0xd0
    7684:      	mov	x2, x21
    7688:      	mov	x4, x24
    768c:      	mov	x5, x27
    7690:      	movz	x3, #0x0, lsl #48
    7694:      	bl	0x7694 <_stogir.loops.reorder!+0x744>
		0000000000007694:  ARM64_RELOC_BRANCH26	_stogir.loops.sift!
    7698:      	add	x16, sp, #0x130
    769c:      	ldr	x0, [x16]
    76a0:      	add	x0, x0, x19, lsl #4
    76a4:      	str	x20, [x0]
    76a8:      	str	x21, [x0, #0x8]
    76ac:      	add	x16, sp, #0x50
    76b0:      	ldr	x0, [x16]
    76b4:      	add	x0, x0, x26, lsl #2
    76b8:      	ldr	w0, [x0]
    76bc:      	sxtw	x0, w0
    76c0:      	cmp	x0, #0x0
    76c4:      	b.ne	0x75cc <_stogir.loops.reorder!+0x67c>
    76c8:      	ldr	x0, [x25]
    76cc:      	add	x0, x0, x26, lsl #4
    76d0:      	ldr	x1, [x0]
    76d4:      	ldr	x0, [x0, #0x8]
    76d8:      	add	x16, sp, #0x230
    76dc:      	str	x1, [x16]
    76e0:      	add	x16, sp, #0x230
    76e4:      	str	x0, [x16, #0x8]
    76e8:      	add	x0, sp, #0xd0
    76ec:      	add	x1, sp, #0x230
    76f0:      	mov	x2, x24
    76f4:      	mov	x3, x27
    76f8:      	bl	0x76f8 <_stogir.loops.reorder!+0x7a8>
		00000000000076f8:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    76fc:      	add	x16, sp, #0x240
    7700:      	movz	x17, #0x0, lsl #48
    7704:      	str	x17, [x16]
    7708:      	add	x16, sp, #0x240
    770c:      	movz	x17, #0x0, lsl #48
    7710:      	str	x17, [x16, #0x8]
    7714:      	add	x16, sp, #0x240
    7718:      	str	w22, [x16]
    771c:      	add	x16, sp, #0x230
    7720:      	ldr	x0, [x16, #0x8]
    7724:      	orr	x19, x0, xzr
    7728:      	add	x16, sp, #0x240
    772c:      	str	x19, [x16, #0x8]
    7730:      	add	x16, sp, #0x240
    7734:      	ldr	x20, [x16]
    7738:      	add	x16, sp, #0x130
    773c:      	ldr	x0, [x16, #0x8]
    7740:      	orr	x21, x0, xzr
    7744:      	add	x16, sp, #0x130
    7748:      	ldr	x0, [x16, #0x10]
    774c:      	cmp	x21, x0
    7750:      	b.lt	0x7598 <_stogir.loops.reorder!+0x648>
    7754:      	cmp	x0, #0x0
    7758:      	b.ne	0x7588 <_stogir.loops.reorder!+0x638>
    775c:      	mov	x0, #0x2                ; =2
    7760:      	b	0x758c <_stogir.loops.reorder!+0x63c>
    7764:      	add	x16, sp, #0x190
    7768:      	ldr	x0, [x16, #0x8]
    776c:      	ldr	x1, [x28, #0x8]
    7770:      	cmp	x0, x1
    7774:      	cset	w19, eq
    7778:      	uxtb	w16, w19
    777c:      	cmp	w16, wzr
    7780:      	b.eq	0x77f0 <_stogir.loops.reorder!+0x8a0>
    7784:      	movn	x0, #0x0, lsl #48
    7788:      	movz	x20, #0x0, lsl #48
    778c:      	b	0x77a0 <_stogir.loops.reorder!+0x850>
    7790:      	mov	x20, #0x1               ; =1
    7794:      	ldr	x2, [x28]
    7798:      	add	x2, x2, x0, lsl #2
    779c:      	str	w1, [x2]
    77a0:      	ldr	x1, [x28, #0x8]
    77a4:      	add	x0, x0, #0x1
    77a8:      	cmp	x0, x1
    77ac:      	b.ge	0x77f4 <_stogir.loops.reorder!+0x8a4>
    77b0:      	add	x16, sp, #0x190
    77b4:      	ldr	x1, [x16, #0x8]
    77b8:      	add	x16, sp, #0x190
    77bc:      	ldr	x2, [x16]
    77c0:      	sub	x1, x1, #0x1
    77c4:      	sub	x1, x1, x0
    77c8:      	add	x1, x2, x1, lsl #2
    77cc:      	ldr	w1, [x1]
    77d0:      	ldr	x2, [x28]
    77d4:      	sxtw	x3, w1
    77d8:      	add	x2, x2, x0, lsl #2
    77dc:      	ldr	w2, [x2]
    77e0:      	sxtw	x2, w2
    77e4:      	cmp	x2, x3
    77e8:      	b.eq	0x7794 <_stogir.loops.reorder!+0x844>
    77ec:      	b	0x7790 <_stogir.loops.reorder!+0x840>
    77f0:      	movz	x20, #0x0, lsl #48
    77f4:      	add	x0, sp, #0x50
    77f8:      	bl	0x77f8 <_stogir.loops.reorder!+0x8a8>
		00000000000077f8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    77fc:      	add	x0, sp, #0xd0
    7800:      	bl	0x7800 <_stogir.loops.reorder!+0x8b0>
		0000000000007800:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    7804:      	add	x0, sp, #0x130
    7808:      	bl	0x7808 <_stogir.loops.reorder!+0x8b8>
		0000000000007808:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame
    780c:      	add	x0, sp, #0x190
    7810:      	bl	0x7810 <_stogir.loops.reorder!+0x8c0>
		0000000000007810:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7814:      	uxtb	w16, w19
    7818:      	cmp	w16, wzr
    781c:      	b.eq	0x78dc <_stogir.loops.reorder!+0x98c>
    7820:      	and	x0, x20, #0xff
    7824:      	movz	x1, #0x0, lsl #48
    7828:      	movz	x2, #0x0, lsl #48
    782c:      	b	0x78ec <_stogir.loops.reorder!+0x99c>
    7830:      	movz	w5, #0x0, lsl #16
    7834:      	movz	w6, #0x0, lsl #16
    7838:      	ubfx	x5, x5, #0, #32
    783c:      	lsr	x16, x5, #0
    7840:      	cmp	x16, #0x1
    7844:      	b.eq	0x7860 <_stogir.loops.reorder!+0x910>
    7848:      	b.lo	0x7850 <_stogir.loops.reorder!+0x900>
    784c:      	b	0x7864 <_stogir.loops.reorder!+0x914>
    7850:      	cmp	x16, #0x0
    7854:      	b.eq	0x785c <_stogir.loops.reorder!+0x90c>
    7858:      	b	0x7864 <_stogir.loops.reorder!+0x914>
    785c:      	b	0x78f0 <_stogir.loops.reorder!+0x9a0>
    7860:      	b	0x7868 <_stogir.loops.reorder!+0x918>
    7864:      	b	0x7aac <_stogir.loops.reorder!+0xb5c>
    7868:      	sxtw	x5, w6
    786c:      	ldr	x7, [x26]
    7870:      	add	x7, x7, x5, lsl #2
    7874:      	ldr	w7, [x7]
    7878:      	sxtw	x7, w7
    787c:      	cmp	x7, #0x0
    7880:      	b.le	0x78b4 <_stogir.loops.reorder!+0x964>
    7884:      	ldr	x7, [x28]
    7888:      	add	x7, x7, x4, lsl #2
    788c:      	ldr	w7, [x7]
    7890:      	sxtw	x7, w7
    7894:      	cmp	x7, x5
    7898:      	b.eq	0x78a0 <_stogir.loops.reorder!+0x950>
    789c:      	mov	x3, #0x1                ; =1
    78a0:      	add	x5, x4, #0x1
    78a4:      	ldr	x7, [x28]
    78a8:      	add	x4, x7, x4, lsl #2
    78ac:      	str	w6, [x4]
    78b0:      	mov	x4, x5
    78b4:      	cmp	x2, x1
    78b8:      	b.ge	0x7830 <_stogir.loops.reorder!+0x8e0>
    78bc:      	add	x5, x2, #0x1
    78c0:      	add	x2, x0, x2, lsl #2
    78c4:      	ldr	w2, [x2]
    78c8:      	movn	w17, #0x0, lsl #16
    78cc:      	and	w6, w2, w17
    78d0:      	mov	x2, x5
    78d4:      	mov	w5, #0x1                ; =1
    78d8:      	b	0x7838 <_stogir.loops.reorder!+0x8e8>
    78dc:      	mov	x1, #0x1                ; =1
    78e0:      	adrp	x0, 0x7000 <_stogir.loops.reorder!+0xb0>
		00000000000078e0:  ARM64_RELOC_PAGE21	l_stogir.439
    78e4:      	ldr	x0, [x0]
		00000000000078e4:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    78e8:      	mov	x2, #0x33               ; =51
    78ec:      	b	0x78fc <_stogir.loops.reorder!+0x9ac>
    78f0:      	and	x0, x3, #0xff
    78f4:      	movz	x1, #0x0, lsl #48
    78f8:      	movz	x2, #0x0, lsl #48
    78fc:      	str	x1, [x23]
    7900:      	str	x0, [x23, #0x8]
    7904:      	str	x2, [x23, #0x10]
    7908:      	ldr	x19, [sp, #0x260]
    790c:      	ldr	x20, [sp, #0x268]
    7910:      	ldr	x21, [sp, #0x270]
    7914:      	ldr	x22, [sp, #0x278]
    7918:      	ldr	x23, [sp, #0x280]
    791c:      	ldr	x24, [sp, #0x288]
    7920:      	ldr	x25, [sp, #0x290]
    7924:      	ldr	x26, [sp, #0x298]
    7928:      	ldr	x27, [sp, #0x2a0]
    792c:      	ldr	x28, [sp, #0x2a8]
    7930:      	ldr	x29, [sp]
    7934:      	ldr	x30, [sp, #0x8]
    7938:      	add	sp, sp, #0x2b0
    793c:      	ret
    7940:      	cmp	x21, #0x0
    7944:      	b.eq	0x79ac <_stogir.loops.reorder!+0xa5c>
    7948:      	add	x8, sp, #0x80
    794c:      	ldr	x0, [sp, #0x250]
    7950:      	bl	0x7950 <_stogir.loops.reorder!+0xa00>
		0000000000007950:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7954:      	add	x16, sp, #0x80
    7958:      	ldr	x0, [x16]
    795c:      	add	x16, sp, #0x50
    7960:      	str	x0, [x16]
    7964:      	add	x16, sp, #0x80
    7968:      	ldr	x0, [x16, #0x8]
    796c:      	add	x16, sp, #0x50
    7970:      	str	x0, [x16, #0x8]
    7974:      	add	x16, sp, #0x80
    7978:      	ldr	x0, [x16, #0x10]
    797c:      	add	x16, sp, #0x50
    7980:      	str	x0, [x16, #0x10]
    7984:      	add	x16, sp, #0x80
    7988:      	ldr	x0, [x16, #0x18]
    798c:      	add	x16, sp, #0x50
    7990:      	str	x0, [x16, #0x18]
    7994:      	add	x16, sp, #0x80
    7998:      	ldr	x0, [x16, #0x20]
    799c:      	add	x16, sp, #0x50
    79a0:      	str	x0, [x16, #0x20]
    79a4:      	movn	x19, #0x0, lsl #48
    79a8:      	b	0x7a70 <_stogir.loops.reorder!+0xb20>
    79ac:      	add	x8, sp, #0x10
    79b0:      	mov	x0, x24
    79b4:      	bl	0x79b4 <_stogir.loops.reorder!+0xa64>
		00000000000079b4:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    79b8:      	add	x16, sp, #0x10
    79bc:      	ldr	x0, [x16]
    79c0:      	add	x16, sp, #0x10
    79c4:      	ldr	x1, [x16, #0x8]
    79c8:      	add	x16, sp, #0x10
    79cc:      	ldr	x2, [x16, #0x10]
    79d0:      	movz	x3, #0x0, lsl #48
    79d4:      	b	0x7250 <_stogir.loops.reorder!+0x300>
    79d8:      	orr	w1, w0, wzr
    79dc:      	ldr	x2, [x28]
    79e0:      	add	x2, x2, x0, lsl #2
    79e4:      	ldr	w2, [x2]
    79e8:      	sxtw	x2, w2
    79ec:      	add	x16, sp, #0x50
    79f0:      	ldr	x3, [x16]
    79f4:      	add	x2, x3, x2, lsl #2
    79f8:      	str	w1, [x2]
    79fc:      	ldr	x1, [x28, #0x8]
    7a00:      	add	x0, x0, #0x1
    7a04:      	cmp	x0, x1
    7a08:      	b.lt	0x79d8 <_stogir.loops.reorder!+0xa88>
    7a0c:      	add	x0, x24, #0x50
    7a10:      	add	x8, sp, #0xb0
    7a14:      	bl	0x7a14 <_stogir.loops.reorder!+0xac4>
		0000000000007a14:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge
    7a18:      	add	x16, sp, #0xb0
    7a1c:      	ldr	x19, [x16]
    7a20:      	add	x16, sp, #0xb0
    7a24:      	ldr	x20, [x16, #0x8]
    7a28:      	add	x16, sp, #0xb0
    7a2c:      	ldr	x21, [x16, #0x10]
    7a30:      	mov	x22, #0x1               ; =1
    7a34:      	b	0x7044 <_stogir.loops.reorder!+0xf4>
    7a38:      	movn	x0, #0x0, lsl #48
    7a3c:      	b	0x79fc <_stogir.loops.reorder!+0xaac>
    7a40:      	lsl	x0, x0, #1
    7a44:      	mov	x1, x0
    7a48:      	add	x0, sp, #0x50
    7a4c:      	bl	0x7a4c <_stogir.loops.reorder!+0xafc>
		0000000000007a4c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    7a50:      	add	x0, x20, #0x1
    7a54:      	add	x16, sp, #0x50
    7a58:      	ldr	x1, [x16]
    7a5c:      	add	x1, x1, x20, lsl #2
    7a60:      	movn	w17, #0x0, lsl #16
    7a64:      	str	w17, [x1]
    7a68:      	add	x16, sp, #0x50
    7a6c:      	str	x0, [x16, #0x8]
    7a70:      	ldr	x0, [x26, #0x8]
    7a74:      	add	x19, x19, #0x1
    7a78:      	cmp	x19, x0
    7a7c:      	b.ge	0x7a38 <_stogir.loops.reorder!+0xae8>
    7a80:      	add	x16, sp, #0x50
    7a84:      	ldr	x0, [x16, #0x8]
    7a88:      	orr	x20, x0, xzr
    7a8c:      	add	x16, sp, #0x50
    7a90:      	ldr	x0, [x16, #0x10]
    7a94:      	cmp	x20, x0
    7a98:      	b.lt	0x7a50 <_stogir.loops.reorder!+0xb00>
    7a9c:      	cmp	x0, #0x0
    7aa0:      	b.ne	0x7a40 <_stogir.loops.reorder!+0xaf0>
    7aa4:      	mov	x0, #0x2                ; =2
    7aa8:      	b	0x7a44 <_stogir.loops.reorder!+0xaf4>
    7aac:      	brk	#0
    7ab0:      	b	0x7aac <_stogir.loops.reorder!+0xb5c>
    7ab4:      	brk	#0
    7ab8:      	b	0x7ab4 <_stogir.loops.reorder!+0xb64>
    7abc:      	brk	#0
    7ac0:      	b	0x7abc <_stogir.loops.reorder!+0xb6c>
    7ac4:      	brk	#0
    7ac8:      	b	0x7ac4 <_stogir.loops.reorder!+0xb74>
    7acc:      	brk	#0
    7ad0:      	b	0x7acc <_stogir.loops.reorder!+0xb7c>
    7ad4:      	mov	x23, x8
    7ad8:      	mov	x24, x0
    7adc:      	mov	x25, x1
    7ae0:      	mov	x26, x2
    7ae4:      	mov	x27, x3
    7ae8:      	mov	x28, x4
    7aec:      	str	x5, [sp, #0x250]
    7af0:      	b	0x7398 <_stogir.loops.reorder!+0x448>
    7af4:      	mov	x23, x8
    7af8:      	mov	x24, x0
    7afc:      	mov	x25, x1
    7b00:      	mov	x26, x2
    7b04:      	mov	x27, x3
    7b08:      	mov	x28, x4
    7b0c:      	str	x5, [sp, #0x250]
    7b10:      	b	0x7398 <_stogir.loops.reorder!+0x448>
    7b14:      	mov	x23, x8
    7b18:      	mov	x24, x0
    7b1c:      	mov	x25, x1
    7b20:      	mov	x26, x2
    7b24:      	mov	x27, x3
    7b28:      	mov	x28, x4
    7b2c:      	str	x5, [sp, #0x250]
    7b30:      	b	0x7398 <_stogir.loops.reorder!+0x448>
    7b34:      	str	x20, [sp, #0x258]
    7b38:      	mov	x20, x0
    7b3c:      	b	0x7404 <_stogir.loops.reorder!+0x4b4>

0000000000007b40 <_stogir.schedule.order-with-uses>:
    7b40:      	sub	sp, sp, #0x2a0
    7b44:      	str	x29, [sp, #0x10]
    7b48:      	str	x30, [sp, #0x18]
    7b4c:      	add	x29, sp, #0x10
    7b50:      	str	x19, [sp, #0x248]
    7b54:      	str	x20, [sp, #0x250]
    7b58:      	str	x21, [sp, #0x258]
    7b5c:      	str	x22, [sp, #0x260]
    7b60:      	str	x23, [sp, #0x268]
    7b64:      	str	x24, [sp, #0x270]
    7b68:      	str	x25, [sp, #0x278]
    7b6c:      	str	x26, [sp, #0x280]
    7b70:      	str	x27, [sp, #0x288]
    7b74:      	str	x28, [sp, #0x290]
    7b78:      	mov	x19, x8
    7b7c:      	add	x8, sp, #0x50
    7b80:      	mov	x20, x0
    7b84:      	mov	x0, x4
    7b88:      	mov	x21, x1
    7b8c:      	mov	x22, x2
    7b90:      	mov	x23, x3
    7b94:      	mov	x24, x4
    7b98:      	bl	0x7b98 <_stogir.schedule.order-with-uses+0x58>
		0000000000007b98:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7b9c:      	add	x16, sp, #0x50
    7ba0:      	ldr	x0, [x16]
    7ba4:      	add	x16, sp, #0x20
    7ba8:      	str	x0, [x16]
    7bac:      	add	x16, sp, #0x50
    7bb0:      	ldr	x0, [x16, #0x8]
    7bb4:      	add	x16, sp, #0x20
    7bb8:      	str	x0, [x16, #0x8]
    7bbc:      	add	x16, sp, #0x50
    7bc0:      	ldr	x0, [x16, #0x10]
    7bc4:      	add	x16, sp, #0x20
    7bc8:      	str	x0, [x16, #0x10]
    7bcc:      	add	x16, sp, #0x50
    7bd0:      	ldr	x0, [x16, #0x18]
    7bd4:      	add	x16, sp, #0x20
    7bd8:      	str	x0, [x16, #0x18]
    7bdc:      	add	x16, sp, #0x50
    7be0:      	ldr	x0, [x16, #0x20]
    7be4:      	add	x16, sp, #0x20
    7be8:      	str	x0, [x16, #0x20]
    7bec:      	add	x8, sp, #0xb0
    7bf0:      	mov	x0, x24
    7bf4:      	bl	0x7bf4 <_stogir.schedule.order-with-uses+0xb4>
		0000000000007bf4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7bf8:      	add	x16, sp, #0xb0
    7bfc:      	ldr	x0, [x16]
    7c00:      	add	x16, sp, #0x80
    7c04:      	str	x0, [x16]
    7c08:      	add	x16, sp, #0xb0
    7c0c:      	ldr	x0, [x16, #0x8]
    7c10:      	add	x16, sp, #0x80
    7c14:      	str	x0, [x16, #0x8]
    7c18:      	add	x16, sp, #0xb0
    7c1c:      	ldr	x0, [x16, #0x10]
    7c20:      	add	x16, sp, #0x80
    7c24:      	str	x0, [x16, #0x10]
    7c28:      	add	x16, sp, #0xb0
    7c2c:      	ldr	x0, [x16, #0x18]
    7c30:      	add	x16, sp, #0x80
    7c34:      	str	x0, [x16, #0x18]
    7c38:      	add	x16, sp, #0xb0
    7c3c:      	ldr	x0, [x16, #0x20]
    7c40:      	add	x16, sp, #0x80
    7c44:      	str	x0, [x16, #0x20]
    7c48:      	add	x8, sp, #0x110
    7c4c:      	mov	x0, x24
    7c50:      	bl	0x7c50 <_stogir.schedule.order-with-uses+0x110>
		0000000000007c50:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7c54:      	add	x16, sp, #0x110
    7c58:      	ldr	x0, [x16]
    7c5c:      	add	x16, sp, #0xe0
    7c60:      	str	x0, [x16]
    7c64:      	add	x16, sp, #0x110
    7c68:      	ldr	x0, [x16, #0x8]
    7c6c:      	add	x16, sp, #0xe0
    7c70:      	str	x0, [x16, #0x8]
    7c74:      	add	x16, sp, #0x110
    7c78:      	ldr	x0, [x16, #0x10]
    7c7c:      	add	x16, sp, #0xe0
    7c80:      	str	x0, [x16, #0x10]
    7c84:      	add	x16, sp, #0x110
    7c88:      	ldr	x0, [x16, #0x18]
    7c8c:      	add	x16, sp, #0xe0
    7c90:      	str	x0, [x16, #0x18]
    7c94:      	add	x16, sp, #0x110
    7c98:      	ldr	x0, [x16, #0x20]
    7c9c:      	add	x16, sp, #0xe0
    7ca0:      	str	x0, [x16, #0x20]
    7ca4:      	add	x8, sp, #0x170
    7ca8:      	mov	x0, x24
    7cac:      	bl	0x7cac <_stogir.schedule.order-with-uses+0x16c>
		0000000000007cac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7cb0:      	add	x16, sp, #0x170
    7cb4:      	ldr	x0, [x16]
    7cb8:      	add	x16, sp, #0x140
    7cbc:      	str	x0, [x16]
    7cc0:      	add	x16, sp, #0x170
    7cc4:      	ldr	x0, [x16, #0x8]
    7cc8:      	add	x16, sp, #0x140
    7ccc:      	str	x0, [x16, #0x8]
    7cd0:      	add	x16, sp, #0x170
    7cd4:      	ldr	x0, [x16, #0x10]
    7cd8:      	add	x16, sp, #0x140
    7cdc:      	str	x0, [x16, #0x10]
    7ce0:      	add	x16, sp, #0x170
    7ce4:      	ldr	x0, [x16, #0x18]
    7ce8:      	add	x16, sp, #0x140
    7cec:      	str	x0, [x16, #0x18]
    7cf0:      	add	x16, sp, #0x170
    7cf4:      	ldr	x0, [x16, #0x20]
    7cf8:      	add	x16, sp, #0x140
    7cfc:      	str	x0, [x16, #0x20]
    7d00:      	ldr	x0, [x20, #0x8]
    7d04:      	mov	x1, x0
    7d08:      	add	x0, sp, #0x80
    7d0c:      	bl	0x7d0c <_stogir.schedule.order-with-uses+0x1cc>
		0000000000007d0c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    7d10:      	ldr	x0, [x20, #0x8]
    7d14:      	mov	x1, x0
    7d18:      	add	x0, sp, #0xe0
    7d1c:      	bl	0x7d1c <_stogir.schedule.order-with-uses+0x1dc>
		0000000000007d1c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64
    7d20:      	movz	x25, #0x0, lsl #48
    7d24:      	b	0x7d5c <_stogir.schedule.order-with-uses+0x21c>
    7d28:      	lsl	x0, x0, #1
    7d2c:      	mov	x1, x0
    7d30:      	add	x0, sp, #0x20
    7d34:      	bl	0x7d34 <_stogir.schedule.order-with-uses+0x1f4>
		0000000000007d34:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    7d38:      	add	x25, x25, #0x1
    7d3c:      	add	x0, x26, #0x1
    7d40:      	add	x16, sp, #0x20
    7d44:      	ldr	x1, [x16]
    7d48:      	add	x1, x1, x26, lsl #3
    7d4c:      	movn	x17, #0x0, lsl #48
    7d50:      	str	x17, [x1]
    7d54:      	add	x16, sp, #0x20
    7d58:      	str	x0, [x16, #0x8]
    7d5c:      	ldr	x0, [x20, #0x8]
    7d60:      	cmp	x25, x0
    7d64:      	b.ge	0x7d94 <_stogir.schedule.order-with-uses+0x254>
    7d68:      	add	x16, sp, #0x20
    7d6c:      	ldr	x0, [x16, #0x8]
    7d70:      	orr	x26, x0, xzr
    7d74:      	add	x16, sp, #0x20
    7d78:      	ldr	x0, [x16, #0x10]
    7d7c:      	cmp	x26, x0
    7d80:      	b.lt	0x7d38 <_stogir.schedule.order-with-uses+0x1f8>
    7d84:      	cmp	x0, #0x0
    7d88:      	b.ne	0x7d28 <_stogir.schedule.order-with-uses+0x1e8>
    7d8c:      	mov	x0, #0x2                ; =2
    7d90:      	b	0x7d2c <_stogir.schedule.order-with-uses+0x1ec>
    7d94:      	mov	x25, #0x1               ; =1
    7d98:      	adrp	x27, 0x7000 <_stogir.loops.reorder!+0xb0>
		0000000000007d98:  ARM64_RELOC_PAGE21	l_stogir.440
    7d9c:      	ldr	x27, [x27]
		0000000000007d9c:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    7da0:      	movz	x28, #0x0, lsl #48
    7da4:      	movz	x26, #0x0, lsl #48
    7da8:      	b	0x7fc4 <_stogir.schedule.order-with-uses+0x484>
    7dac:      	add	x16, sp, #0xe0
    7db0:      	ldr	x0, [x16]
    7db4:      	orr	x1, x0, xzr
    7db8:      	add	x1, x1, x19, lsl #3
    7dbc:      	add	x0, x0, x19, lsl #3
    7dc0:      	ldr	x1, [x1]
    7dc4:      	add	x1, x1, #0x1
    7dc8:      	str	x1, [x0]
    7dcc:      	sxtw	x27, w27
    7dd0:      	cmp	x22, #0x43
    7dd4:      	cset	w0, eq
    7dd8:      	cmp	x22, #0x83
    7ddc:      	cset	w1, lt
    7de0:      	adrp	x17, 0x7000 <_stogir.loops.reorder!+0xb0>
		0000000000007de0:  ARM64_RELOC_PAGE21	l_stogir.441
    7de4:      	ldr	x17, [x17]
		0000000000007de4:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    7de8:      	add	x2, x22, x17
    7dec:      	adrp	x16, 0x7000 <_stogir.loops.reorder!+0xb0>
		0000000000007dec:  ARM64_RELOC_PAGE21	l_stogir.442
    7df0:      	ldr	x16, [x16]
		0000000000007df0:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    7df4:      	add	x3, x16, x22, lsl #2
    7df8:      	orr	x22, x3, xzr
    7dfc:      	mov	x3, #0x1                ; =1
    7e00:      	movz	x4, #0x0, lsl #48
    7e04:      	b	0x7e78 <_stogir.schedule.order-with-uses+0x338>
    7e08:      	movz	w5, #0x0, lsl #16
    7e0c:      	uxtb	w16, w5
    7e10:      	and	w5, w16, #0x2
    7e14:      	uxtb	w5, w5
    7e18:      	ubfx	x5, x5, #0, #8
    7e1c:      	cmp	x5, #0x0
    7e20:      	cset	w5, eq
    7e24:      	uxtb	w16, w5
    7e28:      	cmp	w16, wzr
    7e2c:      	cset	x5, eq
    7e30:      	cmp	x5, #0x0
    7e34:      	b.eq	0x7e94 <_stogir.schedule.order-with-uses+0x354>
    7e38:      	str	w24, [sp, #0x220]
    7e3c:      	mov	x24, x4
    7e40:      	str	w0, [sp, #0x200]
    7e44:      	str	w1, [sp, #0x208]
    7e48:      	str	x2, [sp, #0x210]
    7e4c:      	str	x22, [sp, #0x218]
    7e50:      	mov	x22, x3
    7e54:      	add	x0, x22, #0x1
    7e58:      	sxtw	x22, w0
    7e5c:      	ldr	w0, [sp, #0x200]
    7e60:      	ldr	w1, [sp, #0x208]
    7e64:      	ldr	x2, [sp, #0x210]
    7e68:      	mov	x3, x22
    7e6c:      	ldr	x22, [sp, #0x218]
    7e70:      	mov	x4, x24
    7e74:      	ldr	w24, [sp, #0x220]
    7e78:      	cmp	x3, x27
    7e7c:      	b.gt	0x8674 <_stogir.schedule.order-with-uses+0xb34>
    7e80:      	uxtb	w16, w1
    7e84:      	cmp	w16, wzr
    7e88:      	b.eq	0x7e08 <_stogir.schedule.order-with-uses+0x2c8>
    7e8c:      	ldrb	w5, [x2]
    7e90:      	b	0x7e0c <_stogir.schedule.order-with-uses+0x2cc>
    7e94:      	orr	w5, w3, wzr
    7e98:      	sxtw	x6, w5
    7e9c:      	uxtb	w16, w0
    7ea0:      	cmp	w16, wzr
    7ea4:      	b.eq	0x7ed0 <_stogir.schedule.order-with-uses+0x390>
    7ea8:      	cmp	x6, #0x2
    7eac:      	b.lt	0x7ed0 <_stogir.schedule.order-with-uses+0x390>
    7eb0:      	str	w24, [sp, #0x220]
    7eb4:      	mov	x24, x4
    7eb8:      	str	w0, [sp, #0x200]
    7ebc:      	str	w1, [sp, #0x208]
    7ec0:      	str	x2, [sp, #0x210]
    7ec4:      	str	x22, [sp, #0x218]
    7ec8:      	mov	x22, x3
    7ecc:      	b	0x7e54 <_stogir.schedule.order-with-uses+0x314>
    7ed0:      	uxtb	w16, w1
    7ed4:      	cmp	w16, wzr
    7ed8:      	b.eq	0x7f00 <_stogir.schedule.order-with-uses+0x3c0>
    7edc:      	ldr	w7, [x22]
    7ee0:      	cmp	x6, #0x0
    7ee4:      	b.le	0x7ef8 <_stogir.schedule.order-with-uses+0x3b8>
    7ee8:      	cmp	x6, #0x4
    7eec:      	b.le	0x8614 <_stogir.schedule.order-with-uses+0xad4>
    7ef0:      	mov	w6, #0x4                ; =4
    7ef4:      	b	0x8618 <_stogir.schedule.order-with-uses+0xad8>
    7ef8:      	movz	w6, #0x0, lsl #16
    7efc:      	b	0x7f04 <_stogir.schedule.order-with-uses+0x3c4>
    7f00:      	movz	w6, #0x0, lsl #16
    7f04:      	ubfx	x6, x6, #0, #32
    7f08:      	cmp	x6, #0xf
    7f0c:      	b.hs	0x867c <_stogir.schedule.order-with-uses+0xb3c>
    7f10:      	mov	x16, #0x1               ; =1
    7f14:      	lsl	x6, x16, x6
    7f18:      	mov	w17, #0x5e1c            ; =24092
    7f1c:      	and	w6, w6, w17
    7f20:      	ubfx	x6, x6, #0, #32
    7f24:      	cmp	x6, #0x0
    7f28:      	b.eq	0x869c <_stogir.schedule.order-with-uses+0xb5c>
    7f2c:      	str	w0, [sp, #0x200]
    7f30:      	mov	x0, x20
    7f34:      	str	w1, [sp, #0x208]
    7f38:      	mov	w1, w24
    7f3c:      	str	x2, [sp, #0x210]
    7f40:      	mov	w2, w5
    7f44:      	str	x22, [sp, #0x218]
    7f48:      	mov	x22, x3
    7f4c:      	str	w24, [sp, #0x220]
    7f50:      	mov	x24, x4
    7f54:      	bl	0x7f54 <_stogir.schedule.order-with-uses+0x414>
		0000000000007f54:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    7f58:      	ubfx	x0, x0, #0, #32
    7f5c:      	lsr	x16, x0, #0
    7f60:      	cmp	x16, #0x1
    7f64:      	b.eq	0x7f80 <_stogir.schedule.order-with-uses+0x440>
    7f68:      	b.lo	0x7f70 <_stogir.schedule.order-with-uses+0x430>
    7f6c:      	b	0x7f84 <_stogir.schedule.order-with-uses+0x444>
    7f70:      	cmp	x16, #0x0
    7f74:      	b.eq	0x7f7c <_stogir.schedule.order-with-uses+0x43c>
    7f78:      	b	0x7f84 <_stogir.schedule.order-with-uses+0x444>
    7f7c:      	b	0x7f88 <_stogir.schedule.order-with-uses+0x448>
    7f80:      	b	0x862c <_stogir.schedule.order-with-uses+0xaec>
    7f84:      	b	0x866c <_stogir.schedule.order-with-uses+0xb2c>
    7f88:      	adrp	x16, 0x7000 <_stogir.loops.reorder!+0xb0>
		0000000000007f88:  ARM64_RELOC_PAGE21	l_stogir.443
    7f8c:      	ldr	x16, [x16]
		0000000000007f8c:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    7f90:      	str	x16, [sp, #0x1f0]
    7f94:      	mov	x28, #0x19              ; =25
    7f98:      	b	0x8654 <_stogir.schedule.order-with-uses+0xb14>
    7f9c:      	add	x26, x26, #0x1
    7fa0:      	add	x16, sp, #0x20
    7fa4:      	ldr	x0, [x16]
    7fa8:      	add	x0, x0, x25, lsl #3
    7fac:      	str	x24, [x0]
    7fb0:      	add	x25, x25, #0x1
    7fb4:      	ldr	x19, [sp, #0x1e8]
    7fb8:      	ldr	x22, [sp, #0x1f8]
    7fbc:      	ldr	x24, [sp, #0x1e0]
    7fc0:      	ldr	x27, [sp, #0x1f0]
    7fc4:      	cmp	x28, #0x0
    7fc8:      	b.ne	0x86bc <_stogir.schedule.order-with-uses+0xb7c>
    7fcc:      	add	x16, sp, #0x20
    7fd0:      	ldr	x0, [x16, #0x8]
    7fd4:      	cmp	x25, x0
    7fd8:      	b.ge	0x86d0 <_stogir.schedule.order-with-uses+0xb90>
    7fdc:      	orr	w0, w25, wzr
    7fe0:      	mov	w1, w0
    7fe4:      	str	x24, [sp, #0x1e0]
    7fe8:      	mov	w24, w0
    7fec:      	mov	x0, x20
    7ff0:      	bl	0x7ff0 <_stogir.schedule.order-with-uses+0x4b0>
		0000000000007ff0:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
    7ff4:      	cmp	x0, #0x0
    7ff8:      	b.eq	0x86e4 <_stogir.schedule.order-with-uses+0xba4>
    7ffc:      	ldr	x0, [x22]
    8000:      	add	x0, x25, x0
    8004:      	ldrb	w0, [x0]
    8008:      	cmp	x0, #0x0
    800c:      	b.eq	0x86f4 <_stogir.schedule.order-with-uses+0xbb4>
    8010:      	ldr	x0, [x21]
    8014:      	add	x0, x0, x25, lsl #2
    8018:      	ldr	w0, [x0]
    801c:      	sxtw	x0, w0
    8020:      	ldr	x1, [x20]
    8024:      	add	x1, x1, x25, lsl #4
    8028:      	ldr	x1, [x1]
    802c:      	ldr	x2, [x20, #0x78]
    8030:      	add	x2, x2, x25, lsl #2
    8034:      	ldr	w2, [x2]
    8038:      	cmp	x0, #0x0
    803c:      	b.gt	0x805c <_stogir.schedule.order-with-uses+0x51c>
    8040:      	str	x19, [sp, #0x1e8]
    8044:      	str	x22, [sp, #0x1f8]
    8048:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		0000000000008048:  ARM64_RELOC_PAGE21	l_stogir.444
    804c:      	ldr	x16, [x16]
		000000000000804c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    8050:      	str	x16, [sp, #0x1f0]
    8054:      	mov	x28, #0x19              ; =25
    8058:      	b	0x7fb0 <_stogir.schedule.order-with-uses+0x470>
    805c:      	uxtb	w1, w1
    8060:      	orr	x3, x1, xzr
    8064:      	str	x19, [sp, #0x1e8]
    8068:      	mov	x19, x0
    806c:      	mov	w0, w3
    8070:      	str	x27, [sp, #0x1f0]
    8074:      	mov	w27, w2
    8078:      	str	x22, [sp, #0x1f8]
    807c:      	mov	w22, w1
    8080:      	bl	0x8080 <_stogir.schedule.order-with-uses+0x540>
		0000000000008080:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    8084:      	cmp	x0, #0x0
    8088:      	b.eq	0x7dac <_stogir.schedule.order-with-uses+0x26c>
    808c:      	add	x16, sp, #0x80
    8090:      	ldr	x0, [x16]
    8094:      	add	x1, x0, x19, lsl #2
    8098:      	ldr	w1, [x1]
    809c:      	sxtw	x1, w1
    80a0:      	cmp	x1, #0x0
    80a4:      	b.ne	0x8658 <_stogir.schedule.order-with-uses+0xb18>
    80a8:      	add	x0, x0, x19, lsl #2
    80ac:      	str	w24, [x0]
    80b0:      	b	0x8668 <_stogir.schedule.order-with-uses+0xb28>
    80b4:      	lsl	x3, x3, #1
    80b8:      	str	x0, [sp, #0x228]
    80bc:      	add	x0, sp, #0x140
    80c0:      	str	x6, [sp, #0x1f8]
    80c4:      	str	w19, [sp, #0x230]
    80c8:      	mov	x19, x1
    80cc:      	mov	x1, x3
    80d0:      	str	x20, [sp, #0x238]
    80d4:      	mov	w20, w4
    80d8:      	str	x21, [sp, #0x240]
    80dc:      	mov	x21, x2
    80e0:      	bl	0x80e0 <_stogir.schedule.order-with-uses+0x5a0>
		00000000000080e0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    80e4:      	add	x0, x21, #0x1
    80e8:      	add	x16, sp, #0x140
    80ec:      	ldr	x1, [x16]
    80f0:      	add	x1, x1, x21, lsl #2
    80f4:      	str	w20, [x1]
    80f8:      	add	x16, sp, #0x140
    80fc:      	str	x0, [x16, #0x8]
    8100:      	b	0x8278 <_stogir.schedule.order-with-uses+0x738>
    8104:      	mov	x19, #0x1               ; =1
    8108:      	b	0x8140 <_stogir.schedule.order-with-uses+0x600>
    810c:      	nop
    8110:      	lsl	x0, x0, #1
    8114:      	mov	x1, x0
    8118:      	add	x0, sp, #0x140
    811c:      	bl	0x811c <_stogir.schedule.order-with-uses+0x5dc>
		000000000000811c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8120:      	add	x0, x24, #0x1
    8124:      	add	x16, sp, #0x140
    8128:      	ldr	x1, [x16]
    812c:      	add	x1, x1, x24, lsl #2
    8130:      	str	w22, [x1]
    8134:      	add	x16, sp, #0x140
    8138:      	str	x0, [x16, #0x8]
    813c:      	add	x19, x19, #0x1
    8140:      	add	x16, sp, #0x20
    8144:      	ldr	x0, [x16, #0x8]
    8148:      	cmp	x19, x0
    814c:      	b.ge	0x8208 <_stogir.schedule.order-with-uses+0x6c8>
    8150:      	add	x16, sp, #0x20
    8154:      	ldr	x0, [x16]
    8158:      	orr	x1, x0, xzr
    815c:      	add	x2, x1, x19, lsl #3
    8160:      	ldr	x2, [x2]
    8164:      	cmp	x2, #0x0
    8168:      	b.lt	0x813c <_stogir.schedule.order-with-uses+0x5fc>
    816c:      	orr	w22, w19, wzr
    8170:      	ldr	x2, [x21]
    8174:      	sxtw	x3, w22
    8178:      	add	x2, x2, x19, lsl #2
    817c:      	ldr	w2, [x2]
    8180:      	sxtw	x2, w2
    8184:      	add	x16, sp, #0x80
    8188:      	ldr	x4, [x16]
    818c:      	add	x4, x4, x2, lsl #2
    8190:      	ldr	w4, [x4]
    8194:      	sxtw	x4, w4
    8198:      	cmp	x4, x3
    819c:      	b.ne	0x81c4 <_stogir.schedule.order-with-uses+0x684>
    81a0:      	add	x1, x1, x19, lsl #3
    81a4:      	add	x0, x0, x19, lsl #3
    81a8:      	ldr	x1, [x1]
    81ac:      	add	x16, sp, #0xe0
    81b0:      	ldr	x3, [x16]
    81b4:      	add	x2, x3, x2, lsl #3
    81b8:      	ldr	x2, [x2]
    81bc:      	add	x1, x2, x1
    81c0:      	str	x1, [x0]
    81c4:      	add	x16, sp, #0x20
    81c8:      	ldr	x0, [x16]
    81cc:      	add	x0, x0, x19, lsl #3
    81d0:      	ldr	x0, [x0]
    81d4:      	cmp	x0, #0x0
    81d8:      	b.ne	0x813c <_stogir.schedule.order-with-uses+0x5fc>
    81dc:      	add	x16, sp, #0x140
    81e0:      	ldr	x0, [x16, #0x8]
    81e4:      	orr	x24, x0, xzr
    81e8:      	add	x16, sp, #0x140
    81ec:      	ldr	x0, [x16, #0x10]
    81f0:      	cmp	x24, x0
    81f4:      	b.lt	0x8120 <_stogir.schedule.order-with-uses+0x5e0>
    81f8:      	cmp	x0, #0x0
    81fc:      	b.ne	0x8110 <_stogir.schedule.order-with-uses+0x5d0>
    8200:      	mov	x0, #0x2                ; =2
    8204:      	b	0x8114 <_stogir.schedule.order-with-uses+0x5d4>
    8208:      	cmp	x28, #0x0
    820c:      	cset	w19, eq
    8210:      	movz	x22, #0x0, lsl #48
    8214:      	b	0x83c4 <_stogir.schedule.order-with-uses+0x884>
    8218:      	sub	w2, w2, #0x1
    821c:      	lsl	w2, w2, #2
    8220:      	ubfx	x2, x2, #0, #32
    8224:      	lsr	x2, x3, x2
    8228:      	and	w2, w2, #0xf
    822c:      	b	0x8454 <_stogir.schedule.order-with-uses+0x914>
    8230:      	movz	w8, #0x0, lsl #16
    8234:      	uxtb	w16, w8
    8238:      	and	w8, w16, #0x2
    823c:      	uxtb	w8, w8
    8240:      	ubfx	x8, x8, #0, #8
    8244:      	cmp	x8, #0x0
    8248:      	cset	w8, eq
    824c:      	uxtb	w16, w8
    8250:      	cmp	w16, wzr
    8254:      	cset	x8, eq
    8258:      	cmp	x8, #0x0
    825c:      	b.eq	0x8318 <_stogir.schedule.order-with-uses+0x7d8>
    8260:      	str	x20, [sp, #0x238]
    8264:      	str	x21, [sp, #0x240]
    8268:      	str	x6, [sp, #0x1f8]
    826c:      	str	x0, [sp, #0x228]
    8270:      	str	w19, [sp, #0x230]
    8274:      	mov	x19, x1
    8278:      	add	x19, x19, #0x1
    827c:      	ldr	x20, [sp, #0x238]
    8280:      	ldr	x21, [sp, #0x240]
    8284:      	ldr	x0, [sp, #0x228]
    8288:      	mov	x1, x19
    828c:      	ldr	w19, [sp, #0x230]
    8290:      	cmp	x1, x0
    8294:      	b.ge	0x8704 <_stogir.schedule.order-with-uses+0xbc4>
    8298:      	add	x2, x27, x1
    829c:      	ldr	x3, [x23, #0x28]
    82a0:      	add	x2, x3, x2, lsl #3
    82a4:      	ldr	x2, [x2]
    82a8:      	ldr	x3, [x20]
    82ac:      	orr	w4, w2, wzr
    82b0:      	sxtw	x5, w4
    82b4:      	add	x3, x3, x5, lsl #4
    82b8:      	ldr	x3, [x3]
    82bc:      	ldr	x6, [sp, #0x1f8]
    82c0:      	ldr	x7, [x6]
    82c4:      	add	x7, x7, x5
    82c8:      	ldrb	w7, [x7]
    82cc:      	cmp	x7, #0x0
    82d0:      	b.eq	0x8714 <_stogir.schedule.order-with-uses+0xbd4>
    82d4:      	ldr	x7, [x21]
    82d8:      	add	x7, x7, x5, lsl #2
    82dc:      	ldr	w7, [x7]
    82e0:      	sxtw	x7, w7
    82e4:      	cmp	x7, x25
    82e8:      	b.ne	0x8730 <_stogir.schedule.order-with-uses+0xbf0>
    82ec:      	uxtb	w3, w3
    82f0:      	cmp	x3, #0x83
    82f4:      	cset	w7, lt
    82f8:      	uxtb	w16, w7
    82fc:      	cmp	w16, wzr
    8300:      	b.eq	0x8230 <_stogir.schedule.order-with-uses+0x6f0>
    8304:      	adrp	x17, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		0000000000008304:  ARM64_RELOC_PAGE21	l_stogir.441
    8308:      	ldr	x17, [x17]
		0000000000008308:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    830c:      	add	x8, x3, x17
    8310:      	ldrb	w8, [x8]
    8314:      	b	0x8234 <_stogir.schedule.order-with-uses+0x6f4>
    8318:      	lsr	x2, x2, #32
    831c:      	sxtw	x8, w2
    8320:      	cmp	x3, #0x43
    8324:      	b.ne	0x841c <_stogir.schedule.order-with-uses+0x8dc>
    8328:      	cmp	x8, #0x2
    832c:      	b.lt	0x841c <_stogir.schedule.order-with-uses+0x8dc>
    8330:      	str	x20, [sp, #0x238]
    8334:      	str	x21, [sp, #0x240]
    8338:      	str	x6, [sp, #0x1f8]
    833c:      	str	x0, [sp, #0x228]
    8340:      	str	w19, [sp, #0x230]
    8344:      	mov	x19, x1
    8348:      	b	0x8278 <_stogir.schedule.order-with-uses+0x738>
    834c:      	add	x16, sp, #0x80
    8350:      	ldr	x0, [x16]
    8354:      	add	x0, x0, x25, lsl #2
    8358:      	ldr	w0, [x0]
    835c:      	sxtw	x1, w0
    8360:      	cmp	x1, #0x0
    8364:      	b.le	0x83b4 <_stogir.schedule.order-with-uses+0x874>
    8368:      	cmp	x1, x24
    836c:      	b.eq	0x83b4 <_stogir.schedule.order-with-uses+0x874>
    8370:      	add	x16, sp, #0x20
    8374:      	ldr	x2, [x16]
    8378:      	orr	x3, x2, xzr
    837c:      	add	x3, x3, x1, lsl #3
    8380:      	add	x2, x2, x1, lsl #3
    8384:      	ldr	x3, [x3]
    8388:      	sub	x3, x3, #0x1
    838c:      	str	x3, [x2]
    8390:      	add	x16, sp, #0x20
    8394:      	ldr	x2, [x16]
    8398:      	add	x1, x2, x1, lsl #3
    839c:      	ldr	x1, [x1]
    83a0:      	cmp	x1, #0x0
    83a4:      	b.ne	0x83b4 <_stogir.schedule.order-with-uses+0x874>
    83a8:      	mov	w1, w0
    83ac:      	add	x0, sp, #0x140
    83b0:      	bl	0x83b0 <_stogir.schedule.order-with-uses+0x870>
		00000000000083b0:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    83b4:      	add	x22, x22, #0x1
    83b8:      	ldr	x20, [sp, #0x238]
    83bc:      	ldr	x21, [sp, #0x240]
    83c0:      	ldr	w19, [sp, #0x230]
    83c4:      	uxtb	w16, w19
    83c8:      	cmp	w16, wzr
    83cc:      	b.eq	0x874c <_stogir.schedule.order-with-uses+0xc0c>
    83d0:      	add	x16, sp, #0x140
    83d4:      	ldr	x0, [x16, #0x8]
    83d8:      	cmp	x22, x0
    83dc:      	b.ge	0x8754 <_stogir.schedule.order-with-uses+0xc14>
    83e0:      	add	x16, sp, #0x140
    83e4:      	ldr	x0, [x16]
    83e8:      	add	x0, x0, x22, lsl #2
    83ec:      	ldr	w0, [x0]
    83f0:      	sxtw	x24, w0
    83f4:      	ldr	x0, [x21]
    83f8:      	add	x0, x0, x24, lsl #2
    83fc:      	ldr	w0, [x0]
    8400:      	sxtw	x25, w0
    8404:      	ldr	x0, [x23]
    8408:      	add	x0, x0, x24, lsl #4
    840c:      	ldr	x27, [x0]
    8410:      	ldr	x0, [x0, #0x8]
    8414:      	movz	x1, #0x0, lsl #48
    8418:      	b	0x8290 <_stogir.schedule.order-with-uses+0x750>
    841c:      	uxtb	w16, w7
    8420:      	cmp	w16, wzr
    8424:      	b.eq	0x8458 <_stogir.schedule.order-with-uses+0x918>
    8428:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		0000000000008428:  ARM64_RELOC_PAGE21	l_stogir.442
    842c:      	ldr	x16, [x16]
		000000000000842c:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8430:      	add	x3, x16, x3, lsl #2
    8434:      	ldr	w3, [x3]
    8438:      	cmp	x8, #0x0
    843c:      	b.le	0x8450 <_stogir.schedule.order-with-uses+0x910>
    8440:      	cmp	x8, #0x4
    8444:      	b.le	0x8218 <_stogir.schedule.order-with-uses+0x6d8>
    8448:      	mov	w2, #0x4                ; =4
    844c:      	b	0x821c <_stogir.schedule.order-with-uses+0x6dc>
    8450:      	movz	w2, #0x0, lsl #16
    8454:      	b	0x845c <_stogir.schedule.order-with-uses+0x91c>
    8458:      	movz	w2, #0x0, lsl #16
    845c:      	ubfx	x2, x2, #0, #32
    8460:      	cmp	x2, #0xf
    8464:      	b.hs	0x875c <_stogir.schedule.order-with-uses+0xc1c>
    8468:      	mov	x16, #0x1               ; =1
    846c:      	lsl	x2, x16, x2
    8470:      	mov	w17, #0x5e1c            ; =24092
    8474:      	and	w2, w2, w17
    8478:      	ubfx	x2, x2, #0, #32
    847c:      	cmp	x2, #0x0
    8480:      	b.eq	0x8778 <_stogir.schedule.order-with-uses+0xc38>
    8484:      	add	x16, sp, #0x20
    8488:      	ldr	x2, [x16]
    848c:      	orr	x3, x2, xzr
    8490:      	add	x3, x3, x5, lsl #3
    8494:      	add	x2, x2, x5, lsl #3
    8498:      	ldr	x3, [x3]
    849c:      	sub	x3, x3, #0x1
    84a0:      	str	x3, [x2]
    84a4:      	add	x16, sp, #0x20
    84a8:      	ldr	x2, [x16]
    84ac:      	add	x2, x2, x5, lsl #3
    84b0:      	ldr	x2, [x2]
    84b4:      	cmp	x2, #0x0
    84b8:      	b.ne	0x8794 <_stogir.schedule.order-with-uses+0xc54>
    84bc:      	add	x16, sp, #0x140
    84c0:      	ldr	x2, [x16, #0x8]
    84c4:      	add	x16, sp, #0x140
    84c8:      	ldr	x3, [x16, #0x10]
    84cc:      	cmp	x2, x3
    84d0:      	b.lt	0x87b0 <_stogir.schedule.order-with-uses+0xc70>
    84d4:      	cmp	x3, #0x0
    84d8:      	b.ne	0x80b4 <_stogir.schedule.order-with-uses+0x574>
    84dc:      	mov	x3, #0x2                ; =2
    84e0:      	b	0x80b8 <_stogir.schedule.order-with-uses+0x578>
    84e4:      	add	x0, sp, #0x20
    84e8:      	bl	0x84e8 <_stogir.schedule.order-with-uses+0x9a8>
		00000000000084e8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    84ec:      	add	x0, sp, #0x80
    84f0:      	bl	0x84f0 <_stogir.schedule.order-with-uses+0x9b0>
		00000000000084f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    84f4:      	add	x0, sp, #0xe0
    84f8:      	bl	0x84f8 <_stogir.schedule.order-with-uses+0x9b8>
		00000000000084f8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    84fc:      	ldr	x0, [sp, #0x1f0]
    8500:      	mov	x1, x28
    8504:      	adrp	x2, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		0000000000008504:  ARM64_RELOC_PAGE21	l_stogir.440
    8508:      	ldr	x2, [x2]
		0000000000008508:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    850c:      	movz	x3, #0x0, lsl #48
    8510:      	bl	0x8510 <_stogir.schedule.order-with-uses+0x9d0>
		0000000000008510:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    8514:      	cmp	x0, #0x0
    8518:      	b.eq	0x853c <_stogir.schedule.order-with-uses+0x9fc>
    851c:      	add	x0, sp, #0x140
    8520:      	bl	0x8520 <_stogir.schedule.order-with-uses+0x9e0>
		0000000000008520:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    8524:      	cmp	x0, x26
    8528:      	b.eq	0x853c <_stogir.schedule.order-with-uses+0x9fc>
    852c:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		000000000000852c:  ARM64_RELOC_PAGE21	l_stogir.445
    8530:      	ldr	x16, [x16]
		0000000000008530:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    8534:      	str	x16, [sp, #0x1f0]
    8538:      	mov	x28, #0x16              ; =22
    853c:      	ldr	x0, [sp, #0x1f0]
    8540:      	mov	x1, x28
    8544:      	adrp	x2, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		0000000000008544:  ARM64_RELOC_PAGE21	l_stogir.440
    8548:      	ldr	x2, [x2]
		0000000000008548:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    854c:      	movz	x3, #0x0, lsl #48
    8550:      	bl	0x8550 <_stogir.schedule.order-with-uses+0xa10>
		0000000000008550:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    8554:      	cmp	x0, #0x0
    8558:      	b.eq	0x87d4 <_stogir.schedule.order-with-uses+0xc94>
    855c:      	add	x8, sp, #0x1a0
    8560:      	ldr	x0, [sp, #0x238]
    8564:      	add	x1, sp, #0x140
    8568:      	ldr	x2, [sp, #0x1e0]
    856c:      	bl	0x856c <_stogir.schedule.order-with-uses+0xa2c>
		000000000000856c:  ARM64_RELOC_BRANCH26	_stogir.schedule.entry-prefix
    8570:      	add	x16, sp, #0x1a0
    8574:      	ldr	x19, [x16]
    8578:      	add	x16, sp, #0x1a0
    857c:      	ldr	x28, [x16, #0x8]
    8580:      	add	x16, sp, #0x1a0
    8584:      	ldr	x20, [x16, #0x10]
    8588:      	add	x16, sp, #0x1a0
    858c:      	ldr	x21, [x16, #0x18]
    8590:      	add	x16, sp, #0x1a0
    8594:      	ldr	x22, [x16, #0x20]
    8598:      	add	x0, sp, #0x140
    859c:      	bl	0x859c <_stogir.schedule.order-with-uses+0xa5c>
		000000000000859c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    85a0:      	movz	x0, #0x0, lsl #48
    85a4:      	b	0x85c0 <_stogir.schedule.order-with-uses+0xa80>
    85a8:      	add	x0, sp, #0x140
    85ac:      	bl	0x85ac <_stogir.schedule.order-with-uses+0xa6c>
		00000000000085ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    85b0:      	mov	x0, #0x1                ; =1
    85b4:      	movz	x20, #0x0, lsl #48
    85b8:      	movz	x21, #0x0, lsl #48
    85bc:      	movz	x22, #0x0, lsl #48
    85c0:      	ldr	x1, [sp, #0x1e8]
    85c4:      	str	x0, [x1]
    85c8:      	str	x19, [x1, #0x8]
    85cc:      	str	x28, [x1, #0x10]
    85d0:      	str	x20, [x1, #0x18]
    85d4:      	str	x21, [x1, #0x20]
    85d8:      	str	x22, [x1, #0x28]
    85dc:      	ldr	x19, [sp, #0x248]
    85e0:      	ldr	x20, [sp, #0x250]
    85e4:      	ldr	x21, [sp, #0x258]
    85e8:      	ldr	x22, [sp, #0x260]
    85ec:      	ldr	x23, [sp, #0x268]
    85f0:      	ldr	x24, [sp, #0x270]
    85f4:      	ldr	x25, [sp, #0x278]
    85f8:      	ldr	x26, [sp, #0x280]
    85fc:      	ldr	x27, [sp, #0x288]
    8600:      	ldr	x28, [sp, #0x290]
    8604:      	ldr	x29, [sp, #0x10]
    8608:      	ldr	x30, [sp, #0x18]
    860c:      	add	sp, sp, #0x2a0
    8610:      	ret
    8614:      	sub	w6, w5, #0x1
    8618:      	lsl	w6, w6, #2
    861c:      	ubfx	x6, x6, #0, #32
    8620:      	lsr	x6, x7, x6
    8624:      	and	w6, w6, #0xf
    8628:      	b	0x7efc <_stogir.schedule.order-with-uses+0x3bc>
    862c:      	sxtw	x1, w1
    8630:      	cmp	x1, #0x0
    8634:      	b.le	0x8654 <_stogir.schedule.order-with-uses+0xb14>
    8638:      	ldr	x0, [x21]
    863c:      	add	x0, x0, x1, lsl #2
    8640:      	ldr	w0, [x0]
    8644:      	sxtw	x0, w0
    8648:      	cmp	x0, x19
    864c:      	b.ne	0x8654 <_stogir.schedule.order-with-uses+0xb14>
    8650:      	add	x24, x24, #0x1
    8654:      	b	0x7e54 <_stogir.schedule.order-with-uses+0x314>
    8658:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		0000000000008658:  ARM64_RELOC_PAGE21	l_stogir.446
    865c:      	ldr	x16, [x16]
		000000000000865c:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    8660:      	str	x16, [sp, #0x1f0]
    8664:      	mov	x28, #0x13              ; =19
    8668:      	b	0x7dcc <_stogir.schedule.order-with-uses+0x28c>
    866c:      	brk	#0
    8670:      	b	0x866c <_stogir.schedule.order-with-uses+0xb2c>
    8674:      	mov	x24, x4
    8678:      	b	0x7f9c <_stogir.schedule.order-with-uses+0x45c>
    867c:      	str	w24, [sp, #0x220]
    8680:      	mov	x24, x4
    8684:      	str	w0, [sp, #0x200]
    8688:      	str	w1, [sp, #0x208]
    868c:      	str	x2, [sp, #0x210]
    8690:      	str	x22, [sp, #0x218]
    8694:      	mov	x22, x3
    8698:      	b	0x7e54 <_stogir.schedule.order-with-uses+0x314>
    869c:      	str	w24, [sp, #0x220]
    86a0:      	mov	x24, x4
    86a4:      	str	w0, [sp, #0x200]
    86a8:      	str	w1, [sp, #0x208]
    86ac:      	str	x2, [sp, #0x210]
    86b0:      	str	x22, [sp, #0x218]
    86b4:      	mov	x22, x3
    86b8:      	b	0x7e54 <_stogir.schedule.order-with-uses+0x314>
    86bc:      	str	x19, [sp, #0x1e8]
    86c0:      	str	x22, [sp, #0x1f8]
    86c4:      	str	x24, [sp, #0x1e0]
    86c8:      	str	x27, [sp, #0x1f0]
    86cc:      	b	0x8104 <_stogir.schedule.order-with-uses+0x5c4>
    86d0:      	str	x19, [sp, #0x1e8]
    86d4:      	str	x22, [sp, #0x1f8]
    86d8:      	str	x24, [sp, #0x1e0]
    86dc:      	str	x27, [sp, #0x1f0]
    86e0:      	b	0x8104 <_stogir.schedule.order-with-uses+0x5c4>
    86e4:      	str	x19, [sp, #0x1e8]
    86e8:      	str	x22, [sp, #0x1f8]
    86ec:      	str	x27, [sp, #0x1f0]
    86f0:      	b	0x7fb0 <_stogir.schedule.order-with-uses+0x470>
    86f4:      	str	x19, [sp, #0x1e8]
    86f8:      	str	x22, [sp, #0x1f8]
    86fc:      	str	x27, [sp, #0x1f0]
    8700:      	b	0x7fb0 <_stogir.schedule.order-with-uses+0x470>
    8704:      	str	x20, [sp, #0x238]
    8708:      	str	x21, [sp, #0x240]
    870c:      	str	w19, [sp, #0x230]
    8710:      	b	0x834c <_stogir.schedule.order-with-uses+0x80c>
    8714:      	str	x20, [sp, #0x238]
    8718:      	str	x21, [sp, #0x240]
    871c:      	str	x6, [sp, #0x1f8]
    8720:      	str	x0, [sp, #0x228]
    8724:      	str	w19, [sp, #0x230]
    8728:      	mov	x19, x1
    872c:      	b	0x8278 <_stogir.schedule.order-with-uses+0x738>
    8730:      	str	x20, [sp, #0x238]
    8734:      	str	x21, [sp, #0x240]
    8738:      	str	x6, [sp, #0x1f8]
    873c:      	str	x0, [sp, #0x228]
    8740:      	str	w19, [sp, #0x230]
    8744:      	mov	x19, x1
    8748:      	b	0x8278 <_stogir.schedule.order-with-uses+0x738>
    874c:      	str	x20, [sp, #0x238]
    8750:      	b	0x84e4 <_stogir.schedule.order-with-uses+0x9a4>
    8754:      	str	x20, [sp, #0x238]
    8758:      	b	0x84e4 <_stogir.schedule.order-with-uses+0x9a4>
    875c:      	str	x20, [sp, #0x238]
    8760:      	str	x21, [sp, #0x240]
    8764:      	str	x6, [sp, #0x1f8]
    8768:      	str	x0, [sp, #0x228]
    876c:      	str	w19, [sp, #0x230]
    8770:      	mov	x19, x1
    8774:      	b	0x8278 <_stogir.schedule.order-with-uses+0x738>
    8778:      	str	x20, [sp, #0x238]
    877c:      	str	x21, [sp, #0x240]
    8780:      	str	x6, [sp, #0x1f8]
    8784:      	str	x0, [sp, #0x228]
    8788:      	str	w19, [sp, #0x230]
    878c:      	mov	x19, x1
    8790:      	b	0x8278 <_stogir.schedule.order-with-uses+0x738>
    8794:      	str	x20, [sp, #0x238]
    8798:      	str	x21, [sp, #0x240]
    879c:      	str	x6, [sp, #0x1f8]
    87a0:      	str	x0, [sp, #0x228]
    87a4:      	str	w19, [sp, #0x230]
    87a8:      	mov	x19, x1
    87ac:      	b	0x8278 <_stogir.schedule.order-with-uses+0x738>
    87b0:      	str	x20, [sp, #0x238]
    87b4:      	str	x21, [sp, #0x240]
    87b8:      	str	x6, [sp, #0x1f8]
    87bc:      	str	x0, [sp, #0x228]
    87c0:      	mov	w20, w4
    87c4:      	mov	x21, x2
    87c8:      	str	w19, [sp, #0x230]
    87cc:      	mov	x19, x1
    87d0:      	b	0x80e4 <_stogir.schedule.order-with-uses+0x5a4>
    87d4:      	ldr	x19, [sp, #0x1f0]
    87d8:      	b	0x85a8 <_stogir.schedule.order-with-uses+0xa68>
    87dc:      	udf	#0x0

00000000000087e0 <_stogir.schedule.pack>:
    87e0:      	sub	sp, sp, #0xd0
    87e4:      	str	x29, [sp]
    87e8:      	str	x30, [sp, #0x8]
    87ec:      	mov	x29, sp
    87f0:      	str	x19, [sp, #0x90]
    87f4:      	str	x20, [sp, #0x98]
    87f8:      	str	x21, [sp, #0xa0]
    87fc:      	str	x22, [sp, #0xa8]
    8800:      	str	x23, [sp, #0xb0]
    8804:      	str	x24, [sp, #0xb8]
    8808:      	str	x25, [sp, #0xc0]
    880c:      	str	x26, [sp, #0xc8]
    8810:      	ldr	x4, [x3]
    8814:      	ldr	x3, [x3, #0x8]
    8818:      	add	x16, sp, #0x10
    881c:      	movz	x17, #0x0, lsl #48
    8820:      	str	x17, [x16]
    8824:      	add	x16, sp, #0x10
    8828:      	movz	x17, #0x0, lsl #48
    882c:      	str	x17, [x16, #0x8]
    8830:      	add	x16, sp, #0x10
    8834:      	movz	x17, #0x0, lsl #48
    8838:      	str	x17, [x16, #0x10]
    883c:      	add	x16, sp, #0x10
    8840:      	str	x4, [x16, #0x18]
    8844:      	add	x16, sp, #0x10
    8848:      	str	x3, [x16, #0x20]
    884c:      	add	x16, sp, #0x10
    8850:      	movz	x17, #0x0, lsl #48
    8854:      	str	x17, [x16, #0x28]
    8858:      	add	x16, sp, #0x10
    885c:      	movz	x17, #0x0, lsl #48
    8860:      	str	x17, [x16, #0x30]
    8864:      	add	x16, sp, #0x10
    8868:      	movz	x17, #0x0, lsl #48
    886c:      	str	x17, [x16, #0x38]
    8870:      	add	x16, sp, #0x10
    8874:      	str	x4, [x16, #0x40]
    8878:      	add	x16, sp, #0x10
    887c:      	str	x3, [x16, #0x48]
    8880:      	add	x16, sp, #0x60
    8884:      	movz	x17, #0x0, lsl #48
    8888:      	str	x17, [x16]
    888c:      	add	x16, sp, #0x60
    8890:      	movz	x17, #0x0, lsl #48
    8894:      	str	x17, [x16, #0x8]
    8898:      	add	x16, sp, #0x60
    889c:      	movz	x17, #0x0, lsl #48
    88a0:      	str	x17, [x16, #0x10]
    88a4:      	add	x16, sp, #0x60
    88a8:      	str	x4, [x16, #0x18]
    88ac:      	add	x16, sp, #0x60
    88b0:      	str	x3, [x16, #0x20]
    88b4:      	ldr	x3, [x1, #0x8]
    88b8:      	orr	x19, x3, xzr
    88bc:      	cmp	x19, #0x0
    88c0:      	b.le	0x8d7c <_stogir.schedule.pack+0x59c>
    88c4:      	cmp	x19, #0x0
    88c8:      	b.ge	0x88d4 <_stogir.schedule.pack+0xf4>
    88cc:      	movz	x3, #0x0, lsl #48
    88d0:      	b	0x88d8 <_stogir.schedule.pack+0xf8>
    88d4:      	mov	x3, x19
    88d8:      	mov	x20, x8
    88dc:      	mov	x21, x0
    88e0:      	add	x0, sp, #0x10
    88e4:      	mov	x22, x1
    88e8:      	mov	x1, x3
    88ec:      	mov	x23, x2
    88f0:      	bl	0x88f0 <_stogir.schedule.pack+0x110>
		00000000000088f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range
    88f4:      	add	x16, sp, #0x10
    88f8:      	orr	x24, x16, xzr
    88fc:      	lsl	x0, x19, #4
    8900:      	add	x16, sp, #0x10
    8904:      	ldr	x1, [x16]
    8908:      	mov	x2, x0
    890c:      	mov	x0, x1
    8910:      	movz	x1, #0x0, lsl #48
    8914:      	bl	0x8914 <_stogir.schedule.pack+0x134>
		0000000000008914:  ARM64_RELOC_BRANCH26	_memset
    8918:      	add	x16, sp, #0x10
    891c:      	str	x19, [x16, #0x8]
    8920:      	ldr	x0, [x22, #0x8]
    8924:      	orr	x19, x0, xzr
    8928:      	add	x16, sp, #0x60
    892c:      	ldr	x0, [x16, #0x8]
    8930:      	orr	x25, x0, xzr
    8934:      	add	x16, sp, #0x60
    8938:      	ldr	x0, [x16, #0x10]
    893c:      	add	x26, x25, x19
    8940:      	cmp	x26, x0
    8944:      	b.le	0x8978 <_stogir.schedule.pack+0x198>
    8948:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    894c:      	cmp	x0, x17
    8950:      	b.gt	0x895c <_stogir.schedule.pack+0x17c>
    8954:      	lsl	x0, x0, #1
    8958:      	b	0x8960 <_stogir.schedule.pack+0x180>
    895c:      	mov	x0, x26
    8960:      	cmp	x0, x26
    8964:      	b.gt	0x896c <_stogir.schedule.pack+0x18c>
    8968:      	mov	x0, x26
    896c:      	mov	x1, x0
    8970:      	add	x0, sp, #0x60
    8974:      	bl	0x8974 <_stogir.schedule.pack+0x194>
		0000000000008974:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    8978:      	lsl	x0, x19, #3
    897c:      	add	x16, sp, #0x60
    8980:      	ldr	x1, [x16]
    8984:      	add	x1, x1, x25, lsl #3
    8988:      	mov	x2, x0
    898c:      	mov	x0, x1
    8990:      	movz	x1, #0x0, lsl #48
    8994:      	bl	0x8994 <_stogir.schedule.pack+0x1b4>
		0000000000008994:  ARM64_RELOC_BRANCH26	_memset
    8998:      	add	x16, sp, #0x60
    899c:      	str	x26, [x16, #0x8]
    89a0:      	ldr	x0, [x21]
    89a4:      	ldr	x1, [x21, #0x8]
    89a8:      	movz	x2, #0x0, lsl #48
    89ac:      	b	0x8a24 <_stogir.schedule.pack+0x244>
    89b0:      	movz	w3, #0x0, lsl #16
    89b4:      	movz	w4, #0x0, lsl #16
    89b8:      	ubfx	x3, x3, #0, #32
    89bc:      	lsr	x16, x3, #0
    89c0:      	cmp	x16, #0x1
    89c4:      	b.eq	0x89e0 <_stogir.schedule.pack+0x200>
    89c8:      	b.lo	0x89d0 <_stogir.schedule.pack+0x1f0>
    89cc:      	b	0x89e4 <_stogir.schedule.pack+0x204>
    89d0:      	cmp	x16, #0x0
    89d4:      	b.eq	0x89dc <_stogir.schedule.pack+0x1fc>
    89d8:      	b	0x89e4 <_stogir.schedule.pack+0x204>
    89dc:      	b	0x8a4c <_stogir.schedule.pack+0x26c>
    89e0:      	b	0x89e8 <_stogir.schedule.pack+0x208>
    89e4:      	b	0x8d74 <_stogir.schedule.pack+0x594>
    89e8:      	sxtw	x4, w4
    89ec:      	ldr	x3, [x22]
    89f0:      	add	x3, x3, x4, lsl #2
    89f4:      	ldr	w3, [x3]
    89f8:      	sxtw	x3, w3
    89fc:      	add	x16, sp, #0x10
    8a00:      	ldr	x4, [x16]
    8a04:      	orr	x5, x4, xzr
    8a08:      	add	x5, x5, x3, lsl #4
    8a0c:      	add	x3, x4, x3, lsl #4
    8a10:      	ldr	x4, [x5]
    8a14:      	ldr	x5, [x5, #0x8]
    8a18:      	add	x5, x5, #0x1
    8a1c:      	str	x4, [x3]
    8a20:      	str	x5, [x3, #0x8]
    8a24:      	cmp	x2, x1
    8a28:      	b.ge	0x89b0 <_stogir.schedule.pack+0x1d0>
    8a2c:      	add	x3, x2, #0x1
    8a30:      	add	x2, x0, x2, lsl #2
    8a34:      	ldr	w2, [x2]
    8a38:      	movn	w17, #0x0, lsl #16
    8a3c:      	and	w4, w2, w17
    8a40:      	mov	x2, x3
    8a44:      	mov	w3, #0x1                ; =1
    8a48:      	b	0x89b8 <_stogir.schedule.pack+0x1d8>
    8a4c:      	ldr	x0, [x23]
    8a50:      	ldr	x1, [x23, #0x8]
    8a54:      	movz	x2, #0x0, lsl #48
    8a58:      	movz	x3, #0x0, lsl #48
    8a5c:      	b	0x8ad4 <_stogir.schedule.pack+0x2f4>
    8a60:      	movz	w4, #0x0, lsl #16
    8a64:      	movz	w5, #0x0, lsl #16
    8a68:      	ubfx	x4, x4, #0, #32
    8a6c:      	lsr	x16, x4, #0
    8a70:      	cmp	x16, #0x1
    8a74:      	b.eq	0x8a90 <_stogir.schedule.pack+0x2b0>
    8a78:      	b.lo	0x8a80 <_stogir.schedule.pack+0x2a0>
    8a7c:      	b	0x8a94 <_stogir.schedule.pack+0x2b4>
    8a80:      	cmp	x16, #0x0
    8a84:      	b.eq	0x8a8c <_stogir.schedule.pack+0x2ac>
    8a88:      	b	0x8a94 <_stogir.schedule.pack+0x2b4>
    8a8c:      	b	0x8afc <_stogir.schedule.pack+0x31c>
    8a90:      	b	0x8a98 <_stogir.schedule.pack+0x2b8>
    8a94:      	b	0x8d6c <_stogir.schedule.pack+0x58c>
    8a98:      	sxtw	x5, w5
    8a9c:      	add	x16, sp, #0x10
    8aa0:      	ldr	x4, [x16]
    8aa4:      	orr	x6, x4, xzr
    8aa8:      	add	x6, x6, x5, lsl #4
    8aac:      	add	x4, x4, x5, lsl #4
    8ab0:      	ldr	x6, [x6, #0x8]
    8ab4:      	add	x7, x6, x2
    8ab8:      	str	x2, [x4]
    8abc:      	str	x6, [x4, #0x8]
    8ac0:      	add	x16, sp, #0x60
    8ac4:      	ldr	x4, [x16]
    8ac8:      	add	x4, x4, x5, lsl #3
    8acc:      	str	x2, [x4]
    8ad0:      	mov	x2, x7
    8ad4:      	cmp	x3, x1
    8ad8:      	b.ge	0x8a60 <_stogir.schedule.pack+0x280>
    8adc:      	add	x4, x3, #0x1
    8ae0:      	add	x3, x0, x3, lsl #2
    8ae4:      	ldr	w3, [x3]
    8ae8:      	movn	w17, #0x0, lsl #16
    8aec:      	and	w5, w3, w17
    8af0:      	mov	x3, x4
    8af4:      	mov	w4, #0x1                ; =1
    8af8:      	b	0x8a68 <_stogir.schedule.pack+0x288>
    8afc:      	add	x19, x24, #0x28
    8b00:      	ldr	x0, [x21, #0x8]
    8b04:      	orr	x23, x0, xzr
    8b08:      	ldr	x0, [x19, #0x8]
    8b0c:      	orr	x24, x0, xzr
    8b10:      	ldr	x0, [x19, #0x10]
    8b14:      	add	x25, x24, x23
    8b18:      	cmp	x25, x0
    8b1c:      	b.le	0x8b50 <_stogir.schedule.pack+0x370>
    8b20:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    8b24:      	cmp	x0, x17
    8b28:      	b.gt	0x8b34 <_stogir.schedule.pack+0x354>
    8b2c:      	lsl	x0, x0, #1
    8b30:      	b	0x8b38 <_stogir.schedule.pack+0x358>
    8b34:      	mov	x0, x25
    8b38:      	cmp	x0, x25
    8b3c:      	b.gt	0x8b44 <_stogir.schedule.pack+0x364>
    8b40:      	mov	x0, x25
    8b44:      	mov	x1, x0
    8b48:      	mov	x0, x19
    8b4c:      	bl	0x8b4c <_stogir.schedule.pack+0x36c>
		0000000000008b4c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8b50:      	lsl	x0, x23, #2
    8b54:      	add	x16, sp, #0x10
    8b58:      	ldr	x1, [x16, #0x28]
    8b5c:      	add	x1, x1, x24, lsl #2
    8b60:      	mov	x2, x0
    8b64:      	mov	x0, x1
    8b68:      	movz	x1, #0x0, lsl #48
    8b6c:      	bl	0x8b6c <_stogir.schedule.pack+0x38c>
		0000000000008b6c:  ARM64_RELOC_BRANCH26	_memset
    8b70:      	str	x25, [x19, #0x8]
    8b74:      	ldr	x0, [x21]
    8b78:      	ldr	x1, [x21, #0x8]
    8b7c:      	movz	x2, #0x0, lsl #48
    8b80:      	b	0x8c08 <_stogir.schedule.pack+0x428>
    8b84:      	nop
    8b88:      	movz	w3, #0x0, lsl #16
    8b8c:      	movz	w4, #0x0, lsl #16
    8b90:      	ubfx	x3, x3, #0, #32
    8b94:      	lsr	x16, x3, #0
    8b98:      	cmp	x16, #0x1
    8b9c:      	b.eq	0x8bb8 <_stogir.schedule.pack+0x3d8>
    8ba0:      	b.lo	0x8ba8 <_stogir.schedule.pack+0x3c8>
    8ba4:      	b	0x8bbc <_stogir.schedule.pack+0x3dc>
    8ba8:      	cmp	x16, #0x0
    8bac:      	b.eq	0x8bb4 <_stogir.schedule.pack+0x3d4>
    8bb0:      	b	0x8bbc <_stogir.schedule.pack+0x3dc>
    8bb4:      	b	0x8c30 <_stogir.schedule.pack+0x450>
    8bb8:      	b	0x8bc0 <_stogir.schedule.pack+0x3e0>
    8bbc:      	b	0x8d64 <_stogir.schedule.pack+0x584>
    8bc0:      	sxtw	x3, w4
    8bc4:      	ldr	x5, [x22]
    8bc8:      	add	x3, x5, x3, lsl #2
    8bcc:      	ldr	w3, [x3]
    8bd0:      	sxtw	x3, w3
    8bd4:      	add	x16, sp, #0x60
    8bd8:      	ldr	x5, [x16]
    8bdc:      	add	x5, x5, x3, lsl #3
    8be0:      	ldr	x5, [x5]
    8be4:      	add	x16, sp, #0x10
    8be8:      	ldr	x6, [x16, #0x28]
    8bec:      	add	x7, x5, #0x1
    8bf0:      	add	x5, x6, x5, lsl #2
    8bf4:      	str	w4, [x5]
    8bf8:      	add	x16, sp, #0x60
    8bfc:      	ldr	x4, [x16]
    8c00:      	add	x3, x4, x3, lsl #3
    8c04:      	str	x7, [x3]
    8c08:      	cmp	x2, x1
    8c0c:      	b.ge	0x8b88 <_stogir.schedule.pack+0x3a8>
    8c10:      	add	x3, x2, #0x1
    8c14:      	add	x2, x0, x2, lsl #2
    8c18:      	ldr	w2, [x2]
    8c1c:      	movn	w17, #0x0, lsl #16
    8c20:      	and	w4, w2, w17
    8c24:      	mov	x2, x3
    8c28:      	mov	w3, #0x1                ; =1
    8c2c:      	b	0x8b90 <_stogir.schedule.pack+0x3b0>
    8c30:      	b	0x8c44 <_stogir.schedule.pack+0x464>
    8c34:      	nop
    8c38:      	sub	x0, x0, #0x1
    8c3c:      	add	x16, sp, #0x60
    8c40:      	str	x0, [x16, #0x8]
    8c44:      	add	x16, sp, #0x60
    8c48:      	ldr	x0, [x16, #0x8]
    8c4c:      	cmp	x0, #0x0
    8c50:      	b.ne	0x8c38 <_stogir.schedule.pack+0x458>
    8c54:      	add	x16, sp, #0x60
    8c58:      	orr	x0, x16, xzr
    8c5c:      	add	x16, sp, #0x60
    8c60:      	ldr	x1, [x16, #0x10]
    8c64:      	cmp	x1, #0x0
    8c68:      	b.le	0x8c98 <_stogir.schedule.pack+0x4b8>
    8c6c:      	add	x0, x0, #0x18
    8c70:      	add	x16, sp, #0x60
    8c74:      	ldr	x2, [x16]
    8c78:      	fmov	d31, x1
    8c7c:      	mov	x1, x2
    8c80:      	fmov	x2, d31
    8c84:      	adrp	x3, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		0000000000008c84:  ARM64_RELOC_PAGE21	l_stogir.447
    8c88:      	ldr	x3, [x3]
		0000000000008c88:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    8c8c:      	mov	x4, #0x8                ; =8
    8c90:      	mov	x5, #0x8                ; =8
    8c94:      	bl	0x8c94 <_stogir.schedule.pack+0x4b4>
		0000000000008c94:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    8c98:      	add	x16, sp, #0x60
    8c9c:      	movz	x17, #0x0, lsl #48
    8ca0:      	str	x17, [x16]
    8ca4:      	add	x16, sp, #0x60
    8ca8:      	movz	x17, #0x0, lsl #48
    8cac:      	str	x17, [x16, #0x8]
    8cb0:      	add	x16, sp, #0x60
    8cb4:      	movz	x17, #0x0, lsl #48
    8cb8:      	str	x17, [x16, #0x10]
    8cbc:      	add	x16, sp, #0x10
    8cc0:      	ldr	x0, [x16]
    8cc4:      	add	x16, sp, #0x10
    8cc8:      	ldr	x1, [x16, #0x8]
    8ccc:      	add	x16, sp, #0x10
    8cd0:      	ldr	x2, [x16, #0x10]
    8cd4:      	add	x16, sp, #0x10
    8cd8:      	ldr	x3, [x16, #0x18]
    8cdc:      	add	x16, sp, #0x10
    8ce0:      	ldr	x4, [x16, #0x20]
    8ce4:      	add	x16, sp, #0x10
    8ce8:      	ldr	x5, [x16, #0x28]
    8cec:      	add	x16, sp, #0x10
    8cf0:      	ldr	x6, [x16, #0x30]
    8cf4:      	add	x16, sp, #0x10
    8cf8:      	ldr	x7, [x16, #0x38]
    8cfc:      	add	x16, sp, #0x10
    8d00:      	ldr	x8, [x16, #0x40]
    8d04:      	add	x16, sp, #0x10
    8d08:      	ldr	x9, [x16, #0x48]
    8d0c:      	str	x0, [x20]
    8d10:      	str	x1, [x20, #0x8]
    8d14:      	str	x2, [x20, #0x10]
    8d18:      	str	x3, [x20, #0x18]
    8d1c:      	str	x4, [x20, #0x20]
    8d20:      	str	x5, [x20, #0x28]
    8d24:      	str	x6, [x20, #0x30]
    8d28:      	str	x7, [x20, #0x38]
    8d2c:      	str	x8, [x20, #0x40]
    8d30:      	str	x9, [x20, #0x48]
    8d34:      	ldr	x19, [sp, #0x90]
    8d38:      	ldr	x20, [sp, #0x98]
    8d3c:      	ldr	x21, [sp, #0xa0]
    8d40:      	ldr	x22, [sp, #0xa8]
    8d44:      	ldr	x23, [sp, #0xb0]
    8d48:      	ldr	x24, [sp, #0xb8]
    8d4c:      	ldr	x25, [sp, #0xc0]
    8d50:      	ldr	x26, [sp, #0xc8]
    8d54:      	ldr	x29, [sp]
    8d58:      	ldr	x30, [sp, #0x8]
    8d5c:      	add	sp, sp, #0xd0
    8d60:      	ret
    8d64:      	brk	#0
    8d68:      	b	0x8d64 <_stogir.schedule.pack+0x584>
    8d6c:      	brk	#0
    8d70:      	b	0x8d6c <_stogir.schedule.pack+0x58c>
    8d74:      	brk	#0
    8d78:      	b	0x8d74 <_stogir.schedule.pack+0x594>
    8d7c:      	mov	x20, x8
    8d80:      	mov	x21, x0
    8d84:      	mov	x22, x1
    8d88:      	mov	x23, x2
    8d8c:      	b	0x88f4 <_stogir.schedule.pack+0x114>

0000000000008d90 <_stogir.checked-schedule.cluster!>:
    8d90:      	sub	sp, sp, #0x230
    8d94:      	str	x29, [sp]
    8d98:      	str	x30, [sp, #0x8]
    8d9c:      	mov	x29, sp
    8da0:      	str	x19, [sp, #0x1d8]
    8da4:      	str	x20, [sp, #0x1e0]
    8da8:      	str	x21, [sp, #0x1e8]
    8dac:      	str	x22, [sp, #0x1f0]
    8db0:      	str	x23, [sp, #0x1f8]
    8db4:      	str	x24, [sp, #0x200]
    8db8:      	str	x25, [sp, #0x208]
    8dbc:      	str	x26, [sp, #0x210]
    8dc0:      	str	x27, [sp, #0x218]
    8dc4:      	str	x28, [sp, #0x220]
    8dc8:      	add	x16, sp, #0x10
    8dcc:      	orr	x4, x16, xzr
    8dd0:      	add	x19, x2, #0x28
    8dd4:      	add	x20, x4, #0x8
    8dd8:      	ldr	x4, [x2, #0x28]
    8ddc:      	ldr	x5, [x19, #0x8]
    8de0:      	orr	x21, x4, xzr
    8de4:      	orr	x22, x5, xzr
    8de8:      	movz	x23, #0x0, lsl #48
    8dec:      	adrp	x24, 0x8000 <_stogir.schedule.order-with-uses+0x4c0>
		0000000000008dec:  ARM64_RELOC_PAGE21	l_stogir.448
    8df0:      	ldr	x24, [x24]
		0000000000008df0:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    8df4:      	movz	x25, #0x0, lsl #48
    8df8:      	movz	x26, #0x0, lsl #48
    8dfc:      	b	0x8e3c <_stogir.checked-schedule.cluster!+0xac>
    8e00:      	add	x16, sp, #0x10
    8e04:      	ldr	w0, [x16, #0x8]
    8e08:      	sxtw	x0, w0
    8e0c:      	cmp	x0, #0x0
    8e10:      	b.eq	0x8e1c <_stogir.checked-schedule.cluster!+0x8c>
    8e14:      	add	x0, x23, #0x1
    8e18:      	sxtw	x23, w0
    8e1c:      	mov	x8, x27
    8e20:      	mov	x0, x28
    8e24:      	mov	x1, x21
    8e28:      	mov	x2, x22
    8e2c:      	mov	x3, x26
    8e30:      	ldr	x22, [sp, #0x198]
    8e34:      	ldr	x21, [sp, #0x190]
    8e38:      	ldr	x26, [sp, #0x1a0]
    8e3c:      	cmp	x26, x22
    8e40:      	b.ge	0x8e64 <_stogir.checked-schedule.cluster!+0xd4>
    8e44:      	add	x4, x26, #0x1
    8e48:      	add	x5, x21, x26, lsl #2
    8e4c:      	ldr	w5, [x5]
    8e50:      	movn	w17, #0x0, lsl #16
    8e54:      	and	w5, w5, w17
    8e58:      	mov	x26, x4
    8e5c:      	mov	w4, #0x1                ; =1
    8e60:      	b	0x8e6c <_stogir.checked-schedule.cluster!+0xdc>
    8e64:      	movz	w4, #0x0, lsl #16
    8e68:      	movz	w5, #0x0, lsl #16
    8e6c:      	ubfx	x4, x4, #0, #32
    8e70:      	lsr	x16, x4, #0
    8e74:      	cmp	x16, #0x1
    8e78:      	b.eq	0x8ea8 <_stogir.checked-schedule.cluster!+0x118>
    8e7c:      	b.lo	0x8e84 <_stogir.checked-schedule.cluster!+0xf4>
    8e80:      	b	0x8eac <_stogir.checked-schedule.cluster!+0x11c>
    8e84:      	cmp	x16, #0x0
    8e88:      	b.eq	0x8e90 <_stogir.checked-schedule.cluster!+0x100>
    8e8c:      	b	0x8eac <_stogir.checked-schedule.cluster!+0x11c>
    8e90:      	mov	x27, x8
    8e94:      	mov	x28, x0
    8e98:      	mov	x21, x1
    8e9c:      	mov	x22, x2
    8ea0:      	mov	x26, x3
    8ea4:      	b	0x8f3c <_stogir.checked-schedule.cluster!+0x1ac>
    8ea8:      	b	0x8eb0 <_stogir.checked-schedule.cluster!+0x120>
    8eac:      	b	0x96f8 <_stogir.checked-schedule.cluster!+0x968>
    8eb0:      	sxtw	x4, w5
    8eb4:      	ldr	x6, [x0]
    8eb8:      	add	x4, x6, x4, lsl #4
    8ebc:      	ldr	x4, [x4]
    8ec0:      	uxtb	w4, w4
    8ec4:      	cmp	x4, #0x2c
    8ec8:      	b.ne	0x9720 <_stogir.checked-schedule.cluster!+0x990>
    8ecc:      	mov	x27, x8
    8ed0:      	add	x8, sp, #0x10
    8ed4:      	mov	x28, x0
    8ed8:      	str	x21, [sp, #0x190]
    8edc:      	mov	x21, x1
    8ee0:      	mov	w1, w5
    8ee4:      	str	x22, [sp, #0x198]
    8ee8:      	mov	x22, x2
    8eec:      	str	x26, [sp, #0x1a0]
    8ef0:      	mov	x26, x3
    8ef4:      	bl	0x8ef4 <_stogir.checked-schedule.cluster!+0x164>
		0000000000008ef4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    8ef8:      	add	x16, sp, #0x10
    8efc:      	ldr	w0, [x16]
    8f00:      	lsr	x16, x0, #0
    8f04:      	cmp	x16, #0x1
    8f08:      	b.eq	0x8f24 <_stogir.checked-schedule.cluster!+0x194>
    8f0c:      	b.lo	0x8f14 <_stogir.checked-schedule.cluster!+0x184>
    8f10:      	b	0x8f28 <_stogir.checked-schedule.cluster!+0x198>
    8f14:      	cmp	x16, #0x0
    8f18:      	b.eq	0x8f20 <_stogir.checked-schedule.cluster!+0x190>
    8f1c:      	b	0x8f28 <_stogir.checked-schedule.cluster!+0x198>
    8f20:      	b	0x8e00 <_stogir.checked-schedule.cluster!+0x70>
    8f24:      	b	0x8f2c <_stogir.checked-schedule.cluster!+0x19c>
    8f28:      	b	0x9710 <_stogir.checked-schedule.cluster!+0x980>
    8f2c:      	add	x16, sp, #0x10
    8f30:      	ldr	x24, [x16, #0x8]
    8f34:      	ldr	x25, [x20, #0x8]
    8f38:      	b	0x8e1c <_stogir.checked-schedule.cluster!+0x8c>
    8f3c:      	cmp	x25, #0x0
    8f40:      	b.ne	0x8f78 <_stogir.checked-schedule.cluster!+0x1e8>
    8f44:      	cmp	x23, #0x0
    8f48:      	b.ne	0x9558 <_stogir.checked-schedule.cluster!+0x7c8>
    8f4c:      	add	x8, sp, #0x30
    8f50:      	mov	x0, x28
    8f54:      	mov	x1, x22
    8f58:      	bl	0x8f58 <_stogir.checked-schedule.cluster!+0x1c8>
		0000000000008f58:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate
    8f5c:      	add	x16, sp, #0x30
    8f60:      	ldr	x0, [x16]
    8f64:      	add	x16, sp, #0x30
    8f68:      	ldr	x24, [x16, #0x8]
    8f6c:      	add	x16, sp, #0x30
    8f70:      	ldr	x25, [x16, #0x10]
    8f74:      	b	0x934c <_stogir.checked-schedule.cluster!+0x5bc>
    8f78:      	mov	x0, #0x1                ; =1
    8f7c:      	b	0x934c <_stogir.checked-schedule.cluster!+0x5bc>
    8f80:      	add	x16, sp, #0xb0
    8f84:      	ldr	x2, [x16]
    8f88:      	add	x1, x2, x1, lsl #2
    8f8c:      	str	w26, [x1]
    8f90:      	add	x16, sp, #0x80
    8f94:      	ldr	x1, [x16]
    8f98:      	add	x0, x1, x0, lsl #2
    8f9c:      	str	w26, [x0]
    8fa0:      	add	x16, sp, #0xe0
    8fa4:      	ldr	x0, [x16]
    8fa8:      	add	x0, x0, x28
    8fac:      	mov	w17, #0x1               ; =1
    8fb0:      	strb	w17, [x0]
    8fb4:      	ldr	x28, [sp, #0x1c0]
    8fb8:      	ldr	x0, [sp, #0x1a8]
    8fbc:      	ldr	x26, [sp, #0x1b8]
    8fc0:      	ldr	x1, [sp, #0x1b0]
    8fc4:      	cmp	x1, x0
    8fc8:      	b.ge	0x8fec <_stogir.checked-schedule.cluster!+0x25c>
    8fcc:      	add	x2, x1, #0x1
    8fd0:      	add	x1, x26, x1, lsl #2
    8fd4:      	ldr	w1, [x1]
    8fd8:      	movn	w17, #0x0, lsl #16
    8fdc:      	and	w3, w1, w17
    8fe0:      	mov	x1, x2
    8fe4:      	mov	w2, #0x1                ; =1
    8fe8:      	b	0x8ff4 <_stogir.checked-schedule.cluster!+0x264>
    8fec:      	movz	w2, #0x0, lsl #16
    8ff0:      	movz	w3, #0x0, lsl #16
    8ff4:      	ubfx	x2, x2, #0, #32
    8ff8:      	lsr	x16, x2, #0
    8ffc:      	cmp	x16, #0x1
    9000:      	b.eq	0x9020 <_stogir.checked-schedule.cluster!+0x290>
    9004:      	b.lo	0x900c <_stogir.checked-schedule.cluster!+0x27c>
    9008:      	b	0x9024 <_stogir.checked-schedule.cluster!+0x294>
    900c:      	cmp	x16, #0x0
    9010:      	b.eq	0x9018 <_stogir.checked-schedule.cluster!+0x288>
    9014:      	b	0x9024 <_stogir.checked-schedule.cluster!+0x294>
    9018:      	str	x28, [sp, #0x1c0]
    901c:      	b	0x90c8 <_stogir.checked-schedule.cluster!+0x338>
    9020:      	b	0x9028 <_stogir.checked-schedule.cluster!+0x298>
    9024:      	b	0x9700 <_stogir.checked-schedule.cluster!+0x970>
    9028:      	sxtw	x2, w3
    902c:      	ldr	x4, [x28]
    9030:      	add	x4, x4, x2, lsl #4
    9034:      	ldr	x5, [x4]
    9038:      	uxtb	w6, w5
    903c:      	ldr	x4, [x4, #0x8]
    9040:      	add	x16, sp, #0x140
    9044:      	str	x5, [x16]
    9048:      	add	x16, sp, #0x140
    904c:      	str	x4, [x16, #0x8]
    9050:      	cmp	x6, #0x2c
    9054:      	b.ne	0x9744 <_stogir.checked-schedule.cluster!+0x9b4>
    9058:      	lsr	x4, x5, #32
    905c:      	add	x8, sp, #0x150
    9060:      	str	x0, [sp, #0x1a8]
    9064:      	mov	x0, x28
    9068:      	str	x1, [sp, #0x1b0]
    906c:      	mov	w1, w4
    9070:      	str	x26, [sp, #0x1b8]
    9074:      	mov	w26, w3
    9078:      	str	x28, [sp, #0x1c0]
    907c:      	mov	x28, x2
    9080:      	bl	0x9080 <_stogir.checked-schedule.cluster!+0x2f0>
		0000000000009080:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    9084:      	add	x16, sp, #0x150
    9088:      	ldr	w0, [x16]
    908c:      	lsr	x16, x0, #0
    9090:      	cmp	x16, #0x1
    9094:      	b.eq	0x90b0 <_stogir.checked-schedule.cluster!+0x320>
    9098:      	b.lo	0x90a0 <_stogir.checked-schedule.cluster!+0x310>
    909c:      	b	0x90b4 <_stogir.checked-schedule.cluster!+0x324>
    90a0:      	cmp	x16, #0x0
    90a4:      	b.eq	0x90ac <_stogir.checked-schedule.cluster!+0x31c>
    90a8:      	b	0x90b4 <_stogir.checked-schedule.cluster!+0x324>
    90ac:      	b	0x966c <_stogir.checked-schedule.cluster!+0x8dc>
    90b0:      	b	0x90b8 <_stogir.checked-schedule.cluster!+0x328>
    90b4:      	b	0x9718 <_stogir.checked-schedule.cluster!+0x988>
    90b8:      	add	x16, sp, #0x150
    90bc:      	ldr	x24, [x16, #0x8]
    90c0:      	ldr	x25, [x20, #0x8]
    90c4:      	b	0x8fb4 <_stogir.checked-schedule.cluster!+0x224>
    90c8:      	ldr	x0, [x22, #0x28]
    90cc:      	ldr	x1, [x19, #0x8]
    90d0:      	orr	x20, x0, xzr
    90d4:      	orr	x21, x1, xzr
    90d8:      	movz	x26, #0x0, lsl #48
    90dc:      	b	0x9234 <_stogir.checked-schedule.cluster!+0x4a4>
    90e0:      	add	x0, sp, #0x110
    90e4:      	bl	0x90e4 <_stogir.checked-schedule.cluster!+0x354>
		00000000000090e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    90e8:      	mov	x0, #0x1                ; =1
    90ec:      	b	0x934c <_stogir.checked-schedule.cluster!+0x5bc>
    90f0:      	adrp	x24, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		00000000000090f0:  ARM64_RELOC_PAGE21	l_stogir.449
    90f4:      	ldr	x24, [x24]
		00000000000090f4:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    90f8:      	mov	x25, #0x32              ; =50
    90fc:      	b	0x9270 <_stogir.checked-schedule.cluster!+0x4e0>
    9100:      	lsl	x2, x2, #1
    9104:      	str	x20, [sp, #0x1c8]
    9108:      	mov	x20, x0
    910c:      	add	x0, sp, #0x110
    9110:      	str	x21, [sp, #0x1d0]
    9114:      	mov	x21, x1
    9118:      	mov	x1, x2
    911c:      	bl	0x911c <_stogir.checked-schedule.cluster!+0x38c>
		000000000000911c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9120:      	add	x0, x21, #0x1
    9124:      	add	x16, sp, #0x110
    9128:      	ldr	x1, [x16]
    912c:      	add	x1, x1, x21, lsl #2
    9130:      	str	w28, [x1]
    9134:      	add	x16, sp, #0x110
    9138:      	str	x0, [x16, #0x8]
    913c:      	add	x16, sp, #0x50
    9140:      	ldr	x0, [x16]
    9144:      	add	x0, x0, x20, lsl #2
    9148:      	ldr	w0, [x0]
    914c:      	orr	w20, w0, wzr
    9150:      	b	0x9198 <_stogir.checked-schedule.cluster!+0x408>
    9154:      	nop
    9158:      	lsl	x0, x0, #1
    915c:      	mov	x1, x0
    9160:      	add	x0, sp, #0x110
    9164:      	bl	0x9164 <_stogir.checked-schedule.cluster!+0x3d4>
		0000000000009164:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9168:      	add	x0, x28, #0x1
    916c:      	add	x16, sp, #0x110
    9170:      	ldr	x1, [x16]
    9174:      	add	x1, x1, x28, lsl #2
    9178:      	str	w20, [x1]
    917c:      	add	x16, sp, #0x110
    9180:      	str	x0, [x16, #0x8]
    9184:      	add	x16, sp, #0xb0
    9188:      	ldr	x0, [x16]
    918c:      	add	x0, x0, x21, lsl #2
    9190:      	ldr	w0, [x0]
    9194:      	orr	w20, w0, wzr
    9198:      	sxtw	x21, w20
    919c:      	cmp	x21, #0x0
    91a0:      	b.eq	0x922c <_stogir.checked-schedule.cluster!+0x49c>
    91a4:      	add	x16, sp, #0x110
    91a8:      	ldr	x0, [x16, #0x8]
    91ac:      	orr	x28, x0, xzr
    91b0:      	add	x16, sp, #0x110
    91b4:      	ldr	x0, [x16, #0x10]
    91b8:      	cmp	x28, x0
    91bc:      	b.lt	0x9168 <_stogir.checked-schedule.cluster!+0x3d8>
    91c0:      	cmp	x0, #0x0
    91c4:      	b.ne	0x9158 <_stogir.checked-schedule.cluster!+0x3c8>
    91c8:      	mov	x0, #0x2                ; =2
    91cc:      	b	0x915c <_stogir.checked-schedule.cluster!+0x3cc>
    91d0:      	movz	w0, #0x0, lsl #16
    91d4:      	movz	w28, #0x0, lsl #16
    91d8:      	ubfx	x0, x0, #0, #32
    91dc:      	lsr	x16, x0, #0
    91e0:      	cmp	x16, #0x1
    91e4:      	b.eq	0x9200 <_stogir.checked-schedule.cluster!+0x470>
    91e8:      	b.lo	0x91f0 <_stogir.checked-schedule.cluster!+0x460>
    91ec:      	b	0x9204 <_stogir.checked-schedule.cluster!+0x474>
    91f0:      	cmp	x16, #0x0
    91f4:      	b.eq	0x91fc <_stogir.checked-schedule.cluster!+0x46c>
    91f8:      	b	0x9204 <_stogir.checked-schedule.cluster!+0x474>
    91fc:      	b	0x925c <_stogir.checked-schedule.cluster!+0x4cc>
    9200:      	b	0x9208 <_stogir.checked-schedule.cluster!+0x478>
    9204:      	b	0x96f0 <_stogir.checked-schedule.cluster!+0x960>
    9208:      	sxtw	x0, w28
    920c:      	add	x16, sp, #0xe0
    9210:      	ldr	x1, [x16]
    9214:      	add	x1, x1, x0
    9218:      	ldrb	w1, [x1]
    921c:      	cmp	x1, #0x0
    9220:      	b.eq	0x9390 <_stogir.checked-schedule.cluster!+0x600>
    9224:      	str	x21, [sp, #0x1d0]
    9228:      	str	x20, [sp, #0x1c8]
    922c:      	ldr	x21, [sp, #0x1d0]
    9230:      	ldr	x20, [sp, #0x1c8]
    9234:      	cmp	x26, x21
    9238:      	b.ge	0x91d0 <_stogir.checked-schedule.cluster!+0x440>
    923c:      	add	x0, x26, #0x1
    9240:      	add	x1, x20, x26, lsl #2
    9244:      	ldr	w1, [x1]
    9248:      	movn	w17, #0x0, lsl #16
    924c:      	and	w28, w1, w17
    9250:      	mov	x26, x0
    9254:      	mov	w0, #0x1                ; =1
    9258:      	b	0x91d8 <_stogir.checked-schedule.cluster!+0x448>
    925c:      	add	x16, sp, #0x110
    9260:      	ldr	x0, [x16, #0x8]
    9264:      	ldr	x1, [x19, #0x8]
    9268:      	cmp	x0, x1
    926c:      	b.ne	0x90f0 <_stogir.checked-schedule.cluster!+0x360>
    9270:      	cmp	x25, #0x0
    9274:      	b.ne	0x92d4 <_stogir.checked-schedule.cluster!+0x544>
    9278:      	add	x8, sp, #0x170
    927c:      	ldr	x0, [sp, #0x1c0]
    9280:      	add	x1, sp, #0x110
    9284:      	bl	0x9284 <_stogir.checked-schedule.cluster!+0x4f4>
		0000000000009284:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    9288:      	add	x16, sp, #0x170
    928c:      	ldr	w0, [x16]
    9290:      	lsr	x16, x0, #0
    9294:      	cmp	x16, #0x1
    9298:      	b.eq	0x92b4 <_stogir.checked-schedule.cluster!+0x524>
    929c:      	b.lo	0x92a4 <_stogir.checked-schedule.cluster!+0x514>
    92a0:      	b	0x92b8 <_stogir.checked-schedule.cluster!+0x528>
    92a4:      	cmp	x16, #0x0
    92a8:      	b.eq	0x92b0 <_stogir.checked-schedule.cluster!+0x520>
    92ac:      	b	0x92b8 <_stogir.checked-schedule.cluster!+0x528>
    92b0:      	b	0x92d4 <_stogir.checked-schedule.cluster!+0x544>
    92b4:      	b	0x92bc <_stogir.checked-schedule.cluster!+0x52c>
    92b8:      	b	0x9708 <_stogir.checked-schedule.cluster!+0x978>
    92bc:      	add	x16, sp, #0x170
    92c0:      	orr	x0, x16, xzr
    92c4:      	add	x0, x0, #0x8
    92c8:      	add	x16, sp, #0x170
    92cc:      	ldr	x24, [x16, #0x8]
    92d0:      	ldr	x25, [x0, #0x8]
    92d4:      	add	x0, sp, #0x50
    92d8:      	bl	0x92d8 <_stogir.checked-schedule.cluster!+0x548>
		00000000000092d8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    92dc:      	add	x0, sp, #0x80
    92e0:      	bl	0x92e0 <_stogir.checked-schedule.cluster!+0x550>
		00000000000092e0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    92e4:      	add	x0, sp, #0xb0
    92e8:      	bl	0x92e8 <_stogir.checked-schedule.cluster!+0x558>
		00000000000092e8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    92ec:      	add	x0, sp, #0xe0
    92f0:      	bl	0x92f0 <_stogir.checked-schedule.cluster!+0x560>
		00000000000092f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__bool
    92f4:      	cmp	x25, #0x0
    92f8:      	b.ne	0x90e0 <_stogir.checked-schedule.cluster!+0x350>
    92fc:      	and	x24, x23, #0xffffffff
    9300:      	mov	x0, x19
    9304:      	bl	0x9304 <_stogir.checked-schedule.cluster!+0x574>
		0000000000009304:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9308:      	add	x16, sp, #0x110
    930c:      	ldr	x0, [x16]
    9310:      	add	x16, sp, #0x110
    9314:      	ldr	x1, [x16, #0x8]
    9318:      	add	x16, sp, #0x110
    931c:      	ldr	x2, [x16, #0x10]
    9320:      	add	x16, sp, #0x110
    9324:      	ldr	x3, [x16, #0x18]
    9328:      	add	x16, sp, #0x110
    932c:      	ldr	x4, [x16, #0x20]
    9330:      	str	x0, [x22, #0x28]
    9334:      	str	x1, [x19, #0x8]
    9338:      	str	x2, [x19, #0x10]
    933c:      	str	x3, [x19, #0x18]
    9340:      	str	x4, [x19, #0x20]
    9344:      	movz	x0, #0x0, lsl #48
    9348:      	movz	x25, #0x0, lsl #48
    934c:      	str	x0, [x27]
    9350:      	str	x24, [x27, #0x8]
    9354:      	str	x25, [x27, #0x10]
    9358:      	ldr	x19, [sp, #0x1d8]
    935c:      	ldr	x20, [sp, #0x1e0]
    9360:      	ldr	x21, [sp, #0x1e8]
    9364:      	ldr	x22, [sp, #0x1f0]
    9368:      	ldr	x23, [sp, #0x1f8]
    936c:      	ldr	x24, [sp, #0x200]
    9370:      	ldr	x25, [sp, #0x208]
    9374:      	ldr	x26, [sp, #0x210]
    9378:      	ldr	x27, [sp, #0x218]
    937c:      	ldr	x28, [sp, #0x220]
    9380:      	ldr	x29, [sp]
    9384:      	ldr	x30, [sp, #0x8]
    9388:      	add	sp, sp, #0x230
    938c:      	ret
    9390:      	add	x16, sp, #0x110
    9394:      	ldr	x1, [x16, #0x8]
    9398:      	add	x16, sp, #0x110
    939c:      	ldr	x2, [x16, #0x10]
    93a0:      	cmp	x1, x2
    93a4:      	b.lt	0x9758 <_stogir.checked-schedule.cluster!+0x9c8>
    93a8:      	cmp	x2, #0x0
    93ac:      	b.ne	0x9100 <_stogir.checked-schedule.cluster!+0x370>
    93b0:      	mov	x2, #0x2                ; =2
    93b4:      	b	0x9104 <_stogir.checked-schedule.cluster!+0x374>
    93b8:      	add	x16, sp, #0x150
    93bc:      	orr	x0, x16, xzr
    93c0:      	ldr	x1, [x22, #0x28]
    93c4:      	add	x20, x0, #0x8
    93c8:      	ldr	x0, [x19, #0x8]
    93cc:      	orr	x26, x1, xzr
    93d0:      	movz	x1, #0x0, lsl #48
    93d4:      	b	0x8fc4 <_stogir.checked-schedule.cluster!+0x234>
    93d8:      	lsl	x0, x0, #1
    93dc:      	mov	x1, x0
    93e0:      	add	x0, sp, #0x50
    93e4:      	bl	0x93e4 <_stogir.checked-schedule.cluster!+0x654>
		00000000000093e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    93e8:      	add	x0, x26, #0x1
    93ec:      	add	x16, sp, #0x50
    93f0:      	ldr	x1, [x16]
    93f4:      	add	x1, x1, x26, lsl #2
    93f8:      	movz	w17, #0x0, lsl #16
    93fc:      	str	w17, [x1]
    9400:      	add	x16, sp, #0x50
    9404:      	str	x0, [x16, #0x8]
    9408:      	add	x16, sp, #0x80
    940c:      	ldr	x0, [x16, #0x8]
    9410:      	orr	x26, x0, xzr
    9414:      	add	x16, sp, #0x80
    9418:      	ldr	x0, [x16, #0x10]
    941c:      	cmp	x26, x0
    9420:      	b.lt	0x9444 <_stogir.checked-schedule.cluster!+0x6b4>
    9424:      	cmp	x0, #0x0
    9428:      	b.ne	0x9434 <_stogir.checked-schedule.cluster!+0x6a4>
    942c:      	mov	x0, #0x2                ; =2
    9430:      	b	0x9438 <_stogir.checked-schedule.cluster!+0x6a8>
    9434:      	lsl	x0, x0, #1
    9438:      	mov	x1, x0
    943c:      	add	x0, sp, #0x80
    9440:      	bl	0x9440 <_stogir.checked-schedule.cluster!+0x6b0>
		0000000000009440:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9444:      	add	x0, x26, #0x1
    9448:      	add	x16, sp, #0x80
    944c:      	ldr	x1, [x16]
    9450:      	add	x1, x1, x26, lsl #2
    9454:      	movz	w17, #0x0, lsl #16
    9458:      	str	w17, [x1]
    945c:      	add	x16, sp, #0x80
    9460:      	str	x0, [x16, #0x8]
    9464:      	add	x16, sp, #0xb0
    9468:      	ldr	x0, [x16, #0x8]
    946c:      	orr	x26, x0, xzr
    9470:      	add	x16, sp, #0xb0
    9474:      	ldr	x0, [x16, #0x10]
    9478:      	cmp	x26, x0
    947c:      	b.lt	0x94a0 <_stogir.checked-schedule.cluster!+0x710>
    9480:      	cmp	x0, #0x0
    9484:      	b.ne	0x9490 <_stogir.checked-schedule.cluster!+0x700>
    9488:      	mov	x0, #0x2                ; =2
    948c:      	b	0x9494 <_stogir.checked-schedule.cluster!+0x704>
    9490:      	lsl	x0, x0, #1
    9494:      	mov	x1, x0
    9498:      	add	x0, sp, #0xb0
    949c:      	bl	0x949c <_stogir.checked-schedule.cluster!+0x70c>
		000000000000949c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    94a0:      	add	x0, x26, #0x1
    94a4:      	add	x16, sp, #0xb0
    94a8:      	ldr	x1, [x16]
    94ac:      	add	x1, x1, x26, lsl #2
    94b0:      	movz	w17, #0x0, lsl #16
    94b4:      	str	w17, [x1]
    94b8:      	add	x16, sp, #0xb0
    94bc:      	str	x0, [x16, #0x8]
    94c0:      	add	x16, sp, #0xe0
    94c4:      	ldr	x0, [x16, #0x8]
    94c8:      	orr	x26, x0, xzr
    94cc:      	add	x16, sp, #0xe0
    94d0:      	ldr	x0, [x16, #0x10]
    94d4:      	cmp	x26, x0
    94d8:      	b.lt	0x94fc <_stogir.checked-schedule.cluster!+0x76c>
    94dc:      	cmp	x0, #0x0
    94e0:      	b.ne	0x94ec <_stogir.checked-schedule.cluster!+0x75c>
    94e4:      	mov	x0, #0x2                ; =2
    94e8:      	b	0x94f0 <_stogir.checked-schedule.cluster!+0x760>
    94ec:      	lsl	x0, x0, #1
    94f0:      	mov	x1, x0
    94f4:      	add	x0, sp, #0xe0
    94f8:      	bl	0x94f8 <_stogir.checked-schedule.cluster!+0x768>
		00000000000094f8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    94fc:      	add	x20, x20, #0x1
    9500:      	add	x0, x26, #0x1
    9504:      	add	x16, sp, #0xe0
    9508:      	ldr	x1, [x16]
    950c:      	add	x1, x1, x26
    9510:      	movz	w17, #0x0, lsl #16
    9514:      	strb	w17, [x1]
    9518:      	add	x16, sp, #0xe0
    951c:      	str	x0, [x16, #0x8]
    9520:      	ldr	x0, [x28, #0x8]
    9524:      	cmp	x20, x0
    9528:      	b.ge	0x93b8 <_stogir.checked-schedule.cluster!+0x628>
    952c:      	add	x16, sp, #0x50
    9530:      	ldr	x0, [x16, #0x8]
    9534:      	orr	x26, x0, xzr
    9538:      	add	x16, sp, #0x50
    953c:      	ldr	x0, [x16, #0x10]
    9540:      	cmp	x26, x0
    9544:      	b.lt	0x93e8 <_stogir.checked-schedule.cluster!+0x658>
    9548:      	cmp	x0, #0x0
    954c:      	b.ne	0x93d8 <_stogir.checked-schedule.cluster!+0x648>
    9550:      	mov	x0, #0x2                ; =2
    9554:      	b	0x93dc <_stogir.checked-schedule.cluster!+0x64c>
    9558:      	ldr	x0, [x26]
    955c:      	ldr	x1, [x26, #0x8]
    9560:      	add	x16, sp, #0x50
    9564:      	movz	x17, #0x0, lsl #48
    9568:      	str	x17, [x16]
    956c:      	add	x16, sp, #0x50
    9570:      	movz	x17, #0x0, lsl #48
    9574:      	str	x17, [x16, #0x8]
    9578:      	add	x16, sp, #0x50
    957c:      	movz	x17, #0x0, lsl #48
    9580:      	str	x17, [x16, #0x10]
    9584:      	add	x16, sp, #0x50
    9588:      	str	x0, [x16, #0x18]
    958c:      	add	x16, sp, #0x50
    9590:      	str	x1, [x16, #0x20]
    9594:      	add	x16, sp, #0x80
    9598:      	movz	x17, #0x0, lsl #48
    959c:      	str	x17, [x16]
    95a0:      	add	x16, sp, #0x80
    95a4:      	movz	x17, #0x0, lsl #48
    95a8:      	str	x17, [x16, #0x8]
    95ac:      	add	x16, sp, #0x80
    95b0:      	movz	x17, #0x0, lsl #48
    95b4:      	str	x17, [x16, #0x10]
    95b8:      	add	x16, sp, #0x80
    95bc:      	str	x0, [x16, #0x18]
    95c0:      	add	x16, sp, #0x80
    95c4:      	str	x1, [x16, #0x20]
    95c8:      	add	x16, sp, #0xb0
    95cc:      	movz	x17, #0x0, lsl #48
    95d0:      	str	x17, [x16]
    95d4:      	add	x16, sp, #0xb0
    95d8:      	movz	x17, #0x0, lsl #48
    95dc:      	str	x17, [x16, #0x8]
    95e0:      	add	x16, sp, #0xb0
    95e4:      	movz	x17, #0x0, lsl #48
    95e8:      	str	x17, [x16, #0x10]
    95ec:      	add	x16, sp, #0xb0
    95f0:      	str	x0, [x16, #0x18]
    95f4:      	add	x16, sp, #0xb0
    95f8:      	str	x1, [x16, #0x20]
    95fc:      	add	x16, sp, #0xe0
    9600:      	movz	x17, #0x0, lsl #48
    9604:      	str	x17, [x16]
    9608:      	add	x16, sp, #0xe0
    960c:      	movz	x17, #0x0, lsl #48
    9610:      	str	x17, [x16, #0x8]
    9614:      	add	x16, sp, #0xe0
    9618:      	movz	x17, #0x0, lsl #48
    961c:      	str	x17, [x16, #0x10]
    9620:      	add	x16, sp, #0xe0
    9624:      	str	x0, [x16, #0x18]
    9628:      	add	x16, sp, #0xe0
    962c:      	str	x1, [x16, #0x20]
    9630:      	add	x16, sp, #0x110
    9634:      	movz	x17, #0x0, lsl #48
    9638:      	str	x17, [x16]
    963c:      	add	x16, sp, #0x110
    9640:      	movz	x17, #0x0, lsl #48
    9644:      	str	x17, [x16, #0x8]
    9648:      	add	x16, sp, #0x110
    964c:      	movz	x17, #0x0, lsl #48
    9650:      	str	x17, [x16, #0x10]
    9654:      	add	x16, sp, #0x110
    9658:      	str	x0, [x16, #0x18]
    965c:      	add	x16, sp, #0x110
    9660:      	str	x1, [x16, #0x20]
    9664:      	movz	x20, #0x0, lsl #48
    9668:      	b	0x9520 <_stogir.checked-schedule.cluster!+0x790>
    966c:      	add	x16, sp, #0x150
    9670:      	ldr	w0, [x16, #0x8]
    9674:      	sxtw	x0, w0
    9678:      	cmp	x0, #0x0
    967c:      	b.eq	0x8fb4 <_stogir.checked-schedule.cluster!+0x224>
    9680:      	add	x16, sp, #0x140
    9684:      	ldr	w0, [x16, #0x4]
    9688:      	sxtw	x0, w0
    968c:      	add	x16, sp, #0x80
    9690:      	ldr	x1, [x16]
    9694:      	add	x1, x1, x0, lsl #2
    9698:      	ldr	w1, [x1]
    969c:      	ldr	x2, [x21]
    96a0:      	orr	x3, x2, xzr
    96a4:      	add	x3, x3, x0, lsl #2
    96a8:      	add	x2, x2, x28, lsl #2
    96ac:      	ldr	w3, [x3]
    96b0:      	ldr	w2, [x2]
    96b4:      	sxtw	x3, w3
    96b8:      	sxtw	x2, w2
    96bc:      	cmp	x3, x2
    96c0:      	b.eq	0x96d0 <_stogir.checked-schedule.cluster!+0x940>
    96c4:      	adrp	x24, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		00000000000096c4:  ARM64_RELOC_PAGE21	l_stogir.450
    96c8:      	ldr	x24, [x24]
		00000000000096c8:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    96cc:      	mov	x25, #0x30              ; =48
    96d0:      	sxtw	x1, w1
    96d4:      	cmp	x1, #0x0
    96d8:      	b.ne	0x8f80 <_stogir.checked-schedule.cluster!+0x1f0>
    96dc:      	add	x16, sp, #0x50
    96e0:      	ldr	x1, [x16]
    96e4:      	add	x1, x1, x0, lsl #2
    96e8:      	str	w26, [x1]
    96ec:      	b	0x8f90 <_stogir.checked-schedule.cluster!+0x200>
    96f0:      	brk	#0
    96f4:      	b	0x96f0 <_stogir.checked-schedule.cluster!+0x960>
    96f8:      	brk	#0
    96fc:      	b	0x96f8 <_stogir.checked-schedule.cluster!+0x968>
    9700:      	brk	#0
    9704:      	b	0x9700 <_stogir.checked-schedule.cluster!+0x970>
    9708:      	brk	#0
    970c:      	b	0x9708 <_stogir.checked-schedule.cluster!+0x978>
    9710:      	brk	#0
    9714:      	b	0x9710 <_stogir.checked-schedule.cluster!+0x980>
    9718:      	brk	#0
    971c:      	b	0x9718 <_stogir.checked-schedule.cluster!+0x988>
    9720:      	mov	x27, x8
    9724:      	mov	x28, x0
    9728:      	str	x22, [sp, #0x198]
    972c:      	mov	x22, x2
    9730:      	str	x21, [sp, #0x190]
    9734:      	mov	x21, x1
    9738:      	str	x26, [sp, #0x1a0]
    973c:      	mov	x26, x3
    9740:      	b	0x8e1c <_stogir.checked-schedule.cluster!+0x8c>
    9744:      	str	x28, [sp, #0x1c0]
    9748:      	str	x0, [sp, #0x1a8]
    974c:      	str	x26, [sp, #0x1b8]
    9750:      	str	x1, [sp, #0x1b0]
    9754:      	b	0x8fb4 <_stogir.checked-schedule.cluster!+0x224>
    9758:      	str	x21, [sp, #0x1d0]
    975c:      	mov	x21, x1
    9760:      	str	x20, [sp, #0x1c8]
    9764:      	mov	x20, x0
    9768:      	b	0x9120 <_stogir.checked-schedule.cluster!+0x390>
    976c:      	udf	#0x0

0000000000009770 <_stogir.adjacency.release!>:
    9770:      	sub	sp, sp, #0x20
    9774:      	str	x29, [sp]
    9778:      	str	x30, [sp, #0x8]
    977c:      	mov	x29, sp
    9780:      	str	x19, [sp, #0x10]
    9784:      	str	x20, [sp, #0x18]
    9788:      	b	0x9798 <_stogir.adjacency.release!+0x28>
    978c:      	nop
    9790:      	sub	x1, x1, #0x1
    9794:      	str	x1, [x0, #0x8]
    9798:      	ldr	x1, [x0, #0x8]
    979c:      	cmp	x1, #0x0
    97a0:      	b.ne	0x9790 <_stogir.adjacency.release!+0x20>
    97a4:      	ldr	x1, [x0, #0x10]
    97a8:      	cmp	x1, #0x0
    97ac:      	b.le	0x987c <_stogir.adjacency.release!+0x10c>
    97b0:      	add	x2, x0, #0x18
    97b4:      	ldr	x3, [x0]
    97b8:      	mov	x19, x0
    97bc:      	mov	x0, x2
    97c0:      	mov	x2, x1
    97c4:      	mov	x1, x3
    97c8:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		00000000000097c8:  ARM64_RELOC_PAGE21	l_stogir.451
    97cc:      	ldr	x3, [x3]
		00000000000097cc:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    97d0:      	mov	x4, #0x10               ; =16
    97d4:      	mov	x5, #0x8                ; =8
    97d8:      	bl	0x97d8 <_stogir.adjacency.release!+0x68>
		00000000000097d8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    97dc:      	add	x20, x19, #0x28
    97e0:      	movz	x17, #0x0, lsl #48
    97e4:      	str	x17, [x19]
    97e8:      	movz	x17, #0x0, lsl #48
    97ec:      	str	x17, [x19, #0x8]
    97f0:      	movz	x17, #0x0, lsl #48
    97f4:      	str	x17, [x19, #0x10]
    97f8:      	b	0x9808 <_stogir.adjacency.release!+0x98>
    97fc:      	nop
    9800:      	sub	x0, x0, #0x1
    9804:      	str	x0, [x20, #0x8]
    9808:      	ldr	x0, [x20, #0x8]
    980c:      	cmp	x0, #0x0
    9810:      	b.ne	0x9800 <_stogir.adjacency.release!+0x90>
    9814:      	ldr	x0, [x20, #0x10]
    9818:      	cmp	x0, #0x0
    981c:      	b.le	0x984c <_stogir.adjacency.release!+0xdc>
    9820:      	add	x1, x20, #0x18
    9824:      	ldr	x2, [x19, #0x28]
    9828:      	fmov	d31, x0
    982c:      	mov	x0, x1
    9830:      	mov	x1, x2
    9834:      	fmov	x2, d31
    9838:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009838:  ARM64_RELOC_PAGE21	l_stogir.452
    983c:      	ldr	x3, [x3]
		000000000000983c:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9840:      	mov	x4, #0x8                ; =8
    9844:      	mov	x5, #0x8                ; =8
    9848:      	bl	0x9848 <_stogir.adjacency.release!+0xd8>
		0000000000009848:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    984c:      	movz	x17, #0x0, lsl #48
    9850:      	str	x17, [x19, #0x28]
    9854:      	movz	x17, #0x0, lsl #48
    9858:      	str	x17, [x20, #0x8]
    985c:      	movz	x17, #0x0, lsl #48
    9860:      	str	x17, [x20, #0x10]
    9864:      	ldr	x19, [sp, #0x10]
    9868:      	ldr	x20, [sp, #0x18]
    986c:      	ldr	x29, [sp]
    9870:      	ldr	x30, [sp, #0x8]
    9874:      	add	sp, sp, #0x20
    9878:      	ret
    987c:      	mov	x19, x0
    9880:      	b	0x97dc <_stogir.adjacency.release!+0x6c>
    9884:      	udf	#0x0

0000000000009888 <_inherent$coil.arraylist.ArrayList$free!__bool>:
    9888:      	sub	sp, sp, #0x20
    988c:      	str	x29, [sp]
    9890:      	str	x30, [sp, #0x8]
    9894:      	mov	x29, sp
    9898:      	str	x19, [sp, #0x10]
    989c:      	b	0x98a8 <_inherent$coil.arraylist.ArrayList$free!__bool+0x20>
    98a0:      	sub	x1, x1, #0x1
    98a4:      	str	x1, [x0, #0x8]
    98a8:      	ldr	x1, [x0, #0x8]
    98ac:      	cmp	x1, #0x0
    98b0:      	b.ne	0x98a0 <_inherent$coil.arraylist.ArrayList$free!__bool+0x18>
    98b4:      	ldr	x1, [x0, #0x10]
    98b8:      	cmp	x1, #0x0
    98bc:      	b.le	0x991c <_inherent$coil.arraylist.ArrayList$free!__bool+0x94>
    98c0:      	add	x2, x0, #0x18
    98c4:      	ldr	x3, [x0]
    98c8:      	mov	x19, x0
    98cc:      	mov	x0, x2
    98d0:      	mov	x2, x1
    98d4:      	mov	x1, x3
    98d8:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		00000000000098d8:  ARM64_RELOC_PAGE21	l_stogir.453
    98dc:      	ldr	x3, [x3]
		00000000000098dc:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    98e0:      	mov	x4, #0x1                ; =1
    98e4:      	mov	x5, #0x1                ; =1
    98e8:      	bl	0x98e8 <_inherent$coil.arraylist.ArrayList$free!__bool+0x60>
		00000000000098e8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    98ec:      	movz	x17, #0x0, lsl #48
    98f0:      	str	x17, [x19]
    98f4:      	movz	x17, #0x0, lsl #48
    98f8:      	str	x17, [x19, #0x8]
    98fc:      	movz	x17, #0x0, lsl #48
    9900:      	str	x17, [x19, #0x10]
    9904:      	movz	x0, #0x0, lsl #48
    9908:      	ldr	x19, [sp, #0x10]
    990c:      	ldr	x29, [sp]
    9910:      	ldr	x30, [sp, #0x8]
    9914:      	add	sp, sp, #0x20
    9918:      	ret
    991c:      	mov	x19, x0
    9920:      	b	0x98ec <_inherent$coil.arraylist.ArrayList$free!__bool+0x64>
    9924:      	udf	#0x0

0000000000009928 <_stogir.uses.release!>:
    9928:      	sub	sp, sp, #0x20
    992c:      	str	x29, [sp]
    9930:      	str	x30, [sp, #0x8]
    9934:      	mov	x29, sp
    9938:      	str	x19, [sp, #0x10]
    993c:      	str	x20, [sp, #0x18]
    9940:      	b	0x9950 <_stogir.uses.release!+0x28>
    9944:      	nop
    9948:      	sub	x1, x1, #0x1
    994c:      	str	x1, [x0, #0x8]
    9950:      	ldr	x1, [x0, #0x8]
    9954:      	cmp	x1, #0x0
    9958:      	b.ne	0x9948 <_stogir.uses.release!+0x20>
    995c:      	ldr	x1, [x0, #0x10]
    9960:      	cmp	x1, #0x0
    9964:      	b.le	0x9a34 <_stogir.uses.release!+0x10c>
    9968:      	add	x2, x0, #0x18
    996c:      	ldr	x3, [x0]
    9970:      	mov	x19, x0
    9974:      	mov	x0, x2
    9978:      	mov	x2, x1
    997c:      	mov	x1, x3
    9980:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009980:  ARM64_RELOC_PAGE21	l_stogir.454
    9984:      	ldr	x3, [x3]
		0000000000009984:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    9988:      	mov	x4, #0x10               ; =16
    998c:      	mov	x5, #0x8                ; =8
    9990:      	bl	0x9990 <_stogir.uses.release!+0x68>
		0000000000009990:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    9994:      	add	x20, x19, #0x28
    9998:      	movz	x17, #0x0, lsl #48
    999c:      	str	x17, [x19]
    99a0:      	movz	x17, #0x0, lsl #48
    99a4:      	str	x17, [x19, #0x8]
    99a8:      	movz	x17, #0x0, lsl #48
    99ac:      	str	x17, [x19, #0x10]
    99b0:      	b	0x99c0 <_stogir.uses.release!+0x98>
    99b4:      	nop
    99b8:      	sub	x0, x0, #0x1
    99bc:      	str	x0, [x20, #0x8]
    99c0:      	ldr	x0, [x20, #0x8]
    99c4:      	cmp	x0, #0x0
    99c8:      	b.ne	0x99b8 <_stogir.uses.release!+0x90>
    99cc:      	ldr	x0, [x20, #0x10]
    99d0:      	cmp	x0, #0x0
    99d4:      	b.le	0x9a04 <_stogir.uses.release!+0xdc>
    99d8:      	add	x1, x20, #0x18
    99dc:      	ldr	x2, [x19, #0x28]
    99e0:      	fmov	d31, x0
    99e4:      	mov	x0, x1
    99e8:      	mov	x1, x2
    99ec:      	fmov	x2, d31
    99f0:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		00000000000099f0:  ARM64_RELOC_PAGE21	l_stogir.455
    99f4:      	ldr	x3, [x3]
		00000000000099f4:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    99f8:      	mov	x4, #0x8                ; =8
    99fc:      	mov	x5, #0x4                ; =4
    9a00:      	bl	0x9a00 <_stogir.uses.release!+0xd8>
		0000000000009a00:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    9a04:      	movz	x17, #0x0, lsl #48
    9a08:      	str	x17, [x19, #0x28]
    9a0c:      	movz	x17, #0x0, lsl #48
    9a10:      	str	x17, [x20, #0x8]
    9a14:      	movz	x17, #0x0, lsl #48
    9a18:      	str	x17, [x20, #0x10]
    9a1c:      	ldr	x19, [sp, #0x10]
    9a20:      	ldr	x20, [sp, #0x18]
    9a24:      	ldr	x29, [sp]
    9a28:      	ldr	x30, [sp, #0x8]
    9a2c:      	add	sp, sp, #0x20
    9a30:      	ret
    9a34:      	mov	x19, x0
    9a38:      	b	0x9994 <_stogir.uses.release!+0x6c>
    9a3c:      	udf	#0x0

0000000000009a40 <_stogir.verify.structure>:
    9a40:      	sub	sp, sp, #0x110
    9a44:      	str	x29, [sp, #0x10]
    9a48:      	str	x30, [sp, #0x18]
    9a4c:      	add	x29, sp, #0x10
    9a50:      	str	x19, [sp, #0xb8]
    9a54:      	str	x20, [sp, #0xc0]
    9a58:      	str	x21, [sp, #0xc8]
    9a5c:      	str	x22, [sp, #0xd0]
    9a60:      	str	x23, [sp, #0xd8]
    9a64:      	str	x24, [sp, #0xe0]
    9a68:      	str	x25, [sp, #0xe8]
    9a6c:      	str	x26, [sp, #0xf0]
    9a70:      	str	x27, [sp, #0xf8]
    9a74:      	str	x28, [sp, #0x100]
    9a78:      	mov	x19, x8
    9a7c:      	mov	x20, x0
    9a80:      	bl	0x9a80 <_stogir.verify.structure+0x40>
		0000000000009a80:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    9a84:      	add	x21, x20, #0x78
    9a88:      	mov	x22, x0
    9a8c:      	mov	x0, x21
    9a90:      	bl	0x9a90 <_stogir.verify.structure+0x50>
		0000000000009a90:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    9a94:      	cmp	x22, x0
    9a98:      	b.ne	0x9ac8 <_stogir.verify.structure+0x88>
    9a9c:      	adrp	x22, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009a9c:  ARM64_RELOC_PAGE21	l_stogir.456
    9aa0:      	ldr	x22, [x22]
		0000000000009aa0:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9aa4:      	movz	x23, #0x0, lsl #48
    9aa8:      	b	0x9ad4 <_stogir.verify.structure+0x94>
    9aac:      	ldr	x1, [sp, #0x88]
    9ab0:      	ldr	x5, [sp, #0x90]
    9ab4:      	add	x5, x1, x5
    9ab8:      	ldr	x19, [sp, #0x40]
    9abc:      	add	x1, x19, #0x1
    9ac0:      	sxtw	x19, w1
    9ac4:      	b	0x9b04 <_stogir.verify.structure+0xc4>
    9ac8:      	adrp	x22, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009ac8:  ARM64_RELOC_PAGE21	l_stogir.457
    9acc:      	ldr	x22, [x22]
		0000000000009acc:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    9ad0:      	mov	x23, #0x2c              ; =44
    9ad4:      	add	x24, x20, #0x110
    9ad8:      	add	x25, x20, #0x28
    9adc:      	add	x26, x20, #0x50
    9ae0:      	add	x27, x24, #0x28
    9ae4:      	mov	x28, #0x1               ; =1
    9ae8:      	movz	x0, #0x0, lsl #48
    9aec:      	b	0x9b5c <_stogir.verify.structure+0x11c>
    9af0:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009af0:  ARM64_RELOC_PAGE21	l_stogir.458
    9af4:      	ldr	x16, [x16]
		0000000000009af4:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    9af8:      	str	x16, [sp, #0x38]
    9afc:      	mov	x16, #0x16              ; =22
    9b00:      	str	x16, [sp, #0x80]
    9b04:      	b	0x9b38 <_stogir.verify.structure+0xf8>
    9b08:      	mov	x5, x28
    9b0c:      	str	x19, [sp, #0x30]
    9b10:      	mov	x19, x0
    9b14:      	mov	x0, x21
    9b18:      	mov	x2, x24
    9b1c:      	mov	x3, x25
    9b20:      	mov	x4, x26
    9b24:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009b24:  ARM64_RELOC_PAGE21	l_stogir.459
    9b28:      	ldr	x16, [x16]
		0000000000009b28:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    9b2c:      	str	x16, [sp, #0x38]
    9b30:      	mov	x16, #0x23              ; =35
    9b34:      	str	x16, [sp, #0x80]
    9b38:      	mov	x21, x0
    9b3c:      	mov	x24, x2
    9b40:      	mov	x25, x3
    9b44:      	mov	x26, x4
    9b48:      	mov	x28, x5
    9b4c:      	mov	x0, x19
    9b50:      	ldr	x19, [sp, #0x30]
    9b54:      	ldr	x22, [sp, #0x38]
    9b58:      	ldr	x23, [sp, #0x80]
    9b5c:      	cmp	x23, #0x0
    9b60:      	b.ne	0xa31c <_stogir.verify.structure+0x8dc>
    9b64:      	ldr	x1, [x20, #0x8]
    9b68:      	cmp	x28, x1
    9b6c:      	b.ge	0xa330 <_stogir.verify.structure+0x8f0>
    9b70:      	ldr	x1, [x20]
    9b74:      	add	x1, x1, x28, lsl #4
    9b78:      	ldr	x1, [x1]
    9b7c:      	ldr	x2, [x20, #0x78]
    9b80:      	add	x2, x2, x28, lsl #2
    9b84:      	ldr	w2, [x2]
    9b88:      	sxtw	x2, w2
    9b8c:      	cmp	x2, #0x0
    9b90:      	b.lt	0x9b08 <_stogir.verify.structure+0xc8>
    9b94:      	mov	x17, #0xffff            ; =65535
    9b98:      	cmp	x2, x17
    9b9c:      	b.gt	0xa344 <_stogir.verify.structure+0x904>
    9ba0:      	uxtb	w3, w1
    9ba4:      	orr	x4, x3, xzr
    9ba8:      	cmp	x4, #0x83
    9bac:      	cset	w5, lt
    9bb0:      	uxtb	w16, w5
    9bb4:      	cmp	w16, wzr
    9bb8:      	b.eq	0xa364 <_stogir.verify.structure+0x924>
    9bbc:      	ubfx	x1, x1, #0, #32
    9bc0:      	ubfx	x6, x1, #8, #8
    9bc4:      	orr	x7, x6, xzr
    9bc8:      	str	x0, [sp, #0x40]
    9bcc:      	mov	w0, w7
    9bd0:      	str	x19, [sp, #0x30]
    9bd4:      	mov	w19, w3
    9bd8:      	str	x22, [sp, #0x38]
    9bdc:      	mov	x22, x2
    9be0:      	str	x26, [sp, #0x48]
    9be4:      	mov	x26, x4
    9be8:      	str	x25, [sp, #0x50]
    9bec:      	mov	w25, w5
    9bf0:      	str	x21, [sp, #0x58]
    9bf4:      	mov	x21, x1
    9bf8:      	str	x24, [sp, #0x60]
    9bfc:      	mov	w24, w6
    9c00:      	bl	0x9c00 <_stogir.verify.structure+0x1c0>
		0000000000009c00:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    9c04:      	cmp	x0, #0x0
    9c08:      	b.eq	0xa384 <_stogir.verify.structure+0x944>
    9c0c:      	adrp	x17, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009c0c:  ARM64_RELOC_PAGE21	l_stogir.460
    9c10:      	ldr	x17, [x17]
		0000000000009c10:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    9c14:      	add	x0, x26, x17
    9c18:      	ldrsb	w0, [x0]
    9c1c:      	sxtb	x0, w0
    9c20:      	cmp	x0, #0x0
    9c24:      	b.lt	0xa03c <_stogir.verify.structure+0x5fc>
    9c28:      	uxtb	w16, w25
    9c2c:      	cmp	w16, wzr
    9c30:      	b.eq	0xa110 <_stogir.verify.structure+0x6d0>
    9c34:      	adrp	x17, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009c34:  ARM64_RELOC_PAGE21	l_stogir.460
    9c38:      	ldr	x17, [x17]
		0000000000009c38:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    9c3c:      	add	x0, x26, x17
    9c40:      	ldrsb	w0, [x0]
    9c44:      	sxtb	w0, w0
    9c48:      	b	0xa114 <_stogir.verify.structure+0x6d4>
    9c4c:      	ldr	x0, [sp, #0x38]
    9c50:      	ldr	x1, [sp, #0x80]
    9c54:      	adrp	x2, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009c54:  ARM64_RELOC_PAGE21	l_stogir.456
    9c58:      	ldr	x2, [x2]
		0000000000009c58:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9c5c:      	movz	x3, #0x0, lsl #48
    9c60:      	bl	0x9c60 <_stogir.verify.structure+0x220>
		0000000000009c60:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    9c64:      	cmp	x0, #0x0
    9c68:      	b.eq	0xa3a0 <_stogir.verify.structure+0x960>
    9c6c:      	and	x0, x19, #0xffffffff
    9c70:      	movz	x1, #0x0, lsl #48
    9c74:      	movz	x16, #0x0, lsl #48
    9c78:      	str	x16, [sp, #0x80]
    9c7c:      	b	0x9c84 <_stogir.verify.structure+0x244>
    9c80:      	mov	x1, #0x1                ; =1
    9c84:      	ldr	x2, [sp, #0x30]
    9c88:      	str	x1, [x2]
    9c8c:      	str	x0, [x2, #0x8]
    9c90:      	ldr	x0, [sp, #0x80]
    9c94:      	str	x0, [x2, #0x10]
    9c98:      	ldr	x19, [sp, #0xb8]
    9c9c:      	ldr	x20, [sp, #0xc0]
    9ca0:      	ldr	x21, [sp, #0xc8]
    9ca4:      	ldr	x22, [sp, #0xd0]
    9ca8:      	ldr	x23, [sp, #0xd8]
    9cac:      	ldr	x24, [sp, #0xe0]
    9cb0:      	ldr	x25, [sp, #0xe8]
    9cb4:      	ldr	x26, [sp, #0xf0]
    9cb8:      	ldr	x27, [sp, #0xf8]
    9cbc:      	ldr	x28, [sp, #0x100]
    9cc0:      	ldr	x29, [sp, #0x10]
    9cc4:      	ldr	x30, [sp, #0x18]
    9cc8:      	add	sp, sp, #0x110
    9ccc:      	ret
    9cd0:      	mov	w9, w5
    9cd4:      	lsl	w9, w9, #2
    9cd8:      	ubfx	x9, x9, #0, #32
    9cdc:      	lsr	x8, x8, x9
    9ce0:      	and	w8, w8, #0xf
    9ce4:      	b	0x9d04 <_stogir.verify.structure+0x2c4>
    9ce8:      	movz	x1, #0x0, lsl #48
    9cec:      	cmp	x1, #0x0
    9cf0:      	b.eq	0xa150 <_stogir.verify.structure+0x710>
    9cf4:      	ldr	w1, [sp, #0xb0]
    9cf8:      	ldr	w5, [sp, #0xa8]
    9cfc:      	b	0x9dac <_stogir.verify.structure+0x36c>
    9d00:      	movz	w8, #0x0, lsl #16
    9d04:      	b	0x9d0c <_stogir.verify.structure+0x2cc>
    9d08:      	movz	w8, #0x0, lsl #16
    9d0c:      	str	w0, [sp, #0x68]
    9d10:      	str	x2, [sp, #0x98]
    9d14:      	mov	w2, w3
    9d18:      	str	x4, [sp, #0xa0]
    9d1c:      	str	x22, [sp, #0x70]
    9d20:      	mov	x22, x1
    9d24:      	mov	w1, w0
    9d28:      	mov	x0, x20
    9d2c:      	str	x26, [sp, #0x78]
    9d30:      	mov	w26, w7
    9d34:      	str	x23, [sp, #0x80]
    9d38:      	mov	w23, w8
    9d3c:      	str	x19, [sp, #0x88]
    9d40:      	mov	w19, w5
    9d44:      	str	x28, [sp, #0x90]
    9d48:      	mov	w28, w6
    9d4c:      	bl	0x9d4c <_stogir.verify.structure+0x30c>
		0000000000009d4c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    9d50:      	ubfx	x0, x0, #0, #32
    9d54:      	lsr	x16, x0, #0
    9d58:      	cmp	x16, #0x1
    9d5c:      	b.eq	0x9d78 <_stogir.verify.structure+0x338>
    9d60:      	b.lo	0x9d68 <_stogir.verify.structure+0x328>
    9d64:      	b	0x9d7c <_stogir.verify.structure+0x33c>
    9d68:      	cmp	x16, #0x0
    9d6c:      	b.eq	0x9d74 <_stogir.verify.structure+0x334>
    9d70:      	b	0x9d7c <_stogir.verify.structure+0x33c>
    9d74:      	b	0x9d80 <_stogir.verify.structure+0x340>
    9d78:      	b	0x9e60 <_stogir.verify.structure+0x420>
    9d7c:      	b	0xa284 <_stogir.verify.structure+0x844>
    9d80:      	ldr	x0, [sp, #0x58]
    9d84:      	ldr	x2, [sp, #0x60]
    9d88:      	mov	w1, w21
    9d8c:      	mov	w5, w24
    9d90:      	ldr	x3, [sp, #0x50]
    9d94:      	ldr	x4, [sp, #0x48]
    9d98:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009d98:  ARM64_RELOC_PAGE21	l_stogir.461
    9d9c:      	ldr	x16, [x16]
		0000000000009d9c:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    9da0:      	str	x16, [sp, #0x38]
    9da4:      	mov	x16, #0x17              ; =23
    9da8:      	str	x16, [sp, #0x80]
    9dac:      	ldr	x6, [sp, #0x98]
    9db0:      	add	x6, x6, #0x1
    9db4:      	sxtw	x6, w6
    9db8:      	ldr	x28, [sp, #0x90]
    9dbc:      	str	x0, [sp, #0x58]
    9dc0:      	ldr	x19, [sp, #0x88]
    9dc4:      	ldr	w0, [sp, #0x68]
    9dc8:      	str	x2, [sp, #0x60]
    9dcc:      	ldr	x26, [sp, #0x78]
    9dd0:      	mov	w21, w1
    9dd4:      	mov	w24, w5
    9dd8:      	mov	x1, x22
    9ddc:      	ldr	x22, [sp, #0x70]
    9de0:      	str	x3, [sp, #0x50]
    9de4:      	str	x4, [sp, #0x48]
    9de8:      	mov	x2, x6
    9dec:      	ldr	x23, [sp, #0x80]
    9df0:      	cmp	x23, #0x0
    9df4:      	b.ne	0x9e08 <_stogir.verify.structure+0x3c8>
    9df8:      	cmp	x2, x22
    9dfc:      	cset	w3, le
    9e00:      	ubfx	x3, x3, #0, #8
    9e04:      	b	0x9e0c <_stogir.verify.structure+0x3cc>
    9e08:      	movz	x3, #0x0, lsl #48
    9e0c:      	cmp	x3, #0x0
    9e10:      	b.eq	0xa3a8 <_stogir.verify.structure+0x968>
    9e14:      	orr	w3, w2, wzr
    9e18:      	sxtw	x4, w3
    9e1c:      	sub	w5, w3, #0x1
    9e20:      	cmp	x4, #0x0
    9e24:      	cset	w6, gt
    9e28:      	cmp	x4, #0x4
    9e2c:      	cset	w7, gt
    9e30:      	uxtb	w16, w25
    9e34:      	cmp	w16, wzr
    9e38:      	b.eq	0x9d08 <_stogir.verify.structure+0x2c8>
    9e3c:      	ldr	w8, [x26]
    9e40:      	uxtb	w16, w6
    9e44:      	cmp	w16, wzr
    9e48:      	b.eq	0x9d00 <_stogir.verify.structure+0x2c0>
    9e4c:      	uxtb	w16, w7
    9e50:      	cmp	w16, wzr
    9e54:      	b.eq	0x9cd0 <_stogir.verify.structure+0x290>
    9e58:      	mov	w9, #0x4                ; =4
    9e5c:      	b	0x9cd4 <_stogir.verify.structure+0x294>
    9e60:      	ubfx	x23, x23, #0, #32
    9e64:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009e64:  ARM64_RELOC_PAGE21	l_stogir.462
    9e68:      	ldr	x16, [x16]
		0000000000009e68:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    9e6c:      	ldr	w0, [x16]
    9e70:      	cmp	x23, x0
    9e74:      	b.ne	0x9e88 <_stogir.verify.structure+0x448>
    9e78:      	mov	x0, #0x1                ; =1
    9e7c:      	b	0x9ea0 <_stogir.verify.structure+0x460>
    9e80:      	movz	x1, #0x0, lsl #48
    9e84:      	b	0x9f00 <_stogir.verify.structure+0x4c0>
    9e88:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009e88:  ARM64_RELOC_PAGE21	l_stogir.463
    9e8c:      	ldr	x16, [x16]
		0000000000009e8c:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    9e90:      	ldr	w0, [x16]
    9e94:      	cmp	x23, x0
    9e98:      	cset	w0, eq
    9e9c:      	ubfx	x0, x0, #0, #8
    9ea0:      	cmp	x0, #0x0
    9ea4:      	b.eq	0xa3c8 <_stogir.verify.structure+0x988>
    9ea8:      	str	w24, [sp, #0xa8]
    9eac:      	mov	x24, x0
    9eb0:      	mov	x0, x20
    9eb4:      	str	w21, [sp, #0xb0]
    9eb8:      	mov	w21, w1
    9ebc:      	bl	0x9ebc <_stogir.verify.structure+0x47c>
		0000000000009ebc:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    9ec0:      	cmp	x0, #0x0
    9ec4:      	cset	w1, eq
    9ec8:      	uxtb	w16, w1
    9ecc:      	cmp	w16, wzr
    9ed0:      	cset	x1, eq
    9ed4:      	cmp	x1, #0x0
    9ed8:      	b.eq	0x9f00 <_stogir.verify.structure+0x4c0>
    9edc:      	ldr	w0, [x0]
    9ee0:      	uxtb	w0, w0
    9ee4:      	cmp	x0, #0x48
    9ee8:      	b.ne	0x9f00 <_stogir.verify.structure+0x4c0>
    9eec:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009eec:  ARM64_RELOC_PAGE21	l_stogir.464
    9ef0:      	ldr	x16, [x16]
		0000000000009ef0:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    9ef4:      	str	x16, [sp, #0x38]
    9ef8:      	mov	x16, #0x25              ; =37
    9efc:      	str	x16, [sp, #0x80]
    9f00:      	sxtw	x21, w21
    9f04:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009f04:  ARM64_RELOC_PAGE21	l_stogir.465
    9f08:      	ldr	x16, [x16]
		0000000000009f08:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    9f0c:      	ldr	w0, [x16]
    9f10:      	cmp	x23, x0
    9f14:      	b.ne	0xa3dc <_stogir.verify.structure+0x99c>
    9f18:      	cmp	x21, #0x0
    9f1c:      	b.gt	0xa0ac <_stogir.verify.structure+0x66c>
    9f20:      	ldr	x2, [sp, #0x60]
    9f24:      	movz	w0, #0x0, lsl #16
    9f28:      	ubfx	x0, x0, #0, #32
    9f2c:      	lsr	x16, x0, #0
    9f30:      	cmp	x16, #0x1
    9f34:      	b.eq	0x9f50 <_stogir.verify.structure+0x510>
    9f38:      	b.lo	0x9f40 <_stogir.verify.structure+0x500>
    9f3c:      	b	0x9f54 <_stogir.verify.structure+0x514>
    9f40:      	cmp	x16, #0x0
    9f44:      	b.eq	0x9f4c <_stogir.verify.structure+0x50c>
    9f48:      	b	0x9f54 <_stogir.verify.structure+0x514>
    9f4c:      	b	0x9f58 <_stogir.verify.structure+0x518>
    9f50:      	b	0x9f6c <_stogir.verify.structure+0x52c>
    9f54:      	b	0xa314 <_stogir.verify.structure+0x8d4>
    9f58:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009f58:  ARM64_RELOC_PAGE21	l_stogir.466
    9f5c:      	ldr	x16, [x16]
		0000000000009f5c:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    9f60:      	str	x16, [sp, #0x38]
    9f64:      	mov	x16, #0x21              ; =33
    9f68:      	str	x16, [sp, #0x80]
    9f6c:      	cmp	x23, #0xf
    9f70:      	b.hs	0xa3e4 <_stogir.verify.structure+0x9a4>
    9f74:      	mov	x16, #0x1               ; =1
    9f78:      	lsl	x0, x16, x23
    9f7c:      	mov	w17, #0x5e1c            ; =24092
    9f80:      	and	w0, w0, w17
    9f84:      	ubfx	x0, x0, #0, #32
    9f88:      	cmp	x0, #0x0
    9f8c:      	b.eq	0xa3fc <_stogir.verify.structure+0x9bc>
    9f90:      	cmp	x24, #0x0
    9f94:      	b.eq	0xa198 <_stogir.verify.structure+0x758>
    9f98:      	ldr	x0, [sp, #0x58]
    9f9c:      	ldr	x3, [sp, #0x50]
    9fa0:      	ldr	x4, [sp, #0x48]
    9fa4:      	b	0x9cec <_stogir.verify.structure+0x2ac>
    9fa8:      	orr	w0, w28, wzr
    9fac:      	cmp	x26, #0x78
    9fb0:      	cset	w21, eq
    9fb4:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009fb4:  ARM64_RELOC_PAGE21	l_stogir.467
    9fb8:      	ldr	x16, [x16]
		0000000000009fb8:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    9fbc:      	add	x1, x16, x26, lsl #2
    9fc0:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x270>
		0000000000009fc0:  ARM64_RELOC_PAGE21	l_stogir.467
    9fc4:      	ldr	x16, [x16]
		0000000000009fc4:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    9fc8:      	add	x2, x16, x26, lsl #2
    9fcc:      	cmp	x24, #0x0
    9fd0:      	cset	w24, eq
    9fd4:      	orr	x26, x1, xzr
    9fd8:      	orr	x1, x2, xzr
    9fdc:      	mov	x2, #0x1                ; =1
    9fe0:      	b	0x9df0 <_stogir.verify.structure+0x3b0>
    9fe4:      	nop
    9fe8:      	movz	x1, #0x0, lsl #48
    9fec:      	cmp	x1, #0x0
    9ff0:      	b.eq	0x9fa8 <_stogir.verify.structure+0x568>
    9ff4:      	add	x1, x0, x28
    9ff8:      	ldr	x2, [x20, #0x78]
    9ffc:      	add	x1, x2, x1, lsl #2
    a000:      	ldr	w1, [x1]
    a004:      	sxtw	x1, w1
    a008:      	cmn	x1, #0x1
    a00c:      	b.eq	0xa020 <_stogir.verify.structure+0x5e0>
    a010:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a010:  ARM64_RELOC_PAGE21	l_stogir.468
    a014:      	ldr	x16, [x16]
		000000000000a014:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    a018:      	str	x16, [sp, #0x38]
    a01c:      	mov	x23, #0x1b              ; =27
    a020:      	add	x0, x0, #0x1
    a024:      	cmp	x23, #0x0
    a028:      	b.ne	0x9fe8 <_stogir.verify.structure+0x5a8>
    a02c:      	cmp	x0, x19
    a030:      	cset	w1, lt
    a034:      	ubfx	x1, x1, #0, #8
    a038:      	b	0x9fec <_stogir.verify.structure+0x5ac>
    a03c:      	mov	w0, w19
    a040:      	bl	0xa040 <_stogir.verify.structure+0x600>
		000000000000a040:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
    a044:      	sxtw	x0, w0
    a048:      	cmn	x0, #0x1
    a04c:      	b.ne	0xa06c <_stogir.verify.structure+0x62c>
    a050:      	ubfx	x0, x21, #16, #16
    a054:      	cmp	x22, x0
    a058:      	b.eq	0xa06c <_stogir.verify.structure+0x62c>
    a05c:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a05c:  ARM64_RELOC_PAGE21	l_stogir.469
    a060:      	ldr	x16, [x16]
		000000000000a060:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a064:      	str	x16, [sp, #0x38]
    a068:      	mov	x23, #0x24              ; =36
    a06c:      	add	x0, x22, #0x4
    a070:      	ldr	x1, [x20, #0x8]
    a074:      	asr	x16, x0, #63
    a078:      	lsr	x16, x16, #62
    a07c:      	add	x0, x0, x16
    a080:      	asr	x0, x0, #2
    a084:      	orr	x19, x0, xzr
    a088:      	add	x0, x19, x28
    a08c:      	cmp	x0, x1
    a090:      	b.le	0xa0a4 <_stogir.verify.structure+0x664>
    a094:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a094:  ARM64_RELOC_PAGE21	l_stogir.470
    a098:      	ldr	x16, [x16]
		000000000000a098:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    a09c:      	str	x16, [sp, #0x38]
    a0a0:      	mov	x23, #0x15              ; =21
    a0a4:      	mov	x0, #0x1                ; =1
    a0a8:      	b	0xa024 <_stogir.verify.structure+0x5e4>
    a0ac:      	ldr	x0, [x27, #0x8]
    a0b0:      	cmp	x21, x0
    a0b4:      	b.gt	0xa414 <_stogir.verify.structure+0x9d4>
    a0b8:      	sub	x0, x21, #0x1
    a0bc:      	ldr	x2, [sp, #0x60]
    a0c0:      	ldr	x3, [x2, #0x28]
    a0c4:      	mov	x17, #0x18              ; =24
    a0c8:      	mul	x0, x0, x17
    a0cc:      	add	x0, x0, x3
    a0d0:      	ldr	x3, [x0]
    a0d4:      	ldr	x0, [x0, #0x8]
    a0d8:      	ldr	x4, [x2, #0x8]
    a0dc:      	cmp	x3, #0x0
    a0e0:      	b.lt	0xa108 <_stogir.verify.structure+0x6c8>
    a0e4:      	cmp	x3, x4
    a0e8:      	b.gt	0xa108 <_stogir.verify.structure+0x6c8>
    a0ec:      	cmp	x0, #0x0
    a0f0:      	b.lt	0xa108 <_stogir.verify.structure+0x6c8>
    a0f4:      	sub	x3, x4, x3
    a0f8:      	cmp	x0, x3
    a0fc:      	b.gt	0xa108 <_stogir.verify.structure+0x6c8>
    a100:      	mov	w0, #0x1                ; =1
    a104:      	b	0xa10c <_stogir.verify.structure+0x6cc>
    a108:      	movz	w0, #0x0, lsl #16
    a10c:      	b	0x9f28 <_stogir.verify.structure+0x4e8>
    a110:      	mov	w0, #-0x2               ; =-2
    a114:      	sxtw	x0, w0
    a118:      	cmp	x22, x0
    a11c:      	b.eq	0xa03c <_stogir.verify.structure+0x5fc>
    a120:      	ldr	x0, [sp, #0x58]
    a124:      	ldr	x2, [sp, #0x60]
    a128:      	ldr	x3, [sp, #0x50]
    a12c:      	ldr	x4, [sp, #0x48]
    a130:      	mov	x5, x28
    a134:      	ldr	x19, [sp, #0x40]
    a138:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a138:  ARM64_RELOC_PAGE21	l_stogir.471
    a13c:      	ldr	x16, [x16]
		000000000000a13c:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    a140:      	str	x16, [sp, #0x38]
    a144:      	mov	x16, #0x23              ; =35
    a148:      	str	x16, [sp, #0x80]
    a14c:      	b	0x9ac4 <_stogir.verify.structure+0x84>
    a150:      	cmp	x21, #0x0
    a154:      	b.ne	0xa41c <_stogir.verify.structure+0x9dc>
    a158:      	uxtb	w16, w25
    a15c:      	cmp	w16, wzr
    a160:      	b.eq	0xa28c <_stogir.verify.structure+0x84c>
    a164:      	ldr	w1, [x22]
    a168:      	uxtb	w16, w28
    a16c:      	cmp	w16, wzr
    a170:      	b.eq	0xa2d4 <_stogir.verify.structure+0x894>
    a174:      	uxtb	w16, w26
    a178:      	cmp	w16, wzr
    a17c:      	b.eq	0xa184 <_stogir.verify.structure+0x744>
    a180:      	mov	w19, #0x4               ; =4
    a184:      	lsl	w5, w19, #2
    a188:      	ubfx	x5, x5, #0, #32
    a18c:      	lsr	x1, x1, x5
    a190:      	and	w1, w1, #0xf
    a194:      	b	0xa2d8 <_stogir.verify.structure+0x898>
    a198:      	cmp	x21, #0x0
    a19c:      	b.le	0xa428 <_stogir.verify.structure+0x9e8>
    a1a0:      	ldr	x0, [x20, #0x8]
    a1a4:      	cmp	x21, x0
    a1a8:      	b.ge	0xa430 <_stogir.verify.structure+0x9f0>
    a1ac:      	ldr	x0, [sp, #0x58]
    a1b0:      	ldr	x1, [x0, #0x8]
    a1b4:      	cmp	x21, x1
    a1b8:      	b.ge	0xa2e4 <_stogir.verify.structure+0x8a4>
    a1bc:      	ldr	x1, [x20, #0x78]
    a1c0:      	add	x1, x1, x21, lsl #2
    a1c4:      	ldr	w1, [x1]
    a1c8:      	sxtw	x1, w1
    a1cc:      	cmp	x1, #0x0
    a1d0:      	cset	w1, ge
    a1d4:      	ubfx	x1, x1, #0, #8
    a1d8:      	b	0xa2e8 <_stogir.verify.structure+0x8a8>
    a1dc:      	ldr	w1, [sp, #0xb0]
    a1e0:      	uxtb	w16, w1
    a1e4:      	cmp	w16, wzr
    a1e8:      	b.eq	0xa438 <_stogir.verify.structure+0x9f8>
    a1ec:      	ldr	w5, [sp, #0xa8]
    a1f0:      	uxtb	w16, w5
    a1f4:      	cmp	w16, wzr
    a1f8:      	b.eq	0xa208 <_stogir.verify.structure+0x7c8>
    a1fc:      	ldr	x6, [sp, #0xa0]
    a200:      	cmp	x6, #0x2
    a204:      	b.eq	0x9cfc <_stogir.verify.structure+0x2bc>
    a208:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a208:  ARM64_RELOC_PAGE21	l_stogir.472
    a20c:      	ldr	x16, [x16]
		000000000000a20c:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    a210:      	str	x16, [sp, #0x38]
    a214:      	mov	x16, #0x1a              ; =26
    a218:      	str	x16, [sp, #0x80]
    a21c:      	b	0x9cfc <_stogir.verify.structure+0x2bc>
    a220:      	movz	x1, #0x0, lsl #48
    a224:      	ldr	x3, [sp, #0x50]
    a228:      	ldr	x4, [sp, #0x48]
    a22c:      	b	0x9cec <_stogir.verify.structure+0x2ac>
    a230:      	cmp	x21, #0x0
    a234:      	b.ge	0xa440 <_stogir.verify.structure+0xa00>
    a238:      	ldr	x3, [sp, #0x50]
    a23c:      	ldr	x1, [x3, #0x8]
    a240:      	ldr	x4, [sp, #0x48]
    a244:      	ldr	x5, [x4, #0x8]
    a248:      	cmp	x1, x5
    a24c:      	b.ne	0xa2dc <_stogir.verify.structure+0x89c>
    a250:      	movz	x16, #0x0, lsl #48
    a254:      	sub	x5, x16, x21
    a258:      	cmp	x5, x1
    a25c:      	b.gt	0xa30c <_stogir.verify.structure+0x8cc>
    a260:      	sub	x1, x5, #0x1
    a264:      	ldr	x5, [x20, #0x50]
    a268:      	add	x1, x5, x1, lsl #2
    a26c:      	ldr	w1, [x1]
    a270:      	sxtw	x1, w1
    a274:      	cmp	x1, #0x0
    a278:      	cset	w1, gt
    a27c:      	ubfx	x1, x1, #0, #8
    a280:      	b	0xa310 <_stogir.verify.structure+0x8d0>
    a284:      	brk	#0
    a288:      	b	0xa284 <_stogir.verify.structure+0x844>
    a28c:      	movz	w1, #0x0, lsl #16
    a290:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a290:  ARM64_RELOC_PAGE21	l_stogir.473
    a294:      	ldr	x16, [x16]
		000000000000a294:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    a298:      	ldr	w5, [x16]
    a29c:      	ubfx	x1, x1, #0, #32
    a2a0:      	cmp	x1, x5
    a2a4:      	b.ne	0xa2b4 <_stogir.verify.structure+0x874>
    a2a8:      	ldr	w1, [sp, #0xb0]
    a2ac:      	ldr	w5, [sp, #0xa8]
    a2b0:      	b	0x9cfc <_stogir.verify.structure+0x2bc>
    a2b4:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a2b4:  ARM64_RELOC_PAGE21	l_stogir.474
    a2b8:      	ldr	x16, [x16]
		000000000000a2b8:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    a2bc:      	ldr	w5, [x16]
    a2c0:      	cmp	x1, x5
    a2c4:      	b.ne	0xa2ec <_stogir.verify.structure+0x8ac>
    a2c8:      	ldr	w1, [sp, #0xb0]
    a2cc:      	ldr	w5, [sp, #0xa8]
    a2d0:      	b	0x9cfc <_stogir.verify.structure+0x2bc>
    a2d4:      	movz	w1, #0x0, lsl #16
    a2d8:      	b	0xa290 <_stogir.verify.structure+0x850>
    a2dc:      	movz	x1, #0x0, lsl #48
    a2e0:      	b	0x9cec <_stogir.verify.structure+0x2ac>
    a2e4:      	movz	x1, #0x0, lsl #48
    a2e8:      	b	0xa224 <_stogir.verify.structure+0x7e4>
    a2ec:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a2ec:  ARM64_RELOC_PAGE21	l_stogir.475
    a2f0:      	ldr	x16, [x16]
		000000000000a2f0:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    a2f4:      	ldr	w5, [x16]
    a2f8:      	cmp	x1, x5
    a2fc:      	b.ne	0xa1dc <_stogir.verify.structure+0x79c>
    a300:      	ldr	w1, [sp, #0xb0]
    a304:      	ldr	w5, [sp, #0xa8]
    a308:      	b	0x9cfc <_stogir.verify.structure+0x2bc>
    a30c:      	movz	x1, #0x0, lsl #48
    a310:      	b	0xa2e0 <_stogir.verify.structure+0x8a0>
    a314:      	brk	#0
    a318:      	b	0xa314 <_stogir.verify.structure+0x8d4>
    a31c:      	str	x19, [sp, #0x30]
    a320:      	mov	x19, x0
    a324:      	str	x22, [sp, #0x38]
    a328:      	str	x23, [sp, #0x80]
    a32c:      	b	0x9c4c <_stogir.verify.structure+0x20c>
    a330:      	str	x19, [sp, #0x30]
    a334:      	mov	x19, x0
    a338:      	str	x22, [sp, #0x38]
    a33c:      	str	x23, [sp, #0x80]
    a340:      	b	0x9c4c <_stogir.verify.structure+0x20c>
    a344:      	mov	x5, x28
    a348:      	str	x19, [sp, #0x30]
    a34c:      	mov	x19, x0
    a350:      	mov	x0, x21
    a354:      	mov	x2, x24
    a358:      	mov	x3, x25
    a35c:      	mov	x4, x26
    a360:      	b	0x9b24 <_stogir.verify.structure+0xe4>
    a364:      	mov	x5, x28
    a368:      	str	x19, [sp, #0x30]
    a36c:      	mov	x19, x0
    a370:      	mov	x0, x21
    a374:      	mov	x2, x24
    a378:      	mov	x3, x25
    a37c:      	mov	x4, x26
    a380:      	b	0x9af0 <_stogir.verify.structure+0xb0>
    a384:      	mov	x5, x28
    a388:      	ldr	x19, [sp, #0x40]
    a38c:      	ldr	x0, [sp, #0x58]
    a390:      	ldr	x2, [sp, #0x60]
    a394:      	ldr	x3, [sp, #0x50]
    a398:      	ldr	x4, [sp, #0x48]
    a39c:      	b	0x9af0 <_stogir.verify.structure+0xb0>
    a3a0:      	ldr	x0, [sp, #0x38]
    a3a4:      	b	0x9c80 <_stogir.verify.structure+0x240>
    a3a8:      	str	x28, [sp, #0x90]
    a3ac:      	ldr	x0, [sp, #0x58]
    a3b0:      	str	x19, [sp, #0x88]
    a3b4:      	ldr	x2, [sp, #0x60]
    a3b8:      	str	x23, [sp, #0x80]
    a3bc:      	ldr	x3, [sp, #0x50]
    a3c0:      	ldr	x4, [sp, #0x48]
    a3c4:      	b	0x9aac <_stogir.verify.structure+0x6c>
    a3c8:      	str	w21, [sp, #0xb0]
    a3cc:      	mov	w21, w1
    a3d0:      	str	w24, [sp, #0xa8]
    a3d4:      	mov	x24, x0
    a3d8:      	b	0x9e80 <_stogir.verify.structure+0x440>
    a3dc:      	ldr	x2, [sp, #0x60]
    a3e0:      	b	0x9f6c <_stogir.verify.structure+0x52c>
    a3e4:      	ldr	x0, [sp, #0x58]
    a3e8:      	ldr	w1, [sp, #0xb0]
    a3ec:      	ldr	w5, [sp, #0xa8]
    a3f0:      	ldr	x3, [sp, #0x50]
    a3f4:      	ldr	x4, [sp, #0x48]
    a3f8:      	b	0x9cfc <_stogir.verify.structure+0x2bc>
    a3fc:      	ldr	x0, [sp, #0x58]
    a400:      	ldr	w1, [sp, #0xb0]
    a404:      	ldr	w5, [sp, #0xa8]
    a408:      	ldr	x3, [sp, #0x50]
    a40c:      	ldr	x4, [sp, #0x48]
    a410:      	b	0x9cfc <_stogir.verify.structure+0x2bc>
    a414:      	ldr	x2, [sp, #0x60]
    a418:      	b	0x9f24 <_stogir.verify.structure+0x4e4>
    a41c:      	ldr	w1, [sp, #0xb0]
    a420:      	ldr	w5, [sp, #0xa8]
    a424:      	b	0xa208 <_stogir.verify.structure+0x7c8>
    a428:      	ldr	x0, [sp, #0x58]
    a42c:      	b	0xa230 <_stogir.verify.structure+0x7f0>
    a430:      	ldr	x0, [sp, #0x58]
    a434:      	b	0xa220 <_stogir.verify.structure+0x7e0>
    a438:      	ldr	w5, [sp, #0xa8]
    a43c:      	b	0xa208 <_stogir.verify.structure+0x7c8>
    a440:      	ldr	x3, [sp, #0x50]
    a444:      	ldr	x4, [sp, #0x48]
    a448:      	b	0x9ce8 <_stogir.verify.structure+0x2a8>
    a44c:      	udf	#0x0

000000000000a450 <_stogir.verify.schedule-input-structured>:
    a450:      	sub	sp, sp, #0x40
    a454:      	str	x29, [sp]
    a458:      	str	x30, [sp, #0x8]
    a45c:      	mov	x29, sp
    a460:      	str	x19, [sp, #0x30]
    a464:      	sxtw	x1, w1
    a468:      	add	x4, x0, #0x28
    a46c:      	add	x5, x0, #0x78
    a470:      	cmp	x1, #0x0
    a474:      	cset	w6, gt
    a478:      	movz	x16, #0x0, lsl #48
    a47c:      	sub	x7, x16, x1
    a480:      	sub	x9, x7, #0x1
    a484:      	uxtb	w16, w6
    a488:      	cmp	w16, wzr
    a48c:      	b.eq	0xa4c8 <_stogir.verify.schedule-input-structured+0x78>
    a490:      	ldr	x4, [x0, #0x8]
    a494:      	cmp	x1, x4
    a498:      	b.ge	0xa514 <_stogir.verify.schedule-input-structured+0xc4>
    a49c:      	ldr	x4, [x5, #0x8]
    a4a0:      	cmp	x1, x4
    a4a4:      	b.ge	0xa6ec <_stogir.verify.schedule-input-structured+0x29c>
    a4a8:      	ldr	x4, [x0, #0x78]
    a4ac:      	add	x4, x4, x1, lsl #2
    a4b0:      	ldr	w4, [x4]
    a4b4:      	sxtw	x4, w4
    a4b8:      	cmp	x4, #0x0
    a4bc:      	cset	w4, ge
    a4c0:      	ubfx	x4, x4, #0, #8
    a4c4:      	b	0xa6f0 <_stogir.verify.schedule-input-structured+0x2a0>
    a4c8:      	cmp	x1, #0x0
    a4cc:      	b.ge	0xa51c <_stogir.verify.schedule-input-structured+0xcc>
    a4d0:      	add	x10, x0, #0x50
    a4d4:      	ldr	x4, [x4, #0x8]
    a4d8:      	ldr	x10, [x10, #0x8]
    a4dc:      	cmp	x4, x10
    a4e0:      	b.ne	0xa50c <_stogir.verify.schedule-input-structured+0xbc>
    a4e4:      	cmp	x7, x4
    a4e8:      	b.gt	0xa6f4 <_stogir.verify.schedule-input-structured+0x2a4>
    a4ec:      	ldr	x4, [x0, #0x50]
    a4f0:      	add	x4, x4, x9, lsl #2
    a4f4:      	ldr	w4, [x4]
    a4f8:      	sxtw	x4, w4
    a4fc:      	cmp	x4, #0x0
    a500:      	cset	w4, gt
    a504:      	ubfx	x4, x4, #0, #8
    a508:      	b	0xa6f8 <_stogir.verify.schedule-input-structured+0x2a8>
    a50c:      	movz	x4, #0x0, lsl #48
    a510:      	b	0xa520 <_stogir.verify.schedule-input-structured+0xd0>
    a514:      	movz	x4, #0x0, lsl #48
    a518:      	b	0xa520 <_stogir.verify.schedule-input-structured+0xd0>
    a51c:      	movz	x4, #0x0, lsl #48
    a520:      	cmp	x4, #0x0
    a524:      	b.eq	0xa558 <_stogir.verify.schedule-input-structured+0x108>
    a528:      	uxtb	w16, w6
    a52c:      	cmp	w16, wzr
    a530:      	b.eq	0xa544 <_stogir.verify.schedule-input-structured+0xf4>
    a534:      	ldr	x4, [x0]
    a538:      	add	x4, x4, x1, lsl #4
    a53c:      	ldr	x4, [x4]
    a540:      	b	0xa550 <_stogir.verify.schedule-input-structured+0x100>
    a544:      	ldr	x4, [x0, #0x28]
    a548:      	add	x4, x4, x9, lsl #4
    a54c:      	ldr	x4, [x4]
    a550:      	mov	w6, #0x1                ; =1
    a554:      	b	0xa560 <_stogir.verify.schedule-input-structured+0x110>
    a558:      	movz	w6, #0x0, lsl #16
    a55c:      	movz	x4, #0x0, lsl #48
    a560:      	ubfx	x6, x6, #0, #32
    a564:      	lsr	x16, x6, #0
    a568:      	cmp	x16, #0x1
    a56c:      	b.eq	0xa588 <_stogir.verify.schedule-input-structured+0x138>
    a570:      	b.lo	0xa578 <_stogir.verify.schedule-input-structured+0x128>
    a574:      	b	0xa58c <_stogir.verify.schedule-input-structured+0x13c>
    a578:      	cmp	x16, #0x0
    a57c:      	b.eq	0xa584 <_stogir.verify.schedule-input-structured+0x134>
    a580:      	b	0xa58c <_stogir.verify.schedule-input-structured+0x13c>
    a584:      	b	0xa590 <_stogir.verify.schedule-input-structured+0x140>
    a588:      	b	0xa6c4 <_stogir.verify.schedule-input-structured+0x274>
    a58c:      	b	0xa744 <_stogir.verify.schedule-input-structured+0x2f4>
    a590:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a590:  ARM64_RELOC_PAGE21	l_stogir.476
    a594:      	ldr	x1, [x1]
		000000000000a594:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    a598:      	mov	x4, #0xd                ; =13
    a59c:      	b	0xa5ac <_stogir.verify.schedule-input-structured+0x15c>
    a5a0:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a5a0:  ARM64_RELOC_PAGE21	l_stogir.477
    a5a4:      	ldr	x1, [x1]
		000000000000a5a4:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    a5a8:      	mov	x4, #0x1b               ; =27
    a5ac:      	cmp	x3, #0x0
    a5b0:      	b.ne	0xa5c0 <_stogir.verify.schedule-input-structured+0x170>
    a5b4:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a5b4:  ARM64_RELOC_PAGE21	l_stogir.478
    a5b8:      	ldr	x1, [x1]
		000000000000a5b8:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    a5bc:      	mov	x4, #0x25               ; =37
    a5c0:      	movz	x6, #0x0, lsl #48
    a5c4:      	b	0xa648 <_stogir.verify.schedule-input-structured+0x1f8>
    a5c8:      	movz	w7, #0x0, lsl #16
    a5cc:      	movz	w9, #0x0, lsl #16
    a5d0:      	ubfx	x7, x7, #0, #32
    a5d4:      	lsr	x16, x7, #0
    a5d8:      	cmp	x16, #0x1
    a5dc:      	b.eq	0xa5f8 <_stogir.verify.schedule-input-structured+0x1a8>
    a5e0:      	b.lo	0xa5e8 <_stogir.verify.schedule-input-structured+0x198>
    a5e4:      	b	0xa5fc <_stogir.verify.schedule-input-structured+0x1ac>
    a5e8:      	cmp	x16, #0x0
    a5ec:      	b.eq	0xa5f4 <_stogir.verify.schedule-input-structured+0x1a4>
    a5f0:      	b	0xa5fc <_stogir.verify.schedule-input-structured+0x1ac>
    a5f4:      	b	0xa670 <_stogir.verify.schedule-input-structured+0x220>
    a5f8:      	b	0xa600 <_stogir.verify.schedule-input-structured+0x1b0>
    a5fc:      	b	0xa73c <_stogir.verify.schedule-input-structured+0x2ec>
    a600:      	sxtw	x9, w9
    a604:      	cmp	x9, #0x0
    a608:      	b.le	0xa63c <_stogir.verify.schedule-input-structured+0x1ec>
    a60c:      	ldr	x7, [x0, #0x8]
    a610:      	cmp	x9, x7
    a614:      	b.ge	0xa63c <_stogir.verify.schedule-input-structured+0x1ec>
    a618:      	ldr	x7, [x5, #0x8]
    a61c:      	cmp	x9, x7
    a620:      	b.ge	0xa63c <_stogir.verify.schedule-input-structured+0x1ec>
    a624:      	ldr	x7, [x0, #0x78]
    a628:      	add	x7, x7, x9, lsl #2
    a62c:      	ldr	w7, [x7]
    a630:      	sxtw	x7, w7
    a634:      	cmp	x7, #0x0
    a638:      	b.ge	0xa648 <_stogir.verify.schedule-input-structured+0x1f8>
    a63c:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a63c:  ARM64_RELOC_PAGE21	l_stogir.479
    a640:      	ldr	x1, [x1]
		000000000000a640:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    a644:      	mov	x4, #0x16               ; =22
    a648:      	cmp	x6, x3
    a64c:      	b.ge	0xa5c8 <_stogir.verify.schedule-input-structured+0x178>
    a650:      	add	x7, x6, #0x1
    a654:      	add	x6, x2, x6, lsl #2
    a658:      	ldr	w6, [x6]
    a65c:      	movn	w17, #0x0, lsl #16
    a660:      	and	w9, w6, w17
    a664:      	mov	x6, x7
    a668:      	mov	w7, #0x1                ; =1
    a66c:      	b	0xa5d0 <_stogir.verify.schedule-input-structured+0x180>
    a670:      	cmp	x4, #0x0
    a674:      	b.ne	0xa74c <_stogir.verify.schedule-input-structured+0x2fc>
    a678:      	mov	x19, x8
    a67c:      	add	x8, sp, #0x10
    a680:      	bl	0xa680 <_stogir.verify.schedule-input-structured+0x230>
		000000000000a680:  ARM64_RELOC_BRANCH26	_stogir.verify.phis-structured
    a684:      	add	x16, sp, #0x10
    a688:      	ldr	x0, [x16]
    a68c:      	add	x16, sp, #0x10
    a690:      	ldr	x1, [x16, #0x8]
    a694:      	add	x16, sp, #0x10
    a698:      	ldr	x4, [x16, #0x10]
    a69c:      	b	0xa6a4 <_stogir.verify.schedule-input-structured+0x254>
    a6a0:      	mov	x0, #0x1                ; =1
    a6a4:      	str	x0, [x19]
    a6a8:      	str	x1, [x19, #0x8]
    a6ac:      	str	x4, [x19, #0x10]
    a6b0:      	ldr	x19, [sp, #0x30]
    a6b4:      	ldr	x29, [sp]
    a6b8:      	ldr	x30, [sp, #0x8]
    a6bc:      	add	sp, sp, #0x40
    a6c0:      	ret
    a6c4:      	cmp	x1, #0x0
    a6c8:      	b.le	0xa5a0 <_stogir.verify.schedule-input-structured+0x150>
    a6cc:      	uxtb	w4, w4
    a6d0:      	cmp	x4, #0x83
    a6d4:      	b.ge	0xa6fc <_stogir.verify.schedule-input-structured+0x2ac>
    a6d8:      	adrp	x17, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a6d8:  ARM64_RELOC_PAGE21	l_stogir.480
    a6dc:      	ldr	x17, [x17]
		000000000000a6dc:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    a6e0:      	add	x1, x4, x17
    a6e4:      	ldrb	w1, [x1]
    a6e8:      	b	0xa700 <_stogir.verify.schedule-input-structured+0x2b0>
    a6ec:      	movz	x4, #0x0, lsl #48
    a6f0:      	b	0xa518 <_stogir.verify.schedule-input-structured+0xc8>
    a6f4:      	movz	x4, #0x0, lsl #48
    a6f8:      	b	0xa510 <_stogir.verify.schedule-input-structured+0xc0>
    a6fc:      	movz	w1, #0x0, lsl #16
    a700:      	uxtb	w16, w1
    a704:      	and	w1, w16, #0x2
    a708:      	uxtb	w1, w1
    a70c:      	ubfx	x1, x1, #0, #8
    a710:      	cmp	x1, #0x0
    a714:      	cset	w1, eq
    a718:      	uxtb	w16, w1
    a71c:      	cmp	w16, wzr
    a720:      	cset	x1, eq
    a724:      	cmp	x1, #0x0
    a728:      	b.eq	0xa5a0 <_stogir.verify.schedule-input-structured+0x150>
    a72c:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a72c:  ARM64_RELOC_PAGE21	l_stogir.481
    a730:      	ldr	x1, [x1]
		000000000000a730:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    a734:      	movz	x4, #0x0, lsl #48
    a738:      	b	0xa5ac <_stogir.verify.schedule-input-structured+0x15c>
    a73c:      	brk	#0
    a740:      	b	0xa73c <_stogir.verify.schedule-input-structured+0x2ec>
    a744:      	brk	#0
    a748:      	b	0xa744 <_stogir.verify.schedule-input-structured+0x2f4>
    a74c:      	mov	x19, x8
    a750:      	b	0xa6a0 <_stogir.verify.schedule-input-structured+0x250>

000000000000a754 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
    a754:      	ldr	x0, [x0, #0x8]
    a758:      	ret

000000000000a75c <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    a75c:      	ldr	x0, [x0, #0x8]
    a760:      	ret

000000000000a764 <_stogir.verify.control-sources>:
    a764:      	sub	sp, sp, #0x40
    a768:      	str	x29, [sp]
    a76c:      	str	x30, [sp, #0x8]
    a770:      	mov	x29, sp
    a774:      	str	x19, [sp, #0x30]
    a778:      	str	x20, [sp, #0x38]
    a77c:      	mov	x19, x8
    a780:      	add	x8, sp, #0x10
    a784:      	mov	x20, x0
    a788:      	bl	0xa788 <_stogir.verify.control-sources+0x24>
		000000000000a788:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    a78c:      	add	x16, sp, #0x10
    a790:      	ldr	w0, [x16]
    a794:      	lsr	x16, x0, #0
    a798:      	cmp	x16, #0x1
    a79c:      	b.eq	0xa7b8 <_stogir.verify.control-sources+0x54>
    a7a0:      	b.lo	0xa7a8 <_stogir.verify.control-sources+0x44>
    a7a4:      	b	0xa7bc <_stogir.verify.control-sources+0x58>
    a7a8:      	cmp	x16, #0x0
    a7ac:      	b.eq	0xa7b4 <_stogir.verify.control-sources+0x50>
    a7b0:      	b	0xa7bc <_stogir.verify.control-sources+0x58>
    a7b4:      	b	0xa808 <_stogir.verify.control-sources+0xa4>
    a7b8:      	b	0xa7c0 <_stogir.verify.control-sources+0x5c>
    a7bc:      	b	0xabc0 <_stogir.verify.control-sources+0x45c>
    a7c0:      	add	x16, sp, #0x10
    a7c4:      	orr	x0, x16, xzr
    a7c8:      	add	x0, x0, #0x8
    a7cc:      	add	x16, sp, #0x10
    a7d0:      	ldr	x1, [x16, #0x8]
    a7d4:      	ldr	x0, [x0, #0x8]
    a7d8:      	mov	x2, #0x1                ; =1
    a7dc:      	b	0xa7e4 <_stogir.verify.control-sources+0x80>
    a7e0:      	mov	x2, #0x1                ; =1
    a7e4:      	str	x2, [x19]
    a7e8:      	str	x1, [x19, #0x8]
    a7ec:      	str	x0, [x19, #0x10]
    a7f0:      	ldr	x19, [sp, #0x30]
    a7f4:      	ldr	x20, [sp, #0x38]
    a7f8:      	ldr	x29, [sp]
    a7fc:      	ldr	x30, [sp, #0x8]
    a800:      	add	sp, sp, #0x40
    a804:      	ret
    a808:      	add	x2, x20, #0x78
    a80c:      	mov	x3, #0x1                ; =1
    a810:      	movz	x4, #0x0, lsl #48
    a814:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a814:  ARM64_RELOC_PAGE21	l_stogir.482
    a818:      	ldr	x1, [x1]
		000000000000a818:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    a81c:      	movz	x0, #0x0, lsl #48
    a820:      	b	0xaa90 <_stogir.verify.control-sources+0x32c>
    a824:      	movz	w12, #0x0, lsl #16
    a828:      	uxtb	w16, w12
    a82c:      	and	w12, w16, #0x1
    a830:      	uxtb	w12, w12
    a834:      	ubfx	x12, x12, #0, #8
    a838:      	cmp	x12, #0x0
    a83c:      	b.ne	0xa84c <_stogir.verify.control-sources+0xe8>
    a840:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a840:  ARM64_RELOC_PAGE21	l_stogir.483
    a844:      	ldr	x1, [x1]
		000000000000a844:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    a848:      	mov	x0, #0x1d               ; =29
    a84c:      	b	0xa9f8 <_stogir.verify.control-sources+0x294>
    a850:      	movz	x5, #0x0, lsl #48
    a854:      	cmp	x5, #0x0
    a858:      	b.eq	0xab98 <_stogir.verify.control-sources+0x434>
    a85c:      	orr	w5, w3, wzr
    a860:      	ldr	x6, [x20]
    a864:      	sxtw	x5, w5
    a868:      	cmp	x5, #0x0
    a86c:      	cset	w7, le
    a870:      	lsl	x8, x5, #2
    a874:      	add	x6, x6, x3, lsl #4
    a878:      	ldr	x6, [x6]
    a87c:      	ldr	x9, [x20, #0x78]
    a880:      	uxtb	w6, w6
    a884:      	add	x9, x9, x3, lsl #2
    a888:      	cmp	x6, #0x83
    a88c:      	cset	w10, lt
    a890:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a890:  ARM64_RELOC_PAGE21	l_stogir.484
    a894:      	ldr	x16, [x16]
		000000000000a894:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    a898:      	add	x6, x16, x6, lsl #2
    a89c:      	ldr	w9, [x9]
    a8a0:      	sxtw	x9, w9
    a8a4:      	mov	x11, #0x1               ; =1
    a8a8:      	b	0xa924 <_stogir.verify.control-sources+0x1c0>
    a8ac:      	movz	w13, #0x0, lsl #16
    a8b0:      	movz	w12, #0x0, lsl #16
    a8b4:      	b	0xa8d8 <_stogir.verify.control-sources+0x174>
    a8b8:      	sub	w12, w12, #0x1
    a8bc:      	lsl	w12, w12, #2
    a8c0:      	ubfx	x12, x12, #0, #32
    a8c4:      	lsr	x12, x14, x12
    a8c8:      	and	w12, w12, #0xf
    a8cc:      	b	0xa97c <_stogir.verify.control-sources+0x218>
    a8d0:      	movz	w13, #0x0, lsl #16
    a8d4:      	movz	w12, #0x0, lsl #16
    a8d8:      	ubfx	x13, x13, #0, #32
    a8dc:      	lsr	x16, x13, #0
    a8e0:      	cmp	x16, #0x1
    a8e4:      	b.eq	0xa900 <_stogir.verify.control-sources+0x19c>
    a8e8:      	b.lo	0xa8f0 <_stogir.verify.control-sources+0x18c>
    a8ec:      	b	0xa904 <_stogir.verify.control-sources+0x1a0>
    a8f0:      	cmp	x16, #0x0
    a8f4:      	b.eq	0xa8fc <_stogir.verify.control-sources+0x198>
    a8f8:      	b	0xa904 <_stogir.verify.control-sources+0x1a0>
    a8fc:      	b	0xa908 <_stogir.verify.control-sources+0x1a4>
    a900:      	b	0xa9e0 <_stogir.verify.control-sources+0x27c>
    a904:      	b	0xabb0 <_stogir.verify.control-sources+0x44c>
    a908:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a908:  ARM64_RELOC_PAGE21	l_stogir.485
    a90c:      	ldr	x1, [x1]
		000000000000a90c:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    a910:      	mov	x0, #0x16               ; =22
    a914:      	add	x4, x4, #0x1
    a918:      	sxtw	x4, w4
    a91c:      	add	x11, x11, #0x1
    a920:      	sxtw	x11, w11
    a924:      	cmp	x0, #0x0
    a928:      	b.ne	0xa93c <_stogir.verify.control-sources+0x1d8>
    a92c:      	cmp	x11, x9
    a930:      	cset	w12, le
    a934:      	ubfx	x12, x12, #0, #8
    a938:      	b	0xa940 <_stogir.verify.control-sources+0x1dc>
    a93c:      	movz	x12, #0x0, lsl #48
    a940:      	cmp	x12, #0x0
    a944:      	b.eq	0xaa78 <_stogir.verify.control-sources+0x314>
    a948:      	orr	w12, w11, wzr
    a94c:      	sxtw	x13, w12
    a950:      	uxtb	w16, w10
    a954:      	cmp	w16, wzr
    a958:      	b.eq	0xa980 <_stogir.verify.control-sources+0x21c>
    a95c:      	ldr	w14, [x6]
    a960:      	cmp	x13, #0x0
    a964:      	b.le	0xa978 <_stogir.verify.control-sources+0x214>
    a968:      	cmp	x13, #0x4
    a96c:      	b.le	0xa8b8 <_stogir.verify.control-sources+0x154>
    a970:      	mov	w12, #0x4               ; =4
    a974:      	b	0xa8bc <_stogir.verify.control-sources+0x158>
    a978:      	movz	w12, #0x0, lsl #16
    a97c:      	b	0xa984 <_stogir.verify.control-sources+0x220>
    a980:      	movz	w12, #0x0, lsl #16
    a984:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a984:  ARM64_RELOC_PAGE21	l_stogir.486
    a988:      	ldr	x16, [x16]
		000000000000a988:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    a98c:      	ldr	w14, [x16]
    a990:      	ubfx	x12, x12, #0, #32
    a994:      	cmp	x12, x14
    a998:      	b.ne	0xa91c <_stogir.verify.control-sources+0x1b8>
    a99c:      	uxtb	w16, w7
    a9a0:      	cmp	w16, wzr
    a9a4:      	b.ne	0xa8d0 <_stogir.verify.control-sources+0x16c>
    a9a8:      	ldr	x12, [x20, #0x8]
    a9ac:      	cmp	x5, x12
    a9b0:      	b.ge	0xaa04 <_stogir.verify.control-sources+0x2a0>
    a9b4:      	ldr	x12, [x2, #0x8]
    a9b8:      	cmp	x5, x12
    a9bc:      	b.ge	0xa9fc <_stogir.verify.control-sources+0x298>
    a9c0:      	ldr	x12, [x20, #0x78]
    a9c4:      	add	x12, x8, x12
    a9c8:      	ldr	w12, [x12]
    a9cc:      	sxtw	x12, w12
    a9d0:      	cmp	x12, #0x0
    a9d4:      	cset	w12, ge
    a9d8:      	ubfx	x12, x12, #0, #8
    a9dc:      	b	0xaa00 <_stogir.verify.control-sources+0x29c>
    a9e0:      	sxtw	x12, w12
    a9e4:      	cmp	x12, #0x0
    a9e8:      	b.gt	0xaaac <_stogir.verify.control-sources+0x348>
    a9ec:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000a9ec:  ARM64_RELOC_PAGE21	l_stogir.487
    a9f0:      	ldr	x1, [x1]
		000000000000a9f0:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    a9f4:      	mov	x0, #0x25               ; =37
    a9f8:      	b	0xa914 <_stogir.verify.control-sources+0x1b0>
    a9fc:      	movz	x12, #0x0, lsl #48
    aa00:      	b	0xaa08 <_stogir.verify.control-sources+0x2a4>
    aa04:      	movz	x12, #0x0, lsl #48
    aa08:      	cmp	x12, #0x0
    aa0c:      	b.eq	0xa8d0 <_stogir.verify.control-sources+0x16c>
    aa10:      	cmp	x13, #0x1
    aa14:      	b.lt	0xa8ac <_stogir.verify.control-sources+0x148>
    aa18:      	ldr	x12, [x20, #0x78]
    aa1c:      	add	x12, x8, x12
    aa20:      	ldr	w12, [x12]
    aa24:      	sxtw	x12, w12
    aa28:      	cmp	x13, x12
    aa2c:      	b.gt	0xa8ac <_stogir.verify.control-sources+0x148>
    aa30:      	ldr	x12, [x20]
    aa34:      	asr	x16, x13, #63
    aa38:      	lsr	x16, x16, #62
    aa3c:      	add	x14, x13, x16
    aa40:      	asr	x14, x14, #2
    aa44:      	asr	x16, x13, #63
    aa48:      	lsr	x16, x16, #62
    aa4c:      	add	x13, x13, x16
    aa50:      	and	x13, x13, #0x3
    aa54:      	sub	x13, x13, x16
    aa58:      	add	x14, x14, x5
    aa5c:      	add	x12, x12, x14, lsl #4
    aa60:      	add	x12, x12, x13, lsl #2
    aa64:      	ldr	w12, [x12]
    aa68:      	movn	w17, #0x0, lsl #16
    aa6c:      	and	w12, w12, w17
    aa70:      	mov	w13, #0x1               ; =1
    aa74:      	b	0xa8b4 <_stogir.verify.control-sources+0x150>
    aa78:      	add	x5, x9, #0x4
    aa7c:      	asr	x16, x5, #63
    aa80:      	lsr	x16, x16, #62
    aa84:      	add	x5, x5, x16
    aa88:      	asr	x5, x5, #2
    aa8c:      	add	x3, x5, x3
    aa90:      	cmp	x0, #0x0
    aa94:      	b.ne	0xa850 <_stogir.verify.control-sources+0xec>
    aa98:      	ldr	x5, [x20, #0x8]
    aa9c:      	cmp	x3, x5
    aaa0:      	cset	w5, lt
    aaa4:      	ubfx	x5, x5, #0, #8
    aaa8:      	b	0xa854 <_stogir.verify.control-sources+0xf0>
    aaac:      	ldr	x13, [x20, #0x8]
    aab0:      	cmp	x12, x13
    aab4:      	b.ge	0xaaec <_stogir.verify.control-sources+0x388>
    aab8:      	ldr	x13, [x2, #0x8]
    aabc:      	cmp	x12, x13
    aac0:      	b.ge	0xaae4 <_stogir.verify.control-sources+0x380>
    aac4:      	ldr	x13, [x20, #0x78]
    aac8:      	add	x13, x13, x12, lsl #2
    aacc:      	ldr	w13, [x13]
    aad0:      	sxtw	x13, w13
    aad4:      	cmp	x13, #0x0
    aad8:      	cset	w13, ge
    aadc:      	ubfx	x13, x13, #0, #8
    aae0:      	b	0xaae8 <_stogir.verify.control-sources+0x384>
    aae4:      	movz	x13, #0x0, lsl #48
    aae8:      	b	0xaaf0 <_stogir.verify.control-sources+0x38c>
    aaec:      	movz	x13, #0x0, lsl #48
    aaf0:      	cmp	x13, #0x0
    aaf4:      	b.eq	0xab30 <_stogir.verify.control-sources+0x3cc>
    aaf8:      	cmp	x12, #0x0
    aafc:      	b.le	0xab10 <_stogir.verify.control-sources+0x3ac>
    ab00:      	ldr	x13, [x20]
    ab04:      	add	x12, x13, x12, lsl #4
    ab08:      	ldr	x12, [x12]
    ab0c:      	b	0xab28 <_stogir.verify.control-sources+0x3c4>
    ab10:      	movz	x16, #0x0, lsl #48
    ab14:      	sub	x12, x16, x12
    ab18:      	ldr	x13, [x20, #0x28]
    ab1c:      	sub	x12, x12, #0x1
    ab20:      	add	x12, x13, x12, lsl #4
    ab24:      	ldr	x12, [x12]
    ab28:      	mov	w13, #0x1               ; =1
    ab2c:      	b	0xab38 <_stogir.verify.control-sources+0x3d4>
    ab30:      	movz	w13, #0x0, lsl #16
    ab34:      	movz	x12, #0x0, lsl #48
    ab38:      	ubfx	x13, x13, #0, #32
    ab3c:      	lsr	x16, x13, #0
    ab40:      	cmp	x16, #0x1
    ab44:      	b.eq	0xab60 <_stogir.verify.control-sources+0x3fc>
    ab48:      	b.lo	0xab50 <_stogir.verify.control-sources+0x3ec>
    ab4c:      	b	0xab64 <_stogir.verify.control-sources+0x400>
    ab50:      	cmp	x16, #0x0
    ab54:      	b.eq	0xab5c <_stogir.verify.control-sources+0x3f8>
    ab58:      	b	0xab64 <_stogir.verify.control-sources+0x400>
    ab5c:      	b	0xab68 <_stogir.verify.control-sources+0x404>
    ab60:      	b	0xab78 <_stogir.verify.control-sources+0x414>
    ab64:      	b	0xabb8 <_stogir.verify.control-sources+0x454>
    ab68:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000ab68:  ARM64_RELOC_PAGE21	l_stogir.485
    ab6c:      	ldr	x1, [x1]
		000000000000ab6c:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    ab70:      	mov	x0, #0x16               ; =22
    ab74:      	b	0xa84c <_stogir.verify.control-sources+0xe8>
    ab78:      	uxtb	w12, w12
    ab7c:      	cmp	x12, #0x83
    ab80:      	b.ge	0xa824 <_stogir.verify.control-sources+0xc0>
    ab84:      	adrp	x17, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000ab84:  ARM64_RELOC_PAGE21	l_stogir.488
    ab88:      	ldr	x17, [x17]
		000000000000ab88:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    ab8c:      	add	x12, x12, x17
    ab90:      	ldrb	w12, [x12]
    ab94:      	b	0xa828 <_stogir.verify.control-sources+0xc4>
    ab98:      	cmp	x0, #0x0
    ab9c:      	b.ne	0xa7e0 <_stogir.verify.control-sources+0x7c>
    aba0:      	and	x1, x4, #0xffffffff
    aba4:      	movz	x2, #0x0, lsl #48
    aba8:      	movz	x0, #0x0, lsl #48
    abac:      	b	0xa7e4 <_stogir.verify.control-sources+0x80>
    abb0:      	brk	#0
    abb4:      	b	0xabb0 <_stogir.verify.control-sources+0x44c>
    abb8:      	brk	#0
    abbc:      	b	0xabb8 <_stogir.verify.control-sources+0x454>
    abc0:      	brk	#0
    abc4:      	b	0xabc0 <_stogir.verify.control-sources+0x45c>

000000000000abc8 <_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge>:
    abc8:      	ldr	x1, [x0]
    abcc:      	ldr	x0, [x0, #0x8]
    abd0:      	movz	x17, #0x0, lsl #48
    abd4:      	str	x17, [x8]
    abd8:      	movz	x17, #0x0, lsl #48
    abdc:      	str	x17, [x8, #0x8]
    abe0:      	movz	x17, #0x0, lsl #48
    abe4:      	str	x17, [x8, #0x10]
    abe8:      	str	x1, [x8, #0x18]
    abec:      	str	x0, [x8, #0x20]
    abf0:      	ret

000000000000abf4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32>:
    abf4:      	sub	sp, sp, #0x30
    abf8:      	str	x29, [sp]
    abfc:      	str	x30, [sp, #0x8]
    ac00:      	mov	x29, sp
    ac04:      	str	x19, [sp, #0x10]
    ac08:      	str	x20, [sp, #0x18]
    ac0c:      	str	x21, [sp, #0x20]
    ac10:      	str	x22, [sp, #0x28]
    ac14:      	ldr	x2, [x0, #0x8]
    ac18:      	orr	x19, x2, xzr
    ac1c:      	ldr	x2, [x0, #0x10]
    ac20:      	add	x20, x19, x1
    ac24:      	cmp	x20, x2
    ac28:      	b.le	0xaca4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0xb0>
    ac2c:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    ac30:      	cmp	x2, x17
    ac34:      	b.gt	0xac40 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x4c>
    ac38:      	lsl	x2, x2, #1
    ac3c:      	b	0xac44 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x50>
    ac40:      	mov	x2, x20
    ac44:      	cmp	x2, x20
    ac48:      	b.gt	0xac50 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x5c>
    ac4c:      	mov	x2, x20
    ac50:      	mov	x21, x0
    ac54:      	mov	x22, x1
    ac58:      	mov	x1, x2
    ac5c:      	bl	0xac5c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x68>
		000000000000ac5c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ac60:      	lsl	x0, x22, #2
    ac64:      	ldr	x1, [x21]
    ac68:      	add	x1, x1, x19, lsl #2
    ac6c:      	mov	x2, x0
    ac70:      	mov	x0, x1
    ac74:      	movz	x1, #0x0, lsl #48
    ac78:      	bl	0xac78 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x84>
		000000000000ac78:  ARM64_RELOC_BRANCH26	_memset
    ac7c:      	str	x20, [x21, #0x8]
    ac80:      	mov	x0, x20
    ac84:      	ldr	x19, [sp, #0x10]
    ac88:      	ldr	x20, [sp, #0x18]
    ac8c:      	ldr	x21, [sp, #0x20]
    ac90:      	ldr	x22, [sp, #0x28]
    ac94:      	ldr	x29, [sp]
    ac98:      	ldr	x30, [sp, #0x8]
    ac9c:      	add	sp, sp, #0x30
    aca0:      	ret
    aca4:      	mov	x21, x0
    aca8:      	mov	x22, x1
    acac:      	b	0xac60 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x6c>

000000000000acb0 <_stogir.opcode.block-start?>:
    acb0:      	sxtw	x0, w0
    acb4:      	cmp	x0, #0x0
    acb8:      	b.lt	0xacd8 <_stogir.opcode.block-start?+0x28>
    acbc:      	cmp	x0, #0x83
    acc0:      	b.ge	0xacd8 <_stogir.opcode.block-start?+0x28>
    acc4:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000acc4:  ARM64_RELOC_PAGE21	l_stogir.489
    acc8:      	ldr	x16, [x16]
		000000000000acc8:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    accc:      	add	x0, x16, x0
    acd0:      	ldrb	w0, [x0]
    acd4:      	b	0xacdc <_stogir.opcode.block-start?+0x2c>
    acd8:      	movz	w0, #0x0, lsl #16
    acdc:      	uxtb	w16, w0
    ace0:      	and	w0, w16, #0x2
    ace4:      	uxtb	w0, w0
    ace8:      	ubfx	x0, x0, #0, #8
    acec:      	cmp	x0, #0x0
    acf0:      	cset	w0, eq
    acf4:      	uxtb	w16, w0
    acf8:      	cmp	w16, wzr
    acfc:      	cset	x0, eq
    ad00:      	ret

000000000000ad04 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32>:
    ad04:      	sub	sp, sp, #0x30
    ad08:      	str	x29, [sp]
    ad0c:      	str	x30, [sp, #0x8]
    ad10:      	mov	x29, sp
    ad14:      	str	x19, [sp, #0x10]
    ad18:      	str	x20, [sp, #0x18]
    ad1c:      	str	x21, [sp, #0x20]
    ad20:      	ldr	x2, [x0, #0x8]
    ad24:      	orr	x19, x2, xzr
    ad28:      	ldr	x2, [x0, #0x10]
    ad2c:      	cmp	x19, x2
    ad30:      	b.lt	0xad44 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x40>
    ad34:      	cmp	x2, #0x0
    ad38:      	b.ne	0xad50 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x4c>
    ad3c:      	mov	x2, #0x2                ; =2
    ad40:      	b	0xad54 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x50>
    ad44:      	mov	x20, x0
    ad48:      	mov	w21, w1
    ad4c:      	b	0xad64 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x60>
    ad50:      	lsl	x2, x2, #1
    ad54:      	mov	x20, x0
    ad58:      	mov	w21, w1
    ad5c:      	mov	x1, x2
    ad60:      	bl	0xad60 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x5c>
		000000000000ad60:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ad64:      	add	x0, x19, #0x1
    ad68:      	ldr	x1, [x20]
    ad6c:      	add	x1, x1, x19, lsl #2
    ad70:      	str	w21, [x1]
    ad74:      	str	x0, [x20, #0x8]
    ad78:      	ldr	x19, [sp, #0x10]
    ad7c:      	ldr	x20, [sp, #0x18]
    ad80:      	ldr	x21, [sp, #0x20]
    ad84:      	ldr	x29, [sp]
    ad88:      	ldr	x30, [sp, #0x8]
    ad8c:      	add	sp, sp, #0x30
    ad90:      	ret

000000000000ad94 <_coil.core.Set$coil.arraylist.ArrayList$set!__i32>:
    ad94:      	ldr	x0, [x0]
    ad98:      	add	x0, x0, x1, lsl #2
    ad9c:      	str	w2, [x0]
    ada0:      	movz	x0, #0x0, lsl #48
    ada4:      	ret

000000000000ada8 <_stogir.opcode.control?>:
    ada8:      	sxtw	x0, w0
    adac:      	cmp	x0, #0x0
    adb0:      	b.lt	0xadd0 <_stogir.opcode.control?+0x28>
    adb4:      	cmp	x0, #0x83
    adb8:      	b.ge	0xadd0 <_stogir.opcode.control?+0x28>
    adbc:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5c0>
		000000000000adbc:  ARM64_RELOC_PAGE21	l_stogir.490
    adc0:      	ldr	x16, [x16]
		000000000000adc0:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    adc4:      	add	x0, x16, x0
    adc8:      	ldrb	w0, [x0]
    adcc:      	b	0xadd4 <_stogir.opcode.control?+0x2c>
    add0:      	movz	w0, #0x0, lsl #16
    add4:      	uxtb	w16, w0
    add8:      	and	w0, w16, #0x1
    addc:      	uxtb	w0, w0
    ade0:      	ubfx	x0, x0, #0, #8
    ade4:      	ret

000000000000ade8 <_inherent$coil.arraylist.ArrayList$clear!__i32>:
    ade8:      	b	0xadf8 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x10>
    adec:      	nop
    adf0:      	sub	x1, x1, #0x1
    adf4:      	str	x1, [x0, #0x8]
    adf8:      	ldr	x1, [x0, #0x8]
    adfc:      	cmp	x1, #0x0
    ae00:      	b.ne	0xadf0 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x8>
    ae04:      	movz	x0, #0x0, lsl #48
    ae08:      	ret

000000000000ae0c <_stogir.graph.operand>:
    ae0c:      	sxtw	x1, w1
    ae10:      	cmp	x1, #0x0
    ae14:      	b.le	0xae58 <_stogir.graph.operand+0x4c>
    ae18:      	lsl	x3, x1, #2
    ae1c:      	add	x4, x0, #0x78
    ae20:      	ldr	x5, [x0, #0x8]
    ae24:      	cmp	x1, x5
    ae28:      	b.ge	0xae84 <_stogir.graph.operand+0x78>
    ae2c:      	ldr	x4, [x4, #0x8]
    ae30:      	cmp	x1, x4
    ae34:      	b.ge	0xae7c <_stogir.graph.operand+0x70>
    ae38:      	ldr	x4, [x0, #0x78]
    ae3c:      	add	x4, x3, x4
    ae40:      	ldr	w4, [x4]
    ae44:      	sxtw	x4, w4
    ae48:      	cmp	x4, #0x0
    ae4c:      	cset	w4, ge
    ae50:      	ubfx	x4, x4, #0, #8
    ae54:      	b	0xae80 <_stogir.graph.operand+0x74>
    ae58:      	movz	x1, #0x0, lsl #48
    ae5c:      	movz	x0, #0x0, lsl #48
    ae60:      	fmov	d31, x0
    ae64:      	mov	x0, x1
    ae68:      	fmov	x1, d31
    ae6c:      	ret
    ae70:      	movz	x1, #0x0, lsl #48
    ae74:      	movz	x0, #0x0, lsl #48
    ae78:      	b	0xae60 <_stogir.graph.operand+0x54>
    ae7c:      	movz	x4, #0x0, lsl #48
    ae80:      	b	0xae88 <_stogir.graph.operand+0x7c>
    ae84:      	movz	x4, #0x0, lsl #48
    ae88:      	cmp	x4, #0x0
    ae8c:      	b.eq	0xae58 <_stogir.graph.operand+0x4c>
    ae90:      	sxtw	x2, w2
    ae94:      	cmp	x2, #0x1
    ae98:      	b.lt	0xae70 <_stogir.graph.operand+0x64>
    ae9c:      	ldr	x4, [x0, #0x78]
    aea0:      	add	x3, x3, x4
    aea4:      	ldr	w3, [x3]
    aea8:      	sxtw	x3, w3
    aeac:      	cmp	x2, x3
    aeb0:      	b.gt	0xae70 <_stogir.graph.operand+0x64>
    aeb4:      	ldr	x0, [x0]
    aeb8:      	asr	x16, x2, #63
    aebc:      	lsr	x16, x16, #62
    aec0:      	add	x3, x2, x16
    aec4:      	asr	x3, x3, #2
    aec8:      	asr	x16, x2, #63
    aecc:      	lsr	x16, x16, #62
    aed0:      	add	x2, x2, x16
    aed4:      	and	x2, x2, #0x3
    aed8:      	sub	x2, x2, x16
    aedc:      	add	x1, x3, x1
    aee0:      	add	x0, x0, x1, lsl #4
    aee4:      	add	x0, x0, x2, lsl #2
    aee8:      	ldr	w0, [x0]
    aeec:      	sxtw	x0, w0
    aef0:      	and	x0, x0, #0xffffffff
    aef4:      	mov	x1, #0x1                ; =1
    aef8:      	b	0xae78 <_stogir.graph.operand+0x6c>

000000000000aefc <_inherent$coil.arraylist.ArrayList$new__bool>:
    aefc:      	ldr	x1, [x0]
    af00:      	ldr	x0, [x0, #0x8]
    af04:      	movz	x17, #0x0, lsl #48
    af08:      	str	x17, [x8]
    af0c:      	movz	x17, #0x0, lsl #48
    af10:      	str	x17, [x8, #0x8]
    af14:      	movz	x17, #0x0, lsl #48
    af18:      	str	x17, [x8, #0x10]
    af1c:      	str	x1, [x8, #0x18]
    af20:      	str	x0, [x8, #0x20]
    af24:      	ret

000000000000af28 <_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame>:
    af28:      	ldr	x1, [x0]
    af2c:      	ldr	x0, [x0, #0x8]
    af30:      	movz	x17, #0x0, lsl #48
    af34:      	str	x17, [x8]
    af38:      	movz	x17, #0x0, lsl #48
    af3c:      	str	x17, [x8, #0x8]
    af40:      	movz	x17, #0x0, lsl #48
    af44:      	str	x17, [x8, #0x10]
    af48:      	str	x1, [x8, #0x18]
    af4c:      	str	x0, [x8, #0x20]
    af50:      	ret

000000000000af54 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool>:
    af54:      	sub	sp, sp, #0x30
    af58:      	str	x29, [sp]
    af5c:      	str	x30, [sp, #0x8]
    af60:      	mov	x29, sp
    af64:      	str	x19, [sp, #0x10]
    af68:      	str	x20, [sp, #0x18]
    af6c:      	str	x21, [sp, #0x20]
    af70:      	str	x22, [sp, #0x28]
    af74:      	ldr	x2, [x0, #0x8]
    af78:      	orr	x19, x2, xzr
    af7c:      	ldr	x2, [x0, #0x10]
    af80:      	add	x20, x19, x1
    af84:      	cmp	x20, x2
    af88:      	b.le	0xb004 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xb0>
    af8c:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    af90:      	cmp	x2, x17
    af94:      	b.gt	0xafa0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x4c>
    af98:      	lsl	x2, x2, #1
    af9c:      	b	0xafa4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x50>
    afa0:      	mov	x2, x20
    afa4:      	cmp	x2, x20
    afa8:      	b.gt	0xafb0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x5c>
    afac:      	mov	x2, x20
    afb0:      	mov	x21, x0
    afb4:      	mov	x22, x1
    afb8:      	mov	x1, x2
    afbc:      	bl	0xafbc <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x68>
		000000000000afbc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    afc0:      	lsr	x0, x22, #0
    afc4:      	ldr	x1, [x21]
    afc8:      	add	x1, x1, x19
    afcc:      	mov	x2, x0
    afd0:      	mov	x0, x1
    afd4:      	movz	x1, #0x0, lsl #48
    afd8:      	bl	0xafd8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x84>
		000000000000afd8:  ARM64_RELOC_BRANCH26	_memset
    afdc:      	str	x20, [x21, #0x8]
    afe0:      	mov	x0, x20
    afe4:      	ldr	x19, [sp, #0x10]
    afe8:      	ldr	x20, [sp, #0x18]
    afec:      	ldr	x21, [sp, #0x20]
    aff0:      	ldr	x22, [sp, #0x28]
    aff4:      	ldr	x29, [sp]
    aff8:      	ldr	x30, [sp, #0x8]
    affc:      	add	sp, sp, #0x30
    b000:      	ret
    b004:      	mov	x21, x0
    b008:      	mov	x22, x1
    b00c:      	b	0xafc0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x6c>

000000000000b010 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame>:
    b010:      	sub	sp, sp, #0x30
    b014:      	str	x29, [sp]
    b018:      	str	x30, [sp, #0x8]
    b01c:      	mov	x29, sp
    b020:      	str	x19, [sp, #0x10]
    b024:      	str	x20, [sp, #0x18]
    b028:      	str	x21, [sp, #0x20]
    b02c:      	str	x22, [sp, #0x28]
    b030:      	ldr	x3, [x0, #0x8]
    b034:      	orr	x19, x3, xzr
    b038:      	ldr	x3, [x0, #0x10]
    b03c:      	cmp	x19, x3
    b040:      	b.lt	0xb054 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x44>
    b044:      	cmp	x3, #0x0
    b048:      	b.ne	0xb064 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x54>
    b04c:      	mov	x3, #0x2                ; =2
    b050:      	b	0xb068 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x58>
    b054:      	mov	x20, x0
    b058:      	mov	x21, x1
    b05c:      	mov	x22, x2
    b060:      	b	0xb07c <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x6c>
    b064:      	lsl	x3, x3, #1
    b068:      	mov	x20, x0
    b06c:      	mov	x21, x1
    b070:      	mov	x1, x3
    b074:      	mov	x22, x2
    b078:      	bl	0xb078 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x68>
		000000000000b078:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    b07c:      	add	x0, x19, #0x1
    b080:      	ldr	x1, [x20]
    b084:      	add	x1, x1, x19, lsl #4
    b088:      	str	x21, [x1]
    b08c:      	str	x22, [x1, #0x8]
    b090:      	str	x0, [x20, #0x8]
    b094:      	ldr	x19, [sp, #0x10]
    b098:      	ldr	x20, [sp, #0x18]
    b09c:      	ldr	x21, [sp, #0x20]
    b0a0:      	ldr	x22, [sp, #0x28]
    b0a4:      	ldr	x29, [sp]
    b0a8:      	ldr	x30, [sp, #0x8]
    b0ac:      	add	sp, sp, #0x30
    b0b0:      	ret
    b0b4:      	udf	#0x0

000000000000b0b8 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame>:
    b0b8:      	sub	sp, sp, #0x20
    b0bc:      	str	x29, [sp]
    b0c0:      	str	x30, [sp, #0x8]
    b0c4:      	mov	x29, sp
    b0c8:      	str	x19, [sp, #0x10]
    b0cc:      	b	0xb0d8 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x20>
    b0d0:      	sub	x1, x1, #0x1
    b0d4:      	str	x1, [x0, #0x8]
    b0d8:      	ldr	x1, [x0, #0x8]
    b0dc:      	cmp	x1, #0x0
    b0e0:      	b.ne	0xb0d0 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x18>
    b0e4:      	ldr	x1, [x0, #0x10]
    b0e8:      	cmp	x1, #0x0
    b0ec:      	b.le	0xb14c <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x94>
    b0f0:      	add	x2, x0, #0x18
    b0f4:      	ldr	x3, [x0]
    b0f8:      	mov	x19, x0
    b0fc:      	mov	x0, x2
    b100:      	mov	x2, x1
    b104:      	mov	x1, x3
    b108:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000b108:  ARM64_RELOC_PAGE21	l_stogir.491
    b10c:      	ldr	x3, [x3]
		000000000000b10c:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    b110:      	mov	x4, #0x10               ; =16
    b114:      	mov	x5, #0x8                ; =8
    b118:      	bl	0xb118 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x60>
		000000000000b118:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b11c:      	movz	x17, #0x0, lsl #48
    b120:      	str	x17, [x19]
    b124:      	movz	x17, #0x0, lsl #48
    b128:      	str	x17, [x19, #0x8]
    b12c:      	movz	x17, #0x0, lsl #48
    b130:      	str	x17, [x19, #0x10]
    b134:      	movz	x0, #0x0, lsl #48
    b138:      	ldr	x19, [sp, #0x10]
    b13c:      	ldr	x29, [sp]
    b140:      	ldr	x30, [sp, #0x8]
    b144:      	add	sp, sp, #0x20
    b148:      	ret
    b14c:      	mov	x19, x0
    b150:      	b	0xb11c <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x64>

000000000000b154 <_inherent$coil.arraylist.ArrayList$new__i64>:
    b154:      	ldr	x1, [x0]
    b158:      	ldr	x0, [x0, #0x8]
    b15c:      	movz	x17, #0x0, lsl #48
    b160:      	str	x17, [x8]
    b164:      	movz	x17, #0x0, lsl #48
    b168:      	str	x17, [x8, #0x8]
    b16c:      	movz	x17, #0x0, lsl #48
    b170:      	str	x17, [x8, #0x10]
    b174:      	str	x1, [x8, #0x18]
    b178:      	str	x0, [x8, #0x20]
    b17c:      	ret

000000000000b180 <_inherent$coil.arraylist.ArrayList$free!__i64>:
    b180:      	sub	sp, sp, #0x20
    b184:      	str	x29, [sp]
    b188:      	str	x30, [sp, #0x8]
    b18c:      	mov	x29, sp
    b190:      	str	x19, [sp, #0x10]
    b194:      	b	0xb1a0 <_inherent$coil.arraylist.ArrayList$free!__i64+0x20>
    b198:      	sub	x1, x1, #0x1
    b19c:      	str	x1, [x0, #0x8]
    b1a0:      	ldr	x1, [x0, #0x8]
    b1a4:      	cmp	x1, #0x0
    b1a8:      	b.ne	0xb198 <_inherent$coil.arraylist.ArrayList$free!__i64+0x18>
    b1ac:      	ldr	x1, [x0, #0x10]
    b1b0:      	cmp	x1, #0x0
    b1b4:      	b.le	0xb214 <_inherent$coil.arraylist.ArrayList$free!__i64+0x94>
    b1b8:      	add	x2, x0, #0x18
    b1bc:      	ldr	x3, [x0]
    b1c0:      	mov	x19, x0
    b1c4:      	mov	x0, x2
    b1c8:      	mov	x2, x1
    b1cc:      	mov	x1, x3
    b1d0:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000b1d0:  ARM64_RELOC_PAGE21	l_stogir.492
    b1d4:      	ldr	x3, [x3]
		000000000000b1d4:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    b1d8:      	mov	x4, #0x8                ; =8
    b1dc:      	mov	x5, #0x8                ; =8
    b1e0:      	bl	0xb1e0 <_inherent$coil.arraylist.ArrayList$free!__i64+0x60>
		000000000000b1e0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b1e4:      	movz	x17, #0x0, lsl #48
    b1e8:      	str	x17, [x19]
    b1ec:      	movz	x17, #0x0, lsl #48
    b1f0:      	str	x17, [x19, #0x8]
    b1f4:      	movz	x17, #0x0, lsl #48
    b1f8:      	str	x17, [x19, #0x10]
    b1fc:      	movz	x0, #0x0, lsl #48
    b200:      	ldr	x19, [sp, #0x10]
    b204:      	ldr	x29, [sp]
    b208:      	ldr	x30, [sp, #0x8]
    b20c:      	add	sp, sp, #0x20
    b210:      	ret
    b214:      	mov	x19, x0
    b218:      	b	0xb1e4 <_inherent$coil.arraylist.ArrayList$free!__i64+0x64>
    b21c:      	udf	#0x0

000000000000b220 <_stogir.dominators.build-index>:
    b220:      	sub	sp, sp, #0x130
    b224:      	str	x29, [sp]
    b228:      	str	x30, [sp, #0x8]
    b22c:      	mov	x29, sp
    b230:      	str	x19, [sp, #0xf0]
    b234:      	str	x20, [sp, #0xf8]
    b238:      	str	x21, [sp, #0x100]
    b23c:      	str	x22, [sp, #0x108]
    b240:      	str	x23, [sp, #0x110]
    b244:      	str	x24, [sp, #0x118]
    b248:      	str	x25, [sp, #0x120]
    b24c:      	ldr	x2, [x0, #0x8]
    b250:      	orr	x19, x2, xzr
    b254:      	ldr	x2, [x1]
    b258:      	ldr	x1, [x1, #0x8]
    b25c:      	add	x16, sp, #0x10
    b260:      	movz	x17, #0x0, lsl #48
    b264:      	str	x17, [x16]
    b268:      	add	x16, sp, #0x10
    b26c:      	movz	x17, #0x0, lsl #48
    b270:      	str	x17, [x16, #0x8]
    b274:      	add	x16, sp, #0x10
    b278:      	movz	x17, #0x0, lsl #48
    b27c:      	str	x17, [x16, #0x10]
    b280:      	add	x16, sp, #0x10
    b284:      	str	x2, [x16, #0x18]
    b288:      	add	x16, sp, #0x10
    b28c:      	str	x1, [x16, #0x20]
    b290:      	add	x16, sp, #0x10
    b294:      	movz	x17, #0x0, lsl #48
    b298:      	str	x17, [x16, #0x28]
    b29c:      	add	x16, sp, #0x10
    b2a0:      	movz	x17, #0x0, lsl #48
    b2a4:      	str	x17, [x16, #0x30]
    b2a8:      	add	x16, sp, #0x10
    b2ac:      	movz	x17, #0x0, lsl #48
    b2b0:      	str	x17, [x16, #0x38]
    b2b4:      	add	x16, sp, #0x10
    b2b8:      	str	x2, [x16, #0x40]
    b2bc:      	add	x16, sp, #0x10
    b2c0:      	str	x1, [x16, #0x48]
    b2c4:      	add	x16, sp, #0x60
    b2c8:      	movz	x17, #0x0, lsl #48
    b2cc:      	str	x17, [x16]
    b2d0:      	add	x16, sp, #0x60
    b2d4:      	movz	x17, #0x0, lsl #48
    b2d8:      	str	x17, [x16, #0x8]
    b2dc:      	add	x16, sp, #0x60
    b2e0:      	movz	x17, #0x0, lsl #48
    b2e4:      	str	x17, [x16, #0x10]
    b2e8:      	add	x16, sp, #0x60
    b2ec:      	str	x2, [x16, #0x18]
    b2f0:      	add	x16, sp, #0x60
    b2f4:      	str	x1, [x16, #0x20]
    b2f8:      	add	x16, sp, #0x90
    b2fc:      	movz	x17, #0x0, lsl #48
    b300:      	str	x17, [x16]
    b304:      	add	x16, sp, #0x90
    b308:      	movz	x17, #0x0, lsl #48
    b30c:      	str	x17, [x16, #0x8]
    b310:      	add	x16, sp, #0x90
    b314:      	movz	x17, #0x0, lsl #48
    b318:      	str	x17, [x16, #0x10]
    b31c:      	add	x16, sp, #0x90
    b320:      	str	x2, [x16, #0x18]
    b324:      	add	x16, sp, #0x90
    b328:      	str	x1, [x16, #0x20]
    b32c:      	add	x16, sp, #0xc0
    b330:      	movz	x17, #0x0, lsl #48
    b334:      	str	x17, [x16]
    b338:      	add	x16, sp, #0xc0
    b33c:      	movz	x17, #0x0, lsl #48
    b340:      	str	x17, [x16, #0x8]
    b344:      	add	x16, sp, #0xc0
    b348:      	movz	x17, #0x0, lsl #48
    b34c:      	str	x17, [x16, #0x10]
    b350:      	add	x16, sp, #0xc0
    b354:      	str	x2, [x16, #0x18]
    b358:      	add	x16, sp, #0xc0
    b35c:      	str	x1, [x16, #0x20]
    b360:      	cmp	x19, #0x0
    b364:      	b.le	0xb908 <_stogir.dominators.build-index+0x6e8>
    b368:      	cmp	x19, #0x0
    b36c:      	b.ge	0xb378 <_stogir.dominators.build-index+0x158>
    b370:      	movz	x1, #0x0, lsl #48
    b374:      	b	0xb37c <_stogir.dominators.build-index+0x15c>
    b378:      	mov	x1, x19
    b37c:      	mov	x20, x8
    b380:      	mov	x21, x0
    b384:      	add	x0, sp, #0x10
    b388:      	bl	0xb388 <_stogir.dominators.build-index+0x168>
		000000000000b388:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b38c:      	add	x16, sp, #0x10
    b390:      	orr	x0, x16, xzr
    b394:      	lsl	x1, x19, #2
    b398:      	add	x22, x0, #0x28
    b39c:      	add	x16, sp, #0x10
    b3a0:      	ldr	x0, [x16]
    b3a4:      	mov	x2, x1
    b3a8:      	movz	x1, #0x0, lsl #48
    b3ac:      	bl	0xb3ac <_stogir.dominators.build-index+0x18c>
		000000000000b3ac:  ARM64_RELOC_BRANCH26	_memset
    b3b0:      	add	x16, sp, #0x10
    b3b4:      	str	x19, [x16, #0x8]
    b3b8:      	ldr	x0, [x22, #0x8]
    b3bc:      	orr	x23, x0, xzr
    b3c0:      	ldr	x0, [x22, #0x10]
    b3c4:      	add	x24, x23, x19
    b3c8:      	cmp	x24, x0
    b3cc:      	b.le	0xb400 <_stogir.dominators.build-index+0x1e0>
    b3d0:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b3d4:      	cmp	x0, x17
    b3d8:      	b.gt	0xb3e4 <_stogir.dominators.build-index+0x1c4>
    b3dc:      	lsl	x0, x0, #1
    b3e0:      	b	0xb3e8 <_stogir.dominators.build-index+0x1c8>
    b3e4:      	mov	x0, x24
    b3e8:      	cmp	x0, x24
    b3ec:      	b.gt	0xb3f4 <_stogir.dominators.build-index+0x1d4>
    b3f0:      	mov	x0, x24
    b3f4:      	mov	x1, x0
    b3f8:      	mov	x0, x22
    b3fc:      	bl	0xb3fc <_stogir.dominators.build-index+0x1dc>
		000000000000b3fc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b400:      	lsl	x0, x19, #2
    b404:      	add	x16, sp, #0x10
    b408:      	ldr	x1, [x16, #0x28]
    b40c:      	add	x1, x1, x23, lsl #2
    b410:      	mov	x2, x0
    b414:      	mov	x0, x1
    b418:      	movz	x1, #0x0, lsl #48
    b41c:      	bl	0xb41c <_stogir.dominators.build-index+0x1fc>
		000000000000b41c:  ARM64_RELOC_BRANCH26	_memset
    b420:      	str	x24, [x22, #0x8]
    b424:      	add	x16, sp, #0x60
    b428:      	ldr	x0, [x16, #0x8]
    b42c:      	orr	x22, x0, xzr
    b430:      	add	x16, sp, #0x60
    b434:      	ldr	x0, [x16, #0x10]
    b438:      	add	x23, x22, x19
    b43c:      	cmp	x23, x0
    b440:      	b.le	0xb474 <_stogir.dominators.build-index+0x254>
    b444:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b448:      	cmp	x0, x17
    b44c:      	b.gt	0xb458 <_stogir.dominators.build-index+0x238>
    b450:      	lsl	x0, x0, #1
    b454:      	b	0xb45c <_stogir.dominators.build-index+0x23c>
    b458:      	mov	x0, x23
    b45c:      	cmp	x0, x23
    b460:      	b.gt	0xb468 <_stogir.dominators.build-index+0x248>
    b464:      	mov	x0, x23
    b468:      	mov	x1, x0
    b46c:      	add	x0, sp, #0x60
    b470:      	bl	0xb470 <_stogir.dominators.build-index+0x250>
		000000000000b470:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b474:      	lsl	x0, x19, #2
    b478:      	add	x16, sp, #0x60
    b47c:      	ldr	x1, [x16]
    b480:      	add	x1, x1, x22, lsl #2
    b484:      	mov	x2, x0
    b488:      	mov	x0, x1
    b48c:      	movz	x1, #0x0, lsl #48
    b490:      	bl	0xb490 <_stogir.dominators.build-index+0x270>
		000000000000b490:  ARM64_RELOC_BRANCH26	_memset
    b494:      	add	x16, sp, #0x60
    b498:      	str	x23, [x16, #0x8]
    b49c:      	add	x0, sp, #0x90
    b4a0:      	mov	x1, x19
    b4a4:      	bl	0xb4a4 <_stogir.dominators.build-index+0x284>
		000000000000b4a4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    b4a8:      	movz	x0, #0x0, lsl #48
    b4ac:      	b	0xb4e4 <_stogir.dominators.build-index+0x2c4>
    b4b0:      	orr	w2, w0, wzr
    b4b4:      	add	x16, sp, #0x60
    b4b8:      	ldr	x3, [x16]
    b4bc:      	add	x3, x3, x1, lsl #2
    b4c0:      	ldr	w3, [x3]
    b4c4:      	add	x16, sp, #0x90
    b4c8:      	ldr	x4, [x16]
    b4cc:      	add	x4, x4, x0, lsl #2
    b4d0:      	str	w3, [x4]
    b4d4:      	add	x16, sp, #0x60
    b4d8:      	ldr	x3, [x16]
    b4dc:      	add	x1, x3, x1, lsl #2
    b4e0:      	str	w2, [x1]
    b4e4:      	add	x0, x0, #0x1
    b4e8:      	cmp	x0, x19
    b4ec:      	b.ge	0xb514 <_stogir.dominators.build-index+0x2f4>
    b4f0:      	ldr	x1, [x21]
    b4f4:      	add	x1, x1, x0, lsl #2
    b4f8:      	ldr	w1, [x1]
    b4fc:      	sxtw	x1, w1
    b500:      	cmp	x1, #0x0
    b504:      	b.le	0xb4e4 <_stogir.dominators.build-index+0x2c4>
    b508:      	cmp	x1, x0
    b50c:      	b.ne	0xb4b0 <_stogir.dominators.build-index+0x290>
    b510:      	b	0xb4e4 <_stogir.dominators.build-index+0x2c4>
    b514:      	movz	x22, #0x0, lsl #48
    b518:      	movz	x0, #0x0, lsl #48
    b51c:      	b	0xb660 <_stogir.dominators.build-index+0x440>
    b520:      	lsl	x0, x0, #1
    b524:      	mov	x1, x0
    b528:      	add	x0, sp, #0xc0
    b52c:      	bl	0xb52c <_stogir.dominators.build-index+0x30c>
		000000000000b52c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b530:      	sxtw	x0, w23
    b534:      	orr	w1, w22, wzr
    b538:      	add	x2, x24, #0x1
    b53c:      	add	x16, sp, #0xc0
    b540:      	ldr	x3, [x16]
    b544:      	add	x3, x3, x24, lsl #2
    b548:      	str	w1, [x3]
    b54c:      	add	x16, sp, #0xc0
    b550:      	str	x2, [x16, #0x8]
    b554:      	b	0xb588 <_stogir.dominators.build-index+0x368>
    b558:      	lsl	x0, x0, #1
    b55c:      	mov	x1, x0
    b560:      	add	x0, sp, #0xc0
    b564:      	bl	0xb564 <_stogir.dominators.build-index+0x344>
		000000000000b564:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b568:      	sxtw	x0, w24
    b56c:      	add	x1, x25, #0x1
    b570:      	add	x16, sp, #0xc0
    b574:      	ldr	x2, [x16]
    b578:      	add	x2, x2, x25, lsl #2
    b57c:      	str	w23, [x2]
    b580:      	add	x16, sp, #0xc0
    b584:      	str	x1, [x16, #0x8]
    b588:      	add	x16, sp, #0xc0
    b58c:      	ldr	x1, [x16, #0x8]
    b590:      	cmp	x1, #0x0
    b594:      	b.le	0xb660 <_stogir.dominators.build-index+0x440>
    b598:      	add	x16, sp, #0xc0
    b59c:      	ldr	x2, [x16]
    b5a0:      	sub	x1, x1, #0x1
    b5a4:      	add	x1, x2, x1, lsl #2
    b5a8:      	ldr	w1, [x1]
    b5ac:      	sxtw	x1, w1
    b5b0:      	add	x16, sp, #0x60
    b5b4:      	ldr	x2, [x16]
    b5b8:      	add	x3, x2, x1, lsl #2
    b5bc:      	ldr	w23, [x3]
    b5c0:      	sxtw	x3, w23
    b5c4:      	cmp	x3, #0x0
    b5c8:      	b.le	0xb628 <_stogir.dominators.build-index+0x408>
    b5cc:      	add	x0, x0, #0x1
    b5d0:      	add	x16, sp, #0x90
    b5d4:      	ldr	x4, [x16]
    b5d8:      	orr	w24, w0, wzr
    b5dc:      	add	x0, x2, x1, lsl #2
    b5e0:      	add	x1, x4, x3, lsl #2
    b5e4:      	ldr	w1, [x1]
    b5e8:      	str	w1, [x0]
    b5ec:      	add	x16, sp, #0x10
    b5f0:      	ldr	x0, [x16]
    b5f4:      	add	x0, x0, x3, lsl #2
    b5f8:      	str	w24, [x0]
    b5fc:      	add	x16, sp, #0xc0
    b600:      	ldr	x0, [x16, #0x8]
    b604:      	orr	x25, x0, xzr
    b608:      	add	x16, sp, #0xc0
    b60c:      	ldr	x0, [x16, #0x10]
    b610:      	cmp	x25, x0
    b614:      	b.lt	0xb568 <_stogir.dominators.build-index+0x348>
    b618:      	cmp	x0, #0x0
    b61c:      	b.ne	0xb558 <_stogir.dominators.build-index+0x338>
    b620:      	mov	x0, #0x2                ; =2
    b624:      	b	0xb55c <_stogir.dominators.build-index+0x33c>
    b628:      	orr	w2, w0, wzr
    b62c:      	add	x16, sp, #0x10
    b630:      	ldr	x3, [x16, #0x28]
    b634:      	add	x1, x3, x1, lsl #2
    b638:      	str	w2, [x1]
    b63c:      	add	x16, sp, #0xc0
    b640:      	ldr	x1, [x16, #0x8]
    b644:      	cmp	x1, #0x0
    b648:      	b.eq	0xb588 <_stogir.dominators.build-index+0x368>
    b64c:      	sub	x1, x1, #0x1
    b650:      	add	x16, sp, #0xc0
    b654:      	str	x1, [x16, #0x8]
    b658:      	b	0xb588 <_stogir.dominators.build-index+0x368>
    b65c:      	nop
    b660:      	add	x22, x22, #0x1
    b664:      	cmp	x22, x19
    b668:      	b.ge	0xb6c8 <_stogir.dominators.build-index+0x4a8>
    b66c:      	ldr	x1, [x21]
    b670:      	add	x1, x1, x22, lsl #2
    b674:      	ldr	w1, [x1]
    b678:      	sxtw	x1, w1
    b67c:      	cmp	x1, x22
    b680:      	b.ne	0xb660 <_stogir.dominators.build-index+0x440>
    b684:      	add	x0, x0, #0x1
    b688:      	add	x16, sp, #0x10
    b68c:      	ldr	x1, [x16]
    b690:      	orr	w23, w0, wzr
    b694:      	add	x0, x1, x22, lsl #2
    b698:      	str	w23, [x0]
    b69c:      	add	x16, sp, #0xc0
    b6a0:      	ldr	x0, [x16, #0x8]
    b6a4:      	orr	x24, x0, xzr
    b6a8:      	add	x16, sp, #0xc0
    b6ac:      	ldr	x0, [x16, #0x10]
    b6b0:      	cmp	x24, x0
    b6b4:      	b.lt	0xb530 <_stogir.dominators.build-index+0x310>
    b6b8:      	cmp	x0, #0x0
    b6bc:      	b.ne	0xb520 <_stogir.dominators.build-index+0x300>
    b6c0:      	mov	x0, #0x2                ; =2
    b6c4:      	b	0xb524 <_stogir.dominators.build-index+0x304>
    b6c8:      	b	0xb6dc <_stogir.dominators.build-index+0x4bc>
    b6cc:      	nop
    b6d0:      	sub	x0, x0, #0x1
    b6d4:      	add	x16, sp, #0xc0
    b6d8:      	str	x0, [x16, #0x8]
    b6dc:      	add	x16, sp, #0xc0
    b6e0:      	ldr	x0, [x16, #0x8]
    b6e4:      	cmp	x0, #0x0
    b6e8:      	b.ne	0xb6d0 <_stogir.dominators.build-index+0x4b0>
    b6ec:      	add	x16, sp, #0xc0
    b6f0:      	orr	x0, x16, xzr
    b6f4:      	add	x16, sp, #0xc0
    b6f8:      	ldr	x1, [x16, #0x10]
    b6fc:      	cmp	x1, #0x0
    b700:      	b.le	0xb730 <_stogir.dominators.build-index+0x510>
    b704:      	add	x0, x0, #0x18
    b708:      	add	x16, sp, #0xc0
    b70c:      	ldr	x2, [x16]
    b710:      	fmov	d31, x1
    b714:      	mov	x1, x2
    b718:      	fmov	x2, d31
    b71c:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000b71c:  ARM64_RELOC_PAGE21	l_stogir.493
    b720:      	ldr	x3, [x3]
		000000000000b720:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b724:      	mov	x4, #0x4                ; =4
    b728:      	mov	x5, #0x4                ; =4
    b72c:      	bl	0xb72c <_stogir.dominators.build-index+0x50c>
		000000000000b72c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b730:      	add	x16, sp, #0xc0
    b734:      	movz	x17, #0x0, lsl #48
    b738:      	str	x17, [x16]
    b73c:      	add	x16, sp, #0xc0
    b740:      	movz	x17, #0x0, lsl #48
    b744:      	str	x17, [x16, #0x8]
    b748:      	add	x16, sp, #0xc0
    b74c:      	movz	x17, #0x0, lsl #48
    b750:      	str	x17, [x16, #0x10]
    b754:      	b	0xb764 <_stogir.dominators.build-index+0x544>
    b758:      	sub	x0, x0, #0x1
    b75c:      	add	x16, sp, #0x90
    b760:      	str	x0, [x16, #0x8]
    b764:      	add	x16, sp, #0x90
    b768:      	ldr	x0, [x16, #0x8]
    b76c:      	cmp	x0, #0x0
    b770:      	b.ne	0xb758 <_stogir.dominators.build-index+0x538>
    b774:      	add	x16, sp, #0x90
    b778:      	orr	x0, x16, xzr
    b77c:      	add	x16, sp, #0x90
    b780:      	ldr	x1, [x16, #0x10]
    b784:      	cmp	x1, #0x0
    b788:      	b.le	0xb7b8 <_stogir.dominators.build-index+0x598>
    b78c:      	add	x0, x0, #0x18
    b790:      	add	x16, sp, #0x90
    b794:      	ldr	x2, [x16]
    b798:      	fmov	d31, x1
    b79c:      	mov	x1, x2
    b7a0:      	fmov	x2, d31
    b7a4:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000b7a4:  ARM64_RELOC_PAGE21	l_stogir.493
    b7a8:      	ldr	x3, [x3]
		000000000000b7a8:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b7ac:      	mov	x4, #0x4                ; =4
    b7b0:      	mov	x5, #0x4                ; =4
    b7b4:      	bl	0xb7b4 <_stogir.dominators.build-index+0x594>
		000000000000b7b4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b7b8:      	add	x16, sp, #0x90
    b7bc:      	movz	x17, #0x0, lsl #48
    b7c0:      	str	x17, [x16]
    b7c4:      	add	x16, sp, #0x90
    b7c8:      	movz	x17, #0x0, lsl #48
    b7cc:      	str	x17, [x16, #0x8]
    b7d0:      	add	x16, sp, #0x90
    b7d4:      	movz	x17, #0x0, lsl #48
    b7d8:      	str	x17, [x16, #0x10]
    b7dc:      	b	0xb7ec <_stogir.dominators.build-index+0x5cc>
    b7e0:      	sub	x0, x0, #0x1
    b7e4:      	add	x16, sp, #0x60
    b7e8:      	str	x0, [x16, #0x8]
    b7ec:      	add	x16, sp, #0x60
    b7f0:      	ldr	x0, [x16, #0x8]
    b7f4:      	cmp	x0, #0x0
    b7f8:      	b.ne	0xb7e0 <_stogir.dominators.build-index+0x5c0>
    b7fc:      	add	x16, sp, #0x60
    b800:      	orr	x0, x16, xzr
    b804:      	add	x16, sp, #0x60
    b808:      	ldr	x1, [x16, #0x10]
    b80c:      	cmp	x1, #0x0
    b810:      	b.le	0xb840 <_stogir.dominators.build-index+0x620>
    b814:      	add	x0, x0, #0x18
    b818:      	add	x16, sp, #0x60
    b81c:      	ldr	x2, [x16]
    b820:      	fmov	d31, x1
    b824:      	mov	x1, x2
    b828:      	fmov	x2, d31
    b82c:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000b82c:  ARM64_RELOC_PAGE21	l_stogir.493
    b830:      	ldr	x3, [x3]
		000000000000b830:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b834:      	mov	x4, #0x4                ; =4
    b838:      	mov	x5, #0x4                ; =4
    b83c:      	bl	0xb83c <_stogir.dominators.build-index+0x61c>
		000000000000b83c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b840:      	add	x16, sp, #0x60
    b844:      	movz	x17, #0x0, lsl #48
    b848:      	str	x17, [x16]
    b84c:      	add	x16, sp, #0x60
    b850:      	movz	x17, #0x0, lsl #48
    b854:      	str	x17, [x16, #0x8]
    b858:      	add	x16, sp, #0x60
    b85c:      	movz	x17, #0x0, lsl #48
    b860:      	str	x17, [x16, #0x10]
    b864:      	add	x16, sp, #0x10
    b868:      	ldr	x0, [x16]
    b86c:      	add	x16, sp, #0x10
    b870:      	ldr	x1, [x16, #0x8]
    b874:      	add	x16, sp, #0x10
    b878:      	ldr	x2, [x16, #0x10]
    b87c:      	add	x16, sp, #0x10
    b880:      	ldr	x3, [x16, #0x18]
    b884:      	add	x16, sp, #0x10
    b888:      	ldr	x4, [x16, #0x20]
    b88c:      	add	x16, sp, #0x10
    b890:      	ldr	x5, [x16, #0x28]
    b894:      	add	x16, sp, #0x10
    b898:      	ldr	x6, [x16, #0x30]
    b89c:      	add	x16, sp, #0x10
    b8a0:      	ldr	x7, [x16, #0x38]
    b8a4:      	add	x16, sp, #0x10
    b8a8:      	ldr	x8, [x16, #0x40]
    b8ac:      	add	x16, sp, #0x10
    b8b0:      	ldr	x9, [x16, #0x48]
    b8b4:      	str	x0, [x20]
    b8b8:      	str	x1, [x20, #0x8]
    b8bc:      	str	x2, [x20, #0x10]
    b8c0:      	str	x3, [x20, #0x18]
    b8c4:      	str	x4, [x20, #0x20]
    b8c8:      	str	x5, [x20, #0x28]
    b8cc:      	str	x6, [x20, #0x30]
    b8d0:      	str	x7, [x20, #0x38]
    b8d4:      	str	x8, [x20, #0x40]
    b8d8:      	str	x9, [x20, #0x48]
    b8dc:      	ldr	x19, [sp, #0xf0]
    b8e0:      	ldr	x20, [sp, #0xf8]
    b8e4:      	ldr	x21, [sp, #0x100]
    b8e8:      	ldr	x22, [sp, #0x108]
    b8ec:      	ldr	x23, [sp, #0x110]
    b8f0:      	ldr	x24, [sp, #0x118]
    b8f4:      	ldr	x25, [sp, #0x120]
    b8f8:      	ldr	x29, [sp]
    b8fc:      	ldr	x30, [sp, #0x8]
    b900:      	add	sp, sp, #0x130
    b904:      	ret
    b908:      	mov	x20, x8
    b90c:      	mov	x21, x0
    b910:      	b	0xb38c <_stogir.dominators.build-index+0x16c>
    b914:      	udf	#0x0

000000000000b918 <_stogir.dominators.release-index!>:
    b918:      	sub	sp, sp, #0x20
    b91c:      	str	x29, [sp]
    b920:      	str	x30, [sp, #0x8]
    b924:      	mov	x29, sp
    b928:      	str	x19, [sp, #0x10]
    b92c:      	str	x20, [sp, #0x18]
    b930:      	b	0xb940 <_stogir.dominators.release-index!+0x28>
    b934:      	nop
    b938:      	sub	x1, x1, #0x1
    b93c:      	str	x1, [x0, #0x8]
    b940:      	ldr	x1, [x0, #0x8]
    b944:      	cmp	x1, #0x0
    b948:      	b.ne	0xb938 <_stogir.dominators.release-index!+0x20>
    b94c:      	ldr	x1, [x0, #0x10]
    b950:      	cmp	x1, #0x0
    b954:      	b.le	0xba24 <_stogir.dominators.release-index!+0x10c>
    b958:      	add	x2, x0, #0x18
    b95c:      	ldr	x3, [x0]
    b960:      	mov	x19, x0
    b964:      	mov	x0, x2
    b968:      	mov	x2, x1
    b96c:      	mov	x1, x3
    b970:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000b970:  ARM64_RELOC_PAGE21	l_stogir.494
    b974:      	ldr	x3, [x3]
		000000000000b974:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    b978:      	mov	x4, #0x4                ; =4
    b97c:      	mov	x5, #0x4                ; =4
    b980:      	bl	0xb980 <_stogir.dominators.release-index!+0x68>
		000000000000b980:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b984:      	add	x20, x19, #0x28
    b988:      	movz	x17, #0x0, lsl #48
    b98c:      	str	x17, [x19]
    b990:      	movz	x17, #0x0, lsl #48
    b994:      	str	x17, [x19, #0x8]
    b998:      	movz	x17, #0x0, lsl #48
    b99c:      	str	x17, [x19, #0x10]
    b9a0:      	b	0xb9b0 <_stogir.dominators.release-index!+0x98>
    b9a4:      	nop
    b9a8:      	sub	x0, x0, #0x1
    b9ac:      	str	x0, [x20, #0x8]
    b9b0:      	ldr	x0, [x20, #0x8]
    b9b4:      	cmp	x0, #0x0
    b9b8:      	b.ne	0xb9a8 <_stogir.dominators.release-index!+0x90>
    b9bc:      	ldr	x0, [x20, #0x10]
    b9c0:      	cmp	x0, #0x0
    b9c4:      	b.le	0xb9f4 <_stogir.dominators.release-index!+0xdc>
    b9c8:      	add	x1, x20, #0x18
    b9cc:      	ldr	x2, [x19, #0x28]
    b9d0:      	fmov	d31, x0
    b9d4:      	mov	x0, x1
    b9d8:      	mov	x1, x2
    b9dc:      	fmov	x2, d31
    b9e0:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000b9e0:  ARM64_RELOC_PAGE21	l_stogir.494
    b9e4:      	ldr	x3, [x3]
		000000000000b9e4:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    b9e8:      	mov	x4, #0x4                ; =4
    b9ec:      	mov	x5, #0x4                ; =4
    b9f0:      	bl	0xb9f0 <_stogir.dominators.release-index!+0xd8>
		000000000000b9f0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b9f4:      	movz	x17, #0x0, lsl #48
    b9f8:      	str	x17, [x19, #0x28]
    b9fc:      	movz	x17, #0x0, lsl #48
    ba00:      	str	x17, [x20, #0x8]
    ba04:      	movz	x17, #0x0, lsl #48
    ba08:      	str	x17, [x20, #0x10]
    ba0c:      	ldr	x19, [sp, #0x10]
    ba10:      	ldr	x20, [sp, #0x18]
    ba14:      	ldr	x29, [sp]
    ba18:      	ldr	x30, [sp, #0x8]
    ba1c:      	add	sp, sp, #0x20
    ba20:      	ret
    ba24:      	mov	x19, x0
    ba28:      	b	0xb984 <_stogir.dominators.release-index!+0x6c>

000000000000ba2c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64>:
    ba2c:      	sub	sp, sp, #0x30
    ba30:      	str	x29, [sp]
    ba34:      	str	x30, [sp, #0x8]
    ba38:      	mov	x29, sp
    ba3c:      	str	x19, [sp, #0x10]
    ba40:      	str	x20, [sp, #0x18]
    ba44:      	str	x21, [sp, #0x20]
    ba48:      	str	x22, [sp, #0x28]
    ba4c:      	ldr	x2, [x0, #0x8]
    ba50:      	orr	x19, x2, xzr
    ba54:      	ldr	x2, [x0, #0x10]
    ba58:      	add	x20, x19, x1
    ba5c:      	cmp	x20, x2
    ba60:      	b.le	0xbadc <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0xb0>
    ba64:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    ba68:      	cmp	x2, x17
    ba6c:      	b.gt	0xba78 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x4c>
    ba70:      	lsl	x2, x2, #1
    ba74:      	b	0xba7c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x50>
    ba78:      	mov	x2, x20
    ba7c:      	cmp	x2, x20
    ba80:      	b.gt	0xba88 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x5c>
    ba84:      	mov	x2, x20
    ba88:      	mov	x21, x0
    ba8c:      	mov	x22, x1
    ba90:      	mov	x1, x2
    ba94:      	bl	0xba94 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x68>
		000000000000ba94:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    ba98:      	lsl	x0, x22, #3
    ba9c:      	ldr	x1, [x21]
    baa0:      	add	x1, x1, x19, lsl #3
    baa4:      	mov	x2, x0
    baa8:      	mov	x0, x1
    baac:      	movz	x1, #0x0, lsl #48
    bab0:      	bl	0xbab0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x84>
		000000000000bab0:  ARM64_RELOC_BRANCH26	_memset
    bab4:      	str	x20, [x21, #0x8]
    bab8:      	mov	x0, x20
    babc:      	ldr	x19, [sp, #0x10]
    bac0:      	ldr	x20, [sp, #0x18]
    bac4:      	ldr	x21, [sp, #0x20]
    bac8:      	ldr	x22, [sp, #0x28]
    bacc:      	ldr	x29, [sp]
    bad0:      	ldr	x30, [sp, #0x8]
    bad4:      	add	sp, sp, #0x30
    bad8:      	ret
    badc:      	mov	x21, x0
    bae0:      	mov	x22, x1
    bae4:      	b	0xba98 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x6c>

000000000000bae8 <_stogir.uses.scan!__constfalse>:
    bae8:      	sub	sp, sp, #0x10
    baec:      	mov	x3, #0x1                ; =1
    baf0:      	b	0xbc14 <_stogir.uses.scan!__constfalse+0x12c>
    baf4:      	sub	w10, w8, #0x1
    baf8:      	lsl	w10, w10, #2
    bafc:      	ubfx	x10, x10, #0, #32
    bb00:      	lsr	x10, x5, x10
    bb04:      	and	w10, w10, #0xf
    bb08:      	b	0xbb14 <_stogir.uses.scan!__constfalse+0x2c>
    bb0c:      	nop
    bb10:      	movz	w10, #0x0, lsl #16
    bb14:      	ubfx	x10, x10, #0, #32
    bb18:      	cmp	x10, #0xf
    bb1c:      	b.hs	0xbbcc <_stogir.uses.scan!__constfalse+0xe4>
    bb20:      	mov	x16, #0x1               ; =1
    bb24:      	lsl	x10, x16, x10
    bb28:      	mov	w17, #0x5e1c            ; =24092
    bb2c:      	and	w10, w10, w17
    bb30:      	ubfx	x10, x10, #0, #32
    bb34:      	cmp	x10, #0x0
    bb38:      	b.eq	0xbbcc <_stogir.uses.scan!__constfalse+0xe4>
    bb3c:      	ldr	x10, [x0]
    bb40:      	asr	x16, x9, #63
    bb44:      	lsr	x16, x16, #62
    bb48:      	add	x11, x9, x16
    bb4c:      	asr	x11, x11, #2
    bb50:      	asr	x16, x9, #63
    bb54:      	lsr	x16, x16, #62
    bb58:      	add	x9, x9, x16
    bb5c:      	and	x9, x9, #0x3
    bb60:      	sub	x9, x9, x16
    bb64:      	add	x11, x11, x3
    bb68:      	add	x10, x10, x11, lsl #4
    bb6c:      	add	x9, x10, x9, lsl #2
    bb70:      	ldr	w9, [x9]
    bb74:      	sxtw	x9, w9
    bb78:      	cmp	x9, #0x0
    bb7c:      	b.le	0xbbcc <_stogir.uses.scan!__constfalse+0xe4>
    bb80:      	ldr	x10, [x2]
    bb84:      	add	x10, x10, x9, lsl #3
    bb88:      	ldr	x10, [x10]
    bb8c:      	mov	x16, sp
    bb90:      	movz	x17, #0x0, lsl #48
    bb94:      	str	x17, [x16]
    bb98:      	add	x11, x10, #0x1
    bb9c:      	mov	x16, sp
    bba0:      	str	w4, [x16]
    bba4:      	mov	x16, sp
    bba8:      	str	w8, [x16, #0x4]
    bbac:      	mov	x16, sp
    bbb0:      	ldr	x8, [x16]
    bbb4:      	ldr	x12, [x1, #0x28]
    bbb8:      	add	x10, x12, x10, lsl #3
    bbbc:      	str	x8, [x10]
    bbc0:      	ldr	x8, [x2]
    bbc4:      	add	x8, x8, x9, lsl #3
    bbc8:      	str	x11, [x8]
    bbcc:      	add	x7, x7, #0x1
    bbd0:      	sxtw	x7, w7
    bbd4:      	cmp	x7, x6
    bbd8:      	b.gt	0xbbfc <_stogir.uses.scan!__constfalse+0x114>
    bbdc:      	orr	w8, w7, wzr
    bbe0:      	sxtw	x9, w8
    bbe4:      	cmp	x9, #0x0
    bbe8:      	b.le	0xbb10 <_stogir.uses.scan!__constfalse+0x28>
    bbec:      	cmp	x9, #0x4
    bbf0:      	b.le	0xbaf4 <_stogir.uses.scan!__constfalse+0xc>
    bbf4:      	mov	w10, #0x4               ; =4
    bbf8:      	b	0xbaf8 <_stogir.uses.scan!__constfalse+0x10>
    bbfc:      	add	x4, x6, #0x4
    bc00:      	asr	x16, x4, #63
    bc04:      	lsr	x16, x16, #62
    bc08:      	add	x4, x4, x16
    bc0c:      	asr	x4, x4, #2
    bc10:      	add	x3, x4, x3
    bc14:      	ldr	x4, [x0, #0x8]
    bc18:      	cmp	x3, x4
    bc1c:      	b.ge	0xbc5c <_stogir.uses.scan!__constfalse+0x174>
    bc20:      	orr	w4, w3, wzr
    bc24:      	ldr	x5, [x0]
    bc28:      	add	x5, x5, x3, lsl #4
    bc2c:      	ldr	x5, [x5]
    bc30:      	ldr	x6, [x0, #0x78]
    bc34:      	uxtb	w5, w5
    bc38:      	add	x6, x6, x3, lsl #2
    bc3c:      	adrp	x16, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000bc3c:  ARM64_RELOC_PAGE21	l_stogir.495
    bc40:      	ldr	x16, [x16]
		000000000000bc40:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    bc44:      	add	x5, x16, x5, lsl #2
    bc48:      	ldr	w6, [x6]
    bc4c:      	sxtw	x6, w6
    bc50:      	ldr	w5, [x5]
    bc54:      	mov	x7, #0x1                ; =1
    bc58:      	b	0xbbd4 <_stogir.uses.scan!__constfalse+0xec>
    bc5c:      	add	sp, sp, #0x10
    bc60:      	ret

000000000000bc64 <_stogir.opcode.properties>:
    bc64:      	sxtw	x0, w0
    bc68:      	cmp	x0, #0x0
    bc6c:      	b.lt	0xbc8c <_stogir.opcode.properties+0x28>
    bc70:      	cmp	x0, #0x83
    bc74:      	b.ge	0xbc8c <_stogir.opcode.properties+0x28>
    bc78:      	adrp	x16, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000bc78:  ARM64_RELOC_PAGE21	l_stogir.496
    bc7c:      	ldr	x16, [x16]
		000000000000bc7c:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    bc80:      	add	x0, x16, x0
    bc84:      	ldrb	w0, [x0]
    bc88:      	b	0xbc90 <_stogir.opcode.properties+0x2c>
    bc8c:      	movz	x0, #0x0, lsl #48
    bc90:      	ret

000000000000bc94 <_stogir.graph.lookup>:
    bc94:      	sxtw	x1, w1
    bc98:      	add	x2, x0, #0x28
    bc9c:      	cmp	x1, #0x0
    bca0:      	cset	w3, gt
    bca4:      	movz	x16, #0x0, lsl #48
    bca8:      	sub	x4, x16, x1
    bcac:      	sub	x5, x4, #0x1
    bcb0:      	uxtb	w16, w3
    bcb4:      	cmp	w16, wzr
    bcb8:      	b.eq	0xbcf8 <_stogir.graph.lookup+0x64>
    bcbc:      	ldr	x2, [x0, #0x8]
    bcc0:      	cmp	x1, x2
    bcc4:      	b.ge	0xbd44 <_stogir.graph.lookup+0xb0>
    bcc8:      	add	x2, x0, #0x78
    bccc:      	ldr	x2, [x2, #0x8]
    bcd0:      	cmp	x1, x2
    bcd4:      	b.ge	0xbdbc <_stogir.graph.lookup+0x128>
    bcd8:      	ldr	x2, [x0, #0x78]
    bcdc:      	add	x2, x2, x1, lsl #2
    bce0:      	ldr	w2, [x2]
    bce4:      	sxtw	x2, w2
    bce8:      	cmp	x2, #0x0
    bcec:      	cset	w2, ge
    bcf0:      	ubfx	x2, x2, #0, #8
    bcf4:      	b	0xbdc0 <_stogir.graph.lookup+0x12c>
    bcf8:      	cmp	x1, #0x0
    bcfc:      	b.ge	0xbd4c <_stogir.graph.lookup+0xb8>
    bd00:      	add	x6, x0, #0x50
    bd04:      	ldr	x2, [x2, #0x8]
    bd08:      	ldr	x6, [x6, #0x8]
    bd0c:      	cmp	x2, x6
    bd10:      	b.ne	0xbd3c <_stogir.graph.lookup+0xa8>
    bd14:      	cmp	x4, x2
    bd18:      	b.gt	0xbdc4 <_stogir.graph.lookup+0x130>
    bd1c:      	ldr	x2, [x0, #0x50]
    bd20:      	add	x2, x2, x5, lsl #2
    bd24:      	ldr	w2, [x2]
    bd28:      	sxtw	x2, w2
    bd2c:      	cmp	x2, #0x0
    bd30:      	cset	w2, gt
    bd34:      	ubfx	x2, x2, #0, #8
    bd38:      	b	0xbdc8 <_stogir.graph.lookup+0x134>
    bd3c:      	movz	x2, #0x0, lsl #48
    bd40:      	b	0xbd50 <_stogir.graph.lookup+0xbc>
    bd44:      	movz	x2, #0x0, lsl #48
    bd48:      	b	0xbd50 <_stogir.graph.lookup+0xbc>
    bd4c:      	movz	x2, #0x0, lsl #48
    bd50:      	cmp	x2, #0x0
    bd54:      	b.eq	0xbd90 <_stogir.graph.lookup+0xfc>
    bd58:      	uxtb	w16, w3
    bd5c:      	cmp	w16, wzr
    bd60:      	b.eq	0xbd78 <_stogir.graph.lookup+0xe4>
    bd64:      	ldr	x0, [x0]
    bd68:      	add	x0, x0, x1, lsl #4
    bd6c:      	ldr	x1, [x0]
    bd70:      	ldr	x0, [x0, #0x8]
    bd74:      	b	0xbd88 <_stogir.graph.lookup+0xf4>
    bd78:      	ldr	x0, [x0, #0x28]
    bd7c:      	add	x0, x0, x5, lsl #4
    bd80:      	ldr	x1, [x0]
    bd84:      	ldr	x0, [x0, #0x8]
    bd88:      	mov	x2, #0x1                ; =1
    bd8c:      	b	0xbd9c <_stogir.graph.lookup+0x108>
    bd90:      	movz	x2, #0x0, lsl #48
    bd94:      	movz	x1, #0x0, lsl #48
    bd98:      	movz	x0, #0x0, lsl #48
    bd9c:      	str	x2, [x8]
    bda0:      	str	x1, [x8, #0x8]
    bda4:      	str	x0, [x8, #0x10]
    bda8:      	movz	x17, #0x0, lsl #48
    bdac:      	str	x17, [x8, #0x18]
    bdb0:      	movz	x17, #0x0, lsl #48
    bdb4:      	str	x17, [x8, #0x20]
    bdb8:      	ret
    bdbc:      	movz	x2, #0x0, lsl #48
    bdc0:      	b	0xbd48 <_stogir.graph.lookup+0xb4>
    bdc4:      	movz	x2, #0x0, lsl #48
    bdc8:      	b	0xbd40 <_stogir.graph.lookup+0xac>
    bdcc:      	udf	#0x0

000000000000bdd0 <_stogir.dominators.dominates?>:
    bdd0:      	sxtw	x1, w1
    bdd4:      	sxtw	x2, w2
    bdd8:      	movz	x3, #0x0, lsl #48
    bddc:      	movz	x4, #0x0, lsl #48
    bde0:      	b	0xbdf4 <_stogir.dominators.dominates?+0x24>
    bde4:      	mov	x2, x5
    bde8:      	b	0xbdf4 <_stogir.dominators.dominates?+0x24>
    bdec:      	nop
    bdf0:      	mov	x3, #0x1                ; =1
    bdf4:      	cmp	x3, #0x0
    bdf8:      	b.ne	0xbe44 <_stogir.dominators.dominates?+0x74>
    bdfc:      	cmp	x2, #0x0
    be00:      	b.le	0xbdf0 <_stogir.dominators.dominates?+0x20>
    be04:      	ldr	x5, [x0, #0x8]
    be08:      	cmp	x2, x5
    be0c:      	b.ge	0xbdf0 <_stogir.dominators.dominates?+0x20>
    be10:      	ldr	x5, [x0]
    be14:      	add	x5, x5, x2, lsl #2
    be18:      	ldr	w5, [x5]
    be1c:      	sxtw	x5, w5
    be20:      	cmp	x5, #0x0
    be24:      	b.ne	0xbe30 <_stogir.dominators.dominates?+0x60>
    be28:      	mov	x3, #0x1                ; =1
    be2c:      	b	0xbde8 <_stogir.dominators.dominates?+0x18>
    be30:      	cmp	x2, x1
    be34:      	b.ne	0xbe4c <_stogir.dominators.dominates?+0x7c>
    be38:      	mov	x3, #0x1                ; =1
    be3c:      	mov	x4, #0x1                ; =1
    be40:      	b	0xbde8 <_stogir.dominators.dominates?+0x18>
    be44:      	mov	x0, x4
    be48:      	ret
    be4c:      	cmp	x2, x5
    be50:      	b.ne	0xbde4 <_stogir.dominators.dominates?+0x14>
    be54:      	mov	x3, #0x1                ; =1
    be58:      	b	0xbde8 <_stogir.dominators.dominates?+0x18>

000000000000be5c <_stogir.placement.use-block>:
    be5c:      	sub	sp, sp, #0x50
    be60:      	str	x29, [sp, #0x10]
    be64:      	str	x30, [sp, #0x18]
    be68:      	add	x29, sp, #0x10
    be6c:      	str	x19, [sp, #0x30]
    be70:      	str	x20, [sp, #0x38]
    be74:      	str	x21, [sp, #0x40]
    be78:      	str	x22, [sp, #0x48]
    be7c:      	sxtw	x2, w2
    be80:      	add	x19, x0, #0x78
    be84:      	add	x4, x0, #0x28
    be88:      	lsl	x5, x2, #2
    be8c:      	cmp	x2, #0x0
    be90:      	cset	w6, gt
    be94:      	movz	x16, #0x0, lsl #48
    be98:      	sub	x7, x16, x2
    be9c:      	sub	x9, x7, #0x1
    bea0:      	uxtb	w16, w6
    bea4:      	cmp	w16, wzr
    bea8:      	b.eq	0xbee4 <_stogir.placement.use-block+0x88>
    beac:      	ldr	x4, [x0, #0x8]
    beb0:      	cmp	x2, x4
    beb4:      	b.ge	0xbf30 <_stogir.placement.use-block+0xd4>
    beb8:      	ldr	x4, [x19, #0x8]
    bebc:      	cmp	x2, x4
    bec0:      	b.ge	0xc010 <_stogir.placement.use-block+0x1b4>
    bec4:      	ldr	x4, [x0, #0x78]
    bec8:      	add	x4, x5, x4
    becc:      	ldr	w4, [x4]
    bed0:      	sxtw	x4, w4
    bed4:      	cmp	x4, #0x0
    bed8:      	cset	w4, ge
    bedc:      	ubfx	x4, x4, #0, #8
    bee0:      	b	0xc014 <_stogir.placement.use-block+0x1b8>
    bee4:      	cmp	x2, #0x0
    bee8:      	b.ge	0xbf38 <_stogir.placement.use-block+0xdc>
    beec:      	add	x10, x0, #0x50
    bef0:      	ldr	x4, [x4, #0x8]
    bef4:      	ldr	x10, [x10, #0x8]
    bef8:      	cmp	x4, x10
    befc:      	b.ne	0xbf28 <_stogir.placement.use-block+0xcc>
    bf00:      	cmp	x7, x4
    bf04:      	b.gt	0xc02c <_stogir.placement.use-block+0x1d0>
    bf08:      	ldr	x4, [x0, #0x50]
    bf0c:      	add	x4, x4, x9, lsl #2
    bf10:      	ldr	w4, [x4]
    bf14:      	sxtw	x4, w4
    bf18:      	cmp	x4, #0x0
    bf1c:      	cset	w4, gt
    bf20:      	ubfx	x4, x4, #0, #8
    bf24:      	b	0xc030 <_stogir.placement.use-block+0x1d4>
    bf28:      	movz	x4, #0x0, lsl #48
    bf2c:      	b	0xbf3c <_stogir.placement.use-block+0xe0>
    bf30:      	movz	x4, #0x0, lsl #48
    bf34:      	b	0xbf3c <_stogir.placement.use-block+0xe0>
    bf38:      	movz	x4, #0x0, lsl #48
    bf3c:      	lsl	x7, x2, #4
    bf40:      	cmp	x4, #0x0
    bf44:      	b.eq	0xbf78 <_stogir.placement.use-block+0x11c>
    bf48:      	uxtb	w16, w6
    bf4c:      	cmp	w16, wzr
    bf50:      	b.eq	0xbf64 <_stogir.placement.use-block+0x108>
    bf54:      	ldr	x4, [x0]
    bf58:      	add	x4, x7, x4
    bf5c:      	ldr	x4, [x4]
    bf60:      	b	0xbf70 <_stogir.placement.use-block+0x114>
    bf64:      	ldr	x4, [x0, #0x28]
    bf68:      	add	x4, x4, x9, lsl #4
    bf6c:      	ldr	x4, [x4]
    bf70:      	mov	w6, #0x1                ; =1
    bf74:      	b	0xbf80 <_stogir.placement.use-block+0x124>
    bf78:      	movz	w6, #0x0, lsl #16
    bf7c:      	movz	x4, #0x0, lsl #48
    bf80:      	ubfx	x6, x6, #0, #32
    bf84:      	lsr	x16, x6, #0
    bf88:      	cmp	x16, #0x1
    bf8c:      	b.eq	0xbfa8 <_stogir.placement.use-block+0x14c>
    bf90:      	b.lo	0xbf98 <_stogir.placement.use-block+0x13c>
    bf94:      	b	0xbfac <_stogir.placement.use-block+0x150>
    bf98:      	cmp	x16, #0x0
    bf9c:      	b.eq	0xbfa4 <_stogir.placement.use-block+0x148>
    bfa0:      	b	0xbfac <_stogir.placement.use-block+0x150>
    bfa4:      	b	0xbfb0 <_stogir.placement.use-block+0x154>
    bfa8:      	b	0xbff0 <_stogir.placement.use-block+0x194>
    bfac:      	b	0xc0d0 <_stogir.placement.use-block+0x274>
    bfb0:      	mov	x20, x8
    bfb4:      	mov	x1, #0x1                ; =1
    bfb8:      	adrp	x0, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xac>
		000000000000bfb8:  ARM64_RELOC_PAGE21	l_stogir.497
    bfbc:      	ldr	x0, [x0]
		000000000000bfbc:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    bfc0:      	mov	x2, #0x21               ; =33
    bfc4:      	str	x1, [x20]
    bfc8:      	str	x0, [x20, #0x8]
    bfcc:      	str	x2, [x20, #0x10]
    bfd0:      	ldr	x19, [sp, #0x30]
    bfd4:      	ldr	x20, [sp, #0x38]
    bfd8:      	ldr	x21, [sp, #0x40]
    bfdc:      	ldr	x22, [sp, #0x48]
    bfe0:      	ldr	x29, [sp, #0x10]
    bfe4:      	ldr	x30, [sp, #0x18]
    bfe8:      	add	sp, sp, #0x50
    bfec:      	ret
    bff0:      	cmp	x2, #0x0
    bff4:      	b.gt	0xc018 <_stogir.placement.use-block+0x1bc>
    bff8:      	mov	x20, x8
    bffc:      	mov	x1, #0x1                ; =1
    c000:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c000:  ARM64_RELOC_PAGE21	l_stogir.498
    c004:      	ldr	x0, [x0]
		000000000000c004:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    c008:      	mov	x2, #0x13               ; =19
    c00c:      	b	0xbfc4 <_stogir.placement.use-block+0x168>
    c010:      	movz	x4, #0x0, lsl #48
    c014:      	b	0xbf34 <_stogir.placement.use-block+0xd8>
    c018:      	sxtw	x6, w3
    c01c:      	cmp	x6, #0x1
    c020:      	b.ge	0xc034 <_stogir.placement.use-block+0x1d8>
    c024:      	mov	x20, x8
    c028:      	b	0xbffc <_stogir.placement.use-block+0x1a0>
    c02c:      	movz	x4, #0x0, lsl #48
    c030:      	b	0xbf2c <_stogir.placement.use-block+0xd0>
    c034:      	ldr	x9, [x0, #0x78]
    c038:      	add	x10, x5, x9
    c03c:      	ldr	w10, [x10]
    c040:      	sxtw	x10, w10
    c044:      	cmp	x6, x10
    c048:      	b.gt	0xc298 <_stogir.placement.use-block+0x43c>
    c04c:      	uxtb	w4, w4
    c050:      	cmp	x4, #0x43
    c054:      	b.ne	0xc2a0 <_stogir.placement.use-block+0x444>
    c058:      	cmp	x6, #0x2
    c05c:      	b.lt	0xc2ac <_stogir.placement.use-block+0x450>
    c060:      	ldr	x4, [x0, #0x8]
    c064:      	cmp	x2, x4
    c068:      	b.ge	0xc134 <_stogir.placement.use-block+0x2d8>
    c06c:      	ldr	x4, [x19, #0x8]
    c070:      	cmp	x2, x4
    c074:      	b.ge	0xc174 <_stogir.placement.use-block+0x318>
    c078:      	add	x2, x5, x9
    c07c:      	ldr	w2, [x2]
    c080:      	sxtw	x2, w2
    c084:      	cmp	x2, #0x0
    c088:      	cset	w2, ge
    c08c:      	ubfx	x2, x2, #0, #8
    c090:      	b	0xc178 <_stogir.placement.use-block+0x31c>
    c094:      	and	x0, x0, #0xffffffff
    c098:      	movz	x1, #0x0, lsl #48
    c09c:      	movz	x2, #0x0, lsl #48
    c0a0:      	b	0xc00c <_stogir.placement.use-block+0x1b0>
    c0a4:      	ldr	x0, [x22]
    c0a8:      	add	x0, x0, x2, lsl #2
    c0ac:      	ldr	w0, [x0]
    c0b0:      	sxtw	x0, w0
    c0b4:      	cmp	x0, #0x0
    c0b8:      	b.ne	0xc094 <_stogir.placement.use-block+0x238>
    c0bc:      	mov	x1, #0x1                ; =1
    c0c0:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c0c0:  ARM64_RELOC_PAGE21	l_stogir.499
    c0c4:      	ldr	x0, [x0]
		000000000000c0c4:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    c0c8:      	mov	x2, #0xf                ; =15
    c0cc:      	b	0xc0a0 <_stogir.placement.use-block+0x244>
    c0d0:      	brk	#0
    c0d4:      	b	0xc0d0 <_stogir.placement.use-block+0x274>
    c0d8:      	movz	w4, #0x0, lsl #16
    c0dc:      	movz	w2, #0x0, lsl #16
    c0e0:      	ubfx	x4, x4, #0, #32
    c0e4:      	lsr	x16, x4, #0
    c0e8:      	cmp	x16, #0x1
    c0ec:      	b.eq	0xc108 <_stogir.placement.use-block+0x2ac>
    c0f0:      	b.lo	0xc0f8 <_stogir.placement.use-block+0x29c>
    c0f4:      	b	0xc10c <_stogir.placement.use-block+0x2b0>
    c0f8:      	cmp	x16, #0x0
    c0fc:      	b.eq	0xc104 <_stogir.placement.use-block+0x2a8>
    c100:      	b	0xc10c <_stogir.placement.use-block+0x2b0>
    c104:      	b	0xc110 <_stogir.placement.use-block+0x2b4>
    c108:      	b	0xc17c <_stogir.placement.use-block+0x320>
    c10c:      	b	0xc288 <_stogir.placement.use-block+0x42c>
    c110:      	mov	x20, x8
    c114:      	mov	x1, #0x1                ; =1
    c118:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c118:  ARM64_RELOC_PAGE21	l_stogir.500
    c11c:      	ldr	x0, [x0]
		000000000000c11c:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c120:      	mov	x2, #0x12               ; =18
    c124:      	b	0xc0a0 <_stogir.placement.use-block+0x244>
    c128:      	movz	w4, #0x0, lsl #16
    c12c:      	movz	w2, #0x0, lsl #16
    c130:      	b	0xc0e0 <_stogir.placement.use-block+0x284>
    c134:      	movz	x2, #0x0, lsl #48
    c138:      	cmp	x2, #0x0
    c13c:      	b.eq	0xc0d8 <_stogir.placement.use-block+0x27c>
    c140:      	ldr	x2, [x0, #0x78]
    c144:      	add	x2, x5, x2
    c148:      	ldr	w2, [x2]
    c14c:      	sxtw	x2, w2
    c150:      	cmp	x2, #0x1
    c154:      	b.lt	0xc128 <_stogir.placement.use-block+0x2cc>
    c158:      	ldr	x2, [x0]
    c15c:      	add	x2, x7, x2
    c160:      	ldr	w2, [x2, #0x4]
    c164:      	movn	w17, #0x0, lsl #16
    c168:      	and	w2, w2, w17
    c16c:      	mov	w4, #0x1                ; =1
    c170:      	b	0xc130 <_stogir.placement.use-block+0x2d4>
    c174:      	movz	x2, #0x0, lsl #48
    c178:      	b	0xc138 <_stogir.placement.use-block+0x2dc>
    c17c:      	sub	w3, w3, #0x1
    c180:      	mov	x20, x8
    c184:      	mov	x21, x0
    c188:      	mov	x22, x1
    c18c:      	mov	w1, w2
    c190:      	mov	w2, w3
    c194:      	bl	0xc194 <_stogir.placement.use-block+0x338>
		000000000000c194:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    c198:      	ubfx	x0, x0, #0, #32
    c19c:      	lsr	x16, x0, #0
    c1a0:      	cmp	x16, #0x1
    c1a4:      	b.eq	0xc1c0 <_stogir.placement.use-block+0x364>
    c1a8:      	b.lo	0xc1b0 <_stogir.placement.use-block+0x354>
    c1ac:      	b	0xc1c4 <_stogir.placement.use-block+0x368>
    c1b0:      	cmp	x16, #0x0
    c1b4:      	b.eq	0xc1bc <_stogir.placement.use-block+0x360>
    c1b8:      	b	0xc1c4 <_stogir.placement.use-block+0x368>
    c1bc:      	b	0xc1c8 <_stogir.placement.use-block+0x36c>
    c1c0:      	b	0xc1f0 <_stogir.placement.use-block+0x394>
    c1c4:      	b	0xc290 <_stogir.placement.use-block+0x434>
    c1c8:      	mov	x1, #0x1                ; =1
    c1cc:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c1cc:  ARM64_RELOC_PAGE21	l_stogir.501
    c1d0:      	ldr	x0, [x0]
		000000000000c1d0:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    c1d4:      	mov	x2, #0x17               ; =23
    c1d8:      	b	0xc1ec <_stogir.placement.use-block+0x390>
    c1dc:      	mov	x1, #0x1                ; =1
    c1e0:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c1e0:  ARM64_RELOC_PAGE21	l_stogir.502
    c1e4:      	ldr	x0, [x0]
		000000000000c1e4:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    c1e8:      	mov	x2, #0x25               ; =37
    c1ec:      	b	0xc124 <_stogir.placement.use-block+0x2c8>
    c1f0:      	sxtw	x1, w1
    c1f4:      	cmp	x1, #0x0
    c1f8:      	b.le	0xc1dc <_stogir.placement.use-block+0x380>
    c1fc:      	lsl	x0, x1, #2
    c200:      	ldr	x2, [x21, #0x8]
    c204:      	cmp	x1, x2
    c208:      	b.ge	0xc250 <_stogir.placement.use-block+0x3f4>
    c20c:      	ldr	x2, [x19, #0x8]
    c210:      	cmp	x1, x2
    c214:      	b.ge	0xc248 <_stogir.placement.use-block+0x3ec>
    c218:      	ldr	x1, [x21, #0x78]
    c21c:      	add	x1, x0, x1
    c220:      	ldr	w1, [x1]
    c224:      	sxtw	x1, w1
    c228:      	cmp	x1, #0x0
    c22c:      	cset	w1, ge
    c230:      	ubfx	x1, x1, #0, #8
    c234:      	b	0xc24c <_stogir.placement.use-block+0x3f0>
    c238:      	and	x0, x0, #0xffffffff
    c23c:      	movz	x1, #0x0, lsl #48
    c240:      	movz	x2, #0x0, lsl #48
    c244:      	b	0xc1ec <_stogir.placement.use-block+0x390>
    c248:      	movz	x1, #0x0, lsl #48
    c24c:      	b	0xc254 <_stogir.placement.use-block+0x3f8>
    c250:      	movz	x1, #0x0, lsl #48
    c254:      	cmp	x1, #0x0
    c258:      	b.eq	0xc1dc <_stogir.placement.use-block+0x380>
    c25c:      	ldr	x1, [x22]
    c260:      	add	x0, x0, x1
    c264:      	ldr	w0, [x0]
    c268:      	sxtw	x0, w0
    c26c:      	cmp	x0, #0x0
    c270:      	b.ne	0xc238 <_stogir.placement.use-block+0x3dc>
    c274:      	mov	x1, #0x1                ; =1
    c278:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c278:  ARM64_RELOC_PAGE21	l_stogir.503
    c27c:      	ldr	x0, [x0]
		000000000000c27c:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    c280:      	mov	x2, #0x1a               ; =26
    c284:      	b	0xc244 <_stogir.placement.use-block+0x3e8>
    c288:      	brk	#0
    c28c:      	b	0xc288 <_stogir.placement.use-block+0x42c>
    c290:      	brk	#0
    c294:      	b	0xc290 <_stogir.placement.use-block+0x434>
    c298:      	mov	x20, x8
    c29c:      	b	0xbffc <_stogir.placement.use-block+0x1a0>
    c2a0:      	mov	x20, x8
    c2a4:      	mov	x22, x1
    c2a8:      	b	0xc0a4 <_stogir.placement.use-block+0x248>
    c2ac:      	mov	x20, x8
    c2b0:      	mov	x22, x1
    c2b4:      	b	0xc0a4 <_stogir.placement.use-block+0x248>

000000000000c2b8 <_stogir.placement.choose-block>:
    c2b8:      	sxtw	x2, w2
    c2bc:      	sxtw	x4, w3
    c2c0:      	mov	x6, x4
    c2c4:      	movz	x5, #0x0, lsl #48
    c2c8:      	movz	x7, #0x0, lsl #48
    c2cc:      	b	0xc2dc <_stogir.placement.choose-block+0x24>
    c2d0:      	mov	x6, x9
    c2d4:      	b	0xc2dc <_stogir.placement.choose-block+0x24>
    c2d8:      	mov	x5, #0x1                ; =1
    c2dc:      	cmp	x5, #0x0
    c2e0:      	b.ne	0xc32c <_stogir.placement.choose-block+0x74>
    c2e4:      	cmp	x6, #0x0
    c2e8:      	b.le	0xc2d8 <_stogir.placement.choose-block+0x20>
    c2ec:      	ldr	x9, [x0, #0x8]
    c2f0:      	cmp	x6, x9
    c2f4:      	b.ge	0xc2d8 <_stogir.placement.choose-block+0x20>
    c2f8:      	ldr	x9, [x0]
    c2fc:      	add	x9, x9, x6, lsl #2
    c300:      	ldr	w9, [x9]
    c304:      	sxtw	x9, w9
    c308:      	cmp	x9, #0x0
    c30c:      	b.ne	0xc318 <_stogir.placement.choose-block+0x60>
    c310:      	mov	x5, #0x1                ; =1
    c314:      	b	0xc2d4 <_stogir.placement.choose-block+0x1c>
    c318:      	cmp	x6, x2
    c31c:      	b.ne	0xc338 <_stogir.placement.choose-block+0x80>
    c320:      	mov	x5, #0x1                ; =1
    c324:      	mov	x7, #0x1                ; =1
    c328:      	b	0xc2d4 <_stogir.placement.choose-block+0x1c>
    c32c:      	cmp	x7, #0x0
    c330:      	b.eq	0xc3a4 <_stogir.placement.choose-block+0xec>
    c334:      	b	0xc34c <_stogir.placement.choose-block+0x94>
    c338:      	cmp	x6, x9
    c33c:      	b.ne	0xc2d0 <_stogir.placement.choose-block+0x18>
    c340:      	mov	x5, #0x1                ; =1
    c344:      	b	0xc2d4 <_stogir.placement.choose-block+0x1c>
    c348:      	mov	x4, x5
    c34c:      	sxtw	x3, w3
    c350:      	cmp	x3, x2
    c354:      	b.eq	0xc394 <_stogir.placement.choose-block+0xdc>
    c358:      	ldr	x5, [x0]
    c35c:      	add	x3, x5, x3, lsl #2
    c360:      	ldr	w3, [x3]
    c364:      	sxtw	x5, w3
    c368:      	ldr	x6, [x1]
    c36c:      	orr	x7, x6, xzr
    c370:      	add	x7, x7, x5, lsl #2
    c374:      	add	x6, x6, x4, lsl #2
    c378:      	ldr	w7, [x7]
    c37c:      	sxtw	x7, w7
    c380:      	ldr	w6, [x6]
    c384:      	sxtw	x6, w6
    c388:      	cmp	x7, x6
    c38c:      	b.lt	0xc348 <_stogir.placement.choose-block+0x90>
    c390:      	b	0xc34c <_stogir.placement.choose-block+0x94>
    c394:      	and	x0, x4, #0xffffffff
    c398:      	movz	x1, #0x0, lsl #48
    c39c:      	movz	x2, #0x0, lsl #48
    c3a0:      	b	0xc3b4 <_stogir.placement.choose-block+0xfc>
    c3a4:      	mov	x1, #0x1                ; =1
    c3a8:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c3a8:  ARM64_RELOC_PAGE21	l_stogir.504
    c3ac:      	ldr	x0, [x0]
		000000000000c3ac:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    c3b0:      	mov	x2, #0x29               ; =41
    c3b4:      	str	x1, [x8]
    c3b8:      	str	x0, [x8, #0x8]
    c3bc:      	str	x2, [x8, #0x10]
    c3c0:      	ret

000000000000c3c4 <_stogir.checked.validate-projection>:
    c3c4:      	sub	sp, sp, #0x40
    c3c8:      	str	x29, [sp]
    c3cc:      	str	x30, [sp, #0x8]
    c3d0:      	mov	x29, sp
    c3d4:      	str	x19, [sp, #0x30]
    c3d8:      	sxtw	x1, w1
    c3dc:      	add	x2, x0, #0x78
    c3e0:      	add	x3, x0, #0x28
    c3e4:      	lsl	x4, x1, #2
    c3e8:      	cmp	x1, #0x0
    c3ec:      	cset	w5, gt
    c3f0:      	movz	x16, #0x0, lsl #48
    c3f4:      	sub	x6, x16, x1
    c3f8:      	sub	x7, x6, #0x1
    c3fc:      	uxtb	w16, w5
    c400:      	cmp	w16, wzr
    c404:      	b.eq	0xc440 <_stogir.checked.validate-projection+0x7c>
    c408:      	ldr	x3, [x0, #0x8]
    c40c:      	cmp	x1, x3
    c410:      	b.ge	0xc48c <_stogir.checked.validate-projection+0xc8>
    c414:      	ldr	x2, [x2, #0x8]
    c418:      	cmp	x1, x2
    c41c:      	b.ge	0xc55c <_stogir.checked.validate-projection+0x198>
    c420:      	ldr	x2, [x0, #0x78]
    c424:      	add	x2, x4, x2
    c428:      	ldr	w2, [x2]
    c42c:      	sxtw	x2, w2
    c430:      	cmp	x2, #0x0
    c434:      	cset	w2, ge
    c438:      	ubfx	x2, x2, #0, #8
    c43c:      	b	0xc560 <_stogir.checked.validate-projection+0x19c>
    c440:      	cmp	x1, #0x0
    c444:      	b.ge	0xc494 <_stogir.checked.validate-projection+0xd0>
    c448:      	add	x2, x0, #0x50
    c44c:      	ldr	x3, [x3, #0x8]
    c450:      	ldr	x2, [x2, #0x8]
    c454:      	cmp	x3, x2
    c458:      	b.ne	0xc484 <_stogir.checked.validate-projection+0xc0>
    c45c:      	cmp	x6, x3
    c460:      	b.gt	0xc5c8 <_stogir.checked.validate-projection+0x204>
    c464:      	ldr	x2, [x0, #0x50]
    c468:      	add	x2, x2, x7, lsl #2
    c46c:      	ldr	w2, [x2]
    c470:      	sxtw	x2, w2
    c474:      	cmp	x2, #0x0
    c478:      	cset	w2, gt
    c47c:      	ubfx	x2, x2, #0, #8
    c480:      	b	0xc5cc <_stogir.checked.validate-projection+0x208>
    c484:      	movz	x2, #0x0, lsl #48
    c488:      	b	0xc498 <_stogir.checked.validate-projection+0xd4>
    c48c:      	movz	x2, #0x0, lsl #48
    c490:      	b	0xc498 <_stogir.checked.validate-projection+0xd4>
    c494:      	movz	x2, #0x0, lsl #48
    c498:      	cmp	x2, #0x0
    c49c:      	b.eq	0xc4d0 <_stogir.checked.validate-projection+0x10c>
    c4a0:      	uxtb	w16, w5
    c4a4:      	cmp	w16, wzr
    c4a8:      	b.eq	0xc4bc <_stogir.checked.validate-projection+0xf8>
    c4ac:      	ldr	x2, [x0]
    c4b0:      	add	x2, x2, x1, lsl #4
    c4b4:      	ldr	x2, [x2]
    c4b8:      	b	0xc4c8 <_stogir.checked.validate-projection+0x104>
    c4bc:      	ldr	x2, [x0, #0x28]
    c4c0:      	add	x2, x2, x7, lsl #4
    c4c4:      	ldr	x2, [x2]
    c4c8:      	mov	w3, #0x1                ; =1
    c4cc:      	b	0xc4d8 <_stogir.checked.validate-projection+0x114>
    c4d0:      	movz	w3, #0x0, lsl #16
    c4d4:      	movz	x2, #0x0, lsl #48
    c4d8:      	ubfx	x3, x3, #0, #32
    c4dc:      	lsr	x16, x3, #0
    c4e0:      	cmp	x16, #0x1
    c4e4:      	b.eq	0xc500 <_stogir.checked.validate-projection+0x13c>
    c4e8:      	b.lo	0xc4f0 <_stogir.checked.validate-projection+0x12c>
    c4ec:      	b	0xc504 <_stogir.checked.validate-projection+0x140>
    c4f0:      	cmp	x16, #0x0
    c4f4:      	b.eq	0xc4fc <_stogir.checked.validate-projection+0x138>
    c4f8:      	b	0xc504 <_stogir.checked.validate-projection+0x140>
    c4fc:      	b	0xc508 <_stogir.checked.validate-projection+0x144>
    c500:      	b	0xc520 <_stogir.checked.validate-projection+0x15c>
    c504:      	b	0xc5d0 <_stogir.checked.validate-projection+0x20c>
    c508:      	mov	x19, x8
    c50c:      	mov	x0, #0x1                ; =1
    c510:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c510:  ARM64_RELOC_PAGE21	l_stogir.505
    c514:      	ldr	x1, [x1]
		000000000000c514:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    c518:      	mov	x2, #0x10               ; =16
    c51c:      	b	0xc53c <_stogir.checked.validate-projection+0x178>
    c520:      	cmp	x1, #0x0
    c524:      	b.gt	0xc564 <_stogir.checked.validate-projection+0x1a0>
    c528:      	mov	x19, x8
    c52c:      	mov	x0, #0x1                ; =1
    c530:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c530:  ARM64_RELOC_PAGE21	l_stogir.506
    c534:      	ldr	x1, [x1]
		000000000000c534:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    c538:      	mov	x2, #0x1c               ; =28
    c53c:      	str	x0, [x19]
    c540:      	str	x1, [x19, #0x8]
    c544:      	str	x2, [x19, #0x10]
    c548:      	ldr	x19, [sp, #0x30]
    c54c:      	ldr	x29, [sp]
    c550:      	ldr	x30, [sp, #0x8]
    c554:      	add	sp, sp, #0x40
    c558:      	ret
    c55c:      	movz	x2, #0x0, lsl #48
    c560:      	b	0xc490 <_stogir.checked.validate-projection+0xcc>
    c564:      	uxtb	w1, w2
    c568:      	cmp	x1, #0x2c
    c56c:      	b.ne	0xc5d8 <_stogir.checked.validate-projection+0x214>
    c570:      	orr	w1, w2, wzr
    c574:      	ubfx	x1, x1, #0, #32
    c578:      	ubfx	x1, x1, #8, #8
    c57c:      	cmp	x1, #0x1
    c580:      	b.ne	0xc5e0 <_stogir.checked.validate-projection+0x21c>
    c584:      	ldr	x1, [x0, #0x78]
    c588:      	add	x1, x4, x1
    c58c:      	ldr	w1, [x1]
    c590:      	sxtw	x1, w1
    c594:      	cmp	x1, #0x1
    c598:      	b.ne	0xc5e8 <_stogir.checked.validate-projection+0x224>
    c59c:      	lsr	x1, x2, #32
    c5a0:      	mov	x19, x8
    c5a4:      	add	x8, sp, #0x10
    c5a8:      	bl	0xc5a8 <_stogir.checked.validate-projection+0x1e4>
		000000000000c5a8:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    c5ac:      	add	x16, sp, #0x10
    c5b0:      	ldr	x0, [x16]
    c5b4:      	add	x16, sp, #0x10
    c5b8:      	ldr	x1, [x16, #0x8]
    c5bc:      	add	x16, sp, #0x10
    c5c0:      	ldr	x2, [x16, #0x10]
    c5c4:      	b	0xc53c <_stogir.checked.validate-projection+0x178>
    c5c8:      	movz	x2, #0x0, lsl #48
    c5cc:      	b	0xc488 <_stogir.checked.validate-projection+0xc4>
    c5d0:      	brk	#0
    c5d4:      	b	0xc5d0 <_stogir.checked.validate-projection+0x20c>
    c5d8:      	mov	x19, x8
    c5dc:      	b	0xc52c <_stogir.checked.validate-projection+0x168>
    c5e0:      	mov	x19, x8
    c5e4:      	b	0xc52c <_stogir.checked.validate-projection+0x168>
    c5e8:      	mov	x19, x8
    c5ec:      	b	0xc52c <_stogir.checked.validate-projection+0x168>

000000000000c5f0 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge>:
    c5f0:      	ldr	x1, [x0]
    c5f4:      	ldr	x0, [x0, #0x8]
    c5f8:      	str	x1, [x8]
    c5fc:      	str	x0, [x8, #0x8]
    c600:      	movz	x17, #0x0, lsl #48
    c604:      	str	x17, [x8, #0x10]
    c608:      	ret

000000000000c60c <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64>:
    c60c:      	ldr	x1, [x0]
    c610:      	ldr	x0, [x0, #0x8]
    c614:      	str	x1, [x8]
    c618:      	str	x0, [x8, #0x8]
    c61c:      	movz	x17, #0x0, lsl #48
    c620:      	str	x17, [x8, #0x10]
    c624:      	ret

000000000000c628 <_stogir.loops.heapify!>:
    c628:      	ldr	x4, [x1, #0x8]
    c62c:      	asr	x16, x4, #63
    c630:      	lsr	x16, x16, #63
    c634:      	add	x4, x4, x16
    c638:      	asr	x4, x4, #1
    c63c:      	cmp	x4, #0x0
    c640:      	b.le	0xc7c4 <_stogir.loops.heapify!+0x19c>
    c644:      	sub	x4, x4, #0x1
    c648:      	ldr	x5, [x1]
    c64c:      	ldr	x6, [x1, #0x8]
    c650:      	mov	x8, x4
    c654:      	movz	x7, #0x0, lsl #48
    c658:      	b	0xc69c <_stogir.loops.heapify!+0x74>
    c65c:      	nop
    c660:      	add	x8, x5, x8
    c664:      	add	x10, x5, x9
    c668:      	ldr	x11, [x0]
    c66c:      	orr	x12, x11, xzr
    c670:      	orr	x13, x11, xzr
    c674:      	add	x12, x12, x8, lsl #3
    c678:      	add	x13, x13, x10, lsl #3
    c67c:      	add	x8, x11, x8, lsl #3
    c680:      	ldr	x11, [x12]
    c684:      	ldr	x12, [x13]
    c688:      	str	x12, [x8]
    c68c:      	ldr	x8, [x0]
    c690:      	add	x8, x8, x10, lsl #3
    c694:      	str	x11, [x8]
    c698:      	mov	x8, x9
    c69c:      	cmp	x7, #0x0
    c6a0:      	b.ne	0xc63c <_stogir.loops.heapify!+0x14>
    c6a4:      	lsl	x9, x8, #1
    c6a8:      	add	x9, x9, #0x1
    c6ac:      	cmp	x9, x6
    c6b0:      	b.ge	0xc63c <_stogir.loops.heapify!+0x14>
    c6b4:      	lsl	x9, x8, #1
    c6b8:      	add	x9, x9, #0x1
    c6bc:      	add	x10, x9, #0x1
    c6c0:      	cmp	x10, x6
    c6c4:      	b.ge	0xc744 <_stogir.loops.heapify!+0x11c>
    c6c8:      	add	x10, x9, x5
    c6cc:      	ldr	x11, [x0]
    c6d0:      	add	x12, x10, #0x1
    c6d4:      	orr	x13, x11, xzr
    c6d8:      	add	x10, x11, x10, lsl #3
    c6dc:      	add	x11, x13, x12, lsl #3
    c6e0:      	ldr	x11, [x11]
    c6e4:      	ldr	x10, [x10]
    c6e8:      	ldr	x12, [x2, #0x50]
    c6ec:      	orr	x13, x12, xzr
    c6f0:      	add	x13, x13, x11, lsl #4
    c6f4:      	add	x12, x12, x10, lsl #4
    c6f8:      	ldr	x13, [x13]
    c6fc:      	ldr	x14, [x3]
    c700:      	asr	x13, x13, #32
    c704:      	orr	x15, x14, xzr
    c708:      	add	x13, x15, x13, lsl #2
    c70c:      	ldr	w13, [x13]
    c710:      	sxtw	x13, w13
    c714:      	ldr	x12, [x12]
    c718:      	asr	x12, x12, #32
    c71c:      	add	x12, x14, x12, lsl #2
    c720:      	ldr	w12, [x12]
    c724:      	sxtw	x12, w12
    c728:      	cmp	x13, x12
    c72c:      	b.lt	0xc740 <_stogir.loops.heapify!+0x118>
    c730:      	cmp	x13, x12
    c734:      	b.ne	0xc744 <_stogir.loops.heapify!+0x11c>
    c738:      	cmp	x11, x10
    c73c:      	b.le	0xc744 <_stogir.loops.heapify!+0x11c>
    c740:      	add	x9, x9, #0x1
    c744:      	add	x10, x5, x8
    c748:      	ldr	x11, [x0]
    c74c:      	add	x12, x5, x9
    c750:      	orr	x13, x11, xzr
    c754:      	add	x10, x11, x10, lsl #3
    c758:      	add	x11, x13, x12, lsl #3
    c75c:      	ldr	x11, [x11]
    c760:      	ldr	x10, [x10]
    c764:      	ldr	x12, [x2, #0x50]
    c768:      	orr	x13, x12, xzr
    c76c:      	add	x13, x13, x11, lsl #4
    c770:      	add	x12, x12, x10, lsl #4
    c774:      	ldr	x13, [x13]
    c778:      	ldr	x14, [x3]
    c77c:      	asr	x13, x13, #32
    c780:      	orr	x15, x14, xzr
    c784:      	add	x13, x15, x13, lsl #2
    c788:      	ldr	w13, [x13]
    c78c:      	sxtw	x13, w13
    c790:      	ldr	x12, [x12]
    c794:      	asr	x12, x12, #32
    c798:      	add	x12, x14, x12, lsl #2
    c79c:      	ldr	w12, [x12]
    c7a0:      	sxtw	x12, w12
    c7a4:      	cmp	x13, x12
    c7a8:      	b.lt	0xc660 <_stogir.loops.heapify!+0x38>
    c7ac:      	cmp	x13, x12
    c7b0:      	b.ne	0xc7bc <_stogir.loops.heapify!+0x194>
    c7b4:      	cmp	x11, x10
    c7b8:      	b.gt	0xc660 <_stogir.loops.heapify!+0x38>
    c7bc:      	mov	x7, #0x1                ; =1
    c7c0:      	b	0xc69c <_stogir.loops.heapify!+0x74>
    c7c4:      	ret

000000000000c7c8 <_stogir.loops.sift!>:
    c7c8:      	movz	x6, #0x0, lsl #48
    c7cc:      	b	0xc80c <_stogir.loops.sift!+0x44>
    c7d0:      	add	x3, x1, x3
    c7d4:      	add	x8, x1, x7
    c7d8:      	ldr	x9, [x0]
    c7dc:      	orr	x10, x9, xzr
    c7e0:      	orr	x11, x9, xzr
    c7e4:      	add	x10, x10, x3, lsl #3
    c7e8:      	add	x11, x11, x8, lsl #3
    c7ec:      	add	x3, x9, x3, lsl #3
    c7f0:      	ldr	x9, [x10]
    c7f4:      	ldr	x10, [x11]
    c7f8:      	str	x10, [x3]
    c7fc:      	ldr	x3, [x0]
    c800:      	add	x3, x3, x8, lsl #3
    c804:      	str	x9, [x3]
    c808:      	mov	x3, x7
    c80c:      	cmp	x6, #0x0
    c810:      	b.ne	0xc934 <_stogir.loops.sift!+0x16c>
    c814:      	lsl	x7, x3, #1
    c818:      	add	x7, x7, #0x1
    c81c:      	cmp	x7, x2
    c820:      	b.ge	0xc934 <_stogir.loops.sift!+0x16c>
    c824:      	lsl	x7, x3, #1
    c828:      	add	x7, x7, #0x1
    c82c:      	add	x8, x7, #0x1
    c830:      	cmp	x8, x2
    c834:      	b.ge	0xc8b4 <_stogir.loops.sift!+0xec>
    c838:      	add	x8, x7, x1
    c83c:      	ldr	x9, [x0]
    c840:      	add	x10, x8, #0x1
    c844:      	orr	x11, x9, xzr
    c848:      	add	x8, x9, x8, lsl #3
    c84c:      	add	x9, x11, x10, lsl #3
    c850:      	ldr	x9, [x9]
    c854:      	ldr	x8, [x8]
    c858:      	ldr	x10, [x4, #0x50]
    c85c:      	orr	x11, x10, xzr
    c860:      	add	x11, x11, x9, lsl #4
    c864:      	add	x10, x10, x8, lsl #4
    c868:      	ldr	x11, [x11]
    c86c:      	ldr	x12, [x5]
    c870:      	asr	x11, x11, #32
    c874:      	orr	x13, x12, xzr
    c878:      	add	x11, x13, x11, lsl #2
    c87c:      	ldr	w11, [x11]
    c880:      	sxtw	x11, w11
    c884:      	ldr	x10, [x10]
    c888:      	asr	x10, x10, #32
    c88c:      	add	x10, x12, x10, lsl #2
    c890:      	ldr	w10, [x10]
    c894:      	sxtw	x10, w10
    c898:      	cmp	x11, x10
    c89c:      	b.lt	0xc8b0 <_stogir.loops.sift!+0xe8>
    c8a0:      	cmp	x11, x10
    c8a4:      	b.ne	0xc8b4 <_stogir.loops.sift!+0xec>
    c8a8:      	cmp	x9, x8
    c8ac:      	b.le	0xc8b4 <_stogir.loops.sift!+0xec>
    c8b0:      	add	x7, x7, #0x1
    c8b4:      	add	x8, x1, x3
    c8b8:      	ldr	x9, [x0]
    c8bc:      	add	x10, x1, x7
    c8c0:      	orr	x11, x9, xzr
    c8c4:      	add	x8, x9, x8, lsl #3
    c8c8:      	add	x9, x11, x10, lsl #3
    c8cc:      	ldr	x9, [x9]
    c8d0:      	ldr	x8, [x8]
    c8d4:      	ldr	x10, [x4, #0x50]
    c8d8:      	orr	x11, x10, xzr
    c8dc:      	add	x11, x11, x9, lsl #4
    c8e0:      	add	x10, x10, x8, lsl #4
    c8e4:      	ldr	x11, [x11]
    c8e8:      	ldr	x12, [x5]
    c8ec:      	asr	x11, x11, #32
    c8f0:      	orr	x13, x12, xzr
    c8f4:      	add	x11, x13, x11, lsl #2
    c8f8:      	ldr	w11, [x11]
    c8fc:      	sxtw	x11, w11
    c900:      	ldr	x10, [x10]
    c904:      	asr	x10, x10, #32
    c908:      	add	x10, x12, x10, lsl #2
    c90c:      	ldr	w10, [x10]
    c910:      	sxtw	x10, w10
    c914:      	cmp	x11, x10
    c918:      	b.lt	0xc7d0 <_stogir.loops.sift!+0x8>
    c91c:      	cmp	x11, x10
    c920:      	b.ne	0xc92c <_stogir.loops.sift!+0x164>
    c924:      	cmp	x9, x8
    c928:      	b.gt	0xc7d0 <_stogir.loops.sift!+0x8>
    c92c:      	mov	x6, #0x1                ; =1
    c930:      	b	0xc80c <_stogir.loops.sift!+0x44>
    c934:      	ret

000000000000c938 <_stogir.opcode.block-end?>:
    c938:      	sxtw	x0, w0
    c93c:      	cmp	x0, #0x0
    c940:      	b.lt	0xc960 <_stogir.opcode.block-end?+0x28>
    c944:      	cmp	x0, #0x83
    c948:      	b.ge	0xc960 <_stogir.opcode.block-end?+0x28>
    c94c:      	adrp	x16, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000c94c:  ARM64_RELOC_PAGE21	l_stogir.507
    c950:      	ldr	x16, [x16]
		000000000000c950:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    c954:      	add	x0, x16, x0
    c958:      	ldrb	w0, [x0]
    c95c:      	b	0xc964 <_stogir.opcode.block-end?+0x2c>
    c960:      	movz	w0, #0x0, lsl #16
    c964:      	uxtb	w16, w0
    c968:      	and	w0, w16, #0x4
    c96c:      	uxtb	w0, w0
    c970:      	ubfx	x0, x0, #0, #8
    c974:      	cmp	x0, #0x0
    c978:      	cset	w0, eq
    c97c:      	uxtb	w16, w0
    c980:      	cmp	w16, wzr
    c984:      	cset	x0, eq
    c988:      	ret

000000000000c98c <_stogir.schedule.entry-prefix>:
    c98c:      	sub	sp, sp, #0x90
    c990:      	str	x29, [sp]
    c994:      	str	x30, [sp, #0x8]
    c998:      	mov	x29, sp
    c99c:      	str	x19, [sp, #0x40]
    c9a0:      	str	x20, [sp, #0x48]
    c9a4:      	str	x21, [sp, #0x50]
    c9a8:      	str	x22, [sp, #0x58]
    c9ac:      	str	x23, [sp, #0x60]
    c9b0:      	str	x24, [sp, #0x68]
    c9b4:      	str	x25, [sp, #0x70]
    c9b8:      	str	x26, [sp, #0x78]
    c9bc:      	str	x27, [sp, #0x80]
    c9c0:      	ldr	x3, [x2]
    c9c4:      	ldr	x2, [x2, #0x8]
    c9c8:      	add	x16, sp, #0x10
    c9cc:      	movz	x17, #0x0, lsl #48
    c9d0:      	str	x17, [x16]
    c9d4:      	add	x16, sp, #0x10
    c9d8:      	movz	x17, #0x0, lsl #48
    c9dc:      	str	x17, [x16, #0x8]
    c9e0:      	add	x16, sp, #0x10
    c9e4:      	movz	x17, #0x0, lsl #48
    c9e8:      	str	x17, [x16, #0x10]
    c9ec:      	add	x16, sp, #0x10
    c9f0:      	str	x3, [x16, #0x18]
    c9f4:      	add	x16, sp, #0x10
    c9f8:      	str	x2, [x16, #0x20]
    c9fc:      	movz	x19, #0x0, lsl #48
    ca00:      	b	0xcaf4 <_stogir.schedule.entry-prefix+0x168>
    ca04:      	lsl	x2, x2, #1
    ca08:      	mov	x25, x8
    ca0c:      	mov	x26, x0
    ca10:      	add	x0, sp, #0x10
    ca14:      	mov	x27, x1
    ca18:      	mov	x1, x2
    ca1c:      	bl	0xca1c <_stogir.schedule.entry-prefix+0x90>
		000000000000ca1c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ca20:      	add	x0, x24, #0x1
    ca24:      	add	x16, sp, #0x10
    ca28:      	ldr	x1, [x16]
    ca2c:      	add	x1, x1, x24, lsl #2
    ca30:      	str	w23, [x1]
    ca34:      	add	x16, sp, #0x10
    ca38:      	str	x0, [x16, #0x8]
    ca3c:      	mov	x8, x25
    ca40:      	mov	x0, x26
    ca44:      	mov	x1, x27
    ca48:      	cmp	x22, x21
    ca4c:      	b.ge	0xca70 <_stogir.schedule.entry-prefix+0xe4>
    ca50:      	add	x2, x22, #0x1
    ca54:      	add	x3, x20, x22, lsl #2
    ca58:      	ldr	w3, [x3]
    ca5c:      	movn	w17, #0x0, lsl #16
    ca60:      	and	w23, w3, w17
    ca64:      	mov	x22, x2
    ca68:      	mov	w2, #0x1                ; =1
    ca6c:      	b	0xca78 <_stogir.schedule.entry-prefix+0xec>
    ca70:      	movz	w2, #0x0, lsl #16
    ca74:      	movz	w23, #0x0, lsl #16
    ca78:      	ubfx	x2, x2, #0, #32
    ca7c:      	lsr	x16, x2, #0
    ca80:      	cmp	x16, #0x1
    ca84:      	b.eq	0xcaac <_stogir.schedule.entry-prefix+0x120>
    ca88:      	b.lo	0xca90 <_stogir.schedule.entry-prefix+0x104>
    ca8c:      	b	0xcab0 <_stogir.schedule.entry-prefix+0x124>
    ca90:      	cmp	x16, #0x0
    ca94:      	b.eq	0xca9c <_stogir.schedule.entry-prefix+0x110>
    ca98:      	b	0xcab0 <_stogir.schedule.entry-prefix+0x124>
    ca9c:      	mov	x25, x8
    caa0:      	mov	x26, x0
    caa4:      	mov	x27, x1
    caa8:      	b	0xcae4 <_stogir.schedule.entry-prefix+0x158>
    caac:      	b	0xcab4 <_stogir.schedule.entry-prefix+0x128>
    cab0:      	b	0xcc0c <_stogir.schedule.entry-prefix+0x280>
    cab4:      	sxtw	x2, w23
    cab8:      	ldr	x3, [x0]
    cabc:      	add	x2, x3, x2, lsl #4
    cac0:      	ldr	x2, [x2]
    cac4:      	uxtb	w2, w2
    cac8:      	cmp	x2, #0x83
    cacc:      	b.ge	0xcb14 <_stogir.schedule.entry-prefix+0x188>
    cad0:      	adrp	x17, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000cad0:  ARM64_RELOC_PAGE21	l_stogir.508
    cad4:      	ldr	x17, [x17]
		000000000000cad4:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    cad8:      	add	x3, x2, x17
    cadc:      	ldrb	w3, [x3]
    cae0:      	b	0xcb18 <_stogir.schedule.entry-prefix+0x18c>
    cae4:      	add	x19, x19, #0x1
    cae8:      	mov	x8, x25
    caec:      	mov	x0, x26
    caf0:      	mov	x1, x27
    caf4:      	cmp	x19, #0x3
    caf8:      	b.ge	0xcc14 <_stogir.schedule.entry-prefix+0x288>
    cafc:      	ldr	x2, [x1]
    cb00:      	ldr	x3, [x1, #0x8]
    cb04:      	orr	x20, x2, xzr
    cb08:      	orr	x21, x3, xzr
    cb0c:      	movz	x22, #0x0, lsl #48
    cb10:      	b	0xca48 <_stogir.schedule.entry-prefix+0xbc>
    cb14:      	movz	w3, #0x0, lsl #16
    cb18:      	uxtb	w16, w3
    cb1c:      	and	w3, w16, #0x2
    cb20:      	uxtb	w3, w3
    cb24:      	ubfx	x3, x3, #0, #8
    cb28:      	cmp	x3, #0x0
    cb2c:      	cset	w3, eq
    cb30:      	uxtb	w16, w3
    cb34:      	cmp	w16, wzr
    cb38:      	cset	x3, eq
    cb3c:      	cmp	x3, #0x0
    cb40:      	b.eq	0xcb4c <_stogir.schedule.entry-prefix+0x1c0>
    cb44:      	movz	x2, #0x0, lsl #48
    cb48:      	b	0xcb68 <_stogir.schedule.entry-prefix+0x1dc>
    cb4c:      	cmp	x2, #0x47
    cb50:      	cset	w2, eq
    cb54:      	uxtb	w16, w2
    cb58:      	cmp	w16, wzr
    cb5c:      	mov	x16, #0x1               ; =1
    cb60:      	mov	x17, #0x2               ; =2
    cb64:      	csel	x2, x16, x17, ne
    cb68:      	cmp	x2, x19
    cb6c:      	b.ne	0xcc1c <_stogir.schedule.entry-prefix+0x290>
    cb70:      	add	x16, sp, #0x10
    cb74:      	ldr	x2, [x16, #0x8]
    cb78:      	orr	x24, x2, xzr
    cb7c:      	add	x16, sp, #0x10
    cb80:      	ldr	x2, [x16, #0x10]
    cb84:      	cmp	x24, x2
    cb88:      	b.lt	0xcc2c <_stogir.schedule.entry-prefix+0x2a0>
    cb8c:      	cmp	x2, #0x0
    cb90:      	b.ne	0xca04 <_stogir.schedule.entry-prefix+0x78>
    cb94:      	mov	x2, #0x2                ; =2
    cb98:      	b	0xca08 <_stogir.schedule.entry-prefix+0x7c>
    cb9c:      	add	x16, sp, #0x10
    cba0:      	ldr	x0, [x16]
    cba4:      	add	x16, sp, #0x10
    cba8:      	ldr	x1, [x16, #0x8]
    cbac:      	add	x16, sp, #0x10
    cbb0:      	ldr	x2, [x16, #0x10]
    cbb4:      	add	x16, sp, #0x10
    cbb8:      	ldr	x3, [x16, #0x18]
    cbbc:      	add	x16, sp, #0x10
    cbc0:      	ldr	x4, [x16, #0x20]
    cbc4:      	str	x0, [x25]
    cbc8:      	str	x1, [x25, #0x8]
    cbcc:      	str	x2, [x25, #0x10]
    cbd0:      	str	x3, [x25, #0x18]
    cbd4:      	str	x4, [x25, #0x20]
    cbd8:      	ldr	x19, [sp, #0x40]
    cbdc:      	ldr	x20, [sp, #0x48]
    cbe0:      	ldr	x21, [sp, #0x50]
    cbe4:      	ldr	x22, [sp, #0x58]
    cbe8:      	ldr	x23, [sp, #0x60]
    cbec:      	ldr	x24, [sp, #0x68]
    cbf0:      	ldr	x25, [sp, #0x70]
    cbf4:      	ldr	x26, [sp, #0x78]
    cbf8:      	ldr	x27, [sp, #0x80]
    cbfc:      	ldr	x29, [sp]
    cc00:      	ldr	x30, [sp, #0x8]
    cc04:      	add	sp, sp, #0x90
    cc08:      	ret
    cc0c:      	brk	#0
    cc10:      	b	0xcc0c <_stogir.schedule.entry-prefix+0x280>
    cc14:      	mov	x25, x8
    cc18:      	b	0xcb9c <_stogir.schedule.entry-prefix+0x210>
    cc1c:      	mov	x25, x8
    cc20:      	mov	x26, x0
    cc24:      	mov	x27, x1
    cc28:      	b	0xca3c <_stogir.schedule.entry-prefix+0xb0>
    cc2c:      	mov	x25, x8
    cc30:      	mov	x26, x0
    cc34:      	mov	x27, x1
    cc38:      	b	0xca20 <_stogir.schedule.entry-prefix+0x94>

000000000000cc3c <_stogir.checked-schedule.validate>:
    cc3c:      	sub	sp, sp, #0x40
    cc40:      	str	x29, [sp]
    cc44:      	str	x30, [sp, #0x8]
    cc48:      	mov	x29, sp
    cc4c:      	str	x19, [sp, #0x30]
    cc50:      	add	x1, x1, #0x28
    cc54:      	mov	x19, x8
    cc58:      	add	x8, sp, #0x10
    cc5c:      	bl	0xcc5c <_stogir.checked-schedule.validate+0x20>
		000000000000cc5c:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    cc60:      	add	x16, sp, #0x10
    cc64:      	ldr	x0, [x16]
    cc68:      	str	x0, [x19]
    cc6c:      	add	x16, sp, #0x10
    cc70:      	ldr	x0, [x16, #0x8]
    cc74:      	str	x0, [x19, #0x8]
    cc78:      	add	x16, sp, #0x10
    cc7c:      	ldr	x0, [x16, #0x10]
    cc80:      	str	x0, [x19, #0x10]
    cc84:      	ldr	x19, [sp, #0x30]
    cc88:      	ldr	x29, [sp]
    cc8c:      	ldr	x30, [sp, #0x8]
    cc90:      	add	sp, sp, #0x40
    cc94:      	ret

000000000000cc98 <_stogir.checked.projection>:
    cc98:      	sub	sp, sp, #0x40
    cc9c:      	str	x29, [sp]
    cca0:      	str	x30, [sp, #0x8]
    cca4:      	mov	x29, sp
    cca8:      	str	x19, [sp, #0x30]
    ccac:      	sxtw	x2, w1
    ccb0:      	add	x3, x0, #0x28
    ccb4:      	cmp	x2, #0x0
    ccb8:      	cset	w4, gt
    ccbc:      	movz	x16, #0x0, lsl #48
    ccc0:      	sub	x5, x16, x2
    ccc4:      	sub	x6, x5, #0x1
    ccc8:      	uxtb	w16, w4
    cccc:      	cmp	w16, wzr
    ccd0:      	b.eq	0xcd10 <_stogir.checked.projection+0x78>
    ccd4:      	ldr	x3, [x0, #0x8]
    ccd8:      	cmp	x2, x3
    ccdc:      	b.ge	0xcd5c <_stogir.checked.projection+0xc4>
    cce0:      	add	x3, x0, #0x78
    cce4:      	ldr	x3, [x3, #0x8]
    cce8:      	cmp	x2, x3
    ccec:      	b.ge	0xce5c <_stogir.checked.projection+0x1c4>
    ccf0:      	ldr	x3, [x0, #0x78]
    ccf4:      	add	x3, x3, x2, lsl #2
    ccf8:      	ldr	w3, [x3]
    ccfc:      	sxtw	x3, w3
    cd00:      	cmp	x3, #0x0
    cd04:      	cset	w3, ge
    cd08:      	ubfx	x3, x3, #0, #8
    cd0c:      	b	0xce60 <_stogir.checked.projection+0x1c8>
    cd10:      	cmp	x2, #0x0
    cd14:      	b.ge	0xcd64 <_stogir.checked.projection+0xcc>
    cd18:      	add	x7, x0, #0x50
    cd1c:      	ldr	x3, [x3, #0x8]
    cd20:      	ldr	x7, [x7, #0x8]
    cd24:      	cmp	x3, x7
    cd28:      	b.ne	0xcd54 <_stogir.checked.projection+0xbc>
    cd2c:      	cmp	x5, x3
    cd30:      	b.gt	0xce8c <_stogir.checked.projection+0x1f4>
    cd34:      	ldr	x3, [x0, #0x50]
    cd38:      	add	x3, x3, x6, lsl #2
    cd3c:      	ldr	w3, [x3]
    cd40:      	sxtw	x3, w3
    cd44:      	cmp	x3, #0x0
    cd48:      	cset	w3, gt
    cd4c:      	ubfx	x3, x3, #0, #8
    cd50:      	b	0xce90 <_stogir.checked.projection+0x1f8>
    cd54:      	movz	x3, #0x0, lsl #48
    cd58:      	b	0xcd68 <_stogir.checked.projection+0xd0>
    cd5c:      	movz	x3, #0x0, lsl #48
    cd60:      	b	0xcd68 <_stogir.checked.projection+0xd0>
    cd64:      	movz	x3, #0x0, lsl #48
    cd68:      	cmp	x3, #0x0
    cd6c:      	b.eq	0xcda0 <_stogir.checked.projection+0x108>
    cd70:      	uxtb	w16, w4
    cd74:      	cmp	w16, wzr
    cd78:      	b.eq	0xcd8c <_stogir.checked.projection+0xf4>
    cd7c:      	ldr	x3, [x0]
    cd80:      	add	x2, x3, x2, lsl #4
    cd84:      	ldr	x2, [x2]
    cd88:      	b	0xcd98 <_stogir.checked.projection+0x100>
    cd8c:      	ldr	x2, [x0, #0x28]
    cd90:      	add	x2, x2, x6, lsl #4
    cd94:      	ldr	x2, [x2]
    cd98:      	mov	w3, #0x1                ; =1
    cd9c:      	b	0xcda8 <_stogir.checked.projection+0x110>
    cda0:      	movz	w3, #0x0, lsl #16
    cda4:      	movz	x2, #0x0, lsl #48
    cda8:      	ubfx	x3, x3, #0, #32
    cdac:      	lsr	x16, x3, #0
    cdb0:      	cmp	x16, #0x1
    cdb4:      	b.eq	0xcdd0 <_stogir.checked.projection+0x138>
    cdb8:      	b.lo	0xcdc0 <_stogir.checked.projection+0x128>
    cdbc:      	b	0xcdd4 <_stogir.checked.projection+0x13c>
    cdc0:      	cmp	x16, #0x0
    cdc4:      	b.eq	0xcdcc <_stogir.checked.projection+0x134>
    cdc8:      	b	0xcdd4 <_stogir.checked.projection+0x13c>
    cdcc:      	b	0xcdd8 <_stogir.checked.projection+0x140>
    cdd0:      	b	0xce20 <_stogir.checked.projection+0x188>
    cdd4:      	b	0xce94 <_stogir.checked.projection+0x1fc>
    cdd8:      	mov	x19, x8
    cddc:      	mov	x0, #0x1                ; =1
    cde0:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000cde0:  ARM64_RELOC_PAGE21	l_stogir.509
    cde4:      	ldr	x1, [x1]
		000000000000cde4:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    cde8:      	mov	x2, #0x17               ; =23
    cdec:      	b	0xce00 <_stogir.checked.projection+0x168>
    cdf0:      	mov	x0, #0x1                ; =1
    cdf4:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000cdf4:  ARM64_RELOC_PAGE21	l_stogir.510
    cdf8:      	ldr	x1, [x1]
		000000000000cdf8:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    cdfc:      	mov	x2, #0x20               ; =32
    ce00:      	str	x0, [x19]
    ce04:      	str	x1, [x19, #0x8]
    ce08:      	str	x2, [x19, #0x10]
    ce0c:      	ldr	x19, [sp, #0x30]
    ce10:      	ldr	x29, [sp]
    ce14:      	ldr	x30, [sp, #0x8]
    ce18:      	add	sp, sp, #0x40
    ce1c:      	ret
    ce20:      	uxtb	w3, w2
    ce24:      	cmp	x3, #0x29
    ce28:      	b.lt	0xce9c <_stogir.checked.projection+0x204>
    ce2c:      	cmp	x3, #0x2b
    ce30:      	b.gt	0xcea4 <_stogir.checked.projection+0x20c>
    ce34:      	mov	x19, x8
    ce38:      	add	x8, sp, #0x10
    ce3c:      	bl	0xce3c <_stogir.checked.projection+0x1a4>
		000000000000ce3c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    ce40:      	add	x16, sp, #0x10
    ce44:      	ldr	x0, [x16]
    ce48:      	add	x16, sp, #0x10
    ce4c:      	ldr	x1, [x16, #0x8]
    ce50:      	add	x16, sp, #0x10
    ce54:      	ldr	x2, [x16, #0x10]
    ce58:      	b	0xce00 <_stogir.checked.projection+0x168>
    ce5c:      	movz	x3, #0x0, lsl #48
    ce60:      	b	0xcd60 <_stogir.checked.projection+0xc8>
    ce64:      	ubfx	x2, x2, #0, #32
    ce68:      	ubfx	x0, x2, #8, #8
    ce6c:      	cmp	x0, #0x0
    ce70:      	b.eq	0xcdf0 <_stogir.checked.projection+0x158>
    ce74:      	cmp	x0, #0xd
    ce78:      	b.gt	0xcdf0 <_stogir.checked.projection+0x158>
    ce7c:      	movz	x0, #0x0, lsl #48
    ce80:      	movz	x1, #0x0, lsl #48
    ce84:      	movz	x2, #0x0, lsl #48
    ce88:      	b	0xce00 <_stogir.checked.projection+0x168>
    ce8c:      	movz	x3, #0x0, lsl #48
    ce90:      	b	0xcd58 <_stogir.checked.projection+0xc0>
    ce94:      	brk	#0
    ce98:      	b	0xce94 <_stogir.checked.projection+0x1fc>
    ce9c:      	mov	x19, x8
    cea0:      	b	0xce64 <_stogir.checked.projection+0x1cc>
    cea4:      	mov	x19, x8
    cea8:      	b	0xce64 <_stogir.checked.projection+0x1cc>

000000000000ceac <_stogir.checked-schedule.validate-nodes>:
    ceac:      	sub	sp, sp, #0xe0
    ceb0:      	str	x29, [sp]
    ceb4:      	str	x30, [sp, #0x8]
    ceb8:      	mov	x29, sp
    cebc:      	str	x19, [sp, #0x88]
    cec0:      	str	x20, [sp, #0x90]
    cec4:      	str	x21, [sp, #0x98]
    cec8:      	str	x22, [sp, #0xa0]
    cecc:      	str	x23, [sp, #0xa8]
    ced0:      	str	x24, [sp, #0xb0]
    ced4:      	str	x25, [sp, #0xb8]
    ced8:      	str	x26, [sp, #0xc0]
    cedc:      	str	x27, [sp, #0xc8]
    cee0:      	str	x28, [sp, #0xd0]
    cee4:      	add	x19, x0, #0x28
    cee8:      	add	x20, x0, #0x78
    ceec:      	add	x21, x0, #0x50
    cef0:      	add	x16, sp, #0x20
    cef4:      	orr	x2, x16, xzr
    cef8:      	add	x22, x2, #0x8
    cefc:      	add	x16, sp, #0x40
    cf00:      	orr	x2, x16, xzr
    cf04:      	ldr	x3, [x1]
    cf08:      	add	x23, x2, #0x8
    cf0c:      	ldr	x1, [x1, #0x8]
    cf10:      	orr	x24, x3, xzr
    cf14:      	orr	x25, x1, xzr
    cf18:      	movz	x26, #0x0, lsl #48
    cf1c:      	adrp	x27, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000cf1c:  ARM64_RELOC_PAGE21	l_stogir.511
    cf20:      	ldr	x27, [x27]
		000000000000cf20:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    cf24:      	movz	x28, #0x0, lsl #48
    cf28:      	movz	w1, #0x0, lsl #16
    cf2c:      	movz	x2, #0x0, lsl #48
    cf30:      	b	0xcf58 <_stogir.checked-schedule.validate-nodes+0xac>
    cf34:      	adrp	x27, 0xc000 <_stogir.placement.use-block+0x1a4>
		000000000000cf34:  ARM64_RELOC_PAGE21	l_stogir.512
    cf38:      	ldr	x27, [x27]
		000000000000cf38:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    cf3c:      	mov	x28, #0x24              ; =36
    cf40:      	mov	x8, x19
    cf44:      	ldr	x0, [sp, #0x68]
    cf48:      	ldr	x19, [sp, #0x60]
    cf4c:      	mov	w1, w20
    cf50:      	ldr	x20, [sp, #0x70]
    cf54:      	ldr	x2, [sp, #0x78]
    cf58:      	cmp	x2, x25
    cf5c:      	b.ge	0xcf80 <_stogir.checked-schedule.validate-nodes+0xd4>
    cf60:      	add	x3, x2, #0x1
    cf64:      	add	x2, x24, x2, lsl #2
    cf68:      	ldr	w2, [x2]
    cf6c:      	movn	w17, #0x0, lsl #16
    cf70:      	and	w4, w2, w17
    cf74:      	mov	x2, x3
    cf78:      	mov	w3, #0x1                ; =1
    cf7c:      	b	0xcf88 <_stogir.checked-schedule.validate-nodes+0xdc>
    cf80:      	movz	w3, #0x0, lsl #16
    cf84:      	movz	w4, #0x0, lsl #16
    cf88:      	ubfx	x3, x3, #0, #32
    cf8c:      	lsr	x16, x3, #0
    cf90:      	cmp	x16, #0x1
    cf94:      	b.eq	0xcfb4 <_stogir.checked-schedule.validate-nodes+0x108>
    cf98:      	b.lo	0xcfa0 <_stogir.checked-schedule.validate-nodes+0xf4>
    cf9c:      	b	0xcfb8 <_stogir.checked-schedule.validate-nodes+0x10c>
    cfa0:      	cmp	x16, #0x0
    cfa4:      	b.eq	0xcfac <_stogir.checked-schedule.validate-nodes+0x100>
    cfa8:      	b	0xcfb8 <_stogir.checked-schedule.validate-nodes+0x10c>
    cfac:      	mov	x19, x8
    cfb0:      	b	0xd020 <_stogir.checked-schedule.validate-nodes+0x174>
    cfb4:      	b	0xcfbc <_stogir.checked-schedule.validate-nodes+0x110>
    cfb8:      	b	0xd288 <_stogir.checked-schedule.validate-nodes+0x3dc>
    cfbc:      	cmp	x28, #0x0
    cfc0:      	b.ne	0xd2f0 <_stogir.checked-schedule.validate-nodes+0x444>
    cfc4:      	sxtw	x3, w4
    cfc8:      	cmp	x3, #0x0
    cfcc:      	cset	w5, gt
    cfd0:      	movz	x16, #0x0, lsl #48
    cfd4:      	sub	x6, x16, x3
    cfd8:      	sub	x7, x6, #0x1
    cfdc:      	uxtb	w16, w5
    cfe0:      	cmp	w16, wzr
    cfe4:      	b.eq	0xd080 <_stogir.checked-schedule.validate-nodes+0x1d4>
    cfe8:      	ldr	x6, [x0, #0x8]
    cfec:      	cmp	x3, x6
    cff0:      	b.ge	0xd0c0 <_stogir.checked-schedule.validate-nodes+0x214>
    cff4:      	ldr	x6, [x20, #0x8]
    cff8:      	cmp	x3, x6
    cffc:      	b.ge	0xd200 <_stogir.checked-schedule.validate-nodes+0x354>
    d000:      	ldr	x6, [x0, #0x78]
    d004:      	add	x6, x6, x3, lsl #2
    d008:      	ldr	w6, [x6]
    d00c:      	sxtw	x6, w6
    d010:      	cmp	x6, #0x0
    d014:      	cset	w6, ge
    d018:      	ubfx	x6, x6, #0, #8
    d01c:      	b	0xd204 <_stogir.checked-schedule.validate-nodes+0x358>
    d020:      	cmp	x28, #0x0
    d024:      	b.ne	0xd038 <_stogir.checked-schedule.validate-nodes+0x18c>
    d028:      	and	x27, x26, #0xffffffff
    d02c:      	movz	x0, #0x0, lsl #48
    d030:      	movz	x28, #0x0, lsl #48
    d034:      	b	0xd03c <_stogir.checked-schedule.validate-nodes+0x190>
    d038:      	mov	x0, #0x1                ; =1
    d03c:      	str	x0, [x19]
    d040:      	str	x27, [x19, #0x8]
    d044:      	str	x28, [x19, #0x10]
    d048:      	ldr	x19, [sp, #0x88]
    d04c:      	ldr	x20, [sp, #0x90]
    d050:      	ldr	x21, [sp, #0x98]
    d054:      	ldr	x22, [sp, #0xa0]
    d058:      	ldr	x23, [sp, #0xa8]
    d05c:      	ldr	x24, [sp, #0xb0]
    d060:      	ldr	x25, [sp, #0xb8]
    d064:      	ldr	x26, [sp, #0xc0]
    d068:      	ldr	x27, [sp, #0xc8]
    d06c:      	ldr	x28, [sp, #0xd0]
    d070:      	ldr	x29, [sp]
    d074:      	ldr	x30, [sp, #0x8]
    d078:      	add	sp, sp, #0xe0
    d07c:      	ret
    d080:      	cmp	x3, #0x0
    d084:      	b.ge	0xd0c8 <_stogir.checked-schedule.validate-nodes+0x21c>
    d088:      	ldr	x9, [x19, #0x8]
    d08c:      	ldr	x10, [x21, #0x8]
    d090:      	cmp	x9, x10
    d094:      	b.ne	0xd1f8 <_stogir.checked-schedule.validate-nodes+0x34c>
    d098:      	cmp	x6, x9
    d09c:      	b.gt	0xd270 <_stogir.checked-schedule.validate-nodes+0x3c4>
    d0a0:      	ldr	x6, [x0, #0x50]
    d0a4:      	add	x6, x6, x7, lsl #2
    d0a8:      	ldr	w6, [x6]
    d0ac:      	sxtw	x6, w6
    d0b0:      	cmp	x6, #0x0
    d0b4:      	cset	w6, gt
    d0b8:      	ubfx	x6, x6, #0, #8
    d0bc:      	b	0xd274 <_stogir.checked-schedule.validate-nodes+0x3c8>
    d0c0:      	movz	x6, #0x0, lsl #48
    d0c4:      	b	0xd0cc <_stogir.checked-schedule.validate-nodes+0x220>
    d0c8:      	movz	x6, #0x0, lsl #48
    d0cc:      	cmp	x6, #0x0
    d0d0:      	b.eq	0xd10c <_stogir.checked-schedule.validate-nodes+0x260>
    d0d4:      	uxtb	w16, w5
    d0d8:      	cmp	w16, wzr
    d0dc:      	b.eq	0xd0f4 <_stogir.checked-schedule.validate-nodes+0x248>
    d0e0:      	ldr	x5, [x0]
    d0e4:      	add	x3, x5, x3, lsl #4
    d0e8:      	ldr	x5, [x3]
    d0ec:      	ldr	x3, [x3, #0x8]
    d0f0:      	b	0xd104 <_stogir.checked-schedule.validate-nodes+0x258>
    d0f4:      	ldr	x3, [x0, #0x28]
    d0f8:      	add	x3, x3, x7, lsl #4
    d0fc:      	ldr	x5, [x3]
    d100:      	ldr	x3, [x3, #0x8]
    d104:      	mov	w6, #0x1                ; =1
    d108:      	b	0xd118 <_stogir.checked-schedule.validate-nodes+0x26c>
    d10c:      	movz	w6, #0x0, lsl #16
    d110:      	movz	x5, #0x0, lsl #48
    d114:      	movz	x3, #0x0, lsl #48
    d118:      	ubfx	x6, x6, #0, #32
    d11c:      	lsr	x16, x6, #0
    d120:      	cmp	x16, #0x1
    d124:      	b.eq	0xd158 <_stogir.checked-schedule.validate-nodes+0x2ac>
    d128:      	b.lo	0xd130 <_stogir.checked-schedule.validate-nodes+0x284>
    d12c:      	b	0xd15c <_stogir.checked-schedule.validate-nodes+0x2b0>
    d130:      	cmp	x16, #0x0
    d134:      	b.eq	0xd13c <_stogir.checked-schedule.validate-nodes+0x290>
    d138:      	b	0xd15c <_stogir.checked-schedule.validate-nodes+0x2b0>
    d13c:      	str	x0, [sp, #0x68]
    d140:      	str	x19, [sp, #0x60]
    d144:      	mov	x19, x8
    d148:      	str	x20, [sp, #0x70]
    d14c:      	mov	w20, w1
    d150:      	str	x2, [sp, #0x78]
    d154:      	b	0xcf34 <_stogir.checked-schedule.validate-nodes+0x88>
    d158:      	b	0xd160 <_stogir.checked-schedule.validate-nodes+0x2b4>
    d15c:      	b	0xd2d8 <_stogir.checked-schedule.validate-nodes+0x42c>
    d160:      	uxtb	w6, w5
    d164:      	add	x16, sp, #0x10
    d168:      	str	x5, [x16]
    d16c:      	add	x16, sp, #0x10
    d170:      	str	x3, [x16, #0x8]
    d174:      	cmp	x6, #0x29
    d178:      	b.lt	0xd30c <_stogir.checked-schedule.validate-nodes+0x460>
    d17c:      	cmp	x6, #0x2b
    d180:      	b.gt	0xd32c <_stogir.checked-schedule.validate-nodes+0x480>
    d184:      	str	x0, [sp, #0x68]
    d188:      	str	x2, [sp, #0x78]
    d18c:      	str	w4, [sp, #0x80]
    d190:      	str	x19, [sp, #0x60]
    d194:      	mov	x19, x8
    d198:      	add	x8, sp, #0x20
    d19c:      	str	x20, [sp, #0x70]
    d1a0:      	mov	w20, w1
    d1a4:      	mov	w1, w4
    d1a8:      	bl	0xd1a8 <_stogir.checked-schedule.validate-nodes+0x2fc>
		000000000000d1a8:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    d1ac:      	add	x16, sp, #0x20
    d1b0:      	ldr	w0, [x16]
    d1b4:      	lsr	x16, x0, #0
    d1b8:      	cmp	x16, #0x1
    d1bc:      	b.eq	0xd1d8 <_stogir.checked-schedule.validate-nodes+0x32c>
    d1c0:      	b.lo	0xd1c8 <_stogir.checked-schedule.validate-nodes+0x31c>
    d1c4:      	b	0xd1dc <_stogir.checked-schedule.validate-nodes+0x330>
    d1c8:      	cmp	x16, #0x0
    d1cc:      	b.eq	0xd1d4 <_stogir.checked-schedule.validate-nodes+0x328>
    d1d0:      	b	0xd1dc <_stogir.checked-schedule.validate-nodes+0x330>
    d1d4:      	b	0xd290 <_stogir.checked-schedule.validate-nodes+0x3e4>
    d1d8:      	b	0xd1e0 <_stogir.checked-schedule.validate-nodes+0x334>
    d1dc:      	b	0xd2e8 <_stogir.checked-schedule.validate-nodes+0x43c>
    d1e0:      	add	x16, sp, #0x20
    d1e4:      	ldr	x27, [x16, #0x8]
    d1e8:      	ldr	x28, [x22, #0x8]
    d1ec:      	b	0xd294 <_stogir.checked-schedule.validate-nodes+0x3e8>
    d1f0:      	movz	w20, #0x0, lsl #16
    d1f4:      	b	0xcf40 <_stogir.checked-schedule.validate-nodes+0x94>
    d1f8:      	movz	x6, #0x0, lsl #48
    d1fc:      	b	0xd0cc <_stogir.checked-schedule.validate-nodes+0x220>
    d200:      	movz	x6, #0x0, lsl #48
    d204:      	b	0xd0c4 <_stogir.checked-schedule.validate-nodes+0x218>
    d208:      	add	x16, sp, #0x10
    d20c:      	ldr	w0, [x16]
    d210:      	uxtb	w0, w0
    d214:      	cmp	x0, #0x2c
    d218:      	b.ne	0xd1f0 <_stogir.checked-schedule.validate-nodes+0x344>
    d21c:      	add	x8, sp, #0x40
    d220:      	ldr	x0, [sp, #0x68]
    d224:      	ldr	w1, [sp, #0x80]
    d228:      	bl	0xd228 <_stogir.checked-schedule.validate-nodes+0x37c>
		000000000000d228:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    d22c:      	add	x16, sp, #0x40
    d230:      	ldr	w0, [x16]
    d234:      	lsr	x16, x0, #0
    d238:      	cmp	x16, #0x1
    d23c:      	b.eq	0xd258 <_stogir.checked-schedule.validate-nodes+0x3ac>
    d240:      	b.lo	0xd248 <_stogir.checked-schedule.validate-nodes+0x39c>
    d244:      	b	0xd25c <_stogir.checked-schedule.validate-nodes+0x3b0>
    d248:      	cmp	x16, #0x0
    d24c:      	b.eq	0xd254 <_stogir.checked-schedule.validate-nodes+0x3a8>
    d250:      	b	0xd25c <_stogir.checked-schedule.validate-nodes+0x3b0>
    d254:      	b	0xd298 <_stogir.checked-schedule.validate-nodes+0x3ec>
    d258:      	b	0xd260 <_stogir.checked-schedule.validate-nodes+0x3b4>
    d25c:      	b	0xd2e0 <_stogir.checked-schedule.validate-nodes+0x434>
    d260:      	add	x16, sp, #0x40
    d264:      	ldr	x27, [x16, #0x8]
    d268:      	ldr	x28, [x23, #0x8]
    d26c:      	b	0xd284 <_stogir.checked-schedule.validate-nodes+0x3d8>
    d270:      	movz	x6, #0x0, lsl #48
    d274:      	b	0xd1fc <_stogir.checked-schedule.validate-nodes+0x350>
    d278:      	adrp	x27, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000d278:  ARM64_RELOC_PAGE21	l_stogir.513
    d27c:      	ldr	x27, [x27]
		000000000000d27c:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    d280:      	mov	x28, #0x35              ; =53
    d284:      	b	0xd1f4 <_stogir.checked-schedule.validate-nodes+0x348>
    d288:      	brk	#0
    d28c:      	b	0xd288 <_stogir.checked-schedule.validate-nodes+0x3dc>
    d290:      	ldr	w20, [sp, #0x80]
    d294:      	b	0xd1f4 <_stogir.checked-schedule.validate-nodes+0x348>
    d298:      	add	x16, sp, #0x40
    d29c:      	ldr	w0, [x16, #0x8]
    d2a0:      	sxtw	x0, w0
    d2a4:      	cmp	x0, #0x0
    d2a8:      	b.ne	0xd2b4 <_stogir.checked-schedule.validate-nodes+0x408>
    d2ac:      	movz	w20, #0x0, lsl #16
    d2b0:      	b	0xd284 <_stogir.checked-schedule.validate-nodes+0x3d8>
    d2b4:      	sxtw	x0, w20
    d2b8:      	add	x16, sp, #0x10
    d2bc:      	ldr	w1, [x16, #0x4]
    d2c0:      	sxtw	x1, w1
    d2c4:      	cmp	x0, x1
    d2c8:      	b.ne	0xd278 <_stogir.checked-schedule.validate-nodes+0x3cc>
    d2cc:      	add	x0, x26, #0x1
    d2d0:      	sxtw	x26, w0
    d2d4:      	b	0xd284 <_stogir.checked-schedule.validate-nodes+0x3d8>
    d2d8:      	brk	#0
    d2dc:      	b	0xd2d8 <_stogir.checked-schedule.validate-nodes+0x42c>
    d2e0:      	brk	#0
    d2e4:      	b	0xd2e0 <_stogir.checked-schedule.validate-nodes+0x434>
    d2e8:      	brk	#0
    d2ec:      	b	0xd2e8 <_stogir.checked-schedule.validate-nodes+0x43c>
    d2f0:      	str	x0, [sp, #0x68]
    d2f4:      	str	x19, [sp, #0x60]
    d2f8:      	mov	x19, x8
    d2fc:      	str	x20, [sp, #0x70]
    d300:      	mov	w20, w1
    d304:      	str	x2, [sp, #0x78]
    d308:      	b	0xcf40 <_stogir.checked-schedule.validate-nodes+0x94>
    d30c:      	str	x0, [sp, #0x68]
    d310:      	str	w4, [sp, #0x80]
    d314:      	str	x19, [sp, #0x60]
    d318:      	mov	x19, x8
    d31c:      	str	x20, [sp, #0x70]
    d320:      	mov	w20, w1
    d324:      	str	x2, [sp, #0x78]
    d328:      	b	0xd208 <_stogir.checked-schedule.validate-nodes+0x35c>
    d32c:      	str	x0, [sp, #0x68]
    d330:      	str	w4, [sp, #0x80]
    d334:      	str	x19, [sp, #0x60]
    d338:      	mov	x19, x8
    d33c:      	str	x20, [sp, #0x70]
    d340:      	mov	w20, w1
    d344:      	str	x2, [sp, #0x78]
    d348:      	b	0xd208 <_stogir.checked-schedule.validate-nodes+0x35c>

000000000000d34c <_coil.alloc.sized-free>:
    d34c:      	sub	sp, sp, #0x70
    d350:      	str	x29, [sp]
    d354:      	str	x30, [sp, #0x8]
    d358:      	mov	x29, sp
    d35c:      	str	x19, [sp, #0x60]
    d360:      	str	x20, [sp, #0x68]
    d364:      	cmp	x2, #0x0
    d368:      	b.ne	0xd388 <_coil.alloc.sized-free+0x3c>
    d36c:      	movz	x0, #0x0, lsl #48
    d370:      	ldr	x19, [sp, #0x60]
    d374:      	ldr	x20, [sp, #0x68]
    d378:      	ldr	x29, [sp]
    d37c:      	ldr	x30, [sp, #0x8]
    d380:      	add	sp, sp, #0x70
    d384:      	ret
    d388:      	add	x8, sp, #0x10
    d38c:      	mov	x19, x0
    d390:      	mov	x0, x3
    d394:      	mov	x3, x2
    d398:      	mov	x2, x5
    d39c:      	mov	x20, x1
    d3a0:      	mov	x1, x4
    d3a4:      	bl	0xd3a4 <_coil.alloc.sized-free+0x58>
		000000000000d3a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    d3a8:      	add	x16, sp, #0x10
    d3ac:      	ldr	w0, [x16]
    d3b0:      	lsr	x16, x0, #0
    d3b4:      	cmp	x16, #0x1
    d3b8:      	b.eq	0xd3d4 <_coil.alloc.sized-free+0x88>
    d3bc:      	b.lo	0xd3c4 <_coil.alloc.sized-free+0x78>
    d3c0:      	b	0xd3d8 <_coil.alloc.sized-free+0x8c>
    d3c4:      	cmp	x16, #0x0
    d3c8:      	b.eq	0xd3d0 <_coil.alloc.sized-free+0x84>
    d3cc:      	b	0xd3d8 <_coil.alloc.sized-free+0x8c>
    d3d0:      	b	0xd3dc <_coil.alloc.sized-free+0x90>
    d3d4:      	b	0xd3e4 <_coil.alloc.sized-free+0x98>
    d3d8:      	b	0xd438 <_coil.alloc.sized-free+0xec>
    d3dc:      	movz	x0, #0x0, lsl #48
    d3e0:      	b	0xd434 <_coil.alloc.sized-free+0xe8>
    d3e4:      	add	x16, sp, #0x10
    d3e8:      	orr	x0, x16, xzr
    d3ec:      	add	x0, x0, #0x8
    d3f0:      	add	x16, sp, #0x10
    d3f4:      	ldr	x1, [x16, #0x8]
    d3f8:      	add	x16, sp, #0x40
    d3fc:      	str	x1, [x16]
    d400:      	ldr	x1, [x0, #0x8]
    d404:      	add	x16, sp, #0x40
    d408:      	str	x1, [x16, #0x8]
    d40c:      	ldr	x1, [x0, #0x10]
    d410:      	add	x16, sp, #0x40
    d414:      	str	x1, [x16, #0x10]
    d418:      	ldr	x0, [x0, #0x18]
    d41c:      	add	x16, sp, #0x40
    d420:      	str	x0, [x16, #0x18]
    d424:      	mov	x0, x19
    d428:      	mov	x1, x20
    d42c:      	add	x2, sp, #0x40
    d430:      	bl	0xd430 <_coil.alloc.sized-free+0xe4>
		000000000000d430:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-free
    d434:      	b	0xd370 <_coil.alloc.sized-free+0x24>
    d438:      	brk	#0
    d43c:      	b	0xd438 <_coil.alloc.sized-free+0xec>

000000000000d440 <_stogir.types.valid?>:
    d440:      	sxtw	x1, w0
    d444:      	cmp	x1, #0x0
    d448:      	b.lt	0xd45c <_stogir.types.valid?+0x1c>
    d44c:      	cmp	x1, #0xd
    d450:      	b.gt	0xd45c <_stogir.types.valid?+0x1c>
    d454:      	mov	x0, #0x1                ; =1
    d458:      	b	0xd498 <_stogir.types.valid?+0x58>
    d45c:      	cmp	x1, #0xf
    d460:      	b.le	0xd494 <_stogir.types.valid?+0x54>
    d464:      	cmp	x1, #0x80
    d468:      	b.ge	0xd48c <_stogir.types.valid?+0x4c>
    d46c:      	and	w0, w0, #0xf
    d470:      	ubfx	x0, x0, #0, #32
    d474:      	cmp	x0, #0x1
    d478:      	b.lt	0xd49c <_stogir.types.valid?+0x5c>
    d47c:      	cmp	x0, #0xd
    d480:      	cset	w0, le
    d484:      	ubfx	x0, x0, #0, #8
    d488:      	b	0xd4a0 <_stogir.types.valid?+0x60>
    d48c:      	movz	x0, #0x0, lsl #48
    d490:      	b	0xd498 <_stogir.types.valid?+0x58>
    d494:      	movz	x0, #0x0, lsl #48
    d498:      	ret
    d49c:      	movz	x0, #0x0, lsl #48
    d4a0:      	b	0xd490 <_stogir.types.valid?+0x50>

000000000000d4a4 <_stogir.opcode.input-count>:
    d4a4:      	sxtw	x0, w0
    d4a8:      	cmp	x0, #0x0
    d4ac:      	b.lt	0xd4d0 <_stogir.opcode.input-count+0x2c>
    d4b0:      	cmp	x0, #0x83
    d4b4:      	b.ge	0xd4d0 <_stogir.opcode.input-count+0x2c>
    d4b8:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000d4b8:  ARM64_RELOC_PAGE21	l_stogir.514
    d4bc:      	ldr	x16, [x16]
		000000000000d4bc:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    d4c0:      	add	x0, x16, x0
    d4c4:      	ldrsb	w0, [x0]
    d4c8:      	sxtb	x0, w0
    d4cc:      	b	0xd4d4 <_stogir.opcode.input-count+0x30>
    d4d0:      	mov	x0, #-0x2               ; =-2
    d4d4:      	ret

000000000000d4d8 <_stogir.graph.borrow-node>:
    d4d8:      	sxtw	x1, w1
    d4dc:      	add	x2, x0, #0x28
    d4e0:      	cmp	x1, #0x0
    d4e4:      	cset	w3, gt
    d4e8:      	movz	x16, #0x0, lsl #48
    d4ec:      	sub	x4, x16, x1
    d4f0:      	sub	x5, x4, #0x1
    d4f4:      	uxtb	w16, w3
    d4f8:      	cmp	w16, wzr
    d4fc:      	b.eq	0xd53c <_stogir.graph.borrow-node+0x64>
    d500:      	ldr	x2, [x0, #0x8]
    d504:      	cmp	x1, x2
    d508:      	b.ge	0xd588 <_stogir.graph.borrow-node+0xb0>
    d50c:      	add	x2, x0, #0x78
    d510:      	ldr	x2, [x2, #0x8]
    d514:      	cmp	x1, x2
    d518:      	b.ge	0xd5c8 <_stogir.graph.borrow-node+0xf0>
    d51c:      	ldr	x2, [x0, #0x78]
    d520:      	add	x2, x2, x1, lsl #2
    d524:      	ldr	w2, [x2]
    d528:      	sxtw	x2, w2
    d52c:      	cmp	x2, #0x0
    d530:      	cset	w2, ge
    d534:      	ubfx	x2, x2, #0, #8
    d538:      	b	0xd5cc <_stogir.graph.borrow-node+0xf4>
    d53c:      	cmp	x1, #0x0
    d540:      	b.ge	0xd590 <_stogir.graph.borrow-node+0xb8>
    d544:      	add	x6, x0, #0x50
    d548:      	ldr	x2, [x2, #0x8]
    d54c:      	ldr	x6, [x6, #0x8]
    d550:      	cmp	x2, x6
    d554:      	b.ne	0xd580 <_stogir.graph.borrow-node+0xa8>
    d558:      	cmp	x4, x2
    d55c:      	b.gt	0xd5d0 <_stogir.graph.borrow-node+0xf8>
    d560:      	ldr	x2, [x0, #0x50]
    d564:      	add	x2, x2, x5, lsl #2
    d568:      	ldr	w2, [x2]
    d56c:      	sxtw	x2, w2
    d570:      	cmp	x2, #0x0
    d574:      	cset	w2, gt
    d578:      	ubfx	x2, x2, #0, #8
    d57c:      	b	0xd5d4 <_stogir.graph.borrow-node+0xfc>
    d580:      	movz	x2, #0x0, lsl #48
    d584:      	b	0xd594 <_stogir.graph.borrow-node+0xbc>
    d588:      	movz	x2, #0x0, lsl #48
    d58c:      	b	0xd594 <_stogir.graph.borrow-node+0xbc>
    d590:      	movz	x2, #0x0, lsl #48
    d594:      	cmp	x2, #0x0
    d598:      	b.eq	0xd5c0 <_stogir.graph.borrow-node+0xe8>
    d59c:      	uxtb	w16, w3
    d5a0:      	cmp	w16, wzr
    d5a4:      	b.eq	0xd5b4 <_stogir.graph.borrow-node+0xdc>
    d5a8:      	ldr	x0, [x0]
    d5ac:      	add	x0, x0, x1, lsl #4
    d5b0:      	b	0xd5bc <_stogir.graph.borrow-node+0xe4>
    d5b4:      	ldr	x0, [x0, #0x28]
    d5b8:      	add	x0, x0, x5, lsl #4
    d5bc:      	b	0xd5c4 <_stogir.graph.borrow-node+0xec>
    d5c0:      	movz	x0, #0x0, lsl #48
    d5c4:      	ret
    d5c8:      	movz	x2, #0x0, lsl #48
    d5cc:      	b	0xd58c <_stogir.graph.borrow-node+0xb4>
    d5d0:      	movz	x2, #0x0, lsl #48
    d5d4:      	b	0xd584 <_stogir.graph.borrow-node+0xac>

000000000000d5d8 <_stogir.verify.phis-structured>:
    d5d8:      	sub	sp, sp, #0xd0
    d5dc:      	str	x29, [sp, #0x10]
    d5e0:      	str	x30, [sp, #0x18]
    d5e4:      	add	x29, sp, #0x10
    d5e8:      	str	x19, [sp, #0x78]
    d5ec:      	str	x20, [sp, #0x80]
    d5f0:      	str	x21, [sp, #0x88]
    d5f4:      	str	x22, [sp, #0x90]
    d5f8:      	str	x23, [sp, #0x98]
    d5fc:      	str	x24, [sp, #0xa0]
    d600:      	str	x25, [sp, #0xa8]
    d604:      	str	x26, [sp, #0xb0]
    d608:      	str	x27, [sp, #0xb8]
    d60c:      	str	x28, [sp, #0xc0]
    d610:      	add	x19, x0, #0x78
    d614:      	add	x20, x0, #0x28
    d618:      	add	x21, x0, #0x50
    d61c:      	mov	x22, #0x1               ; =1
    d620:      	movz	x23, #0x0, lsl #48
    d624:      	adrp	x24, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000d624:  ARM64_RELOC_PAGE21	l_stogir.515
    d628:      	ldr	x24, [x24]
		000000000000d628:  ARM64_RELOC_PAGEOFF12	l_stogir.515
    d62c:      	movz	x25, #0x0, lsl #48
    d630:      	b	0xd918 <_stogir.verify.phis-structured+0x340>
    d634:      	movz	x6, #0x0, lsl #48
    d638:      	b	0xd648 <_stogir.verify.phis-structured+0x70>
    d63c:      	movz	x6, #0x0, lsl #48
    d640:      	b	0xd650 <_stogir.verify.phis-structured+0x78>
    d644:      	movz	x6, #0x0, lsl #48
    d648:      	b	0xd658 <_stogir.verify.phis-structured+0x80>
    d64c:      	movz	x6, #0x0, lsl #48
    d650:      	b	0xd658 <_stogir.verify.phis-structured+0x80>
    d654:      	movz	x6, #0x0, lsl #48
    d658:      	cmp	x6, #0x0
    d65c:      	b.eq	0xd690 <_stogir.verify.phis-structured+0xb8>
    d660:      	uxtb	w16, w5
    d664:      	cmp	w16, wzr
    d668:      	b.eq	0xd67c <_stogir.verify.phis-structured+0xa4>
    d66c:      	ldr	x5, [x24]
    d670:      	add	x4, x5, x4, lsl #4
    d674:      	ldr	x4, [x4]
    d678:      	b	0xd688 <_stogir.verify.phis-structured+0xb0>
    d67c:      	ldr	x4, [x24, #0x28]
    d680:      	add	x4, x4, x7, lsl #4
    d684:      	ldr	x4, [x4]
    d688:      	mov	w5, #0x1                ; =1
    d68c:      	b	0xd698 <_stogir.verify.phis-structured+0xc0>
    d690:      	movz	w5, #0x0, lsl #16
    d694:      	movz	x4, #0x0, lsl #48
    d698:      	ubfx	x5, x5, #0, #32
    d69c:      	lsr	x16, x5, #0
    d6a0:      	cmp	x16, #0x1
    d6a4:      	b.eq	0xd6c0 <_stogir.verify.phis-structured+0xe8>
    d6a8:      	b.lo	0xd6b0 <_stogir.verify.phis-structured+0xd8>
    d6ac:      	b	0xd6c4 <_stogir.verify.phis-structured+0xec>
    d6b0:      	cmp	x16, #0x0
    d6b4:      	b.eq	0xd6bc <_stogir.verify.phis-structured+0xe4>
    d6b8:      	b	0xd6c4 <_stogir.verify.phis-structured+0xec>
    d6bc:      	b	0xd6c8 <_stogir.verify.phis-structured+0xf0>
    d6c0:      	b	0xd6dc <_stogir.verify.phis-structured+0x104>
    d6c4:      	b	0xdb20 <_stogir.verify.phis-structured+0x548>
    d6c8:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000d6c8:  ARM64_RELOC_PAGE21	l_stogir.516
    d6cc:      	ldr	x16, [x16]
		000000000000d6cc:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    d6d0:      	str	x16, [sp, #0x68]
    d6d4:      	mov	x25, #0x11              ; =17
    d6d8:      	b	0xd6fc <_stogir.verify.phis-structured+0x124>
    d6dc:      	ubfx	x4, x4, #0, #32
    d6e0:      	ubfx	x4, x4, #8, #8
    d6e4:      	cmp	x4, x0
    d6e8:      	b.eq	0xd6fc <_stogir.verify.phis-structured+0x124>
    d6ec:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000d6ec:  ARM64_RELOC_PAGE21	l_stogir.517
    d6f0:      	ldr	x16, [x16]
		000000000000d6f0:  ARM64_RELOC_PAGEOFF12	l_stogir.517
    d6f4:      	str	x16, [sp, #0x68]
    d6f8:      	mov	x25, #0x1a              ; =26
    d6fc:      	b	0xd754 <_stogir.verify.phis-structured+0x17c>
    d700:      	movz	w5, #0x0, lsl #16
    d704:      	movz	w4, #0x0, lsl #16
    d708:      	b	0xd714 <_stogir.verify.phis-structured+0x13c>
    d70c:      	movz	w5, #0x0, lsl #16
    d710:      	movz	w4, #0x0, lsl #16
    d714:      	ubfx	x5, x5, #0, #32
    d718:      	lsr	x16, x5, #0
    d71c:      	cmp	x16, #0x1
    d720:      	b.eq	0xd73c <_stogir.verify.phis-structured+0x164>
    d724:      	b.lo	0xd72c <_stogir.verify.phis-structured+0x154>
    d728:      	b	0xd740 <_stogir.verify.phis-structured+0x168>
    d72c:      	cmp	x16, #0x0
    d730:      	b.eq	0xd738 <_stogir.verify.phis-structured+0x160>
    d734:      	b	0xd740 <_stogir.verify.phis-structured+0x168>
    d738:      	b	0xd744 <_stogir.verify.phis-structured+0x16c>
    d73c:      	b	0xd7c4 <_stogir.verify.phis-structured+0x1ec>
    d740:      	b	0xdb18 <_stogir.verify.phis-structured+0x540>
    d744:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000d744:  ARM64_RELOC_PAGE21	l_stogir.516
    d748:      	ldr	x16, [x16]
		000000000000d748:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    d74c:      	str	x16, [sp, #0x68]
    d750:      	mov	x25, #0x11              ; =17
    d754:      	add	x3, x3, #0x1
    d758:      	sxtw	x3, w3
    d75c:      	cmp	x25, #0x0
    d760:      	b.ne	0xd774 <_stogir.verify.phis-structured+0x19c>
    d764:      	cmp	x3, x27
    d768:      	cset	w4, le
    d76c:      	ubfx	x4, x4, #0, #8
    d770:      	b	0xd778 <_stogir.verify.phis-structured+0x1a0>
    d774:      	movz	x4, #0x0, lsl #48
    d778:      	cmp	x4, #0x0
    d77c:      	b.eq	0xd8e4 <_stogir.verify.phis-structured+0x30c>
    d780:      	uxtb	w16, w1
    d784:      	cmp	w16, wzr
    d788:      	b.ne	0xd70c <_stogir.verify.phis-structured+0x134>
    d78c:      	ldr	x4, [x24, #0x8]
    d790:      	cmp	x28, x4
    d794:      	b.ge	0xd828 <_stogir.verify.phis-structured+0x250>
    d798:      	ldr	x4, [x19, #0x8]
    d79c:      	cmp	x28, x4
    d7a0:      	b.ge	0xd820 <_stogir.verify.phis-structured+0x248>
    d7a4:      	ldr	x4, [x24, #0x78]
    d7a8:      	add	x4, x2, x4
    d7ac:      	ldr	w4, [x4]
    d7b0:      	sxtw	x4, w4
    d7b4:      	cmp	x4, #0x0
    d7b8:      	cset	w4, ge
    d7bc:      	ubfx	x4, x4, #0, #8
    d7c0:      	b	0xd824 <_stogir.verify.phis-structured+0x24c>
    d7c4:      	sxtw	x4, w4
    d7c8:      	cmp	x4, #0x0
    d7cc:      	cset	w5, gt
    d7d0:      	movz	x16, #0x0, lsl #48
    d7d4:      	sub	x6, x16, x4
    d7d8:      	sub	x7, x6, #0x1
    d7dc:      	uxtb	w16, w5
    d7e0:      	cmp	w16, wzr
    d7e4:      	b.eq	0xd8a4 <_stogir.verify.phis-structured+0x2cc>
    d7e8:      	ldr	x6, [x24, #0x8]
    d7ec:      	cmp	x4, x6
    d7f0:      	b.ge	0xd64c <_stogir.verify.phis-structured+0x74>
    d7f4:      	ldr	x6, [x19, #0x8]
    d7f8:      	cmp	x4, x6
    d7fc:      	b.ge	0xd63c <_stogir.verify.phis-structured+0x64>
    d800:      	ldr	x6, [x24, #0x78]
    d804:      	add	x6, x6, x4, lsl #2
    d808:      	ldr	w6, [x6]
    d80c:      	sxtw	x6, w6
    d810:      	cmp	x6, #0x0
    d814:      	cset	w6, ge
    d818:      	ubfx	x6, x6, #0, #8
    d81c:      	b	0xd640 <_stogir.verify.phis-structured+0x68>
    d820:      	movz	x4, #0x0, lsl #48
    d824:      	b	0xd82c <_stogir.verify.phis-structured+0x254>
    d828:      	movz	x4, #0x0, lsl #48
    d82c:      	cmp	x4, #0x0
    d830:      	b.eq	0xd70c <_stogir.verify.phis-structured+0x134>
    d834:      	orr	w4, w3, wzr
    d838:      	sxtw	x4, w4
    d83c:      	cmp	x4, #0x1
    d840:      	b.lt	0xd700 <_stogir.verify.phis-structured+0x128>
    d844:      	ldr	x5, [x24, #0x78]
    d848:      	add	x5, x2, x5
    d84c:      	ldr	w5, [x5]
    d850:      	sxtw	x5, w5
    d854:      	cmp	x4, x5
    d858:      	b.gt	0xd700 <_stogir.verify.phis-structured+0x128>
    d85c:      	ldr	x5, [x24]
    d860:      	asr	x16, x4, #63
    d864:      	lsr	x16, x16, #62
    d868:      	add	x6, x4, x16
    d86c:      	asr	x6, x6, #2
    d870:      	asr	x16, x4, #63
    d874:      	lsr	x16, x16, #62
    d878:      	add	x4, x4, x16
    d87c:      	and	x4, x4, #0x3
    d880:      	sub	x4, x4, x16
    d884:      	add	x6, x6, x28
    d888:      	add	x5, x5, x6, lsl #4
    d88c:      	add	x4, x5, x4, lsl #2
    d890:      	ldr	w4, [x4]
    d894:      	movn	w17, #0x0, lsl #16
    d898:      	and	w4, w4, w17
    d89c:      	mov	w5, #0x1                ; =1
    d8a0:      	b	0xd708 <_stogir.verify.phis-structured+0x130>
    d8a4:      	cmp	x4, #0x0
    d8a8:      	b.ge	0xd654 <_stogir.verify.phis-structured+0x7c>
    d8ac:      	ldr	x8, [x20, #0x8]
    d8b0:      	ldr	x9, [x21, #0x8]
    d8b4:      	cmp	x8, x9
    d8b8:      	b.ne	0xd644 <_stogir.verify.phis-structured+0x6c>
    d8bc:      	cmp	x6, x8
    d8c0:      	b.gt	0xd634 <_stogir.verify.phis-structured+0x5c>
    d8c4:      	ldr	x6, [x24, #0x50]
    d8c8:      	add	x6, x6, x7, lsl #2
    d8cc:      	ldr	w6, [x6]
    d8d0:      	sxtw	x6, w6
    d8d4:      	cmp	x6, #0x0
    d8d8:      	cset	w6, gt
    d8dc:      	ubfx	x6, x6, #0, #8
    d8e0:      	b	0xd638 <_stogir.verify.phis-structured+0x60>
    d8e4:      	add	x0, x23, #0x1
    d8e8:      	sxtw	x23, w0
    d8ec:      	add	x0, x27, #0x4
    d8f0:      	asr	x16, x0, #63
    d8f4:      	lsr	x16, x16, #62
    d8f8:      	add	x0, x0, x16
    d8fc:      	asr	x0, x0, #2
    d900:      	ldr	x1, [sp, #0x70]
    d904:      	add	x1, x0, x1
    d908:      	ldr	x8, [sp, #0x60]
    d90c:      	mov	x0, x24
    d910:      	mov	x22, x1
    d914:      	ldr	x24, [sp, #0x68]
    d918:      	cmp	x25, #0x0
    d91c:      	b.ne	0xdb68 <_stogir.verify.phis-structured+0x590>
    d920:      	ldr	x1, [x0, #0x8]
    d924:      	cmp	x22, x1
    d928:      	b.ge	0xdb74 <_stogir.verify.phis-structured+0x59c>
    d92c:      	ldr	x1, [x0]
    d930:      	add	x1, x1, x22, lsl #4
    d934:      	ldr	x26, [x1]
    d938:      	ldr	x1, [x0, #0x78]
    d93c:      	uxtb	w2, w26
    d940:      	add	x1, x1, x22, lsl #2
    d944:      	ldr	w1, [x1]
    d948:      	sxtw	x27, w1
    d94c:      	cmp	x2, #0x43
    d950:      	b.ne	0xdb80 <_stogir.verify.phis-structured+0x5a8>
    d954:      	orr	w28, w22, wzr
    d958:      	cmp	x27, #0x3
    d95c:      	b.ge	0xd9b4 <_stogir.verify.phis-structured+0x3dc>
    d960:      	str	x22, [sp, #0x70]
    d964:      	str	x8, [sp, #0x60]
    d968:      	mov	x24, x0
    d96c:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000d96c:  ARM64_RELOC_PAGE21	l_stogir.518
    d970:      	ldr	x16, [x16]
		000000000000d970:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    d974:      	str	x16, [sp, #0x68]
    d978:      	mov	x25, #0x2b              ; =43
    d97c:      	ubfx	x26, x26, #0, #32
    d980:      	ubfx	x0, x26, #8, #8
    d984:      	cmp	x0, #0x0
    d988:      	b.ne	0xd99c <_stogir.verify.phis-structured+0x3c4>
    d98c:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000d98c:  ARM64_RELOC_PAGE21	l_stogir.519
    d990:      	ldr	x16, [x16]
		000000000000d990:  ARM64_RELOC_PAGEOFF12	l_stogir.519
    d994:      	str	x16, [sp, #0x68]
    d998:      	mov	x25, #0x19              ; =25
    d99c:      	sxtw	x28, w28
    d9a0:      	cmp	x28, #0x0
    d9a4:      	cset	w1, le
    d9a8:      	lsl	x2, x28, #2
    d9ac:      	mov	x3, #0x2                ; =2
    d9b0:      	b	0xd75c <_stogir.verify.phis-structured+0x184>
    d9b4:      	mov	w1, w28
    d9b8:      	str	x8, [sp, #0x60]
    d9bc:      	str	x24, [sp, #0x68]
    d9c0:      	mov	x24, x0
    d9c4:      	mov	x2, #0x1                ; =1
    d9c8:      	bl	0xd9c8 <_stogir.verify.phis-structured+0x3f0>
		000000000000d9c8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    d9cc:      	ubfx	x0, x0, #0, #32
    d9d0:      	lsr	x16, x0, #0
    d9d4:      	cmp	x16, #0x1
    d9d8:      	b.eq	0xd9f4 <_stogir.verify.phis-structured+0x41c>
    d9dc:      	b.lo	0xd9e4 <_stogir.verify.phis-structured+0x40c>
    d9e0:      	b	0xd9f8 <_stogir.verify.phis-structured+0x420>
    d9e4:      	cmp	x16, #0x0
    d9e8:      	b.eq	0xd9f0 <_stogir.verify.phis-structured+0x418>
    d9ec:      	b	0xd9f8 <_stogir.verify.phis-structured+0x420>
    d9f0:      	b	0xd9fc <_stogir.verify.phis-structured+0x424>
    d9f4:      	b	0xda78 <_stogir.verify.phis-structured+0x4a0>
    d9f8:      	b	0xdb58 <_stogir.verify.phis-structured+0x580>
    d9fc:      	str	x22, [sp, #0x70]
    da00:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000da00:  ARM64_RELOC_PAGE21	l_stogir.520
    da04:      	ldr	x16, [x16]
		000000000000da04:  ARM64_RELOC_PAGEOFF12	l_stogir.520
    da08:      	str	x16, [sp, #0x68]
    da0c:      	mov	x25, #0x10              ; =16
    da10:      	b	0xd97c <_stogir.verify.phis-structured+0x3a4>
    da14:      	cmp	x25, #0x0
    da18:      	b.ne	0xdb94 <_stogir.verify.phis-structured+0x5bc>
    da1c:      	and	x0, x23, #0xffffffff
    da20:      	movz	x1, #0x0, lsl #48
    da24:      	movz	x25, #0x0, lsl #48
    da28:      	b	0xda30 <_stogir.verify.phis-structured+0x458>
    da2c:      	mov	x1, #0x1                ; =1
    da30:      	ldr	x2, [sp, #0x60]
    da34:      	str	x1, [x2]
    da38:      	str	x0, [x2, #0x8]
    da3c:      	str	x25, [x2, #0x10]
    da40:      	ldr	x19, [sp, #0x78]
    da44:      	ldr	x20, [sp, #0x80]
    da48:      	ldr	x21, [sp, #0x88]
    da4c:      	ldr	x22, [sp, #0x90]
    da50:      	ldr	x23, [sp, #0x98]
    da54:      	ldr	x24, [sp, #0xa0]
    da58:      	ldr	x25, [sp, #0xa8]
    da5c:      	ldr	x26, [sp, #0xb0]
    da60:      	ldr	x27, [sp, #0xb8]
    da64:      	ldr	x28, [sp, #0xc0]
    da68:      	ldr	x29, [sp, #0x10]
    da6c:      	ldr	x30, [sp, #0x18]
    da70:      	add	sp, sp, #0xd0
    da74:      	ret
    da78:      	orr	w0, w1, wzr
    da7c:      	add	x8, sp, #0x20
    da80:      	mov	w1, w0
    da84:      	str	x22, [sp, #0x70]
    da88:      	mov	w22, w0
    da8c:      	mov	x0, x24
    da90:      	bl	0xda90 <_stogir.verify.phis-structured+0x4b8>
		000000000000da90:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    da94:      	add	x16, sp, #0x20
    da98:      	ldr	w0, [x16]
    da9c:      	lsr	x16, x0, #0
    daa0:      	cmp	x16, #0x1
    daa4:      	b.eq	0xdac0 <_stogir.verify.phis-structured+0x4e8>
    daa8:      	b.lo	0xdab0 <_stogir.verify.phis-structured+0x4d8>
    daac:      	b	0xdac4 <_stogir.verify.phis-structured+0x4ec>
    dab0:      	cmp	x16, #0x0
    dab4:      	b.eq	0xdabc <_stogir.verify.phis-structured+0x4e4>
    dab8:      	b	0xdac4 <_stogir.verify.phis-structured+0x4ec>
    dabc:      	b	0xdac8 <_stogir.verify.phis-structured+0x4f0>
    dac0:      	b	0xdadc <_stogir.verify.phis-structured+0x504>
    dac4:      	b	0xdb60 <_stogir.verify.phis-structured+0x588>
    dac8:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000dac8:  ARM64_RELOC_PAGE21	l_stogir.521
    dacc:      	ldr	x16, [x16]
		000000000000dacc:  ARM64_RELOC_PAGEOFF12	l_stogir.521
    dad0:      	str	x16, [sp, #0x68]
    dad4:      	mov	x25, #0x12              ; =18
    dad8:      	b	0xdb14 <_stogir.verify.phis-structured+0x53c>
    dadc:      	sxtw	x22, w22
    dae0:      	add	x16, sp, #0x20
    dae4:      	ldr	x0, [x16, #0x8]
    dae8:      	cmp	x22, #0x0
    daec:      	b.le	0xdb04 <_stogir.verify.phis-structured+0x52c>
    daf0:      	uxtb	w0, w0
    daf4:      	cmp	x0, #0x70
    daf8:      	b.eq	0xdb28 <_stogir.verify.phis-structured+0x550>
    dafc:      	cmp	x0, #0x71
    db00:      	b.eq	0xdb28 <_stogir.verify.phis-structured+0x550>
    db04:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000db04:  ARM64_RELOC_PAGE21	l_stogir.522
    db08:      	ldr	x16, [x16]
		000000000000db08:  ARM64_RELOC_PAGEOFF12	l_stogir.522
    db0c:      	str	x16, [sp, #0x68]
    db10:      	mov	x25, #0x26              ; =38
    db14:      	b	0xda10 <_stogir.verify.phis-structured+0x438>
    db18:      	brk	#0
    db1c:      	b	0xdb18 <_stogir.verify.phis-structured+0x540>
    db20:      	brk	#0
    db24:      	b	0xdb20 <_stogir.verify.phis-structured+0x548>
    db28:      	ldr	x0, [x24, #0x78]
    db2c:      	add	x0, x0, x22, lsl #2
    db30:      	ldr	w0, [x0]
    db34:      	add	w0, w0, #0x1
    db38:      	sxtw	x0, w0
    db3c:      	cmp	x27, x0
    db40:      	b.eq	0xdb54 <_stogir.verify.phis-structured+0x57c>
    db44:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000db44:  ARM64_RELOC_PAGE21	l_stogir.523
    db48:      	ldr	x16, [x16]
		000000000000db48:  ARM64_RELOC_PAGEOFF12	l_stogir.523
    db4c:      	str	x16, [sp, #0x68]
    db50:      	mov	x25, #0x2b              ; =43
    db54:      	b	0xdb14 <_stogir.verify.phis-structured+0x53c>
    db58:      	brk	#0
    db5c:      	b	0xdb58 <_stogir.verify.phis-structured+0x580>
    db60:      	brk	#0
    db64:      	b	0xdb60 <_stogir.verify.phis-structured+0x588>
    db68:      	str	x8, [sp, #0x60]
    db6c:      	str	x24, [sp, #0x68]
    db70:      	b	0xda14 <_stogir.verify.phis-structured+0x43c>
    db74:      	str	x8, [sp, #0x60]
    db78:      	str	x24, [sp, #0x68]
    db7c:      	b	0xda14 <_stogir.verify.phis-structured+0x43c>
    db80:      	str	x22, [sp, #0x70]
    db84:      	str	x8, [sp, #0x60]
    db88:      	str	x24, [sp, #0x68]
    db8c:      	mov	x24, x0
    db90:      	b	0xd8ec <_stogir.verify.phis-structured+0x314>
    db94:      	ldr	x0, [sp, #0x68]
    db98:      	b	0xda2c <_stogir.verify.phis-structured+0x454>

000000000000db9c <_inherent$coil.arraylist.ArrayList$reserve!__i32>:
    db9c:      	sub	sp, sp, #0x50
    dba0:      	str	x29, [sp]
    dba4:      	str	x30, [sp, #0x8]
    dba8:      	mov	x29, sp
    dbac:      	str	x19, [sp, #0x40]
    dbb0:      	str	x20, [sp, #0x48]
    dbb4:      	add	x2, x0, #0x18
    dbb8:      	ldr	x3, [x0, #0x10]
    dbbc:      	ldr	x4, [x0, #0x18]
    dbc0:      	ldr	x2, [x2, #0x8]
    dbc4:      	add	x16, sp, #0x10
    dbc8:      	str	x4, [x16]
    dbcc:      	add	x16, sp, #0x10
    dbd0:      	str	x2, [x16, #0x8]
    dbd4:      	cmp	x1, x3
    dbd8:      	b.le	0xdc48 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xac>
    dbdc:      	ldr	x2, [x0]
    dbe0:      	add	x8, sp, #0x20
    dbe4:      	mov	x19, x0
    dbe8:      	add	x0, sp, #0x10
    dbec:      	mov	x20, x1
    dbf0:      	fmov	d31, x1
    dbf4:      	mov	x1, x2
    dbf8:      	mov	x2, x3
    dbfc:      	fmov	x3, d31
    dc00:      	bl	0xdc00 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x64>
		000000000000dc00:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i32
    dc04:      	add	x16, sp, #0x20
    dc08:      	ldr	w0, [x16]
    dc0c:      	lsr	x16, x0, #0
    dc10:      	cmp	x16, #0x1
    dc14:      	b.eq	0xdc30 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x94>
    dc18:      	b.lo	0xdc20 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x84>
    dc1c:      	b	0xdc34 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x98>
    dc20:      	cmp	x16, #0x0
    dc24:      	b.eq	0xdc2c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x90>
    dc28:      	b	0xdc34 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x98>
    dc2c:      	b	0xdc64 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xc8>
    dc30:      	b	0xdc38 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x9c>
    dc34:      	b	0xdc7c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe0>
    dc38:      	add	x16, sp, #0x20
    dc3c:      	ldr	x0, [x16, #0x8]
    dc40:      	str	x0, [x19]
    dc44:      	str	x20, [x19, #0x10]
    dc48:      	movz	x0, #0x0, lsl #48
    dc4c:      	ldr	x19, [sp, #0x40]
    dc50:      	ldr	x20, [sp, #0x48]
    dc54:      	ldr	x29, [sp]
    dc58:      	ldr	x30, [sp, #0x8]
    dc5c:      	add	sp, sp, #0x50
    dc60:      	ret
    dc64:      	lsl	x0, x20, #2
    dc68:      	mov	x1, x0
    dc6c:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000dc6c:  ARM64_RELOC_PAGE21	l_stogir.524
    dc70:      	ldr	x0, [x0]
		000000000000dc70:  ARM64_RELOC_PAGEOFF12	l_stogir.524
    dc74:      	bl	0xdc74 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xd8>
		000000000000dc74:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    dc78:      	b	0xdc78 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xdc>
    dc7c:      	brk	#0
    dc80:      	b	0xdc7c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe0>

000000000000dc84 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge>:
    dc84:      	sub	sp, sp, #0x50
    dc88:      	str	x29, [sp]
    dc8c:      	str	x30, [sp, #0x8]
    dc90:      	mov	x29, sp
    dc94:      	str	x19, [sp, #0x40]
    dc98:      	str	x20, [sp, #0x48]
    dc9c:      	add	x2, x0, #0x18
    dca0:      	ldr	x3, [x0, #0x10]
    dca4:      	ldr	x4, [x0, #0x18]
    dca8:      	ldr	x2, [x2, #0x8]
    dcac:      	add	x16, sp, #0x10
    dcb0:      	str	x4, [x16]
    dcb4:      	add	x16, sp, #0x10
    dcb8:      	str	x2, [x16, #0x8]
    dcbc:      	cmp	x1, x3
    dcc0:      	b.le	0xdd30 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xac>
    dcc4:      	ldr	x2, [x0]
    dcc8:      	add	x8, sp, #0x20
    dccc:      	mov	x19, x0
    dcd0:      	add	x0, sp, #0x10
    dcd4:      	mov	x20, x1
    dcd8:      	fmov	d31, x1
    dcdc:      	mov	x1, x2
    dce0:      	mov	x2, x3
    dce4:      	fmov	x3, d31
    dce8:      	bl	0xdce8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x64>
		000000000000dce8:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.cfg.Edge
    dcec:      	add	x16, sp, #0x20
    dcf0:      	ldr	w0, [x16]
    dcf4:      	lsr	x16, x0, #0
    dcf8:      	cmp	x16, #0x1
    dcfc:      	b.eq	0xdd18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x94>
    dd00:      	b.lo	0xdd08 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x84>
    dd04:      	b	0xdd1c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x98>
    dd08:      	cmp	x16, #0x0
    dd0c:      	b.eq	0xdd14 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x90>
    dd10:      	b	0xdd1c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x98>
    dd14:      	b	0xdd4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xc8>
    dd18:      	b	0xdd20 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x9c>
    dd1c:      	b	0xdd64 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe0>
    dd20:      	add	x16, sp, #0x20
    dd24:      	ldr	x0, [x16, #0x8]
    dd28:      	str	x0, [x19]
    dd2c:      	str	x20, [x19, #0x10]
    dd30:      	movz	x0, #0x0, lsl #48
    dd34:      	ldr	x19, [sp, #0x40]
    dd38:      	ldr	x20, [sp, #0x48]
    dd3c:      	ldr	x29, [sp]
    dd40:      	ldr	x30, [sp, #0x8]
    dd44:      	add	sp, sp, #0x50
    dd48:      	ret
    dd4c:      	lsl	x0, x20, #4
    dd50:      	mov	x1, x0
    dd54:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000dd54:  ARM64_RELOC_PAGE21	l_stogir.525
    dd58:      	ldr	x0, [x0]
		000000000000dd58:  ARM64_RELOC_PAGEOFF12	l_stogir.525
    dd5c:      	bl	0xdd5c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xd8>
		000000000000dd5c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    dd60:      	b	0xdd60 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xdc>
    dd64:      	brk	#0
    dd68:      	b	0xdd64 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe0>

000000000000dd6c <_inherent$coil.arraylist.ArrayList$reserve!__bool>:
    dd6c:      	sub	sp, sp, #0x50
    dd70:      	str	x29, [sp]
    dd74:      	str	x30, [sp, #0x8]
    dd78:      	mov	x29, sp
    dd7c:      	str	x19, [sp, #0x40]
    dd80:      	str	x20, [sp, #0x48]
    dd84:      	add	x2, x0, #0x18
    dd88:      	ldr	x3, [x0, #0x10]
    dd8c:      	ldr	x4, [x0, #0x18]
    dd90:      	ldr	x2, [x2, #0x8]
    dd94:      	add	x16, sp, #0x10
    dd98:      	str	x4, [x16]
    dd9c:      	add	x16, sp, #0x10
    dda0:      	str	x2, [x16, #0x8]
    dda4:      	cmp	x1, x3
    dda8:      	b.le	0xde18 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xac>
    ddac:      	ldr	x2, [x0]
    ddb0:      	add	x8, sp, #0x20
    ddb4:      	mov	x19, x0
    ddb8:      	add	x0, sp, #0x10
    ddbc:      	mov	x20, x1
    ddc0:      	fmov	d31, x1
    ddc4:      	mov	x1, x2
    ddc8:      	mov	x2, x3
    ddcc:      	fmov	x3, d31
    ddd0:      	bl	0xddd0 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x64>
		000000000000ddd0:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__bool
    ddd4:      	add	x16, sp, #0x20
    ddd8:      	ldr	w0, [x16]
    dddc:      	lsr	x16, x0, #0
    dde0:      	cmp	x16, #0x1
    dde4:      	b.eq	0xde00 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x94>
    dde8:      	b.lo	0xddf0 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x84>
    ddec:      	b	0xde04 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x98>
    ddf0:      	cmp	x16, #0x0
    ddf4:      	b.eq	0xddfc <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x90>
    ddf8:      	b	0xde04 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x98>
    ddfc:      	b	0xde34 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xc8>
    de00:      	b	0xde08 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x9c>
    de04:      	b	0xde4c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe0>
    de08:      	add	x16, sp, #0x20
    de0c:      	ldr	x0, [x16, #0x8]
    de10:      	str	x0, [x19]
    de14:      	str	x20, [x19, #0x10]
    de18:      	movz	x0, #0x0, lsl #48
    de1c:      	ldr	x19, [sp, #0x40]
    de20:      	ldr	x20, [sp, #0x48]
    de24:      	ldr	x29, [sp]
    de28:      	ldr	x30, [sp, #0x8]
    de2c:      	add	sp, sp, #0x50
    de30:      	ret
    de34:      	lsr	x0, x20, #0
    de38:      	mov	x1, x0
    de3c:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000de3c:  ARM64_RELOC_PAGE21	l_stogir.526
    de40:      	ldr	x0, [x0]
		000000000000de40:  ARM64_RELOC_PAGEOFF12	l_stogir.526
    de44:      	bl	0xde44 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xd8>
		000000000000de44:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    de48:      	b	0xde48 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xdc>
    de4c:      	brk	#0
    de50:      	b	0xde4c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe0>

000000000000de54 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame>:
    de54:      	sub	sp, sp, #0x50
    de58:      	str	x29, [sp]
    de5c:      	str	x30, [sp, #0x8]
    de60:      	mov	x29, sp
    de64:      	str	x19, [sp, #0x40]
    de68:      	str	x20, [sp, #0x48]
    de6c:      	add	x2, x0, #0x18
    de70:      	ldr	x3, [x0, #0x10]
    de74:      	ldr	x4, [x0, #0x18]
    de78:      	ldr	x2, [x2, #0x8]
    de7c:      	add	x16, sp, #0x10
    de80:      	str	x4, [x16]
    de84:      	add	x16, sp, #0x10
    de88:      	str	x2, [x16, #0x8]
    de8c:      	cmp	x1, x3
    de90:      	b.le	0xdf00 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xac>
    de94:      	ldr	x2, [x0]
    de98:      	add	x8, sp, #0x20
    de9c:      	mov	x19, x0
    dea0:      	add	x0, sp, #0x10
    dea4:      	mov	x20, x1
    dea8:      	fmov	d31, x1
    deac:      	mov	x1, x2
    deb0:      	mov	x2, x3
    deb4:      	fmov	x3, d31
    deb8:      	bl	0xdeb8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x64>
		000000000000deb8:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Frame
    debc:      	add	x16, sp, #0x20
    dec0:      	ldr	w0, [x16]
    dec4:      	lsr	x16, x0, #0
    dec8:      	cmp	x16, #0x1
    decc:      	b.eq	0xdee8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x94>
    ded0:      	b.lo	0xded8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x84>
    ded4:      	b	0xdeec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x98>
    ded8:      	cmp	x16, #0x0
    dedc:      	b.eq	0xdee4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x90>
    dee0:      	b	0xdeec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x98>
    dee4:      	b	0xdf1c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xc8>
    dee8:      	b	0xdef0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x9c>
    deec:      	b	0xdf34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe0>
    def0:      	add	x16, sp, #0x20
    def4:      	ldr	x0, [x16, #0x8]
    def8:      	str	x0, [x19]
    defc:      	str	x20, [x19, #0x10]
    df00:      	movz	x0, #0x0, lsl #48
    df04:      	ldr	x19, [sp, #0x40]
    df08:      	ldr	x20, [sp, #0x48]
    df0c:      	ldr	x29, [sp]
    df10:      	ldr	x30, [sp, #0x8]
    df14:      	add	sp, sp, #0x50
    df18:      	ret
    df1c:      	lsl	x0, x20, #4
    df20:      	mov	x1, x0
    df24:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x154>
		000000000000df24:  ARM64_RELOC_PAGE21	l_stogir.527
    df28:      	ldr	x0, [x0]
		000000000000df28:  ARM64_RELOC_PAGEOFF12	l_stogir.527
    df2c:      	bl	0xdf2c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xd8>
		000000000000df2c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    df30:      	b	0xdf30 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xdc>
    df34:      	brk	#0
    df38:      	b	0xdf34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe0>

000000000000df3c <_inherent$coil.arraylist.ArrayList$reserve!__i64>:
    df3c:      	sub	sp, sp, #0x50
    df40:      	str	x29, [sp]
    df44:      	str	x30, [sp, #0x8]
    df48:      	mov	x29, sp
    df4c:      	str	x19, [sp, #0x40]
    df50:      	str	x20, [sp, #0x48]
    df54:      	add	x2, x0, #0x18
    df58:      	ldr	x3, [x0, #0x10]
    df5c:      	ldr	x4, [x0, #0x18]
    df60:      	ldr	x2, [x2, #0x8]
    df64:      	add	x16, sp, #0x10
    df68:      	str	x4, [x16]
    df6c:      	add	x16, sp, #0x10
    df70:      	str	x2, [x16, #0x8]
    df74:      	cmp	x1, x3
    df78:      	b.le	0xdfe8 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
    df7c:      	ldr	x2, [x0]
    df80:      	add	x8, sp, #0x20
    df84:      	mov	x19, x0
    df88:      	add	x0, sp, #0x10
    df8c:      	mov	x20, x1
    df90:      	fmov	d31, x1
    df94:      	mov	x1, x2
    df98:      	mov	x2, x3
    df9c:      	fmov	x3, d31
    dfa0:      	bl	0xdfa0 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x64>
		000000000000dfa0:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i64
    dfa4:      	add	x16, sp, #0x20
    dfa8:      	ldr	w0, [x16]
    dfac:      	lsr	x16, x0, #0
    dfb0:      	cmp	x16, #0x1
    dfb4:      	b.eq	0xdfd0 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
    dfb8:      	b.lo	0xdfc0 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x84>
    dfbc:      	b	0xdfd4 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x98>
    dfc0:      	cmp	x16, #0x0
    dfc4:      	b.eq	0xdfcc <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x90>
    dfc8:      	b	0xdfd4 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x98>
    dfcc:      	b	0xe004 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc8>
    dfd0:      	b	0xdfd8 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x9c>
    dfd4:      	b	0xe01c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe0>
    dfd8:      	add	x16, sp, #0x20
    dfdc:      	ldr	x0, [x16, #0x8]
    dfe0:      	str	x0, [x19]
    dfe4:      	str	x20, [x19, #0x10]
    dfe8:      	movz	x0, #0x0, lsl #48
    dfec:      	ldr	x19, [sp, #0x40]
    dff0:      	ldr	x20, [sp, #0x48]
    dff4:      	ldr	x29, [sp]
    dff8:      	ldr	x30, [sp, #0x8]
    dffc:      	add	sp, sp, #0x50
    e000:      	ret
    e004:      	lsl	x0, x20, #3
    e008:      	mov	x1, x0
    e00c:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e00c:  ARM64_RELOC_PAGE21	l_stogir.528
    e010:      	ldr	x0, [x0]
		000000000000e010:  ARM64_RELOC_PAGEOFF12	l_stogir.528
    e014:      	bl	0xe014 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xd8>
		000000000000e014:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e018:      	b	0xe018 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xdc>
    e01c:      	brk	#0
    e020:      	b	0xe01c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe0>

000000000000e024 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range>:
    e024:      	sub	sp, sp, #0x50
    e028:      	str	x29, [sp]
    e02c:      	str	x30, [sp, #0x8]
    e030:      	mov	x29, sp
    e034:      	str	x19, [sp, #0x40]
    e038:      	str	x20, [sp, #0x48]
    e03c:      	add	x2, x0, #0x18
    e040:      	ldr	x3, [x0, #0x10]
    e044:      	ldr	x4, [x0, #0x18]
    e048:      	ldr	x2, [x2, #0x8]
    e04c:      	add	x16, sp, #0x10
    e050:      	str	x4, [x16]
    e054:      	add	x16, sp, #0x10
    e058:      	str	x2, [x16, #0x8]
    e05c:      	cmp	x1, x3
    e060:      	b.le	0xe0d0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xac>
    e064:      	ldr	x2, [x0]
    e068:      	add	x8, sp, #0x20
    e06c:      	mov	x19, x0
    e070:      	add	x0, sp, #0x10
    e074:      	mov	x20, x1
    e078:      	fmov	d31, x1
    e07c:      	mov	x1, x2
    e080:      	mov	x2, x3
    e084:      	fmov	x3, d31
    e088:      	bl	0xe088 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x64>
		000000000000e088:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Range
    e08c:      	add	x16, sp, #0x20
    e090:      	ldr	w0, [x16]
    e094:      	lsr	x16, x0, #0
    e098:      	cmp	x16, #0x1
    e09c:      	b.eq	0xe0b8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x94>
    e0a0:      	b.lo	0xe0a8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x84>
    e0a4:      	b	0xe0bc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x98>
    e0a8:      	cmp	x16, #0x0
    e0ac:      	b.eq	0xe0b4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x90>
    e0b0:      	b	0xe0bc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x98>
    e0b4:      	b	0xe0ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xc8>
    e0b8:      	b	0xe0c0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x9c>
    e0bc:      	b	0xe104 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe0>
    e0c0:      	add	x16, sp, #0x20
    e0c4:      	ldr	x0, [x16, #0x8]
    e0c8:      	str	x0, [x19]
    e0cc:      	str	x20, [x19, #0x10]
    e0d0:      	movz	x0, #0x0, lsl #48
    e0d4:      	ldr	x19, [sp, #0x40]
    e0d8:      	ldr	x20, [sp, #0x48]
    e0dc:      	ldr	x29, [sp]
    e0e0:      	ldr	x30, [sp, #0x8]
    e0e4:      	add	sp, sp, #0x50
    e0e8:      	ret
    e0ec:      	lsl	x0, x20, #4
    e0f0:      	mov	x1, x0
    e0f4:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e0f4:  ARM64_RELOC_PAGE21	l_stogir.529
    e0f8:      	ldr	x0, [x0]
		000000000000e0f8:  ARM64_RELOC_PAGEOFF12	l_stogir.529
    e0fc:      	bl	0xe0fc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xd8>
		000000000000e0fc:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e100:      	b	0xe100 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xdc>
    e104:      	brk	#0
    e108:      	b	0xe104 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe0>

000000000000e10c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use>:
    e10c:      	sub	sp, sp, #0x50
    e110:      	str	x29, [sp]
    e114:      	str	x30, [sp, #0x8]
    e118:      	mov	x29, sp
    e11c:      	str	x19, [sp, #0x40]
    e120:      	str	x20, [sp, #0x48]
    e124:      	add	x2, x0, #0x18
    e128:      	ldr	x3, [x0, #0x10]
    e12c:      	ldr	x4, [x0, #0x18]
    e130:      	ldr	x2, [x2, #0x8]
    e134:      	add	x16, sp, #0x10
    e138:      	str	x4, [x16]
    e13c:      	add	x16, sp, #0x10
    e140:      	str	x2, [x16, #0x8]
    e144:      	cmp	x1, x3
    e148:      	b.le	0xe1b8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xac>
    e14c:      	ldr	x2, [x0]
    e150:      	add	x8, sp, #0x20
    e154:      	mov	x19, x0
    e158:      	add	x0, sp, #0x10
    e15c:      	mov	x20, x1
    e160:      	fmov	d31, x1
    e164:      	mov	x1, x2
    e168:      	mov	x2, x3
    e16c:      	fmov	x3, d31
    e170:      	bl	0xe170 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x64>
		000000000000e170:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Use
    e174:      	add	x16, sp, #0x20
    e178:      	ldr	w0, [x16]
    e17c:      	lsr	x16, x0, #0
    e180:      	cmp	x16, #0x1
    e184:      	b.eq	0xe1a0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x94>
    e188:      	b.lo	0xe190 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x84>
    e18c:      	b	0xe1a4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x98>
    e190:      	cmp	x16, #0x0
    e194:      	b.eq	0xe19c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x90>
    e198:      	b	0xe1a4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x98>
    e19c:      	b	0xe1d4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xc8>
    e1a0:      	b	0xe1a8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x9c>
    e1a4:      	b	0xe1ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe0>
    e1a8:      	add	x16, sp, #0x20
    e1ac:      	ldr	x0, [x16, #0x8]
    e1b0:      	str	x0, [x19]
    e1b4:      	str	x20, [x19, #0x10]
    e1b8:      	movz	x0, #0x0, lsl #48
    e1bc:      	ldr	x19, [sp, #0x40]
    e1c0:      	ldr	x20, [sp, #0x48]
    e1c4:      	ldr	x29, [sp]
    e1c8:      	ldr	x30, [sp, #0x8]
    e1cc:      	add	sp, sp, #0x50
    e1d0:      	ret
    e1d4:      	lsl	x0, x20, #3
    e1d8:      	mov	x1, x0
    e1dc:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e1dc:  ARM64_RELOC_PAGE21	l_stogir.530
    e1e0:      	ldr	x0, [x0]
		000000000000e1e0:  ARM64_RELOC_PAGEOFF12	l_stogir.530
    e1e4:      	bl	0xe1e4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xd8>
		000000000000e1e4:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e1e8:      	b	0xe1e8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xdc>
    e1ec:      	brk	#0
    e1f0:      	b	0xe1ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe0>

000000000000e1f4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range>:
    e1f4:      	sub	sp, sp, #0x50
    e1f8:      	str	x29, [sp]
    e1fc:      	str	x30, [sp, #0x8]
    e200:      	mov	x29, sp
    e204:      	str	x19, [sp, #0x40]
    e208:      	str	x20, [sp, #0x48]
    e20c:      	add	x2, x0, #0x18
    e210:      	ldr	x3, [x0, #0x10]
    e214:      	ldr	x4, [x0, #0x18]
    e218:      	ldr	x2, [x2, #0x8]
    e21c:      	add	x16, sp, #0x10
    e220:      	str	x4, [x16]
    e224:      	add	x16, sp, #0x10
    e228:      	str	x2, [x16, #0x8]
    e22c:      	cmp	x1, x3
    e230:      	b.le	0xe2a0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xac>
    e234:      	ldr	x2, [x0]
    e238:      	add	x8, sp, #0x20
    e23c:      	mov	x19, x0
    e240:      	add	x0, sp, #0x10
    e244:      	mov	x20, x1
    e248:      	fmov	d31, x1
    e24c:      	mov	x1, x2
    e250:      	mov	x2, x3
    e254:      	fmov	x3, d31
    e258:      	bl	0xe258 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x64>
		000000000000e258:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.schedule.Range
    e25c:      	add	x16, sp, #0x20
    e260:      	ldr	w0, [x16]
    e264:      	lsr	x16, x0, #0
    e268:      	cmp	x16, #0x1
    e26c:      	b.eq	0xe288 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x94>
    e270:      	b.lo	0xe278 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x84>
    e274:      	b	0xe28c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x98>
    e278:      	cmp	x16, #0x0
    e27c:      	b.eq	0xe284 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x90>
    e280:      	b	0xe28c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x98>
    e284:      	b	0xe2bc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xc8>
    e288:      	b	0xe290 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x9c>
    e28c:      	b	0xe2d4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe0>
    e290:      	add	x16, sp, #0x20
    e294:      	ldr	x0, [x16, #0x8]
    e298:      	str	x0, [x19]
    e29c:      	str	x20, [x19, #0x10]
    e2a0:      	movz	x0, #0x0, lsl #48
    e2a4:      	ldr	x19, [sp, #0x40]
    e2a8:      	ldr	x20, [sp, #0x48]
    e2ac:      	ldr	x29, [sp]
    e2b0:      	ldr	x30, [sp, #0x8]
    e2b4:      	add	sp, sp, #0x50
    e2b8:      	ret
    e2bc:      	lsl	x0, x20, #4
    e2c0:      	mov	x1, x0
    e2c4:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e2c4:  ARM64_RELOC_PAGE21	l_stogir.531
    e2c8:      	ldr	x0, [x0]
		000000000000e2c8:  ARM64_RELOC_PAGEOFF12	l_stogir.531
    e2cc:      	bl	0xe2cc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xd8>
		000000000000e2cc:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e2d0:      	b	0xe2d0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xdc>
    e2d4:      	brk	#0
    e2d8:      	b	0xe2d4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe0>

000000000000e2dc <_stogir.checked.validate>:
    e2dc:      	sub	sp, sp, #0x20
    e2e0:      	str	x29, [sp]
    e2e4:      	str	x30, [sp, #0x8]
    e2e8:      	mov	x29, sp
    e2ec:      	str	x19, [sp, #0x10]
    e2f0:      	sxtw	x1, w1
    e2f4:      	add	x2, x0, #0x78
    e2f8:      	add	x3, x0, #0x28
    e2fc:      	add	x4, x0, #0x50
    e300:      	lsl	x5, x1, #2
    e304:      	cmp	x1, #0x0
    e308:      	cset	w6, gt
    e30c:      	movz	x16, #0x0, lsl #48
    e310:      	sub	x7, x16, x1
    e314:      	sub	x9, x7, #0x1
    e318:      	uxtb	w16, w6
    e31c:      	cmp	w16, wzr
    e320:      	b.eq	0xe35c <_stogir.checked.validate+0x80>
    e324:      	ldr	x7, [x0, #0x8]
    e328:      	cmp	x1, x7
    e32c:      	b.ge	0xe3a4 <_stogir.checked.validate+0xc8>
    e330:      	ldr	x7, [x2, #0x8]
    e334:      	cmp	x1, x7
    e338:      	b.ge	0xe4f0 <_stogir.checked.validate+0x214>
    e33c:      	ldr	x7, [x0, #0x78]
    e340:      	add	x7, x5, x7
    e344:      	ldr	w7, [x7]
    e348:      	sxtw	x7, w7
    e34c:      	cmp	x7, #0x0
    e350:      	cset	w7, ge
    e354:      	ubfx	x7, x7, #0, #8
    e358:      	b	0xe4f4 <_stogir.checked.validate+0x218>
    e35c:      	cmp	x1, #0x0
    e360:      	b.ge	0xe3ac <_stogir.checked.validate+0xd0>
    e364:      	ldr	x10, [x3, #0x8]
    e368:      	ldr	x11, [x4, #0x8]
    e36c:      	cmp	x10, x11
    e370:      	b.ne	0xe39c <_stogir.checked.validate+0xc0>
    e374:      	cmp	x7, x10
    e378:      	b.gt	0xe4f8 <_stogir.checked.validate+0x21c>
    e37c:      	ldr	x7, [x0, #0x50]
    e380:      	add	x7, x7, x9, lsl #2
    e384:      	ldr	w7, [x7]
    e388:      	sxtw	x7, w7
    e38c:      	cmp	x7, #0x0
    e390:      	cset	w7, gt
    e394:      	ubfx	x7, x7, #0, #8
    e398:      	b	0xe4fc <_stogir.checked.validate+0x220>
    e39c:      	movz	x7, #0x0, lsl #48
    e3a0:      	b	0xe3b0 <_stogir.checked.validate+0xd4>
    e3a4:      	movz	x7, #0x0, lsl #48
    e3a8:      	b	0xe3b0 <_stogir.checked.validate+0xd4>
    e3ac:      	movz	x7, #0x0, lsl #48
    e3b0:      	cmp	x7, #0x0
    e3b4:      	b.eq	0xe3f0 <_stogir.checked.validate+0x114>
    e3b8:      	uxtb	w16, w6
    e3bc:      	cmp	w16, wzr
    e3c0:      	b.eq	0xe3d8 <_stogir.checked.validate+0xfc>
    e3c4:      	ldr	x6, [x0]
    e3c8:      	add	x6, x6, x1, lsl #4
    e3cc:      	ldr	x7, [x6]
    e3d0:      	ldr	x6, [x6, #0x8]
    e3d4:      	b	0xe3e8 <_stogir.checked.validate+0x10c>
    e3d8:      	ldr	x6, [x0, #0x28]
    e3dc:      	add	x6, x6, x9, lsl #4
    e3e0:      	ldr	x7, [x6]
    e3e4:      	ldr	x6, [x6, #0x8]
    e3e8:      	mov	w9, #0x1                ; =1
    e3ec:      	b	0xe3fc <_stogir.checked.validate+0x120>
    e3f0:      	movz	w9, #0x0, lsl #16
    e3f4:      	movz	x7, #0x0, lsl #48
    e3f8:      	movz	x6, #0x0, lsl #48
    e3fc:      	ubfx	x9, x9, #0, #32
    e400:      	lsr	x16, x9, #0
    e404:      	cmp	x16, #0x1
    e408:      	b.eq	0xe424 <_stogir.checked.validate+0x148>
    e40c:      	b.lo	0xe414 <_stogir.checked.validate+0x138>
    e410:      	b	0xe428 <_stogir.checked.validate+0x14c>
    e414:      	cmp	x16, #0x0
    e418:      	b.eq	0xe420 <_stogir.checked.validate+0x144>
    e41c:      	b	0xe428 <_stogir.checked.validate+0x14c>
    e420:      	b	0xe42c <_stogir.checked.validate+0x150>
    e424:      	b	0xe474 <_stogir.checked.validate+0x198>
    e428:      	b	0xe704 <_stogir.checked.validate+0x428>
    e42c:      	mov	x0, #0x1                ; =1
    e430:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e430:  ARM64_RELOC_PAGE21	l_stogir.532
    e434:      	ldr	x11, [x11]
		000000000000e434:  ARM64_RELOC_PAGEOFF12	l_stogir.532
    e438:      	mov	x12, #0x1a              ; =26
    e43c:      	b	0xe450 <_stogir.checked.validate+0x174>
    e440:      	mov	x0, #0x1                ; =1
    e444:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e444:  ARM64_RELOC_PAGE21	l_stogir.533
    e448:      	ldr	x11, [x11]
		000000000000e448:  ARM64_RELOC_PAGEOFF12	l_stogir.533
    e44c:      	mov	x12, #0x26              ; =38
    e450:      	str	x0, [x8]
    e454:      	str	x11, [x8, #0x8]
    e458:      	str	x12, [x8, #0x10]
    e45c:      	sub	sp, x29, #0x0
    e460:      	ldr	x19, [sp, #0x10]
    e464:      	ldr	x29, [sp]
    e468:      	ldr	x30, [sp, #0x8]
    e46c:      	add	sp, sp, #0x20
    e470:      	ret
    e474:      	cmp	x1, #0x0
    e478:      	b.le	0xe440 <_stogir.checked.validate+0x164>
    e47c:      	uxtb	w1, w7
    e480:      	cmp	x1, #0x29
    e484:      	b.lt	0xe440 <_stogir.checked.validate+0x164>
    e488:      	cmp	x1, #0x2b
    e48c:      	b.gt	0xe440 <_stogir.checked.validate+0x164>
    e490:      	ldr	x1, [x0, #0x78]
    e494:      	add	x1, x5, x1
    e498:      	ldr	w1, [x1]
    e49c:      	sxtw	x1, w1
    e4a0:      	cmp	x1, #0x2
    e4a4:      	b.ne	0xe440 <_stogir.checked.validate+0x164>
    e4a8:      	orr	w1, w7, wzr
    e4ac:      	mov	x5, sp
    e4b0:      	ubfx	x1, x1, #0, #32
    e4b4:      	sub	sp, sp, #0x10
    e4b8:      	mov	x9, sp
    e4bc:      	sub	sp, sp, #0x10
    e4c0:      	mov	x10, sp
    e4c4:      	ubfx	x1, x1, #8, #8
    e4c8:      	cmp	x1, #0x1
    e4cc:      	b.lt	0xe6c8 <_stogir.checked.validate+0x3ec>
    e4d0:      	cmp	x1, #0xb
    e4d4:      	b.gt	0xe6c8 <_stogir.checked.validate+0x3ec>
    e4d8:      	cmp	x1, #0x1
    e4dc:      	b.eq	0xe6c8 <_stogir.checked.validate+0x3ec>
    e4e0:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e4e0:  ARM64_RELOC_PAGE21	l_stogir.534
    e4e4:      	ldr	x11, [x11]
		000000000000e4e4:  ARM64_RELOC_PAGEOFF12	l_stogir.534
    e4e8:      	movz	x12, #0x0, lsl #48
    e4ec:      	b	0xe6d4 <_stogir.checked.validate+0x3f8>
    e4f0:      	movz	x7, #0x0, lsl #48
    e4f4:      	b	0xe3a8 <_stogir.checked.validate+0xcc>
    e4f8:      	movz	x7, #0x0, lsl #48
    e4fc:      	b	0xe3a0 <_stogir.checked.validate+0xc4>
    e500:      	mov	x0, #0x1                ; =1
    e504:      	mov	sp, x5
    e508:      	b	0xe450 <_stogir.checked.validate+0x174>
    e50c:      	movz	w9, #0x0, lsl #16
    e510:      	movz	x7, #0x0, lsl #48
    e514:      	ubfx	x9, x9, #0, #32
    e518:      	lsr	x16, x9, #0
    e51c:      	cmp	x16, #0x1
    e520:      	b.eq	0xe53c <_stogir.checked.validate+0x260>
    e524:      	b.lo	0xe52c <_stogir.checked.validate+0x250>
    e528:      	b	0xe540 <_stogir.checked.validate+0x264>
    e52c:      	cmp	x16, #0x0
    e530:      	b.eq	0xe538 <_stogir.checked.validate+0x25c>
    e534:      	b	0xe540 <_stogir.checked.validate+0x264>
    e538:      	b	0xe544 <_stogir.checked.validate+0x268>
    e53c:      	b	0xe6a8 <_stogir.checked.validate+0x3cc>
    e540:      	b	0xe71c <_stogir.checked.validate+0x440>
    e544:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e544:  ARM64_RELOC_PAGE21	l_stogir.535
    e548:      	ldr	x11, [x11]
		000000000000e548:  ARM64_RELOC_PAGEOFF12	l_stogir.535
    e54c:      	mov	x12, #0x22              ; =34
    e550:      	cmp	x6, #0x2
    e554:      	b.ge	0xe578 <_stogir.checked.validate+0x29c>
    e558:      	add	x7, x6, #0x1
    e55c:      	add	x6, x13, x6, lsl #2
    e560:      	ldr	w6, [x6]
    e564:      	movn	w17, #0x0, lsl #16
    e568:      	and	w9, w6, w17
    e56c:      	mov	x6, x7
    e570:      	mov	w7, #0x1                ; =1
    e574:      	b	0xe580 <_stogir.checked.validate+0x2a4>
    e578:      	movz	w7, #0x0, lsl #16
    e57c:      	movz	w9, #0x0, lsl #16
    e580:      	ubfx	x7, x7, #0, #32
    e584:      	lsr	x16, x7, #0
    e588:      	cmp	x16, #0x1
    e58c:      	b.eq	0xe5a8 <_stogir.checked.validate+0x2cc>
    e590:      	b.lo	0xe598 <_stogir.checked.validate+0x2bc>
    e594:      	b	0xe5ac <_stogir.checked.validate+0x2d0>
    e598:      	cmp	x16, #0x0
    e59c:      	b.eq	0xe5a4 <_stogir.checked.validate+0x2c8>
    e5a0:      	b	0xe5ac <_stogir.checked.validate+0x2d0>
    e5a4:      	b	0xe60c <_stogir.checked.validate+0x330>
    e5a8:      	b	0xe5b0 <_stogir.checked.validate+0x2d4>
    e5ac:      	b	0xe714 <_stogir.checked.validate+0x438>
    e5b0:      	sxtw	x9, w9
    e5b4:      	cmp	x9, #0x0
    e5b8:      	cset	w7, gt
    e5bc:      	movz	x16, #0x0, lsl #48
    e5c0:      	sub	x10, x16, x9
    e5c4:      	sub	x14, x10, #0x1
    e5c8:      	uxtb	w16, w7
    e5cc:      	cmp	w16, wzr
    e5d0:      	b.eq	0xe668 <_stogir.checked.validate+0x38c>
    e5d4:      	ldr	x10, [x0, #0x8]
    e5d8:      	cmp	x9, x10
    e5dc:      	b.ge	0xe660 <_stogir.checked.validate+0x384>
    e5e0:      	ldr	x10, [x2, #0x8]
    e5e4:      	cmp	x9, x10
    e5e8:      	b.ge	0xe6fc <_stogir.checked.validate+0x420>
    e5ec:      	ldr	x10, [x0, #0x78]
    e5f0:      	add	x10, x10, x9, lsl #2
    e5f4:      	ldr	w10, [x10]
    e5f8:      	sxtw	x10, w10
    e5fc:      	cmp	x10, #0x0
    e600:      	cset	w10, ge
    e604:      	ubfx	x10, x10, #0, #8
    e608:      	b	0xe700 <_stogir.checked.validate+0x424>
    e60c:      	cmp	x12, #0x0
    e610:      	b.ne	0xe500 <_stogir.checked.validate+0x224>
    e614:      	and	x11, x1, #0xffffffff
    e618:      	movz	x0, #0x0, lsl #48
    e61c:      	movz	x12, #0x0, lsl #48
    e620:      	b	0xe504 <_stogir.checked.validate+0x228>
    e624:      	ldr	x7, [x0, #0x28]
    e628:      	add	x7, x7, x14, lsl #4
    e62c:      	ldr	x7, [x7]
    e630:      	mov	w9, #0x1                ; =1
    e634:      	b	0xe514 <_stogir.checked.validate+0x238>
    e638:      	movz	x10, #0x0, lsl #48
    e63c:      	cmp	x10, #0x0
    e640:      	b.eq	0xe50c <_stogir.checked.validate+0x230>
    e644:      	uxtb	w16, w7
    e648:      	cmp	w16, wzr
    e64c:      	b.eq	0xe624 <_stogir.checked.validate+0x348>
    e650:      	ldr	x7, [x0]
    e654:      	add	x7, x7, x9, lsl #4
    e658:      	ldr	x7, [x7]
    e65c:      	b	0xe630 <_stogir.checked.validate+0x354>
    e660:      	movz	x10, #0x0, lsl #48
    e664:      	b	0xe63c <_stogir.checked.validate+0x360>
    e668:      	cmp	x9, #0x0
    e66c:      	b.ge	0xe638 <_stogir.checked.validate+0x35c>
    e670:      	ldr	x15, [x3, #0x8]
    e674:      	ldr	x19, [x4, #0x8]
    e678:      	cmp	x15, x19
    e67c:      	b.ne	0xe6f4 <_stogir.checked.validate+0x418>
    e680:      	cmp	x10, x15
    e684:      	b.gt	0xe70c <_stogir.checked.validate+0x430>
    e688:      	ldr	x10, [x0, #0x50]
    e68c:      	add	x10, x10, x14, lsl #2
    e690:      	ldr	w10, [x10]
    e694:      	sxtw	x10, w10
    e698:      	cmp	x10, #0x0
    e69c:      	cset	w10, gt
    e6a0:      	ubfx	x10, x10, #0, #8
    e6a4:      	b	0xe710 <_stogir.checked.validate+0x434>
    e6a8:      	ubfx	x7, x7, #0, #32
    e6ac:      	ubfx	x7, x7, #8, #8
    e6b0:      	cmp	x7, x1
    e6b4:      	b.eq	0xe6c4 <_stogir.checked.validate+0x3e8>
    e6b8:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e6b8:  ARM64_RELOC_PAGE21	l_stogir.536
    e6bc:      	ldr	x11, [x11]
		000000000000e6bc:  ARM64_RELOC_PAGEOFF12	l_stogir.536
    e6c0:      	mov	x12, #0x28              ; =40
    e6c4:      	b	0xe550 <_stogir.checked.validate+0x274>
    e6c8:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e6c8:  ARM64_RELOC_PAGE21	l_stogir.537
    e6cc:      	ldr	x11, [x11]
		000000000000e6cc:  ARM64_RELOC_PAGEOFF12	l_stogir.537
    e6d0:      	mov	x12, #0x36              ; =54
    e6d4:      	orr	x13, x10, xzr
    e6d8:      	lsr	x7, x7, #32
    e6dc:      	str	w7, [x9]
    e6e0:      	str	w6, [x9, #0x4]
    e6e4:      	ldr	x6, [x9]
    e6e8:      	str	x6, [x10]
    e6ec:      	movz	x6, #0x0, lsl #48
    e6f0:      	b	0xe550 <_stogir.checked.validate+0x274>
    e6f4:      	movz	x10, #0x0, lsl #48
    e6f8:      	b	0xe63c <_stogir.checked.validate+0x360>
    e6fc:      	movz	x10, #0x0, lsl #48
    e700:      	b	0xe664 <_stogir.checked.validate+0x388>
    e704:      	brk	#0
    e708:      	b	0xe704 <_stogir.checked.validate+0x428>
    e70c:      	movz	x10, #0x0, lsl #48
    e710:      	b	0xe6f8 <_stogir.checked.validate+0x41c>
    e714:      	brk	#0
    e718:      	b	0xe714 <_stogir.checked.validate+0x438>
    e71c:      	brk	#0
    e720:      	b	0xe71c <_stogir.checked.validate+0x440>

000000000000e724 <_coil.alloc.sized-request>:
    e724:      	cmp	x3, #0x0
    e728:      	b.le	0xe750 <_coil.alloc.sized-request+0x2c>
    e72c:      	cmp	x1, #0x0
    e730:      	b.le	0xe750 <_coil.alloc.sized-request+0x2c>
    e734:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    e738:      	sdiv	x4, x16, x1
    e73c:      	cmp	x3, x4
    e740:      	b.gt	0xe750 <_coil.alloc.sized-request+0x2c>
    e744:      	mul	x1, x3, x1
    e748:      	mov	x4, #0x1                ; =1
    e74c:      	b	0xe764 <_coil.alloc.sized-request+0x40>
    e750:      	movz	x4, #0x0, lsl #48
    e754:      	movz	x0, #0x0, lsl #48
    e758:      	movz	x3, #0x0, lsl #48
    e75c:      	movz	x1, #0x0, lsl #48
    e760:      	movz	x2, #0x0, lsl #48
    e764:      	str	x4, [x8]
    e768:      	str	x0, [x8, #0x8]
    e76c:      	str	x3, [x8, #0x10]
    e770:      	str	x1, [x8, #0x18]
    e774:      	str	x2, [x8, #0x20]
    e778:      	ret

000000000000e77c <_coil.alloc.raw-free>:
    e77c:      	sub	sp, sp, #0x10
    e780:      	str	x29, [sp]
    e784:      	str	x30, [sp, #0x8]
    e788:      	mov	x29, sp
    e78c:      	ldr	x3, [x2, #0x8]
    e790:      	cmp	x3, #0x0
    e794:      	b.le	0xe7dc <_coil.alloc.raw-free+0x60>
    e798:      	ldr	x3, [x2, #0x10]
    e79c:      	cmp	x3, #0x0
    e7a0:      	b.le	0xe7dc <_coil.alloc.raw-free+0x60>
    e7a4:      	ldr	x3, [x2, #0x18]
    e7a8:      	cmp	x3, #0x0
    e7ac:      	b.le	0xe7dc <_coil.alloc.raw-free+0x60>
    e7b0:      	sub	x4, x3, #0x1
    e7b4:      	and	x3, x4, x3
    e7b8:      	cmp	x3, #0x0
    e7bc:      	b.ne	0xe7dc <_coil.alloc.raw-free+0x60>
    e7c0:      	ldr	x3, [x0]
    e7c4:      	ldr	x0, [x0, #0x8]
    e7c8:      	ldr	x0, [x0, #0x18]
    e7cc:      	mov	x30, x0
    e7d0:      	mov	x0, x3
    e7d4:      	blr	x30
    e7d8:      	b	0xe7e0 <_coil.alloc.raw-free+0x64>
    e7dc:      	movz	x0, #0x0, lsl #48
    e7e0:      	ldr	x29, [sp]
    e7e4:      	ldr	x30, [sp, #0x8]
    e7e8:      	add	sp, sp, #0x10
    e7ec:      	ret

000000000000e7f0 <_coil.alloc.reallocate__i32>:
    e7f0:      	sub	sp, sp, #0x40
    e7f4:      	str	x29, [sp, #0x10]
    e7f8:      	str	x30, [sp, #0x18]
    e7fc:      	add	x29, sp, #0x10
    e800:      	str	x19, [sp, #0x30]
    e804:      	str	x20, [sp, #0x38]
    e808:      	mov	x19, x8
    e80c:      	mov	x20, x3
    e810:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e810:  ARM64_RELOC_PAGE21	l_stogir.538
    e814:      	ldr	x4, [x4]
		000000000000e814:  ARM64_RELOC_PAGEOFF12	l_stogir.538
    e818:      	mov	x5, #0x4                ; =4
    e81c:      	mov	x6, #0x4                ; =4
    e820:      	bl	0xe820 <_coil.alloc.reallocate__i32+0x30>
		000000000000e820:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    e824:      	ubfx	x0, x0, #0, #32
    e828:      	lsr	x16, x0, #0
    e82c:      	cmp	x16, #0x1
    e830:      	b.eq	0xe84c <_coil.alloc.reallocate__i32+0x5c>
    e834:      	b.lo	0xe83c <_coil.alloc.reallocate__i32+0x4c>
    e838:      	b	0xe850 <_coil.alloc.reallocate__i32+0x60>
    e83c:      	cmp	x16, #0x0
    e840:      	b.eq	0xe848 <_coil.alloc.reallocate__i32+0x58>
    e844:      	b	0xe850 <_coil.alloc.reallocate__i32+0x60>
    e848:      	b	0xe854 <_coil.alloc.reallocate__i32+0x64>
    e84c:      	b	0xe864 <_coil.alloc.reallocate__i32+0x74>
    e850:      	b	0xe88c <_coil.alloc.reallocate__i32+0x9c>
    e854:      	movz	x0, #0x0, lsl #48
    e858:      	movz	x1, #0x0, lsl #48
    e85c:      	movz	x20, #0x0, lsl #48
    e860:      	b	0xe868 <_coil.alloc.reallocate__i32+0x78>
    e864:      	mov	x0, #0x1                ; =1
    e868:      	str	x0, [x19]
    e86c:      	str	x1, [x19, #0x8]
    e870:      	str	x20, [x19, #0x10]
    e874:      	ldr	x19, [sp, #0x30]
    e878:      	ldr	x20, [sp, #0x38]
    e87c:      	ldr	x29, [sp, #0x10]
    e880:      	ldr	x30, [sp, #0x18]
    e884:      	add	sp, sp, #0x40
    e888:      	ret
    e88c:      	brk	#0
    e890:      	b	0xe88c <_coil.alloc.reallocate__i32+0x9c>
    e894:      	udf	#0x0

000000000000e898 <_coil.alloc.oom-at>:
    e898:      	sub	sp, sp, #0x20
    e89c:      	str	x29, [sp]
    e8a0:      	str	x30, [sp, #0x8]
    e8a4:      	mov	x29, sp
    e8a8:      	str	x19, [sp, #0x10]
    e8ac:      	str	x20, [sp, #0x18]
    e8b0:      	movz	x2, #0x0, lsl #48
    e8b4:      	b	0xe8bc <_coil.alloc.oom-at+0x24>
    e8b8:      	add	x2, x2, #0x1
    e8bc:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e8bc:  ARM64_RELOC_PAGE21	l_stogir.539
    e8c0:      	ldr	x17, [x17]
		000000000000e8c0:  ARM64_RELOC_PAGEOFF12	l_stogir.539
    e8c4:      	add	x3, x2, x17
    e8c8:      	ldrsb	w3, [x3]
    e8cc:      	sxtb	x3, w3
    e8d0:      	cmp	x3, #0x0
    e8d4:      	b.ne	0xe8b8 <_coil.alloc.oom-at+0x20>
    e8d8:      	mov	x19, x0
    e8dc:      	mov	x20, x1
    e8e0:      	mov	x0, #0x2                ; =2
    e8e4:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e8e4:  ARM64_RELOC_PAGE21	l_stogir.539
    e8e8:      	ldr	x1, [x1]
		000000000000e8e8:  ARM64_RELOC_PAGEOFF12	l_stogir.539
    e8ec:      	bl	0xe8ec <_coil.alloc.oom-at+0x54>
		000000000000e8ec:  ARM64_RELOC_BRANCH26	_write
    e8f0:      	movz	x0, #0x0, lsl #48
    e8f4:      	b	0xe8fc <_coil.alloc.oom-at+0x64>
    e8f8:      	add	x0, x0, #0x1
    e8fc:      	add	x1, x0, x19
    e900:      	ldrsb	w1, [x1]
    e904:      	sxtb	x1, w1
    e908:      	cmp	x1, #0x0
    e90c:      	b.ne	0xe8f8 <_coil.alloc.oom-at+0x60>
    e910:      	mov	x1, x19
    e914:      	mov	x2, x0
    e918:      	mov	x0, #0x2                ; =2
    e91c:      	bl	0xe91c <_coil.alloc.oom-at+0x84>
		000000000000e91c:  ARM64_RELOC_BRANCH26	_write
    e920:      	movz	x0, #0x0, lsl #48
    e924:      	b	0xe92c <_coil.alloc.oom-at+0x94>
    e928:      	add	x0, x0, #0x1
    e92c:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e92c:  ARM64_RELOC_PAGE21	l_stogir.540
    e930:      	ldr	x17, [x17]
		000000000000e930:  ARM64_RELOC_PAGEOFF12	l_stogir.540
    e934:      	add	x1, x0, x17
    e938:      	ldrsb	w1, [x1]
    e93c:      	sxtb	x1, w1
    e940:      	cmp	x1, #0x0
    e944:      	b.ne	0xe928 <_coil.alloc.oom-at+0x90>
    e948:      	mov	x2, x0
    e94c:      	mov	x0, #0x2                ; =2
    e950:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e950:  ARM64_RELOC_PAGE21	l_stogir.540
    e954:      	ldr	x1, [x1]
		000000000000e954:  ARM64_RELOC_PAGEOFF12	l_stogir.540
    e958:      	bl	0xe958 <_coil.alloc.oom-at+0xc0>
		000000000000e958:  ARM64_RELOC_BRANCH26	_write
    e95c:      	cmp	x20, #0x0
    e960:      	b.lt	0xea4c <_coil.alloc.oom-at+0x1b4>
    e964:      	movz	x0, #0x0, lsl #48
    e968:      	b	0xe974 <_coil.alloc.oom-at+0xdc>
    e96c:      	nop
    e970:      	add	x0, x0, #0x1
    e974:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e974:  ARM64_RELOC_PAGE21	l_stogir.541
    e978:      	ldr	x17, [x17]
		000000000000e978:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    e97c:      	add	x1, x0, x17
    e980:      	ldrsb	w1, [x1]
    e984:      	sxtb	x1, w1
    e988:      	cmp	x1, #0x0
    e98c:      	b.ne	0xe970 <_coil.alloc.oom-at+0xd8>
    e990:      	mov	x2, x0
    e994:      	mov	x0, #0x2                ; =2
    e998:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e998:  ARM64_RELOC_PAGE21	l_stogir.541
    e99c:      	ldr	x1, [x1]
		000000000000e99c:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    e9a0:      	bl	0xe9a0 <_coil.alloc.oom-at+0x108>
		000000000000e9a0:  ARM64_RELOC_BRANCH26	_write
    e9a4:      	mov	x0, #0x18               ; =24
    e9a8:      	sub	x0, x0, #0x1
    e9ac:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e9ac:  ARM64_RELOC_PAGE21	l_stogir.542
    e9b0:      	ldr	x17, [x17]
		000000000000e9b0:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    e9b4:      	add	x1, x0, x17
    e9b8:      	mov	x17, #0xa               ; =10
    e9bc:      	sdiv	x16, x20, x17
    e9c0:      	msub	x2, x16, x17, x20
    e9c4:      	mov	x17, #0xa               ; =10
    e9c8:      	sdiv	x3, x20, x17
    e9cc:      	orr	x20, x3, xzr
    e9d0:      	add	x2, x2, #0x30
    e9d4:      	uxtb	w2, w2
    e9d8:      	uxtb	w2, w2
    e9dc:      	strb	w2, [x1]
    e9e0:      	cmp	x20, #0x0
    e9e4:      	b.ne	0xe9a8 <_coil.alloc.oom-at+0x110>
    e9e8:      	mov	x16, #0x18              ; =24
    e9ec:      	sub	x1, x16, x0
    e9f0:      	adrp	x16, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000e9f0:  ARM64_RELOC_PAGE21	l_stogir.542
    e9f4:      	ldr	x16, [x16]
		000000000000e9f4:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    e9f8:      	add	x0, x16, x0
    e9fc:      	mov	x2, x1
    ea00:      	mov	x1, x0
    ea04:      	mov	x0, #0x2                ; =2
    ea08:      	bl	0xea08 <_coil.alloc.oom-at+0x170>
		000000000000ea08:  ARM64_RELOC_BRANCH26	_write
    ea0c:      	movz	x0, #0x0, lsl #48
    ea10:      	b	0xea1c <_coil.alloc.oom-at+0x184>
    ea14:      	nop
    ea18:      	add	x0, x0, #0x1
    ea1c:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ea1c:  ARM64_RELOC_PAGE21	l_stogir.543
    ea20:      	ldr	x17, [x17]
		000000000000ea20:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    ea24:      	add	x1, x0, x17
    ea28:      	ldrsb	w1, [x1]
    ea2c:      	sxtb	x1, w1
    ea30:      	cmp	x1, #0x0
    ea34:      	b.ne	0xea18 <_coil.alloc.oom-at+0x180>
    ea38:      	mov	x2, x0
    ea3c:      	mov	x0, #0x2                ; =2
    ea40:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ea40:  ARM64_RELOC_PAGE21	l_stogir.543
    ea44:      	ldr	x1, [x1]
		000000000000ea44:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    ea48:      	bl	0xea48 <_coil.alloc.oom-at+0x1b0>
		000000000000ea48:  ARM64_RELOC_BRANCH26	_write
    ea4c:      	movz	x0, #0x0, lsl #48
    ea50:      	b	0xea5c <_coil.alloc.oom-at+0x1c4>
    ea54:      	nop
    ea58:      	add	x0, x0, #0x1
    ea5c:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ea5c:  ARM64_RELOC_PAGE21	l_stogir.544
    ea60:      	ldr	x17, [x17]
		000000000000ea60:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    ea64:      	add	x1, x0, x17
    ea68:      	ldrsb	w1, [x1]
    ea6c:      	sxtb	x1, w1
    ea70:      	cmp	x1, #0x0
    ea74:      	b.ne	0xea58 <_coil.alloc.oom-at+0x1c0>
    ea78:      	mov	x2, x0
    ea7c:      	mov	x0, #0x2                ; =2
    ea80:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ea80:  ARM64_RELOC_PAGE21	l_stogir.544
    ea84:      	ldr	x1, [x1]
		000000000000ea84:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    ea88:      	bl	0xea88 <_coil.alloc.oom-at+0x1f0>
		000000000000ea88:  ARM64_RELOC_BRANCH26	_write
    ea8c:      	bl	0xea8c <_coil.alloc.oom-at+0x1f4>
		000000000000ea8c:  ARM64_RELOC_BRANCH26	_abort
    ea90:      	b	0xea90 <_coil.alloc.oom-at+0x1f8>

000000000000ea94 <_coil.alloc.reallocate__stogir.cfg.Edge>:
    ea94:      	sub	sp, sp, #0x40
    ea98:      	str	x29, [sp, #0x10]
    ea9c:      	str	x30, [sp, #0x18]
    eaa0:      	add	x29, sp, #0x10
    eaa4:      	str	x19, [sp, #0x30]
    eaa8:      	str	x20, [sp, #0x38]
    eaac:      	mov	x19, x8
    eab0:      	mov	x20, x3
    eab4:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000eab4:  ARM64_RELOC_PAGE21	l_stogir.545
    eab8:      	ldr	x4, [x4]
		000000000000eab8:  ARM64_RELOC_PAGEOFF12	l_stogir.545
    eabc:      	mov	x5, #0x10               ; =16
    eac0:      	mov	x6, #0x4                ; =4
    eac4:      	bl	0xeac4 <_coil.alloc.reallocate__stogir.cfg.Edge+0x30>
		000000000000eac4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    eac8:      	ubfx	x0, x0, #0, #32
    eacc:      	lsr	x16, x0, #0
    ead0:      	cmp	x16, #0x1
    ead4:      	b.eq	0xeaf0 <_coil.alloc.reallocate__stogir.cfg.Edge+0x5c>
    ead8:      	b.lo	0xeae0 <_coil.alloc.reallocate__stogir.cfg.Edge+0x4c>
    eadc:      	b	0xeaf4 <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    eae0:      	cmp	x16, #0x0
    eae4:      	b.eq	0xeaec <_coil.alloc.reallocate__stogir.cfg.Edge+0x58>
    eae8:      	b	0xeaf4 <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    eaec:      	b	0xeaf8 <_coil.alloc.reallocate__stogir.cfg.Edge+0x64>
    eaf0:      	b	0xeb08 <_coil.alloc.reallocate__stogir.cfg.Edge+0x74>
    eaf4:      	b	0xeb30 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>
    eaf8:      	movz	x0, #0x0, lsl #48
    eafc:      	movz	x1, #0x0, lsl #48
    eb00:      	movz	x20, #0x0, lsl #48
    eb04:      	b	0xeb0c <_coil.alloc.reallocate__stogir.cfg.Edge+0x78>
    eb08:      	mov	x0, #0x1                ; =1
    eb0c:      	str	x0, [x19]
    eb10:      	str	x1, [x19, #0x8]
    eb14:      	str	x20, [x19, #0x10]
    eb18:      	ldr	x19, [sp, #0x30]
    eb1c:      	ldr	x20, [sp, #0x38]
    eb20:      	ldr	x29, [sp, #0x10]
    eb24:      	ldr	x30, [sp, #0x18]
    eb28:      	add	sp, sp, #0x40
    eb2c:      	ret
    eb30:      	brk	#0
    eb34:      	b	0xeb30 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>

000000000000eb38 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range>:
    eb38:      	sub	sp, sp, #0x50
    eb3c:      	str	x29, [sp]
    eb40:      	str	x30, [sp, #0x8]
    eb44:      	mov	x29, sp
    eb48:      	str	x19, [sp, #0x40]
    eb4c:      	str	x20, [sp, #0x48]
    eb50:      	add	x2, x0, #0x18
    eb54:      	ldr	x3, [x0, #0x10]
    eb58:      	ldr	x4, [x0, #0x18]
    eb5c:      	ldr	x2, [x2, #0x8]
    eb60:      	add	x16, sp, #0x10
    eb64:      	str	x4, [x16]
    eb68:      	add	x16, sp, #0x10
    eb6c:      	str	x2, [x16, #0x8]
    eb70:      	cmp	x1, x3
    eb74:      	b.le	0xebe4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xac>
    eb78:      	ldr	x2, [x0]
    eb7c:      	add	x8, sp, #0x20
    eb80:      	mov	x19, x0
    eb84:      	add	x0, sp, #0x10
    eb88:      	mov	x20, x1
    eb8c:      	fmov	d31, x1
    eb90:      	mov	x1, x2
    eb94:      	mov	x2, x3
    eb98:      	fmov	x3, d31
    eb9c:      	bl	0xeb9c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x64>
		000000000000eb9c:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Range
    eba0:      	add	x16, sp, #0x20
    eba4:      	ldr	w0, [x16]
    eba8:      	lsr	x16, x0, #0
    ebac:      	cmp	x16, #0x1
    ebb0:      	b.eq	0xebcc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x94>
    ebb4:      	b.lo	0xebbc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x84>
    ebb8:      	b	0xebd0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x98>
    ebbc:      	cmp	x16, #0x0
    ebc0:      	b.eq	0xebc8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x90>
    ebc4:      	b	0xebd0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x98>
    ebc8:      	b	0xec00 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xc8>
    ebcc:      	b	0xebd4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x9c>
    ebd0:      	b	0xec18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe0>
    ebd4:      	add	x16, sp, #0x20
    ebd8:      	ldr	x0, [x16, #0x8]
    ebdc:      	str	x0, [x19]
    ebe0:      	str	x20, [x19, #0x10]
    ebe4:      	movz	x0, #0x0, lsl #48
    ebe8:      	ldr	x19, [sp, #0x40]
    ebec:      	ldr	x20, [sp, #0x48]
    ebf0:      	ldr	x29, [sp]
    ebf4:      	ldr	x30, [sp, #0x8]
    ebf8:      	add	sp, sp, #0x50
    ebfc:      	ret
    ec00:      	lsl	x0, x20, #4
    ec04:      	mov	x1, x0
    ec08:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ec08:  ARM64_RELOC_PAGE21	l_stogir.546
    ec0c:      	ldr	x0, [x0]
		000000000000ec0c:  ARM64_RELOC_PAGEOFF12	l_stogir.546
    ec10:      	bl	0xec10 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xd8>
		000000000000ec10:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    ec14:      	b	0xec14 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xdc>
    ec18:      	brk	#0
    ec1c:      	b	0xec18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe0>

000000000000ec20 <_coil.alloc.reallocate__bool>:
    ec20:      	sub	sp, sp, #0x40
    ec24:      	str	x29, [sp, #0x10]
    ec28:      	str	x30, [sp, #0x18]
    ec2c:      	add	x29, sp, #0x10
    ec30:      	str	x19, [sp, #0x30]
    ec34:      	str	x20, [sp, #0x38]
    ec38:      	mov	x19, x8
    ec3c:      	mov	x20, x3
    ec40:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ec40:  ARM64_RELOC_PAGE21	l_stogir.547
    ec44:      	ldr	x4, [x4]
		000000000000ec44:  ARM64_RELOC_PAGEOFF12	l_stogir.547
    ec48:      	mov	x5, #0x1                ; =1
    ec4c:      	mov	x6, #0x1                ; =1
    ec50:      	bl	0xec50 <_coil.alloc.reallocate__bool+0x30>
		000000000000ec50:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ec54:      	ubfx	x0, x0, #0, #32
    ec58:      	lsr	x16, x0, #0
    ec5c:      	cmp	x16, #0x1
    ec60:      	b.eq	0xec7c <_coil.alloc.reallocate__bool+0x5c>
    ec64:      	b.lo	0xec6c <_coil.alloc.reallocate__bool+0x4c>
    ec68:      	b	0xec80 <_coil.alloc.reallocate__bool+0x60>
    ec6c:      	cmp	x16, #0x0
    ec70:      	b.eq	0xec78 <_coil.alloc.reallocate__bool+0x58>
    ec74:      	b	0xec80 <_coil.alloc.reallocate__bool+0x60>
    ec78:      	b	0xec84 <_coil.alloc.reallocate__bool+0x64>
    ec7c:      	b	0xec94 <_coil.alloc.reallocate__bool+0x74>
    ec80:      	b	0xecbc <_coil.alloc.reallocate__bool+0x9c>
    ec84:      	movz	x0, #0x0, lsl #48
    ec88:      	movz	x1, #0x0, lsl #48
    ec8c:      	movz	x20, #0x0, lsl #48
    ec90:      	b	0xec98 <_coil.alloc.reallocate__bool+0x78>
    ec94:      	mov	x0, #0x1                ; =1
    ec98:      	str	x0, [x19]
    ec9c:      	str	x1, [x19, #0x8]
    eca0:      	str	x20, [x19, #0x10]
    eca4:      	ldr	x19, [sp, #0x30]
    eca8:      	ldr	x20, [sp, #0x38]
    ecac:      	ldr	x29, [sp, #0x10]
    ecb0:      	ldr	x30, [sp, #0x18]
    ecb4:      	add	sp, sp, #0x40
    ecb8:      	ret
    ecbc:      	brk	#0
    ecc0:      	b	0xecbc <_coil.alloc.reallocate__bool+0x9c>

000000000000ecc4 <_coil.alloc.reallocate__stogir.adjacency.Frame>:
    ecc4:      	sub	sp, sp, #0x40
    ecc8:      	str	x29, [sp, #0x10]
    eccc:      	str	x30, [sp, #0x18]
    ecd0:      	add	x29, sp, #0x10
    ecd4:      	str	x19, [sp, #0x30]
    ecd8:      	str	x20, [sp, #0x38]
    ecdc:      	mov	x19, x8
    ece0:      	mov	x20, x3
    ece4:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ece4:  ARM64_RELOC_PAGE21	l_stogir.548
    ece8:      	ldr	x4, [x4]
		000000000000ece8:  ARM64_RELOC_PAGEOFF12	l_stogir.548
    ecec:      	mov	x5, #0x10               ; =16
    ecf0:      	mov	x6, #0x8                ; =8
    ecf4:      	bl	0xecf4 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x30>
		000000000000ecf4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ecf8:      	ubfx	x0, x0, #0, #32
    ecfc:      	lsr	x16, x0, #0
    ed00:      	cmp	x16, #0x1
    ed04:      	b.eq	0xed20 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x5c>
    ed08:      	b.lo	0xed10 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x4c>
    ed0c:      	b	0xed24 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    ed10:      	cmp	x16, #0x0
    ed14:      	b.eq	0xed1c <_coil.alloc.reallocate__stogir.adjacency.Frame+0x58>
    ed18:      	b	0xed24 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    ed1c:      	b	0xed28 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x64>
    ed20:      	b	0xed38 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x74>
    ed24:      	b	0xed60 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>
    ed28:      	movz	x0, #0x0, lsl #48
    ed2c:      	movz	x1, #0x0, lsl #48
    ed30:      	movz	x20, #0x0, lsl #48
    ed34:      	b	0xed3c <_coil.alloc.reallocate__stogir.adjacency.Frame+0x78>
    ed38:      	mov	x0, #0x1                ; =1
    ed3c:      	str	x0, [x19]
    ed40:      	str	x1, [x19, #0x8]
    ed44:      	str	x20, [x19, #0x10]
    ed48:      	ldr	x19, [sp, #0x30]
    ed4c:      	ldr	x20, [sp, #0x38]
    ed50:      	ldr	x29, [sp, #0x10]
    ed54:      	ldr	x30, [sp, #0x18]
    ed58:      	add	sp, sp, #0x40
    ed5c:      	ret
    ed60:      	brk	#0
    ed64:      	b	0xed60 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>

000000000000ed68 <_coil.alloc.reallocate__i64>:
    ed68:      	sub	sp, sp, #0x40
    ed6c:      	str	x29, [sp, #0x10]
    ed70:      	str	x30, [sp, #0x18]
    ed74:      	add	x29, sp, #0x10
    ed78:      	str	x19, [sp, #0x30]
    ed7c:      	str	x20, [sp, #0x38]
    ed80:      	mov	x19, x8
    ed84:      	mov	x20, x3
    ed88:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ed88:  ARM64_RELOC_PAGE21	l_stogir.549
    ed8c:      	ldr	x4, [x4]
		000000000000ed8c:  ARM64_RELOC_PAGEOFF12	l_stogir.549
    ed90:      	mov	x5, #0x8                ; =8
    ed94:      	mov	x6, #0x8                ; =8
    ed98:      	bl	0xed98 <_coil.alloc.reallocate__i64+0x30>
		000000000000ed98:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ed9c:      	ubfx	x0, x0, #0, #32
    eda0:      	lsr	x16, x0, #0
    eda4:      	cmp	x16, #0x1
    eda8:      	b.eq	0xedc4 <_coil.alloc.reallocate__i64+0x5c>
    edac:      	b.lo	0xedb4 <_coil.alloc.reallocate__i64+0x4c>
    edb0:      	b	0xedc8 <_coil.alloc.reallocate__i64+0x60>
    edb4:      	cmp	x16, #0x0
    edb8:      	b.eq	0xedc0 <_coil.alloc.reallocate__i64+0x58>
    edbc:      	b	0xedc8 <_coil.alloc.reallocate__i64+0x60>
    edc0:      	b	0xedcc <_coil.alloc.reallocate__i64+0x64>
    edc4:      	b	0xeddc <_coil.alloc.reallocate__i64+0x74>
    edc8:      	b	0xee04 <_coil.alloc.reallocate__i64+0x9c>
    edcc:      	movz	x0, #0x0, lsl #48
    edd0:      	movz	x1, #0x0, lsl #48
    edd4:      	movz	x20, #0x0, lsl #48
    edd8:      	b	0xede0 <_coil.alloc.reallocate__i64+0x78>
    eddc:      	mov	x0, #0x1                ; =1
    ede0:      	str	x0, [x19]
    ede4:      	str	x1, [x19, #0x8]
    ede8:      	str	x20, [x19, #0x10]
    edec:      	ldr	x19, [sp, #0x30]
    edf0:      	ldr	x20, [sp, #0x38]
    edf4:      	ldr	x29, [sp, #0x10]
    edf8:      	ldr	x30, [sp, #0x18]
    edfc:      	add	sp, sp, #0x40
    ee00:      	ret
    ee04:      	brk	#0
    ee08:      	b	0xee04 <_coil.alloc.reallocate__i64+0x9c>

000000000000ee0c <_coil.alloc.reallocate__stogir.uses.Range>:
    ee0c:      	sub	sp, sp, #0x40
    ee10:      	str	x29, [sp, #0x10]
    ee14:      	str	x30, [sp, #0x18]
    ee18:      	add	x29, sp, #0x10
    ee1c:      	str	x19, [sp, #0x30]
    ee20:      	str	x20, [sp, #0x38]
    ee24:      	mov	x19, x8
    ee28:      	mov	x20, x3
    ee2c:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ee2c:  ARM64_RELOC_PAGE21	l_stogir.550
    ee30:      	ldr	x4, [x4]
		000000000000ee30:  ARM64_RELOC_PAGEOFF12	l_stogir.550
    ee34:      	mov	x5, #0x10               ; =16
    ee38:      	mov	x6, #0x8                ; =8
    ee3c:      	bl	0xee3c <_coil.alloc.reallocate__stogir.uses.Range+0x30>
		000000000000ee3c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ee40:      	ubfx	x0, x0, #0, #32
    ee44:      	lsr	x16, x0, #0
    ee48:      	cmp	x16, #0x1
    ee4c:      	b.eq	0xee68 <_coil.alloc.reallocate__stogir.uses.Range+0x5c>
    ee50:      	b.lo	0xee58 <_coil.alloc.reallocate__stogir.uses.Range+0x4c>
    ee54:      	b	0xee6c <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    ee58:      	cmp	x16, #0x0
    ee5c:      	b.eq	0xee64 <_coil.alloc.reallocate__stogir.uses.Range+0x58>
    ee60:      	b	0xee6c <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    ee64:      	b	0xee70 <_coil.alloc.reallocate__stogir.uses.Range+0x64>
    ee68:      	b	0xee80 <_coil.alloc.reallocate__stogir.uses.Range+0x74>
    ee6c:      	b	0xeea8 <_coil.alloc.reallocate__stogir.uses.Range+0x9c>
    ee70:      	movz	x0, #0x0, lsl #48
    ee74:      	movz	x1, #0x0, lsl #48
    ee78:      	movz	x20, #0x0, lsl #48
    ee7c:      	b	0xee84 <_coil.alloc.reallocate__stogir.uses.Range+0x78>
    ee80:      	mov	x0, #0x1                ; =1
    ee84:      	str	x0, [x19]
    ee88:      	str	x1, [x19, #0x8]
    ee8c:      	str	x20, [x19, #0x10]
    ee90:      	ldr	x19, [sp, #0x30]
    ee94:      	ldr	x20, [sp, #0x38]
    ee98:      	ldr	x29, [sp, #0x10]
    ee9c:      	ldr	x30, [sp, #0x18]
    eea0:      	add	sp, sp, #0x40
    eea4:      	ret
    eea8:      	brk	#0
    eeac:      	b	0xeea8 <_coil.alloc.reallocate__stogir.uses.Range+0x9c>

000000000000eeb0 <_coil.alloc.reallocate__stogir.uses.Use>:
    eeb0:      	sub	sp, sp, #0x40
    eeb4:      	str	x29, [sp, #0x10]
    eeb8:      	str	x30, [sp, #0x18]
    eebc:      	add	x29, sp, #0x10
    eec0:      	str	x19, [sp, #0x30]
    eec4:      	str	x20, [sp, #0x38]
    eec8:      	mov	x19, x8
    eecc:      	mov	x20, x3
    eed0:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000eed0:  ARM64_RELOC_PAGE21	l_stogir.551
    eed4:      	ldr	x4, [x4]
		000000000000eed4:  ARM64_RELOC_PAGEOFF12	l_stogir.551
    eed8:      	mov	x5, #0x8                ; =8
    eedc:      	mov	x6, #0x4                ; =4
    eee0:      	bl	0xeee0 <_coil.alloc.reallocate__stogir.uses.Use+0x30>
		000000000000eee0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    eee4:      	ubfx	x0, x0, #0, #32
    eee8:      	lsr	x16, x0, #0
    eeec:      	cmp	x16, #0x1
    eef0:      	b.eq	0xef0c <_coil.alloc.reallocate__stogir.uses.Use+0x5c>
    eef4:      	b.lo	0xeefc <_coil.alloc.reallocate__stogir.uses.Use+0x4c>
    eef8:      	b	0xef10 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    eefc:      	cmp	x16, #0x0
    ef00:      	b.eq	0xef08 <_coil.alloc.reallocate__stogir.uses.Use+0x58>
    ef04:      	b	0xef10 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    ef08:      	b	0xef14 <_coil.alloc.reallocate__stogir.uses.Use+0x64>
    ef0c:      	b	0xef24 <_coil.alloc.reallocate__stogir.uses.Use+0x74>
    ef10:      	b	0xef4c <_coil.alloc.reallocate__stogir.uses.Use+0x9c>
    ef14:      	movz	x0, #0x0, lsl #48
    ef18:      	movz	x1, #0x0, lsl #48
    ef1c:      	movz	x20, #0x0, lsl #48
    ef20:      	b	0xef28 <_coil.alloc.reallocate__stogir.uses.Use+0x78>
    ef24:      	mov	x0, #0x1                ; =1
    ef28:      	str	x0, [x19]
    ef2c:      	str	x1, [x19, #0x8]
    ef30:      	str	x20, [x19, #0x10]
    ef34:      	ldr	x19, [sp, #0x30]
    ef38:      	ldr	x20, [sp, #0x38]
    ef3c:      	ldr	x29, [sp, #0x10]
    ef40:      	ldr	x30, [sp, #0x18]
    ef44:      	add	sp, sp, #0x40
    ef48:      	ret
    ef4c:      	brk	#0
    ef50:      	b	0xef4c <_coil.alloc.reallocate__stogir.uses.Use+0x9c>

000000000000ef54 <_coil.alloc.reallocate__stogir.schedule.Range>:
    ef54:      	sub	sp, sp, #0x40
    ef58:      	str	x29, [sp, #0x10]
    ef5c:      	str	x30, [sp, #0x18]
    ef60:      	add	x29, sp, #0x10
    ef64:      	str	x19, [sp, #0x30]
    ef68:      	str	x20, [sp, #0x38]
    ef6c:      	mov	x19, x8
    ef70:      	mov	x20, x3
    ef74:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc4>
		000000000000ef74:  ARM64_RELOC_PAGE21	l_stogir.552
    ef78:      	ldr	x4, [x4]
		000000000000ef78:  ARM64_RELOC_PAGEOFF12	l_stogir.552
    ef7c:      	mov	x5, #0x10               ; =16
    ef80:      	mov	x6, #0x8                ; =8
    ef84:      	bl	0xef84 <_coil.alloc.reallocate__stogir.schedule.Range+0x30>
		000000000000ef84:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ef88:      	ubfx	x0, x0, #0, #32
    ef8c:      	lsr	x16, x0, #0
    ef90:      	cmp	x16, #0x1
    ef94:      	b.eq	0xefb0 <_coil.alloc.reallocate__stogir.schedule.Range+0x5c>
    ef98:      	b.lo	0xefa0 <_coil.alloc.reallocate__stogir.schedule.Range+0x4c>
    ef9c:      	b	0xefb4 <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    efa0:      	cmp	x16, #0x0
    efa4:      	b.eq	0xefac <_coil.alloc.reallocate__stogir.schedule.Range+0x58>
    efa8:      	b	0xefb4 <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    efac:      	b	0xefb8 <_coil.alloc.reallocate__stogir.schedule.Range+0x64>
    efb0:      	b	0xefc8 <_coil.alloc.reallocate__stogir.schedule.Range+0x74>
    efb4:      	b	0xeff0 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>
    efb8:      	movz	x0, #0x0, lsl #48
    efbc:      	movz	x1, #0x0, lsl #48
    efc0:      	movz	x20, #0x0, lsl #48
    efc4:      	b	0xefcc <_coil.alloc.reallocate__stogir.schedule.Range+0x78>
    efc8:      	mov	x0, #0x1                ; =1
    efcc:      	str	x0, [x19]
    efd0:      	str	x1, [x19, #0x8]
    efd4:      	str	x20, [x19, #0x10]
    efd8:      	ldr	x19, [sp, #0x30]
    efdc:      	ldr	x20, [sp, #0x38]
    efe0:      	ldr	x29, [sp, #0x10]
    efe4:      	ldr	x30, [sp, #0x18]
    efe8:      	add	sp, sp, #0x40
    efec:      	ret
    eff0:      	brk	#0
    eff4:      	b	0xeff0 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>

000000000000eff8 <_coil.alloc.sized-reallocate>:
    eff8:      	sub	sp, sp, #0x80
    effc:      	str	x29, [sp, #0x10]
    f000:      	str	x30, [sp, #0x18]
    f004:      	add	x29, sp, #0x10
    f008:      	str	x19, [sp, #0x40]
    f00c:      	str	x20, [sp, #0x48]
    f010:      	str	x21, [sp, #0x50]
    f014:      	str	x22, [sp, #0x58]
    f018:      	str	x23, [sp, #0x60]
    f01c:      	str	x24, [sp, #0x68]
    f020:      	str	x25, [sp, #0x70]
    f024:      	mov	x19, x0
    f028:      	mov	x20, x1
    f02c:      	mov	x21, x2
    f030:      	mov	x22, x3
    f034:      	mov	x23, x4
    f038:      	mov	x24, x5
    f03c:      	mov	x25, x6
    f040:      	movz	x7, #0x0, lsl #48
    f044:      	uxtb	w7, w7
    f048:      	bl	0xf048 <_coil.alloc.sized-reallocate+0x50>
		000000000000f048:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-resize
    f04c:      	ubfx	x0, x0, #0, #32
    f050:      	lsr	x16, x0, #0
    f054:      	cmp	x16, #0x1
    f058:      	b.eq	0xf074 <_coil.alloc.sized-reallocate+0x7c>
    f05c:      	b.lo	0xf064 <_coil.alloc.sized-reallocate+0x6c>
    f060:      	b	0xf078 <_coil.alloc.sized-reallocate+0x80>
    f064:      	cmp	x16, #0x0
    f068:      	b.eq	0xf070 <_coil.alloc.sized-reallocate+0x78>
    f06c:      	b	0xf078 <_coil.alloc.sized-reallocate+0x80>
    f070:      	b	0xf0b4 <_coil.alloc.sized-reallocate+0xbc>
    f074:      	b	0xf07c <_coil.alloc.sized-reallocate+0x84>
    f078:      	b	0xf150 <_coil.alloc.sized-reallocate+0x158>
    f07c:      	mov	x22, x1
    f080:      	mov	x0, #0x1                ; =1
    f084:      	mov	x1, x22
    f088:      	ldr	x19, [sp, #0x40]
    f08c:      	ldr	x20, [sp, #0x48]
    f090:      	ldr	x21, [sp, #0x50]
    f094:      	ldr	x22, [sp, #0x58]
    f098:      	ldr	x23, [sp, #0x60]
    f09c:      	ldr	x24, [sp, #0x68]
    f0a0:      	ldr	x25, [sp, #0x70]
    f0a4:      	ldr	x29, [sp, #0x10]
    f0a8:      	ldr	x30, [sp, #0x18]
    f0ac:      	add	sp, sp, #0x80
    f0b0:      	ret
    f0b4:      	mov	x0, x19
    f0b8:      	mov	x1, x23
    f0bc:      	mov	x2, x24
    f0c0:      	mov	x3, x25
    f0c4:      	mov	x4, x22
    f0c8:      	bl	0xf0c8 <_coil.alloc.sized-reallocate+0xd0>
		000000000000f0c8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    f0cc:      	ubfx	x0, x0, #0, #32
    f0d0:      	lsr	x16, x0, #0
    f0d4:      	cmp	x16, #0x1
    f0d8:      	b.eq	0xf0f4 <_coil.alloc.sized-reallocate+0xfc>
    f0dc:      	b.lo	0xf0e4 <_coil.alloc.sized-reallocate+0xec>
    f0e0:      	b	0xf0f8 <_coil.alloc.sized-reallocate+0x100>
    f0e4:      	cmp	x16, #0x0
    f0e8:      	b.eq	0xf0f0 <_coil.alloc.sized-reallocate+0xf8>
    f0ec:      	b	0xf0f8 <_coil.alloc.sized-reallocate+0x100>
    f0f0:      	b	0xf0fc <_coil.alloc.sized-reallocate+0x104>
    f0f4:      	b	0xf108 <_coil.alloc.sized-reallocate+0x110>
    f0f8:      	b	0xf158 <_coil.alloc.sized-reallocate+0x160>
    f0fc:      	movz	x0, #0x0, lsl #48
    f100:      	movz	x22, #0x0, lsl #48
    f104:      	b	0xf14c <_coil.alloc.sized-reallocate+0x154>
    f108:      	cmp	x21, x22
    f10c:      	b.ge	0xf114 <_coil.alloc.sized-reallocate+0x11c>
    f110:      	mov	x22, x21
    f114:      	orr	x0, x1, xzr
    f118:      	mul	x2, x24, x22
    f11c:      	lsr	x2, x2, #0
    f120:      	mov	x22, x1
    f124:      	mov	x1, x20
    f128:      	bl	0xf128 <_coil.alloc.sized-reallocate+0x130>
		000000000000f128:  ARM64_RELOC_BRANCH26	_memcpy
    f12c:      	mov	x0, x19
    f130:      	mov	x1, x20
    f134:      	mov	x2, x21
    f138:      	mov	x3, x23
    f13c:      	mov	x4, x24
    f140:      	mov	x5, x25
    f144:      	bl	0xf144 <_coil.alloc.sized-reallocate+0x14c>
		000000000000f144:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    f148:      	mov	x0, #0x1                ; =1
    f14c:      	b	0xf084 <_coil.alloc.sized-reallocate+0x8c>
    f150:      	brk	#0
    f154:      	b	0xf150 <_coil.alloc.sized-reallocate+0x158>
    f158:      	brk	#0
    f15c:      	b	0xf158 <_coil.alloc.sized-reallocate+0x160>

000000000000f160 <_coil.alloc.reallocate__stogir.adjacency.Range>:
    f160:      	sub	sp, sp, #0x40
    f164:      	str	x29, [sp, #0x10]
    f168:      	str	x30, [sp, #0x18]
    f16c:      	add	x29, sp, #0x10
    f170:      	str	x19, [sp, #0x30]
    f174:      	str	x20, [sp, #0x38]
    f178:      	mov	x19, x8
    f17c:      	mov	x20, x3
    f180:      	adrp	x4, 0xf000 <_coil.alloc.sized-reallocate+0x8>
		000000000000f180:  ARM64_RELOC_PAGE21	l_stogir.553
    f184:      	ldr	x4, [x4]
		000000000000f184:  ARM64_RELOC_PAGEOFF12	l_stogir.553
    f188:      	mov	x5, #0x10               ; =16
    f18c:      	mov	x6, #0x8                ; =8
    f190:      	bl	0xf190 <_coil.alloc.reallocate__stogir.adjacency.Range+0x30>
		000000000000f190:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f194:      	ubfx	x0, x0, #0, #32
    f198:      	lsr	x16, x0, #0
    f19c:      	cmp	x16, #0x1
    f1a0:      	b.eq	0xf1bc <_coil.alloc.reallocate__stogir.adjacency.Range+0x5c>
    f1a4:      	b.lo	0xf1ac <_coil.alloc.reallocate__stogir.adjacency.Range+0x4c>
    f1a8:      	b	0xf1c0 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    f1ac:      	cmp	x16, #0x0
    f1b0:      	b.eq	0xf1b8 <_coil.alloc.reallocate__stogir.adjacency.Range+0x58>
    f1b4:      	b	0xf1c0 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    f1b8:      	b	0xf1c4 <_coil.alloc.reallocate__stogir.adjacency.Range+0x64>
    f1bc:      	b	0xf1d4 <_coil.alloc.reallocate__stogir.adjacency.Range+0x74>
    f1c0:      	b	0xf1fc <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>
    f1c4:      	movz	x0, #0x0, lsl #48
    f1c8:      	movz	x1, #0x0, lsl #48
    f1cc:      	movz	x20, #0x0, lsl #48
    f1d0:      	b	0xf1d8 <_coil.alloc.reallocate__stogir.adjacency.Range+0x78>
    f1d4:      	mov	x0, #0x1                ; =1
    f1d8:      	str	x0, [x19]
    f1dc:      	str	x1, [x19, #0x8]
    f1e0:      	str	x20, [x19, #0x10]
    f1e4:      	ldr	x19, [sp, #0x30]
    f1e8:      	ldr	x20, [sp, #0x38]
    f1ec:      	ldr	x29, [sp, #0x10]
    f1f0:      	ldr	x30, [sp, #0x18]
    f1f4:      	add	sp, sp, #0x40
    f1f8:      	ret
    f1fc:      	brk	#0
    f200:      	b	0xf1fc <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>

000000000000f204 <_coil.alloc.sized-resize>:
    f204:      	sub	sp, sp, #0x120
    f208:      	str	x29, [sp, #0x10]
    f20c:      	str	x30, [sp, #0x18]
    f210:      	add	x29, sp, #0x10
    f214:      	str	x19, [sp, #0xe0]
    f218:      	str	x20, [sp, #0xe8]
    f21c:      	str	x21, [sp, #0xf0]
    f220:      	str	x22, [sp, #0xf8]
    f224:      	str	x23, [sp, #0x100]
    f228:      	str	x24, [sp, #0x108]
    f22c:      	str	x25, [sp, #0x110]
    f230:      	cmp	x3, #0x0
    f234:      	b.ne	0xf27c <_coil.alloc.sized-resize+0x78>
    f238:      	mov	x3, x4
    f23c:      	mov	x4, x5
    f240:      	mov	x5, x6
    f244:      	bl	0xf244 <_coil.alloc.sized-resize+0x40>
		000000000000f244:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    f248:      	mov	x0, #0x1                ; =1
    f24c:      	movz	x1, #0x0, lsl #48
    f250:      	ldr	x19, [sp, #0xe0]
    f254:      	ldr	x20, [sp, #0xe8]
    f258:      	ldr	x21, [sp, #0xf0]
    f25c:      	ldr	x22, [sp, #0xf8]
    f260:      	ldr	x23, [sp, #0x100]
    f264:      	ldr	x24, [sp, #0x108]
    f268:      	ldr	x25, [sp, #0x110]
    f26c:      	ldr	x29, [sp, #0x10]
    f270:      	ldr	x30, [sp, #0x18]
    f274:      	add	sp, sp, #0x120
    f278:      	ret
    f27c:      	cmp	x2, #0x0
    f280:      	b.ne	0xf29c <_coil.alloc.sized-resize+0x98>
    f284:      	mov	x1, x4
    f288:      	mov	x2, x5
    f28c:      	mov	x4, x3
    f290:      	mov	x3, x6
    f294:      	bl	0xf294 <_coil.alloc.sized-resize+0x90>
		000000000000f294:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    f298:      	b	0xf250 <_coil.alloc.sized-resize+0x4c>
    f29c:      	add	x8, sp, #0x20
    f2a0:      	mov	x19, x0
    f2a4:      	mov	x0, x4
    f2a8:      	mov	x20, x1
    f2ac:      	mov	x1, x5
    f2b0:      	mov	x21, x3
    f2b4:      	mov	x3, x2
    f2b8:      	mov	x2, x6
    f2bc:      	mov	x22, x4
    f2c0:      	mov	x23, x5
    f2c4:      	mov	x24, x6
    f2c8:      	mov	w25, w7
    f2cc:      	bl	0xf2cc <_coil.alloc.sized-resize+0xc8>
		000000000000f2cc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f2d0:      	add	x16, sp, #0x20
    f2d4:      	ldr	w0, [x16]
    f2d8:      	lsr	x16, x0, #0
    f2dc:      	cmp	x16, #0x1
    f2e0:      	b.eq	0xf2fc <_coil.alloc.sized-resize+0xf8>
    f2e4:      	b.lo	0xf2ec <_coil.alloc.sized-resize+0xe8>
    f2e8:      	b	0xf300 <_coil.alloc.sized-resize+0xfc>
    f2ec:      	cmp	x16, #0x0
    f2f0:      	b.eq	0xf2f8 <_coil.alloc.sized-resize+0xf4>
    f2f4:      	b	0xf300 <_coil.alloc.sized-resize+0xfc>
    f2f8:      	b	0xf304 <_coil.alloc.sized-resize+0x100>
    f2fc:      	b	0xf310 <_coil.alloc.sized-resize+0x10c>
    f300:      	b	0xf440 <_coil.alloc.sized-resize+0x23c>
    f304:      	movz	x0, #0x0, lsl #48
    f308:      	movz	x1, #0x0, lsl #48
    f30c:      	b	0xf298 <_coil.alloc.sized-resize+0x94>
    f310:      	add	x16, sp, #0x20
    f314:      	orr	x0, x16, xzr
    f318:      	add	x0, x0, #0x8
    f31c:      	add	x16, sp, #0x20
    f320:      	ldr	x1, [x16, #0x8]
    f324:      	add	x16, sp, #0x50
    f328:      	str	x1, [x16]
    f32c:      	ldr	x1, [x0, #0x8]
    f330:      	add	x16, sp, #0x50
    f334:      	str	x1, [x16, #0x8]
    f338:      	ldr	x1, [x0, #0x10]
    f33c:      	add	x16, sp, #0x50
    f340:      	str	x1, [x16, #0x10]
    f344:      	ldr	x0, [x0, #0x18]
    f348:      	add	x16, sp, #0x50
    f34c:      	str	x0, [x16, #0x18]
    f350:      	add	x8, sp, #0x70
    f354:      	mov	x0, x22
    f358:      	mov	x1, x23
    f35c:      	mov	x2, x24
    f360:      	mov	x3, x21
    f364:      	bl	0xf364 <_coil.alloc.sized-resize+0x160>
		000000000000f364:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f368:      	add	x16, sp, #0x70
    f36c:      	ldr	w0, [x16]
    f370:      	lsr	x16, x0, #0
    f374:      	cmp	x16, #0x1
    f378:      	b.eq	0xf394 <_coil.alloc.sized-resize+0x190>
    f37c:      	b.lo	0xf384 <_coil.alloc.sized-resize+0x180>
    f380:      	b	0xf398 <_coil.alloc.sized-resize+0x194>
    f384:      	cmp	x16, #0x0
    f388:      	b.eq	0xf390 <_coil.alloc.sized-resize+0x18c>
    f38c:      	b	0xf398 <_coil.alloc.sized-resize+0x194>
    f390:      	b	0xf39c <_coil.alloc.sized-resize+0x198>
    f394:      	b	0xf3b4 <_coil.alloc.sized-resize+0x1b0>
    f398:      	b	0xf448 <_coil.alloc.sized-resize+0x244>
    f39c:      	movz	x0, #0x0, lsl #48
    f3a0:      	movz	x1, #0x0, lsl #48
    f3a4:      	b	0xf3b0 <_coil.alloc.sized-resize+0x1ac>
    f3a8:      	movz	x0, #0x0, lsl #48
    f3ac:      	movz	x1, #0x0, lsl #48
    f3b0:      	b	0xf30c <_coil.alloc.sized-resize+0x108>
    f3b4:      	ubfx	x25, x25, #0, #8
    f3b8:      	add	x16, sp, #0x70
    f3bc:      	orr	x0, x16, xzr
    f3c0:      	add	x0, x0, #0x8
    f3c4:      	add	x16, sp, #0x70
    f3c8:      	ldr	x1, [x16, #0x8]
    f3cc:      	add	x16, sp, #0xa0
    f3d0:      	str	x1, [x16]
    f3d4:      	ldr	x1, [x0, #0x8]
    f3d8:      	add	x16, sp, #0xa0
    f3dc:      	str	x1, [x16, #0x8]
    f3e0:      	ldr	x1, [x0, #0x10]
    f3e4:      	add	x16, sp, #0xa0
    f3e8:      	str	x1, [x16, #0x10]
    f3ec:      	ldr	x0, [x0, #0x18]
    f3f0:      	add	x16, sp, #0xa0
    f3f4:      	str	x0, [x16, #0x18]
    f3f8:      	cmp	x25, #0x0
    f3fc:      	b.eq	0xf428 <_coil.alloc.sized-resize+0x224>
    f400:      	mov	x0, x19
    f404:      	mov	x1, x20
    f408:      	add	x2, sp, #0x50
    f40c:      	add	x3, sp, #0xa0
    f410:      	bl	0xf410 <_coil.alloc.sized-resize+0x20c>
		000000000000f410:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-resize
    f414:      	cmp	x0, #0x0
    f418:      	b.eq	0xf3a8 <_coil.alloc.sized-resize+0x1a4>
    f41c:      	orr	x1, x20, xzr
    f420:      	mov	x0, #0x1                ; =1
    f424:      	b	0xf3b0 <_coil.alloc.sized-resize+0x1ac>
    f428:      	mov	x0, x19
    f42c:      	mov	x1, x20
    f430:      	add	x2, sp, #0x50
    f434:      	add	x3, sp, #0xa0
    f438:      	bl	0xf438 <_coil.alloc.sized-resize+0x234>
		000000000000f438:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-remap
    f43c:      	b	0xf3b0 <_coil.alloc.sized-resize+0x1ac>
    f440:      	brk	#0
    f444:      	b	0xf440 <_coil.alloc.sized-resize+0x23c>
    f448:      	brk	#0
    f44c:      	b	0xf448 <_coil.alloc.sized-resize+0x244>

000000000000f450 <_coil.alloc.sized-alloc>:
    f450:      	sub	sp, sp, #0x90
    f454:      	str	x29, [sp, #0x10]
    f458:      	str	x30, [sp, #0x18]
    f45c:      	add	x29, sp, #0x10
    f460:      	str	x19, [sp, #0x80]
    f464:      	cmp	x4, #0x0
    f468:      	b.ne	0xf488 <_coil.alloc.sized-alloc+0x38>
    f46c:      	mov	x0, #0x1                ; =1
    f470:      	movz	x1, #0x0, lsl #48
    f474:      	ldr	x19, [sp, #0x80]
    f478:      	ldr	x29, [sp, #0x10]
    f47c:      	ldr	x30, [sp, #0x18]
    f480:      	add	sp, sp, #0x90
    f484:      	ret
    f488:      	add	x8, sp, #0x20
    f48c:      	mov	x19, x0
    f490:      	mov	x0, x1
    f494:      	mov	x1, x2
    f498:      	mov	x2, x3
    f49c:      	mov	x3, x4
    f4a0:      	bl	0xf4a0 <_coil.alloc.sized-alloc+0x50>
		000000000000f4a0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f4a4:      	add	x16, sp, #0x20
    f4a8:      	ldr	w0, [x16]
    f4ac:      	lsr	x16, x0, #0
    f4b0:      	cmp	x16, #0x1
    f4b4:      	b.eq	0xf4d0 <_coil.alloc.sized-alloc+0x80>
    f4b8:      	b.lo	0xf4c0 <_coil.alloc.sized-alloc+0x70>
    f4bc:      	b	0xf4d4 <_coil.alloc.sized-alloc+0x84>
    f4c0:      	cmp	x16, #0x0
    f4c4:      	b.eq	0xf4cc <_coil.alloc.sized-alloc+0x7c>
    f4c8:      	b	0xf4d4 <_coil.alloc.sized-alloc+0x84>
    f4cc:      	b	0xf4d8 <_coil.alloc.sized-alloc+0x88>
    f4d0:      	b	0xf4e4 <_coil.alloc.sized-alloc+0x94>
    f4d4:      	b	0xf534 <_coil.alloc.sized-alloc+0xe4>
    f4d8:      	movz	x0, #0x0, lsl #48
    f4dc:      	movz	x1, #0x0, lsl #48
    f4e0:      	b	0xf530 <_coil.alloc.sized-alloc+0xe0>
    f4e4:      	add	x16, sp, #0x20
    f4e8:      	orr	x0, x16, xzr
    f4ec:      	add	x0, x0, #0x8
    f4f0:      	add	x16, sp, #0x20
    f4f4:      	ldr	x1, [x16, #0x8]
    f4f8:      	add	x16, sp, #0x50
    f4fc:      	str	x1, [x16]
    f500:      	ldr	x1, [x0, #0x8]
    f504:      	add	x16, sp, #0x50
    f508:      	str	x1, [x16, #0x8]
    f50c:      	ldr	x1, [x0, #0x10]
    f510:      	add	x16, sp, #0x50
    f514:      	str	x1, [x16, #0x10]
    f518:      	ldr	x0, [x0, #0x18]
    f51c:      	add	x16, sp, #0x50
    f520:      	str	x0, [x16, #0x18]
    f524:      	mov	x0, x19
    f528:      	add	x1, sp, #0x50
    f52c:      	bl	0xf52c <_coil.alloc.sized-alloc+0xdc>
		000000000000f52c:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-alloc
    f530:      	b	0xf474 <_coil.alloc.sized-alloc+0x24>
    f534:      	brk	#0
    f538:      	b	0xf534 <_coil.alloc.sized-alloc+0xe4>

000000000000f53c <_coil.alloc.raw-resize>:
    f53c:      	sub	sp, sp, #0x10
    f540:      	str	x29, [sp]
    f544:      	str	x30, [sp, #0x8]
    f548:      	mov	x29, sp
    f54c:      	ldr	x4, [x2, #0x8]
    f550:      	cmp	x4, #0x0
    f554:      	b.le	0xf5d0 <_coil.alloc.raw-resize+0x94>
    f558:      	ldr	x4, [x2, #0x10]
    f55c:      	cmp	x4, #0x0
    f560:      	b.le	0xf5d0 <_coil.alloc.raw-resize+0x94>
    f564:      	ldr	x4, [x2, #0x18]
    f568:      	cmp	x4, #0x0
    f56c:      	b.le	0xf5d0 <_coil.alloc.raw-resize+0x94>
    f570:      	sub	x5, x4, #0x1
    f574:      	and	x4, x5, x4
    f578:      	cmp	x4, #0x0
    f57c:      	b.ne	0xf5d0 <_coil.alloc.raw-resize+0x94>
    f580:      	ldr	x4, [x3, #0x8]
    f584:      	cmp	x4, #0x0
    f588:      	b.le	0xf5d0 <_coil.alloc.raw-resize+0x94>
    f58c:      	ldr	x4, [x3, #0x10]
    f590:      	cmp	x4, #0x0
    f594:      	b.le	0xf5d0 <_coil.alloc.raw-resize+0x94>
    f598:      	ldr	x4, [x3, #0x18]
    f59c:      	cmp	x4, #0x0
    f5a0:      	b.le	0xf5d0 <_coil.alloc.raw-resize+0x94>
    f5a4:      	sub	x5, x4, #0x1
    f5a8:      	and	x4, x5, x4
    f5ac:      	cmp	x4, #0x0
    f5b0:      	b.ne	0xf5d0 <_coil.alloc.raw-resize+0x94>
    f5b4:      	ldr	x4, [x0]
    f5b8:      	ldr	x0, [x0, #0x8]
    f5bc:      	ldr	x0, [x0, #0x8]
    f5c0:      	mov	x30, x0
    f5c4:      	mov	x0, x4
    f5c8:      	blr	x30
    f5cc:      	b	0xf5d4 <_coil.alloc.raw-resize+0x98>
    f5d0:      	movz	x0, #0x0, lsl #48
    f5d4:      	ldr	x29, [sp]
    f5d8:      	ldr	x30, [sp, #0x8]
    f5dc:      	add	sp, sp, #0x10
    f5e0:      	ret

000000000000f5e4 <_coil.alloc.raw-remap>:
    f5e4:      	sub	sp, sp, #0x30
    f5e8:      	str	x29, [sp, #0x10]
    f5ec:      	str	x30, [sp, #0x18]
    f5f0:      	add	x29, sp, #0x10
    f5f4:      	ldr	x4, [x2, #0x8]
    f5f8:      	cmp	x4, #0x0
    f5fc:      	b.le	0xf678 <_coil.alloc.raw-remap+0x94>
    f600:      	ldr	x4, [x2, #0x10]
    f604:      	cmp	x4, #0x0
    f608:      	b.le	0xf678 <_coil.alloc.raw-remap+0x94>
    f60c:      	ldr	x4, [x2, #0x18]
    f610:      	cmp	x4, #0x0
    f614:      	b.le	0xf678 <_coil.alloc.raw-remap+0x94>
    f618:      	sub	x5, x4, #0x1
    f61c:      	and	x4, x5, x4
    f620:      	cmp	x4, #0x0
    f624:      	b.ne	0xf678 <_coil.alloc.raw-remap+0x94>
    f628:      	ldr	x4, [x3, #0x8]
    f62c:      	cmp	x4, #0x0
    f630:      	b.le	0xf678 <_coil.alloc.raw-remap+0x94>
    f634:      	ldr	x4, [x3, #0x10]
    f638:      	cmp	x4, #0x0
    f63c:      	b.le	0xf678 <_coil.alloc.raw-remap+0x94>
    f640:      	ldr	x4, [x3, #0x18]
    f644:      	cmp	x4, #0x0
    f648:      	b.le	0xf678 <_coil.alloc.raw-remap+0x94>
    f64c:      	sub	x5, x4, #0x1
    f650:      	and	x4, x5, x4
    f654:      	cmp	x4, #0x0
    f658:      	b.ne	0xf678 <_coil.alloc.raw-remap+0x94>
    f65c:      	ldr	x4, [x0]
    f660:      	ldr	x0, [x0, #0x8]
    f664:      	ldr	x0, [x0, #0x10]
    f668:      	mov	x30, x0
    f66c:      	mov	x0, x4
    f670:      	blr	x30
    f674:      	b	0xf680 <_coil.alloc.raw-remap+0x9c>
    f678:      	movz	x0, #0x0, lsl #48
    f67c:      	movz	x1, #0x0, lsl #48
    f680:      	ldr	x29, [sp, #0x10]
    f684:      	ldr	x30, [sp, #0x18]
    f688:      	add	sp, sp, #0x30
    f68c:      	ret

000000000000f690 <_coil.alloc.raw-alloc>:
    f690:      	sub	sp, sp, #0x30
    f694:      	str	x29, [sp, #0x10]
    f698:      	str	x30, [sp, #0x18]
    f69c:      	add	x29, sp, #0x10
    f6a0:      	ldr	x2, [x1, #0x8]
    f6a4:      	cmp	x2, #0x0
    f6a8:      	b.le	0xf6f0 <_coil.alloc.raw-alloc+0x60>
    f6ac:      	ldr	x2, [x1, #0x10]
    f6b0:      	cmp	x2, #0x0
    f6b4:      	b.le	0xf6f0 <_coil.alloc.raw-alloc+0x60>
    f6b8:      	ldr	x2, [x1, #0x18]
    f6bc:      	cmp	x2, #0x0
    f6c0:      	b.le	0xf6f0 <_coil.alloc.raw-alloc+0x60>
    f6c4:      	sub	x3, x2, #0x1
    f6c8:      	and	x2, x3, x2
    f6cc:      	cmp	x2, #0x0
    f6d0:      	b.ne	0xf6f0 <_coil.alloc.raw-alloc+0x60>
    f6d4:      	ldr	x2, [x0]
    f6d8:      	ldr	x0, [x0, #0x8]
    f6dc:      	ldr	x0, [x0]
    f6e0:      	mov	x30, x0
    f6e4:      	mov	x0, x2
    f6e8:      	blr	x30
    f6ec:      	b	0xf6f8 <_coil.alloc.raw-alloc+0x68>
    f6f0:      	movz	x0, #0x0, lsl #48
    f6f4:      	movz	x1, #0x0, lsl #48
    f6f8:      	ldr	x29, [sp, #0x10]
    f6fc:      	ldr	x30, [sp, #0x18]
    f700:      	add	sp, sp, #0x30
    f704:      	ret
