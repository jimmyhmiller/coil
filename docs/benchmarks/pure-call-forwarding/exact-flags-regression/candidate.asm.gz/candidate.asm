
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-pure-call-forwarding/build/pure-verifier/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	str	x20, [sp, #0x1d8]
      18:      	add	x8, sp, #0x10
      1c:      	mov	x19, x0
      20:      	mov	x1, #0x8                ; =8
      24:      	bl	0x24 <_gap_verify_graph+0x24>
		0000000000000024:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      28:      	add	x16, sp, #0x10
      2c:      	ldr	w0, [x16]
      30:      	lsr	x16, x0, #0
      34:      	cmp	x16, #0x1
      38:      	b.eq	0x54 <_gap_verify_graph+0x54>
      3c:      	b.lo	0x44 <_gap_verify_graph+0x44>
      40:      	b	0x58 <_gap_verify_graph+0x58>
      44:      	cmp	x16, #0x0
      48:      	b.eq	0x50 <_gap_verify_graph+0x50>
      4c:      	b	0x58 <_gap_verify_graph+0x58>
      50:      	b	0x64 <_gap_verify_graph+0x64>
      54:      	b	0x5c <_gap_verify_graph+0x5c>
      58:      	b	0x9c <_gap_verify_graph+0x9c>
      5c:      	movn	x0, #0x0, lsl #48
      60:      	b	0x84 <_gap_verify_graph+0x84>
      64:      	add	x16, sp, #0x30
      68:      	orr	x20, x16, xzr
      6c:      	add	x0, sp, #0x30
      70:      	mov	x1, x19
      74:      	mov	x2, #0x1a0              ; =416
      78:      	bl	0x78 <_gap_verify_graph+0x78>
		0000000000000078:  ARM64_RELOC_BRANCH26	_memmove
      7c:      	mov	x0, x20
      80:      	bl	0x80 <_gap_verify_graph+0x80>
		0000000000000080:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
      84:      	ldr	x19, [sp, #0x1d0]
      88:      	ldr	x20, [sp, #0x1d8]
      8c:      	ldr	x29, [sp]
      90:      	ldr	x30, [sp, #0x8]
      94:      	add	sp, sp, #0x1e0
      98:      	ret
      9c:      	brk	#0
      a0:      	b	0x9c <_gap_verify_graph+0x9c>

00000000000000a4 <_stogir.verify.integer-operations-target>:
      a4:      	sub	sp, sp, #0x70
      a8:      	str	x29, [sp]
      ac:      	str	x30, [sp, #0x8]
      b0:      	mov	x29, sp
      b4:      	str	x19, [sp, #0x50]
      b8:      	str	x20, [sp, #0x58]
      bc:      	str	x21, [sp, #0x60]
      c0:      	mov	x19, x8
      c4:      	add	x8, sp, #0x10
      c8:      	mov	x20, x0
      cc:      	mov	w21, w1
      d0:      	bl	0xd0 <_stogir.verify.integer-operations-target+0x2c>
		00000000000000d0:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      d4:      	add	x16, sp, #0x10
      d8:      	ldr	w0, [x16]
      dc:      	lsr	x16, x0, #0
      e0:      	cmp	x16, #0x1
      e4:      	b.eq	0x100 <_stogir.verify.integer-operations-target+0x5c>
      e8:      	b.lo	0xf0 <_stogir.verify.integer-operations-target+0x4c>
      ec:      	b	0x104 <_stogir.verify.integer-operations-target+0x60>
      f0:      	cmp	x16, #0x0
      f4:      	b.eq	0xfc <_stogir.verify.integer-operations-target+0x58>
      f8:      	b	0x104 <_stogir.verify.integer-operations-target+0x60>
      fc:      	b	0x128 <_stogir.verify.integer-operations-target+0x84>
     100:      	b	0x108 <_stogir.verify.integer-operations-target+0x64>
     104:      	b	0x178 <_stogir.verify.integer-operations-target+0xd4>
     108:      	add	x16, sp, #0x10
     10c:      	orr	x0, x16, xzr
     110:      	add	x0, x0, #0x8
     114:      	add	x16, sp, #0x10
     118:      	ldr	x1, [x16, #0x8]
     11c:      	ldr	x0, [x0, #0x8]
     120:      	mov	x2, #0x1                ; =1
     124:      	b	0x150 <_stogir.verify.integer-operations-target+0xac>
     128:      	add	x8, sp, #0x30
     12c:      	mov	x0, x20
     130:      	mov	w1, w21
     134:      	bl	0x134 <_stogir.verify.integer-operations-target+0x90>
		0000000000000134:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     138:      	add	x16, sp, #0x30
     13c:      	ldr	x2, [x16]
     140:      	add	x16, sp, #0x30
     144:      	ldr	x1, [x16, #0x8]
     148:      	add	x16, sp, #0x30
     14c:      	ldr	x0, [x16, #0x10]
     150:      	str	x2, [x19]
     154:      	str	x1, [x19, #0x8]
     158:      	str	x0, [x19, #0x10]
     15c:      	ldr	x19, [sp, #0x50]
     160:      	ldr	x20, [sp, #0x58]
     164:      	ldr	x21, [sp, #0x60]
     168:      	ldr	x29, [sp]
     16c:      	ldr	x30, [sp, #0x8]
     170:      	add	sp, sp, #0x70
     174:      	ret
     178:      	brk	#0
     17c:      	b	0x178 <_stogir.verify.integer-operations-target+0xd4>

0000000000000180 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     180:      	ldr	x0, [x0, #0x8]
     184:      	ret

0000000000000188 <_stogir.verify.structure>:
     188:      	sub	sp, sp, #0x170
     18c:      	str	x29, [sp]
     190:      	str	x30, [sp, #0x8]
     194:      	mov	x29, sp
     198:      	str	x19, [sp, #0x118]
     19c:      	str	x20, [sp, #0x120]
     1a0:      	str	x21, [sp, #0x128]
     1a4:      	str	x22, [sp, #0x130]
     1a8:      	str	x23, [sp, #0x138]
     1ac:      	str	x24, [sp, #0x140]
     1b0:      	str	x25, [sp, #0x148]
     1b4:      	str	x26, [sp, #0x150]
     1b8:      	str	x27, [sp, #0x158]
     1bc:      	str	x28, [sp, #0x160]
     1c0:      	add	x19, x0, #0x78
     1c4:      	mov	x20, x8
     1c8:      	mov	x21, x0
     1cc:      	bl	0x1cc <_stogir.verify.structure+0x44>
		00000000000001cc:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
     1d0:      	fmov	d31, x0
     1d4:      	mov	x0, x19
     1d8:      	fmov	x19, d31
     1dc:      	bl	0x1dc <_stogir.verify.structure+0x54>
		00000000000001dc:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
     1e0:      	cmp	x19, x0
     1e4:      	b.ne	0x218 <_stogir.verify.structure+0x90>
     1e8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001e8:  ARM64_RELOC_PAGE21	l_stogir.311
     1ec:      	ldr	x16, [x16]
		00000000000001ec:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     1f0:      	orr	x19, x16, xzr
     1f4:      	movz	x22, #0x0, lsl #48
     1f8:      	b	0x228 <_stogir.verify.structure+0xa0>
     1fc:      	ldr	x0, [sp, #0xc8]
     200:      	ldr	x1, [sp, #0xd0]
     204:      	add	x0, x1, x0
     208:      	ldr	x1, [sp, #0x88]
     20c:      	add	x1, x1, #0x1
     210:      	sxtw	x1, w1
     214:      	b	0x2f4 <_stogir.verify.structure+0x16c>
     218:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000218:  ARM64_RELOC_PAGE21	l_stogir.312
     21c:      	ldr	x16, [x16]
		000000000000021c:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     220:      	orr	x19, x16, xzr
     224:      	mov	x22, #0x2c              ; =44
     228:      	add	x16, sp, #0x10
     22c:      	orr	x23, x16, xzr
     230:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000230:  ARM64_RELOC_PAGE21	l_stogir.313
     234:      	ldr	x16, [x16]
		0000000000000234:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     238:      	orr	x24, x16, xzr
     23c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000023c:  ARM64_RELOC_PAGE21	l_stogir.314
     240:      	ldr	x16, [x16]
		0000000000000240:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     244:      	orr	x25, x16, xzr
     248:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000248:  ARM64_RELOC_PAGE21	l_stogir.315
     24c:      	ldr	x16, [x16]
		000000000000024c:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     250:      	orr	x26, x16, xzr
     254:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000254:  ARM64_RELOC_PAGE21	l_stogir.316
     258:      	ldr	x16, [x16]
		0000000000000258:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     25c:      	orr	x27, x16, xzr
     260:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000260:  ARM64_RELOC_PAGE21	l_stogir.317
     264:      	ldr	x16, [x16]
		0000000000000264:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     268:      	orr	x28, x16, xzr
     26c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000026c:  ARM64_RELOC_PAGE21	l_stogir.318
     270:      	ldr	x16, [x16]
		0000000000000270:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     274:      	orr	x0, x16, xzr
     278:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000278:  ARM64_RELOC_PAGE21	l_stogir.319
     27c:      	ldr	x16, [x16]
		000000000000027c:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     280:      	orr	x1, x16, xzr
     284:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000284:  ARM64_RELOC_PAGE21	l_stogir.320
     288:      	ldr	x16, [x16]
		0000000000000288:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     28c:      	orr	x2, x16, xzr
     290:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000290:  ARM64_RELOC_PAGE21	l_stogir.321
     294:      	ldr	x16, [x16]
		0000000000000294:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     298:      	orr	x3, x16, xzr
     29c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000029c:  ARM64_RELOC_PAGE21	l_stogir.322
     2a0:      	ldr	x16, [x16]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     2a4:      	orr	x4, x16, xzr
     2a8:      	add	x5, x21, #0x110
     2ac:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002ac:  ARM64_RELOC_PAGE21	l_stogir.323
     2b0:      	ldr	x16, [x16]
		00000000000002b0:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     2b4:      	orr	x6, x16, xzr
     2b8:      	add	x7, x21, #0x78
     2bc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002bc:  ARM64_RELOC_PAGE21	l_stogir.324
     2c0:      	ldr	x16, [x16]
		00000000000002c0:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     2c4:      	orr	x8, x16, xzr
     2c8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002c8:  ARM64_RELOC_PAGE21	l_stogir.324
     2cc:      	ldr	x16, [x16]
		00000000000002cc:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     2d0:      	orr	x9, x16, xzr
     2d4:      	add	x10, x5, #0x28
     2d8:      	mov	x11, #0x1               ; =1
     2dc:      	movz	x12, #0x0, lsl #48
     2e0:      	b	0x384 <_stogir.verify.structure+0x1fc>
     2e4:      	ldr	x17, [sp, #0x58]
     2e8:      	str	x17, [sp, #0x80]
     2ec:      	mov	x16, #0x16              ; =22
     2f0:      	str	x16, [sp, #0xc0]
     2f4:      	b	0x328 <_stogir.verify.structure+0x1a0>
     2f8:      	mov	x0, x20
     2fc:      	mov	x1, x19
     300:      	str	x21, [sp, #0xe0]
     304:      	str	x24, [sp, #0xb8]
     308:      	mov	x24, x23
     30c:      	str	x25, [sp, #0x100]
     310:      	str	x26, [sp, #0xa0]
     314:      	str	x27, [sp, #0xa8]
     318:      	ldr	x17, [sp, #0x50]
     31c:      	str	x17, [sp, #0x80]
     320:      	mov	x16, #0x23              ; =35
     324:      	str	x16, [sp, #0xc0]
     328:      	ldr	x20, [sp, #0x78]
     32c:      	ldr	x21, [sp, #0xe0]
     330:      	ldr	x23, [sp, #0x48]
     334:      	ldr	x25, [sp, #0x58]
     338:      	ldr	x26, [sp, #0x60]
     33c:      	ldr	x27, [sp, #0x68]
     340:      	ldr	x2, [sp, #0x30]
     344:      	ldr	x3, [sp, #0x38]
     348:      	ldr	x4, [sp, #0x40]
     34c:      	mov	x5, x24
     350:      	ldr	x24, [sp, #0x50]
     354:      	mov	x10, x28
     358:      	ldr	x28, [sp, #0x70]
     35c:      	ldr	x6, [sp, #0xb8]
     360:      	ldr	x7, [sp, #0x100]
     364:      	ldr	x8, [sp, #0xa0]
     368:      	ldr	x9, [sp, #0xa8]
     36c:      	mov	x11, x0
     370:      	ldr	x0, [sp, #0x20]
     374:      	mov	x12, x1
     378:      	ldr	x1, [sp, #0x28]
     37c:      	ldr	x19, [sp, #0x80]
     380:      	ldr	x22, [sp, #0xc0]
     384:      	cmp	x22, #0x0
     388:      	b.ne	0xb34 <_stogir.verify.structure+0x9ac>
     38c:      	str	x0, [sp, #0x20]
     390:      	mov	x0, x21
     394:      	str	x1, [sp, #0x28]
     398:      	str	x2, [sp, #0x30]
     39c:      	str	x3, [sp, #0x38]
     3a0:      	str	x4, [sp, #0x40]
     3a4:      	str	x23, [sp, #0x48]
     3a8:      	mov	x23, x5
     3ac:      	str	x24, [sp, #0x50]
     3b0:      	mov	x24, x6
     3b4:      	str	x25, [sp, #0x58]
     3b8:      	mov	x25, x7
     3bc:      	str	x26, [sp, #0x60]
     3c0:      	mov	x26, x8
     3c4:      	str	x27, [sp, #0x68]
     3c8:      	mov	x27, x9
     3cc:      	str	x28, [sp, #0x70]
     3d0:      	mov	x28, x10
     3d4:      	str	x20, [sp, #0x78]
     3d8:      	mov	x20, x11
     3dc:      	str	x19, [sp, #0x80]
     3e0:      	mov	x19, x12
     3e4:      	bl	0x3e4 <_stogir.verify.structure+0x25c>
		00000000000003e4:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
     3e8:      	cmp	x20, x0
     3ec:      	b.ge	0xb48 <_stogir.verify.structure+0x9c0>
     3f0:      	ldr	x0, [x21]
     3f4:      	add	x0, x0, x20, lsl #4
     3f8:      	ldr	x1, [x0]
     3fc:      	ldr	x0, [x0, #0x8]
     400:      	add	x16, sp, #0x10
     404:      	str	x1, [x16]
     408:      	add	x16, sp, #0x10
     40c:      	str	x0, [x16, #0x8]
     410:      	ldr	x0, [sp, #0x48]
     414:      	bl	0x414 <_stogir.verify.structure+0x28c>
		0000000000000414:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
     418:      	ldr	x1, [x21, #0x78]
     41c:      	add	x1, x1, x20, lsl #2
     420:      	ldr	w1, [x1]
     424:      	sxtw	x1, w1
     428:      	cmp	x1, #0x0
     42c:      	b.lt	0x2f8 <_stogir.verify.structure+0x170>
     430:      	mov	x17, #0xffff            ; =65535
     434:      	cmp	x1, x17
     438:      	b.gt	0xb54 <_stogir.verify.structure+0x9cc>
     43c:      	uxtb	w0, w0
     440:      	orr	x2, x0, xzr
     444:      	str	w2, [sp, #0x98]
     448:      	str	x19, [sp, #0x88]
     44c:      	mov	x19, x1
     450:      	str	x23, [sp, #0x90]
     454:      	mov	w23, w0
     458:      	mov	w0, w2
     45c:      	bl	0x45c <_stogir.verify.structure+0x2d4>
		000000000000045c:  ARM64_RELOC_BRANCH26	_stogir.opcode.valid?
     460:      	cmp	x0, #0x0
     464:      	b.eq	0xb78 <_stogir.verify.structure+0x9f0>
     468:      	ldr	x0, [sp, #0x48]
     46c:      	bl	0x46c <_stogir.verify.structure+0x2e4>
		000000000000046c:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
     470:      	uxtb	w0, w0
     474:      	bl	0x474 <_stogir.verify.structure+0x2ec>
		0000000000000474:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     478:      	cmp	x0, #0x0
     47c:      	b.eq	0xb9c <_stogir.verify.structure+0xa14>
     480:      	cmp	x23, #0x83
     484:      	cset	w0, lt
     488:      	uxtb	w16, w0
     48c:      	cmp	w16, wzr
     490:      	b.eq	0x9c0 <_stogir.verify.structure+0x838>
     494:      	add	x1, x23, x26
     498:      	ldrsb	w1, [x1]
     49c:      	sxtb	w1, w1
     4a0:      	b	0x9c4 <_stogir.verify.structure+0x83c>
     4a4:      	ldr	x0, [sp, #0xc0]
     4a8:      	cmp	x0, #0x0
     4ac:      	b.ne	0xbc0 <_stogir.verify.structure+0xa38>
     4b0:      	and	x1, x1, #0xffffffff
     4b4:      	movz	x2, #0x0, lsl #48
     4b8:      	movz	x0, #0x0, lsl #48
     4bc:      	b	0x4c4 <_stogir.verify.structure+0x33c>
     4c0:      	mov	x2, #0x1                ; =1
     4c4:      	ldr	x3, [sp, #0x78]
     4c8:      	str	x2, [x3]
     4cc:      	str	x1, [x3, #0x8]
     4d0:      	str	x0, [x3, #0x10]
     4d4:      	ldr	x19, [sp, #0x118]
     4d8:      	ldr	x20, [sp, #0x120]
     4dc:      	ldr	x21, [sp, #0x128]
     4e0:      	ldr	x22, [sp, #0x130]
     4e4:      	ldr	x23, [sp, #0x138]
     4e8:      	ldr	x24, [sp, #0x140]
     4ec:      	ldr	x25, [sp, #0x148]
     4f0:      	ldr	x26, [sp, #0x150]
     4f4:      	ldr	x27, [sp, #0x158]
     4f8:      	ldr	x28, [sp, #0x160]
     4fc:      	ldr	x29, [sp]
     500:      	ldr	x30, [sp, #0x8]
     504:      	add	sp, sp, #0x170
     508:      	ret
     50c:      	movz	w3, #0x0, lsl #16
     510:      	movz	w2, #0x0, lsl #16
     514:      	b	0x53c <_stogir.verify.structure+0x3b4>
     518:      	ldr	x0, [sp, #0xe0]
     51c:      	ldr	w1, [sp, #0x108]
     520:      	bl	0x520 <_stogir.verify.structure+0x398>
		0000000000000520:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
     524:      	cmp	x0, #0x0
     528:      	b.eq	0xa38 <_stogir.verify.structure+0x8b0>
     52c:      	ldr	w1, [sp, #0x110]
     530:      	b	0x598 <_stogir.verify.structure+0x410>
     534:      	movz	w3, #0x0, lsl #16
     538:      	movz	w2, #0x0, lsl #16
     53c:      	ubfx	x3, x3, #0, #32
     540:      	lsr	x16, x3, #0
     544:      	cmp	x16, #0x1
     548:      	b.eq	0x564 <_stogir.verify.structure+0x3dc>
     54c:      	b.lo	0x554 <_stogir.verify.structure+0x3cc>
     550:      	b	0x568 <_stogir.verify.structure+0x3e0>
     554:      	cmp	x16, #0x0
     558:      	b.eq	0x560 <_stogir.verify.structure+0x3d8>
     55c:      	b	0x568 <_stogir.verify.structure+0x3e0>
     560:      	b	0x56c <_stogir.verify.structure+0x3e4>
     564:      	b	0x680 <_stogir.verify.structure+0x4f8>
     568:      	b	0xaa8 <_stogir.verify.structure+0x920>
     56c:      	str	x21, [sp, #0xe0]
     570:      	mov	w1, w19
     574:      	str	x24, [sp, #0xf8]
     578:      	ldr	x24, [sp, #0x90]
     57c:      	str	w23, [sp, #0xf0]
     580:      	str	x22, [sp, #0xe8]
     584:      	str	x25, [sp, #0x100]
     588:      	ldr	x17, [sp, #0x28]
     58c:      	str	x17, [sp, #0x80]
     590:      	mov	x16, #0x17              ; =23
     594:      	str	x16, [sp, #0xc0]
     598:      	ldr	x0, [sp, #0xd8]
     59c:      	add	x0, x0, #0x1
     5a0:      	sxtw	x0, w0
     5a4:      	ldr	x21, [sp, #0xe0]
     5a8:      	ldr	x19, [sp, #0xb0]
     5ac:      	ldr	x27, [sp, #0xd0]
     5b0:      	str	x24, [sp, #0x90]
     5b4:      	ldr	x24, [sp, #0xb8]
     5b8:      	mov	x2, x20
     5bc:      	ldr	x20, [sp, #0xc8]
     5c0:      	ldr	w23, [sp, #0xf0]
     5c4:      	ldr	x3, [sp, #0xe8]
     5c8:      	ldr	x25, [sp, #0x100]
     5cc:      	mov	x4, x0
     5d0:      	ldr	x0, [sp, #0xf8]
     5d4:      	ldr	x22, [sp, #0xc0]
     5d8:      	cmp	x22, #0x0
     5dc:      	b.ne	0x5f0 <_stogir.verify.structure+0x468>
     5e0:      	cmp	x4, x19
     5e4:      	cset	w5, le
     5e8:      	ubfx	x5, x5, #0, #8
     5ec:      	b	0x5f4 <_stogir.verify.structure+0x46c>
     5f0:      	movz	x5, #0x0, lsl #48
     5f4:      	cmp	x5, #0x0
     5f8:      	b.eq	0xbc8 <_stogir.verify.structure+0xa40>
     5fc:      	orr	w5, w4, wzr
     600:      	str	x4, [sp, #0xd8]
     604:      	str	x19, [sp, #0xb0]
     608:      	mov	w19, w1
     60c:      	mov	w1, w5
     610:      	str	x24, [sp, #0xb8]
     614:      	mov	x24, x0
     618:      	ldr	w0, [sp, #0x98]
     61c:      	str	x22, [sp, #0xc0]
     620:      	mov	x22, x3
     624:      	str	x20, [sp, #0xc8]
     628:      	mov	x20, x2
     62c:      	str	x27, [sp, #0xd0]
     630:      	mov	w27, w5
     634:      	bl	0x634 <_stogir.verify.structure+0x4ac>
		0000000000000634:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     638:      	sxtw	x1, w27
     63c:      	uxtb	w16, w23
     640:      	cmp	w16, wzr
     644:      	b.ne	0x534 <_stogir.verify.structure+0x3ac>
     648:      	ldr	x2, [x21, #0x8]
     64c:      	cmp	x24, x2
     650:      	b.ge	0x6a8 <_stogir.verify.structure+0x520>
     654:      	ldr	x2, [x25, #0x8]
     658:      	cmp	x24, x2
     65c:      	b.ge	0x6a0 <_stogir.verify.structure+0x518>
     660:      	ldr	x2, [x21, #0x78]
     664:      	add	x2, x22, x2
     668:      	ldr	w2, [x2]
     66c:      	sxtw	x2, w2
     670:      	cmp	x2, #0x0
     674:      	cset	w2, ge
     678:      	ubfx	x2, x2, #0, #8
     67c:      	b	0x6a4 <_stogir.verify.structure+0x51c>
     680:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000680:  ARM64_RELOC_PAGE21	l_stogir.325
     684:      	ldr	x16, [x16]
		0000000000000684:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     688:      	ldr	w3, [x16]
     68c:      	ubfx	x4, x0, #0, #32
     690:      	cmp	x4, x3
     694:      	b.ne	0x724 <_stogir.verify.structure+0x59c>
     698:      	mov	x3, #0x1                ; =1
     69c:      	b	0x73c <_stogir.verify.structure+0x5b4>
     6a0:      	movz	x2, #0x0, lsl #48
     6a4:      	b	0x6ac <_stogir.verify.structure+0x524>
     6a8:      	movz	x2, #0x0, lsl #48
     6ac:      	cmp	x2, #0x0
     6b0:      	b.eq	0x534 <_stogir.verify.structure+0x3ac>
     6b4:      	cmp	x1, #0x1
     6b8:      	b.lt	0x50c <_stogir.verify.structure+0x384>
     6bc:      	ldr	x2, [x21, #0x78]
     6c0:      	add	x2, x22, x2
     6c4:      	ldr	w2, [x2]
     6c8:      	sxtw	x2, w2
     6cc:      	cmp	x1, x2
     6d0:      	b.gt	0x50c <_stogir.verify.structure+0x384>
     6d4:      	ldr	x2, [x21]
     6d8:      	asr	x16, x1, #63
     6dc:      	lsr	x16, x16, #62
     6e0:      	add	x3, x1, x16
     6e4:      	asr	x3, x3, #2
     6e8:      	asr	x16, x1, #63
     6ec:      	lsr	x16, x16, #62
     6f0:      	add	x4, x1, x16
     6f4:      	and	x4, x4, #0x3
     6f8:      	sub	x4, x4, x16
     6fc:      	add	x3, x3, x24
     700:      	add	x2, x2, x3, lsl #4
     704:      	add	x2, x2, x4, lsl #2
     708:      	ldr	w2, [x2]
     70c:      	movn	w17, #0x0, lsl #16
     710:      	and	w2, w2, w17
     714:      	mov	w3, #0x1                ; =1
     718:      	b	0x514 <_stogir.verify.structure+0x38c>
     71c:      	movz	x19, #0x0, lsl #48
     720:      	b	0x7c4 <_stogir.verify.structure+0x63c>
     724:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000724:  ARM64_RELOC_PAGE21	l_stogir.326
     728:      	ldr	x16, [x16]
		0000000000000728:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     72c:      	ldr	w3, [x16]
     730:      	cmp	x4, x3
     734:      	cset	w3, eq
     738:      	ubfx	x3, x3, #0, #8
     73c:      	orr	w5, w2, wzr
     740:      	cmp	x3, #0x0
     744:      	b.eq	0xbe8 <_stogir.verify.structure+0xa60>
     748:      	str	w5, [sp, #0x108]
     74c:      	str	x21, [sp, #0xe0]
     750:      	str	x22, [sp, #0xe8]
     754:      	mov	w22, w2
     758:      	str	w23, [sp, #0xf0]
     75c:      	mov	w23, w0
     760:      	mov	x0, x21
     764:      	mov	x21, x1
     768:      	mov	w1, w5
     76c:      	str	x24, [sp, #0xf8]
     770:      	mov	x24, x4
     774:      	str	x25, [sp, #0x100]
     778:      	mov	x25, x3
     77c:      	bl	0x77c <_stogir.verify.structure+0x5f4>
		000000000000077c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     780:      	cmp	x0, #0x0
     784:      	cset	w1, eq
     788:      	uxtb	w16, w1
     78c:      	cmp	w16, wzr
     790:      	cset	x1, eq
     794:      	cmp	x1, #0x0
     798:      	b.eq	0xc1c <_stogir.verify.structure+0xa94>
     79c:      	str	w19, [sp, #0x110]
     7a0:      	mov	x19, x1
     7a4:      	bl	0x7a4 <_stogir.verify.structure+0x61c>
		00000000000007a4:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
     7a8:      	uxtb	w0, w0
     7ac:      	cmp	x0, #0x48
     7b0:      	b.ne	0x7c4 <_stogir.verify.structure+0x63c>
     7b4:      	ldr	x17, [sp, #0x30]
     7b8:      	str	x17, [sp, #0x80]
     7bc:      	mov	x16, #0x25              ; =37
     7c0:      	str	x16, [sp, #0xc0]
     7c4:      	sxtw	x22, w22
     7c8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007c8:  ARM64_RELOC_PAGE21	l_stogir.327
     7cc:      	ldr	x16, [x16]
		00000000000007cc:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     7d0:      	ldr	w0, [x16]
     7d4:      	cmp	x24, x0
     7d8:      	b.ne	0xc28 <_stogir.verify.structure+0xaa0>
     7dc:      	cmp	x22, #0x0
     7e0:      	b.gt	0x964 <_stogir.verify.structure+0x7dc>
     7e4:      	ldr	x24, [sp, #0x90]
     7e8:      	movz	w0, #0x0, lsl #16
     7ec:      	ubfx	x0, x0, #0, #32
     7f0:      	lsr	x16, x0, #0
     7f4:      	cmp	x16, #0x1
     7f8:      	b.eq	0x814 <_stogir.verify.structure+0x68c>
     7fc:      	b.lo	0x804 <_stogir.verify.structure+0x67c>
     800:      	b	0x818 <_stogir.verify.structure+0x690>
     804:      	cmp	x16, #0x0
     808:      	b.eq	0x810 <_stogir.verify.structure+0x688>
     80c:      	b	0x818 <_stogir.verify.structure+0x690>
     810:      	b	0x81c <_stogir.verify.structure+0x694>
     814:      	b	0x82c <_stogir.verify.structure+0x6a4>
     818:      	b	0xb2c <_stogir.verify.structure+0x9a4>
     81c:      	ldr	x17, [sp, #0x38]
     820:      	str	x17, [sp, #0x80]
     824:      	mov	x16, #0x21              ; =33
     828:      	str	x16, [sp, #0xc0]
     82c:      	ubfx	x23, x23, #0, #32
     830:      	cmp	x23, #0xf
     834:      	b.hs	0xc30 <_stogir.verify.structure+0xaa8>
     838:      	mov	x16, #0x1               ; =1
     83c:      	lsl	x0, x16, x23
     840:      	mov	w17, #0x5e1c            ; =24092
     844:      	and	w0, w0, w17
     848:      	ubfx	x0, x0, #0, #32
     84c:      	cmp	x0, #0x0
     850:      	b.eq	0xc38 <_stogir.verify.structure+0xab0>
     854:      	cmp	x25, #0x0
     858:      	b.eq	0x518 <_stogir.verify.structure+0x390>
     85c:      	mov	x0, x19
     860:      	b	0x524 <_stogir.verify.structure+0x39c>
     864:      	orr	w0, w20, wzr
     868:      	cmp	x23, #0x78
     86c:      	cset	w1, eq
     870:      	sxtw	x0, w0
     874:      	add	x2, x24, x23, lsl #2
     878:      	cmp	x0, #0x0
     87c:      	cset	w23, le
     880:      	lsl	x3, x0, #2
     884:      	mov	x4, #0x1                ; =1
     888:      	b	0x5d8 <_stogir.verify.structure+0x450>
     88c:      	nop
     890:      	movz	x1, #0x0, lsl #48
     894:      	cmp	x1, #0x0
     898:      	b.eq	0x864 <_stogir.verify.structure+0x6dc>
     89c:      	add	x1, x0, x20
     8a0:      	ldr	x2, [x21, #0x78]
     8a4:      	add	x1, x2, x1, lsl #2
     8a8:      	ldr	w1, [x1]
     8ac:      	sxtw	x1, w1
     8b0:      	cmn	x1, #0x1
     8b4:      	b.eq	0x8c4 <_stogir.verify.structure+0x73c>
     8b8:      	ldr	x17, [sp, #0x20]
     8bc:      	str	x17, [sp, #0x80]
     8c0:      	mov	x22, #0x1b              ; =27
     8c4:      	add	x0, x0, #0x1
     8c8:      	cmp	x22, #0x0
     8cc:      	b.ne	0x890 <_stogir.verify.structure+0x708>
     8d0:      	cmp	x0, x27
     8d4:      	cset	w1, lt
     8d8:      	ubfx	x1, x1, #0, #8
     8dc:      	b	0x894 <_stogir.verify.structure+0x70c>
     8e0:      	str	x26, [sp, #0xa0]
     8e4:      	mov	w26, w0
     8e8:      	ldr	w0, [sp, #0x98]
     8ec:      	bl	0x8ec <_stogir.verify.structure+0x764>
		00000000000008ec:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     8f0:      	sxtw	x0, w0
     8f4:      	cmn	x0, #0x1
     8f8:      	b.ne	0x91c <_stogir.verify.structure+0x794>
     8fc:      	ldr	x0, [sp, #0x48]
     900:      	bl	0x900 <_stogir.verify.structure+0x778>
		0000000000000900:  ARM64_RELOC_BRANCH26	_stogir.node.auxiliary
     904:      	uxth	w0, w0
     908:      	cmp	x19, x0
     90c:      	b.eq	0x91c <_stogir.verify.structure+0x794>
     910:      	ldr	x17, [sp, #0x68]
     914:      	str	x17, [sp, #0x80]
     918:      	mov	x22, #0x24              ; =36
     91c:      	add	x0, x19, #0x4
     920:      	str	x27, [sp, #0xa8]
     924:      	mov	x27, x0
     928:      	mov	x0, x21
     92c:      	bl	0x92c <_stogir.verify.structure+0x7a4>
		000000000000092c:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
     930:      	asr	x16, x27, #63
     934:      	lsr	x16, x16, #62
     938:      	add	x1, x27, x16
     93c:      	asr	x1, x1, #2
     940:      	orr	x27, x1, xzr
     944:      	add	x1, x27, x20
     948:      	cmp	x1, x0
     94c:      	b.le	0x95c <_stogir.verify.structure+0x7d4>
     950:      	ldr	x17, [sp, #0x70]
     954:      	str	x17, [sp, #0x80]
     958:      	mov	x22, #0x15              ; =21
     95c:      	mov	x0, #0x1                ; =1
     960:      	b	0x8c8 <_stogir.verify.structure+0x740>
     964:      	ldr	x0, [x28, #0x8]
     968:      	cmp	x22, x0
     96c:      	b.gt	0xc40 <_stogir.verify.structure+0xab8>
     970:      	sub	x0, x22, #0x1
     974:      	ldr	x24, [sp, #0x90]
     978:      	ldr	x1, [x24, #0x28]
     97c:      	mov	x17, #0x18              ; =24
     980:      	mul	x0, x0, x17
     984:      	add	x0, x0, x1
     988:      	ldr	x1, [x0]
     98c:      	ldr	x0, [x0, #0x8]
     990:      	ldr	x2, [x24, #0x8]
     994:      	cmp	x1, #0x0
     998:      	b.lt	0x9ec <_stogir.verify.structure+0x864>
     99c:      	cmp	x1, x2
     9a0:      	b.gt	0x9ec <_stogir.verify.structure+0x864>
     9a4:      	cmp	x0, #0x0
     9a8:      	b.lt	0x9ec <_stogir.verify.structure+0x864>
     9ac:      	sub	x1, x2, x1
     9b0:      	cmp	x0, x1
     9b4:      	b.gt	0x9ec <_stogir.verify.structure+0x864>
     9b8:      	mov	w0, #0x1                ; =1
     9bc:      	b	0x9f0 <_stogir.verify.structure+0x868>
     9c0:      	mov	w1, #-0x2               ; =-2
     9c4:      	sxtw	x1, w1
     9c8:      	cmp	x1, #0x0
     9cc:      	b.lt	0x8e0 <_stogir.verify.structure+0x758>
     9d0:      	uxtb	w16, w0
     9d4:      	cmp	w16, wzr
     9d8:      	b.eq	0x9f4 <_stogir.verify.structure+0x86c>
     9dc:      	add	x1, x23, x27
     9e0:      	ldrsb	w1, [x1]
     9e4:      	sxtb	w1, w1
     9e8:      	b	0x9f8 <_stogir.verify.structure+0x870>
     9ec:      	movz	w0, #0x0, lsl #16
     9f0:      	b	0x7ec <_stogir.verify.structure+0x664>
     9f4:      	mov	w1, #-0x2               ; =-2
     9f8:      	sxtw	x1, w1
     9fc:      	cmp	x19, x1
     a00:      	b.eq	0x8e0 <_stogir.verify.structure+0x758>
     a04:      	str	x21, [sp, #0xe0]
     a08:      	str	x24, [sp, #0xb8]
     a0c:      	ldr	x24, [sp, #0x90]
     a10:      	str	x25, [sp, #0x100]
     a14:      	str	x26, [sp, #0xa0]
     a18:      	str	x27, [sp, #0xa8]
     a1c:      	mov	x0, x20
     a20:      	ldr	x1, [sp, #0x88]
     a24:      	ldr	x17, [sp, #0x60]
     a28:      	str	x17, [sp, #0x80]
     a2c:      	mov	x16, #0x23              ; =35
     a30:      	str	x16, [sp, #0xc0]
     a34:      	b	0x214 <_stogir.verify.structure+0x8c>
     a38:      	cmp	x22, #0x0
     a3c:      	b.ne	0xc48 <_stogir.verify.structure+0xac0>
     a40:      	ldr	x0, [sp, #0x48]
     a44:      	bl	0xa44 <_stogir.verify.structure+0x8bc>
		0000000000000a44:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
     a48:      	uxtb	w16, w26
     a4c:      	cmp	w16, wzr
     a50:      	b.eq	0xab0 <_stogir.verify.structure+0x928>
     a54:      	ldr	w1, [x20]
     a58:      	cmp	x21, #0x0
     a5c:      	b.le	0xaf0 <_stogir.verify.structure+0x968>
     a60:      	cmp	x21, #0x4
     a64:      	b.le	0xb14 <_stogir.verify.structure+0x98c>
     a68:      	mov	w2, #0x4                ; =4
     a6c:      	b	0xb18 <_stogir.verify.structure+0x990>
     a70:      	ldr	w1, [sp, #0x110]
     a74:      	uxtb	w16, w1
     a78:      	cmp	w16, wzr
     a7c:      	b.eq	0xa94 <_stogir.verify.structure+0x90c>
     a80:      	uxtb	w0, w0
     a84:      	cmp	x0, #0x0
     a88:      	b.ne	0xa94 <_stogir.verify.structure+0x90c>
     a8c:      	cmp	x21, #0x2
     a90:      	b.eq	0x530 <_stogir.verify.structure+0x3a8>
     a94:      	ldr	x17, [sp, #0x40]
     a98:      	str	x17, [sp, #0x80]
     a9c:      	mov	x16, #0x1a              ; =26
     aa0:      	str	x16, [sp, #0xc0]
     aa4:      	b	0x530 <_stogir.verify.structure+0x3a8>
     aa8:      	brk	#0
     aac:      	b	0xaa8 <_stogir.verify.structure+0x920>
     ab0:      	movz	w1, #0x0, lsl #16
     ab4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ab4:  ARM64_RELOC_PAGE21	l_stogir.328
     ab8:      	ldr	x16, [x16]
		0000000000000ab8:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     abc:      	ldr	w2, [x16]
     ac0:      	ubfx	x1, x1, #0, #32
     ac4:      	cmp	x1, x2
     ac8:      	b.ne	0xad4 <_stogir.verify.structure+0x94c>
     acc:      	ldr	w1, [sp, #0x110]
     ad0:      	b	0x530 <_stogir.verify.structure+0x3a8>
     ad4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ad4:  ARM64_RELOC_PAGE21	l_stogir.329
     ad8:      	ldr	x16, [x16]
		0000000000000ad8:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     adc:      	ldr	w2, [x16]
     ae0:      	cmp	x1, x2
     ae4:      	b.ne	0xaf8 <_stogir.verify.structure+0x970>
     ae8:      	ldr	w1, [sp, #0x110]
     aec:      	b	0x530 <_stogir.verify.structure+0x3a8>
     af0:      	movz	w1, #0x0, lsl #16
     af4:      	b	0xab4 <_stogir.verify.structure+0x92c>
     af8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000af8:  ARM64_RELOC_PAGE21	l_stogir.330
     afc:      	ldr	x16, [x16]
		0000000000000afc:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     b00:      	ldr	w2, [x16]
     b04:      	cmp	x1, x2
     b08:      	b.ne	0xa70 <_stogir.verify.structure+0x8e8>
     b0c:      	ldr	w1, [sp, #0x110]
     b10:      	b	0x530 <_stogir.verify.structure+0x3a8>
     b14:      	sub	w2, w27, #0x1
     b18:      	lsl	w2, w2, #2
     b1c:      	ubfx	x2, x2, #0, #32
     b20:      	lsr	x1, x1, x2
     b24:      	and	w1, w1, #0xf
     b28:      	b	0xaf4 <_stogir.verify.structure+0x96c>
     b2c:      	brk	#0
     b30:      	b	0xb2c <_stogir.verify.structure+0x9a4>
     b34:      	mov	x1, x12
     b38:      	str	x20, [sp, #0x78]
     b3c:      	str	x19, [sp, #0x80]
     b40:      	str	x22, [sp, #0xc0]
     b44:      	b	0x4a4 <_stogir.verify.structure+0x31c>
     b48:      	mov	x1, x19
     b4c:      	str	x22, [sp, #0xc0]
     b50:      	b	0x4a4 <_stogir.verify.structure+0x31c>
     b54:      	mov	x0, x20
     b58:      	mov	x1, x19
     b5c:      	str	x21, [sp, #0xe0]
     b60:      	str	x24, [sp, #0xb8]
     b64:      	mov	x24, x23
     b68:      	str	x25, [sp, #0x100]
     b6c:      	str	x26, [sp, #0xa0]
     b70:      	str	x27, [sp, #0xa8]
     b74:      	b	0x318 <_stogir.verify.structure+0x190>
     b78:      	mov	x0, x20
     b7c:      	ldr	x1, [sp, #0x88]
     b80:      	str	x21, [sp, #0xe0]
     b84:      	str	x24, [sp, #0xb8]
     b88:      	ldr	x24, [sp, #0x90]
     b8c:      	str	x25, [sp, #0x100]
     b90:      	str	x26, [sp, #0xa0]
     b94:      	str	x27, [sp, #0xa8]
     b98:      	b	0x2e4 <_stogir.verify.structure+0x15c>
     b9c:      	mov	x0, x20
     ba0:      	ldr	x1, [sp, #0x88]
     ba4:      	str	x21, [sp, #0xe0]
     ba8:      	str	x24, [sp, #0xb8]
     bac:      	ldr	x24, [sp, #0x90]
     bb0:      	str	x25, [sp, #0x100]
     bb4:      	str	x26, [sp, #0xa0]
     bb8:      	str	x27, [sp, #0xa8]
     bbc:      	b	0x2e4 <_stogir.verify.structure+0x15c>
     bc0:      	ldr	x1, [sp, #0x80]
     bc4:      	b	0x4c0 <_stogir.verify.structure+0x338>
     bc8:      	str	x20, [sp, #0xc8]
     bcc:      	str	x21, [sp, #0xe0]
     bd0:      	str	x27, [sp, #0xd0]
     bd4:      	str	x22, [sp, #0xc0]
     bd8:      	str	x24, [sp, #0xb8]
     bdc:      	ldr	x24, [sp, #0x90]
     be0:      	str	x25, [sp, #0x100]
     be4:      	b	0x1fc <_stogir.verify.structure+0x74>
     be8:      	str	x21, [sp, #0xe0]
     bec:      	str	w5, [sp, #0x108]
     bf0:      	mov	x21, x1
     bf4:      	str	w19, [sp, #0x110]
     bf8:      	str	x24, [sp, #0xf8]
     bfc:      	mov	x24, x4
     c00:      	str	w23, [sp, #0xf0]
     c04:      	mov	w23, w0
     c08:      	str	x22, [sp, #0xe8]
     c0c:      	mov	w22, w2
     c10:      	str	x25, [sp, #0x100]
     c14:      	mov	x25, x3
     c18:      	b	0x71c <_stogir.verify.structure+0x594>
     c1c:      	str	w19, [sp, #0x110]
     c20:      	mov	x19, x1
     c24:      	b	0x7c4 <_stogir.verify.structure+0x63c>
     c28:      	ldr	x24, [sp, #0x90]
     c2c:      	b	0x82c <_stogir.verify.structure+0x6a4>
     c30:      	ldr	w1, [sp, #0x110]
     c34:      	b	0x530 <_stogir.verify.structure+0x3a8>
     c38:      	ldr	w1, [sp, #0x110]
     c3c:      	b	0x530 <_stogir.verify.structure+0x3a8>
     c40:      	ldr	x24, [sp, #0x90]
     c44:      	b	0x7e8 <_stogir.verify.structure+0x660>
     c48:      	ldr	w1, [sp, #0x110]
     c4c:      	b	0xa94 <_stogir.verify.structure+0x90c>

0000000000000c50 <_stogir.verify.integer-operations-target-structured>:
     c50:      	sub	sp, sp, #0x3c0
     c54:      	str	x29, [sp, #0x10]
     c58:      	str	x30, [sp, #0x18]
     c5c:      	add	x29, sp, #0x10
     c60:      	str	x19, [sp, #0x368]
     c64:      	str	x20, [sp, #0x370]
     c68:      	str	x21, [sp, #0x378]
     c6c:      	str	x22, [sp, #0x380]
     c70:      	str	x23, [sp, #0x388]
     c74:      	str	x24, [sp, #0x390]
     c78:      	str	x25, [sp, #0x398]
     c7c:      	str	x26, [sp, #0x3a0]
     c80:      	str	x27, [sp, #0x3a8]
     c84:      	str	x28, [sp, #0x3b0]
     c88:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000c88:  ARM64_RELOC_PAGE21	l_stogir.331
     c8c:      	ldr	x16, [x16]
		0000000000000c8c:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     c90:      	orr	x19, x16, xzr
     c94:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000c94:  ARM64_RELOC_PAGE21	l_stogir.332
     c98:      	ldr	x16, [x16]
		0000000000000c98:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     c9c:      	orr	x20, x16, xzr
     ca0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ca0:  ARM64_RELOC_PAGE21	l_stogir.333
     ca4:      	ldr	x16, [x16]
		0000000000000ca4:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     ca8:      	orr	x21, x16, xzr
     cac:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cac:  ARM64_RELOC_PAGE21	l_stogir.334
     cb0:      	ldr	x16, [x16]
		0000000000000cb0:  ARM64_RELOC_PAGEOFF12	l_stogir.334
     cb4:      	orr	x22, x16, xzr
     cb8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cb8:  ARM64_RELOC_PAGE21	l_stogir.335
     cbc:      	ldr	x16, [x16]
		0000000000000cbc:  ARM64_RELOC_PAGEOFF12	l_stogir.335
     cc0:      	orr	x23, x16, xzr
     cc4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cc4:  ARM64_RELOC_PAGE21	l_stogir.336
     cc8:      	ldr	x16, [x16]
		0000000000000cc8:  ARM64_RELOC_PAGEOFF12	l_stogir.336
     ccc:      	orr	x24, x16, xzr
     cd0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cd0:  ARM64_RELOC_PAGE21	l_stogir.337
     cd4:      	ldr	x16, [x16]
		0000000000000cd4:  ARM64_RELOC_PAGEOFF12	l_stogir.337
     cd8:      	orr	x25, x16, xzr
     cdc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cdc:  ARM64_RELOC_PAGE21	l_stogir.338
     ce0:      	ldr	x16, [x16]
		0000000000000ce0:  ARM64_RELOC_PAGEOFF12	l_stogir.338
     ce4:      	orr	x26, x16, xzr
     ce8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ce8:  ARM64_RELOC_PAGE21	l_stogir.339
     cec:      	ldr	x16, [x16]
		0000000000000cec:  ARM64_RELOC_PAGEOFF12	l_stogir.339
     cf0:      	orr	x27, x16, xzr
     cf4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cf4:  ARM64_RELOC_PAGE21	l_stogir.340
     cf8:      	ldr	x16, [x16]
		0000000000000cf8:  ARM64_RELOC_PAGEOFF12	l_stogir.340
     cfc:      	orr	x28, x16, xzr
     d00:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000d00:  ARM64_RELOC_PAGE21	l_stogir.341
     d04:      	ldr	x16, [x16]
		0000000000000d04:  ARM64_RELOC_PAGEOFF12	l_stogir.341
     d08:      	orr	x2, x16, xzr
     d0c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000d0c:  ARM64_RELOC_PAGE21	l_stogir.342
     d10:      	ldr	x16, [x16]
		0000000000000d10:  ARM64_RELOC_PAGEOFF12	l_stogir.342
     d14:      	orr	x3, x16, xzr
     d18:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000d18:  ARM64_RELOC_PAGE21	l_stogir.343
     d1c:      	ldr	x16, [x16]
		0000000000000d1c:  ARM64_RELOC_PAGEOFF12	l_stogir.343
     d20:      	orr	x4, x16, xzr
     d24:      	add	x5, x0, #0x78
     d28:      	add	x6, x0, #0x28
     d2c:      	add	x7, x0, #0x50
     d30:      	orr	w9, w1, wzr
     d34:      	orr	w10, w1, wzr
     d38:      	add	x16, sp, #0x20
     d3c:      	orr	x11, x16, xzr
     d40:      	add	x16, sp, #0x30
     d44:      	orr	x12, x16, xzr
     d48:      	add	x12, x12, #0x8
     d4c:      	add	x16, sp, #0x50
     d50:      	orr	x13, x16, xzr
     d54:      	add	x13, x13, #0x8
     d58:      	add	x16, sp, #0x70
     d5c:      	orr	x14, x16, xzr
     d60:      	add	x16, sp, #0xc0
     d64:      	orr	x15, x16, xzr
     d68:      	add	x15, x15, #0x8
     d6c:      	str	x0, [sp, #0x220]
     d70:      	add	x16, sp, #0xe0
     d74:      	orr	x0, x16, xzr
     d78:      	add	x0, x0, #0x8
     d7c:      	str	x0, [sp, #0x228]
     d80:      	add	x16, sp, #0x100
     d84:      	orr	x0, x16, xzr
     d88:      	add	x0, x0, #0x8
     d8c:      	str	x0, [sp, #0x230]
     d90:      	add	x16, sp, #0x120
     d94:      	orr	x0, x16, xzr
     d98:      	add	x0, x0, #0x8
     d9c:      	str	x0, [sp, #0x238]
     da0:      	add	x16, sp, #0x140
     da4:      	orr	x0, x16, xzr
     da8:      	add	x0, x0, #0x8
     dac:      	str	x0, [sp, #0x240]
     db0:      	add	x16, sp, #0x160
     db4:      	orr	x0, x16, xzr
     db8:      	add	x0, x0, #0x8
     dbc:      	str	x0, [sp, #0x248]
     dc0:      	add	x16, sp, #0x180
     dc4:      	orr	x0, x16, xzr
     dc8:      	add	x0, x0, #0x8
     dcc:      	str	x0, [sp, #0x250]
     dd0:      	add	x16, sp, #0x1a0
     dd4:      	orr	x0, x16, xzr
     dd8:      	add	x0, x0, #0x8
     ddc:      	str	x20, [sp, #0x258]
     de0:      	add	x16, sp, #0x1d0
     de4:      	orr	x20, x16, xzr
     de8:      	str	x0, [sp, #0x260]
     dec:      	add	x16, sp, #0x1e0
     df0:      	orr	x0, x16, xzr
     df4:      	add	x0, x0, #0x8
     df8:      	str	x21, [sp, #0x270]
     dfc:      	str	x22, [sp, #0x278]
     e00:      	str	x20, [sp, #0x268]
     e04:      	mov	x20, #0x1               ; =1
     e08:      	movz	x21, #0x0, lsl #48
     e0c:      	movz	x22, #0x0, lsl #48
     e10:      	cmp	x22, #0x0
     e14:      	b.ne	0x1eac <_stogir.verify.integer-operations-target-structured+0x125c>
     e18:      	str	x8, [sp, #0x2b8]
     e1c:      	str	x2, [sp, #0x290]
     e20:      	str	x4, [sp, #0x2e0]
     e24:      	str	x7, [sp, #0x2e8]
     e28:      	str	w9, [sp, #0x2c0]
     e2c:      	str	w10, [sp, #0x2c8]
     e30:      	str	w1, [sp, #0x2d0]
     e34:      	str	x11, [sp, #0x2d8]
     e38:      	str	x14, [sp, #0x2f0]
     e3c:      	str	x15, [sp, #0x2f8]
     e40:      	str	x0, [sp, #0x300]
     e44:      	ldr	x0, [sp, #0x220]
     e48:      	str	x23, [sp, #0x280]
     e4c:      	mov	x23, x13
     e50:      	str	x24, [sp, #0x288]
     e54:      	ldr	x24, [sp, #0x220]
     e58:      	str	x25, [sp, #0x298]
     e5c:      	mov	x25, x3
     e60:      	str	x26, [sp, #0x2a0]
     e64:      	mov	x26, x12
     e68:      	str	x27, [sp, #0x2a8]
     e6c:      	mov	x27, x5
     e70:      	str	x28, [sp, #0x2b0]
     e74:      	mov	x28, x6
     e78:      	bl	0xe78 <_stogir.verify.integer-operations-target-structured+0x228>
		0000000000000e78:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
     e7c:      	cmp	x20, x0
     e80:      	b.ge	0x1e48 <_stogir.verify.integer-operations-target-structured+0x11f8>
     e84:      	ldr	x0, [x24]
     e88:      	add	x0, x0, x20, lsl #4
     e8c:      	ldr	x1, [x0]
     e90:      	ldr	x0, [x0, #0x8]
     e94:      	add	x16, sp, #0x20
     e98:      	str	x1, [x16]
     e9c:      	add	x16, sp, #0x20
     ea0:      	str	x0, [x16, #0x8]
     ea4:      	ldr	x0, [sp, #0x2d8]
     ea8:      	bl	0xea8 <_stogir.verify.integer-operations-target-structured+0x258>
		0000000000000ea8:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
     eac:      	uxtb	w0, w0
     eb0:      	ldr	x1, [x24, #0x78]
     eb4:      	orr	x2, x0, xzr
     eb8:      	add	x1, x1, x20, lsl #2
     ebc:      	ldr	w1, [x1]
     ec0:      	cmp	x2, #0x83
     ec4:      	b.ge	0x16f4 <_stogir.verify.integer-operations-target-structured+0xaa4>
     ec8:      	add	x3, x25, x2, lsl #1
     ecc:      	ldrh	w3, [x3]
     ed0:      	cmp	x2, #0xe
     ed4:      	b.lt	0x16fc <_stogir.verify.integer-operations-target-structured+0xaac>
     ed8:      	cmp	x2, #0x17
     edc:      	cset	w4, le
     ee0:      	ubfx	x4, x4, #0, #8
     ee4:      	orr	w5, w20, wzr
     ee8:      	and	w6, w3, #0x4
     eec:      	ubfx	x6, x6, #0, #32
     ef0:      	str	w0, [sp, #0x320]
     ef4:      	mov	x0, x24
     ef8:      	str	w1, [sp, #0x318]
     efc:      	str	w3, [sp, #0x338]
     f00:      	mov	w3, w1
     f04:      	mov	w1, w5
     f08:      	str	x4, [sp, #0x328]
     f0c:      	str	w5, [sp, #0x330]
     f10:      	str	x25, [sp, #0x308]
     f14:      	mov	x25, x6
     f18:      	str	x20, [sp, #0x310]
     f1c:      	mov	x20, x2
     f20:      	ldr	x2, [sp, #0x2d8]
     f24:      	bl	0xf24 <_stogir.verify.integer-operations-target-structured+0x2d4>
		0000000000000f24:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
     f28:      	uxtb	w1, w0
     f2c:      	cmp	x1, #0x0
     f30:      	cset	w1, ne
     f34:      	cmp	x25, #0x0
     f38:      	b.ne	0x1704 <_stogir.verify.integer-operations-target-structured+0xab4>
     f3c:      	uxtb	w16, w1
     f40:      	cmp	w16, wzr
     f44:      	b.ne	0x1704 <_stogir.verify.integer-operations-target-structured+0xab4>
     f48:      	str	x0, [sp, #0x340]
     f4c:      	mov	w25, w1
     f50:      	cmp	x20, #0x44
     f54:      	b.ne	0x1778 <_stogir.verify.integer-operations-target-structured+0xb28>
     f58:      	uxtb	w16, w25
     f5c:      	cmp	w16, wzr
     f60:      	b.eq	0x1770 <_stogir.verify.integer-operations-target-structured+0xb20>
     f64:      	movz	x0, #0x0, lsl #48
     f68:      	cmp	x0, #0x0
     f6c:      	b.eq	0xfc0 <_stogir.verify.integer-operations-target-structured+0x370>
     f70:      	add	x8, sp, #0x50
     f74:      	mov	x0, x24
     f78:      	ldr	w1, [sp, #0x330]
     f7c:      	bl	0xf7c <_stogir.verify.integer-operations-target-structured+0x32c>
		0000000000000f7c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
     f80:      	add	x16, sp, #0x50
     f84:      	ldr	w0, [x16]
     f88:      	lsr	x16, x0, #0
     f8c:      	cmp	x16, #0x1
     f90:      	b.eq	0xfac <_stogir.verify.integer-operations-target-structured+0x35c>
     f94:      	b.lo	0xf9c <_stogir.verify.integer-operations-target-structured+0x34c>
     f98:      	b	0xfb0 <_stogir.verify.integer-operations-target-structured+0x360>
     f9c:      	cmp	x16, #0x0
     fa0:      	b.eq	0xfa8 <_stogir.verify.integer-operations-target-structured+0x358>
     fa4:      	b	0xfb0 <_stogir.verify.integer-operations-target-structured+0x360>
     fa8:      	b	0x1780 <_stogir.verify.integer-operations-target-structured+0xb30>
     fac:      	b	0xfb4 <_stogir.verify.integer-operations-target-structured+0x364>
     fb0:      	b	0x178c <_stogir.verify.integer-operations-target-structured+0xb3c>
     fb4:      	add	x16, sp, #0x50
     fb8:      	ldr	x19, [x16, #0x8]
     fbc:      	ldr	x22, [x23, #0x8]
     fc0:      	cmp	x20, #0x1d
     fc4:      	b.ne	0x1794 <_stogir.verify.integer-operations-target-structured+0xb44>
     fc8:      	mov	x0, #0x1                ; =1
     fcc:      	cmp	x0, #0x0
     fd0:      	b.eq	0x17ac <_stogir.verify.integer-operations-target-structured+0xb5c>
     fd4:      	add	x16, sp, #0x20
     fd8:      	ldr	w0, [x16, #0xc]
     fdc:      	sxtw	x0, w0
     fe0:      	cmp	x0, #0x0
     fe4:      	b.ne	0x17a4 <_stogir.verify.integer-operations-target-structured+0xb54>
     fe8:      	movz	x0, #0x0, lsl #48
     fec:      	cmp	x0, #0x0
     ff0:      	b.eq	0x10bc <_stogir.verify.integer-operations-target-structured+0x46c>
     ff4:      	add	x16, sp, #0x20
     ff8:      	ldr	w0, [x16, #0xc]
     ffc:      	sxtw	x0, w0
    1000:      	cmp	x0, #0x0
    1004:      	cset	w1, gt
    1008:      	movz	x16, #0x0, lsl #48
    100c:      	sub	x2, x16, x0
    1010:      	sub	x3, x2, #0x1
    1014:      	uxtb	w16, w1
    1018:      	cmp	w16, wzr
    101c:      	b.eq	0x17c4 <_stogir.verify.integer-operations-target-structured+0xb74>
    1020:      	ldr	x2, [x24, #0x8]
    1024:      	cmp	x0, x2
    1028:      	b.ge	0x17bc <_stogir.verify.integer-operations-target-structured+0xb6c>
    102c:      	ldr	x2, [x27, #0x8]
    1030:      	cmp	x0, x2
    1034:      	b.ge	0x17b4 <_stogir.verify.integer-operations-target-structured+0xb64>
    1038:      	ldr	x2, [x24, #0x78]
    103c:      	add	x2, x2, x0, lsl #2
    1040:      	ldr	w2, [x2]
    1044:      	sxtw	x2, w2
    1048:      	cmp	x2, #0x0
    104c:      	cset	w2, ge
    1050:      	ubfx	x2, x2, #0, #8
    1054:      	ldr	x5, [sp, #0x2e8]
    1058:      	cmp	x2, #0x0
    105c:      	b.eq	0x1834 <_stogir.verify.integer-operations-target-structured+0xbe4>
    1060:      	uxtb	w16, w1
    1064:      	cmp	w16, wzr
    1068:      	b.eq	0x1820 <_stogir.verify.integer-operations-target-structured+0xbd0>
    106c:      	ldr	x1, [x24]
    1070:      	add	x0, x1, x0, lsl #4
    1074:      	ldr	x1, [x0]
    1078:      	ldr	x0, [x0, #0x8]
    107c:      	mov	w2, #0x1                ; =1
    1080:      	ubfx	x2, x2, #0, #32
    1084:      	lsr	x16, x2, #0
    1088:      	cmp	x16, #0x1
    108c:      	b.eq	0x10a8 <_stogir.verify.integer-operations-target-structured+0x458>
    1090:      	b.lo	0x1098 <_stogir.verify.integer-operations-target-structured+0x448>
    1094:      	b	0x10ac <_stogir.verify.integer-operations-target-structured+0x45c>
    1098:      	cmp	x16, #0x0
    109c:      	b.eq	0x10a4 <_stogir.verify.integer-operations-target-structured+0x454>
    10a0:      	b	0x10ac <_stogir.verify.integer-operations-target-structured+0x45c>
    10a4:      	b	0x10b0 <_stogir.verify.integer-operations-target-structured+0x460>
    10a8:      	b	0x1844 <_stogir.verify.integer-operations-target-structured+0xbf4>
    10ac:      	b	0x1908 <_stogir.verify.integer-operations-target-structured+0xcb8>
    10b0:      	str	x5, [sp, #0x2e8]
    10b4:      	ldr	x19, [sp, #0x258]
    10b8:      	mov	x22, #0x16              ; =22
    10bc:      	ldr	w0, [sp, #0x338]
    10c0:      	and	w1, w0, #0x8
    10c4:      	ubfx	x1, x1, #0, #32
    10c8:      	cmp	x1, #0x0
    10cc:      	b.ne	0x1910 <_stogir.verify.integer-operations-target-structured+0xcc0>
    10d0:      	movz	x1, #0x0, lsl #48
    10d4:      	cmp	x20, #0x2c
    10d8:      	cset	w2, eq
    10dc:      	cmp	x1, #0x0
    10e0:      	b.eq	0x1918 <_stogir.verify.integer-operations-target-structured+0xcc8>
    10e4:      	mov	x1, #0x1                ; =1
    10e8:      	cmp	x1, #0x0
    10ec:      	b.eq	0x1eb4 <_stogir.verify.integer-operations-target-structured+0x1264>
    10f0:      	uxtb	w16, w2
    10f4:      	cmp	w16, wzr
    10f8:      	b.eq	0x1ec0 <_stogir.verify.integer-operations-target-structured+0x1270>
    10fc:      	add	x8, sp, #0x80
    1100:      	ldr	w1, [sp, #0x330]
    1104:      	str	x23, [sp, #0x348]
    1108:      	mov	w23, w0
    110c:      	mov	x0, x24
    1110:      	bl	0x1110 <_stogir.verify.integer-operations-target-structured+0x4c0>
		0000000000001110:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    1114:      	add	x16, sp, #0x80
    1118:      	ldr	x0, [x16]
    111c:      	add	x16, sp, #0x80
    1120:      	ldr	x1, [x16, #0x8]
    1124:      	add	x16, sp, #0x80
    1128:      	ldr	x2, [x16, #0x10]
    112c:      	ubfx	x0, x0, #0, #32
    1130:      	lsr	x16, x0, #0
    1134:      	cmp	x16, #0x1
    1138:      	b.eq	0x1154 <_stogir.verify.integer-operations-target-structured+0x504>
    113c:      	b.lo	0x1144 <_stogir.verify.integer-operations-target-structured+0x4f4>
    1140:      	b	0x1158 <_stogir.verify.integer-operations-target-structured+0x508>
    1144:      	cmp	x16, #0x0
    1148:      	b.eq	0x1150 <_stogir.verify.integer-operations-target-structured+0x500>
    114c:      	b	0x1158 <_stogir.verify.integer-operations-target-structured+0x508>
    1150:      	b	0x194c <_stogir.verify.integer-operations-target-structured+0xcfc>
    1154:      	b	0x115c <_stogir.verify.integer-operations-target-structured+0x50c>
    1158:      	b	0x1958 <_stogir.verify.integer-operations-target-structured+0xd08>
    115c:      	mov	x19, x1
    1160:      	mov	x22, x2
    1164:      	and	w0, w23, #0x10
    1168:      	ubfx	x0, x0, #0, #32
    116c:      	cmp	x0, #0x0
    1170:      	b.ne	0x1960 <_stogir.verify.integer-operations-target-structured+0xd10>
    1174:      	movz	x0, #0x0, lsl #48
    1178:      	cmp	x0, #0x0
    117c:      	b.eq	0x1ecc <_stogir.verify.integer-operations-target-structured+0x127c>
    1180:      	add	x8, sp, #0xc0
    1184:      	mov	x0, x24
    1188:      	ldr	w1, [sp, #0x330]
    118c:      	bl	0x118c <_stogir.verify.integer-operations-target-structured+0x53c>
		000000000000118c:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    1190:      	add	x16, sp, #0xc0
    1194:      	ldr	w0, [x16]
    1198:      	lsr	x16, x0, #0
    119c:      	cmp	x16, #0x1
    11a0:      	b.eq	0x11c0 <_stogir.verify.integer-operations-target-structured+0x570>
    11a4:      	b.lo	0x11ac <_stogir.verify.integer-operations-target-structured+0x55c>
    11a8:      	b	0x11c4 <_stogir.verify.integer-operations-target-structured+0x574>
    11ac:      	cmp	x16, #0x0
    11b0:      	b.eq	0x11b8 <_stogir.verify.integer-operations-target-structured+0x568>
    11b4:      	b	0x11c4 <_stogir.verify.integer-operations-target-structured+0x574>
    11b8:      	ldr	x0, [sp, #0x2f8]
    11bc:      	b	0x1968 <_stogir.verify.integer-operations-target-structured+0xd18>
    11c0:      	b	0x11c8 <_stogir.verify.integer-operations-target-structured+0x578>
    11c4:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xd24>
    11c8:      	add	x16, sp, #0xc0
    11cc:      	ldr	x19, [x16, #0x8]
    11d0:      	ldr	x0, [sp, #0x2f8]
    11d4:      	ldr	x22, [x0, #0x8]
    11d8:      	and	w1, w23, #0x20
    11dc:      	ubfx	x1, x1, #0, #32
    11e0:      	cmp	x1, #0x0
    11e4:      	b.ne	0x197c <_stogir.verify.integer-operations-target-structured+0xd2c>
    11e8:      	movz	x1, #0x0, lsl #48
    11ec:      	cmp	x1, #0x0
    11f0:      	b.eq	0x1ed4 <_stogir.verify.integer-operations-target-structured+0x1284>
    11f4:      	add	x8, sp, #0xe0
    11f8:      	ldr	w1, [sp, #0x330]
    11fc:      	str	x0, [sp, #0x2f8]
    1200:      	mov	x0, x24
    1204:      	bl	0x1204 <_stogir.verify.integer-operations-target-structured+0x5b4>
		0000000000001204:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    1208:      	add	x16, sp, #0xe0
    120c:      	ldr	w0, [x16]
    1210:      	lsr	x16, x0, #0
    1214:      	cmp	x16, #0x1
    1218:      	b.eq	0x1238 <_stogir.verify.integer-operations-target-structured+0x5e8>
    121c:      	b.lo	0x1224 <_stogir.verify.integer-operations-target-structured+0x5d4>
    1220:      	b	0x123c <_stogir.verify.integer-operations-target-structured+0x5ec>
    1224:      	cmp	x16, #0x0
    1228:      	b.eq	0x1230 <_stogir.verify.integer-operations-target-structured+0x5e0>
    122c:      	b	0x123c <_stogir.verify.integer-operations-target-structured+0x5ec>
    1230:      	ldr	x0, [sp, #0x228]
    1234:      	b	0x1984 <_stogir.verify.integer-operations-target-structured+0xd34>
    1238:      	b	0x1240 <_stogir.verify.integer-operations-target-structured+0x5f0>
    123c:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xd40>
    1240:      	add	x16, sp, #0xe0
    1244:      	ldr	x19, [x16, #0x8]
    1248:      	ldr	x0, [sp, #0x228]
    124c:      	ldr	x22, [x0, #0x8]
    1250:      	and	w1, w23, #0x40
    1254:      	ubfx	x1, x1, #0, #32
    1258:      	cmp	x1, #0x0
    125c:      	b.ne	0x1998 <_stogir.verify.integer-operations-target-structured+0xd48>
    1260:      	movz	x1, #0x0, lsl #48
    1264:      	cmp	x1, #0x0
    1268:      	b.eq	0x1ee0 <_stogir.verify.integer-operations-target-structured+0x1290>
    126c:      	add	x8, sp, #0x100
    1270:      	ldr	w1, [sp, #0x330]
    1274:      	str	x0, [sp, #0x228]
    1278:      	mov	x0, x24
    127c:      	bl	0x127c <_stogir.verify.integer-operations-target-structured+0x62c>
		000000000000127c:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    1280:      	add	x16, sp, #0x100
    1284:      	ldr	w0, [x16]
    1288:      	lsr	x16, x0, #0
    128c:      	cmp	x16, #0x1
    1290:      	b.eq	0x12b0 <_stogir.verify.integer-operations-target-structured+0x660>
    1294:      	b.lo	0x129c <_stogir.verify.integer-operations-target-structured+0x64c>
    1298:      	b	0x12b4 <_stogir.verify.integer-operations-target-structured+0x664>
    129c:      	cmp	x16, #0x0
    12a0:      	b.eq	0x12a8 <_stogir.verify.integer-operations-target-structured+0x658>
    12a4:      	b	0x12b4 <_stogir.verify.integer-operations-target-structured+0x664>
    12a8:      	ldr	x0, [sp, #0x230]
    12ac:      	b	0x19a0 <_stogir.verify.integer-operations-target-structured+0xd50>
    12b0:      	b	0x12b8 <_stogir.verify.integer-operations-target-structured+0x668>
    12b4:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xd5c>
    12b8:      	add	x16, sp, #0x100
    12bc:      	ldr	x19, [x16, #0x8]
    12c0:      	ldr	x0, [sp, #0x230]
    12c4:      	ldr	x22, [x0, #0x8]
    12c8:      	and	w1, w23, #0x80
    12cc:      	ubfx	x1, x1, #0, #32
    12d0:      	cmp	x1, #0x0
    12d4:      	b.ne	0x19b4 <_stogir.verify.integer-operations-target-structured+0xd64>
    12d8:      	movz	x1, #0x0, lsl #48
    12dc:      	cmp	x1, #0x0
    12e0:      	b.eq	0x1eec <_stogir.verify.integer-operations-target-structured+0x129c>
    12e4:      	add	x8, sp, #0x120
    12e8:      	ldr	w1, [sp, #0x330]
    12ec:      	str	x0, [sp, #0x230]
    12f0:      	mov	x0, x24
    12f4:      	bl	0x12f4 <_stogir.verify.integer-operations-target-structured+0x6a4>
		00000000000012f4:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    12f8:      	add	x16, sp, #0x120
    12fc:      	ldr	w0, [x16]
    1300:      	lsr	x16, x0, #0
    1304:      	cmp	x16, #0x1
    1308:      	b.eq	0x1328 <_stogir.verify.integer-operations-target-structured+0x6d8>
    130c:      	b.lo	0x1314 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1310:      	b	0x132c <_stogir.verify.integer-operations-target-structured+0x6dc>
    1314:      	cmp	x16, #0x0
    1318:      	b.eq	0x1320 <_stogir.verify.integer-operations-target-structured+0x6d0>
    131c:      	b	0x132c <_stogir.verify.integer-operations-target-structured+0x6dc>
    1320:      	ldr	x0, [sp, #0x238]
    1324:      	b	0x19bc <_stogir.verify.integer-operations-target-structured+0xd6c>
    1328:      	b	0x1330 <_stogir.verify.integer-operations-target-structured+0x6e0>
    132c:      	b	0x19c8 <_stogir.verify.integer-operations-target-structured+0xd78>
    1330:      	add	x16, sp, #0x120
    1334:      	ldr	x19, [x16, #0x8]
    1338:      	ldr	x0, [sp, #0x238]
    133c:      	ldr	x22, [x0, #0x8]
    1340:      	and	w1, w23, #0x100
    1344:      	ubfx	x1, x1, #0, #32
    1348:      	cmp	x1, #0x0
    134c:      	b.ne	0x19d0 <_stogir.verify.integer-operations-target-structured+0xd80>
    1350:      	movz	x1, #0x0, lsl #48
    1354:      	cmp	x1, #0x0
    1358:      	b.eq	0x1ef8 <_stogir.verify.integer-operations-target-structured+0x12a8>
    135c:      	add	x8, sp, #0x140
    1360:      	ldr	w1, [sp, #0x330]
    1364:      	ldr	w2, [sp, #0x2c8]
    1368:      	str	x0, [sp, #0x238]
    136c:      	mov	x0, x24
    1370:      	bl	0x1370 <_stogir.verify.integer-operations-target-structured+0x720>
		0000000000001370:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1374:      	add	x16, sp, #0x140
    1378:      	ldr	w0, [x16]
    137c:      	lsr	x16, x0, #0
    1380:      	cmp	x16, #0x1
    1384:      	b.eq	0x13a4 <_stogir.verify.integer-operations-target-structured+0x754>
    1388:      	b.lo	0x1390 <_stogir.verify.integer-operations-target-structured+0x740>
    138c:      	b	0x13a8 <_stogir.verify.integer-operations-target-structured+0x758>
    1390:      	cmp	x16, #0x0
    1394:      	b.eq	0x139c <_stogir.verify.integer-operations-target-structured+0x74c>
    1398:      	b	0x13a8 <_stogir.verify.integer-operations-target-structured+0x758>
    139c:      	ldr	x0, [sp, #0x240]
    13a0:      	b	0x19d8 <_stogir.verify.integer-operations-target-structured+0xd88>
    13a4:      	b	0x13ac <_stogir.verify.integer-operations-target-structured+0x75c>
    13a8:      	b	0x19e4 <_stogir.verify.integer-operations-target-structured+0xd94>
    13ac:      	add	x16, sp, #0x140
    13b0:      	ldr	x19, [x16, #0x8]
    13b4:      	ldr	x0, [sp, #0x240]
    13b8:      	ldr	x22, [x0, #0x8]
    13bc:      	and	w1, w23, #0x200
    13c0:      	ubfx	x1, x1, #0, #32
    13c4:      	cmp	x1, #0x0
    13c8:      	b.ne	0x19ec <_stogir.verify.integer-operations-target-structured+0xd9c>
    13cc:      	movz	x1, #0x0, lsl #48
    13d0:      	cmp	x1, #0x0
    13d4:      	b.eq	0x1f04 <_stogir.verify.integer-operations-target-structured+0x12b4>
    13d8:      	add	x8, sp, #0x160
    13dc:      	ldr	w1, [sp, #0x330]
    13e0:      	ldr	w2, [sp, #0x2d0]
    13e4:      	str	x0, [sp, #0x240]
    13e8:      	mov	x0, x24
    13ec:      	bl	0x13ec <_stogir.verify.integer-operations-target-structured+0x79c>
		00000000000013ec:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    13f0:      	add	x16, sp, #0x160
    13f4:      	ldr	w0, [x16]
    13f8:      	lsr	x16, x0, #0
    13fc:      	cmp	x16, #0x1
    1400:      	b.eq	0x1420 <_stogir.verify.integer-operations-target-structured+0x7d0>
    1404:      	b.lo	0x140c <_stogir.verify.integer-operations-target-structured+0x7bc>
    1408:      	b	0x1424 <_stogir.verify.integer-operations-target-structured+0x7d4>
    140c:      	cmp	x16, #0x0
    1410:      	b.eq	0x1418 <_stogir.verify.integer-operations-target-structured+0x7c8>
    1414:      	b	0x1424 <_stogir.verify.integer-operations-target-structured+0x7d4>
    1418:      	ldr	x0, [sp, #0x248]
    141c:      	b	0x19f4 <_stogir.verify.integer-operations-target-structured+0xda4>
    1420:      	b	0x1428 <_stogir.verify.integer-operations-target-structured+0x7d8>
    1424:      	b	0x1a00 <_stogir.verify.integer-operations-target-structured+0xdb0>
    1428:      	add	x16, sp, #0x160
    142c:      	ldr	x19, [x16, #0x8]
    1430:      	ldr	x0, [sp, #0x248]
    1434:      	ldr	x22, [x0, #0x8]
    1438:      	cmp	x20, #0x3c
    143c:      	b.ne	0x1f10 <_stogir.verify.integer-operations-target-structured+0x12c0>
    1440:      	add	x8, sp, #0x180
    1444:      	ldr	w1, [sp, #0x330]
    1448:      	str	x0, [sp, #0x248]
    144c:      	mov	x0, x24
    1450:      	bl	0x1450 <_stogir.verify.integer-operations-target-structured+0x800>
		0000000000001450:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    1454:      	add	x16, sp, #0x180
    1458:      	ldr	w0, [x16]
    145c:      	lsr	x16, x0, #0
    1460:      	cmp	x16, #0x1
    1464:      	b.eq	0x1484 <_stogir.verify.integer-operations-target-structured+0x834>
    1468:      	b.lo	0x1470 <_stogir.verify.integer-operations-target-structured+0x820>
    146c:      	b	0x1488 <_stogir.verify.integer-operations-target-structured+0x838>
    1470:      	cmp	x16, #0x0
    1474:      	b.eq	0x147c <_stogir.verify.integer-operations-target-structured+0x82c>
    1478:      	b	0x1488 <_stogir.verify.integer-operations-target-structured+0x838>
    147c:      	ldr	x0, [sp, #0x250]
    1480:      	b	0x1a08 <_stogir.verify.integer-operations-target-structured+0xdb8>
    1484:      	b	0x148c <_stogir.verify.integer-operations-target-structured+0x83c>
    1488:      	b	0x1a14 <_stogir.verify.integer-operations-target-structured+0xdc4>
    148c:      	add	x16, sp, #0x180
    1490:      	ldr	x19, [x16, #0x8]
    1494:      	ldr	x0, [sp, #0x250]
    1498:      	ldr	x22, [x0, #0x8]
    149c:      	cmp	x20, #0x78
    14a0:      	b.ne	0x1f1c <_stogir.verify.integer-operations-target-structured+0x12cc>
    14a4:      	str	x0, [sp, #0x250]
    14a8:      	ldr	x0, [sp, #0x2d8]
    14ac:      	bl	0x14ac <_stogir.verify.integer-operations-target-structured+0x85c>
		00000000000014ac:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    14b0:      	uxtb	w0, w0
    14b4:      	cmp	x0, #0x0
    14b8:      	b.ne	0x1a24 <_stogir.verify.integer-operations-target-structured+0xdd4>
    14bc:      	add	x16, sp, #0x20
    14c0:      	ldr	w0, [x16, #0x8]
    14c4:      	sxtw	x0, w0
    14c8:      	cmp	x0, #0x0
    14cc:      	b.ne	0x1a1c <_stogir.verify.integer-operations-target-structured+0xdcc>
    14d0:      	movz	x0, #0x0, lsl #48
    14d4:      	cmp	x0, #0x0
    14d8:      	b.eq	0x14e4 <_stogir.verify.integer-operations-target-structured+0x894>
    14dc:      	ldr	x19, [sp, #0x278]
    14e0:      	mov	x22, #0x1f              ; =31
    14e4:      	str	x24, [sp, #0x220]
    14e8:      	add	x0, x21, #0x1
    14ec:      	sxtw	x21, w0
    14f0:      	ldr	x0, [sp, #0x340]
    14f4:      	uxth	w0, w0
    14f8:      	mov	w17, #0x8               ; =8
    14fc:      	uxth	w16, w0
    1500:      	ubfx	w17, w17, #0, #4
    1504:      	lsr	w0, w16, w17
    1508:      	uxth	w0, w0
    150c:      	uxtb	w0, w0
    1510:      	orr	x24, x0, xzr
    1514:      	cmp	x24, #0x0
    1518:      	b.eq	0x1f28 <_stogir.verify.integer-operations-target-structured+0x12d8>
    151c:      	add	x8, sp, #0x1e0
    1520:      	ldr	x0, [sp, #0x220]
    1524:      	ldr	w1, [sp, #0x330]
    1528:      	bl	0x1528 <_stogir.verify.integer-operations-target-structured+0x8d8>
		0000000000001528:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    152c:      	add	x16, sp, #0x1e0
    1530:      	ldr	w0, [x16]
    1534:      	lsr	x16, x0, #0
    1538:      	cmp	x16, #0x1
    153c:      	b.eq	0x155c <_stogir.verify.integer-operations-target-structured+0x90c>
    1540:      	b.lo	0x1548 <_stogir.verify.integer-operations-target-structured+0x8f8>
    1544:      	b	0x1560 <_stogir.verify.integer-operations-target-structured+0x910>
    1548:      	cmp	x16, #0x0
    154c:      	b.eq	0x1554 <_stogir.verify.integer-operations-target-structured+0x904>
    1550:      	b	0x1560 <_stogir.verify.integer-operations-target-structured+0x910>
    1554:      	ldr	x0, [sp, #0x300]
    1558:      	b	0x1ae0 <_stogir.verify.integer-operations-target-structured+0xe90>
    155c:      	b	0x1564 <_stogir.verify.integer-operations-target-structured+0x914>
    1560:      	b	0x1aec <_stogir.verify.integer-operations-target-structured+0xe9c>
    1564:      	add	x16, sp, #0x1e0
    1568:      	ldr	x19, [x16, #0x8]
    156c:      	ldr	x0, [sp, #0x300]
    1570:      	ldr	x22, [x0, #0x8]
    1574:      	uxtb	w16, w25
    1578:      	cmp	w16, wzr
    157c:      	b.eq	0x1af4 <_stogir.verify.integer-operations-target-structured+0xea4>
    1580:      	movz	x1, #0x0, lsl #48
    1584:      	and	w2, w23, #0x1
    1588:      	and	w3, w23, #0x2
    158c:      	ubfx	x2, x2, #0, #32
    1590:      	ubfx	x3, x3, #0, #32
    1594:      	cmp	x2, #0x0
    1598:      	cset	w2, eq
    159c:      	cmp	x3, #0x0
    15a0:      	cset	w3, eq
    15a4:      	uxtb	w16, w2
    15a8:      	cmp	w16, wzr
    15ac:      	cset	x23, eq
    15b0:      	uxtb	w16, w3
    15b4:      	cmp	w16, wzr
    15b8:      	cset	x25, eq
    15bc:      	cmp	x1, #0x0
    15c0:      	b.eq	0x1f30 <_stogir.verify.integer-operations-target-structured+0x12e0>
    15c4:      	cmp	x24, #0x0
    15c8:      	b.eq	0x1afc <_stogir.verify.integer-operations-target-structured+0xeac>
    15cc:      	movz	x1, #0x0, lsl #48
    15d0:      	cmp	x1, #0x0
    15d4:      	b.eq	0x1f38 <_stogir.verify.integer-operations-target-structured+0x12e8>
    15d8:      	ldr	x24, [sp, #0x328]
    15dc:      	cmp	x24, #0x0
    15e0:      	b.eq	0x1b04 <_stogir.verify.integer-operations-target-structured+0xeb4>
    15e4:      	mov	x1, #0x1                ; =1
    15e8:      	cmp	x1, #0x0
    15ec:      	b.eq	0x1f40 <_stogir.verify.integer-operations-target-structured+0x12f0>
    15f0:      	add	x16, sp, #0x200
    15f4:      	str	x16, [sp]
    15f8:      	ldr	w1, [sp, #0x330]
    15fc:      	str	x0, [sp, #0x300]
    1600:      	ldr	x0, [sp, #0x220]
    1604:      	mov	x2, #0x1                ; =1
    1608:      	bl	0x1608 <_stogir.verify.integer-operations-target-structured+0x9b8>
		0000000000001608:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    160c:      	ldr	x16, [sp]
    1610:      	str	x0, [x16]
    1614:      	str	x1, [x16, #0x8]
    1618:      	add	x16, sp, #0x200
    161c:      	ldr	x0, [x16]
    1620:      	add	x16, sp, #0x200
    1624:      	ldr	x1, [x16, #0x8]
    1628:      	ubfx	x0, x0, #0, #32
    162c:      	lsr	x16, x0, #0
    1630:      	cmp	x16, #0x1
    1634:      	b.eq	0x1650 <_stogir.verify.integer-operations-target-structured+0xa00>
    1638:      	b.lo	0x1640 <_stogir.verify.integer-operations-target-structured+0x9f0>
    163c:      	b	0x1654 <_stogir.verify.integer-operations-target-structured+0xa04>
    1640:      	cmp	x16, #0x0
    1644:      	b.eq	0x164c <_stogir.verify.integer-operations-target-structured+0x9fc>
    1648:      	b	0x1654 <_stogir.verify.integer-operations-target-structured+0xa04>
    164c:      	b	0x1658 <_stogir.verify.integer-operations-target-structured+0xa08>
    1650:      	b	0x1b2c <_stogir.verify.integer-operations-target-structured+0xedc>
    1654:      	b	0x1e38 <_stogir.verify.integer-operations-target-structured+0x11e8>
    1658:      	str	x26, [sp, #0x350]
    165c:      	str	x27, [sp, #0x360]
    1660:      	ldr	x19, [sp, #0x298]
    1664:      	mov	x22, #0x17              ; =23
    1668:      	add	x0, x21, #0x1
    166c:      	sxtw	x21, w0
    1670:      	ldr	w0, [sp, #0x318]
    1674:      	sxtw	x0, w0
    1678:      	add	x0, x0, #0x4
    167c:      	asr	x16, x0, #63
    1680:      	lsr	x16, x16, #62
    1684:      	add	x0, x0, x16
    1688:      	asr	x0, x0, #2
    168c:      	ldr	x1, [sp, #0x310]
    1690:      	add	x1, x0, x1
    1694:      	ldr	x8, [sp, #0x2b8]
    1698:      	ldr	x11, [sp, #0x2d8]
    169c:      	ldr	x14, [sp, #0x2f0]
    16a0:      	ldr	x23, [sp, #0x280]
    16a4:      	ldr	x24, [sp, #0x288]
    16a8:      	ldr	x25, [sp, #0x298]
    16ac:      	ldr	x26, [sp, #0x2a0]
    16b0:      	ldr	x27, [sp, #0x2a8]
    16b4:      	ldr	x2, [sp, #0x290]
    16b8:      	ldr	w9, [sp, #0x2c0]
    16bc:      	ldr	x12, [sp, #0x350]
    16c0:      	ldr	x13, [sp, #0x348]
    16c4:      	ldr	x15, [sp, #0x2f8]
    16c8:      	ldr	w10, [sp, #0x2c8]
    16cc:      	ldr	x0, [sp, #0x300]
    16d0:      	ldr	x3, [sp, #0x308]
    16d4:      	ldr	x4, [sp, #0x2e0]
    16d8:      	ldr	x5, [sp, #0x360]
    16dc:      	mov	x6, x28
    16e0:      	ldr	x28, [sp, #0x2b0]
    16e4:      	ldr	x7, [sp, #0x2e8]
    16e8:      	mov	x20, x1
    16ec:      	ldr	w1, [sp, #0x2d0]
    16f0:      	b	0xe10 <_stogir.verify.integer-operations-target-structured+0x1c0>
    16f4:      	movz	w3, #0x0, lsl #16
    16f8:      	b	0xed0 <_stogir.verify.integer-operations-target-structured+0x280>
    16fc:      	movz	x4, #0x0, lsl #48
    1700:      	b	0xee4 <_stogir.verify.integer-operations-target-structured+0x294>
    1704:      	add	x8, sp, #0x30
    1708:      	ldr	w2, [sp, #0x2c0]
    170c:      	str	x0, [sp, #0x340]
    1710:      	mov	x0, x24
    1714:      	mov	w25, w1
    1718:      	ldr	w1, [sp, #0x330]
    171c:      	bl	0x171c <_stogir.verify.integer-operations-target-structured+0xacc>
		000000000000171c:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    1720:      	add	x16, sp, #0x30
    1724:      	ldr	w0, [x16]
    1728:      	lsr	x16, x0, #0
    172c:      	cmp	x16, #0x1
    1730:      	b.eq	0x174c <_stogir.verify.integer-operations-target-structured+0xafc>
    1734:      	b.lo	0x173c <_stogir.verify.integer-operations-target-structured+0xaec>
    1738:      	b	0x1750 <_stogir.verify.integer-operations-target-structured+0xb00>
    173c:      	cmp	x16, #0x0
    1740:      	b.eq	0x1748 <_stogir.verify.integer-operations-target-structured+0xaf8>
    1744:      	b	0x1750 <_stogir.verify.integer-operations-target-structured+0xb00>
    1748:      	b	0x1764 <_stogir.verify.integer-operations-target-structured+0xb14>
    174c:      	b	0x1754 <_stogir.verify.integer-operations-target-structured+0xb04>
    1750:      	b	0x1e40 <_stogir.verify.integer-operations-target-structured+0x11f0>
    1754:      	add	x16, sp, #0x30
    1758:      	ldr	x19, [x16, #0x8]
    175c:      	ldr	x22, [x26, #0x8]
    1760:      	b	0xf50 <_stogir.verify.integer-operations-target-structured+0x300>
    1764:      	add	x0, x21, #0x1
    1768:      	sxtw	x21, w0
    176c:      	b	0x1760 <_stogir.verify.integer-operations-target-structured+0xb10>
    1770:      	mov	x0, #0x1                ; =1
    1774:      	b	0xf68 <_stogir.verify.integer-operations-target-structured+0x318>
    1778:      	movz	x0, #0x0, lsl #48
    177c:      	b	0xf68 <_stogir.verify.integer-operations-target-structured+0x318>
    1780:      	add	x0, x21, #0x1
    1784:      	sxtw	x21, w0
    1788:      	b	0xfc0 <_stogir.verify.integer-operations-target-structured+0x370>
    178c:      	brk	#0
    1790:      	b	0x178c <_stogir.verify.integer-operations-target-structured+0xb3c>
    1794:      	cmp	x20, #0x1e
    1798:      	cset	w0, eq
    179c:      	ubfx	x0, x0, #0, #8
    17a0:      	b	0xfcc <_stogir.verify.integer-operations-target-structured+0x37c>
    17a4:      	mov	x0, #0x1                ; =1
    17a8:      	b	0xfec <_stogir.verify.integer-operations-target-structured+0x39c>
    17ac:      	movz	x0, #0x0, lsl #48
    17b0:      	b	0xfec <_stogir.verify.integer-operations-target-structured+0x39c>
    17b4:      	movz	x2, #0x0, lsl #48
    17b8:      	b	0x1054 <_stogir.verify.integer-operations-target-structured+0x404>
    17bc:      	movz	x2, #0x0, lsl #48
    17c0:      	b	0x1054 <_stogir.verify.integer-operations-target-structured+0x404>
    17c4:      	cmp	x0, #0x0
    17c8:      	b.ge	0x1f50 <_stogir.verify.integer-operations-target-structured+0x1300>
    17cc:      	ldr	x4, [x28, #0x8]
    17d0:      	ldr	x5, [sp, #0x2e8]
    17d4:      	ldr	x6, [x5, #0x8]
    17d8:      	cmp	x4, x6
    17dc:      	b.ne	0x1810 <_stogir.verify.integer-operations-target-structured+0xbc0>
    17e0:      	cmp	x2, x4
    17e4:      	b.gt	0x1808 <_stogir.verify.integer-operations-target-structured+0xbb8>
    17e8:      	ldr	x2, [x24, #0x50]
    17ec:      	add	x2, x2, x3, lsl #2
    17f0:      	ldr	w2, [x2]
    17f4:      	sxtw	x2, w2
    17f8:      	cmp	x2, #0x0
    17fc:      	cset	w2, gt
    1800:      	ubfx	x2, x2, #0, #8
    1804:      	b	0x1058 <_stogir.verify.integer-operations-target-structured+0x408>
    1808:      	movz	x2, #0x0, lsl #48
    180c:      	b	0x1804 <_stogir.verify.integer-operations-target-structured+0xbb4>
    1810:      	movz	x2, #0x0, lsl #48
    1814:      	b	0x1804 <_stogir.verify.integer-operations-target-structured+0xbb4>
    1818:      	movz	x2, #0x0, lsl #48
    181c:      	b	0x1804 <_stogir.verify.integer-operations-target-structured+0xbb4>
    1820:      	ldr	x0, [x24, #0x28]
    1824:      	add	x0, x0, x3, lsl #4
    1828:      	ldr	x1, [x0]
    182c:      	ldr	x0, [x0, #0x8]
    1830:      	b	0x107c <_stogir.verify.integer-operations-target-structured+0x42c>
    1834:      	movz	w2, #0x0, lsl #16
    1838:      	movz	x1, #0x0, lsl #48
    183c:      	movz	x0, #0x0, lsl #48
    1840:      	b	0x1080 <_stogir.verify.integer-operations-target-structured+0x430>
    1844:      	add	x16, sp, #0x70
    1848:      	str	x1, [x16]
    184c:      	add	x16, sp, #0x70
    1850:      	str	x0, [x16, #0x8]
    1854:      	add	x16, sp, #0x20
    1858:      	ldr	w0, [x16, #0xc]
    185c:      	sxtw	x0, w0
    1860:      	cmp	x0, #0x0
    1864:      	b.ge	0x1878 <_stogir.verify.integer-operations-target-structured+0xc28>
    1868:      	str	x5, [sp, #0x2e8]
    186c:      	ldr	x19, [sp, #0x270]
    1870:      	mov	x22, #0x2d              ; =45
    1874:      	b	0x10bc <_stogir.verify.integer-operations-target-structured+0x46c>
    1878:      	ldr	x0, [sp, #0x2f0]
    187c:      	str	x5, [sp, #0x2e8]
    1880:      	bl	0x1880 <_stogir.verify.integer-operations-target-structured+0xc30>
		0000000000001880:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    1884:      	uxtb	w0, w0
    1888:      	cmp	x0, #0x83
    188c:      	b.ge	0x1f58 <_stogir.verify.integer-operations-target-structured+0x1308>
    1890:      	ldr	x1, [sp, #0x2e0]
    1894:      	add	x0, x0, x1
    1898:      	ldrb	w0, [x0]
    189c:      	uxtb	w16, w0
    18a0:      	and	w0, w16, #0x2
    18a4:      	uxtb	w0, w0
    18a8:      	ubfx	x0, x0, #0, #8
    18ac:      	cmp	x0, #0x0
    18b0:      	cset	w0, eq
    18b4:      	uxtb	w16, w0
    18b8:      	cmp	w16, wzr
    18bc:      	cset	x0, eq
    18c0:      	cmp	x0, #0x0
    18c4:      	b.eq	0x18d8 <_stogir.verify.integer-operations-target-structured+0xc88>
    18c8:      	str	x1, [sp, #0x2e0]
    18cc:      	b	0x1874 <_stogir.verify.integer-operations-target-structured+0xc24>
    18d0:      	movz	w0, #0x0, lsl #16
    18d4:      	b	0x189c <_stogir.verify.integer-operations-target-structured+0xc4c>
    18d8:      	ldr	x0, [sp, #0x2f0]
    18dc:      	str	x1, [sp, #0x2e0]
    18e0:      	bl	0x18e0 <_stogir.verify.integer-operations-target-structured+0xc90>
		00000000000018e0:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    18e4:      	uxtb	w0, w0
    18e8:      	cmp	x0, #0x65
    18ec:      	b.eq	0x1874 <_stogir.verify.integer-operations-target-structured+0xc24>
    18f0:      	ldr	x0, [sp, #0x2f0]
    18f4:      	bl	0x18f4 <_stogir.verify.integer-operations-target-structured+0xca4>
		00000000000018f4:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    18f8:      	uxtb	w0, w0
    18fc:      	cmp	x0, #0x66
    1900:      	b.eq	0x1874 <_stogir.verify.integer-operations-target-structured+0xc24>
    1904:      	b	0x186c <_stogir.verify.integer-operations-target-structured+0xc1c>
    1908:      	brk	#0
    190c:      	b	0x1908 <_stogir.verify.integer-operations-target-structured+0xcb8>
    1910:      	mov	x1, #0x1                ; =1
    1914:      	b	0x10d4 <_stogir.verify.integer-operations-target-structured+0x484>
    1918:      	ubfx	x1, x2, #0, #8
    191c:      	b	0x10e8 <_stogir.verify.integer-operations-target-structured+0x498>
    1920:      	add	x8, sp, #0xa0
    1924:      	mov	x0, x24
    1928:      	ldr	w1, [sp, #0x330]
    192c:      	bl	0x192c <_stogir.verify.integer-operations-target-structured+0xcdc>
		000000000000192c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1930:      	add	x16, sp, #0xa0
    1934:      	ldr	x0, [x16]
    1938:      	add	x16, sp, #0xa0
    193c:      	ldr	x1, [x16, #0x8]
    1940:      	add	x16, sp, #0xa0
    1944:      	ldr	x2, [x16, #0x10]
    1948:      	b	0x112c <_stogir.verify.integer-operations-target-structured+0x4dc>
    194c:      	add	x0, x21, #0x1
    1950:      	sxtw	x21, w0
    1954:      	b	0x1164 <_stogir.verify.integer-operations-target-structured+0x514>
    1958:      	brk	#0
    195c:      	b	0x1958 <_stogir.verify.integer-operations-target-structured+0xd08>
    1960:      	mov	x0, #0x1                ; =1
    1964:      	b	0x1178 <_stogir.verify.integer-operations-target-structured+0x528>
    1968:      	add	x1, x21, #0x1
    196c:      	sxtw	x21, w1
    1970:      	b	0x11d8 <_stogir.verify.integer-operations-target-structured+0x588>
    1974:      	brk	#0
    1978:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xd24>
    197c:      	mov	x1, #0x1                ; =1
    1980:      	b	0x11ec <_stogir.verify.integer-operations-target-structured+0x59c>
    1984:      	add	x1, x21, #0x1
    1988:      	sxtw	x21, w1
    198c:      	b	0x1250 <_stogir.verify.integer-operations-target-structured+0x600>
    1990:      	brk	#0
    1994:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xd40>
    1998:      	mov	x1, #0x1                ; =1
    199c:      	b	0x1264 <_stogir.verify.integer-operations-target-structured+0x614>
    19a0:      	add	x1, x21, #0x1
    19a4:      	sxtw	x21, w1
    19a8:      	b	0x12c8 <_stogir.verify.integer-operations-target-structured+0x678>
    19ac:      	brk	#0
    19b0:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xd5c>
    19b4:      	mov	x1, #0x1                ; =1
    19b8:      	b	0x12dc <_stogir.verify.integer-operations-target-structured+0x68c>
    19bc:      	add	x1, x21, #0x1
    19c0:      	sxtw	x21, w1
    19c4:      	b	0x1340 <_stogir.verify.integer-operations-target-structured+0x6f0>
    19c8:      	brk	#0
    19cc:      	b	0x19c8 <_stogir.verify.integer-operations-target-structured+0xd78>
    19d0:      	mov	x1, #0x1                ; =1
    19d4:      	b	0x1354 <_stogir.verify.integer-operations-target-structured+0x704>
    19d8:      	add	x1, x21, #0x1
    19dc:      	sxtw	x21, w1
    19e0:      	b	0x13bc <_stogir.verify.integer-operations-target-structured+0x76c>
    19e4:      	brk	#0
    19e8:      	b	0x19e4 <_stogir.verify.integer-operations-target-structured+0xd94>
    19ec:      	mov	x1, #0x1                ; =1
    19f0:      	b	0x13d0 <_stogir.verify.integer-operations-target-structured+0x780>
    19f4:      	add	x1, x21, #0x1
    19f8:      	sxtw	x21, w1
    19fc:      	b	0x1438 <_stogir.verify.integer-operations-target-structured+0x7e8>
    1a00:      	brk	#0
    1a04:      	b	0x1a00 <_stogir.verify.integer-operations-target-structured+0xdb0>
    1a08:      	add	x1, x21, #0x1
    1a0c:      	sxtw	x21, w1
    1a10:      	b	0x149c <_stogir.verify.integer-operations-target-structured+0x84c>
    1a14:      	brk	#0
    1a18:      	b	0x1a14 <_stogir.verify.integer-operations-target-structured+0xdc4>
    1a1c:      	mov	x0, #0x1                ; =1
    1a20:      	b	0x14d4 <_stogir.verify.integer-operations-target-structured+0x884>
    1a24:      	add	x16, sp, #0x20
    1a28:      	ldr	w0, [x16, #0x8]
    1a2c:      	add	x8, sp, #0x1a0
    1a30:      	mov	w1, w0
    1a34:      	mov	x0, x24
    1a38:      	bl	0x1a38 <_stogir.verify.integer-operations-target-structured+0xde8>
		0000000000001a38:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1a3c:      	add	x16, sp, #0x1a0
    1a40:      	ldr	w0, [x16]
    1a44:      	lsr	x16, x0, #0
    1a48:      	cmp	x16, #0x1
    1a4c:      	b.eq	0x1a68 <_stogir.verify.integer-operations-target-structured+0xe18>
    1a50:      	b.lo	0x1a58 <_stogir.verify.integer-operations-target-structured+0xe08>
    1a54:      	b	0x1a6c <_stogir.verify.integer-operations-target-structured+0xe1c>
    1a58:      	cmp	x16, #0x0
    1a5c:      	b.eq	0x1a64 <_stogir.verify.integer-operations-target-structured+0xe14>
    1a60:      	b	0x1a6c <_stogir.verify.integer-operations-target-structured+0xe1c>
    1a64:      	b	0x1a70 <_stogir.verify.integer-operations-target-structured+0xe20>
    1a68:      	b	0x1a80 <_stogir.verify.integer-operations-target-structured+0xe30>
    1a6c:      	b	0x1ad8 <_stogir.verify.integer-operations-target-structured+0xe88>
    1a70:      	str	x24, [sp, #0x220]
    1a74:      	ldr	x19, [sp, #0x280]
    1a78:      	mov	x22, #0x14              ; =20
    1a7c:      	b	0x14e8 <_stogir.verify.integer-operations-target-structured+0x898>
    1a80:      	add	x16, sp, #0x1a0
    1a84:      	ldr	x0, [x16, #0x8]
    1a88:      	add	x16, sp, #0x1d0
    1a8c:      	str	x0, [x16]
    1a90:      	ldr	x0, [sp, #0x260]
    1a94:      	ldr	x1, [x0, #0x8]
    1a98:      	add	x16, sp, #0x1d0
    1a9c:      	str	x1, [x16, #0x8]
    1aa0:      	str	x0, [sp, #0x260]
    1aa4:      	ldr	x0, [sp, #0x268]
    1aa8:      	bl	0x1aa8 <_stogir.verify.integer-operations-target-structured+0xe58>
		0000000000001aa8:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    1aac:      	uxtb	w0, w0
    1ab0:      	str	x24, [sp, #0x220]
    1ab4:      	mov	w24, w0
    1ab8:      	ldr	x0, [sp, #0x2d8]
    1abc:      	bl	0x1abc <_stogir.verify.integer-operations-target-structured+0xe6c>
		0000000000001abc:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    1ac0:      	uxtb	w0, w0
    1ac4:      	cmp	x24, x0
    1ac8:      	b.eq	0x1ad4 <_stogir.verify.integer-operations-target-structured+0xe84>
    1acc:      	ldr	x19, [sp, #0x288]
    1ad0:      	mov	x22, #0x1a              ; =26
    1ad4:      	b	0x1a7c <_stogir.verify.integer-operations-target-structured+0xe2c>
    1ad8:      	brk	#0
    1adc:      	b	0x1ad8 <_stogir.verify.integer-operations-target-structured+0xe88>
    1ae0:      	add	x1, x21, #0x1
    1ae4:      	sxtw	x21, w1
    1ae8:      	b	0x1574 <_stogir.verify.integer-operations-target-structured+0x924>
    1aec:      	brk	#0
    1af0:      	b	0x1aec <_stogir.verify.integer-operations-target-structured+0xe9c>
    1af4:      	mov	x1, #0x1                ; =1
    1af8:      	b	0x1584 <_stogir.verify.integer-operations-target-structured+0x934>
    1afc:      	mov	x1, #0x1                ; =1
    1b00:      	b	0x15d0 <_stogir.verify.integer-operations-target-structured+0x980>
    1b04:      	cmp	x23, #0x0
    1b08:      	b.eq	0x1b14 <_stogir.verify.integer-operations-target-structured+0xec4>
    1b0c:      	mov	x1, #0x1                ; =1
    1b10:      	b	0x15e8 <_stogir.verify.integer-operations-target-structured+0x998>
    1b14:      	mov	x1, x25
    1b18:      	b	0x1b10 <_stogir.verify.integer-operations-target-structured+0xec0>
    1b1c:      	movz	x1, #0x0, lsl #48
    1b20:      	b	0x15e8 <_stogir.verify.integer-operations-target-structured+0x998>
    1b24:      	movz	x1, #0x0, lsl #48
    1b28:      	b	0x15e8 <_stogir.verify.integer-operations-target-structured+0x998>
    1b2c:      	ldr	x0, [sp, #0x220]
    1b30:      	bl	0x1b30 <_stogir.verify.integer-operations-target-structured+0xee0>
		0000000000001b30:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1b34:      	cmp	x0, #0x0
    1b38:      	b.ne	0x1b50 <_stogir.verify.integer-operations-target-structured+0xf00>
    1b3c:      	str	x26, [sp, #0x350]
    1b40:      	str	x27, [sp, #0x360]
    1b44:      	ldr	x19, [sp, #0x298]
    1b48:      	mov	x22, #0x17              ; =23
    1b4c:      	b	0x1668 <_stogir.verify.integer-operations-target-structured+0xa18>
    1b50:      	bl	0x1b50 <_stogir.verify.integer-operations-target-structured+0xf00>
		0000000000001b50:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    1b54:      	uxtb	w0, w0
    1b58:      	str	x26, [sp, #0x350]
    1b5c:      	mov	w26, w0
    1b60:      	ldr	x0, [sp, #0x2d8]
    1b64:      	bl	0x1b64 <_stogir.verify.integer-operations-target-structured+0xf14>
		0000000000001b64:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    1b68:      	orr	x1, x26, xzr
    1b6c:      	uxtb	w0, w0
    1b70:      	cmp	x0, #0x6
    1b74:      	b.ne	0x1c94 <_stogir.verify.integer-operations-target-structured+0x1044>
    1b78:      	cmp	x1, #0x6
    1b7c:      	b.ne	0x1c8c <_stogir.verify.integer-operations-target-structured+0x103c>
    1b80:      	cmp	x20, #0x1a
    1b84:      	b.ne	0x1c7c <_stogir.verify.integer-operations-target-structured+0x102c>
    1b88:      	mov	x0, #0x1                ; =1
    1b8c:      	str	w26, [sp, #0x358]
    1b90:      	str	x27, [sp, #0x360]
    1b94:      	mov	x27, x0
    1b98:      	mov	w0, w26
    1b9c:      	mov	x26, x1
    1ba0:      	bl	0x1ba0 <_stogir.verify.integer-operations-target-structured+0xf50>
		0000000000001ba0:  ARM64_RELOC_BRANCH26	_stogir.types.integer?
    1ba4:      	cmp	x0, #0x0
    1ba8:      	b.eq	0x1c9c <_stogir.verify.integer-operations-target-structured+0x104c>
    1bac:      	movz	x0, #0x0, lsl #48
    1bb0:      	cmp	x0, #0x0
    1bb4:      	b.eq	0x1ca4 <_stogir.verify.integer-operations-target-structured+0x1054>
    1bb8:      	mov	x0, #0x1                ; =1
    1bbc:      	cmp	x0, #0x0
    1bc0:      	b.eq	0x1bcc <_stogir.verify.integer-operations-target-structured+0xf7c>
    1bc4:      	ldr	x19, [sp, #0x2a0]
    1bc8:      	mov	x22, #0x1c              ; =28
    1bcc:      	ldr	x0, [sp, #0x2d8]
    1bd0:      	bl	0x1bd0 <_stogir.verify.integer-operations-target-structured+0xf80>
		0000000000001bd0:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    1bd4:      	cmp	x24, #0x0
    1bd8:      	b.eq	0x1da0 <_stogir.verify.integer-operations-target-structured+0x1150>
    1bdc:      	mov	x1, #0x1                ; =1
    1be0:      	uxtb	w0, w0
    1be4:      	sxtw	x1, w1
    1be8:      	cmp	x0, x1
    1bec:      	b.eq	0x1bf8 <_stogir.verify.integer-operations-target-structured+0xfa8>
    1bf0:      	ldr	x19, [sp, #0x2a8]
    1bf4:      	mov	x22, #0x26              ; =38
    1bf8:      	cmp	x24, #0x0
    1bfc:      	b.eq	0x1c04 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1c00:      	mov	x23, #0x1               ; =1
    1c04:      	cmp	x23, #0x0
    1c08:      	b.eq	0x1c78 <_stogir.verify.integer-operations-target-structured+0x1028>
    1c0c:      	add	x16, sp, #0x210
    1c10:      	str	x16, [sp]
    1c14:      	ldr	x0, [sp, #0x220]
    1c18:      	ldr	w1, [sp, #0x330]
    1c1c:      	mov	x2, #0x2                ; =2
    1c20:      	bl	0x1c20 <_stogir.verify.integer-operations-target-structured+0xfd0>
		0000000000001c20:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1c24:      	ldr	x16, [sp]
    1c28:      	str	x0, [x16]
    1c2c:      	str	x1, [x16, #0x8]
    1c30:      	add	x16, sp, #0x210
    1c34:      	ldr	x0, [x16]
    1c38:      	add	x16, sp, #0x210
    1c3c:      	ldr	x1, [x16, #0x8]
    1c40:      	ubfx	x0, x0, #0, #32
    1c44:      	lsr	x16, x0, #0
    1c48:      	cmp	x16, #0x1
    1c4c:      	b.eq	0x1c68 <_stogir.verify.integer-operations-target-structured+0x1018>
    1c50:      	b.lo	0x1c58 <_stogir.verify.integer-operations-target-structured+0x1008>
    1c54:      	b	0x1c6c <_stogir.verify.integer-operations-target-structured+0x101c>
    1c58:      	cmp	x16, #0x0
    1c5c:      	b.eq	0x1c64 <_stogir.verify.integer-operations-target-structured+0x1014>
    1c60:      	b	0x1c6c <_stogir.verify.integer-operations-target-structured+0x101c>
    1c64:      	b	0x1c70 <_stogir.verify.integer-operations-target-structured+0x1020>
    1c68:      	b	0x1da8 <_stogir.verify.integer-operations-target-structured+0x1158>
    1c6c:      	b	0x1e30 <_stogir.verify.integer-operations-target-structured+0x11e0>
    1c70:      	ldr	x19, [sp, #0x2b0]
    1c74:      	mov	x22, #0x1d              ; =29
    1c78:      	b	0x1b4c <_stogir.verify.integer-operations-target-structured+0xefc>
    1c7c:      	cmp	x20, #0x1b
    1c80:      	cset	w0, eq
    1c84:      	ubfx	x0, x0, #0, #8
    1c88:      	b	0x1b8c <_stogir.verify.integer-operations-target-structured+0xf3c>
    1c8c:      	movz	x0, #0x0, lsl #48
    1c90:      	b	0x1b8c <_stogir.verify.integer-operations-target-structured+0xf3c>
    1c94:      	movz	x0, #0x0, lsl #48
    1c98:      	b	0x1b8c <_stogir.verify.integer-operations-target-structured+0xf3c>
    1c9c:      	mov	x0, #0x1                ; =1
    1ca0:      	b	0x1bb0 <_stogir.verify.integer-operations-target-structured+0xf60>
    1ca4:      	cmp	x25, #0x0
    1ca8:      	b.eq	0x1cc8 <_stogir.verify.integer-operations-target-structured+0x1078>
    1cac:      	ldr	w0, [sp, #0x320]
    1cb0:      	ldr	w1, [sp, #0x358]
    1cb4:      	bl	0x1cb4 <_stogir.verify.integer-operations-target-structured+0x1064>
		0000000000001cb4:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1cb8:      	cmp	x0, #0x0
    1cbc:      	b.ne	0x1cc8 <_stogir.verify.integer-operations-target-structured+0x1078>
    1cc0:      	mov	x0, #0x1                ; =1
    1cc4:      	b	0x1bbc <_stogir.verify.integer-operations-target-structured+0xf6c>
    1cc8:      	cmp	x23, #0x0
    1ccc:      	b.eq	0x1d98 <_stogir.verify.integer-operations-target-structured+0x1148>
    1cd0:      	cmp	x20, #0x3a
    1cd4:      	cset	w0, eq
    1cd8:      	cmp	x20, #0x3b
    1cdc:      	cset	w1, eq
    1ce0:      	cmp	x20, #0x1a
    1ce4:      	b.lt	0x1d48 <_stogir.verify.integer-operations-target-structured+0x10f8>
    1ce8:      	cmp	x20, #0x1e
    1cec:      	b.gt	0x1d48 <_stogir.verify.integer-operations-target-structured+0x10f8>
    1cf0:      	cmp	x26, #0x1
    1cf4:      	b.lt	0x1d90 <_stogir.verify.integer-operations-target-structured+0x1140>
    1cf8:      	cmp	x26, #0xb
    1cfc:      	b.gt	0x1d90 <_stogir.verify.integer-operations-target-structured+0x1140>
    1d00:      	cmp	x26, #0x1
    1d04:      	b.ne	0x1d88 <_stogir.verify.integer-operations-target-structured+0x1138>
    1d08:      	cmp	x20, #0x2e
    1d0c:      	b.eq	0x1d78 <_stogir.verify.integer-operations-target-structured+0x1128>
    1d10:      	cmp	x20, #0x2f
    1d14:      	b.eq	0x1d78 <_stogir.verify.integer-operations-target-structured+0x1128>
    1d18:      	cmp	x20, #0x30
    1d1c:      	b.eq	0x1d78 <_stogir.verify.integer-operations-target-structured+0x1128>
    1d20:      	uxtb	w16, w0
    1d24:      	cmp	w16, wzr
    1d28:      	b.eq	0x1d80 <_stogir.verify.integer-operations-target-structured+0x1130>
    1d2c:      	mov	x1, #0x1                ; =1
    1d30:      	cmp	x1, #0x0
    1d34:      	cset	w0, ne
    1d38:      	uxtb	w16, w0
    1d3c:      	cmp	w16, wzr
    1d40:      	cset	x0, eq
    1d44:      	b	0x1cc4 <_stogir.verify.integer-operations-target-structured+0x1074>
    1d48:      	cmp	x20, #0x2e
    1d4c:      	b.lt	0x1d58 <_stogir.verify.integer-operations-target-structured+0x1108>
    1d50:      	cmp	x20, #0x35
    1d54:      	b.le	0x1cf0 <_stogir.verify.integer-operations-target-structured+0x10a0>
    1d58:      	uxtb	w16, w0
    1d5c:      	cmp	w16, wzr
    1d60:      	b.ne	0x1cf0 <_stogir.verify.integer-operations-target-structured+0x10a0>
    1d64:      	uxtb	w16, w1
    1d68:      	cmp	w16, wzr
    1d6c:      	b.ne	0x1cf0 <_stogir.verify.integer-operations-target-structured+0x10a0>
    1d70:      	movz	x1, #0x0, lsl #48
    1d74:      	b	0x1d30 <_stogir.verify.integer-operations-target-structured+0x10e0>
    1d78:      	mov	x1, #0x1                ; =1
    1d7c:      	b	0x1d30 <_stogir.verify.integer-operations-target-structured+0x10e0>
    1d80:      	ubfx	x1, x1, #0, #8
    1d84:      	b	0x1d30 <_stogir.verify.integer-operations-target-structured+0x10e0>
    1d88:      	mov	x1, #0x1                ; =1
    1d8c:      	b	0x1d30 <_stogir.verify.integer-operations-target-structured+0x10e0>
    1d90:      	movz	x1, #0x0, lsl #48
    1d94:      	b	0x1d30 <_stogir.verify.integer-operations-target-structured+0x10e0>
    1d98:      	movz	x0, #0x0, lsl #48
    1d9c:      	b	0x1d44 <_stogir.verify.integer-operations-target-structured+0x10f4>
    1da0:      	mov	x1, x26
    1da4:      	b	0x1be0 <_stogir.verify.integer-operations-target-structured+0xf90>
    1da8:      	ldr	x0, [sp, #0x220]
    1dac:      	bl	0x1dac <_stogir.verify.integer-operations-target-structured+0x115c>
		0000000000001dac:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1db0:      	cmp	x0, #0x0
    1db4:      	b.ne	0x1dc4 <_stogir.verify.integer-operations-target-structured+0x1174>
    1db8:      	ldr	x19, [sp, #0x2b0]
    1dbc:      	mov	x22, #0x1d              ; =29
    1dc0:      	b	0x1c78 <_stogir.verify.integer-operations-target-structured+0x1028>
    1dc4:      	bl	0x1dc4 <_stogir.verify.integer-operations-target-structured+0x1174>
		0000000000001dc4:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    1dc8:      	uxtb	w0, w0
    1dcc:      	cmp	x26, x0
    1dd0:      	b.ne	0x1df8 <_stogir.verify.integer-operations-target-structured+0x11a8>
    1dd4:      	mov	x0, #0x1                ; =1
    1dd8:      	cmp	x0, #0x0
    1ddc:      	b.eq	0x1e28 <_stogir.verify.integer-operations-target-structured+0x11d8>
    1de0:      	movz	x0, #0x0, lsl #48
    1de4:      	cmp	x0, #0x0
    1de8:      	b.eq	0x1df4 <_stogir.verify.integer-operations-target-structured+0x11a4>
    1dec:      	ldr	x19, [sp, #0x290]
    1df0:      	mov	x22, #0x1d              ; =29
    1df4:      	b	0x1dc0 <_stogir.verify.integer-operations-target-structured+0x1170>
    1df8:      	cmp	x27, #0x0
    1dfc:      	b.eq	0x1e20 <_stogir.verify.integer-operations-target-structured+0x11d0>
    1e00:      	cmp	x0, #0x5
    1e04:      	b.ne	0x1e10 <_stogir.verify.integer-operations-target-structured+0x11c0>
    1e08:      	mov	x0, #0x1                ; =1
    1e0c:      	b	0x1dd8 <_stogir.verify.integer-operations-target-structured+0x1188>
    1e10:      	cmp	x0, #0xb
    1e14:      	cset	w0, eq
    1e18:      	ubfx	x0, x0, #0, #8
    1e1c:      	b	0x1e0c <_stogir.verify.integer-operations-target-structured+0x11bc>
    1e20:      	movz	x0, #0x0, lsl #48
    1e24:      	b	0x1e0c <_stogir.verify.integer-operations-target-structured+0x11bc>
    1e28:      	mov	x0, #0x1                ; =1
    1e2c:      	b	0x1de4 <_stogir.verify.integer-operations-target-structured+0x1194>
    1e30:      	brk	#0
    1e34:      	b	0x1e30 <_stogir.verify.integer-operations-target-structured+0x11e0>
    1e38:      	brk	#0
    1e3c:      	b	0x1e38 <_stogir.verify.integer-operations-target-structured+0x11e8>
    1e40:      	brk	#0
    1e44:      	b	0x1e40 <_stogir.verify.integer-operations-target-structured+0x11f0>
    1e48:      	cmp	x22, #0x0
    1e4c:      	b.ne	0x1ea4 <_stogir.verify.integer-operations-target-structured+0x1254>
    1e50:      	and	x19, x21, #0xffffffff
    1e54:      	movz	x0, #0x0, lsl #48
    1e58:      	movz	x22, #0x0, lsl #48
    1e5c:      	ldr	x1, [sp, #0x2b8]
    1e60:      	str	x0, [x1]
    1e64:      	str	x19, [x1, #0x8]
    1e68:      	str	x22, [x1, #0x10]
    1e6c:      	ldr	x19, [sp, #0x368]
    1e70:      	ldr	x20, [sp, #0x370]
    1e74:      	ldr	x21, [sp, #0x378]
    1e78:      	ldr	x22, [sp, #0x380]
    1e7c:      	ldr	x23, [sp, #0x388]
    1e80:      	ldr	x24, [sp, #0x390]
    1e84:      	ldr	x25, [sp, #0x398]
    1e88:      	ldr	x26, [sp, #0x3a0]
    1e8c:      	ldr	x27, [sp, #0x3a8]
    1e90:      	ldr	x28, [sp, #0x3b0]
    1e94:      	ldr	x29, [sp, #0x10]
    1e98:      	ldr	x30, [sp, #0x18]
    1e9c:      	add	sp, sp, #0x3c0
    1ea0:      	ret
    1ea4:      	mov	x0, #0x1                ; =1
    1ea8:      	b	0x1e5c <_stogir.verify.integer-operations-target-structured+0x120c>
    1eac:      	str	x8, [sp, #0x2b8]
    1eb0:      	b	0x1e48 <_stogir.verify.integer-operations-target-structured+0x11f8>
    1eb4:      	str	x23, [sp, #0x348]
    1eb8:      	mov	w23, w0
    1ebc:      	b	0x1164 <_stogir.verify.integer-operations-target-structured+0x514>
    1ec0:      	str	x23, [sp, #0x348]
    1ec4:      	mov	w23, w0
    1ec8:      	b	0x1920 <_stogir.verify.integer-operations-target-structured+0xcd0>
    1ecc:      	ldr	x0, [sp, #0x2f8]
    1ed0:      	b	0x11d8 <_stogir.verify.integer-operations-target-structured+0x588>
    1ed4:      	str	x0, [sp, #0x2f8]
    1ed8:      	ldr	x0, [sp, #0x228]
    1edc:      	b	0x1250 <_stogir.verify.integer-operations-target-structured+0x600>
    1ee0:      	str	x0, [sp, #0x228]
    1ee4:      	ldr	x0, [sp, #0x230]
    1ee8:      	b	0x12c8 <_stogir.verify.integer-operations-target-structured+0x678>
    1eec:      	str	x0, [sp, #0x230]
    1ef0:      	ldr	x0, [sp, #0x238]
    1ef4:      	b	0x1340 <_stogir.verify.integer-operations-target-structured+0x6f0>
    1ef8:      	str	x0, [sp, #0x238]
    1efc:      	ldr	x0, [sp, #0x240]
    1f00:      	b	0x13bc <_stogir.verify.integer-operations-target-structured+0x76c>
    1f04:      	str	x0, [sp, #0x240]
    1f08:      	ldr	x0, [sp, #0x248]
    1f0c:      	b	0x1438 <_stogir.verify.integer-operations-target-structured+0x7e8>
    1f10:      	str	x0, [sp, #0x248]
    1f14:      	ldr	x0, [sp, #0x250]
    1f18:      	b	0x149c <_stogir.verify.integer-operations-target-structured+0x84c>
    1f1c:      	str	x24, [sp, #0x220]
    1f20:      	str	x0, [sp, #0x250]
    1f24:      	b	0x14f0 <_stogir.verify.integer-operations-target-structured+0x8a0>
    1f28:      	ldr	x0, [sp, #0x300]
    1f2c:      	b	0x1574 <_stogir.verify.integer-operations-target-structured+0x924>
    1f30:      	ldr	x24, [sp, #0x328]
    1f34:      	b	0x1b24 <_stogir.verify.integer-operations-target-structured+0xed4>
    1f38:      	ldr	x24, [sp, #0x328]
    1f3c:      	b	0x1b1c <_stogir.verify.integer-operations-target-structured+0xecc>
    1f40:      	str	x26, [sp, #0x350]
    1f44:      	str	x0, [sp, #0x300]
    1f48:      	str	x27, [sp, #0x360]
    1f4c:      	b	0x1670 <_stogir.verify.integer-operations-target-structured+0xa20>
    1f50:      	ldr	x5, [sp, #0x2e8]
    1f54:      	b	0x1818 <_stogir.verify.integer-operations-target-structured+0xbc8>
    1f58:      	ldr	x1, [sp, #0x2e0]
    1f5c:      	b	0x18d0 <_stogir.verify.integer-operations-target-structured+0xc80>

0000000000001f60 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    1f60:      	ldr	x0, [x0, #0x8]
    1f64:      	ret

0000000000001f68 <_stogir.node.opcode>:
    1f68:      	ldr	w0, [x0]
    1f6c:      	uxtb	w0, w0
    1f70:      	ret

0000000000001f74 <_stogir.opcode.valid?>:
    1f74:      	sxtw	x0, w0
    1f78:      	cmp	x0, #0x0
    1f7c:      	b.lt	0x1f90 <_stogir.opcode.valid?+0x1c>
    1f80:      	cmp	x0, #0x83
    1f84:      	cset	w0, lt
    1f88:      	ubfx	x0, x0, #0, #8
    1f8c:      	b	0x1f94 <_stogir.opcode.valid?+0x20>
    1f90:      	movz	x0, #0x0, lsl #48
    1f94:      	ret

0000000000001f98 <_stogir.node.type-id>:
    1f98:      	ldr	w0, [x0]
    1f9c:      	ubfx	x0, x0, #8, #8
    1fa0:      	ret

0000000000001fa4 <_stogir.types.valid?>:
    1fa4:      	sxtw	x1, w0
    1fa8:      	cmp	x1, #0x0
    1fac:      	b.lt	0x1fc0 <_stogir.types.valid?+0x1c>
    1fb0:      	cmp	x1, #0xd
    1fb4:      	b.gt	0x1fc0 <_stogir.types.valid?+0x1c>
    1fb8:      	mov	x0, #0x1                ; =1
    1fbc:      	b	0x1ffc <_stogir.types.valid?+0x58>
    1fc0:      	cmp	x1, #0xf
    1fc4:      	b.le	0x1ff8 <_stogir.types.valid?+0x54>
    1fc8:      	cmp	x1, #0x80
    1fcc:      	b.ge	0x1ff0 <_stogir.types.valid?+0x4c>
    1fd0:      	and	w0, w0, #0xf
    1fd4:      	ubfx	x0, x0, #0, #32
    1fd8:      	cmp	x0, #0x1
    1fdc:      	b.lt	0x2000 <_stogir.types.valid?+0x5c>
    1fe0:      	cmp	x0, #0xd
    1fe4:      	cset	w0, le
    1fe8:      	ubfx	x0, x0, #0, #8
    1fec:      	b	0x2004 <_stogir.types.valid?+0x60>
    1ff0:      	movz	x0, #0x0, lsl #48
    1ff4:      	b	0x1ffc <_stogir.types.valid?+0x58>
    1ff8:      	movz	x0, #0x0, lsl #48
    1ffc:      	ret
    2000:      	movz	x0, #0x0, lsl #48
    2004:      	b	0x1ff4 <_stogir.types.valid?+0x50>

0000000000002008 <_stogir.opcode.input-count>:
    2008:      	sxtw	x0, w0
    200c:      	cmp	x0, #0x0
    2010:      	b.lt	0x2038 <_stogir.opcode.input-count+0x30>
    2014:      	cmp	x0, #0x83
    2018:      	b.ge	0x2038 <_stogir.opcode.input-count+0x30>
    201c:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		000000000000201c:  ARM64_RELOC_PAGE21	l_stogir.344
    2020:      	ldr	x16, [x16]
		0000000000002020:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    2024:      	orr	x1, x16, xzr
    2028:      	add	x0, x1, x0
    202c:      	ldrsb	w0, [x0]
    2030:      	sxtb	x0, w0
    2034:      	b	0x203c <_stogir.opcode.input-count+0x34>
    2038:      	mov	x0, #-0x2               ; =-2
    203c:      	ret

0000000000002040 <_stogir.node.auxiliary>:
    2040:      	ldr	w0, [x0]
    2044:      	ubfx	x0, x0, #16, #16
    2048:      	ret

000000000000204c <_stogir.opcode.operand-code>:
    204c:      	sxtw	x0, w0
    2050:      	cmp	x0, #0x0
    2054:      	b.lt	0x2090 <_stogir.opcode.operand-code+0x44>
    2058:      	cmp	x0, #0x83
    205c:      	b.ge	0x2090 <_stogir.opcode.operand-code+0x44>
    2060:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002060:  ARM64_RELOC_PAGE21	l_stogir.345
    2064:      	ldr	x16, [x16]
		0000000000002064:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    2068:      	orr	x2, x16, xzr
    206c:      	sxtw	x3, w1
    2070:      	add	x0, x2, x0, lsl #2
    2074:      	ldr	w0, [x0]
    2078:      	cmp	x3, #0x0
    207c:      	b.le	0x2098 <_stogir.opcode.operand-code+0x4c>
    2080:      	cmp	x3, #0x4
    2084:      	b.le	0x20a0 <_stogir.opcode.operand-code+0x54>
    2088:      	mov	w1, #0x4                ; =4
    208c:      	b	0x20a4 <_stogir.opcode.operand-code+0x58>
    2090:      	movz	x0, #0x0, lsl #48
    2094:      	ret
    2098:      	movz	x0, #0x0, lsl #48
    209c:      	b	0x2094 <_stogir.opcode.operand-code+0x48>
    20a0:      	sub	w1, w1, #0x1
    20a4:      	lsl	w1, w1, #2
    20a8:      	ubfx	x1, x1, #0, #32
    20ac:      	lsr	x0, x0, x1
    20b0:      	and	w0, w0, #0xf
    20b4:      	ubfx	x0, x0, #0, #32
    20b8:      	b	0x209c <_stogir.opcode.operand-code+0x50>

00000000000020bc <_stogir.graph.operand>:
    20bc:      	sub	sp, sp, #0x10
    20c0:      	mov	x3, sp
    20c4:      	sxtw	x1, w1
    20c8:      	cmp	x1, #0x0
    20cc:      	b.le	0x2110 <_stogir.graph.operand+0x54>
    20d0:      	lsl	x4, x1, #2
    20d4:      	ldr	x5, [x0, #0x8]
    20d8:      	cmp	x1, x5
    20dc:      	b.ge	0x2144 <_stogir.graph.operand+0x88>
    20e0:      	add	x5, x0, #0x78
    20e4:      	ldr	x5, [x5, #0x8]
    20e8:      	cmp	x1, x5
    20ec:      	b.ge	0x213c <_stogir.graph.operand+0x80>
    20f0:      	ldr	x5, [x0, #0x78]
    20f4:      	add	x5, x4, x5
    20f8:      	ldr	w5, [x5]
    20fc:      	sxtw	x5, w5
    2100:      	cmp	x5, #0x0
    2104:      	cset	w5, ge
    2108:      	ubfx	x5, x5, #0, #8
    210c:      	b	0x2140 <_stogir.graph.operand+0x84>
    2110:      	movz	x1, #0x0, lsl #48
    2114:      	movz	x0, #0x0, lsl #48
    2118:      	str	x1, [x3]
    211c:      	str	x0, [x3, #0x8]
    2120:      	ldr	x0, [sp]
    2124:      	ldr	x1, [sp, #0x8]
    2128:      	add	sp, sp, #0x10
    212c:      	ret
    2130:      	movz	x1, #0x0, lsl #48
    2134:      	movz	x0, #0x0, lsl #48
    2138:      	b	0x2118 <_stogir.graph.operand+0x5c>
    213c:      	movz	x5, #0x0, lsl #48
    2140:      	b	0x2148 <_stogir.graph.operand+0x8c>
    2144:      	movz	x5, #0x0, lsl #48
    2148:      	cmp	x5, #0x0
    214c:      	b.eq	0x2110 <_stogir.graph.operand+0x54>
    2150:      	sxtw	x2, w2
    2154:      	cmp	x2, #0x1
    2158:      	b.lt	0x2130 <_stogir.graph.operand+0x74>
    215c:      	ldr	x5, [x0, #0x78]
    2160:      	add	x4, x4, x5
    2164:      	ldr	w4, [x4]
    2168:      	sxtw	x4, w4
    216c:      	cmp	x2, x4
    2170:      	b.gt	0x2130 <_stogir.graph.operand+0x74>
    2174:      	asr	x16, x2, #63
    2178:      	lsr	x16, x16, #62
    217c:      	add	x4, x2, x16
    2180:      	asr	x4, x4, #2
    2184:      	asr	x16, x2, #63
    2188:      	lsr	x16, x16, #62
    218c:      	add	x2, x2, x16
    2190:      	and	x2, x2, #0x3
    2194:      	sub	x2, x2, x16
    2198:      	ldr	x0, [x0]
    219c:      	add	x1, x4, x1
    21a0:      	add	x0, x0, x1, lsl #4
    21a4:      	add	x0, x0, x2, lsl #2
    21a8:      	ldr	w0, [x0]
    21ac:      	sxtw	x0, w0
    21b0:      	and	x0, x0, #0xffffffff
    21b4:      	mov	x1, #0x1                ; =1
    21b8:      	b	0x2138 <_stogir.graph.operand+0x7c>

00000000000021bc <_stogir.graph.borrow-node>:
    21bc:      	sxtw	x1, w1
    21c0:      	cmp	x1, #0x0
    21c4:      	cset	w2, gt
    21c8:      	movz	x16, #0x0, lsl #48
    21cc:      	sub	x3, x16, x1
    21d0:      	sub	x4, x3, #0x1
    21d4:      	uxtb	w16, w2
    21d8:      	cmp	w16, wzr
    21dc:      	b.eq	0x221c <_stogir.graph.borrow-node+0x60>
    21e0:      	ldr	x3, [x0, #0x8]
    21e4:      	cmp	x1, x3
    21e8:      	b.ge	0x226c <_stogir.graph.borrow-node+0xb0>
    21ec:      	add	x3, x0, #0x78
    21f0:      	ldr	x3, [x3, #0x8]
    21f4:      	cmp	x1, x3
    21f8:      	b.ge	0x22ac <_stogir.graph.borrow-node+0xf0>
    21fc:      	ldr	x3, [x0, #0x78]
    2200:      	add	x3, x3, x1, lsl #2
    2204:      	ldr	w3, [x3]
    2208:      	sxtw	x3, w3
    220c:      	cmp	x3, #0x0
    2210:      	cset	w3, ge
    2214:      	ubfx	x3, x3, #0, #8
    2218:      	b	0x22b0 <_stogir.graph.borrow-node+0xf4>
    221c:      	cmp	x1, #0x0
    2220:      	b.ge	0x2274 <_stogir.graph.borrow-node+0xb8>
    2224:      	add	x5, x0, #0x28
    2228:      	add	x6, x0, #0x50
    222c:      	ldr	x5, [x5, #0x8]
    2230:      	ldr	x6, [x6, #0x8]
    2234:      	cmp	x5, x6
    2238:      	b.ne	0x2264 <_stogir.graph.borrow-node+0xa8>
    223c:      	cmp	x3, x5
    2240:      	b.gt	0x22b4 <_stogir.graph.borrow-node+0xf8>
    2244:      	ldr	x3, [x0, #0x50]
    2248:      	add	x3, x3, x4, lsl #2
    224c:      	ldr	w3, [x3]
    2250:      	sxtw	x3, w3
    2254:      	cmp	x3, #0x0
    2258:      	cset	w3, gt
    225c:      	ubfx	x3, x3, #0, #8
    2260:      	b	0x22b8 <_stogir.graph.borrow-node+0xfc>
    2264:      	movz	x3, #0x0, lsl #48
    2268:      	b	0x2278 <_stogir.graph.borrow-node+0xbc>
    226c:      	movz	x3, #0x0, lsl #48
    2270:      	b	0x2278 <_stogir.graph.borrow-node+0xbc>
    2274:      	movz	x3, #0x0, lsl #48
    2278:      	cmp	x3, #0x0
    227c:      	b.eq	0x22a4 <_stogir.graph.borrow-node+0xe8>
    2280:      	uxtb	w16, w2
    2284:      	cmp	w16, wzr
    2288:      	b.eq	0x2298 <_stogir.graph.borrow-node+0xdc>
    228c:      	ldr	x0, [x0]
    2290:      	add	x0, x0, x1, lsl #4
    2294:      	b	0x22a0 <_stogir.graph.borrow-node+0xe4>
    2298:      	ldr	x0, [x0, #0x28]
    229c:      	add	x0, x0, x4, lsl #4
    22a0:      	b	0x22a8 <_stogir.graph.borrow-node+0xec>
    22a4:      	movz	x0, #0x0, lsl #48
    22a8:      	ret
    22ac:      	movz	x3, #0x0, lsl #48
    22b0:      	b	0x2270 <_stogir.graph.borrow-node+0xb4>
    22b4:      	movz	x3, #0x0, lsl #48
    22b8:      	b	0x2268 <_stogir.graph.borrow-node+0xac>

00000000000022bc <_stogir.graph.contains?>:
    22bc:      	sxtw	x1, w1
    22c0:      	cmp	x1, #0x0
    22c4:      	b.le	0x2304 <_stogir.graph.contains?+0x48>
    22c8:      	ldr	x2, [x0, #0x8]
    22cc:      	cmp	x1, x2
    22d0:      	b.ge	0x2360 <_stogir.graph.contains?+0xa4>
    22d4:      	add	x2, x0, #0x78
    22d8:      	ldr	x2, [x2, #0x8]
    22dc:      	cmp	x1, x2
    22e0:      	b.ge	0x2370 <_stogir.graph.contains?+0xb4>
    22e4:      	ldr	x0, [x0, #0x78]
    22e8:      	add	x0, x0, x1, lsl #2
    22ec:      	ldr	w0, [x0]
    22f0:      	sxtw	x0, w0
    22f4:      	cmp	x0, #0x0
    22f8:      	cset	w0, ge
    22fc:      	ubfx	x0, x0, #0, #8
    2300:      	b	0x2374 <_stogir.graph.contains?+0xb8>
    2304:      	cmp	x1, #0x0
    2308:      	b.ge	0x2368 <_stogir.graph.contains?+0xac>
    230c:      	add	x2, x0, #0x28
    2310:      	add	x3, x0, #0x50
    2314:      	ldr	x2, [x2, #0x8]
    2318:      	ldr	x3, [x3, #0x8]
    231c:      	cmp	x2, x3
    2320:      	b.ne	0x2380 <_stogir.graph.contains?+0xc4>
    2324:      	movz	x16, #0x0, lsl #48
    2328:      	sub	x3, x16, x1
    232c:      	cmp	x3, x2
    2330:      	b.gt	0x2378 <_stogir.graph.contains?+0xbc>
    2334:      	movz	x16, #0x0, lsl #48
    2338:      	sub	x1, x16, x1
    233c:      	sub	x1, x1, #0x1
    2340:      	ldr	x0, [x0, #0x50]
    2344:      	add	x0, x0, x1, lsl #2
    2348:      	ldr	w0, [x0]
    234c:      	sxtw	x0, w0
    2350:      	cmp	x0, #0x0
    2354:      	cset	w0, gt
    2358:      	ubfx	x0, x0, #0, #8
    235c:      	b	0x237c <_stogir.graph.contains?+0xc0>
    2360:      	movz	x0, #0x0, lsl #48
    2364:      	b	0x2374 <_stogir.graph.contains?+0xb8>
    2368:      	movz	x0, #0x0, lsl #48
    236c:      	b	0x237c <_stogir.graph.contains?+0xc0>
    2370:      	movz	x0, #0x0, lsl #48
    2374:      	b	0x237c <_stogir.graph.contains?+0xc0>
    2378:      	movz	x0, #0x0, lsl #48
    237c:      	ret
    2380:      	movz	x0, #0x0, lsl #48
    2384:      	b	0x237c <_stogir.graph.contains?+0xc0>

0000000000002388 <_stogir.verify.classifications>:
    2388:      	sub	sp, sp, #0x70
    238c:      	str	x29, [sp]
    2390:      	str	x30, [sp, #0x8]
    2394:      	mov	x29, sp
    2398:      	str	x19, [sp, #0x20]
    239c:      	str	x20, [sp, #0x28]
    23a0:      	str	x21, [sp, #0x30]
    23a4:      	str	x22, [sp, #0x38]
    23a8:      	str	x23, [sp, #0x40]
    23ac:      	str	x24, [sp, #0x48]
    23b0:      	str	x25, [sp, #0x50]
    23b4:      	str	x26, [sp, #0x58]
    23b8:      	str	x27, [sp, #0x60]
    23bc:      	str	x28, [sp, #0x68]
    23c0:      	ldr	w4, [x2]
    23c4:      	orr	x5, x4, xzr
    23c8:      	ubfx	x5, x5, #8, #8
    23cc:      	orr	x19, x5, xzr
    23d0:      	cmp	x19, #0xf
    23d4:      	b.le	0x2408 <_stogir.verify.classifications+0x80>
    23d8:      	cmp	x19, #0x80
    23dc:      	b.ge	0x2400 <_stogir.verify.classifications+0x78>
    23e0:      	and	w5, w5, #0xf
    23e4:      	ubfx	x5, x5, #0, #32
    23e8:      	cmp	x5, #0x1
    23ec:      	b.lt	0x28e4 <_stogir.verify.classifications+0x55c>
    23f0:      	cmp	x5, #0xd
    23f4:      	cset	w5, le
    23f8:      	ubfx	x20, x5, #0, #8
    23fc:      	b	0x28e8 <_stogir.verify.classifications+0x560>
    2400:      	movz	x20, #0x0, lsl #48
    2404:      	b	0x240c <_stogir.verify.classifications+0x84>
    2408:      	movz	x20, #0x0, lsl #48
    240c:      	uxtb	w21, w4
    2410:      	orr	x4, x21, xzr
    2414:      	mov	x22, x0
    2418:      	mov	w0, w4
    241c:      	mov	w23, w1
    2420:      	mov	x24, x2
    2424:      	mov	w25, w3
    2428:      	bl	0x2428 <_stogir.verify.classifications+0xa0>
		0000000000002428:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    242c:      	cmp	x0, #0x0
    2430:      	b.eq	0x244c <_stogir.verify.classifications+0xc4>
    2434:      	cmp	x20, #0x0
    2438:      	cset	w0, ne
    243c:      	uxtb	w16, w0
    2440:      	cmp	w16, wzr
    2444:      	cset	x26, eq
    2448:      	b	0x2450 <_stogir.verify.classifications+0xc8>
    244c:      	movz	x26, #0x0, lsl #48
    2450:      	cmp	x26, #0x0
    2454:      	cset	w27, ne
    2458:      	uxtb	w16, w27
    245c:      	cmp	w16, wzr
    2460:      	b.eq	0x2494 <_stogir.verify.classifications+0x10c>
    2464:      	ldr	w0, [x24, #0x4]
    2468:      	mov	w1, w0
    246c:      	mov	x0, x22
    2470:      	bl	0x2470 <_stogir.verify.classifications+0xe8>
		0000000000002470:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2474:      	cmp	x0, #0x0
    2478:      	b.ne	0x2484 <_stogir.verify.classifications+0xfc>
    247c:      	movn	w28, #0x0, lsl #16
    2480:      	b	0x2490 <_stogir.verify.classifications+0x108>
    2484:      	ldr	w0, [x0]
    2488:      	ubfx	x0, x0, #8, #8
    248c:      	orr	x28, x0, xzr
    2490:      	b	0x2498 <_stogir.verify.classifications+0x110>
    2494:      	movn	w28, #0x0, lsl #16
    2498:      	sxtw	x0, w28
    249c:      	cmp	x26, #0x0
    24a0:      	b.eq	0x2940 <_stogir.verify.classifications+0x5b8>
    24a4:      	mov	x26, x0
    24a8:      	mov	w0, w28
    24ac:      	bl	0x24ac <_stogir.verify.classifications+0x124>
		00000000000024ac:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    24b0:      	cmp	x0, #0x0
    24b4:      	b.eq	0x28d4 <_stogir.verify.classifications+0x54c>
    24b8:      	movz	x0, #0x0, lsl #48
    24bc:      	b	0x24c4 <_stogir.verify.classifications+0x13c>
    24c0:      	mov	x0, #0x1                ; =1
    24c4:      	b	0x24dc <_stogir.verify.classifications+0x154>
    24c8:      	movz	x19, #0x0, lsl #48
    24cc:      	b	0x2558 <_stogir.verify.classifications+0x1d0>
    24d0:      	movz	x20, #0x0, lsl #48
    24d4:      	b	0x2560 <_stogir.verify.classifications+0x1d8>
    24d8:      	movz	x0, #0x0, lsl #48
    24dc:      	sxtw	x25, w25
    24e0:      	cmp	x26, #0xf
    24e4:      	cset	w1, gt
    24e8:      	cmp	x26, #0x80
    24ec:      	cset	w2, lt
    24f0:      	cmp	x21, #0x83
    24f4:      	cset	w3, lt
    24f8:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		00000000000024f8:  ARM64_RELOC_PAGE21	l_stogir.346
    24fc:      	ldr	x16, [x16]
		00000000000024fc:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    2500:      	orr	x4, x16, xzr
    2504:      	add	x5, x22, #0x78
    2508:      	add	x6, x22, #0x28
    250c:      	add	x7, x22, #0x50
    2510:      	sxtw	x23, w23
    2514:      	add	x8, x22, #0x78
    2518:      	and	w9, w28, #0xf
    251c:      	add	x4, x4, x21, lsl #2
    2520:      	cmp	x23, #0x0
    2524:      	cset	w10, le
    2528:      	lsl	x11, x23, #2
    252c:      	ubfx	x9, x9, #0, #32
    2530:      	cmp	x9, #0x1
    2534:      	cset	w12, ge
    2538:      	cmp	x9, #0xd
    253c:      	cset	w9, le
    2540:      	ubfx	x9, x9, #0, #8
    2544:      	mov	x13, #0x1               ; =1
    2548:      	b	0x2600 <_stogir.verify.classifications+0x278>
    254c:      	movz	x19, #0x0, lsl #48
    2550:      	b	0x2580 <_stogir.verify.classifications+0x1f8>
    2554:      	movz	x19, #0x0, lsl #48
    2558:      	b	0x2588 <_stogir.verify.classifications+0x200>
    255c:      	movz	x20, #0x0, lsl #48
    2560:      	b	0x25f8 <_stogir.verify.classifications+0x270>
    2564:      	sub	w14, w14, #0x1
    2568:      	lsl	w14, w14, #2
    256c:      	ubfx	x14, x14, #0, #32
    2570:      	lsr	x14, x19, x14
    2574:      	and	w14, w14, #0xf
    2578:      	b	0x2644 <_stogir.verify.classifications+0x2bc>
    257c:      	movz	x19, #0x0, lsl #48
    2580:      	b	0x2588 <_stogir.verify.classifications+0x200>
    2584:      	movz	x19, #0x0, lsl #48
    2588:      	cmp	x19, #0x0
    258c:      	b.eq	0x25b4 <_stogir.verify.classifications+0x22c>
    2590:      	uxtb	w16, w15
    2594:      	cmp	w16, wzr
    2598:      	b.eq	0x25a8 <_stogir.verify.classifications+0x220>
    259c:      	ldr	x15, [x22]
    25a0:      	add	x14, x15, x14, lsl #4
    25a4:      	b	0x25b0 <_stogir.verify.classifications+0x228>
    25a8:      	ldr	x14, [x22, #0x28]
    25ac:      	add	x14, x14, x21, lsl #4
    25b0:      	b	0x25b8 <_stogir.verify.classifications+0x230>
    25b4:      	movz	x14, #0x0, lsl #48
    25b8:      	cmp	x14, #0x0
    25bc:      	b.eq	0x25f8 <_stogir.verify.classifications+0x270>
    25c0:      	ldr	w14, [x14]
    25c4:      	ubfx	x14, x14, #8, #8
    25c8:      	orr	x15, x14, xzr
    25cc:      	cmp	x15, #0xf
    25d0:      	b.le	0x25f8 <_stogir.verify.classifications+0x270>
    25d4:      	cmp	x15, #0x80
    25d8:      	b.ge	0x25f8 <_stogir.verify.classifications+0x270>
    25dc:      	and	w14, w14, #0xf
    25e0:      	ubfx	x14, x14, #0, #32
    25e4:      	cmp	x14, #0x1
    25e8:      	b.lt	0x25f8 <_stogir.verify.classifications+0x270>
    25ec:      	cmp	x14, #0xd
    25f0:      	b.gt	0x25f8 <_stogir.verify.classifications+0x270>
    25f4:      	mov	x20, #0x1               ; =1
    25f8:      	add	x13, x13, #0x1
    25fc:      	sxtw	x13, w13
    2600:      	cmp	x20, #0x0
    2604:      	b.ne	0x2780 <_stogir.verify.classifications+0x3f8>
    2608:      	cmp	x13, x25
    260c:      	b.gt	0x2780 <_stogir.verify.classifications+0x3f8>
    2610:      	orr	w14, w13, wzr
    2614:      	sxtw	x15, w14
    2618:      	uxtb	w16, w3
    261c:      	cmp	w16, wzr
    2620:      	b.eq	0x2648 <_stogir.verify.classifications+0x2c0>
    2624:      	ldr	w19, [x4]
    2628:      	cmp	x15, #0x0
    262c:      	b.le	0x2640 <_stogir.verify.classifications+0x2b8>
    2630:      	cmp	x15, #0x4
    2634:      	b.le	0x2564 <_stogir.verify.classifications+0x1dc>
    2638:      	mov	w14, #0x4               ; =4
    263c:      	b	0x2568 <_stogir.verify.classifications+0x1e0>
    2640:      	movz	w14, #0x0, lsl #16
    2644:      	b	0x264c <_stogir.verify.classifications+0x2c4>
    2648:      	movz	w14, #0x0, lsl #16
    264c:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		000000000000264c:  ARM64_RELOC_PAGE21	l_stogir.347
    2650:      	ldr	x16, [x16]
		0000000000002650:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    2654:      	ldr	w19, [x16]
    2658:      	ubfx	x14, x14, #0, #32
    265c:      	cmp	x14, x19
    2660:      	b.eq	0x2678 <_stogir.verify.classifications+0x2f0>
    2664:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002664:  ARM64_RELOC_PAGE21	l_stogir.348
    2668:      	ldr	x16, [x16]
		0000000000002668:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    266c:      	ldr	w19, [x16]
    2670:      	cmp	x14, x19
    2674:      	b.ne	0x25f8 <_stogir.verify.classifications+0x270>
    2678:      	cmp	x13, #0x1
    267c:      	b.ne	0x26b8 <_stogir.verify.classifications+0x330>
    2680:      	uxtb	w16, w27
    2684:      	cmp	w16, wzr
    2688:      	b.eq	0x26b8 <_stogir.verify.classifications+0x330>
    268c:      	uxtb	w16, w1
    2690:      	cmp	w16, wzr
    2694:      	b.eq	0x255c <_stogir.verify.classifications+0x1d4>
    2698:      	uxtb	w16, w2
    269c:      	cmp	w16, wzr
    26a0:      	b.eq	0x24d0 <_stogir.verify.classifications+0x148>
    26a4:      	uxtb	w16, w12
    26a8:      	cmp	w16, wzr
    26ac:      	b.eq	0x2888 <_stogir.verify.classifications+0x500>
    26b0:      	mov	x20, x9
    26b4:      	b	0x288c <_stogir.verify.classifications+0x504>
    26b8:      	cmp	x13, #0x1
    26bc:      	b.ne	0x2720 <_stogir.verify.classifications+0x398>
    26c0:      	ldr	w14, [x24, #0x4]
    26c4:      	sxtw	x14, w14
    26c8:      	cmp	x14, #0x0
    26cc:      	cset	w15, gt
    26d0:      	movz	x16, #0x0, lsl #48
    26d4:      	sub	x19, x16, x14
    26d8:      	sub	x21, x19, #0x1
    26dc:      	uxtb	w16, w15
    26e0:      	cmp	w16, wzr
    26e4:      	b.eq	0x2730 <_stogir.verify.classifications+0x3a8>
    26e8:      	ldr	x19, [x22, #0x8]
    26ec:      	cmp	x14, x19
    26f0:      	b.ge	0x257c <_stogir.verify.classifications+0x1f4>
    26f4:      	ldr	x19, [x5, #0x8]
    26f8:      	cmp	x14, x19
    26fc:      	b.ge	0x254c <_stogir.verify.classifications+0x1c4>
    2700:      	ldr	x19, [x22, #0x78]
    2704:      	add	x19, x19, x14, lsl #2
    2708:      	ldr	w19, [x19]
    270c:      	sxtw	x19, w19
    2710:      	cmp	x19, #0x0
    2714:      	cset	w19, ge
    2718:      	ubfx	x19, x19, #0, #8
    271c:      	b	0x2550 <_stogir.verify.classifications+0x1c8>
    2720:      	cmp	x13, #0x2
    2724:      	b.ne	0x2770 <_stogir.verify.classifications+0x3e8>
    2728:      	ldr	w14, [x24, #0x8]
    272c:      	b	0x26c4 <_stogir.verify.classifications+0x33c>
    2730:      	cmp	x14, #0x0
    2734:      	b.ge	0x2584 <_stogir.verify.classifications+0x1fc>
    2738:      	ldr	x26, [x6, #0x8]
    273c:      	ldr	x28, [x7, #0x8]
    2740:      	cmp	x26, x28
    2744:      	b.ne	0x2554 <_stogir.verify.classifications+0x1cc>
    2748:      	cmp	x19, x26
    274c:      	b.gt	0x24c8 <_stogir.verify.classifications+0x140>
    2750:      	ldr	x19, [x22, #0x50]
    2754:      	add	x19, x19, x21, lsl #2
    2758:      	ldr	w19, [x19]
    275c:      	sxtw	x19, w19
    2760:      	cmp	x19, #0x0
    2764:      	cset	w19, gt
    2768:      	ubfx	x19, x19, #0, #8
    276c:      	b	0x24cc <_stogir.verify.classifications+0x144>
    2770:      	cmp	x13, #0x3
    2774:      	b.ne	0x27e4 <_stogir.verify.classifications+0x45c>
    2778:      	ldr	w14, [x24, #0xc]
    277c:      	b	0x272c <_stogir.verify.classifications+0x3a4>
    2780:      	uxtb	w20, w20
    2784:      	uxtb	w0, w0
    2788:      	add	x16, sp, #0x10
    278c:      	movz	w17, #0x0, lsl #16
    2790:      	strh	w17, [x16]
    2794:      	add	x16, sp, #0x10
    2798:      	strb	w20, [x16]
    279c:      	add	x16, sp, #0x10
    27a0:      	strb	w0, [x16, #0x1]
    27a4:      	add	x16, sp, #0x10
    27a8:      	ldrh	w0, [x16]
    27ac:      	ldr	x19, [sp, #0x20]
    27b0:      	ldr	x20, [sp, #0x28]
    27b4:      	ldr	x21, [sp, #0x30]
    27b8:      	ldr	x22, [sp, #0x38]
    27bc:      	ldr	x23, [sp, #0x40]
    27c0:      	ldr	x24, [sp, #0x48]
    27c4:      	ldr	x25, [sp, #0x50]
    27c8:      	ldr	x26, [sp, #0x58]
    27cc:      	ldr	x27, [sp, #0x60]
    27d0:      	ldr	x28, [sp, #0x68]
    27d4:      	ldr	x29, [sp]
    27d8:      	ldr	x30, [sp, #0x8]
    27dc:      	add	sp, sp, #0x70
    27e0:      	ret
    27e4:      	uxtb	w16, w10
    27e8:      	cmp	w16, wzr
    27ec:      	b.ne	0x2894 <_stogir.verify.classifications+0x50c>
    27f0:      	ldr	x14, [x22, #0x8]
    27f4:      	cmp	x23, x14
    27f8:      	b.ge	0x2894 <_stogir.verify.classifications+0x50c>
    27fc:      	ldr	x14, [x8, #0x8]
    2800:      	cmp	x23, x14
    2804:      	b.ge	0x2894 <_stogir.verify.classifications+0x50c>
    2808:      	ldr	x14, [x22, #0x78]
    280c:      	add	x14, x11, x14
    2810:      	ldr	w14, [x14]
    2814:      	sxtw	x14, w14
    2818:      	cmp	x14, #0x0
    281c:      	b.lt	0x2894 <_stogir.verify.classifications+0x50c>
    2820:      	cmp	x15, #0x1
    2824:      	b.lt	0x291c <_stogir.verify.classifications+0x594>
    2828:      	ldr	x14, [x22, #0x78]
    282c:      	add	x14, x11, x14
    2830:      	ldr	w14, [x14]
    2834:      	sxtw	x14, w14
    2838:      	cmp	x15, x14
    283c:      	b.gt	0x291c <_stogir.verify.classifications+0x594>
    2840:      	ldr	x14, [x22]
    2844:      	asr	x16, x15, #63
    2848:      	lsr	x16, x16, #62
    284c:      	add	x19, x15, x16
    2850:      	asr	x19, x19, #2
    2854:      	asr	x16, x15, #63
    2858:      	lsr	x16, x16, #62
    285c:      	add	x15, x15, x16
    2860:      	and	x15, x15, #0x3
    2864:      	sub	x15, x15, x16
    2868:      	add	x19, x19, x23
    286c:      	add	x14, x14, x19, lsl #4
    2870:      	add	x14, x14, x15, lsl #2
    2874:      	ldr	w14, [x14]
    2878:      	movn	w17, #0x0, lsl #16
    287c:      	and	w14, w14, w17
    2880:      	mov	w15, #0x1               ; =1
    2884:      	b	0x2924 <_stogir.verify.classifications+0x59c>
    2888:      	movz	x20, #0x0, lsl #48
    288c:      	b	0x24d4 <_stogir.verify.classifications+0x14c>
    2890:      	b	0x277c <_stogir.verify.classifications+0x3f4>
    2894:      	movz	w15, #0x0, lsl #16
    2898:      	movz	w14, #0x0, lsl #16
    289c:      	ubfx	x15, x15, #0, #32
    28a0:      	lsr	x16, x15, #0
    28a4:      	cmp	x16, #0x1
    28a8:      	b.eq	0x28c4 <_stogir.verify.classifications+0x53c>
    28ac:      	b.lo	0x28b4 <_stogir.verify.classifications+0x52c>
    28b0:      	b	0x28c8 <_stogir.verify.classifications+0x540>
    28b4:      	cmp	x16, #0x0
    28b8:      	b.eq	0x28c0 <_stogir.verify.classifications+0x538>
    28bc:      	b	0x28c8 <_stogir.verify.classifications+0x540>
    28c0:      	b	0x28cc <_stogir.verify.classifications+0x544>
    28c4:      	b	0x2890 <_stogir.verify.classifications+0x508>
    28c8:      	b	0x2938 <_stogir.verify.classifications+0x5b0>
    28cc:      	movz	w14, #0x0, lsl #16
    28d0:      	b	0x2890 <_stogir.verify.classifications+0x508>
    28d4:      	cmp	x21, #0x18
    28d8:      	b.ne	0x28ec <_stogir.verify.classifications+0x564>
    28dc:      	mov	x0, #0x1                ; =1
    28e0:      	b	0x24c4 <_stogir.verify.classifications+0x13c>
    28e4:      	movz	x20, #0x0, lsl #48
    28e8:      	b	0x2404 <_stogir.verify.classifications+0x7c>
    28ec:      	cmp	x21, #0x19
    28f0:      	b.ne	0x28fc <_stogir.verify.classifications+0x574>
    28f4:      	mov	x0, #0x1                ; =1
    28f8:      	b	0x24c4 <_stogir.verify.classifications+0x13c>
    28fc:      	cmp	x19, #0xc
    2900:      	b.eq	0x24c0 <_stogir.verify.classifications+0x138>
    2904:      	cmp	x19, #0xd
    2908:      	b.eq	0x24c0 <_stogir.verify.classifications+0x138>
    290c:      	cmp	x26, #0xc
    2910:      	b.ne	0x2928 <_stogir.verify.classifications+0x5a0>
    2914:      	mov	x0, #0x1                ; =1
    2918:      	b	0x2934 <_stogir.verify.classifications+0x5ac>
    291c:      	movz	w15, #0x0, lsl #16
    2920:      	movz	w14, #0x0, lsl #16
    2924:      	b	0x289c <_stogir.verify.classifications+0x514>
    2928:      	cmp	x26, #0xd
    292c:      	cset	w0, eq
    2930:      	ubfx	x0, x0, #0, #8
    2934:      	b	0x24c4 <_stogir.verify.classifications+0x13c>
    2938:      	brk	#0
    293c:      	b	0x2938 <_stogir.verify.classifications+0x5b0>
    2940:      	mov	x26, x0
    2944:      	b	0x24d8 <_stogir.verify.classifications+0x150>

0000000000002948 <_stogir.vector.validate>:
    2948:      	sub	sp, sp, #0x280
    294c:      	str	x29, [sp]
    2950:      	str	x30, [sp, #0x8]
    2954:      	mov	x29, sp
    2958:      	str	x19, [sp, #0x228]
    295c:      	str	x20, [sp, #0x230]
    2960:      	str	x21, [sp, #0x238]
    2964:      	str	x22, [sp, #0x240]
    2968:      	str	x23, [sp, #0x248]
    296c:      	str	x24, [sp, #0x250]
    2970:      	str	x25, [sp, #0x258]
    2974:      	str	x26, [sp, #0x260]
    2978:      	str	x27, [sp, #0x268]
    297c:      	str	x28, [sp, #0x270]
    2980:      	orr	w19, w1, wzr
    2984:      	mov	x20, x8
    2988:      	add	x8, sp, #0x10
    298c:      	mov	x21, x0
    2990:      	mov	w22, w1
    2994:      	mov	w1, w19
    2998:      	mov	w23, w2
    299c:      	bl	0x299c <_stogir.vector.validate+0x54>
		000000000000299c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    29a0:      	add	x16, sp, #0x10
    29a4:      	ldr	w0, [x16]
    29a8:      	lsr	x16, x0, #0
    29ac:      	cmp	x16, #0x1
    29b0:      	b.eq	0x29cc <_stogir.vector.validate+0x84>
    29b4:      	b.lo	0x29bc <_stogir.vector.validate+0x74>
    29b8:      	b	0x29d0 <_stogir.vector.validate+0x88>
    29bc:      	cmp	x16, #0x0
    29c0:      	b.eq	0x29c8 <_stogir.vector.validate+0x80>
    29c4:      	b	0x29d0 <_stogir.vector.validate+0x88>
    29c8:      	b	0x29d4 <_stogir.vector.validate+0x8c>
    29cc:      	b	0x2a64 <_stogir.vector.validate+0x11c>
    29d0:      	b	0x2c98 <_stogir.vector.validate+0x350>
    29d4:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		00000000000029d4:  ARM64_RELOC_PAGE21	l_stogir.349
    29d8:      	ldr	x16, [x16]
		00000000000029d8:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    29dc:      	orr	x19, x16, xzr
    29e0:      	str	x20, [sp, #0x1c8]
    29e4:      	mov	x0, #0x1                ; =1
    29e8:      	mov	x25, #0x1a              ; =26
    29ec:      	b	0x2a1c <_stogir.vector.validate+0xd4>
    29f0:      	add	x8, sp, #0x70
    29f4:      	mov	x0, x21
    29f8:      	ldr	w1, [sp, #0x1c0]
    29fc:      	mov	w2, w23
    2a00:      	bl	0x2a00 <_stogir.vector.validate+0xb8>
		0000000000002a00:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    2a04:      	add	x16, sp, #0x70
    2a08:      	ldr	x0, [x16]
    2a0c:      	add	x16, sp, #0x70
    2a10:      	ldr	x19, [x16, #0x8]
    2a14:      	add	x16, sp, #0x70
    2a18:      	ldr	x25, [x16, #0x10]
    2a1c:      	ldr	x1, [sp, #0x1c8]
    2a20:      	str	x0, [x1]
    2a24:      	str	x19, [x1, #0x8]
    2a28:      	str	x25, [x1, #0x10]
    2a2c:      	ldr	x19, [sp, #0x228]
    2a30:      	ldr	x20, [sp, #0x230]
    2a34:      	ldr	x21, [sp, #0x238]
    2a38:      	ldr	x22, [sp, #0x240]
    2a3c:      	ldr	x23, [sp, #0x248]
    2a40:      	ldr	x24, [sp, #0x250]
    2a44:      	ldr	x25, [sp, #0x258]
    2a48:      	ldr	x26, [sp, #0x260]
    2a4c:      	ldr	x27, [sp, #0x268]
    2a50:      	ldr	x28, [sp, #0x270]
    2a54:      	ldr	x29, [sp]
    2a58:      	ldr	x30, [sp, #0x8]
    2a5c:      	add	sp, sp, #0x280
    2a60:      	ret
    2a64:      	sxtw	x22, w22
    2a68:      	add	x16, sp, #0x10
    2a6c:      	orr	x0, x16, xzr
    2a70:      	cmp	x22, #0x0
    2a74:      	cset	w24, le
    2a78:      	add	x0, x0, #0x8
    2a7c:      	add	x16, sp, #0x10
    2a80:      	ldr	x1, [x16, #0x8]
    2a84:      	add	x16, sp, #0x40
    2a88:      	str	x1, [x16]
    2a8c:      	ldr	x0, [x0, #0x8]
    2a90:      	add	x16, sp, #0x40
    2a94:      	str	x0, [x16, #0x8]
    2a98:      	uxtb	w16, w24
    2a9c:      	cmp	w16, wzr
    2aa0:      	b.eq	0x2ac0 <_stogir.vector.validate+0x178>
    2aa4:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002aa4:  ARM64_RELOC_PAGE21	l_stogir.350
    2aa8:      	ldr	x16, [x16]
		0000000000002aa8:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    2aac:      	orr	x19, x16, xzr
    2ab0:      	str	x20, [sp, #0x1c8]
    2ab4:      	mov	x0, #0x1                ; =1
    2ab8:      	mov	x25, #0x3b              ; =59
    2abc:      	b	0x2a1c <_stogir.vector.validate+0xd4>
    2ac0:      	add	x16, sp, #0x40
    2ac4:      	orr	x25, x16, xzr
    2ac8:      	lsl	x26, x22, #2
    2acc:      	mov	x0, x25
    2ad0:      	bl	0x2ad0 <_stogir.vector.validate+0x188>
		0000000000002ad0:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    2ad4:      	uxtb	w27, w0
    2ad8:      	mov	x0, x25
    2adc:      	bl	0x2adc <_stogir.vector.validate+0x194>
		0000000000002adc:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    2ae0:      	orr	x25, x27, xzr
    2ae4:      	ldr	x1, [x21, #0x78]
    2ae8:      	cmp	x25, #0x44
    2aec:      	cset	w2, eq
    2af0:      	add	x1, x1, x22, lsl #2
    2af4:      	ldr	w28, [x1]
    2af8:      	cmp	x25, #0x24
    2afc:      	b.ne	0x2b40 <_stogir.vector.validate+0x1f8>
    2b00:      	str	x20, [sp, #0x1c8]
    2b04:      	str	w19, [sp, #0x1c0]
    2b08:      	uxtb	w16, w2
    2b0c:      	cmp	w16, wzr
    2b10:      	b.eq	0x29f0 <_stogir.vector.validate+0xa8>
    2b14:      	add	x8, sp, #0x50
    2b18:      	mov	x0, x21
    2b1c:      	ldr	w1, [sp, #0x1c0]
    2b20:      	bl	0x2b20 <_stogir.vector.validate+0x1d8>
		0000000000002b20:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    2b24:      	add	x16, sp, #0x50
    2b28:      	ldr	x0, [x16]
    2b2c:      	add	x16, sp, #0x50
    2b30:      	ldr	x19, [x16, #0x8]
    2b34:      	add	x16, sp, #0x50
    2b38:      	ldr	x25, [x16, #0x10]
    2b3c:      	b	0x2a1c <_stogir.vector.validate+0xd4>
    2b40:      	uxtb	w16, w2
    2b44:      	cmp	w16, wzr
    2b48:      	b.ne	0x3424 <_stogir.vector.validate+0xadc>
    2b4c:      	cmp	x25, #0x3c
    2b50:      	b.ne	0x2c04 <_stogir.vector.validate+0x2bc>
    2b54:      	add	x8, sp, #0x90
    2b58:      	mov	x0, x21
    2b5c:      	mov	w1, w19
    2b60:      	bl	0x2b60 <_stogir.vector.validate+0x218>
		0000000000002b60:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    2b64:      	add	x16, sp, #0x90
    2b68:      	ldr	x0, [x16]
    2b6c:      	add	x16, sp, #0x90
    2b70:      	ldr	x19, [x16, #0x8]
    2b74:      	add	x16, sp, #0x90
    2b78:      	ldr	x25, [x16, #0x10]
    2b7c:      	str	x20, [sp, #0x1c8]
    2b80:      	b	0x2c00 <_stogir.vector.validate+0x2b8>
    2b84:      	cmp	x25, #0x41
    2b88:      	cset	w0, eq
    2b8c:      	cmp	x25, #0x48
    2b90:      	cset	w1, eq
    2b94:      	cmp	x25, #0x55
    2b98:      	cset	w2, ge
    2b9c:      	cmp	x25, #0x58
    2ba0:      	cset	w3, le
    2ba4:      	cmp	x25, #0x47
    2ba8:      	b.ne	0x2ca0 <_stogir.vector.validate+0x358>
    2bac:      	str	x20, [sp, #0x1c8]
    2bb0:      	str	w19, [sp, #0x1c0]
    2bb4:      	mov	w19, w0
    2bb8:      	mov	w20, w1
    2bbc:      	str	w2, [sp, #0x1d0]
    2bc0:      	str	w3, [sp, #0x1d8]
    2bc4:      	mov	x0, x21
    2bc8:      	ldr	w1, [sp, #0x1c0]
    2bcc:      	bl	0x2bcc <_stogir.vector.validate+0x284>
		0000000000002bcc:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2bd0:      	cmp	x0, #0x0
    2bd4:      	b.eq	0x2cc4 <_stogir.vector.validate+0x37c>
    2bd8:      	add	x8, sp, #0xf0
    2bdc:      	mov	x0, x21
    2be0:      	ldr	w1, [sp, #0x1c0]
    2be4:      	bl	0x2be4 <_stogir.vector.validate+0x29c>
		0000000000002be4:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    2be8:      	add	x16, sp, #0xf0
    2bec:      	ldr	x0, [x16]
    2bf0:      	add	x16, sp, #0xf0
    2bf4:      	ldr	x19, [x16, #0x8]
    2bf8:      	add	x16, sp, #0xf0
    2bfc:      	ldr	x25, [x16, #0x10]
    2c00:      	b	0x2a1c <_stogir.vector.validate+0xd4>
    2c04:      	fmov	d31, x0
    2c08:      	mov	w0, w27
    2c0c:      	fmov	x27, d31
    2c10:      	bl	0x2c10 <_stogir.vector.validate+0x2c8>
		0000000000002c10:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operation?
    2c14:      	cmp	x0, #0x0
    2c18:      	b.eq	0x2c50 <_stogir.vector.validate+0x308>
    2c1c:      	add	x8, sp, #0xb0
    2c20:      	mov	x0, x21
    2c24:      	mov	w1, w19
    2c28:      	mov	w2, w23
    2c2c:      	bl	0x2c2c <_stogir.vector.validate+0x2e4>
		0000000000002c2c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    2c30:      	add	x16, sp, #0xb0
    2c34:      	ldr	x0, [x16]
    2c38:      	add	x16, sp, #0xb0
    2c3c:      	ldr	x19, [x16, #0x8]
    2c40:      	add	x16, sp, #0xb0
    2c44:      	ldr	x25, [x16, #0x10]
    2c48:      	str	x20, [sp, #0x1c8]
    2c4c:      	b	0x2c00 <_stogir.vector.validate+0x2b8>
    2c50:      	mov	x0, x21
    2c54:      	mov	w1, w19
    2c58:      	bl	0x2c58 <_stogir.vector.validate+0x310>
		0000000000002c58:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    2c5c:      	cmp	x0, #0x0
    2c60:      	b.eq	0x2b84 <_stogir.vector.validate+0x23c>
    2c64:      	add	x8, sp, #0xd0
    2c68:      	mov	x0, x21
    2c6c:      	mov	w1, w19
    2c70:      	mov	w2, w23
    2c74:      	bl	0x2c74 <_stogir.vector.validate+0x32c>
		0000000000002c74:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    2c78:      	add	x16, sp, #0xd0
    2c7c:      	ldr	x0, [x16]
    2c80:      	add	x16, sp, #0xd0
    2c84:      	ldr	x19, [x16, #0x8]
    2c88:      	add	x16, sp, #0xd0
    2c8c:      	ldr	x25, [x16, #0x10]
    2c90:      	str	x20, [sp, #0x1c8]
    2c94:      	b	0x2c00 <_stogir.vector.validate+0x2b8>
    2c98:      	brk	#0
    2c9c:      	b	0x2c98 <_stogir.vector.validate+0x350>
    2ca0:      	cmp	x25, #0x4f
    2ca4:      	b.ne	0x2d3c <_stogir.vector.validate+0x3f4>
    2ca8:      	str	x20, [sp, #0x1c8]
    2cac:      	str	w19, [sp, #0x1c0]
    2cb0:      	mov	w19, w0
    2cb4:      	mov	w20, w1
    2cb8:      	str	w2, [sp, #0x1d0]
    2cbc:      	str	w3, [sp, #0x1d8]
    2cc0:      	b	0x2bc4 <_stogir.vector.validate+0x27c>
    2cc4:      	uxtb	w16, w19
    2cc8:      	cmp	w16, wzr
    2ccc:      	b.ne	0x2d0c <_stogir.vector.validate+0x3c4>
    2cd0:      	uxtb	w16, w20
    2cd4:      	cmp	w16, wzr
    2cd8:      	b.ne	0x2d0c <_stogir.vector.validate+0x3c4>
    2cdc:      	ldr	w0, [sp, #0x1d0]
    2ce0:      	uxtb	w16, w0
    2ce4:      	cmp	w16, wzr
    2ce8:      	b.eq	0x2cfc <_stogir.vector.validate+0x3b4>
    2cec:      	ldr	w0, [sp, #0x1d8]
    2cf0:      	uxtb	w16, w0
    2cf4:      	cmp	w16, wzr
    2cf8:      	b.ne	0x2d0c <_stogir.vector.validate+0x3c4>
    2cfc:      	movz	x0, #0x0, lsl #48
    2d00:      	movz	x19, #0x0, lsl #48
    2d04:      	movz	x25, #0x0, lsl #48
    2d08:      	b	0x2d38 <_stogir.vector.validate+0x3f0>
    2d0c:      	add	x8, sp, #0x110
    2d10:      	mov	x0, x21
    2d14:      	ldr	w1, [sp, #0x1c0]
    2d18:      	mov	w2, w23
    2d1c:      	bl	0x2d1c <_stogir.vector.validate+0x3d4>
		0000000000002d1c:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    2d20:      	add	x16, sp, #0x110
    2d24:      	ldr	x0, [x16]
    2d28:      	add	x16, sp, #0x110
    2d2c:      	ldr	x19, [x16, #0x8]
    2d30:      	add	x16, sp, #0x110
    2d34:      	ldr	x25, [x16, #0x10]
    2d38:      	b	0x2c00 <_stogir.vector.validate+0x2b8>
    2d3c:      	cmp	x25, #0x50
    2d40:      	b.eq	0x3430 <_stogir.vector.validate+0xae8>
    2d44:      	cmp	x25, #0x78
    2d48:      	b.ne	0x2d68 <_stogir.vector.validate+0x420>
    2d4c:      	str	x20, [sp, #0x1c8]
    2d50:      	str	w19, [sp, #0x1c0]
    2d54:      	mov	w19, w0
    2d58:      	mov	w20, w1
    2d5c:      	str	w2, [sp, #0x1d0]
    2d60:      	str	w3, [sp, #0x1d8]
    2d64:      	b	0x2bc4 <_stogir.vector.validate+0x27c>
    2d68:      	uxtb	w16, w0
    2d6c:      	cmp	w16, wzr
    2d70:      	b.ne	0x2e30 <_stogir.vector.validate+0x4e8>
    2d74:      	uxtb	w16, w1
    2d78:      	cmp	w16, wzr
    2d7c:      	b.ne	0x2e30 <_stogir.vector.validate+0x4e8>
    2d80:      	uxtb	w16, w2
    2d84:      	cmp	w16, wzr
    2d88:      	b.eq	0x2d98 <_stogir.vector.validate+0x450>
    2d8c:      	uxtb	w16, w3
    2d90:      	cmp	w16, wzr
    2d94:      	b.ne	0x2e30 <_stogir.vector.validate+0x4e8>
    2d98:      	str	w2, [sp, #0x1d0]
    2d9c:      	str	w3, [sp, #0x1d8]
    2da0:      	str	w19, [sp, #0x1c0]
    2da4:      	str	x20, [sp, #0x1c8]
    2da8:      	mov	w20, w1
    2dac:      	mov	w1, w19
    2db0:      	mov	w19, w0
    2db4:      	mov	x0, x21
    2db8:      	bl	0x2db8 <_stogir.vector.validate+0x470>
		0000000000002db8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2dbc:      	cmp	x0, #0x0
    2dc0:      	b.ne	0x2bc4 <_stogir.vector.validate+0x27c>
    2dc4:      	uxtb	w27, w27
    2dc8:      	sxtw	x28, w28
    2dcc:      	orr	x0, x27, xzr
    2dd0:      	orr	w20, w0, wzr
    2dd4:      	cmp	x25, #0x5b
    2dd8:      	b.ne	0x2e64 <_stogir.vector.validate+0x51c>
    2ddc:      	str	w20, [sp, #0x220]
    2de0:      	cmp	x28, #0x2
    2de4:      	b.ne	0x2e4c <_stogir.vector.validate+0x504>
    2de8:      	add	x16, sp, #0x40
    2dec:      	ldr	w0, [x16, #0x4]
    2df0:      	add	x16, sp, #0x40
    2df4:      	ldr	w1, [x16, #0x8]
    2df8:      	add	x8, sp, #0x130
    2dfc:      	mov	w2, w23
    2e00:      	mov	w3, w0
    2e04:      	mov	x0, x21
    2e08:      	mov	w4, w1
    2e0c:      	ldr	w1, [sp, #0x220]
    2e10:      	bl	0x2e10 <_stogir.vector.validate+0x4c8>
		0000000000002e10:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    2e14:      	add	x16, sp, #0x130
    2e18:      	ldr	x0, [x16]
    2e1c:      	add	x16, sp, #0x130
    2e20:      	ldr	x19, [x16, #0x8]
    2e24:      	add	x16, sp, #0x130
    2e28:      	ldr	x25, [x16, #0x10]
    2e2c:      	b	0x2e60 <_stogir.vector.validate+0x518>
    2e30:      	str	x20, [sp, #0x1c8]
    2e34:      	str	w19, [sp, #0x1c0]
    2e38:      	mov	w19, w0
    2e3c:      	mov	w20, w1
    2e40:      	str	w2, [sp, #0x1d0]
    2e44:      	str	w3, [sp, #0x1d8]
    2e48:      	b	0x2bc4 <_stogir.vector.validate+0x27c>
    2e4c:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002e4c:  ARM64_RELOC_PAGE21	l_stogir.351
    2e50:      	ldr	x16, [x16]
		0000000000002e50:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    2e54:      	orr	x19, x16, xzr
    2e58:      	mov	x0, #0x1                ; =1
    2e5c:      	mov	x25, #0x19              ; =25
    2e60:      	b	0x2c00 <_stogir.vector.validate+0x2b8>
    2e64:      	cmp	x25, #0x5c
    2e68:      	b.eq	0x344c <_stogir.vector.validate+0xb04>
    2e6c:      	cmp	x25, #0x5d
    2e70:      	b.eq	0x2ee0 <_stogir.vector.validate+0x598>
    2e74:      	cmp	x25, #0x5e
    2e78:      	b.eq	0x2ee0 <_stogir.vector.validate+0x598>
    2e7c:      	cmp	x25, #0x43
    2e80:      	b.ne	0x2f48 <_stogir.vector.validate+0x600>
    2e84:      	mov	w0, w20
    2e88:      	bl	0x2e88 <_stogir.vector.validate+0x540>
		0000000000002e88:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2e8c:      	cmp	x0, #0x0
    2e90:      	b.eq	0x2f60 <_stogir.vector.validate+0x618>
    2e94:      	mov	w0, w20
    2e98:      	mov	w1, w23
    2e9c:      	bl	0x2e9c <_stogir.vector.validate+0x554>
		0000000000002e9c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2ea0:      	sxtw	x0, w0
    2ea4:      	cmp	x0, #0x0
    2ea8:      	b.le	0x2f60 <_stogir.vector.validate+0x618>
    2eac:      	cmp	x28, #0x3
    2eb0:      	b.lt	0x2f60 <_stogir.vector.validate+0x618>
    2eb4:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002eb4:  ARM64_RELOC_PAGE21	l_stogir.352
    2eb8:      	ldr	x16, [x16]
		0000000000002eb8:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    2ebc:      	orr	x19, x16, xzr
    2ec0:      	movz	x25, #0x0, lsl #48
    2ec4:      	b	0x2f70 <_stogir.vector.validate+0x628>
    2ec8:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002ec8:  ARM64_RELOC_PAGE21	l_stogir.353
    2ecc:      	ldr	x16, [x16]
		0000000000002ecc:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    2ed0:      	orr	x19, x16, xzr
    2ed4:      	mov	x0, #0x1                ; =1
    2ed8:      	mov	x25, #0x1a              ; =26
    2edc:      	b	0x2e60 <_stogir.vector.validate+0x518>
    2ee0:      	cmp	x28, #0x3
    2ee4:      	b.ne	0x2ec8 <_stogir.vector.validate+0x580>
    2ee8:      	cmp	x27, #0x0
    2eec:      	b.ne	0x2ec8 <_stogir.vector.validate+0x580>
    2ef0:      	add	x16, sp, #0x40
    2ef4:      	ldr	w0, [x16, #0x4]
    2ef8:      	add	x16, sp, #0x40
    2efc:      	ldr	w1, [x16, #0x8]
    2f00:      	add	x16, sp, #0x40
    2f04:      	ldr	w2, [x16, #0xc]
    2f08:      	add	x8, sp, #0x150
    2f0c:      	mov	w3, w1
    2f10:      	mov	w1, w23
    2f14:      	mov	w4, w2
    2f18:      	mov	w2, w0
    2f1c:      	mov	x0, x21
    2f20:      	bl	0x2f20 <_stogir.vector.validate+0x5d8>
		0000000000002f20:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    2f24:      	add	x16, sp, #0x150
    2f28:      	ldr	x0, [x16]
    2f2c:      	add	x16, sp, #0x150
    2f30:      	ldr	x19, [x16, #0x8]
    2f34:      	add	x16, sp, #0x150
    2f38:      	ldr	x25, [x16, #0x10]
    2f3c:      	b	0x2edc <_stogir.vector.validate+0x594>
    2f40:      	mov	x0, #0x1                ; =1
    2f44:      	b	0x2edc <_stogir.vector.validate+0x594>
    2f48:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002f48:  ARM64_RELOC_PAGE21	l_stogir.354
    2f4c:      	ldr	x16, [x16]
		0000000000002f4c:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    2f50:      	orr	x19, x16, xzr
    2f54:      	mov	x0, #0x1                ; =1
    2f58:      	mov	x25, #0x28              ; =40
    2f5c:      	b	0x2f44 <_stogir.vector.validate+0x5fc>
    2f60:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002f60:  ARM64_RELOC_PAGE21	l_stogir.355
    2f64:      	ldr	x16, [x16]
		0000000000002f64:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    2f68:      	orr	x19, x16, xzr
    2f6c:      	mov	x25, #0x20              ; =32
    2f70:      	add	x16, sp, #0x40
    2f74:      	ldr	w0, [x16, #0x4]
    2f78:      	add	x8, sp, #0x170
    2f7c:      	mov	w1, w0
    2f80:      	mov	x0, x21
    2f84:      	bl	0x2f84 <_stogir.vector.validate+0x63c>
		0000000000002f84:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    2f88:      	add	x16, sp, #0x170
    2f8c:      	ldr	w0, [x16]
    2f90:      	lsr	x16, x0, #0
    2f94:      	cmp	x16, #0x1
    2f98:      	b.eq	0x2fb4 <_stogir.vector.validate+0x66c>
    2f9c:      	b.lo	0x2fa4 <_stogir.vector.validate+0x65c>
    2fa0:      	b	0x2fb8 <_stogir.vector.validate+0x670>
    2fa4:      	cmp	x16, #0x0
    2fa8:      	b.eq	0x2fb0 <_stogir.vector.validate+0x668>
    2fac:      	b	0x2fb8 <_stogir.vector.validate+0x670>
    2fb0:      	b	0x2fbc <_stogir.vector.validate+0x674>
    2fb4:      	b	0x335c <_stogir.vector.validate+0xa14>
    2fb8:      	b	0x341c <_stogir.vector.validate+0xad4>
    2fbc:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002fbc:  ARM64_RELOC_PAGE21	l_stogir.356
    2fc0:      	ldr	x16, [x16]
		0000000000002fc0:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    2fc4:      	orr	x19, x16, xzr
    2fc8:      	mov	x25, #0x19              ; =25
    2fcc:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002fcc:  ARM64_RELOC_PAGE21	l_stogir.357
    2fd0:      	ldr	x16, [x16]
		0000000000002fd0:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    2fd4:      	orr	x0, x16, xzr
    2fd8:      	add	x16, sp, #0x1b0
    2fdc:      	orr	x1, x16, xzr
    2fe0:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x5c>
		0000000000002fe0:  ARM64_RELOC_PAGE21	l_stogir.358
    2fe4:      	ldr	x16, [x16]
		0000000000002fe4:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    2fe8:      	orr	x2, x16, xzr
    2fec:      	add	x3, x21, #0x78
    2ff0:      	add	x4, x21, #0x28
    2ff4:      	add	x5, x21, #0x50
    2ff8:      	add	x6, x21, #0x78
    2ffc:      	mov	x7, #0x2                ; =2
    3000:      	b	0x30f8 <_stogir.vector.validate+0x7b0>
    3004:      	add	x16, sp, #0x1b0
    3008:      	str	x9, [x16]
    300c:      	add	x16, sp, #0x1b0
    3010:      	str	x8, [x16, #0x8]
    3014:      	str	x0, [sp, #0x1e8]
    3018:      	mov	x0, x1
    301c:      	str	x1, [sp, #0x1f0]
    3020:      	str	x2, [sp, #0x1f8]
    3024:      	str	x3, [sp, #0x200]
    3028:      	str	x4, [sp, #0x208]
    302c:      	str	x5, [sp, #0x210]
    3030:      	str	x6, [sp, #0x218]
    3034:      	str	w20, [sp, #0x220]
    3038:      	mov	x20, x7
    303c:      	bl	0x303c <_stogir.vector.validate+0x6f4>
		000000000000303c:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    3040:      	uxtb	w0, w0
    3044:      	cmp	x0, x27
    3048:      	b.eq	0x3054 <_stogir.vector.validate+0x70c>
    304c:      	ldr	x19, [sp, #0x1f8]
    3050:      	mov	x25, #0x1e              ; =30
    3054:      	b	0x30cc <_stogir.vector.validate+0x784>
    3058:      	movz	w9, #0x0, lsl #16
    305c:      	movz	w8, #0x0, lsl #16
    3060:      	b	0x3070 <_stogir.vector.validate+0x728>
    3064:      	nop
    3068:      	movz	w9, #0x0, lsl #16
    306c:      	movz	w8, #0x0, lsl #16
    3070:      	ubfx	x9, x9, #0, #32
    3074:      	lsr	x16, x9, #0
    3078:      	cmp	x16, #0x1
    307c:      	b.eq	0x3098 <_stogir.vector.validate+0x750>
    3080:      	b.lo	0x3088 <_stogir.vector.validate+0x740>
    3084:      	b	0x309c <_stogir.vector.validate+0x754>
    3088:      	cmp	x16, #0x0
    308c:      	b.eq	0x3094 <_stogir.vector.validate+0x74c>
    3090:      	b	0x309c <_stogir.vector.validate+0x754>
    3094:      	b	0x30a0 <_stogir.vector.validate+0x758>
    3098:      	b	0x314c <_stogir.vector.validate+0x804>
    309c:      	b	0x340c <_stogir.vector.validate+0xac4>
    30a0:      	str	x0, [sp, #0x1e8]
    30a4:      	str	x1, [sp, #0x1f0]
    30a8:      	str	x2, [sp, #0x1f8]
    30ac:      	str	w20, [sp, #0x220]
    30b0:      	mov	x20, x7
    30b4:      	str	x3, [sp, #0x200]
    30b8:      	str	x4, [sp, #0x208]
    30bc:      	str	x5, [sp, #0x210]
    30c0:      	str	x6, [sp, #0x218]
    30c4:      	mov	x19, x0
    30c8:      	mov	x25, #0x18              ; =24
    30cc:      	add	x0, x20, #0x1
    30d0:      	sxtw	x20, w0
    30d4:      	ldr	x0, [sp, #0x1e8]
    30d8:      	ldr	x1, [sp, #0x1f0]
    30dc:      	ldr	x2, [sp, #0x1f8]
    30e0:      	ldr	x3, [sp, #0x200]
    30e4:      	ldr	x4, [sp, #0x208]
    30e8:      	ldr	x5, [sp, #0x210]
    30ec:      	ldr	x6, [sp, #0x218]
    30f0:      	mov	x7, x20
    30f4:      	ldr	w20, [sp, #0x220]
    30f8:      	cmp	x25, #0x0
    30fc:      	b.ne	0x3454 <_stogir.vector.validate+0xb0c>
    3100:      	cmp	x7, x28
    3104:      	b.gt	0x345c <_stogir.vector.validate+0xb14>
    3108:      	uxtb	w16, w24
    310c:      	cmp	w16, wzr
    3110:      	b.ne	0x3068 <_stogir.vector.validate+0x720>
    3114:      	ldr	x8, [x21, #0x8]
    3118:      	cmp	x22, x8
    311c:      	b.ge	0x31b0 <_stogir.vector.validate+0x868>
    3120:      	ldr	x8, [x6, #0x8]
    3124:      	cmp	x22, x8
    3128:      	b.ge	0x31a8 <_stogir.vector.validate+0x860>
    312c:      	ldr	x8, [x21, #0x78]
    3130:      	add	x8, x26, x8
    3134:      	ldr	w8, [x8]
    3138:      	sxtw	x8, w8
    313c:      	cmp	x8, #0x0
    3140:      	cset	w8, ge
    3144:      	ubfx	x8, x8, #0, #8
    3148:      	b	0x31ac <_stogir.vector.validate+0x864>
    314c:      	sxtw	x8, w8
    3150:      	cmp	x8, #0x0
    3154:      	cset	w9, gt
    3158:      	movz	x16, #0x0, lsl #48
    315c:      	sub	x10, x16, x8
    3160:      	sub	x11, x10, #0x1
    3164:      	uxtb	w16, w9
    3168:      	cmp	w16, wzr
    316c:      	b.eq	0x322c <_stogir.vector.validate+0x8e4>
    3170:      	ldr	x10, [x21, #0x8]
    3174:      	cmp	x8, x10
    3178:      	b.ge	0x3294 <_stogir.vector.validate+0x94c>
    317c:      	ldr	x10, [x3, #0x8]
    3180:      	cmp	x8, x10
    3184:      	b.ge	0x3354 <_stogir.vector.validate+0xa0c>
    3188:      	ldr	x10, [x21, #0x78]
    318c:      	add	x10, x10, x8, lsl #2
    3190:      	ldr	w10, [x10]
    3194:      	sxtw	x10, w10
    3198:      	cmp	x10, #0x0
    319c:      	cset	w10, ge
    31a0:      	ubfx	x10, x10, #0, #8
    31a4:      	b	0x3358 <_stogir.vector.validate+0xa10>
    31a8:      	movz	x8, #0x0, lsl #48
    31ac:      	b	0x31b4 <_stogir.vector.validate+0x86c>
    31b0:      	movz	x8, #0x0, lsl #48
    31b4:      	cmp	x8, #0x0
    31b8:      	b.eq	0x3068 <_stogir.vector.validate+0x720>
    31bc:      	orr	w8, w7, wzr
    31c0:      	sxtw	x8, w8
    31c4:      	cmp	x8, #0x1
    31c8:      	b.lt	0x3058 <_stogir.vector.validate+0x710>
    31cc:      	ldr	x9, [x21, #0x78]
    31d0:      	add	x9, x26, x9
    31d4:      	ldr	w9, [x9]
    31d8:      	sxtw	x9, w9
    31dc:      	cmp	x8, x9
    31e0:      	b.gt	0x3058 <_stogir.vector.validate+0x710>
    31e4:      	ldr	x9, [x21]
    31e8:      	asr	x16, x8, #63
    31ec:      	lsr	x16, x16, #62
    31f0:      	add	x10, x8, x16
    31f4:      	asr	x10, x10, #2
    31f8:      	asr	x16, x8, #63
    31fc:      	lsr	x16, x16, #62
    3200:      	add	x8, x8, x16
    3204:      	and	x8, x8, #0x3
    3208:      	sub	x8, x8, x16
    320c:      	add	x10, x10, x22
    3210:      	add	x9, x9, x10, lsl #4
    3214:      	add	x8, x9, x8, lsl #2
    3218:      	ldr	w8, [x8]
    321c:      	movn	w17, #0x0, lsl #16
    3220:      	and	w8, w8, w17
    3224:      	mov	w9, #0x1                ; =1
    3228:      	b	0x3060 <_stogir.vector.validate+0x718>
    322c:      	cmp	x8, #0x0
    3230:      	b.ge	0x329c <_stogir.vector.validate+0x954>
    3234:      	ldr	x12, [x4, #0x8]
    3238:      	ldr	x13, [x5, #0x8]
    323c:      	cmp	x12, x13
    3240:      	b.ne	0x334c <_stogir.vector.validate+0xa04>
    3244:      	cmp	x10, x12
    3248:      	b.gt	0x3404 <_stogir.vector.validate+0xabc>
    324c:      	ldr	x10, [x21, #0x50]
    3250:      	add	x10, x10, x11, lsl #2
    3254:      	ldr	w10, [x10]
    3258:      	sxtw	x10, w10
    325c:      	cmp	x10, #0x0
    3260:      	cset	w10, gt
    3264:      	ubfx	x10, x10, #0, #8
    3268:      	b	0x3408 <_stogir.vector.validate+0xac0>
    326c:      	cmp	x25, #0x0
    3270:      	b.ne	0x2f40 <_stogir.vector.validate+0x5f8>
    3274:      	ldr	w0, [sp, #0x220]
    3278:      	mov	w1, w23
    327c:      	bl	0x327c <_stogir.vector.validate+0x934>
		000000000000327c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3280:      	sxtw	x0, w0
    3284:      	and	x19, x0, #0xffffffff
    3288:      	movz	x0, #0x0, lsl #48
    328c:      	movz	x25, #0x0, lsl #48
    3290:      	b	0x2f44 <_stogir.vector.validate+0x5fc>
    3294:      	movz	x10, #0x0, lsl #48
    3298:      	b	0x32a0 <_stogir.vector.validate+0x958>
    329c:      	movz	x10, #0x0, lsl #48
    32a0:      	cmp	x10, #0x0
    32a4:      	b.eq	0x32e0 <_stogir.vector.validate+0x998>
    32a8:      	uxtb	w16, w9
    32ac:      	cmp	w16, wzr
    32b0:      	b.eq	0x32c8 <_stogir.vector.validate+0x980>
    32b4:      	ldr	x9, [x21]
    32b8:      	add	x8, x9, x8, lsl #4
    32bc:      	ldr	x9, [x8]
    32c0:      	ldr	x8, [x8, #0x8]
    32c4:      	b	0x32d8 <_stogir.vector.validate+0x990>
    32c8:      	ldr	x8, [x21, #0x28]
    32cc:      	add	x8, x8, x11, lsl #4
    32d0:      	ldr	x9, [x8]
    32d4:      	ldr	x8, [x8, #0x8]
    32d8:      	mov	w10, #0x1               ; =1
    32dc:      	b	0x32ec <_stogir.vector.validate+0x9a4>
    32e0:      	movz	w10, #0x0, lsl #16
    32e4:      	movz	x9, #0x0, lsl #48
    32e8:      	movz	x8, #0x0, lsl #48
    32ec:      	ubfx	x10, x10, #0, #32
    32f0:      	lsr	x16, x10, #0
    32f4:      	cmp	x16, #0x1
    32f8:      	b.eq	0x3314 <_stogir.vector.validate+0x9cc>
    32fc:      	b.lo	0x3304 <_stogir.vector.validate+0x9bc>
    3300:      	b	0x3318 <_stogir.vector.validate+0x9d0>
    3304:      	cmp	x16, #0x0
    3308:      	b.eq	0x3310 <_stogir.vector.validate+0x9c8>
    330c:      	b	0x3318 <_stogir.vector.validate+0x9d0>
    3310:      	b	0x331c <_stogir.vector.validate+0x9d4>
    3314:      	b	0x3004 <_stogir.vector.validate+0x6bc>
    3318:      	b	0x3414 <_stogir.vector.validate+0xacc>
    331c:      	str	x0, [sp, #0x1e8]
    3320:      	str	x1, [sp, #0x1f0]
    3324:      	str	x2, [sp, #0x1f8]
    3328:      	str	w20, [sp, #0x220]
    332c:      	mov	x20, x7
    3330:      	str	x3, [sp, #0x200]
    3334:      	str	x4, [sp, #0x208]
    3338:      	str	x5, [sp, #0x210]
    333c:      	str	x6, [sp, #0x218]
    3340:      	mov	x19, x0
    3344:      	mov	x25, #0x18              ; =24
    3348:      	b	0x3054 <_stogir.vector.validate+0x70c>
    334c:      	movz	x10, #0x0, lsl #48
    3350:      	b	0x32a0 <_stogir.vector.validate+0x958>
    3354:      	movz	x10, #0x0, lsl #48
    3358:      	b	0x3298 <_stogir.vector.validate+0x950>
    335c:      	add	x16, sp, #0x170
    3360:      	orr	x0, x16, xzr
    3364:      	add	x0, x0, #0x8
    3368:      	add	x16, sp, #0x170
    336c:      	ldr	x1, [x16, #0x8]
    3370:      	add	x16, sp, #0x1a0
    3374:      	str	x1, [x16]
    3378:      	ldr	x0, [x0, #0x8]
    337c:      	add	x16, sp, #0x1a0
    3380:      	str	x0, [x16, #0x8]
    3384:      	add	x16, sp, #0x40
    3388:      	ldr	w0, [x16, #0x4]
    338c:      	sxtw	x0, w0
    3390:      	cmp	x0, #0x0
    3394:      	b.le	0x33f0 <_stogir.vector.validate+0xaa8>
    3398:      	add	x16, sp, #0x1a0
    339c:      	orr	x0, x16, xzr
    33a0:      	str	x0, [sp, #0x1e0]
    33a4:      	bl	0x33a4 <_stogir.vector.validate+0xa5c>
		00000000000033a4:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    33a8:      	uxtb	w0, w0
    33ac:      	cmp	x0, #0x70
    33b0:      	b.eq	0x33c8 <_stogir.vector.validate+0xa80>
    33b4:      	ldr	x0, [sp, #0x1e0]
    33b8:      	bl	0x33b8 <_stogir.vector.validate+0xa70>
		00000000000033b8:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    33bc:      	uxtb	w0, w0
    33c0:      	cmp	x0, #0x71
    33c4:      	b.ne	0x33f0 <_stogir.vector.validate+0xaa8>
    33c8:      	add	x16, sp, #0x40
    33cc:      	ldr	w0, [x16, #0x4]
    33d0:      	sxtw	x0, w0
    33d4:      	ldr	x1, [x21, #0x78]
    33d8:      	add	x0, x1, x0, lsl #2
    33dc:      	ldr	w0, [x0]
    33e0:      	add	w0, w0, #0x1
    33e4:      	sxtw	x0, w0
    33e8:      	cmp	x28, x0
    33ec:      	b.eq	0x3400 <_stogir.vector.validate+0xab8>
    33f0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		00000000000033f0:  ARM64_RELOC_PAGE21	l_stogir.359
    33f4:      	ldr	x16, [x16]
		00000000000033f4:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    33f8:      	orr	x19, x16, xzr
    33fc:      	mov	x25, #0x19              ; =25
    3400:      	b	0x2fcc <_stogir.vector.validate+0x684>
    3404:      	movz	x10, #0x0, lsl #48
    3408:      	b	0x3350 <_stogir.vector.validate+0xa08>
    340c:      	brk	#0
    3410:      	b	0x340c <_stogir.vector.validate+0xac4>
    3414:      	brk	#0
    3418:      	b	0x3414 <_stogir.vector.validate+0xacc>
    341c:      	brk	#0
    3420:      	b	0x341c <_stogir.vector.validate+0xad4>
    3424:      	str	x20, [sp, #0x1c8]
    3428:      	str	w19, [sp, #0x1c0]
    342c:      	b	0x2b08 <_stogir.vector.validate+0x1c0>
    3430:      	str	x20, [sp, #0x1c8]
    3434:      	str	w19, [sp, #0x1c0]
    3438:      	mov	w19, w0
    343c:      	mov	w20, w1
    3440:      	str	w2, [sp, #0x1d0]
    3444:      	str	w3, [sp, #0x1d8]
    3448:      	b	0x2bc4 <_stogir.vector.validate+0x27c>
    344c:      	str	w20, [sp, #0x220]
    3450:      	b	0x2de0 <_stogir.vector.validate+0x498>
    3454:      	str	w20, [sp, #0x220]
    3458:      	b	0x326c <_stogir.vector.validate+0x924>
    345c:      	str	w20, [sp, #0x220]
    3460:      	b	0x326c <_stogir.vector.validate+0x924>

0000000000003464 <_stogir.copy.validate>:
    3464:      	sub	sp, sp, #0x10
    3468:      	sxtw	x1, w1
    346c:      	lsl	x2, x1, #2
    3470:      	cmp	x1, #0x0
    3474:      	cset	w3, gt
    3478:      	movz	x16, #0x0, lsl #48
    347c:      	sub	x4, x16, x1
    3480:      	sub	x5, x4, #0x1
    3484:      	uxtb	w16, w3
    3488:      	cmp	w16, wzr
    348c:      	b.eq	0x34cc <_stogir.copy.validate+0x68>
    3490:      	ldr	x4, [x0, #0x8]
    3494:      	cmp	x1, x4
    3498:      	b.ge	0x3534 <_stogir.copy.validate+0xd0>
    349c:      	add	x4, x0, #0x78
    34a0:      	ldr	x4, [x4, #0x8]
    34a4:      	cmp	x1, x4
    34a8:      	b.ge	0x36cc <_stogir.copy.validate+0x268>
    34ac:      	ldr	x4, [x0, #0x78]
    34b0:      	add	x4, x2, x4
    34b4:      	ldr	w4, [x4]
    34b8:      	sxtw	x4, w4
    34bc:      	cmp	x4, #0x0
    34c0:      	cset	w4, ge
    34c4:      	ubfx	x4, x4, #0, #8
    34c8:      	b	0x36d0 <_stogir.copy.validate+0x26c>
    34cc:      	cmp	x1, #0x0
    34d0:      	b.ge	0x353c <_stogir.copy.validate+0xd8>
    34d4:      	add	x6, x0, #0x28
    34d8:      	add	x7, x0, #0x50
    34dc:      	ldr	x6, [x6, #0x8]
    34e0:      	ldr	x7, [x7, #0x8]
    34e4:      	cmp	x6, x7
    34e8:      	b.ne	0x3514 <_stogir.copy.validate+0xb0>
    34ec:      	cmp	x4, x6
    34f0:      	b.gt	0x36d4 <_stogir.copy.validate+0x270>
    34f4:      	ldr	x4, [x0, #0x50]
    34f8:      	add	x4, x4, x5, lsl #2
    34fc:      	ldr	w4, [x4]
    3500:      	sxtw	x4, w4
    3504:      	cmp	x4, #0x0
    3508:      	cset	w4, gt
    350c:      	ubfx	x4, x4, #0, #8
    3510:      	b	0x36d8 <_stogir.copy.validate+0x274>
    3514:      	movz	x4, #0x0, lsl #48
    3518:      	b	0x3540 <_stogir.copy.validate+0xdc>
    351c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		000000000000351c:  ARM64_RELOC_PAGE21	l_stogir.360
    3520:      	ldr	x16, [x16]
		0000000000003520:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    3524:      	orr	x0, x16, xzr
    3528:      	mov	x1, #0x1                ; =1
    352c:      	mov	x2, #0x21               ; =33
    3530:      	b	0x35d0 <_stogir.copy.validate+0x16c>
    3534:      	movz	x4, #0x0, lsl #48
    3538:      	b	0x3540 <_stogir.copy.validate+0xdc>
    353c:      	movz	x4, #0x0, lsl #48
    3540:      	cmp	x4, #0x0
    3544:      	b.eq	0x3580 <_stogir.copy.validate+0x11c>
    3548:      	uxtb	w16, w3
    354c:      	cmp	w16, wzr
    3550:      	b.eq	0x3568 <_stogir.copy.validate+0x104>
    3554:      	ldr	x3, [x0]
    3558:      	add	x3, x3, x1, lsl #4
    355c:      	ldr	x4, [x3]
    3560:      	ldr	x3, [x3, #0x8]
    3564:      	b	0x3578 <_stogir.copy.validate+0x114>
    3568:      	ldr	x3, [x0, #0x28]
    356c:      	add	x3, x3, x5, lsl #4
    3570:      	ldr	x4, [x3]
    3574:      	ldr	x3, [x3, #0x8]
    3578:      	mov	w5, #0x1                ; =1
    357c:      	b	0x358c <_stogir.copy.validate+0x128>
    3580:      	movz	w5, #0x0, lsl #16
    3584:      	movz	x4, #0x0, lsl #48
    3588:      	movz	x3, #0x0, lsl #48
    358c:      	ubfx	x5, x5, #0, #32
    3590:      	lsr	x16, x5, #0
    3594:      	cmp	x16, #0x1
    3598:      	b.eq	0x35b4 <_stogir.copy.validate+0x150>
    359c:      	b.lo	0x35a4 <_stogir.copy.validate+0x140>
    35a0:      	b	0x35b8 <_stogir.copy.validate+0x154>
    35a4:      	cmp	x16, #0x0
    35a8:      	b.eq	0x35b0 <_stogir.copy.validate+0x14c>
    35ac:      	b	0x35b8 <_stogir.copy.validate+0x154>
    35b0:      	b	0x35bc <_stogir.copy.validate+0x158>
    35b4:      	b	0x35e4 <_stogir.copy.validate+0x180>
    35b8:      	b	0x36dc <_stogir.copy.validate+0x278>
    35bc:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		00000000000035bc:  ARM64_RELOC_PAGE21	l_stogir.361
    35c0:      	ldr	x16, [x16]
		00000000000035c0:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    35c4:      	orr	x0, x16, xzr
    35c8:      	mov	x1, #0x1                ; =1
    35cc:      	mov	x2, #0x18               ; =24
    35d0:      	str	x1, [x8]
    35d4:      	str	x0, [x8, #0x8]
    35d8:      	str	x2, [x8, #0x10]
    35dc:      	add	sp, sp, #0x10
    35e0:      	ret
    35e4:      	mov	x16, sp
    35e8:      	str	x4, [x16]
    35ec:      	mov	x16, sp
    35f0:      	str	x3, [x16, #0x8]
    35f4:      	cmp	x1, #0x0
    35f8:      	b.le	0x351c <_stogir.copy.validate+0xb8>
    35fc:      	uxtb	w1, w4
    3600:      	cmp	x1, #0x44
    3604:      	b.ne	0x351c <_stogir.copy.validate+0xb8>
    3608:      	ldr	x1, [x0, #0x78]
    360c:      	add	x1, x2, x1
    3610:      	ldr	w1, [x1]
    3614:      	sxtw	x1, w1
    3618:      	cmp	x1, #0x2
    361c:      	b.ne	0x351c <_stogir.copy.validate+0xb8>
    3620:      	ubfx	x4, x4, #0, #32
    3624:      	ubfx	x1, x4, #8, #8
    3628:      	orr	x2, x1, xzr
    362c:      	cmp	x2, #0x0
    3630:      	b.eq	0x351c <_stogir.copy.validate+0xb8>
    3634:      	cmp	x2, #0xd
    3638:      	b.le	0x3664 <_stogir.copy.validate+0x200>
    363c:      	cmp	x2, #0xf
    3640:      	b.le	0x351c <_stogir.copy.validate+0xb8>
    3644:      	cmp	x2, #0x80
    3648:      	b.ge	0x351c <_stogir.copy.validate+0xb8>
    364c:      	and	w1, w1, #0xf
    3650:      	ubfx	x1, x1, #0, #32
    3654:      	cmp	x1, #0x1
    3658:      	b.lt	0x351c <_stogir.copy.validate+0xb8>
    365c:      	cmp	x1, #0xd
    3660:      	b.gt	0x351c <_stogir.copy.validate+0xb8>
    3664:      	mov	x16, sp
    3668:      	ldr	w1, [x16, #0x4]
    366c:      	sxtw	x1, w1
    3670:      	cmp	x1, #0x0
    3674:      	cset	w3, gt
    3678:      	movz	x16, #0x0, lsl #48
    367c:      	sub	x4, x16, x1
    3680:      	sub	x5, x4, #0x1
    3684:      	uxtb	w16, w3
    3688:      	cmp	w16, wzr
    368c:      	b.eq	0x36fc <_stogir.copy.validate+0x298>
    3690:      	ldr	x4, [x0, #0x8]
    3694:      	cmp	x1, x4
    3698:      	b.ge	0x3744 <_stogir.copy.validate+0x2e0>
    369c:      	add	x4, x0, #0x78
    36a0:      	ldr	x4, [x4, #0x8]
    36a4:      	cmp	x1, x4
    36a8:      	b.ge	0x380c <_stogir.copy.validate+0x3a8>
    36ac:      	ldr	x4, [x0, #0x78]
    36b0:      	add	x4, x4, x1, lsl #2
    36b4:      	ldr	w4, [x4]
    36b8:      	sxtw	x4, w4
    36bc:      	cmp	x4, #0x0
    36c0:      	cset	w4, ge
    36c4:      	ubfx	x4, x4, #0, #8
    36c8:      	b	0x3810 <_stogir.copy.validate+0x3ac>
    36cc:      	movz	x4, #0x0, lsl #48
    36d0:      	b	0x3538 <_stogir.copy.validate+0xd4>
    36d4:      	movz	x4, #0x0, lsl #48
    36d8:      	b	0x3518 <_stogir.copy.validate+0xb4>
    36dc:      	brk	#0
    36e0:      	b	0x36dc <_stogir.copy.validate+0x278>
    36e4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		00000000000036e4:  ARM64_RELOC_PAGE21	l_stogir.362
    36e8:      	ldr	x16, [x16]
		00000000000036e8:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    36ec:      	orr	x0, x16, xzr
    36f0:      	mov	x1, #0x1                ; =1
    36f4:      	mov	x2, #0x20               ; =32
    36f8:      	b	0x3530 <_stogir.copy.validate+0xcc>
    36fc:      	cmp	x1, #0x0
    3700:      	b.ge	0x374c <_stogir.copy.validate+0x2e8>
    3704:      	add	x6, x0, #0x28
    3708:      	add	x7, x0, #0x50
    370c:      	ldr	x6, [x6, #0x8]
    3710:      	ldr	x7, [x7, #0x8]
    3714:      	cmp	x6, x7
    3718:      	b.ne	0x3804 <_stogir.copy.validate+0x3a0>
    371c:      	cmp	x4, x6
    3720:      	b.gt	0x3814 <_stogir.copy.validate+0x3b0>
    3724:      	ldr	x4, [x0, #0x50]
    3728:      	add	x4, x4, x5, lsl #2
    372c:      	ldr	w4, [x4]
    3730:      	sxtw	x4, w4
    3734:      	cmp	x4, #0x0
    3738:      	cset	w4, gt
    373c:      	ubfx	x4, x4, #0, #8
    3740:      	b	0x3818 <_stogir.copy.validate+0x3b4>
    3744:      	movz	x4, #0x0, lsl #48
    3748:      	b	0x3750 <_stogir.copy.validate+0x2ec>
    374c:      	movz	x4, #0x0, lsl #48
    3750:      	cmp	x4, #0x0
    3754:      	b.eq	0x3788 <_stogir.copy.validate+0x324>
    3758:      	uxtb	w16, w3
    375c:      	cmp	w16, wzr
    3760:      	b.eq	0x3774 <_stogir.copy.validate+0x310>
    3764:      	ldr	x0, [x0]
    3768:      	add	x0, x0, x1, lsl #4
    376c:      	ldr	x0, [x0]
    3770:      	b	0x3780 <_stogir.copy.validate+0x31c>
    3774:      	ldr	x0, [x0, #0x28]
    3778:      	add	x0, x0, x5, lsl #4
    377c:      	ldr	x0, [x0]
    3780:      	mov	w1, #0x1                ; =1
    3784:      	b	0x3790 <_stogir.copy.validate+0x32c>
    3788:      	movz	w1, #0x0, lsl #16
    378c:      	movz	x0, #0x0, lsl #48
    3790:      	ubfx	x1, x1, #0, #32
    3794:      	lsr	x16, x1, #0
    3798:      	cmp	x16, #0x1
    379c:      	b.eq	0x37b8 <_stogir.copy.validate+0x354>
    37a0:      	b.lo	0x37a8 <_stogir.copy.validate+0x344>
    37a4:      	b	0x37bc <_stogir.copy.validate+0x358>
    37a8:      	cmp	x16, #0x0
    37ac:      	b.eq	0x37b4 <_stogir.copy.validate+0x350>
    37b0:      	b	0x37bc <_stogir.copy.validate+0x358>
    37b4:      	b	0x37c0 <_stogir.copy.validate+0x35c>
    37b8:      	b	0x37d8 <_stogir.copy.validate+0x374>
    37bc:      	b	0x381c <_stogir.copy.validate+0x3b8>
    37c0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		00000000000037c0:  ARM64_RELOC_PAGE21	l_stogir.363
    37c4:      	ldr	x16, [x16]
		00000000000037c4:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    37c8:      	orr	x0, x16, xzr
    37cc:      	mov	x1, #0x1                ; =1
    37d0:      	mov	x2, #0x13               ; =19
    37d4:      	b	0x36f8 <_stogir.copy.validate+0x294>
    37d8:      	mov	x16, sp
    37dc:      	ldr	w1, [x16]
    37e0:      	ubfx	x0, x0, #0, #32
    37e4:      	ubfx	x0, x0, #8, #8
    37e8:      	ubfx	x1, x1, #8, #8
    37ec:      	cmp	x0, x1
    37f0:      	b.ne	0x36e4 <_stogir.copy.validate+0x280>
    37f4:      	and	x0, x2, #0xffffffff
    37f8:      	movz	x1, #0x0, lsl #48
    37fc:      	movz	x2, #0x0, lsl #48
    3800:      	b	0x36f8 <_stogir.copy.validate+0x294>
    3804:      	movz	x4, #0x0, lsl #48
    3808:      	b	0x3750 <_stogir.copy.validate+0x2ec>
    380c:      	movz	x4, #0x0, lsl #48
    3810:      	b	0x3748 <_stogir.copy.validate+0x2e4>
    3814:      	movz	x4, #0x0, lsl #48
    3818:      	b	0x3808 <_stogir.copy.validate+0x3a4>
    381c:      	brk	#0
    3820:      	b	0x381c <_stogir.copy.validate+0x3b8>

0000000000003824 <_stogir.graph.lookup>:
    3824:      	sxtw	x1, w1
    3828:      	cmp	x1, #0x0
    382c:      	cset	w2, gt
    3830:      	movz	x16, #0x0, lsl #48
    3834:      	sub	x3, x16, x1
    3838:      	sub	x4, x3, #0x1
    383c:      	uxtb	w16, w2
    3840:      	cmp	w16, wzr
    3844:      	b.eq	0x3884 <_stogir.graph.lookup+0x60>
    3848:      	ldr	x3, [x0, #0x8]
    384c:      	cmp	x1, x3
    3850:      	b.ge	0x38d4 <_stogir.graph.lookup+0xb0>
    3854:      	add	x3, x0, #0x78
    3858:      	ldr	x3, [x3, #0x8]
    385c:      	cmp	x1, x3
    3860:      	b.ge	0x394c <_stogir.graph.lookup+0x128>
    3864:      	ldr	x3, [x0, #0x78]
    3868:      	add	x3, x3, x1, lsl #2
    386c:      	ldr	w3, [x3]
    3870:      	sxtw	x3, w3
    3874:      	cmp	x3, #0x0
    3878:      	cset	w3, ge
    387c:      	ubfx	x3, x3, #0, #8
    3880:      	b	0x3950 <_stogir.graph.lookup+0x12c>
    3884:      	cmp	x1, #0x0
    3888:      	b.ge	0x38dc <_stogir.graph.lookup+0xb8>
    388c:      	add	x5, x0, #0x28
    3890:      	add	x6, x0, #0x50
    3894:      	ldr	x5, [x5, #0x8]
    3898:      	ldr	x6, [x6, #0x8]
    389c:      	cmp	x5, x6
    38a0:      	b.ne	0x38cc <_stogir.graph.lookup+0xa8>
    38a4:      	cmp	x3, x5
    38a8:      	b.gt	0x3954 <_stogir.graph.lookup+0x130>
    38ac:      	ldr	x3, [x0, #0x50]
    38b0:      	add	x3, x3, x4, lsl #2
    38b4:      	ldr	w3, [x3]
    38b8:      	sxtw	x3, w3
    38bc:      	cmp	x3, #0x0
    38c0:      	cset	w3, gt
    38c4:      	ubfx	x3, x3, #0, #8
    38c8:      	b	0x3958 <_stogir.graph.lookup+0x134>
    38cc:      	movz	x3, #0x0, lsl #48
    38d0:      	b	0x38e0 <_stogir.graph.lookup+0xbc>
    38d4:      	movz	x3, #0x0, lsl #48
    38d8:      	b	0x38e0 <_stogir.graph.lookup+0xbc>
    38dc:      	movz	x3, #0x0, lsl #48
    38e0:      	cmp	x3, #0x0
    38e4:      	b.eq	0x3920 <_stogir.graph.lookup+0xfc>
    38e8:      	uxtb	w16, w2
    38ec:      	cmp	w16, wzr
    38f0:      	b.eq	0x3908 <_stogir.graph.lookup+0xe4>
    38f4:      	ldr	x0, [x0]
    38f8:      	add	x0, x0, x1, lsl #4
    38fc:      	ldr	x1, [x0]
    3900:      	ldr	x0, [x0, #0x8]
    3904:      	b	0x3918 <_stogir.graph.lookup+0xf4>
    3908:      	ldr	x0, [x0, #0x28]
    390c:      	add	x0, x0, x4, lsl #4
    3910:      	ldr	x1, [x0]
    3914:      	ldr	x0, [x0, #0x8]
    3918:      	mov	x2, #0x1                ; =1
    391c:      	b	0x392c <_stogir.graph.lookup+0x108>
    3920:      	movz	x2, #0x0, lsl #48
    3924:      	movz	x1, #0x0, lsl #48
    3928:      	movz	x0, #0x0, lsl #48
    392c:      	str	x2, [x8]
    3930:      	str	x1, [x8, #0x8]
    3934:      	str	x0, [x8, #0x10]
    3938:      	movz	x17, #0x0, lsl #48
    393c:      	str	x17, [x8, #0x18]
    3940:      	movz	x17, #0x0, lsl #48
    3944:      	str	x17, [x8, #0x20]
    3948:      	ret
    394c:      	movz	x3, #0x0, lsl #48
    3950:      	b	0x38d8 <_stogir.graph.lookup+0xb4>
    3954:      	movz	x3, #0x0, lsl #48
    3958:      	b	0x38d0 <_stogir.graph.lookup+0xac>

000000000000395c <_stogir.checked.validate-projection>:
    395c:      	sub	sp, sp, #0x40
    3960:      	str	x29, [sp]
    3964:      	str	x30, [sp, #0x8]
    3968:      	mov	x29, sp
    396c:      	str	x19, [sp, #0x30]
    3970:      	sxtw	x1, w1
    3974:      	lsl	x2, x1, #2
    3978:      	cmp	x1, #0x0
    397c:      	cset	w3, gt
    3980:      	movz	x16, #0x0, lsl #48
    3984:      	sub	x4, x16, x1
    3988:      	sub	x5, x4, #0x1
    398c:      	uxtb	w16, w3
    3990:      	cmp	w16, wzr
    3994:      	b.eq	0x39d4 <_stogir.checked.validate-projection+0x78>
    3998:      	ldr	x4, [x0, #0x8]
    399c:      	cmp	x1, x4
    39a0:      	b.ge	0x3a24 <_stogir.checked.validate-projection+0xc8>
    39a4:      	add	x4, x0, #0x78
    39a8:      	ldr	x4, [x4, #0x8]
    39ac:      	cmp	x1, x4
    39b0:      	b.ge	0x3afc <_stogir.checked.validate-projection+0x1a0>
    39b4:      	ldr	x4, [x0, #0x78]
    39b8:      	add	x4, x2, x4
    39bc:      	ldr	w4, [x4]
    39c0:      	sxtw	x4, w4
    39c4:      	cmp	x4, #0x0
    39c8:      	cset	w4, ge
    39cc:      	ubfx	x4, x4, #0, #8
    39d0:      	b	0x3b00 <_stogir.checked.validate-projection+0x1a4>
    39d4:      	cmp	x1, #0x0
    39d8:      	b.ge	0x3a2c <_stogir.checked.validate-projection+0xd0>
    39dc:      	add	x6, x0, #0x28
    39e0:      	add	x7, x0, #0x50
    39e4:      	ldr	x6, [x6, #0x8]
    39e8:      	ldr	x7, [x7, #0x8]
    39ec:      	cmp	x6, x7
    39f0:      	b.ne	0x3a1c <_stogir.checked.validate-projection+0xc0>
    39f4:      	cmp	x4, x6
    39f8:      	b.gt	0x3b68 <_stogir.checked.validate-projection+0x20c>
    39fc:      	ldr	x4, [x0, #0x50]
    3a00:      	add	x4, x4, x5, lsl #2
    3a04:      	ldr	w4, [x4]
    3a08:      	sxtw	x4, w4
    3a0c:      	cmp	x4, #0x0
    3a10:      	cset	w4, gt
    3a14:      	ubfx	x4, x4, #0, #8
    3a18:      	b	0x3b6c <_stogir.checked.validate-projection+0x210>
    3a1c:      	movz	x4, #0x0, lsl #48
    3a20:      	b	0x3a30 <_stogir.checked.validate-projection+0xd4>
    3a24:      	movz	x4, #0x0, lsl #48
    3a28:      	b	0x3a30 <_stogir.checked.validate-projection+0xd4>
    3a2c:      	movz	x4, #0x0, lsl #48
    3a30:      	cmp	x4, #0x0
    3a34:      	b.eq	0x3a68 <_stogir.checked.validate-projection+0x10c>
    3a38:      	uxtb	w16, w3
    3a3c:      	cmp	w16, wzr
    3a40:      	b.eq	0x3a54 <_stogir.checked.validate-projection+0xf8>
    3a44:      	ldr	x3, [x0]
    3a48:      	add	x3, x3, x1, lsl #4
    3a4c:      	ldr	x3, [x3]
    3a50:      	b	0x3a60 <_stogir.checked.validate-projection+0x104>
    3a54:      	ldr	x3, [x0, #0x28]
    3a58:      	add	x3, x3, x5, lsl #4
    3a5c:      	ldr	x3, [x3]
    3a60:      	mov	w4, #0x1                ; =1
    3a64:      	b	0x3a70 <_stogir.checked.validate-projection+0x114>
    3a68:      	movz	w4, #0x0, lsl #16
    3a6c:      	movz	x3, #0x0, lsl #48
    3a70:      	ubfx	x4, x4, #0, #32
    3a74:      	lsr	x16, x4, #0
    3a78:      	cmp	x16, #0x1
    3a7c:      	b.eq	0x3a98 <_stogir.checked.validate-projection+0x13c>
    3a80:      	b.lo	0x3a88 <_stogir.checked.validate-projection+0x12c>
    3a84:      	b	0x3a9c <_stogir.checked.validate-projection+0x140>
    3a88:      	cmp	x16, #0x0
    3a8c:      	b.eq	0x3a94 <_stogir.checked.validate-projection+0x138>
    3a90:      	b	0x3a9c <_stogir.checked.validate-projection+0x140>
    3a94:      	b	0x3aa0 <_stogir.checked.validate-projection+0x144>
    3a98:      	b	0x3abc <_stogir.checked.validate-projection+0x160>
    3a9c:      	b	0x3b70 <_stogir.checked.validate-projection+0x214>
    3aa0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		0000000000003aa0:  ARM64_RELOC_PAGE21	l_stogir.364
    3aa4:      	ldr	x16, [x16]
		0000000000003aa4:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    3aa8:      	orr	x0, x16, xzr
    3aac:      	mov	x19, x8
    3ab0:      	mov	x1, #0x1                ; =1
    3ab4:      	mov	x2, #0x10               ; =16
    3ab8:      	b	0x3adc <_stogir.checked.validate-projection+0x180>
    3abc:      	cmp	x1, #0x0
    3ac0:      	b.gt	0x3b04 <_stogir.checked.validate-projection+0x1a8>
    3ac4:      	mov	x19, x8
    3ac8:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		0000000000003ac8:  ARM64_RELOC_PAGE21	l_stogir.365
    3acc:      	ldr	x16, [x16]
		0000000000003acc:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    3ad0:      	orr	x0, x16, xzr
    3ad4:      	mov	x1, #0x1                ; =1
    3ad8:      	mov	x2, #0x1c               ; =28
    3adc:      	str	x1, [x19]
    3ae0:      	str	x0, [x19, #0x8]
    3ae4:      	str	x2, [x19, #0x10]
    3ae8:      	ldr	x19, [sp, #0x30]
    3aec:      	ldr	x29, [sp]
    3af0:      	ldr	x30, [sp, #0x8]
    3af4:      	add	sp, sp, #0x40
    3af8:      	ret
    3afc:      	movz	x4, #0x0, lsl #48
    3b00:      	b	0x3a28 <_stogir.checked.validate-projection+0xcc>
    3b04:      	uxtb	w1, w3
    3b08:      	cmp	x1, #0x2c
    3b0c:      	b.ne	0x3b78 <_stogir.checked.validate-projection+0x21c>
    3b10:      	orr	w1, w3, wzr
    3b14:      	ubfx	x1, x1, #0, #32
    3b18:      	ubfx	x1, x1, #8, #8
    3b1c:      	cmp	x1, #0x1
    3b20:      	b.ne	0x3b80 <_stogir.checked.validate-projection+0x224>
    3b24:      	ldr	x1, [x0, #0x78]
    3b28:      	add	x1, x2, x1
    3b2c:      	ldr	w1, [x1]
    3b30:      	sxtw	x1, w1
    3b34:      	cmp	x1, #0x1
    3b38:      	b.ne	0x3b88 <_stogir.checked.validate-projection+0x22c>
    3b3c:      	lsr	x1, x3, #32
    3b40:      	mov	x19, x8
    3b44:      	add	x8, sp, #0x10
    3b48:      	bl	0x3b48 <_stogir.checked.validate-projection+0x1ec>
		0000000000003b48:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    3b4c:      	add	x16, sp, #0x10
    3b50:      	ldr	x1, [x16]
    3b54:      	add	x16, sp, #0x10
    3b58:      	ldr	x0, [x16, #0x8]
    3b5c:      	add	x16, sp, #0x10
    3b60:      	ldr	x2, [x16, #0x10]
    3b64:      	b	0x3adc <_stogir.checked.validate-projection+0x180>
    3b68:      	movz	x4, #0x0, lsl #48
    3b6c:      	b	0x3a20 <_stogir.checked.validate-projection+0xc4>
    3b70:      	brk	#0
    3b74:      	b	0x3b70 <_stogir.checked.validate-projection+0x214>
    3b78:      	mov	x19, x8
    3b7c:      	b	0x3ac8 <_stogir.checked.validate-projection+0x16c>
    3b80:      	mov	x19, x8
    3b84:      	b	0x3ac8 <_stogir.checked.validate-projection+0x16c>
    3b88:      	mov	x19, x8
    3b8c:      	b	0x3ac8 <_stogir.checked.validate-projection+0x16c>

0000000000003b90 <_stogir.checked.validate>:
    3b90:      	sub	sp, sp, #0x30
    3b94:      	str	x29, [sp]
    3b98:      	str	x30, [sp, #0x8]
    3b9c:      	mov	x29, sp
    3ba0:      	str	x19, [sp, #0x10]
    3ba4:      	str	x20, [sp, #0x18]
    3ba8:      	str	x21, [sp, #0x20]
    3bac:      	sxtw	x1, w1
    3bb0:      	lsl	x2, x1, #2
    3bb4:      	cmp	x1, #0x0
    3bb8:      	cset	w3, gt
    3bbc:      	movz	x16, #0x0, lsl #48
    3bc0:      	sub	x4, x16, x1
    3bc4:      	sub	x5, x4, #0x1
    3bc8:      	uxtb	w16, w3
    3bcc:      	cmp	w16, wzr
    3bd0:      	b.eq	0x3c10 <_stogir.checked.validate+0x80>
    3bd4:      	ldr	x4, [x0, #0x8]
    3bd8:      	cmp	x1, x4
    3bdc:      	b.ge	0x3c60 <_stogir.checked.validate+0xd0>
    3be0:      	add	x4, x0, #0x78
    3be4:      	ldr	x4, [x4, #0x8]
    3be8:      	cmp	x1, x4
    3bec:      	b.ge	0x3dc4 <_stogir.checked.validate+0x234>
    3bf0:      	ldr	x4, [x0, #0x78]
    3bf4:      	add	x4, x2, x4
    3bf8:      	ldr	w4, [x4]
    3bfc:      	sxtw	x4, w4
    3c00:      	cmp	x4, #0x0
    3c04:      	cset	w4, ge
    3c08:      	ubfx	x4, x4, #0, #8
    3c0c:      	b	0x3dc8 <_stogir.checked.validate+0x238>
    3c10:      	cmp	x1, #0x0
    3c14:      	b.ge	0x3c68 <_stogir.checked.validate+0xd8>
    3c18:      	add	x6, x0, #0x28
    3c1c:      	add	x7, x0, #0x50
    3c20:      	ldr	x6, [x6, #0x8]
    3c24:      	ldr	x7, [x7, #0x8]
    3c28:      	cmp	x6, x7
    3c2c:      	b.ne	0x3c58 <_stogir.checked.validate+0xc8>
    3c30:      	cmp	x4, x6
    3c34:      	b.gt	0x3dcc <_stogir.checked.validate+0x23c>
    3c38:      	ldr	x4, [x0, #0x50]
    3c3c:      	add	x4, x4, x5, lsl #2
    3c40:      	ldr	w4, [x4]
    3c44:      	sxtw	x4, w4
    3c48:      	cmp	x4, #0x0
    3c4c:      	cset	w4, gt
    3c50:      	ubfx	x4, x4, #0, #8
    3c54:      	b	0x3dd0 <_stogir.checked.validate+0x240>
    3c58:      	movz	x4, #0x0, lsl #48
    3c5c:      	b	0x3c6c <_stogir.checked.validate+0xdc>
    3c60:      	movz	x4, #0x0, lsl #48
    3c64:      	b	0x3c6c <_stogir.checked.validate+0xdc>
    3c68:      	movz	x4, #0x0, lsl #48
    3c6c:      	cmp	x4, #0x0
    3c70:      	b.eq	0x3cac <_stogir.checked.validate+0x11c>
    3c74:      	uxtb	w16, w3
    3c78:      	cmp	w16, wzr
    3c7c:      	b.eq	0x3c94 <_stogir.checked.validate+0x104>
    3c80:      	ldr	x3, [x0]
    3c84:      	add	x3, x3, x1, lsl #4
    3c88:      	ldr	x4, [x3]
    3c8c:      	ldr	x3, [x3, #0x8]
    3c90:      	b	0x3ca4 <_stogir.checked.validate+0x114>
    3c94:      	ldr	x3, [x0, #0x28]
    3c98:      	add	x3, x3, x5, lsl #4
    3c9c:      	ldr	x4, [x3]
    3ca0:      	ldr	x3, [x3, #0x8]
    3ca4:      	mov	w5, #0x1                ; =1
    3ca8:      	b	0x3cb8 <_stogir.checked.validate+0x128>
    3cac:      	movz	w5, #0x0, lsl #16
    3cb0:      	movz	x4, #0x0, lsl #48
    3cb4:      	movz	x3, #0x0, lsl #48
    3cb8:      	ubfx	x5, x5, #0, #32
    3cbc:      	lsr	x16, x5, #0
    3cc0:      	cmp	x16, #0x1
    3cc4:      	b.eq	0x3ce0 <_stogir.checked.validate+0x150>
    3cc8:      	b.lo	0x3cd0 <_stogir.checked.validate+0x140>
    3ccc:      	b	0x3ce4 <_stogir.checked.validate+0x154>
    3cd0:      	cmp	x16, #0x0
    3cd4:      	b.eq	0x3cdc <_stogir.checked.validate+0x14c>
    3cd8:      	b	0x3ce4 <_stogir.checked.validate+0x154>
    3cdc:      	b	0x3ce8 <_stogir.checked.validate+0x158>
    3ce0:      	b	0x3d40 <_stogir.checked.validate+0x1b0>
    3ce4:      	b	0x3ff8 <_stogir.checked.validate+0x468>
    3ce8:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		0000000000003ce8:  ARM64_RELOC_PAGE21	l_stogir.366
    3cec:      	ldr	x16, [x16]
		0000000000003cec:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    3cf0:      	orr	x1, x16, xzr
    3cf4:      	mov	x0, #0x1                ; =1
    3cf8:      	mov	x9, #0x1a               ; =26
    3cfc:      	b	0x3d14 <_stogir.checked.validate+0x184>
    3d00:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		0000000000003d00:  ARM64_RELOC_PAGE21	l_stogir.367
    3d04:      	ldr	x16, [x16]
		0000000000003d04:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    3d08:      	orr	x1, x16, xzr
    3d0c:      	mov	x0, #0x1                ; =1
    3d10:      	mov	x9, #0x26               ; =38
    3d14:      	str	x0, [x8]
    3d18:      	str	x1, [x8, #0x8]
    3d1c:      	str	x9, [x8, #0x10]
    3d20:      	sub	sp, x29, #0x0
    3d24:      	ldr	x19, [sp, #0x10]
    3d28:      	ldr	x20, [sp, #0x18]
    3d2c:      	ldr	x21, [sp, #0x20]
    3d30:      	ldr	x29, [sp]
    3d34:      	ldr	x30, [sp, #0x8]
    3d38:      	add	sp, sp, #0x30
    3d3c:      	ret
    3d40:      	cmp	x1, #0x0
    3d44:      	b.le	0x3d00 <_stogir.checked.validate+0x170>
    3d48:      	uxtb	w1, w4
    3d4c:      	cmp	x1, #0x29
    3d50:      	b.lt	0x3d00 <_stogir.checked.validate+0x170>
    3d54:      	cmp	x1, #0x2b
    3d58:      	b.gt	0x3d00 <_stogir.checked.validate+0x170>
    3d5c:      	ldr	x1, [x0, #0x78]
    3d60:      	add	x1, x2, x1
    3d64:      	ldr	w1, [x1]
    3d68:      	sxtw	x1, w1
    3d6c:      	cmp	x1, #0x2
    3d70:      	b.ne	0x3d00 <_stogir.checked.validate+0x170>
    3d74:      	orr	w1, w4, wzr
    3d78:      	mov	x2, sp
    3d7c:      	ubfx	x1, x1, #0, #32
    3d80:      	sub	sp, sp, #0x10
    3d84:      	mov	x5, sp
    3d88:      	sub	sp, sp, #0x10
    3d8c:      	mov	x6, sp
    3d90:      	ubfx	x1, x1, #8, #8
    3d94:      	orr	x7, x1, xzr
    3d98:      	cmp	x7, #0x1
    3d9c:      	b.lt	0x3f94 <_stogir.checked.validate+0x404>
    3da0:      	cmp	x7, #0xb
    3da4:      	b.gt	0x3f94 <_stogir.checked.validate+0x404>
    3da8:      	cmp	x7, #0x1
    3dac:      	b.eq	0x3f94 <_stogir.checked.validate+0x404>
    3db0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		0000000000003db0:  ARM64_RELOC_PAGE21	l_stogir.368
    3db4:      	ldr	x16, [x16]
		0000000000003db4:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    3db8:      	orr	x1, x16, xzr
    3dbc:      	movz	x9, #0x0, lsl #48
    3dc0:      	b	0x3fa4 <_stogir.checked.validate+0x414>
    3dc4:      	movz	x4, #0x0, lsl #48
    3dc8:      	b	0x3c64 <_stogir.checked.validate+0xd4>
    3dcc:      	movz	x4, #0x0, lsl #48
    3dd0:      	b	0x3c5c <_stogir.checked.validate+0xcc>
    3dd4:      	mov	x0, #0x1                ; =1
    3dd8:      	mov	sp, x2
    3ddc:      	b	0x3d14 <_stogir.checked.validate+0x184>
    3de0:      	movz	w5, #0x0, lsl #16
    3de4:      	movz	x4, #0x0, lsl #48
    3de8:      	ubfx	x5, x5, #0, #32
    3dec:      	lsr	x16, x5, #0
    3df0:      	cmp	x16, #0x1
    3df4:      	b.eq	0x3e10 <_stogir.checked.validate+0x280>
    3df8:      	b.lo	0x3e00 <_stogir.checked.validate+0x270>
    3dfc:      	b	0x3e14 <_stogir.checked.validate+0x284>
    3e00:      	cmp	x16, #0x0
    3e04:      	b.eq	0x3e0c <_stogir.checked.validate+0x27c>
    3e08:      	b	0x3e14 <_stogir.checked.validate+0x284>
    3e0c:      	b	0x3e18 <_stogir.checked.validate+0x288>
    3e10:      	b	0x3f78 <_stogir.checked.validate+0x3e8>
    3e14:      	b	0x4010 <_stogir.checked.validate+0x480>
    3e18:      	mov	x1, x11
    3e1c:      	mov	x9, #0x22               ; =34
    3e20:      	cmp	x3, #0x2
    3e24:      	b.ge	0x3e48 <_stogir.checked.validate+0x2b8>
    3e28:      	add	x4, x3, #0x1
    3e2c:      	add	x3, x10, x3, lsl #2
    3e30:      	ldr	w3, [x3]
    3e34:      	movn	w17, #0x0, lsl #16
    3e38:      	and	w5, w3, w17
    3e3c:      	mov	x3, x4
    3e40:      	mov	w4, #0x1                ; =1
    3e44:      	b	0x3e50 <_stogir.checked.validate+0x2c0>
    3e48:      	movz	w4, #0x0, lsl #16
    3e4c:      	movz	w5, #0x0, lsl #16
    3e50:      	ubfx	x4, x4, #0, #32
    3e54:      	lsr	x16, x4, #0
    3e58:      	cmp	x16, #0x1
    3e5c:      	b.eq	0x3e78 <_stogir.checked.validate+0x2e8>
    3e60:      	b.lo	0x3e68 <_stogir.checked.validate+0x2d8>
    3e64:      	b	0x3e7c <_stogir.checked.validate+0x2ec>
    3e68:      	cmp	x16, #0x0
    3e6c:      	b.eq	0x3e74 <_stogir.checked.validate+0x2e4>
    3e70:      	b	0x3e7c <_stogir.checked.validate+0x2ec>
    3e74:      	b	0x3edc <_stogir.checked.validate+0x34c>
    3e78:      	b	0x3e80 <_stogir.checked.validate+0x2f0>
    3e7c:      	b	0x4008 <_stogir.checked.validate+0x478>
    3e80:      	sxtw	x5, w5
    3e84:      	cmp	x5, #0x0
    3e88:      	cset	w4, gt
    3e8c:      	movz	x16, #0x0, lsl #48
    3e90:      	sub	x6, x16, x5
    3e94:      	sub	x19, x6, #0x1
    3e98:      	uxtb	w16, w4
    3e9c:      	cmp	w16, wzr
    3ea0:      	b.eq	0x3f38 <_stogir.checked.validate+0x3a8>
    3ea4:      	ldr	x6, [x0, #0x8]
    3ea8:      	cmp	x5, x6
    3eac:      	b.ge	0x3f30 <_stogir.checked.validate+0x3a0>
    3eb0:      	ldr	x6, [x13, #0x8]
    3eb4:      	cmp	x5, x6
    3eb8:      	b.ge	0x3ff0 <_stogir.checked.validate+0x460>
    3ebc:      	ldr	x6, [x0, #0x78]
    3ec0:      	add	x6, x6, x5, lsl #2
    3ec4:      	ldr	w6, [x6]
    3ec8:      	sxtw	x6, w6
    3ecc:      	cmp	x6, #0x0
    3ed0:      	cset	w6, ge
    3ed4:      	ubfx	x6, x6, #0, #8
    3ed8:      	b	0x3ff4 <_stogir.checked.validate+0x464>
    3edc:      	cmp	x9, #0x0
    3ee0:      	b.ne	0x3dd4 <_stogir.checked.validate+0x244>
    3ee4:      	and	x1, x7, #0xffffffff
    3ee8:      	movz	x0, #0x0, lsl #48
    3eec:      	movz	x9, #0x0, lsl #48
    3ef0:      	b	0x3dd8 <_stogir.checked.validate+0x248>
    3ef4:      	ldr	x4, [x0, #0x28]
    3ef8:      	add	x4, x4, x19, lsl #4
    3efc:      	ldr	x4, [x4]
    3f00:      	mov	w5, #0x1                ; =1
    3f04:      	b	0x3de8 <_stogir.checked.validate+0x258>
    3f08:      	movz	x6, #0x0, lsl #48
    3f0c:      	cmp	x6, #0x0
    3f10:      	b.eq	0x3de0 <_stogir.checked.validate+0x250>
    3f14:      	uxtb	w16, w4
    3f18:      	cmp	w16, wzr
    3f1c:      	b.eq	0x3ef4 <_stogir.checked.validate+0x364>
    3f20:      	ldr	x4, [x0]
    3f24:      	add	x4, x4, x5, lsl #4
    3f28:      	ldr	x4, [x4]
    3f2c:      	b	0x3f00 <_stogir.checked.validate+0x370>
    3f30:      	movz	x6, #0x0, lsl #48
    3f34:      	b	0x3f0c <_stogir.checked.validate+0x37c>
    3f38:      	cmp	x5, #0x0
    3f3c:      	b.ge	0x3f08 <_stogir.checked.validate+0x378>
    3f40:      	ldr	x20, [x14, #0x8]
    3f44:      	ldr	x21, [x15, #0x8]
    3f48:      	cmp	x20, x21
    3f4c:      	b.ne	0x3fe8 <_stogir.checked.validate+0x458>
    3f50:      	cmp	x6, x20
    3f54:      	b.gt	0x4000 <_stogir.checked.validate+0x470>
    3f58:      	ldr	x6, [x0, #0x50]
    3f5c:      	add	x6, x6, x19, lsl #2
    3f60:      	ldr	w6, [x6]
    3f64:      	sxtw	x6, w6
    3f68:      	cmp	x6, #0x0
    3f6c:      	cset	w6, gt
    3f70:      	ubfx	x6, x6, #0, #8
    3f74:      	b	0x4004 <_stogir.checked.validate+0x474>
    3f78:      	ubfx	x4, x4, #0, #32
    3f7c:      	ubfx	x4, x4, #8, #8
    3f80:      	cmp	x4, x7
    3f84:      	b.eq	0x3f90 <_stogir.checked.validate+0x400>
    3f88:      	mov	x1, x12
    3f8c:      	mov	x9, #0x28               ; =40
    3f90:      	b	0x3e20 <_stogir.checked.validate+0x290>
    3f94:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		0000000000003f94:  ARM64_RELOC_PAGE21	l_stogir.369
    3f98:      	ldr	x16, [x16]
		0000000000003f98:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    3f9c:      	orr	x1, x16, xzr
    3fa0:      	mov	x9, #0x36               ; =54
    3fa4:      	orr	x10, x6, xzr
    3fa8:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		0000000000003fa8:  ARM64_RELOC_PAGE21	l_stogir.370
    3fac:      	ldr	x16, [x16]
		0000000000003fac:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    3fb0:      	orr	x11, x16, xzr
    3fb4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6b8>
		0000000000003fb4:  ARM64_RELOC_PAGE21	l_stogir.371
    3fb8:      	ldr	x16, [x16]
		0000000000003fb8:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    3fbc:      	orr	x12, x16, xzr
    3fc0:      	add	x13, x0, #0x78
    3fc4:      	add	x14, x0, #0x28
    3fc8:      	add	x15, x0, #0x50
    3fcc:      	lsr	x4, x4, #32
    3fd0:      	str	w4, [x5]
    3fd4:      	str	w3, [x5, #0x4]
    3fd8:      	ldr	x3, [x5]
    3fdc:      	str	x3, [x6]
    3fe0:      	movz	x3, #0x0, lsl #48
    3fe4:      	b	0x3e20 <_stogir.checked.validate+0x290>
    3fe8:      	movz	x6, #0x0, lsl #48
    3fec:      	b	0x3f0c <_stogir.checked.validate+0x37c>
    3ff0:      	movz	x6, #0x0, lsl #48
    3ff4:      	b	0x3f34 <_stogir.checked.validate+0x3a4>
    3ff8:      	brk	#0
    3ffc:      	b	0x3ff8 <_stogir.checked.validate+0x468>
    4000:      	movz	x6, #0x0, lsl #48
    4004:      	b	0x3fec <_stogir.checked.validate+0x45c>
    4008:      	brk	#0
    400c:      	b	0x4008 <_stogir.checked.validate+0x478>
    4010:      	brk	#0
    4014:      	b	0x4010 <_stogir.checked.validate+0x480>

0000000000004018 <_stogir.atomic.validate>:
    4018:      	sub	sp, sp, #0xe0
    401c:      	str	x29, [sp, #0x10]
    4020:      	str	x30, [sp, #0x18]
    4024:      	add	x29, sp, #0x10
    4028:      	str	x19, [sp, #0x90]
    402c:      	str	x20, [sp, #0x98]
    4030:      	str	x21, [sp, #0xa0]
    4034:      	str	x22, [sp, #0xa8]
    4038:      	str	x23, [sp, #0xb0]
    403c:      	str	x24, [sp, #0xb8]
    4040:      	str	x25, [sp, #0xc0]
    4044:      	str	x26, [sp, #0xc8]
    4048:      	str	x27, [sp, #0xd0]
    404c:      	sxtw	x19, w1
    4050:      	lsl	x20, x19, #2
    4054:      	cmp	x19, #0x0
    4058:      	cset	w2, gt
    405c:      	movz	x16, #0x0, lsl #48
    4060:      	sub	x3, x16, x19
    4064:      	sub	x4, x3, #0x1
    4068:      	uxtb	w16, w2
    406c:      	cmp	w16, wzr
    4070:      	b.eq	0x40b0 <_stogir.atomic.validate+0x98>
    4074:      	ldr	x3, [x0, #0x8]
    4078:      	cmp	x19, x3
    407c:      	b.ge	0x4100 <_stogir.atomic.validate+0xe8>
    4080:      	add	x3, x0, #0x78
    4084:      	ldr	x3, [x3, #0x8]
    4088:      	cmp	x19, x3
    408c:      	b.ge	0x4260 <_stogir.atomic.validate+0x248>
    4090:      	ldr	x3, [x0, #0x78]
    4094:      	add	x3, x20, x3
    4098:      	ldr	w3, [x3]
    409c:      	sxtw	x3, w3
    40a0:      	cmp	x3, #0x0
    40a4:      	cset	w3, ge
    40a8:      	ubfx	x3, x3, #0, #8
    40ac:      	b	0x4264 <_stogir.atomic.validate+0x24c>
    40b0:      	cmp	x19, #0x0
    40b4:      	b.ge	0x4108 <_stogir.atomic.validate+0xf0>
    40b8:      	add	x5, x0, #0x28
    40bc:      	add	x6, x0, #0x50
    40c0:      	ldr	x5, [x5, #0x8]
    40c4:      	ldr	x6, [x6, #0x8]
    40c8:      	cmp	x5, x6
    40cc:      	b.ne	0x40f8 <_stogir.atomic.validate+0xe0>
    40d0:      	cmp	x3, x5
    40d4:      	b.gt	0x4330 <_stogir.atomic.validate+0x318>
    40d8:      	ldr	x3, [x0, #0x50]
    40dc:      	add	x3, x3, x4, lsl #2
    40e0:      	ldr	w3, [x3]
    40e4:      	sxtw	x3, w3
    40e8:      	cmp	x3, #0x0
    40ec:      	cset	w3, gt
    40f0:      	ubfx	x3, x3, #0, #8
    40f4:      	b	0x4334 <_stogir.atomic.validate+0x31c>
    40f8:      	movz	x3, #0x0, lsl #48
    40fc:      	b	0x410c <_stogir.atomic.validate+0xf4>
    4100:      	movz	x3, #0x0, lsl #48
    4104:      	b	0x410c <_stogir.atomic.validate+0xf4>
    4108:      	movz	x3, #0x0, lsl #48
    410c:      	cmp	x3, #0x0
    4110:      	b.eq	0x414c <_stogir.atomic.validate+0x134>
    4114:      	uxtb	w16, w2
    4118:      	cmp	w16, wzr
    411c:      	b.eq	0x4134 <_stogir.atomic.validate+0x11c>
    4120:      	ldr	x2, [x0]
    4124:      	add	x2, x2, x19, lsl #4
    4128:      	ldr	x3, [x2]
    412c:      	ldr	x2, [x2, #0x8]
    4130:      	b	0x4144 <_stogir.atomic.validate+0x12c>
    4134:      	ldr	x2, [x0, #0x28]
    4138:      	add	x2, x2, x4, lsl #4
    413c:      	ldr	x3, [x2]
    4140:      	ldr	x2, [x2, #0x8]
    4144:      	mov	w4, #0x1                ; =1
    4148:      	b	0x4158 <_stogir.atomic.validate+0x140>
    414c:      	movz	w4, #0x0, lsl #16
    4150:      	movz	x3, #0x0, lsl #48
    4154:      	movz	x2, #0x0, lsl #48
    4158:      	ubfx	x4, x4, #0, #32
    415c:      	lsr	x16, x4, #0
    4160:      	cmp	x16, #0x1
    4164:      	b.eq	0x4180 <_stogir.atomic.validate+0x168>
    4168:      	b.lo	0x4170 <_stogir.atomic.validate+0x158>
    416c:      	b	0x4184 <_stogir.atomic.validate+0x16c>
    4170:      	cmp	x16, #0x0
    4174:      	b.eq	0x417c <_stogir.atomic.validate+0x164>
    4178:      	b	0x4184 <_stogir.atomic.validate+0x16c>
    417c:      	b	0x4188 <_stogir.atomic.validate+0x170>
    4180:      	b	0x41e0 <_stogir.atomic.validate+0x1c8>
    4184:      	b	0x4808 <_stogir.atomic.validate+0x7f0>
    4188:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004188:  ARM64_RELOC_PAGE21	l_stogir.372
    418c:      	ldr	x16, [x16]
		000000000000418c:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    4190:      	orr	x19, x16, xzr
    4194:      	mov	x22, x8
    4198:      	mov	x0, #0x1                ; =1
    419c:      	mov	x20, #0x1a              ; =26
    41a0:      	str	x0, [x22]
    41a4:      	str	x19, [x22, #0x8]
    41a8:      	str	x20, [x22, #0x10]
    41ac:      	ldr	x19, [sp, #0x90]
    41b0:      	ldr	x20, [sp, #0x98]
    41b4:      	ldr	x21, [sp, #0xa0]
    41b8:      	ldr	x22, [sp, #0xa8]
    41bc:      	ldr	x23, [sp, #0xb0]
    41c0:      	ldr	x24, [sp, #0xb8]
    41c4:      	ldr	x25, [sp, #0xc0]
    41c8:      	ldr	x26, [sp, #0xc8]
    41cc:      	ldr	x27, [sp, #0xd0]
    41d0:      	ldr	x29, [sp, #0x10]
    41d4:      	ldr	x30, [sp, #0x18]
    41d8:      	add	sp, sp, #0xe0
    41dc:      	ret
    41e0:      	add	x16, sp, #0x20
    41e4:      	orr	x21, x16, xzr
    41e8:      	add	x16, sp, #0x20
    41ec:      	str	x3, [x16]
    41f0:      	add	x16, sp, #0x20
    41f4:      	str	x2, [x16, #0x8]
    41f8:      	mov	x22, x8
    41fc:      	mov	x23, x0
    4200:      	mov	x0, x21
    4204:      	mov	w24, w1
    4208:      	bl	0x4208 <_stogir.atomic.validate+0x1f0>
		0000000000004208:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    420c:      	uxtb	w25, w0
    4210:      	mov	x0, x21
    4214:      	bl	0x4214 <_stogir.atomic.validate+0x1fc>
		0000000000004214:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    4218:      	cmp	x19, #0x0
    421c:      	b.le	0x4270 <_stogir.atomic.validate+0x258>
    4220:      	cmp	x25, #0x7e
    4224:      	b.lt	0x4270 <_stogir.atomic.validate+0x258>
    4228:      	cmp	x25, #0x82
    422c:      	b.gt	0x4270 <_stogir.atomic.validate+0x258>
    4230:      	ldr	x1, [x23, #0x78]
    4234:      	add	x1, x20, x1
    4238:      	ldr	w1, [x1]
    423c:      	cmp	x25, #0x83
    4240:      	b.ge	0x47b8 <_stogir.atomic.validate+0x7a0>
    4244:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004244:  ARM64_RELOC_PAGE21	l_stogir.373
    4248:      	ldr	x16, [x16]
		0000000000004248:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    424c:      	orr	x2, x16, xzr
    4250:      	add	x2, x25, x2
    4254:      	ldrsb	w2, [x2]
    4258:      	sxtb	w2, w2
    425c:      	b	0x47bc <_stogir.atomic.validate+0x7a4>
    4260:      	movz	x3, #0x0, lsl #48
    4264:      	b	0x4104 <_stogir.atomic.validate+0xec>
    4268:      	mov	x0, #0x1                ; =1
    426c:      	b	0x41a0 <_stogir.atomic.validate+0x188>
    4270:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004270:  ARM64_RELOC_PAGE21	l_stogir.374
    4274:      	ldr	x16, [x16]
		0000000000004274:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    4278:      	orr	x19, x16, xzr
    427c:      	mov	x20, #0x20              ; =32
    4280:      	add	x16, sp, #0x20
    4284:      	ldr	w1, [x16, #0x4]
    4288:      	sxtw	x1, w1
    428c:      	cmp	x1, #0x0
    4290:      	cset	w2, gt
    4294:      	movz	x16, #0x0, lsl #48
    4298:      	sub	x3, x16, x1
    429c:      	sub	x4, x3, #0x1
    42a0:      	uxtb	w16, w2
    42a4:      	cmp	w16, wzr
    42a8:      	b.eq	0x42e8 <_stogir.atomic.validate+0x2d0>
    42ac:      	ldr	x3, [x23, #0x8]
    42b0:      	cmp	x1, x3
    42b4:      	b.ge	0x4340 <_stogir.atomic.validate+0x328>
    42b8:      	add	x3, x23, #0x78
    42bc:      	ldr	x3, [x3, #0x8]
    42c0:      	cmp	x1, x3
    42c4:      	b.ge	0x45b4 <_stogir.atomic.validate+0x59c>
    42c8:      	ldr	x3, [x23, #0x78]
    42cc:      	add	x3, x3, x1, lsl #2
    42d0:      	ldr	w3, [x3]
    42d4:      	sxtw	x3, w3
    42d8:      	cmp	x3, #0x0
    42dc:      	cset	w3, ge
    42e0:      	ubfx	x3, x3, #0, #8
    42e4:      	b	0x45b8 <_stogir.atomic.validate+0x5a0>
    42e8:      	cmp	x1, #0x0
    42ec:      	b.ge	0x4348 <_stogir.atomic.validate+0x330>
    42f0:      	add	x5, x23, #0x28
    42f4:      	add	x6, x23, #0x50
    42f8:      	ldr	x5, [x5, #0x8]
    42fc:      	ldr	x6, [x6, #0x8]
    4300:      	cmp	x5, x6
    4304:      	b.ne	0x4338 <_stogir.atomic.validate+0x320>
    4308:      	cmp	x3, x5
    430c:      	b.gt	0x4714 <_stogir.atomic.validate+0x6fc>
    4310:      	ldr	x3, [x23, #0x50]
    4314:      	add	x3, x3, x4, lsl #2
    4318:      	ldr	w3, [x3]
    431c:      	sxtw	x3, w3
    4320:      	cmp	x3, #0x0
    4324:      	cset	w3, gt
    4328:      	ubfx	x3, x3, #0, #8
    432c:      	b	0x4718 <_stogir.atomic.validate+0x700>
    4330:      	movz	x3, #0x0, lsl #48
    4334:      	b	0x40fc <_stogir.atomic.validate+0xe4>
    4338:      	movz	x3, #0x0, lsl #48
    433c:      	b	0x434c <_stogir.atomic.validate+0x334>
    4340:      	movz	x3, #0x0, lsl #48
    4344:      	b	0x434c <_stogir.atomic.validate+0x334>
    4348:      	movz	x3, #0x0, lsl #48
    434c:      	cmp	x3, #0x0
    4350:      	b.eq	0x438c <_stogir.atomic.validate+0x374>
    4354:      	uxtb	w16, w2
    4358:      	cmp	w16, wzr
    435c:      	b.eq	0x4374 <_stogir.atomic.validate+0x35c>
    4360:      	ldr	x2, [x23]
    4364:      	add	x1, x2, x1, lsl #4
    4368:      	ldr	x2, [x1]
    436c:      	ldr	x1, [x1, #0x8]
    4370:      	b	0x4384 <_stogir.atomic.validate+0x36c>
    4374:      	ldr	x1, [x23, #0x28]
    4378:      	add	x1, x1, x4, lsl #4
    437c:      	ldr	x2, [x1]
    4380:      	ldr	x1, [x1, #0x8]
    4384:      	mov	w3, #0x1                ; =1
    4388:      	b	0x4398 <_stogir.atomic.validate+0x380>
    438c:      	movz	w3, #0x0, lsl #16
    4390:      	movz	x2, #0x0, lsl #48
    4394:      	movz	x1, #0x0, lsl #48
    4398:      	ubfx	x3, x3, #0, #32
    439c:      	lsr	x16, x3, #0
    43a0:      	cmp	x16, #0x1
    43a4:      	b.eq	0x43c0 <_stogir.atomic.validate+0x3a8>
    43a8:      	b.lo	0x43b0 <_stogir.atomic.validate+0x398>
    43ac:      	b	0x43c4 <_stogir.atomic.validate+0x3ac>
    43b0:      	cmp	x16, #0x0
    43b4:      	b.eq	0x43bc <_stogir.atomic.validate+0x3a4>
    43b8:      	b	0x43c4 <_stogir.atomic.validate+0x3ac>
    43bc:      	b	0x43c8 <_stogir.atomic.validate+0x3b0>
    43c0:      	b	0x43e0 <_stogir.atomic.validate+0x3c8>
    43c4:      	b	0x4810 <_stogir.atomic.validate+0x7f8>
    43c8:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		00000000000043c8:  ARM64_RELOC_PAGE21	l_stogir.375
    43cc:      	ldr	x16, [x16]
		00000000000043cc:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    43d0:      	orr	x19, x16, xzr
    43d4:      	mov	x26, x0
    43d8:      	mov	x20, #0x16              ; =22
    43dc:      	b	0x4418 <_stogir.atomic.validate+0x400>
    43e0:      	add	x16, sp, #0x30
    43e4:      	str	x2, [x16]
    43e8:      	add	x16, sp, #0x30
    43ec:      	str	x1, [x16, #0x8]
    43f0:      	add	x16, sp, #0x20
    43f4:      	ldr	w1, [x16, #0x4]
    43f8:      	sxtw	x1, w1
    43fc:      	cmp	x1, #0x0
    4400:      	b.gt	0x4614 <_stogir.atomic.validate+0x5fc>
    4404:      	mov	x26, x0
    4408:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004408:  ARM64_RELOC_PAGE21	l_stogir.376
    440c:      	ldr	x16, [x16]
		000000000000440c:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    4410:      	orr	x19, x16, xzr
    4414:      	mov	x20, #0x16              ; =22
    4418:      	uxtb	w26, w26
    441c:      	cmp	x25, #0x82
    4420:      	cset	w21, eq
    4424:      	cmp	x26, #0x0
    4428:      	cset	w27, eq
    442c:      	uxtb	w16, w21
    4430:      	cmp	w16, wzr
    4434:      	b.eq	0x4468 <_stogir.atomic.validate+0x450>
    4438:      	uxtb	w16, w27
    443c:      	cmp	w16, wzr
    4440:      	b.eq	0x444c <_stogir.atomic.validate+0x434>
    4444:      	movz	x0, #0x0, lsl #48
    4448:      	b	0x4450 <_stogir.atomic.validate+0x438>
    444c:      	mov	x0, #0x1                ; =1
    4450:      	cmp	x0, #0x0
    4454:      	b.eq	0x4468 <_stogir.atomic.validate+0x450>
    4458:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004458:  ARM64_RELOC_PAGE21	l_stogir.377
    445c:      	ldr	x16, [x16]
		000000000000445c:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    4460:      	orr	x19, x16, xzr
    4464:      	mov	x20, #0x19              ; =25
    4468:      	uxtb	w16, w21
    446c:      	cmp	w16, wzr
    4470:      	b.eq	0x447c <_stogir.atomic.validate+0x464>
    4474:      	movz	x0, #0x0, lsl #48
    4478:      	b	0x4480 <_stogir.atomic.validate+0x468>
    447c:      	mov	x0, #0x1                ; =1
    4480:      	cmp	x0, #0x0
    4484:      	b.eq	0x44cc <_stogir.atomic.validate+0x4b4>
    4488:      	add	x16, sp, #0x20
    448c:      	ldr	w0, [x16, #0x8]
    4490:      	mov	w1, w0
    4494:      	mov	x0, x23
    4498:      	mov	x2, #0x6                ; =6
    449c:      	bl	0x449c <_stogir.atomic.validate+0x484>
		000000000000449c:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    44a0:      	cmp	x0, #0x0
    44a4:      	b.eq	0x45dc <_stogir.atomic.validate+0x5c4>
    44a8:      	movz	x0, #0x0, lsl #48
    44ac:      	b	0x45e0 <_stogir.atomic.validate+0x5c8>
    44b0:      	movz	x0, #0x0, lsl #48
    44b4:      	cmp	x0, #0x0
    44b8:      	b.eq	0x44cc <_stogir.atomic.validate+0x4b4>
    44bc:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		00000000000044bc:  ARM64_RELOC_PAGE21	l_stogir.378
    44c0:      	ldr	x16, [x16]
		00000000000044c0:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    44c4:      	orr	x19, x16, xzr
    44c8:      	mov	x20, #0x22              ; =34
    44cc:      	cmp	x25, #0x80
    44d0:      	cset	w27, eq
    44d4:      	uxtb	w16, w27
    44d8:      	cmp	w16, wzr
    44dc:      	b.eq	0x44e8 <_stogir.atomic.validate+0x4d0>
    44e0:      	mov	x0, #0x1                ; =1
    44e4:      	b	0x44f4 <_stogir.atomic.validate+0x4dc>
    44e8:      	cmp	x25, #0x81
    44ec:      	cset	w0, eq
    44f0:      	ubfx	x0, x0, #0, #8
    44f4:      	cmp	x0, #0x0
    44f8:      	b.eq	0x4598 <_stogir.atomic.validate+0x580>
    44fc:      	add	x16, sp, #0x80
    4500:      	str	x16, [sp]
    4504:      	mov	x0, x23
    4508:      	mov	w1, w24
    450c:      	mov	x2, #0x4                ; =4
    4510:      	bl	0x4510 <_stogir.atomic.validate+0x4f8>
		0000000000004510:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    4514:      	ldr	x16, [sp]
    4518:      	str	x0, [x16]
    451c:      	str	x1, [x16, #0x8]
    4520:      	add	x16, sp, #0x80
    4524:      	ldr	x0, [x16]
    4528:      	add	x16, sp, #0x80
    452c:      	ldr	x1, [x16, #0x8]
    4530:      	ubfx	x0, x0, #0, #32
    4534:      	lsr	x16, x0, #0
    4538:      	cmp	x16, #0x1
    453c:      	b.eq	0x4558 <_stogir.atomic.validate+0x540>
    4540:      	b.lo	0x4548 <_stogir.atomic.validate+0x530>
    4544:      	b	0x455c <_stogir.atomic.validate+0x544>
    4548:      	cmp	x16, #0x0
    454c:      	b.eq	0x4554 <_stogir.atomic.validate+0x53c>
    4550:      	b	0x455c <_stogir.atomic.validate+0x544>
    4554:      	b	0x4560 <_stogir.atomic.validate+0x548>
    4558:      	b	0x471c <_stogir.atomic.validate+0x704>
    455c:      	b	0x4818 <_stogir.atomic.validate+0x800>
    4560:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004560:  ARM64_RELOC_PAGE21	l_stogir.379
    4564:      	ldr	x16, [x16]
		0000000000004564:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    4568:      	orr	x19, x16, xzr
    456c:      	mov	x20, #0x1d              ; =29
    4570:      	b	0x4598 <_stogir.atomic.validate+0x580>
    4574:      	mov	x0, x23
    4578:      	mov	w2, w26
    457c:      	bl	0x457c <_stogir.atomic.validate+0x564>
		000000000000457c:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4580:      	cmp	x0, #0x0
    4584:      	b.ne	0x4598 <_stogir.atomic.validate+0x580>
    4588:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004588:  ARM64_RELOC_PAGE21	l_stogir.380
    458c:      	ldr	x16, [x16]
		000000000000458c:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    4590:      	orr	x19, x16, xzr
    4594:      	mov	x20, #0x24              ; =36
    4598:      	cmp	x20, #0x0
    459c:      	b.ne	0x4268 <_stogir.atomic.validate+0x250>
    45a0:      	uxtb	w16, w21
    45a4:      	cmp	w16, wzr
    45a8:      	b.eq	0x45bc <_stogir.atomic.validate+0x5a4>
    45ac:      	movz	x0, #0x0, lsl #48
    45b0:      	b	0x45cc <_stogir.atomic.validate+0x5b4>
    45b4:      	movz	x3, #0x0, lsl #48
    45b8:      	b	0x4344 <_stogir.atomic.validate+0x32c>
    45bc:      	mov	w0, w26
    45c0:      	mov	x1, #0x8                ; =8
    45c4:      	bl	0x45c4 <_stogir.atomic.validate+0x5ac>
		00000000000045c4:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    45c8:      	sxtw	x0, w0
    45cc:      	and	x19, x0, #0xffffffff
    45d0:      	movz	x0, #0x0, lsl #48
    45d4:      	movz	x20, #0x0, lsl #48
    45d8:      	b	0x426c <_stogir.atomic.validate+0x254>
    45dc:      	mov	x0, #0x1                ; =1
    45e0:      	cmp	x0, #0x0
    45e4:      	b.eq	0x45f8 <_stogir.atomic.validate+0x5e0>
    45e8:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		00000000000045e8:  ARM64_RELOC_PAGE21	l_stogir.381
    45ec:      	ldr	x16, [x16]
		00000000000045ec:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    45f0:      	orr	x19, x16, xzr
    45f4:      	mov	x20, #0x1b              ; =27
    45f8:      	cmp	x25, #0x7f
    45fc:      	b.ne	0x4694 <_stogir.atomic.validate+0x67c>
    4600:      	uxtb	w16, w27
    4604:      	cmp	w16, wzr
    4608:      	b.eq	0x473c <_stogir.atomic.validate+0x724>
    460c:      	movz	x0, #0x0, lsl #48
    4610:      	b	0x4740 <_stogir.atomic.validate+0x728>
    4614:      	add	x16, sp, #0x30
    4618:      	orr	x21, x16, xzr
    461c:      	mov	x26, x0
    4620:      	mov	x0, x21
    4624:      	bl	0x4624 <_stogir.atomic.validate+0x60c>
		0000000000004624:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    4628:      	uxtb	w0, w0
    462c:      	bl	0x462c <_stogir.atomic.validate+0x614>
		000000000000462c:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    4630:      	cmp	x0, #0x0
    4634:      	b.eq	0x4408 <_stogir.atomic.validate+0x3f0>
    4638:      	mov	x0, x21
    463c:      	bl	0x463c <_stogir.atomic.validate+0x624>
		000000000000463c:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    4640:      	uxtb	w0, w0
    4644:      	bl	0x4644 <_stogir.atomic.validate+0x62c>
		0000000000004644:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    4648:      	cmp	x0, #0x0
    464c:      	b.ne	0x4408 <_stogir.atomic.validate+0x3f0>
    4650:      	b	0x4418 <_stogir.atomic.validate+0x400>
    4654:      	add	x16, sp, #0x40
    4658:      	orr	x0, x16, xzr
    465c:      	add	x16, sp, #0x70
    4660:      	orr	x1, x16, xzr
    4664:      	add	x0, x0, #0x8
    4668:      	add	x16, sp, #0x40
    466c:      	ldr	x2, [x16, #0x8]
    4670:      	add	x16, sp, #0x70
    4674:      	str	x2, [x16]
    4678:      	ldr	x0, [x0, #0x8]
    467c:      	add	x16, sp, #0x70
    4680:      	str	x0, [x16, #0x8]
    4684:      	mov	x0, x1
    4688:      	bl	0x4688 <_stogir.atomic.validate+0x670>
		0000000000004688:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    468c:      	uxtb	w0, w0
    4690:      	orr	x26, x0, xzr
    4694:      	cmp	x26, #0x2
    4698:      	b.ge	0x46e0 <_stogir.atomic.validate+0x6c8>
    469c:      	mov	x0, #0x1                ; =1
    46a0:      	b	0x46ec <_stogir.atomic.validate+0x6d4>
    46a4:      	mov	x0, #0x1                ; =1
    46a8:      	b	0x44b4 <_stogir.atomic.validate+0x49c>
    46ac:      	mov	x0, #0x1                ; =1
    46b0:      	cmp	x0, #0x0
    46b4:      	b.eq	0x44b0 <_stogir.atomic.validate+0x498>
    46b8:      	orr	w0, w26, wzr
    46bc:      	add	x16, sp, #0x20
    46c0:      	ldr	w1, [x16, #0xc]
    46c4:      	mov	w2, w0
    46c8:      	mov	x0, x23
    46cc:      	bl	0x46cc <_stogir.atomic.validate+0x6b4>
		00000000000046cc:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    46d0:      	cmp	x0, #0x0
    46d4:      	b.eq	0x46a4 <_stogir.atomic.validate+0x68c>
    46d8:      	movz	x0, #0x0, lsl #48
    46dc:      	b	0x46a8 <_stogir.atomic.validate+0x690>
    46e0:      	cmp	x26, #0x5
    46e4:      	cset	w0, gt
    46e8:      	ubfx	x0, x0, #0, #8
    46ec:      	cmp	x0, #0x0
    46f0:      	b.eq	0x4704 <_stogir.atomic.validate+0x6ec>
    46f4:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		00000000000046f4:  ARM64_RELOC_PAGE21	l_stogir.382
    46f8:      	ldr	x16, [x16]
		00000000000046f8:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    46fc:      	orr	x19, x16, xzr
    4700:      	mov	x20, #0x25              ; =37
    4704:      	cmp	x25, #0x7e
    4708:      	b.ne	0x46ac <_stogir.atomic.validate+0x694>
    470c:      	movz	x0, #0x0, lsl #48
    4710:      	b	0x46b0 <_stogir.atomic.validate+0x698>
    4714:      	movz	x3, #0x0, lsl #48
    4718:      	b	0x433c <_stogir.atomic.validate+0x324>
    471c:      	uxtb	w16, w27
    4720:      	cmp	w16, wzr
    4724:      	b.eq	0x4574 <_stogir.atomic.validate+0x55c>
    4728:      	sxtw	x1, w1
    472c:      	cmp	x1, #0x0
    4730:      	b.ge	0x47e0 <_stogir.atomic.validate+0x7c8>
    4734:      	mov	x0, #0x1                ; =1
    4738:      	b	0x47ec <_stogir.atomic.validate+0x7d4>
    473c:      	mov	x0, #0x1                ; =1
    4740:      	cmp	x0, #0x0
    4744:      	b.eq	0x4758 <_stogir.atomic.validate+0x740>
    4748:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004748:  ARM64_RELOC_PAGE21	l_stogir.383
    474c:      	ldr	x16, [x16]
		000000000000474c:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    4750:      	orr	x19, x16, xzr
    4754:      	mov	x20, #0x19              ; =25
    4758:      	add	x16, sp, #0x20
    475c:      	ldr	w0, [x16, #0xc]
    4760:      	add	x8, sp, #0x40
    4764:      	mov	w1, w0
    4768:      	mov	x0, x23
    476c:      	bl	0x476c <_stogir.atomic.validate+0x754>
		000000000000476c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4770:      	add	x16, sp, #0x40
    4774:      	ldr	w0, [x16]
    4778:      	lsr	x16, x0, #0
    477c:      	cmp	x16, #0x1
    4780:      	b.eq	0x479c <_stogir.atomic.validate+0x784>
    4784:      	b.lo	0x478c <_stogir.atomic.validate+0x774>
    4788:      	b	0x47a0 <_stogir.atomic.validate+0x788>
    478c:      	cmp	x16, #0x0
    4790:      	b.eq	0x4798 <_stogir.atomic.validate+0x780>
    4794:      	b	0x47a0 <_stogir.atomic.validate+0x788>
    4798:      	b	0x47a4 <_stogir.atomic.validate+0x78c>
    479c:      	b	0x4654 <_stogir.atomic.validate+0x63c>
    47a0:      	b	0x4820 <_stogir.atomic.validate+0x808>
    47a4:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		00000000000047a4:  ARM64_RELOC_PAGE21	l_stogir.384
    47a8:      	ldr	x16, [x16]
		00000000000047a8:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    47ac:      	orr	x19, x16, xzr
    47b0:      	mov	x20, #0x1a              ; =26
    47b4:      	b	0x4694 <_stogir.atomic.validate+0x67c>
    47b8:      	mov	w2, #-0x2               ; =-2
    47bc:      	sxtw	x1, w1
    47c0:      	sxtw	x2, w2
    47c4:      	cmp	x1, x2
    47c8:      	b.ne	0x4270 <_stogir.atomic.validate+0x258>
    47cc:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		00000000000047cc:  ARM64_RELOC_PAGE21	l_stogir.385
    47d0:      	ldr	x16, [x16]
		00000000000047d0:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    47d4:      	orr	x19, x16, xzr
    47d8:      	movz	x20, #0x0, lsl #48
    47dc:      	b	0x4280 <_stogir.atomic.validate+0x268>
    47e0:      	cmp	x1, #0x9
    47e4:      	cset	w0, gt
    47e8:      	ubfx	x0, x0, #0, #8
    47ec:      	cmp	x0, #0x0
    47f0:      	b.eq	0x4804 <_stogir.atomic.validate+0x7ec>
    47f4:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		00000000000047f4:  ARM64_RELOC_PAGE21	l_stogir.386
    47f8:      	ldr	x16, [x16]
		00000000000047f8:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    47fc:      	orr	x19, x16, xzr
    4800:      	mov	x20, #0x1c              ; =28
    4804:      	b	0x4598 <_stogir.atomic.validate+0x580>
    4808:      	brk	#0
    480c:      	b	0x4808 <_stogir.atomic.validate+0x7f0>
    4810:      	brk	#0
    4814:      	b	0x4810 <_stogir.atomic.validate+0x7f8>
    4818:      	brk	#0
    481c:      	b	0x4818 <_stogir.atomic.validate+0x800>
    4820:      	brk	#0
    4824:      	b	0x4820 <_stogir.atomic.validate+0x808>

0000000000004828 <_stogir.terminal.validate>:
    4828:      	sub	sp, sp, #0x50
    482c:      	str	x29, [sp]
    4830:      	str	x30, [sp, #0x8]
    4834:      	mov	x29, sp
    4838:      	str	x19, [sp, #0x40]
    483c:      	sxtw	x1, w1
    4840:      	lsl	x2, x1, #2
    4844:      	cmp	x1, #0x0
    4848:      	cset	w3, gt
    484c:      	movz	x16, #0x0, lsl #48
    4850:      	sub	x4, x16, x1
    4854:      	sub	x5, x4, #0x1
    4858:      	uxtb	w16, w3
    485c:      	cmp	w16, wzr
    4860:      	b.eq	0x48a0 <_stogir.terminal.validate+0x78>
    4864:      	ldr	x4, [x0, #0x8]
    4868:      	cmp	x1, x4
    486c:      	b.ge	0x48f0 <_stogir.terminal.validate+0xc8>
    4870:      	add	x4, x0, #0x78
    4874:      	ldr	x4, [x4, #0x8]
    4878:      	cmp	x1, x4
    487c:      	b.ge	0x49e4 <_stogir.terminal.validate+0x1bc>
    4880:      	ldr	x4, [x0, #0x78]
    4884:      	add	x4, x2, x4
    4888:      	ldr	w4, [x4]
    488c:      	sxtw	x4, w4
    4890:      	cmp	x4, #0x0
    4894:      	cset	w4, ge
    4898:      	ubfx	x4, x4, #0, #8
    489c:      	b	0x49e8 <_stogir.terminal.validate+0x1c0>
    48a0:      	cmp	x1, #0x0
    48a4:      	b.ge	0x48f8 <_stogir.terminal.validate+0xd0>
    48a8:      	add	x6, x0, #0x28
    48ac:      	add	x7, x0, #0x50
    48b0:      	ldr	x6, [x6, #0x8]
    48b4:      	ldr	x7, [x7, #0x8]
    48b8:      	cmp	x6, x7
    48bc:      	b.ne	0x48e8 <_stogir.terminal.validate+0xc0>
    48c0:      	cmp	x4, x6
    48c4:      	b.gt	0x4a24 <_stogir.terminal.validate+0x1fc>
    48c8:      	ldr	x4, [x0, #0x50]
    48cc:      	add	x4, x4, x5, lsl #2
    48d0:      	ldr	w4, [x4]
    48d4:      	sxtw	x4, w4
    48d8:      	cmp	x4, #0x0
    48dc:      	cset	w4, gt
    48e0:      	ubfx	x4, x4, #0, #8
    48e4:      	b	0x4a28 <_stogir.terminal.validate+0x200>
    48e8:      	movz	x4, #0x0, lsl #48
    48ec:      	b	0x48fc <_stogir.terminal.validate+0xd4>
    48f0:      	movz	x4, #0x0, lsl #48
    48f4:      	b	0x48fc <_stogir.terminal.validate+0xd4>
    48f8:      	movz	x4, #0x0, lsl #48
    48fc:      	cmp	x4, #0x0
    4900:      	b.eq	0x493c <_stogir.terminal.validate+0x114>
    4904:      	uxtb	w16, w3
    4908:      	cmp	w16, wzr
    490c:      	b.eq	0x4924 <_stogir.terminal.validate+0xfc>
    4910:      	ldr	x3, [x0]
    4914:      	add	x3, x3, x1, lsl #4
    4918:      	ldr	x4, [x3]
    491c:      	ldr	x3, [x3, #0x8]
    4920:      	b	0x4934 <_stogir.terminal.validate+0x10c>
    4924:      	ldr	x3, [x0, #0x28]
    4928:      	add	x3, x3, x5, lsl #4
    492c:      	ldr	x4, [x3]
    4930:      	ldr	x3, [x3, #0x8]
    4934:      	mov	w5, #0x1                ; =1
    4938:      	b	0x4948 <_stogir.terminal.validate+0x120>
    493c:      	movz	w5, #0x0, lsl #16
    4940:      	movz	x4, #0x0, lsl #48
    4944:      	movz	x3, #0x0, lsl #48
    4948:      	ubfx	x5, x5, #0, #32
    494c:      	lsr	x16, x5, #0
    4950:      	cmp	x16, #0x1
    4954:      	b.eq	0x4970 <_stogir.terminal.validate+0x148>
    4958:      	b.lo	0x4960 <_stogir.terminal.validate+0x138>
    495c:      	b	0x4974 <_stogir.terminal.validate+0x14c>
    4960:      	cmp	x16, #0x0
    4964:      	b.eq	0x496c <_stogir.terminal.validate+0x144>
    4968:      	b	0x4974 <_stogir.terminal.validate+0x14c>
    496c:      	b	0x4978 <_stogir.terminal.validate+0x150>
    4970:      	b	0x4994 <_stogir.terminal.validate+0x16c>
    4974:      	b	0x4aec <_stogir.terminal.validate+0x2c4>
    4978:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004978:  ARM64_RELOC_PAGE21	l_stogir.387
    497c:      	ldr	x16, [x16]
		000000000000497c:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    4980:      	orr	x0, x16, xzr
    4984:      	mov	x19, x8
    4988:      	mov	x1, #0x1                ; =1
    498c:      	mov	x2, #0x21               ; =33
    4990:      	b	0x49c4 <_stogir.terminal.validate+0x19c>
    4994:      	add	x16, sp, #0x10
    4998:      	str	x4, [x16]
    499c:      	add	x16, sp, #0x10
    49a0:      	str	x3, [x16, #0x8]
    49a4:      	cmp	x1, #0x0
    49a8:      	b.gt	0x49ec <_stogir.terminal.validate+0x1c4>
    49ac:      	mov	x19, x8
    49b0:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		00000000000049b0:  ARM64_RELOC_PAGE21	l_stogir.388
    49b4:      	ldr	x16, [x16]
		00000000000049b4:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    49b8:      	orr	x0, x16, xzr
    49bc:      	mov	x1, #0x1                ; =1
    49c0:      	mov	x2, #0x1b               ; =27
    49c4:      	str	x1, [x19]
    49c8:      	str	x0, [x19, #0x8]
    49cc:      	str	x2, [x19, #0x10]
    49d0:      	ldr	x19, [sp, #0x40]
    49d4:      	ldr	x29, [sp]
    49d8:      	ldr	x30, [sp, #0x8]
    49dc:      	add	sp, sp, #0x50
    49e0:      	ret
    49e4:      	movz	x4, #0x0, lsl #48
    49e8:      	b	0x48f4 <_stogir.terminal.validate+0xcc>
    49ec:      	uxtb	w4, w4
    49f0:      	orr	x1, x4, xzr
    49f4:      	cmp	x1, #0x60
    49f8:      	cset	w3, eq
    49fc:      	cmp	x1, #0x79
    4a00:      	cset	w1, eq
    4a04:      	uxtb	w16, w3
    4a08:      	cmp	w16, wzr
    4a0c:      	b.ne	0x4a2c <_stogir.terminal.validate+0x204>
    4a10:      	uxtb	w16, w1
    4a14:      	cmp	w16, wzr
    4a18:      	b.ne	0x4a2c <_stogir.terminal.validate+0x204>
    4a1c:      	mov	x19, x8
    4a20:      	b	0x49b0 <_stogir.terminal.validate+0x188>
    4a24:      	movz	x4, #0x0, lsl #48
    4a28:      	b	0x48ec <_stogir.terminal.validate+0xc4>
    4a2c:      	add	x16, sp, #0x10
    4a30:      	ldr	w5, [x16]
    4a34:      	ubfx	x5, x5, #8, #8
    4a38:      	cmp	x5, #0x0
    4a3c:      	b.ne	0x4af4 <_stogir.terminal.validate+0x2cc>
    4a40:      	uxtb	w16, w3
    4a44:      	cmp	w16, wzr
    4a48:      	mov	w16, #0x1               ; =1
    4a4c:      	mov	w17, #0x3               ; =3
    4a50:      	csel	w3, w16, w17, ne
    4a54:      	sxtw	x3, w3
    4a58:      	ldr	x5, [x0, #0x78]
    4a5c:      	add	x2, x2, x5
    4a60:      	ldr	w2, [x2]
    4a64:      	sxtw	x2, w2
    4a68:      	cmp	x2, x3
    4a6c:      	b.ne	0x4afc <_stogir.terminal.validate+0x2d4>
    4a70:      	uxtb	w16, w1
    4a74:      	cmp	w16, wzr
    4a78:      	b.eq	0x4acc <_stogir.terminal.validate+0x2a4>
    4a7c:      	add	x16, sp, #0x10
    4a80:      	ldr	w2, [x16, #0x8]
    4a84:      	sxtw	x2, w2
    4a88:      	cmp	x2, #0x0
    4a8c:      	b.eq	0x4acc <_stogir.terminal.validate+0x2a4>
    4a90:      	mov	x19, x8
    4a94:      	b	0x49b0 <_stogir.terminal.validate+0x188>
    4a98:      	movz	w1, #0x0, lsl #16
    4a9c:      	mov	w3, w1
    4aa0:      	mov	w1, w4
    4aa4:      	mov	x19, x8
    4aa8:      	add	x8, sp, #0x20
    4aac:      	bl	0x4aac <_stogir.terminal.validate+0x284>
		0000000000004aac:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    4ab0:      	add	x16, sp, #0x20
    4ab4:      	ldr	x1, [x16]
    4ab8:      	add	x16, sp, #0x20
    4abc:      	ldr	x0, [x16, #0x8]
    4ac0:      	add	x16, sp, #0x20
    4ac4:      	ldr	x2, [x16, #0x10]
    4ac8:      	b	0x49c4 <_stogir.terminal.validate+0x19c>
    4acc:      	add	x16, sp, #0x10
    4ad0:      	ldr	w2, [x16, #0x4]
    4ad4:      	uxtb	w16, w1
    4ad8:      	cmp	w16, wzr
    4adc:      	b.eq	0x4a98 <_stogir.terminal.validate+0x270>
    4ae0:      	add	x16, sp, #0x10
    4ae4:      	ldr	w1, [x16, #0xc]
    4ae8:      	b	0x4a9c <_stogir.terminal.validate+0x274>
    4aec:      	brk	#0
    4af0:      	b	0x4aec <_stogir.terminal.validate+0x2c4>
    4af4:      	mov	x19, x8
    4af8:      	b	0x49b0 <_stogir.terminal.validate+0x188>
    4afc:      	mov	x19, x8
    4b00:      	b	0x49b0 <_stogir.terminal.validate+0x188>

0000000000004b04 <_stogir.switch.validate>:
    4b04:      	sub	sp, sp, #0x70
    4b08:      	str	x29, [sp]
    4b0c:      	str	x30, [sp, #0x8]
    4b10:      	mov	x29, sp
    4b14:      	str	x19, [sp, #0x60]
    4b18:      	sxtw	x1, w1
    4b1c:      	lsl	x2, x1, #2
    4b20:      	cmp	x1, #0x0
    4b24:      	cset	w3, gt
    4b28:      	movz	x16, #0x0, lsl #48
    4b2c:      	sub	x4, x16, x1
    4b30:      	sub	x5, x4, #0x1
    4b34:      	uxtb	w16, w3
    4b38:      	cmp	w16, wzr
    4b3c:      	b.eq	0x4b7c <_stogir.switch.validate+0x78>
    4b40:      	ldr	x4, [x0, #0x8]
    4b44:      	cmp	x1, x4
    4b48:      	b.ge	0x4bcc <_stogir.switch.validate+0xc8>
    4b4c:      	add	x4, x0, #0x78
    4b50:      	ldr	x4, [x4, #0x8]
    4b54:      	cmp	x1, x4
    4b58:      	b.ge	0x4cc0 <_stogir.switch.validate+0x1bc>
    4b5c:      	ldr	x4, [x0, #0x78]
    4b60:      	add	x4, x2, x4
    4b64:      	ldr	w4, [x4]
    4b68:      	sxtw	x4, w4
    4b6c:      	cmp	x4, #0x0
    4b70:      	cset	w4, ge
    4b74:      	ubfx	x4, x4, #0, #8
    4b78:      	b	0x4cc4 <_stogir.switch.validate+0x1c0>
    4b7c:      	cmp	x1, #0x0
    4b80:      	b.ge	0x4bd4 <_stogir.switch.validate+0xd0>
    4b84:      	add	x6, x0, #0x28
    4b88:      	add	x7, x0, #0x50
    4b8c:      	ldr	x6, [x6, #0x8]
    4b90:      	ldr	x7, [x7, #0x8]
    4b94:      	cmp	x6, x7
    4b98:      	b.ne	0x4bc4 <_stogir.switch.validate+0xc0>
    4b9c:      	cmp	x4, x6
    4ba0:      	b.gt	0x4cfc <_stogir.switch.validate+0x1f8>
    4ba4:      	ldr	x4, [x0, #0x50]
    4ba8:      	add	x4, x4, x5, lsl #2
    4bac:      	ldr	w4, [x4]
    4bb0:      	sxtw	x4, w4
    4bb4:      	cmp	x4, #0x0
    4bb8:      	cset	w4, gt
    4bbc:      	ubfx	x4, x4, #0, #8
    4bc0:      	b	0x4d00 <_stogir.switch.validate+0x1fc>
    4bc4:      	movz	x4, #0x0, lsl #48
    4bc8:      	b	0x4bd8 <_stogir.switch.validate+0xd4>
    4bcc:      	movz	x4, #0x0, lsl #48
    4bd0:      	b	0x4bd8 <_stogir.switch.validate+0xd4>
    4bd4:      	movz	x4, #0x0, lsl #48
    4bd8:      	cmp	x4, #0x0
    4bdc:      	b.eq	0x4c18 <_stogir.switch.validate+0x114>
    4be0:      	uxtb	w16, w3
    4be4:      	cmp	w16, wzr
    4be8:      	b.eq	0x4c00 <_stogir.switch.validate+0xfc>
    4bec:      	ldr	x3, [x0]
    4bf0:      	add	x3, x3, x1, lsl #4
    4bf4:      	ldr	x4, [x3]
    4bf8:      	ldr	x3, [x3, #0x8]
    4bfc:      	b	0x4c10 <_stogir.switch.validate+0x10c>
    4c00:      	ldr	x3, [x0, #0x28]
    4c04:      	add	x3, x3, x5, lsl #4
    4c08:      	ldr	x4, [x3]
    4c0c:      	ldr	x3, [x3, #0x8]
    4c10:      	mov	w5, #0x1                ; =1
    4c14:      	b	0x4c24 <_stogir.switch.validate+0x120>
    4c18:      	movz	w5, #0x0, lsl #16
    4c1c:      	movz	x4, #0x0, lsl #48
    4c20:      	movz	x3, #0x0, lsl #48
    4c24:      	ubfx	x5, x5, #0, #32
    4c28:      	lsr	x16, x5, #0
    4c2c:      	cmp	x16, #0x1
    4c30:      	b.eq	0x4c4c <_stogir.switch.validate+0x148>
    4c34:      	b.lo	0x4c3c <_stogir.switch.validate+0x138>
    4c38:      	b	0x4c50 <_stogir.switch.validate+0x14c>
    4c3c:      	cmp	x16, #0x0
    4c40:      	b.eq	0x4c48 <_stogir.switch.validate+0x144>
    4c44:      	b	0x4c50 <_stogir.switch.validate+0x14c>
    4c48:      	b	0x4c54 <_stogir.switch.validate+0x150>
    4c4c:      	b	0x4c70 <_stogir.switch.validate+0x16c>
    4c50:      	b	0x4de4 <_stogir.switch.validate+0x2e0>
    4c54:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004c54:  ARM64_RELOC_PAGE21	l_stogir.389
    4c58:      	ldr	x16, [x16]
		0000000000004c58:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    4c5c:      	orr	x0, x16, xzr
    4c60:      	mov	x19, x8
    4c64:      	mov	x1, #0x1                ; =1
    4c68:      	mov	x2, #0x1a               ; =26
    4c6c:      	b	0x4ca0 <_stogir.switch.validate+0x19c>
    4c70:      	add	x16, sp, #0x10
    4c74:      	str	x4, [x16]
    4c78:      	add	x16, sp, #0x10
    4c7c:      	str	x3, [x16, #0x8]
    4c80:      	cmp	x1, #0x0
    4c84:      	b.gt	0x4cc8 <_stogir.switch.validate+0x1c4>
    4c88:      	mov	x19, x8
    4c8c:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004c8c:  ARM64_RELOC_PAGE21	l_stogir.390
    4c90:      	ldr	x16, [x16]
		0000000000004c90:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    4c94:      	orr	x0, x16, xzr
    4c98:      	mov	x1, #0x1                ; =1
    4c9c:      	mov	x2, #0x20               ; =32
    4ca0:      	str	x1, [x19]
    4ca4:      	str	x0, [x19, #0x8]
    4ca8:      	str	x2, [x19, #0x10]
    4cac:      	ldr	x19, [sp, #0x60]
    4cb0:      	ldr	x29, [sp]
    4cb4:      	ldr	x30, [sp, #0x8]
    4cb8:      	add	sp, sp, #0x70
    4cbc:      	ret
    4cc0:      	movz	x4, #0x0, lsl #48
    4cc4:      	b	0x4bd0 <_stogir.switch.validate+0xcc>
    4cc8:      	uxtb	w4, w4
    4ccc:      	orr	x1, x4, xzr
    4cd0:      	cmp	x1, #0x75
    4cd4:      	cset	w3, eq
    4cd8:      	uxtb	w16, w3
    4cdc:      	cmp	w16, wzr
    4ce0:      	b.ne	0x4d04 <_stogir.switch.validate+0x200>
    4ce4:      	cmp	x1, #0x6d
    4ce8:      	b.lt	0x4dec <_stogir.switch.validate+0x2e8>
    4cec:      	cmp	x1, #0x6f
    4cf0:      	b.le	0x4d04 <_stogir.switch.validate+0x200>
    4cf4:      	mov	x19, x8
    4cf8:      	b	0x4c8c <_stogir.switch.validate+0x188>
    4cfc:      	movz	x4, #0x0, lsl #48
    4d00:      	b	0x4bc8 <_stogir.switch.validate+0xc4>
    4d04:      	add	x16, sp, #0x10
    4d08:      	ldr	w5, [x16]
    4d0c:      	ubfx	x5, x5, #8, #8
    4d10:      	cmp	x5, #0x0
    4d14:      	b.ne	0x4df4 <_stogir.switch.validate+0x2f0>
    4d18:      	ldr	x5, [x0, #0x78]
    4d1c:      	add	x2, x2, x5
    4d20:      	ldr	w2, [x2]
    4d24:      	cmp	x1, #0x6d
    4d28:      	b.eq	0x4d8c <_stogir.switch.validate+0x288>
    4d2c:      	cmp	x1, #0x6e
    4d30:      	b.eq	0x4d8c <_stogir.switch.validate+0x288>
    4d34:      	mov	w1, #0x2                ; =2
    4d38:      	b	0x4d90 <_stogir.switch.validate+0x28c>
    4d3c:      	add	x16, sp, #0x10
    4d40:      	ldr	w1, [x16, #0x4]
    4d44:      	add	x16, sp, #0x10
    4d48:      	ldr	w2, [x16, #0x8]
    4d4c:      	add	x16, sp, #0x10
    4d50:      	ldr	w3, [x16, #0xc]
    4d54:      	add	x8, sp, #0x40
    4d58:      	fmov	s31, w1
    4d5c:      	mov	w1, w4
    4d60:      	mov	w4, w3
    4d64:      	mov	w3, w2
    4d68:      	fmov	w2, s31
    4d6c:      	bl	0x4d6c <_stogir.switch.validate+0x268>
		0000000000004d6c:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    4d70:      	add	x16, sp, #0x40
    4d74:      	ldr	x1, [x16]
    4d78:      	add	x16, sp, #0x40
    4d7c:      	ldr	x0, [x16, #0x8]
    4d80:      	add	x16, sp, #0x40
    4d84:      	ldr	x2, [x16, #0x10]
    4d88:      	b	0x4ca0 <_stogir.switch.validate+0x19c>
    4d8c:      	mov	w1, #0x3                ; =3
    4d90:      	sxtw	x2, w2
    4d94:      	sxtw	x1, w1
    4d98:      	cmp	x2, x1
    4d9c:      	b.ne	0x4dfc <_stogir.switch.validate+0x2f8>
    4da0:      	uxtb	w16, w3
    4da4:      	cmp	w16, wzr
    4da8:      	b.eq	0x4e04 <_stogir.switch.validate+0x300>
    4dac:      	add	x16, sp, #0x10
    4db0:      	ldr	w1, [x16, #0x4]
    4db4:      	add	x16, sp, #0x10
    4db8:      	ldr	w2, [x16, #0x8]
    4dbc:      	mov	x19, x8
    4dc0:      	add	x8, sp, #0x20
    4dc4:      	bl	0x4dc4 <_stogir.switch.validate+0x2c0>
		0000000000004dc4:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    4dc8:      	add	x16, sp, #0x20
    4dcc:      	ldr	x1, [x16]
    4dd0:      	add	x16, sp, #0x20
    4dd4:      	ldr	x0, [x16, #0x8]
    4dd8:      	add	x16, sp, #0x20
    4ddc:      	ldr	x2, [x16, #0x10]
    4de0:      	b	0x4d88 <_stogir.switch.validate+0x284>
    4de4:      	brk	#0
    4de8:      	b	0x4de4 <_stogir.switch.validate+0x2e0>
    4dec:      	mov	x19, x8
    4df0:      	b	0x4c8c <_stogir.switch.validate+0x188>
    4df4:      	mov	x19, x8
    4df8:      	b	0x4c8c <_stogir.switch.validate+0x188>
    4dfc:      	mov	x19, x8
    4e00:      	b	0x4c8c <_stogir.switch.validate+0x188>
    4e04:      	mov	x19, x8
    4e08:      	b	0x4d3c <_stogir.switch.validate+0x238>

0000000000004e0c <_stogir.stack.validate>:
    4e0c:      	sub	sp, sp, #0xc0
    4e10:      	str	x29, [sp]
    4e14:      	str	x30, [sp, #0x8]
    4e18:      	mov	x29, sp
    4e1c:      	str	x19, [sp, #0x70]
    4e20:      	str	x20, [sp, #0x78]
    4e24:      	str	x21, [sp, #0x80]
    4e28:      	str	x22, [sp, #0x88]
    4e2c:      	str	x23, [sp, #0x90]
    4e30:      	str	x24, [sp, #0x98]
    4e34:      	str	x25, [sp, #0xa0]
    4e38:      	str	x26, [sp, #0xa8]
    4e3c:      	str	x27, [sp, #0xb0]
    4e40:      	str	x28, [sp, #0xb8]
    4e44:      	sxtw	x19, w1
    4e48:      	lsl	x20, x19, #2
    4e4c:      	cmp	x19, #0x0
    4e50:      	cset	w21, gt
    4e54:      	movz	x16, #0x0, lsl #48
    4e58:      	sub	x22, x16, x19
    4e5c:      	cmp	x19, #0x0
    4e60:      	cset	w23, lt
    4e64:      	sub	x1, x22, #0x1
    4e68:      	lsl	x24, x1, #2
    4e6c:      	uxtb	w16, w21
    4e70:      	cmp	w16, wzr
    4e74:      	b.eq	0x4eb4 <_stogir.stack.validate+0xa8>
    4e78:      	ldr	x2, [x0, #0x8]
    4e7c:      	cmp	x19, x2
    4e80:      	b.ge	0x4f70 <_stogir.stack.validate+0x164>
    4e84:      	add	x2, x0, #0x78
    4e88:      	ldr	x2, [x2, #0x8]
    4e8c:      	cmp	x19, x2
    4e90:      	b.ge	0x50f0 <_stogir.stack.validate+0x2e4>
    4e94:      	ldr	x2, [x0, #0x78]
    4e98:      	add	x2, x20, x2
    4e9c:      	ldr	w2, [x2]
    4ea0:      	sxtw	x2, w2
    4ea4:      	cmp	x2, #0x0
    4ea8:      	cset	w2, ge
    4eac:      	ubfx	x2, x2, #0, #8
    4eb0:      	b	0x50f4 <_stogir.stack.validate+0x2e8>
    4eb4:      	uxtb	w16, w23
    4eb8:      	cmp	w16, wzr
    4ebc:      	b.eq	0x4f78 <_stogir.stack.validate+0x16c>
    4ec0:      	add	x2, x0, #0x28
    4ec4:      	add	x3, x0, #0x50
    4ec8:      	ldr	x2, [x2, #0x8]
    4ecc:      	ldr	x3, [x3, #0x8]
    4ed0:      	cmp	x2, x3
    4ed4:      	b.ne	0x4f00 <_stogir.stack.validate+0xf4>
    4ed8:      	cmp	x22, x2
    4edc:      	b.gt	0x50f8 <_stogir.stack.validate+0x2ec>
    4ee0:      	ldr	x2, [x0, #0x50]
    4ee4:      	add	x2, x24, x2
    4ee8:      	ldr	w2, [x2]
    4eec:      	sxtw	x2, w2
    4ef0:      	cmp	x2, #0x0
    4ef4:      	cset	w2, gt
    4ef8:      	ubfx	x2, x2, #0, #8
    4efc:      	b	0x50fc <_stogir.stack.validate+0x2f0>
    4f00:      	movz	x2, #0x0, lsl #48
    4f04:      	b	0x4f7c <_stogir.stack.validate+0x170>
    4f08:      	uxtb	w16, w28
    4f0c:      	cmp	w16, wzr
    4f10:      	b.ne	0x4f58 <_stogir.stack.validate+0x14c>
    4f14:      	cmp	x1, #0x51
    4f18:      	cset	w2, eq
    4f1c:      	cmp	x1, #0x53
    4f20:      	cset	w19, eq
    4f24:      	cmp	x1, #0x54
    4f28:      	cset	w21, eq
    4f2c:      	uxtb	w16, w2
    4f30:      	cmp	w16, wzr
    4f34:      	b.ne	0x5258 <_stogir.stack.validate+0x44c>
    4f38:      	cmp	x1, #0x52
    4f3c:      	b.eq	0x5258 <_stogir.stack.validate+0x44c>
    4f40:      	uxtb	w16, w19
    4f44:      	cmp	w16, wzr
    4f48:      	b.ne	0x5258 <_stogir.stack.validate+0x44c>
    4f4c:      	uxtb	w16, w21
    4f50:      	cmp	w16, wzr
    4f54:      	b.ne	0x5258 <_stogir.stack.validate+0x44c>
    4f58:      	adrp	x16, 0x4000 <_stogir.checked.validate+0x470>
		0000000000004f58:  ARM64_RELOC_PAGE21	l_stogir.391
    4f5c:      	ldr	x16, [x16]
		0000000000004f5c:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    4f60:      	orr	x0, x16, xzr
    4f64:      	mov	x1, #0x1                ; =1
    4f68:      	mov	x2, #0x19               ; =25
    4f6c:      	b	0x5018 <_stogir.stack.validate+0x20c>
    4f70:      	movz	x2, #0x0, lsl #48
    4f74:      	b	0x4f7c <_stogir.stack.validate+0x170>
    4f78:      	movz	x2, #0x0, lsl #48
    4f7c:      	lsl	x25, x19, #4
    4f80:      	lsl	x26, x1, #4
    4f84:      	cmp	x2, #0x0
    4f88:      	b.eq	0x4fc4 <_stogir.stack.validate+0x1b8>
    4f8c:      	uxtb	w16, w21
    4f90:      	cmp	w16, wzr
    4f94:      	b.eq	0x4fac <_stogir.stack.validate+0x1a0>
    4f98:      	ldr	x1, [x0]
    4f9c:      	add	x1, x25, x1
    4fa0:      	ldr	x2, [x1]
    4fa4:      	ldr	x1, [x1, #0x8]
    4fa8:      	b	0x4fbc <_stogir.stack.validate+0x1b0>
    4fac:      	ldr	x1, [x0, #0x28]
    4fb0:      	add	x1, x26, x1
    4fb4:      	ldr	x2, [x1]
    4fb8:      	ldr	x1, [x1, #0x8]
    4fbc:      	mov	w3, #0x1                ; =1
    4fc0:      	b	0x4fd0 <_stogir.stack.validate+0x1c4>
    4fc4:      	movz	w3, #0x0, lsl #16
    4fc8:      	movz	x2, #0x0, lsl #48
    4fcc:      	movz	x1, #0x0, lsl #48
    4fd0:      	ubfx	x3, x3, #0, #32
    4fd4:      	lsr	x16, x3, #0
    4fd8:      	cmp	x16, #0x1
    4fdc:      	b.eq	0x4ff8 <_stogir.stack.validate+0x1ec>
    4fe0:      	b.lo	0x4fe8 <_stogir.stack.validate+0x1dc>
    4fe4:      	b	0x4ffc <_stogir.stack.validate+0x1f0>
    4fe8:      	cmp	x16, #0x0
    4fec:      	b.eq	0x4ff4 <_stogir.stack.validate+0x1e8>
    4ff0:      	b	0x4ffc <_stogir.stack.validate+0x1f0>
    4ff4:      	b	0x5000 <_stogir.stack.validate+0x1f4>
    4ff8:      	b	0x5060 <_stogir.stack.validate+0x254>
    4ffc:      	b	0x53f8 <_stogir.stack.validate+0x5ec>
    5000:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005000:  ARM64_RELOC_PAGE21	l_stogir.392
    5004:      	ldr	x16, [x16]
		0000000000005004:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    5008:      	orr	x0, x16, xzr
    500c:      	str	x8, [sp, #0x68]
    5010:      	mov	x1, #0x1                ; =1
    5014:      	mov	x2, #0x19               ; =25
    5018:      	ldr	x3, [sp, #0x68]
    501c:      	str	x1, [x3]
    5020:      	str	x0, [x3, #0x8]
    5024:      	str	x2, [x3, #0x10]
    5028:      	ldr	x19, [sp, #0x70]
    502c:      	ldr	x20, [sp, #0x78]
    5030:      	ldr	x21, [sp, #0x80]
    5034:      	ldr	x22, [sp, #0x88]
    5038:      	ldr	x23, [sp, #0x90]
    503c:      	ldr	x24, [sp, #0x98]
    5040:      	ldr	x25, [sp, #0xa0]
    5044:      	ldr	x26, [sp, #0xa8]
    5048:      	ldr	x27, [sp, #0xb0]
    504c:      	ldr	x28, [sp, #0xb8]
    5050:      	ldr	x29, [sp]
    5054:      	ldr	x30, [sp, #0x8]
    5058:      	add	sp, sp, #0xc0
    505c:      	ret
    5060:      	add	x16, sp, #0x10
    5064:      	orr	x27, x16, xzr
    5068:      	cmp	x19, #0x0
    506c:      	cset	w28, le
    5070:      	add	x16, sp, #0x10
    5074:      	str	x2, [x16]
    5078:      	add	x16, sp, #0x10
    507c:      	str	x1, [x16, #0x8]
    5080:      	str	x8, [sp, #0x68]
    5084:      	str	x27, [sp, #0x60]
    5088:      	fmov	d31, x0
    508c:      	mov	x0, x27
    5090:      	fmov	x27, d31
    5094:      	bl	0x5094 <_stogir.stack.validate+0x288>
		0000000000005094:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    5098:      	uxtb	w0, w0
    509c:      	orr	x1, x0, xzr
    50a0:      	cmp	x1, #0x42
    50a4:      	b.ne	0x4f08 <_stogir.stack.validate+0xfc>
    50a8:      	uxtb	w16, w21
    50ac:      	cmp	w16, wzr
    50b0:      	b.eq	0x5118 <_stogir.stack.validate+0x30c>
    50b4:      	ldr	x0, [x27, #0x8]
    50b8:      	cmp	x19, x0
    50bc:      	b.ge	0x5164 <_stogir.stack.validate+0x358>
    50c0:      	add	x0, x27, #0x78
    50c4:      	ldr	x0, [x0, #0x8]
    50c8:      	cmp	x19, x0
    50cc:      	b.ge	0x5250 <_stogir.stack.validate+0x444>
    50d0:      	ldr	x0, [x27, #0x78]
    50d4:      	add	x0, x20, x0
    50d8:      	ldr	w0, [x0]
    50dc:      	sxtw	x0, w0
    50e0:      	cmp	x0, #0x0
    50e4:      	cset	w0, ge
    50e8:      	ubfx	x0, x0, #0, #8
    50ec:      	b	0x5254 <_stogir.stack.validate+0x448>
    50f0:      	movz	x2, #0x0, lsl #48
    50f4:      	b	0x4f74 <_stogir.stack.validate+0x168>
    50f8:      	movz	x2, #0x0, lsl #48
    50fc:      	b	0x4f04 <_stogir.stack.validate+0xf8>
    5100:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005100:  ARM64_RELOC_PAGE21	l_stogir.393
    5104:      	ldr	x16, [x16]
		0000000000005104:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    5108:      	orr	x0, x16, xzr
    510c:      	mov	x1, #0x1                ; =1
    5110:      	mov	x2, #0x1e               ; =30
    5114:      	b	0x4f6c <_stogir.stack.validate+0x160>
    5118:      	uxtb	w16, w23
    511c:      	cmp	w16, wzr
    5120:      	b.eq	0x516c <_stogir.stack.validate+0x360>
    5124:      	add	x0, x27, #0x28
    5128:      	add	x1, x27, #0x50
    512c:      	ldr	x0, [x0, #0x8]
    5130:      	ldr	x1, [x1, #0x8]
    5134:      	cmp	x0, x1
    5138:      	b.ne	0x5248 <_stogir.stack.validate+0x43c>
    513c:      	cmp	x22, x0
    5140:      	b.gt	0x5378 <_stogir.stack.validate+0x56c>
    5144:      	ldr	x0, [x27, #0x50]
    5148:      	add	x0, x24, x0
    514c:      	ldr	w0, [x0]
    5150:      	sxtw	x0, w0
    5154:      	cmp	x0, #0x0
    5158:      	cset	w0, gt
    515c:      	ubfx	x0, x0, #0, #8
    5160:      	b	0x537c <_stogir.stack.validate+0x570>
    5164:      	movz	x0, #0x0, lsl #48
    5168:      	b	0x5170 <_stogir.stack.validate+0x364>
    516c:      	movz	x0, #0x0, lsl #48
    5170:      	cmp	x0, #0x0
    5174:      	b.eq	0x51a8 <_stogir.stack.validate+0x39c>
    5178:      	uxtb	w16, w21
    517c:      	cmp	w16, wzr
    5180:      	b.eq	0x5194 <_stogir.stack.validate+0x388>
    5184:      	ldr	x0, [x27]
    5188:      	add	x0, x25, x0
    518c:      	ldr	x0, [x0]
    5190:      	b	0x51a0 <_stogir.stack.validate+0x394>
    5194:      	ldr	x0, [x27, #0x28]
    5198:      	add	x0, x26, x0
    519c:      	ldr	x0, [x0]
    51a0:      	mov	w1, #0x1                ; =1
    51a4:      	b	0x51b0 <_stogir.stack.validate+0x3a4>
    51a8:      	movz	w1, #0x0, lsl #16
    51ac:      	movz	x0, #0x0, lsl #48
    51b0:      	ubfx	x1, x1, #0, #32
    51b4:      	lsr	x16, x1, #0
    51b8:      	cmp	x16, #0x1
    51bc:      	b.eq	0x51d8 <_stogir.stack.validate+0x3cc>
    51c0:      	b.lo	0x51c8 <_stogir.stack.validate+0x3bc>
    51c4:      	b	0x51dc <_stogir.stack.validate+0x3d0>
    51c8:      	cmp	x16, #0x0
    51cc:      	b.eq	0x51d4 <_stogir.stack.validate+0x3c8>
    51d0:      	b	0x51dc <_stogir.stack.validate+0x3d0>
    51d4:      	b	0x51e0 <_stogir.stack.validate+0x3d4>
    51d8:      	b	0x51f8 <_stogir.stack.validate+0x3ec>
    51dc:      	b	0x5400 <_stogir.stack.validate+0x5f4>
    51e0:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		00000000000051e0:  ARM64_RELOC_PAGE21	l_stogir.394
    51e4:      	ldr	x16, [x16]
		00000000000051e4:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    51e8:      	orr	x0, x16, xzr
    51ec:      	mov	x1, #0x1                ; =1
    51f0:      	mov	x2, #0x21               ; =33
    51f4:      	b	0x5114 <_stogir.stack.validate+0x308>
    51f8:      	uxtb	w16, w28
    51fc:      	cmp	w16, wzr
    5200:      	b.ne	0x5100 <_stogir.stack.validate+0x2f4>
    5204:      	uxtb	w1, w0
    5208:      	cmp	x1, #0x42
    520c:      	b.ne	0x5100 <_stogir.stack.validate+0x2f4>
    5210:      	ubfx	x0, x0, #0, #32
    5214:      	ubfx	x0, x0, #8, #8
    5218:      	cmp	x0, #0x6
    521c:      	b.ne	0x5100 <_stogir.stack.validate+0x2f4>
    5220:      	ldr	x0, [x27, #0x78]
    5224:      	add	x0, x20, x0
    5228:      	ldr	w0, [x0]
    522c:      	sxtw	x0, w0
    5230:      	cmp	x0, #0x0
    5234:      	b.ne	0x5100 <_stogir.stack.validate+0x2f4>
    5238:      	movz	x1, #0x0, lsl #48
    523c:      	mov	x0, #0x8                ; =8
    5240:      	movz	x2, #0x0, lsl #48
    5244:      	b	0x5114 <_stogir.stack.validate+0x308>
    5248:      	movz	x0, #0x0, lsl #48
    524c:      	b	0x5170 <_stogir.stack.validate+0x364>
    5250:      	movz	x0, #0x0, lsl #48
    5254:      	b	0x5168 <_stogir.stack.validate+0x35c>
    5258:      	ldr	x1, [x27, #0x78]
    525c:      	add	x1, x20, x1
    5260:      	ldr	w1, [x1]
    5264:      	uxtb	w16, w2
    5268:      	cmp	w16, wzr
    526c:      	b.eq	0x52cc <_stogir.stack.validate+0x4c0>
    5270:      	mov	w2, #0x3                ; =3
    5274:      	b	0x52e0 <_stogir.stack.validate+0x4d4>
    5278:      	ldr	x0, [sp, #0x60]
    527c:      	bl	0x527c <_stogir.stack.validate+0x470>
		000000000000527c:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    5280:      	uxtb	w0, w0
    5284:      	add	x16, sp, #0x10
    5288:      	ldr	w1, [x16, #0x4]
    528c:      	add	x16, sp, #0x10
    5290:      	ldr	w2, [x16, #0x8]
    5294:      	add	x8, sp, #0x20
    5298:      	mov	w3, w1
    529c:      	mov	w1, w20
    52a0:      	mov	w4, w2
    52a4:      	mov	w2, w0
    52a8:      	mov	x0, x27
    52ac:      	bl	0x52ac <_stogir.stack.validate+0x4a0>
		00000000000052ac:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    52b0:      	add	x16, sp, #0x20
    52b4:      	ldr	x1, [x16]
    52b8:      	add	x16, sp, #0x20
    52bc:      	ldr	x0, [x16, #0x8]
    52c0:      	add	x16, sp, #0x20
    52c4:      	ldr	x2, [x16, #0x10]
    52c8:      	b	0x4f6c <_stogir.stack.validate+0x160>
    52cc:      	uxtb	w16, w19
    52d0:      	cmp	w16, wzr
    52d4:      	mov	w16, #0x1               ; =1
    52d8:      	mov	w17, #0x2               ; =2
    52dc:      	csel	w2, w16, w17, ne
    52e0:      	sxtw	x1, w1
    52e4:      	sxtw	x2, w2
    52e8:      	cmp	x1, x2
    52ec:      	b.ne	0x4f58 <_stogir.stack.validate+0x14c>
    52f0:      	mov	w20, w0
    52f4:      	ldr	x0, [sp, #0x60]
    52f8:      	bl	0x52f8 <_stogir.stack.validate+0x4ec>
		00000000000052f8:  ARM64_RELOC_BRANCH26	_stogir.node.auxiliary
    52fc:      	uxth	w0, w0
    5300:      	uxth	w16, w0
    5304:      	and	w0, w16, #0x8000
    5308:      	uxth	w0, w0
    530c:      	ubfx	x0, x0, #0, #16
    5310:      	cmp	x0, #0x0
    5314:      	b.eq	0x5380 <_stogir.stack.validate+0x574>
    5318:      	add	x16, sp, #0x10
    531c:      	ldr	w0, [x16]
    5320:      	uxtb	w1, w0
    5324:      	cmp	x1, #0x51
    5328:      	b.ne	0x5360 <_stogir.stack.validate+0x554>
    532c:      	ubfx	x0, x0, #16, #16
    5330:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    5334:      	b.ne	0x5360 <_stogir.stack.validate+0x554>
    5338:      	add	x16, sp, #0x10
    533c:      	ldr	w0, [x16, #0x4]
    5340:      	add	x16, sp, #0x10
    5344:      	ldr	w1, [x16, #0x8]
    5348:      	mov	w2, w1
    534c:      	mov	w1, w0
    5350:      	mov	x0, x27
    5354:      	bl	0x5354 <_stogir.stack.validate+0x548>
		0000000000005354:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    5358:      	cmp	x0, #0x0
    535c:      	b.ne	0x5380 <_stogir.stack.validate+0x574>
    5360:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005360:  ARM64_RELOC_PAGE21	l_stogir.395
    5364:      	ldr	x16, [x16]
		0000000000005364:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    5368:      	orr	x0, x16, xzr
    536c:      	mov	x1, #0x1                ; =1
    5370:      	mov	x2, #0x26               ; =38
    5374:      	b	0x52c8 <_stogir.stack.validate+0x4bc>
    5378:      	movz	x0, #0x0, lsl #48
    537c:      	b	0x524c <_stogir.stack.validate+0x440>
    5380:      	uxtb	w16, w19
    5384:      	cmp	w16, wzr
    5388:      	b.ne	0x5278 <_stogir.stack.validate+0x46c>
    538c:      	uxtb	w16, w21
    5390:      	cmp	w16, wzr
    5394:      	b.ne	0x5278 <_stogir.stack.validate+0x46c>
    5398:      	ldr	x0, [sp, #0x60]
    539c:      	bl	0x539c <_stogir.stack.validate+0x590>
		000000000000539c:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    53a0:      	uxtb	w0, w0
    53a4:      	add	x16, sp, #0x10
    53a8:      	ldr	w1, [x16, #0x4]
    53ac:      	add	x16, sp, #0x10
    53b0:      	ldr	w2, [x16, #0x8]
    53b4:      	add	x16, sp, #0x10
    53b8:      	ldr	w3, [x16, #0xc]
    53bc:      	add	x8, sp, #0x40
    53c0:      	mov	w4, w2
    53c4:      	mov	w2, w0
    53c8:      	mov	x0, x27
    53cc:      	mov	w5, w3
    53d0:      	mov	w3, w1
    53d4:      	mov	w1, w20
    53d8:      	bl	0x53d8 <_stogir.stack.validate+0x5cc>
		00000000000053d8:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    53dc:      	add	x16, sp, #0x40
    53e0:      	ldr	x1, [x16]
    53e4:      	add	x16, sp, #0x40
    53e8:      	ldr	x0, [x16, #0x8]
    53ec:      	add	x16, sp, #0x40
    53f0:      	ldr	x2, [x16, #0x10]
    53f4:      	b	0x52c8 <_stogir.stack.validate+0x4bc>
    53f8:      	brk	#0
    53fc:      	b	0x53f8 <_stogir.stack.validate+0x5ec>
    5400:      	brk	#0
    5404:      	b	0x5400 <_stogir.stack.validate+0x5f4>

0000000000005408 <_stogir.locals.validate>:
    5408:      	sub	sp, sp, #0xb0
    540c:      	str	x29, [sp]
    5410:      	str	x30, [sp, #0x8]
    5414:      	mov	x29, sp
    5418:      	str	x19, [sp, #0x60]
    541c:      	str	x20, [sp, #0x68]
    5420:      	str	x21, [sp, #0x70]
    5424:      	str	x22, [sp, #0x78]
    5428:      	str	x23, [sp, #0x80]
    542c:      	str	x24, [sp, #0x88]
    5430:      	str	x25, [sp, #0x90]
    5434:      	str	x26, [sp, #0x98]
    5438:      	str	x27, [sp, #0xa0]
    543c:      	sxtw	x19, w1
    5440:      	lsl	x20, x19, #2
    5444:      	cmp	x19, #0x0
    5448:      	cset	w1, gt
    544c:      	movz	x16, #0x0, lsl #48
    5450:      	sub	x3, x16, x19
    5454:      	sub	x4, x3, #0x1
    5458:      	uxtb	w16, w1
    545c:      	cmp	w16, wzr
    5460:      	b.eq	0x54a0 <_stogir.locals.validate+0x98>
    5464:      	ldr	x3, [x0, #0x8]
    5468:      	cmp	x19, x3
    546c:      	b.ge	0x555c <_stogir.locals.validate+0x154>
    5470:      	add	x3, x0, #0x78
    5474:      	ldr	x3, [x3, #0x8]
    5478:      	cmp	x19, x3
    547c:      	b.ge	0x567c <_stogir.locals.validate+0x274>
    5480:      	ldr	x3, [x0, #0x78]
    5484:      	add	x3, x20, x3
    5488:      	ldr	w3, [x3]
    548c:      	sxtw	x3, w3
    5490:      	cmp	x3, #0x0
    5494:      	cset	w3, ge
    5498:      	ubfx	x3, x3, #0, #8
    549c:      	b	0x5680 <_stogir.locals.validate+0x278>
    54a0:      	cmp	x19, #0x0
    54a4:      	b.ge	0x5564 <_stogir.locals.validate+0x15c>
    54a8:      	add	x5, x0, #0x28
    54ac:      	add	x6, x0, #0x50
    54b0:      	ldr	x5, [x5, #0x8]
    54b4:      	ldr	x6, [x6, #0x8]
    54b8:      	cmp	x5, x6
    54bc:      	b.ne	0x54e8 <_stogir.locals.validate+0xe0>
    54c0:      	cmp	x3, x5
    54c4:      	b.gt	0x56c8 <_stogir.locals.validate+0x2c0>
    54c8:      	ldr	x3, [x0, #0x50]
    54cc:      	add	x3, x3, x4, lsl #2
    54d0:      	ldr	w3, [x3]
    54d4:      	sxtw	x3, w3
    54d8:      	cmp	x3, #0x0
    54dc:      	cset	w3, gt
    54e0:      	ubfx	x3, x3, #0, #8
    54e4:      	b	0x56cc <_stogir.locals.validate+0x2c4>
    54e8:      	movz	x3, #0x0, lsl #48
    54ec:      	b	0x5568 <_stogir.locals.validate+0x160>
    54f0:      	cmp	x1, #0x0
    54f4:      	cset	w1, ne
    54f8:      	uxtb	w16, w1
    54fc:      	cmp	w16, wzr
    5500:      	mov	w16, #0x2               ; =2
    5504:      	mov	w17, #0x3               ; =3
    5508:      	csel	w1, w16, w17, ne
    550c:      	cmp	x19, #0x0
    5510:      	b.le	0x5544 <_stogir.locals.validate+0x13c>
    5514:      	cmp	x0, #0x48
    5518:      	cset	w27, eq
    551c:      	uxtb	w16, w26
    5520:      	cmp	w16, wzr
    5524:      	b.ne	0x56d0 <_stogir.locals.validate+0x2c8>
    5528:      	uxtb	w16, w27
    552c:      	cmp	w16, wzr
    5530:      	b.ne	0x56d0 <_stogir.locals.validate+0x2c8>
    5534:      	cmp	x0, #0x55
    5538:      	b.lt	0x5544 <_stogir.locals.validate+0x13c>
    553c:      	cmp	x0, #0x58
    5540:      	b.le	0x56d0 <_stogir.locals.validate+0x2c8>
    5544:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005544:  ARM64_RELOC_PAGE21	l_stogir.396
    5548:      	ldr	x16, [x16]
		0000000000005548:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    554c:      	orr	x0, x16, xzr
    5550:      	mov	x2, #0x1                ; =1
    5554:      	mov	x1, #0x17               ; =23
    5558:      	b	0x55fc <_stogir.locals.validate+0x1f4>
    555c:      	movz	x3, #0x0, lsl #48
    5560:      	b	0x5568 <_stogir.locals.validate+0x160>
    5564:      	movz	x3, #0x0, lsl #48
    5568:      	cmp	x3, #0x0
    556c:      	b.eq	0x55a8 <_stogir.locals.validate+0x1a0>
    5570:      	uxtb	w16, w1
    5574:      	cmp	w16, wzr
    5578:      	b.eq	0x5590 <_stogir.locals.validate+0x188>
    557c:      	ldr	x1, [x0]
    5580:      	add	x1, x1, x19, lsl #4
    5584:      	ldr	x3, [x1]
    5588:      	ldr	x1, [x1, #0x8]
    558c:      	b	0x55a0 <_stogir.locals.validate+0x198>
    5590:      	ldr	x1, [x0, #0x28]
    5594:      	add	x1, x1, x4, lsl #4
    5598:      	ldr	x3, [x1]
    559c:      	ldr	x1, [x1, #0x8]
    55a0:      	mov	w4, #0x1                ; =1
    55a4:      	b	0x55b4 <_stogir.locals.validate+0x1ac>
    55a8:      	movz	w4, #0x0, lsl #16
    55ac:      	movz	x3, #0x0, lsl #48
    55b0:      	movz	x1, #0x0, lsl #48
    55b4:      	ubfx	x4, x4, #0, #32
    55b8:      	lsr	x16, x4, #0
    55bc:      	cmp	x16, #0x1
    55c0:      	b.eq	0x55dc <_stogir.locals.validate+0x1d4>
    55c4:      	b.lo	0x55cc <_stogir.locals.validate+0x1c4>
    55c8:      	b	0x55e0 <_stogir.locals.validate+0x1d8>
    55cc:      	cmp	x16, #0x0
    55d0:      	b.eq	0x55d8 <_stogir.locals.validate+0x1d0>
    55d4:      	b	0x55e0 <_stogir.locals.validate+0x1d8>
    55d8:      	b	0x55e4 <_stogir.locals.validate+0x1dc>
    55dc:      	b	0x563c <_stogir.locals.validate+0x234>
    55e0:      	b	0x57f0 <_stogir.locals.validate+0x3e8>
    55e4:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		00000000000055e4:  ARM64_RELOC_PAGE21	l_stogir.397
    55e8:      	ldr	x16, [x16]
		00000000000055e8:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    55ec:      	orr	x0, x16, xzr
    55f0:      	mov	x22, x8
    55f4:      	mov	x2, #0x1                ; =1
    55f8:      	mov	x1, #0x17               ; =23
    55fc:      	str	x2, [x22]
    5600:      	str	x0, [x22, #0x8]
    5604:      	str	x1, [x22, #0x10]
    5608:      	ldr	x19, [sp, #0x60]
    560c:      	ldr	x20, [sp, #0x68]
    5610:      	ldr	x21, [sp, #0x70]
    5614:      	ldr	x22, [sp, #0x78]
    5618:      	ldr	x23, [sp, #0x80]
    561c:      	ldr	x24, [sp, #0x88]
    5620:      	ldr	x25, [sp, #0x90]
    5624:      	ldr	x26, [sp, #0x98]
    5628:      	ldr	x27, [sp, #0xa0]
    562c:      	ldr	x29, [sp]
    5630:      	ldr	x30, [sp, #0x8]
    5634:      	add	sp, sp, #0xb0
    5638:      	ret
    563c:      	add	x16, sp, #0x10
    5640:      	orr	x21, x16, xzr
    5644:      	add	x16, sp, #0x10
    5648:      	str	x3, [x16]
    564c:      	add	x16, sp, #0x10
    5650:      	str	x1, [x16, #0x8]
    5654:      	mov	x22, x8
    5658:      	mov	x23, x0
    565c:      	mov	x0, x21
    5660:      	mov	w24, w2
    5664:      	bl	0x5664 <_stogir.locals.validate+0x25c>
		0000000000005664:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    5668:      	uxtb	w0, w0
    566c:      	cmp	x0, #0x55
    5670:      	b.ne	0x56ac <_stogir.locals.validate+0x2a4>
    5674:      	mov	x1, #0x1                ; =1
    5678:      	b	0x56b8 <_stogir.locals.validate+0x2b0>
    567c:      	movz	x3, #0x0, lsl #48
    5680:      	b	0x5560 <_stogir.locals.validate+0x158>
    5684:      	cmp	x0, #0x58
    5688:      	cset	w2, eq
    568c:      	ubfx	x25, x2, #0, #8
    5690:      	cmp	x0, #0x41
    5694:      	cset	w26, eq
    5698:      	uxtb	w16, w26
    569c:      	cmp	w16, wzr
    56a0:      	b.eq	0x54f0 <_stogir.locals.validate+0xe8>
    56a4:      	mov	w1, #0x1                ; =1
    56a8:      	b	0x550c <_stogir.locals.validate+0x104>
    56ac:      	cmp	x0, #0x56
    56b0:      	cset	w1, eq
    56b4:      	ubfx	x1, x1, #0, #8
    56b8:      	cmp	x0, #0x57
    56bc:      	b.ne	0x5684 <_stogir.locals.validate+0x27c>
    56c0:      	mov	x25, #0x1               ; =1
    56c4:      	b	0x5690 <_stogir.locals.validate+0x288>
    56c8:      	movz	x3, #0x0, lsl #48
    56cc:      	b	0x54ec <_stogir.locals.validate+0xe4>
    56d0:      	sxtw	x1, w1
    56d4:      	ldr	x0, [x23, #0x78]
    56d8:      	add	x0, x20, x0
    56dc:      	ldr	w0, [x0]
    56e0:      	sxtw	x0, w0
    56e4:      	cmp	x0, x1
    56e8:      	b.ne	0x5544 <_stogir.locals.validate+0x13c>
    56ec:      	uxtb	w16, w26
    56f0:      	cmp	w16, wzr
    56f4:      	b.ne	0x5714 <_stogir.locals.validate+0x30c>
    56f8:      	uxtb	w16, w27
    56fc:      	cmp	w16, wzr
    5700:      	b.ne	0x5714 <_stogir.locals.validate+0x30c>
    5704:      	add	x16, sp, #0x10
    5708:      	ldr	w0, [x16, #0x8]
    570c:      	sxtw	x19, w0
    5710:      	b	0x572c <_stogir.locals.validate+0x324>
    5714:      	uxtb	w16, w27
    5718:      	cmp	w16, wzr
    571c:      	b.ne	0x572c <_stogir.locals.validate+0x324>
    5720:      	add	x16, sp, #0x10
    5724:      	ldr	w0, [x16, #0x4]
    5728:      	sxtw	x19, w0
    572c:      	add	x16, sp, #0x20
    5730:      	orr	x20, x16, xzr
    5734:      	add	x8, sp, #0x20
    5738:      	mov	x0, x23
    573c:      	mov	w1, w19
    5740:      	mov	w2, w24
    5744:      	bl	0x5744 <_stogir.locals.validate+0x33c>
		0000000000005744:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    5748:      	add	x16, sp, #0x20
    574c:      	ldr	w0, [x16]
    5750:      	lsr	x16, x0, #0
    5754:      	cmp	x16, #0x1
    5758:      	b.eq	0x5774 <_stogir.locals.validate+0x36c>
    575c:      	b.lo	0x5764 <_stogir.locals.validate+0x35c>
    5760:      	b	0x5778 <_stogir.locals.validate+0x370>
    5764:      	cmp	x16, #0x0
    5768:      	b.eq	0x5770 <_stogir.locals.validate+0x368>
    576c:      	b	0x5778 <_stogir.locals.validate+0x370>
    5770:      	b	0x5794 <_stogir.locals.validate+0x38c>
    5774:      	b	0x577c <_stogir.locals.validate+0x374>
    5778:      	b	0x5a5c <_stogir.locals.validate+0x654>
    577c:      	add	x1, x20, #0x8
    5780:      	add	x16, sp, #0x20
    5784:      	ldr	x0, [x16, #0x8]
    5788:      	ldr	x1, [x1, #0x8]
    578c:      	mov	x2, #0x1                ; =1
    5790:      	b	0x5558 <_stogir.locals.validate+0x150>
    5794:      	add	x16, sp, #0x20
    5798:      	ldr	x19, [x16, #0x8]
    579c:      	uxtb	w16, w27
    57a0:      	cmp	w16, wzr
    57a4:      	b.eq	0x57bc <_stogir.locals.validate+0x3b4>
    57a8:      	sxtw	x19, w19
    57ac:      	and	x0, x19, #0xffffffff
    57b0:      	movz	x2, #0x0, lsl #48
    57b4:      	movz	x1, #0x0, lsl #48
    57b8:      	b	0x5790 <_stogir.locals.validate+0x388>
    57bc:      	uxtb	w16, w26
    57c0:      	cmp	w16, wzr
    57c4:      	b.eq	0x5810 <_stogir.locals.validate+0x408>
    57c8:      	mov	x0, x21
    57cc:      	bl	0x57cc <_stogir.locals.validate+0x3c4>
		00000000000057cc:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    57d0:      	uxtb	w0, w0
    57d4:      	cmp	x0, #0x6
    57d8:      	b.ne	0x57f8 <_stogir.locals.validate+0x3f0>
    57dc:      	sxtw	x24, w24
    57e0:      	and	x0, x24, #0xffffffff
    57e4:      	movz	x2, #0x0, lsl #48
    57e8:      	movz	x1, #0x0, lsl #48
    57ec:      	b	0x580c <_stogir.locals.validate+0x404>
    57f0:      	brk	#0
    57f4:      	b	0x57f0 <_stogir.locals.validate+0x3e8>
    57f8:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		00000000000057f8:  ARM64_RELOC_PAGE21	l_stogir.398
    57fc:      	ldr	x16, [x16]
		00000000000057fc:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    5800:      	orr	x0, x16, xzr
    5804:      	mov	x2, #0x1                ; =1
    5808:      	mov	x1, #0x21               ; =33
    580c:      	b	0x57b8 <_stogir.locals.validate+0x3b0>
    5810:      	add	x16, sp, #0x10
    5814:      	ldr	w0, [x16, #0x4]
    5818:      	sxtw	x0, w0
    581c:      	cmp	x0, #0x0
    5820:      	cset	w1, gt
    5824:      	movz	x16, #0x0, lsl #48
    5828:      	sub	x2, x16, x0
    582c:      	sub	x3, x2, #0x1
    5830:      	uxtb	w16, w1
    5834:      	cmp	w16, wzr
    5838:      	b.eq	0x5918 <_stogir.locals.validate+0x510>
    583c:      	ldr	x2, [x23, #0x8]
    5840:      	cmp	x0, x2
    5844:      	b.ge	0x5910 <_stogir.locals.validate+0x508>
    5848:      	add	x2, x23, #0x78
    584c:      	ldr	x2, [x2, #0x8]
    5850:      	cmp	x0, x2
    5854:      	b.ge	0x5a4c <_stogir.locals.validate+0x644>
    5858:      	ldr	x2, [x23, #0x78]
    585c:      	add	x2, x2, x0, lsl #2
    5860:      	ldr	w2, [x2]
    5864:      	sxtw	x2, w2
    5868:      	cmp	x2, #0x0
    586c:      	cset	w2, ge
    5870:      	ubfx	x2, x2, #0, #8
    5874:      	b	0x5a50 <_stogir.locals.validate+0x648>
    5878:      	movz	w2, #0x0, lsl #16
    587c:      	movz	x1, #0x0, lsl #48
    5880:      	movz	x0, #0x0, lsl #48
    5884:      	ubfx	x2, x2, #0, #32
    5888:      	lsr	x16, x2, #0
    588c:      	cmp	x16, #0x1
    5890:      	b.eq	0x58ac <_stogir.locals.validate+0x4a4>
    5894:      	b.lo	0x589c <_stogir.locals.validate+0x494>
    5898:      	b	0x58b0 <_stogir.locals.validate+0x4a8>
    589c:      	cmp	x16, #0x0
    58a0:      	b.eq	0x58a8 <_stogir.locals.validate+0x4a0>
    58a4:      	b	0x58b0 <_stogir.locals.validate+0x4a8>
    58a8:      	b	0x58b4 <_stogir.locals.validate+0x4ac>
    58ac:      	b	0x5960 <_stogir.locals.validate+0x558>
    58b0:      	b	0x5bd8 <_stogir.locals.validate+0x7d0>
    58b4:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		00000000000058b4:  ARM64_RELOC_PAGE21	l_stogir.399
    58b8:      	ldr	x16, [x16]
		00000000000058b8:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    58bc:      	orr	x0, x16, xzr
    58c0:      	mov	x2, #0x1                ; =1
    58c4:      	mov	x1, #0x1c               ; =28
    58c8:      	b	0x580c <_stogir.locals.validate+0x404>
    58cc:      	ldr	x0, [x23, #0x28]
    58d0:      	add	x0, x0, x3, lsl #4
    58d4:      	ldr	x1, [x0]
    58d8:      	ldr	x0, [x0, #0x8]
    58dc:      	mov	w2, #0x1                ; =1
    58e0:      	b	0x5884 <_stogir.locals.validate+0x47c>
    58e4:      	movz	x2, #0x0, lsl #48
    58e8:      	cmp	x2, #0x0
    58ec:      	b.eq	0x5878 <_stogir.locals.validate+0x470>
    58f0:      	uxtb	w16, w1
    58f4:      	cmp	w16, wzr
    58f8:      	b.eq	0x58cc <_stogir.locals.validate+0x4c4>
    58fc:      	ldr	x1, [x23]
    5900:      	add	x0, x1, x0, lsl #4
    5904:      	ldr	x1, [x0]
    5908:      	ldr	x0, [x0, #0x8]
    590c:      	b	0x58dc <_stogir.locals.validate+0x4d4>
    5910:      	movz	x2, #0x0, lsl #48
    5914:      	b	0x58e8 <_stogir.locals.validate+0x4e0>
    5918:      	cmp	x0, #0x0
    591c:      	b.ge	0x58e4 <_stogir.locals.validate+0x4dc>
    5920:      	add	x4, x23, #0x28
    5924:      	add	x5, x23, #0x50
    5928:      	ldr	x4, [x4, #0x8]
    592c:      	ldr	x5, [x5, #0x8]
    5930:      	cmp	x4, x5
    5934:      	b.ne	0x5a44 <_stogir.locals.validate+0x63c>
    5938:      	cmp	x2, x4
    593c:      	b.gt	0x5a54 <_stogir.locals.validate+0x64c>
    5940:      	ldr	x2, [x23, #0x50]
    5944:      	add	x2, x2, x3, lsl #2
    5948:      	ldr	w2, [x2]
    594c:      	sxtw	x2, w2
    5950:      	cmp	x2, #0x0
    5954:      	cset	w2, gt
    5958:      	ubfx	x2, x2, #0, #8
    595c:      	b	0x5a58 <_stogir.locals.validate+0x650>
    5960:      	add	x16, sp, #0x40
    5964:      	str	x1, [x16]
    5968:      	add	x16, sp, #0x40
    596c:      	str	x0, [x16, #0x8]
    5970:      	add	x16, sp, #0x10
    5974:      	ldr	w0, [x16, #0x4]
    5978:      	sxtw	x0, w0
    597c:      	cmp	x0, #0x0
    5980:      	b.le	0x5a2c <_stogir.locals.validate+0x624>
    5984:      	add	x16, sp, #0x40
    5988:      	orr	x20, x16, xzr
    598c:      	mov	x0, x20
    5990:      	bl	0x5990 <_stogir.locals.validate+0x588>
		0000000000005990:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    5994:      	uxtb	w0, w0
    5998:      	bl	0x5998 <_stogir.locals.validate+0x590>
		0000000000005998:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    599c:      	cmp	x0, #0x0
    59a0:      	b.eq	0x5a2c <_stogir.locals.validate+0x624>
    59a4:      	mov	x0, x20
    59a8:      	bl	0x59a8 <_stogir.locals.validate+0x5a0>
		00000000000059a8:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    59ac:      	uxtb	w0, w0
    59b0:      	bl	0x59b0 <_stogir.locals.validate+0x5a8>
		00000000000059b0:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    59b4:      	cmp	x0, #0x0
    59b8:      	b.ne	0x5a2c <_stogir.locals.validate+0x624>
    59bc:      	cmp	x25, #0x0
    59c0:      	b.eq	0x5ae8 <_stogir.locals.validate+0x6e0>
    59c4:      	add	x16, sp, #0x10
    59c8:      	ldr	w0, [x16, #0xc]
    59cc:      	sxtw	x0, w0
    59d0:      	cmp	x0, #0x0
    59d4:      	cset	w1, gt
    59d8:      	movz	x16, #0x0, lsl #48
    59dc:      	sub	x2, x16, x0
    59e0:      	sub	x3, x2, #0x1
    59e4:      	uxtb	w16, w1
    59e8:      	cmp	w16, wzr
    59ec:      	b.eq	0x5b90 <_stogir.locals.validate+0x788>
    59f0:      	ldr	x2, [x23, #0x8]
    59f4:      	cmp	x0, x2
    59f8:      	b.ge	0x5b88 <_stogir.locals.validate+0x780>
    59fc:      	add	x2, x23, #0x78
    5a00:      	ldr	x2, [x2, #0x8]
    5a04:      	cmp	x0, x2
    5a08:      	b.ge	0x5be8 <_stogir.locals.validate+0x7e0>
    5a0c:      	ldr	x2, [x23, #0x78]
    5a10:      	add	x2, x2, x0, lsl #2
    5a14:      	ldr	w2, [x2]
    5a18:      	sxtw	x2, w2
    5a1c:      	cmp	x2, #0x0
    5a20:      	cset	w2, ge
    5a24:      	ubfx	x2, x2, #0, #8
    5a28:      	b	0x5bec <_stogir.locals.validate+0x7e4>
    5a2c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005a2c:  ARM64_RELOC_PAGE21	l_stogir.400
    5a30:      	ldr	x16, [x16]
		0000000000005a30:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    5a34:      	orr	x0, x16, xzr
    5a38:      	mov	x2, #0x1                ; =1
    5a3c:      	mov	x1, #0x1c               ; =28
    5a40:      	b	0x58c8 <_stogir.locals.validate+0x4c0>
    5a44:      	movz	x2, #0x0, lsl #48
    5a48:      	b	0x58e8 <_stogir.locals.validate+0x4e0>
    5a4c:      	movz	x2, #0x0, lsl #48
    5a50:      	b	0x5914 <_stogir.locals.validate+0x50c>
    5a54:      	movz	x2, #0x0, lsl #48
    5a58:      	b	0x5a48 <_stogir.locals.validate+0x640>
    5a5c:      	brk	#0
    5a60:      	b	0x5a5c <_stogir.locals.validate+0x654>
    5a64:      	add	x16, sp, #0x50
    5a68:      	orr	x20, x16, xzr
    5a6c:      	add	x16, sp, #0x50
    5a70:      	str	x1, [x16]
    5a74:      	add	x16, sp, #0x50
    5a78:      	str	x0, [x16, #0x8]
    5a7c:      	mov	x0, x20
    5a80:      	bl	0x5a80 <_stogir.locals.validate+0x678>
		0000000000005a80:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    5a84:      	uxtb	w0, w0
    5a88:      	mov	w1, w24
    5a8c:      	bl	0x5a8c <_stogir.locals.validate+0x684>
		0000000000005a8c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    5a90:      	sxtw	x23, w0
    5a94:      	cmp	x23, #0x0
    5a98:      	b.le	0x5ac0 <_stogir.locals.validate+0x6b8>
    5a9c:      	cmp	x23, x19
    5aa0:      	b.gt	0x5ac0 <_stogir.locals.validate+0x6b8>
    5aa4:      	cmp	x25, #0x0
    5aa8:      	b.eq	0x5bf8 <_stogir.locals.validate+0x7f0>
    5aac:      	mov	x0, x21
    5ab0:      	bl	0x5ab0 <_stogir.locals.validate+0x6a8>
		0000000000005ab0:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    5ab4:      	uxtb	w0, w0
    5ab8:      	cmp	x0, #0x0
    5abc:      	b.eq	0x5bf8 <_stogir.locals.validate+0x7f0>
    5ac0:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005ac0:  ARM64_RELOC_PAGE21	l_stogir.401
    5ac4:      	ldr	x16, [x16]
		0000000000005ac4:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    5ac8:      	orr	x0, x16, xzr
    5acc:      	mov	x2, #0x1                ; =1
    5ad0:      	mov	x1, #0x23               ; =35
    5ad4:      	b	0x5a40 <_stogir.locals.validate+0x638>
    5ad8:      	movz	w2, #0x0, lsl #16
    5adc:      	movz	x1, #0x0, lsl #48
    5ae0:      	movz	x0, #0x0, lsl #48
    5ae4:      	b	0x5afc <_stogir.locals.validate+0x6f4>
    5ae8:      	add	x16, sp, #0x10
    5aec:      	ldr	x1, [x16]
    5af0:      	add	x16, sp, #0x10
    5af4:      	ldr	x0, [x16, #0x8]
    5af8:      	mov	w2, #0x1                ; =1
    5afc:      	ubfx	x2, x2, #0, #32
    5b00:      	lsr	x16, x2, #0
    5b04:      	cmp	x16, #0x1
    5b08:      	b.eq	0x5b24 <_stogir.locals.validate+0x71c>
    5b0c:      	b.lo	0x5b14 <_stogir.locals.validate+0x70c>
    5b10:      	b	0x5b28 <_stogir.locals.validate+0x720>
    5b14:      	cmp	x16, #0x0
    5b18:      	b.eq	0x5b20 <_stogir.locals.validate+0x718>
    5b1c:      	b	0x5b28 <_stogir.locals.validate+0x720>
    5b20:      	b	0x5b2c <_stogir.locals.validate+0x724>
    5b24:      	b	0x5a64 <_stogir.locals.validate+0x65c>
    5b28:      	b	0x5c1c <_stogir.locals.validate+0x814>
    5b2c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005b2c:  ARM64_RELOC_PAGE21	l_stogir.402
    5b30:      	ldr	x16, [x16]
		0000000000005b30:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    5b34:      	orr	x0, x16, xzr
    5b38:      	mov	x2, #0x1                ; =1
    5b3c:      	mov	x1, #0x19               ; =25
    5b40:      	b	0x5ad4 <_stogir.locals.validate+0x6cc>
    5b44:      	ldr	x0, [x23, #0x28]
    5b48:      	add	x0, x0, x3, lsl #4
    5b4c:      	ldr	x1, [x0]
    5b50:      	ldr	x0, [x0, #0x8]
    5b54:      	mov	w2, #0x1                ; =1
    5b58:      	b	0x5ae4 <_stogir.locals.validate+0x6dc>
    5b5c:      	movz	x2, #0x0, lsl #48
    5b60:      	cmp	x2, #0x0
    5b64:      	b.eq	0x5ad8 <_stogir.locals.validate+0x6d0>
    5b68:      	uxtb	w16, w1
    5b6c:      	cmp	w16, wzr
    5b70:      	b.eq	0x5b44 <_stogir.locals.validate+0x73c>
    5b74:      	ldr	x1, [x23]
    5b78:      	add	x0, x1, x0, lsl #4
    5b7c:      	ldr	x1, [x0]
    5b80:      	ldr	x0, [x0, #0x8]
    5b84:      	b	0x5b54 <_stogir.locals.validate+0x74c>
    5b88:      	movz	x2, #0x0, lsl #48
    5b8c:      	b	0x5b60 <_stogir.locals.validate+0x758>
    5b90:      	cmp	x0, #0x0
    5b94:      	b.ge	0x5b5c <_stogir.locals.validate+0x754>
    5b98:      	add	x4, x23, #0x28
    5b9c:      	add	x5, x23, #0x50
    5ba0:      	ldr	x4, [x4, #0x8]
    5ba4:      	ldr	x5, [x5, #0x8]
    5ba8:      	cmp	x4, x5
    5bac:      	b.ne	0x5be0 <_stogir.locals.validate+0x7d8>
    5bb0:      	cmp	x2, x4
    5bb4:      	b.gt	0x5bf0 <_stogir.locals.validate+0x7e8>
    5bb8:      	ldr	x2, [x23, #0x50]
    5bbc:      	add	x2, x2, x3, lsl #2
    5bc0:      	ldr	w2, [x2]
    5bc4:      	sxtw	x2, w2
    5bc8:      	cmp	x2, #0x0
    5bcc:      	cset	w2, gt
    5bd0:      	ubfx	x2, x2, #0, #8
    5bd4:      	b	0x5bf4 <_stogir.locals.validate+0x7ec>
    5bd8:      	brk	#0
    5bdc:      	b	0x5bd8 <_stogir.locals.validate+0x7d0>
    5be0:      	movz	x2, #0x0, lsl #48
    5be4:      	b	0x5b60 <_stogir.locals.validate+0x758>
    5be8:      	movz	x2, #0x0, lsl #48
    5bec:      	b	0x5b8c <_stogir.locals.validate+0x784>
    5bf0:      	movz	x2, #0x0, lsl #48
    5bf4:      	b	0x5be4 <_stogir.locals.validate+0x7dc>
    5bf8:      	mov	x0, x20
    5bfc:      	bl	0x5bfc <_stogir.locals.validate+0x7f4>
		0000000000005bfc:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    5c00:      	uxtb	w0, w0
    5c04:      	cmp	x0, #0x48
    5c08:      	b.eq	0x5ac0 <_stogir.locals.validate+0x6b8>
    5c0c:      	and	x0, x23, #0xffffffff
    5c10:      	movz	x2, #0x0, lsl #48
    5c14:      	movz	x1, #0x0, lsl #48
    5c18:      	b	0x5ad4 <_stogir.locals.validate+0x6cc>
    5c1c:      	brk	#0
    5c20:      	b	0x5c1c <_stogir.locals.validate+0x814>

0000000000005c24 <_stogir.conversion.validate>:
    5c24:      	sub	sp, sp, #0x40
    5c28:      	str	x29, [sp]
    5c2c:      	str	x30, [sp, #0x8]
    5c30:      	mov	x29, sp
    5c34:      	str	x19, [sp, #0x30]
    5c38:      	sxtw	x1, w1
    5c3c:      	lsl	x3, x1, #2
    5c40:      	cmp	x1, #0x0
    5c44:      	cset	w4, gt
    5c48:      	movz	x16, #0x0, lsl #48
    5c4c:      	sub	x5, x16, x1
    5c50:      	sub	x6, x5, #0x1
    5c54:      	uxtb	w16, w4
    5c58:      	cmp	w16, wzr
    5c5c:      	b.eq	0x5c9c <_stogir.conversion.validate+0x78>
    5c60:      	ldr	x5, [x0, #0x8]
    5c64:      	cmp	x1, x5
    5c68:      	b.ge	0x5cec <_stogir.conversion.validate+0xc8>
    5c6c:      	add	x5, x0, #0x78
    5c70:      	ldr	x5, [x5, #0x8]
    5c74:      	cmp	x1, x5
    5c78:      	b.ge	0x5dc4 <_stogir.conversion.validate+0x1a0>
    5c7c:      	ldr	x5, [x0, #0x78]
    5c80:      	add	x5, x3, x5
    5c84:      	ldr	w5, [x5]
    5c88:      	sxtw	x5, w5
    5c8c:      	cmp	x5, #0x0
    5c90:      	cset	w5, ge
    5c94:      	ubfx	x5, x5, #0, #8
    5c98:      	b	0x5dc8 <_stogir.conversion.validate+0x1a4>
    5c9c:      	cmp	x1, #0x0
    5ca0:      	b.ge	0x5cf4 <_stogir.conversion.validate+0xd0>
    5ca4:      	add	x7, x0, #0x28
    5ca8:      	add	x9, x0, #0x50
    5cac:      	ldr	x7, [x7, #0x8]
    5cb0:      	ldr	x9, [x9, #0x8]
    5cb4:      	cmp	x7, x9
    5cb8:      	b.ne	0x5ce4 <_stogir.conversion.validate+0xc0>
    5cbc:      	cmp	x5, x7
    5cc0:      	b.gt	0x5e58 <_stogir.conversion.validate+0x234>
    5cc4:      	ldr	x5, [x0, #0x50]
    5cc8:      	add	x5, x5, x6, lsl #2
    5ccc:      	ldr	w5, [x5]
    5cd0:      	sxtw	x5, w5
    5cd4:      	cmp	x5, #0x0
    5cd8:      	cset	w5, gt
    5cdc:      	ubfx	x5, x5, #0, #8
    5ce0:      	b	0x5e5c <_stogir.conversion.validate+0x238>
    5ce4:      	movz	x5, #0x0, lsl #48
    5ce8:      	b	0x5cf8 <_stogir.conversion.validate+0xd4>
    5cec:      	movz	x5, #0x0, lsl #48
    5cf0:      	b	0x5cf8 <_stogir.conversion.validate+0xd4>
    5cf4:      	movz	x5, #0x0, lsl #48
    5cf8:      	cmp	x5, #0x0
    5cfc:      	b.eq	0x5d30 <_stogir.conversion.validate+0x10c>
    5d00:      	uxtb	w16, w4
    5d04:      	cmp	w16, wzr
    5d08:      	b.eq	0x5d1c <_stogir.conversion.validate+0xf8>
    5d0c:      	ldr	x4, [x0]
    5d10:      	add	x4, x4, x1, lsl #4
    5d14:      	ldr	x4, [x4]
    5d18:      	b	0x5d28 <_stogir.conversion.validate+0x104>
    5d1c:      	ldr	x4, [x0, #0x28]
    5d20:      	add	x4, x4, x6, lsl #4
    5d24:      	ldr	x4, [x4]
    5d28:      	mov	w5, #0x1                ; =1
    5d2c:      	b	0x5d38 <_stogir.conversion.validate+0x114>
    5d30:      	movz	w5, #0x0, lsl #16
    5d34:      	movz	x4, #0x0, lsl #48
    5d38:      	ubfx	x5, x5, #0, #32
    5d3c:      	lsr	x16, x5, #0
    5d40:      	cmp	x16, #0x1
    5d44:      	b.eq	0x5d60 <_stogir.conversion.validate+0x13c>
    5d48:      	b.lo	0x5d50 <_stogir.conversion.validate+0x12c>
    5d4c:      	b	0x5d64 <_stogir.conversion.validate+0x140>
    5d50:      	cmp	x16, #0x0
    5d54:      	b.eq	0x5d5c <_stogir.conversion.validate+0x138>
    5d58:      	b	0x5d64 <_stogir.conversion.validate+0x140>
    5d5c:      	b	0x5d68 <_stogir.conversion.validate+0x144>
    5d60:      	b	0x5da0 <_stogir.conversion.validate+0x17c>
    5d64:      	b	0x5ed0 <_stogir.conversion.validate+0x2ac>
    5d68:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005d68:  ARM64_RELOC_PAGE21	l_stogir.403
    5d6c:      	ldr	x16, [x16]
		0000000000005d6c:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    5d70:      	orr	x0, x16, xzr
    5d74:      	mov	x19, x8
    5d78:      	mov	x1, #0x1                ; =1
    5d7c:      	mov	x2, #0x12               ; =18
    5d80:      	str	x1, [x19]
    5d84:      	str	x0, [x19, #0x8]
    5d88:      	str	x2, [x19, #0x10]
    5d8c:      	ldr	x19, [sp, #0x30]
    5d90:      	ldr	x29, [sp]
    5d94:      	ldr	x30, [sp, #0x8]
    5d98:      	add	sp, sp, #0x40
    5d9c:      	ret
    5da0:      	cmp	x1, #0x0
    5da4:      	b.gt	0x5dcc <_stogir.conversion.validate+0x1a8>
    5da8:      	mov	x19, x8
    5dac:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005dac:  ARM64_RELOC_PAGE21	l_stogir.404
    5db0:      	ldr	x16, [x16]
		0000000000005db0:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    5db4:      	orr	x0, x16, xzr
    5db8:      	mov	x1, #0x1                ; =1
    5dbc:      	mov	x2, #0x1e               ; =30
    5dc0:      	b	0x5d80 <_stogir.conversion.validate+0x15c>
    5dc4:      	movz	x5, #0x0, lsl #48
    5dc8:      	b	0x5cf0 <_stogir.conversion.validate+0xcc>
    5dcc:      	uxtb	w1, w4
    5dd0:      	orr	x5, x1, xzr
    5dd4:      	cmp	x5, #0x21
    5dd8:      	b.lt	0x5fe8 <_stogir.conversion.validate+0x3c4>
    5ddc:      	cmp	x5, #0x27
    5de0:      	b.gt	0x5ff0 <_stogir.conversion.validate+0x3cc>
    5de4:      	ldr	x5, [x0, #0x78]
    5de8:      	add	x3, x3, x5
    5dec:      	ldr	w3, [x3]
    5df0:      	sxtw	x3, w3
    5df4:      	cmp	x3, #0x1
    5df8:      	b.ne	0x5ff8 <_stogir.conversion.validate+0x3d4>
    5dfc:      	asr	x3, x4, #32
    5e00:      	cmp	x3, #0x0
    5e04:      	cset	w6, gt
    5e08:      	movz	x16, #0x0, lsl #48
    5e0c:      	sub	x7, x16, x3
    5e10:      	sub	x9, x7, #0x1
    5e14:      	uxtb	w16, w6
    5e18:      	cmp	w16, wzr
    5e1c:      	b.eq	0x5e88 <_stogir.conversion.validate+0x264>
    5e20:      	ldr	x7, [x0, #0x8]
    5e24:      	cmp	x3, x7
    5e28:      	b.ge	0x5ed8 <_stogir.conversion.validate+0x2b4>
    5e2c:      	add	x7, x0, #0x78
    5e30:      	ldr	x7, [x7, #0x8]
    5e34:      	cmp	x3, x7
    5e38:      	b.ge	0x5f78 <_stogir.conversion.validate+0x354>
    5e3c:      	add	x5, x5, x3, lsl #2
    5e40:      	ldr	w5, [x5]
    5e44:      	sxtw	x5, w5
    5e48:      	cmp	x5, #0x0
    5e4c:      	cset	w5, ge
    5e50:      	ubfx	x5, x5, #0, #8
    5e54:      	b	0x5f7c <_stogir.conversion.validate+0x358>
    5e58:      	movz	x5, #0x0, lsl #48
    5e5c:      	b	0x5ce8 <_stogir.conversion.validate+0xc4>
    5e60:      	uxtb	w3, w0
    5e64:      	cmp	x3, #0x48
    5e68:      	b.ne	0x5f80 <_stogir.conversion.validate+0x35c>
    5e6c:      	mov	x19, x8
    5e70:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005e70:  ARM64_RELOC_PAGE21	l_stogir.405
    5e74:      	ldr	x16, [x16]
		0000000000005e74:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    5e78:      	orr	x0, x16, xzr
    5e7c:      	mov	x1, #0x1                ; =1
    5e80:      	mov	x2, #0x25               ; =37
    5e84:      	b	0x5dc0 <_stogir.conversion.validate+0x19c>
    5e88:      	cmp	x3, #0x0
    5e8c:      	b.ge	0x5ee0 <_stogir.conversion.validate+0x2bc>
    5e90:      	add	x5, x0, #0x28
    5e94:      	add	x10, x0, #0x50
    5e98:      	ldr	x5, [x5, #0x8]
    5e9c:      	ldr	x10, [x10, #0x8]
    5ea0:      	cmp	x5, x10
    5ea4:      	b.ne	0x5f70 <_stogir.conversion.validate+0x34c>
    5ea8:      	cmp	x7, x5
    5eac:      	b.gt	0x5fd8 <_stogir.conversion.validate+0x3b4>
    5eb0:      	ldr	x5, [x0, #0x50]
    5eb4:      	add	x5, x5, x9, lsl #2
    5eb8:      	ldr	w5, [x5]
    5ebc:      	sxtw	x5, w5
    5ec0:      	cmp	x5, #0x0
    5ec4:      	cset	w5, gt
    5ec8:      	ubfx	x5, x5, #0, #8
    5ecc:      	b	0x5fdc <_stogir.conversion.validate+0x3b8>
    5ed0:      	brk	#0
    5ed4:      	b	0x5ed0 <_stogir.conversion.validate+0x2ac>
    5ed8:      	movz	x5, #0x0, lsl #48
    5edc:      	b	0x5ee4 <_stogir.conversion.validate+0x2c0>
    5ee0:      	movz	x5, #0x0, lsl #48
    5ee4:      	cmp	x5, #0x0
    5ee8:      	b.eq	0x5f1c <_stogir.conversion.validate+0x2f8>
    5eec:      	uxtb	w16, w6
    5ef0:      	cmp	w16, wzr
    5ef4:      	b.eq	0x5f08 <_stogir.conversion.validate+0x2e4>
    5ef8:      	ldr	x0, [x0]
    5efc:      	add	x0, x0, x3, lsl #4
    5f00:      	ldr	x0, [x0]
    5f04:      	b	0x5f14 <_stogir.conversion.validate+0x2f0>
    5f08:      	ldr	x0, [x0, #0x28]
    5f0c:      	add	x0, x0, x9, lsl #4
    5f10:      	ldr	x0, [x0]
    5f14:      	mov	w3, #0x1                ; =1
    5f18:      	b	0x5f24 <_stogir.conversion.validate+0x300>
    5f1c:      	movz	w3, #0x0, lsl #16
    5f20:      	movz	x0, #0x0, lsl #48
    5f24:      	ubfx	x3, x3, #0, #32
    5f28:      	lsr	x16, x3, #0
    5f2c:      	cmp	x16, #0x1
    5f30:      	b.eq	0x5f4c <_stogir.conversion.validate+0x328>
    5f34:      	b.lo	0x5f3c <_stogir.conversion.validate+0x318>
    5f38:      	b	0x5f50 <_stogir.conversion.validate+0x32c>
    5f3c:      	cmp	x16, #0x0
    5f40:      	b.eq	0x5f48 <_stogir.conversion.validate+0x324>
    5f44:      	b	0x5f50 <_stogir.conversion.validate+0x32c>
    5f48:      	b	0x5f54 <_stogir.conversion.validate+0x330>
    5f4c:      	b	0x5e60 <_stogir.conversion.validate+0x23c>
    5f50:      	b	0x5fe0 <_stogir.conversion.validate+0x3bc>
    5f54:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x1f4>
		0000000000005f54:  ARM64_RELOC_PAGE21	l_stogir.406
    5f58:      	ldr	x16, [x16]
		0000000000005f58:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    5f5c:      	orr	x0, x16, xzr
    5f60:      	mov	x19, x8
    5f64:      	mov	x1, #0x1                ; =1
    5f68:      	mov	x2, #0x19               ; =25
    5f6c:      	b	0x5e84 <_stogir.conversion.validate+0x260>
    5f70:      	movz	x5, #0x0, lsl #48
    5f74:      	b	0x5ee4 <_stogir.conversion.validate+0x2c0>
    5f78:      	movz	x5, #0x0, lsl #48
    5f7c:      	b	0x5edc <_stogir.conversion.validate+0x2b8>
    5f80:      	cmp	x3, #0x46
    5f84:      	b.eq	0x6000 <_stogir.conversion.validate+0x3dc>
    5f88:      	ubfx	x4, x4, #0, #32
    5f8c:      	ubfx	x0, x0, #0, #32
    5f90:      	ubfx	x3, x4, #8, #8
    5f94:      	ubfx	x0, x0, #8, #8
    5f98:      	mov	x19, x8
    5f9c:      	add	x8, sp, #0x10
    5fa0:      	fmov	s31, w0
    5fa4:      	mov	w0, w1
    5fa8:      	fmov	w1, s31
    5fac:      	fmov	s31, w2
    5fb0:      	mov	w2, w3
    5fb4:      	fmov	w3, s31
    5fb8:      	bl	0x5fb8 <_stogir.conversion.validate+0x394>
		0000000000005fb8:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    5fbc:      	add	x16, sp, #0x10
    5fc0:      	ldr	x1, [x16]
    5fc4:      	add	x16, sp, #0x10
    5fc8:      	ldr	x0, [x16, #0x8]
    5fcc:      	add	x16, sp, #0x10
    5fd0:      	ldr	x2, [x16, #0x10]
    5fd4:      	b	0x5e84 <_stogir.conversion.validate+0x260>
    5fd8:      	movz	x5, #0x0, lsl #48
    5fdc:      	b	0x5f74 <_stogir.conversion.validate+0x350>
    5fe0:      	brk	#0
    5fe4:      	b	0x5fe0 <_stogir.conversion.validate+0x3bc>
    5fe8:      	mov	x19, x8
    5fec:      	b	0x5dac <_stogir.conversion.validate+0x188>
    5ff0:      	mov	x19, x8
    5ff4:      	b	0x5dac <_stogir.conversion.validate+0x188>
    5ff8:      	mov	x19, x8
    5ffc:      	b	0x5dac <_stogir.conversion.validate+0x188>
    6000:      	mov	x19, x8
    6004:      	b	0x5e70 <_stogir.conversion.validate+0x24c>

0000000000006008 <_stogir.conditional.validate>:
    6008:      	sub	sp, sp, #0x40
    600c:      	str	x29, [sp]
    6010:      	str	x30, [sp, #0x8]
    6014:      	mov	x29, sp
    6018:      	str	x19, [sp, #0x30]
    601c:      	sxtw	x1, w1
    6020:      	lsl	x2, x1, #2
    6024:      	cmp	x1, #0x0
    6028:      	cset	w3, gt
    602c:      	movz	x16, #0x0, lsl #48
    6030:      	sub	x4, x16, x1
    6034:      	sub	x5, x4, #0x1
    6038:      	uxtb	w16, w3
    603c:      	cmp	w16, wzr
    6040:      	b.eq	0x6080 <_stogir.conditional.validate+0x78>
    6044:      	ldr	x4, [x0, #0x8]
    6048:      	cmp	x1, x4
    604c:      	b.ge	0x60d0 <_stogir.conditional.validate+0xc8>
    6050:      	add	x4, x0, #0x78
    6054:      	ldr	x4, [x4, #0x8]
    6058:      	cmp	x1, x4
    605c:      	b.ge	0x61b4 <_stogir.conditional.validate+0x1ac>
    6060:      	ldr	x4, [x0, #0x78]
    6064:      	add	x4, x2, x4
    6068:      	ldr	w4, [x4]
    606c:      	sxtw	x4, w4
    6070:      	cmp	x4, #0x0
    6074:      	cset	w4, ge
    6078:      	ubfx	x4, x4, #0, #8
    607c:      	b	0x61b8 <_stogir.conditional.validate+0x1b0>
    6080:      	cmp	x1, #0x0
    6084:      	b.ge	0x60d8 <_stogir.conditional.validate+0xd0>
    6088:      	add	x6, x0, #0x28
    608c:      	add	x7, x0, #0x50
    6090:      	ldr	x6, [x6, #0x8]
    6094:      	ldr	x7, [x7, #0x8]
    6098:      	cmp	x6, x7
    609c:      	b.ne	0x60c8 <_stogir.conditional.validate+0xc0>
    60a0:      	cmp	x4, x6
    60a4:      	b.gt	0x6234 <_stogir.conditional.validate+0x22c>
    60a8:      	ldr	x4, [x0, #0x50]
    60ac:      	add	x4, x4, x5, lsl #2
    60b0:      	ldr	w4, [x4]
    60b4:      	sxtw	x4, w4
    60b8:      	cmp	x4, #0x0
    60bc:      	cset	w4, gt
    60c0:      	ubfx	x4, x4, #0, #8
    60c4:      	b	0x6238 <_stogir.conditional.validate+0x230>
    60c8:      	movz	x4, #0x0, lsl #48
    60cc:      	b	0x60dc <_stogir.conditional.validate+0xd4>
    60d0:      	movz	x4, #0x0, lsl #48
    60d4:      	b	0x60dc <_stogir.conditional.validate+0xd4>
    60d8:      	movz	x4, #0x0, lsl #48
    60dc:      	cmp	x4, #0x0
    60e0:      	b.eq	0x611c <_stogir.conditional.validate+0x114>
    60e4:      	uxtb	w16, w3
    60e8:      	cmp	w16, wzr
    60ec:      	b.eq	0x6104 <_stogir.conditional.validate+0xfc>
    60f0:      	ldr	x3, [x0]
    60f4:      	add	x3, x3, x1, lsl #4
    60f8:      	ldr	x4, [x3]
    60fc:      	ldr	x3, [x3, #0x8]
    6100:      	b	0x6114 <_stogir.conditional.validate+0x10c>
    6104:      	ldr	x3, [x0, #0x28]
    6108:      	add	x3, x3, x5, lsl #4
    610c:      	ldr	x4, [x3]
    6110:      	ldr	x3, [x3, #0x8]
    6114:      	mov	w5, #0x1                ; =1
    6118:      	b	0x6128 <_stogir.conditional.validate+0x120>
    611c:      	movz	w5, #0x0, lsl #16
    6120:      	movz	x4, #0x0, lsl #48
    6124:      	movz	x3, #0x0, lsl #48
    6128:      	ubfx	x5, x5, #0, #32
    612c:      	lsr	x16, x5, #0
    6130:      	cmp	x16, #0x1
    6134:      	b.eq	0x6150 <_stogir.conditional.validate+0x148>
    6138:      	b.lo	0x6140 <_stogir.conditional.validate+0x138>
    613c:      	b	0x6154 <_stogir.conditional.validate+0x14c>
    6140:      	cmp	x16, #0x0
    6144:      	b.eq	0x614c <_stogir.conditional.validate+0x144>
    6148:      	b	0x6154 <_stogir.conditional.validate+0x14c>
    614c:      	b	0x6158 <_stogir.conditional.validate+0x150>
    6150:      	b	0x6174 <_stogir.conditional.validate+0x16c>
    6154:      	b	0x623c <_stogir.conditional.validate+0x234>
    6158:      	adrp	x16, 0x6000 <_stogir.conversion.validate+0x3dc>
		0000000000006158:  ARM64_RELOC_PAGE21	l_stogir.407
    615c:      	ldr	x16, [x16]
		000000000000615c:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    6160:      	orr	x0, x16, xzr
    6164:      	mov	x19, x8
    6168:      	mov	x1, #0x1                ; =1
    616c:      	mov	x2, #0x18               ; =24
    6170:      	b	0x6194 <_stogir.conditional.validate+0x18c>
    6174:      	cmp	x1, #0x0
    6178:      	b.gt	0x61bc <_stogir.conditional.validate+0x1b4>
    617c:      	mov	x19, x8
    6180:      	adrp	x16, 0x6000 <_stogir.conversion.validate+0x3dc>
		0000000000006180:  ARM64_RELOC_PAGE21	l_stogir.408
    6184:      	ldr	x16, [x16]
		0000000000006184:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    6188:      	orr	x0, x16, xzr
    618c:      	mov	x1, #0x1                ; =1
    6190:      	mov	x2, #0x18               ; =24
    6194:      	str	x1, [x19]
    6198:      	str	x0, [x19, #0x8]
    619c:      	str	x2, [x19, #0x10]
    61a0:      	ldr	x19, [sp, #0x30]
    61a4:      	ldr	x29, [sp]
    61a8:      	ldr	x30, [sp, #0x8]
    61ac:      	add	sp, sp, #0x40
    61b0:      	ret
    61b4:      	movz	x4, #0x0, lsl #48
    61b8:      	b	0x60d4 <_stogir.conditional.validate+0xcc>
    61bc:      	uxtb	w1, w4
    61c0:      	cmp	x1, #0x3c
    61c4:      	b.ne	0x6244 <_stogir.conditional.validate+0x23c>
    61c8:      	ldr	x1, [x0, #0x78]
    61cc:      	add	x1, x2, x1
    61d0:      	ldr	w1, [x1]
    61d4:      	sxtw	x1, w1
    61d8:      	cmp	x1, #0x3
    61dc:      	b.ne	0x624c <_stogir.conditional.validate+0x244>
    61e0:      	orr	w1, w3, wzr
    61e4:      	orr	w2, w4, wzr
    61e8:      	lsr	x4, x4, #32
    61ec:      	lsr	x3, x3, #32
    61f0:      	ubfx	x2, x2, #0, #32
    61f4:      	ubfx	x2, x2, #8, #8
    61f8:      	mov	x19, x8
    61fc:      	add	x8, sp, #0x10
    6200:      	fmov	s31, w1
    6204:      	mov	w1, w2
    6208:      	mov	w2, w4
    620c:      	mov	w4, w3
    6210:      	fmov	w3, s31
    6214:      	bl	0x6214 <_stogir.conditional.validate+0x20c>
		0000000000006214:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    6218:      	add	x16, sp, #0x10
    621c:      	ldr	x1, [x16]
    6220:      	add	x16, sp, #0x10
    6224:      	ldr	x0, [x16, #0x8]
    6228:      	add	x16, sp, #0x10
    622c:      	ldr	x2, [x16, #0x10]
    6230:      	b	0x6194 <_stogir.conditional.validate+0x18c>
    6234:      	movz	x4, #0x0, lsl #48
    6238:      	b	0x60cc <_stogir.conditional.validate+0xc4>
    623c:      	brk	#0
    6240:      	b	0x623c <_stogir.conditional.validate+0x234>
    6244:      	mov	x19, x8
    6248:      	b	0x6180 <_stogir.conditional.validate+0x178>
    624c:      	mov	x19, x8
    6250:      	b	0x6180 <_stogir.conditional.validate+0x178>

0000000000006254 <_stogir.floating.validate>:
    6254:      	sub	sp, sp, #0x50
    6258:      	str	x29, [sp]
    625c:      	str	x30, [sp, #0x8]
    6260:      	mov	x29, sp
    6264:      	str	x19, [sp, #0x40]
    6268:      	sxtw	x1, w1
    626c:      	lsl	x2, x1, #2
    6270:      	cmp	x1, #0x0
    6274:      	cset	w3, gt
    6278:      	movz	x16, #0x0, lsl #48
    627c:      	sub	x4, x16, x1
    6280:      	sub	x5, x4, #0x1
    6284:      	uxtb	w16, w3
    6288:      	cmp	w16, wzr
    628c:      	b.eq	0x62cc <_stogir.floating.validate+0x78>
    6290:      	ldr	x4, [x0, #0x8]
    6294:      	cmp	x1, x4
    6298:      	b.ge	0x631c <_stogir.floating.validate+0xc8>
    629c:      	add	x4, x0, #0x78
    62a0:      	ldr	x4, [x4, #0x8]
    62a4:      	cmp	x1, x4
    62a8:      	b.ge	0x6410 <_stogir.floating.validate+0x1bc>
    62ac:      	ldr	x4, [x0, #0x78]
    62b0:      	add	x4, x2, x4
    62b4:      	ldr	w4, [x4]
    62b8:      	sxtw	x4, w4
    62bc:      	cmp	x4, #0x0
    62c0:      	cset	w4, ge
    62c4:      	ubfx	x4, x4, #0, #8
    62c8:      	b	0x6414 <_stogir.floating.validate+0x1c0>
    62cc:      	cmp	x1, #0x0
    62d0:      	b.ge	0x6324 <_stogir.floating.validate+0xd0>
    62d4:      	add	x6, x0, #0x28
    62d8:      	add	x7, x0, #0x50
    62dc:      	ldr	x6, [x6, #0x8]
    62e0:      	ldr	x7, [x7, #0x8]
    62e4:      	cmp	x6, x7
    62e8:      	b.ne	0x6314 <_stogir.floating.validate+0xc0>
    62ec:      	cmp	x4, x6
    62f0:      	b.gt	0x649c <_stogir.floating.validate+0x248>
    62f4:      	ldr	x4, [x0, #0x50]
    62f8:      	add	x4, x4, x5, lsl #2
    62fc:      	ldr	w4, [x4]
    6300:      	sxtw	x4, w4
    6304:      	cmp	x4, #0x0
    6308:      	cset	w4, gt
    630c:      	ubfx	x4, x4, #0, #8
    6310:      	b	0x64a0 <_stogir.floating.validate+0x24c>
    6314:      	movz	x4, #0x0, lsl #48
    6318:      	b	0x6328 <_stogir.floating.validate+0xd4>
    631c:      	movz	x4, #0x0, lsl #48
    6320:      	b	0x6328 <_stogir.floating.validate+0xd4>
    6324:      	movz	x4, #0x0, lsl #48
    6328:      	cmp	x4, #0x0
    632c:      	b.eq	0x6368 <_stogir.floating.validate+0x114>
    6330:      	uxtb	w16, w3
    6334:      	cmp	w16, wzr
    6338:      	b.eq	0x6350 <_stogir.floating.validate+0xfc>
    633c:      	ldr	x3, [x0]
    6340:      	add	x3, x3, x1, lsl #4
    6344:      	ldr	x4, [x3]
    6348:      	ldr	x3, [x3, #0x8]
    634c:      	b	0x6360 <_stogir.floating.validate+0x10c>
    6350:      	ldr	x3, [x0, #0x28]
    6354:      	add	x3, x3, x5, lsl #4
    6358:      	ldr	x4, [x3]
    635c:      	ldr	x3, [x3, #0x8]
    6360:      	mov	w5, #0x1                ; =1
    6364:      	b	0x6374 <_stogir.floating.validate+0x120>
    6368:      	movz	w5, #0x0, lsl #16
    636c:      	movz	x4, #0x0, lsl #48
    6370:      	movz	x3, #0x0, lsl #48
    6374:      	ubfx	x5, x5, #0, #32
    6378:      	lsr	x16, x5, #0
    637c:      	cmp	x16, #0x1
    6380:      	b.eq	0x639c <_stogir.floating.validate+0x148>
    6384:      	b.lo	0x638c <_stogir.floating.validate+0x138>
    6388:      	b	0x63a0 <_stogir.floating.validate+0x14c>
    638c:      	cmp	x16, #0x0
    6390:      	b.eq	0x6398 <_stogir.floating.validate+0x144>
    6394:      	b	0x63a0 <_stogir.floating.validate+0x14c>
    6398:      	b	0x63a4 <_stogir.floating.validate+0x150>
    639c:      	b	0x63dc <_stogir.floating.validate+0x188>
    63a0:      	b	0x6718 <_stogir.floating.validate+0x4c4>
    63a4:      	adrp	x16, 0x6000 <_stogir.conversion.validate+0x3dc>
		00000000000063a4:  ARM64_RELOC_PAGE21	l_stogir.409
    63a8:      	ldr	x16, [x16]
		00000000000063a8:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    63ac:      	orr	x0, x16, xzr
    63b0:      	mov	x19, x8
    63b4:      	mov	x1, #0x1                ; =1
    63b8:      	mov	x2, #0x1c               ; =28
    63bc:      	str	x1, [x19]
    63c0:      	str	x0, [x19, #0x8]
    63c4:      	str	x2, [x19, #0x10]
    63c8:      	ldr	x19, [sp, #0x40]
    63cc:      	ldr	x29, [sp]
    63d0:      	ldr	x30, [sp, #0x8]
    63d4:      	add	sp, sp, #0x50
    63d8:      	ret
    63dc:      	add	x16, sp, #0x10
    63e0:      	str	x4, [x16]
    63e4:      	add	x16, sp, #0x10
    63e8:      	str	x3, [x16, #0x8]
    63ec:      	cmp	x1, #0x0
    63f0:      	b.gt	0x6418 <_stogir.floating.validate+0x1c4>
    63f4:      	mov	x19, x8
    63f8:      	adrp	x16, 0x6000 <_stogir.conversion.validate+0x3dc>
		00000000000063f8:  ARM64_RELOC_PAGE21	l_stogir.410
    63fc:      	ldr	x16, [x16]
		00000000000063fc:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    6400:      	orr	x0, x16, xzr
    6404:      	mov	x1, #0x1                ; =1
    6408:      	mov	x2, #0x1c               ; =28
    640c:      	b	0x63bc <_stogir.floating.validate+0x168>
    6410:      	movz	x4, #0x0, lsl #48
    6414:      	b	0x6320 <_stogir.floating.validate+0xcc>
    6418:      	uxtb	w4, w4
    641c:      	orr	x1, x4, xzr
    6420:      	cmp	x1, #0xe
    6424:      	cset	w3, ge
    6428:      	cmp	x1, #0x19
    642c:      	cset	w5, le
    6430:      	cmp	x1, #0x1f
    6434:      	cset	w6, eq
    6438:      	cmp	x1, #0x20
    643c:      	cset	w7, eq
    6440:      	uxtb	w16, w3
    6444:      	cmp	w16, wzr
    6448:      	b.eq	0x64a4 <_stogir.floating.validate+0x250>
    644c:      	uxtb	w16, w5
    6450:      	cmp	w16, wzr
    6454:      	b.eq	0x64a4 <_stogir.floating.validate+0x250>
    6458:      	cmp	x1, #0x1d
    645c:      	cset	w1, eq
    6460:      	ldr	x9, [x0, #0x78]
    6464:      	add	x2, x2, x9
    6468:      	ldr	w2, [x2]
    646c:      	uxtb	w16, w6
    6470:      	cmp	w16, wzr
    6474:      	b.ne	0x64e4 <_stogir.floating.validate+0x290>
    6478:      	uxtb	w16, w7
    647c:      	cmp	w16, wzr
    6480:      	b.ne	0x64e4 <_stogir.floating.validate+0x290>
    6484:      	uxtb	w16, w1
    6488:      	cmp	w16, wzr
    648c:      	mov	w16, #0x3               ; =3
    6490:      	mov	w17, #0x2               ; =2
    6494:      	csel	w6, w16, w17, ne
    6498:      	b	0x64e8 <_stogir.floating.validate+0x294>
    649c:      	movz	x4, #0x0, lsl #48
    64a0:      	b	0x6318 <_stogir.floating.validate+0xc4>
    64a4:      	uxtb	w16, w6
    64a8:      	cmp	w16, wzr
    64ac:      	b.ne	0x6458 <_stogir.floating.validate+0x204>
    64b0:      	uxtb	w16, w7
    64b4:      	cmp	w16, wzr
    64b8:      	b.ne	0x6458 <_stogir.floating.validate+0x204>
    64bc:      	cmp	x1, #0x1a
    64c0:      	b.lt	0x64cc <_stogir.floating.validate+0x278>
    64c4:      	cmp	x1, #0x1d
    64c8:      	b.le	0x6458 <_stogir.floating.validate+0x204>
    64cc:      	cmp	x1, #0x3a
    64d0:      	b.eq	0x6458 <_stogir.floating.validate+0x204>
    64d4:      	cmp	x1, #0x3b
    64d8:      	b.eq	0x6458 <_stogir.floating.validate+0x204>
    64dc:      	mov	x19, x8
    64e0:      	b	0x63f8 <_stogir.floating.validate+0x1a4>
    64e4:      	mov	w6, #0x1                ; =1
    64e8:      	sxtw	x2, w2
    64ec:      	sxtw	x6, w6
    64f0:      	cmp	x2, x6
    64f4:      	b.ne	0x6728 <_stogir.floating.validate+0x4d4>
    64f8:      	add	x16, sp, #0x10
    64fc:      	ldr	w2, [x16, #0x4]
    6500:      	sxtw	x2, w2
    6504:      	cmp	x2, #0x0
    6508:      	cset	w6, gt
    650c:      	movz	x16, #0x0, lsl #48
    6510:      	sub	x7, x16, x2
    6514:      	sub	x9, x7, #0x1
    6518:      	uxtb	w16, w6
    651c:      	cmp	w16, wzr
    6520:      	b.eq	0x6578 <_stogir.floating.validate+0x324>
    6524:      	ldr	x7, [x0, #0x8]
    6528:      	cmp	x2, x7
    652c:      	b.ge	0x65c0 <_stogir.floating.validate+0x36c>
    6530:      	add	x7, x0, #0x78
    6534:      	ldr	x7, [x7, #0x8]
    6538:      	cmp	x2, x7
    653c:      	b.ge	0x6690 <_stogir.floating.validate+0x43c>
    6540:      	ldr	x7, [x0, #0x78]
    6544:      	add	x7, x7, x2, lsl #2
    6548:      	ldr	w7, [x7]
    654c:      	sxtw	x7, w7
    6550:      	cmp	x7, #0x0
    6554:      	cset	w7, ge
    6558:      	ubfx	x7, x7, #0, #8
    655c:      	b	0x6694 <_stogir.floating.validate+0x440>
    6560:      	adrp	x16, 0x6000 <_stogir.conversion.validate+0x3dc>
		0000000000006560:  ARM64_RELOC_PAGE21	l_stogir.411
    6564:      	ldr	x16, [x16]
		0000000000006564:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    6568:      	orr	x0, x16, xzr
    656c:      	mov	x1, #0x1                ; =1
    6570:      	mov	x2, #0x1d               ; =29
    6574:      	b	0x640c <_stogir.floating.validate+0x1b8>
    6578:      	cmp	x2, #0x0
    657c:      	b.ge	0x65c8 <_stogir.floating.validate+0x374>
    6580:      	add	x10, x0, #0x28
    6584:      	add	x11, x0, #0x50
    6588:      	ldr	x10, [x10, #0x8]
    658c:      	ldr	x11, [x11, #0x8]
    6590:      	cmp	x10, x11
    6594:      	b.ne	0x6688 <_stogir.floating.validate+0x434>
    6598:      	cmp	x7, x10
    659c:      	b.gt	0x6710 <_stogir.floating.validate+0x4bc>
    65a0:      	ldr	x7, [x0, #0x50]
    65a4:      	add	x7, x7, x9, lsl #2
    65a8:      	ldr	w7, [x7]
    65ac:      	sxtw	x7, w7
    65b0:      	cmp	x7, #0x0
    65b4:      	cset	w7, gt
    65b8:      	ubfx	x7, x7, #0, #8
    65bc:      	b	0x6714 <_stogir.floating.validate+0x4c0>
    65c0:      	movz	x7, #0x0, lsl #48
    65c4:      	b	0x65cc <_stogir.floating.validate+0x378>
    65c8:      	movz	x7, #0x0, lsl #48
    65cc:      	cmp	x7, #0x0
    65d0:      	b.eq	0x6604 <_stogir.floating.validate+0x3b0>
    65d4:      	uxtb	w16, w6
    65d8:      	cmp	w16, wzr
    65dc:      	b.eq	0x65f0 <_stogir.floating.validate+0x39c>
    65e0:      	ldr	x6, [x0]
    65e4:      	add	x2, x6, x2, lsl #4
    65e8:      	ldr	x2, [x2]
    65ec:      	b	0x65fc <_stogir.floating.validate+0x3a8>
    65f0:      	ldr	x2, [x0, #0x28]
    65f4:      	add	x2, x2, x9, lsl #4
    65f8:      	ldr	x2, [x2]
    65fc:      	mov	w6, #0x1                ; =1
    6600:      	b	0x660c <_stogir.floating.validate+0x3b8>
    6604:      	movz	w6, #0x0, lsl #16
    6608:      	movz	x2, #0x0, lsl #48
    660c:      	ubfx	x6, x6, #0, #32
    6610:      	lsr	x16, x6, #0
    6614:      	cmp	x16, #0x1
    6618:      	b.eq	0x6634 <_stogir.floating.validate+0x3e0>
    661c:      	b.lo	0x6624 <_stogir.floating.validate+0x3d0>
    6620:      	b	0x6638 <_stogir.floating.validate+0x3e4>
    6624:      	cmp	x16, #0x0
    6628:      	b.eq	0x6630 <_stogir.floating.validate+0x3dc>
    662c:      	b	0x6638 <_stogir.floating.validate+0x3e4>
    6630:      	b	0x663c <_stogir.floating.validate+0x3e8>
    6634:      	b	0x6658 <_stogir.floating.validate+0x404>
    6638:      	b	0x6720 <_stogir.floating.validate+0x4cc>
    663c:      	adrp	x16, 0x6000 <_stogir.conversion.validate+0x3dc>
		000000000000663c:  ARM64_RELOC_PAGE21	l_stogir.412
    6640:      	ldr	x16, [x16]
		0000000000006640:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    6644:      	orr	x0, x16, xzr
    6648:      	mov	x19, x8
    664c:      	mov	x1, #0x1                ; =1
    6650:      	mov	x2, #0x18               ; =24
    6654:      	b	0x6574 <_stogir.floating.validate+0x320>
    6658:      	add	x16, sp, #0x10
    665c:      	ldr	w6, [x16]
    6660:      	ubfx	x2, x2, #0, #32
    6664:      	ubfx	x2, x2, #8, #8
    6668:      	uxtb	w16, w3
    666c:      	cmp	w16, wzr
    6670:      	b.eq	0x66d4 <_stogir.floating.validate+0x480>
    6674:      	uxtb	w16, w5
    6678:      	cmp	w16, wzr
    667c:      	b.eq	0x66d4 <_stogir.floating.validate+0x480>
    6680:      	mov	w3, #0x1                ; =1
    6684:      	b	0x66d8 <_stogir.floating.validate+0x484>
    6688:      	movz	x7, #0x0, lsl #48
    668c:      	b	0x65cc <_stogir.floating.validate+0x378>
    6690:      	movz	x7, #0x0, lsl #48
    6694:      	b	0x65c4 <_stogir.floating.validate+0x370>
    6698:      	movz	w1, #0x0, lsl #16
    669c:      	mov	x19, x8
    66a0:      	add	x8, sp, #0x20
    66a4:      	fmov	s31, w1
    66a8:      	mov	w1, w4
    66ac:      	mov	w4, w5
    66b0:      	fmov	w5, s31
    66b4:      	bl	0x66b4 <_stogir.floating.validate+0x460>
		00000000000066b4:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    66b8:      	add	x16, sp, #0x20
    66bc:      	ldr	x1, [x16]
    66c0:      	add	x16, sp, #0x20
    66c4:      	ldr	x0, [x16, #0x8]
    66c8:      	add	x16, sp, #0x20
    66cc:      	ldr	x2, [x16, #0x10]
    66d0:      	b	0x6574 <_stogir.floating.validate+0x320>
    66d4:      	orr	x3, x2, xzr
    66d8:      	sxtw	x3, w3
    66dc:      	ubfx	x5, x6, #8, #8
    66e0:      	cmp	x5, x3
    66e4:      	b.ne	0x6730 <_stogir.floating.validate+0x4dc>
    66e8:      	add	x16, sp, #0x10
    66ec:      	ldr	w3, [x16, #0x4]
    66f0:      	add	x16, sp, #0x10
    66f4:      	ldr	w5, [x16, #0x8]
    66f8:      	uxtb	w16, w1
    66fc:      	cmp	w16, wzr
    6700:      	b.eq	0x6698 <_stogir.floating.validate+0x444>
    6704:      	add	x16, sp, #0x10
    6708:      	ldr	w1, [x16, #0xc]
    670c:      	b	0x669c <_stogir.floating.validate+0x448>
    6710:      	movz	x7, #0x0, lsl #48
    6714:      	b	0x668c <_stogir.floating.validate+0x438>
    6718:      	brk	#0
    671c:      	b	0x6718 <_stogir.floating.validate+0x4c4>
    6720:      	brk	#0
    6724:      	b	0x6720 <_stogir.floating.validate+0x4cc>
    6728:      	mov	x19, x8
    672c:      	b	0x63f8 <_stogir.floating.validate+0x1a4>
    6730:      	mov	x19, x8
    6734:      	b	0x6560 <_stogir.floating.validate+0x30c>

0000000000006738 <_stogir.types.integer?>:
    6738:      	sxtw	x0, w0
    673c:      	cmp	x0, #0x1
    6740:      	b.lt	0x6754 <_stogir.types.integer?+0x1c>
    6744:      	cmp	x0, #0xb
    6748:      	cset	w0, le
    674c:      	ubfx	x0, x0, #0, #8
    6750:      	b	0x6758 <_stogir.types.integer?+0x20>
    6754:      	movz	x0, #0x0, lsl #48
    6758:      	ret

000000000000675c <_stogir.integer-unary.valid-type?>:
    675c:      	sxtw	x0, w0
    6760:      	cmp	x0, #0x2d
    6764:      	cset	w2, eq
    6768:      	cmp	x0, #0x1f
    676c:      	cset	w3, eq
    6770:      	cmp	x0, #0x20
    6774:      	cset	w4, eq
    6778:      	cmp	x0, #0x36
    677c:      	cset	w5, eq
    6780:      	uxtb	w16, w3
    6784:      	cmp	w16, wzr
    6788:      	b.ne	0x67d0 <_stogir.integer-unary.valid-type?+0x74>
    678c:      	uxtb	w16, w4
    6790:      	cmp	w16, wzr
    6794:      	b.ne	0x67d0 <_stogir.integer-unary.valid-type?+0x74>
    6798:      	uxtb	w16, w2
    679c:      	cmp	w16, wzr
    67a0:      	b.ne	0x67d0 <_stogir.integer-unary.valid-type?+0x74>
    67a4:      	uxtb	w16, w5
    67a8:      	cmp	w16, wzr
    67ac:      	b.ne	0x67d0 <_stogir.integer-unary.valid-type?+0x74>
    67b0:      	cmp	x0, #0x37
    67b4:      	b.eq	0x67d0 <_stogir.integer-unary.valid-type?+0x74>
    67b8:      	cmp	x0, #0x38
    67bc:      	b.eq	0x67d0 <_stogir.integer-unary.valid-type?+0x74>
    67c0:      	cmp	x0, #0x39
    67c4:      	b.eq	0x67d0 <_stogir.integer-unary.valid-type?+0x74>
    67c8:      	movz	x0, #0x0, lsl #48
    67cc:      	b	0x6808 <_stogir.integer-unary.valid-type?+0xac>
    67d0:      	sxtw	x1, w1
    67d4:      	cmp	x1, #0x1
    67d8:      	b.lt	0x6804 <_stogir.integer-unary.valid-type?+0xa8>
    67dc:      	cmp	x1, #0xb
    67e0:      	cset	w0, le
    67e4:      	uxtb	w16, w0
    67e8:      	cmp	w16, wzr
    67ec:      	b.eq	0x6804 <_stogir.integer-unary.valid-type?+0xa8>
    67f0:      	uxtb	w16, w2
    67f4:      	cmp	w16, wzr
    67f8:      	b.eq	0x6814 <_stogir.integer-unary.valid-type?+0xb8>
    67fc:      	mov	x0, #0x1                ; =1
    6800:      	b	0x6810 <_stogir.integer-unary.valid-type?+0xb4>
    6804:      	movz	x0, #0x0, lsl #48
    6808:      	ret
    680c:      	mov	x0, #0x1                ; =1
    6810:      	b	0x6808 <_stogir.integer-unary.valid-type?+0xac>
    6814:      	cmp	x1, #0x1
    6818:      	b.ne	0x6824 <_stogir.integer-unary.valid-type?+0xc8>
    681c:      	movz	x0, #0x0, lsl #48
    6820:      	b	0x6810 <_stogir.integer-unary.valid-type?+0xb4>
    6824:      	cmp	x1, #0x6
    6828:      	cset	w2, eq
    682c:      	uxtb	w16, w3
    6830:      	cmp	w16, wzr
    6834:      	b.eq	0x6848 <_stogir.integer-unary.valid-type?+0xec>
    6838:      	uxtb	w16, w2
    683c:      	cmp	w16, wzr
    6840:      	cset	x0, eq
    6844:      	b	0x6810 <_stogir.integer-unary.valid-type?+0xb4>
    6848:      	uxtb	w16, w4
    684c:      	cmp	w16, wzr
    6850:      	b.eq	0x686c <_stogir.integer-unary.valid-type?+0x110>
    6854:      	cmp	x1, #0x7
    6858:      	b.lt	0x6864 <_stogir.integer-unary.valid-type?+0x108>
    685c:      	ubfx	x0, x0, #0, #8
    6860:      	b	0x6868 <_stogir.integer-unary.valid-type?+0x10c>
    6864:      	movz	x0, #0x0, lsl #48
    6868:      	b	0x6810 <_stogir.integer-unary.valid-type?+0xb4>
    686c:      	uxtb	w16, w5
    6870:      	cmp	w16, wzr
    6874:      	b.eq	0x680c <_stogir.integer-unary.valid-type?+0xb0>
    6878:      	cmp	x1, #0x3
    687c:      	b.ne	0x6898 <_stogir.integer-unary.valid-type?+0x13c>
    6880:      	mov	x0, #0x1                ; =1
    6884:      	b	0x6894 <_stogir.integer-unary.valid-type?+0x138>
    6888:      	cmp	x1, #0xb
    688c:      	cset	w0, eq
    6890:      	ubfx	x0, x0, #0, #8
    6894:      	b	0x6810 <_stogir.integer-unary.valid-type?+0xb4>
    6898:      	cmp	x1, #0x4
    689c:      	b.ne	0x68a8 <_stogir.integer-unary.valid-type?+0x14c>
    68a0:      	mov	x0, #0x1                ; =1
    68a4:      	b	0x6894 <_stogir.integer-unary.valid-type?+0x138>
    68a8:      	cmp	x1, #0x5
    68ac:      	b.ne	0x68b8 <_stogir.integer-unary.valid-type?+0x15c>
    68b0:      	mov	x0, #0x1                ; =1
    68b4:      	b	0x6894 <_stogir.integer-unary.valid-type?+0x138>
    68b8:      	uxtb	w16, w2
    68bc:      	cmp	w16, wzr
    68c0:      	b.eq	0x68cc <_stogir.integer-unary.valid-type?+0x170>
    68c4:      	mov	x0, #0x1                ; =1
    68c8:      	b	0x6894 <_stogir.integer-unary.valid-type?+0x138>
    68cc:      	cmp	x1, #0x9
    68d0:      	b.ne	0x68dc <_stogir.integer-unary.valid-type?+0x180>
    68d4:      	mov	x0, #0x1                ; =1
    68d8:      	b	0x6894 <_stogir.integer-unary.valid-type?+0x138>
    68dc:      	cmp	x1, #0xa
    68e0:      	b.ne	0x6888 <_stogir.integer-unary.valid-type?+0x12c>
    68e4:      	mov	x0, #0x1                ; =1
    68e8:      	b	0x6894 <_stogir.integer-unary.valid-type?+0x138>

00000000000068ec <_stogir.types.valid-scalar?>:
    68ec:      	sxtw	x0, w0
    68f0:      	cmp	x0, #0x0
    68f4:      	b.lt	0x6908 <_stogir.types.valid-scalar?+0x1c>
    68f8:      	cmp	x0, #0xd
    68fc:      	cset	w0, le
    6900:      	ubfx	x0, x0, #0, #8
    6904:      	b	0x690c <_stogir.types.valid-scalar?+0x20>
    6908:      	movz	x0, #0x0, lsl #48
    690c:      	ret

0000000000006910 <_stogir.types.vector?>:
    6910:      	sxtw	x1, w0
    6914:      	cmp	x1, #0xf
    6918:      	b.le	0x6944 <_stogir.types.vector?+0x34>
    691c:      	cmp	x1, #0x80
    6920:      	b.ge	0x6954 <_stogir.types.vector?+0x44>
    6924:      	and	w0, w0, #0xf
    6928:      	ubfx	x0, x0, #0, #32
    692c:      	cmp	x0, #0x1
    6930:      	b.lt	0x694c <_stogir.types.vector?+0x3c>
    6934:      	cmp	x0, #0xd
    6938:      	cset	w0, le
    693c:      	ubfx	x0, x0, #0, #8
    6940:      	b	0x6950 <_stogir.types.vector?+0x40>
    6944:      	movz	x0, #0x0, lsl #48
    6948:      	b	0x6950 <_stogir.types.vector?+0x40>
    694c:      	movz	x0, #0x0, lsl #48
    6950:      	ret
    6954:      	movz	x0, #0x0, lsl #48
    6958:      	b	0x6950 <_stogir.types.vector?+0x40>

000000000000695c <_stogir.floating.operation?>:
    695c:      	sxtw	x0, w0
    6960:      	cmp	x0, #0xe
    6964:      	b.lt	0x6978 <_stogir.floating.operation?+0x1c>
    6968:      	cmp	x0, #0x19
    696c:      	b.gt	0x6978 <_stogir.floating.operation?+0x1c>
    6970:      	mov	x0, #0x1                ; =1
    6974:      	b	0x69a4 <_stogir.floating.operation?+0x48>
    6978:      	cmp	x0, #0x1f
    697c:      	b.eq	0x69a0 <_stogir.floating.operation?+0x44>
    6980:      	cmp	x0, #0x20
    6984:      	b.eq	0x69a0 <_stogir.floating.operation?+0x44>
    6988:      	cmp	x0, #0x1a
    698c:      	b.lt	0x69b8 <_stogir.floating.operation?+0x5c>
    6990:      	cmp	x0, #0x1d
    6994:      	b.gt	0x69b8 <_stogir.floating.operation?+0x5c>
    6998:      	mov	x0, #0x1                ; =1
    699c:      	b	0x69b4 <_stogir.floating.operation?+0x58>
    69a0:      	mov	x0, #0x1                ; =1
    69a4:      	ret
    69a8:      	cmp	x0, #0x3b
    69ac:      	cset	w0, eq
    69b0:      	ubfx	x0, x0, #0, #8
    69b4:      	b	0x69a4 <_stogir.floating.operation?+0x48>
    69b8:      	cmp	x0, #0x3a
    69bc:      	b.ne	0x69a8 <_stogir.floating.operation?+0x4c>
    69c0:      	mov	x0, #0x1                ; =1
    69c4:      	b	0x69b4 <_stogir.floating.operation?+0x58>

00000000000069c8 <_stogir.types.floating?>:
    69c8:      	sxtw	x0, w0
    69cc:      	cmp	x0, #0xc
    69d0:      	b.ne	0x69dc <_stogir.types.floating?+0x14>
    69d4:      	mov	x0, #0x1                ; =1
    69d8:      	b	0x69e8 <_stogir.types.floating?+0x20>
    69dc:      	cmp	x0, #0xd
    69e0:      	cset	w0, eq
    69e4:      	ubfx	x0, x0, #0, #8
    69e8:      	ret

00000000000069ec <_stogir.vector-lanes.operation?>:
    69ec:      	sxtw	x0, w0
    69f0:      	cmp	x0, #0x3d
    69f4:      	b.lt	0x6a08 <_stogir.vector-lanes.operation?+0x1c>
    69f8:      	cmp	x0, #0x3f
    69fc:      	cset	w0, le
    6a00:      	ubfx	x0, x0, #0, #8
    6a04:      	b	0x6a0c <_stogir.vector-lanes.operation?+0x20>
    6a08:      	movz	x0, #0x0, lsl #48
    6a0c:      	ret

0000000000006a10 <_stogir.vector-lanes.validate>:
    6a10:      	sub	sp, sp, #0x50
    6a14:      	str	x29, [sp]
    6a18:      	str	x30, [sp, #0x8]
    6a1c:      	mov	x29, sp
    6a20:      	str	x19, [sp, #0x40]
    6a24:      	sxtw	x1, w1
    6a28:      	lsl	x3, x1, #2
    6a2c:      	cmp	x1, #0x0
    6a30:      	cset	w4, gt
    6a34:      	movz	x16, #0x0, lsl #48
    6a38:      	sub	x5, x16, x1
    6a3c:      	sub	x6, x5, #0x1
    6a40:      	uxtb	w16, w4
    6a44:      	cmp	w16, wzr
    6a48:      	b.eq	0x6a88 <_stogir.vector-lanes.validate+0x78>
    6a4c:      	ldr	x5, [x0, #0x8]
    6a50:      	cmp	x1, x5
    6a54:      	b.ge	0x6ad8 <_stogir.vector-lanes.validate+0xc8>
    6a58:      	add	x5, x0, #0x78
    6a5c:      	ldr	x5, [x5, #0x8]
    6a60:      	cmp	x1, x5
    6a64:      	b.ge	0x6bcc <_stogir.vector-lanes.validate+0x1bc>
    6a68:      	ldr	x5, [x0, #0x78]
    6a6c:      	add	x5, x3, x5
    6a70:      	ldr	w5, [x5]
    6a74:      	sxtw	x5, w5
    6a78:      	cmp	x5, #0x0
    6a7c:      	cset	w5, ge
    6a80:      	ubfx	x5, x5, #0, #8
    6a84:      	b	0x6bd0 <_stogir.vector-lanes.validate+0x1c0>
    6a88:      	cmp	x1, #0x0
    6a8c:      	b.ge	0x6ae0 <_stogir.vector-lanes.validate+0xd0>
    6a90:      	add	x7, x0, #0x28
    6a94:      	add	x9, x0, #0x50
    6a98:      	ldr	x7, [x7, #0x8]
    6a9c:      	ldr	x9, [x9, #0x8]
    6aa0:      	cmp	x7, x9
    6aa4:      	b.ne	0x6ad0 <_stogir.vector-lanes.validate+0xc0>
    6aa8:      	cmp	x5, x7
    6aac:      	b.gt	0x6c10 <_stogir.vector-lanes.validate+0x200>
    6ab0:      	ldr	x5, [x0, #0x50]
    6ab4:      	add	x5, x5, x6, lsl #2
    6ab8:      	ldr	w5, [x5]
    6abc:      	sxtw	x5, w5
    6ac0:      	cmp	x5, #0x0
    6ac4:      	cset	w5, gt
    6ac8:      	ubfx	x5, x5, #0, #8
    6acc:      	b	0x6c14 <_stogir.vector-lanes.validate+0x204>
    6ad0:      	movz	x5, #0x0, lsl #48
    6ad4:      	b	0x6ae4 <_stogir.vector-lanes.validate+0xd4>
    6ad8:      	movz	x5, #0x0, lsl #48
    6adc:      	b	0x6ae4 <_stogir.vector-lanes.validate+0xd4>
    6ae0:      	movz	x5, #0x0, lsl #48
    6ae4:      	cmp	x5, #0x0
    6ae8:      	b.eq	0x6b24 <_stogir.vector-lanes.validate+0x114>
    6aec:      	uxtb	w16, w4
    6af0:      	cmp	w16, wzr
    6af4:      	b.eq	0x6b0c <_stogir.vector-lanes.validate+0xfc>
    6af8:      	ldr	x4, [x0]
    6afc:      	add	x4, x4, x1, lsl #4
    6b00:      	ldr	x5, [x4]
    6b04:      	ldr	x4, [x4, #0x8]
    6b08:      	b	0x6b1c <_stogir.vector-lanes.validate+0x10c>
    6b0c:      	ldr	x4, [x0, #0x28]
    6b10:      	add	x4, x4, x6, lsl #4
    6b14:      	ldr	x5, [x4]
    6b18:      	ldr	x4, [x4, #0x8]
    6b1c:      	mov	w6, #0x1                ; =1
    6b20:      	b	0x6b30 <_stogir.vector-lanes.validate+0x120>
    6b24:      	movz	w6, #0x0, lsl #16
    6b28:      	movz	x5, #0x0, lsl #48
    6b2c:      	movz	x4, #0x0, lsl #48
    6b30:      	ubfx	x6, x6, #0, #32
    6b34:      	lsr	x16, x6, #0
    6b38:      	cmp	x16, #0x1
    6b3c:      	b.eq	0x6b58 <_stogir.vector-lanes.validate+0x148>
    6b40:      	b.lo	0x6b48 <_stogir.vector-lanes.validate+0x138>
    6b44:      	b	0x6b5c <_stogir.vector-lanes.validate+0x14c>
    6b48:      	cmp	x16, #0x0
    6b4c:      	b.eq	0x6b54 <_stogir.vector-lanes.validate+0x144>
    6b50:      	b	0x6b5c <_stogir.vector-lanes.validate+0x14c>
    6b54:      	b	0x6b60 <_stogir.vector-lanes.validate+0x150>
    6b58:      	b	0x6b7c <_stogir.vector-lanes.validate+0x16c>
    6b5c:      	b	0x6cd0 <_stogir.vector-lanes.validate+0x2c0>
    6b60:      	adrp	x16, 0x6000 <_stogir.conversion.validate+0x3dc>
		0000000000006b60:  ARM64_RELOC_PAGE21	l_stogir.413
    6b64:      	ldr	x16, [x16]
		0000000000006b64:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    6b68:      	orr	x0, x16, xzr
    6b6c:      	mov	x19, x8
    6b70:      	mov	x1, #0x1                ; =1
    6b74:      	mov	x2, #0x1f               ; =31
    6b78:      	b	0x6bac <_stogir.vector-lanes.validate+0x19c>
    6b7c:      	add	x16, sp, #0x10
    6b80:      	str	x5, [x16]
    6b84:      	add	x16, sp, #0x10
    6b88:      	str	x4, [x16, #0x8]
    6b8c:      	cmp	x1, #0x0
    6b90:      	b.gt	0x6bd4 <_stogir.vector-lanes.validate+0x1c4>
    6b94:      	mov	x19, x8
    6b98:      	adrp	x16, 0x6000 <_stogir.conversion.validate+0x3dc>
		0000000000006b98:  ARM64_RELOC_PAGE21	l_stogir.414
    6b9c:      	ldr	x16, [x16]
		0000000000006b9c:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    6ba0:      	orr	x0, x16, xzr
    6ba4:      	mov	x1, #0x1                ; =1
    6ba8:      	mov	x2, #0x25               ; =37
    6bac:      	str	x1, [x19]
    6bb0:      	str	x0, [x19, #0x8]
    6bb4:      	str	x2, [x19, #0x10]
    6bb8:      	ldr	x19, [sp, #0x40]
    6bbc:      	ldr	x29, [sp]
    6bc0:      	ldr	x30, [sp, #0x8]
    6bc4:      	add	sp, sp, #0x50
    6bc8:      	ret
    6bcc:      	movz	x5, #0x0, lsl #48
    6bd0:      	b	0x6adc <_stogir.vector-lanes.validate+0xcc>
    6bd4:      	uxtb	w5, w5
    6bd8:      	orr	x1, x5, xzr
    6bdc:      	cmp	x1, #0x3d
    6be0:      	b.lt	0x6cd8 <_stogir.vector-lanes.validate+0x2c8>
    6be4:      	cmp	x1, #0x3f
    6be8:      	b.gt	0x6ce0 <_stogir.vector-lanes.validate+0x2d0>
    6bec:      	cmp	x1, #0x3e
    6bf0:      	cset	w4, eq
    6bf4:      	ldr	x6, [x0, #0x78]
    6bf8:      	add	x3, x3, x6
    6bfc:      	ldr	w3, [x3]
    6c00:      	cmp	x1, #0x3d
    6c04:      	b.ne	0x6c6c <_stogir.vector-lanes.validate+0x25c>
    6c08:      	mov	w6, #0x2                ; =2
    6c0c:      	b	0x6c80 <_stogir.vector-lanes.validate+0x270>
    6c10:      	movz	x5, #0x0, lsl #48
    6c14:      	b	0x6ad4 <_stogir.vector-lanes.validate+0xc4>
    6c18:      	movz	w4, #0x0, lsl #16
    6c1c:      	ubfx	x3, x3, #8, #8
    6c20:      	mov	x19, x8
    6c24:      	add	x8, sp, #0x20
    6c28:      	fmov	s31, w1
    6c2c:      	mov	w1, w5
    6c30:      	fmov	w5, s31
    6c34:      	fmov	s31, w2
    6c38:      	mov	w2, w3
    6c3c:      	fmov	w3, s31
    6c40:      	fmov	s31, w4
    6c44:      	mov	w4, w6
    6c48:      	fmov	w6, s31
    6c4c:      	bl	0x6c4c <_stogir.vector-lanes.validate+0x23c>
		0000000000006c4c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    6c50:      	add	x16, sp, #0x20
    6c54:      	ldr	x1, [x16]
    6c58:      	add	x16, sp, #0x20
    6c5c:      	ldr	x0, [x16, #0x8]
    6c60:      	add	x16, sp, #0x20
    6c64:      	ldr	x2, [x16, #0x10]
    6c68:      	b	0x6bac <_stogir.vector-lanes.validate+0x19c>
    6c6c:      	uxtb	w16, w4
    6c70:      	cmp	w16, wzr
    6c74:      	mov	w16, #0x3               ; =3
    6c78:      	mov	w17, #0x1               ; =1
    6c7c:      	csel	w6, w16, w17, ne
    6c80:      	sxtw	x3, w3
    6c84:      	sxtw	x6, w6
    6c88:      	cmp	x3, x6
    6c8c:      	b.ne	0x6ce8 <_stogir.vector-lanes.validate+0x2d8>
    6c90:      	add	x16, sp, #0x10
    6c94:      	ldr	w3, [x16]
    6c98:      	add	x16, sp, #0x10
    6c9c:      	ldr	w6, [x16, #0x4]
    6ca0:      	cmp	x1, #0x3f
    6ca4:      	b.ne	0x6cb0 <_stogir.vector-lanes.validate+0x2a0>
    6ca8:      	movz	w1, #0x0, lsl #16
    6cac:      	b	0x6cb8 <_stogir.vector-lanes.validate+0x2a8>
    6cb0:      	add	x16, sp, #0x10
    6cb4:      	ldr	w1, [x16, #0x8]
    6cb8:      	uxtb	w16, w4
    6cbc:      	cmp	w16, wzr
    6cc0:      	b.eq	0x6c18 <_stogir.vector-lanes.validate+0x208>
    6cc4:      	add	x16, sp, #0x10
    6cc8:      	ldr	w4, [x16, #0xc]
    6ccc:      	b	0x6c1c <_stogir.vector-lanes.validate+0x20c>
    6cd0:      	brk	#0
    6cd4:      	b	0x6cd0 <_stogir.vector-lanes.validate+0x2c0>
    6cd8:      	mov	x19, x8
    6cdc:      	b	0x6b98 <_stogir.vector-lanes.validate+0x188>
    6ce0:      	mov	x19, x8
    6ce4:      	b	0x6b98 <_stogir.vector-lanes.validate+0x188>
    6ce8:      	mov	x19, x8
    6cec:      	b	0x6b98 <_stogir.vector-lanes.validate+0x188>

0000000000006cf0 <_stogir.vector-comparison.node?>:
    6cf0:      	sxtw	x1, w1
    6cf4:      	cmp	x1, #0x0
    6cf8:      	cset	w2, gt
    6cfc:      	movz	x16, #0x0, lsl #48
    6d00:      	sub	x3, x16, x1
    6d04:      	sub	x4, x3, #0x1
    6d08:      	uxtb	w16, w2
    6d0c:      	cmp	w16, wzr
    6d10:      	b.eq	0x6d50 <_stogir.vector-comparison.node?+0x60>
    6d14:      	ldr	x3, [x0, #0x8]
    6d18:      	cmp	x1, x3
    6d1c:      	b.ge	0x6da0 <_stogir.vector-comparison.node?+0xb0>
    6d20:      	add	x3, x0, #0x78
    6d24:      	ldr	x3, [x3, #0x8]
    6d28:      	cmp	x1, x3
    6d2c:      	b.ge	0x6e7c <_stogir.vector-comparison.node?+0x18c>
    6d30:      	ldr	x3, [x0, #0x78]
    6d34:      	add	x3, x3, x1, lsl #2
    6d38:      	ldr	w3, [x3]
    6d3c:      	sxtw	x3, w3
    6d40:      	cmp	x3, #0x0
    6d44:      	cset	w3, ge
    6d48:      	ubfx	x3, x3, #0, #8
    6d4c:      	b	0x6e80 <_stogir.vector-comparison.node?+0x190>
    6d50:      	cmp	x1, #0x0
    6d54:      	b.ge	0x6da8 <_stogir.vector-comparison.node?+0xb8>
    6d58:      	add	x5, x0, #0x28
    6d5c:      	add	x6, x0, #0x50
    6d60:      	ldr	x5, [x5, #0x8]
    6d64:      	ldr	x6, [x6, #0x8]
    6d68:      	cmp	x5, x6
    6d6c:      	b.ne	0x6d98 <_stogir.vector-comparison.node?+0xa8>
    6d70:      	cmp	x3, x5
    6d74:      	b.gt	0x6e84 <_stogir.vector-comparison.node?+0x194>
    6d78:      	ldr	x3, [x0, #0x50]
    6d7c:      	add	x3, x3, x4, lsl #2
    6d80:      	ldr	w3, [x3]
    6d84:      	sxtw	x3, w3
    6d88:      	cmp	x3, #0x0
    6d8c:      	cset	w3, gt
    6d90:      	ubfx	x3, x3, #0, #8
    6d94:      	b	0x6e88 <_stogir.vector-comparison.node?+0x198>
    6d98:      	movz	x3, #0x0, lsl #48
    6d9c:      	b	0x6dac <_stogir.vector-comparison.node?+0xbc>
    6da0:      	movz	x3, #0x0, lsl #48
    6da4:      	b	0x6dac <_stogir.vector-comparison.node?+0xbc>
    6da8:      	movz	x3, #0x0, lsl #48
    6dac:      	cmp	x3, #0x0
    6db0:      	b.eq	0x6de4 <_stogir.vector-comparison.node?+0xf4>
    6db4:      	uxtb	w16, w2
    6db8:      	cmp	w16, wzr
    6dbc:      	b.eq	0x6dd0 <_stogir.vector-comparison.node?+0xe0>
    6dc0:      	ldr	x0, [x0]
    6dc4:      	add	x0, x0, x1, lsl #4
    6dc8:      	ldr	x0, [x0]
    6dcc:      	b	0x6ddc <_stogir.vector-comparison.node?+0xec>
    6dd0:      	ldr	x0, [x0, #0x28]
    6dd4:      	add	x0, x0, x4, lsl #4
    6dd8:      	ldr	x0, [x0]
    6ddc:      	mov	w1, #0x1                ; =1
    6de0:      	b	0x6dec <_stogir.vector-comparison.node?+0xfc>
    6de4:      	movz	w1, #0x0, lsl #16
    6de8:      	movz	x0, #0x0, lsl #48
    6dec:      	ubfx	x1, x1, #0, #32
    6df0:      	lsr	x16, x1, #0
    6df4:      	cmp	x16, #0x1
    6df8:      	b.eq	0x6e14 <_stogir.vector-comparison.node?+0x124>
    6dfc:      	b.lo	0x6e04 <_stogir.vector-comparison.node?+0x114>
    6e00:      	b	0x6e18 <_stogir.vector-comparison.node?+0x128>
    6e04:      	cmp	x16, #0x0
    6e08:      	b.eq	0x6e10 <_stogir.vector-comparison.node?+0x120>
    6e0c:      	b	0x6e18 <_stogir.vector-comparison.node?+0x128>
    6e10:      	b	0x6e1c <_stogir.vector-comparison.node?+0x12c>
    6e14:      	b	0x6e2c <_stogir.vector-comparison.node?+0x13c>
    6e18:      	b	0x6ea4 <_stogir.vector-comparison.node?+0x1b4>
    6e1c:      	movz	x0, #0x0, lsl #48
    6e20:      	b	0x6e28 <_stogir.vector-comparison.node?+0x138>
    6e24:      	movz	x0, #0x0, lsl #48
    6e28:      	ret
    6e2c:      	uxtb	w1, w0
    6e30:      	cmp	x1, #0xe
    6e34:      	b.lt	0x6e24 <_stogir.vector-comparison.node?+0x134>
    6e38:      	cmp	x1, #0x19
    6e3c:      	b.gt	0x6e24 <_stogir.vector-comparison.node?+0x134>
    6e40:      	ubfx	x0, x0, #0, #32
    6e44:      	ubfx	x0, x0, #8, #8
    6e48:      	orr	x1, x0, xzr
    6e4c:      	cmp	x1, #0xf
    6e50:      	b.le	0x6e8c <_stogir.vector-comparison.node?+0x19c>
    6e54:      	cmp	x1, #0x80
    6e58:      	b.ge	0x6e94 <_stogir.vector-comparison.node?+0x1a4>
    6e5c:      	and	w0, w0, #0xf
    6e60:      	ubfx	x0, x0, #0, #32
    6e64:      	cmp	x0, #0x1
    6e68:      	b.lt	0x6e9c <_stogir.vector-comparison.node?+0x1ac>
    6e6c:      	cmp	x0, #0xd
    6e70:      	cset	w0, le
    6e74:      	ubfx	x0, x0, #0, #8
    6e78:      	b	0x6ea0 <_stogir.vector-comparison.node?+0x1b0>
    6e7c:      	movz	x3, #0x0, lsl #48
    6e80:      	b	0x6da4 <_stogir.vector-comparison.node?+0xb4>
    6e84:      	movz	x3, #0x0, lsl #48
    6e88:      	b	0x6d9c <_stogir.vector-comparison.node?+0xac>
    6e8c:      	movz	x0, #0x0, lsl #48
    6e90:      	b	0x6e28 <_stogir.vector-comparison.node?+0x138>
    6e94:      	movz	x0, #0x0, lsl #48
    6e98:      	b	0x6e90 <_stogir.vector-comparison.node?+0x1a0>
    6e9c:      	movz	x0, #0x0, lsl #48
    6ea0:      	b	0x6e98 <_stogir.vector-comparison.node?+0x1a8>
    6ea4:      	brk	#0
    6ea8:      	b	0x6ea4 <_stogir.vector-comparison.node?+0x1b4>

0000000000006eac <_stogir.vector-comparison.validate>:
    6eac:      	sub	sp, sp, #0x50
    6eb0:      	str	x29, [sp]
    6eb4:      	str	x30, [sp, #0x8]
    6eb8:      	mov	x29, sp
    6ebc:      	str	x19, [sp, #0x40]
    6ec0:      	sxtw	x1, w1
    6ec4:      	lsl	x3, x1, #2
    6ec8:      	cmp	x1, #0x0
    6ecc:      	cset	w4, gt
    6ed0:      	movz	x16, #0x0, lsl #48
    6ed4:      	sub	x5, x16, x1
    6ed8:      	sub	x6, x5, #0x1
    6edc:      	uxtb	w16, w4
    6ee0:      	cmp	w16, wzr
    6ee4:      	b.eq	0x6f24 <_stogir.vector-comparison.validate+0x78>
    6ee8:      	ldr	x5, [x0, #0x8]
    6eec:      	cmp	x1, x5
    6ef0:      	b.ge	0x6f74 <_stogir.vector-comparison.validate+0xc8>
    6ef4:      	add	x5, x0, #0x78
    6ef8:      	ldr	x5, [x5, #0x8]
    6efc:      	cmp	x1, x5
    6f00:      	b.ge	0x706c <_stogir.vector-comparison.validate+0x1c0>
    6f04:      	ldr	x5, [x0, #0x78]
    6f08:      	add	x5, x3, x5
    6f0c:      	ldr	w5, [x5]
    6f10:      	sxtw	x5, w5
    6f14:      	cmp	x5, #0x0
    6f18:      	cset	w5, ge
    6f1c:      	ubfx	x5, x5, #0, #8
    6f20:      	b	0x7070 <_stogir.vector-comparison.validate+0x1c4>
    6f24:      	cmp	x1, #0x0
    6f28:      	b.ge	0x6f7c <_stogir.vector-comparison.validate+0xd0>
    6f2c:      	add	x7, x0, #0x28
    6f30:      	add	x9, x0, #0x50
    6f34:      	ldr	x7, [x7, #0x8]
    6f38:      	ldr	x9, [x9, #0x8]
    6f3c:      	cmp	x7, x9
    6f40:      	b.ne	0x6f6c <_stogir.vector-comparison.validate+0xc0>
    6f44:      	cmp	x5, x7
    6f48:      	b.gt	0x70bc <_stogir.vector-comparison.validate+0x210>
    6f4c:      	ldr	x5, [x0, #0x50]
    6f50:      	add	x5, x5, x6, lsl #2
    6f54:      	ldr	w5, [x5]
    6f58:      	sxtw	x5, w5
    6f5c:      	cmp	x5, #0x0
    6f60:      	cset	w5, gt
    6f64:      	ubfx	x5, x5, #0, #8
    6f68:      	b	0x70c0 <_stogir.vector-comparison.validate+0x214>
    6f6c:      	movz	x5, #0x0, lsl #48
    6f70:      	b	0x6f80 <_stogir.vector-comparison.validate+0xd4>
    6f74:      	movz	x5, #0x0, lsl #48
    6f78:      	b	0x6f80 <_stogir.vector-comparison.validate+0xd4>
    6f7c:      	movz	x5, #0x0, lsl #48
    6f80:      	lsl	x7, x1, #4
    6f84:      	cmp	x5, #0x0
    6f88:      	b.eq	0x6fc4 <_stogir.vector-comparison.validate+0x118>
    6f8c:      	uxtb	w16, w4
    6f90:      	cmp	w16, wzr
    6f94:      	b.eq	0x6fac <_stogir.vector-comparison.validate+0x100>
    6f98:      	ldr	x4, [x0]
    6f9c:      	add	x4, x7, x4
    6fa0:      	ldr	x5, [x4]
    6fa4:      	ldr	x4, [x4, #0x8]
    6fa8:      	b	0x6fbc <_stogir.vector-comparison.validate+0x110>
    6fac:      	ldr	x4, [x0, #0x28]
    6fb0:      	add	x4, x4, x6, lsl #4
    6fb4:      	ldr	x5, [x4]
    6fb8:      	ldr	x4, [x4, #0x8]
    6fbc:      	mov	w6, #0x1                ; =1
    6fc0:      	b	0x6fd0 <_stogir.vector-comparison.validate+0x124>
    6fc4:      	movz	w6, #0x0, lsl #16
    6fc8:      	movz	x5, #0x0, lsl #48
    6fcc:      	movz	x4, #0x0, lsl #48
    6fd0:      	ubfx	x6, x6, #0, #32
    6fd4:      	lsr	x16, x6, #0
    6fd8:      	cmp	x16, #0x1
    6fdc:      	b.eq	0x6ff8 <_stogir.vector-comparison.validate+0x14c>
    6fe0:      	b.lo	0x6fe8 <_stogir.vector-comparison.validate+0x13c>
    6fe4:      	b	0x6ffc <_stogir.vector-comparison.validate+0x150>
    6fe8:      	cmp	x16, #0x0
    6fec:      	b.eq	0x6ff4 <_stogir.vector-comparison.validate+0x148>
    6ff0:      	b	0x6ffc <_stogir.vector-comparison.validate+0x150>
    6ff4:      	b	0x7000 <_stogir.vector-comparison.validate+0x154>
    6ff8:      	b	0x7038 <_stogir.vector-comparison.validate+0x18c>
    6ffc:      	b	0x71bc <_stogir.vector-comparison.validate+0x310>
    7000:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		0000000000007000:  ARM64_RELOC_PAGE21	l_stogir.415
    7004:      	ldr	x16, [x16]
		0000000000007004:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    7008:      	orr	x0, x16, xzr
    700c:      	mov	x19, x8
    7010:      	mov	x1, #0x1                ; =1
    7014:      	mov	x2, #0x25               ; =37
    7018:      	str	x1, [x19]
    701c:      	str	x0, [x19, #0x8]
    7020:      	str	x2, [x19, #0x10]
    7024:      	ldr	x19, [sp, #0x40]
    7028:      	ldr	x29, [sp]
    702c:      	ldr	x30, [sp, #0x8]
    7030:      	add	sp, sp, #0x50
    7034:      	ret
    7038:      	add	x16, sp, #0x10
    703c:      	str	x5, [x16]
    7040:      	add	x16, sp, #0x10
    7044:      	str	x4, [x16, #0x8]
    7048:      	cmp	x1, #0x0
    704c:      	b.gt	0x7074 <_stogir.vector-comparison.validate+0x1c8>
    7050:      	mov	x19, x8
    7054:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		0000000000007054:  ARM64_RELOC_PAGE21	l_stogir.416
    7058:      	ldr	x16, [x16]
		0000000000007058:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    705c:      	orr	x0, x16, xzr
    7060:      	mov	x1, #0x1                ; =1
    7064:      	mov	x2, #0x2b               ; =43
    7068:      	b	0x7018 <_stogir.vector-comparison.validate+0x16c>
    706c:      	movz	x5, #0x0, lsl #48
    7070:      	b	0x6f78 <_stogir.vector-comparison.validate+0xcc>
    7074:      	ldr	x4, [x0, #0x8]
    7078:      	cmp	x1, x4
    707c:      	b.ge	0x70c4 <_stogir.vector-comparison.validate+0x218>
    7080:      	add	x4, x0, #0x78
    7084:      	ldr	x4, [x4, #0x8]
    7088:      	cmp	x1, x4
    708c:      	b.ge	0x70c4 <_stogir.vector-comparison.validate+0x218>
    7090:      	ldr	x1, [x0, #0x78]
    7094:      	add	x1, x3, x1
    7098:      	ldr	w1, [x1]
    709c:      	sxtw	x1, w1
    70a0:      	cmp	x1, #0x0
    70a4:      	b.lt	0x70c4 <_stogir.vector-comparison.validate+0x218>
    70a8:      	ldr	x1, [x0]
    70ac:      	add	x1, x7, x1
    70b0:      	ldr	x1, [x1]
    70b4:      	mov	w4, #0x1                ; =1
    70b8:      	b	0x70cc <_stogir.vector-comparison.validate+0x220>
    70bc:      	movz	x5, #0x0, lsl #48
    70c0:      	b	0x6f70 <_stogir.vector-comparison.validate+0xc4>
    70c4:      	movz	w4, #0x0, lsl #16
    70c8:      	movz	x1, #0x0, lsl #48
    70cc:      	ubfx	x4, x4, #0, #32
    70d0:      	lsr	x16, x4, #0
    70d4:      	cmp	x16, #0x1
    70d8:      	b.eq	0x70f4 <_stogir.vector-comparison.validate+0x248>
    70dc:      	b.lo	0x70e4 <_stogir.vector-comparison.validate+0x238>
    70e0:      	b	0x70f8 <_stogir.vector-comparison.validate+0x24c>
    70e4:      	cmp	x16, #0x0
    70e8:      	b.eq	0x70f0 <_stogir.vector-comparison.validate+0x244>
    70ec:      	b	0x70f8 <_stogir.vector-comparison.validate+0x24c>
    70f0:      	b	0x70fc <_stogir.vector-comparison.validate+0x250>
    70f4:      	b	0x7104 <_stogir.vector-comparison.validate+0x258>
    70f8:      	b	0x71c4 <_stogir.vector-comparison.validate+0x318>
    70fc:      	mov	x19, x8
    7100:      	b	0x7054 <_stogir.vector-comparison.validate+0x1a8>
    7104:      	uxtb	w4, w1
    7108:      	cmp	x4, #0xe
    710c:      	b.lt	0x71cc <_stogir.vector-comparison.validate+0x320>
    7110:      	cmp	x4, #0x19
    7114:      	b.gt	0x71d4 <_stogir.vector-comparison.validate+0x328>
    7118:      	ubfx	x1, x1, #0, #32
    711c:      	ubfx	x1, x1, #8, #8
    7120:      	orr	x4, x1, xzr
    7124:      	cmp	x4, #0xf
    7128:      	b.le	0x71dc <_stogir.vector-comparison.validate+0x330>
    712c:      	cmp	x4, #0x80
    7130:      	b.ge	0x71e4 <_stogir.vector-comparison.validate+0x338>
    7134:      	and	w1, w1, #0xf
    7138:      	ubfx	x1, x1, #0, #32
    713c:      	cmp	x1, #0x1
    7140:      	b.lt	0x71ec <_stogir.vector-comparison.validate+0x340>
    7144:      	cmp	x1, #0xd
    7148:      	b.gt	0x71f4 <_stogir.vector-comparison.validate+0x348>
    714c:      	ldr	x1, [x0, #0x78]
    7150:      	add	x1, x3, x1
    7154:      	ldr	w1, [x1]
    7158:      	sxtw	x1, w1
    715c:      	cmp	x1, #0x2
    7160:      	b.ne	0x71fc <_stogir.vector-comparison.validate+0x350>
    7164:      	add	x16, sp, #0x10
    7168:      	ldr	w1, [x16]
    716c:      	uxtb	w3, w1
    7170:      	add	x16, sp, #0x10
    7174:      	ldr	w4, [x16, #0x4]
    7178:      	ubfx	x1, x1, #8, #8
    717c:      	add	x16, sp, #0x10
    7180:      	ldr	w5, [x16, #0x8]
    7184:      	mov	x19, x8
    7188:      	add	x8, sp, #0x20
    718c:      	fmov	s31, w1
    7190:      	mov	w1, w3
    7194:      	mov	w3, w2
    7198:      	fmov	w2, s31
    719c:      	bl	0x719c <_stogir.vector-comparison.validate+0x2f0>
		000000000000719c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    71a0:      	add	x16, sp, #0x20
    71a4:      	ldr	x1, [x16]
    71a8:      	add	x16, sp, #0x20
    71ac:      	ldr	x0, [x16, #0x8]
    71b0:      	add	x16, sp, #0x20
    71b4:      	ldr	x2, [x16, #0x10]
    71b8:      	b	0x7068 <_stogir.vector-comparison.validate+0x1bc>
    71bc:      	brk	#0
    71c0:      	b	0x71bc <_stogir.vector-comparison.validate+0x310>
    71c4:      	brk	#0
    71c8:      	b	0x71c4 <_stogir.vector-comparison.validate+0x318>
    71cc:      	mov	x19, x8
    71d0:      	b	0x7054 <_stogir.vector-comparison.validate+0x1a8>
    71d4:      	mov	x19, x8
    71d8:      	b	0x7054 <_stogir.vector-comparison.validate+0x1a8>
    71dc:      	mov	x19, x8
    71e0:      	b	0x7054 <_stogir.vector-comparison.validate+0x1a8>
    71e4:      	mov	x19, x8
    71e8:      	b	0x7054 <_stogir.vector-comparison.validate+0x1a8>
    71ec:      	mov	x19, x8
    71f0:      	b	0x7054 <_stogir.vector-comparison.validate+0x1a8>
    71f4:      	mov	x19, x8
    71f8:      	b	0x7054 <_stogir.vector-comparison.validate+0x1a8>
    71fc:      	mov	x19, x8
    7200:      	b	0x7054 <_stogir.vector-comparison.validate+0x1a8>

0000000000007204 <_stogir.vector-arithmetic.node?>:
    7204:      	sxtw	x1, w1
    7208:      	cmp	x1, #0x0
    720c:      	cset	w2, gt
    7210:      	movz	x16, #0x0, lsl #48
    7214:      	sub	x3, x16, x1
    7218:      	sub	x4, x3, #0x1
    721c:      	uxtb	w16, w2
    7220:      	cmp	w16, wzr
    7224:      	b.eq	0x7264 <_stogir.vector-arithmetic.node?+0x60>
    7228:      	ldr	x3, [x0, #0x8]
    722c:      	cmp	x1, x3
    7230:      	b.ge	0x72b4 <_stogir.vector-arithmetic.node?+0xb0>
    7234:      	add	x3, x0, #0x78
    7238:      	ldr	x3, [x3, #0x8]
    723c:      	cmp	x1, x3
    7240:      	b.ge	0x73d8 <_stogir.vector-arithmetic.node?+0x1d4>
    7244:      	ldr	x3, [x0, #0x78]
    7248:      	add	x3, x3, x1, lsl #2
    724c:      	ldr	w3, [x3]
    7250:      	sxtw	x3, w3
    7254:      	cmp	x3, #0x0
    7258:      	cset	w3, ge
    725c:      	ubfx	x3, x3, #0, #8
    7260:      	b	0x73dc <_stogir.vector-arithmetic.node?+0x1d8>
    7264:      	cmp	x1, #0x0
    7268:      	b.ge	0x72bc <_stogir.vector-arithmetic.node?+0xb8>
    726c:      	add	x5, x0, #0x28
    7270:      	add	x6, x0, #0x50
    7274:      	ldr	x5, [x5, #0x8]
    7278:      	ldr	x6, [x6, #0x8]
    727c:      	cmp	x5, x6
    7280:      	b.ne	0x72ac <_stogir.vector-arithmetic.node?+0xa8>
    7284:      	cmp	x3, x5
    7288:      	b.gt	0x73e8 <_stogir.vector-arithmetic.node?+0x1e4>
    728c:      	ldr	x3, [x0, #0x50]
    7290:      	add	x3, x3, x4, lsl #2
    7294:      	ldr	w3, [x3]
    7298:      	sxtw	x3, w3
    729c:      	cmp	x3, #0x0
    72a0:      	cset	w3, gt
    72a4:      	ubfx	x3, x3, #0, #8
    72a8:      	b	0x73ec <_stogir.vector-arithmetic.node?+0x1e8>
    72ac:      	movz	x3, #0x0, lsl #48
    72b0:      	b	0x72c0 <_stogir.vector-arithmetic.node?+0xbc>
    72b4:      	movz	x3, #0x0, lsl #48
    72b8:      	b	0x72c0 <_stogir.vector-arithmetic.node?+0xbc>
    72bc:      	movz	x3, #0x0, lsl #48
    72c0:      	cmp	x3, #0x0
    72c4:      	b.eq	0x72f8 <_stogir.vector-arithmetic.node?+0xf4>
    72c8:      	uxtb	w16, w2
    72cc:      	cmp	w16, wzr
    72d0:      	b.eq	0x72e4 <_stogir.vector-arithmetic.node?+0xe0>
    72d4:      	ldr	x0, [x0]
    72d8:      	add	x0, x0, x1, lsl #4
    72dc:      	ldr	x0, [x0]
    72e0:      	b	0x72f0 <_stogir.vector-arithmetic.node?+0xec>
    72e4:      	ldr	x0, [x0, #0x28]
    72e8:      	add	x0, x0, x4, lsl #4
    72ec:      	ldr	x0, [x0]
    72f0:      	mov	w1, #0x1                ; =1
    72f4:      	b	0x7300 <_stogir.vector-arithmetic.node?+0xfc>
    72f8:      	movz	w1, #0x0, lsl #16
    72fc:      	movz	x0, #0x0, lsl #48
    7300:      	ubfx	x1, x1, #0, #32
    7304:      	lsr	x16, x1, #0
    7308:      	cmp	x16, #0x1
    730c:      	b.eq	0x7328 <_stogir.vector-arithmetic.node?+0x124>
    7310:      	b.lo	0x7318 <_stogir.vector-arithmetic.node?+0x114>
    7314:      	b	0x732c <_stogir.vector-arithmetic.node?+0x128>
    7318:      	cmp	x16, #0x0
    731c:      	b.eq	0x7324 <_stogir.vector-arithmetic.node?+0x120>
    7320:      	b	0x732c <_stogir.vector-arithmetic.node?+0x128>
    7324:      	b	0x7330 <_stogir.vector-arithmetic.node?+0x12c>
    7328:      	b	0x7340 <_stogir.vector-arithmetic.node?+0x13c>
    732c:      	b	0x73f8 <_stogir.vector-arithmetic.node?+0x1f4>
    7330:      	movz	x0, #0x0, lsl #48
    7334:      	b	0x733c <_stogir.vector-arithmetic.node?+0x138>
    7338:      	movz	x0, #0x0, lsl #48
    733c:      	ret
    7340:      	uxtb	w1, w0
    7344:      	cmp	x1, #0x1f
    7348:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    734c:      	cmp	x1, #0x20
    7350:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7354:      	cmp	x1, #0x2d
    7358:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    735c:      	cmp	x1, #0x36
    7360:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7364:      	cmp	x1, #0x37
    7368:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    736c:      	cmp	x1, #0x38
    7370:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7374:      	cmp	x1, #0x39
    7378:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    737c:      	cmp	x1, #0x3a
    7380:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7384:      	cmp	x1, #0x3b
    7388:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    738c:      	cmp	x1, #0x31
    7390:      	b.lt	0x7400 <_stogir.vector-arithmetic.node?+0x1fc>
    7394:      	cmp	x1, #0x35
    7398:      	b.gt	0x7400 <_stogir.vector-arithmetic.node?+0x1fc>
    739c:      	ubfx	x0, x0, #0, #32
    73a0:      	ubfx	x0, x0, #8, #8
    73a4:      	orr	x1, x0, xzr
    73a8:      	cmp	x1, #0xf
    73ac:      	b.le	0x7338 <_stogir.vector-arithmetic.node?+0x134>
    73b0:      	cmp	x1, #0x80
    73b4:      	b.ge	0x73e0 <_stogir.vector-arithmetic.node?+0x1dc>
    73b8:      	and	w0, w0, #0xf
    73bc:      	ubfx	x0, x0, #0, #32
    73c0:      	cmp	x0, #0x1
    73c4:      	b.lt	0x73f0 <_stogir.vector-arithmetic.node?+0x1ec>
    73c8:      	cmp	x0, #0xd
    73cc:      	cset	w0, le
    73d0:      	ubfx	x0, x0, #0, #8
    73d4:      	b	0x73f4 <_stogir.vector-arithmetic.node?+0x1f0>
    73d8:      	movz	x3, #0x0, lsl #48
    73dc:      	b	0x72b8 <_stogir.vector-arithmetic.node?+0xb4>
    73e0:      	movz	x0, #0x0, lsl #48
    73e4:      	b	0x733c <_stogir.vector-arithmetic.node?+0x138>
    73e8:      	movz	x3, #0x0, lsl #48
    73ec:      	b	0x72b0 <_stogir.vector-arithmetic.node?+0xac>
    73f0:      	movz	x0, #0x0, lsl #48
    73f4:      	b	0x73e4 <_stogir.vector-arithmetic.node?+0x1e0>
    73f8:      	brk	#0
    73fc:      	b	0x73f8 <_stogir.vector-arithmetic.node?+0x1f4>
    7400:      	cmp	x1, #0x1a
    7404:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7408:      	cmp	x1, #0x1b
    740c:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7410:      	cmp	x1, #0x1c
    7414:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7418:      	cmp	x1, #0x1d
    741c:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7420:      	cmp	x1, #0x1e
    7424:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7428:      	cmp	x1, #0x2e
    742c:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7430:      	cmp	x1, #0x2f
    7434:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7438:      	cmp	x1, #0x30
    743c:      	b.eq	0x739c <_stogir.vector-arithmetic.node?+0x198>
    7440:      	movz	x0, #0x0, lsl #48
    7444:      	b	0x733c <_stogir.vector-arithmetic.node?+0x138>

0000000000007448 <_stogir.vector-arithmetic.validate>:
    7448:      	sub	sp, sp, #0x60
    744c:      	str	x29, [sp]
    7450:      	str	x30, [sp, #0x8]
    7454:      	mov	x29, sp
    7458:      	str	x19, [sp, #0x40]
    745c:      	str	x20, [sp, #0x48]
    7460:      	str	x21, [sp, #0x50]
    7464:      	str	x22, [sp, #0x58]
    7468:      	sxtw	x2, w1
    746c:      	lsl	x19, x2, #2
    7470:      	cmp	x2, #0x0
    7474:      	cset	w3, gt
    7478:      	movz	x16, #0x0, lsl #48
    747c:      	sub	x4, x16, x2
    7480:      	sub	x5, x4, #0x1
    7484:      	uxtb	w16, w3
    7488:      	cmp	w16, wzr
    748c:      	b.eq	0x74cc <_stogir.vector-arithmetic.validate+0x84>
    7490:      	ldr	x4, [x0, #0x8]
    7494:      	cmp	x2, x4
    7498:      	b.ge	0x751c <_stogir.vector-arithmetic.validate+0xd4>
    749c:      	add	x4, x0, #0x78
    74a0:      	ldr	x4, [x4, #0x8]
    74a4:      	cmp	x2, x4
    74a8:      	b.ge	0x761c <_stogir.vector-arithmetic.validate+0x1d4>
    74ac:      	ldr	x4, [x0, #0x78]
    74b0:      	add	x4, x19, x4
    74b4:      	ldr	w4, [x4]
    74b8:      	sxtw	x4, w4
    74bc:      	cmp	x4, #0x0
    74c0:      	cset	w4, ge
    74c4:      	ubfx	x4, x4, #0, #8
    74c8:      	b	0x7620 <_stogir.vector-arithmetic.validate+0x1d8>
    74cc:      	cmp	x2, #0x0
    74d0:      	b.ge	0x7524 <_stogir.vector-arithmetic.validate+0xdc>
    74d4:      	add	x6, x0, #0x28
    74d8:      	add	x7, x0, #0x50
    74dc:      	ldr	x6, [x6, #0x8]
    74e0:      	ldr	x7, [x7, #0x8]
    74e4:      	cmp	x6, x7
    74e8:      	b.ne	0x7514 <_stogir.vector-arithmetic.validate+0xcc>
    74ec:      	cmp	x4, x6
    74f0:      	b.gt	0x76b4 <_stogir.vector-arithmetic.validate+0x26c>
    74f4:      	ldr	x4, [x0, #0x50]
    74f8:      	add	x4, x4, x5, lsl #2
    74fc:      	ldr	w4, [x4]
    7500:      	sxtw	x4, w4
    7504:      	cmp	x4, #0x0
    7508:      	cset	w4, gt
    750c:      	ubfx	x4, x4, #0, #8
    7510:      	b	0x76b8 <_stogir.vector-arithmetic.validate+0x270>
    7514:      	movz	x4, #0x0, lsl #48
    7518:      	b	0x7528 <_stogir.vector-arithmetic.validate+0xe0>
    751c:      	movz	x4, #0x0, lsl #48
    7520:      	b	0x7528 <_stogir.vector-arithmetic.validate+0xe0>
    7524:      	movz	x4, #0x0, lsl #48
    7528:      	cmp	x4, #0x0
    752c:      	b.eq	0x7568 <_stogir.vector-arithmetic.validate+0x120>
    7530:      	uxtb	w16, w3
    7534:      	cmp	w16, wzr
    7538:      	b.eq	0x7550 <_stogir.vector-arithmetic.validate+0x108>
    753c:      	ldr	x3, [x0]
    7540:      	add	x3, x3, x2, lsl #4
    7544:      	ldr	x20, [x3]
    7548:      	ldr	x3, [x3, #0x8]
    754c:      	b	0x7560 <_stogir.vector-arithmetic.validate+0x118>
    7550:      	ldr	x3, [x0, #0x28]
    7554:      	add	x3, x3, x5, lsl #4
    7558:      	ldr	x20, [x3]
    755c:      	ldr	x3, [x3, #0x8]
    7560:      	mov	w4, #0x1                ; =1
    7564:      	b	0x7574 <_stogir.vector-arithmetic.validate+0x12c>
    7568:      	movz	w4, #0x0, lsl #16
    756c:      	movz	x20, #0x0, lsl #48
    7570:      	movz	x3, #0x0, lsl #48
    7574:      	ubfx	x4, x4, #0, #32
    7578:      	lsr	x16, x4, #0
    757c:      	cmp	x16, #0x1
    7580:      	b.eq	0x759c <_stogir.vector-arithmetic.validate+0x154>
    7584:      	b.lo	0x758c <_stogir.vector-arithmetic.validate+0x144>
    7588:      	b	0x75a0 <_stogir.vector-arithmetic.validate+0x158>
    758c:      	cmp	x16, #0x0
    7590:      	b.eq	0x7598 <_stogir.vector-arithmetic.validate+0x150>
    7594:      	b	0x75a0 <_stogir.vector-arithmetic.validate+0x158>
    7598:      	b	0x75a4 <_stogir.vector-arithmetic.validate+0x15c>
    759c:      	b	0x75c0 <_stogir.vector-arithmetic.validate+0x178>
    75a0:      	b	0x774c <_stogir.vector-arithmetic.validate+0x304>
    75a4:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		00000000000075a4:  ARM64_RELOC_PAGE21	l_stogir.417
    75a8:      	ldr	x16, [x16]
		00000000000075a8:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    75ac:      	orr	x0, x16, xzr
    75b0:      	mov	x21, x8
    75b4:      	mov	x1, #0x1                ; =1
    75b8:      	mov	x2, #0x25               ; =37
    75bc:      	b	0x75f0 <_stogir.vector-arithmetic.validate+0x1a8>
    75c0:      	add	x16, sp, #0x10
    75c4:      	str	x20, [x16]
    75c8:      	add	x16, sp, #0x10
    75cc:      	str	x3, [x16, #0x8]
    75d0:      	cmp	x2, #0x0
    75d4:      	b.gt	0x7624 <_stogir.vector-arithmetic.validate+0x1dc>
    75d8:      	mov	x21, x8
    75dc:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		00000000000075dc:  ARM64_RELOC_PAGE21	l_stogir.418
    75e0:      	ldr	x16, [x16]
		00000000000075e0:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    75e4:      	orr	x0, x16, xzr
    75e8:      	mov	x1, #0x1                ; =1
    75ec:      	mov	x2, #0x2b               ; =43
    75f0:      	str	x1, [x21]
    75f4:      	str	x0, [x21, #0x8]
    75f8:      	str	x2, [x21, #0x10]
    75fc:      	ldr	x19, [sp, #0x40]
    7600:      	ldr	x20, [sp, #0x48]
    7604:      	ldr	x21, [sp, #0x50]
    7608:      	ldr	x22, [sp, #0x58]
    760c:      	ldr	x29, [sp]
    7610:      	ldr	x30, [sp, #0x8]
    7614:      	add	sp, sp, #0x60
    7618:      	ret
    761c:      	movz	x4, #0x0, lsl #48
    7620:      	b	0x7520 <_stogir.vector-arithmetic.validate+0xd8>
    7624:      	mov	x21, x8
    7628:      	mov	x22, x0
    762c:      	bl	0x762c <_stogir.vector-arithmetic.validate+0x1e4>
		000000000000762c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    7630:      	cmp	x0, #0x0
    7634:      	b.eq	0x75dc <_stogir.vector-arithmetic.validate+0x194>
    7638:      	uxtb	w20, w20
    763c:      	orr	x0, x20, xzr
    7640:      	ldr	x1, [x22, #0x78]
    7644:      	cmp	x0, #0x1d
    7648:      	cset	w2, eq
    764c:      	cmp	x0, #0x1e
    7650:      	cset	w3, eq
    7654:      	add	x1, x19, x1
    7658:      	ldr	w1, [x1]
    765c:      	cmp	x0, #0x1f
    7660:      	b.eq	0x7700 <_stogir.vector-arithmetic.validate+0x2b8>
    7664:      	cmp	x0, #0x20
    7668:      	b.eq	0x7700 <_stogir.vector-arithmetic.validate+0x2b8>
    766c:      	cmp	x0, #0x2d
    7670:      	b.eq	0x7700 <_stogir.vector-arithmetic.validate+0x2b8>
    7674:      	cmp	x0, #0x36
    7678:      	b.eq	0x7700 <_stogir.vector-arithmetic.validate+0x2b8>
    767c:      	cmp	x0, #0x37
    7680:      	b.eq	0x7700 <_stogir.vector-arithmetic.validate+0x2b8>
    7684:      	cmp	x0, #0x38
    7688:      	b.eq	0x7700 <_stogir.vector-arithmetic.validate+0x2b8>
    768c:      	cmp	x0, #0x39
    7690:      	b.eq	0x7700 <_stogir.vector-arithmetic.validate+0x2b8>
    7694:      	uxtb	w16, w2
    7698:      	cmp	w16, wzr
    769c:      	b.ne	0x7754 <_stogir.vector-arithmetic.validate+0x30c>
    76a0:      	uxtb	w16, w3
    76a4:      	cmp	w16, wzr
    76a8:      	b.ne	0x7754 <_stogir.vector-arithmetic.validate+0x30c>
    76ac:      	mov	w0, #0x2                ; =2
    76b0:      	b	0x7758 <_stogir.vector-arithmetic.validate+0x310>
    76b4:      	movz	x4, #0x0, lsl #48
    76b8:      	b	0x7518 <_stogir.vector-arithmetic.validate+0xd0>
    76bc:      	add	x16, sp, #0x10
    76c0:      	ldr	w2, [x16, #0xc]
    76c4:      	ubfx	x0, x0, #8, #8
    76c8:      	add	x8, sp, #0x20
    76cc:      	mov	w3, w1
    76d0:      	mov	w1, w20
    76d4:      	mov	w5, w2
    76d8:      	mov	w2, w0
    76dc:      	mov	x0, x22
    76e0:      	bl	0x76e0 <_stogir.vector-arithmetic.validate+0x298>
		00000000000076e0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    76e4:      	add	x16, sp, #0x20
    76e8:      	ldr	x1, [x16]
    76ec:      	add	x16, sp, #0x20
    76f0:      	ldr	x0, [x16, #0x8]
    76f4:      	add	x16, sp, #0x20
    76f8:      	ldr	x2, [x16, #0x10]
    76fc:      	b	0x75f0 <_stogir.vector-arithmetic.validate+0x1a8>
    7700:      	mov	w0, #0x1                ; =1
    7704:      	sxtw	x1, w1
    7708:      	sxtw	x0, w0
    770c:      	cmp	x1, x0
    7710:      	b.ne	0x75dc <_stogir.vector-arithmetic.validate+0x194>
    7714:      	add	x16, sp, #0x10
    7718:      	ldr	w0, [x16]
    771c:      	add	x16, sp, #0x10
    7720:      	ldr	w1, [x16, #0x4]
    7724:      	add	x16, sp, #0x10
    7728:      	ldr	w4, [x16, #0x8]
    772c:      	uxtb	w16, w2
    7730:      	cmp	w16, wzr
    7734:      	b.ne	0x76bc <_stogir.vector-arithmetic.validate+0x274>
    7738:      	uxtb	w16, w3
    773c:      	cmp	w16, wzr
    7740:      	b.ne	0x76bc <_stogir.vector-arithmetic.validate+0x274>
    7744:      	movz	w2, #0x0, lsl #16
    7748:      	b	0x76c4 <_stogir.vector-arithmetic.validate+0x27c>
    774c:      	brk	#0
    7750:      	b	0x774c <_stogir.vector-arithmetic.validate+0x304>
    7754:      	mov	w0, #0x3                ; =3
    7758:      	b	0x7704 <_stogir.vector-arithmetic.validate+0x2bc>

000000000000775c <_stogir.vector.memory-inputs>:
    775c:      	sub	sp, sp, #0x60
    7760:      	str	x29, [sp]
    7764:      	str	x30, [sp, #0x8]
    7768:      	mov	x29, sp
    776c:      	str	x19, [sp, #0x30]
    7770:      	str	x20, [sp, #0x38]
    7774:      	str	x21, [sp, #0x40]
    7778:      	str	x22, [sp, #0x48]
    777c:      	str	x23, [sp, #0x50]
    7780:      	str	x24, [sp, #0x58]
    7784:      	mov	x19, x8
    7788:      	mov	x20, x0
    778c:      	mov	w0, w1
    7790:      	mov	w21, w1
    7794:      	mov	w22, w2
    7798:      	mov	w23, w3
    779c:      	mov	w24, w4
    77a0:      	bl	0x77a0 <_stogir.vector.memory-inputs+0x44>
		00000000000077a0:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    77a4:      	cmp	x0, #0x0
    77a8:      	b.eq	0x7824 <_stogir.vector.memory-inputs+0xc8>
    77ac:      	mov	w0, w21
    77b0:      	mov	w1, w22
    77b4:      	bl	0x77b4 <_stogir.vector.memory-inputs+0x58>
		00000000000077b4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    77b8:      	sxtw	x0, w0
    77bc:      	cmp	x0, #0x0
    77c0:      	b.le	0x7824 <_stogir.vector.memory-inputs+0xc8>
    77c4:      	sxtw	x23, w23
    77c8:      	cmp	x23, #0x0
    77cc:      	cset	w0, gt
    77d0:      	movz	x16, #0x0, lsl #48
    77d4:      	sub	x1, x16, x23
    77d8:      	sub	x2, x1, #0x1
    77dc:      	uxtb	w16, w0
    77e0:      	cmp	w16, wzr
    77e4:      	b.eq	0x790c <_stogir.vector.memory-inputs+0x1b0>
    77e8:      	ldr	x1, [x20, #0x8]
    77ec:      	cmp	x23, x1
    77f0:      	b.ge	0x7904 <_stogir.vector.memory-inputs+0x1a8>
    77f4:      	add	x1, x20, #0x78
    77f8:      	ldr	x1, [x1, #0x8]
    77fc:      	cmp	x23, x1
    7800:      	b.ge	0x7a24 <_stogir.vector.memory-inputs+0x2c8>
    7804:      	ldr	x1, [x20, #0x78]
    7808:      	add	x1, x1, x23, lsl #2
    780c:      	ldr	w1, [x1]
    7810:      	sxtw	x1, w1
    7814:      	cmp	x1, #0x0
    7818:      	cset	w1, ge
    781c:      	ubfx	x1, x1, #0, #8
    7820:      	b	0x7a28 <_stogir.vector.memory-inputs+0x2cc>
    7824:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		0000000000007824:  ARM64_RELOC_PAGE21	l_stogir.419
    7828:      	ldr	x16, [x16]
		0000000000007828:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    782c:      	orr	x0, x16, xzr
    7830:      	mov	x1, #0x1                ; =1
    7834:      	mov	x2, #0x32               ; =50
    7838:      	str	x1, [x19]
    783c:      	str	x0, [x19, #0x8]
    7840:      	str	x2, [x19, #0x10]
    7844:      	ldr	x19, [sp, #0x30]
    7848:      	ldr	x20, [sp, #0x38]
    784c:      	ldr	x21, [sp, #0x40]
    7850:      	ldr	x22, [sp, #0x48]
    7854:      	ldr	x23, [sp, #0x50]
    7858:      	ldr	x24, [sp, #0x58]
    785c:      	ldr	x29, [sp]
    7860:      	ldr	x30, [sp, #0x8]
    7864:      	add	sp, sp, #0x60
    7868:      	ret
    786c:      	movz	w2, #0x0, lsl #16
    7870:      	movz	x1, #0x0, lsl #48
    7874:      	movz	x0, #0x0, lsl #48
    7878:      	ubfx	x2, x2, #0, #32
    787c:      	lsr	x16, x2, #0
    7880:      	cmp	x16, #0x1
    7884:      	b.eq	0x78a0 <_stogir.vector.memory-inputs+0x144>
    7888:      	b.lo	0x7890 <_stogir.vector.memory-inputs+0x134>
    788c:      	b	0x78a4 <_stogir.vector.memory-inputs+0x148>
    7890:      	cmp	x16, #0x0
    7894:      	b.eq	0x789c <_stogir.vector.memory-inputs+0x140>
    7898:      	b	0x78a4 <_stogir.vector.memory-inputs+0x148>
    789c:      	b	0x78a8 <_stogir.vector.memory-inputs+0x14c>
    78a0:      	b	0x7954 <_stogir.vector.memory-inputs+0x1f8>
    78a4:      	b	0x7bb8 <_stogir.vector.memory-inputs+0x45c>
    78a8:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		00000000000078a8:  ARM64_RELOC_PAGE21	l_stogir.420
    78ac:      	ldr	x16, [x16]
		00000000000078ac:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    78b0:      	orr	x0, x16, xzr
    78b4:      	mov	x1, #0x1                ; =1
    78b8:      	mov	x2, #0x1d               ; =29
    78bc:      	b	0x7838 <_stogir.vector.memory-inputs+0xdc>
    78c0:      	ldr	x0, [x20, #0x28]
    78c4:      	add	x0, x0, x2, lsl #4
    78c8:      	ldr	x1, [x0]
    78cc:      	ldr	x0, [x0, #0x8]
    78d0:      	mov	w2, #0x1                ; =1
    78d4:      	b	0x7878 <_stogir.vector.memory-inputs+0x11c>
    78d8:      	movz	x1, #0x0, lsl #48
    78dc:      	cmp	x1, #0x0
    78e0:      	b.eq	0x786c <_stogir.vector.memory-inputs+0x110>
    78e4:      	uxtb	w16, w0
    78e8:      	cmp	w16, wzr
    78ec:      	b.eq	0x78c0 <_stogir.vector.memory-inputs+0x164>
    78f0:      	ldr	x0, [x20]
    78f4:      	add	x0, x0, x23, lsl #4
    78f8:      	ldr	x1, [x0]
    78fc:      	ldr	x0, [x0, #0x8]
    7900:      	b	0x78d0 <_stogir.vector.memory-inputs+0x174>
    7904:      	movz	x1, #0x0, lsl #48
    7908:      	b	0x78dc <_stogir.vector.memory-inputs+0x180>
    790c:      	cmp	x23, #0x0
    7910:      	b.ge	0x78d8 <_stogir.vector.memory-inputs+0x17c>
    7914:      	add	x3, x20, #0x28
    7918:      	add	x4, x20, #0x50
    791c:      	ldr	x3, [x3, #0x8]
    7920:      	ldr	x4, [x4, #0x8]
    7924:      	cmp	x3, x4
    7928:      	b.ne	0x7a1c <_stogir.vector.memory-inputs+0x2c0>
    792c:      	cmp	x1, x3
    7930:      	b.gt	0x7a2c <_stogir.vector.memory-inputs+0x2d0>
    7934:      	ldr	x1, [x20, #0x50]
    7938:      	add	x1, x1, x2, lsl #2
    793c:      	ldr	w1, [x1]
    7940:      	sxtw	x1, w1
    7944:      	cmp	x1, #0x0
    7948:      	cset	w1, gt
    794c:      	ubfx	x1, x1, #0, #8
    7950:      	b	0x7a30 <_stogir.vector.memory-inputs+0x2d4>
    7954:      	add	x16, sp, #0x10
    7958:      	str	x1, [x16]
    795c:      	add	x16, sp, #0x10
    7960:      	str	x0, [x16, #0x8]
    7964:      	cmp	x23, #0x0
    7968:      	b.le	0x7a04 <_stogir.vector.memory-inputs+0x2a8>
    796c:      	add	x16, sp, #0x10
    7970:      	orr	x23, x16, xzr
    7974:      	mov	x0, x23
    7978:      	bl	0x7978 <_stogir.vector.memory-inputs+0x21c>
		0000000000007978:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    797c:      	uxtb	w0, w0
    7980:      	bl	0x7980 <_stogir.vector.memory-inputs+0x224>
		0000000000007980:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    7984:      	cmp	x0, #0x0
    7988:      	b.eq	0x7a04 <_stogir.vector.memory-inputs+0x2a8>
    798c:      	mov	x0, x23
    7990:      	bl	0x7990 <_stogir.vector.memory-inputs+0x234>
		0000000000007990:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    7994:      	uxtb	w0, w0
    7998:      	bl	0x7998 <_stogir.vector.memory-inputs+0x23c>
		0000000000007998:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    799c:      	cmp	x0, #0x0
    79a0:      	b.ne	0x7a04 <_stogir.vector.memory-inputs+0x2a8>
    79a4:      	sxtw	x24, w24
    79a8:      	cmp	x24, #0x0
    79ac:      	cset	w0, gt
    79b0:      	movz	x16, #0x0, lsl #48
    79b4:      	sub	x1, x16, x24
    79b8:      	sub	x2, x1, #0x1
    79bc:      	uxtb	w16, w0
    79c0:      	cmp	w16, wzr
    79c4:      	b.eq	0x7ad4 <_stogir.vector.memory-inputs+0x378>
    79c8:      	ldr	x1, [x20, #0x8]
    79cc:      	cmp	x24, x1
    79d0:      	b.ge	0x7acc <_stogir.vector.memory-inputs+0x370>
    79d4:      	add	x1, x20, #0x78
    79d8:      	ldr	x1, [x1, #0x8]
    79dc:      	cmp	x24, x1
    79e0:      	b.ge	0x7bb0 <_stogir.vector.memory-inputs+0x454>
    79e4:      	ldr	x1, [x20, #0x78]
    79e8:      	add	x1, x1, x24, lsl #2
    79ec:      	ldr	w1, [x1]
    79f0:      	sxtw	x1, w1
    79f4:      	cmp	x1, #0x0
    79f8:      	cset	w1, ge
    79fc:      	ubfx	x1, x1, #0, #8
    7a00:      	b	0x7bb4 <_stogir.vector.memory-inputs+0x458>
    7a04:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		0000000000007a04:  ARM64_RELOC_PAGE21	l_stogir.421
    7a08:      	ldr	x16, [x16]
		0000000000007a08:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    7a0c:      	orr	x0, x16, xzr
    7a10:      	mov	x1, #0x1                ; =1
    7a14:      	mov	x2, #0x2c               ; =44
    7a18:      	b	0x78bc <_stogir.vector.memory-inputs+0x160>
    7a1c:      	movz	x1, #0x0, lsl #48
    7a20:      	b	0x78dc <_stogir.vector.memory-inputs+0x180>
    7a24:      	movz	x1, #0x0, lsl #48
    7a28:      	b	0x7908 <_stogir.vector.memory-inputs+0x1ac>
    7a2c:      	movz	x1, #0x0, lsl #48
    7a30:      	b	0x7a20 <_stogir.vector.memory-inputs+0x2c4>
    7a34:      	movz	w2, #0x0, lsl #16
    7a38:      	movz	x1, #0x0, lsl #48
    7a3c:      	movz	x0, #0x0, lsl #48
    7a40:      	ubfx	x2, x2, #0, #32
    7a44:      	lsr	x16, x2, #0
    7a48:      	cmp	x16, #0x1
    7a4c:      	b.eq	0x7a68 <_stogir.vector.memory-inputs+0x30c>
    7a50:      	b.lo	0x7a58 <_stogir.vector.memory-inputs+0x2fc>
    7a54:      	b	0x7a6c <_stogir.vector.memory-inputs+0x310>
    7a58:      	cmp	x16, #0x0
    7a5c:      	b.eq	0x7a64 <_stogir.vector.memory-inputs+0x308>
    7a60:      	b	0x7a6c <_stogir.vector.memory-inputs+0x310>
    7a64:      	b	0x7a70 <_stogir.vector.memory-inputs+0x314>
    7a68:      	b	0x7b1c <_stogir.vector.memory-inputs+0x3c0>
    7a6c:      	b	0x7bc8 <_stogir.vector.memory-inputs+0x46c>
    7a70:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		0000000000007a70:  ARM64_RELOC_PAGE21	l_stogir.422
    7a74:      	ldr	x16, [x16]
		0000000000007a74:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    7a78:      	orr	x0, x16, xzr
    7a7c:      	mov	x1, #0x1                ; =1
    7a80:      	mov	x2, #0x1d               ; =29
    7a84:      	b	0x7a18 <_stogir.vector.memory-inputs+0x2bc>
    7a88:      	ldr	x0, [x20, #0x28]
    7a8c:      	add	x0, x0, x2, lsl #4
    7a90:      	ldr	x1, [x0]
    7a94:      	ldr	x0, [x0, #0x8]
    7a98:      	mov	w2, #0x1                ; =1
    7a9c:      	b	0x7a40 <_stogir.vector.memory-inputs+0x2e4>
    7aa0:      	movz	x1, #0x0, lsl #48
    7aa4:      	cmp	x1, #0x0
    7aa8:      	b.eq	0x7a34 <_stogir.vector.memory-inputs+0x2d8>
    7aac:      	uxtb	w16, w0
    7ab0:      	cmp	w16, wzr
    7ab4:      	b.eq	0x7a88 <_stogir.vector.memory-inputs+0x32c>
    7ab8:      	ldr	x0, [x20]
    7abc:      	add	x0, x0, x24, lsl #4
    7ac0:      	ldr	x1, [x0]
    7ac4:      	ldr	x0, [x0, #0x8]
    7ac8:      	b	0x7a98 <_stogir.vector.memory-inputs+0x33c>
    7acc:      	movz	x1, #0x0, lsl #48
    7ad0:      	b	0x7aa4 <_stogir.vector.memory-inputs+0x348>
    7ad4:      	cmp	x24, #0x0
    7ad8:      	b.ge	0x7aa0 <_stogir.vector.memory-inputs+0x344>
    7adc:      	add	x3, x20, #0x28
    7ae0:      	add	x4, x20, #0x50
    7ae4:      	ldr	x3, [x3, #0x8]
    7ae8:      	ldr	x4, [x4, #0x8]
    7aec:      	cmp	x3, x4
    7af0:      	b.ne	0x7ba8 <_stogir.vector.memory-inputs+0x44c>
    7af4:      	cmp	x1, x3
    7af8:      	b.gt	0x7bc0 <_stogir.vector.memory-inputs+0x464>
    7afc:      	ldr	x1, [x20, #0x50]
    7b00:      	add	x1, x1, x2, lsl #2
    7b04:      	ldr	w1, [x1]
    7b08:      	sxtw	x1, w1
    7b0c:      	cmp	x1, #0x0
    7b10:      	cset	w1, gt
    7b14:      	ubfx	x1, x1, #0, #8
    7b18:      	b	0x7bc4 <_stogir.vector.memory-inputs+0x468>
    7b1c:      	add	x16, sp, #0x20
    7b20:      	orr	x20, x16, xzr
    7b24:      	add	x16, sp, #0x20
    7b28:      	str	x1, [x16]
    7b2c:      	add	x16, sp, #0x20
    7b30:      	str	x0, [x16, #0x8]
    7b34:      	mov	x0, x20
    7b38:      	bl	0x7b38 <_stogir.vector.memory-inputs+0x3dc>
		0000000000007b38:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    7b3c:      	uxtb	w0, w0
    7b40:      	cmp	x0, #0x6
    7b44:      	b.ne	0x7b90 <_stogir.vector.memory-inputs+0x434>
    7b48:      	mov	x0, x20
    7b4c:      	bl	0x7b4c <_stogir.vector.memory-inputs+0x3f0>
		0000000000007b4c:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    7b50:      	uxtb	w0, w0
    7b54:      	cmp	x0, #0x48
    7b58:      	b.eq	0x7b90 <_stogir.vector.memory-inputs+0x434>
    7b5c:      	mov	x0, x20
    7b60:      	bl	0x7b60 <_stogir.vector.memory-inputs+0x404>
		0000000000007b60:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    7b64:      	uxtb	w0, w0
    7b68:      	cmp	x0, #0x46
    7b6c:      	b.eq	0x7b90 <_stogir.vector.memory-inputs+0x434>
    7b70:      	mov	w0, w21
    7b74:      	mov	w1, w22
    7b78:      	bl	0x7b78 <_stogir.vector.memory-inputs+0x41c>
		0000000000007b78:  ARM64_RELOC_BRANCH26	_stogir.types.size
    7b7c:      	sxtw	x0, w0
    7b80:      	and	x0, x0, #0xffffffff
    7b84:      	movz	x1, #0x0, lsl #48
    7b88:      	movz	x2, #0x0, lsl #48
    7b8c:      	b	0x7ba4 <_stogir.vector.memory-inputs+0x448>
    7b90:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		0000000000007b90:  ARM64_RELOC_PAGE21	l_stogir.423
    7b94:      	ldr	x16, [x16]
		0000000000007b94:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    7b98:      	orr	x0, x16, xzr
    7b9c:      	mov	x1, #0x1                ; =1
    7ba0:      	mov	x2, #0x2b               ; =43
    7ba4:      	b	0x7a84 <_stogir.vector.memory-inputs+0x328>
    7ba8:      	movz	x1, #0x0, lsl #48
    7bac:      	b	0x7aa4 <_stogir.vector.memory-inputs+0x348>
    7bb0:      	movz	x1, #0x0, lsl #48
    7bb4:      	b	0x7ad0 <_stogir.vector.memory-inputs+0x374>
    7bb8:      	brk	#0
    7bbc:      	b	0x7bb8 <_stogir.vector.memory-inputs+0x45c>
    7bc0:      	movz	x1, #0x0, lsl #48
    7bc4:      	b	0x7bac <_stogir.vector.memory-inputs+0x450>
    7bc8:      	brk	#0
    7bcc:      	b	0x7bc8 <_stogir.vector.memory-inputs+0x46c>

0000000000007bd0 <_stogir.vector.store-inputs>:
    7bd0:      	sub	sp, sp, #0x40
    7bd4:      	str	x29, [sp]
    7bd8:      	str	x30, [sp, #0x8]
    7bdc:      	mov	x29, sp
    7be0:      	str	x19, [sp, #0x30]
    7be4:      	sxtw	x4, w4
    7be8:      	cmp	x4, #0x0
    7bec:      	cset	w5, gt
    7bf0:      	movz	x16, #0x0, lsl #48
    7bf4:      	sub	x6, x16, x4
    7bf8:      	sub	x7, x6, #0x1
    7bfc:      	uxtb	w16, w5
    7c00:      	cmp	w16, wzr
    7c04:      	b.eq	0x7c44 <_stogir.vector.store-inputs+0x74>
    7c08:      	ldr	x6, [x0, #0x8]
    7c0c:      	cmp	x4, x6
    7c10:      	b.ge	0x7c94 <_stogir.vector.store-inputs+0xc4>
    7c14:      	add	x6, x0, #0x78
    7c18:      	ldr	x6, [x6, #0x8]
    7c1c:      	cmp	x4, x6
    7c20:      	b.ge	0x7d8c <_stogir.vector.store-inputs+0x1bc>
    7c24:      	ldr	x6, [x0, #0x78]
    7c28:      	add	x6, x6, x4, lsl #2
    7c2c:      	ldr	w6, [x6]
    7c30:      	sxtw	x6, w6
    7c34:      	cmp	x6, #0x0
    7c38:      	cset	w6, ge
    7c3c:      	ubfx	x6, x6, #0, #8
    7c40:      	b	0x7d90 <_stogir.vector.store-inputs+0x1c0>
    7c44:      	cmp	x4, #0x0
    7c48:      	b.ge	0x7c9c <_stogir.vector.store-inputs+0xcc>
    7c4c:      	add	x9, x0, #0x28
    7c50:      	add	x10, x0, #0x50
    7c54:      	ldr	x9, [x9, #0x8]
    7c58:      	ldr	x10, [x10, #0x8]
    7c5c:      	cmp	x9, x10
    7c60:      	b.ne	0x7c8c <_stogir.vector.store-inputs+0xbc>
    7c64:      	cmp	x6, x9
    7c68:      	b.gt	0x7d94 <_stogir.vector.store-inputs+0x1c4>
    7c6c:      	ldr	x6, [x0, #0x50]
    7c70:      	add	x6, x6, x7, lsl #2
    7c74:      	ldr	w6, [x6]
    7c78:      	sxtw	x6, w6
    7c7c:      	cmp	x6, #0x0
    7c80:      	cset	w6, gt
    7c84:      	ubfx	x6, x6, #0, #8
    7c88:      	b	0x7d98 <_stogir.vector.store-inputs+0x1c8>
    7c8c:      	movz	x6, #0x0, lsl #48
    7c90:      	b	0x7ca0 <_stogir.vector.store-inputs+0xd0>
    7c94:      	movz	x6, #0x0, lsl #48
    7c98:      	b	0x7ca0 <_stogir.vector.store-inputs+0xd0>
    7c9c:      	movz	x6, #0x0, lsl #48
    7ca0:      	cmp	x6, #0x0
    7ca4:      	b.eq	0x7cd8 <_stogir.vector.store-inputs+0x108>
    7ca8:      	uxtb	w16, w5
    7cac:      	cmp	w16, wzr
    7cb0:      	b.eq	0x7cc4 <_stogir.vector.store-inputs+0xf4>
    7cb4:      	ldr	x5, [x0]
    7cb8:      	add	x4, x5, x4, lsl #4
    7cbc:      	ldr	x4, [x4]
    7cc0:      	b	0x7cd0 <_stogir.vector.store-inputs+0x100>
    7cc4:      	ldr	x4, [x0, #0x28]
    7cc8:      	add	x4, x4, x7, lsl #4
    7ccc:      	ldr	x4, [x4]
    7cd0:      	mov	w5, #0x1                ; =1
    7cd4:      	b	0x7ce0 <_stogir.vector.store-inputs+0x110>
    7cd8:      	movz	w5, #0x0, lsl #16
    7cdc:      	movz	x4, #0x0, lsl #48
    7ce0:      	ubfx	x5, x5, #0, #32
    7ce4:      	lsr	x16, x5, #0
    7ce8:      	cmp	x16, #0x1
    7cec:      	b.eq	0x7d08 <_stogir.vector.store-inputs+0x138>
    7cf0:      	b.lo	0x7cf8 <_stogir.vector.store-inputs+0x128>
    7cf4:      	b	0x7d0c <_stogir.vector.store-inputs+0x13c>
    7cf8:      	cmp	x16, #0x0
    7cfc:      	b.eq	0x7d04 <_stogir.vector.store-inputs+0x134>
    7d00:      	b	0x7d0c <_stogir.vector.store-inputs+0x13c>
    7d04:      	b	0x7d10 <_stogir.vector.store-inputs+0x140>
    7d08:      	b	0x7d2c <_stogir.vector.store-inputs+0x15c>
    7d0c:      	b	0x7d9c <_stogir.vector.store-inputs+0x1cc>
    7d10:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x154>
		0000000000007d10:  ARM64_RELOC_PAGE21	l_stogir.424
    7d14:      	ldr	x16, [x16]
		0000000000007d14:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    7d18:      	orr	x0, x16, xzr
    7d1c:      	mov	x19, x8
    7d20:      	mov	x1, #0x1                ; =1
    7d24:      	mov	x2, #0x1a               ; =26
    7d28:      	b	0x7d6c <_stogir.vector.store-inputs+0x19c>
    7d2c:      	ubfx	x4, x4, #0, #32
    7d30:      	ubfx	x4, x4, #8, #8
    7d34:      	mov	x19, x8
    7d38:      	add	x8, sp, #0x10
    7d3c:      	fmov	s31, w1
    7d40:      	mov	w1, w4
    7d44:      	mov	w4, w3
    7d48:      	mov	w3, w2
    7d4c:      	fmov	w2, s31
    7d50:      	bl	0x7d50 <_stogir.vector.store-inputs+0x180>
		0000000000007d50:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    7d54:      	add	x16, sp, #0x10
    7d58:      	ldr	x1, [x16]
    7d5c:      	add	x16, sp, #0x10
    7d60:      	ldr	x0, [x16, #0x8]
    7d64:      	add	x16, sp, #0x10
    7d68:      	ldr	x2, [x16, #0x10]
    7d6c:      	str	x1, [x19]
    7d70:      	str	x0, [x19, #0x8]
    7d74:      	str	x2, [x19, #0x10]
    7d78:      	ldr	x19, [sp, #0x30]
    7d7c:      	ldr	x29, [sp]
    7d80:      	ldr	x30, [sp, #0x8]
    7d84:      	add	sp, sp, #0x40
    7d88:      	ret
    7d8c:      	movz	x6, #0x0, lsl #48
    7d90:      	b	0x7c98 <_stogir.vector.store-inputs+0xc8>
    7d94:      	movz	x6, #0x0, lsl #48
    7d98:      	b	0x7c90 <_stogir.vector.store-inputs+0xc0>
    7d9c:      	brk	#0
    7da0:      	b	0x7d9c <_stogir.vector.store-inputs+0x1cc>

0000000000007da4 <_stogir.types.size>:
    7da4:      	sxtw	x2, w0
    7da8:      	sxtw	x3, w1
    7dac:      	cmp	x2, #0xf
    7db0:      	cset	w4, gt
    7db4:      	cmp	x2, #0x0
    7db8:      	cset	w5, eq
    7dbc:      	cmp	x3, #0x4
    7dc0:      	cset	w6, eq
    7dc4:      	cmp	x3, #0x8
    7dc8:      	cset	w7, eq
    7dcc:      	uxtb	w16, w4
    7dd0:      	cmp	w16, wzr
    7dd4:      	b.eq	0x7e98 <_stogir.types.size+0xf4>
    7dd8:      	cmp	x2, #0x80
    7ddc:      	cset	w8, lt
    7de0:      	uxtb	w16, w8
    7de4:      	cmp	w16, wzr
    7de8:      	b.eq	0x7e98 <_stogir.types.size+0xf4>
    7dec:      	and	w0, w0, #0xf
    7df0:      	ubfx	x9, x0, #0, #32
    7df4:      	cmp	x9, #0x1
    7df8:      	cset	w10, ge
    7dfc:      	uxtb	w16, w10
    7e00:      	cmp	w16, wzr
    7e04:      	b.eq	0x7e98 <_stogir.types.size+0xf4>
    7e08:      	cmp	x9, #0xd
    7e0c:      	cset	w9, le
    7e10:      	uxtb	w16, w9
    7e14:      	cmp	w16, wzr
    7e18:      	b.eq	0x7e98 <_stogir.types.size+0xf4>
    7e1c:      	cmp	x2, #0x0
    7e20:      	cset	w3, ge
    7e24:      	cmp	x2, #0xd
    7e28:      	cset	w11, le
    7e2c:      	uxtb	w16, w3
    7e30:      	cmp	w16, wzr
    7e34:      	b.eq	0x7e44 <_stogir.types.size+0xa0>
    7e38:      	uxtb	w16, w11
    7e3c:      	cmp	w16, wzr
    7e40:      	b.ne	0x7e78 <_stogir.types.size+0xd4>
    7e44:      	uxtb	w16, w4
    7e48:      	cmp	w16, wzr
    7e4c:      	b.eq	0x7e74 <_stogir.types.size+0xd0>
    7e50:      	uxtb	w16, w8
    7e54:      	cmp	w16, wzr
    7e58:      	b.eq	0x7e74 <_stogir.types.size+0xd0>
    7e5c:      	uxtb	w16, w10
    7e60:      	cmp	w16, wzr
    7e64:      	b.eq	0x7e74 <_stogir.types.size+0xd0>
    7e68:      	uxtb	w16, w9
    7e6c:      	cmp	w16, wzr
    7e70:      	b.ne	0x7e78 <_stogir.types.size+0xd4>
    7e74:      	movn	w0, #0x0, lsl #16
    7e78:      	uxtb	w16, w6
    7e7c:      	cmp	w16, wzr
    7e80:      	b.ne	0x7fb8 <_stogir.types.size+0x214>
    7e84:      	uxtb	w16, w7
    7e88:      	cmp	w16, wzr
    7e8c:      	b.ne	0x7fb8 <_stogir.types.size+0x214>
    7e90:      	movn	w1, #0x0, lsl #16
    7e94:      	b	0x7f4c <_stogir.types.size+0x1a8>
    7e98:      	uxtb	w16, w6
    7e9c:      	cmp	w16, wzr
    7ea0:      	b.ne	0x7eb8 <_stogir.types.size+0x114>
    7ea4:      	uxtb	w16, w7
    7ea8:      	cmp	w16, wzr
    7eac:      	b.ne	0x7eb8 <_stogir.types.size+0x114>
    7eb0:      	movn	x3, #0x0, lsl #48
    7eb4:      	b	0x7ed0 <_stogir.types.size+0x12c>
    7eb8:      	uxtb	w16, w5
    7ebc:      	cmp	w16, wzr
    7ec0:      	b.eq	0x7ed8 <_stogir.types.size+0x134>
    7ec4:      	movz	x3, #0x0, lsl #48
    7ec8:      	b	0x7ed0 <_stogir.types.size+0x12c>
    7ecc:      	mov	x3, #0x1                ; =1
    7ed0:      	mov	x0, x3
    7ed4:      	ret
    7ed8:      	cmp	x2, #0x1
    7edc:      	b.eq	0x7ecc <_stogir.types.size+0x128>
    7ee0:      	cmp	x2, #0x2
    7ee4:      	b.eq	0x7ecc <_stogir.types.size+0x128>
    7ee8:      	cmp	x2, #0x7
    7eec:      	b.eq	0x7ecc <_stogir.types.size+0x128>
    7ef0:      	cmp	x2, #0x8
    7ef4:      	b.eq	0x7ecc <_stogir.types.size+0x128>
    7ef8:      	cmp	x2, #0x3
    7efc:      	b.eq	0x803c <_stogir.types.size+0x298>
    7f00:      	cmp	x2, #0x9
    7f04:      	b.eq	0x803c <_stogir.types.size+0x298>
    7f08:      	cmp	x2, #0x4
    7f0c:      	b.eq	0x806c <_stogir.types.size+0x2c8>
    7f10:      	cmp	x2, #0xa
    7f14:      	b.eq	0x806c <_stogir.types.size+0x2c8>
    7f18:      	cmp	x2, #0xd
    7f1c:      	b.eq	0x806c <_stogir.types.size+0x2c8>
    7f20:      	cmp	x2, #0x5
    7f24:      	b.eq	0x807c <_stogir.types.size+0x2d8>
    7f28:      	cmp	x2, #0xb
    7f2c:      	b.eq	0x807c <_stogir.types.size+0x2d8>
    7f30:      	cmp	x2, #0xc
    7f34:      	b.eq	0x807c <_stogir.types.size+0x2d8>
    7f38:      	cmp	x2, #0x6
    7f3c:      	b.eq	0x7f44 <_stogir.types.size+0x1a0>
    7f40:      	movn	x3, #0x0, lsl #48
    7f44:      	b	0x8080 <_stogir.types.size+0x2dc>
    7f48:      	mov	w1, #0x1                ; =1
    7f4c:      	sxtw	x0, w1
    7f50:      	cmp	x0, #0x0
    7f54:      	b.ge	0x7f60 <_stogir.types.size+0x1bc>
    7f58:      	movn	x3, #0x0, lsl #48
    7f5c:      	b	0x7ed0 <_stogir.types.size+0x12c>
    7f60:      	uxtb	w16, w4
    7f64:      	cmp	w16, wzr
    7f68:      	b.eq	0x8044 <_stogir.types.size+0x2a0>
    7f6c:      	uxtb	w16, w8
    7f70:      	cmp	w16, wzr
    7f74:      	b.eq	0x8044 <_stogir.types.size+0x2a0>
    7f78:      	uxtb	w16, w10
    7f7c:      	cmp	w16, wzr
    7f80:      	b.eq	0x8044 <_stogir.types.size+0x2a0>
    7f84:      	uxtb	w16, w9
    7f88:      	cmp	w16, wzr
    7f8c:      	b.eq	0x8044 <_stogir.types.size+0x2a0>
    7f90:      	ubfx	x0, x2, #4, #32
    7f94:      	sub	w0, w0, #0x1
    7f98:      	sxtw	x0, w0
    7f9c:      	mov	x16, #0x1               ; =1
    7fa0:      	lsl	x0, x16, x0
    7fa4:      	b	0x7fac <_stogir.types.size+0x208>
    7fa8:      	movn	w0, #0x0, lsl #16
    7fac:      	mul	w0, w0, w1
    7fb0:      	sxtw	x3, w0
    7fb4:      	b	0x7f5c <_stogir.types.size+0x1b8>
    7fb8:      	sxtw	x0, w0
    7fbc:      	cmp	x0, #0x0
    7fc0:      	b.ne	0x7fcc <_stogir.types.size+0x228>
    7fc4:      	movz	w1, #0x0, lsl #16
    7fc8:      	b	0x7f4c <_stogir.types.size+0x1a8>
    7fcc:      	cmp	x0, #0x1
    7fd0:      	b.eq	0x7f48 <_stogir.types.size+0x1a4>
    7fd4:      	cmp	x0, #0x2
    7fd8:      	b.eq	0x7f48 <_stogir.types.size+0x1a4>
    7fdc:      	cmp	x0, #0x7
    7fe0:      	b.eq	0x7f48 <_stogir.types.size+0x1a4>
    7fe4:      	cmp	x0, #0x8
    7fe8:      	b.eq	0x7f48 <_stogir.types.size+0x1a4>
    7fec:      	cmp	x0, #0x3
    7ff0:      	b.eq	0x8074 <_stogir.types.size+0x2d0>
    7ff4:      	cmp	x0, #0x9
    7ff8:      	b.eq	0x8074 <_stogir.types.size+0x2d0>
    7ffc:      	cmp	x0, #0x4
    8000:      	b.eq	0x8084 <_stogir.types.size+0x2e0>
    8004:      	cmp	x0, #0xa
    8008:      	b.eq	0x8084 <_stogir.types.size+0x2e0>
    800c:      	cmp	x0, #0xd
    8010:      	b.eq	0x8084 <_stogir.types.size+0x2e0>
    8014:      	cmp	x0, #0x5
    8018:      	b.eq	0x808c <_stogir.types.size+0x2e8>
    801c:      	cmp	x0, #0xb
    8020:      	b.eq	0x808c <_stogir.types.size+0x2e8>
    8024:      	cmp	x0, #0xc
    8028:      	b.eq	0x808c <_stogir.types.size+0x2e8>
    802c:      	cmp	x0, #0x6
    8030:      	b.eq	0x8038 <_stogir.types.size+0x294>
    8034:      	movn	w1, #0x0, lsl #16
    8038:      	b	0x8090 <_stogir.types.size+0x2ec>
    803c:      	mov	x3, #0x2                ; =2
    8040:      	b	0x7ed0 <_stogir.types.size+0x12c>
    8044:      	uxtb	w16, w3
    8048:      	cmp	w16, wzr
    804c:      	b.eq	0x7fa8 <_stogir.types.size+0x204>
    8050:      	uxtb	w16, w11
    8054:      	cmp	w16, wzr
    8058:      	b.eq	0x7fa8 <_stogir.types.size+0x204>
    805c:      	uxtb	w16, w5
    8060:      	cmp	w16, wzr
    8064:      	cset	w0, eq
    8068:      	b	0x7fac <_stogir.types.size+0x208>
    806c:      	mov	x3, #0x4                ; =4
    8070:      	b	0x8040 <_stogir.types.size+0x29c>
    8074:      	mov	w1, #0x2                ; =2
    8078:      	b	0x7f4c <_stogir.types.size+0x1a8>
    807c:      	mov	x3, #0x8                ; =8
    8080:      	b	0x8070 <_stogir.types.size+0x2cc>
    8084:      	mov	w1, #0x4                ; =4
    8088:      	b	0x8078 <_stogir.types.size+0x2d4>
    808c:      	mov	w1, #0x8                ; =8
    8090:      	b	0x8088 <_stogir.types.size+0x2e4>

0000000000008094 <_stogir.checked.projection>:
    8094:      	sub	sp, sp, #0x40
    8098:      	str	x29, [sp]
    809c:      	str	x30, [sp, #0x8]
    80a0:      	mov	x29, sp
    80a4:      	str	x19, [sp, #0x30]
    80a8:      	sxtw	x2, w1
    80ac:      	cmp	x2, #0x0
    80b0:      	cset	w3, gt
    80b4:      	movz	x16, #0x0, lsl #48
    80b8:      	sub	x4, x16, x2
    80bc:      	sub	x5, x4, #0x1
    80c0:      	uxtb	w16, w3
    80c4:      	cmp	w16, wzr
    80c8:      	b.eq	0x8108 <_stogir.checked.projection+0x74>
    80cc:      	ldr	x4, [x0, #0x8]
    80d0:      	cmp	x2, x4
    80d4:      	b.ge	0x8158 <_stogir.checked.projection+0xc4>
    80d8:      	add	x4, x0, #0x78
    80dc:      	ldr	x4, [x4, #0x8]
    80e0:      	cmp	x2, x4
    80e4:      	b.ge	0x8260 <_stogir.checked.projection+0x1cc>
    80e8:      	ldr	x4, [x0, #0x78]
    80ec:      	add	x4, x4, x2, lsl #2
    80f0:      	ldr	w4, [x4]
    80f4:      	sxtw	x4, w4
    80f8:      	cmp	x4, #0x0
    80fc:      	cset	w4, ge
    8100:      	ubfx	x4, x4, #0, #8
    8104:      	b	0x8264 <_stogir.checked.projection+0x1d0>
    8108:      	cmp	x2, #0x0
    810c:      	b.ge	0x8160 <_stogir.checked.projection+0xcc>
    8110:      	add	x6, x0, #0x28
    8114:      	add	x7, x0, #0x50
    8118:      	ldr	x6, [x6, #0x8]
    811c:      	ldr	x7, [x7, #0x8]
    8120:      	cmp	x6, x7
    8124:      	b.ne	0x8150 <_stogir.checked.projection+0xbc>
    8128:      	cmp	x4, x6
    812c:      	b.gt	0x8290 <_stogir.checked.projection+0x1fc>
    8130:      	ldr	x4, [x0, #0x50]
    8134:      	add	x4, x4, x5, lsl #2
    8138:      	ldr	w4, [x4]
    813c:      	sxtw	x4, w4
    8140:      	cmp	x4, #0x0
    8144:      	cset	w4, gt
    8148:      	ubfx	x4, x4, #0, #8
    814c:      	b	0x8294 <_stogir.checked.projection+0x200>
    8150:      	movz	x4, #0x0, lsl #48
    8154:      	b	0x8164 <_stogir.checked.projection+0xd0>
    8158:      	movz	x4, #0x0, lsl #48
    815c:      	b	0x8164 <_stogir.checked.projection+0xd0>
    8160:      	movz	x4, #0x0, lsl #48
    8164:      	cmp	x4, #0x0
    8168:      	b.eq	0x819c <_stogir.checked.projection+0x108>
    816c:      	uxtb	w16, w3
    8170:      	cmp	w16, wzr
    8174:      	b.eq	0x8188 <_stogir.checked.projection+0xf4>
    8178:      	ldr	x3, [x0]
    817c:      	add	x2, x3, x2, lsl #4
    8180:      	ldr	x2, [x2]
    8184:      	b	0x8194 <_stogir.checked.projection+0x100>
    8188:      	ldr	x2, [x0, #0x28]
    818c:      	add	x2, x2, x5, lsl #4
    8190:      	ldr	x2, [x2]
    8194:      	mov	w3, #0x1                ; =1
    8198:      	b	0x81a4 <_stogir.checked.projection+0x110>
    819c:      	movz	w3, #0x0, lsl #16
    81a0:      	movz	x2, #0x0, lsl #48
    81a4:      	ubfx	x3, x3, #0, #32
    81a8:      	lsr	x16, x3, #0
    81ac:      	cmp	x16, #0x1
    81b0:      	b.eq	0x81cc <_stogir.checked.projection+0x138>
    81b4:      	b.lo	0x81bc <_stogir.checked.projection+0x128>
    81b8:      	b	0x81d0 <_stogir.checked.projection+0x13c>
    81bc:      	cmp	x16, #0x0
    81c0:      	b.eq	0x81c8 <_stogir.checked.projection+0x134>
    81c4:      	b	0x81d0 <_stogir.checked.projection+0x13c>
    81c8:      	b	0x81d4 <_stogir.checked.projection+0x140>
    81cc:      	b	0x8224 <_stogir.checked.projection+0x190>
    81d0:      	b	0x8298 <_stogir.checked.projection+0x204>
    81d4:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		00000000000081d4:  ARM64_RELOC_PAGE21	l_stogir.425
    81d8:      	ldr	x16, [x16]
		00000000000081d8:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    81dc:      	orr	x0, x16, xzr
    81e0:      	mov	x19, x8
    81e4:      	mov	x1, #0x1                ; =1
    81e8:      	mov	x2, #0x17               ; =23
    81ec:      	b	0x8204 <_stogir.checked.projection+0x170>
    81f0:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		00000000000081f0:  ARM64_RELOC_PAGE21	l_stogir.426
    81f4:      	ldr	x16, [x16]
		00000000000081f4:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    81f8:      	orr	x0, x16, xzr
    81fc:      	mov	x1, #0x1                ; =1
    8200:      	mov	x2, #0x20               ; =32
    8204:      	str	x1, [x19]
    8208:      	str	x0, [x19, #0x8]
    820c:      	str	x2, [x19, #0x10]
    8210:      	ldr	x19, [sp, #0x30]
    8214:      	ldr	x29, [sp]
    8218:      	ldr	x30, [sp, #0x8]
    821c:      	add	sp, sp, #0x40
    8220:      	ret
    8224:      	uxtb	w3, w2
    8228:      	cmp	x3, #0x29
    822c:      	b.lt	0x82a0 <_stogir.checked.projection+0x20c>
    8230:      	cmp	x3, #0x2b
    8234:      	b.gt	0x82a8 <_stogir.checked.projection+0x214>
    8238:      	mov	x19, x8
    823c:      	add	x8, sp, #0x10
    8240:      	bl	0x8240 <_stogir.checked.projection+0x1ac>
		0000000000008240:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    8244:      	add	x16, sp, #0x10
    8248:      	ldr	x1, [x16]
    824c:      	add	x16, sp, #0x10
    8250:      	ldr	x0, [x16, #0x8]
    8254:      	add	x16, sp, #0x10
    8258:      	ldr	x2, [x16, #0x10]
    825c:      	b	0x8204 <_stogir.checked.projection+0x170>
    8260:      	movz	x4, #0x0, lsl #48
    8264:      	b	0x815c <_stogir.checked.projection+0xc8>
    8268:      	ubfx	x2, x2, #0, #32
    826c:      	ubfx	x0, x2, #8, #8
    8270:      	cmp	x0, #0x0
    8274:      	b.eq	0x81f0 <_stogir.checked.projection+0x15c>
    8278:      	cmp	x0, #0xd
    827c:      	b.gt	0x81f0 <_stogir.checked.projection+0x15c>
    8280:      	movz	x1, #0x0, lsl #48
    8284:      	movz	x0, #0x0, lsl #48
    8288:      	movz	x2, #0x0, lsl #48
    828c:      	b	0x8204 <_stogir.checked.projection+0x170>
    8290:      	movz	x4, #0x0, lsl #48
    8294:      	b	0x8154 <_stogir.checked.projection+0xc0>
    8298:      	brk	#0
    829c:      	b	0x8298 <_stogir.checked.projection+0x204>
    82a0:      	mov	x19, x8
    82a4:      	b	0x8268 <_stogir.checked.projection+0x1d4>
    82a8:      	mov	x19, x8
    82ac:      	b	0x8268 <_stogir.checked.projection+0x1d4>

00000000000082b0 <_stogir.opcode.control?>:
    82b0:      	sxtw	x0, w0
    82b4:      	cmp	x0, #0x0
    82b8:      	b.lt	0x82dc <_stogir.opcode.control?+0x2c>
    82bc:      	cmp	x0, #0x83
    82c0:      	b.ge	0x82dc <_stogir.opcode.control?+0x2c>
    82c4:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		00000000000082c4:  ARM64_RELOC_PAGE21	l_stogir.427
    82c8:      	ldr	x16, [x16]
		00000000000082c8:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    82cc:      	orr	x1, x16, xzr
    82d0:      	add	x0, x1, x0
    82d4:      	ldrb	w0, [x0]
    82d8:      	b	0x82e0 <_stogir.opcode.control?+0x30>
    82dc:      	movz	w0, #0x0, lsl #16
    82e0:      	uxtb	w16, w0
    82e4:      	and	w0, w16, #0x1
    82e8:      	uxtb	w0, w0
    82ec:      	ubfx	x0, x0, #0, #8
    82f0:      	ret

00000000000082f4 <_stogir.opcode.block-end?>:
    82f4:      	sxtw	x0, w0
    82f8:      	cmp	x0, #0x0
    82fc:      	b.lt	0x8320 <_stogir.opcode.block-end?+0x2c>
    8300:      	cmp	x0, #0x83
    8304:      	b.ge	0x8320 <_stogir.opcode.block-end?+0x2c>
    8308:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008308:  ARM64_RELOC_PAGE21	l_stogir.428
    830c:      	ldr	x16, [x16]
		000000000000830c:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    8310:      	orr	x1, x16, xzr
    8314:      	add	x0, x1, x0
    8318:      	ldrb	w0, [x0]
    831c:      	b	0x8324 <_stogir.opcode.block-end?+0x30>
    8320:      	movz	w0, #0x0, lsl #16
    8324:      	uxtb	w16, w0
    8328:      	and	w0, w16, #0x4
    832c:      	uxtb	w0, w0
    8330:      	ubfx	x0, x0, #0, #8
    8334:      	cmp	x0, #0x0
    8338:      	cset	w0, eq
    833c:      	uxtb	w16, w0
    8340:      	cmp	w16, wzr
    8344:      	cset	x0, eq
    8348:      	ret

000000000000834c <_stogir.atomic.ordinary?>:
    834c:      	sxtw	x1, w1
    8350:      	cmp	x1, #0x0
    8354:      	cset	w3, gt
    8358:      	movz	x16, #0x0, lsl #48
    835c:      	sub	x4, x16, x1
    8360:      	sub	x5, x4, #0x1
    8364:      	uxtb	w16, w3
    8368:      	cmp	w16, wzr
    836c:      	b.eq	0x83ac <_stogir.atomic.ordinary?+0x60>
    8370:      	ldr	x4, [x0, #0x8]
    8374:      	cmp	x1, x4
    8378:      	b.ge	0x83fc <_stogir.atomic.ordinary?+0xb0>
    837c:      	add	x4, x0, #0x78
    8380:      	ldr	x4, [x4, #0x8]
    8384:      	cmp	x1, x4
    8388:      	b.ge	0x84b4 <_stogir.atomic.ordinary?+0x168>
    838c:      	ldr	x4, [x0, #0x78]
    8390:      	add	x4, x4, x1, lsl #2
    8394:      	ldr	w4, [x4]
    8398:      	sxtw	x4, w4
    839c:      	cmp	x4, #0x0
    83a0:      	cset	w4, ge
    83a4:      	ubfx	x4, x4, #0, #8
    83a8:      	b	0x84b8 <_stogir.atomic.ordinary?+0x16c>
    83ac:      	cmp	x1, #0x0
    83b0:      	b.ge	0x8404 <_stogir.atomic.ordinary?+0xb8>
    83b4:      	add	x6, x0, #0x28
    83b8:      	add	x7, x0, #0x50
    83bc:      	ldr	x6, [x6, #0x8]
    83c0:      	ldr	x7, [x7, #0x8]
    83c4:      	cmp	x6, x7
    83c8:      	b.ne	0x83f4 <_stogir.atomic.ordinary?+0xa8>
    83cc:      	cmp	x4, x6
    83d0:      	b.gt	0x84d4 <_stogir.atomic.ordinary?+0x188>
    83d4:      	ldr	x4, [x0, #0x50]
    83d8:      	add	x4, x4, x5, lsl #2
    83dc:      	ldr	w4, [x4]
    83e0:      	sxtw	x4, w4
    83e4:      	cmp	x4, #0x0
    83e8:      	cset	w4, gt
    83ec:      	ubfx	x4, x4, #0, #8
    83f0:      	b	0x84d8 <_stogir.atomic.ordinary?+0x18c>
    83f4:      	movz	x4, #0x0, lsl #48
    83f8:      	b	0x8408 <_stogir.atomic.ordinary?+0xbc>
    83fc:      	movz	x4, #0x0, lsl #48
    8400:      	b	0x8408 <_stogir.atomic.ordinary?+0xbc>
    8404:      	movz	x4, #0x0, lsl #48
    8408:      	cmp	x4, #0x0
    840c:      	b.eq	0x8440 <_stogir.atomic.ordinary?+0xf4>
    8410:      	uxtb	w16, w3
    8414:      	cmp	w16, wzr
    8418:      	b.eq	0x842c <_stogir.atomic.ordinary?+0xe0>
    841c:      	ldr	x0, [x0]
    8420:      	add	x0, x0, x1, lsl #4
    8424:      	ldr	x0, [x0]
    8428:      	b	0x8438 <_stogir.atomic.ordinary?+0xec>
    842c:      	ldr	x0, [x0, #0x28]
    8430:      	add	x0, x0, x5, lsl #4
    8434:      	ldr	x0, [x0]
    8438:      	mov	w1, #0x1                ; =1
    843c:      	b	0x8448 <_stogir.atomic.ordinary?+0xfc>
    8440:      	movz	w1, #0x0, lsl #16
    8444:      	movz	x0, #0x0, lsl #48
    8448:      	ubfx	x1, x1, #0, #32
    844c:      	lsr	x16, x1, #0
    8450:      	cmp	x16, #0x1
    8454:      	b.eq	0x8470 <_stogir.atomic.ordinary?+0x124>
    8458:      	b.lo	0x8460 <_stogir.atomic.ordinary?+0x114>
    845c:      	b	0x8474 <_stogir.atomic.ordinary?+0x128>
    8460:      	cmp	x16, #0x0
    8464:      	b.eq	0x846c <_stogir.atomic.ordinary?+0x120>
    8468:      	b	0x8474 <_stogir.atomic.ordinary?+0x128>
    846c:      	b	0x8478 <_stogir.atomic.ordinary?+0x12c>
    8470:      	b	0x8488 <_stogir.atomic.ordinary?+0x13c>
    8474:      	b	0x84dc <_stogir.atomic.ordinary?+0x190>
    8478:      	movz	x0, #0x0, lsl #48
    847c:      	b	0x8484 <_stogir.atomic.ordinary?+0x138>
    8480:      	movz	x0, #0x0, lsl #48
    8484:      	ret
    8488:      	sxtw	x2, w2
    848c:      	orr	w1, w0, wzr
    8490:      	ubfx	x1, x1, #0, #32
    8494:      	ubfx	x1, x1, #8, #8
    8498:      	cmp	x1, x2
    849c:      	b.ne	0x8480 <_stogir.atomic.ordinary?+0x134>
    84a0:      	uxtb	w0, w0
    84a4:      	cmp	x0, #0x46
    84a8:      	b.ne	0x84bc <_stogir.atomic.ordinary?+0x170>
    84ac:      	movz	x0, #0x0, lsl #48
    84b0:      	b	0x84d0 <_stogir.atomic.ordinary?+0x184>
    84b4:      	movz	x4, #0x0, lsl #48
    84b8:      	b	0x8400 <_stogir.atomic.ordinary?+0xb4>
    84bc:      	cmp	x0, #0x48
    84c0:      	cset	w0, eq
    84c4:      	uxtb	w16, w0
    84c8:      	cmp	w16, wzr
    84cc:      	cset	x0, eq
    84d0:      	b	0x8484 <_stogir.atomic.ordinary?+0x138>
    84d4:      	movz	x4, #0x0, lsl #48
    84d8:      	b	0x83f8 <_stogir.atomic.ordinary?+0xac>
    84dc:      	brk	#0
    84e0:      	b	0x84dc <_stogir.atomic.ordinary?+0x190>

00000000000084e4 <_stogir.types.scalar-size>:
    84e4:      	sxtw	x1, w1
    84e8:      	cmp	x1, #0x4
    84ec:      	b.eq	0x8500 <_stogir.types.scalar-size+0x1c>
    84f0:      	cmp	x1, #0x8
    84f4:      	b.eq	0x8500 <_stogir.types.scalar-size+0x1c>
    84f8:      	movn	x1, #0x0, lsl #48
    84fc:      	b	0x8518 <_stogir.types.scalar-size+0x34>
    8500:      	sxtw	x0, w0
    8504:      	cmp	x0, #0x0
    8508:      	b.ne	0x8520 <_stogir.types.scalar-size+0x3c>
    850c:      	movz	x1, #0x0, lsl #48
    8510:      	b	0x8518 <_stogir.types.scalar-size+0x34>
    8514:      	mov	x1, #0x1                ; =1
    8518:      	mov	x0, x1
    851c:      	ret
    8520:      	cmp	x0, #0x1
    8524:      	b.eq	0x8514 <_stogir.types.scalar-size+0x30>
    8528:      	cmp	x0, #0x2
    852c:      	b.eq	0x8514 <_stogir.types.scalar-size+0x30>
    8530:      	cmp	x0, #0x7
    8534:      	b.eq	0x8514 <_stogir.types.scalar-size+0x30>
    8538:      	cmp	x0, #0x8
    853c:      	b.eq	0x8514 <_stogir.types.scalar-size+0x30>
    8540:      	cmp	x0, #0x3
    8544:      	b.eq	0x8590 <_stogir.types.scalar-size+0xac>
    8548:      	cmp	x0, #0x9
    854c:      	b.eq	0x8590 <_stogir.types.scalar-size+0xac>
    8550:      	cmp	x0, #0x4
    8554:      	b.eq	0x8598 <_stogir.types.scalar-size+0xb4>
    8558:      	cmp	x0, #0xa
    855c:      	b.eq	0x8598 <_stogir.types.scalar-size+0xb4>
    8560:      	cmp	x0, #0xd
    8564:      	b.eq	0x8598 <_stogir.types.scalar-size+0xb4>
    8568:      	cmp	x0, #0x5
    856c:      	b.eq	0x85a0 <_stogir.types.scalar-size+0xbc>
    8570:      	cmp	x0, #0xb
    8574:      	b.eq	0x85a0 <_stogir.types.scalar-size+0xbc>
    8578:      	cmp	x0, #0xc
    857c:      	b.eq	0x85a0 <_stogir.types.scalar-size+0xbc>
    8580:      	cmp	x0, #0x6
    8584:      	b.eq	0x858c <_stogir.types.scalar-size+0xa8>
    8588:      	movn	x1, #0x0, lsl #48
    858c:      	b	0x85a4 <_stogir.types.scalar-size+0xc0>
    8590:      	mov	x1, #0x2                ; =2
    8594:      	b	0x8518 <_stogir.types.scalar-size+0x34>
    8598:      	mov	x1, #0x4                ; =4
    859c:      	b	0x8594 <_stogir.types.scalar-size+0xb0>
    85a0:      	mov	x1, #0x8                ; =8
    85a4:      	b	0x859c <_stogir.types.scalar-size+0xb8>

00000000000085a8 <_stogir.terminal.inputs>:
    85a8:      	sxtw	x1, w1
    85ac:      	cmp	x1, #0x60
    85b0:      	cset	w4, eq
    85b4:      	uxtb	w16, w4
    85b8:      	cmp	w16, wzr
    85bc:      	b.ne	0x85ec <_stogir.terminal.inputs+0x44>
    85c0:      	cmp	x1, #0x79
    85c4:      	b.eq	0x85ec <_stogir.terminal.inputs+0x44>
    85c8:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		00000000000085c8:  ARM64_RELOC_PAGE21	l_stogir.429
    85cc:      	ldr	x16, [x16]
		00000000000085cc:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    85d0:      	orr	x0, x16, xzr
    85d4:      	mov	x1, #0x1                ; =1
    85d8:      	mov	x2, #0x25               ; =37
    85dc:      	str	x1, [x8]
    85e0:      	str	x0, [x8, #0x8]
    85e4:      	str	x2, [x8, #0x10]
    85e8:      	ret
    85ec:      	sxtw	x3, w3
    85f0:      	uxtb	w16, w4
    85f4:      	cmp	w16, wzr
    85f8:      	b.eq	0x8604 <_stogir.terminal.inputs+0x5c>
    85fc:      	cmp	x3, #0x0
    8600:      	b.ne	0x85c8 <_stogir.terminal.inputs+0x20>
    8604:      	sxtw	x2, w2
    8608:      	cmp	x2, #0x0
    860c:      	cset	w1, gt
    8610:      	movz	x16, #0x0, lsl #48
    8614:      	sub	x4, x16, x2
    8618:      	sub	x5, x4, #0x1
    861c:      	uxtb	w16, w1
    8620:      	cmp	w16, wzr
    8624:      	b.eq	0x86f8 <_stogir.terminal.inputs+0x150>
    8628:      	ldr	x4, [x0, #0x8]
    862c:      	cmp	x2, x4
    8630:      	b.ge	0x86f0 <_stogir.terminal.inputs+0x148>
    8634:      	add	x4, x0, #0x78
    8638:      	ldr	x4, [x4, #0x8]
    863c:      	cmp	x2, x4
    8640:      	b.ge	0x8798 <_stogir.terminal.inputs+0x1f0>
    8644:      	ldr	x4, [x0, #0x78]
    8648:      	add	x4, x4, x2, lsl #2
    864c:      	ldr	w4, [x4]
    8650:      	sxtw	x4, w4
    8654:      	cmp	x4, #0x0
    8658:      	cset	w4, ge
    865c:      	ubfx	x4, x4, #0, #8
    8660:      	b	0x879c <_stogir.terminal.inputs+0x1f4>
    8664:      	movz	w4, #0x0, lsl #16
    8668:      	movz	x1, #0x0, lsl #48
    866c:      	ubfx	x4, x4, #0, #32
    8670:      	lsr	x16, x4, #0
    8674:      	cmp	x16, #0x1
    8678:      	b.eq	0x8694 <_stogir.terminal.inputs+0xec>
    867c:      	b.lo	0x8684 <_stogir.terminal.inputs+0xdc>
    8680:      	b	0x8698 <_stogir.terminal.inputs+0xf0>
    8684:      	cmp	x16, #0x0
    8688:      	b.eq	0x8690 <_stogir.terminal.inputs+0xe8>
    868c:      	b	0x8698 <_stogir.terminal.inputs+0xf0>
    8690:      	b	0x869c <_stogir.terminal.inputs+0xf4>
    8694:      	b	0x8740 <_stogir.terminal.inputs+0x198>
    8698:      	b	0x88ec <_stogir.terminal.inputs+0x344>
    869c:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		000000000000869c:  ARM64_RELOC_PAGE21	l_stogir.430
    86a0:      	ldr	x16, [x16]
		00000000000086a0:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    86a4:      	orr	x0, x16, xzr
    86a8:      	mov	x1, #0x1                ; =1
    86ac:      	mov	x2, #0x1d               ; =29
    86b0:      	b	0x85dc <_stogir.terminal.inputs+0x34>
    86b4:      	ldr	x1, [x0, #0x28]
    86b8:      	add	x1, x1, x5, lsl #4
    86bc:      	ldr	x1, [x1]
    86c0:      	mov	w4, #0x1                ; =1
    86c4:      	b	0x866c <_stogir.terminal.inputs+0xc4>
    86c8:      	movz	x4, #0x0, lsl #48
    86cc:      	cmp	x4, #0x0
    86d0:      	b.eq	0x8664 <_stogir.terminal.inputs+0xbc>
    86d4:      	uxtb	w16, w1
    86d8:      	cmp	w16, wzr
    86dc:      	b.eq	0x86b4 <_stogir.terminal.inputs+0x10c>
    86e0:      	ldr	x1, [x0]
    86e4:      	add	x1, x1, x2, lsl #4
    86e8:      	ldr	x1, [x1]
    86ec:      	b	0x86c0 <_stogir.terminal.inputs+0x118>
    86f0:      	movz	x4, #0x0, lsl #48
    86f4:      	b	0x86cc <_stogir.terminal.inputs+0x124>
    86f8:      	cmp	x2, #0x0
    86fc:      	b.ge	0x86c8 <_stogir.terminal.inputs+0x120>
    8700:      	add	x6, x0, #0x28
    8704:      	add	x7, x0, #0x50
    8708:      	ldr	x6, [x6, #0x8]
    870c:      	ldr	x7, [x7, #0x8]
    8710:      	cmp	x6, x7
    8714:      	b.ne	0x8790 <_stogir.terminal.inputs+0x1e8>
    8718:      	cmp	x4, x6
    871c:      	b.gt	0x87a0 <_stogir.terminal.inputs+0x1f8>
    8720:      	ldr	x4, [x0, #0x50]
    8724:      	add	x4, x4, x5, lsl #2
    8728:      	ldr	w4, [x4]
    872c:      	sxtw	x4, w4
    8730:      	cmp	x4, #0x0
    8734:      	cset	w4, gt
    8738:      	ubfx	x4, x4, #0, #8
    873c:      	b	0x87a4 <_stogir.terminal.inputs+0x1fc>
    8740:      	cmp	x2, #0x0
    8744:      	b.le	0x8778 <_stogir.terminal.inputs+0x1d0>
    8748:      	uxtb	w1, w1
    874c:      	cmp	x1, #0x83
    8750:      	cset	w2, lt
    8754:      	uxtb	w16, w2
    8758:      	cmp	w16, wzr
    875c:      	b.eq	0x87a8 <_stogir.terminal.inputs+0x200>
    8760:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008760:  ARM64_RELOC_PAGE21	l_stogir.431
    8764:      	ldr	x16, [x16]
		0000000000008764:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    8768:      	orr	x4, x16, xzr
    876c:      	add	x4, x1, x4
    8770:      	ldrb	w4, [x4]
    8774:      	b	0x87ac <_stogir.terminal.inputs+0x204>
    8778:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008778:  ARM64_RELOC_PAGE21	l_stogir.432
    877c:      	ldr	x16, [x16]
		000000000000877c:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    8780:      	orr	x0, x16, xzr
    8784:      	mov	x1, #0x1                ; =1
    8788:      	mov	x2, #0x2c               ; =44
    878c:      	b	0x86b0 <_stogir.terminal.inputs+0x108>
    8790:      	movz	x4, #0x0, lsl #48
    8794:      	b	0x86cc <_stogir.terminal.inputs+0x124>
    8798:      	movz	x4, #0x0, lsl #48
    879c:      	b	0x86f4 <_stogir.terminal.inputs+0x14c>
    87a0:      	movz	x4, #0x0, lsl #48
    87a4:      	b	0x8794 <_stogir.terminal.inputs+0x1ec>
    87a8:      	movz	w4, #0x0, lsl #16
    87ac:      	uxtb	w16, w4
    87b0:      	and	w4, w16, #0x1
    87b4:      	uxtb	w4, w4
    87b8:      	ubfx	x4, x4, #0, #8
    87bc:      	cmp	x4, #0x0
    87c0:      	b.eq	0x8778 <_stogir.terminal.inputs+0x1d0>
    87c4:      	uxtb	w16, w2
    87c8:      	cmp	w16, wzr
    87cc:      	b.eq	0x87e8 <_stogir.terminal.inputs+0x240>
    87d0:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		00000000000087d0:  ARM64_RELOC_PAGE21	l_stogir.431
    87d4:      	ldr	x16, [x16]
		00000000000087d4:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    87d8:      	orr	x2, x16, xzr
    87dc:      	add	x1, x1, x2
    87e0:      	ldrb	w1, [x1]
    87e4:      	b	0x87ec <_stogir.terminal.inputs+0x244>
    87e8:      	movz	w1, #0x0, lsl #16
    87ec:      	uxtb	w16, w1
    87f0:      	and	w1, w16, #0x4
    87f4:      	uxtb	w1, w1
    87f8:      	ubfx	x1, x1, #0, #8
    87fc:      	cmp	x1, #0x0
    8800:      	cset	w1, eq
    8804:      	uxtb	w16, w1
    8808:      	cmp	w16, wzr
    880c:      	cset	x1, eq
    8810:      	cmp	x1, #0x0
    8814:      	b.ne	0x8778 <_stogir.terminal.inputs+0x1d0>
    8818:      	cmp	x3, #0x0
    881c:      	b.ne	0x8830 <_stogir.terminal.inputs+0x288>
    8820:      	movz	x1, #0x0, lsl #48
    8824:      	movz	x0, #0x0, lsl #48
    8828:      	movz	x2, #0x0, lsl #48
    882c:      	b	0x878c <_stogir.terminal.inputs+0x1e4>
    8830:      	cmp	x3, #0x0
    8834:      	cset	w1, gt
    8838:      	movz	x16, #0x0, lsl #48
    883c:      	sub	x2, x16, x3
    8840:      	sub	x4, x2, #0x1
    8844:      	uxtb	w16, w1
    8848:      	cmp	w16, wzr
    884c:      	b.eq	0x88a4 <_stogir.terminal.inputs+0x2fc>
    8850:      	ldr	x2, [x0, #0x8]
    8854:      	cmp	x3, x2
    8858:      	b.ge	0x88f4 <_stogir.terminal.inputs+0x34c>
    885c:      	add	x2, x0, #0x78
    8860:      	ldr	x2, [x2, #0x8]
    8864:      	cmp	x3, x2
    8868:      	b.ge	0x89bc <_stogir.terminal.inputs+0x414>
    886c:      	ldr	x2, [x0, #0x78]
    8870:      	add	x2, x2, x3, lsl #2
    8874:      	ldr	w2, [x2]
    8878:      	sxtw	x2, w2
    887c:      	cmp	x2, #0x0
    8880:      	cset	w2, ge
    8884:      	ubfx	x2, x2, #0, #8
    8888:      	b	0x89c0 <_stogir.terminal.inputs+0x418>
    888c:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		000000000000888c:  ARM64_RELOC_PAGE21	l_stogir.433
    8890:      	ldr	x16, [x16]
		0000000000008890:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    8894:      	orr	x0, x16, xzr
    8898:      	mov	x1, #0x1                ; =1
    889c:      	mov	x2, #0x2e               ; =46
    88a0:      	b	0x882c <_stogir.terminal.inputs+0x284>
    88a4:      	cmp	x3, #0x0
    88a8:      	b.ge	0x88fc <_stogir.terminal.inputs+0x354>
    88ac:      	add	x5, x0, #0x28
    88b0:      	add	x6, x0, #0x50
    88b4:      	ldr	x5, [x5, #0x8]
    88b8:      	ldr	x6, [x6, #0x8]
    88bc:      	cmp	x5, x6
    88c0:      	b.ne	0x89b4 <_stogir.terminal.inputs+0x40c>
    88c4:      	cmp	x2, x5
    88c8:      	b.gt	0x89c4 <_stogir.terminal.inputs+0x41c>
    88cc:      	ldr	x2, [x0, #0x50]
    88d0:      	add	x2, x2, x4, lsl #2
    88d4:      	ldr	w2, [x2]
    88d8:      	sxtw	x2, w2
    88dc:      	cmp	x2, #0x0
    88e0:      	cset	w2, gt
    88e4:      	ubfx	x2, x2, #0, #8
    88e8:      	b	0x89c8 <_stogir.terminal.inputs+0x420>
    88ec:      	brk	#0
    88f0:      	b	0x88ec <_stogir.terminal.inputs+0x344>
    88f4:      	movz	x2, #0x0, lsl #48
    88f8:      	b	0x8900 <_stogir.terminal.inputs+0x358>
    88fc:      	movz	x2, #0x0, lsl #48
    8900:      	cmp	x2, #0x0
    8904:      	b.eq	0x8938 <_stogir.terminal.inputs+0x390>
    8908:      	uxtb	w16, w1
    890c:      	cmp	w16, wzr
    8910:      	b.eq	0x8924 <_stogir.terminal.inputs+0x37c>
    8914:      	ldr	x0, [x0]
    8918:      	add	x0, x0, x3, lsl #4
    891c:      	ldr	x0, [x0]
    8920:      	b	0x8930 <_stogir.terminal.inputs+0x388>
    8924:      	ldr	x0, [x0, #0x28]
    8928:      	add	x0, x0, x4, lsl #4
    892c:      	ldr	x0, [x0]
    8930:      	mov	w1, #0x1                ; =1
    8934:      	b	0x8940 <_stogir.terminal.inputs+0x398>
    8938:      	movz	w1, #0x0, lsl #16
    893c:      	movz	x0, #0x0, lsl #48
    8940:      	ubfx	x1, x1, #0, #32
    8944:      	lsr	x16, x1, #0
    8948:      	cmp	x16, #0x1
    894c:      	b.eq	0x8968 <_stogir.terminal.inputs+0x3c0>
    8950:      	b.lo	0x8958 <_stogir.terminal.inputs+0x3b0>
    8954:      	b	0x896c <_stogir.terminal.inputs+0x3c4>
    8958:      	cmp	x16, #0x0
    895c:      	b.eq	0x8964 <_stogir.terminal.inputs+0x3bc>
    8960:      	b	0x896c <_stogir.terminal.inputs+0x3c4>
    8964:      	b	0x8970 <_stogir.terminal.inputs+0x3c8>
    8968:      	b	0x8988 <_stogir.terminal.inputs+0x3e0>
    896c:      	b	0x8a0c <_stogir.terminal.inputs+0x464>
    8970:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008970:  ARM64_RELOC_PAGE21	l_stogir.434
    8974:      	ldr	x16, [x16]
		0000000000008974:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    8978:      	orr	x0, x16, xzr
    897c:      	mov	x1, #0x1                ; =1
    8980:      	mov	x2, #0x1d               ; =29
    8984:      	b	0x88a0 <_stogir.terminal.inputs+0x2f8>
    8988:      	cmp	x3, #0x0
    898c:      	b.le	0x888c <_stogir.terminal.inputs+0x2e4>
    8990:      	uxtb	w0, w0
    8994:      	cmp	x0, #0x83
    8998:      	b.ge	0x89cc <_stogir.terminal.inputs+0x424>
    899c:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		000000000000899c:  ARM64_RELOC_PAGE21	l_stogir.431
    89a0:      	ldr	x16, [x16]
		00000000000089a0:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    89a4:      	orr	x1, x16, xzr
    89a8:      	add	x0, x0, x1
    89ac:      	ldrb	w0, [x0]
    89b0:      	b	0x89d0 <_stogir.terminal.inputs+0x428>
    89b4:      	movz	x2, #0x0, lsl #48
    89b8:      	b	0x8900 <_stogir.terminal.inputs+0x358>
    89bc:      	movz	x2, #0x0, lsl #48
    89c0:      	b	0x88f8 <_stogir.terminal.inputs+0x350>
    89c4:      	movz	x2, #0x0, lsl #48
    89c8:      	b	0x89b8 <_stogir.terminal.inputs+0x410>
    89cc:      	movz	w0, #0x0, lsl #16
    89d0:      	uxtb	w16, w0
    89d4:      	and	w0, w16, #0x8
    89d8:      	uxtb	w0, w0
    89dc:      	ubfx	x0, x0, #0, #8
    89e0:      	cmp	x0, #0x0
    89e4:      	cset	w0, eq
    89e8:      	uxtb	w16, w0
    89ec:      	cmp	w16, wzr
    89f0:      	cset	x0, eq
    89f4:      	cmp	x0, #0x0
    89f8:      	b.eq	0x888c <_stogir.terminal.inputs+0x2e4>
    89fc:      	and	x0, x3, #0xffffffff
    8a00:      	movz	x1, #0x0, lsl #48
    8a04:      	movz	x2, #0x0, lsl #48
    8a08:      	b	0x88a0 <_stogir.terminal.inputs+0x2f8>
    8a0c:      	brk	#0
    8a10:      	b	0x8a0c <_stogir.terminal.inputs+0x464>

0000000000008a14 <_stogir.switch.switch-inputs>:
    8a14:      	sxtw	x1, w1
    8a18:      	cmp	x1, #0x0
    8a1c:      	cset	w3, gt
    8a20:      	movz	x16, #0x0, lsl #48
    8a24:      	sub	x4, x16, x1
    8a28:      	sub	x5, x4, #0x1
    8a2c:      	uxtb	w16, w3
    8a30:      	cmp	w16, wzr
    8a34:      	b.eq	0x8a74 <_stogir.switch.switch-inputs+0x60>
    8a38:      	ldr	x4, [x0, #0x8]
    8a3c:      	cmp	x1, x4
    8a40:      	b.ge	0x8adc <_stogir.switch.switch-inputs+0xc8>
    8a44:      	add	x4, x0, #0x78
    8a48:      	ldr	x4, [x4, #0x8]
    8a4c:      	cmp	x1, x4
    8a50:      	b.ge	0x8bb4 <_stogir.switch.switch-inputs+0x1a0>
    8a54:      	ldr	x4, [x0, #0x78]
    8a58:      	add	x4, x4, x1, lsl #2
    8a5c:      	ldr	w4, [x4]
    8a60:      	sxtw	x4, w4
    8a64:      	cmp	x4, #0x0
    8a68:      	cset	w4, ge
    8a6c:      	ubfx	x4, x4, #0, #8
    8a70:      	b	0x8bb8 <_stogir.switch.switch-inputs+0x1a4>
    8a74:      	cmp	x1, #0x0
    8a78:      	b.ge	0x8ae4 <_stogir.switch.switch-inputs+0xd0>
    8a7c:      	add	x6, x0, #0x28
    8a80:      	add	x7, x0, #0x50
    8a84:      	ldr	x6, [x6, #0x8]
    8a88:      	ldr	x7, [x7, #0x8]
    8a8c:      	cmp	x6, x7
    8a90:      	b.ne	0x8abc <_stogir.switch.switch-inputs+0xa8>
    8a94:      	cmp	x4, x6
    8a98:      	b.gt	0x8bbc <_stogir.switch.switch-inputs+0x1a8>
    8a9c:      	ldr	x4, [x0, #0x50]
    8aa0:      	add	x4, x4, x5, lsl #2
    8aa4:      	ldr	w4, [x4]
    8aa8:      	sxtw	x4, w4
    8aac:      	cmp	x4, #0x0
    8ab0:      	cset	w4, gt
    8ab4:      	ubfx	x4, x4, #0, #8
    8ab8:      	b	0x8bc0 <_stogir.switch.switch-inputs+0x1ac>
    8abc:      	movz	x4, #0x0, lsl #48
    8ac0:      	b	0x8ae8 <_stogir.switch.switch-inputs+0xd4>
    8ac4:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008ac4:  ARM64_RELOC_PAGE21	l_stogir.435
    8ac8:      	ldr	x16, [x16]
		0000000000008ac8:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    8acc:      	orr	x0, x16, xzr
    8ad0:      	mov	x1, #0x1                ; =1
    8ad4:      	mov	x2, #0x16               ; =22
    8ad8:      	b	0x8b6c <_stogir.switch.switch-inputs+0x158>
    8adc:      	movz	x4, #0x0, lsl #48
    8ae0:      	b	0x8ae8 <_stogir.switch.switch-inputs+0xd4>
    8ae4:      	movz	x4, #0x0, lsl #48
    8ae8:      	cmp	x4, #0x0
    8aec:      	b.eq	0x8b20 <_stogir.switch.switch-inputs+0x10c>
    8af0:      	uxtb	w16, w3
    8af4:      	cmp	w16, wzr
    8af8:      	b.eq	0x8b0c <_stogir.switch.switch-inputs+0xf8>
    8afc:      	ldr	x3, [x0]
    8b00:      	add	x3, x3, x1, lsl #4
    8b04:      	ldr	x3, [x3]
    8b08:      	b	0x8b18 <_stogir.switch.switch-inputs+0x104>
    8b0c:      	ldr	x3, [x0, #0x28]
    8b10:      	add	x3, x3, x5, lsl #4
    8b14:      	ldr	x3, [x3]
    8b18:      	mov	w4, #0x1                ; =1
    8b1c:      	b	0x8b28 <_stogir.switch.switch-inputs+0x114>
    8b20:      	movz	w4, #0x0, lsl #16
    8b24:      	movz	x3, #0x0, lsl #48
    8b28:      	ubfx	x4, x4, #0, #32
    8b2c:      	lsr	x16, x4, #0
    8b30:      	cmp	x16, #0x1
    8b34:      	b.eq	0x8b50 <_stogir.switch.switch-inputs+0x13c>
    8b38:      	b.lo	0x8b40 <_stogir.switch.switch-inputs+0x12c>
    8b3c:      	b	0x8b54 <_stogir.switch.switch-inputs+0x140>
    8b40:      	cmp	x16, #0x0
    8b44:      	b.eq	0x8b4c <_stogir.switch.switch-inputs+0x138>
    8b48:      	b	0x8b54 <_stogir.switch.switch-inputs+0x140>
    8b4c:      	b	0x8b58 <_stogir.switch.switch-inputs+0x144>
    8b50:      	b	0x8b7c <_stogir.switch.switch-inputs+0x168>
    8b54:      	b	0x8dd0 <_stogir.switch.switch-inputs+0x3bc>
    8b58:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008b58:  ARM64_RELOC_PAGE21	l_stogir.436
    8b5c:      	ldr	x16, [x16]
		0000000000008b5c:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    8b60:      	orr	x0, x16, xzr
    8b64:      	mov	x1, #0x1                ; =1
    8b68:      	mov	x2, #0x16               ; =22
    8b6c:      	str	x1, [x8]
    8b70:      	str	x0, [x8, #0x8]
    8b74:      	str	x2, [x8, #0x10]
    8b78:      	ret
    8b7c:      	cmp	x1, #0x0
    8b80:      	b.le	0x8ac4 <_stogir.switch.switch-inputs+0xb0>
    8b84:      	uxtb	w3, w3
    8b88:      	cmp	x3, #0x83
    8b8c:      	cset	w1, lt
    8b90:      	uxtb	w16, w1
    8b94:      	cmp	w16, wzr
    8b98:      	b.eq	0x8bc4 <_stogir.switch.switch-inputs+0x1b0>
    8b9c:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008b9c:  ARM64_RELOC_PAGE21	l_stogir.437
    8ba0:      	ldr	x16, [x16]
		0000000000008ba0:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    8ba4:      	orr	x4, x16, xzr
    8ba8:      	add	x4, x3, x4
    8bac:      	ldrb	w4, [x4]
    8bb0:      	b	0x8bc8 <_stogir.switch.switch-inputs+0x1b4>
    8bb4:      	movz	x4, #0x0, lsl #48
    8bb8:      	b	0x8ae0 <_stogir.switch.switch-inputs+0xcc>
    8bbc:      	movz	x4, #0x0, lsl #48
    8bc0:      	b	0x8ac0 <_stogir.switch.switch-inputs+0xac>
    8bc4:      	movz	w4, #0x0, lsl #16
    8bc8:      	uxtb	w16, w4
    8bcc:      	and	w4, w16, #0x1
    8bd0:      	uxtb	w4, w4
    8bd4:      	ubfx	x4, x4, #0, #8
    8bd8:      	cmp	x4, #0x0
    8bdc:      	b.eq	0x8ac4 <_stogir.switch.switch-inputs+0xb0>
    8be0:      	uxtb	w16, w1
    8be4:      	cmp	w16, wzr
    8be8:      	b.eq	0x8c04 <_stogir.switch.switch-inputs+0x1f0>
    8bec:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008bec:  ARM64_RELOC_PAGE21	l_stogir.437
    8bf0:      	ldr	x16, [x16]
		0000000000008bf0:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    8bf4:      	orr	x1, x16, xzr
    8bf8:      	add	x1, x3, x1
    8bfc:      	ldrb	w1, [x1]
    8c00:      	b	0x8c08 <_stogir.switch.switch-inputs+0x1f4>
    8c04:      	movz	w1, #0x0, lsl #16
    8c08:      	uxtb	w16, w1
    8c0c:      	and	w1, w16, #0x4
    8c10:      	uxtb	w1, w1
    8c14:      	ubfx	x1, x1, #0, #8
    8c18:      	cmp	x1, #0x0
    8c1c:      	cset	w1, eq
    8c20:      	uxtb	w16, w1
    8c24:      	cmp	w16, wzr
    8c28:      	cset	x1, eq
    8c2c:      	cmp	x1, #0x0
    8c30:      	b.ne	0x8ac4 <_stogir.switch.switch-inputs+0xb0>
    8c34:      	sxtw	x2, w2
    8c38:      	cmp	x2, #0x0
    8c3c:      	cset	w1, gt
    8c40:      	movz	x16, #0x0, lsl #48
    8c44:      	sub	x3, x16, x2
    8c48:      	sub	x4, x3, #0x1
    8c4c:      	uxtb	w16, w1
    8c50:      	cmp	w16, wzr
    8c54:      	b.eq	0x8cac <_stogir.switch.switch-inputs+0x298>
    8c58:      	ldr	x3, [x0, #0x8]
    8c5c:      	cmp	x2, x3
    8c60:      	b.ge	0x8cf4 <_stogir.switch.switch-inputs+0x2e0>
    8c64:      	add	x3, x0, #0x78
    8c68:      	ldr	x3, [x3, #0x8]
    8c6c:      	cmp	x2, x3
    8c70:      	b.ge	0x8dc8 <_stogir.switch.switch-inputs+0x3b4>
    8c74:      	ldr	x3, [x0, #0x78]
    8c78:      	add	x3, x3, x2, lsl #2
    8c7c:      	ldr	w3, [x3]
    8c80:      	sxtw	x3, w3
    8c84:      	cmp	x3, #0x0
    8c88:      	cset	w3, ge
    8c8c:      	ubfx	x3, x3, #0, #8
    8c90:      	b	0x8dcc <_stogir.switch.switch-inputs+0x3b8>
    8c94:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008c94:  ARM64_RELOC_PAGE21	l_stogir.438
    8c98:      	ldr	x16, [x16]
		0000000000008c98:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    8c9c:      	orr	x0, x16, xzr
    8ca0:      	mov	x1, #0x1                ; =1
    8ca4:      	mov	x2, #0x20               ; =32
    8ca8:      	b	0x8ad8 <_stogir.switch.switch-inputs+0xc4>
    8cac:      	cmp	x2, #0x0
    8cb0:      	b.ge	0x8cfc <_stogir.switch.switch-inputs+0x2e8>
    8cb4:      	add	x5, x0, #0x28
    8cb8:      	add	x6, x0, #0x50
    8cbc:      	ldr	x5, [x5, #0x8]
    8cc0:      	ldr	x6, [x6, #0x8]
    8cc4:      	cmp	x5, x6
    8cc8:      	b.ne	0x8dc0 <_stogir.switch.switch-inputs+0x3ac>
    8ccc:      	cmp	x3, x5
    8cd0:      	b.gt	0x8dd8 <_stogir.switch.switch-inputs+0x3c4>
    8cd4:      	ldr	x3, [x0, #0x50]
    8cd8:      	add	x3, x3, x4, lsl #2
    8cdc:      	ldr	w3, [x3]
    8ce0:      	sxtw	x3, w3
    8ce4:      	cmp	x3, #0x0
    8ce8:      	cset	w3, gt
    8cec:      	ubfx	x3, x3, #0, #8
    8cf0:      	b	0x8ddc <_stogir.switch.switch-inputs+0x3c8>
    8cf4:      	movz	x3, #0x0, lsl #48
    8cf8:      	b	0x8d00 <_stogir.switch.switch-inputs+0x2ec>
    8cfc:      	movz	x3, #0x0, lsl #48
    8d00:      	cmp	x3, #0x0
    8d04:      	b.eq	0x8d38 <_stogir.switch.switch-inputs+0x324>
    8d08:      	uxtb	w16, w1
    8d0c:      	cmp	w16, wzr
    8d10:      	b.eq	0x8d24 <_stogir.switch.switch-inputs+0x310>
    8d14:      	ldr	x0, [x0]
    8d18:      	add	x0, x0, x2, lsl #4
    8d1c:      	ldr	x0, [x0]
    8d20:      	b	0x8d30 <_stogir.switch.switch-inputs+0x31c>
    8d24:      	ldr	x0, [x0, #0x28]
    8d28:      	add	x0, x0, x4, lsl #4
    8d2c:      	ldr	x0, [x0]
    8d30:      	mov	w1, #0x1                ; =1
    8d34:      	b	0x8d40 <_stogir.switch.switch-inputs+0x32c>
    8d38:      	movz	w1, #0x0, lsl #16
    8d3c:      	movz	x0, #0x0, lsl #48
    8d40:      	ubfx	x1, x1, #0, #32
    8d44:      	lsr	x16, x1, #0
    8d48:      	cmp	x16, #0x1
    8d4c:      	b.eq	0x8d68 <_stogir.switch.switch-inputs+0x354>
    8d50:      	b.lo	0x8d58 <_stogir.switch.switch-inputs+0x344>
    8d54:      	b	0x8d6c <_stogir.switch.switch-inputs+0x358>
    8d58:      	cmp	x16, #0x0
    8d5c:      	b.eq	0x8d64 <_stogir.switch.switch-inputs+0x350>
    8d60:      	b	0x8d6c <_stogir.switch.switch-inputs+0x358>
    8d64:      	b	0x8d70 <_stogir.switch.switch-inputs+0x35c>
    8d68:      	b	0x8d88 <_stogir.switch.switch-inputs+0x374>
    8d6c:      	b	0x8de0 <_stogir.switch.switch-inputs+0x3cc>
    8d70:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008d70:  ARM64_RELOC_PAGE21	l_stogir.439
    8d74:      	ldr	x16, [x16]
		0000000000008d74:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    8d78:      	orr	x0, x16, xzr
    8d7c:      	mov	x1, #0x1                ; =1
    8d80:      	mov	x2, #0x17               ; =23
    8d84:      	b	0x8ca8 <_stogir.switch.switch-inputs+0x294>
    8d88:      	orr	w1, w0, wzr
    8d8c:      	ubfx	x1, x1, #0, #32
    8d90:      	ubfx	x1, x1, #8, #8
    8d94:      	cmp	x1, #0x1
    8d98:      	b.lt	0x8c94 <_stogir.switch.switch-inputs+0x280>
    8d9c:      	cmp	x1, #0xb
    8da0:      	b.gt	0x8c94 <_stogir.switch.switch-inputs+0x280>
    8da4:      	uxtb	w0, w0
    8da8:      	cmp	x0, #0x48
    8dac:      	b.eq	0x8c94 <_stogir.switch.switch-inputs+0x280>
    8db0:      	and	x0, x1, #0xffffffff
    8db4:      	movz	x1, #0x0, lsl #48
    8db8:      	movz	x2, #0x0, lsl #48
    8dbc:      	b	0x8ca8 <_stogir.switch.switch-inputs+0x294>
    8dc0:      	movz	x3, #0x0, lsl #48
    8dc4:      	b	0x8d00 <_stogir.switch.switch-inputs+0x2ec>
    8dc8:      	movz	x3, #0x0, lsl #48
    8dcc:      	b	0x8cf8 <_stogir.switch.switch-inputs+0x2e4>
    8dd0:      	brk	#0
    8dd4:      	b	0x8dd0 <_stogir.switch.switch-inputs+0x3bc>
    8dd8:      	movz	x3, #0x0, lsl #48
    8ddc:      	b	0x8dc4 <_stogir.switch.switch-inputs+0x3b0>
    8de0:      	brk	#0
    8de4:      	b	0x8de0 <_stogir.switch.switch-inputs+0x3cc>

0000000000008de8 <_stogir.switch.case-inputs>:
    8de8:      	sub	sp, sp, #0xd0
    8dec:      	str	x29, [sp]
    8df0:      	str	x30, [sp, #0x8]
    8df4:      	mov	x29, sp
    8df8:      	str	x19, [sp, #0x80]
    8dfc:      	str	x20, [sp, #0x88]
    8e00:      	str	x21, [sp, #0x90]
    8e04:      	str	x22, [sp, #0x98]
    8e08:      	str	x23, [sp, #0xa0]
    8e0c:      	str	x24, [sp, #0xa8]
    8e10:      	str	x25, [sp, #0xb0]
    8e14:      	str	x26, [sp, #0xb8]
    8e18:      	str	x27, [sp, #0xc0]
    8e1c:      	sxtw	x2, w2
    8e20:      	lsl	x19, x2, #2
    8e24:      	cmp	x2, #0x0
    8e28:      	cset	w5, gt
    8e2c:      	movz	x16, #0x0, lsl #48
    8e30:      	sub	x6, x16, x2
    8e34:      	sub	x7, x6, #0x1
    8e38:      	uxtb	w16, w5
    8e3c:      	cmp	w16, wzr
    8e40:      	b.eq	0x8e80 <_stogir.switch.case-inputs+0x98>
    8e44:      	ldr	x6, [x0, #0x8]
    8e48:      	cmp	x2, x6
    8e4c:      	b.ge	0x8ed0 <_stogir.switch.case-inputs+0xe8>
    8e50:      	add	x6, x0, #0x78
    8e54:      	ldr	x6, [x6, #0x8]
    8e58:      	cmp	x2, x6
    8e5c:      	b.ge	0x8fe4 <_stogir.switch.case-inputs+0x1fc>
    8e60:      	ldr	x6, [x0, #0x78]
    8e64:      	add	x6, x19, x6
    8e68:      	ldr	w6, [x6]
    8e6c:      	sxtw	x6, w6
    8e70:      	cmp	x6, #0x0
    8e74:      	cset	w6, ge
    8e78:      	ubfx	x6, x6, #0, #8
    8e7c:      	b	0x8fe8 <_stogir.switch.case-inputs+0x200>
    8e80:      	cmp	x2, #0x0
    8e84:      	b.ge	0x8ed8 <_stogir.switch.case-inputs+0xf0>
    8e88:      	add	x9, x0, #0x28
    8e8c:      	add	x10, x0, #0x50
    8e90:      	ldr	x9, [x9, #0x8]
    8e94:      	ldr	x10, [x10, #0x8]
    8e98:      	cmp	x9, x10
    8e9c:      	b.ne	0x8ec8 <_stogir.switch.case-inputs+0xe0>
    8ea0:      	cmp	x6, x9
    8ea4:      	b.gt	0x90c8 <_stogir.switch.case-inputs+0x2e0>
    8ea8:      	ldr	x6, [x0, #0x50]
    8eac:      	add	x6, x6, x7, lsl #2
    8eb0:      	ldr	w6, [x6]
    8eb4:      	sxtw	x6, w6
    8eb8:      	cmp	x6, #0x0
    8ebc:      	cset	w6, gt
    8ec0:      	ubfx	x6, x6, #0, #8
    8ec4:      	b	0x90cc <_stogir.switch.case-inputs+0x2e4>
    8ec8:      	movz	x6, #0x0, lsl #48
    8ecc:      	b	0x8edc <_stogir.switch.case-inputs+0xf4>
    8ed0:      	movz	x6, #0x0, lsl #48
    8ed4:      	b	0x8edc <_stogir.switch.case-inputs+0xf4>
    8ed8:      	movz	x6, #0x0, lsl #48
    8edc:      	cmp	x6, #0x0
    8ee0:      	b.eq	0x8f1c <_stogir.switch.case-inputs+0x134>
    8ee4:      	uxtb	w16, w5
    8ee8:      	cmp	w16, wzr
    8eec:      	b.eq	0x8f04 <_stogir.switch.case-inputs+0x11c>
    8ef0:      	ldr	x5, [x0]
    8ef4:      	add	x5, x5, x2, lsl #4
    8ef8:      	ldr	x20, [x5]
    8efc:      	ldr	x21, [x5, #0x8]
    8f00:      	b	0x8f14 <_stogir.switch.case-inputs+0x12c>
    8f04:      	ldr	x5, [x0, #0x28]
    8f08:      	add	x5, x5, x7, lsl #4
    8f0c:      	ldr	x20, [x5]
    8f10:      	ldr	x21, [x5, #0x8]
    8f14:      	mov	w5, #0x1                ; =1
    8f18:      	b	0x8f28 <_stogir.switch.case-inputs+0x140>
    8f1c:      	movz	w5, #0x0, lsl #16
    8f20:      	movz	x20, #0x0, lsl #48
    8f24:      	movz	x21, #0x0, lsl #48
    8f28:      	ubfx	x5, x5, #0, #32
    8f2c:      	lsr	x16, x5, #0
    8f30:      	cmp	x16, #0x1
    8f34:      	b.eq	0x8f50 <_stogir.switch.case-inputs+0x168>
    8f38:      	b.lo	0x8f40 <_stogir.switch.case-inputs+0x158>
    8f3c:      	b	0x8f54 <_stogir.switch.case-inputs+0x16c>
    8f40:      	cmp	x16, #0x0
    8f44:      	b.eq	0x8f4c <_stogir.switch.case-inputs+0x164>
    8f48:      	b	0x8f54 <_stogir.switch.case-inputs+0x16c>
    8f4c:      	b	0x8f58 <_stogir.switch.case-inputs+0x170>
    8f50:      	b	0x8fb0 <_stogir.switch.case-inputs+0x1c8>
    8f54:      	b	0x90d0 <_stogir.switch.case-inputs+0x2e8>
    8f58:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008f58:  ARM64_RELOC_PAGE21	l_stogir.440
    8f5c:      	ldr	x16, [x16]
		0000000000008f5c:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    8f60:      	orr	x19, x16, xzr
    8f64:      	mov	x23, x8
    8f68:      	mov	x1, #0x1                ; =1
    8f6c:      	mov	x0, #0x1a               ; =26
    8f70:      	str	x1, [x23]
    8f74:      	str	x19, [x23, #0x8]
    8f78:      	str	x0, [x23, #0x10]
    8f7c:      	ldr	x19, [sp, #0x80]
    8f80:      	ldr	x20, [sp, #0x88]
    8f84:      	ldr	x21, [sp, #0x90]
    8f88:      	ldr	x22, [sp, #0x98]
    8f8c:      	ldr	x23, [sp, #0xa0]
    8f90:      	ldr	x24, [sp, #0xa8]
    8f94:      	ldr	x25, [sp, #0xb0]
    8f98:      	ldr	x26, [sp, #0xb8]
    8f9c:      	ldr	x27, [sp, #0xc0]
    8fa0:      	ldr	x29, [sp]
    8fa4:      	ldr	x30, [sp, #0x8]
    8fa8:      	add	sp, sp, #0xd0
    8fac:      	ret
    8fb0:      	add	x16, sp, #0x10
    8fb4:      	str	x20, [x16]
    8fb8:      	add	x16, sp, #0x10
    8fbc:      	str	x21, [x16, #0x8]
    8fc0:      	cmp	x2, #0x0
    8fc4:      	b.gt	0x8fec <_stogir.switch.case-inputs+0x204>
    8fc8:      	mov	x23, x8
    8fcc:      	adrp	x16, 0x8000 <_stogir.types.size+0x25c>
		0000000000008fcc:  ARM64_RELOC_PAGE21	l_stogir.441
    8fd0:      	ldr	x16, [x16]
		0000000000008fd0:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    8fd4:      	orr	x19, x16, xzr
    8fd8:      	mov	x1, #0x1                ; =1
    8fdc:      	mov	x0, #0x1f               ; =31
    8fe0:      	b	0x8f70 <_stogir.switch.case-inputs+0x188>
    8fe4:      	movz	x6, #0x0, lsl #48
    8fe8:      	b	0x8ed4 <_stogir.switch.case-inputs+0xec>
    8fec:      	add	x16, sp, #0x10
    8ff0:      	orr	x22, x16, xzr
    8ff4:      	mov	x23, x8
    8ff8:      	mov	x24, x0
    8ffc:      	mov	x0, x22
    9000:      	mov	w25, w1
    9004:      	mov	w26, w3
    9008:      	mov	w27, w4
    900c:      	bl	0x900c <_stogir.switch.case-inputs+0x224>
		000000000000900c:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    9010:      	uxtb	w0, w0
    9014:      	cmp	x0, #0x75
    9018:      	b.ne	0x8fcc <_stogir.switch.case-inputs+0x1e4>
    901c:      	mov	x0, x22
    9020:      	bl	0x9020 <_stogir.switch.case-inputs+0x238>
		0000000000009020:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    9024:      	uxtb	w0, w0
    9028:      	cmp	x0, #0x0
    902c:      	b.ne	0x8fcc <_stogir.switch.case-inputs+0x1e4>
    9030:      	ldr	x0, [x24, #0x78]
    9034:      	add	x0, x19, x0
    9038:      	ldr	w0, [x0]
    903c:      	sxtw	x0, w0
    9040:      	cmp	x0, #0x2
    9044:      	b.ne	0x8fcc <_stogir.switch.case-inputs+0x1e4>
    9048:      	sxtw	x25, w25
    904c:      	cmp	x25, #0x6d
    9050:      	b.lt	0x8fcc <_stogir.switch.case-inputs+0x1e4>
    9054:      	cmp	x25, #0x6f
    9058:      	b.gt	0x8fcc <_stogir.switch.case-inputs+0x1e4>
    905c:      	add	x16, sp, #0x20
    9060:      	orr	x19, x16, xzr
    9064:      	lsr	x0, x20, #32
    9068:      	add	x8, sp, #0x20
    906c:      	mov	w1, w0
    9070:      	mov	x0, x24
    9074:      	mov	w2, w21
    9078:      	bl	0x9078 <_stogir.switch.case-inputs+0x290>
		0000000000009078:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    907c:      	add	x16, sp, #0x20
    9080:      	ldr	w0, [x16]
    9084:      	lsr	x16, x0, #0
    9088:      	cmp	x16, #0x1
    908c:      	b.eq	0x90a8 <_stogir.switch.case-inputs+0x2c0>
    9090:      	b.lo	0x9098 <_stogir.switch.case-inputs+0x2b0>
    9094:      	b	0x90ac <_stogir.switch.case-inputs+0x2c4>
    9098:      	cmp	x16, #0x0
    909c:      	b.eq	0x90a4 <_stogir.switch.case-inputs+0x2bc>
    90a0:      	b	0x90ac <_stogir.switch.case-inputs+0x2c4>
    90a4:      	b	0x90d8 <_stogir.switch.case-inputs+0x2f0>
    90a8:      	b	0x90b0 <_stogir.switch.case-inputs+0x2c8>
    90ac:      	b	0x9218 <_stogir.switch.case-inputs+0x430>
    90b0:      	add	x0, x19, #0x8
    90b4:      	add	x16, sp, #0x20
    90b8:      	ldr	x19, [x16, #0x8]
    90bc:      	ldr	x0, [x0, #0x8]
    90c0:      	mov	x1, #0x1                ; =1
    90c4:      	b	0x8fe0 <_stogir.switch.case-inputs+0x1f8>
    90c8:      	movz	x6, #0x0, lsl #48
    90cc:      	b	0x8ecc <_stogir.switch.case-inputs+0xe4>
    90d0:      	brk	#0
    90d4:      	b	0x90d0 <_stogir.switch.case-inputs+0x2e8>
    90d8:      	add	x16, sp, #0x20
    90dc:      	ldr	w20, [x16, #0x8]
    90e0:      	sxtw	x0, w20
    90e4:      	and	x19, x0, #0xffffffff
    90e8:      	cmp	x25, #0x6f
    90ec:      	b.ne	0x90fc <_stogir.switch.case-inputs+0x314>
    90f0:      	movz	x1, #0x0, lsl #48
    90f4:      	movz	x0, #0x0, lsl #48
    90f8:      	b	0x90c4 <_stogir.switch.case-inputs+0x2dc>
    90fc:      	orr	w21, w26, wzr
    9100:      	add	x16, sp, #0x40
    9104:      	orr	x22, x16, xzr
    9108:      	add	x8, sp, #0x40
    910c:      	mov	x0, x24
    9110:      	mov	w1, w21
    9114:      	mov	w2, w20
    9118:      	bl	0x9118 <_stogir.switch.case-inputs+0x330>
		0000000000009118:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    911c:      	add	x16, sp, #0x40
    9120:      	ldr	w0, [x16]
    9124:      	lsr	x16, x0, #0
    9128:      	cmp	x16, #0x1
    912c:      	b.eq	0x9148 <_stogir.switch.case-inputs+0x360>
    9130:      	b.lo	0x9138 <_stogir.switch.case-inputs+0x350>
    9134:      	b	0x914c <_stogir.switch.case-inputs+0x364>
    9138:      	cmp	x16, #0x0
    913c:      	b.eq	0x9144 <_stogir.switch.case-inputs+0x35c>
    9140:      	b	0x914c <_stogir.switch.case-inputs+0x364>
    9144:      	b	0x9168 <_stogir.switch.case-inputs+0x380>
    9148:      	b	0x9150 <_stogir.switch.case-inputs+0x368>
    914c:      	b	0x9220 <_stogir.switch.case-inputs+0x438>
    9150:      	add	x0, x22, #0x8
    9154:      	add	x16, sp, #0x40
    9158:      	ldr	x19, [x16, #0x8]
    915c:      	ldr	x0, [x0, #0x8]
    9160:      	mov	x1, #0x1                ; =1
    9164:      	b	0x90f8 <_stogir.switch.case-inputs+0x310>
    9168:      	add	x16, sp, #0x40
    916c:      	ldr	x22, [x16, #0x8]
    9170:      	cmp	x25, #0x6d
    9174:      	b.eq	0x917c <_stogir.switch.case-inputs+0x394>
    9178:      	orr	w21, w27, wzr
    917c:      	add	x16, sp, #0x60
    9180:      	orr	x25, x16, xzr
    9184:      	add	x8, sp, #0x60
    9188:      	mov	x0, x24
    918c:      	mov	w1, w21
    9190:      	mov	w2, w20
    9194:      	bl	0x9194 <_stogir.switch.case-inputs+0x3ac>
		0000000000009194:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    9198:      	add	x16, sp, #0x60
    919c:      	ldr	w0, [x16]
    91a0:      	lsr	x16, x0, #0
    91a4:      	cmp	x16, #0x1
    91a8:      	b.eq	0x91c4 <_stogir.switch.case-inputs+0x3dc>
    91ac:      	b.lo	0x91b4 <_stogir.switch.case-inputs+0x3cc>
    91b0:      	b	0x91c8 <_stogir.switch.case-inputs+0x3e0>
    91b4:      	cmp	x16, #0x0
    91b8:      	b.eq	0x91c0 <_stogir.switch.case-inputs+0x3d8>
    91bc:      	b	0x91c8 <_stogir.switch.case-inputs+0x3e0>
    91c0:      	b	0x91f0 <_stogir.switch.case-inputs+0x408>
    91c4:      	b	0x91cc <_stogir.switch.case-inputs+0x3e4>
    91c8:      	b	0x9228 <_stogir.switch.case-inputs+0x440>
    91cc:      	add	x0, x25, #0x8
    91d0:      	add	x16, sp, #0x60
    91d4:      	ldr	x19, [x16, #0x8]
    91d8:      	ldr	x0, [x0, #0x8]
    91dc:      	mov	x1, #0x1                ; =1
    91e0:      	b	0x91ec <_stogir.switch.case-inputs+0x404>
    91e4:      	movz	x1, #0x0, lsl #48
    91e8:      	movz	x0, #0x0, lsl #48
    91ec:      	b	0x9164 <_stogir.switch.case-inputs+0x37c>
    91f0:      	add	x16, sp, #0x60
    91f4:      	ldr	x0, [x16, #0x8]
    91f8:      	cmp	x22, x0
    91fc:      	b.ls	0x91e4 <_stogir.switch.case-inputs+0x3fc>
    9200:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009200:  ARM64_RELOC_PAGE21	l_stogir.442
    9204:      	ldr	x16, [x16]
		0000000000009204:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    9208:      	orr	x19, x16, xzr
    920c:      	mov	x1, #0x1                ; =1
    9210:      	mov	x0, #0x1a               ; =26
    9214:      	b	0x91ec <_stogir.switch.case-inputs+0x404>
    9218:      	brk	#0
    921c:      	b	0x9218 <_stogir.switch.case-inputs+0x430>
    9220:      	brk	#0
    9224:      	b	0x9220 <_stogir.switch.case-inputs+0x438>
    9228:      	brk	#0
    922c:      	b	0x9228 <_stogir.switch.case-inputs+0x440>

0000000000009230 <_stogir.stack.valid-frame-object-inputs?>:
    9230:      	sub	sp, sp, #0x20
    9234:      	str	x29, [sp]
    9238:      	str	x30, [sp, #0x8]
    923c:      	mov	x29, sp
    9240:      	str	x19, [sp, #0x10]
    9244:      	str	x20, [sp, #0x18]
    9248:      	mov	x19, x0
    924c:      	mov	w20, w2
    9250:      	bl	0x9250 <_stogir.stack.valid-frame-object-inputs?+0x20>
		0000000000009250:  ARM64_RELOC_BRANCH26	_stogir.stack.entry-allocation?
    9254:      	cmp	x0, #0x0
    9258:      	b.eq	0x92d4 <_stogir.stack.valid-frame-object-inputs?+0xa4>
    925c:      	sxtw	x20, w20
    9260:      	cmp	x20, #0x0
    9264:      	b.ge	0x92f4 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    9268:      	cmp	x20, #0x0
    926c:      	cset	w0, gt
    9270:      	movz	x16, #0x0, lsl #48
    9274:      	sub	x1, x16, x20
    9278:      	mov	x2, sp
    927c:      	sub	x3, x1, #0x1
    9280:      	mov	x4, sp
    9284:      	sub	sp, sp, #0x10
    9288:      	mov	x5, sp
    928c:      	uxtb	w16, w0
    9290:      	cmp	w16, wzr
    9294:      	b.eq	0x92fc <_stogir.stack.valid-frame-object-inputs?+0xcc>
    9298:      	ldr	x1, [x19, #0x8]
    929c:      	cmp	x20, x1
    92a0:      	b.ge	0x9354 <_stogir.stack.valid-frame-object-inputs?+0x124>
    92a4:      	add	x1, x19, #0x78
    92a8:      	ldr	x1, [x1, #0x8]
    92ac:      	cmp	x20, x1
    92b0:      	b.ge	0x94b0 <_stogir.stack.valid-frame-object-inputs?+0x280>
    92b4:      	ldr	x1, [x19, #0x78]
    92b8:      	add	x1, x1, x20, lsl #2
    92bc:      	ldr	w1, [x1]
    92c0:      	sxtw	x1, w1
    92c4:      	cmp	x1, #0x0
    92c8:      	cset	w1, ge
    92cc:      	ubfx	x1, x1, #0, #8
    92d0:      	b	0x94b4 <_stogir.stack.valid-frame-object-inputs?+0x284>
    92d4:      	movz	x0, #0x0, lsl #48
    92d8:      	sub	sp, x29, #0x0
    92dc:      	ldr	x19, [sp, #0x10]
    92e0:      	ldr	x20, [sp, #0x18]
    92e4:      	ldr	x29, [sp]
    92e8:      	ldr	x30, [sp, #0x8]
    92ec:      	add	sp, sp, #0x20
    92f0:      	ret
    92f4:      	movz	x0, #0x0, lsl #48
    92f8:      	b	0x92d8 <_stogir.stack.valid-frame-object-inputs?+0xa8>
    92fc:      	add	x6, x19, #0x28
    9300:      	add	x7, x19, #0x50
    9304:      	ldr	x6, [x6, #0x8]
    9308:      	ldr	x7, [x7, #0x8]
    930c:      	cmp	x6, x7
    9310:      	b.ne	0x935c <_stogir.stack.valid-frame-object-inputs?+0x12c>
    9314:      	cmp	x1, x6
    9318:      	b.gt	0x934c <_stogir.stack.valid-frame-object-inputs?+0x11c>
    931c:      	ldr	x1, [x19, #0x50]
    9320:      	add	x1, x1, x3, lsl #2
    9324:      	ldr	w1, [x1]
    9328:      	sxtw	x1, w1
    932c:      	cmp	x1, #0x0
    9330:      	cset	w1, gt
    9334:      	ubfx	x1, x1, #0, #8
    9338:      	b	0x9350 <_stogir.stack.valid-frame-object-inputs?+0x120>
    933c:      	cmp	x0, #0x0
    9340:      	cset	w0, gt
    9344:      	ubfx	x0, x0, #0, #8
    9348:      	b	0x92f8 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    934c:      	movz	x1, #0x0, lsl #48
    9350:      	b	0x9360 <_stogir.stack.valid-frame-object-inputs?+0x130>
    9354:      	movz	x1, #0x0, lsl #48
    9358:      	b	0x9360 <_stogir.stack.valid-frame-object-inputs?+0x130>
    935c:      	movz	x1, #0x0, lsl #48
    9360:      	cmp	x1, #0x0
    9364:      	b.eq	0x93a0 <_stogir.stack.valid-frame-object-inputs?+0x170>
    9368:      	uxtb	w16, w0
    936c:      	cmp	w16, wzr
    9370:      	b.eq	0x9388 <_stogir.stack.valid-frame-object-inputs?+0x158>
    9374:      	ldr	x0, [x19]
    9378:      	add	x0, x0, x20, lsl #4
    937c:      	ldr	x1, [x0]
    9380:      	ldr	x0, [x0, #0x8]
    9384:      	b	0x9398 <_stogir.stack.valid-frame-object-inputs?+0x168>
    9388:      	ldr	x0, [x19, #0x28]
    938c:      	add	x0, x0, x3, lsl #4
    9390:      	ldr	x1, [x0]
    9394:      	ldr	x0, [x0, #0x8]
    9398:      	mov	w3, #0x1                ; =1
    939c:      	b	0x93ac <_stogir.stack.valid-frame-object-inputs?+0x17c>
    93a0:      	movz	w3, #0x0, lsl #16
    93a4:      	movz	x1, #0x0, lsl #48
    93a8:      	movz	x0, #0x0, lsl #48
    93ac:      	ubfx	x3, x3, #0, #32
    93b0:      	lsr	x16, x3, #0
    93b4:      	cmp	x16, #0x1
    93b8:      	b.eq	0x93d4 <_stogir.stack.valid-frame-object-inputs?+0x1a4>
    93bc:      	b.lo	0x93c4 <_stogir.stack.valid-frame-object-inputs?+0x194>
    93c0:      	b	0x93d8 <_stogir.stack.valid-frame-object-inputs?+0x1a8>
    93c4:      	cmp	x16, #0x0
    93c8:      	b.eq	0x93d0 <_stogir.stack.valid-frame-object-inputs?+0x1a0>
    93cc:      	b	0x93d8 <_stogir.stack.valid-frame-object-inputs?+0x1a8>
    93d0:      	b	0x93dc <_stogir.stack.valid-frame-object-inputs?+0x1ac>
    93d4:      	b	0x948c <_stogir.stack.valid-frame-object-inputs?+0x25c>
    93d8:      	b	0x95c8 <_stogir.stack.valid-frame-object-inputs?+0x398>
    93dc:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		00000000000093dc:  ARM64_RELOC_PAGE21	l_stogir.443
    93e0:      	ldr	x16, [x16]
		00000000000093e0:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    93e4:      	orr	x0, x16, xzr
    93e8:      	mov	w1, #0x1                ; =1
    93ec:      	b	0x944c <_stogir.stack.valid-frame-object-inputs?+0x21c>
    93f0:      	mov	w1, #0x1                ; =1
    93f4:      	ldr	w3, [x5, #0x8]
    93f8:      	ldr	w6, [x5, #0xc]
    93fc:      	cmp	x20, #0x0
    9400:      	b.ge	0x943c <_stogir.stack.valid-frame-object-inputs?+0x20c>
    9404:      	cmp	x0, #0x1
    9408:      	b.lt	0x943c <_stogir.stack.valid-frame-object-inputs?+0x20c>
    940c:      	cmp	x0, #0xb
    9410:      	cset	w7, le
    9414:      	uxtb	w16, w7
    9418:      	cmp	w16, wzr
    941c:      	b.eq	0x943c <_stogir.stack.valid-frame-object-inputs?+0x20c>
    9420:      	ldr	w5, [x5]
    9424:      	uxtb	w8, w5
    9428:      	ubfx	x5, x5, #8, #8
    942c:      	cmp	x8, x5
    9430:      	b.eq	0x9538 <_stogir.stack.valid-frame-object-inputs?+0x308>
    9434:      	cmp	x8, #0x49
    9438:      	b.eq	0x9538 <_stogir.stack.valid-frame-object-inputs?+0x308>
    943c:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		000000000000943c:  ARM64_RELOC_PAGE21	l_stogir.444
    9440:      	ldr	x16, [x16]
		0000000000009440:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    9444:      	orr	x0, x16, xzr
    9448:      	mov	w1, #0x1                ; =1
    944c:      	mov	sp, x4
    9450:      	ubfx	x1, x1, #0, #32
    9454:      	mov	sp, x2
    9458:      	lsr	x16, x1, #0
    945c:      	cmp	x16, #0x1
    9460:      	b.eq	0x947c <_stogir.stack.valid-frame-object-inputs?+0x24c>
    9464:      	b.lo	0x946c <_stogir.stack.valid-frame-object-inputs?+0x23c>
    9468:      	b	0x9480 <_stogir.stack.valid-frame-object-inputs?+0x250>
    946c:      	cmp	x16, #0x0
    9470:      	b.eq	0x9478 <_stogir.stack.valid-frame-object-inputs?+0x248>
    9474:      	b	0x9480 <_stogir.stack.valid-frame-object-inputs?+0x250>
    9478:      	b	0x933c <_stogir.stack.valid-frame-object-inputs?+0x10c>
    947c:      	b	0x9484 <_stogir.stack.valid-frame-object-inputs?+0x254>
    9480:      	b	0x95d0 <_stogir.stack.valid-frame-object-inputs?+0x3a0>
    9484:      	movz	x0, #0x0, lsl #48
    9488:      	b	0x9348 <_stogir.stack.valid-frame-object-inputs?+0x118>
    948c:      	orr	w3, w1, wzr
    9490:      	str	x1, [x5]
    9494:      	ubfx	x3, x3, #0, #32
    9498:      	str	x0, [x5, #0x8]
    949c:      	ubfx	x0, x3, #8, #8
    94a0:      	cmp	x0, #0x0
    94a4:      	b.ne	0x94b8 <_stogir.stack.valid-frame-object-inputs?+0x288>
    94a8:      	movz	w1, #0x0, lsl #16
    94ac:      	b	0x93f4 <_stogir.stack.valid-frame-object-inputs?+0x1c4>
    94b0:      	movz	x1, #0x0, lsl #48
    94b4:      	b	0x9358 <_stogir.stack.valid-frame-object-inputs?+0x128>
    94b8:      	cmp	x0, #0x1
    94bc:      	b.eq	0x93f0 <_stogir.stack.valid-frame-object-inputs?+0x1c0>
    94c0:      	cmp	x0, #0x2
    94c4:      	b.eq	0x93f0 <_stogir.stack.valid-frame-object-inputs?+0x1c0>
    94c8:      	cmp	x0, #0x7
    94cc:      	b.eq	0x93f0 <_stogir.stack.valid-frame-object-inputs?+0x1c0>
    94d0:      	cmp	x0, #0x8
    94d4:      	b.eq	0x93f0 <_stogir.stack.valid-frame-object-inputs?+0x1c0>
    94d8:      	cmp	x0, #0x3
    94dc:      	b.eq	0x95c0 <_stogir.stack.valid-frame-object-inputs?+0x390>
    94e0:      	cmp	x0, #0x9
    94e4:      	b.eq	0x95c0 <_stogir.stack.valid-frame-object-inputs?+0x390>
    94e8:      	cmp	x0, #0x4
    94ec:      	b.eq	0x95d8 <_stogir.stack.valid-frame-object-inputs?+0x3a8>
    94f0:      	cmp	x0, #0xa
    94f4:      	b.eq	0x95d8 <_stogir.stack.valid-frame-object-inputs?+0x3a8>
    94f8:      	cmp	x0, #0xd
    94fc:      	b.eq	0x95d8 <_stogir.stack.valid-frame-object-inputs?+0x3a8>
    9500:      	cmp	x0, #0x5
    9504:      	b.eq	0x95e0 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    9508:      	cmp	x0, #0xb
    950c:      	b.eq	0x95e0 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    9510:      	cmp	x0, #0xc
    9514:      	b.eq	0x95e0 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    9518:      	cmp	x0, #0x6
    951c:      	cset	w1, eq
    9520:      	uxtb	w16, w1
    9524:      	cmp	w16, wzr
    9528:      	mov	w16, #0x8               ; =8
    952c:      	movn	w17, #0x0, lsl #16
    9530:      	csel	w1, w16, w17, ne
    9534:      	b	0x95e4 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    9538:      	sxtw	x5, w1
    953c:      	cmp	x5, #0x0
    9540:      	b.le	0x943c <_stogir.stack.valid-frame-object-inputs?+0x20c>
    9544:      	lsl	w1, w1, #3
    9548:      	ubfx	x3, x3, #0, #32
    954c:      	ubfx	x6, x6, #0, #32
    9550:      	lsl	x6, x6, #32
    9554:      	orr	x3, x6, x3
    9558:      	cmp	x5, #0x8
    955c:      	b.ge	0x9570 <_stogir.stack.valid-frame-object-inputs?+0x340>
    9560:      	sxtw	x5, w1
    9564:      	lsr	x5, x3, x5
    9568:      	cmp	x5, #0x0
    956c:      	b.ne	0x943c <_stogir.stack.valid-frame-object-inputs?+0x20c>
    9570:      	cmp	x0, #0x7
    9574:      	b.lt	0x95a0 <_stogir.stack.valid-frame-object-inputs?+0x370>
    9578:      	uxtb	w16, w7
    957c:      	cmp	w16, wzr
    9580:      	b.eq	0x95a0 <_stogir.stack.valid-frame-object-inputs?+0x370>
    9584:      	sub	w0, w1, #0x1
    9588:      	sxtw	x0, w0
    958c:      	mov	x16, #0x1               ; =1
    9590:      	lsl	x0, x16, x0
    9594:      	and	x0, x0, x3
    9598:      	cmp	x0, #0x0
    959c:      	b.ne	0x943c <_stogir.stack.valid-frame-object-inputs?+0x20c>
    95a0:      	mov	x17, #-0x10             ; =-16
    95a4:      	movk	x17, #0x7fff, lsl #48
    95a8:      	cmp	x3, x17
    95ac:      	b.hi	0x943c <_stogir.stack.valid-frame-object-inputs?+0x20c>
    95b0:      	add	x0, x3, #0xf
    95b4:      	and	x0, x0, #0xfffffffffffffff0
    95b8:      	movz	w1, #0x0, lsl #16
    95bc:      	b	0x944c <_stogir.stack.valid-frame-object-inputs?+0x21c>
    95c0:      	mov	w1, #0x2                ; =2
    95c4:      	b	0x93f4 <_stogir.stack.valid-frame-object-inputs?+0x1c4>
    95c8:      	brk	#0
    95cc:      	b	0x95c8 <_stogir.stack.valid-frame-object-inputs?+0x398>
    95d0:      	brk	#0
    95d4:      	b	0x95d0 <_stogir.stack.valid-frame-object-inputs?+0x3a0>
    95d8:      	mov	w1, #0x4                ; =4
    95dc:      	b	0x95c4 <_stogir.stack.valid-frame-object-inputs?+0x394>
    95e0:      	mov	w1, #0x8                ; =8
    95e4:      	b	0x95dc <_stogir.stack.valid-frame-object-inputs?+0x3ac>

00000000000095e8 <_stogir.stack.validate-scope-inputs>:
    95e8:      	sub	sp, sp, #0x60
    95ec:      	str	x29, [sp]
    95f0:      	str	x30, [sp, #0x8]
    95f4:      	mov	x29, sp
    95f8:      	str	x19, [sp, #0x30]
    95fc:      	str	x20, [sp, #0x38]
    9600:      	str	x21, [sp, #0x40]
    9604:      	str	x22, [sp, #0x48]
    9608:      	str	x23, [sp, #0x50]
    960c:      	sxtw	x1, w1
    9610:      	cmp	x1, #0x53
    9614:      	cset	w19, eq
    9618:      	uxtb	w16, w19
    961c:      	cmp	w16, wzr
    9620:      	b.ne	0x9674 <_stogir.stack.validate-scope-inputs+0x8c>
    9624:      	cmp	x1, #0x54
    9628:      	b.eq	0x9674 <_stogir.stack.validate-scope-inputs+0x8c>
    962c:      	mov	x21, x8
    9630:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009630:  ARM64_RELOC_PAGE21	l_stogir.445
    9634:      	ldr	x16, [x16]
		0000000000009634:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    9638:      	orr	x0, x16, xzr
    963c:      	mov	x1, #0x1                ; =1
    9640:      	mov	x2, #0x22               ; =34
    9644:      	str	x1, [x21]
    9648:      	str	x0, [x21, #0x8]
    964c:      	str	x2, [x21, #0x10]
    9650:      	ldr	x19, [sp, #0x30]
    9654:      	ldr	x20, [sp, #0x38]
    9658:      	ldr	x21, [sp, #0x40]
    965c:      	ldr	x22, [sp, #0x48]
    9660:      	ldr	x23, [sp, #0x50]
    9664:      	ldr	x29, [sp]
    9668:      	ldr	x30, [sp, #0x8]
    966c:      	add	sp, sp, #0x60
    9670:      	ret
    9674:      	uxtb	w16, w19
    9678:      	cmp	w16, wzr
    967c:      	mov	w16, #0x6               ; =6
    9680:      	movz	w17, #0x0, lsl #16
    9684:      	csel	w1, w16, w17, ne
    9688:      	sxtw	x2, w2
    968c:      	sxtw	x1, w1
    9690:      	cmp	x2, x1
    9694:      	b.ne	0x9a68 <_stogir.stack.validate-scope-inputs+0x480>
    9698:      	sxtw	x3, w3
    969c:      	cmp	x3, #0x0
    96a0:      	cset	w1, gt
    96a4:      	movz	x16, #0x0, lsl #48
    96a8:      	sub	x2, x16, x3
    96ac:      	sub	x5, x2, #0x1
    96b0:      	uxtb	w16, w1
    96b4:      	cmp	w16, wzr
    96b8:      	b.eq	0x979c <_stogir.stack.validate-scope-inputs+0x1b4>
    96bc:      	ldr	x2, [x0, #0x8]
    96c0:      	cmp	x3, x2
    96c4:      	b.ge	0x9794 <_stogir.stack.validate-scope-inputs+0x1ac>
    96c8:      	add	x2, x0, #0x78
    96cc:      	ldr	x2, [x2, #0x8]
    96d0:      	cmp	x3, x2
    96d4:      	b.ge	0x9820 <_stogir.stack.validate-scope-inputs+0x238>
    96d8:      	ldr	x2, [x0, #0x78]
    96dc:      	add	x2, x2, x3, lsl #2
    96e0:      	ldr	w2, [x2]
    96e4:      	sxtw	x2, w2
    96e8:      	cmp	x2, #0x0
    96ec:      	cset	w2, ge
    96f0:      	ubfx	x2, x2, #0, #8
    96f4:      	b	0x9824 <_stogir.stack.validate-scope-inputs+0x23c>
    96f8:      	movz	w5, #0x0, lsl #16
    96fc:      	movz	x2, #0x0, lsl #48
    9700:      	movz	x1, #0x0, lsl #48
    9704:      	ubfx	x5, x5, #0, #32
    9708:      	lsr	x16, x5, #0
    970c:      	cmp	x16, #0x1
    9710:      	b.eq	0x972c <_stogir.stack.validate-scope-inputs+0x144>
    9714:      	b.lo	0x971c <_stogir.stack.validate-scope-inputs+0x134>
    9718:      	b	0x9730 <_stogir.stack.validate-scope-inputs+0x148>
    971c:      	cmp	x16, #0x0
    9720:      	b.eq	0x9728 <_stogir.stack.validate-scope-inputs+0x140>
    9724:      	b	0x9730 <_stogir.stack.validate-scope-inputs+0x148>
    9728:      	b	0x9734 <_stogir.stack.validate-scope-inputs+0x14c>
    972c:      	b	0x97e4 <_stogir.stack.validate-scope-inputs+0x1fc>
    9730:      	b	0x9950 <_stogir.stack.validate-scope-inputs+0x368>
    9734:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009734:  ARM64_RELOC_PAGE21	l_stogir.446
    9738:      	ldr	x16, [x16]
		0000000000009738:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    973c:      	orr	x0, x16, xzr
    9740:      	mov	x21, x8
    9744:      	mov	x1, #0x1                ; =1
    9748:      	mov	x2, #0x1b               ; =27
    974c:      	b	0x9644 <_stogir.stack.validate-scope-inputs+0x5c>
    9750:      	ldr	x1, [x0, #0x28]
    9754:      	add	x1, x1, x5, lsl #4
    9758:      	ldr	x2, [x1]
    975c:      	ldr	x1, [x1, #0x8]
    9760:      	mov	w5, #0x1                ; =1
    9764:      	b	0x9704 <_stogir.stack.validate-scope-inputs+0x11c>
    9768:      	movz	x2, #0x0, lsl #48
    976c:      	cmp	x2, #0x0
    9770:      	b.eq	0x96f8 <_stogir.stack.validate-scope-inputs+0x110>
    9774:      	uxtb	w16, w1
    9778:      	cmp	w16, wzr
    977c:      	b.eq	0x9750 <_stogir.stack.validate-scope-inputs+0x168>
    9780:      	ldr	x1, [x0]
    9784:      	add	x1, x1, x3, lsl #4
    9788:      	ldr	x2, [x1]
    978c:      	ldr	x1, [x1, #0x8]
    9790:      	b	0x9760 <_stogir.stack.validate-scope-inputs+0x178>
    9794:      	movz	x2, #0x0, lsl #48
    9798:      	b	0x976c <_stogir.stack.validate-scope-inputs+0x184>
    979c:      	cmp	x3, #0x0
    97a0:      	b.ge	0x9768 <_stogir.stack.validate-scope-inputs+0x180>
    97a4:      	add	x6, x0, #0x28
    97a8:      	add	x7, x0, #0x50
    97ac:      	ldr	x6, [x6, #0x8]
    97b0:      	ldr	x7, [x7, #0x8]
    97b4:      	cmp	x6, x7
    97b8:      	b.ne	0x9818 <_stogir.stack.validate-scope-inputs+0x230>
    97bc:      	cmp	x2, x6
    97c0:      	b.gt	0x9888 <_stogir.stack.validate-scope-inputs+0x2a0>
    97c4:      	ldr	x2, [x0, #0x50]
    97c8:      	add	x2, x2, x5, lsl #2
    97cc:      	ldr	w2, [x2]
    97d0:      	sxtw	x2, w2
    97d4:      	cmp	x2, #0x0
    97d8:      	cset	w2, gt
    97dc:      	ubfx	x2, x2, #0, #8
    97e0:      	b	0x988c <_stogir.stack.validate-scope-inputs+0x2a4>
    97e4:      	add	x16, sp, #0x10
    97e8:      	str	x2, [x16]
    97ec:      	add	x16, sp, #0x10
    97f0:      	str	x1, [x16, #0x8]
    97f4:      	cmp	x3, #0x0
    97f8:      	b.gt	0x9828 <_stogir.stack.validate-scope-inputs+0x240>
    97fc:      	mov	x21, x8
    9800:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009800:  ARM64_RELOC_PAGE21	l_stogir.447
    9804:      	ldr	x16, [x16]
		0000000000009804:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    9808:      	orr	x0, x16, xzr
    980c:      	mov	x1, #0x1                ; =1
    9810:      	mov	x2, #0x1b               ; =27
    9814:      	b	0x974c <_stogir.stack.validate-scope-inputs+0x164>
    9818:      	movz	x2, #0x0, lsl #48
    981c:      	b	0x976c <_stogir.stack.validate-scope-inputs+0x184>
    9820:      	movz	x2, #0x0, lsl #48
    9824:      	b	0x9798 <_stogir.stack.validate-scope-inputs+0x1b0>
    9828:      	add	x16, sp, #0x10
    982c:      	orr	x20, x16, xzr
    9830:      	mov	x21, x8
    9834:      	mov	x22, x0
    9838:      	mov	x0, x20
    983c:      	mov	w23, w4
    9840:      	bl	0x9840 <_stogir.stack.validate-scope-inputs+0x258>
		0000000000009840:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    9844:      	uxtb	w0, w0
    9848:      	bl	0x9848 <_stogir.stack.validate-scope-inputs+0x260>
		0000000000009848:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    984c:      	cmp	x0, #0x0
    9850:      	b.eq	0x9800 <_stogir.stack.validate-scope-inputs+0x218>
    9854:      	mov	x0, x20
    9858:      	bl	0x9858 <_stogir.stack.validate-scope-inputs+0x270>
		0000000000009858:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    985c:      	uxtb	w0, w0
    9860:      	bl	0x9860 <_stogir.stack.validate-scope-inputs+0x278>
		0000000000009860:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    9864:      	cmp	x0, #0x0
    9868:      	b.ne	0x9800 <_stogir.stack.validate-scope-inputs+0x218>
    986c:      	uxtb	w16, w19
    9870:      	cmp	w16, wzr
    9874:      	b.eq	0x9890 <_stogir.stack.validate-scope-inputs+0x2a8>
    9878:      	movz	x1, #0x0, lsl #48
    987c:      	mov	x0, #0x8                ; =8
    9880:      	movz	x2, #0x0, lsl #48
    9884:      	b	0x9814 <_stogir.stack.validate-scope-inputs+0x22c>
    9888:      	movz	x2, #0x0, lsl #48
    988c:      	b	0x981c <_stogir.stack.validate-scope-inputs+0x234>
    9890:      	sxtw	x23, w23
    9894:      	cmp	x23, #0x0
    9898:      	cset	w0, gt
    989c:      	movz	x16, #0x0, lsl #48
    98a0:      	sub	x1, x16, x23
    98a4:      	sub	x2, x1, #0x1
    98a8:      	uxtb	w16, w0
    98ac:      	cmp	w16, wzr
    98b0:      	b.eq	0x9908 <_stogir.stack.validate-scope-inputs+0x320>
    98b4:      	ldr	x1, [x22, #0x8]
    98b8:      	cmp	x23, x1
    98bc:      	b.ge	0x9958 <_stogir.stack.validate-scope-inputs+0x370>
    98c0:      	add	x1, x22, #0x78
    98c4:      	ldr	x1, [x1, #0x8]
    98c8:      	cmp	x23, x1
    98cc:      	b.ge	0x9a50 <_stogir.stack.validate-scope-inputs+0x468>
    98d0:      	ldr	x1, [x22, #0x78]
    98d4:      	add	x1, x1, x23, lsl #2
    98d8:      	ldr	w1, [x1]
    98dc:      	sxtw	x1, w1
    98e0:      	cmp	x1, #0x0
    98e4:      	cset	w1, ge
    98e8:      	ubfx	x1, x1, #0, #8
    98ec:      	b	0x9a54 <_stogir.stack.validate-scope-inputs+0x46c>
    98f0:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		00000000000098f0:  ARM64_RELOC_PAGE21	l_stogir.448
    98f4:      	ldr	x16, [x16]
		00000000000098f4:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    98f8:      	orr	x0, x16, xzr
    98fc:      	mov	x1, #0x1                ; =1
    9900:      	mov	x2, #0x29               ; =41
    9904:      	b	0x9884 <_stogir.stack.validate-scope-inputs+0x29c>
    9908:      	cmp	x23, #0x0
    990c:      	b.ge	0x9960 <_stogir.stack.validate-scope-inputs+0x378>
    9910:      	add	x3, x22, #0x28
    9914:      	add	x4, x22, #0x50
    9918:      	ldr	x3, [x3, #0x8]
    991c:      	ldr	x4, [x4, #0x8]
    9920:      	cmp	x3, x4
    9924:      	b.ne	0x9a48 <_stogir.stack.validate-scope-inputs+0x460>
    9928:      	cmp	x1, x3
    992c:      	b.gt	0x9a58 <_stogir.stack.validate-scope-inputs+0x470>
    9930:      	ldr	x1, [x22, #0x50]
    9934:      	add	x1, x1, x2, lsl #2
    9938:      	ldr	w1, [x1]
    993c:      	sxtw	x1, w1
    9940:      	cmp	x1, #0x0
    9944:      	cset	w1, gt
    9948:      	ubfx	x1, x1, #0, #8
    994c:      	b	0x9a5c <_stogir.stack.validate-scope-inputs+0x474>
    9950:      	brk	#0
    9954:      	b	0x9950 <_stogir.stack.validate-scope-inputs+0x368>
    9958:      	movz	x1, #0x0, lsl #48
    995c:      	b	0x9964 <_stogir.stack.validate-scope-inputs+0x37c>
    9960:      	movz	x1, #0x0, lsl #48
    9964:      	cmp	x1, #0x0
    9968:      	b.eq	0x99a4 <_stogir.stack.validate-scope-inputs+0x3bc>
    996c:      	uxtb	w16, w0
    9970:      	cmp	w16, wzr
    9974:      	b.eq	0x998c <_stogir.stack.validate-scope-inputs+0x3a4>
    9978:      	ldr	x0, [x22]
    997c:      	add	x0, x0, x23, lsl #4
    9980:      	ldr	x1, [x0]
    9984:      	ldr	x0, [x0, #0x8]
    9988:      	b	0x999c <_stogir.stack.validate-scope-inputs+0x3b4>
    998c:      	ldr	x0, [x22, #0x28]
    9990:      	add	x0, x0, x2, lsl #4
    9994:      	ldr	x1, [x0]
    9998:      	ldr	x0, [x0, #0x8]
    999c:      	mov	w2, #0x1                ; =1
    99a0:      	b	0x99b0 <_stogir.stack.validate-scope-inputs+0x3c8>
    99a4:      	movz	w2, #0x0, lsl #16
    99a8:      	movz	x1, #0x0, lsl #48
    99ac:      	movz	x0, #0x0, lsl #48
    99b0:      	ubfx	x2, x2, #0, #32
    99b4:      	lsr	x16, x2, #0
    99b8:      	cmp	x16, #0x1
    99bc:      	b.eq	0x99d8 <_stogir.stack.validate-scope-inputs+0x3f0>
    99c0:      	b.lo	0x99c8 <_stogir.stack.validate-scope-inputs+0x3e0>
    99c4:      	b	0x99dc <_stogir.stack.validate-scope-inputs+0x3f4>
    99c8:      	cmp	x16, #0x0
    99cc:      	b.eq	0x99d4 <_stogir.stack.validate-scope-inputs+0x3ec>
    99d0:      	b	0x99dc <_stogir.stack.validate-scope-inputs+0x3f4>
    99d4:      	b	0x99e0 <_stogir.stack.validate-scope-inputs+0x3f8>
    99d8:      	b	0x99f8 <_stogir.stack.validate-scope-inputs+0x410>
    99dc:      	b	0x9a60 <_stogir.stack.validate-scope-inputs+0x478>
    99e0:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		00000000000099e0:  ARM64_RELOC_PAGE21	l_stogir.449
    99e4:      	ldr	x16, [x16]
		00000000000099e4:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    99e8:      	orr	x0, x16, xzr
    99ec:      	mov	x1, #0x1                ; =1
    99f0:      	mov	x2, #0x1b               ; =27
    99f4:      	b	0x9904 <_stogir.stack.validate-scope-inputs+0x31c>
    99f8:      	add	x16, sp, #0x20
    99fc:      	orr	x19, x16, xzr
    9a00:      	add	x16, sp, #0x20
    9a04:      	str	x1, [x16]
    9a08:      	add	x16, sp, #0x20
    9a0c:      	str	x0, [x16, #0x8]
    9a10:      	mov	x0, x19
    9a14:      	bl	0x9a14 <_stogir.stack.validate-scope-inputs+0x42c>
		0000000000009a14:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    9a18:      	uxtb	w0, w0
    9a1c:      	cmp	x0, #0x6
    9a20:      	b.ne	0x98f0 <_stogir.stack.validate-scope-inputs+0x308>
    9a24:      	mov	x0, x19
    9a28:      	bl	0x9a28 <_stogir.stack.validate-scope-inputs+0x440>
		0000000000009a28:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    9a2c:      	uxtb	w0, w0
    9a30:      	cmp	x0, #0x48
    9a34:      	b.eq	0x98f0 <_stogir.stack.validate-scope-inputs+0x308>
    9a38:      	movz	x1, #0x0, lsl #48
    9a3c:      	mov	x0, #0x8                ; =8
    9a40:      	movz	x2, #0x0, lsl #48
    9a44:      	b	0x9904 <_stogir.stack.validate-scope-inputs+0x31c>
    9a48:      	movz	x1, #0x0, lsl #48
    9a4c:      	b	0x9964 <_stogir.stack.validate-scope-inputs+0x37c>
    9a50:      	movz	x1, #0x0, lsl #48
    9a54:      	b	0x995c <_stogir.stack.validate-scope-inputs+0x374>
    9a58:      	movz	x1, #0x0, lsl #48
    9a5c:      	b	0x9a4c <_stogir.stack.validate-scope-inputs+0x464>
    9a60:      	brk	#0
    9a64:      	b	0x9a60 <_stogir.stack.validate-scope-inputs+0x478>
    9a68:      	mov	x21, x8
    9a6c:      	b	0x9630 <_stogir.stack.validate-scope-inputs+0x48>

0000000000009a70 <_stogir.stack.validate-inputs>:
    9a70:      	sub	sp, sp, #0x90
    9a74:      	str	x29, [sp]
    9a78:      	str	x30, [sp, #0x8]
    9a7c:      	mov	x29, sp
    9a80:      	str	x19, [sp, #0x50]
    9a84:      	str	x20, [sp, #0x58]
    9a88:      	str	x21, [sp, #0x60]
    9a8c:      	str	x22, [sp, #0x68]
    9a90:      	str	x23, [sp, #0x70]
    9a94:      	str	x24, [sp, #0x78]
    9a98:      	str	x25, [sp, #0x80]
    9a9c:      	sxtw	x1, w1
    9aa0:      	cmp	x1, #0x51
    9aa4:      	cset	w19, eq
    9aa8:      	uxtb	w16, w19
    9aac:      	cmp	w16, wzr
    9ab0:      	b.ne	0x9b0c <_stogir.stack.validate-inputs+0x9c>
    9ab4:      	cmp	x1, #0x52
    9ab8:      	b.eq	0x9b0c <_stogir.stack.validate-inputs+0x9c>
    9abc:      	mov	x21, x8
    9ac0:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009ac0:  ARM64_RELOC_PAGE21	l_stogir.450
    9ac4:      	ldr	x16, [x16]
		0000000000009ac4:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    9ac8:      	orr	x0, x16, xzr
    9acc:      	mov	x2, #0x1                ; =1
    9ad0:      	mov	x1, #0x29               ; =41
    9ad4:      	str	x2, [x21]
    9ad8:      	str	x0, [x21, #0x8]
    9adc:      	str	x1, [x21, #0x10]
    9ae0:      	ldr	x19, [sp, #0x50]
    9ae4:      	ldr	x20, [sp, #0x58]
    9ae8:      	ldr	x21, [sp, #0x60]
    9aec:      	ldr	x22, [sp, #0x68]
    9af0:      	ldr	x23, [sp, #0x70]
    9af4:      	ldr	x24, [sp, #0x78]
    9af8:      	ldr	x25, [sp, #0x80]
    9afc:      	ldr	x29, [sp]
    9b00:      	ldr	x30, [sp, #0x8]
    9b04:      	add	sp, sp, #0x90
    9b08:      	ret
    9b0c:      	uxtb	w16, w19
    9b10:      	cmp	w16, wzr
    9b14:      	mov	w16, #0x6               ; =6
    9b18:      	movz	w17, #0x0, lsl #16
    9b1c:      	csel	w1, w16, w17, ne
    9b20:      	sxtw	x2, w2
    9b24:      	sxtw	x1, w1
    9b28:      	cmp	x2, x1
    9b2c:      	b.ne	0xa000 <_stogir.stack.validate-inputs+0x590>
    9b30:      	sxtw	x20, w5
    9b34:      	uxtb	w16, w19
    9b38:      	cmp	w16, wzr
    9b3c:      	b.eq	0xa008 <_stogir.stack.validate-inputs+0x598>
    9b40:      	cmp	x20, #0x0
    9b44:      	b.ne	0x9d70 <_stogir.stack.validate-inputs+0x300>
    9b48:      	mov	x21, x8
    9b4c:      	mov	x22, x0
    9b50:      	mov	w23, w3
    9b54:      	mov	w24, w4
    9b58:      	sxtw	x23, w23
    9b5c:      	cmp	x23, #0x0
    9b60:      	cset	w0, gt
    9b64:      	movz	x16, #0x0, lsl #48
    9b68:      	sub	x1, x16, x23
    9b6c:      	sub	x2, x1, #0x1
    9b70:      	uxtb	w16, w0
    9b74:      	cmp	w16, wzr
    9b78:      	b.eq	0x9c58 <_stogir.stack.validate-inputs+0x1e8>
    9b7c:      	ldr	x1, [x22, #0x8]
    9b80:      	cmp	x23, x1
    9b84:      	b.ge	0x9c50 <_stogir.stack.validate-inputs+0x1e0>
    9b88:      	add	x1, x22, #0x78
    9b8c:      	ldr	x1, [x1, #0x8]
    9b90:      	cmp	x23, x1
    9b94:      	b.ge	0x9d9c <_stogir.stack.validate-inputs+0x32c>
    9b98:      	ldr	x1, [x22, #0x78]
    9b9c:      	add	x1, x1, x23, lsl #2
    9ba0:      	ldr	w1, [x1]
    9ba4:      	sxtw	x1, w1
    9ba8:      	cmp	x1, #0x0
    9bac:      	cset	w1, ge
    9bb0:      	ubfx	x1, x1, #0, #8
    9bb4:      	b	0x9da0 <_stogir.stack.validate-inputs+0x330>
    9bb8:      	movz	w2, #0x0, lsl #16
    9bbc:      	movz	x1, #0x0, lsl #48
    9bc0:      	movz	x0, #0x0, lsl #48
    9bc4:      	ubfx	x2, x2, #0, #32
    9bc8:      	lsr	x16, x2, #0
    9bcc:      	cmp	x16, #0x1
    9bd0:      	b.eq	0x9bec <_stogir.stack.validate-inputs+0x17c>
    9bd4:      	b.lo	0x9bdc <_stogir.stack.validate-inputs+0x16c>
    9bd8:      	b	0x9bf0 <_stogir.stack.validate-inputs+0x180>
    9bdc:      	cmp	x16, #0x0
    9be0:      	b.eq	0x9be8 <_stogir.stack.validate-inputs+0x178>
    9be4:      	b	0x9bf0 <_stogir.stack.validate-inputs+0x180>
    9be8:      	b	0x9bf4 <_stogir.stack.validate-inputs+0x184>
    9bec:      	b	0x9ca0 <_stogir.stack.validate-inputs+0x230>
    9bf0:      	b	0x9f90 <_stogir.stack.validate-inputs+0x520>
    9bf4:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009bf4:  ARM64_RELOC_PAGE21	l_stogir.451
    9bf8:      	ldr	x16, [x16]
		0000000000009bf8:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    9bfc:      	orr	x0, x16, xzr
    9c00:      	mov	x2, #0x1                ; =1
    9c04:      	mov	x1, #0x1f               ; =31
    9c08:      	b	0x9ad4 <_stogir.stack.validate-inputs+0x64>
    9c0c:      	ldr	x0, [x22, #0x28]
    9c10:      	add	x0, x0, x2, lsl #4
    9c14:      	ldr	x1, [x0]
    9c18:      	ldr	x0, [x0, #0x8]
    9c1c:      	mov	w2, #0x1                ; =1
    9c20:      	b	0x9bc4 <_stogir.stack.validate-inputs+0x154>
    9c24:      	movz	x1, #0x0, lsl #48
    9c28:      	cmp	x1, #0x0
    9c2c:      	b.eq	0x9bb8 <_stogir.stack.validate-inputs+0x148>
    9c30:      	uxtb	w16, w0
    9c34:      	cmp	w16, wzr
    9c38:      	b.eq	0x9c0c <_stogir.stack.validate-inputs+0x19c>
    9c3c:      	ldr	x0, [x22]
    9c40:      	add	x0, x0, x23, lsl #4
    9c44:      	ldr	x1, [x0]
    9c48:      	ldr	x0, [x0, #0x8]
    9c4c:      	b	0x9c1c <_stogir.stack.validate-inputs+0x1ac>
    9c50:      	movz	x1, #0x0, lsl #48
    9c54:      	b	0x9c28 <_stogir.stack.validate-inputs+0x1b8>
    9c58:      	cmp	x23, #0x0
    9c5c:      	b.ge	0x9c24 <_stogir.stack.validate-inputs+0x1b4>
    9c60:      	add	x3, x22, #0x28
    9c64:      	add	x4, x22, #0x50
    9c68:      	ldr	x3, [x3, #0x8]
    9c6c:      	ldr	x4, [x4, #0x8]
    9c70:      	cmp	x3, x4
    9c74:      	b.ne	0x9d94 <_stogir.stack.validate-inputs+0x324>
    9c78:      	cmp	x1, x3
    9c7c:      	b.gt	0x9da4 <_stogir.stack.validate-inputs+0x334>
    9c80:      	ldr	x1, [x22, #0x50]
    9c84:      	add	x1, x1, x2, lsl #2
    9c88:      	ldr	w1, [x1]
    9c8c:      	sxtw	x1, w1
    9c90:      	cmp	x1, #0x0
    9c94:      	cset	w1, gt
    9c98:      	ubfx	x1, x1, #0, #8
    9c9c:      	b	0x9da8 <_stogir.stack.validate-inputs+0x338>
    9ca0:      	add	x16, sp, #0x10
    9ca4:      	str	x1, [x16]
    9ca8:      	add	x16, sp, #0x10
    9cac:      	str	x0, [x16, #0x8]
    9cb0:      	cmp	x23, #0x0
    9cb4:      	b.le	0x9d58 <_stogir.stack.validate-inputs+0x2e8>
    9cb8:      	add	x16, sp, #0x10
    9cbc:      	orr	x23, x16, xzr
    9cc0:      	mov	x0, x23
    9cc4:      	bl	0x9cc4 <_stogir.stack.validate-inputs+0x254>
		0000000000009cc4:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    9cc8:      	uxtb	w0, w0
    9ccc:      	bl	0x9ccc <_stogir.stack.validate-inputs+0x25c>
		0000000000009ccc:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    9cd0:      	cmp	x0, #0x0
    9cd4:      	b.eq	0x9d58 <_stogir.stack.validate-inputs+0x2e8>
    9cd8:      	mov	x0, x23
    9cdc:      	bl	0x9cdc <_stogir.stack.validate-inputs+0x26c>
		0000000000009cdc:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    9ce0:      	uxtb	w0, w0
    9ce4:      	bl	0x9ce4 <_stogir.stack.validate-inputs+0x274>
		0000000000009ce4:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    9ce8:      	cmp	x0, #0x0
    9cec:      	b.ne	0x9d58 <_stogir.stack.validate-inputs+0x2e8>
    9cf0:      	sxtw	x0, w24
    9cf4:      	cmp	x0, #0x0
    9cf8:      	cset	w23, lt
    9cfc:      	cmp	x0, #0x0
    9d00:      	cset	w1, gt
    9d04:      	movz	x16, #0x0, lsl #48
    9d08:      	sub	x2, x16, x0
    9d0c:      	sub	x3, x2, #0x1
    9d10:      	uxtb	w16, w1
    9d14:      	cmp	w16, wzr
    9d18:      	b.eq	0x9e4c <_stogir.stack.validate-inputs+0x3dc>
    9d1c:      	ldr	x2, [x22, #0x8]
    9d20:      	cmp	x0, x2
    9d24:      	b.ge	0x9e44 <_stogir.stack.validate-inputs+0x3d4>
    9d28:      	add	x2, x22, #0x78
    9d2c:      	ldr	x2, [x2, #0x8]
    9d30:      	cmp	x0, x2
    9d34:      	b.ge	0x9f88 <_stogir.stack.validate-inputs+0x518>
    9d38:      	ldr	x2, [x22, #0x78]
    9d3c:      	add	x2, x2, x0, lsl #2
    9d40:      	ldr	w2, [x2]
    9d44:      	sxtw	x2, w2
    9d48:      	cmp	x2, #0x0
    9d4c:      	cset	w2, ge
    9d50:      	ubfx	x2, x2, #0, #8
    9d54:      	b	0x9f8c <_stogir.stack.validate-inputs+0x51c>
    9d58:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009d58:  ARM64_RELOC_PAGE21	l_stogir.452
    9d5c:      	ldr	x16, [x16]
		0000000000009d5c:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9d60:      	orr	x0, x16, xzr
    9d64:      	mov	x2, #0x1                ; =1
    9d68:      	mov	x1, #0x1f               ; =31
    9d6c:      	b	0x9c08 <_stogir.stack.validate-inputs+0x198>
    9d70:      	mov	x21, x8
    9d74:      	mov	x22, x0
    9d78:      	mov	x0, x20
    9d7c:      	mov	w23, w3
    9d80:      	mov	w24, w4
    9d84:      	bl	0x9d84 <_stogir.stack.validate-inputs+0x314>
		0000000000009d84:  ARM64_RELOC_BRANCH26	_stogir.frame.valid-alignment?
    9d88:      	cmp	x0, #0x0
    9d8c:      	b.eq	0x9ac0 <_stogir.stack.validate-inputs+0x50>
    9d90:      	b	0x9b58 <_stogir.stack.validate-inputs+0xe8>
    9d94:      	movz	x1, #0x0, lsl #48
    9d98:      	b	0x9c28 <_stogir.stack.validate-inputs+0x1b8>
    9d9c:      	movz	x1, #0x0, lsl #48
    9da0:      	b	0x9c54 <_stogir.stack.validate-inputs+0x1e4>
    9da4:      	movz	x1, #0x0, lsl #48
    9da8:      	b	0x9d98 <_stogir.stack.validate-inputs+0x328>
    9dac:      	movz	w2, #0x0, lsl #16
    9db0:      	movz	x1, #0x0, lsl #48
    9db4:      	movz	x0, #0x0, lsl #48
    9db8:      	ubfx	x2, x2, #0, #32
    9dbc:      	lsr	x16, x2, #0
    9dc0:      	cmp	x16, #0x1
    9dc4:      	b.eq	0x9de0 <_stogir.stack.validate-inputs+0x370>
    9dc8:      	b.lo	0x9dd0 <_stogir.stack.validate-inputs+0x360>
    9dcc:      	b	0x9de4 <_stogir.stack.validate-inputs+0x374>
    9dd0:      	cmp	x16, #0x0
    9dd4:      	b.eq	0x9ddc <_stogir.stack.validate-inputs+0x36c>
    9dd8:      	b	0x9de4 <_stogir.stack.validate-inputs+0x374>
    9ddc:      	b	0x9de8 <_stogir.stack.validate-inputs+0x378>
    9de0:      	b	0x9e98 <_stogir.stack.validate-inputs+0x428>
    9de4:      	b	0x9ff0 <_stogir.stack.validate-inputs+0x580>
    9de8:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009de8:  ARM64_RELOC_PAGE21	l_stogir.453
    9dec:      	ldr	x16, [x16]
		0000000000009dec:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    9df0:      	orr	x0, x16, xzr
    9df4:      	mov	x2, #0x1                ; =1
    9df8:      	mov	x1, #0x18               ; =24
    9dfc:      	b	0x9d6c <_stogir.stack.validate-inputs+0x2fc>
    9e00:      	ldr	x0, [x22, #0x28]
    9e04:      	add	x0, x0, x3, lsl #4
    9e08:      	ldr	x1, [x0]
    9e0c:      	ldr	x0, [x0, #0x8]
    9e10:      	mov	w2, #0x1                ; =1
    9e14:      	b	0x9db8 <_stogir.stack.validate-inputs+0x348>
    9e18:      	movz	x2, #0x0, lsl #48
    9e1c:      	cmp	x2, #0x0
    9e20:      	b.eq	0x9dac <_stogir.stack.validate-inputs+0x33c>
    9e24:      	uxtb	w16, w1
    9e28:      	cmp	w16, wzr
    9e2c:      	b.eq	0x9e00 <_stogir.stack.validate-inputs+0x390>
    9e30:      	ldr	x1, [x22]
    9e34:      	add	x0, x1, x0, lsl #4
    9e38:      	ldr	x1, [x0]
    9e3c:      	ldr	x0, [x0, #0x8]
    9e40:      	b	0x9e10 <_stogir.stack.validate-inputs+0x3a0>
    9e44:      	movz	x2, #0x0, lsl #48
    9e48:      	b	0x9e1c <_stogir.stack.validate-inputs+0x3ac>
    9e4c:      	uxtb	w16, w23
    9e50:      	cmp	w16, wzr
    9e54:      	b.eq	0x9e18 <_stogir.stack.validate-inputs+0x3a8>
    9e58:      	add	x4, x22, #0x28
    9e5c:      	add	x5, x22, #0x50
    9e60:      	ldr	x4, [x4, #0x8]
    9e64:      	ldr	x5, [x5, #0x8]
    9e68:      	cmp	x4, x5
    9e6c:      	b.ne	0x9f80 <_stogir.stack.validate-inputs+0x510>
    9e70:      	cmp	x2, x4
    9e74:      	b.gt	0x9f98 <_stogir.stack.validate-inputs+0x528>
    9e78:      	ldr	x2, [x22, #0x50]
    9e7c:      	add	x2, x2, x3, lsl #2
    9e80:      	ldr	w2, [x2]
    9e84:      	sxtw	x2, w2
    9e88:      	cmp	x2, #0x0
    9e8c:      	cset	w2, gt
    9e90:      	ubfx	x2, x2, #0, #8
    9e94:      	b	0x9f9c <_stogir.stack.validate-inputs+0x52c>
    9e98:      	add	x16, sp, #0x20
    9e9c:      	orr	x25, x16, xzr
    9ea0:      	add	x16, sp, #0x20
    9ea4:      	str	x1, [x16]
    9ea8:      	add	x16, sp, #0x20
    9eac:      	str	x0, [x16, #0x8]
    9eb0:      	mov	x0, x25
    9eb4:      	bl	0x9eb4 <_stogir.stack.validate-inputs+0x444>
		0000000000009eb4:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    9eb8:      	uxtb	w0, w0
    9ebc:      	bl	0x9ebc <_stogir.stack.validate-inputs+0x44c>
		0000000000009ebc:  ARM64_RELOC_BRANCH26	_stogir.types.integer?
    9ec0:      	cmp	x0, #0x0
    9ec4:      	b.eq	0x9f68 <_stogir.stack.validate-inputs+0x4f8>
    9ec8:      	mov	x0, x25
    9ecc:      	bl	0x9ecc <_stogir.stack.validate-inputs+0x45c>
		0000000000009ecc:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    9ed0:      	uxtb	w0, w0
    9ed4:      	cmp	x0, #0x48
    9ed8:      	b.eq	0x9f68 <_stogir.stack.validate-inputs+0x4f8>
    9edc:      	uxtb	w16, w23
    9ee0:      	cmp	w16, wzr
    9ee4:      	b.eq	0x9fa0 <_stogir.stack.validate-inputs+0x530>
    9ee8:      	uxtb	w16, w19
    9eec:      	cmp	w16, wzr
    9ef0:      	b.eq	0x9efc <_stogir.stack.validate-inputs+0x48c>
    9ef4:      	cmp	x20, #0x10
    9ef8:      	b.gt	0x9f00 <_stogir.stack.validate-inputs+0x490>
    9efc:      	mov	x20, #0x10              ; =16
    9f00:      	add	x8, sp, #0x30
    9f04:      	mov	x0, x22
    9f08:      	mov	w1, w24
    9f0c:      	mov	x2, x20
    9f10:      	bl	0x9f10 <_stogir.stack.validate-inputs+0x4a0>
		0000000000009f10:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    9f14:      	add	x16, sp, #0x30
    9f18:      	ldr	w0, [x16]
    9f1c:      	lsr	x16, x0, #0
    9f20:      	cmp	x16, #0x1
    9f24:      	b.eq	0x9f40 <_stogir.stack.validate-inputs+0x4d0>
    9f28:      	b.lo	0x9f30 <_stogir.stack.validate-inputs+0x4c0>
    9f2c:      	b	0x9f44 <_stogir.stack.validate-inputs+0x4d4>
    9f30:      	cmp	x16, #0x0
    9f34:      	b.eq	0x9f3c <_stogir.stack.validate-inputs+0x4cc>
    9f38:      	b	0x9f44 <_stogir.stack.validate-inputs+0x4d4>
    9f3c:      	b	0x9fc8 <_stogir.stack.validate-inputs+0x558>
    9f40:      	b	0x9f48 <_stogir.stack.validate-inputs+0x4d8>
    9f44:      	b	0x9ff8 <_stogir.stack.validate-inputs+0x588>
    9f48:      	add	x16, sp, #0x30
    9f4c:      	orr	x0, x16, xzr
    9f50:      	add	x1, x0, #0x8
    9f54:      	add	x16, sp, #0x30
    9f58:      	ldr	x0, [x16, #0x8]
    9f5c:      	ldr	x1, [x1, #0x8]
    9f60:      	mov	x2, #0x1                ; =1
    9f64:      	b	0x9fec <_stogir.stack.validate-inputs+0x57c>
    9f68:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x218>
		0000000000009f68:  ARM64_RELOC_PAGE21	l_stogir.454
    9f6c:      	ldr	x16, [x16]
		0000000000009f6c:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    9f70:      	orr	x0, x16, xzr
    9f74:      	mov	x2, #0x1                ; =1
    9f78:      	mov	x1, #0x29               ; =41
    9f7c:      	b	0x9dfc <_stogir.stack.validate-inputs+0x38c>
    9f80:      	movz	x2, #0x0, lsl #48
    9f84:      	b	0x9e1c <_stogir.stack.validate-inputs+0x3ac>
    9f88:      	movz	x2, #0x0, lsl #48
    9f8c:      	b	0x9e48 <_stogir.stack.validate-inputs+0x3d8>
    9f90:      	brk	#0
    9f94:      	b	0x9f90 <_stogir.stack.validate-inputs+0x520>
    9f98:      	movz	x2, #0x0, lsl #48
    9f9c:      	b	0x9f84 <_stogir.stack.validate-inputs+0x514>
    9fa0:      	mov	x0, x25
    9fa4:      	bl	0x9fa4 <_stogir.stack.validate-inputs+0x534>
		0000000000009fa4:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    9fa8:      	uxtb	w0, w0
    9fac:      	mov	x1, #0x8                ; =8
    9fb0:      	bl	0x9fb0 <_stogir.stack.validate-inputs+0x540>
		0000000000009fb0:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    9fb4:      	sxtw	x0, w0
    9fb8:      	and	x0, x0, #0xffffffff
    9fbc:      	movz	x2, #0x0, lsl #48
    9fc0:      	movz	x1, #0x0, lsl #48
    9fc4:      	b	0x9f7c <_stogir.stack.validate-inputs+0x50c>
    9fc8:      	mov	x0, x25
    9fcc:      	bl	0x9fcc <_stogir.stack.validate-inputs+0x55c>
		0000000000009fcc:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    9fd0:      	uxtb	w0, w0
    9fd4:      	mov	x1, #0x8                ; =8
    9fd8:      	bl	0x9fd8 <_stogir.stack.validate-inputs+0x568>
		0000000000009fd8:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    9fdc:      	sxtw	x0, w0
    9fe0:      	and	x0, x0, #0xffffffff
    9fe4:      	movz	x2, #0x0, lsl #48
    9fe8:      	movz	x1, #0x0, lsl #48
    9fec:      	b	0x9fc4 <_stogir.stack.validate-inputs+0x554>
    9ff0:      	brk	#0
    9ff4:      	b	0x9ff0 <_stogir.stack.validate-inputs+0x580>
    9ff8:      	brk	#0
    9ffc:      	b	0x9ff8 <_stogir.stack.validate-inputs+0x588>
    a000:      	mov	x21, x8
    a004:      	b	0x9ac0 <_stogir.stack.validate-inputs+0x50>
    a008:      	mov	x21, x8
    a00c:      	mov	x22, x0
    a010:      	mov	w23, w3
    a014:      	mov	w24, w4
    a018:      	b	0x9b58 <_stogir.stack.validate-inputs+0xe8>

000000000000a01c <_stogir.locals.shape>:
    a01c:      	sub	sp, sp, #0x70
    a020:      	str	x29, [sp]
    a024:      	str	x30, [sp, #0x8]
    a028:      	mov	x29, sp
    a02c:      	str	x19, [sp, #0x30]
    a030:      	str	x20, [sp, #0x38]
    a034:      	str	x21, [sp, #0x40]
    a038:      	str	x22, [sp, #0x48]
    a03c:      	str	x23, [sp, #0x50]
    a040:      	str	x24, [sp, #0x58]
    a044:      	str	x25, [sp, #0x60]
    a048:      	str	x26, [sp, #0x68]
    a04c:      	sxtw	x19, w1
    a050:      	lsl	x20, x19, #2
    a054:      	cmp	x19, #0x0
    a058:      	cset	w1, gt
    a05c:      	movz	x16, #0x0, lsl #48
    a060:      	sub	x3, x16, x19
    a064:      	sub	x4, x3, #0x1
    a068:      	uxtb	w16, w1
    a06c:      	cmp	w16, wzr
    a070:      	b.eq	0xa0b0 <_stogir.locals.shape+0x94>
    a074:      	ldr	x3, [x0, #0x8]
    a078:      	cmp	x19, x3
    a07c:      	b.ge	0xa118 <_stogir.locals.shape+0xfc>
    a080:      	add	x3, x0, #0x78
    a084:      	ldr	x3, [x3, #0x8]
    a088:      	cmp	x19, x3
    a08c:      	b.ge	0xa2c0 <_stogir.locals.shape+0x2a4>
    a090:      	ldr	x3, [x0, #0x78]
    a094:      	add	x3, x20, x3
    a098:      	ldr	w3, [x3]
    a09c:      	sxtw	x3, w3
    a0a0:      	cmp	x3, #0x0
    a0a4:      	cset	w3, ge
    a0a8:      	ubfx	x3, x3, #0, #8
    a0ac:      	b	0xa2c4 <_stogir.locals.shape+0x2a8>
    a0b0:      	cmp	x19, #0x0
    a0b4:      	b.ge	0xa120 <_stogir.locals.shape+0x104>
    a0b8:      	add	x5, x0, #0x28
    a0bc:      	add	x6, x0, #0x50
    a0c0:      	ldr	x5, [x5, #0x8]
    a0c4:      	ldr	x6, [x6, #0x8]
    a0c8:      	cmp	x5, x6
    a0cc:      	b.ne	0xa0f8 <_stogir.locals.shape+0xdc>
    a0d0:      	cmp	x3, x5
    a0d4:      	b.gt	0xa3b8 <_stogir.locals.shape+0x39c>
    a0d8:      	ldr	x3, [x0, #0x50]
    a0dc:      	add	x3, x3, x4, lsl #2
    a0e0:      	ldr	w3, [x3]
    a0e4:      	sxtw	x3, w3
    a0e8:      	cmp	x3, #0x0
    a0ec:      	cset	w3, gt
    a0f0:      	ubfx	x3, x3, #0, #8
    a0f4:      	b	0xa3bc <_stogir.locals.shape+0x3a0>
    a0f8:      	movz	x3, #0x0, lsl #48
    a0fc:      	b	0xa124 <_stogir.locals.shape+0x108>
    a100:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000a100:  ARM64_RELOC_PAGE21	l_stogir.455
    a104:      	ldr	x16, [x16]
		000000000000a104:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    a108:      	orr	x21, x16, xzr
    a10c:      	mov	x0, #0x1                ; =1
    a110:      	mov	x23, #0x1c              ; =28
    a114:      	b	0xa1b8 <_stogir.locals.shape+0x19c>
    a118:      	movz	x3, #0x0, lsl #48
    a11c:      	b	0xa124 <_stogir.locals.shape+0x108>
    a120:      	movz	x3, #0x0, lsl #48
    a124:      	cmp	x3, #0x0
    a128:      	b.eq	0xa164 <_stogir.locals.shape+0x148>
    a12c:      	uxtb	w16, w1
    a130:      	cmp	w16, wzr
    a134:      	b.eq	0xa14c <_stogir.locals.shape+0x130>
    a138:      	ldr	x1, [x0]
    a13c:      	add	x1, x1, x19, lsl #4
    a140:      	ldr	x3, [x1]
    a144:      	ldr	x1, [x1, #0x8]
    a148:      	b	0xa15c <_stogir.locals.shape+0x140>
    a14c:      	ldr	x1, [x0, #0x28]
    a150:      	add	x1, x1, x4, lsl #4
    a154:      	ldr	x3, [x1]
    a158:      	ldr	x1, [x1, #0x8]
    a15c:      	mov	w4, #0x1                ; =1
    a160:      	b	0xa170 <_stogir.locals.shape+0x154>
    a164:      	movz	w4, #0x0, lsl #16
    a168:      	movz	x3, #0x0, lsl #48
    a16c:      	movz	x1, #0x0, lsl #48
    a170:      	ubfx	x4, x4, #0, #32
    a174:      	lsr	x16, x4, #0
    a178:      	cmp	x16, #0x1
    a17c:      	b.eq	0xa198 <_stogir.locals.shape+0x17c>
    a180:      	b.lo	0xa188 <_stogir.locals.shape+0x16c>
    a184:      	b	0xa19c <_stogir.locals.shape+0x180>
    a188:      	cmp	x16, #0x0
    a18c:      	b.eq	0xa194 <_stogir.locals.shape+0x178>
    a190:      	b	0xa19c <_stogir.locals.shape+0x180>
    a194:      	b	0xa1a0 <_stogir.locals.shape+0x184>
    a198:      	b	0xa1f4 <_stogir.locals.shape+0x1d8>
    a19c:      	b	0xa3c8 <_stogir.locals.shape+0x3ac>
    a1a0:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000a1a0:  ARM64_RELOC_PAGE21	l_stogir.456
    a1a4:      	ldr	x16, [x16]
		000000000000a1a4:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    a1a8:      	orr	x21, x16, xzr
    a1ac:      	mov	x24, x8
    a1b0:      	mov	x0, #0x1                ; =1
    a1b4:      	mov	x23, #0x16              ; =22
    a1b8:      	str	x0, [x24]
    a1bc:      	str	x21, [x24, #0x8]
    a1c0:      	str	x23, [x24, #0x10]
    a1c4:      	ldr	x19, [sp, #0x30]
    a1c8:      	ldr	x20, [sp, #0x38]
    a1cc:      	ldr	x21, [sp, #0x40]
    a1d0:      	ldr	x22, [sp, #0x48]
    a1d4:      	ldr	x23, [sp, #0x50]
    a1d8:      	ldr	x24, [sp, #0x58]
    a1dc:      	ldr	x25, [sp, #0x60]
    a1e0:      	ldr	x26, [sp, #0x68]
    a1e4:      	ldr	x29, [sp]
    a1e8:      	ldr	x30, [sp, #0x8]
    a1ec:      	add	sp, sp, #0x70
    a1f0:      	ret
    a1f4:      	add	x16, sp, #0x10
    a1f8:      	orr	x22, x16, xzr
    a1fc:      	orr	w21, w2, wzr
    a200:      	asr	x23, x1, #32
    a204:      	add	x16, sp, #0x10
    a208:      	str	x3, [x16]
    a20c:      	add	x16, sp, #0x10
    a210:      	str	x1, [x16, #0x8]
    a214:      	mov	x24, x8
    a218:      	mov	x25, x0
    a21c:      	mov	x0, x22
    a220:      	bl	0xa220 <_stogir.locals.shape+0x204>
		000000000000a220:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    a224:      	uxtb	w0, w0
    a228:      	mov	w1, w21
    a22c:      	bl	0xa22c <_stogir.locals.shape+0x210>
		000000000000a22c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a230:      	sxtw	x21, w0
    a234:      	cmp	x23, #0x0
    a238:      	b.ne	0xa240 <_stogir.locals.shape+0x224>
    a23c:      	mov	x23, x21
    a240:      	add	x16, sp, #0x10
    a244:      	ldr	w0, [x16, #0x8]
    a248:      	sxtw	x0, w0
    a24c:      	cmp	x0, #0x0
    a250:      	cset	w1, eq
    a254:      	ubfx	x26, x1, #0, #8
    a258:      	cmp	x0, #0x0
    a25c:      	b.le	0xa300 <_stogir.locals.shape+0x2e4>
    a260:      	add	x1, x25, #0x110
    a264:      	add	x2, x1, #0x28
    a268:      	ldr	x2, [x2, #0x8]
    a26c:      	cmp	x0, x2
    a270:      	b.gt	0xa2c8 <_stogir.locals.shape+0x2ac>
    a274:      	sub	x0, x0, #0x1
    a278:      	mov	x17, #0x18              ; =24
    a27c:      	mul	x0, x0, x17
    a280:      	ldr	x2, [x1, #0x28]
    a284:      	add	x0, x0, x2
    a288:      	ldr	x2, [x0]
    a28c:      	ldr	x0, [x0, #0x8]
    a290:      	ldr	x1, [x1, #0x8]
    a294:      	cmp	x2, #0x0
    a298:      	b.lt	0xa3c0 <_stogir.locals.shape+0x3a4>
    a29c:      	cmp	x2, x1
    a2a0:      	b.gt	0xa3c0 <_stogir.locals.shape+0x3a4>
    a2a4:      	cmp	x0, #0x0
    a2a8:      	b.lt	0xa3c0 <_stogir.locals.shape+0x3a4>
    a2ac:      	sub	x1, x1, x2
    a2b0:      	cmp	x0, x1
    a2b4:      	b.gt	0xa3c0 <_stogir.locals.shape+0x3a4>
    a2b8:      	mov	w0, #0x1                ; =1
    a2bc:      	b	0xa3c4 <_stogir.locals.shape+0x3a8>
    a2c0:      	movz	x3, #0x0, lsl #48
    a2c4:      	b	0xa11c <_stogir.locals.shape+0x100>
    a2c8:      	movz	w0, #0x0, lsl #16
    a2cc:      	ubfx	x0, x0, #0, #32
    a2d0:      	lsr	x16, x0, #0
    a2d4:      	cmp	x16, #0x1
    a2d8:      	b.eq	0xa2f4 <_stogir.locals.shape+0x2d8>
    a2dc:      	b.lo	0xa2e4 <_stogir.locals.shape+0x2c8>
    a2e0:      	b	0xa2f8 <_stogir.locals.shape+0x2dc>
    a2e4:      	cmp	x16, #0x0
    a2e8:      	b.eq	0xa2f0 <_stogir.locals.shape+0x2d4>
    a2ec:      	b	0xa2f8 <_stogir.locals.shape+0x2dc>
    a2f0:      	b	0xa300 <_stogir.locals.shape+0x2e4>
    a2f4:      	b	0xa2fc <_stogir.locals.shape+0x2e0>
    a2f8:      	b	0xa430 <_stogir.locals.shape+0x414>
    a2fc:      	mov	x26, #0x1               ; =1
    a300:      	cmp	x19, #0x0
    a304:      	b.le	0xa100 <_stogir.locals.shape+0xe4>
    a308:      	mov	x0, x22
    a30c:      	bl	0xa30c <_stogir.locals.shape+0x2f0>
		000000000000a30c:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    a310:      	uxtb	w0, w0
    a314:      	cmp	x0, #0x48
    a318:      	b.ne	0xa100 <_stogir.locals.shape+0xe4>
    a31c:      	ldr	x19, [x25, #0x78]
    a320:      	add	x0, x20, x19
    a324:      	ldr	w0, [x0]
    a328:      	sxtw	x0, w0
    a32c:      	cmp	x0, #0x3
    a330:      	b.ne	0xa100 <_stogir.locals.shape+0xe4>
    a334:      	cmp	x21, #0x0
    a338:      	b.le	0xa100 <_stogir.locals.shape+0xe4>
    a33c:      	cmp	x26, #0x0
    a340:      	b.eq	0xa100 <_stogir.locals.shape+0xe4>
    a344:      	mov	x0, x23
    a348:      	bl	0xa348 <_stogir.locals.shape+0x32c>
		000000000000a348:  ARM64_RELOC_BRANCH26	_stogir.frame.valid-alignment?
    a34c:      	cmp	x0, #0x0
    a350:      	b.eq	0xa100 <_stogir.locals.shape+0xe4>
    a354:      	add	x16, sp, #0x10
    a358:      	ldr	w0, [x16, #0x4]
    a35c:      	sxtw	x0, w0
    a360:      	cmp	x0, #0x0
    a364:      	cset	w1, gt
    a368:      	movz	x16, #0x0, lsl #48
    a36c:      	sub	x2, x16, x0
    a370:      	sub	x3, x2, #0x1
    a374:      	uxtb	w16, w1
    a378:      	cmp	w16, wzr
    a37c:      	b.eq	0xa3e8 <_stogir.locals.shape+0x3cc>
    a380:      	ldr	x2, [x25, #0x8]
    a384:      	cmp	x0, x2
    a388:      	b.ge	0xa438 <_stogir.locals.shape+0x41c>
    a38c:      	add	x2, x25, #0x78
    a390:      	ldr	x2, [x2, #0x8]
    a394:      	cmp	x0, x2
    a398:      	b.ge	0xa534 <_stogir.locals.shape+0x518>
    a39c:      	add	x2, x19, x0, lsl #2
    a3a0:      	ldr	w2, [x2]
    a3a4:      	sxtw	x2, w2
    a3a8:      	cmp	x2, #0x0
    a3ac:      	cset	w2, ge
    a3b0:      	ubfx	x2, x2, #0, #8
    a3b4:      	b	0xa538 <_stogir.locals.shape+0x51c>
    a3b8:      	movz	x3, #0x0, lsl #48
    a3bc:      	b	0xa0fc <_stogir.locals.shape+0xe0>
    a3c0:      	movz	w0, #0x0, lsl #16
    a3c4:      	b	0xa2cc <_stogir.locals.shape+0x2b0>
    a3c8:      	brk	#0
    a3cc:      	b	0xa3c8 <_stogir.locals.shape+0x3ac>
    a3d0:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000a3d0:  ARM64_RELOC_PAGE21	l_stogir.457
    a3d4:      	ldr	x16, [x16]
		000000000000a3d4:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    a3d8:      	orr	x21, x16, xzr
    a3dc:      	mov	x0, #0x1                ; =1
    a3e0:      	mov	x23, #0x2c              ; =44
    a3e4:      	b	0xa114 <_stogir.locals.shape+0xf8>
    a3e8:      	cmp	x0, #0x0
    a3ec:      	b.ge	0xa440 <_stogir.locals.shape+0x424>
    a3f0:      	add	x4, x25, #0x28
    a3f4:      	add	x5, x25, #0x50
    a3f8:      	ldr	x4, [x4, #0x8]
    a3fc:      	ldr	x5, [x5, #0x8]
    a400:      	cmp	x4, x5
    a404:      	b.ne	0xa52c <_stogir.locals.shape+0x510>
    a408:      	cmp	x2, x4
    a40c:      	b.gt	0xa53c <_stogir.locals.shape+0x520>
    a410:      	ldr	x2, [x25, #0x50]
    a414:      	add	x2, x2, x3, lsl #2
    a418:      	ldr	w2, [x2]
    a41c:      	sxtw	x2, w2
    a420:      	cmp	x2, #0x0
    a424:      	cset	w2, gt
    a428:      	ubfx	x2, x2, #0, #8
    a42c:      	b	0xa540 <_stogir.locals.shape+0x524>
    a430:      	brk	#0
    a434:      	b	0xa430 <_stogir.locals.shape+0x414>
    a438:      	movz	x2, #0x0, lsl #48
    a43c:      	b	0xa444 <_stogir.locals.shape+0x428>
    a440:      	movz	x2, #0x0, lsl #48
    a444:      	cmp	x2, #0x0
    a448:      	b.eq	0xa484 <_stogir.locals.shape+0x468>
    a44c:      	uxtb	w16, w1
    a450:      	cmp	w16, wzr
    a454:      	b.eq	0xa46c <_stogir.locals.shape+0x450>
    a458:      	ldr	x1, [x25]
    a45c:      	add	x0, x1, x0, lsl #4
    a460:      	ldr	x1, [x0]
    a464:      	ldr	x0, [x0, #0x8]
    a468:      	b	0xa47c <_stogir.locals.shape+0x460>
    a46c:      	ldr	x0, [x25, #0x28]
    a470:      	add	x0, x0, x3, lsl #4
    a474:      	ldr	x1, [x0]
    a478:      	ldr	x0, [x0, #0x8]
    a47c:      	mov	w2, #0x1                ; =1
    a480:      	b	0xa490 <_stogir.locals.shape+0x474>
    a484:      	movz	w2, #0x0, lsl #16
    a488:      	movz	x1, #0x0, lsl #48
    a48c:      	movz	x0, #0x0, lsl #48
    a490:      	ubfx	x2, x2, #0, #32
    a494:      	lsr	x16, x2, #0
    a498:      	cmp	x16, #0x1
    a49c:      	b.eq	0xa4b8 <_stogir.locals.shape+0x49c>
    a4a0:      	b.lo	0xa4a8 <_stogir.locals.shape+0x48c>
    a4a4:      	b	0xa4bc <_stogir.locals.shape+0x4a0>
    a4a8:      	cmp	x16, #0x0
    a4ac:      	b.eq	0xa4b4 <_stogir.locals.shape+0x498>
    a4b0:      	b	0xa4bc <_stogir.locals.shape+0x4a0>
    a4b4:      	b	0xa4c0 <_stogir.locals.shape+0x4a4>
    a4b8:      	b	0xa4d8 <_stogir.locals.shape+0x4bc>
    a4bc:      	b	0xa57c <_stogir.locals.shape+0x560>
    a4c0:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000a4c0:  ARM64_RELOC_PAGE21	l_stogir.458
    a4c4:      	ldr	x16, [x16]
		000000000000a4c4:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    a4c8:      	orr	x21, x16, xzr
    a4cc:      	mov	x0, #0x1                ; =1
    a4d0:      	mov	x23, #0x1d              ; =29
    a4d4:      	b	0xa3e4 <_stogir.locals.shape+0x3c8>
    a4d8:      	add	x16, sp, #0x20
    a4dc:      	str	x1, [x16]
    a4e0:      	add	x16, sp, #0x20
    a4e4:      	str	x0, [x16, #0x8]
    a4e8:      	add	x16, sp, #0x10
    a4ec:      	ldr	w0, [x16, #0x4]
    a4f0:      	sxtw	x0, w0
    a4f4:      	cmp	x0, #0x0
    a4f8:      	b.le	0xa3d0 <_stogir.locals.shape+0x3b4>
    a4fc:      	add	x16, sp, #0x20
    a500:      	orr	x0, x16, xzr
    a504:      	bl	0xa504 <_stogir.locals.shape+0x4e8>
		000000000000a504:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    a508:      	uxtb	w0, w0
    a50c:      	cmp	x0, #0x83
    a510:      	b.ge	0xa544 <_stogir.locals.shape+0x528>
    a514:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000a514:  ARM64_RELOC_PAGE21	l_stogir.459
    a518:      	ldr	x16, [x16]
		000000000000a518:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    a51c:      	orr	x1, x16, xzr
    a520:      	add	x0, x0, x1
    a524:      	ldrb	w0, [x0]
    a528:      	b	0xa548 <_stogir.locals.shape+0x52c>
    a52c:      	movz	x2, #0x0, lsl #48
    a530:      	b	0xa444 <_stogir.locals.shape+0x428>
    a534:      	movz	x2, #0x0, lsl #48
    a538:      	b	0xa43c <_stogir.locals.shape+0x420>
    a53c:      	movz	x2, #0x0, lsl #48
    a540:      	b	0xa530 <_stogir.locals.shape+0x514>
    a544:      	movz	w0, #0x0, lsl #16
    a548:      	uxtb	w16, w0
    a54c:      	and	w0, w16, #0x2
    a550:      	uxtb	w0, w0
    a554:      	ubfx	x0, x0, #0, #8
    a558:      	cmp	x0, #0x0
    a55c:      	cset	w0, eq
    a560:      	uxtb	w16, w0
    a564:      	cmp	w16, wzr
    a568:      	cset	x0, eq
    a56c:      	cmp	x0, #0x0
    a570:      	b.eq	0xa3d0 <_stogir.locals.shape+0x3b4>
    a574:      	movz	x0, #0x0, lsl #48
    a578:      	b	0xa3e4 <_stogir.locals.shape+0x3c8>
    a57c:      	brk	#0
    a580:      	b	0xa57c <_stogir.locals.shape+0x560>

000000000000a584 <_stogir.conversion.policy>:
    a584:      	sub	sp, sp, #0x70
    a588:      	str	x29, [sp]
    a58c:      	str	x30, [sp, #0x8]
    a590:      	mov	x29, sp
    a594:      	str	x19, [sp, #0x18]
    a598:      	str	x20, [sp, #0x20]
    a59c:      	str	x21, [sp, #0x28]
    a5a0:      	str	x22, [sp, #0x30]
    a5a4:      	str	x23, [sp, #0x38]
    a5a8:      	str	x24, [sp, #0x40]
    a5ac:      	str	x25, [sp, #0x48]
    a5b0:      	str	x26, [sp, #0x50]
    a5b4:      	str	x27, [sp, #0x58]
    a5b8:      	str	x28, [sp, #0x60]
    a5bc:      	sxtw	x19, w0
    a5c0:      	sxtw	x20, w1
    a5c4:      	sxtw	x21, w2
    a5c8:      	cmp	x19, #0x24
    a5cc:      	b.ne	0xa608 <_stogir.conversion.policy+0x84>
    a5d0:      	cmp	x20, #0xf
    a5d4:      	b.le	0xa7f4 <_stogir.conversion.policy+0x270>
    a5d8:      	cmp	x20, #0x80
    a5dc:      	b.ge	0xa7f4 <_stogir.conversion.policy+0x270>
    a5e0:      	and	w0, w1, #0xf
    a5e4:      	ubfx	x0, x0, #0, #32
    a5e8:      	cmp	x0, #0x1
    a5ec:      	b.lt	0xa7f4 <_stogir.conversion.policy+0x270>
    a5f0:      	cmp	x0, #0xd
    a5f4:      	b.gt	0xa7f4 <_stogir.conversion.policy+0x270>
    a5f8:      	mov	x22, #0x1               ; =1
    a5fc:      	b	0xa604 <_stogir.conversion.policy+0x80>
    a600:      	movz	x22, #0x0, lsl #48
    a604:      	b	0xa60c <_stogir.conversion.policy+0x88>
    a608:      	movz	x22, #0x0, lsl #48
    a60c:      	sxtw	x0, w3
    a610:      	cmp	x20, #0xd
    a614:      	cset	w23, eq
    a618:      	cmp	x20, #0xc
    a61c:      	cset	w24, eq
    a620:      	cmp	x0, #0x4
    a624:      	cset	w25, eq
    a628:      	cmp	x0, #0x8
    a62c:      	cset	w26, eq
    a630:      	cmp	x22, #0x0
    a634:      	b.eq	0xaab8 <_stogir.conversion.policy+0x534>
    a638:      	orr	w0, w3, wzr
    a63c:      	str	x8, [sp, #0x10]
    a640:      	mov	w28, w2
    a644:      	mov	w27, w3
    a648:      	fmov	s31, w0
    a64c:      	mov	w0, w1
    a650:      	fmov	w1, s31
    a654:      	bl	0xa654 <_stogir.conversion.policy+0xd0>
		000000000000a654:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a658:      	b	0xa660 <_stogir.conversion.policy+0xdc>
    a65c:      	mov	w0, #0x1                ; =1
    a660:      	cmp	x21, #0xd
    a664:      	cset	w1, eq
    a668:      	cmp	x21, #0xc
    a66c:      	cset	w2, eq
    a670:      	cmp	x22, #0x0
    a674:      	b.eq	0xaac8 <_stogir.conversion.policy+0x544>
    a678:      	mov	w22, w0
    a67c:      	mov	w0, w28
    a680:      	mov	w28, w1
    a684:      	mov	w1, w27
    a688:      	mov	w25, w2
    a68c:      	bl	0xa68c <_stogir.conversion.policy+0x108>
		000000000000a68c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a690:      	orr	w27, w0, wzr
    a694:      	mov	w0, w25
    a698:      	b	0xa6a0 <_stogir.conversion.policy+0x11c>
    a69c:      	mov	w27, #0x1               ; =1
    a6a0:      	cmp	x19, #0x21
    a6a4:      	b.lt	0xa778 <_stogir.conversion.policy+0x1f4>
    a6a8:      	cmp	x19, #0x27
    a6ac:      	b.gt	0xa778 <_stogir.conversion.policy+0x1f4>
    a6b0:      	lsl	w1, w22, #3
    a6b4:      	sxtw	x1, w1
    a6b8:      	cmp	x1, #0x0
    a6bc:      	b.le	0xa778 <_stogir.conversion.policy+0x1f4>
    a6c0:      	lsl	w2, w27, #3
    a6c4:      	sxtw	x2, w2
    a6c8:      	cmp	x2, #0x0
    a6cc:      	b.le	0xa778 <_stogir.conversion.policy+0x1f4>
    a6d0:      	cmp	x19, #0x26
    a6d4:      	cset	w3, eq
    a6d8:      	cmp	x20, #0x1
    a6dc:      	cset	w4, ge
    a6e0:      	cmp	x20, #0xb
    a6e4:      	cset	w5, le
    a6e8:      	cmp	x21, #0x1
    a6ec:      	cset	w6, ge
    a6f0:      	cmp	x21, #0xb
    a6f4:      	cset	w7, le
    a6f8:      	cmp	x19, #0x25
    a6fc:      	b.lt	0xa974 <_stogir.conversion.policy+0x3f0>
    a700:      	ubfx	x8, x28, #0, #8
    a704:      	cmp	x19, #0x25
    a708:      	b.ne	0xa9e4 <_stogir.conversion.policy+0x460>
    a70c:      	uxtb	w16, w4
    a710:      	cmp	w16, wzr
    a714:      	b.eq	0xa9dc <_stogir.conversion.policy+0x458>
    a718:      	uxtb	w16, w5
    a71c:      	cmp	w16, wzr
    a720:      	b.eq	0xa9dc <_stogir.conversion.policy+0x458>
    a724:      	uxtb	w16, w0
    a728:      	cmp	w16, wzr
    a72c:      	b.eq	0xa734 <_stogir.conversion.policy+0x1b0>
    a730:      	mov	x8, #0x1                ; =1
    a734:      	b	0xa9e0 <_stogir.conversion.policy+0x45c>
    a738:      	uxtb	w16, w25
    a73c:      	cmp	w16, wzr
    a740:      	b.ne	0xa7d4 <_stogir.conversion.policy+0x250>
    a744:      	uxtb	w16, w26
    a748:      	cmp	w16, wzr
    a74c:      	b.ne	0xa7d4 <_stogir.conversion.policy+0x250>
    a750:      	movn	w27, #0x0, lsl #16
    a754:      	b	0xa6a0 <_stogir.conversion.policy+0x11c>
    a758:      	uxtb	w16, w25
    a75c:      	cmp	w16, wzr
    a760:      	b.ne	0xa7e4 <_stogir.conversion.policy+0x260>
    a764:      	uxtb	w16, w26
    a768:      	cmp	w16, wzr
    a76c:      	b.ne	0xa7e4 <_stogir.conversion.policy+0x260>
    a770:      	movn	w0, #0x0, lsl #16
    a774:      	b	0xa660 <_stogir.conversion.policy+0xdc>
    a778:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000a778:  ARM64_RELOC_PAGE21	l_stogir.460
    a77c:      	ldr	x16, [x16]
		000000000000a77c:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    a780:      	orr	x0, x16, xzr
    a784:      	mov	x1, #0x1                ; =1
    a788:      	mov	x2, #0x22               ; =34
    a78c:      	ldr	x3, [sp, #0x10]
    a790:      	str	x1, [x3]
    a794:      	str	x0, [x3, #0x8]
    a798:      	str	x2, [x3, #0x10]
    a79c:      	ldr	x19, [sp, #0x18]
    a7a0:      	ldr	x20, [sp, #0x20]
    a7a4:      	ldr	x21, [sp, #0x28]
    a7a8:      	ldr	x22, [sp, #0x30]
    a7ac:      	ldr	x23, [sp, #0x38]
    a7b0:      	ldr	x24, [sp, #0x40]
    a7b4:      	ldr	x25, [sp, #0x48]
    a7b8:      	ldr	x26, [sp, #0x50]
    a7bc:      	ldr	x27, [sp, #0x58]
    a7c0:      	ldr	x28, [sp, #0x60]
    a7c4:      	ldr	x29, [sp]
    a7c8:      	ldr	x30, [sp, #0x8]
    a7cc:      	add	sp, sp, #0x70
    a7d0:      	ret
    a7d4:      	cmp	x21, #0x0
    a7d8:      	b.ne	0xa82c <_stogir.conversion.policy+0x2a8>
    a7dc:      	movz	w27, #0x0, lsl #16
    a7e0:      	b	0xa6a0 <_stogir.conversion.policy+0x11c>
    a7e4:      	cmp	x20, #0x0
    a7e8:      	b.ne	0xa8a4 <_stogir.conversion.policy+0x320>
    a7ec:      	movz	w0, #0x0, lsl #16
    a7f0:      	b	0xa660 <_stogir.conversion.policy+0xdc>
    a7f4:      	cmp	x21, #0xf
    a7f8:      	b.le	0xa600 <_stogir.conversion.policy+0x7c>
    a7fc:      	cmp	x21, #0x80
    a800:      	b.ge	0xa824 <_stogir.conversion.policy+0x2a0>
    a804:      	and	w0, w2, #0xf
    a808:      	ubfx	x0, x0, #0, #32
    a80c:      	cmp	x0, #0x1
    a810:      	b.lt	0xa91c <_stogir.conversion.policy+0x398>
    a814:      	cmp	x0, #0xd
    a818:      	cset	w0, le
    a81c:      	ubfx	x22, x0, #0, #8
    a820:      	b	0xa920 <_stogir.conversion.policy+0x39c>
    a824:      	movz	x22, #0x0, lsl #48
    a828:      	b	0xa604 <_stogir.conversion.policy+0x80>
    a82c:      	cmp	x21, #0x1
    a830:      	b.eq	0xa69c <_stogir.conversion.policy+0x118>
    a834:      	cmp	x21, #0x2
    a838:      	b.eq	0xa69c <_stogir.conversion.policy+0x118>
    a83c:      	cmp	x21, #0x7
    a840:      	b.eq	0xa69c <_stogir.conversion.policy+0x118>
    a844:      	cmp	x21, #0x8
    a848:      	b.eq	0xa69c <_stogir.conversion.policy+0x118>
    a84c:      	cmp	x21, #0x3
    a850:      	b.eq	0xaa10 <_stogir.conversion.policy+0x48c>
    a854:      	cmp	x21, #0x9
    a858:      	b.eq	0xaa10 <_stogir.conversion.policy+0x48c>
    a85c:      	cmp	x21, #0x4
    a860:      	b.eq	0xaa80 <_stogir.conversion.policy+0x4fc>
    a864:      	cmp	x21, #0xa
    a868:      	b.eq	0xaa80 <_stogir.conversion.policy+0x4fc>
    a86c:      	uxtb	w16, w28
    a870:      	cmp	w16, wzr
    a874:      	b.ne	0xaa80 <_stogir.conversion.policy+0x4fc>
    a878:      	cmp	x21, #0x5
    a87c:      	b.eq	0xaaa0 <_stogir.conversion.policy+0x51c>
    a880:      	cmp	x21, #0xb
    a884:      	b.eq	0xaaa0 <_stogir.conversion.policy+0x51c>
    a888:      	uxtb	w16, w0
    a88c:      	cmp	w16, wzr
    a890:      	b.ne	0xaaa0 <_stogir.conversion.policy+0x51c>
    a894:      	cmp	x21, #0x6
    a898:      	b.eq	0xa8a0 <_stogir.conversion.policy+0x31c>
    a89c:      	movn	w27, #0x0, lsl #16
    a8a0:      	b	0xaaa4 <_stogir.conversion.policy+0x520>
    a8a4:      	cmp	x20, #0x1
    a8a8:      	b.eq	0xa65c <_stogir.conversion.policy+0xd8>
    a8ac:      	cmp	x20, #0x2
    a8b0:      	b.eq	0xa65c <_stogir.conversion.policy+0xd8>
    a8b4:      	cmp	x20, #0x7
    a8b8:      	b.eq	0xa65c <_stogir.conversion.policy+0xd8>
    a8bc:      	cmp	x20, #0x8
    a8c0:      	b.eq	0xa65c <_stogir.conversion.policy+0xd8>
    a8c4:      	cmp	x20, #0x3
    a8c8:      	b.eq	0xaa18 <_stogir.conversion.policy+0x494>
    a8cc:      	cmp	x20, #0x9
    a8d0:      	b.eq	0xaa18 <_stogir.conversion.policy+0x494>
    a8d4:      	cmp	x20, #0x4
    a8d8:      	b.eq	0xaa88 <_stogir.conversion.policy+0x504>
    a8dc:      	cmp	x20, #0xa
    a8e0:      	b.eq	0xaa88 <_stogir.conversion.policy+0x504>
    a8e4:      	uxtb	w16, w23
    a8e8:      	cmp	w16, wzr
    a8ec:      	b.ne	0xaa88 <_stogir.conversion.policy+0x504>
    a8f0:      	cmp	x20, #0x5
    a8f4:      	b.eq	0xaaa8 <_stogir.conversion.policy+0x524>
    a8f8:      	cmp	x20, #0xb
    a8fc:      	b.eq	0xaaa8 <_stogir.conversion.policy+0x524>
    a900:      	uxtb	w16, w24
    a904:      	cmp	w16, wzr
    a908:      	b.ne	0xaaa8 <_stogir.conversion.policy+0x524>
    a90c:      	cmp	x20, #0x6
    a910:      	b.ne	0xaab0 <_stogir.conversion.policy+0x52c>
    a914:      	mov	w0, w27
    a918:      	b	0xaab4 <_stogir.conversion.policy+0x530>
    a91c:      	movz	x22, #0x0, lsl #48
    a920:      	b	0xa828 <_stogir.conversion.policy+0x2a4>
    a924:      	mov	x0, #0x1                ; =1
    a928:      	cmp	x0, #0x0
    a92c:      	b.ne	0xa778 <_stogir.conversion.policy+0x1f4>
    a930:      	cmp	x19, #0x23
    a934:      	b.eq	0xa944 <_stogir.conversion.policy+0x3c0>
    a938:      	uxtb	w16, w3
    a93c:      	cmp	w16, wzr
    a940:      	b.eq	0xa948 <_stogir.conversion.policy+0x3c4>
    a944:      	mov	x1, x2
    a948:      	and	x0, x1, #0xffffffff
    a94c:      	movz	x1, #0x0, lsl #48
    a950:      	movz	x2, #0x0, lsl #48
    a954:      	b	0xa78c <_stogir.conversion.policy+0x208>
    a958:      	movz	x8, #0x0, lsl #48
    a95c:      	cmp	x8, #0x0
    a960:      	cset	w0, ne
    a964:      	uxtb	w16, w0
    a968:      	cmp	w16, wzr
    a96c:      	cset	x0, eq
    a970:      	b	0xa928 <_stogir.conversion.policy+0x3a4>
    a974:      	cmp	x19, #0x24
    a978:      	b.ne	0xa994 <_stogir.conversion.policy+0x410>
    a97c:      	cmp	x1, x2
    a980:      	cset	w0, eq
    a984:      	uxtb	w16, w0
    a988:      	cmp	w16, wzr
    a98c:      	cset	x0, eq
    a990:      	b	0xa928 <_stogir.conversion.policy+0x3a4>
    a994:      	uxtb	w16, w4
    a998:      	cmp	w16, wzr
    a99c:      	b.eq	0xa924 <_stogir.conversion.policy+0x3a0>
    a9a0:      	uxtb	w16, w5
    a9a4:      	cmp	w16, wzr
    a9a8:      	b.eq	0xa924 <_stogir.conversion.policy+0x3a0>
    a9ac:      	uxtb	w16, w6
    a9b0:      	cmp	w16, wzr
    a9b4:      	b.eq	0xaa50 <_stogir.conversion.policy+0x4cc>
    a9b8:      	uxtb	w16, w7
    a9bc:      	cmp	w16, wzr
    a9c0:      	b.eq	0xaa50 <_stogir.conversion.policy+0x4cc>
    a9c4:      	cmp	x19, #0x23
    a9c8:      	b.ne	0xaa90 <_stogir.conversion.policy+0x50c>
    a9cc:      	cmp	x2, x1
    a9d0:      	cset	w0, ge
    a9d4:      	ubfx	x0, x0, #0, #8
    a9d8:      	b	0xaa9c <_stogir.conversion.policy+0x518>
    a9dc:      	movz	x8, #0x0, lsl #48
    a9e0:      	b	0xa95c <_stogir.conversion.policy+0x3d8>
    a9e4:      	uxtb	w16, w3
    a9e8:      	cmp	w16, wzr
    a9ec:      	b.eq	0xaa28 <_stogir.conversion.policy+0x4a4>
    a9f0:      	uxtb	w16, w24
    a9f4:      	cmp	w16, wzr
    a9f8:      	b.ne	0xaa6c <_stogir.conversion.policy+0x4e8>
    a9fc:      	uxtb	w16, w23
    aa00:      	cmp	w16, wzr
    aa04:      	b.ne	0xaa6c <_stogir.conversion.policy+0x4e8>
    aa08:      	movz	x8, #0x0, lsl #48
    aa0c:      	b	0xaa24 <_stogir.conversion.policy+0x4a0>
    aa10:      	mov	w27, #0x2               ; =2
    aa14:      	b	0xa6a0 <_stogir.conversion.policy+0x11c>
    aa18:      	mov	w0, #0x2                ; =2
    aa1c:      	b	0xa660 <_stogir.conversion.policy+0xdc>
    aa20:      	movz	x8, #0x0, lsl #48
    aa24:      	b	0xa95c <_stogir.conversion.policy+0x3d8>
    aa28:      	cmp	x19, #0x27
    aa2c:      	b.ne	0xa958 <_stogir.conversion.policy+0x3d4>
    aa30:      	uxtb	w16, w24
    aa34:      	cmp	w16, wzr
    aa38:      	b.ne	0xaa58 <_stogir.conversion.policy+0x4d4>
    aa3c:      	uxtb	w16, w23
    aa40:      	cmp	w16, wzr
    aa44:      	b.ne	0xaa58 <_stogir.conversion.policy+0x4d4>
    aa48:      	movz	x8, #0x0, lsl #48
    aa4c:      	b	0xaa68 <_stogir.conversion.policy+0x4e4>
    aa50:      	mov	x0, #0x1                ; =1
    aa54:      	b	0xa928 <_stogir.conversion.policy+0x3a4>
    aa58:      	uxtb	w16, w0
    aa5c:      	cmp	w16, wzr
    aa60:      	b.eq	0xaa68 <_stogir.conversion.policy+0x4e4>
    aa64:      	mov	x8, #0x1                ; =1
    aa68:      	b	0xa95c <_stogir.conversion.policy+0x3d8>
    aa6c:      	uxtb	w16, w6
    aa70:      	cmp	w16, wzr
    aa74:      	b.eq	0xaa20 <_stogir.conversion.policy+0x49c>
    aa78:      	ubfx	x8, x7, #0, #8
    aa7c:      	b	0xaa24 <_stogir.conversion.policy+0x4a0>
    aa80:      	mov	w27, #0x4               ; =4
    aa84:      	b	0xaa14 <_stogir.conversion.policy+0x490>
    aa88:      	mov	w0, #0x4                ; =4
    aa8c:      	b	0xaa1c <_stogir.conversion.policy+0x498>
    aa90:      	cmp	x2, x1
    aa94:      	cset	w0, le
    aa98:      	ubfx	x0, x0, #0, #8
    aa9c:      	b	0xaa54 <_stogir.conversion.policy+0x4d0>
    aaa0:      	mov	w27, #0x8               ; =8
    aaa4:      	b	0xaa84 <_stogir.conversion.policy+0x500>
    aaa8:      	mov	w0, #0x8                ; =8
    aaac:      	b	0xaa8c <_stogir.conversion.policy+0x508>
    aab0:      	movn	w0, #0x0, lsl #16
    aab4:      	b	0xaaac <_stogir.conversion.policy+0x528>
    aab8:      	str	x8, [sp, #0x10]
    aabc:      	mov	w28, w2
    aac0:      	mov	w27, w3
    aac4:      	b	0xa758 <_stogir.conversion.policy+0x1d4>
    aac8:      	mov	w22, w0
    aacc:      	mov	w28, w1
    aad0:      	mov	w0, w2
    aad4:      	b	0xa738 <_stogir.conversion.policy+0x1b4>

000000000000aad8 <_stogir.conditional.operands>:
    aad8:      	sub	sp, sp, #0xc0
    aadc:      	str	x29, [sp]
    aae0:      	str	x30, [sp, #0x8]
    aae4:      	mov	x29, sp
    aae8:      	str	x19, [sp, #0x68]
    aaec:      	str	x20, [sp, #0x70]
    aaf0:      	str	x21, [sp, #0x78]
    aaf4:      	str	x22, [sp, #0x80]
    aaf8:      	str	x23, [sp, #0x88]
    aafc:      	str	x24, [sp, #0x90]
    ab00:      	str	x25, [sp, #0x98]
    ab04:      	str	x26, [sp, #0xa0]
    ab08:      	str	x27, [sp, #0xa8]
    ab0c:      	str	x28, [sp, #0xb0]
    ab10:      	sxtw	x19, w1
    ab14:      	cmp	x19, #0x0
    ab18:      	b.ne	0xabe8 <_stogir.conditional.operands+0x110>
    ab1c:      	mov	x20, x8
    ab20:      	mov	x21, x0
    ab24:      	mov	w22, w2
    ab28:      	mov	w23, w3
    ab2c:      	mov	w24, w4
    ab30:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000ab30:  ARM64_RELOC_PAGE21	l_stogir.461
    ab34:      	ldr	x16, [x16]
		000000000000ab34:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    ab38:      	orr	x25, x16, xzr
    ab3c:      	mov	x26, #0x2b              ; =43
    ab40:      	sxtw	x22, w22
    ab44:      	cmp	x22, #0x0
    ab48:      	cset	w0, gt
    ab4c:      	movz	x16, #0x0, lsl #48
    ab50:      	sub	x1, x16, x22
    ab54:      	sub	x2, x1, #0x1
    ab58:      	uxtb	w16, w0
    ab5c:      	cmp	w16, wzr
    ab60:      	b.eq	0xaba0 <_stogir.conditional.operands+0xc8>
    ab64:      	ldr	x1, [x21, #0x8]
    ab68:      	cmp	x22, x1
    ab6c:      	b.ge	0xac30 <_stogir.conditional.operands+0x158>
    ab70:      	add	x1, x21, #0x78
    ab74:      	ldr	x1, [x1, #0x8]
    ab78:      	cmp	x22, x1
    ab7c:      	b.ge	0xb028 <_stogir.conditional.operands+0x550>
    ab80:      	ldr	x1, [x21, #0x78]
    ab84:      	add	x1, x1, x22, lsl #2
    ab88:      	ldr	w1, [x1]
    ab8c:      	sxtw	x1, w1
    ab90:      	cmp	x1, #0x0
    ab94:      	cset	w1, ge
    ab98:      	ubfx	x1, x1, #0, #8
    ab9c:      	b	0xb02c <_stogir.conditional.operands+0x554>
    aba0:      	cmp	x22, #0x0
    aba4:      	b.ge	0xac38 <_stogir.conditional.operands+0x160>
    aba8:      	add	x3, x21, #0x28
    abac:      	add	x4, x21, #0x50
    abb0:      	ldr	x3, [x3, #0x8]
    abb4:      	ldr	x4, [x4, #0x8]
    abb8:      	cmp	x3, x4
    abbc:      	b.ne	0xac20 <_stogir.conditional.operands+0x148>
    abc0:      	cmp	x1, x3
    abc4:      	b.gt	0xb030 <_stogir.conditional.operands+0x558>
    abc8:      	ldr	x1, [x21, #0x50]
    abcc:      	add	x1, x1, x2, lsl #2
    abd0:      	ldr	w1, [x1]
    abd4:      	sxtw	x1, w1
    abd8:      	cmp	x1, #0x0
    abdc:      	cset	w1, gt
    abe0:      	ubfx	x1, x1, #0, #8
    abe4:      	b	0xb034 <_stogir.conditional.operands+0x55c>
    abe8:      	mov	x20, x8
    abec:      	mov	x21, x0
    abf0:      	mov	w0, w1
    abf4:      	mov	w22, w2
    abf8:      	mov	w23, w3
    abfc:      	mov	w24, w4
    ac00:      	bl	0xac00 <_stogir.conditional.operands+0x128>
		000000000000ac00:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    ac04:      	cmp	x0, #0x0
    ac08:      	b.eq	0xab30 <_stogir.conditional.operands+0x58>
    ac0c:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000ac0c:  ARM64_RELOC_PAGE21	l_stogir.462
    ac10:      	ldr	x16, [x16]
		000000000000ac10:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    ac14:      	orr	x25, x16, xzr
    ac18:      	movz	x26, #0x0, lsl #48
    ac1c:      	b	0xab40 <_stogir.conditional.operands+0x68>
    ac20:      	movz	x1, #0x0, lsl #48
    ac24:      	b	0xac3c <_stogir.conditional.operands+0x164>
    ac28:      	movz	x6, #0x0, lsl #48
    ac2c:      	b	0xacd8 <_stogir.conditional.operands+0x200>
    ac30:      	movz	x1, #0x0, lsl #48
    ac34:      	b	0xac3c <_stogir.conditional.operands+0x164>
    ac38:      	movz	x1, #0x0, lsl #48
    ac3c:      	cmp	x1, #0x0
    ac40:      	b.eq	0xac7c <_stogir.conditional.operands+0x1a4>
    ac44:      	uxtb	w16, w0
    ac48:      	cmp	w16, wzr
    ac4c:      	b.eq	0xac64 <_stogir.conditional.operands+0x18c>
    ac50:      	ldr	x0, [x21]
    ac54:      	add	x0, x0, x22, lsl #4
    ac58:      	ldr	x1, [x0]
    ac5c:      	ldr	x0, [x0, #0x8]
    ac60:      	b	0xac74 <_stogir.conditional.operands+0x19c>
    ac64:      	ldr	x0, [x21, #0x28]
    ac68:      	add	x0, x0, x2, lsl #4
    ac6c:      	ldr	x1, [x0]
    ac70:      	ldr	x0, [x0, #0x8]
    ac74:      	mov	w2, #0x1                ; =1
    ac78:      	b	0xac88 <_stogir.conditional.operands+0x1b0>
    ac7c:      	movz	w2, #0x0, lsl #16
    ac80:      	movz	x1, #0x0, lsl #48
    ac84:      	movz	x0, #0x0, lsl #48
    ac88:      	ubfx	x2, x2, #0, #32
    ac8c:      	lsr	x16, x2, #0
    ac90:      	cmp	x16, #0x1
    ac94:      	b.eq	0xacb0 <_stogir.conditional.operands+0x1d8>
    ac98:      	b.lo	0xaca0 <_stogir.conditional.operands+0x1c8>
    ac9c:      	b	0xacb4 <_stogir.conditional.operands+0x1dc>
    aca0:      	cmp	x16, #0x0
    aca4:      	b.eq	0xacac <_stogir.conditional.operands+0x1d4>
    aca8:      	b	0xacb4 <_stogir.conditional.operands+0x1dc>
    acac:      	b	0xacb8 <_stogir.conditional.operands+0x1e0>
    acb0:      	b	0xacdc <_stogir.conditional.operands+0x204>
    acb4:      	b	0xb048 <_stogir.conditional.operands+0x570>
    acb8:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000acb8:  ARM64_RELOC_PAGE21	l_stogir.463
    acbc:      	ldr	x16, [x16]
		000000000000acbc:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    acc0:      	orr	x25, x16, xzr
    acc4:      	mov	x26, #0x16              ; =22
    acc8:      	b	0xad58 <_stogir.conditional.operands+0x280>
    accc:      	movz	x6, #0x0, lsl #48
    acd0:      	b	0xadb8 <_stogir.conditional.operands+0x2e0>
    acd4:      	movz	x6, #0x0, lsl #48
    acd8:      	b	0xadc0 <_stogir.conditional.operands+0x2e8>
    acdc:      	add	x16, sp, #0x10
    ace0:      	orr	x22, x16, xzr
    ace4:      	add	x16, sp, #0x10
    ace8:      	str	x1, [x16]
    acec:      	add	x16, sp, #0x10
    acf0:      	str	x0, [x16, #0x8]
    acf4:      	mov	x0, x22
    acf8:      	bl	0xacf8 <_stogir.conditional.operands+0x220>
		000000000000acf8:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    acfc:      	uxtb	w0, w0
    ad00:      	cmp	x0, #0x48
    ad04:      	b.eq	0xad48 <_stogir.conditional.operands+0x270>
    ad08:      	mov	x0, x22
    ad0c:      	bl	0xad0c <_stogir.conditional.operands+0x234>
		000000000000ad0c:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    ad10:      	uxtb	w0, w0
    ad14:      	cmp	x0, #0x46
    ad18:      	b.eq	0xad48 <_stogir.conditional.operands+0x270>
    ad1c:      	mov	x0, x22
    ad20:      	bl	0xad20 <_stogir.conditional.operands+0x248>
		000000000000ad20:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    ad24:      	uxtb	w0, w0
    ad28:      	cmp	x0, #0x0
    ad2c:      	b.eq	0xad48 <_stogir.conditional.operands+0x270>
    ad30:      	mov	x0, x22
    ad34:      	bl	0xad34 <_stogir.conditional.operands+0x25c>
		000000000000ad34:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    ad38:      	uxtb	w0, w0
    ad3c:      	bl	0xad3c <_stogir.conditional.operands+0x264>
		000000000000ad3c:  ARM64_RELOC_BRANCH26	_stogir.types.valid-scalar?
    ad40:      	cmp	x0, #0x0
    ad44:      	b.ne	0xad58 <_stogir.conditional.operands+0x280>
    ad48:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000ad48:  ARM64_RELOC_PAGE21	l_stogir.464
    ad4c:      	ldr	x16, [x16]
		000000000000ad4c:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    ad50:      	orr	x25, x16, xzr
    ad54:      	mov	x26, #0x2a              ; =42
    ad58:      	add	x16, sp, #0x30
    ad5c:      	orr	x22, x16, xzr
    ad60:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000ad60:  ARM64_RELOC_PAGE21	l_stogir.465
    ad64:      	ldr	x16, [x16]
		000000000000ad64:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    ad68:      	orr	x27, x16, xzr
    ad6c:      	add	x16, sp, #0x40
    ad70:      	orr	x28, x16, xzr
    ad74:      	adrp	x16, 0xa000 <_stogir.stack.validate-inputs+0x590>
		000000000000ad74:  ARM64_RELOC_PAGE21	l_stogir.466
    ad78:      	ldr	x16, [x16]
		000000000000ad78:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    ad7c:      	orr	x0, x16, xzr
    ad80:      	add	x1, x21, #0x78
    ad84:      	add	x2, x21, #0x28
    ad88:      	add	x3, x21, #0x50
    ad8c:      	add	x16, sp, #0x20
    ad90:      	str	w23, [x16]
    ad94:      	add	x16, sp, #0x20
    ad98:      	str	w24, [x16, #0x4]
    ad9c:      	add	x16, sp, #0x20
    ada0:      	ldr	x4, [x16]
    ada4:      	add	x16, sp, #0x30
    ada8:      	str	x4, [x16]
    adac:      	movz	x23, #0x0, lsl #48
    adb0:      	b	0xaed4 <_stogir.conditional.operands+0x3fc>
    adb4:      	movz	x6, #0x0, lsl #48
    adb8:      	b	0xadc0 <_stogir.conditional.operands+0x2e8>
    adbc:      	movz	x6, #0x0, lsl #48
    adc0:      	cmp	x6, #0x0
    adc4:      	b.eq	0xae00 <_stogir.conditional.operands+0x328>
    adc8:      	uxtb	w16, w4
    adcc:      	cmp	w16, wzr
    add0:      	b.eq	0xade8 <_stogir.conditional.operands+0x310>
    add4:      	ldr	x4, [x21]
    add8:      	add	x4, x4, x5, lsl #4
    addc:      	ldr	x5, [x4]
    ade0:      	ldr	x4, [x4, #0x8]
    ade4:      	b	0xadf8 <_stogir.conditional.operands+0x320>
    ade8:      	ldr	x4, [x21, #0x28]
    adec:      	add	x4, x4, x7, lsl #4
    adf0:      	ldr	x5, [x4]
    adf4:      	ldr	x4, [x4, #0x8]
    adf8:      	mov	w6, #0x1                ; =1
    adfc:      	b	0xae0c <_stogir.conditional.operands+0x334>
    ae00:      	movz	w6, #0x0, lsl #16
    ae04:      	movz	x5, #0x0, lsl #48
    ae08:      	movz	x4, #0x0, lsl #48
    ae0c:      	ubfx	x6, x6, #0, #32
    ae10:      	lsr	x16, x6, #0
    ae14:      	cmp	x16, #0x1
    ae18:      	b.eq	0xae34 <_stogir.conditional.operands+0x35c>
    ae1c:      	b.lo	0xae24 <_stogir.conditional.operands+0x34c>
    ae20:      	b	0xae38 <_stogir.conditional.operands+0x360>
    ae24:      	cmp	x16, #0x0
    ae28:      	b.eq	0xae30 <_stogir.conditional.operands+0x358>
    ae2c:      	b	0xae38 <_stogir.conditional.operands+0x360>
    ae30:      	b	0xae3c <_stogir.conditional.operands+0x364>
    ae34:      	b	0xae60 <_stogir.conditional.operands+0x388>
    ae38:      	b	0xb040 <_stogir.conditional.operands+0x568>
    ae3c:      	mov	x24, x0
    ae40:      	str	x1, [sp, #0x50]
    ae44:      	str	x2, [sp, #0x58]
    ae48:      	str	x3, [sp, #0x60]
    ae4c:      	mov	x25, x27
    ae50:      	mov	x26, #0x10              ; =16
    ae54:      	b	0xaec4 <_stogir.conditional.operands+0x3ec>
    ae58:      	mov	x0, #0x1                ; =1
    ae5c:      	b	0xafa4 <_stogir.conditional.operands+0x4cc>
    ae60:      	add	x16, sp, #0x40
    ae64:      	str	x5, [x16]
    ae68:      	add	x16, sp, #0x40
    ae6c:      	str	x4, [x16, #0x8]
    ae70:      	mov	x24, x0
    ae74:      	mov	x0, x28
    ae78:      	str	x1, [sp, #0x50]
    ae7c:      	str	x2, [sp, #0x58]
    ae80:      	str	x3, [sp, #0x60]
    ae84:      	bl	0xae84 <_stogir.conditional.operands+0x3ac>
		000000000000ae84:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    ae88:      	uxtb	w0, w0
    ae8c:      	cmp	x0, #0x48
    ae90:      	b.eq	0xaebc <_stogir.conditional.operands+0x3e4>
    ae94:      	mov	x0, x28
    ae98:      	bl	0xae98 <_stogir.conditional.operands+0x3c0>
		000000000000ae98:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    ae9c:      	uxtb	w0, w0
    aea0:      	cmp	x0, #0x46
    aea4:      	b.eq	0xaebc <_stogir.conditional.operands+0x3e4>
    aea8:      	mov	x0, x28
    aeac:      	bl	0xaeac <_stogir.conditional.operands+0x3d4>
		000000000000aeac:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    aeb0:      	uxtb	w0, w0
    aeb4:      	cmp	x0, x19
    aeb8:      	b.eq	0xaec4 <_stogir.conditional.operands+0x3ec>
    aebc:      	mov	x25, x24
    aec0:      	mov	x26, #0x21              ; =33
    aec4:      	mov	x0, x24
    aec8:      	ldr	x1, [sp, #0x50]
    aecc:      	ldr	x2, [sp, #0x58]
    aed0:      	ldr	x3, [sp, #0x60]
    aed4:      	cmp	x23, #0x2
    aed8:      	b.ge	0xaefc <_stogir.conditional.operands+0x424>
    aedc:      	add	x4, x23, #0x1
    aee0:      	add	x5, x22, x23, lsl #2
    aee4:      	ldr	w5, [x5]
    aee8:      	movn	w17, #0x0, lsl #16
    aeec:      	and	w5, w5, w17
    aef0:      	mov	x23, x4
    aef4:      	mov	w4, #0x1                ; =1
    aef8:      	b	0xaf04 <_stogir.conditional.operands+0x42c>
    aefc:      	movz	w4, #0x0, lsl #16
    af00:      	movz	w5, #0x0, lsl #16
    af04:      	ubfx	x4, x4, #0, #32
    af08:      	lsr	x16, x4, #0
    af0c:      	cmp	x16, #0x1
    af10:      	b.eq	0xaf2c <_stogir.conditional.operands+0x454>
    af14:      	b.lo	0xaf1c <_stogir.conditional.operands+0x444>
    af18:      	b	0xaf30 <_stogir.conditional.operands+0x458>
    af1c:      	cmp	x16, #0x0
    af20:      	b.eq	0xaf28 <_stogir.conditional.operands+0x450>
    af24:      	b	0xaf30 <_stogir.conditional.operands+0x458>
    af28:      	b	0xaf90 <_stogir.conditional.operands+0x4b8>
    af2c:      	b	0xaf34 <_stogir.conditional.operands+0x45c>
    af30:      	b	0xb038 <_stogir.conditional.operands+0x560>
    af34:      	sxtw	x5, w5
    af38:      	cmp	x5, #0x0
    af3c:      	cset	w4, gt
    af40:      	movz	x16, #0x0, lsl #48
    af44:      	sub	x6, x16, x5
    af48:      	sub	x7, x6, #0x1
    af4c:      	uxtb	w16, w4
    af50:      	cmp	w16, wzr
    af54:      	b.eq	0xafe8 <_stogir.conditional.operands+0x510>
    af58:      	ldr	x6, [x21, #0x8]
    af5c:      	cmp	x5, x6
    af60:      	b.ge	0xadb4 <_stogir.conditional.operands+0x2dc>
    af64:      	ldr	x6, [x1, #0x8]
    af68:      	cmp	x5, x6
    af6c:      	b.ge	0xaccc <_stogir.conditional.operands+0x1f4>
    af70:      	ldr	x6, [x21, #0x78]
    af74:      	add	x6, x6, x5, lsl #2
    af78:      	ldr	w6, [x6]
    af7c:      	sxtw	x6, w6
    af80:      	cmp	x6, #0x0
    af84:      	cset	w6, ge
    af88:      	ubfx	x6, x6, #0, #8
    af8c:      	b	0xacd0 <_stogir.conditional.operands+0x1f8>
    af90:      	cmp	x26, #0x0
    af94:      	b.ne	0xae58 <_stogir.conditional.operands+0x380>
    af98:      	and	x25, x19, #0xffffffff
    af9c:      	movz	x0, #0x0, lsl #48
    afa0:      	movz	x26, #0x0, lsl #48
    afa4:      	str	x0, [x20]
    afa8:      	str	x25, [x20, #0x8]
    afac:      	str	x26, [x20, #0x10]
    afb0:      	ldr	x19, [sp, #0x68]
    afb4:      	ldr	x20, [sp, #0x70]
    afb8:      	ldr	x21, [sp, #0x78]
    afbc:      	ldr	x22, [sp, #0x80]
    afc0:      	ldr	x23, [sp, #0x88]
    afc4:      	ldr	x24, [sp, #0x90]
    afc8:      	ldr	x25, [sp, #0x98]
    afcc:      	ldr	x26, [sp, #0xa0]
    afd0:      	ldr	x27, [sp, #0xa8]
    afd4:      	ldr	x28, [sp, #0xb0]
    afd8:      	ldr	x29, [sp]
    afdc:      	ldr	x30, [sp, #0x8]
    afe0:      	add	sp, sp, #0xc0
    afe4:      	ret
    afe8:      	cmp	x5, #0x0
    afec:      	b.ge	0xadbc <_stogir.conditional.operands+0x2e4>
    aff0:      	ldr	x8, [x2, #0x8]
    aff4:      	ldr	x9, [x3, #0x8]
    aff8:      	cmp	x8, x9
    affc:      	b.ne	0xacd4 <_stogir.conditional.operands+0x1fc>
    b000:      	cmp	x6, x8
    b004:      	b.gt	0xac28 <_stogir.conditional.operands+0x150>
    b008:      	ldr	x6, [x21, #0x50]
    b00c:      	add	x6, x6, x7, lsl #2
    b010:      	ldr	w6, [x6]
    b014:      	sxtw	x6, w6
    b018:      	cmp	x6, #0x0
    b01c:      	cset	w6, gt
    b020:      	ubfx	x6, x6, #0, #8
    b024:      	b	0xac2c <_stogir.conditional.operands+0x154>
    b028:      	movz	x1, #0x0, lsl #48
    b02c:      	b	0xac34 <_stogir.conditional.operands+0x15c>
    b030:      	movz	x1, #0x0, lsl #48
    b034:      	b	0xac24 <_stogir.conditional.operands+0x14c>
    b038:      	brk	#0
    b03c:      	b	0xb038 <_stogir.conditional.operands+0x560>
    b040:      	brk	#0
    b044:      	b	0xb040 <_stogir.conditional.operands+0x568>
    b048:      	brk	#0
    b04c:      	b	0xb048 <_stogir.conditional.operands+0x570>

000000000000b050 <_stogir.floating.unary?>:
    b050:      	sxtw	x0, w0
    b054:      	cmp	x0, #0x1f
    b058:      	b.ne	0xb064 <_stogir.floating.unary?+0x14>
    b05c:      	mov	x0, #0x1                ; =1
    b060:      	b	0xb070 <_stogir.floating.unary?+0x20>
    b064:      	cmp	x0, #0x20
    b068:      	cset	w0, eq
    b06c:      	ubfx	x0, x0, #0, #8
    b070:      	ret

000000000000b074 <_stogir.floating.operands>:
    b074:      	sub	sp, sp, #0xd0
    b078:      	str	x29, [sp]
    b07c:      	str	x30, [sp, #0x8]
    b080:      	mov	x29, sp
    b084:      	str	x19, [sp, #0x78]
    b088:      	str	x20, [sp, #0x80]
    b08c:      	str	x21, [sp, #0x88]
    b090:      	str	x22, [sp, #0x90]
    b094:      	str	x23, [sp, #0x98]
    b098:      	str	x24, [sp, #0xa0]
    b09c:      	str	x25, [sp, #0xa8]
    b0a0:      	str	x26, [sp, #0xb0]
    b0a4:      	str	x27, [sp, #0xb8]
    b0a8:      	str	x28, [sp, #0xc0]
    b0ac:      	mov	x19, x8
    b0b0:      	mov	x20, x0
    b0b4:      	mov	w0, w1
    b0b8:      	mov	w21, w1
    b0bc:      	mov	w22, w2
    b0c0:      	mov	w23, w3
    b0c4:      	mov	w24, w4
    b0c8:      	mov	w25, w5
    b0cc:      	bl	0xb0cc <_stogir.floating.operands+0x58>
		000000000000b0cc:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    b0d0:      	cmp	x0, #0x0
    b0d4:      	b.eq	0xb178 <_stogir.floating.operands+0x104>
    b0d8:      	mov	w0, w22
    b0dc:      	bl	0xb0dc <_stogir.floating.operands+0x68>
		000000000000b0dc:  ARM64_RELOC_BRANCH26	_stogir.types.floating?
    b0e0:      	cmp	x0, #0x0
    b0e4:      	b.eq	0xb178 <_stogir.floating.operands+0x104>
    b0e8:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b0e8:  ARM64_RELOC_PAGE21	l_stogir.467
    b0ec:      	ldr	x16, [x16]
		000000000000b0ec:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    b0f0:      	orr	x26, x16, xzr
    b0f4:      	movz	x27, #0x0, lsl #48
    b0f8:      	b	0xb188 <_stogir.floating.operands+0x114>
    b0fc:      	movz	w0, #0x0, lsl #16
    b100:      	uxtb	w16, w0
    b104:      	and	w0, w16, #0x2
    b108:      	uxtb	w0, w0
    b10c:      	ubfx	x0, x0, #0, #8
    b110:      	cmp	x0, #0x0
    b114:      	cset	w0, eq
    b118:      	uxtb	w16, w0
    b11c:      	cmp	w16, wzr
    b120:      	cset	x0, eq
    b124:      	cmp	x0, #0x0
    b128:      	b.ne	0xb164 <_stogir.floating.operands+0xf0>
    b12c:      	mov	x0, x20
    b130:      	bl	0xb130 <_stogir.floating.operands+0xbc>
		000000000000b130:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    b134:      	uxtb	w0, w0
    b138:      	cmp	x0, #0x65
    b13c:      	b.eq	0xb164 <_stogir.floating.operands+0xf0>
    b140:      	mov	x0, x20
    b144:      	bl	0xb144 <_stogir.floating.operands+0xd0>
		000000000000b144:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    b148:      	uxtb	w0, w0
    b14c:      	cmp	x0, #0x66
    b150:      	b.eq	0xb164 <_stogir.floating.operands+0xf0>
    b154:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b154:  ARM64_RELOC_PAGE21	l_stogir.468
    b158:      	ldr	x16, [x16]
		000000000000b158:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    b15c:      	orr	x26, x16, xzr
    b160:      	mov	x27, #0x2d              ; =45
    b164:      	b	0xb47c <_stogir.floating.operands+0x408>
    b168:      	movz	x7, #0x0, lsl #48
    b16c:      	b	0xb200 <_stogir.floating.operands+0x18c>
    b170:      	movz	x7, #0x0, lsl #48
    b174:      	b	0xb208 <_stogir.floating.operands+0x194>
    b178:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b178:  ARM64_RELOC_PAGE21	l_stogir.469
    b17c:      	ldr	x16, [x16]
		000000000000b17c:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    b180:      	orr	x26, x16, xzr
    b184:      	mov	x27, #0x22              ; =34
    b188:      	add	x16, sp, #0x10
    b18c:      	str	w23, [x16]
    b190:      	mov	w0, w21
    b194:      	bl	0xb194 <_stogir.floating.operands+0x120>
		000000000000b194:  ARM64_RELOC_BRANCH26	_stogir.floating.unary?
    b198:      	cmp	x0, #0x0
    b19c:      	b.ne	0xb1a4 <_stogir.floating.operands+0x130>
    b1a0:      	orr	w23, w24, wzr
    b1a4:      	sxtw	x22, w22
    b1a8:      	add	x16, sp, #0x20
    b1ac:      	orr	x24, x16, xzr
    b1b0:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b1b0:  ARM64_RELOC_PAGE21	l_stogir.470
    b1b4:      	ldr	x16, [x16]
		000000000000b1b4:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    b1b8:      	orr	x28, x16, xzr
    b1bc:      	add	x16, sp, #0x30
    b1c0:      	orr	x0, x16, xzr
    b1c4:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b1c4:  ARM64_RELOC_PAGE21	l_stogir.471
    b1c8:      	ldr	x16, [x16]
		000000000000b1c8:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    b1cc:      	orr	x1, x16, xzr
    b1d0:      	add	x2, x20, #0x78
    b1d4:      	add	x3, x20, #0x28
    b1d8:      	add	x4, x20, #0x50
    b1dc:      	add	x16, sp, #0x10
    b1e0:      	str	w23, [x16, #0x4]
    b1e4:      	add	x16, sp, #0x10
    b1e8:      	ldr	x5, [x16]
    b1ec:      	add	x16, sp, #0x20
    b1f0:      	str	x5, [x16]
    b1f4:      	movz	x23, #0x0, lsl #48
    b1f8:      	b	0xb2f4 <_stogir.floating.operands+0x280>
    b1fc:      	movz	x7, #0x0, lsl #48
    b200:      	b	0xb208 <_stogir.floating.operands+0x194>
    b204:      	movz	x7, #0x0, lsl #48
    b208:      	cmp	x7, #0x0
    b20c:      	b.eq	0xb248 <_stogir.floating.operands+0x1d4>
    b210:      	uxtb	w16, w5
    b214:      	cmp	w16, wzr
    b218:      	b.eq	0xb230 <_stogir.floating.operands+0x1bc>
    b21c:      	ldr	x5, [x20]
    b220:      	add	x5, x5, x6, lsl #4
    b224:      	ldr	x6, [x5]
    b228:      	ldr	x5, [x5, #0x8]
    b22c:      	b	0xb240 <_stogir.floating.operands+0x1cc>
    b230:      	ldr	x5, [x20, #0x28]
    b234:      	add	x5, x5, x8, lsl #4
    b238:      	ldr	x6, [x5]
    b23c:      	ldr	x5, [x5, #0x8]
    b240:      	mov	w7, #0x1                ; =1
    b244:      	b	0xb254 <_stogir.floating.operands+0x1e0>
    b248:      	movz	w7, #0x0, lsl #16
    b24c:      	movz	x6, #0x0, lsl #48
    b250:      	movz	x5, #0x0, lsl #48
    b254:      	ubfx	x7, x7, #0, #32
    b258:      	lsr	x16, x7, #0
    b25c:      	cmp	x16, #0x1
    b260:      	b.eq	0xb27c <_stogir.floating.operands+0x208>
    b264:      	b.lo	0xb26c <_stogir.floating.operands+0x1f8>
    b268:      	b	0xb280 <_stogir.floating.operands+0x20c>
    b26c:      	cmp	x16, #0x0
    b270:      	b.eq	0xb278 <_stogir.floating.operands+0x204>
    b274:      	b	0xb280 <_stogir.floating.operands+0x20c>
    b278:      	b	0xb284 <_stogir.floating.operands+0x210>
    b27c:      	b	0xb2a4 <_stogir.floating.operands+0x230>
    b280:      	b	0xb63c <_stogir.floating.operands+0x5c8>
    b284:      	str	x0, [sp, #0x50]
    b288:      	str	x1, [sp, #0x58]
    b28c:      	str	x2, [sp, #0x60]
    b290:      	str	x3, [sp, #0x68]
    b294:      	str	x4, [sp, #0x70]
    b298:      	mov	x26, x28
    b29c:      	mov	x27, #0x18              ; =24
    b2a0:      	b	0xb2e0 <_stogir.floating.operands+0x26c>
    b2a4:      	add	x16, sp, #0x30
    b2a8:      	str	x6, [x16]
    b2ac:      	add	x16, sp, #0x30
    b2b0:      	str	x5, [x16, #0x8]
    b2b4:      	str	x0, [sp, #0x50]
    b2b8:      	str	x1, [sp, #0x58]
    b2bc:      	str	x2, [sp, #0x60]
    b2c0:      	str	x3, [sp, #0x68]
    b2c4:      	str	x4, [sp, #0x70]
    b2c8:      	bl	0xb2c8 <_stogir.floating.operands+0x254>
		000000000000b2c8:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    b2cc:      	uxtb	w0, w0
    b2d0:      	cmp	x0, x22
    b2d4:      	b.eq	0xb2e0 <_stogir.floating.operands+0x26c>
    b2d8:      	ldr	x26, [sp, #0x58]
    b2dc:      	mov	x27, #0x1e              ; =30
    b2e0:      	ldr	x0, [sp, #0x50]
    b2e4:      	ldr	x1, [sp, #0x58]
    b2e8:      	ldr	x2, [sp, #0x60]
    b2ec:      	ldr	x3, [sp, #0x68]
    b2f0:      	ldr	x4, [sp, #0x70]
    b2f4:      	cmp	x23, #0x2
    b2f8:      	b.ge	0xb31c <_stogir.floating.operands+0x2a8>
    b2fc:      	add	x5, x23, #0x1
    b300:      	add	x6, x24, x23, lsl #2
    b304:      	ldr	w6, [x6]
    b308:      	movn	w17, #0x0, lsl #16
    b30c:      	and	w6, w6, w17
    b310:      	mov	x23, x5
    b314:      	mov	w5, #0x1                ; =1
    b318:      	b	0xb324 <_stogir.floating.operands+0x2b0>
    b31c:      	movz	w5, #0x0, lsl #16
    b320:      	movz	w6, #0x0, lsl #16
    b324:      	ubfx	x5, x5, #0, #32
    b328:      	lsr	x16, x5, #0
    b32c:      	cmp	x16, #0x1
    b330:      	b.eq	0xb34c <_stogir.floating.operands+0x2d8>
    b334:      	b.lo	0xb33c <_stogir.floating.operands+0x2c8>
    b338:      	b	0xb350 <_stogir.floating.operands+0x2dc>
    b33c:      	cmp	x16, #0x0
    b340:      	b.eq	0xb348 <_stogir.floating.operands+0x2d4>
    b344:      	b	0xb350 <_stogir.floating.operands+0x2dc>
    b348:      	b	0xb3b0 <_stogir.floating.operands+0x33c>
    b34c:      	b	0xb354 <_stogir.floating.operands+0x2e0>
    b350:      	b	0xb634 <_stogir.floating.operands+0x5c0>
    b354:      	sxtw	x6, w6
    b358:      	cmp	x6, #0x0
    b35c:      	cset	w5, gt
    b360:      	movz	x16, #0x0, lsl #48
    b364:      	sub	x7, x16, x6
    b368:      	sub	x8, x7, #0x1
    b36c:      	uxtb	w16, w5
    b370:      	cmp	w16, wzr
    b374:      	b.eq	0xb42c <_stogir.floating.operands+0x3b8>
    b378:      	ldr	x7, [x20, #0x8]
    b37c:      	cmp	x6, x7
    b380:      	b.ge	0xb1fc <_stogir.floating.operands+0x188>
    b384:      	ldr	x7, [x2, #0x8]
    b388:      	cmp	x6, x7
    b38c:      	b.ge	0xb168 <_stogir.floating.operands+0xf4>
    b390:      	ldr	x7, [x20, #0x78]
    b394:      	add	x7, x7, x6, lsl #2
    b398:      	ldr	w7, [x7]
    b39c:      	sxtw	x7, w7
    b3a0:      	cmp	x7, #0x0
    b3a4:      	cset	w7, ge
    b3a8:      	ubfx	x7, x7, #0, #8
    b3ac:      	b	0xb16c <_stogir.floating.operands+0xf8>
    b3b0:      	sxtw	x25, w25
    b3b4:      	cmp	x25, #0x0
    b3b8:      	b.eq	0xb47c <_stogir.floating.operands+0x408>
    b3bc:      	sxtw	x21, w21
    b3c0:      	cmp	x21, #0x1d
    b3c4:      	b.ne	0xb46c <_stogir.floating.operands+0x3f8>
    b3c8:      	cmp	x25, #0x0
    b3cc:      	cset	w0, lt
    b3d0:      	cmp	x25, #0x0
    b3d4:      	cset	w1, gt
    b3d8:      	movz	x16, #0x0, lsl #48
    b3dc:      	sub	x2, x16, x25
    b3e0:      	sub	x3, x2, #0x1
    b3e4:      	uxtb	w16, w1
    b3e8:      	cmp	w16, wzr
    b3ec:      	b.eq	0xb4dc <_stogir.floating.operands+0x468>
    b3f0:      	ldr	x2, [x20, #0x8]
    b3f4:      	cmp	x25, x2
    b3f8:      	b.ge	0xb530 <_stogir.floating.operands+0x4bc>
    b3fc:      	add	x2, x20, #0x78
    b400:      	ldr	x2, [x2, #0x8]
    b404:      	cmp	x25, x2
    b408:      	b.ge	0xb624 <_stogir.floating.operands+0x5b0>
    b40c:      	ldr	x2, [x20, #0x78]
    b410:      	add	x2, x2, x25, lsl #2
    b414:      	ldr	w2, [x2]
    b418:      	sxtw	x2, w2
    b41c:      	cmp	x2, #0x0
    b420:      	cset	w2, ge
    b424:      	ubfx	x2, x2, #0, #8
    b428:      	b	0xb628 <_stogir.floating.operands+0x5b4>
    b42c:      	cmp	x6, #0x0
    b430:      	b.ge	0xb204 <_stogir.floating.operands+0x190>
    b434:      	ldr	x9, [x3, #0x8]
    b438:      	ldr	x10, [x4, #0x8]
    b43c:      	cmp	x9, x10
    b440:      	b.ne	0xb170 <_stogir.floating.operands+0xfc>
    b444:      	cmp	x7, x9
    b448:      	b.gt	0xb528 <_stogir.floating.operands+0x4b4>
    b44c:      	ldr	x7, [x20, #0x50]
    b450:      	add	x7, x7, x8, lsl #2
    b454:      	ldr	w7, [x7]
    b458:      	sxtw	x7, w7
    b45c:      	cmp	x7, #0x0
    b460:      	cset	w7, gt
    b464:      	ubfx	x7, x7, #0, #8
    b468:      	b	0xb52c <_stogir.floating.operands+0x4b8>
    b46c:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b46c:  ARM64_RELOC_PAGE21	l_stogir.472
    b470:      	ldr	x16, [x16]
		000000000000b470:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    b474:      	orr	x26, x16, xzr
    b478:      	mov	x27, #0x21              ; =33
    b47c:      	cmp	x27, #0x0
    b480:      	b.ne	0xb494 <_stogir.floating.operands+0x420>
    b484:      	and	x26, x22, #0xffffffff
    b488:      	movz	x0, #0x0, lsl #48
    b48c:      	movz	x27, #0x0, lsl #48
    b490:      	b	0xb498 <_stogir.floating.operands+0x424>
    b494:      	mov	x0, #0x1                ; =1
    b498:      	str	x0, [x19]
    b49c:      	str	x26, [x19, #0x8]
    b4a0:      	str	x27, [x19, #0x10]
    b4a4:      	ldr	x19, [sp, #0x78]
    b4a8:      	ldr	x20, [sp, #0x80]
    b4ac:      	ldr	x21, [sp, #0x88]
    b4b0:      	ldr	x22, [sp, #0x90]
    b4b4:      	ldr	x23, [sp, #0x98]
    b4b8:      	ldr	x24, [sp, #0xa0]
    b4bc:      	ldr	x25, [sp, #0xa8]
    b4c0:      	ldr	x26, [sp, #0xb0]
    b4c4:      	ldr	x27, [sp, #0xb8]
    b4c8:      	ldr	x28, [sp, #0xc0]
    b4cc:      	ldr	x29, [sp]
    b4d0:      	ldr	x30, [sp, #0x8]
    b4d4:      	add	sp, sp, #0xd0
    b4d8:      	ret
    b4dc:      	uxtb	w16, w0
    b4e0:      	cmp	w16, wzr
    b4e4:      	b.eq	0xb538 <_stogir.floating.operands+0x4c4>
    b4e8:      	add	x4, x20, #0x28
    b4ec:      	add	x5, x20, #0x50
    b4f0:      	ldr	x4, [x4, #0x8]
    b4f4:      	ldr	x5, [x5, #0x8]
    b4f8:      	cmp	x4, x5
    b4fc:      	b.ne	0xb61c <_stogir.floating.operands+0x5a8>
    b500:      	cmp	x2, x4
    b504:      	b.gt	0xb62c <_stogir.floating.operands+0x5b8>
    b508:      	ldr	x2, [x20, #0x50]
    b50c:      	add	x2, x2, x3, lsl #2
    b510:      	ldr	w2, [x2]
    b514:      	sxtw	x2, w2
    b518:      	cmp	x2, #0x0
    b51c:      	cset	w2, gt
    b520:      	ubfx	x2, x2, #0, #8
    b524:      	b	0xb630 <_stogir.floating.operands+0x5bc>
    b528:      	movz	x7, #0x0, lsl #48
    b52c:      	b	0xb174 <_stogir.floating.operands+0x100>
    b530:      	movz	x2, #0x0, lsl #48
    b534:      	b	0xb53c <_stogir.floating.operands+0x4c8>
    b538:      	movz	x2, #0x0, lsl #48
    b53c:      	cmp	x2, #0x0
    b540:      	b.eq	0xb57c <_stogir.floating.operands+0x508>
    b544:      	uxtb	w16, w1
    b548:      	cmp	w16, wzr
    b54c:      	b.eq	0xb564 <_stogir.floating.operands+0x4f0>
    b550:      	ldr	x1, [x20]
    b554:      	add	x1, x1, x25, lsl #4
    b558:      	ldr	x2, [x1]
    b55c:      	ldr	x1, [x1, #0x8]
    b560:      	b	0xb574 <_stogir.floating.operands+0x500>
    b564:      	ldr	x1, [x20, #0x28]
    b568:      	add	x1, x1, x3, lsl #4
    b56c:      	ldr	x2, [x1]
    b570:      	ldr	x1, [x1, #0x8]
    b574:      	mov	w3, #0x1                ; =1
    b578:      	b	0xb588 <_stogir.floating.operands+0x514>
    b57c:      	movz	w3, #0x0, lsl #16
    b580:      	movz	x2, #0x0, lsl #48
    b584:      	movz	x1, #0x0, lsl #48
    b588:      	ubfx	x3, x3, #0, #32
    b58c:      	lsr	x16, x3, #0
    b590:      	cmp	x16, #0x1
    b594:      	b.eq	0xb5b0 <_stogir.floating.operands+0x53c>
    b598:      	b.lo	0xb5a0 <_stogir.floating.operands+0x52c>
    b59c:      	b	0xb5b4 <_stogir.floating.operands+0x540>
    b5a0:      	cmp	x16, #0x0
    b5a4:      	b.eq	0xb5ac <_stogir.floating.operands+0x538>
    b5a8:      	b	0xb5b4 <_stogir.floating.operands+0x540>
    b5ac:      	b	0xb5b8 <_stogir.floating.operands+0x544>
    b5b0:      	b	0xb5cc <_stogir.floating.operands+0x558>
    b5b4:      	b	0xb644 <_stogir.floating.operands+0x5d0>
    b5b8:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b5b8:  ARM64_RELOC_PAGE21	l_stogir.473
    b5bc:      	ldr	x16, [x16]
		000000000000b5bc:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    b5c0:      	orr	x26, x16, xzr
    b5c4:      	mov	x27, #0x16              ; =22
    b5c8:      	b	0xb164 <_stogir.floating.operands+0xf0>
    b5cc:      	add	x16, sp, #0x40
    b5d0:      	str	x2, [x16]
    b5d4:      	add	x16, sp, #0x40
    b5d8:      	str	x1, [x16, #0x8]
    b5dc:      	uxtb	w16, w0
    b5e0:      	cmp	w16, wzr
    b5e4:      	b.ne	0xb154 <_stogir.floating.operands+0xe0>
    b5e8:      	add	x16, sp, #0x40
    b5ec:      	orr	x20, x16, xzr
    b5f0:      	mov	x0, x20
    b5f4:      	bl	0xb5f4 <_stogir.floating.operands+0x580>
		000000000000b5f4:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    b5f8:      	uxtb	w0, w0
    b5fc:      	cmp	x0, #0x83
    b600:      	b.ge	0xb0fc <_stogir.floating.operands+0x88>
    b604:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b604:  ARM64_RELOC_PAGE21	l_stogir.474
    b608:      	ldr	x16, [x16]
		000000000000b608:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    b60c:      	orr	x1, x16, xzr
    b610:      	add	x0, x0, x1
    b614:      	ldrb	w0, [x0]
    b618:      	b	0xb100 <_stogir.floating.operands+0x8c>
    b61c:      	movz	x2, #0x0, lsl #48
    b620:      	b	0xb53c <_stogir.floating.operands+0x4c8>
    b624:      	movz	x2, #0x0, lsl #48
    b628:      	b	0xb534 <_stogir.floating.operands+0x4c0>
    b62c:      	movz	x2, #0x0, lsl #48
    b630:      	b	0xb620 <_stogir.floating.operands+0x5ac>
    b634:      	brk	#0
    b638:      	b	0xb634 <_stogir.floating.operands+0x5c0>
    b63c:      	brk	#0
    b640:      	b	0xb63c <_stogir.floating.operands+0x5c8>
    b644:      	brk	#0
    b648:      	b	0xb644 <_stogir.floating.operands+0x5d0>

000000000000b64c <_stogir.vector-lanes.operands>:
    b64c:      	sub	sp, sp, #0xe0
    b650:      	str	x29, [sp]
    b654:      	str	x30, [sp, #0x8]
    b658:      	mov	x29, sp
    b65c:      	str	x19, [sp, #0x88]
    b660:      	str	x20, [sp, #0x90]
    b664:      	str	x21, [sp, #0x98]
    b668:      	str	x22, [sp, #0xa0]
    b66c:      	str	x23, [sp, #0xa8]
    b670:      	str	x24, [sp, #0xb0]
    b674:      	str	x25, [sp, #0xb8]
    b678:      	str	x26, [sp, #0xc0]
    b67c:      	str	x27, [sp, #0xc8]
    b680:      	str	x28, [sp, #0xd0]
    b684:      	sxtw	x4, w4
    b688:      	cmp	x4, #0x0
    b68c:      	cset	w7, gt
    b690:      	movz	x16, #0x0, lsl #48
    b694:      	sub	x9, x16, x4
    b698:      	sub	x10, x9, #0x1
    b69c:      	uxtb	w16, w7
    b6a0:      	cmp	w16, wzr
    b6a4:      	b.eq	0xb6e4 <_stogir.vector-lanes.operands+0x98>
    b6a8:      	ldr	x9, [x0, #0x8]
    b6ac:      	cmp	x4, x9
    b6b0:      	b.ge	0xb73c <_stogir.vector-lanes.operands+0xf0>
    b6b4:      	add	x9, x0, #0x78
    b6b8:      	ldr	x9, [x9, #0x8]
    b6bc:      	cmp	x4, x9
    b6c0:      	b.ge	0xb878 <_stogir.vector-lanes.operands+0x22c>
    b6c4:      	ldr	x9, [x0, #0x78]
    b6c8:      	add	x9, x9, x4, lsl #2
    b6cc:      	ldr	w9, [x9]
    b6d0:      	sxtw	x9, w9
    b6d4:      	cmp	x9, #0x0
    b6d8:      	cset	w9, ge
    b6dc:      	ubfx	x9, x9, #0, #8
    b6e0:      	b	0xb87c <_stogir.vector-lanes.operands+0x230>
    b6e4:      	cmp	x4, #0x0
    b6e8:      	b.ge	0xb744 <_stogir.vector-lanes.operands+0xf8>
    b6ec:      	add	x11, x0, #0x28
    b6f0:      	add	x12, x0, #0x50
    b6f4:      	ldr	x11, [x11, #0x8]
    b6f8:      	ldr	x12, [x12, #0x8]
    b6fc:      	cmp	x11, x12
    b700:      	b.ne	0xb72c <_stogir.vector-lanes.operands+0xe0>
    b704:      	cmp	x9, x11
    b708:      	b.gt	0xba0c <_stogir.vector-lanes.operands+0x3c0>
    b70c:      	ldr	x9, [x0, #0x50]
    b710:      	add	x9, x9, x10, lsl #2
    b714:      	ldr	w9, [x9]
    b718:      	sxtw	x9, w9
    b71c:      	cmp	x9, #0x0
    b720:      	cset	w9, gt
    b724:      	ubfx	x9, x9, #0, #8
    b728:      	b	0xba10 <_stogir.vector-lanes.operands+0x3c4>
    b72c:      	movz	x9, #0x0, lsl #48
    b730:      	b	0xb748 <_stogir.vector-lanes.operands+0xfc>
    b734:      	mov	x0, #0x1                ; =1
    b738:      	b	0xb7dc <_stogir.vector-lanes.operands+0x190>
    b73c:      	movz	x9, #0x0, lsl #48
    b740:      	b	0xb748 <_stogir.vector-lanes.operands+0xfc>
    b744:      	movz	x9, #0x0, lsl #48
    b748:      	cmp	x9, #0x0
    b74c:      	b.eq	0xb788 <_stogir.vector-lanes.operands+0x13c>
    b750:      	uxtb	w16, w7
    b754:      	cmp	w16, wzr
    b758:      	b.eq	0xb770 <_stogir.vector-lanes.operands+0x124>
    b75c:      	ldr	x7, [x0]
    b760:      	add	x4, x7, x4, lsl #4
    b764:      	ldr	x7, [x4]
    b768:      	ldr	x4, [x4, #0x8]
    b76c:      	b	0xb780 <_stogir.vector-lanes.operands+0x134>
    b770:      	ldr	x4, [x0, #0x28]
    b774:      	add	x4, x4, x10, lsl #4
    b778:      	ldr	x7, [x4]
    b77c:      	ldr	x4, [x4, #0x8]
    b780:      	mov	w9, #0x1                ; =1
    b784:      	b	0xb794 <_stogir.vector-lanes.operands+0x148>
    b788:      	movz	w9, #0x0, lsl #16
    b78c:      	movz	x7, #0x0, lsl #48
    b790:      	movz	x4, #0x0, lsl #48
    b794:      	ubfx	x9, x9, #0, #32
    b798:      	lsr	x16, x9, #0
    b79c:      	cmp	x16, #0x1
    b7a0:      	b.eq	0xb7bc <_stogir.vector-lanes.operands+0x170>
    b7a4:      	b.lo	0xb7ac <_stogir.vector-lanes.operands+0x160>
    b7a8:      	b	0xb7c0 <_stogir.vector-lanes.operands+0x174>
    b7ac:      	cmp	x16, #0x0
    b7b0:      	b.eq	0xb7b8 <_stogir.vector-lanes.operands+0x16c>
    b7b4:      	b	0xb7c0 <_stogir.vector-lanes.operands+0x174>
    b7b8:      	b	0xb7c4 <_stogir.vector-lanes.operands+0x178>
    b7bc:      	b	0xb824 <_stogir.vector-lanes.operands+0x1d8>
    b7c0:      	b	0xbda4 <_stogir.vector-lanes.operands+0x758>
    b7c4:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b7c4:  ARM64_RELOC_PAGE21	l_stogir.475
    b7c8:      	ldr	x16, [x16]
		000000000000b7c8:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    b7cc:      	orr	x19, x16, xzr
    b7d0:      	str	x8, [sp, #0x78]
    b7d4:      	mov	x0, #0x1                ; =1
    b7d8:      	mov	x25, #0x1b              ; =27
    b7dc:      	ldr	x1, [sp, #0x78]
    b7e0:      	str	x0, [x1]
    b7e4:      	str	x19, [x1, #0x8]
    b7e8:      	str	x25, [x1, #0x10]
    b7ec:      	ldr	x19, [sp, #0x88]
    b7f0:      	ldr	x20, [sp, #0x90]
    b7f4:      	ldr	x21, [sp, #0x98]
    b7f8:      	ldr	x22, [sp, #0xa0]
    b7fc:      	ldr	x23, [sp, #0xa8]
    b800:      	ldr	x24, [sp, #0xb0]
    b804:      	ldr	x25, [sp, #0xb8]
    b808:      	ldr	x26, [sp, #0xc0]
    b80c:      	ldr	x27, [sp, #0xc8]
    b810:      	ldr	x28, [sp, #0xd0]
    b814:      	ldr	x29, [sp]
    b818:      	ldr	x30, [sp, #0x8]
    b81c:      	add	sp, sp, #0xe0
    b820:      	ret
    b824:      	sxtw	x20, w1
    b828:      	sxtw	x21, w2
    b82c:      	add	x16, sp, #0x10
    b830:      	orr	x22, x16, xzr
    b834:      	add	x16, sp, #0x10
    b838:      	str	x7, [x16]
    b83c:      	add	x16, sp, #0x10
    b840:      	str	x4, [x16, #0x8]
    b844:      	cmp	x20, #0x3d
    b848:      	b.ne	0xbdbc <_stogir.vector-lanes.operands+0x770>
    b84c:      	mov	x23, x8
    b850:      	mov	x24, x0
    b854:      	mov	x0, x22
    b858:      	mov	w19, w1
    b85c:      	mov	w25, w2
    b860:      	mov	w26, w3
    b864:      	mov	w27, w5
    b868:      	mov	w28, w6
    b86c:      	bl	0xb86c <_stogir.vector-lanes.operands+0x220>
		000000000000b86c:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    b870:      	uxtb	w0, w0
    b874:      	b	0xb884 <_stogir.vector-lanes.operands+0x238>
    b878:      	movz	x9, #0x0, lsl #48
    b87c:      	b	0xb740 <_stogir.vector-lanes.operands+0xf4>
    b880:      	mov	x0, x21
    b884:      	cmp	x20, #0x3d
    b888:      	b.ne	0xb894 <_stogir.vector-lanes.operands+0x248>
    b88c:      	mov	x1, x0
    b890:      	b	0xb8ac <_stogir.vector-lanes.operands+0x260>
    b894:      	mov	x21, x0
    b898:      	mov	x0, x22
    b89c:      	bl	0xb89c <_stogir.vector-lanes.operands+0x250>
		000000000000b89c:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    b8a0:      	uxtb	w0, w0
    b8a4:      	mov	x1, x21
    b8a8:      	orr	x21, x0, xzr
    b8ac:      	orr	w0, w1, wzr
    b8b0:      	str	x22, [sp, #0x70]
    b8b4:      	mov	w22, w0
    b8b8:      	mov	w0, w19
    b8bc:      	mov	x19, x1
    b8c0:      	bl	0xb8c0 <_stogir.vector-lanes.operands+0x274>
		000000000000b8c0:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operation?
    b8c4:      	cmp	x0, #0x0
    b8c8:      	b.eq	0xbddc <_stogir.vector-lanes.operands+0x790>
    b8cc:      	mov	w0, w22
    b8d0:      	bl	0xb8d0 <_stogir.vector-lanes.operands+0x284>
		000000000000b8d0:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    b8d4:      	cmp	x0, #0x0
    b8d8:      	b.eq	0xbde4 <_stogir.vector-lanes.operands+0x798>
    b8dc:      	sxtw	x0, w26
    b8e0:      	cmp	x0, #0x4
    b8e4:      	b.eq	0xb8f8 <_stogir.vector-lanes.operands+0x2ac>
    b8e8:      	cmp	x0, #0x8
    b8ec:      	b.eq	0xb8f8 <_stogir.vector-lanes.operands+0x2ac>
    b8f0:      	mov	x0, x19
    b8f4:      	b	0xb910 <_stogir.vector-lanes.operands+0x2c4>
    b8f8:      	add	x16, sp, #0x10
    b8fc:      	ldr	w0, [x16]
    b900:      	uxtb	w0, w0
    b904:      	cmp	x0, #0x48
    b908:      	b.ne	0xbcfc <_stogir.vector-lanes.operands+0x6b0>
    b90c:      	mov	x0, x19
    b910:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b910:  ARM64_RELOC_PAGE21	l_stogir.476
    b914:      	ldr	x16, [x16]
		000000000000b914:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    b918:      	orr	x19, x16, xzr
    b91c:      	mov	x1, #0x36               ; =54
    b920:      	sxtw	x27, w27
    b924:      	sxtw	x2, w28
    b928:      	cmp	x2, #0x0
    b92c:      	cset	w2, eq
    b930:      	cmp	x20, #0x3f
    b934:      	b.ne	0xbdec <_stogir.vector-lanes.operands+0x7a0>
    b938:      	mov	x20, x1
    b93c:      	mov	w1, w21
    b940:      	mov	x21, x0
    b944:      	mov	w0, w22
    b948:      	mov	w22, w2
    b94c:      	mov	w2, w26
    b950:      	bl	0xb950 <_stogir.vector-lanes.operands+0x304>
		000000000000b950:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b954:      	cmp	x0, #0x0
    b958:      	b.eq	0xbb08 <_stogir.vector-lanes.operands+0x4bc>
    b95c:      	movz	x0, #0x0, lsl #48
    b960:      	b	0xbb0c <_stogir.vector-lanes.operands+0x4c0>
    b964:      	cmp	x20, #0x3d
    b968:      	b.ne	0xbdfc <_stogir.vector-lanes.operands+0x7b0>
    b96c:      	mov	w2, w26
    b970:      	str	x23, [sp, #0x78]
    b974:      	mov	w23, w1
    b978:      	mov	w1, w25
    b97c:      	mov	x25, x0
    b980:      	mov	w0, w22
    b984:      	bl	0xb984 <_stogir.vector-lanes.operands+0x338>
		000000000000b984:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b988:      	cmp	x0, #0x0
    b98c:      	b.ne	0xb9a0 <_stogir.vector-lanes.operands+0x354>
    b990:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b990:  ARM64_RELOC_PAGE21	l_stogir.477
    b994:      	ldr	x16, [x16]
		000000000000b994:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    b998:      	orr	x19, x16, xzr
    b99c:      	mov	x25, #0x26              ; =38
    b9a0:      	cmp	x20, #0x3e
    b9a4:      	b.ne	0xbe0c <_stogir.vector-lanes.operands+0x7c0>
    b9a8:      	sxtw	x0, w22
    b9ac:      	str	w22, [sp, #0x80]
    b9b0:      	mov	x22, x0
    b9b4:      	ldr	x0, [sp, #0x70]
    b9b8:      	bl	0xb9b8 <_stogir.vector-lanes.operands+0x36c>
		000000000000b9b8:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    b9bc:      	uxtb	w0, w0
    b9c0:      	cmp	x0, x22
    b9c4:      	b.ne	0xba34 <_stogir.vector-lanes.operands+0x3e8>
    b9c8:      	movz	x0, #0x0, lsl #48
    b9cc:      	b	0xba38 <_stogir.vector-lanes.operands+0x3ec>
    b9d0:      	mov	x0, #0x1                ; =1
    b9d4:      	cmp	x0, #0x0
    b9d8:      	b.eq	0xb9ec <_stogir.vector-lanes.operands+0x3a0>
    b9dc:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000b9dc:  ARM64_RELOC_PAGE21	l_stogir.478
    b9e0:      	ldr	x16, [x16]
		000000000000b9e0:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    b9e4:      	orr	x19, x16, xzr
    b9e8:      	mov	x20, #0x24              ; =36
    b9ec:      	str	x23, [sp, #0x78]
    b9f0:      	mov	x25, x20
    b9f4:      	cmp	x25, #0x0
    b9f8:      	b.ne	0xb734 <_stogir.vector-lanes.operands+0xe8>
    b9fc:      	and	x19, x21, #0xffffffff
    ba00:      	movz	x0, #0x0, lsl #48
    ba04:      	movz	x25, #0x0, lsl #48
    ba08:      	b	0xb738 <_stogir.vector-lanes.operands+0xec>
    ba0c:      	movz	x9, #0x0, lsl #48
    ba10:      	b	0xb730 <_stogir.vector-lanes.operands+0xe4>
    ba14:      	uxtb	w16, w23
    ba18:      	cmp	w16, wzr
    ba1c:      	b.ne	0xba30 <_stogir.vector-lanes.operands+0x3e4>
    ba20:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000ba20:  ARM64_RELOC_PAGE21	l_stogir.479
    ba24:      	ldr	x16, [x16]
		000000000000ba24:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    ba28:      	orr	x19, x16, xzr
    ba2c:      	mov	x25, #0x20              ; =32
    ba30:      	b	0xb9f4 <_stogir.vector-lanes.operands+0x3a8>
    ba34:      	mov	x0, #0x1                ; =1
    ba38:      	b	0xba40 <_stogir.vector-lanes.operands+0x3f4>
    ba3c:      	movz	x0, #0x0, lsl #48
    ba40:      	cmp	x0, #0x0
    ba44:      	b.eq	0xba58 <_stogir.vector-lanes.operands+0x40c>
    ba48:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000ba48:  ARM64_RELOC_PAGE21	l_stogir.480
    ba4c:      	ldr	x16, [x16]
		000000000000ba4c:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    ba50:      	orr	x19, x16, xzr
    ba54:      	mov	x25, #0x27              ; =39
    ba58:      	cmp	x27, #0x0
    ba5c:      	cset	w22, lt
    ba60:      	cmp	x27, #0x0
    ba64:      	cset	w0, gt
    ba68:      	movz	x16, #0x0, lsl #48
    ba6c:      	sub	x1, x16, x27
    ba70:      	sub	x2, x1, #0x1
    ba74:      	uxtb	w16, w0
    ba78:      	cmp	w16, wzr
    ba7c:      	b.eq	0xbabc <_stogir.vector-lanes.operands+0x470>
    ba80:      	ldr	x1, [x24, #0x8]
    ba84:      	cmp	x27, x1
    ba88:      	b.ge	0xbbb0 <_stogir.vector-lanes.operands+0x564>
    ba8c:      	add	x1, x24, #0x78
    ba90:      	ldr	x1, [x1, #0x8]
    ba94:      	cmp	x27, x1
    ba98:      	b.ge	0xbcf4 <_stogir.vector-lanes.operands+0x6a8>
    ba9c:      	ldr	x1, [x24, #0x78]
    baa0:      	add	x1, x1, x27, lsl #2
    baa4:      	ldr	w1, [x1]
    baa8:      	sxtw	x1, w1
    baac:      	cmp	x1, #0x0
    bab0:      	cset	w1, ge
    bab4:      	ubfx	x1, x1, #0, #8
    bab8:      	b	0xbcf8 <_stogir.vector-lanes.operands+0x6ac>
    babc:      	uxtb	w16, w22
    bac0:      	cmp	w16, wzr
    bac4:      	b.eq	0xbbb8 <_stogir.vector-lanes.operands+0x56c>
    bac8:      	add	x3, x24, #0x28
    bacc:      	add	x4, x24, #0x50
    bad0:      	ldr	x3, [x3, #0x8]
    bad4:      	ldr	x4, [x4, #0x8]
    bad8:      	cmp	x3, x4
    badc:      	b.ne	0xbcec <_stogir.vector-lanes.operands+0x6a0>
    bae0:      	cmp	x1, x3
    bae4:      	b.gt	0xbd24 <_stogir.vector-lanes.operands+0x6d8>
    bae8:      	ldr	x1, [x24, #0x50]
    baec:      	add	x1, x1, x2, lsl #2
    baf0:      	ldr	w1, [x1]
    baf4:      	sxtw	x1, w1
    baf8:      	cmp	x1, #0x0
    bafc:      	cset	w1, gt
    bb00:      	ubfx	x1, x1, #0, #8
    bb04:      	b	0xbd28 <_stogir.vector-lanes.operands+0x6dc>
    bb08:      	mov	x0, #0x1                ; =1
    bb0c:      	cmp	x0, #0x0
    bb10:      	b.eq	0xbb1c <_stogir.vector-lanes.operands+0x4d0>
    bb14:      	mov	x0, #0x1                ; =1
    bb18:      	b	0xb9d4 <_stogir.vector-lanes.operands+0x388>
    bb1c:      	cmp	x27, #0x0
    bb20:      	b.ne	0xb9d0 <_stogir.vector-lanes.operands+0x384>
    bb24:      	uxtb	w16, w22
    bb28:      	cmp	w16, wzr
    bb2c:      	cset	x0, eq
    bb30:      	b	0xb9d4 <_stogir.vector-lanes.operands+0x388>
    bb34:      	movz	x0, #0x0, lsl #48
    bb38:      	cmp	x0, #0x0
    bb3c:      	b.eq	0xbb50 <_stogir.vector-lanes.operands+0x504>
    bb40:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000bb40:  ARM64_RELOC_PAGE21	l_stogir.481
    bb44:      	ldr	x16, [x16]
		000000000000bb44:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    bb48:      	orr	x19, x16, xzr
    bb4c:      	mov	x25, #0x28              ; =40
    bb50:      	cmp	x20, #0x3e
    bb54:      	b.ne	0xba14 <_stogir.vector-lanes.operands+0x3c8>
    bb58:      	add	x8, sp, #0x30
    bb5c:      	mov	x0, x24
    bb60:      	mov	w1, w28
    bb64:      	bl	0xbb64 <_stogir.vector-lanes.operands+0x518>
		000000000000bb64:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    bb68:      	add	x16, sp, #0x30
    bb6c:      	ldr	w0, [x16]
    bb70:      	lsr	x16, x0, #0
    bb74:      	cmp	x16, #0x1
    bb78:      	b.eq	0xbb94 <_stogir.vector-lanes.operands+0x548>
    bb7c:      	b.lo	0xbb84 <_stogir.vector-lanes.operands+0x538>
    bb80:      	b	0xbb98 <_stogir.vector-lanes.operands+0x54c>
    bb84:      	cmp	x16, #0x0
    bb88:      	b.eq	0xbb90 <_stogir.vector-lanes.operands+0x544>
    bb8c:      	b	0xbb98 <_stogir.vector-lanes.operands+0x54c>
    bb90:      	b	0xbb9c <_stogir.vector-lanes.operands+0x550>
    bb94:      	b	0xbd2c <_stogir.vector-lanes.operands+0x6e0>
    bb98:      	b	0xbdb4 <_stogir.vector-lanes.operands+0x768>
    bb9c:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000bb9c:  ARM64_RELOC_PAGE21	l_stogir.482
    bba0:      	ldr	x16, [x16]
		000000000000bba0:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    bba4:      	orr	x19, x16, xzr
    bba8:      	mov	x25, #0x20              ; =32
    bbac:      	b	0xba30 <_stogir.vector-lanes.operands+0x3e4>
    bbb0:      	movz	x1, #0x0, lsl #48
    bbb4:      	b	0xbbbc <_stogir.vector-lanes.operands+0x570>
    bbb8:      	movz	x1, #0x0, lsl #48
    bbbc:      	cmp	x1, #0x0
    bbc0:      	b.eq	0xbbfc <_stogir.vector-lanes.operands+0x5b0>
    bbc4:      	uxtb	w16, w0
    bbc8:      	cmp	w16, wzr
    bbcc:      	b.eq	0xbbe4 <_stogir.vector-lanes.operands+0x598>
    bbd0:      	ldr	x0, [x24]
    bbd4:      	add	x0, x0, x27, lsl #4
    bbd8:      	ldr	x1, [x0]
    bbdc:      	ldr	x0, [x0, #0x8]
    bbe0:      	b	0xbbf4 <_stogir.vector-lanes.operands+0x5a8>
    bbe4:      	ldr	x0, [x24, #0x28]
    bbe8:      	add	x0, x0, x2, lsl #4
    bbec:      	ldr	x1, [x0]
    bbf0:      	ldr	x0, [x0, #0x8]
    bbf4:      	mov	w2, #0x1                ; =1
    bbf8:      	b	0xbc08 <_stogir.vector-lanes.operands+0x5bc>
    bbfc:      	movz	w2, #0x0, lsl #16
    bc00:      	movz	x1, #0x0, lsl #48
    bc04:      	movz	x0, #0x0, lsl #48
    bc08:      	ubfx	x2, x2, #0, #32
    bc0c:      	lsr	x16, x2, #0
    bc10:      	cmp	x16, #0x1
    bc14:      	b.eq	0xbc30 <_stogir.vector-lanes.operands+0x5e4>
    bc18:      	b.lo	0xbc20 <_stogir.vector-lanes.operands+0x5d4>
    bc1c:      	b	0xbc34 <_stogir.vector-lanes.operands+0x5e8>
    bc20:      	cmp	x16, #0x0
    bc24:      	b.eq	0xbc2c <_stogir.vector-lanes.operands+0x5e0>
    bc28:      	b	0xbc34 <_stogir.vector-lanes.operands+0x5e8>
    bc2c:      	b	0xbc38 <_stogir.vector-lanes.operands+0x5ec>
    bc30:      	b	0xbc4c <_stogir.vector-lanes.operands+0x600>
    bc34:      	b	0xbdac <_stogir.vector-lanes.operands+0x760>
    bc38:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000bc38:  ARM64_RELOC_PAGE21	l_stogir.483
    bc3c:      	ldr	x16, [x16]
		000000000000bc3c:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    bc40:      	orr	x19, x16, xzr
    bc44:      	mov	x25, #0x19              ; =25
    bc48:      	b	0xbb50 <_stogir.vector-lanes.operands+0x504>
    bc4c:      	add	x16, sp, #0x20
    bc50:      	orr	x27, x16, xzr
    bc54:      	add	x16, sp, #0x20
    bc58:      	str	x1, [x16]
    bc5c:      	add	x16, sp, #0x20
    bc60:      	str	x0, [x16, #0x8]
    bc64:      	mov	x0, x27
    bc68:      	bl	0xbc68 <_stogir.vector-lanes.operands+0x61c>
		000000000000bc68:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    bc6c:      	uxtb	w0, w0
    bc70:      	bl	0xbc70 <_stogir.vector-lanes.operands+0x624>
		000000000000bc70:  ARM64_RELOC_BRANCH26	_stogir.types.integer?
    bc74:      	cmp	x0, #0x0
    bc78:      	b.eq	0xbc98 <_stogir.vector-lanes.operands+0x64c>
    bc7c:      	add	x16, sp, #0x20
    bc80:      	ldr	w0, [x16]
    bc84:      	uxtb	w0, w0
    bc88:      	cmp	x0, #0x48
    bc8c:      	b.eq	0xbc98 <_stogir.vector-lanes.operands+0x64c>
    bc90:      	cmp	x0, #0x46
    bc94:      	b.ne	0xbca8 <_stogir.vector-lanes.operands+0x65c>
    bc98:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000bc98:  ARM64_RELOC_PAGE21	l_stogir.484
    bc9c:      	ldr	x16, [x16]
		000000000000bc9c:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    bca0:      	orr	x19, x16, xzr
    bca4:      	mov	x25, #0x2b              ; =43
    bca8:      	uxtb	w16, w22
    bcac:      	cmp	w16, wzr
    bcb0:      	b.eq	0xbb34 <_stogir.vector-lanes.operands+0x4e8>
    bcb4:      	mov	x0, x27
    bcb8:      	bl	0xbcb8 <_stogir.vector-lanes.operands+0x66c>
		000000000000bcb8:  ARM64_RELOC_BRANCH26	_stogir.symbols.numeric?
    bcbc:      	cmp	x0, #0x0
    bcc0:      	b.eq	0xbd1c <_stogir.vector-lanes.operands+0x6d0>
    bcc4:      	mov	x0, x27
    bcc8:      	bl	0xbcc8 <_stogir.vector-lanes.operands+0x67c>
		000000000000bcc8:  ARM64_RELOC_BRANCH26	_stogir.node.constant-bits
    bccc:      	mov	x22, x0
    bcd0:      	ldr	w0, [sp, #0x80]
    bcd4:      	bl	0xbcd4 <_stogir.vector-lanes.operands+0x688>
		000000000000bcd4:  ARM64_RELOC_BRANCH26	_stogir.types.lanes
    bcd8:      	sxtw	x0, w0
    bcdc:      	cmp	x22, x0
    bce0:      	cset	w0, hs
    bce4:      	ubfx	x0, x0, #0, #8
    bce8:      	b	0xbd20 <_stogir.vector-lanes.operands+0x6d4>
    bcec:      	movz	x1, #0x0, lsl #48
    bcf0:      	b	0xbbbc <_stogir.vector-lanes.operands+0x570>
    bcf4:      	movz	x1, #0x0, lsl #48
    bcf8:      	b	0xbbb4 <_stogir.vector-lanes.operands+0x568>
    bcfc:      	cmp	x0, #0x46
    bd00:      	b.eq	0xbe14 <_stogir.vector-lanes.operands+0x7c8>
    bd04:      	mov	x0, x19
    bd08:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000bd08:  ARM64_RELOC_PAGE21	l_stogir.485
    bd0c:      	ldr	x16, [x16]
		000000000000bd0c:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    bd10:      	orr	x19, x16, xzr
    bd14:      	movz	x1, #0x0, lsl #48
    bd18:      	b	0xb920 <_stogir.vector-lanes.operands+0x2d4>
    bd1c:      	movz	x0, #0x0, lsl #48
    bd20:      	b	0xbb38 <_stogir.vector-lanes.operands+0x4ec>
    bd24:      	movz	x1, #0x0, lsl #48
    bd28:      	b	0xbcf0 <_stogir.vector-lanes.operands+0x6a4>
    bd2c:      	add	x16, sp, #0x30
    bd30:      	orr	x0, x16, xzr
    bd34:      	add	x0, x0, #0x8
    bd38:      	add	x16, sp, #0x30
    bd3c:      	ldr	x1, [x16, #0x8]
    bd40:      	add	x16, sp, #0x60
    bd44:      	str	x1, [x16]
    bd48:      	uxtb	w1, w1
    bd4c:      	ldr	x0, [x0, #0x8]
    bd50:      	add	x16, sp, #0x60
    bd54:      	str	x0, [x16, #0x8]
    bd58:      	cmp	x1, #0x48
    bd5c:      	b.eq	0xbd90 <_stogir.vector-lanes.operands+0x744>
    bd60:      	cmp	x1, #0x46
    bd64:      	b.eq	0xbd90 <_stogir.vector-lanes.operands+0x744>
    bd68:      	add	x16, sp, #0x60
    bd6c:      	orr	x0, x16, xzr
    bd70:      	bl	0xbd70 <_stogir.vector-lanes.operands+0x724>
		000000000000bd70:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    bd74:      	uxtb	w0, w0
    bd78:      	mov	w1, w0
    bd7c:      	ldr	w0, [sp, #0x80]
    bd80:      	mov	w2, w26
    bd84:      	bl	0xbd84 <_stogir.vector-lanes.operands+0x738>
		000000000000bd84:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    bd88:      	cmp	x0, #0x0
    bd8c:      	b.ne	0xbda0 <_stogir.vector-lanes.operands+0x754>
    bd90:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000bd90:  ARM64_RELOC_PAGE21	l_stogir.486
    bd94:      	ldr	x16, [x16]
		000000000000bd94:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    bd98:      	orr	x19, x16, xzr
    bd9c:      	mov	x25, #0x27              ; =39
    bda0:      	b	0xbbac <_stogir.vector-lanes.operands+0x560>
    bda4:      	brk	#0
    bda8:      	b	0xbda4 <_stogir.vector-lanes.operands+0x758>
    bdac:      	brk	#0
    bdb0:      	b	0xbdac <_stogir.vector-lanes.operands+0x760>
    bdb4:      	brk	#0
    bdb8:      	b	0xbdb4 <_stogir.vector-lanes.operands+0x768>
    bdbc:      	mov	x23, x8
    bdc0:      	mov	x24, x0
    bdc4:      	mov	w19, w1
    bdc8:      	mov	w25, w2
    bdcc:      	mov	w26, w3
    bdd0:      	mov	w27, w5
    bdd4:      	mov	w28, w6
    bdd8:      	b	0xb880 <_stogir.vector-lanes.operands+0x234>
    bddc:      	mov	x0, x19
    bde0:      	b	0xb910 <_stogir.vector-lanes.operands+0x2c4>
    bde4:      	mov	x0, x19
    bde8:      	b	0xb910 <_stogir.vector-lanes.operands+0x2c4>
    bdec:      	mov	x21, x0
    bdf0:      	mov	x0, x1
    bdf4:      	mov	w1, w2
    bdf8:      	b	0xb964 <_stogir.vector-lanes.operands+0x318>
    bdfc:      	str	x23, [sp, #0x78]
    be00:      	mov	w23, w1
    be04:      	mov	x25, x0
    be08:      	b	0xb9a0 <_stogir.vector-lanes.operands+0x354>
    be0c:      	str	w22, [sp, #0x80]
    be10:      	b	0xba3c <_stogir.vector-lanes.operands+0x3f0>
    be14:      	mov	x0, x19
    be18:      	b	0xb910 <_stogir.vector-lanes.operands+0x2c4>

000000000000be1c <_stogir.vector-comparison.operands>:
    be1c:      	sub	sp, sp, #0x70
    be20:      	str	x29, [sp]
    be24:      	str	x30, [sp, #0x8]
    be28:      	mov	x29, sp
    be2c:      	str	x19, [sp, #0x30]
    be30:      	str	x20, [sp, #0x38]
    be34:      	str	x21, [sp, #0x40]
    be38:      	str	x22, [sp, #0x48]
    be3c:      	str	x23, [sp, #0x50]
    be40:      	str	x24, [sp, #0x58]
    be44:      	str	x25, [sp, #0x60]
    be48:      	str	x26, [sp, #0x68]
    be4c:      	sxtw	x4, w4
    be50:      	cmp	x4, #0x0
    be54:      	cset	w6, gt
    be58:      	movz	x16, #0x0, lsl #48
    be5c:      	sub	x7, x16, x4
    be60:      	sub	x9, x7, #0x1
    be64:      	uxtb	w16, w6
    be68:      	cmp	w16, wzr
    be6c:      	b.eq	0xbeac <_stogir.vector-comparison.operands+0x90>
    be70:      	ldr	x7, [x0, #0x8]
    be74:      	cmp	x4, x7
    be78:      	b.ge	0xbefc <_stogir.vector-comparison.operands+0xe0>
    be7c:      	add	x7, x0, #0x78
    be80:      	ldr	x7, [x7, #0x8]
    be84:      	cmp	x4, x7
    be88:      	b.ge	0xc048 <_stogir.vector-comparison.operands+0x22c>
    be8c:      	ldr	x7, [x0, #0x78]
    be90:      	add	x7, x7, x4, lsl #2
    be94:      	ldr	w7, [x7]
    be98:      	sxtw	x7, w7
    be9c:      	cmp	x7, #0x0
    bea0:      	cset	w7, ge
    bea4:      	ubfx	x7, x7, #0, #8
    bea8:      	b	0xc04c <_stogir.vector-comparison.operands+0x230>
    beac:      	cmp	x4, #0x0
    beb0:      	b.ge	0xbf04 <_stogir.vector-comparison.operands+0xe8>
    beb4:      	add	x10, x0, #0x28
    beb8:      	add	x11, x0, #0x50
    bebc:      	ldr	x10, [x10, #0x8]
    bec0:      	ldr	x11, [x11, #0x8]
    bec4:      	cmp	x10, x11
    bec8:      	b.ne	0xbef4 <_stogir.vector-comparison.operands+0xd8>
    becc:      	cmp	x7, x10
    bed0:      	b.gt	0xc130 <_stogir.vector-comparison.operands+0x314>
    bed4:      	ldr	x7, [x0, #0x50]
    bed8:      	add	x7, x7, x9, lsl #2
    bedc:      	ldr	w7, [x7]
    bee0:      	sxtw	x7, w7
    bee4:      	cmp	x7, #0x0
    bee8:      	cset	w7, gt
    beec:      	ubfx	x7, x7, #0, #8
    bef0:      	b	0xc134 <_stogir.vector-comparison.operands+0x318>
    bef4:      	movz	x7, #0x0, lsl #48
    bef8:      	b	0xbf08 <_stogir.vector-comparison.operands+0xec>
    befc:      	movz	x7, #0x0, lsl #48
    bf00:      	b	0xbf08 <_stogir.vector-comparison.operands+0xec>
    bf04:      	movz	x7, #0x0, lsl #48
    bf08:      	cmp	x7, #0x0
    bf0c:      	b.eq	0xbf48 <_stogir.vector-comparison.operands+0x12c>
    bf10:      	uxtb	w16, w6
    bf14:      	cmp	w16, wzr
    bf18:      	b.eq	0xbf30 <_stogir.vector-comparison.operands+0x114>
    bf1c:      	ldr	x6, [x0]
    bf20:      	add	x4, x6, x4, lsl #4
    bf24:      	ldr	x6, [x4]
    bf28:      	ldr	x4, [x4, #0x8]
    bf2c:      	b	0xbf40 <_stogir.vector-comparison.operands+0x124>
    bf30:      	ldr	x4, [x0, #0x28]
    bf34:      	add	x4, x4, x9, lsl #4
    bf38:      	ldr	x6, [x4]
    bf3c:      	ldr	x4, [x4, #0x8]
    bf40:      	mov	w7, #0x1                ; =1
    bf44:      	b	0xbf54 <_stogir.vector-comparison.operands+0x138>
    bf48:      	movz	w7, #0x0, lsl #16
    bf4c:      	movz	x6, #0x0, lsl #48
    bf50:      	movz	x4, #0x0, lsl #48
    bf54:      	adrp	x16, 0xb000 <_stogir.conditional.operands+0x528>
		000000000000bf54:  ARM64_RELOC_PAGE21	l_stogir.487
    bf58:      	ldr	x16, [x16]
		000000000000bf58:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    bf5c:      	orr	x9, x16, xzr
    bf60:      	ubfx	x7, x7, #0, #32
    bf64:      	lsr	x16, x7, #0
    bf68:      	cmp	x16, #0x1
    bf6c:      	b.eq	0xbf88 <_stogir.vector-comparison.operands+0x16c>
    bf70:      	b.lo	0xbf78 <_stogir.vector-comparison.operands+0x15c>
    bf74:      	b	0xbf8c <_stogir.vector-comparison.operands+0x170>
    bf78:      	cmp	x16, #0x0
    bf7c:      	b.eq	0xbf84 <_stogir.vector-comparison.operands+0x168>
    bf80:      	b	0xbf8c <_stogir.vector-comparison.operands+0x170>
    bf84:      	b	0xbf90 <_stogir.vector-comparison.operands+0x174>
    bf88:      	b	0xbfd8 <_stogir.vector-comparison.operands+0x1bc>
    bf8c:      	b	0xc2d0 <_stogir.vector-comparison.operands+0x4b4>
    bf90:      	mov	x21, x8
    bf94:      	mov	x0, #0x1                ; =1
    bf98:      	mov	x1, #0x21               ; =33
    bf9c:      	str	x0, [x21]
    bfa0:      	str	x9, [x21, #0x8]
    bfa4:      	str	x1, [x21, #0x10]
    bfa8:      	ldr	x19, [sp, #0x30]
    bfac:      	ldr	x20, [sp, #0x38]
    bfb0:      	ldr	x21, [sp, #0x40]
    bfb4:      	ldr	x22, [sp, #0x48]
    bfb8:      	ldr	x23, [sp, #0x50]
    bfbc:      	ldr	x24, [sp, #0x58]
    bfc0:      	ldr	x25, [sp, #0x60]
    bfc4:      	ldr	x26, [sp, #0x68]
    bfc8:      	ldr	x29, [sp]
    bfcc:      	ldr	x30, [sp, #0x8]
    bfd0:      	add	sp, sp, #0x70
    bfd4:      	ret
    bfd8:      	sxtw	x5, w5
    bfdc:      	add	x16, sp, #0x10
    bfe0:      	str	x6, [x16]
    bfe4:      	cmp	x5, #0x0
    bfe8:      	cset	w6, gt
    bfec:      	movz	x16, #0x0, lsl #48
    bff0:      	sub	x7, x16, x5
    bff4:      	add	x16, sp, #0x10
    bff8:      	str	x4, [x16, #0x8]
    bffc:      	sub	x4, x7, #0x1
    c000:      	uxtb	w16, w6
    c004:      	cmp	w16, wzr
    c008:      	b.eq	0xc0e8 <_stogir.vector-comparison.operands+0x2cc>
    c00c:      	ldr	x7, [x0, #0x8]
    c010:      	cmp	x5, x7
    c014:      	b.ge	0xc0e0 <_stogir.vector-comparison.operands+0x2c4>
    c018:      	add	x7, x0, #0x78
    c01c:      	ldr	x7, [x7, #0x8]
    c020:      	cmp	x5, x7
    c024:      	b.ge	0xc19c <_stogir.vector-comparison.operands+0x380>
    c028:      	ldr	x7, [x0, #0x78]
    c02c:      	add	x7, x7, x5, lsl #2
    c030:      	ldr	w7, [x7]
    c034:      	sxtw	x7, w7
    c038:      	cmp	x7, #0x0
    c03c:      	cset	w7, ge
    c040:      	ubfx	x7, x7, #0, #8
    c044:      	b	0xc1a0 <_stogir.vector-comparison.operands+0x384>
    c048:      	movz	x7, #0x0, lsl #48
    c04c:      	b	0xbf00 <_stogir.vector-comparison.operands+0xe4>
    c050:      	movz	w5, #0x0, lsl #16
    c054:      	movz	x4, #0x0, lsl #48
    c058:      	movz	x0, #0x0, lsl #48
    c05c:      	ubfx	x5, x5, #0, #32
    c060:      	lsr	x16, x5, #0
    c064:      	cmp	x16, #0x1
    c068:      	b.eq	0xc084 <_stogir.vector-comparison.operands+0x268>
    c06c:      	b.lo	0xc074 <_stogir.vector-comparison.operands+0x258>
    c070:      	b	0xc088 <_stogir.vector-comparison.operands+0x26c>
    c074:      	cmp	x16, #0x0
    c078:      	b.eq	0xc080 <_stogir.vector-comparison.operands+0x264>
    c07c:      	b	0xc088 <_stogir.vector-comparison.operands+0x26c>
    c080:      	b	0xc08c <_stogir.vector-comparison.operands+0x270>
    c084:      	b	0xc138 <_stogir.vector-comparison.operands+0x31c>
    c088:      	b	0xc2d8 <_stogir.vector-comparison.operands+0x4bc>
    c08c:      	mov	x21, x8
    c090:      	mov	x0, #0x1                ; =1
    c094:      	mov	x1, #0x21               ; =33
    c098:      	b	0xbf9c <_stogir.vector-comparison.operands+0x180>
    c09c:      	ldr	x0, [x0, #0x28]
    c0a0:      	add	x0, x0, x4, lsl #4
    c0a4:      	ldr	x4, [x0]
    c0a8:      	ldr	x0, [x0, #0x8]
    c0ac:      	mov	w5, #0x1                ; =1
    c0b0:      	b	0xc05c <_stogir.vector-comparison.operands+0x240>
    c0b4:      	movz	x7, #0x0, lsl #48
    c0b8:      	cmp	x7, #0x0
    c0bc:      	b.eq	0xc050 <_stogir.vector-comparison.operands+0x234>
    c0c0:      	uxtb	w16, w6
    c0c4:      	cmp	w16, wzr
    c0c8:      	b.eq	0xc09c <_stogir.vector-comparison.operands+0x280>
    c0cc:      	ldr	x0, [x0]
    c0d0:      	add	x0, x0, x5, lsl #4
    c0d4:      	ldr	x4, [x0]
    c0d8:      	ldr	x0, [x0, #0x8]
    c0dc:      	b	0xc0ac <_stogir.vector-comparison.operands+0x290>
    c0e0:      	movz	x7, #0x0, lsl #48
    c0e4:      	b	0xc0b8 <_stogir.vector-comparison.operands+0x29c>
    c0e8:      	cmp	x5, #0x0
    c0ec:      	b.ge	0xc0b4 <_stogir.vector-comparison.operands+0x298>
    c0f0:      	add	x10, x0, #0x28
    c0f4:      	add	x11, x0, #0x50
    c0f8:      	ldr	x10, [x10, #0x8]
    c0fc:      	ldr	x11, [x11, #0x8]
    c100:      	cmp	x10, x11
    c104:      	b.ne	0xc194 <_stogir.vector-comparison.operands+0x378>
    c108:      	cmp	x7, x10
    c10c:      	b.gt	0xc2c8 <_stogir.vector-comparison.operands+0x4ac>
    c110:      	ldr	x7, [x0, #0x50]
    c114:      	add	x7, x7, x4, lsl #2
    c118:      	ldr	w7, [x7]
    c11c:      	sxtw	x7, w7
    c120:      	cmp	x7, #0x0
    c124:      	cset	w7, gt
    c128:      	ubfx	x7, x7, #0, #8
    c12c:      	b	0xc2cc <_stogir.vector-comparison.operands+0x4b0>
    c130:      	movz	x7, #0x0, lsl #48
    c134:      	b	0xbef8 <_stogir.vector-comparison.operands+0xdc>
    c138:      	sxtw	x19, w3
    c13c:      	add	x16, sp, #0x10
    c140:      	orr	x20, x16, xzr
    c144:      	add	x16, sp, #0x20
    c148:      	str	x4, [x16]
    c14c:      	add	x16, sp, #0x20
    c150:      	str	x0, [x16, #0x8]
    c154:      	mov	x0, x20
    c158:      	mov	x21, x8
    c15c:      	mov	w22, w1
    c160:      	mov	w23, w2
    c164:      	mov	w24, w3
    c168:      	bl	0xc168 <_stogir.vector-comparison.operands+0x34c>
		000000000000c168:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    c16c:      	cmp	x19, #0x4
    c170:      	b.eq	0xc1a4 <_stogir.vector-comparison.operands+0x388>
    c174:      	cmp	x19, #0x8
    c178:      	b.eq	0xc1a4 <_stogir.vector-comparison.operands+0x388>
    c17c:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c17c:  ARM64_RELOC_PAGE21	l_stogir.488
    c180:      	ldr	x16, [x16]
		000000000000c180:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    c184:      	orr	x9, x16, xzr
    c188:      	mov	x0, #0x1                ; =1
    c18c:      	mov	x1, #0x33               ; =51
    c190:      	b	0xc098 <_stogir.vector-comparison.operands+0x27c>
    c194:      	movz	x7, #0x0, lsl #48
    c198:      	b	0xc0b8 <_stogir.vector-comparison.operands+0x29c>
    c19c:      	movz	x7, #0x0, lsl #48
    c1a0:      	b	0xc0e4 <_stogir.vector-comparison.operands+0x2c8>
    c1a4:      	uxtb	w19, w0
    c1a8:      	orr	x0, x19, xzr
    c1ac:      	orr	w25, w0, wzr
    c1b0:      	mov	w0, w22
    c1b4:      	mov	w1, w25
    c1b8:      	bl	0xc1b8 <_stogir.vector-comparison.operands+0x39c>
		000000000000c1b8:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    c1bc:      	cmp	x0, #0x0
    c1c0:      	b.eq	0xc17c <_stogir.vector-comparison.operands+0x360>
    c1c4:      	add	x16, sp, #0x20
    c1c8:      	orr	x22, x16, xzr
    c1cc:      	mov	x0, x20
    c1d0:      	bl	0xc1d0 <_stogir.vector-comparison.operands+0x3b4>
		000000000000c1d0:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    c1d4:      	uxtb	w26, w0
    c1d8:      	mov	x0, x22
    c1dc:      	bl	0xc1dc <_stogir.vector-comparison.operands+0x3c0>
		000000000000c1dc:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    c1e0:      	uxtb	w0, w0
    c1e4:      	cmp	x26, x0
    c1e8:      	b.ne	0xc17c <_stogir.vector-comparison.operands+0x360>
    c1ec:      	mov	x0, x20
    c1f0:      	bl	0xc1f0 <_stogir.vector-comparison.operands+0x3d4>
		000000000000c1f0:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c1f4:      	uxtb	w0, w0
    c1f8:      	cmp	x0, #0x48
    c1fc:      	b.eq	0xc17c <_stogir.vector-comparison.operands+0x360>
    c200:      	mov	x0, x20
    c204:      	bl	0xc204 <_stogir.vector-comparison.operands+0x3e8>
		000000000000c204:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c208:      	uxtb	w0, w0
    c20c:      	cmp	x0, #0x46
    c210:      	b.eq	0xc17c <_stogir.vector-comparison.operands+0x360>
    c214:      	mov	x0, x22
    c218:      	bl	0xc218 <_stogir.vector-comparison.operands+0x3fc>
		000000000000c218:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c21c:      	uxtb	w0, w0
    c220:      	cmp	x0, #0x48
    c224:      	b.eq	0xc17c <_stogir.vector-comparison.operands+0x360>
    c228:      	mov	x0, x22
    c22c:      	bl	0xc22c <_stogir.vector-comparison.operands+0x410>
		000000000000c22c:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c230:      	uxtb	w0, w0
    c234:      	cmp	x0, #0x46
    c238:      	b.eq	0xc17c <_stogir.vector-comparison.operands+0x360>
    c23c:      	mov	w0, w23
    c240:      	bl	0xc240 <_stogir.vector-comparison.operands+0x424>
		000000000000c240:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    c244:      	cmp	x0, #0x0
    c248:      	b.eq	0xc17c <_stogir.vector-comparison.operands+0x360>
    c24c:      	mov	w0, w23
    c250:      	bl	0xc250 <_stogir.vector-comparison.operands+0x434>
		000000000000c250:  ARM64_RELOC_BRANCH26	_stogir.types.base-type
    c254:      	bl	0xc254 <_stogir.vector-comparison.operands+0x438>
		000000000000c254:  ARM64_RELOC_BRANCH26	_stogir.types.integer?
    c258:      	cmp	x0, #0x0
    c25c:      	b.eq	0xc17c <_stogir.vector-comparison.operands+0x360>
    c260:      	mov	w0, w23
    c264:      	bl	0xc264 <_stogir.vector-comparison.operands+0x448>
		000000000000c264:  ARM64_RELOC_BRANCH26	_stogir.types.lanes
    c268:      	orr	w20, w0, wzr
    c26c:      	mov	w0, w25
    c270:      	bl	0xc270 <_stogir.vector-comparison.operands+0x454>
		000000000000c270:  ARM64_RELOC_BRANCH26	_stogir.types.lanes
    c274:      	sxtw	x20, w20
    c278:      	sxtw	x0, w0
    c27c:      	cmp	x20, x0
    c280:      	b.ne	0xc17c <_stogir.vector-comparison.operands+0x360>
    c284:      	mov	w0, w23
    c288:      	bl	0xc288 <_stogir.vector-comparison.operands+0x46c>
		000000000000c288:  ARM64_RELOC_BRANCH26	_stogir.types.base-type
    c28c:      	mov	w1, w24
    c290:      	bl	0xc290 <_stogir.vector-comparison.operands+0x474>
		000000000000c290:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    c294:      	orr	w20, w0, wzr
    c298:      	mov	w0, w25
    c29c:      	bl	0xc29c <_stogir.vector-comparison.operands+0x480>
		000000000000c29c:  ARM64_RELOC_BRANCH26	_stogir.types.base-type
    c2a0:      	sxtw	x20, w20
    c2a4:      	mov	w1, w24
    c2a8:      	bl	0xc2a8 <_stogir.vector-comparison.operands+0x48c>
		000000000000c2a8:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    c2ac:      	sxtw	x0, w0
    c2b0:      	cmp	x20, x0
    c2b4:      	b.ne	0xc17c <_stogir.vector-comparison.operands+0x360>
    c2b8:      	and	x9, x19, #0xffffffff
    c2bc:      	movz	x0, #0x0, lsl #48
    c2c0:      	movz	x1, #0x0, lsl #48
    c2c4:      	b	0xc190 <_stogir.vector-comparison.operands+0x374>
    c2c8:      	movz	x7, #0x0, lsl #48
    c2cc:      	b	0xc198 <_stogir.vector-comparison.operands+0x37c>
    c2d0:      	brk	#0
    c2d4:      	b	0xc2d0 <_stogir.vector-comparison.operands+0x4b4>
    c2d8:      	brk	#0
    c2dc:      	b	0xc2d8 <_stogir.vector-comparison.operands+0x4bc>

000000000000c2e0 <_stogir.vector-arithmetic.unary?>:
    c2e0:      	sxtw	x0, w0
    c2e4:      	cmp	x0, #0x1f
    c2e8:      	b.ne	0xc304 <_stogir.vector-arithmetic.unary?+0x24>
    c2ec:      	mov	x0, #0x1                ; =1
    c2f0:      	b	0xc300 <_stogir.vector-arithmetic.unary?+0x20>
    c2f4:      	cmp	x0, #0x39
    c2f8:      	cset	w0, eq
    c2fc:      	ubfx	x0, x0, #0, #8
    c300:      	ret
    c304:      	cmp	x0, #0x20
    c308:      	b.ne	0xc314 <_stogir.vector-arithmetic.unary?+0x34>
    c30c:      	mov	x0, #0x1                ; =1
    c310:      	b	0xc300 <_stogir.vector-arithmetic.unary?+0x20>
    c314:      	cmp	x0, #0x2d
    c318:      	b.ne	0xc324 <_stogir.vector-arithmetic.unary?+0x44>
    c31c:      	mov	x0, #0x1                ; =1
    c320:      	b	0xc300 <_stogir.vector-arithmetic.unary?+0x20>
    c324:      	cmp	x0, #0x36
    c328:      	b.ne	0xc334 <_stogir.vector-arithmetic.unary?+0x54>
    c32c:      	mov	x0, #0x1                ; =1
    c330:      	b	0xc300 <_stogir.vector-arithmetic.unary?+0x20>
    c334:      	cmp	x0, #0x37
    c338:      	b.ne	0xc344 <_stogir.vector-arithmetic.unary?+0x64>
    c33c:      	mov	x0, #0x1                ; =1
    c340:      	b	0xc300 <_stogir.vector-arithmetic.unary?+0x20>
    c344:      	cmp	x0, #0x38
    c348:      	b.ne	0xc2f4 <_stogir.vector-arithmetic.unary?+0x14>
    c34c:      	mov	x0, #0x1                ; =1
    c350:      	b	0xc300 <_stogir.vector-arithmetic.unary?+0x20>

000000000000c354 <_stogir.vector-arithmetic.operands>:
    c354:      	sub	sp, sp, #0xb0
    c358:      	str	x29, [sp]
    c35c:      	str	x30, [sp, #0x8]
    c360:      	mov	x29, sp
    c364:      	str	x19, [sp, #0x60]
    c368:      	str	x20, [sp, #0x68]
    c36c:      	str	x21, [sp, #0x70]
    c370:      	str	x22, [sp, #0x78]
    c374:      	str	x23, [sp, #0x80]
    c378:      	str	x24, [sp, #0x88]
    c37c:      	str	x25, [sp, #0x90]
    c380:      	str	x26, [sp, #0x98]
    c384:      	str	x27, [sp, #0xa0]
    c388:      	str	x28, [sp, #0xa8]
    c38c:      	mov	x19, x8
    c390:      	mov	x20, x0
    c394:      	mov	w0, w1
    c398:      	mov	w21, w1
    c39c:      	mov	w1, w2
    c3a0:      	mov	w22, w2
    c3a4:      	mov	w23, w3
    c3a8:      	mov	w24, w4
    c3ac:      	mov	w25, w5
    c3b0:      	bl	0xc3b0 <_stogir.vector-arithmetic.operands+0x5c>
		000000000000c3b0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    c3b4:      	cmp	x0, #0x0
    c3b8:      	b.eq	0xc3d0 <_stogir.vector-arithmetic.operands+0x7c>
    c3bc:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c3bc:  ARM64_RELOC_PAGE21	l_stogir.489
    c3c0:      	ldr	x16, [x16]
		000000000000c3c0:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    c3c4:      	orr	x26, x16, xzr
    c3c8:      	movz	x27, #0x0, lsl #48
    c3cc:      	b	0xc3e0 <_stogir.vector-arithmetic.operands+0x8c>
    c3d0:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c3d0:  ARM64_RELOC_PAGE21	l_stogir.490
    c3d4:      	ldr	x16, [x16]
		000000000000c3d4:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    c3d8:      	orr	x26, x16, xzr
    c3dc:      	mov	x27, #0x37              ; =55
    c3e0:      	sxtw	x22, w22
    c3e4:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c3e4:  ARM64_RELOC_PAGE21	l_stogir.491
    c3e8:      	ldr	x16, [x16]
		000000000000c3e8:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    c3ec:      	orr	x28, x16, xzr
    c3f0:      	add	x16, sp, #0x10
    c3f4:      	orr	x0, x16, xzr
    c3f8:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c3f8:  ARM64_RELOC_PAGE21	l_stogir.492
    c3fc:      	ldr	x16, [x16]
		000000000000c3fc:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    c400:      	orr	x1, x16, xzr
    c404:      	add	x2, x20, #0x78
    c408:      	add	x3, x20, #0x28
    c40c:      	add	x4, x20, #0x50
    c410:      	movz	x5, #0x0, lsl #48
    c414:      	b	0xc578 <_stogir.vector-arithmetic.operands+0x224>
    c418:      	movz	x2, #0x0, lsl #48
    c41c:      	b	0xc42c <_stogir.vector-arithmetic.operands+0xd8>
    c420:      	movz	x2, #0x0, lsl #48
    c424:      	b	0xc434 <_stogir.vector-arithmetic.operands+0xe0>
    c428:      	movz	x2, #0x0, lsl #48
    c42c:      	b	0xc43c <_stogir.vector-arithmetic.operands+0xe8>
    c430:      	movz	x2, #0x0, lsl #48
    c434:      	b	0xc43c <_stogir.vector-arithmetic.operands+0xe8>
    c438:      	movz	x2, #0x0, lsl #48
    c43c:      	cmp	x2, #0x0
    c440:      	b.eq	0xc47c <_stogir.vector-arithmetic.operands+0x128>
    c444:      	uxtb	w16, w1
    c448:      	cmp	w16, wzr
    c44c:      	b.eq	0xc464 <_stogir.vector-arithmetic.operands+0x110>
    c450:      	ldr	x1, [x20]
    c454:      	add	x0, x1, x0, lsl #4
    c458:      	ldr	x1, [x0]
    c45c:      	ldr	x0, [x0, #0x8]
    c460:      	b	0xc474 <_stogir.vector-arithmetic.operands+0x120>
    c464:      	ldr	x0, [x20, #0x28]
    c468:      	add	x0, x0, x3, lsl #4
    c46c:      	ldr	x1, [x0]
    c470:      	ldr	x0, [x0, #0x8]
    c474:      	mov	w2, #0x1                ; =1
    c478:      	b	0xc488 <_stogir.vector-arithmetic.operands+0x134>
    c47c:      	movz	w2, #0x0, lsl #16
    c480:      	movz	x1, #0x0, lsl #48
    c484:      	movz	x0, #0x0, lsl #48
    c488:      	ubfx	x2, x2, #0, #32
    c48c:      	lsr	x16, x2, #0
    c490:      	cmp	x16, #0x1
    c494:      	b.eq	0xc4b0 <_stogir.vector-arithmetic.operands+0x15c>
    c498:      	b.lo	0xc4a0 <_stogir.vector-arithmetic.operands+0x14c>
    c49c:      	b	0xc4b4 <_stogir.vector-arithmetic.operands+0x160>
    c4a0:      	cmp	x16, #0x0
    c4a4:      	b.eq	0xc4ac <_stogir.vector-arithmetic.operands+0x158>
    c4a8:      	b	0xc4b4 <_stogir.vector-arithmetic.operands+0x160>
    c4ac:      	b	0xc4b8 <_stogir.vector-arithmetic.operands+0x164>
    c4b0:      	b	0xc4c4 <_stogir.vector-arithmetic.operands+0x170>
    c4b4:      	b	0xc854 <_stogir.vector-arithmetic.operands+0x500>
    c4b8:      	ldr	x26, [sp, #0x50]
    c4bc:      	mov	x27, #0x21              ; =33
    c4c0:      	b	0xc548 <_stogir.vector-arithmetic.operands+0x1f4>
    c4c4:      	add	x16, sp, #0x10
    c4c8:      	str	x1, [x16]
    c4cc:      	add	x16, sp, #0x10
    c4d0:      	str	x0, [x16, #0x8]
    c4d4:      	ldr	x0, [sp, #0x30]
    c4d8:      	bl	0xc4d8 <_stogir.vector-arithmetic.operands+0x184>
		000000000000c4d8:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    c4dc:      	uxtb	w0, w0
    c4e0:      	cmp	x0, x22
    c4e4:      	b.eq	0xc518 <_stogir.vector-arithmetic.operands+0x1c4>
    c4e8:      	cmp	x19, #0x1
    c4ec:      	b.ne	0xc540 <_stogir.vector-arithmetic.operands+0x1ec>
    c4f0:      	mov	w0, w21
    c4f4:      	bl	0xc4f4 <_stogir.vector-arithmetic.operands+0x1a0>
		000000000000c4f4:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.shift?
    c4f8:      	cmp	x0, #0x0
    c4fc:      	b.eq	0xc540 <_stogir.vector-arithmetic.operands+0x1ec>
    c500:      	ldr	x0, [sp, #0x30]
    c504:      	bl	0xc504 <_stogir.vector-arithmetic.operands+0x1b0>
		000000000000c504:  ARM64_RELOC_BRANCH26	_stogir.node.type-id
    c508:      	uxtb	w0, w0
    c50c:      	bl	0xc50c <_stogir.vector-arithmetic.operands+0x1b8>
		000000000000c50c:  ARM64_RELOC_BRANCH26	_stogir.types.integer?
    c510:      	cmp	x0, #0x0
    c514:      	b.eq	0xc540 <_stogir.vector-arithmetic.operands+0x1ec>
    c518:      	ldr	x0, [sp, #0x30]
    c51c:      	bl	0xc51c <_stogir.vector-arithmetic.operands+0x1c8>
		000000000000c51c:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c520:      	uxtb	w0, w0
    c524:      	cmp	x0, #0x48
    c528:      	b.eq	0xc540 <_stogir.vector-arithmetic.operands+0x1ec>
    c52c:      	ldr	x0, [sp, #0x30]
    c530:      	bl	0xc530 <_stogir.vector-arithmetic.operands+0x1dc>
		000000000000c530:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c534:      	uxtb	w0, w0
    c538:      	cmp	x0, #0x46
    c53c:      	b.ne	0xc548 <_stogir.vector-arithmetic.operands+0x1f4>
    c540:      	ldr	x26, [sp, #0x38]
    c544:      	mov	x27, #0x32              ; =50
    c548:      	add	x0, x19, #0x1
    c54c:      	sxtw	x19, w0
    c550:      	ldr	x0, [sp, #0x30]
    c554:      	ldr	x1, [sp, #0x38]
    c558:      	mov	x2, x23
    c55c:      	ldr	w23, [sp, #0x40]
    c560:      	mov	x3, x24
    c564:      	ldr	w24, [sp, #0x48]
    c568:      	mov	x4, x28
    c56c:      	ldr	x28, [sp, #0x50]
    c570:      	mov	x5, x19
    c574:      	ldr	x19, [sp, #0x58]
    c578:      	str	x0, [sp, #0x30]
    c57c:      	mov	w0, w21
    c580:      	str	x1, [sp, #0x38]
    c584:      	str	w23, [sp, #0x40]
    c588:      	mov	x23, x2
    c58c:      	str	w24, [sp, #0x48]
    c590:      	mov	x24, x3
    c594:      	str	x28, [sp, #0x50]
    c598:      	mov	x28, x4
    c59c:      	str	x19, [sp, #0x58]
    c5a0:      	mov	x19, x5
    c5a4:      	bl	0xc5a4 <_stogir.vector-arithmetic.operands+0x250>
		000000000000c5a4:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.unary?
    c5a8:      	cmp	x0, #0x0
    c5ac:      	b.eq	0xc5b8 <_stogir.vector-arithmetic.operands+0x264>
    c5b0:      	mov	x0, #0x1                ; =1
    c5b4:      	b	0xc5bc <_stogir.vector-arithmetic.operands+0x268>
    c5b8:      	mov	x0, #0x2                ; =2
    c5bc:      	cmp	x19, x0
    c5c0:      	b.ge	0xc674 <_stogir.vector-arithmetic.operands+0x320>
    c5c4:      	cmp	x19, #0x0
    c5c8:      	b.ne	0xc5d4 <_stogir.vector-arithmetic.operands+0x280>
    c5cc:      	ldr	w0, [sp, #0x40]
    c5d0:      	b	0xc5d8 <_stogir.vector-arithmetic.operands+0x284>
    c5d4:      	ldr	w0, [sp, #0x48]
    c5d8:      	sxtw	x0, w0
    c5dc:      	cmp	x0, #0x0
    c5e0:      	cset	w1, gt
    c5e4:      	movz	x16, #0x0, lsl #48
    c5e8:      	sub	x2, x16, x0
    c5ec:      	sub	x3, x2, #0x1
    c5f0:      	uxtb	w16, w1
    c5f4:      	cmp	w16, wzr
    c5f8:      	b.eq	0xc634 <_stogir.vector-arithmetic.operands+0x2e0>
    c5fc:      	ldr	x2, [x20, #0x8]
    c600:      	cmp	x0, x2
    c604:      	b.ge	0xc430 <_stogir.vector-arithmetic.operands+0xdc>
    c608:      	ldr	x2, [x23, #0x8]
    c60c:      	cmp	x0, x2
    c610:      	b.ge	0xc420 <_stogir.vector-arithmetic.operands+0xcc>
    c614:      	ldr	x2, [x20, #0x78]
    c618:      	add	x2, x2, x0, lsl #2
    c61c:      	ldr	w2, [x2]
    c620:      	sxtw	x2, w2
    c624:      	cmp	x2, #0x0
    c628:      	cset	w2, ge
    c62c:      	ubfx	x2, x2, #0, #8
    c630:      	b	0xc424 <_stogir.vector-arithmetic.operands+0xd0>
    c634:      	cmp	x0, #0x0
    c638:      	b.ge	0xc438 <_stogir.vector-arithmetic.operands+0xe4>
    c63c:      	ldr	x4, [x24, #0x8]
    c640:      	ldr	x5, [x28, #0x8]
    c644:      	cmp	x4, x5
    c648:      	b.ne	0xc428 <_stogir.vector-arithmetic.operands+0xd4>
    c64c:      	cmp	x2, x4
    c650:      	b.gt	0xc418 <_stogir.vector-arithmetic.operands+0xc4>
    c654:      	ldr	x2, [x20, #0x50]
    c658:      	add	x2, x2, x3, lsl #2
    c65c:      	ldr	w2, [x2]
    c660:      	sxtw	x2, w2
    c664:      	cmp	x2, #0x0
    c668:      	cset	w2, gt
    c66c:      	ubfx	x2, x2, #0, #8
    c670:      	b	0xc41c <_stogir.vector-arithmetic.operands+0xc8>
    c674:      	sxtw	x25, w25
    c678:      	cmp	x25, #0x0
    c67c:      	b.ne	0xc688 <_stogir.vector-arithmetic.operands+0x334>
    c680:      	movz	x0, #0x0, lsl #48
    c684:      	b	0xc68c <_stogir.vector-arithmetic.operands+0x338>
    c688:      	mov	x0, #0x1                ; =1
    c68c:      	cmp	x0, #0x0
    c690:      	b.eq	0xc6c4 <_stogir.vector-arithmetic.operands+0x370>
    c694:      	sxtw	x21, w21
    c698:      	cmp	x21, #0x1d
    c69c:      	b.ne	0xc784 <_stogir.vector-arithmetic.operands+0x430>
    c6a0:      	mov	x0, #0x1                ; =1
    c6a4:      	b	0xc790 <_stogir.vector-arithmetic.operands+0x43c>
    c6a8:      	mov	x0, #0x1                ; =1
    c6ac:      	cmp	x0, #0x0
    c6b0:      	b.eq	0xc728 <_stogir.vector-arithmetic.operands+0x3d4>
    c6b4:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c6b4:  ARM64_RELOC_PAGE21	l_stogir.493
    c6b8:      	ldr	x16, [x16]
		000000000000c6b8:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    c6bc:      	orr	x26, x16, xzr
    c6c0:      	mov	x27, #0x23              ; =35
    c6c4:      	cmp	x27, #0x0
    c6c8:      	b.ne	0xc6dc <_stogir.vector-arithmetic.operands+0x388>
    c6cc:      	and	x26, x22, #0xffffffff
    c6d0:      	movz	x0, #0x0, lsl #48
    c6d4:      	movz	x27, #0x0, lsl #48
    c6d8:      	b	0xc6e0 <_stogir.vector-arithmetic.operands+0x38c>
    c6dc:      	mov	x0, #0x1                ; =1
    c6e0:      	ldr	x1, [sp, #0x58]
    c6e4:      	str	x0, [x1]
    c6e8:      	str	x26, [x1, #0x8]
    c6ec:      	str	x27, [x1, #0x10]
    c6f0:      	ldr	x19, [sp, #0x60]
    c6f4:      	ldr	x20, [sp, #0x68]
    c6f8:      	ldr	x21, [sp, #0x70]
    c6fc:      	ldr	x22, [sp, #0x78]
    c700:      	ldr	x23, [sp, #0x80]
    c704:      	ldr	x24, [sp, #0x88]
    c708:      	ldr	x25, [sp, #0x90]
    c70c:      	ldr	x26, [sp, #0x98]
    c710:      	ldr	x27, [sp, #0xa0]
    c714:      	ldr	x28, [sp, #0xa8]
    c718:      	ldr	x29, [sp]
    c71c:      	ldr	x30, [sp, #0x8]
    c720:      	add	sp, sp, #0xb0
    c724:      	ret
    c728:      	cmp	x25, #0x0
    c72c:      	cset	w0, gt
    c730:      	movz	x16, #0x0, lsl #48
    c734:      	sub	x1, x16, x25
    c738:      	sub	x2, x1, #0x1
    c73c:      	uxtb	w16, w0
    c740:      	cmp	w16, wzr
    c744:      	b.eq	0xc80c <_stogir.vector-arithmetic.operands+0x4b8>
    c748:      	ldr	x1, [x20, #0x8]
    c74c:      	cmp	x25, x1
    c750:      	b.ge	0xc85c <_stogir.vector-arithmetic.operands+0x508>
    c754:      	add	x1, x20, #0x78
    c758:      	ldr	x1, [x1, #0x8]
    c75c:      	cmp	x25, x1
    c760:      	b.ge	0xc94c <_stogir.vector-arithmetic.operands+0x5f8>
    c764:      	ldr	x1, [x20, #0x78]
    c768:      	add	x1, x1, x25, lsl #2
    c76c:      	ldr	w1, [x1]
    c770:      	sxtw	x1, w1
    c774:      	cmp	x1, #0x0
    c778:      	cset	w1, ge
    c77c:      	ubfx	x1, x1, #0, #8
    c780:      	b	0xc950 <_stogir.vector-arithmetic.operands+0x5fc>
    c784:      	cmp	x21, #0x1e
    c788:      	cset	w0, eq
    c78c:      	ubfx	x0, x0, #0, #8
    c790:      	cmp	x0, #0x0
    c794:      	b.eq	0xc6a8 <_stogir.vector-arithmetic.operands+0x354>
    c798:      	movz	x0, #0x0, lsl #48
    c79c:      	b	0xc6ac <_stogir.vector-arithmetic.operands+0x358>
    c7a0:      	movz	w0, #0x0, lsl #16
    c7a4:      	uxtb	w16, w0
    c7a8:      	and	w0, w16, #0x2
    c7ac:      	uxtb	w0, w0
    c7b0:      	ubfx	x0, x0, #0, #8
    c7b4:      	cmp	x0, #0x0
    c7b8:      	cset	w0, eq
    c7bc:      	uxtb	w16, w0
    c7c0:      	cmp	w16, wzr
    c7c4:      	cset	x0, eq
    c7c8:      	cmp	x0, #0x0
    c7cc:      	b.ne	0xc808 <_stogir.vector-arithmetic.operands+0x4b4>
    c7d0:      	mov	x0, x19
    c7d4:      	bl	0xc7d4 <_stogir.vector-arithmetic.operands+0x480>
		000000000000c7d4:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c7d8:      	uxtb	w0, w0
    c7dc:      	cmp	x0, #0x65
    c7e0:      	b.eq	0xc808 <_stogir.vector-arithmetic.operands+0x4b4>
    c7e4:      	mov	x0, x19
    c7e8:      	bl	0xc7e8 <_stogir.vector-arithmetic.operands+0x494>
		000000000000c7e8:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c7ec:      	uxtb	w0, w0
    c7f0:      	cmp	x0, #0x66
    c7f4:      	b.eq	0xc808 <_stogir.vector-arithmetic.operands+0x4b4>
    c7f8:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c7f8:  ARM64_RELOC_PAGE21	l_stogir.494
    c7fc:      	ldr	x16, [x16]
		000000000000c7fc:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    c800:      	orr	x26, x16, xzr
    c804:      	mov	x27, #0x34              ; =52
    c808:      	b	0xc6c4 <_stogir.vector-arithmetic.operands+0x370>
    c80c:      	cmp	x25, #0x0
    c810:      	b.ge	0xc864 <_stogir.vector-arithmetic.operands+0x510>
    c814:      	add	x3, x20, #0x28
    c818:      	add	x4, x20, #0x50
    c81c:      	ldr	x3, [x3, #0x8]
    c820:      	ldr	x4, [x4, #0x8]
    c824:      	cmp	x3, x4
    c828:      	b.ne	0xc944 <_stogir.vector-arithmetic.operands+0x5f0>
    c82c:      	cmp	x1, x3
    c830:      	b.gt	0xc954 <_stogir.vector-arithmetic.operands+0x600>
    c834:      	ldr	x1, [x20, #0x50]
    c838:      	add	x1, x1, x2, lsl #2
    c83c:      	ldr	w1, [x1]
    c840:      	sxtw	x1, w1
    c844:      	cmp	x1, #0x0
    c848:      	cset	w1, gt
    c84c:      	ubfx	x1, x1, #0, #8
    c850:      	b	0xc958 <_stogir.vector-arithmetic.operands+0x604>
    c854:      	brk	#0
    c858:      	b	0xc854 <_stogir.vector-arithmetic.operands+0x500>
    c85c:      	movz	x1, #0x0, lsl #48
    c860:      	b	0xc868 <_stogir.vector-arithmetic.operands+0x514>
    c864:      	movz	x1, #0x0, lsl #48
    c868:      	cmp	x1, #0x0
    c86c:      	b.eq	0xc8a8 <_stogir.vector-arithmetic.operands+0x554>
    c870:      	uxtb	w16, w0
    c874:      	cmp	w16, wzr
    c878:      	b.eq	0xc890 <_stogir.vector-arithmetic.operands+0x53c>
    c87c:      	ldr	x0, [x20]
    c880:      	add	x0, x0, x25, lsl #4
    c884:      	ldr	x1, [x0]
    c888:      	ldr	x0, [x0, #0x8]
    c88c:      	b	0xc8a0 <_stogir.vector-arithmetic.operands+0x54c>
    c890:      	ldr	x0, [x20, #0x28]
    c894:      	add	x0, x0, x2, lsl #4
    c898:      	ldr	x1, [x0]
    c89c:      	ldr	x0, [x0, #0x8]
    c8a0:      	mov	w2, #0x1                ; =1
    c8a4:      	b	0xc8b4 <_stogir.vector-arithmetic.operands+0x560>
    c8a8:      	movz	w2, #0x0, lsl #16
    c8ac:      	movz	x1, #0x0, lsl #48
    c8b0:      	movz	x0, #0x0, lsl #48
    c8b4:      	ubfx	x2, x2, #0, #32
    c8b8:      	lsr	x16, x2, #0
    c8bc:      	cmp	x16, #0x1
    c8c0:      	b.eq	0xc8dc <_stogir.vector-arithmetic.operands+0x588>
    c8c4:      	b.lo	0xc8cc <_stogir.vector-arithmetic.operands+0x578>
    c8c8:      	b	0xc8e0 <_stogir.vector-arithmetic.operands+0x58c>
    c8cc:      	cmp	x16, #0x0
    c8d0:      	b.eq	0xc8d8 <_stogir.vector-arithmetic.operands+0x584>
    c8d4:      	b	0xc8e0 <_stogir.vector-arithmetic.operands+0x58c>
    c8d8:      	b	0xc8e4 <_stogir.vector-arithmetic.operands+0x590>
    c8dc:      	b	0xc8f8 <_stogir.vector-arithmetic.operands+0x5a4>
    c8e0:      	b	0xc95c <_stogir.vector-arithmetic.operands+0x608>
    c8e4:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c8e4:  ARM64_RELOC_PAGE21	l_stogir.495
    c8e8:      	ldr	x16, [x16]
		000000000000c8e8:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    c8ec:      	orr	x26, x16, xzr
    c8f0:      	mov	x27, #0x1d              ; =29
    c8f4:      	b	0xc808 <_stogir.vector-arithmetic.operands+0x4b4>
    c8f8:      	add	x16, sp, #0x20
    c8fc:      	str	x1, [x16]
    c900:      	add	x16, sp, #0x20
    c904:      	str	x0, [x16, #0x8]
    c908:      	cmp	x25, #0x0
    c90c:      	b.le	0xc7f8 <_stogir.vector-arithmetic.operands+0x4a4>
    c910:      	add	x16, sp, #0x20
    c914:      	orr	x19, x16, xzr
    c918:      	mov	x0, x19
    c91c:      	bl	0xc91c <_stogir.vector-arithmetic.operands+0x5c8>
		000000000000c91c:  ARM64_RELOC_BRANCH26	_stogir.node.opcode
    c920:      	uxtb	w0, w0
    c924:      	cmp	x0, #0x83
    c928:      	b.ge	0xc7a0 <_stogir.vector-arithmetic.operands+0x44c>
    c92c:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000c92c:  ARM64_RELOC_PAGE21	l_stogir.496
    c930:      	ldr	x16, [x16]
		000000000000c930:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    c934:      	orr	x1, x16, xzr
    c938:      	add	x0, x0, x1
    c93c:      	ldrb	w0, [x0]
    c940:      	b	0xc7a4 <_stogir.vector-arithmetic.operands+0x450>
    c944:      	movz	x1, #0x0, lsl #48
    c948:      	b	0xc868 <_stogir.vector-arithmetic.operands+0x514>
    c94c:      	movz	x1, #0x0, lsl #48
    c950:      	b	0xc860 <_stogir.vector-arithmetic.operands+0x50c>
    c954:      	movz	x1, #0x0, lsl #48
    c958:      	b	0xc948 <_stogir.vector-arithmetic.operands+0x5f4>
    c95c:      	brk	#0
    c960:      	b	0xc95c <_stogir.vector-arithmetic.operands+0x608>

000000000000c964 <_stogir.types.base-type>:
    c964:      	and	w1, w0, #0xf
    c968:      	sxtw	x0, w0
    c96c:      	ubfx	x1, x1, #0, #32
    c970:      	cmp	x0, #0x0
    c974:      	b.lt	0xc980 <_stogir.types.base-type+0x1c>
    c978:      	cmp	x0, #0xd
    c97c:      	b.le	0xc9a4 <_stogir.types.base-type+0x40>
    c980:      	cmp	x0, #0xf
    c984:      	b.le	0xc9a0 <_stogir.types.base-type+0x3c>
    c988:      	cmp	x0, #0x80
    c98c:      	b.ge	0xc9a0 <_stogir.types.base-type+0x3c>
    c990:      	cmp	x1, #0x1
    c994:      	b.lt	0xc9a0 <_stogir.types.base-type+0x3c>
    c998:      	cmp	x1, #0xd
    c99c:      	b.le	0xc9a4 <_stogir.types.base-type+0x40>
    c9a0:      	movn	x1, #0x0, lsl #48
    c9a4:      	mov	x0, x1
    c9a8:      	ret

000000000000c9ac <_stogir.types.lanes>:
    c9ac:      	sxtw	x1, w0
    c9b0:      	cmp	x1, #0xf
    c9b4:      	b.le	0xc9f4 <_stogir.types.lanes+0x48>
    c9b8:      	cmp	x1, #0x80
    c9bc:      	b.ge	0xc9f4 <_stogir.types.lanes+0x48>
    c9c0:      	and	w0, w0, #0xf
    c9c4:      	ubfx	x0, x0, #0, #32
    c9c8:      	cmp	x0, #0x1
    c9cc:      	b.lt	0xc9f4 <_stogir.types.lanes+0x48>
    c9d0:      	cmp	x0, #0xd
    c9d4:      	b.gt	0xc9f4 <_stogir.types.lanes+0x48>
    c9d8:      	ubfx	x0, x1, #4, #32
    c9dc:      	sub	w0, w0, #0x1
    c9e0:      	sxtw	x0, w0
    c9e4:      	mov	x16, #0x1               ; =1
    c9e8:      	lsl	x0, x16, x0
    c9ec:      	sxtw	x0, w0
    c9f0:      	b	0xca20 <_stogir.types.lanes+0x74>
    c9f4:      	cmp	x1, #0x0
    c9f8:      	b.lt	0xca1c <_stogir.types.lanes+0x70>
    c9fc:      	cmp	x1, #0xd
    ca00:      	b.gt	0xca1c <_stogir.types.lanes+0x70>
    ca04:      	cmp	x1, #0x0
    ca08:      	cset	w0, eq
    ca0c:      	uxtb	w16, w0
    ca10:      	cmp	w16, wzr
    ca14:      	cset	x0, eq
    ca18:      	b	0xca20 <_stogir.types.lanes+0x74>
    ca1c:      	movn	x0, #0x0, lsl #48
    ca20:      	ret

000000000000ca24 <_stogir.switch.key>:
    ca24:      	sub	sp, sp, #0x30
    ca28:      	str	x19, [sp]
    ca2c:      	str	x20, [sp, #0x8]
    ca30:      	str	x21, [sp, #0x10]
    ca34:      	str	x22, [sp, #0x18]
    ca38:      	str	x23, [sp, #0x20]
    ca3c:      	sxtw	x2, w2
    ca40:      	cmp	x2, #0x1
    ca44:      	b.lt	0xcabc <_stogir.switch.key+0x98>
    ca48:      	cmp	x2, #0xb
    ca4c:      	cset	w3, le
    ca50:      	uxtb	w16, w3
    ca54:      	cmp	w16, wzr
    ca58:      	b.eq	0xcabc <_stogir.switch.key+0x98>
    ca5c:      	sxtw	x1, w1
    ca60:      	cmp	x1, #0x0
    ca64:      	cset	w4, gt
    ca68:      	movz	x16, #0x0, lsl #48
    ca6c:      	sub	x5, x16, x1
    ca70:      	sub	x6, x5, #0x1
    ca74:      	uxtb	w16, w4
    ca78:      	cmp	w16, wzr
    ca7c:      	b.eq	0xcb3c <_stogir.switch.key+0x118>
    ca80:      	ldr	x5, [x0, #0x8]
    ca84:      	cmp	x1, x5
    ca88:      	b.ge	0xcb84 <_stogir.switch.key+0x160>
    ca8c:      	add	x5, x0, #0x78
    ca90:      	ldr	x5, [x5, #0x8]
    ca94:      	cmp	x1, x5
    ca98:      	b.ge	0xccc4 <_stogir.switch.key+0x2a0>
    ca9c:      	ldr	x5, [x0, #0x78]
    caa0:      	add	x5, x5, x1, lsl #2
    caa4:      	ldr	w5, [x5]
    caa8:      	sxtw	x5, w5
    caac:      	cmp	x5, #0x0
    cab0:      	cset	w5, ge
    cab4:      	ubfx	x5, x5, #0, #8
    cab8:      	b	0xccc8 <_stogir.switch.key+0x2a4>
    cabc:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000cabc:  ARM64_RELOC_PAGE21	l_stogir.497
    cac0:      	ldr	x16, [x16]
		000000000000cac0:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    cac4:      	orr	x0, x16, xzr
    cac8:      	mov	x1, #0x1                ; =1
    cacc:      	mov	x2, #0x24               ; =36
    cad0:      	str	x1, [x8]
    cad4:      	str	x0, [x8, #0x8]
    cad8:      	str	x2, [x8, #0x10]
    cadc:      	ldr	x19, [sp]
    cae0:      	ldr	x20, [sp, #0x8]
    cae4:      	ldr	x21, [sp, #0x10]
    cae8:      	ldr	x22, [sp, #0x18]
    caec:      	ldr	x23, [sp, #0x20]
    caf0:      	add	sp, sp, #0x30
    caf4:      	ret
    caf8:      	mov	w23, #0x1               ; =1
    cafc:      	cmp	x1, #0x0
    cb00:      	b.ge	0xcb24 <_stogir.switch.key+0x100>
    cb04:      	orr	w1, w4, wzr
    cb08:      	uxtb	w4, w4
    cb0c:      	ubfx	x1, x1, #0, #32
    cb10:      	ubfx	x1, x1, #8, #8
    cb14:      	cmp	x4, x1
    cb18:      	b.eq	0xcd6c <_stogir.switch.key+0x348>
    cb1c:      	cmp	x4, #0x49
    cb20:      	b.eq	0xcd6c <_stogir.switch.key+0x348>
    cb24:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000cb24:  ARM64_RELOC_PAGE21	l_stogir.498
    cb28:      	ldr	x16, [x16]
		000000000000cb28:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    cb2c:      	orr	x0, x16, xzr
    cb30:      	mov	x1, #0x1                ; =1
    cb34:      	mov	x2, #0x30               ; =48
    cb38:      	b	0xcad0 <_stogir.switch.key+0xac>
    cb3c:      	cmp	x1, #0x0
    cb40:      	b.ge	0xcb8c <_stogir.switch.key+0x168>
    cb44:      	add	x7, x0, #0x28
    cb48:      	add	x9, x0, #0x50
    cb4c:      	ldr	x7, [x7, #0x8]
    cb50:      	ldr	x9, [x9, #0x8]
    cb54:      	cmp	x7, x9
    cb58:      	b.ne	0xccbc <_stogir.switch.key+0x298>
    cb5c:      	cmp	x5, x7
    cb60:      	b.gt	0xcd64 <_stogir.switch.key+0x340>
    cb64:      	ldr	x5, [x0, #0x50]
    cb68:      	add	x5, x5, x6, lsl #2
    cb6c:      	ldr	w5, [x5]
    cb70:      	sxtw	x5, w5
    cb74:      	cmp	x5, #0x0
    cb78:      	cset	w5, gt
    cb7c:      	ubfx	x5, x5, #0, #8
    cb80:      	b	0xcd68 <_stogir.switch.key+0x344>
    cb84:      	movz	x5, #0x0, lsl #48
    cb88:      	b	0xcb90 <_stogir.switch.key+0x16c>
    cb8c:      	movz	x5, #0x0, lsl #48
    cb90:      	cmp	x5, #0x0
    cb94:      	b.eq	0xcbd0 <_stogir.switch.key+0x1ac>
    cb98:      	uxtb	w16, w4
    cb9c:      	cmp	w16, wzr
    cba0:      	b.eq	0xcbb8 <_stogir.switch.key+0x194>
    cba4:      	ldr	x0, [x0]
    cba8:      	add	x0, x0, x1, lsl #4
    cbac:      	ldr	x4, [x0]
    cbb0:      	ldr	x0, [x0, #0x8]
    cbb4:      	b	0xcbc8 <_stogir.switch.key+0x1a4>
    cbb8:      	ldr	x0, [x0, #0x28]
    cbbc:      	add	x0, x0, x6, lsl #4
    cbc0:      	ldr	x4, [x0]
    cbc4:      	ldr	x0, [x0, #0x8]
    cbc8:      	mov	w5, #0x1                ; =1
    cbcc:      	b	0xcbdc <_stogir.switch.key+0x1b8>
    cbd0:      	movz	w5, #0x0, lsl #16
    cbd4:      	movz	x4, #0x0, lsl #48
    cbd8:      	movz	x0, #0x0, lsl #48
    cbdc:      	ubfx	x5, x5, #0, #32
    cbe0:      	lsr	x16, x5, #0
    cbe4:      	cmp	x16, #0x1
    cbe8:      	b.eq	0xcc04 <_stogir.switch.key+0x1e0>
    cbec:      	b.lo	0xcbf4 <_stogir.switch.key+0x1d0>
    cbf0:      	b	0xcc08 <_stogir.switch.key+0x1e4>
    cbf4:      	cmp	x16, #0x0
    cbf8:      	b.eq	0xcc00 <_stogir.switch.key+0x1dc>
    cbfc:      	b	0xcc08 <_stogir.switch.key+0x1e4>
    cc00:      	b	0xcc0c <_stogir.switch.key+0x1e8>
    cc04:      	b	0xcc24 <_stogir.switch.key+0x200>
    cc08:      	b	0xce00 <_stogir.switch.key+0x3dc>
    cc0c:      	adrp	x16, 0xc000 <_stogir.vector-comparison.operands+0x1e4>
		000000000000cc0c:  ARM64_RELOC_PAGE21	l_stogir.499
    cc10:      	ldr	x16, [x16]
		000000000000cc10:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    cc14:      	orr	x0, x16, xzr
    cc18:      	mov	x1, #0x1                ; =1
    cc1c:      	mov	x2, #0x1c               ; =28
    cc20:      	b	0xcb38 <_stogir.switch.key+0x114>
    cc24:      	cmp	x2, #0x1
    cc28:      	cset	w5, eq
    cc2c:      	cmp	x2, #0x0
    cc30:      	cset	w6, eq
    cc34:      	cmp	x2, #0x2
    cc38:      	cset	w7, eq
    cc3c:      	cmp	x2, #0x7
    cc40:      	cset	w9, eq
    cc44:      	cmp	x2, #0x8
    cc48:      	cset	w10, eq
    cc4c:      	cmp	x2, #0x3
    cc50:      	cset	w11, eq
    cc54:      	cmp	x2, #0x9
    cc58:      	cset	w12, eq
    cc5c:      	cmp	x2, #0x4
    cc60:      	cset	w13, eq
    cc64:      	cmp	x2, #0xa
    cc68:      	cset	w14, eq
    cc6c:      	cmp	x2, #0xd
    cc70:      	cset	w15, eq
    cc74:      	cmp	x2, #0x5
    cc78:      	cset	w19, eq
    cc7c:      	cmp	x2, #0xb
    cc80:      	cset	w20, eq
    cc84:      	cmp	x2, #0xc
    cc88:      	cset	w21, eq
    cc8c:      	cmp	x2, #0x6
    cc90:      	cset	w22, eq
    cc94:      	uxtb	w16, w22
    cc98:      	cmp	w16, wzr
    cc9c:      	mov	w16, #0x8               ; =8
    cca0:      	movn	w17, #0x0, lsl #16
    cca4:      	csel	w22, w16, w17, ne
    cca8:      	uxtb	w16, w6
    ccac:      	cmp	w16, wzr
    ccb0:      	b.eq	0xcccc <_stogir.switch.key+0x2a8>
    ccb4:      	movz	w23, #0x0, lsl #16
    ccb8:      	b	0xcafc <_stogir.switch.key+0xd8>
    ccbc:      	movz	x5, #0x0, lsl #48
    ccc0:      	b	0xcb90 <_stogir.switch.key+0x16c>
    ccc4:      	movz	x5, #0x0, lsl #48
    ccc8:      	b	0xcb88 <_stogir.switch.key+0x164>
    cccc:      	uxtb	w16, w5
    ccd0:      	cmp	w16, wzr
    ccd4:      	b.ne	0xcaf8 <_stogir.switch.key+0xd4>
    ccd8:      	uxtb	w16, w7
    ccdc:      	cmp	w16, wzr
    cce0:      	b.ne	0xcaf8 <_stogir.switch.key+0xd4>
    cce4:      	uxtb	w16, w9
    cce8:      	cmp	w16, wzr
    ccec:      	b.ne	0xcaf8 <_stogir.switch.key+0xd4>
    ccf0:      	uxtb	w16, w10
    ccf4:      	cmp	w16, wzr
    ccf8:      	b.ne	0xcaf8 <_stogir.switch.key+0xd4>
    ccfc:      	uxtb	w16, w11
    cd00:      	cmp	w16, wzr
    cd04:      	b.ne	0xcdf8 <_stogir.switch.key+0x3d4>
    cd08:      	uxtb	w16, w12
    cd0c:      	cmp	w16, wzr
    cd10:      	b.ne	0xcdf8 <_stogir.switch.key+0x3d4>
    cd14:      	uxtb	w16, w13
    cd18:      	cmp	w16, wzr
    cd1c:      	b.ne	0xcebc <_stogir.switch.key+0x498>
    cd20:      	uxtb	w16, w14
    cd24:      	cmp	w16, wzr
    cd28:      	b.ne	0xcebc <_stogir.switch.key+0x498>
    cd2c:      	uxtb	w16, w15
    cd30:      	cmp	w16, wzr
    cd34:      	b.ne	0xcebc <_stogir.switch.key+0x498>
    cd38:      	uxtb	w16, w19
    cd3c:      	cmp	w16, wzr
    cd40:      	b.ne	0xcec4 <_stogir.switch.key+0x4a0>
    cd44:      	uxtb	w16, w20
    cd48:      	cmp	w16, wzr
    cd4c:      	b.ne	0xcec4 <_stogir.switch.key+0x4a0>
    cd50:      	uxtb	w16, w21
    cd54:      	cmp	w16, wzr
    cd58:      	b.ne	0xcec4 <_stogir.switch.key+0x4a0>
    cd5c:      	mov	w23, w22
    cd60:      	b	0xcec8 <_stogir.switch.key+0x4a4>
    cd64:      	movz	x5, #0x0, lsl #48
    cd68:      	b	0xccc0 <_stogir.switch.key+0x29c>
    cd6c:      	cmp	x1, x2
    cd70:      	b.ne	0xcb24 <_stogir.switch.key+0x100>
    cd74:      	lsl	w1, w23, #3
    cd78:      	orr	w4, w0, wzr
    cd7c:      	sxtw	x1, w1
    cd80:      	ubfx	x4, x4, #0, #32
    cd84:      	lsr	x0, x0, #32
    cd88:      	ubfx	x0, x0, #0, #32
    cd8c:      	lsl	x0, x0, #32
    cd90:      	orr	x0, x0, x4
    cd94:      	cmp	x1, #0x40
    cd98:      	b.ge	0xcda8 <_stogir.switch.key+0x384>
    cd9c:      	lsr	x1, x0, x1
    cda0:      	cmp	x1, #0x0
    cda4:      	b.ne	0xcb24 <_stogir.switch.key+0x100>
    cda8:      	uxtb	w16, w5
    cdac:      	cmp	w16, wzr
    cdb0:      	b.eq	0xcdbc <_stogir.switch.key+0x398>
    cdb4:      	cmp	x0, #0x1
    cdb8:      	b.hi	0xcb24 <_stogir.switch.key+0x100>
    cdbc:      	cmp	x2, #0x7
    cdc0:      	b.lt	0xcde4 <_stogir.switch.key+0x3c0>
    cdc4:      	uxtb	w16, w3
    cdc8:      	cmp	w16, wzr
    cdcc:      	b.eq	0xcde4 <_stogir.switch.key+0x3c0>
    cdd0:      	uxtb	w16, w6
    cdd4:      	cmp	w16, wzr
    cdd8:      	b.eq	0xce24 <_stogir.switch.key+0x400>
    cddc:      	movz	w22, #0x0, lsl #16
    cde0:      	b	0xce0c <_stogir.switch.key+0x3e8>
    cde4:      	movz	x1, #0x0, lsl #48
    cde8:      	eor	x0, x1, x0
    cdec:      	movz	x1, #0x0, lsl #48
    cdf0:      	movz	x2, #0x0, lsl #48
    cdf4:      	b	0xcb38 <_stogir.switch.key+0x114>
    cdf8:      	mov	w23, #0x2               ; =2
    cdfc:      	b	0xcafc <_stogir.switch.key+0xd8>
    ce00:      	brk	#0
    ce04:      	b	0xce00 <_stogir.switch.key+0x3dc>
    ce08:      	mov	w22, #0x1               ; =1
    ce0c:      	lsl	w1, w22, #3
    ce10:      	sub	w1, w1, #0x1
    ce14:      	sxtw	x1, w1
    ce18:      	mov	x16, #0x1               ; =1
    ce1c:      	lsl	x1, x16, x1
    ce20:      	b	0xcde8 <_stogir.switch.key+0x3c4>
    ce24:      	uxtb	w16, w5
    ce28:      	cmp	w16, wzr
    ce2c:      	b.ne	0xce08 <_stogir.switch.key+0x3e4>
    ce30:      	uxtb	w16, w7
    ce34:      	cmp	w16, wzr
    ce38:      	b.ne	0xce08 <_stogir.switch.key+0x3e4>
    ce3c:      	uxtb	w16, w9
    ce40:      	cmp	w16, wzr
    ce44:      	b.ne	0xce08 <_stogir.switch.key+0x3e4>
    ce48:      	uxtb	w16, w10
    ce4c:      	cmp	w16, wzr
    ce50:      	b.ne	0xce08 <_stogir.switch.key+0x3e4>
    ce54:      	uxtb	w16, w11
    ce58:      	cmp	w16, wzr
    ce5c:      	b.ne	0xcecc <_stogir.switch.key+0x4a8>
    ce60:      	uxtb	w16, w12
    ce64:      	cmp	w16, wzr
    ce68:      	b.ne	0xcecc <_stogir.switch.key+0x4a8>
    ce6c:      	uxtb	w16, w13
    ce70:      	cmp	w16, wzr
    ce74:      	b.ne	0xced4 <_stogir.switch.key+0x4b0>
    ce78:      	uxtb	w16, w14
    ce7c:      	cmp	w16, wzr
    ce80:      	b.ne	0xced4 <_stogir.switch.key+0x4b0>
    ce84:      	uxtb	w16, w15
    ce88:      	cmp	w16, wzr
    ce8c:      	b.ne	0xced4 <_stogir.switch.key+0x4b0>
    ce90:      	uxtb	w16, w19
    ce94:      	cmp	w16, wzr
    ce98:      	b.ne	0xceb4 <_stogir.switch.key+0x490>
    ce9c:      	uxtb	w16, w20
    cea0:      	cmp	w16, wzr
    cea4:      	b.ne	0xceb4 <_stogir.switch.key+0x490>
    cea8:      	uxtb	w16, w21
    ceac:      	cmp	w16, wzr
    ceb0:      	b.eq	0xceb8 <_stogir.switch.key+0x494>
    ceb4:      	mov	w22, #0x8               ; =8
    ceb8:      	b	0xced8 <_stogir.switch.key+0x4b4>
    cebc:      	mov	w23, #0x4               ; =4
    cec0:      	b	0xcdfc <_stogir.switch.key+0x3d8>
    cec4:      	mov	w23, #0x8               ; =8
    cec8:      	b	0xcec0 <_stogir.switch.key+0x49c>
    cecc:      	mov	w22, #0x2               ; =2
    ced0:      	b	0xce0c <_stogir.switch.key+0x3e8>
    ced4:      	mov	w22, #0x4               ; =4
    ced8:      	b	0xced0 <_stogir.switch.key+0x4ac>

000000000000cedc <_stogir.stack.entry-allocation?>:
    cedc:      	sub	sp, sp, #0x10
    cee0:      	add	x2, x0, #0x78
    cee4:      	add	x3, x0, #0x28
    cee8:      	add	x4, x0, #0x50
    ceec:      	add	x5, x0, #0x78
    cef0:      	add	x6, x0, #0x28
    cef4:      	add	x7, x0, #0x50
    cef8:      	sxtw	x1, w1
    cefc:      	mov	x8, #0x1                ; =1
    cf00:      	movz	x9, #0x0, lsl #48
    cf04:      	b	0xd008 <_stogir.stack.entry-allocation?+0x12c>
    cf08:      	movz	x12, #0x0, lsl #48
    cf0c:      	b	0xcf78 <_stogir.stack.entry-allocation?+0x9c>
    cf10:      	movz	w11, #0x0, lsl #16
    cf14:      	movz	x10, #0x0, lsl #48
    cf18:      	ubfx	x11, x11, #0, #32
    cf1c:      	lsr	x16, x11, #0
    cf20:      	cmp	x16, #0x1
    cf24:      	b.eq	0xcf40 <_stogir.stack.entry-allocation?+0x64>
    cf28:      	b.lo	0xcf30 <_stogir.stack.entry-allocation?+0x54>
    cf2c:      	b	0xcf44 <_stogir.stack.entry-allocation?+0x68>
    cf30:      	cmp	x16, #0x0
    cf34:      	b.eq	0xcf3c <_stogir.stack.entry-allocation?+0x60>
    cf38:      	b	0xcf44 <_stogir.stack.entry-allocation?+0x68>
    cf3c:      	b	0xcf64 <_stogir.stack.entry-allocation?+0x88>
    cf40:      	b	0xcf48 <_stogir.stack.entry-allocation?+0x6c>
    cf44:      	b	0xd22c <_stogir.stack.entry-allocation?+0x350>
    cf48:      	uxtb	w11, w10
    cf4c:      	ubfx	x10, x10, #0, #32
    cf50:      	ubfx	x10, x10, #8, #8
    cf54:      	cmp	x11, x10
    cf58:      	b.eq	0xd21c <_stogir.stack.entry-allocation?+0x340>
    cf5c:      	cmp	x11, #0x49
    cf60:      	b.eq	0xd21c <_stogir.stack.entry-allocation?+0x340>
    cf64:      	movz	x8, #0x0, lsl #48
    cf68:      	b	0xd0e8 <_stogir.stack.entry-allocation?+0x20c>
    cf6c:      	movz	x12, #0x0, lsl #48
    cf70:      	b	0xcf80 <_stogir.stack.entry-allocation?+0xa4>
    cf74:      	movz	x12, #0x0, lsl #48
    cf78:      	b	0xcf88 <_stogir.stack.entry-allocation?+0xac>
    cf7c:      	movz	x12, #0x0, lsl #48
    cf80:      	b	0xcf88 <_stogir.stack.entry-allocation?+0xac>
    cf84:      	movz	x12, #0x0, lsl #48
    cf88:      	cmp	x12, #0x0
    cf8c:      	b.eq	0xcfc8 <_stogir.stack.entry-allocation?+0xec>
    cf90:      	uxtb	w16, w11
    cf94:      	cmp	w16, wzr
    cf98:      	b.eq	0xcfb0 <_stogir.stack.entry-allocation?+0xd4>
    cf9c:      	ldr	x11, [x0]
    cfa0:      	add	x10, x11, x10, lsl #4
    cfa4:      	ldr	x11, [x10]
    cfa8:      	ldr	x10, [x10, #0x8]
    cfac:      	b	0xcfc0 <_stogir.stack.entry-allocation?+0xe4>
    cfb0:      	ldr	x10, [x0, #0x28]
    cfb4:      	add	x10, x10, x13, lsl #4
    cfb8:      	ldr	x11, [x10]
    cfbc:      	ldr	x10, [x10, #0x8]
    cfc0:      	mov	w12, #0x1               ; =1
    cfc4:      	b	0xcfd4 <_stogir.stack.entry-allocation?+0xf8>
    cfc8:      	movz	w12, #0x0, lsl #16
    cfcc:      	movz	x11, #0x0, lsl #48
    cfd0:      	movz	x10, #0x0, lsl #48
    cfd4:      	ubfx	x12, x12, #0, #32
    cfd8:      	lsr	x16, x12, #0
    cfdc:      	cmp	x16, #0x1
    cfe0:      	b.eq	0xcffc <_stogir.stack.entry-allocation?+0x120>
    cfe4:      	b.lo	0xcfec <_stogir.stack.entry-allocation?+0x110>
    cfe8:      	b	0xd000 <_stogir.stack.entry-allocation?+0x124>
    cfec:      	cmp	x16, #0x0
    cff0:      	b.eq	0xcff8 <_stogir.stack.entry-allocation?+0x11c>
    cff4:      	b	0xd000 <_stogir.stack.entry-allocation?+0x124>
    cff8:      	b	0xd004 <_stogir.stack.entry-allocation?+0x128>
    cffc:      	b	0xd0b8 <_stogir.stack.entry-allocation?+0x1dc>
    d000:      	b	0xd188 <_stogir.stack.entry-allocation?+0x2ac>
    d004:      	movz	x8, #0x0, lsl #48
    d008:      	cmp	x8, #0x0
    d00c:      	b.eq	0xd170 <_stogir.stack.entry-allocation?+0x294>
    d010:      	cmp	x9, #0x0
    d014:      	b.ne	0xd170 <_stogir.stack.entry-allocation?+0x294>
    d018:      	orr	w10, w1, wzr
    d01c:      	sxtw	x10, w10
    d020:      	cmp	x10, #0x0
    d024:      	cset	w11, gt
    d028:      	movz	x16, #0x0, lsl #48
    d02c:      	sub	x12, x16, x10
    d030:      	sub	x13, x12, #0x1
    d034:      	uxtb	w16, w11
    d038:      	cmp	w16, wzr
    d03c:      	b.eq	0xd078 <_stogir.stack.entry-allocation?+0x19c>
    d040:      	ldr	x12, [x0, #0x8]
    d044:      	cmp	x10, x12
    d048:      	b.ge	0xcf7c <_stogir.stack.entry-allocation?+0xa0>
    d04c:      	ldr	x12, [x2, #0x8]
    d050:      	cmp	x10, x12
    d054:      	b.ge	0xcf6c <_stogir.stack.entry-allocation?+0x90>
    d058:      	ldr	x12, [x0, #0x78]
    d05c:      	add	x12, x12, x10, lsl #2
    d060:      	ldr	w12, [x12]
    d064:      	sxtw	x12, w12
    d068:      	cmp	x12, #0x0
    d06c:      	cset	w12, ge
    d070:      	ubfx	x12, x12, #0, #8
    d074:      	b	0xcf70 <_stogir.stack.entry-allocation?+0x94>
    d078:      	cmp	x10, #0x0
    d07c:      	b.ge	0xcf84 <_stogir.stack.entry-allocation?+0xa8>
    d080:      	ldr	x14, [x3, #0x8]
    d084:      	ldr	x15, [x4, #0x8]
    d088:      	cmp	x14, x15
    d08c:      	b.ne	0xcf74 <_stogir.stack.entry-allocation?+0x98>
    d090:      	cmp	x12, x14
    d094:      	b.gt	0xcf08 <_stogir.stack.entry-allocation?+0x2c>
    d098:      	ldr	x12, [x0, #0x50]
    d09c:      	add	x12, x12, x13, lsl #2
    d0a0:      	ldr	w12, [x12]
    d0a4:      	sxtw	x12, w12
    d0a8:      	cmp	x12, #0x0
    d0ac:      	cset	w12, gt
    d0b0:      	ubfx	x12, x12, #0, #8
    d0b4:      	b	0xcf0c <_stogir.stack.entry-allocation?+0x30>
    d0b8:      	uxtb	w12, w11
    d0bc:      	asr	x13, x11, #32
    d0c0:      	mov	x16, sp
    d0c4:      	str	x11, [x16]
    d0c8:      	mov	x16, sp
    d0cc:      	str	x10, [x16, #0x8]
    d0d0:      	cmp	x12, #0x68
    d0d4:      	b.ne	0xd0ec <_stogir.stack.entry-allocation?+0x210>
    d0d8:      	cmp	x13, #0x0
    d0dc:      	cset	w8, eq
    d0e0:      	ubfx	x8, x8, #0, #8
    d0e4:      	mov	x9, #0x1                ; =1
    d0e8:      	b	0xd008 <_stogir.stack.entry-allocation?+0x12c>
    d0ec:      	cmp	x1, #0x0
    d0f0:      	b.le	0xcf64 <_stogir.stack.entry-allocation?+0x88>
    d0f4:      	cmp	x12, #0x51
    d0f8:      	b.ne	0xcf64 <_stogir.stack.entry-allocation?+0x88>
    d0fc:      	cmp	x13, #0x0
    d100:      	b.le	0xcf64 <_stogir.stack.entry-allocation?+0x88>
    d104:      	cmp	x13, x1
    d108:      	b.ge	0xcf64 <_stogir.stack.entry-allocation?+0x88>
    d10c:      	sxtw	x10, w10
    d110:      	cmp	x10, #0x0
    d114:      	b.ge	0xcf64 <_stogir.stack.entry-allocation?+0x88>
    d118:      	cmp	x10, #0x0
    d11c:      	cset	w11, gt
    d120:      	movz	x16, #0x0, lsl #48
    d124:      	sub	x12, x16, x10
    d128:      	sub	x13, x12, #0x1
    d12c:      	uxtb	w16, w11
    d130:      	cmp	w16, wzr
    d134:      	b.eq	0xd1d4 <_stogir.stack.entry-allocation?+0x2f8>
    d138:      	ldr	x12, [x0, #0x8]
    d13c:      	cmp	x10, x12
    d140:      	b.ge	0xd1cc <_stogir.stack.entry-allocation?+0x2f0>
    d144:      	ldr	x12, [x5, #0x8]
    d148:      	cmp	x10, x12
    d14c:      	b.ge	0xd214 <_stogir.stack.entry-allocation?+0x338>
    d150:      	ldr	x12, [x0, #0x78]
    d154:      	add	x12, x12, x10, lsl #2
    d158:      	ldr	w12, [x12]
    d15c:      	sxtw	x12, w12
    d160:      	cmp	x12, #0x0
    d164:      	cset	w12, ge
    d168:      	ubfx	x12, x12, #0, #8
    d16c:      	b	0xd218 <_stogir.stack.entry-allocation?+0x33c>
    d170:      	cmp	x8, #0x0
    d174:      	b.ne	0xd17c <_stogir.stack.entry-allocation?+0x2a0>
    d178:      	movz	x9, #0x0, lsl #48
    d17c:      	mov	x0, x9
    d180:      	add	sp, sp, #0x10
    d184:      	ret
    d188:      	brk	#0
    d18c:      	b	0xd188 <_stogir.stack.entry-allocation?+0x2ac>
    d190:      	ldr	x10, [x0, #0x28]
    d194:      	add	x10, x10, x13, lsl #4
    d198:      	ldr	x10, [x10]
    d19c:      	mov	w11, #0x1               ; =1
    d1a0:      	b	0xcf18 <_stogir.stack.entry-allocation?+0x3c>
    d1a4:      	movz	x12, #0x0, lsl #48
    d1a8:      	cmp	x12, #0x0
    d1ac:      	b.eq	0xcf10 <_stogir.stack.entry-allocation?+0x34>
    d1b0:      	uxtb	w16, w11
    d1b4:      	cmp	w16, wzr
    d1b8:      	b.eq	0xd190 <_stogir.stack.entry-allocation?+0x2b4>
    d1bc:      	ldr	x11, [x0]
    d1c0:      	add	x10, x11, x10, lsl #4
    d1c4:      	ldr	x10, [x10]
    d1c8:      	b	0xd19c <_stogir.stack.entry-allocation?+0x2c0>
    d1cc:      	movz	x12, #0x0, lsl #48
    d1d0:      	b	0xd1a8 <_stogir.stack.entry-allocation?+0x2cc>
    d1d4:      	ldr	x14, [x6, #0x8]
    d1d8:      	ldr	x15, [x7, #0x8]
    d1dc:      	cmp	x14, x15
    d1e0:      	b.ne	0xd1a4 <_stogir.stack.entry-allocation?+0x2c8>
    d1e4:      	cmp	x12, x14
    d1e8:      	b.gt	0xd20c <_stogir.stack.entry-allocation?+0x330>
    d1ec:      	ldr	x12, [x0, #0x50]
    d1f0:      	add	x12, x12, x13, lsl #2
    d1f4:      	ldr	w12, [x12]
    d1f8:      	sxtw	x12, w12
    d1fc:      	cmp	x12, #0x0
    d200:      	cset	w12, gt
    d204:      	ubfx	x12, x12, #0, #8
    d208:      	b	0xd210 <_stogir.stack.entry-allocation?+0x334>
    d20c:      	movz	x12, #0x0, lsl #48
    d210:      	b	0xd1a8 <_stogir.stack.entry-allocation?+0x2cc>
    d214:      	movz	x12, #0x0, lsl #48
    d218:      	b	0xd1d0 <_stogir.stack.entry-allocation?+0x2f4>
    d21c:      	mov	x16, sp
    d220:      	ldr	w1, [x16, #0x4]
    d224:      	sxtw	x1, w1
    d228:      	b	0xcf68 <_stogir.stack.entry-allocation?+0x8c>
    d22c:      	brk	#0
    d230:      	b	0xd22c <_stogir.stack.entry-allocation?+0x350>

000000000000d234 <_stogir.frame.valid-alignment?>:
    d234:      	cmp	x0, #0x0
    d238:      	b.le	0xd254 <_stogir.frame.valid-alignment?+0x20>
    d23c:      	sub	x1, x0, #0x1
    d240:      	and	x0, x1, x0
    d244:      	cmp	x0, #0x0
    d248:      	cset	w0, eq
    d24c:      	ubfx	x0, x0, #0, #8
    d250:      	b	0xd258 <_stogir.frame.valid-alignment?+0x24>
    d254:      	movz	x0, #0x0, lsl #48
    d258:      	ret

000000000000d25c <_stogir.stack.constant-size-aligned>:
    d25c:      	sub	sp, sp, #0x10
    d260:      	cmp	x2, #0x10
    d264:      	b.lt	0xd2e0 <_stogir.stack.constant-size-aligned+0x84>
    d268:      	cmp	x2, #0x0
    d26c:      	b.le	0xd2e0 <_stogir.stack.constant-size-aligned+0x84>
    d270:      	sub	x3, x2, #0x1
    d274:      	and	x3, x3, x2
    d278:      	cmp	x3, #0x0
    d27c:      	b.ne	0xd2e0 <_stogir.stack.constant-size-aligned+0x84>
    d280:      	sxtw	x1, w1
    d284:      	cmp	x1, #0x0
    d288:      	cset	w3, gt
    d28c:      	movz	x16, #0x0, lsl #48
    d290:      	sub	x4, x16, x1
    d294:      	sub	x5, x4, #0x1
    d298:      	uxtb	w16, w3
    d29c:      	cmp	w16, wzr
    d2a0:      	b.eq	0xd378 <_stogir.stack.constant-size-aligned+0x11c>
    d2a4:      	ldr	x4, [x0, #0x8]
    d2a8:      	cmp	x1, x4
    d2ac:      	b.ge	0xd3c0 <_stogir.stack.constant-size-aligned+0x164>
    d2b0:      	add	x4, x0, #0x78
    d2b4:      	ldr	x4, [x4, #0x8]
    d2b8:      	cmp	x1, x4
    d2bc:      	b.ge	0xd494 <_stogir.stack.constant-size-aligned+0x238>
    d2c0:      	ldr	x4, [x0, #0x78]
    d2c4:      	add	x4, x4, x1, lsl #2
    d2c8:      	ldr	w4, [x4]
    d2cc:      	sxtw	x4, w4
    d2d0:      	cmp	x4, #0x0
    d2d4:      	cset	w4, ge
    d2d8:      	ubfx	x4, x4, #0, #8
    d2dc:      	b	0xd498 <_stogir.stack.constant-size-aligned+0x23c>
    d2e0:      	adrp	x16, 0xd000 <_stogir.stack.entry-allocation?+0x124>
		000000000000d2e0:  ARM64_RELOC_PAGE21	l_stogir.500
    d2e4:      	ldr	x16, [x16]
		000000000000d2e4:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    d2e8:      	orr	x0, x16, xzr
    d2ec:      	mov	x1, #0x1                ; =1
    d2f0:      	mov	x2, #0x20               ; =32
    d2f4:      	str	x1, [x8]
    d2f8:      	str	x0, [x8, #0x8]
    d2fc:      	str	x2, [x8, #0x10]
    d300:      	add	sp, sp, #0x10
    d304:      	ret
    d308:      	mov	w3, #0x1                ; =1
    d30c:      	mov	x16, sp
    d310:      	ldr	w4, [x16, #0x8]
    d314:      	mov	x16, sp
    d318:      	ldr	w5, [x16, #0xc]
    d31c:      	cmp	x1, #0x0
    d320:      	b.ge	0xd360 <_stogir.stack.constant-size-aligned+0x104>
    d324:      	cmp	x0, #0x1
    d328:      	b.lt	0xd360 <_stogir.stack.constant-size-aligned+0x104>
    d32c:      	cmp	x0, #0xb
    d330:      	cset	w1, le
    d334:      	uxtb	w16, w1
    d338:      	cmp	w16, wzr
    d33c:      	b.eq	0xd360 <_stogir.stack.constant-size-aligned+0x104>
    d340:      	mov	x16, sp
    d344:      	ldr	w6, [x16]
    d348:      	uxtb	w7, w6
    d34c:      	ubfx	x6, x6, #8, #8
    d350:      	cmp	x7, x6
    d354:      	b.eq	0xd524 <_stogir.stack.constant-size-aligned+0x2c8>
    d358:      	cmp	x7, #0x49
    d35c:      	b.eq	0xd524 <_stogir.stack.constant-size-aligned+0x2c8>
    d360:      	adrp	x16, 0xd000 <_stogir.stack.entry-allocation?+0x124>
		000000000000d360:  ARM64_RELOC_PAGE21	l_stogir.501
    d364:      	ldr	x16, [x16]
		000000000000d364:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    d368:      	orr	x0, x16, xzr
    d36c:      	mov	x1, #0x1                ; =1
    d370:      	mov	x2, #0x30               ; =48
    d374:      	b	0xd2f4 <_stogir.stack.constant-size-aligned+0x98>
    d378:      	cmp	x1, #0x0
    d37c:      	b.ge	0xd3c8 <_stogir.stack.constant-size-aligned+0x16c>
    d380:      	add	x6, x0, #0x28
    d384:      	add	x7, x0, #0x50
    d388:      	ldr	x6, [x6, #0x8]
    d38c:      	ldr	x7, [x7, #0x8]
    d390:      	cmp	x6, x7
    d394:      	b.ne	0xd48c <_stogir.stack.constant-size-aligned+0x230>
    d398:      	cmp	x4, x6
    d39c:      	b.gt	0xd51c <_stogir.stack.constant-size-aligned+0x2c0>
    d3a0:      	ldr	x4, [x0, #0x50]
    d3a4:      	add	x4, x4, x5, lsl #2
    d3a8:      	ldr	w4, [x4]
    d3ac:      	sxtw	x4, w4
    d3b0:      	cmp	x4, #0x0
    d3b4:      	cset	w4, gt
    d3b8:      	ubfx	x4, x4, #0, #8
    d3bc:      	b	0xd520 <_stogir.stack.constant-size-aligned+0x2c4>
    d3c0:      	movz	x4, #0x0, lsl #48
    d3c4:      	b	0xd3cc <_stogir.stack.constant-size-aligned+0x170>
    d3c8:      	movz	x4, #0x0, lsl #48
    d3cc:      	cmp	x4, #0x0
    d3d0:      	b.eq	0xd40c <_stogir.stack.constant-size-aligned+0x1b0>
    d3d4:      	uxtb	w16, w3
    d3d8:      	cmp	w16, wzr
    d3dc:      	b.eq	0xd3f4 <_stogir.stack.constant-size-aligned+0x198>
    d3e0:      	ldr	x0, [x0]
    d3e4:      	add	x0, x0, x1, lsl #4
    d3e8:      	ldr	x3, [x0]
    d3ec:      	ldr	x0, [x0, #0x8]
    d3f0:      	b	0xd404 <_stogir.stack.constant-size-aligned+0x1a8>
    d3f4:      	ldr	x0, [x0, #0x28]
    d3f8:      	add	x0, x0, x5, lsl #4
    d3fc:      	ldr	x3, [x0]
    d400:      	ldr	x0, [x0, #0x8]
    d404:      	mov	w4, #0x1                ; =1
    d408:      	b	0xd418 <_stogir.stack.constant-size-aligned+0x1bc>
    d40c:      	movz	w4, #0x0, lsl #16
    d410:      	movz	x3, #0x0, lsl #48
    d414:      	movz	x0, #0x0, lsl #48
    d418:      	ubfx	x4, x4, #0, #32
    d41c:      	lsr	x16, x4, #0
    d420:      	cmp	x16, #0x1
    d424:      	b.eq	0xd440 <_stogir.stack.constant-size-aligned+0x1e4>
    d428:      	b.lo	0xd430 <_stogir.stack.constant-size-aligned+0x1d4>
    d42c:      	b	0xd444 <_stogir.stack.constant-size-aligned+0x1e8>
    d430:      	cmp	x16, #0x0
    d434:      	b.eq	0xd43c <_stogir.stack.constant-size-aligned+0x1e0>
    d438:      	b	0xd444 <_stogir.stack.constant-size-aligned+0x1e8>
    d43c:      	b	0xd448 <_stogir.stack.constant-size-aligned+0x1ec>
    d440:      	b	0xd460 <_stogir.stack.constant-size-aligned+0x204>
    d444:      	b	0xd5c8 <_stogir.stack.constant-size-aligned+0x36c>
    d448:      	adrp	x16, 0xd000 <_stogir.stack.entry-allocation?+0x124>
		000000000000d448:  ARM64_RELOC_PAGE21	l_stogir.502
    d44c:      	ldr	x16, [x16]
		000000000000d44c:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    d450:      	orr	x0, x16, xzr
    d454:      	mov	x1, #0x1                ; =1
    d458:      	mov	x2, #0x18               ; =24
    d45c:      	b	0xd374 <_stogir.stack.constant-size-aligned+0x118>
    d460:      	orr	w4, w3, wzr
    d464:      	mov	x16, sp
    d468:      	str	x3, [x16]
    d46c:      	ubfx	x4, x4, #0, #32
    d470:      	mov	x16, sp
    d474:      	str	x0, [x16, #0x8]
    d478:      	ubfx	x0, x4, #8, #8
    d47c:      	cmp	x0, #0x0
    d480:      	b.ne	0xd49c <_stogir.stack.constant-size-aligned+0x240>
    d484:      	movz	w3, #0x0, lsl #16
    d488:      	b	0xd30c <_stogir.stack.constant-size-aligned+0xb0>
    d48c:      	movz	x4, #0x0, lsl #48
    d490:      	b	0xd3cc <_stogir.stack.constant-size-aligned+0x170>
    d494:      	movz	x4, #0x0, lsl #48
    d498:      	b	0xd3c4 <_stogir.stack.constant-size-aligned+0x168>
    d49c:      	cmp	x0, #0x1
    d4a0:      	b.eq	0xd308 <_stogir.stack.constant-size-aligned+0xac>
    d4a4:      	cmp	x0, #0x2
    d4a8:      	b.eq	0xd308 <_stogir.stack.constant-size-aligned+0xac>
    d4ac:      	cmp	x0, #0x7
    d4b0:      	b.eq	0xd308 <_stogir.stack.constant-size-aligned+0xac>
    d4b4:      	cmp	x0, #0x8
    d4b8:      	b.eq	0xd308 <_stogir.stack.constant-size-aligned+0xac>
    d4bc:      	cmp	x0, #0x3
    d4c0:      	b.eq	0xd5c0 <_stogir.stack.constant-size-aligned+0x364>
    d4c4:      	cmp	x0, #0x9
    d4c8:      	b.eq	0xd5c0 <_stogir.stack.constant-size-aligned+0x364>
    d4cc:      	cmp	x0, #0x4
    d4d0:      	b.eq	0xd5d0 <_stogir.stack.constant-size-aligned+0x374>
    d4d4:      	cmp	x0, #0xa
    d4d8:      	b.eq	0xd5d0 <_stogir.stack.constant-size-aligned+0x374>
    d4dc:      	cmp	x0, #0xd
    d4e0:      	b.eq	0xd5d0 <_stogir.stack.constant-size-aligned+0x374>
    d4e4:      	cmp	x0, #0x5
    d4e8:      	b.eq	0xd5d8 <_stogir.stack.constant-size-aligned+0x37c>
    d4ec:      	cmp	x0, #0xb
    d4f0:      	b.eq	0xd5d8 <_stogir.stack.constant-size-aligned+0x37c>
    d4f4:      	cmp	x0, #0xc
    d4f8:      	b.eq	0xd5d8 <_stogir.stack.constant-size-aligned+0x37c>
    d4fc:      	cmp	x0, #0x6
    d500:      	cset	w3, eq
    d504:      	uxtb	w16, w3
    d508:      	cmp	w16, wzr
    d50c:      	mov	w16, #0x8               ; =8
    d510:      	movn	w17, #0x0, lsl #16
    d514:      	csel	w3, w16, w17, ne
    d518:      	b	0xd5dc <_stogir.stack.constant-size-aligned+0x380>
    d51c:      	movz	x4, #0x0, lsl #48
    d520:      	b	0xd490 <_stogir.stack.constant-size-aligned+0x234>
    d524:      	sxtw	x6, w3
    d528:      	cmp	x6, #0x0
    d52c:      	b.le	0xd360 <_stogir.stack.constant-size-aligned+0x104>
    d530:      	lsl	w3, w3, #3
    d534:      	ubfx	x4, x4, #0, #32
    d538:      	ubfx	x5, x5, #0, #32
    d53c:      	lsl	x5, x5, #32
    d540:      	orr	x4, x5, x4
    d544:      	cmp	x6, #0x8
    d548:      	b.ge	0xd55c <_stogir.stack.constant-size-aligned+0x300>
    d54c:      	sxtw	x5, w3
    d550:      	lsr	x5, x4, x5
    d554:      	cmp	x5, #0x0
    d558:      	b.ne	0xd360 <_stogir.stack.constant-size-aligned+0x104>
    d55c:      	cmp	x0, #0x7
    d560:      	b.lt	0xd58c <_stogir.stack.constant-size-aligned+0x330>
    d564:      	uxtb	w16, w1
    d568:      	cmp	w16, wzr
    d56c:      	b.eq	0xd58c <_stogir.stack.constant-size-aligned+0x330>
    d570:      	sub	w0, w3, #0x1
    d574:      	sxtw	x0, w0
    d578:      	mov	x16, #0x1               ; =1
    d57c:      	lsl	x0, x16, x0
    d580:      	and	x0, x0, x4
    d584:      	cmp	x0, #0x0
    d588:      	b.ne	0xd360 <_stogir.stack.constant-size-aligned+0x104>
    d58c:      	sub	x0, x2, #0x1
    d590:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    d594:      	sub	x0, x16, x0
    d598:      	cmp	x4, x0
    d59c:      	b.hi	0xd360 <_stogir.stack.constant-size-aligned+0x104>
    d5a0:      	sub	x0, x2, #0x1
    d5a4:      	movz	x16, #0x0, lsl #48
    d5a8:      	sub	x1, x16, x2
    d5ac:      	add	x0, x0, x4
    d5b0:      	and	x0, x1, x0
    d5b4:      	movz	x1, #0x0, lsl #48
    d5b8:      	movz	x2, #0x0, lsl #48
    d5bc:      	b	0xd374 <_stogir.stack.constant-size-aligned+0x118>
    d5c0:      	mov	w3, #0x2                ; =2
    d5c4:      	b	0xd30c <_stogir.stack.constant-size-aligned+0xb0>
    d5c8:      	brk	#0
    d5cc:      	b	0xd5c8 <_stogir.stack.constant-size-aligned+0x36c>
    d5d0:      	mov	w3, #0x4                ; =4
    d5d4:      	b	0xd5c4 <_stogir.stack.constant-size-aligned+0x368>
    d5d8:      	mov	w3, #0x8                ; =8
    d5dc:      	b	0xd5d4 <_stogir.stack.constant-size-aligned+0x378>

000000000000d5e0 <_stogir.vector-lanes.compatible?>:
    d5e0:      	and	w3, w0, #0xf
    d5e4:      	sxtw	x0, w0
    d5e8:      	ubfx	x4, x3, #0, #32
    d5ec:      	cmp	x0, #0xf
    d5f0:      	cset	w5, gt
    d5f4:      	cmp	x0, #0x80
    d5f8:      	cset	w6, lt
    d5fc:      	cmp	x4, #0x1
    d600:      	cset	w7, ge
    d604:      	cmp	x4, #0xd
    d608:      	cset	w4, le
    d60c:      	cmp	x0, #0x0
    d610:      	b.lt	0xd61c <_stogir.vector-lanes.compatible?+0x3c>
    d614:      	cmp	x0, #0xd
    d618:      	b.le	0xd650 <_stogir.vector-lanes.compatible?+0x70>
    d61c:      	uxtb	w16, w5
    d620:      	cmp	w16, wzr
    d624:      	b.eq	0xd64c <_stogir.vector-lanes.compatible?+0x6c>
    d628:      	uxtb	w16, w6
    d62c:      	cmp	w16, wzr
    d630:      	b.eq	0xd64c <_stogir.vector-lanes.compatible?+0x6c>
    d634:      	uxtb	w16, w7
    d638:      	cmp	w16, wzr
    d63c:      	b.eq	0xd64c <_stogir.vector-lanes.compatible?+0x6c>
    d640:      	uxtb	w16, w4
    d644:      	cmp	w16, wzr
    d648:      	b.ne	0xd650 <_stogir.vector-lanes.compatible?+0x70>
    d64c:      	movn	w3, #0x0, lsl #16
    d650:      	uxtb	w16, w5
    d654:      	cmp	w16, wzr
    d658:      	b.eq	0xd6b4 <_stogir.vector-lanes.compatible?+0xd4>
    d65c:      	uxtb	w16, w6
    d660:      	cmp	w16, wzr
    d664:      	b.eq	0xd6b4 <_stogir.vector-lanes.compatible?+0xd4>
    d668:      	uxtb	w16, w7
    d66c:      	cmp	w16, wzr
    d670:      	b.eq	0xd6b4 <_stogir.vector-lanes.compatible?+0xd4>
    d674:      	uxtb	w16, w4
    d678:      	cmp	w16, wzr
    d67c:      	b.eq	0xd6b4 <_stogir.vector-lanes.compatible?+0xd4>
    d680:      	sxtw	x0, w2
    d684:      	cmp	x0, #0x4
    d688:      	cset	w4, eq
    d68c:      	cmp	x0, #0x8
    d690:      	cset	w0, eq
    d694:      	uxtb	w16, w4
    d698:      	cmp	w16, wzr
    d69c:      	b.ne	0xd6c4 <_stogir.vector-lanes.compatible?+0xe4>
    d6a0:      	uxtb	w16, w0
    d6a4:      	cmp	w16, wzr
    d6a8:      	b.ne	0xd6c4 <_stogir.vector-lanes.compatible?+0xe4>
    d6ac:      	movz	x0, #0x0, lsl #48
    d6b0:      	b	0xd6c0 <_stogir.vector-lanes.compatible?+0xe0>
    d6b4:      	movz	x0, #0x0, lsl #48
    d6b8:      	ret
    d6bc:      	movz	x0, #0x0, lsl #48
    d6c0:      	b	0xd6b8 <_stogir.vector-lanes.compatible?+0xd8>
    d6c4:      	sxtw	x1, w1
    d6c8:      	cmp	x1, #0x0
    d6cc:      	b.lt	0xd6bc <_stogir.vector-lanes.compatible?+0xdc>
    d6d0:      	cmp	x1, #0xd
    d6d4:      	b.gt	0xd6bc <_stogir.vector-lanes.compatible?+0xdc>
    d6d8:      	cmp	x1, #0x0
    d6dc:      	b.le	0xd6f4 <_stogir.vector-lanes.compatible?+0x114>
    d6e0:      	sxtw	x3, w3
    d6e4:      	cmp	x3, x1
    d6e8:      	b.ne	0xd6fc <_stogir.vector-lanes.compatible?+0x11c>
    d6ec:      	mov	x0, #0x1                ; =1
    d6f0:      	b	0xd6f8 <_stogir.vector-lanes.compatible?+0x118>
    d6f4:      	movz	x0, #0x0, lsl #48
    d6f8:      	b	0xd6c0 <_stogir.vector-lanes.compatible?+0xe0>
    d6fc:      	cmp	x3, #0x1
    d700:      	b.lt	0xd73c <_stogir.vector-lanes.compatible?+0x15c>
    d704:      	cmp	x3, #0xb
    d708:      	b.gt	0xd73c <_stogir.vector-lanes.compatible?+0x15c>
    d70c:      	cmp	x1, #0x1
    d710:      	b.lt	0xd744 <_stogir.vector-lanes.compatible?+0x164>
    d714:      	cmp	x1, #0xb
    d718:      	b.gt	0xd744 <_stogir.vector-lanes.compatible?+0x164>
    d71c:      	uxtb	w16, w4
    d720:      	cmp	w16, wzr
    d724:      	b.ne	0xd768 <_stogir.vector-lanes.compatible?+0x188>
    d728:      	uxtb	w16, w0
    d72c:      	cmp	w16, wzr
    d730:      	b.ne	0xd768 <_stogir.vector-lanes.compatible?+0x188>
    d734:      	movn	w3, #0x0, lsl #16
    d738:      	b	0xd77c <_stogir.vector-lanes.compatible?+0x19c>
    d73c:      	movz	x0, #0x0, lsl #48
    d740:      	b	0xd6f0 <_stogir.vector-lanes.compatible?+0x110>
    d744:      	movz	x0, #0x0, lsl #48
    d748:      	b	0xd740 <_stogir.vector-lanes.compatible?+0x160>
    d74c:      	mov	w2, #0x1                ; =1
    d750:      	sxtw	x3, w3
    d754:      	sxtw	x2, w2
    d758:      	cmp	x3, x2
    d75c:      	cset	w0, eq
    d760:      	ubfx	x0, x0, #0, #8
    d764:      	b	0xd748 <_stogir.vector-lanes.compatible?+0x168>
    d768:      	cmp	x3, #0x0
    d76c:      	b.ne	0xd81c <_stogir.vector-lanes.compatible?+0x23c>
    d770:      	movz	w3, #0x0, lsl #16
    d774:      	b	0xd77c <_stogir.vector-lanes.compatible?+0x19c>
    d778:      	mov	w3, #0x1                ; =1
    d77c:      	uxtb	w16, w4
    d780:      	cmp	w16, wzr
    d784:      	b.ne	0xd79c <_stogir.vector-lanes.compatible?+0x1bc>
    d788:      	uxtb	w16, w0
    d78c:      	cmp	w16, wzr
    d790:      	b.ne	0xd79c <_stogir.vector-lanes.compatible?+0x1bc>
    d794:      	movn	w2, #0x0, lsl #16
    d798:      	b	0xd750 <_stogir.vector-lanes.compatible?+0x170>
    d79c:      	cmp	x1, #0x0
    d7a0:      	b.ne	0xd7ac <_stogir.vector-lanes.compatible?+0x1cc>
    d7a4:      	movz	w2, #0x0, lsl #16
    d7a8:      	b	0xd750 <_stogir.vector-lanes.compatible?+0x170>
    d7ac:      	cmp	x1, #0x1
    d7b0:      	b.eq	0xd74c <_stogir.vector-lanes.compatible?+0x16c>
    d7b4:      	cmp	x1, #0x2
    d7b8:      	b.eq	0xd74c <_stogir.vector-lanes.compatible?+0x16c>
    d7bc:      	cmp	x1, #0x7
    d7c0:      	b.eq	0xd74c <_stogir.vector-lanes.compatible?+0x16c>
    d7c4:      	cmp	x1, #0x8
    d7c8:      	b.eq	0xd74c <_stogir.vector-lanes.compatible?+0x16c>
    d7cc:      	cmp	x1, #0x3
    d7d0:      	b.eq	0xd88c <_stogir.vector-lanes.compatible?+0x2ac>
    d7d4:      	cmp	x1, #0x9
    d7d8:      	b.eq	0xd88c <_stogir.vector-lanes.compatible?+0x2ac>
    d7dc:      	cmp	x1, #0x4
    d7e0:      	b.eq	0xd89c <_stogir.vector-lanes.compatible?+0x2bc>
    d7e4:      	cmp	x1, #0xa
    d7e8:      	b.eq	0xd89c <_stogir.vector-lanes.compatible?+0x2bc>
    d7ec:      	cmp	x1, #0xd
    d7f0:      	b.eq	0xd89c <_stogir.vector-lanes.compatible?+0x2bc>
    d7f4:      	cmp	x1, #0x5
    d7f8:      	b.eq	0xd8ac <_stogir.vector-lanes.compatible?+0x2cc>
    d7fc:      	cmp	x1, #0xb
    d800:      	b.eq	0xd8ac <_stogir.vector-lanes.compatible?+0x2cc>
    d804:      	cmp	x1, #0xc
    d808:      	b.eq	0xd8ac <_stogir.vector-lanes.compatible?+0x2cc>
    d80c:      	cmp	x1, #0x6
    d810:      	b.eq	0xd818 <_stogir.vector-lanes.compatible?+0x238>
    d814:      	movn	w2, #0x0, lsl #16
    d818:      	b	0xd8b0 <_stogir.vector-lanes.compatible?+0x2d0>
    d81c:      	cmp	x3, #0x1
    d820:      	b.eq	0xd778 <_stogir.vector-lanes.compatible?+0x198>
    d824:      	cmp	x3, #0x2
    d828:      	b.eq	0xd778 <_stogir.vector-lanes.compatible?+0x198>
    d82c:      	cmp	x3, #0x7
    d830:      	b.eq	0xd778 <_stogir.vector-lanes.compatible?+0x198>
    d834:      	cmp	x3, #0x8
    d838:      	b.eq	0xd778 <_stogir.vector-lanes.compatible?+0x198>
    d83c:      	cmp	x3, #0x3
    d840:      	b.eq	0xd894 <_stogir.vector-lanes.compatible?+0x2b4>
    d844:      	cmp	x3, #0x9
    d848:      	b.eq	0xd894 <_stogir.vector-lanes.compatible?+0x2b4>
    d84c:      	cmp	x3, #0x4
    d850:      	b.eq	0xd8a4 <_stogir.vector-lanes.compatible?+0x2c4>
    d854:      	cmp	x3, #0xa
    d858:      	b.eq	0xd8a4 <_stogir.vector-lanes.compatible?+0x2c4>
    d85c:      	cmp	x3, #0xd
    d860:      	b.eq	0xd8a4 <_stogir.vector-lanes.compatible?+0x2c4>
    d864:      	cmp	x3, #0x5
    d868:      	b.eq	0xd8b4 <_stogir.vector-lanes.compatible?+0x2d4>
    d86c:      	cmp	x3, #0xb
    d870:      	b.eq	0xd8b4 <_stogir.vector-lanes.compatible?+0x2d4>
    d874:      	cmp	x3, #0xc
    d878:      	b.eq	0xd8b4 <_stogir.vector-lanes.compatible?+0x2d4>
    d87c:      	cmp	x3, #0x6
    d880:      	b.ne	0xd8bc <_stogir.vector-lanes.compatible?+0x2dc>
    d884:      	mov	w3, w2
    d888:      	b	0xd8c0 <_stogir.vector-lanes.compatible?+0x2e0>
    d88c:      	mov	w2, #0x2                ; =2
    d890:      	b	0xd750 <_stogir.vector-lanes.compatible?+0x170>
    d894:      	mov	w3, #0x2                ; =2
    d898:      	b	0xd77c <_stogir.vector-lanes.compatible?+0x19c>
    d89c:      	mov	w2, #0x4                ; =4
    d8a0:      	b	0xd890 <_stogir.vector-lanes.compatible?+0x2b0>
    d8a4:      	mov	w3, #0x4                ; =4
    d8a8:      	b	0xd898 <_stogir.vector-lanes.compatible?+0x2b8>
    d8ac:      	mov	w2, #0x8                ; =8
    d8b0:      	b	0xd8a0 <_stogir.vector-lanes.compatible?+0x2c0>
    d8b4:      	mov	w3, #0x8                ; =8
    d8b8:      	b	0xd8a8 <_stogir.vector-lanes.compatible?+0x2c8>
    d8bc:      	movn	w3, #0x0, lsl #16
    d8c0:      	b	0xd8b8 <_stogir.vector-lanes.compatible?+0x2d8>

000000000000d8c4 <_stogir.symbols.numeric?>:
    d8c4:      	ldr	w0, [x0]
    d8c8:      	uxtb	w1, w0
    d8cc:      	ubfx	x0, x0, #8, #8
    d8d0:      	cmp	x1, x0
    d8d4:      	b.ne	0xd8e0 <_stogir.symbols.numeric?+0x1c>
    d8d8:      	mov	x0, #0x1                ; =1
    d8dc:      	b	0xd8ec <_stogir.symbols.numeric?+0x28>
    d8e0:      	cmp	x1, #0x49
    d8e4:      	cset	w0, eq
    d8e8:      	ubfx	x0, x0, #0, #8
    d8ec:      	ret

000000000000d8f0 <_stogir.node.constant-bits>:
    d8f0:      	ldr	w1, [x0, #0x8]
    d8f4:      	ubfx	x1, x1, #0, #32
    d8f8:      	ldr	w0, [x0, #0xc]
    d8fc:      	ubfx	x0, x0, #0, #32
    d900:      	lsl	x0, x0, #32
    d904:      	orr	x0, x0, x1
    d908:      	ret

000000000000d90c <_stogir.vector-comparison.valid-type?>:
    d90c:      	sxtw	x0, w0
    d910:      	cmp	x0, #0xe
    d914:      	b.lt	0xd9ac <_stogir.vector-comparison.valid-type?+0xa0>
    d918:      	cmp	x0, #0x19
    d91c:      	b.gt	0xd9ac <_stogir.vector-comparison.valid-type?+0xa0>
    d920:      	sxtw	x2, w1
    d924:      	cmp	x2, #0xf
    d928:      	cset	w3, gt
    d92c:      	uxtb	w16, w3
    d930:      	cmp	w16, wzr
    d934:      	b.eq	0xd9b4 <_stogir.vector-comparison.valid-type?+0xa8>
    d938:      	cmp	x2, #0x80
    d93c:      	cset	w4, lt
    d940:      	uxtb	w16, w4
    d944:      	cmp	w16, wzr
    d948:      	b.eq	0xd9b4 <_stogir.vector-comparison.valid-type?+0xa8>
    d94c:      	and	w1, w1, #0xf
    d950:      	ubfx	x5, x1, #0, #32
    d954:      	cmp	x5, #0x1
    d958:      	cset	w6, ge
    d95c:      	uxtb	w16, w6
    d960:      	cmp	w16, wzr
    d964:      	b.eq	0xd9b4 <_stogir.vector-comparison.valid-type?+0xa8>
    d968:      	cmp	x5, #0xd
    d96c:      	cset	w5, le
    d970:      	uxtb	w16, w5
    d974:      	cmp	w16, wzr
    d978:      	b.eq	0xd9b4 <_stogir.vector-comparison.valid-type?+0xa8>
    d97c:      	cmp	x2, #0x0
    d980:      	cset	w7, ge
    d984:      	cmp	x2, #0xd
    d988:      	cset	w2, le
    d98c:      	uxtb	w16, w7
    d990:      	cmp	w16, wzr
    d994:      	b.eq	0xd9c4 <_stogir.vector-comparison.valid-type?+0xb8>
    d998:      	uxtb	w16, w2
    d99c:      	cmp	w16, wzr
    d9a0:      	b.eq	0xd9c4 <_stogir.vector-comparison.valid-type?+0xb8>
    d9a4:      	mov	w8, w1
    d9a8:      	b	0xd9f8 <_stogir.vector-comparison.valid-type?+0xec>
    d9ac:      	movz	x0, #0x0, lsl #48
    d9b0:      	ret
    d9b4:      	movz	x0, #0x0, lsl #48
    d9b8:      	b	0xd9b0 <_stogir.vector-comparison.valid-type?+0xa4>
    d9bc:      	mov	x0, #0x1                ; =1
    d9c0:      	b	0xd9b8 <_stogir.vector-comparison.valid-type?+0xac>
    d9c4:      	uxtb	w16, w3
    d9c8:      	cmp	w16, wzr
    d9cc:      	b.eq	0xd9f4 <_stogir.vector-comparison.valid-type?+0xe8>
    d9d0:      	uxtb	w16, w4
    d9d4:      	cmp	w16, wzr
    d9d8:      	b.eq	0xd9f4 <_stogir.vector-comparison.valid-type?+0xe8>
    d9dc:      	uxtb	w16, w6
    d9e0:      	cmp	w16, wzr
    d9e4:      	b.eq	0xd9f4 <_stogir.vector-comparison.valid-type?+0xe8>
    d9e8:      	uxtb	w16, w5
    d9ec:      	cmp	w16, wzr
    d9f0:      	b.ne	0xd9a4 <_stogir.vector-comparison.valid-type?+0x98>
    d9f4:      	movn	w8, #0x0, lsl #16
    d9f8:      	sxtw	x8, w8
    d9fc:      	cmp	x8, #0xc
    da00:      	b.eq	0xd9bc <_stogir.vector-comparison.valid-type?+0xb0>
    da04:      	cmp	x8, #0xd
    da08:      	b.eq	0xd9bc <_stogir.vector-comparison.valid-type?+0xb0>
    da0c:      	uxtb	w16, w7
    da10:      	cmp	w16, wzr
    da14:      	b.eq	0xda24 <_stogir.vector-comparison.valid-type?+0x118>
    da18:      	uxtb	w16, w2
    da1c:      	cmp	w16, wzr
    da20:      	b.ne	0xda58 <_stogir.vector-comparison.valid-type?+0x14c>
    da24:      	uxtb	w16, w3
    da28:      	cmp	w16, wzr
    da2c:      	b.eq	0xda54 <_stogir.vector-comparison.valid-type?+0x148>
    da30:      	uxtb	w16, w4
    da34:      	cmp	w16, wzr
    da38:      	b.eq	0xda54 <_stogir.vector-comparison.valid-type?+0x148>
    da3c:      	uxtb	w16, w6
    da40:      	cmp	w16, wzr
    da44:      	b.eq	0xda54 <_stogir.vector-comparison.valid-type?+0x148>
    da48:      	uxtb	w16, w5
    da4c:      	cmp	w16, wzr
    da50:      	b.ne	0xda58 <_stogir.vector-comparison.valid-type?+0x14c>
    da54:      	movn	w1, #0x0, lsl #16
    da58:      	sxtw	x1, w1
    da5c:      	cmp	x1, #0x1
    da60:      	b.lt	0xda7c <_stogir.vector-comparison.valid-type?+0x170>
    da64:      	cmp	x1, #0xb
    da68:      	b.gt	0xda7c <_stogir.vector-comparison.valid-type?+0x170>
    da6c:      	cmp	x0, #0x17
    da70:      	cset	w0, le
    da74:      	ubfx	x0, x0, #0, #8
    da78:      	b	0xda80 <_stogir.vector-comparison.valid-type?+0x174>
    da7c:      	movz	x0, #0x0, lsl #48
    da80:      	b	0xd9c0 <_stogir.vector-comparison.valid-type?+0xb4>

000000000000da84 <_stogir.vector-arithmetic.shift?>:
    da84:      	sxtw	x0, w0
    da88:      	cmp	x0, #0x31
    da8c:      	b.lt	0xdaa0 <_stogir.vector-arithmetic.shift?+0x1c>
    da90:      	cmp	x0, #0x35
    da94:      	cset	w0, le
    da98:      	ubfx	x0, x0, #0, #8
    da9c:      	b	0xdaa4 <_stogir.vector-arithmetic.shift?+0x20>
    daa0:      	movz	x0, #0x0, lsl #48
    daa4:      	ret

000000000000daa8 <_stogir.vector-arithmetic.valid-type?>:
    daa8:      	sub	sp, sp, #0x30
    daac:      	str	x29, [sp]
    dab0:      	str	x30, [sp, #0x8]
    dab4:      	mov	x29, sp
    dab8:      	str	x19, [sp, #0x10]
    dabc:      	str	x20, [sp, #0x18]
    dac0:      	str	x21, [sp, #0x20]
    dac4:      	str	x22, [sp, #0x28]
    dac8:      	sxtw	x2, w1
    dacc:      	and	w1, w1, #0xf
    dad0:      	cmp	x2, #0xf
    dad4:      	cset	w3, gt
    dad8:      	cmp	x2, #0x80
    dadc:      	cset	w4, lt
    dae0:      	ubfx	x5, x1, #0, #32
    dae4:      	cmp	x5, #0x1
    dae8:      	cset	w6, ge
    daec:      	cmp	x5, #0xd
    daf0:      	cset	w5, le
    daf4:      	cmp	x2, #0x0
    daf8:      	b.lt	0xdb04 <_stogir.vector-arithmetic.valid-type?+0x5c>
    dafc:      	cmp	x2, #0xd
    db00:      	b.le	0xdb38 <_stogir.vector-arithmetic.valid-type?+0x90>
    db04:      	uxtb	w16, w3
    db08:      	cmp	w16, wzr
    db0c:      	b.eq	0xdb34 <_stogir.vector-arithmetic.valid-type?+0x8c>
    db10:      	uxtb	w16, w4
    db14:      	cmp	w16, wzr
    db18:      	b.eq	0xdb34 <_stogir.vector-arithmetic.valid-type?+0x8c>
    db1c:      	uxtb	w16, w6
    db20:      	cmp	w16, wzr
    db24:      	b.eq	0xdb34 <_stogir.vector-arithmetic.valid-type?+0x8c>
    db28:      	uxtb	w16, w5
    db2c:      	cmp	w16, wzr
    db30:      	b.ne	0xdb38 <_stogir.vector-arithmetic.valid-type?+0x90>
    db34:      	movn	w1, #0x0, lsl #16
    db38:      	uxtb	w16, w3
    db3c:      	cmp	w16, wzr
    db40:      	b.eq	0xdd28 <_stogir.vector-arithmetic.valid-type?+0x280>
    db44:      	uxtb	w16, w4
    db48:      	cmp	w16, wzr
    db4c:      	b.eq	0xdd28 <_stogir.vector-arithmetic.valid-type?+0x280>
    db50:      	uxtb	w16, w6
    db54:      	cmp	w16, wzr
    db58:      	b.eq	0xdd28 <_stogir.vector-arithmetic.valid-type?+0x280>
    db5c:      	uxtb	w16, w5
    db60:      	cmp	w16, wzr
    db64:      	b.eq	0xdd28 <_stogir.vector-arithmetic.valid-type?+0x280>
    db68:      	sxtw	x2, w0
    db6c:      	cmp	x2, #0x1f
    db70:      	cset	w19, eq
    db74:      	cmp	x2, #0x20
    db78:      	cset	w20, eq
    db7c:      	cmp	x2, #0x2e
    db80:      	cset	w3, eq
    db84:      	cmp	x2, #0x2f
    db88:      	cset	w4, eq
    db8c:      	cmp	x2, #0x30
    db90:      	cset	w5, eq
    db94:      	cmp	x2, #0x1e
    db98:      	cset	w6, eq
    db9c:      	cmp	x2, #0x31
    dba0:      	cset	w7, ge
    dba4:      	cmp	x2, #0x35
    dba8:      	cset	w8, le
    dbac:      	cmp	x2, #0x3a
    dbb0:      	cset	w9, eq
    dbb4:      	cmp	x2, #0x3b
    dbb8:      	cset	w10, eq
    dbbc:      	cmp	x2, #0x2d
    dbc0:      	cset	w11, eq
    dbc4:      	cmp	x2, #0x36
    dbc8:      	cset	w12, eq
    dbcc:      	cmp	x2, #0x37
    dbd0:      	cset	w13, eq
    dbd4:      	cmp	x2, #0x38
    dbd8:      	cset	w14, eq
    dbdc:      	cmp	x2, #0x39
    dbe0:      	cset	w15, eq
    dbe4:      	uxtb	w16, w19
    dbe8:      	cmp	w16, wzr
    dbec:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dbf0:      	uxtb	w16, w20
    dbf4:      	cmp	w16, wzr
    dbf8:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dbfc:      	uxtb	w16, w11
    dc00:      	cmp	w16, wzr
    dc04:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dc08:      	uxtb	w16, w12
    dc0c:      	cmp	w16, wzr
    dc10:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dc14:      	uxtb	w16, w13
    dc18:      	cmp	w16, wzr
    dc1c:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dc20:      	uxtb	w16, w14
    dc24:      	cmp	w16, wzr
    dc28:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dc2c:      	uxtb	w16, w15
    dc30:      	cmp	w16, wzr
    dc34:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dc38:      	uxtb	w16, w9
    dc3c:      	cmp	w16, wzr
    dc40:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dc44:      	uxtb	w16, w10
    dc48:      	cmp	w16, wzr
    dc4c:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    dc50:      	uxtb	w16, w7
    dc54:      	cmp	w16, wzr
    dc58:      	b.eq	0xde34 <_stogir.vector-arithmetic.valid-type?+0x38c>
    dc5c:      	uxtb	w16, w8
    dc60:      	cmp	w16, wzr
    dc64:      	b.eq	0xde34 <_stogir.vector-arithmetic.valid-type?+0x38c>
    dc68:      	sxtw	x2, w1
    dc6c:      	cmp	x2, #0xc
    dc70:      	cset	w21, eq
    dc74:      	cmp	x2, #0xd
    dc78:      	cset	w22, eq
    dc7c:      	uxtb	w16, w19
    dc80:      	cmp	w16, wzr
    dc84:      	b.ne	0xdd54 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    dc88:      	uxtb	w16, w20
    dc8c:      	cmp	w16, wzr
    dc90:      	b.ne	0xdd54 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    dc94:      	uxtb	w16, w11
    dc98:      	cmp	w16, wzr
    dc9c:      	b.ne	0xdd54 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    dca0:      	uxtb	w16, w12
    dca4:      	cmp	w16, wzr
    dca8:      	b.ne	0xdd54 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    dcac:      	uxtb	w16, w13
    dcb0:      	cmp	w16, wzr
    dcb4:      	b.ne	0xdd54 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    dcb8:      	uxtb	w16, w14
    dcbc:      	cmp	w16, wzr
    dcc0:      	b.ne	0xdd54 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    dcc4:      	uxtb	w16, w15
    dcc8:      	cmp	w16, wzr
    dccc:      	b.ne	0xdd54 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    dcd0:      	cmp	x2, #0x1
    dcd4:      	cset	w0, eq
    dcd8:      	cmp	x2, #0x1
    dcdc:      	cset	w1, ge
    dce0:      	cmp	x2, #0xb
    dce4:      	cset	w2, le
    dce8:      	uxtb	w16, w7
    dcec:      	cmp	w16, wzr
    dcf0:      	b.eq	0xdda4 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    dcf4:      	uxtb	w16, w8
    dcf8:      	cmp	w16, wzr
    dcfc:      	b.eq	0xdda4 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    dd00:      	uxtb	w16, w1
    dd04:      	cmp	w16, wzr
    dd08:      	b.eq	0xde2c <_stogir.vector-arithmetic.valid-type?+0x384>
    dd0c:      	uxtb	w16, w2
    dd10:      	cmp	w16, wzr
    dd14:      	b.eq	0xde2c <_stogir.vector-arithmetic.valid-type?+0x384>
    dd18:      	uxtb	w16, w0
    dd1c:      	cmp	w16, wzr
    dd20:      	cset	x0, eq
    dd24:      	b	0xde30 <_stogir.vector-arithmetic.valid-type?+0x388>
    dd28:      	movz	x0, #0x0, lsl #48
    dd2c:      	ldr	x19, [sp, #0x10]
    dd30:      	ldr	x20, [sp, #0x18]
    dd34:      	ldr	x21, [sp, #0x20]
    dd38:      	ldr	x22, [sp, #0x28]
    dd3c:      	ldr	x29, [sp]
    dd40:      	ldr	x30, [sp, #0x8]
    dd44:      	add	sp, sp, #0x30
    dd48:      	ret
    dd4c:      	ubfx	x0, x20, #0, #8
    dd50:      	b	0xdd2c <_stogir.vector-arithmetic.valid-type?+0x284>
    dd54:      	bl	0xdd54 <_stogir.vector-arithmetic.valid-type?+0x2ac>
		000000000000dd54:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    dd58:      	cmp	x0, #0x0
    dd5c:      	b.eq	0xdd68 <_stogir.vector-arithmetic.valid-type?+0x2c0>
    dd60:      	mov	x0, #0x1                ; =1
    dd64:      	b	0xdd50 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    dd68:      	uxtb	w16, w21
    dd6c:      	cmp	w16, wzr
    dd70:      	b.ne	0xdd88 <_stogir.vector-arithmetic.valid-type?+0x2e0>
    dd74:      	uxtb	w16, w22
    dd78:      	cmp	w16, wzr
    dd7c:      	b.ne	0xdd88 <_stogir.vector-arithmetic.valid-type?+0x2e0>
    dd80:      	movz	x0, #0x0, lsl #48
    dd84:      	b	0xdd50 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    dd88:      	uxtb	w16, w19
    dd8c:      	cmp	w16, wzr
    dd90:      	b.eq	0xdd4c <_stogir.vector-arithmetic.valid-type?+0x2a4>
    dd94:      	mov	x0, #0x1                ; =1
    dd98:      	b	0xdd50 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    dd9c:      	movz	x0, #0x0, lsl #48
    dda0:      	b	0xdd50 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    dda4:      	uxtb	w16, w3
    dda8:      	cmp	w16, wzr
    ddac:      	b.ne	0xde18 <_stogir.vector-arithmetic.valid-type?+0x370>
    ddb0:      	uxtb	w16, w4
    ddb4:      	cmp	w16, wzr
    ddb8:      	b.ne	0xde18 <_stogir.vector-arithmetic.valid-type?+0x370>
    ddbc:      	uxtb	w16, w5
    ddc0:      	cmp	w16, wzr
    ddc4:      	b.ne	0xde18 <_stogir.vector-arithmetic.valid-type?+0x370>
    ddc8:      	uxtb	w16, w21
    ddcc:      	cmp	w16, wzr
    ddd0:      	b.ne	0xde8c <_stogir.vector-arithmetic.valid-type?+0x3e4>
    ddd4:      	uxtb	w16, w22
    ddd8:      	cmp	w16, wzr
    dddc:      	b.ne	0xde8c <_stogir.vector-arithmetic.valid-type?+0x3e4>
    dde0:      	uxtb	w16, w1
    dde4:      	cmp	w16, wzr
    dde8:      	b.eq	0xde9c <_stogir.vector-arithmetic.valid-type?+0x3f4>
    ddec:      	uxtb	w16, w2
    ddf0:      	cmp	w16, wzr
    ddf4:      	b.eq	0xde9c <_stogir.vector-arithmetic.valid-type?+0x3f4>
    ddf8:      	uxtb	w16, w0
    ddfc:      	cmp	w16, wzr
    de00:      	b.eq	0xdea4 <_stogir.vector-arithmetic.valid-type?+0x3fc>
    de04:      	uxtb	w16, w9
    de08:      	cmp	w16, wzr
    de0c:      	b.eq	0xdeac <_stogir.vector-arithmetic.valid-type?+0x404>
    de10:      	mov	x0, #0x1                ; =1
    de14:      	b	0xdeb0 <_stogir.vector-arithmetic.valid-type?+0x408>
    de18:      	uxtb	w16, w1
    de1c:      	cmp	w16, wzr
    de20:      	b.eq	0xdd9c <_stogir.vector-arithmetic.valid-type?+0x2f4>
    de24:      	ubfx	x0, x2, #0, #8
    de28:      	b	0xdda0 <_stogir.vector-arithmetic.valid-type?+0x2f8>
    de2c:      	movz	x0, #0x0, lsl #48
    de30:      	b	0xdda0 <_stogir.vector-arithmetic.valid-type?+0x2f8>
    de34:      	cmp	x2, #0x1a
    de38:      	b.eq	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    de3c:      	cmp	x2, #0x1b
    de40:      	b.eq	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    de44:      	cmp	x2, #0x1c
    de48:      	b.eq	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    de4c:      	cmp	x2, #0x1d
    de50:      	b.eq	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    de54:      	uxtb	w16, w6
    de58:      	cmp	w16, wzr
    de5c:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    de60:      	uxtb	w16, w3
    de64:      	cmp	w16, wzr
    de68:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    de6c:      	uxtb	w16, w4
    de70:      	cmp	w16, wzr
    de74:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    de78:      	uxtb	w16, w5
    de7c:      	cmp	w16, wzr
    de80:      	b.ne	0xdc68 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    de84:      	movz	x0, #0x0, lsl #48
    de88:      	b	0xdd50 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    de8c:      	uxtb	w16, w6
    de90:      	cmp	w16, wzr
    de94:      	cset	x0, eq
    de98:      	b	0xdda0 <_stogir.vector-arithmetic.valid-type?+0x2f8>
    de9c:      	movz	x0, #0x0, lsl #48
    dea0:      	b	0xde98 <_stogir.vector-arithmetic.valid-type?+0x3f0>
    dea4:      	mov	x0, #0x1                ; =1
    dea8:      	b	0xdea0 <_stogir.vector-arithmetic.valid-type?+0x3f8>
    deac:      	ubfx	x0, x10, #0, #8
    deb0:      	b	0xdea8 <_stogir.vector-arithmetic.valid-type?+0x400>
