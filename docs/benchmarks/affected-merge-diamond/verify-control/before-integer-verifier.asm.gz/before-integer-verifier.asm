000000000000093c <_stogir.verify.integer-operations-target-structured>:
     93c: d10c03ff     	sub	sp, sp, #0x300
     940: f90003fd     	str	x29, [sp]
     944: f90007fe     	str	x30, [sp, #0x8]
     948: 910003fd     	mov	x29, sp
     94c: f9015bf3     	str	x19, [sp, #0x2b0]
     950: f9015ff4     	str	x20, [sp, #0x2b8]
     954: f90163f5     	str	x21, [sp, #0x2c0]
     958: f90167f6     	str	x22, [sp, #0x2c8]
     95c: f9016bf7     	str	x23, [sp, #0x2d0]
     960: f9016ff8     	str	x24, [sp, #0x2d8]
     964: f90173f9     	str	x25, [sp, #0x2e0]
     968: f90177fa     	str	x26, [sp, #0x2e8]
     96c: f9017bfb     	str	x27, [sp, #0x2f0]
     970: f9017ffc     	str	x28, [sp, #0x2f8]
     974: 2a1f0033     	orr	w19, w1, wzr
     978: 2a1f0034     	orr	w20, w1, wzr
     97c: 2a1f0035     	orr	w21, w1, wzr
     980: 9101e016     	add	x22, x0, #0x78
     984: 9100a017     	add	x23, x0, #0x28
     988: 91014018     	add	x24, x0, #0x50
     98c: 910083f0     	add	x16, sp, #0x20
     990: aa1f0201     	orr	x1, x16, xzr
     994: 91002039     	add	x25, x1, #0x8
     998: 910103f0     	add	x16, sp, #0x40
     99c: aa1f0201     	orr	x1, x16, xzr
     9a0: 9100203a     	add	x26, x1, #0x8
     9a4: 910343f0     	add	x16, sp, #0xd0
     9a8: aa1f0201     	orr	x1, x16, xzr
     9ac: 9100203b     	add	x27, x1, #0x8
     9b0: 9103c3f0     	add	x16, sp, #0xf0
     9b4: aa1f0201     	orr	x1, x16, xzr
     9b8: 9100203c     	add	x28, x1, #0x8
     9bc: 910443f0     	add	x16, sp, #0x110
     9c0: aa1f0201     	orr	x1, x16, xzr
     9c4: 91002021     	add	x1, x1, #0x8
     9c8: 9104c3f0     	add	x16, sp, #0x130
     9cc: aa1f0202     	orr	x2, x16, xzr
     9d0: 91002042     	add	x2, x2, #0x8
     9d4: 910543f0     	add	x16, sp, #0x150
     9d8: aa1f0203     	orr	x3, x16, xzr
     9dc: 91002063     	add	x3, x3, #0x8
     9e0: 9105c3f0     	add	x16, sp, #0x170
     9e4: aa1f0204     	orr	x4, x16, xzr
     9e8: 91002084     	add	x4, x4, #0x8
     9ec: 910643f0     	add	x16, sp, #0x190
     9f0: aa1f0205     	orr	x5, x16, xzr
     9f4: 910020a5     	add	x5, x5, #0x8
     9f8: 910783f0     	add	x16, sp, #0x1e0
     9fc: aa1f0206     	orr	x6, x16, xzr
     a00: 910020c6     	add	x6, x6, #0x8
     a04: d2800027     	mov	x7, #0x1                ; =1
     a08: d2e00009     	movz	x9, #0x0, lsl #48
     a0c: 9000000a     	adrp	x10, 0x0 <_gap_verify_graph>
     a10: f940014a     	ldr	x10, [x10]
     a14: d2e0000b     	movz	x11, #0x0, lsl #48
     a18: f100017f     	cmp	x11, #0x0
     a1c: 54006981     	b.ne	0x174c <_stogir.verify.integer-operations-target-structured+0xe10>
     a20: f940040c     	ldr	x12, [x0, #0x8]
     a24: eb0c00ff     	cmp	x7, x12
     a28: 540069ca     	b.ge	0x1760 <_stogir.verify.integer-operations-target-structured+0xe24>
     a2c: f940000c     	ldr	x12, [x0]
     a30: 8b07118c     	add	x12, x12, x7, lsl #4
     a34: f940018d     	ldr	x13, [x12]
     a38: 53001dae     	uxtb	w14, w13
     a3c: f940058c     	ldr	x12, [x12, #0x8]
     a40: aa1f01cf     	orr	x15, x14, xzr
     a44: 910043f0     	add	x16, sp, #0x10
     a48: f900020d     	str	x13, [x16]
     a4c: 910043f0     	add	x16, sp, #0x10
     a50: f900060c     	str	x12, [x16, #0x8]
     a54: f9403c0c     	ldr	x12, [x0, #0x78]
     a58: b867798c     	ldr	w12, [x12, x7, lsl #2]
     a5c: f1020dff     	cmp	x15, #0x83
     a60: 5400212a     	b.ge	0xe84 <_stogir.verify.integer-operations-target-structured+0x548>
     a64: 90000010     	adrp	x16, 0x0 <_gap_verify_graph>
     a68: f9400210     	ldr	x16, [x16]
     a6c: 786f7a0d     	ldrh	w13, [x16, x15, lsl #1]
     a70: f10039ff     	cmp	x15, #0xe
     a74: 5400680b     	b.lt	0x1774 <_stogir.verify.integer-operations-target-structured+0xe38>
     a78: f90103e0     	str	x0, [sp, #0x200]
     a7c: f1005dff     	cmp	x15, #0x17
     a80: 1a9fc7e0     	cset	w0, le
     a84: d3401c00     	ubfx	x0, x0, #0, #8
     a88: f90107e0     	str	x0, [sp, #0x208]
     a8c: 2a1f00e0     	orr	w0, w7, wzr
     a90: f9010be1     	str	x1, [sp, #0x210]
     a94: 121e01a1     	and	w1, w13, #0x4
     a98: d3407c21     	ubfx	x1, x1, #0, #32
     a9c: f9011be8     	str	x8, [sp, #0x230]
     aa0: f90147e2     	str	x2, [sp, #0x288]
     aa4: 910043e2     	add	x2, sp, #0x10
     aa8: f9013fe3     	str	x3, [sp, #0x278]
     aac: 2a0c03e3     	mov	w3, w12
     ab0: f90137e4     	str	x4, [sp, #0x268]
     ab4: f90133e5     	str	x5, [sp, #0x260]
     ab8: f9012fe6     	str	x6, [sp, #0x258]
     abc: f9012be7     	str	x7, [sp, #0x250]
     ac0: b90273ee     	str	w14, [sp, #0x270]
     ac4: b90283ec     	str	w12, [sp, #0x280]
     ac8: b90293e0     	str	w0, [sp, #0x290]
     acc: b9021bf3     	str	w19, [sp, #0x218]
     ad0: 2a0d03f3     	mov	w19, w13
     ad4: b90223f4     	str	w20, [sp, #0x220]
     ad8: aa0903f4     	mov	x20, x9
     adc: b9022bf5     	str	w21, [sp, #0x228]
     ae0: aa0103f5     	mov	x21, x1
     ae4: 2a0003e1     	mov	w1, w0
     ae8: f94103e0     	ldr	x0, [sp, #0x200]
     aec: f9011ff8     	str	x24, [sp, #0x238]
     af0: aa0f03f8     	mov	x24, x15
     af4: f90123f7     	str	x23, [sp, #0x240]
     af8: aa0b03f7     	mov	x23, x11
     afc: f90127f6     	str	x22, [sp, #0x248]
     b00: aa0a03f6     	mov	x22, x10
     b04: 94000000     	bl	0xb04 <_stogir.verify.integer-operations-target-structured+0x1c8>
     b08: 53001c01     	uxtb	w1, w0
     b0c: f10002bf     	cmp	x21, #0x0
     b10: 54001c21     	b.ne	0xe94 <_stogir.verify.integer-operations-target-structured+0x558>
     b14: f100003f     	cmp	x1, #0x0
     b18: 54001be1     	b.ne	0xe94 <_stogir.verify.integer-operations-target-structured+0x558>
     b1c: f9014fe0     	str	x0, [sp, #0x298]
     b20: aa0103f5     	mov	x21, x1
     b24: f101131f     	cmp	x24, #0x44
     b28: 540002e1     	b.ne	0xb84 <_stogir.verify.integer-operations-target-structured+0x248>
     b2c: f10002bf     	cmp	x21, #0x0
     b30: 540002a1     	b.ne	0xb84 <_stogir.verify.integer-operations-target-structured+0x248>
     b34: 910103e8     	add	x8, sp, #0x40
     b38: f94103e0     	ldr	x0, [sp, #0x200]
     b3c: b94293e1     	ldr	w1, [sp, #0x290]
     b40: 94000000     	bl	0xb40 <_stogir.verify.integer-operations-target-structured+0x204>
     b44: 910103f0     	add	x16, sp, #0x40
     b48: b9400200     	ldr	w0, [x16]
     b4c: d340fc10     	lsr	x16, x0, #0
     b50: f100061f     	cmp	x16, #0x1
     b54: 540000e0     	b.eq	0xb70 <_stogir.verify.integer-operations-target-structured+0x234>
     b58: 54000043     	b.lo	0xb60 <_stogir.verify.integer-operations-target-structured+0x224>
     b5c: 14000006     	b	0xb74 <_stogir.verify.integer-operations-target-structured+0x238>
     b60: f100021f     	cmp	x16, #0x0
     b64: 54000040     	b.eq	0xb6c <_stogir.verify.integer-operations-target-structured+0x230>
     b68: 14000003     	b	0xb74 <_stogir.verify.integer-operations-target-structured+0x238>
     b6c: 140000e5     	b	0xf00 <_stogir.verify.integer-operations-target-structured+0x5c4>
     b70: 14000002     	b	0xb78 <_stogir.verify.integer-operations-target-structured+0x23c>
     b74: 140000e6     	b	0xf0c <_stogir.verify.integer-operations-target-structured+0x5d0>
     b78: 910103f0     	add	x16, sp, #0x40
     b7c: f9400616     	ldr	x22, [x16, #0x8]
     b80: f9400757     	ldr	x23, [x26, #0x8]
     b84: f100771f     	cmp	x24, #0x1d
     b88: 54001c60     	b.eq	0xf14 <_stogir.verify.integer-operations-target-structured+0x5d8>
     b8c: f1007b1f     	cmp	x24, #0x1e
     b90: 54001c20     	b.eq	0xf14 <_stogir.verify.integer-operations-target-structured+0x5d8>
     b94: 121d0260     	and	w0, w19, #0x8
     b98: d3407c00     	ubfx	x0, x0, #0, #32
     b9c: f100001f     	cmp	x0, #0x0
     ba0: 540023a1     	b.ne	0x1014 <_stogir.verify.integer-operations-target-structured+0x6d8>
     ba4: f100b31f     	cmp	x24, #0x2c
     ba8: 54002360     	b.eq	0x1014 <_stogir.verify.integer-operations-target-structured+0x6d8>
     bac: 121c0260     	and	w0, w19, #0x10
     bb0: d3407c00     	ubfx	x0, x0, #0, #32
     bb4: f100001f     	cmp	x0, #0x0
     bb8: 540002a0     	b.eq	0xc0c <_stogir.verify.integer-operations-target-structured+0x2d0>
     bbc: 910343e8     	add	x8, sp, #0xd0
     bc0: f94103e0     	ldr	x0, [sp, #0x200]
     bc4: b94293e1     	ldr	w1, [sp, #0x290]
     bc8: 94000000     	bl	0xbc8 <_stogir.verify.integer-operations-target-structured+0x28c>
     bcc: 910343f0     	add	x16, sp, #0xd0
     bd0: b9400200     	ldr	w0, [x16]
     bd4: d340fc10     	lsr	x16, x0, #0
     bd8: f100061f     	cmp	x16, #0x1
     bdc: 540000e0     	b.eq	0xbf8 <_stogir.verify.integer-operations-target-structured+0x2bc>
     be0: 54000043     	b.lo	0xbe8 <_stogir.verify.integer-operations-target-structured+0x2ac>
     be4: 14000006     	b	0xbfc <_stogir.verify.integer-operations-target-structured+0x2c0>
     be8: f100021f     	cmp	x16, #0x0
     bec: 54000040     	b.eq	0xbf4 <_stogir.verify.integer-operations-target-structured+0x2b8>
     bf0: 14000003     	b	0xbfc <_stogir.verify.integer-operations-target-structured+0x2c0>
     bf4: 14000131     	b	0x10b8 <_stogir.verify.integer-operations-target-structured+0x77c>
     bf8: 14000002     	b	0xc00 <_stogir.verify.integer-operations-target-structured+0x2c4>
     bfc: 140002b5     	b	0x16d0 <_stogir.verify.integer-operations-target-structured+0xd94>
     c00: 910343f0     	add	x16, sp, #0xd0
     c04: f9400616     	ldr	x22, [x16, #0x8]
     c08: f9400777     	ldr	x23, [x27, #0x8]
     c0c: 121b0260     	and	w0, w19, #0x20
     c10: d3407c00     	ubfx	x0, x0, #0, #32
     c14: f100001f     	cmp	x0, #0x0
     c18: 540002a0     	b.eq	0xc6c <_stogir.verify.integer-operations-target-structured+0x330>
     c1c: 9103c3e8     	add	x8, sp, #0xf0
     c20: f94103e0     	ldr	x0, [sp, #0x200]
     c24: b94293e1     	ldr	w1, [sp, #0x290]
     c28: 94000000     	bl	0xc28 <_stogir.verify.integer-operations-target-structured+0x2ec>
     c2c: 9103c3f0     	add	x16, sp, #0xf0
     c30: b9400200     	ldr	w0, [x16]
     c34: d340fc10     	lsr	x16, x0, #0
     c38: f100061f     	cmp	x16, #0x1
     c3c: 540000e0     	b.eq	0xc58 <_stogir.verify.integer-operations-target-structured+0x31c>
     c40: 54000043     	b.lo	0xc48 <_stogir.verify.integer-operations-target-structured+0x30c>
     c44: 14000006     	b	0xc5c <_stogir.verify.integer-operations-target-structured+0x320>
     c48: f100021f     	cmp	x16, #0x0
     c4c: 54000040     	b.eq	0xc54 <_stogir.verify.integer-operations-target-structured+0x318>
     c50: 14000003     	b	0xc5c <_stogir.verify.integer-operations-target-structured+0x320>
     c54: 1400011c     	b	0x10c4 <_stogir.verify.integer-operations-target-structured+0x788>
     c58: 14000002     	b	0xc60 <_stogir.verify.integer-operations-target-structured+0x324>
     c5c: 1400029b     	b	0x16c8 <_stogir.verify.integer-operations-target-structured+0xd8c>
     c60: 9103c3f0     	add	x16, sp, #0xf0
     c64: f9400616     	ldr	x22, [x16, #0x8]
     c68: f9400797     	ldr	x23, [x28, #0x8]
     c6c: 121a0260     	and	w0, w19, #0x40
     c70: d3407c00     	ubfx	x0, x0, #0, #32
     c74: f100001f     	cmp	x0, #0x0
     c78: 540022c1     	b.ne	0x10d0 <_stogir.verify.integer-operations-target-structured+0x794>
     c7c: f9410be0     	ldr	x0, [sp, #0x210]
     c80: 12190261     	and	w1, w19, #0x80
     c84: d3407c21     	ubfx	x1, x1, #0, #32
     c88: f100003f     	cmp	x1, #0x0
     c8c: 54002561     	b.ne	0x1138 <_stogir.verify.integer-operations-target-structured+0x7fc>
     c90: f9010be0     	str	x0, [sp, #0x210]
     c94: f94147e0     	ldr	x0, [sp, #0x288]
     c98: 12180261     	and	w1, w19, #0x100
     c9c: d3407c21     	ubfx	x1, x1, #0, #32
     ca0: f100003f     	cmp	x1, #0x0
     ca4: 54002801     	b.ne	0x11a4 <_stogir.verify.integer-operations-target-structured+0x868>
     ca8: f90147e0     	str	x0, [sp, #0x288]
     cac: f9413fe0     	ldr	x0, [sp, #0x278]
     cb0: 12170261     	and	w1, w19, #0x200
     cb4: d3407c21     	ubfx	x1, x1, #0, #32
     cb8: f100003f     	cmp	x1, #0x0
     cbc: 54002ac1     	b.ne	0x1214 <_stogir.verify.integer-operations-target-structured+0x8d8>
     cc0: f9013fe0     	str	x0, [sp, #0x278]
     cc4: f94137e0     	ldr	x0, [sp, #0x268]
     cc8: f100f31f     	cmp	x24, #0x3c
     ccc: 54005581     	b.ne	0x177c <_stogir.verify.integer-operations-target-structured+0xe40>
     cd0: 910643e8     	add	x8, sp, #0x190
     cd4: b94293e1     	ldr	w1, [sp, #0x290]
     cd8: f90137e0     	str	x0, [sp, #0x268]
     cdc: f94103e0     	ldr	x0, [sp, #0x200]
     ce0: 94000000     	bl	0xce0 <_stogir.verify.integer-operations-target-structured+0x3a4>
     ce4: 910643f0     	add	x16, sp, #0x190
     ce8: b9400200     	ldr	w0, [x16]
     cec: d340fc10     	lsr	x16, x0, #0
     cf0: f100061f     	cmp	x16, #0x1
     cf4: 54000100     	b.eq	0xd14 <_stogir.verify.integer-operations-target-structured+0x3d8>
     cf8: 54000043     	b.lo	0xd00 <_stogir.verify.integer-operations-target-structured+0x3c4>
     cfc: 14000007     	b	0xd18 <_stogir.verify.integer-operations-target-structured+0x3dc>
     d00: f100021f     	cmp	x16, #0x0
     d04: 54000040     	b.eq	0xd0c <_stogir.verify.integer-operations-target-structured+0x3d0>
     d08: 14000004     	b	0xd18 <_stogir.verify.integer-operations-target-structured+0x3dc>
     d0c: f94133e0     	ldr	x0, [sp, #0x260]
     d10: 1400015d     	b	0x1284 <_stogir.verify.integer-operations-target-structured+0x948>
     d14: 14000002     	b	0xd1c <_stogir.verify.integer-operations-target-structured+0x3e0>
     d18: 1400015e     	b	0x1290 <_stogir.verify.integer-operations-target-structured+0x954>
     d1c: 910643f0     	add	x16, sp, #0x190
     d20: f9400616     	ldr	x22, [x16, #0x8]
     d24: f94133e0     	ldr	x0, [sp, #0x260]
     d28: f9400417     	ldr	x23, [x0, #0x8]
     d2c: f101e31f     	cmp	x24, #0x78
     d30: 540052c1     	b.ne	0x1788 <_stogir.verify.integer-operations-target-structured+0xe4c>
     d34: 910043f0     	add	x16, sp, #0x10
     d38: b9400201     	ldr	w1, [x16]
     d3c: d3483c21     	ubfx	x1, x1, #8, #8
     d40: f100003f     	cmp	x1, #0x0
     d44: 54002aa1     	b.ne	0x1298 <_stogir.verify.integer-operations-target-structured+0x95c>
     d48: 910043f0     	add	x16, sp, #0x10
     d4c: b9400a01     	ldr	w1, [x16, #0x8]
     d50: 93407c21     	sxtw	x1, w1
     d54: f100003f     	cmp	x1, #0x0
     d58: 54000080     	b.eq	0xd68 <_stogir.verify.integer-operations-target-structured+0x42c>
     d5c: 90000016     	adrp	x22, 0x0 <_gap_verify_graph>
     d60: f94002d6     	ldr	x22, [x22]
     d64: d28003f7     	mov	x23, #0x1f              ; =31
     d68: f90133e0     	str	x0, [sp, #0x260]
     d6c: 91000680     	add	x0, x20, #0x1
     d70: 93407c14     	sxtw	x20, w0
     d74: f9414fe0     	ldr	x0, [sp, #0x298]
     d78: 53003c00     	uxth	w0, w0
     d7c: 52800111     	mov	w17, #0x8               ; =8
     d80: 53003c10     	uxth	w16, w0
     d84: 53000e31     	ubfx	w17, w17, #0, #4
     d88: 1ad12600     	lsr	w0, w16, w17
     d8c: 53003c00     	uxth	w0, w0
     d90: 53001c00     	uxtb	w0, w0
     d94: f100001f     	cmp	x0, #0x0
     d98: 54004fc0     	b.eq	0x1790 <_stogir.verify.integer-operations-target-structured+0xe54>
     d9c: 910783e8     	add	x8, sp, #0x1e0
     da0: b94293e1     	ldr	w1, [sp, #0x290]
     da4: f90153f9     	str	x25, [sp, #0x2a0]
     da8: aa0003f9     	mov	x25, x0
     dac: f94103e0     	ldr	x0, [sp, #0x200]
     db0: 94000000     	bl	0xdb0 <_stogir.verify.integer-operations-target-structured+0x474>
     db4: 910783f0     	add	x16, sp, #0x1e0
     db8: b9400200     	ldr	w0, [x16]
     dbc: d340fc10     	lsr	x16, x0, #0
     dc0: f100061f     	cmp	x16, #0x1
     dc4: 54000100     	b.eq	0xde4 <_stogir.verify.integer-operations-target-structured+0x4a8>
     dc8: 54000043     	b.lo	0xdd0 <_stogir.verify.integer-operations-target-structured+0x494>
     dcc: 14000007     	b	0xde8 <_stogir.verify.integer-operations-target-structured+0x4ac>
     dd0: f100021f     	cmp	x16, #0x0
     dd4: 54000040     	b.eq	0xddc <_stogir.verify.integer-operations-target-structured+0x4a0>
     dd8: 14000004     	b	0xde8 <_stogir.verify.integer-operations-target-structured+0x4ac>
     ddc: f9412fe0     	ldr	x0, [sp, #0x258]
     de0: 14000154     	b	0x1330 <_stogir.verify.integer-operations-target-structured+0x9f4>
     de4: 14000002     	b	0xdec <_stogir.verify.integer-operations-target-structured+0x4b0>
     de8: 14000155     	b	0x133c <_stogir.verify.integer-operations-target-structured+0xa00>
     dec: 910783f0     	add	x16, sp, #0x1e0
     df0: f9400616     	ldr	x22, [x16, #0x8]
     df4: f9412fe0     	ldr	x0, [sp, #0x258]
     df8: f9400417     	ldr	x23, [x0, #0x8]
     dfc: f10002bf     	cmp	x21, #0x0
     e00: 54002a20     	b.eq	0x1344 <_stogir.verify.integer-operations-target-structured+0xa08>
     e04: f90157fa     	str	x26, [sp, #0x2a8]
     e08: f9012fe0     	str	x0, [sp, #0x258]
     e0c: b94283e0     	ldr	w0, [sp, #0x280]
     e10: 93407c00     	sxtw	x0, w0
     e14: 91001000     	add	x0, x0, #0x4
     e18: 937ffc10     	asr	x16, x0, #63
     e1c: d37efe10     	lsr	x16, x16, #62
     e20: 8b100000     	add	x0, x0, x16
     e24: 9342fc00     	asr	x0, x0, #2
     e28: f9412be1     	ldr	x1, [sp, #0x250]
     e2c: 8b010001     	add	x1, x0, x1
     e30: f9411be8     	ldr	x8, [sp, #0x230]
     e34: f94103e0     	ldr	x0, [sp, #0x200]
     e38: b9421bf3     	ldr	w19, [sp, #0x218]
     e3c: f94153f9     	ldr	x25, [sp, #0x2a0]
     e40: f94157fa     	ldr	x26, [sp, #0x2a8]
     e44: f94147e2     	ldr	x2, [sp, #0x288]
     e48: f9413fe3     	ldr	x3, [sp, #0x278]
     e4c: b9422bf5     	ldr	w21, [sp, #0x228]
     e50: f94137e4     	ldr	x4, [sp, #0x268]
     e54: f94133e5     	ldr	x5, [sp, #0x260]
     e58: f9412fe6     	ldr	x6, [sp, #0x258]
     e5c: f9411ff8     	ldr	x24, [sp, #0x238]
     e60: aa0103e7     	mov	x7, x1
     e64: f9410be1     	ldr	x1, [sp, #0x210]
     e68: aa1403e9     	mov	x9, x20
     e6c: b94223f4     	ldr	w20, [sp, #0x220]
     e70: aa1603ea     	mov	x10, x22
     e74: f94127f6     	ldr	x22, [sp, #0x248]
     e78: aa1703eb     	mov	x11, x23
     e7c: f94123f7     	ldr	x23, [sp, #0x240]
     e80: 17fffee6     	b	0xa18 <_stogir.verify.integer-operations-target-structured+0xdc>
     e84: 52a0000d     	movz	w13, #0x0, lsl #16
     e88: 17fffefa     	b	0xa70 <_stogir.verify.integer-operations-target-structured+0x134>
     e8c: d2e00000     	movz	x0, #0x0, lsl #48
     e90: 17fffefe     	b	0xa88 <_stogir.verify.integer-operations-target-structured+0x14c>
     e94: 910083e8     	add	x8, sp, #0x20
     e98: b9421be2     	ldr	w2, [sp, #0x218]
     e9c: f9014fe0     	str	x0, [sp, #0x298]
     ea0: f94103e0     	ldr	x0, [sp, #0x200]
     ea4: aa0103f5     	mov	x21, x1
     ea8: b94293e1     	ldr	w1, [sp, #0x290]
     eac: 94000000     	bl	0xeac <_stogir.verify.integer-operations-target-structured+0x570>
     eb0: 910083f0     	add	x16, sp, #0x20
     eb4: b9400200     	ldr	w0, [x16]
     eb8: d340fc10     	lsr	x16, x0, #0
     ebc: f100061f     	cmp	x16, #0x1
     ec0: 540000e0     	b.eq	0xedc <_stogir.verify.integer-operations-target-structured+0x5a0>
     ec4: 54000043     	b.lo	0xecc <_stogir.verify.integer-operations-target-structured+0x590>
     ec8: 14000006     	b	0xee0 <_stogir.verify.integer-operations-target-structured+0x5a4>
     ecc: f100021f     	cmp	x16, #0x0
     ed0: 54000040     	b.eq	0xed8 <_stogir.verify.integer-operations-target-structured+0x59c>
     ed4: 14000003     	b	0xee0 <_stogir.verify.integer-operations-target-structured+0x5a4>
     ed8: 14000007     	b	0xef4 <_stogir.verify.integer-operations-target-structured+0x5b8>
     edc: 14000002     	b	0xee4 <_stogir.verify.integer-operations-target-structured+0x5a8>
     ee0: 14000200     	b	0x16e0 <_stogir.verify.integer-operations-target-structured+0xda4>
     ee4: 910083f0     	add	x16, sp, #0x20
     ee8: f9400616     	ldr	x22, [x16, #0x8]
     eec: f9400737     	ldr	x23, [x25, #0x8]
     ef0: 17ffff0d     	b	0xb24 <_stogir.verify.integer-operations-target-structured+0x1e8>
     ef4: 91000680     	add	x0, x20, #0x1
     ef8: 93407c14     	sxtw	x20, w0
     efc: 17fffffd     	b	0xef0 <_stogir.verify.integer-operations-target-structured+0x5b4>
     f00: 91000680     	add	x0, x20, #0x1
     f04: 93407c14     	sxtw	x20, w0
     f08: 17ffff1f     	b	0xb84 <_stogir.verify.integer-operations-target-structured+0x248>
     f0c: d4200000     	brk	#0
     f10: 17ffffff     	b	0xf0c <_stogir.verify.integer-operations-target-structured+0x5d0>
     f14: 910043f0     	add	x16, sp, #0x10
     f18: b9400e00     	ldr	w0, [x16, #0xc]
     f1c: 93407c00     	sxtw	x0, w0
     f20: f100001f     	cmp	x0, #0x0
     f24: 54ffe380     	b.eq	0xb94 <_stogir.verify.integer-operations-target-structured+0x258>
     f28: 910043f0     	add	x16, sp, #0x10
     f2c: b9400e00     	ldr	w0, [x16, #0xc]
     f30: 910183e8     	add	x8, sp, #0x60
     f34: 2a0003e1     	mov	w1, w0
     f38: f94103e0     	ldr	x0, [sp, #0x200]
     f3c: 94000000     	bl	0xf3c <_stogir.verify.integer-operations-target-structured+0x600>
     f40: 910183f0     	add	x16, sp, #0x60
     f44: b9400200     	ldr	w0, [x16]
     f48: d340fc10     	lsr	x16, x0, #0
     f4c: f100061f     	cmp	x16, #0x1
     f50: 540000e0     	b.eq	0xf6c <_stogir.verify.integer-operations-target-structured+0x630>
     f54: 54000043     	b.lo	0xf5c <_stogir.verify.integer-operations-target-structured+0x620>
     f58: 14000006     	b	0xf70 <_stogir.verify.integer-operations-target-structured+0x634>
     f5c: f100021f     	cmp	x16, #0x0
     f60: 54000040     	b.eq	0xf68 <_stogir.verify.integer-operations-target-structured+0x62c>
     f64: 14000003     	b	0xf70 <_stogir.verify.integer-operations-target-structured+0x634>
     f68: 14000003     	b	0xf74 <_stogir.verify.integer-operations-target-structured+0x638>
     f6c: 14000006     	b	0xf84 <_stogir.verify.integer-operations-target-structured+0x648>
     f70: 14000027     	b	0x100c <_stogir.verify.integer-operations-target-structured+0x6d0>
     f74: 90000016     	adrp	x22, 0x0 <_gap_verify_graph>
     f78: f94002d6     	ldr	x22, [x22]
     f7c: d28002d7     	mov	x23, #0x16              ; =22
     f80: 17ffff05     	b	0xb94 <_stogir.verify.integer-operations-target-structured+0x258>
     f84: 910183f0     	add	x16, sp, #0x60
     f88: f9400600     	ldr	x0, [x16, #0x8]
     f8c: 910043f0     	add	x16, sp, #0x10
     f90: b9400e01     	ldr	w1, [x16, #0xc]
     f94: 93407c21     	sxtw	x1, w1
     f98: f100003f     	cmp	x1, #0x0
     f9c: 540002cb     	b.lt	0xff4 <_stogir.verify.integer-operations-target-structured+0x6b8>
     fa0: 53001c00     	uxtb	w0, w0
     fa4: f1020c1f     	cmp	x0, #0x83
     fa8: 540002ea     	b.ge	0x1004 <_stogir.verify.integer-operations-target-structured+0x6c8>
     fac: 90000011     	adrp	x17, 0x0 <_gap_verify_graph>
     fb0: f9400231     	ldr	x17, [x17]
     fb4: 38716801     	ldrb	w1, [x0, x17]
     fb8: 53001c30     	uxtb	w16, w1
     fbc: 121f0201     	and	w1, w16, #0x2
     fc0: 53001c21     	uxtb	w1, w1
     fc4: d3401c21     	ubfx	x1, x1, #0, #8
     fc8: f100003f     	cmp	x1, #0x0
     fcc: 1a9f17e1     	cset	w1, eq
     fd0: 53001c30     	uxtb	w16, w1
     fd4: 6b1f021f     	cmp	w16, wzr
     fd8: 9a9f17e1     	cset	x1, eq
     fdc: f100003f     	cmp	x1, #0x0
     fe0: 54000101     	b.ne	0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
     fe4: f101941f     	cmp	x0, #0x65
     fe8: 540000c0     	b.eq	0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
     fec: f101981f     	cmp	x0, #0x66
     ff0: 54000080     	b.eq	0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
     ff4: 90000016     	adrp	x22, 0x0 <_gap_verify_graph>
     ff8: f94002d6     	ldr	x22, [x22]
     ffc: d28005b7     	mov	x23, #0x2d              ; =45
    1000: 17ffffe0     	b	0xf80 <_stogir.verify.integer-operations-target-structured+0x644>
    1004: 52a00001     	movz	w1, #0x0, lsl #16
    1008: 17ffffec     	b	0xfb8 <_stogir.verify.integer-operations-target-structured+0x67c>
    100c: d4200000     	brk	#0
    1010: 17ffffff     	b	0x100c <_stogir.verify.integer-operations-target-structured+0x6d0>
    1014: f100b31f     	cmp	x24, #0x2c
    1018: 54000341     	b.ne	0x1080 <_stogir.verify.integer-operations-target-structured+0x744>
    101c: 910243e8     	add	x8, sp, #0x90
    1020: f94103e0     	ldr	x0, [sp, #0x200]
    1024: b94293e1     	ldr	w1, [sp, #0x290]
    1028: 94000000     	bl	0x1028 <_stogir.verify.integer-operations-target-structured+0x6ec>
    102c: 910243f0     	add	x16, sp, #0x90
    1030: f9400200     	ldr	x0, [x16]
    1034: 910243f0     	add	x16, sp, #0x90
    1038: f9400601     	ldr	x1, [x16, #0x8]
    103c: 910243f0     	add	x16, sp, #0x90
    1040: f9400a02     	ldr	x2, [x16, #0x10]
    1044: d3407c00     	ubfx	x0, x0, #0, #32
    1048: d340fc10     	lsr	x16, x0, #0
    104c: f100061f     	cmp	x16, #0x1
    1050: 540000e0     	b.eq	0x106c <_stogir.verify.integer-operations-target-structured+0x730>
    1054: 54000043     	b.lo	0x105c <_stogir.verify.integer-operations-target-structured+0x720>
    1058: 14000006     	b	0x1070 <_stogir.verify.integer-operations-target-structured+0x734>
    105c: f100021f     	cmp	x16, #0x0
    1060: 54000040     	b.eq	0x1068 <_stogir.verify.integer-operations-target-structured+0x72c>
    1064: 14000003     	b	0x1070 <_stogir.verify.integer-operations-target-structured+0x734>
    1068: 14000011     	b	0x10ac <_stogir.verify.integer-operations-target-structured+0x770>
    106c: 14000002     	b	0x1074 <_stogir.verify.integer-operations-target-structured+0x738>
    1070: 1400019a     	b	0x16d8 <_stogir.verify.integer-operations-target-structured+0xd9c>
    1074: aa0103f6     	mov	x22, x1
    1078: aa0203f7     	mov	x23, x2
    107c: 17fffecc     	b	0xbac <_stogir.verify.integer-operations-target-structured+0x270>
    1080: 9102c3e8     	add	x8, sp, #0xb0
    1084: f94103e0     	ldr	x0, [sp, #0x200]
    1088: b94293e1     	ldr	w1, [sp, #0x290]
    108c: 94000000     	bl	0x108c <_stogir.verify.integer-operations-target-structured+0x750>
    1090: 9102c3f0     	add	x16, sp, #0xb0
    1094: f9400200     	ldr	x0, [x16]
    1098: 9102c3f0     	add	x16, sp, #0xb0
    109c: f9400601     	ldr	x1, [x16, #0x8]
    10a0: 9102c3f0     	add	x16, sp, #0xb0
    10a4: f9400a02     	ldr	x2, [x16, #0x10]
    10a8: 17ffffe7     	b	0x1044 <_stogir.verify.integer-operations-target-structured+0x708>
    10ac: 91000680     	add	x0, x20, #0x1
    10b0: 93407c14     	sxtw	x20, w0
    10b4: 17fffff2     	b	0x107c <_stogir.verify.integer-operations-target-structured+0x740>
    10b8: 91000680     	add	x0, x20, #0x1
    10bc: 93407c14     	sxtw	x20, w0
    10c0: 17fffed3     	b	0xc0c <_stogir.verify.integer-operations-target-structured+0x2d0>
    10c4: 91000680     	add	x0, x20, #0x1
    10c8: 93407c14     	sxtw	x20, w0
    10cc: 17fffee8     	b	0xc6c <_stogir.verify.integer-operations-target-structured+0x330>
    10d0: 910443e8     	add	x8, sp, #0x110
    10d4: f94103e0     	ldr	x0, [sp, #0x200]
    10d8: b94293e1     	ldr	w1, [sp, #0x290]
    10dc: 94000000     	bl	0x10dc <_stogir.verify.integer-operations-target-structured+0x7a0>
    10e0: 910443f0     	add	x16, sp, #0x110
    10e4: b9400200     	ldr	w0, [x16]
    10e8: d340fc10     	lsr	x16, x0, #0
    10ec: f100061f     	cmp	x16, #0x1
    10f0: 54000100     	b.eq	0x1110 <_stogir.verify.integer-operations-target-structured+0x7d4>
    10f4: 54000043     	b.lo	0x10fc <_stogir.verify.integer-operations-target-structured+0x7c0>
    10f8: 14000007     	b	0x1114 <_stogir.verify.integer-operations-target-structured+0x7d8>
    10fc: f100021f     	cmp	x16, #0x0
    1100: 54000040     	b.eq	0x1108 <_stogir.verify.integer-operations-target-structured+0x7cc>
    1104: 14000004     	b	0x1114 <_stogir.verify.integer-operations-target-structured+0x7d8>
    1108: f9410be0     	ldr	x0, [sp, #0x210]
    110c: 14000008     	b	0x112c <_stogir.verify.integer-operations-target-structured+0x7f0>
    1110: 14000002     	b	0x1118 <_stogir.verify.integer-operations-target-structured+0x7dc>
    1114: 1400016b     	b	0x16c0 <_stogir.verify.integer-operations-target-structured+0xd84>
    1118: 910443f0     	add	x16, sp, #0x110
    111c: f9400616     	ldr	x22, [x16, #0x8]
    1120: f9410be0     	ldr	x0, [sp, #0x210]
    1124: f9400417     	ldr	x23, [x0, #0x8]
    1128: 17fffed6     	b	0xc80 <_stogir.verify.integer-operations-target-structured+0x344>
    112c: 91000681     	add	x1, x20, #0x1
    1130: 93407c34     	sxtw	x20, w1
    1134: 17fffffd     	b	0x1128 <_stogir.verify.integer-operations-target-structured+0x7ec>
    1138: 9104c3e8     	add	x8, sp, #0x130
    113c: b94293e1     	ldr	w1, [sp, #0x290]
    1140: f9010be0     	str	x0, [sp, #0x210]
    1144: f94103e0     	ldr	x0, [sp, #0x200]
    1148: 94000000     	bl	0x1148 <_stogir.verify.integer-operations-target-structured+0x80c>
    114c: 9104c3f0     	add	x16, sp, #0x130
    1150: b9400200     	ldr	w0, [x16]
    1154: d340fc10     	lsr	x16, x0, #0
    1158: f100061f     	cmp	x16, #0x1
    115c: 54000100     	b.eq	0x117c <_stogir.verify.integer-operations-target-structured+0x840>
    1160: 54000043     	b.lo	0x1168 <_stogir.verify.integer-operations-target-structured+0x82c>
    1164: 14000007     	b	0x1180 <_stogir.verify.integer-operations-target-structured+0x844>
    1168: f100021f     	cmp	x16, #0x0
    116c: 54000040     	b.eq	0x1174 <_stogir.verify.integer-operations-target-structured+0x838>
    1170: 14000004     	b	0x1180 <_stogir.verify.integer-operations-target-structured+0x844>
    1174: f94147e0     	ldr	x0, [sp, #0x288]
    1178: 14000008     	b	0x1198 <_stogir.verify.integer-operations-target-structured+0x85c>
    117c: 14000002     	b	0x1184 <_stogir.verify.integer-operations-target-structured+0x848>
    1180: 1400014e     	b	0x16b8 <_stogir.verify.integer-operations-target-structured+0xd7c>
    1184: 9104c3f0     	add	x16, sp, #0x130
    1188: f9400616     	ldr	x22, [x16, #0x8]
    118c: f94147e0     	ldr	x0, [sp, #0x288]
    1190: f9400417     	ldr	x23, [x0, #0x8]
    1194: 17fffec1     	b	0xc98 <_stogir.verify.integer-operations-target-structured+0x35c>
    1198: 91000681     	add	x1, x20, #0x1
    119c: 93407c34     	sxtw	x20, w1
    11a0: 17fffffd     	b	0x1194 <_stogir.verify.integer-operations-target-structured+0x858>
    11a4: 910543e8     	add	x8, sp, #0x150
    11a8: b94293e1     	ldr	w1, [sp, #0x290]
    11ac: b94223e2     	ldr	w2, [sp, #0x220]
    11b0: f90147e0     	str	x0, [sp, #0x288]
    11b4: f94103e0     	ldr	x0, [sp, #0x200]
    11b8: 94000000     	bl	0x11b8 <_stogir.verify.integer-operations-target-structured+0x87c>
    11bc: 910543f0     	add	x16, sp, #0x150
    11c0: b9400200     	ldr	w0, [x16]
    11c4: d340fc10     	lsr	x16, x0, #0
    11c8: f100061f     	cmp	x16, #0x1
    11cc: 54000100     	b.eq	0x11ec <_stogir.verify.integer-operations-target-structured+0x8b0>
    11d0: 54000043     	b.lo	0x11d8 <_stogir.verify.integer-operations-target-structured+0x89c>
    11d4: 14000007     	b	0x11f0 <_stogir.verify.integer-operations-target-structured+0x8b4>
    11d8: f100021f     	cmp	x16, #0x0
    11dc: 54000040     	b.eq	0x11e4 <_stogir.verify.integer-operations-target-structured+0x8a8>
    11e0: 14000004     	b	0x11f0 <_stogir.verify.integer-operations-target-structured+0x8b4>
    11e4: f9413fe0     	ldr	x0, [sp, #0x278]
    11e8: 14000008     	b	0x1208 <_stogir.verify.integer-operations-target-structured+0x8cc>
    11ec: 14000002     	b	0x11f4 <_stogir.verify.integer-operations-target-structured+0x8b8>
    11f0: 14000130     	b	0x16b0 <_stogir.verify.integer-operations-target-structured+0xd74>
    11f4: 910543f0     	add	x16, sp, #0x150
    11f8: f9400616     	ldr	x22, [x16, #0x8]
    11fc: f9413fe0     	ldr	x0, [sp, #0x278]
    1200: f9400417     	ldr	x23, [x0, #0x8]
    1204: 17fffeab     	b	0xcb0 <_stogir.verify.integer-operations-target-structured+0x374>
    1208: 91000681     	add	x1, x20, #0x1
    120c: 93407c34     	sxtw	x20, w1
    1210: 17fffffd     	b	0x1204 <_stogir.verify.integer-operations-target-structured+0x8c8>
    1214: 9105c3e8     	add	x8, sp, #0x170
    1218: b94293e1     	ldr	w1, [sp, #0x290]
    121c: b9422be2     	ldr	w2, [sp, #0x228]
    1220: f9013fe0     	str	x0, [sp, #0x278]
    1224: f94103e0     	ldr	x0, [sp, #0x200]
    1228: 94000000     	bl	0x1228 <_stogir.verify.integer-operations-target-structured+0x8ec>
    122c: 9105c3f0     	add	x16, sp, #0x170
    1230: b9400200     	ldr	w0, [x16]
    1234: d340fc10     	lsr	x16, x0, #0
    1238: f100061f     	cmp	x16, #0x1
    123c: 54000100     	b.eq	0x125c <_stogir.verify.integer-operations-target-structured+0x920>
    1240: 54000043     	b.lo	0x1248 <_stogir.verify.integer-operations-target-structured+0x90c>
    1244: 14000007     	b	0x1260 <_stogir.verify.integer-operations-target-structured+0x924>
    1248: f100021f     	cmp	x16, #0x0
    124c: 54000040     	b.eq	0x1254 <_stogir.verify.integer-operations-target-structured+0x918>
    1250: 14000004     	b	0x1260 <_stogir.verify.integer-operations-target-structured+0x924>
    1254: f94137e0     	ldr	x0, [sp, #0x268]
    1258: 14000008     	b	0x1278 <_stogir.verify.integer-operations-target-structured+0x93c>
    125c: 14000002     	b	0x1264 <_stogir.verify.integer-operations-target-structured+0x928>
    1260: 14000112     	b	0x16a8 <_stogir.verify.integer-operations-target-structured+0xd6c>
    1264: 9105c3f0     	add	x16, sp, #0x170
    1268: f9400616     	ldr	x22, [x16, #0x8]
    126c: f94137e0     	ldr	x0, [sp, #0x268]
    1270: f9400417     	ldr	x23, [x0, #0x8]
    1274: 17fffe95     	b	0xcc8 <_stogir.verify.integer-operations-target-structured+0x38c>
    1278: 91000681     	add	x1, x20, #0x1
    127c: 93407c34     	sxtw	x20, w1
    1280: 17fffffd     	b	0x1274 <_stogir.verify.integer-operations-target-structured+0x938>
    1284: 91000681     	add	x1, x20, #0x1
    1288: 93407c34     	sxtw	x20, w1
    128c: 17fffea8     	b	0xd2c <_stogir.verify.integer-operations-target-structured+0x3f0>
    1290: d4200000     	brk	#0
    1294: 17ffffff     	b	0x1290 <_stogir.verify.integer-operations-target-structured+0x954>
    1298: 910043f0     	add	x16, sp, #0x10
    129c: b9400a01     	ldr	w1, [x16, #0x8]
    12a0: 9106c3e8     	add	x8, sp, #0x1b0
    12a4: f90133e0     	str	x0, [sp, #0x260]
    12a8: f94103e0     	ldr	x0, [sp, #0x200]
    12ac: 94000000     	bl	0x12ac <_stogir.verify.integer-operations-target-structured+0x970>
    12b0: 9106c3f0     	add	x16, sp, #0x1b0
    12b4: b9400200     	ldr	w0, [x16]
    12b8: d340fc10     	lsr	x16, x0, #0
    12bc: f100061f     	cmp	x16, #0x1
    12c0: 540000e0     	b.eq	0x12dc <_stogir.verify.integer-operations-target-structured+0x9a0>
    12c4: 54000043     	b.lo	0x12cc <_stogir.verify.integer-operations-target-structured+0x990>
    12c8: 14000006     	b	0x12e0 <_stogir.verify.integer-operations-target-structured+0x9a4>
    12cc: f100021f     	cmp	x16, #0x0
    12d0: 54000040     	b.eq	0x12d8 <_stogir.verify.integer-operations-target-structured+0x99c>
    12d4: 14000003     	b	0x12e0 <_stogir.verify.integer-operations-target-structured+0x9a4>
    12d8: 14000003     	b	0x12e4 <_stogir.verify.integer-operations-target-structured+0x9a8>
    12dc: 14000006     	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x9b8>
    12e0: 14000012     	b	0x1328 <_stogir.verify.integer-operations-target-structured+0x9ec>
    12e4: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    12e8: f94002d6     	ldr	x22, [x22]
    12ec: d2800297     	mov	x23, #0x14              ; =20
    12f0: 17fffe9f     	b	0xd6c <_stogir.verify.integer-operations-target-structured+0x430>
    12f4: 9106c3f0     	add	x16, sp, #0x1b0
    12f8: f9400600     	ldr	x0, [x16, #0x8]
    12fc: 910043f0     	add	x16, sp, #0x10
    1300: b9400201     	ldr	w1, [x16]
    1304: d3407c00     	ubfx	x0, x0, #0, #32
    1308: d3483c21     	ubfx	x1, x1, #8, #8
    130c: d3483c00     	ubfx	x0, x0, #8, #8
    1310: eb01001f     	cmp	x0, x1
    1314: 54000080     	b.eq	0x1324 <_stogir.verify.integer-operations-target-structured+0x9e8>
    1318: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    131c: f94002d6     	ldr	x22, [x22]
    1320: d2800357     	mov	x23, #0x1a              ; =26
    1324: 17fffff3     	b	0x12f0 <_stogir.verify.integer-operations-target-structured+0x9b4>
    1328: d4200000     	brk	#0
    132c: 17ffffff     	b	0x1328 <_stogir.verify.integer-operations-target-structured+0x9ec>
    1330: 91000681     	add	x1, x20, #0x1
    1334: 93407c34     	sxtw	x20, w1
    1338: 17fffeb1     	b	0xdfc <_stogir.verify.integer-operations-target-structured+0x4c0>
    133c: d4200000     	brk	#0
    1340: 17ffffff     	b	0x133c <_stogir.verify.integer-operations-target-structured+0xa00>
    1344: f100033f     	cmp	x25, #0x0
    1348: 54000080     	b.eq	0x1358 <_stogir.verify.integer-operations-target-structured+0xa1c>
    134c: f90157fa     	str	x26, [sp, #0x2a8]
    1350: f9012fe0     	str	x0, [sp, #0x258]
    1354: 17fffeae     	b	0xe0c <_stogir.verify.integer-operations-target-structured+0x4d0>
    1358: 12000261     	and	w1, w19, #0x1
    135c: 121f0262     	and	w2, w19, #0x2
    1360: d3407c33     	ubfx	x19, x1, #0, #32
    1364: d3407c42     	ubfx	x2, x2, #0, #32
    1368: f94107f5     	ldr	x21, [sp, #0x208]
    136c: f10002bf     	cmp	x21, #0x0
    1370: 540000a1     	b.ne	0x1384 <_stogir.verify.integer-operations-target-structured+0xa48>
    1374: f100027f     	cmp	x19, #0x0
    1378: 54000061     	b.ne	0x1384 <_stogir.verify.integer-operations-target-structured+0xa48>
    137c: f100005f     	cmp	x2, #0x0
    1380: 54002100     	b.eq	0x17a0 <_stogir.verify.integer-operations-target-structured+0xe64>
    1384: 910043f0     	add	x16, sp, #0x10
    1388: b9400601     	ldr	w1, [x16, #0x4]
    138c: 93407c21     	sxtw	x1, w1
    1390: d2e00010     	movz	x16, #0x0, lsl #48
    1394: cb010203     	sub	x3, x16, x1
    1398: d1000464     	sub	x4, x3, #0x1
    139c: f100003f     	cmp	x1, #0x0
    13a0: 5400206d     	b.le	0x17ac <_stogir.verify.integer-operations-target-structured+0xe70>
    13a4: f94103f9     	ldr	x25, [sp, #0x200]
    13a8: f9400723     	ldr	x3, [x25, #0x8]
    13ac: eb03003f     	cmp	x1, x3
    13b0: 5400204a     	b.ge	0x17b8 <_stogir.verify.integer-operations-target-structured+0xe7c>
    13b4: f94127e5     	ldr	x5, [sp, #0x248]
    13b8: f94004a3     	ldr	x3, [x5, #0x8]
    13bc: eb03003f     	cmp	x1, x3
    13c0: 540003aa     	b.ge	0x1434 <_stogir.verify.integer-operations-target-structured+0xaf8>
    13c4: f9403f23     	ldr	x3, [x25, #0x78]
    13c8: b8617863     	ldr	w3, [x3, x1, lsl #2]
    13cc: 93407c63     	sxtw	x3, w3
    13d0: f100007f     	cmp	x3, #0x0
    13d4: 1a9fb7e3     	cset	w3, ge
    13d8: d3401c63     	ubfx	x3, x3, #0, #8
    13dc: f94123e6     	ldr	x6, [sp, #0x240]
    13e0: f9411fe8     	ldr	x8, [sp, #0x238]
    13e4: f100007f     	cmp	x3, #0x0
    13e8: 54000620     	b.eq	0x14ac <_stogir.verify.integer-operations-target-structured+0xb70>
    13ec: f100003f     	cmp	x1, #0x0
    13f0: 5400058d     	b.le	0x14a0 <_stogir.verify.integer-operations-target-structured+0xb64>
    13f4: f9400323     	ldr	x3, [x25]
    13f8: 8b011061     	add	x1, x3, x1, lsl #4
    13fc: f100003f     	cmp	x1, #0x0
    1400: 540005a1     	b.ne	0x14b4 <_stogir.verify.integer-operations-target-structured+0xb78>
    1404: f90103f9     	str	x25, [sp, #0x200]
    1408: f90127e5     	str	x5, [sp, #0x248]
    140c: f90157fa     	str	x26, [sp, #0x2a8]
    1410: f9012fe0     	str	x0, [sp, #0x258]
    1414: f90123e6     	str	x6, [sp, #0x240]
    1418: f9011fe8     	str	x8, [sp, #0x238]
    141c: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1420: f94002d6     	ldr	x22, [x22]
    1424: d28002f7     	mov	x23, #0x17              ; =23
    1428: 91000680     	add	x0, x20, #0x1
    142c: 93407c14     	sxtw	x20, w0
    1430: 17fffe77     	b	0xe0c <_stogir.verify.integer-operations-target-structured+0x4d0>
    1434: d2e00003     	movz	x3, #0x0, lsl #48
    1438: 17ffffe9     	b	0x13dc <_stogir.verify.integer-operations-target-structured+0xaa0>
    143c: d2e00003     	movz	x3, #0x0, lsl #48
    1440: 17ffffe7     	b	0x13dc <_stogir.verify.integer-operations-target-structured+0xaa0>
    1444: f100003f     	cmp	x1, #0x0
    1448: 54001bca     	b.ge	0x17c0 <_stogir.verify.integer-operations-target-structured+0xe84>
    144c: f94123e6     	ldr	x6, [sp, #0x240]
    1450: f94004c7     	ldr	x7, [x6, #0x8]
    1454: f9411fe8     	ldr	x8, [sp, #0x238]
    1458: f9400509     	ldr	x9, [x8, #0x8]
    145c: eb0900ff     	cmp	x7, x9
    1460: 54000181     	b.ne	0x1490 <_stogir.verify.integer-operations-target-structured+0xb54>
    1464: eb07007f     	cmp	x3, x7
    1468: 5400010c     	b.gt	0x1488 <_stogir.verify.integer-operations-target-structured+0xb4c>
    146c: f9402b23     	ldr	x3, [x25, #0x50]
    1470: b8647863     	ldr	w3, [x3, x4, lsl #2]
    1474: 93407c63     	sxtw	x3, w3
    1478: f100007f     	cmp	x3, #0x0
    147c: 1a9fd7e3     	cset	w3, gt
    1480: d3401c63     	ubfx	x3, x3, #0, #8
    1484: 17ffffd8     	b	0x13e4 <_stogir.verify.integer-operations-target-structured+0xaa8>
    1488: d2e00003     	movz	x3, #0x0, lsl #48
    148c: 17fffffe     	b	0x1484 <_stogir.verify.integer-operations-target-structured+0xb48>
    1490: d2e00003     	movz	x3, #0x0, lsl #48
    1494: 17fffffc     	b	0x1484 <_stogir.verify.integer-operations-target-structured+0xb48>
    1498: d2e00003     	movz	x3, #0x0, lsl #48
    149c: 17fffffa     	b	0x1484 <_stogir.verify.integer-operations-target-structured+0xb48>
    14a0: f9401721     	ldr	x1, [x25, #0x28]
    14a4: 8b041021     	add	x1, x1, x4, lsl #4
    14a8: 17ffffd5     	b	0x13fc <_stogir.verify.integer-operations-target-structured+0xac0>
    14ac: d2e00001     	movz	x1, #0x0, lsl #48
    14b0: 17ffffd3     	b	0x13fc <_stogir.verify.integer-operations-target-structured+0xac0>
    14b4: b9400021     	ldr	w1, [x1]
    14b8: 910043f0     	add	x16, sp, #0x10
    14bc: b9400203     	ldr	w3, [x16]
    14c0: d3483c21     	ubfx	x1, x1, #8, #8
    14c4: aa1f0024     	orr	x4, x1, xzr
    14c8: d3483c63     	ubfx	x3, x3, #8, #8
    14cc: f100187f     	cmp	x3, #0x6
    14d0: 54000701     	b.ne	0x15b0 <_stogir.verify.integer-operations-target-structured+0xc74>
    14d4: f100189f     	cmp	x4, #0x6
    14d8: 54000681     	b.ne	0x15a8 <_stogir.verify.integer-operations-target-structured+0xc6c>
    14dc: f1006b1f     	cmp	x24, #0x1a
    14e0: 540005c1     	b.ne	0x1598 <_stogir.verify.integer-operations-target-structured+0xc5c>
    14e4: d2800023     	mov	x3, #0x1                ; =1
    14e8: f100049f     	cmp	x4, #0x1
    14ec: 5400170b     	b.lt	0x17cc <_stogir.verify.integer-operations-target-structured+0xe90>
    14f0: f1002c9f     	cmp	x4, #0xb
    14f4: 540017ec     	b.gt	0x17f0 <_stogir.verify.integer-operations-target-structured+0xeb4>
    14f8: f100005f     	cmp	x2, #0x0
    14fc: 1a9f17e2     	cset	w2, eq
    1500: 53001c50     	uxtb	w16, w2
    1504: 6b1f021f     	cmp	w16, wzr
    1508: 9a9f17e2     	cset	x2, eq
    150c: f100005f     	cmp	x2, #0x0
    1510: 54001820     	b.eq	0x1814 <_stogir.verify.integer-operations-target-structured+0xed8>
    1514: b94273ed     	ldr	w13, [sp, #0x270]
    1518: f9012fe0     	str	x0, [sp, #0x258]
    151c: 2a0d03e0     	mov	w0, w13
    1520: f90127e5     	str	x5, [sp, #0x248]
    1524: f90123e6     	str	x6, [sp, #0x240]
    1528: f9011fe8     	str	x8, [sp, #0x238]
    152c: f90103f9     	str	x25, [sp, #0x200]
    1530: aa0403f9     	mov	x25, x4
    1534: f90157fa     	str	x26, [sp, #0x2a8]
    1538: aa0303fa     	mov	x26, x3
    153c: 94000000     	bl	0x153c <_stogir.verify.integer-operations-target-structured+0xc00>
    1540: f100001f     	cmp	x0, #0x0
    1544: 540003a1     	b.ne	0x15b8 <_stogir.verify.integer-operations-target-structured+0xc7c>
    1548: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    154c: f94002d6     	ldr	x22, [x22]
    1550: d2800397     	mov	x23, #0x1c              ; =28
    1554: 910043f0     	add	x16, sp, #0x10
    1558: b9400200     	ldr	w0, [x16]
    155c: f10002bf     	cmp	x21, #0x0
    1560: 540006c0     	b.eq	0x1638 <_stogir.verify.integer-operations-target-structured+0xcfc>
    1564: d2800021     	mov	x1, #0x1                ; =1
    1568: d3483c00     	ubfx	x0, x0, #8, #8
    156c: 93407c21     	sxtw	x1, w1
    1570: eb01001f     	cmp	x0, x1
    1574: 54000080     	b.eq	0x1584 <_stogir.verify.integer-operations-target-structured+0xc48>
    1578: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    157c: f94002d6     	ldr	x22, [x22]
    1580: d28004d7     	mov	x23, #0x26              ; =38
    1584: f10002bf     	cmp	x21, #0x0
    1588: 540005c1     	b.ne	0x1640 <_stogir.verify.integer-operations-target-structured+0xd04>
    158c: f100027f     	cmp	x19, #0x0
    1590: 54000581     	b.ne	0x1640 <_stogir.verify.integer-operations-target-structured+0xd04>
    1594: 17ffffa5     	b	0x1428 <_stogir.verify.integer-operations-target-structured+0xaec>
    1598: f1006f1f     	cmp	x24, #0x1b
    159c: 1a9f17e3     	cset	w3, eq
    15a0: d3401c63     	ubfx	x3, x3, #0, #8
    15a4: 17ffffd1     	b	0x14e8 <_stogir.verify.integer-operations-target-structured+0xbac>
    15a8: d2e00003     	movz	x3, #0x0, lsl #48
    15ac: 17ffffcf     	b	0x14e8 <_stogir.verify.integer-operations-target-structured+0xbac>
    15b0: d2e00003     	movz	x3, #0x0, lsl #48
    15b4: 17ffffcd     	b	0x14e8 <_stogir.verify.integer-operations-target-structured+0xbac>
    15b8: f100027f     	cmp	x19, #0x0
    15bc: 54fffcc0     	b.eq	0x1554 <_stogir.verify.integer-operations-target-structured+0xc18>
    15c0: f1006b1f     	cmp	x24, #0x1a
    15c4: 5400028b     	b.lt	0x1614 <_stogir.verify.integer-operations-target-structured+0xcd8>
    15c8: f1007b1f     	cmp	x24, #0x1e
    15cc: 5400024c     	b.gt	0x1614 <_stogir.verify.integer-operations-target-structured+0xcd8>
    15d0: f100073f     	cmp	x25, #0x1
    15d4: 54fffbab     	b.lt	0x1548 <_stogir.verify.integer-operations-target-structured+0xc0c>
    15d8: f1002f3f     	cmp	x25, #0xb
    15dc: 54fffb6c     	b.gt	0x1548 <_stogir.verify.integer-operations-target-structured+0xc0c>
    15e0: f100073f     	cmp	x25, #0x1
    15e4: 54fffb81     	b.ne	0x1554 <_stogir.verify.integer-operations-target-structured+0xc18>
    15e8: f100bb1f     	cmp	x24, #0x2e
    15ec: 54fffb40     	b.eq	0x1554 <_stogir.verify.integer-operations-target-structured+0xc18>
    15f0: f100bf1f     	cmp	x24, #0x2f
    15f4: 54fffb00     	b.eq	0x1554 <_stogir.verify.integer-operations-target-structured+0xc18>
    15f8: f100c31f     	cmp	x24, #0x30
    15fc: 54fffac0     	b.eq	0x1554 <_stogir.verify.integer-operations-target-structured+0xc18>
    1600: f100eb1f     	cmp	x24, #0x3a
    1604: 54fffa80     	b.eq	0x1554 <_stogir.verify.integer-operations-target-structured+0xc18>
    1608: f100ef1f     	cmp	x24, #0x3b
    160c: 54fff9e1     	b.ne	0x1548 <_stogir.verify.integer-operations-target-structured+0xc0c>
    1610: 17ffffd1     	b	0x1554 <_stogir.verify.integer-operations-target-structured+0xc18>
    1614: f100bb1f     	cmp	x24, #0x2e
    1618: 5400006b     	b.lt	0x1624 <_stogir.verify.integer-operations-target-structured+0xce8>
    161c: f100d71f     	cmp	x24, #0x35
    1620: 54fffd8d     	b.le	0x15d0 <_stogir.verify.integer-operations-target-structured+0xc94>
    1624: f100eb1f     	cmp	x24, #0x3a
    1628: 54fffd40     	b.eq	0x15d0 <_stogir.verify.integer-operations-target-structured+0xc94>
    162c: f100ef1f     	cmp	x24, #0x3b
    1630: 54fffd00     	b.eq	0x15d0 <_stogir.verify.integer-operations-target-structured+0xc94>
    1634: 17ffffc5     	b	0x1548 <_stogir.verify.integer-operations-target-structured+0xc0c>
    1638: aa1903e1     	mov	x1, x25
    163c: 17ffffcb     	b	0x1568 <_stogir.verify.integer-operations-target-structured+0xc2c>
    1640: 910043f0     	add	x16, sp, #0x10
    1644: b9400a00     	ldr	w0, [x16, #0x8]
    1648: 2a0003e1     	mov	w1, w0
    164c: f94103e0     	ldr	x0, [sp, #0x200]
    1650: 94000000     	bl	0x1650 <_stogir.verify.integer-operations-target-structured+0xd14>
    1654: f100001f     	cmp	x0, #0x0
    1658: 540000a1     	b.ne	0x166c <_stogir.verify.integer-operations-target-structured+0xd30>
    165c: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1660: f94002d6     	ldr	x22, [x22]
    1664: d28003b7     	mov	x23, #0x1d              ; =29
    1668: 17ffffcb     	b	0x1594 <_stogir.verify.integer-operations-target-structured+0xc58>
    166c: b9400000     	ldr	w0, [x0]
    1670: d3483c00     	ubfx	x0, x0, #8, #8
    1674: eb00033f     	cmp	x25, x0
    1678: 540000e0     	b.eq	0x1694 <_stogir.verify.integer-operations-target-structured+0xd58>
    167c: f100035f     	cmp	x26, #0x0
    1680: 540000c0     	b.eq	0x1698 <_stogir.verify.integer-operations-target-structured+0xd5c>
    1684: f100141f     	cmp	x0, #0x5
    1688: 54000060     	b.eq	0x1694 <_stogir.verify.integer-operations-target-structured+0xd58>
    168c: f1002c1f     	cmp	x0, #0xb
    1690: 54000041     	b.ne	0x1698 <_stogir.verify.integer-operations-target-structured+0xd5c>
    1694: 17fffff5     	b	0x1668 <_stogir.verify.integer-operations-target-structured+0xd2c>
    1698: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x6c4>
    169c: f94002d6     	ldr	x22, [x22]
    16a0: d28003b7     	mov	x23, #0x1d              ; =29
    16a4: 17fffffc     	b	0x1694 <_stogir.verify.integer-operations-target-structured+0xd58>
    16a8: d4200000     	brk	#0
    16ac: 17ffffff     	b	0x16a8 <_stogir.verify.integer-operations-target-structured+0xd6c>
    16b0: d4200000     	brk	#0
    16b4: 17ffffff     	b	0x16b0 <_stogir.verify.integer-operations-target-structured+0xd74>
    16b8: d4200000     	brk	#0
    16bc: 17ffffff     	b	0x16b8 <_stogir.verify.integer-operations-target-structured+0xd7c>
    16c0: d4200000     	brk	#0
    16c4: 17ffffff     	b	0x16c0 <_stogir.verify.integer-operations-target-structured+0xd84>
    16c8: d4200000     	brk	#0
    16cc: 17ffffff     	b	0x16c8 <_stogir.verify.integer-operations-target-structured+0xd8c>
    16d0: d4200000     	brk	#0
    16d4: 17ffffff     	b	0x16d0 <_stogir.verify.integer-operations-target-structured+0xd94>
    16d8: d4200000     	brk	#0
    16dc: 17ffffff     	b	0x16d8 <_stogir.verify.integer-operations-target-structured+0xd9c>
    16e0: d4200000     	brk	#0
    16e4: 17ffffff     	b	0x16e0 <_stogir.verify.integer-operations-target-structured+0xda4>
    16e8: f10002ff     	cmp	x23, #0x0
    16ec: 540002c1     	b.ne	0x1744 <_stogir.verify.integer-operations-target-structured+0xe08>
    16f0: 92407e96     	and	x22, x20, #0xffffffff
    16f4: d2e00000     	movz	x0, #0x0, lsl #48
    16f8: d2e00017     	movz	x23, #0x0, lsl #48
    16fc: f9411be1     	ldr	x1, [sp, #0x230]
    1700: f9000020     	str	x0, [x1]
    1704: f9000436     	str	x22, [x1, #0x8]
    1708: f9000837     	str	x23, [x1, #0x10]
    170c: f9415bf3     	ldr	x19, [sp, #0x2b0]
    1710: f9415ff4     	ldr	x20, [sp, #0x2b8]
    1714: f94163f5     	ldr	x21, [sp, #0x2c0]
    1718: f94167f6     	ldr	x22, [sp, #0x2c8]
    171c: f9416bf7     	ldr	x23, [sp, #0x2d0]
    1720: f9416ff8     	ldr	x24, [sp, #0x2d8]
    1724: f94173f9     	ldr	x25, [sp, #0x2e0]
    1728: f94177fa     	ldr	x26, [sp, #0x2e8]
    172c: f9417bfb     	ldr	x27, [sp, #0x2f0]
    1730: f9417ffc     	ldr	x28, [sp, #0x2f8]
    1734: f94003fd     	ldr	x29, [sp]
    1738: f94007fe     	ldr	x30, [sp, #0x8]
    173c: 910c03ff     	add	sp, sp, #0x300
    1740: d65f03c0     	ret
    1744: d2800020     	mov	x0, #0x1                ; =1
    1748: 17ffffed     	b	0x16fc <_stogir.verify.integer-operations-target-structured+0xdc0>
    174c: aa0903f4     	mov	x20, x9
    1750: f9011be8     	str	x8, [sp, #0x230]
    1754: aa0a03f6     	mov	x22, x10
    1758: aa0b03f7     	mov	x23, x11
    175c: 17ffffe3     	b	0x16e8 <_stogir.verify.integer-operations-target-structured+0xdac>
    1760: aa0903f4     	mov	x20, x9
    1764: f9011be8     	str	x8, [sp, #0x230]
    1768: aa0a03f6     	mov	x22, x10
    176c: aa0b03f7     	mov	x23, x11
    1770: 17ffffde     	b	0x16e8 <_stogir.verify.integer-operations-target-structured+0xdac>
    1774: f90103e0     	str	x0, [sp, #0x200]
    1778: 17fffdc5     	b	0xe8c <_stogir.verify.integer-operations-target-structured+0x550>
    177c: f90137e0     	str	x0, [sp, #0x268]
    1780: f94133e0     	ldr	x0, [sp, #0x260]
    1784: 17fffd6a     	b	0xd2c <_stogir.verify.integer-operations-target-structured+0x3f0>
    1788: f90133e0     	str	x0, [sp, #0x260]
    178c: 17fffd7a     	b	0xd74 <_stogir.verify.integer-operations-target-structured+0x438>
    1790: f90153f9     	str	x25, [sp, #0x2a0]
    1794: aa0003f9     	mov	x25, x0
    1798: f9412fe0     	ldr	x0, [sp, #0x258]
    179c: 17fffd98     	b	0xdfc <_stogir.verify.integer-operations-target-structured+0x4c0>
    17a0: f90157fa     	str	x26, [sp, #0x2a8]
    17a4: f9012fe0     	str	x0, [sp, #0x258]
    17a8: 17fffd99     	b	0xe0c <_stogir.verify.integer-operations-target-structured+0x4d0>
    17ac: f94103f9     	ldr	x25, [sp, #0x200]
    17b0: f94127e5     	ldr	x5, [sp, #0x248]
    17b4: 17ffff24     	b	0x1444 <_stogir.verify.integer-operations-target-structured+0xb08>
    17b8: f94127e5     	ldr	x5, [sp, #0x248]
    17bc: 17ffff20     	b	0x143c <_stogir.verify.integer-operations-target-structured+0xb00>
    17c0: f94123e6     	ldr	x6, [sp, #0x240]
    17c4: f9411fe8     	ldr	x8, [sp, #0x238]
    17c8: 17ffff34     	b	0x1498 <_stogir.verify.integer-operations-target-structured+0xb5c>
    17cc: f90103f9     	str	x25, [sp, #0x200]
    17d0: f90127e5     	str	x5, [sp, #0x248]
    17d4: f90157fa     	str	x26, [sp, #0x2a8]
    17d8: aa0303fa     	mov	x26, x3
    17dc: f9012fe0     	str	x0, [sp, #0x258]
    17e0: aa0403f9     	mov	x25, x4
    17e4: f90123e6     	str	x6, [sp, #0x240]
    17e8: f9011fe8     	str	x8, [sp, #0x238]
    17ec: 17ffff57     	b	0x1548 <_stogir.verify.integer-operations-target-structured+0xc0c>
    17f0: f90103f9     	str	x25, [sp, #0x200]
    17f4: f90127e5     	str	x5, [sp, #0x248]
    17f8: f90157fa     	str	x26, [sp, #0x2a8]
    17fc: aa0303fa     	mov	x26, x3
    1800: f9012fe0     	str	x0, [sp, #0x258]
    1804: aa0403f9     	mov	x25, x4
    1808: f90123e6     	str	x6, [sp, #0x240]
    180c: f9011fe8     	str	x8, [sp, #0x238]
    1810: 17ffff4e     	b	0x1548 <_stogir.verify.integer-operations-target-structured+0xc0c>
    1814: f90103f9     	str	x25, [sp, #0x200]
    1818: f90127e5     	str	x5, [sp, #0x248]
    181c: f90157fa     	str	x26, [sp, #0x2a8]
    1820: aa0303fa     	mov	x26, x3
    1824: f9012fe0     	str	x0, [sp, #0x258]
    1828: aa0403f9     	mov	x25, x4
    182c: f90123e6     	str	x6, [sp, #0x240]
    1830: f9011fe8     	str	x8, [sp, #0x238]
    1834: 17ffff61     	b	0x15b8 <_stogir.verify.integer-operations-target-structured+0xc7c>

