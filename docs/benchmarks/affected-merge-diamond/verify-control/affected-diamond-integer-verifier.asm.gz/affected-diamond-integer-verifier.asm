0000000000000994 <_stogir.verify.integer-operations-target-structured>:
     994: d10c43ff     	sub	sp, sp, #0x310
     998: f90003fd     	str	x29, [sp]
     99c: f90007fe     	str	x30, [sp, #0x8]
     9a0: 910003fd     	mov	x29, sp
     9a4: f9015ff3     	str	x19, [sp, #0x2b8]
     9a8: f90163f4     	str	x20, [sp, #0x2c0]
     9ac: f90167f5     	str	x21, [sp, #0x2c8]
     9b0: f9016bf6     	str	x22, [sp, #0x2d0]
     9b4: f9016ff7     	str	x23, [sp, #0x2d8]
     9b8: f90173f8     	str	x24, [sp, #0x2e0]
     9bc: f90177f9     	str	x25, [sp, #0x2e8]
     9c0: f9017bfa     	str	x26, [sp, #0x2f0]
     9c4: f9017ffb     	str	x27, [sp, #0x2f8]
     9c8: f90183fc     	str	x28, [sp, #0x300]
     9cc: 2a1f0033     	orr	w19, w1, wzr
     9d0: 2a1f0034     	orr	w20, w1, wzr
     9d4: 2a1f0035     	orr	w21, w1, wzr
     9d8: 9101e016     	add	x22, x0, #0x78
     9dc: 9100a017     	add	x23, x0, #0x28
     9e0: 91014018     	add	x24, x0, #0x50
     9e4: 910083f0     	add	x16, sp, #0x20
     9e8: aa1f0201     	orr	x1, x16, xzr
     9ec: 91002039     	add	x25, x1, #0x8
     9f0: 910103f0     	add	x16, sp, #0x40
     9f4: aa1f0201     	orr	x1, x16, xzr
     9f8: 9100203a     	add	x26, x1, #0x8
     9fc: 910343f0     	add	x16, sp, #0xd0
     a00: aa1f0201     	orr	x1, x16, xzr
     a04: 9100203b     	add	x27, x1, #0x8
     a08: 9103c3f0     	add	x16, sp, #0xf0
     a0c: aa1f0201     	orr	x1, x16, xzr
     a10: 9100203c     	add	x28, x1, #0x8
     a14: 910443f0     	add	x16, sp, #0x110
     a18: aa1f0201     	orr	x1, x16, xzr
     a1c: 91002021     	add	x1, x1, #0x8
     a20: 9104c3f0     	add	x16, sp, #0x130
     a24: aa1f0202     	orr	x2, x16, xzr
     a28: 91002042     	add	x2, x2, #0x8
     a2c: 910543f0     	add	x16, sp, #0x150
     a30: aa1f0203     	orr	x3, x16, xzr
     a34: 91002063     	add	x3, x3, #0x8
     a38: 9105c3f0     	add	x16, sp, #0x170
     a3c: aa1f0204     	orr	x4, x16, xzr
     a40: 91002084     	add	x4, x4, #0x8
     a44: 910643f0     	add	x16, sp, #0x190
     a48: aa1f0205     	orr	x5, x16, xzr
     a4c: 910020a5     	add	x5, x5, #0x8
     a50: 910783f0     	add	x16, sp, #0x1e0
     a54: aa1f0206     	orr	x6, x16, xzr
     a58: 910020c6     	add	x6, x6, #0x8
     a5c: d2800027     	mov	x7, #0x1                ; =1
     a60: d2e00009     	movz	x9, #0x0, lsl #48
     a64: 9000000a     	adrp	x10, 0x0 <_gap_verify_graph>
     a68: f940014a     	ldr	x10, [x10]
     a6c: d2e0000b     	movz	x11, #0x0, lsl #48
     a70: f100017f     	cmp	x11, #0x0
     a74: 540071c1     	b.ne	0x18ac <_stogir.verify.integer-operations-target-structured+0xf18>
     a78: f940040c     	ldr	x12, [x0, #0x8]
     a7c: eb0c00ff     	cmp	x7, x12
     a80: 5400720a     	b.ge	0x18c0 <_stogir.verify.integer-operations-target-structured+0xf2c>
     a84: f940000c     	ldr	x12, [x0]
     a88: 8b07118c     	add	x12, x12, x7, lsl #4
     a8c: f940018d     	ldr	x13, [x12]
     a90: 53001dae     	uxtb	w14, w13
     a94: f940058c     	ldr	x12, [x12, #0x8]
     a98: aa1f01cf     	orr	x15, x14, xzr
     a9c: 910043f0     	add	x16, sp, #0x10
     aa0: f900020d     	str	x13, [x16]
     aa4: 910043f0     	add	x16, sp, #0x10
     aa8: f900060c     	str	x12, [x16, #0x8]
     aac: f9403c0c     	ldr	x12, [x0, #0x78]
     ab0: b867798c     	ldr	w12, [x12, x7, lsl #2]
     ab4: f1020dff     	cmp	x15, #0x83
     ab8: 540038aa     	b.ge	0x11cc <_stogir.verify.integer-operations-target-structured+0x838>
     abc: 90000010     	adrp	x16, 0x0 <_gap_verify_graph>
     ac0: f9400210     	ldr	x16, [x16]
     ac4: 786f7a0d     	ldrh	w13, [x16, x15, lsl #1]
     ac8: f10039ff     	cmp	x15, #0xe
     acc: 5400704b     	b.lt	0x18d4 <_stogir.verify.integer-operations-target-structured+0xf40>
     ad0: f90103e0     	str	x0, [sp, #0x200]
     ad4: f1005dff     	cmp	x15, #0x17
     ad8: 1a9fc7e0     	cset	w0, le
     adc: d3401c00     	ubfx	x0, x0, #0, #8
     ae0: f90107e0     	str	x0, [sp, #0x208]
     ae4: 2a1f00e0     	orr	w0, w7, wzr
     ae8: f9010be1     	str	x1, [sp, #0x210]
     aec: 121e01a1     	and	w1, w13, #0x4
     af0: d3407c21     	ubfx	x1, x1, #0, #32
     af4: f9011be8     	str	x8, [sp, #0x230]
     af8: f90147e2     	str	x2, [sp, #0x288]
     afc: 910043e2     	add	x2, sp, #0x10
     b00: f9013fe3     	str	x3, [sp, #0x278]
     b04: 2a0c03e3     	mov	w3, w12
     b08: f90137e4     	str	x4, [sp, #0x268]
     b0c: f90133e5     	str	x5, [sp, #0x260]
     b10: f9012fe6     	str	x6, [sp, #0x258]
     b14: f9012be7     	str	x7, [sp, #0x250]
     b18: b90273ee     	str	w14, [sp, #0x270]
     b1c: b90283ec     	str	w12, [sp, #0x280]
     b20: b90293e0     	str	w0, [sp, #0x290]
     b24: b9021bf3     	str	w19, [sp, #0x218]
     b28: 2a0d03f3     	mov	w19, w13
     b2c: b90223f4     	str	w20, [sp, #0x220]
     b30: aa0903f4     	mov	x20, x9
     b34: b9022bf5     	str	w21, [sp, #0x228]
     b38: aa0103f5     	mov	x21, x1
     b3c: 2a0003e1     	mov	w1, w0
     b40: f94103e0     	ldr	x0, [sp, #0x200]
     b44: f9011ff8     	str	x24, [sp, #0x238]
     b48: aa0f03f8     	mov	x24, x15
     b4c: f90123f7     	str	x23, [sp, #0x240]
     b50: aa0b03f7     	mov	x23, x11
     b54: f90127f6     	str	x22, [sp, #0x248]
     b58: aa0a03f6     	mov	x22, x10
     b5c: 94000000     	bl	0xb5c <_stogir.verify.integer-operations-target-structured+0x1c8>
     b60: 53001c01     	uxtb	w1, w0
     b64: f10002bf     	cmp	x21, #0x0
     b68: 540033a1     	b.ne	0x11dc <_stogir.verify.integer-operations-target-structured+0x848>
     b6c: f100003f     	cmp	x1, #0x0
     b70: 54003361     	b.ne	0x11dc <_stogir.verify.integer-operations-target-structured+0x848>
     b74: f9014fe0     	str	x0, [sp, #0x298]
     b78: aa0103f5     	mov	x21, x1
     b7c: f101131f     	cmp	x24, #0x44
     b80: 540002e1     	b.ne	0xbdc <_stogir.verify.integer-operations-target-structured+0x248>
     b84: f10002bf     	cmp	x21, #0x0
     b88: 540002a1     	b.ne	0xbdc <_stogir.verify.integer-operations-target-structured+0x248>
     b8c: 910103e8     	add	x8, sp, #0x40
     b90: f94103e0     	ldr	x0, [sp, #0x200]
     b94: b94293e1     	ldr	w1, [sp, #0x290]
     b98: 94000000     	bl	0xb98 <_stogir.verify.integer-operations-target-structured+0x204>
     b9c: 910103f0     	add	x16, sp, #0x40
     ba0: b9400200     	ldr	w0, [x16]
     ba4: d340fc10     	lsr	x16, x0, #0
     ba8: f100061f     	cmp	x16, #0x1
     bac: 540000e0     	b.eq	0xbc8 <_stogir.verify.integer-operations-target-structured+0x234>
     bb0: 54000043     	b.lo	0xbb8 <_stogir.verify.integer-operations-target-structured+0x224>
     bb4: 14000006     	b	0xbcc <_stogir.verify.integer-operations-target-structured+0x238>
     bb8: f100021f     	cmp	x16, #0x0
     bbc: 54000040     	b.eq	0xbc4 <_stogir.verify.integer-operations-target-structured+0x230>
     bc0: 14000003     	b	0xbcc <_stogir.verify.integer-operations-target-structured+0x238>
     bc4: 140001a1     	b	0x1248 <_stogir.verify.integer-operations-target-structured+0x8b4>
     bc8: 14000002     	b	0xbd0 <_stogir.verify.integer-operations-target-structured+0x23c>
     bcc: 140001a2     	b	0x1254 <_stogir.verify.integer-operations-target-structured+0x8c0>
     bd0: 910103f0     	add	x16, sp, #0x40
     bd4: f9400616     	ldr	x22, [x16, #0x8]
     bd8: f9400757     	ldr	x23, [x26, #0x8]
     bdc: f100771f     	cmp	x24, #0x1d
     be0: 540033e0     	b.eq	0x125c <_stogir.verify.integer-operations-target-structured+0x8c8>
     be4: f1007b1f     	cmp	x24, #0x1e
     be8: 540033a0     	b.eq	0x125c <_stogir.verify.integer-operations-target-structured+0x8c8>
     bec: 121d0260     	and	w0, w19, #0x8
     bf0: d3407c00     	ubfx	x0, x0, #0, #32
     bf4: f100001f     	cmp	x0, #0x0
     bf8: 1a9f17e0     	cset	w0, eq
     bfc: 53001c10     	uxtb	w16, w0
     c00: 6b1f021f     	cmp	w16, wzr
     c04: 9a9f17e0     	cset	x0, eq
     c08: f100001f     	cmp	x0, #0x0
     c0c: 54003a81     	b.ne	0x135c <_stogir.verify.integer-operations-target-structured+0x9c8>
     c10: f100b31f     	cmp	x24, #0x2c
     c14: 54003a40     	b.eq	0x135c <_stogir.verify.integer-operations-target-structured+0x9c8>
     c18: 121c0260     	and	w0, w19, #0x10
     c1c: d3407c00     	ubfx	x0, x0, #0, #32
     c20: f100001f     	cmp	x0, #0x0
     c24: 1a9f17e0     	cset	w0, eq
     c28: 53001c10     	uxtb	w16, w0
     c2c: 6b1f021f     	cmp	w16, wzr
     c30: 9a9f17e0     	cset	x0, eq
     c34: f100001f     	cmp	x0, #0x0
     c38: 540002a0     	b.eq	0xc8c <_stogir.verify.integer-operations-target-structured+0x2f8>
     c3c: 910343e8     	add	x8, sp, #0xd0
     c40: f94103e0     	ldr	x0, [sp, #0x200]
     c44: b94293e1     	ldr	w1, [sp, #0x290]
     c48: 94000000     	bl	0xc48 <_stogir.verify.integer-operations-target-structured+0x2b4>
     c4c: 910343f0     	add	x16, sp, #0xd0
     c50: b9400200     	ldr	w0, [x16]
     c54: d340fc10     	lsr	x16, x0, #0
     c58: f100061f     	cmp	x16, #0x1
     c5c: 540000e0     	b.eq	0xc78 <_stogir.verify.integer-operations-target-structured+0x2e4>
     c60: 54000043     	b.lo	0xc68 <_stogir.verify.integer-operations-target-structured+0x2d4>
     c64: 14000006     	b	0xc7c <_stogir.verify.integer-operations-target-structured+0x2e8>
     c68: f100021f     	cmp	x16, #0x0
     c6c: 54000040     	b.eq	0xc74 <_stogir.verify.integer-operations-target-structured+0x2e0>
     c70: 14000003     	b	0xc7c <_stogir.verify.integer-operations-target-structured+0x2e8>
     c74: 140001e3     	b	0x1400 <_stogir.verify.integer-operations-target-structured+0xa6c>
     c78: 14000002     	b	0xc80 <_stogir.verify.integer-operations-target-structured+0x2ec>
     c7c: 140001e4     	b	0x140c <_stogir.verify.integer-operations-target-structured+0xa78>
     c80: 910343f0     	add	x16, sp, #0xd0
     c84: f9400616     	ldr	x22, [x16, #0x8]
     c88: f9400777     	ldr	x23, [x27, #0x8]
     c8c: 121b0260     	and	w0, w19, #0x20
     c90: d3407c00     	ubfx	x0, x0, #0, #32
     c94: f100001f     	cmp	x0, #0x0
     c98: 1a9f17e0     	cset	w0, eq
     c9c: 53001c10     	uxtb	w16, w0
     ca0: 6b1f021f     	cmp	w16, wzr
     ca4: 9a9f17e0     	cset	x0, eq
     ca8: f100001f     	cmp	x0, #0x0
     cac: 540002a0     	b.eq	0xd00 <_stogir.verify.integer-operations-target-structured+0x36c>
     cb0: 9103c3e8     	add	x8, sp, #0xf0
     cb4: f94103e0     	ldr	x0, [sp, #0x200]
     cb8: b94293e1     	ldr	w1, [sp, #0x290]
     cbc: 94000000     	bl	0xcbc <_stogir.verify.integer-operations-target-structured+0x328>
     cc0: 9103c3f0     	add	x16, sp, #0xf0
     cc4: b9400200     	ldr	w0, [x16]
     cc8: d340fc10     	lsr	x16, x0, #0
     ccc: f100061f     	cmp	x16, #0x1
     cd0: 540000e0     	b.eq	0xcec <_stogir.verify.integer-operations-target-structured+0x358>
     cd4: 54000043     	b.lo	0xcdc <_stogir.verify.integer-operations-target-structured+0x348>
     cd8: 14000006     	b	0xcf0 <_stogir.verify.integer-operations-target-structured+0x35c>
     cdc: f100021f     	cmp	x16, #0x0
     ce0: 54000040     	b.eq	0xce8 <_stogir.verify.integer-operations-target-structured+0x354>
     ce4: 14000003     	b	0xcf0 <_stogir.verify.integer-operations-target-structured+0x35c>
     ce8: 140001cb     	b	0x1414 <_stogir.verify.integer-operations-target-structured+0xa80>
     cec: 14000002     	b	0xcf4 <_stogir.verify.integer-operations-target-structured+0x360>
     cf0: 140001cc     	b	0x1420 <_stogir.verify.integer-operations-target-structured+0xa8c>
     cf4: 9103c3f0     	add	x16, sp, #0xf0
     cf8: f9400616     	ldr	x22, [x16, #0x8]
     cfc: f9400797     	ldr	x23, [x28, #0x8]
     d00: 121a0260     	and	w0, w19, #0x40
     d04: d3407c00     	ubfx	x0, x0, #0, #32
     d08: f100001f     	cmp	x0, #0x0
     d0c: 1a9f17e0     	cset	w0, eq
     d10: 53001c10     	uxtb	w16, w0
     d14: 6b1f021f     	cmp	w16, wzr
     d18: 9a9f17e0     	cset	x0, eq
     d1c: f100001f     	cmp	x0, #0x0
     d20: 54005de0     	b.eq	0x18dc <_stogir.verify.integer-operations-target-structured+0xf48>
     d24: 910443e8     	add	x8, sp, #0x110
     d28: f94103e0     	ldr	x0, [sp, #0x200]
     d2c: b94293e1     	ldr	w1, [sp, #0x290]
     d30: 94000000     	bl	0xd30 <_stogir.verify.integer-operations-target-structured+0x39c>
     d34: 910443f0     	add	x16, sp, #0x110
     d38: b9400200     	ldr	w0, [x16]
     d3c: d340fc10     	lsr	x16, x0, #0
     d40: f100061f     	cmp	x16, #0x1
     d44: 54000100     	b.eq	0xd64 <_stogir.verify.integer-operations-target-structured+0x3d0>
     d48: 54000043     	b.lo	0xd50 <_stogir.verify.integer-operations-target-structured+0x3bc>
     d4c: 14000007     	b	0xd68 <_stogir.verify.integer-operations-target-structured+0x3d4>
     d50: f100021f     	cmp	x16, #0x0
     d54: 54000040     	b.eq	0xd5c <_stogir.verify.integer-operations-target-structured+0x3c8>
     d58: 14000004     	b	0xd68 <_stogir.verify.integer-operations-target-structured+0x3d4>
     d5c: f9410be0     	ldr	x0, [sp, #0x210]
     d60: 140001b2     	b	0x1428 <_stogir.verify.integer-operations-target-structured+0xa94>
     d64: 14000002     	b	0xd6c <_stogir.verify.integer-operations-target-structured+0x3d8>
     d68: 140001b3     	b	0x1434 <_stogir.verify.integer-operations-target-structured+0xaa0>
     d6c: 910443f0     	add	x16, sp, #0x110
     d70: f9400616     	ldr	x22, [x16, #0x8]
     d74: f9410be0     	ldr	x0, [sp, #0x210]
     d78: f9400417     	ldr	x23, [x0, #0x8]
     d7c: 12190261     	and	w1, w19, #0x80
     d80: d3407c21     	ubfx	x1, x1, #0, #32
     d84: f100003f     	cmp	x1, #0x0
     d88: 1a9f17e1     	cset	w1, eq
     d8c: 53001c30     	uxtb	w16, w1
     d90: 6b1f021f     	cmp	w16, wzr
     d94: 9a9f17e1     	cset	x1, eq
     d98: f100003f     	cmp	x1, #0x0
     d9c: 54005a40     	b.eq	0x18e4 <_stogir.verify.integer-operations-target-structured+0xf50>
     da0: 9104c3e8     	add	x8, sp, #0x130
     da4: b94293e1     	ldr	w1, [sp, #0x290]
     da8: f9010be0     	str	x0, [sp, #0x210]
     dac: f94103e0     	ldr	x0, [sp, #0x200]
     db0: 94000000     	bl	0xdb0 <_stogir.verify.integer-operations-target-structured+0x41c>
     db4: 9104c3f0     	add	x16, sp, #0x130
     db8: b9400200     	ldr	w0, [x16]
     dbc: d340fc10     	lsr	x16, x0, #0
     dc0: f100061f     	cmp	x16, #0x1
     dc4: 54000100     	b.eq	0xde4 <_stogir.verify.integer-operations-target-structured+0x450>
     dc8: 54000043     	b.lo	0xdd0 <_stogir.verify.integer-operations-target-structured+0x43c>
     dcc: 14000007     	b	0xde8 <_stogir.verify.integer-operations-target-structured+0x454>
     dd0: f100021f     	cmp	x16, #0x0
     dd4: 54000040     	b.eq	0xddc <_stogir.verify.integer-operations-target-structured+0x448>
     dd8: 14000004     	b	0xde8 <_stogir.verify.integer-operations-target-structured+0x454>
     ddc: f94147e0     	ldr	x0, [sp, #0x288]
     de0: 14000197     	b	0x143c <_stogir.verify.integer-operations-target-structured+0xaa8>
     de4: 14000002     	b	0xdec <_stogir.verify.integer-operations-target-structured+0x458>
     de8: 14000198     	b	0x1448 <_stogir.verify.integer-operations-target-structured+0xab4>
     dec: 9104c3f0     	add	x16, sp, #0x130
     df0: f9400616     	ldr	x22, [x16, #0x8]
     df4: f94147e0     	ldr	x0, [sp, #0x288]
     df8: f9400417     	ldr	x23, [x0, #0x8]
     dfc: 12180261     	and	w1, w19, #0x100
     e00: d3407c21     	ubfx	x1, x1, #0, #32
     e04: f100003f     	cmp	x1, #0x0
     e08: 1a9f17e1     	cset	w1, eq
     e0c: 53001c30     	uxtb	w16, w1
     e10: 6b1f021f     	cmp	w16, wzr
     e14: 9a9f17e1     	cset	x1, eq
     e18: f100003f     	cmp	x1, #0x0
     e1c: 540056a0     	b.eq	0x18f0 <_stogir.verify.integer-operations-target-structured+0xf5c>
     e20: 910543e8     	add	x8, sp, #0x150
     e24: b94293e1     	ldr	w1, [sp, #0x290]
     e28: b94223e2     	ldr	w2, [sp, #0x220]
     e2c: f90147e0     	str	x0, [sp, #0x288]
     e30: f94103e0     	ldr	x0, [sp, #0x200]
     e34: 94000000     	bl	0xe34 <_stogir.verify.integer-operations-target-structured+0x4a0>
     e38: 910543f0     	add	x16, sp, #0x150
     e3c: b9400200     	ldr	w0, [x16]
     e40: d340fc10     	lsr	x16, x0, #0
     e44: f100061f     	cmp	x16, #0x1
     e48: 54000100     	b.eq	0xe68 <_stogir.verify.integer-operations-target-structured+0x4d4>
     e4c: 54000043     	b.lo	0xe54 <_stogir.verify.integer-operations-target-structured+0x4c0>
     e50: 14000007     	b	0xe6c <_stogir.verify.integer-operations-target-structured+0x4d8>
     e54: f100021f     	cmp	x16, #0x0
     e58: 54000040     	b.eq	0xe60 <_stogir.verify.integer-operations-target-structured+0x4cc>
     e5c: 14000004     	b	0xe6c <_stogir.verify.integer-operations-target-structured+0x4d8>
     e60: f9413fe0     	ldr	x0, [sp, #0x278]
     e64: 1400017b     	b	0x1450 <_stogir.verify.integer-operations-target-structured+0xabc>
     e68: 14000002     	b	0xe70 <_stogir.verify.integer-operations-target-structured+0x4dc>
     e6c: 1400017c     	b	0x145c <_stogir.verify.integer-operations-target-structured+0xac8>
     e70: 910543f0     	add	x16, sp, #0x150
     e74: f9400616     	ldr	x22, [x16, #0x8]
     e78: f9413fe0     	ldr	x0, [sp, #0x278]
     e7c: f9400417     	ldr	x23, [x0, #0x8]
     e80: 12170261     	and	w1, w19, #0x200
     e84: d3407c21     	ubfx	x1, x1, #0, #32
     e88: f100003f     	cmp	x1, #0x0
     e8c: 1a9f17e1     	cset	w1, eq
     e90: 53001c30     	uxtb	w16, w1
     e94: 6b1f021f     	cmp	w16, wzr
     e98: 9a9f17e1     	cset	x1, eq
     e9c: f100003f     	cmp	x1, #0x0
     ea0: 540052e0     	b.eq	0x18fc <_stogir.verify.integer-operations-target-structured+0xf68>
     ea4: 9105c3e8     	add	x8, sp, #0x170
     ea8: b94293e1     	ldr	w1, [sp, #0x290]
     eac: b9422be2     	ldr	w2, [sp, #0x228]
     eb0: f9013fe0     	str	x0, [sp, #0x278]
     eb4: f94103e0     	ldr	x0, [sp, #0x200]
     eb8: 94000000     	bl	0xeb8 <_stogir.verify.integer-operations-target-structured+0x524>
     ebc: 9105c3f0     	add	x16, sp, #0x170
     ec0: b9400200     	ldr	w0, [x16]
     ec4: d340fc10     	lsr	x16, x0, #0
     ec8: f100061f     	cmp	x16, #0x1
     ecc: 54000100     	b.eq	0xeec <_stogir.verify.integer-operations-target-structured+0x558>
     ed0: 54000043     	b.lo	0xed8 <_stogir.verify.integer-operations-target-structured+0x544>
     ed4: 14000007     	b	0xef0 <_stogir.verify.integer-operations-target-structured+0x55c>
     ed8: f100021f     	cmp	x16, #0x0
     edc: 54000040     	b.eq	0xee4 <_stogir.verify.integer-operations-target-structured+0x550>
     ee0: 14000004     	b	0xef0 <_stogir.verify.integer-operations-target-structured+0x55c>
     ee4: f94137e0     	ldr	x0, [sp, #0x268]
     ee8: 1400015f     	b	0x1464 <_stogir.verify.integer-operations-target-structured+0xad0>
     eec: 14000002     	b	0xef4 <_stogir.verify.integer-operations-target-structured+0x560>
     ef0: 14000160     	b	0x1470 <_stogir.verify.integer-operations-target-structured+0xadc>
     ef4: 9105c3f0     	add	x16, sp, #0x170
     ef8: f9400616     	ldr	x22, [x16, #0x8]
     efc: f94137e0     	ldr	x0, [sp, #0x268]
     f00: f9400417     	ldr	x23, [x0, #0x8]
     f04: f100f31f     	cmp	x24, #0x3c
     f08: 54005001     	b.ne	0x1908 <_stogir.verify.integer-operations-target-structured+0xf74>
     f0c: 910643e8     	add	x8, sp, #0x190
     f10: b94293e1     	ldr	w1, [sp, #0x290]
     f14: f90137e0     	str	x0, [sp, #0x268]
     f18: f94103e0     	ldr	x0, [sp, #0x200]
     f1c: 94000000     	bl	0xf1c <_stogir.verify.integer-operations-target-structured+0x588>
     f20: 910643f0     	add	x16, sp, #0x190
     f24: b9400200     	ldr	w0, [x16]
     f28: d340fc10     	lsr	x16, x0, #0
     f2c: f100061f     	cmp	x16, #0x1
     f30: 54000100     	b.eq	0xf50 <_stogir.verify.integer-operations-target-structured+0x5bc>
     f34: 54000043     	b.lo	0xf3c <_stogir.verify.integer-operations-target-structured+0x5a8>
     f38: 14000007     	b	0xf54 <_stogir.verify.integer-operations-target-structured+0x5c0>
     f3c: f100021f     	cmp	x16, #0x0
     f40: 54000040     	b.eq	0xf48 <_stogir.verify.integer-operations-target-structured+0x5b4>
     f44: 14000004     	b	0xf54 <_stogir.verify.integer-operations-target-structured+0x5c0>
     f48: f94133e0     	ldr	x0, [sp, #0x260]
     f4c: 1400014b     	b	0x1478 <_stogir.verify.integer-operations-target-structured+0xae4>
     f50: 14000002     	b	0xf58 <_stogir.verify.integer-operations-target-structured+0x5c4>
     f54: 1400014c     	b	0x1484 <_stogir.verify.integer-operations-target-structured+0xaf0>
     f58: 910643f0     	add	x16, sp, #0x190
     f5c: f9400616     	ldr	x22, [x16, #0x8]
     f60: f94133e0     	ldr	x0, [sp, #0x260]
     f64: f9400417     	ldr	x23, [x0, #0x8]
     f68: f101e31f     	cmp	x24, #0x78
     f6c: 54004d41     	b.ne	0x1914 <_stogir.verify.integer-operations-target-structured+0xf80>
     f70: 910043f0     	add	x16, sp, #0x10
     f74: b9400201     	ldr	w1, [x16]
     f78: d3483c21     	ubfx	x1, x1, #8, #8
     f7c: f100003f     	cmp	x1, #0x0
     f80: 54002861     	b.ne	0x148c <_stogir.verify.integer-operations-target-structured+0xaf8>
     f84: 910043f0     	add	x16, sp, #0x10
     f88: b9400a01     	ldr	w1, [x16, #0x8]
     f8c: 93407c21     	sxtw	x1, w1
     f90: f100003f     	cmp	x1, #0x0
     f94: 1a9f17e1     	cset	w1, eq
     f98: 53001c30     	uxtb	w16, w1
     f9c: 6b1f021f     	cmp	w16, wzr
     fa0: 9a9f17e1     	cset	x1, eq
     fa4: f100003f     	cmp	x1, #0x0
     fa8: 54000080     	b.eq	0xfb8 <_stogir.verify.integer-operations-target-structured+0x624>
     fac: 90000016     	adrp	x22, 0x0 <_gap_verify_graph>
     fb0: f94002d6     	ldr	x22, [x22]
     fb4: d28003f7     	mov	x23, #0x1f              ; =31
     fb8: f90133e0     	str	x0, [sp, #0x260]
     fbc: 91000680     	add	x0, x20, #0x1
     fc0: 93407c14     	sxtw	x20, w0
     fc4: f9414fe0     	ldr	x0, [sp, #0x298]
     fc8: 53003c00     	uxth	w0, w0
     fcc: 52800111     	mov	w17, #0x8               ; =8
     fd0: 53003c10     	uxth	w16, w0
     fd4: 53000e31     	ubfx	w17, w17, #0, #4
     fd8: 1ad12600     	lsr	w0, w16, w17
     fdc: 53003c00     	uxth	w0, w0
     fe0: 53001c00     	uxtb	w0, w0
     fe4: f100001f     	cmp	x0, #0x0
     fe8: 1a9f07e0     	cset	w0, ne
     fec: 53001c10     	uxtb	w16, w0
     ff0: 6b1f021f     	cmp	w16, wzr
     ff4: 54004940     	b.eq	0x191c <_stogir.verify.integer-operations-target-structured+0xf88>
     ff8: 910783e8     	add	x8, sp, #0x1e0
     ffc: b94293e1     	ldr	w1, [sp, #0x290]
    1000: f90153f9     	str	x25, [sp, #0x2a0]
    1004: 2a0003f9     	mov	w25, w0
    1008: f94103e0     	ldr	x0, [sp, #0x200]
    100c: 94000000     	bl	0x100c <_stogir.verify.integer-operations-target-structured+0x678>
    1010: 910783f0     	add	x16, sp, #0x1e0
    1014: b9400200     	ldr	w0, [x16]
    1018: d340fc10     	lsr	x16, x0, #0
    101c: f100061f     	cmp	x16, #0x1
    1020: 54000100     	b.eq	0x1040 <_stogir.verify.integer-operations-target-structured+0x6ac>
    1024: 54000043     	b.lo	0x102c <_stogir.verify.integer-operations-target-structured+0x698>
    1028: 14000007     	b	0x1044 <_stogir.verify.integer-operations-target-structured+0x6b0>
    102c: f100021f     	cmp	x16, #0x0
    1030: 54000040     	b.eq	0x1038 <_stogir.verify.integer-operations-target-structured+0x6a4>
    1034: 14000004     	b	0x1044 <_stogir.verify.integer-operations-target-structured+0x6b0>
    1038: f9412fe0     	ldr	x0, [sp, #0x258]
    103c: 1400013a     	b	0x1524 <_stogir.verify.integer-operations-target-structured+0xb90>
    1040: 14000002     	b	0x1048 <_stogir.verify.integer-operations-target-structured+0x6b4>
    1044: 1400013b     	b	0x1530 <_stogir.verify.integer-operations-target-structured+0xb9c>
    1048: 910783f0     	add	x16, sp, #0x1e0
    104c: f9400616     	ldr	x22, [x16, #0x8]
    1050: f9412fe0     	ldr	x0, [sp, #0x258]
    1054: f9400417     	ldr	x23, [x0, #0x8]
    1058: f10002bf     	cmp	x21, #0x0
    105c: 54004681     	b.ne	0x192c <_stogir.verify.integer-operations-target-structured+0xf98>
    1060: 53001f30     	uxtb	w16, w25
    1064: 6b1f021f     	cmp	w16, wzr
    1068: 9a9f17e1     	cset	x1, eq
    106c: f100003f     	cmp	x1, #0x0
    1070: 54004660     	b.eq	0x193c <_stogir.verify.integer-operations-target-structured+0xfa8>
    1074: 12000261     	and	w1, w19, #0x1
    1078: 121f0262     	and	w2, w19, #0x2
    107c: d3407c33     	ubfx	x19, x1, #0, #32
    1080: d3407c42     	ubfx	x2, x2, #0, #32
    1084: f94107f5     	ldr	x21, [sp, #0x208]
    1088: f10002bf     	cmp	x21, #0x0
    108c: 540000a1     	b.ne	0x10a0 <_stogir.verify.integer-operations-target-structured+0x70c>
    1090: f100027f     	cmp	x19, #0x0
    1094: 54000061     	b.ne	0x10a0 <_stogir.verify.integer-operations-target-structured+0x70c>
    1098: f100005f     	cmp	x2, #0x0
    109c: 54004580     	b.eq	0x194c <_stogir.verify.integer-operations-target-structured+0xfb8>
    10a0: 910043f0     	add	x16, sp, #0x10
    10a4: b9400601     	ldr	w1, [x16, #0x4]
    10a8: 93407c21     	sxtw	x1, w1
    10ac: d2e00010     	movz	x16, #0x0, lsl #48
    10b0: cb010203     	sub	x3, x16, x1
    10b4: d1000464     	sub	x4, x3, #0x1
    10b8: f100003f     	cmp	x1, #0x0
    10bc: 5400450d     	b.le	0x195c <_stogir.verify.integer-operations-target-structured+0xfc8>
    10c0: f94103f9     	ldr	x25, [sp, #0x200]
    10c4: f9400723     	ldr	x3, [x25, #0x8]
    10c8: eb03003f     	cmp	x1, x3
    10cc: 540044ea     	b.ge	0x1968 <_stogir.verify.integer-operations-target-structured+0xfd4>
    10d0: f94127e5     	ldr	x5, [sp, #0x248]
    10d4: f94004a3     	ldr	x3, [x5, #0x8]
    10d8: eb03003f     	cmp	x1, x3
    10dc: 540022ea     	b.ge	0x1538 <_stogir.verify.integer-operations-target-structured+0xba4>
    10e0: f9403f23     	ldr	x3, [x25, #0x78]
    10e4: b8617863     	ldr	w3, [x3, x1, lsl #2]
    10e8: 93407c63     	sxtw	x3, w3
    10ec: f100007f     	cmp	x3, #0x0
    10f0: 1a9fb7e3     	cset	w3, ge
    10f4: d3401c63     	ubfx	x3, x3, #0, #8
    10f8: f94123e6     	ldr	x6, [sp, #0x240]
    10fc: f9411fe8     	ldr	x8, [sp, #0x238]
    1100: f100007f     	cmp	x3, #0x0
    1104: 54002560     	b.eq	0x15b0 <_stogir.verify.integer-operations-target-structured+0xc1c>
    1108: f100003f     	cmp	x1, #0x0
    110c: 540024cd     	b.le	0x15a4 <_stogir.verify.integer-operations-target-structured+0xc10>
    1110: f9400323     	ldr	x3, [x25]
    1114: 8b011061     	add	x1, x3, x1, lsl #4
    1118: f100003f     	cmp	x1, #0x0
    111c: 540024e1     	b.ne	0x15b8 <_stogir.verify.integer-operations-target-structured+0xc24>
    1120: f90103f9     	str	x25, [sp, #0x200]
    1124: f90127e5     	str	x5, [sp, #0x248]
    1128: f90157fa     	str	x26, [sp, #0x2a8]
    112c: f9015bfb     	str	x27, [sp, #0x2b0]
    1130: f9012fe0     	str	x0, [sp, #0x258]
    1134: f90123e6     	str	x6, [sp, #0x240]
    1138: f9011fe8     	str	x8, [sp, #0x238]
    113c: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    1140: f94002d6     	ldr	x22, [x22]
    1144: d28002f7     	mov	x23, #0x17              ; =23
    1148: 91000680     	add	x0, x20, #0x1
    114c: 93407c14     	sxtw	x20, w0
    1150: b94283e0     	ldr	w0, [sp, #0x280]
    1154: 93407c00     	sxtw	x0, w0
    1158: 91001000     	add	x0, x0, #0x4
    115c: 937ffc10     	asr	x16, x0, #63
    1160: d37efe10     	lsr	x16, x16, #62
    1164: 8b100000     	add	x0, x0, x16
    1168: 9342fc00     	asr	x0, x0, #2
    116c: f9412be1     	ldr	x1, [sp, #0x250]
    1170: 8b010001     	add	x1, x0, x1
    1174: f9411be8     	ldr	x8, [sp, #0x230]
    1178: f94103e0     	ldr	x0, [sp, #0x200]
    117c: b9421bf3     	ldr	w19, [sp, #0x218]
    1180: f94153f9     	ldr	x25, [sp, #0x2a0]
    1184: f94157fa     	ldr	x26, [sp, #0x2a8]
    1188: f9415bfb     	ldr	x27, [sp, #0x2b0]
    118c: f94147e2     	ldr	x2, [sp, #0x288]
    1190: f9413fe3     	ldr	x3, [sp, #0x278]
    1194: b9422bf5     	ldr	w21, [sp, #0x228]
    1198: f94137e4     	ldr	x4, [sp, #0x268]
    119c: f94133e5     	ldr	x5, [sp, #0x260]
    11a0: f9412fe6     	ldr	x6, [sp, #0x258]
    11a4: f9411ff8     	ldr	x24, [sp, #0x238]
    11a8: aa0103e7     	mov	x7, x1
    11ac: f9410be1     	ldr	x1, [sp, #0x210]
    11b0: aa1403e9     	mov	x9, x20
    11b4: b94223f4     	ldr	w20, [sp, #0x220]
    11b8: aa1603ea     	mov	x10, x22
    11bc: f94127f6     	ldr	x22, [sp, #0x248]
    11c0: aa1703eb     	mov	x11, x23
    11c4: f94123f7     	ldr	x23, [sp, #0x240]
    11c8: 17fffe2a     	b	0xa70 <_stogir.verify.integer-operations-target-structured+0xdc>
    11cc: 52a0000d     	movz	w13, #0x0, lsl #16
    11d0: 17fffe3e     	b	0xac8 <_stogir.verify.integer-operations-target-structured+0x134>
    11d4: d2e00000     	movz	x0, #0x0, lsl #48
    11d8: 17fffe42     	b	0xae0 <_stogir.verify.integer-operations-target-structured+0x14c>
    11dc: 910083e8     	add	x8, sp, #0x20
    11e0: b9421be2     	ldr	w2, [sp, #0x218]
    11e4: f9014fe0     	str	x0, [sp, #0x298]
    11e8: f94103e0     	ldr	x0, [sp, #0x200]
    11ec: aa0103f5     	mov	x21, x1
    11f0: b94293e1     	ldr	w1, [sp, #0x290]
    11f4: 94000000     	bl	0x11f4 <_stogir.verify.integer-operations-target-structured+0x860>
    11f8: 910083f0     	add	x16, sp, #0x20
    11fc: b9400200     	ldr	w0, [x16]
    1200: d340fc10     	lsr	x16, x0, #0
    1204: f100061f     	cmp	x16, #0x1
    1208: 540000e0     	b.eq	0x1224 <_stogir.verify.integer-operations-target-structured+0x890>
    120c: 54000043     	b.lo	0x1214 <_stogir.verify.integer-operations-target-structured+0x880>
    1210: 14000006     	b	0x1228 <_stogir.verify.integer-operations-target-structured+0x894>
    1214: f100021f     	cmp	x16, #0x0
    1218: 54000040     	b.eq	0x1220 <_stogir.verify.integer-operations-target-structured+0x88c>
    121c: 14000003     	b	0x1228 <_stogir.verify.integer-operations-target-structured+0x894>
    1220: 14000007     	b	0x123c <_stogir.verify.integer-operations-target-structured+0x8a8>
    1224: 14000002     	b	0x122c <_stogir.verify.integer-operations-target-structured+0x898>
    1228: 14000186     	b	0x1840 <_stogir.verify.integer-operations-target-structured+0xeac>
    122c: 910083f0     	add	x16, sp, #0x20
    1230: f9400616     	ldr	x22, [x16, #0x8]
    1234: f9400737     	ldr	x23, [x25, #0x8]
    1238: 17fffe51     	b	0xb7c <_stogir.verify.integer-operations-target-structured+0x1e8>
    123c: 91000680     	add	x0, x20, #0x1
    1240: 93407c14     	sxtw	x20, w0
    1244: 17fffffd     	b	0x1238 <_stogir.verify.integer-operations-target-structured+0x8a4>
    1248: 91000680     	add	x0, x20, #0x1
    124c: 93407c14     	sxtw	x20, w0
    1250: 17fffe63     	b	0xbdc <_stogir.verify.integer-operations-target-structured+0x248>
    1254: d4200000     	brk	#0
    1258: 17ffffff     	b	0x1254 <_stogir.verify.integer-operations-target-structured+0x8c0>
    125c: 910043f0     	add	x16, sp, #0x10
    1260: b9400e00     	ldr	w0, [x16, #0xc]
    1264: 93407c00     	sxtw	x0, w0
    1268: f100001f     	cmp	x0, #0x0
    126c: 54ffcc00     	b.eq	0xbec <_stogir.verify.integer-operations-target-structured+0x258>
    1270: 910043f0     	add	x16, sp, #0x10
    1274: b9400e00     	ldr	w0, [x16, #0xc]
    1278: 910183e8     	add	x8, sp, #0x60
    127c: 2a0003e1     	mov	w1, w0
    1280: f94103e0     	ldr	x0, [sp, #0x200]
    1284: 94000000     	bl	0x1284 <_stogir.verify.integer-operations-target-structured+0x8f0>
    1288: 910183f0     	add	x16, sp, #0x60
    128c: b9400200     	ldr	w0, [x16]
    1290: d340fc10     	lsr	x16, x0, #0
    1294: f100061f     	cmp	x16, #0x1
    1298: 540000e0     	b.eq	0x12b4 <_stogir.verify.integer-operations-target-structured+0x920>
    129c: 54000043     	b.lo	0x12a4 <_stogir.verify.integer-operations-target-structured+0x910>
    12a0: 14000006     	b	0x12b8 <_stogir.verify.integer-operations-target-structured+0x924>
    12a4: f100021f     	cmp	x16, #0x0
    12a8: 54000040     	b.eq	0x12b0 <_stogir.verify.integer-operations-target-structured+0x91c>
    12ac: 14000003     	b	0x12b8 <_stogir.verify.integer-operations-target-structured+0x924>
    12b0: 14000003     	b	0x12bc <_stogir.verify.integer-operations-target-structured+0x928>
    12b4: 14000006     	b	0x12cc <_stogir.verify.integer-operations-target-structured+0x938>
    12b8: 14000027     	b	0x1354 <_stogir.verify.integer-operations-target-structured+0x9c0>
    12bc: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    12c0: f94002d6     	ldr	x22, [x22]
    12c4: d28002d7     	mov	x23, #0x16              ; =22
    12c8: 17fffe49     	b	0xbec <_stogir.verify.integer-operations-target-structured+0x258>
    12cc: 910183f0     	add	x16, sp, #0x60
    12d0: f9400600     	ldr	x0, [x16, #0x8]
    12d4: 910043f0     	add	x16, sp, #0x10
    12d8: b9400e01     	ldr	w1, [x16, #0xc]
    12dc: 93407c21     	sxtw	x1, w1
    12e0: f100003f     	cmp	x1, #0x0
    12e4: 540002cb     	b.lt	0x133c <_stogir.verify.integer-operations-target-structured+0x9a8>
    12e8: 53001c00     	uxtb	w0, w0
    12ec: f1020c1f     	cmp	x0, #0x83
    12f0: 540002ea     	b.ge	0x134c <_stogir.verify.integer-operations-target-structured+0x9b8>
    12f4: 90000011     	adrp	x17, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    12f8: f9400231     	ldr	x17, [x17]
    12fc: 38716801     	ldrb	w1, [x0, x17]
    1300: 53001c30     	uxtb	w16, w1
    1304: 121f0201     	and	w1, w16, #0x2
    1308: 53001c21     	uxtb	w1, w1
    130c: d3401c21     	ubfx	x1, x1, #0, #8
    1310: f100003f     	cmp	x1, #0x0
    1314: 1a9f17e1     	cset	w1, eq
    1318: 53001c30     	uxtb	w16, w1
    131c: 6b1f021f     	cmp	w16, wzr
    1320: 9a9f17e1     	cset	x1, eq
    1324: f100003f     	cmp	x1, #0x0
    1328: 54000101     	b.ne	0x1348 <_stogir.verify.integer-operations-target-structured+0x9b4>
    132c: f101941f     	cmp	x0, #0x65
    1330: 540000c0     	b.eq	0x1348 <_stogir.verify.integer-operations-target-structured+0x9b4>
    1334: f101981f     	cmp	x0, #0x66
    1338: 54000080     	b.eq	0x1348 <_stogir.verify.integer-operations-target-structured+0x9b4>
    133c: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    1340: f94002d6     	ldr	x22, [x22]
    1344: d28005b7     	mov	x23, #0x2d              ; =45
    1348: 17ffffe0     	b	0x12c8 <_stogir.verify.integer-operations-target-structured+0x934>
    134c: 52a00001     	movz	w1, #0x0, lsl #16
    1350: 17ffffec     	b	0x1300 <_stogir.verify.integer-operations-target-structured+0x96c>
    1354: d4200000     	brk	#0
    1358: 17ffffff     	b	0x1354 <_stogir.verify.integer-operations-target-structured+0x9c0>
    135c: f100b31f     	cmp	x24, #0x2c
    1360: 54000341     	b.ne	0x13c8 <_stogir.verify.integer-operations-target-structured+0xa34>
    1364: 910243e8     	add	x8, sp, #0x90
    1368: f94103e0     	ldr	x0, [sp, #0x200]
    136c: b94293e1     	ldr	w1, [sp, #0x290]
    1370: 94000000     	bl	0x1370 <_stogir.verify.integer-operations-target-structured+0x9dc>
    1374: 910243f0     	add	x16, sp, #0x90
    1378: f9400200     	ldr	x0, [x16]
    137c: 910243f0     	add	x16, sp, #0x90
    1380: f9400601     	ldr	x1, [x16, #0x8]
    1384: 910243f0     	add	x16, sp, #0x90
    1388: f9400a02     	ldr	x2, [x16, #0x10]
    138c: d3407c00     	ubfx	x0, x0, #0, #32
    1390: d340fc10     	lsr	x16, x0, #0
    1394: f100061f     	cmp	x16, #0x1
    1398: 540000e0     	b.eq	0x13b4 <_stogir.verify.integer-operations-target-structured+0xa20>
    139c: 54000043     	b.lo	0x13a4 <_stogir.verify.integer-operations-target-structured+0xa10>
    13a0: 14000006     	b	0x13b8 <_stogir.verify.integer-operations-target-structured+0xa24>
    13a4: f100021f     	cmp	x16, #0x0
    13a8: 54000040     	b.eq	0x13b0 <_stogir.verify.integer-operations-target-structured+0xa1c>
    13ac: 14000003     	b	0x13b8 <_stogir.verify.integer-operations-target-structured+0xa24>
    13b0: 14000011     	b	0x13f4 <_stogir.verify.integer-operations-target-structured+0xa60>
    13b4: 14000002     	b	0x13bc <_stogir.verify.integer-operations-target-structured+0xa28>
    13b8: 14000120     	b	0x1838 <_stogir.verify.integer-operations-target-structured+0xea4>
    13bc: aa0103f6     	mov	x22, x1
    13c0: aa0203f7     	mov	x23, x2
    13c4: 17fffe15     	b	0xc18 <_stogir.verify.integer-operations-target-structured+0x284>
    13c8: 9102c3e8     	add	x8, sp, #0xb0
    13cc: f94103e0     	ldr	x0, [sp, #0x200]
    13d0: b94293e1     	ldr	w1, [sp, #0x290]
    13d4: 94000000     	bl	0x13d4 <_stogir.verify.integer-operations-target-structured+0xa40>
    13d8: 9102c3f0     	add	x16, sp, #0xb0
    13dc: f9400200     	ldr	x0, [x16]
    13e0: 9102c3f0     	add	x16, sp, #0xb0
    13e4: f9400601     	ldr	x1, [x16, #0x8]
    13e8: 9102c3f0     	add	x16, sp, #0xb0
    13ec: f9400a02     	ldr	x2, [x16, #0x10]
    13f0: 17ffffe7     	b	0x138c <_stogir.verify.integer-operations-target-structured+0x9f8>
    13f4: 91000680     	add	x0, x20, #0x1
    13f8: 93407c14     	sxtw	x20, w0
    13fc: 17fffff2     	b	0x13c4 <_stogir.verify.integer-operations-target-structured+0xa30>
    1400: 91000680     	add	x0, x20, #0x1
    1404: 93407c14     	sxtw	x20, w0
    1408: 17fffe21     	b	0xc8c <_stogir.verify.integer-operations-target-structured+0x2f8>
    140c: d4200000     	brk	#0
    1410: 17ffffff     	b	0x140c <_stogir.verify.integer-operations-target-structured+0xa78>
    1414: 91000680     	add	x0, x20, #0x1
    1418: 93407c14     	sxtw	x20, w0
    141c: 17fffe39     	b	0xd00 <_stogir.verify.integer-operations-target-structured+0x36c>
    1420: d4200000     	brk	#0
    1424: 17ffffff     	b	0x1420 <_stogir.verify.integer-operations-target-structured+0xa8c>
    1428: 91000681     	add	x1, x20, #0x1
    142c: 93407c34     	sxtw	x20, w1
    1430: 17fffe53     	b	0xd7c <_stogir.verify.integer-operations-target-structured+0x3e8>
    1434: d4200000     	brk	#0
    1438: 17ffffff     	b	0x1434 <_stogir.verify.integer-operations-target-structured+0xaa0>
    143c: 91000681     	add	x1, x20, #0x1
    1440: 93407c34     	sxtw	x20, w1
    1444: 17fffe6e     	b	0xdfc <_stogir.verify.integer-operations-target-structured+0x468>
    1448: d4200000     	brk	#0
    144c: 17ffffff     	b	0x1448 <_stogir.verify.integer-operations-target-structured+0xab4>
    1450: 91000681     	add	x1, x20, #0x1
    1454: 93407c34     	sxtw	x20, w1
    1458: 17fffe8a     	b	0xe80 <_stogir.verify.integer-operations-target-structured+0x4ec>
    145c: d4200000     	brk	#0
    1460: 17ffffff     	b	0x145c <_stogir.verify.integer-operations-target-structured+0xac8>
    1464: 91000681     	add	x1, x20, #0x1
    1468: 93407c34     	sxtw	x20, w1
    146c: 17fffea6     	b	0xf04 <_stogir.verify.integer-operations-target-structured+0x570>
    1470: d4200000     	brk	#0
    1474: 17ffffff     	b	0x1470 <_stogir.verify.integer-operations-target-structured+0xadc>
    1478: 91000681     	add	x1, x20, #0x1
    147c: 93407c34     	sxtw	x20, w1
    1480: 17fffeba     	b	0xf68 <_stogir.verify.integer-operations-target-structured+0x5d4>
    1484: d4200000     	brk	#0
    1488: 17ffffff     	b	0x1484 <_stogir.verify.integer-operations-target-structured+0xaf0>
    148c: 910043f0     	add	x16, sp, #0x10
    1490: b9400a01     	ldr	w1, [x16, #0x8]
    1494: 9106c3e8     	add	x8, sp, #0x1b0
    1498: f90133e0     	str	x0, [sp, #0x260]
    149c: f94103e0     	ldr	x0, [sp, #0x200]
    14a0: 94000000     	bl	0x14a0 <_stogir.verify.integer-operations-target-structured+0xb0c>
    14a4: 9106c3f0     	add	x16, sp, #0x1b0
    14a8: b9400200     	ldr	w0, [x16]
    14ac: d340fc10     	lsr	x16, x0, #0
    14b0: f100061f     	cmp	x16, #0x1
    14b4: 540000e0     	b.eq	0x14d0 <_stogir.verify.integer-operations-target-structured+0xb3c>
    14b8: 54000043     	b.lo	0x14c0 <_stogir.verify.integer-operations-target-structured+0xb2c>
    14bc: 14000006     	b	0x14d4 <_stogir.verify.integer-operations-target-structured+0xb40>
    14c0: f100021f     	cmp	x16, #0x0
    14c4: 54000040     	b.eq	0x14cc <_stogir.verify.integer-operations-target-structured+0xb38>
    14c8: 14000003     	b	0x14d4 <_stogir.verify.integer-operations-target-structured+0xb40>
    14cc: 14000003     	b	0x14d8 <_stogir.verify.integer-operations-target-structured+0xb44>
    14d0: 14000006     	b	0x14e8 <_stogir.verify.integer-operations-target-structured+0xb54>
    14d4: 14000012     	b	0x151c <_stogir.verify.integer-operations-target-structured+0xb88>
    14d8: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    14dc: f94002d6     	ldr	x22, [x22]
    14e0: d2800297     	mov	x23, #0x14              ; =20
    14e4: 17fffeb6     	b	0xfbc <_stogir.verify.integer-operations-target-structured+0x628>
    14e8: 9106c3f0     	add	x16, sp, #0x1b0
    14ec: f9400600     	ldr	x0, [x16, #0x8]
    14f0: 910043f0     	add	x16, sp, #0x10
    14f4: b9400201     	ldr	w1, [x16]
    14f8: d3407c00     	ubfx	x0, x0, #0, #32
    14fc: d3483c21     	ubfx	x1, x1, #8, #8
    1500: d3483c00     	ubfx	x0, x0, #8, #8
    1504: eb01001f     	cmp	x0, x1
    1508: 54000080     	b.eq	0x1518 <_stogir.verify.integer-operations-target-structured+0xb84>
    150c: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    1510: f94002d6     	ldr	x22, [x22]
    1514: d2800357     	mov	x23, #0x1a              ; =26
    1518: 17fffff3     	b	0x14e4 <_stogir.verify.integer-operations-target-structured+0xb50>
    151c: d4200000     	brk	#0
    1520: 17ffffff     	b	0x151c <_stogir.verify.integer-operations-target-structured+0xb88>
    1524: 91000681     	add	x1, x20, #0x1
    1528: 93407c34     	sxtw	x20, w1
    152c: 17fffecb     	b	0x1058 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1530: d4200000     	brk	#0
    1534: 17ffffff     	b	0x1530 <_stogir.verify.integer-operations-target-structured+0xb9c>
    1538: d2e00003     	movz	x3, #0x0, lsl #48
    153c: 17fffeef     	b	0x10f8 <_stogir.verify.integer-operations-target-structured+0x764>
    1540: d2e00003     	movz	x3, #0x0, lsl #48
    1544: 17fffeed     	b	0x10f8 <_stogir.verify.integer-operations-target-structured+0x764>
    1548: f100003f     	cmp	x1, #0x0
    154c: 5400212a     	b.ge	0x1970 <_stogir.verify.integer-operations-target-structured+0xfdc>
    1550: f94123e6     	ldr	x6, [sp, #0x240]
    1554: f94004c7     	ldr	x7, [x6, #0x8]
    1558: f9411fe8     	ldr	x8, [sp, #0x238]
    155c: f9400509     	ldr	x9, [x8, #0x8]
    1560: eb0900ff     	cmp	x7, x9
    1564: 54000181     	b.ne	0x1594 <_stogir.verify.integer-operations-target-structured+0xc00>
    1568: eb07007f     	cmp	x3, x7
    156c: 5400010c     	b.gt	0x158c <_stogir.verify.integer-operations-target-structured+0xbf8>
    1570: f9402b23     	ldr	x3, [x25, #0x50]
    1574: b8647863     	ldr	w3, [x3, x4, lsl #2]
    1578: 93407c63     	sxtw	x3, w3
    157c: f100007f     	cmp	x3, #0x0
    1580: 1a9fd7e3     	cset	w3, gt
    1584: d3401c63     	ubfx	x3, x3, #0, #8
    1588: 17fffede     	b	0x1100 <_stogir.verify.integer-operations-target-structured+0x76c>
    158c: d2e00003     	movz	x3, #0x0, lsl #48
    1590: 17fffffe     	b	0x1588 <_stogir.verify.integer-operations-target-structured+0xbf4>
    1594: d2e00003     	movz	x3, #0x0, lsl #48
    1598: 17fffffc     	b	0x1588 <_stogir.verify.integer-operations-target-structured+0xbf4>
    159c: d2e00003     	movz	x3, #0x0, lsl #48
    15a0: 17fffffa     	b	0x1588 <_stogir.verify.integer-operations-target-structured+0xbf4>
    15a4: f9401721     	ldr	x1, [x25, #0x28]
    15a8: 8b041021     	add	x1, x1, x4, lsl #4
    15ac: 17fffedb     	b	0x1118 <_stogir.verify.integer-operations-target-structured+0x784>
    15b0: d2e00001     	movz	x1, #0x0, lsl #48
    15b4: 17fffed9     	b	0x1118 <_stogir.verify.integer-operations-target-structured+0x784>
    15b8: b9400021     	ldr	w1, [x1]
    15bc: 910043f0     	add	x16, sp, #0x10
    15c0: b9400203     	ldr	w3, [x16]
    15c4: d3483c21     	ubfx	x1, x1, #8, #8
    15c8: aa1f0024     	orr	x4, x1, xzr
    15cc: d3483c63     	ubfx	x3, x3, #8, #8
    15d0: f100187f     	cmp	x3, #0x6
    15d4: 540006a1     	b.ne	0x16a8 <_stogir.verify.integer-operations-target-structured+0xd14>
    15d8: f100189f     	cmp	x4, #0x6
    15dc: 54000621     	b.ne	0x16a0 <_stogir.verify.integer-operations-target-structured+0xd0c>
    15e0: f1006b1f     	cmp	x24, #0x1a
    15e4: 54000561     	b.ne	0x1690 <_stogir.verify.integer-operations-target-structured+0xcfc>
    15e8: d2800023     	mov	x3, #0x1                ; =1
    15ec: f1002c9f     	cmp	x4, #0xb
    15f0: 1a9fc7e7     	cset	w7, le
    15f4: f100049f     	cmp	x4, #0x1
    15f8: 540005cb     	b.lt	0x16b0 <_stogir.verify.integer-operations-target-structured+0xd1c>
    15fc: d3401ce9     	ubfx	x9, x7, #0, #8
    1600: f100013f     	cmp	x9, #0x0
    1604: 1a9f07e9     	cset	w9, ne
    1608: 53001d30     	uxtb	w16, w9
    160c: 6b1f021f     	cmp	w16, wzr
    1610: 9a9f17e9     	cset	x9, eq
    1614: f100013f     	cmp	x9, #0x0
    1618: 54000500     	b.eq	0x16b8 <_stogir.verify.integer-operations-target-structured+0xd24>
    161c: f90103f9     	str	x25, [sp, #0x200]
    1620: f90127e5     	str	x5, [sp, #0x248]
    1624: f90157fa     	str	x26, [sp, #0x2a8]
    1628: aa0303fa     	mov	x26, x3
    162c: f9015bfb     	str	x27, [sp, #0x2b0]
    1630: f9012fe0     	str	x0, [sp, #0x258]
    1634: aa0403f9     	mov	x25, x4
    1638: f90123e6     	str	x6, [sp, #0x240]
    163c: f9011fe8     	str	x8, [sp, #0x238]
    1640: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    1644: f94002d6     	ldr	x22, [x22]
    1648: d2800397     	mov	x23, #0x1c              ; =28
    164c: 910043f0     	add	x16, sp, #0x10
    1650: b9400200     	ldr	w0, [x16]
    1654: f10002bf     	cmp	x21, #0x0
    1658: 540009e0     	b.eq	0x1794 <_stogir.verify.integer-operations-target-structured+0xe00>
    165c: d2800021     	mov	x1, #0x1                ; =1
    1660: d3483c00     	ubfx	x0, x0, #8, #8
    1664: 93407c21     	sxtw	x1, w1
    1668: eb01001f     	cmp	x0, x1
    166c: 54000080     	b.eq	0x167c <_stogir.verify.integer-operations-target-structured+0xce8>
    1670: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    1674: f94002d6     	ldr	x22, [x22]
    1678: d28004d7     	mov	x23, #0x26              ; =38
    167c: f10002bf     	cmp	x21, #0x0
    1680: 540008e1     	b.ne	0x179c <_stogir.verify.integer-operations-target-structured+0xe08>
    1684: f100027f     	cmp	x19, #0x0
    1688: 540008a1     	b.ne	0x179c <_stogir.verify.integer-operations-target-structured+0xe08>
    168c: 17fffeaf     	b	0x1148 <_stogir.verify.integer-operations-target-structured+0x7b4>
    1690: f1006f1f     	cmp	x24, #0x1b
    1694: 1a9f17e3     	cset	w3, eq
    1698: d3401c63     	ubfx	x3, x3, #0, #8
    169c: 17ffffd4     	b	0x15ec <_stogir.verify.integer-operations-target-structured+0xc58>
    16a0: d2e00003     	movz	x3, #0x0, lsl #48
    16a4: 17ffffd2     	b	0x15ec <_stogir.verify.integer-operations-target-structured+0xc58>
    16a8: d2e00003     	movz	x3, #0x0, lsl #48
    16ac: 17ffffd0     	b	0x15ec <_stogir.verify.integer-operations-target-structured+0xc58>
    16b0: d2e00009     	movz	x9, #0x0, lsl #48
    16b4: 17ffffd3     	b	0x1600 <_stogir.verify.integer-operations-target-structured+0xc6c>
    16b8: f100005f     	cmp	x2, #0x0
    16bc: 1a9f17e2     	cset	w2, eq
    16c0: 53001c50     	uxtb	w16, w2
    16c4: 6b1f021f     	cmp	w16, wzr
    16c8: 9a9f17e2     	cset	x2, eq
    16cc: f100005f     	cmp	x2, #0x0
    16d0: 54001560     	b.eq	0x197c <_stogir.verify.integer-operations-target-structured+0xfe8>
    16d4: b94273ed     	ldr	w13, [sp, #0x270]
    16d8: f9012fe0     	str	x0, [sp, #0x258]
    16dc: 2a0d03e0     	mov	w0, w13
    16e0: f90127e5     	str	x5, [sp, #0x248]
    16e4: f90123e6     	str	x6, [sp, #0x240]
    16e8: f9011fe8     	str	x8, [sp, #0x238]
    16ec: f90103f9     	str	x25, [sp, #0x200]
    16f0: aa0403f9     	mov	x25, x4
    16f4: f90157fa     	str	x26, [sp, #0x2a8]
    16f8: aa0303fa     	mov	x26, x3
    16fc: f9015bfb     	str	x27, [sp, #0x2b0]
    1700: 2a0703fb     	mov	w27, w7
    1704: 94000000     	bl	0x1704 <_stogir.verify.integer-operations-target-structured+0xd70>
    1708: f100001f     	cmp	x0, #0x0
    170c: 54fff9a0     	b.eq	0x1640 <_stogir.verify.integer-operations-target-structured+0xcac>
    1710: f100027f     	cmp	x19, #0x0
    1714: 54fff9c0     	b.eq	0x164c <_stogir.verify.integer-operations-target-structured+0xcb8>
    1718: f1006b1f     	cmp	x24, #0x1a
    171c: 540002ab     	b.lt	0x1770 <_stogir.verify.integer-operations-target-structured+0xddc>
    1720: f1007b1f     	cmp	x24, #0x1e
    1724: 5400026c     	b.gt	0x1770 <_stogir.verify.integer-operations-target-structured+0xddc>
    1728: f100073f     	cmp	x25, #0x1
    172c: 54fff8ab     	b.lt	0x1640 <_stogir.verify.integer-operations-target-structured+0xcac>
    1730: 53001f70     	uxtb	w16, w27
    1734: 6b1f021f     	cmp	w16, wzr
    1738: 54fff840     	b.eq	0x1640 <_stogir.verify.integer-operations-target-structured+0xcac>
    173c: f100073f     	cmp	x25, #0x1
    1740: 54fff861     	b.ne	0x164c <_stogir.verify.integer-operations-target-structured+0xcb8>
    1744: f100bb1f     	cmp	x24, #0x2e
    1748: 54fff820     	b.eq	0x164c <_stogir.verify.integer-operations-target-structured+0xcb8>
    174c: f100bf1f     	cmp	x24, #0x2f
    1750: 54fff7e0     	b.eq	0x164c <_stogir.verify.integer-operations-target-structured+0xcb8>
    1754: f100c31f     	cmp	x24, #0x30
    1758: 54fff7a0     	b.eq	0x164c <_stogir.verify.integer-operations-target-structured+0xcb8>
    175c: f100eb1f     	cmp	x24, #0x3a
    1760: 54fff760     	b.eq	0x164c <_stogir.verify.integer-operations-target-structured+0xcb8>
    1764: f100ef1f     	cmp	x24, #0x3b
    1768: 54fff6c1     	b.ne	0x1640 <_stogir.verify.integer-operations-target-structured+0xcac>
    176c: 17ffffb8     	b	0x164c <_stogir.verify.integer-operations-target-structured+0xcb8>
    1770: f100bb1f     	cmp	x24, #0x2e
    1774: 5400006b     	b.lt	0x1780 <_stogir.verify.integer-operations-target-structured+0xdec>
    1778: f100d71f     	cmp	x24, #0x35
    177c: 54fffd6d     	b.le	0x1728 <_stogir.verify.integer-operations-target-structured+0xd94>
    1780: f100eb1f     	cmp	x24, #0x3a
    1784: 54fffd20     	b.eq	0x1728 <_stogir.verify.integer-operations-target-structured+0xd94>
    1788: f100ef1f     	cmp	x24, #0x3b
    178c: 54fffce0     	b.eq	0x1728 <_stogir.verify.integer-operations-target-structured+0xd94>
    1790: 17ffffac     	b	0x1640 <_stogir.verify.integer-operations-target-structured+0xcac>
    1794: aa1903e1     	mov	x1, x25
    1798: 17ffffb2     	b	0x1660 <_stogir.verify.integer-operations-target-structured+0xccc>
    179c: 910043f0     	add	x16, sp, #0x10
    17a0: b9400a00     	ldr	w0, [x16, #0x8]
    17a4: 2a0003e1     	mov	w1, w0
    17a8: f94103e0     	ldr	x0, [sp, #0x200]
    17ac: 94000000     	bl	0x17ac <_stogir.verify.integer-operations-target-structured+0xe18>
    17b0: f100001f     	cmp	x0, #0x0
    17b4: 540000a1     	b.ne	0x17c8 <_stogir.verify.integer-operations-target-structured+0xe34>
    17b8: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    17bc: f94002d6     	ldr	x22, [x22]
    17c0: d28003b7     	mov	x23, #0x1d              ; =29
    17c4: 17ffffb2     	b	0x168c <_stogir.verify.integer-operations-target-structured+0xcf8>
    17c8: b9400000     	ldr	w0, [x0]
    17cc: d3483c00     	ubfx	x0, x0, #8, #8
    17d0: eb00033f     	cmp	x25, x0
    17d4: 540001a1     	b.ne	0x1808 <_stogir.verify.integer-operations-target-structured+0xe74>
    17d8: d2800020     	mov	x0, #0x1                ; =1
    17dc: f100001f     	cmp	x0, #0x0
    17e0: 1a9f07e0     	cset	w0, ne
    17e4: 53001c10     	uxtb	w16, w0
    17e8: 6b1f021f     	cmp	w16, wzr
    17ec: 9a9f17e0     	cset	x0, eq
    17f0: f100001f     	cmp	x0, #0x0
    17f4: 54000080     	b.eq	0x1804 <_stogir.verify.integer-operations-target-structured+0xe70>
    17f8: 90000016     	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x66c>
    17fc: f94002d6     	ldr	x22, [x22]
    1800: d28003b7     	mov	x23, #0x1d              ; =29
    1804: 17fffff0     	b	0x17c4 <_stogir.verify.integer-operations-target-structured+0xe30>
    1808: f100035f     	cmp	x26, #0x0
    180c: 54000120     	b.eq	0x1830 <_stogir.verify.integer-operations-target-structured+0xe9c>
    1810: f100141f     	cmp	x0, #0x5
    1814: 54000061     	b.ne	0x1820 <_stogir.verify.integer-operations-target-structured+0xe8c>
    1818: d2800020     	mov	x0, #0x1                ; =1
    181c: 17fffff0     	b	0x17dc <_stogir.verify.integer-operations-target-structured+0xe48>
    1820: f1002c1f     	cmp	x0, #0xb
    1824: 1a9f17e0     	cset	w0, eq
    1828: d3401c00     	ubfx	x0, x0, #0, #8
    182c: 17fffffc     	b	0x181c <_stogir.verify.integer-operations-target-structured+0xe88>
    1830: d2e00000     	movz	x0, #0x0, lsl #48
    1834: 17fffffa     	b	0x181c <_stogir.verify.integer-operations-target-structured+0xe88>
    1838: d4200000     	brk	#0
    183c: 17ffffff     	b	0x1838 <_stogir.verify.integer-operations-target-structured+0xea4>
    1840: d4200000     	brk	#0
    1844: 17ffffff     	b	0x1840 <_stogir.verify.integer-operations-target-structured+0xeac>
    1848: f10002ff     	cmp	x23, #0x0
    184c: 540002c1     	b.ne	0x18a4 <_stogir.verify.integer-operations-target-structured+0xf10>
    1850: 92407e96     	and	x22, x20, #0xffffffff
    1854: d2e00000     	movz	x0, #0x0, lsl #48
    1858: d2e00017     	movz	x23, #0x0, lsl #48
    185c: f9411be1     	ldr	x1, [sp, #0x230]
    1860: f9000020     	str	x0, [x1]
    1864: f9000436     	str	x22, [x1, #0x8]
    1868: f9000837     	str	x23, [x1, #0x10]
    186c: f9415ff3     	ldr	x19, [sp, #0x2b8]
    1870: f94163f4     	ldr	x20, [sp, #0x2c0]
    1874: f94167f5     	ldr	x21, [sp, #0x2c8]
    1878: f9416bf6     	ldr	x22, [sp, #0x2d0]
    187c: f9416ff7     	ldr	x23, [sp, #0x2d8]
    1880: f94173f8     	ldr	x24, [sp, #0x2e0]
    1884: f94177f9     	ldr	x25, [sp, #0x2e8]
    1888: f9417bfa     	ldr	x26, [sp, #0x2f0]
    188c: f9417ffb     	ldr	x27, [sp, #0x2f8]
    1890: f94183fc     	ldr	x28, [sp, #0x300]
    1894: f94003fd     	ldr	x29, [sp]
    1898: f94007fe     	ldr	x30, [sp, #0x8]
    189c: 910c43ff     	add	sp, sp, #0x310
    18a0: d65f03c0     	ret
    18a4: d2800020     	mov	x0, #0x1                ; =1
    18a8: 17ffffed     	b	0x185c <_stogir.verify.integer-operations-target-structured+0xec8>
    18ac: aa0903f4     	mov	x20, x9
    18b0: f9011be8     	str	x8, [sp, #0x230]
    18b4: aa0a03f6     	mov	x22, x10
    18b8: aa0b03f7     	mov	x23, x11
    18bc: 17ffffe3     	b	0x1848 <_stogir.verify.integer-operations-target-structured+0xeb4>
    18c0: aa0903f4     	mov	x20, x9
    18c4: f9011be8     	str	x8, [sp, #0x230]
    18c8: aa0a03f6     	mov	x22, x10
    18cc: aa0b03f7     	mov	x23, x11
    18d0: 17ffffde     	b	0x1848 <_stogir.verify.integer-operations-target-structured+0xeb4>
    18d4: f90103e0     	str	x0, [sp, #0x200]
    18d8: 17fffe3f     	b	0x11d4 <_stogir.verify.integer-operations-target-structured+0x840>
    18dc: f9410be0     	ldr	x0, [sp, #0x210]
    18e0: 17fffd27     	b	0xd7c <_stogir.verify.integer-operations-target-structured+0x3e8>
    18e4: f9010be0     	str	x0, [sp, #0x210]
    18e8: f94147e0     	ldr	x0, [sp, #0x288]
    18ec: 17fffd44     	b	0xdfc <_stogir.verify.integer-operations-target-structured+0x468>
    18f0: f90147e0     	str	x0, [sp, #0x288]
    18f4: f9413fe0     	ldr	x0, [sp, #0x278]
    18f8: 17fffd62     	b	0xe80 <_stogir.verify.integer-operations-target-structured+0x4ec>
    18fc: f9013fe0     	str	x0, [sp, #0x278]
    1900: f94137e0     	ldr	x0, [sp, #0x268]
    1904: 17fffd80     	b	0xf04 <_stogir.verify.integer-operations-target-structured+0x570>
    1908: f90137e0     	str	x0, [sp, #0x268]
    190c: f94133e0     	ldr	x0, [sp, #0x260]
    1910: 17fffd96     	b	0xf68 <_stogir.verify.integer-operations-target-structured+0x5d4>
    1914: f90133e0     	str	x0, [sp, #0x260]
    1918: 17fffdab     	b	0xfc4 <_stogir.verify.integer-operations-target-structured+0x630>
    191c: f90153f9     	str	x25, [sp, #0x2a0]
    1920: 2a0003f9     	mov	w25, w0
    1924: f9412fe0     	ldr	x0, [sp, #0x258]
    1928: 17fffdcc     	b	0x1058 <_stogir.verify.integer-operations-target-structured+0x6c4>
    192c: f90157fa     	str	x26, [sp, #0x2a8]
    1930: f9015bfb     	str	x27, [sp, #0x2b0]
    1934: f9012fe0     	str	x0, [sp, #0x258]
    1938: 17fffe06     	b	0x1150 <_stogir.verify.integer-operations-target-structured+0x7bc>
    193c: f90157fa     	str	x26, [sp, #0x2a8]
    1940: f9015bfb     	str	x27, [sp, #0x2b0]
    1944: f9012fe0     	str	x0, [sp, #0x258]
    1948: 17fffe02     	b	0x1150 <_stogir.verify.integer-operations-target-structured+0x7bc>
    194c: f90157fa     	str	x26, [sp, #0x2a8]
    1950: f9015bfb     	str	x27, [sp, #0x2b0]
    1954: f9012fe0     	str	x0, [sp, #0x258]
    1958: 17fffdfe     	b	0x1150 <_stogir.verify.integer-operations-target-structured+0x7bc>
    195c: f94103f9     	ldr	x25, [sp, #0x200]
    1960: f94127e5     	ldr	x5, [sp, #0x248]
    1964: 17fffef9     	b	0x1548 <_stogir.verify.integer-operations-target-structured+0xbb4>
    1968: f94127e5     	ldr	x5, [sp, #0x248]
    196c: 17fffef5     	b	0x1540 <_stogir.verify.integer-operations-target-structured+0xbac>
    1970: f94123e6     	ldr	x6, [sp, #0x240]
    1974: f9411fe8     	ldr	x8, [sp, #0x238]
    1978: 17ffff09     	b	0x159c <_stogir.verify.integer-operations-target-structured+0xc08>
    197c: f90103f9     	str	x25, [sp, #0x200]
    1980: f90127e5     	str	x5, [sp, #0x248]
    1984: f90157fa     	str	x26, [sp, #0x2a8]
    1988: aa0303fa     	mov	x26, x3
    198c: f9015bfb     	str	x27, [sp, #0x2b0]
    1990: f9012fe0     	str	x0, [sp, #0x258]
    1994: aa0403f9     	mov	x25, x4
    1998: 2a0703fb     	mov	w27, w7
    199c: f90123e6     	str	x6, [sp, #0x240]
    19a0: f9011fe8     	str	x8, [sp, #0x238]
    19a4: 17ffff5b     	b	0x1710 <_stogir.verify.integer-operations-target-structured+0xd7c>

