
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-validator-dispatch/build/validator-verifier/word-trunc/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0x8c <_gap_verify_graph+0x8c>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x78 <_gap_verify_graph+0x78>
      60:      	add	x0, sp, #0x30
      64:      	mov	x1, x19
      68:      	mov	x2, #0x1a0              ; =416
      6c:      	bl	0x6c <_gap_verify_graph+0x6c>
		000000000000006c:  ARM64_RELOC_BRANCH26	_memmove
      70:      	add	x16, sp, #0x30
      74:      	ldr	x0, [x16, #0x8]
      78:      	ldr	x19, [sp, #0x1d0]
      7c:      	ldr	x29, [sp]
      80:      	ldr	x30, [sp, #0x8]
      84:      	add	sp, sp, #0x1e0
      88:      	ret
      8c:      	brk	#0
      90:      	b	0x8c <_gap_verify_graph+0x8c>

0000000000000094 <_stogir.verify.integer-operations-target>:
      94:      	sub	sp, sp, #0x70
      98:      	str	x29, [sp]
      9c:      	str	x30, [sp, #0x8]
      a0:      	mov	x29, sp
      a4:      	str	x19, [sp, #0x50]
      a8:      	str	x20, [sp, #0x58]
      ac:      	str	x21, [sp, #0x60]
      b0:      	mov	x19, x8
      b4:      	add	x8, sp, #0x10
      b8:      	mov	x20, x0
      bc:      	mov	w21, w1
      c0:      	bl	0xc0 <_stogir.verify.integer-operations-target+0x2c>
		00000000000000c0:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      c4:      	add	x16, sp, #0x10
      c8:      	ldr	w0, [x16]
      cc:      	lsr	x16, x0, #0
      d0:      	cmp	x16, #0x1
      d4:      	b.eq	0xf0 <_stogir.verify.integer-operations-target+0x5c>
      d8:      	b.lo	0xe0 <_stogir.verify.integer-operations-target+0x4c>
      dc:      	b	0xf4 <_stogir.verify.integer-operations-target+0x60>
      e0:      	cmp	x16, #0x0
      e4:      	b.eq	0xec <_stogir.verify.integer-operations-target+0x58>
      e8:      	b	0xf4 <_stogir.verify.integer-operations-target+0x60>
      ec:      	b	0x118 <_stogir.verify.integer-operations-target+0x84>
      f0:      	b	0xf8 <_stogir.verify.integer-operations-target+0x64>
      f4:      	b	0x168 <_stogir.verify.integer-operations-target+0xd4>
      f8:      	add	x16, sp, #0x10
      fc:      	orr	x0, x16, xzr
     100:      	add	x0, x0, #0x8
     104:      	add	x16, sp, #0x10
     108:      	ldr	x1, [x16, #0x8]
     10c:      	ldr	x0, [x0, #0x8]
     110:      	mov	x2, #0x1                ; =1
     114:      	b	0x140 <_stogir.verify.integer-operations-target+0xac>
     118:      	add	x8, sp, #0x30
     11c:      	mov	x0, x20
     120:      	mov	w1, w21
     124:      	bl	0x124 <_stogir.verify.integer-operations-target+0x90>
		0000000000000124:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     128:      	add	x16, sp, #0x30
     12c:      	ldr	x2, [x16]
     130:      	add	x16, sp, #0x30
     134:      	ldr	x1, [x16, #0x8]
     138:      	add	x16, sp, #0x30
     13c:      	ldr	x0, [x16, #0x10]
     140:      	str	x2, [x19]
     144:      	str	x1, [x19, #0x8]
     148:      	str	x0, [x19, #0x10]
     14c:      	ldr	x19, [sp, #0x50]
     150:      	ldr	x20, [sp, #0x58]
     154:      	ldr	x21, [sp, #0x60]
     158:      	ldr	x29, [sp]
     15c:      	ldr	x30, [sp, #0x8]
     160:      	add	sp, sp, #0x70
     164:      	ret
     168:      	brk	#0
     16c:      	b	0x168 <_stogir.verify.integer-operations-target+0xd4>

0000000000000170 <_stogir.verify.structure>:
     170:      	sub	sp, sp, #0x1a0
     174:      	str	x29, [sp, #0x10]
     178:      	str	x30, [sp, #0x18]
     17c:      	add	x29, sp, #0x10
     180:      	str	x19, [sp, #0x150]
     184:      	str	x20, [sp, #0x158]
     188:      	str	x21, [sp, #0x160]
     18c:      	str	x22, [sp, #0x168]
     190:      	str	x23, [sp, #0x170]
     194:      	str	x24, [sp, #0x178]
     198:      	str	x25, [sp, #0x180]
     19c:      	str	x26, [sp, #0x188]
     1a0:      	str	x27, [sp, #0x190]
     1a4:      	str	x28, [sp, #0x198]
     1a8:      	add	x1, x0, #0x78
     1ac:      	ldr	x2, [x0, #0x8]
     1b0:      	ldr	x1, [x1, #0x8]
     1b4:      	cmp	x2, x1
     1b8:      	b.ne	0x1ec <_stogir.verify.structure+0x7c>
     1bc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001bc:  ARM64_RELOC_PAGE21	l_stogir.311
     1c0:      	ldr	x16, [x16]
		00000000000001c0:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     1c4:      	orr	x19, x16, xzr
     1c8:      	movz	x20, #0x0, lsl #48
     1cc:      	b	0x1fc <_stogir.verify.structure+0x8c>
     1d0:      	ldr	x1, [sp, #0x120]
     1d4:      	ldr	x6, [sp, #0x128]
     1d8:      	add	x6, x1, x6
     1dc:      	ldr	x1, [sp, #0xc0]
     1e0:      	add	x1, x1, #0x1
     1e4:      	sxtw	x1, w1
     1e8:      	b	0x2c8 <_stogir.verify.structure+0x158>
     1ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001ec:  ARM64_RELOC_PAGE21	l_stogir.312
     1f0:      	ldr	x16, [x16]
		00000000000001f0:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     1f4:      	orr	x19, x16, xzr
     1f8:      	mov	x20, #0x2c              ; =44
     1fc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001fc:  ARM64_RELOC_PAGE21	l_stogir.313
     200:      	ldr	x16, [x16]
		0000000000000200:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     204:      	orr	x21, x16, xzr
     208:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000208:  ARM64_RELOC_PAGE21	l_stogir.314
     20c:      	ldr	x16, [x16]
		000000000000020c:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     210:      	orr	x22, x16, xzr
     214:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000214:  ARM64_RELOC_PAGE21	l_stogir.315
     218:      	ldr	x16, [x16]
		0000000000000218:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     21c:      	orr	x23, x16, xzr
     220:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000220:  ARM64_RELOC_PAGE21	l_stogir.316
     224:      	ldr	x16, [x16]
		0000000000000224:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     228:      	orr	x24, x16, xzr
     22c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000022c:  ARM64_RELOC_PAGE21	l_stogir.317
     230:      	ldr	x16, [x16]
		0000000000000230:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     234:      	orr	x25, x16, xzr
     238:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000238:  ARM64_RELOC_PAGE21	l_stogir.318
     23c:      	ldr	x16, [x16]
		000000000000023c:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     240:      	orr	x26, x16, xzr
     244:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000244:  ARM64_RELOC_PAGE21	l_stogir.319
     248:      	ldr	x16, [x16]
		0000000000000248:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     24c:      	orr	x27, x16, xzr
     250:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000250:  ARM64_RELOC_PAGE21	l_stogir.320
     254:      	ldr	x16, [x16]
		0000000000000254:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     258:      	orr	x28, x16, xzr
     25c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000025c:  ARM64_RELOC_PAGE21	l_stogir.321
     260:      	ldr	x16, [x16]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     264:      	orr	x1, x16, xzr
     268:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000268:  ARM64_RELOC_PAGE21	l_stogir.322
     26c:      	ldr	x16, [x16]
		000000000000026c:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     270:      	orr	x2, x16, xzr
     274:      	add	x3, x0, #0x110
     278:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000278:  ARM64_RELOC_PAGE21	l_stogir.323
     27c:      	ldr	x16, [x16]
		000000000000027c:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     280:      	orr	x4, x16, xzr
     284:      	add	x5, x0, #0x78
     288:      	add	x6, x0, #0x28
     28c:      	add	x7, x0, #0x50
     290:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000290:  ARM64_RELOC_PAGE21	l_stogir.323
     294:      	ldr	x16, [x16]
		0000000000000294:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     298:      	orr	x9, x16, xzr
     29c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000029c:  ARM64_RELOC_PAGE21	l_stogir.324
     2a0:      	ldr	x16, [x16]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     2a4:      	orr	x10, x16, xzr
     2a8:      	add	x11, x3, #0x28
     2ac:      	mov	x12, #0x1               ; =1
     2b0:      	movz	x13, #0x0, lsl #48
     2b4:      	b	0x390 <_stogir.verify.structure+0x220>
     2b8:      	ldr	x17, [sp, #0x58]
     2bc:      	str	x17, [sp, #0xa8]
     2c0:      	mov	x16, #0x16              ; =22
     2c4:      	str	x16, [sp, #0x118]
     2c8:      	b	0x334 <_stogir.verify.structure+0x1c4>
     2cc:      	nop
     2d0:      	str	x8, [sp, #0xa0]
     2d4:      	str	x21, [sp, #0x40]
     2d8:      	str	x22, [sp, #0x58]
     2dc:      	str	x23, [sp, #0x60]
     2e0:      	mov	x23, x0
     2e4:      	str	x24, [sp, #0x78]
     2e8:      	str	x25, [sp, #0x80]
     2ec:      	str	x26, [sp, #0x88]
     2f0:      	str	x27, [sp, #0x90]
     2f4:      	str	x28, [sp, #0x98]
     2f8:      	str	x1, [sp, #0x68]
     2fc:      	mov	x1, x13
     300:      	str	x2, [sp, #0x70]
     304:      	str	x4, [sp, #0x100]
     308:      	mov	x0, x11
     30c:      	mov	x2, x5
     310:      	mov	x4, x6
     314:      	mov	x6, x12
     318:      	mov	x5, x7
     31c:      	str	x9, [sp, #0xe8]
     320:      	str	x10, [sp, #0xf8]
     324:      	ldr	x17, [sp, #0x40]
     328:      	str	x17, [sp, #0xa8]
     32c:      	mov	x16, #0x23              ; =35
     330:      	str	x16, [sp, #0x118]
     334:      	ldr	x8, [sp, #0xa0]
     338:      	ldr	x21, [sp, #0x40]
     33c:      	ldr	x22, [sp, #0x58]
     340:      	ldr	x24, [sp, #0x78]
     344:      	ldr	x25, [sp, #0x80]
     348:      	ldr	x26, [sp, #0x88]
     34c:      	ldr	x27, [sp, #0x90]
     350:      	ldr	x28, [sp, #0x98]
     354:      	mov	x11, x0
     358:      	mov	x0, x23
     35c:      	ldr	x23, [sp, #0x60]
     360:      	mov	x7, x5
     364:      	mov	x5, x2
     368:      	ldr	x2, [sp, #0x70]
     36c:      	ldr	x9, [sp, #0xe8]
     370:      	ldr	x10, [sp, #0xf8]
     374:      	mov	x12, x6
     378:      	mov	x6, x4
     37c:      	ldr	x4, [sp, #0x100]
     380:      	mov	x13, x1
     384:      	ldr	x1, [sp, #0x68]
     388:      	ldr	x19, [sp, #0xa8]
     38c:      	ldr	x20, [sp, #0x118]
     390:      	cmp	x20, #0x0
     394:      	b.ne	0xba8 <_stogir.verify.structure+0xa38>
     398:      	ldr	x14, [x0, #0x8]
     39c:      	cmp	x12, x14
     3a0:      	b.ge	0xbbc <_stogir.verify.structure+0xa4c>
     3a4:      	ldr	x14, [x0]
     3a8:      	add	x14, x14, x12, lsl #4
     3ac:      	ldr	x14, [x14]
     3b0:      	ldr	x15, [x0, #0x78]
     3b4:      	add	x15, x15, x12, lsl #2
     3b8:      	ldr	w15, [x15]
     3bc:      	sxtw	x15, w15
     3c0:      	cmp	x15, #0x0
     3c4:      	b.lt	0x2d0 <_stogir.verify.structure+0x160>
     3c8:      	mov	x17, #0xffff            ; =65535
     3cc:      	cmp	x15, x17
     3d0:      	b.gt	0xbd0 <_stogir.verify.structure+0xa60>
     3d4:      	str	x0, [sp, #0x30]
     3d8:      	uxtb	w0, w14
     3dc:      	str	w0, [sp, #0x38]
     3e0:      	str	x21, [sp, #0x40]
     3e4:      	cmp	x0, #0x83
     3e8:      	cset	w21, lt
     3ec:      	uxtb	w16, w21
     3f0:      	cmp	w16, wzr
     3f4:      	b.eq	0xc28 <_stogir.verify.structure+0xab8>
     3f8:      	ubfx	x14, x14, #0, #32
     3fc:      	str	x0, [sp, #0x48]
     400:      	ubfx	x0, x14, #8, #8
     404:      	str	w0, [sp, #0x50]
     408:      	str	x8, [sp, #0xa0]
     40c:      	str	x1, [sp, #0x68]
     410:      	str	x2, [sp, #0x70]
     414:      	str	x3, [sp, #0xd0]
     418:      	str	x5, [sp, #0xc8]
     41c:      	str	x6, [sp, #0xb8]
     420:      	str	x7, [sp, #0xb0]
     424:      	str	x9, [sp, #0xe8]
     428:      	str	x11, [sp, #0xd8]
     42c:      	str	x13, [sp, #0xc0]
     430:      	str	x22, [sp, #0x58]
     434:      	ldr	w22, [sp, #0x50]
     438:      	str	x23, [sp, #0x60]
     43c:      	ldr	x23, [sp, #0x30]
     440:      	str	x24, [sp, #0x78]
     444:      	ldr	w24, [sp, #0x38]
     448:      	str	x25, [sp, #0x80]
     44c:      	mov	x25, x4
     450:      	str	x26, [sp, #0x88]
     454:      	mov	x26, x15
     458:      	str	x27, [sp, #0x90]
     45c:      	mov	x27, x12
     460:      	str	x28, [sp, #0x98]
     464:      	ldr	x28, [sp, #0x48]
     468:      	str	x19, [sp, #0xa8]
     46c:      	mov	x19, x10
     470:      	str	w21, [sp, #0xe0]
     474:      	mov	x21, x14
     478:      	bl	0x478 <_stogir.verify.structure+0x308>
		0000000000000478:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     47c:      	cmp	x0, #0x0
     480:      	b.eq	0xc7c <_stogir.verify.structure+0xb0c>
     484:      	add	x0, x28, x19
     488:      	ldrsb	w0, [x0]
     48c:      	sxtb	x0, w0
     490:      	cmp	x0, #0x0
     494:      	b.lt	0x908 <_stogir.verify.structure+0x798>
     498:      	mov	w0, w24
     49c:      	bl	0x49c <_stogir.verify.structure+0x32c>
		000000000000049c:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4a0:      	sxtw	x0, w0
     4a4:      	cmp	x26, x0
     4a8:      	b.eq	0x908 <_stogir.verify.structure+0x798>
     4ac:      	ldr	x3, [sp, #0xd0]
     4b0:      	str	x25, [sp, #0x100]
     4b4:      	ldr	x0, [sp, #0xd8]
     4b8:      	ldr	x2, [sp, #0xc8]
     4bc:      	ldr	x4, [sp, #0xb8]
     4c0:      	ldr	x5, [sp, #0xb0]
     4c4:      	str	x19, [sp, #0xf8]
     4c8:      	mov	x6, x27
     4cc:      	ldr	x1, [sp, #0xc0]
     4d0:      	ldr	x17, [sp, #0x60]
     4d4:      	str	x17, [sp, #0xa8]
     4d8:      	mov	x16, #0x23              ; =35
     4dc:      	str	x16, [sp, #0x118]
     4e0:      	b	0x1e8 <_stogir.verify.structure+0x78>
     4e4:      	ldr	x0, [sp, #0x118]
     4e8:      	cmp	x0, #0x0
     4ec:      	b.ne	0xca4 <_stogir.verify.structure+0xb34>
     4f0:      	and	x1, x1, #0xffffffff
     4f4:      	movz	x2, #0x0, lsl #48
     4f8:      	movz	x0, #0x0, lsl #48
     4fc:      	b	0x504 <_stogir.verify.structure+0x394>
     500:      	mov	x2, #0x1                ; =1
     504:      	ldr	x3, [sp, #0xa0]
     508:      	str	x2, [x3]
     50c:      	str	x1, [x3, #0x8]
     510:      	str	x0, [x3, #0x10]
     514:      	ldr	x19, [sp, #0x150]
     518:      	ldr	x20, [sp, #0x158]
     51c:      	ldr	x21, [sp, #0x160]
     520:      	ldr	x22, [sp, #0x168]
     524:      	ldr	x23, [sp, #0x170]
     528:      	ldr	x24, [sp, #0x178]
     52c:      	ldr	x25, [sp, #0x180]
     530:      	ldr	x26, [sp, #0x188]
     534:      	ldr	x27, [sp, #0x190]
     538:      	ldr	x28, [sp, #0x198]
     53c:      	ldr	x29, [sp, #0x10]
     540:      	ldr	x30, [sp, #0x18]
     544:      	add	sp, sp, #0x1a0
     548:      	ret
     54c:      	mov	x11, x8
     550:      	lsl	x11, x11, #2
     554:      	ubfx	x11, x11, #0, #32
     558:      	lsr	x10, x10, x11
     55c:      	ubfx	x10, x10, #0, #32
     560:      	and	x10, x10, #0xf
     564:      	ubfx	x10, x10, #0, #32
     568:      	b	0x588 <_stogir.verify.structure+0x418>
     56c:      	movz	x1, #0x0, lsl #48
     570:      	cmp	x1, #0x0
     574:      	b.eq	0x9d8 <_stogir.verify.structure+0x868>
     578:      	ldr	w1, [sp, #0x148]
     57c:      	ldr	w6, [sp, #0x140]
     580:      	b	0x664 <_stogir.verify.structure+0x4f4>
     584:      	movz	x10, #0x0, lsl #48
     588:      	b	0x590 <_stogir.verify.structure+0x420>
     58c:      	movz	x10, #0x0, lsl #48
     590:      	add	x16, sp, #0x20
     594:      	str	x16, [sp]
     598:      	str	w0, [sp, #0xf0]
     59c:      	str	x2, [sp, #0xe8]
     5a0:      	mov	w2, w4
     5a4:      	str	x3, [sp, #0x130]
     5a8:      	str	x19, [sp, #0xf8]
     5ac:      	mov	x19, x1
     5b0:      	mov	w1, w0
     5b4:      	mov	x0, x23
     5b8:      	str	x25, [sp, #0x100]
     5bc:      	mov	x25, x10
     5c0:      	str	x26, [sp, #0x108]
     5c4:      	mov	x26, x5
     5c8:      	str	x28, [sp, #0x110]
     5cc:      	mov	w28, w6
     5d0:      	str	x20, [sp, #0x118]
     5d4:      	mov	w20, w7
     5d8:      	str	x21, [sp, #0x120]
     5dc:      	mov	x21, x8
     5e0:      	str	x27, [sp, #0x128]
     5e4:      	mov	w27, w9
     5e8:      	bl	0x5e8 <_stogir.verify.structure+0x478>
		00000000000005e8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     5ec:      	ldr	x16, [sp]
     5f0:      	str	x0, [x16]
     5f4:      	str	x1, [x16, #0x8]
     5f8:      	add	x16, sp, #0x20
     5fc:      	ldr	x0, [x16]
     600:      	add	x16, sp, #0x20
     604:      	ldr	x1, [x16, #0x8]
     608:      	ubfx	x0, x0, #0, #32
     60c:      	lsr	x16, x0, #0
     610:      	cmp	x16, #0x1
     614:      	b.eq	0x630 <_stogir.verify.structure+0x4c0>
     618:      	b.lo	0x620 <_stogir.verify.structure+0x4b0>
     61c:      	b	0x634 <_stogir.verify.structure+0x4c4>
     620:      	cmp	x16, #0x0
     624:      	b.eq	0x62c <_stogir.verify.structure+0x4bc>
     628:      	b	0x634 <_stogir.verify.structure+0x4c4>
     62c:      	b	0x638 <_stogir.verify.structure+0x4c8>
     630:      	b	0x734 <_stogir.verify.structure+0x5c4>
     634:      	b	0xb10 <_stogir.verify.structure+0x9a0>
     638:      	ldr	x3, [sp, #0xd0]
     63c:      	ldr	x0, [sp, #0xd8]
     640:      	ldr	x2, [sp, #0xc8]
     644:      	ldr	x4, [sp, #0xb8]
     648:      	ldr	x5, [sp, #0xb0]
     64c:      	mov	w1, w24
     650:      	mov	w6, w22
     654:      	ldr	x17, [sp, #0x90]
     658:      	str	x17, [sp, #0xa8]
     65c:      	mov	x16, #0x17              ; =23
     660:      	str	x16, [sp, #0x118]
     664:      	ldr	x7, [sp, #0x130]
     668:      	add	x7, x7, #0x1
     66c:      	sxtw	x7, w7
     670:      	ldr	x26, [sp, #0x108]
     674:      	ldr	x21, [sp, #0x120]
     678:      	str	x3, [sp, #0xd0]
     67c:      	str	w27, [sp, #0xe0]
     680:      	ldr	x27, [sp, #0x128]
     684:      	ldr	x25, [sp, #0x100]
     688:      	ldr	x28, [sp, #0x110]
     68c:      	str	x0, [sp, #0xd8]
     690:      	ldr	w0, [sp, #0xf0]
     694:      	str	x2, [sp, #0xc8]
     698:      	str	x4, [sp, #0xb8]
     69c:      	str	x5, [sp, #0xb0]
     6a0:      	mov	w24, w1
     6a4:      	mov	w22, w6
     6a8:      	ldr	x2, [sp, #0xe8]
     6ac:      	mov	x1, x19
     6b0:      	ldr	x19, [sp, #0xf8]
     6b4:      	mov	x3, x7
     6b8:      	ldr	x20, [sp, #0x118]
     6bc:      	cmp	x20, #0x0
     6c0:      	b.ne	0x6d4 <_stogir.verify.structure+0x564>
     6c4:      	cmp	x3, x26
     6c8:      	cset	w4, le
     6cc:      	ubfx	x4, x4, #0, #8
     6d0:      	b	0x6d8 <_stogir.verify.structure+0x568>
     6d4:      	movz	x4, #0x0, lsl #48
     6d8:      	cmp	x4, #0x0
     6dc:      	b.eq	0xcac <_stogir.verify.structure+0xb3c>
     6e0:      	orr	w4, w3, wzr
     6e4:      	sxtw	x5, w4
     6e8:      	cmp	x5, #0x0
     6ec:      	cset	w6, gt
     6f0:      	cmp	x5, #0x4
     6f4:      	cset	w7, gt
     6f8:      	sub	x8, x5, #0x1
     6fc:      	sxtw	x8, w8
     700:      	ldr	w9, [sp, #0xe0]
     704:      	uxtb	w16, w9
     708:      	cmp	w16, wzr
     70c:      	b.eq	0x58c <_stogir.verify.structure+0x41c>
     710:      	ldr	w10, [x28]
     714:      	uxtb	w16, w6
     718:      	cmp	w16, wzr
     71c:      	b.eq	0x584 <_stogir.verify.structure+0x414>
     720:      	uxtb	w16, w7
     724:      	cmp	w16, wzr
     728:      	b.eq	0x54c <_stogir.verify.structure+0x3dc>
     72c:      	mov	x11, #0x4               ; =4
     730:      	b	0x550 <_stogir.verify.structure+0x3e0>
     734:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000734:  ARM64_RELOC_PAGE21	l_stogir.325
     738:      	ldr	x16, [x16]
		0000000000000738:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     73c:      	ldr	w0, [x16]
     740:      	ubfx	x2, x25, #0, #32
     744:      	cmp	x2, x0
     748:      	b.ne	0x75c <_stogir.verify.structure+0x5ec>
     74c:      	mov	x0, #0x1                ; =1
     750:      	b	0x774 <_stogir.verify.structure+0x604>
     754:      	movz	x1, #0x0, lsl #48
     758:      	b	0x7d8 <_stogir.verify.structure+0x668>
     75c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000075c:  ARM64_RELOC_PAGE21	l_stogir.326
     760:      	ldr	x16, [x16]
		0000000000000760:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     764:      	ldr	w0, [x16]
     768:      	cmp	x2, x0
     76c:      	cset	w0, eq
     770:      	ubfx	x0, x0, #0, #8
     774:      	cmp	x0, #0x0
     778:      	b.eq	0xcdc <_stogir.verify.structure+0xb6c>
     77c:      	str	x26, [sp, #0x138]
     780:      	mov	x26, x2
     784:      	str	w22, [sp, #0x140]
     788:      	mov	x22, x0
     78c:      	mov	x0, x23
     790:      	str	w24, [sp, #0x148]
     794:      	mov	w24, w1
     798:      	bl	0x798 <_stogir.verify.structure+0x628>
		0000000000000798:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     79c:      	cmp	x0, #0x0
     7a0:      	cset	w1, eq
     7a4:      	uxtb	w16, w1
     7a8:      	cmp	w16, wzr
     7ac:      	cset	x1, eq
     7b0:      	cmp	x1, #0x0
     7b4:      	b.eq	0x7d8 <_stogir.verify.structure+0x668>
     7b8:      	ldr	w0, [x0]
     7bc:      	uxtb	w0, w0
     7c0:      	cmp	x0, #0x48
     7c4:      	b.ne	0x7d8 <_stogir.verify.structure+0x668>
     7c8:      	ldr	x17, [sp, #0x98]
     7cc:      	str	x17, [sp, #0xa8]
     7d0:      	mov	x16, #0x25              ; =37
     7d4:      	str	x16, [sp, #0x118]
     7d8:      	sxtw	x24, w24
     7dc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007dc:  ARM64_RELOC_PAGE21	l_stogir.327
     7e0:      	ldr	x16, [x16]
		00000000000007e0:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     7e4:      	ldr	w0, [x16]
     7e8:      	cmp	x26, x0
     7ec:      	b.ne	0xcf8 <_stogir.verify.structure+0xb88>
     7f0:      	cmp	x24, #0x0
     7f4:      	b.gt	0x970 <_stogir.verify.structure+0x800>
     7f8:      	ldr	x3, [sp, #0xd0]
     7fc:      	ldr	x0, [sp, #0xd8]
     800:      	movz	x2, #0x0, lsl #48
     804:      	ubfx	x2, x2, #0, #32
     808:      	lsr	x16, x2, #0
     80c:      	cmp	x16, #0x1
     810:      	b.eq	0x82c <_stogir.verify.structure+0x6bc>
     814:      	b.lo	0x81c <_stogir.verify.structure+0x6ac>
     818:      	b	0x830 <_stogir.verify.structure+0x6c0>
     81c:      	cmp	x16, #0x0
     820:      	b.eq	0x828 <_stogir.verify.structure+0x6b8>
     824:      	b	0x830 <_stogir.verify.structure+0x6c0>
     828:      	b	0x834 <_stogir.verify.structure+0x6c4>
     82c:      	b	0x844 <_stogir.verify.structure+0x6d4>
     830:      	b	0xba0 <_stogir.verify.structure+0xa30>
     834:      	ldr	x17, [sp, #0x68]
     838:      	str	x17, [sp, #0xa8]
     83c:      	mov	x16, #0x21              ; =33
     840:      	str	x16, [sp, #0x118]
     844:      	ubfx	x25, x25, #0, #32
     848:      	cmp	x25, #0xf
     84c:      	b.hs	0xd04 <_stogir.verify.structure+0xb94>
     850:      	mov	x16, #0x1               ; =1
     854:      	lsl	x2, x16, x25
     858:      	ubfx	x2, x2, #0, #32
     85c:      	mov	x17, #0x5e1c            ; =24092
     860:      	and	x2, x2, x17
     864:      	ubfx	x2, x2, #0, #32
     868:      	cmp	x2, #0x0
     86c:      	b.eq	0xd1c <_stogir.verify.structure+0xbac>
     870:      	cmp	x22, #0x0
     874:      	b.eq	0xa28 <_stogir.verify.structure+0x8b8>
     878:      	ldr	x2, [sp, #0xc8]
     87c:      	ldr	x4, [sp, #0xb8]
     880:      	ldr	x5, [sp, #0xb0]
     884:      	b	0x570 <_stogir.verify.structure+0x400>
     888:      	orr	w0, w27, wzr
     88c:      	cmp	x28, #0x78
     890:      	cset	w24, eq
     894:      	add	x1, x25, x28, lsl #2
     898:      	ldr	x2, [sp, #0xe8]
     89c:      	add	x3, x2, x28, lsl #2
     8a0:      	cmp	x22, #0x0
     8a4:      	cset	w22, eq
     8a8:      	orr	x28, x1, xzr
     8ac:      	orr	x1, x3, xzr
     8b0:      	mov	x3, #0x1                ; =1
     8b4:      	b	0x6bc <_stogir.verify.structure+0x54c>
     8b8:      	movz	x1, #0x0, lsl #48
     8bc:      	cmp	x1, #0x0
     8c0:      	b.eq	0x888 <_stogir.verify.structure+0x718>
     8c4:      	add	x1, x0, x27
     8c8:      	ldr	x2, [x23, #0x78]
     8cc:      	add	x1, x2, x1, lsl #2
     8d0:      	ldr	w1, [x1]
     8d4:      	sxtw	x1, w1
     8d8:      	cmn	x1, #0x1
     8dc:      	b.eq	0x8ec <_stogir.verify.structure+0x77c>
     8e0:      	ldr	x17, [sp, #0x88]
     8e4:      	str	x17, [sp, #0xa8]
     8e8:      	mov	x20, #0x1b              ; =27
     8ec:      	add	x0, x0, #0x1
     8f0:      	cmp	x20, #0x0
     8f4:      	b.ne	0x8b8 <_stogir.verify.structure+0x748>
     8f8:      	cmp	x0, x21
     8fc:      	cset	w1, lt
     900:      	ubfx	x1, x1, #0, #8
     904:      	b	0x8bc <_stogir.verify.structure+0x74c>
     908:      	mov	w0, w24
     90c:      	bl	0x90c <_stogir.verify.structure+0x79c>
		000000000000090c:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     910:      	sxtw	x0, w0
     914:      	cmn	x0, #0x1
     918:      	b.ne	0x934 <_stogir.verify.structure+0x7c4>
     91c:      	ubfx	x0, x21, #16, #16
     920:      	cmp	x26, x0
     924:      	b.eq	0x934 <_stogir.verify.structure+0x7c4>
     928:      	ldr	x17, [sp, #0x78]
     92c:      	str	x17, [sp, #0xa8]
     930:      	mov	x20, #0x24              ; =36
     934:      	add	x0, x26, #0x4
     938:      	ldr	x1, [x23, #0x8]
     93c:      	asr	x16, x0, #63
     940:      	lsr	x16, x16, #62
     944:      	add	x0, x0, x16
     948:      	asr	x0, x0, #2
     94c:      	orr	x21, x0, xzr
     950:      	add	x0, x21, x27
     954:      	cmp	x0, x1
     958:      	b.le	0x968 <_stogir.verify.structure+0x7f8>
     95c:      	ldr	x17, [sp, #0x80]
     960:      	str	x17, [sp, #0xa8]
     964:      	mov	x20, #0x15              ; =21
     968:      	mov	x0, #0x1                ; =1
     96c:      	b	0x8f0 <_stogir.verify.structure+0x780>
     970:      	ldr	x0, [sp, #0xd8]
     974:      	ldr	x2, [x0, #0x8]
     978:      	cmp	x24, x2
     97c:      	b.gt	0xd34 <_stogir.verify.structure+0xbc4>
     980:      	sub	x2, x24, #0x1
     984:      	ldr	x3, [sp, #0xd0]
     988:      	ldr	x4, [x3, #0x28]
     98c:      	mov	x17, #0x18              ; =24
     990:      	mul	x2, x2, x17
     994:      	add	x2, x2, x4
     998:      	ldr	x4, [x2]
     99c:      	ldr	x2, [x2, #0x8]
     9a0:      	ldr	x5, [x3, #0x8]
     9a4:      	cmp	x4, #0x0
     9a8:      	b.lt	0x9d0 <_stogir.verify.structure+0x860>
     9ac:      	cmp	x4, x5
     9b0:      	b.gt	0x9d0 <_stogir.verify.structure+0x860>
     9b4:      	cmp	x2, #0x0
     9b8:      	b.lt	0x9d0 <_stogir.verify.structure+0x860>
     9bc:      	sub	x4, x5, x4
     9c0:      	cmp	x2, x4
     9c4:      	b.gt	0x9d0 <_stogir.verify.structure+0x860>
     9c8:      	mov	x2, #0x1                ; =1
     9cc:      	b	0x9d4 <_stogir.verify.structure+0x864>
     9d0:      	movz	x2, #0x0, lsl #48
     9d4:      	b	0x804 <_stogir.verify.structure+0x694>
     9d8:      	cmp	x24, #0x0
     9dc:      	b.ne	0xd3c <_stogir.verify.structure+0xbcc>
     9e0:      	uxtb	w16, w27
     9e4:      	cmp	w16, wzr
     9e8:      	b.eq	0xb18 <_stogir.verify.structure+0x9a8>
     9ec:      	ldr	w1, [x19]
     9f0:      	uxtb	w16, w28
     9f4:      	cmp	w16, wzr
     9f8:      	b.eq	0xb60 <_stogir.verify.structure+0x9f0>
     9fc:      	uxtb	w16, w20
     a00:      	cmp	w16, wzr
     a04:      	b.eq	0xa0c <_stogir.verify.structure+0x89c>
     a08:      	mov	x21, #0x4               ; =4
     a0c:      	lsl	x6, x21, #2
     a10:      	ubfx	x6, x6, #0, #32
     a14:      	lsr	x1, x1, x6
     a18:      	ubfx	x1, x1, #0, #32
     a1c:      	and	x1, x1, #0xf
     a20:      	ubfx	x1, x1, #0, #32
     a24:      	b	0xb64 <_stogir.verify.structure+0x9f4>
     a28:      	cmp	x24, #0x0
     a2c:      	b.le	0xd48 <_stogir.verify.structure+0xbd8>
     a30:      	ldr	x1, [x23, #0x8]
     a34:      	cmp	x24, x1
     a38:      	b.ge	0xd50 <_stogir.verify.structure+0xbe0>
     a3c:      	ldr	x2, [sp, #0xc8]
     a40:      	ldr	x1, [x2, #0x8]
     a44:      	cmp	x24, x1
     a48:      	b.ge	0xb70 <_stogir.verify.structure+0xa00>
     a4c:      	ldr	x1, [x23, #0x78]
     a50:      	add	x1, x1, x24, lsl #2
     a54:      	ldr	w1, [x1]
     a58:      	sxtw	x1, w1
     a5c:      	cmp	x1, #0x0
     a60:      	cset	w1, ge
     a64:      	ubfx	x1, x1, #0, #8
     a68:      	b	0xb74 <_stogir.verify.structure+0xa04>
     a6c:      	ldr	w1, [sp, #0x148]
     a70:      	uxtb	w16, w1
     a74:      	cmp	w16, wzr
     a78:      	b.eq	0xd58 <_stogir.verify.structure+0xbe8>
     a7c:      	ldr	w6, [sp, #0x140]
     a80:      	uxtb	w16, w6
     a84:      	cmp	w16, wzr
     a88:      	b.eq	0xa98 <_stogir.verify.structure+0x928>
     a8c:      	ldr	x7, [sp, #0x138]
     a90:      	cmp	x7, #0x2
     a94:      	b.eq	0x580 <_stogir.verify.structure+0x410>
     a98:      	ldr	x17, [sp, #0x70]
     a9c:      	str	x17, [sp, #0xa8]
     aa0:      	mov	x16, #0x1a              ; =26
     aa4:      	str	x16, [sp, #0x118]
     aa8:      	b	0x580 <_stogir.verify.structure+0x410>
     aac:      	movz	x1, #0x0, lsl #48
     ab0:      	ldr	x4, [sp, #0xb8]
     ab4:      	ldr	x5, [sp, #0xb0]
     ab8:      	b	0x570 <_stogir.verify.structure+0x400>
     abc:      	cmp	x24, #0x0
     ac0:      	b.ge	0xd60 <_stogir.verify.structure+0xbf0>
     ac4:      	ldr	x4, [sp, #0xb8]
     ac8:      	ldr	x1, [x4, #0x8]
     acc:      	ldr	x5, [sp, #0xb0]
     ad0:      	ldr	x6, [x5, #0x8]
     ad4:      	cmp	x1, x6
     ad8:      	b.ne	0xb68 <_stogir.verify.structure+0x9f8>
     adc:      	movz	x16, #0x0, lsl #48
     ae0:      	sub	x6, x16, x24
     ae4:      	cmp	x6, x1
     ae8:      	b.gt	0xb98 <_stogir.verify.structure+0xa28>
     aec:      	sub	x1, x6, #0x1
     af0:      	ldr	x6, [x23, #0x50]
     af4:      	add	x1, x6, x1, lsl #2
     af8:      	ldr	w1, [x1]
     afc:      	sxtw	x1, w1
     b00:      	cmp	x1, #0x0
     b04:      	cset	w1, gt
     b08:      	ubfx	x1, x1, #0, #8
     b0c:      	b	0xb9c <_stogir.verify.structure+0xa2c>
     b10:      	brk	#0
     b14:      	b	0xb10 <_stogir.verify.structure+0x9a0>
     b18:      	movz	x1, #0x0, lsl #48
     b1c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b1c:  ARM64_RELOC_PAGE21	l_stogir.328
     b20:      	ldr	x16, [x16]
		0000000000000b20:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     b24:      	ldr	w6, [x16]
     b28:      	ubfx	x1, x1, #0, #32
     b2c:      	cmp	x1, x6
     b30:      	b.ne	0xb40 <_stogir.verify.structure+0x9d0>
     b34:      	ldr	w1, [sp, #0x148]
     b38:      	ldr	w6, [sp, #0x140]
     b3c:      	b	0x580 <_stogir.verify.structure+0x410>
     b40:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b40:  ARM64_RELOC_PAGE21	l_stogir.329
     b44:      	ldr	x16, [x16]
		0000000000000b44:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     b48:      	ldr	w6, [x16]
     b4c:      	cmp	x1, x6
     b50:      	b.ne	0xb78 <_stogir.verify.structure+0xa08>
     b54:      	ldr	w1, [sp, #0x148]
     b58:      	ldr	w6, [sp, #0x140]
     b5c:      	b	0x580 <_stogir.verify.structure+0x410>
     b60:      	movz	x1, #0x0, lsl #48
     b64:      	b	0xb1c <_stogir.verify.structure+0x9ac>
     b68:      	movz	x1, #0x0, lsl #48
     b6c:      	b	0x570 <_stogir.verify.structure+0x400>
     b70:      	movz	x1, #0x0, lsl #48
     b74:      	b	0xab0 <_stogir.verify.structure+0x940>
     b78:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b78:  ARM64_RELOC_PAGE21	l_stogir.330
     b7c:      	ldr	x16, [x16]
		0000000000000b7c:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     b80:      	ldr	w6, [x16]
     b84:      	cmp	x1, x6
     b88:      	b.ne	0xa6c <_stogir.verify.structure+0x8fc>
     b8c:      	ldr	w1, [sp, #0x148]
     b90:      	ldr	w6, [sp, #0x140]
     b94:      	b	0x580 <_stogir.verify.structure+0x410>
     b98:      	movz	x1, #0x0, lsl #48
     b9c:      	b	0xb6c <_stogir.verify.structure+0x9fc>
     ba0:      	brk	#0
     ba4:      	b	0xba0 <_stogir.verify.structure+0xa30>
     ba8:      	mov	x1, x13
     bac:      	str	x8, [sp, #0xa0]
     bb0:      	str	x19, [sp, #0xa8]
     bb4:      	str	x20, [sp, #0x118]
     bb8:      	b	0x4e4 <_stogir.verify.structure+0x374>
     bbc:      	mov	x1, x13
     bc0:      	str	x8, [sp, #0xa0]
     bc4:      	str	x19, [sp, #0xa8]
     bc8:      	str	x20, [sp, #0x118]
     bcc:      	b	0x4e4 <_stogir.verify.structure+0x374>
     bd0:      	str	x8, [sp, #0xa0]
     bd4:      	str	x21, [sp, #0x40]
     bd8:      	str	x22, [sp, #0x58]
     bdc:      	str	x23, [sp, #0x60]
     be0:      	mov	x23, x0
     be4:      	str	x24, [sp, #0x78]
     be8:      	str	x25, [sp, #0x80]
     bec:      	str	x26, [sp, #0x88]
     bf0:      	str	x27, [sp, #0x90]
     bf4:      	str	x28, [sp, #0x98]
     bf8:      	str	x1, [sp, #0x68]
     bfc:      	mov	x1, x13
     c00:      	str	x2, [sp, #0x70]
     c04:      	str	x4, [sp, #0x100]
     c08:      	mov	x0, x11
     c0c:      	mov	x2, x5
     c10:      	mov	x4, x6
     c14:      	mov	x6, x12
     c18:      	mov	x5, x7
     c1c:      	str	x9, [sp, #0xe8]
     c20:      	str	x10, [sp, #0xf8]
     c24:      	b	0x324 <_stogir.verify.structure+0x1b4>
     c28:      	str	x8, [sp, #0xa0]
     c2c:      	str	x22, [sp, #0x58]
     c30:      	str	x23, [sp, #0x60]
     c34:      	ldr	x23, [sp, #0x30]
     c38:      	str	x24, [sp, #0x78]
     c3c:      	str	x25, [sp, #0x80]
     c40:      	str	x26, [sp, #0x88]
     c44:      	str	x27, [sp, #0x90]
     c48:      	str	x28, [sp, #0x98]
     c4c:      	str	x1, [sp, #0x68]
     c50:      	mov	x1, x13
     c54:      	str	x2, [sp, #0x70]
     c58:      	str	x4, [sp, #0x100]
     c5c:      	mov	x0, x11
     c60:      	mov	x2, x5
     c64:      	mov	x4, x6
     c68:      	mov	x6, x12
     c6c:      	mov	x5, x7
     c70:      	str	x9, [sp, #0xe8]
     c74:      	str	x10, [sp, #0xf8]
     c78:      	b	0x2b8 <_stogir.verify.structure+0x148>
     c7c:      	mov	x6, x27
     c80:      	ldr	x1, [sp, #0xc0]
     c84:      	ldr	x3, [sp, #0xd0]
     c88:      	str	x25, [sp, #0x100]
     c8c:      	ldr	x0, [sp, #0xd8]
     c90:      	ldr	x2, [sp, #0xc8]
     c94:      	ldr	x4, [sp, #0xb8]
     c98:      	ldr	x5, [sp, #0xb0]
     c9c:      	str	x19, [sp, #0xf8]
     ca0:      	b	0x2b8 <_stogir.verify.structure+0x148>
     ca4:      	ldr	x1, [sp, #0xa8]
     ca8:      	b	0x500 <_stogir.verify.structure+0x390>
     cac:      	str	x27, [sp, #0x128]
     cb0:      	str	x21, [sp, #0x120]
     cb4:      	ldr	x3, [sp, #0xd0]
     cb8:      	str	x20, [sp, #0x118]
     cbc:      	str	x25, [sp, #0x100]
     cc0:      	ldr	x0, [sp, #0xd8]
     cc4:      	ldr	x4, [sp, #0xb8]
     cc8:      	ldr	x5, [sp, #0xb0]
     ccc:      	str	x2, [sp, #0xe8]
     cd0:      	ldr	x2, [sp, #0xc8]
     cd4:      	str	x19, [sp, #0xf8]
     cd8:      	b	0x1d0 <_stogir.verify.structure+0x60>
     cdc:      	str	x26, [sp, #0x138]
     ce0:      	mov	x26, x2
     ce4:      	str	w24, [sp, #0x148]
     ce8:      	mov	w24, w1
     cec:      	str	w22, [sp, #0x140]
     cf0:      	mov	x22, x0
     cf4:      	b	0x754 <_stogir.verify.structure+0x5e4>
     cf8:      	ldr	x3, [sp, #0xd0]
     cfc:      	ldr	x0, [sp, #0xd8]
     d00:      	b	0x844 <_stogir.verify.structure+0x6d4>
     d04:      	ldr	x2, [sp, #0xc8]
     d08:      	ldr	x4, [sp, #0xb8]
     d0c:      	ldr	x5, [sp, #0xb0]
     d10:      	ldr	w1, [sp, #0x148]
     d14:      	ldr	w6, [sp, #0x140]
     d18:      	b	0x580 <_stogir.verify.structure+0x410>
     d1c:      	ldr	x2, [sp, #0xc8]
     d20:      	ldr	x4, [sp, #0xb8]
     d24:      	ldr	x5, [sp, #0xb0]
     d28:      	ldr	w1, [sp, #0x148]
     d2c:      	ldr	w6, [sp, #0x140]
     d30:      	b	0x580 <_stogir.verify.structure+0x410>
     d34:      	ldr	x3, [sp, #0xd0]
     d38:      	b	0x800 <_stogir.verify.structure+0x690>
     d3c:      	ldr	w1, [sp, #0x148]
     d40:      	ldr	w6, [sp, #0x140]
     d44:      	b	0xa98 <_stogir.verify.structure+0x928>
     d48:      	ldr	x2, [sp, #0xc8]
     d4c:      	b	0xabc <_stogir.verify.structure+0x94c>
     d50:      	ldr	x2, [sp, #0xc8]
     d54:      	b	0xaac <_stogir.verify.structure+0x93c>
     d58:      	ldr	w6, [sp, #0x140]
     d5c:      	b	0xa98 <_stogir.verify.structure+0x928>
     d60:      	ldr	x4, [sp, #0xb8]
     d64:      	ldr	x5, [sp, #0xb0]
     d68:      	b	0x56c <_stogir.verify.structure+0x3fc>

0000000000000d6c <_stogir.verify.integer-operations-target-structured>:
     d6c:      	sub	sp, sp, #0x3b0
     d70:      	str	x29, [sp, #0x10]
     d74:      	str	x30, [sp, #0x18]
     d78:      	add	x29, sp, #0x10
     d7c:      	str	x19, [sp, #0x358]
     d80:      	str	x20, [sp, #0x360]
     d84:      	str	x21, [sp, #0x368]
     d88:      	str	x22, [sp, #0x370]
     d8c:      	str	x23, [sp, #0x378]
     d90:      	str	x24, [sp, #0x380]
     d94:      	str	x25, [sp, #0x388]
     d98:      	str	x26, [sp, #0x390]
     d9c:      	str	x27, [sp, #0x398]
     da0:      	str	x28, [sp, #0x3a0]
     da4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000da4:  ARM64_RELOC_PAGE21	l_stogir.331
     da8:      	ldr	x16, [x16]
		0000000000000da8:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     dac:      	orr	x19, x16, xzr
     db0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000db0:  ARM64_RELOC_PAGE21	l_stogir.332
     db4:      	ldr	x16, [x16]
		0000000000000db4:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     db8:      	orr	x20, x16, xzr
     dbc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000dbc:  ARM64_RELOC_PAGE21	l_stogir.333
     dc0:      	ldr	x16, [x16]
		0000000000000dc0:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     dc4:      	orr	x21, x16, xzr
     dc8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000dc8:  ARM64_RELOC_PAGE21	l_stogir.334
     dcc:      	ldr	x16, [x16]
		0000000000000dcc:  ARM64_RELOC_PAGEOFF12	l_stogir.334
     dd0:      	orr	x22, x16, xzr
     dd4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000dd4:  ARM64_RELOC_PAGE21	l_stogir.335
     dd8:      	ldr	x16, [x16]
		0000000000000dd8:  ARM64_RELOC_PAGEOFF12	l_stogir.335
     ddc:      	orr	x23, x16, xzr
     de0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000de0:  ARM64_RELOC_PAGE21	l_stogir.336
     de4:      	ldr	x16, [x16]
		0000000000000de4:  ARM64_RELOC_PAGEOFF12	l_stogir.336
     de8:      	orr	x24, x16, xzr
     dec:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000dec:  ARM64_RELOC_PAGE21	l_stogir.337
     df0:      	ldr	x16, [x16]
		0000000000000df0:  ARM64_RELOC_PAGEOFF12	l_stogir.337
     df4:      	orr	x25, x16, xzr
     df8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000df8:  ARM64_RELOC_PAGE21	l_stogir.338
     dfc:      	ldr	x16, [x16]
		0000000000000dfc:  ARM64_RELOC_PAGEOFF12	l_stogir.338
     e00:      	orr	x26, x16, xzr
     e04:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e04:  ARM64_RELOC_PAGE21	l_stogir.339
     e08:      	ldr	x16, [x16]
		0000000000000e08:  ARM64_RELOC_PAGEOFF12	l_stogir.339
     e0c:      	orr	x27, x16, xzr
     e10:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e10:  ARM64_RELOC_PAGE21	l_stogir.340
     e14:      	ldr	x16, [x16]
		0000000000000e14:  ARM64_RELOC_PAGEOFF12	l_stogir.340
     e18:      	orr	x28, x16, xzr
     e1c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e1c:  ARM64_RELOC_PAGE21	l_stogir.341
     e20:      	ldr	x16, [x16]
		0000000000000e20:  ARM64_RELOC_PAGEOFF12	l_stogir.341
     e24:      	orr	x2, x16, xzr
     e28:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e28:  ARM64_RELOC_PAGE21	l_stogir.342
     e2c:      	ldr	x16, [x16]
		0000000000000e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.342
     e30:      	orr	x3, x16, xzr
     e34:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e34:  ARM64_RELOC_PAGE21	l_stogir.343
     e38:      	ldr	x16, [x16]
		0000000000000e38:  ARM64_RELOC_PAGEOFF12	l_stogir.343
     e3c:      	orr	x4, x16, xzr
     e40:      	add	x5, x0, #0x78
     e44:      	add	x6, x0, #0x28
     e48:      	add	x7, x0, #0x50
     e4c:      	orr	w9, w1, wzr
     e50:      	orr	w10, w1, wzr
     e54:      	add	x16, sp, #0x20
     e58:      	orr	x11, x16, xzr
     e5c:      	add	x16, sp, #0x30
     e60:      	orr	x12, x16, xzr
     e64:      	add	x12, x12, #0x8
     e68:      	add	x16, sp, #0x50
     e6c:      	orr	x13, x16, xzr
     e70:      	add	x13, x13, #0x8
     e74:      	add	x16, sp, #0xe0
     e78:      	orr	x14, x16, xzr
     e7c:      	add	x14, x14, #0x8
     e80:      	add	x16, sp, #0x100
     e84:      	orr	x15, x16, xzr
     e88:      	add	x15, x15, #0x8
     e8c:      	str	w1, [sp, #0x230]
     e90:      	add	x16, sp, #0x120
     e94:      	orr	x1, x16, xzr
     e98:      	add	x1, x1, #0x8
     e9c:      	str	x1, [sp, #0x238]
     ea0:      	add	x16, sp, #0x140
     ea4:      	orr	x1, x16, xzr
     ea8:      	add	x1, x1, #0x8
     eac:      	str	x1, [sp, #0x240]
     eb0:      	add	x16, sp, #0x160
     eb4:      	orr	x1, x16, xzr
     eb8:      	add	x1, x1, #0x8
     ebc:      	str	x1, [sp, #0x248]
     ec0:      	add	x16, sp, #0x180
     ec4:      	orr	x1, x16, xzr
     ec8:      	add	x1, x1, #0x8
     ecc:      	str	x1, [sp, #0x250]
     ed0:      	add	x16, sp, #0x1a0
     ed4:      	orr	x1, x16, xzr
     ed8:      	add	x1, x1, #0x8
     edc:      	str	x1, [sp, #0x258]
     ee0:      	add	x16, sp, #0x1f0
     ee4:      	orr	x1, x16, xzr
     ee8:      	add	x1, x1, #0x8
     eec:      	str	x20, [sp, #0x260]
     ef0:      	str	x21, [sp, #0x268]
     ef4:      	str	x22, [sp, #0x270]
     ef8:      	mov	x20, #0x1               ; =1
     efc:      	movz	x21, #0x0, lsl #48
     f00:      	movz	x22, #0x0, lsl #48
     f04:      	cmp	x22, #0x0
     f08:      	b.ne	0x1eb0 <_stogir.verify.integer-operations-target-structured+0x1144>
     f0c:      	str	x1, [sp, #0x278]
     f10:      	ldr	x1, [x0, #0x8]
     f14:      	cmp	x20, x1
     f18:      	b.ge	0x1eb8 <_stogir.verify.integer-operations-target-structured+0x114c>
     f1c:      	ldr	x1, [x0]
     f20:      	add	x1, x1, x20, lsl #4
     f24:      	str	x2, [sp, #0x280]
     f28:      	ldr	x2, [x1]
     f2c:      	str	x23, [sp, #0x288]
     f30:      	uxtb	w23, w2
     f34:      	ldr	x1, [x1, #0x8]
     f38:      	str	x24, [sp, #0x290]
     f3c:      	orr	x24, x23, xzr
     f40:      	add	x16, sp, #0x20
     f44:      	str	x2, [x16]
     f48:      	add	x16, sp, #0x20
     f4c:      	str	x1, [x16, #0x8]
     f50:      	ldr	x1, [x0, #0x78]
     f54:      	add	x1, x1, x20, lsl #2
     f58:      	ldr	w1, [x1]
     f5c:      	cmp	x24, #0x83
     f60:      	b.ge	0x1740 <_stogir.verify.integer-operations-target-structured+0x9d4>
     f64:      	add	x2, x3, x24, lsl #1
     f68:      	ldrh	w2, [x2]
     f6c:      	cmp	x24, #0xe
     f70:      	b.lt	0x1ec0 <_stogir.verify.integer-operations-target-structured+0x1154>
     f74:      	str	x0, [sp, #0x298]
     f78:      	cmp	x24, #0x17
     f7c:      	cset	w0, le
     f80:      	ubfx	x0, x0, #0, #8
     f84:      	str	x0, [sp, #0x2a0]
     f88:      	orr	w0, w20, wzr
     f8c:      	sxtw	x2, w2
     f90:      	str	w0, [sp, #0x2a8]
     f94:      	and	x0, x2, #0x4
     f98:      	str	x8, [sp, #0x2d8]
     f9c:      	str	x3, [sp, #0x2c0]
     fa0:      	mov	w3, w1
     fa4:      	str	x5, [sp, #0x318]
     fa8:      	str	x6, [sp, #0x310]
     fac:      	str	x7, [sp, #0x308]
     fb0:      	str	w9, [sp, #0x2e8]
     fb4:      	str	w10, [sp, #0x2f0]
     fb8:      	str	x11, [sp, #0x2f8]
     fbc:      	str	x15, [sp, #0x328]
     fc0:      	str	w1, [sp, #0x320]
     fc4:      	ldr	w1, [sp, #0x2a8]
     fc8:      	str	x25, [sp, #0x2b0]
     fcc:      	mov	x25, x14
     fd0:      	str	x26, [sp, #0x2b8]
     fd4:      	mov	x26, x2
     fd8:      	mov	x2, x11
     fdc:      	str	x27, [sp, #0x2c8]
     fe0:      	mov	x27, x4
     fe4:      	str	x28, [sp, #0x2d0]
     fe8:      	mov	x28, x0
     fec:      	ldr	x0, [sp, #0x298]
     ff0:      	str	x20, [sp, #0x2e0]
     ff4:      	mov	x20, x13
     ff8:      	str	w23, [sp, #0x300]
     ffc:      	mov	x23, x12
    1000:      	bl	0x1000 <_stogir.verify.integer-operations-target-structured+0x294>
		0000000000001000:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    1004:      	uxtb	w1, w0
    1008:      	sxtw	x28, w28
    100c:      	cmp	x1, #0x0
    1010:      	cset	w1, ne
    1014:      	cmp	x28, #0x0
    1018:      	b.ne	0x1750 <_stogir.verify.integer-operations-target-structured+0x9e4>
    101c:      	uxtb	w16, w1
    1020:      	cmp	w16, wzr
    1024:      	b.ne	0x1750 <_stogir.verify.integer-operations-target-structured+0x9e4>
    1028:      	str	x0, [sp, #0x330]
    102c:      	mov	w28, w1
    1030:      	cmp	x24, #0x44
    1034:      	b.ne	0x17c4 <_stogir.verify.integer-operations-target-structured+0xa58>
    1038:      	uxtb	w16, w28
    103c:      	cmp	w16, wzr
    1040:      	b.eq	0x17bc <_stogir.verify.integer-operations-target-structured+0xa50>
    1044:      	movz	x0, #0x0, lsl #48
    1048:      	cmp	x0, #0x0
    104c:      	b.eq	0x10a0 <_stogir.verify.integer-operations-target-structured+0x334>
    1050:      	add	x8, sp, #0x50
    1054:      	ldr	x0, [sp, #0x298]
    1058:      	ldr	w1, [sp, #0x2a8]
    105c:      	bl	0x105c <_stogir.verify.integer-operations-target-structured+0x2f0>
		000000000000105c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    1060:      	add	x16, sp, #0x50
    1064:      	ldr	w0, [x16]
    1068:      	lsr	x16, x0, #0
    106c:      	cmp	x16, #0x1
    1070:      	b.eq	0x108c <_stogir.verify.integer-operations-target-structured+0x320>
    1074:      	b.lo	0x107c <_stogir.verify.integer-operations-target-structured+0x310>
    1078:      	b	0x1090 <_stogir.verify.integer-operations-target-structured+0x324>
    107c:      	cmp	x16, #0x0
    1080:      	b.eq	0x1088 <_stogir.verify.integer-operations-target-structured+0x31c>
    1084:      	b	0x1090 <_stogir.verify.integer-operations-target-structured+0x324>
    1088:      	b	0x17cc <_stogir.verify.integer-operations-target-structured+0xa60>
    108c:      	b	0x1094 <_stogir.verify.integer-operations-target-structured+0x328>
    1090:      	b	0x17d8 <_stogir.verify.integer-operations-target-structured+0xa6c>
    1094:      	add	x16, sp, #0x50
    1098:      	ldr	x19, [x16, #0x8]
    109c:      	ldr	x22, [x20, #0x8]
    10a0:      	cmp	x24, #0x1d
    10a4:      	b.ne	0x17e0 <_stogir.verify.integer-operations-target-structured+0xa74>
    10a8:      	mov	x0, #0x1                ; =1
    10ac:      	cmp	x0, #0x0
    10b0:      	b.eq	0x17f8 <_stogir.verify.integer-operations-target-structured+0xa8c>
    10b4:      	add	x16, sp, #0x20
    10b8:      	ldr	w0, [x16, #0xc]
    10bc:      	sxtw	x0, w0
    10c0:      	cmp	x0, #0x0
    10c4:      	b.ne	0x17f0 <_stogir.verify.integer-operations-target-structured+0xa84>
    10c8:      	movz	x0, #0x0, lsl #48
    10cc:      	cmp	x0, #0x0
    10d0:      	b.eq	0x1128 <_stogir.verify.integer-operations-target-structured+0x3bc>
    10d4:      	add	x16, sp, #0x20
    10d8:      	ldr	w0, [x16, #0xc]
    10dc:      	add	x8, sp, #0x70
    10e0:      	mov	w1, w0
    10e4:      	ldr	x0, [sp, #0x298]
    10e8:      	bl	0x10e8 <_stogir.verify.integer-operations-target-structured+0x37c>
		00000000000010e8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    10ec:      	add	x16, sp, #0x70
    10f0:      	ldr	w0, [x16]
    10f4:      	lsr	x16, x0, #0
    10f8:      	cmp	x16, #0x1
    10fc:      	b.eq	0x1118 <_stogir.verify.integer-operations-target-structured+0x3ac>
    1100:      	b.lo	0x1108 <_stogir.verify.integer-operations-target-structured+0x39c>
    1104:      	b	0x111c <_stogir.verify.integer-operations-target-structured+0x3b0>
    1108:      	cmp	x16, #0x0
    110c:      	b.eq	0x1114 <_stogir.verify.integer-operations-target-structured+0x3a8>
    1110:      	b	0x111c <_stogir.verify.integer-operations-target-structured+0x3b0>
    1114:      	b	0x1120 <_stogir.verify.integer-operations-target-structured+0x3b4>
    1118:      	b	0x1800 <_stogir.verify.integer-operations-target-structured+0xa94>
    111c:      	b	0x1898 <_stogir.verify.integer-operations-target-structured+0xb2c>
    1120:      	ldr	x19, [sp, #0x260]
    1124:      	mov	x22, #0x16              ; =22
    1128:      	and	x0, x26, #0x8
    112c:      	sxtw	x0, w0
    1130:      	cmp	x0, #0x0
    1134:      	b.ne	0x18a0 <_stogir.verify.integer-operations-target-structured+0xb34>
    1138:      	movz	x0, #0x0, lsl #48
    113c:      	cmp	x24, #0x2c
    1140:      	cset	w1, eq
    1144:      	cmp	x0, #0x0
    1148:      	b.eq	0x18a8 <_stogir.verify.integer-operations-target-structured+0xb3c>
    114c:      	mov	x0, #0x1                ; =1
    1150:      	cmp	x0, #0x0
    1154:      	b.eq	0x11c4 <_stogir.verify.integer-operations-target-structured+0x458>
    1158:      	uxtb	w16, w1
    115c:      	cmp	w16, wzr
    1160:      	b.eq	0x18b0 <_stogir.verify.integer-operations-target-structured+0xb44>
    1164:      	add	x8, sp, #0xa0
    1168:      	ldr	x0, [sp, #0x298]
    116c:      	ldr	w1, [sp, #0x2a8]
    1170:      	bl	0x1170 <_stogir.verify.integer-operations-target-structured+0x404>
		0000000000001170:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    1174:      	add	x16, sp, #0xa0
    1178:      	ldr	x0, [x16]
    117c:      	add	x16, sp, #0xa0
    1180:      	ldr	x1, [x16, #0x8]
    1184:      	add	x16, sp, #0xa0
    1188:      	ldr	x2, [x16, #0x10]
    118c:      	ubfx	x0, x0, #0, #32
    1190:      	lsr	x16, x0, #0
    1194:      	cmp	x16, #0x1
    1198:      	b.eq	0x11b4 <_stogir.verify.integer-operations-target-structured+0x448>
    119c:      	b.lo	0x11a4 <_stogir.verify.integer-operations-target-structured+0x438>
    11a0:      	b	0x11b8 <_stogir.verify.integer-operations-target-structured+0x44c>
    11a4:      	cmp	x16, #0x0
    11a8:      	b.eq	0x11b0 <_stogir.verify.integer-operations-target-structured+0x444>
    11ac:      	b	0x11b8 <_stogir.verify.integer-operations-target-structured+0x44c>
    11b0:      	b	0x18dc <_stogir.verify.integer-operations-target-structured+0xb70>
    11b4:      	b	0x11bc <_stogir.verify.integer-operations-target-structured+0x450>
    11b8:      	b	0x18e8 <_stogir.verify.integer-operations-target-structured+0xb7c>
    11bc:      	mov	x19, x1
    11c0:      	mov	x22, x2
    11c4:      	and	x0, x26, #0x10
    11c8:      	sxtw	x0, w0
    11cc:      	cmp	x0, #0x0
    11d0:      	b.ne	0x18f0 <_stogir.verify.integer-operations-target-structured+0xb84>
    11d4:      	movz	x0, #0x0, lsl #48
    11d8:      	cmp	x0, #0x0
    11dc:      	b.eq	0x1230 <_stogir.verify.integer-operations-target-structured+0x4c4>
    11e0:      	add	x8, sp, #0xe0
    11e4:      	ldr	x0, [sp, #0x298]
    11e8:      	ldr	w1, [sp, #0x2a8]
    11ec:      	bl	0x11ec <_stogir.verify.integer-operations-target-structured+0x480>
		00000000000011ec:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    11f0:      	add	x16, sp, #0xe0
    11f4:      	ldr	w0, [x16]
    11f8:      	lsr	x16, x0, #0
    11fc:      	cmp	x16, #0x1
    1200:      	b.eq	0x121c <_stogir.verify.integer-operations-target-structured+0x4b0>
    1204:      	b.lo	0x120c <_stogir.verify.integer-operations-target-structured+0x4a0>
    1208:      	b	0x1220 <_stogir.verify.integer-operations-target-structured+0x4b4>
    120c:      	cmp	x16, #0x0
    1210:      	b.eq	0x1218 <_stogir.verify.integer-operations-target-structured+0x4ac>
    1214:      	b	0x1220 <_stogir.verify.integer-operations-target-structured+0x4b4>
    1218:      	b	0x18f8 <_stogir.verify.integer-operations-target-structured+0xb8c>
    121c:      	b	0x1224 <_stogir.verify.integer-operations-target-structured+0x4b8>
    1220:      	b	0x1904 <_stogir.verify.integer-operations-target-structured+0xb98>
    1224:      	add	x16, sp, #0xe0
    1228:      	ldr	x19, [x16, #0x8]
    122c:      	ldr	x22, [x25, #0x8]
    1230:      	and	x0, x26, #0x20
    1234:      	sxtw	x0, w0
    1238:      	cmp	x0, #0x0
    123c:      	b.ne	0x190c <_stogir.verify.integer-operations-target-structured+0xba0>
    1240:      	movz	x0, #0x0, lsl #48
    1244:      	cmp	x0, #0x0
    1248:      	b.eq	0x1ec8 <_stogir.verify.integer-operations-target-structured+0x115c>
    124c:      	add	x8, sp, #0x100
    1250:      	ldr	x0, [sp, #0x298]
    1254:      	ldr	w1, [sp, #0x2a8]
    1258:      	bl	0x1258 <_stogir.verify.integer-operations-target-structured+0x4ec>
		0000000000001258:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    125c:      	add	x16, sp, #0x100
    1260:      	ldr	w0, [x16]
    1264:      	lsr	x16, x0, #0
    1268:      	cmp	x16, #0x1
    126c:      	b.eq	0x128c <_stogir.verify.integer-operations-target-structured+0x520>
    1270:      	b.lo	0x1278 <_stogir.verify.integer-operations-target-structured+0x50c>
    1274:      	b	0x1290 <_stogir.verify.integer-operations-target-structured+0x524>
    1278:      	cmp	x16, #0x0
    127c:      	b.eq	0x1284 <_stogir.verify.integer-operations-target-structured+0x518>
    1280:      	b	0x1290 <_stogir.verify.integer-operations-target-structured+0x524>
    1284:      	ldr	x0, [sp, #0x328]
    1288:      	b	0x1914 <_stogir.verify.integer-operations-target-structured+0xba8>
    128c:      	b	0x1294 <_stogir.verify.integer-operations-target-structured+0x528>
    1290:      	b	0x1920 <_stogir.verify.integer-operations-target-structured+0xbb4>
    1294:      	add	x16, sp, #0x100
    1298:      	ldr	x19, [x16, #0x8]
    129c:      	ldr	x0, [sp, #0x328]
    12a0:      	ldr	x22, [x0, #0x8]
    12a4:      	and	x1, x26, #0x40
    12a8:      	sxtw	x1, w1
    12ac:      	cmp	x1, #0x0
    12b0:      	b.ne	0x1928 <_stogir.verify.integer-operations-target-structured+0xbbc>
    12b4:      	movz	x1, #0x0, lsl #48
    12b8:      	cmp	x1, #0x0
    12bc:      	b.eq	0x1ed0 <_stogir.verify.integer-operations-target-structured+0x1164>
    12c0:      	add	x8, sp, #0x120
    12c4:      	ldr	w1, [sp, #0x2a8]
    12c8:      	str	x0, [sp, #0x328]
    12cc:      	ldr	x0, [sp, #0x298]
    12d0:      	bl	0x12d0 <_stogir.verify.integer-operations-target-structured+0x564>
		00000000000012d0:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    12d4:      	add	x16, sp, #0x120
    12d8:      	ldr	w0, [x16]
    12dc:      	lsr	x16, x0, #0
    12e0:      	cmp	x16, #0x1
    12e4:      	b.eq	0x1304 <_stogir.verify.integer-operations-target-structured+0x598>
    12e8:      	b.lo	0x12f0 <_stogir.verify.integer-operations-target-structured+0x584>
    12ec:      	b	0x1308 <_stogir.verify.integer-operations-target-structured+0x59c>
    12f0:      	cmp	x16, #0x0
    12f4:      	b.eq	0x12fc <_stogir.verify.integer-operations-target-structured+0x590>
    12f8:      	b	0x1308 <_stogir.verify.integer-operations-target-structured+0x59c>
    12fc:      	ldr	x0, [sp, #0x238]
    1300:      	b	0x1930 <_stogir.verify.integer-operations-target-structured+0xbc4>
    1304:      	b	0x130c <_stogir.verify.integer-operations-target-structured+0x5a0>
    1308:      	b	0x193c <_stogir.verify.integer-operations-target-structured+0xbd0>
    130c:      	add	x16, sp, #0x120
    1310:      	ldr	x19, [x16, #0x8]
    1314:      	ldr	x0, [sp, #0x238]
    1318:      	ldr	x22, [x0, #0x8]
    131c:      	and	x1, x26, #0x80
    1320:      	sxtw	x1, w1
    1324:      	cmp	x1, #0x0
    1328:      	b.ne	0x1944 <_stogir.verify.integer-operations-target-structured+0xbd8>
    132c:      	movz	x1, #0x0, lsl #48
    1330:      	cmp	x1, #0x0
    1334:      	b.eq	0x1edc <_stogir.verify.integer-operations-target-structured+0x1170>
    1338:      	add	x8, sp, #0x140
    133c:      	ldr	w1, [sp, #0x2a8]
    1340:      	str	x0, [sp, #0x238]
    1344:      	ldr	x0, [sp, #0x298]
    1348:      	bl	0x1348 <_stogir.verify.integer-operations-target-structured+0x5dc>
		0000000000001348:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    134c:      	add	x16, sp, #0x140
    1350:      	ldr	w0, [x16]
    1354:      	lsr	x16, x0, #0
    1358:      	cmp	x16, #0x1
    135c:      	b.eq	0x137c <_stogir.verify.integer-operations-target-structured+0x610>
    1360:      	b.lo	0x1368 <_stogir.verify.integer-operations-target-structured+0x5fc>
    1364:      	b	0x1380 <_stogir.verify.integer-operations-target-structured+0x614>
    1368:      	cmp	x16, #0x0
    136c:      	b.eq	0x1374 <_stogir.verify.integer-operations-target-structured+0x608>
    1370:      	b	0x1380 <_stogir.verify.integer-operations-target-structured+0x614>
    1374:      	ldr	x0, [sp, #0x240]
    1378:      	b	0x194c <_stogir.verify.integer-operations-target-structured+0xbe0>
    137c:      	b	0x1384 <_stogir.verify.integer-operations-target-structured+0x618>
    1380:      	b	0x1958 <_stogir.verify.integer-operations-target-structured+0xbec>
    1384:      	add	x16, sp, #0x140
    1388:      	ldr	x19, [x16, #0x8]
    138c:      	ldr	x0, [sp, #0x240]
    1390:      	ldr	x22, [x0, #0x8]
    1394:      	and	x1, x26, #0x100
    1398:      	sxtw	x1, w1
    139c:      	cmp	x1, #0x0
    13a0:      	b.ne	0x1960 <_stogir.verify.integer-operations-target-structured+0xbf4>
    13a4:      	movz	x1, #0x0, lsl #48
    13a8:      	cmp	x1, #0x0
    13ac:      	b.eq	0x1ee8 <_stogir.verify.integer-operations-target-structured+0x117c>
    13b0:      	add	x8, sp, #0x160
    13b4:      	ldr	w1, [sp, #0x2a8]
    13b8:      	ldr	w2, [sp, #0x2f0]
    13bc:      	str	x0, [sp, #0x240]
    13c0:      	ldr	x0, [sp, #0x298]
    13c4:      	bl	0x13c4 <_stogir.verify.integer-operations-target-structured+0x658>
		00000000000013c4:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    13c8:      	add	x16, sp, #0x160
    13cc:      	ldr	w0, [x16]
    13d0:      	lsr	x16, x0, #0
    13d4:      	cmp	x16, #0x1
    13d8:      	b.eq	0x13f8 <_stogir.verify.integer-operations-target-structured+0x68c>
    13dc:      	b.lo	0x13e4 <_stogir.verify.integer-operations-target-structured+0x678>
    13e0:      	b	0x13fc <_stogir.verify.integer-operations-target-structured+0x690>
    13e4:      	cmp	x16, #0x0
    13e8:      	b.eq	0x13f0 <_stogir.verify.integer-operations-target-structured+0x684>
    13ec:      	b	0x13fc <_stogir.verify.integer-operations-target-structured+0x690>
    13f0:      	ldr	x0, [sp, #0x248]
    13f4:      	b	0x1968 <_stogir.verify.integer-operations-target-structured+0xbfc>
    13f8:      	b	0x1400 <_stogir.verify.integer-operations-target-structured+0x694>
    13fc:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xc08>
    1400:      	add	x16, sp, #0x160
    1404:      	ldr	x19, [x16, #0x8]
    1408:      	ldr	x0, [sp, #0x248]
    140c:      	ldr	x22, [x0, #0x8]
    1410:      	and	x1, x26, #0x200
    1414:      	sxtw	x1, w1
    1418:      	cmp	x1, #0x0
    141c:      	b.ne	0x197c <_stogir.verify.integer-operations-target-structured+0xc10>
    1420:      	movz	x1, #0x0, lsl #48
    1424:      	cmp	x1, #0x0
    1428:      	b.eq	0x1ef4 <_stogir.verify.integer-operations-target-structured+0x1188>
    142c:      	add	x8, sp, #0x180
    1430:      	ldr	w1, [sp, #0x2a8]
    1434:      	ldr	w2, [sp, #0x230]
    1438:      	str	x0, [sp, #0x248]
    143c:      	ldr	x0, [sp, #0x298]
    1440:      	bl	0x1440 <_stogir.verify.integer-operations-target-structured+0x6d4>
		0000000000001440:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    1444:      	add	x16, sp, #0x180
    1448:      	ldr	w0, [x16]
    144c:      	lsr	x16, x0, #0
    1450:      	cmp	x16, #0x1
    1454:      	b.eq	0x1474 <_stogir.verify.integer-operations-target-structured+0x708>
    1458:      	b.lo	0x1460 <_stogir.verify.integer-operations-target-structured+0x6f4>
    145c:      	b	0x1478 <_stogir.verify.integer-operations-target-structured+0x70c>
    1460:      	cmp	x16, #0x0
    1464:      	b.eq	0x146c <_stogir.verify.integer-operations-target-structured+0x700>
    1468:      	b	0x1478 <_stogir.verify.integer-operations-target-structured+0x70c>
    146c:      	ldr	x0, [sp, #0x250]
    1470:      	b	0x1984 <_stogir.verify.integer-operations-target-structured+0xc18>
    1474:      	b	0x147c <_stogir.verify.integer-operations-target-structured+0x710>
    1478:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xc24>
    147c:      	add	x16, sp, #0x180
    1480:      	ldr	x19, [x16, #0x8]
    1484:      	ldr	x0, [sp, #0x250]
    1488:      	ldr	x22, [x0, #0x8]
    148c:      	cmp	x24, #0x3c
    1490:      	b.ne	0x1f00 <_stogir.verify.integer-operations-target-structured+0x1194>
    1494:      	add	x8, sp, #0x1a0
    1498:      	ldr	w1, [sp, #0x2a8]
    149c:      	str	x0, [sp, #0x250]
    14a0:      	ldr	x0, [sp, #0x298]
    14a4:      	bl	0x14a4 <_stogir.verify.integer-operations-target-structured+0x738>
		00000000000014a4:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    14a8:      	add	x16, sp, #0x1a0
    14ac:      	ldr	w0, [x16]
    14b0:      	lsr	x16, x0, #0
    14b4:      	cmp	x16, #0x1
    14b8:      	b.eq	0x14d8 <_stogir.verify.integer-operations-target-structured+0x76c>
    14bc:      	b.lo	0x14c4 <_stogir.verify.integer-operations-target-structured+0x758>
    14c0:      	b	0x14dc <_stogir.verify.integer-operations-target-structured+0x770>
    14c4:      	cmp	x16, #0x0
    14c8:      	b.eq	0x14d0 <_stogir.verify.integer-operations-target-structured+0x764>
    14cc:      	b	0x14dc <_stogir.verify.integer-operations-target-structured+0x770>
    14d0:      	ldr	x0, [sp, #0x258]
    14d4:      	b	0x1998 <_stogir.verify.integer-operations-target-structured+0xc2c>
    14d8:      	b	0x14e0 <_stogir.verify.integer-operations-target-structured+0x774>
    14dc:      	b	0x19a4 <_stogir.verify.integer-operations-target-structured+0xc38>
    14e0:      	add	x16, sp, #0x1a0
    14e4:      	ldr	x19, [x16, #0x8]
    14e8:      	ldr	x0, [sp, #0x258]
    14ec:      	ldr	x22, [x0, #0x8]
    14f0:      	cmp	x24, #0x78
    14f4:      	b.ne	0x1f0c <_stogir.verify.integer-operations-target-structured+0x11a0>
    14f8:      	add	x16, sp, #0x20
    14fc:      	ldr	w1, [x16]
    1500:      	ubfx	x1, x1, #8, #8
    1504:      	cmp	x1, #0x0
    1508:      	b.ne	0x19ac <_stogir.verify.integer-operations-target-structured+0xc40>
    150c:      	add	x16, sp, #0x20
    1510:      	ldr	w1, [x16, #0x8]
    1514:      	sxtw	x1, w1
    1518:      	cmp	x1, #0x0
    151c:      	b.eq	0x1528 <_stogir.verify.integer-operations-target-structured+0x7bc>
    1520:      	ldr	x19, [sp, #0x270]
    1524:      	mov	x22, #0x1f              ; =31
    1528:      	str	x0, [sp, #0x258]
    152c:      	add	x0, x21, #0x1
    1530:      	sxtw	x21, w0
    1534:      	ldr	x0, [sp, #0x330]
    1538:      	uxth	w0, w0
    153c:      	mov	w17, #0x8               ; =8
    1540:      	uxth	w16, w0
    1544:      	ubfx	w17, w17, #0, #4
    1548:      	lsr	w0, w16, w17
    154c:      	uxth	w0, w0
    1550:      	uxtb	w0, w0
    1554:      	cmp	x0, #0x0
    1558:      	b.eq	0x1f14 <_stogir.verify.integer-operations-target-structured+0x11a8>
    155c:      	add	x8, sp, #0x1f0
    1560:      	ldr	w1, [sp, #0x2a8]
    1564:      	str	x20, [sp, #0x338]
    1568:      	mov	x20, x0
    156c:      	ldr	x0, [sp, #0x298]
    1570:      	bl	0x1570 <_stogir.verify.integer-operations-target-structured+0x804>
		0000000000001570:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    1574:      	add	x16, sp, #0x1f0
    1578:      	ldr	w0, [x16]
    157c:      	lsr	x16, x0, #0
    1580:      	cmp	x16, #0x1
    1584:      	b.eq	0x15a4 <_stogir.verify.integer-operations-target-structured+0x838>
    1588:      	b.lo	0x1590 <_stogir.verify.integer-operations-target-structured+0x824>
    158c:      	b	0x15a8 <_stogir.verify.integer-operations-target-structured+0x83c>
    1590:      	cmp	x16, #0x0
    1594:      	b.eq	0x159c <_stogir.verify.integer-operations-target-structured+0x830>
    1598:      	b	0x15a8 <_stogir.verify.integer-operations-target-structured+0x83c>
    159c:      	ldr	x0, [sp, #0x278]
    15a0:      	b	0x1a3c <_stogir.verify.integer-operations-target-structured+0xcd0>
    15a4:      	b	0x15ac <_stogir.verify.integer-operations-target-structured+0x840>
    15a8:      	b	0x1a48 <_stogir.verify.integer-operations-target-structured+0xcdc>
    15ac:      	add	x16, sp, #0x1f0
    15b0:      	ldr	x19, [x16, #0x8]
    15b4:      	ldr	x0, [sp, #0x278]
    15b8:      	ldr	x22, [x0, #0x8]
    15bc:      	uxtb	w16, w28
    15c0:      	cmp	w16, wzr
    15c4:      	b.eq	0x1a50 <_stogir.verify.integer-operations-target-structured+0xce4>
    15c8:      	movz	x1, #0x0, lsl #48
    15cc:      	and	x2, x26, #0x1
    15d0:      	and	x3, x26, #0x2
    15d4:      	sxtw	x2, w2
    15d8:      	sxtw	x3, w3
    15dc:      	cmp	x2, #0x0
    15e0:      	cset	w2, eq
    15e4:      	cmp	x3, #0x0
    15e8:      	cset	w3, eq
    15ec:      	uxtb	w16, w2
    15f0:      	cmp	w16, wzr
    15f4:      	cset	x26, eq
    15f8:      	uxtb	w16, w3
    15fc:      	cmp	w16, wzr
    1600:      	cset	x28, eq
    1604:      	cmp	x1, #0x0
    1608:      	b.eq	0x1f24 <_stogir.verify.integer-operations-target-structured+0x11b8>
    160c:      	cmp	x20, #0x0
    1610:      	b.eq	0x1a58 <_stogir.verify.integer-operations-target-structured+0xcec>
    1614:      	movz	x1, #0x0, lsl #48
    1618:      	cmp	x1, #0x0
    161c:      	b.eq	0x1f2c <_stogir.verify.integer-operations-target-structured+0x11c0>
    1620:      	ldr	x20, [sp, #0x2a0]
    1624:      	cmp	x20, #0x0
    1628:      	b.eq	0x1a60 <_stogir.verify.integer-operations-target-structured+0xcf4>
    162c:      	mov	x1, #0x1                ; =1
    1630:      	cmp	x1, #0x0
    1634:      	b.eq	0x1f34 <_stogir.verify.integer-operations-target-structured+0x11c8>
    1638:      	add	x16, sp, #0x210
    163c:      	str	x16, [sp]
    1640:      	ldr	w1, [sp, #0x2a8]
    1644:      	str	x0, [sp, #0x278]
    1648:      	ldr	x0, [sp, #0x298]
    164c:      	mov	x2, #0x1                ; =1
    1650:      	bl	0x1650 <_stogir.verify.integer-operations-target-structured+0x8e4>
		0000000000001650:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1654:      	ldr	x16, [sp]
    1658:      	str	x0, [x16]
    165c:      	str	x1, [x16, #0x8]
    1660:      	add	x16, sp, #0x210
    1664:      	ldr	x0, [x16]
    1668:      	add	x16, sp, #0x210
    166c:      	ldr	x1, [x16, #0x8]
    1670:      	ubfx	x0, x0, #0, #32
    1674:      	lsr	x16, x0, #0
    1678:      	cmp	x16, #0x1
    167c:      	b.eq	0x1698 <_stogir.verify.integer-operations-target-structured+0x92c>
    1680:      	b.lo	0x1688 <_stogir.verify.integer-operations-target-structured+0x91c>
    1684:      	b	0x169c <_stogir.verify.integer-operations-target-structured+0x930>
    1688:      	cmp	x16, #0x0
    168c:      	b.eq	0x1694 <_stogir.verify.integer-operations-target-structured+0x928>
    1690:      	b	0x169c <_stogir.verify.integer-operations-target-structured+0x930>
    1694:      	b	0x16a0 <_stogir.verify.integer-operations-target-structured+0x934>
    1698:      	b	0x1a88 <_stogir.verify.integer-operations-target-structured+0xd1c>
    169c:      	b	0x1e3c <_stogir.verify.integer-operations-target-structured+0x10d0>
    16a0:      	str	x23, [sp, #0x340]
    16a4:      	str	x25, [sp, #0x348]
    16a8:      	str	x27, [sp, #0x350]
    16ac:      	ldr	x19, [sp, #0x2b0]
    16b0:      	mov	x22, #0x17              ; =23
    16b4:      	add	x0, x21, #0x1
    16b8:      	sxtw	x21, w0
    16bc:      	ldr	w0, [sp, #0x320]
    16c0:      	sxtw	x0, w0
    16c4:      	add	x0, x0, #0x4
    16c8:      	asr	x16, x0, #63
    16cc:      	lsr	x16, x16, #62
    16d0:      	add	x0, x0, x16
    16d4:      	asr	x0, x0, #2
    16d8:      	ldr	x1, [sp, #0x2e0]
    16dc:      	add	x1, x0, x1
    16e0:      	ldr	x8, [sp, #0x2d8]
    16e4:      	ldr	x0, [sp, #0x298]
    16e8:      	ldr	x11, [sp, #0x2f8]
    16ec:      	ldr	x23, [sp, #0x288]
    16f0:      	ldr	x24, [sp, #0x290]
    16f4:      	ldr	x25, [sp, #0x2b0]
    16f8:      	ldr	x26, [sp, #0x2b8]
    16fc:      	ldr	x27, [sp, #0x2c8]
    1700:      	ldr	x28, [sp, #0x2d0]
    1704:      	ldr	x2, [sp, #0x280]
    1708:      	ldr	w9, [sp, #0x2e8]
    170c:      	ldr	x12, [sp, #0x340]
    1710:      	ldr	x13, [sp, #0x338]
    1714:      	ldr	x14, [sp, #0x348]
    1718:      	ldr	x15, [sp, #0x328]
    171c:      	ldr	w10, [sp, #0x2f0]
    1720:      	ldr	x3, [sp, #0x2c0]
    1724:      	ldr	x4, [sp, #0x350]
    1728:      	ldr	x5, [sp, #0x318]
    172c:      	ldr	x6, [sp, #0x310]
    1730:      	ldr	x7, [sp, #0x308]
    1734:      	mov	x20, x1
    1738:      	ldr	x1, [sp, #0x278]
    173c:      	b	0xf04 <_stogir.verify.integer-operations-target-structured+0x198>
    1740:      	movz	x2, #0x0, lsl #48
    1744:      	b	0xf6c <_stogir.verify.integer-operations-target-structured+0x200>
    1748:      	movz	x0, #0x0, lsl #48
    174c:      	b	0xf84 <_stogir.verify.integer-operations-target-structured+0x218>
    1750:      	add	x8, sp, #0x30
    1754:      	ldr	w2, [sp, #0x2e8]
    1758:      	str	x0, [sp, #0x330]
    175c:      	ldr	x0, [sp, #0x298]
    1760:      	mov	w28, w1
    1764:      	ldr	w1, [sp, #0x2a8]
    1768:      	bl	0x1768 <_stogir.verify.integer-operations-target-structured+0x9fc>
		0000000000001768:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    176c:      	add	x16, sp, #0x30
    1770:      	ldr	w0, [x16]
    1774:      	lsr	x16, x0, #0
    1778:      	cmp	x16, #0x1
    177c:      	b.eq	0x1798 <_stogir.verify.integer-operations-target-structured+0xa2c>
    1780:      	b.lo	0x1788 <_stogir.verify.integer-operations-target-structured+0xa1c>
    1784:      	b	0x179c <_stogir.verify.integer-operations-target-structured+0xa30>
    1788:      	cmp	x16, #0x0
    178c:      	b.eq	0x1794 <_stogir.verify.integer-operations-target-structured+0xa28>
    1790:      	b	0x179c <_stogir.verify.integer-operations-target-structured+0xa30>
    1794:      	b	0x17b0 <_stogir.verify.integer-operations-target-structured+0xa44>
    1798:      	b	0x17a0 <_stogir.verify.integer-operations-target-structured+0xa34>
    179c:      	b	0x1e44 <_stogir.verify.integer-operations-target-structured+0x10d8>
    17a0:      	add	x16, sp, #0x30
    17a4:      	ldr	x19, [x16, #0x8]
    17a8:      	ldr	x22, [x23, #0x8]
    17ac:      	b	0x1030 <_stogir.verify.integer-operations-target-structured+0x2c4>
    17b0:      	add	x0, x21, #0x1
    17b4:      	sxtw	x21, w0
    17b8:      	b	0x17ac <_stogir.verify.integer-operations-target-structured+0xa40>
    17bc:      	mov	x0, #0x1                ; =1
    17c0:      	b	0x1048 <_stogir.verify.integer-operations-target-structured+0x2dc>
    17c4:      	movz	x0, #0x0, lsl #48
    17c8:      	b	0x1048 <_stogir.verify.integer-operations-target-structured+0x2dc>
    17cc:      	add	x0, x21, #0x1
    17d0:      	sxtw	x21, w0
    17d4:      	b	0x10a0 <_stogir.verify.integer-operations-target-structured+0x334>
    17d8:      	brk	#0
    17dc:      	b	0x17d8 <_stogir.verify.integer-operations-target-structured+0xa6c>
    17e0:      	cmp	x24, #0x1e
    17e4:      	cset	w0, eq
    17e8:      	ubfx	x0, x0, #0, #8
    17ec:      	b	0x10ac <_stogir.verify.integer-operations-target-structured+0x340>
    17f0:      	mov	x0, #0x1                ; =1
    17f4:      	b	0x10cc <_stogir.verify.integer-operations-target-structured+0x360>
    17f8:      	movz	x0, #0x0, lsl #48
    17fc:      	b	0x10cc <_stogir.verify.integer-operations-target-structured+0x360>
    1800:      	add	x16, sp, #0x70
    1804:      	ldr	x0, [x16, #0x8]
    1808:      	add	x16, sp, #0x20
    180c:      	ldr	w1, [x16, #0xc]
    1810:      	sxtw	x1, w1
    1814:      	cmp	x1, #0x0
    1818:      	b.ge	0x1834 <_stogir.verify.integer-operations-target-structured+0xac8>
    181c:      	mov	x0, #0x1                ; =1
    1820:      	cmp	x0, #0x0
    1824:      	b.eq	0x1830 <_stogir.verify.integer-operations-target-structured+0xac4>
    1828:      	ldr	x19, [sp, #0x268]
    182c:      	mov	x22, #0x2d              ; =45
    1830:      	b	0x1128 <_stogir.verify.integer-operations-target-structured+0x3bc>
    1834:      	uxtb	w0, w0
    1838:      	cmp	x0, #0x83
    183c:      	b.ge	0x1888 <_stogir.verify.integer-operations-target-structured+0xb1c>
    1840:      	add	x1, x0, x27
    1844:      	ldrb	w1, [x1]
    1848:      	uxtb	w1, w1
    184c:      	and	x1, x1, #0x2
    1850:      	uxtb	w1, w1
    1854:      	cmp	x1, #0x0
    1858:      	cset	w1, eq
    185c:      	uxtb	w16, w1
    1860:      	cmp	w16, wzr
    1864:      	cset	x1, eq
    1868:      	cmp	x1, #0x0
    186c:      	b.ne	0x1890 <_stogir.verify.integer-operations-target-structured+0xb24>
    1870:      	cmp	x0, #0x65
    1874:      	b.eq	0x1890 <_stogir.verify.integer-operations-target-structured+0xb24>
    1878:      	cmp	x0, #0x66
    187c:      	b.eq	0x1890 <_stogir.verify.integer-operations-target-structured+0xb24>
    1880:      	mov	x0, #0x1                ; =1
    1884:      	b	0x1820 <_stogir.verify.integer-operations-target-structured+0xab4>
    1888:      	movz	x1, #0x0, lsl #48
    188c:      	b	0x1848 <_stogir.verify.integer-operations-target-structured+0xadc>
    1890:      	movz	x0, #0x0, lsl #48
    1894:      	b	0x1884 <_stogir.verify.integer-operations-target-structured+0xb18>
    1898:      	brk	#0
    189c:      	b	0x1898 <_stogir.verify.integer-operations-target-structured+0xb2c>
    18a0:      	mov	x0, #0x1                ; =1
    18a4:      	b	0x113c <_stogir.verify.integer-operations-target-structured+0x3d0>
    18a8:      	ubfx	x0, x1, #0, #8
    18ac:      	b	0x1150 <_stogir.verify.integer-operations-target-structured+0x3e4>
    18b0:      	add	x8, sp, #0xc0
    18b4:      	ldr	x0, [sp, #0x298]
    18b8:      	ldr	w1, [sp, #0x2a8]
    18bc:      	bl	0x18bc <_stogir.verify.integer-operations-target-structured+0xb50>
		00000000000018bc:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    18c0:      	add	x16, sp, #0xc0
    18c4:      	ldr	x0, [x16]
    18c8:      	add	x16, sp, #0xc0
    18cc:      	ldr	x1, [x16, #0x8]
    18d0:      	add	x16, sp, #0xc0
    18d4:      	ldr	x2, [x16, #0x10]
    18d8:      	b	0x118c <_stogir.verify.integer-operations-target-structured+0x420>
    18dc:      	add	x0, x21, #0x1
    18e0:      	sxtw	x21, w0
    18e4:      	b	0x11c4 <_stogir.verify.integer-operations-target-structured+0x458>
    18e8:      	brk	#0
    18ec:      	b	0x18e8 <_stogir.verify.integer-operations-target-structured+0xb7c>
    18f0:      	mov	x0, #0x1                ; =1
    18f4:      	b	0x11d8 <_stogir.verify.integer-operations-target-structured+0x46c>
    18f8:      	add	x0, x21, #0x1
    18fc:      	sxtw	x21, w0
    1900:      	b	0x1230 <_stogir.verify.integer-operations-target-structured+0x4c4>
    1904:      	brk	#0
    1908:      	b	0x1904 <_stogir.verify.integer-operations-target-structured+0xb98>
    190c:      	mov	x0, #0x1                ; =1
    1910:      	b	0x1244 <_stogir.verify.integer-operations-target-structured+0x4d8>
    1914:      	add	x1, x21, #0x1
    1918:      	sxtw	x21, w1
    191c:      	b	0x12a4 <_stogir.verify.integer-operations-target-structured+0x538>
    1920:      	brk	#0
    1924:      	b	0x1920 <_stogir.verify.integer-operations-target-structured+0xbb4>
    1928:      	mov	x1, #0x1                ; =1
    192c:      	b	0x12b8 <_stogir.verify.integer-operations-target-structured+0x54c>
    1930:      	add	x1, x21, #0x1
    1934:      	sxtw	x21, w1
    1938:      	b	0x131c <_stogir.verify.integer-operations-target-structured+0x5b0>
    193c:      	brk	#0
    1940:      	b	0x193c <_stogir.verify.integer-operations-target-structured+0xbd0>
    1944:      	mov	x1, #0x1                ; =1
    1948:      	b	0x1330 <_stogir.verify.integer-operations-target-structured+0x5c4>
    194c:      	add	x1, x21, #0x1
    1950:      	sxtw	x21, w1
    1954:      	b	0x1394 <_stogir.verify.integer-operations-target-structured+0x628>
    1958:      	brk	#0
    195c:      	b	0x1958 <_stogir.verify.integer-operations-target-structured+0xbec>
    1960:      	mov	x1, #0x1                ; =1
    1964:      	b	0x13a8 <_stogir.verify.integer-operations-target-structured+0x63c>
    1968:      	add	x1, x21, #0x1
    196c:      	sxtw	x21, w1
    1970:      	b	0x1410 <_stogir.verify.integer-operations-target-structured+0x6a4>
    1974:      	brk	#0
    1978:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xc08>
    197c:      	mov	x1, #0x1                ; =1
    1980:      	b	0x1424 <_stogir.verify.integer-operations-target-structured+0x6b8>
    1984:      	add	x1, x21, #0x1
    1988:      	sxtw	x21, w1
    198c:      	b	0x148c <_stogir.verify.integer-operations-target-structured+0x720>
    1990:      	brk	#0
    1994:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xc24>
    1998:      	add	x1, x21, #0x1
    199c:      	sxtw	x21, w1
    19a0:      	b	0x14f0 <_stogir.verify.integer-operations-target-structured+0x784>
    19a4:      	brk	#0
    19a8:      	b	0x19a4 <_stogir.verify.integer-operations-target-structured+0xc38>
    19ac:      	add	x16, sp, #0x20
    19b0:      	ldr	w1, [x16, #0x8]
    19b4:      	add	x8, sp, #0x1c0
    19b8:      	str	x0, [sp, #0x258]
    19bc:      	ldr	x0, [sp, #0x298]
    19c0:      	bl	0x19c0 <_stogir.verify.integer-operations-target-structured+0xc54>
		00000000000019c0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    19c4:      	add	x16, sp, #0x1c0
    19c8:      	ldr	w0, [x16]
    19cc:      	lsr	x16, x0, #0
    19d0:      	cmp	x16, #0x1
    19d4:      	b.eq	0x19f0 <_stogir.verify.integer-operations-target-structured+0xc84>
    19d8:      	b.lo	0x19e0 <_stogir.verify.integer-operations-target-structured+0xc74>
    19dc:      	b	0x19f4 <_stogir.verify.integer-operations-target-structured+0xc88>
    19e0:      	cmp	x16, #0x0
    19e4:      	b.eq	0x19ec <_stogir.verify.integer-operations-target-structured+0xc80>
    19e8:      	b	0x19f4 <_stogir.verify.integer-operations-target-structured+0xc88>
    19ec:      	b	0x19f8 <_stogir.verify.integer-operations-target-structured+0xc8c>
    19f0:      	b	0x1a04 <_stogir.verify.integer-operations-target-structured+0xc98>
    19f4:      	b	0x1a34 <_stogir.verify.integer-operations-target-structured+0xcc8>
    19f8:      	ldr	x19, [sp, #0x288]
    19fc:      	mov	x22, #0x14              ; =20
    1a00:      	b	0x152c <_stogir.verify.integer-operations-target-structured+0x7c0>
    1a04:      	add	x16, sp, #0x1c0
    1a08:      	ldr	x0, [x16, #0x8]
    1a0c:      	add	x16, sp, #0x20
    1a10:      	ldr	w1, [x16]
    1a14:      	ubfx	x0, x0, #0, #32
    1a18:      	ubfx	x1, x1, #8, #8
    1a1c:      	ubfx	x0, x0, #8, #8
    1a20:      	cmp	x0, x1
    1a24:      	b.eq	0x1a30 <_stogir.verify.integer-operations-target-structured+0xcc4>
    1a28:      	ldr	x19, [sp, #0x290]
    1a2c:      	mov	x22, #0x1a              ; =26
    1a30:      	b	0x1a00 <_stogir.verify.integer-operations-target-structured+0xc94>
    1a34:      	brk	#0
    1a38:      	b	0x1a34 <_stogir.verify.integer-operations-target-structured+0xcc8>
    1a3c:      	add	x1, x21, #0x1
    1a40:      	sxtw	x21, w1
    1a44:      	b	0x15bc <_stogir.verify.integer-operations-target-structured+0x850>
    1a48:      	brk	#0
    1a4c:      	b	0x1a48 <_stogir.verify.integer-operations-target-structured+0xcdc>
    1a50:      	mov	x1, #0x1                ; =1
    1a54:      	b	0x15cc <_stogir.verify.integer-operations-target-structured+0x860>
    1a58:      	mov	x1, #0x1                ; =1
    1a5c:      	b	0x1618 <_stogir.verify.integer-operations-target-structured+0x8ac>
    1a60:      	cmp	x26, #0x0
    1a64:      	b.eq	0x1a70 <_stogir.verify.integer-operations-target-structured+0xd04>
    1a68:      	mov	x1, #0x1                ; =1
    1a6c:      	b	0x1630 <_stogir.verify.integer-operations-target-structured+0x8c4>
    1a70:      	mov	x1, x28
    1a74:      	b	0x1a6c <_stogir.verify.integer-operations-target-structured+0xd00>
    1a78:      	movz	x1, #0x0, lsl #48
    1a7c:      	b	0x1630 <_stogir.verify.integer-operations-target-structured+0x8c4>
    1a80:      	movz	x1, #0x0, lsl #48
    1a84:      	b	0x1630 <_stogir.verify.integer-operations-target-structured+0x8c4>
    1a88:      	sxtw	x1, w1
    1a8c:      	cmp	x1, #0x0
    1a90:      	cset	w0, gt
    1a94:      	movz	x16, #0x0, lsl #48
    1a98:      	sub	x2, x16, x1
    1a9c:      	sub	x3, x2, #0x1
    1aa0:      	uxtb	w16, w0
    1aa4:      	cmp	w16, wzr
    1aa8:      	b.eq	0x1f48 <_stogir.verify.integer-operations-target-structured+0x11dc>
    1aac:      	ldr	x4, [sp, #0x298]
    1ab0:      	ldr	x2, [x4, #0x8]
    1ab4:      	cmp	x1, x2
    1ab8:      	b.ge	0x1f54 <_stogir.verify.integer-operations-target-structured+0x11e8>
    1abc:      	ldr	x5, [sp, #0x318]
    1ac0:      	ldr	x2, [x5, #0x8]
    1ac4:      	cmp	x1, x2
    1ac8:      	b.ge	0x1b3c <_stogir.verify.integer-operations-target-structured+0xdd0>
    1acc:      	ldr	x2, [x4, #0x78]
    1ad0:      	add	x2, x2, x1, lsl #2
    1ad4:      	ldr	w2, [x2]
    1ad8:      	sxtw	x2, w2
    1adc:      	cmp	x2, #0x0
    1ae0:      	cset	w2, ge
    1ae4:      	ubfx	x2, x2, #0, #8
    1ae8:      	ldr	x6, [sp, #0x310]
    1aec:      	ldr	x8, [sp, #0x308]
    1af0:      	cmp	x2, #0x0
    1af4:      	b.eq	0x1bb8 <_stogir.verify.integer-operations-target-structured+0xe4c>
    1af8:      	uxtb	w16, w0
    1afc:      	cmp	w16, wzr
    1b00:      	b.eq	0x1bac <_stogir.verify.integer-operations-target-structured+0xe40>
    1b04:      	ldr	x0, [x4]
    1b08:      	add	x0, x0, x1, lsl #4
    1b0c:      	cmp	x0, #0x0
    1b10:      	b.ne	0x1bc0 <_stogir.verify.integer-operations-target-structured+0xe54>
    1b14:      	str	x4, [sp, #0x298]
    1b18:      	str	x23, [sp, #0x340]
    1b1c:      	str	x25, [sp, #0x348]
    1b20:      	str	x27, [sp, #0x350]
    1b24:      	str	x5, [sp, #0x318]
    1b28:      	str	x6, [sp, #0x310]
    1b2c:      	str	x8, [sp, #0x308]
    1b30:      	ldr	x19, [sp, #0x2b0]
    1b34:      	mov	x22, #0x17              ; =23
    1b38:      	b	0x16b4 <_stogir.verify.integer-operations-target-structured+0x948>
    1b3c:      	movz	x2, #0x0, lsl #48
    1b40:      	b	0x1ae8 <_stogir.verify.integer-operations-target-structured+0xd7c>
    1b44:      	movz	x2, #0x0, lsl #48
    1b48:      	b	0x1ae8 <_stogir.verify.integer-operations-target-structured+0xd7c>
    1b4c:      	cmp	x1, #0x0
    1b50:      	b.ge	0x1f5c <_stogir.verify.integer-operations-target-structured+0x11f0>
    1b54:      	ldr	x6, [sp, #0x310]
    1b58:      	ldr	x7, [x6, #0x8]
    1b5c:      	ldr	x8, [sp, #0x308]
    1b60:      	ldr	x9, [x8, #0x8]
    1b64:      	cmp	x7, x9
    1b68:      	b.ne	0x1b9c <_stogir.verify.integer-operations-target-structured+0xe30>
    1b6c:      	cmp	x2, x7
    1b70:      	b.gt	0x1b94 <_stogir.verify.integer-operations-target-structured+0xe28>
    1b74:      	ldr	x2, [x4, #0x50]
    1b78:      	add	x2, x2, x3, lsl #2
    1b7c:      	ldr	w2, [x2]
    1b80:      	sxtw	x2, w2
    1b84:      	cmp	x2, #0x0
    1b88:      	cset	w2, gt
    1b8c:      	ubfx	x2, x2, #0, #8
    1b90:      	b	0x1af0 <_stogir.verify.integer-operations-target-structured+0xd84>
    1b94:      	movz	x2, #0x0, lsl #48
    1b98:      	b	0x1b90 <_stogir.verify.integer-operations-target-structured+0xe24>
    1b9c:      	movz	x2, #0x0, lsl #48
    1ba0:      	b	0x1b90 <_stogir.verify.integer-operations-target-structured+0xe24>
    1ba4:      	movz	x2, #0x0, lsl #48
    1ba8:      	b	0x1b90 <_stogir.verify.integer-operations-target-structured+0xe24>
    1bac:      	ldr	x0, [x4, #0x28]
    1bb0:      	add	x0, x0, x3, lsl #4
    1bb4:      	b	0x1b0c <_stogir.verify.integer-operations-target-structured+0xda0>
    1bb8:      	movz	x0, #0x0, lsl #48
    1bbc:      	b	0x1b0c <_stogir.verify.integer-operations-target-structured+0xda0>
    1bc0:      	ldr	w0, [x0]
    1bc4:      	add	x16, sp, #0x20
    1bc8:      	ldr	w1, [x16]
    1bcc:      	ubfx	x0, x0, #8, #8
    1bd0:      	orr	x2, x0, xzr
    1bd4:      	ubfx	x1, x1, #8, #8
    1bd8:      	cmp	x1, #0x6
    1bdc:      	b.ne	0x1d38 <_stogir.verify.integer-operations-target-structured+0xfcc>
    1be0:      	cmp	x2, #0x6
    1be4:      	b.ne	0x1d30 <_stogir.verify.integer-operations-target-structured+0xfc4>
    1be8:      	cmp	x24, #0x1a
    1bec:      	b.ne	0x1d20 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1bf0:      	mov	x1, #0x1                ; =1
    1bf4:      	cmp	x2, #0x1
    1bf8:      	cset	w3, ge
    1bfc:      	uxtb	w16, w3
    1c00:      	cmp	w16, wzr
    1c04:      	b.eq	0x1f68 <_stogir.verify.integer-operations-target-structured+0x11fc>
    1c08:      	cmp	x2, #0xb
    1c0c:      	cset	w7, le
    1c10:      	uxtb	w16, w7
    1c14:      	cmp	w16, wzr
    1c18:      	b.eq	0x1f90 <_stogir.verify.integer-operations-target-structured+0x1224>
    1c1c:      	cmp	x28, #0x0
    1c20:      	b.eq	0x1fb8 <_stogir.verify.integer-operations-target-structured+0x124c>
    1c24:      	ldr	w9, [sp, #0x300]
    1c28:      	str	x4, [sp, #0x298]
    1c2c:      	str	x5, [sp, #0x318]
    1c30:      	str	x6, [sp, #0x310]
    1c34:      	str	x8, [sp, #0x308]
    1c38:      	mov	w28, w7
    1c3c:      	str	x23, [sp, #0x340]
    1c40:      	mov	x23, x2
    1c44:      	str	x25, [sp, #0x348]
    1c48:      	mov	x25, x1
    1c4c:      	mov	w1, w0
    1c50:      	mov	w0, w9
    1c54:      	str	x27, [sp, #0x350]
    1c58:      	mov	w27, w3
    1c5c:      	bl	0x1c5c <_stogir.verify.integer-operations-target-structured+0xef0>
		0000000000001c5c:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1c60:      	cmp	x0, #0x0
    1c64:      	b.ne	0x1d40 <_stogir.verify.integer-operations-target-structured+0xfd4>
    1c68:      	ldr	x19, [sp, #0x2b8]
    1c6c:      	mov	x22, #0x1c              ; =28
    1c70:      	add	x16, sp, #0x20
    1c74:      	ldr	w0, [x16]
    1c78:      	cmp	x20, #0x0
    1c7c:      	b.eq	0x1dd8 <_stogir.verify.integer-operations-target-structured+0x106c>
    1c80:      	mov	x1, #0x1                ; =1
    1c84:      	ubfx	x0, x0, #8, #8
    1c88:      	sxtw	x1, w1
    1c8c:      	cmp	x0, x1
    1c90:      	b.eq	0x1c9c <_stogir.verify.integer-operations-target-structured+0xf30>
    1c94:      	ldr	x19, [sp, #0x2c8]
    1c98:      	mov	x22, #0x26              ; =38
    1c9c:      	cmp	x20, #0x0
    1ca0:      	b.eq	0x1ca8 <_stogir.verify.integer-operations-target-structured+0xf3c>
    1ca4:      	mov	x26, #0x1               ; =1
    1ca8:      	cmp	x26, #0x0
    1cac:      	b.eq	0x1d1c <_stogir.verify.integer-operations-target-structured+0xfb0>
    1cb0:      	add	x16, sp, #0x220
    1cb4:      	str	x16, [sp]
    1cb8:      	ldr	x0, [sp, #0x298]
    1cbc:      	ldr	w1, [sp, #0x2a8]
    1cc0:      	mov	x2, #0x2                ; =2
    1cc4:      	bl	0x1cc4 <_stogir.verify.integer-operations-target-structured+0xf58>
		0000000000001cc4:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1cc8:      	ldr	x16, [sp]
    1ccc:      	str	x0, [x16]
    1cd0:      	str	x1, [x16, #0x8]
    1cd4:      	add	x16, sp, #0x220
    1cd8:      	ldr	x0, [x16]
    1cdc:      	add	x16, sp, #0x220
    1ce0:      	ldr	x1, [x16, #0x8]
    1ce4:      	ubfx	x0, x0, #0, #32
    1ce8:      	lsr	x16, x0, #0
    1cec:      	cmp	x16, #0x1
    1cf0:      	b.eq	0x1d0c <_stogir.verify.integer-operations-target-structured+0xfa0>
    1cf4:      	b.lo	0x1cfc <_stogir.verify.integer-operations-target-structured+0xf90>
    1cf8:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xfa4>
    1cfc:      	cmp	x16, #0x0
    1d00:      	b.eq	0x1d08 <_stogir.verify.integer-operations-target-structured+0xf9c>
    1d04:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xfa4>
    1d08:      	b	0x1d14 <_stogir.verify.integer-operations-target-structured+0xfa8>
    1d0c:      	b	0x1de0 <_stogir.verify.integer-operations-target-structured+0x1074>
    1d10:      	b	0x1e34 <_stogir.verify.integer-operations-target-structured+0x10c8>
    1d14:      	ldr	x19, [sp, #0x2d0]
    1d18:      	mov	x22, #0x1d              ; =29
    1d1c:      	b	0x1b38 <_stogir.verify.integer-operations-target-structured+0xdcc>
    1d20:      	cmp	x24, #0x1b
    1d24:      	cset	w1, eq
    1d28:      	ubfx	x1, x1, #0, #8
    1d2c:      	b	0x1bf4 <_stogir.verify.integer-operations-target-structured+0xe88>
    1d30:      	movz	x1, #0x0, lsl #48
    1d34:      	b	0x1bf4 <_stogir.verify.integer-operations-target-structured+0xe88>
    1d38:      	movz	x1, #0x0, lsl #48
    1d3c:      	b	0x1bf4 <_stogir.verify.integer-operations-target-structured+0xe88>
    1d40:      	cmp	x26, #0x0
    1d44:      	b.eq	0x1c70 <_stogir.verify.integer-operations-target-structured+0xf04>
    1d48:      	cmp	x24, #0x3a
    1d4c:      	cset	w0, eq
    1d50:      	cmp	x24, #0x1a
    1d54:      	b.lt	0x1db0 <_stogir.verify.integer-operations-target-structured+0x1044>
    1d58:      	cmp	x24, #0x1e
    1d5c:      	b.gt	0x1db0 <_stogir.verify.integer-operations-target-structured+0x1044>
    1d60:      	uxtb	w16, w27
    1d64:      	cmp	w16, wzr
    1d68:      	b.eq	0x1c68 <_stogir.verify.integer-operations-target-structured+0xefc>
    1d6c:      	uxtb	w16, w28
    1d70:      	cmp	w16, wzr
    1d74:      	b.eq	0x1c68 <_stogir.verify.integer-operations-target-structured+0xefc>
    1d78:      	cmp	x23, #0x1
    1d7c:      	b.ne	0x1c70 <_stogir.verify.integer-operations-target-structured+0xf04>
    1d80:      	cmp	x24, #0x2e
    1d84:      	b.eq	0x1c70 <_stogir.verify.integer-operations-target-structured+0xf04>
    1d88:      	cmp	x24, #0x2f
    1d8c:      	b.eq	0x1c70 <_stogir.verify.integer-operations-target-structured+0xf04>
    1d90:      	cmp	x24, #0x30
    1d94:      	b.eq	0x1c70 <_stogir.verify.integer-operations-target-structured+0xf04>
    1d98:      	uxtb	w16, w0
    1d9c:      	cmp	w16, wzr
    1da0:      	b.ne	0x1c70 <_stogir.verify.integer-operations-target-structured+0xf04>
    1da4:      	cmp	x24, #0x3b
    1da8:      	b.ne	0x1c68 <_stogir.verify.integer-operations-target-structured+0xefc>
    1dac:      	b	0x1c70 <_stogir.verify.integer-operations-target-structured+0xf04>
    1db0:      	cmp	x24, #0x2e
    1db4:      	b.lt	0x1dc0 <_stogir.verify.integer-operations-target-structured+0x1054>
    1db8:      	cmp	x24, #0x35
    1dbc:      	b.le	0x1d60 <_stogir.verify.integer-operations-target-structured+0xff4>
    1dc0:      	uxtb	w16, w0
    1dc4:      	cmp	w16, wzr
    1dc8:      	b.ne	0x1d60 <_stogir.verify.integer-operations-target-structured+0xff4>
    1dcc:      	cmp	x24, #0x3b
    1dd0:      	b.eq	0x1d60 <_stogir.verify.integer-operations-target-structured+0xff4>
    1dd4:      	b	0x1c68 <_stogir.verify.integer-operations-target-structured+0xefc>
    1dd8:      	mov	x1, x23
    1ddc:      	b	0x1c84 <_stogir.verify.integer-operations-target-structured+0xf18>
    1de0:      	ldr	x0, [sp, #0x298]
    1de4:      	bl	0x1de4 <_stogir.verify.integer-operations-target-structured+0x1078>
		0000000000001de4:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1de8:      	cmp	x0, #0x0
    1dec:      	b.ne	0x1dfc <_stogir.verify.integer-operations-target-structured+0x1090>
    1df0:      	ldr	x19, [sp, #0x2d0]
    1df4:      	mov	x22, #0x1d              ; =29
    1df8:      	b	0x1d1c <_stogir.verify.integer-operations-target-structured+0xfb0>
    1dfc:      	ldr	w0, [x0]
    1e00:      	ubfx	x0, x0, #8, #8
    1e04:      	cmp	x23, x0
    1e08:      	b.eq	0x1e24 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1e0c:      	cmp	x25, #0x0
    1e10:      	b.eq	0x1e28 <_stogir.verify.integer-operations-target-structured+0x10bc>
    1e14:      	cmp	x0, #0x5
    1e18:      	b.eq	0x1e24 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1e1c:      	cmp	x0, #0xb
    1e20:      	b.ne	0x1e28 <_stogir.verify.integer-operations-target-structured+0x10bc>
    1e24:      	b	0x1df8 <_stogir.verify.integer-operations-target-structured+0x108c>
    1e28:      	ldr	x19, [sp, #0x280]
    1e2c:      	mov	x22, #0x1d              ; =29
    1e30:      	b	0x1e24 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1e34:      	brk	#0
    1e38:      	b	0x1e34 <_stogir.verify.integer-operations-target-structured+0x10c8>
    1e3c:      	brk	#0
    1e40:      	b	0x1e3c <_stogir.verify.integer-operations-target-structured+0x10d0>
    1e44:      	brk	#0
    1e48:      	b	0x1e44 <_stogir.verify.integer-operations-target-structured+0x10d8>
    1e4c:      	cmp	x22, #0x0
    1e50:      	b.ne	0x1ea8 <_stogir.verify.integer-operations-target-structured+0x113c>
    1e54:      	and	x19, x21, #0xffffffff
    1e58:      	movz	x0, #0x0, lsl #48
    1e5c:      	movz	x22, #0x0, lsl #48
    1e60:      	ldr	x1, [sp, #0x2d8]
    1e64:      	str	x0, [x1]
    1e68:      	str	x19, [x1, #0x8]
    1e6c:      	str	x22, [x1, #0x10]
    1e70:      	ldr	x19, [sp, #0x358]
    1e74:      	ldr	x20, [sp, #0x360]
    1e78:      	ldr	x21, [sp, #0x368]
    1e7c:      	ldr	x22, [sp, #0x370]
    1e80:      	ldr	x23, [sp, #0x378]
    1e84:      	ldr	x24, [sp, #0x380]
    1e88:      	ldr	x25, [sp, #0x388]
    1e8c:      	ldr	x26, [sp, #0x390]
    1e90:      	ldr	x27, [sp, #0x398]
    1e94:      	ldr	x28, [sp, #0x3a0]
    1e98:      	ldr	x29, [sp, #0x10]
    1e9c:      	ldr	x30, [sp, #0x18]
    1ea0:      	add	sp, sp, #0x3b0
    1ea4:      	ret
    1ea8:      	mov	x0, #0x1                ; =1
    1eac:      	b	0x1e60 <_stogir.verify.integer-operations-target-structured+0x10f4>
    1eb0:      	str	x8, [sp, #0x2d8]
    1eb4:      	b	0x1e4c <_stogir.verify.integer-operations-target-structured+0x10e0>
    1eb8:      	str	x8, [sp, #0x2d8]
    1ebc:      	b	0x1e4c <_stogir.verify.integer-operations-target-structured+0x10e0>
    1ec0:      	str	x0, [sp, #0x298]
    1ec4:      	b	0x1748 <_stogir.verify.integer-operations-target-structured+0x9dc>
    1ec8:      	ldr	x0, [sp, #0x328]
    1ecc:      	b	0x12a4 <_stogir.verify.integer-operations-target-structured+0x538>
    1ed0:      	str	x0, [sp, #0x328]
    1ed4:      	ldr	x0, [sp, #0x238]
    1ed8:      	b	0x131c <_stogir.verify.integer-operations-target-structured+0x5b0>
    1edc:      	str	x0, [sp, #0x238]
    1ee0:      	ldr	x0, [sp, #0x240]
    1ee4:      	b	0x1394 <_stogir.verify.integer-operations-target-structured+0x628>
    1ee8:      	str	x0, [sp, #0x240]
    1eec:      	ldr	x0, [sp, #0x248]
    1ef0:      	b	0x1410 <_stogir.verify.integer-operations-target-structured+0x6a4>
    1ef4:      	str	x0, [sp, #0x248]
    1ef8:      	ldr	x0, [sp, #0x250]
    1efc:      	b	0x148c <_stogir.verify.integer-operations-target-structured+0x720>
    1f00:      	str	x0, [sp, #0x250]
    1f04:      	ldr	x0, [sp, #0x258]
    1f08:      	b	0x14f0 <_stogir.verify.integer-operations-target-structured+0x784>
    1f0c:      	str	x0, [sp, #0x258]
    1f10:      	b	0x1534 <_stogir.verify.integer-operations-target-structured+0x7c8>
    1f14:      	str	x20, [sp, #0x338]
    1f18:      	mov	x20, x0
    1f1c:      	ldr	x0, [sp, #0x278]
    1f20:      	b	0x15bc <_stogir.verify.integer-operations-target-structured+0x850>
    1f24:      	ldr	x20, [sp, #0x2a0]
    1f28:      	b	0x1a80 <_stogir.verify.integer-operations-target-structured+0xd14>
    1f2c:      	ldr	x20, [sp, #0x2a0]
    1f30:      	b	0x1a78 <_stogir.verify.integer-operations-target-structured+0xd0c>
    1f34:      	str	x23, [sp, #0x340]
    1f38:      	str	x25, [sp, #0x348]
    1f3c:      	str	x0, [sp, #0x278]
    1f40:      	str	x27, [sp, #0x350]
    1f44:      	b	0x16bc <_stogir.verify.integer-operations-target-structured+0x950>
    1f48:      	ldr	x4, [sp, #0x298]
    1f4c:      	ldr	x5, [sp, #0x318]
    1f50:      	b	0x1b4c <_stogir.verify.integer-operations-target-structured+0xde0>
    1f54:      	ldr	x5, [sp, #0x318]
    1f58:      	b	0x1b44 <_stogir.verify.integer-operations-target-structured+0xdd8>
    1f5c:      	ldr	x6, [sp, #0x310]
    1f60:      	ldr	x8, [sp, #0x308]
    1f64:      	b	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xe38>
    1f68:      	str	x4, [sp, #0x298]
    1f6c:      	str	x23, [sp, #0x340]
    1f70:      	str	x25, [sp, #0x348]
    1f74:      	mov	x25, x1
    1f78:      	mov	x23, x2
    1f7c:      	str	x27, [sp, #0x350]
    1f80:      	str	x5, [sp, #0x318]
    1f84:      	str	x6, [sp, #0x310]
    1f88:      	str	x8, [sp, #0x308]
    1f8c:      	b	0x1c68 <_stogir.verify.integer-operations-target-structured+0xefc>
    1f90:      	str	x4, [sp, #0x298]
    1f94:      	str	x23, [sp, #0x340]
    1f98:      	str	x25, [sp, #0x348]
    1f9c:      	mov	x25, x1
    1fa0:      	mov	x23, x2
    1fa4:      	str	x27, [sp, #0x350]
    1fa8:      	str	x5, [sp, #0x318]
    1fac:      	str	x6, [sp, #0x310]
    1fb0:      	str	x8, [sp, #0x308]
    1fb4:      	b	0x1c68 <_stogir.verify.integer-operations-target-structured+0xefc>
    1fb8:      	str	x4, [sp, #0x298]
    1fbc:      	str	x23, [sp, #0x340]
    1fc0:      	str	x25, [sp, #0x348]
    1fc4:      	mov	x25, x1
    1fc8:      	mov	x23, x2
    1fcc:      	mov	w28, w7
    1fd0:      	str	x27, [sp, #0x350]
    1fd4:      	mov	w27, w3
    1fd8:      	str	x5, [sp, #0x318]
    1fdc:      	str	x6, [sp, #0x310]
    1fe0:      	str	x8, [sp, #0x308]
    1fe4:      	b	0x1d40 <_stogir.verify.integer-operations-target-structured+0xfd4>

0000000000001fe8 <_stogir.types.valid?>:
    1fe8:      	sxtw	x0, w0
    1fec:      	cmp	x0, #0x0
    1ff0:      	b.lt	0x2004 <_stogir.types.valid?+0x1c>
    1ff4:      	cmp	x0, #0xd
    1ff8:      	b.gt	0x2004 <_stogir.types.valid?+0x1c>
    1ffc:      	mov	x0, #0x1                ; =1
    2000:      	b	0x2040 <_stogir.types.valid?+0x58>
    2004:      	cmp	x0, #0xf
    2008:      	b.le	0x203c <_stogir.types.valid?+0x54>
    200c:      	cmp	x0, #0x80
    2010:      	b.ge	0x2034 <_stogir.types.valid?+0x4c>
    2014:      	and	x0, x0, #0xf
    2018:      	sxtw	x0, w0
    201c:      	cmp	x0, #0x1
    2020:      	b.lt	0x2044 <_stogir.types.valid?+0x5c>
    2024:      	cmp	x0, #0xd
    2028:      	cset	w0, le
    202c:      	ubfx	x0, x0, #0, #8
    2030:      	b	0x2048 <_stogir.types.valid?+0x60>
    2034:      	movz	x0, #0x0, lsl #48
    2038:      	b	0x2040 <_stogir.types.valid?+0x58>
    203c:      	movz	x0, #0x0, lsl #48
    2040:      	ret
    2044:      	movz	x0, #0x0, lsl #48
    2048:      	b	0x2038 <_stogir.types.valid?+0x50>

000000000000204c <_stogir.opcode.operand-slots>:
    204c:      	sxtw	x0, w0
    2050:      	cmp	x0, #0x0
    2054:      	b.lt	0x207c <_stogir.opcode.operand-slots+0x30>
    2058:      	cmp	x0, #0x83
    205c:      	b.ge	0x207c <_stogir.opcode.operand-slots+0x30>
    2060:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002060:  ARM64_RELOC_PAGE21	l_stogir.344
    2064:      	ldr	x16, [x16]
		0000000000002064:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    2068:      	orr	x1, x16, xzr
    206c:      	add	x0, x1, x0
    2070:      	ldrsb	w0, [x0]
    2074:      	sxtb	x0, w0
    2078:      	b	0x2080 <_stogir.opcode.operand-slots+0x34>
    207c:      	mov	x0, #-0x2               ; =-2
    2080:      	ret

0000000000002084 <_stogir.opcode.input-count>:
    2084:      	sxtw	x0, w0
    2088:      	cmp	x0, #0x0
    208c:      	b.lt	0x20b4 <_stogir.opcode.input-count+0x30>
    2090:      	cmp	x0, #0x83
    2094:      	b.ge	0x20b4 <_stogir.opcode.input-count+0x30>
    2098:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002098:  ARM64_RELOC_PAGE21	l_stogir.345
    209c:      	ldr	x16, [x16]
		000000000000209c:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    20a0:      	orr	x1, x16, xzr
    20a4:      	add	x0, x1, x0
    20a8:      	ldrsb	w0, [x0]
    20ac:      	sxtb	x0, w0
    20b0:      	b	0x20b8 <_stogir.opcode.input-count+0x34>
    20b4:      	mov	x0, #-0x2               ; =-2
    20b8:      	ret

00000000000020bc <_stogir.graph.operand>:
    20bc:      	sub	sp, sp, #0x10
    20c0:      	mov	x3, sp
    20c4:      	sxtw	x1, w1
    20c8:      	cmp	x1, #0x0
    20cc:      	b.le	0x2110 <_stogir.graph.operand+0x54>
    20d0:      	lsl	x4, x1, #2
    20d4:      	ldr	x5, [x0, #0x8]
    20d8:      	cmp	x1, x5
    20dc:      	b.ge	0x2144 <_stogir.graph.operand+0x88>
    20e0:      	add	x5, x0, #0x78
    20e4:      	ldr	x5, [x5, #0x8]
    20e8:      	cmp	x1, x5
    20ec:      	b.ge	0x213c <_stogir.graph.operand+0x80>
    20f0:      	ldr	x5, [x0, #0x78]
    20f4:      	add	x5, x4, x5
    20f8:      	ldr	w5, [x5]
    20fc:      	sxtw	x5, w5
    2100:      	cmp	x5, #0x0
    2104:      	cset	w5, ge
    2108:      	ubfx	x5, x5, #0, #8
    210c:      	b	0x2140 <_stogir.graph.operand+0x84>
    2110:      	movz	x1, #0x0, lsl #48
    2114:      	movz	x0, #0x0, lsl #48
    2118:      	str	x1, [x3]
    211c:      	str	x0, [x3, #0x8]
    2120:      	ldr	x0, [sp]
    2124:      	ldr	x1, [sp, #0x8]
    2128:      	add	sp, sp, #0x10
    212c:      	ret
    2130:      	movz	x1, #0x0, lsl #48
    2134:      	movz	x0, #0x0, lsl #48
    2138:      	b	0x2118 <_stogir.graph.operand+0x5c>
    213c:      	movz	x5, #0x0, lsl #48
    2140:      	b	0x2148 <_stogir.graph.operand+0x8c>
    2144:      	movz	x5, #0x0, lsl #48
    2148:      	cmp	x5, #0x0
    214c:      	b.eq	0x2110 <_stogir.graph.operand+0x54>
    2150:      	sxtw	x2, w2
    2154:      	cmp	x2, #0x1
    2158:      	b.lt	0x2130 <_stogir.graph.operand+0x74>
    215c:      	ldr	x5, [x0, #0x78]
    2160:      	add	x4, x4, x5
    2164:      	ldr	w4, [x4]
    2168:      	sxtw	x4, w4
    216c:      	cmp	x2, x4
    2170:      	b.gt	0x2130 <_stogir.graph.operand+0x74>
    2174:      	asr	x16, x2, #63
    2178:      	lsr	x16, x16, #62
    217c:      	add	x4, x2, x16
    2180:      	asr	x4, x4, #2
    2184:      	asr	x16, x2, #63
    2188:      	lsr	x16, x16, #62
    218c:      	add	x2, x2, x16
    2190:      	and	x2, x2, #0x3
    2194:      	sub	x2, x2, x16
    2198:      	ldr	x0, [x0]
    219c:      	add	x1, x4, x1
    21a0:      	add	x0, x0, x1, lsl #4
    21a4:      	add	x0, x0, x2, lsl #2
    21a8:      	ldr	w0, [x0]
    21ac:      	sxtw	x0, w0
    21b0:      	and	x0, x0, #0xffffffff
    21b4:      	mov	x1, #0x1                ; =1
    21b8:      	b	0x2138 <_stogir.graph.operand+0x7c>

00000000000021bc <_stogir.graph.borrow-node>:
    21bc:      	sxtw	x1, w1
    21c0:      	cmp	x1, #0x0
    21c4:      	cset	w2, gt
    21c8:      	movz	x16, #0x0, lsl #48
    21cc:      	sub	x3, x16, x1
    21d0:      	sub	x4, x3, #0x1
    21d4:      	uxtb	w16, w2
    21d8:      	cmp	w16, wzr
    21dc:      	b.eq	0x221c <_stogir.graph.borrow-node+0x60>
    21e0:      	ldr	x3, [x0, #0x8]
    21e4:      	cmp	x1, x3
    21e8:      	b.ge	0x226c <_stogir.graph.borrow-node+0xb0>
    21ec:      	add	x3, x0, #0x78
    21f0:      	ldr	x3, [x3, #0x8]
    21f4:      	cmp	x1, x3
    21f8:      	b.ge	0x22ac <_stogir.graph.borrow-node+0xf0>
    21fc:      	ldr	x3, [x0, #0x78]
    2200:      	add	x3, x3, x1, lsl #2
    2204:      	ldr	w3, [x3]
    2208:      	sxtw	x3, w3
    220c:      	cmp	x3, #0x0
    2210:      	cset	w3, ge
    2214:      	ubfx	x3, x3, #0, #8
    2218:      	b	0x22b0 <_stogir.graph.borrow-node+0xf4>
    221c:      	cmp	x1, #0x0
    2220:      	b.ge	0x2274 <_stogir.graph.borrow-node+0xb8>
    2224:      	add	x5, x0, #0x28
    2228:      	add	x6, x0, #0x50
    222c:      	ldr	x5, [x5, #0x8]
    2230:      	ldr	x6, [x6, #0x8]
    2234:      	cmp	x5, x6
    2238:      	b.ne	0x2264 <_stogir.graph.borrow-node+0xa8>
    223c:      	cmp	x3, x5
    2240:      	b.gt	0x22b4 <_stogir.graph.borrow-node+0xf8>
    2244:      	ldr	x3, [x0, #0x50]
    2248:      	add	x3, x3, x4, lsl #2
    224c:      	ldr	w3, [x3]
    2250:      	sxtw	x3, w3
    2254:      	cmp	x3, #0x0
    2258:      	cset	w3, gt
    225c:      	ubfx	x3, x3, #0, #8
    2260:      	b	0x22b8 <_stogir.graph.borrow-node+0xfc>
    2264:      	movz	x3, #0x0, lsl #48
    2268:      	b	0x2278 <_stogir.graph.borrow-node+0xbc>
    226c:      	movz	x3, #0x0, lsl #48
    2270:      	b	0x2278 <_stogir.graph.borrow-node+0xbc>
    2274:      	movz	x3, #0x0, lsl #48
    2278:      	cmp	x3, #0x0
    227c:      	b.eq	0x22a4 <_stogir.graph.borrow-node+0xe8>
    2280:      	uxtb	w16, w2
    2284:      	cmp	w16, wzr
    2288:      	b.eq	0x2298 <_stogir.graph.borrow-node+0xdc>
    228c:      	ldr	x0, [x0]
    2290:      	add	x0, x0, x1, lsl #4
    2294:      	b	0x22a0 <_stogir.graph.borrow-node+0xe4>
    2298:      	ldr	x0, [x0, #0x28]
    229c:      	add	x0, x0, x4, lsl #4
    22a0:      	b	0x22a8 <_stogir.graph.borrow-node+0xec>
    22a4:      	movz	x0, #0x0, lsl #48
    22a8:      	ret
    22ac:      	movz	x3, #0x0, lsl #48
    22b0:      	b	0x2270 <_stogir.graph.borrow-node+0xb4>
    22b4:      	movz	x3, #0x0, lsl #48
    22b8:      	b	0x2268 <_stogir.graph.borrow-node+0xac>

00000000000022bc <_stogir.verify.classifications>:
    22bc:      	sub	sp, sp, #0x70
    22c0:      	str	x29, [sp]
    22c4:      	str	x30, [sp, #0x8]
    22c8:      	mov	x29, sp
    22cc:      	str	x19, [sp, #0x20]
    22d0:      	str	x20, [sp, #0x28]
    22d4:      	str	x21, [sp, #0x30]
    22d8:      	str	x22, [sp, #0x38]
    22dc:      	str	x23, [sp, #0x40]
    22e0:      	str	x24, [sp, #0x48]
    22e4:      	str	x25, [sp, #0x50]
    22e8:      	str	x26, [sp, #0x58]
    22ec:      	str	x27, [sp, #0x60]
    22f0:      	str	x28, [sp, #0x68]
    22f4:      	ldr	w4, [x2]
    22f8:      	uxtb	w19, w4
    22fc:      	orr	x5, x19, xzr
    2300:      	orr	w20, w5, wzr
    2304:      	ubfx	x21, x4, #8, #8
    2308:      	orr	x4, x21, xzr
    230c:      	mov	x22, x0
    2310:      	mov	w0, w4
    2314:      	mov	w23, w1
    2318:      	mov	x24, x2
    231c:      	mov	w25, w3
    2320:      	bl	0x2320 <_stogir.verify.classifications+0x64>
		0000000000002320:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2324:      	fmov	d31, x0
    2328:      	mov	w0, w20
    232c:      	fmov	x20, d31
    2330:      	bl	0x2330 <_stogir.verify.classifications+0x74>
		0000000000002330:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2334:      	cmp	x0, #0x0
    2338:      	b.eq	0x2354 <_stogir.verify.classifications+0x98>
    233c:      	cmp	x20, #0x0
    2340:      	cset	w0, ne
    2344:      	uxtb	w16, w0
    2348:      	cmp	w16, wzr
    234c:      	cset	x26, eq
    2350:      	b	0x2358 <_stogir.verify.classifications+0x9c>
    2354:      	movz	x26, #0x0, lsl #48
    2358:      	cmp	x26, #0x0
    235c:      	cset	w27, ne
    2360:      	uxtb	w16, w27
    2364:      	cmp	w16, wzr
    2368:      	b.eq	0x2398 <_stogir.verify.classifications+0xdc>
    236c:      	ldr	w0, [x24, #0x4]
    2370:      	mov	w1, w0
    2374:      	mov	x0, x22
    2378:      	bl	0x2378 <_stogir.verify.classifications+0xbc>
		0000000000002378:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    237c:      	cmp	x0, #0x0
    2380:      	b.ne	0x238c <_stogir.verify.classifications+0xd0>
    2384:      	movn	x0, #0x0, lsl #48
    2388:      	b	0x2394 <_stogir.verify.classifications+0xd8>
    238c:      	ldr	w0, [x0]
    2390:      	ubfx	x0, x0, #8, #8
    2394:      	b	0x239c <_stogir.verify.classifications+0xe0>
    2398:      	movn	x0, #0x0, lsl #48
    239c:      	sxtw	x28, w0
    23a0:      	cmp	x26, #0x0
    23a4:      	b.eq	0x23d4 <_stogir.verify.classifications+0x118>
    23a8:      	bl	0x23a8 <_stogir.verify.classifications+0xec>
		00000000000023a8:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    23ac:      	cmp	x0, #0x0
    23b0:      	b.eq	0x27e8 <_stogir.verify.classifications+0x52c>
    23b4:      	movz	x0, #0x0, lsl #48
    23b8:      	b	0x23c0 <_stogir.verify.classifications+0x104>
    23bc:      	mov	x0, #0x1                ; =1
    23c0:      	b	0x23d8 <_stogir.verify.classifications+0x11c>
    23c4:      	movz	x19, #0x0, lsl #48
    23c8:      	b	0x2454 <_stogir.verify.classifications+0x198>
    23cc:      	movz	x20, #0x0, lsl #48
    23d0:      	b	0x245c <_stogir.verify.classifications+0x1a0>
    23d4:      	movz	x0, #0x0, lsl #48
    23d8:      	sxtw	x25, w25
    23dc:      	cmp	x28, #0xf
    23e0:      	cset	w1, gt
    23e4:      	cmp	x28, #0x80
    23e8:      	cset	w2, lt
    23ec:      	and	x3, x28, #0xf
    23f0:      	cmp	x19, #0x83
    23f4:      	cset	w4, lt
    23f8:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		00000000000023f8:  ARM64_RELOC_PAGE21	l_stogir.346
    23fc:      	ldr	x16, [x16]
		00000000000023fc:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    2400:      	orr	x5, x16, xzr
    2404:      	add	x6, x22, #0x78
    2408:      	add	x7, x22, #0x28
    240c:      	add	x8, x22, #0x50
    2410:      	sxtw	x23, w23
    2414:      	add	x9, x22, #0x78
    2418:      	add	x5, x5, x19, lsl #2
    241c:      	cmp	x23, #0x0
    2420:      	cset	w10, le
    2424:      	lsl	x11, x23, #2
    2428:      	sxtw	x3, w3
    242c:      	cmp	x3, #0x1
    2430:      	cset	w12, ge
    2434:      	cmp	x3, #0xd
    2438:      	cset	w3, le
    243c:      	ubfx	x3, x3, #0, #8
    2440:      	mov	x13, #0x1               ; =1
    2444:      	b	0x2504 <_stogir.verify.classifications+0x248>
    2448:      	movz	x19, #0x0, lsl #48
    244c:      	b	0x2488 <_stogir.verify.classifications+0x1cc>
    2450:      	movz	x19, #0x0, lsl #48
    2454:      	b	0x2490 <_stogir.verify.classifications+0x1d4>
    2458:      	movz	x20, #0x0, lsl #48
    245c:      	b	0x24fc <_stogir.verify.classifications+0x240>
    2460:      	sub	x19, x14, #0x1
    2464:      	sxtw	x19, w19
    2468:      	lsl	x19, x19, #2
    246c:      	ubfx	x19, x19, #0, #32
    2470:      	lsr	x15, x15, x19
    2474:      	ubfx	x15, x15, #0, #32
    2478:      	and	x15, x15, #0xf
    247c:      	ubfx	x15, x15, #0, #32
    2480:      	b	0x2548 <_stogir.verify.classifications+0x28c>
    2484:      	movz	x19, #0x0, lsl #48
    2488:      	b	0x2490 <_stogir.verify.classifications+0x1d4>
    248c:      	movz	x19, #0x0, lsl #48
    2490:      	cmp	x19, #0x0
    2494:      	b.eq	0x24bc <_stogir.verify.classifications+0x200>
    2498:      	uxtb	w16, w15
    249c:      	cmp	w16, wzr
    24a0:      	b.eq	0x24b0 <_stogir.verify.classifications+0x1f4>
    24a4:      	ldr	x15, [x22]
    24a8:      	add	x14, x15, x14, lsl #4
    24ac:      	b	0x24b8 <_stogir.verify.classifications+0x1fc>
    24b0:      	ldr	x14, [x22, #0x28]
    24b4:      	add	x14, x14, x21, lsl #4
    24b8:      	b	0x24c0 <_stogir.verify.classifications+0x204>
    24bc:      	movz	x14, #0x0, lsl #48
    24c0:      	cmp	x14, #0x0
    24c4:      	b.eq	0x24fc <_stogir.verify.classifications+0x240>
    24c8:      	ldr	w14, [x14]
    24cc:      	ubfx	x14, x14, #8, #8
    24d0:      	cmp	x14, #0xf
    24d4:      	b.le	0x24fc <_stogir.verify.classifications+0x240>
    24d8:      	cmp	x14, #0x80
    24dc:      	b.ge	0x24fc <_stogir.verify.classifications+0x240>
    24e0:      	and	x14, x14, #0xf
    24e4:      	sxtw	x14, w14
    24e8:      	cmp	x14, #0x1
    24ec:      	b.lt	0x24fc <_stogir.verify.classifications+0x240>
    24f0:      	cmp	x14, #0xd
    24f4:      	b.gt	0x24fc <_stogir.verify.classifications+0x240>
    24f8:      	mov	x20, #0x1               ; =1
    24fc:      	add	x13, x13, #0x1
    2500:      	sxtw	x13, w13
    2504:      	cmp	x20, #0x0
    2508:      	b.ne	0x2690 <_stogir.verify.classifications+0x3d4>
    250c:      	cmp	x13, x25
    2510:      	b.gt	0x2690 <_stogir.verify.classifications+0x3d4>
    2514:      	orr	w14, w13, wzr
    2518:      	sxtw	x14, w14
    251c:      	uxtb	w16, w4
    2520:      	cmp	w16, wzr
    2524:      	b.eq	0x254c <_stogir.verify.classifications+0x290>
    2528:      	ldr	w15, [x5]
    252c:      	cmp	x14, #0x0
    2530:      	b.le	0x2544 <_stogir.verify.classifications+0x288>
    2534:      	cmp	x14, #0x4
    2538:      	b.le	0x2460 <_stogir.verify.classifications+0x1a4>
    253c:      	mov	x19, #0x4               ; =4
    2540:      	b	0x2468 <_stogir.verify.classifications+0x1ac>
    2544:      	movz	x15, #0x0, lsl #48
    2548:      	b	0x2550 <_stogir.verify.classifications+0x294>
    254c:      	movz	x15, #0x0, lsl #48
    2550:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002550:  ARM64_RELOC_PAGE21	l_stogir.347
    2554:      	ldr	x16, [x16]
		0000000000002554:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    2558:      	ldr	w19, [x16]
    255c:      	ubfx	x15, x15, #0, #32
    2560:      	cmp	x15, x19
    2564:      	b.eq	0x257c <_stogir.verify.classifications+0x2c0>
    2568:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002568:  ARM64_RELOC_PAGE21	l_stogir.348
    256c:      	ldr	x16, [x16]
		000000000000256c:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    2570:      	ldr	w19, [x16]
    2574:      	cmp	x15, x19
    2578:      	b.ne	0x24fc <_stogir.verify.classifications+0x240>
    257c:      	cmp	x13, #0x1
    2580:      	b.ne	0x25bc <_stogir.verify.classifications+0x300>
    2584:      	uxtb	w16, w27
    2588:      	cmp	w16, wzr
    258c:      	b.eq	0x25bc <_stogir.verify.classifications+0x300>
    2590:      	uxtb	w16, w1
    2594:      	cmp	w16, wzr
    2598:      	b.eq	0x2458 <_stogir.verify.classifications+0x19c>
    259c:      	uxtb	w16, w2
    25a0:      	cmp	w16, wzr
    25a4:      	b.eq	0x23cc <_stogir.verify.classifications+0x110>
    25a8:      	uxtb	w16, w12
    25ac:      	cmp	w16, wzr
    25b0:      	b.eq	0x2798 <_stogir.verify.classifications+0x4dc>
    25b4:      	mov	x20, x3
    25b8:      	b	0x279c <_stogir.verify.classifications+0x4e0>
    25bc:      	cmp	x13, #0x1
    25c0:      	b.ne	0x2628 <_stogir.verify.classifications+0x36c>
    25c4:      	ldr	w14, [x24, #0x4]
    25c8:      	sxtw	x14, w14
    25cc:      	sxtw	x14, w14
    25d0:      	cmp	x14, #0x0
    25d4:      	cset	w15, gt
    25d8:      	movz	x16, #0x0, lsl #48
    25dc:      	sub	x19, x16, x14
    25e0:      	sub	x21, x19, #0x1
    25e4:      	uxtb	w16, w15
    25e8:      	cmp	w16, wzr
    25ec:      	b.eq	0x263c <_stogir.verify.classifications+0x380>
    25f0:      	ldr	x19, [x22, #0x8]
    25f4:      	cmp	x14, x19
    25f8:      	b.ge	0x2484 <_stogir.verify.classifications+0x1c8>
    25fc:      	ldr	x19, [x6, #0x8]
    2600:      	cmp	x14, x19
    2604:      	b.ge	0x2448 <_stogir.verify.classifications+0x18c>
    2608:      	ldr	x19, [x22, #0x78]
    260c:      	add	x19, x19, x14, lsl #2
    2610:      	ldr	w19, [x19]
    2614:      	sxtw	x19, w19
    2618:      	cmp	x19, #0x0
    261c:      	cset	w19, ge
    2620:      	ubfx	x19, x19, #0, #8
    2624:      	b	0x244c <_stogir.verify.classifications+0x190>
    2628:      	cmp	x13, #0x2
    262c:      	b.ne	0x267c <_stogir.verify.classifications+0x3c0>
    2630:      	ldr	w14, [x24, #0x8]
    2634:      	sxtw	x14, w14
    2638:      	b	0x25cc <_stogir.verify.classifications+0x310>
    263c:      	cmp	x14, #0x0
    2640:      	b.ge	0x248c <_stogir.verify.classifications+0x1d0>
    2644:      	ldr	x26, [x7, #0x8]
    2648:      	ldr	x28, [x8, #0x8]
    264c:      	cmp	x26, x28
    2650:      	b.ne	0x2450 <_stogir.verify.classifications+0x194>
    2654:      	cmp	x19, x26
    2658:      	b.gt	0x23c4 <_stogir.verify.classifications+0x108>
    265c:      	ldr	x19, [x22, #0x50]
    2660:      	add	x19, x19, x21, lsl #2
    2664:      	ldr	w19, [x19]
    2668:      	sxtw	x19, w19
    266c:      	cmp	x19, #0x0
    2670:      	cset	w19, gt
    2674:      	ubfx	x19, x19, #0, #8
    2678:      	b	0x23c8 <_stogir.verify.classifications+0x10c>
    267c:      	cmp	x13, #0x3
    2680:      	b.ne	0x26f4 <_stogir.verify.classifications+0x438>
    2684:      	ldr	w14, [x24, #0xc]
    2688:      	sxtw	x14, w14
    268c:      	b	0x2638 <_stogir.verify.classifications+0x37c>
    2690:      	uxtb	w20, w20
    2694:      	uxtb	w0, w0
    2698:      	add	x16, sp, #0x10
    269c:      	movz	w17, #0x0, lsl #16
    26a0:      	strh	w17, [x16]
    26a4:      	add	x16, sp, #0x10
    26a8:      	strb	w20, [x16]
    26ac:      	add	x16, sp, #0x10
    26b0:      	strb	w0, [x16, #0x1]
    26b4:      	add	x16, sp, #0x10
    26b8:      	ldrh	w0, [x16]
    26bc:      	ldr	x19, [sp, #0x20]
    26c0:      	ldr	x20, [sp, #0x28]
    26c4:      	ldr	x21, [sp, #0x30]
    26c8:      	ldr	x22, [sp, #0x38]
    26cc:      	ldr	x23, [sp, #0x40]
    26d0:      	ldr	x24, [sp, #0x48]
    26d4:      	ldr	x25, [sp, #0x50]
    26d8:      	ldr	x26, [sp, #0x58]
    26dc:      	ldr	x27, [sp, #0x60]
    26e0:      	ldr	x28, [sp, #0x68]
    26e4:      	ldr	x29, [sp]
    26e8:      	ldr	x30, [sp, #0x8]
    26ec:      	add	sp, sp, #0x70
    26f0:      	ret
    26f4:      	uxtb	w16, w10
    26f8:      	cmp	w16, wzr
    26fc:      	b.ne	0x27a8 <_stogir.verify.classifications+0x4ec>
    2700:      	ldr	x15, [x22, #0x8]
    2704:      	cmp	x23, x15
    2708:      	b.ge	0x27a8 <_stogir.verify.classifications+0x4ec>
    270c:      	ldr	x15, [x9, #0x8]
    2710:      	cmp	x23, x15
    2714:      	b.ge	0x27a8 <_stogir.verify.classifications+0x4ec>
    2718:      	ldr	x15, [x22, #0x78]
    271c:      	add	x15, x11, x15
    2720:      	ldr	w15, [x15]
    2724:      	sxtw	x15, w15
    2728:      	cmp	x15, #0x0
    272c:      	b.lt	0x27a8 <_stogir.verify.classifications+0x4ec>
    2730:      	cmp	x14, #0x1
    2734:      	b.lt	0x2828 <_stogir.verify.classifications+0x56c>
    2738:      	ldr	x15, [x22, #0x78]
    273c:      	add	x15, x11, x15
    2740:      	ldr	w15, [x15]
    2744:      	sxtw	x15, w15
    2748:      	cmp	x14, x15
    274c:      	b.gt	0x2828 <_stogir.verify.classifications+0x56c>
    2750:      	ldr	x15, [x22]
    2754:      	asr	x16, x14, #63
    2758:      	lsr	x16, x16, #62
    275c:      	add	x19, x14, x16
    2760:      	asr	x19, x19, #2
    2764:      	asr	x16, x14, #63
    2768:      	lsr	x16, x16, #62
    276c:      	add	x14, x14, x16
    2770:      	and	x14, x14, #0x3
    2774:      	sub	x14, x14, x16
    2778:      	add	x19, x19, x23
    277c:      	add	x15, x15, x19, lsl #4
    2780:      	add	x14, x15, x14, lsl #2
    2784:      	ldr	w14, [x14]
    2788:      	sxtw	x14, w14
    278c:      	and	x14, x14, #0xffffffff
    2790:      	mov	x15, #0x1               ; =1
    2794:      	b	0x2830 <_stogir.verify.classifications+0x574>
    2798:      	movz	x20, #0x0, lsl #48
    279c:      	b	0x23d0 <_stogir.verify.classifications+0x114>
    27a0:      	sxtw	x14, w14
    27a4:      	b	0x268c <_stogir.verify.classifications+0x3d0>
    27a8:      	movz	x15, #0x0, lsl #48
    27ac:      	movz	x14, #0x0, lsl #48
    27b0:      	ubfx	x15, x15, #0, #32
    27b4:      	lsr	x16, x15, #0
    27b8:      	cmp	x16, #0x1
    27bc:      	b.eq	0x27d8 <_stogir.verify.classifications+0x51c>
    27c0:      	b.lo	0x27c8 <_stogir.verify.classifications+0x50c>
    27c4:      	b	0x27dc <_stogir.verify.classifications+0x520>
    27c8:      	cmp	x16, #0x0
    27cc:      	b.eq	0x27d4 <_stogir.verify.classifications+0x518>
    27d0:      	b	0x27dc <_stogir.verify.classifications+0x520>
    27d4:      	b	0x27e0 <_stogir.verify.classifications+0x524>
    27d8:      	b	0x27a0 <_stogir.verify.classifications+0x4e4>
    27dc:      	b	0x2844 <_stogir.verify.classifications+0x588>
    27e0:      	movz	x14, #0x0, lsl #48
    27e4:      	b	0x27a4 <_stogir.verify.classifications+0x4e8>
    27e8:      	cmp	x19, #0x18
    27ec:      	b.ne	0x27f8 <_stogir.verify.classifications+0x53c>
    27f0:      	mov	x0, #0x1                ; =1
    27f4:      	b	0x23c0 <_stogir.verify.classifications+0x104>
    27f8:      	cmp	x19, #0x19
    27fc:      	b.ne	0x2808 <_stogir.verify.classifications+0x54c>
    2800:      	mov	x0, #0x1                ; =1
    2804:      	b	0x23c0 <_stogir.verify.classifications+0x104>
    2808:      	cmp	x21, #0xc
    280c:      	b.eq	0x23bc <_stogir.verify.classifications+0x100>
    2810:      	cmp	x21, #0xd
    2814:      	b.eq	0x23bc <_stogir.verify.classifications+0x100>
    2818:      	cmp	x28, #0xc
    281c:      	b.ne	0x2834 <_stogir.verify.classifications+0x578>
    2820:      	mov	x0, #0x1                ; =1
    2824:      	b	0x2840 <_stogir.verify.classifications+0x584>
    2828:      	movz	x15, #0x0, lsl #48
    282c:      	movz	x14, #0x0, lsl #48
    2830:      	b	0x27b0 <_stogir.verify.classifications+0x4f4>
    2834:      	cmp	x28, #0xd
    2838:      	cset	w0, eq
    283c:      	ubfx	x0, x0, #0, #8
    2840:      	b	0x23c0 <_stogir.verify.classifications+0x104>
    2844:      	brk	#0
    2848:      	b	0x2844 <_stogir.verify.classifications+0x588>
    284c:      	udf	#0x0

0000000000002850 <_stogir.vector.validate>:
    2850:      	sub	sp, sp, #0x210
    2854:      	str	x29, [sp]
    2858:      	str	x30, [sp, #0x8]
    285c:      	mov	x29, sp
    2860:      	str	x19, [sp, #0x1c0]
    2864:      	str	x20, [sp, #0x1c8]
    2868:      	str	x21, [sp, #0x1d0]
    286c:      	str	x22, [sp, #0x1d8]
    2870:      	str	x23, [sp, #0x1e0]
    2874:      	str	x24, [sp, #0x1e8]
    2878:      	str	x25, [sp, #0x1f0]
    287c:      	str	x26, [sp, #0x1f8]
    2880:      	str	x27, [sp, #0x200]
    2884:      	str	x28, [sp, #0x208]
    2888:      	orr	w19, w1, wzr
    288c:      	mov	x20, x8
    2890:      	add	x8, sp, #0x10
    2894:      	mov	x21, x0
    2898:      	mov	w22, w1
    289c:      	mov	w1, w19
    28a0:      	mov	w23, w2
    28a4:      	bl	0x28a4 <_stogir.vector.validate+0x54>
		00000000000028a4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    28a8:      	add	x16, sp, #0x10
    28ac:      	ldr	w0, [x16]
    28b0:      	lsr	x16, x0, #0
    28b4:      	cmp	x16, #0x1
    28b8:      	b.eq	0x28d4 <_stogir.vector.validate+0x84>
    28bc:      	b.lo	0x28c4 <_stogir.vector.validate+0x74>
    28c0:      	b	0x28d8 <_stogir.vector.validate+0x88>
    28c4:      	cmp	x16, #0x0
    28c8:      	b.eq	0x28d0 <_stogir.vector.validate+0x80>
    28cc:      	b	0x28d8 <_stogir.vector.validate+0x88>
    28d0:      	b	0x28dc <_stogir.vector.validate+0x8c>
    28d4:      	b	0x296c <_stogir.vector.validate+0x11c>
    28d8:      	b	0x2b80 <_stogir.vector.validate+0x330>
    28dc:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		00000000000028dc:  ARM64_RELOC_PAGE21	l_stogir.349
    28e0:      	ldr	x16, [x16]
		00000000000028e0:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    28e4:      	orr	x19, x16, xzr
    28e8:      	str	x20, [sp, #0x1a8]
    28ec:      	mov	x0, #0x1                ; =1
    28f0:      	mov	x25, #0x1a              ; =26
    28f4:      	b	0x2924 <_stogir.vector.validate+0xd4>
    28f8:      	add	x8, sp, #0x70
    28fc:      	mov	x0, x21
    2900:      	ldr	w1, [sp, #0x1a0]
    2904:      	mov	w2, w23
    2908:      	bl	0x2908 <_stogir.vector.validate+0xb8>
		0000000000002908:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    290c:      	add	x16, sp, #0x70
    2910:      	ldr	x0, [x16]
    2914:      	add	x16, sp, #0x70
    2918:      	ldr	x19, [x16, #0x8]
    291c:      	add	x16, sp, #0x70
    2920:      	ldr	x25, [x16, #0x10]
    2924:      	ldr	x1, [sp, #0x1a8]
    2928:      	str	x0, [x1]
    292c:      	str	x19, [x1, #0x8]
    2930:      	str	x25, [x1, #0x10]
    2934:      	ldr	x19, [sp, #0x1c0]
    2938:      	ldr	x20, [sp, #0x1c8]
    293c:      	ldr	x21, [sp, #0x1d0]
    2940:      	ldr	x22, [sp, #0x1d8]
    2944:      	ldr	x23, [sp, #0x1e0]
    2948:      	ldr	x24, [sp, #0x1e8]
    294c:      	ldr	x25, [sp, #0x1f0]
    2950:      	ldr	x26, [sp, #0x1f8]
    2954:      	ldr	x27, [sp, #0x200]
    2958:      	ldr	x28, [sp, #0x208]
    295c:      	ldr	x29, [sp]
    2960:      	ldr	x30, [sp, #0x8]
    2964:      	add	sp, sp, #0x210
    2968:      	ret
    296c:      	sxtw	x22, w22
    2970:      	add	x16, sp, #0x10
    2974:      	orr	x0, x16, xzr
    2978:      	cmp	x22, #0x0
    297c:      	cset	w24, le
    2980:      	add	x0, x0, #0x8
    2984:      	add	x16, sp, #0x10
    2988:      	ldr	x25, [x16, #0x8]
    298c:      	add	x16, sp, #0x40
    2990:      	str	x25, [x16]
    2994:      	ldr	x0, [x0, #0x8]
    2998:      	add	x16, sp, #0x40
    299c:      	str	x0, [x16, #0x8]
    29a0:      	uxtb	w16, w24
    29a4:      	cmp	w16, wzr
    29a8:      	b.eq	0x29c8 <_stogir.vector.validate+0x178>
    29ac:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		00000000000029ac:  ARM64_RELOC_PAGE21	l_stogir.350
    29b0:      	ldr	x16, [x16]
		00000000000029b0:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    29b4:      	orr	x19, x16, xzr
    29b8:      	str	x20, [sp, #0x1a8]
    29bc:      	mov	x0, #0x1                ; =1
    29c0:      	mov	x25, #0x3b              ; =59
    29c4:      	b	0x2924 <_stogir.vector.validate+0xd4>
    29c8:      	lsl	x26, x22, #2
    29cc:      	uxtb	w0, w25
    29d0:      	orr	x27, x0, xzr
    29d4:      	ldr	x0, [x21, #0x78]
    29d8:      	cmp	x27, #0x44
    29dc:      	cset	w1, eq
    29e0:      	add	x0, x0, x22, lsl #2
    29e4:      	ldr	w28, [x0]
    29e8:      	cmp	x27, #0x24
    29ec:      	b.ne	0x2a30 <_stogir.vector.validate+0x1e0>
    29f0:      	str	x20, [sp, #0x1a8]
    29f4:      	str	w19, [sp, #0x1a0]
    29f8:      	uxtb	w16, w1
    29fc:      	cmp	w16, wzr
    2a00:      	b.eq	0x28f8 <_stogir.vector.validate+0xa8>
    2a04:      	add	x8, sp, #0x50
    2a08:      	mov	x0, x21
    2a0c:      	ldr	w1, [sp, #0x1a0]
    2a10:      	bl	0x2a10 <_stogir.vector.validate+0x1c0>
		0000000000002a10:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    2a14:      	add	x16, sp, #0x50
    2a18:      	ldr	x0, [x16]
    2a1c:      	add	x16, sp, #0x50
    2a20:      	ldr	x19, [x16, #0x8]
    2a24:      	add	x16, sp, #0x50
    2a28:      	ldr	x25, [x16, #0x10]
    2a2c:      	b	0x2924 <_stogir.vector.validate+0xd4>
    2a30:      	uxtb	w16, w1
    2a34:      	cmp	w16, wzr
    2a38:      	b.ne	0x3268 <_stogir.vector.validate+0xa18>
    2a3c:      	cmp	x27, #0x3c
    2a40:      	b.ne	0x2af4 <_stogir.vector.validate+0x2a4>
    2a44:      	add	x8, sp, #0x90
    2a48:      	mov	x0, x21
    2a4c:      	mov	w1, w19
    2a50:      	bl	0x2a50 <_stogir.vector.validate+0x200>
		0000000000002a50:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    2a54:      	add	x16, sp, #0x90
    2a58:      	ldr	x0, [x16]
    2a5c:      	add	x16, sp, #0x90
    2a60:      	ldr	x19, [x16, #0x8]
    2a64:      	add	x16, sp, #0x90
    2a68:      	ldr	x25, [x16, #0x10]
    2a6c:      	str	x20, [sp, #0x1a8]
    2a70:      	b	0x2af0 <_stogir.vector.validate+0x2a0>
    2a74:      	cmp	x27, #0x41
    2a78:      	cset	w0, eq
    2a7c:      	cmp	x27, #0x48
    2a80:      	cset	w1, eq
    2a84:      	cmp	x27, #0x55
    2a88:      	cset	w2, ge
    2a8c:      	cmp	x27, #0x58
    2a90:      	cset	w3, le
    2a94:      	cmp	x27, #0x47
    2a98:      	b.ne	0x2b88 <_stogir.vector.validate+0x338>
    2a9c:      	str	x20, [sp, #0x1a8]
    2aa0:      	str	w19, [sp, #0x1a0]
    2aa4:      	mov	w19, w0
    2aa8:      	mov	w20, w1
    2aac:      	str	w2, [sp, #0x1b0]
    2ab0:      	str	w3, [sp, #0x1b8]
    2ab4:      	mov	x0, x21
    2ab8:      	ldr	w1, [sp, #0x1a0]
    2abc:      	bl	0x2abc <_stogir.vector.validate+0x26c>
		0000000000002abc:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2ac0:      	cmp	x0, #0x0
    2ac4:      	b.eq	0x2bac <_stogir.vector.validate+0x35c>
    2ac8:      	add	x8, sp, #0xf0
    2acc:      	mov	x0, x21
    2ad0:      	ldr	w1, [sp, #0x1a0]
    2ad4:      	bl	0x2ad4 <_stogir.vector.validate+0x284>
		0000000000002ad4:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    2ad8:      	add	x16, sp, #0xf0
    2adc:      	ldr	x0, [x16]
    2ae0:      	add	x16, sp, #0xf0
    2ae4:      	ldr	x19, [x16, #0x8]
    2ae8:      	add	x16, sp, #0xf0
    2aec:      	ldr	x25, [x16, #0x10]
    2af0:      	b	0x2924 <_stogir.vector.validate+0xd4>
    2af4:      	cmp	x27, #0x3d
    2af8:      	b.lt	0x2b38 <_stogir.vector.validate+0x2e8>
    2afc:      	cmp	x27, #0x3f
    2b00:      	b.gt	0x2b38 <_stogir.vector.validate+0x2e8>
    2b04:      	add	x8, sp, #0xb0
    2b08:      	mov	x0, x21
    2b0c:      	mov	w1, w19
    2b10:      	mov	w2, w23
    2b14:      	bl	0x2b14 <_stogir.vector.validate+0x2c4>
		0000000000002b14:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    2b18:      	add	x16, sp, #0xb0
    2b1c:      	ldr	x0, [x16]
    2b20:      	add	x16, sp, #0xb0
    2b24:      	ldr	x19, [x16, #0x8]
    2b28:      	add	x16, sp, #0xb0
    2b2c:      	ldr	x25, [x16, #0x10]
    2b30:      	str	x20, [sp, #0x1a8]
    2b34:      	b	0x2af0 <_stogir.vector.validate+0x2a0>
    2b38:      	mov	x0, x21
    2b3c:      	mov	w1, w19
    2b40:      	bl	0x2b40 <_stogir.vector.validate+0x2f0>
		0000000000002b40:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    2b44:      	cmp	x0, #0x0
    2b48:      	b.eq	0x2a74 <_stogir.vector.validate+0x224>
    2b4c:      	add	x8, sp, #0xd0
    2b50:      	mov	x0, x21
    2b54:      	mov	w1, w19
    2b58:      	mov	w2, w23
    2b5c:      	bl	0x2b5c <_stogir.vector.validate+0x30c>
		0000000000002b5c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    2b60:      	add	x16, sp, #0xd0
    2b64:      	ldr	x0, [x16]
    2b68:      	add	x16, sp, #0xd0
    2b6c:      	ldr	x19, [x16, #0x8]
    2b70:      	add	x16, sp, #0xd0
    2b74:      	ldr	x25, [x16, #0x10]
    2b78:      	str	x20, [sp, #0x1a8]
    2b7c:      	b	0x2af0 <_stogir.vector.validate+0x2a0>
    2b80:      	brk	#0
    2b84:      	b	0x2b80 <_stogir.vector.validate+0x330>
    2b88:      	cmp	x27, #0x4f
    2b8c:      	b.ne	0x2c24 <_stogir.vector.validate+0x3d4>
    2b90:      	str	x20, [sp, #0x1a8]
    2b94:      	str	w19, [sp, #0x1a0]
    2b98:      	mov	w19, w0
    2b9c:      	mov	w20, w1
    2ba0:      	str	w2, [sp, #0x1b0]
    2ba4:      	str	w3, [sp, #0x1b8]
    2ba8:      	b	0x2ab4 <_stogir.vector.validate+0x264>
    2bac:      	uxtb	w16, w19
    2bb0:      	cmp	w16, wzr
    2bb4:      	b.ne	0x2bf4 <_stogir.vector.validate+0x3a4>
    2bb8:      	uxtb	w16, w20
    2bbc:      	cmp	w16, wzr
    2bc0:      	b.ne	0x2bf4 <_stogir.vector.validate+0x3a4>
    2bc4:      	ldr	w0, [sp, #0x1b0]
    2bc8:      	uxtb	w16, w0
    2bcc:      	cmp	w16, wzr
    2bd0:      	b.eq	0x2be4 <_stogir.vector.validate+0x394>
    2bd4:      	ldr	w0, [sp, #0x1b8]
    2bd8:      	uxtb	w16, w0
    2bdc:      	cmp	w16, wzr
    2be0:      	b.ne	0x2bf4 <_stogir.vector.validate+0x3a4>
    2be4:      	movz	x0, #0x0, lsl #48
    2be8:      	movz	x19, #0x0, lsl #48
    2bec:      	movz	x25, #0x0, lsl #48
    2bf0:      	b	0x2c20 <_stogir.vector.validate+0x3d0>
    2bf4:      	add	x8, sp, #0x110
    2bf8:      	mov	x0, x21
    2bfc:      	ldr	w1, [sp, #0x1a0]
    2c00:      	mov	w2, w23
    2c04:      	bl	0x2c04 <_stogir.vector.validate+0x3b4>
		0000000000002c04:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    2c08:      	add	x16, sp, #0x110
    2c0c:      	ldr	x0, [x16]
    2c10:      	add	x16, sp, #0x110
    2c14:      	ldr	x19, [x16, #0x8]
    2c18:      	add	x16, sp, #0x110
    2c1c:      	ldr	x25, [x16, #0x10]
    2c20:      	b	0x2af0 <_stogir.vector.validate+0x2a0>
    2c24:      	cmp	x27, #0x50
    2c28:      	b.eq	0x3274 <_stogir.vector.validate+0xa24>
    2c2c:      	cmp	x27, #0x78
    2c30:      	b.ne	0x2c50 <_stogir.vector.validate+0x400>
    2c34:      	str	x20, [sp, #0x1a8]
    2c38:      	str	w19, [sp, #0x1a0]
    2c3c:      	mov	w19, w0
    2c40:      	mov	w20, w1
    2c44:      	str	w2, [sp, #0x1b0]
    2c48:      	str	w3, [sp, #0x1b8]
    2c4c:      	b	0x2ab4 <_stogir.vector.validate+0x264>
    2c50:      	uxtb	w16, w0
    2c54:      	cmp	w16, wzr
    2c58:      	b.ne	0x2d40 <_stogir.vector.validate+0x4f0>
    2c5c:      	uxtb	w16, w1
    2c60:      	cmp	w16, wzr
    2c64:      	b.ne	0x2d40 <_stogir.vector.validate+0x4f0>
    2c68:      	uxtb	w16, w2
    2c6c:      	cmp	w16, wzr
    2c70:      	b.eq	0x2c80 <_stogir.vector.validate+0x430>
    2c74:      	uxtb	w16, w3
    2c78:      	cmp	w16, wzr
    2c7c:      	b.ne	0x2d40 <_stogir.vector.validate+0x4f0>
    2c80:      	str	w2, [sp, #0x1b0]
    2c84:      	str	w3, [sp, #0x1b8]
    2c88:      	str	w19, [sp, #0x1a0]
    2c8c:      	str	x20, [sp, #0x1a8]
    2c90:      	mov	w20, w1
    2c94:      	mov	w1, w19
    2c98:      	mov	w19, w0
    2c9c:      	mov	x0, x21
    2ca0:      	bl	0x2ca0 <_stogir.vector.validate+0x450>
		0000000000002ca0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2ca4:      	cmp	x0, #0x0
    2ca8:      	b.ne	0x2ab4 <_stogir.vector.validate+0x264>
    2cac:      	sxtw	x28, w28
    2cb0:      	ubfx	x25, x25, #0, #32
    2cb4:      	ubfx	x0, x25, #8, #8
    2cb8:      	orr	x1, x0, xzr
    2cbc:      	orr	w20, w1, wzr
    2cc0:      	cmp	x27, #0x5b
    2cc4:      	b.eq	0x2d74 <_stogir.vector.validate+0x524>
    2cc8:      	cmp	x27, #0x5c
    2ccc:      	b.eq	0x2d74 <_stogir.vector.validate+0x524>
    2cd0:      	orr	x25, x0, xzr
    2cd4:      	cmp	x27, #0x5d
    2cd8:      	b.ne	0x2ddc <_stogir.vector.validate+0x58c>
    2cdc:      	mov	x27, x25
    2ce0:      	cmp	x28, #0x3
    2ce4:      	b.ne	0x2dc4 <_stogir.vector.validate+0x574>
    2ce8:      	cmp	x27, #0x0
    2cec:      	b.ne	0x2dc4 <_stogir.vector.validate+0x574>
    2cf0:      	add	x16, sp, #0x40
    2cf4:      	ldr	w0, [x16, #0x4]
    2cf8:      	add	x16, sp, #0x40
    2cfc:      	ldr	w1, [x16, #0x8]
    2d00:      	add	x16, sp, #0x40
    2d04:      	ldr	w2, [x16, #0xc]
    2d08:      	add	x8, sp, #0x150
    2d0c:      	mov	w3, w1
    2d10:      	mov	w1, w23
    2d14:      	mov	w4, w2
    2d18:      	mov	w2, w0
    2d1c:      	mov	x0, x21
    2d20:      	bl	0x2d20 <_stogir.vector.validate+0x4d0>
		0000000000002d20:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    2d24:      	add	x16, sp, #0x150
    2d28:      	ldr	x0, [x16]
    2d2c:      	add	x16, sp, #0x150
    2d30:      	ldr	x19, [x16, #0x8]
    2d34:      	add	x16, sp, #0x150
    2d38:      	ldr	x25, [x16, #0x10]
    2d3c:      	b	0x2dd8 <_stogir.vector.validate+0x588>
    2d40:      	str	x20, [sp, #0x1a8]
    2d44:      	str	w19, [sp, #0x1a0]
    2d48:      	mov	w19, w0
    2d4c:      	mov	w20, w1
    2d50:      	str	w2, [sp, #0x1b0]
    2d54:      	str	w3, [sp, #0x1b8]
    2d58:      	b	0x2ab4 <_stogir.vector.validate+0x264>
    2d5c:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002d5c:  ARM64_RELOC_PAGE21	l_stogir.351
    2d60:      	ldr	x16, [x16]
		0000000000002d60:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    2d64:      	orr	x19, x16, xzr
    2d68:      	mov	x0, #0x1                ; =1
    2d6c:      	mov	x25, #0x19              ; =25
    2d70:      	b	0x2af0 <_stogir.vector.validate+0x2a0>
    2d74:      	cmp	x28, #0x2
    2d78:      	b.ne	0x2d5c <_stogir.vector.validate+0x50c>
    2d7c:      	add	x16, sp, #0x40
    2d80:      	ldr	w0, [x16, #0x4]
    2d84:      	add	x16, sp, #0x40
    2d88:      	ldr	w1, [x16, #0x8]
    2d8c:      	add	x8, sp, #0x130
    2d90:      	mov	w2, w23
    2d94:      	mov	w3, w0
    2d98:      	mov	x0, x21
    2d9c:      	mov	w4, w1
    2da0:      	mov	w1, w20
    2da4:      	bl	0x2da4 <_stogir.vector.validate+0x554>
		0000000000002da4:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    2da8:      	add	x16, sp, #0x130
    2dac:      	ldr	x0, [x16]
    2db0:      	add	x16, sp, #0x130
    2db4:      	ldr	x19, [x16, #0x8]
    2db8:      	add	x16, sp, #0x130
    2dbc:      	ldr	x25, [x16, #0x10]
    2dc0:      	b	0x2d70 <_stogir.vector.validate+0x520>
    2dc4:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002dc4:  ARM64_RELOC_PAGE21	l_stogir.352
    2dc8:      	ldr	x16, [x16]
		0000000000002dc8:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    2dcc:      	orr	x19, x16, xzr
    2dd0:      	mov	x0, #0x1                ; =1
    2dd4:      	mov	x25, #0x1a              ; =26
    2dd8:      	b	0x2d70 <_stogir.vector.validate+0x520>
    2ddc:      	cmp	x27, #0x5e
    2de0:      	b.eq	0x3290 <_stogir.vector.validate+0xa40>
    2de4:      	cmp	x27, #0x43
    2de8:      	b.ne	0x2e54 <_stogir.vector.validate+0x604>
    2dec:      	cmp	x25, #0xf
    2df0:      	b.le	0x3184 <_stogir.vector.validate+0x934>
    2df4:      	cmp	x25, #0x80
    2df8:      	b.ge	0x3184 <_stogir.vector.validate+0x934>
    2dfc:      	and	x0, x25, #0xf
    2e00:      	sxtw	x0, w0
    2e04:      	cmp	x0, #0x1
    2e08:      	b.lt	0x3184 <_stogir.vector.validate+0x934>
    2e0c:      	cmp	x0, #0xd
    2e10:      	b.gt	0x3184 <_stogir.vector.validate+0x934>
    2e14:      	mov	w0, w20
    2e18:      	mov	w1, w23
    2e1c:      	bl	0x2e1c <_stogir.vector.validate+0x5cc>
		0000000000002e1c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2e20:      	sxtw	x0, w0
    2e24:      	cmp	x0, #0x0
    2e28:      	b.le	0x3184 <_stogir.vector.validate+0x934>
    2e2c:      	cmp	x28, #0x3
    2e30:      	b.lt	0x3184 <_stogir.vector.validate+0x934>
    2e34:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002e34:  ARM64_RELOC_PAGE21	l_stogir.353
    2e38:      	ldr	x16, [x16]
		0000000000002e38:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    2e3c:      	orr	x19, x16, xzr
    2e40:      	mov	x27, x25
    2e44:      	movz	x25, #0x0, lsl #48
    2e48:      	b	0x3198 <_stogir.vector.validate+0x948>
    2e4c:      	mov	x0, #0x1                ; =1
    2e50:      	b	0x2dd8 <_stogir.vector.validate+0x588>
    2e54:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002e54:  ARM64_RELOC_PAGE21	l_stogir.354
    2e58:      	ldr	x16, [x16]
		0000000000002e58:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    2e5c:      	orr	x19, x16, xzr
    2e60:      	mov	x0, #0x1                ; =1
    2e64:      	mov	x25, #0x28              ; =40
    2e68:      	b	0x2e50 <_stogir.vector.validate+0x600>
    2e6c:      	add	x16, sp, #0x40
    2e70:      	ldr	w0, [x16, #0x4]
    2e74:      	sxtw	x0, w0
    2e78:      	ldr	x1, [x21, #0x78]
    2e7c:      	add	x0, x1, x0, lsl #2
    2e80:      	ldr	w0, [x0]
    2e84:      	sxtw	x0, w0
    2e88:      	add	x0, x0, #0x1
    2e8c:      	sxtw	x0, w0
    2e90:      	cmp	x28, x0
    2e94:      	cset	w0, eq
    2e98:      	uxtb	w16, w0
    2e9c:      	cmp	w16, wzr
    2ea0:      	cset	x0, eq
    2ea4:      	cmp	x0, #0x0
    2ea8:      	b.eq	0x2ebc <_stogir.vector.validate+0x66c>
    2eac:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002eac:  ARM64_RELOC_PAGE21	l_stogir.355
    2eb0:      	ldr	x16, [x16]
		0000000000002eb0:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    2eb4:      	orr	x19, x16, xzr
    2eb8:      	mov	x25, #0x19              ; =25
    2ebc:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002ebc:  ARM64_RELOC_PAGE21	l_stogir.356
    2ec0:      	ldr	x16, [x16]
		0000000000002ec0:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    2ec4:      	orr	x0, x16, xzr
    2ec8:      	adrp	x16, 0x2000 <_stogir.types.valid?+0x18>
		0000000000002ec8:  ARM64_RELOC_PAGE21	l_stogir.357
    2ecc:      	ldr	x16, [x16]
		0000000000002ecc:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    2ed0:      	orr	x1, x16, xzr
    2ed4:      	add	x2, x21, #0x78
    2ed8:      	add	x3, x21, #0x28
    2edc:      	add	x4, x21, #0x50
    2ee0:      	add	x5, x21, #0x78
    2ee4:      	mov	x6, #0x2                ; =2
    2ee8:      	b	0x2f60 <_stogir.vector.validate+0x710>
    2eec:      	ubfx	x7, x7, #0, #32
    2ef0:      	ubfx	x7, x7, #8, #8
    2ef4:      	cmp	x7, x27
    2ef8:      	b.eq	0x2f04 <_stogir.vector.validate+0x6b4>
    2efc:      	mov	x19, x1
    2f00:      	mov	x25, #0x1e              ; =30
    2f04:      	b	0x2f58 <_stogir.vector.validate+0x708>
    2f08:      	movz	x8, #0x0, lsl #48
    2f0c:      	movz	x7, #0x0, lsl #48
    2f10:      	b	0x2f20 <_stogir.vector.validate+0x6d0>
    2f14:      	nop
    2f18:      	movz	x8, #0x0, lsl #48
    2f1c:      	movz	x7, #0x0, lsl #48
    2f20:      	ubfx	x8, x8, #0, #32
    2f24:      	lsr	x16, x8, #0
    2f28:      	cmp	x16, #0x1
    2f2c:      	b.eq	0x2f48 <_stogir.vector.validate+0x6f8>
    2f30:      	b.lo	0x2f38 <_stogir.vector.validate+0x6e8>
    2f34:      	b	0x2f4c <_stogir.vector.validate+0x6fc>
    2f38:      	cmp	x16, #0x0
    2f3c:      	b.eq	0x2f44 <_stogir.vector.validate+0x6f4>
    2f40:      	b	0x2f4c <_stogir.vector.validate+0x6fc>
    2f44:      	b	0x2f50 <_stogir.vector.validate+0x700>
    2f48:      	b	0x2fb4 <_stogir.vector.validate+0x764>
    2f4c:      	b	0x3250 <_stogir.vector.validate+0xa00>
    2f50:      	mov	x19, x0
    2f54:      	mov	x25, #0x18              ; =24
    2f58:      	add	x6, x6, #0x1
    2f5c:      	sxtw	x6, w6
    2f60:      	cmp	x25, #0x0
    2f64:      	b.ne	0x30d4 <_stogir.vector.validate+0x884>
    2f68:      	cmp	x6, x28
    2f6c:      	b.gt	0x30d4 <_stogir.vector.validate+0x884>
    2f70:      	uxtb	w16, w24
    2f74:      	cmp	w16, wzr
    2f78:      	b.ne	0x2f18 <_stogir.vector.validate+0x6c8>
    2f7c:      	ldr	x7, [x21, #0x8]
    2f80:      	cmp	x22, x7
    2f84:      	b.ge	0x3018 <_stogir.vector.validate+0x7c8>
    2f88:      	ldr	x7, [x5, #0x8]
    2f8c:      	cmp	x22, x7
    2f90:      	b.ge	0x3010 <_stogir.vector.validate+0x7c0>
    2f94:      	ldr	x7, [x21, #0x78]
    2f98:      	add	x7, x26, x7
    2f9c:      	ldr	w7, [x7]
    2fa0:      	sxtw	x7, w7
    2fa4:      	cmp	x7, #0x0
    2fa8:      	cset	w7, ge
    2fac:      	ubfx	x7, x7, #0, #8
    2fb0:      	b	0x3014 <_stogir.vector.validate+0x7c4>
    2fb4:      	sxtw	x7, w7
    2fb8:      	cmp	x7, #0x0
    2fbc:      	cset	w8, gt
    2fc0:      	movz	x16, #0x0, lsl #48
    2fc4:      	sub	x9, x16, x7
    2fc8:      	sub	x10, x9, #0x1
    2fcc:      	uxtb	w16, w8
    2fd0:      	cmp	w16, wzr
    2fd4:      	b.eq	0x3094 <_stogir.vector.validate+0x844>
    2fd8:      	ldr	x9, [x21, #0x8]
    2fdc:      	cmp	x7, x9
    2fe0:      	b.ge	0x30fc <_stogir.vector.validate+0x8ac>
    2fe4:      	ldr	x9, [x2, #0x8]
    2fe8:      	cmp	x7, x9
    2fec:      	b.ge	0x3200 <_stogir.vector.validate+0x9b0>
    2ff0:      	ldr	x9, [x21, #0x78]
    2ff4:      	add	x9, x9, x7, lsl #2
    2ff8:      	ldr	w9, [x9]
    2ffc:      	sxtw	x9, w9
    3000:      	cmp	x9, #0x0
    3004:      	cset	w9, ge
    3008:      	ubfx	x9, x9, #0, #8
    300c:      	b	0x3204 <_stogir.vector.validate+0x9b4>
    3010:      	movz	x7, #0x0, lsl #48
    3014:      	b	0x301c <_stogir.vector.validate+0x7cc>
    3018:      	movz	x7, #0x0, lsl #48
    301c:      	cmp	x7, #0x0
    3020:      	b.eq	0x2f18 <_stogir.vector.validate+0x6c8>
    3024:      	orr	w7, w6, wzr
    3028:      	sxtw	x7, w7
    302c:      	cmp	x7, #0x1
    3030:      	b.lt	0x2f08 <_stogir.vector.validate+0x6b8>
    3034:      	ldr	x8, [x21, #0x78]
    3038:      	add	x8, x26, x8
    303c:      	ldr	w8, [x8]
    3040:      	sxtw	x8, w8
    3044:      	cmp	x7, x8
    3048:      	b.gt	0x2f08 <_stogir.vector.validate+0x6b8>
    304c:      	ldr	x8, [x21]
    3050:      	asr	x16, x7, #63
    3054:      	lsr	x16, x16, #62
    3058:      	add	x9, x7, x16
    305c:      	asr	x9, x9, #2
    3060:      	asr	x16, x7, #63
    3064:      	lsr	x16, x16, #62
    3068:      	add	x7, x7, x16
    306c:      	and	x7, x7, #0x3
    3070:      	sub	x7, x7, x16
    3074:      	add	x9, x9, x22
    3078:      	add	x8, x8, x9, lsl #4
    307c:      	add	x7, x8, x7, lsl #2
    3080:      	ldr	w7, [x7]
    3084:      	sxtw	x7, w7
    3088:      	and	x7, x7, #0xffffffff
    308c:      	mov	x8, #0x1                ; =1
    3090:      	b	0x2f10 <_stogir.vector.validate+0x6c0>
    3094:      	cmp	x7, #0x0
    3098:      	b.ge	0x3104 <_stogir.vector.validate+0x8b4>
    309c:      	ldr	x11, [x3, #0x8]
    30a0:      	ldr	x12, [x4, #0x8]
    30a4:      	cmp	x11, x12
    30a8:      	b.ne	0x31f8 <_stogir.vector.validate+0x9a8>
    30ac:      	cmp	x9, x11
    30b0:      	b.gt	0x322c <_stogir.vector.validate+0x9dc>
    30b4:      	ldr	x9, [x21, #0x50]
    30b8:      	add	x9, x9, x10, lsl #2
    30bc:      	ldr	w9, [x9]
    30c0:      	sxtw	x9, w9
    30c4:      	cmp	x9, #0x0
    30c8:      	cset	w9, gt
    30cc:      	ubfx	x9, x9, #0, #8
    30d0:      	b	0x3230 <_stogir.vector.validate+0x9e0>
    30d4:      	cmp	x25, #0x0
    30d8:      	b.ne	0x2e4c <_stogir.vector.validate+0x5fc>
    30dc:      	mov	w0, w20
    30e0:      	mov	w1, w23
    30e4:      	bl	0x30e4 <_stogir.vector.validate+0x894>
		00000000000030e4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    30e8:      	sxtw	x0, w0
    30ec:      	and	x19, x0, #0xffffffff
    30f0:      	movz	x0, #0x0, lsl #48
    30f4:      	movz	x25, #0x0, lsl #48
    30f8:      	b	0x2e50 <_stogir.vector.validate+0x600>
    30fc:      	movz	x9, #0x0, lsl #48
    3100:      	b	0x3108 <_stogir.vector.validate+0x8b8>
    3104:      	movz	x9, #0x0, lsl #48
    3108:      	cmp	x9, #0x0
    310c:      	b.eq	0x3140 <_stogir.vector.validate+0x8f0>
    3110:      	uxtb	w16, w8
    3114:      	cmp	w16, wzr
    3118:      	b.eq	0x312c <_stogir.vector.validate+0x8dc>
    311c:      	ldr	x8, [x21]
    3120:      	add	x7, x8, x7, lsl #4
    3124:      	ldr	x7, [x7]
    3128:      	b	0x3138 <_stogir.vector.validate+0x8e8>
    312c:      	ldr	x7, [x21, #0x28]
    3130:      	add	x7, x7, x10, lsl #4
    3134:      	ldr	x7, [x7]
    3138:      	mov	x8, #0x1                ; =1
    313c:      	b	0x3148 <_stogir.vector.validate+0x8f8>
    3140:      	movz	x8, #0x0, lsl #48
    3144:      	movz	x7, #0x0, lsl #48
    3148:      	ubfx	x8, x8, #0, #32
    314c:      	lsr	x16, x8, #0
    3150:      	cmp	x16, #0x1
    3154:      	b.eq	0x3170 <_stogir.vector.validate+0x920>
    3158:      	b.lo	0x3160 <_stogir.vector.validate+0x910>
    315c:      	b	0x3174 <_stogir.vector.validate+0x924>
    3160:      	cmp	x16, #0x0
    3164:      	b.eq	0x316c <_stogir.vector.validate+0x91c>
    3168:      	b	0x3174 <_stogir.vector.validate+0x924>
    316c:      	b	0x3178 <_stogir.vector.validate+0x928>
    3170:      	b	0x2eec <_stogir.vector.validate+0x69c>
    3174:      	b	0x3258 <_stogir.vector.validate+0xa08>
    3178:      	mov	x19, x0
    317c:      	mov	x25, #0x18              ; =24
    3180:      	b	0x2f04 <_stogir.vector.validate+0x6b4>
    3184:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003184:  ARM64_RELOC_PAGE21	l_stogir.358
    3188:      	ldr	x16, [x16]
		0000000000003188:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    318c:      	orr	x19, x16, xzr
    3190:      	mov	x27, x25
    3194:      	mov	x25, #0x20              ; =32
    3198:      	add	x16, sp, #0x40
    319c:      	ldr	w0, [x16, #0x4]
    31a0:      	add	x8, sp, #0x170
    31a4:      	mov	w1, w0
    31a8:      	mov	x0, x21
    31ac:      	bl	0x31ac <_stogir.vector.validate+0x95c>
		00000000000031ac:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    31b0:      	add	x16, sp, #0x170
    31b4:      	ldr	w0, [x16]
    31b8:      	lsr	x16, x0, #0
    31bc:      	cmp	x16, #0x1
    31c0:      	b.eq	0x31dc <_stogir.vector.validate+0x98c>
    31c4:      	b.lo	0x31cc <_stogir.vector.validate+0x97c>
    31c8:      	b	0x31e0 <_stogir.vector.validate+0x990>
    31cc:      	cmp	x16, #0x0
    31d0:      	b.eq	0x31d8 <_stogir.vector.validate+0x988>
    31d4:      	b	0x31e0 <_stogir.vector.validate+0x990>
    31d8:      	b	0x31e4 <_stogir.vector.validate+0x994>
    31dc:      	b	0x3208 <_stogir.vector.validate+0x9b8>
    31e0:      	b	0x3260 <_stogir.vector.validate+0xa10>
    31e4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		00000000000031e4:  ARM64_RELOC_PAGE21	l_stogir.359
    31e8:      	ldr	x16, [x16]
		00000000000031e8:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    31ec:      	orr	x19, x16, xzr
    31f0:      	mov	x25, #0x19              ; =25
    31f4:      	b	0x2ebc <_stogir.vector.validate+0x66c>
    31f8:      	movz	x9, #0x0, lsl #48
    31fc:      	b	0x3108 <_stogir.vector.validate+0x8b8>
    3200:      	movz	x9, #0x0, lsl #48
    3204:      	b	0x3100 <_stogir.vector.validate+0x8b0>
    3208:      	add	x16, sp, #0x170
    320c:      	ldr	x0, [x16, #0x8]
    3210:      	add	x16, sp, #0x40
    3214:      	ldr	w1, [x16, #0x4]
    3218:      	sxtw	x1, w1
    321c:      	cmp	x1, #0x0
    3220:      	b.gt	0x3234 <_stogir.vector.validate+0x9e4>
    3224:      	mov	x0, #0x1                ; =1
    3228:      	b	0x2ea4 <_stogir.vector.validate+0x654>
    322c:      	movz	x9, #0x0, lsl #48
    3230:      	b	0x31fc <_stogir.vector.validate+0x9ac>
    3234:      	uxtb	w0, w0
    3238:      	cmp	x0, #0x70
    323c:      	b.eq	0x2e6c <_stogir.vector.validate+0x61c>
    3240:      	cmp	x0, #0x71
    3244:      	b.eq	0x2e6c <_stogir.vector.validate+0x61c>
    3248:      	mov	x0, #0x1                ; =1
    324c:      	b	0x2ea4 <_stogir.vector.validate+0x654>
    3250:      	brk	#0
    3254:      	b	0x3250 <_stogir.vector.validate+0xa00>
    3258:      	brk	#0
    325c:      	b	0x3258 <_stogir.vector.validate+0xa08>
    3260:      	brk	#0
    3264:      	b	0x3260 <_stogir.vector.validate+0xa10>
    3268:      	str	x20, [sp, #0x1a8]
    326c:      	str	w19, [sp, #0x1a0]
    3270:      	b	0x29f8 <_stogir.vector.validate+0x1a8>
    3274:      	str	x20, [sp, #0x1a8]
    3278:      	str	w19, [sp, #0x1a0]
    327c:      	mov	w19, w0
    3280:      	mov	w20, w1
    3284:      	str	w2, [sp, #0x1b0]
    3288:      	str	w3, [sp, #0x1b8]
    328c:      	b	0x2ab4 <_stogir.vector.validate+0x264>
    3290:      	mov	x27, x25
    3294:      	b	0x2ce0 <_stogir.vector.validate+0x490>

0000000000003298 <_stogir.copy.validate>:
    3298:      	sub	sp, sp, #0x10
    329c:      	sxtw	x1, w1
    32a0:      	lsl	x2, x1, #2
    32a4:      	cmp	x1, #0x0
    32a8:      	cset	w3, gt
    32ac:      	movz	x16, #0x0, lsl #48
    32b0:      	sub	x4, x16, x1
    32b4:      	sub	x5, x4, #0x1
    32b8:      	uxtb	w16, w3
    32bc:      	cmp	w16, wzr
    32c0:      	b.eq	0x3300 <_stogir.copy.validate+0x68>
    32c4:      	ldr	x4, [x0, #0x8]
    32c8:      	cmp	x1, x4
    32cc:      	b.ge	0x3368 <_stogir.copy.validate+0xd0>
    32d0:      	add	x4, x0, #0x78
    32d4:      	ldr	x4, [x4, #0x8]
    32d8:      	cmp	x1, x4
    32dc:      	b.ge	0x34fc <_stogir.copy.validate+0x264>
    32e0:      	ldr	x4, [x0, #0x78]
    32e4:      	add	x4, x2, x4
    32e8:      	ldr	w4, [x4]
    32ec:      	sxtw	x4, w4
    32f0:      	cmp	x4, #0x0
    32f4:      	cset	w4, ge
    32f8:      	ubfx	x4, x4, #0, #8
    32fc:      	b	0x3500 <_stogir.copy.validate+0x268>
    3300:      	cmp	x1, #0x0
    3304:      	b.ge	0x3370 <_stogir.copy.validate+0xd8>
    3308:      	add	x6, x0, #0x28
    330c:      	add	x7, x0, #0x50
    3310:      	ldr	x6, [x6, #0x8]
    3314:      	ldr	x7, [x7, #0x8]
    3318:      	cmp	x6, x7
    331c:      	b.ne	0x3348 <_stogir.copy.validate+0xb0>
    3320:      	cmp	x4, x6
    3324:      	b.gt	0x3504 <_stogir.copy.validate+0x26c>
    3328:      	ldr	x4, [x0, #0x50]
    332c:      	add	x4, x4, x5, lsl #2
    3330:      	ldr	w4, [x4]
    3334:      	sxtw	x4, w4
    3338:      	cmp	x4, #0x0
    333c:      	cset	w4, gt
    3340:      	ubfx	x4, x4, #0, #8
    3344:      	b	0x3508 <_stogir.copy.validate+0x270>
    3348:      	movz	x4, #0x0, lsl #48
    334c:      	b	0x3374 <_stogir.copy.validate+0xdc>
    3350:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003350:  ARM64_RELOC_PAGE21	l_stogir.360
    3354:      	ldr	x16, [x16]
		0000000000003354:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    3358:      	orr	x0, x16, xzr
    335c:      	mov	x1, #0x1                ; =1
    3360:      	mov	x2, #0x21               ; =33
    3364:      	b	0x3404 <_stogir.copy.validate+0x16c>
    3368:      	movz	x4, #0x0, lsl #48
    336c:      	b	0x3374 <_stogir.copy.validate+0xdc>
    3370:      	movz	x4, #0x0, lsl #48
    3374:      	cmp	x4, #0x0
    3378:      	b.eq	0x33b4 <_stogir.copy.validate+0x11c>
    337c:      	uxtb	w16, w3
    3380:      	cmp	w16, wzr
    3384:      	b.eq	0x339c <_stogir.copy.validate+0x104>
    3388:      	ldr	x3, [x0]
    338c:      	add	x3, x3, x1, lsl #4
    3390:      	ldr	x4, [x3]
    3394:      	ldr	x3, [x3, #0x8]
    3398:      	b	0x33ac <_stogir.copy.validate+0x114>
    339c:      	ldr	x3, [x0, #0x28]
    33a0:      	add	x3, x3, x5, lsl #4
    33a4:      	ldr	x4, [x3]
    33a8:      	ldr	x3, [x3, #0x8]
    33ac:      	mov	x5, #0x1                ; =1
    33b0:      	b	0x33c0 <_stogir.copy.validate+0x128>
    33b4:      	movz	x5, #0x0, lsl #48
    33b8:      	movz	x4, #0x0, lsl #48
    33bc:      	movz	x3, #0x0, lsl #48
    33c0:      	ubfx	x5, x5, #0, #32
    33c4:      	lsr	x16, x5, #0
    33c8:      	cmp	x16, #0x1
    33cc:      	b.eq	0x33e8 <_stogir.copy.validate+0x150>
    33d0:      	b.lo	0x33d8 <_stogir.copy.validate+0x140>
    33d4:      	b	0x33ec <_stogir.copy.validate+0x154>
    33d8:      	cmp	x16, #0x0
    33dc:      	b.eq	0x33e4 <_stogir.copy.validate+0x14c>
    33e0:      	b	0x33ec <_stogir.copy.validate+0x154>
    33e4:      	b	0x33f0 <_stogir.copy.validate+0x158>
    33e8:      	b	0x3418 <_stogir.copy.validate+0x180>
    33ec:      	b	0x350c <_stogir.copy.validate+0x274>
    33f0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		00000000000033f0:  ARM64_RELOC_PAGE21	l_stogir.361
    33f4:      	ldr	x16, [x16]
		00000000000033f4:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    33f8:      	orr	x0, x16, xzr
    33fc:      	mov	x1, #0x1                ; =1
    3400:      	mov	x2, #0x18               ; =24
    3404:      	str	x1, [x8]
    3408:      	str	x0, [x8, #0x8]
    340c:      	str	x2, [x8, #0x10]
    3410:      	add	sp, sp, #0x10
    3414:      	ret
    3418:      	mov	x16, sp
    341c:      	str	x4, [x16]
    3420:      	mov	x16, sp
    3424:      	str	x3, [x16, #0x8]
    3428:      	cmp	x1, #0x0
    342c:      	b.le	0x3350 <_stogir.copy.validate+0xb8>
    3430:      	uxtb	w1, w4
    3434:      	cmp	x1, #0x44
    3438:      	b.ne	0x3350 <_stogir.copy.validate+0xb8>
    343c:      	ldr	x1, [x0, #0x78]
    3440:      	add	x1, x2, x1
    3444:      	ldr	w1, [x1]
    3448:      	sxtw	x1, w1
    344c:      	cmp	x1, #0x2
    3450:      	b.ne	0x3350 <_stogir.copy.validate+0xb8>
    3454:      	ubfx	x4, x4, #0, #32
    3458:      	ubfx	x1, x4, #8, #8
    345c:      	cmp	x1, #0x0
    3460:      	b.eq	0x3350 <_stogir.copy.validate+0xb8>
    3464:      	cmp	x1, #0xd
    3468:      	b.le	0x3494 <_stogir.copy.validate+0x1fc>
    346c:      	cmp	x1, #0xf
    3470:      	b.le	0x3350 <_stogir.copy.validate+0xb8>
    3474:      	cmp	x1, #0x80
    3478:      	b.ge	0x3350 <_stogir.copy.validate+0xb8>
    347c:      	and	x2, x1, #0xf
    3480:      	sxtw	x2, w2
    3484:      	cmp	x2, #0x1
    3488:      	b.lt	0x3350 <_stogir.copy.validate+0xb8>
    348c:      	cmp	x2, #0xd
    3490:      	b.gt	0x3350 <_stogir.copy.validate+0xb8>
    3494:      	mov	x16, sp
    3498:      	ldr	w2, [x16, #0x4]
    349c:      	sxtw	x2, w2
    34a0:      	cmp	x2, #0x0
    34a4:      	cset	w3, gt
    34a8:      	movz	x16, #0x0, lsl #48
    34ac:      	sub	x4, x16, x2
    34b0:      	sub	x5, x4, #0x1
    34b4:      	uxtb	w16, w3
    34b8:      	cmp	w16, wzr
    34bc:      	b.eq	0x352c <_stogir.copy.validate+0x294>
    34c0:      	ldr	x4, [x0, #0x8]
    34c4:      	cmp	x2, x4
    34c8:      	b.ge	0x3574 <_stogir.copy.validate+0x2dc>
    34cc:      	add	x4, x0, #0x78
    34d0:      	ldr	x4, [x4, #0x8]
    34d4:      	cmp	x2, x4
    34d8:      	b.ge	0x363c <_stogir.copy.validate+0x3a4>
    34dc:      	ldr	x4, [x0, #0x78]
    34e0:      	add	x4, x4, x2, lsl #2
    34e4:      	ldr	w4, [x4]
    34e8:      	sxtw	x4, w4
    34ec:      	cmp	x4, #0x0
    34f0:      	cset	w4, ge
    34f4:      	ubfx	x4, x4, #0, #8
    34f8:      	b	0x3640 <_stogir.copy.validate+0x3a8>
    34fc:      	movz	x4, #0x0, lsl #48
    3500:      	b	0x336c <_stogir.copy.validate+0xd4>
    3504:      	movz	x4, #0x0, lsl #48
    3508:      	b	0x334c <_stogir.copy.validate+0xb4>
    350c:      	brk	#0
    3510:      	b	0x350c <_stogir.copy.validate+0x274>
    3514:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003514:  ARM64_RELOC_PAGE21	l_stogir.362
    3518:      	ldr	x16, [x16]
		0000000000003518:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    351c:      	orr	x0, x16, xzr
    3520:      	mov	x1, #0x1                ; =1
    3524:      	mov	x2, #0x20               ; =32
    3528:      	b	0x3364 <_stogir.copy.validate+0xcc>
    352c:      	cmp	x2, #0x0
    3530:      	b.ge	0x357c <_stogir.copy.validate+0x2e4>
    3534:      	add	x6, x0, #0x28
    3538:      	add	x7, x0, #0x50
    353c:      	ldr	x6, [x6, #0x8]
    3540:      	ldr	x7, [x7, #0x8]
    3544:      	cmp	x6, x7
    3548:      	b.ne	0x3634 <_stogir.copy.validate+0x39c>
    354c:      	cmp	x4, x6
    3550:      	b.gt	0x3644 <_stogir.copy.validate+0x3ac>
    3554:      	ldr	x4, [x0, #0x50]
    3558:      	add	x4, x4, x5, lsl #2
    355c:      	ldr	w4, [x4]
    3560:      	sxtw	x4, w4
    3564:      	cmp	x4, #0x0
    3568:      	cset	w4, gt
    356c:      	ubfx	x4, x4, #0, #8
    3570:      	b	0x3648 <_stogir.copy.validate+0x3b0>
    3574:      	movz	x4, #0x0, lsl #48
    3578:      	b	0x3580 <_stogir.copy.validate+0x2e8>
    357c:      	movz	x4, #0x0, lsl #48
    3580:      	cmp	x4, #0x0
    3584:      	b.eq	0x35b8 <_stogir.copy.validate+0x320>
    3588:      	uxtb	w16, w3
    358c:      	cmp	w16, wzr
    3590:      	b.eq	0x35a4 <_stogir.copy.validate+0x30c>
    3594:      	ldr	x0, [x0]
    3598:      	add	x0, x0, x2, lsl #4
    359c:      	ldr	x0, [x0]
    35a0:      	b	0x35b0 <_stogir.copy.validate+0x318>
    35a4:      	ldr	x0, [x0, #0x28]
    35a8:      	add	x0, x0, x5, lsl #4
    35ac:      	ldr	x0, [x0]
    35b0:      	mov	x2, #0x1                ; =1
    35b4:      	b	0x35c0 <_stogir.copy.validate+0x328>
    35b8:      	movz	x2, #0x0, lsl #48
    35bc:      	movz	x0, #0x0, lsl #48
    35c0:      	ubfx	x2, x2, #0, #32
    35c4:      	lsr	x16, x2, #0
    35c8:      	cmp	x16, #0x1
    35cc:      	b.eq	0x35e8 <_stogir.copy.validate+0x350>
    35d0:      	b.lo	0x35d8 <_stogir.copy.validate+0x340>
    35d4:      	b	0x35ec <_stogir.copy.validate+0x354>
    35d8:      	cmp	x16, #0x0
    35dc:      	b.eq	0x35e4 <_stogir.copy.validate+0x34c>
    35e0:      	b	0x35ec <_stogir.copy.validate+0x354>
    35e4:      	b	0x35f0 <_stogir.copy.validate+0x358>
    35e8:      	b	0x3608 <_stogir.copy.validate+0x370>
    35ec:      	b	0x364c <_stogir.copy.validate+0x3b4>
    35f0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		00000000000035f0:  ARM64_RELOC_PAGE21	l_stogir.363
    35f4:      	ldr	x16, [x16]
		00000000000035f4:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    35f8:      	orr	x0, x16, xzr
    35fc:      	mov	x1, #0x1                ; =1
    3600:      	mov	x2, #0x13               ; =19
    3604:      	b	0x3528 <_stogir.copy.validate+0x290>
    3608:      	mov	x16, sp
    360c:      	ldr	w2, [x16]
    3610:      	ubfx	x0, x0, #0, #32
    3614:      	ubfx	x0, x0, #8, #8
    3618:      	ubfx	x2, x2, #8, #8
    361c:      	cmp	x0, x2
    3620:      	b.ne	0x3514 <_stogir.copy.validate+0x27c>
    3624:      	and	x0, x1, #0xffffffff
    3628:      	movz	x1, #0x0, lsl #48
    362c:      	movz	x2, #0x0, lsl #48
    3630:      	b	0x3528 <_stogir.copy.validate+0x290>
    3634:      	movz	x4, #0x0, lsl #48
    3638:      	b	0x3580 <_stogir.copy.validate+0x2e8>
    363c:      	movz	x4, #0x0, lsl #48
    3640:      	b	0x3578 <_stogir.copy.validate+0x2e0>
    3644:      	movz	x4, #0x0, lsl #48
    3648:      	b	0x3638 <_stogir.copy.validate+0x3a0>
    364c:      	brk	#0
    3650:      	b	0x364c <_stogir.copy.validate+0x3b4>

0000000000003654 <_stogir.graph.lookup>:
    3654:      	sxtw	x1, w1
    3658:      	cmp	x1, #0x0
    365c:      	cset	w2, gt
    3660:      	movz	x16, #0x0, lsl #48
    3664:      	sub	x3, x16, x1
    3668:      	sub	x4, x3, #0x1
    366c:      	uxtb	w16, w2
    3670:      	cmp	w16, wzr
    3674:      	b.eq	0x36b4 <_stogir.graph.lookup+0x60>
    3678:      	ldr	x3, [x0, #0x8]
    367c:      	cmp	x1, x3
    3680:      	b.ge	0x3704 <_stogir.graph.lookup+0xb0>
    3684:      	add	x3, x0, #0x78
    3688:      	ldr	x3, [x3, #0x8]
    368c:      	cmp	x1, x3
    3690:      	b.ge	0x377c <_stogir.graph.lookup+0x128>
    3694:      	ldr	x3, [x0, #0x78]
    3698:      	add	x3, x3, x1, lsl #2
    369c:      	ldr	w3, [x3]
    36a0:      	sxtw	x3, w3
    36a4:      	cmp	x3, #0x0
    36a8:      	cset	w3, ge
    36ac:      	ubfx	x3, x3, #0, #8
    36b0:      	b	0x3780 <_stogir.graph.lookup+0x12c>
    36b4:      	cmp	x1, #0x0
    36b8:      	b.ge	0x370c <_stogir.graph.lookup+0xb8>
    36bc:      	add	x5, x0, #0x28
    36c0:      	add	x6, x0, #0x50
    36c4:      	ldr	x5, [x5, #0x8]
    36c8:      	ldr	x6, [x6, #0x8]
    36cc:      	cmp	x5, x6
    36d0:      	b.ne	0x36fc <_stogir.graph.lookup+0xa8>
    36d4:      	cmp	x3, x5
    36d8:      	b.gt	0x3784 <_stogir.graph.lookup+0x130>
    36dc:      	ldr	x3, [x0, #0x50]
    36e0:      	add	x3, x3, x4, lsl #2
    36e4:      	ldr	w3, [x3]
    36e8:      	sxtw	x3, w3
    36ec:      	cmp	x3, #0x0
    36f0:      	cset	w3, gt
    36f4:      	ubfx	x3, x3, #0, #8
    36f8:      	b	0x3788 <_stogir.graph.lookup+0x134>
    36fc:      	movz	x3, #0x0, lsl #48
    3700:      	b	0x3710 <_stogir.graph.lookup+0xbc>
    3704:      	movz	x3, #0x0, lsl #48
    3708:      	b	0x3710 <_stogir.graph.lookup+0xbc>
    370c:      	movz	x3, #0x0, lsl #48
    3710:      	cmp	x3, #0x0
    3714:      	b.eq	0x3750 <_stogir.graph.lookup+0xfc>
    3718:      	uxtb	w16, w2
    371c:      	cmp	w16, wzr
    3720:      	b.eq	0x3738 <_stogir.graph.lookup+0xe4>
    3724:      	ldr	x0, [x0]
    3728:      	add	x0, x0, x1, lsl #4
    372c:      	ldr	x1, [x0]
    3730:      	ldr	x0, [x0, #0x8]
    3734:      	b	0x3748 <_stogir.graph.lookup+0xf4>
    3738:      	ldr	x0, [x0, #0x28]
    373c:      	add	x0, x0, x4, lsl #4
    3740:      	ldr	x1, [x0]
    3744:      	ldr	x0, [x0, #0x8]
    3748:      	mov	x2, #0x1                ; =1
    374c:      	b	0x375c <_stogir.graph.lookup+0x108>
    3750:      	movz	x2, #0x0, lsl #48
    3754:      	movz	x1, #0x0, lsl #48
    3758:      	movz	x0, #0x0, lsl #48
    375c:      	str	x2, [x8]
    3760:      	str	x1, [x8, #0x8]
    3764:      	str	x0, [x8, #0x10]
    3768:      	movz	x17, #0x0, lsl #48
    376c:      	str	x17, [x8, #0x18]
    3770:      	movz	x17, #0x0, lsl #48
    3774:      	str	x17, [x8, #0x20]
    3778:      	ret
    377c:      	movz	x3, #0x0, lsl #48
    3780:      	b	0x3708 <_stogir.graph.lookup+0xb4>
    3784:      	movz	x3, #0x0, lsl #48
    3788:      	b	0x3700 <_stogir.graph.lookup+0xac>

000000000000378c <_stogir.checked.validate-projection>:
    378c:      	sub	sp, sp, #0x40
    3790:      	str	x29, [sp]
    3794:      	str	x30, [sp, #0x8]
    3798:      	mov	x29, sp
    379c:      	str	x19, [sp, #0x30]
    37a0:      	sxtw	x1, w1
    37a4:      	lsl	x2, x1, #2
    37a8:      	cmp	x1, #0x0
    37ac:      	cset	w3, gt
    37b0:      	movz	x16, #0x0, lsl #48
    37b4:      	sub	x4, x16, x1
    37b8:      	sub	x5, x4, #0x1
    37bc:      	uxtb	w16, w3
    37c0:      	cmp	w16, wzr
    37c4:      	b.eq	0x3804 <_stogir.checked.validate-projection+0x78>
    37c8:      	ldr	x4, [x0, #0x8]
    37cc:      	cmp	x1, x4
    37d0:      	b.ge	0x3854 <_stogir.checked.validate-projection+0xc8>
    37d4:      	add	x4, x0, #0x78
    37d8:      	ldr	x4, [x4, #0x8]
    37dc:      	cmp	x1, x4
    37e0:      	b.ge	0x392c <_stogir.checked.validate-projection+0x1a0>
    37e4:      	ldr	x4, [x0, #0x78]
    37e8:      	add	x4, x2, x4
    37ec:      	ldr	w4, [x4]
    37f0:      	sxtw	x4, w4
    37f4:      	cmp	x4, #0x0
    37f8:      	cset	w4, ge
    37fc:      	ubfx	x4, x4, #0, #8
    3800:      	b	0x3930 <_stogir.checked.validate-projection+0x1a4>
    3804:      	cmp	x1, #0x0
    3808:      	b.ge	0x385c <_stogir.checked.validate-projection+0xd0>
    380c:      	add	x6, x0, #0x28
    3810:      	add	x7, x0, #0x50
    3814:      	ldr	x6, [x6, #0x8]
    3818:      	ldr	x7, [x7, #0x8]
    381c:      	cmp	x6, x7
    3820:      	b.ne	0x384c <_stogir.checked.validate-projection+0xc0>
    3824:      	cmp	x4, x6
    3828:      	b.gt	0x3998 <_stogir.checked.validate-projection+0x20c>
    382c:      	ldr	x4, [x0, #0x50]
    3830:      	add	x4, x4, x5, lsl #2
    3834:      	ldr	w4, [x4]
    3838:      	sxtw	x4, w4
    383c:      	cmp	x4, #0x0
    3840:      	cset	w4, gt
    3844:      	ubfx	x4, x4, #0, #8
    3848:      	b	0x399c <_stogir.checked.validate-projection+0x210>
    384c:      	movz	x4, #0x0, lsl #48
    3850:      	b	0x3860 <_stogir.checked.validate-projection+0xd4>
    3854:      	movz	x4, #0x0, lsl #48
    3858:      	b	0x3860 <_stogir.checked.validate-projection+0xd4>
    385c:      	movz	x4, #0x0, lsl #48
    3860:      	cmp	x4, #0x0
    3864:      	b.eq	0x3898 <_stogir.checked.validate-projection+0x10c>
    3868:      	uxtb	w16, w3
    386c:      	cmp	w16, wzr
    3870:      	b.eq	0x3884 <_stogir.checked.validate-projection+0xf8>
    3874:      	ldr	x3, [x0]
    3878:      	add	x3, x3, x1, lsl #4
    387c:      	ldr	x3, [x3]
    3880:      	b	0x3890 <_stogir.checked.validate-projection+0x104>
    3884:      	ldr	x3, [x0, #0x28]
    3888:      	add	x3, x3, x5, lsl #4
    388c:      	ldr	x3, [x3]
    3890:      	mov	x4, #0x1                ; =1
    3894:      	b	0x38a0 <_stogir.checked.validate-projection+0x114>
    3898:      	movz	x4, #0x0, lsl #48
    389c:      	movz	x3, #0x0, lsl #48
    38a0:      	ubfx	x4, x4, #0, #32
    38a4:      	lsr	x16, x4, #0
    38a8:      	cmp	x16, #0x1
    38ac:      	b.eq	0x38c8 <_stogir.checked.validate-projection+0x13c>
    38b0:      	b.lo	0x38b8 <_stogir.checked.validate-projection+0x12c>
    38b4:      	b	0x38cc <_stogir.checked.validate-projection+0x140>
    38b8:      	cmp	x16, #0x0
    38bc:      	b.eq	0x38c4 <_stogir.checked.validate-projection+0x138>
    38c0:      	b	0x38cc <_stogir.checked.validate-projection+0x140>
    38c4:      	b	0x38d0 <_stogir.checked.validate-projection+0x144>
    38c8:      	b	0x38ec <_stogir.checked.validate-projection+0x160>
    38cc:      	b	0x39a0 <_stogir.checked.validate-projection+0x214>
    38d0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		00000000000038d0:  ARM64_RELOC_PAGE21	l_stogir.364
    38d4:      	ldr	x16, [x16]
		00000000000038d4:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    38d8:      	orr	x0, x16, xzr
    38dc:      	mov	x19, x8
    38e0:      	mov	x1, #0x1                ; =1
    38e4:      	mov	x2, #0x10               ; =16
    38e8:      	b	0x390c <_stogir.checked.validate-projection+0x180>
    38ec:      	cmp	x1, #0x0
    38f0:      	b.gt	0x3934 <_stogir.checked.validate-projection+0x1a8>
    38f4:      	mov	x19, x8
    38f8:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		00000000000038f8:  ARM64_RELOC_PAGE21	l_stogir.365
    38fc:      	ldr	x16, [x16]
		00000000000038fc:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    3900:      	orr	x0, x16, xzr
    3904:      	mov	x1, #0x1                ; =1
    3908:      	mov	x2, #0x1c               ; =28
    390c:      	str	x1, [x19]
    3910:      	str	x0, [x19, #0x8]
    3914:      	str	x2, [x19, #0x10]
    3918:      	ldr	x19, [sp, #0x30]
    391c:      	ldr	x29, [sp]
    3920:      	ldr	x30, [sp, #0x8]
    3924:      	add	sp, sp, #0x40
    3928:      	ret
    392c:      	movz	x4, #0x0, lsl #48
    3930:      	b	0x3858 <_stogir.checked.validate-projection+0xcc>
    3934:      	uxtb	w1, w3
    3938:      	cmp	x1, #0x2c
    393c:      	b.ne	0x39a8 <_stogir.checked.validate-projection+0x21c>
    3940:      	orr	w1, w3, wzr
    3944:      	ubfx	x1, x1, #0, #32
    3948:      	ubfx	x1, x1, #8, #8
    394c:      	cmp	x1, #0x1
    3950:      	b.ne	0x39b0 <_stogir.checked.validate-projection+0x224>
    3954:      	ldr	x1, [x0, #0x78]
    3958:      	add	x1, x2, x1
    395c:      	ldr	w1, [x1]
    3960:      	sxtw	x1, w1
    3964:      	cmp	x1, #0x1
    3968:      	b.ne	0x39b8 <_stogir.checked.validate-projection+0x22c>
    396c:      	lsr	x1, x3, #32
    3970:      	mov	x19, x8
    3974:      	add	x8, sp, #0x10
    3978:      	bl	0x3978 <_stogir.checked.validate-projection+0x1ec>
		0000000000003978:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    397c:      	add	x16, sp, #0x10
    3980:      	ldr	x1, [x16]
    3984:      	add	x16, sp, #0x10
    3988:      	ldr	x0, [x16, #0x8]
    398c:      	add	x16, sp, #0x10
    3990:      	ldr	x2, [x16, #0x10]
    3994:      	b	0x390c <_stogir.checked.validate-projection+0x180>
    3998:      	movz	x4, #0x0, lsl #48
    399c:      	b	0x3850 <_stogir.checked.validate-projection+0xc4>
    39a0:      	brk	#0
    39a4:      	b	0x39a0 <_stogir.checked.validate-projection+0x214>
    39a8:      	mov	x19, x8
    39ac:      	b	0x38f8 <_stogir.checked.validate-projection+0x16c>
    39b0:      	mov	x19, x8
    39b4:      	b	0x38f8 <_stogir.checked.validate-projection+0x16c>
    39b8:      	mov	x19, x8
    39bc:      	b	0x38f8 <_stogir.checked.validate-projection+0x16c>

00000000000039c0 <_stogir.checked.validate>:
    39c0:      	sub	sp, sp, #0x30
    39c4:      	str	x29, [sp]
    39c8:      	str	x30, [sp, #0x8]
    39cc:      	mov	x29, sp
    39d0:      	str	x19, [sp, #0x10]
    39d4:      	str	x20, [sp, #0x18]
    39d8:      	str	x21, [sp, #0x20]
    39dc:      	sxtw	x1, w1
    39e0:      	lsl	x2, x1, #2
    39e4:      	cmp	x1, #0x0
    39e8:      	cset	w3, gt
    39ec:      	movz	x16, #0x0, lsl #48
    39f0:      	sub	x4, x16, x1
    39f4:      	sub	x5, x4, #0x1
    39f8:      	uxtb	w16, w3
    39fc:      	cmp	w16, wzr
    3a00:      	b.eq	0x3a40 <_stogir.checked.validate+0x80>
    3a04:      	ldr	x4, [x0, #0x8]
    3a08:      	cmp	x1, x4
    3a0c:      	b.ge	0x3a90 <_stogir.checked.validate+0xd0>
    3a10:      	add	x4, x0, #0x78
    3a14:      	ldr	x4, [x4, #0x8]
    3a18:      	cmp	x1, x4
    3a1c:      	b.ge	0x3bf4 <_stogir.checked.validate+0x234>
    3a20:      	ldr	x4, [x0, #0x78]
    3a24:      	add	x4, x2, x4
    3a28:      	ldr	w4, [x4]
    3a2c:      	sxtw	x4, w4
    3a30:      	cmp	x4, #0x0
    3a34:      	cset	w4, ge
    3a38:      	ubfx	x4, x4, #0, #8
    3a3c:      	b	0x3bf8 <_stogir.checked.validate+0x238>
    3a40:      	cmp	x1, #0x0
    3a44:      	b.ge	0x3a98 <_stogir.checked.validate+0xd8>
    3a48:      	add	x6, x0, #0x28
    3a4c:      	add	x7, x0, #0x50
    3a50:      	ldr	x6, [x6, #0x8]
    3a54:      	ldr	x7, [x7, #0x8]
    3a58:      	cmp	x6, x7
    3a5c:      	b.ne	0x3a88 <_stogir.checked.validate+0xc8>
    3a60:      	cmp	x4, x6
    3a64:      	b.gt	0x3bfc <_stogir.checked.validate+0x23c>
    3a68:      	ldr	x4, [x0, #0x50]
    3a6c:      	add	x4, x4, x5, lsl #2
    3a70:      	ldr	w4, [x4]
    3a74:      	sxtw	x4, w4
    3a78:      	cmp	x4, #0x0
    3a7c:      	cset	w4, gt
    3a80:      	ubfx	x4, x4, #0, #8
    3a84:      	b	0x3c00 <_stogir.checked.validate+0x240>
    3a88:      	movz	x4, #0x0, lsl #48
    3a8c:      	b	0x3a9c <_stogir.checked.validate+0xdc>
    3a90:      	movz	x4, #0x0, lsl #48
    3a94:      	b	0x3a9c <_stogir.checked.validate+0xdc>
    3a98:      	movz	x4, #0x0, lsl #48
    3a9c:      	cmp	x4, #0x0
    3aa0:      	b.eq	0x3adc <_stogir.checked.validate+0x11c>
    3aa4:      	uxtb	w16, w3
    3aa8:      	cmp	w16, wzr
    3aac:      	b.eq	0x3ac4 <_stogir.checked.validate+0x104>
    3ab0:      	ldr	x3, [x0]
    3ab4:      	add	x3, x3, x1, lsl #4
    3ab8:      	ldr	x4, [x3]
    3abc:      	ldr	x3, [x3, #0x8]
    3ac0:      	b	0x3ad4 <_stogir.checked.validate+0x114>
    3ac4:      	ldr	x3, [x0, #0x28]
    3ac8:      	add	x3, x3, x5, lsl #4
    3acc:      	ldr	x4, [x3]
    3ad0:      	ldr	x3, [x3, #0x8]
    3ad4:      	mov	x5, #0x1                ; =1
    3ad8:      	b	0x3ae8 <_stogir.checked.validate+0x128>
    3adc:      	movz	x5, #0x0, lsl #48
    3ae0:      	movz	x4, #0x0, lsl #48
    3ae4:      	movz	x3, #0x0, lsl #48
    3ae8:      	ubfx	x5, x5, #0, #32
    3aec:      	lsr	x16, x5, #0
    3af0:      	cmp	x16, #0x1
    3af4:      	b.eq	0x3b10 <_stogir.checked.validate+0x150>
    3af8:      	b.lo	0x3b00 <_stogir.checked.validate+0x140>
    3afc:      	b	0x3b14 <_stogir.checked.validate+0x154>
    3b00:      	cmp	x16, #0x0
    3b04:      	b.eq	0x3b0c <_stogir.checked.validate+0x14c>
    3b08:      	b	0x3b14 <_stogir.checked.validate+0x154>
    3b0c:      	b	0x3b18 <_stogir.checked.validate+0x158>
    3b10:      	b	0x3b70 <_stogir.checked.validate+0x1b0>
    3b14:      	b	0x3e28 <_stogir.checked.validate+0x468>
    3b18:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003b18:  ARM64_RELOC_PAGE21	l_stogir.366
    3b1c:      	ldr	x16, [x16]
		0000000000003b1c:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    3b20:      	orr	x1, x16, xzr
    3b24:      	mov	x0, #0x1                ; =1
    3b28:      	mov	x9, #0x1a               ; =26
    3b2c:      	b	0x3b44 <_stogir.checked.validate+0x184>
    3b30:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003b30:  ARM64_RELOC_PAGE21	l_stogir.367
    3b34:      	ldr	x16, [x16]
		0000000000003b34:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    3b38:      	orr	x1, x16, xzr
    3b3c:      	mov	x0, #0x1                ; =1
    3b40:      	mov	x9, #0x26               ; =38
    3b44:      	str	x0, [x8]
    3b48:      	str	x1, [x8, #0x8]
    3b4c:      	str	x9, [x8, #0x10]
    3b50:      	sub	sp, x29, #0x0
    3b54:      	ldr	x19, [sp, #0x10]
    3b58:      	ldr	x20, [sp, #0x18]
    3b5c:      	ldr	x21, [sp, #0x20]
    3b60:      	ldr	x29, [sp]
    3b64:      	ldr	x30, [sp, #0x8]
    3b68:      	add	sp, sp, #0x30
    3b6c:      	ret
    3b70:      	cmp	x1, #0x0
    3b74:      	b.le	0x3b30 <_stogir.checked.validate+0x170>
    3b78:      	uxtb	w1, w4
    3b7c:      	cmp	x1, #0x29
    3b80:      	b.lt	0x3b30 <_stogir.checked.validate+0x170>
    3b84:      	cmp	x1, #0x2b
    3b88:      	b.gt	0x3b30 <_stogir.checked.validate+0x170>
    3b8c:      	ldr	x1, [x0, #0x78]
    3b90:      	add	x1, x2, x1
    3b94:      	ldr	w1, [x1]
    3b98:      	sxtw	x1, w1
    3b9c:      	cmp	x1, #0x2
    3ba0:      	b.ne	0x3b30 <_stogir.checked.validate+0x170>
    3ba4:      	orr	w1, w4, wzr
    3ba8:      	mov	x2, sp
    3bac:      	ubfx	x1, x1, #0, #32
    3bb0:      	sub	sp, sp, #0x10
    3bb4:      	mov	x5, sp
    3bb8:      	sub	sp, sp, #0x10
    3bbc:      	mov	x6, sp
    3bc0:      	ubfx	x1, x1, #8, #8
    3bc4:      	orr	x7, x1, xzr
    3bc8:      	cmp	x7, #0x1
    3bcc:      	b.lt	0x3dc4 <_stogir.checked.validate+0x404>
    3bd0:      	cmp	x7, #0xb
    3bd4:      	b.gt	0x3dc4 <_stogir.checked.validate+0x404>
    3bd8:      	cmp	x7, #0x1
    3bdc:      	b.eq	0x3dc4 <_stogir.checked.validate+0x404>
    3be0:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003be0:  ARM64_RELOC_PAGE21	l_stogir.368
    3be4:      	ldr	x16, [x16]
		0000000000003be4:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    3be8:      	orr	x1, x16, xzr
    3bec:      	movz	x9, #0x0, lsl #48
    3bf0:      	b	0x3dd4 <_stogir.checked.validate+0x414>
    3bf4:      	movz	x4, #0x0, lsl #48
    3bf8:      	b	0x3a94 <_stogir.checked.validate+0xd4>
    3bfc:      	movz	x4, #0x0, lsl #48
    3c00:      	b	0x3a8c <_stogir.checked.validate+0xcc>
    3c04:      	mov	x0, #0x1                ; =1
    3c08:      	mov	sp, x2
    3c0c:      	b	0x3b44 <_stogir.checked.validate+0x184>
    3c10:      	movz	x5, #0x0, lsl #48
    3c14:      	movz	x4, #0x0, lsl #48
    3c18:      	ubfx	x5, x5, #0, #32
    3c1c:      	lsr	x16, x5, #0
    3c20:      	cmp	x16, #0x1
    3c24:      	b.eq	0x3c40 <_stogir.checked.validate+0x280>
    3c28:      	b.lo	0x3c30 <_stogir.checked.validate+0x270>
    3c2c:      	b	0x3c44 <_stogir.checked.validate+0x284>
    3c30:      	cmp	x16, #0x0
    3c34:      	b.eq	0x3c3c <_stogir.checked.validate+0x27c>
    3c38:      	b	0x3c44 <_stogir.checked.validate+0x284>
    3c3c:      	b	0x3c48 <_stogir.checked.validate+0x288>
    3c40:      	b	0x3da8 <_stogir.checked.validate+0x3e8>
    3c44:      	b	0x3e40 <_stogir.checked.validate+0x480>
    3c48:      	mov	x1, x11
    3c4c:      	mov	x9, #0x22               ; =34
    3c50:      	cmp	x3, #0x2
    3c54:      	b.ge	0x3c78 <_stogir.checked.validate+0x2b8>
    3c58:      	add	x4, x3, #0x1
    3c5c:      	add	x3, x10, x3, lsl #2
    3c60:      	ldr	w3, [x3]
    3c64:      	sxtw	x3, w3
    3c68:      	and	x5, x3, #0xffffffff
    3c6c:      	mov	x3, x4
    3c70:      	mov	x4, #0x1                ; =1
    3c74:      	b	0x3c80 <_stogir.checked.validate+0x2c0>
    3c78:      	movz	x4, #0x0, lsl #48
    3c7c:      	movz	x5, #0x0, lsl #48
    3c80:      	ubfx	x4, x4, #0, #32
    3c84:      	lsr	x16, x4, #0
    3c88:      	cmp	x16, #0x1
    3c8c:      	b.eq	0x3ca8 <_stogir.checked.validate+0x2e8>
    3c90:      	b.lo	0x3c98 <_stogir.checked.validate+0x2d8>
    3c94:      	b	0x3cac <_stogir.checked.validate+0x2ec>
    3c98:      	cmp	x16, #0x0
    3c9c:      	b.eq	0x3ca4 <_stogir.checked.validate+0x2e4>
    3ca0:      	b	0x3cac <_stogir.checked.validate+0x2ec>
    3ca4:      	b	0x3d0c <_stogir.checked.validate+0x34c>
    3ca8:      	b	0x3cb0 <_stogir.checked.validate+0x2f0>
    3cac:      	b	0x3e38 <_stogir.checked.validate+0x478>
    3cb0:      	sxtw	x5, w5
    3cb4:      	cmp	x5, #0x0
    3cb8:      	cset	w4, gt
    3cbc:      	movz	x16, #0x0, lsl #48
    3cc0:      	sub	x6, x16, x5
    3cc4:      	sub	x19, x6, #0x1
    3cc8:      	uxtb	w16, w4
    3ccc:      	cmp	w16, wzr
    3cd0:      	b.eq	0x3d68 <_stogir.checked.validate+0x3a8>
    3cd4:      	ldr	x6, [x0, #0x8]
    3cd8:      	cmp	x5, x6
    3cdc:      	b.ge	0x3d60 <_stogir.checked.validate+0x3a0>
    3ce0:      	ldr	x6, [x13, #0x8]
    3ce4:      	cmp	x5, x6
    3ce8:      	b.ge	0x3e20 <_stogir.checked.validate+0x460>
    3cec:      	ldr	x6, [x0, #0x78]
    3cf0:      	add	x6, x6, x5, lsl #2
    3cf4:      	ldr	w6, [x6]
    3cf8:      	sxtw	x6, w6
    3cfc:      	cmp	x6, #0x0
    3d00:      	cset	w6, ge
    3d04:      	ubfx	x6, x6, #0, #8
    3d08:      	b	0x3e24 <_stogir.checked.validate+0x464>
    3d0c:      	cmp	x9, #0x0
    3d10:      	b.ne	0x3c04 <_stogir.checked.validate+0x244>
    3d14:      	and	x1, x7, #0xffffffff
    3d18:      	movz	x0, #0x0, lsl #48
    3d1c:      	movz	x9, #0x0, lsl #48
    3d20:      	b	0x3c08 <_stogir.checked.validate+0x248>
    3d24:      	ldr	x4, [x0, #0x28]
    3d28:      	add	x4, x4, x19, lsl #4
    3d2c:      	ldr	x4, [x4]
    3d30:      	mov	x5, #0x1                ; =1
    3d34:      	b	0x3c18 <_stogir.checked.validate+0x258>
    3d38:      	movz	x6, #0x0, lsl #48
    3d3c:      	cmp	x6, #0x0
    3d40:      	b.eq	0x3c10 <_stogir.checked.validate+0x250>
    3d44:      	uxtb	w16, w4
    3d48:      	cmp	w16, wzr
    3d4c:      	b.eq	0x3d24 <_stogir.checked.validate+0x364>
    3d50:      	ldr	x4, [x0]
    3d54:      	add	x4, x4, x5, lsl #4
    3d58:      	ldr	x4, [x4]
    3d5c:      	b	0x3d30 <_stogir.checked.validate+0x370>
    3d60:      	movz	x6, #0x0, lsl #48
    3d64:      	b	0x3d3c <_stogir.checked.validate+0x37c>
    3d68:      	cmp	x5, #0x0
    3d6c:      	b.ge	0x3d38 <_stogir.checked.validate+0x378>
    3d70:      	ldr	x20, [x14, #0x8]
    3d74:      	ldr	x21, [x15, #0x8]
    3d78:      	cmp	x20, x21
    3d7c:      	b.ne	0x3e18 <_stogir.checked.validate+0x458>
    3d80:      	cmp	x6, x20
    3d84:      	b.gt	0x3e30 <_stogir.checked.validate+0x470>
    3d88:      	ldr	x6, [x0, #0x50]
    3d8c:      	add	x6, x6, x19, lsl #2
    3d90:      	ldr	w6, [x6]
    3d94:      	sxtw	x6, w6
    3d98:      	cmp	x6, #0x0
    3d9c:      	cset	w6, gt
    3da0:      	ubfx	x6, x6, #0, #8
    3da4:      	b	0x3e34 <_stogir.checked.validate+0x474>
    3da8:      	ubfx	x4, x4, #0, #32
    3dac:      	ubfx	x4, x4, #8, #8
    3db0:      	cmp	x4, x7
    3db4:      	b.eq	0x3dc0 <_stogir.checked.validate+0x400>
    3db8:      	mov	x1, x12
    3dbc:      	mov	x9, #0x28               ; =40
    3dc0:      	b	0x3c50 <_stogir.checked.validate+0x290>
    3dc4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003dc4:  ARM64_RELOC_PAGE21	l_stogir.369
    3dc8:      	ldr	x16, [x16]
		0000000000003dc8:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    3dcc:      	orr	x1, x16, xzr
    3dd0:      	mov	x9, #0x36               ; =54
    3dd4:      	orr	x10, x6, xzr
    3dd8:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003dd8:  ARM64_RELOC_PAGE21	l_stogir.370
    3ddc:      	ldr	x16, [x16]
		0000000000003ddc:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    3de0:      	orr	x11, x16, xzr
    3de4:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003de4:  ARM64_RELOC_PAGE21	l_stogir.371
    3de8:      	ldr	x16, [x16]
		0000000000003de8:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    3dec:      	orr	x12, x16, xzr
    3df0:      	add	x13, x0, #0x78
    3df4:      	add	x14, x0, #0x28
    3df8:      	add	x15, x0, #0x50
    3dfc:      	lsr	x4, x4, #32
    3e00:      	str	w4, [x5]
    3e04:      	str	w3, [x5, #0x4]
    3e08:      	ldr	x3, [x5]
    3e0c:      	str	x3, [x6]
    3e10:      	movz	x3, #0x0, lsl #48
    3e14:      	b	0x3c50 <_stogir.checked.validate+0x290>
    3e18:      	movz	x6, #0x0, lsl #48
    3e1c:      	b	0x3d3c <_stogir.checked.validate+0x37c>
    3e20:      	movz	x6, #0x0, lsl #48
    3e24:      	b	0x3d64 <_stogir.checked.validate+0x3a4>
    3e28:      	brk	#0
    3e2c:      	b	0x3e28 <_stogir.checked.validate+0x468>
    3e30:      	movz	x6, #0x0, lsl #48
    3e34:      	b	0x3e1c <_stogir.checked.validate+0x45c>
    3e38:      	brk	#0
    3e3c:      	b	0x3e38 <_stogir.checked.validate+0x478>
    3e40:      	brk	#0
    3e44:      	b	0x3e40 <_stogir.checked.validate+0x480>

0000000000003e48 <_stogir.atomic.validate>:
    3e48:      	sub	sp, sp, #0xf0
    3e4c:      	str	x29, [sp, #0x10]
    3e50:      	str	x30, [sp, #0x18]
    3e54:      	add	x29, sp, #0x10
    3e58:      	str	x19, [sp, #0xa0]
    3e5c:      	str	x20, [sp, #0xa8]
    3e60:      	str	x21, [sp, #0xb0]
    3e64:      	str	x22, [sp, #0xb8]
    3e68:      	str	x23, [sp, #0xc0]
    3e6c:      	str	x24, [sp, #0xc8]
    3e70:      	str	x25, [sp, #0xd0]
    3e74:      	str	x26, [sp, #0xd8]
    3e78:      	str	x27, [sp, #0xe0]
    3e7c:      	sxtw	x2, w1
    3e80:      	lsl	x3, x2, #2
    3e84:      	cmp	x2, #0x0
    3e88:      	cset	w4, gt
    3e8c:      	movz	x16, #0x0, lsl #48
    3e90:      	sub	x5, x16, x2
    3e94:      	sub	x6, x5, #0x1
    3e98:      	uxtb	w16, w4
    3e9c:      	cmp	w16, wzr
    3ea0:      	b.eq	0x3ee0 <_stogir.atomic.validate+0x98>
    3ea4:      	ldr	x5, [x0, #0x8]
    3ea8:      	cmp	x2, x5
    3eac:      	b.ge	0x3f30 <_stogir.atomic.validate+0xe8>
    3eb0:      	add	x5, x0, #0x78
    3eb4:      	ldr	x5, [x5, #0x8]
    3eb8:      	cmp	x2, x5
    3ebc:      	b.ge	0x4070 <_stogir.atomic.validate+0x228>
    3ec0:      	ldr	x5, [x0, #0x78]
    3ec4:      	add	x5, x3, x5
    3ec8:      	ldr	w5, [x5]
    3ecc:      	sxtw	x5, w5
    3ed0:      	cmp	x5, #0x0
    3ed4:      	cset	w5, ge
    3ed8:      	ubfx	x5, x5, #0, #8
    3edc:      	b	0x4074 <_stogir.atomic.validate+0x22c>
    3ee0:      	cmp	x2, #0x0
    3ee4:      	b.ge	0x3f38 <_stogir.atomic.validate+0xf0>
    3ee8:      	add	x7, x0, #0x28
    3eec:      	add	x9, x0, #0x50
    3ef0:      	ldr	x7, [x7, #0x8]
    3ef4:      	ldr	x9, [x9, #0x8]
    3ef8:      	cmp	x7, x9
    3efc:      	b.ne	0x3f28 <_stogir.atomic.validate+0xe0>
    3f00:      	cmp	x5, x7
    3f04:      	b.gt	0x40f8 <_stogir.atomic.validate+0x2b0>
    3f08:      	ldr	x5, [x0, #0x50]
    3f0c:      	add	x5, x5, x6, lsl #2
    3f10:      	ldr	w5, [x5]
    3f14:      	sxtw	x5, w5
    3f18:      	cmp	x5, #0x0
    3f1c:      	cset	w5, gt
    3f20:      	ubfx	x5, x5, #0, #8
    3f24:      	b	0x40fc <_stogir.atomic.validate+0x2b4>
    3f28:      	movz	x5, #0x0, lsl #48
    3f2c:      	b	0x3f3c <_stogir.atomic.validate+0xf4>
    3f30:      	movz	x5, #0x0, lsl #48
    3f34:      	b	0x3f3c <_stogir.atomic.validate+0xf4>
    3f38:      	movz	x5, #0x0, lsl #48
    3f3c:      	cmp	x5, #0x0
    3f40:      	b.eq	0x3f7c <_stogir.atomic.validate+0x134>
    3f44:      	uxtb	w16, w4
    3f48:      	cmp	w16, wzr
    3f4c:      	b.eq	0x3f64 <_stogir.atomic.validate+0x11c>
    3f50:      	ldr	x4, [x0]
    3f54:      	add	x4, x4, x2, lsl #4
    3f58:      	ldr	x19, [x4]
    3f5c:      	ldr	x4, [x4, #0x8]
    3f60:      	b	0x3f74 <_stogir.atomic.validate+0x12c>
    3f64:      	ldr	x4, [x0, #0x28]
    3f68:      	add	x4, x4, x6, lsl #4
    3f6c:      	ldr	x19, [x4]
    3f70:      	ldr	x4, [x4, #0x8]
    3f74:      	mov	x5, #0x1                ; =1
    3f78:      	b	0x3f88 <_stogir.atomic.validate+0x140>
    3f7c:      	movz	x5, #0x0, lsl #48
    3f80:      	movz	x19, #0x0, lsl #48
    3f84:      	movz	x4, #0x0, lsl #48
    3f88:      	ubfx	x5, x5, #0, #32
    3f8c:      	lsr	x16, x5, #0
    3f90:      	cmp	x16, #0x1
    3f94:      	b.eq	0x3fb0 <_stogir.atomic.validate+0x168>
    3f98:      	b.lo	0x3fa0 <_stogir.atomic.validate+0x158>
    3f9c:      	b	0x3fb4 <_stogir.atomic.validate+0x16c>
    3fa0:      	cmp	x16, #0x0
    3fa4:      	b.eq	0x3fac <_stogir.atomic.validate+0x164>
    3fa8:      	b	0x3fb4 <_stogir.atomic.validate+0x16c>
    3fac:      	b	0x3fb8 <_stogir.atomic.validate+0x170>
    3fb0:      	b	0x4010 <_stogir.atomic.validate+0x1c8>
    3fb4:      	b	0x45b4 <_stogir.atomic.validate+0x76c>
    3fb8:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x7b0>
		0000000000003fb8:  ARM64_RELOC_PAGE21	l_stogir.372
    3fbc:      	ldr	x16, [x16]
		0000000000003fbc:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    3fc0:      	orr	x20, x16, xzr
    3fc4:      	mov	x23, x8
    3fc8:      	mov	x0, #0x1                ; =1
    3fcc:      	mov	x22, #0x1a              ; =26
    3fd0:      	str	x0, [x23]
    3fd4:      	str	x20, [x23, #0x8]
    3fd8:      	str	x22, [x23, #0x10]
    3fdc:      	ldr	x19, [sp, #0xa0]
    3fe0:      	ldr	x20, [sp, #0xa8]
    3fe4:      	ldr	x21, [sp, #0xb0]
    3fe8:      	ldr	x22, [sp, #0xb8]
    3fec:      	ldr	x23, [sp, #0xc0]
    3ff0:      	ldr	x24, [sp, #0xc8]
    3ff4:      	ldr	x25, [sp, #0xd0]
    3ff8:      	ldr	x26, [sp, #0xd8]
    3ffc:      	ldr	x27, [sp, #0xe0]
    4000:      	ldr	x29, [sp, #0x10]
    4004:      	ldr	x30, [sp, #0x18]
    4008:      	add	sp, sp, #0xf0
    400c:      	ret
    4010:      	uxtb	w5, w19
    4014:      	add	x16, sp, #0x20
    4018:      	str	x19, [x16]
    401c:      	orr	x21, x5, xzr
    4020:      	add	x16, sp, #0x20
    4024:      	str	x4, [x16, #0x8]
    4028:      	cmp	x2, #0x0
    402c:      	b.le	0x4080 <_stogir.atomic.validate+0x238>
    4030:      	cmp	x21, #0x7e
    4034:      	b.lt	0x4080 <_stogir.atomic.validate+0x238>
    4038:      	cmp	x21, #0x82
    403c:      	b.gt	0x4080 <_stogir.atomic.validate+0x238>
    4040:      	ldr	x2, [x0, #0x78]
    4044:      	add	x2, x3, x2
    4048:      	ldr	w2, [x2]
    404c:      	cmp	x21, #0x83
    4050:      	b.ge	0x44e4 <_stogir.atomic.validate+0x69c>
    4054:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004054:  ARM64_RELOC_PAGE21	l_stogir.373
    4058:      	ldr	x16, [x16]
		0000000000004058:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    405c:      	orr	x3, x16, xzr
    4060:      	add	x3, x21, x3
    4064:      	ldrsb	w3, [x3]
    4068:      	sxtb	x3, w3
    406c:      	b	0x44e8 <_stogir.atomic.validate+0x6a0>
    4070:      	movz	x5, #0x0, lsl #48
    4074:      	b	0x3f34 <_stogir.atomic.validate+0xec>
    4078:      	mov	x0, #0x1                ; =1
    407c:      	b	0x3fd0 <_stogir.atomic.validate+0x188>
    4080:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004080:  ARM64_RELOC_PAGE21	l_stogir.374
    4084:      	ldr	x16, [x16]
		0000000000004084:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    4088:      	orr	x20, x16, xzr
    408c:      	mov	x22, #0x20              ; =32
    4090:      	add	x16, sp, #0x20
    4094:      	ldr	w2, [x16, #0x4]
    4098:      	mov	x23, x8
    409c:      	add	x8, sp, #0x30
    40a0:      	mov	x24, x0
    40a4:      	mov	w25, w1
    40a8:      	mov	w1, w2
    40ac:      	bl	0x40ac <_stogir.atomic.validate+0x264>
		00000000000040ac:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    40b0:      	add	x16, sp, #0x30
    40b4:      	ldr	w0, [x16]
    40b8:      	lsr	x16, x0, #0
    40bc:      	cmp	x16, #0x1
    40c0:      	b.eq	0x40dc <_stogir.atomic.validate+0x294>
    40c4:      	b.lo	0x40cc <_stogir.atomic.validate+0x284>
    40c8:      	b	0x40e0 <_stogir.atomic.validate+0x298>
    40cc:      	cmp	x16, #0x0
    40d0:      	b.eq	0x40d8 <_stogir.atomic.validate+0x290>
    40d4:      	b	0x40e0 <_stogir.atomic.validate+0x298>
    40d8:      	b	0x40e4 <_stogir.atomic.validate+0x29c>
    40dc:      	b	0x41a8 <_stogir.atomic.validate+0x360>
    40e0:      	b	0x45bc <_stogir.atomic.validate+0x774>
    40e4:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		00000000000040e4:  ARM64_RELOC_PAGE21	l_stogir.375
    40e8:      	ldr	x16, [x16]
		00000000000040e8:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    40ec:      	orr	x20, x16, xzr
    40f0:      	mov	x22, #0x16              ; =22
    40f4:      	b	0x411c <_stogir.atomic.validate+0x2d4>
    40f8:      	movz	x5, #0x0, lsl #48
    40fc:      	b	0x3f2c <_stogir.atomic.validate+0xe4>
    4100:      	mov	x0, #0x1                ; =1
    4104:      	cmp	x0, #0x0
    4108:      	b.eq	0x411c <_stogir.atomic.validate+0x2d4>
    410c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		000000000000410c:  ARM64_RELOC_PAGE21	l_stogir.376
    4110:      	ldr	x16, [x16]
		0000000000004110:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    4114:      	orr	x20, x16, xzr
    4118:      	mov	x22, #0x16              ; =22
    411c:      	cmp	x21, #0x82
    4120:      	cset	w26, eq
    4124:      	ubfx	x19, x19, #0, #32
    4128:      	ubfx	x0, x19, #8, #8
    412c:      	orr	x19, x0, xzr
    4130:      	cmp	x19, #0x0
    4134:      	cset	w27, eq
    4138:      	uxtb	w16, w26
    413c:      	cmp	w16, wzr
    4140:      	b.eq	0x4160 <_stogir.atomic.validate+0x318>
    4144:      	uxtb	w16, w27
    4148:      	cmp	w16, wzr
    414c:      	b.ne	0x4160 <_stogir.atomic.validate+0x318>
    4150:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004150:  ARM64_RELOC_PAGE21	l_stogir.377
    4154:      	ldr	x16, [x16]
		0000000000004154:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    4158:      	orr	x20, x16, xzr
    415c:      	mov	x22, #0x19              ; =25
    4160:      	uxtb	w16, w26
    4164:      	cmp	w16, wzr
    4168:      	b.eq	0x4174 <_stogir.atomic.validate+0x32c>
    416c:      	movz	x0, #0x0, lsl #48
    4170:      	b	0x4178 <_stogir.atomic.validate+0x330>
    4174:      	mov	x0, #0x1                ; =1
    4178:      	cmp	x0, #0x0
    417c:      	b.eq	0x41e8 <_stogir.atomic.validate+0x3a0>
    4180:      	add	x16, sp, #0x20
    4184:      	ldr	w0, [x16, #0x8]
    4188:      	mov	w1, w0
    418c:      	mov	x0, x24
    4190:      	mov	x2, #0x6                ; =6
    4194:      	bl	0x4194 <_stogir.atomic.validate+0x34c>
		0000000000004194:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4198:      	cmp	x0, #0x0
    419c:      	b.eq	0x42c0 <_stogir.atomic.validate+0x478>
    41a0:      	movz	x0, #0x0, lsl #48
    41a4:      	b	0x42c4 <_stogir.atomic.validate+0x47c>
    41a8:      	add	x16, sp, #0x30
    41ac:      	ldr	x0, [x16, #0x8]
    41b0:      	add	x16, sp, #0x20
    41b4:      	ldr	w1, [x16, #0x4]
    41b8:      	sxtw	x1, w1
    41bc:      	cmp	x1, #0x0
    41c0:      	b.gt	0x4360 <_stogir.atomic.validate+0x518>
    41c4:      	mov	x0, #0x1                ; =1
    41c8:      	b	0x4104 <_stogir.atomic.validate+0x2bc>
    41cc:      	movz	x0, #0x0, lsl #48
    41d0:      	cmp	x0, #0x0
    41d4:      	b.eq	0x41e8 <_stogir.atomic.validate+0x3a0>
    41d8:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		00000000000041d8:  ARM64_RELOC_PAGE21	l_stogir.378
    41dc:      	ldr	x16, [x16]
		00000000000041dc:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    41e0:      	orr	x20, x16, xzr
    41e4:      	mov	x22, #0x22              ; =34
    41e8:      	cmp	x21, #0x80
    41ec:      	cset	w27, eq
    41f0:      	uxtb	w16, w27
    41f4:      	cmp	w16, wzr
    41f8:      	b.eq	0x4204 <_stogir.atomic.validate+0x3bc>
    41fc:      	mov	x0, #0x1                ; =1
    4200:      	b	0x4210 <_stogir.atomic.validate+0x3c8>
    4204:      	cmp	x21, #0x81
    4208:      	cset	w0, eq
    420c:      	ubfx	x0, x0, #0, #8
    4210:      	cmp	x0, #0x0
    4214:      	b.eq	0x428c <_stogir.atomic.validate+0x444>
    4218:      	add	x16, sp, #0x90
    421c:      	str	x16, [sp]
    4220:      	mov	x0, x24
    4224:      	mov	w1, w25
    4228:      	mov	x2, #0x4                ; =4
    422c:      	bl	0x422c <_stogir.atomic.validate+0x3e4>
		000000000000422c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    4230:      	ldr	x16, [sp]
    4234:      	str	x0, [x16]
    4238:      	str	x1, [x16, #0x8]
    423c:      	add	x16, sp, #0x90
    4240:      	ldr	x0, [x16]
    4244:      	add	x16, sp, #0x90
    4248:      	ldr	x1, [x16, #0x8]
    424c:      	ubfx	x0, x0, #0, #32
    4250:      	lsr	x16, x0, #0
    4254:      	cmp	x16, #0x1
    4258:      	b.eq	0x4274 <_stogir.atomic.validate+0x42c>
    425c:      	b.lo	0x4264 <_stogir.atomic.validate+0x41c>
    4260:      	b	0x4278 <_stogir.atomic.validate+0x430>
    4264:      	cmp	x16, #0x0
    4268:      	b.eq	0x4270 <_stogir.atomic.validate+0x428>
    426c:      	b	0x4278 <_stogir.atomic.validate+0x430>
    4270:      	b	0x427c <_stogir.atomic.validate+0x434>
    4274:      	b	0x4438 <_stogir.atomic.validate+0x5f0>
    4278:      	b	0x45cc <_stogir.atomic.validate+0x784>
    427c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		000000000000427c:  ARM64_RELOC_PAGE21	l_stogir.379
    4280:      	ldr	x16, [x16]
		0000000000004280:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    4284:      	orr	x20, x16, xzr
    4288:      	mov	x22, #0x1d              ; =29
    428c:      	cmp	x22, #0x0
    4290:      	b.ne	0x4078 <_stogir.atomic.validate+0x230>
    4294:      	uxtb	w16, w26
    4298:      	cmp	w16, wzr
    429c:      	b.eq	0x4424 <_stogir.atomic.validate+0x5dc>
    42a0:      	movz	x0, #0x0, lsl #48
    42a4:      	b	0x42b0 <_stogir.atomic.validate+0x468>
    42a8:      	mov	x0, #0x1                ; =1
    42ac:      	sxtw	x0, w0
    42b0:      	and	x20, x0, #0xffffffff
    42b4:      	movz	x0, #0x0, lsl #48
    42b8:      	movz	x22, #0x0, lsl #48
    42bc:      	b	0x407c <_stogir.atomic.validate+0x234>
    42c0:      	mov	x0, #0x1                ; =1
    42c4:      	cmp	x0, #0x0
    42c8:      	b.eq	0x42dc <_stogir.atomic.validate+0x494>
    42cc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		00000000000042cc:  ARM64_RELOC_PAGE21	l_stogir.380
    42d0:      	ldr	x16, [x16]
		00000000000042d0:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    42d4:      	orr	x20, x16, xzr
    42d8:      	mov	x22, #0x1b              ; =27
    42dc:      	cmp	x21, #0x7f
    42e0:      	b.ne	0x43a4 <_stogir.atomic.validate+0x55c>
    42e4:      	uxtb	w16, w27
    42e8:      	cmp	w16, wzr
    42ec:      	b.ne	0x4300 <_stogir.atomic.validate+0x4b8>
    42f0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		00000000000042f0:  ARM64_RELOC_PAGE21	l_stogir.381
    42f4:      	ldr	x16, [x16]
		00000000000042f4:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    42f8:      	orr	x20, x16, xzr
    42fc:      	mov	x22, #0x19              ; =25
    4300:      	add	x16, sp, #0x20
    4304:      	ldr	w0, [x16, #0xc]
    4308:      	add	x8, sp, #0x60
    430c:      	mov	w1, w0
    4310:      	mov	x0, x24
    4314:      	bl	0x4314 <_stogir.atomic.validate+0x4cc>
		0000000000004314:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4318:      	add	x16, sp, #0x60
    431c:      	ldr	w0, [x16]
    4320:      	lsr	x16, x0, #0
    4324:      	cmp	x16, #0x1
    4328:      	b.eq	0x4344 <_stogir.atomic.validate+0x4fc>
    432c:      	b.lo	0x4334 <_stogir.atomic.validate+0x4ec>
    4330:      	b	0x4348 <_stogir.atomic.validate+0x500>
    4334:      	cmp	x16, #0x0
    4338:      	b.eq	0x4340 <_stogir.atomic.validate+0x4f8>
    433c:      	b	0x4348 <_stogir.atomic.validate+0x500>
    4340:      	b	0x434c <_stogir.atomic.validate+0x504>
    4344:      	b	0x4390 <_stogir.atomic.validate+0x548>
    4348:      	b	0x45d4 <_stogir.atomic.validate+0x78c>
    434c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		000000000000434c:  ARM64_RELOC_PAGE21	l_stogir.382
    4350:      	ldr	x16, [x16]
		0000000000004350:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    4354:      	orr	x20, x16, xzr
    4358:      	mov	x22, #0x1a              ; =26
    435c:      	b	0x43a4 <_stogir.atomic.validate+0x55c>
    4360:      	uxtb	w0, w0
    4364:      	cmp	x0, #0x83
    4368:      	cset	w1, lt
    436c:      	uxtb	w16, w1
    4370:      	cmp	w16, wzr
    4374:      	b.eq	0x44a8 <_stogir.atomic.validate+0x660>
    4378:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004378:  ARM64_RELOC_PAGE21	l_stogir.383
    437c:      	ldr	x16, [x16]
		000000000000437c:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    4380:      	orr	x2, x16, xzr
    4384:      	add	x2, x0, x2
    4388:      	ldrb	w2, [x2]
    438c:      	b	0x44ac <_stogir.atomic.validate+0x664>
    4390:      	add	x16, sp, #0x60
    4394:      	ldr	x0, [x16, #0x8]
    4398:      	ubfx	x0, x0, #0, #32
    439c:      	ubfx	x0, x0, #8, #8
    43a0:      	orr	x19, x0, xzr
    43a4:      	cmp	x19, #0x2
    43a8:      	b.ge	0x43f0 <_stogir.atomic.validate+0x5a8>
    43ac:      	mov	x0, #0x1                ; =1
    43b0:      	b	0x43fc <_stogir.atomic.validate+0x5b4>
    43b4:      	mov	x0, #0x1                ; =1
    43b8:      	b	0x41d0 <_stogir.atomic.validate+0x388>
    43bc:      	mov	x0, #0x1                ; =1
    43c0:      	cmp	x0, #0x0
    43c4:      	b.eq	0x41cc <_stogir.atomic.validate+0x384>
    43c8:      	orr	w0, w19, wzr
    43cc:      	add	x16, sp, #0x20
    43d0:      	ldr	w1, [x16, #0xc]
    43d4:      	mov	w2, w0
    43d8:      	mov	x0, x24
    43dc:      	bl	0x43dc <_stogir.atomic.validate+0x594>
		00000000000043dc:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    43e0:      	cmp	x0, #0x0
    43e4:      	b.eq	0x43b4 <_stogir.atomic.validate+0x56c>
    43e8:      	movz	x0, #0x0, lsl #48
    43ec:      	b	0x43b8 <_stogir.atomic.validate+0x570>
    43f0:      	cmp	x19, #0x5
    43f4:      	cset	w0, gt
    43f8:      	ubfx	x0, x0, #0, #8
    43fc:      	cmp	x0, #0x0
    4400:      	b.eq	0x4414 <_stogir.atomic.validate+0x5cc>
    4404:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004404:  ARM64_RELOC_PAGE21	l_stogir.384
    4408:      	ldr	x16, [x16]
		0000000000004408:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    440c:      	orr	x20, x16, xzr
    4410:      	mov	x22, #0x25              ; =37
    4414:      	cmp	x21, #0x7e
    4418:      	b.ne	0x43bc <_stogir.atomic.validate+0x574>
    441c:      	movz	x0, #0x0, lsl #48
    4420:      	b	0x43c0 <_stogir.atomic.validate+0x578>
    4424:      	sxtw	x19, w19
    4428:      	cmp	x19, #0x0
    442c:      	b.ne	0x450c <_stogir.atomic.validate+0x6c4>
    4430:      	movz	x0, #0x0, lsl #48
    4434:      	b	0x42ac <_stogir.atomic.validate+0x464>
    4438:      	uxtb	w16, w27
    443c:      	cmp	w16, wzr
    4440:      	b.eq	0x4458 <_stogir.atomic.validate+0x610>
    4444:      	sxtw	x1, w1
    4448:      	cmp	x1, #0x0
    444c:      	b.ge	0x458c <_stogir.atomic.validate+0x744>
    4450:      	mov	x0, #0x1                ; =1
    4454:      	b	0x4598 <_stogir.atomic.validate+0x750>
    4458:      	mov	x0, x24
    445c:      	mov	w2, w19
    4460:      	bl	0x4460 <_stogir.atomic.validate+0x618>
		0000000000004460:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4464:      	cmp	x0, #0x0
    4468:      	b.ne	0x447c <_stogir.atomic.validate+0x634>
    446c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		000000000000446c:  ARM64_RELOC_PAGE21	l_stogir.385
    4470:      	ldr	x16, [x16]
		0000000000004470:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    4474:      	orr	x20, x16, xzr
    4478:      	mov	x22, #0x24              ; =36
    447c:      	b	0x428c <_stogir.atomic.validate+0x444>
    4480:      	movz	x0, #0x0, lsl #48
    4484:      	uxtb	w0, w0
    4488:      	and	x0, x0, #0x4
    448c:      	uxtb	w0, w0
    4490:      	cmp	x0, #0x0
    4494:      	cset	w0, eq
    4498:      	uxtb	w16, w0
    449c:      	cmp	w16, wzr
    44a0:      	cset	x0, eq
    44a4:      	b	0x4104 <_stogir.atomic.validate+0x2bc>
    44a8:      	movz	x2, #0x0, lsl #48
    44ac:      	uxtb	w2, w2
    44b0:      	and	x2, x2, #0x1
    44b4:      	uxtb	w2, w2
    44b8:      	cmp	x2, #0x0
    44bc:      	b.eq	0x4100 <_stogir.atomic.validate+0x2b8>
    44c0:      	uxtb	w16, w1
    44c4:      	cmp	w16, wzr
    44c8:      	b.eq	0x4480 <_stogir.atomic.validate+0x638>
    44cc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		00000000000044cc:  ARM64_RELOC_PAGE21	l_stogir.383
    44d0:      	ldr	x16, [x16]
		00000000000044d0:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    44d4:      	orr	x1, x16, xzr
    44d8:      	add	x0, x0, x1
    44dc:      	ldrb	w0, [x0]
    44e0:      	b	0x4484 <_stogir.atomic.validate+0x63c>
    44e4:      	mov	x3, #-0x2               ; =-2
    44e8:      	sxtw	x2, w2
    44ec:      	sxtw	x3, w3
    44f0:      	cmp	x2, x3
    44f4:      	b.ne	0x4080 <_stogir.atomic.validate+0x238>
    44f8:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		00000000000044f8:  ARM64_RELOC_PAGE21	l_stogir.386
    44fc:      	ldr	x16, [x16]
		00000000000044fc:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    4500:      	orr	x20, x16, xzr
    4504:      	movz	x22, #0x0, lsl #48
    4508:      	b	0x4090 <_stogir.atomic.validate+0x248>
    450c:      	cmp	x19, #0x1
    4510:      	b.eq	0x42a8 <_stogir.atomic.validate+0x460>
    4514:      	cmp	x19, #0x2
    4518:      	b.eq	0x42a8 <_stogir.atomic.validate+0x460>
    451c:      	cmp	x19, #0x7
    4520:      	b.eq	0x42a8 <_stogir.atomic.validate+0x460>
    4524:      	cmp	x19, #0x8
    4528:      	b.eq	0x42a8 <_stogir.atomic.validate+0x460>
    452c:      	cmp	x19, #0x3
    4530:      	b.eq	0x45c4 <_stogir.atomic.validate+0x77c>
    4534:      	cmp	x19, #0x9
    4538:      	b.eq	0x45c4 <_stogir.atomic.validate+0x77c>
    453c:      	cmp	x19, #0x4
    4540:      	b.eq	0x45dc <_stogir.atomic.validate+0x794>
    4544:      	cmp	x19, #0xa
    4548:      	b.eq	0x45dc <_stogir.atomic.validate+0x794>
    454c:      	cmp	x19, #0xd
    4550:      	b.eq	0x45dc <_stogir.atomic.validate+0x794>
    4554:      	cmp	x19, #0x5
    4558:      	b.eq	0x45e4 <_stogir.atomic.validate+0x79c>
    455c:      	cmp	x19, #0xb
    4560:      	b.eq	0x45e4 <_stogir.atomic.validate+0x79c>
    4564:      	cmp	x19, #0xc
    4568:      	b.eq	0x45e4 <_stogir.atomic.validate+0x79c>
    456c:      	cmp	x19, #0x6
    4570:      	cset	w0, eq
    4574:      	uxtb	w16, w0
    4578:      	cmp	w16, wzr
    457c:      	mov	x16, #0x8               ; =8
    4580:      	movn	x17, #0x0, lsl #48
    4584:      	csel	x0, x16, x17, ne
    4588:      	b	0x45e8 <_stogir.atomic.validate+0x7a0>
    458c:      	cmp	x1, #0x9
    4590:      	cset	w0, gt
    4594:      	ubfx	x0, x0, #0, #8
    4598:      	cmp	x0, #0x0
    459c:      	b.eq	0x45b0 <_stogir.atomic.validate+0x768>
    45a0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		00000000000045a0:  ARM64_RELOC_PAGE21	l_stogir.387
    45a4:      	ldr	x16, [x16]
		00000000000045a4:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    45a8:      	orr	x20, x16, xzr
    45ac:      	mov	x22, #0x1c              ; =28
    45b0:      	b	0x447c <_stogir.atomic.validate+0x634>
    45b4:      	brk	#0
    45b8:      	b	0x45b4 <_stogir.atomic.validate+0x76c>
    45bc:      	brk	#0
    45c0:      	b	0x45bc <_stogir.atomic.validate+0x774>
    45c4:      	mov	x0, #0x2                ; =2
    45c8:      	b	0x42ac <_stogir.atomic.validate+0x464>
    45cc:      	brk	#0
    45d0:      	b	0x45cc <_stogir.atomic.validate+0x784>
    45d4:      	brk	#0
    45d8:      	b	0x45d4 <_stogir.atomic.validate+0x78c>
    45dc:      	mov	x0, #0x4                ; =4
    45e0:      	b	0x45c8 <_stogir.atomic.validate+0x780>
    45e4:      	mov	x0, #0x8                ; =8
    45e8:      	b	0x45e0 <_stogir.atomic.validate+0x798>

00000000000045ec <_stogir.terminal.validate>:
    45ec:      	sub	sp, sp, #0x50
    45f0:      	str	x29, [sp]
    45f4:      	str	x30, [sp, #0x8]
    45f8:      	mov	x29, sp
    45fc:      	str	x19, [sp, #0x40]
    4600:      	sxtw	x1, w1
    4604:      	lsl	x2, x1, #2
    4608:      	cmp	x1, #0x0
    460c:      	cset	w3, gt
    4610:      	movz	x16, #0x0, lsl #48
    4614:      	sub	x4, x16, x1
    4618:      	sub	x5, x4, #0x1
    461c:      	uxtb	w16, w3
    4620:      	cmp	w16, wzr
    4624:      	b.eq	0x4664 <_stogir.terminal.validate+0x78>
    4628:      	ldr	x4, [x0, #0x8]
    462c:      	cmp	x1, x4
    4630:      	b.ge	0x46b4 <_stogir.terminal.validate+0xc8>
    4634:      	add	x4, x0, #0x78
    4638:      	ldr	x4, [x4, #0x8]
    463c:      	cmp	x1, x4
    4640:      	b.ge	0x47a8 <_stogir.terminal.validate+0x1bc>
    4644:      	ldr	x4, [x0, #0x78]
    4648:      	add	x4, x2, x4
    464c:      	ldr	w4, [x4]
    4650:      	sxtw	x4, w4
    4654:      	cmp	x4, #0x0
    4658:      	cset	w4, ge
    465c:      	ubfx	x4, x4, #0, #8
    4660:      	b	0x47ac <_stogir.terminal.validate+0x1c0>
    4664:      	cmp	x1, #0x0
    4668:      	b.ge	0x46bc <_stogir.terminal.validate+0xd0>
    466c:      	add	x6, x0, #0x28
    4670:      	add	x7, x0, #0x50
    4674:      	ldr	x6, [x6, #0x8]
    4678:      	ldr	x7, [x7, #0x8]
    467c:      	cmp	x6, x7
    4680:      	b.ne	0x46ac <_stogir.terminal.validate+0xc0>
    4684:      	cmp	x4, x6
    4688:      	b.gt	0x47e8 <_stogir.terminal.validate+0x1fc>
    468c:      	ldr	x4, [x0, #0x50]
    4690:      	add	x4, x4, x5, lsl #2
    4694:      	ldr	w4, [x4]
    4698:      	sxtw	x4, w4
    469c:      	cmp	x4, #0x0
    46a0:      	cset	w4, gt
    46a4:      	ubfx	x4, x4, #0, #8
    46a8:      	b	0x47ec <_stogir.terminal.validate+0x200>
    46ac:      	movz	x4, #0x0, lsl #48
    46b0:      	b	0x46c0 <_stogir.terminal.validate+0xd4>
    46b4:      	movz	x4, #0x0, lsl #48
    46b8:      	b	0x46c0 <_stogir.terminal.validate+0xd4>
    46bc:      	movz	x4, #0x0, lsl #48
    46c0:      	cmp	x4, #0x0
    46c4:      	b.eq	0x4700 <_stogir.terminal.validate+0x114>
    46c8:      	uxtb	w16, w3
    46cc:      	cmp	w16, wzr
    46d0:      	b.eq	0x46e8 <_stogir.terminal.validate+0xfc>
    46d4:      	ldr	x3, [x0]
    46d8:      	add	x3, x3, x1, lsl #4
    46dc:      	ldr	x4, [x3]
    46e0:      	ldr	x3, [x3, #0x8]
    46e4:      	b	0x46f8 <_stogir.terminal.validate+0x10c>
    46e8:      	ldr	x3, [x0, #0x28]
    46ec:      	add	x3, x3, x5, lsl #4
    46f0:      	ldr	x4, [x3]
    46f4:      	ldr	x3, [x3, #0x8]
    46f8:      	mov	x5, #0x1                ; =1
    46fc:      	b	0x470c <_stogir.terminal.validate+0x120>
    4700:      	movz	x5, #0x0, lsl #48
    4704:      	movz	x4, #0x0, lsl #48
    4708:      	movz	x3, #0x0, lsl #48
    470c:      	ubfx	x5, x5, #0, #32
    4710:      	lsr	x16, x5, #0
    4714:      	cmp	x16, #0x1
    4718:      	b.eq	0x4734 <_stogir.terminal.validate+0x148>
    471c:      	b.lo	0x4724 <_stogir.terminal.validate+0x138>
    4720:      	b	0x4738 <_stogir.terminal.validate+0x14c>
    4724:      	cmp	x16, #0x0
    4728:      	b.eq	0x4730 <_stogir.terminal.validate+0x144>
    472c:      	b	0x4738 <_stogir.terminal.validate+0x14c>
    4730:      	b	0x473c <_stogir.terminal.validate+0x150>
    4734:      	b	0x4758 <_stogir.terminal.validate+0x16c>
    4738:      	b	0x48b4 <_stogir.terminal.validate+0x2c8>
    473c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		000000000000473c:  ARM64_RELOC_PAGE21	l_stogir.388
    4740:      	ldr	x16, [x16]
		0000000000004740:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    4744:      	orr	x0, x16, xzr
    4748:      	mov	x19, x8
    474c:      	mov	x1, #0x1                ; =1
    4750:      	mov	x2, #0x21               ; =33
    4754:      	b	0x4788 <_stogir.terminal.validate+0x19c>
    4758:      	add	x16, sp, #0x10
    475c:      	str	x4, [x16]
    4760:      	add	x16, sp, #0x10
    4764:      	str	x3, [x16, #0x8]
    4768:      	cmp	x1, #0x0
    476c:      	b.gt	0x47b0 <_stogir.terminal.validate+0x1c4>
    4770:      	mov	x19, x8
    4774:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004774:  ARM64_RELOC_PAGE21	l_stogir.389
    4778:      	ldr	x16, [x16]
		0000000000004778:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    477c:      	orr	x0, x16, xzr
    4780:      	mov	x1, #0x1                ; =1
    4784:      	mov	x2, #0x1b               ; =27
    4788:      	str	x1, [x19]
    478c:      	str	x0, [x19, #0x8]
    4790:      	str	x2, [x19, #0x10]
    4794:      	ldr	x19, [sp, #0x40]
    4798:      	ldr	x29, [sp]
    479c:      	ldr	x30, [sp, #0x8]
    47a0:      	add	sp, sp, #0x50
    47a4:      	ret
    47a8:      	movz	x4, #0x0, lsl #48
    47ac:      	b	0x46b8 <_stogir.terminal.validate+0xcc>
    47b0:      	uxtb	w4, w4
    47b4:      	orr	x1, x4, xzr
    47b8:      	cmp	x1, #0x60
    47bc:      	cset	w3, eq
    47c0:      	cmp	x1, #0x79
    47c4:      	cset	w1, eq
    47c8:      	uxtb	w16, w3
    47cc:      	cmp	w16, wzr
    47d0:      	b.ne	0x47f0 <_stogir.terminal.validate+0x204>
    47d4:      	uxtb	w16, w1
    47d8:      	cmp	w16, wzr
    47dc:      	b.ne	0x47f0 <_stogir.terminal.validate+0x204>
    47e0:      	mov	x19, x8
    47e4:      	b	0x4774 <_stogir.terminal.validate+0x188>
    47e8:      	movz	x4, #0x0, lsl #48
    47ec:      	b	0x46b0 <_stogir.terminal.validate+0xc4>
    47f0:      	add	x16, sp, #0x10
    47f4:      	ldr	w5, [x16]
    47f8:      	ubfx	x5, x5, #8, #8
    47fc:      	cmp	x5, #0x0
    4800:      	b.ne	0x48bc <_stogir.terminal.validate+0x2d0>
    4804:      	uxtb	w16, w3
    4808:      	cmp	w16, wzr
    480c:      	mov	x16, #0x1               ; =1
    4810:      	mov	x17, #0x3               ; =3
    4814:      	csel	x3, x16, x17, ne
    4818:      	sxtw	x3, w3
    481c:      	ldr	x5, [x0, #0x78]
    4820:      	add	x2, x2, x5
    4824:      	ldr	w2, [x2]
    4828:      	sxtw	x2, w2
    482c:      	cmp	x2, x3
    4830:      	b.ne	0x48c4 <_stogir.terminal.validate+0x2d8>
    4834:      	uxtb	w16, w1
    4838:      	cmp	w16, wzr
    483c:      	b.eq	0x4890 <_stogir.terminal.validate+0x2a4>
    4840:      	add	x16, sp, #0x10
    4844:      	ldr	w2, [x16, #0x8]
    4848:      	sxtw	x2, w2
    484c:      	cmp	x2, #0x0
    4850:      	b.eq	0x4890 <_stogir.terminal.validate+0x2a4>
    4854:      	mov	x19, x8
    4858:      	b	0x4774 <_stogir.terminal.validate+0x188>
    485c:      	movz	x1, #0x0, lsl #48
    4860:      	mov	w3, w1
    4864:      	mov	w1, w4
    4868:      	mov	x19, x8
    486c:      	add	x8, sp, #0x20
    4870:      	bl	0x4870 <_stogir.terminal.validate+0x284>
		0000000000004870:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    4874:      	add	x16, sp, #0x20
    4878:      	ldr	x1, [x16]
    487c:      	add	x16, sp, #0x20
    4880:      	ldr	x0, [x16, #0x8]
    4884:      	add	x16, sp, #0x20
    4888:      	ldr	x2, [x16, #0x10]
    488c:      	b	0x4788 <_stogir.terminal.validate+0x19c>
    4890:      	add	x16, sp, #0x10
    4894:      	ldr	w2, [x16, #0x4]
    4898:      	uxtb	w16, w1
    489c:      	cmp	w16, wzr
    48a0:      	b.eq	0x485c <_stogir.terminal.validate+0x270>
    48a4:      	add	x16, sp, #0x10
    48a8:      	ldr	w1, [x16, #0xc]
    48ac:      	sxtw	x1, w1
    48b0:      	b	0x4860 <_stogir.terminal.validate+0x274>
    48b4:      	brk	#0
    48b8:      	b	0x48b4 <_stogir.terminal.validate+0x2c8>
    48bc:      	mov	x19, x8
    48c0:      	b	0x4774 <_stogir.terminal.validate+0x188>
    48c4:      	mov	x19, x8
    48c8:      	b	0x4774 <_stogir.terminal.validate+0x188>

00000000000048cc <_stogir.switch.validate>:
    48cc:      	sub	sp, sp, #0x70
    48d0:      	str	x29, [sp]
    48d4:      	str	x30, [sp, #0x8]
    48d8:      	mov	x29, sp
    48dc:      	str	x19, [sp, #0x60]
    48e0:      	sxtw	x1, w1
    48e4:      	lsl	x2, x1, #2
    48e8:      	cmp	x1, #0x0
    48ec:      	cset	w3, gt
    48f0:      	movz	x16, #0x0, lsl #48
    48f4:      	sub	x4, x16, x1
    48f8:      	sub	x5, x4, #0x1
    48fc:      	uxtb	w16, w3
    4900:      	cmp	w16, wzr
    4904:      	b.eq	0x4944 <_stogir.switch.validate+0x78>
    4908:      	ldr	x4, [x0, #0x8]
    490c:      	cmp	x1, x4
    4910:      	b.ge	0x4994 <_stogir.switch.validate+0xc8>
    4914:      	add	x4, x0, #0x78
    4918:      	ldr	x4, [x4, #0x8]
    491c:      	cmp	x1, x4
    4920:      	b.ge	0x4a88 <_stogir.switch.validate+0x1bc>
    4924:      	ldr	x4, [x0, #0x78]
    4928:      	add	x4, x2, x4
    492c:      	ldr	w4, [x4]
    4930:      	sxtw	x4, w4
    4934:      	cmp	x4, #0x0
    4938:      	cset	w4, ge
    493c:      	ubfx	x4, x4, #0, #8
    4940:      	b	0x4a8c <_stogir.switch.validate+0x1c0>
    4944:      	cmp	x1, #0x0
    4948:      	b.ge	0x499c <_stogir.switch.validate+0xd0>
    494c:      	add	x6, x0, #0x28
    4950:      	add	x7, x0, #0x50
    4954:      	ldr	x6, [x6, #0x8]
    4958:      	ldr	x7, [x7, #0x8]
    495c:      	cmp	x6, x7
    4960:      	b.ne	0x498c <_stogir.switch.validate+0xc0>
    4964:      	cmp	x4, x6
    4968:      	b.gt	0x4ac4 <_stogir.switch.validate+0x1f8>
    496c:      	ldr	x4, [x0, #0x50]
    4970:      	add	x4, x4, x5, lsl #2
    4974:      	ldr	w4, [x4]
    4978:      	sxtw	x4, w4
    497c:      	cmp	x4, #0x0
    4980:      	cset	w4, gt
    4984:      	ubfx	x4, x4, #0, #8
    4988:      	b	0x4ac8 <_stogir.switch.validate+0x1fc>
    498c:      	movz	x4, #0x0, lsl #48
    4990:      	b	0x49a0 <_stogir.switch.validate+0xd4>
    4994:      	movz	x4, #0x0, lsl #48
    4998:      	b	0x49a0 <_stogir.switch.validate+0xd4>
    499c:      	movz	x4, #0x0, lsl #48
    49a0:      	cmp	x4, #0x0
    49a4:      	b.eq	0x49e0 <_stogir.switch.validate+0x114>
    49a8:      	uxtb	w16, w3
    49ac:      	cmp	w16, wzr
    49b0:      	b.eq	0x49c8 <_stogir.switch.validate+0xfc>
    49b4:      	ldr	x3, [x0]
    49b8:      	add	x3, x3, x1, lsl #4
    49bc:      	ldr	x4, [x3]
    49c0:      	ldr	x3, [x3, #0x8]
    49c4:      	b	0x49d8 <_stogir.switch.validate+0x10c>
    49c8:      	ldr	x3, [x0, #0x28]
    49cc:      	add	x3, x3, x5, lsl #4
    49d0:      	ldr	x4, [x3]
    49d4:      	ldr	x3, [x3, #0x8]
    49d8:      	mov	x5, #0x1                ; =1
    49dc:      	b	0x49ec <_stogir.switch.validate+0x120>
    49e0:      	movz	x5, #0x0, lsl #48
    49e4:      	movz	x4, #0x0, lsl #48
    49e8:      	movz	x3, #0x0, lsl #48
    49ec:      	ubfx	x5, x5, #0, #32
    49f0:      	lsr	x16, x5, #0
    49f4:      	cmp	x16, #0x1
    49f8:      	b.eq	0x4a14 <_stogir.switch.validate+0x148>
    49fc:      	b.lo	0x4a04 <_stogir.switch.validate+0x138>
    4a00:      	b	0x4a18 <_stogir.switch.validate+0x14c>
    4a04:      	cmp	x16, #0x0
    4a08:      	b.eq	0x4a10 <_stogir.switch.validate+0x144>
    4a0c:      	b	0x4a18 <_stogir.switch.validate+0x14c>
    4a10:      	b	0x4a1c <_stogir.switch.validate+0x150>
    4a14:      	b	0x4a38 <_stogir.switch.validate+0x16c>
    4a18:      	b	0x4bac <_stogir.switch.validate+0x2e0>
    4a1c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004a1c:  ARM64_RELOC_PAGE21	l_stogir.390
    4a20:      	ldr	x16, [x16]
		0000000000004a20:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    4a24:      	orr	x0, x16, xzr
    4a28:      	mov	x19, x8
    4a2c:      	mov	x1, #0x1                ; =1
    4a30:      	mov	x2, #0x1a               ; =26
    4a34:      	b	0x4a68 <_stogir.switch.validate+0x19c>
    4a38:      	add	x16, sp, #0x10
    4a3c:      	str	x4, [x16]
    4a40:      	add	x16, sp, #0x10
    4a44:      	str	x3, [x16, #0x8]
    4a48:      	cmp	x1, #0x0
    4a4c:      	b.gt	0x4a90 <_stogir.switch.validate+0x1c4>
    4a50:      	mov	x19, x8
    4a54:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004a54:  ARM64_RELOC_PAGE21	l_stogir.391
    4a58:      	ldr	x16, [x16]
		0000000000004a58:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    4a5c:      	orr	x0, x16, xzr
    4a60:      	mov	x1, #0x1                ; =1
    4a64:      	mov	x2, #0x20               ; =32
    4a68:      	str	x1, [x19]
    4a6c:      	str	x0, [x19, #0x8]
    4a70:      	str	x2, [x19, #0x10]
    4a74:      	ldr	x19, [sp, #0x60]
    4a78:      	ldr	x29, [sp]
    4a7c:      	ldr	x30, [sp, #0x8]
    4a80:      	add	sp, sp, #0x70
    4a84:      	ret
    4a88:      	movz	x4, #0x0, lsl #48
    4a8c:      	b	0x4998 <_stogir.switch.validate+0xcc>
    4a90:      	uxtb	w4, w4
    4a94:      	orr	x1, x4, xzr
    4a98:      	cmp	x1, #0x75
    4a9c:      	cset	w3, eq
    4aa0:      	uxtb	w16, w3
    4aa4:      	cmp	w16, wzr
    4aa8:      	b.ne	0x4acc <_stogir.switch.validate+0x200>
    4aac:      	cmp	x1, #0x6d
    4ab0:      	b.lt	0x4bb4 <_stogir.switch.validate+0x2e8>
    4ab4:      	cmp	x1, #0x6f
    4ab8:      	b.le	0x4acc <_stogir.switch.validate+0x200>
    4abc:      	mov	x19, x8
    4ac0:      	b	0x4a54 <_stogir.switch.validate+0x188>
    4ac4:      	movz	x4, #0x0, lsl #48
    4ac8:      	b	0x4990 <_stogir.switch.validate+0xc4>
    4acc:      	add	x16, sp, #0x10
    4ad0:      	ldr	w5, [x16]
    4ad4:      	ubfx	x5, x5, #8, #8
    4ad8:      	cmp	x5, #0x0
    4adc:      	b.ne	0x4bbc <_stogir.switch.validate+0x2f0>
    4ae0:      	ldr	x5, [x0, #0x78]
    4ae4:      	add	x2, x2, x5
    4ae8:      	ldr	w2, [x2]
    4aec:      	cmp	x1, #0x6d
    4af0:      	b.eq	0x4b54 <_stogir.switch.validate+0x288>
    4af4:      	cmp	x1, #0x6e
    4af8:      	b.eq	0x4b54 <_stogir.switch.validate+0x288>
    4afc:      	mov	x1, #0x2                ; =2
    4b00:      	b	0x4b58 <_stogir.switch.validate+0x28c>
    4b04:      	add	x16, sp, #0x10
    4b08:      	ldr	w1, [x16, #0x4]
    4b0c:      	add	x16, sp, #0x10
    4b10:      	ldr	w2, [x16, #0x8]
    4b14:      	add	x16, sp, #0x10
    4b18:      	ldr	w3, [x16, #0xc]
    4b1c:      	add	x8, sp, #0x40
    4b20:      	fmov	s31, w1
    4b24:      	mov	w1, w4
    4b28:      	mov	w4, w3
    4b2c:      	mov	w3, w2
    4b30:      	fmov	w2, s31
    4b34:      	bl	0x4b34 <_stogir.switch.validate+0x268>
		0000000000004b34:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    4b38:      	add	x16, sp, #0x40
    4b3c:      	ldr	x1, [x16]
    4b40:      	add	x16, sp, #0x40
    4b44:      	ldr	x0, [x16, #0x8]
    4b48:      	add	x16, sp, #0x40
    4b4c:      	ldr	x2, [x16, #0x10]
    4b50:      	b	0x4a68 <_stogir.switch.validate+0x19c>
    4b54:      	mov	x1, #0x3                ; =3
    4b58:      	sxtw	x2, w2
    4b5c:      	sxtw	x1, w1
    4b60:      	cmp	x2, x1
    4b64:      	b.ne	0x4bc4 <_stogir.switch.validate+0x2f8>
    4b68:      	uxtb	w16, w3
    4b6c:      	cmp	w16, wzr
    4b70:      	b.eq	0x4bcc <_stogir.switch.validate+0x300>
    4b74:      	add	x16, sp, #0x10
    4b78:      	ldr	w1, [x16, #0x4]
    4b7c:      	add	x16, sp, #0x10
    4b80:      	ldr	w2, [x16, #0x8]
    4b84:      	mov	x19, x8
    4b88:      	add	x8, sp, #0x20
    4b8c:      	bl	0x4b8c <_stogir.switch.validate+0x2c0>
		0000000000004b8c:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    4b90:      	add	x16, sp, #0x20
    4b94:      	ldr	x1, [x16]
    4b98:      	add	x16, sp, #0x20
    4b9c:      	ldr	x0, [x16, #0x8]
    4ba0:      	add	x16, sp, #0x20
    4ba4:      	ldr	x2, [x16, #0x10]
    4ba8:      	b	0x4b50 <_stogir.switch.validate+0x284>
    4bac:      	brk	#0
    4bb0:      	b	0x4bac <_stogir.switch.validate+0x2e0>
    4bb4:      	mov	x19, x8
    4bb8:      	b	0x4a54 <_stogir.switch.validate+0x188>
    4bbc:      	mov	x19, x8
    4bc0:      	b	0x4a54 <_stogir.switch.validate+0x188>
    4bc4:      	mov	x19, x8
    4bc8:      	b	0x4a54 <_stogir.switch.validate+0x188>
    4bcc:      	mov	x19, x8
    4bd0:      	b	0x4b04 <_stogir.switch.validate+0x238>

0000000000004bd4 <_stogir.stack.validate>:
    4bd4:      	sub	sp, sp, #0x90
    4bd8:      	str	x29, [sp]
    4bdc:      	str	x30, [sp, #0x8]
    4be0:      	mov	x29, sp
    4be4:      	str	x19, [sp, #0x60]
    4be8:      	str	x20, [sp, #0x68]
    4bec:      	str	x21, [sp, #0x70]
    4bf0:      	str	x22, [sp, #0x78]
    4bf4:      	str	x23, [sp, #0x80]
    4bf8:      	sxtw	x1, w1
    4bfc:      	lsl	x2, x1, #2
    4c00:      	cmp	x1, #0x0
    4c04:      	cset	w3, gt
    4c08:      	movz	x16, #0x0, lsl #48
    4c0c:      	sub	x4, x16, x1
    4c10:      	cmp	x1, #0x0
    4c14:      	cset	w5, lt
    4c18:      	sub	x6, x4, #0x1
    4c1c:      	lsl	x7, x6, #2
    4c20:      	uxtb	w16, w3
    4c24:      	cmp	w16, wzr
    4c28:      	b.eq	0x4c68 <_stogir.stack.validate+0x94>
    4c2c:      	ldr	x9, [x0, #0x8]
    4c30:      	cmp	x1, x9
    4c34:      	b.ge	0x4ce4 <_stogir.stack.validate+0x110>
    4c38:      	add	x9, x0, #0x78
    4c3c:      	ldr	x9, [x9, #0x8]
    4c40:      	cmp	x1, x9
    4c44:      	b.ge	0x4e2c <_stogir.stack.validate+0x258>
    4c48:      	ldr	x9, [x0, #0x78]
    4c4c:      	add	x9, x2, x9
    4c50:      	ldr	w9, [x9]
    4c54:      	sxtw	x9, w9
    4c58:      	cmp	x9, #0x0
    4c5c:      	cset	w9, ge
    4c60:      	ubfx	x9, x9, #0, #8
    4c64:      	b	0x4e30 <_stogir.stack.validate+0x25c>
    4c68:      	uxtb	w16, w5
    4c6c:      	cmp	w16, wzr
    4c70:      	b.eq	0x4cec <_stogir.stack.validate+0x118>
    4c74:      	add	x9, x0, #0x28
    4c78:      	add	x10, x0, #0x50
    4c7c:      	ldr	x9, [x9, #0x8]
    4c80:      	ldr	x10, [x10, #0x8]
    4c84:      	cmp	x9, x10
    4c88:      	b.ne	0x4cb4 <_stogir.stack.validate+0xe0>
    4c8c:      	cmp	x4, x9
    4c90:      	b.gt	0x4e34 <_stogir.stack.validate+0x260>
    4c94:      	ldr	x9, [x0, #0x50]
    4c98:      	add	x9, x7, x9
    4c9c:      	ldr	w9, [x9]
    4ca0:      	sxtw	x9, w9
    4ca4:      	cmp	x9, #0x0
    4ca8:      	cset	w9, gt
    4cac:      	ubfx	x9, x9, #0, #8
    4cb0:      	b	0x4e38 <_stogir.stack.validate+0x264>
    4cb4:      	movz	x9, #0x0, lsl #48
    4cb8:      	b	0x4cf0 <_stogir.stack.validate+0x11c>
    4cbc:      	uxtb	w16, w12
    4cc0:      	cmp	w16, wzr
    4cc4:      	b.eq	0x4e58 <_stogir.stack.validate+0x284>
    4cc8:      	mov	x22, x8
    4ccc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004ccc:  ARM64_RELOC_PAGE21	l_stogir.392
    4cd0:      	ldr	x16, [x16]
		0000000000004cd0:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    4cd4:      	orr	x0, x16, xzr
    4cd8:      	mov	x1, #0x1                ; =1
    4cdc:      	mov	x2, #0x19               ; =25
    4ce0:      	b	0x4d8c <_stogir.stack.validate+0x1b8>
    4ce4:      	movz	x9, #0x0, lsl #48
    4ce8:      	b	0x4cf0 <_stogir.stack.validate+0x11c>
    4cec:      	movz	x9, #0x0, lsl #48
    4cf0:      	lsl	x10, x1, #4
    4cf4:      	lsl	x6, x6, #4
    4cf8:      	cmp	x9, #0x0
    4cfc:      	b.eq	0x4d38 <_stogir.stack.validate+0x164>
    4d00:      	uxtb	w16, w3
    4d04:      	cmp	w16, wzr
    4d08:      	b.eq	0x4d20 <_stogir.stack.validate+0x14c>
    4d0c:      	ldr	x9, [x0]
    4d10:      	add	x9, x10, x9
    4d14:      	ldr	x11, [x9]
    4d18:      	ldr	x9, [x9, #0x8]
    4d1c:      	b	0x4d30 <_stogir.stack.validate+0x15c>
    4d20:      	ldr	x9, [x0, #0x28]
    4d24:      	add	x9, x6, x9
    4d28:      	ldr	x11, [x9]
    4d2c:      	ldr	x9, [x9, #0x8]
    4d30:      	mov	x12, #0x1               ; =1
    4d34:      	b	0x4d44 <_stogir.stack.validate+0x170>
    4d38:      	movz	x12, #0x0, lsl #48
    4d3c:      	movz	x11, #0x0, lsl #48
    4d40:      	movz	x9, #0x0, lsl #48
    4d44:      	ubfx	x12, x12, #0, #32
    4d48:      	lsr	x16, x12, #0
    4d4c:      	cmp	x16, #0x1
    4d50:      	b.eq	0x4d6c <_stogir.stack.validate+0x198>
    4d54:      	b.lo	0x4d5c <_stogir.stack.validate+0x188>
    4d58:      	b	0x4d70 <_stogir.stack.validate+0x19c>
    4d5c:      	cmp	x16, #0x0
    4d60:      	b.eq	0x4d68 <_stogir.stack.validate+0x194>
    4d64:      	b	0x4d70 <_stogir.stack.validate+0x19c>
    4d68:      	b	0x4d74 <_stogir.stack.validate+0x1a0>
    4d6c:      	b	0x4dbc <_stogir.stack.validate+0x1e8>
    4d70:      	b	0x5178 <_stogir.stack.validate+0x5a4>
    4d74:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004d74:  ARM64_RELOC_PAGE21	l_stogir.393
    4d78:      	ldr	x16, [x16]
		0000000000004d78:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    4d7c:      	orr	x0, x16, xzr
    4d80:      	mov	x22, x8
    4d84:      	mov	x1, #0x1                ; =1
    4d88:      	mov	x2, #0x19               ; =25
    4d8c:      	str	x1, [x22]
    4d90:      	str	x0, [x22, #0x8]
    4d94:      	str	x2, [x22, #0x10]
    4d98:      	ldr	x19, [sp, #0x60]
    4d9c:      	ldr	x20, [sp, #0x68]
    4da0:      	ldr	x21, [sp, #0x70]
    4da4:      	ldr	x22, [sp, #0x78]
    4da8:      	ldr	x23, [sp, #0x80]
    4dac:      	ldr	x29, [sp]
    4db0:      	ldr	x30, [sp, #0x8]
    4db4:      	add	sp, sp, #0x90
    4db8:      	ret
    4dbc:      	cmp	x1, #0x0
    4dc0:      	cset	w12, le
    4dc4:      	uxtb	w19, w11
    4dc8:      	add	x16, sp, #0x10
    4dcc:      	str	x11, [x16]
    4dd0:      	orr	x11, x19, xzr
    4dd4:      	add	x16, sp, #0x10
    4dd8:      	str	x9, [x16, #0x8]
    4ddc:      	cmp	x11, #0x42
    4de0:      	b.ne	0x4cbc <_stogir.stack.validate+0xe8>
    4de4:      	uxtb	w16, w3
    4de8:      	cmp	w16, wzr
    4dec:      	b.eq	0x4ea4 <_stogir.stack.validate+0x2d0>
    4df0:      	ldr	x4, [x0, #0x8]
    4df4:      	cmp	x1, x4
    4df8:      	b.ge	0x4ef0 <_stogir.stack.validate+0x31c>
    4dfc:      	add	x4, x0, #0x78
    4e00:      	ldr	x4, [x4, #0x8]
    4e04:      	cmp	x1, x4
    4e08:      	b.ge	0x4fdc <_stogir.stack.validate+0x408>
    4e0c:      	ldr	x1, [x0, #0x78]
    4e10:      	add	x1, x2, x1
    4e14:      	ldr	w1, [x1]
    4e18:      	sxtw	x1, w1
    4e1c:      	cmp	x1, #0x0
    4e20:      	cset	w1, ge
    4e24:      	ubfx	x1, x1, #0, #8
    4e28:      	b	0x4fe0 <_stogir.stack.validate+0x40c>
    4e2c:      	movz	x9, #0x0, lsl #48
    4e30:      	b	0x4ce8 <_stogir.stack.validate+0x114>
    4e34:      	movz	x9, #0x0, lsl #48
    4e38:      	b	0x4cb8 <_stogir.stack.validate+0xe4>
    4e3c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004e3c:  ARM64_RELOC_PAGE21	l_stogir.394
    4e40:      	ldr	x16, [x16]
		0000000000004e40:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    4e44:      	orr	x0, x16, xzr
    4e48:      	mov	x1, #0x1                ; =1
    4e4c:      	mov	x2, #0x1e               ; =30
    4e50:      	mov	x22, x8
    4e54:      	b	0x4ce0 <_stogir.stack.validate+0x10c>
    4e58:      	cmp	x11, #0x51
    4e5c:      	cset	w1, eq
    4e60:      	cmp	x11, #0x53
    4e64:      	cset	w20, eq
    4e68:      	cmp	x11, #0x54
    4e6c:      	cset	w21, eq
    4e70:      	uxtb	w16, w1
    4e74:      	cmp	w16, wzr
    4e78:      	b.ne	0x4fe4 <_stogir.stack.validate+0x410>
    4e7c:      	cmp	x11, #0x52
    4e80:      	b.eq	0x4fe4 <_stogir.stack.validate+0x410>
    4e84:      	uxtb	w16, w20
    4e88:      	cmp	w16, wzr
    4e8c:      	b.ne	0x4fe4 <_stogir.stack.validate+0x410>
    4e90:      	uxtb	w16, w21
    4e94:      	cmp	w16, wzr
    4e98:      	b.ne	0x4fe4 <_stogir.stack.validate+0x410>
    4e9c:      	mov	x22, x8
    4ea0:      	b	0x4ccc <_stogir.stack.validate+0xf8>
    4ea4:      	uxtb	w16, w5
    4ea8:      	cmp	w16, wzr
    4eac:      	b.eq	0x4ef8 <_stogir.stack.validate+0x324>
    4eb0:      	add	x1, x0, #0x28
    4eb4:      	add	x5, x0, #0x50
    4eb8:      	ldr	x1, [x1, #0x8]
    4ebc:      	ldr	x5, [x5, #0x8]
    4ec0:      	cmp	x1, x5
    4ec4:      	b.ne	0x4fd4 <_stogir.stack.validate+0x400>
    4ec8:      	cmp	x4, x1
    4ecc:      	b.gt	0x511c <_stogir.stack.validate+0x548>
    4ed0:      	ldr	x1, [x0, #0x50]
    4ed4:      	add	x1, x7, x1
    4ed8:      	ldr	w1, [x1]
    4edc:      	sxtw	x1, w1
    4ee0:      	cmp	x1, #0x0
    4ee4:      	cset	w1, gt
    4ee8:      	ubfx	x1, x1, #0, #8
    4eec:      	b	0x5120 <_stogir.stack.validate+0x54c>
    4ef0:      	movz	x1, #0x0, lsl #48
    4ef4:      	b	0x4efc <_stogir.stack.validate+0x328>
    4ef8:      	movz	x1, #0x0, lsl #48
    4efc:      	cmp	x1, #0x0
    4f00:      	b.eq	0x4f34 <_stogir.stack.validate+0x360>
    4f04:      	uxtb	w16, w3
    4f08:      	cmp	w16, wzr
    4f0c:      	b.eq	0x4f20 <_stogir.stack.validate+0x34c>
    4f10:      	ldr	x1, [x0]
    4f14:      	add	x1, x10, x1
    4f18:      	ldr	x1, [x1]
    4f1c:      	b	0x4f2c <_stogir.stack.validate+0x358>
    4f20:      	ldr	x1, [x0, #0x28]
    4f24:      	add	x1, x6, x1
    4f28:      	ldr	x1, [x1]
    4f2c:      	mov	x3, #0x1                ; =1
    4f30:      	b	0x4f3c <_stogir.stack.validate+0x368>
    4f34:      	movz	x3, #0x0, lsl #48
    4f38:      	movz	x1, #0x0, lsl #48
    4f3c:      	ubfx	x3, x3, #0, #32
    4f40:      	lsr	x16, x3, #0
    4f44:      	cmp	x16, #0x1
    4f48:      	b.eq	0x4f64 <_stogir.stack.validate+0x390>
    4f4c:      	b.lo	0x4f54 <_stogir.stack.validate+0x380>
    4f50:      	b	0x4f68 <_stogir.stack.validate+0x394>
    4f54:      	cmp	x16, #0x0
    4f58:      	b.eq	0x4f60 <_stogir.stack.validate+0x38c>
    4f5c:      	b	0x4f68 <_stogir.stack.validate+0x394>
    4f60:      	b	0x4f6c <_stogir.stack.validate+0x398>
    4f64:      	b	0x4f84 <_stogir.stack.validate+0x3b0>
    4f68:      	b	0x5180 <_stogir.stack.validate+0x5ac>
    4f6c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x1b8>
		0000000000004f6c:  ARM64_RELOC_PAGE21	l_stogir.395
    4f70:      	ldr	x16, [x16]
		0000000000004f70:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    4f74:      	orr	x0, x16, xzr
    4f78:      	mov	x1, #0x1                ; =1
    4f7c:      	mov	x2, #0x21               ; =33
    4f80:      	b	0x4e50 <_stogir.stack.validate+0x27c>
    4f84:      	uxtb	w16, w12
    4f88:      	cmp	w16, wzr
    4f8c:      	b.ne	0x4e3c <_stogir.stack.validate+0x268>
    4f90:      	uxtb	w3, w1
    4f94:      	cmp	x3, #0x42
    4f98:      	b.ne	0x4e3c <_stogir.stack.validate+0x268>
    4f9c:      	ubfx	x1, x1, #0, #32
    4fa0:      	ubfx	x1, x1, #8, #8
    4fa4:      	cmp	x1, #0x6
    4fa8:      	b.ne	0x4e3c <_stogir.stack.validate+0x268>
    4fac:      	ldr	x0, [x0, #0x78]
    4fb0:      	add	x0, x2, x0
    4fb4:      	ldr	w0, [x0]
    4fb8:      	sxtw	x0, w0
    4fbc:      	cmp	x0, #0x0
    4fc0:      	b.ne	0x4e3c <_stogir.stack.validate+0x268>
    4fc4:      	movz	x1, #0x0, lsl #48
    4fc8:      	mov	x0, #0x8                ; =8
    4fcc:      	movz	x2, #0x0, lsl #48
    4fd0:      	b	0x4e50 <_stogir.stack.validate+0x27c>
    4fd4:      	movz	x1, #0x0, lsl #48
    4fd8:      	b	0x4efc <_stogir.stack.validate+0x328>
    4fdc:      	movz	x1, #0x0, lsl #48
    4fe0:      	b	0x4ef4 <_stogir.stack.validate+0x320>
    4fe4:      	ldr	x3, [x0, #0x78]
    4fe8:      	add	x2, x2, x3
    4fec:      	ldr	w2, [x2]
    4ff0:      	uxtb	w16, w1
    4ff4:      	cmp	w16, wzr
    4ff8:      	b.eq	0x5058 <_stogir.stack.validate+0x484>
    4ffc:      	mov	x1, #0x3                ; =3
    5000:      	b	0x506c <_stogir.stack.validate+0x498>
    5004:      	add	x16, sp, #0x10
    5008:      	ldr	w0, [x16]
    500c:      	add	x16, sp, #0x10
    5010:      	ldr	w1, [x16, #0x4]
    5014:      	add	x16, sp, #0x10
    5018:      	ldr	w2, [x16, #0x8]
    501c:      	ubfx	x0, x0, #8, #8
    5020:      	add	x8, sp, #0x20
    5024:      	mov	w3, w1
    5028:      	mov	w1, w19
    502c:      	mov	w4, w2
    5030:      	mov	w2, w0
    5034:      	mov	x0, x23
    5038:      	bl	0x5038 <_stogir.stack.validate+0x464>
		0000000000005038:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    503c:      	add	x16, sp, #0x20
    5040:      	ldr	x1, [x16]
    5044:      	add	x16, sp, #0x20
    5048:      	ldr	x0, [x16, #0x8]
    504c:      	add	x16, sp, #0x20
    5050:      	ldr	x2, [x16, #0x10]
    5054:      	b	0x4ce0 <_stogir.stack.validate+0x10c>
    5058:      	uxtb	w16, w20
    505c:      	cmp	w16, wzr
    5060:      	mov	x16, #0x1               ; =1
    5064:      	mov	x17, #0x2               ; =2
    5068:      	csel	x1, x16, x17, ne
    506c:      	sxtw	x2, w2
    5070:      	sxtw	x1, w1
    5074:      	cmp	x2, x1
    5078:      	b.ne	0x5188 <_stogir.stack.validate+0x5b4>
    507c:      	add	x16, sp, #0x10
    5080:      	ldr	w1, [x16]
    5084:      	orr	x2, x1, xzr
    5088:      	ubfx	x2, x2, #16, #16
    508c:      	and	x2, x2, #0x8000
    5090:      	uxth	w2, w2
    5094:      	cmp	x2, #0x0
    5098:      	b.ne	0x5124 <_stogir.stack.validate+0x550>
    509c:      	mov	x22, x8
    50a0:      	mov	x23, x0
    50a4:      	uxtb	w16, w20
    50a8:      	cmp	w16, wzr
    50ac:      	b.ne	0x5004 <_stogir.stack.validate+0x430>
    50b0:      	uxtb	w16, w21
    50b4:      	cmp	w16, wzr
    50b8:      	b.ne	0x5004 <_stogir.stack.validate+0x430>
    50bc:      	add	x16, sp, #0x10
    50c0:      	ldr	w0, [x16]
    50c4:      	add	x16, sp, #0x10
    50c8:      	ldr	w1, [x16, #0x4]
    50cc:      	add	x16, sp, #0x10
    50d0:      	ldr	w2, [x16, #0x8]
    50d4:      	ubfx	x0, x0, #8, #8
    50d8:      	add	x16, sp, #0x10
    50dc:      	ldr	w3, [x16, #0xc]
    50e0:      	add	x8, sp, #0x40
    50e4:      	mov	w4, w2
    50e8:      	mov	w2, w0
    50ec:      	mov	x0, x23
    50f0:      	mov	w5, w3
    50f4:      	mov	w3, w1
    50f8:      	mov	w1, w19
    50fc:      	bl	0x50fc <_stogir.stack.validate+0x528>
		00000000000050fc:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    5100:      	add	x16, sp, #0x40
    5104:      	ldr	x1, [x16]
    5108:      	add	x16, sp, #0x40
    510c:      	ldr	x0, [x16, #0x8]
    5110:      	add	x16, sp, #0x40
    5114:      	ldr	x2, [x16, #0x10]
    5118:      	b	0x5054 <_stogir.stack.validate+0x480>
    511c:      	movz	x1, #0x0, lsl #48
    5120:      	b	0x4fd8 <_stogir.stack.validate+0x404>
    5124:      	uxtb	w2, w1
    5128:      	cmp	x2, #0x51
    512c:      	b.ne	0x5190 <_stogir.stack.validate+0x5bc>
    5130:      	ubfx	x1, x1, #16, #16
    5134:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    5138:      	b.ne	0x5198 <_stogir.stack.validate+0x5c4>
    513c:      	add	x16, sp, #0x10
    5140:      	ldr	w1, [x16, #0x4]
    5144:      	add	x16, sp, #0x10
    5148:      	ldr	w2, [x16, #0x8]
    514c:      	mov	x22, x8
    5150:      	mov	x23, x0
    5154:      	bl	0x5154 <_stogir.stack.validate+0x580>
		0000000000005154:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    5158:      	cmp	x0, #0x0
    515c:      	b.ne	0x50a4 <_stogir.stack.validate+0x4d0>
    5160:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005160:  ARM64_RELOC_PAGE21	l_stogir.396
    5164:      	ldr	x16, [x16]
		0000000000005164:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    5168:      	orr	x0, x16, xzr
    516c:      	mov	x1, #0x1                ; =1
    5170:      	mov	x2, #0x26               ; =38
    5174:      	b	0x5054 <_stogir.stack.validate+0x480>
    5178:      	brk	#0
    517c:      	b	0x5178 <_stogir.stack.validate+0x5a4>
    5180:      	brk	#0
    5184:      	b	0x5180 <_stogir.stack.validate+0x5ac>
    5188:      	mov	x22, x8
    518c:      	b	0x4ccc <_stogir.stack.validate+0xf8>
    5190:      	mov	x22, x8
    5194:      	b	0x5160 <_stogir.stack.validate+0x58c>
    5198:      	mov	x22, x8
    519c:      	b	0x5160 <_stogir.stack.validate+0x58c>

00000000000051a0 <_stogir.locals.validate>:
    51a0:      	sub	sp, sp, #0xb0
    51a4:      	str	x29, [sp]
    51a8:      	str	x30, [sp, #0x8]
    51ac:      	mov	x29, sp
    51b0:      	str	x19, [sp, #0x70]
    51b4:      	str	x20, [sp, #0x78]
    51b8:      	str	x21, [sp, #0x80]
    51bc:      	str	x22, [sp, #0x88]
    51c0:      	str	x23, [sp, #0x90]
    51c4:      	str	x24, [sp, #0x98]
    51c8:      	str	x25, [sp, #0xa0]
    51cc:      	sxtw	x1, w1
    51d0:      	lsl	x3, x1, #2
    51d4:      	cmp	x1, #0x0
    51d8:      	cset	w4, gt
    51dc:      	movz	x16, #0x0, lsl #48
    51e0:      	sub	x5, x16, x1
    51e4:      	sub	x6, x5, #0x1
    51e8:      	uxtb	w16, w4
    51ec:      	cmp	w16, wzr
    51f0:      	b.eq	0x5230 <_stogir.locals.validate+0x90>
    51f4:      	ldr	x5, [x0, #0x8]
    51f8:      	cmp	x1, x5
    51fc:      	b.ge	0x52c4 <_stogir.locals.validate+0x124>
    5200:      	add	x5, x0, #0x78
    5204:      	ldr	x5, [x5, #0x8]
    5208:      	cmp	x1, x5
    520c:      	b.ge	0x53c0 <_stogir.locals.validate+0x220>
    5210:      	ldr	x5, [x0, #0x78]
    5214:      	add	x5, x3, x5
    5218:      	ldr	w5, [x5]
    521c:      	sxtw	x5, w5
    5220:      	cmp	x5, #0x0
    5224:      	cset	w5, ge
    5228:      	ubfx	x5, x5, #0, #8
    522c:      	b	0x53c4 <_stogir.locals.validate+0x224>
    5230:      	cmp	x1, #0x0
    5234:      	b.ge	0x52cc <_stogir.locals.validate+0x12c>
    5238:      	add	x7, x0, #0x28
    523c:      	add	x9, x0, #0x50
    5240:      	ldr	x7, [x7, #0x8]
    5244:      	ldr	x9, [x9, #0x8]
    5248:      	cmp	x7, x9
    524c:      	b.ne	0x5278 <_stogir.locals.validate+0xd8>
    5250:      	cmp	x5, x7
    5254:      	b.gt	0x5444 <_stogir.locals.validate+0x2a4>
    5258:      	ldr	x5, [x0, #0x50]
    525c:      	add	x5, x5, x6, lsl #2
    5260:      	ldr	w5, [x5]
    5264:      	sxtw	x5, w5
    5268:      	cmp	x5, #0x0
    526c:      	cset	w5, gt
    5270:      	ubfx	x5, x5, #0, #8
    5274:      	b	0x5448 <_stogir.locals.validate+0x2a8>
    5278:      	movz	x5, #0x0, lsl #48
    527c:      	b	0x52d0 <_stogir.locals.validate+0x130>
    5280:      	cmp	x4, #0x0
    5284:      	cset	w4, ne
    5288:      	uxtb	w16, w4
    528c:      	cmp	w16, wzr
    5290:      	mov	x16, #0x2               ; =2
    5294:      	mov	x17, #0x3               ; =3
    5298:      	csel	x4, x16, x17, ne
    529c:      	sxtw	x4, w4
    52a0:      	cmp	x1, #0x0
    52a4:      	b.gt	0x53c8 <_stogir.locals.validate+0x228>
    52a8:      	mov	x23, x8
    52ac:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		00000000000052ac:  ARM64_RELOC_PAGE21	l_stogir.397
    52b0:      	ldr	x16, [x16]
		00000000000052b0:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    52b4:      	orr	x0, x16, xzr
    52b8:      	mov	x2, #0x1                ; =1
    52bc:      	mov	x1, #0x17               ; =23
    52c0:      	b	0x5364 <_stogir.locals.validate+0x1c4>
    52c4:      	movz	x5, #0x0, lsl #48
    52c8:      	b	0x52d0 <_stogir.locals.validate+0x130>
    52cc:      	movz	x5, #0x0, lsl #48
    52d0:      	cmp	x5, #0x0
    52d4:      	b.eq	0x5310 <_stogir.locals.validate+0x170>
    52d8:      	uxtb	w16, w4
    52dc:      	cmp	w16, wzr
    52e0:      	b.eq	0x52f8 <_stogir.locals.validate+0x158>
    52e4:      	ldr	x4, [x0]
    52e8:      	add	x4, x4, x1, lsl #4
    52ec:      	ldr	x5, [x4]
    52f0:      	ldr	x4, [x4, #0x8]
    52f4:      	b	0x5308 <_stogir.locals.validate+0x168>
    52f8:      	ldr	x4, [x0, #0x28]
    52fc:      	add	x4, x4, x6, lsl #4
    5300:      	ldr	x5, [x4]
    5304:      	ldr	x4, [x4, #0x8]
    5308:      	mov	x6, #0x1                ; =1
    530c:      	b	0x531c <_stogir.locals.validate+0x17c>
    5310:      	movz	x6, #0x0, lsl #48
    5314:      	movz	x5, #0x0, lsl #48
    5318:      	movz	x4, #0x0, lsl #48
    531c:      	ubfx	x6, x6, #0, #32
    5320:      	lsr	x16, x6, #0
    5324:      	cmp	x16, #0x1
    5328:      	b.eq	0x5344 <_stogir.locals.validate+0x1a4>
    532c:      	b.lo	0x5334 <_stogir.locals.validate+0x194>
    5330:      	b	0x5348 <_stogir.locals.validate+0x1a8>
    5334:      	cmp	x16, #0x0
    5338:      	b.eq	0x5340 <_stogir.locals.validate+0x1a0>
    533c:      	b	0x5348 <_stogir.locals.validate+0x1a8>
    5340:      	b	0x534c <_stogir.locals.validate+0x1ac>
    5344:      	b	0x539c <_stogir.locals.validate+0x1fc>
    5348:      	b	0x556c <_stogir.locals.validate+0x3cc>
    534c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		000000000000534c:  ARM64_RELOC_PAGE21	l_stogir.398
    5350:      	ldr	x16, [x16]
		0000000000005350:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    5354:      	orr	x0, x16, xzr
    5358:      	mov	x23, x8
    535c:      	mov	x2, #0x1                ; =1
    5360:      	mov	x1, #0x17               ; =23
    5364:      	str	x2, [x23]
    5368:      	str	x0, [x23, #0x8]
    536c:      	str	x1, [x23, #0x10]
    5370:      	ldr	x19, [sp, #0x70]
    5374:      	ldr	x20, [sp, #0x78]
    5378:      	ldr	x21, [sp, #0x80]
    537c:      	ldr	x22, [sp, #0x88]
    5380:      	ldr	x23, [sp, #0x90]
    5384:      	ldr	x24, [sp, #0x98]
    5388:      	ldr	x25, [sp, #0xa0]
    538c:      	ldr	x29, [sp]
    5390:      	ldr	x30, [sp, #0x8]
    5394:      	add	sp, sp, #0xb0
    5398:      	ret
    539c:      	uxtb	w6, w5
    53a0:      	add	x16, sp, #0x10
    53a4:      	str	x5, [x16]
    53a8:      	add	x16, sp, #0x10
    53ac:      	str	x4, [x16, #0x8]
    53b0:      	cmp	x6, #0x55
    53b4:      	b.ne	0x5428 <_stogir.locals.validate+0x288>
    53b8:      	mov	x4, #0x1                ; =1
    53bc:      	b	0x5434 <_stogir.locals.validate+0x294>
    53c0:      	movz	x5, #0x0, lsl #48
    53c4:      	b	0x52c8 <_stogir.locals.validate+0x128>
    53c8:      	cmp	x6, #0x48
    53cc:      	cset	w21, eq
    53d0:      	uxtb	w16, w20
    53d4:      	cmp	w16, wzr
    53d8:      	b.ne	0x544c <_stogir.locals.validate+0x2ac>
    53dc:      	uxtb	w16, w21
    53e0:      	cmp	w16, wzr
    53e4:      	b.ne	0x544c <_stogir.locals.validate+0x2ac>
    53e8:      	cmp	x6, #0x55
    53ec:      	b.lt	0x58c4 <_stogir.locals.validate+0x724>
    53f0:      	cmp	x6, #0x58
    53f4:      	b.le	0x544c <_stogir.locals.validate+0x2ac>
    53f8:      	mov	x23, x8
    53fc:      	b	0x52ac <_stogir.locals.validate+0x10c>
    5400:      	cmp	x6, #0x58
    5404:      	cset	w5, eq
    5408:      	ubfx	x19, x5, #0, #8
    540c:      	cmp	x6, #0x41
    5410:      	cset	w20, eq
    5414:      	uxtb	w16, w20
    5418:      	cmp	w16, wzr
    541c:      	b.eq	0x5280 <_stogir.locals.validate+0xe0>
    5420:      	mov	x4, #0x1                ; =1
    5424:      	b	0x52a0 <_stogir.locals.validate+0x100>
    5428:      	cmp	x6, #0x56
    542c:      	cset	w4, eq
    5430:      	ubfx	x4, x4, #0, #8
    5434:      	cmp	x6, #0x57
    5438:      	b.ne	0x5400 <_stogir.locals.validate+0x260>
    543c:      	mov	x19, #0x1               ; =1
    5440:      	b	0x540c <_stogir.locals.validate+0x26c>
    5444:      	movz	x5, #0x0, lsl #48
    5448:      	b	0x527c <_stogir.locals.validate+0xdc>
    544c:      	sxtw	x4, w4
    5450:      	ldr	x5, [x0, #0x78]
    5454:      	add	x3, x3, x5
    5458:      	ldr	w3, [x3]
    545c:      	sxtw	x3, w3
    5460:      	cmp	x3, x4
    5464:      	b.ne	0x58cc <_stogir.locals.validate+0x72c>
    5468:      	uxtb	w16, w20
    546c:      	cmp	w16, wzr
    5470:      	b.ne	0x5490 <_stogir.locals.validate+0x2f0>
    5474:      	uxtb	w16, w21
    5478:      	cmp	w16, wzr
    547c:      	b.ne	0x5490 <_stogir.locals.validate+0x2f0>
    5480:      	add	x16, sp, #0x10
    5484:      	ldr	w1, [x16, #0x8]
    5488:      	sxtw	x1, w1
    548c:      	b	0x54a8 <_stogir.locals.validate+0x308>
    5490:      	uxtb	w16, w21
    5494:      	cmp	w16, wzr
    5498:      	b.ne	0x54a8 <_stogir.locals.validate+0x308>
    549c:      	add	x16, sp, #0x10
    54a0:      	ldr	w1, [x16, #0x4]
    54a4:      	sxtw	x1, w1
    54a8:      	add	x16, sp, #0x20
    54ac:      	orr	x22, x16, xzr
    54b0:      	mov	x23, x8
    54b4:      	add	x8, sp, #0x20
    54b8:      	mov	x24, x0
    54bc:      	mov	w25, w2
    54c0:      	bl	0x54c0 <_stogir.locals.validate+0x320>
		00000000000054c0:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    54c4:      	add	x16, sp, #0x20
    54c8:      	ldr	w0, [x16]
    54cc:      	lsr	x16, x0, #0
    54d0:      	cmp	x16, #0x1
    54d4:      	b.eq	0x54f0 <_stogir.locals.validate+0x350>
    54d8:      	b.lo	0x54e0 <_stogir.locals.validate+0x340>
    54dc:      	b	0x54f4 <_stogir.locals.validate+0x354>
    54e0:      	cmp	x16, #0x0
    54e4:      	b.eq	0x54ec <_stogir.locals.validate+0x34c>
    54e8:      	b	0x54f4 <_stogir.locals.validate+0x354>
    54ec:      	b	0x5510 <_stogir.locals.validate+0x370>
    54f0:      	b	0x54f8 <_stogir.locals.validate+0x358>
    54f4:      	b	0x5744 <_stogir.locals.validate+0x5a4>
    54f8:      	add	x1, x22, #0x8
    54fc:      	add	x16, sp, #0x20
    5500:      	ldr	x0, [x16, #0x8]
    5504:      	ldr	x1, [x1, #0x8]
    5508:      	mov	x2, #0x1                ; =1
    550c:      	b	0x52c0 <_stogir.locals.validate+0x120>
    5510:      	add	x16, sp, #0x20
    5514:      	ldr	x22, [x16, #0x8]
    5518:      	uxtb	w16, w21
    551c:      	cmp	w16, wzr
    5520:      	b.eq	0x5538 <_stogir.locals.validate+0x398>
    5524:      	sxtw	x22, w22
    5528:      	and	x0, x22, #0xffffffff
    552c:      	movz	x2, #0x0, lsl #48
    5530:      	movz	x1, #0x0, lsl #48
    5534:      	b	0x550c <_stogir.locals.validate+0x36c>
    5538:      	uxtb	w16, w20
    553c:      	cmp	w16, wzr
    5540:      	b.eq	0x558c <_stogir.locals.validate+0x3ec>
    5544:      	add	x16, sp, #0x10
    5548:      	ldr	w0, [x16]
    554c:      	ubfx	x0, x0, #8, #8
    5550:      	cmp	x0, #0x6
    5554:      	b.ne	0x5574 <_stogir.locals.validate+0x3d4>
    5558:      	sxtw	x25, w25
    555c:      	and	x0, x25, #0xffffffff
    5560:      	movz	x2, #0x0, lsl #48
    5564:      	movz	x1, #0x0, lsl #48
    5568:      	b	0x5588 <_stogir.locals.validate+0x3e8>
    556c:      	brk	#0
    5570:      	b	0x556c <_stogir.locals.validate+0x3cc>
    5574:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005574:  ARM64_RELOC_PAGE21	l_stogir.399
    5578:      	ldr	x16, [x16]
		0000000000005578:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    557c:      	orr	x0, x16, xzr
    5580:      	mov	x2, #0x1                ; =1
    5584:      	mov	x1, #0x21               ; =33
    5588:      	b	0x5534 <_stogir.locals.validate+0x394>
    558c:      	add	x16, sp, #0x10
    5590:      	ldr	w0, [x16, #0x4]
    5594:      	sxtw	x0, w0
    5598:      	cmp	x0, #0x0
    559c:      	cset	w1, gt
    55a0:      	movz	x16, #0x0, lsl #48
    55a4:      	sub	x2, x16, x0
    55a8:      	sub	x3, x2, #0x1
    55ac:      	uxtb	w16, w1
    55b0:      	cmp	w16, wzr
    55b4:      	b.eq	0x5688 <_stogir.locals.validate+0x4e8>
    55b8:      	ldr	x2, [x24, #0x8]
    55bc:      	cmp	x0, x2
    55c0:      	b.ge	0x5680 <_stogir.locals.validate+0x4e0>
    55c4:      	add	x2, x24, #0x78
    55c8:      	ldr	x2, [x2, #0x8]
    55cc:      	cmp	x0, x2
    55d0:      	b.ge	0x5734 <_stogir.locals.validate+0x594>
    55d4:      	ldr	x2, [x24, #0x78]
    55d8:      	add	x2, x2, x0, lsl #2
    55dc:      	ldr	w2, [x2]
    55e0:      	sxtw	x2, w2
    55e4:      	cmp	x2, #0x0
    55e8:      	cset	w2, ge
    55ec:      	ubfx	x2, x2, #0, #8
    55f0:      	b	0x5738 <_stogir.locals.validate+0x598>
    55f4:      	movz	x1, #0x0, lsl #48
    55f8:      	movz	x0, #0x0, lsl #48
    55fc:      	ubfx	x1, x1, #0, #32
    5600:      	lsr	x16, x1, #0
    5604:      	cmp	x16, #0x1
    5608:      	b.eq	0x5624 <_stogir.locals.validate+0x484>
    560c:      	b.lo	0x5614 <_stogir.locals.validate+0x474>
    5610:      	b	0x5628 <_stogir.locals.validate+0x488>
    5614:      	cmp	x16, #0x0
    5618:      	b.eq	0x5620 <_stogir.locals.validate+0x480>
    561c:      	b	0x5628 <_stogir.locals.validate+0x488>
    5620:      	b	0x562c <_stogir.locals.validate+0x48c>
    5624:      	b	0x56d0 <_stogir.locals.validate+0x530>
    5628:      	b	0x5898 <_stogir.locals.validate+0x6f8>
    562c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		000000000000562c:  ARM64_RELOC_PAGE21	l_stogir.400
    5630:      	ldr	x16, [x16]
		0000000000005630:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    5634:      	orr	x0, x16, xzr
    5638:      	mov	x2, #0x1                ; =1
    563c:      	mov	x1, #0x1c               ; =28
    5640:      	b	0x5588 <_stogir.locals.validate+0x3e8>
    5644:      	ldr	x0, [x24, #0x28]
    5648:      	add	x0, x0, x3, lsl #4
    564c:      	ldr	x0, [x0]
    5650:      	mov	x1, #0x1                ; =1
    5654:      	b	0x55fc <_stogir.locals.validate+0x45c>
    5658:      	movz	x2, #0x0, lsl #48
    565c:      	cmp	x2, #0x0
    5660:      	b.eq	0x55f4 <_stogir.locals.validate+0x454>
    5664:      	uxtb	w16, w1
    5668:      	cmp	w16, wzr
    566c:      	b.eq	0x5644 <_stogir.locals.validate+0x4a4>
    5670:      	ldr	x1, [x24]
    5674:      	add	x0, x1, x0, lsl #4
    5678:      	ldr	x0, [x0]
    567c:      	b	0x5650 <_stogir.locals.validate+0x4b0>
    5680:      	movz	x2, #0x0, lsl #48
    5684:      	b	0x565c <_stogir.locals.validate+0x4bc>
    5688:      	cmp	x0, #0x0
    568c:      	b.ge	0x5658 <_stogir.locals.validate+0x4b8>
    5690:      	add	x4, x24, #0x28
    5694:      	add	x5, x24, #0x50
    5698:      	ldr	x4, [x4, #0x8]
    569c:      	ldr	x5, [x5, #0x8]
    56a0:      	cmp	x4, x5
    56a4:      	b.ne	0x572c <_stogir.locals.validate+0x58c>
    56a8:      	cmp	x2, x4
    56ac:      	b.gt	0x573c <_stogir.locals.validate+0x59c>
    56b0:      	ldr	x2, [x24, #0x50]
    56b4:      	add	x2, x2, x3, lsl #2
    56b8:      	ldr	w2, [x2]
    56bc:      	sxtw	x2, w2
    56c0:      	cmp	x2, #0x0
    56c4:      	cset	w2, gt
    56c8:      	ubfx	x2, x2, #0, #8
    56cc:      	b	0x5740 <_stogir.locals.validate+0x5a0>
    56d0:      	add	x16, sp, #0x10
    56d4:      	ldr	w1, [x16, #0x4]
    56d8:      	sxtw	x1, w1
    56dc:      	cmp	x1, #0x0
    56e0:      	b.le	0x5714 <_stogir.locals.validate+0x574>
    56e4:      	uxtb	w0, w0
    56e8:      	cmp	x0, #0x83
    56ec:      	cset	w1, lt
    56f0:      	uxtb	w16, w1
    56f4:      	cmp	w16, wzr
    56f8:      	b.eq	0x574c <_stogir.locals.validate+0x5ac>
    56fc:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		00000000000056fc:  ARM64_RELOC_PAGE21	l_stogir.401
    5700:      	ldr	x16, [x16]
		0000000000005700:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    5704:      	orr	x2, x16, xzr
    5708:      	add	x2, x0, x2
    570c:      	ldrb	w2, [x2]
    5710:      	b	0x5750 <_stogir.locals.validate+0x5b0>
    5714:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005714:  ARM64_RELOC_PAGE21	l_stogir.402
    5718:      	ldr	x16, [x16]
		0000000000005718:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    571c:      	orr	x0, x16, xzr
    5720:      	mov	x2, #0x1                ; =1
    5724:      	mov	x1, #0x1c               ; =28
    5728:      	b	0x5640 <_stogir.locals.validate+0x4a0>
    572c:      	movz	x2, #0x0, lsl #48
    5730:      	b	0x565c <_stogir.locals.validate+0x4bc>
    5734:      	movz	x2, #0x0, lsl #48
    5738:      	b	0x5684 <_stogir.locals.validate+0x4e4>
    573c:      	movz	x2, #0x0, lsl #48
    5740:      	b	0x5730 <_stogir.locals.validate+0x590>
    5744:      	brk	#0
    5748:      	b	0x5744 <_stogir.locals.validate+0x5a4>
    574c:      	movz	x2, #0x0, lsl #48
    5750:      	uxtb	w2, w2
    5754:      	and	x2, x2, #0x1
    5758:      	uxtb	w2, w2
    575c:      	cmp	x2, #0x0
    5760:      	b.eq	0x5714 <_stogir.locals.validate+0x574>
    5764:      	uxtb	w16, w1
    5768:      	cmp	w16, wzr
    576c:      	b.eq	0x5788 <_stogir.locals.validate+0x5e8>
    5770:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005770:  ARM64_RELOC_PAGE21	l_stogir.401
    5774:      	ldr	x16, [x16]
		0000000000005774:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    5778:      	orr	x1, x16, xzr
    577c:      	add	x0, x0, x1
    5780:      	ldrb	w0, [x0]
    5784:      	b	0x578c <_stogir.locals.validate+0x5ec>
    5788:      	movz	x0, #0x0, lsl #48
    578c:      	uxtb	w0, w0
    5790:      	and	x0, x0, #0x4
    5794:      	uxtb	w0, w0
    5798:      	cmp	x0, #0x0
    579c:      	cset	w0, eq
    57a0:      	uxtb	w16, w0
    57a4:      	cmp	w16, wzr
    57a8:      	cset	x0, eq
    57ac:      	cmp	x0, #0x0
    57b0:      	b.ne	0x5714 <_stogir.locals.validate+0x574>
    57b4:      	cmp	x19, #0x0
    57b8:      	b.eq	0x5844 <_stogir.locals.validate+0x6a4>
    57bc:      	add	x16, sp, #0x10
    57c0:      	ldr	w0, [x16, #0xc]
    57c4:      	add	x8, sp, #0x40
    57c8:      	mov	w1, w0
    57cc:      	mov	x0, x24
    57d0:      	bl	0x57d0 <_stogir.locals.validate+0x630>
		00000000000057d0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    57d4:      	add	x16, sp, #0x40
    57d8:      	ldr	x0, [x16]
    57dc:      	add	x16, sp, #0x40
    57e0:      	ldr	x20, [x16, #0x8]
    57e4:      	b	0x5850 <_stogir.locals.validate+0x6b0>
    57e8:      	orr	w0, w20, wzr
    57ec:      	ubfx	x0, x0, #0, #32
    57f0:      	ubfx	x0, x0, #8, #8
    57f4:      	mov	w1, w25
    57f8:      	bl	0x57f8 <_stogir.locals.validate+0x658>
		00000000000057f8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    57fc:      	sxtw	x0, w0
    5800:      	cmp	x0, #0x0
    5804:      	b.le	0x582c <_stogir.locals.validate+0x68c>
    5808:      	cmp	x0, x22
    580c:      	b.gt	0x582c <_stogir.locals.validate+0x68c>
    5810:      	cmp	x19, #0x0
    5814:      	b.eq	0x58a0 <_stogir.locals.validate+0x700>
    5818:      	add	x16, sp, #0x10
    581c:      	ldr	w1, [x16]
    5820:      	ubfx	x1, x1, #8, #8
    5824:      	cmp	x1, #0x0
    5828:      	b.eq	0x58a0 <_stogir.locals.validate+0x700>
    582c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		000000000000582c:  ARM64_RELOC_PAGE21	l_stogir.403
    5830:      	ldr	x16, [x16]
		0000000000005830:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    5834:      	orr	x0, x16, xzr
    5838:      	mov	x2, #0x1                ; =1
    583c:      	mov	x1, #0x23               ; =35
    5840:      	b	0x5728 <_stogir.locals.validate+0x588>
    5844:      	add	x16, sp, #0x10
    5848:      	ldr	x20, [x16]
    584c:      	mov	x0, #0x1                ; =1
    5850:      	ubfx	x0, x0, #0, #32
    5854:      	lsr	x16, x0, #0
    5858:      	cmp	x16, #0x1
    585c:      	b.eq	0x5878 <_stogir.locals.validate+0x6d8>
    5860:      	b.lo	0x5868 <_stogir.locals.validate+0x6c8>
    5864:      	b	0x587c <_stogir.locals.validate+0x6dc>
    5868:      	cmp	x16, #0x0
    586c:      	b.eq	0x5874 <_stogir.locals.validate+0x6d4>
    5870:      	b	0x587c <_stogir.locals.validate+0x6dc>
    5874:      	b	0x5880 <_stogir.locals.validate+0x6e0>
    5878:      	b	0x57e8 <_stogir.locals.validate+0x648>
    587c:      	b	0x58bc <_stogir.locals.validate+0x71c>
    5880:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005880:  ARM64_RELOC_PAGE21	l_stogir.404
    5884:      	ldr	x16, [x16]
		0000000000005884:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    5888:      	orr	x0, x16, xzr
    588c:      	mov	x2, #0x1                ; =1
    5890:      	mov	x1, #0x19               ; =25
    5894:      	b	0x5840 <_stogir.locals.validate+0x6a0>
    5898:      	brk	#0
    589c:      	b	0x5898 <_stogir.locals.validate+0x6f8>
    58a0:      	uxtb	w20, w20
    58a4:      	cmp	x20, #0x48
    58a8:      	b.eq	0x582c <_stogir.locals.validate+0x68c>
    58ac:      	and	x0, x0, #0xffffffff
    58b0:      	movz	x2, #0x0, lsl #48
    58b4:      	movz	x1, #0x0, lsl #48
    58b8:      	b	0x5840 <_stogir.locals.validate+0x6a0>
    58bc:      	brk	#0
    58c0:      	b	0x58bc <_stogir.locals.validate+0x71c>
    58c4:      	mov	x23, x8
    58c8:      	b	0x52ac <_stogir.locals.validate+0x10c>
    58cc:      	mov	x23, x8
    58d0:      	b	0x52ac <_stogir.locals.validate+0x10c>

00000000000058d4 <_stogir.conversion.validate>:
    58d4:      	sub	sp, sp, #0x40
    58d8:      	str	x29, [sp]
    58dc:      	str	x30, [sp, #0x8]
    58e0:      	mov	x29, sp
    58e4:      	str	x19, [sp, #0x30]
    58e8:      	sxtw	x1, w1
    58ec:      	lsl	x3, x1, #2
    58f0:      	cmp	x1, #0x0
    58f4:      	cset	w4, gt
    58f8:      	movz	x16, #0x0, lsl #48
    58fc:      	sub	x5, x16, x1
    5900:      	sub	x6, x5, #0x1
    5904:      	uxtb	w16, w4
    5908:      	cmp	w16, wzr
    590c:      	b.eq	0x594c <_stogir.conversion.validate+0x78>
    5910:      	ldr	x5, [x0, #0x8]
    5914:      	cmp	x1, x5
    5918:      	b.ge	0x599c <_stogir.conversion.validate+0xc8>
    591c:      	add	x5, x0, #0x78
    5920:      	ldr	x5, [x5, #0x8]
    5924:      	cmp	x1, x5
    5928:      	b.ge	0x5a74 <_stogir.conversion.validate+0x1a0>
    592c:      	ldr	x5, [x0, #0x78]
    5930:      	add	x5, x3, x5
    5934:      	ldr	w5, [x5]
    5938:      	sxtw	x5, w5
    593c:      	cmp	x5, #0x0
    5940:      	cset	w5, ge
    5944:      	ubfx	x5, x5, #0, #8
    5948:      	b	0x5a78 <_stogir.conversion.validate+0x1a4>
    594c:      	cmp	x1, #0x0
    5950:      	b.ge	0x59a4 <_stogir.conversion.validate+0xd0>
    5954:      	add	x7, x0, #0x28
    5958:      	add	x9, x0, #0x50
    595c:      	ldr	x7, [x7, #0x8]
    5960:      	ldr	x9, [x9, #0x8]
    5964:      	cmp	x7, x9
    5968:      	b.ne	0x5994 <_stogir.conversion.validate+0xc0>
    596c:      	cmp	x5, x7
    5970:      	b.gt	0x5b08 <_stogir.conversion.validate+0x234>
    5974:      	ldr	x5, [x0, #0x50]
    5978:      	add	x5, x5, x6, lsl #2
    597c:      	ldr	w5, [x5]
    5980:      	sxtw	x5, w5
    5984:      	cmp	x5, #0x0
    5988:      	cset	w5, gt
    598c:      	ubfx	x5, x5, #0, #8
    5990:      	b	0x5b0c <_stogir.conversion.validate+0x238>
    5994:      	movz	x5, #0x0, lsl #48
    5998:      	b	0x59a8 <_stogir.conversion.validate+0xd4>
    599c:      	movz	x5, #0x0, lsl #48
    59a0:      	b	0x59a8 <_stogir.conversion.validate+0xd4>
    59a4:      	movz	x5, #0x0, lsl #48
    59a8:      	cmp	x5, #0x0
    59ac:      	b.eq	0x59e0 <_stogir.conversion.validate+0x10c>
    59b0:      	uxtb	w16, w4
    59b4:      	cmp	w16, wzr
    59b8:      	b.eq	0x59cc <_stogir.conversion.validate+0xf8>
    59bc:      	ldr	x4, [x0]
    59c0:      	add	x4, x4, x1, lsl #4
    59c4:      	ldr	x4, [x4]
    59c8:      	b	0x59d8 <_stogir.conversion.validate+0x104>
    59cc:      	ldr	x4, [x0, #0x28]
    59d0:      	add	x4, x4, x6, lsl #4
    59d4:      	ldr	x4, [x4]
    59d8:      	mov	x5, #0x1                ; =1
    59dc:      	b	0x59e8 <_stogir.conversion.validate+0x114>
    59e0:      	movz	x5, #0x0, lsl #48
    59e4:      	movz	x4, #0x0, lsl #48
    59e8:      	ubfx	x5, x5, #0, #32
    59ec:      	lsr	x16, x5, #0
    59f0:      	cmp	x16, #0x1
    59f4:      	b.eq	0x5a10 <_stogir.conversion.validate+0x13c>
    59f8:      	b.lo	0x5a00 <_stogir.conversion.validate+0x12c>
    59fc:      	b	0x5a14 <_stogir.conversion.validate+0x140>
    5a00:      	cmp	x16, #0x0
    5a04:      	b.eq	0x5a0c <_stogir.conversion.validate+0x138>
    5a08:      	b	0x5a14 <_stogir.conversion.validate+0x140>
    5a0c:      	b	0x5a18 <_stogir.conversion.validate+0x144>
    5a10:      	b	0x5a50 <_stogir.conversion.validate+0x17c>
    5a14:      	b	0x5b80 <_stogir.conversion.validate+0x2ac>
    5a18:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005a18:  ARM64_RELOC_PAGE21	l_stogir.405
    5a1c:      	ldr	x16, [x16]
		0000000000005a1c:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    5a20:      	orr	x0, x16, xzr
    5a24:      	mov	x19, x8
    5a28:      	mov	x1, #0x1                ; =1
    5a2c:      	mov	x2, #0x12               ; =18
    5a30:      	str	x1, [x19]
    5a34:      	str	x0, [x19, #0x8]
    5a38:      	str	x2, [x19, #0x10]
    5a3c:      	ldr	x19, [sp, #0x30]
    5a40:      	ldr	x29, [sp]
    5a44:      	ldr	x30, [sp, #0x8]
    5a48:      	add	sp, sp, #0x40
    5a4c:      	ret
    5a50:      	cmp	x1, #0x0
    5a54:      	b.gt	0x5a7c <_stogir.conversion.validate+0x1a8>
    5a58:      	mov	x19, x8
    5a5c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005a5c:  ARM64_RELOC_PAGE21	l_stogir.406
    5a60:      	ldr	x16, [x16]
		0000000000005a60:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    5a64:      	orr	x0, x16, xzr
    5a68:      	mov	x1, #0x1                ; =1
    5a6c:      	mov	x2, #0x1e               ; =30
    5a70:      	b	0x5a30 <_stogir.conversion.validate+0x15c>
    5a74:      	movz	x5, #0x0, lsl #48
    5a78:      	b	0x59a0 <_stogir.conversion.validate+0xcc>
    5a7c:      	uxtb	w1, w4
    5a80:      	orr	x5, x1, xzr
    5a84:      	cmp	x5, #0x21
    5a88:      	b.lt	0x5c98 <_stogir.conversion.validate+0x3c4>
    5a8c:      	cmp	x5, #0x27
    5a90:      	b.gt	0x5ca0 <_stogir.conversion.validate+0x3cc>
    5a94:      	ldr	x5, [x0, #0x78]
    5a98:      	add	x3, x3, x5
    5a9c:      	ldr	w3, [x3]
    5aa0:      	sxtw	x3, w3
    5aa4:      	cmp	x3, #0x1
    5aa8:      	b.ne	0x5ca8 <_stogir.conversion.validate+0x3d4>
    5aac:      	asr	x3, x4, #32
    5ab0:      	cmp	x3, #0x0
    5ab4:      	cset	w6, gt
    5ab8:      	movz	x16, #0x0, lsl #48
    5abc:      	sub	x7, x16, x3
    5ac0:      	sub	x9, x7, #0x1
    5ac4:      	uxtb	w16, w6
    5ac8:      	cmp	w16, wzr
    5acc:      	b.eq	0x5b38 <_stogir.conversion.validate+0x264>
    5ad0:      	ldr	x7, [x0, #0x8]
    5ad4:      	cmp	x3, x7
    5ad8:      	b.ge	0x5b88 <_stogir.conversion.validate+0x2b4>
    5adc:      	add	x7, x0, #0x78
    5ae0:      	ldr	x7, [x7, #0x8]
    5ae4:      	cmp	x3, x7
    5ae8:      	b.ge	0x5c28 <_stogir.conversion.validate+0x354>
    5aec:      	add	x5, x5, x3, lsl #2
    5af0:      	ldr	w5, [x5]
    5af4:      	sxtw	x5, w5
    5af8:      	cmp	x5, #0x0
    5afc:      	cset	w5, ge
    5b00:      	ubfx	x5, x5, #0, #8
    5b04:      	b	0x5c2c <_stogir.conversion.validate+0x358>
    5b08:      	movz	x5, #0x0, lsl #48
    5b0c:      	b	0x5998 <_stogir.conversion.validate+0xc4>
    5b10:      	uxtb	w3, w0
    5b14:      	cmp	x3, #0x48
    5b18:      	b.ne	0x5c30 <_stogir.conversion.validate+0x35c>
    5b1c:      	mov	x19, x8
    5b20:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005b20:  ARM64_RELOC_PAGE21	l_stogir.407
    5b24:      	ldr	x16, [x16]
		0000000000005b24:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    5b28:      	orr	x0, x16, xzr
    5b2c:      	mov	x1, #0x1                ; =1
    5b30:      	mov	x2, #0x25               ; =37
    5b34:      	b	0x5a70 <_stogir.conversion.validate+0x19c>
    5b38:      	cmp	x3, #0x0
    5b3c:      	b.ge	0x5b90 <_stogir.conversion.validate+0x2bc>
    5b40:      	add	x5, x0, #0x28
    5b44:      	add	x10, x0, #0x50
    5b48:      	ldr	x5, [x5, #0x8]
    5b4c:      	ldr	x10, [x10, #0x8]
    5b50:      	cmp	x5, x10
    5b54:      	b.ne	0x5c20 <_stogir.conversion.validate+0x34c>
    5b58:      	cmp	x7, x5
    5b5c:      	b.gt	0x5c88 <_stogir.conversion.validate+0x3b4>
    5b60:      	ldr	x5, [x0, #0x50]
    5b64:      	add	x5, x5, x9, lsl #2
    5b68:      	ldr	w5, [x5]
    5b6c:      	sxtw	x5, w5
    5b70:      	cmp	x5, #0x0
    5b74:      	cset	w5, gt
    5b78:      	ubfx	x5, x5, #0, #8
    5b7c:      	b	0x5c8c <_stogir.conversion.validate+0x3b8>
    5b80:      	brk	#0
    5b84:      	b	0x5b80 <_stogir.conversion.validate+0x2ac>
    5b88:      	movz	x5, #0x0, lsl #48
    5b8c:      	b	0x5b94 <_stogir.conversion.validate+0x2c0>
    5b90:      	movz	x5, #0x0, lsl #48
    5b94:      	cmp	x5, #0x0
    5b98:      	b.eq	0x5bcc <_stogir.conversion.validate+0x2f8>
    5b9c:      	uxtb	w16, w6
    5ba0:      	cmp	w16, wzr
    5ba4:      	b.eq	0x5bb8 <_stogir.conversion.validate+0x2e4>
    5ba8:      	ldr	x0, [x0]
    5bac:      	add	x0, x0, x3, lsl #4
    5bb0:      	ldr	x0, [x0]
    5bb4:      	b	0x5bc4 <_stogir.conversion.validate+0x2f0>
    5bb8:      	ldr	x0, [x0, #0x28]
    5bbc:      	add	x0, x0, x9, lsl #4
    5bc0:      	ldr	x0, [x0]
    5bc4:      	mov	x3, #0x1                ; =1
    5bc8:      	b	0x5bd4 <_stogir.conversion.validate+0x300>
    5bcc:      	movz	x3, #0x0, lsl #48
    5bd0:      	movz	x0, #0x0, lsl #48
    5bd4:      	ubfx	x3, x3, #0, #32
    5bd8:      	lsr	x16, x3, #0
    5bdc:      	cmp	x16, #0x1
    5be0:      	b.eq	0x5bfc <_stogir.conversion.validate+0x328>
    5be4:      	b.lo	0x5bec <_stogir.conversion.validate+0x318>
    5be8:      	b	0x5c00 <_stogir.conversion.validate+0x32c>
    5bec:      	cmp	x16, #0x0
    5bf0:      	b.eq	0x5bf8 <_stogir.conversion.validate+0x324>
    5bf4:      	b	0x5c00 <_stogir.conversion.validate+0x32c>
    5bf8:      	b	0x5c04 <_stogir.conversion.validate+0x330>
    5bfc:      	b	0x5b10 <_stogir.conversion.validate+0x23c>
    5c00:      	b	0x5c90 <_stogir.conversion.validate+0x3bc>
    5c04:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005c04:  ARM64_RELOC_PAGE21	l_stogir.408
    5c08:      	ldr	x16, [x16]
		0000000000005c08:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    5c0c:      	orr	x0, x16, xzr
    5c10:      	mov	x19, x8
    5c14:      	mov	x1, #0x1                ; =1
    5c18:      	mov	x2, #0x19               ; =25
    5c1c:      	b	0x5b34 <_stogir.conversion.validate+0x260>
    5c20:      	movz	x5, #0x0, lsl #48
    5c24:      	b	0x5b94 <_stogir.conversion.validate+0x2c0>
    5c28:      	movz	x5, #0x0, lsl #48
    5c2c:      	b	0x5b8c <_stogir.conversion.validate+0x2b8>
    5c30:      	cmp	x3, #0x46
    5c34:      	b.eq	0x5cb0 <_stogir.conversion.validate+0x3dc>
    5c38:      	ubfx	x4, x4, #0, #32
    5c3c:      	ubfx	x0, x0, #0, #32
    5c40:      	ubfx	x3, x4, #8, #8
    5c44:      	ubfx	x0, x0, #8, #8
    5c48:      	mov	x19, x8
    5c4c:      	add	x8, sp, #0x10
    5c50:      	fmov	s31, w0
    5c54:      	mov	w0, w1
    5c58:      	fmov	w1, s31
    5c5c:      	fmov	s31, w2
    5c60:      	mov	w2, w3
    5c64:      	fmov	w3, s31
    5c68:      	bl	0x5c68 <_stogir.conversion.validate+0x394>
		0000000000005c68:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    5c6c:      	add	x16, sp, #0x10
    5c70:      	ldr	x1, [x16]
    5c74:      	add	x16, sp, #0x10
    5c78:      	ldr	x0, [x16, #0x8]
    5c7c:      	add	x16, sp, #0x10
    5c80:      	ldr	x2, [x16, #0x10]
    5c84:      	b	0x5b34 <_stogir.conversion.validate+0x260>
    5c88:      	movz	x5, #0x0, lsl #48
    5c8c:      	b	0x5c24 <_stogir.conversion.validate+0x350>
    5c90:      	brk	#0
    5c94:      	b	0x5c90 <_stogir.conversion.validate+0x3bc>
    5c98:      	mov	x19, x8
    5c9c:      	b	0x5a5c <_stogir.conversion.validate+0x188>
    5ca0:      	mov	x19, x8
    5ca4:      	b	0x5a5c <_stogir.conversion.validate+0x188>
    5ca8:      	mov	x19, x8
    5cac:      	b	0x5a5c <_stogir.conversion.validate+0x188>
    5cb0:      	mov	x19, x8
    5cb4:      	b	0x5b20 <_stogir.conversion.validate+0x24c>

0000000000005cb8 <_stogir.conditional.validate>:
    5cb8:      	sub	sp, sp, #0x40
    5cbc:      	str	x29, [sp]
    5cc0:      	str	x30, [sp, #0x8]
    5cc4:      	mov	x29, sp
    5cc8:      	str	x19, [sp, #0x30]
    5ccc:      	sxtw	x1, w1
    5cd0:      	lsl	x2, x1, #2
    5cd4:      	cmp	x1, #0x0
    5cd8:      	cset	w3, gt
    5cdc:      	movz	x16, #0x0, lsl #48
    5ce0:      	sub	x4, x16, x1
    5ce4:      	sub	x5, x4, #0x1
    5ce8:      	uxtb	w16, w3
    5cec:      	cmp	w16, wzr
    5cf0:      	b.eq	0x5d30 <_stogir.conditional.validate+0x78>
    5cf4:      	ldr	x4, [x0, #0x8]
    5cf8:      	cmp	x1, x4
    5cfc:      	b.ge	0x5d80 <_stogir.conditional.validate+0xc8>
    5d00:      	add	x4, x0, #0x78
    5d04:      	ldr	x4, [x4, #0x8]
    5d08:      	cmp	x1, x4
    5d0c:      	b.ge	0x5e64 <_stogir.conditional.validate+0x1ac>
    5d10:      	ldr	x4, [x0, #0x78]
    5d14:      	add	x4, x2, x4
    5d18:      	ldr	w4, [x4]
    5d1c:      	sxtw	x4, w4
    5d20:      	cmp	x4, #0x0
    5d24:      	cset	w4, ge
    5d28:      	ubfx	x4, x4, #0, #8
    5d2c:      	b	0x5e68 <_stogir.conditional.validate+0x1b0>
    5d30:      	cmp	x1, #0x0
    5d34:      	b.ge	0x5d88 <_stogir.conditional.validate+0xd0>
    5d38:      	add	x6, x0, #0x28
    5d3c:      	add	x7, x0, #0x50
    5d40:      	ldr	x6, [x6, #0x8]
    5d44:      	ldr	x7, [x7, #0x8]
    5d48:      	cmp	x6, x7
    5d4c:      	b.ne	0x5d78 <_stogir.conditional.validate+0xc0>
    5d50:      	cmp	x4, x6
    5d54:      	b.gt	0x5ee4 <_stogir.conditional.validate+0x22c>
    5d58:      	ldr	x4, [x0, #0x50]
    5d5c:      	add	x4, x4, x5, lsl #2
    5d60:      	ldr	w4, [x4]
    5d64:      	sxtw	x4, w4
    5d68:      	cmp	x4, #0x0
    5d6c:      	cset	w4, gt
    5d70:      	ubfx	x4, x4, #0, #8
    5d74:      	b	0x5ee8 <_stogir.conditional.validate+0x230>
    5d78:      	movz	x4, #0x0, lsl #48
    5d7c:      	b	0x5d8c <_stogir.conditional.validate+0xd4>
    5d80:      	movz	x4, #0x0, lsl #48
    5d84:      	b	0x5d8c <_stogir.conditional.validate+0xd4>
    5d88:      	movz	x4, #0x0, lsl #48
    5d8c:      	cmp	x4, #0x0
    5d90:      	b.eq	0x5dcc <_stogir.conditional.validate+0x114>
    5d94:      	uxtb	w16, w3
    5d98:      	cmp	w16, wzr
    5d9c:      	b.eq	0x5db4 <_stogir.conditional.validate+0xfc>
    5da0:      	ldr	x3, [x0]
    5da4:      	add	x3, x3, x1, lsl #4
    5da8:      	ldr	x4, [x3]
    5dac:      	ldr	x3, [x3, #0x8]
    5db0:      	b	0x5dc4 <_stogir.conditional.validate+0x10c>
    5db4:      	ldr	x3, [x0, #0x28]
    5db8:      	add	x3, x3, x5, lsl #4
    5dbc:      	ldr	x4, [x3]
    5dc0:      	ldr	x3, [x3, #0x8]
    5dc4:      	mov	x5, #0x1                ; =1
    5dc8:      	b	0x5dd8 <_stogir.conditional.validate+0x120>
    5dcc:      	movz	x5, #0x0, lsl #48
    5dd0:      	movz	x4, #0x0, lsl #48
    5dd4:      	movz	x3, #0x0, lsl #48
    5dd8:      	ubfx	x5, x5, #0, #32
    5ddc:      	lsr	x16, x5, #0
    5de0:      	cmp	x16, #0x1
    5de4:      	b.eq	0x5e00 <_stogir.conditional.validate+0x148>
    5de8:      	b.lo	0x5df0 <_stogir.conditional.validate+0x138>
    5dec:      	b	0x5e04 <_stogir.conditional.validate+0x14c>
    5df0:      	cmp	x16, #0x0
    5df4:      	b.eq	0x5dfc <_stogir.conditional.validate+0x144>
    5df8:      	b	0x5e04 <_stogir.conditional.validate+0x14c>
    5dfc:      	b	0x5e08 <_stogir.conditional.validate+0x150>
    5e00:      	b	0x5e24 <_stogir.conditional.validate+0x16c>
    5e04:      	b	0x5eec <_stogir.conditional.validate+0x234>
    5e08:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005e08:  ARM64_RELOC_PAGE21	l_stogir.409
    5e0c:      	ldr	x16, [x16]
		0000000000005e0c:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    5e10:      	orr	x0, x16, xzr
    5e14:      	mov	x19, x8
    5e18:      	mov	x1, #0x1                ; =1
    5e1c:      	mov	x2, #0x18               ; =24
    5e20:      	b	0x5e44 <_stogir.conditional.validate+0x18c>
    5e24:      	cmp	x1, #0x0
    5e28:      	b.gt	0x5e6c <_stogir.conditional.validate+0x1b4>
    5e2c:      	mov	x19, x8
    5e30:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x42c>
		0000000000005e30:  ARM64_RELOC_PAGE21	l_stogir.410
    5e34:      	ldr	x16, [x16]
		0000000000005e34:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    5e38:      	orr	x0, x16, xzr
    5e3c:      	mov	x1, #0x1                ; =1
    5e40:      	mov	x2, #0x18               ; =24
    5e44:      	str	x1, [x19]
    5e48:      	str	x0, [x19, #0x8]
    5e4c:      	str	x2, [x19, #0x10]
    5e50:      	ldr	x19, [sp, #0x30]
    5e54:      	ldr	x29, [sp]
    5e58:      	ldr	x30, [sp, #0x8]
    5e5c:      	add	sp, sp, #0x40
    5e60:      	ret
    5e64:      	movz	x4, #0x0, lsl #48
    5e68:      	b	0x5d84 <_stogir.conditional.validate+0xcc>
    5e6c:      	uxtb	w1, w4
    5e70:      	cmp	x1, #0x3c
    5e74:      	b.ne	0x5ef4 <_stogir.conditional.validate+0x23c>
    5e78:      	ldr	x1, [x0, #0x78]
    5e7c:      	add	x1, x2, x1
    5e80:      	ldr	w1, [x1]
    5e84:      	sxtw	x1, w1
    5e88:      	cmp	x1, #0x3
    5e8c:      	b.ne	0x5efc <_stogir.conditional.validate+0x244>
    5e90:      	orr	w1, w3, wzr
    5e94:      	orr	w2, w4, wzr
    5e98:      	lsr	x4, x4, #32
    5e9c:      	lsr	x3, x3, #32
    5ea0:      	ubfx	x2, x2, #0, #32
    5ea4:      	ubfx	x2, x2, #8, #8
    5ea8:      	mov	x19, x8
    5eac:      	add	x8, sp, #0x10
    5eb0:      	fmov	s31, w1
    5eb4:      	mov	w1, w2
    5eb8:      	mov	w2, w4
    5ebc:      	mov	w4, w3
    5ec0:      	fmov	w3, s31
    5ec4:      	bl	0x5ec4 <_stogir.conditional.validate+0x20c>
		0000000000005ec4:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    5ec8:      	add	x16, sp, #0x10
    5ecc:      	ldr	x1, [x16]
    5ed0:      	add	x16, sp, #0x10
    5ed4:      	ldr	x0, [x16, #0x8]
    5ed8:      	add	x16, sp, #0x10
    5edc:      	ldr	x2, [x16, #0x10]
    5ee0:      	b	0x5e44 <_stogir.conditional.validate+0x18c>
    5ee4:      	movz	x4, #0x0, lsl #48
    5ee8:      	b	0x5d7c <_stogir.conditional.validate+0xc4>
    5eec:      	brk	#0
    5ef0:      	b	0x5eec <_stogir.conditional.validate+0x234>
    5ef4:      	mov	x19, x8
    5ef8:      	b	0x5e30 <_stogir.conditional.validate+0x178>
    5efc:      	mov	x19, x8
    5f00:      	b	0x5e30 <_stogir.conditional.validate+0x178>

0000000000005f04 <_stogir.floating.validate>:
    5f04:      	sub	sp, sp, #0x50
    5f08:      	str	x29, [sp]
    5f0c:      	str	x30, [sp, #0x8]
    5f10:      	mov	x29, sp
    5f14:      	str	x19, [sp, #0x40]
    5f18:      	sxtw	x1, w1
    5f1c:      	lsl	x2, x1, #2
    5f20:      	cmp	x1, #0x0
    5f24:      	cset	w3, gt
    5f28:      	movz	x16, #0x0, lsl #48
    5f2c:      	sub	x4, x16, x1
    5f30:      	sub	x5, x4, #0x1
    5f34:      	uxtb	w16, w3
    5f38:      	cmp	w16, wzr
    5f3c:      	b.eq	0x5f7c <_stogir.floating.validate+0x78>
    5f40:      	ldr	x4, [x0, #0x8]
    5f44:      	cmp	x1, x4
    5f48:      	b.ge	0x5fcc <_stogir.floating.validate+0xc8>
    5f4c:      	add	x4, x0, #0x78
    5f50:      	ldr	x4, [x4, #0x8]
    5f54:      	cmp	x1, x4
    5f58:      	b.ge	0x60c0 <_stogir.floating.validate+0x1bc>
    5f5c:      	ldr	x4, [x0, #0x78]
    5f60:      	add	x4, x2, x4
    5f64:      	ldr	w4, [x4]
    5f68:      	sxtw	x4, w4
    5f6c:      	cmp	x4, #0x0
    5f70:      	cset	w4, ge
    5f74:      	ubfx	x4, x4, #0, #8
    5f78:      	b	0x60c4 <_stogir.floating.validate+0x1c0>
    5f7c:      	cmp	x1, #0x0
    5f80:      	b.ge	0x5fd4 <_stogir.floating.validate+0xd0>
    5f84:      	add	x6, x0, #0x28
    5f88:      	add	x7, x0, #0x50
    5f8c:      	ldr	x6, [x6, #0x8]
    5f90:      	ldr	x7, [x7, #0x8]
    5f94:      	cmp	x6, x7
    5f98:      	b.ne	0x5fc4 <_stogir.floating.validate+0xc0>
    5f9c:      	cmp	x4, x6
    5fa0:      	b.gt	0x614c <_stogir.floating.validate+0x248>
    5fa4:      	ldr	x4, [x0, #0x50]
    5fa8:      	add	x4, x4, x5, lsl #2
    5fac:      	ldr	w4, [x4]
    5fb0:      	sxtw	x4, w4
    5fb4:      	cmp	x4, #0x0
    5fb8:      	cset	w4, gt
    5fbc:      	ubfx	x4, x4, #0, #8
    5fc0:      	b	0x6150 <_stogir.floating.validate+0x24c>
    5fc4:      	movz	x4, #0x0, lsl #48
    5fc8:      	b	0x5fd8 <_stogir.floating.validate+0xd4>
    5fcc:      	movz	x4, #0x0, lsl #48
    5fd0:      	b	0x5fd8 <_stogir.floating.validate+0xd4>
    5fd4:      	movz	x4, #0x0, lsl #48
    5fd8:      	cmp	x4, #0x0
    5fdc:      	b.eq	0x6018 <_stogir.floating.validate+0x114>
    5fe0:      	uxtb	w16, w3
    5fe4:      	cmp	w16, wzr
    5fe8:      	b.eq	0x6000 <_stogir.floating.validate+0xfc>
    5fec:      	ldr	x3, [x0]
    5ff0:      	add	x3, x3, x1, lsl #4
    5ff4:      	ldr	x4, [x3]
    5ff8:      	ldr	x3, [x3, #0x8]
    5ffc:      	b	0x6010 <_stogir.floating.validate+0x10c>
    6000:      	ldr	x3, [x0, #0x28]
    6004:      	add	x3, x3, x5, lsl #4
    6008:      	ldr	x4, [x3]
    600c:      	ldr	x3, [x3, #0x8]
    6010:      	mov	x5, #0x1                ; =1
    6014:      	b	0x6024 <_stogir.floating.validate+0x120>
    6018:      	movz	x5, #0x0, lsl #48
    601c:      	movz	x4, #0x0, lsl #48
    6020:      	movz	x3, #0x0, lsl #48
    6024:      	ubfx	x5, x5, #0, #32
    6028:      	lsr	x16, x5, #0
    602c:      	cmp	x16, #0x1
    6030:      	b.eq	0x604c <_stogir.floating.validate+0x148>
    6034:      	b.lo	0x603c <_stogir.floating.validate+0x138>
    6038:      	b	0x6050 <_stogir.floating.validate+0x14c>
    603c:      	cmp	x16, #0x0
    6040:      	b.eq	0x6048 <_stogir.floating.validate+0x144>
    6044:      	b	0x6050 <_stogir.floating.validate+0x14c>
    6048:      	b	0x6054 <_stogir.floating.validate+0x150>
    604c:      	b	0x608c <_stogir.floating.validate+0x188>
    6050:      	b	0x63cc <_stogir.floating.validate+0x4c8>
    6054:      	adrp	x16, 0x6000 <_stogir.floating.validate+0xfc>
		0000000000006054:  ARM64_RELOC_PAGE21	l_stogir.411
    6058:      	ldr	x16, [x16]
		0000000000006058:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    605c:      	orr	x0, x16, xzr
    6060:      	mov	x19, x8
    6064:      	mov	x1, #0x1                ; =1
    6068:      	mov	x2, #0x1c               ; =28
    606c:      	str	x1, [x19]
    6070:      	str	x0, [x19, #0x8]
    6074:      	str	x2, [x19, #0x10]
    6078:      	ldr	x19, [sp, #0x40]
    607c:      	ldr	x29, [sp]
    6080:      	ldr	x30, [sp, #0x8]
    6084:      	add	sp, sp, #0x50
    6088:      	ret
    608c:      	add	x16, sp, #0x10
    6090:      	str	x4, [x16]
    6094:      	add	x16, sp, #0x10
    6098:      	str	x3, [x16, #0x8]
    609c:      	cmp	x1, #0x0
    60a0:      	b.gt	0x60c8 <_stogir.floating.validate+0x1c4>
    60a4:      	mov	x19, x8
    60a8:      	adrp	x16, 0x6000 <_stogir.floating.validate+0xfc>
		00000000000060a8:  ARM64_RELOC_PAGE21	l_stogir.412
    60ac:      	ldr	x16, [x16]
		00000000000060ac:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    60b0:      	orr	x0, x16, xzr
    60b4:      	mov	x1, #0x1                ; =1
    60b8:      	mov	x2, #0x1c               ; =28
    60bc:      	b	0x606c <_stogir.floating.validate+0x168>
    60c0:      	movz	x4, #0x0, lsl #48
    60c4:      	b	0x5fd0 <_stogir.floating.validate+0xcc>
    60c8:      	uxtb	w4, w4
    60cc:      	orr	x1, x4, xzr
    60d0:      	cmp	x1, #0xe
    60d4:      	cset	w3, ge
    60d8:      	cmp	x1, #0x19
    60dc:      	cset	w5, le
    60e0:      	cmp	x1, #0x1f
    60e4:      	cset	w6, eq
    60e8:      	cmp	x1, #0x20
    60ec:      	cset	w7, eq
    60f0:      	uxtb	w16, w3
    60f4:      	cmp	w16, wzr
    60f8:      	b.eq	0x6154 <_stogir.floating.validate+0x250>
    60fc:      	uxtb	w16, w5
    6100:      	cmp	w16, wzr
    6104:      	b.eq	0x6154 <_stogir.floating.validate+0x250>
    6108:      	cmp	x1, #0x1d
    610c:      	cset	w1, eq
    6110:      	ldr	x9, [x0, #0x78]
    6114:      	add	x2, x2, x9
    6118:      	ldr	w2, [x2]
    611c:      	uxtb	w16, w6
    6120:      	cmp	w16, wzr
    6124:      	b.ne	0x6194 <_stogir.floating.validate+0x290>
    6128:      	uxtb	w16, w7
    612c:      	cmp	w16, wzr
    6130:      	b.ne	0x6194 <_stogir.floating.validate+0x290>
    6134:      	uxtb	w16, w1
    6138:      	cmp	w16, wzr
    613c:      	mov	x16, #0x3               ; =3
    6140:      	mov	x17, #0x2               ; =2
    6144:      	csel	x6, x16, x17, ne
    6148:      	b	0x6198 <_stogir.floating.validate+0x294>
    614c:      	movz	x4, #0x0, lsl #48
    6150:      	b	0x5fc8 <_stogir.floating.validate+0xc4>
    6154:      	uxtb	w16, w6
    6158:      	cmp	w16, wzr
    615c:      	b.ne	0x6108 <_stogir.floating.validate+0x204>
    6160:      	uxtb	w16, w7
    6164:      	cmp	w16, wzr
    6168:      	b.ne	0x6108 <_stogir.floating.validate+0x204>
    616c:      	cmp	x1, #0x1a
    6170:      	b.lt	0x617c <_stogir.floating.validate+0x278>
    6174:      	cmp	x1, #0x1d
    6178:      	b.le	0x6108 <_stogir.floating.validate+0x204>
    617c:      	cmp	x1, #0x3a
    6180:      	b.eq	0x6108 <_stogir.floating.validate+0x204>
    6184:      	cmp	x1, #0x3b
    6188:      	b.eq	0x6108 <_stogir.floating.validate+0x204>
    618c:      	mov	x19, x8
    6190:      	b	0x60a8 <_stogir.floating.validate+0x1a4>
    6194:      	mov	x6, #0x1                ; =1
    6198:      	sxtw	x2, w2
    619c:      	sxtw	x6, w6
    61a0:      	cmp	x2, x6
    61a4:      	b.ne	0x63dc <_stogir.floating.validate+0x4d8>
    61a8:      	add	x16, sp, #0x10
    61ac:      	ldr	w2, [x16, #0x4]
    61b0:      	sxtw	x2, w2
    61b4:      	cmp	x2, #0x0
    61b8:      	cset	w6, gt
    61bc:      	movz	x16, #0x0, lsl #48
    61c0:      	sub	x7, x16, x2
    61c4:      	sub	x9, x7, #0x1
    61c8:      	uxtb	w16, w6
    61cc:      	cmp	w16, wzr
    61d0:      	b.eq	0x6228 <_stogir.floating.validate+0x324>
    61d4:      	ldr	x7, [x0, #0x8]
    61d8:      	cmp	x2, x7
    61dc:      	b.ge	0x6270 <_stogir.floating.validate+0x36c>
    61e0:      	add	x7, x0, #0x78
    61e4:      	ldr	x7, [x7, #0x8]
    61e8:      	cmp	x2, x7
    61ec:      	b.ge	0x6340 <_stogir.floating.validate+0x43c>
    61f0:      	ldr	x7, [x0, #0x78]
    61f4:      	add	x7, x7, x2, lsl #2
    61f8:      	ldr	w7, [x7]
    61fc:      	sxtw	x7, w7
    6200:      	cmp	x7, #0x0
    6204:      	cset	w7, ge
    6208:      	ubfx	x7, x7, #0, #8
    620c:      	b	0x6344 <_stogir.floating.validate+0x440>
    6210:      	adrp	x16, 0x6000 <_stogir.floating.validate+0xfc>
		0000000000006210:  ARM64_RELOC_PAGE21	l_stogir.413
    6214:      	ldr	x16, [x16]
		0000000000006214:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    6218:      	orr	x0, x16, xzr
    621c:      	mov	x1, #0x1                ; =1
    6220:      	mov	x2, #0x1d               ; =29
    6224:      	b	0x60bc <_stogir.floating.validate+0x1b8>
    6228:      	cmp	x2, #0x0
    622c:      	b.ge	0x6278 <_stogir.floating.validate+0x374>
    6230:      	add	x10, x0, #0x28
    6234:      	add	x11, x0, #0x50
    6238:      	ldr	x10, [x10, #0x8]
    623c:      	ldr	x11, [x11, #0x8]
    6240:      	cmp	x10, x11
    6244:      	b.ne	0x6338 <_stogir.floating.validate+0x434>
    6248:      	cmp	x7, x10
    624c:      	b.gt	0x63c4 <_stogir.floating.validate+0x4c0>
    6250:      	ldr	x7, [x0, #0x50]
    6254:      	add	x7, x7, x9, lsl #2
    6258:      	ldr	w7, [x7]
    625c:      	sxtw	x7, w7
    6260:      	cmp	x7, #0x0
    6264:      	cset	w7, gt
    6268:      	ubfx	x7, x7, #0, #8
    626c:      	b	0x63c8 <_stogir.floating.validate+0x4c4>
    6270:      	movz	x7, #0x0, lsl #48
    6274:      	b	0x627c <_stogir.floating.validate+0x378>
    6278:      	movz	x7, #0x0, lsl #48
    627c:      	cmp	x7, #0x0
    6280:      	b.eq	0x62b4 <_stogir.floating.validate+0x3b0>
    6284:      	uxtb	w16, w6
    6288:      	cmp	w16, wzr
    628c:      	b.eq	0x62a0 <_stogir.floating.validate+0x39c>
    6290:      	ldr	x6, [x0]
    6294:      	add	x2, x6, x2, lsl #4
    6298:      	ldr	x2, [x2]
    629c:      	b	0x62ac <_stogir.floating.validate+0x3a8>
    62a0:      	ldr	x2, [x0, #0x28]
    62a4:      	add	x2, x2, x9, lsl #4
    62a8:      	ldr	x2, [x2]
    62ac:      	mov	x6, #0x1                ; =1
    62b0:      	b	0x62bc <_stogir.floating.validate+0x3b8>
    62b4:      	movz	x6, #0x0, lsl #48
    62b8:      	movz	x2, #0x0, lsl #48
    62bc:      	ubfx	x6, x6, #0, #32
    62c0:      	lsr	x16, x6, #0
    62c4:      	cmp	x16, #0x1
    62c8:      	b.eq	0x62e4 <_stogir.floating.validate+0x3e0>
    62cc:      	b.lo	0x62d4 <_stogir.floating.validate+0x3d0>
    62d0:      	b	0x62e8 <_stogir.floating.validate+0x3e4>
    62d4:      	cmp	x16, #0x0
    62d8:      	b.eq	0x62e0 <_stogir.floating.validate+0x3dc>
    62dc:      	b	0x62e8 <_stogir.floating.validate+0x3e4>
    62e0:      	b	0x62ec <_stogir.floating.validate+0x3e8>
    62e4:      	b	0x6308 <_stogir.floating.validate+0x404>
    62e8:      	b	0x63d4 <_stogir.floating.validate+0x4d0>
    62ec:      	adrp	x16, 0x6000 <_stogir.floating.validate+0xfc>
		00000000000062ec:  ARM64_RELOC_PAGE21	l_stogir.414
    62f0:      	ldr	x16, [x16]
		00000000000062f0:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    62f4:      	orr	x0, x16, xzr
    62f8:      	mov	x19, x8
    62fc:      	mov	x1, #0x1                ; =1
    6300:      	mov	x2, #0x18               ; =24
    6304:      	b	0x6224 <_stogir.floating.validate+0x320>
    6308:      	add	x16, sp, #0x10
    630c:      	ldr	w6, [x16]
    6310:      	ubfx	x2, x2, #0, #32
    6314:      	ubfx	x2, x2, #8, #8
    6318:      	uxtb	w16, w3
    631c:      	cmp	w16, wzr
    6320:      	b.eq	0x6384 <_stogir.floating.validate+0x480>
    6324:      	uxtb	w16, w5
    6328:      	cmp	w16, wzr
    632c:      	b.eq	0x6384 <_stogir.floating.validate+0x480>
    6330:      	mov	x3, #0x1                ; =1
    6334:      	b	0x6388 <_stogir.floating.validate+0x484>
    6338:      	movz	x7, #0x0, lsl #48
    633c:      	b	0x627c <_stogir.floating.validate+0x378>
    6340:      	movz	x7, #0x0, lsl #48
    6344:      	b	0x6274 <_stogir.floating.validate+0x370>
    6348:      	movz	x1, #0x0, lsl #48
    634c:      	mov	x19, x8
    6350:      	add	x8, sp, #0x20
    6354:      	fmov	s31, w1
    6358:      	mov	w1, w4
    635c:      	mov	w4, w5
    6360:      	fmov	w5, s31
    6364:      	bl	0x6364 <_stogir.floating.validate+0x460>
		0000000000006364:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    6368:      	add	x16, sp, #0x20
    636c:      	ldr	x1, [x16]
    6370:      	add	x16, sp, #0x20
    6374:      	ldr	x0, [x16, #0x8]
    6378:      	add	x16, sp, #0x20
    637c:      	ldr	x2, [x16, #0x10]
    6380:      	b	0x6224 <_stogir.floating.validate+0x320>
    6384:      	orr	x3, x2, xzr
    6388:      	ubfx	x5, x6, #8, #8
    638c:      	sxtw	x3, w3
    6390:      	cmp	x5, x3
    6394:      	b.ne	0x63e4 <_stogir.floating.validate+0x4e0>
    6398:      	add	x16, sp, #0x10
    639c:      	ldr	w3, [x16, #0x4]
    63a0:      	add	x16, sp, #0x10
    63a4:      	ldr	w5, [x16, #0x8]
    63a8:      	uxtb	w16, w1
    63ac:      	cmp	w16, wzr
    63b0:      	b.eq	0x6348 <_stogir.floating.validate+0x444>
    63b4:      	add	x16, sp, #0x10
    63b8:      	ldr	w1, [x16, #0xc]
    63bc:      	sxtw	x1, w1
    63c0:      	b	0x634c <_stogir.floating.validate+0x448>
    63c4:      	movz	x7, #0x0, lsl #48
    63c8:      	b	0x633c <_stogir.floating.validate+0x438>
    63cc:      	brk	#0
    63d0:      	b	0x63cc <_stogir.floating.validate+0x4c8>
    63d4:      	brk	#0
    63d8:      	b	0x63d4 <_stogir.floating.validate+0x4d0>
    63dc:      	mov	x19, x8
    63e0:      	b	0x60a8 <_stogir.floating.validate+0x1a4>
    63e4:      	mov	x19, x8
    63e8:      	b	0x6210 <_stogir.floating.validate+0x30c>

00000000000063ec <_stogir.integer-unary.valid-type?>:
    63ec:      	sxtw	x0, w0
    63f0:      	cmp	x0, #0x2d
    63f4:      	cset	w2, eq
    63f8:      	cmp	x0, #0x1f
    63fc:      	cset	w3, eq
    6400:      	cmp	x0, #0x20
    6404:      	cset	w4, eq
    6408:      	cmp	x0, #0x36
    640c:      	cset	w5, eq
    6410:      	uxtb	w16, w3
    6414:      	cmp	w16, wzr
    6418:      	b.ne	0x6460 <_stogir.integer-unary.valid-type?+0x74>
    641c:      	uxtb	w16, w4
    6420:      	cmp	w16, wzr
    6424:      	b.ne	0x6460 <_stogir.integer-unary.valid-type?+0x74>
    6428:      	uxtb	w16, w2
    642c:      	cmp	w16, wzr
    6430:      	b.ne	0x6460 <_stogir.integer-unary.valid-type?+0x74>
    6434:      	uxtb	w16, w5
    6438:      	cmp	w16, wzr
    643c:      	b.ne	0x6460 <_stogir.integer-unary.valid-type?+0x74>
    6440:      	cmp	x0, #0x37
    6444:      	b.eq	0x6460 <_stogir.integer-unary.valid-type?+0x74>
    6448:      	cmp	x0, #0x38
    644c:      	b.eq	0x6460 <_stogir.integer-unary.valid-type?+0x74>
    6450:      	cmp	x0, #0x39
    6454:      	b.eq	0x6460 <_stogir.integer-unary.valid-type?+0x74>
    6458:      	movz	x0, #0x0, lsl #48
    645c:      	b	0x6498 <_stogir.integer-unary.valid-type?+0xac>
    6460:      	sxtw	x1, w1
    6464:      	cmp	x1, #0x1
    6468:      	b.lt	0x6494 <_stogir.integer-unary.valid-type?+0xa8>
    646c:      	cmp	x1, #0xb
    6470:      	cset	w0, le
    6474:      	uxtb	w16, w0
    6478:      	cmp	w16, wzr
    647c:      	b.eq	0x6494 <_stogir.integer-unary.valid-type?+0xa8>
    6480:      	uxtb	w16, w2
    6484:      	cmp	w16, wzr
    6488:      	b.eq	0x64a4 <_stogir.integer-unary.valid-type?+0xb8>
    648c:      	mov	x0, #0x1                ; =1
    6490:      	b	0x64a0 <_stogir.integer-unary.valid-type?+0xb4>
    6494:      	movz	x0, #0x0, lsl #48
    6498:      	ret
    649c:      	mov	x0, #0x1                ; =1
    64a0:      	b	0x6498 <_stogir.integer-unary.valid-type?+0xac>
    64a4:      	cmp	x1, #0x1
    64a8:      	b.ne	0x64b4 <_stogir.integer-unary.valid-type?+0xc8>
    64ac:      	movz	x0, #0x0, lsl #48
    64b0:      	b	0x64a0 <_stogir.integer-unary.valid-type?+0xb4>
    64b4:      	cmp	x1, #0x6
    64b8:      	cset	w2, eq
    64bc:      	uxtb	w16, w3
    64c0:      	cmp	w16, wzr
    64c4:      	b.eq	0x64d8 <_stogir.integer-unary.valid-type?+0xec>
    64c8:      	uxtb	w16, w2
    64cc:      	cmp	w16, wzr
    64d0:      	cset	x0, eq
    64d4:      	b	0x64a0 <_stogir.integer-unary.valid-type?+0xb4>
    64d8:      	uxtb	w16, w4
    64dc:      	cmp	w16, wzr
    64e0:      	b.eq	0x64fc <_stogir.integer-unary.valid-type?+0x110>
    64e4:      	cmp	x1, #0x7
    64e8:      	b.lt	0x64f4 <_stogir.integer-unary.valid-type?+0x108>
    64ec:      	ubfx	x0, x0, #0, #8
    64f0:      	b	0x64f8 <_stogir.integer-unary.valid-type?+0x10c>
    64f4:      	movz	x0, #0x0, lsl #48
    64f8:      	b	0x64a0 <_stogir.integer-unary.valid-type?+0xb4>
    64fc:      	uxtb	w16, w5
    6500:      	cmp	w16, wzr
    6504:      	b.eq	0x649c <_stogir.integer-unary.valid-type?+0xb0>
    6508:      	cmp	x1, #0x3
    650c:      	b.ne	0x6528 <_stogir.integer-unary.valid-type?+0x13c>
    6510:      	mov	x0, #0x1                ; =1
    6514:      	b	0x6524 <_stogir.integer-unary.valid-type?+0x138>
    6518:      	cmp	x1, #0xb
    651c:      	cset	w0, eq
    6520:      	ubfx	x0, x0, #0, #8
    6524:      	b	0x64a0 <_stogir.integer-unary.valid-type?+0xb4>
    6528:      	cmp	x1, #0x4
    652c:      	b.ne	0x6538 <_stogir.integer-unary.valid-type?+0x14c>
    6530:      	mov	x0, #0x1                ; =1
    6534:      	b	0x6524 <_stogir.integer-unary.valid-type?+0x138>
    6538:      	cmp	x1, #0x5
    653c:      	b.ne	0x6548 <_stogir.integer-unary.valid-type?+0x15c>
    6540:      	mov	x0, #0x1                ; =1
    6544:      	b	0x6524 <_stogir.integer-unary.valid-type?+0x138>
    6548:      	uxtb	w16, w2
    654c:      	cmp	w16, wzr
    6550:      	b.eq	0x655c <_stogir.integer-unary.valid-type?+0x170>
    6554:      	mov	x0, #0x1                ; =1
    6558:      	b	0x6524 <_stogir.integer-unary.valid-type?+0x138>
    655c:      	cmp	x1, #0x9
    6560:      	b.ne	0x656c <_stogir.integer-unary.valid-type?+0x180>
    6564:      	mov	x0, #0x1                ; =1
    6568:      	b	0x6524 <_stogir.integer-unary.valid-type?+0x138>
    656c:      	cmp	x1, #0xa
    6570:      	b.ne	0x6518 <_stogir.integer-unary.valid-type?+0x12c>
    6574:      	mov	x0, #0x1                ; =1
    6578:      	b	0x6524 <_stogir.integer-unary.valid-type?+0x138>

000000000000657c <_stogir.types.vector?>:
    657c:      	sxtw	x0, w0
    6580:      	cmp	x0, #0xf
    6584:      	b.le	0x65b8 <_stogir.types.vector?+0x3c>
    6588:      	cmp	x0, #0x80
    658c:      	b.ge	0x65c8 <_stogir.types.vector?+0x4c>
    6590:      	and	x1, x0, #0xf
    6594:      	sxtw	x1, w1
    6598:      	cmp	x1, #0x1
    659c:      	b.lt	0x65c0 <_stogir.types.vector?+0x44>
    65a0:      	and	x0, x0, #0xf
    65a4:      	sxtw	x0, w0
    65a8:      	cmp	x0, #0xd
    65ac:      	cset	w0, le
    65b0:      	ubfx	x0, x0, #0, #8
    65b4:      	b	0x65c4 <_stogir.types.vector?+0x48>
    65b8:      	movz	x0, #0x0, lsl #48
    65bc:      	b	0x65c4 <_stogir.types.vector?+0x48>
    65c0:      	movz	x0, #0x0, lsl #48
    65c4:      	ret
    65c8:      	movz	x0, #0x0, lsl #48
    65cc:      	b	0x65c4 <_stogir.types.vector?+0x48>

00000000000065d0 <_stogir.floating.operation?>:
    65d0:      	sxtw	x0, w0
    65d4:      	cmp	x0, #0xe
    65d8:      	b.lt	0x65ec <_stogir.floating.operation?+0x1c>
    65dc:      	cmp	x0, #0x19
    65e0:      	b.gt	0x65ec <_stogir.floating.operation?+0x1c>
    65e4:      	mov	x0, #0x1                ; =1
    65e8:      	b	0x6618 <_stogir.floating.operation?+0x48>
    65ec:      	cmp	x0, #0x1f
    65f0:      	b.eq	0x6614 <_stogir.floating.operation?+0x44>
    65f4:      	cmp	x0, #0x20
    65f8:      	b.eq	0x6614 <_stogir.floating.operation?+0x44>
    65fc:      	cmp	x0, #0x1a
    6600:      	b.lt	0x662c <_stogir.floating.operation?+0x5c>
    6604:      	cmp	x0, #0x1d
    6608:      	b.gt	0x662c <_stogir.floating.operation?+0x5c>
    660c:      	mov	x0, #0x1                ; =1
    6610:      	b	0x6628 <_stogir.floating.operation?+0x58>
    6614:      	mov	x0, #0x1                ; =1
    6618:      	ret
    661c:      	cmp	x0, #0x3b
    6620:      	cset	w0, eq
    6624:      	ubfx	x0, x0, #0, #8
    6628:      	b	0x6618 <_stogir.floating.operation?+0x48>
    662c:      	cmp	x0, #0x3a
    6630:      	b.ne	0x661c <_stogir.floating.operation?+0x4c>
    6634:      	mov	x0, #0x1                ; =1
    6638:      	b	0x6628 <_stogir.floating.operation?+0x58>

000000000000663c <_stogir.vector-lanes.validate>:
    663c:      	sub	sp, sp, #0x50
    6640:      	str	x29, [sp]
    6644:      	str	x30, [sp, #0x8]
    6648:      	mov	x29, sp
    664c:      	str	x19, [sp, #0x40]
    6650:      	sxtw	x1, w1
    6654:      	lsl	x3, x1, #2
    6658:      	cmp	x1, #0x0
    665c:      	cset	w4, gt
    6660:      	movz	x16, #0x0, lsl #48
    6664:      	sub	x5, x16, x1
    6668:      	sub	x6, x5, #0x1
    666c:      	uxtb	w16, w4
    6670:      	cmp	w16, wzr
    6674:      	b.eq	0x66b4 <_stogir.vector-lanes.validate+0x78>
    6678:      	ldr	x5, [x0, #0x8]
    667c:      	cmp	x1, x5
    6680:      	b.ge	0x6704 <_stogir.vector-lanes.validate+0xc8>
    6684:      	add	x5, x0, #0x78
    6688:      	ldr	x5, [x5, #0x8]
    668c:      	cmp	x1, x5
    6690:      	b.ge	0x67f8 <_stogir.vector-lanes.validate+0x1bc>
    6694:      	ldr	x5, [x0, #0x78]
    6698:      	add	x5, x3, x5
    669c:      	ldr	w5, [x5]
    66a0:      	sxtw	x5, w5
    66a4:      	cmp	x5, #0x0
    66a8:      	cset	w5, ge
    66ac:      	ubfx	x5, x5, #0, #8
    66b0:      	b	0x67fc <_stogir.vector-lanes.validate+0x1c0>
    66b4:      	cmp	x1, #0x0
    66b8:      	b.ge	0x670c <_stogir.vector-lanes.validate+0xd0>
    66bc:      	add	x7, x0, #0x28
    66c0:      	add	x9, x0, #0x50
    66c4:      	ldr	x7, [x7, #0x8]
    66c8:      	ldr	x9, [x9, #0x8]
    66cc:      	cmp	x7, x9
    66d0:      	b.ne	0x66fc <_stogir.vector-lanes.validate+0xc0>
    66d4:      	cmp	x5, x7
    66d8:      	b.gt	0x683c <_stogir.vector-lanes.validate+0x200>
    66dc:      	ldr	x5, [x0, #0x50]
    66e0:      	add	x5, x5, x6, lsl #2
    66e4:      	ldr	w5, [x5]
    66e8:      	sxtw	x5, w5
    66ec:      	cmp	x5, #0x0
    66f0:      	cset	w5, gt
    66f4:      	ubfx	x5, x5, #0, #8
    66f8:      	b	0x6840 <_stogir.vector-lanes.validate+0x204>
    66fc:      	movz	x5, #0x0, lsl #48
    6700:      	b	0x6710 <_stogir.vector-lanes.validate+0xd4>
    6704:      	movz	x5, #0x0, lsl #48
    6708:      	b	0x6710 <_stogir.vector-lanes.validate+0xd4>
    670c:      	movz	x5, #0x0, lsl #48
    6710:      	cmp	x5, #0x0
    6714:      	b.eq	0x6750 <_stogir.vector-lanes.validate+0x114>
    6718:      	uxtb	w16, w4
    671c:      	cmp	w16, wzr
    6720:      	b.eq	0x6738 <_stogir.vector-lanes.validate+0xfc>
    6724:      	ldr	x4, [x0]
    6728:      	add	x4, x4, x1, lsl #4
    672c:      	ldr	x5, [x4]
    6730:      	ldr	x4, [x4, #0x8]
    6734:      	b	0x6748 <_stogir.vector-lanes.validate+0x10c>
    6738:      	ldr	x4, [x0, #0x28]
    673c:      	add	x4, x4, x6, lsl #4
    6740:      	ldr	x5, [x4]
    6744:      	ldr	x4, [x4, #0x8]
    6748:      	mov	x6, #0x1                ; =1
    674c:      	b	0x675c <_stogir.vector-lanes.validate+0x120>
    6750:      	movz	x6, #0x0, lsl #48
    6754:      	movz	x5, #0x0, lsl #48
    6758:      	movz	x4, #0x0, lsl #48
    675c:      	ubfx	x6, x6, #0, #32
    6760:      	lsr	x16, x6, #0
    6764:      	cmp	x16, #0x1
    6768:      	b.eq	0x6784 <_stogir.vector-lanes.validate+0x148>
    676c:      	b.lo	0x6774 <_stogir.vector-lanes.validate+0x138>
    6770:      	b	0x6788 <_stogir.vector-lanes.validate+0x14c>
    6774:      	cmp	x16, #0x0
    6778:      	b.eq	0x6780 <_stogir.vector-lanes.validate+0x144>
    677c:      	b	0x6788 <_stogir.vector-lanes.validate+0x14c>
    6780:      	b	0x678c <_stogir.vector-lanes.validate+0x150>
    6784:      	b	0x67a8 <_stogir.vector-lanes.validate+0x16c>
    6788:      	b	0x6904 <_stogir.vector-lanes.validate+0x2c8>
    678c:      	adrp	x16, 0x6000 <_stogir.floating.validate+0xfc>
		000000000000678c:  ARM64_RELOC_PAGE21	l_stogir.415
    6790:      	ldr	x16, [x16]
		0000000000006790:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    6794:      	orr	x0, x16, xzr
    6798:      	mov	x19, x8
    679c:      	mov	x1, #0x1                ; =1
    67a0:      	mov	x2, #0x1f               ; =31
    67a4:      	b	0x67d8 <_stogir.vector-lanes.validate+0x19c>
    67a8:      	add	x16, sp, #0x10
    67ac:      	str	x5, [x16]
    67b0:      	add	x16, sp, #0x10
    67b4:      	str	x4, [x16, #0x8]
    67b8:      	cmp	x1, #0x0
    67bc:      	b.gt	0x6800 <_stogir.vector-lanes.validate+0x1c4>
    67c0:      	mov	x19, x8
    67c4:      	adrp	x16, 0x6000 <_stogir.floating.validate+0xfc>
		00000000000067c4:  ARM64_RELOC_PAGE21	l_stogir.416
    67c8:      	ldr	x16, [x16]
		00000000000067c8:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    67cc:      	orr	x0, x16, xzr
    67d0:      	mov	x1, #0x1                ; =1
    67d4:      	mov	x2, #0x25               ; =37
    67d8:      	str	x1, [x19]
    67dc:      	str	x0, [x19, #0x8]
    67e0:      	str	x2, [x19, #0x10]
    67e4:      	ldr	x19, [sp, #0x40]
    67e8:      	ldr	x29, [sp]
    67ec:      	ldr	x30, [sp, #0x8]
    67f0:      	add	sp, sp, #0x50
    67f4:      	ret
    67f8:      	movz	x5, #0x0, lsl #48
    67fc:      	b	0x6708 <_stogir.vector-lanes.validate+0xcc>
    6800:      	uxtb	w5, w5
    6804:      	orr	x1, x5, xzr
    6808:      	cmp	x1, #0x3d
    680c:      	b.lt	0x690c <_stogir.vector-lanes.validate+0x2d0>
    6810:      	cmp	x1, #0x3f
    6814:      	b.gt	0x6914 <_stogir.vector-lanes.validate+0x2d8>
    6818:      	cmp	x1, #0x3e
    681c:      	cset	w4, eq
    6820:      	ldr	x6, [x0, #0x78]
    6824:      	add	x3, x3, x6
    6828:      	ldr	w3, [x3]
    682c:      	cmp	x1, #0x3d
    6830:      	b.ne	0x6898 <_stogir.vector-lanes.validate+0x25c>
    6834:      	mov	x6, #0x2                ; =2
    6838:      	b	0x68ac <_stogir.vector-lanes.validate+0x270>
    683c:      	movz	x5, #0x0, lsl #48
    6840:      	b	0x6700 <_stogir.vector-lanes.validate+0xc4>
    6844:      	movz	x4, #0x0, lsl #48
    6848:      	ubfx	x3, x3, #8, #8
    684c:      	mov	x19, x8
    6850:      	add	x8, sp, #0x20
    6854:      	fmov	s31, w1
    6858:      	mov	w1, w5
    685c:      	fmov	w5, s31
    6860:      	fmov	s31, w2
    6864:      	mov	w2, w3
    6868:      	fmov	w3, s31
    686c:      	fmov	s31, w4
    6870:      	mov	w4, w6
    6874:      	fmov	w6, s31
    6878:      	bl	0x6878 <_stogir.vector-lanes.validate+0x23c>
		0000000000006878:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    687c:      	add	x16, sp, #0x20
    6880:      	ldr	x1, [x16]
    6884:      	add	x16, sp, #0x20
    6888:      	ldr	x0, [x16, #0x8]
    688c:      	add	x16, sp, #0x20
    6890:      	ldr	x2, [x16, #0x10]
    6894:      	b	0x67d8 <_stogir.vector-lanes.validate+0x19c>
    6898:      	uxtb	w16, w4
    689c:      	cmp	w16, wzr
    68a0:      	mov	x16, #0x3               ; =3
    68a4:      	mov	x17, #0x1               ; =1
    68a8:      	csel	x6, x16, x17, ne
    68ac:      	sxtw	x3, w3
    68b0:      	sxtw	x6, w6
    68b4:      	cmp	x3, x6
    68b8:      	b.ne	0x691c <_stogir.vector-lanes.validate+0x2e0>
    68bc:      	add	x16, sp, #0x10
    68c0:      	ldr	w3, [x16]
    68c4:      	add	x16, sp, #0x10
    68c8:      	ldr	w6, [x16, #0x4]
    68cc:      	cmp	x1, #0x3f
    68d0:      	b.ne	0x68dc <_stogir.vector-lanes.validate+0x2a0>
    68d4:      	movz	x1, #0x0, lsl #48
    68d8:      	b	0x68e8 <_stogir.vector-lanes.validate+0x2ac>
    68dc:      	add	x16, sp, #0x10
    68e0:      	ldr	w1, [x16, #0x8]
    68e4:      	sxtw	x1, w1
    68e8:      	uxtb	w16, w4
    68ec:      	cmp	w16, wzr
    68f0:      	b.eq	0x6844 <_stogir.vector-lanes.validate+0x208>
    68f4:      	add	x16, sp, #0x10
    68f8:      	ldr	w4, [x16, #0xc]
    68fc:      	sxtw	x4, w4
    6900:      	b	0x6848 <_stogir.vector-lanes.validate+0x20c>
    6904:      	brk	#0
    6908:      	b	0x6904 <_stogir.vector-lanes.validate+0x2c8>
    690c:      	mov	x19, x8
    6910:      	b	0x67c4 <_stogir.vector-lanes.validate+0x188>
    6914:      	mov	x19, x8
    6918:      	b	0x67c4 <_stogir.vector-lanes.validate+0x188>
    691c:      	mov	x19, x8
    6920:      	b	0x67c4 <_stogir.vector-lanes.validate+0x188>

0000000000006924 <_stogir.vector-comparison.node?>:
    6924:      	sxtw	x1, w1
    6928:      	cmp	x1, #0x0
    692c:      	cset	w2, gt
    6930:      	movz	x16, #0x0, lsl #48
    6934:      	sub	x3, x16, x1
    6938:      	sub	x4, x3, #0x1
    693c:      	uxtb	w16, w2
    6940:      	cmp	w16, wzr
    6944:      	b.eq	0x6984 <_stogir.vector-comparison.node?+0x60>
    6948:      	ldr	x3, [x0, #0x8]
    694c:      	cmp	x1, x3
    6950:      	b.ge	0x69d4 <_stogir.vector-comparison.node?+0xb0>
    6954:      	add	x3, x0, #0x78
    6958:      	ldr	x3, [x3, #0x8]
    695c:      	cmp	x1, x3
    6960:      	b.ge	0x6aac <_stogir.vector-comparison.node?+0x188>
    6964:      	ldr	x3, [x0, #0x78]
    6968:      	add	x3, x3, x1, lsl #2
    696c:      	ldr	w3, [x3]
    6970:      	sxtw	x3, w3
    6974:      	cmp	x3, #0x0
    6978:      	cset	w3, ge
    697c:      	ubfx	x3, x3, #0, #8
    6980:      	b	0x6ab0 <_stogir.vector-comparison.node?+0x18c>
    6984:      	cmp	x1, #0x0
    6988:      	b.ge	0x69dc <_stogir.vector-comparison.node?+0xb8>
    698c:      	add	x5, x0, #0x28
    6990:      	add	x6, x0, #0x50
    6994:      	ldr	x5, [x5, #0x8]
    6998:      	ldr	x6, [x6, #0x8]
    699c:      	cmp	x5, x6
    69a0:      	b.ne	0x69cc <_stogir.vector-comparison.node?+0xa8>
    69a4:      	cmp	x3, x5
    69a8:      	b.gt	0x6ab4 <_stogir.vector-comparison.node?+0x190>
    69ac:      	ldr	x3, [x0, #0x50]
    69b0:      	add	x3, x3, x4, lsl #2
    69b4:      	ldr	w3, [x3]
    69b8:      	sxtw	x3, w3
    69bc:      	cmp	x3, #0x0
    69c0:      	cset	w3, gt
    69c4:      	ubfx	x3, x3, #0, #8
    69c8:      	b	0x6ab8 <_stogir.vector-comparison.node?+0x194>
    69cc:      	movz	x3, #0x0, lsl #48
    69d0:      	b	0x69e0 <_stogir.vector-comparison.node?+0xbc>
    69d4:      	movz	x3, #0x0, lsl #48
    69d8:      	b	0x69e0 <_stogir.vector-comparison.node?+0xbc>
    69dc:      	movz	x3, #0x0, lsl #48
    69e0:      	cmp	x3, #0x0
    69e4:      	b.eq	0x6a18 <_stogir.vector-comparison.node?+0xf4>
    69e8:      	uxtb	w16, w2
    69ec:      	cmp	w16, wzr
    69f0:      	b.eq	0x6a04 <_stogir.vector-comparison.node?+0xe0>
    69f4:      	ldr	x0, [x0]
    69f8:      	add	x0, x0, x1, lsl #4
    69fc:      	ldr	x0, [x0]
    6a00:      	b	0x6a10 <_stogir.vector-comparison.node?+0xec>
    6a04:      	ldr	x0, [x0, #0x28]
    6a08:      	add	x0, x0, x4, lsl #4
    6a0c:      	ldr	x0, [x0]
    6a10:      	mov	x1, #0x1                ; =1
    6a14:      	b	0x6a20 <_stogir.vector-comparison.node?+0xfc>
    6a18:      	movz	x1, #0x0, lsl #48
    6a1c:      	movz	x0, #0x0, lsl #48
    6a20:      	ubfx	x1, x1, #0, #32
    6a24:      	lsr	x16, x1, #0
    6a28:      	cmp	x16, #0x1
    6a2c:      	b.eq	0x6a48 <_stogir.vector-comparison.node?+0x124>
    6a30:      	b.lo	0x6a38 <_stogir.vector-comparison.node?+0x114>
    6a34:      	b	0x6a4c <_stogir.vector-comparison.node?+0x128>
    6a38:      	cmp	x16, #0x0
    6a3c:      	b.eq	0x6a44 <_stogir.vector-comparison.node?+0x120>
    6a40:      	b	0x6a4c <_stogir.vector-comparison.node?+0x128>
    6a44:      	b	0x6a50 <_stogir.vector-comparison.node?+0x12c>
    6a48:      	b	0x6a60 <_stogir.vector-comparison.node?+0x13c>
    6a4c:      	b	0x6ad4 <_stogir.vector-comparison.node?+0x1b0>
    6a50:      	movz	x0, #0x0, lsl #48
    6a54:      	b	0x6a5c <_stogir.vector-comparison.node?+0x138>
    6a58:      	movz	x0, #0x0, lsl #48
    6a5c:      	ret
    6a60:      	uxtb	w1, w0
    6a64:      	cmp	x1, #0xe
    6a68:      	b.lt	0x6a58 <_stogir.vector-comparison.node?+0x134>
    6a6c:      	cmp	x1, #0x19
    6a70:      	b.gt	0x6a58 <_stogir.vector-comparison.node?+0x134>
    6a74:      	ubfx	x0, x0, #0, #32
    6a78:      	ubfx	x0, x0, #8, #8
    6a7c:      	cmp	x0, #0xf
    6a80:      	b.le	0x6abc <_stogir.vector-comparison.node?+0x198>
    6a84:      	cmp	x0, #0x80
    6a88:      	b.ge	0x6ac4 <_stogir.vector-comparison.node?+0x1a0>
    6a8c:      	and	x0, x0, #0xf
    6a90:      	sxtw	x0, w0
    6a94:      	cmp	x0, #0x1
    6a98:      	b.lt	0x6acc <_stogir.vector-comparison.node?+0x1a8>
    6a9c:      	cmp	x0, #0xd
    6aa0:      	cset	w0, le
    6aa4:      	ubfx	x0, x0, #0, #8
    6aa8:      	b	0x6ad0 <_stogir.vector-comparison.node?+0x1ac>
    6aac:      	movz	x3, #0x0, lsl #48
    6ab0:      	b	0x69d8 <_stogir.vector-comparison.node?+0xb4>
    6ab4:      	movz	x3, #0x0, lsl #48
    6ab8:      	b	0x69d0 <_stogir.vector-comparison.node?+0xac>
    6abc:      	movz	x0, #0x0, lsl #48
    6ac0:      	b	0x6a5c <_stogir.vector-comparison.node?+0x138>
    6ac4:      	movz	x0, #0x0, lsl #48
    6ac8:      	b	0x6ac0 <_stogir.vector-comparison.node?+0x19c>
    6acc:      	movz	x0, #0x0, lsl #48
    6ad0:      	b	0x6ac8 <_stogir.vector-comparison.node?+0x1a4>
    6ad4:      	brk	#0
    6ad8:      	b	0x6ad4 <_stogir.vector-comparison.node?+0x1b0>

0000000000006adc <_stogir.vector-comparison.validate>:
    6adc:      	sub	sp, sp, #0x50
    6ae0:      	str	x29, [sp]
    6ae4:      	str	x30, [sp, #0x8]
    6ae8:      	mov	x29, sp
    6aec:      	str	x19, [sp, #0x40]
    6af0:      	sxtw	x1, w1
    6af4:      	lsl	x3, x1, #2
    6af8:      	cmp	x1, #0x0
    6afc:      	cset	w4, gt
    6b00:      	movz	x16, #0x0, lsl #48
    6b04:      	sub	x5, x16, x1
    6b08:      	sub	x6, x5, #0x1
    6b0c:      	uxtb	w16, w4
    6b10:      	cmp	w16, wzr
    6b14:      	b.eq	0x6b54 <_stogir.vector-comparison.validate+0x78>
    6b18:      	ldr	x5, [x0, #0x8]
    6b1c:      	cmp	x1, x5
    6b20:      	b.ge	0x6ba4 <_stogir.vector-comparison.validate+0xc8>
    6b24:      	add	x5, x0, #0x78
    6b28:      	ldr	x5, [x5, #0x8]
    6b2c:      	cmp	x1, x5
    6b30:      	b.ge	0x6c9c <_stogir.vector-comparison.validate+0x1c0>
    6b34:      	ldr	x5, [x0, #0x78]
    6b38:      	add	x5, x3, x5
    6b3c:      	ldr	w5, [x5]
    6b40:      	sxtw	x5, w5
    6b44:      	cmp	x5, #0x0
    6b48:      	cset	w5, ge
    6b4c:      	ubfx	x5, x5, #0, #8
    6b50:      	b	0x6ca0 <_stogir.vector-comparison.validate+0x1c4>
    6b54:      	cmp	x1, #0x0
    6b58:      	b.ge	0x6bac <_stogir.vector-comparison.validate+0xd0>
    6b5c:      	add	x7, x0, #0x28
    6b60:      	add	x9, x0, #0x50
    6b64:      	ldr	x7, [x7, #0x8]
    6b68:      	ldr	x9, [x9, #0x8]
    6b6c:      	cmp	x7, x9
    6b70:      	b.ne	0x6b9c <_stogir.vector-comparison.validate+0xc0>
    6b74:      	cmp	x5, x7
    6b78:      	b.gt	0x6cec <_stogir.vector-comparison.validate+0x210>
    6b7c:      	ldr	x5, [x0, #0x50]
    6b80:      	add	x5, x5, x6, lsl #2
    6b84:      	ldr	w5, [x5]
    6b88:      	sxtw	x5, w5
    6b8c:      	cmp	x5, #0x0
    6b90:      	cset	w5, gt
    6b94:      	ubfx	x5, x5, #0, #8
    6b98:      	b	0x6cf0 <_stogir.vector-comparison.validate+0x214>
    6b9c:      	movz	x5, #0x0, lsl #48
    6ba0:      	b	0x6bb0 <_stogir.vector-comparison.validate+0xd4>
    6ba4:      	movz	x5, #0x0, lsl #48
    6ba8:      	b	0x6bb0 <_stogir.vector-comparison.validate+0xd4>
    6bac:      	movz	x5, #0x0, lsl #48
    6bb0:      	lsl	x7, x1, #4
    6bb4:      	cmp	x5, #0x0
    6bb8:      	b.eq	0x6bf4 <_stogir.vector-comparison.validate+0x118>
    6bbc:      	uxtb	w16, w4
    6bc0:      	cmp	w16, wzr
    6bc4:      	b.eq	0x6bdc <_stogir.vector-comparison.validate+0x100>
    6bc8:      	ldr	x4, [x0]
    6bcc:      	add	x4, x7, x4
    6bd0:      	ldr	x5, [x4]
    6bd4:      	ldr	x4, [x4, #0x8]
    6bd8:      	b	0x6bec <_stogir.vector-comparison.validate+0x110>
    6bdc:      	ldr	x4, [x0, #0x28]
    6be0:      	add	x4, x4, x6, lsl #4
    6be4:      	ldr	x5, [x4]
    6be8:      	ldr	x4, [x4, #0x8]
    6bec:      	mov	x6, #0x1                ; =1
    6bf0:      	b	0x6c00 <_stogir.vector-comparison.validate+0x124>
    6bf4:      	movz	x6, #0x0, lsl #48
    6bf8:      	movz	x5, #0x0, lsl #48
    6bfc:      	movz	x4, #0x0, lsl #48
    6c00:      	ubfx	x6, x6, #0, #32
    6c04:      	lsr	x16, x6, #0
    6c08:      	cmp	x16, #0x1
    6c0c:      	b.eq	0x6c28 <_stogir.vector-comparison.validate+0x14c>
    6c10:      	b.lo	0x6c18 <_stogir.vector-comparison.validate+0x13c>
    6c14:      	b	0x6c2c <_stogir.vector-comparison.validate+0x150>
    6c18:      	cmp	x16, #0x0
    6c1c:      	b.eq	0x6c24 <_stogir.vector-comparison.validate+0x148>
    6c20:      	b	0x6c2c <_stogir.vector-comparison.validate+0x150>
    6c24:      	b	0x6c30 <_stogir.vector-comparison.validate+0x154>
    6c28:      	b	0x6c68 <_stogir.vector-comparison.validate+0x18c>
    6c2c:      	b	0x6de8 <_stogir.vector-comparison.validate+0x30c>
    6c30:      	adrp	x16, 0x6000 <_stogir.floating.validate+0xfc>
		0000000000006c30:  ARM64_RELOC_PAGE21	l_stogir.417
    6c34:      	ldr	x16, [x16]
		0000000000006c34:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    6c38:      	orr	x0, x16, xzr
    6c3c:      	mov	x19, x8
    6c40:      	mov	x1, #0x1                ; =1
    6c44:      	mov	x2, #0x25               ; =37
    6c48:      	str	x1, [x19]
    6c4c:      	str	x0, [x19, #0x8]
    6c50:      	str	x2, [x19, #0x10]
    6c54:      	ldr	x19, [sp, #0x40]
    6c58:      	ldr	x29, [sp]
    6c5c:      	ldr	x30, [sp, #0x8]
    6c60:      	add	sp, sp, #0x50
    6c64:      	ret
    6c68:      	add	x16, sp, #0x10
    6c6c:      	str	x5, [x16]
    6c70:      	add	x16, sp, #0x10
    6c74:      	str	x4, [x16, #0x8]
    6c78:      	cmp	x1, #0x0
    6c7c:      	b.gt	0x6ca4 <_stogir.vector-comparison.validate+0x1c8>
    6c80:      	mov	x19, x8
    6c84:      	adrp	x16, 0x6000 <_stogir.floating.validate+0xfc>
		0000000000006c84:  ARM64_RELOC_PAGE21	l_stogir.418
    6c88:      	ldr	x16, [x16]
		0000000000006c88:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    6c8c:      	orr	x0, x16, xzr
    6c90:      	mov	x1, #0x1                ; =1
    6c94:      	mov	x2, #0x2b               ; =43
    6c98:      	b	0x6c48 <_stogir.vector-comparison.validate+0x16c>
    6c9c:      	movz	x5, #0x0, lsl #48
    6ca0:      	b	0x6ba8 <_stogir.vector-comparison.validate+0xcc>
    6ca4:      	ldr	x4, [x0, #0x8]
    6ca8:      	cmp	x1, x4
    6cac:      	b.ge	0x6cf4 <_stogir.vector-comparison.validate+0x218>
    6cb0:      	add	x4, x0, #0x78
    6cb4:      	ldr	x4, [x4, #0x8]
    6cb8:      	cmp	x1, x4
    6cbc:      	b.ge	0x6cf4 <_stogir.vector-comparison.validate+0x218>
    6cc0:      	ldr	x1, [x0, #0x78]
    6cc4:      	add	x1, x3, x1
    6cc8:      	ldr	w1, [x1]
    6ccc:      	sxtw	x1, w1
    6cd0:      	cmp	x1, #0x0
    6cd4:      	b.lt	0x6cf4 <_stogir.vector-comparison.validate+0x218>
    6cd8:      	ldr	x1, [x0]
    6cdc:      	add	x1, x7, x1
    6ce0:      	ldr	x1, [x1]
    6ce4:      	mov	x4, #0x1                ; =1
    6ce8:      	b	0x6cfc <_stogir.vector-comparison.validate+0x220>
    6cec:      	movz	x5, #0x0, lsl #48
    6cf0:      	b	0x6ba0 <_stogir.vector-comparison.validate+0xc4>
    6cf4:      	movz	x4, #0x0, lsl #48
    6cf8:      	movz	x1, #0x0, lsl #48
    6cfc:      	ubfx	x4, x4, #0, #32
    6d00:      	lsr	x16, x4, #0
    6d04:      	cmp	x16, #0x1
    6d08:      	b.eq	0x6d24 <_stogir.vector-comparison.validate+0x248>
    6d0c:      	b.lo	0x6d14 <_stogir.vector-comparison.validate+0x238>
    6d10:      	b	0x6d28 <_stogir.vector-comparison.validate+0x24c>
    6d14:      	cmp	x16, #0x0
    6d18:      	b.eq	0x6d20 <_stogir.vector-comparison.validate+0x244>
    6d1c:      	b	0x6d28 <_stogir.vector-comparison.validate+0x24c>
    6d20:      	b	0x6d2c <_stogir.vector-comparison.validate+0x250>
    6d24:      	b	0x6d34 <_stogir.vector-comparison.validate+0x258>
    6d28:      	b	0x6df0 <_stogir.vector-comparison.validate+0x314>
    6d2c:      	mov	x19, x8
    6d30:      	b	0x6c84 <_stogir.vector-comparison.validate+0x1a8>
    6d34:      	uxtb	w4, w1
    6d38:      	cmp	x4, #0xe
    6d3c:      	b.lt	0x6df8 <_stogir.vector-comparison.validate+0x31c>
    6d40:      	cmp	x4, #0x19
    6d44:      	b.gt	0x6e00 <_stogir.vector-comparison.validate+0x324>
    6d48:      	ubfx	x1, x1, #0, #32
    6d4c:      	ubfx	x1, x1, #8, #8
    6d50:      	cmp	x1, #0xf
    6d54:      	b.le	0x6e08 <_stogir.vector-comparison.validate+0x32c>
    6d58:      	cmp	x1, #0x80
    6d5c:      	b.ge	0x6e10 <_stogir.vector-comparison.validate+0x334>
    6d60:      	and	x1, x1, #0xf
    6d64:      	sxtw	x1, w1
    6d68:      	cmp	x1, #0x1
    6d6c:      	b.lt	0x6e18 <_stogir.vector-comparison.validate+0x33c>
    6d70:      	cmp	x1, #0xd
    6d74:      	b.gt	0x6e20 <_stogir.vector-comparison.validate+0x344>
    6d78:      	ldr	x1, [x0, #0x78]
    6d7c:      	add	x1, x3, x1
    6d80:      	ldr	w1, [x1]
    6d84:      	sxtw	x1, w1
    6d88:      	cmp	x1, #0x2
    6d8c:      	b.ne	0x6e28 <_stogir.vector-comparison.validate+0x34c>
    6d90:      	add	x16, sp, #0x10
    6d94:      	ldr	w1, [x16]
    6d98:      	uxtb	w3, w1
    6d9c:      	add	x16, sp, #0x10
    6da0:      	ldr	w4, [x16, #0x4]
    6da4:      	ubfx	x1, x1, #8, #8
    6da8:      	add	x16, sp, #0x10
    6dac:      	ldr	w5, [x16, #0x8]
    6db0:      	mov	x19, x8
    6db4:      	add	x8, sp, #0x20
    6db8:      	fmov	s31, w1
    6dbc:      	mov	w1, w3
    6dc0:      	mov	w3, w2
    6dc4:      	fmov	w2, s31
    6dc8:      	bl	0x6dc8 <_stogir.vector-comparison.validate+0x2ec>
		0000000000006dc8:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    6dcc:      	add	x16, sp, #0x20
    6dd0:      	ldr	x1, [x16]
    6dd4:      	add	x16, sp, #0x20
    6dd8:      	ldr	x0, [x16, #0x8]
    6ddc:      	add	x16, sp, #0x20
    6de0:      	ldr	x2, [x16, #0x10]
    6de4:      	b	0x6c98 <_stogir.vector-comparison.validate+0x1bc>
    6de8:      	brk	#0
    6dec:      	b	0x6de8 <_stogir.vector-comparison.validate+0x30c>
    6df0:      	brk	#0
    6df4:      	b	0x6df0 <_stogir.vector-comparison.validate+0x314>
    6df8:      	mov	x19, x8
    6dfc:      	b	0x6c84 <_stogir.vector-comparison.validate+0x1a8>
    6e00:      	mov	x19, x8
    6e04:      	b	0x6c84 <_stogir.vector-comparison.validate+0x1a8>
    6e08:      	mov	x19, x8
    6e0c:      	b	0x6c84 <_stogir.vector-comparison.validate+0x1a8>
    6e10:      	mov	x19, x8
    6e14:      	b	0x6c84 <_stogir.vector-comparison.validate+0x1a8>
    6e18:      	mov	x19, x8
    6e1c:      	b	0x6c84 <_stogir.vector-comparison.validate+0x1a8>
    6e20:      	mov	x19, x8
    6e24:      	b	0x6c84 <_stogir.vector-comparison.validate+0x1a8>
    6e28:      	mov	x19, x8
    6e2c:      	b	0x6c84 <_stogir.vector-comparison.validate+0x1a8>

0000000000006e30 <_stogir.vector-arithmetic.node?>:
    6e30:      	sxtw	x1, w1
    6e34:      	cmp	x1, #0x0
    6e38:      	cset	w2, gt
    6e3c:      	movz	x16, #0x0, lsl #48
    6e40:      	sub	x3, x16, x1
    6e44:      	sub	x4, x3, #0x1
    6e48:      	uxtb	w16, w2
    6e4c:      	cmp	w16, wzr
    6e50:      	b.eq	0x6e90 <_stogir.vector-arithmetic.node?+0x60>
    6e54:      	ldr	x3, [x0, #0x8]
    6e58:      	cmp	x1, x3
    6e5c:      	b.ge	0x6ee0 <_stogir.vector-arithmetic.node?+0xb0>
    6e60:      	add	x3, x0, #0x78
    6e64:      	ldr	x3, [x3, #0x8]
    6e68:      	cmp	x1, x3
    6e6c:      	b.ge	0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
    6e70:      	ldr	x3, [x0, #0x78]
    6e74:      	add	x3, x3, x1, lsl #2
    6e78:      	ldr	w3, [x3]
    6e7c:      	sxtw	x3, w3
    6e80:      	cmp	x3, #0x0
    6e84:      	cset	w3, ge
    6e88:      	ubfx	x3, x3, #0, #8
    6e8c:      	b	0x7004 <_stogir.vector-arithmetic.node?+0x1d4>
    6e90:      	cmp	x1, #0x0
    6e94:      	b.ge	0x6ee8 <_stogir.vector-arithmetic.node?+0xb8>
    6e98:      	add	x5, x0, #0x28
    6e9c:      	add	x6, x0, #0x50
    6ea0:      	ldr	x5, [x5, #0x8]
    6ea4:      	ldr	x6, [x6, #0x8]
    6ea8:      	cmp	x5, x6
    6eac:      	b.ne	0x6ed8 <_stogir.vector-arithmetic.node?+0xa8>
    6eb0:      	cmp	x3, x5
    6eb4:      	b.gt	0x7010 <_stogir.vector-arithmetic.node?+0x1e0>
    6eb8:      	ldr	x3, [x0, #0x50]
    6ebc:      	add	x3, x3, x4, lsl #2
    6ec0:      	ldr	w3, [x3]
    6ec4:      	sxtw	x3, w3
    6ec8:      	cmp	x3, #0x0
    6ecc:      	cset	w3, gt
    6ed0:      	ubfx	x3, x3, #0, #8
    6ed4:      	b	0x7014 <_stogir.vector-arithmetic.node?+0x1e4>
    6ed8:      	movz	x3, #0x0, lsl #48
    6edc:      	b	0x6eec <_stogir.vector-arithmetic.node?+0xbc>
    6ee0:      	movz	x3, #0x0, lsl #48
    6ee4:      	b	0x6eec <_stogir.vector-arithmetic.node?+0xbc>
    6ee8:      	movz	x3, #0x0, lsl #48
    6eec:      	cmp	x3, #0x0
    6ef0:      	b.eq	0x6f24 <_stogir.vector-arithmetic.node?+0xf4>
    6ef4:      	uxtb	w16, w2
    6ef8:      	cmp	w16, wzr
    6efc:      	b.eq	0x6f10 <_stogir.vector-arithmetic.node?+0xe0>
    6f00:      	ldr	x0, [x0]
    6f04:      	add	x0, x0, x1, lsl #4
    6f08:      	ldr	x0, [x0]
    6f0c:      	b	0x6f1c <_stogir.vector-arithmetic.node?+0xec>
    6f10:      	ldr	x0, [x0, #0x28]
    6f14:      	add	x0, x0, x4, lsl #4
    6f18:      	ldr	x0, [x0]
    6f1c:      	mov	x1, #0x1                ; =1
    6f20:      	b	0x6f2c <_stogir.vector-arithmetic.node?+0xfc>
    6f24:      	movz	x1, #0x0, lsl #48
    6f28:      	movz	x0, #0x0, lsl #48
    6f2c:      	ubfx	x1, x1, #0, #32
    6f30:      	lsr	x16, x1, #0
    6f34:      	cmp	x16, #0x1
    6f38:      	b.eq	0x6f54 <_stogir.vector-arithmetic.node?+0x124>
    6f3c:      	b.lo	0x6f44 <_stogir.vector-arithmetic.node?+0x114>
    6f40:      	b	0x6f58 <_stogir.vector-arithmetic.node?+0x128>
    6f44:      	cmp	x16, #0x0
    6f48:      	b.eq	0x6f50 <_stogir.vector-arithmetic.node?+0x120>
    6f4c:      	b	0x6f58 <_stogir.vector-arithmetic.node?+0x128>
    6f50:      	b	0x6f5c <_stogir.vector-arithmetic.node?+0x12c>
    6f54:      	b	0x6f6c <_stogir.vector-arithmetic.node?+0x13c>
    6f58:      	b	0x7020 <_stogir.vector-arithmetic.node?+0x1f0>
    6f5c:      	movz	x0, #0x0, lsl #48
    6f60:      	b	0x6f68 <_stogir.vector-arithmetic.node?+0x138>
    6f64:      	movz	x0, #0x0, lsl #48
    6f68:      	ret
    6f6c:      	uxtb	w1, w0
    6f70:      	cmp	x1, #0x1f
    6f74:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6f78:      	cmp	x1, #0x20
    6f7c:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6f80:      	cmp	x1, #0x2d
    6f84:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6f88:      	cmp	x1, #0x36
    6f8c:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6f90:      	cmp	x1, #0x37
    6f94:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6f98:      	cmp	x1, #0x38
    6f9c:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6fa0:      	cmp	x1, #0x39
    6fa4:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6fa8:      	cmp	x1, #0x3a
    6fac:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6fb0:      	cmp	x1, #0x3b
    6fb4:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    6fb8:      	cmp	x1, #0x31
    6fbc:      	b.lt	0x7028 <_stogir.vector-arithmetic.node?+0x1f8>
    6fc0:      	cmp	x1, #0x35
    6fc4:      	b.gt	0x7028 <_stogir.vector-arithmetic.node?+0x1f8>
    6fc8:      	ubfx	x0, x0, #0, #32
    6fcc:      	ubfx	x0, x0, #8, #8
    6fd0:      	cmp	x0, #0xf
    6fd4:      	b.le	0x6f64 <_stogir.vector-arithmetic.node?+0x134>
    6fd8:      	cmp	x0, #0x80
    6fdc:      	b.ge	0x7008 <_stogir.vector-arithmetic.node?+0x1d8>
    6fe0:      	and	x0, x0, #0xf
    6fe4:      	sxtw	x0, w0
    6fe8:      	cmp	x0, #0x1
    6fec:      	b.lt	0x7018 <_stogir.vector-arithmetic.node?+0x1e8>
    6ff0:      	cmp	x0, #0xd
    6ff4:      	cset	w0, le
    6ff8:      	ubfx	x0, x0, #0, #8
    6ffc:      	b	0x701c <_stogir.vector-arithmetic.node?+0x1ec>
    7000:      	movz	x3, #0x0, lsl #48
    7004:      	b	0x6ee4 <_stogir.vector-arithmetic.node?+0xb4>
    7008:      	movz	x0, #0x0, lsl #48
    700c:      	b	0x6f68 <_stogir.vector-arithmetic.node?+0x138>
    7010:      	movz	x3, #0x0, lsl #48
    7014:      	b	0x6edc <_stogir.vector-arithmetic.node?+0xac>
    7018:      	movz	x0, #0x0, lsl #48
    701c:      	b	0x700c <_stogir.vector-arithmetic.node?+0x1dc>
    7020:      	brk	#0
    7024:      	b	0x7020 <_stogir.vector-arithmetic.node?+0x1f0>
    7028:      	cmp	x1, #0x1a
    702c:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    7030:      	cmp	x1, #0x1b
    7034:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    7038:      	cmp	x1, #0x1c
    703c:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    7040:      	cmp	x1, #0x1d
    7044:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    7048:      	cmp	x1, #0x1e
    704c:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    7050:      	cmp	x1, #0x2e
    7054:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    7058:      	cmp	x1, #0x2f
    705c:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    7060:      	cmp	x1, #0x30
    7064:      	b.eq	0x6fc8 <_stogir.vector-arithmetic.node?+0x198>
    7068:      	movz	x0, #0x0, lsl #48
    706c:      	b	0x6f68 <_stogir.vector-arithmetic.node?+0x138>

0000000000007070 <_stogir.vector-arithmetic.validate>:
    7070:      	sub	sp, sp, #0x60
    7074:      	str	x29, [sp]
    7078:      	str	x30, [sp, #0x8]
    707c:      	mov	x29, sp
    7080:      	str	x19, [sp, #0x40]
    7084:      	str	x20, [sp, #0x48]
    7088:      	str	x21, [sp, #0x50]
    708c:      	str	x22, [sp, #0x58]
    7090:      	sxtw	x2, w1
    7094:      	lsl	x19, x2, #2
    7098:      	cmp	x2, #0x0
    709c:      	cset	w3, gt
    70a0:      	movz	x16, #0x0, lsl #48
    70a4:      	sub	x4, x16, x2
    70a8:      	sub	x5, x4, #0x1
    70ac:      	uxtb	w16, w3
    70b0:      	cmp	w16, wzr
    70b4:      	b.eq	0x70f4 <_stogir.vector-arithmetic.validate+0x84>
    70b8:      	ldr	x4, [x0, #0x8]
    70bc:      	cmp	x2, x4
    70c0:      	b.ge	0x7144 <_stogir.vector-arithmetic.validate+0xd4>
    70c4:      	add	x4, x0, #0x78
    70c8:      	ldr	x4, [x4, #0x8]
    70cc:      	cmp	x2, x4
    70d0:      	b.ge	0x7244 <_stogir.vector-arithmetic.validate+0x1d4>
    70d4:      	ldr	x4, [x0, #0x78]
    70d8:      	add	x4, x19, x4
    70dc:      	ldr	w4, [x4]
    70e0:      	sxtw	x4, w4
    70e4:      	cmp	x4, #0x0
    70e8:      	cset	w4, ge
    70ec:      	ubfx	x4, x4, #0, #8
    70f0:      	b	0x7248 <_stogir.vector-arithmetic.validate+0x1d8>
    70f4:      	cmp	x2, #0x0
    70f8:      	b.ge	0x714c <_stogir.vector-arithmetic.validate+0xdc>
    70fc:      	add	x6, x0, #0x28
    7100:      	add	x7, x0, #0x50
    7104:      	ldr	x6, [x6, #0x8]
    7108:      	ldr	x7, [x7, #0x8]
    710c:      	cmp	x6, x7
    7110:      	b.ne	0x713c <_stogir.vector-arithmetic.validate+0xcc>
    7114:      	cmp	x4, x6
    7118:      	b.gt	0x72dc <_stogir.vector-arithmetic.validate+0x26c>
    711c:      	ldr	x4, [x0, #0x50]
    7120:      	add	x4, x4, x5, lsl #2
    7124:      	ldr	w4, [x4]
    7128:      	sxtw	x4, w4
    712c:      	cmp	x4, #0x0
    7130:      	cset	w4, gt
    7134:      	ubfx	x4, x4, #0, #8
    7138:      	b	0x72e0 <_stogir.vector-arithmetic.validate+0x270>
    713c:      	movz	x4, #0x0, lsl #48
    7140:      	b	0x7150 <_stogir.vector-arithmetic.validate+0xe0>
    7144:      	movz	x4, #0x0, lsl #48
    7148:      	b	0x7150 <_stogir.vector-arithmetic.validate+0xe0>
    714c:      	movz	x4, #0x0, lsl #48
    7150:      	cmp	x4, #0x0
    7154:      	b.eq	0x7190 <_stogir.vector-arithmetic.validate+0x120>
    7158:      	uxtb	w16, w3
    715c:      	cmp	w16, wzr
    7160:      	b.eq	0x7178 <_stogir.vector-arithmetic.validate+0x108>
    7164:      	ldr	x3, [x0]
    7168:      	add	x3, x3, x2, lsl #4
    716c:      	ldr	x20, [x3]
    7170:      	ldr	x3, [x3, #0x8]
    7174:      	b	0x7188 <_stogir.vector-arithmetic.validate+0x118>
    7178:      	ldr	x3, [x0, #0x28]
    717c:      	add	x3, x3, x5, lsl #4
    7180:      	ldr	x20, [x3]
    7184:      	ldr	x3, [x3, #0x8]
    7188:      	mov	x4, #0x1                ; =1
    718c:      	b	0x719c <_stogir.vector-arithmetic.validate+0x12c>
    7190:      	movz	x4, #0x0, lsl #48
    7194:      	movz	x20, #0x0, lsl #48
    7198:      	movz	x3, #0x0, lsl #48
    719c:      	ubfx	x4, x4, #0, #32
    71a0:      	lsr	x16, x4, #0
    71a4:      	cmp	x16, #0x1
    71a8:      	b.eq	0x71c4 <_stogir.vector-arithmetic.validate+0x154>
    71ac:      	b.lo	0x71b4 <_stogir.vector-arithmetic.validate+0x144>
    71b0:      	b	0x71c8 <_stogir.vector-arithmetic.validate+0x158>
    71b4:      	cmp	x16, #0x0
    71b8:      	b.eq	0x71c0 <_stogir.vector-arithmetic.validate+0x150>
    71bc:      	b	0x71c8 <_stogir.vector-arithmetic.validate+0x158>
    71c0:      	b	0x71cc <_stogir.vector-arithmetic.validate+0x15c>
    71c4:      	b	0x71e8 <_stogir.vector-arithmetic.validate+0x178>
    71c8:      	b	0x7378 <_stogir.vector-arithmetic.validate+0x308>
    71cc:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		00000000000071cc:  ARM64_RELOC_PAGE21	l_stogir.419
    71d0:      	ldr	x16, [x16]
		00000000000071d0:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    71d4:      	orr	x0, x16, xzr
    71d8:      	mov	x21, x8
    71dc:      	mov	x1, #0x1                ; =1
    71e0:      	mov	x2, #0x25               ; =37
    71e4:      	b	0x7218 <_stogir.vector-arithmetic.validate+0x1a8>
    71e8:      	add	x16, sp, #0x10
    71ec:      	str	x20, [x16]
    71f0:      	add	x16, sp, #0x10
    71f4:      	str	x3, [x16, #0x8]
    71f8:      	cmp	x2, #0x0
    71fc:      	b.gt	0x724c <_stogir.vector-arithmetic.validate+0x1dc>
    7200:      	mov	x21, x8
    7204:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		0000000000007204:  ARM64_RELOC_PAGE21	l_stogir.420
    7208:      	ldr	x16, [x16]
		0000000000007208:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    720c:      	orr	x0, x16, xzr
    7210:      	mov	x1, #0x1                ; =1
    7214:      	mov	x2, #0x2b               ; =43
    7218:      	str	x1, [x21]
    721c:      	str	x0, [x21, #0x8]
    7220:      	str	x2, [x21, #0x10]
    7224:      	ldr	x19, [sp, #0x40]
    7228:      	ldr	x20, [sp, #0x48]
    722c:      	ldr	x21, [sp, #0x50]
    7230:      	ldr	x22, [sp, #0x58]
    7234:      	ldr	x29, [sp]
    7238:      	ldr	x30, [sp, #0x8]
    723c:      	add	sp, sp, #0x60
    7240:      	ret
    7244:      	movz	x4, #0x0, lsl #48
    7248:      	b	0x7148 <_stogir.vector-arithmetic.validate+0xd8>
    724c:      	mov	x21, x8
    7250:      	mov	x22, x0
    7254:      	bl	0x7254 <_stogir.vector-arithmetic.validate+0x1e4>
		0000000000007254:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    7258:      	cmp	x0, #0x0
    725c:      	b.eq	0x7204 <_stogir.vector-arithmetic.validate+0x194>
    7260:      	uxtb	w20, w20
    7264:      	orr	x0, x20, xzr
    7268:      	ldr	x1, [x22, #0x78]
    726c:      	cmp	x0, #0x1d
    7270:      	cset	w2, eq
    7274:      	cmp	x0, #0x1e
    7278:      	cset	w3, eq
    727c:      	add	x1, x19, x1
    7280:      	ldr	w1, [x1]
    7284:      	cmp	x0, #0x1f
    7288:      	b.eq	0x732c <_stogir.vector-arithmetic.validate+0x2bc>
    728c:      	cmp	x0, #0x20
    7290:      	b.eq	0x732c <_stogir.vector-arithmetic.validate+0x2bc>
    7294:      	cmp	x0, #0x2d
    7298:      	b.eq	0x732c <_stogir.vector-arithmetic.validate+0x2bc>
    729c:      	cmp	x0, #0x36
    72a0:      	b.eq	0x732c <_stogir.vector-arithmetic.validate+0x2bc>
    72a4:      	cmp	x0, #0x37
    72a8:      	b.eq	0x732c <_stogir.vector-arithmetic.validate+0x2bc>
    72ac:      	cmp	x0, #0x38
    72b0:      	b.eq	0x732c <_stogir.vector-arithmetic.validate+0x2bc>
    72b4:      	cmp	x0, #0x39
    72b8:      	b.eq	0x732c <_stogir.vector-arithmetic.validate+0x2bc>
    72bc:      	uxtb	w16, w2
    72c0:      	cmp	w16, wzr
    72c4:      	b.ne	0x7380 <_stogir.vector-arithmetic.validate+0x310>
    72c8:      	uxtb	w16, w3
    72cc:      	cmp	w16, wzr
    72d0:      	b.ne	0x7380 <_stogir.vector-arithmetic.validate+0x310>
    72d4:      	mov	x0, #0x2                ; =2
    72d8:      	b	0x7384 <_stogir.vector-arithmetic.validate+0x314>
    72dc:      	movz	x4, #0x0, lsl #48
    72e0:      	b	0x7140 <_stogir.vector-arithmetic.validate+0xd0>
    72e4:      	add	x16, sp, #0x10
    72e8:      	ldr	w2, [x16, #0xc]
    72ec:      	sxtw	x2, w2
    72f0:      	ubfx	x0, x0, #8, #8
    72f4:      	add	x8, sp, #0x20
    72f8:      	mov	w3, w1
    72fc:      	mov	w1, w20
    7300:      	mov	w5, w2
    7304:      	mov	w2, w0
    7308:      	mov	x0, x22
    730c:      	bl	0x730c <_stogir.vector-arithmetic.validate+0x29c>
		000000000000730c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    7310:      	add	x16, sp, #0x20
    7314:      	ldr	x1, [x16]
    7318:      	add	x16, sp, #0x20
    731c:      	ldr	x0, [x16, #0x8]
    7320:      	add	x16, sp, #0x20
    7324:      	ldr	x2, [x16, #0x10]
    7328:      	b	0x7218 <_stogir.vector-arithmetic.validate+0x1a8>
    732c:      	mov	x0, #0x1                ; =1
    7330:      	sxtw	x1, w1
    7334:      	sxtw	x0, w0
    7338:      	cmp	x1, x0
    733c:      	b.ne	0x7204 <_stogir.vector-arithmetic.validate+0x194>
    7340:      	add	x16, sp, #0x10
    7344:      	ldr	w0, [x16]
    7348:      	add	x16, sp, #0x10
    734c:      	ldr	w1, [x16, #0x4]
    7350:      	add	x16, sp, #0x10
    7354:      	ldr	w4, [x16, #0x8]
    7358:      	uxtb	w16, w2
    735c:      	cmp	w16, wzr
    7360:      	b.ne	0x72e4 <_stogir.vector-arithmetic.validate+0x274>
    7364:      	uxtb	w16, w3
    7368:      	cmp	w16, wzr
    736c:      	b.ne	0x72e4 <_stogir.vector-arithmetic.validate+0x274>
    7370:      	movz	x2, #0x0, lsl #48
    7374:      	b	0x72f0 <_stogir.vector-arithmetic.validate+0x280>
    7378:      	brk	#0
    737c:      	b	0x7378 <_stogir.vector-arithmetic.validate+0x308>
    7380:      	mov	x0, #0x3                ; =3
    7384:      	b	0x7330 <_stogir.vector-arithmetic.validate+0x2c0>

0000000000007388 <_stogir.vector.memory-inputs>:
    7388:      	sub	sp, sp, #0x40
    738c:      	str	x29, [sp]
    7390:      	str	x30, [sp, #0x8]
    7394:      	mov	x29, sp
    7398:      	str	x19, [sp, #0x10]
    739c:      	str	x20, [sp, #0x18]
    73a0:      	str	x21, [sp, #0x20]
    73a4:      	str	x22, [sp, #0x28]
    73a8:      	str	x23, [sp, #0x30]
    73ac:      	str	x24, [sp, #0x38]
    73b0:      	sxtw	x5, w1
    73b4:      	cmp	x5, #0xf
    73b8:      	b.le	0x782c <_stogir.vector.memory-inputs+0x4a4>
    73bc:      	cmp	x5, #0x80
    73c0:      	b.ge	0x7834 <_stogir.vector.memory-inputs+0x4ac>
    73c4:      	and	x6, x5, #0xf
    73c8:      	sxtw	x6, w6
    73cc:      	cmp	x6, #0x1
    73d0:      	b.lt	0x783c <_stogir.vector.memory-inputs+0x4b4>
    73d4:      	and	x5, x5, #0xf
    73d8:      	sxtw	x5, w5
    73dc:      	cmp	x5, #0xd
    73e0:      	b.gt	0x7844 <_stogir.vector.memory-inputs+0x4bc>
    73e4:      	mov	x19, x8
    73e8:      	mov	x20, x0
    73ec:      	mov	w0, w1
    73f0:      	mov	w21, w1
    73f4:      	mov	w1, w2
    73f8:      	mov	w22, w2
    73fc:      	mov	w23, w3
    7400:      	mov	w24, w4
    7404:      	bl	0x7404 <_stogir.vector.memory-inputs+0x7c>
		0000000000007404:  ARM64_RELOC_BRANCH26	_stogir.types.size
    7408:      	sxtw	x0, w0
    740c:      	cmp	x0, #0x0
    7410:      	b.le	0x7474 <_stogir.vector.memory-inputs+0xec>
    7414:      	sxtw	x23, w23
    7418:      	cmp	x23, #0x0
    741c:      	cset	w0, gt
    7420:      	movz	x16, #0x0, lsl #48
    7424:      	sub	x1, x16, x23
    7428:      	sub	x2, x1, #0x1
    742c:      	uxtb	w16, w0
    7430:      	cmp	w16, wzr
    7434:      	b.eq	0x7550 <_stogir.vector.memory-inputs+0x1c8>
    7438:      	ldr	x1, [x20, #0x8]
    743c:      	cmp	x23, x1
    7440:      	b.ge	0x7548 <_stogir.vector.memory-inputs+0x1c0>
    7444:      	add	x1, x20, #0x78
    7448:      	ldr	x1, [x1, #0x8]
    744c:      	cmp	x23, x1
    7450:      	b.ge	0x75f0 <_stogir.vector.memory-inputs+0x268>
    7454:      	ldr	x1, [x20, #0x78]
    7458:      	add	x1, x1, x23, lsl #2
    745c:      	ldr	w1, [x1]
    7460:      	sxtw	x1, w1
    7464:      	cmp	x1, #0x0
    7468:      	cset	w1, ge
    746c:      	ubfx	x1, x1, #0, #8
    7470:      	b	0x75f4 <_stogir.vector.memory-inputs+0x26c>
    7474:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		0000000000007474:  ARM64_RELOC_PAGE21	l_stogir.421
    7478:      	ldr	x16, [x16]
		0000000000007478:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    747c:      	orr	x0, x16, xzr
    7480:      	mov	x1, #0x1                ; =1
    7484:      	mov	x2, #0x32               ; =50
    7488:      	str	x1, [x19]
    748c:      	str	x0, [x19, #0x8]
    7490:      	str	x2, [x19, #0x10]
    7494:      	ldr	x19, [sp, #0x10]
    7498:      	ldr	x20, [sp, #0x18]
    749c:      	ldr	x21, [sp, #0x20]
    74a0:      	ldr	x22, [sp, #0x28]
    74a4:      	ldr	x23, [sp, #0x30]
    74a8:      	ldr	x24, [sp, #0x38]
    74ac:      	ldr	x29, [sp]
    74b0:      	ldr	x30, [sp, #0x8]
    74b4:      	add	sp, sp, #0x40
    74b8:      	ret
    74bc:      	movz	x1, #0x0, lsl #48
    74c0:      	movz	x0, #0x0, lsl #48
    74c4:      	ubfx	x1, x1, #0, #32
    74c8:      	lsr	x16, x1, #0
    74cc:      	cmp	x16, #0x1
    74d0:      	b.eq	0x74ec <_stogir.vector.memory-inputs+0x164>
    74d4:      	b.lo	0x74dc <_stogir.vector.memory-inputs+0x154>
    74d8:      	b	0x74f0 <_stogir.vector.memory-inputs+0x168>
    74dc:      	cmp	x16, #0x0
    74e0:      	b.eq	0x74e8 <_stogir.vector.memory-inputs+0x160>
    74e4:      	b	0x74f0 <_stogir.vector.memory-inputs+0x168>
    74e8:      	b	0x74f4 <_stogir.vector.memory-inputs+0x16c>
    74ec:      	b	0x7598 <_stogir.vector.memory-inputs+0x210>
    74f0:      	b	0x7814 <_stogir.vector.memory-inputs+0x48c>
    74f4:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		00000000000074f4:  ARM64_RELOC_PAGE21	l_stogir.422
    74f8:      	ldr	x16, [x16]
		00000000000074f8:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    74fc:      	orr	x0, x16, xzr
    7500:      	mov	x1, #0x1                ; =1
    7504:      	mov	x2, #0x1d               ; =29
    7508:      	b	0x7488 <_stogir.vector.memory-inputs+0x100>
    750c:      	ldr	x0, [x20, #0x28]
    7510:      	add	x0, x0, x2, lsl #4
    7514:      	ldr	x0, [x0]
    7518:      	mov	x1, #0x1                ; =1
    751c:      	b	0x74c4 <_stogir.vector.memory-inputs+0x13c>
    7520:      	movz	x1, #0x0, lsl #48
    7524:      	cmp	x1, #0x0
    7528:      	b.eq	0x74bc <_stogir.vector.memory-inputs+0x134>
    752c:      	uxtb	w16, w0
    7530:      	cmp	w16, wzr
    7534:      	b.eq	0x750c <_stogir.vector.memory-inputs+0x184>
    7538:      	ldr	x0, [x20]
    753c:      	add	x0, x0, x23, lsl #4
    7540:      	ldr	x0, [x0]
    7544:      	b	0x7518 <_stogir.vector.memory-inputs+0x190>
    7548:      	movz	x1, #0x0, lsl #48
    754c:      	b	0x7524 <_stogir.vector.memory-inputs+0x19c>
    7550:      	cmp	x23, #0x0
    7554:      	b.ge	0x7520 <_stogir.vector.memory-inputs+0x198>
    7558:      	add	x3, x20, #0x28
    755c:      	add	x4, x20, #0x50
    7560:      	ldr	x3, [x3, #0x8]
    7564:      	ldr	x4, [x4, #0x8]
    7568:      	cmp	x3, x4
    756c:      	b.ne	0x75e8 <_stogir.vector.memory-inputs+0x260>
    7570:      	cmp	x1, x3
    7574:      	b.gt	0x75f8 <_stogir.vector.memory-inputs+0x270>
    7578:      	ldr	x1, [x20, #0x50]
    757c:      	add	x1, x1, x2, lsl #2
    7580:      	ldr	w1, [x1]
    7584:      	sxtw	x1, w1
    7588:      	cmp	x1, #0x0
    758c:      	cset	w1, gt
    7590:      	ubfx	x1, x1, #0, #8
    7594:      	b	0x75fc <_stogir.vector.memory-inputs+0x274>
    7598:      	cmp	x23, #0x0
    759c:      	b.le	0x75d0 <_stogir.vector.memory-inputs+0x248>
    75a0:      	uxtb	w0, w0
    75a4:      	cmp	x0, #0x83
    75a8:      	cset	w1, lt
    75ac:      	uxtb	w16, w1
    75b0:      	cmp	w16, wzr
    75b4:      	b.eq	0x7600 <_stogir.vector.memory-inputs+0x278>
    75b8:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		00000000000075b8:  ARM64_RELOC_PAGE21	l_stogir.423
    75bc:      	ldr	x16, [x16]
		00000000000075bc:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    75c0:      	orr	x2, x16, xzr
    75c4:      	add	x2, x0, x2
    75c8:      	ldrb	w2, [x2]
    75cc:      	b	0x7604 <_stogir.vector.memory-inputs+0x27c>
    75d0:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		00000000000075d0:  ARM64_RELOC_PAGE21	l_stogir.424
    75d4:      	ldr	x16, [x16]
		00000000000075d4:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    75d8:      	orr	x0, x16, xzr
    75dc:      	mov	x1, #0x1                ; =1
    75e0:      	mov	x2, #0x2c               ; =44
    75e4:      	b	0x7508 <_stogir.vector.memory-inputs+0x180>
    75e8:      	movz	x1, #0x0, lsl #48
    75ec:      	b	0x7524 <_stogir.vector.memory-inputs+0x19c>
    75f0:      	movz	x1, #0x0, lsl #48
    75f4:      	b	0x754c <_stogir.vector.memory-inputs+0x1c4>
    75f8:      	movz	x1, #0x0, lsl #48
    75fc:      	b	0x75ec <_stogir.vector.memory-inputs+0x264>
    7600:      	movz	x2, #0x0, lsl #48
    7604:      	uxtb	w2, w2
    7608:      	and	x2, x2, #0x1
    760c:      	uxtb	w2, w2
    7610:      	cmp	x2, #0x0
    7614:      	b.eq	0x75d0 <_stogir.vector.memory-inputs+0x248>
    7618:      	uxtb	w16, w1
    761c:      	cmp	w16, wzr
    7620:      	b.eq	0x763c <_stogir.vector.memory-inputs+0x2b4>
    7624:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		0000000000007624:  ARM64_RELOC_PAGE21	l_stogir.423
    7628:      	ldr	x16, [x16]
		0000000000007628:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    762c:      	orr	x1, x16, xzr
    7630:      	add	x0, x0, x1
    7634:      	ldrb	w0, [x0]
    7638:      	b	0x7640 <_stogir.vector.memory-inputs+0x2b8>
    763c:      	movz	x0, #0x0, lsl #48
    7640:      	uxtb	w0, w0
    7644:      	and	x0, x0, #0x4
    7648:      	uxtb	w0, w0
    764c:      	cmp	x0, #0x0
    7650:      	cset	w0, eq
    7654:      	uxtb	w16, w0
    7658:      	cmp	w16, wzr
    765c:      	cset	x0, eq
    7660:      	cmp	x0, #0x0
    7664:      	b.ne	0x75d0 <_stogir.vector.memory-inputs+0x248>
    7668:      	sxtw	x24, w24
    766c:      	cmp	x24, #0x0
    7670:      	cset	w0, gt
    7674:      	movz	x16, #0x0, lsl #48
    7678:      	sub	x1, x16, x24
    767c:      	sub	x2, x1, #0x1
    7680:      	uxtb	w16, w0
    7684:      	cmp	w16, wzr
    7688:      	b.eq	0x76e0 <_stogir.vector.memory-inputs+0x358>
    768c:      	ldr	x1, [x20, #0x8]
    7690:      	cmp	x24, x1
    7694:      	b.ge	0x7728 <_stogir.vector.memory-inputs+0x3a0>
    7698:      	add	x1, x20, #0x78
    769c:      	ldr	x1, [x1, #0x8]
    76a0:      	cmp	x24, x1
    76a4:      	b.ge	0x780c <_stogir.vector.memory-inputs+0x484>
    76a8:      	ldr	x1, [x20, #0x78]
    76ac:      	add	x1, x1, x24, lsl #2
    76b0:      	ldr	w1, [x1]
    76b4:      	sxtw	x1, w1
    76b8:      	cmp	x1, #0x0
    76bc:      	cset	w1, ge
    76c0:      	ubfx	x1, x1, #0, #8
    76c4:      	b	0x7810 <_stogir.vector.memory-inputs+0x488>
    76c8:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		00000000000076c8:  ARM64_RELOC_PAGE21	l_stogir.425
    76cc:      	ldr	x16, [x16]
		00000000000076cc:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    76d0:      	orr	x0, x16, xzr
    76d4:      	mov	x1, #0x1                ; =1
    76d8:      	mov	x2, #0x2b               ; =43
    76dc:      	b	0x75e4 <_stogir.vector.memory-inputs+0x25c>
    76e0:      	cmp	x24, #0x0
    76e4:      	b.ge	0x7730 <_stogir.vector.memory-inputs+0x3a8>
    76e8:      	add	x3, x20, #0x28
    76ec:      	add	x4, x20, #0x50
    76f0:      	ldr	x3, [x3, #0x8]
    76f4:      	ldr	x4, [x4, #0x8]
    76f8:      	cmp	x3, x4
    76fc:      	b.ne	0x7804 <_stogir.vector.memory-inputs+0x47c>
    7700:      	cmp	x1, x3
    7704:      	b.gt	0x781c <_stogir.vector.memory-inputs+0x494>
    7708:      	ldr	x1, [x20, #0x50]
    770c:      	add	x1, x1, x2, lsl #2
    7710:      	ldr	w1, [x1]
    7714:      	sxtw	x1, w1
    7718:      	cmp	x1, #0x0
    771c:      	cset	w1, gt
    7720:      	ubfx	x1, x1, #0, #8
    7724:      	b	0x7820 <_stogir.vector.memory-inputs+0x498>
    7728:      	movz	x1, #0x0, lsl #48
    772c:      	b	0x7734 <_stogir.vector.memory-inputs+0x3ac>
    7730:      	movz	x1, #0x0, lsl #48
    7734:      	cmp	x1, #0x0
    7738:      	b.eq	0x776c <_stogir.vector.memory-inputs+0x3e4>
    773c:      	uxtb	w16, w0
    7740:      	cmp	w16, wzr
    7744:      	b.eq	0x7758 <_stogir.vector.memory-inputs+0x3d0>
    7748:      	ldr	x0, [x20]
    774c:      	add	x0, x0, x24, lsl #4
    7750:      	ldr	x0, [x0]
    7754:      	b	0x7764 <_stogir.vector.memory-inputs+0x3dc>
    7758:      	ldr	x0, [x20, #0x28]
    775c:      	add	x0, x0, x2, lsl #4
    7760:      	ldr	x0, [x0]
    7764:      	mov	x1, #0x1                ; =1
    7768:      	b	0x7774 <_stogir.vector.memory-inputs+0x3ec>
    776c:      	movz	x1, #0x0, lsl #48
    7770:      	movz	x0, #0x0, lsl #48
    7774:      	ubfx	x1, x1, #0, #32
    7778:      	lsr	x16, x1, #0
    777c:      	cmp	x16, #0x1
    7780:      	b.eq	0x779c <_stogir.vector.memory-inputs+0x414>
    7784:      	b.lo	0x778c <_stogir.vector.memory-inputs+0x404>
    7788:      	b	0x77a0 <_stogir.vector.memory-inputs+0x418>
    778c:      	cmp	x16, #0x0
    7790:      	b.eq	0x7798 <_stogir.vector.memory-inputs+0x410>
    7794:      	b	0x77a0 <_stogir.vector.memory-inputs+0x418>
    7798:      	b	0x77a4 <_stogir.vector.memory-inputs+0x41c>
    779c:      	b	0x77bc <_stogir.vector.memory-inputs+0x434>
    77a0:      	b	0x7824 <_stogir.vector.memory-inputs+0x49c>
    77a4:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		00000000000077a4:  ARM64_RELOC_PAGE21	l_stogir.426
    77a8:      	ldr	x16, [x16]
		00000000000077a8:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    77ac:      	orr	x0, x16, xzr
    77b0:      	mov	x1, #0x1                ; =1
    77b4:      	mov	x2, #0x1d               ; =29
    77b8:      	b	0x76dc <_stogir.vector.memory-inputs+0x354>
    77bc:      	orr	w1, w0, wzr
    77c0:      	ubfx	x1, x1, #0, #32
    77c4:      	ubfx	x1, x1, #8, #8
    77c8:      	cmp	x1, #0x6
    77cc:      	b.ne	0x76c8 <_stogir.vector.memory-inputs+0x340>
    77d0:      	uxtb	w0, w0
    77d4:      	cmp	x0, #0x48
    77d8:      	b.eq	0x76c8 <_stogir.vector.memory-inputs+0x340>
    77dc:      	cmp	x0, #0x46
    77e0:      	b.eq	0x76c8 <_stogir.vector.memory-inputs+0x340>
    77e4:      	mov	w0, w21
    77e8:      	mov	w1, w22
    77ec:      	bl	0x77ec <_stogir.vector.memory-inputs+0x464>
		00000000000077ec:  ARM64_RELOC_BRANCH26	_stogir.types.size
    77f0:      	sxtw	x0, w0
    77f4:      	and	x0, x0, #0xffffffff
    77f8:      	movz	x1, #0x0, lsl #48
    77fc:      	movz	x2, #0x0, lsl #48
    7800:      	b	0x76dc <_stogir.vector.memory-inputs+0x354>
    7804:      	movz	x1, #0x0, lsl #48
    7808:      	b	0x7734 <_stogir.vector.memory-inputs+0x3ac>
    780c:      	movz	x1, #0x0, lsl #48
    7810:      	b	0x772c <_stogir.vector.memory-inputs+0x3a4>
    7814:      	brk	#0
    7818:      	b	0x7814 <_stogir.vector.memory-inputs+0x48c>
    781c:      	movz	x1, #0x0, lsl #48
    7820:      	b	0x7808 <_stogir.vector.memory-inputs+0x480>
    7824:      	brk	#0
    7828:      	b	0x7824 <_stogir.vector.memory-inputs+0x49c>
    782c:      	mov	x19, x8
    7830:      	b	0x7474 <_stogir.vector.memory-inputs+0xec>
    7834:      	mov	x19, x8
    7838:      	b	0x7474 <_stogir.vector.memory-inputs+0xec>
    783c:      	mov	x19, x8
    7840:      	b	0x7474 <_stogir.vector.memory-inputs+0xec>
    7844:      	mov	x19, x8
    7848:      	b	0x7474 <_stogir.vector.memory-inputs+0xec>

000000000000784c <_stogir.vector.store-inputs>:
    784c:      	sub	sp, sp, #0x40
    7850:      	str	x29, [sp]
    7854:      	str	x30, [sp, #0x8]
    7858:      	mov	x29, sp
    785c:      	str	x19, [sp, #0x30]
    7860:      	sxtw	x4, w4
    7864:      	cmp	x4, #0x0
    7868:      	cset	w5, gt
    786c:      	movz	x16, #0x0, lsl #48
    7870:      	sub	x6, x16, x4
    7874:      	sub	x7, x6, #0x1
    7878:      	uxtb	w16, w5
    787c:      	cmp	w16, wzr
    7880:      	b.eq	0x78c0 <_stogir.vector.store-inputs+0x74>
    7884:      	ldr	x6, [x0, #0x8]
    7888:      	cmp	x4, x6
    788c:      	b.ge	0x7910 <_stogir.vector.store-inputs+0xc4>
    7890:      	add	x6, x0, #0x78
    7894:      	ldr	x6, [x6, #0x8]
    7898:      	cmp	x4, x6
    789c:      	b.ge	0x7a08 <_stogir.vector.store-inputs+0x1bc>
    78a0:      	ldr	x6, [x0, #0x78]
    78a4:      	add	x6, x6, x4, lsl #2
    78a8:      	ldr	w6, [x6]
    78ac:      	sxtw	x6, w6
    78b0:      	cmp	x6, #0x0
    78b4:      	cset	w6, ge
    78b8:      	ubfx	x6, x6, #0, #8
    78bc:      	b	0x7a0c <_stogir.vector.store-inputs+0x1c0>
    78c0:      	cmp	x4, #0x0
    78c4:      	b.ge	0x7918 <_stogir.vector.store-inputs+0xcc>
    78c8:      	add	x9, x0, #0x28
    78cc:      	add	x10, x0, #0x50
    78d0:      	ldr	x9, [x9, #0x8]
    78d4:      	ldr	x10, [x10, #0x8]
    78d8:      	cmp	x9, x10
    78dc:      	b.ne	0x7908 <_stogir.vector.store-inputs+0xbc>
    78e0:      	cmp	x6, x9
    78e4:      	b.gt	0x7a10 <_stogir.vector.store-inputs+0x1c4>
    78e8:      	ldr	x6, [x0, #0x50]
    78ec:      	add	x6, x6, x7, lsl #2
    78f0:      	ldr	w6, [x6]
    78f4:      	sxtw	x6, w6
    78f8:      	cmp	x6, #0x0
    78fc:      	cset	w6, gt
    7900:      	ubfx	x6, x6, #0, #8
    7904:      	b	0x7a14 <_stogir.vector.store-inputs+0x1c8>
    7908:      	movz	x6, #0x0, lsl #48
    790c:      	b	0x791c <_stogir.vector.store-inputs+0xd0>
    7910:      	movz	x6, #0x0, lsl #48
    7914:      	b	0x791c <_stogir.vector.store-inputs+0xd0>
    7918:      	movz	x6, #0x0, lsl #48
    791c:      	cmp	x6, #0x0
    7920:      	b.eq	0x7954 <_stogir.vector.store-inputs+0x108>
    7924:      	uxtb	w16, w5
    7928:      	cmp	w16, wzr
    792c:      	b.eq	0x7940 <_stogir.vector.store-inputs+0xf4>
    7930:      	ldr	x5, [x0]
    7934:      	add	x4, x5, x4, lsl #4
    7938:      	ldr	x4, [x4]
    793c:      	b	0x794c <_stogir.vector.store-inputs+0x100>
    7940:      	ldr	x4, [x0, #0x28]
    7944:      	add	x4, x4, x7, lsl #4
    7948:      	ldr	x4, [x4]
    794c:      	mov	x5, #0x1                ; =1
    7950:      	b	0x795c <_stogir.vector.store-inputs+0x110>
    7954:      	movz	x5, #0x0, lsl #48
    7958:      	movz	x4, #0x0, lsl #48
    795c:      	ubfx	x5, x5, #0, #32
    7960:      	lsr	x16, x5, #0
    7964:      	cmp	x16, #0x1
    7968:      	b.eq	0x7984 <_stogir.vector.store-inputs+0x138>
    796c:      	b.lo	0x7974 <_stogir.vector.store-inputs+0x128>
    7970:      	b	0x7988 <_stogir.vector.store-inputs+0x13c>
    7974:      	cmp	x16, #0x0
    7978:      	b.eq	0x7980 <_stogir.vector.store-inputs+0x134>
    797c:      	b	0x7988 <_stogir.vector.store-inputs+0x13c>
    7980:      	b	0x798c <_stogir.vector.store-inputs+0x140>
    7984:      	b	0x79a8 <_stogir.vector.store-inputs+0x15c>
    7988:      	b	0x7a18 <_stogir.vector.store-inputs+0x1cc>
    798c:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		000000000000798c:  ARM64_RELOC_PAGE21	l_stogir.427
    7990:      	ldr	x16, [x16]
		0000000000007990:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    7994:      	orr	x0, x16, xzr
    7998:      	mov	x19, x8
    799c:      	mov	x1, #0x1                ; =1
    79a0:      	mov	x2, #0x1a               ; =26
    79a4:      	b	0x79e8 <_stogir.vector.store-inputs+0x19c>
    79a8:      	ubfx	x4, x4, #0, #32
    79ac:      	ubfx	x4, x4, #8, #8
    79b0:      	mov	x19, x8
    79b4:      	add	x8, sp, #0x10
    79b8:      	fmov	s31, w1
    79bc:      	mov	w1, w4
    79c0:      	mov	w4, w3
    79c4:      	mov	w3, w2
    79c8:      	fmov	w2, s31
    79cc:      	bl	0x79cc <_stogir.vector.store-inputs+0x180>
		00000000000079cc:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    79d0:      	add	x16, sp, #0x10
    79d4:      	ldr	x1, [x16]
    79d8:      	add	x16, sp, #0x10
    79dc:      	ldr	x0, [x16, #0x8]
    79e0:      	add	x16, sp, #0x10
    79e4:      	ldr	x2, [x16, #0x10]
    79e8:      	str	x1, [x19]
    79ec:      	str	x0, [x19, #0x8]
    79f0:      	str	x2, [x19, #0x10]
    79f4:      	ldr	x19, [sp, #0x30]
    79f8:      	ldr	x29, [sp]
    79fc:      	ldr	x30, [sp, #0x8]
    7a00:      	add	sp, sp, #0x40
    7a04:      	ret
    7a08:      	movz	x6, #0x0, lsl #48
    7a0c:      	b	0x7914 <_stogir.vector.store-inputs+0xc8>
    7a10:      	movz	x6, #0x0, lsl #48
    7a14:      	b	0x790c <_stogir.vector.store-inputs+0xc0>
    7a18:      	brk	#0
    7a1c:      	b	0x7a18 <_stogir.vector.store-inputs+0x1cc>

0000000000007a20 <_stogir.types.size>:
    7a20:      	sxtw	x0, w0
    7a24:      	sxtw	x1, w1
    7a28:      	cmp	x0, #0xf
    7a2c:      	cset	w2, gt
    7a30:      	cmp	x0, #0x0
    7a34:      	cset	w3, eq
    7a38:      	cmp	x1, #0x4
    7a3c:      	cset	w4, eq
    7a40:      	cmp	x1, #0x8
    7a44:      	cset	w5, eq
    7a48:      	uxtb	w16, w2
    7a4c:      	cmp	w16, wzr
    7a50:      	b.eq	0x7b14 <_stogir.types.size+0xf4>
    7a54:      	cmp	x0, #0x80
    7a58:      	cset	w6, lt
    7a5c:      	uxtb	w16, w6
    7a60:      	cmp	w16, wzr
    7a64:      	b.eq	0x7b14 <_stogir.types.size+0xf4>
    7a68:      	and	x7, x0, #0xf
    7a6c:      	sxtw	x7, w7
    7a70:      	cmp	x7, #0x1
    7a74:      	cset	w8, ge
    7a78:      	uxtb	w16, w8
    7a7c:      	cmp	w16, wzr
    7a80:      	b.eq	0x7b14 <_stogir.types.size+0xf4>
    7a84:      	cmp	x7, #0xd
    7a88:      	cset	w9, le
    7a8c:      	uxtb	w16, w9
    7a90:      	cmp	w16, wzr
    7a94:      	b.eq	0x7b14 <_stogir.types.size+0xf4>
    7a98:      	cmp	x0, #0x0
    7a9c:      	cset	w10, ge
    7aa0:      	cmp	x0, #0xd
    7aa4:      	cset	w11, le
    7aa8:      	uxtb	w16, w10
    7aac:      	cmp	w16, wzr
    7ab0:      	b.eq	0x7ac0 <_stogir.types.size+0xa0>
    7ab4:      	uxtb	w16, w11
    7ab8:      	cmp	w16, wzr
    7abc:      	b.ne	0x7af4 <_stogir.types.size+0xd4>
    7ac0:      	uxtb	w16, w2
    7ac4:      	cmp	w16, wzr
    7ac8:      	b.eq	0x7af0 <_stogir.types.size+0xd0>
    7acc:      	uxtb	w16, w6
    7ad0:      	cmp	w16, wzr
    7ad4:      	b.eq	0x7af0 <_stogir.types.size+0xd0>
    7ad8:      	uxtb	w16, w8
    7adc:      	cmp	w16, wzr
    7ae0:      	b.eq	0x7af0 <_stogir.types.size+0xd0>
    7ae4:      	uxtb	w16, w9
    7ae8:      	cmp	w16, wzr
    7aec:      	b.ne	0x7af4 <_stogir.types.size+0xd4>
    7af0:      	movn	x7, #0x0, lsl #48
    7af4:      	uxtb	w16, w4
    7af8:      	cmp	w16, wzr
    7afc:      	b.ne	0x7c40 <_stogir.types.size+0x220>
    7b00:      	uxtb	w16, w5
    7b04:      	cmp	w16, wzr
    7b08:      	b.ne	0x7c40 <_stogir.types.size+0x220>
    7b0c:      	movn	x1, #0x0, lsl #48
    7b10:      	b	0x7bc8 <_stogir.types.size+0x1a8>
    7b14:      	uxtb	w16, w4
    7b18:      	cmp	w16, wzr
    7b1c:      	b.ne	0x7b34 <_stogir.types.size+0x114>
    7b20:      	uxtb	w16, w5
    7b24:      	cmp	w16, wzr
    7b28:      	b.ne	0x7b34 <_stogir.types.size+0x114>
    7b2c:      	movn	x1, #0x0, lsl #48
    7b30:      	b	0x7b4c <_stogir.types.size+0x12c>
    7b34:      	uxtb	w16, w3
    7b38:      	cmp	w16, wzr
    7b3c:      	b.eq	0x7b54 <_stogir.types.size+0x134>
    7b40:      	movz	x1, #0x0, lsl #48
    7b44:      	b	0x7b4c <_stogir.types.size+0x12c>
    7b48:      	mov	x1, #0x1                ; =1
    7b4c:      	mov	x0, x1
    7b50:      	ret
    7b54:      	cmp	x0, #0x1
    7b58:      	b.eq	0x7b48 <_stogir.types.size+0x128>
    7b5c:      	cmp	x0, #0x2
    7b60:      	b.eq	0x7b48 <_stogir.types.size+0x128>
    7b64:      	cmp	x0, #0x7
    7b68:      	b.eq	0x7b48 <_stogir.types.size+0x128>
    7b6c:      	cmp	x0, #0x8
    7b70:      	b.eq	0x7b48 <_stogir.types.size+0x128>
    7b74:      	cmp	x0, #0x3
    7b78:      	b.eq	0x7cc4 <_stogir.types.size+0x2a4>
    7b7c:      	cmp	x0, #0x9
    7b80:      	b.eq	0x7cc4 <_stogir.types.size+0x2a4>
    7b84:      	cmp	x0, #0x4
    7b88:      	b.eq	0x7cf4 <_stogir.types.size+0x2d4>
    7b8c:      	cmp	x0, #0xa
    7b90:      	b.eq	0x7cf4 <_stogir.types.size+0x2d4>
    7b94:      	cmp	x0, #0xd
    7b98:      	b.eq	0x7cf4 <_stogir.types.size+0x2d4>
    7b9c:      	cmp	x0, #0x5
    7ba0:      	b.eq	0x7d04 <_stogir.types.size+0x2e4>
    7ba4:      	cmp	x0, #0xb
    7ba8:      	b.eq	0x7d04 <_stogir.types.size+0x2e4>
    7bac:      	cmp	x0, #0xc
    7bb0:      	b.eq	0x7d04 <_stogir.types.size+0x2e4>
    7bb4:      	cmp	x0, #0x6
    7bb8:      	b.eq	0x7bc0 <_stogir.types.size+0x1a0>
    7bbc:      	movn	x1, #0x0, lsl #48
    7bc0:      	b	0x7d08 <_stogir.types.size+0x2e8>
    7bc4:      	mov	x1, #0x1                ; =1
    7bc8:      	sxtw	x1, w1
    7bcc:      	cmp	x1, #0x0
    7bd0:      	b.ge	0x7bdc <_stogir.types.size+0x1bc>
    7bd4:      	movn	x1, #0x0, lsl #48
    7bd8:      	b	0x7b4c <_stogir.types.size+0x12c>
    7bdc:      	uxtb	w16, w2
    7be0:      	cmp	w16, wzr
    7be4:      	b.eq	0x7ccc <_stogir.types.size+0x2ac>
    7be8:      	uxtb	w16, w6
    7bec:      	cmp	w16, wzr
    7bf0:      	b.eq	0x7ccc <_stogir.types.size+0x2ac>
    7bf4:      	uxtb	w16, w8
    7bf8:      	cmp	w16, wzr
    7bfc:      	b.eq	0x7ccc <_stogir.types.size+0x2ac>
    7c00:      	uxtb	w16, w9
    7c04:      	cmp	w16, wzr
    7c08:      	b.eq	0x7ccc <_stogir.types.size+0x2ac>
    7c0c:      	ubfx	x0, x0, #4, #32
    7c10:      	sxtw	x0, w0
    7c14:      	sub	x0, x0, #0x1
    7c18:      	sxtw	x0, w0
    7c1c:      	mov	x16, #0x1               ; =1
    7c20:      	lsl	x0, x16, x0
    7c24:      	sxtw	x0, w0
    7c28:      	b	0x7c30 <_stogir.types.size+0x210>
    7c2c:      	movn	x0, #0x0, lsl #48
    7c30:      	sxtw	x0, w0
    7c34:      	mul	x0, x0, x1
    7c38:      	sxtw	x1, w0
    7c3c:      	b	0x7bd8 <_stogir.types.size+0x1b8>
    7c40:      	sxtw	x7, w7
    7c44:      	cmp	x7, #0x0
    7c48:      	b.ne	0x7c54 <_stogir.types.size+0x234>
    7c4c:      	movz	x1, #0x0, lsl #48
    7c50:      	b	0x7bc8 <_stogir.types.size+0x1a8>
    7c54:      	cmp	x7, #0x1
    7c58:      	b.eq	0x7bc4 <_stogir.types.size+0x1a4>
    7c5c:      	cmp	x7, #0x2
    7c60:      	b.eq	0x7bc4 <_stogir.types.size+0x1a4>
    7c64:      	cmp	x7, #0x7
    7c68:      	b.eq	0x7bc4 <_stogir.types.size+0x1a4>
    7c6c:      	cmp	x7, #0x8
    7c70:      	b.eq	0x7bc4 <_stogir.types.size+0x1a4>
    7c74:      	cmp	x7, #0x3
    7c78:      	b.eq	0x7cfc <_stogir.types.size+0x2dc>
    7c7c:      	cmp	x7, #0x9
    7c80:      	b.eq	0x7cfc <_stogir.types.size+0x2dc>
    7c84:      	cmp	x7, #0x4
    7c88:      	b.eq	0x7d0c <_stogir.types.size+0x2ec>
    7c8c:      	cmp	x7, #0xa
    7c90:      	b.eq	0x7d0c <_stogir.types.size+0x2ec>
    7c94:      	cmp	x7, #0xd
    7c98:      	b.eq	0x7d0c <_stogir.types.size+0x2ec>
    7c9c:      	cmp	x7, #0x5
    7ca0:      	b.eq	0x7d14 <_stogir.types.size+0x2f4>
    7ca4:      	cmp	x7, #0xb
    7ca8:      	b.eq	0x7d14 <_stogir.types.size+0x2f4>
    7cac:      	cmp	x7, #0xc
    7cb0:      	b.eq	0x7d14 <_stogir.types.size+0x2f4>
    7cb4:      	cmp	x7, #0x6
    7cb8:      	b.eq	0x7cc0 <_stogir.types.size+0x2a0>
    7cbc:      	movn	x1, #0x0, lsl #48
    7cc0:      	b	0x7d18 <_stogir.types.size+0x2f8>
    7cc4:      	mov	x1, #0x2                ; =2
    7cc8:      	b	0x7b4c <_stogir.types.size+0x12c>
    7ccc:      	uxtb	w16, w10
    7cd0:      	cmp	w16, wzr
    7cd4:      	b.eq	0x7c2c <_stogir.types.size+0x20c>
    7cd8:      	uxtb	w16, w11
    7cdc:      	cmp	w16, wzr
    7ce0:      	b.eq	0x7c2c <_stogir.types.size+0x20c>
    7ce4:      	uxtb	w16, w3
    7ce8:      	cmp	w16, wzr
    7cec:      	cset	x0, eq
    7cf0:      	b	0x7c30 <_stogir.types.size+0x210>
    7cf4:      	mov	x1, #0x4                ; =4
    7cf8:      	b	0x7cc8 <_stogir.types.size+0x2a8>
    7cfc:      	mov	x1, #0x2                ; =2
    7d00:      	b	0x7bc8 <_stogir.types.size+0x1a8>
    7d04:      	mov	x1, #0x8                ; =8
    7d08:      	b	0x7cf8 <_stogir.types.size+0x2d8>
    7d0c:      	mov	x1, #0x4                ; =4
    7d10:      	b	0x7d00 <_stogir.types.size+0x2e0>
    7d14:      	mov	x1, #0x8                ; =8
    7d18:      	b	0x7d10 <_stogir.types.size+0x2f0>

0000000000007d1c <_stogir.checked.projection>:
    7d1c:      	sub	sp, sp, #0x40
    7d20:      	str	x29, [sp]
    7d24:      	str	x30, [sp, #0x8]
    7d28:      	mov	x29, sp
    7d2c:      	str	x19, [sp, #0x30]
    7d30:      	sxtw	x2, w1
    7d34:      	cmp	x2, #0x0
    7d38:      	cset	w3, gt
    7d3c:      	movz	x16, #0x0, lsl #48
    7d40:      	sub	x4, x16, x2
    7d44:      	sub	x5, x4, #0x1
    7d48:      	uxtb	w16, w3
    7d4c:      	cmp	w16, wzr
    7d50:      	b.eq	0x7d90 <_stogir.checked.projection+0x74>
    7d54:      	ldr	x4, [x0, #0x8]
    7d58:      	cmp	x2, x4
    7d5c:      	b.ge	0x7de0 <_stogir.checked.projection+0xc4>
    7d60:      	add	x4, x0, #0x78
    7d64:      	ldr	x4, [x4, #0x8]
    7d68:      	cmp	x2, x4
    7d6c:      	b.ge	0x7ee8 <_stogir.checked.projection+0x1cc>
    7d70:      	ldr	x4, [x0, #0x78]
    7d74:      	add	x4, x4, x2, lsl #2
    7d78:      	ldr	w4, [x4]
    7d7c:      	sxtw	x4, w4
    7d80:      	cmp	x4, #0x0
    7d84:      	cset	w4, ge
    7d88:      	ubfx	x4, x4, #0, #8
    7d8c:      	b	0x7eec <_stogir.checked.projection+0x1d0>
    7d90:      	cmp	x2, #0x0
    7d94:      	b.ge	0x7de8 <_stogir.checked.projection+0xcc>
    7d98:      	add	x6, x0, #0x28
    7d9c:      	add	x7, x0, #0x50
    7da0:      	ldr	x6, [x6, #0x8]
    7da4:      	ldr	x7, [x7, #0x8]
    7da8:      	cmp	x6, x7
    7dac:      	b.ne	0x7dd8 <_stogir.checked.projection+0xbc>
    7db0:      	cmp	x4, x6
    7db4:      	b.gt	0x7f18 <_stogir.checked.projection+0x1fc>
    7db8:      	ldr	x4, [x0, #0x50]
    7dbc:      	add	x4, x4, x5, lsl #2
    7dc0:      	ldr	w4, [x4]
    7dc4:      	sxtw	x4, w4
    7dc8:      	cmp	x4, #0x0
    7dcc:      	cset	w4, gt
    7dd0:      	ubfx	x4, x4, #0, #8
    7dd4:      	b	0x7f1c <_stogir.checked.projection+0x200>
    7dd8:      	movz	x4, #0x0, lsl #48
    7ddc:      	b	0x7dec <_stogir.checked.projection+0xd0>
    7de0:      	movz	x4, #0x0, lsl #48
    7de4:      	b	0x7dec <_stogir.checked.projection+0xd0>
    7de8:      	movz	x4, #0x0, lsl #48
    7dec:      	cmp	x4, #0x0
    7df0:      	b.eq	0x7e24 <_stogir.checked.projection+0x108>
    7df4:      	uxtb	w16, w3
    7df8:      	cmp	w16, wzr
    7dfc:      	b.eq	0x7e10 <_stogir.checked.projection+0xf4>
    7e00:      	ldr	x3, [x0]
    7e04:      	add	x2, x3, x2, lsl #4
    7e08:      	ldr	x2, [x2]
    7e0c:      	b	0x7e1c <_stogir.checked.projection+0x100>
    7e10:      	ldr	x2, [x0, #0x28]
    7e14:      	add	x2, x2, x5, lsl #4
    7e18:      	ldr	x2, [x2]
    7e1c:      	mov	x3, #0x1                ; =1
    7e20:      	b	0x7e2c <_stogir.checked.projection+0x110>
    7e24:      	movz	x3, #0x0, lsl #48
    7e28:      	movz	x2, #0x0, lsl #48
    7e2c:      	ubfx	x3, x3, #0, #32
    7e30:      	lsr	x16, x3, #0
    7e34:      	cmp	x16, #0x1
    7e38:      	b.eq	0x7e54 <_stogir.checked.projection+0x138>
    7e3c:      	b.lo	0x7e44 <_stogir.checked.projection+0x128>
    7e40:      	b	0x7e58 <_stogir.checked.projection+0x13c>
    7e44:      	cmp	x16, #0x0
    7e48:      	b.eq	0x7e50 <_stogir.checked.projection+0x134>
    7e4c:      	b	0x7e58 <_stogir.checked.projection+0x13c>
    7e50:      	b	0x7e5c <_stogir.checked.projection+0x140>
    7e54:      	b	0x7eac <_stogir.checked.projection+0x190>
    7e58:      	b	0x7f20 <_stogir.checked.projection+0x204>
    7e5c:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		0000000000007e5c:  ARM64_RELOC_PAGE21	l_stogir.428
    7e60:      	ldr	x16, [x16]
		0000000000007e60:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    7e64:      	orr	x0, x16, xzr
    7e68:      	mov	x19, x8
    7e6c:      	mov	x1, #0x1                ; =1
    7e70:      	mov	x2, #0x17               ; =23
    7e74:      	b	0x7e8c <_stogir.checked.projection+0x170>
    7e78:      	adrp	x16, 0x7000 <_stogir.vector-arithmetic.node?+0x1d0>
		0000000000007e78:  ARM64_RELOC_PAGE21	l_stogir.429
    7e7c:      	ldr	x16, [x16]
		0000000000007e7c:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    7e80:      	orr	x0, x16, xzr
    7e84:      	mov	x1, #0x1                ; =1
    7e88:      	mov	x2, #0x20               ; =32
    7e8c:      	str	x1, [x19]
    7e90:      	str	x0, [x19, #0x8]
    7e94:      	str	x2, [x19, #0x10]
    7e98:      	ldr	x19, [sp, #0x30]
    7e9c:      	ldr	x29, [sp]
    7ea0:      	ldr	x30, [sp, #0x8]
    7ea4:      	add	sp, sp, #0x40
    7ea8:      	ret
    7eac:      	uxtb	w3, w2
    7eb0:      	cmp	x3, #0x29
    7eb4:      	b.lt	0x7f28 <_stogir.checked.projection+0x20c>
    7eb8:      	cmp	x3, #0x2b
    7ebc:      	b.gt	0x7f30 <_stogir.checked.projection+0x214>
    7ec0:      	mov	x19, x8
    7ec4:      	add	x8, sp, #0x10
    7ec8:      	bl	0x7ec8 <_stogir.checked.projection+0x1ac>
		0000000000007ec8:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    7ecc:      	add	x16, sp, #0x10
    7ed0:      	ldr	x1, [x16]
    7ed4:      	add	x16, sp, #0x10
    7ed8:      	ldr	x0, [x16, #0x8]
    7edc:      	add	x16, sp, #0x10
    7ee0:      	ldr	x2, [x16, #0x10]
    7ee4:      	b	0x7e8c <_stogir.checked.projection+0x170>
    7ee8:      	movz	x4, #0x0, lsl #48
    7eec:      	b	0x7de4 <_stogir.checked.projection+0xc8>
    7ef0:      	ubfx	x2, x2, #0, #32
    7ef4:      	ubfx	x0, x2, #8, #8
    7ef8:      	cmp	x0, #0x0
    7efc:      	b.eq	0x7e78 <_stogir.checked.projection+0x15c>
    7f00:      	cmp	x0, #0xd
    7f04:      	b.gt	0x7e78 <_stogir.checked.projection+0x15c>
    7f08:      	movz	x1, #0x0, lsl #48
    7f0c:      	movz	x0, #0x0, lsl #48
    7f10:      	movz	x2, #0x0, lsl #48
    7f14:      	b	0x7e8c <_stogir.checked.projection+0x170>
    7f18:      	movz	x4, #0x0, lsl #48
    7f1c:      	b	0x7ddc <_stogir.checked.projection+0xc0>
    7f20:      	brk	#0
    7f24:      	b	0x7f20 <_stogir.checked.projection+0x204>
    7f28:      	mov	x19, x8
    7f2c:      	b	0x7ef0 <_stogir.checked.projection+0x1d4>
    7f30:      	mov	x19, x8
    7f34:      	b	0x7ef0 <_stogir.checked.projection+0x1d4>

0000000000007f38 <_stogir.atomic.ordinary?>:
    7f38:      	sxtw	x1, w1
    7f3c:      	cmp	x1, #0x0
    7f40:      	cset	w3, gt
    7f44:      	movz	x16, #0x0, lsl #48
    7f48:      	sub	x4, x16, x1
    7f4c:      	sub	x5, x4, #0x1
    7f50:      	uxtb	w16, w3
    7f54:      	cmp	w16, wzr
    7f58:      	b.eq	0x7f98 <_stogir.atomic.ordinary?+0x60>
    7f5c:      	ldr	x4, [x0, #0x8]
    7f60:      	cmp	x1, x4
    7f64:      	b.ge	0x7fe8 <_stogir.atomic.ordinary?+0xb0>
    7f68:      	add	x4, x0, #0x78
    7f6c:      	ldr	x4, [x4, #0x8]
    7f70:      	cmp	x1, x4
    7f74:      	b.ge	0x80a0 <_stogir.atomic.ordinary?+0x168>
    7f78:      	ldr	x4, [x0, #0x78]
    7f7c:      	add	x4, x4, x1, lsl #2
    7f80:      	ldr	w4, [x4]
    7f84:      	sxtw	x4, w4
    7f88:      	cmp	x4, #0x0
    7f8c:      	cset	w4, ge
    7f90:      	ubfx	x4, x4, #0, #8
    7f94:      	b	0x80a4 <_stogir.atomic.ordinary?+0x16c>
    7f98:      	cmp	x1, #0x0
    7f9c:      	b.ge	0x7ff0 <_stogir.atomic.ordinary?+0xb8>
    7fa0:      	add	x6, x0, #0x28
    7fa4:      	add	x7, x0, #0x50
    7fa8:      	ldr	x6, [x6, #0x8]
    7fac:      	ldr	x7, [x7, #0x8]
    7fb0:      	cmp	x6, x7
    7fb4:      	b.ne	0x7fe0 <_stogir.atomic.ordinary?+0xa8>
    7fb8:      	cmp	x4, x6
    7fbc:      	b.gt	0x80c0 <_stogir.atomic.ordinary?+0x188>
    7fc0:      	ldr	x4, [x0, #0x50]
    7fc4:      	add	x4, x4, x5, lsl #2
    7fc8:      	ldr	w4, [x4]
    7fcc:      	sxtw	x4, w4
    7fd0:      	cmp	x4, #0x0
    7fd4:      	cset	w4, gt
    7fd8:      	ubfx	x4, x4, #0, #8
    7fdc:      	b	0x80c4 <_stogir.atomic.ordinary?+0x18c>
    7fe0:      	movz	x4, #0x0, lsl #48
    7fe4:      	b	0x7ff4 <_stogir.atomic.ordinary?+0xbc>
    7fe8:      	movz	x4, #0x0, lsl #48
    7fec:      	b	0x7ff4 <_stogir.atomic.ordinary?+0xbc>
    7ff0:      	movz	x4, #0x0, lsl #48
    7ff4:      	cmp	x4, #0x0
    7ff8:      	b.eq	0x802c <_stogir.atomic.ordinary?+0xf4>
    7ffc:      	uxtb	w16, w3
    8000:      	cmp	w16, wzr
    8004:      	b.eq	0x8018 <_stogir.atomic.ordinary?+0xe0>
    8008:      	ldr	x0, [x0]
    800c:      	add	x0, x0, x1, lsl #4
    8010:      	ldr	x0, [x0]
    8014:      	b	0x8024 <_stogir.atomic.ordinary?+0xec>
    8018:      	ldr	x0, [x0, #0x28]
    801c:      	add	x0, x0, x5, lsl #4
    8020:      	ldr	x0, [x0]
    8024:      	mov	x1, #0x1                ; =1
    8028:      	b	0x8034 <_stogir.atomic.ordinary?+0xfc>
    802c:      	movz	x1, #0x0, lsl #48
    8030:      	movz	x0, #0x0, lsl #48
    8034:      	ubfx	x1, x1, #0, #32
    8038:      	lsr	x16, x1, #0
    803c:      	cmp	x16, #0x1
    8040:      	b.eq	0x805c <_stogir.atomic.ordinary?+0x124>
    8044:      	b.lo	0x804c <_stogir.atomic.ordinary?+0x114>
    8048:      	b	0x8060 <_stogir.atomic.ordinary?+0x128>
    804c:      	cmp	x16, #0x0
    8050:      	b.eq	0x8058 <_stogir.atomic.ordinary?+0x120>
    8054:      	b	0x8060 <_stogir.atomic.ordinary?+0x128>
    8058:      	b	0x8064 <_stogir.atomic.ordinary?+0x12c>
    805c:      	b	0x8074 <_stogir.atomic.ordinary?+0x13c>
    8060:      	b	0x80c8 <_stogir.atomic.ordinary?+0x190>
    8064:      	movz	x0, #0x0, lsl #48
    8068:      	b	0x8070 <_stogir.atomic.ordinary?+0x138>
    806c:      	movz	x0, #0x0, lsl #48
    8070:      	ret
    8074:      	sxtw	x2, w2
    8078:      	orr	w1, w0, wzr
    807c:      	ubfx	x1, x1, #0, #32
    8080:      	ubfx	x1, x1, #8, #8
    8084:      	cmp	x1, x2
    8088:      	b.ne	0x806c <_stogir.atomic.ordinary?+0x134>
    808c:      	uxtb	w0, w0
    8090:      	cmp	x0, #0x46
    8094:      	b.ne	0x80a8 <_stogir.atomic.ordinary?+0x170>
    8098:      	movz	x0, #0x0, lsl #48
    809c:      	b	0x80bc <_stogir.atomic.ordinary?+0x184>
    80a0:      	movz	x4, #0x0, lsl #48
    80a4:      	b	0x7fec <_stogir.atomic.ordinary?+0xb4>
    80a8:      	cmp	x0, #0x48
    80ac:      	cset	w0, eq
    80b0:      	uxtb	w16, w0
    80b4:      	cmp	w16, wzr
    80b8:      	cset	x0, eq
    80bc:      	b	0x8070 <_stogir.atomic.ordinary?+0x138>
    80c0:      	movz	x4, #0x0, lsl #48
    80c4:      	b	0x7fe4 <_stogir.atomic.ordinary?+0xac>
    80c8:      	brk	#0
    80cc:      	b	0x80c8 <_stogir.atomic.ordinary?+0x190>

00000000000080d0 <_stogir.types.scalar-size>:
    80d0:      	sxtw	x1, w1
    80d4:      	cmp	x1, #0x4
    80d8:      	b.eq	0x80ec <_stogir.types.scalar-size+0x1c>
    80dc:      	cmp	x1, #0x8
    80e0:      	b.eq	0x80ec <_stogir.types.scalar-size+0x1c>
    80e4:      	movn	x1, #0x0, lsl #48
    80e8:      	b	0x8104 <_stogir.types.scalar-size+0x34>
    80ec:      	sxtw	x0, w0
    80f0:      	cmp	x0, #0x0
    80f4:      	b.ne	0x810c <_stogir.types.scalar-size+0x3c>
    80f8:      	movz	x1, #0x0, lsl #48
    80fc:      	b	0x8104 <_stogir.types.scalar-size+0x34>
    8100:      	mov	x1, #0x1                ; =1
    8104:      	mov	x0, x1
    8108:      	ret
    810c:      	cmp	x0, #0x1
    8110:      	b.eq	0x8100 <_stogir.types.scalar-size+0x30>
    8114:      	cmp	x0, #0x2
    8118:      	b.eq	0x8100 <_stogir.types.scalar-size+0x30>
    811c:      	cmp	x0, #0x7
    8120:      	b.eq	0x8100 <_stogir.types.scalar-size+0x30>
    8124:      	cmp	x0, #0x8
    8128:      	b.eq	0x8100 <_stogir.types.scalar-size+0x30>
    812c:      	cmp	x0, #0x3
    8130:      	b.eq	0x817c <_stogir.types.scalar-size+0xac>
    8134:      	cmp	x0, #0x9
    8138:      	b.eq	0x817c <_stogir.types.scalar-size+0xac>
    813c:      	cmp	x0, #0x4
    8140:      	b.eq	0x8184 <_stogir.types.scalar-size+0xb4>
    8144:      	cmp	x0, #0xa
    8148:      	b.eq	0x8184 <_stogir.types.scalar-size+0xb4>
    814c:      	cmp	x0, #0xd
    8150:      	b.eq	0x8184 <_stogir.types.scalar-size+0xb4>
    8154:      	cmp	x0, #0x5
    8158:      	b.eq	0x818c <_stogir.types.scalar-size+0xbc>
    815c:      	cmp	x0, #0xb
    8160:      	b.eq	0x818c <_stogir.types.scalar-size+0xbc>
    8164:      	cmp	x0, #0xc
    8168:      	b.eq	0x818c <_stogir.types.scalar-size+0xbc>
    816c:      	cmp	x0, #0x6
    8170:      	b.eq	0x8178 <_stogir.types.scalar-size+0xa8>
    8174:      	movn	x1, #0x0, lsl #48
    8178:      	b	0x8190 <_stogir.types.scalar-size+0xc0>
    817c:      	mov	x1, #0x2                ; =2
    8180:      	b	0x8104 <_stogir.types.scalar-size+0x34>
    8184:      	mov	x1, #0x4                ; =4
    8188:      	b	0x8180 <_stogir.types.scalar-size+0xb0>
    818c:      	mov	x1, #0x8                ; =8
    8190:      	b	0x8188 <_stogir.types.scalar-size+0xb8>

0000000000008194 <_stogir.terminal.inputs>:
    8194:      	sxtw	x1, w1
    8198:      	cmp	x1, #0x60
    819c:      	cset	w4, eq
    81a0:      	uxtb	w16, w4
    81a4:      	cmp	w16, wzr
    81a8:      	b.ne	0x81d8 <_stogir.terminal.inputs+0x44>
    81ac:      	cmp	x1, #0x79
    81b0:      	b.eq	0x81d8 <_stogir.terminal.inputs+0x44>
    81b4:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		00000000000081b4:  ARM64_RELOC_PAGE21	l_stogir.430
    81b8:      	ldr	x16, [x16]
		00000000000081b8:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    81bc:      	orr	x0, x16, xzr
    81c0:      	mov	x1, #0x1                ; =1
    81c4:      	mov	x2, #0x25               ; =37
    81c8:      	str	x1, [x8]
    81cc:      	str	x0, [x8, #0x8]
    81d0:      	str	x2, [x8, #0x10]
    81d4:      	ret
    81d8:      	sxtw	x3, w3
    81dc:      	uxtb	w16, w4
    81e0:      	cmp	w16, wzr
    81e4:      	b.eq	0x81f0 <_stogir.terminal.inputs+0x5c>
    81e8:      	cmp	x3, #0x0
    81ec:      	b.ne	0x81b4 <_stogir.terminal.inputs+0x20>
    81f0:      	sxtw	x2, w2
    81f4:      	cmp	x2, #0x0
    81f8:      	cset	w1, gt
    81fc:      	movz	x16, #0x0, lsl #48
    8200:      	sub	x4, x16, x2
    8204:      	sub	x5, x4, #0x1
    8208:      	uxtb	w16, w1
    820c:      	cmp	w16, wzr
    8210:      	b.eq	0x82e4 <_stogir.terminal.inputs+0x150>
    8214:      	ldr	x4, [x0, #0x8]
    8218:      	cmp	x2, x4
    821c:      	b.ge	0x82dc <_stogir.terminal.inputs+0x148>
    8220:      	add	x4, x0, #0x78
    8224:      	ldr	x4, [x4, #0x8]
    8228:      	cmp	x2, x4
    822c:      	b.ge	0x8384 <_stogir.terminal.inputs+0x1f0>
    8230:      	ldr	x4, [x0, #0x78]
    8234:      	add	x4, x4, x2, lsl #2
    8238:      	ldr	w4, [x4]
    823c:      	sxtw	x4, w4
    8240:      	cmp	x4, #0x0
    8244:      	cset	w4, ge
    8248:      	ubfx	x4, x4, #0, #8
    824c:      	b	0x8388 <_stogir.terminal.inputs+0x1f4>
    8250:      	movz	x4, #0x0, lsl #48
    8254:      	movz	x1, #0x0, lsl #48
    8258:      	ubfx	x4, x4, #0, #32
    825c:      	lsr	x16, x4, #0
    8260:      	cmp	x16, #0x1
    8264:      	b.eq	0x8280 <_stogir.terminal.inputs+0xec>
    8268:      	b.lo	0x8270 <_stogir.terminal.inputs+0xdc>
    826c:      	b	0x8284 <_stogir.terminal.inputs+0xf0>
    8270:      	cmp	x16, #0x0
    8274:      	b.eq	0x827c <_stogir.terminal.inputs+0xe8>
    8278:      	b	0x8284 <_stogir.terminal.inputs+0xf0>
    827c:      	b	0x8288 <_stogir.terminal.inputs+0xf4>
    8280:      	b	0x832c <_stogir.terminal.inputs+0x198>
    8284:      	b	0x84d0 <_stogir.terminal.inputs+0x33c>
    8288:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008288:  ARM64_RELOC_PAGE21	l_stogir.431
    828c:      	ldr	x16, [x16]
		000000000000828c:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    8290:      	orr	x0, x16, xzr
    8294:      	mov	x1, #0x1                ; =1
    8298:      	mov	x2, #0x1d               ; =29
    829c:      	b	0x81c8 <_stogir.terminal.inputs+0x34>
    82a0:      	ldr	x1, [x0, #0x28]
    82a4:      	add	x1, x1, x5, lsl #4
    82a8:      	ldr	x1, [x1]
    82ac:      	mov	x4, #0x1                ; =1
    82b0:      	b	0x8258 <_stogir.terminal.inputs+0xc4>
    82b4:      	movz	x4, #0x0, lsl #48
    82b8:      	cmp	x4, #0x0
    82bc:      	b.eq	0x8250 <_stogir.terminal.inputs+0xbc>
    82c0:      	uxtb	w16, w1
    82c4:      	cmp	w16, wzr
    82c8:      	b.eq	0x82a0 <_stogir.terminal.inputs+0x10c>
    82cc:      	ldr	x1, [x0]
    82d0:      	add	x1, x1, x2, lsl #4
    82d4:      	ldr	x1, [x1]
    82d8:      	b	0x82ac <_stogir.terminal.inputs+0x118>
    82dc:      	movz	x4, #0x0, lsl #48
    82e0:      	b	0x82b8 <_stogir.terminal.inputs+0x124>
    82e4:      	cmp	x2, #0x0
    82e8:      	b.ge	0x82b4 <_stogir.terminal.inputs+0x120>
    82ec:      	add	x6, x0, #0x28
    82f0:      	add	x7, x0, #0x50
    82f4:      	ldr	x6, [x6, #0x8]
    82f8:      	ldr	x7, [x7, #0x8]
    82fc:      	cmp	x6, x7
    8300:      	b.ne	0x837c <_stogir.terminal.inputs+0x1e8>
    8304:      	cmp	x4, x6
    8308:      	b.gt	0x838c <_stogir.terminal.inputs+0x1f8>
    830c:      	ldr	x4, [x0, #0x50]
    8310:      	add	x4, x4, x5, lsl #2
    8314:      	ldr	w4, [x4]
    8318:      	sxtw	x4, w4
    831c:      	cmp	x4, #0x0
    8320:      	cset	w4, gt
    8324:      	ubfx	x4, x4, #0, #8
    8328:      	b	0x8390 <_stogir.terminal.inputs+0x1fc>
    832c:      	cmp	x2, #0x0
    8330:      	b.le	0x8364 <_stogir.terminal.inputs+0x1d0>
    8334:      	uxtb	w1, w1
    8338:      	cmp	x1, #0x83
    833c:      	cset	w2, lt
    8340:      	uxtb	w16, w2
    8344:      	cmp	w16, wzr
    8348:      	b.eq	0x8394 <_stogir.terminal.inputs+0x200>
    834c:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		000000000000834c:  ARM64_RELOC_PAGE21	l_stogir.432
    8350:      	ldr	x16, [x16]
		0000000000008350:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    8354:      	orr	x4, x16, xzr
    8358:      	add	x4, x1, x4
    835c:      	ldrb	w4, [x4]
    8360:      	b	0x8398 <_stogir.terminal.inputs+0x204>
    8364:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008364:  ARM64_RELOC_PAGE21	l_stogir.433
    8368:      	ldr	x16, [x16]
		0000000000008368:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    836c:      	orr	x0, x16, xzr
    8370:      	mov	x1, #0x1                ; =1
    8374:      	mov	x2, #0x2c               ; =44
    8378:      	b	0x829c <_stogir.terminal.inputs+0x108>
    837c:      	movz	x4, #0x0, lsl #48
    8380:      	b	0x82b8 <_stogir.terminal.inputs+0x124>
    8384:      	movz	x4, #0x0, lsl #48
    8388:      	b	0x82e0 <_stogir.terminal.inputs+0x14c>
    838c:      	movz	x4, #0x0, lsl #48
    8390:      	b	0x8380 <_stogir.terminal.inputs+0x1ec>
    8394:      	movz	x4, #0x0, lsl #48
    8398:      	uxtb	w4, w4
    839c:      	and	x4, x4, #0x1
    83a0:      	uxtb	w4, w4
    83a4:      	cmp	x4, #0x0
    83a8:      	b.eq	0x8364 <_stogir.terminal.inputs+0x1d0>
    83ac:      	uxtb	w16, w2
    83b0:      	cmp	w16, wzr
    83b4:      	b.eq	0x83d0 <_stogir.terminal.inputs+0x23c>
    83b8:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		00000000000083b8:  ARM64_RELOC_PAGE21	l_stogir.432
    83bc:      	ldr	x16, [x16]
		00000000000083bc:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    83c0:      	orr	x2, x16, xzr
    83c4:      	add	x1, x1, x2
    83c8:      	ldrb	w1, [x1]
    83cc:      	b	0x83d4 <_stogir.terminal.inputs+0x240>
    83d0:      	movz	x1, #0x0, lsl #48
    83d4:      	uxtb	w1, w1
    83d8:      	and	x1, x1, #0x4
    83dc:      	uxtb	w1, w1
    83e0:      	cmp	x1, #0x0
    83e4:      	cset	w1, eq
    83e8:      	uxtb	w16, w1
    83ec:      	cmp	w16, wzr
    83f0:      	cset	x1, eq
    83f4:      	cmp	x1, #0x0
    83f8:      	b.ne	0x8364 <_stogir.terminal.inputs+0x1d0>
    83fc:      	cmp	x3, #0x0
    8400:      	b.ne	0x8414 <_stogir.terminal.inputs+0x280>
    8404:      	movz	x1, #0x0, lsl #48
    8408:      	movz	x0, #0x0, lsl #48
    840c:      	movz	x2, #0x0, lsl #48
    8410:      	b	0x8378 <_stogir.terminal.inputs+0x1e4>
    8414:      	cmp	x3, #0x0
    8418:      	cset	w1, gt
    841c:      	movz	x16, #0x0, lsl #48
    8420:      	sub	x2, x16, x3
    8424:      	sub	x4, x2, #0x1
    8428:      	uxtb	w16, w1
    842c:      	cmp	w16, wzr
    8430:      	b.eq	0x8488 <_stogir.terminal.inputs+0x2f4>
    8434:      	ldr	x2, [x0, #0x8]
    8438:      	cmp	x3, x2
    843c:      	b.ge	0x84d8 <_stogir.terminal.inputs+0x344>
    8440:      	add	x2, x0, #0x78
    8444:      	ldr	x2, [x2, #0x8]
    8448:      	cmp	x3, x2
    844c:      	b.ge	0x85a0 <_stogir.terminal.inputs+0x40c>
    8450:      	ldr	x2, [x0, #0x78]
    8454:      	add	x2, x2, x3, lsl #2
    8458:      	ldr	w2, [x2]
    845c:      	sxtw	x2, w2
    8460:      	cmp	x2, #0x0
    8464:      	cset	w2, ge
    8468:      	ubfx	x2, x2, #0, #8
    846c:      	b	0x85a4 <_stogir.terminal.inputs+0x410>
    8470:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008470:  ARM64_RELOC_PAGE21	l_stogir.434
    8474:      	ldr	x16, [x16]
		0000000000008474:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    8478:      	orr	x0, x16, xzr
    847c:      	mov	x1, #0x1                ; =1
    8480:      	mov	x2, #0x2e               ; =46
    8484:      	b	0x8410 <_stogir.terminal.inputs+0x27c>
    8488:      	cmp	x3, #0x0
    848c:      	b.ge	0x84e0 <_stogir.terminal.inputs+0x34c>
    8490:      	add	x5, x0, #0x28
    8494:      	add	x6, x0, #0x50
    8498:      	ldr	x5, [x5, #0x8]
    849c:      	ldr	x6, [x6, #0x8]
    84a0:      	cmp	x5, x6
    84a4:      	b.ne	0x8598 <_stogir.terminal.inputs+0x404>
    84a8:      	cmp	x2, x5
    84ac:      	b.gt	0x85a8 <_stogir.terminal.inputs+0x414>
    84b0:      	ldr	x2, [x0, #0x50]
    84b4:      	add	x2, x2, x4, lsl #2
    84b8:      	ldr	w2, [x2]
    84bc:      	sxtw	x2, w2
    84c0:      	cmp	x2, #0x0
    84c4:      	cset	w2, gt
    84c8:      	ubfx	x2, x2, #0, #8
    84cc:      	b	0x85ac <_stogir.terminal.inputs+0x418>
    84d0:      	brk	#0
    84d4:      	b	0x84d0 <_stogir.terminal.inputs+0x33c>
    84d8:      	movz	x2, #0x0, lsl #48
    84dc:      	b	0x84e4 <_stogir.terminal.inputs+0x350>
    84e0:      	movz	x2, #0x0, lsl #48
    84e4:      	cmp	x2, #0x0
    84e8:      	b.eq	0x851c <_stogir.terminal.inputs+0x388>
    84ec:      	uxtb	w16, w1
    84f0:      	cmp	w16, wzr
    84f4:      	b.eq	0x8508 <_stogir.terminal.inputs+0x374>
    84f8:      	ldr	x0, [x0]
    84fc:      	add	x0, x0, x3, lsl #4
    8500:      	ldr	x0, [x0]
    8504:      	b	0x8514 <_stogir.terminal.inputs+0x380>
    8508:      	ldr	x0, [x0, #0x28]
    850c:      	add	x0, x0, x4, lsl #4
    8510:      	ldr	x0, [x0]
    8514:      	mov	x1, #0x1                ; =1
    8518:      	b	0x8524 <_stogir.terminal.inputs+0x390>
    851c:      	movz	x1, #0x0, lsl #48
    8520:      	movz	x0, #0x0, lsl #48
    8524:      	ubfx	x1, x1, #0, #32
    8528:      	lsr	x16, x1, #0
    852c:      	cmp	x16, #0x1
    8530:      	b.eq	0x854c <_stogir.terminal.inputs+0x3b8>
    8534:      	b.lo	0x853c <_stogir.terminal.inputs+0x3a8>
    8538:      	b	0x8550 <_stogir.terminal.inputs+0x3bc>
    853c:      	cmp	x16, #0x0
    8540:      	b.eq	0x8548 <_stogir.terminal.inputs+0x3b4>
    8544:      	b	0x8550 <_stogir.terminal.inputs+0x3bc>
    8548:      	b	0x8554 <_stogir.terminal.inputs+0x3c0>
    854c:      	b	0x856c <_stogir.terminal.inputs+0x3d8>
    8550:      	b	0x85ec <_stogir.terminal.inputs+0x458>
    8554:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008554:  ARM64_RELOC_PAGE21	l_stogir.435
    8558:      	ldr	x16, [x16]
		0000000000008558:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    855c:      	orr	x0, x16, xzr
    8560:      	mov	x1, #0x1                ; =1
    8564:      	mov	x2, #0x1d               ; =29
    8568:      	b	0x8484 <_stogir.terminal.inputs+0x2f0>
    856c:      	cmp	x3, #0x0
    8570:      	b.le	0x8470 <_stogir.terminal.inputs+0x2dc>
    8574:      	uxtb	w0, w0
    8578:      	cmp	x0, #0x83
    857c:      	b.ge	0x85b0 <_stogir.terminal.inputs+0x41c>
    8580:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008580:  ARM64_RELOC_PAGE21	l_stogir.432
    8584:      	ldr	x16, [x16]
		0000000000008584:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    8588:      	orr	x1, x16, xzr
    858c:      	add	x0, x0, x1
    8590:      	ldrb	w0, [x0]
    8594:      	b	0x85b4 <_stogir.terminal.inputs+0x420>
    8598:      	movz	x2, #0x0, lsl #48
    859c:      	b	0x84e4 <_stogir.terminal.inputs+0x350>
    85a0:      	movz	x2, #0x0, lsl #48
    85a4:      	b	0x84dc <_stogir.terminal.inputs+0x348>
    85a8:      	movz	x2, #0x0, lsl #48
    85ac:      	b	0x859c <_stogir.terminal.inputs+0x408>
    85b0:      	movz	x0, #0x0, lsl #48
    85b4:      	uxtb	w0, w0
    85b8:      	and	x0, x0, #0x8
    85bc:      	uxtb	w0, w0
    85c0:      	cmp	x0, #0x0
    85c4:      	cset	w0, eq
    85c8:      	uxtb	w16, w0
    85cc:      	cmp	w16, wzr
    85d0:      	cset	x0, eq
    85d4:      	cmp	x0, #0x0
    85d8:      	b.eq	0x8470 <_stogir.terminal.inputs+0x2dc>
    85dc:      	and	x0, x3, #0xffffffff
    85e0:      	movz	x1, #0x0, lsl #48
    85e4:      	movz	x2, #0x0, lsl #48
    85e8:      	b	0x8484 <_stogir.terminal.inputs+0x2f0>
    85ec:      	brk	#0
    85f0:      	b	0x85ec <_stogir.terminal.inputs+0x458>

00000000000085f4 <_stogir.switch.switch-inputs>:
    85f4:      	sxtw	x1, w1
    85f8:      	cmp	x1, #0x0
    85fc:      	cset	w3, gt
    8600:      	movz	x16, #0x0, lsl #48
    8604:      	sub	x4, x16, x1
    8608:      	sub	x5, x4, #0x1
    860c:      	uxtb	w16, w3
    8610:      	cmp	w16, wzr
    8614:      	b.eq	0x8654 <_stogir.switch.switch-inputs+0x60>
    8618:      	ldr	x4, [x0, #0x8]
    861c:      	cmp	x1, x4
    8620:      	b.ge	0x86bc <_stogir.switch.switch-inputs+0xc8>
    8624:      	add	x4, x0, #0x78
    8628:      	ldr	x4, [x4, #0x8]
    862c:      	cmp	x1, x4
    8630:      	b.ge	0x8794 <_stogir.switch.switch-inputs+0x1a0>
    8634:      	ldr	x4, [x0, #0x78]
    8638:      	add	x4, x4, x1, lsl #2
    863c:      	ldr	w4, [x4]
    8640:      	sxtw	x4, w4
    8644:      	cmp	x4, #0x0
    8648:      	cset	w4, ge
    864c:      	ubfx	x4, x4, #0, #8
    8650:      	b	0x8798 <_stogir.switch.switch-inputs+0x1a4>
    8654:      	cmp	x1, #0x0
    8658:      	b.ge	0x86c4 <_stogir.switch.switch-inputs+0xd0>
    865c:      	add	x6, x0, #0x28
    8660:      	add	x7, x0, #0x50
    8664:      	ldr	x6, [x6, #0x8]
    8668:      	ldr	x7, [x7, #0x8]
    866c:      	cmp	x6, x7
    8670:      	b.ne	0x869c <_stogir.switch.switch-inputs+0xa8>
    8674:      	cmp	x4, x6
    8678:      	b.gt	0x879c <_stogir.switch.switch-inputs+0x1a8>
    867c:      	ldr	x4, [x0, #0x50]
    8680:      	add	x4, x4, x5, lsl #2
    8684:      	ldr	w4, [x4]
    8688:      	sxtw	x4, w4
    868c:      	cmp	x4, #0x0
    8690:      	cset	w4, gt
    8694:      	ubfx	x4, x4, #0, #8
    8698:      	b	0x87a0 <_stogir.switch.switch-inputs+0x1ac>
    869c:      	movz	x4, #0x0, lsl #48
    86a0:      	b	0x86c8 <_stogir.switch.switch-inputs+0xd4>
    86a4:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		00000000000086a4:  ARM64_RELOC_PAGE21	l_stogir.436
    86a8:      	ldr	x16, [x16]
		00000000000086a8:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    86ac:      	orr	x0, x16, xzr
    86b0:      	mov	x1, #0x1                ; =1
    86b4:      	mov	x2, #0x16               ; =22
    86b8:      	b	0x874c <_stogir.switch.switch-inputs+0x158>
    86bc:      	movz	x4, #0x0, lsl #48
    86c0:      	b	0x86c8 <_stogir.switch.switch-inputs+0xd4>
    86c4:      	movz	x4, #0x0, lsl #48
    86c8:      	cmp	x4, #0x0
    86cc:      	b.eq	0x8700 <_stogir.switch.switch-inputs+0x10c>
    86d0:      	uxtb	w16, w3
    86d4:      	cmp	w16, wzr
    86d8:      	b.eq	0x86ec <_stogir.switch.switch-inputs+0xf8>
    86dc:      	ldr	x3, [x0]
    86e0:      	add	x3, x3, x1, lsl #4
    86e4:      	ldr	x3, [x3]
    86e8:      	b	0x86f8 <_stogir.switch.switch-inputs+0x104>
    86ec:      	ldr	x3, [x0, #0x28]
    86f0:      	add	x3, x3, x5, lsl #4
    86f4:      	ldr	x3, [x3]
    86f8:      	mov	x4, #0x1                ; =1
    86fc:      	b	0x8708 <_stogir.switch.switch-inputs+0x114>
    8700:      	movz	x4, #0x0, lsl #48
    8704:      	movz	x3, #0x0, lsl #48
    8708:      	ubfx	x4, x4, #0, #32
    870c:      	lsr	x16, x4, #0
    8710:      	cmp	x16, #0x1
    8714:      	b.eq	0x8730 <_stogir.switch.switch-inputs+0x13c>
    8718:      	b.lo	0x8720 <_stogir.switch.switch-inputs+0x12c>
    871c:      	b	0x8734 <_stogir.switch.switch-inputs+0x140>
    8720:      	cmp	x16, #0x0
    8724:      	b.eq	0x872c <_stogir.switch.switch-inputs+0x138>
    8728:      	b	0x8734 <_stogir.switch.switch-inputs+0x140>
    872c:      	b	0x8738 <_stogir.switch.switch-inputs+0x144>
    8730:      	b	0x875c <_stogir.switch.switch-inputs+0x168>
    8734:      	b	0x89a8 <_stogir.switch.switch-inputs+0x3b4>
    8738:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008738:  ARM64_RELOC_PAGE21	l_stogir.437
    873c:      	ldr	x16, [x16]
		000000000000873c:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    8740:      	orr	x0, x16, xzr
    8744:      	mov	x1, #0x1                ; =1
    8748:      	mov	x2, #0x16               ; =22
    874c:      	str	x1, [x8]
    8750:      	str	x0, [x8, #0x8]
    8754:      	str	x2, [x8, #0x10]
    8758:      	ret
    875c:      	cmp	x1, #0x0
    8760:      	b.le	0x86a4 <_stogir.switch.switch-inputs+0xb0>
    8764:      	uxtb	w3, w3
    8768:      	cmp	x3, #0x83
    876c:      	cset	w1, lt
    8770:      	uxtb	w16, w1
    8774:      	cmp	w16, wzr
    8778:      	b.eq	0x87a4 <_stogir.switch.switch-inputs+0x1b0>
    877c:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		000000000000877c:  ARM64_RELOC_PAGE21	l_stogir.438
    8780:      	ldr	x16, [x16]
		0000000000008780:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    8784:      	orr	x4, x16, xzr
    8788:      	add	x4, x3, x4
    878c:      	ldrb	w4, [x4]
    8790:      	b	0x87a8 <_stogir.switch.switch-inputs+0x1b4>
    8794:      	movz	x4, #0x0, lsl #48
    8798:      	b	0x86c0 <_stogir.switch.switch-inputs+0xcc>
    879c:      	movz	x4, #0x0, lsl #48
    87a0:      	b	0x86a0 <_stogir.switch.switch-inputs+0xac>
    87a4:      	movz	x4, #0x0, lsl #48
    87a8:      	uxtb	w4, w4
    87ac:      	and	x4, x4, #0x1
    87b0:      	uxtb	w4, w4
    87b4:      	cmp	x4, #0x0
    87b8:      	b.eq	0x86a4 <_stogir.switch.switch-inputs+0xb0>
    87bc:      	uxtb	w16, w1
    87c0:      	cmp	w16, wzr
    87c4:      	b.eq	0x87e0 <_stogir.switch.switch-inputs+0x1ec>
    87c8:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		00000000000087c8:  ARM64_RELOC_PAGE21	l_stogir.438
    87cc:      	ldr	x16, [x16]
		00000000000087cc:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    87d0:      	orr	x1, x16, xzr
    87d4:      	add	x1, x3, x1
    87d8:      	ldrb	w1, [x1]
    87dc:      	b	0x87e4 <_stogir.switch.switch-inputs+0x1f0>
    87e0:      	movz	x1, #0x0, lsl #48
    87e4:      	uxtb	w1, w1
    87e8:      	and	x1, x1, #0x4
    87ec:      	uxtb	w1, w1
    87f0:      	cmp	x1, #0x0
    87f4:      	cset	w1, eq
    87f8:      	uxtb	w16, w1
    87fc:      	cmp	w16, wzr
    8800:      	cset	x1, eq
    8804:      	cmp	x1, #0x0
    8808:      	b.ne	0x86a4 <_stogir.switch.switch-inputs+0xb0>
    880c:      	sxtw	x2, w2
    8810:      	cmp	x2, #0x0
    8814:      	cset	w1, gt
    8818:      	movz	x16, #0x0, lsl #48
    881c:      	sub	x3, x16, x2
    8820:      	sub	x4, x3, #0x1
    8824:      	uxtb	w16, w1
    8828:      	cmp	w16, wzr
    882c:      	b.eq	0x8884 <_stogir.switch.switch-inputs+0x290>
    8830:      	ldr	x3, [x0, #0x8]
    8834:      	cmp	x2, x3
    8838:      	b.ge	0x88cc <_stogir.switch.switch-inputs+0x2d8>
    883c:      	add	x3, x0, #0x78
    8840:      	ldr	x3, [x3, #0x8]
    8844:      	cmp	x2, x3
    8848:      	b.ge	0x89a0 <_stogir.switch.switch-inputs+0x3ac>
    884c:      	ldr	x3, [x0, #0x78]
    8850:      	add	x3, x3, x2, lsl #2
    8854:      	ldr	w3, [x3]
    8858:      	sxtw	x3, w3
    885c:      	cmp	x3, #0x0
    8860:      	cset	w3, ge
    8864:      	ubfx	x3, x3, #0, #8
    8868:      	b	0x89a4 <_stogir.switch.switch-inputs+0x3b0>
    886c:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		000000000000886c:  ARM64_RELOC_PAGE21	l_stogir.439
    8870:      	ldr	x16, [x16]
		0000000000008870:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    8874:      	orr	x0, x16, xzr
    8878:      	mov	x1, #0x1                ; =1
    887c:      	mov	x2, #0x20               ; =32
    8880:      	b	0x86b8 <_stogir.switch.switch-inputs+0xc4>
    8884:      	cmp	x2, #0x0
    8888:      	b.ge	0x88d4 <_stogir.switch.switch-inputs+0x2e0>
    888c:      	add	x5, x0, #0x28
    8890:      	add	x6, x0, #0x50
    8894:      	ldr	x5, [x5, #0x8]
    8898:      	ldr	x6, [x6, #0x8]
    889c:      	cmp	x5, x6
    88a0:      	b.ne	0x8998 <_stogir.switch.switch-inputs+0x3a4>
    88a4:      	cmp	x3, x5
    88a8:      	b.gt	0x89b0 <_stogir.switch.switch-inputs+0x3bc>
    88ac:      	ldr	x3, [x0, #0x50]
    88b0:      	add	x3, x3, x4, lsl #2
    88b4:      	ldr	w3, [x3]
    88b8:      	sxtw	x3, w3
    88bc:      	cmp	x3, #0x0
    88c0:      	cset	w3, gt
    88c4:      	ubfx	x3, x3, #0, #8
    88c8:      	b	0x89b4 <_stogir.switch.switch-inputs+0x3c0>
    88cc:      	movz	x3, #0x0, lsl #48
    88d0:      	b	0x88d8 <_stogir.switch.switch-inputs+0x2e4>
    88d4:      	movz	x3, #0x0, lsl #48
    88d8:      	cmp	x3, #0x0
    88dc:      	b.eq	0x8910 <_stogir.switch.switch-inputs+0x31c>
    88e0:      	uxtb	w16, w1
    88e4:      	cmp	w16, wzr
    88e8:      	b.eq	0x88fc <_stogir.switch.switch-inputs+0x308>
    88ec:      	ldr	x0, [x0]
    88f0:      	add	x0, x0, x2, lsl #4
    88f4:      	ldr	x0, [x0]
    88f8:      	b	0x8908 <_stogir.switch.switch-inputs+0x314>
    88fc:      	ldr	x0, [x0, #0x28]
    8900:      	add	x0, x0, x4, lsl #4
    8904:      	ldr	x0, [x0]
    8908:      	mov	x1, #0x1                ; =1
    890c:      	b	0x8918 <_stogir.switch.switch-inputs+0x324>
    8910:      	movz	x1, #0x0, lsl #48
    8914:      	movz	x0, #0x0, lsl #48
    8918:      	ubfx	x1, x1, #0, #32
    891c:      	lsr	x16, x1, #0
    8920:      	cmp	x16, #0x1
    8924:      	b.eq	0x8940 <_stogir.switch.switch-inputs+0x34c>
    8928:      	b.lo	0x8930 <_stogir.switch.switch-inputs+0x33c>
    892c:      	b	0x8944 <_stogir.switch.switch-inputs+0x350>
    8930:      	cmp	x16, #0x0
    8934:      	b.eq	0x893c <_stogir.switch.switch-inputs+0x348>
    8938:      	b	0x8944 <_stogir.switch.switch-inputs+0x350>
    893c:      	b	0x8948 <_stogir.switch.switch-inputs+0x354>
    8940:      	b	0x8960 <_stogir.switch.switch-inputs+0x36c>
    8944:      	b	0x89b8 <_stogir.switch.switch-inputs+0x3c4>
    8948:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008948:  ARM64_RELOC_PAGE21	l_stogir.440
    894c:      	ldr	x16, [x16]
		000000000000894c:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    8950:      	orr	x0, x16, xzr
    8954:      	mov	x1, #0x1                ; =1
    8958:      	mov	x2, #0x17               ; =23
    895c:      	b	0x8880 <_stogir.switch.switch-inputs+0x28c>
    8960:      	orr	w1, w0, wzr
    8964:      	ubfx	x1, x1, #0, #32
    8968:      	ubfx	x1, x1, #8, #8
    896c:      	cmp	x1, #0x1
    8970:      	b.lt	0x886c <_stogir.switch.switch-inputs+0x278>
    8974:      	cmp	x1, #0xb
    8978:      	b.gt	0x886c <_stogir.switch.switch-inputs+0x278>
    897c:      	uxtb	w0, w0
    8980:      	cmp	x0, #0x48
    8984:      	b.eq	0x886c <_stogir.switch.switch-inputs+0x278>
    8988:      	and	x0, x1, #0xffffffff
    898c:      	movz	x1, #0x0, lsl #48
    8990:      	movz	x2, #0x0, lsl #48
    8994:      	b	0x8880 <_stogir.switch.switch-inputs+0x28c>
    8998:      	movz	x3, #0x0, lsl #48
    899c:      	b	0x88d8 <_stogir.switch.switch-inputs+0x2e4>
    89a0:      	movz	x3, #0x0, lsl #48
    89a4:      	b	0x88d0 <_stogir.switch.switch-inputs+0x2dc>
    89a8:      	brk	#0
    89ac:      	b	0x89a8 <_stogir.switch.switch-inputs+0x3b4>
    89b0:      	movz	x3, #0x0, lsl #48
    89b4:      	b	0x899c <_stogir.switch.switch-inputs+0x3a8>
    89b8:      	brk	#0
    89bc:      	b	0x89b8 <_stogir.switch.switch-inputs+0x3c4>

00000000000089c0 <_stogir.switch.case-inputs>:
    89c0:      	sub	sp, sp, #0xb0
    89c4:      	str	x29, [sp]
    89c8:      	str	x30, [sp, #0x8]
    89cc:      	mov	x29, sp
    89d0:      	str	x19, [sp, #0x70]
    89d4:      	str	x20, [sp, #0x78]
    89d8:      	str	x21, [sp, #0x80]
    89dc:      	str	x22, [sp, #0x88]
    89e0:      	str	x23, [sp, #0x90]
    89e4:      	str	x24, [sp, #0x98]
    89e8:      	str	x25, [sp, #0xa0]
    89ec:      	str	x26, [sp, #0xa8]
    89f0:      	sxtw	x2, w2
    89f4:      	lsl	x5, x2, #2
    89f8:      	cmp	x2, #0x0
    89fc:      	cset	w6, gt
    8a00:      	movz	x16, #0x0, lsl #48
    8a04:      	sub	x7, x16, x2
    8a08:      	sub	x9, x7, #0x1
    8a0c:      	uxtb	w16, w6
    8a10:      	cmp	w16, wzr
    8a14:      	b.eq	0x8a54 <_stogir.switch.case-inputs+0x94>
    8a18:      	ldr	x7, [x0, #0x8]
    8a1c:      	cmp	x2, x7
    8a20:      	b.ge	0x8aa4 <_stogir.switch.case-inputs+0xe4>
    8a24:      	add	x7, x0, #0x78
    8a28:      	ldr	x7, [x7, #0x8]
    8a2c:      	cmp	x2, x7
    8a30:      	b.ge	0x8ba4 <_stogir.switch.case-inputs+0x1e4>
    8a34:      	ldr	x7, [x0, #0x78]
    8a38:      	add	x7, x5, x7
    8a3c:      	ldr	w7, [x7]
    8a40:      	sxtw	x7, w7
    8a44:      	cmp	x7, #0x0
    8a48:      	cset	w7, ge
    8a4c:      	ubfx	x7, x7, #0, #8
    8a50:      	b	0x8ba8 <_stogir.switch.case-inputs+0x1e8>
    8a54:      	cmp	x2, #0x0
    8a58:      	b.ge	0x8aac <_stogir.switch.case-inputs+0xec>
    8a5c:      	add	x10, x0, #0x28
    8a60:      	add	x11, x0, #0x50
    8a64:      	ldr	x10, [x10, #0x8]
    8a68:      	ldr	x11, [x11, #0x8]
    8a6c:      	cmp	x10, x11
    8a70:      	b.ne	0x8a9c <_stogir.switch.case-inputs+0xdc>
    8a74:      	cmp	x7, x10
    8a78:      	b.gt	0x8c6c <_stogir.switch.case-inputs+0x2ac>
    8a7c:      	ldr	x7, [x0, #0x50]
    8a80:      	add	x7, x7, x9, lsl #2
    8a84:      	ldr	w7, [x7]
    8a88:      	sxtw	x7, w7
    8a8c:      	cmp	x7, #0x0
    8a90:      	cset	w7, gt
    8a94:      	ubfx	x7, x7, #0, #8
    8a98:      	b	0x8c70 <_stogir.switch.case-inputs+0x2b0>
    8a9c:      	movz	x7, #0x0, lsl #48
    8aa0:      	b	0x8ab0 <_stogir.switch.case-inputs+0xf0>
    8aa4:      	movz	x7, #0x0, lsl #48
    8aa8:      	b	0x8ab0 <_stogir.switch.case-inputs+0xf0>
    8aac:      	movz	x7, #0x0, lsl #48
    8ab0:      	cmp	x7, #0x0
    8ab4:      	b.eq	0x8af0 <_stogir.switch.case-inputs+0x130>
    8ab8:      	uxtb	w16, w6
    8abc:      	cmp	w16, wzr
    8ac0:      	b.eq	0x8ad8 <_stogir.switch.case-inputs+0x118>
    8ac4:      	ldr	x6, [x0]
    8ac8:      	add	x6, x6, x2, lsl #4
    8acc:      	ldr	x7, [x6]
    8ad0:      	ldr	x6, [x6, #0x8]
    8ad4:      	b	0x8ae8 <_stogir.switch.case-inputs+0x128>
    8ad8:      	ldr	x6, [x0, #0x28]
    8adc:      	add	x6, x6, x9, lsl #4
    8ae0:      	ldr	x7, [x6]
    8ae4:      	ldr	x6, [x6, #0x8]
    8ae8:      	mov	x9, #0x1                ; =1
    8aec:      	b	0x8afc <_stogir.switch.case-inputs+0x13c>
    8af0:      	movz	x9, #0x0, lsl #48
    8af4:      	movz	x7, #0x0, lsl #48
    8af8:      	movz	x6, #0x0, lsl #48
    8afc:      	ubfx	x9, x9, #0, #32
    8b00:      	lsr	x16, x9, #0
    8b04:      	cmp	x16, #0x1
    8b08:      	b.eq	0x8b24 <_stogir.switch.case-inputs+0x164>
    8b0c:      	b.lo	0x8b14 <_stogir.switch.case-inputs+0x154>
    8b10:      	b	0x8b28 <_stogir.switch.case-inputs+0x168>
    8b14:      	cmp	x16, #0x0
    8b18:      	b.eq	0x8b20 <_stogir.switch.case-inputs+0x160>
    8b1c:      	b	0x8b28 <_stogir.switch.case-inputs+0x168>
    8b20:      	b	0x8b2c <_stogir.switch.case-inputs+0x16c>
    8b24:      	b	0x8b80 <_stogir.switch.case-inputs+0x1c0>
    8b28:      	b	0x8c74 <_stogir.switch.case-inputs+0x2b4>
    8b2c:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008b2c:  ARM64_RELOC_PAGE21	l_stogir.441
    8b30:      	ldr	x16, [x16]
		0000000000008b30:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    8b34:      	orr	x19, x16, xzr
    8b38:      	mov	x21, x8
    8b3c:      	mov	x1, #0x1                ; =1
    8b40:      	mov	x0, #0x1a               ; =26
    8b44:      	str	x1, [x21]
    8b48:      	str	x19, [x21, #0x8]
    8b4c:      	str	x0, [x21, #0x10]
    8b50:      	ldr	x19, [sp, #0x70]
    8b54:      	ldr	x20, [sp, #0x78]
    8b58:      	ldr	x21, [sp, #0x80]
    8b5c:      	ldr	x22, [sp, #0x88]
    8b60:      	ldr	x23, [sp, #0x90]
    8b64:      	ldr	x24, [sp, #0x98]
    8b68:      	ldr	x25, [sp, #0xa0]
    8b6c:      	ldr	x26, [sp, #0xa8]
    8b70:      	ldr	x29, [sp]
    8b74:      	ldr	x30, [sp, #0x8]
    8b78:      	add	sp, sp, #0xb0
    8b7c:      	ret
    8b80:      	cmp	x2, #0x0
    8b84:      	b.gt	0x8bac <_stogir.switch.case-inputs+0x1ec>
    8b88:      	mov	x21, x8
    8b8c:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008b8c:  ARM64_RELOC_PAGE21	l_stogir.442
    8b90:      	ldr	x16, [x16]
		0000000000008b90:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8b94:      	orr	x19, x16, xzr
    8b98:      	mov	x1, #0x1                ; =1
    8b9c:      	mov	x0, #0x1f               ; =31
    8ba0:      	b	0x8b44 <_stogir.switch.case-inputs+0x184>
    8ba4:      	movz	x7, #0x0, lsl #48
    8ba8:      	b	0x8aa8 <_stogir.switch.case-inputs+0xe8>
    8bac:      	uxtb	w2, w7
    8bb0:      	cmp	x2, #0x75
    8bb4:      	b.ne	0x8dd8 <_stogir.switch.case-inputs+0x418>
    8bb8:      	orr	w2, w7, wzr
    8bbc:      	ubfx	x2, x2, #0, #32
    8bc0:      	ubfx	x2, x2, #8, #8
    8bc4:      	cmp	x2, #0x0
    8bc8:      	b.ne	0x8de0 <_stogir.switch.case-inputs+0x420>
    8bcc:      	ldr	x2, [x0, #0x78]
    8bd0:      	add	x2, x5, x2
    8bd4:      	ldr	w2, [x2]
    8bd8:      	sxtw	x2, w2
    8bdc:      	cmp	x2, #0x2
    8be0:      	b.ne	0x8de8 <_stogir.switch.case-inputs+0x428>
    8be4:      	sxtw	x20, w1
    8be8:      	cmp	x20, #0x6d
    8bec:      	b.lt	0x8df0 <_stogir.switch.case-inputs+0x430>
    8bf0:      	cmp	x20, #0x6f
    8bf4:      	b.gt	0x8df8 <_stogir.switch.case-inputs+0x438>
    8bf8:      	add	x16, sp, #0x10
    8bfc:      	orr	x19, x16, xzr
    8c00:      	lsr	x1, x7, #32
    8c04:      	mov	w2, w6
    8c08:      	mov	x21, x8
    8c0c:      	add	x8, sp, #0x10
    8c10:      	mov	x22, x0
    8c14:      	mov	w23, w3
    8c18:      	mov	w24, w4
    8c1c:      	bl	0x8c1c <_stogir.switch.case-inputs+0x25c>
		0000000000008c1c:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    8c20:      	add	x16, sp, #0x10
    8c24:      	ldr	w0, [x16]
    8c28:      	lsr	x16, x0, #0
    8c2c:      	cmp	x16, #0x1
    8c30:      	b.eq	0x8c4c <_stogir.switch.case-inputs+0x28c>
    8c34:      	b.lo	0x8c3c <_stogir.switch.case-inputs+0x27c>
    8c38:      	b	0x8c50 <_stogir.switch.case-inputs+0x290>
    8c3c:      	cmp	x16, #0x0
    8c40:      	b.eq	0x8c48 <_stogir.switch.case-inputs+0x288>
    8c44:      	b	0x8c50 <_stogir.switch.case-inputs+0x290>
    8c48:      	b	0x8c7c <_stogir.switch.case-inputs+0x2bc>
    8c4c:      	b	0x8c54 <_stogir.switch.case-inputs+0x294>
    8c50:      	b	0x8dc0 <_stogir.switch.case-inputs+0x400>
    8c54:      	add	x0, x19, #0x8
    8c58:      	add	x16, sp, #0x10
    8c5c:      	ldr	x19, [x16, #0x8]
    8c60:      	ldr	x0, [x0, #0x8]
    8c64:      	mov	x1, #0x1                ; =1
    8c68:      	b	0x8ba0 <_stogir.switch.case-inputs+0x1e0>
    8c6c:      	movz	x7, #0x0, lsl #48
    8c70:      	b	0x8aa0 <_stogir.switch.case-inputs+0xe0>
    8c74:      	brk	#0
    8c78:      	b	0x8c74 <_stogir.switch.case-inputs+0x2b4>
    8c7c:      	add	x16, sp, #0x10
    8c80:      	ldr	w25, [x16, #0x8]
    8c84:      	sxtw	x0, w25
    8c88:      	and	x19, x0, #0xffffffff
    8c8c:      	cmp	x20, #0x6f
    8c90:      	b.ne	0x8ca0 <_stogir.switch.case-inputs+0x2e0>
    8c94:      	movz	x1, #0x0, lsl #48
    8c98:      	movz	x0, #0x0, lsl #48
    8c9c:      	b	0x8c68 <_stogir.switch.case-inputs+0x2a8>
    8ca0:      	add	x16, sp, #0x30
    8ca4:      	orr	x26, x16, xzr
    8ca8:      	add	x8, sp, #0x30
    8cac:      	mov	x0, x22
    8cb0:      	mov	w1, w23
    8cb4:      	mov	w2, w25
    8cb8:      	bl	0x8cb8 <_stogir.switch.case-inputs+0x2f8>
		0000000000008cb8:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    8cbc:      	add	x16, sp, #0x30
    8cc0:      	ldr	w0, [x16]
    8cc4:      	lsr	x16, x0, #0
    8cc8:      	cmp	x16, #0x1
    8ccc:      	b.eq	0x8ce8 <_stogir.switch.case-inputs+0x328>
    8cd0:      	b.lo	0x8cd8 <_stogir.switch.case-inputs+0x318>
    8cd4:      	b	0x8cec <_stogir.switch.case-inputs+0x32c>
    8cd8:      	cmp	x16, #0x0
    8cdc:      	b.eq	0x8ce4 <_stogir.switch.case-inputs+0x324>
    8ce0:      	b	0x8cec <_stogir.switch.case-inputs+0x32c>
    8ce4:      	b	0x8d08 <_stogir.switch.case-inputs+0x348>
    8ce8:      	b	0x8cf0 <_stogir.switch.case-inputs+0x330>
    8cec:      	b	0x8dc8 <_stogir.switch.case-inputs+0x408>
    8cf0:      	add	x0, x26, #0x8
    8cf4:      	add	x16, sp, #0x30
    8cf8:      	ldr	x19, [x16, #0x8]
    8cfc:      	ldr	x0, [x0, #0x8]
    8d00:      	mov	x1, #0x1                ; =1
    8d04:      	b	0x8c9c <_stogir.switch.case-inputs+0x2dc>
    8d08:      	add	x16, sp, #0x30
    8d0c:      	ldr	x26, [x16, #0x8]
    8d10:      	cmp	x20, #0x6d
    8d14:      	b.ne	0x8d2c <_stogir.switch.case-inputs+0x36c>
    8d18:      	sxtw	x24, w23
    8d1c:      	b	0x8d30 <_stogir.switch.case-inputs+0x370>
    8d20:      	movz	x1, #0x0, lsl #48
    8d24:      	movz	x0, #0x0, lsl #48
    8d28:      	b	0x8d04 <_stogir.switch.case-inputs+0x344>
    8d2c:      	sxtw	x24, w24
    8d30:      	add	x16, sp, #0x50
    8d34:      	orr	x20, x16, xzr
    8d38:      	add	x8, sp, #0x50
    8d3c:      	mov	x0, x22
    8d40:      	mov	w1, w24
    8d44:      	mov	w2, w25
    8d48:      	bl	0x8d48 <_stogir.switch.case-inputs+0x388>
		0000000000008d48:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    8d4c:      	add	x16, sp, #0x50
    8d50:      	ldr	w0, [x16]
    8d54:      	lsr	x16, x0, #0
    8d58:      	cmp	x16, #0x1
    8d5c:      	b.eq	0x8d78 <_stogir.switch.case-inputs+0x3b8>
    8d60:      	b.lo	0x8d68 <_stogir.switch.case-inputs+0x3a8>
    8d64:      	b	0x8d7c <_stogir.switch.case-inputs+0x3bc>
    8d68:      	cmp	x16, #0x0
    8d6c:      	b.eq	0x8d74 <_stogir.switch.case-inputs+0x3b4>
    8d70:      	b	0x8d7c <_stogir.switch.case-inputs+0x3bc>
    8d74:      	b	0x8d98 <_stogir.switch.case-inputs+0x3d8>
    8d78:      	b	0x8d80 <_stogir.switch.case-inputs+0x3c0>
    8d7c:      	b	0x8dd0 <_stogir.switch.case-inputs+0x410>
    8d80:      	add	x0, x20, #0x8
    8d84:      	add	x16, sp, #0x50
    8d88:      	ldr	x19, [x16, #0x8]
    8d8c:      	ldr	x0, [x0, #0x8]
    8d90:      	mov	x1, #0x1                ; =1
    8d94:      	b	0x8d28 <_stogir.switch.case-inputs+0x368>
    8d98:      	add	x16, sp, #0x50
    8d9c:      	ldr	x0, [x16, #0x8]
    8da0:      	cmp	x26, x0
    8da4:      	b.ls	0x8d20 <_stogir.switch.case-inputs+0x360>
    8da8:      	adrp	x16, 0x8000 <_stogir.atomic.ordinary?+0xc8>
		0000000000008da8:  ARM64_RELOC_PAGE21	l_stogir.443
    8dac:      	ldr	x16, [x16]
		0000000000008dac:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    8db0:      	orr	x19, x16, xzr
    8db4:      	mov	x1, #0x1                ; =1
    8db8:      	mov	x0, #0x1a               ; =26
    8dbc:      	b	0x8d28 <_stogir.switch.case-inputs+0x368>
    8dc0:      	brk	#0
    8dc4:      	b	0x8dc0 <_stogir.switch.case-inputs+0x400>
    8dc8:      	brk	#0
    8dcc:      	b	0x8dc8 <_stogir.switch.case-inputs+0x408>
    8dd0:      	brk	#0
    8dd4:      	b	0x8dd0 <_stogir.switch.case-inputs+0x410>
    8dd8:      	mov	x21, x8
    8ddc:      	b	0x8b8c <_stogir.switch.case-inputs+0x1cc>
    8de0:      	mov	x21, x8
    8de4:      	b	0x8b8c <_stogir.switch.case-inputs+0x1cc>
    8de8:      	mov	x21, x8
    8dec:      	b	0x8b8c <_stogir.switch.case-inputs+0x1cc>
    8df0:      	mov	x21, x8
    8df4:      	b	0x8b8c <_stogir.switch.case-inputs+0x1cc>
    8df8:      	mov	x21, x8
    8dfc:      	b	0x8b8c <_stogir.switch.case-inputs+0x1cc>

0000000000008e00 <_stogir.stack.valid-frame-object-inputs?>:
    8e00:      	sub	sp, sp, #0x50
    8e04:      	str	x29, [sp]
    8e08:      	str	x30, [sp, #0x8]
    8e0c:      	mov	x29, sp
    8e10:      	str	x19, [sp, #0x30]
    8e14:      	str	x20, [sp, #0x38]
    8e18:      	str	x21, [sp, #0x40]
    8e1c:      	add	x3, x0, #0x78
    8e20:      	add	x4, x0, #0x28
    8e24:      	add	x5, x0, #0x50
    8e28:      	add	x6, x0, #0x78
    8e2c:      	add	x7, x0, #0x28
    8e30:      	add	x8, x0, #0x50
    8e34:      	sxtw	x1, w1
    8e38:      	mov	x9, sp
    8e3c:      	sub	sp, sp, #0x10
    8e40:      	mov	x10, sp
    8e44:      	mov	x11, #0x1               ; =1
    8e48:      	movz	x12, #0x0, lsl #48
    8e4c:      	b	0x8f50 <_stogir.stack.valid-frame-object-inputs?+0x150>
    8e50:      	movz	x15, #0x0, lsl #48
    8e54:      	b	0x8ec0 <_stogir.stack.valid-frame-object-inputs?+0xc0>
    8e58:      	movz	x14, #0x0, lsl #48
    8e5c:      	movz	x13, #0x0, lsl #48
    8e60:      	ubfx	x14, x14, #0, #32
    8e64:      	lsr	x16, x14, #0
    8e68:      	cmp	x16, #0x1
    8e6c:      	b.eq	0x8e88 <_stogir.stack.valid-frame-object-inputs?+0x88>
    8e70:      	b.lo	0x8e78 <_stogir.stack.valid-frame-object-inputs?+0x78>
    8e74:      	b	0x8e8c <_stogir.stack.valid-frame-object-inputs?+0x8c>
    8e78:      	cmp	x16, #0x0
    8e7c:      	b.eq	0x8e84 <_stogir.stack.valid-frame-object-inputs?+0x84>
    8e80:      	b	0x8e8c <_stogir.stack.valid-frame-object-inputs?+0x8c>
    8e84:      	b	0x8eac <_stogir.stack.valid-frame-object-inputs?+0xac>
    8e88:      	b	0x8e90 <_stogir.stack.valid-frame-object-inputs?+0x90>
    8e8c:      	b	0x9208 <_stogir.stack.valid-frame-object-inputs?+0x408>
    8e90:      	uxtb	w14, w13
    8e94:      	ubfx	x13, x13, #0, #32
    8e98:      	ubfx	x13, x13, #8, #8
    8e9c:      	cmp	x14, x13
    8ea0:      	b.eq	0x91f4 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    8ea4:      	cmp	x14, #0x49
    8ea8:      	b.eq	0x91f4 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    8eac:      	movz	x11, #0x0, lsl #48
    8eb0:      	b	0x9028 <_stogir.stack.valid-frame-object-inputs?+0x228>
    8eb4:      	movz	x15, #0x0, lsl #48
    8eb8:      	b	0x8ec8 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    8ebc:      	movz	x15, #0x0, lsl #48
    8ec0:      	b	0x8ed0 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    8ec4:      	movz	x15, #0x0, lsl #48
    8ec8:      	b	0x8ed0 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    8ecc:      	movz	x15, #0x0, lsl #48
    8ed0:      	cmp	x15, #0x0
    8ed4:      	b.eq	0x8f10 <_stogir.stack.valid-frame-object-inputs?+0x110>
    8ed8:      	uxtb	w16, w14
    8edc:      	cmp	w16, wzr
    8ee0:      	b.eq	0x8ef8 <_stogir.stack.valid-frame-object-inputs?+0xf8>
    8ee4:      	ldr	x14, [x0]
    8ee8:      	add	x13, x14, x13, lsl #4
    8eec:      	ldr	x14, [x13]
    8ef0:      	ldr	x13, [x13, #0x8]
    8ef4:      	b	0x8f08 <_stogir.stack.valid-frame-object-inputs?+0x108>
    8ef8:      	ldr	x13, [x0, #0x28]
    8efc:      	add	x13, x13, x19, lsl #4
    8f00:      	ldr	x14, [x13]
    8f04:      	ldr	x13, [x13, #0x8]
    8f08:      	mov	x15, #0x1               ; =1
    8f0c:      	b	0x8f1c <_stogir.stack.valid-frame-object-inputs?+0x11c>
    8f10:      	movz	x15, #0x0, lsl #48
    8f14:      	movz	x14, #0x0, lsl #48
    8f18:      	movz	x13, #0x0, lsl #48
    8f1c:      	ubfx	x15, x15, #0, #32
    8f20:      	lsr	x16, x15, #0
    8f24:      	cmp	x16, #0x1
    8f28:      	b.eq	0x8f44 <_stogir.stack.valid-frame-object-inputs?+0x144>
    8f2c:      	b.lo	0x8f34 <_stogir.stack.valid-frame-object-inputs?+0x134>
    8f30:      	b	0x8f48 <_stogir.stack.valid-frame-object-inputs?+0x148>
    8f34:      	cmp	x16, #0x0
    8f38:      	b.eq	0x8f40 <_stogir.stack.valid-frame-object-inputs?+0x140>
    8f3c:      	b	0x8f48 <_stogir.stack.valid-frame-object-inputs?+0x148>
    8f40:      	b	0x8f4c <_stogir.stack.valid-frame-object-inputs?+0x14c>
    8f44:      	b	0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
    8f48:      	b	0x9160 <_stogir.stack.valid-frame-object-inputs?+0x360>
    8f4c:      	movz	x11, #0x0, lsl #48
    8f50:      	cmp	x11, #0x0
    8f54:      	b.eq	0x90b0 <_stogir.stack.valid-frame-object-inputs?+0x2b0>
    8f58:      	cmp	x12, #0x0
    8f5c:      	b.ne	0x90b0 <_stogir.stack.valid-frame-object-inputs?+0x2b0>
    8f60:      	orr	w13, w1, wzr
    8f64:      	sxtw	x13, w13
    8f68:      	cmp	x13, #0x0
    8f6c:      	cset	w14, gt
    8f70:      	movz	x16, #0x0, lsl #48
    8f74:      	sub	x15, x16, x13
    8f78:      	sub	x19, x15, #0x1
    8f7c:      	uxtb	w16, w14
    8f80:      	cmp	w16, wzr
    8f84:      	b.eq	0x8fc0 <_stogir.stack.valid-frame-object-inputs?+0x1c0>
    8f88:      	ldr	x15, [x0, #0x8]
    8f8c:      	cmp	x13, x15
    8f90:      	b.ge	0x8ec4 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    8f94:      	ldr	x15, [x3, #0x8]
    8f98:      	cmp	x13, x15
    8f9c:      	b.ge	0x8eb4 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    8fa0:      	ldr	x15, [x0, #0x78]
    8fa4:      	add	x15, x15, x13, lsl #2
    8fa8:      	ldr	w15, [x15]
    8fac:      	sxtw	x15, w15
    8fb0:      	cmp	x15, #0x0
    8fb4:      	cset	w15, ge
    8fb8:      	ubfx	x15, x15, #0, #8
    8fbc:      	b	0x8eb8 <_stogir.stack.valid-frame-object-inputs?+0xb8>
    8fc0:      	cmp	x13, #0x0
    8fc4:      	b.ge	0x8ecc <_stogir.stack.valid-frame-object-inputs?+0xcc>
    8fc8:      	ldr	x20, [x4, #0x8]
    8fcc:      	ldr	x21, [x5, #0x8]
    8fd0:      	cmp	x20, x21
    8fd4:      	b.ne	0x8ebc <_stogir.stack.valid-frame-object-inputs?+0xbc>
    8fd8:      	cmp	x15, x20
    8fdc:      	b.gt	0x8e50 <_stogir.stack.valid-frame-object-inputs?+0x50>
    8fe0:      	ldr	x15, [x0, #0x50]
    8fe4:      	add	x15, x15, x19, lsl #2
    8fe8:      	ldr	w15, [x15]
    8fec:      	sxtw	x15, w15
    8ff0:      	cmp	x15, #0x0
    8ff4:      	cset	w15, gt
    8ff8:      	ubfx	x15, x15, #0, #8
    8ffc:      	b	0x8e54 <_stogir.stack.valid-frame-object-inputs?+0x54>
    9000:      	uxtb	w15, w14
    9004:      	asr	x19, x14, #32
    9008:      	str	x14, [x10]
    900c:      	str	x13, [x10, #0x8]
    9010:      	cmp	x15, #0x68
    9014:      	b.ne	0x902c <_stogir.stack.valid-frame-object-inputs?+0x22c>
    9018:      	cmp	x19, #0x0
    901c:      	cset	w11, eq
    9020:      	ubfx	x11, x11, #0, #8
    9024:      	mov	x12, #0x1               ; =1
    9028:      	b	0x8f50 <_stogir.stack.valid-frame-object-inputs?+0x150>
    902c:      	cmp	x1, #0x0
    9030:      	b.le	0x8eac <_stogir.stack.valid-frame-object-inputs?+0xac>
    9034:      	cmp	x15, #0x51
    9038:      	b.ne	0x8eac <_stogir.stack.valid-frame-object-inputs?+0xac>
    903c:      	cmp	x19, #0x0
    9040:      	b.le	0x8eac <_stogir.stack.valid-frame-object-inputs?+0xac>
    9044:      	cmp	x19, x1
    9048:      	b.ge	0x8eac <_stogir.stack.valid-frame-object-inputs?+0xac>
    904c:      	sxtw	x13, w13
    9050:      	cmp	x13, #0x0
    9054:      	b.ge	0x8eac <_stogir.stack.valid-frame-object-inputs?+0xac>
    9058:      	cmp	x13, #0x0
    905c:      	cset	w14, gt
    9060:      	movz	x16, #0x0, lsl #48
    9064:      	sub	x15, x16, x13
    9068:      	sub	x19, x15, #0x1
    906c:      	uxtb	w16, w14
    9070:      	cmp	w16, wzr
    9074:      	b.eq	0x91ac <_stogir.stack.valid-frame-object-inputs?+0x3ac>
    9078:      	ldr	x15, [x0, #0x8]
    907c:      	cmp	x13, x15
    9080:      	b.ge	0x91a4 <_stogir.stack.valid-frame-object-inputs?+0x3a4>
    9084:      	ldr	x15, [x6, #0x8]
    9088:      	cmp	x13, x15
    908c:      	b.ge	0x91ec <_stogir.stack.valid-frame-object-inputs?+0x3ec>
    9090:      	ldr	x15, [x0, #0x78]
    9094:      	add	x15, x15, x13, lsl #2
    9098:      	ldr	w15, [x15]
    909c:      	sxtw	x15, w15
    90a0:      	cmp	x15, #0x0
    90a4:      	cset	w15, ge
    90a8:      	ubfx	x15, x15, #0, #8
    90ac:      	b	0x91f0 <_stogir.stack.valid-frame-object-inputs?+0x3f0>
    90b0:      	cmp	x11, #0x0
    90b4:      	b.ne	0x90bc <_stogir.stack.valid-frame-object-inputs?+0x2bc>
    90b8:      	movz	x12, #0x0, lsl #48
    90bc:      	mov	sp, x9
    90c0:      	cmp	x12, #0x0
    90c4:      	b.eq	0x911c <_stogir.stack.valid-frame-object-inputs?+0x31c>
    90c8:      	sxtw	x1, w2
    90cc:      	cmp	x1, #0x0
    90d0:      	b.ge	0x9140 <_stogir.stack.valid-frame-object-inputs?+0x340>
    90d4:      	add	x8, x29, #0x10
    90d8:      	mov	w1, w2
    90dc:      	bl	0x90dc <_stogir.stack.valid-frame-object-inputs?+0x2dc>
		00000000000090dc:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    90e0:      	add	x16, x29, #0x10
    90e4:      	ldr	w0, [x16]
    90e8:      	lsr	x16, x0, #0
    90ec:      	cmp	x16, #0x1
    90f0:      	b.eq	0x910c <_stogir.stack.valid-frame-object-inputs?+0x30c>
    90f4:      	b.lo	0x90fc <_stogir.stack.valid-frame-object-inputs?+0x2fc>
    90f8:      	b	0x9110 <_stogir.stack.valid-frame-object-inputs?+0x310>
    90fc:      	cmp	x16, #0x0
    9100:      	b.eq	0x9108 <_stogir.stack.valid-frame-object-inputs?+0x308>
    9104:      	b	0x9110 <_stogir.stack.valid-frame-object-inputs?+0x310>
    9108:      	b	0x9148 <_stogir.stack.valid-frame-object-inputs?+0x348>
    910c:      	b	0x9114 <_stogir.stack.valid-frame-object-inputs?+0x314>
    9110:      	b	0x9200 <_stogir.stack.valid-frame-object-inputs?+0x400>
    9114:      	movz	x0, #0x0, lsl #48
    9118:      	b	0x915c <_stogir.stack.valid-frame-object-inputs?+0x35c>
    911c:      	movz	x0, #0x0, lsl #48
    9120:      	sub	sp, x29, #0x0
    9124:      	ldr	x19, [sp, #0x30]
    9128:      	ldr	x20, [sp, #0x38]
    912c:      	ldr	x21, [sp, #0x40]
    9130:      	ldr	x29, [sp]
    9134:      	ldr	x30, [sp, #0x8]
    9138:      	add	sp, sp, #0x50
    913c:      	ret
    9140:      	movz	x0, #0x0, lsl #48
    9144:      	b	0x9120 <_stogir.stack.valid-frame-object-inputs?+0x320>
    9148:      	add	x16, x29, #0x10
    914c:      	ldr	x0, [x16, #0x8]
    9150:      	cmp	x0, #0x0
    9154:      	cset	w0, gt
    9158:      	ubfx	x0, x0, #0, #8
    915c:      	b	0x9144 <_stogir.stack.valid-frame-object-inputs?+0x344>
    9160:      	brk	#0
    9164:      	b	0x9160 <_stogir.stack.valid-frame-object-inputs?+0x360>
    9168:      	ldr	x13, [x0, #0x28]
    916c:      	add	x13, x13, x19, lsl #4
    9170:      	ldr	x13, [x13]
    9174:      	mov	x14, #0x1               ; =1
    9178:      	b	0x8e60 <_stogir.stack.valid-frame-object-inputs?+0x60>
    917c:      	movz	x15, #0x0, lsl #48
    9180:      	cmp	x15, #0x0
    9184:      	b.eq	0x8e58 <_stogir.stack.valid-frame-object-inputs?+0x58>
    9188:      	uxtb	w16, w14
    918c:      	cmp	w16, wzr
    9190:      	b.eq	0x9168 <_stogir.stack.valid-frame-object-inputs?+0x368>
    9194:      	ldr	x14, [x0]
    9198:      	add	x13, x14, x13, lsl #4
    919c:      	ldr	x13, [x13]
    91a0:      	b	0x9174 <_stogir.stack.valid-frame-object-inputs?+0x374>
    91a4:      	movz	x15, #0x0, lsl #48
    91a8:      	b	0x9180 <_stogir.stack.valid-frame-object-inputs?+0x380>
    91ac:      	ldr	x20, [x7, #0x8]
    91b0:      	ldr	x21, [x8, #0x8]
    91b4:      	cmp	x20, x21
    91b8:      	b.ne	0x917c <_stogir.stack.valid-frame-object-inputs?+0x37c>
    91bc:      	cmp	x15, x20
    91c0:      	b.gt	0x91e4 <_stogir.stack.valid-frame-object-inputs?+0x3e4>
    91c4:      	ldr	x15, [x0, #0x50]
    91c8:      	add	x15, x15, x19, lsl #2
    91cc:      	ldr	w15, [x15]
    91d0:      	sxtw	x15, w15
    91d4:      	cmp	x15, #0x0
    91d8:      	cset	w15, gt
    91dc:      	ubfx	x15, x15, #0, #8
    91e0:      	b	0x91e8 <_stogir.stack.valid-frame-object-inputs?+0x3e8>
    91e4:      	movz	x15, #0x0, lsl #48
    91e8:      	b	0x9180 <_stogir.stack.valid-frame-object-inputs?+0x380>
    91ec:      	movz	x15, #0x0, lsl #48
    91f0:      	b	0x91a8 <_stogir.stack.valid-frame-object-inputs?+0x3a8>
    91f4:      	ldr	w1, [x10, #0x4]
    91f8:      	sxtw	x1, w1
    91fc:      	b	0x8eb0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    9200:      	brk	#0
    9204:      	b	0x9200 <_stogir.stack.valid-frame-object-inputs?+0x400>
    9208:      	brk	#0
    920c:      	b	0x9208 <_stogir.stack.valid-frame-object-inputs?+0x408>

0000000000009210 <_stogir.stack.validate-scope-inputs>:
    9210:      	sxtw	x1, w1
    9214:      	cmp	x1, #0x53
    9218:      	cset	w5, eq
    921c:      	uxtb	w16, w5
    9220:      	cmp	w16, wzr
    9224:      	b.ne	0x9254 <_stogir.stack.validate-scope-inputs+0x44>
    9228:      	cmp	x1, #0x54
    922c:      	b.eq	0x9254 <_stogir.stack.validate-scope-inputs+0x44>
    9230:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009230:  ARM64_RELOC_PAGE21	l_stogir.444
    9234:      	ldr	x16, [x16]
		0000000000009234:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    9238:      	orr	x0, x16, xzr
    923c:      	mov	x1, #0x1                ; =1
    9240:      	mov	x2, #0x22               ; =34
    9244:      	str	x1, [x8]
    9248:      	str	x0, [x8, #0x8]
    924c:      	str	x2, [x8, #0x10]
    9250:      	ret
    9254:      	uxtb	w16, w5
    9258:      	cmp	w16, wzr
    925c:      	mov	x16, #0x6               ; =6
    9260:      	movz	x17, #0x0, lsl #48
    9264:      	csel	x1, x16, x17, ne
    9268:      	sxtw	x2, w2
    926c:      	sxtw	x1, w1
    9270:      	cmp	x2, x1
    9274:      	b.ne	0x9230 <_stogir.stack.validate-scope-inputs+0x20>
    9278:      	sxtw	x3, w3
    927c:      	cmp	x3, #0x0
    9280:      	cset	w1, gt
    9284:      	movz	x16, #0x0, lsl #48
    9288:      	sub	x2, x16, x3
    928c:      	sub	x6, x2, #0x1
    9290:      	uxtb	w16, w1
    9294:      	cmp	w16, wzr
    9298:      	b.eq	0x936c <_stogir.stack.validate-scope-inputs+0x15c>
    929c:      	ldr	x2, [x0, #0x8]
    92a0:      	cmp	x3, x2
    92a4:      	b.ge	0x9364 <_stogir.stack.validate-scope-inputs+0x154>
    92a8:      	add	x2, x0, #0x78
    92ac:      	ldr	x2, [x2, #0x8]
    92b0:      	cmp	x3, x2
    92b4:      	b.ge	0x940c <_stogir.stack.validate-scope-inputs+0x1fc>
    92b8:      	ldr	x2, [x0, #0x78]
    92bc:      	add	x2, x2, x3, lsl #2
    92c0:      	ldr	w2, [x2]
    92c4:      	sxtw	x2, w2
    92c8:      	cmp	x2, #0x0
    92cc:      	cset	w2, ge
    92d0:      	ubfx	x2, x2, #0, #8
    92d4:      	b	0x9410 <_stogir.stack.validate-scope-inputs+0x200>
    92d8:      	movz	x2, #0x0, lsl #48
    92dc:      	movz	x1, #0x0, lsl #48
    92e0:      	ubfx	x2, x2, #0, #32
    92e4:      	lsr	x16, x2, #0
    92e8:      	cmp	x16, #0x1
    92ec:      	b.eq	0x9308 <_stogir.stack.validate-scope-inputs+0xf8>
    92f0:      	b.lo	0x92f8 <_stogir.stack.validate-scope-inputs+0xe8>
    92f4:      	b	0x930c <_stogir.stack.validate-scope-inputs+0xfc>
    92f8:      	cmp	x16, #0x0
    92fc:      	b.eq	0x9304 <_stogir.stack.validate-scope-inputs+0xf4>
    9300:      	b	0x930c <_stogir.stack.validate-scope-inputs+0xfc>
    9304:      	b	0x9310 <_stogir.stack.validate-scope-inputs+0x100>
    9308:      	b	0x93b4 <_stogir.stack.validate-scope-inputs+0x1a4>
    930c:      	b	0x95dc <_stogir.stack.validate-scope-inputs+0x3cc>
    9310:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009310:  ARM64_RELOC_PAGE21	l_stogir.445
    9314:      	ldr	x16, [x16]
		0000000000009314:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    9318:      	orr	x0, x16, xzr
    931c:      	mov	x1, #0x1                ; =1
    9320:      	mov	x2, #0x1b               ; =27
    9324:      	b	0x9244 <_stogir.stack.validate-scope-inputs+0x34>
    9328:      	ldr	x1, [x0, #0x28]
    932c:      	add	x1, x1, x6, lsl #4
    9330:      	ldr	x1, [x1]
    9334:      	mov	x2, #0x1                ; =1
    9338:      	b	0x92e0 <_stogir.stack.validate-scope-inputs+0xd0>
    933c:      	movz	x2, #0x0, lsl #48
    9340:      	cmp	x2, #0x0
    9344:      	b.eq	0x92d8 <_stogir.stack.validate-scope-inputs+0xc8>
    9348:      	uxtb	w16, w1
    934c:      	cmp	w16, wzr
    9350:      	b.eq	0x9328 <_stogir.stack.validate-scope-inputs+0x118>
    9354:      	ldr	x1, [x0]
    9358:      	add	x1, x1, x3, lsl #4
    935c:      	ldr	x1, [x1]
    9360:      	b	0x9334 <_stogir.stack.validate-scope-inputs+0x124>
    9364:      	movz	x2, #0x0, lsl #48
    9368:      	b	0x9340 <_stogir.stack.validate-scope-inputs+0x130>
    936c:      	cmp	x3, #0x0
    9370:      	b.ge	0x933c <_stogir.stack.validate-scope-inputs+0x12c>
    9374:      	add	x7, x0, #0x28
    9378:      	add	x9, x0, #0x50
    937c:      	ldr	x7, [x7, #0x8]
    9380:      	ldr	x9, [x9, #0x8]
    9384:      	cmp	x7, x9
    9388:      	b.ne	0x9404 <_stogir.stack.validate-scope-inputs+0x1f4>
    938c:      	cmp	x2, x7
    9390:      	b.gt	0x9414 <_stogir.stack.validate-scope-inputs+0x204>
    9394:      	ldr	x2, [x0, #0x50]
    9398:      	add	x2, x2, x6, lsl #2
    939c:      	ldr	w2, [x2]
    93a0:      	sxtw	x2, w2
    93a4:      	cmp	x2, #0x0
    93a8:      	cset	w2, gt
    93ac:      	ubfx	x2, x2, #0, #8
    93b0:      	b	0x9418 <_stogir.stack.validate-scope-inputs+0x208>
    93b4:      	cmp	x3, #0x0
    93b8:      	b.le	0x93ec <_stogir.stack.validate-scope-inputs+0x1dc>
    93bc:      	uxtb	w1, w1
    93c0:      	cmp	x1, #0x83
    93c4:      	cset	w2, lt
    93c8:      	uxtb	w16, w2
    93cc:      	cmp	w16, wzr
    93d0:      	b.eq	0x941c <_stogir.stack.validate-scope-inputs+0x20c>
    93d4:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		00000000000093d4:  ARM64_RELOC_PAGE21	l_stogir.446
    93d8:      	ldr	x16, [x16]
		00000000000093d8:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    93dc:      	orr	x3, x16, xzr
    93e0:      	add	x3, x1, x3
    93e4:      	ldrb	w3, [x3]
    93e8:      	b	0x9420 <_stogir.stack.validate-scope-inputs+0x210>
    93ec:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		00000000000093ec:  ARM64_RELOC_PAGE21	l_stogir.447
    93f0:      	ldr	x16, [x16]
		00000000000093f0:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    93f4:      	orr	x0, x16, xzr
    93f8:      	mov	x1, #0x1                ; =1
    93fc:      	mov	x2, #0x1b               ; =27
    9400:      	b	0x9324 <_stogir.stack.validate-scope-inputs+0x114>
    9404:      	movz	x2, #0x0, lsl #48
    9408:      	b	0x9340 <_stogir.stack.validate-scope-inputs+0x130>
    940c:      	movz	x2, #0x0, lsl #48
    9410:      	b	0x9368 <_stogir.stack.validate-scope-inputs+0x158>
    9414:      	movz	x2, #0x0, lsl #48
    9418:      	b	0x9408 <_stogir.stack.validate-scope-inputs+0x1f8>
    941c:      	movz	x3, #0x0, lsl #48
    9420:      	uxtb	w3, w3
    9424:      	and	x3, x3, #0x1
    9428:      	uxtb	w3, w3
    942c:      	cmp	x3, #0x0
    9430:      	b.eq	0x93ec <_stogir.stack.validate-scope-inputs+0x1dc>
    9434:      	uxtb	w16, w2
    9438:      	cmp	w16, wzr
    943c:      	b.eq	0x9458 <_stogir.stack.validate-scope-inputs+0x248>
    9440:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009440:  ARM64_RELOC_PAGE21	l_stogir.446
    9444:      	ldr	x16, [x16]
		0000000000009444:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    9448:      	orr	x2, x16, xzr
    944c:      	add	x1, x1, x2
    9450:      	ldrb	w1, [x1]
    9454:      	b	0x945c <_stogir.stack.validate-scope-inputs+0x24c>
    9458:      	movz	x1, #0x0, lsl #48
    945c:      	uxtb	w1, w1
    9460:      	and	x1, x1, #0x4
    9464:      	uxtb	w1, w1
    9468:      	cmp	x1, #0x0
    946c:      	cset	w1, eq
    9470:      	uxtb	w16, w1
    9474:      	cmp	w16, wzr
    9478:      	cset	x1, eq
    947c:      	cmp	x1, #0x0
    9480:      	b.ne	0x93ec <_stogir.stack.validate-scope-inputs+0x1dc>
    9484:      	uxtb	w16, w5
    9488:      	cmp	w16, wzr
    948c:      	b.eq	0x94a0 <_stogir.stack.validate-scope-inputs+0x290>
    9490:      	movz	x1, #0x0, lsl #48
    9494:      	mov	x0, #0x8                ; =8
    9498:      	movz	x2, #0x0, lsl #48
    949c:      	b	0x9400 <_stogir.stack.validate-scope-inputs+0x1f0>
    94a0:      	sxtw	x4, w4
    94a4:      	cmp	x4, #0x0
    94a8:      	cset	w1, gt
    94ac:      	movz	x16, #0x0, lsl #48
    94b0:      	sub	x2, x16, x4
    94b4:      	sub	x3, x2, #0x1
    94b8:      	uxtb	w16, w1
    94bc:      	cmp	w16, wzr
    94c0:      	b.eq	0x9594 <_stogir.stack.validate-scope-inputs+0x384>
    94c4:      	ldr	x2, [x0, #0x8]
    94c8:      	cmp	x4, x2
    94cc:      	b.ge	0x958c <_stogir.stack.validate-scope-inputs+0x37c>
    94d0:      	add	x2, x0, #0x78
    94d4:      	ldr	x2, [x2, #0x8]
    94d8:      	cmp	x4, x2
    94dc:      	b.ge	0x9634 <_stogir.stack.validate-scope-inputs+0x424>
    94e0:      	ldr	x2, [x0, #0x78]
    94e4:      	add	x2, x2, x4, lsl #2
    94e8:      	ldr	w2, [x2]
    94ec:      	sxtw	x2, w2
    94f0:      	cmp	x2, #0x0
    94f4:      	cset	w2, ge
    94f8:      	ubfx	x2, x2, #0, #8
    94fc:      	b	0x9638 <_stogir.stack.validate-scope-inputs+0x428>
    9500:      	movz	x1, #0x0, lsl #48
    9504:      	movz	x0, #0x0, lsl #48
    9508:      	ubfx	x1, x1, #0, #32
    950c:      	lsr	x16, x1, #0
    9510:      	cmp	x16, #0x1
    9514:      	b.eq	0x9530 <_stogir.stack.validate-scope-inputs+0x320>
    9518:      	b.lo	0x9520 <_stogir.stack.validate-scope-inputs+0x310>
    951c:      	b	0x9534 <_stogir.stack.validate-scope-inputs+0x324>
    9520:      	cmp	x16, #0x0
    9524:      	b.eq	0x952c <_stogir.stack.validate-scope-inputs+0x31c>
    9528:      	b	0x9534 <_stogir.stack.validate-scope-inputs+0x324>
    952c:      	b	0x9538 <_stogir.stack.validate-scope-inputs+0x328>
    9530:      	b	0x95e4 <_stogir.stack.validate-scope-inputs+0x3d4>
    9534:      	b	0x9644 <_stogir.stack.validate-scope-inputs+0x434>
    9538:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009538:  ARM64_RELOC_PAGE21	l_stogir.448
    953c:      	ldr	x16, [x16]
		000000000000953c:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    9540:      	orr	x0, x16, xzr
    9544:      	mov	x1, #0x1                ; =1
    9548:      	mov	x2, #0x1b               ; =27
    954c:      	b	0x949c <_stogir.stack.validate-scope-inputs+0x28c>
    9550:      	ldr	x0, [x0, #0x28]
    9554:      	add	x0, x0, x3, lsl #4
    9558:      	ldr	x0, [x0]
    955c:      	mov	x1, #0x1                ; =1
    9560:      	b	0x9508 <_stogir.stack.validate-scope-inputs+0x2f8>
    9564:      	movz	x2, #0x0, lsl #48
    9568:      	cmp	x2, #0x0
    956c:      	b.eq	0x9500 <_stogir.stack.validate-scope-inputs+0x2f0>
    9570:      	uxtb	w16, w1
    9574:      	cmp	w16, wzr
    9578:      	b.eq	0x9550 <_stogir.stack.validate-scope-inputs+0x340>
    957c:      	ldr	x0, [x0]
    9580:      	add	x0, x0, x4, lsl #4
    9584:      	ldr	x0, [x0]
    9588:      	b	0x955c <_stogir.stack.validate-scope-inputs+0x34c>
    958c:      	movz	x2, #0x0, lsl #48
    9590:      	b	0x9568 <_stogir.stack.validate-scope-inputs+0x358>
    9594:      	cmp	x4, #0x0
    9598:      	b.ge	0x9564 <_stogir.stack.validate-scope-inputs+0x354>
    959c:      	add	x5, x0, #0x28
    95a0:      	add	x6, x0, #0x50
    95a4:      	ldr	x5, [x5, #0x8]
    95a8:      	ldr	x6, [x6, #0x8]
    95ac:      	cmp	x5, x6
    95b0:      	b.ne	0x962c <_stogir.stack.validate-scope-inputs+0x41c>
    95b4:      	cmp	x2, x5
    95b8:      	b.gt	0x963c <_stogir.stack.validate-scope-inputs+0x42c>
    95bc:      	ldr	x2, [x0, #0x50]
    95c0:      	add	x2, x2, x3, lsl #2
    95c4:      	ldr	w2, [x2]
    95c8:      	sxtw	x2, w2
    95cc:      	cmp	x2, #0x0
    95d0:      	cset	w2, gt
    95d4:      	ubfx	x2, x2, #0, #8
    95d8:      	b	0x9640 <_stogir.stack.validate-scope-inputs+0x430>
    95dc:      	brk	#0
    95e0:      	b	0x95dc <_stogir.stack.validate-scope-inputs+0x3cc>
    95e4:      	orr	w1, w0, wzr
    95e8:      	ubfx	x1, x1, #0, #32
    95ec:      	ubfx	x1, x1, #8, #8
    95f0:      	cmp	x1, #0x6
    95f4:      	b.ne	0x9614 <_stogir.stack.validate-scope-inputs+0x404>
    95f8:      	uxtb	w0, w0
    95fc:      	cmp	x0, #0x48
    9600:      	b.eq	0x9614 <_stogir.stack.validate-scope-inputs+0x404>
    9604:      	movz	x1, #0x0, lsl #48
    9608:      	mov	x0, #0x8                ; =8
    960c:      	movz	x2, #0x0, lsl #48
    9610:      	b	0x9628 <_stogir.stack.validate-scope-inputs+0x418>
    9614:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009614:  ARM64_RELOC_PAGE21	l_stogir.449
    9618:      	ldr	x16, [x16]
		0000000000009618:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    961c:      	orr	x0, x16, xzr
    9620:      	mov	x1, #0x1                ; =1
    9624:      	mov	x2, #0x29               ; =41
    9628:      	b	0x954c <_stogir.stack.validate-scope-inputs+0x33c>
    962c:      	movz	x2, #0x0, lsl #48
    9630:      	b	0x9568 <_stogir.stack.validate-scope-inputs+0x358>
    9634:      	movz	x2, #0x0, lsl #48
    9638:      	b	0x9590 <_stogir.stack.validate-scope-inputs+0x380>
    963c:      	movz	x2, #0x0, lsl #48
    9640:      	b	0x9630 <_stogir.stack.validate-scope-inputs+0x420>
    9644:      	brk	#0
    9648:      	b	0x9644 <_stogir.stack.validate-scope-inputs+0x434>

000000000000964c <_stogir.stack.validate-inputs>:
    964c:      	sub	sp, sp, #0x110
    9650:      	str	x29, [sp]
    9654:      	str	x30, [sp, #0x8]
    9658:      	mov	x29, sp
    965c:      	str	x19, [sp, #0xb8]
    9660:      	str	x20, [sp, #0xc0]
    9664:      	str	x21, [sp, #0xc8]
    9668:      	str	x22, [sp, #0xd0]
    966c:      	str	x23, [sp, #0xd8]
    9670:      	str	x24, [sp, #0xe0]
    9674:      	str	x25, [sp, #0xe8]
    9678:      	str	x26, [sp, #0xf0]
    967c:      	str	x27, [sp, #0xf8]
    9680:      	str	x28, [sp, #0x100]
    9684:      	sxtw	x1, w1
    9688:      	cmp	x1, #0x51
    968c:      	cset	w19, eq
    9690:      	uxtb	w16, w19
    9694:      	cmp	w16, wzr
    9698:      	b.ne	0x9704 <_stogir.stack.validate-inputs+0xb8>
    969c:      	cmp	x1, #0x52
    96a0:      	b.eq	0x9704 <_stogir.stack.validate-inputs+0xb8>
    96a4:      	str	x8, [sp, #0x90]
    96a8:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		00000000000096a8:  ARM64_RELOC_PAGE21	l_stogir.450
    96ac:      	ldr	x16, [x16]
		00000000000096ac:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    96b0:      	orr	x0, x16, xzr
    96b4:      	mov	x2, #0x1                ; =1
    96b8:      	mov	x1, #0x29               ; =41
    96bc:      	ldr	x3, [sp, #0x90]
    96c0:      	str	x2, [x3]
    96c4:      	str	x0, [x3, #0x8]
    96c8:      	str	x1, [x3, #0x10]
    96cc:      	ldr	x19, [sp, #0xb8]
    96d0:      	ldr	x20, [sp, #0xc0]
    96d4:      	ldr	x21, [sp, #0xc8]
    96d8:      	ldr	x22, [sp, #0xd0]
    96dc:      	ldr	x23, [sp, #0xd8]
    96e0:      	ldr	x24, [sp, #0xe0]
    96e4:      	ldr	x25, [sp, #0xe8]
    96e8:      	ldr	x26, [sp, #0xf0]
    96ec:      	ldr	x27, [sp, #0xf8]
    96f0:      	ldr	x28, [sp, #0x100]
    96f4:      	ldr	x29, [sp]
    96f8:      	ldr	x30, [sp, #0x8]
    96fc:      	add	sp, sp, #0x110
    9700:      	ret
    9704:      	uxtb	w16, w19
    9708:      	cmp	w16, wzr
    970c:      	mov	x16, #0x6               ; =6
    9710:      	movz	x17, #0x0, lsl #48
    9714:      	csel	x1, x16, x17, ne
    9718:      	sxtw	x2, w2
    971c:      	sxtw	x1, w1
    9720:      	cmp	x2, x1
    9724:      	b.ne	0x9c58 <_stogir.stack.validate-inputs+0x60c>
    9728:      	sxtw	x20, w5
    972c:      	uxtb	w16, w19
    9730:      	cmp	w16, wzr
    9734:      	b.eq	0x9758 <_stogir.stack.validate-inputs+0x10c>
    9738:      	cmp	x20, #0x0
    973c:      	b.eq	0x9758 <_stogir.stack.validate-inputs+0x10c>
    9740:      	cmp	x20, #0x0
    9744:      	b.le	0x97f4 <_stogir.stack.validate-inputs+0x1a8>
    9748:      	sub	x1, x20, #0x1
    974c:      	and	x1, x1, x20
    9750:      	cmp	x1, #0x0
    9754:      	b.ne	0x97f4 <_stogir.stack.validate-inputs+0x1a8>
    9758:      	mov	w1, w3
    975c:      	mov	x21, x8
    9760:      	add	x8, sp, #0x10
    9764:      	mov	x22, x0
    9768:      	mov	w23, w3
    976c:      	mov	w24, w4
    9770:      	bl	0x9770 <_stogir.stack.validate-inputs+0x124>
		0000000000009770:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    9774:      	add	x16, sp, #0x10
    9778:      	ldr	w0, [x16]
    977c:      	lsr	x16, x0, #0
    9780:      	cmp	x16, #0x1
    9784:      	b.eq	0x97a0 <_stogir.stack.validate-inputs+0x154>
    9788:      	b.lo	0x9790 <_stogir.stack.validate-inputs+0x144>
    978c:      	b	0x97a4 <_stogir.stack.validate-inputs+0x158>
    9790:      	cmp	x16, #0x0
    9794:      	b.eq	0x979c <_stogir.stack.validate-inputs+0x150>
    9798:      	b	0x97a4 <_stogir.stack.validate-inputs+0x158>
    979c:      	b	0x97a8 <_stogir.stack.validate-inputs+0x15c>
    97a0:      	b	0x97c4 <_stogir.stack.validate-inputs+0x178>
    97a4:      	b	0x9a74 <_stogir.stack.validate-inputs+0x428>
    97a8:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		00000000000097a8:  ARM64_RELOC_PAGE21	l_stogir.451
    97ac:      	ldr	x16, [x16]
		00000000000097ac:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    97b0:      	orr	x0, x16, xzr
    97b4:      	str	x21, [sp, #0x90]
    97b8:      	mov	x2, #0x1                ; =1
    97bc:      	mov	x1, #0x1f               ; =31
    97c0:      	b	0x96bc <_stogir.stack.validate-inputs+0x70>
    97c4:      	sxtw	x23, w23
    97c8:      	add	x16, sp, #0x10
    97cc:      	ldr	x0, [x16, #0x8]
    97d0:      	cmp	x23, #0x0
    97d4:      	b.gt	0x97fc <_stogir.stack.validate-inputs+0x1b0>
    97d8:      	str	x21, [sp, #0x90]
    97dc:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		00000000000097dc:  ARM64_RELOC_PAGE21	l_stogir.452
    97e0:      	ldr	x16, [x16]
		00000000000097e0:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    97e4:      	orr	x0, x16, xzr
    97e8:      	mov	x2, #0x1                ; =1
    97ec:      	mov	x1, #0x1f               ; =31
    97f0:      	b	0x97c0 <_stogir.stack.validate-inputs+0x174>
    97f4:      	str	x8, [sp, #0x90]
    97f8:      	b	0x96a8 <_stogir.stack.validate-inputs+0x5c>
    97fc:      	uxtb	w0, w0
    9800:      	cmp	x0, #0x83
    9804:      	cset	w1, lt
    9808:      	uxtb	w16, w1
    980c:      	cmp	w16, wzr
    9810:      	b.eq	0x982c <_stogir.stack.validate-inputs+0x1e0>
    9814:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009814:  ARM64_RELOC_PAGE21	l_stogir.453
    9818:      	ldr	x16, [x16]
		0000000000009818:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    981c:      	orr	x2, x16, xzr
    9820:      	add	x2, x0, x2
    9824:      	ldrb	w2, [x2]
    9828:      	b	0x9830 <_stogir.stack.validate-inputs+0x1e4>
    982c:      	movz	x2, #0x0, lsl #48
    9830:      	uxtb	w2, w2
    9834:      	and	x2, x2, #0x1
    9838:      	uxtb	w2, w2
    983c:      	cmp	x2, #0x0
    9840:      	b.eq	0x9c60 <_stogir.stack.validate-inputs+0x614>
    9844:      	uxtb	w16, w1
    9848:      	cmp	w16, wzr
    984c:      	b.eq	0x9868 <_stogir.stack.validate-inputs+0x21c>
    9850:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009850:  ARM64_RELOC_PAGE21	l_stogir.453
    9854:      	ldr	x16, [x16]
		0000000000009854:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    9858:      	orr	x1, x16, xzr
    985c:      	add	x0, x0, x1
    9860:      	ldrb	w0, [x0]
    9864:      	b	0x986c <_stogir.stack.validate-inputs+0x220>
    9868:      	movz	x0, #0x0, lsl #48
    986c:      	uxtb	w0, w0
    9870:      	and	x0, x0, #0x4
    9874:      	uxtb	w0, w0
    9878:      	cmp	x0, #0x0
    987c:      	cset	w0, eq
    9880:      	uxtb	w16, w0
    9884:      	cmp	w16, wzr
    9888:      	cset	x0, eq
    988c:      	cmp	x0, #0x0
    9890:      	b.ne	0x9c68 <_stogir.stack.validate-inputs+0x61c>
    9894:      	add	x8, sp, #0x40
    9898:      	mov	x0, x22
    989c:      	mov	w1, w24
    98a0:      	bl	0x98a0 <_stogir.stack.validate-inputs+0x254>
		00000000000098a0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    98a4:      	add	x16, sp, #0x40
    98a8:      	ldr	w0, [x16]
    98ac:      	lsr	x16, x0, #0
    98b0:      	cmp	x16, #0x1
    98b4:      	b.eq	0x98d0 <_stogir.stack.validate-inputs+0x284>
    98b8:      	b.lo	0x98c0 <_stogir.stack.validate-inputs+0x274>
    98bc:      	b	0x98d4 <_stogir.stack.validate-inputs+0x288>
    98c0:      	cmp	x16, #0x0
    98c4:      	b.eq	0x98cc <_stogir.stack.validate-inputs+0x280>
    98c8:      	b	0x98d4 <_stogir.stack.validate-inputs+0x288>
    98cc:      	b	0x98d8 <_stogir.stack.validate-inputs+0x28c>
    98d0:      	b	0x98f4 <_stogir.stack.validate-inputs+0x2a8>
    98d4:      	b	0x9b60 <_stogir.stack.validate-inputs+0x514>
    98d8:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		00000000000098d8:  ARM64_RELOC_PAGE21	l_stogir.454
    98dc:      	ldr	x16, [x16]
		00000000000098dc:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    98e0:      	orr	x0, x16, xzr
    98e4:      	str	x21, [sp, #0x90]
    98e8:      	mov	x2, #0x1                ; =1
    98ec:      	mov	x1, #0x18               ; =24
    98f0:      	b	0x97f0 <_stogir.stack.validate-inputs+0x1a4>
    98f4:      	add	x16, sp, #0x40
    98f8:      	ldr	x0, [x16, #0x8]
    98fc:      	orr	w1, w0, wzr
    9900:      	ubfx	x1, x1, #0, #32
    9904:      	ubfx	x1, x1, #8, #8
    9908:      	cmp	x1, #0x1
    990c:      	b.lt	0x9c70 <_stogir.stack.validate-inputs+0x624>
    9910:      	cmp	x1, #0xb
    9914:      	b.gt	0x9c78 <_stogir.stack.validate-inputs+0x62c>
    9918:      	uxtb	w0, w0
    991c:      	cmp	x0, #0x48
    9920:      	b.eq	0x9c80 <_stogir.stack.validate-inputs+0x634>
    9924:      	sxtw	x0, w24
    9928:      	cmp	x1, #0x0
    992c:      	cset	w23, eq
    9930:      	cmp	x1, #0x1
    9934:      	cset	w25, eq
    9938:      	cmp	x1, #0x2
    993c:      	cset	w26, eq
    9940:      	cmp	x1, #0x7
    9944:      	cset	w27, eq
    9948:      	cmp	x1, #0x8
    994c:      	cset	w28, eq
    9950:      	cmp	x1, #0x3
    9954:      	cset	w2, eq
    9958:      	cmp	x1, #0x9
    995c:      	cset	w3, eq
    9960:      	cmp	x1, #0x4
    9964:      	cset	w4, eq
    9968:      	cmp	x1, #0xa
    996c:      	cset	w5, eq
    9970:      	cmp	x1, #0xd
    9974:      	cset	w6, eq
    9978:      	cmp	x1, #0x5
    997c:      	cset	w7, eq
    9980:      	cmp	x1, #0xb
    9984:      	cset	w8, eq
    9988:      	cmp	x1, #0xc
    998c:      	cset	w9, eq
    9990:      	cmp	x1, #0x6
    9994:      	cset	w1, eq
    9998:      	uxtb	w16, w1
    999c:      	cmp	w16, wzr
    99a0:      	mov	x16, #0x8               ; =8
    99a4:      	movn	x17, #0x0, lsl #48
    99a8:      	csel	x1, x16, x17, ne
    99ac:      	cmp	x0, #0x0
    99b0:      	b.ge	0x9c88 <_stogir.stack.validate-inputs+0x63c>
    99b4:      	uxtb	w16, w19
    99b8:      	cmp	w16, wzr
    99bc:      	b.eq	0x99c8 <_stogir.stack.validate-inputs+0x37c>
    99c0:      	cmp	x20, #0x10
    99c4:      	b.gt	0x99cc <_stogir.stack.validate-inputs+0x380>
    99c8:      	mov	x20, #0x10              ; =16
    99cc:      	mov	x0, x22
    99d0:      	mov	w19, w2
    99d4:      	mov	x2, x20
    99d8:      	mov	w20, w3
    99dc:      	mov	w22, w4
    99e0:      	str	w7, [sp, #0x98]
    99e4:      	str	w8, [sp, #0xa0]
    99e8:      	add	x8, sp, #0x70
    99ec:      	str	w9, [sp, #0xa8]
    99f0:      	str	x1, [sp, #0xb0]
    99f4:      	mov	w1, w24
    99f8:      	mov	w24, w5
    99fc:      	str	x21, [sp, #0x90]
    9a00:      	mov	w21, w6
    9a04:      	bl	0x9a04 <_stogir.stack.validate-inputs+0x3b8>
		0000000000009a04:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    9a08:      	add	x16, sp, #0x70
    9a0c:      	ldr	w0, [x16]
    9a10:      	lsr	x16, x0, #0
    9a14:      	cmp	x16, #0x1
    9a18:      	b.eq	0x9a34 <_stogir.stack.validate-inputs+0x3e8>
    9a1c:      	b.lo	0x9a24 <_stogir.stack.validate-inputs+0x3d8>
    9a20:      	b	0x9a38 <_stogir.stack.validate-inputs+0x3ec>
    9a24:      	cmp	x16, #0x0
    9a28:      	b.eq	0x9a30 <_stogir.stack.validate-inputs+0x3e4>
    9a2c:      	b	0x9a38 <_stogir.stack.validate-inputs+0x3ec>
    9a30:      	b	0x9b68 <_stogir.stack.validate-inputs+0x51c>
    9a34:      	b	0x9a3c <_stogir.stack.validate-inputs+0x3f0>
    9a38:      	b	0x9c3c <_stogir.stack.validate-inputs+0x5f0>
    9a3c:      	add	x16, sp, #0x70
    9a40:      	orr	x0, x16, xzr
    9a44:      	add	x1, x0, #0x8
    9a48:      	add	x16, sp, #0x70
    9a4c:      	ldr	x0, [x16, #0x8]
    9a50:      	ldr	x1, [x1, #0x8]
    9a54:      	mov	x2, #0x1                ; =1
    9a58:      	b	0x9ac4 <_stogir.stack.validate-inputs+0x478>
    9a5c:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009a5c:  ARM64_RELOC_PAGE21	l_stogir.455
    9a60:      	ldr	x16, [x16]
		0000000000009a60:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    9a64:      	orr	x0, x16, xzr
    9a68:      	mov	x2, #0x1                ; =1
    9a6c:      	mov	x1, #0x29               ; =41
    9a70:      	b	0x98f0 <_stogir.stack.validate-inputs+0x2a4>
    9a74:      	brk	#0
    9a78:      	b	0x9a74 <_stogir.stack.validate-inputs+0x428>
    9a7c:      	mov	x3, #0x1                ; =1
    9a80:      	sxtw	x3, w3
    9a84:      	and	x0, x3, #0xffffffff
    9a88:      	movz	x2, #0x0, lsl #48
    9a8c:      	movz	x1, #0x0, lsl #48
    9a90:      	b	0x9a70 <_stogir.stack.validate-inputs+0x424>
    9a94:      	uxtb	w16, w23
    9a98:      	cmp	w16, wzr
    9a9c:      	b.eq	0x9ac8 <_stogir.stack.validate-inputs+0x47c>
    9aa0:      	movz	x3, #0x0, lsl #48
    9aa4:      	b	0x9a80 <_stogir.stack.validate-inputs+0x434>
    9aa8:      	mov	x16, #0x1               ; =1
    9aac:      	str	x16, [sp, #0xb0]
    9ab0:      	ldr	x3, [sp, #0xb0]
    9ab4:      	sxtw	x3, w3
    9ab8:      	and	x0, x3, #0xffffffff
    9abc:      	movz	x2, #0x0, lsl #48
    9ac0:      	movz	x1, #0x0, lsl #48
    9ac4:      	b	0x9a90 <_stogir.stack.validate-inputs+0x444>
    9ac8:      	uxtb	w16, w25
    9acc:      	cmp	w16, wzr
    9ad0:      	b.ne	0x9a7c <_stogir.stack.validate-inputs+0x430>
    9ad4:      	uxtb	w16, w26
    9ad8:      	cmp	w16, wzr
    9adc:      	b.ne	0x9a7c <_stogir.stack.validate-inputs+0x430>
    9ae0:      	uxtb	w16, w27
    9ae4:      	cmp	w16, wzr
    9ae8:      	b.ne	0x9a7c <_stogir.stack.validate-inputs+0x430>
    9aec:      	uxtb	w16, w28
    9af0:      	cmp	w16, wzr
    9af4:      	b.ne	0x9a7c <_stogir.stack.validate-inputs+0x430>
    9af8:      	uxtb	w16, w19
    9afc:      	cmp	w16, wzr
    9b00:      	b.ne	0x9c28 <_stogir.stack.validate-inputs+0x5dc>
    9b04:      	uxtb	w16, w20
    9b08:      	cmp	w16, wzr
    9b0c:      	b.ne	0x9c28 <_stogir.stack.validate-inputs+0x5dc>
    9b10:      	uxtb	w16, w22
    9b14:      	cmp	w16, wzr
    9b18:      	b.ne	0x9c44 <_stogir.stack.validate-inputs+0x5f8>
    9b1c:      	uxtb	w16, w24
    9b20:      	cmp	w16, wzr
    9b24:      	b.ne	0x9c44 <_stogir.stack.validate-inputs+0x5f8>
    9b28:      	uxtb	w16, w21
    9b2c:      	cmp	w16, wzr
    9b30:      	b.ne	0x9c44 <_stogir.stack.validate-inputs+0x5f8>
    9b34:      	uxtb	w16, w0
    9b38:      	cmp	w16, wzr
    9b3c:      	b.ne	0x9b58 <_stogir.stack.validate-inputs+0x50c>
    9b40:      	uxtb	w16, w1
    9b44:      	cmp	w16, wzr
    9b48:      	b.ne	0x9b58 <_stogir.stack.validate-inputs+0x50c>
    9b4c:      	uxtb	w16, w2
    9b50:      	cmp	w16, wzr
    9b54:      	b.eq	0x9b5c <_stogir.stack.validate-inputs+0x510>
    9b58:      	mov	x3, #0x8                ; =8
    9b5c:      	b	0x9c48 <_stogir.stack.validate-inputs+0x5fc>
    9b60:      	brk	#0
    9b64:      	b	0x9b60 <_stogir.stack.validate-inputs+0x514>
    9b68:      	uxtb	w16, w23
    9b6c:      	cmp	w16, wzr
    9b70:      	b.eq	0x9b80 <_stogir.stack.validate-inputs+0x534>
    9b74:      	movz	x16, #0x0, lsl #48
    9b78:      	str	x16, [sp, #0xb0]
    9b7c:      	b	0x9ab0 <_stogir.stack.validate-inputs+0x464>
    9b80:      	uxtb	w16, w25
    9b84:      	cmp	w16, wzr
    9b88:      	b.ne	0x9aa8 <_stogir.stack.validate-inputs+0x45c>
    9b8c:      	uxtb	w16, w26
    9b90:      	cmp	w16, wzr
    9b94:      	b.ne	0x9aa8 <_stogir.stack.validate-inputs+0x45c>
    9b98:      	uxtb	w16, w27
    9b9c:      	cmp	w16, wzr
    9ba0:      	b.ne	0x9aa8 <_stogir.stack.validate-inputs+0x45c>
    9ba4:      	uxtb	w16, w28
    9ba8:      	cmp	w16, wzr
    9bac:      	b.ne	0x9aa8 <_stogir.stack.validate-inputs+0x45c>
    9bb0:      	uxtb	w16, w19
    9bb4:      	cmp	w16, wzr
    9bb8:      	b.ne	0x9c30 <_stogir.stack.validate-inputs+0x5e4>
    9bbc:      	uxtb	w16, w20
    9bc0:      	cmp	w16, wzr
    9bc4:      	b.ne	0x9c30 <_stogir.stack.validate-inputs+0x5e4>
    9bc8:      	uxtb	w16, w22
    9bcc:      	cmp	w16, wzr
    9bd0:      	b.ne	0x9c4c <_stogir.stack.validate-inputs+0x600>
    9bd4:      	uxtb	w16, w24
    9bd8:      	cmp	w16, wzr
    9bdc:      	b.ne	0x9c4c <_stogir.stack.validate-inputs+0x600>
    9be0:      	uxtb	w16, w21
    9be4:      	cmp	w16, wzr
    9be8:      	b.ne	0x9c4c <_stogir.stack.validate-inputs+0x600>
    9bec:      	ldr	w0, [sp, #0x98]
    9bf0:      	uxtb	w16, w0
    9bf4:      	cmp	w16, wzr
    9bf8:      	b.ne	0x9c1c <_stogir.stack.validate-inputs+0x5d0>
    9bfc:      	ldr	w1, [sp, #0xa0]
    9c00:      	uxtb	w16, w1
    9c04:      	cmp	w16, wzr
    9c08:      	b.ne	0x9c1c <_stogir.stack.validate-inputs+0x5d0>
    9c0c:      	ldr	w2, [sp, #0xa8]
    9c10:      	uxtb	w16, w2
    9c14:      	cmp	w16, wzr
    9c18:      	b.eq	0x9c24 <_stogir.stack.validate-inputs+0x5d8>
    9c1c:      	mov	x16, #0x8               ; =8
    9c20:      	str	x16, [sp, #0xb0]
    9c24:      	b	0x9c54 <_stogir.stack.validate-inputs+0x608>
    9c28:      	mov	x3, #0x2                ; =2
    9c2c:      	b	0x9a80 <_stogir.stack.validate-inputs+0x434>
    9c30:      	mov	x16, #0x2               ; =2
    9c34:      	str	x16, [sp, #0xb0]
    9c38:      	b	0x9ab0 <_stogir.stack.validate-inputs+0x464>
    9c3c:      	brk	#0
    9c40:      	b	0x9c3c <_stogir.stack.validate-inputs+0x5f0>
    9c44:      	mov	x3, #0x4                ; =4
    9c48:      	b	0x9c2c <_stogir.stack.validate-inputs+0x5e0>
    9c4c:      	mov	x16, #0x4               ; =4
    9c50:      	str	x16, [sp, #0xb0]
    9c54:      	b	0x9c38 <_stogir.stack.validate-inputs+0x5ec>
    9c58:      	str	x8, [sp, #0x90]
    9c5c:      	b	0x96a8 <_stogir.stack.validate-inputs+0x5c>
    9c60:      	str	x21, [sp, #0x90]
    9c64:      	b	0x97dc <_stogir.stack.validate-inputs+0x190>
    9c68:      	str	x21, [sp, #0x90]
    9c6c:      	b	0x97dc <_stogir.stack.validate-inputs+0x190>
    9c70:      	str	x21, [sp, #0x90]
    9c74:      	b	0x9a5c <_stogir.stack.validate-inputs+0x410>
    9c78:      	str	x21, [sp, #0x90]
    9c7c:      	b	0x9a5c <_stogir.stack.validate-inputs+0x410>
    9c80:      	str	x21, [sp, #0x90]
    9c84:      	b	0x9a5c <_stogir.stack.validate-inputs+0x410>
    9c88:      	str	x21, [sp, #0x90]
    9c8c:      	mov	w19, w2
    9c90:      	mov	w20, w3
    9c94:      	mov	x3, x1
    9c98:      	mov	w22, w4
    9c9c:      	mov	w24, w5
    9ca0:      	mov	w21, w6
    9ca4:      	mov	w0, w7
    9ca8:      	mov	w1, w8
    9cac:      	mov	w2, w9
    9cb0:      	b	0x9a94 <_stogir.stack.validate-inputs+0x448>

0000000000009cb4 <_stogir.locals.shape>:
    9cb4:      	sub	sp, sp, #0x40
    9cb8:      	str	x29, [sp]
    9cbc:      	str	x30, [sp, #0x8]
    9cc0:      	mov	x29, sp
    9cc4:      	str	x19, [sp, #0x20]
    9cc8:      	str	x20, [sp, #0x28]
    9ccc:      	str	x21, [sp, #0x30]
    9cd0:      	str	x22, [sp, #0x38]
    9cd4:      	sxtw	x19, w1
    9cd8:      	lsl	x20, x19, #2
    9cdc:      	cmp	x19, #0x0
    9ce0:      	cset	w1, gt
    9ce4:      	movz	x16, #0x0, lsl #48
    9ce8:      	sub	x3, x16, x19
    9cec:      	sub	x4, x3, #0x1
    9cf0:      	uxtb	w16, w1
    9cf4:      	cmp	w16, wzr
    9cf8:      	b.eq	0x9d38 <_stogir.locals.shape+0x84>
    9cfc:      	ldr	x3, [x0, #0x8]
    9d00:      	cmp	x19, x3
    9d04:      	b.ge	0x9da0 <_stogir.locals.shape+0xec>
    9d08:      	add	x3, x0, #0x78
    9d0c:      	ldr	x3, [x3, #0x8]
    9d10:      	cmp	x19, x3
    9d14:      	b.ge	0x9f38 <_stogir.locals.shape+0x284>
    9d18:      	ldr	x3, [x0, #0x78]
    9d1c:      	add	x3, x20, x3
    9d20:      	ldr	w3, [x3]
    9d24:      	sxtw	x3, w3
    9d28:      	cmp	x3, #0x0
    9d2c:      	cset	w3, ge
    9d30:      	ubfx	x3, x3, #0, #8
    9d34:      	b	0x9f3c <_stogir.locals.shape+0x288>
    9d38:      	cmp	x19, #0x0
    9d3c:      	b.ge	0x9da8 <_stogir.locals.shape+0xf4>
    9d40:      	add	x5, x0, #0x28
    9d44:      	add	x6, x0, #0x50
    9d48:      	ldr	x5, [x5, #0x8]
    9d4c:      	ldr	x6, [x6, #0x8]
    9d50:      	cmp	x5, x6
    9d54:      	b.ne	0x9d80 <_stogir.locals.shape+0xcc>
    9d58:      	cmp	x3, x5
    9d5c:      	b.gt	0xa03c <_stogir.locals.shape+0x388>
    9d60:      	ldr	x3, [x0, #0x50]
    9d64:      	add	x3, x3, x4, lsl #2
    9d68:      	ldr	w3, [x3]
    9d6c:      	sxtw	x3, w3
    9d70:      	cmp	x3, #0x0
    9d74:      	cset	w3, gt
    9d78:      	ubfx	x3, x3, #0, #8
    9d7c:      	b	0xa040 <_stogir.locals.shape+0x38c>
    9d80:      	movz	x3, #0x0, lsl #48
    9d84:      	b	0x9dac <_stogir.locals.shape+0xf8>
    9d88:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009d88:  ARM64_RELOC_PAGE21	l_stogir.456
    9d8c:      	ldr	x16, [x16]
		0000000000009d8c:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9d90:      	orr	x0, x16, xzr
    9d94:      	mov	x2, #0x1                ; =1
    9d98:      	mov	x1, #0x1c               ; =28
    9d9c:      	b	0x9e40 <_stogir.locals.shape+0x18c>
    9da0:      	movz	x3, #0x0, lsl #48
    9da4:      	b	0x9dac <_stogir.locals.shape+0xf8>
    9da8:      	movz	x3, #0x0, lsl #48
    9dac:      	cmp	x3, #0x0
    9db0:      	b.eq	0x9dec <_stogir.locals.shape+0x138>
    9db4:      	uxtb	w16, w1
    9db8:      	cmp	w16, wzr
    9dbc:      	b.eq	0x9dd4 <_stogir.locals.shape+0x120>
    9dc0:      	ldr	x1, [x0]
    9dc4:      	add	x1, x1, x19, lsl #4
    9dc8:      	ldr	x3, [x1]
    9dcc:      	ldr	x1, [x1, #0x8]
    9dd0:      	b	0x9de4 <_stogir.locals.shape+0x130>
    9dd4:      	ldr	x1, [x0, #0x28]
    9dd8:      	add	x1, x1, x4, lsl #4
    9ddc:      	ldr	x3, [x1]
    9de0:      	ldr	x1, [x1, #0x8]
    9de4:      	mov	x4, #0x1                ; =1
    9de8:      	b	0x9df8 <_stogir.locals.shape+0x144>
    9dec:      	movz	x4, #0x0, lsl #48
    9df0:      	movz	x3, #0x0, lsl #48
    9df4:      	movz	x1, #0x0, lsl #48
    9df8:      	ubfx	x4, x4, #0, #32
    9dfc:      	lsr	x16, x4, #0
    9e00:      	cmp	x16, #0x1
    9e04:      	b.eq	0x9e20 <_stogir.locals.shape+0x16c>
    9e08:      	b.lo	0x9e10 <_stogir.locals.shape+0x15c>
    9e0c:      	b	0x9e24 <_stogir.locals.shape+0x170>
    9e10:      	cmp	x16, #0x0
    9e14:      	b.eq	0x9e1c <_stogir.locals.shape+0x168>
    9e18:      	b	0x9e24 <_stogir.locals.shape+0x170>
    9e1c:      	b	0x9e28 <_stogir.locals.shape+0x174>
    9e20:      	b	0x9e6c <_stogir.locals.shape+0x1b8>
    9e24:      	b	0xa04c <_stogir.locals.shape+0x398>
    9e28:      	adrp	x16, 0x9000 <_stogir.stack.valid-frame-object-inputs?+0x200>
		0000000000009e28:  ARM64_RELOC_PAGE21	l_stogir.457
    9e2c:      	ldr	x16, [x16]
		0000000000009e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    9e30:      	orr	x0, x16, xzr
    9e34:      	mov	x21, x8
    9e38:      	mov	x2, #0x1                ; =1
    9e3c:      	mov	x1, #0x16               ; =22
    9e40:      	str	x2, [x21]
    9e44:      	str	x0, [x21, #0x8]
    9e48:      	str	x1, [x21, #0x10]
    9e4c:      	ldr	x19, [sp, #0x20]
    9e50:      	ldr	x20, [sp, #0x28]
    9e54:      	ldr	x21, [sp, #0x30]
    9e58:      	ldr	x22, [sp, #0x38]
    9e5c:      	ldr	x29, [sp]
    9e60:      	ldr	x30, [sp, #0x8]
    9e64:      	add	sp, sp, #0x40
    9e68:      	ret
    9e6c:      	orr	w4, w3, wzr
    9e70:      	add	x16, sp, #0x10
    9e74:      	str	x3, [x16]
    9e78:      	ubfx	x4, x4, #0, #32
    9e7c:      	add	x16, sp, #0x10
    9e80:      	str	x1, [x16, #0x8]
    9e84:      	ubfx	x1, x4, #8, #8
    9e88:      	mov	x21, x8
    9e8c:      	mov	x22, x0
    9e90:      	mov	w0, w1
    9e94:      	mov	w1, w2
    9e98:      	bl	0x9e98 <_stogir.locals.shape+0x1e4>
		0000000000009e98:  ARM64_RELOC_BRANCH26	_stogir.types.size
    9e9c:      	add	x16, sp, #0x10
    9ea0:      	ldr	w1, [x16, #0xc]
    9ea4:      	sxtw	x0, w0
    9ea8:      	sxtw	x1, w1
    9eac:      	cmp	x1, #0x0
    9eb0:      	b.ne	0x9eb8 <_stogir.locals.shape+0x204>
    9eb4:      	mov	x1, x0
    9eb8:      	add	x16, sp, #0x10
    9ebc:      	ldr	w2, [x16, #0x8]
    9ec0:      	sxtw	x2, w2
    9ec4:      	cmp	x2, #0x0
    9ec8:      	cset	w3, eq
    9ecc:      	ubfx	x3, x3, #0, #8
    9ed0:      	cmp	x2, #0x0
    9ed4:      	b.le	0x9f78 <_stogir.locals.shape+0x2c4>
    9ed8:      	add	x4, x22, #0x110
    9edc:      	add	x5, x4, #0x28
    9ee0:      	ldr	x5, [x5, #0x8]
    9ee4:      	cmp	x2, x5
    9ee8:      	b.gt	0x9f40 <_stogir.locals.shape+0x28c>
    9eec:      	sub	x2, x2, #0x1
    9ef0:      	mov	x17, #0x18              ; =24
    9ef4:      	mul	x2, x2, x17
    9ef8:      	ldr	x5, [x4, #0x28]
    9efc:      	add	x2, x2, x5
    9f00:      	ldr	x5, [x2]
    9f04:      	ldr	x2, [x2, #0x8]
    9f08:      	ldr	x4, [x4, #0x8]
    9f0c:      	cmp	x5, #0x0
    9f10:      	b.lt	0xa044 <_stogir.locals.shape+0x390>
    9f14:      	cmp	x5, x4
    9f18:      	b.gt	0xa044 <_stogir.locals.shape+0x390>
    9f1c:      	cmp	x2, #0x0
    9f20:      	b.lt	0xa044 <_stogir.locals.shape+0x390>
    9f24:      	sub	x4, x4, x5
    9f28:      	cmp	x2, x4
    9f2c:      	b.gt	0xa044 <_stogir.locals.shape+0x390>
    9f30:      	mov	x2, #0x1                ; =1
    9f34:      	b	0xa048 <_stogir.locals.shape+0x394>
    9f38:      	movz	x3, #0x0, lsl #48
    9f3c:      	b	0x9da4 <_stogir.locals.shape+0xf0>
    9f40:      	movz	x2, #0x0, lsl #48
    9f44:      	ubfx	x2, x2, #0, #32
    9f48:      	lsr	x16, x2, #0
    9f4c:      	cmp	x16, #0x1
    9f50:      	b.eq	0x9f6c <_stogir.locals.shape+0x2b8>
    9f54:      	b.lo	0x9f5c <_stogir.locals.shape+0x2a8>
    9f58:      	b	0x9f70 <_stogir.locals.shape+0x2bc>
    9f5c:      	cmp	x16, #0x0
    9f60:      	b.eq	0x9f68 <_stogir.locals.shape+0x2b4>
    9f64:      	b	0x9f70 <_stogir.locals.shape+0x2bc>
    9f68:      	b	0x9f78 <_stogir.locals.shape+0x2c4>
    9f6c:      	b	0x9f74 <_stogir.locals.shape+0x2c0>
    9f70:      	b	0xa054 <_stogir.locals.shape+0x3a0>
    9f74:      	mov	x3, #0x1                ; =1
    9f78:      	cmp	x19, #0x0
    9f7c:      	b.le	0x9d88 <_stogir.locals.shape+0xd4>
    9f80:      	add	x16, sp, #0x10
    9f84:      	ldr	w2, [x16]
    9f88:      	uxtb	w2, w2
    9f8c:      	cmp	x2, #0x48
    9f90:      	b.ne	0x9d88 <_stogir.locals.shape+0xd4>
    9f94:      	ldr	x2, [x22, #0x78]
    9f98:      	add	x2, x20, x2
    9f9c:      	ldr	w2, [x2]
    9fa0:      	sxtw	x2, w2
    9fa4:      	cmp	x2, #0x3
    9fa8:      	b.ne	0x9d88 <_stogir.locals.shape+0xd4>
    9fac:      	cmp	x0, #0x0
    9fb0:      	b.le	0x9d88 <_stogir.locals.shape+0xd4>
    9fb4:      	cmp	x3, #0x0
    9fb8:      	b.eq	0x9d88 <_stogir.locals.shape+0xd4>
    9fbc:      	cmp	x1, #0x0
    9fc0:      	b.le	0x9d88 <_stogir.locals.shape+0xd4>
    9fc4:      	sub	x2, x1, #0x1
    9fc8:      	and	x2, x2, x1
    9fcc:      	cmp	x2, #0x0
    9fd0:      	b.ne	0x9d88 <_stogir.locals.shape+0xd4>
    9fd4:      	add	x16, sp, #0x10
    9fd8:      	ldr	w2, [x16, #0x4]
    9fdc:      	sxtw	x2, w2
    9fe0:      	cmp	x2, #0x0
    9fe4:      	cset	w3, gt
    9fe8:      	movz	x16, #0x0, lsl #48
    9fec:      	sub	x4, x16, x2
    9ff0:      	sub	x5, x4, #0x1
    9ff4:      	uxtb	w16, w3
    9ff8:      	cmp	w16, wzr
    9ffc:      	b.eq	0xa074 <_stogir.locals.shape+0x3c0>
    a000:      	ldr	x4, [x22, #0x8]
    a004:      	cmp	x2, x4
    a008:      	b.ge	0xa0bc <_stogir.locals.shape+0x408>
    a00c:      	add	x4, x22, #0x78
    a010:      	ldr	x4, [x4, #0x8]
    a014:      	cmp	x2, x4
    a018:      	b.ge	0xa190 <_stogir.locals.shape+0x4dc>
    a01c:      	ldr	x4, [x22, #0x78]
    a020:      	add	x4, x4, x2, lsl #2
    a024:      	ldr	w4, [x4]
    a028:      	sxtw	x4, w4
    a02c:      	cmp	x4, #0x0
    a030:      	cset	w4, ge
    a034:      	ubfx	x4, x4, #0, #8
    a038:      	b	0xa194 <_stogir.locals.shape+0x4e0>
    a03c:      	movz	x3, #0x0, lsl #48
    a040:      	b	0x9d84 <_stogir.locals.shape+0xd0>
    a044:      	movz	x2, #0x0, lsl #48
    a048:      	b	0x9f44 <_stogir.locals.shape+0x290>
    a04c:      	brk	#0
    a050:      	b	0xa04c <_stogir.locals.shape+0x398>
    a054:      	brk	#0
    a058:      	b	0xa054 <_stogir.locals.shape+0x3a0>
    a05c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a05c:  ARM64_RELOC_PAGE21	l_stogir.458
    a060:      	ldr	x16, [x16]
		000000000000a060:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    a064:      	orr	x0, x16, xzr
    a068:      	mov	x2, #0x1                ; =1
    a06c:      	mov	x1, #0x2c               ; =44
    a070:      	b	0x9d9c <_stogir.locals.shape+0xe8>
    a074:      	cmp	x2, #0x0
    a078:      	b.ge	0xa0c4 <_stogir.locals.shape+0x410>
    a07c:      	add	x6, x22, #0x28
    a080:      	add	x7, x22, #0x50
    a084:      	ldr	x6, [x6, #0x8]
    a088:      	ldr	x7, [x7, #0x8]
    a08c:      	cmp	x6, x7
    a090:      	b.ne	0xa188 <_stogir.locals.shape+0x4d4>
    a094:      	cmp	x4, x6
    a098:      	b.gt	0xa198 <_stogir.locals.shape+0x4e4>
    a09c:      	ldr	x4, [x22, #0x50]
    a0a0:      	add	x4, x4, x5, lsl #2
    a0a4:      	ldr	w4, [x4]
    a0a8:      	sxtw	x4, w4
    a0ac:      	cmp	x4, #0x0
    a0b0:      	cset	w4, gt
    a0b4:      	ubfx	x4, x4, #0, #8
    a0b8:      	b	0xa19c <_stogir.locals.shape+0x4e8>
    a0bc:      	movz	x4, #0x0, lsl #48
    a0c0:      	b	0xa0c8 <_stogir.locals.shape+0x414>
    a0c4:      	movz	x4, #0x0, lsl #48
    a0c8:      	cmp	x4, #0x0
    a0cc:      	b.eq	0xa100 <_stogir.locals.shape+0x44c>
    a0d0:      	uxtb	w16, w3
    a0d4:      	cmp	w16, wzr
    a0d8:      	b.eq	0xa0ec <_stogir.locals.shape+0x438>
    a0dc:      	ldr	x3, [x22]
    a0e0:      	add	x2, x3, x2, lsl #4
    a0e4:      	ldr	x2, [x2]
    a0e8:      	b	0xa0f8 <_stogir.locals.shape+0x444>
    a0ec:      	ldr	x2, [x22, #0x28]
    a0f0:      	add	x2, x2, x5, lsl #4
    a0f4:      	ldr	x2, [x2]
    a0f8:      	mov	x3, #0x1                ; =1
    a0fc:      	b	0xa108 <_stogir.locals.shape+0x454>
    a100:      	movz	x3, #0x0, lsl #48
    a104:      	movz	x2, #0x0, lsl #48
    a108:      	ubfx	x3, x3, #0, #32
    a10c:      	lsr	x16, x3, #0
    a110:      	cmp	x16, #0x1
    a114:      	b.eq	0xa130 <_stogir.locals.shape+0x47c>
    a118:      	b.lo	0xa120 <_stogir.locals.shape+0x46c>
    a11c:      	b	0xa134 <_stogir.locals.shape+0x480>
    a120:      	cmp	x16, #0x0
    a124:      	b.eq	0xa12c <_stogir.locals.shape+0x478>
    a128:      	b	0xa134 <_stogir.locals.shape+0x480>
    a12c:      	b	0xa138 <_stogir.locals.shape+0x484>
    a130:      	b	0xa150 <_stogir.locals.shape+0x49c>
    a134:      	b	0xa1d4 <_stogir.locals.shape+0x520>
    a138:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a138:  ARM64_RELOC_PAGE21	l_stogir.459
    a13c:      	ldr	x16, [x16]
		000000000000a13c:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    a140:      	orr	x0, x16, xzr
    a144:      	mov	x2, #0x1                ; =1
    a148:      	mov	x1, #0x1d               ; =29
    a14c:      	b	0xa070 <_stogir.locals.shape+0x3bc>
    a150:      	add	x16, sp, #0x10
    a154:      	ldr	w3, [x16, #0x4]
    a158:      	sxtw	x3, w3
    a15c:      	cmp	x3, #0x0
    a160:      	b.le	0xa05c <_stogir.locals.shape+0x3a8>
    a164:      	uxtb	w2, w2
    a168:      	cmp	x2, #0x83
    a16c:      	b.ge	0xa1a0 <_stogir.locals.shape+0x4ec>
    a170:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a170:  ARM64_RELOC_PAGE21	l_stogir.460
    a174:      	ldr	x16, [x16]
		000000000000a174:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    a178:      	orr	x3, x16, xzr
    a17c:      	add	x2, x2, x3
    a180:      	ldrb	w2, [x2]
    a184:      	b	0xa1a4 <_stogir.locals.shape+0x4f0>
    a188:      	movz	x4, #0x0, lsl #48
    a18c:      	b	0xa0c8 <_stogir.locals.shape+0x414>
    a190:      	movz	x4, #0x0, lsl #48
    a194:      	b	0xa0c0 <_stogir.locals.shape+0x40c>
    a198:      	movz	x4, #0x0, lsl #48
    a19c:      	b	0xa18c <_stogir.locals.shape+0x4d8>
    a1a0:      	movz	x2, #0x0, lsl #48
    a1a4:      	uxtb	w2, w2
    a1a8:      	and	x2, x2, #0x2
    a1ac:      	uxtb	w2, w2
    a1b0:      	cmp	x2, #0x0
    a1b4:      	cset	w2, eq
    a1b8:      	uxtb	w16, w2
    a1bc:      	cmp	w16, wzr
    a1c0:      	cset	x2, eq
    a1c4:      	cmp	x2, #0x0
    a1c8:      	b.eq	0xa05c <_stogir.locals.shape+0x3a8>
    a1cc:      	movz	x2, #0x0, lsl #48
    a1d0:      	b	0xa070 <_stogir.locals.shape+0x3bc>
    a1d4:      	brk	#0
    a1d8:      	b	0xa1d4 <_stogir.locals.shape+0x520>

000000000000a1dc <_stogir.conversion.policy>:
    a1dc:      	sub	sp, sp, #0x70
    a1e0:      	str	x29, [sp]
    a1e4:      	str	x30, [sp, #0x8]
    a1e8:      	mov	x29, sp
    a1ec:      	str	x19, [sp, #0x20]
    a1f0:      	str	x20, [sp, #0x28]
    a1f4:      	str	x21, [sp, #0x30]
    a1f8:      	str	x22, [sp, #0x38]
    a1fc:      	str	x23, [sp, #0x40]
    a200:      	str	x24, [sp, #0x48]
    a204:      	str	x25, [sp, #0x50]
    a208:      	str	x26, [sp, #0x58]
    a20c:      	str	x27, [sp, #0x60]
    a210:      	str	x28, [sp, #0x68]
    a214:      	sxtw	x19, w0
    a218:      	sxtw	x20, w1
    a21c:      	sxtw	x21, w2
    a220:      	cmp	x19, #0x24
    a224:      	b.ne	0xa260 <_stogir.conversion.policy+0x84>
    a228:      	cmp	x20, #0xf
    a22c:      	b.le	0xa454 <_stogir.conversion.policy+0x278>
    a230:      	cmp	x20, #0x80
    a234:      	b.ge	0xa454 <_stogir.conversion.policy+0x278>
    a238:      	and	x0, x20, #0xf
    a23c:      	sxtw	x0, w0
    a240:      	cmp	x0, #0x1
    a244:      	b.lt	0xa454 <_stogir.conversion.policy+0x278>
    a248:      	cmp	x0, #0xd
    a24c:      	b.gt	0xa454 <_stogir.conversion.policy+0x278>
    a250:      	mov	x22, #0x1               ; =1
    a254:      	b	0xa25c <_stogir.conversion.policy+0x80>
    a258:      	movz	x22, #0x0, lsl #48
    a25c:      	b	0xa264 <_stogir.conversion.policy+0x88>
    a260:      	movz	x22, #0x0, lsl #48
    a264:      	sxtw	x23, w3
    a268:      	cmp	x20, #0xd
    a26c:      	cset	w24, eq
    a270:      	cmp	x20, #0xc
    a274:      	cset	w25, eq
    a278:      	cmp	x23, #0x4
    a27c:      	cset	w26, eq
    a280:      	cmp	x23, #0x8
    a284:      	cset	w27, eq
    a288:      	cmp	x22, #0x0
    a28c:      	b.eq	0xa718 <_stogir.conversion.policy+0x53c>
    a290:      	mov	w0, w1
    a294:      	mov	w1, w3
    a298:      	str	x8, [sp, #0x10]
    a29c:      	mov	w28, w2
    a2a0:      	str	x19, [sp, #0x18]
    a2a4:      	mov	w19, w3
    a2a8:      	bl	0xa2a8 <_stogir.conversion.policy+0xcc>
		000000000000a2a8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a2ac:      	sxtw	x0, w0
    a2b0:      	b	0xa2bc <_stogir.conversion.policy+0xe0>
    a2b4:      	mov	x0, #0x1                ; =1
    a2b8:      	sxtw	x0, w0
    a2bc:      	cmp	x21, #0xd
    a2c0:      	cset	w1, eq
    a2c4:      	cmp	x21, #0xc
    a2c8:      	cset	w2, eq
    a2cc:      	cmp	x22, #0x0
    a2d0:      	b.eq	0xa72c <_stogir.conversion.policy+0x550>
    a2d4:      	mov	w22, w1
    a2d8:      	mov	w1, w19
    a2dc:      	mov	x19, x0
    a2e0:      	mov	w0, w28
    a2e4:      	mov	w28, w2
    a2e8:      	bl	0xa2e8 <_stogir.conversion.policy+0x10c>
		000000000000a2e8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a2ec:      	sxtw	x0, w0
    a2f0:      	b	0xa2fc <_stogir.conversion.policy+0x120>
    a2f4:      	mov	x23, #0x1               ; =1
    a2f8:      	sxtw	x0, w23
    a2fc:      	ldr	x1, [sp, #0x18]
    a300:      	cmp	x1, #0x21
    a304:      	b.lt	0xa3d8 <_stogir.conversion.policy+0x1fc>
    a308:      	cmp	x1, #0x27
    a30c:      	b.gt	0xa3d8 <_stogir.conversion.policy+0x1fc>
    a310:      	lsl	x2, x19, #3
    a314:      	sxtw	x2, w2
    a318:      	cmp	x2, #0x0
    a31c:      	b.le	0xa3d8 <_stogir.conversion.policy+0x1fc>
    a320:      	lsl	x0, x0, #3
    a324:      	sxtw	x0, w0
    a328:      	cmp	x0, #0x0
    a32c:      	b.le	0xa3d8 <_stogir.conversion.policy+0x1fc>
    a330:      	cmp	x1, #0x26
    a334:      	cset	w3, eq
    a338:      	cmp	x20, #0x1
    a33c:      	cset	w4, ge
    a340:      	cmp	x20, #0xb
    a344:      	cset	w5, le
    a348:      	cmp	x21, #0x1
    a34c:      	cset	w6, ge
    a350:      	cmp	x21, #0xb
    a354:      	cset	w7, le
    a358:      	cmp	x1, #0x25
    a35c:      	b.lt	0xa5d4 <_stogir.conversion.policy+0x3f8>
    a360:      	ubfx	x8, x22, #0, #8
    a364:      	cmp	x1, #0x25
    a368:      	b.ne	0xa644 <_stogir.conversion.policy+0x468>
    a36c:      	uxtb	w16, w4
    a370:      	cmp	w16, wzr
    a374:      	b.eq	0xa63c <_stogir.conversion.policy+0x460>
    a378:      	uxtb	w16, w5
    a37c:      	cmp	w16, wzr
    a380:      	b.eq	0xa63c <_stogir.conversion.policy+0x460>
    a384:      	uxtb	w16, w28
    a388:      	cmp	w16, wzr
    a38c:      	b.eq	0xa394 <_stogir.conversion.policy+0x1b8>
    a390:      	mov	x8, #0x1                ; =1
    a394:      	b	0xa640 <_stogir.conversion.policy+0x464>
    a398:      	uxtb	w16, w26
    a39c:      	cmp	w16, wzr
    a3a0:      	b.ne	0xa434 <_stogir.conversion.policy+0x258>
    a3a4:      	uxtb	w16, w27
    a3a8:      	cmp	w16, wzr
    a3ac:      	b.ne	0xa434 <_stogir.conversion.policy+0x258>
    a3b0:      	movn	x23, #0x0, lsl #48
    a3b4:      	b	0xa2f8 <_stogir.conversion.policy+0x11c>
    a3b8:      	uxtb	w16, w26
    a3bc:      	cmp	w16, wzr
    a3c0:      	b.ne	0xa444 <_stogir.conversion.policy+0x268>
    a3c4:      	uxtb	w16, w27
    a3c8:      	cmp	w16, wzr
    a3cc:      	b.ne	0xa444 <_stogir.conversion.policy+0x268>
    a3d0:      	movn	x0, #0x0, lsl #48
    a3d4:      	b	0xa2b8 <_stogir.conversion.policy+0xdc>
    a3d8:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a3d8:  ARM64_RELOC_PAGE21	l_stogir.461
    a3dc:      	ldr	x16, [x16]
		000000000000a3dc:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    a3e0:      	orr	x0, x16, xzr
    a3e4:      	mov	x1, #0x1                ; =1
    a3e8:      	mov	x2, #0x22               ; =34
    a3ec:      	ldr	x3, [sp, #0x10]
    a3f0:      	str	x1, [x3]
    a3f4:      	str	x0, [x3, #0x8]
    a3f8:      	str	x2, [x3, #0x10]
    a3fc:      	ldr	x19, [sp, #0x20]
    a400:      	ldr	x20, [sp, #0x28]
    a404:      	ldr	x21, [sp, #0x30]
    a408:      	ldr	x22, [sp, #0x38]
    a40c:      	ldr	x23, [sp, #0x40]
    a410:      	ldr	x24, [sp, #0x48]
    a414:      	ldr	x25, [sp, #0x50]
    a418:      	ldr	x26, [sp, #0x58]
    a41c:      	ldr	x27, [sp, #0x60]
    a420:      	ldr	x28, [sp, #0x68]
    a424:      	ldr	x29, [sp]
    a428:      	ldr	x30, [sp, #0x8]
    a42c:      	add	sp, sp, #0x70
    a430:      	ret
    a434:      	cmp	x21, #0x0
    a438:      	b.ne	0xa48c <_stogir.conversion.policy+0x2b0>
    a43c:      	movz	x23, #0x0, lsl #48
    a440:      	b	0xa2f8 <_stogir.conversion.policy+0x11c>
    a444:      	cmp	x20, #0x0
    a448:      	b.ne	0xa504 <_stogir.conversion.policy+0x328>
    a44c:      	movz	x0, #0x0, lsl #48
    a450:      	b	0xa2b8 <_stogir.conversion.policy+0xdc>
    a454:      	cmp	x21, #0xf
    a458:      	b.le	0xa258 <_stogir.conversion.policy+0x7c>
    a45c:      	cmp	x21, #0x80
    a460:      	b.ge	0xa484 <_stogir.conversion.policy+0x2a8>
    a464:      	and	x0, x21, #0xf
    a468:      	sxtw	x0, w0
    a46c:      	cmp	x0, #0x1
    a470:      	b.lt	0xa57c <_stogir.conversion.policy+0x3a0>
    a474:      	cmp	x0, #0xd
    a478:      	cset	w0, le
    a47c:      	ubfx	x22, x0, #0, #8
    a480:      	b	0xa580 <_stogir.conversion.policy+0x3a4>
    a484:      	movz	x22, #0x0, lsl #48
    a488:      	b	0xa25c <_stogir.conversion.policy+0x80>
    a48c:      	cmp	x21, #0x1
    a490:      	b.eq	0xa2f4 <_stogir.conversion.policy+0x118>
    a494:      	cmp	x21, #0x2
    a498:      	b.eq	0xa2f4 <_stogir.conversion.policy+0x118>
    a49c:      	cmp	x21, #0x7
    a4a0:      	b.eq	0xa2f4 <_stogir.conversion.policy+0x118>
    a4a4:      	cmp	x21, #0x8
    a4a8:      	b.eq	0xa2f4 <_stogir.conversion.policy+0x118>
    a4ac:      	cmp	x21, #0x3
    a4b0:      	b.eq	0xa670 <_stogir.conversion.policy+0x494>
    a4b4:      	cmp	x21, #0x9
    a4b8:      	b.eq	0xa670 <_stogir.conversion.policy+0x494>
    a4bc:      	cmp	x21, #0x4
    a4c0:      	b.eq	0xa6e0 <_stogir.conversion.policy+0x504>
    a4c4:      	cmp	x21, #0xa
    a4c8:      	b.eq	0xa6e0 <_stogir.conversion.policy+0x504>
    a4cc:      	uxtb	w16, w22
    a4d0:      	cmp	w16, wzr
    a4d4:      	b.ne	0xa6e0 <_stogir.conversion.policy+0x504>
    a4d8:      	cmp	x21, #0x5
    a4dc:      	b.eq	0xa700 <_stogir.conversion.policy+0x524>
    a4e0:      	cmp	x21, #0xb
    a4e4:      	b.eq	0xa700 <_stogir.conversion.policy+0x524>
    a4e8:      	uxtb	w16, w28
    a4ec:      	cmp	w16, wzr
    a4f0:      	b.ne	0xa700 <_stogir.conversion.policy+0x524>
    a4f4:      	cmp	x21, #0x6
    a4f8:      	b.eq	0xa500 <_stogir.conversion.policy+0x324>
    a4fc:      	movn	x23, #0x0, lsl #48
    a500:      	b	0xa704 <_stogir.conversion.policy+0x528>
    a504:      	cmp	x20, #0x1
    a508:      	b.eq	0xa2b4 <_stogir.conversion.policy+0xd8>
    a50c:      	cmp	x20, #0x2
    a510:      	b.eq	0xa2b4 <_stogir.conversion.policy+0xd8>
    a514:      	cmp	x20, #0x7
    a518:      	b.eq	0xa2b4 <_stogir.conversion.policy+0xd8>
    a51c:      	cmp	x20, #0x8
    a520:      	b.eq	0xa2b4 <_stogir.conversion.policy+0xd8>
    a524:      	cmp	x20, #0x3
    a528:      	b.eq	0xa678 <_stogir.conversion.policy+0x49c>
    a52c:      	cmp	x20, #0x9
    a530:      	b.eq	0xa678 <_stogir.conversion.policy+0x49c>
    a534:      	cmp	x20, #0x4
    a538:      	b.eq	0xa6e8 <_stogir.conversion.policy+0x50c>
    a53c:      	cmp	x20, #0xa
    a540:      	b.eq	0xa6e8 <_stogir.conversion.policy+0x50c>
    a544:      	uxtb	w16, w24
    a548:      	cmp	w16, wzr
    a54c:      	b.ne	0xa6e8 <_stogir.conversion.policy+0x50c>
    a550:      	cmp	x20, #0x5
    a554:      	b.eq	0xa708 <_stogir.conversion.policy+0x52c>
    a558:      	cmp	x20, #0xb
    a55c:      	b.eq	0xa708 <_stogir.conversion.policy+0x52c>
    a560:      	uxtb	w16, w25
    a564:      	cmp	w16, wzr
    a568:      	b.ne	0xa708 <_stogir.conversion.policy+0x52c>
    a56c:      	cmp	x20, #0x6
    a570:      	b.ne	0xa710 <_stogir.conversion.policy+0x534>
    a574:      	mov	x0, x23
    a578:      	b	0xa714 <_stogir.conversion.policy+0x538>
    a57c:      	movz	x22, #0x0, lsl #48
    a580:      	b	0xa488 <_stogir.conversion.policy+0x2ac>
    a584:      	mov	x4, #0x1                ; =1
    a588:      	cmp	x4, #0x0
    a58c:      	b.ne	0xa3d8 <_stogir.conversion.policy+0x1fc>
    a590:      	cmp	x1, #0x23
    a594:      	b.eq	0xa5a4 <_stogir.conversion.policy+0x3c8>
    a598:      	uxtb	w16, w3
    a59c:      	cmp	w16, wzr
    a5a0:      	b.eq	0xa5a8 <_stogir.conversion.policy+0x3cc>
    a5a4:      	mov	x2, x0
    a5a8:      	and	x0, x2, #0xffffffff
    a5ac:      	movz	x1, #0x0, lsl #48
    a5b0:      	movz	x2, #0x0, lsl #48
    a5b4:      	b	0xa3ec <_stogir.conversion.policy+0x210>
    a5b8:      	movz	x8, #0x0, lsl #48
    a5bc:      	cmp	x8, #0x0
    a5c0:      	cset	w4, ne
    a5c4:      	uxtb	w16, w4
    a5c8:      	cmp	w16, wzr
    a5cc:      	cset	x4, eq
    a5d0:      	b	0xa588 <_stogir.conversion.policy+0x3ac>
    a5d4:      	cmp	x1, #0x24
    a5d8:      	b.ne	0xa5f4 <_stogir.conversion.policy+0x418>
    a5dc:      	cmp	x2, x0
    a5e0:      	cset	w4, eq
    a5e4:      	uxtb	w16, w4
    a5e8:      	cmp	w16, wzr
    a5ec:      	cset	x4, eq
    a5f0:      	b	0xa588 <_stogir.conversion.policy+0x3ac>
    a5f4:      	uxtb	w16, w4
    a5f8:      	cmp	w16, wzr
    a5fc:      	b.eq	0xa584 <_stogir.conversion.policy+0x3a8>
    a600:      	uxtb	w16, w5
    a604:      	cmp	w16, wzr
    a608:      	b.eq	0xa584 <_stogir.conversion.policy+0x3a8>
    a60c:      	uxtb	w16, w6
    a610:      	cmp	w16, wzr
    a614:      	b.eq	0xa6b0 <_stogir.conversion.policy+0x4d4>
    a618:      	uxtb	w16, w7
    a61c:      	cmp	w16, wzr
    a620:      	b.eq	0xa6b0 <_stogir.conversion.policy+0x4d4>
    a624:      	cmp	x1, #0x23
    a628:      	b.ne	0xa6f0 <_stogir.conversion.policy+0x514>
    a62c:      	cmp	x0, x2
    a630:      	cset	w4, ge
    a634:      	ubfx	x4, x4, #0, #8
    a638:      	b	0xa6fc <_stogir.conversion.policy+0x520>
    a63c:      	movz	x8, #0x0, lsl #48
    a640:      	b	0xa5bc <_stogir.conversion.policy+0x3e0>
    a644:      	uxtb	w16, w3
    a648:      	cmp	w16, wzr
    a64c:      	b.eq	0xa688 <_stogir.conversion.policy+0x4ac>
    a650:      	uxtb	w16, w25
    a654:      	cmp	w16, wzr
    a658:      	b.ne	0xa6cc <_stogir.conversion.policy+0x4f0>
    a65c:      	uxtb	w16, w24
    a660:      	cmp	w16, wzr
    a664:      	b.ne	0xa6cc <_stogir.conversion.policy+0x4f0>
    a668:      	movz	x8, #0x0, lsl #48
    a66c:      	b	0xa684 <_stogir.conversion.policy+0x4a8>
    a670:      	mov	x23, #0x2               ; =2
    a674:      	b	0xa2f8 <_stogir.conversion.policy+0x11c>
    a678:      	mov	x0, #0x2                ; =2
    a67c:      	b	0xa2b8 <_stogir.conversion.policy+0xdc>
    a680:      	movz	x8, #0x0, lsl #48
    a684:      	b	0xa5bc <_stogir.conversion.policy+0x3e0>
    a688:      	cmp	x1, #0x27
    a68c:      	b.ne	0xa5b8 <_stogir.conversion.policy+0x3dc>
    a690:      	uxtb	w16, w25
    a694:      	cmp	w16, wzr
    a698:      	b.ne	0xa6b8 <_stogir.conversion.policy+0x4dc>
    a69c:      	uxtb	w16, w24
    a6a0:      	cmp	w16, wzr
    a6a4:      	b.ne	0xa6b8 <_stogir.conversion.policy+0x4dc>
    a6a8:      	movz	x8, #0x0, lsl #48
    a6ac:      	b	0xa6c8 <_stogir.conversion.policy+0x4ec>
    a6b0:      	mov	x4, #0x1                ; =1
    a6b4:      	b	0xa588 <_stogir.conversion.policy+0x3ac>
    a6b8:      	uxtb	w16, w28
    a6bc:      	cmp	w16, wzr
    a6c0:      	b.eq	0xa6c8 <_stogir.conversion.policy+0x4ec>
    a6c4:      	mov	x8, #0x1                ; =1
    a6c8:      	b	0xa5bc <_stogir.conversion.policy+0x3e0>
    a6cc:      	uxtb	w16, w6
    a6d0:      	cmp	w16, wzr
    a6d4:      	b.eq	0xa680 <_stogir.conversion.policy+0x4a4>
    a6d8:      	ubfx	x8, x7, #0, #8
    a6dc:      	b	0xa684 <_stogir.conversion.policy+0x4a8>
    a6e0:      	mov	x23, #0x4               ; =4
    a6e4:      	b	0xa674 <_stogir.conversion.policy+0x498>
    a6e8:      	mov	x0, #0x4                ; =4
    a6ec:      	b	0xa67c <_stogir.conversion.policy+0x4a0>
    a6f0:      	cmp	x0, x2
    a6f4:      	cset	w4, le
    a6f8:      	ubfx	x4, x4, #0, #8
    a6fc:      	b	0xa6b4 <_stogir.conversion.policy+0x4d8>
    a700:      	mov	x23, #0x8               ; =8
    a704:      	b	0xa6e4 <_stogir.conversion.policy+0x508>
    a708:      	mov	x0, #0x8                ; =8
    a70c:      	b	0xa6ec <_stogir.conversion.policy+0x510>
    a710:      	movn	x0, #0x0, lsl #48
    a714:      	b	0xa70c <_stogir.conversion.policy+0x530>
    a718:      	str	x8, [sp, #0x10]
    a71c:      	str	x19, [sp, #0x18]
    a720:      	mov	w28, w2
    a724:      	mov	w19, w3
    a728:      	b	0xa3b8 <_stogir.conversion.policy+0x1dc>
    a72c:      	mov	x19, x0
    a730:      	mov	w22, w1
    a734:      	mov	w28, w2
    a738:      	b	0xa398 <_stogir.conversion.policy+0x1bc>

000000000000a73c <_stogir.conditional.operands>:
    a73c:      	sub	sp, sp, #0x30
    a740:      	str	x19, [sp, #0x20]
    a744:      	str	x20, [sp, #0x28]
    a748:      	sxtw	x1, w1
    a74c:      	cmp	x1, #0x0
    a750:      	b.eq	0xa7a0 <_stogir.conditional.operands+0x64>
    a754:      	cmp	x1, #0x0
    a758:      	b.lt	0xa778 <_stogir.conditional.operands+0x3c>
    a75c:      	cmp	x1, #0xd
    a760:      	b.gt	0xa778 <_stogir.conditional.operands+0x3c>
    a764:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a764:  ARM64_RELOC_PAGE21	l_stogir.462
    a768:      	ldr	x16, [x16]
		000000000000a768:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    a76c:      	orr	x5, x16, xzr
    a770:      	movz	x6, #0x0, lsl #48
    a774:      	b	0xa7b0 <_stogir.conditional.operands+0x74>
    a778:      	cmp	x1, #0xf
    a77c:      	b.le	0xa7a0 <_stogir.conditional.operands+0x64>
    a780:      	cmp	x1, #0x80
    a784:      	b.ge	0xa7a0 <_stogir.conditional.operands+0x64>
    a788:      	and	x5, x1, #0xf
    a78c:      	sxtw	x5, w5
    a790:      	cmp	x5, #0x1
    a794:      	b.lt	0xa7a0 <_stogir.conditional.operands+0x64>
    a798:      	cmp	x5, #0xd
    a79c:      	b.le	0xa764 <_stogir.conditional.operands+0x28>
    a7a0:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a7a0:  ARM64_RELOC_PAGE21	l_stogir.463
    a7a4:      	ldr	x16, [x16]
		000000000000a7a4:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    a7a8:      	orr	x5, x16, xzr
    a7ac:      	mov	x6, #0x2b               ; =43
    a7b0:      	sxtw	x2, w2
    a7b4:      	cmp	x2, #0x0
    a7b8:      	cset	w7, gt
    a7bc:      	movz	x16, #0x0, lsl #48
    a7c0:      	sub	x9, x16, x2
    a7c4:      	sub	x10, x9, #0x1
    a7c8:      	uxtb	w16, w7
    a7cc:      	cmp	w16, wzr
    a7d0:      	b.eq	0xa810 <_stogir.conditional.operands+0xd4>
    a7d4:      	ldr	x9, [x0, #0x8]
    a7d8:      	cmp	x2, x9
    a7dc:      	b.ge	0xa868 <_stogir.conditional.operands+0x12c>
    a7e0:      	add	x9, x0, #0x78
    a7e4:      	ldr	x9, [x9, #0x8]
    a7e8:      	cmp	x2, x9
    a7ec:      	b.ge	0xab88 <_stogir.conditional.operands+0x44c>
    a7f0:      	ldr	x9, [x0, #0x78]
    a7f4:      	add	x9, x9, x2, lsl #2
    a7f8:      	ldr	w9, [x9]
    a7fc:      	sxtw	x9, w9
    a800:      	cmp	x9, #0x0
    a804:      	cset	w9, ge
    a808:      	ubfx	x9, x9, #0, #8
    a80c:      	b	0xab8c <_stogir.conditional.operands+0x450>
    a810:      	cmp	x2, #0x0
    a814:      	b.ge	0xa870 <_stogir.conditional.operands+0x134>
    a818:      	add	x11, x0, #0x28
    a81c:      	add	x12, x0, #0x50
    a820:      	ldr	x11, [x11, #0x8]
    a824:      	ldr	x12, [x12, #0x8]
    a828:      	cmp	x11, x12
    a82c:      	b.ne	0xa858 <_stogir.conditional.operands+0x11c>
    a830:      	cmp	x9, x11
    a834:      	b.gt	0xab90 <_stogir.conditional.operands+0x454>
    a838:      	ldr	x9, [x0, #0x50]
    a83c:      	add	x9, x9, x10, lsl #2
    a840:      	ldr	w9, [x9]
    a844:      	sxtw	x9, w9
    a848:      	cmp	x9, #0x0
    a84c:      	cset	w9, gt
    a850:      	ubfx	x9, x9, #0, #8
    a854:      	b	0xab94 <_stogir.conditional.operands+0x458>
    a858:      	movz	x9, #0x0, lsl #48
    a85c:      	b	0xa874 <_stogir.conditional.operands+0x138>
    a860:      	movz	x14, #0x0, lsl #48
    a864:      	b	0xa904 <_stogir.conditional.operands+0x1c8>
    a868:      	movz	x9, #0x0, lsl #48
    a86c:      	b	0xa874 <_stogir.conditional.operands+0x138>
    a870:      	movz	x9, #0x0, lsl #48
    a874:      	cmp	x9, #0x0
    a878:      	b.eq	0xa8ac <_stogir.conditional.operands+0x170>
    a87c:      	uxtb	w16, w7
    a880:      	cmp	w16, wzr
    a884:      	b.eq	0xa898 <_stogir.conditional.operands+0x15c>
    a888:      	ldr	x7, [x0]
    a88c:      	add	x2, x7, x2, lsl #4
    a890:      	ldr	x2, [x2]
    a894:      	b	0xa8a4 <_stogir.conditional.operands+0x168>
    a898:      	ldr	x2, [x0, #0x28]
    a89c:      	add	x2, x2, x10, lsl #4
    a8a0:      	ldr	x2, [x2]
    a8a4:      	mov	x7, #0x1                ; =1
    a8a8:      	b	0xa8b4 <_stogir.conditional.operands+0x178>
    a8ac:      	movz	x7, #0x0, lsl #48
    a8b0:      	movz	x2, #0x0, lsl #48
    a8b4:      	ubfx	x7, x7, #0, #32
    a8b8:      	lsr	x16, x7, #0
    a8bc:      	cmp	x16, #0x1
    a8c0:      	b.eq	0xa8dc <_stogir.conditional.operands+0x1a0>
    a8c4:      	b.lo	0xa8cc <_stogir.conditional.operands+0x190>
    a8c8:      	b	0xa8e0 <_stogir.conditional.operands+0x1a4>
    a8cc:      	cmp	x16, #0x0
    a8d0:      	b.eq	0xa8d8 <_stogir.conditional.operands+0x19c>
    a8d4:      	b	0xa8e0 <_stogir.conditional.operands+0x1a4>
    a8d8:      	b	0xa8e4 <_stogir.conditional.operands+0x1a8>
    a8dc:      	b	0xa908 <_stogir.conditional.operands+0x1cc>
    a8e0:      	b	0xaba8 <_stogir.conditional.operands+0x46c>
    a8e4:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a8e4:  ARM64_RELOC_PAGE21	l_stogir.464
    a8e8:      	ldr	x16, [x16]
		000000000000a8e8:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    a8ec:      	orr	x5, x16, xzr
    a8f0:      	mov	x6, #0x16               ; =22
    a8f4:      	b	0xa94c <_stogir.conditional.operands+0x210>
    a8f8:      	movz	x14, #0x0, lsl #48
    a8fc:      	b	0xa9a4 <_stogir.conditional.operands+0x268>
    a900:      	movz	x14, #0x0, lsl #48
    a904:      	b	0xa9ac <_stogir.conditional.operands+0x270>
    a908:      	uxtb	w7, w2
    a90c:      	cmp	x7, #0x48
    a910:      	b.eq	0xa93c <_stogir.conditional.operands+0x200>
    a914:      	cmp	x7, #0x46
    a918:      	b.eq	0xa93c <_stogir.conditional.operands+0x200>
    a91c:      	ubfx	x7, x2, #0, #32
    a920:      	ubfx	x7, x7, #8, #8
    a924:      	cmp	x7, #0x0
    a928:      	b.eq	0xa93c <_stogir.conditional.operands+0x200>
    a92c:      	ubfx	x2, x2, #0, #32
    a930:      	ubfx	x2, x2, #8, #8
    a934:      	cmp	x2, #0xd
    a938:      	b.le	0xa94c <_stogir.conditional.operands+0x210>
    a93c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a93c:  ARM64_RELOC_PAGE21	l_stogir.465
    a940:      	ldr	x16, [x16]
		000000000000a940:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    a944:      	orr	x5, x16, xzr
    a948:      	mov	x6, #0x2a               ; =42
    a94c:      	add	x16, sp, #0x10
    a950:      	orr	x2, x16, xzr
    a954:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a954:  ARM64_RELOC_PAGE21	l_stogir.466
    a958:      	ldr	x16, [x16]
		000000000000a958:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    a95c:      	orr	x7, x16, xzr
    a960:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000a960:  ARM64_RELOC_PAGE21	l_stogir.467
    a964:      	ldr	x16, [x16]
		000000000000a964:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    a968:      	orr	x9, x16, xzr
    a96c:      	add	x10, x0, #0x78
    a970:      	add	x11, x0, #0x28
    a974:      	add	x12, x0, #0x50
    a978:      	mov	x16, sp
    a97c:      	str	w3, [x16]
    a980:      	mov	x16, sp
    a984:      	str	w4, [x16, #0x4]
    a988:      	mov	x16, sp
    a98c:      	ldr	x3, [x16]
    a990:      	add	x16, sp, #0x10
    a994:      	str	x3, [x16]
    a998:      	movz	x3, #0x0, lsl #48
    a99c:      	b	0xaa54 <_stogir.conditional.operands+0x318>
    a9a0:      	movz	x14, #0x0, lsl #48
    a9a4:      	b	0xa9ac <_stogir.conditional.operands+0x270>
    a9a8:      	movz	x14, #0x0, lsl #48
    a9ac:      	cmp	x14, #0x0
    a9b0:      	b.eq	0xa9e4 <_stogir.conditional.operands+0x2a8>
    a9b4:      	uxtb	w16, w4
    a9b8:      	cmp	w16, wzr
    a9bc:      	b.eq	0xa9d0 <_stogir.conditional.operands+0x294>
    a9c0:      	ldr	x4, [x0]
    a9c4:      	add	x4, x4, x13, lsl #4
    a9c8:      	ldr	x4, [x4]
    a9cc:      	b	0xa9dc <_stogir.conditional.operands+0x2a0>
    a9d0:      	ldr	x4, [x0, #0x28]
    a9d4:      	add	x4, x4, x15, lsl #4
    a9d8:      	ldr	x4, [x4]
    a9dc:      	mov	x13, #0x1               ; =1
    a9e0:      	b	0xa9ec <_stogir.conditional.operands+0x2b0>
    a9e4:      	movz	x13, #0x0, lsl #48
    a9e8:      	movz	x4, #0x0, lsl #48
    a9ec:      	ubfx	x13, x13, #0, #32
    a9f0:      	lsr	x16, x13, #0
    a9f4:      	cmp	x16, #0x1
    a9f8:      	b.eq	0xaa14 <_stogir.conditional.operands+0x2d8>
    a9fc:      	b.lo	0xaa04 <_stogir.conditional.operands+0x2c8>
    aa00:      	b	0xaa18 <_stogir.conditional.operands+0x2dc>
    aa04:      	cmp	x16, #0x0
    aa08:      	b.eq	0xaa10 <_stogir.conditional.operands+0x2d4>
    aa0c:      	b	0xaa18 <_stogir.conditional.operands+0x2dc>
    aa10:      	b	0xaa1c <_stogir.conditional.operands+0x2e0>
    aa14:      	b	0xaa28 <_stogir.conditional.operands+0x2ec>
    aa18:      	b	0xaba0 <_stogir.conditional.operands+0x464>
    aa1c:      	mov	x5, x7
    aa20:      	mov	x6, #0x10               ; =16
    aa24:      	b	0xaa54 <_stogir.conditional.operands+0x318>
    aa28:      	uxtb	w13, w4
    aa2c:      	cmp	x13, #0x48
    aa30:      	b.eq	0xaa4c <_stogir.conditional.operands+0x310>
    aa34:      	cmp	x13, #0x46
    aa38:      	b.eq	0xaa4c <_stogir.conditional.operands+0x310>
    aa3c:      	ubfx	x4, x4, #0, #32
    aa40:      	ubfx	x4, x4, #8, #8
    aa44:      	cmp	x4, x1
    aa48:      	b.eq	0xaa54 <_stogir.conditional.operands+0x318>
    aa4c:      	mov	x5, x9
    aa50:      	mov	x6, #0x21               ; =33
    aa54:      	cmp	x3, #0x2
    aa58:      	b.ge	0xaa7c <_stogir.conditional.operands+0x340>
    aa5c:      	add	x4, x3, #0x1
    aa60:      	add	x3, x2, x3, lsl #2
    aa64:      	ldr	w3, [x3]
    aa68:      	sxtw	x3, w3
    aa6c:      	and	x13, x3, #0xffffffff
    aa70:      	mov	x3, x4
    aa74:      	mov	x4, #0x1                ; =1
    aa78:      	b	0xaa84 <_stogir.conditional.operands+0x348>
    aa7c:      	movz	x4, #0x0, lsl #48
    aa80:      	movz	x13, #0x0, lsl #48
    aa84:      	ubfx	x4, x4, #0, #32
    aa88:      	lsr	x16, x4, #0
    aa8c:      	cmp	x16, #0x1
    aa90:      	b.eq	0xaaac <_stogir.conditional.operands+0x370>
    aa94:      	b.lo	0xaa9c <_stogir.conditional.operands+0x360>
    aa98:      	b	0xaab0 <_stogir.conditional.operands+0x374>
    aa9c:      	cmp	x16, #0x0
    aaa0:      	b.eq	0xaaa8 <_stogir.conditional.operands+0x36c>
    aaa4:      	b	0xaab0 <_stogir.conditional.operands+0x374>
    aaa8:      	b	0xab10 <_stogir.conditional.operands+0x3d4>
    aaac:      	b	0xaab4 <_stogir.conditional.operands+0x378>
    aab0:      	b	0xab98 <_stogir.conditional.operands+0x45c>
    aab4:      	sxtw	x13, w13
    aab8:      	cmp	x13, #0x0
    aabc:      	cset	w4, gt
    aac0:      	movz	x16, #0x0, lsl #48
    aac4:      	sub	x14, x16, x13
    aac8:      	sub	x15, x14, #0x1
    aacc:      	uxtb	w16, w4
    aad0:      	cmp	w16, wzr
    aad4:      	b.eq	0xab48 <_stogir.conditional.operands+0x40c>
    aad8:      	ldr	x14, [x0, #0x8]
    aadc:      	cmp	x13, x14
    aae0:      	b.ge	0xa9a0 <_stogir.conditional.operands+0x264>
    aae4:      	ldr	x14, [x10, #0x8]
    aae8:      	cmp	x13, x14
    aaec:      	b.ge	0xa8f8 <_stogir.conditional.operands+0x1bc>
    aaf0:      	ldr	x14, [x0, #0x78]
    aaf4:      	add	x14, x14, x13, lsl #2
    aaf8:      	ldr	w14, [x14]
    aafc:      	sxtw	x14, w14
    ab00:      	cmp	x14, #0x0
    ab04:      	cset	w14, ge
    ab08:      	ubfx	x14, x14, #0, #8
    ab0c:      	b	0xa8fc <_stogir.conditional.operands+0x1c0>
    ab10:      	cmp	x6, #0x0
    ab14:      	b.ne	0xab28 <_stogir.conditional.operands+0x3ec>
    ab18:      	and	x5, x1, #0xffffffff
    ab1c:      	movz	x0, #0x0, lsl #48
    ab20:      	movz	x6, #0x0, lsl #48
    ab24:      	b	0xab2c <_stogir.conditional.operands+0x3f0>
    ab28:      	mov	x0, #0x1                ; =1
    ab2c:      	str	x0, [x8]
    ab30:      	str	x5, [x8, #0x8]
    ab34:      	str	x6, [x8, #0x10]
    ab38:      	ldr	x19, [sp, #0x20]
    ab3c:      	ldr	x20, [sp, #0x28]
    ab40:      	add	sp, sp, #0x30
    ab44:      	ret
    ab48:      	cmp	x13, #0x0
    ab4c:      	b.ge	0xa9a8 <_stogir.conditional.operands+0x26c>
    ab50:      	ldr	x19, [x11, #0x8]
    ab54:      	ldr	x20, [x12, #0x8]
    ab58:      	cmp	x19, x20
    ab5c:      	b.ne	0xa900 <_stogir.conditional.operands+0x1c4>
    ab60:      	cmp	x14, x19
    ab64:      	b.gt	0xa860 <_stogir.conditional.operands+0x124>
    ab68:      	ldr	x14, [x0, #0x50]
    ab6c:      	add	x14, x14, x15, lsl #2
    ab70:      	ldr	w14, [x14]
    ab74:      	sxtw	x14, w14
    ab78:      	cmp	x14, #0x0
    ab7c:      	cset	w14, gt
    ab80:      	ubfx	x14, x14, #0, #8
    ab84:      	b	0xa864 <_stogir.conditional.operands+0x128>
    ab88:      	movz	x9, #0x0, lsl #48
    ab8c:      	b	0xa86c <_stogir.conditional.operands+0x130>
    ab90:      	movz	x9, #0x0, lsl #48
    ab94:      	b	0xa85c <_stogir.conditional.operands+0x120>
    ab98:      	brk	#0
    ab9c:      	b	0xab98 <_stogir.conditional.operands+0x45c>
    aba0:      	brk	#0
    aba4:      	b	0xaba0 <_stogir.conditional.operands+0x464>
    aba8:      	brk	#0
    abac:      	b	0xaba8 <_stogir.conditional.operands+0x46c>

000000000000abb0 <_stogir.floating.operands>:
    abb0:      	sub	sp, sp, #0x90
    abb4:      	str	x29, [sp]
    abb8:      	str	x30, [sp, #0x8]
    abbc:      	mov	x29, sp
    abc0:      	str	x19, [sp, #0x60]
    abc4:      	str	x20, [sp, #0x68]
    abc8:      	str	x21, [sp, #0x70]
    abcc:      	str	x22, [sp, #0x78]
    abd0:      	str	x23, [sp, #0x80]
    abd4:      	sxtw	x1, w1
    abd8:      	sxtw	x19, w2
    abdc:      	cmp	x1, #0x1f
    abe0:      	cset	w2, eq
    abe4:      	cmp	x1, #0x20
    abe8:      	cset	w6, eq
    abec:      	cmp	x1, #0xe
    abf0:      	b.lt	0xac20 <_stogir.floating.operands+0x70>
    abf4:      	cmp	x1, #0x19
    abf8:      	b.gt	0xac20 <_stogir.floating.operands+0x70>
    abfc:      	cmp	x19, #0xc
    ac00:      	b.eq	0xac5c <_stogir.floating.operands+0xac>
    ac04:      	cmp	x19, #0xd
    ac08:      	b.eq	0xac5c <_stogir.floating.operands+0xac>
    ac0c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000ac0c:  ARM64_RELOC_PAGE21	l_stogir.468
    ac10:      	ldr	x16, [x16]
		000000000000ac10:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    ac14:      	orr	x20, x16, xzr
    ac18:      	mov	x21, #0x22              ; =34
    ac1c:      	b	0xac6c <_stogir.floating.operands+0xbc>
    ac20:      	uxtb	w16, w2
    ac24:      	cmp	w16, wzr
    ac28:      	b.ne	0xabfc <_stogir.floating.operands+0x4c>
    ac2c:      	uxtb	w16, w6
    ac30:      	cmp	w16, wzr
    ac34:      	b.ne	0xabfc <_stogir.floating.operands+0x4c>
    ac38:      	cmp	x1, #0x1a
    ac3c:      	b.lt	0xac48 <_stogir.floating.operands+0x98>
    ac40:      	cmp	x1, #0x1d
    ac44:      	b.le	0xabfc <_stogir.floating.operands+0x4c>
    ac48:      	cmp	x1, #0x3a
    ac4c:      	b.eq	0xabfc <_stogir.floating.operands+0x4c>
    ac50:      	cmp	x1, #0x3b
    ac54:      	b.eq	0xabfc <_stogir.floating.operands+0x4c>
    ac58:      	b	0xac0c <_stogir.floating.operands+0x5c>
    ac5c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000ac5c:  ARM64_RELOC_PAGE21	l_stogir.469
    ac60:      	ldr	x16, [x16]
		000000000000ac60:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    ac64:      	orr	x20, x16, xzr
    ac68:      	movz	x21, #0x0, lsl #48
    ac6c:      	add	x16, sp, #0x10
    ac70:      	str	w3, [x16]
    ac74:      	uxtb	w16, w2
    ac78:      	cmp	w16, wzr
    ac7c:      	b.ne	0xacf4 <_stogir.floating.operands+0x144>
    ac80:      	uxtb	w16, w6
    ac84:      	cmp	w16, wzr
    ac88:      	b.ne	0xacf4 <_stogir.floating.operands+0x144>
    ac8c:      	sxtw	x3, w4
    ac90:      	b	0xacf8 <_stogir.floating.operands+0x148>
    ac94:      	movz	x1, #0x0, lsl #48
    ac98:      	uxtb	w1, w1
    ac9c:      	and	x1, x1, #0x2
    aca0:      	uxtb	w1, w1
    aca4:      	cmp	x1, #0x0
    aca8:      	cset	w1, eq
    acac:      	uxtb	w16, w1
    acb0:      	cmp	w16, wzr
    acb4:      	cset	x1, eq
    acb8:      	cmp	x1, #0x0
    acbc:      	b.ne	0xace0 <_stogir.floating.operands+0x130>
    acc0:      	cmp	x0, #0x65
    acc4:      	b.eq	0xace0 <_stogir.floating.operands+0x130>
    acc8:      	cmp	x0, #0x66
    accc:      	b.eq	0xace0 <_stogir.floating.operands+0x130>
    acd0:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000acd0:  ARM64_RELOC_PAGE21	l_stogir.470
    acd4:      	ldr	x16, [x16]
		000000000000acd4:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    acd8:      	orr	x20, x16, xzr
    acdc:      	mov	x21, #0x2d              ; =45
    ace0:      	b	0xaddc <_stogir.floating.operands+0x22c>
    ace4:      	movz	x13, #0x0, lsl #48
    ace8:      	b	0xad48 <_stogir.floating.operands+0x198>
    acec:      	movz	x13, #0x0, lsl #48
    acf0:      	b	0xad50 <_stogir.floating.operands+0x1a0>
    acf4:      	sxtw	x3, w3
    acf8:      	add	x16, sp, #0x20
    acfc:      	orr	x2, x16, xzr
    ad00:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000ad00:  ARM64_RELOC_PAGE21	l_stogir.471
    ad04:      	ldr	x16, [x16]
		000000000000ad04:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    ad08:      	orr	x4, x16, xzr
    ad0c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000ad0c:  ARM64_RELOC_PAGE21	l_stogir.472
    ad10:      	ldr	x16, [x16]
		000000000000ad10:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    ad14:      	orr	x6, x16, xzr
    ad18:      	add	x7, x0, #0x78
    ad1c:      	add	x9, x0, #0x28
    ad20:      	add	x10, x0, #0x50
    ad24:      	add	x16, sp, #0x10
    ad28:      	str	w3, [x16, #0x4]
    ad2c:      	add	x16, sp, #0x10
    ad30:      	ldr	x3, [x16]
    ad34:      	add	x16, sp, #0x20
    ad38:      	str	x3, [x16]
    ad3c:      	movz	x3, #0x0, lsl #48
    ad40:      	b	0xadf8 <_stogir.floating.operands+0x248>
    ad44:      	movz	x13, #0x0, lsl #48
    ad48:      	b	0xad50 <_stogir.floating.operands+0x1a0>
    ad4c:      	movz	x13, #0x0, lsl #48
    ad50:      	cmp	x13, #0x0
    ad54:      	b.eq	0xad88 <_stogir.floating.operands+0x1d8>
    ad58:      	uxtb	w16, w11
    ad5c:      	cmp	w16, wzr
    ad60:      	b.eq	0xad74 <_stogir.floating.operands+0x1c4>
    ad64:      	ldr	x11, [x0]
    ad68:      	add	x11, x11, x12, lsl #4
    ad6c:      	ldr	x11, [x11]
    ad70:      	b	0xad80 <_stogir.floating.operands+0x1d0>
    ad74:      	ldr	x11, [x0, #0x28]
    ad78:      	add	x11, x11, x14, lsl #4
    ad7c:      	ldr	x11, [x11]
    ad80:      	mov	x12, #0x1               ; =1
    ad84:      	b	0xad90 <_stogir.floating.operands+0x1e0>
    ad88:      	movz	x12, #0x0, lsl #48
    ad8c:      	movz	x11, #0x0, lsl #48
    ad90:      	ubfx	x12, x12, #0, #32
    ad94:      	lsr	x16, x12, #0
    ad98:      	cmp	x16, #0x1
    ad9c:      	b.eq	0xadb8 <_stogir.floating.operands+0x208>
    ada0:      	b.lo	0xada8 <_stogir.floating.operands+0x1f8>
    ada4:      	b	0xadbc <_stogir.floating.operands+0x20c>
    ada8:      	cmp	x16, #0x0
    adac:      	b.eq	0xadb4 <_stogir.floating.operands+0x204>
    adb0:      	b	0xadbc <_stogir.floating.operands+0x20c>
    adb4:      	b	0xadc0 <_stogir.floating.operands+0x210>
    adb8:      	b	0xade0 <_stogir.floating.operands+0x230>
    adbc:      	b	0xaff4 <_stogir.floating.operands+0x444>
    adc0:      	mov	x20, x4
    adc4:      	mov	x21, #0x18              ; =24
    adc8:      	b	0xadf8 <_stogir.floating.operands+0x248>
    adcc:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000adcc:  ARM64_RELOC_PAGE21	l_stogir.473
    add0:      	ldr	x16, [x16]
		000000000000add0:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    add4:      	orr	x20, x16, xzr
    add8:      	mov	x21, #0x21              ; =33
    addc:      	b	0xaec4 <_stogir.floating.operands+0x314>
    ade0:      	ubfx	x11, x11, #0, #32
    ade4:      	ubfx	x11, x11, #8, #8
    ade8:      	cmp	x11, x19
    adec:      	b.eq	0xadf8 <_stogir.floating.operands+0x248>
    adf0:      	mov	x20, x6
    adf4:      	mov	x21, #0x1e              ; =30
    adf8:      	cmp	x3, #0x2
    adfc:      	b.ge	0xae20 <_stogir.floating.operands+0x270>
    ae00:      	add	x11, x3, #0x1
    ae04:      	add	x3, x2, x3, lsl #2
    ae08:      	ldr	w3, [x3]
    ae0c:      	sxtw	x3, w3
    ae10:      	and	x12, x3, #0xffffffff
    ae14:      	mov	x3, x11
    ae18:      	mov	x11, #0x1               ; =1
    ae1c:      	b	0xae28 <_stogir.floating.operands+0x278>
    ae20:      	movz	x11, #0x0, lsl #48
    ae24:      	movz	x12, #0x0, lsl #48
    ae28:      	ubfx	x11, x11, #0, #32
    ae2c:      	lsr	x16, x11, #0
    ae30:      	cmp	x16, #0x1
    ae34:      	b.eq	0xae50 <_stogir.floating.operands+0x2a0>
    ae38:      	b.lo	0xae40 <_stogir.floating.operands+0x290>
    ae3c:      	b	0xae54 <_stogir.floating.operands+0x2a4>
    ae40:      	cmp	x16, #0x0
    ae44:      	b.eq	0xae4c <_stogir.floating.operands+0x29c>
    ae48:      	b	0xae54 <_stogir.floating.operands+0x2a4>
    ae4c:      	b	0xaeb4 <_stogir.floating.operands+0x304>
    ae50:      	b	0xae58 <_stogir.floating.operands+0x2a8>
    ae54:      	b	0xafec <_stogir.floating.operands+0x43c>
    ae58:      	sxtw	x12, w12
    ae5c:      	cmp	x12, #0x0
    ae60:      	cset	w11, gt
    ae64:      	movz	x16, #0x0, lsl #48
    ae68:      	sub	x13, x16, x12
    ae6c:      	sub	x14, x13, #0x1
    ae70:      	uxtb	w16, w11
    ae74:      	cmp	w16, wzr
    ae78:      	b.eq	0xaf3c <_stogir.floating.operands+0x38c>
    ae7c:      	ldr	x13, [x0, #0x8]
    ae80:      	cmp	x12, x13
    ae84:      	b.ge	0xad44 <_stogir.floating.operands+0x194>
    ae88:      	ldr	x13, [x7, #0x8]
    ae8c:      	cmp	x12, x13
    ae90:      	b.ge	0xace4 <_stogir.floating.operands+0x134>
    ae94:      	ldr	x13, [x0, #0x78]
    ae98:      	add	x13, x13, x12, lsl #2
    ae9c:      	ldr	w13, [x13]
    aea0:      	sxtw	x13, w13
    aea4:      	cmp	x13, #0x0
    aea8:      	cset	w13, ge
    aeac:      	ubfx	x13, x13, #0, #8
    aeb0:      	b	0xace8 <_stogir.floating.operands+0x138>
    aeb4:      	sxtw	x22, w5
    aeb8:      	cmp	x22, #0x0
    aebc:      	b.ne	0xaedc <_stogir.floating.operands+0x32c>
    aec0:      	mov	x23, x8
    aec4:      	cmp	x21, #0x0
    aec8:      	b.ne	0xaf7c <_stogir.floating.operands+0x3cc>
    aecc:      	and	x20, x19, #0xffffffff
    aed0:      	movz	x0, #0x0, lsl #48
    aed4:      	movz	x21, #0x0, lsl #48
    aed8:      	b	0xaf80 <_stogir.floating.operands+0x3d0>
    aedc:      	cmp	x1, #0x1d
    aee0:      	b.ne	0xb004 <_stogir.floating.operands+0x454>
    aee4:      	mov	w1, w5
    aee8:      	mov	x23, x8
    aeec:      	add	x8, sp, #0x30
    aef0:      	bl	0xaef0 <_stogir.floating.operands+0x340>
		000000000000aef0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    aef4:      	add	x16, sp, #0x30
    aef8:      	ldr	w0, [x16]
    aefc:      	lsr	x16, x0, #0
    af00:      	cmp	x16, #0x1
    af04:      	b.eq	0xaf20 <_stogir.floating.operands+0x370>
    af08:      	b.lo	0xaf10 <_stogir.floating.operands+0x360>
    af0c:      	b	0xaf24 <_stogir.floating.operands+0x374>
    af10:      	cmp	x16, #0x0
    af14:      	b.eq	0xaf1c <_stogir.floating.operands+0x36c>
    af18:      	b	0xaf24 <_stogir.floating.operands+0x374>
    af1c:      	b	0xaf28 <_stogir.floating.operands+0x378>
    af20:      	b	0xafb8 <_stogir.floating.operands+0x408>
    af24:      	b	0xaffc <_stogir.floating.operands+0x44c>
    af28:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000af28:  ARM64_RELOC_PAGE21	l_stogir.474
    af2c:      	ldr	x16, [x16]
		000000000000af2c:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    af30:      	orr	x20, x16, xzr
    af34:      	mov	x21, #0x16              ; =22
    af38:      	b	0xace0 <_stogir.floating.operands+0x130>
    af3c:      	cmp	x12, #0x0
    af40:      	b.ge	0xad4c <_stogir.floating.operands+0x19c>
    af44:      	ldr	x15, [x9, #0x8]
    af48:      	ldr	x22, [x10, #0x8]
    af4c:      	cmp	x15, x22
    af50:      	b.ne	0xacec <_stogir.floating.operands+0x13c>
    af54:      	cmp	x13, x15
    af58:      	b.gt	0xafb0 <_stogir.floating.operands+0x400>
    af5c:      	ldr	x13, [x0, #0x50]
    af60:      	add	x13, x13, x14, lsl #2
    af64:      	ldr	w13, [x13]
    af68:      	sxtw	x13, w13
    af6c:      	cmp	x13, #0x0
    af70:      	cset	w13, gt
    af74:      	ubfx	x13, x13, #0, #8
    af78:      	b	0xafb4 <_stogir.floating.operands+0x404>
    af7c:      	mov	x0, #0x1                ; =1
    af80:      	str	x0, [x23]
    af84:      	str	x20, [x23, #0x8]
    af88:      	str	x21, [x23, #0x10]
    af8c:      	ldr	x19, [sp, #0x60]
    af90:      	ldr	x20, [sp, #0x68]
    af94:      	ldr	x21, [sp, #0x70]
    af98:      	ldr	x22, [sp, #0x78]
    af9c:      	ldr	x23, [sp, #0x80]
    afa0:      	ldr	x29, [sp]
    afa4:      	ldr	x30, [sp, #0x8]
    afa8:      	add	sp, sp, #0x90
    afac:      	ret
    afb0:      	movz	x13, #0x0, lsl #48
    afb4:      	b	0xacf0 <_stogir.floating.operands+0x140>
    afb8:      	add	x16, sp, #0x30
    afbc:      	ldr	x0, [x16, #0x8]
    afc0:      	cmp	x22, #0x0
    afc4:      	b.lt	0xacd0 <_stogir.floating.operands+0x120>
    afc8:      	uxtb	w0, w0
    afcc:      	cmp	x0, #0x83
    afd0:      	b.ge	0xac94 <_stogir.floating.operands+0xe4>
    afd4:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x34c>
		000000000000afd4:  ARM64_RELOC_PAGE21	l_stogir.475
    afd8:      	ldr	x16, [x16]
		000000000000afd8:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    afdc:      	orr	x1, x16, xzr
    afe0:      	add	x1, x0, x1
    afe4:      	ldrb	w1, [x1]
    afe8:      	b	0xac98 <_stogir.floating.operands+0xe8>
    afec:      	brk	#0
    aff0:      	b	0xafec <_stogir.floating.operands+0x43c>
    aff4:      	brk	#0
    aff8:      	b	0xaff4 <_stogir.floating.operands+0x444>
    affc:      	brk	#0
    b000:      	b	0xaffc <_stogir.floating.operands+0x44c>
    b004:      	mov	x23, x8
    b008:      	b	0xadcc <_stogir.floating.operands+0x21c>

000000000000b00c <_stogir.vector-lanes.operands>:
    b00c:      	sub	sp, sp, #0x110
    b010:      	str	x29, [sp]
    b014:      	str	x30, [sp, #0x8]
    b018:      	mov	x29, sp
    b01c:      	str	x19, [sp, #0xc0]
    b020:      	str	x20, [sp, #0xc8]
    b024:      	str	x21, [sp, #0xd0]
    b028:      	str	x22, [sp, #0xd8]
    b02c:      	str	x23, [sp, #0xe0]
    b030:      	str	x24, [sp, #0xe8]
    b034:      	str	x25, [sp, #0xf0]
    b038:      	str	x26, [sp, #0xf8]
    b03c:      	str	x27, [sp, #0x100]
    b040:      	str	x28, [sp, #0x108]
    b044:      	sxtw	x4, w4
    b048:      	cmp	x4, #0x0
    b04c:      	cset	w7, gt
    b050:      	movz	x16, #0x0, lsl #48
    b054:      	sub	x9, x16, x4
    b058:      	sub	x10, x9, #0x1
    b05c:      	uxtb	w16, w7
    b060:      	cmp	w16, wzr
    b064:      	b.eq	0xb0a4 <_stogir.vector-lanes.operands+0x98>
    b068:      	ldr	x9, [x0, #0x8]
    b06c:      	cmp	x4, x9
    b070:      	b.ge	0xb0fc <_stogir.vector-lanes.operands+0xf0>
    b074:      	add	x9, x0, #0x78
    b078:      	ldr	x9, [x9, #0x8]
    b07c:      	cmp	x4, x9
    b080:      	b.ge	0xb200 <_stogir.vector-lanes.operands+0x1f4>
    b084:      	ldr	x9, [x0, #0x78]
    b088:      	add	x9, x9, x4, lsl #2
    b08c:      	ldr	w9, [x9]
    b090:      	sxtw	x9, w9
    b094:      	cmp	x9, #0x0
    b098:      	cset	w9, ge
    b09c:      	ubfx	x9, x9, #0, #8
    b0a0:      	b	0xb204 <_stogir.vector-lanes.operands+0x1f8>
    b0a4:      	cmp	x4, #0x0
    b0a8:      	b.ge	0xb104 <_stogir.vector-lanes.operands+0xf8>
    b0ac:      	add	x11, x0, #0x28
    b0b0:      	add	x12, x0, #0x50
    b0b4:      	ldr	x11, [x11, #0x8]
    b0b8:      	ldr	x12, [x12, #0x8]
    b0bc:      	cmp	x11, x12
    b0c0:      	b.ne	0xb0ec <_stogir.vector-lanes.operands+0xe0>
    b0c4:      	cmp	x9, x11
    b0c8:      	b.gt	0xb3b4 <_stogir.vector-lanes.operands+0x3a8>
    b0cc:      	ldr	x9, [x0, #0x50]
    b0d0:      	add	x9, x9, x10, lsl #2
    b0d4:      	ldr	w9, [x9]
    b0d8:      	sxtw	x9, w9
    b0dc:      	cmp	x9, #0x0
    b0e0:      	cset	w9, gt
    b0e4:      	ubfx	x9, x9, #0, #8
    b0e8:      	b	0xb3b8 <_stogir.vector-lanes.operands+0x3ac>
    b0ec:      	movz	x9, #0x0, lsl #48
    b0f0:      	b	0xb108 <_stogir.vector-lanes.operands+0xfc>
    b0f4:      	mov	x1, #0x1                ; =1
    b0f8:      	b	0xb190 <_stogir.vector-lanes.operands+0x184>
    b0fc:      	movz	x9, #0x0, lsl #48
    b100:      	b	0xb108 <_stogir.vector-lanes.operands+0xfc>
    b104:      	movz	x9, #0x0, lsl #48
    b108:      	cmp	x9, #0x0
    b10c:      	b.eq	0xb140 <_stogir.vector-lanes.operands+0x134>
    b110:      	uxtb	w16, w7
    b114:      	cmp	w16, wzr
    b118:      	b.eq	0xb12c <_stogir.vector-lanes.operands+0x120>
    b11c:      	ldr	x7, [x0]
    b120:      	add	x4, x7, x4, lsl #4
    b124:      	ldr	x4, [x4]
    b128:      	b	0xb138 <_stogir.vector-lanes.operands+0x12c>
    b12c:      	ldr	x4, [x0, #0x28]
    b130:      	add	x4, x4, x10, lsl #4
    b134:      	ldr	x4, [x4]
    b138:      	mov	x7, #0x1                ; =1
    b13c:      	b	0xb148 <_stogir.vector-lanes.operands+0x13c>
    b140:      	movz	x7, #0x0, lsl #48
    b144:      	movz	x4, #0x0, lsl #48
    b148:      	ubfx	x7, x7, #0, #32
    b14c:      	lsr	x16, x7, #0
    b150:      	cmp	x16, #0x1
    b154:      	b.eq	0xb170 <_stogir.vector-lanes.operands+0x164>
    b158:      	b.lo	0xb160 <_stogir.vector-lanes.operands+0x154>
    b15c:      	b	0xb174 <_stogir.vector-lanes.operands+0x168>
    b160:      	cmp	x16, #0x0
    b164:      	b.eq	0xb16c <_stogir.vector-lanes.operands+0x160>
    b168:      	b	0xb174 <_stogir.vector-lanes.operands+0x168>
    b16c:      	b	0xb178 <_stogir.vector-lanes.operands+0x16c>
    b170:      	b	0xb1d8 <_stogir.vector-lanes.operands+0x1cc>
    b174:      	b	0xb694 <_stogir.vector-lanes.operands+0x688>
    b178:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b178:  ARM64_RELOC_PAGE21	l_stogir.476
    b17c:      	ldr	x16, [x16]
		000000000000b17c:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    b180:      	orr	x19, x16, xzr
    b184:      	str	x8, [sp, #0xa0]
    b188:      	mov	x1, #0x1                ; =1
    b18c:      	mov	x0, #0x1b               ; =27
    b190:      	ldr	x2, [sp, #0xa0]
    b194:      	str	x1, [x2]
    b198:      	str	x19, [x2, #0x8]
    b19c:      	str	x0, [x2, #0x10]
    b1a0:      	ldr	x19, [sp, #0xc0]
    b1a4:      	ldr	x20, [sp, #0xc8]
    b1a8:      	ldr	x21, [sp, #0xd0]
    b1ac:      	ldr	x22, [sp, #0xd8]
    b1b0:      	ldr	x23, [sp, #0xe0]
    b1b4:      	ldr	x24, [sp, #0xe8]
    b1b8:      	ldr	x25, [sp, #0xf0]
    b1bc:      	ldr	x26, [sp, #0xf8]
    b1c0:      	ldr	x27, [sp, #0x100]
    b1c4:      	ldr	x28, [sp, #0x108]
    b1c8:      	ldr	x29, [sp]
    b1cc:      	ldr	x30, [sp, #0x8]
    b1d0:      	add	sp, sp, #0x110
    b1d4:      	ret
    b1d8:      	sxtw	x20, w1
    b1dc:      	sxtw	x1, w2
    b1e0:      	orr	w7, w4, wzr
    b1e4:      	ubfx	x7, x7, #0, #32
    b1e8:      	ubfx	x7, x7, #8, #8
    b1ec:      	orr	x21, x7, xzr
    b1f0:      	cmp	x20, #0x3d
    b1f4:      	b.ne	0xb208 <_stogir.vector-lanes.operands+0x1fc>
    b1f8:      	mov	x22, x21
    b1fc:      	b	0xb20c <_stogir.vector-lanes.operands+0x200>
    b200:      	movz	x9, #0x0, lsl #48
    b204:      	b	0xb100 <_stogir.vector-lanes.operands+0xf4>
    b208:      	mov	x22, x1
    b20c:      	cmp	x20, #0x3d
    b210:      	b.eq	0xb218 <_stogir.vector-lanes.operands+0x20c>
    b214:      	mov	x1, x21
    b218:      	orr	w23, w22, wzr
    b21c:      	sxtw	x24, w23
    b220:      	cmp	x24, #0xf
    b224:      	cset	w25, gt
    b228:      	cmp	x24, #0x80
    b22c:      	cset	w26, lt
    b230:      	and	x7, x24, #0xf
    b234:      	sxtw	x7, w7
    b238:      	cmp	x7, #0x1
    b23c:      	cset	w27, ge
    b240:      	cmp	x7, #0xd
    b244:      	cset	w28, le
    b248:      	cmp	x20, #0x3d
    b24c:      	b.lt	0xb29c <_stogir.vector-lanes.operands+0x290>
    b250:      	cmp	x20, #0x3f
    b254:      	b.gt	0xb29c <_stogir.vector-lanes.operands+0x290>
    b258:      	uxtb	w16, w25
    b25c:      	cmp	w16, wzr
    b260:      	b.eq	0xb29c <_stogir.vector-lanes.operands+0x290>
    b264:      	uxtb	w16, w26
    b268:      	cmp	w16, wzr
    b26c:      	b.eq	0xb29c <_stogir.vector-lanes.operands+0x290>
    b270:      	uxtb	w16, w27
    b274:      	cmp	w16, wzr
    b278:      	b.eq	0xb29c <_stogir.vector-lanes.operands+0x290>
    b27c:      	uxtb	w16, w28
    b280:      	cmp	w16, wzr
    b284:      	b.eq	0xb29c <_stogir.vector-lanes.operands+0x290>
    b288:      	sxtw	x7, w3
    b28c:      	cmp	x7, #0x4
    b290:      	b.eq	0xb6c4 <_stogir.vector-lanes.operands+0x6b8>
    b294:      	cmp	x7, #0x8
    b298:      	b.eq	0xb6c4 <_stogir.vector-lanes.operands+0x6b8>
    b29c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b29c:  ARM64_RELOC_PAGE21	l_stogir.477
    b2a0:      	ldr	x16, [x16]
		000000000000b2a0:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    b2a4:      	orr	x19, x16, xzr
    b2a8:      	mov	x4, #0x36               ; =54
    b2ac:      	sxtw	x7, w5
    b2b0:      	sxtw	x9, w6
    b2b4:      	cmp	x9, #0x0
    b2b8:      	cset	w9, eq
    b2bc:      	cmp	x20, #0x3f
    b2c0:      	b.ne	0xb6fc <_stogir.vector-lanes.operands+0x6f0>
    b2c4:      	mov	w0, w23
    b2c8:      	mov	w2, w3
    b2cc:      	mov	x20, x8
    b2d0:      	mov	x21, x4
    b2d4:      	mov	x23, x7
    b2d8:      	mov	w24, w9
    b2dc:      	bl	0xb2dc <_stogir.vector-lanes.operands+0x2d0>
		000000000000b2dc:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b2e0:      	cmp	x0, #0x0
    b2e4:      	b.eq	0xb4c4 <_stogir.vector-lanes.operands+0x4b8>
    b2e8:      	movz	x0, #0x0, lsl #48
    b2ec:      	b	0xb4c8 <_stogir.vector-lanes.operands+0x4bc>
    b2f0:      	cmp	x20, #0x3d
    b2f4:      	b.ne	0xb708 <_stogir.vector-lanes.operands+0x6fc>
    b2f8:      	str	x0, [sp, #0x80]
    b2fc:      	mov	w0, w23
    b300:      	str	w3, [sp, #0x98]
    b304:      	str	w6, [sp, #0xb0]
    b308:      	str	x1, [sp, #0xa0]
    b30c:      	mov	w1, w2
    b310:      	mov	w2, w3
    b314:      	str	x4, [sp, #0xa8]
    b318:      	str	w8, [sp, #0xb8]
    b31c:      	str	w23, [sp, #0x88]
    b320:      	mov	x23, x7
    b324:      	str	x22, [sp, #0x90]
    b328:      	mov	w22, w5
    b32c:      	bl	0xb32c <_stogir.vector-lanes.operands+0x320>
		000000000000b32c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b330:      	cmp	x0, #0x0
    b334:      	b.ne	0xb34c <_stogir.vector-lanes.operands+0x340>
    b338:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b338:  ARM64_RELOC_PAGE21	l_stogir.478
    b33c:      	ldr	x16, [x16]
		000000000000b33c:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    b340:      	orr	x19, x16, xzr
    b344:      	mov	x16, #0x26              ; =38
    b348:      	str	x16, [sp, #0xa8]
    b34c:      	cmp	x20, #0x3e
    b350:      	b.ne	0xb3e4 <_stogir.vector-lanes.operands+0x3d8>
    b354:      	cmp	x21, x24
    b358:      	cset	w0, eq
    b35c:      	uxtb	w16, w0
    b360:      	cmp	w16, wzr
    b364:      	cset	x0, eq
    b368:      	b	0xb3e8 <_stogir.vector-lanes.operands+0x3dc>
    b36c:      	mov	x0, #0x1                ; =1
    b370:      	cmp	x0, #0x0
    b374:      	b.eq	0xb388 <_stogir.vector-lanes.operands+0x37c>
    b378:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b378:  ARM64_RELOC_PAGE21	l_stogir.479
    b37c:      	ldr	x16, [x16]
		000000000000b37c:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    b380:      	orr	x19, x16, xzr
    b384:      	mov	x21, #0x24              ; =36
    b388:      	str	x22, [sp, #0x90]
    b38c:      	str	x20, [sp, #0xa0]
    b390:      	str	x21, [sp, #0xa8]
    b394:      	ldr	x0, [sp, #0xa8]
    b398:      	cmp	x0, #0x0
    b39c:      	b.ne	0xb0f4 <_stogir.vector-lanes.operands+0xe8>
    b3a0:      	ldr	x0, [sp, #0x90]
    b3a4:      	and	x19, x0, #0xffffffff
    b3a8:      	movz	x1, #0x0, lsl #48
    b3ac:      	movz	x0, #0x0, lsl #48
    b3b0:      	b	0xb0f8 <_stogir.vector-lanes.operands+0xec>
    b3b4:      	movz	x9, #0x0, lsl #48
    b3b8:      	b	0xb0f0 <_stogir.vector-lanes.operands+0xe4>
    b3bc:      	ldr	w0, [sp, #0xb8]
    b3c0:      	uxtb	w16, w0
    b3c4:      	cmp	w16, wzr
    b3c8:      	b.ne	0xb3e0 <_stogir.vector-lanes.operands+0x3d4>
    b3cc:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b3cc:  ARM64_RELOC_PAGE21	l_stogir.480
    b3d0:      	ldr	x16, [x16]
		000000000000b3d0:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    b3d4:      	orr	x19, x16, xzr
    b3d8:      	mov	x16, #0x20              ; =32
    b3dc:      	str	x16, [sp, #0xa8]
    b3e0:      	b	0xb394 <_stogir.vector-lanes.operands+0x388>
    b3e4:      	movz	x0, #0x0, lsl #48
    b3e8:      	cmp	x0, #0x0
    b3ec:      	b.eq	0xb404 <_stogir.vector-lanes.operands+0x3f8>
    b3f0:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b3f0:  ARM64_RELOC_PAGE21	l_stogir.481
    b3f4:      	ldr	x16, [x16]
		000000000000b3f4:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    b3f8:      	orr	x19, x16, xzr
    b3fc:      	mov	x16, #0x27              ; =39
    b400:      	str	x16, [sp, #0xa8]
    b404:      	add	x8, sp, #0x10
    b408:      	ldr	x0, [sp, #0x80]
    b40c:      	mov	w1, w22
    b410:      	bl	0xb410 <_stogir.vector-lanes.operands+0x404>
		000000000000b410:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b414:      	add	x16, sp, #0x10
    b418:      	ldr	w0, [x16]
    b41c:      	lsr	x16, x0, #0
    b420:      	cmp	x16, #0x1
    b424:      	b.eq	0xb440 <_stogir.vector-lanes.operands+0x434>
    b428:      	b.lo	0xb430 <_stogir.vector-lanes.operands+0x424>
    b42c:      	b	0xb444 <_stogir.vector-lanes.operands+0x438>
    b430:      	cmp	x16, #0x0
    b434:      	b.eq	0xb43c <_stogir.vector-lanes.operands+0x430>
    b438:      	b	0xb444 <_stogir.vector-lanes.operands+0x438>
    b43c:      	b	0xb448 <_stogir.vector-lanes.operands+0x43c>
    b440:      	b	0xb4f0 <_stogir.vector-lanes.operands+0x4e4>
    b444:      	b	0xb6ec <_stogir.vector-lanes.operands+0x6e0>
    b448:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b448:  ARM64_RELOC_PAGE21	l_stogir.482
    b44c:      	ldr	x16, [x16]
		000000000000b44c:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    b450:      	orr	x19, x16, xzr
    b454:      	mov	x16, #0x19              ; =25
    b458:      	str	x16, [sp, #0xa8]
    b45c:      	cmp	x20, #0x3e
    b460:      	b.ne	0xb3bc <_stogir.vector-lanes.operands+0x3b0>
    b464:      	ldr	w0, [sp, #0xb0]
    b468:      	add	x8, sp, #0x50
    b46c:      	mov	w1, w0
    b470:      	ldr	x0, [sp, #0x80]
    b474:      	bl	0xb474 <_stogir.vector-lanes.operands+0x468>
		000000000000b474:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b478:      	add	x16, sp, #0x50
    b47c:      	ldr	w0, [x16]
    b480:      	lsr	x16, x0, #0
    b484:      	cmp	x16, #0x1
    b488:      	b.eq	0xb4a4 <_stogir.vector-lanes.operands+0x498>
    b48c:      	b.lo	0xb494 <_stogir.vector-lanes.operands+0x488>
    b490:      	b	0xb4a8 <_stogir.vector-lanes.operands+0x49c>
    b494:      	cmp	x16, #0x0
    b498:      	b.eq	0xb4a0 <_stogir.vector-lanes.operands+0x494>
    b49c:      	b	0xb4a8 <_stogir.vector-lanes.operands+0x49c>
    b4a0:      	b	0xb4ac <_stogir.vector-lanes.operands+0x4a0>
    b4a4:      	b	0xb5dc <_stogir.vector-lanes.operands+0x5d0>
    b4a8:      	b	0xb6f4 <_stogir.vector-lanes.operands+0x6e8>
    b4ac:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b4ac:  ARM64_RELOC_PAGE21	l_stogir.483
    b4b0:      	ldr	x16, [x16]
		000000000000b4b0:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    b4b4:      	orr	x19, x16, xzr
    b4b8:      	mov	x16, #0x20              ; =32
    b4bc:      	str	x16, [sp, #0xa8]
    b4c0:      	b	0xb3e0 <_stogir.vector-lanes.operands+0x3d4>
    b4c4:      	mov	x0, #0x1                ; =1
    b4c8:      	cmp	x0, #0x0
    b4cc:      	b.eq	0xb4d8 <_stogir.vector-lanes.operands+0x4cc>
    b4d0:      	mov	x0, #0x1                ; =1
    b4d4:      	b	0xb370 <_stogir.vector-lanes.operands+0x364>
    b4d8:      	cmp	x23, #0x0
    b4dc:      	b.ne	0xb36c <_stogir.vector-lanes.operands+0x360>
    b4e0:      	uxtb	w16, w24
    b4e4:      	cmp	w16, wzr
    b4e8:      	cset	x0, eq
    b4ec:      	b	0xb370 <_stogir.vector-lanes.operands+0x364>
    b4f0:      	add	x16, sp, #0x10
    b4f4:      	orr	x0, x16, xzr
    b4f8:      	add	x0, x0, #0x8
    b4fc:      	add	x16, sp, #0x10
    b500:      	ldr	x1, [x16, #0x8]
    b504:      	add	x16, sp, #0x40
    b508:      	str	x1, [x16]
    b50c:      	ldr	x0, [x0, #0x8]
    b510:      	ubfx	x1, x1, #0, #32
    b514:      	add	x16, sp, #0x40
    b518:      	str	x0, [x16, #0x8]
    b51c:      	ubfx	x0, x1, #8, #8
    b520:      	cmp	x0, #0x1
    b524:      	b.lt	0xb54c <_stogir.vector-lanes.operands+0x540>
    b528:      	cmp	x0, #0xb
    b52c:      	b.gt	0xb54c <_stogir.vector-lanes.operands+0x540>
    b530:      	add	x16, sp, #0x40
    b534:      	ldr	w0, [x16]
    b538:      	uxtb	w0, w0
    b53c:      	cmp	x0, #0x48
    b540:      	b.eq	0xb54c <_stogir.vector-lanes.operands+0x540>
    b544:      	cmp	x0, #0x46
    b548:      	b.ne	0xb560 <_stogir.vector-lanes.operands+0x554>
    b54c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b54c:  ARM64_RELOC_PAGE21	l_stogir.484
    b550:      	ldr	x16, [x16]
		000000000000b550:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    b554:      	orr	x19, x16, xzr
    b558:      	mov	x16, #0x2b              ; =43
    b55c:      	str	x16, [sp, #0xa8]
    b560:      	cmp	x23, #0x0
    b564:      	b.ge	0xb590 <_stogir.vector-lanes.operands+0x584>
    b568:      	add	x16, sp, #0x40
    b56c:      	ldr	w0, [x16]
    b570:      	uxtb	w1, w0
    b574:      	ubfx	x0, x0, #8, #8
    b578:      	cmp	x1, x0
    b57c:      	b.eq	0xb634 <_stogir.vector-lanes.operands+0x628>
    b580:      	cmp	x1, #0x49
    b584:      	b.eq	0xb634 <_stogir.vector-lanes.operands+0x628>
    b588:      	movz	x0, #0x0, lsl #48
    b58c:      	b	0xb5d8 <_stogir.vector-lanes.operands+0x5cc>
    b590:      	movz	x0, #0x0, lsl #48
    b594:      	cmp	x0, #0x0
    b598:      	b.eq	0xb5b0 <_stogir.vector-lanes.operands+0x5a4>
    b59c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b59c:  ARM64_RELOC_PAGE21	l_stogir.485
    b5a0:      	ldr	x16, [x16]
		000000000000b5a0:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    b5a4:      	orr	x19, x16, xzr
    b5a8:      	mov	x16, #0x28              ; =40
    b5ac:      	str	x16, [sp, #0xa8]
    b5b0:      	b	0xb45c <_stogir.vector-lanes.operands+0x450>
    b5b4:      	movn	x2, #0x0, lsl #48
    b5b8:      	ubfx	x0, x0, #0, #32
    b5bc:      	ubfx	x1, x1, #0, #32
    b5c0:      	lsl	x1, x1, #32
    b5c4:      	orr	x0, x1, x0
    b5c8:      	sxtw	x2, w2
    b5cc:      	cmp	x0, x2
    b5d0:      	cset	w0, hs
    b5d4:      	ubfx	x0, x0, #0, #8
    b5d8:      	b	0xb594 <_stogir.vector-lanes.operands+0x588>
    b5dc:      	add	x16, sp, #0x50
    b5e0:      	ldr	x0, [x16, #0x8]
    b5e4:      	uxtb	w1, w0
    b5e8:      	cmp	x1, #0x48
    b5ec:      	b.eq	0xb61c <_stogir.vector-lanes.operands+0x610>
    b5f0:      	cmp	x1, #0x46
    b5f4:      	b.eq	0xb61c <_stogir.vector-lanes.operands+0x610>
    b5f8:      	ldr	w1, [sp, #0x98]
    b5fc:      	ubfx	x0, x0, #0, #32
    b600:      	ubfx	x0, x0, #8, #8
    b604:      	mov	w2, w1
    b608:      	mov	w1, w0
    b60c:      	ldr	w0, [sp, #0x88]
    b610:      	bl	0xb610 <_stogir.vector-lanes.operands+0x604>
		000000000000b610:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b614:      	cmp	x0, #0x0
    b618:      	b.ne	0xb630 <_stogir.vector-lanes.operands+0x624>
    b61c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b61c:  ARM64_RELOC_PAGE21	l_stogir.486
    b620:      	ldr	x16, [x16]
		000000000000b620:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    b624:      	orr	x19, x16, xzr
    b628:      	mov	x16, #0x27              ; =39
    b62c:      	str	x16, [sp, #0xa8]
    b630:      	b	0xb4c0 <_stogir.vector-lanes.operands+0x4b4>
    b634:      	add	x16, sp, #0x40
    b638:      	ldr	w0, [x16, #0x8]
    b63c:      	add	x16, sp, #0x40
    b640:      	ldr	w1, [x16, #0xc]
    b644:      	uxtb	w16, w25
    b648:      	cmp	w16, wzr
    b64c:      	b.eq	0xb69c <_stogir.vector-lanes.operands+0x690>
    b650:      	uxtb	w16, w26
    b654:      	cmp	w16, wzr
    b658:      	b.eq	0xb69c <_stogir.vector-lanes.operands+0x690>
    b65c:      	uxtb	w16, w27
    b660:      	cmp	w16, wzr
    b664:      	b.eq	0xb69c <_stogir.vector-lanes.operands+0x690>
    b668:      	uxtb	w16, w28
    b66c:      	cmp	w16, wzr
    b670:      	b.eq	0xb69c <_stogir.vector-lanes.operands+0x690>
    b674:      	ubfx	x2, x24, #4, #32
    b678:      	sxtw	x2, w2
    b67c:      	sub	x2, x2, #0x1
    b680:      	sxtw	x2, w2
    b684:      	mov	x16, #0x1               ; =1
    b688:      	lsl	x2, x16, x2
    b68c:      	sxtw	x2, w2
    b690:      	b	0xb5b8 <_stogir.vector-lanes.operands+0x5ac>
    b694:      	brk	#0
    b698:      	b	0xb694 <_stogir.vector-lanes.operands+0x688>
    b69c:      	cmp	x24, #0x0
    b6a0:      	b.lt	0xb5b4 <_stogir.vector-lanes.operands+0x5a8>
    b6a4:      	cmp	x24, #0xd
    b6a8:      	b.gt	0xb5b4 <_stogir.vector-lanes.operands+0x5a8>
    b6ac:      	cmp	x24, #0x0
    b6b0:      	cset	w2, eq
    b6b4:      	uxtb	w16, w2
    b6b8:      	cmp	w16, wzr
    b6bc:      	cset	x2, eq
    b6c0:      	b	0xb5b8 <_stogir.vector-lanes.operands+0x5ac>
    b6c4:      	uxtb	w4, w4
    b6c8:      	cmp	x4, #0x48
    b6cc:      	b.eq	0xb29c <_stogir.vector-lanes.operands+0x290>
    b6d0:      	cmp	x4, #0x46
    b6d4:      	b.eq	0xb29c <_stogir.vector-lanes.operands+0x290>
    b6d8:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b6d8:  ARM64_RELOC_PAGE21	l_stogir.487
    b6dc:      	ldr	x16, [x16]
		000000000000b6dc:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b6e0:      	orr	x19, x16, xzr
    b6e4:      	movz	x4, #0x0, lsl #48
    b6e8:      	b	0xb2ac <_stogir.vector-lanes.operands+0x2a0>
    b6ec:      	brk	#0
    b6f0:      	b	0xb6ec <_stogir.vector-lanes.operands+0x6e0>
    b6f4:      	brk	#0
    b6f8:      	b	0xb6f4 <_stogir.vector-lanes.operands+0x6e8>
    b6fc:      	mov	x1, x8
    b700:      	mov	w8, w9
    b704:      	b	0xb2f0 <_stogir.vector-lanes.operands+0x2e4>
    b708:      	str	x22, [sp, #0x90]
    b70c:      	str	x1, [sp, #0xa0]
    b710:      	str	x0, [sp, #0x80]
    b714:      	str	w3, [sp, #0x98]
    b718:      	mov	w22, w5
    b71c:      	str	w6, [sp, #0xb0]
    b720:      	str	w23, [sp, #0x88]
    b724:      	mov	x23, x7
    b728:      	str	w8, [sp, #0xb8]
    b72c:      	str	x4, [sp, #0xa8]
    b730:      	b	0xb34c <_stogir.vector-lanes.operands+0x340>

000000000000b734 <_stogir.vector-comparison.operands>:
    b734:      	sub	sp, sp, #0xc0
    b738:      	str	x29, [sp]
    b73c:      	str	x30, [sp, #0x8]
    b740:      	mov	x29, sp
    b744:      	str	x19, [sp, #0x70]
    b748:      	str	x20, [sp, #0x78]
    b74c:      	str	x21, [sp, #0x80]
    b750:      	str	x22, [sp, #0x88]
    b754:      	str	x23, [sp, #0x90]
    b758:      	str	x24, [sp, #0x98]
    b75c:      	str	x25, [sp, #0xa0]
    b760:      	str	x26, [sp, #0xa8]
    b764:      	str	x27, [sp, #0xb0]
    b768:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b768:  ARM64_RELOC_PAGE21	l_stogir.488
    b76c:      	ldr	x16, [x16]
		000000000000b76c:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    b770:      	orr	x19, x16, xzr
    b774:      	mov	x20, x8
    b778:      	add	x8, sp, #0x10
    b77c:      	mov	x21, x0
    b780:      	mov	w22, w1
    b784:      	mov	w1, w4
    b788:      	mov	w23, w2
    b78c:      	mov	w24, w3
    b790:      	mov	w25, w5
    b794:      	bl	0xb794 <_stogir.vector-comparison.operands+0x60>
		000000000000b794:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b798:      	add	x16, sp, #0x10
    b79c:      	ldr	w0, [x16]
    b7a0:      	lsr	x16, x0, #0
    b7a4:      	cmp	x16, #0x1
    b7a8:      	b.eq	0xb7c4 <_stogir.vector-comparison.operands+0x90>
    b7ac:      	b.lo	0xb7b4 <_stogir.vector-comparison.operands+0x80>
    b7b0:      	b	0xb7c8 <_stogir.vector-comparison.operands+0x94>
    b7b4:      	cmp	x16, #0x0
    b7b8:      	b.eq	0xb7c0 <_stogir.vector-comparison.operands+0x8c>
    b7bc:      	b	0xb7c8 <_stogir.vector-comparison.operands+0x94>
    b7c0:      	b	0xb7cc <_stogir.vector-comparison.operands+0x98>
    b7c4:      	b	0xb814 <_stogir.vector-comparison.operands+0xe0>
    b7c8:      	b	0xb98c <_stogir.vector-comparison.operands+0x258>
    b7cc:      	mov	x0, #0x1                ; =1
    b7d0:      	mov	x1, #0x21               ; =33
    b7d4:      	str	x0, [x20]
    b7d8:      	str	x19, [x20, #0x8]
    b7dc:      	str	x1, [x20, #0x10]
    b7e0:      	ldr	x19, [sp, #0x70]
    b7e4:      	ldr	x20, [sp, #0x78]
    b7e8:      	ldr	x21, [sp, #0x80]
    b7ec:      	ldr	x22, [sp, #0x88]
    b7f0:      	ldr	x23, [sp, #0x90]
    b7f4:      	ldr	x24, [sp, #0x98]
    b7f8:      	ldr	x25, [sp, #0xa0]
    b7fc:      	ldr	x26, [sp, #0xa8]
    b800:      	ldr	x27, [sp, #0xb0]
    b804:      	ldr	x29, [sp]
    b808:      	ldr	x30, [sp, #0x8]
    b80c:      	add	sp, sp, #0xc0
    b810:      	ret
    b814:      	add	x16, sp, #0x10
    b818:      	ldr	x26, [x16, #0x8]
    b81c:      	add	x8, sp, #0x40
    b820:      	mov	x0, x21
    b824:      	mov	w1, w25
    b828:      	bl	0xb828 <_stogir.vector-comparison.operands+0xf4>
		000000000000b828:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b82c:      	add	x16, sp, #0x40
    b830:      	ldr	w0, [x16]
    b834:      	lsr	x16, x0, #0
    b838:      	cmp	x16, #0x1
    b83c:      	b.eq	0xb858 <_stogir.vector-comparison.operands+0x124>
    b840:      	b.lo	0xb848 <_stogir.vector-comparison.operands+0x114>
    b844:      	b	0xb85c <_stogir.vector-comparison.operands+0x128>
    b848:      	cmp	x16, #0x0
    b84c:      	b.eq	0xb854 <_stogir.vector-comparison.operands+0x120>
    b850:      	b	0xb85c <_stogir.vector-comparison.operands+0x128>
    b854:      	b	0xb860 <_stogir.vector-comparison.operands+0x12c>
    b858:      	b	0xb86c <_stogir.vector-comparison.operands+0x138>
    b85c:      	b	0xb994 <_stogir.vector-comparison.operands+0x260>
    b860:      	mov	x0, #0x1                ; =1
    b864:      	mov	x1, #0x21               ; =33
    b868:      	b	0xb7d4 <_stogir.vector-comparison.operands+0xa0>
    b86c:      	sxtw	x0, w24
    b870:      	add	x16, sp, #0x40
    b874:      	ldr	x19, [x16, #0x8]
    b878:      	cmp	x0, #0x4
    b87c:      	b.eq	0xb8a0 <_stogir.vector-comparison.operands+0x16c>
    b880:      	cmp	x0, #0x8
    b884:      	b.eq	0xb8a0 <_stogir.vector-comparison.operands+0x16c>
    b888:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000b888:  ARM64_RELOC_PAGE21	l_stogir.489
    b88c:      	ldr	x16, [x16]
		000000000000b88c:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    b890:      	orr	x19, x16, xzr
    b894:      	mov	x0, #0x1                ; =1
    b898:      	mov	x1, #0x33               ; =51
    b89c:      	b	0xb868 <_stogir.vector-comparison.operands+0x134>
    b8a0:      	orr	w0, w26, wzr
    b8a4:      	ubfx	x0, x0, #0, #32
    b8a8:      	ubfx	x21, x0, #8, #8
    b8ac:      	orr	x0, x21, xzr
    b8b0:      	mov	w1, w0
    b8b4:      	mov	w0, w22
    b8b8:      	bl	0xb8b8 <_stogir.vector-comparison.operands+0x184>
		000000000000b8b8:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    b8bc:      	cmp	x0, #0x0
    b8c0:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b8c4:      	orr	w0, w19, wzr
    b8c8:      	ubfx	x0, x0, #0, #32
    b8cc:      	ubfx	x0, x0, #8, #8
    b8d0:      	cmp	x21, x0
    b8d4:      	b.ne	0xb888 <_stogir.vector-comparison.operands+0x154>
    b8d8:      	uxtb	w26, w26
    b8dc:      	cmp	x26, #0x48
    b8e0:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b8e4:      	cmp	x26, #0x46
    b8e8:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b8ec:      	uxtb	w19, w19
    b8f0:      	cmp	x19, #0x48
    b8f4:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b8f8:      	cmp	x19, #0x46
    b8fc:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b900:      	sxtw	x23, w23
    b904:      	cmp	x23, #0xf
    b908:      	cset	w0, gt
    b90c:      	uxtb	w16, w0
    b910:      	cmp	w16, wzr
    b914:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b918:      	cmp	x23, #0x80
    b91c:      	cset	w1, lt
    b920:      	uxtb	w16, w1
    b924:      	cmp	w16, wzr
    b928:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b92c:      	and	x2, x23, #0xf
    b930:      	sxtw	x2, w2
    b934:      	cmp	x2, #0x1
    b938:      	cset	w3, ge
    b93c:      	uxtb	w16, w3
    b940:      	cmp	w16, wzr
    b944:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b948:      	cmp	x2, #0xd
    b94c:      	cset	w4, le
    b950:      	uxtb	w16, w4
    b954:      	cmp	w16, wzr
    b958:      	b.eq	0xb888 <_stogir.vector-comparison.operands+0x154>
    b95c:      	cmp	x23, #0x0
    b960:      	cset	w5, ge
    b964:      	cmp	x23, #0xd
    b968:      	cset	w6, le
    b96c:      	uxtb	w16, w5
    b970:      	cmp	w16, wzr
    b974:      	b.eq	0xb99c <_stogir.vector-comparison.operands+0x268>
    b978:      	uxtb	w16, w6
    b97c:      	cmp	w16, wzr
    b980:      	b.eq	0xb99c <_stogir.vector-comparison.operands+0x268>
    b984:      	mov	x7, x2
    b988:      	b	0xb9d0 <_stogir.vector-comparison.operands+0x29c>
    b98c:      	brk	#0
    b990:      	b	0xb98c <_stogir.vector-comparison.operands+0x258>
    b994:      	brk	#0
    b998:      	b	0xb994 <_stogir.vector-comparison.operands+0x260>
    b99c:      	uxtb	w16, w0
    b9a0:      	cmp	w16, wzr
    b9a4:      	b.eq	0xb9cc <_stogir.vector-comparison.operands+0x298>
    b9a8:      	uxtb	w16, w1
    b9ac:      	cmp	w16, wzr
    b9b0:      	b.eq	0xb9cc <_stogir.vector-comparison.operands+0x298>
    b9b4:      	uxtb	w16, w3
    b9b8:      	cmp	w16, wzr
    b9bc:      	b.eq	0xb9cc <_stogir.vector-comparison.operands+0x298>
    b9c0:      	uxtb	w16, w4
    b9c4:      	cmp	w16, wzr
    b9c8:      	b.ne	0xb984 <_stogir.vector-comparison.operands+0x250>
    b9cc:      	movn	x7, #0x0, lsl #48
    b9d0:      	sxtw	x7, w7
    b9d4:      	cmp	x7, #0x1
    b9d8:      	b.lt	0xb888 <_stogir.vector-comparison.operands+0x154>
    b9dc:      	cmp	x7, #0xb
    b9e0:      	b.gt	0xb888 <_stogir.vector-comparison.operands+0x154>
    b9e4:      	uxtb	w16, w0
    b9e8:      	cmp	w16, wzr
    b9ec:      	b.eq	0xba34 <_stogir.vector-comparison.operands+0x300>
    b9f0:      	uxtb	w16, w1
    b9f4:      	cmp	w16, wzr
    b9f8:      	b.eq	0xba34 <_stogir.vector-comparison.operands+0x300>
    b9fc:      	uxtb	w16, w3
    ba00:      	cmp	w16, wzr
    ba04:      	b.eq	0xba34 <_stogir.vector-comparison.operands+0x300>
    ba08:      	uxtb	w16, w4
    ba0c:      	cmp	w16, wzr
    ba10:      	b.eq	0xba34 <_stogir.vector-comparison.operands+0x300>
    ba14:      	ubfx	x7, x23, #4, #32
    ba18:      	sxtw	x7, w7
    ba1c:      	sub	x7, x7, #0x1
    ba20:      	sxtw	x7, w7
    ba24:      	mov	x16, #0x1               ; =1
    ba28:      	lsl	x7, x16, x7
    ba2c:      	sxtw	x7, w7
    ba30:      	b	0xbb40 <_stogir.vector-comparison.operands+0x40c>
    ba34:      	uxtb	w16, w5
    ba38:      	cmp	w16, wzr
    ba3c:      	b.eq	0xbb3c <_stogir.vector-comparison.operands+0x408>
    ba40:      	uxtb	w16, w6
    ba44:      	cmp	w16, wzr
    ba48:      	b.eq	0xbb3c <_stogir.vector-comparison.operands+0x408>
    ba4c:      	cmp	x23, #0x0
    ba50:      	cset	w7, eq
    ba54:      	uxtb	w16, w7
    ba58:      	cmp	w16, wzr
    ba5c:      	cset	x7, eq
    ba60:      	b	0xbb40 <_stogir.vector-comparison.operands+0x40c>
    ba64:      	movn	x8, #0x0, lsl #48
    ba68:      	sxtw	x7, w7
    ba6c:      	sxtw	x8, w8
    ba70:      	cmp	x7, x8
    ba74:      	b.ne	0xb888 <_stogir.vector-comparison.operands+0x154>
    ba78:      	uxtb	w16, w5
    ba7c:      	cmp	w16, wzr
    ba80:      	b.eq	0xba90 <_stogir.vector-comparison.operands+0x35c>
    ba84:      	uxtb	w16, w6
    ba88:      	cmp	w16, wzr
    ba8c:      	b.ne	0xbac4 <_stogir.vector-comparison.operands+0x390>
    ba90:      	uxtb	w16, w0
    ba94:      	cmp	w16, wzr
    ba98:      	b.eq	0xbac0 <_stogir.vector-comparison.operands+0x38c>
    ba9c:      	uxtb	w16, w1
    baa0:      	cmp	w16, wzr
    baa4:      	b.eq	0xbac0 <_stogir.vector-comparison.operands+0x38c>
    baa8:      	uxtb	w16, w3
    baac:      	cmp	w16, wzr
    bab0:      	b.eq	0xbac0 <_stogir.vector-comparison.operands+0x38c>
    bab4:      	uxtb	w16, w4
    bab8:      	cmp	w16, wzr
    babc:      	b.ne	0xbac4 <_stogir.vector-comparison.operands+0x390>
    bac0:      	movn	x2, #0x0, lsl #48
    bac4:      	mov	w0, w2
    bac8:      	mov	w1, w24
    bacc:      	bl	0xbacc <_stogir.vector-comparison.operands+0x398>
		000000000000bacc:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    bad0:      	uxtb	w16, w19
    bad4:      	cmp	w16, wzr
    bad8:      	b.ne	0xbb10 <_stogir.vector-comparison.operands+0x3dc>
    badc:      	uxtb	w16, w22
    bae0:      	cmp	w16, wzr
    bae4:      	b.eq	0xbb0c <_stogir.vector-comparison.operands+0x3d8>
    bae8:      	uxtb	w16, w23
    baec:      	cmp	w16, wzr
    baf0:      	b.eq	0xbb0c <_stogir.vector-comparison.operands+0x3d8>
    baf4:      	uxtb	w16, w26
    baf8:      	cmp	w16, wzr
    bafc:      	b.eq	0xbb0c <_stogir.vector-comparison.operands+0x3d8>
    bb00:      	uxtb	w16, w27
    bb04:      	cmp	w16, wzr
    bb08:      	b.ne	0xbb10 <_stogir.vector-comparison.operands+0x3dc>
    bb0c:      	movn	x25, #0x0, lsl #48
    bb10:      	sxtw	x19, w0
    bb14:      	mov	w0, w25
    bb18:      	mov	w1, w24
    bb1c:      	bl	0xbb1c <_stogir.vector-comparison.operands+0x3e8>
		000000000000bb1c:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    bb20:      	sxtw	x0, w0
    bb24:      	cmp	x19, x0
    bb28:      	b.ne	0xb888 <_stogir.vector-comparison.operands+0x154>
    bb2c:      	and	x19, x21, #0xffffffff
    bb30:      	movz	x0, #0x0, lsl #48
    bb34:      	movz	x1, #0x0, lsl #48
    bb38:      	b	0xb89c <_stogir.vector-comparison.operands+0x168>
    bb3c:      	movn	x7, #0x0, lsl #48
    bb40:      	and	x8, x21, #0xf
    bb44:      	cmp	x21, #0xd
    bb48:      	cset	w19, le
    bb4c:      	cmp	x21, #0xf
    bb50:      	cset	w22, gt
    bb54:      	cmp	x21, #0x80
    bb58:      	cset	w23, lt
    bb5c:      	sxtw	x25, w8
    bb60:      	cmp	x25, #0x1
    bb64:      	cset	w26, ge
    bb68:      	cmp	x25, #0xd
    bb6c:      	cset	w27, le
    bb70:      	uxtb	w16, w22
    bb74:      	cmp	w16, wzr
    bb78:      	b.eq	0xbbc0 <_stogir.vector-comparison.operands+0x48c>
    bb7c:      	uxtb	w16, w23
    bb80:      	cmp	w16, wzr
    bb84:      	b.eq	0xbbc0 <_stogir.vector-comparison.operands+0x48c>
    bb88:      	uxtb	w16, w26
    bb8c:      	cmp	w16, wzr
    bb90:      	b.eq	0xbbc0 <_stogir.vector-comparison.operands+0x48c>
    bb94:      	uxtb	w16, w27
    bb98:      	cmp	w16, wzr
    bb9c:      	b.eq	0xbbc0 <_stogir.vector-comparison.operands+0x48c>
    bba0:      	ubfx	x8, x21, #4, #32
    bba4:      	sxtw	x8, w8
    bba8:      	sub	x8, x8, #0x1
    bbac:      	sxtw	x8, w8
    bbb0:      	mov	x16, #0x1               ; =1
    bbb4:      	lsl	x8, x16, x8
    bbb8:      	sxtw	x8, w8
    bbbc:      	b	0xba68 <_stogir.vector-comparison.operands+0x334>
    bbc0:      	uxtb	w16, w19
    bbc4:      	cmp	w16, wzr
    bbc8:      	b.eq	0xba64 <_stogir.vector-comparison.operands+0x330>
    bbcc:      	cmp	x21, #0x0
    bbd0:      	cset	w8, eq
    bbd4:      	uxtb	w16, w8
    bbd8:      	cmp	w16, wzr
    bbdc:      	cset	x8, eq
    bbe0:      	b	0xba68 <_stogir.vector-comparison.operands+0x334>

000000000000bbe4 <_stogir.vector-arithmetic.operands>:
    bbe4:      	sub	sp, sp, #0x80
    bbe8:      	str	x29, [sp]
    bbec:      	str	x30, [sp, #0x8]
    bbf0:      	mov	x29, sp
    bbf4:      	str	x19, [sp, #0x30]
    bbf8:      	str	x20, [sp, #0x38]
    bbfc:      	str	x21, [sp, #0x40]
    bc00:      	str	x22, [sp, #0x48]
    bc04:      	str	x23, [sp, #0x50]
    bc08:      	str	x24, [sp, #0x58]
    bc0c:      	str	x25, [sp, #0x60]
    bc10:      	str	x26, [sp, #0x68]
    bc14:      	str	x27, [sp, #0x70]
    bc18:      	str	x28, [sp, #0x78]
    bc1c:      	mov	x19, x8
    bc20:      	mov	x20, x0
    bc24:      	mov	w0, w1
    bc28:      	mov	w21, w1
    bc2c:      	mov	w1, w2
    bc30:      	mov	w22, w2
    bc34:      	mov	w23, w3
    bc38:      	mov	w24, w4
    bc3c:      	mov	w25, w5
    bc40:      	bl	0xbc40 <_stogir.vector-arithmetic.operands+0x5c>
		000000000000bc40:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    bc44:      	cmp	x0, #0x0
    bc48:      	b.eq	0xbc60 <_stogir.vector-arithmetic.operands+0x7c>
    bc4c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000bc4c:  ARM64_RELOC_PAGE21	l_stogir.490
    bc50:      	ldr	x16, [x16]
		000000000000bc50:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    bc54:      	orr	x0, x16, xzr
    bc58:      	movz	x1, #0x0, lsl #48
    bc5c:      	b	0xbc70 <_stogir.vector-arithmetic.operands+0x8c>
    bc60:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000bc60:  ARM64_RELOC_PAGE21	l_stogir.491
    bc64:      	ldr	x16, [x16]
		000000000000bc64:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    bc68:      	orr	x0, x16, xzr
    bc6c:      	mov	x1, #0x37               ; =55
    bc70:      	sxtw	x21, w21
    bc74:      	sxtw	x22, w22
    bc78:      	sxtw	x23, w23
    bc7c:      	sxtw	x24, w24
    bc80:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000bc80:  ARM64_RELOC_PAGE21	l_stogir.492
    bc84:      	ldr	x16, [x16]
		000000000000bc84:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    bc88:      	orr	x2, x16, xzr
    bc8c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000bc8c:  ARM64_RELOC_PAGE21	l_stogir.493
    bc90:      	ldr	x16, [x16]
		000000000000bc90:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    bc94:      	orr	x3, x16, xzr
    bc98:      	add	x4, x20, #0x78
    bc9c:      	add	x5, x20, #0x28
    bca0:      	add	x6, x20, #0x50
    bca4:      	cmp	x21, #0x31
    bca8:      	cset	w7, ge
    bcac:      	cmp	x21, #0x35
    bcb0:      	cset	w8, le
    bcb4:      	cmp	x21, #0x1f
    bcb8:      	cset	w9, eq
    bcbc:      	cmp	x21, #0x20
    bcc0:      	cset	w10, eq
    bcc4:      	cmp	x21, #0x2d
    bcc8:      	cset	w11, eq
    bccc:      	cmp	x21, #0x36
    bcd0:      	cset	w12, eq
    bcd4:      	cmp	x21, #0x37
    bcd8:      	cset	w13, eq
    bcdc:      	cmp	x21, #0x38
    bce0:      	cset	w14, eq
    bce4:      	cmp	x21, #0x39
    bce8:      	cset	w15, eq
    bcec:      	movz	x26, #0x0, lsl #48
    bcf0:      	b	0xbe14 <_stogir.vector-arithmetic.operands+0x230>
    bcf4:      	movz	x2, #0x0, lsl #48
    bcf8:      	b	0xbd08 <_stogir.vector-arithmetic.operands+0x124>
    bcfc:      	movz	x2, #0x0, lsl #48
    bd00:      	b	0xbd10 <_stogir.vector-arithmetic.operands+0x12c>
    bd04:      	movz	x2, #0x0, lsl #48
    bd08:      	b	0xbd20 <_stogir.vector-arithmetic.operands+0x13c>
    bd0c:      	movz	x2, #0x0, lsl #48
    bd10:      	str	x4, [sp, #0x20]
    bd14:      	str	x5, [sp, #0x28]
    bd18:      	b	0xbd20 <_stogir.vector-arithmetic.operands+0x13c>
    bd1c:      	movz	x2, #0x0, lsl #48
    bd20:      	cmp	x2, #0x0
    bd24:      	b.eq	0xbd58 <_stogir.vector-arithmetic.operands+0x174>
    bd28:      	uxtb	w16, w28
    bd2c:      	cmp	w16, wzr
    bd30:      	b.eq	0xbd44 <_stogir.vector-arithmetic.operands+0x160>
    bd34:      	ldr	x2, [x20]
    bd38:      	add	x2, x2, x27, lsl #4
    bd3c:      	ldr	x2, [x2]
    bd40:      	b	0xbd50 <_stogir.vector-arithmetic.operands+0x16c>
    bd44:      	ldr	x2, [x20, #0x28]
    bd48:      	add	x2, x2, x3, lsl #4
    bd4c:      	ldr	x2, [x2]
    bd50:      	mov	x3, #0x1                ; =1
    bd54:      	b	0xbd60 <_stogir.vector-arithmetic.operands+0x17c>
    bd58:      	movz	x3, #0x0, lsl #48
    bd5c:      	movz	x2, #0x0, lsl #48
    bd60:      	ubfx	x3, x3, #0, #32
    bd64:      	lsr	x16, x3, #0
    bd68:      	cmp	x16, #0x1
    bd6c:      	b.eq	0xbd88 <_stogir.vector-arithmetic.operands+0x1a4>
    bd70:      	b.lo	0xbd78 <_stogir.vector-arithmetic.operands+0x194>
    bd74:      	b	0xbd8c <_stogir.vector-arithmetic.operands+0x1a8>
    bd78:      	cmp	x16, #0x0
    bd7c:      	b.eq	0xbd84 <_stogir.vector-arithmetic.operands+0x1a0>
    bd80:      	b	0xbd8c <_stogir.vector-arithmetic.operands+0x1a8>
    bd84:      	b	0xbd90 <_stogir.vector-arithmetic.operands+0x1ac>
    bd88:      	b	0xbd9c <_stogir.vector-arithmetic.operands+0x1b8>
    bd8c:      	b	0xc0f8 <_stogir.vector-arithmetic.operands+0x514>
    bd90:      	ldr	x0, [sp, #0x10]
    bd94:      	mov	x1, #0x21               ; =33
    bd98:      	b	0xbdfc <_stogir.vector-arithmetic.operands+0x218>
    bd9c:      	orr	w3, w2, wzr
    bda0:      	ubfx	x3, x3, #0, #32
    bda4:      	ubfx	x3, x3, #8, #8
    bda8:      	cmp	x3, x22
    bdac:      	b.eq	0xbde0 <_stogir.vector-arithmetic.operands+0x1fc>
    bdb0:      	cmp	x26, #0x1
    bdb4:      	b.ne	0xbdf4 <_stogir.vector-arithmetic.operands+0x210>
    bdb8:      	uxtb	w16, w7
    bdbc:      	cmp	w16, wzr
    bdc0:      	b.eq	0xbdf4 <_stogir.vector-arithmetic.operands+0x210>
    bdc4:      	uxtb	w16, w8
    bdc8:      	cmp	w16, wzr
    bdcc:      	b.eq	0xbdf4 <_stogir.vector-arithmetic.operands+0x210>
    bdd0:      	cmp	x3, #0x1
    bdd4:      	b.lt	0xbdf4 <_stogir.vector-arithmetic.operands+0x210>
    bdd8:      	cmp	x3, #0xb
    bddc:      	b.gt	0xbdf4 <_stogir.vector-arithmetic.operands+0x210>
    bde0:      	uxtb	w2, w2
    bde4:      	cmp	x2, #0x48
    bde8:      	b.eq	0xbdf4 <_stogir.vector-arithmetic.operands+0x210>
    bdec:      	cmp	x2, #0x46
    bdf0:      	b.ne	0xbdfc <_stogir.vector-arithmetic.operands+0x218>
    bdf4:      	ldr	x0, [sp, #0x18]
    bdf8:      	mov	x1, #0x32               ; =50
    bdfc:      	add	x2, x26, #0x1
    be00:      	sxtw	x26, w2
    be04:      	ldr	x2, [sp, #0x10]
    be08:      	ldr	x3, [sp, #0x18]
    be0c:      	ldr	x4, [sp, #0x20]
    be10:      	ldr	x5, [sp, #0x28]
    be14:      	uxtb	w16, w9
    be18:      	cmp	w16, wzr
    be1c:      	b.ne	0xbe70 <_stogir.vector-arithmetic.operands+0x28c>
    be20:      	uxtb	w16, w10
    be24:      	cmp	w16, wzr
    be28:      	b.ne	0xbe70 <_stogir.vector-arithmetic.operands+0x28c>
    be2c:      	uxtb	w16, w11
    be30:      	cmp	w16, wzr
    be34:      	b.ne	0xbe70 <_stogir.vector-arithmetic.operands+0x28c>
    be38:      	uxtb	w16, w12
    be3c:      	cmp	w16, wzr
    be40:      	b.ne	0xbe70 <_stogir.vector-arithmetic.operands+0x28c>
    be44:      	uxtb	w16, w13
    be48:      	cmp	w16, wzr
    be4c:      	b.ne	0xbe70 <_stogir.vector-arithmetic.operands+0x28c>
    be50:      	uxtb	w16, w14
    be54:      	cmp	w16, wzr
    be58:      	b.ne	0xbe70 <_stogir.vector-arithmetic.operands+0x28c>
    be5c:      	uxtb	w16, w15
    be60:      	cmp	w16, wzr
    be64:      	b.ne	0xbe70 <_stogir.vector-arithmetic.operands+0x28c>
    be68:      	mov	x27, #0x2               ; =2
    be6c:      	b	0xbe74 <_stogir.vector-arithmetic.operands+0x290>
    be70:      	mov	x27, #0x1               ; =1
    be74:      	cmp	x26, x27
    be78:      	b.ge	0xbf3c <_stogir.vector-arithmetic.operands+0x358>
    be7c:      	cmp	x26, #0x0
    be80:      	b.ne	0xbe8c <_stogir.vector-arithmetic.operands+0x2a8>
    be84:      	mov	x27, x23
    be88:      	b	0xbe90 <_stogir.vector-arithmetic.operands+0x2ac>
    be8c:      	mov	x27, x24
    be90:      	sxtw	x27, w27
    be94:      	cmp	x27, #0x0
    be98:      	cset	w28, gt
    be9c:      	str	x2, [sp, #0x10]
    bea0:      	movz	x16, #0x0, lsl #48
    bea4:      	sub	x2, x16, x27
    bea8:      	str	x3, [sp, #0x18]
    beac:      	sub	x3, x2, #0x1
    beb0:      	uxtb	w16, w28
    beb4:      	cmp	w16, wzr
    beb8:      	b.eq	0xbef4 <_stogir.vector-arithmetic.operands+0x310>
    bebc:      	ldr	x2, [x20, #0x8]
    bec0:      	cmp	x27, x2
    bec4:      	b.ge	0xbd0c <_stogir.vector-arithmetic.operands+0x128>
    bec8:      	ldr	x2, [x4, #0x8]
    becc:      	cmp	x27, x2
    bed0:      	b.ge	0xbcfc <_stogir.vector-arithmetic.operands+0x118>
    bed4:      	ldr	x2, [x20, #0x78]
    bed8:      	add	x2, x2, x27, lsl #2
    bedc:      	ldr	w2, [x2]
    bee0:      	sxtw	x2, w2
    bee4:      	cmp	x2, #0x0
    bee8:      	cset	w2, ge
    beec:      	ubfx	x2, x2, #0, #8
    bef0:      	b	0xbd00 <_stogir.vector-arithmetic.operands+0x11c>
    bef4:      	cmp	x27, #0x0
    bef8:      	b.ge	0xc1dc <_stogir.vector-arithmetic.operands+0x5f8>
    befc:      	str	x4, [sp, #0x20]
    bf00:      	ldr	x4, [x5, #0x8]
    bf04:      	str	x5, [sp, #0x28]
    bf08:      	ldr	x5, [x6, #0x8]
    bf0c:      	cmp	x4, x5
    bf10:      	b.ne	0xbd04 <_stogir.vector-arithmetic.operands+0x120>
    bf14:      	cmp	x2, x4
    bf18:      	b.gt	0xbcf4 <_stogir.vector-arithmetic.operands+0x110>
    bf1c:      	ldr	x2, [x20, #0x50]
    bf20:      	add	x2, x2, x3, lsl #2
    bf24:      	ldr	w2, [x2]
    bf28:      	sxtw	x2, w2
    bf2c:      	cmp	x2, #0x0
    bf30:      	cset	w2, gt
    bf34:      	ubfx	x2, x2, #0, #8
    bf38:      	b	0xbcf8 <_stogir.vector-arithmetic.operands+0x114>
    bf3c:      	sxtw	x25, w25
    bf40:      	cmp	x25, #0x0
    bf44:      	b.ne	0xbf50 <_stogir.vector-arithmetic.operands+0x36c>
    bf48:      	movz	x2, #0x0, lsl #48
    bf4c:      	b	0xbf54 <_stogir.vector-arithmetic.operands+0x370>
    bf50:      	mov	x2, #0x1                ; =1
    bf54:      	cmp	x2, #0x0
    bf58:      	b.eq	0xbf88 <_stogir.vector-arithmetic.operands+0x3a4>
    bf5c:      	cmp	x21, #0x1d
    bf60:      	b.ne	0xc044 <_stogir.vector-arithmetic.operands+0x460>
    bf64:      	mov	x2, #0x1                ; =1
    bf68:      	b	0xc050 <_stogir.vector-arithmetic.operands+0x46c>
    bf6c:      	mov	x2, #0x1                ; =1
    bf70:      	cmp	x2, #0x0
    bf74:      	b.eq	0xbfe8 <_stogir.vector-arithmetic.operands+0x404>
    bf78:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x450>
		000000000000bf78:  ARM64_RELOC_PAGE21	l_stogir.494
    bf7c:      	ldr	x16, [x16]
		000000000000bf7c:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    bf80:      	orr	x0, x16, xzr
    bf84:      	mov	x1, #0x23               ; =35
    bf88:      	cmp	x1, #0x0
    bf8c:      	b.ne	0xbfa0 <_stogir.vector-arithmetic.operands+0x3bc>
    bf90:      	and	x0, x22, #0xffffffff
    bf94:      	movz	x2, #0x0, lsl #48
    bf98:      	movz	x1, #0x0, lsl #48
    bf9c:      	b	0xbfa4 <_stogir.vector-arithmetic.operands+0x3c0>
    bfa0:      	mov	x2, #0x1                ; =1
    bfa4:      	str	x2, [x19]
    bfa8:      	str	x0, [x19, #0x8]
    bfac:      	str	x1, [x19, #0x10]
    bfb0:      	ldr	x19, [sp, #0x30]
    bfb4:      	ldr	x20, [sp, #0x38]
    bfb8:      	ldr	x21, [sp, #0x40]
    bfbc:      	ldr	x22, [sp, #0x48]
    bfc0:      	ldr	x23, [sp, #0x50]
    bfc4:      	ldr	x24, [sp, #0x58]
    bfc8:      	ldr	x25, [sp, #0x60]
    bfcc:      	ldr	x26, [sp, #0x68]
    bfd0:      	ldr	x27, [sp, #0x70]
    bfd4:      	ldr	x28, [sp, #0x78]
    bfd8:      	ldr	x29, [sp]
    bfdc:      	ldr	x30, [sp, #0x8]
    bfe0:      	add	sp, sp, #0x80
    bfe4:      	ret
    bfe8:      	cmp	x25, #0x0
    bfec:      	cset	w2, gt
    bff0:      	movz	x16, #0x0, lsl #48
    bff4:      	sub	x3, x16, x25
    bff8:      	sub	x4, x3, #0x1
    bffc:      	uxtb	w16, w2
    c000:      	cmp	w16, wzr
    c004:      	b.eq	0xc0b0 <_stogir.vector-arithmetic.operands+0x4cc>
    c008:      	ldr	x3, [x20, #0x8]
    c00c:      	cmp	x25, x3
    c010:      	b.ge	0xc100 <_stogir.vector-arithmetic.operands+0x51c>
    c014:      	add	x3, x20, #0x78
    c018:      	ldr	x3, [x3, #0x8]
    c01c:      	cmp	x25, x3
    c020:      	b.ge	0xc1c4 <_stogir.vector-arithmetic.operands+0x5e0>
    c024:      	ldr	x3, [x20, #0x78]
    c028:      	add	x3, x3, x25, lsl #2
    c02c:      	ldr	w3, [x3]
    c030:      	sxtw	x3, w3
    c034:      	cmp	x3, #0x0
    c038:      	cset	w3, ge
    c03c:      	ubfx	x3, x3, #0, #8
    c040:      	b	0xc1c8 <_stogir.vector-arithmetic.operands+0x5e4>
    c044:      	cmp	x21, #0x1e
    c048:      	cset	w2, eq
    c04c:      	ubfx	x2, x2, #0, #8
    c050:      	cmp	x2, #0x0
    c054:      	b.eq	0xbf6c <_stogir.vector-arithmetic.operands+0x388>
    c058:      	movz	x2, #0x0, lsl #48
    c05c:      	b	0xbf70 <_stogir.vector-arithmetic.operands+0x38c>
    c060:      	movz	x3, #0x0, lsl #48
    c064:      	uxtb	w3, w3
    c068:      	and	x3, x3, #0x2
    c06c:      	uxtb	w3, w3
    c070:      	cmp	x3, #0x0
    c074:      	cset	w3, eq
    c078:      	uxtb	w16, w3
    c07c:      	cmp	w16, wzr
    c080:      	cset	x3, eq
    c084:      	cmp	x3, #0x0
    c088:      	b.ne	0xc0ac <_stogir.vector-arithmetic.operands+0x4c8>
    c08c:      	cmp	x2, #0x65
    c090:      	b.eq	0xc0ac <_stogir.vector-arithmetic.operands+0x4c8>
    c094:      	cmp	x2, #0x66
    c098:      	b.eq	0xc0ac <_stogir.vector-arithmetic.operands+0x4c8>
    c09c:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000c09c:  ARM64_RELOC_PAGE21	l_stogir.495
    c0a0:      	ldr	x16, [x16]
		000000000000c0a0:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    c0a4:      	orr	x0, x16, xzr
    c0a8:      	mov	x1, #0x34               ; =52
    c0ac:      	b	0xbf88 <_stogir.vector-arithmetic.operands+0x3a4>
    c0b0:      	cmp	x25, #0x0
    c0b4:      	b.ge	0xc108 <_stogir.vector-arithmetic.operands+0x524>
    c0b8:      	add	x5, x20, #0x28
    c0bc:      	add	x6, x20, #0x50
    c0c0:      	ldr	x5, [x5, #0x8]
    c0c4:      	ldr	x6, [x6, #0x8]
    c0c8:      	cmp	x5, x6
    c0cc:      	b.ne	0xc1bc <_stogir.vector-arithmetic.operands+0x5d8>
    c0d0:      	cmp	x3, x5
    c0d4:      	b.gt	0xc1cc <_stogir.vector-arithmetic.operands+0x5e8>
    c0d8:      	ldr	x3, [x20, #0x50]
    c0dc:      	add	x3, x3, x4, lsl #2
    c0e0:      	ldr	w3, [x3]
    c0e4:      	sxtw	x3, w3
    c0e8:      	cmp	x3, #0x0
    c0ec:      	cset	w3, gt
    c0f0:      	ubfx	x3, x3, #0, #8
    c0f4:      	b	0xc1d0 <_stogir.vector-arithmetic.operands+0x5ec>
    c0f8:      	brk	#0
    c0fc:      	b	0xc0f8 <_stogir.vector-arithmetic.operands+0x514>
    c100:      	movz	x3, #0x0, lsl #48
    c104:      	b	0xc10c <_stogir.vector-arithmetic.operands+0x528>
    c108:      	movz	x3, #0x0, lsl #48
    c10c:      	cmp	x3, #0x0
    c110:      	b.eq	0xc144 <_stogir.vector-arithmetic.operands+0x560>
    c114:      	uxtb	w16, w2
    c118:      	cmp	w16, wzr
    c11c:      	b.eq	0xc130 <_stogir.vector-arithmetic.operands+0x54c>
    c120:      	ldr	x2, [x20]
    c124:      	add	x2, x2, x25, lsl #4
    c128:      	ldr	x2, [x2]
    c12c:      	b	0xc13c <_stogir.vector-arithmetic.operands+0x558>
    c130:      	ldr	x2, [x20, #0x28]
    c134:      	add	x2, x2, x4, lsl #4
    c138:      	ldr	x2, [x2]
    c13c:      	mov	x3, #0x1                ; =1
    c140:      	b	0xc14c <_stogir.vector-arithmetic.operands+0x568>
    c144:      	movz	x3, #0x0, lsl #48
    c148:      	movz	x2, #0x0, lsl #48
    c14c:      	ubfx	x3, x3, #0, #32
    c150:      	lsr	x16, x3, #0
    c154:      	cmp	x16, #0x1
    c158:      	b.eq	0xc174 <_stogir.vector-arithmetic.operands+0x590>
    c15c:      	b.lo	0xc164 <_stogir.vector-arithmetic.operands+0x580>
    c160:      	b	0xc178 <_stogir.vector-arithmetic.operands+0x594>
    c164:      	cmp	x16, #0x0
    c168:      	b.eq	0xc170 <_stogir.vector-arithmetic.operands+0x58c>
    c16c:      	b	0xc178 <_stogir.vector-arithmetic.operands+0x594>
    c170:      	b	0xc17c <_stogir.vector-arithmetic.operands+0x598>
    c174:      	b	0xc190 <_stogir.vector-arithmetic.operands+0x5ac>
    c178:      	b	0xc1d4 <_stogir.vector-arithmetic.operands+0x5f0>
    c17c:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000c17c:  ARM64_RELOC_PAGE21	l_stogir.496
    c180:      	ldr	x16, [x16]
		000000000000c180:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    c184:      	orr	x0, x16, xzr
    c188:      	mov	x1, #0x1d               ; =29
    c18c:      	b	0xc0ac <_stogir.vector-arithmetic.operands+0x4c8>
    c190:      	cmp	x25, #0x0
    c194:      	b.le	0xc09c <_stogir.vector-arithmetic.operands+0x4b8>
    c198:      	uxtb	w2, w2
    c19c:      	cmp	x2, #0x83
    c1a0:      	b.ge	0xc060 <_stogir.vector-arithmetic.operands+0x47c>
    c1a4:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000c1a4:  ARM64_RELOC_PAGE21	l_stogir.497
    c1a8:      	ldr	x16, [x16]
		000000000000c1a8:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    c1ac:      	orr	x3, x16, xzr
    c1b0:      	add	x3, x2, x3
    c1b4:      	ldrb	w3, [x3]
    c1b8:      	b	0xc064 <_stogir.vector-arithmetic.operands+0x480>
    c1bc:      	movz	x3, #0x0, lsl #48
    c1c0:      	b	0xc10c <_stogir.vector-arithmetic.operands+0x528>
    c1c4:      	movz	x3, #0x0, lsl #48
    c1c8:      	b	0xc104 <_stogir.vector-arithmetic.operands+0x520>
    c1cc:      	movz	x3, #0x0, lsl #48
    c1d0:      	b	0xc1c0 <_stogir.vector-arithmetic.operands+0x5dc>
    c1d4:      	brk	#0
    c1d8:      	b	0xc1d4 <_stogir.vector-arithmetic.operands+0x5f0>
    c1dc:      	str	x4, [sp, #0x20]
    c1e0:      	str	x5, [sp, #0x28]
    c1e4:      	b	0xbd1c <_stogir.vector-arithmetic.operands+0x138>

000000000000c1e8 <_stogir.switch.key>:
    c1e8:      	sub	sp, sp, #0x30
    c1ec:      	str	x19, [sp]
    c1f0:      	str	x20, [sp, #0x8]
    c1f4:      	str	x21, [sp, #0x10]
    c1f8:      	str	x22, [sp, #0x18]
    c1fc:      	str	x23, [sp, #0x20]
    c200:      	sxtw	x2, w2
    c204:      	cmp	x2, #0x1
    c208:      	b.lt	0xc280 <_stogir.switch.key+0x98>
    c20c:      	cmp	x2, #0xb
    c210:      	cset	w3, le
    c214:      	uxtb	w16, w3
    c218:      	cmp	w16, wzr
    c21c:      	b.eq	0xc280 <_stogir.switch.key+0x98>
    c220:      	sxtw	x1, w1
    c224:      	cmp	x1, #0x0
    c228:      	cset	w4, gt
    c22c:      	movz	x16, #0x0, lsl #48
    c230:      	sub	x5, x16, x1
    c234:      	sub	x6, x5, #0x1
    c238:      	uxtb	w16, w4
    c23c:      	cmp	w16, wzr
    c240:      	b.eq	0xc300 <_stogir.switch.key+0x118>
    c244:      	ldr	x5, [x0, #0x8]
    c248:      	cmp	x1, x5
    c24c:      	b.ge	0xc348 <_stogir.switch.key+0x160>
    c250:      	add	x5, x0, #0x78
    c254:      	ldr	x5, [x5, #0x8]
    c258:      	cmp	x1, x5
    c25c:      	b.ge	0xc488 <_stogir.switch.key+0x2a0>
    c260:      	ldr	x5, [x0, #0x78]
    c264:      	add	x5, x5, x1, lsl #2
    c268:      	ldr	w5, [x5]
    c26c:      	sxtw	x5, w5
    c270:      	cmp	x5, #0x0
    c274:      	cset	w5, ge
    c278:      	ubfx	x5, x5, #0, #8
    c27c:      	b	0xc48c <_stogir.switch.key+0x2a4>
    c280:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000c280:  ARM64_RELOC_PAGE21	l_stogir.498
    c284:      	ldr	x16, [x16]
		000000000000c284:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    c288:      	orr	x0, x16, xzr
    c28c:      	mov	x1, #0x1                ; =1
    c290:      	mov	x2, #0x24               ; =36
    c294:      	str	x1, [x8]
    c298:      	str	x0, [x8, #0x8]
    c29c:      	str	x2, [x8, #0x10]
    c2a0:      	ldr	x19, [sp]
    c2a4:      	ldr	x20, [sp, #0x8]
    c2a8:      	ldr	x21, [sp, #0x10]
    c2ac:      	ldr	x22, [sp, #0x18]
    c2b0:      	ldr	x23, [sp, #0x20]
    c2b4:      	add	sp, sp, #0x30
    c2b8:      	ret
    c2bc:      	mov	x23, #0x1               ; =1
    c2c0:      	cmp	x1, #0x0
    c2c4:      	b.ge	0xc2e8 <_stogir.switch.key+0x100>
    c2c8:      	orr	w1, w4, wzr
    c2cc:      	uxtb	w4, w4
    c2d0:      	ubfx	x1, x1, #0, #32
    c2d4:      	ubfx	x1, x1, #8, #8
    c2d8:      	cmp	x4, x1
    c2dc:      	b.eq	0xc530 <_stogir.switch.key+0x348>
    c2e0:      	cmp	x4, #0x49
    c2e4:      	b.eq	0xc530 <_stogir.switch.key+0x348>
    c2e8:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000c2e8:  ARM64_RELOC_PAGE21	l_stogir.499
    c2ec:      	ldr	x16, [x16]
		000000000000c2ec:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    c2f0:      	orr	x0, x16, xzr
    c2f4:      	mov	x1, #0x1                ; =1
    c2f8:      	mov	x2, #0x30               ; =48
    c2fc:      	b	0xc294 <_stogir.switch.key+0xac>
    c300:      	cmp	x1, #0x0
    c304:      	b.ge	0xc350 <_stogir.switch.key+0x168>
    c308:      	add	x7, x0, #0x28
    c30c:      	add	x9, x0, #0x50
    c310:      	ldr	x7, [x7, #0x8]
    c314:      	ldr	x9, [x9, #0x8]
    c318:      	cmp	x7, x9
    c31c:      	b.ne	0xc480 <_stogir.switch.key+0x298>
    c320:      	cmp	x5, x7
    c324:      	b.gt	0xc528 <_stogir.switch.key+0x340>
    c328:      	ldr	x5, [x0, #0x50]
    c32c:      	add	x5, x5, x6, lsl #2
    c330:      	ldr	w5, [x5]
    c334:      	sxtw	x5, w5
    c338:      	cmp	x5, #0x0
    c33c:      	cset	w5, gt
    c340:      	ubfx	x5, x5, #0, #8
    c344:      	b	0xc52c <_stogir.switch.key+0x344>
    c348:      	movz	x5, #0x0, lsl #48
    c34c:      	b	0xc354 <_stogir.switch.key+0x16c>
    c350:      	movz	x5, #0x0, lsl #48
    c354:      	cmp	x5, #0x0
    c358:      	b.eq	0xc394 <_stogir.switch.key+0x1ac>
    c35c:      	uxtb	w16, w4
    c360:      	cmp	w16, wzr
    c364:      	b.eq	0xc37c <_stogir.switch.key+0x194>
    c368:      	ldr	x0, [x0]
    c36c:      	add	x0, x0, x1, lsl #4
    c370:      	ldr	x4, [x0]
    c374:      	ldr	x0, [x0, #0x8]
    c378:      	b	0xc38c <_stogir.switch.key+0x1a4>
    c37c:      	ldr	x0, [x0, #0x28]
    c380:      	add	x0, x0, x6, lsl #4
    c384:      	ldr	x4, [x0]
    c388:      	ldr	x0, [x0, #0x8]
    c38c:      	mov	x5, #0x1                ; =1
    c390:      	b	0xc3a0 <_stogir.switch.key+0x1b8>
    c394:      	movz	x5, #0x0, lsl #48
    c398:      	movz	x4, #0x0, lsl #48
    c39c:      	movz	x0, #0x0, lsl #48
    c3a0:      	ubfx	x5, x5, #0, #32
    c3a4:      	lsr	x16, x5, #0
    c3a8:      	cmp	x16, #0x1
    c3ac:      	b.eq	0xc3c8 <_stogir.switch.key+0x1e0>
    c3b0:      	b.lo	0xc3b8 <_stogir.switch.key+0x1d0>
    c3b4:      	b	0xc3cc <_stogir.switch.key+0x1e4>
    c3b8:      	cmp	x16, #0x0
    c3bc:      	b.eq	0xc3c4 <_stogir.switch.key+0x1dc>
    c3c0:      	b	0xc3cc <_stogir.switch.key+0x1e4>
    c3c4:      	b	0xc3d0 <_stogir.switch.key+0x1e8>
    c3c8:      	b	0xc3e8 <_stogir.switch.key+0x200>
    c3cc:      	b	0xc5c8 <_stogir.switch.key+0x3e0>
    c3d0:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000c3d0:  ARM64_RELOC_PAGE21	l_stogir.500
    c3d4:      	ldr	x16, [x16]
		000000000000c3d4:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c3d8:      	orr	x0, x16, xzr
    c3dc:      	mov	x1, #0x1                ; =1
    c3e0:      	mov	x2, #0x1c               ; =28
    c3e4:      	b	0xc2fc <_stogir.switch.key+0x114>
    c3e8:      	cmp	x2, #0x1
    c3ec:      	cset	w5, eq
    c3f0:      	cmp	x2, #0x0
    c3f4:      	cset	w6, eq
    c3f8:      	cmp	x2, #0x2
    c3fc:      	cset	w7, eq
    c400:      	cmp	x2, #0x7
    c404:      	cset	w9, eq
    c408:      	cmp	x2, #0x8
    c40c:      	cset	w10, eq
    c410:      	cmp	x2, #0x3
    c414:      	cset	w11, eq
    c418:      	cmp	x2, #0x9
    c41c:      	cset	w12, eq
    c420:      	cmp	x2, #0x4
    c424:      	cset	w13, eq
    c428:      	cmp	x2, #0xa
    c42c:      	cset	w14, eq
    c430:      	cmp	x2, #0xd
    c434:      	cset	w15, eq
    c438:      	cmp	x2, #0x5
    c43c:      	cset	w19, eq
    c440:      	cmp	x2, #0xb
    c444:      	cset	w20, eq
    c448:      	cmp	x2, #0xc
    c44c:      	cset	w21, eq
    c450:      	cmp	x2, #0x6
    c454:      	cset	w22, eq
    c458:      	uxtb	w16, w22
    c45c:      	cmp	w16, wzr
    c460:      	mov	x16, #0x8               ; =8
    c464:      	movn	x17, #0x0, lsl #48
    c468:      	csel	x22, x16, x17, ne
    c46c:      	uxtb	w16, w6
    c470:      	cmp	w16, wzr
    c474:      	b.eq	0xc490 <_stogir.switch.key+0x2a8>
    c478:      	movz	x23, #0x0, lsl #48
    c47c:      	b	0xc2c0 <_stogir.switch.key+0xd8>
    c480:      	movz	x5, #0x0, lsl #48
    c484:      	b	0xc354 <_stogir.switch.key+0x16c>
    c488:      	movz	x5, #0x0, lsl #48
    c48c:      	b	0xc34c <_stogir.switch.key+0x164>
    c490:      	uxtb	w16, w5
    c494:      	cmp	w16, wzr
    c498:      	b.ne	0xc2bc <_stogir.switch.key+0xd4>
    c49c:      	uxtb	w16, w7
    c4a0:      	cmp	w16, wzr
    c4a4:      	b.ne	0xc2bc <_stogir.switch.key+0xd4>
    c4a8:      	uxtb	w16, w9
    c4ac:      	cmp	w16, wzr
    c4b0:      	b.ne	0xc2bc <_stogir.switch.key+0xd4>
    c4b4:      	uxtb	w16, w10
    c4b8:      	cmp	w16, wzr
    c4bc:      	b.ne	0xc2bc <_stogir.switch.key+0xd4>
    c4c0:      	uxtb	w16, w11
    c4c4:      	cmp	w16, wzr
    c4c8:      	b.ne	0xc5c0 <_stogir.switch.key+0x3d8>
    c4cc:      	uxtb	w16, w12
    c4d0:      	cmp	w16, wzr
    c4d4:      	b.ne	0xc5c0 <_stogir.switch.key+0x3d8>
    c4d8:      	uxtb	w16, w13
    c4dc:      	cmp	w16, wzr
    c4e0:      	b.ne	0xc68c <_stogir.switch.key+0x4a4>
    c4e4:      	uxtb	w16, w14
    c4e8:      	cmp	w16, wzr
    c4ec:      	b.ne	0xc68c <_stogir.switch.key+0x4a4>
    c4f0:      	uxtb	w16, w15
    c4f4:      	cmp	w16, wzr
    c4f8:      	b.ne	0xc68c <_stogir.switch.key+0x4a4>
    c4fc:      	uxtb	w16, w19
    c500:      	cmp	w16, wzr
    c504:      	b.ne	0xc694 <_stogir.switch.key+0x4ac>
    c508:      	uxtb	w16, w20
    c50c:      	cmp	w16, wzr
    c510:      	b.ne	0xc694 <_stogir.switch.key+0x4ac>
    c514:      	uxtb	w16, w21
    c518:      	cmp	w16, wzr
    c51c:      	b.ne	0xc694 <_stogir.switch.key+0x4ac>
    c520:      	mov	x23, x22
    c524:      	b	0xc698 <_stogir.switch.key+0x4b0>
    c528:      	movz	x5, #0x0, lsl #48
    c52c:      	b	0xc484 <_stogir.switch.key+0x29c>
    c530:      	cmp	x1, x2
    c534:      	b.ne	0xc2e8 <_stogir.switch.key+0x100>
    c538:      	orr	w1, w0, wzr
    c53c:      	sxtw	x23, w23
    c540:      	ubfx	x1, x1, #0, #32
    c544:      	lsr	x0, x0, #32
    c548:      	lsl	x4, x23, #3
    c54c:      	ubfx	x0, x0, #0, #32
    c550:      	lsl	x0, x0, #32
    c554:      	sxtw	x4, w4
    c558:      	orr	x0, x0, x1
    c55c:      	cmp	x4, #0x40
    c560:      	b.ge	0xc570 <_stogir.switch.key+0x388>
    c564:      	lsr	x1, x0, x4
    c568:      	cmp	x1, #0x0
    c56c:      	b.ne	0xc2e8 <_stogir.switch.key+0x100>
    c570:      	uxtb	w16, w5
    c574:      	cmp	w16, wzr
    c578:      	b.eq	0xc584 <_stogir.switch.key+0x39c>
    c57c:      	cmp	x0, #0x1
    c580:      	b.hi	0xc2e8 <_stogir.switch.key+0x100>
    c584:      	cmp	x2, #0x7
    c588:      	b.lt	0xc5ac <_stogir.switch.key+0x3c4>
    c58c:      	uxtb	w16, w3
    c590:      	cmp	w16, wzr
    c594:      	b.eq	0xc5ac <_stogir.switch.key+0x3c4>
    c598:      	uxtb	w16, w6
    c59c:      	cmp	w16, wzr
    c5a0:      	b.eq	0xc5f4 <_stogir.switch.key+0x40c>
    c5a4:      	movz	x22, #0x0, lsl #48
    c5a8:      	b	0xc5d4 <_stogir.switch.key+0x3ec>
    c5ac:      	movz	x1, #0x0, lsl #48
    c5b0:      	eor	x0, x1, x0
    c5b4:      	movz	x1, #0x0, lsl #48
    c5b8:      	movz	x2, #0x0, lsl #48
    c5bc:      	b	0xc2fc <_stogir.switch.key+0x114>
    c5c0:      	mov	x23, #0x2               ; =2
    c5c4:      	b	0xc2c0 <_stogir.switch.key+0xd8>
    c5c8:      	brk	#0
    c5cc:      	b	0xc5c8 <_stogir.switch.key+0x3e0>
    c5d0:      	mov	x22, #0x1               ; =1
    c5d4:      	sxtw	x22, w22
    c5d8:      	lsl	x1, x22, #3
    c5dc:      	sxtw	x1, w1
    c5e0:      	sub	x1, x1, #0x1
    c5e4:      	sxtw	x1, w1
    c5e8:      	mov	x16, #0x1               ; =1
    c5ec:      	lsl	x1, x16, x1
    c5f0:      	b	0xc5b0 <_stogir.switch.key+0x3c8>
    c5f4:      	uxtb	w16, w5
    c5f8:      	cmp	w16, wzr
    c5fc:      	b.ne	0xc5d0 <_stogir.switch.key+0x3e8>
    c600:      	uxtb	w16, w7
    c604:      	cmp	w16, wzr
    c608:      	b.ne	0xc5d0 <_stogir.switch.key+0x3e8>
    c60c:      	uxtb	w16, w9
    c610:      	cmp	w16, wzr
    c614:      	b.ne	0xc5d0 <_stogir.switch.key+0x3e8>
    c618:      	uxtb	w16, w10
    c61c:      	cmp	w16, wzr
    c620:      	b.ne	0xc5d0 <_stogir.switch.key+0x3e8>
    c624:      	uxtb	w16, w11
    c628:      	cmp	w16, wzr
    c62c:      	b.ne	0xc69c <_stogir.switch.key+0x4b4>
    c630:      	uxtb	w16, w12
    c634:      	cmp	w16, wzr
    c638:      	b.ne	0xc69c <_stogir.switch.key+0x4b4>
    c63c:      	uxtb	w16, w13
    c640:      	cmp	w16, wzr
    c644:      	b.ne	0xc6a4 <_stogir.switch.key+0x4bc>
    c648:      	uxtb	w16, w14
    c64c:      	cmp	w16, wzr
    c650:      	b.ne	0xc6a4 <_stogir.switch.key+0x4bc>
    c654:      	uxtb	w16, w15
    c658:      	cmp	w16, wzr
    c65c:      	b.ne	0xc6a4 <_stogir.switch.key+0x4bc>
    c660:      	uxtb	w16, w19
    c664:      	cmp	w16, wzr
    c668:      	b.ne	0xc684 <_stogir.switch.key+0x49c>
    c66c:      	uxtb	w16, w20
    c670:      	cmp	w16, wzr
    c674:      	b.ne	0xc684 <_stogir.switch.key+0x49c>
    c678:      	uxtb	w16, w21
    c67c:      	cmp	w16, wzr
    c680:      	b.eq	0xc688 <_stogir.switch.key+0x4a0>
    c684:      	mov	x22, #0x8               ; =8
    c688:      	b	0xc6a8 <_stogir.switch.key+0x4c0>
    c68c:      	mov	x23, #0x4               ; =4
    c690:      	b	0xc5c4 <_stogir.switch.key+0x3dc>
    c694:      	mov	x23, #0x8               ; =8
    c698:      	b	0xc690 <_stogir.switch.key+0x4a8>
    c69c:      	mov	x22, #0x2               ; =2
    c6a0:      	b	0xc5d4 <_stogir.switch.key+0x3ec>
    c6a4:      	mov	x22, #0x4               ; =4
    c6a8:      	b	0xc6a0 <_stogir.switch.key+0x4b8>

000000000000c6ac <_stogir.stack.constant-size>:
    c6ac:      	sub	sp, sp, #0x10
    c6b0:      	str	x29, [sp]
    c6b4:      	str	x30, [sp, #0x8]
    c6b8:      	mov	x29, sp
    c6bc:      	mov	x2, sp
    c6c0:      	sxtw	x1, w1
    c6c4:      	sub	sp, sp, #0x10
    c6c8:      	mov	x3, sp
    c6cc:      	cmp	x1, #0x0
    c6d0:      	cset	w4, gt
    c6d4:      	movz	x16, #0x0, lsl #48
    c6d8:      	sub	x5, x16, x1
    c6dc:      	sub	x6, x5, #0x1
    c6e0:      	uxtb	w16, w4
    c6e4:      	cmp	w16, wzr
    c6e8:      	b.eq	0xc728 <_stogir.stack.constant-size+0x7c>
    c6ec:      	ldr	x5, [x0, #0x8]
    c6f0:      	cmp	x1, x5
    c6f4:      	b.ge	0xc778 <_stogir.stack.constant-size+0xcc>
    c6f8:      	add	x5, x0, #0x78
    c6fc:      	ldr	x5, [x5, #0x8]
    c700:      	cmp	x1, x5
    c704:      	b.ge	0xc8c0 <_stogir.stack.constant-size+0x214>
    c708:      	ldr	x5, [x0, #0x78]
    c70c:      	add	x5, x5, x1, lsl #2
    c710:      	ldr	w5, [x5]
    c714:      	sxtw	x5, w5
    c718:      	cmp	x5, #0x0
    c71c:      	cset	w5, ge
    c720:      	ubfx	x5, x5, #0, #8
    c724:      	b	0xc8c4 <_stogir.stack.constant-size+0x218>
    c728:      	cmp	x1, #0x0
    c72c:      	b.ge	0xc780 <_stogir.stack.constant-size+0xd4>
    c730:      	add	x7, x0, #0x28
    c734:      	add	x9, x0, #0x50
    c738:      	ldr	x7, [x7, #0x8]
    c73c:      	ldr	x9, [x9, #0x8]
    c740:      	cmp	x7, x9
    c744:      	b.ne	0xc770 <_stogir.stack.constant-size+0xc4>
    c748:      	cmp	x5, x7
    c74c:      	b.gt	0xc948 <_stogir.stack.constant-size+0x29c>
    c750:      	ldr	x5, [x0, #0x50]
    c754:      	add	x5, x5, x6, lsl #2
    c758:      	ldr	w5, [x5]
    c75c:      	sxtw	x5, w5
    c760:      	cmp	x5, #0x0
    c764:      	cset	w5, gt
    c768:      	ubfx	x5, x5, #0, #8
    c76c:      	b	0xc94c <_stogir.stack.constant-size+0x2a0>
    c770:      	movz	x5, #0x0, lsl #48
    c774:      	b	0xc784 <_stogir.stack.constant-size+0xd8>
    c778:      	movz	x5, #0x0, lsl #48
    c77c:      	b	0xc784 <_stogir.stack.constant-size+0xd8>
    c780:      	movz	x5, #0x0, lsl #48
    c784:      	cmp	x5, #0x0
    c788:      	b.eq	0xc7c4 <_stogir.stack.constant-size+0x118>
    c78c:      	uxtb	w16, w4
    c790:      	cmp	w16, wzr
    c794:      	b.eq	0xc7ac <_stogir.stack.constant-size+0x100>
    c798:      	ldr	x0, [x0]
    c79c:      	add	x0, x0, x1, lsl #4
    c7a0:      	ldr	x4, [x0]
    c7a4:      	ldr	x0, [x0, #0x8]
    c7a8:      	b	0xc7bc <_stogir.stack.constant-size+0x110>
    c7ac:      	ldr	x0, [x0, #0x28]
    c7b0:      	add	x0, x0, x6, lsl #4
    c7b4:      	ldr	x4, [x0]
    c7b8:      	ldr	x0, [x0, #0x8]
    c7bc:      	mov	x5, #0x1                ; =1
    c7c0:      	b	0xc7d0 <_stogir.stack.constant-size+0x124>
    c7c4:      	movz	x5, #0x0, lsl #48
    c7c8:      	movz	x4, #0x0, lsl #48
    c7cc:      	movz	x0, #0x0, lsl #48
    c7d0:      	ubfx	x5, x5, #0, #32
    c7d4:      	lsr	x16, x5, #0
    c7d8:      	cmp	x16, #0x1
    c7dc:      	b.eq	0xc7f8 <_stogir.stack.constant-size+0x14c>
    c7e0:      	b.lo	0xc7e8 <_stogir.stack.constant-size+0x13c>
    c7e4:      	b	0xc7fc <_stogir.stack.constant-size+0x150>
    c7e8:      	cmp	x16, #0x0
    c7ec:      	b.eq	0xc7f4 <_stogir.stack.constant-size+0x148>
    c7f0:      	b	0xc7fc <_stogir.stack.constant-size+0x150>
    c7f4:      	b	0xc800 <_stogir.stack.constant-size+0x154>
    c7f8:      	b	0xc89c <_stogir.stack.constant-size+0x1f0>
    c7fc:      	b	0xc9ec <_stogir.stack.constant-size+0x340>
    c800:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000c800:  ARM64_RELOC_PAGE21	l_stogir.501
    c804:      	ldr	x16, [x16]
		000000000000c804:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    c808:      	orr	x0, x16, xzr
    c80c:      	mov	x1, #0x1                ; =1
    c810:      	mov	x3, #0x18               ; =24
    c814:      	b	0xc878 <_stogir.stack.constant-size+0x1cc>
    c818:      	mov	x4, #0x1                ; =1
    c81c:      	ldr	w5, [x3, #0x8]
    c820:      	ldr	w6, [x3, #0xc]
    c824:      	cmp	x1, #0x0
    c828:      	b.ge	0xc864 <_stogir.stack.constant-size+0x1b8>
    c82c:      	cmp	x0, #0x1
    c830:      	b.lt	0xc864 <_stogir.stack.constant-size+0x1b8>
    c834:      	cmp	x0, #0xb
    c838:      	cset	w1, le
    c83c:      	uxtb	w16, w1
    c840:      	cmp	w16, wzr
    c844:      	b.eq	0xc864 <_stogir.stack.constant-size+0x1b8>
    c848:      	ldr	w3, [x3]
    c84c:      	uxtb	w7, w3
    c850:      	ubfx	x3, x3, #8, #8
    c854:      	cmp	x7, x3
    c858:      	b.eq	0xc950 <_stogir.stack.constant-size+0x2a4>
    c85c:      	cmp	x7, #0x49
    c860:      	b.eq	0xc950 <_stogir.stack.constant-size+0x2a4>
    c864:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000c864:  ARM64_RELOC_PAGE21	l_stogir.502
    c868:      	ldr	x16, [x16]
		000000000000c868:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    c86c:      	orr	x0, x16, xzr
    c870:      	mov	x1, #0x1                ; =1
    c874:      	mov	x3, #0x30               ; =48
    c878:      	mov	sp, x2
    c87c:      	str	x1, [x8]
    c880:      	str	x0, [x8, #0x8]
    c884:      	str	x3, [x8, #0x10]
    c888:      	sub	sp, x29, #0x0
    c88c:      	ldr	x29, [sp]
    c890:      	ldr	x30, [sp, #0x8]
    c894:      	add	sp, sp, #0x10
    c898:      	ret
    c89c:      	orr	w5, w4, wzr
    c8a0:      	str	x4, [x3]
    c8a4:      	ubfx	x5, x5, #0, #32
    c8a8:      	str	x0, [x3, #0x8]
    c8ac:      	ubfx	x0, x5, #8, #8
    c8b0:      	cmp	x0, #0x0
    c8b4:      	b.ne	0xc8c8 <_stogir.stack.constant-size+0x21c>
    c8b8:      	movz	x4, #0x0, lsl #48
    c8bc:      	b	0xc81c <_stogir.stack.constant-size+0x170>
    c8c0:      	movz	x5, #0x0, lsl #48
    c8c4:      	b	0xc77c <_stogir.stack.constant-size+0xd0>
    c8c8:      	cmp	x0, #0x1
    c8cc:      	b.eq	0xc818 <_stogir.stack.constant-size+0x16c>
    c8d0:      	cmp	x0, #0x2
    c8d4:      	b.eq	0xc818 <_stogir.stack.constant-size+0x16c>
    c8d8:      	cmp	x0, #0x7
    c8dc:      	b.eq	0xc818 <_stogir.stack.constant-size+0x16c>
    c8e0:      	cmp	x0, #0x8
    c8e4:      	b.eq	0xc818 <_stogir.stack.constant-size+0x16c>
    c8e8:      	cmp	x0, #0x3
    c8ec:      	b.eq	0xc9e4 <_stogir.stack.constant-size+0x338>
    c8f0:      	cmp	x0, #0x9
    c8f4:      	b.eq	0xc9e4 <_stogir.stack.constant-size+0x338>
    c8f8:      	cmp	x0, #0x4
    c8fc:      	b.eq	0xc9f4 <_stogir.stack.constant-size+0x348>
    c900:      	cmp	x0, #0xa
    c904:      	b.eq	0xc9f4 <_stogir.stack.constant-size+0x348>
    c908:      	cmp	x0, #0xd
    c90c:      	b.eq	0xc9f4 <_stogir.stack.constant-size+0x348>
    c910:      	cmp	x0, #0x5
    c914:      	b.eq	0xc9fc <_stogir.stack.constant-size+0x350>
    c918:      	cmp	x0, #0xb
    c91c:      	b.eq	0xc9fc <_stogir.stack.constant-size+0x350>
    c920:      	cmp	x0, #0xc
    c924:      	b.eq	0xc9fc <_stogir.stack.constant-size+0x350>
    c928:      	cmp	x0, #0x6
    c92c:      	cset	w4, eq
    c930:      	uxtb	w16, w4
    c934:      	cmp	w16, wzr
    c938:      	mov	x16, #0x8               ; =8
    c93c:      	movn	x17, #0x0, lsl #48
    c940:      	csel	x4, x16, x17, ne
    c944:      	b	0xca00 <_stogir.stack.constant-size+0x354>
    c948:      	movz	x5, #0x0, lsl #48
    c94c:      	b	0xc774 <_stogir.stack.constant-size+0xc8>
    c950:      	sxtw	x4, w4
    c954:      	cmp	x4, #0x0
    c958:      	b.le	0xc864 <_stogir.stack.constant-size+0x1b8>
    c95c:      	ubfx	x5, x5, #0, #32
    c960:      	ubfx	x6, x6, #0, #32
    c964:      	lsl	x3, x6, #32
    c968:      	orr	x3, x3, x5
    c96c:      	cmp	x4, #0x8
    c970:      	b.ge	0xc988 <_stogir.stack.constant-size+0x2dc>
    c974:      	lsl	x5, x4, #3
    c978:      	sxtw	x5, w5
    c97c:      	lsr	x5, x3, x5
    c980:      	cmp	x5, #0x0
    c984:      	b.ne	0xc864 <_stogir.stack.constant-size+0x1b8>
    c988:      	cmp	x0, #0x7
    c98c:      	b.lt	0xc9c0 <_stogir.stack.constant-size+0x314>
    c990:      	uxtb	w16, w1
    c994:      	cmp	w16, wzr
    c998:      	b.eq	0xc9c0 <_stogir.stack.constant-size+0x314>
    c99c:      	lsl	x0, x4, #3
    c9a0:      	sxtw	x0, w0
    c9a4:      	sub	x0, x0, #0x1
    c9a8:      	sxtw	x0, w0
    c9ac:      	mov	x16, #0x1               ; =1
    c9b0:      	lsl	x0, x16, x0
    c9b4:      	and	x0, x0, x3
    c9b8:      	cmp	x0, #0x0
    c9bc:      	b.ne	0xc864 <_stogir.stack.constant-size+0x1b8>
    c9c0:      	mov	x17, #-0x10             ; =-16
    c9c4:      	movk	x17, #0x7fff, lsl #48
    c9c8:      	cmp	x3, x17
    c9cc:      	b.hi	0xc864 <_stogir.stack.constant-size+0x1b8>
    c9d0:      	add	x0, x3, #0xf
    c9d4:      	and	x0, x0, #0xfffffffffffffff0
    c9d8:      	movz	x1, #0x0, lsl #48
    c9dc:      	movz	x3, #0x0, lsl #48
    c9e0:      	b	0xc878 <_stogir.stack.constant-size+0x1cc>
    c9e4:      	mov	x4, #0x2                ; =2
    c9e8:      	b	0xc81c <_stogir.stack.constant-size+0x170>
    c9ec:      	brk	#0
    c9f0:      	b	0xc9ec <_stogir.stack.constant-size+0x340>
    c9f4:      	mov	x4, #0x4                ; =4
    c9f8:      	b	0xc9e8 <_stogir.stack.constant-size+0x33c>
    c9fc:      	mov	x4, #0x8                ; =8
    ca00:      	b	0xc9f8 <_stogir.stack.constant-size+0x34c>

000000000000ca04 <_stogir.stack.constant-size-aligned>:
    ca04:      	sub	sp, sp, #0x10
    ca08:      	cmp	x2, #0x10
    ca0c:      	b.lt	0xca88 <_stogir.stack.constant-size-aligned+0x84>
    ca10:      	cmp	x2, #0x0
    ca14:      	b.le	0xca88 <_stogir.stack.constant-size-aligned+0x84>
    ca18:      	sub	x3, x2, #0x1
    ca1c:      	and	x3, x3, x2
    ca20:      	cmp	x3, #0x0
    ca24:      	b.ne	0xca88 <_stogir.stack.constant-size-aligned+0x84>
    ca28:      	sxtw	x1, w1
    ca2c:      	cmp	x1, #0x0
    ca30:      	cset	w3, gt
    ca34:      	movz	x16, #0x0, lsl #48
    ca38:      	sub	x4, x16, x1
    ca3c:      	sub	x5, x4, #0x1
    ca40:      	uxtb	w16, w3
    ca44:      	cmp	w16, wzr
    ca48:      	b.eq	0xcb20 <_stogir.stack.constant-size-aligned+0x11c>
    ca4c:      	ldr	x4, [x0, #0x8]
    ca50:      	cmp	x1, x4
    ca54:      	b.ge	0xcb68 <_stogir.stack.constant-size-aligned+0x164>
    ca58:      	add	x4, x0, #0x78
    ca5c:      	ldr	x4, [x4, #0x8]
    ca60:      	cmp	x1, x4
    ca64:      	b.ge	0xcc3c <_stogir.stack.constant-size-aligned+0x238>
    ca68:      	ldr	x4, [x0, #0x78]
    ca6c:      	add	x4, x4, x1, lsl #2
    ca70:      	ldr	w4, [x4]
    ca74:      	sxtw	x4, w4
    ca78:      	cmp	x4, #0x0
    ca7c:      	cset	w4, ge
    ca80:      	ubfx	x4, x4, #0, #8
    ca84:      	b	0xcc40 <_stogir.stack.constant-size-aligned+0x23c>
    ca88:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000ca88:  ARM64_RELOC_PAGE21	l_stogir.503
    ca8c:      	ldr	x16, [x16]
		000000000000ca8c:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    ca90:      	orr	x0, x16, xzr
    ca94:      	mov	x1, #0x1                ; =1
    ca98:      	mov	x2, #0x20               ; =32
    ca9c:      	str	x1, [x8]
    caa0:      	str	x0, [x8, #0x8]
    caa4:      	str	x2, [x8, #0x10]
    caa8:      	add	sp, sp, #0x10
    caac:      	ret
    cab0:      	mov	x3, #0x1                ; =1
    cab4:      	mov	x16, sp
    cab8:      	ldr	w4, [x16, #0x8]
    cabc:      	mov	x16, sp
    cac0:      	ldr	w5, [x16, #0xc]
    cac4:      	cmp	x1, #0x0
    cac8:      	b.ge	0xcb08 <_stogir.stack.constant-size-aligned+0x104>
    cacc:      	cmp	x0, #0x1
    cad0:      	b.lt	0xcb08 <_stogir.stack.constant-size-aligned+0x104>
    cad4:      	cmp	x0, #0xb
    cad8:      	cset	w1, le
    cadc:      	uxtb	w16, w1
    cae0:      	cmp	w16, wzr
    cae4:      	b.eq	0xcb08 <_stogir.stack.constant-size-aligned+0x104>
    cae8:      	mov	x16, sp
    caec:      	ldr	w6, [x16]
    caf0:      	uxtb	w7, w6
    caf4:      	ubfx	x6, x6, #8, #8
    caf8:      	cmp	x7, x6
    cafc:      	b.eq	0xcccc <_stogir.stack.constant-size-aligned+0x2c8>
    cb00:      	cmp	x7, #0x49
    cb04:      	b.eq	0xcccc <_stogir.stack.constant-size-aligned+0x2c8>
    cb08:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000cb08:  ARM64_RELOC_PAGE21	l_stogir.504
    cb0c:      	ldr	x16, [x16]
		000000000000cb0c:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    cb10:      	orr	x0, x16, xzr
    cb14:      	mov	x1, #0x1                ; =1
    cb18:      	mov	x2, #0x30               ; =48
    cb1c:      	b	0xca9c <_stogir.stack.constant-size-aligned+0x98>
    cb20:      	cmp	x1, #0x0
    cb24:      	b.ge	0xcb70 <_stogir.stack.constant-size-aligned+0x16c>
    cb28:      	add	x6, x0, #0x28
    cb2c:      	add	x7, x0, #0x50
    cb30:      	ldr	x6, [x6, #0x8]
    cb34:      	ldr	x7, [x7, #0x8]
    cb38:      	cmp	x6, x7
    cb3c:      	b.ne	0xcc34 <_stogir.stack.constant-size-aligned+0x230>
    cb40:      	cmp	x4, x6
    cb44:      	b.gt	0xccc4 <_stogir.stack.constant-size-aligned+0x2c0>
    cb48:      	ldr	x4, [x0, #0x50]
    cb4c:      	add	x4, x4, x5, lsl #2
    cb50:      	ldr	w4, [x4]
    cb54:      	sxtw	x4, w4
    cb58:      	cmp	x4, #0x0
    cb5c:      	cset	w4, gt
    cb60:      	ubfx	x4, x4, #0, #8
    cb64:      	b	0xccc8 <_stogir.stack.constant-size-aligned+0x2c4>
    cb68:      	movz	x4, #0x0, lsl #48
    cb6c:      	b	0xcb74 <_stogir.stack.constant-size-aligned+0x170>
    cb70:      	movz	x4, #0x0, lsl #48
    cb74:      	cmp	x4, #0x0
    cb78:      	b.eq	0xcbb4 <_stogir.stack.constant-size-aligned+0x1b0>
    cb7c:      	uxtb	w16, w3
    cb80:      	cmp	w16, wzr
    cb84:      	b.eq	0xcb9c <_stogir.stack.constant-size-aligned+0x198>
    cb88:      	ldr	x0, [x0]
    cb8c:      	add	x0, x0, x1, lsl #4
    cb90:      	ldr	x3, [x0]
    cb94:      	ldr	x0, [x0, #0x8]
    cb98:      	b	0xcbac <_stogir.stack.constant-size-aligned+0x1a8>
    cb9c:      	ldr	x0, [x0, #0x28]
    cba0:      	add	x0, x0, x5, lsl #4
    cba4:      	ldr	x3, [x0]
    cba8:      	ldr	x0, [x0, #0x8]
    cbac:      	mov	x4, #0x1                ; =1
    cbb0:      	b	0xcbc0 <_stogir.stack.constant-size-aligned+0x1bc>
    cbb4:      	movz	x4, #0x0, lsl #48
    cbb8:      	movz	x3, #0x0, lsl #48
    cbbc:      	movz	x0, #0x0, lsl #48
    cbc0:      	ubfx	x4, x4, #0, #32
    cbc4:      	lsr	x16, x4, #0
    cbc8:      	cmp	x16, #0x1
    cbcc:      	b.eq	0xcbe8 <_stogir.stack.constant-size-aligned+0x1e4>
    cbd0:      	b.lo	0xcbd8 <_stogir.stack.constant-size-aligned+0x1d4>
    cbd4:      	b	0xcbec <_stogir.stack.constant-size-aligned+0x1e8>
    cbd8:      	cmp	x16, #0x0
    cbdc:      	b.eq	0xcbe4 <_stogir.stack.constant-size-aligned+0x1e0>
    cbe0:      	b	0xcbec <_stogir.stack.constant-size-aligned+0x1e8>
    cbe4:      	b	0xcbf0 <_stogir.stack.constant-size-aligned+0x1ec>
    cbe8:      	b	0xcc08 <_stogir.stack.constant-size-aligned+0x204>
    cbec:      	b	0xcd78 <_stogir.stack.constant-size-aligned+0x374>
    cbf0:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x41c>
		000000000000cbf0:  ARM64_RELOC_PAGE21	l_stogir.505
    cbf4:      	ldr	x16, [x16]
		000000000000cbf4:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    cbf8:      	orr	x0, x16, xzr
    cbfc:      	mov	x1, #0x1                ; =1
    cc00:      	mov	x2, #0x18               ; =24
    cc04:      	b	0xcb1c <_stogir.stack.constant-size-aligned+0x118>
    cc08:      	orr	w4, w3, wzr
    cc0c:      	mov	x16, sp
    cc10:      	str	x3, [x16]
    cc14:      	ubfx	x4, x4, #0, #32
    cc18:      	mov	x16, sp
    cc1c:      	str	x0, [x16, #0x8]
    cc20:      	ubfx	x0, x4, #8, #8
    cc24:      	cmp	x0, #0x0
    cc28:      	b.ne	0xcc44 <_stogir.stack.constant-size-aligned+0x240>
    cc2c:      	movz	x3, #0x0, lsl #48
    cc30:      	b	0xcab4 <_stogir.stack.constant-size-aligned+0xb0>
    cc34:      	movz	x4, #0x0, lsl #48
    cc38:      	b	0xcb74 <_stogir.stack.constant-size-aligned+0x170>
    cc3c:      	movz	x4, #0x0, lsl #48
    cc40:      	b	0xcb6c <_stogir.stack.constant-size-aligned+0x168>
    cc44:      	cmp	x0, #0x1
    cc48:      	b.eq	0xcab0 <_stogir.stack.constant-size-aligned+0xac>
    cc4c:      	cmp	x0, #0x2
    cc50:      	b.eq	0xcab0 <_stogir.stack.constant-size-aligned+0xac>
    cc54:      	cmp	x0, #0x7
    cc58:      	b.eq	0xcab0 <_stogir.stack.constant-size-aligned+0xac>
    cc5c:      	cmp	x0, #0x8
    cc60:      	b.eq	0xcab0 <_stogir.stack.constant-size-aligned+0xac>
    cc64:      	cmp	x0, #0x3
    cc68:      	b.eq	0xcd70 <_stogir.stack.constant-size-aligned+0x36c>
    cc6c:      	cmp	x0, #0x9
    cc70:      	b.eq	0xcd70 <_stogir.stack.constant-size-aligned+0x36c>
    cc74:      	cmp	x0, #0x4
    cc78:      	b.eq	0xcd80 <_stogir.stack.constant-size-aligned+0x37c>
    cc7c:      	cmp	x0, #0xa
    cc80:      	b.eq	0xcd80 <_stogir.stack.constant-size-aligned+0x37c>
    cc84:      	cmp	x0, #0xd
    cc88:      	b.eq	0xcd80 <_stogir.stack.constant-size-aligned+0x37c>
    cc8c:      	cmp	x0, #0x5
    cc90:      	b.eq	0xcd88 <_stogir.stack.constant-size-aligned+0x384>
    cc94:      	cmp	x0, #0xb
    cc98:      	b.eq	0xcd88 <_stogir.stack.constant-size-aligned+0x384>
    cc9c:      	cmp	x0, #0xc
    cca0:      	b.eq	0xcd88 <_stogir.stack.constant-size-aligned+0x384>
    cca4:      	cmp	x0, #0x6
    cca8:      	cset	w3, eq
    ccac:      	uxtb	w16, w3
    ccb0:      	cmp	w16, wzr
    ccb4:      	mov	x16, #0x8               ; =8
    ccb8:      	movn	x17, #0x0, lsl #48
    ccbc:      	csel	x3, x16, x17, ne
    ccc0:      	b	0xcd8c <_stogir.stack.constant-size-aligned+0x388>
    ccc4:      	movz	x4, #0x0, lsl #48
    ccc8:      	b	0xcc38 <_stogir.stack.constant-size-aligned+0x234>
    cccc:      	sxtw	x3, w3
    ccd0:      	cmp	x3, #0x0
    ccd4:      	b.le	0xcb08 <_stogir.stack.constant-size-aligned+0x104>
    ccd8:      	ubfx	x4, x4, #0, #32
    ccdc:      	ubfx	x5, x5, #0, #32
    cce0:      	lsl	x5, x5, #32
    cce4:      	orr	x4, x5, x4
    cce8:      	cmp	x3, #0x8
    ccec:      	b.ge	0xcd04 <_stogir.stack.constant-size-aligned+0x300>
    ccf0:      	lsl	x5, x3, #3
    ccf4:      	sxtw	x5, w5
    ccf8:      	lsr	x5, x4, x5
    ccfc:      	cmp	x5, #0x0
    cd00:      	b.ne	0xcb08 <_stogir.stack.constant-size-aligned+0x104>
    cd04:      	cmp	x0, #0x7
    cd08:      	b.lt	0xcd3c <_stogir.stack.constant-size-aligned+0x338>
    cd0c:      	uxtb	w16, w1
    cd10:      	cmp	w16, wzr
    cd14:      	b.eq	0xcd3c <_stogir.stack.constant-size-aligned+0x338>
    cd18:      	lsl	x0, x3, #3
    cd1c:      	sxtw	x0, w0
    cd20:      	sub	x0, x0, #0x1
    cd24:      	sxtw	x0, w0
    cd28:      	mov	x16, #0x1               ; =1
    cd2c:      	lsl	x0, x16, x0
    cd30:      	and	x0, x0, x4
    cd34:      	cmp	x0, #0x0
    cd38:      	b.ne	0xcb08 <_stogir.stack.constant-size-aligned+0x104>
    cd3c:      	sub	x0, x2, #0x1
    cd40:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    cd44:      	sub	x0, x16, x0
    cd48:      	cmp	x4, x0
    cd4c:      	b.hi	0xcb08 <_stogir.stack.constant-size-aligned+0x104>
    cd50:      	sub	x0, x2, #0x1
    cd54:      	movz	x16, #0x0, lsl #48
    cd58:      	sub	x1, x16, x2
    cd5c:      	add	x0, x0, x4
    cd60:      	and	x0, x1, x0
    cd64:      	movz	x1, #0x0, lsl #48
    cd68:      	movz	x2, #0x0, lsl #48
    cd6c:      	b	0xcb1c <_stogir.stack.constant-size-aligned+0x118>
    cd70:      	mov	x3, #0x2                ; =2
    cd74:      	b	0xcab4 <_stogir.stack.constant-size-aligned+0xb0>
    cd78:      	brk	#0
    cd7c:      	b	0xcd78 <_stogir.stack.constant-size-aligned+0x374>
    cd80:      	mov	x3, #0x4                ; =4
    cd84:      	b	0xcd74 <_stogir.stack.constant-size-aligned+0x370>
    cd88:      	mov	x3, #0x8                ; =8
    cd8c:      	b	0xcd84 <_stogir.stack.constant-size-aligned+0x380>

000000000000cd90 <_stogir.vector-lanes.compatible?>:
    cd90:      	sxtw	x0, w0
    cd94:      	and	x3, x0, #0xf
    cd98:      	cmp	x0, #0xf
    cd9c:      	cset	w4, gt
    cda0:      	cmp	x0, #0x80
    cda4:      	cset	w5, lt
    cda8:      	sxtw	x3, w3
    cdac:      	cmp	x3, #0x1
    cdb0:      	cset	w6, ge
    cdb4:      	cmp	x3, #0xd
    cdb8:      	cset	w7, le
    cdbc:      	cmp	x0, #0x0
    cdc0:      	b.lt	0xcdcc <_stogir.vector-lanes.compatible?+0x3c>
    cdc4:      	cmp	x0, #0xd
    cdc8:      	b.le	0xce00 <_stogir.vector-lanes.compatible?+0x70>
    cdcc:      	uxtb	w16, w4
    cdd0:      	cmp	w16, wzr
    cdd4:      	b.eq	0xcdfc <_stogir.vector-lanes.compatible?+0x6c>
    cdd8:      	uxtb	w16, w5
    cddc:      	cmp	w16, wzr
    cde0:      	b.eq	0xcdfc <_stogir.vector-lanes.compatible?+0x6c>
    cde4:      	uxtb	w16, w6
    cde8:      	cmp	w16, wzr
    cdec:      	b.eq	0xcdfc <_stogir.vector-lanes.compatible?+0x6c>
    cdf0:      	uxtb	w16, w7
    cdf4:      	cmp	w16, wzr
    cdf8:      	b.ne	0xce00 <_stogir.vector-lanes.compatible?+0x70>
    cdfc:      	movn	x3, #0x0, lsl #48
    ce00:      	uxtb	w16, w4
    ce04:      	cmp	w16, wzr
    ce08:      	b.eq	0xce64 <_stogir.vector-lanes.compatible?+0xd4>
    ce0c:      	uxtb	w16, w5
    ce10:      	cmp	w16, wzr
    ce14:      	b.eq	0xce64 <_stogir.vector-lanes.compatible?+0xd4>
    ce18:      	uxtb	w16, w6
    ce1c:      	cmp	w16, wzr
    ce20:      	b.eq	0xce64 <_stogir.vector-lanes.compatible?+0xd4>
    ce24:      	uxtb	w16, w7
    ce28:      	cmp	w16, wzr
    ce2c:      	b.eq	0xce64 <_stogir.vector-lanes.compatible?+0xd4>
    ce30:      	sxtw	x2, w2
    ce34:      	cmp	x2, #0x4
    ce38:      	cset	w0, eq
    ce3c:      	cmp	x2, #0x8
    ce40:      	cset	w4, eq
    ce44:      	uxtb	w16, w0
    ce48:      	cmp	w16, wzr
    ce4c:      	b.ne	0xce74 <_stogir.vector-lanes.compatible?+0xe4>
    ce50:      	uxtb	w16, w4
    ce54:      	cmp	w16, wzr
    ce58:      	b.ne	0xce74 <_stogir.vector-lanes.compatible?+0xe4>
    ce5c:      	movz	x0, #0x0, lsl #48
    ce60:      	b	0xce70 <_stogir.vector-lanes.compatible?+0xe0>
    ce64:      	movz	x0, #0x0, lsl #48
    ce68:      	ret
    ce6c:      	movz	x0, #0x0, lsl #48
    ce70:      	b	0xce68 <_stogir.vector-lanes.compatible?+0xd8>
    ce74:      	sxtw	x1, w1
    ce78:      	cmp	x1, #0x0
    ce7c:      	b.lt	0xce6c <_stogir.vector-lanes.compatible?+0xdc>
    ce80:      	cmp	x1, #0xd
    ce84:      	b.gt	0xce6c <_stogir.vector-lanes.compatible?+0xdc>
    ce88:      	cmp	x1, #0x0
    ce8c:      	b.le	0xcea4 <_stogir.vector-lanes.compatible?+0x114>
    ce90:      	sxtw	x3, w3
    ce94:      	cmp	x3, x1
    ce98:      	b.ne	0xceac <_stogir.vector-lanes.compatible?+0x11c>
    ce9c:      	mov	x0, #0x1                ; =1
    cea0:      	b	0xcea8 <_stogir.vector-lanes.compatible?+0x118>
    cea4:      	movz	x0, #0x0, lsl #48
    cea8:      	b	0xce70 <_stogir.vector-lanes.compatible?+0xe0>
    ceac:      	cmp	x3, #0x1
    ceb0:      	b.lt	0xceec <_stogir.vector-lanes.compatible?+0x15c>
    ceb4:      	cmp	x3, #0xb
    ceb8:      	b.gt	0xceec <_stogir.vector-lanes.compatible?+0x15c>
    cebc:      	cmp	x1, #0x1
    cec0:      	b.lt	0xcef4 <_stogir.vector-lanes.compatible?+0x164>
    cec4:      	cmp	x1, #0xb
    cec8:      	b.gt	0xcef4 <_stogir.vector-lanes.compatible?+0x164>
    cecc:      	uxtb	w16, w0
    ced0:      	cmp	w16, wzr
    ced4:      	b.ne	0xcf18 <_stogir.vector-lanes.compatible?+0x188>
    ced8:      	uxtb	w16, w4
    cedc:      	cmp	w16, wzr
    cee0:      	b.ne	0xcf18 <_stogir.vector-lanes.compatible?+0x188>
    cee4:      	movn	x3, #0x0, lsl #48
    cee8:      	b	0xcf2c <_stogir.vector-lanes.compatible?+0x19c>
    ceec:      	movz	x0, #0x0, lsl #48
    cef0:      	b	0xcea0 <_stogir.vector-lanes.compatible?+0x110>
    cef4:      	movz	x0, #0x0, lsl #48
    cef8:      	b	0xcef0 <_stogir.vector-lanes.compatible?+0x160>
    cefc:      	mov	x2, #0x1                ; =1
    cf00:      	sxtw	x3, w3
    cf04:      	sxtw	x2, w2
    cf08:      	cmp	x3, x2
    cf0c:      	cset	w0, eq
    cf10:      	ubfx	x0, x0, #0, #8
    cf14:      	b	0xcef8 <_stogir.vector-lanes.compatible?+0x168>
    cf18:      	cmp	x3, #0x0
    cf1c:      	b.ne	0xcfcc <_stogir.vector-lanes.compatible?+0x23c>
    cf20:      	movz	x3, #0x0, lsl #48
    cf24:      	b	0xcf2c <_stogir.vector-lanes.compatible?+0x19c>
    cf28:      	mov	x3, #0x1                ; =1
    cf2c:      	uxtb	w16, w0
    cf30:      	cmp	w16, wzr
    cf34:      	b.ne	0xcf4c <_stogir.vector-lanes.compatible?+0x1bc>
    cf38:      	uxtb	w16, w4
    cf3c:      	cmp	w16, wzr
    cf40:      	b.ne	0xcf4c <_stogir.vector-lanes.compatible?+0x1bc>
    cf44:      	movn	x2, #0x0, lsl #48
    cf48:      	b	0xcf00 <_stogir.vector-lanes.compatible?+0x170>
    cf4c:      	cmp	x1, #0x0
    cf50:      	b.ne	0xcf5c <_stogir.vector-lanes.compatible?+0x1cc>
    cf54:      	movz	x2, #0x0, lsl #48
    cf58:      	b	0xcf00 <_stogir.vector-lanes.compatible?+0x170>
    cf5c:      	cmp	x1, #0x1
    cf60:      	b.eq	0xcefc <_stogir.vector-lanes.compatible?+0x16c>
    cf64:      	cmp	x1, #0x2
    cf68:      	b.eq	0xcefc <_stogir.vector-lanes.compatible?+0x16c>
    cf6c:      	cmp	x1, #0x7
    cf70:      	b.eq	0xcefc <_stogir.vector-lanes.compatible?+0x16c>
    cf74:      	cmp	x1, #0x8
    cf78:      	b.eq	0xcefc <_stogir.vector-lanes.compatible?+0x16c>
    cf7c:      	cmp	x1, #0x3
    cf80:      	b.eq	0xd03c <_stogir.vector-lanes.compatible?+0x2ac>
    cf84:      	cmp	x1, #0x9
    cf88:      	b.eq	0xd03c <_stogir.vector-lanes.compatible?+0x2ac>
    cf8c:      	cmp	x1, #0x4
    cf90:      	b.eq	0xd04c <_stogir.vector-lanes.compatible?+0x2bc>
    cf94:      	cmp	x1, #0xa
    cf98:      	b.eq	0xd04c <_stogir.vector-lanes.compatible?+0x2bc>
    cf9c:      	cmp	x1, #0xd
    cfa0:      	b.eq	0xd04c <_stogir.vector-lanes.compatible?+0x2bc>
    cfa4:      	cmp	x1, #0x5
    cfa8:      	b.eq	0xd05c <_stogir.vector-lanes.compatible?+0x2cc>
    cfac:      	cmp	x1, #0xb
    cfb0:      	b.eq	0xd05c <_stogir.vector-lanes.compatible?+0x2cc>
    cfb4:      	cmp	x1, #0xc
    cfb8:      	b.eq	0xd05c <_stogir.vector-lanes.compatible?+0x2cc>
    cfbc:      	cmp	x1, #0x6
    cfc0:      	b.eq	0xcfc8 <_stogir.vector-lanes.compatible?+0x238>
    cfc4:      	movn	x2, #0x0, lsl #48
    cfc8:      	b	0xd060 <_stogir.vector-lanes.compatible?+0x2d0>
    cfcc:      	cmp	x3, #0x1
    cfd0:      	b.eq	0xcf28 <_stogir.vector-lanes.compatible?+0x198>
    cfd4:      	cmp	x3, #0x2
    cfd8:      	b.eq	0xcf28 <_stogir.vector-lanes.compatible?+0x198>
    cfdc:      	cmp	x3, #0x7
    cfe0:      	b.eq	0xcf28 <_stogir.vector-lanes.compatible?+0x198>
    cfe4:      	cmp	x3, #0x8
    cfe8:      	b.eq	0xcf28 <_stogir.vector-lanes.compatible?+0x198>
    cfec:      	cmp	x3, #0x3
    cff0:      	b.eq	0xd044 <_stogir.vector-lanes.compatible?+0x2b4>
    cff4:      	cmp	x3, #0x9
    cff8:      	b.eq	0xd044 <_stogir.vector-lanes.compatible?+0x2b4>
    cffc:      	cmp	x3, #0x4
    d000:      	b.eq	0xd054 <_stogir.vector-lanes.compatible?+0x2c4>
    d004:      	cmp	x3, #0xa
    d008:      	b.eq	0xd054 <_stogir.vector-lanes.compatible?+0x2c4>
    d00c:      	cmp	x3, #0xd
    d010:      	b.eq	0xd054 <_stogir.vector-lanes.compatible?+0x2c4>
    d014:      	cmp	x3, #0x5
    d018:      	b.eq	0xd064 <_stogir.vector-lanes.compatible?+0x2d4>
    d01c:      	cmp	x3, #0xb
    d020:      	b.eq	0xd064 <_stogir.vector-lanes.compatible?+0x2d4>
    d024:      	cmp	x3, #0xc
    d028:      	b.eq	0xd064 <_stogir.vector-lanes.compatible?+0x2d4>
    d02c:      	cmp	x3, #0x6
    d030:      	b.ne	0xd06c <_stogir.vector-lanes.compatible?+0x2dc>
    d034:      	mov	x3, x2
    d038:      	b	0xd070 <_stogir.vector-lanes.compatible?+0x2e0>
    d03c:      	mov	x2, #0x2                ; =2
    d040:      	b	0xcf00 <_stogir.vector-lanes.compatible?+0x170>
    d044:      	mov	x3, #0x2                ; =2
    d048:      	b	0xcf2c <_stogir.vector-lanes.compatible?+0x19c>
    d04c:      	mov	x2, #0x4                ; =4
    d050:      	b	0xd040 <_stogir.vector-lanes.compatible?+0x2b0>
    d054:      	mov	x3, #0x4                ; =4
    d058:      	b	0xd048 <_stogir.vector-lanes.compatible?+0x2b8>
    d05c:      	mov	x2, #0x8                ; =8
    d060:      	b	0xd050 <_stogir.vector-lanes.compatible?+0x2c0>
    d064:      	mov	x3, #0x8                ; =8
    d068:      	b	0xd058 <_stogir.vector-lanes.compatible?+0x2c8>
    d06c:      	movn	x3, #0x0, lsl #48
    d070:      	b	0xd068 <_stogir.vector-lanes.compatible?+0x2d8>

000000000000d074 <_stogir.vector-comparison.valid-type?>:
    d074:      	sxtw	x0, w0
    d078:      	cmp	x0, #0xe
    d07c:      	b.lt	0xd114 <_stogir.vector-comparison.valid-type?+0xa0>
    d080:      	cmp	x0, #0x19
    d084:      	b.gt	0xd114 <_stogir.vector-comparison.valid-type?+0xa0>
    d088:      	sxtw	x1, w1
    d08c:      	cmp	x1, #0xf
    d090:      	cset	w2, gt
    d094:      	uxtb	w16, w2
    d098:      	cmp	w16, wzr
    d09c:      	b.eq	0xd11c <_stogir.vector-comparison.valid-type?+0xa8>
    d0a0:      	cmp	x1, #0x80
    d0a4:      	cset	w3, lt
    d0a8:      	uxtb	w16, w3
    d0ac:      	cmp	w16, wzr
    d0b0:      	b.eq	0xd11c <_stogir.vector-comparison.valid-type?+0xa8>
    d0b4:      	and	x4, x1, #0xf
    d0b8:      	sxtw	x4, w4
    d0bc:      	cmp	x4, #0x1
    d0c0:      	cset	w5, ge
    d0c4:      	uxtb	w16, w5
    d0c8:      	cmp	w16, wzr
    d0cc:      	b.eq	0xd11c <_stogir.vector-comparison.valid-type?+0xa8>
    d0d0:      	cmp	x4, #0xd
    d0d4:      	cset	w6, le
    d0d8:      	uxtb	w16, w6
    d0dc:      	cmp	w16, wzr
    d0e0:      	b.eq	0xd11c <_stogir.vector-comparison.valid-type?+0xa8>
    d0e4:      	cmp	x1, #0x0
    d0e8:      	cset	w7, ge
    d0ec:      	cmp	x1, #0xd
    d0f0:      	cset	w1, le
    d0f4:      	uxtb	w16, w7
    d0f8:      	cmp	w16, wzr
    d0fc:      	b.eq	0xd12c <_stogir.vector-comparison.valid-type?+0xb8>
    d100:      	uxtb	w16, w1
    d104:      	cmp	w16, wzr
    d108:      	b.eq	0xd12c <_stogir.vector-comparison.valid-type?+0xb8>
    d10c:      	mov	x8, x4
    d110:      	b	0xd160 <_stogir.vector-comparison.valid-type?+0xec>
    d114:      	movz	x0, #0x0, lsl #48
    d118:      	ret
    d11c:      	movz	x0, #0x0, lsl #48
    d120:      	b	0xd118 <_stogir.vector-comparison.valid-type?+0xa4>
    d124:      	mov	x0, #0x1                ; =1
    d128:      	b	0xd120 <_stogir.vector-comparison.valid-type?+0xac>
    d12c:      	uxtb	w16, w2
    d130:      	cmp	w16, wzr
    d134:      	b.eq	0xd15c <_stogir.vector-comparison.valid-type?+0xe8>
    d138:      	uxtb	w16, w3
    d13c:      	cmp	w16, wzr
    d140:      	b.eq	0xd15c <_stogir.vector-comparison.valid-type?+0xe8>
    d144:      	uxtb	w16, w5
    d148:      	cmp	w16, wzr
    d14c:      	b.eq	0xd15c <_stogir.vector-comparison.valid-type?+0xe8>
    d150:      	uxtb	w16, w6
    d154:      	cmp	w16, wzr
    d158:      	b.ne	0xd10c <_stogir.vector-comparison.valid-type?+0x98>
    d15c:      	movn	x8, #0x0, lsl #48
    d160:      	sxtw	x8, w8
    d164:      	cmp	x8, #0xc
    d168:      	b.eq	0xd124 <_stogir.vector-comparison.valid-type?+0xb0>
    d16c:      	cmp	x8, #0xd
    d170:      	b.eq	0xd124 <_stogir.vector-comparison.valid-type?+0xb0>
    d174:      	uxtb	w16, w7
    d178:      	cmp	w16, wzr
    d17c:      	b.eq	0xd18c <_stogir.vector-comparison.valid-type?+0x118>
    d180:      	uxtb	w16, w1
    d184:      	cmp	w16, wzr
    d188:      	b.ne	0xd1c0 <_stogir.vector-comparison.valid-type?+0x14c>
    d18c:      	uxtb	w16, w2
    d190:      	cmp	w16, wzr
    d194:      	b.eq	0xd1bc <_stogir.vector-comparison.valid-type?+0x148>
    d198:      	uxtb	w16, w3
    d19c:      	cmp	w16, wzr
    d1a0:      	b.eq	0xd1bc <_stogir.vector-comparison.valid-type?+0x148>
    d1a4:      	uxtb	w16, w5
    d1a8:      	cmp	w16, wzr
    d1ac:      	b.eq	0xd1bc <_stogir.vector-comparison.valid-type?+0x148>
    d1b0:      	uxtb	w16, w6
    d1b4:      	cmp	w16, wzr
    d1b8:      	b.ne	0xd1c0 <_stogir.vector-comparison.valid-type?+0x14c>
    d1bc:      	movn	x4, #0x0, lsl #48
    d1c0:      	sxtw	x4, w4
    d1c4:      	cmp	x4, #0x1
    d1c8:      	b.lt	0xd1e4 <_stogir.vector-comparison.valid-type?+0x170>
    d1cc:      	cmp	x4, #0xb
    d1d0:      	b.gt	0xd1e4 <_stogir.vector-comparison.valid-type?+0x170>
    d1d4:      	cmp	x0, #0x17
    d1d8:      	cset	w0, le
    d1dc:      	ubfx	x0, x0, #0, #8
    d1e0:      	b	0xd1e8 <_stogir.vector-comparison.valid-type?+0x174>
    d1e4:      	movz	x0, #0x0, lsl #48
    d1e8:      	b	0xd128 <_stogir.vector-comparison.valid-type?+0xb4>

000000000000d1ec <_stogir.vector-arithmetic.valid-type?>:
    d1ec:      	sub	sp, sp, #0x30
    d1f0:      	str	x29, [sp]
    d1f4:      	str	x30, [sp, #0x8]
    d1f8:      	mov	x29, sp
    d1fc:      	str	x19, [sp, #0x10]
    d200:      	str	x20, [sp, #0x18]
    d204:      	str	x21, [sp, #0x20]
    d208:      	str	x22, [sp, #0x28]
    d20c:      	sxtw	x1, w1
    d210:      	cmp	x1, #0xf
    d214:      	cset	w2, gt
    d218:      	cmp	x1, #0x80
    d21c:      	cset	w3, lt
    d220:      	and	x4, x1, #0xf
    d224:      	sxtw	x4, w4
    d228:      	cmp	x4, #0x1
    d22c:      	cset	w5, ge
    d230:      	cmp	x4, #0xd
    d234:      	cset	w6, le
    d238:      	cmp	x1, #0x0
    d23c:      	b.lt	0xd248 <_stogir.vector-arithmetic.valid-type?+0x5c>
    d240:      	cmp	x1, #0xd
    d244:      	b.le	0xd27c <_stogir.vector-arithmetic.valid-type?+0x90>
    d248:      	uxtb	w16, w2
    d24c:      	cmp	w16, wzr
    d250:      	b.eq	0xd278 <_stogir.vector-arithmetic.valid-type?+0x8c>
    d254:      	uxtb	w16, w3
    d258:      	cmp	w16, wzr
    d25c:      	b.eq	0xd278 <_stogir.vector-arithmetic.valid-type?+0x8c>
    d260:      	uxtb	w16, w5
    d264:      	cmp	w16, wzr
    d268:      	b.eq	0xd278 <_stogir.vector-arithmetic.valid-type?+0x8c>
    d26c:      	uxtb	w16, w6
    d270:      	cmp	w16, wzr
    d274:      	b.ne	0xd27c <_stogir.vector-arithmetic.valid-type?+0x90>
    d278:      	movn	x4, #0x0, lsl #48
    d27c:      	uxtb	w16, w2
    d280:      	cmp	w16, wzr
    d284:      	b.eq	0xd46c <_stogir.vector-arithmetic.valid-type?+0x280>
    d288:      	uxtb	w16, w3
    d28c:      	cmp	w16, wzr
    d290:      	b.eq	0xd46c <_stogir.vector-arithmetic.valid-type?+0x280>
    d294:      	uxtb	w16, w5
    d298:      	cmp	w16, wzr
    d29c:      	b.eq	0xd46c <_stogir.vector-arithmetic.valid-type?+0x280>
    d2a0:      	uxtb	w16, w6
    d2a4:      	cmp	w16, wzr
    d2a8:      	b.eq	0xd46c <_stogir.vector-arithmetic.valid-type?+0x280>
    d2ac:      	sxtw	x1, w0
    d2b0:      	cmp	x1, #0x1f
    d2b4:      	cset	w19, eq
    d2b8:      	cmp	x1, #0x20
    d2bc:      	cset	w20, eq
    d2c0:      	cmp	x1, #0x2e
    d2c4:      	cset	w2, eq
    d2c8:      	cmp	x1, #0x2f
    d2cc:      	cset	w3, eq
    d2d0:      	cmp	x1, #0x30
    d2d4:      	cset	w5, eq
    d2d8:      	cmp	x1, #0x1e
    d2dc:      	cset	w6, eq
    d2e0:      	cmp	x1, #0x31
    d2e4:      	cset	w7, ge
    d2e8:      	cmp	x1, #0x35
    d2ec:      	cset	w8, le
    d2f0:      	cmp	x1, #0x3a
    d2f4:      	cset	w9, eq
    d2f8:      	cmp	x1, #0x3b
    d2fc:      	cset	w10, eq
    d300:      	cmp	x1, #0x2d
    d304:      	cset	w11, eq
    d308:      	cmp	x1, #0x36
    d30c:      	cset	w12, eq
    d310:      	cmp	x1, #0x37
    d314:      	cset	w13, eq
    d318:      	cmp	x1, #0x38
    d31c:      	cset	w14, eq
    d320:      	cmp	x1, #0x39
    d324:      	cset	w15, eq
    d328:      	uxtb	w16, w19
    d32c:      	cmp	w16, wzr
    d330:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d334:      	uxtb	w16, w20
    d338:      	cmp	w16, wzr
    d33c:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d340:      	uxtb	w16, w11
    d344:      	cmp	w16, wzr
    d348:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d34c:      	uxtb	w16, w12
    d350:      	cmp	w16, wzr
    d354:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d358:      	uxtb	w16, w13
    d35c:      	cmp	w16, wzr
    d360:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d364:      	uxtb	w16, w14
    d368:      	cmp	w16, wzr
    d36c:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d370:      	uxtb	w16, w15
    d374:      	cmp	w16, wzr
    d378:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d37c:      	uxtb	w16, w9
    d380:      	cmp	w16, wzr
    d384:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d388:      	uxtb	w16, w10
    d38c:      	cmp	w16, wzr
    d390:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d394:      	uxtb	w16, w7
    d398:      	cmp	w16, wzr
    d39c:      	b.eq	0xd57c <_stogir.vector-arithmetic.valid-type?+0x390>
    d3a0:      	uxtb	w16, w8
    d3a4:      	cmp	w16, wzr
    d3a8:      	b.eq	0xd57c <_stogir.vector-arithmetic.valid-type?+0x390>
    d3ac:      	sxtw	x1, w4
    d3b0:      	cmp	x1, #0xc
    d3b4:      	cset	w21, eq
    d3b8:      	cmp	x1, #0xd
    d3bc:      	cset	w22, eq
    d3c0:      	uxtb	w16, w19
    d3c4:      	cmp	w16, wzr
    d3c8:      	b.ne	0xd498 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d3cc:      	uxtb	w16, w20
    d3d0:      	cmp	w16, wzr
    d3d4:      	b.ne	0xd498 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d3d8:      	uxtb	w16, w11
    d3dc:      	cmp	w16, wzr
    d3e0:      	b.ne	0xd498 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d3e4:      	uxtb	w16, w12
    d3e8:      	cmp	w16, wzr
    d3ec:      	b.ne	0xd498 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d3f0:      	uxtb	w16, w13
    d3f4:      	cmp	w16, wzr
    d3f8:      	b.ne	0xd498 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d3fc:      	uxtb	w16, w14
    d400:      	cmp	w16, wzr
    d404:      	b.ne	0xd498 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d408:      	uxtb	w16, w15
    d40c:      	cmp	w16, wzr
    d410:      	b.ne	0xd498 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d414:      	cmp	x1, #0x1
    d418:      	cset	w0, eq
    d41c:      	cmp	x1, #0x1
    d420:      	cset	w4, ge
    d424:      	cmp	x1, #0xb
    d428:      	cset	w1, le
    d42c:      	uxtb	w16, w7
    d430:      	cmp	w16, wzr
    d434:      	b.eq	0xd4ec <_stogir.vector-arithmetic.valid-type?+0x300>
    d438:      	uxtb	w16, w8
    d43c:      	cmp	w16, wzr
    d440:      	b.eq	0xd4ec <_stogir.vector-arithmetic.valid-type?+0x300>
    d444:      	uxtb	w16, w4
    d448:      	cmp	w16, wzr
    d44c:      	b.eq	0xd574 <_stogir.vector-arithmetic.valid-type?+0x388>
    d450:      	uxtb	w16, w1
    d454:      	cmp	w16, wzr
    d458:      	b.eq	0xd574 <_stogir.vector-arithmetic.valid-type?+0x388>
    d45c:      	uxtb	w16, w0
    d460:      	cmp	w16, wzr
    d464:      	cset	x0, eq
    d468:      	b	0xd578 <_stogir.vector-arithmetic.valid-type?+0x38c>
    d46c:      	movz	x0, #0x0, lsl #48
    d470:      	ldr	x19, [sp, #0x10]
    d474:      	ldr	x20, [sp, #0x18]
    d478:      	ldr	x21, [sp, #0x20]
    d47c:      	ldr	x22, [sp, #0x28]
    d480:      	ldr	x29, [sp]
    d484:      	ldr	x30, [sp, #0x8]
    d488:      	add	sp, sp, #0x30
    d48c:      	ret
    d490:      	ubfx	x0, x20, #0, #8
    d494:      	b	0xd470 <_stogir.vector-arithmetic.valid-type?+0x284>
    d498:      	mov	w1, w4
    d49c:      	bl	0xd49c <_stogir.vector-arithmetic.valid-type?+0x2b0>
		000000000000d49c:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    d4a0:      	cmp	x0, #0x0
    d4a4:      	b.eq	0xd4b0 <_stogir.vector-arithmetic.valid-type?+0x2c4>
    d4a8:      	mov	x0, #0x1                ; =1
    d4ac:      	b	0xd494 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    d4b0:      	uxtb	w16, w21
    d4b4:      	cmp	w16, wzr
    d4b8:      	b.ne	0xd4d0 <_stogir.vector-arithmetic.valid-type?+0x2e4>
    d4bc:      	uxtb	w16, w22
    d4c0:      	cmp	w16, wzr
    d4c4:      	b.ne	0xd4d0 <_stogir.vector-arithmetic.valid-type?+0x2e4>
    d4c8:      	movz	x0, #0x0, lsl #48
    d4cc:      	b	0xd494 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    d4d0:      	uxtb	w16, w19
    d4d4:      	cmp	w16, wzr
    d4d8:      	b.eq	0xd490 <_stogir.vector-arithmetic.valid-type?+0x2a4>
    d4dc:      	mov	x0, #0x1                ; =1
    d4e0:      	b	0xd494 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    d4e4:      	movz	x0, #0x0, lsl #48
    d4e8:      	b	0xd494 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    d4ec:      	uxtb	w16, w2
    d4f0:      	cmp	w16, wzr
    d4f4:      	b.ne	0xd560 <_stogir.vector-arithmetic.valid-type?+0x374>
    d4f8:      	uxtb	w16, w3
    d4fc:      	cmp	w16, wzr
    d500:      	b.ne	0xd560 <_stogir.vector-arithmetic.valid-type?+0x374>
    d504:      	uxtb	w16, w5
    d508:      	cmp	w16, wzr
    d50c:      	b.ne	0xd560 <_stogir.vector-arithmetic.valid-type?+0x374>
    d510:      	uxtb	w16, w21
    d514:      	cmp	w16, wzr
    d518:      	b.ne	0xd5d4 <_stogir.vector-arithmetic.valid-type?+0x3e8>
    d51c:      	uxtb	w16, w22
    d520:      	cmp	w16, wzr
    d524:      	b.ne	0xd5d4 <_stogir.vector-arithmetic.valid-type?+0x3e8>
    d528:      	uxtb	w16, w4
    d52c:      	cmp	w16, wzr
    d530:      	b.eq	0xd5e4 <_stogir.vector-arithmetic.valid-type?+0x3f8>
    d534:      	uxtb	w16, w1
    d538:      	cmp	w16, wzr
    d53c:      	b.eq	0xd5e4 <_stogir.vector-arithmetic.valid-type?+0x3f8>
    d540:      	uxtb	w16, w0
    d544:      	cmp	w16, wzr
    d548:      	b.eq	0xd5ec <_stogir.vector-arithmetic.valid-type?+0x400>
    d54c:      	uxtb	w16, w9
    d550:      	cmp	w16, wzr
    d554:      	b.eq	0xd5f4 <_stogir.vector-arithmetic.valid-type?+0x408>
    d558:      	mov	x0, #0x1                ; =1
    d55c:      	b	0xd5f8 <_stogir.vector-arithmetic.valid-type?+0x40c>
    d560:      	uxtb	w16, w4
    d564:      	cmp	w16, wzr
    d568:      	b.eq	0xd4e4 <_stogir.vector-arithmetic.valid-type?+0x2f8>
    d56c:      	ubfx	x0, x1, #0, #8
    d570:      	b	0xd4e8 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    d574:      	movz	x0, #0x0, lsl #48
    d578:      	b	0xd4e8 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    d57c:      	cmp	x1, #0x1a
    d580:      	b.eq	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d584:      	cmp	x1, #0x1b
    d588:      	b.eq	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d58c:      	cmp	x1, #0x1c
    d590:      	b.eq	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d594:      	cmp	x1, #0x1d
    d598:      	b.eq	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d59c:      	uxtb	w16, w6
    d5a0:      	cmp	w16, wzr
    d5a4:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d5a8:      	uxtb	w16, w2
    d5ac:      	cmp	w16, wzr
    d5b0:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d5b4:      	uxtb	w16, w3
    d5b8:      	cmp	w16, wzr
    d5bc:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d5c0:      	uxtb	w16, w5
    d5c4:      	cmp	w16, wzr
    d5c8:      	b.ne	0xd3ac <_stogir.vector-arithmetic.valid-type?+0x1c0>
    d5cc:      	movz	x0, #0x0, lsl #48
    d5d0:      	b	0xd494 <_stogir.vector-arithmetic.valid-type?+0x2a8>
    d5d4:      	uxtb	w16, w6
    d5d8:      	cmp	w16, wzr
    d5dc:      	cset	x0, eq
    d5e0:      	b	0xd4e8 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    d5e4:      	movz	x0, #0x0, lsl #48
    d5e8:      	b	0xd5e0 <_stogir.vector-arithmetic.valid-type?+0x3f4>
    d5ec:      	mov	x0, #0x1                ; =1
    d5f0:      	b	0xd5e8 <_stogir.vector-arithmetic.valid-type?+0x3fc>
    d5f4:      	ubfx	x0, x10, #0, #8
    d5f8:      	b	0xd5f0 <_stogir.vector-arithmetic.valid-type?+0x404>
