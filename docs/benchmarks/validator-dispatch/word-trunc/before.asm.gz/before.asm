
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-validator-dispatch/build/validator-verifier/word-trunc/before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0x8c <_gap_verify_graph+0x8c>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x78 <_gap_verify_graph+0x78>
      60:      	add	x0, sp, #0x30
      64:      	mov	x1, x19
      68:      	mov	x2, #0x1a0              ; =416
      6c:      	bl	0x6c <_gap_verify_graph+0x6c>
		000000000000006c:  ARM64_RELOC_BRANCH26	_memmove
      70:      	add	x16, sp, #0x30
      74:      	ldr	x0, [x16, #0x8]
      78:      	ldr	x19, [sp, #0x1d0]
      7c:      	ldr	x29, [sp]
      80:      	ldr	x30, [sp, #0x8]
      84:      	add	sp, sp, #0x1e0
      88:      	ret
      8c:      	brk	#0
      90:      	b	0x8c <_gap_verify_graph+0x8c>

0000000000000094 <_stogir.verify.integer-operations-target>:
      94:      	sub	sp, sp, #0x70
      98:      	str	x29, [sp]
      9c:      	str	x30, [sp, #0x8]
      a0:      	mov	x29, sp
      a4:      	str	x19, [sp, #0x50]
      a8:      	str	x20, [sp, #0x58]
      ac:      	str	x21, [sp, #0x60]
      b0:      	mov	x19, x8
      b4:      	add	x8, sp, #0x10
      b8:      	mov	x20, x0
      bc:      	mov	w21, w1
      c0:      	bl	0xc0 <_stogir.verify.integer-operations-target+0x2c>
		00000000000000c0:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      c4:      	add	x16, sp, #0x10
      c8:      	ldr	w0, [x16]
      cc:      	lsr	x16, x0, #0
      d0:      	cmp	x16, #0x1
      d4:      	b.eq	0xf0 <_stogir.verify.integer-operations-target+0x5c>
      d8:      	b.lo	0xe0 <_stogir.verify.integer-operations-target+0x4c>
      dc:      	b	0xf4 <_stogir.verify.integer-operations-target+0x60>
      e0:      	cmp	x16, #0x0
      e4:      	b.eq	0xec <_stogir.verify.integer-operations-target+0x58>
      e8:      	b	0xf4 <_stogir.verify.integer-operations-target+0x60>
      ec:      	b	0x118 <_stogir.verify.integer-operations-target+0x84>
      f0:      	b	0xf8 <_stogir.verify.integer-operations-target+0x64>
      f4:      	b	0x16c <_stogir.verify.integer-operations-target+0xd8>
      f8:      	add	x16, sp, #0x10
      fc:      	orr	x0, x16, xzr
     100:      	add	x0, x0, #0x8
     104:      	add	x16, sp, #0x10
     108:      	ldr	x1, [x16, #0x8]
     10c:      	ldr	x0, [x0, #0x8]
     110:      	mov	x2, #0x1                ; =1
     114:      	b	0x144 <_stogir.verify.integer-operations-target+0xb0>
     118:      	lsr	w21, w21, #0
     11c:      	add	x8, sp, #0x30
     120:      	mov	x0, x20
     124:      	mov	w1, w21
     128:      	bl	0x128 <_stogir.verify.integer-operations-target+0x94>
		0000000000000128:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     12c:      	add	x16, sp, #0x30
     130:      	ldr	x2, [x16]
     134:      	add	x16, sp, #0x30
     138:      	ldr	x1, [x16, #0x8]
     13c:      	add	x16, sp, #0x30
     140:      	ldr	x0, [x16, #0x10]
     144:      	str	x2, [x19]
     148:      	str	x1, [x19, #0x8]
     14c:      	str	x0, [x19, #0x10]
     150:      	ldr	x19, [sp, #0x50]
     154:      	ldr	x20, [sp, #0x58]
     158:      	ldr	x21, [sp, #0x60]
     15c:      	ldr	x29, [sp]
     160:      	ldr	x30, [sp, #0x8]
     164:      	add	sp, sp, #0x70
     168:      	ret
     16c:      	brk	#0
     170:      	b	0x16c <_stogir.verify.integer-operations-target+0xd8>
     174:      	udf	#0x0

0000000000000178 <_stogir.verify.structure>:
     178:      	sub	sp, sp, #0x1a0
     17c:      	str	x29, [sp, #0x10]
     180:      	str	x30, [sp, #0x18]
     184:      	add	x29, sp, #0x10
     188:      	str	x19, [sp, #0x150]
     18c:      	str	x20, [sp, #0x158]
     190:      	str	x21, [sp, #0x160]
     194:      	str	x22, [sp, #0x168]
     198:      	str	x23, [sp, #0x170]
     19c:      	str	x24, [sp, #0x178]
     1a0:      	str	x25, [sp, #0x180]
     1a4:      	str	x26, [sp, #0x188]
     1a8:      	str	x27, [sp, #0x190]
     1ac:      	str	x28, [sp, #0x198]
     1b0:      	add	x1, x0, #0x78
     1b4:      	ldr	x2, [x0, #0x8]
     1b8:      	ldr	x1, [x1, #0x8]
     1bc:      	cmp	x2, x1
     1c0:      	b.ne	0x1f8 <_stogir.verify.structure+0x80>
     1c4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001c4:  ARM64_RELOC_PAGE21	l_stogir.311
     1c8:      	ldr	x16, [x16]
		00000000000001c8:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     1cc:      	orr	x19, x16, xzr
     1d0:      	movz	x20, #0x0, lsl #48
     1d4:      	b	0x208 <_stogir.verify.structure+0x90>
     1d8:      	ldr	x1, [sp, #0x120]
     1dc:      	ldr	x6, [sp, #0x128]
     1e0:      	add	x6, x1, x6
     1e4:      	ldr	x1, [sp, #0xc0]
     1e8:      	add	x1, x1, #0x1
     1ec:      	lsr	w1, w1, #0
     1f0:      	sxtw	x1, w1
     1f4:      	b	0x2d4 <_stogir.verify.structure+0x15c>
     1f8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001f8:  ARM64_RELOC_PAGE21	l_stogir.312
     1fc:      	ldr	x16, [x16]
		00000000000001fc:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     200:      	orr	x19, x16, xzr
     204:      	mov	x20, #0x2c              ; =44
     208:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000208:  ARM64_RELOC_PAGE21	l_stogir.313
     20c:      	ldr	x16, [x16]
		000000000000020c:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     210:      	orr	x21, x16, xzr
     214:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000214:  ARM64_RELOC_PAGE21	l_stogir.314
     218:      	ldr	x16, [x16]
		0000000000000218:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     21c:      	orr	x22, x16, xzr
     220:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000220:  ARM64_RELOC_PAGE21	l_stogir.315
     224:      	ldr	x16, [x16]
		0000000000000224:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     228:      	orr	x23, x16, xzr
     22c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000022c:  ARM64_RELOC_PAGE21	l_stogir.316
     230:      	ldr	x16, [x16]
		0000000000000230:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     234:      	orr	x24, x16, xzr
     238:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000238:  ARM64_RELOC_PAGE21	l_stogir.317
     23c:      	ldr	x16, [x16]
		000000000000023c:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     240:      	orr	x25, x16, xzr
     244:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000244:  ARM64_RELOC_PAGE21	l_stogir.318
     248:      	ldr	x16, [x16]
		0000000000000248:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     24c:      	orr	x26, x16, xzr
     250:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000250:  ARM64_RELOC_PAGE21	l_stogir.319
     254:      	ldr	x16, [x16]
		0000000000000254:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     258:      	orr	x27, x16, xzr
     25c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000025c:  ARM64_RELOC_PAGE21	l_stogir.320
     260:      	ldr	x16, [x16]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     264:      	orr	x28, x16, xzr
     268:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000268:  ARM64_RELOC_PAGE21	l_stogir.321
     26c:      	ldr	x16, [x16]
		000000000000026c:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     270:      	orr	x1, x16, xzr
     274:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000274:  ARM64_RELOC_PAGE21	l_stogir.322
     278:      	ldr	x16, [x16]
		0000000000000278:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     27c:      	orr	x2, x16, xzr
     280:      	add	x3, x0, #0x110
     284:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000284:  ARM64_RELOC_PAGE21	l_stogir.323
     288:      	ldr	x16, [x16]
		0000000000000288:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     28c:      	orr	x4, x16, xzr
     290:      	add	x5, x0, #0x78
     294:      	add	x6, x0, #0x28
     298:      	add	x7, x0, #0x50
     29c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000029c:  ARM64_RELOC_PAGE21	l_stogir.323
     2a0:      	ldr	x16, [x16]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     2a4:      	orr	x9, x16, xzr
     2a8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002a8:  ARM64_RELOC_PAGE21	l_stogir.324
     2ac:      	ldr	x16, [x16]
		00000000000002ac:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     2b0:      	orr	x10, x16, xzr
     2b4:      	add	x11, x3, #0x28
     2b8:      	mov	x12, #0x1               ; =1
     2bc:      	movz	x13, #0x0, lsl #48
     2c0:      	b	0x398 <_stogir.verify.structure+0x220>
     2c4:      	ldr	x17, [sp, #0x58]
     2c8:      	str	x17, [sp, #0xa8]
     2cc:      	mov	x16, #0x16              ; =22
     2d0:      	str	x16, [sp, #0x118]
     2d4:      	b	0x33c <_stogir.verify.structure+0x1c4>
     2d8:      	str	x8, [sp, #0xa0]
     2dc:      	str	x21, [sp, #0x40]
     2e0:      	str	x22, [sp, #0x58]
     2e4:      	str	x23, [sp, #0x60]
     2e8:      	mov	x23, x0
     2ec:      	str	x24, [sp, #0x78]
     2f0:      	str	x25, [sp, #0x80]
     2f4:      	str	x26, [sp, #0x88]
     2f8:      	str	x27, [sp, #0x90]
     2fc:      	str	x28, [sp, #0x98]
     300:      	str	x1, [sp, #0x68]
     304:      	mov	x1, x13
     308:      	str	x2, [sp, #0x70]
     30c:      	str	x4, [sp, #0x100]
     310:      	mov	x0, x11
     314:      	mov	x2, x5
     318:      	mov	x4, x6
     31c:      	mov	x6, x12
     320:      	mov	x5, x7
     324:      	str	x9, [sp, #0xe8]
     328:      	str	x10, [sp, #0xf8]
     32c:      	ldr	x17, [sp, #0x40]
     330:      	str	x17, [sp, #0xa8]
     334:      	mov	x16, #0x23              ; =35
     338:      	str	x16, [sp, #0x118]
     33c:      	ldr	x8, [sp, #0xa0]
     340:      	ldr	x21, [sp, #0x40]
     344:      	ldr	x22, [sp, #0x58]
     348:      	ldr	x24, [sp, #0x78]
     34c:      	ldr	x25, [sp, #0x80]
     350:      	ldr	x26, [sp, #0x88]
     354:      	ldr	x27, [sp, #0x90]
     358:      	ldr	x28, [sp, #0x98]
     35c:      	mov	x11, x0
     360:      	mov	x0, x23
     364:      	ldr	x23, [sp, #0x60]
     368:      	mov	x7, x5
     36c:      	mov	x5, x2
     370:      	ldr	x2, [sp, #0x70]
     374:      	ldr	x9, [sp, #0xe8]
     378:      	ldr	x10, [sp, #0xf8]
     37c:      	mov	x12, x6
     380:      	mov	x6, x4
     384:      	ldr	x4, [sp, #0x100]
     388:      	mov	x13, x1
     38c:      	ldr	x1, [sp, #0x68]
     390:      	ldr	x19, [sp, #0xa8]
     394:      	ldr	x20, [sp, #0x118]
     398:      	cmp	x20, #0x0
     39c:      	b.ne	0xbe0 <_stogir.verify.structure+0xa68>
     3a0:      	ldr	x14, [x0, #0x8]
     3a4:      	cmp	x12, x14
     3a8:      	b.ge	0xbf4 <_stogir.verify.structure+0xa7c>
     3ac:      	ldr	x14, [x0]
     3b0:      	add	x14, x14, x12, lsl #4
     3b4:      	ldr	x14, [x14]
     3b8:      	ldr	x15, [x0, #0x78]
     3bc:      	add	x15, x15, x12, lsl #2
     3c0:      	ldr	w15, [x15]
     3c4:      	sxtw	x15, w15
     3c8:      	cmp	x15, #0x0
     3cc:      	b.lt	0x2d8 <_stogir.verify.structure+0x160>
     3d0:      	mov	x17, #0xffff            ; =65535
     3d4:      	cmp	x15, x17
     3d8:      	b.gt	0xc08 <_stogir.verify.structure+0xa90>
     3dc:      	str	x0, [sp, #0x30]
     3e0:      	uxtb	w0, w14
     3e4:      	str	w0, [sp, #0x38]
     3e8:      	str	x21, [sp, #0x40]
     3ec:      	cmp	x0, #0x83
     3f0:      	cset	w21, lt
     3f4:      	uxtb	w16, w21
     3f8:      	cmp	w16, wzr
     3fc:      	b.eq	0xc60 <_stogir.verify.structure+0xae8>
     400:      	lsr	w14, w14, #0
     404:      	str	x0, [sp, #0x48]
     408:      	ubfx	x0, x14, #8, #8
     40c:      	str	w0, [sp, #0x50]
     410:      	lsr	w0, w0, #0
     414:      	str	x8, [sp, #0xa0]
     418:      	str	x1, [sp, #0x68]
     41c:      	str	x2, [sp, #0x70]
     420:      	str	x3, [sp, #0xd0]
     424:      	str	x5, [sp, #0xc8]
     428:      	str	x6, [sp, #0xb8]
     42c:      	str	x7, [sp, #0xb0]
     430:      	str	x9, [sp, #0xe8]
     434:      	str	x11, [sp, #0xd8]
     438:      	str	x13, [sp, #0xc0]
     43c:      	str	x22, [sp, #0x58]
     440:      	ldr	w22, [sp, #0x50]
     444:      	str	x23, [sp, #0x60]
     448:      	ldr	x23, [sp, #0x30]
     44c:      	str	x24, [sp, #0x78]
     450:      	ldr	w24, [sp, #0x38]
     454:      	str	x25, [sp, #0x80]
     458:      	mov	x25, x4
     45c:      	str	x26, [sp, #0x88]
     460:      	mov	x26, x15
     464:      	str	x27, [sp, #0x90]
     468:      	mov	x27, x12
     46c:      	str	x28, [sp, #0x98]
     470:      	ldr	x28, [sp, #0x48]
     474:      	str	x19, [sp, #0xa8]
     478:      	mov	x19, x10
     47c:      	str	w21, [sp, #0xe0]
     480:      	mov	x21, x14
     484:      	bl	0x484 <_stogir.verify.structure+0x30c>
		0000000000000484:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     488:      	cmp	x0, #0x0
     48c:      	b.eq	0xcb4 <_stogir.verify.structure+0xb3c>
     490:      	add	x0, x28, x19
     494:      	lsr	w24, w24, #0
     498:      	ldrsb	w0, [x0]
     49c:      	sxtb	x0, w0
     4a0:      	cmp	x0, #0x0
     4a4:      	b.lt	0x938 <_stogir.verify.structure+0x7c0>
     4a8:      	mov	w0, w24
     4ac:      	bl	0x4ac <_stogir.verify.structure+0x334>
		00000000000004ac:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4b0:      	lsr	w0, w0, #0
     4b4:      	sxtw	x0, w0
     4b8:      	cmp	x26, x0
     4bc:      	b.eq	0x938 <_stogir.verify.structure+0x7c0>
     4c0:      	ldr	x3, [sp, #0xd0]
     4c4:      	str	x25, [sp, #0x100]
     4c8:      	ldr	x0, [sp, #0xd8]
     4cc:      	ldr	x2, [sp, #0xc8]
     4d0:      	ldr	x4, [sp, #0xb8]
     4d4:      	ldr	x5, [sp, #0xb0]
     4d8:      	str	x19, [sp, #0xf8]
     4dc:      	mov	x6, x27
     4e0:      	ldr	x1, [sp, #0xc0]
     4e4:      	ldr	x17, [sp, #0x60]
     4e8:      	str	x17, [sp, #0xa8]
     4ec:      	mov	x16, #0x23              ; =35
     4f0:      	str	x16, [sp, #0x118]
     4f4:      	b	0x1f4 <_stogir.verify.structure+0x7c>
     4f8:      	ldr	x0, [sp, #0x118]
     4fc:      	cmp	x0, #0x0
     500:      	b.ne	0xcdc <_stogir.verify.structure+0xb64>
     504:      	and	x1, x1, #0xffffffff
     508:      	movz	x2, #0x0, lsl #48
     50c:      	movz	x0, #0x0, lsl #48
     510:      	b	0x518 <_stogir.verify.structure+0x3a0>
     514:      	mov	x2, #0x1                ; =1
     518:      	ldr	x3, [sp, #0xa0]
     51c:      	str	x2, [x3]
     520:      	str	x1, [x3, #0x8]
     524:      	str	x0, [x3, #0x10]
     528:      	ldr	x19, [sp, #0x150]
     52c:      	ldr	x20, [sp, #0x158]
     530:      	ldr	x21, [sp, #0x160]
     534:      	ldr	x22, [sp, #0x168]
     538:      	ldr	x23, [sp, #0x170]
     53c:      	ldr	x24, [sp, #0x178]
     540:      	ldr	x25, [sp, #0x180]
     544:      	ldr	x26, [sp, #0x188]
     548:      	ldr	x27, [sp, #0x190]
     54c:      	ldr	x28, [sp, #0x198]
     550:      	ldr	x29, [sp, #0x10]
     554:      	ldr	x30, [sp, #0x18]
     558:      	add	sp, sp, #0x1a0
     55c:      	ret
     560:      	mov	x11, x8
     564:      	lsl	x11, x11, #2
     568:      	lsr	w11, w11, #0
     56c:      	ubfx	x11, x11, #0, #32
     570:      	lsr	x10, x10, x11
     574:      	lsr	w10, w10, #0
     578:      	and	x10, x10, #0xf
     57c:      	lsr	w10, w10, #0
     580:      	b	0x5a0 <_stogir.verify.structure+0x428>
     584:      	movz	x1, #0x0, lsl #48
     588:      	cmp	x1, #0x0
     58c:      	b.eq	0xa0c <_stogir.verify.structure+0x894>
     590:      	ldr	w1, [sp, #0x148]
     594:      	ldr	w6, [sp, #0x140]
     598:      	b	0x67c <_stogir.verify.structure+0x504>
     59c:      	movz	x10, #0x0, lsl #48
     5a0:      	b	0x5a8 <_stogir.verify.structure+0x430>
     5a4:      	movz	x10, #0x0, lsl #48
     5a8:      	add	x16, sp, #0x20
     5ac:      	str	x16, [sp]
     5b0:      	str	w0, [sp, #0xf0]
     5b4:      	str	x2, [sp, #0xe8]
     5b8:      	mov	w2, w4
     5bc:      	str	x3, [sp, #0x130]
     5c0:      	str	x19, [sp, #0xf8]
     5c4:      	mov	x19, x1
     5c8:      	mov	w1, w0
     5cc:      	mov	x0, x23
     5d0:      	str	x25, [sp, #0x100]
     5d4:      	mov	x25, x10
     5d8:      	str	x26, [sp, #0x108]
     5dc:      	mov	x26, x5
     5e0:      	str	x28, [sp, #0x110]
     5e4:      	mov	w28, w6
     5e8:      	str	x20, [sp, #0x118]
     5ec:      	mov	w20, w7
     5f0:      	str	x21, [sp, #0x120]
     5f4:      	mov	x21, x8
     5f8:      	str	x27, [sp, #0x128]
     5fc:      	mov	w27, w9
     600:      	bl	0x600 <_stogir.verify.structure+0x488>
		0000000000000600:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     604:      	ldr	x16, [sp]
     608:      	str	x0, [x16]
     60c:      	str	x1, [x16, #0x8]
     610:      	add	x16, sp, #0x20
     614:      	ldr	x0, [x16]
     618:      	add	x16, sp, #0x20
     61c:      	ldr	x1, [x16, #0x8]
     620:      	lsr	w0, w0, #0
     624:      	lsr	x16, x0, #0
     628:      	cmp	x16, #0x1
     62c:      	b.eq	0x648 <_stogir.verify.structure+0x4d0>
     630:      	b.lo	0x638 <_stogir.verify.structure+0x4c0>
     634:      	b	0x64c <_stogir.verify.structure+0x4d4>
     638:      	cmp	x16, #0x0
     63c:      	b.eq	0x644 <_stogir.verify.structure+0x4cc>
     640:      	b	0x64c <_stogir.verify.structure+0x4d4>
     644:      	b	0x650 <_stogir.verify.structure+0x4d8>
     648:      	b	0x754 <_stogir.verify.structure+0x5dc>
     64c:      	b	0xb48 <_stogir.verify.structure+0x9d0>
     650:      	ldr	x3, [sp, #0xd0]
     654:      	ldr	x0, [sp, #0xd8]
     658:      	ldr	x2, [sp, #0xc8]
     65c:      	ldr	x4, [sp, #0xb8]
     660:      	ldr	x5, [sp, #0xb0]
     664:      	mov	w1, w24
     668:      	mov	w6, w22
     66c:      	ldr	x17, [sp, #0x90]
     670:      	str	x17, [sp, #0xa8]
     674:      	mov	x16, #0x17              ; =23
     678:      	str	x16, [sp, #0x118]
     67c:      	ldr	x7, [sp, #0x130]
     680:      	add	x7, x7, #0x1
     684:      	lsr	w7, w7, #0
     688:      	sxtw	x7, w7
     68c:      	ldr	x26, [sp, #0x108]
     690:      	ldr	x21, [sp, #0x120]
     694:      	str	x3, [sp, #0xd0]
     698:      	str	w27, [sp, #0xe0]
     69c:      	ldr	x27, [sp, #0x128]
     6a0:      	ldr	x25, [sp, #0x100]
     6a4:      	ldr	x28, [sp, #0x110]
     6a8:      	str	x0, [sp, #0xd8]
     6ac:      	ldr	w0, [sp, #0xf0]
     6b0:      	str	x2, [sp, #0xc8]
     6b4:      	str	x4, [sp, #0xb8]
     6b8:      	str	x5, [sp, #0xb0]
     6bc:      	mov	w24, w1
     6c0:      	mov	w22, w6
     6c4:      	ldr	x2, [sp, #0xe8]
     6c8:      	mov	x1, x19
     6cc:      	ldr	x19, [sp, #0xf8]
     6d0:      	mov	x3, x7
     6d4:      	ldr	x20, [sp, #0x118]
     6d8:      	cmp	x20, #0x0
     6dc:      	b.ne	0x6f0 <_stogir.verify.structure+0x578>
     6e0:      	cmp	x3, x26
     6e4:      	cset	w4, le
     6e8:      	ubfx	x4, x4, #0, #8
     6ec:      	b	0x6f4 <_stogir.verify.structure+0x57c>
     6f0:      	movz	x4, #0x0, lsl #48
     6f4:      	cmp	x4, #0x0
     6f8:      	b.eq	0xce4 <_stogir.verify.structure+0xb6c>
     6fc:      	lsr	w4, w3, #0
     700:      	sxtw	x5, w4
     704:      	cmp	x5, #0x0
     708:      	cset	w6, gt
     70c:      	cmp	x5, #0x4
     710:      	cset	w7, gt
     714:      	sub	x8, x5, #0x1
     718:      	lsr	w8, w8, #0
     71c:      	sxtw	x8, w8
     720:      	ldr	w9, [sp, #0xe0]
     724:      	uxtb	w16, w9
     728:      	cmp	w16, wzr
     72c:      	b.eq	0x5a4 <_stogir.verify.structure+0x42c>
     730:      	ldr	w10, [x28]
     734:      	uxtb	w16, w6
     738:      	cmp	w16, wzr
     73c:      	b.eq	0x59c <_stogir.verify.structure+0x424>
     740:      	uxtb	w16, w7
     744:      	cmp	w16, wzr
     748:      	b.eq	0x560 <_stogir.verify.structure+0x3e8>
     74c:      	mov	x11, #0x4               ; =4
     750:      	b	0x564 <_stogir.verify.structure+0x3ec>
     754:      	lsr	w25, w25, #0
     758:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000758:  ARM64_RELOC_PAGE21	l_stogir.325
     75c:      	ldr	x16, [x16]
		000000000000075c:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     760:      	ldr	w0, [x16]
     764:      	orr	x2, x25, xzr
     768:      	cmp	x2, x0
     76c:      	b.ne	0x780 <_stogir.verify.structure+0x608>
     770:      	mov	x0, #0x1                ; =1
     774:      	b	0x798 <_stogir.verify.structure+0x620>
     778:      	movz	x1, #0x0, lsl #48
     77c:      	b	0x804 <_stogir.verify.structure+0x68c>
     780:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000780:  ARM64_RELOC_PAGE21	l_stogir.326
     784:      	ldr	x16, [x16]
		0000000000000784:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     788:      	ldr	w0, [x16]
     78c:      	cmp	x2, x0
     790:      	cset	w0, eq
     794:      	ubfx	x0, x0, #0, #8
     798:      	lsr	w1, w1, #0
     79c:      	cmp	x0, #0x0
     7a0:      	b.eq	0xd14 <_stogir.verify.structure+0xb9c>
     7a4:      	lsr	w1, w1, #0
     7a8:      	str	x26, [sp, #0x138]
     7ac:      	mov	x26, x2
     7b0:      	str	w22, [sp, #0x140]
     7b4:      	mov	x22, x0
     7b8:      	mov	x0, x23
     7bc:      	str	w24, [sp, #0x148]
     7c0:      	mov	w24, w1
     7c4:      	bl	0x7c4 <_stogir.verify.structure+0x64c>
		00000000000007c4:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     7c8:      	cmp	x0, #0x0
     7cc:      	cset	w1, eq
     7d0:      	uxtb	w16, w1
     7d4:      	cmp	w16, wzr
     7d8:      	cset	x1, eq
     7dc:      	cmp	x1, #0x0
     7e0:      	b.eq	0x804 <_stogir.verify.structure+0x68c>
     7e4:      	ldr	w0, [x0]
     7e8:      	uxtb	w0, w0
     7ec:      	cmp	x0, #0x48
     7f0:      	b.ne	0x804 <_stogir.verify.structure+0x68c>
     7f4:      	ldr	x17, [sp, #0x98]
     7f8:      	str	x17, [sp, #0xa8]
     7fc:      	mov	x16, #0x25              ; =37
     800:      	str	x16, [sp, #0x118]
     804:      	sxtw	x24, w24
     808:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000808:  ARM64_RELOC_PAGE21	l_stogir.327
     80c:      	ldr	x16, [x16]
		000000000000080c:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     810:      	ldr	w0, [x16]
     814:      	cmp	x26, x0
     818:      	b.ne	0xd30 <_stogir.verify.structure+0xbb8>
     81c:      	cmp	x24, #0x0
     820:      	b.gt	0x9a4 <_stogir.verify.structure+0x82c>
     824:      	ldr	x3, [sp, #0xd0]
     828:      	ldr	x0, [sp, #0xd8]
     82c:      	movz	x2, #0x0, lsl #48
     830:      	lsr	w2, w2, #0
     834:      	lsr	x16, x2, #0
     838:      	cmp	x16, #0x1
     83c:      	b.eq	0x858 <_stogir.verify.structure+0x6e0>
     840:      	b.lo	0x848 <_stogir.verify.structure+0x6d0>
     844:      	b	0x85c <_stogir.verify.structure+0x6e4>
     848:      	cmp	x16, #0x0
     84c:      	b.eq	0x854 <_stogir.verify.structure+0x6dc>
     850:      	b	0x85c <_stogir.verify.structure+0x6e4>
     854:      	b	0x860 <_stogir.verify.structure+0x6e8>
     858:      	b	0x870 <_stogir.verify.structure+0x6f8>
     85c:      	b	0xbd8 <_stogir.verify.structure+0xa60>
     860:      	ldr	x17, [sp, #0x68]
     864:      	str	x17, [sp, #0xa8]
     868:      	mov	x16, #0x21              ; =33
     86c:      	str	x16, [sp, #0x118]
     870:      	cmp	x25, #0xf
     874:      	b.hs	0xd3c <_stogir.verify.structure+0xbc4>
     878:      	mov	x16, #0x1               ; =1
     87c:      	lsl	x2, x16, x25
     880:      	lsr	w2, w2, #0
     884:      	mov	x17, #0x5e1c            ; =24092
     888:      	and	x2, x2, x17
     88c:      	lsr	w2, w2, #0
     890:      	cmp	x2, #0x0
     894:      	b.eq	0xd54 <_stogir.verify.structure+0xbdc>
     898:      	cmp	x22, #0x0
     89c:      	b.eq	0xa60 <_stogir.verify.structure+0x8e8>
     8a0:      	ldr	x2, [sp, #0xc8]
     8a4:      	ldr	x4, [sp, #0xb8]
     8a8:      	ldr	x5, [sp, #0xb0]
     8ac:      	b	0x588 <_stogir.verify.structure+0x410>
     8b0:      	lsr	w0, w27, #0
     8b4:      	cmp	x28, #0x78
     8b8:      	cset	w24, eq
     8bc:      	lsr	w0, w0, #0
     8c0:      	add	x1, x25, x28, lsl #2
     8c4:      	ldr	x2, [sp, #0xe8]
     8c8:      	add	x3, x2, x28, lsl #2
     8cc:      	cmp	x22, #0x0
     8d0:      	cset	w22, eq
     8d4:      	orr	x28, x1, xzr
     8d8:      	orr	x1, x3, xzr
     8dc:      	mov	x3, #0x1                ; =1
     8e0:      	b	0x6d8 <_stogir.verify.structure+0x560>
     8e4:      	nop
     8e8:      	movz	x1, #0x0, lsl #48
     8ec:      	cmp	x1, #0x0
     8f0:      	b.eq	0x8b0 <_stogir.verify.structure+0x738>
     8f4:      	add	x1, x0, x27
     8f8:      	ldr	x2, [x23, #0x78]
     8fc:      	add	x1, x2, x1, lsl #2
     900:      	ldr	w1, [x1]
     904:      	sxtw	x1, w1
     908:      	cmn	x1, #0x1
     90c:      	b.eq	0x91c <_stogir.verify.structure+0x7a4>
     910:      	ldr	x17, [sp, #0x88]
     914:      	str	x17, [sp, #0xa8]
     918:      	mov	x20, #0x1b              ; =27
     91c:      	add	x0, x0, #0x1
     920:      	cmp	x20, #0x0
     924:      	b.ne	0x8e8 <_stogir.verify.structure+0x770>
     928:      	cmp	x0, x21
     92c:      	cset	w1, lt
     930:      	ubfx	x1, x1, #0, #8
     934:      	b	0x8ec <_stogir.verify.structure+0x774>
     938:      	mov	w0, w24
     93c:      	bl	0x93c <_stogir.verify.structure+0x7c4>
		000000000000093c:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     940:      	lsr	w0, w0, #0
     944:      	sxtw	x0, w0
     948:      	cmn	x0, #0x1
     94c:      	b.ne	0x968 <_stogir.verify.structure+0x7f0>
     950:      	ubfx	x0, x21, #16, #16
     954:      	cmp	x26, x0
     958:      	b.eq	0x968 <_stogir.verify.structure+0x7f0>
     95c:      	ldr	x17, [sp, #0x78]
     960:      	str	x17, [sp, #0xa8]
     964:      	mov	x20, #0x24              ; =36
     968:      	add	x0, x26, #0x4
     96c:      	ldr	x1, [x23, #0x8]
     970:      	asr	x16, x0, #63
     974:      	lsr	x16, x16, #62
     978:      	add	x0, x0, x16
     97c:      	asr	x0, x0, #2
     980:      	orr	x21, x0, xzr
     984:      	add	x0, x21, x27
     988:      	cmp	x0, x1
     98c:      	b.le	0x99c <_stogir.verify.structure+0x824>
     990:      	ldr	x17, [sp, #0x80]
     994:      	str	x17, [sp, #0xa8]
     998:      	mov	x20, #0x15              ; =21
     99c:      	mov	x0, #0x1                ; =1
     9a0:      	b	0x920 <_stogir.verify.structure+0x7a8>
     9a4:      	ldr	x0, [sp, #0xd8]
     9a8:      	ldr	x2, [x0, #0x8]
     9ac:      	cmp	x24, x2
     9b0:      	b.gt	0xd6c <_stogir.verify.structure+0xbf4>
     9b4:      	sub	x2, x24, #0x1
     9b8:      	ldr	x3, [sp, #0xd0]
     9bc:      	ldr	x4, [x3, #0x28]
     9c0:      	mov	x17, #0x18              ; =24
     9c4:      	mul	x2, x2, x17
     9c8:      	add	x2, x2, x4
     9cc:      	ldr	x4, [x2]
     9d0:      	ldr	x2, [x2, #0x8]
     9d4:      	ldr	x5, [x3, #0x8]
     9d8:      	cmp	x4, #0x0
     9dc:      	b.lt	0xa04 <_stogir.verify.structure+0x88c>
     9e0:      	cmp	x4, x5
     9e4:      	b.gt	0xa04 <_stogir.verify.structure+0x88c>
     9e8:      	cmp	x2, #0x0
     9ec:      	b.lt	0xa04 <_stogir.verify.structure+0x88c>
     9f0:      	sub	x4, x5, x4
     9f4:      	cmp	x2, x4
     9f8:      	b.gt	0xa04 <_stogir.verify.structure+0x88c>
     9fc:      	mov	x2, #0x1                ; =1
     a00:      	b	0xa08 <_stogir.verify.structure+0x890>
     a04:      	movz	x2, #0x0, lsl #48
     a08:      	b	0x830 <_stogir.verify.structure+0x6b8>
     a0c:      	cmp	x24, #0x0
     a10:      	b.ne	0xd74 <_stogir.verify.structure+0xbfc>
     a14:      	uxtb	w16, w27
     a18:      	cmp	w16, wzr
     a1c:      	b.eq	0xb50 <_stogir.verify.structure+0x9d8>
     a20:      	ldr	w1, [x19]
     a24:      	uxtb	w16, w28
     a28:      	cmp	w16, wzr
     a2c:      	b.eq	0xb98 <_stogir.verify.structure+0xa20>
     a30:      	uxtb	w16, w20
     a34:      	cmp	w16, wzr
     a38:      	b.eq	0xa40 <_stogir.verify.structure+0x8c8>
     a3c:      	mov	x21, #0x4               ; =4
     a40:      	lsl	x6, x21, #2
     a44:      	lsr	w6, w6, #0
     a48:      	ubfx	x6, x6, #0, #32
     a4c:      	lsr	x1, x1, x6
     a50:      	lsr	w1, w1, #0
     a54:      	and	x1, x1, #0xf
     a58:      	lsr	w1, w1, #0
     a5c:      	b	0xb9c <_stogir.verify.structure+0xa24>
     a60:      	cmp	x24, #0x0
     a64:      	b.le	0xd80 <_stogir.verify.structure+0xc08>
     a68:      	ldr	x1, [x23, #0x8]
     a6c:      	cmp	x24, x1
     a70:      	b.ge	0xd88 <_stogir.verify.structure+0xc10>
     a74:      	ldr	x2, [sp, #0xc8]
     a78:      	ldr	x1, [x2, #0x8]
     a7c:      	cmp	x24, x1
     a80:      	b.ge	0xba8 <_stogir.verify.structure+0xa30>
     a84:      	ldr	x1, [x23, #0x78]
     a88:      	add	x1, x1, x24, lsl #2
     a8c:      	ldr	w1, [x1]
     a90:      	sxtw	x1, w1
     a94:      	cmp	x1, #0x0
     a98:      	cset	w1, ge
     a9c:      	ubfx	x1, x1, #0, #8
     aa0:      	b	0xbac <_stogir.verify.structure+0xa34>
     aa4:      	ldr	w1, [sp, #0x148]
     aa8:      	uxtb	w16, w1
     aac:      	cmp	w16, wzr
     ab0:      	b.eq	0xd90 <_stogir.verify.structure+0xc18>
     ab4:      	ldr	w6, [sp, #0x140]
     ab8:      	uxtb	w16, w6
     abc:      	cmp	w16, wzr
     ac0:      	b.eq	0xad0 <_stogir.verify.structure+0x958>
     ac4:      	ldr	x7, [sp, #0x138]
     ac8:      	cmp	x7, #0x2
     acc:      	b.eq	0x598 <_stogir.verify.structure+0x420>
     ad0:      	ldr	x17, [sp, #0x70]
     ad4:      	str	x17, [sp, #0xa8]
     ad8:      	mov	x16, #0x1a              ; =26
     adc:      	str	x16, [sp, #0x118]
     ae0:      	b	0x598 <_stogir.verify.structure+0x420>
     ae4:      	movz	x1, #0x0, lsl #48
     ae8:      	ldr	x4, [sp, #0xb8]
     aec:      	ldr	x5, [sp, #0xb0]
     af0:      	b	0x588 <_stogir.verify.structure+0x410>
     af4:      	cmp	x24, #0x0
     af8:      	b.ge	0xd98 <_stogir.verify.structure+0xc20>
     afc:      	ldr	x4, [sp, #0xb8]
     b00:      	ldr	x1, [x4, #0x8]
     b04:      	ldr	x5, [sp, #0xb0]
     b08:      	ldr	x6, [x5, #0x8]
     b0c:      	cmp	x1, x6
     b10:      	b.ne	0xba0 <_stogir.verify.structure+0xa28>
     b14:      	movz	x16, #0x0, lsl #48
     b18:      	sub	x6, x16, x24
     b1c:      	cmp	x6, x1
     b20:      	b.gt	0xbd0 <_stogir.verify.structure+0xa58>
     b24:      	sub	x1, x6, #0x1
     b28:      	ldr	x6, [x23, #0x50]
     b2c:      	add	x1, x6, x1, lsl #2
     b30:      	ldr	w1, [x1]
     b34:      	sxtw	x1, w1
     b38:      	cmp	x1, #0x0
     b3c:      	cset	w1, gt
     b40:      	ubfx	x1, x1, #0, #8
     b44:      	b	0xbd4 <_stogir.verify.structure+0xa5c>
     b48:      	brk	#0
     b4c:      	b	0xb48 <_stogir.verify.structure+0x9d0>
     b50:      	movz	x1, #0x0, lsl #48
     b54:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b54:  ARM64_RELOC_PAGE21	l_stogir.328
     b58:      	ldr	x16, [x16]
		0000000000000b58:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     b5c:      	ldr	w6, [x16]
     b60:      	lsr	w1, w1, #0
     b64:      	cmp	x1, x6
     b68:      	b.ne	0xb78 <_stogir.verify.structure+0xa00>
     b6c:      	ldr	w1, [sp, #0x148]
     b70:      	ldr	w6, [sp, #0x140]
     b74:      	b	0x598 <_stogir.verify.structure+0x420>
     b78:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b78:  ARM64_RELOC_PAGE21	l_stogir.329
     b7c:      	ldr	x16, [x16]
		0000000000000b7c:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     b80:      	ldr	w6, [x16]
     b84:      	cmp	x1, x6
     b88:      	b.ne	0xbb0 <_stogir.verify.structure+0xa38>
     b8c:      	ldr	w1, [sp, #0x148]
     b90:      	ldr	w6, [sp, #0x140]
     b94:      	b	0x598 <_stogir.verify.structure+0x420>
     b98:      	movz	x1, #0x0, lsl #48
     b9c:      	b	0xb54 <_stogir.verify.structure+0x9dc>
     ba0:      	movz	x1, #0x0, lsl #48
     ba4:      	b	0x588 <_stogir.verify.structure+0x410>
     ba8:      	movz	x1, #0x0, lsl #48
     bac:      	b	0xae8 <_stogir.verify.structure+0x970>
     bb0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bb0:  ARM64_RELOC_PAGE21	l_stogir.330
     bb4:      	ldr	x16, [x16]
		0000000000000bb4:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     bb8:      	ldr	w6, [x16]
     bbc:      	cmp	x1, x6
     bc0:      	b.ne	0xaa4 <_stogir.verify.structure+0x92c>
     bc4:      	ldr	w1, [sp, #0x148]
     bc8:      	ldr	w6, [sp, #0x140]
     bcc:      	b	0x598 <_stogir.verify.structure+0x420>
     bd0:      	movz	x1, #0x0, lsl #48
     bd4:      	b	0xba4 <_stogir.verify.structure+0xa2c>
     bd8:      	brk	#0
     bdc:      	b	0xbd8 <_stogir.verify.structure+0xa60>
     be0:      	mov	x1, x13
     be4:      	str	x8, [sp, #0xa0]
     be8:      	str	x19, [sp, #0xa8]
     bec:      	str	x20, [sp, #0x118]
     bf0:      	b	0x4f8 <_stogir.verify.structure+0x380>
     bf4:      	mov	x1, x13
     bf8:      	str	x8, [sp, #0xa0]
     bfc:      	str	x19, [sp, #0xa8]
     c00:      	str	x20, [sp, #0x118]
     c04:      	b	0x4f8 <_stogir.verify.structure+0x380>
     c08:      	str	x8, [sp, #0xa0]
     c0c:      	str	x21, [sp, #0x40]
     c10:      	str	x22, [sp, #0x58]
     c14:      	str	x23, [sp, #0x60]
     c18:      	mov	x23, x0
     c1c:      	str	x24, [sp, #0x78]
     c20:      	str	x25, [sp, #0x80]
     c24:      	str	x26, [sp, #0x88]
     c28:      	str	x27, [sp, #0x90]
     c2c:      	str	x28, [sp, #0x98]
     c30:      	str	x1, [sp, #0x68]
     c34:      	mov	x1, x13
     c38:      	str	x2, [sp, #0x70]
     c3c:      	str	x4, [sp, #0x100]
     c40:      	mov	x0, x11
     c44:      	mov	x2, x5
     c48:      	mov	x4, x6
     c4c:      	mov	x6, x12
     c50:      	mov	x5, x7
     c54:      	str	x9, [sp, #0xe8]
     c58:      	str	x10, [sp, #0xf8]
     c5c:      	b	0x32c <_stogir.verify.structure+0x1b4>
     c60:      	str	x8, [sp, #0xa0]
     c64:      	str	x22, [sp, #0x58]
     c68:      	str	x23, [sp, #0x60]
     c6c:      	ldr	x23, [sp, #0x30]
     c70:      	str	x24, [sp, #0x78]
     c74:      	str	x25, [sp, #0x80]
     c78:      	str	x26, [sp, #0x88]
     c7c:      	str	x27, [sp, #0x90]
     c80:      	str	x28, [sp, #0x98]
     c84:      	str	x1, [sp, #0x68]
     c88:      	mov	x1, x13
     c8c:      	str	x2, [sp, #0x70]
     c90:      	str	x4, [sp, #0x100]
     c94:      	mov	x0, x11
     c98:      	mov	x2, x5
     c9c:      	mov	x4, x6
     ca0:      	mov	x6, x12
     ca4:      	mov	x5, x7
     ca8:      	str	x9, [sp, #0xe8]
     cac:      	str	x10, [sp, #0xf8]
     cb0:      	b	0x2c4 <_stogir.verify.structure+0x14c>
     cb4:      	mov	x6, x27
     cb8:      	ldr	x1, [sp, #0xc0]
     cbc:      	ldr	x3, [sp, #0xd0]
     cc0:      	str	x25, [sp, #0x100]
     cc4:      	ldr	x0, [sp, #0xd8]
     cc8:      	ldr	x2, [sp, #0xc8]
     ccc:      	ldr	x4, [sp, #0xb8]
     cd0:      	ldr	x5, [sp, #0xb0]
     cd4:      	str	x19, [sp, #0xf8]
     cd8:      	b	0x2c4 <_stogir.verify.structure+0x14c>
     cdc:      	ldr	x1, [sp, #0xa8]
     ce0:      	b	0x514 <_stogir.verify.structure+0x39c>
     ce4:      	str	x27, [sp, #0x128]
     ce8:      	str	x21, [sp, #0x120]
     cec:      	ldr	x3, [sp, #0xd0]
     cf0:      	str	x20, [sp, #0x118]
     cf4:      	str	x25, [sp, #0x100]
     cf8:      	ldr	x0, [sp, #0xd8]
     cfc:      	ldr	x4, [sp, #0xb8]
     d00:      	ldr	x5, [sp, #0xb0]
     d04:      	str	x2, [sp, #0xe8]
     d08:      	ldr	x2, [sp, #0xc8]
     d0c:      	str	x19, [sp, #0xf8]
     d10:      	b	0x1d8 <_stogir.verify.structure+0x60>
     d14:      	str	x26, [sp, #0x138]
     d18:      	mov	x26, x2
     d1c:      	str	w24, [sp, #0x148]
     d20:      	mov	w24, w1
     d24:      	str	w22, [sp, #0x140]
     d28:      	mov	x22, x0
     d2c:      	b	0x778 <_stogir.verify.structure+0x600>
     d30:      	ldr	x3, [sp, #0xd0]
     d34:      	ldr	x0, [sp, #0xd8]
     d38:      	b	0x870 <_stogir.verify.structure+0x6f8>
     d3c:      	ldr	x2, [sp, #0xc8]
     d40:      	ldr	x4, [sp, #0xb8]
     d44:      	ldr	x5, [sp, #0xb0]
     d48:      	ldr	w1, [sp, #0x148]
     d4c:      	ldr	w6, [sp, #0x140]
     d50:      	b	0x598 <_stogir.verify.structure+0x420>
     d54:      	ldr	x2, [sp, #0xc8]
     d58:      	ldr	x4, [sp, #0xb8]
     d5c:      	ldr	x5, [sp, #0xb0]
     d60:      	ldr	w1, [sp, #0x148]
     d64:      	ldr	w6, [sp, #0x140]
     d68:      	b	0x598 <_stogir.verify.structure+0x420>
     d6c:      	ldr	x3, [sp, #0xd0]
     d70:      	b	0x82c <_stogir.verify.structure+0x6b4>
     d74:      	ldr	w1, [sp, #0x148]
     d78:      	ldr	w6, [sp, #0x140]
     d7c:      	b	0xad0 <_stogir.verify.structure+0x958>
     d80:      	ldr	x2, [sp, #0xc8]
     d84:      	b	0xaf4 <_stogir.verify.structure+0x97c>
     d88:      	ldr	x2, [sp, #0xc8]
     d8c:      	b	0xae4 <_stogir.verify.structure+0x96c>
     d90:      	ldr	w6, [sp, #0x140]
     d94:      	b	0xad0 <_stogir.verify.structure+0x958>
     d98:      	ldr	x4, [sp, #0xb8]
     d9c:      	ldr	x5, [sp, #0xb0]
     da0:      	b	0x584 <_stogir.verify.structure+0x40c>

0000000000000da4 <_stogir.verify.integer-operations-target-structured>:
     da4:      	sub	sp, sp, #0x3b0
     da8:      	str	x29, [sp, #0x10]
     dac:      	str	x30, [sp, #0x18]
     db0:      	add	x29, sp, #0x10
     db4:      	str	x19, [sp, #0x358]
     db8:      	str	x20, [sp, #0x360]
     dbc:      	str	x21, [sp, #0x368]
     dc0:      	str	x22, [sp, #0x370]
     dc4:      	str	x23, [sp, #0x378]
     dc8:      	str	x24, [sp, #0x380]
     dcc:      	str	x25, [sp, #0x388]
     dd0:      	str	x26, [sp, #0x390]
     dd4:      	str	x27, [sp, #0x398]
     dd8:      	str	x28, [sp, #0x3a0]
     ddc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ddc:  ARM64_RELOC_PAGE21	l_stogir.331
     de0:      	ldr	x16, [x16]
		0000000000000de0:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     de4:      	orr	x19, x16, xzr
     de8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000de8:  ARM64_RELOC_PAGE21	l_stogir.332
     dec:      	ldr	x16, [x16]
		0000000000000dec:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     df0:      	orr	x20, x16, xzr
     df4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000df4:  ARM64_RELOC_PAGE21	l_stogir.333
     df8:      	ldr	x16, [x16]
		0000000000000df8:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     dfc:      	orr	x21, x16, xzr
     e00:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e00:  ARM64_RELOC_PAGE21	l_stogir.334
     e04:      	ldr	x16, [x16]
		0000000000000e04:  ARM64_RELOC_PAGEOFF12	l_stogir.334
     e08:      	orr	x22, x16, xzr
     e0c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e0c:  ARM64_RELOC_PAGE21	l_stogir.335
     e10:      	ldr	x16, [x16]
		0000000000000e10:  ARM64_RELOC_PAGEOFF12	l_stogir.335
     e14:      	orr	x23, x16, xzr
     e18:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e18:  ARM64_RELOC_PAGE21	l_stogir.336
     e1c:      	ldr	x16, [x16]
		0000000000000e1c:  ARM64_RELOC_PAGEOFF12	l_stogir.336
     e20:      	orr	x24, x16, xzr
     e24:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e24:  ARM64_RELOC_PAGE21	l_stogir.337
     e28:      	ldr	x16, [x16]
		0000000000000e28:  ARM64_RELOC_PAGEOFF12	l_stogir.337
     e2c:      	orr	x25, x16, xzr
     e30:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e30:  ARM64_RELOC_PAGE21	l_stogir.338
     e34:      	ldr	x16, [x16]
		0000000000000e34:  ARM64_RELOC_PAGEOFF12	l_stogir.338
     e38:      	orr	x26, x16, xzr
     e3c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e3c:  ARM64_RELOC_PAGE21	l_stogir.339
     e40:      	ldr	x16, [x16]
		0000000000000e40:  ARM64_RELOC_PAGEOFF12	l_stogir.339
     e44:      	orr	x27, x16, xzr
     e48:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e48:  ARM64_RELOC_PAGE21	l_stogir.340
     e4c:      	ldr	x16, [x16]
		0000000000000e4c:  ARM64_RELOC_PAGEOFF12	l_stogir.340
     e50:      	orr	x28, x16, xzr
     e54:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e54:  ARM64_RELOC_PAGE21	l_stogir.341
     e58:      	ldr	x16, [x16]
		0000000000000e58:  ARM64_RELOC_PAGEOFF12	l_stogir.341
     e5c:      	orr	x2, x16, xzr
     e60:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e60:  ARM64_RELOC_PAGE21	l_stogir.342
     e64:      	ldr	x16, [x16]
		0000000000000e64:  ARM64_RELOC_PAGEOFF12	l_stogir.342
     e68:      	orr	x3, x16, xzr
     e6c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e6c:  ARM64_RELOC_PAGE21	l_stogir.343
     e70:      	ldr	x16, [x16]
		0000000000000e70:  ARM64_RELOC_PAGEOFF12	l_stogir.343
     e74:      	orr	x4, x16, xzr
     e78:      	add	x5, x0, #0x78
     e7c:      	add	x6, x0, #0x28
     e80:      	add	x7, x0, #0x50
     e84:      	lsr	w9, w1, #0
     e88:      	lsr	w10, w1, #0
     e8c:      	lsr	w1, w1, #0
     e90:      	add	x16, sp, #0x20
     e94:      	orr	x11, x16, xzr
     e98:      	add	x16, sp, #0x30
     e9c:      	orr	x12, x16, xzr
     ea0:      	add	x12, x12, #0x8
     ea4:      	add	x16, sp, #0x50
     ea8:      	orr	x13, x16, xzr
     eac:      	add	x13, x13, #0x8
     eb0:      	add	x16, sp, #0xe0
     eb4:      	orr	x14, x16, xzr
     eb8:      	add	x14, x14, #0x8
     ebc:      	add	x16, sp, #0x100
     ec0:      	orr	x15, x16, xzr
     ec4:      	add	x15, x15, #0x8
     ec8:      	str	w1, [sp, #0x230]
     ecc:      	add	x16, sp, #0x120
     ed0:      	orr	x1, x16, xzr
     ed4:      	add	x1, x1, #0x8
     ed8:      	str	x1, [sp, #0x238]
     edc:      	add	x16, sp, #0x140
     ee0:      	orr	x1, x16, xzr
     ee4:      	add	x1, x1, #0x8
     ee8:      	str	x1, [sp, #0x240]
     eec:      	add	x16, sp, #0x160
     ef0:      	orr	x1, x16, xzr
     ef4:      	add	x1, x1, #0x8
     ef8:      	str	x1, [sp, #0x248]
     efc:      	add	x16, sp, #0x180
     f00:      	orr	x1, x16, xzr
     f04:      	add	x1, x1, #0x8
     f08:      	str	x1, [sp, #0x250]
     f0c:      	add	x16, sp, #0x1a0
     f10:      	orr	x1, x16, xzr
     f14:      	add	x1, x1, #0x8
     f18:      	str	x1, [sp, #0x258]
     f1c:      	add	x16, sp, #0x1f0
     f20:      	orr	x1, x16, xzr
     f24:      	add	x1, x1, #0x8
     f28:      	str	x20, [sp, #0x260]
     f2c:      	str	x21, [sp, #0x268]
     f30:      	str	x22, [sp, #0x270]
     f34:      	mov	x20, #0x1               ; =1
     f38:      	movz	x21, #0x0, lsl #48
     f3c:      	movz	x22, #0x0, lsl #48
     f40:      	cmp	x22, #0x0
     f44:      	b.ne	0x1f74 <_stogir.verify.integer-operations-target-structured+0x11d0>
     f48:      	str	x1, [sp, #0x278]
     f4c:      	ldr	x1, [x0, #0x8]
     f50:      	cmp	x20, x1
     f54:      	b.ge	0x1f7c <_stogir.verify.integer-operations-target-structured+0x11d8>
     f58:      	ldr	x1, [x0]
     f5c:      	add	x1, x1, x20, lsl #4
     f60:      	str	x2, [sp, #0x280]
     f64:      	ldr	x2, [x1]
     f68:      	str	x23, [sp, #0x288]
     f6c:      	uxtb	w23, w2
     f70:      	ldr	x1, [x1, #0x8]
     f74:      	str	x24, [sp, #0x290]
     f78:      	orr	x24, x23, xzr
     f7c:      	add	x16, sp, #0x20
     f80:      	str	x2, [x16]
     f84:      	add	x16, sp, #0x20
     f88:      	str	x1, [x16, #0x8]
     f8c:      	ldr	x1, [x0, #0x78]
     f90:      	add	x1, x1, x20, lsl #2
     f94:      	ldr	w1, [x1]
     f98:      	cmp	x24, #0x83
     f9c:      	b.ge	0x17bc <_stogir.verify.integer-operations-target-structured+0xa18>
     fa0:      	add	x2, x3, x24, lsl #1
     fa4:      	ldrh	w2, [x2]
     fa8:      	cmp	x24, #0xe
     fac:      	b.lt	0x1f84 <_stogir.verify.integer-operations-target-structured+0x11e0>
     fb0:      	str	x0, [sp, #0x298]
     fb4:      	cmp	x24, #0x17
     fb8:      	cset	w0, le
     fbc:      	ubfx	x0, x0, #0, #8
     fc0:      	lsr	w2, w2, #0
     fc4:      	str	x0, [sp, #0x2a0]
     fc8:      	lsr	w0, w20, #0
     fcc:      	lsr	w1, w1, #0
     fd0:      	sxtw	x2, w2
     fd4:      	lsr	w0, w0, #0
     fd8:      	str	w0, [sp, #0x2a8]
     fdc:      	and	x0, x2, #0x4
     fe0:      	str	x8, [sp, #0x2d8]
     fe4:      	str	x3, [sp, #0x2c0]
     fe8:      	mov	w3, w1
     fec:      	str	x5, [sp, #0x318]
     ff0:      	str	x6, [sp, #0x310]
     ff4:      	str	x7, [sp, #0x308]
     ff8:      	str	w9, [sp, #0x2e8]
     ffc:      	str	w10, [sp, #0x2f0]
    1000:      	str	x11, [sp, #0x2f8]
    1004:      	str	x15, [sp, #0x328]
    1008:      	str	w1, [sp, #0x320]
    100c:      	ldr	w1, [sp, #0x2a8]
    1010:      	str	x25, [sp, #0x2b0]
    1014:      	mov	x25, x14
    1018:      	str	x26, [sp, #0x2b8]
    101c:      	mov	x26, x2
    1020:      	mov	x2, x11
    1024:      	str	x27, [sp, #0x2c8]
    1028:      	mov	x27, x4
    102c:      	str	x28, [sp, #0x2d0]
    1030:      	mov	x28, x0
    1034:      	ldr	x0, [sp, #0x298]
    1038:      	str	x20, [sp, #0x2e0]
    103c:      	mov	x20, x13
    1040:      	str	w23, [sp, #0x300]
    1044:      	mov	x23, x12
    1048:      	bl	0x1048 <_stogir.verify.integer-operations-target-structured+0x2a4>
		0000000000001048:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    104c:      	lsr	w28, w28, #0
    1050:      	uxtb	w1, w0
    1054:      	sxtw	x28, w28
    1058:      	cmp	x1, #0x0
    105c:      	cset	w1, ne
    1060:      	cmp	x28, #0x0
    1064:      	b.ne	0x17cc <_stogir.verify.integer-operations-target-structured+0xa28>
    1068:      	uxtb	w16, w1
    106c:      	cmp	w16, wzr
    1070:      	b.ne	0x17cc <_stogir.verify.integer-operations-target-structured+0xa28>
    1074:      	str	x0, [sp, #0x330]
    1078:      	mov	w28, w1
    107c:      	cmp	x24, #0x44
    1080:      	b.ne	0x1844 <_stogir.verify.integer-operations-target-structured+0xaa0>
    1084:      	uxtb	w16, w28
    1088:      	cmp	w16, wzr
    108c:      	b.eq	0x183c <_stogir.verify.integer-operations-target-structured+0xa98>
    1090:      	movz	x0, #0x0, lsl #48
    1094:      	cmp	x0, #0x0
    1098:      	b.eq	0x10ec <_stogir.verify.integer-operations-target-structured+0x348>
    109c:      	add	x8, sp, #0x50
    10a0:      	ldr	x0, [sp, #0x298]
    10a4:      	ldr	w1, [sp, #0x2a8]
    10a8:      	bl	0x10a8 <_stogir.verify.integer-operations-target-structured+0x304>
		00000000000010a8:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    10ac:      	add	x16, sp, #0x50
    10b0:      	ldr	w0, [x16]
    10b4:      	lsr	x16, x0, #0
    10b8:      	cmp	x16, #0x1
    10bc:      	b.eq	0x10d8 <_stogir.verify.integer-operations-target-structured+0x334>
    10c0:      	b.lo	0x10c8 <_stogir.verify.integer-operations-target-structured+0x324>
    10c4:      	b	0x10dc <_stogir.verify.integer-operations-target-structured+0x338>
    10c8:      	cmp	x16, #0x0
    10cc:      	b.eq	0x10d4 <_stogir.verify.integer-operations-target-structured+0x330>
    10d0:      	b	0x10dc <_stogir.verify.integer-operations-target-structured+0x338>
    10d4:      	b	0x184c <_stogir.verify.integer-operations-target-structured+0xaa8>
    10d8:      	b	0x10e0 <_stogir.verify.integer-operations-target-structured+0x33c>
    10dc:      	b	0x185c <_stogir.verify.integer-operations-target-structured+0xab8>
    10e0:      	add	x16, sp, #0x50
    10e4:      	ldr	x19, [x16, #0x8]
    10e8:      	ldr	x22, [x20, #0x8]
    10ec:      	cmp	x24, #0x1d
    10f0:      	b.ne	0x1864 <_stogir.verify.integer-operations-target-structured+0xac0>
    10f4:      	mov	x0, #0x1                ; =1
    10f8:      	cmp	x0, #0x0
    10fc:      	b.eq	0x187c <_stogir.verify.integer-operations-target-structured+0xad8>
    1100:      	add	x16, sp, #0x20
    1104:      	ldr	w0, [x16, #0xc]
    1108:      	sxtw	x0, w0
    110c:      	cmp	x0, #0x0
    1110:      	b.ne	0x1874 <_stogir.verify.integer-operations-target-structured+0xad0>
    1114:      	movz	x0, #0x0, lsl #48
    1118:      	cmp	x0, #0x0
    111c:      	b.eq	0x1178 <_stogir.verify.integer-operations-target-structured+0x3d4>
    1120:      	add	x16, sp, #0x20
    1124:      	ldr	w0, [x16, #0xc]
    1128:      	lsr	w0, w0, #0
    112c:      	add	x8, sp, #0x70
    1130:      	mov	w1, w0
    1134:      	ldr	x0, [sp, #0x298]
    1138:      	bl	0x1138 <_stogir.verify.integer-operations-target-structured+0x394>
		0000000000001138:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    113c:      	add	x16, sp, #0x70
    1140:      	ldr	w0, [x16]
    1144:      	lsr	x16, x0, #0
    1148:      	cmp	x16, #0x1
    114c:      	b.eq	0x1168 <_stogir.verify.integer-operations-target-structured+0x3c4>
    1150:      	b.lo	0x1158 <_stogir.verify.integer-operations-target-structured+0x3b4>
    1154:      	b	0x116c <_stogir.verify.integer-operations-target-structured+0x3c8>
    1158:      	cmp	x16, #0x0
    115c:      	b.eq	0x1164 <_stogir.verify.integer-operations-target-structured+0x3c0>
    1160:      	b	0x116c <_stogir.verify.integer-operations-target-structured+0x3c8>
    1164:      	b	0x1170 <_stogir.verify.integer-operations-target-structured+0x3cc>
    1168:      	b	0x1884 <_stogir.verify.integer-operations-target-structured+0xae0>
    116c:      	b	0x191c <_stogir.verify.integer-operations-target-structured+0xb78>
    1170:      	ldr	x19, [sp, #0x260]
    1174:      	mov	x22, #0x16              ; =22
    1178:      	and	x0, x26, #0x8
    117c:      	lsr	w0, w0, #0
    1180:      	sxtw	x0, w0
    1184:      	cmp	x0, #0x0
    1188:      	b.ne	0x1924 <_stogir.verify.integer-operations-target-structured+0xb80>
    118c:      	movz	x0, #0x0, lsl #48
    1190:      	cmp	x24, #0x2c
    1194:      	cset	w1, eq
    1198:      	cmp	x0, #0x0
    119c:      	b.eq	0x192c <_stogir.verify.integer-operations-target-structured+0xb88>
    11a0:      	mov	x0, #0x1                ; =1
    11a4:      	cmp	x0, #0x0
    11a8:      	b.eq	0x1218 <_stogir.verify.integer-operations-target-structured+0x474>
    11ac:      	uxtb	w16, w1
    11b0:      	cmp	w16, wzr
    11b4:      	b.eq	0x1934 <_stogir.verify.integer-operations-target-structured+0xb90>
    11b8:      	add	x8, sp, #0xa0
    11bc:      	ldr	x0, [sp, #0x298]
    11c0:      	ldr	w1, [sp, #0x2a8]
    11c4:      	bl	0x11c4 <_stogir.verify.integer-operations-target-structured+0x420>
		00000000000011c4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    11c8:      	add	x16, sp, #0xa0
    11cc:      	ldr	x0, [x16]
    11d0:      	add	x16, sp, #0xa0
    11d4:      	ldr	x1, [x16, #0x8]
    11d8:      	add	x16, sp, #0xa0
    11dc:      	ldr	x2, [x16, #0x10]
    11e0:      	lsr	w0, w0, #0
    11e4:      	lsr	x16, x0, #0
    11e8:      	cmp	x16, #0x1
    11ec:      	b.eq	0x1208 <_stogir.verify.integer-operations-target-structured+0x464>
    11f0:      	b.lo	0x11f8 <_stogir.verify.integer-operations-target-structured+0x454>
    11f4:      	b	0x120c <_stogir.verify.integer-operations-target-structured+0x468>
    11f8:      	cmp	x16, #0x0
    11fc:      	b.eq	0x1204 <_stogir.verify.integer-operations-target-structured+0x460>
    1200:      	b	0x120c <_stogir.verify.integer-operations-target-structured+0x468>
    1204:      	b	0x1960 <_stogir.verify.integer-operations-target-structured+0xbbc>
    1208:      	b	0x1210 <_stogir.verify.integer-operations-target-structured+0x46c>
    120c:      	b	0x1970 <_stogir.verify.integer-operations-target-structured+0xbcc>
    1210:      	mov	x19, x1
    1214:      	mov	x22, x2
    1218:      	and	x0, x26, #0x10
    121c:      	lsr	w0, w0, #0
    1220:      	sxtw	x0, w0
    1224:      	cmp	x0, #0x0
    1228:      	b.ne	0x1978 <_stogir.verify.integer-operations-target-structured+0xbd4>
    122c:      	movz	x0, #0x0, lsl #48
    1230:      	cmp	x0, #0x0
    1234:      	b.eq	0x1288 <_stogir.verify.integer-operations-target-structured+0x4e4>
    1238:      	add	x8, sp, #0xe0
    123c:      	ldr	x0, [sp, #0x298]
    1240:      	ldr	w1, [sp, #0x2a8]
    1244:      	bl	0x1244 <_stogir.verify.integer-operations-target-structured+0x4a0>
		0000000000001244:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    1248:      	add	x16, sp, #0xe0
    124c:      	ldr	w0, [x16]
    1250:      	lsr	x16, x0, #0
    1254:      	cmp	x16, #0x1
    1258:      	b.eq	0x1274 <_stogir.verify.integer-operations-target-structured+0x4d0>
    125c:      	b.lo	0x1264 <_stogir.verify.integer-operations-target-structured+0x4c0>
    1260:      	b	0x1278 <_stogir.verify.integer-operations-target-structured+0x4d4>
    1264:      	cmp	x16, #0x0
    1268:      	b.eq	0x1270 <_stogir.verify.integer-operations-target-structured+0x4cc>
    126c:      	b	0x1278 <_stogir.verify.integer-operations-target-structured+0x4d4>
    1270:      	b	0x1980 <_stogir.verify.integer-operations-target-structured+0xbdc>
    1274:      	b	0x127c <_stogir.verify.integer-operations-target-structured+0x4d8>
    1278:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xbec>
    127c:      	add	x16, sp, #0xe0
    1280:      	ldr	x19, [x16, #0x8]
    1284:      	ldr	x22, [x25, #0x8]
    1288:      	and	x0, x26, #0x20
    128c:      	lsr	w0, w0, #0
    1290:      	sxtw	x0, w0
    1294:      	cmp	x0, #0x0
    1298:      	b.ne	0x1998 <_stogir.verify.integer-operations-target-structured+0xbf4>
    129c:      	movz	x0, #0x0, lsl #48
    12a0:      	cmp	x0, #0x0
    12a4:      	b.eq	0x1f8c <_stogir.verify.integer-operations-target-structured+0x11e8>
    12a8:      	add	x8, sp, #0x100
    12ac:      	ldr	x0, [sp, #0x298]
    12b0:      	ldr	w1, [sp, #0x2a8]
    12b4:      	bl	0x12b4 <_stogir.verify.integer-operations-target-structured+0x510>
		00000000000012b4:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    12b8:      	add	x16, sp, #0x100
    12bc:      	ldr	w0, [x16]
    12c0:      	lsr	x16, x0, #0
    12c4:      	cmp	x16, #0x1
    12c8:      	b.eq	0x12e8 <_stogir.verify.integer-operations-target-structured+0x544>
    12cc:      	b.lo	0x12d4 <_stogir.verify.integer-operations-target-structured+0x530>
    12d0:      	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x548>
    12d4:      	cmp	x16, #0x0
    12d8:      	b.eq	0x12e0 <_stogir.verify.integer-operations-target-structured+0x53c>
    12dc:      	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x548>
    12e0:      	ldr	x0, [sp, #0x328]
    12e4:      	b	0x19a0 <_stogir.verify.integer-operations-target-structured+0xbfc>
    12e8:      	b	0x12f0 <_stogir.verify.integer-operations-target-structured+0x54c>
    12ec:      	b	0x19b0 <_stogir.verify.integer-operations-target-structured+0xc0c>
    12f0:      	add	x16, sp, #0x100
    12f4:      	ldr	x19, [x16, #0x8]
    12f8:      	ldr	x0, [sp, #0x328]
    12fc:      	ldr	x22, [x0, #0x8]
    1300:      	and	x1, x26, #0x40
    1304:      	lsr	w1, w1, #0
    1308:      	sxtw	x1, w1
    130c:      	cmp	x1, #0x0
    1310:      	b.ne	0x19b8 <_stogir.verify.integer-operations-target-structured+0xc14>
    1314:      	movz	x1, #0x0, lsl #48
    1318:      	cmp	x1, #0x0
    131c:      	b.eq	0x1f94 <_stogir.verify.integer-operations-target-structured+0x11f0>
    1320:      	add	x8, sp, #0x120
    1324:      	ldr	w1, [sp, #0x2a8]
    1328:      	str	x0, [sp, #0x328]
    132c:      	ldr	x0, [sp, #0x298]
    1330:      	bl	0x1330 <_stogir.verify.integer-operations-target-structured+0x58c>
		0000000000001330:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    1334:      	add	x16, sp, #0x120
    1338:      	ldr	w0, [x16]
    133c:      	lsr	x16, x0, #0
    1340:      	cmp	x16, #0x1
    1344:      	b.eq	0x1364 <_stogir.verify.integer-operations-target-structured+0x5c0>
    1348:      	b.lo	0x1350 <_stogir.verify.integer-operations-target-structured+0x5ac>
    134c:      	b	0x1368 <_stogir.verify.integer-operations-target-structured+0x5c4>
    1350:      	cmp	x16, #0x0
    1354:      	b.eq	0x135c <_stogir.verify.integer-operations-target-structured+0x5b8>
    1358:      	b	0x1368 <_stogir.verify.integer-operations-target-structured+0x5c4>
    135c:      	ldr	x0, [sp, #0x238]
    1360:      	b	0x19c0 <_stogir.verify.integer-operations-target-structured+0xc1c>
    1364:      	b	0x136c <_stogir.verify.integer-operations-target-structured+0x5c8>
    1368:      	b	0x19d0 <_stogir.verify.integer-operations-target-structured+0xc2c>
    136c:      	add	x16, sp, #0x120
    1370:      	ldr	x19, [x16, #0x8]
    1374:      	ldr	x0, [sp, #0x238]
    1378:      	ldr	x22, [x0, #0x8]
    137c:      	and	x1, x26, #0x80
    1380:      	lsr	w1, w1, #0
    1384:      	sxtw	x1, w1
    1388:      	cmp	x1, #0x0
    138c:      	b.ne	0x19d8 <_stogir.verify.integer-operations-target-structured+0xc34>
    1390:      	movz	x1, #0x0, lsl #48
    1394:      	cmp	x1, #0x0
    1398:      	b.eq	0x1fa0 <_stogir.verify.integer-operations-target-structured+0x11fc>
    139c:      	add	x8, sp, #0x140
    13a0:      	ldr	w1, [sp, #0x2a8]
    13a4:      	str	x0, [sp, #0x238]
    13a8:      	ldr	x0, [sp, #0x298]
    13ac:      	bl	0x13ac <_stogir.verify.integer-operations-target-structured+0x608>
		00000000000013ac:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    13b0:      	add	x16, sp, #0x140
    13b4:      	ldr	w0, [x16]
    13b8:      	lsr	x16, x0, #0
    13bc:      	cmp	x16, #0x1
    13c0:      	b.eq	0x13e0 <_stogir.verify.integer-operations-target-structured+0x63c>
    13c4:      	b.lo	0x13cc <_stogir.verify.integer-operations-target-structured+0x628>
    13c8:      	b	0x13e4 <_stogir.verify.integer-operations-target-structured+0x640>
    13cc:      	cmp	x16, #0x0
    13d0:      	b.eq	0x13d8 <_stogir.verify.integer-operations-target-structured+0x634>
    13d4:      	b	0x13e4 <_stogir.verify.integer-operations-target-structured+0x640>
    13d8:      	ldr	x0, [sp, #0x240]
    13dc:      	b	0x19e0 <_stogir.verify.integer-operations-target-structured+0xc3c>
    13e0:      	b	0x13e8 <_stogir.verify.integer-operations-target-structured+0x644>
    13e4:      	b	0x19f0 <_stogir.verify.integer-operations-target-structured+0xc4c>
    13e8:      	add	x16, sp, #0x140
    13ec:      	ldr	x19, [x16, #0x8]
    13f0:      	ldr	x0, [sp, #0x240]
    13f4:      	ldr	x22, [x0, #0x8]
    13f8:      	and	x1, x26, #0x100
    13fc:      	lsr	w1, w1, #0
    1400:      	sxtw	x1, w1
    1404:      	cmp	x1, #0x0
    1408:      	b.ne	0x19f8 <_stogir.verify.integer-operations-target-structured+0xc54>
    140c:      	movz	x1, #0x0, lsl #48
    1410:      	cmp	x1, #0x0
    1414:      	b.eq	0x1fac <_stogir.verify.integer-operations-target-structured+0x1208>
    1418:      	add	x8, sp, #0x160
    141c:      	ldr	w1, [sp, #0x2a8]
    1420:      	ldr	w2, [sp, #0x2f0]
    1424:      	str	x0, [sp, #0x240]
    1428:      	ldr	x0, [sp, #0x298]
    142c:      	bl	0x142c <_stogir.verify.integer-operations-target-structured+0x688>
		000000000000142c:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1430:      	add	x16, sp, #0x160
    1434:      	ldr	w0, [x16]
    1438:      	lsr	x16, x0, #0
    143c:      	cmp	x16, #0x1
    1440:      	b.eq	0x1460 <_stogir.verify.integer-operations-target-structured+0x6bc>
    1444:      	b.lo	0x144c <_stogir.verify.integer-operations-target-structured+0x6a8>
    1448:      	b	0x1464 <_stogir.verify.integer-operations-target-structured+0x6c0>
    144c:      	cmp	x16, #0x0
    1450:      	b.eq	0x1458 <_stogir.verify.integer-operations-target-structured+0x6b4>
    1454:      	b	0x1464 <_stogir.verify.integer-operations-target-structured+0x6c0>
    1458:      	ldr	x0, [sp, #0x248]
    145c:      	b	0x1a00 <_stogir.verify.integer-operations-target-structured+0xc5c>
    1460:      	b	0x1468 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1464:      	b	0x1a10 <_stogir.verify.integer-operations-target-structured+0xc6c>
    1468:      	add	x16, sp, #0x160
    146c:      	ldr	x19, [x16, #0x8]
    1470:      	ldr	x0, [sp, #0x248]
    1474:      	ldr	x22, [x0, #0x8]
    1478:      	and	x1, x26, #0x200
    147c:      	lsr	w1, w1, #0
    1480:      	sxtw	x1, w1
    1484:      	cmp	x1, #0x0
    1488:      	b.ne	0x1a18 <_stogir.verify.integer-operations-target-structured+0xc74>
    148c:      	movz	x1, #0x0, lsl #48
    1490:      	cmp	x1, #0x0
    1494:      	b.eq	0x1fb8 <_stogir.verify.integer-operations-target-structured+0x1214>
    1498:      	add	x8, sp, #0x180
    149c:      	ldr	w1, [sp, #0x2a8]
    14a0:      	ldr	w2, [sp, #0x230]
    14a4:      	str	x0, [sp, #0x248]
    14a8:      	ldr	x0, [sp, #0x298]
    14ac:      	bl	0x14ac <_stogir.verify.integer-operations-target-structured+0x708>
		00000000000014ac:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    14b0:      	add	x16, sp, #0x180
    14b4:      	ldr	w0, [x16]
    14b8:      	lsr	x16, x0, #0
    14bc:      	cmp	x16, #0x1
    14c0:      	b.eq	0x14e0 <_stogir.verify.integer-operations-target-structured+0x73c>
    14c4:      	b.lo	0x14cc <_stogir.verify.integer-operations-target-structured+0x728>
    14c8:      	b	0x14e4 <_stogir.verify.integer-operations-target-structured+0x740>
    14cc:      	cmp	x16, #0x0
    14d0:      	b.eq	0x14d8 <_stogir.verify.integer-operations-target-structured+0x734>
    14d4:      	b	0x14e4 <_stogir.verify.integer-operations-target-structured+0x740>
    14d8:      	ldr	x0, [sp, #0x250]
    14dc:      	b	0x1a20 <_stogir.verify.integer-operations-target-structured+0xc7c>
    14e0:      	b	0x14e8 <_stogir.verify.integer-operations-target-structured+0x744>
    14e4:      	b	0x1a30 <_stogir.verify.integer-operations-target-structured+0xc8c>
    14e8:      	add	x16, sp, #0x180
    14ec:      	ldr	x19, [x16, #0x8]
    14f0:      	ldr	x0, [sp, #0x250]
    14f4:      	ldr	x22, [x0, #0x8]
    14f8:      	cmp	x24, #0x3c
    14fc:      	b.ne	0x1fc4 <_stogir.verify.integer-operations-target-structured+0x1220>
    1500:      	add	x8, sp, #0x1a0
    1504:      	ldr	w1, [sp, #0x2a8]
    1508:      	str	x0, [sp, #0x250]
    150c:      	ldr	x0, [sp, #0x298]
    1510:      	bl	0x1510 <_stogir.verify.integer-operations-target-structured+0x76c>
		0000000000001510:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    1514:      	add	x16, sp, #0x1a0
    1518:      	ldr	w0, [x16]
    151c:      	lsr	x16, x0, #0
    1520:      	cmp	x16, #0x1
    1524:      	b.eq	0x1544 <_stogir.verify.integer-operations-target-structured+0x7a0>
    1528:      	b.lo	0x1530 <_stogir.verify.integer-operations-target-structured+0x78c>
    152c:      	b	0x1548 <_stogir.verify.integer-operations-target-structured+0x7a4>
    1530:      	cmp	x16, #0x0
    1534:      	b.eq	0x153c <_stogir.verify.integer-operations-target-structured+0x798>
    1538:      	b	0x1548 <_stogir.verify.integer-operations-target-structured+0x7a4>
    153c:      	ldr	x0, [sp, #0x258]
    1540:      	b	0x1a38 <_stogir.verify.integer-operations-target-structured+0xc94>
    1544:      	b	0x154c <_stogir.verify.integer-operations-target-structured+0x7a8>
    1548:      	b	0x1a48 <_stogir.verify.integer-operations-target-structured+0xca4>
    154c:      	add	x16, sp, #0x1a0
    1550:      	ldr	x19, [x16, #0x8]
    1554:      	ldr	x0, [sp, #0x258]
    1558:      	ldr	x22, [x0, #0x8]
    155c:      	cmp	x24, #0x78
    1560:      	b.ne	0x1fd0 <_stogir.verify.integer-operations-target-structured+0x122c>
    1564:      	add	x16, sp, #0x20
    1568:      	ldr	w1, [x16]
    156c:      	ubfx	x1, x1, #8, #8
    1570:      	cmp	x1, #0x0
    1574:      	b.ne	0x1a50 <_stogir.verify.integer-operations-target-structured+0xcac>
    1578:      	add	x16, sp, #0x20
    157c:      	ldr	w1, [x16, #0x8]
    1580:      	sxtw	x1, w1
    1584:      	cmp	x1, #0x0
    1588:      	b.eq	0x1594 <_stogir.verify.integer-operations-target-structured+0x7f0>
    158c:      	ldr	x19, [sp, #0x270]
    1590:      	mov	x22, #0x1f              ; =31
    1594:      	str	x0, [sp, #0x258]
    1598:      	add	x0, x21, #0x1
    159c:      	lsr	w0, w0, #0
    15a0:      	sxtw	x21, w0
    15a4:      	ldr	x0, [sp, #0x330]
    15a8:      	uxth	w0, w0
    15ac:      	mov	w17, #0x8               ; =8
    15b0:      	uxth	w16, w0
    15b4:      	ubfx	w17, w17, #0, #4
    15b8:      	lsr	w0, w16, w17
    15bc:      	uxth	w0, w0
    15c0:      	uxtb	w0, w0
    15c4:      	cmp	x0, #0x0
    15c8:      	b.eq	0x1fd8 <_stogir.verify.integer-operations-target-structured+0x1234>
    15cc:      	add	x8, sp, #0x1f0
    15d0:      	ldr	w1, [sp, #0x2a8]
    15d4:      	str	x20, [sp, #0x338]
    15d8:      	mov	x20, x0
    15dc:      	ldr	x0, [sp, #0x298]
    15e0:      	bl	0x15e0 <_stogir.verify.integer-operations-target-structured+0x83c>
		00000000000015e0:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    15e4:      	add	x16, sp, #0x1f0
    15e8:      	ldr	w0, [x16]
    15ec:      	lsr	x16, x0, #0
    15f0:      	cmp	x16, #0x1
    15f4:      	b.eq	0x1614 <_stogir.verify.integer-operations-target-structured+0x870>
    15f8:      	b.lo	0x1600 <_stogir.verify.integer-operations-target-structured+0x85c>
    15fc:      	b	0x1618 <_stogir.verify.integer-operations-target-structured+0x874>
    1600:      	cmp	x16, #0x0
    1604:      	b.eq	0x160c <_stogir.verify.integer-operations-target-structured+0x868>
    1608:      	b	0x1618 <_stogir.verify.integer-operations-target-structured+0x874>
    160c:      	ldr	x0, [sp, #0x278]
    1610:      	b	0x1ae4 <_stogir.verify.integer-operations-target-structured+0xd40>
    1614:      	b	0x161c <_stogir.verify.integer-operations-target-structured+0x878>
    1618:      	b	0x1af4 <_stogir.verify.integer-operations-target-structured+0xd50>
    161c:      	add	x16, sp, #0x1f0
    1620:      	ldr	x19, [x16, #0x8]
    1624:      	ldr	x0, [sp, #0x278]
    1628:      	ldr	x22, [x0, #0x8]
    162c:      	uxtb	w16, w28
    1630:      	cmp	w16, wzr
    1634:      	b.eq	0x1afc <_stogir.verify.integer-operations-target-structured+0xd58>
    1638:      	movz	x1, #0x0, lsl #48
    163c:      	and	x2, x26, #0x1
    1640:      	and	x3, x26, #0x2
    1644:      	lsr	w2, w2, #0
    1648:      	lsr	w3, w3, #0
    164c:      	sxtw	x2, w2
    1650:      	sxtw	x3, w3
    1654:      	cmp	x2, #0x0
    1658:      	cset	w2, eq
    165c:      	cmp	x3, #0x0
    1660:      	cset	w3, eq
    1664:      	uxtb	w16, w2
    1668:      	cmp	w16, wzr
    166c:      	cset	x26, eq
    1670:      	uxtb	w16, w3
    1674:      	cmp	w16, wzr
    1678:      	cset	x28, eq
    167c:      	cmp	x1, #0x0
    1680:      	b.eq	0x1fe8 <_stogir.verify.integer-operations-target-structured+0x1244>
    1684:      	cmp	x20, #0x0
    1688:      	b.eq	0x1b04 <_stogir.verify.integer-operations-target-structured+0xd60>
    168c:      	movz	x1, #0x0, lsl #48
    1690:      	cmp	x1, #0x0
    1694:      	b.eq	0x1ff0 <_stogir.verify.integer-operations-target-structured+0x124c>
    1698:      	ldr	x20, [sp, #0x2a0]
    169c:      	cmp	x20, #0x0
    16a0:      	b.eq	0x1b0c <_stogir.verify.integer-operations-target-structured+0xd68>
    16a4:      	mov	x1, #0x1                ; =1
    16a8:      	cmp	x1, #0x0
    16ac:      	b.eq	0x1ff8 <_stogir.verify.integer-operations-target-structured+0x1254>
    16b0:      	add	x16, sp, #0x210
    16b4:      	str	x16, [sp]
    16b8:      	ldr	w1, [sp, #0x2a8]
    16bc:      	str	x0, [sp, #0x278]
    16c0:      	ldr	x0, [sp, #0x298]
    16c4:      	mov	x2, #0x1                ; =1
    16c8:      	bl	0x16c8 <_stogir.verify.integer-operations-target-structured+0x924>
		00000000000016c8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    16cc:      	ldr	x16, [sp]
    16d0:      	str	x0, [x16]
    16d4:      	str	x1, [x16, #0x8]
    16d8:      	add	x16, sp, #0x210
    16dc:      	ldr	x0, [x16]
    16e0:      	add	x16, sp, #0x210
    16e4:      	ldr	x1, [x16, #0x8]
    16e8:      	lsr	w0, w0, #0
    16ec:      	lsr	x16, x0, #0
    16f0:      	cmp	x16, #0x1
    16f4:      	b.eq	0x1710 <_stogir.verify.integer-operations-target-structured+0x96c>
    16f8:      	b.lo	0x1700 <_stogir.verify.integer-operations-target-structured+0x95c>
    16fc:      	b	0x1714 <_stogir.verify.integer-operations-target-structured+0x970>
    1700:      	cmp	x16, #0x0
    1704:      	b.eq	0x170c <_stogir.verify.integer-operations-target-structured+0x968>
    1708:      	b	0x1714 <_stogir.verify.integer-operations-target-structured+0x970>
    170c:      	b	0x1718 <_stogir.verify.integer-operations-target-structured+0x974>
    1710:      	b	0x1b34 <_stogir.verify.integer-operations-target-structured+0xd90>
    1714:      	b	0x1f00 <_stogir.verify.integer-operations-target-structured+0x115c>
    1718:      	str	x23, [sp, #0x340]
    171c:      	str	x25, [sp, #0x348]
    1720:      	str	x27, [sp, #0x350]
    1724:      	ldr	x19, [sp, #0x2b0]
    1728:      	mov	x22, #0x17              ; =23
    172c:      	add	x0, x21, #0x1
    1730:      	lsr	w0, w0, #0
    1734:      	sxtw	x21, w0
    1738:      	ldr	w0, [sp, #0x320]
    173c:      	sxtw	x0, w0
    1740:      	add	x0, x0, #0x4
    1744:      	asr	x16, x0, #63
    1748:      	lsr	x16, x16, #62
    174c:      	add	x0, x0, x16
    1750:      	asr	x0, x0, #2
    1754:      	ldr	x1, [sp, #0x2e0]
    1758:      	add	x1, x0, x1
    175c:      	ldr	x8, [sp, #0x2d8]
    1760:      	ldr	x0, [sp, #0x298]
    1764:      	ldr	x11, [sp, #0x2f8]
    1768:      	ldr	x23, [sp, #0x288]
    176c:      	ldr	x24, [sp, #0x290]
    1770:      	ldr	x25, [sp, #0x2b0]
    1774:      	ldr	x26, [sp, #0x2b8]
    1778:      	ldr	x27, [sp, #0x2c8]
    177c:      	ldr	x28, [sp, #0x2d0]
    1780:      	ldr	x2, [sp, #0x280]
    1784:      	ldr	w9, [sp, #0x2e8]
    1788:      	ldr	x12, [sp, #0x340]
    178c:      	ldr	x13, [sp, #0x338]
    1790:      	ldr	x14, [sp, #0x348]
    1794:      	ldr	x15, [sp, #0x328]
    1798:      	ldr	w10, [sp, #0x2f0]
    179c:      	ldr	x3, [sp, #0x2c0]
    17a0:      	ldr	x4, [sp, #0x350]
    17a4:      	ldr	x5, [sp, #0x318]
    17a8:      	ldr	x6, [sp, #0x310]
    17ac:      	ldr	x7, [sp, #0x308]
    17b0:      	mov	x20, x1
    17b4:      	ldr	x1, [sp, #0x278]
    17b8:      	b	0xf40 <_stogir.verify.integer-operations-target-structured+0x19c>
    17bc:      	movz	x2, #0x0, lsl #48
    17c0:      	b	0xfa8 <_stogir.verify.integer-operations-target-structured+0x204>
    17c4:      	movz	x0, #0x0, lsl #48
    17c8:      	b	0xfc0 <_stogir.verify.integer-operations-target-structured+0x21c>
    17cc:      	add	x8, sp, #0x30
    17d0:      	ldr	w2, [sp, #0x2e8]
    17d4:      	str	x0, [sp, #0x330]
    17d8:      	ldr	x0, [sp, #0x298]
    17dc:      	mov	w28, w1
    17e0:      	ldr	w1, [sp, #0x2a8]
    17e4:      	bl	0x17e4 <_stogir.verify.integer-operations-target-structured+0xa40>
		00000000000017e4:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    17e8:      	add	x16, sp, #0x30
    17ec:      	ldr	w0, [x16]
    17f0:      	lsr	x16, x0, #0
    17f4:      	cmp	x16, #0x1
    17f8:      	b.eq	0x1814 <_stogir.verify.integer-operations-target-structured+0xa70>
    17fc:      	b.lo	0x1804 <_stogir.verify.integer-operations-target-structured+0xa60>
    1800:      	b	0x1818 <_stogir.verify.integer-operations-target-structured+0xa74>
    1804:      	cmp	x16, #0x0
    1808:      	b.eq	0x1810 <_stogir.verify.integer-operations-target-structured+0xa6c>
    180c:      	b	0x1818 <_stogir.verify.integer-operations-target-structured+0xa74>
    1810:      	b	0x182c <_stogir.verify.integer-operations-target-structured+0xa88>
    1814:      	b	0x181c <_stogir.verify.integer-operations-target-structured+0xa78>
    1818:      	b	0x1f08 <_stogir.verify.integer-operations-target-structured+0x1164>
    181c:      	add	x16, sp, #0x30
    1820:      	ldr	x19, [x16, #0x8]
    1824:      	ldr	x22, [x23, #0x8]
    1828:      	b	0x107c <_stogir.verify.integer-operations-target-structured+0x2d8>
    182c:      	add	x0, x21, #0x1
    1830:      	lsr	w0, w0, #0
    1834:      	sxtw	x21, w0
    1838:      	b	0x1828 <_stogir.verify.integer-operations-target-structured+0xa84>
    183c:      	mov	x0, #0x1                ; =1
    1840:      	b	0x1094 <_stogir.verify.integer-operations-target-structured+0x2f0>
    1844:      	movz	x0, #0x0, lsl #48
    1848:      	b	0x1094 <_stogir.verify.integer-operations-target-structured+0x2f0>
    184c:      	add	x0, x21, #0x1
    1850:      	lsr	w0, w0, #0
    1854:      	sxtw	x21, w0
    1858:      	b	0x10ec <_stogir.verify.integer-operations-target-structured+0x348>
    185c:      	brk	#0
    1860:      	b	0x185c <_stogir.verify.integer-operations-target-structured+0xab8>
    1864:      	cmp	x24, #0x1e
    1868:      	cset	w0, eq
    186c:      	ubfx	x0, x0, #0, #8
    1870:      	b	0x10f8 <_stogir.verify.integer-operations-target-structured+0x354>
    1874:      	mov	x0, #0x1                ; =1
    1878:      	b	0x1118 <_stogir.verify.integer-operations-target-structured+0x374>
    187c:      	movz	x0, #0x0, lsl #48
    1880:      	b	0x1118 <_stogir.verify.integer-operations-target-structured+0x374>
    1884:      	add	x16, sp, #0x70
    1888:      	ldr	x0, [x16, #0x8]
    188c:      	add	x16, sp, #0x20
    1890:      	ldr	w1, [x16, #0xc]
    1894:      	sxtw	x1, w1
    1898:      	cmp	x1, #0x0
    189c:      	b.ge	0x18b8 <_stogir.verify.integer-operations-target-structured+0xb14>
    18a0:      	mov	x0, #0x1                ; =1
    18a4:      	cmp	x0, #0x0
    18a8:      	b.eq	0x18b4 <_stogir.verify.integer-operations-target-structured+0xb10>
    18ac:      	ldr	x19, [sp, #0x268]
    18b0:      	mov	x22, #0x2d              ; =45
    18b4:      	b	0x1178 <_stogir.verify.integer-operations-target-structured+0x3d4>
    18b8:      	uxtb	w0, w0
    18bc:      	cmp	x0, #0x83
    18c0:      	b.ge	0x190c <_stogir.verify.integer-operations-target-structured+0xb68>
    18c4:      	add	x1, x0, x27
    18c8:      	ldrb	w1, [x1]
    18cc:      	uxtb	w1, w1
    18d0:      	and	x1, x1, #0x2
    18d4:      	uxtb	w1, w1
    18d8:      	cmp	x1, #0x0
    18dc:      	cset	w1, eq
    18e0:      	uxtb	w16, w1
    18e4:      	cmp	w16, wzr
    18e8:      	cset	x1, eq
    18ec:      	cmp	x1, #0x0
    18f0:      	b.ne	0x1914 <_stogir.verify.integer-operations-target-structured+0xb70>
    18f4:      	cmp	x0, #0x65
    18f8:      	b.eq	0x1914 <_stogir.verify.integer-operations-target-structured+0xb70>
    18fc:      	cmp	x0, #0x66
    1900:      	b.eq	0x1914 <_stogir.verify.integer-operations-target-structured+0xb70>
    1904:      	mov	x0, #0x1                ; =1
    1908:      	b	0x18a4 <_stogir.verify.integer-operations-target-structured+0xb00>
    190c:      	movz	x1, #0x0, lsl #48
    1910:      	b	0x18cc <_stogir.verify.integer-operations-target-structured+0xb28>
    1914:      	movz	x0, #0x0, lsl #48
    1918:      	b	0x1908 <_stogir.verify.integer-operations-target-structured+0xb64>
    191c:      	brk	#0
    1920:      	b	0x191c <_stogir.verify.integer-operations-target-structured+0xb78>
    1924:      	mov	x0, #0x1                ; =1
    1928:      	b	0x1190 <_stogir.verify.integer-operations-target-structured+0x3ec>
    192c:      	ubfx	x0, x1, #0, #8
    1930:      	b	0x11a4 <_stogir.verify.integer-operations-target-structured+0x400>
    1934:      	add	x8, sp, #0xc0
    1938:      	ldr	x0, [sp, #0x298]
    193c:      	ldr	w1, [sp, #0x2a8]
    1940:      	bl	0x1940 <_stogir.verify.integer-operations-target-structured+0xb9c>
		0000000000001940:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1944:      	add	x16, sp, #0xc0
    1948:      	ldr	x0, [x16]
    194c:      	add	x16, sp, #0xc0
    1950:      	ldr	x1, [x16, #0x8]
    1954:      	add	x16, sp, #0xc0
    1958:      	ldr	x2, [x16, #0x10]
    195c:      	b	0x11e0 <_stogir.verify.integer-operations-target-structured+0x43c>
    1960:      	add	x0, x21, #0x1
    1964:      	lsr	w0, w0, #0
    1968:      	sxtw	x21, w0
    196c:      	b	0x1218 <_stogir.verify.integer-operations-target-structured+0x474>
    1970:      	brk	#0
    1974:      	b	0x1970 <_stogir.verify.integer-operations-target-structured+0xbcc>
    1978:      	mov	x0, #0x1                ; =1
    197c:      	b	0x1230 <_stogir.verify.integer-operations-target-structured+0x48c>
    1980:      	add	x0, x21, #0x1
    1984:      	lsr	w0, w0, #0
    1988:      	sxtw	x21, w0
    198c:      	b	0x1288 <_stogir.verify.integer-operations-target-structured+0x4e4>
    1990:      	brk	#0
    1994:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xbec>
    1998:      	mov	x0, #0x1                ; =1
    199c:      	b	0x12a0 <_stogir.verify.integer-operations-target-structured+0x4fc>
    19a0:      	add	x1, x21, #0x1
    19a4:      	lsr	w1, w1, #0
    19a8:      	sxtw	x21, w1
    19ac:      	b	0x1300 <_stogir.verify.integer-operations-target-structured+0x55c>
    19b0:      	brk	#0
    19b4:      	b	0x19b0 <_stogir.verify.integer-operations-target-structured+0xc0c>
    19b8:      	mov	x1, #0x1                ; =1
    19bc:      	b	0x1318 <_stogir.verify.integer-operations-target-structured+0x574>
    19c0:      	add	x1, x21, #0x1
    19c4:      	lsr	w1, w1, #0
    19c8:      	sxtw	x21, w1
    19cc:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x5d8>
    19d0:      	brk	#0
    19d4:      	b	0x19d0 <_stogir.verify.integer-operations-target-structured+0xc2c>
    19d8:      	mov	x1, #0x1                ; =1
    19dc:      	b	0x1394 <_stogir.verify.integer-operations-target-structured+0x5f0>
    19e0:      	add	x1, x21, #0x1
    19e4:      	lsr	w1, w1, #0
    19e8:      	sxtw	x21, w1
    19ec:      	b	0x13f8 <_stogir.verify.integer-operations-target-structured+0x654>
    19f0:      	brk	#0
    19f4:      	b	0x19f0 <_stogir.verify.integer-operations-target-structured+0xc4c>
    19f8:      	mov	x1, #0x1                ; =1
    19fc:      	b	0x1410 <_stogir.verify.integer-operations-target-structured+0x66c>
    1a00:      	add	x1, x21, #0x1
    1a04:      	lsr	w1, w1, #0
    1a08:      	sxtw	x21, w1
    1a0c:      	b	0x1478 <_stogir.verify.integer-operations-target-structured+0x6d4>
    1a10:      	brk	#0
    1a14:      	b	0x1a10 <_stogir.verify.integer-operations-target-structured+0xc6c>
    1a18:      	mov	x1, #0x1                ; =1
    1a1c:      	b	0x1490 <_stogir.verify.integer-operations-target-structured+0x6ec>
    1a20:      	add	x1, x21, #0x1
    1a24:      	lsr	w1, w1, #0
    1a28:      	sxtw	x21, w1
    1a2c:      	b	0x14f8 <_stogir.verify.integer-operations-target-structured+0x754>
    1a30:      	brk	#0
    1a34:      	b	0x1a30 <_stogir.verify.integer-operations-target-structured+0xc8c>
    1a38:      	add	x1, x21, #0x1
    1a3c:      	lsr	w1, w1, #0
    1a40:      	sxtw	x21, w1
    1a44:      	b	0x155c <_stogir.verify.integer-operations-target-structured+0x7b8>
    1a48:      	brk	#0
    1a4c:      	b	0x1a48 <_stogir.verify.integer-operations-target-structured+0xca4>
    1a50:      	add	x16, sp, #0x20
    1a54:      	ldr	w1, [x16, #0x8]
    1a58:      	lsr	w1, w1, #0
    1a5c:      	add	x8, sp, #0x1c0
    1a60:      	str	x0, [sp, #0x258]
    1a64:      	ldr	x0, [sp, #0x298]
    1a68:      	bl	0x1a68 <_stogir.verify.integer-operations-target-structured+0xcc4>
		0000000000001a68:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1a6c:      	add	x16, sp, #0x1c0
    1a70:      	ldr	w0, [x16]
    1a74:      	lsr	x16, x0, #0
    1a78:      	cmp	x16, #0x1
    1a7c:      	b.eq	0x1a98 <_stogir.verify.integer-operations-target-structured+0xcf4>
    1a80:      	b.lo	0x1a88 <_stogir.verify.integer-operations-target-structured+0xce4>
    1a84:      	b	0x1a9c <_stogir.verify.integer-operations-target-structured+0xcf8>
    1a88:      	cmp	x16, #0x0
    1a8c:      	b.eq	0x1a94 <_stogir.verify.integer-operations-target-structured+0xcf0>
    1a90:      	b	0x1a9c <_stogir.verify.integer-operations-target-structured+0xcf8>
    1a94:      	b	0x1aa0 <_stogir.verify.integer-operations-target-structured+0xcfc>
    1a98:      	b	0x1aac <_stogir.verify.integer-operations-target-structured+0xd08>
    1a9c:      	b	0x1adc <_stogir.verify.integer-operations-target-structured+0xd38>
    1aa0:      	ldr	x19, [sp, #0x288]
    1aa4:      	mov	x22, #0x14              ; =20
    1aa8:      	b	0x1598 <_stogir.verify.integer-operations-target-structured+0x7f4>
    1aac:      	add	x16, sp, #0x1c0
    1ab0:      	ldr	x0, [x16, #0x8]
    1ab4:      	add	x16, sp, #0x20
    1ab8:      	ldr	w1, [x16]
    1abc:      	lsr	w0, w0, #0
    1ac0:      	ubfx	x1, x1, #8, #8
    1ac4:      	ubfx	x0, x0, #8, #8
    1ac8:      	cmp	x0, x1
    1acc:      	b.eq	0x1ad8 <_stogir.verify.integer-operations-target-structured+0xd34>
    1ad0:      	ldr	x19, [sp, #0x290]
    1ad4:      	mov	x22, #0x1a              ; =26
    1ad8:      	b	0x1aa8 <_stogir.verify.integer-operations-target-structured+0xd04>
    1adc:      	brk	#0
    1ae0:      	b	0x1adc <_stogir.verify.integer-operations-target-structured+0xd38>
    1ae4:      	add	x1, x21, #0x1
    1ae8:      	lsr	w1, w1, #0
    1aec:      	sxtw	x21, w1
    1af0:      	b	0x162c <_stogir.verify.integer-operations-target-structured+0x888>
    1af4:      	brk	#0
    1af8:      	b	0x1af4 <_stogir.verify.integer-operations-target-structured+0xd50>
    1afc:      	mov	x1, #0x1                ; =1
    1b00:      	b	0x163c <_stogir.verify.integer-operations-target-structured+0x898>
    1b04:      	mov	x1, #0x1                ; =1
    1b08:      	b	0x1690 <_stogir.verify.integer-operations-target-structured+0x8ec>
    1b0c:      	cmp	x26, #0x0
    1b10:      	b.eq	0x1b1c <_stogir.verify.integer-operations-target-structured+0xd78>
    1b14:      	mov	x1, #0x1                ; =1
    1b18:      	b	0x16a8 <_stogir.verify.integer-operations-target-structured+0x904>
    1b1c:      	mov	x1, x28
    1b20:      	b	0x1b18 <_stogir.verify.integer-operations-target-structured+0xd74>
    1b24:      	movz	x1, #0x0, lsl #48
    1b28:      	b	0x16a8 <_stogir.verify.integer-operations-target-structured+0x904>
    1b2c:      	movz	x1, #0x0, lsl #48
    1b30:      	b	0x16a8 <_stogir.verify.integer-operations-target-structured+0x904>
    1b34:      	lsr	w1, w1, #0
    1b38:      	sxtw	x1, w1
    1b3c:      	cmp	x1, #0x0
    1b40:      	cset	w0, gt
    1b44:      	movz	x16, #0x0, lsl #48
    1b48:      	sub	x2, x16, x1
    1b4c:      	sub	x3, x2, #0x1
    1b50:      	uxtb	w16, w0
    1b54:      	cmp	w16, wzr
    1b58:      	b.eq	0x200c <_stogir.verify.integer-operations-target-structured+0x1268>
    1b5c:      	ldr	x4, [sp, #0x298]
    1b60:      	ldr	x2, [x4, #0x8]
    1b64:      	cmp	x1, x2
    1b68:      	b.ge	0x2018 <_stogir.verify.integer-operations-target-structured+0x1274>
    1b6c:      	ldr	x5, [sp, #0x318]
    1b70:      	ldr	x2, [x5, #0x8]
    1b74:      	cmp	x1, x2
    1b78:      	b.ge	0x1bec <_stogir.verify.integer-operations-target-structured+0xe48>
    1b7c:      	ldr	x2, [x4, #0x78]
    1b80:      	add	x2, x2, x1, lsl #2
    1b84:      	ldr	w2, [x2]
    1b88:      	sxtw	x2, w2
    1b8c:      	cmp	x2, #0x0
    1b90:      	cset	w2, ge
    1b94:      	ubfx	x2, x2, #0, #8
    1b98:      	ldr	x6, [sp, #0x310]
    1b9c:      	ldr	x8, [sp, #0x308]
    1ba0:      	cmp	x2, #0x0
    1ba4:      	b.eq	0x1c68 <_stogir.verify.integer-operations-target-structured+0xec4>
    1ba8:      	uxtb	w16, w0
    1bac:      	cmp	w16, wzr
    1bb0:      	b.eq	0x1c5c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1bb4:      	ldr	x0, [x4]
    1bb8:      	add	x0, x0, x1, lsl #4
    1bbc:      	cmp	x0, #0x0
    1bc0:      	b.ne	0x1c70 <_stogir.verify.integer-operations-target-structured+0xecc>
    1bc4:      	str	x4, [sp, #0x298]
    1bc8:      	str	x23, [sp, #0x340]
    1bcc:      	str	x25, [sp, #0x348]
    1bd0:      	str	x27, [sp, #0x350]
    1bd4:      	str	x5, [sp, #0x318]
    1bd8:      	str	x6, [sp, #0x310]
    1bdc:      	str	x8, [sp, #0x308]
    1be0:      	ldr	x19, [sp, #0x2b0]
    1be4:      	mov	x22, #0x17              ; =23
    1be8:      	b	0x172c <_stogir.verify.integer-operations-target-structured+0x988>
    1bec:      	movz	x2, #0x0, lsl #48
    1bf0:      	b	0x1b98 <_stogir.verify.integer-operations-target-structured+0xdf4>
    1bf4:      	movz	x2, #0x0, lsl #48
    1bf8:      	b	0x1b98 <_stogir.verify.integer-operations-target-structured+0xdf4>
    1bfc:      	cmp	x1, #0x0
    1c00:      	b.ge	0x2020 <_stogir.verify.integer-operations-target-structured+0x127c>
    1c04:      	ldr	x6, [sp, #0x310]
    1c08:      	ldr	x7, [x6, #0x8]
    1c0c:      	ldr	x8, [sp, #0x308]
    1c10:      	ldr	x9, [x8, #0x8]
    1c14:      	cmp	x7, x9
    1c18:      	b.ne	0x1c4c <_stogir.verify.integer-operations-target-structured+0xea8>
    1c1c:      	cmp	x2, x7
    1c20:      	b.gt	0x1c44 <_stogir.verify.integer-operations-target-structured+0xea0>
    1c24:      	ldr	x2, [x4, #0x50]
    1c28:      	add	x2, x2, x3, lsl #2
    1c2c:      	ldr	w2, [x2]
    1c30:      	sxtw	x2, w2
    1c34:      	cmp	x2, #0x0
    1c38:      	cset	w2, gt
    1c3c:      	ubfx	x2, x2, #0, #8
    1c40:      	b	0x1ba0 <_stogir.verify.integer-operations-target-structured+0xdfc>
    1c44:      	movz	x2, #0x0, lsl #48
    1c48:      	b	0x1c40 <_stogir.verify.integer-operations-target-structured+0xe9c>
    1c4c:      	movz	x2, #0x0, lsl #48
    1c50:      	b	0x1c40 <_stogir.verify.integer-operations-target-structured+0xe9c>
    1c54:      	movz	x2, #0x0, lsl #48
    1c58:      	b	0x1c40 <_stogir.verify.integer-operations-target-structured+0xe9c>
    1c5c:      	ldr	x0, [x4, #0x28]
    1c60:      	add	x0, x0, x3, lsl #4
    1c64:      	b	0x1bbc <_stogir.verify.integer-operations-target-structured+0xe18>
    1c68:      	movz	x0, #0x0, lsl #48
    1c6c:      	b	0x1bbc <_stogir.verify.integer-operations-target-structured+0xe18>
    1c70:      	ldr	w0, [x0]
    1c74:      	add	x16, sp, #0x20
    1c78:      	ldr	w1, [x16]
    1c7c:      	ubfx	x0, x0, #8, #8
    1c80:      	orr	x2, x0, xzr
    1c84:      	ubfx	x1, x1, #8, #8
    1c88:      	cmp	x1, #0x6
    1c8c:      	b.ne	0x1df4 <_stogir.verify.integer-operations-target-structured+0x1050>
    1c90:      	cmp	x2, #0x6
    1c94:      	b.ne	0x1dec <_stogir.verify.integer-operations-target-structured+0x1048>
    1c98:      	cmp	x24, #0x1a
    1c9c:      	b.ne	0x1ddc <_stogir.verify.integer-operations-target-structured+0x1038>
    1ca0:      	mov	x1, #0x1                ; =1
    1ca4:      	cmp	x2, #0x1
    1ca8:      	cset	w3, ge
    1cac:      	uxtb	w16, w3
    1cb0:      	cmp	w16, wzr
    1cb4:      	b.eq	0x202c <_stogir.verify.integer-operations-target-structured+0x1288>
    1cb8:      	cmp	x2, #0xb
    1cbc:      	cset	w7, le
    1cc0:      	uxtb	w16, w7
    1cc4:      	cmp	w16, wzr
    1cc8:      	b.eq	0x2054 <_stogir.verify.integer-operations-target-structured+0x12b0>
    1ccc:      	cmp	x28, #0x0
    1cd0:      	b.eq	0x207c <_stogir.verify.integer-operations-target-structured+0x12d8>
    1cd4:      	ldr	w9, [sp, #0x300]
    1cd8:      	lsr	w9, w9, #0
    1cdc:      	lsr	w0, w0, #0
    1ce0:      	str	x4, [sp, #0x298]
    1ce4:      	str	x5, [sp, #0x318]
    1ce8:      	str	x6, [sp, #0x310]
    1cec:      	str	x8, [sp, #0x308]
    1cf0:      	mov	w28, w7
    1cf4:      	str	x23, [sp, #0x340]
    1cf8:      	mov	x23, x2
    1cfc:      	str	x25, [sp, #0x348]
    1d00:      	mov	x25, x1
    1d04:      	mov	w1, w0
    1d08:      	mov	w0, w9
    1d0c:      	str	x27, [sp, #0x350]
    1d10:      	mov	w27, w3
    1d14:      	bl	0x1d14 <_stogir.verify.integer-operations-target-structured+0xf70>
		0000000000001d14:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1d18:      	cmp	x0, #0x0
    1d1c:      	b.ne	0x1dfc <_stogir.verify.integer-operations-target-structured+0x1058>
    1d20:      	ldr	x19, [sp, #0x2b8]
    1d24:      	mov	x22, #0x1c              ; =28
    1d28:      	add	x16, sp, #0x20
    1d2c:      	ldr	w0, [x16]
    1d30:      	cmp	x20, #0x0
    1d34:      	b.eq	0x1e94 <_stogir.verify.integer-operations-target-structured+0x10f0>
    1d38:      	mov	x1, #0x1                ; =1
    1d3c:      	lsr	w1, w1, #0
    1d40:      	ubfx	x0, x0, #8, #8
    1d44:      	sxtw	x1, w1
    1d48:      	cmp	x0, x1
    1d4c:      	b.eq	0x1d58 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1d50:      	ldr	x19, [sp, #0x2c8]
    1d54:      	mov	x22, #0x26              ; =38
    1d58:      	cmp	x20, #0x0
    1d5c:      	b.eq	0x1d64 <_stogir.verify.integer-operations-target-structured+0xfc0>
    1d60:      	mov	x26, #0x1               ; =1
    1d64:      	cmp	x26, #0x0
    1d68:      	b.eq	0x1dd8 <_stogir.verify.integer-operations-target-structured+0x1034>
    1d6c:      	add	x16, sp, #0x220
    1d70:      	str	x16, [sp]
    1d74:      	ldr	x0, [sp, #0x298]
    1d78:      	ldr	w1, [sp, #0x2a8]
    1d7c:      	mov	x2, #0x2                ; =2
    1d80:      	bl	0x1d80 <_stogir.verify.integer-operations-target-structured+0xfdc>
		0000000000001d80:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1d84:      	ldr	x16, [sp]
    1d88:      	str	x0, [x16]
    1d8c:      	str	x1, [x16, #0x8]
    1d90:      	add	x16, sp, #0x220
    1d94:      	ldr	x0, [x16]
    1d98:      	add	x16, sp, #0x220
    1d9c:      	ldr	x1, [x16, #0x8]
    1da0:      	lsr	w0, w0, #0
    1da4:      	lsr	x16, x0, #0
    1da8:      	cmp	x16, #0x1
    1dac:      	b.eq	0x1dc8 <_stogir.verify.integer-operations-target-structured+0x1024>
    1db0:      	b.lo	0x1db8 <_stogir.verify.integer-operations-target-structured+0x1014>
    1db4:      	b	0x1dcc <_stogir.verify.integer-operations-target-structured+0x1028>
    1db8:      	cmp	x16, #0x0
    1dbc:      	b.eq	0x1dc4 <_stogir.verify.integer-operations-target-structured+0x1020>
    1dc0:      	b	0x1dcc <_stogir.verify.integer-operations-target-structured+0x1028>
    1dc4:      	b	0x1dd0 <_stogir.verify.integer-operations-target-structured+0x102c>
    1dc8:      	b	0x1e9c <_stogir.verify.integer-operations-target-structured+0x10f8>
    1dcc:      	b	0x1ef8 <_stogir.verify.integer-operations-target-structured+0x1154>
    1dd0:      	ldr	x19, [sp, #0x2d0]
    1dd4:      	mov	x22, #0x1d              ; =29
    1dd8:      	b	0x1be8 <_stogir.verify.integer-operations-target-structured+0xe44>
    1ddc:      	cmp	x24, #0x1b
    1de0:      	cset	w1, eq
    1de4:      	ubfx	x1, x1, #0, #8
    1de8:      	b	0x1ca4 <_stogir.verify.integer-operations-target-structured+0xf00>
    1dec:      	movz	x1, #0x0, lsl #48
    1df0:      	b	0x1ca4 <_stogir.verify.integer-operations-target-structured+0xf00>
    1df4:      	movz	x1, #0x0, lsl #48
    1df8:      	b	0x1ca4 <_stogir.verify.integer-operations-target-structured+0xf00>
    1dfc:      	cmp	x26, #0x0
    1e00:      	b.eq	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf84>
    1e04:      	cmp	x24, #0x3a
    1e08:      	cset	w0, eq
    1e0c:      	cmp	x24, #0x1a
    1e10:      	b.lt	0x1e6c <_stogir.verify.integer-operations-target-structured+0x10c8>
    1e14:      	cmp	x24, #0x1e
    1e18:      	b.gt	0x1e6c <_stogir.verify.integer-operations-target-structured+0x10c8>
    1e1c:      	uxtb	w16, w27
    1e20:      	cmp	w16, wzr
    1e24:      	b.eq	0x1d20 <_stogir.verify.integer-operations-target-structured+0xf7c>
    1e28:      	uxtb	w16, w28
    1e2c:      	cmp	w16, wzr
    1e30:      	b.eq	0x1d20 <_stogir.verify.integer-operations-target-structured+0xf7c>
    1e34:      	cmp	x23, #0x1
    1e38:      	b.ne	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf84>
    1e3c:      	cmp	x24, #0x2e
    1e40:      	b.eq	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf84>
    1e44:      	cmp	x24, #0x2f
    1e48:      	b.eq	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf84>
    1e4c:      	cmp	x24, #0x30
    1e50:      	b.eq	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf84>
    1e54:      	uxtb	w16, w0
    1e58:      	cmp	w16, wzr
    1e5c:      	b.ne	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf84>
    1e60:      	cmp	x24, #0x3b
    1e64:      	b.ne	0x1d20 <_stogir.verify.integer-operations-target-structured+0xf7c>
    1e68:      	b	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf84>
    1e6c:      	cmp	x24, #0x2e
    1e70:      	b.lt	0x1e7c <_stogir.verify.integer-operations-target-structured+0x10d8>
    1e74:      	cmp	x24, #0x35
    1e78:      	b.le	0x1e1c <_stogir.verify.integer-operations-target-structured+0x1078>
    1e7c:      	uxtb	w16, w0
    1e80:      	cmp	w16, wzr
    1e84:      	b.ne	0x1e1c <_stogir.verify.integer-operations-target-structured+0x1078>
    1e88:      	cmp	x24, #0x3b
    1e8c:      	b.eq	0x1e1c <_stogir.verify.integer-operations-target-structured+0x1078>
    1e90:      	b	0x1d20 <_stogir.verify.integer-operations-target-structured+0xf7c>
    1e94:      	mov	x1, x23
    1e98:      	b	0x1d3c <_stogir.verify.integer-operations-target-structured+0xf98>
    1e9c:      	lsr	w1, w1, #0
    1ea0:      	lsr	w1, w1, #0
    1ea4:      	ldr	x0, [sp, #0x298]
    1ea8:      	bl	0x1ea8 <_stogir.verify.integer-operations-target-structured+0x1104>
		0000000000001ea8:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1eac:      	cmp	x0, #0x0
    1eb0:      	b.ne	0x1ec0 <_stogir.verify.integer-operations-target-structured+0x111c>
    1eb4:      	ldr	x19, [sp, #0x2d0]
    1eb8:      	mov	x22, #0x1d              ; =29
    1ebc:      	b	0x1dd8 <_stogir.verify.integer-operations-target-structured+0x1034>
    1ec0:      	ldr	w0, [x0]
    1ec4:      	ubfx	x0, x0, #8, #8
    1ec8:      	cmp	x23, x0
    1ecc:      	b.eq	0x1ee8 <_stogir.verify.integer-operations-target-structured+0x1144>
    1ed0:      	cmp	x25, #0x0
    1ed4:      	b.eq	0x1eec <_stogir.verify.integer-operations-target-structured+0x1148>
    1ed8:      	cmp	x0, #0x5
    1edc:      	b.eq	0x1ee8 <_stogir.verify.integer-operations-target-structured+0x1144>
    1ee0:      	cmp	x0, #0xb
    1ee4:      	b.ne	0x1eec <_stogir.verify.integer-operations-target-structured+0x1148>
    1ee8:      	b	0x1ebc <_stogir.verify.integer-operations-target-structured+0x1118>
    1eec:      	ldr	x19, [sp, #0x280]
    1ef0:      	mov	x22, #0x1d              ; =29
    1ef4:      	b	0x1ee8 <_stogir.verify.integer-operations-target-structured+0x1144>
    1ef8:      	brk	#0
    1efc:      	b	0x1ef8 <_stogir.verify.integer-operations-target-structured+0x1154>
    1f00:      	brk	#0
    1f04:      	b	0x1f00 <_stogir.verify.integer-operations-target-structured+0x115c>
    1f08:      	brk	#0
    1f0c:      	b	0x1f08 <_stogir.verify.integer-operations-target-structured+0x1164>
    1f10:      	cmp	x22, #0x0
    1f14:      	b.ne	0x1f6c <_stogir.verify.integer-operations-target-structured+0x11c8>
    1f18:      	and	x19, x21, #0xffffffff
    1f1c:      	movz	x0, #0x0, lsl #48
    1f20:      	movz	x22, #0x0, lsl #48
    1f24:      	ldr	x1, [sp, #0x2d8]
    1f28:      	str	x0, [x1]
    1f2c:      	str	x19, [x1, #0x8]
    1f30:      	str	x22, [x1, #0x10]
    1f34:      	ldr	x19, [sp, #0x358]
    1f38:      	ldr	x20, [sp, #0x360]
    1f3c:      	ldr	x21, [sp, #0x368]
    1f40:      	ldr	x22, [sp, #0x370]
    1f44:      	ldr	x23, [sp, #0x378]
    1f48:      	ldr	x24, [sp, #0x380]
    1f4c:      	ldr	x25, [sp, #0x388]
    1f50:      	ldr	x26, [sp, #0x390]
    1f54:      	ldr	x27, [sp, #0x398]
    1f58:      	ldr	x28, [sp, #0x3a0]
    1f5c:      	ldr	x29, [sp, #0x10]
    1f60:      	ldr	x30, [sp, #0x18]
    1f64:      	add	sp, sp, #0x3b0
    1f68:      	ret
    1f6c:      	mov	x0, #0x1                ; =1
    1f70:      	b	0x1f24 <_stogir.verify.integer-operations-target-structured+0x1180>
    1f74:      	str	x8, [sp, #0x2d8]
    1f78:      	b	0x1f10 <_stogir.verify.integer-operations-target-structured+0x116c>
    1f7c:      	str	x8, [sp, #0x2d8]
    1f80:      	b	0x1f10 <_stogir.verify.integer-operations-target-structured+0x116c>
    1f84:      	str	x0, [sp, #0x298]
    1f88:      	b	0x17c4 <_stogir.verify.integer-operations-target-structured+0xa20>
    1f8c:      	ldr	x0, [sp, #0x328]
    1f90:      	b	0x1300 <_stogir.verify.integer-operations-target-structured+0x55c>
    1f94:      	str	x0, [sp, #0x328]
    1f98:      	ldr	x0, [sp, #0x238]
    1f9c:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x5d8>
    1fa0:      	str	x0, [sp, #0x238]
    1fa4:      	ldr	x0, [sp, #0x240]
    1fa8:      	b	0x13f8 <_stogir.verify.integer-operations-target-structured+0x654>
    1fac:      	str	x0, [sp, #0x240]
    1fb0:      	ldr	x0, [sp, #0x248]
    1fb4:      	b	0x1478 <_stogir.verify.integer-operations-target-structured+0x6d4>
    1fb8:      	str	x0, [sp, #0x248]
    1fbc:      	ldr	x0, [sp, #0x250]
    1fc0:      	b	0x14f8 <_stogir.verify.integer-operations-target-structured+0x754>
    1fc4:      	str	x0, [sp, #0x250]
    1fc8:      	ldr	x0, [sp, #0x258]
    1fcc:      	b	0x155c <_stogir.verify.integer-operations-target-structured+0x7b8>
    1fd0:      	str	x0, [sp, #0x258]
    1fd4:      	b	0x15a4 <_stogir.verify.integer-operations-target-structured+0x800>
    1fd8:      	str	x20, [sp, #0x338]
    1fdc:      	mov	x20, x0
    1fe0:      	ldr	x0, [sp, #0x278]
    1fe4:      	b	0x162c <_stogir.verify.integer-operations-target-structured+0x888>
    1fe8:      	ldr	x20, [sp, #0x2a0]
    1fec:      	b	0x1b2c <_stogir.verify.integer-operations-target-structured+0xd88>
    1ff0:      	ldr	x20, [sp, #0x2a0]
    1ff4:      	b	0x1b24 <_stogir.verify.integer-operations-target-structured+0xd80>
    1ff8:      	str	x23, [sp, #0x340]
    1ffc:      	str	x25, [sp, #0x348]
    2000:      	str	x0, [sp, #0x278]
    2004:      	str	x27, [sp, #0x350]
    2008:      	b	0x1738 <_stogir.verify.integer-operations-target-structured+0x994>
    200c:      	ldr	x4, [sp, #0x298]
    2010:      	ldr	x5, [sp, #0x318]
    2014:      	b	0x1bfc <_stogir.verify.integer-operations-target-structured+0xe58>
    2018:      	ldr	x5, [sp, #0x318]
    201c:      	b	0x1bf4 <_stogir.verify.integer-operations-target-structured+0xe50>
    2020:      	ldr	x6, [sp, #0x310]
    2024:      	ldr	x8, [sp, #0x308]
    2028:      	b	0x1c54 <_stogir.verify.integer-operations-target-structured+0xeb0>
    202c:      	str	x4, [sp, #0x298]
    2030:      	str	x23, [sp, #0x340]
    2034:      	str	x25, [sp, #0x348]
    2038:      	mov	x25, x1
    203c:      	mov	x23, x2
    2040:      	str	x27, [sp, #0x350]
    2044:      	str	x5, [sp, #0x318]
    2048:      	str	x6, [sp, #0x310]
    204c:      	str	x8, [sp, #0x308]
    2050:      	b	0x1d20 <_stogir.verify.integer-operations-target-structured+0xf7c>
    2054:      	str	x4, [sp, #0x298]
    2058:      	str	x23, [sp, #0x340]
    205c:      	str	x25, [sp, #0x348]
    2060:      	mov	x25, x1
    2064:      	mov	x23, x2
    2068:      	str	x27, [sp, #0x350]
    206c:      	str	x5, [sp, #0x318]
    2070:      	str	x6, [sp, #0x310]
    2074:      	str	x8, [sp, #0x308]
    2078:      	b	0x1d20 <_stogir.verify.integer-operations-target-structured+0xf7c>
    207c:      	str	x4, [sp, #0x298]
    2080:      	str	x23, [sp, #0x340]
    2084:      	str	x25, [sp, #0x348]
    2088:      	mov	x25, x1
    208c:      	mov	x23, x2
    2090:      	mov	w28, w7
    2094:      	str	x27, [sp, #0x350]
    2098:      	mov	w27, w3
    209c:      	str	x5, [sp, #0x318]
    20a0:      	str	x6, [sp, #0x310]
    20a4:      	str	x8, [sp, #0x308]
    20a8:      	b	0x1dfc <_stogir.verify.integer-operations-target-structured+0x1058>

00000000000020ac <_stogir.types.valid?>:
    20ac:      	sxtw	x0, w0
    20b0:      	cmp	x0, #0x0
    20b4:      	b.lt	0x20c8 <_stogir.types.valid?+0x1c>
    20b8:      	cmp	x0, #0xd
    20bc:      	b.gt	0x20c8 <_stogir.types.valid?+0x1c>
    20c0:      	mov	x0, #0x1                ; =1
    20c4:      	b	0x2108 <_stogir.types.valid?+0x5c>
    20c8:      	cmp	x0, #0xf
    20cc:      	b.le	0x2104 <_stogir.types.valid?+0x58>
    20d0:      	cmp	x0, #0x80
    20d4:      	b.ge	0x20fc <_stogir.types.valid?+0x50>
    20d8:      	and	x0, x0, #0xf
    20dc:      	lsr	w0, w0, #0
    20e0:      	sxtw	x0, w0
    20e4:      	cmp	x0, #0x1
    20e8:      	b.lt	0x210c <_stogir.types.valid?+0x60>
    20ec:      	cmp	x0, #0xd
    20f0:      	cset	w0, le
    20f4:      	ubfx	x0, x0, #0, #8
    20f8:      	b	0x2110 <_stogir.types.valid?+0x64>
    20fc:      	movz	x0, #0x0, lsl #48
    2100:      	b	0x2108 <_stogir.types.valid?+0x5c>
    2104:      	movz	x0, #0x0, lsl #48
    2108:      	ret
    210c:      	movz	x0, #0x0, lsl #48
    2110:      	b	0x2100 <_stogir.types.valid?+0x54>

0000000000002114 <_stogir.opcode.operand-slots>:
    2114:      	sxtw	x0, w0
    2118:      	cmp	x0, #0x0
    211c:      	b.lt	0x2144 <_stogir.opcode.operand-slots+0x30>
    2120:      	cmp	x0, #0x83
    2124:      	b.ge	0x2144 <_stogir.opcode.operand-slots+0x30>
    2128:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002128:  ARM64_RELOC_PAGE21	l_stogir.344
    212c:      	ldr	x16, [x16]
		000000000000212c:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    2130:      	orr	x1, x16, xzr
    2134:      	add	x0, x1, x0
    2138:      	ldrsb	w0, [x0]
    213c:      	sxtb	x0, w0
    2140:      	b	0x2148 <_stogir.opcode.operand-slots+0x34>
    2144:      	mov	x0, #-0x2               ; =-2
    2148:      	ret

000000000000214c <_stogir.opcode.input-count>:
    214c:      	sxtw	x0, w0
    2150:      	cmp	x0, #0x0
    2154:      	b.lt	0x217c <_stogir.opcode.input-count+0x30>
    2158:      	cmp	x0, #0x83
    215c:      	b.ge	0x217c <_stogir.opcode.input-count+0x30>
    2160:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002160:  ARM64_RELOC_PAGE21	l_stogir.345
    2164:      	ldr	x16, [x16]
		0000000000002164:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    2168:      	orr	x1, x16, xzr
    216c:      	add	x0, x1, x0
    2170:      	ldrsb	w0, [x0]
    2174:      	sxtb	x0, w0
    2178:      	b	0x2180 <_stogir.opcode.input-count+0x34>
    217c:      	mov	x0, #-0x2               ; =-2
    2180:      	ret

0000000000002184 <_stogir.graph.operand>:
    2184:      	sub	sp, sp, #0x10
    2188:      	mov	x3, sp
    218c:      	sxtw	x1, w1
    2190:      	cmp	x1, #0x0
    2194:      	b.le	0x21d8 <_stogir.graph.operand+0x54>
    2198:      	lsl	x4, x1, #2
    219c:      	ldr	x5, [x0, #0x8]
    21a0:      	cmp	x1, x5
    21a4:      	b.ge	0x220c <_stogir.graph.operand+0x88>
    21a8:      	add	x5, x0, #0x78
    21ac:      	ldr	x5, [x5, #0x8]
    21b0:      	cmp	x1, x5
    21b4:      	b.ge	0x2204 <_stogir.graph.operand+0x80>
    21b8:      	ldr	x5, [x0, #0x78]
    21bc:      	add	x5, x4, x5
    21c0:      	ldr	w5, [x5]
    21c4:      	sxtw	x5, w5
    21c8:      	cmp	x5, #0x0
    21cc:      	cset	w5, ge
    21d0:      	ubfx	x5, x5, #0, #8
    21d4:      	b	0x2208 <_stogir.graph.operand+0x84>
    21d8:      	movz	x1, #0x0, lsl #48
    21dc:      	movz	x0, #0x0, lsl #48
    21e0:      	str	x1, [x3]
    21e4:      	str	x0, [x3, #0x8]
    21e8:      	ldr	x0, [sp]
    21ec:      	ldr	x1, [sp, #0x8]
    21f0:      	add	sp, sp, #0x10
    21f4:      	ret
    21f8:      	movz	x1, #0x0, lsl #48
    21fc:      	movz	x0, #0x0, lsl #48
    2200:      	b	0x21e0 <_stogir.graph.operand+0x5c>
    2204:      	movz	x5, #0x0, lsl #48
    2208:      	b	0x2210 <_stogir.graph.operand+0x8c>
    220c:      	movz	x5, #0x0, lsl #48
    2210:      	cmp	x5, #0x0
    2214:      	b.eq	0x21d8 <_stogir.graph.operand+0x54>
    2218:      	sxtw	x2, w2
    221c:      	cmp	x2, #0x1
    2220:      	b.lt	0x21f8 <_stogir.graph.operand+0x74>
    2224:      	ldr	x5, [x0, #0x78]
    2228:      	add	x4, x4, x5
    222c:      	ldr	w4, [x4]
    2230:      	sxtw	x4, w4
    2234:      	cmp	x2, x4
    2238:      	b.gt	0x21f8 <_stogir.graph.operand+0x74>
    223c:      	asr	x16, x2, #63
    2240:      	lsr	x16, x16, #62
    2244:      	add	x4, x2, x16
    2248:      	asr	x4, x4, #2
    224c:      	asr	x16, x2, #63
    2250:      	lsr	x16, x16, #62
    2254:      	add	x2, x2, x16
    2258:      	and	x2, x2, #0x3
    225c:      	sub	x2, x2, x16
    2260:      	ldr	x0, [x0]
    2264:      	add	x1, x4, x1
    2268:      	add	x0, x0, x1, lsl #4
    226c:      	add	x0, x0, x2, lsl #2
    2270:      	ldr	w0, [x0]
    2274:      	sxtw	x0, w0
    2278:      	and	x0, x0, #0xffffffff
    227c:      	mov	x1, #0x1                ; =1
    2280:      	b	0x2200 <_stogir.graph.operand+0x7c>

0000000000002284 <_stogir.graph.borrow-node>:
    2284:      	sxtw	x1, w1
    2288:      	cmp	x1, #0x0
    228c:      	cset	w2, gt
    2290:      	movz	x16, #0x0, lsl #48
    2294:      	sub	x3, x16, x1
    2298:      	sub	x4, x3, #0x1
    229c:      	uxtb	w16, w2
    22a0:      	cmp	w16, wzr
    22a4:      	b.eq	0x22e4 <_stogir.graph.borrow-node+0x60>
    22a8:      	ldr	x3, [x0, #0x8]
    22ac:      	cmp	x1, x3
    22b0:      	b.ge	0x2334 <_stogir.graph.borrow-node+0xb0>
    22b4:      	add	x3, x0, #0x78
    22b8:      	ldr	x3, [x3, #0x8]
    22bc:      	cmp	x1, x3
    22c0:      	b.ge	0x2374 <_stogir.graph.borrow-node+0xf0>
    22c4:      	ldr	x3, [x0, #0x78]
    22c8:      	add	x3, x3, x1, lsl #2
    22cc:      	ldr	w3, [x3]
    22d0:      	sxtw	x3, w3
    22d4:      	cmp	x3, #0x0
    22d8:      	cset	w3, ge
    22dc:      	ubfx	x3, x3, #0, #8
    22e0:      	b	0x2378 <_stogir.graph.borrow-node+0xf4>
    22e4:      	cmp	x1, #0x0
    22e8:      	b.ge	0x233c <_stogir.graph.borrow-node+0xb8>
    22ec:      	add	x5, x0, #0x28
    22f0:      	add	x6, x0, #0x50
    22f4:      	ldr	x5, [x5, #0x8]
    22f8:      	ldr	x6, [x6, #0x8]
    22fc:      	cmp	x5, x6
    2300:      	b.ne	0x232c <_stogir.graph.borrow-node+0xa8>
    2304:      	cmp	x3, x5
    2308:      	b.gt	0x237c <_stogir.graph.borrow-node+0xf8>
    230c:      	ldr	x3, [x0, #0x50]
    2310:      	add	x3, x3, x4, lsl #2
    2314:      	ldr	w3, [x3]
    2318:      	sxtw	x3, w3
    231c:      	cmp	x3, #0x0
    2320:      	cset	w3, gt
    2324:      	ubfx	x3, x3, #0, #8
    2328:      	b	0x2380 <_stogir.graph.borrow-node+0xfc>
    232c:      	movz	x3, #0x0, lsl #48
    2330:      	b	0x2340 <_stogir.graph.borrow-node+0xbc>
    2334:      	movz	x3, #0x0, lsl #48
    2338:      	b	0x2340 <_stogir.graph.borrow-node+0xbc>
    233c:      	movz	x3, #0x0, lsl #48
    2340:      	cmp	x3, #0x0
    2344:      	b.eq	0x236c <_stogir.graph.borrow-node+0xe8>
    2348:      	uxtb	w16, w2
    234c:      	cmp	w16, wzr
    2350:      	b.eq	0x2360 <_stogir.graph.borrow-node+0xdc>
    2354:      	ldr	x0, [x0]
    2358:      	add	x0, x0, x1, lsl #4
    235c:      	b	0x2368 <_stogir.graph.borrow-node+0xe4>
    2360:      	ldr	x0, [x0, #0x28]
    2364:      	add	x0, x0, x4, lsl #4
    2368:      	b	0x2370 <_stogir.graph.borrow-node+0xec>
    236c:      	movz	x0, #0x0, lsl #48
    2370:      	ret
    2374:      	movz	x3, #0x0, lsl #48
    2378:      	b	0x2338 <_stogir.graph.borrow-node+0xb4>
    237c:      	movz	x3, #0x0, lsl #48
    2380:      	b	0x2330 <_stogir.graph.borrow-node+0xac>

0000000000002384 <_stogir.verify.classifications>:
    2384:      	sub	sp, sp, #0x70
    2388:      	str	x29, [sp]
    238c:      	str	x30, [sp, #0x8]
    2390:      	mov	x29, sp
    2394:      	str	x19, [sp, #0x20]
    2398:      	str	x20, [sp, #0x28]
    239c:      	str	x21, [sp, #0x30]
    23a0:      	str	x22, [sp, #0x38]
    23a4:      	str	x23, [sp, #0x40]
    23a8:      	str	x24, [sp, #0x48]
    23ac:      	str	x25, [sp, #0x50]
    23b0:      	str	x26, [sp, #0x58]
    23b4:      	str	x27, [sp, #0x60]
    23b8:      	str	x28, [sp, #0x68]
    23bc:      	ldr	w4, [x2]
    23c0:      	uxtb	w19, w4
    23c4:      	orr	x5, x19, xzr
    23c8:      	lsr	w20, w5, #0
    23cc:      	ubfx	x21, x4, #8, #8
    23d0:      	orr	x4, x21, xzr
    23d4:      	lsr	w4, w4, #0
    23d8:      	mov	x22, x0
    23dc:      	mov	w0, w4
    23e0:      	mov	w23, w1
    23e4:      	mov	x24, x2
    23e8:      	mov	w25, w3
    23ec:      	bl	0x23ec <_stogir.verify.classifications+0x68>
		00000000000023ec:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    23f0:      	fmov	d31, x0
    23f4:      	mov	w0, w20
    23f8:      	fmov	x20, d31
    23fc:      	bl	0x23fc <_stogir.verify.classifications+0x78>
		00000000000023fc:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2400:      	cmp	x0, #0x0
    2404:      	b.eq	0x2420 <_stogir.verify.classifications+0x9c>
    2408:      	cmp	x20, #0x0
    240c:      	cset	w0, ne
    2410:      	uxtb	w16, w0
    2414:      	cmp	w16, wzr
    2418:      	cset	x26, eq
    241c:      	b	0x2424 <_stogir.verify.classifications+0xa0>
    2420:      	movz	x26, #0x0, lsl #48
    2424:      	cmp	x26, #0x0
    2428:      	cset	w27, ne
    242c:      	uxtb	w16, w27
    2430:      	cmp	w16, wzr
    2434:      	b.eq	0x2468 <_stogir.verify.classifications+0xe4>
    2438:      	ldr	w0, [x24, #0x4]
    243c:      	lsr	w0, w0, #0
    2440:      	mov	w1, w0
    2444:      	mov	x0, x22
    2448:      	bl	0x2448 <_stogir.verify.classifications+0xc4>
		0000000000002448:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    244c:      	cmp	x0, #0x0
    2450:      	b.ne	0x245c <_stogir.verify.classifications+0xd8>
    2454:      	movn	x0, #0x0, lsl #48
    2458:      	b	0x2464 <_stogir.verify.classifications+0xe0>
    245c:      	ldr	w0, [x0]
    2460:      	ubfx	x0, x0, #8, #8
    2464:      	b	0x246c <_stogir.verify.classifications+0xe8>
    2468:      	movn	x0, #0x0, lsl #48
    246c:      	lsr	w0, w0, #0
    2470:      	sxtw	x28, w0
    2474:      	cmp	x26, #0x0
    2478:      	b.eq	0x24a8 <_stogir.verify.classifications+0x124>
    247c:      	bl	0x247c <_stogir.verify.classifications+0xf8>
		000000000000247c:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2480:      	cmp	x0, #0x0
    2484:      	b.eq	0x28d8 <_stogir.verify.classifications+0x554>
    2488:      	movz	x0, #0x0, lsl #48
    248c:      	b	0x2494 <_stogir.verify.classifications+0x110>
    2490:      	mov	x0, #0x1                ; =1
    2494:      	b	0x24ac <_stogir.verify.classifications+0x128>
    2498:      	movz	x19, #0x0, lsl #48
    249c:      	b	0x252c <_stogir.verify.classifications+0x1a8>
    24a0:      	movz	x20, #0x0, lsl #48
    24a4:      	b	0x2534 <_stogir.verify.classifications+0x1b0>
    24a8:      	movz	x0, #0x0, lsl #48
    24ac:      	sxtw	x25, w25
    24b0:      	cmp	x28, #0xf
    24b4:      	cset	w1, gt
    24b8:      	cmp	x28, #0x80
    24bc:      	cset	w2, lt
    24c0:      	and	x3, x28, #0xf
    24c4:      	cmp	x19, #0x83
    24c8:      	cset	w4, lt
    24cc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		00000000000024cc:  ARM64_RELOC_PAGE21	l_stogir.346
    24d0:      	ldr	x16, [x16]
		00000000000024d0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    24d4:      	orr	x5, x16, xzr
    24d8:      	add	x6, x22, #0x78
    24dc:      	add	x7, x22, #0x28
    24e0:      	add	x8, x22, #0x50
    24e4:      	sxtw	x23, w23
    24e8:      	add	x9, x22, #0x78
    24ec:      	lsr	w3, w3, #0
    24f0:      	add	x5, x5, x19, lsl #2
    24f4:      	cmp	x23, #0x0
    24f8:      	cset	w10, le
    24fc:      	lsl	x11, x23, #2
    2500:      	sxtw	x3, w3
    2504:      	cmp	x3, #0x1
    2508:      	cset	w12, ge
    250c:      	cmp	x3, #0xd
    2510:      	cset	w3, le
    2514:      	ubfx	x3, x3, #0, #8
    2518:      	mov	x13, #0x1               ; =1
    251c:      	b	0x25ec <_stogir.verify.classifications+0x268>
    2520:      	movz	x19, #0x0, lsl #48
    2524:      	b	0x2568 <_stogir.verify.classifications+0x1e4>
    2528:      	movz	x19, #0x0, lsl #48
    252c:      	b	0x2570 <_stogir.verify.classifications+0x1ec>
    2530:      	movz	x20, #0x0, lsl #48
    2534:      	b	0x25e0 <_stogir.verify.classifications+0x25c>
    2538:      	sub	x19, x14, #0x1
    253c:      	lsr	w19, w19, #0
    2540:      	sxtw	x19, w19
    2544:      	lsl	x19, x19, #2
    2548:      	lsr	w19, w19, #0
    254c:      	ubfx	x19, x19, #0, #32
    2550:      	lsr	x15, x15, x19
    2554:      	lsr	w15, w15, #0
    2558:      	and	x15, x15, #0xf
    255c:      	lsr	w15, w15, #0
    2560:      	b	0x2630 <_stogir.verify.classifications+0x2ac>
    2564:      	movz	x19, #0x0, lsl #48
    2568:      	b	0x2570 <_stogir.verify.classifications+0x1ec>
    256c:      	movz	x19, #0x0, lsl #48
    2570:      	cmp	x19, #0x0
    2574:      	b.eq	0x259c <_stogir.verify.classifications+0x218>
    2578:      	uxtb	w16, w15
    257c:      	cmp	w16, wzr
    2580:      	b.eq	0x2590 <_stogir.verify.classifications+0x20c>
    2584:      	ldr	x15, [x22]
    2588:      	add	x14, x15, x14, lsl #4
    258c:      	b	0x2598 <_stogir.verify.classifications+0x214>
    2590:      	ldr	x14, [x22, #0x28]
    2594:      	add	x14, x14, x21, lsl #4
    2598:      	b	0x25a0 <_stogir.verify.classifications+0x21c>
    259c:      	movz	x14, #0x0, lsl #48
    25a0:      	cmp	x14, #0x0
    25a4:      	b.eq	0x25e0 <_stogir.verify.classifications+0x25c>
    25a8:      	ldr	w14, [x14]
    25ac:      	ubfx	x14, x14, #8, #8
    25b0:      	cmp	x14, #0xf
    25b4:      	b.le	0x25e0 <_stogir.verify.classifications+0x25c>
    25b8:      	cmp	x14, #0x80
    25bc:      	b.ge	0x25e0 <_stogir.verify.classifications+0x25c>
    25c0:      	and	x14, x14, #0xf
    25c4:      	lsr	w14, w14, #0
    25c8:      	sxtw	x14, w14
    25cc:      	cmp	x14, #0x1
    25d0:      	b.lt	0x25e0 <_stogir.verify.classifications+0x25c>
    25d4:      	cmp	x14, #0xd
    25d8:      	b.gt	0x25e0 <_stogir.verify.classifications+0x25c>
    25dc:      	mov	x20, #0x1               ; =1
    25e0:      	add	x13, x13, #0x1
    25e4:      	lsr	w13, w13, #0
    25e8:      	sxtw	x13, w13
    25ec:      	cmp	x20, #0x0
    25f0:      	b.ne	0x277c <_stogir.verify.classifications+0x3f8>
    25f4:      	cmp	x13, x25
    25f8:      	b.gt	0x277c <_stogir.verify.classifications+0x3f8>
    25fc:      	lsr	w14, w13, #0
    2600:      	sxtw	x14, w14
    2604:      	uxtb	w16, w4
    2608:      	cmp	w16, wzr
    260c:      	b.eq	0x2634 <_stogir.verify.classifications+0x2b0>
    2610:      	ldr	w15, [x5]
    2614:      	cmp	x14, #0x0
    2618:      	b.le	0x262c <_stogir.verify.classifications+0x2a8>
    261c:      	cmp	x14, #0x4
    2620:      	b.le	0x2538 <_stogir.verify.classifications+0x1b4>
    2624:      	mov	x19, #0x4               ; =4
    2628:      	b	0x2544 <_stogir.verify.classifications+0x1c0>
    262c:      	movz	x15, #0x0, lsl #48
    2630:      	b	0x2638 <_stogir.verify.classifications+0x2b4>
    2634:      	movz	x15, #0x0, lsl #48
    2638:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002638:  ARM64_RELOC_PAGE21	l_stogir.347
    263c:      	ldr	x16, [x16]
		000000000000263c:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    2640:      	ldr	w19, [x16]
    2644:      	lsr	w15, w15, #0
    2648:      	cmp	x15, x19
    264c:      	b.eq	0x2664 <_stogir.verify.classifications+0x2e0>
    2650:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002650:  ARM64_RELOC_PAGE21	l_stogir.348
    2654:      	ldr	x16, [x16]
		0000000000002654:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    2658:      	ldr	w19, [x16]
    265c:      	cmp	x15, x19
    2660:      	b.ne	0x25e0 <_stogir.verify.classifications+0x25c>
    2664:      	cmp	x13, #0x1
    2668:      	b.ne	0x26a4 <_stogir.verify.classifications+0x320>
    266c:      	uxtb	w16, w27
    2670:      	cmp	w16, wzr
    2674:      	b.eq	0x26a4 <_stogir.verify.classifications+0x320>
    2678:      	uxtb	w16, w1
    267c:      	cmp	w16, wzr
    2680:      	b.eq	0x2530 <_stogir.verify.classifications+0x1ac>
    2684:      	uxtb	w16, w2
    2688:      	cmp	w16, wzr
    268c:      	b.eq	0x24a0 <_stogir.verify.classifications+0x11c>
    2690:      	uxtb	w16, w12
    2694:      	cmp	w16, wzr
    2698:      	b.eq	0x2884 <_stogir.verify.classifications+0x500>
    269c:      	mov	x20, x3
    26a0:      	b	0x2888 <_stogir.verify.classifications+0x504>
    26a4:      	cmp	x13, #0x1
    26a8:      	b.ne	0x2714 <_stogir.verify.classifications+0x390>
    26ac:      	ldr	w14, [x24, #0x4]
    26b0:      	sxtw	x14, w14
    26b4:      	lsr	w14, w14, #0
    26b8:      	sxtw	x14, w14
    26bc:      	cmp	x14, #0x0
    26c0:      	cset	w15, gt
    26c4:      	movz	x16, #0x0, lsl #48
    26c8:      	sub	x19, x16, x14
    26cc:      	sub	x21, x19, #0x1
    26d0:      	uxtb	w16, w15
    26d4:      	cmp	w16, wzr
    26d8:      	b.eq	0x2728 <_stogir.verify.classifications+0x3a4>
    26dc:      	ldr	x19, [x22, #0x8]
    26e0:      	cmp	x14, x19
    26e4:      	b.ge	0x2564 <_stogir.verify.classifications+0x1e0>
    26e8:      	ldr	x19, [x6, #0x8]
    26ec:      	cmp	x14, x19
    26f0:      	b.ge	0x2520 <_stogir.verify.classifications+0x19c>
    26f4:      	ldr	x19, [x22, #0x78]
    26f8:      	add	x19, x19, x14, lsl #2
    26fc:      	ldr	w19, [x19]
    2700:      	sxtw	x19, w19
    2704:      	cmp	x19, #0x0
    2708:      	cset	w19, ge
    270c:      	ubfx	x19, x19, #0, #8
    2710:      	b	0x2524 <_stogir.verify.classifications+0x1a0>
    2714:      	cmp	x13, #0x2
    2718:      	b.ne	0x2768 <_stogir.verify.classifications+0x3e4>
    271c:      	ldr	w14, [x24, #0x8]
    2720:      	sxtw	x14, w14
    2724:      	b	0x26b4 <_stogir.verify.classifications+0x330>
    2728:      	cmp	x14, #0x0
    272c:      	b.ge	0x256c <_stogir.verify.classifications+0x1e8>
    2730:      	ldr	x26, [x7, #0x8]
    2734:      	ldr	x28, [x8, #0x8]
    2738:      	cmp	x26, x28
    273c:      	b.ne	0x2528 <_stogir.verify.classifications+0x1a4>
    2740:      	cmp	x19, x26
    2744:      	b.gt	0x2498 <_stogir.verify.classifications+0x114>
    2748:      	ldr	x19, [x22, #0x50]
    274c:      	add	x19, x19, x21, lsl #2
    2750:      	ldr	w19, [x19]
    2754:      	sxtw	x19, w19
    2758:      	cmp	x19, #0x0
    275c:      	cset	w19, gt
    2760:      	ubfx	x19, x19, #0, #8
    2764:      	b	0x249c <_stogir.verify.classifications+0x118>
    2768:      	cmp	x13, #0x3
    276c:      	b.ne	0x27e0 <_stogir.verify.classifications+0x45c>
    2770:      	ldr	w14, [x24, #0xc]
    2774:      	sxtw	x14, w14
    2778:      	b	0x2724 <_stogir.verify.classifications+0x3a0>
    277c:      	uxtb	w20, w20
    2780:      	uxtb	w0, w0
    2784:      	add	x16, sp, #0x10
    2788:      	movz	w17, #0x0, lsl #16
    278c:      	strh	w17, [x16]
    2790:      	add	x16, sp, #0x10
    2794:      	strb	w20, [x16]
    2798:      	add	x16, sp, #0x10
    279c:      	strb	w0, [x16, #0x1]
    27a0:      	add	x16, sp, #0x10
    27a4:      	ldrh	w0, [x16]
    27a8:      	ldr	x19, [sp, #0x20]
    27ac:      	ldr	x20, [sp, #0x28]
    27b0:      	ldr	x21, [sp, #0x30]
    27b4:      	ldr	x22, [sp, #0x38]
    27b8:      	ldr	x23, [sp, #0x40]
    27bc:      	ldr	x24, [sp, #0x48]
    27c0:      	ldr	x25, [sp, #0x50]
    27c4:      	ldr	x26, [sp, #0x58]
    27c8:      	ldr	x27, [sp, #0x60]
    27cc:      	ldr	x28, [sp, #0x68]
    27d0:      	ldr	x29, [sp]
    27d4:      	ldr	x30, [sp, #0x8]
    27d8:      	add	sp, sp, #0x70
    27dc:      	ret
    27e0:      	uxtb	w16, w10
    27e4:      	cmp	w16, wzr
    27e8:      	b.ne	0x2898 <_stogir.verify.classifications+0x514>
    27ec:      	ldr	x15, [x22, #0x8]
    27f0:      	cmp	x23, x15
    27f4:      	b.ge	0x2898 <_stogir.verify.classifications+0x514>
    27f8:      	ldr	x15, [x9, #0x8]
    27fc:      	cmp	x23, x15
    2800:      	b.ge	0x2898 <_stogir.verify.classifications+0x514>
    2804:      	ldr	x15, [x22, #0x78]
    2808:      	add	x15, x11, x15
    280c:      	ldr	w15, [x15]
    2810:      	sxtw	x15, w15
    2814:      	cmp	x15, #0x0
    2818:      	b.lt	0x2898 <_stogir.verify.classifications+0x514>
    281c:      	cmp	x14, #0x1
    2820:      	b.lt	0x2918 <_stogir.verify.classifications+0x594>
    2824:      	ldr	x15, [x22, #0x78]
    2828:      	add	x15, x11, x15
    282c:      	ldr	w15, [x15]
    2830:      	sxtw	x15, w15
    2834:      	cmp	x14, x15
    2838:      	b.gt	0x2918 <_stogir.verify.classifications+0x594>
    283c:      	ldr	x15, [x22]
    2840:      	asr	x16, x14, #63
    2844:      	lsr	x16, x16, #62
    2848:      	add	x19, x14, x16
    284c:      	asr	x19, x19, #2
    2850:      	asr	x16, x14, #63
    2854:      	lsr	x16, x16, #62
    2858:      	add	x14, x14, x16
    285c:      	and	x14, x14, #0x3
    2860:      	sub	x14, x14, x16
    2864:      	add	x19, x19, x23
    2868:      	add	x15, x15, x19, lsl #4
    286c:      	add	x14, x15, x14, lsl #2
    2870:      	ldr	w14, [x14]
    2874:      	sxtw	x14, w14
    2878:      	and	x14, x14, #0xffffffff
    287c:      	mov	x15, #0x1               ; =1
    2880:      	b	0x2920 <_stogir.verify.classifications+0x59c>
    2884:      	movz	x20, #0x0, lsl #48
    2888:      	b	0x24a4 <_stogir.verify.classifications+0x120>
    288c:      	lsr	w14, w14, #0
    2890:      	sxtw	x14, w14
    2894:      	b	0x2778 <_stogir.verify.classifications+0x3f4>
    2898:      	movz	x15, #0x0, lsl #48
    289c:      	movz	x14, #0x0, lsl #48
    28a0:      	lsr	w15, w15, #0
    28a4:      	lsr	x16, x15, #0
    28a8:      	cmp	x16, #0x1
    28ac:      	b.eq	0x28c8 <_stogir.verify.classifications+0x544>
    28b0:      	b.lo	0x28b8 <_stogir.verify.classifications+0x534>
    28b4:      	b	0x28cc <_stogir.verify.classifications+0x548>
    28b8:      	cmp	x16, #0x0
    28bc:      	b.eq	0x28c4 <_stogir.verify.classifications+0x540>
    28c0:      	b	0x28cc <_stogir.verify.classifications+0x548>
    28c4:      	b	0x28d0 <_stogir.verify.classifications+0x54c>
    28c8:      	b	0x288c <_stogir.verify.classifications+0x508>
    28cc:      	b	0x2934 <_stogir.verify.classifications+0x5b0>
    28d0:      	movz	x14, #0x0, lsl #48
    28d4:      	b	0x2894 <_stogir.verify.classifications+0x510>
    28d8:      	cmp	x19, #0x18
    28dc:      	b.ne	0x28e8 <_stogir.verify.classifications+0x564>
    28e0:      	mov	x0, #0x1                ; =1
    28e4:      	b	0x2494 <_stogir.verify.classifications+0x110>
    28e8:      	cmp	x19, #0x19
    28ec:      	b.ne	0x28f8 <_stogir.verify.classifications+0x574>
    28f0:      	mov	x0, #0x1                ; =1
    28f4:      	b	0x2494 <_stogir.verify.classifications+0x110>
    28f8:      	cmp	x21, #0xc
    28fc:      	b.eq	0x2490 <_stogir.verify.classifications+0x10c>
    2900:      	cmp	x21, #0xd
    2904:      	b.eq	0x2490 <_stogir.verify.classifications+0x10c>
    2908:      	cmp	x28, #0xc
    290c:      	b.ne	0x2924 <_stogir.verify.classifications+0x5a0>
    2910:      	mov	x0, #0x1                ; =1
    2914:      	b	0x2930 <_stogir.verify.classifications+0x5ac>
    2918:      	movz	x15, #0x0, lsl #48
    291c:      	movz	x14, #0x0, lsl #48
    2920:      	b	0x28a0 <_stogir.verify.classifications+0x51c>
    2924:      	cmp	x28, #0xd
    2928:      	cset	w0, eq
    292c:      	ubfx	x0, x0, #0, #8
    2930:      	b	0x2494 <_stogir.verify.classifications+0x110>
    2934:      	brk	#0
    2938:      	b	0x2934 <_stogir.verify.classifications+0x5b0>
    293c:      	udf	#0x0

0000000000002940 <_stogir.vector.validate>:
    2940:      	sub	sp, sp, #0x210
    2944:      	str	x29, [sp]
    2948:      	str	x30, [sp, #0x8]
    294c:      	mov	x29, sp
    2950:      	str	x19, [sp, #0x1c0]
    2954:      	str	x20, [sp, #0x1c8]
    2958:      	str	x21, [sp, #0x1d0]
    295c:      	str	x22, [sp, #0x1d8]
    2960:      	str	x23, [sp, #0x1e0]
    2964:      	str	x24, [sp, #0x1e8]
    2968:      	str	x25, [sp, #0x1f0]
    296c:      	str	x26, [sp, #0x1f8]
    2970:      	str	x27, [sp, #0x200]
    2974:      	str	x28, [sp, #0x208]
    2978:      	lsr	w19, w1, #0
    297c:      	mov	x20, x8
    2980:      	add	x8, sp, #0x10
    2984:      	mov	x21, x0
    2988:      	mov	w22, w1
    298c:      	mov	w1, w19
    2990:      	mov	w23, w2
    2994:      	bl	0x2994 <_stogir.vector.validate+0x54>
		0000000000002994:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    2998:      	add	x16, sp, #0x10
    299c:      	ldr	w0, [x16]
    29a0:      	lsr	x16, x0, #0
    29a4:      	cmp	x16, #0x1
    29a8:      	b.eq	0x29c4 <_stogir.vector.validate+0x84>
    29ac:      	b.lo	0x29b4 <_stogir.vector.validate+0x74>
    29b0:      	b	0x29c8 <_stogir.vector.validate+0x88>
    29b4:      	cmp	x16, #0x0
    29b8:      	b.eq	0x29c0 <_stogir.vector.validate+0x80>
    29bc:      	b	0x29c8 <_stogir.vector.validate+0x88>
    29c0:      	b	0x29cc <_stogir.vector.validate+0x8c>
    29c4:      	b	0x2a60 <_stogir.vector.validate+0x120>
    29c8:      	b	0x2c7c <_stogir.vector.validate+0x33c>
    29cc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		00000000000029cc:  ARM64_RELOC_PAGE21	l_stogir.349
    29d0:      	ldr	x16, [x16]
		00000000000029d0:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    29d4:      	orr	x19, x16, xzr
    29d8:      	str	x20, [sp, #0x1a8]
    29dc:      	mov	x0, #0x1                ; =1
    29e0:      	mov	x25, #0x1a              ; =26
    29e4:      	b	0x2a18 <_stogir.vector.validate+0xd8>
    29e8:      	lsr	w23, w23, #0
    29ec:      	add	x8, sp, #0x70
    29f0:      	mov	x0, x21
    29f4:      	ldr	w1, [sp, #0x1a0]
    29f8:      	mov	w2, w23
    29fc:      	bl	0x29fc <_stogir.vector.validate+0xbc>
		00000000000029fc:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    2a00:      	add	x16, sp, #0x70
    2a04:      	ldr	x0, [x16]
    2a08:      	add	x16, sp, #0x70
    2a0c:      	ldr	x19, [x16, #0x8]
    2a10:      	add	x16, sp, #0x70
    2a14:      	ldr	x25, [x16, #0x10]
    2a18:      	ldr	x1, [sp, #0x1a8]
    2a1c:      	str	x0, [x1]
    2a20:      	str	x19, [x1, #0x8]
    2a24:      	str	x25, [x1, #0x10]
    2a28:      	ldr	x19, [sp, #0x1c0]
    2a2c:      	ldr	x20, [sp, #0x1c8]
    2a30:      	ldr	x21, [sp, #0x1d0]
    2a34:      	ldr	x22, [sp, #0x1d8]
    2a38:      	ldr	x23, [sp, #0x1e0]
    2a3c:      	ldr	x24, [sp, #0x1e8]
    2a40:      	ldr	x25, [sp, #0x1f0]
    2a44:      	ldr	x26, [sp, #0x1f8]
    2a48:      	ldr	x27, [sp, #0x200]
    2a4c:      	ldr	x28, [sp, #0x208]
    2a50:      	ldr	x29, [sp]
    2a54:      	ldr	x30, [sp, #0x8]
    2a58:      	add	sp, sp, #0x210
    2a5c:      	ret
    2a60:      	sxtw	x22, w22
    2a64:      	add	x16, sp, #0x10
    2a68:      	orr	x0, x16, xzr
    2a6c:      	cmp	x22, #0x0
    2a70:      	cset	w24, le
    2a74:      	add	x0, x0, #0x8
    2a78:      	add	x16, sp, #0x10
    2a7c:      	ldr	x25, [x16, #0x8]
    2a80:      	add	x16, sp, #0x40
    2a84:      	str	x25, [x16]
    2a88:      	ldr	x0, [x0, #0x8]
    2a8c:      	add	x16, sp, #0x40
    2a90:      	str	x0, [x16, #0x8]
    2a94:      	uxtb	w16, w24
    2a98:      	cmp	w16, wzr
    2a9c:      	b.eq	0x2abc <_stogir.vector.validate+0x17c>
    2aa0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002aa0:  ARM64_RELOC_PAGE21	l_stogir.350
    2aa4:      	ldr	x16, [x16]
		0000000000002aa4:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    2aa8:      	orr	x19, x16, xzr
    2aac:      	str	x20, [sp, #0x1a8]
    2ab0:      	mov	x0, #0x1                ; =1
    2ab4:      	mov	x25, #0x3b              ; =59
    2ab8:      	b	0x2a18 <_stogir.vector.validate+0xd8>
    2abc:      	lsl	x26, x22, #2
    2ac0:      	uxtb	w0, w25
    2ac4:      	orr	x27, x0, xzr
    2ac8:      	ldr	x0, [x21, #0x78]
    2acc:      	cmp	x27, #0x44
    2ad0:      	cset	w1, eq
    2ad4:      	add	x0, x0, x22, lsl #2
    2ad8:      	ldr	w28, [x0]
    2adc:      	cmp	x27, #0x24
    2ae0:      	b.ne	0x2b24 <_stogir.vector.validate+0x1e4>
    2ae4:      	str	x20, [sp, #0x1a8]
    2ae8:      	str	w19, [sp, #0x1a0]
    2aec:      	uxtb	w16, w1
    2af0:      	cmp	w16, wzr
    2af4:      	b.eq	0x29e8 <_stogir.vector.validate+0xa8>
    2af8:      	add	x8, sp, #0x50
    2afc:      	mov	x0, x21
    2b00:      	ldr	w1, [sp, #0x1a0]
    2b04:      	bl	0x2b04 <_stogir.vector.validate+0x1c4>
		0000000000002b04:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    2b08:      	add	x16, sp, #0x50
    2b0c:      	ldr	x0, [x16]
    2b10:      	add	x16, sp, #0x50
    2b14:      	ldr	x19, [x16, #0x8]
    2b18:      	add	x16, sp, #0x50
    2b1c:      	ldr	x25, [x16, #0x10]
    2b20:      	b	0x2a18 <_stogir.vector.validate+0xd8>
    2b24:      	uxtb	w16, w1
    2b28:      	cmp	w16, wzr
    2b2c:      	b.ne	0x33a4 <_stogir.vector.validate+0xa64>
    2b30:      	cmp	x27, #0x3c
    2b34:      	b.ne	0x2be8 <_stogir.vector.validate+0x2a8>
    2b38:      	add	x8, sp, #0x90
    2b3c:      	mov	x0, x21
    2b40:      	mov	w1, w19
    2b44:      	bl	0x2b44 <_stogir.vector.validate+0x204>
		0000000000002b44:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    2b48:      	add	x16, sp, #0x90
    2b4c:      	ldr	x0, [x16]
    2b50:      	add	x16, sp, #0x90
    2b54:      	ldr	x19, [x16, #0x8]
    2b58:      	add	x16, sp, #0x90
    2b5c:      	ldr	x25, [x16, #0x10]
    2b60:      	str	x20, [sp, #0x1a8]
    2b64:      	b	0x2be4 <_stogir.vector.validate+0x2a4>
    2b68:      	cmp	x27, #0x41
    2b6c:      	cset	w0, eq
    2b70:      	cmp	x27, #0x48
    2b74:      	cset	w1, eq
    2b78:      	cmp	x27, #0x55
    2b7c:      	cset	w2, ge
    2b80:      	cmp	x27, #0x58
    2b84:      	cset	w3, le
    2b88:      	cmp	x27, #0x47
    2b8c:      	b.ne	0x2c84 <_stogir.vector.validate+0x344>
    2b90:      	str	x20, [sp, #0x1a8]
    2b94:      	str	w19, [sp, #0x1a0]
    2b98:      	mov	w19, w0
    2b9c:      	mov	w20, w1
    2ba0:      	str	w2, [sp, #0x1b0]
    2ba4:      	str	w3, [sp, #0x1b8]
    2ba8:      	mov	x0, x21
    2bac:      	ldr	w1, [sp, #0x1a0]
    2bb0:      	bl	0x2bb0 <_stogir.vector.validate+0x270>
		0000000000002bb0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2bb4:      	cmp	x0, #0x0
    2bb8:      	b.eq	0x2ca8 <_stogir.vector.validate+0x368>
    2bbc:      	add	x8, sp, #0xf0
    2bc0:      	mov	x0, x21
    2bc4:      	ldr	w1, [sp, #0x1a0]
    2bc8:      	bl	0x2bc8 <_stogir.vector.validate+0x288>
		0000000000002bc8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    2bcc:      	add	x16, sp, #0xf0
    2bd0:      	ldr	x0, [x16]
    2bd4:      	add	x16, sp, #0xf0
    2bd8:      	ldr	x19, [x16, #0x8]
    2bdc:      	add	x16, sp, #0xf0
    2be0:      	ldr	x25, [x16, #0x10]
    2be4:      	b	0x2a18 <_stogir.vector.validate+0xd8>
    2be8:      	cmp	x27, #0x3d
    2bec:      	b.lt	0x2c30 <_stogir.vector.validate+0x2f0>
    2bf0:      	cmp	x27, #0x3f
    2bf4:      	b.gt	0x2c30 <_stogir.vector.validate+0x2f0>
    2bf8:      	lsr	w23, w23, #0
    2bfc:      	add	x8, sp, #0xb0
    2c00:      	mov	x0, x21
    2c04:      	mov	w1, w19
    2c08:      	mov	w2, w23
    2c0c:      	bl	0x2c0c <_stogir.vector.validate+0x2cc>
		0000000000002c0c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    2c10:      	add	x16, sp, #0xb0
    2c14:      	ldr	x0, [x16]
    2c18:      	add	x16, sp, #0xb0
    2c1c:      	ldr	x19, [x16, #0x8]
    2c20:      	add	x16, sp, #0xb0
    2c24:      	ldr	x25, [x16, #0x10]
    2c28:      	str	x20, [sp, #0x1a8]
    2c2c:      	b	0x2be4 <_stogir.vector.validate+0x2a4>
    2c30:      	mov	x0, x21
    2c34:      	mov	w1, w19
    2c38:      	bl	0x2c38 <_stogir.vector.validate+0x2f8>
		0000000000002c38:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    2c3c:      	cmp	x0, #0x0
    2c40:      	b.eq	0x2b68 <_stogir.vector.validate+0x228>
    2c44:      	lsr	w23, w23, #0
    2c48:      	add	x8, sp, #0xd0
    2c4c:      	mov	x0, x21
    2c50:      	mov	w1, w19
    2c54:      	mov	w2, w23
    2c58:      	bl	0x2c58 <_stogir.vector.validate+0x318>
		0000000000002c58:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    2c5c:      	add	x16, sp, #0xd0
    2c60:      	ldr	x0, [x16]
    2c64:      	add	x16, sp, #0xd0
    2c68:      	ldr	x19, [x16, #0x8]
    2c6c:      	add	x16, sp, #0xd0
    2c70:      	ldr	x25, [x16, #0x10]
    2c74:      	str	x20, [sp, #0x1a8]
    2c78:      	b	0x2be4 <_stogir.vector.validate+0x2a4>
    2c7c:      	brk	#0
    2c80:      	b	0x2c7c <_stogir.vector.validate+0x33c>
    2c84:      	cmp	x27, #0x4f
    2c88:      	b.ne	0x2d24 <_stogir.vector.validate+0x3e4>
    2c8c:      	str	x20, [sp, #0x1a8]
    2c90:      	str	w19, [sp, #0x1a0]
    2c94:      	mov	w19, w0
    2c98:      	mov	w20, w1
    2c9c:      	str	w2, [sp, #0x1b0]
    2ca0:      	str	w3, [sp, #0x1b8]
    2ca4:      	b	0x2ba8 <_stogir.vector.validate+0x268>
    2ca8:      	uxtb	w16, w19
    2cac:      	cmp	w16, wzr
    2cb0:      	b.ne	0x2cf0 <_stogir.vector.validate+0x3b0>
    2cb4:      	uxtb	w16, w20
    2cb8:      	cmp	w16, wzr
    2cbc:      	b.ne	0x2cf0 <_stogir.vector.validate+0x3b0>
    2cc0:      	ldr	w0, [sp, #0x1b0]
    2cc4:      	uxtb	w16, w0
    2cc8:      	cmp	w16, wzr
    2ccc:      	b.eq	0x2ce0 <_stogir.vector.validate+0x3a0>
    2cd0:      	ldr	w0, [sp, #0x1b8]
    2cd4:      	uxtb	w16, w0
    2cd8:      	cmp	w16, wzr
    2cdc:      	b.ne	0x2cf0 <_stogir.vector.validate+0x3b0>
    2ce0:      	movz	x0, #0x0, lsl #48
    2ce4:      	movz	x19, #0x0, lsl #48
    2ce8:      	movz	x25, #0x0, lsl #48
    2cec:      	b	0x2d20 <_stogir.vector.validate+0x3e0>
    2cf0:      	lsr	w23, w23, #0
    2cf4:      	add	x8, sp, #0x110
    2cf8:      	mov	x0, x21
    2cfc:      	ldr	w1, [sp, #0x1a0]
    2d00:      	mov	w2, w23
    2d04:      	bl	0x2d04 <_stogir.vector.validate+0x3c4>
		0000000000002d04:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    2d08:      	add	x16, sp, #0x110
    2d0c:      	ldr	x0, [x16]
    2d10:      	add	x16, sp, #0x110
    2d14:      	ldr	x19, [x16, #0x8]
    2d18:      	add	x16, sp, #0x110
    2d1c:      	ldr	x25, [x16, #0x10]
    2d20:      	b	0x2be4 <_stogir.vector.validate+0x2a4>
    2d24:      	cmp	x27, #0x50
    2d28:      	b.eq	0x33b0 <_stogir.vector.validate+0xa70>
    2d2c:      	cmp	x27, #0x78
    2d30:      	b.ne	0x2d50 <_stogir.vector.validate+0x410>
    2d34:      	str	x20, [sp, #0x1a8]
    2d38:      	str	w19, [sp, #0x1a0]
    2d3c:      	mov	w19, w0
    2d40:      	mov	w20, w1
    2d44:      	str	w2, [sp, #0x1b0]
    2d48:      	str	w3, [sp, #0x1b8]
    2d4c:      	b	0x2ba8 <_stogir.vector.validate+0x268>
    2d50:      	uxtb	w16, w0
    2d54:      	cmp	w16, wzr
    2d58:      	b.ne	0x2e50 <_stogir.vector.validate+0x510>
    2d5c:      	uxtb	w16, w1
    2d60:      	cmp	w16, wzr
    2d64:      	b.ne	0x2e50 <_stogir.vector.validate+0x510>
    2d68:      	uxtb	w16, w2
    2d6c:      	cmp	w16, wzr
    2d70:      	b.eq	0x2d80 <_stogir.vector.validate+0x440>
    2d74:      	uxtb	w16, w3
    2d78:      	cmp	w16, wzr
    2d7c:      	b.ne	0x2e50 <_stogir.vector.validate+0x510>
    2d80:      	str	w2, [sp, #0x1b0]
    2d84:      	str	w3, [sp, #0x1b8]
    2d88:      	str	w19, [sp, #0x1a0]
    2d8c:      	str	x20, [sp, #0x1a8]
    2d90:      	mov	w20, w1
    2d94:      	mov	w1, w19
    2d98:      	mov	w19, w0
    2d9c:      	mov	x0, x21
    2da0:      	bl	0x2da0 <_stogir.vector.validate+0x460>
		0000000000002da0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2da4:      	cmp	x0, #0x0
    2da8:      	b.ne	0x2ba8 <_stogir.vector.validate+0x268>
    2dac:      	sxtw	x28, w28
    2db0:      	lsr	w25, w25, #0
    2db4:      	ubfx	x0, x25, #8, #8
    2db8:      	orr	x1, x0, xzr
    2dbc:      	lsr	w20, w1, #0
    2dc0:      	cmp	x27, #0x5b
    2dc4:      	b.eq	0x2e84 <_stogir.vector.validate+0x544>
    2dc8:      	cmp	x27, #0x5c
    2dcc:      	b.eq	0x2e84 <_stogir.vector.validate+0x544>
    2dd0:      	orr	x25, x0, xzr
    2dd4:      	cmp	x27, #0x5d
    2dd8:      	b.ne	0x2ef8 <_stogir.vector.validate+0x5b8>
    2ddc:      	mov	x27, x25
    2de0:      	cmp	x28, #0x3
    2de4:      	b.ne	0x2ee0 <_stogir.vector.validate+0x5a0>
    2de8:      	cmp	x27, #0x0
    2dec:      	b.ne	0x2ee0 <_stogir.vector.validate+0x5a0>
    2df0:      	lsr	w23, w23, #0
    2df4:      	add	x16, sp, #0x40
    2df8:      	ldr	w0, [x16, #0x4]
    2dfc:      	add	x16, sp, #0x40
    2e00:      	ldr	w1, [x16, #0x8]
    2e04:      	lsr	w0, w0, #0
    2e08:      	add	x16, sp, #0x40
    2e0c:      	ldr	w2, [x16, #0xc]
    2e10:      	lsr	w1, w1, #0
    2e14:      	lsr	w2, w2, #0
    2e18:      	add	x8, sp, #0x150
    2e1c:      	mov	w3, w1
    2e20:      	mov	w1, w23
    2e24:      	mov	w4, w2
    2e28:      	mov	w2, w0
    2e2c:      	mov	x0, x21
    2e30:      	bl	0x2e30 <_stogir.vector.validate+0x4f0>
		0000000000002e30:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    2e34:      	add	x16, sp, #0x150
    2e38:      	ldr	x0, [x16]
    2e3c:      	add	x16, sp, #0x150
    2e40:      	ldr	x19, [x16, #0x8]
    2e44:      	add	x16, sp, #0x150
    2e48:      	ldr	x25, [x16, #0x10]
    2e4c:      	b	0x2ef4 <_stogir.vector.validate+0x5b4>
    2e50:      	str	x20, [sp, #0x1a8]
    2e54:      	str	w19, [sp, #0x1a0]
    2e58:      	mov	w19, w0
    2e5c:      	mov	w20, w1
    2e60:      	str	w2, [sp, #0x1b0]
    2e64:      	str	w3, [sp, #0x1b8]
    2e68:      	b	0x2ba8 <_stogir.vector.validate+0x268>
    2e6c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002e6c:  ARM64_RELOC_PAGE21	l_stogir.351
    2e70:      	ldr	x16, [x16]
		0000000000002e70:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    2e74:      	orr	x19, x16, xzr
    2e78:      	mov	x0, #0x1                ; =1
    2e7c:      	mov	x25, #0x19              ; =25
    2e80:      	b	0x2be4 <_stogir.vector.validate+0x2a4>
    2e84:      	cmp	x28, #0x2
    2e88:      	b.ne	0x2e6c <_stogir.vector.validate+0x52c>
    2e8c:      	lsr	w23, w23, #0
    2e90:      	add	x16, sp, #0x40
    2e94:      	ldr	w0, [x16, #0x4]
    2e98:      	add	x16, sp, #0x40
    2e9c:      	ldr	w1, [x16, #0x8]
    2ea0:      	lsr	w0, w0, #0
    2ea4:      	lsr	w1, w1, #0
    2ea8:      	add	x8, sp, #0x130
    2eac:      	mov	w2, w23
    2eb0:      	mov	w3, w0
    2eb4:      	mov	x0, x21
    2eb8:      	mov	w4, w1
    2ebc:      	mov	w1, w20
    2ec0:      	bl	0x2ec0 <_stogir.vector.validate+0x580>
		0000000000002ec0:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    2ec4:      	add	x16, sp, #0x130
    2ec8:      	ldr	x0, [x16]
    2ecc:      	add	x16, sp, #0x130
    2ed0:      	ldr	x19, [x16, #0x8]
    2ed4:      	add	x16, sp, #0x130
    2ed8:      	ldr	x25, [x16, #0x10]
    2edc:      	b	0x2e80 <_stogir.vector.validate+0x540>
    2ee0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002ee0:  ARM64_RELOC_PAGE21	l_stogir.352
    2ee4:      	ldr	x16, [x16]
		0000000000002ee4:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    2ee8:      	orr	x19, x16, xzr
    2eec:      	mov	x0, #0x1                ; =1
    2ef0:      	mov	x25, #0x1a              ; =26
    2ef4:      	b	0x2e80 <_stogir.vector.validate+0x540>
    2ef8:      	cmp	x27, #0x5e
    2efc:      	b.eq	0x33cc <_stogir.vector.validate+0xa8c>
    2f00:      	cmp	x27, #0x43
    2f04:      	b.ne	0x2f7c <_stogir.vector.validate+0x63c>
    2f08:      	cmp	x25, #0xf
    2f0c:      	b.le	0x32bc <_stogir.vector.validate+0x97c>
    2f10:      	cmp	x25, #0x80
    2f14:      	b.ge	0x32bc <_stogir.vector.validate+0x97c>
    2f18:      	and	x0, x25, #0xf
    2f1c:      	lsr	w0, w0, #0
    2f20:      	sxtw	x0, w0
    2f24:      	cmp	x0, #0x1
    2f28:      	b.lt	0x32bc <_stogir.vector.validate+0x97c>
    2f2c:      	cmp	x0, #0xd
    2f30:      	b.gt	0x32bc <_stogir.vector.validate+0x97c>
    2f34:      	lsr	w23, w23, #0
    2f38:      	mov	w0, w20
    2f3c:      	mov	w1, w23
    2f40:      	bl	0x2f40 <_stogir.vector.validate+0x600>
		0000000000002f40:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2f44:      	lsr	w0, w0, #0
    2f48:      	sxtw	x0, w0
    2f4c:      	cmp	x0, #0x0
    2f50:      	b.le	0x32bc <_stogir.vector.validate+0x97c>
    2f54:      	cmp	x28, #0x3
    2f58:      	b.lt	0x32bc <_stogir.vector.validate+0x97c>
    2f5c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002f5c:  ARM64_RELOC_PAGE21	l_stogir.353
    2f60:      	ldr	x16, [x16]
		0000000000002f60:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    2f64:      	orr	x19, x16, xzr
    2f68:      	mov	x27, x25
    2f6c:      	movz	x25, #0x0, lsl #48
    2f70:      	b	0x32d0 <_stogir.vector.validate+0x990>
    2f74:      	mov	x0, #0x1                ; =1
    2f78:      	b	0x2ef4 <_stogir.vector.validate+0x5b4>
    2f7c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002f7c:  ARM64_RELOC_PAGE21	l_stogir.354
    2f80:      	ldr	x16, [x16]
		0000000000002f80:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    2f84:      	orr	x19, x16, xzr
    2f88:      	mov	x0, #0x1                ; =1
    2f8c:      	mov	x25, #0x28              ; =40
    2f90:      	b	0x2f78 <_stogir.vector.validate+0x638>
    2f94:      	add	x16, sp, #0x40
    2f98:      	ldr	w0, [x16, #0x4]
    2f9c:      	sxtw	x0, w0
    2fa0:      	ldr	x1, [x21, #0x78]
    2fa4:      	add	x0, x1, x0, lsl #2
    2fa8:      	ldr	w0, [x0]
    2fac:      	sxtw	x0, w0
    2fb0:      	add	x0, x0, #0x1
    2fb4:      	lsr	w0, w0, #0
    2fb8:      	sxtw	x0, w0
    2fbc:      	cmp	x28, x0
    2fc0:      	cset	w0, eq
    2fc4:      	uxtb	w16, w0
    2fc8:      	cmp	w16, wzr
    2fcc:      	cset	x0, eq
    2fd0:      	cmp	x0, #0x0
    2fd4:      	b.eq	0x2fe8 <_stogir.vector.validate+0x6a8>
    2fd8:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002fd8:  ARM64_RELOC_PAGE21	l_stogir.355
    2fdc:      	ldr	x16, [x16]
		0000000000002fdc:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    2fe0:      	orr	x19, x16, xzr
    2fe4:      	mov	x25, #0x19              ; =25
    2fe8:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002fe8:  ARM64_RELOC_PAGE21	l_stogir.356
    2fec:      	ldr	x16, [x16]
		0000000000002fec:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    2ff0:      	orr	x0, x16, xzr
    2ff4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x125c>
		0000000000002ff4:  ARM64_RELOC_PAGE21	l_stogir.357
    2ff8:      	ldr	x16, [x16]
		0000000000002ff8:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    2ffc:      	orr	x1, x16, xzr
    3000:      	add	x2, x21, #0x78
    3004:      	add	x3, x21, #0x28
    3008:      	add	x4, x21, #0x50
    300c:      	add	x5, x21, #0x78
    3010:      	mov	x6, #0x2                ; =2
    3014:      	b	0x308c <_stogir.vector.validate+0x74c>
    3018:      	lsr	w7, w7, #0
    301c:      	ubfx	x7, x7, #8, #8
    3020:      	cmp	x7, x27
    3024:      	b.eq	0x3030 <_stogir.vector.validate+0x6f0>
    3028:      	mov	x19, x1
    302c:      	mov	x25, #0x1e              ; =30
    3030:      	b	0x3080 <_stogir.vector.validate+0x740>
    3034:      	movz	x8, #0x0, lsl #48
    3038:      	movz	x7, #0x0, lsl #48
    303c:      	b	0x3048 <_stogir.vector.validate+0x708>
    3040:      	movz	x8, #0x0, lsl #48
    3044:      	movz	x7, #0x0, lsl #48
    3048:      	lsr	w8, w8, #0
    304c:      	lsr	x16, x8, #0
    3050:      	cmp	x16, #0x1
    3054:      	b.eq	0x3070 <_stogir.vector.validate+0x730>
    3058:      	b.lo	0x3060 <_stogir.vector.validate+0x720>
    305c:      	b	0x3074 <_stogir.vector.validate+0x734>
    3060:      	cmp	x16, #0x0
    3064:      	b.eq	0x306c <_stogir.vector.validate+0x72c>
    3068:      	b	0x3074 <_stogir.vector.validate+0x734>
    306c:      	b	0x3078 <_stogir.vector.validate+0x738>
    3070:      	b	0x30e0 <_stogir.vector.validate+0x7a0>
    3074:      	b	0x338c <_stogir.vector.validate+0xa4c>
    3078:      	mov	x19, x0
    307c:      	mov	x25, #0x18              ; =24
    3080:      	add	x6, x6, #0x1
    3084:      	lsr	w6, w6, #0
    3088:      	sxtw	x6, w6
    308c:      	cmp	x25, #0x0
    3090:      	b.ne	0x3204 <_stogir.vector.validate+0x8c4>
    3094:      	cmp	x6, x28
    3098:      	b.gt	0x3204 <_stogir.vector.validate+0x8c4>
    309c:      	uxtb	w16, w24
    30a0:      	cmp	w16, wzr
    30a4:      	b.ne	0x3040 <_stogir.vector.validate+0x700>
    30a8:      	ldr	x7, [x21, #0x8]
    30ac:      	cmp	x22, x7
    30b0:      	b.ge	0x3148 <_stogir.vector.validate+0x808>
    30b4:      	ldr	x7, [x5, #0x8]
    30b8:      	cmp	x22, x7
    30bc:      	b.ge	0x3140 <_stogir.vector.validate+0x800>
    30c0:      	ldr	x7, [x21, #0x78]
    30c4:      	add	x7, x26, x7
    30c8:      	ldr	w7, [x7]
    30cc:      	sxtw	x7, w7
    30d0:      	cmp	x7, #0x0
    30d4:      	cset	w7, ge
    30d8:      	ubfx	x7, x7, #0, #8
    30dc:      	b	0x3144 <_stogir.vector.validate+0x804>
    30e0:      	lsr	w7, w7, #0
    30e4:      	sxtw	x7, w7
    30e8:      	cmp	x7, #0x0
    30ec:      	cset	w8, gt
    30f0:      	movz	x16, #0x0, lsl #48
    30f4:      	sub	x9, x16, x7
    30f8:      	sub	x10, x9, #0x1
    30fc:      	uxtb	w16, w8
    3100:      	cmp	w16, wzr
    3104:      	b.eq	0x31c4 <_stogir.vector.validate+0x884>
    3108:      	ldr	x9, [x21, #0x8]
    310c:      	cmp	x7, x9
    3110:      	b.ge	0x3234 <_stogir.vector.validate+0x8f4>
    3114:      	ldr	x9, [x2, #0x8]
    3118:      	cmp	x7, x9
    311c:      	b.ge	0x333c <_stogir.vector.validate+0x9fc>
    3120:      	ldr	x9, [x21, #0x78]
    3124:      	add	x9, x9, x7, lsl #2
    3128:      	ldr	w9, [x9]
    312c:      	sxtw	x9, w9
    3130:      	cmp	x9, #0x0
    3134:      	cset	w9, ge
    3138:      	ubfx	x9, x9, #0, #8
    313c:      	b	0x3340 <_stogir.vector.validate+0xa00>
    3140:      	movz	x7, #0x0, lsl #48
    3144:      	b	0x314c <_stogir.vector.validate+0x80c>
    3148:      	movz	x7, #0x0, lsl #48
    314c:      	cmp	x7, #0x0
    3150:      	b.eq	0x3040 <_stogir.vector.validate+0x700>
    3154:      	lsr	w7, w6, #0
    3158:      	sxtw	x7, w7
    315c:      	cmp	x7, #0x1
    3160:      	b.lt	0x3034 <_stogir.vector.validate+0x6f4>
    3164:      	ldr	x8, [x21, #0x78]
    3168:      	add	x8, x26, x8
    316c:      	ldr	w8, [x8]
    3170:      	sxtw	x8, w8
    3174:      	cmp	x7, x8
    3178:      	b.gt	0x3034 <_stogir.vector.validate+0x6f4>
    317c:      	ldr	x8, [x21]
    3180:      	asr	x16, x7, #63
    3184:      	lsr	x16, x16, #62
    3188:      	add	x9, x7, x16
    318c:      	asr	x9, x9, #2
    3190:      	asr	x16, x7, #63
    3194:      	lsr	x16, x16, #62
    3198:      	add	x7, x7, x16
    319c:      	and	x7, x7, #0x3
    31a0:      	sub	x7, x7, x16
    31a4:      	add	x9, x9, x22
    31a8:      	add	x8, x8, x9, lsl #4
    31ac:      	add	x7, x8, x7, lsl #2
    31b0:      	ldr	w7, [x7]
    31b4:      	sxtw	x7, w7
    31b8:      	and	x7, x7, #0xffffffff
    31bc:      	mov	x8, #0x1                ; =1
    31c0:      	b	0x303c <_stogir.vector.validate+0x6fc>
    31c4:      	cmp	x7, #0x0
    31c8:      	b.ge	0x323c <_stogir.vector.validate+0x8fc>
    31cc:      	ldr	x11, [x3, #0x8]
    31d0:      	ldr	x12, [x4, #0x8]
    31d4:      	cmp	x11, x12
    31d8:      	b.ne	0x3334 <_stogir.vector.validate+0x9f4>
    31dc:      	cmp	x9, x11
    31e0:      	b.gt	0x3368 <_stogir.vector.validate+0xa28>
    31e4:      	ldr	x9, [x21, #0x50]
    31e8:      	add	x9, x9, x10, lsl #2
    31ec:      	ldr	w9, [x9]
    31f0:      	sxtw	x9, w9
    31f4:      	cmp	x9, #0x0
    31f8:      	cset	w9, gt
    31fc:      	ubfx	x9, x9, #0, #8
    3200:      	b	0x336c <_stogir.vector.validate+0xa2c>
    3204:      	cmp	x25, #0x0
    3208:      	b.ne	0x2f74 <_stogir.vector.validate+0x634>
    320c:      	lsr	w23, w23, #0
    3210:      	mov	w0, w20
    3214:      	mov	w1, w23
    3218:      	bl	0x3218 <_stogir.vector.validate+0x8d8>
		0000000000003218:  ARM64_RELOC_BRANCH26	_stogir.types.size
    321c:      	lsr	w0, w0, #0
    3220:      	sxtw	x0, w0
    3224:      	and	x19, x0, #0xffffffff
    3228:      	movz	x0, #0x0, lsl #48
    322c:      	movz	x25, #0x0, lsl #48
    3230:      	b	0x2f78 <_stogir.vector.validate+0x638>
    3234:      	movz	x9, #0x0, lsl #48
    3238:      	b	0x3240 <_stogir.vector.validate+0x900>
    323c:      	movz	x9, #0x0, lsl #48
    3240:      	cmp	x9, #0x0
    3244:      	b.eq	0x3278 <_stogir.vector.validate+0x938>
    3248:      	uxtb	w16, w8
    324c:      	cmp	w16, wzr
    3250:      	b.eq	0x3264 <_stogir.vector.validate+0x924>
    3254:      	ldr	x8, [x21]
    3258:      	add	x7, x8, x7, lsl #4
    325c:      	ldr	x7, [x7]
    3260:      	b	0x3270 <_stogir.vector.validate+0x930>
    3264:      	ldr	x7, [x21, #0x28]
    3268:      	add	x7, x7, x10, lsl #4
    326c:      	ldr	x7, [x7]
    3270:      	mov	x8, #0x1                ; =1
    3274:      	b	0x3280 <_stogir.vector.validate+0x940>
    3278:      	movz	x8, #0x0, lsl #48
    327c:      	movz	x7, #0x0, lsl #48
    3280:      	lsr	w8, w8, #0
    3284:      	lsr	x16, x8, #0
    3288:      	cmp	x16, #0x1
    328c:      	b.eq	0x32a8 <_stogir.vector.validate+0x968>
    3290:      	b.lo	0x3298 <_stogir.vector.validate+0x958>
    3294:      	b	0x32ac <_stogir.vector.validate+0x96c>
    3298:      	cmp	x16, #0x0
    329c:      	b.eq	0x32a4 <_stogir.vector.validate+0x964>
    32a0:      	b	0x32ac <_stogir.vector.validate+0x96c>
    32a4:      	b	0x32b0 <_stogir.vector.validate+0x970>
    32a8:      	b	0x3018 <_stogir.vector.validate+0x6d8>
    32ac:      	b	0x3394 <_stogir.vector.validate+0xa54>
    32b0:      	mov	x19, x0
    32b4:      	mov	x25, #0x18              ; =24
    32b8:      	b	0x3030 <_stogir.vector.validate+0x6f0>
    32bc:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		00000000000032bc:  ARM64_RELOC_PAGE21	l_stogir.358
    32c0:      	ldr	x16, [x16]
		00000000000032c0:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    32c4:      	orr	x19, x16, xzr
    32c8:      	mov	x27, x25
    32cc:      	mov	x25, #0x20              ; =32
    32d0:      	add	x16, sp, #0x40
    32d4:      	ldr	w0, [x16, #0x4]
    32d8:      	lsr	w0, w0, #0
    32dc:      	add	x8, sp, #0x170
    32e0:      	mov	w1, w0
    32e4:      	mov	x0, x21
    32e8:      	bl	0x32e8 <_stogir.vector.validate+0x9a8>
		00000000000032e8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    32ec:      	add	x16, sp, #0x170
    32f0:      	ldr	w0, [x16]
    32f4:      	lsr	x16, x0, #0
    32f8:      	cmp	x16, #0x1
    32fc:      	b.eq	0x3318 <_stogir.vector.validate+0x9d8>
    3300:      	b.lo	0x3308 <_stogir.vector.validate+0x9c8>
    3304:      	b	0x331c <_stogir.vector.validate+0x9dc>
    3308:      	cmp	x16, #0x0
    330c:      	b.eq	0x3314 <_stogir.vector.validate+0x9d4>
    3310:      	b	0x331c <_stogir.vector.validate+0x9dc>
    3314:      	b	0x3320 <_stogir.vector.validate+0x9e0>
    3318:      	b	0x3344 <_stogir.vector.validate+0xa04>
    331c:      	b	0x339c <_stogir.vector.validate+0xa5c>
    3320:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003320:  ARM64_RELOC_PAGE21	l_stogir.359
    3324:      	ldr	x16, [x16]
		0000000000003324:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    3328:      	orr	x19, x16, xzr
    332c:      	mov	x25, #0x19              ; =25
    3330:      	b	0x2fe8 <_stogir.vector.validate+0x6a8>
    3334:      	movz	x9, #0x0, lsl #48
    3338:      	b	0x3240 <_stogir.vector.validate+0x900>
    333c:      	movz	x9, #0x0, lsl #48
    3340:      	b	0x3238 <_stogir.vector.validate+0x8f8>
    3344:      	add	x16, sp, #0x170
    3348:      	ldr	x0, [x16, #0x8]
    334c:      	add	x16, sp, #0x40
    3350:      	ldr	w1, [x16, #0x4]
    3354:      	sxtw	x1, w1
    3358:      	cmp	x1, #0x0
    335c:      	b.gt	0x3370 <_stogir.vector.validate+0xa30>
    3360:      	mov	x0, #0x1                ; =1
    3364:      	b	0x2fd0 <_stogir.vector.validate+0x690>
    3368:      	movz	x9, #0x0, lsl #48
    336c:      	b	0x3338 <_stogir.vector.validate+0x9f8>
    3370:      	uxtb	w0, w0
    3374:      	cmp	x0, #0x70
    3378:      	b.eq	0x2f94 <_stogir.vector.validate+0x654>
    337c:      	cmp	x0, #0x71
    3380:      	b.eq	0x2f94 <_stogir.vector.validate+0x654>
    3384:      	mov	x0, #0x1                ; =1
    3388:      	b	0x2fd0 <_stogir.vector.validate+0x690>
    338c:      	brk	#0
    3390:      	b	0x338c <_stogir.vector.validate+0xa4c>
    3394:      	brk	#0
    3398:      	b	0x3394 <_stogir.vector.validate+0xa54>
    339c:      	brk	#0
    33a0:      	b	0x339c <_stogir.vector.validate+0xa5c>
    33a4:      	str	x20, [sp, #0x1a8]
    33a8:      	str	w19, [sp, #0x1a0]
    33ac:      	b	0x2aec <_stogir.vector.validate+0x1ac>
    33b0:      	str	x20, [sp, #0x1a8]
    33b4:      	str	w19, [sp, #0x1a0]
    33b8:      	mov	w19, w0
    33bc:      	mov	w20, w1
    33c0:      	str	w2, [sp, #0x1b0]
    33c4:      	str	w3, [sp, #0x1b8]
    33c8:      	b	0x2ba8 <_stogir.vector.validate+0x268>
    33cc:      	mov	x27, x25
    33d0:      	b	0x2de0 <_stogir.vector.validate+0x4a0>

00000000000033d4 <_stogir.copy.validate>:
    33d4:      	sub	sp, sp, #0x10
    33d8:      	sxtw	x1, w1
    33dc:      	lsl	x2, x1, #2
    33e0:      	cmp	x1, #0x0
    33e4:      	cset	w3, gt
    33e8:      	movz	x16, #0x0, lsl #48
    33ec:      	sub	x4, x16, x1
    33f0:      	sub	x5, x4, #0x1
    33f4:      	uxtb	w16, w3
    33f8:      	cmp	w16, wzr
    33fc:      	b.eq	0x343c <_stogir.copy.validate+0x68>
    3400:      	ldr	x4, [x0, #0x8]
    3404:      	cmp	x1, x4
    3408:      	b.ge	0x34a4 <_stogir.copy.validate+0xd0>
    340c:      	add	x4, x0, #0x78
    3410:      	ldr	x4, [x4, #0x8]
    3414:      	cmp	x1, x4
    3418:      	b.ge	0x363c <_stogir.copy.validate+0x268>
    341c:      	ldr	x4, [x0, #0x78]
    3420:      	add	x4, x2, x4
    3424:      	ldr	w4, [x4]
    3428:      	sxtw	x4, w4
    342c:      	cmp	x4, #0x0
    3430:      	cset	w4, ge
    3434:      	ubfx	x4, x4, #0, #8
    3438:      	b	0x3640 <_stogir.copy.validate+0x26c>
    343c:      	cmp	x1, #0x0
    3440:      	b.ge	0x34ac <_stogir.copy.validate+0xd8>
    3444:      	add	x6, x0, #0x28
    3448:      	add	x7, x0, #0x50
    344c:      	ldr	x6, [x6, #0x8]
    3450:      	ldr	x7, [x7, #0x8]
    3454:      	cmp	x6, x7
    3458:      	b.ne	0x3484 <_stogir.copy.validate+0xb0>
    345c:      	cmp	x4, x6
    3460:      	b.gt	0x3644 <_stogir.copy.validate+0x270>
    3464:      	ldr	x4, [x0, #0x50]
    3468:      	add	x4, x4, x5, lsl #2
    346c:      	ldr	w4, [x4]
    3470:      	sxtw	x4, w4
    3474:      	cmp	x4, #0x0
    3478:      	cset	w4, gt
    347c:      	ubfx	x4, x4, #0, #8
    3480:      	b	0x3648 <_stogir.copy.validate+0x274>
    3484:      	movz	x4, #0x0, lsl #48
    3488:      	b	0x34b0 <_stogir.copy.validate+0xdc>
    348c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		000000000000348c:  ARM64_RELOC_PAGE21	l_stogir.360
    3490:      	ldr	x16, [x16]
		0000000000003490:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    3494:      	orr	x0, x16, xzr
    3498:      	mov	x1, #0x1                ; =1
    349c:      	mov	x2, #0x21               ; =33
    34a0:      	b	0x3540 <_stogir.copy.validate+0x16c>
    34a4:      	movz	x4, #0x0, lsl #48
    34a8:      	b	0x34b0 <_stogir.copy.validate+0xdc>
    34ac:      	movz	x4, #0x0, lsl #48
    34b0:      	cmp	x4, #0x0
    34b4:      	b.eq	0x34f0 <_stogir.copy.validate+0x11c>
    34b8:      	uxtb	w16, w3
    34bc:      	cmp	w16, wzr
    34c0:      	b.eq	0x34d8 <_stogir.copy.validate+0x104>
    34c4:      	ldr	x3, [x0]
    34c8:      	add	x3, x3, x1, lsl #4
    34cc:      	ldr	x4, [x3]
    34d0:      	ldr	x3, [x3, #0x8]
    34d4:      	b	0x34e8 <_stogir.copy.validate+0x114>
    34d8:      	ldr	x3, [x0, #0x28]
    34dc:      	add	x3, x3, x5, lsl #4
    34e0:      	ldr	x4, [x3]
    34e4:      	ldr	x3, [x3, #0x8]
    34e8:      	mov	x5, #0x1                ; =1
    34ec:      	b	0x34fc <_stogir.copy.validate+0x128>
    34f0:      	movz	x5, #0x0, lsl #48
    34f4:      	movz	x4, #0x0, lsl #48
    34f8:      	movz	x3, #0x0, lsl #48
    34fc:      	lsr	w5, w5, #0
    3500:      	lsr	x16, x5, #0
    3504:      	cmp	x16, #0x1
    3508:      	b.eq	0x3524 <_stogir.copy.validate+0x150>
    350c:      	b.lo	0x3514 <_stogir.copy.validate+0x140>
    3510:      	b	0x3528 <_stogir.copy.validate+0x154>
    3514:      	cmp	x16, #0x0
    3518:      	b.eq	0x3520 <_stogir.copy.validate+0x14c>
    351c:      	b	0x3528 <_stogir.copy.validate+0x154>
    3520:      	b	0x352c <_stogir.copy.validate+0x158>
    3524:      	b	0x3554 <_stogir.copy.validate+0x180>
    3528:      	b	0x364c <_stogir.copy.validate+0x278>
    352c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		000000000000352c:  ARM64_RELOC_PAGE21	l_stogir.361
    3530:      	ldr	x16, [x16]
		0000000000003530:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    3534:      	orr	x0, x16, xzr
    3538:      	mov	x1, #0x1                ; =1
    353c:      	mov	x2, #0x18               ; =24
    3540:      	str	x1, [x8]
    3544:      	str	x0, [x8, #0x8]
    3548:      	str	x2, [x8, #0x10]
    354c:      	add	sp, sp, #0x10
    3550:      	ret
    3554:      	mov	x16, sp
    3558:      	str	x4, [x16]
    355c:      	mov	x16, sp
    3560:      	str	x3, [x16, #0x8]
    3564:      	cmp	x1, #0x0
    3568:      	b.le	0x348c <_stogir.copy.validate+0xb8>
    356c:      	uxtb	w1, w4
    3570:      	cmp	x1, #0x44
    3574:      	b.ne	0x348c <_stogir.copy.validate+0xb8>
    3578:      	ldr	x1, [x0, #0x78]
    357c:      	add	x1, x2, x1
    3580:      	ldr	w1, [x1]
    3584:      	sxtw	x1, w1
    3588:      	cmp	x1, #0x2
    358c:      	b.ne	0x348c <_stogir.copy.validate+0xb8>
    3590:      	lsr	w4, w4, #0
    3594:      	ubfx	x1, x4, #8, #8
    3598:      	cmp	x1, #0x0
    359c:      	b.eq	0x348c <_stogir.copy.validate+0xb8>
    35a0:      	cmp	x1, #0xd
    35a4:      	b.le	0x35d4 <_stogir.copy.validate+0x200>
    35a8:      	cmp	x1, #0xf
    35ac:      	b.le	0x348c <_stogir.copy.validate+0xb8>
    35b0:      	cmp	x1, #0x80
    35b4:      	b.ge	0x348c <_stogir.copy.validate+0xb8>
    35b8:      	and	x2, x1, #0xf
    35bc:      	lsr	w2, w2, #0
    35c0:      	sxtw	x2, w2
    35c4:      	cmp	x2, #0x1
    35c8:      	b.lt	0x348c <_stogir.copy.validate+0xb8>
    35cc:      	cmp	x2, #0xd
    35d0:      	b.gt	0x348c <_stogir.copy.validate+0xb8>
    35d4:      	mov	x16, sp
    35d8:      	ldr	w2, [x16, #0x4]
    35dc:      	sxtw	x2, w2
    35e0:      	cmp	x2, #0x0
    35e4:      	cset	w3, gt
    35e8:      	movz	x16, #0x0, lsl #48
    35ec:      	sub	x4, x16, x2
    35f0:      	sub	x5, x4, #0x1
    35f4:      	uxtb	w16, w3
    35f8:      	cmp	w16, wzr
    35fc:      	b.eq	0x366c <_stogir.copy.validate+0x298>
    3600:      	ldr	x4, [x0, #0x8]
    3604:      	cmp	x2, x4
    3608:      	b.ge	0x36b4 <_stogir.copy.validate+0x2e0>
    360c:      	add	x4, x0, #0x78
    3610:      	ldr	x4, [x4, #0x8]
    3614:      	cmp	x2, x4
    3618:      	b.ge	0x377c <_stogir.copy.validate+0x3a8>
    361c:      	ldr	x4, [x0, #0x78]
    3620:      	add	x4, x4, x2, lsl #2
    3624:      	ldr	w4, [x4]
    3628:      	sxtw	x4, w4
    362c:      	cmp	x4, #0x0
    3630:      	cset	w4, ge
    3634:      	ubfx	x4, x4, #0, #8
    3638:      	b	0x3780 <_stogir.copy.validate+0x3ac>
    363c:      	movz	x4, #0x0, lsl #48
    3640:      	b	0x34a8 <_stogir.copy.validate+0xd4>
    3644:      	movz	x4, #0x0, lsl #48
    3648:      	b	0x3488 <_stogir.copy.validate+0xb4>
    364c:      	brk	#0
    3650:      	b	0x364c <_stogir.copy.validate+0x278>
    3654:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003654:  ARM64_RELOC_PAGE21	l_stogir.362
    3658:      	ldr	x16, [x16]
		0000000000003658:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    365c:      	orr	x0, x16, xzr
    3660:      	mov	x1, #0x1                ; =1
    3664:      	mov	x2, #0x20               ; =32
    3668:      	b	0x34a0 <_stogir.copy.validate+0xcc>
    366c:      	cmp	x2, #0x0
    3670:      	b.ge	0x36bc <_stogir.copy.validate+0x2e8>
    3674:      	add	x6, x0, #0x28
    3678:      	add	x7, x0, #0x50
    367c:      	ldr	x6, [x6, #0x8]
    3680:      	ldr	x7, [x7, #0x8]
    3684:      	cmp	x6, x7
    3688:      	b.ne	0x3774 <_stogir.copy.validate+0x3a0>
    368c:      	cmp	x4, x6
    3690:      	b.gt	0x3784 <_stogir.copy.validate+0x3b0>
    3694:      	ldr	x4, [x0, #0x50]
    3698:      	add	x4, x4, x5, lsl #2
    369c:      	ldr	w4, [x4]
    36a0:      	sxtw	x4, w4
    36a4:      	cmp	x4, #0x0
    36a8:      	cset	w4, gt
    36ac:      	ubfx	x4, x4, #0, #8
    36b0:      	b	0x3788 <_stogir.copy.validate+0x3b4>
    36b4:      	movz	x4, #0x0, lsl #48
    36b8:      	b	0x36c0 <_stogir.copy.validate+0x2ec>
    36bc:      	movz	x4, #0x0, lsl #48
    36c0:      	cmp	x4, #0x0
    36c4:      	b.eq	0x36f8 <_stogir.copy.validate+0x324>
    36c8:      	uxtb	w16, w3
    36cc:      	cmp	w16, wzr
    36d0:      	b.eq	0x36e4 <_stogir.copy.validate+0x310>
    36d4:      	ldr	x0, [x0]
    36d8:      	add	x0, x0, x2, lsl #4
    36dc:      	ldr	x0, [x0]
    36e0:      	b	0x36f0 <_stogir.copy.validate+0x31c>
    36e4:      	ldr	x0, [x0, #0x28]
    36e8:      	add	x0, x0, x5, lsl #4
    36ec:      	ldr	x0, [x0]
    36f0:      	mov	x2, #0x1                ; =1
    36f4:      	b	0x3700 <_stogir.copy.validate+0x32c>
    36f8:      	movz	x2, #0x0, lsl #48
    36fc:      	movz	x0, #0x0, lsl #48
    3700:      	lsr	w2, w2, #0
    3704:      	lsr	x16, x2, #0
    3708:      	cmp	x16, #0x1
    370c:      	b.eq	0x3728 <_stogir.copy.validate+0x354>
    3710:      	b.lo	0x3718 <_stogir.copy.validate+0x344>
    3714:      	b	0x372c <_stogir.copy.validate+0x358>
    3718:      	cmp	x16, #0x0
    371c:      	b.eq	0x3724 <_stogir.copy.validate+0x350>
    3720:      	b	0x372c <_stogir.copy.validate+0x358>
    3724:      	b	0x3730 <_stogir.copy.validate+0x35c>
    3728:      	b	0x3748 <_stogir.copy.validate+0x374>
    372c:      	b	0x378c <_stogir.copy.validate+0x3b8>
    3730:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003730:  ARM64_RELOC_PAGE21	l_stogir.363
    3734:      	ldr	x16, [x16]
		0000000000003734:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    3738:      	orr	x0, x16, xzr
    373c:      	mov	x1, #0x1                ; =1
    3740:      	mov	x2, #0x13               ; =19
    3744:      	b	0x3668 <_stogir.copy.validate+0x294>
    3748:      	lsr	w0, w0, #0
    374c:      	mov	x16, sp
    3750:      	ldr	w2, [x16]
    3754:      	ubfx	x0, x0, #8, #8
    3758:      	ubfx	x2, x2, #8, #8
    375c:      	cmp	x0, x2
    3760:      	b.ne	0x3654 <_stogir.copy.validate+0x280>
    3764:      	and	x0, x1, #0xffffffff
    3768:      	movz	x1, #0x0, lsl #48
    376c:      	movz	x2, #0x0, lsl #48
    3770:      	b	0x3668 <_stogir.copy.validate+0x294>
    3774:      	movz	x4, #0x0, lsl #48
    3778:      	b	0x36c0 <_stogir.copy.validate+0x2ec>
    377c:      	movz	x4, #0x0, lsl #48
    3780:      	b	0x36b8 <_stogir.copy.validate+0x2e4>
    3784:      	movz	x4, #0x0, lsl #48
    3788:      	b	0x3778 <_stogir.copy.validate+0x3a4>
    378c:      	brk	#0
    3790:      	b	0x378c <_stogir.copy.validate+0x3b8>

0000000000003794 <_stogir.graph.lookup>:
    3794:      	sxtw	x1, w1
    3798:      	cmp	x1, #0x0
    379c:      	cset	w2, gt
    37a0:      	movz	x16, #0x0, lsl #48
    37a4:      	sub	x3, x16, x1
    37a8:      	sub	x4, x3, #0x1
    37ac:      	uxtb	w16, w2
    37b0:      	cmp	w16, wzr
    37b4:      	b.eq	0x37f4 <_stogir.graph.lookup+0x60>
    37b8:      	ldr	x3, [x0, #0x8]
    37bc:      	cmp	x1, x3
    37c0:      	b.ge	0x3844 <_stogir.graph.lookup+0xb0>
    37c4:      	add	x3, x0, #0x78
    37c8:      	ldr	x3, [x3, #0x8]
    37cc:      	cmp	x1, x3
    37d0:      	b.ge	0x38bc <_stogir.graph.lookup+0x128>
    37d4:      	ldr	x3, [x0, #0x78]
    37d8:      	add	x3, x3, x1, lsl #2
    37dc:      	ldr	w3, [x3]
    37e0:      	sxtw	x3, w3
    37e4:      	cmp	x3, #0x0
    37e8:      	cset	w3, ge
    37ec:      	ubfx	x3, x3, #0, #8
    37f0:      	b	0x38c0 <_stogir.graph.lookup+0x12c>
    37f4:      	cmp	x1, #0x0
    37f8:      	b.ge	0x384c <_stogir.graph.lookup+0xb8>
    37fc:      	add	x5, x0, #0x28
    3800:      	add	x6, x0, #0x50
    3804:      	ldr	x5, [x5, #0x8]
    3808:      	ldr	x6, [x6, #0x8]
    380c:      	cmp	x5, x6
    3810:      	b.ne	0x383c <_stogir.graph.lookup+0xa8>
    3814:      	cmp	x3, x5
    3818:      	b.gt	0x38c4 <_stogir.graph.lookup+0x130>
    381c:      	ldr	x3, [x0, #0x50]
    3820:      	add	x3, x3, x4, lsl #2
    3824:      	ldr	w3, [x3]
    3828:      	sxtw	x3, w3
    382c:      	cmp	x3, #0x0
    3830:      	cset	w3, gt
    3834:      	ubfx	x3, x3, #0, #8
    3838:      	b	0x38c8 <_stogir.graph.lookup+0x134>
    383c:      	movz	x3, #0x0, lsl #48
    3840:      	b	0x3850 <_stogir.graph.lookup+0xbc>
    3844:      	movz	x3, #0x0, lsl #48
    3848:      	b	0x3850 <_stogir.graph.lookup+0xbc>
    384c:      	movz	x3, #0x0, lsl #48
    3850:      	cmp	x3, #0x0
    3854:      	b.eq	0x3890 <_stogir.graph.lookup+0xfc>
    3858:      	uxtb	w16, w2
    385c:      	cmp	w16, wzr
    3860:      	b.eq	0x3878 <_stogir.graph.lookup+0xe4>
    3864:      	ldr	x0, [x0]
    3868:      	add	x0, x0, x1, lsl #4
    386c:      	ldr	x1, [x0]
    3870:      	ldr	x0, [x0, #0x8]
    3874:      	b	0x3888 <_stogir.graph.lookup+0xf4>
    3878:      	ldr	x0, [x0, #0x28]
    387c:      	add	x0, x0, x4, lsl #4
    3880:      	ldr	x1, [x0]
    3884:      	ldr	x0, [x0, #0x8]
    3888:      	mov	x2, #0x1                ; =1
    388c:      	b	0x389c <_stogir.graph.lookup+0x108>
    3890:      	movz	x2, #0x0, lsl #48
    3894:      	movz	x1, #0x0, lsl #48
    3898:      	movz	x0, #0x0, lsl #48
    389c:      	str	x2, [x8]
    38a0:      	str	x1, [x8, #0x8]
    38a4:      	str	x0, [x8, #0x10]
    38a8:      	movz	x17, #0x0, lsl #48
    38ac:      	str	x17, [x8, #0x18]
    38b0:      	movz	x17, #0x0, lsl #48
    38b4:      	str	x17, [x8, #0x20]
    38b8:      	ret
    38bc:      	movz	x3, #0x0, lsl #48
    38c0:      	b	0x3848 <_stogir.graph.lookup+0xb4>
    38c4:      	movz	x3, #0x0, lsl #48
    38c8:      	b	0x3840 <_stogir.graph.lookup+0xac>

00000000000038cc <_stogir.checked.validate-projection>:
    38cc:      	sub	sp, sp, #0x40
    38d0:      	str	x29, [sp]
    38d4:      	str	x30, [sp, #0x8]
    38d8:      	mov	x29, sp
    38dc:      	str	x19, [sp, #0x30]
    38e0:      	sxtw	x1, w1
    38e4:      	lsl	x2, x1, #2
    38e8:      	cmp	x1, #0x0
    38ec:      	cset	w3, gt
    38f0:      	movz	x16, #0x0, lsl #48
    38f4:      	sub	x4, x16, x1
    38f8:      	sub	x5, x4, #0x1
    38fc:      	uxtb	w16, w3
    3900:      	cmp	w16, wzr
    3904:      	b.eq	0x3944 <_stogir.checked.validate-projection+0x78>
    3908:      	ldr	x4, [x0, #0x8]
    390c:      	cmp	x1, x4
    3910:      	b.ge	0x3994 <_stogir.checked.validate-projection+0xc8>
    3914:      	add	x4, x0, #0x78
    3918:      	ldr	x4, [x4, #0x8]
    391c:      	cmp	x1, x4
    3920:      	b.ge	0x3a6c <_stogir.checked.validate-projection+0x1a0>
    3924:      	ldr	x4, [x0, #0x78]
    3928:      	add	x4, x2, x4
    392c:      	ldr	w4, [x4]
    3930:      	sxtw	x4, w4
    3934:      	cmp	x4, #0x0
    3938:      	cset	w4, ge
    393c:      	ubfx	x4, x4, #0, #8
    3940:      	b	0x3a70 <_stogir.checked.validate-projection+0x1a4>
    3944:      	cmp	x1, #0x0
    3948:      	b.ge	0x399c <_stogir.checked.validate-projection+0xd0>
    394c:      	add	x6, x0, #0x28
    3950:      	add	x7, x0, #0x50
    3954:      	ldr	x6, [x6, #0x8]
    3958:      	ldr	x7, [x7, #0x8]
    395c:      	cmp	x6, x7
    3960:      	b.ne	0x398c <_stogir.checked.validate-projection+0xc0>
    3964:      	cmp	x4, x6
    3968:      	b.gt	0x3ad8 <_stogir.checked.validate-projection+0x20c>
    396c:      	ldr	x4, [x0, #0x50]
    3970:      	add	x4, x4, x5, lsl #2
    3974:      	ldr	w4, [x4]
    3978:      	sxtw	x4, w4
    397c:      	cmp	x4, #0x0
    3980:      	cset	w4, gt
    3984:      	ubfx	x4, x4, #0, #8
    3988:      	b	0x3adc <_stogir.checked.validate-projection+0x210>
    398c:      	movz	x4, #0x0, lsl #48
    3990:      	b	0x39a0 <_stogir.checked.validate-projection+0xd4>
    3994:      	movz	x4, #0x0, lsl #48
    3998:      	b	0x39a0 <_stogir.checked.validate-projection+0xd4>
    399c:      	movz	x4, #0x0, lsl #48
    39a0:      	cmp	x4, #0x0
    39a4:      	b.eq	0x39d8 <_stogir.checked.validate-projection+0x10c>
    39a8:      	uxtb	w16, w3
    39ac:      	cmp	w16, wzr
    39b0:      	b.eq	0x39c4 <_stogir.checked.validate-projection+0xf8>
    39b4:      	ldr	x3, [x0]
    39b8:      	add	x3, x3, x1, lsl #4
    39bc:      	ldr	x3, [x3]
    39c0:      	b	0x39d0 <_stogir.checked.validate-projection+0x104>
    39c4:      	ldr	x3, [x0, #0x28]
    39c8:      	add	x3, x3, x5, lsl #4
    39cc:      	ldr	x3, [x3]
    39d0:      	mov	x4, #0x1                ; =1
    39d4:      	b	0x39e0 <_stogir.checked.validate-projection+0x114>
    39d8:      	movz	x4, #0x0, lsl #48
    39dc:      	movz	x3, #0x0, lsl #48
    39e0:      	lsr	w4, w4, #0
    39e4:      	lsr	x16, x4, #0
    39e8:      	cmp	x16, #0x1
    39ec:      	b.eq	0x3a08 <_stogir.checked.validate-projection+0x13c>
    39f0:      	b.lo	0x39f8 <_stogir.checked.validate-projection+0x12c>
    39f4:      	b	0x3a0c <_stogir.checked.validate-projection+0x140>
    39f8:      	cmp	x16, #0x0
    39fc:      	b.eq	0x3a04 <_stogir.checked.validate-projection+0x138>
    3a00:      	b	0x3a0c <_stogir.checked.validate-projection+0x140>
    3a04:      	b	0x3a10 <_stogir.checked.validate-projection+0x144>
    3a08:      	b	0x3a2c <_stogir.checked.validate-projection+0x160>
    3a0c:      	b	0x3ae0 <_stogir.checked.validate-projection+0x214>
    3a10:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003a10:  ARM64_RELOC_PAGE21	l_stogir.364
    3a14:      	ldr	x16, [x16]
		0000000000003a14:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    3a18:      	orr	x0, x16, xzr
    3a1c:      	mov	x19, x8
    3a20:      	mov	x1, #0x1                ; =1
    3a24:      	mov	x2, #0x10               ; =16
    3a28:      	b	0x3a4c <_stogir.checked.validate-projection+0x180>
    3a2c:      	cmp	x1, #0x0
    3a30:      	b.gt	0x3a74 <_stogir.checked.validate-projection+0x1a8>
    3a34:      	mov	x19, x8
    3a38:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003a38:  ARM64_RELOC_PAGE21	l_stogir.365
    3a3c:      	ldr	x16, [x16]
		0000000000003a3c:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    3a40:      	orr	x0, x16, xzr
    3a44:      	mov	x1, #0x1                ; =1
    3a48:      	mov	x2, #0x1c               ; =28
    3a4c:      	str	x1, [x19]
    3a50:      	str	x0, [x19, #0x8]
    3a54:      	str	x2, [x19, #0x10]
    3a58:      	ldr	x19, [sp, #0x30]
    3a5c:      	ldr	x29, [sp]
    3a60:      	ldr	x30, [sp, #0x8]
    3a64:      	add	sp, sp, #0x40
    3a68:      	ret
    3a6c:      	movz	x4, #0x0, lsl #48
    3a70:      	b	0x3998 <_stogir.checked.validate-projection+0xcc>
    3a74:      	uxtb	w1, w3
    3a78:      	cmp	x1, #0x2c
    3a7c:      	b.ne	0x3ae8 <_stogir.checked.validate-projection+0x21c>
    3a80:      	lsr	w1, w3, #0
    3a84:      	ubfx	x1, x1, #8, #8
    3a88:      	cmp	x1, #0x1
    3a8c:      	b.ne	0x3af0 <_stogir.checked.validate-projection+0x224>
    3a90:      	ldr	x1, [x0, #0x78]
    3a94:      	add	x1, x2, x1
    3a98:      	ldr	w1, [x1]
    3a9c:      	sxtw	x1, w1
    3aa0:      	cmp	x1, #0x1
    3aa4:      	b.ne	0x3af8 <_stogir.checked.validate-projection+0x22c>
    3aa8:      	lsr	x1, x3, #32
    3aac:      	lsr	w1, w1, #0
    3ab0:      	mov	x19, x8
    3ab4:      	add	x8, sp, #0x10
    3ab8:      	bl	0x3ab8 <_stogir.checked.validate-projection+0x1ec>
		0000000000003ab8:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    3abc:      	add	x16, sp, #0x10
    3ac0:      	ldr	x1, [x16]
    3ac4:      	add	x16, sp, #0x10
    3ac8:      	ldr	x0, [x16, #0x8]
    3acc:      	add	x16, sp, #0x10
    3ad0:      	ldr	x2, [x16, #0x10]
    3ad4:      	b	0x3a4c <_stogir.checked.validate-projection+0x180>
    3ad8:      	movz	x4, #0x0, lsl #48
    3adc:      	b	0x3990 <_stogir.checked.validate-projection+0xc4>
    3ae0:      	brk	#0
    3ae4:      	b	0x3ae0 <_stogir.checked.validate-projection+0x214>
    3ae8:      	mov	x19, x8
    3aec:      	b	0x3a38 <_stogir.checked.validate-projection+0x16c>
    3af0:      	mov	x19, x8
    3af4:      	b	0x3a38 <_stogir.checked.validate-projection+0x16c>
    3af8:      	mov	x19, x8
    3afc:      	b	0x3a38 <_stogir.checked.validate-projection+0x16c>

0000000000003b00 <_stogir.checked.validate>:
    3b00:      	sub	sp, sp, #0x30
    3b04:      	str	x29, [sp]
    3b08:      	str	x30, [sp, #0x8]
    3b0c:      	mov	x29, sp
    3b10:      	str	x19, [sp, #0x10]
    3b14:      	str	x20, [sp, #0x18]
    3b18:      	str	x21, [sp, #0x20]
    3b1c:      	sxtw	x1, w1
    3b20:      	lsl	x2, x1, #2
    3b24:      	cmp	x1, #0x0
    3b28:      	cset	w3, gt
    3b2c:      	movz	x16, #0x0, lsl #48
    3b30:      	sub	x4, x16, x1
    3b34:      	sub	x5, x4, #0x1
    3b38:      	uxtb	w16, w3
    3b3c:      	cmp	w16, wzr
    3b40:      	b.eq	0x3b80 <_stogir.checked.validate+0x80>
    3b44:      	ldr	x4, [x0, #0x8]
    3b48:      	cmp	x1, x4
    3b4c:      	b.ge	0x3bd0 <_stogir.checked.validate+0xd0>
    3b50:      	add	x4, x0, #0x78
    3b54:      	ldr	x4, [x4, #0x8]
    3b58:      	cmp	x1, x4
    3b5c:      	b.ge	0x3d30 <_stogir.checked.validate+0x230>
    3b60:      	ldr	x4, [x0, #0x78]
    3b64:      	add	x4, x2, x4
    3b68:      	ldr	w4, [x4]
    3b6c:      	sxtw	x4, w4
    3b70:      	cmp	x4, #0x0
    3b74:      	cset	w4, ge
    3b78:      	ubfx	x4, x4, #0, #8
    3b7c:      	b	0x3d34 <_stogir.checked.validate+0x234>
    3b80:      	cmp	x1, #0x0
    3b84:      	b.ge	0x3bd8 <_stogir.checked.validate+0xd8>
    3b88:      	add	x6, x0, #0x28
    3b8c:      	add	x7, x0, #0x50
    3b90:      	ldr	x6, [x6, #0x8]
    3b94:      	ldr	x7, [x7, #0x8]
    3b98:      	cmp	x6, x7
    3b9c:      	b.ne	0x3bc8 <_stogir.checked.validate+0xc8>
    3ba0:      	cmp	x4, x6
    3ba4:      	b.gt	0x3d38 <_stogir.checked.validate+0x238>
    3ba8:      	ldr	x4, [x0, #0x50]
    3bac:      	add	x4, x4, x5, lsl #2
    3bb0:      	ldr	w4, [x4]
    3bb4:      	sxtw	x4, w4
    3bb8:      	cmp	x4, #0x0
    3bbc:      	cset	w4, gt
    3bc0:      	ubfx	x4, x4, #0, #8
    3bc4:      	b	0x3d3c <_stogir.checked.validate+0x23c>
    3bc8:      	movz	x4, #0x0, lsl #48
    3bcc:      	b	0x3bdc <_stogir.checked.validate+0xdc>
    3bd0:      	movz	x4, #0x0, lsl #48
    3bd4:      	b	0x3bdc <_stogir.checked.validate+0xdc>
    3bd8:      	movz	x4, #0x0, lsl #48
    3bdc:      	cmp	x4, #0x0
    3be0:      	b.eq	0x3c1c <_stogir.checked.validate+0x11c>
    3be4:      	uxtb	w16, w3
    3be8:      	cmp	w16, wzr
    3bec:      	b.eq	0x3c04 <_stogir.checked.validate+0x104>
    3bf0:      	ldr	x3, [x0]
    3bf4:      	add	x3, x3, x1, lsl #4
    3bf8:      	ldr	x4, [x3]
    3bfc:      	ldr	x3, [x3, #0x8]
    3c00:      	b	0x3c14 <_stogir.checked.validate+0x114>
    3c04:      	ldr	x3, [x0, #0x28]
    3c08:      	add	x3, x3, x5, lsl #4
    3c0c:      	ldr	x4, [x3]
    3c10:      	ldr	x3, [x3, #0x8]
    3c14:      	mov	x5, #0x1                ; =1
    3c18:      	b	0x3c28 <_stogir.checked.validate+0x128>
    3c1c:      	movz	x5, #0x0, lsl #48
    3c20:      	movz	x4, #0x0, lsl #48
    3c24:      	movz	x3, #0x0, lsl #48
    3c28:      	lsr	w5, w5, #0
    3c2c:      	lsr	x16, x5, #0
    3c30:      	cmp	x16, #0x1
    3c34:      	b.eq	0x3c50 <_stogir.checked.validate+0x150>
    3c38:      	b.lo	0x3c40 <_stogir.checked.validate+0x140>
    3c3c:      	b	0x3c54 <_stogir.checked.validate+0x154>
    3c40:      	cmp	x16, #0x0
    3c44:      	b.eq	0x3c4c <_stogir.checked.validate+0x14c>
    3c48:      	b	0x3c54 <_stogir.checked.validate+0x154>
    3c4c:      	b	0x3c58 <_stogir.checked.validate+0x158>
    3c50:      	b	0x3cb0 <_stogir.checked.validate+0x1b0>
    3c54:      	b	0x3f74 <_stogir.checked.validate+0x474>
    3c58:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003c58:  ARM64_RELOC_PAGE21	l_stogir.366
    3c5c:      	ldr	x16, [x16]
		0000000000003c5c:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    3c60:      	orr	x1, x16, xzr
    3c64:      	mov	x0, #0x1                ; =1
    3c68:      	mov	x9, #0x1a               ; =26
    3c6c:      	b	0x3c84 <_stogir.checked.validate+0x184>
    3c70:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003c70:  ARM64_RELOC_PAGE21	l_stogir.367
    3c74:      	ldr	x16, [x16]
		0000000000003c74:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    3c78:      	orr	x1, x16, xzr
    3c7c:      	mov	x0, #0x1                ; =1
    3c80:      	mov	x9, #0x26               ; =38
    3c84:      	str	x0, [x8]
    3c88:      	str	x1, [x8, #0x8]
    3c8c:      	str	x9, [x8, #0x10]
    3c90:      	sub	sp, x29, #0x0
    3c94:      	ldr	x19, [sp, #0x10]
    3c98:      	ldr	x20, [sp, #0x18]
    3c9c:      	ldr	x21, [sp, #0x20]
    3ca0:      	ldr	x29, [sp]
    3ca4:      	ldr	x30, [sp, #0x8]
    3ca8:      	add	sp, sp, #0x30
    3cac:      	ret
    3cb0:      	cmp	x1, #0x0
    3cb4:      	b.le	0x3c70 <_stogir.checked.validate+0x170>
    3cb8:      	uxtb	w1, w4
    3cbc:      	cmp	x1, #0x29
    3cc0:      	b.lt	0x3c70 <_stogir.checked.validate+0x170>
    3cc4:      	cmp	x1, #0x2b
    3cc8:      	b.gt	0x3c70 <_stogir.checked.validate+0x170>
    3ccc:      	ldr	x1, [x0, #0x78]
    3cd0:      	add	x1, x2, x1
    3cd4:      	ldr	w1, [x1]
    3cd8:      	sxtw	x1, w1
    3cdc:      	cmp	x1, #0x2
    3ce0:      	b.ne	0x3c70 <_stogir.checked.validate+0x170>
    3ce4:      	lsr	w1, w4, #0
    3ce8:      	mov	x2, sp
    3cec:      	sub	sp, sp, #0x10
    3cf0:      	mov	x5, sp
    3cf4:      	sub	sp, sp, #0x10
    3cf8:      	mov	x6, sp
    3cfc:      	ubfx	x1, x1, #8, #8
    3d00:      	orr	x7, x1, xzr
    3d04:      	cmp	x7, #0x1
    3d08:      	b.lt	0x3f04 <_stogir.checked.validate+0x404>
    3d0c:      	cmp	x7, #0xb
    3d10:      	b.gt	0x3f04 <_stogir.checked.validate+0x404>
    3d14:      	cmp	x7, #0x1
    3d18:      	b.eq	0x3f04 <_stogir.checked.validate+0x404>
    3d1c:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003d1c:  ARM64_RELOC_PAGE21	l_stogir.368
    3d20:      	ldr	x16, [x16]
		0000000000003d20:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    3d24:      	orr	x1, x16, xzr
    3d28:      	movz	x9, #0x0, lsl #48
    3d2c:      	b	0x3f14 <_stogir.checked.validate+0x414>
    3d30:      	movz	x4, #0x0, lsl #48
    3d34:      	b	0x3bd4 <_stogir.checked.validate+0xd4>
    3d38:      	movz	x4, #0x0, lsl #48
    3d3c:      	b	0x3bcc <_stogir.checked.validate+0xcc>
    3d40:      	mov	x0, #0x1                ; =1
    3d44:      	mov	sp, x2
    3d48:      	b	0x3c84 <_stogir.checked.validate+0x184>
    3d4c:      	movz	x5, #0x0, lsl #48
    3d50:      	movz	x4, #0x0, lsl #48
    3d54:      	lsr	w5, w5, #0
    3d58:      	lsr	x16, x5, #0
    3d5c:      	cmp	x16, #0x1
    3d60:      	b.eq	0x3d7c <_stogir.checked.validate+0x27c>
    3d64:      	b.lo	0x3d6c <_stogir.checked.validate+0x26c>
    3d68:      	b	0x3d80 <_stogir.checked.validate+0x280>
    3d6c:      	cmp	x16, #0x0
    3d70:      	b.eq	0x3d78 <_stogir.checked.validate+0x278>
    3d74:      	b	0x3d80 <_stogir.checked.validate+0x280>
    3d78:      	b	0x3d84 <_stogir.checked.validate+0x284>
    3d7c:      	b	0x3ee8 <_stogir.checked.validate+0x3e8>
    3d80:      	b	0x3f8c <_stogir.checked.validate+0x48c>
    3d84:      	mov	x1, x11
    3d88:      	mov	x9, #0x22               ; =34
    3d8c:      	cmp	x3, #0x2
    3d90:      	b.ge	0x3db4 <_stogir.checked.validate+0x2b4>
    3d94:      	add	x4, x3, #0x1
    3d98:      	add	x3, x10, x3, lsl #2
    3d9c:      	ldr	w3, [x3]
    3da0:      	sxtw	x3, w3
    3da4:      	and	x5, x3, #0xffffffff
    3da8:      	mov	x3, x4
    3dac:      	mov	x4, #0x1                ; =1
    3db0:      	b	0x3dbc <_stogir.checked.validate+0x2bc>
    3db4:      	movz	x4, #0x0, lsl #48
    3db8:      	movz	x5, #0x0, lsl #48
    3dbc:      	lsr	w4, w4, #0
    3dc0:      	lsr	x16, x4, #0
    3dc4:      	cmp	x16, #0x1
    3dc8:      	b.eq	0x3de4 <_stogir.checked.validate+0x2e4>
    3dcc:      	b.lo	0x3dd4 <_stogir.checked.validate+0x2d4>
    3dd0:      	b	0x3de8 <_stogir.checked.validate+0x2e8>
    3dd4:      	cmp	x16, #0x0
    3dd8:      	b.eq	0x3de0 <_stogir.checked.validate+0x2e0>
    3ddc:      	b	0x3de8 <_stogir.checked.validate+0x2e8>
    3de0:      	b	0x3e4c <_stogir.checked.validate+0x34c>
    3de4:      	b	0x3dec <_stogir.checked.validate+0x2ec>
    3de8:      	b	0x3f84 <_stogir.checked.validate+0x484>
    3dec:      	lsr	w5, w5, #0
    3df0:      	sxtw	x5, w5
    3df4:      	cmp	x5, #0x0
    3df8:      	cset	w4, gt
    3dfc:      	movz	x16, #0x0, lsl #48
    3e00:      	sub	x6, x16, x5
    3e04:      	sub	x19, x6, #0x1
    3e08:      	uxtb	w16, w4
    3e0c:      	cmp	w16, wzr
    3e10:      	b.eq	0x3ea8 <_stogir.checked.validate+0x3a8>
    3e14:      	ldr	x6, [x0, #0x8]
    3e18:      	cmp	x5, x6
    3e1c:      	b.ge	0x3ea0 <_stogir.checked.validate+0x3a0>
    3e20:      	ldr	x6, [x13, #0x8]
    3e24:      	cmp	x5, x6
    3e28:      	b.ge	0x3f6c <_stogir.checked.validate+0x46c>
    3e2c:      	ldr	x6, [x0, #0x78]
    3e30:      	add	x6, x6, x5, lsl #2
    3e34:      	ldr	w6, [x6]
    3e38:      	sxtw	x6, w6
    3e3c:      	cmp	x6, #0x0
    3e40:      	cset	w6, ge
    3e44:      	ubfx	x6, x6, #0, #8
    3e48:      	b	0x3f70 <_stogir.checked.validate+0x470>
    3e4c:      	cmp	x9, #0x0
    3e50:      	b.ne	0x3d40 <_stogir.checked.validate+0x240>
    3e54:      	and	x1, x7, #0xffffffff
    3e58:      	movz	x0, #0x0, lsl #48
    3e5c:      	movz	x9, #0x0, lsl #48
    3e60:      	b	0x3d44 <_stogir.checked.validate+0x244>
    3e64:      	ldr	x4, [x0, #0x28]
    3e68:      	add	x4, x4, x19, lsl #4
    3e6c:      	ldr	x4, [x4]
    3e70:      	mov	x5, #0x1                ; =1
    3e74:      	b	0x3d54 <_stogir.checked.validate+0x254>
    3e78:      	movz	x6, #0x0, lsl #48
    3e7c:      	cmp	x6, #0x0
    3e80:      	b.eq	0x3d4c <_stogir.checked.validate+0x24c>
    3e84:      	uxtb	w16, w4
    3e88:      	cmp	w16, wzr
    3e8c:      	b.eq	0x3e64 <_stogir.checked.validate+0x364>
    3e90:      	ldr	x4, [x0]
    3e94:      	add	x4, x4, x5, lsl #4
    3e98:      	ldr	x4, [x4]
    3e9c:      	b	0x3e70 <_stogir.checked.validate+0x370>
    3ea0:      	movz	x6, #0x0, lsl #48
    3ea4:      	b	0x3e7c <_stogir.checked.validate+0x37c>
    3ea8:      	cmp	x5, #0x0
    3eac:      	b.ge	0x3e78 <_stogir.checked.validate+0x378>
    3eb0:      	ldr	x20, [x14, #0x8]
    3eb4:      	ldr	x21, [x15, #0x8]
    3eb8:      	cmp	x20, x21
    3ebc:      	b.ne	0x3f64 <_stogir.checked.validate+0x464>
    3ec0:      	cmp	x6, x20
    3ec4:      	b.gt	0x3f7c <_stogir.checked.validate+0x47c>
    3ec8:      	ldr	x6, [x0, #0x50]
    3ecc:      	add	x6, x6, x19, lsl #2
    3ed0:      	ldr	w6, [x6]
    3ed4:      	sxtw	x6, w6
    3ed8:      	cmp	x6, #0x0
    3edc:      	cset	w6, gt
    3ee0:      	ubfx	x6, x6, #0, #8
    3ee4:      	b	0x3f80 <_stogir.checked.validate+0x480>
    3ee8:      	lsr	w4, w4, #0
    3eec:      	ubfx	x4, x4, #8, #8
    3ef0:      	cmp	x4, x7
    3ef4:      	b.eq	0x3f00 <_stogir.checked.validate+0x400>
    3ef8:      	mov	x1, x12
    3efc:      	mov	x9, #0x28               ; =40
    3f00:      	b	0x3d8c <_stogir.checked.validate+0x28c>
    3f04:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003f04:  ARM64_RELOC_PAGE21	l_stogir.369
    3f08:      	ldr	x16, [x16]
		0000000000003f08:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    3f0c:      	orr	x1, x16, xzr
    3f10:      	mov	x9, #0x36               ; =54
    3f14:      	orr	x10, x6, xzr
    3f18:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003f18:  ARM64_RELOC_PAGE21	l_stogir.370
    3f1c:      	ldr	x16, [x16]
		0000000000003f1c:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    3f20:      	orr	x11, x16, xzr
    3f24:      	adrp	x16, 0x3000 <_stogir.vector.validate+0x6c0>
		0000000000003f24:  ARM64_RELOC_PAGE21	l_stogir.371
    3f28:      	ldr	x16, [x16]
		0000000000003f28:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    3f2c:      	orr	x12, x16, xzr
    3f30:      	add	x13, x0, #0x78
    3f34:      	add	x14, x0, #0x28
    3f38:      	add	x15, x0, #0x50
    3f3c:      	lsr	w3, w3, #0
    3f40:      	lsr	x4, x4, #32
    3f44:      	lsr	w3, w3, #0
    3f48:      	lsr	w4, w4, #0
    3f4c:      	str	w4, [x5]
    3f50:      	str	w3, [x5, #0x4]
    3f54:      	ldr	x3, [x5]
    3f58:      	str	x3, [x6]
    3f5c:      	movz	x3, #0x0, lsl #48
    3f60:      	b	0x3d8c <_stogir.checked.validate+0x28c>
    3f64:      	movz	x6, #0x0, lsl #48
    3f68:      	b	0x3e7c <_stogir.checked.validate+0x37c>
    3f6c:      	movz	x6, #0x0, lsl #48
    3f70:      	b	0x3ea4 <_stogir.checked.validate+0x3a4>
    3f74:      	brk	#0
    3f78:      	b	0x3f74 <_stogir.checked.validate+0x474>
    3f7c:      	movz	x6, #0x0, lsl #48
    3f80:      	b	0x3f68 <_stogir.checked.validate+0x468>
    3f84:      	brk	#0
    3f88:      	b	0x3f84 <_stogir.checked.validate+0x484>
    3f8c:      	brk	#0
    3f90:      	b	0x3f8c <_stogir.checked.validate+0x48c>

0000000000003f94 <_stogir.atomic.validate>:
    3f94:      	sub	sp, sp, #0xf0
    3f98:      	str	x29, [sp, #0x10]
    3f9c:      	str	x30, [sp, #0x18]
    3fa0:      	add	x29, sp, #0x10
    3fa4:      	str	x19, [sp, #0xa0]
    3fa8:      	str	x20, [sp, #0xa8]
    3fac:      	str	x21, [sp, #0xb0]
    3fb0:      	str	x22, [sp, #0xb8]
    3fb4:      	str	x23, [sp, #0xc0]
    3fb8:      	str	x24, [sp, #0xc8]
    3fbc:      	str	x25, [sp, #0xd0]
    3fc0:      	str	x26, [sp, #0xd8]
    3fc4:      	str	x27, [sp, #0xe0]
    3fc8:      	sxtw	x2, w1
    3fcc:      	lsl	x3, x2, #2
    3fd0:      	cmp	x2, #0x0
    3fd4:      	cset	w4, gt
    3fd8:      	movz	x16, #0x0, lsl #48
    3fdc:      	sub	x5, x16, x2
    3fe0:      	sub	x6, x5, #0x1
    3fe4:      	uxtb	w16, w4
    3fe8:      	cmp	w16, wzr
    3fec:      	b.eq	0x402c <_stogir.atomic.validate+0x98>
    3ff0:      	ldr	x5, [x0, #0x8]
    3ff4:      	cmp	x2, x5
    3ff8:      	b.ge	0x407c <_stogir.atomic.validate+0xe8>
    3ffc:      	add	x5, x0, #0x78
    4000:      	ldr	x5, [x5, #0x8]
    4004:      	cmp	x2, x5
    4008:      	b.ge	0x41bc <_stogir.atomic.validate+0x228>
    400c:      	ldr	x5, [x0, #0x78]
    4010:      	add	x5, x3, x5
    4014:      	ldr	w5, [x5]
    4018:      	sxtw	x5, w5
    401c:      	cmp	x5, #0x0
    4020:      	cset	w5, ge
    4024:      	ubfx	x5, x5, #0, #8
    4028:      	b	0x41c0 <_stogir.atomic.validate+0x22c>
    402c:      	cmp	x2, #0x0
    4030:      	b.ge	0x4084 <_stogir.atomic.validate+0xf0>
    4034:      	add	x7, x0, #0x28
    4038:      	add	x9, x0, #0x50
    403c:      	ldr	x7, [x7, #0x8]
    4040:      	ldr	x9, [x9, #0x8]
    4044:      	cmp	x7, x9
    4048:      	b.ne	0x4074 <_stogir.atomic.validate+0xe0>
    404c:      	cmp	x5, x7
    4050:      	b.gt	0x4248 <_stogir.atomic.validate+0x2b4>
    4054:      	ldr	x5, [x0, #0x50]
    4058:      	add	x5, x5, x6, lsl #2
    405c:      	ldr	w5, [x5]
    4060:      	sxtw	x5, w5
    4064:      	cmp	x5, #0x0
    4068:      	cset	w5, gt
    406c:      	ubfx	x5, x5, #0, #8
    4070:      	b	0x424c <_stogir.atomic.validate+0x2b8>
    4074:      	movz	x5, #0x0, lsl #48
    4078:      	b	0x4088 <_stogir.atomic.validate+0xf4>
    407c:      	movz	x5, #0x0, lsl #48
    4080:      	b	0x4088 <_stogir.atomic.validate+0xf4>
    4084:      	movz	x5, #0x0, lsl #48
    4088:      	cmp	x5, #0x0
    408c:      	b.eq	0x40c8 <_stogir.atomic.validate+0x134>
    4090:      	uxtb	w16, w4
    4094:      	cmp	w16, wzr
    4098:      	b.eq	0x40b0 <_stogir.atomic.validate+0x11c>
    409c:      	ldr	x4, [x0]
    40a0:      	add	x4, x4, x2, lsl #4
    40a4:      	ldr	x19, [x4]
    40a8:      	ldr	x4, [x4, #0x8]
    40ac:      	b	0x40c0 <_stogir.atomic.validate+0x12c>
    40b0:      	ldr	x4, [x0, #0x28]
    40b4:      	add	x4, x4, x6, lsl #4
    40b8:      	ldr	x19, [x4]
    40bc:      	ldr	x4, [x4, #0x8]
    40c0:      	mov	x5, #0x1                ; =1
    40c4:      	b	0x40d4 <_stogir.atomic.validate+0x140>
    40c8:      	movz	x5, #0x0, lsl #48
    40cc:      	movz	x19, #0x0, lsl #48
    40d0:      	movz	x4, #0x0, lsl #48
    40d4:      	lsr	w5, w5, #0
    40d8:      	lsr	x16, x5, #0
    40dc:      	cmp	x16, #0x1
    40e0:      	b.eq	0x40fc <_stogir.atomic.validate+0x168>
    40e4:      	b.lo	0x40ec <_stogir.atomic.validate+0x158>
    40e8:      	b	0x4100 <_stogir.atomic.validate+0x16c>
    40ec:      	cmp	x16, #0x0
    40f0:      	b.eq	0x40f8 <_stogir.atomic.validate+0x164>
    40f4:      	b	0x4100 <_stogir.atomic.validate+0x16c>
    40f8:      	b	0x4104 <_stogir.atomic.validate+0x170>
    40fc:      	b	0x415c <_stogir.atomic.validate+0x1c8>
    4100:      	b	0x4728 <_stogir.atomic.validate+0x794>
    4104:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004104:  ARM64_RELOC_PAGE21	l_stogir.372
    4108:      	ldr	x16, [x16]
		0000000000004108:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    410c:      	orr	x20, x16, xzr
    4110:      	mov	x23, x8
    4114:      	mov	x0, #0x1                ; =1
    4118:      	mov	x22, #0x1a              ; =26
    411c:      	str	x0, [x23]
    4120:      	str	x20, [x23, #0x8]
    4124:      	str	x22, [x23, #0x10]
    4128:      	ldr	x19, [sp, #0xa0]
    412c:      	ldr	x20, [sp, #0xa8]
    4130:      	ldr	x21, [sp, #0xb0]
    4134:      	ldr	x22, [sp, #0xb8]
    4138:      	ldr	x23, [sp, #0xc0]
    413c:      	ldr	x24, [sp, #0xc8]
    4140:      	ldr	x25, [sp, #0xd0]
    4144:      	ldr	x26, [sp, #0xd8]
    4148:      	ldr	x27, [sp, #0xe0]
    414c:      	ldr	x29, [sp, #0x10]
    4150:      	ldr	x30, [sp, #0x18]
    4154:      	add	sp, sp, #0xf0
    4158:      	ret
    415c:      	uxtb	w5, w19
    4160:      	add	x16, sp, #0x20
    4164:      	str	x19, [x16]
    4168:      	orr	x21, x5, xzr
    416c:      	add	x16, sp, #0x20
    4170:      	str	x4, [x16, #0x8]
    4174:      	cmp	x2, #0x0
    4178:      	b.le	0x41cc <_stogir.atomic.validate+0x238>
    417c:      	cmp	x21, #0x7e
    4180:      	b.lt	0x41cc <_stogir.atomic.validate+0x238>
    4184:      	cmp	x21, #0x82
    4188:      	b.gt	0x41cc <_stogir.atomic.validate+0x238>
    418c:      	ldr	x2, [x0, #0x78]
    4190:      	add	x2, x3, x2
    4194:      	ldr	w2, [x2]
    4198:      	cmp	x21, #0x83
    419c:      	b.ge	0x4654 <_stogir.atomic.validate+0x6c0>
    41a0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000041a0:  ARM64_RELOC_PAGE21	l_stogir.373
    41a4:      	ldr	x16, [x16]
		00000000000041a4:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    41a8:      	orr	x3, x16, xzr
    41ac:      	add	x3, x21, x3
    41b0:      	ldrsb	w3, [x3]
    41b4:      	sxtb	x3, w3
    41b8:      	b	0x4658 <_stogir.atomic.validate+0x6c4>
    41bc:      	movz	x5, #0x0, lsl #48
    41c0:      	b	0x4080 <_stogir.atomic.validate+0xec>
    41c4:      	mov	x0, #0x1                ; =1
    41c8:      	b	0x411c <_stogir.atomic.validate+0x188>
    41cc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000041cc:  ARM64_RELOC_PAGE21	l_stogir.374
    41d0:      	ldr	x16, [x16]
		00000000000041d0:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    41d4:      	orr	x20, x16, xzr
    41d8:      	mov	x22, #0x20              ; =32
    41dc:      	add	x16, sp, #0x20
    41e0:      	ldr	w2, [x16, #0x4]
    41e4:      	lsr	w2, w2, #0
    41e8:      	mov	x23, x8
    41ec:      	add	x8, sp, #0x30
    41f0:      	mov	x24, x0
    41f4:      	mov	w25, w1
    41f8:      	mov	w1, w2
    41fc:      	bl	0x41fc <_stogir.atomic.validate+0x268>
		00000000000041fc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4200:      	add	x16, sp, #0x30
    4204:      	ldr	w0, [x16]
    4208:      	lsr	x16, x0, #0
    420c:      	cmp	x16, #0x1
    4210:      	b.eq	0x422c <_stogir.atomic.validate+0x298>
    4214:      	b.lo	0x421c <_stogir.atomic.validate+0x288>
    4218:      	b	0x4230 <_stogir.atomic.validate+0x29c>
    421c:      	cmp	x16, #0x0
    4220:      	b.eq	0x4228 <_stogir.atomic.validate+0x294>
    4224:      	b	0x4230 <_stogir.atomic.validate+0x29c>
    4228:      	b	0x4234 <_stogir.atomic.validate+0x2a0>
    422c:      	b	0x42fc <_stogir.atomic.validate+0x368>
    4230:      	b	0x4730 <_stogir.atomic.validate+0x79c>
    4234:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004234:  ARM64_RELOC_PAGE21	l_stogir.375
    4238:      	ldr	x16, [x16]
		0000000000004238:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    423c:      	orr	x20, x16, xzr
    4240:      	mov	x22, #0x16              ; =22
    4244:      	b	0x426c <_stogir.atomic.validate+0x2d8>
    4248:      	movz	x5, #0x0, lsl #48
    424c:      	b	0x4078 <_stogir.atomic.validate+0xe4>
    4250:      	mov	x0, #0x1                ; =1
    4254:      	cmp	x0, #0x0
    4258:      	b.eq	0x426c <_stogir.atomic.validate+0x2d8>
    425c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		000000000000425c:  ARM64_RELOC_PAGE21	l_stogir.376
    4260:      	ldr	x16, [x16]
		0000000000004260:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    4264:      	orr	x20, x16, xzr
    4268:      	mov	x22, #0x16              ; =22
    426c:      	cmp	x21, #0x82
    4270:      	cset	w26, eq
    4274:      	lsr	w19, w19, #0
    4278:      	ubfx	x0, x19, #8, #8
    427c:      	orr	x19, x0, xzr
    4280:      	cmp	x19, #0x0
    4284:      	cset	w27, eq
    4288:      	uxtb	w16, w26
    428c:      	cmp	w16, wzr
    4290:      	b.eq	0x42b0 <_stogir.atomic.validate+0x31c>
    4294:      	uxtb	w16, w27
    4298:      	cmp	w16, wzr
    429c:      	b.ne	0x42b0 <_stogir.atomic.validate+0x31c>
    42a0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000042a0:  ARM64_RELOC_PAGE21	l_stogir.377
    42a4:      	ldr	x16, [x16]
		00000000000042a4:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    42a8:      	orr	x20, x16, xzr
    42ac:      	mov	x22, #0x19              ; =25
    42b0:      	uxtb	w16, w26
    42b4:      	cmp	w16, wzr
    42b8:      	b.eq	0x42c4 <_stogir.atomic.validate+0x330>
    42bc:      	movz	x0, #0x0, lsl #48
    42c0:      	b	0x42c8 <_stogir.atomic.validate+0x334>
    42c4:      	mov	x0, #0x1                ; =1
    42c8:      	cmp	x0, #0x0
    42cc:      	b.eq	0x433c <_stogir.atomic.validate+0x3a8>
    42d0:      	add	x16, sp, #0x20
    42d4:      	ldr	w0, [x16, #0x8]
    42d8:      	lsr	w0, w0, #0
    42dc:      	mov	w1, w0
    42e0:      	mov	x0, x24
    42e4:      	mov	x2, #0x6                ; =6
    42e8:      	bl	0x42e8 <_stogir.atomic.validate+0x354>
		00000000000042e8:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    42ec:      	cmp	x0, #0x0
    42f0:      	b.eq	0x4420 <_stogir.atomic.validate+0x48c>
    42f4:      	movz	x0, #0x0, lsl #48
    42f8:      	b	0x4424 <_stogir.atomic.validate+0x490>
    42fc:      	add	x16, sp, #0x30
    4300:      	ldr	x0, [x16, #0x8]
    4304:      	add	x16, sp, #0x20
    4308:      	ldr	w1, [x16, #0x4]
    430c:      	sxtw	x1, w1
    4310:      	cmp	x1, #0x0
    4314:      	b.gt	0x44c4 <_stogir.atomic.validate+0x530>
    4318:      	mov	x0, #0x1                ; =1
    431c:      	b	0x4254 <_stogir.atomic.validate+0x2c0>
    4320:      	movz	x0, #0x0, lsl #48
    4324:      	cmp	x0, #0x0
    4328:      	b.eq	0x433c <_stogir.atomic.validate+0x3a8>
    432c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		000000000000432c:  ARM64_RELOC_PAGE21	l_stogir.378
    4330:      	ldr	x16, [x16]
		0000000000004330:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    4334:      	orr	x20, x16, xzr
    4338:      	mov	x22, #0x22              ; =34
    433c:      	cmp	x21, #0x80
    4340:      	cset	w27, eq
    4344:      	uxtb	w16, w27
    4348:      	cmp	w16, wzr
    434c:      	b.eq	0x4358 <_stogir.atomic.validate+0x3c4>
    4350:      	mov	x0, #0x1                ; =1
    4354:      	b	0x4364 <_stogir.atomic.validate+0x3d0>
    4358:      	cmp	x21, #0x81
    435c:      	cset	w0, eq
    4360:      	ubfx	x0, x0, #0, #8
    4364:      	lsr	w19, w19, #0
    4368:      	cmp	x0, #0x0
    436c:      	b.eq	0x43e8 <_stogir.atomic.validate+0x454>
    4370:      	lsr	w25, w25, #0
    4374:      	add	x16, sp, #0x90
    4378:      	str	x16, [sp]
    437c:      	mov	x0, x24
    4380:      	mov	w1, w25
    4384:      	mov	x2, #0x4                ; =4
    4388:      	bl	0x4388 <_stogir.atomic.validate+0x3f4>
		0000000000004388:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    438c:      	ldr	x16, [sp]
    4390:      	str	x0, [x16]
    4394:      	str	x1, [x16, #0x8]
    4398:      	add	x16, sp, #0x90
    439c:      	ldr	x0, [x16]
    43a0:      	add	x16, sp, #0x90
    43a4:      	ldr	x1, [x16, #0x8]
    43a8:      	lsr	w0, w0, #0
    43ac:      	lsr	x16, x0, #0
    43b0:      	cmp	x16, #0x1
    43b4:      	b.eq	0x43d0 <_stogir.atomic.validate+0x43c>
    43b8:      	b.lo	0x43c0 <_stogir.atomic.validate+0x42c>
    43bc:      	b	0x43d4 <_stogir.atomic.validate+0x440>
    43c0:      	cmp	x16, #0x0
    43c4:      	b.eq	0x43cc <_stogir.atomic.validate+0x438>
    43c8:      	b	0x43d4 <_stogir.atomic.validate+0x440>
    43cc:      	b	0x43d8 <_stogir.atomic.validate+0x444>
    43d0:      	b	0x45a0 <_stogir.atomic.validate+0x60c>
    43d4:      	b	0x4740 <_stogir.atomic.validate+0x7ac>
    43d8:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000043d8:  ARM64_RELOC_PAGE21	l_stogir.379
    43dc:      	ldr	x16, [x16]
		00000000000043dc:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    43e0:      	orr	x20, x16, xzr
    43e4:      	mov	x22, #0x1d              ; =29
    43e8:      	cmp	x22, #0x0
    43ec:      	b.ne	0x41c4 <_stogir.atomic.validate+0x230>
    43f0:      	uxtb	w16, w26
    43f4:      	cmp	w16, wzr
    43f8:      	b.eq	0x458c <_stogir.atomic.validate+0x5f8>
    43fc:      	movz	x0, #0x0, lsl #48
    4400:      	b	0x4410 <_stogir.atomic.validate+0x47c>
    4404:      	mov	x0, #0x1                ; =1
    4408:      	lsr	w0, w0, #0
    440c:      	sxtw	x0, w0
    4410:      	and	x20, x0, #0xffffffff
    4414:      	movz	x0, #0x0, lsl #48
    4418:      	movz	x22, #0x0, lsl #48
    441c:      	b	0x41c8 <_stogir.atomic.validate+0x234>
    4420:      	mov	x0, #0x1                ; =1
    4424:      	cmp	x0, #0x0
    4428:      	b.eq	0x443c <_stogir.atomic.validate+0x4a8>
    442c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		000000000000442c:  ARM64_RELOC_PAGE21	l_stogir.380
    4430:      	ldr	x16, [x16]
		0000000000004430:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    4434:      	orr	x20, x16, xzr
    4438:      	mov	x22, #0x1b              ; =27
    443c:      	cmp	x21, #0x7f
    4440:      	b.ne	0x4508 <_stogir.atomic.validate+0x574>
    4444:      	uxtb	w16, w27
    4448:      	cmp	w16, wzr
    444c:      	b.ne	0x4460 <_stogir.atomic.validate+0x4cc>
    4450:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004450:  ARM64_RELOC_PAGE21	l_stogir.381
    4454:      	ldr	x16, [x16]
		0000000000004454:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    4458:      	orr	x20, x16, xzr
    445c:      	mov	x22, #0x19              ; =25
    4460:      	add	x16, sp, #0x20
    4464:      	ldr	w0, [x16, #0xc]
    4468:      	lsr	w0, w0, #0
    446c:      	add	x8, sp, #0x60
    4470:      	mov	w1, w0
    4474:      	mov	x0, x24
    4478:      	bl	0x4478 <_stogir.atomic.validate+0x4e4>
		0000000000004478:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    447c:      	add	x16, sp, #0x60
    4480:      	ldr	w0, [x16]
    4484:      	lsr	x16, x0, #0
    4488:      	cmp	x16, #0x1
    448c:      	b.eq	0x44a8 <_stogir.atomic.validate+0x514>
    4490:      	b.lo	0x4498 <_stogir.atomic.validate+0x504>
    4494:      	b	0x44ac <_stogir.atomic.validate+0x518>
    4498:      	cmp	x16, #0x0
    449c:      	b.eq	0x44a4 <_stogir.atomic.validate+0x510>
    44a0:      	b	0x44ac <_stogir.atomic.validate+0x518>
    44a4:      	b	0x44b0 <_stogir.atomic.validate+0x51c>
    44a8:      	b	0x44f4 <_stogir.atomic.validate+0x560>
    44ac:      	b	0x4748 <_stogir.atomic.validate+0x7b4>
    44b0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000044b0:  ARM64_RELOC_PAGE21	l_stogir.382
    44b4:      	ldr	x16, [x16]
		00000000000044b4:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    44b8:      	orr	x20, x16, xzr
    44bc:      	mov	x22, #0x1a              ; =26
    44c0:      	b	0x4508 <_stogir.atomic.validate+0x574>
    44c4:      	uxtb	w0, w0
    44c8:      	cmp	x0, #0x83
    44cc:      	cset	w1, lt
    44d0:      	uxtb	w16, w1
    44d4:      	cmp	w16, wzr
    44d8:      	b.eq	0x4618 <_stogir.atomic.validate+0x684>
    44dc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000044dc:  ARM64_RELOC_PAGE21	l_stogir.383
    44e0:      	ldr	x16, [x16]
		00000000000044e0:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    44e4:      	orr	x2, x16, xzr
    44e8:      	add	x2, x0, x2
    44ec:      	ldrb	w2, [x2]
    44f0:      	b	0x461c <_stogir.atomic.validate+0x688>
    44f4:      	add	x16, sp, #0x60
    44f8:      	ldr	x0, [x16, #0x8]
    44fc:      	lsr	w0, w0, #0
    4500:      	ubfx	x0, x0, #8, #8
    4504:      	orr	x19, x0, xzr
    4508:      	cmp	x19, #0x2
    450c:      	b.ge	0x4558 <_stogir.atomic.validate+0x5c4>
    4510:      	mov	x0, #0x1                ; =1
    4514:      	b	0x4564 <_stogir.atomic.validate+0x5d0>
    4518:      	mov	x0, #0x1                ; =1
    451c:      	b	0x4324 <_stogir.atomic.validate+0x390>
    4520:      	mov	x0, #0x1                ; =1
    4524:      	cmp	x0, #0x0
    4528:      	b.eq	0x4320 <_stogir.atomic.validate+0x38c>
    452c:      	lsr	w0, w19, #0
    4530:      	add	x16, sp, #0x20
    4534:      	ldr	w1, [x16, #0xc]
    4538:      	lsr	w1, w1, #0
    453c:      	mov	w2, w0
    4540:      	mov	x0, x24
    4544:      	bl	0x4544 <_stogir.atomic.validate+0x5b0>
		0000000000004544:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4548:      	cmp	x0, #0x0
    454c:      	b.eq	0x4518 <_stogir.atomic.validate+0x584>
    4550:      	movz	x0, #0x0, lsl #48
    4554:      	b	0x451c <_stogir.atomic.validate+0x588>
    4558:      	cmp	x19, #0x5
    455c:      	cset	w0, gt
    4560:      	ubfx	x0, x0, #0, #8
    4564:      	cmp	x0, #0x0
    4568:      	b.eq	0x457c <_stogir.atomic.validate+0x5e8>
    456c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		000000000000456c:  ARM64_RELOC_PAGE21	l_stogir.384
    4570:      	ldr	x16, [x16]
		0000000000004570:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    4574:      	orr	x20, x16, xzr
    4578:      	mov	x22, #0x25              ; =37
    457c:      	cmp	x21, #0x7e
    4580:      	b.ne	0x4520 <_stogir.atomic.validate+0x58c>
    4584:      	movz	x0, #0x0, lsl #48
    4588:      	b	0x4524 <_stogir.atomic.validate+0x590>
    458c:      	sxtw	x19, w19
    4590:      	cmp	x19, #0x0
    4594:      	b.ne	0x4680 <_stogir.atomic.validate+0x6ec>
    4598:      	movz	x0, #0x0, lsl #48
    459c:      	b	0x4408 <_stogir.atomic.validate+0x474>
    45a0:      	lsr	w1, w1, #0
    45a4:      	uxtb	w16, w27
    45a8:      	cmp	w16, wzr
    45ac:      	b.eq	0x45c4 <_stogir.atomic.validate+0x630>
    45b0:      	sxtw	x1, w1
    45b4:      	cmp	x1, #0x0
    45b8:      	b.ge	0x4700 <_stogir.atomic.validate+0x76c>
    45bc:      	mov	x0, #0x1                ; =1
    45c0:      	b	0x470c <_stogir.atomic.validate+0x778>
    45c4:      	lsr	w1, w1, #0
    45c8:      	mov	x0, x24
    45cc:      	mov	w2, w19
    45d0:      	bl	0x45d0 <_stogir.atomic.validate+0x63c>
		00000000000045d0:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    45d4:      	cmp	x0, #0x0
    45d8:      	b.ne	0x45ec <_stogir.atomic.validate+0x658>
    45dc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000045dc:  ARM64_RELOC_PAGE21	l_stogir.385
    45e0:      	ldr	x16, [x16]
		00000000000045e0:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    45e4:      	orr	x20, x16, xzr
    45e8:      	mov	x22, #0x24              ; =36
    45ec:      	b	0x43e8 <_stogir.atomic.validate+0x454>
    45f0:      	movz	x0, #0x0, lsl #48
    45f4:      	uxtb	w0, w0
    45f8:      	and	x0, x0, #0x4
    45fc:      	uxtb	w0, w0
    4600:      	cmp	x0, #0x0
    4604:      	cset	w0, eq
    4608:      	uxtb	w16, w0
    460c:      	cmp	w16, wzr
    4610:      	cset	x0, eq
    4614:      	b	0x4254 <_stogir.atomic.validate+0x2c0>
    4618:      	movz	x2, #0x0, lsl #48
    461c:      	uxtb	w2, w2
    4620:      	and	x2, x2, #0x1
    4624:      	uxtb	w2, w2
    4628:      	cmp	x2, #0x0
    462c:      	b.eq	0x4250 <_stogir.atomic.validate+0x2bc>
    4630:      	uxtb	w16, w1
    4634:      	cmp	w16, wzr
    4638:      	b.eq	0x45f0 <_stogir.atomic.validate+0x65c>
    463c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		000000000000463c:  ARM64_RELOC_PAGE21	l_stogir.383
    4640:      	ldr	x16, [x16]
		0000000000004640:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    4644:      	orr	x1, x16, xzr
    4648:      	add	x0, x0, x1
    464c:      	ldrb	w0, [x0]
    4650:      	b	0x45f4 <_stogir.atomic.validate+0x660>
    4654:      	mov	x3, #-0x2               ; =-2
    4658:      	sxtw	x2, w2
    465c:      	lsr	w3, w3, #0
    4660:      	sxtw	x3, w3
    4664:      	cmp	x2, x3
    4668:      	b.ne	0x41cc <_stogir.atomic.validate+0x238>
    466c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		000000000000466c:  ARM64_RELOC_PAGE21	l_stogir.386
    4670:      	ldr	x16, [x16]
		0000000000004670:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    4674:      	orr	x20, x16, xzr
    4678:      	movz	x22, #0x0, lsl #48
    467c:      	b	0x41dc <_stogir.atomic.validate+0x248>
    4680:      	cmp	x19, #0x1
    4684:      	b.eq	0x4404 <_stogir.atomic.validate+0x470>
    4688:      	cmp	x19, #0x2
    468c:      	b.eq	0x4404 <_stogir.atomic.validate+0x470>
    4690:      	cmp	x19, #0x7
    4694:      	b.eq	0x4404 <_stogir.atomic.validate+0x470>
    4698:      	cmp	x19, #0x8
    469c:      	b.eq	0x4404 <_stogir.atomic.validate+0x470>
    46a0:      	cmp	x19, #0x3
    46a4:      	b.eq	0x4738 <_stogir.atomic.validate+0x7a4>
    46a8:      	cmp	x19, #0x9
    46ac:      	b.eq	0x4738 <_stogir.atomic.validate+0x7a4>
    46b0:      	cmp	x19, #0x4
    46b4:      	b.eq	0x4750 <_stogir.atomic.validate+0x7bc>
    46b8:      	cmp	x19, #0xa
    46bc:      	b.eq	0x4750 <_stogir.atomic.validate+0x7bc>
    46c0:      	cmp	x19, #0xd
    46c4:      	b.eq	0x4750 <_stogir.atomic.validate+0x7bc>
    46c8:      	cmp	x19, #0x5
    46cc:      	b.eq	0x4758 <_stogir.atomic.validate+0x7c4>
    46d0:      	cmp	x19, #0xb
    46d4:      	b.eq	0x4758 <_stogir.atomic.validate+0x7c4>
    46d8:      	cmp	x19, #0xc
    46dc:      	b.eq	0x4758 <_stogir.atomic.validate+0x7c4>
    46e0:      	cmp	x19, #0x6
    46e4:      	cset	w0, eq
    46e8:      	uxtb	w16, w0
    46ec:      	cmp	w16, wzr
    46f0:      	mov	x16, #0x8               ; =8
    46f4:      	movn	x17, #0x0, lsl #48
    46f8:      	csel	x0, x16, x17, ne
    46fc:      	b	0x475c <_stogir.atomic.validate+0x7c8>
    4700:      	cmp	x1, #0x9
    4704:      	cset	w0, gt
    4708:      	ubfx	x0, x0, #0, #8
    470c:      	cmp	x0, #0x0
    4710:      	b.eq	0x4724 <_stogir.atomic.validate+0x790>
    4714:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004714:  ARM64_RELOC_PAGE21	l_stogir.387
    4718:      	ldr	x16, [x16]
		0000000000004718:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    471c:      	orr	x20, x16, xzr
    4720:      	mov	x22, #0x1c              ; =28
    4724:      	b	0x45ec <_stogir.atomic.validate+0x658>
    4728:      	brk	#0
    472c:      	b	0x4728 <_stogir.atomic.validate+0x794>
    4730:      	brk	#0
    4734:      	b	0x4730 <_stogir.atomic.validate+0x79c>
    4738:      	mov	x0, #0x2                ; =2
    473c:      	b	0x4408 <_stogir.atomic.validate+0x474>
    4740:      	brk	#0
    4744:      	b	0x4740 <_stogir.atomic.validate+0x7ac>
    4748:      	brk	#0
    474c:      	b	0x4748 <_stogir.atomic.validate+0x7b4>
    4750:      	mov	x0, #0x4                ; =4
    4754:      	b	0x473c <_stogir.atomic.validate+0x7a8>
    4758:      	mov	x0, #0x8                ; =8
    475c:      	b	0x4754 <_stogir.atomic.validate+0x7c0>

0000000000004760 <_stogir.terminal.validate>:
    4760:      	sub	sp, sp, #0x50
    4764:      	str	x29, [sp]
    4768:      	str	x30, [sp, #0x8]
    476c:      	mov	x29, sp
    4770:      	str	x19, [sp, #0x40]
    4774:      	sxtw	x1, w1
    4778:      	lsl	x2, x1, #2
    477c:      	cmp	x1, #0x0
    4780:      	cset	w3, gt
    4784:      	movz	x16, #0x0, lsl #48
    4788:      	sub	x4, x16, x1
    478c:      	sub	x5, x4, #0x1
    4790:      	uxtb	w16, w3
    4794:      	cmp	w16, wzr
    4798:      	b.eq	0x47d8 <_stogir.terminal.validate+0x78>
    479c:      	ldr	x4, [x0, #0x8]
    47a0:      	cmp	x1, x4
    47a4:      	b.ge	0x4828 <_stogir.terminal.validate+0xc8>
    47a8:      	add	x4, x0, #0x78
    47ac:      	ldr	x4, [x4, #0x8]
    47b0:      	cmp	x1, x4
    47b4:      	b.ge	0x491c <_stogir.terminal.validate+0x1bc>
    47b8:      	ldr	x4, [x0, #0x78]
    47bc:      	add	x4, x2, x4
    47c0:      	ldr	w4, [x4]
    47c4:      	sxtw	x4, w4
    47c8:      	cmp	x4, #0x0
    47cc:      	cset	w4, ge
    47d0:      	ubfx	x4, x4, #0, #8
    47d4:      	b	0x4920 <_stogir.terminal.validate+0x1c0>
    47d8:      	cmp	x1, #0x0
    47dc:      	b.ge	0x4830 <_stogir.terminal.validate+0xd0>
    47e0:      	add	x6, x0, #0x28
    47e4:      	add	x7, x0, #0x50
    47e8:      	ldr	x6, [x6, #0x8]
    47ec:      	ldr	x7, [x7, #0x8]
    47f0:      	cmp	x6, x7
    47f4:      	b.ne	0x4820 <_stogir.terminal.validate+0xc0>
    47f8:      	cmp	x4, x6
    47fc:      	b.gt	0x495c <_stogir.terminal.validate+0x1fc>
    4800:      	ldr	x4, [x0, #0x50]
    4804:      	add	x4, x4, x5, lsl #2
    4808:      	ldr	w4, [x4]
    480c:      	sxtw	x4, w4
    4810:      	cmp	x4, #0x0
    4814:      	cset	w4, gt
    4818:      	ubfx	x4, x4, #0, #8
    481c:      	b	0x4960 <_stogir.terminal.validate+0x200>
    4820:      	movz	x4, #0x0, lsl #48
    4824:      	b	0x4834 <_stogir.terminal.validate+0xd4>
    4828:      	movz	x4, #0x0, lsl #48
    482c:      	b	0x4834 <_stogir.terminal.validate+0xd4>
    4830:      	movz	x4, #0x0, lsl #48
    4834:      	cmp	x4, #0x0
    4838:      	b.eq	0x4874 <_stogir.terminal.validate+0x114>
    483c:      	uxtb	w16, w3
    4840:      	cmp	w16, wzr
    4844:      	b.eq	0x485c <_stogir.terminal.validate+0xfc>
    4848:      	ldr	x3, [x0]
    484c:      	add	x3, x3, x1, lsl #4
    4850:      	ldr	x4, [x3]
    4854:      	ldr	x3, [x3, #0x8]
    4858:      	b	0x486c <_stogir.terminal.validate+0x10c>
    485c:      	ldr	x3, [x0, #0x28]
    4860:      	add	x3, x3, x5, lsl #4
    4864:      	ldr	x4, [x3]
    4868:      	ldr	x3, [x3, #0x8]
    486c:      	mov	x5, #0x1                ; =1
    4870:      	b	0x4880 <_stogir.terminal.validate+0x120>
    4874:      	movz	x5, #0x0, lsl #48
    4878:      	movz	x4, #0x0, lsl #48
    487c:      	movz	x3, #0x0, lsl #48
    4880:      	lsr	w5, w5, #0
    4884:      	lsr	x16, x5, #0
    4888:      	cmp	x16, #0x1
    488c:      	b.eq	0x48a8 <_stogir.terminal.validate+0x148>
    4890:      	b.lo	0x4898 <_stogir.terminal.validate+0x138>
    4894:      	b	0x48ac <_stogir.terminal.validate+0x14c>
    4898:      	cmp	x16, #0x0
    489c:      	b.eq	0x48a4 <_stogir.terminal.validate+0x144>
    48a0:      	b	0x48ac <_stogir.terminal.validate+0x14c>
    48a4:      	b	0x48b0 <_stogir.terminal.validate+0x150>
    48a8:      	b	0x48cc <_stogir.terminal.validate+0x16c>
    48ac:      	b	0x4a38 <_stogir.terminal.validate+0x2d8>
    48b0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000048b0:  ARM64_RELOC_PAGE21	l_stogir.388
    48b4:      	ldr	x16, [x16]
		00000000000048b4:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    48b8:      	orr	x0, x16, xzr
    48bc:      	mov	x19, x8
    48c0:      	mov	x1, #0x1                ; =1
    48c4:      	mov	x2, #0x21               ; =33
    48c8:      	b	0x48fc <_stogir.terminal.validate+0x19c>
    48cc:      	add	x16, sp, #0x10
    48d0:      	str	x4, [x16]
    48d4:      	add	x16, sp, #0x10
    48d8:      	str	x3, [x16, #0x8]
    48dc:      	cmp	x1, #0x0
    48e0:      	b.gt	0x4924 <_stogir.terminal.validate+0x1c4>
    48e4:      	mov	x19, x8
    48e8:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		00000000000048e8:  ARM64_RELOC_PAGE21	l_stogir.389
    48ec:      	ldr	x16, [x16]
		00000000000048ec:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    48f0:      	orr	x0, x16, xzr
    48f4:      	mov	x1, #0x1                ; =1
    48f8:      	mov	x2, #0x1b               ; =27
    48fc:      	str	x1, [x19]
    4900:      	str	x0, [x19, #0x8]
    4904:      	str	x2, [x19, #0x10]
    4908:      	ldr	x19, [sp, #0x40]
    490c:      	ldr	x29, [sp]
    4910:      	ldr	x30, [sp, #0x8]
    4914:      	add	sp, sp, #0x50
    4918:      	ret
    491c:      	movz	x4, #0x0, lsl #48
    4920:      	b	0x482c <_stogir.terminal.validate+0xcc>
    4924:      	uxtb	w4, w4
    4928:      	orr	x1, x4, xzr
    492c:      	cmp	x1, #0x60
    4930:      	cset	w3, eq
    4934:      	cmp	x1, #0x79
    4938:      	cset	w1, eq
    493c:      	uxtb	w16, w3
    4940:      	cmp	w16, wzr
    4944:      	b.ne	0x4964 <_stogir.terminal.validate+0x204>
    4948:      	uxtb	w16, w1
    494c:      	cmp	w16, wzr
    4950:      	b.ne	0x4964 <_stogir.terminal.validate+0x204>
    4954:      	mov	x19, x8
    4958:      	b	0x48e8 <_stogir.terminal.validate+0x188>
    495c:      	movz	x4, #0x0, lsl #48
    4960:      	b	0x4824 <_stogir.terminal.validate+0xc4>
    4964:      	add	x16, sp, #0x10
    4968:      	ldr	w5, [x16]
    496c:      	ubfx	x5, x5, #8, #8
    4970:      	cmp	x5, #0x0
    4974:      	b.ne	0x4a40 <_stogir.terminal.validate+0x2e0>
    4978:      	uxtb	w16, w3
    497c:      	cmp	w16, wzr
    4980:      	mov	x16, #0x1               ; =1
    4984:      	mov	x17, #0x3               ; =3
    4988:      	csel	x3, x16, x17, ne
    498c:      	lsr	w3, w3, #0
    4990:      	sxtw	x3, w3
    4994:      	ldr	x5, [x0, #0x78]
    4998:      	add	x2, x2, x5
    499c:      	ldr	w2, [x2]
    49a0:      	sxtw	x2, w2
    49a4:      	cmp	x2, x3
    49a8:      	b.ne	0x4a48 <_stogir.terminal.validate+0x2e8>
    49ac:      	uxtb	w16, w1
    49b0:      	cmp	w16, wzr
    49b4:      	b.eq	0x4a14 <_stogir.terminal.validate+0x2b4>
    49b8:      	add	x16, sp, #0x10
    49bc:      	ldr	w2, [x16, #0x8]
    49c0:      	sxtw	x2, w2
    49c4:      	cmp	x2, #0x0
    49c8:      	b.eq	0x4a14 <_stogir.terminal.validate+0x2b4>
    49cc:      	mov	x19, x8
    49d0:      	b	0x48e8 <_stogir.terminal.validate+0x188>
    49d4:      	movz	x1, #0x0, lsl #48
    49d8:      	lsr	w2, w2, #0
    49dc:      	lsr	w4, w4, #0
    49e0:      	lsr	w1, w1, #0
    49e4:      	mov	w3, w1
    49e8:      	mov	w1, w4
    49ec:      	mov	x19, x8
    49f0:      	add	x8, sp, #0x20
    49f4:      	bl	0x49f4 <_stogir.terminal.validate+0x294>
		00000000000049f4:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    49f8:      	add	x16, sp, #0x20
    49fc:      	ldr	x1, [x16]
    4a00:      	add	x16, sp, #0x20
    4a04:      	ldr	x0, [x16, #0x8]
    4a08:      	add	x16, sp, #0x20
    4a0c:      	ldr	x2, [x16, #0x10]
    4a10:      	b	0x48fc <_stogir.terminal.validate+0x19c>
    4a14:      	add	x16, sp, #0x10
    4a18:      	ldr	w2, [x16, #0x4]
    4a1c:      	uxtb	w16, w1
    4a20:      	cmp	w16, wzr
    4a24:      	b.eq	0x49d4 <_stogir.terminal.validate+0x274>
    4a28:      	add	x16, sp, #0x10
    4a2c:      	ldr	w1, [x16, #0xc]
    4a30:      	sxtw	x1, w1
    4a34:      	b	0x49d8 <_stogir.terminal.validate+0x278>
    4a38:      	brk	#0
    4a3c:      	b	0x4a38 <_stogir.terminal.validate+0x2d8>
    4a40:      	mov	x19, x8
    4a44:      	b	0x48e8 <_stogir.terminal.validate+0x188>
    4a48:      	mov	x19, x8
    4a4c:      	b	0x48e8 <_stogir.terminal.validate+0x188>

0000000000004a50 <_stogir.switch.validate>:
    4a50:      	sub	sp, sp, #0x70
    4a54:      	str	x29, [sp]
    4a58:      	str	x30, [sp, #0x8]
    4a5c:      	mov	x29, sp
    4a60:      	str	x19, [sp, #0x60]
    4a64:      	sxtw	x1, w1
    4a68:      	lsl	x2, x1, #2
    4a6c:      	cmp	x1, #0x0
    4a70:      	cset	w3, gt
    4a74:      	movz	x16, #0x0, lsl #48
    4a78:      	sub	x4, x16, x1
    4a7c:      	sub	x5, x4, #0x1
    4a80:      	uxtb	w16, w3
    4a84:      	cmp	w16, wzr
    4a88:      	b.eq	0x4ac8 <_stogir.switch.validate+0x78>
    4a8c:      	ldr	x4, [x0, #0x8]
    4a90:      	cmp	x1, x4
    4a94:      	b.ge	0x4b18 <_stogir.switch.validate+0xc8>
    4a98:      	add	x4, x0, #0x78
    4a9c:      	ldr	x4, [x4, #0x8]
    4aa0:      	cmp	x1, x4
    4aa4:      	b.ge	0x4c0c <_stogir.switch.validate+0x1bc>
    4aa8:      	ldr	x4, [x0, #0x78]
    4aac:      	add	x4, x2, x4
    4ab0:      	ldr	w4, [x4]
    4ab4:      	sxtw	x4, w4
    4ab8:      	cmp	x4, #0x0
    4abc:      	cset	w4, ge
    4ac0:      	ubfx	x4, x4, #0, #8
    4ac4:      	b	0x4c10 <_stogir.switch.validate+0x1c0>
    4ac8:      	cmp	x1, #0x0
    4acc:      	b.ge	0x4b20 <_stogir.switch.validate+0xd0>
    4ad0:      	add	x6, x0, #0x28
    4ad4:      	add	x7, x0, #0x50
    4ad8:      	ldr	x6, [x6, #0x8]
    4adc:      	ldr	x7, [x7, #0x8]
    4ae0:      	cmp	x6, x7
    4ae4:      	b.ne	0x4b10 <_stogir.switch.validate+0xc0>
    4ae8:      	cmp	x4, x6
    4aec:      	b.gt	0x4c48 <_stogir.switch.validate+0x1f8>
    4af0:      	ldr	x4, [x0, #0x50]
    4af4:      	add	x4, x4, x5, lsl #2
    4af8:      	ldr	w4, [x4]
    4afc:      	sxtw	x4, w4
    4b00:      	cmp	x4, #0x0
    4b04:      	cset	w4, gt
    4b08:      	ubfx	x4, x4, #0, #8
    4b0c:      	b	0x4c4c <_stogir.switch.validate+0x1fc>
    4b10:      	movz	x4, #0x0, lsl #48
    4b14:      	b	0x4b24 <_stogir.switch.validate+0xd4>
    4b18:      	movz	x4, #0x0, lsl #48
    4b1c:      	b	0x4b24 <_stogir.switch.validate+0xd4>
    4b20:      	movz	x4, #0x0, lsl #48
    4b24:      	cmp	x4, #0x0
    4b28:      	b.eq	0x4b64 <_stogir.switch.validate+0x114>
    4b2c:      	uxtb	w16, w3
    4b30:      	cmp	w16, wzr
    4b34:      	b.eq	0x4b4c <_stogir.switch.validate+0xfc>
    4b38:      	ldr	x3, [x0]
    4b3c:      	add	x3, x3, x1, lsl #4
    4b40:      	ldr	x4, [x3]
    4b44:      	ldr	x3, [x3, #0x8]
    4b48:      	b	0x4b5c <_stogir.switch.validate+0x10c>
    4b4c:      	ldr	x3, [x0, #0x28]
    4b50:      	add	x3, x3, x5, lsl #4
    4b54:      	ldr	x4, [x3]
    4b58:      	ldr	x3, [x3, #0x8]
    4b5c:      	mov	x5, #0x1                ; =1
    4b60:      	b	0x4b70 <_stogir.switch.validate+0x120>
    4b64:      	movz	x5, #0x0, lsl #48
    4b68:      	movz	x4, #0x0, lsl #48
    4b6c:      	movz	x3, #0x0, lsl #48
    4b70:      	lsr	w5, w5, #0
    4b74:      	lsr	x16, x5, #0
    4b78:      	cmp	x16, #0x1
    4b7c:      	b.eq	0x4b98 <_stogir.switch.validate+0x148>
    4b80:      	b.lo	0x4b88 <_stogir.switch.validate+0x138>
    4b84:      	b	0x4b9c <_stogir.switch.validate+0x14c>
    4b88:      	cmp	x16, #0x0
    4b8c:      	b.eq	0x4b94 <_stogir.switch.validate+0x144>
    4b90:      	b	0x4b9c <_stogir.switch.validate+0x14c>
    4b94:      	b	0x4ba0 <_stogir.switch.validate+0x150>
    4b98:      	b	0x4bbc <_stogir.switch.validate+0x16c>
    4b9c:      	b	0x4d4c <_stogir.switch.validate+0x2fc>
    4ba0:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004ba0:  ARM64_RELOC_PAGE21	l_stogir.390
    4ba4:      	ldr	x16, [x16]
		0000000000004ba4:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    4ba8:      	orr	x0, x16, xzr
    4bac:      	mov	x19, x8
    4bb0:      	mov	x1, #0x1                ; =1
    4bb4:      	mov	x2, #0x1a               ; =26
    4bb8:      	b	0x4bec <_stogir.switch.validate+0x19c>
    4bbc:      	add	x16, sp, #0x10
    4bc0:      	str	x4, [x16]
    4bc4:      	add	x16, sp, #0x10
    4bc8:      	str	x3, [x16, #0x8]
    4bcc:      	cmp	x1, #0x0
    4bd0:      	b.gt	0x4c14 <_stogir.switch.validate+0x1c4>
    4bd4:      	mov	x19, x8
    4bd8:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004bd8:  ARM64_RELOC_PAGE21	l_stogir.391
    4bdc:      	ldr	x16, [x16]
		0000000000004bdc:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    4be0:      	orr	x0, x16, xzr
    4be4:      	mov	x1, #0x1                ; =1
    4be8:      	mov	x2, #0x20               ; =32
    4bec:      	str	x1, [x19]
    4bf0:      	str	x0, [x19, #0x8]
    4bf4:      	str	x2, [x19, #0x10]
    4bf8:      	ldr	x19, [sp, #0x60]
    4bfc:      	ldr	x29, [sp]
    4c00:      	ldr	x30, [sp, #0x8]
    4c04:      	add	sp, sp, #0x70
    4c08:      	ret
    4c0c:      	movz	x4, #0x0, lsl #48
    4c10:      	b	0x4b1c <_stogir.switch.validate+0xcc>
    4c14:      	uxtb	w4, w4
    4c18:      	orr	x1, x4, xzr
    4c1c:      	cmp	x1, #0x75
    4c20:      	cset	w3, eq
    4c24:      	uxtb	w16, w3
    4c28:      	cmp	w16, wzr
    4c2c:      	b.ne	0x4c50 <_stogir.switch.validate+0x200>
    4c30:      	cmp	x1, #0x6d
    4c34:      	b.lt	0x4d54 <_stogir.switch.validate+0x304>
    4c38:      	cmp	x1, #0x6f
    4c3c:      	b.le	0x4c50 <_stogir.switch.validate+0x200>
    4c40:      	mov	x19, x8
    4c44:      	b	0x4bd8 <_stogir.switch.validate+0x188>
    4c48:      	movz	x4, #0x0, lsl #48
    4c4c:      	b	0x4b14 <_stogir.switch.validate+0xc4>
    4c50:      	add	x16, sp, #0x10
    4c54:      	ldr	w5, [x16]
    4c58:      	ubfx	x5, x5, #8, #8
    4c5c:      	cmp	x5, #0x0
    4c60:      	b.ne	0x4d5c <_stogir.switch.validate+0x30c>
    4c64:      	ldr	x5, [x0, #0x78]
    4c68:      	add	x2, x2, x5
    4c6c:      	ldr	w2, [x2]
    4c70:      	cmp	x1, #0x6d
    4c74:      	b.eq	0x4ce8 <_stogir.switch.validate+0x298>
    4c78:      	cmp	x1, #0x6e
    4c7c:      	b.eq	0x4ce8 <_stogir.switch.validate+0x298>
    4c80:      	mov	x1, #0x2                ; =2
    4c84:      	b	0x4cec <_stogir.switch.validate+0x29c>
    4c88:      	lsr	w4, w4, #0
    4c8c:      	add	x16, sp, #0x10
    4c90:      	ldr	w1, [x16, #0x4]
    4c94:      	add	x16, sp, #0x10
    4c98:      	ldr	w2, [x16, #0x8]
    4c9c:      	lsr	w1, w1, #0
    4ca0:      	add	x16, sp, #0x10
    4ca4:      	ldr	w3, [x16, #0xc]
    4ca8:      	lsr	w2, w2, #0
    4cac:      	lsr	w3, w3, #0
    4cb0:      	add	x8, sp, #0x40
    4cb4:      	fmov	s31, w1
    4cb8:      	mov	w1, w4
    4cbc:      	mov	w4, w3
    4cc0:      	mov	w3, w2
    4cc4:      	fmov	w2, s31
    4cc8:      	bl	0x4cc8 <_stogir.switch.validate+0x278>
		0000000000004cc8:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    4ccc:      	add	x16, sp, #0x40
    4cd0:      	ldr	x1, [x16]
    4cd4:      	add	x16, sp, #0x40
    4cd8:      	ldr	x0, [x16, #0x8]
    4cdc:      	add	x16, sp, #0x40
    4ce0:      	ldr	x2, [x16, #0x10]
    4ce4:      	b	0x4bec <_stogir.switch.validate+0x19c>
    4ce8:      	mov	x1, #0x3                ; =3
    4cec:      	sxtw	x2, w2
    4cf0:      	lsr	w1, w1, #0
    4cf4:      	sxtw	x1, w1
    4cf8:      	cmp	x2, x1
    4cfc:      	b.ne	0x4d64 <_stogir.switch.validate+0x314>
    4d00:      	uxtb	w16, w3
    4d04:      	cmp	w16, wzr
    4d08:      	b.eq	0x4d6c <_stogir.switch.validate+0x31c>
    4d0c:      	add	x16, sp, #0x10
    4d10:      	ldr	w1, [x16, #0x4]
    4d14:      	add	x16, sp, #0x10
    4d18:      	ldr	w2, [x16, #0x8]
    4d1c:      	lsr	w1, w1, #0
    4d20:      	lsr	w2, w2, #0
    4d24:      	mov	x19, x8
    4d28:      	add	x8, sp, #0x20
    4d2c:      	bl	0x4d2c <_stogir.switch.validate+0x2dc>
		0000000000004d2c:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    4d30:      	add	x16, sp, #0x20
    4d34:      	ldr	x1, [x16]
    4d38:      	add	x16, sp, #0x20
    4d3c:      	ldr	x0, [x16, #0x8]
    4d40:      	add	x16, sp, #0x20
    4d44:      	ldr	x2, [x16, #0x10]
    4d48:      	b	0x4ce4 <_stogir.switch.validate+0x294>
    4d4c:      	brk	#0
    4d50:      	b	0x4d4c <_stogir.switch.validate+0x2fc>
    4d54:      	mov	x19, x8
    4d58:      	b	0x4bd8 <_stogir.switch.validate+0x188>
    4d5c:      	mov	x19, x8
    4d60:      	b	0x4bd8 <_stogir.switch.validate+0x188>
    4d64:      	mov	x19, x8
    4d68:      	b	0x4bd8 <_stogir.switch.validate+0x188>
    4d6c:      	mov	x19, x8
    4d70:      	b	0x4c88 <_stogir.switch.validate+0x238>

0000000000004d74 <_stogir.stack.validate>:
    4d74:      	sub	sp, sp, #0x90
    4d78:      	str	x29, [sp]
    4d7c:      	str	x30, [sp, #0x8]
    4d80:      	mov	x29, sp
    4d84:      	str	x19, [sp, #0x60]
    4d88:      	str	x20, [sp, #0x68]
    4d8c:      	str	x21, [sp, #0x70]
    4d90:      	str	x22, [sp, #0x78]
    4d94:      	str	x23, [sp, #0x80]
    4d98:      	sxtw	x1, w1
    4d9c:      	lsl	x2, x1, #2
    4da0:      	cmp	x1, #0x0
    4da4:      	cset	w3, gt
    4da8:      	movz	x16, #0x0, lsl #48
    4dac:      	sub	x4, x16, x1
    4db0:      	cmp	x1, #0x0
    4db4:      	cset	w5, lt
    4db8:      	sub	x6, x4, #0x1
    4dbc:      	lsl	x7, x6, #2
    4dc0:      	uxtb	w16, w3
    4dc4:      	cmp	w16, wzr
    4dc8:      	b.eq	0x4e08 <_stogir.stack.validate+0x94>
    4dcc:      	ldr	x9, [x0, #0x8]
    4dd0:      	cmp	x1, x9
    4dd4:      	b.ge	0x4e84 <_stogir.stack.validate+0x110>
    4dd8:      	add	x9, x0, #0x78
    4ddc:      	ldr	x9, [x9, #0x8]
    4de0:      	cmp	x1, x9
    4de4:      	b.ge	0x4fcc <_stogir.stack.validate+0x258>
    4de8:      	ldr	x9, [x0, #0x78]
    4dec:      	add	x9, x2, x9
    4df0:      	ldr	w9, [x9]
    4df4:      	sxtw	x9, w9
    4df8:      	cmp	x9, #0x0
    4dfc:      	cset	w9, ge
    4e00:      	ubfx	x9, x9, #0, #8
    4e04:      	b	0x4fd0 <_stogir.stack.validate+0x25c>
    4e08:      	uxtb	w16, w5
    4e0c:      	cmp	w16, wzr
    4e10:      	b.eq	0x4e8c <_stogir.stack.validate+0x118>
    4e14:      	add	x9, x0, #0x28
    4e18:      	add	x10, x0, #0x50
    4e1c:      	ldr	x9, [x9, #0x8]
    4e20:      	ldr	x10, [x10, #0x8]
    4e24:      	cmp	x9, x10
    4e28:      	b.ne	0x4e54 <_stogir.stack.validate+0xe0>
    4e2c:      	cmp	x4, x9
    4e30:      	b.gt	0x4fd4 <_stogir.stack.validate+0x260>
    4e34:      	ldr	x9, [x0, #0x50]
    4e38:      	add	x9, x7, x9
    4e3c:      	ldr	w9, [x9]
    4e40:      	sxtw	x9, w9
    4e44:      	cmp	x9, #0x0
    4e48:      	cset	w9, gt
    4e4c:      	ubfx	x9, x9, #0, #8
    4e50:      	b	0x4fd8 <_stogir.stack.validate+0x264>
    4e54:      	movz	x9, #0x0, lsl #48
    4e58:      	b	0x4e90 <_stogir.stack.validate+0x11c>
    4e5c:      	uxtb	w16, w12
    4e60:      	cmp	w16, wzr
    4e64:      	b.eq	0x4ff8 <_stogir.stack.validate+0x284>
    4e68:      	mov	x22, x8
    4e6c:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004e6c:  ARM64_RELOC_PAGE21	l_stogir.392
    4e70:      	ldr	x16, [x16]
		0000000000004e70:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    4e74:      	orr	x0, x16, xzr
    4e78:      	mov	x1, #0x1                ; =1
    4e7c:      	mov	x2, #0x19               ; =25
    4e80:      	b	0x4f2c <_stogir.stack.validate+0x1b8>
    4e84:      	movz	x9, #0x0, lsl #48
    4e88:      	b	0x4e90 <_stogir.stack.validate+0x11c>
    4e8c:      	movz	x9, #0x0, lsl #48
    4e90:      	lsl	x10, x1, #4
    4e94:      	lsl	x6, x6, #4
    4e98:      	cmp	x9, #0x0
    4e9c:      	b.eq	0x4ed8 <_stogir.stack.validate+0x164>
    4ea0:      	uxtb	w16, w3
    4ea4:      	cmp	w16, wzr
    4ea8:      	b.eq	0x4ec0 <_stogir.stack.validate+0x14c>
    4eac:      	ldr	x9, [x0]
    4eb0:      	add	x9, x10, x9
    4eb4:      	ldr	x11, [x9]
    4eb8:      	ldr	x9, [x9, #0x8]
    4ebc:      	b	0x4ed0 <_stogir.stack.validate+0x15c>
    4ec0:      	ldr	x9, [x0, #0x28]
    4ec4:      	add	x9, x6, x9
    4ec8:      	ldr	x11, [x9]
    4ecc:      	ldr	x9, [x9, #0x8]
    4ed0:      	mov	x12, #0x1               ; =1
    4ed4:      	b	0x4ee4 <_stogir.stack.validate+0x170>
    4ed8:      	movz	x12, #0x0, lsl #48
    4edc:      	movz	x11, #0x0, lsl #48
    4ee0:      	movz	x9, #0x0, lsl #48
    4ee4:      	lsr	w12, w12, #0
    4ee8:      	lsr	x16, x12, #0
    4eec:      	cmp	x16, #0x1
    4ef0:      	b.eq	0x4f0c <_stogir.stack.validate+0x198>
    4ef4:      	b.lo	0x4efc <_stogir.stack.validate+0x188>
    4ef8:      	b	0x4f10 <_stogir.stack.validate+0x19c>
    4efc:      	cmp	x16, #0x0
    4f00:      	b.eq	0x4f08 <_stogir.stack.validate+0x194>
    4f04:      	b	0x4f10 <_stogir.stack.validate+0x19c>
    4f08:      	b	0x4f14 <_stogir.stack.validate+0x1a0>
    4f0c:      	b	0x4f5c <_stogir.stack.validate+0x1e8>
    4f10:      	b	0x5344 <_stogir.stack.validate+0x5d0>
    4f14:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004f14:  ARM64_RELOC_PAGE21	l_stogir.393
    4f18:      	ldr	x16, [x16]
		0000000000004f18:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    4f1c:      	orr	x0, x16, xzr
    4f20:      	mov	x22, x8
    4f24:      	mov	x1, #0x1                ; =1
    4f28:      	mov	x2, #0x19               ; =25
    4f2c:      	str	x1, [x22]
    4f30:      	str	x0, [x22, #0x8]
    4f34:      	str	x2, [x22, #0x10]
    4f38:      	ldr	x19, [sp, #0x60]
    4f3c:      	ldr	x20, [sp, #0x68]
    4f40:      	ldr	x21, [sp, #0x70]
    4f44:      	ldr	x22, [sp, #0x78]
    4f48:      	ldr	x23, [sp, #0x80]
    4f4c:      	ldr	x29, [sp]
    4f50:      	ldr	x30, [sp, #0x8]
    4f54:      	add	sp, sp, #0x90
    4f58:      	ret
    4f5c:      	cmp	x1, #0x0
    4f60:      	cset	w12, le
    4f64:      	uxtb	w19, w11
    4f68:      	add	x16, sp, #0x10
    4f6c:      	str	x11, [x16]
    4f70:      	orr	x11, x19, xzr
    4f74:      	add	x16, sp, #0x10
    4f78:      	str	x9, [x16, #0x8]
    4f7c:      	cmp	x11, #0x42
    4f80:      	b.ne	0x4e5c <_stogir.stack.validate+0xe8>
    4f84:      	uxtb	w16, w3
    4f88:      	cmp	w16, wzr
    4f8c:      	b.eq	0x5044 <_stogir.stack.validate+0x2d0>
    4f90:      	ldr	x4, [x0, #0x8]
    4f94:      	cmp	x1, x4
    4f98:      	b.ge	0x5090 <_stogir.stack.validate+0x31c>
    4f9c:      	add	x4, x0, #0x78
    4fa0:      	ldr	x4, [x4, #0x8]
    4fa4:      	cmp	x1, x4
    4fa8:      	b.ge	0x517c <_stogir.stack.validate+0x408>
    4fac:      	ldr	x1, [x0, #0x78]
    4fb0:      	add	x1, x2, x1
    4fb4:      	ldr	w1, [x1]
    4fb8:      	sxtw	x1, w1
    4fbc:      	cmp	x1, #0x0
    4fc0:      	cset	w1, ge
    4fc4:      	ubfx	x1, x1, #0, #8
    4fc8:      	b	0x5180 <_stogir.stack.validate+0x40c>
    4fcc:      	movz	x9, #0x0, lsl #48
    4fd0:      	b	0x4e88 <_stogir.stack.validate+0x114>
    4fd4:      	movz	x9, #0x0, lsl #48
    4fd8:      	b	0x4e58 <_stogir.stack.validate+0xe4>
    4fdc:      	adrp	x16, 0x4000 <_stogir.atomic.validate+0x6c>
		0000000000004fdc:  ARM64_RELOC_PAGE21	l_stogir.394
    4fe0:      	ldr	x16, [x16]
		0000000000004fe0:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    4fe4:      	orr	x0, x16, xzr
    4fe8:      	mov	x1, #0x1                ; =1
    4fec:      	mov	x2, #0x1e               ; =30
    4ff0:      	mov	x22, x8
    4ff4:      	b	0x4e80 <_stogir.stack.validate+0x10c>
    4ff8:      	cmp	x11, #0x51
    4ffc:      	cset	w1, eq
    5000:      	cmp	x11, #0x53
    5004:      	cset	w20, eq
    5008:      	cmp	x11, #0x54
    500c:      	cset	w21, eq
    5010:      	uxtb	w16, w1
    5014:      	cmp	w16, wzr
    5018:      	b.ne	0x5184 <_stogir.stack.validate+0x410>
    501c:      	cmp	x11, #0x52
    5020:      	b.eq	0x5184 <_stogir.stack.validate+0x410>
    5024:      	uxtb	w16, w20
    5028:      	cmp	w16, wzr
    502c:      	b.ne	0x5184 <_stogir.stack.validate+0x410>
    5030:      	uxtb	w16, w21
    5034:      	cmp	w16, wzr
    5038:      	b.ne	0x5184 <_stogir.stack.validate+0x410>
    503c:      	mov	x22, x8
    5040:      	b	0x4e6c <_stogir.stack.validate+0xf8>
    5044:      	uxtb	w16, w5
    5048:      	cmp	w16, wzr
    504c:      	b.eq	0x5098 <_stogir.stack.validate+0x324>
    5050:      	add	x1, x0, #0x28
    5054:      	add	x5, x0, #0x50
    5058:      	ldr	x1, [x1, #0x8]
    505c:      	ldr	x5, [x5, #0x8]
    5060:      	cmp	x1, x5
    5064:      	b.ne	0x5174 <_stogir.stack.validate+0x400>
    5068:      	cmp	x4, x1
    506c:      	b.gt	0x52e0 <_stogir.stack.validate+0x56c>
    5070:      	ldr	x1, [x0, #0x50]
    5074:      	add	x1, x7, x1
    5078:      	ldr	w1, [x1]
    507c:      	sxtw	x1, w1
    5080:      	cmp	x1, #0x0
    5084:      	cset	w1, gt
    5088:      	ubfx	x1, x1, #0, #8
    508c:      	b	0x52e4 <_stogir.stack.validate+0x570>
    5090:      	movz	x1, #0x0, lsl #48
    5094:      	b	0x509c <_stogir.stack.validate+0x328>
    5098:      	movz	x1, #0x0, lsl #48
    509c:      	cmp	x1, #0x0
    50a0:      	b.eq	0x50d4 <_stogir.stack.validate+0x360>
    50a4:      	uxtb	w16, w3
    50a8:      	cmp	w16, wzr
    50ac:      	b.eq	0x50c0 <_stogir.stack.validate+0x34c>
    50b0:      	ldr	x1, [x0]
    50b4:      	add	x1, x10, x1
    50b8:      	ldr	x1, [x1]
    50bc:      	b	0x50cc <_stogir.stack.validate+0x358>
    50c0:      	ldr	x1, [x0, #0x28]
    50c4:      	add	x1, x6, x1
    50c8:      	ldr	x1, [x1]
    50cc:      	mov	x3, #0x1                ; =1
    50d0:      	b	0x50dc <_stogir.stack.validate+0x368>
    50d4:      	movz	x3, #0x0, lsl #48
    50d8:      	movz	x1, #0x0, lsl #48
    50dc:      	lsr	w3, w3, #0
    50e0:      	lsr	x16, x3, #0
    50e4:      	cmp	x16, #0x1
    50e8:      	b.eq	0x5104 <_stogir.stack.validate+0x390>
    50ec:      	b.lo	0x50f4 <_stogir.stack.validate+0x380>
    50f0:      	b	0x5108 <_stogir.stack.validate+0x394>
    50f4:      	cmp	x16, #0x0
    50f8:      	b.eq	0x5100 <_stogir.stack.validate+0x38c>
    50fc:      	b	0x5108 <_stogir.stack.validate+0x394>
    5100:      	b	0x510c <_stogir.stack.validate+0x398>
    5104:      	b	0x5124 <_stogir.stack.validate+0x3b0>
    5108:      	b	0x534c <_stogir.stack.validate+0x5d8>
    510c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		000000000000510c:  ARM64_RELOC_PAGE21	l_stogir.395
    5110:      	ldr	x16, [x16]
		0000000000005110:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    5114:      	orr	x0, x16, xzr
    5118:      	mov	x1, #0x1                ; =1
    511c:      	mov	x2, #0x21               ; =33
    5120:      	b	0x4ff0 <_stogir.stack.validate+0x27c>
    5124:      	uxtb	w16, w12
    5128:      	cmp	w16, wzr
    512c:      	b.ne	0x4fdc <_stogir.stack.validate+0x268>
    5130:      	uxtb	w3, w1
    5134:      	cmp	x3, #0x42
    5138:      	b.ne	0x4fdc <_stogir.stack.validate+0x268>
    513c:      	lsr	w1, w1, #0
    5140:      	ubfx	x1, x1, #8, #8
    5144:      	cmp	x1, #0x6
    5148:      	b.ne	0x4fdc <_stogir.stack.validate+0x268>
    514c:      	ldr	x0, [x0, #0x78]
    5150:      	add	x0, x2, x0
    5154:      	ldr	w0, [x0]
    5158:      	sxtw	x0, w0
    515c:      	cmp	x0, #0x0
    5160:      	b.ne	0x4fdc <_stogir.stack.validate+0x268>
    5164:      	movz	x1, #0x0, lsl #48
    5168:      	mov	x0, #0x8                ; =8
    516c:      	movz	x2, #0x0, lsl #48
    5170:      	b	0x4ff0 <_stogir.stack.validate+0x27c>
    5174:      	movz	x1, #0x0, lsl #48
    5178:      	b	0x509c <_stogir.stack.validate+0x328>
    517c:      	movz	x1, #0x0, lsl #48
    5180:      	b	0x5094 <_stogir.stack.validate+0x320>
    5184:      	ldr	x3, [x0, #0x78]
    5188:      	add	x2, x2, x3
    518c:      	ldr	w2, [x2]
    5190:      	uxtb	w16, w1
    5194:      	cmp	w16, wzr
    5198:      	b.eq	0x5204 <_stogir.stack.validate+0x490>
    519c:      	mov	x1, #0x3                ; =3
    51a0:      	b	0x5218 <_stogir.stack.validate+0x4a4>
    51a4:      	add	x16, sp, #0x10
    51a8:      	ldr	w0, [x16]
    51ac:      	add	x16, sp, #0x10
    51b0:      	ldr	w1, [x16, #0x4]
    51b4:      	add	x16, sp, #0x10
    51b8:      	ldr	w2, [x16, #0x8]
    51bc:      	lsr	w1, w1, #0
    51c0:      	ubfx	x0, x0, #8, #8
    51c4:      	lsr	w2, w2, #0
    51c8:      	lsr	w0, w0, #0
    51cc:      	add	x8, sp, #0x20
    51d0:      	mov	w3, w1
    51d4:      	mov	w1, w19
    51d8:      	mov	w4, w2
    51dc:      	mov	w2, w0
    51e0:      	mov	x0, x23
    51e4:      	bl	0x51e4 <_stogir.stack.validate+0x470>
		00000000000051e4:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    51e8:      	add	x16, sp, #0x20
    51ec:      	ldr	x1, [x16]
    51f0:      	add	x16, sp, #0x20
    51f4:      	ldr	x0, [x16, #0x8]
    51f8:      	add	x16, sp, #0x20
    51fc:      	ldr	x2, [x16, #0x10]
    5200:      	b	0x4e80 <_stogir.stack.validate+0x10c>
    5204:      	uxtb	w16, w20
    5208:      	cmp	w16, wzr
    520c:      	mov	x16, #0x1               ; =1
    5210:      	mov	x17, #0x2               ; =2
    5214:      	csel	x1, x16, x17, ne
    5218:      	sxtw	x2, w2
    521c:      	lsr	w1, w1, #0
    5220:      	sxtw	x1, w1
    5224:      	cmp	x2, x1
    5228:      	b.ne	0x5354 <_stogir.stack.validate+0x5e0>
    522c:      	add	x16, sp, #0x10
    5230:      	ldr	w1, [x16]
    5234:      	orr	x2, x1, xzr
    5238:      	ubfx	x2, x2, #16, #16
    523c:      	and	x2, x2, #0x8000
    5240:      	uxth	w2, w2
    5244:      	cmp	x2, #0x0
    5248:      	b.ne	0x52e8 <_stogir.stack.validate+0x574>
    524c:      	mov	x22, x8
    5250:      	mov	x23, x0
    5254:      	lsr	w19, w19, #0
    5258:      	uxtb	w16, w20
    525c:      	cmp	w16, wzr
    5260:      	b.ne	0x51a4 <_stogir.stack.validate+0x430>
    5264:      	uxtb	w16, w21
    5268:      	cmp	w16, wzr
    526c:      	b.ne	0x51a4 <_stogir.stack.validate+0x430>
    5270:      	add	x16, sp, #0x10
    5274:      	ldr	w0, [x16]
    5278:      	add	x16, sp, #0x10
    527c:      	ldr	w1, [x16, #0x4]
    5280:      	add	x16, sp, #0x10
    5284:      	ldr	w2, [x16, #0x8]
    5288:      	lsr	w1, w1, #0
    528c:      	ubfx	x0, x0, #8, #8
    5290:      	add	x16, sp, #0x10
    5294:      	ldr	w3, [x16, #0xc]
    5298:      	lsr	w2, w2, #0
    529c:      	lsr	w3, w3, #0
    52a0:      	lsr	w0, w0, #0
    52a4:      	add	x8, sp, #0x40
    52a8:      	mov	w4, w2
    52ac:      	mov	w2, w0
    52b0:      	mov	x0, x23
    52b4:      	mov	w5, w3
    52b8:      	mov	w3, w1
    52bc:      	mov	w1, w19
    52c0:      	bl	0x52c0 <_stogir.stack.validate+0x54c>
		00000000000052c0:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    52c4:      	add	x16, sp, #0x40
    52c8:      	ldr	x1, [x16]
    52cc:      	add	x16, sp, #0x40
    52d0:      	ldr	x0, [x16, #0x8]
    52d4:      	add	x16, sp, #0x40
    52d8:      	ldr	x2, [x16, #0x10]
    52dc:      	b	0x5200 <_stogir.stack.validate+0x48c>
    52e0:      	movz	x1, #0x0, lsl #48
    52e4:      	b	0x5178 <_stogir.stack.validate+0x404>
    52e8:      	uxtb	w2, w1
    52ec:      	cmp	x2, #0x51
    52f0:      	b.ne	0x535c <_stogir.stack.validate+0x5e8>
    52f4:      	ubfx	x1, x1, #16, #16
    52f8:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    52fc:      	b.ne	0x5364 <_stogir.stack.validate+0x5f0>
    5300:      	add	x16, sp, #0x10
    5304:      	ldr	w1, [x16, #0x4]
    5308:      	add	x16, sp, #0x10
    530c:      	ldr	w2, [x16, #0x8]
    5310:      	lsr	w1, w1, #0
    5314:      	lsr	w2, w2, #0
    5318:      	mov	x22, x8
    531c:      	mov	x23, x0
    5320:      	bl	0x5320 <_stogir.stack.validate+0x5ac>
		0000000000005320:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    5324:      	cmp	x0, #0x0
    5328:      	b.ne	0x5254 <_stogir.stack.validate+0x4e0>
    532c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		000000000000532c:  ARM64_RELOC_PAGE21	l_stogir.396
    5330:      	ldr	x16, [x16]
		0000000000005330:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    5334:      	orr	x0, x16, xzr
    5338:      	mov	x1, #0x1                ; =1
    533c:      	mov	x2, #0x26               ; =38
    5340:      	b	0x5200 <_stogir.stack.validate+0x48c>
    5344:      	brk	#0
    5348:      	b	0x5344 <_stogir.stack.validate+0x5d0>
    534c:      	brk	#0
    5350:      	b	0x534c <_stogir.stack.validate+0x5d8>
    5354:      	mov	x22, x8
    5358:      	b	0x4e6c <_stogir.stack.validate+0xf8>
    535c:      	mov	x22, x8
    5360:      	b	0x532c <_stogir.stack.validate+0x5b8>
    5364:      	mov	x22, x8
    5368:      	b	0x532c <_stogir.stack.validate+0x5b8>

000000000000536c <_stogir.locals.validate>:
    536c:      	sub	sp, sp, #0xb0
    5370:      	str	x29, [sp]
    5374:      	str	x30, [sp, #0x8]
    5378:      	mov	x29, sp
    537c:      	str	x19, [sp, #0x70]
    5380:      	str	x20, [sp, #0x78]
    5384:      	str	x21, [sp, #0x80]
    5388:      	str	x22, [sp, #0x88]
    538c:      	str	x23, [sp, #0x90]
    5390:      	str	x24, [sp, #0x98]
    5394:      	str	x25, [sp, #0xa0]
    5398:      	sxtw	x1, w1
    539c:      	lsl	x3, x1, #2
    53a0:      	cmp	x1, #0x0
    53a4:      	cset	w4, gt
    53a8:      	movz	x16, #0x0, lsl #48
    53ac:      	sub	x5, x16, x1
    53b0:      	sub	x6, x5, #0x1
    53b4:      	uxtb	w16, w4
    53b8:      	cmp	w16, wzr
    53bc:      	b.eq	0x53fc <_stogir.locals.validate+0x90>
    53c0:      	ldr	x5, [x0, #0x8]
    53c4:      	cmp	x1, x5
    53c8:      	b.ge	0x5494 <_stogir.locals.validate+0x128>
    53cc:      	add	x5, x0, #0x78
    53d0:      	ldr	x5, [x5, #0x8]
    53d4:      	cmp	x1, x5
    53d8:      	b.ge	0x5590 <_stogir.locals.validate+0x224>
    53dc:      	ldr	x5, [x0, #0x78]
    53e0:      	add	x5, x3, x5
    53e4:      	ldr	w5, [x5]
    53e8:      	sxtw	x5, w5
    53ec:      	cmp	x5, #0x0
    53f0:      	cset	w5, ge
    53f4:      	ubfx	x5, x5, #0, #8
    53f8:      	b	0x5594 <_stogir.locals.validate+0x228>
    53fc:      	cmp	x1, #0x0
    5400:      	b.ge	0x549c <_stogir.locals.validate+0x130>
    5404:      	add	x7, x0, #0x28
    5408:      	add	x9, x0, #0x50
    540c:      	ldr	x7, [x7, #0x8]
    5410:      	ldr	x9, [x9, #0x8]
    5414:      	cmp	x7, x9
    5418:      	b.ne	0x5444 <_stogir.locals.validate+0xd8>
    541c:      	cmp	x5, x7
    5420:      	b.gt	0x5614 <_stogir.locals.validate+0x2a8>
    5424:      	ldr	x5, [x0, #0x50]
    5428:      	add	x5, x5, x6, lsl #2
    542c:      	ldr	w5, [x5]
    5430:      	sxtw	x5, w5
    5434:      	cmp	x5, #0x0
    5438:      	cset	w5, gt
    543c:      	ubfx	x5, x5, #0, #8
    5440:      	b	0x5618 <_stogir.locals.validate+0x2ac>
    5444:      	movz	x5, #0x0, lsl #48
    5448:      	b	0x54a0 <_stogir.locals.validate+0x134>
    544c:      	cmp	x4, #0x0
    5450:      	cset	w4, ne
    5454:      	uxtb	w16, w4
    5458:      	cmp	w16, wzr
    545c:      	mov	x16, #0x2               ; =2
    5460:      	mov	x17, #0x3               ; =3
    5464:      	csel	x4, x16, x17, ne
    5468:      	lsr	w4, w4, #0
    546c:      	sxtw	x4, w4
    5470:      	cmp	x1, #0x0
    5474:      	b.gt	0x5598 <_stogir.locals.validate+0x22c>
    5478:      	mov	x23, x8
    547c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		000000000000547c:  ARM64_RELOC_PAGE21	l_stogir.397
    5480:      	ldr	x16, [x16]
		0000000000005480:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    5484:      	orr	x0, x16, xzr
    5488:      	mov	x2, #0x1                ; =1
    548c:      	mov	x1, #0x17               ; =23
    5490:      	b	0x5534 <_stogir.locals.validate+0x1c8>
    5494:      	movz	x5, #0x0, lsl #48
    5498:      	b	0x54a0 <_stogir.locals.validate+0x134>
    549c:      	movz	x5, #0x0, lsl #48
    54a0:      	cmp	x5, #0x0
    54a4:      	b.eq	0x54e0 <_stogir.locals.validate+0x174>
    54a8:      	uxtb	w16, w4
    54ac:      	cmp	w16, wzr
    54b0:      	b.eq	0x54c8 <_stogir.locals.validate+0x15c>
    54b4:      	ldr	x4, [x0]
    54b8:      	add	x4, x4, x1, lsl #4
    54bc:      	ldr	x5, [x4]
    54c0:      	ldr	x4, [x4, #0x8]
    54c4:      	b	0x54d8 <_stogir.locals.validate+0x16c>
    54c8:      	ldr	x4, [x0, #0x28]
    54cc:      	add	x4, x4, x6, lsl #4
    54d0:      	ldr	x5, [x4]
    54d4:      	ldr	x4, [x4, #0x8]
    54d8:      	mov	x6, #0x1                ; =1
    54dc:      	b	0x54ec <_stogir.locals.validate+0x180>
    54e0:      	movz	x6, #0x0, lsl #48
    54e4:      	movz	x5, #0x0, lsl #48
    54e8:      	movz	x4, #0x0, lsl #48
    54ec:      	lsr	w6, w6, #0
    54f0:      	lsr	x16, x6, #0
    54f4:      	cmp	x16, #0x1
    54f8:      	b.eq	0x5514 <_stogir.locals.validate+0x1a8>
    54fc:      	b.lo	0x5504 <_stogir.locals.validate+0x198>
    5500:      	b	0x5518 <_stogir.locals.validate+0x1ac>
    5504:      	cmp	x16, #0x0
    5508:      	b.eq	0x5510 <_stogir.locals.validate+0x1a4>
    550c:      	b	0x5518 <_stogir.locals.validate+0x1ac>
    5510:      	b	0x551c <_stogir.locals.validate+0x1b0>
    5514:      	b	0x556c <_stogir.locals.validate+0x200>
    5518:      	b	0x574c <_stogir.locals.validate+0x3e0>
    551c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		000000000000551c:  ARM64_RELOC_PAGE21	l_stogir.398
    5520:      	ldr	x16, [x16]
		0000000000005520:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    5524:      	orr	x0, x16, xzr
    5528:      	mov	x23, x8
    552c:      	mov	x2, #0x1                ; =1
    5530:      	mov	x1, #0x17               ; =23
    5534:      	str	x2, [x23]
    5538:      	str	x0, [x23, #0x8]
    553c:      	str	x1, [x23, #0x10]
    5540:      	ldr	x19, [sp, #0x70]
    5544:      	ldr	x20, [sp, #0x78]
    5548:      	ldr	x21, [sp, #0x80]
    554c:      	ldr	x22, [sp, #0x88]
    5550:      	ldr	x23, [sp, #0x90]
    5554:      	ldr	x24, [sp, #0x98]
    5558:      	ldr	x25, [sp, #0xa0]
    555c:      	ldr	x29, [sp]
    5560:      	ldr	x30, [sp, #0x8]
    5564:      	add	sp, sp, #0xb0
    5568:      	ret
    556c:      	uxtb	w6, w5
    5570:      	add	x16, sp, #0x10
    5574:      	str	x5, [x16]
    5578:      	add	x16, sp, #0x10
    557c:      	str	x4, [x16, #0x8]
    5580:      	cmp	x6, #0x55
    5584:      	b.ne	0x55f8 <_stogir.locals.validate+0x28c>
    5588:      	mov	x4, #0x1                ; =1
    558c:      	b	0x5604 <_stogir.locals.validate+0x298>
    5590:      	movz	x5, #0x0, lsl #48
    5594:      	b	0x5498 <_stogir.locals.validate+0x12c>
    5598:      	cmp	x6, #0x48
    559c:      	cset	w21, eq
    55a0:      	uxtb	w16, w20
    55a4:      	cmp	w16, wzr
    55a8:      	b.ne	0x561c <_stogir.locals.validate+0x2b0>
    55ac:      	uxtb	w16, w21
    55b0:      	cmp	w16, wzr
    55b4:      	b.ne	0x561c <_stogir.locals.validate+0x2b0>
    55b8:      	cmp	x6, #0x55
    55bc:      	b.lt	0x5ab0 <_stogir.locals.validate+0x744>
    55c0:      	cmp	x6, #0x58
    55c4:      	b.le	0x561c <_stogir.locals.validate+0x2b0>
    55c8:      	mov	x23, x8
    55cc:      	b	0x547c <_stogir.locals.validate+0x110>
    55d0:      	cmp	x6, #0x58
    55d4:      	cset	w5, eq
    55d8:      	ubfx	x19, x5, #0, #8
    55dc:      	cmp	x6, #0x41
    55e0:      	cset	w20, eq
    55e4:      	uxtb	w16, w20
    55e8:      	cmp	w16, wzr
    55ec:      	b.eq	0x544c <_stogir.locals.validate+0xe0>
    55f0:      	mov	x4, #0x1                ; =1
    55f4:      	b	0x5470 <_stogir.locals.validate+0x104>
    55f8:      	cmp	x6, #0x56
    55fc:      	cset	w4, eq
    5600:      	ubfx	x4, x4, #0, #8
    5604:      	cmp	x6, #0x57
    5608:      	b.ne	0x55d0 <_stogir.locals.validate+0x264>
    560c:      	mov	x19, #0x1               ; =1
    5610:      	b	0x55dc <_stogir.locals.validate+0x270>
    5614:      	movz	x5, #0x0, lsl #48
    5618:      	b	0x5448 <_stogir.locals.validate+0xdc>
    561c:      	lsr	w4, w4, #0
    5620:      	sxtw	x4, w4
    5624:      	ldr	x5, [x0, #0x78]
    5628:      	add	x3, x3, x5
    562c:      	ldr	w3, [x3]
    5630:      	sxtw	x3, w3
    5634:      	cmp	x3, x4
    5638:      	b.ne	0x5ab8 <_stogir.locals.validate+0x74c>
    563c:      	uxtb	w16, w20
    5640:      	cmp	w16, wzr
    5644:      	b.ne	0x5664 <_stogir.locals.validate+0x2f8>
    5648:      	uxtb	w16, w21
    564c:      	cmp	w16, wzr
    5650:      	b.ne	0x5664 <_stogir.locals.validate+0x2f8>
    5654:      	add	x16, sp, #0x10
    5658:      	ldr	w1, [x16, #0x8]
    565c:      	sxtw	x1, w1
    5660:      	b	0x567c <_stogir.locals.validate+0x310>
    5664:      	uxtb	w16, w21
    5668:      	cmp	w16, wzr
    566c:      	b.ne	0x567c <_stogir.locals.validate+0x310>
    5670:      	add	x16, sp, #0x10
    5674:      	ldr	w1, [x16, #0x4]
    5678:      	sxtw	x1, w1
    567c:      	add	x16, sp, #0x20
    5680:      	orr	x22, x16, xzr
    5684:      	lsr	w2, w2, #0
    5688:      	lsr	w1, w1, #0
    568c:      	mov	x23, x8
    5690:      	add	x8, sp, #0x20
    5694:      	mov	x24, x0
    5698:      	mov	w25, w2
    569c:      	bl	0x569c <_stogir.locals.validate+0x330>
		000000000000569c:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    56a0:      	add	x16, sp, #0x20
    56a4:      	ldr	w0, [x16]
    56a8:      	lsr	x16, x0, #0
    56ac:      	cmp	x16, #0x1
    56b0:      	b.eq	0x56cc <_stogir.locals.validate+0x360>
    56b4:      	b.lo	0x56bc <_stogir.locals.validate+0x350>
    56b8:      	b	0x56d0 <_stogir.locals.validate+0x364>
    56bc:      	cmp	x16, #0x0
    56c0:      	b.eq	0x56c8 <_stogir.locals.validate+0x35c>
    56c4:      	b	0x56d0 <_stogir.locals.validate+0x364>
    56c8:      	b	0x56ec <_stogir.locals.validate+0x380>
    56cc:      	b	0x56d4 <_stogir.locals.validate+0x368>
    56d0:      	b	0x5924 <_stogir.locals.validate+0x5b8>
    56d4:      	add	x1, x22, #0x8
    56d8:      	add	x16, sp, #0x20
    56dc:      	ldr	x0, [x16, #0x8]
    56e0:      	ldr	x1, [x1, #0x8]
    56e4:      	mov	x2, #0x1                ; =1
    56e8:      	b	0x5490 <_stogir.locals.validate+0x124>
    56ec:      	add	x16, sp, #0x20
    56f0:      	ldr	x22, [x16, #0x8]
    56f4:      	uxtb	w16, w21
    56f8:      	cmp	w16, wzr
    56fc:      	b.eq	0x5718 <_stogir.locals.validate+0x3ac>
    5700:      	lsr	w22, w22, #0
    5704:      	sxtw	x22, w22
    5708:      	and	x0, x22, #0xffffffff
    570c:      	movz	x2, #0x0, lsl #48
    5710:      	movz	x1, #0x0, lsl #48
    5714:      	b	0x56e8 <_stogir.locals.validate+0x37c>
    5718:      	uxtb	w16, w20
    571c:      	cmp	w16, wzr
    5720:      	b.eq	0x576c <_stogir.locals.validate+0x400>
    5724:      	add	x16, sp, #0x10
    5728:      	ldr	w0, [x16]
    572c:      	ubfx	x0, x0, #8, #8
    5730:      	cmp	x0, #0x6
    5734:      	b.ne	0x5754 <_stogir.locals.validate+0x3e8>
    5738:      	sxtw	x25, w25
    573c:      	and	x0, x25, #0xffffffff
    5740:      	movz	x2, #0x0, lsl #48
    5744:      	movz	x1, #0x0, lsl #48
    5748:      	b	0x5768 <_stogir.locals.validate+0x3fc>
    574c:      	brk	#0
    5750:      	b	0x574c <_stogir.locals.validate+0x3e0>
    5754:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		0000000000005754:  ARM64_RELOC_PAGE21	l_stogir.399
    5758:      	ldr	x16, [x16]
		0000000000005758:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    575c:      	orr	x0, x16, xzr
    5760:      	mov	x2, #0x1                ; =1
    5764:      	mov	x1, #0x21               ; =33
    5768:      	b	0x5714 <_stogir.locals.validate+0x3a8>
    576c:      	add	x16, sp, #0x10
    5770:      	ldr	w0, [x16, #0x4]
    5774:      	sxtw	x0, w0
    5778:      	cmp	x0, #0x0
    577c:      	cset	w1, gt
    5780:      	movz	x16, #0x0, lsl #48
    5784:      	sub	x2, x16, x0
    5788:      	sub	x3, x2, #0x1
    578c:      	uxtb	w16, w1
    5790:      	cmp	w16, wzr
    5794:      	b.eq	0x5868 <_stogir.locals.validate+0x4fc>
    5798:      	ldr	x2, [x24, #0x8]
    579c:      	cmp	x0, x2
    57a0:      	b.ge	0x5860 <_stogir.locals.validate+0x4f4>
    57a4:      	add	x2, x24, #0x78
    57a8:      	ldr	x2, [x2, #0x8]
    57ac:      	cmp	x0, x2
    57b0:      	b.ge	0x5914 <_stogir.locals.validate+0x5a8>
    57b4:      	ldr	x2, [x24, #0x78]
    57b8:      	add	x2, x2, x0, lsl #2
    57bc:      	ldr	w2, [x2]
    57c0:      	sxtw	x2, w2
    57c4:      	cmp	x2, #0x0
    57c8:      	cset	w2, ge
    57cc:      	ubfx	x2, x2, #0, #8
    57d0:      	b	0x5918 <_stogir.locals.validate+0x5ac>
    57d4:      	movz	x1, #0x0, lsl #48
    57d8:      	movz	x0, #0x0, lsl #48
    57dc:      	lsr	w1, w1, #0
    57e0:      	lsr	x16, x1, #0
    57e4:      	cmp	x16, #0x1
    57e8:      	b.eq	0x5804 <_stogir.locals.validate+0x498>
    57ec:      	b.lo	0x57f4 <_stogir.locals.validate+0x488>
    57f0:      	b	0x5808 <_stogir.locals.validate+0x49c>
    57f4:      	cmp	x16, #0x0
    57f8:      	b.eq	0x5800 <_stogir.locals.validate+0x494>
    57fc:      	b	0x5808 <_stogir.locals.validate+0x49c>
    5800:      	b	0x580c <_stogir.locals.validate+0x4a0>
    5804:      	b	0x58b0 <_stogir.locals.validate+0x544>
    5808:      	b	0x5a84 <_stogir.locals.validate+0x718>
    580c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		000000000000580c:  ARM64_RELOC_PAGE21	l_stogir.400
    5810:      	ldr	x16, [x16]
		0000000000005810:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    5814:      	orr	x0, x16, xzr
    5818:      	mov	x2, #0x1                ; =1
    581c:      	mov	x1, #0x1c               ; =28
    5820:      	b	0x5768 <_stogir.locals.validate+0x3fc>
    5824:      	ldr	x0, [x24, #0x28]
    5828:      	add	x0, x0, x3, lsl #4
    582c:      	ldr	x0, [x0]
    5830:      	mov	x1, #0x1                ; =1
    5834:      	b	0x57dc <_stogir.locals.validate+0x470>
    5838:      	movz	x2, #0x0, lsl #48
    583c:      	cmp	x2, #0x0
    5840:      	b.eq	0x57d4 <_stogir.locals.validate+0x468>
    5844:      	uxtb	w16, w1
    5848:      	cmp	w16, wzr
    584c:      	b.eq	0x5824 <_stogir.locals.validate+0x4b8>
    5850:      	ldr	x1, [x24]
    5854:      	add	x0, x1, x0, lsl #4
    5858:      	ldr	x0, [x0]
    585c:      	b	0x5830 <_stogir.locals.validate+0x4c4>
    5860:      	movz	x2, #0x0, lsl #48
    5864:      	b	0x583c <_stogir.locals.validate+0x4d0>
    5868:      	cmp	x0, #0x0
    586c:      	b.ge	0x5838 <_stogir.locals.validate+0x4cc>
    5870:      	add	x4, x24, #0x28
    5874:      	add	x5, x24, #0x50
    5878:      	ldr	x4, [x4, #0x8]
    587c:      	ldr	x5, [x5, #0x8]
    5880:      	cmp	x4, x5
    5884:      	b.ne	0x590c <_stogir.locals.validate+0x5a0>
    5888:      	cmp	x2, x4
    588c:      	b.gt	0x591c <_stogir.locals.validate+0x5b0>
    5890:      	ldr	x2, [x24, #0x50]
    5894:      	add	x2, x2, x3, lsl #2
    5898:      	ldr	w2, [x2]
    589c:      	sxtw	x2, w2
    58a0:      	cmp	x2, #0x0
    58a4:      	cset	w2, gt
    58a8:      	ubfx	x2, x2, #0, #8
    58ac:      	b	0x5920 <_stogir.locals.validate+0x5b4>
    58b0:      	add	x16, sp, #0x10
    58b4:      	ldr	w1, [x16, #0x4]
    58b8:      	sxtw	x1, w1
    58bc:      	cmp	x1, #0x0
    58c0:      	b.le	0x58f4 <_stogir.locals.validate+0x588>
    58c4:      	uxtb	w0, w0
    58c8:      	cmp	x0, #0x83
    58cc:      	cset	w1, lt
    58d0:      	uxtb	w16, w1
    58d4:      	cmp	w16, wzr
    58d8:      	b.eq	0x592c <_stogir.locals.validate+0x5c0>
    58dc:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		00000000000058dc:  ARM64_RELOC_PAGE21	l_stogir.401
    58e0:      	ldr	x16, [x16]
		00000000000058e0:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    58e4:      	orr	x2, x16, xzr
    58e8:      	add	x2, x0, x2
    58ec:      	ldrb	w2, [x2]
    58f0:      	b	0x5930 <_stogir.locals.validate+0x5c4>
    58f4:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		00000000000058f4:  ARM64_RELOC_PAGE21	l_stogir.402
    58f8:      	ldr	x16, [x16]
		00000000000058f8:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    58fc:      	orr	x0, x16, xzr
    5900:      	mov	x2, #0x1                ; =1
    5904:      	mov	x1, #0x1c               ; =28
    5908:      	b	0x5820 <_stogir.locals.validate+0x4b4>
    590c:      	movz	x2, #0x0, lsl #48
    5910:      	b	0x583c <_stogir.locals.validate+0x4d0>
    5914:      	movz	x2, #0x0, lsl #48
    5918:      	b	0x5864 <_stogir.locals.validate+0x4f8>
    591c:      	movz	x2, #0x0, lsl #48
    5920:      	b	0x5910 <_stogir.locals.validate+0x5a4>
    5924:      	brk	#0
    5928:      	b	0x5924 <_stogir.locals.validate+0x5b8>
    592c:      	movz	x2, #0x0, lsl #48
    5930:      	uxtb	w2, w2
    5934:      	and	x2, x2, #0x1
    5938:      	uxtb	w2, w2
    593c:      	cmp	x2, #0x0
    5940:      	b.eq	0x58f4 <_stogir.locals.validate+0x588>
    5944:      	uxtb	w16, w1
    5948:      	cmp	w16, wzr
    594c:      	b.eq	0x5968 <_stogir.locals.validate+0x5fc>
    5950:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		0000000000005950:  ARM64_RELOC_PAGE21	l_stogir.401
    5954:      	ldr	x16, [x16]
		0000000000005954:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    5958:      	orr	x1, x16, xzr
    595c:      	add	x0, x0, x1
    5960:      	ldrb	w0, [x0]
    5964:      	b	0x596c <_stogir.locals.validate+0x600>
    5968:      	movz	x0, #0x0, lsl #48
    596c:      	uxtb	w0, w0
    5970:      	and	x0, x0, #0x4
    5974:      	uxtb	w0, w0
    5978:      	cmp	x0, #0x0
    597c:      	cset	w0, eq
    5980:      	uxtb	w16, w0
    5984:      	cmp	w16, wzr
    5988:      	cset	x0, eq
    598c:      	cmp	x0, #0x0
    5990:      	b.ne	0x58f4 <_stogir.locals.validate+0x588>
    5994:      	cmp	x19, #0x0
    5998:      	b.eq	0x5a30 <_stogir.locals.validate+0x6c4>
    599c:      	add	x16, sp, #0x10
    59a0:      	ldr	w0, [x16, #0xc]
    59a4:      	lsr	w0, w0, #0
    59a8:      	add	x8, sp, #0x40
    59ac:      	mov	w1, w0
    59b0:      	mov	x0, x24
    59b4:      	bl	0x59b4 <_stogir.locals.validate+0x648>
		00000000000059b4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    59b8:      	add	x16, sp, #0x40
    59bc:      	ldr	x0, [x16]
    59c0:      	add	x16, sp, #0x40
    59c4:      	ldr	x20, [x16, #0x8]
    59c8:      	b	0x5a3c <_stogir.locals.validate+0x6d0>
    59cc:      	lsr	w25, w25, #0
    59d0:      	lsr	w0, w20, #0
    59d4:      	ubfx	x0, x0, #8, #8
    59d8:      	lsr	w0, w0, #0
    59dc:      	mov	w1, w25
    59e0:      	bl	0x59e0 <_stogir.locals.validate+0x674>
		00000000000059e0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    59e4:      	lsr	w0, w0, #0
    59e8:      	sxtw	x0, w0
    59ec:      	cmp	x0, #0x0
    59f0:      	b.le	0x5a18 <_stogir.locals.validate+0x6ac>
    59f4:      	cmp	x0, x22
    59f8:      	b.gt	0x5a18 <_stogir.locals.validate+0x6ac>
    59fc:      	cmp	x19, #0x0
    5a00:      	b.eq	0x5a8c <_stogir.locals.validate+0x720>
    5a04:      	add	x16, sp, #0x10
    5a08:      	ldr	w1, [x16]
    5a0c:      	ubfx	x1, x1, #8, #8
    5a10:      	cmp	x1, #0x0
    5a14:      	b.eq	0x5a8c <_stogir.locals.validate+0x720>
    5a18:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		0000000000005a18:  ARM64_RELOC_PAGE21	l_stogir.403
    5a1c:      	ldr	x16, [x16]
		0000000000005a1c:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    5a20:      	orr	x0, x16, xzr
    5a24:      	mov	x2, #0x1                ; =1
    5a28:      	mov	x1, #0x23               ; =35
    5a2c:      	b	0x5908 <_stogir.locals.validate+0x59c>
    5a30:      	add	x16, sp, #0x10
    5a34:      	ldr	x20, [x16]
    5a38:      	mov	x0, #0x1                ; =1
    5a3c:      	lsr	w0, w0, #0
    5a40:      	lsr	x16, x0, #0
    5a44:      	cmp	x16, #0x1
    5a48:      	b.eq	0x5a64 <_stogir.locals.validate+0x6f8>
    5a4c:      	b.lo	0x5a54 <_stogir.locals.validate+0x6e8>
    5a50:      	b	0x5a68 <_stogir.locals.validate+0x6fc>
    5a54:      	cmp	x16, #0x0
    5a58:      	b.eq	0x5a60 <_stogir.locals.validate+0x6f4>
    5a5c:      	b	0x5a68 <_stogir.locals.validate+0x6fc>
    5a60:      	b	0x5a6c <_stogir.locals.validate+0x700>
    5a64:      	b	0x59cc <_stogir.locals.validate+0x660>
    5a68:      	b	0x5aa8 <_stogir.locals.validate+0x73c>
    5a6c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		0000000000005a6c:  ARM64_RELOC_PAGE21	l_stogir.404
    5a70:      	ldr	x16, [x16]
		0000000000005a70:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    5a74:      	orr	x0, x16, xzr
    5a78:      	mov	x2, #0x1                ; =1
    5a7c:      	mov	x1, #0x19               ; =25
    5a80:      	b	0x5a2c <_stogir.locals.validate+0x6c0>
    5a84:      	brk	#0
    5a88:      	b	0x5a84 <_stogir.locals.validate+0x718>
    5a8c:      	uxtb	w20, w20
    5a90:      	cmp	x20, #0x48
    5a94:      	b.eq	0x5a18 <_stogir.locals.validate+0x6ac>
    5a98:      	and	x0, x0, #0xffffffff
    5a9c:      	movz	x2, #0x0, lsl #48
    5aa0:      	movz	x1, #0x0, lsl #48
    5aa4:      	b	0x5a2c <_stogir.locals.validate+0x6c0>
    5aa8:      	brk	#0
    5aac:      	b	0x5aa8 <_stogir.locals.validate+0x73c>
    5ab0:      	mov	x23, x8
    5ab4:      	b	0x547c <_stogir.locals.validate+0x110>
    5ab8:      	mov	x23, x8
    5abc:      	b	0x547c <_stogir.locals.validate+0x110>

0000000000005ac0 <_stogir.conversion.validate>:
    5ac0:      	sub	sp, sp, #0x40
    5ac4:      	str	x29, [sp]
    5ac8:      	str	x30, [sp, #0x8]
    5acc:      	mov	x29, sp
    5ad0:      	str	x19, [sp, #0x30]
    5ad4:      	sxtw	x1, w1
    5ad8:      	lsl	x3, x1, #2
    5adc:      	cmp	x1, #0x0
    5ae0:      	cset	w4, gt
    5ae4:      	movz	x16, #0x0, lsl #48
    5ae8:      	sub	x5, x16, x1
    5aec:      	sub	x6, x5, #0x1
    5af0:      	uxtb	w16, w4
    5af4:      	cmp	w16, wzr
    5af8:      	b.eq	0x5b38 <_stogir.conversion.validate+0x78>
    5afc:      	ldr	x5, [x0, #0x8]
    5b00:      	cmp	x1, x5
    5b04:      	b.ge	0x5b88 <_stogir.conversion.validate+0xc8>
    5b08:      	add	x5, x0, #0x78
    5b0c:      	ldr	x5, [x5, #0x8]
    5b10:      	cmp	x1, x5
    5b14:      	b.ge	0x5c60 <_stogir.conversion.validate+0x1a0>
    5b18:      	ldr	x5, [x0, #0x78]
    5b1c:      	add	x5, x3, x5
    5b20:      	ldr	w5, [x5]
    5b24:      	sxtw	x5, w5
    5b28:      	cmp	x5, #0x0
    5b2c:      	cset	w5, ge
    5b30:      	ubfx	x5, x5, #0, #8
    5b34:      	b	0x5c64 <_stogir.conversion.validate+0x1a4>
    5b38:      	cmp	x1, #0x0
    5b3c:      	b.ge	0x5b90 <_stogir.conversion.validate+0xd0>
    5b40:      	add	x7, x0, #0x28
    5b44:      	add	x9, x0, #0x50
    5b48:      	ldr	x7, [x7, #0x8]
    5b4c:      	ldr	x9, [x9, #0x8]
    5b50:      	cmp	x7, x9
    5b54:      	b.ne	0x5b80 <_stogir.conversion.validate+0xc0>
    5b58:      	cmp	x5, x7
    5b5c:      	b.gt	0x5cf4 <_stogir.conversion.validate+0x234>
    5b60:      	ldr	x5, [x0, #0x50]
    5b64:      	add	x5, x5, x6, lsl #2
    5b68:      	ldr	w5, [x5]
    5b6c:      	sxtw	x5, w5
    5b70:      	cmp	x5, #0x0
    5b74:      	cset	w5, gt
    5b78:      	ubfx	x5, x5, #0, #8
    5b7c:      	b	0x5cf8 <_stogir.conversion.validate+0x238>
    5b80:      	movz	x5, #0x0, lsl #48
    5b84:      	b	0x5b94 <_stogir.conversion.validate+0xd4>
    5b88:      	movz	x5, #0x0, lsl #48
    5b8c:      	b	0x5b94 <_stogir.conversion.validate+0xd4>
    5b90:      	movz	x5, #0x0, lsl #48
    5b94:      	cmp	x5, #0x0
    5b98:      	b.eq	0x5bcc <_stogir.conversion.validate+0x10c>
    5b9c:      	uxtb	w16, w4
    5ba0:      	cmp	w16, wzr
    5ba4:      	b.eq	0x5bb8 <_stogir.conversion.validate+0xf8>
    5ba8:      	ldr	x4, [x0]
    5bac:      	add	x4, x4, x1, lsl #4
    5bb0:      	ldr	x4, [x4]
    5bb4:      	b	0x5bc4 <_stogir.conversion.validate+0x104>
    5bb8:      	ldr	x4, [x0, #0x28]
    5bbc:      	add	x4, x4, x6, lsl #4
    5bc0:      	ldr	x4, [x4]
    5bc4:      	mov	x5, #0x1                ; =1
    5bc8:      	b	0x5bd4 <_stogir.conversion.validate+0x114>
    5bcc:      	movz	x5, #0x0, lsl #48
    5bd0:      	movz	x4, #0x0, lsl #48
    5bd4:      	lsr	w5, w5, #0
    5bd8:      	lsr	x16, x5, #0
    5bdc:      	cmp	x16, #0x1
    5be0:      	b.eq	0x5bfc <_stogir.conversion.validate+0x13c>
    5be4:      	b.lo	0x5bec <_stogir.conversion.validate+0x12c>
    5be8:      	b	0x5c00 <_stogir.conversion.validate+0x140>
    5bec:      	cmp	x16, #0x0
    5bf0:      	b.eq	0x5bf8 <_stogir.conversion.validate+0x138>
    5bf4:      	b	0x5c00 <_stogir.conversion.validate+0x140>
    5bf8:      	b	0x5c04 <_stogir.conversion.validate+0x144>
    5bfc:      	b	0x5c3c <_stogir.conversion.validate+0x17c>
    5c00:      	b	0x5d6c <_stogir.conversion.validate+0x2ac>
    5c04:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		0000000000005c04:  ARM64_RELOC_PAGE21	l_stogir.405
    5c08:      	ldr	x16, [x16]
		0000000000005c08:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    5c0c:      	orr	x0, x16, xzr
    5c10:      	mov	x19, x8
    5c14:      	mov	x1, #0x1                ; =1
    5c18:      	mov	x2, #0x12               ; =18
    5c1c:      	str	x1, [x19]
    5c20:      	str	x0, [x19, #0x8]
    5c24:      	str	x2, [x19, #0x10]
    5c28:      	ldr	x19, [sp, #0x30]
    5c2c:      	ldr	x29, [sp]
    5c30:      	ldr	x30, [sp, #0x8]
    5c34:      	add	sp, sp, #0x40
    5c38:      	ret
    5c3c:      	cmp	x1, #0x0
    5c40:      	b.gt	0x5c68 <_stogir.conversion.validate+0x1a8>
    5c44:      	mov	x19, x8
    5c48:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		0000000000005c48:  ARM64_RELOC_PAGE21	l_stogir.406
    5c4c:      	ldr	x16, [x16]
		0000000000005c4c:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    5c50:      	orr	x0, x16, xzr
    5c54:      	mov	x1, #0x1                ; =1
    5c58:      	mov	x2, #0x1e               ; =30
    5c5c:      	b	0x5c1c <_stogir.conversion.validate+0x15c>
    5c60:      	movz	x5, #0x0, lsl #48
    5c64:      	b	0x5b8c <_stogir.conversion.validate+0xcc>
    5c68:      	uxtb	w1, w4
    5c6c:      	orr	x5, x1, xzr
    5c70:      	cmp	x5, #0x21
    5c74:      	b.lt	0x5e94 <_stogir.conversion.validate+0x3d4>
    5c78:      	cmp	x5, #0x27
    5c7c:      	b.gt	0x5e9c <_stogir.conversion.validate+0x3dc>
    5c80:      	ldr	x5, [x0, #0x78]
    5c84:      	add	x3, x3, x5
    5c88:      	ldr	w3, [x3]
    5c8c:      	sxtw	x3, w3
    5c90:      	cmp	x3, #0x1
    5c94:      	b.ne	0x5ea4 <_stogir.conversion.validate+0x3e4>
    5c98:      	asr	x3, x4, #32
    5c9c:      	cmp	x3, #0x0
    5ca0:      	cset	w6, gt
    5ca4:      	movz	x16, #0x0, lsl #48
    5ca8:      	sub	x7, x16, x3
    5cac:      	sub	x9, x7, #0x1
    5cb0:      	uxtb	w16, w6
    5cb4:      	cmp	w16, wzr
    5cb8:      	b.eq	0x5d24 <_stogir.conversion.validate+0x264>
    5cbc:      	ldr	x7, [x0, #0x8]
    5cc0:      	cmp	x3, x7
    5cc4:      	b.ge	0x5d74 <_stogir.conversion.validate+0x2b4>
    5cc8:      	add	x7, x0, #0x78
    5ccc:      	ldr	x7, [x7, #0x8]
    5cd0:      	cmp	x3, x7
    5cd4:      	b.ge	0x5e14 <_stogir.conversion.validate+0x354>
    5cd8:      	add	x5, x5, x3, lsl #2
    5cdc:      	ldr	w5, [x5]
    5ce0:      	sxtw	x5, w5
    5ce4:      	cmp	x5, #0x0
    5ce8:      	cset	w5, ge
    5cec:      	ubfx	x5, x5, #0, #8
    5cf0:      	b	0x5e18 <_stogir.conversion.validate+0x358>
    5cf4:      	movz	x5, #0x0, lsl #48
    5cf8:      	b	0x5b84 <_stogir.conversion.validate+0xc4>
    5cfc:      	uxtb	w3, w0
    5d00:      	cmp	x3, #0x48
    5d04:      	b.ne	0x5e1c <_stogir.conversion.validate+0x35c>
    5d08:      	mov	x19, x8
    5d0c:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		0000000000005d0c:  ARM64_RELOC_PAGE21	l_stogir.407
    5d10:      	ldr	x16, [x16]
		0000000000005d10:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    5d14:      	orr	x0, x16, xzr
    5d18:      	mov	x1, #0x1                ; =1
    5d1c:      	mov	x2, #0x25               ; =37
    5d20:      	b	0x5c5c <_stogir.conversion.validate+0x19c>
    5d24:      	cmp	x3, #0x0
    5d28:      	b.ge	0x5d7c <_stogir.conversion.validate+0x2bc>
    5d2c:      	add	x5, x0, #0x28
    5d30:      	add	x10, x0, #0x50
    5d34:      	ldr	x5, [x5, #0x8]
    5d38:      	ldr	x10, [x10, #0x8]
    5d3c:      	cmp	x5, x10
    5d40:      	b.ne	0x5e0c <_stogir.conversion.validate+0x34c>
    5d44:      	cmp	x7, x5
    5d48:      	b.gt	0x5e84 <_stogir.conversion.validate+0x3c4>
    5d4c:      	ldr	x5, [x0, #0x50]
    5d50:      	add	x5, x5, x9, lsl #2
    5d54:      	ldr	w5, [x5]
    5d58:      	sxtw	x5, w5
    5d5c:      	cmp	x5, #0x0
    5d60:      	cset	w5, gt
    5d64:      	ubfx	x5, x5, #0, #8
    5d68:      	b	0x5e88 <_stogir.conversion.validate+0x3c8>
    5d6c:      	brk	#0
    5d70:      	b	0x5d6c <_stogir.conversion.validate+0x2ac>
    5d74:      	movz	x5, #0x0, lsl #48
    5d78:      	b	0x5d80 <_stogir.conversion.validate+0x2c0>
    5d7c:      	movz	x5, #0x0, lsl #48
    5d80:      	cmp	x5, #0x0
    5d84:      	b.eq	0x5db8 <_stogir.conversion.validate+0x2f8>
    5d88:      	uxtb	w16, w6
    5d8c:      	cmp	w16, wzr
    5d90:      	b.eq	0x5da4 <_stogir.conversion.validate+0x2e4>
    5d94:      	ldr	x0, [x0]
    5d98:      	add	x0, x0, x3, lsl #4
    5d9c:      	ldr	x0, [x0]
    5da0:      	b	0x5db0 <_stogir.conversion.validate+0x2f0>
    5da4:      	ldr	x0, [x0, #0x28]
    5da8:      	add	x0, x0, x9, lsl #4
    5dac:      	ldr	x0, [x0]
    5db0:      	mov	x3, #0x1                ; =1
    5db4:      	b	0x5dc0 <_stogir.conversion.validate+0x300>
    5db8:      	movz	x3, #0x0, lsl #48
    5dbc:      	movz	x0, #0x0, lsl #48
    5dc0:      	lsr	w3, w3, #0
    5dc4:      	lsr	x16, x3, #0
    5dc8:      	cmp	x16, #0x1
    5dcc:      	b.eq	0x5de8 <_stogir.conversion.validate+0x328>
    5dd0:      	b.lo	0x5dd8 <_stogir.conversion.validate+0x318>
    5dd4:      	b	0x5dec <_stogir.conversion.validate+0x32c>
    5dd8:      	cmp	x16, #0x0
    5ddc:      	b.eq	0x5de4 <_stogir.conversion.validate+0x324>
    5de0:      	b	0x5dec <_stogir.conversion.validate+0x32c>
    5de4:      	b	0x5df0 <_stogir.conversion.validate+0x330>
    5de8:      	b	0x5cfc <_stogir.conversion.validate+0x23c>
    5dec:      	b	0x5e8c <_stogir.conversion.validate+0x3cc>
    5df0:      	adrp	x16, 0x5000 <_stogir.stack.validate+0x28c>
		0000000000005df0:  ARM64_RELOC_PAGE21	l_stogir.408
    5df4:      	ldr	x16, [x16]
		0000000000005df4:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    5df8:      	orr	x0, x16, xzr
    5dfc:      	mov	x19, x8
    5e00:      	mov	x1, #0x1                ; =1
    5e04:      	mov	x2, #0x19               ; =25
    5e08:      	b	0x5d20 <_stogir.conversion.validate+0x260>
    5e0c:      	movz	x5, #0x0, lsl #48
    5e10:      	b	0x5d80 <_stogir.conversion.validate+0x2c0>
    5e14:      	movz	x5, #0x0, lsl #48
    5e18:      	b	0x5d78 <_stogir.conversion.validate+0x2b8>
    5e1c:      	cmp	x3, #0x46
    5e20:      	b.eq	0x5eac <_stogir.conversion.validate+0x3ec>
    5e24:      	lsr	w2, w2, #0
    5e28:      	lsr	w4, w4, #0
    5e2c:      	lsr	w0, w0, #0
    5e30:      	lsr	w1, w1, #0
    5e34:      	ubfx	x3, x4, #8, #8
    5e38:      	ubfx	x0, x0, #8, #8
    5e3c:      	lsr	w3, w3, #0
    5e40:      	lsr	w0, w0, #0
    5e44:      	mov	x19, x8
    5e48:      	add	x8, sp, #0x10
    5e4c:      	fmov	s31, w0
    5e50:      	mov	w0, w1
    5e54:      	fmov	w1, s31
    5e58:      	fmov	s31, w2
    5e5c:      	mov	w2, w3
    5e60:      	fmov	w3, s31
    5e64:      	bl	0x5e64 <_stogir.conversion.validate+0x3a4>
		0000000000005e64:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    5e68:      	add	x16, sp, #0x10
    5e6c:      	ldr	x1, [x16]
    5e70:      	add	x16, sp, #0x10
    5e74:      	ldr	x0, [x16, #0x8]
    5e78:      	add	x16, sp, #0x10
    5e7c:      	ldr	x2, [x16, #0x10]
    5e80:      	b	0x5d20 <_stogir.conversion.validate+0x260>
    5e84:      	movz	x5, #0x0, lsl #48
    5e88:      	b	0x5e10 <_stogir.conversion.validate+0x350>
    5e8c:      	brk	#0
    5e90:      	b	0x5e8c <_stogir.conversion.validate+0x3cc>
    5e94:      	mov	x19, x8
    5e98:      	b	0x5c48 <_stogir.conversion.validate+0x188>
    5e9c:      	mov	x19, x8
    5ea0:      	b	0x5c48 <_stogir.conversion.validate+0x188>
    5ea4:      	mov	x19, x8
    5ea8:      	b	0x5c48 <_stogir.conversion.validate+0x188>
    5eac:      	mov	x19, x8
    5eb0:      	b	0x5d0c <_stogir.conversion.validate+0x24c>

0000000000005eb4 <_stogir.conditional.validate>:
    5eb4:      	sub	sp, sp, #0x40
    5eb8:      	str	x29, [sp]
    5ebc:      	str	x30, [sp, #0x8]
    5ec0:      	mov	x29, sp
    5ec4:      	str	x19, [sp, #0x30]
    5ec8:      	sxtw	x1, w1
    5ecc:      	lsl	x2, x1, #2
    5ed0:      	cmp	x1, #0x0
    5ed4:      	cset	w3, gt
    5ed8:      	movz	x16, #0x0, lsl #48
    5edc:      	sub	x4, x16, x1
    5ee0:      	sub	x5, x4, #0x1
    5ee4:      	uxtb	w16, w3
    5ee8:      	cmp	w16, wzr
    5eec:      	b.eq	0x5f2c <_stogir.conditional.validate+0x78>
    5ef0:      	ldr	x4, [x0, #0x8]
    5ef4:      	cmp	x1, x4
    5ef8:      	b.ge	0x5f7c <_stogir.conditional.validate+0xc8>
    5efc:      	add	x4, x0, #0x78
    5f00:      	ldr	x4, [x4, #0x8]
    5f04:      	cmp	x1, x4
    5f08:      	b.ge	0x6060 <_stogir.conditional.validate+0x1ac>
    5f0c:      	ldr	x4, [x0, #0x78]
    5f10:      	add	x4, x2, x4
    5f14:      	ldr	w4, [x4]
    5f18:      	sxtw	x4, w4
    5f1c:      	cmp	x4, #0x0
    5f20:      	cset	w4, ge
    5f24:      	ubfx	x4, x4, #0, #8
    5f28:      	b	0x6064 <_stogir.conditional.validate+0x1b0>
    5f2c:      	cmp	x1, #0x0
    5f30:      	b.ge	0x5f84 <_stogir.conditional.validate+0xd0>
    5f34:      	add	x6, x0, #0x28
    5f38:      	add	x7, x0, #0x50
    5f3c:      	ldr	x6, [x6, #0x8]
    5f40:      	ldr	x7, [x7, #0x8]
    5f44:      	cmp	x6, x7
    5f48:      	b.ne	0x5f74 <_stogir.conditional.validate+0xc0>
    5f4c:      	cmp	x4, x6
    5f50:      	b.gt	0x60ec <_stogir.conditional.validate+0x238>
    5f54:      	ldr	x4, [x0, #0x50]
    5f58:      	add	x4, x4, x5, lsl #2
    5f5c:      	ldr	w4, [x4]
    5f60:      	sxtw	x4, w4
    5f64:      	cmp	x4, #0x0
    5f68:      	cset	w4, gt
    5f6c:      	ubfx	x4, x4, #0, #8
    5f70:      	b	0x60f0 <_stogir.conditional.validate+0x23c>
    5f74:      	movz	x4, #0x0, lsl #48
    5f78:      	b	0x5f88 <_stogir.conditional.validate+0xd4>
    5f7c:      	movz	x4, #0x0, lsl #48
    5f80:      	b	0x5f88 <_stogir.conditional.validate+0xd4>
    5f84:      	movz	x4, #0x0, lsl #48
    5f88:      	cmp	x4, #0x0
    5f8c:      	b.eq	0x5fc8 <_stogir.conditional.validate+0x114>
    5f90:      	uxtb	w16, w3
    5f94:      	cmp	w16, wzr
    5f98:      	b.eq	0x5fb0 <_stogir.conditional.validate+0xfc>
    5f9c:      	ldr	x3, [x0]
    5fa0:      	add	x3, x3, x1, lsl #4
    5fa4:      	ldr	x4, [x3]
    5fa8:      	ldr	x3, [x3, #0x8]
    5fac:      	b	0x5fc0 <_stogir.conditional.validate+0x10c>
    5fb0:      	ldr	x3, [x0, #0x28]
    5fb4:      	add	x3, x3, x5, lsl #4
    5fb8:      	ldr	x4, [x3]
    5fbc:      	ldr	x3, [x3, #0x8]
    5fc0:      	mov	x5, #0x1                ; =1
    5fc4:      	b	0x5fd4 <_stogir.conditional.validate+0x120>
    5fc8:      	movz	x5, #0x0, lsl #48
    5fcc:      	movz	x4, #0x0, lsl #48
    5fd0:      	movz	x3, #0x0, lsl #48
    5fd4:      	lsr	w5, w5, #0
    5fd8:      	lsr	x16, x5, #0
    5fdc:      	cmp	x16, #0x1
    5fe0:      	b.eq	0x5ffc <_stogir.conditional.validate+0x148>
    5fe4:      	b.lo	0x5fec <_stogir.conditional.validate+0x138>
    5fe8:      	b	0x6000 <_stogir.conditional.validate+0x14c>
    5fec:      	cmp	x16, #0x0
    5ff0:      	b.eq	0x5ff8 <_stogir.conditional.validate+0x144>
    5ff4:      	b	0x6000 <_stogir.conditional.validate+0x14c>
    5ff8:      	b	0x6004 <_stogir.conditional.validate+0x150>
    5ffc:      	b	0x6020 <_stogir.conditional.validate+0x16c>
    6000:      	b	0x60f4 <_stogir.conditional.validate+0x240>
    6004:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		0000000000006004:  ARM64_RELOC_PAGE21	l_stogir.409
    6008:      	ldr	x16, [x16]
		0000000000006008:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    600c:      	orr	x0, x16, xzr
    6010:      	mov	x19, x8
    6014:      	mov	x1, #0x1                ; =1
    6018:      	mov	x2, #0x18               ; =24
    601c:      	b	0x6040 <_stogir.conditional.validate+0x18c>
    6020:      	cmp	x1, #0x0
    6024:      	b.gt	0x6068 <_stogir.conditional.validate+0x1b4>
    6028:      	mov	x19, x8
    602c:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		000000000000602c:  ARM64_RELOC_PAGE21	l_stogir.410
    6030:      	ldr	x16, [x16]
		0000000000006030:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    6034:      	orr	x0, x16, xzr
    6038:      	mov	x1, #0x1                ; =1
    603c:      	mov	x2, #0x18               ; =24
    6040:      	str	x1, [x19]
    6044:      	str	x0, [x19, #0x8]
    6048:      	str	x2, [x19, #0x10]
    604c:      	ldr	x19, [sp, #0x30]
    6050:      	ldr	x29, [sp]
    6054:      	ldr	x30, [sp, #0x8]
    6058:      	add	sp, sp, #0x40
    605c:      	ret
    6060:      	movz	x4, #0x0, lsl #48
    6064:      	b	0x5f80 <_stogir.conditional.validate+0xcc>
    6068:      	uxtb	w1, w4
    606c:      	cmp	x1, #0x3c
    6070:      	b.ne	0x60fc <_stogir.conditional.validate+0x248>
    6074:      	ldr	x1, [x0, #0x78]
    6078:      	add	x1, x2, x1
    607c:      	ldr	w1, [x1]
    6080:      	sxtw	x1, w1
    6084:      	cmp	x1, #0x3
    6088:      	b.ne	0x6104 <_stogir.conditional.validate+0x250>
    608c:      	lsr	w1, w3, #0
    6090:      	lsr	w2, w4, #0
    6094:      	lsr	x4, x4, #32
    6098:      	lsr	w1, w1, #0
    609c:      	lsr	x3, x3, #32
    60a0:      	lsr	w4, w4, #0
    60a4:      	lsr	w3, w3, #0
    60a8:      	ubfx	x2, x2, #8, #8
    60ac:      	lsr	w2, w2, #0
    60b0:      	mov	x19, x8
    60b4:      	add	x8, sp, #0x10
    60b8:      	fmov	s31, w1
    60bc:      	mov	w1, w2
    60c0:      	mov	w2, w4
    60c4:      	mov	w4, w3
    60c8:      	fmov	w3, s31
    60cc:      	bl	0x60cc <_stogir.conditional.validate+0x218>
		00000000000060cc:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    60d0:      	add	x16, sp, #0x10
    60d4:      	ldr	x1, [x16]
    60d8:      	add	x16, sp, #0x10
    60dc:      	ldr	x0, [x16, #0x8]
    60e0:      	add	x16, sp, #0x10
    60e4:      	ldr	x2, [x16, #0x10]
    60e8:      	b	0x6040 <_stogir.conditional.validate+0x18c>
    60ec:      	movz	x4, #0x0, lsl #48
    60f0:      	b	0x5f78 <_stogir.conditional.validate+0xc4>
    60f4:      	brk	#0
    60f8:      	b	0x60f4 <_stogir.conditional.validate+0x240>
    60fc:      	mov	x19, x8
    6100:      	b	0x602c <_stogir.conditional.validate+0x178>
    6104:      	mov	x19, x8
    6108:      	b	0x602c <_stogir.conditional.validate+0x178>

000000000000610c <_stogir.floating.validate>:
    610c:      	sub	sp, sp, #0x50
    6110:      	str	x29, [sp]
    6114:      	str	x30, [sp, #0x8]
    6118:      	mov	x29, sp
    611c:      	str	x19, [sp, #0x40]
    6120:      	sxtw	x1, w1
    6124:      	lsl	x2, x1, #2
    6128:      	cmp	x1, #0x0
    612c:      	cset	w3, gt
    6130:      	movz	x16, #0x0, lsl #48
    6134:      	sub	x4, x16, x1
    6138:      	sub	x5, x4, #0x1
    613c:      	uxtb	w16, w3
    6140:      	cmp	w16, wzr
    6144:      	b.eq	0x6184 <_stogir.floating.validate+0x78>
    6148:      	ldr	x4, [x0, #0x8]
    614c:      	cmp	x1, x4
    6150:      	b.ge	0x61d4 <_stogir.floating.validate+0xc8>
    6154:      	add	x4, x0, #0x78
    6158:      	ldr	x4, [x4, #0x8]
    615c:      	cmp	x1, x4
    6160:      	b.ge	0x62c8 <_stogir.floating.validate+0x1bc>
    6164:      	ldr	x4, [x0, #0x78]
    6168:      	add	x4, x2, x4
    616c:      	ldr	w4, [x4]
    6170:      	sxtw	x4, w4
    6174:      	cmp	x4, #0x0
    6178:      	cset	w4, ge
    617c:      	ubfx	x4, x4, #0, #8
    6180:      	b	0x62cc <_stogir.floating.validate+0x1c0>
    6184:      	cmp	x1, #0x0
    6188:      	b.ge	0x61dc <_stogir.floating.validate+0xd0>
    618c:      	add	x6, x0, #0x28
    6190:      	add	x7, x0, #0x50
    6194:      	ldr	x6, [x6, #0x8]
    6198:      	ldr	x7, [x7, #0x8]
    619c:      	cmp	x6, x7
    61a0:      	b.ne	0x61cc <_stogir.floating.validate+0xc0>
    61a4:      	cmp	x4, x6
    61a8:      	b.gt	0x6354 <_stogir.floating.validate+0x248>
    61ac:      	ldr	x4, [x0, #0x50]
    61b0:      	add	x4, x4, x5, lsl #2
    61b4:      	ldr	w4, [x4]
    61b8:      	sxtw	x4, w4
    61bc:      	cmp	x4, #0x0
    61c0:      	cset	w4, gt
    61c4:      	ubfx	x4, x4, #0, #8
    61c8:      	b	0x6358 <_stogir.floating.validate+0x24c>
    61cc:      	movz	x4, #0x0, lsl #48
    61d0:      	b	0x61e0 <_stogir.floating.validate+0xd4>
    61d4:      	movz	x4, #0x0, lsl #48
    61d8:      	b	0x61e0 <_stogir.floating.validate+0xd4>
    61dc:      	movz	x4, #0x0, lsl #48
    61e0:      	cmp	x4, #0x0
    61e4:      	b.eq	0x6220 <_stogir.floating.validate+0x114>
    61e8:      	uxtb	w16, w3
    61ec:      	cmp	w16, wzr
    61f0:      	b.eq	0x6208 <_stogir.floating.validate+0xfc>
    61f4:      	ldr	x3, [x0]
    61f8:      	add	x3, x3, x1, lsl #4
    61fc:      	ldr	x4, [x3]
    6200:      	ldr	x3, [x3, #0x8]
    6204:      	b	0x6218 <_stogir.floating.validate+0x10c>
    6208:      	ldr	x3, [x0, #0x28]
    620c:      	add	x3, x3, x5, lsl #4
    6210:      	ldr	x4, [x3]
    6214:      	ldr	x3, [x3, #0x8]
    6218:      	mov	x5, #0x1                ; =1
    621c:      	b	0x622c <_stogir.floating.validate+0x120>
    6220:      	movz	x5, #0x0, lsl #48
    6224:      	movz	x4, #0x0, lsl #48
    6228:      	movz	x3, #0x0, lsl #48
    622c:      	lsr	w5, w5, #0
    6230:      	lsr	x16, x5, #0
    6234:      	cmp	x16, #0x1
    6238:      	b.eq	0x6254 <_stogir.floating.validate+0x148>
    623c:      	b.lo	0x6244 <_stogir.floating.validate+0x138>
    6240:      	b	0x6258 <_stogir.floating.validate+0x14c>
    6244:      	cmp	x16, #0x0
    6248:      	b.eq	0x6250 <_stogir.floating.validate+0x144>
    624c:      	b	0x6258 <_stogir.floating.validate+0x14c>
    6250:      	b	0x625c <_stogir.floating.validate+0x150>
    6254:      	b	0x6294 <_stogir.floating.validate+0x188>
    6258:      	b	0x65f0 <_stogir.floating.validate+0x4e4>
    625c:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		000000000000625c:  ARM64_RELOC_PAGE21	l_stogir.411
    6260:      	ldr	x16, [x16]
		0000000000006260:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    6264:      	orr	x0, x16, xzr
    6268:      	mov	x19, x8
    626c:      	mov	x1, #0x1                ; =1
    6270:      	mov	x2, #0x1c               ; =28
    6274:      	str	x1, [x19]
    6278:      	str	x0, [x19, #0x8]
    627c:      	str	x2, [x19, #0x10]
    6280:      	ldr	x19, [sp, #0x40]
    6284:      	ldr	x29, [sp]
    6288:      	ldr	x30, [sp, #0x8]
    628c:      	add	sp, sp, #0x50
    6290:      	ret
    6294:      	add	x16, sp, #0x10
    6298:      	str	x4, [x16]
    629c:      	add	x16, sp, #0x10
    62a0:      	str	x3, [x16, #0x8]
    62a4:      	cmp	x1, #0x0
    62a8:      	b.gt	0x62d0 <_stogir.floating.validate+0x1c4>
    62ac:      	mov	x19, x8
    62b0:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		00000000000062b0:  ARM64_RELOC_PAGE21	l_stogir.412
    62b4:      	ldr	x16, [x16]
		00000000000062b4:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    62b8:      	orr	x0, x16, xzr
    62bc:      	mov	x1, #0x1                ; =1
    62c0:      	mov	x2, #0x1c               ; =28
    62c4:      	b	0x6274 <_stogir.floating.validate+0x168>
    62c8:      	movz	x4, #0x0, lsl #48
    62cc:      	b	0x61d8 <_stogir.floating.validate+0xcc>
    62d0:      	uxtb	w4, w4
    62d4:      	orr	x1, x4, xzr
    62d8:      	cmp	x1, #0xe
    62dc:      	cset	w3, ge
    62e0:      	cmp	x1, #0x19
    62e4:      	cset	w5, le
    62e8:      	cmp	x1, #0x1f
    62ec:      	cset	w6, eq
    62f0:      	cmp	x1, #0x20
    62f4:      	cset	w7, eq
    62f8:      	uxtb	w16, w3
    62fc:      	cmp	w16, wzr
    6300:      	b.eq	0x635c <_stogir.floating.validate+0x250>
    6304:      	uxtb	w16, w5
    6308:      	cmp	w16, wzr
    630c:      	b.eq	0x635c <_stogir.floating.validate+0x250>
    6310:      	cmp	x1, #0x1d
    6314:      	cset	w1, eq
    6318:      	ldr	x9, [x0, #0x78]
    631c:      	add	x2, x2, x9
    6320:      	ldr	w2, [x2]
    6324:      	uxtb	w16, w6
    6328:      	cmp	w16, wzr
    632c:      	b.ne	0x639c <_stogir.floating.validate+0x290>
    6330:      	uxtb	w16, w7
    6334:      	cmp	w16, wzr
    6338:      	b.ne	0x639c <_stogir.floating.validate+0x290>
    633c:      	uxtb	w16, w1
    6340:      	cmp	w16, wzr
    6344:      	mov	x16, #0x3               ; =3
    6348:      	mov	x17, #0x2               ; =2
    634c:      	csel	x6, x16, x17, ne
    6350:      	b	0x63a0 <_stogir.floating.validate+0x294>
    6354:      	movz	x4, #0x0, lsl #48
    6358:      	b	0x61d0 <_stogir.floating.validate+0xc4>
    635c:      	uxtb	w16, w6
    6360:      	cmp	w16, wzr
    6364:      	b.ne	0x6310 <_stogir.floating.validate+0x204>
    6368:      	uxtb	w16, w7
    636c:      	cmp	w16, wzr
    6370:      	b.ne	0x6310 <_stogir.floating.validate+0x204>
    6374:      	cmp	x1, #0x1a
    6378:      	b.lt	0x6384 <_stogir.floating.validate+0x278>
    637c:      	cmp	x1, #0x1d
    6380:      	b.le	0x6310 <_stogir.floating.validate+0x204>
    6384:      	cmp	x1, #0x3a
    6388:      	b.eq	0x6310 <_stogir.floating.validate+0x204>
    638c:      	cmp	x1, #0x3b
    6390:      	b.eq	0x6310 <_stogir.floating.validate+0x204>
    6394:      	mov	x19, x8
    6398:      	b	0x62b0 <_stogir.floating.validate+0x1a4>
    639c:      	mov	x6, #0x1                ; =1
    63a0:      	sxtw	x2, w2
    63a4:      	lsr	w6, w6, #0
    63a8:      	sxtw	x6, w6
    63ac:      	cmp	x2, x6
    63b0:      	b.ne	0x6600 <_stogir.floating.validate+0x4f4>
    63b4:      	add	x16, sp, #0x10
    63b8:      	ldr	w2, [x16, #0x4]
    63bc:      	sxtw	x2, w2
    63c0:      	cmp	x2, #0x0
    63c4:      	cset	w6, gt
    63c8:      	movz	x16, #0x0, lsl #48
    63cc:      	sub	x7, x16, x2
    63d0:      	sub	x9, x7, #0x1
    63d4:      	uxtb	w16, w6
    63d8:      	cmp	w16, wzr
    63dc:      	b.eq	0x6434 <_stogir.floating.validate+0x328>
    63e0:      	ldr	x7, [x0, #0x8]
    63e4:      	cmp	x2, x7
    63e8:      	b.ge	0x647c <_stogir.floating.validate+0x370>
    63ec:      	add	x7, x0, #0x78
    63f0:      	ldr	x7, [x7, #0x8]
    63f4:      	cmp	x2, x7
    63f8:      	b.ge	0x654c <_stogir.floating.validate+0x440>
    63fc:      	ldr	x7, [x0, #0x78]
    6400:      	add	x7, x7, x2, lsl #2
    6404:      	ldr	w7, [x7]
    6408:      	sxtw	x7, w7
    640c:      	cmp	x7, #0x0
    6410:      	cset	w7, ge
    6414:      	ubfx	x7, x7, #0, #8
    6418:      	b	0x6550 <_stogir.floating.validate+0x444>
    641c:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		000000000000641c:  ARM64_RELOC_PAGE21	l_stogir.413
    6420:      	ldr	x16, [x16]
		0000000000006420:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    6424:      	orr	x0, x16, xzr
    6428:      	mov	x1, #0x1                ; =1
    642c:      	mov	x2, #0x1d               ; =29
    6430:      	b	0x62c4 <_stogir.floating.validate+0x1b8>
    6434:      	cmp	x2, #0x0
    6438:      	b.ge	0x6484 <_stogir.floating.validate+0x378>
    643c:      	add	x10, x0, #0x28
    6440:      	add	x11, x0, #0x50
    6444:      	ldr	x10, [x10, #0x8]
    6448:      	ldr	x11, [x11, #0x8]
    644c:      	cmp	x10, x11
    6450:      	b.ne	0x6544 <_stogir.floating.validate+0x438>
    6454:      	cmp	x7, x10
    6458:      	b.gt	0x65e8 <_stogir.floating.validate+0x4dc>
    645c:      	ldr	x7, [x0, #0x50]
    6460:      	add	x7, x7, x9, lsl #2
    6464:      	ldr	w7, [x7]
    6468:      	sxtw	x7, w7
    646c:      	cmp	x7, #0x0
    6470:      	cset	w7, gt
    6474:      	ubfx	x7, x7, #0, #8
    6478:      	b	0x65ec <_stogir.floating.validate+0x4e0>
    647c:      	movz	x7, #0x0, lsl #48
    6480:      	b	0x6488 <_stogir.floating.validate+0x37c>
    6484:      	movz	x7, #0x0, lsl #48
    6488:      	cmp	x7, #0x0
    648c:      	b.eq	0x64c0 <_stogir.floating.validate+0x3b4>
    6490:      	uxtb	w16, w6
    6494:      	cmp	w16, wzr
    6498:      	b.eq	0x64ac <_stogir.floating.validate+0x3a0>
    649c:      	ldr	x6, [x0]
    64a0:      	add	x2, x6, x2, lsl #4
    64a4:      	ldr	x2, [x2]
    64a8:      	b	0x64b8 <_stogir.floating.validate+0x3ac>
    64ac:      	ldr	x2, [x0, #0x28]
    64b0:      	add	x2, x2, x9, lsl #4
    64b4:      	ldr	x2, [x2]
    64b8:      	mov	x6, #0x1                ; =1
    64bc:      	b	0x64c8 <_stogir.floating.validate+0x3bc>
    64c0:      	movz	x6, #0x0, lsl #48
    64c4:      	movz	x2, #0x0, lsl #48
    64c8:      	lsr	w6, w6, #0
    64cc:      	lsr	x16, x6, #0
    64d0:      	cmp	x16, #0x1
    64d4:      	b.eq	0x64f0 <_stogir.floating.validate+0x3e4>
    64d8:      	b.lo	0x64e0 <_stogir.floating.validate+0x3d4>
    64dc:      	b	0x64f4 <_stogir.floating.validate+0x3e8>
    64e0:      	cmp	x16, #0x0
    64e4:      	b.eq	0x64ec <_stogir.floating.validate+0x3e0>
    64e8:      	b	0x64f4 <_stogir.floating.validate+0x3e8>
    64ec:      	b	0x64f8 <_stogir.floating.validate+0x3ec>
    64f0:      	b	0x6514 <_stogir.floating.validate+0x408>
    64f4:      	b	0x65f8 <_stogir.floating.validate+0x4ec>
    64f8:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		00000000000064f8:  ARM64_RELOC_PAGE21	l_stogir.414
    64fc:      	ldr	x16, [x16]
		00000000000064fc:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    6500:      	orr	x0, x16, xzr
    6504:      	mov	x19, x8
    6508:      	mov	x1, #0x1                ; =1
    650c:      	mov	x2, #0x18               ; =24
    6510:      	b	0x6430 <_stogir.floating.validate+0x324>
    6514:      	lsr	w2, w2, #0
    6518:      	add	x16, sp, #0x10
    651c:      	ldr	w6, [x16]
    6520:      	ubfx	x2, x2, #8, #8
    6524:      	uxtb	w16, w3
    6528:      	cmp	w16, wzr
    652c:      	b.eq	0x65a4 <_stogir.floating.validate+0x498>
    6530:      	uxtb	w16, w5
    6534:      	cmp	w16, wzr
    6538:      	b.eq	0x65a4 <_stogir.floating.validate+0x498>
    653c:      	mov	x3, #0x1                ; =1
    6540:      	b	0x65a8 <_stogir.floating.validate+0x49c>
    6544:      	movz	x7, #0x0, lsl #48
    6548:      	b	0x6488 <_stogir.floating.validate+0x37c>
    654c:      	movz	x7, #0x0, lsl #48
    6550:      	b	0x6480 <_stogir.floating.validate+0x374>
    6554:      	movz	x1, #0x0, lsl #48
    6558:      	lsr	w3, w3, #0
    655c:      	lsr	w5, w5, #0
    6560:      	lsr	w4, w4, #0
    6564:      	lsr	w2, w2, #0
    6568:      	lsr	w1, w1, #0
    656c:      	mov	x19, x8
    6570:      	add	x8, sp, #0x20
    6574:      	fmov	s31, w1
    6578:      	mov	w1, w4
    657c:      	mov	w4, w5
    6580:      	fmov	w5, s31
    6584:      	bl	0x6584 <_stogir.floating.validate+0x478>
		0000000000006584:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    6588:      	add	x16, sp, #0x20
    658c:      	ldr	x1, [x16]
    6590:      	add	x16, sp, #0x20
    6594:      	ldr	x0, [x16, #0x8]
    6598:      	add	x16, sp, #0x20
    659c:      	ldr	x2, [x16, #0x10]
    65a0:      	b	0x6430 <_stogir.floating.validate+0x324>
    65a4:      	orr	x3, x2, xzr
    65a8:      	lsr	w3, w3, #0
    65ac:      	ubfx	x5, x6, #8, #8
    65b0:      	sxtw	x3, w3
    65b4:      	cmp	x5, x3
    65b8:      	b.ne	0x6608 <_stogir.floating.validate+0x4fc>
    65bc:      	add	x16, sp, #0x10
    65c0:      	ldr	w3, [x16, #0x4]
    65c4:      	add	x16, sp, #0x10
    65c8:      	ldr	w5, [x16, #0x8]
    65cc:      	uxtb	w16, w1
    65d0:      	cmp	w16, wzr
    65d4:      	b.eq	0x6554 <_stogir.floating.validate+0x448>
    65d8:      	add	x16, sp, #0x10
    65dc:      	ldr	w1, [x16, #0xc]
    65e0:      	sxtw	x1, w1
    65e4:      	b	0x6558 <_stogir.floating.validate+0x44c>
    65e8:      	movz	x7, #0x0, lsl #48
    65ec:      	b	0x6548 <_stogir.floating.validate+0x43c>
    65f0:      	brk	#0
    65f4:      	b	0x65f0 <_stogir.floating.validate+0x4e4>
    65f8:      	brk	#0
    65fc:      	b	0x65f8 <_stogir.floating.validate+0x4ec>
    6600:      	mov	x19, x8
    6604:      	b	0x62b0 <_stogir.floating.validate+0x1a4>
    6608:      	mov	x19, x8
    660c:      	b	0x641c <_stogir.floating.validate+0x310>

0000000000006610 <_stogir.integer-unary.valid-type?>:
    6610:      	sxtw	x0, w0
    6614:      	cmp	x0, #0x2d
    6618:      	cset	w2, eq
    661c:      	cmp	x0, #0x1f
    6620:      	cset	w3, eq
    6624:      	cmp	x0, #0x20
    6628:      	cset	w4, eq
    662c:      	cmp	x0, #0x36
    6630:      	cset	w5, eq
    6634:      	uxtb	w16, w3
    6638:      	cmp	w16, wzr
    663c:      	b.ne	0x6684 <_stogir.integer-unary.valid-type?+0x74>
    6640:      	uxtb	w16, w4
    6644:      	cmp	w16, wzr
    6648:      	b.ne	0x6684 <_stogir.integer-unary.valid-type?+0x74>
    664c:      	uxtb	w16, w2
    6650:      	cmp	w16, wzr
    6654:      	b.ne	0x6684 <_stogir.integer-unary.valid-type?+0x74>
    6658:      	uxtb	w16, w5
    665c:      	cmp	w16, wzr
    6660:      	b.ne	0x6684 <_stogir.integer-unary.valid-type?+0x74>
    6664:      	cmp	x0, #0x37
    6668:      	b.eq	0x6684 <_stogir.integer-unary.valid-type?+0x74>
    666c:      	cmp	x0, #0x38
    6670:      	b.eq	0x6684 <_stogir.integer-unary.valid-type?+0x74>
    6674:      	cmp	x0, #0x39
    6678:      	b.eq	0x6684 <_stogir.integer-unary.valid-type?+0x74>
    667c:      	movz	x0, #0x0, lsl #48
    6680:      	b	0x66bc <_stogir.integer-unary.valid-type?+0xac>
    6684:      	sxtw	x1, w1
    6688:      	cmp	x1, #0x1
    668c:      	b.lt	0x66b8 <_stogir.integer-unary.valid-type?+0xa8>
    6690:      	cmp	x1, #0xb
    6694:      	cset	w0, le
    6698:      	uxtb	w16, w0
    669c:      	cmp	w16, wzr
    66a0:      	b.eq	0x66b8 <_stogir.integer-unary.valid-type?+0xa8>
    66a4:      	uxtb	w16, w2
    66a8:      	cmp	w16, wzr
    66ac:      	b.eq	0x66c8 <_stogir.integer-unary.valid-type?+0xb8>
    66b0:      	mov	x0, #0x1                ; =1
    66b4:      	b	0x66c4 <_stogir.integer-unary.valid-type?+0xb4>
    66b8:      	movz	x0, #0x0, lsl #48
    66bc:      	ret
    66c0:      	mov	x0, #0x1                ; =1
    66c4:      	b	0x66bc <_stogir.integer-unary.valid-type?+0xac>
    66c8:      	cmp	x1, #0x1
    66cc:      	b.ne	0x66d8 <_stogir.integer-unary.valid-type?+0xc8>
    66d0:      	movz	x0, #0x0, lsl #48
    66d4:      	b	0x66c4 <_stogir.integer-unary.valid-type?+0xb4>
    66d8:      	cmp	x1, #0x6
    66dc:      	cset	w2, eq
    66e0:      	uxtb	w16, w3
    66e4:      	cmp	w16, wzr
    66e8:      	b.eq	0x66fc <_stogir.integer-unary.valid-type?+0xec>
    66ec:      	uxtb	w16, w2
    66f0:      	cmp	w16, wzr
    66f4:      	cset	x0, eq
    66f8:      	b	0x66c4 <_stogir.integer-unary.valid-type?+0xb4>
    66fc:      	uxtb	w16, w4
    6700:      	cmp	w16, wzr
    6704:      	b.eq	0x6720 <_stogir.integer-unary.valid-type?+0x110>
    6708:      	cmp	x1, #0x7
    670c:      	b.lt	0x6718 <_stogir.integer-unary.valid-type?+0x108>
    6710:      	ubfx	x0, x0, #0, #8
    6714:      	b	0x671c <_stogir.integer-unary.valid-type?+0x10c>
    6718:      	movz	x0, #0x0, lsl #48
    671c:      	b	0x66c4 <_stogir.integer-unary.valid-type?+0xb4>
    6720:      	uxtb	w16, w5
    6724:      	cmp	w16, wzr
    6728:      	b.eq	0x66c0 <_stogir.integer-unary.valid-type?+0xb0>
    672c:      	cmp	x1, #0x3
    6730:      	b.ne	0x674c <_stogir.integer-unary.valid-type?+0x13c>
    6734:      	mov	x0, #0x1                ; =1
    6738:      	b	0x6748 <_stogir.integer-unary.valid-type?+0x138>
    673c:      	cmp	x1, #0xb
    6740:      	cset	w0, eq
    6744:      	ubfx	x0, x0, #0, #8
    6748:      	b	0x66c4 <_stogir.integer-unary.valid-type?+0xb4>
    674c:      	cmp	x1, #0x4
    6750:      	b.ne	0x675c <_stogir.integer-unary.valid-type?+0x14c>
    6754:      	mov	x0, #0x1                ; =1
    6758:      	b	0x6748 <_stogir.integer-unary.valid-type?+0x138>
    675c:      	cmp	x1, #0x5
    6760:      	b.ne	0x676c <_stogir.integer-unary.valid-type?+0x15c>
    6764:      	mov	x0, #0x1                ; =1
    6768:      	b	0x6748 <_stogir.integer-unary.valid-type?+0x138>
    676c:      	uxtb	w16, w2
    6770:      	cmp	w16, wzr
    6774:      	b.eq	0x6780 <_stogir.integer-unary.valid-type?+0x170>
    6778:      	mov	x0, #0x1                ; =1
    677c:      	b	0x6748 <_stogir.integer-unary.valid-type?+0x138>
    6780:      	cmp	x1, #0x9
    6784:      	b.ne	0x6790 <_stogir.integer-unary.valid-type?+0x180>
    6788:      	mov	x0, #0x1                ; =1
    678c:      	b	0x6748 <_stogir.integer-unary.valid-type?+0x138>
    6790:      	cmp	x1, #0xa
    6794:      	b.ne	0x673c <_stogir.integer-unary.valid-type?+0x12c>
    6798:      	mov	x0, #0x1                ; =1
    679c:      	b	0x6748 <_stogir.integer-unary.valid-type?+0x138>

00000000000067a0 <_stogir.types.vector?>:
    67a0:      	sxtw	x0, w0
    67a4:      	cmp	x0, #0xf
    67a8:      	b.le	0x67e4 <_stogir.types.vector?+0x44>
    67ac:      	cmp	x0, #0x80
    67b0:      	b.ge	0x67f4 <_stogir.types.vector?+0x54>
    67b4:      	and	x1, x0, #0xf
    67b8:      	lsr	w1, w1, #0
    67bc:      	sxtw	x1, w1
    67c0:      	cmp	x1, #0x1
    67c4:      	b.lt	0x67ec <_stogir.types.vector?+0x4c>
    67c8:      	and	x0, x0, #0xf
    67cc:      	lsr	w0, w0, #0
    67d0:      	sxtw	x0, w0
    67d4:      	cmp	x0, #0xd
    67d8:      	cset	w0, le
    67dc:      	ubfx	x0, x0, #0, #8
    67e0:      	b	0x67f0 <_stogir.types.vector?+0x50>
    67e4:      	movz	x0, #0x0, lsl #48
    67e8:      	b	0x67f0 <_stogir.types.vector?+0x50>
    67ec:      	movz	x0, #0x0, lsl #48
    67f0:      	ret
    67f4:      	movz	x0, #0x0, lsl #48
    67f8:      	b	0x67f0 <_stogir.types.vector?+0x50>

00000000000067fc <_stogir.floating.operation?>:
    67fc:      	sxtw	x0, w0
    6800:      	cmp	x0, #0xe
    6804:      	b.lt	0x6818 <_stogir.floating.operation?+0x1c>
    6808:      	cmp	x0, #0x19
    680c:      	b.gt	0x6818 <_stogir.floating.operation?+0x1c>
    6810:      	mov	x0, #0x1                ; =1
    6814:      	b	0x6844 <_stogir.floating.operation?+0x48>
    6818:      	cmp	x0, #0x1f
    681c:      	b.eq	0x6840 <_stogir.floating.operation?+0x44>
    6820:      	cmp	x0, #0x20
    6824:      	b.eq	0x6840 <_stogir.floating.operation?+0x44>
    6828:      	cmp	x0, #0x1a
    682c:      	b.lt	0x6858 <_stogir.floating.operation?+0x5c>
    6830:      	cmp	x0, #0x1d
    6834:      	b.gt	0x6858 <_stogir.floating.operation?+0x5c>
    6838:      	mov	x0, #0x1                ; =1
    683c:      	b	0x6854 <_stogir.floating.operation?+0x58>
    6840:      	mov	x0, #0x1                ; =1
    6844:      	ret
    6848:      	cmp	x0, #0x3b
    684c:      	cset	w0, eq
    6850:      	ubfx	x0, x0, #0, #8
    6854:      	b	0x6844 <_stogir.floating.operation?+0x48>
    6858:      	cmp	x0, #0x3a
    685c:      	b.ne	0x6848 <_stogir.floating.operation?+0x4c>
    6860:      	mov	x0, #0x1                ; =1
    6864:      	b	0x6854 <_stogir.floating.operation?+0x58>

0000000000006868 <_stogir.vector-lanes.validate>:
    6868:      	sub	sp, sp, #0x50
    686c:      	str	x29, [sp]
    6870:      	str	x30, [sp, #0x8]
    6874:      	mov	x29, sp
    6878:      	str	x19, [sp, #0x40]
    687c:      	sxtw	x1, w1
    6880:      	lsl	x3, x1, #2
    6884:      	cmp	x1, #0x0
    6888:      	cset	w4, gt
    688c:      	movz	x16, #0x0, lsl #48
    6890:      	sub	x5, x16, x1
    6894:      	sub	x6, x5, #0x1
    6898:      	uxtb	w16, w4
    689c:      	cmp	w16, wzr
    68a0:      	b.eq	0x68e0 <_stogir.vector-lanes.validate+0x78>
    68a4:      	ldr	x5, [x0, #0x8]
    68a8:      	cmp	x1, x5
    68ac:      	b.ge	0x6930 <_stogir.vector-lanes.validate+0xc8>
    68b0:      	add	x5, x0, #0x78
    68b4:      	ldr	x5, [x5, #0x8]
    68b8:      	cmp	x1, x5
    68bc:      	b.ge	0x6a24 <_stogir.vector-lanes.validate+0x1bc>
    68c0:      	ldr	x5, [x0, #0x78]
    68c4:      	add	x5, x3, x5
    68c8:      	ldr	w5, [x5]
    68cc:      	sxtw	x5, w5
    68d0:      	cmp	x5, #0x0
    68d4:      	cset	w5, ge
    68d8:      	ubfx	x5, x5, #0, #8
    68dc:      	b	0x6a28 <_stogir.vector-lanes.validate+0x1c0>
    68e0:      	cmp	x1, #0x0
    68e4:      	b.ge	0x6938 <_stogir.vector-lanes.validate+0xd0>
    68e8:      	add	x7, x0, #0x28
    68ec:      	add	x9, x0, #0x50
    68f0:      	ldr	x7, [x7, #0x8]
    68f4:      	ldr	x9, [x9, #0x8]
    68f8:      	cmp	x7, x9
    68fc:      	b.ne	0x6928 <_stogir.vector-lanes.validate+0xc0>
    6900:      	cmp	x5, x7
    6904:      	b.gt	0x6a68 <_stogir.vector-lanes.validate+0x200>
    6908:      	ldr	x5, [x0, #0x50]
    690c:      	add	x5, x5, x6, lsl #2
    6910:      	ldr	w5, [x5]
    6914:      	sxtw	x5, w5
    6918:      	cmp	x5, #0x0
    691c:      	cset	w5, gt
    6920:      	ubfx	x5, x5, #0, #8
    6924:      	b	0x6a6c <_stogir.vector-lanes.validate+0x204>
    6928:      	movz	x5, #0x0, lsl #48
    692c:      	b	0x693c <_stogir.vector-lanes.validate+0xd4>
    6930:      	movz	x5, #0x0, lsl #48
    6934:      	b	0x693c <_stogir.vector-lanes.validate+0xd4>
    6938:      	movz	x5, #0x0, lsl #48
    693c:      	cmp	x5, #0x0
    6940:      	b.eq	0x697c <_stogir.vector-lanes.validate+0x114>
    6944:      	uxtb	w16, w4
    6948:      	cmp	w16, wzr
    694c:      	b.eq	0x6964 <_stogir.vector-lanes.validate+0xfc>
    6950:      	ldr	x4, [x0]
    6954:      	add	x4, x4, x1, lsl #4
    6958:      	ldr	x5, [x4]
    695c:      	ldr	x4, [x4, #0x8]
    6960:      	b	0x6974 <_stogir.vector-lanes.validate+0x10c>
    6964:      	ldr	x4, [x0, #0x28]
    6968:      	add	x4, x4, x6, lsl #4
    696c:      	ldr	x5, [x4]
    6970:      	ldr	x4, [x4, #0x8]
    6974:      	mov	x6, #0x1                ; =1
    6978:      	b	0x6988 <_stogir.vector-lanes.validate+0x120>
    697c:      	movz	x6, #0x0, lsl #48
    6980:      	movz	x5, #0x0, lsl #48
    6984:      	movz	x4, #0x0, lsl #48
    6988:      	lsr	w6, w6, #0
    698c:      	lsr	x16, x6, #0
    6990:      	cmp	x16, #0x1
    6994:      	b.eq	0x69b0 <_stogir.vector-lanes.validate+0x148>
    6998:      	b.lo	0x69a0 <_stogir.vector-lanes.validate+0x138>
    699c:      	b	0x69b4 <_stogir.vector-lanes.validate+0x14c>
    69a0:      	cmp	x16, #0x0
    69a4:      	b.eq	0x69ac <_stogir.vector-lanes.validate+0x144>
    69a8:      	b	0x69b4 <_stogir.vector-lanes.validate+0x14c>
    69ac:      	b	0x69b8 <_stogir.vector-lanes.validate+0x150>
    69b0:      	b	0x69d4 <_stogir.vector-lanes.validate+0x16c>
    69b4:      	b	0x6b4c <_stogir.vector-lanes.validate+0x2e4>
    69b8:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		00000000000069b8:  ARM64_RELOC_PAGE21	l_stogir.415
    69bc:      	ldr	x16, [x16]
		00000000000069bc:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    69c0:      	orr	x0, x16, xzr
    69c4:      	mov	x19, x8
    69c8:      	mov	x1, #0x1                ; =1
    69cc:      	mov	x2, #0x1f               ; =31
    69d0:      	b	0x6a04 <_stogir.vector-lanes.validate+0x19c>
    69d4:      	add	x16, sp, #0x10
    69d8:      	str	x5, [x16]
    69dc:      	add	x16, sp, #0x10
    69e0:      	str	x4, [x16, #0x8]
    69e4:      	cmp	x1, #0x0
    69e8:      	b.gt	0x6a2c <_stogir.vector-lanes.validate+0x1c4>
    69ec:      	mov	x19, x8
    69f0:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		00000000000069f0:  ARM64_RELOC_PAGE21	l_stogir.416
    69f4:      	ldr	x16, [x16]
		00000000000069f4:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    69f8:      	orr	x0, x16, xzr
    69fc:      	mov	x1, #0x1                ; =1
    6a00:      	mov	x2, #0x25               ; =37
    6a04:      	str	x1, [x19]
    6a08:      	str	x0, [x19, #0x8]
    6a0c:      	str	x2, [x19, #0x10]
    6a10:      	ldr	x19, [sp, #0x40]
    6a14:      	ldr	x29, [sp]
    6a18:      	ldr	x30, [sp, #0x8]
    6a1c:      	add	sp, sp, #0x50
    6a20:      	ret
    6a24:      	movz	x5, #0x0, lsl #48
    6a28:      	b	0x6934 <_stogir.vector-lanes.validate+0xcc>
    6a2c:      	uxtb	w5, w5
    6a30:      	orr	x1, x5, xzr
    6a34:      	cmp	x1, #0x3d
    6a38:      	b.lt	0x6b54 <_stogir.vector-lanes.validate+0x2ec>
    6a3c:      	cmp	x1, #0x3f
    6a40:      	b.gt	0x6b5c <_stogir.vector-lanes.validate+0x2f4>
    6a44:      	cmp	x1, #0x3e
    6a48:      	cset	w4, eq
    6a4c:      	ldr	x6, [x0, #0x78]
    6a50:      	add	x3, x3, x6
    6a54:      	ldr	w3, [x3]
    6a58:      	cmp	x1, #0x3d
    6a5c:      	b.ne	0x6adc <_stogir.vector-lanes.validate+0x274>
    6a60:      	mov	x6, #0x2                ; =2
    6a64:      	b	0x6af0 <_stogir.vector-lanes.validate+0x288>
    6a68:      	movz	x5, #0x0, lsl #48
    6a6c:      	b	0x692c <_stogir.vector-lanes.validate+0xc4>
    6a70:      	movz	x4, #0x0, lsl #48
    6a74:      	lsr	w2, w2, #0
    6a78:      	lsr	w6, w6, #0
    6a7c:      	lsr	w1, w1, #0
    6a80:      	lsr	w5, w5, #0
    6a84:      	lsr	w4, w4, #0
    6a88:      	ubfx	x3, x3, #8, #8
    6a8c:      	lsr	w3, w3, #0
    6a90:      	mov	x19, x8
    6a94:      	add	x8, sp, #0x20
    6a98:      	fmov	s31, w1
    6a9c:      	mov	w1, w5
    6aa0:      	fmov	w5, s31
    6aa4:      	fmov	s31, w2
    6aa8:      	mov	w2, w3
    6aac:      	fmov	w3, s31
    6ab0:      	fmov	s31, w4
    6ab4:      	mov	w4, w6
    6ab8:      	fmov	w6, s31
    6abc:      	bl	0x6abc <_stogir.vector-lanes.validate+0x254>
		0000000000006abc:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    6ac0:      	add	x16, sp, #0x20
    6ac4:      	ldr	x1, [x16]
    6ac8:      	add	x16, sp, #0x20
    6acc:      	ldr	x0, [x16, #0x8]
    6ad0:      	add	x16, sp, #0x20
    6ad4:      	ldr	x2, [x16, #0x10]
    6ad8:      	b	0x6a04 <_stogir.vector-lanes.validate+0x19c>
    6adc:      	uxtb	w16, w4
    6ae0:      	cmp	w16, wzr
    6ae4:      	mov	x16, #0x3               ; =3
    6ae8:      	mov	x17, #0x1               ; =1
    6aec:      	csel	x6, x16, x17, ne
    6af0:      	sxtw	x3, w3
    6af4:      	lsr	w6, w6, #0
    6af8:      	sxtw	x6, w6
    6afc:      	cmp	x3, x6
    6b00:      	b.ne	0x6b64 <_stogir.vector-lanes.validate+0x2fc>
    6b04:      	add	x16, sp, #0x10
    6b08:      	ldr	w3, [x16]
    6b0c:      	add	x16, sp, #0x10
    6b10:      	ldr	w6, [x16, #0x4]
    6b14:      	cmp	x1, #0x3f
    6b18:      	b.ne	0x6b24 <_stogir.vector-lanes.validate+0x2bc>
    6b1c:      	movz	x1, #0x0, lsl #48
    6b20:      	b	0x6b30 <_stogir.vector-lanes.validate+0x2c8>
    6b24:      	add	x16, sp, #0x10
    6b28:      	ldr	w1, [x16, #0x8]
    6b2c:      	sxtw	x1, w1
    6b30:      	uxtb	w16, w4
    6b34:      	cmp	w16, wzr
    6b38:      	b.eq	0x6a70 <_stogir.vector-lanes.validate+0x208>
    6b3c:      	add	x16, sp, #0x10
    6b40:      	ldr	w4, [x16, #0xc]
    6b44:      	sxtw	x4, w4
    6b48:      	b	0x6a74 <_stogir.vector-lanes.validate+0x20c>
    6b4c:      	brk	#0
    6b50:      	b	0x6b4c <_stogir.vector-lanes.validate+0x2e4>
    6b54:      	mov	x19, x8
    6b58:      	b	0x69f0 <_stogir.vector-lanes.validate+0x188>
    6b5c:      	mov	x19, x8
    6b60:      	b	0x69f0 <_stogir.vector-lanes.validate+0x188>
    6b64:      	mov	x19, x8
    6b68:      	b	0x69f0 <_stogir.vector-lanes.validate+0x188>

0000000000006b6c <_stogir.vector-comparison.node?>:
    6b6c:      	sxtw	x1, w1
    6b70:      	cmp	x1, #0x0
    6b74:      	cset	w2, gt
    6b78:      	movz	x16, #0x0, lsl #48
    6b7c:      	sub	x3, x16, x1
    6b80:      	sub	x4, x3, #0x1
    6b84:      	uxtb	w16, w2
    6b88:      	cmp	w16, wzr
    6b8c:      	b.eq	0x6bcc <_stogir.vector-comparison.node?+0x60>
    6b90:      	ldr	x3, [x0, #0x8]
    6b94:      	cmp	x1, x3
    6b98:      	b.ge	0x6c1c <_stogir.vector-comparison.node?+0xb0>
    6b9c:      	add	x3, x0, #0x78
    6ba0:      	ldr	x3, [x3, #0x8]
    6ba4:      	cmp	x1, x3
    6ba8:      	b.ge	0x6cf8 <_stogir.vector-comparison.node?+0x18c>
    6bac:      	ldr	x3, [x0, #0x78]
    6bb0:      	add	x3, x3, x1, lsl #2
    6bb4:      	ldr	w3, [x3]
    6bb8:      	sxtw	x3, w3
    6bbc:      	cmp	x3, #0x0
    6bc0:      	cset	w3, ge
    6bc4:      	ubfx	x3, x3, #0, #8
    6bc8:      	b	0x6cfc <_stogir.vector-comparison.node?+0x190>
    6bcc:      	cmp	x1, #0x0
    6bd0:      	b.ge	0x6c24 <_stogir.vector-comparison.node?+0xb8>
    6bd4:      	add	x5, x0, #0x28
    6bd8:      	add	x6, x0, #0x50
    6bdc:      	ldr	x5, [x5, #0x8]
    6be0:      	ldr	x6, [x6, #0x8]
    6be4:      	cmp	x5, x6
    6be8:      	b.ne	0x6c14 <_stogir.vector-comparison.node?+0xa8>
    6bec:      	cmp	x3, x5
    6bf0:      	b.gt	0x6d00 <_stogir.vector-comparison.node?+0x194>
    6bf4:      	ldr	x3, [x0, #0x50]
    6bf8:      	add	x3, x3, x4, lsl #2
    6bfc:      	ldr	w3, [x3]
    6c00:      	sxtw	x3, w3
    6c04:      	cmp	x3, #0x0
    6c08:      	cset	w3, gt
    6c0c:      	ubfx	x3, x3, #0, #8
    6c10:      	b	0x6d04 <_stogir.vector-comparison.node?+0x198>
    6c14:      	movz	x3, #0x0, lsl #48
    6c18:      	b	0x6c28 <_stogir.vector-comparison.node?+0xbc>
    6c1c:      	movz	x3, #0x0, lsl #48
    6c20:      	b	0x6c28 <_stogir.vector-comparison.node?+0xbc>
    6c24:      	movz	x3, #0x0, lsl #48
    6c28:      	cmp	x3, #0x0
    6c2c:      	b.eq	0x6c60 <_stogir.vector-comparison.node?+0xf4>
    6c30:      	uxtb	w16, w2
    6c34:      	cmp	w16, wzr
    6c38:      	b.eq	0x6c4c <_stogir.vector-comparison.node?+0xe0>
    6c3c:      	ldr	x0, [x0]
    6c40:      	add	x0, x0, x1, lsl #4
    6c44:      	ldr	x0, [x0]
    6c48:      	b	0x6c58 <_stogir.vector-comparison.node?+0xec>
    6c4c:      	ldr	x0, [x0, #0x28]
    6c50:      	add	x0, x0, x4, lsl #4
    6c54:      	ldr	x0, [x0]
    6c58:      	mov	x1, #0x1                ; =1
    6c5c:      	b	0x6c68 <_stogir.vector-comparison.node?+0xfc>
    6c60:      	movz	x1, #0x0, lsl #48
    6c64:      	movz	x0, #0x0, lsl #48
    6c68:      	lsr	w1, w1, #0
    6c6c:      	lsr	x16, x1, #0
    6c70:      	cmp	x16, #0x1
    6c74:      	b.eq	0x6c90 <_stogir.vector-comparison.node?+0x124>
    6c78:      	b.lo	0x6c80 <_stogir.vector-comparison.node?+0x114>
    6c7c:      	b	0x6c94 <_stogir.vector-comparison.node?+0x128>
    6c80:      	cmp	x16, #0x0
    6c84:      	b.eq	0x6c8c <_stogir.vector-comparison.node?+0x120>
    6c88:      	b	0x6c94 <_stogir.vector-comparison.node?+0x128>
    6c8c:      	b	0x6c98 <_stogir.vector-comparison.node?+0x12c>
    6c90:      	b	0x6ca8 <_stogir.vector-comparison.node?+0x13c>
    6c94:      	b	0x6d20 <_stogir.vector-comparison.node?+0x1b4>
    6c98:      	movz	x0, #0x0, lsl #48
    6c9c:      	b	0x6ca4 <_stogir.vector-comparison.node?+0x138>
    6ca0:      	movz	x0, #0x0, lsl #48
    6ca4:      	ret
    6ca8:      	uxtb	w1, w0
    6cac:      	cmp	x1, #0xe
    6cb0:      	b.lt	0x6ca0 <_stogir.vector-comparison.node?+0x134>
    6cb4:      	cmp	x1, #0x19
    6cb8:      	b.gt	0x6ca0 <_stogir.vector-comparison.node?+0x134>
    6cbc:      	lsr	w0, w0, #0
    6cc0:      	ubfx	x0, x0, #8, #8
    6cc4:      	cmp	x0, #0xf
    6cc8:      	b.le	0x6d08 <_stogir.vector-comparison.node?+0x19c>
    6ccc:      	cmp	x0, #0x80
    6cd0:      	b.ge	0x6d10 <_stogir.vector-comparison.node?+0x1a4>
    6cd4:      	and	x0, x0, #0xf
    6cd8:      	lsr	w0, w0, #0
    6cdc:      	sxtw	x0, w0
    6ce0:      	cmp	x0, #0x1
    6ce4:      	b.lt	0x6d18 <_stogir.vector-comparison.node?+0x1ac>
    6ce8:      	cmp	x0, #0xd
    6cec:      	cset	w0, le
    6cf0:      	ubfx	x0, x0, #0, #8
    6cf4:      	b	0x6d1c <_stogir.vector-comparison.node?+0x1b0>
    6cf8:      	movz	x3, #0x0, lsl #48
    6cfc:      	b	0x6c20 <_stogir.vector-comparison.node?+0xb4>
    6d00:      	movz	x3, #0x0, lsl #48
    6d04:      	b	0x6c18 <_stogir.vector-comparison.node?+0xac>
    6d08:      	movz	x0, #0x0, lsl #48
    6d0c:      	b	0x6ca4 <_stogir.vector-comparison.node?+0x138>
    6d10:      	movz	x0, #0x0, lsl #48
    6d14:      	b	0x6d0c <_stogir.vector-comparison.node?+0x1a0>
    6d18:      	movz	x0, #0x0, lsl #48
    6d1c:      	b	0x6d14 <_stogir.vector-comparison.node?+0x1a8>
    6d20:      	brk	#0
    6d24:      	b	0x6d20 <_stogir.vector-comparison.node?+0x1b4>

0000000000006d28 <_stogir.vector-comparison.validate>:
    6d28:      	sub	sp, sp, #0x50
    6d2c:      	str	x29, [sp]
    6d30:      	str	x30, [sp, #0x8]
    6d34:      	mov	x29, sp
    6d38:      	str	x19, [sp, #0x40]
    6d3c:      	sxtw	x1, w1
    6d40:      	lsl	x3, x1, #2
    6d44:      	cmp	x1, #0x0
    6d48:      	cset	w4, gt
    6d4c:      	movz	x16, #0x0, lsl #48
    6d50:      	sub	x5, x16, x1
    6d54:      	sub	x6, x5, #0x1
    6d58:      	uxtb	w16, w4
    6d5c:      	cmp	w16, wzr
    6d60:      	b.eq	0x6da0 <_stogir.vector-comparison.validate+0x78>
    6d64:      	ldr	x5, [x0, #0x8]
    6d68:      	cmp	x1, x5
    6d6c:      	b.ge	0x6df0 <_stogir.vector-comparison.validate+0xc8>
    6d70:      	add	x5, x0, #0x78
    6d74:      	ldr	x5, [x5, #0x8]
    6d78:      	cmp	x1, x5
    6d7c:      	b.ge	0x6ee8 <_stogir.vector-comparison.validate+0x1c0>
    6d80:      	ldr	x5, [x0, #0x78]
    6d84:      	add	x5, x3, x5
    6d88:      	ldr	w5, [x5]
    6d8c:      	sxtw	x5, w5
    6d90:      	cmp	x5, #0x0
    6d94:      	cset	w5, ge
    6d98:      	ubfx	x5, x5, #0, #8
    6d9c:      	b	0x6eec <_stogir.vector-comparison.validate+0x1c4>
    6da0:      	cmp	x1, #0x0
    6da4:      	b.ge	0x6df8 <_stogir.vector-comparison.validate+0xd0>
    6da8:      	add	x7, x0, #0x28
    6dac:      	add	x9, x0, #0x50
    6db0:      	ldr	x7, [x7, #0x8]
    6db4:      	ldr	x9, [x9, #0x8]
    6db8:      	cmp	x7, x9
    6dbc:      	b.ne	0x6de8 <_stogir.vector-comparison.validate+0xc0>
    6dc0:      	cmp	x5, x7
    6dc4:      	b.gt	0x6f38 <_stogir.vector-comparison.validate+0x210>
    6dc8:      	ldr	x5, [x0, #0x50]
    6dcc:      	add	x5, x5, x6, lsl #2
    6dd0:      	ldr	w5, [x5]
    6dd4:      	sxtw	x5, w5
    6dd8:      	cmp	x5, #0x0
    6ddc:      	cset	w5, gt
    6de0:      	ubfx	x5, x5, #0, #8
    6de4:      	b	0x6f3c <_stogir.vector-comparison.validate+0x214>
    6de8:      	movz	x5, #0x0, lsl #48
    6dec:      	b	0x6dfc <_stogir.vector-comparison.validate+0xd4>
    6df0:      	movz	x5, #0x0, lsl #48
    6df4:      	b	0x6dfc <_stogir.vector-comparison.validate+0xd4>
    6df8:      	movz	x5, #0x0, lsl #48
    6dfc:      	lsl	x7, x1, #4
    6e00:      	cmp	x5, #0x0
    6e04:      	b.eq	0x6e40 <_stogir.vector-comparison.validate+0x118>
    6e08:      	uxtb	w16, w4
    6e0c:      	cmp	w16, wzr
    6e10:      	b.eq	0x6e28 <_stogir.vector-comparison.validate+0x100>
    6e14:      	ldr	x4, [x0]
    6e18:      	add	x4, x7, x4
    6e1c:      	ldr	x5, [x4]
    6e20:      	ldr	x4, [x4, #0x8]
    6e24:      	b	0x6e38 <_stogir.vector-comparison.validate+0x110>
    6e28:      	ldr	x4, [x0, #0x28]
    6e2c:      	add	x4, x4, x6, lsl #4
    6e30:      	ldr	x5, [x4]
    6e34:      	ldr	x4, [x4, #0x8]
    6e38:      	mov	x6, #0x1                ; =1
    6e3c:      	b	0x6e4c <_stogir.vector-comparison.validate+0x124>
    6e40:      	movz	x6, #0x0, lsl #48
    6e44:      	movz	x5, #0x0, lsl #48
    6e48:      	movz	x4, #0x0, lsl #48
    6e4c:      	lsr	w6, w6, #0
    6e50:      	lsr	x16, x6, #0
    6e54:      	cmp	x16, #0x1
    6e58:      	b.eq	0x6e74 <_stogir.vector-comparison.validate+0x14c>
    6e5c:      	b.lo	0x6e64 <_stogir.vector-comparison.validate+0x13c>
    6e60:      	b	0x6e78 <_stogir.vector-comparison.validate+0x150>
    6e64:      	cmp	x16, #0x0
    6e68:      	b.eq	0x6e70 <_stogir.vector-comparison.validate+0x148>
    6e6c:      	b	0x6e78 <_stogir.vector-comparison.validate+0x150>
    6e70:      	b	0x6e7c <_stogir.vector-comparison.validate+0x154>
    6e74:      	b	0x6eb4 <_stogir.vector-comparison.validate+0x18c>
    6e78:      	b	0x704c <_stogir.vector-comparison.validate+0x324>
    6e7c:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		0000000000006e7c:  ARM64_RELOC_PAGE21	l_stogir.417
    6e80:      	ldr	x16, [x16]
		0000000000006e80:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    6e84:      	orr	x0, x16, xzr
    6e88:      	mov	x19, x8
    6e8c:      	mov	x1, #0x1                ; =1
    6e90:      	mov	x2, #0x25               ; =37
    6e94:      	str	x1, [x19]
    6e98:      	str	x0, [x19, #0x8]
    6e9c:      	str	x2, [x19, #0x10]
    6ea0:      	ldr	x19, [sp, #0x40]
    6ea4:      	ldr	x29, [sp]
    6ea8:      	ldr	x30, [sp, #0x8]
    6eac:      	add	sp, sp, #0x50
    6eb0:      	ret
    6eb4:      	add	x16, sp, #0x10
    6eb8:      	str	x5, [x16]
    6ebc:      	add	x16, sp, #0x10
    6ec0:      	str	x4, [x16, #0x8]
    6ec4:      	cmp	x1, #0x0
    6ec8:      	b.gt	0x6ef0 <_stogir.vector-comparison.validate+0x1c8>
    6ecc:      	mov	x19, x8
    6ed0:      	adrp	x16, 0x6000 <_stogir.conditional.validate+0x14c>
		0000000000006ed0:  ARM64_RELOC_PAGE21	l_stogir.418
    6ed4:      	ldr	x16, [x16]
		0000000000006ed4:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    6ed8:      	orr	x0, x16, xzr
    6edc:      	mov	x1, #0x1                ; =1
    6ee0:      	mov	x2, #0x2b               ; =43
    6ee4:      	b	0x6e94 <_stogir.vector-comparison.validate+0x16c>
    6ee8:      	movz	x5, #0x0, lsl #48
    6eec:      	b	0x6df4 <_stogir.vector-comparison.validate+0xcc>
    6ef0:      	ldr	x4, [x0, #0x8]
    6ef4:      	cmp	x1, x4
    6ef8:      	b.ge	0x6f40 <_stogir.vector-comparison.validate+0x218>
    6efc:      	add	x4, x0, #0x78
    6f00:      	ldr	x4, [x4, #0x8]
    6f04:      	cmp	x1, x4
    6f08:      	b.ge	0x6f40 <_stogir.vector-comparison.validate+0x218>
    6f0c:      	ldr	x1, [x0, #0x78]
    6f10:      	add	x1, x3, x1
    6f14:      	ldr	w1, [x1]
    6f18:      	sxtw	x1, w1
    6f1c:      	cmp	x1, #0x0
    6f20:      	b.lt	0x6f40 <_stogir.vector-comparison.validate+0x218>
    6f24:      	ldr	x1, [x0]
    6f28:      	add	x1, x7, x1
    6f2c:      	ldr	x1, [x1]
    6f30:      	mov	x4, #0x1                ; =1
    6f34:      	b	0x6f48 <_stogir.vector-comparison.validate+0x220>
    6f38:      	movz	x5, #0x0, lsl #48
    6f3c:      	b	0x6dec <_stogir.vector-comparison.validate+0xc4>
    6f40:      	movz	x4, #0x0, lsl #48
    6f44:      	movz	x1, #0x0, lsl #48
    6f48:      	lsr	w4, w4, #0
    6f4c:      	lsr	x16, x4, #0
    6f50:      	cmp	x16, #0x1
    6f54:      	b.eq	0x6f70 <_stogir.vector-comparison.validate+0x248>
    6f58:      	b.lo	0x6f60 <_stogir.vector-comparison.validate+0x238>
    6f5c:      	b	0x6f74 <_stogir.vector-comparison.validate+0x24c>
    6f60:      	cmp	x16, #0x0
    6f64:      	b.eq	0x6f6c <_stogir.vector-comparison.validate+0x244>
    6f68:      	b	0x6f74 <_stogir.vector-comparison.validate+0x24c>
    6f6c:      	b	0x6f78 <_stogir.vector-comparison.validate+0x250>
    6f70:      	b	0x6f80 <_stogir.vector-comparison.validate+0x258>
    6f74:      	b	0x7054 <_stogir.vector-comparison.validate+0x32c>
    6f78:      	mov	x19, x8
    6f7c:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x1a8>
    6f80:      	uxtb	w4, w1
    6f84:      	cmp	x4, #0xe
    6f88:      	b.lt	0x705c <_stogir.vector-comparison.validate+0x334>
    6f8c:      	cmp	x4, #0x19
    6f90:      	b.gt	0x7064 <_stogir.vector-comparison.validate+0x33c>
    6f94:      	lsr	w1, w1, #0
    6f98:      	ubfx	x1, x1, #8, #8
    6f9c:      	cmp	x1, #0xf
    6fa0:      	b.le	0x706c <_stogir.vector-comparison.validate+0x344>
    6fa4:      	cmp	x1, #0x80
    6fa8:      	b.ge	0x7074 <_stogir.vector-comparison.validate+0x34c>
    6fac:      	and	x1, x1, #0xf
    6fb0:      	lsr	w1, w1, #0
    6fb4:      	sxtw	x1, w1
    6fb8:      	cmp	x1, #0x1
    6fbc:      	b.lt	0x707c <_stogir.vector-comparison.validate+0x354>
    6fc0:      	cmp	x1, #0xd
    6fc4:      	b.gt	0x7084 <_stogir.vector-comparison.validate+0x35c>
    6fc8:      	ldr	x1, [x0, #0x78]
    6fcc:      	add	x1, x3, x1
    6fd0:      	ldr	w1, [x1]
    6fd4:      	sxtw	x1, w1
    6fd8:      	cmp	x1, #0x2
    6fdc:      	b.ne	0x708c <_stogir.vector-comparison.validate+0x364>
    6fe0:      	lsr	w2, w2, #0
    6fe4:      	add	x16, sp, #0x10
    6fe8:      	ldr	w1, [x16]
    6fec:      	uxtb	w3, w1
    6ff0:      	add	x16, sp, #0x10
    6ff4:      	ldr	w4, [x16, #0x4]
    6ff8:      	lsr	w3, w3, #0
    6ffc:      	ubfx	x1, x1, #8, #8
    7000:      	add	x16, sp, #0x10
    7004:      	ldr	w5, [x16, #0x8]
    7008:      	lsr	w4, w4, #0
    700c:      	lsr	w5, w5, #0
    7010:      	lsr	w1, w1, #0
    7014:      	mov	x19, x8
    7018:      	add	x8, sp, #0x20
    701c:      	fmov	s31, w1
    7020:      	mov	w1, w3
    7024:      	mov	w3, w2
    7028:      	fmov	w2, s31
    702c:      	bl	0x702c <_stogir.vector-comparison.validate+0x304>
		000000000000702c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    7030:      	add	x16, sp, #0x20
    7034:      	ldr	x1, [x16]
    7038:      	add	x16, sp, #0x20
    703c:      	ldr	x0, [x16, #0x8]
    7040:      	add	x16, sp, #0x20
    7044:      	ldr	x2, [x16, #0x10]
    7048:      	b	0x6ee4 <_stogir.vector-comparison.validate+0x1bc>
    704c:      	brk	#0
    7050:      	b	0x704c <_stogir.vector-comparison.validate+0x324>
    7054:      	brk	#0
    7058:      	b	0x7054 <_stogir.vector-comparison.validate+0x32c>
    705c:      	mov	x19, x8
    7060:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x1a8>
    7064:      	mov	x19, x8
    7068:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x1a8>
    706c:      	mov	x19, x8
    7070:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x1a8>
    7074:      	mov	x19, x8
    7078:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x1a8>
    707c:      	mov	x19, x8
    7080:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x1a8>
    7084:      	mov	x19, x8
    7088:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x1a8>
    708c:      	mov	x19, x8
    7090:      	b	0x6ed0 <_stogir.vector-comparison.validate+0x1a8>

0000000000007094 <_stogir.vector-arithmetic.node?>:
    7094:      	sxtw	x1, w1
    7098:      	cmp	x1, #0x0
    709c:      	cset	w2, gt
    70a0:      	movz	x16, #0x0, lsl #48
    70a4:      	sub	x3, x16, x1
    70a8:      	sub	x4, x3, #0x1
    70ac:      	uxtb	w16, w2
    70b0:      	cmp	w16, wzr
    70b4:      	b.eq	0x70f4 <_stogir.vector-arithmetic.node?+0x60>
    70b8:      	ldr	x3, [x0, #0x8]
    70bc:      	cmp	x1, x3
    70c0:      	b.ge	0x7144 <_stogir.vector-arithmetic.node?+0xb0>
    70c4:      	add	x3, x0, #0x78
    70c8:      	ldr	x3, [x3, #0x8]
    70cc:      	cmp	x1, x3
    70d0:      	b.ge	0x7268 <_stogir.vector-arithmetic.node?+0x1d4>
    70d4:      	ldr	x3, [x0, #0x78]
    70d8:      	add	x3, x3, x1, lsl #2
    70dc:      	ldr	w3, [x3]
    70e0:      	sxtw	x3, w3
    70e4:      	cmp	x3, #0x0
    70e8:      	cset	w3, ge
    70ec:      	ubfx	x3, x3, #0, #8
    70f0:      	b	0x726c <_stogir.vector-arithmetic.node?+0x1d8>
    70f4:      	cmp	x1, #0x0
    70f8:      	b.ge	0x714c <_stogir.vector-arithmetic.node?+0xb8>
    70fc:      	add	x5, x0, #0x28
    7100:      	add	x6, x0, #0x50
    7104:      	ldr	x5, [x5, #0x8]
    7108:      	ldr	x6, [x6, #0x8]
    710c:      	cmp	x5, x6
    7110:      	b.ne	0x713c <_stogir.vector-arithmetic.node?+0xa8>
    7114:      	cmp	x3, x5
    7118:      	b.gt	0x7278 <_stogir.vector-arithmetic.node?+0x1e4>
    711c:      	ldr	x3, [x0, #0x50]
    7120:      	add	x3, x3, x4, lsl #2
    7124:      	ldr	w3, [x3]
    7128:      	sxtw	x3, w3
    712c:      	cmp	x3, #0x0
    7130:      	cset	w3, gt
    7134:      	ubfx	x3, x3, #0, #8
    7138:      	b	0x727c <_stogir.vector-arithmetic.node?+0x1e8>
    713c:      	movz	x3, #0x0, lsl #48
    7140:      	b	0x7150 <_stogir.vector-arithmetic.node?+0xbc>
    7144:      	movz	x3, #0x0, lsl #48
    7148:      	b	0x7150 <_stogir.vector-arithmetic.node?+0xbc>
    714c:      	movz	x3, #0x0, lsl #48
    7150:      	cmp	x3, #0x0
    7154:      	b.eq	0x7188 <_stogir.vector-arithmetic.node?+0xf4>
    7158:      	uxtb	w16, w2
    715c:      	cmp	w16, wzr
    7160:      	b.eq	0x7174 <_stogir.vector-arithmetic.node?+0xe0>
    7164:      	ldr	x0, [x0]
    7168:      	add	x0, x0, x1, lsl #4
    716c:      	ldr	x0, [x0]
    7170:      	b	0x7180 <_stogir.vector-arithmetic.node?+0xec>
    7174:      	ldr	x0, [x0, #0x28]
    7178:      	add	x0, x0, x4, lsl #4
    717c:      	ldr	x0, [x0]
    7180:      	mov	x1, #0x1                ; =1
    7184:      	b	0x7190 <_stogir.vector-arithmetic.node?+0xfc>
    7188:      	movz	x1, #0x0, lsl #48
    718c:      	movz	x0, #0x0, lsl #48
    7190:      	lsr	w1, w1, #0
    7194:      	lsr	x16, x1, #0
    7198:      	cmp	x16, #0x1
    719c:      	b.eq	0x71b8 <_stogir.vector-arithmetic.node?+0x124>
    71a0:      	b.lo	0x71a8 <_stogir.vector-arithmetic.node?+0x114>
    71a4:      	b	0x71bc <_stogir.vector-arithmetic.node?+0x128>
    71a8:      	cmp	x16, #0x0
    71ac:      	b.eq	0x71b4 <_stogir.vector-arithmetic.node?+0x120>
    71b0:      	b	0x71bc <_stogir.vector-arithmetic.node?+0x128>
    71b4:      	b	0x71c0 <_stogir.vector-arithmetic.node?+0x12c>
    71b8:      	b	0x71d0 <_stogir.vector-arithmetic.node?+0x13c>
    71bc:      	b	0x7288 <_stogir.vector-arithmetic.node?+0x1f4>
    71c0:      	movz	x0, #0x0, lsl #48
    71c4:      	b	0x71cc <_stogir.vector-arithmetic.node?+0x138>
    71c8:      	movz	x0, #0x0, lsl #48
    71cc:      	ret
    71d0:      	uxtb	w1, w0
    71d4:      	cmp	x1, #0x1f
    71d8:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    71dc:      	cmp	x1, #0x20
    71e0:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    71e4:      	cmp	x1, #0x2d
    71e8:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    71ec:      	cmp	x1, #0x36
    71f0:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    71f4:      	cmp	x1, #0x37
    71f8:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    71fc:      	cmp	x1, #0x38
    7200:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    7204:      	cmp	x1, #0x39
    7208:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    720c:      	cmp	x1, #0x3a
    7210:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    7214:      	cmp	x1, #0x3b
    7218:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    721c:      	cmp	x1, #0x31
    7220:      	b.lt	0x7290 <_stogir.vector-arithmetic.node?+0x1fc>
    7224:      	cmp	x1, #0x35
    7228:      	b.gt	0x7290 <_stogir.vector-arithmetic.node?+0x1fc>
    722c:      	lsr	w0, w0, #0
    7230:      	ubfx	x0, x0, #8, #8
    7234:      	cmp	x0, #0xf
    7238:      	b.le	0x71c8 <_stogir.vector-arithmetic.node?+0x134>
    723c:      	cmp	x0, #0x80
    7240:      	b.ge	0x7270 <_stogir.vector-arithmetic.node?+0x1dc>
    7244:      	and	x0, x0, #0xf
    7248:      	lsr	w0, w0, #0
    724c:      	sxtw	x0, w0
    7250:      	cmp	x0, #0x1
    7254:      	b.lt	0x7280 <_stogir.vector-arithmetic.node?+0x1ec>
    7258:      	cmp	x0, #0xd
    725c:      	cset	w0, le
    7260:      	ubfx	x0, x0, #0, #8
    7264:      	b	0x7284 <_stogir.vector-arithmetic.node?+0x1f0>
    7268:      	movz	x3, #0x0, lsl #48
    726c:      	b	0x7148 <_stogir.vector-arithmetic.node?+0xb4>
    7270:      	movz	x0, #0x0, lsl #48
    7274:      	b	0x71cc <_stogir.vector-arithmetic.node?+0x138>
    7278:      	movz	x3, #0x0, lsl #48
    727c:      	b	0x7140 <_stogir.vector-arithmetic.node?+0xac>
    7280:      	movz	x0, #0x0, lsl #48
    7284:      	b	0x7274 <_stogir.vector-arithmetic.node?+0x1e0>
    7288:      	brk	#0
    728c:      	b	0x7288 <_stogir.vector-arithmetic.node?+0x1f4>
    7290:      	cmp	x1, #0x1a
    7294:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    7298:      	cmp	x1, #0x1b
    729c:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    72a0:      	cmp	x1, #0x1c
    72a4:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    72a8:      	cmp	x1, #0x1d
    72ac:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    72b0:      	cmp	x1, #0x1e
    72b4:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    72b8:      	cmp	x1, #0x2e
    72bc:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    72c0:      	cmp	x1, #0x2f
    72c4:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    72c8:      	cmp	x1, #0x30
    72cc:      	b.eq	0x722c <_stogir.vector-arithmetic.node?+0x198>
    72d0:      	movz	x0, #0x0, lsl #48
    72d4:      	b	0x71cc <_stogir.vector-arithmetic.node?+0x138>

00000000000072d8 <_stogir.vector-arithmetic.validate>:
    72d8:      	sub	sp, sp, #0x60
    72dc:      	str	x29, [sp]
    72e0:      	str	x30, [sp, #0x8]
    72e4:      	mov	x29, sp
    72e8:      	str	x19, [sp, #0x40]
    72ec:      	str	x20, [sp, #0x48]
    72f0:      	str	x21, [sp, #0x50]
    72f4:      	str	x22, [sp, #0x58]
    72f8:      	sxtw	x2, w1
    72fc:      	lsl	x19, x2, #2
    7300:      	cmp	x2, #0x0
    7304:      	cset	w3, gt
    7308:      	movz	x16, #0x0, lsl #48
    730c:      	sub	x4, x16, x2
    7310:      	sub	x5, x4, #0x1
    7314:      	uxtb	w16, w3
    7318:      	cmp	w16, wzr
    731c:      	b.eq	0x735c <_stogir.vector-arithmetic.validate+0x84>
    7320:      	ldr	x4, [x0, #0x8]
    7324:      	cmp	x2, x4
    7328:      	b.ge	0x73ac <_stogir.vector-arithmetic.validate+0xd4>
    732c:      	add	x4, x0, #0x78
    7330:      	ldr	x4, [x4, #0x8]
    7334:      	cmp	x2, x4
    7338:      	b.ge	0x74ac <_stogir.vector-arithmetic.validate+0x1d4>
    733c:      	ldr	x4, [x0, #0x78]
    7340:      	add	x4, x19, x4
    7344:      	ldr	w4, [x4]
    7348:      	sxtw	x4, w4
    734c:      	cmp	x4, #0x0
    7350:      	cset	w4, ge
    7354:      	ubfx	x4, x4, #0, #8
    7358:      	b	0x74b0 <_stogir.vector-arithmetic.validate+0x1d8>
    735c:      	cmp	x2, #0x0
    7360:      	b.ge	0x73b4 <_stogir.vector-arithmetic.validate+0xdc>
    7364:      	add	x6, x0, #0x28
    7368:      	add	x7, x0, #0x50
    736c:      	ldr	x6, [x6, #0x8]
    7370:      	ldr	x7, [x7, #0x8]
    7374:      	cmp	x6, x7
    7378:      	b.ne	0x73a4 <_stogir.vector-arithmetic.validate+0xcc>
    737c:      	cmp	x4, x6
    7380:      	b.gt	0x7548 <_stogir.vector-arithmetic.validate+0x270>
    7384:      	ldr	x4, [x0, #0x50]
    7388:      	add	x4, x4, x5, lsl #2
    738c:      	ldr	w4, [x4]
    7390:      	sxtw	x4, w4
    7394:      	cmp	x4, #0x0
    7398:      	cset	w4, gt
    739c:      	ubfx	x4, x4, #0, #8
    73a0:      	b	0x754c <_stogir.vector-arithmetic.validate+0x274>
    73a4:      	movz	x4, #0x0, lsl #48
    73a8:      	b	0x73b8 <_stogir.vector-arithmetic.validate+0xe0>
    73ac:      	movz	x4, #0x0, lsl #48
    73b0:      	b	0x73b8 <_stogir.vector-arithmetic.validate+0xe0>
    73b4:      	movz	x4, #0x0, lsl #48
    73b8:      	cmp	x4, #0x0
    73bc:      	b.eq	0x73f8 <_stogir.vector-arithmetic.validate+0x120>
    73c0:      	uxtb	w16, w3
    73c4:      	cmp	w16, wzr
    73c8:      	b.eq	0x73e0 <_stogir.vector-arithmetic.validate+0x108>
    73cc:      	ldr	x3, [x0]
    73d0:      	add	x3, x3, x2, lsl #4
    73d4:      	ldr	x20, [x3]
    73d8:      	ldr	x3, [x3, #0x8]
    73dc:      	b	0x73f0 <_stogir.vector-arithmetic.validate+0x118>
    73e0:      	ldr	x3, [x0, #0x28]
    73e4:      	add	x3, x3, x5, lsl #4
    73e8:      	ldr	x20, [x3]
    73ec:      	ldr	x3, [x3, #0x8]
    73f0:      	mov	x4, #0x1                ; =1
    73f4:      	b	0x7404 <_stogir.vector-arithmetic.validate+0x12c>
    73f8:      	movz	x4, #0x0, lsl #48
    73fc:      	movz	x20, #0x0, lsl #48
    7400:      	movz	x3, #0x0, lsl #48
    7404:      	lsr	w4, w4, #0
    7408:      	lsr	x16, x4, #0
    740c:      	cmp	x16, #0x1
    7410:      	b.eq	0x742c <_stogir.vector-arithmetic.validate+0x154>
    7414:      	b.lo	0x741c <_stogir.vector-arithmetic.validate+0x144>
    7418:      	b	0x7430 <_stogir.vector-arithmetic.validate+0x158>
    741c:      	cmp	x16, #0x0
    7420:      	b.eq	0x7428 <_stogir.vector-arithmetic.validate+0x150>
    7424:      	b	0x7430 <_stogir.vector-arithmetic.validate+0x158>
    7428:      	b	0x7434 <_stogir.vector-arithmetic.validate+0x15c>
    742c:      	b	0x7450 <_stogir.vector-arithmetic.validate+0x178>
    7430:      	b	0x75fc <_stogir.vector-arithmetic.validate+0x324>
    7434:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		0000000000007434:  ARM64_RELOC_PAGE21	l_stogir.419
    7438:      	ldr	x16, [x16]
		0000000000007438:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    743c:      	orr	x0, x16, xzr
    7440:      	mov	x21, x8
    7444:      	mov	x1, #0x1                ; =1
    7448:      	mov	x2, #0x25               ; =37
    744c:      	b	0x7480 <_stogir.vector-arithmetic.validate+0x1a8>
    7450:      	add	x16, sp, #0x10
    7454:      	str	x20, [x16]
    7458:      	add	x16, sp, #0x10
    745c:      	str	x3, [x16, #0x8]
    7460:      	cmp	x2, #0x0
    7464:      	b.gt	0x74b4 <_stogir.vector-arithmetic.validate+0x1dc>
    7468:      	mov	x21, x8
    746c:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		000000000000746c:  ARM64_RELOC_PAGE21	l_stogir.420
    7470:      	ldr	x16, [x16]
		0000000000007470:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    7474:      	orr	x0, x16, xzr
    7478:      	mov	x1, #0x1                ; =1
    747c:      	mov	x2, #0x2b               ; =43
    7480:      	str	x1, [x21]
    7484:      	str	x0, [x21, #0x8]
    7488:      	str	x2, [x21, #0x10]
    748c:      	ldr	x19, [sp, #0x40]
    7490:      	ldr	x20, [sp, #0x48]
    7494:      	ldr	x21, [sp, #0x50]
    7498:      	ldr	x22, [sp, #0x58]
    749c:      	ldr	x29, [sp]
    74a0:      	ldr	x30, [sp, #0x8]
    74a4:      	add	sp, sp, #0x60
    74a8:      	ret
    74ac:      	movz	x4, #0x0, lsl #48
    74b0:      	b	0x73b0 <_stogir.vector-arithmetic.validate+0xd8>
    74b4:      	lsr	w1, w1, #0
    74b8:      	mov	x21, x8
    74bc:      	mov	x22, x0
    74c0:      	bl	0x74c0 <_stogir.vector-arithmetic.validate+0x1e8>
		00000000000074c0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    74c4:      	cmp	x0, #0x0
    74c8:      	b.eq	0x746c <_stogir.vector-arithmetic.validate+0x194>
    74cc:      	uxtb	w20, w20
    74d0:      	orr	x0, x20, xzr
    74d4:      	ldr	x1, [x22, #0x78]
    74d8:      	cmp	x0, #0x1d
    74dc:      	cset	w2, eq
    74e0:      	cmp	x0, #0x1e
    74e4:      	cset	w3, eq
    74e8:      	add	x1, x19, x1
    74ec:      	ldr	w1, [x1]
    74f0:      	cmp	x0, #0x1f
    74f4:      	b.eq	0x75ac <_stogir.vector-arithmetic.validate+0x2d4>
    74f8:      	cmp	x0, #0x20
    74fc:      	b.eq	0x75ac <_stogir.vector-arithmetic.validate+0x2d4>
    7500:      	cmp	x0, #0x2d
    7504:      	b.eq	0x75ac <_stogir.vector-arithmetic.validate+0x2d4>
    7508:      	cmp	x0, #0x36
    750c:      	b.eq	0x75ac <_stogir.vector-arithmetic.validate+0x2d4>
    7510:      	cmp	x0, #0x37
    7514:      	b.eq	0x75ac <_stogir.vector-arithmetic.validate+0x2d4>
    7518:      	cmp	x0, #0x38
    751c:      	b.eq	0x75ac <_stogir.vector-arithmetic.validate+0x2d4>
    7520:      	cmp	x0, #0x39
    7524:      	b.eq	0x75ac <_stogir.vector-arithmetic.validate+0x2d4>
    7528:      	uxtb	w16, w2
    752c:      	cmp	w16, wzr
    7530:      	b.ne	0x7604 <_stogir.vector-arithmetic.validate+0x32c>
    7534:      	uxtb	w16, w3
    7538:      	cmp	w16, wzr
    753c:      	b.ne	0x7604 <_stogir.vector-arithmetic.validate+0x32c>
    7540:      	mov	x0, #0x2                ; =2
    7544:      	b	0x7608 <_stogir.vector-arithmetic.validate+0x330>
    7548:      	movz	x4, #0x0, lsl #48
    754c:      	b	0x73a8 <_stogir.vector-arithmetic.validate+0xd0>
    7550:      	add	x16, sp, #0x10
    7554:      	ldr	w2, [x16, #0xc]
    7558:      	sxtw	x2, w2
    755c:      	lsr	w1, w1, #0
    7560:      	lsr	w4, w4, #0
    7564:      	lsr	w20, w20, #0
    7568:      	lsr	w2, w2, #0
    756c:      	ubfx	x0, x0, #8, #8
    7570:      	lsr	w0, w0, #0
    7574:      	add	x8, sp, #0x20
    7578:      	mov	w3, w1
    757c:      	mov	w1, w20
    7580:      	mov	w5, w2
    7584:      	mov	w2, w0
    7588:      	mov	x0, x22
    758c:      	bl	0x758c <_stogir.vector-arithmetic.validate+0x2b4>
		000000000000758c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    7590:      	add	x16, sp, #0x20
    7594:      	ldr	x1, [x16]
    7598:      	add	x16, sp, #0x20
    759c:      	ldr	x0, [x16, #0x8]
    75a0:      	add	x16, sp, #0x20
    75a4:      	ldr	x2, [x16, #0x10]
    75a8:      	b	0x7480 <_stogir.vector-arithmetic.validate+0x1a8>
    75ac:      	mov	x0, #0x1                ; =1
    75b0:      	sxtw	x1, w1
    75b4:      	lsr	w0, w0, #0
    75b8:      	sxtw	x0, w0
    75bc:      	cmp	x1, x0
    75c0:      	b.ne	0x746c <_stogir.vector-arithmetic.validate+0x194>
    75c4:      	add	x16, sp, #0x10
    75c8:      	ldr	w0, [x16]
    75cc:      	add	x16, sp, #0x10
    75d0:      	ldr	w1, [x16, #0x4]
    75d4:      	add	x16, sp, #0x10
    75d8:      	ldr	w4, [x16, #0x8]
    75dc:      	uxtb	w16, w2
    75e0:      	cmp	w16, wzr
    75e4:      	b.ne	0x7550 <_stogir.vector-arithmetic.validate+0x278>
    75e8:      	uxtb	w16, w3
    75ec:      	cmp	w16, wzr
    75f0:      	b.ne	0x7550 <_stogir.vector-arithmetic.validate+0x278>
    75f4:      	movz	x2, #0x0, lsl #48
    75f8:      	b	0x755c <_stogir.vector-arithmetic.validate+0x284>
    75fc:      	brk	#0
    7600:      	b	0x75fc <_stogir.vector-arithmetic.validate+0x324>
    7604:      	mov	x0, #0x3                ; =3
    7608:      	b	0x75b0 <_stogir.vector-arithmetic.validate+0x2d8>

000000000000760c <_stogir.vector.memory-inputs>:
    760c:      	sub	sp, sp, #0x40
    7610:      	str	x29, [sp]
    7614:      	str	x30, [sp, #0x8]
    7618:      	mov	x29, sp
    761c:      	str	x19, [sp, #0x10]
    7620:      	str	x20, [sp, #0x18]
    7624:      	str	x21, [sp, #0x20]
    7628:      	str	x22, [sp, #0x28]
    762c:      	str	x23, [sp, #0x30]
    7630:      	str	x24, [sp, #0x38]
    7634:      	sxtw	x5, w1
    7638:      	cmp	x5, #0xf
    763c:      	b.le	0x7acc <_stogir.vector.memory-inputs+0x4c0>
    7640:      	cmp	x5, #0x80
    7644:      	b.ge	0x7ad4 <_stogir.vector.memory-inputs+0x4c8>
    7648:      	and	x6, x5, #0xf
    764c:      	lsr	w6, w6, #0
    7650:      	sxtw	x6, w6
    7654:      	cmp	x6, #0x1
    7658:      	b.lt	0x7adc <_stogir.vector.memory-inputs+0x4d0>
    765c:      	and	x5, x5, #0xf
    7660:      	lsr	w5, w5, #0
    7664:      	sxtw	x5, w5
    7668:      	cmp	x5, #0xd
    766c:      	b.gt	0x7ae4 <_stogir.vector.memory-inputs+0x4d8>
    7670:      	lsr	w1, w1, #0
    7674:      	lsr	w2, w2, #0
    7678:      	mov	x19, x8
    767c:      	mov	x20, x0
    7680:      	mov	w0, w1
    7684:      	mov	w21, w1
    7688:      	mov	w1, w2
    768c:      	mov	w22, w2
    7690:      	mov	w23, w3
    7694:      	mov	w24, w4
    7698:      	bl	0x7698 <_stogir.vector.memory-inputs+0x8c>
		0000000000007698:  ARM64_RELOC_BRANCH26	_stogir.types.size
    769c:      	lsr	w0, w0, #0
    76a0:      	sxtw	x0, w0
    76a4:      	cmp	x0, #0x0
    76a8:      	b.le	0x770c <_stogir.vector.memory-inputs+0x100>
    76ac:      	sxtw	x23, w23
    76b0:      	cmp	x23, #0x0
    76b4:      	cset	w0, gt
    76b8:      	movz	x16, #0x0, lsl #48
    76bc:      	sub	x1, x16, x23
    76c0:      	sub	x2, x1, #0x1
    76c4:      	uxtb	w16, w0
    76c8:      	cmp	w16, wzr
    76cc:      	b.eq	0x77e8 <_stogir.vector.memory-inputs+0x1dc>
    76d0:      	ldr	x1, [x20, #0x8]
    76d4:      	cmp	x23, x1
    76d8:      	b.ge	0x77e0 <_stogir.vector.memory-inputs+0x1d4>
    76dc:      	add	x1, x20, #0x78
    76e0:      	ldr	x1, [x1, #0x8]
    76e4:      	cmp	x23, x1
    76e8:      	b.ge	0x7888 <_stogir.vector.memory-inputs+0x27c>
    76ec:      	ldr	x1, [x20, #0x78]
    76f0:      	add	x1, x1, x23, lsl #2
    76f4:      	ldr	w1, [x1]
    76f8:      	sxtw	x1, w1
    76fc:      	cmp	x1, #0x0
    7700:      	cset	w1, ge
    7704:      	ubfx	x1, x1, #0, #8
    7708:      	b	0x788c <_stogir.vector.memory-inputs+0x280>
    770c:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		000000000000770c:  ARM64_RELOC_PAGE21	l_stogir.421
    7710:      	ldr	x16, [x16]
		0000000000007710:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    7714:      	orr	x0, x16, xzr
    7718:      	mov	x1, #0x1                ; =1
    771c:      	mov	x2, #0x32               ; =50
    7720:      	str	x1, [x19]
    7724:      	str	x0, [x19, #0x8]
    7728:      	str	x2, [x19, #0x10]
    772c:      	ldr	x19, [sp, #0x10]
    7730:      	ldr	x20, [sp, #0x18]
    7734:      	ldr	x21, [sp, #0x20]
    7738:      	ldr	x22, [sp, #0x28]
    773c:      	ldr	x23, [sp, #0x30]
    7740:      	ldr	x24, [sp, #0x38]
    7744:      	ldr	x29, [sp]
    7748:      	ldr	x30, [sp, #0x8]
    774c:      	add	sp, sp, #0x40
    7750:      	ret
    7754:      	movz	x1, #0x0, lsl #48
    7758:      	movz	x0, #0x0, lsl #48
    775c:      	lsr	w1, w1, #0
    7760:      	lsr	x16, x1, #0
    7764:      	cmp	x16, #0x1
    7768:      	b.eq	0x7784 <_stogir.vector.memory-inputs+0x178>
    776c:      	b.lo	0x7774 <_stogir.vector.memory-inputs+0x168>
    7770:      	b	0x7788 <_stogir.vector.memory-inputs+0x17c>
    7774:      	cmp	x16, #0x0
    7778:      	b.eq	0x7780 <_stogir.vector.memory-inputs+0x174>
    777c:      	b	0x7788 <_stogir.vector.memory-inputs+0x17c>
    7780:      	b	0x778c <_stogir.vector.memory-inputs+0x180>
    7784:      	b	0x7830 <_stogir.vector.memory-inputs+0x224>
    7788:      	b	0x7ab4 <_stogir.vector.memory-inputs+0x4a8>
    778c:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		000000000000778c:  ARM64_RELOC_PAGE21	l_stogir.422
    7790:      	ldr	x16, [x16]
		0000000000007790:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    7794:      	orr	x0, x16, xzr
    7798:      	mov	x1, #0x1                ; =1
    779c:      	mov	x2, #0x1d               ; =29
    77a0:      	b	0x7720 <_stogir.vector.memory-inputs+0x114>
    77a4:      	ldr	x0, [x20, #0x28]
    77a8:      	add	x0, x0, x2, lsl #4
    77ac:      	ldr	x0, [x0]
    77b0:      	mov	x1, #0x1                ; =1
    77b4:      	b	0x775c <_stogir.vector.memory-inputs+0x150>
    77b8:      	movz	x1, #0x0, lsl #48
    77bc:      	cmp	x1, #0x0
    77c0:      	b.eq	0x7754 <_stogir.vector.memory-inputs+0x148>
    77c4:      	uxtb	w16, w0
    77c8:      	cmp	w16, wzr
    77cc:      	b.eq	0x77a4 <_stogir.vector.memory-inputs+0x198>
    77d0:      	ldr	x0, [x20]
    77d4:      	add	x0, x0, x23, lsl #4
    77d8:      	ldr	x0, [x0]
    77dc:      	b	0x77b0 <_stogir.vector.memory-inputs+0x1a4>
    77e0:      	movz	x1, #0x0, lsl #48
    77e4:      	b	0x77bc <_stogir.vector.memory-inputs+0x1b0>
    77e8:      	cmp	x23, #0x0
    77ec:      	b.ge	0x77b8 <_stogir.vector.memory-inputs+0x1ac>
    77f0:      	add	x3, x20, #0x28
    77f4:      	add	x4, x20, #0x50
    77f8:      	ldr	x3, [x3, #0x8]
    77fc:      	ldr	x4, [x4, #0x8]
    7800:      	cmp	x3, x4
    7804:      	b.ne	0x7880 <_stogir.vector.memory-inputs+0x274>
    7808:      	cmp	x1, x3
    780c:      	b.gt	0x7890 <_stogir.vector.memory-inputs+0x284>
    7810:      	ldr	x1, [x20, #0x50]
    7814:      	add	x1, x1, x2, lsl #2
    7818:      	ldr	w1, [x1]
    781c:      	sxtw	x1, w1
    7820:      	cmp	x1, #0x0
    7824:      	cset	w1, gt
    7828:      	ubfx	x1, x1, #0, #8
    782c:      	b	0x7894 <_stogir.vector.memory-inputs+0x288>
    7830:      	cmp	x23, #0x0
    7834:      	b.le	0x7868 <_stogir.vector.memory-inputs+0x25c>
    7838:      	uxtb	w0, w0
    783c:      	cmp	x0, #0x83
    7840:      	cset	w1, lt
    7844:      	uxtb	w16, w1
    7848:      	cmp	w16, wzr
    784c:      	b.eq	0x7898 <_stogir.vector.memory-inputs+0x28c>
    7850:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		0000000000007850:  ARM64_RELOC_PAGE21	l_stogir.423
    7854:      	ldr	x16, [x16]
		0000000000007854:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    7858:      	orr	x2, x16, xzr
    785c:      	add	x2, x0, x2
    7860:      	ldrb	w2, [x2]
    7864:      	b	0x789c <_stogir.vector.memory-inputs+0x290>
    7868:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		0000000000007868:  ARM64_RELOC_PAGE21	l_stogir.424
    786c:      	ldr	x16, [x16]
		000000000000786c:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    7870:      	orr	x0, x16, xzr
    7874:      	mov	x1, #0x1                ; =1
    7878:      	mov	x2, #0x2c               ; =44
    787c:      	b	0x77a0 <_stogir.vector.memory-inputs+0x194>
    7880:      	movz	x1, #0x0, lsl #48
    7884:      	b	0x77bc <_stogir.vector.memory-inputs+0x1b0>
    7888:      	movz	x1, #0x0, lsl #48
    788c:      	b	0x77e4 <_stogir.vector.memory-inputs+0x1d8>
    7890:      	movz	x1, #0x0, lsl #48
    7894:      	b	0x7884 <_stogir.vector.memory-inputs+0x278>
    7898:      	movz	x2, #0x0, lsl #48
    789c:      	uxtb	w2, w2
    78a0:      	and	x2, x2, #0x1
    78a4:      	uxtb	w2, w2
    78a8:      	cmp	x2, #0x0
    78ac:      	b.eq	0x7868 <_stogir.vector.memory-inputs+0x25c>
    78b0:      	uxtb	w16, w1
    78b4:      	cmp	w16, wzr
    78b8:      	b.eq	0x78d4 <_stogir.vector.memory-inputs+0x2c8>
    78bc:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		00000000000078bc:  ARM64_RELOC_PAGE21	l_stogir.423
    78c0:      	ldr	x16, [x16]
		00000000000078c0:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    78c4:      	orr	x1, x16, xzr
    78c8:      	add	x0, x0, x1
    78cc:      	ldrb	w0, [x0]
    78d0:      	b	0x78d8 <_stogir.vector.memory-inputs+0x2cc>
    78d4:      	movz	x0, #0x0, lsl #48
    78d8:      	uxtb	w0, w0
    78dc:      	and	x0, x0, #0x4
    78e0:      	uxtb	w0, w0
    78e4:      	cmp	x0, #0x0
    78e8:      	cset	w0, eq
    78ec:      	uxtb	w16, w0
    78f0:      	cmp	w16, wzr
    78f4:      	cset	x0, eq
    78f8:      	cmp	x0, #0x0
    78fc:      	b.ne	0x7868 <_stogir.vector.memory-inputs+0x25c>
    7900:      	sxtw	x24, w24
    7904:      	cmp	x24, #0x0
    7908:      	cset	w0, gt
    790c:      	movz	x16, #0x0, lsl #48
    7910:      	sub	x1, x16, x24
    7914:      	sub	x2, x1, #0x1
    7918:      	uxtb	w16, w0
    791c:      	cmp	w16, wzr
    7920:      	b.eq	0x7978 <_stogir.vector.memory-inputs+0x36c>
    7924:      	ldr	x1, [x20, #0x8]
    7928:      	cmp	x24, x1
    792c:      	b.ge	0x79c0 <_stogir.vector.memory-inputs+0x3b4>
    7930:      	add	x1, x20, #0x78
    7934:      	ldr	x1, [x1, #0x8]
    7938:      	cmp	x24, x1
    793c:      	b.ge	0x7aac <_stogir.vector.memory-inputs+0x4a0>
    7940:      	ldr	x1, [x20, #0x78]
    7944:      	add	x1, x1, x24, lsl #2
    7948:      	ldr	w1, [x1]
    794c:      	sxtw	x1, w1
    7950:      	cmp	x1, #0x0
    7954:      	cset	w1, ge
    7958:      	ubfx	x1, x1, #0, #8
    795c:      	b	0x7ab0 <_stogir.vector.memory-inputs+0x4a4>
    7960:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		0000000000007960:  ARM64_RELOC_PAGE21	l_stogir.425
    7964:      	ldr	x16, [x16]
		0000000000007964:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    7968:      	orr	x0, x16, xzr
    796c:      	mov	x1, #0x1                ; =1
    7970:      	mov	x2, #0x2b               ; =43
    7974:      	b	0x787c <_stogir.vector.memory-inputs+0x270>
    7978:      	cmp	x24, #0x0
    797c:      	b.ge	0x79c8 <_stogir.vector.memory-inputs+0x3bc>
    7980:      	add	x3, x20, #0x28
    7984:      	add	x4, x20, #0x50
    7988:      	ldr	x3, [x3, #0x8]
    798c:      	ldr	x4, [x4, #0x8]
    7990:      	cmp	x3, x4
    7994:      	b.ne	0x7aa4 <_stogir.vector.memory-inputs+0x498>
    7998:      	cmp	x1, x3
    799c:      	b.gt	0x7abc <_stogir.vector.memory-inputs+0x4b0>
    79a0:      	ldr	x1, [x20, #0x50]
    79a4:      	add	x1, x1, x2, lsl #2
    79a8:      	ldr	w1, [x1]
    79ac:      	sxtw	x1, w1
    79b0:      	cmp	x1, #0x0
    79b4:      	cset	w1, gt
    79b8:      	ubfx	x1, x1, #0, #8
    79bc:      	b	0x7ac0 <_stogir.vector.memory-inputs+0x4b4>
    79c0:      	movz	x1, #0x0, lsl #48
    79c4:      	b	0x79cc <_stogir.vector.memory-inputs+0x3c0>
    79c8:      	movz	x1, #0x0, lsl #48
    79cc:      	cmp	x1, #0x0
    79d0:      	b.eq	0x7a04 <_stogir.vector.memory-inputs+0x3f8>
    79d4:      	uxtb	w16, w0
    79d8:      	cmp	w16, wzr
    79dc:      	b.eq	0x79f0 <_stogir.vector.memory-inputs+0x3e4>
    79e0:      	ldr	x0, [x20]
    79e4:      	add	x0, x0, x24, lsl #4
    79e8:      	ldr	x0, [x0]
    79ec:      	b	0x79fc <_stogir.vector.memory-inputs+0x3f0>
    79f0:      	ldr	x0, [x20, #0x28]
    79f4:      	add	x0, x0, x2, lsl #4
    79f8:      	ldr	x0, [x0]
    79fc:      	mov	x1, #0x1                ; =1
    7a00:      	b	0x7a0c <_stogir.vector.memory-inputs+0x400>
    7a04:      	movz	x1, #0x0, lsl #48
    7a08:      	movz	x0, #0x0, lsl #48
    7a0c:      	lsr	w1, w1, #0
    7a10:      	lsr	x16, x1, #0
    7a14:      	cmp	x16, #0x1
    7a18:      	b.eq	0x7a34 <_stogir.vector.memory-inputs+0x428>
    7a1c:      	b.lo	0x7a24 <_stogir.vector.memory-inputs+0x418>
    7a20:      	b	0x7a38 <_stogir.vector.memory-inputs+0x42c>
    7a24:      	cmp	x16, #0x0
    7a28:      	b.eq	0x7a30 <_stogir.vector.memory-inputs+0x424>
    7a2c:      	b	0x7a38 <_stogir.vector.memory-inputs+0x42c>
    7a30:      	b	0x7a3c <_stogir.vector.memory-inputs+0x430>
    7a34:      	b	0x7a54 <_stogir.vector.memory-inputs+0x448>
    7a38:      	b	0x7ac4 <_stogir.vector.memory-inputs+0x4b8>
    7a3c:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		0000000000007a3c:  ARM64_RELOC_PAGE21	l_stogir.426
    7a40:      	ldr	x16, [x16]
		0000000000007a40:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    7a44:      	orr	x0, x16, xzr
    7a48:      	mov	x1, #0x1                ; =1
    7a4c:      	mov	x2, #0x1d               ; =29
    7a50:      	b	0x7974 <_stogir.vector.memory-inputs+0x368>
    7a54:      	lsr	w1, w0, #0
    7a58:      	ubfx	x1, x1, #8, #8
    7a5c:      	cmp	x1, #0x6
    7a60:      	b.ne	0x7960 <_stogir.vector.memory-inputs+0x354>
    7a64:      	uxtb	w0, w0
    7a68:      	cmp	x0, #0x48
    7a6c:      	b.eq	0x7960 <_stogir.vector.memory-inputs+0x354>
    7a70:      	cmp	x0, #0x46
    7a74:      	b.eq	0x7960 <_stogir.vector.memory-inputs+0x354>
    7a78:      	lsr	w21, w21, #0
    7a7c:      	lsr	w22, w22, #0
    7a80:      	mov	w0, w21
    7a84:      	mov	w1, w22
    7a88:      	bl	0x7a88 <_stogir.vector.memory-inputs+0x47c>
		0000000000007a88:  ARM64_RELOC_BRANCH26	_stogir.types.size
    7a8c:      	lsr	w0, w0, #0
    7a90:      	sxtw	x0, w0
    7a94:      	and	x0, x0, #0xffffffff
    7a98:      	movz	x1, #0x0, lsl #48
    7a9c:      	movz	x2, #0x0, lsl #48
    7aa0:      	b	0x7974 <_stogir.vector.memory-inputs+0x368>
    7aa4:      	movz	x1, #0x0, lsl #48
    7aa8:      	b	0x79cc <_stogir.vector.memory-inputs+0x3c0>
    7aac:      	movz	x1, #0x0, lsl #48
    7ab0:      	b	0x79c4 <_stogir.vector.memory-inputs+0x3b8>
    7ab4:      	brk	#0
    7ab8:      	b	0x7ab4 <_stogir.vector.memory-inputs+0x4a8>
    7abc:      	movz	x1, #0x0, lsl #48
    7ac0:      	b	0x7aa8 <_stogir.vector.memory-inputs+0x49c>
    7ac4:      	brk	#0
    7ac8:      	b	0x7ac4 <_stogir.vector.memory-inputs+0x4b8>
    7acc:      	mov	x19, x8
    7ad0:      	b	0x770c <_stogir.vector.memory-inputs+0x100>
    7ad4:      	mov	x19, x8
    7ad8:      	b	0x770c <_stogir.vector.memory-inputs+0x100>
    7adc:      	mov	x19, x8
    7ae0:      	b	0x770c <_stogir.vector.memory-inputs+0x100>
    7ae4:      	mov	x19, x8
    7ae8:      	b	0x770c <_stogir.vector.memory-inputs+0x100>

0000000000007aec <_stogir.vector.store-inputs>:
    7aec:      	sub	sp, sp, #0x40
    7af0:      	str	x29, [sp]
    7af4:      	str	x30, [sp, #0x8]
    7af8:      	mov	x29, sp
    7afc:      	str	x19, [sp, #0x30]
    7b00:      	sxtw	x4, w4
    7b04:      	cmp	x4, #0x0
    7b08:      	cset	w5, gt
    7b0c:      	movz	x16, #0x0, lsl #48
    7b10:      	sub	x6, x16, x4
    7b14:      	sub	x7, x6, #0x1
    7b18:      	uxtb	w16, w5
    7b1c:      	cmp	w16, wzr
    7b20:      	b.eq	0x7b60 <_stogir.vector.store-inputs+0x74>
    7b24:      	ldr	x6, [x0, #0x8]
    7b28:      	cmp	x4, x6
    7b2c:      	b.ge	0x7bb0 <_stogir.vector.store-inputs+0xc4>
    7b30:      	add	x6, x0, #0x78
    7b34:      	ldr	x6, [x6, #0x8]
    7b38:      	cmp	x4, x6
    7b3c:      	b.ge	0x7cb8 <_stogir.vector.store-inputs+0x1cc>
    7b40:      	ldr	x6, [x0, #0x78]
    7b44:      	add	x6, x6, x4, lsl #2
    7b48:      	ldr	w6, [x6]
    7b4c:      	sxtw	x6, w6
    7b50:      	cmp	x6, #0x0
    7b54:      	cset	w6, ge
    7b58:      	ubfx	x6, x6, #0, #8
    7b5c:      	b	0x7cbc <_stogir.vector.store-inputs+0x1d0>
    7b60:      	cmp	x4, #0x0
    7b64:      	b.ge	0x7bb8 <_stogir.vector.store-inputs+0xcc>
    7b68:      	add	x9, x0, #0x28
    7b6c:      	add	x10, x0, #0x50
    7b70:      	ldr	x9, [x9, #0x8]
    7b74:      	ldr	x10, [x10, #0x8]
    7b78:      	cmp	x9, x10
    7b7c:      	b.ne	0x7ba8 <_stogir.vector.store-inputs+0xbc>
    7b80:      	cmp	x6, x9
    7b84:      	b.gt	0x7cc0 <_stogir.vector.store-inputs+0x1d4>
    7b88:      	ldr	x6, [x0, #0x50]
    7b8c:      	add	x6, x6, x7, lsl #2
    7b90:      	ldr	w6, [x6]
    7b94:      	sxtw	x6, w6
    7b98:      	cmp	x6, #0x0
    7b9c:      	cset	w6, gt
    7ba0:      	ubfx	x6, x6, #0, #8
    7ba4:      	b	0x7cc4 <_stogir.vector.store-inputs+0x1d8>
    7ba8:      	movz	x6, #0x0, lsl #48
    7bac:      	b	0x7bbc <_stogir.vector.store-inputs+0xd0>
    7bb0:      	movz	x6, #0x0, lsl #48
    7bb4:      	b	0x7bbc <_stogir.vector.store-inputs+0xd0>
    7bb8:      	movz	x6, #0x0, lsl #48
    7bbc:      	cmp	x6, #0x0
    7bc0:      	b.eq	0x7bf4 <_stogir.vector.store-inputs+0x108>
    7bc4:      	uxtb	w16, w5
    7bc8:      	cmp	w16, wzr
    7bcc:      	b.eq	0x7be0 <_stogir.vector.store-inputs+0xf4>
    7bd0:      	ldr	x5, [x0]
    7bd4:      	add	x4, x5, x4, lsl #4
    7bd8:      	ldr	x4, [x4]
    7bdc:      	b	0x7bec <_stogir.vector.store-inputs+0x100>
    7be0:      	ldr	x4, [x0, #0x28]
    7be4:      	add	x4, x4, x7, lsl #4
    7be8:      	ldr	x4, [x4]
    7bec:      	mov	x5, #0x1                ; =1
    7bf0:      	b	0x7bfc <_stogir.vector.store-inputs+0x110>
    7bf4:      	movz	x5, #0x0, lsl #48
    7bf8:      	movz	x4, #0x0, lsl #48
    7bfc:      	lsr	w5, w5, #0
    7c00:      	lsr	x16, x5, #0
    7c04:      	cmp	x16, #0x1
    7c08:      	b.eq	0x7c24 <_stogir.vector.store-inputs+0x138>
    7c0c:      	b.lo	0x7c14 <_stogir.vector.store-inputs+0x128>
    7c10:      	b	0x7c28 <_stogir.vector.store-inputs+0x13c>
    7c14:      	cmp	x16, #0x0
    7c18:      	b.eq	0x7c20 <_stogir.vector.store-inputs+0x134>
    7c1c:      	b	0x7c28 <_stogir.vector.store-inputs+0x13c>
    7c20:      	b	0x7c2c <_stogir.vector.store-inputs+0x140>
    7c24:      	b	0x7c48 <_stogir.vector.store-inputs+0x15c>
    7c28:      	b	0x7cc8 <_stogir.vector.store-inputs+0x1dc>
    7c2c:      	adrp	x16, 0x7000 <_stogir.vector-comparison.validate+0x2d8>
		0000000000007c2c:  ARM64_RELOC_PAGE21	l_stogir.427
    7c30:      	ldr	x16, [x16]
		0000000000007c30:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    7c34:      	orr	x0, x16, xzr
    7c38:      	mov	x19, x8
    7c3c:      	mov	x1, #0x1                ; =1
    7c40:      	mov	x2, #0x1a               ; =26
    7c44:      	b	0x7c98 <_stogir.vector.store-inputs+0x1ac>
    7c48:      	lsr	w1, w1, #0
    7c4c:      	lsr	w2, w2, #0
    7c50:      	lsr	w3, w3, #0
    7c54:      	lsr	w4, w4, #0
    7c58:      	ubfx	x4, x4, #8, #8
    7c5c:      	lsr	w4, w4, #0
    7c60:      	mov	x19, x8
    7c64:      	add	x8, sp, #0x10
    7c68:      	fmov	s31, w1
    7c6c:      	mov	w1, w4
    7c70:      	mov	w4, w3
    7c74:      	mov	w3, w2
    7c78:      	fmov	w2, s31
    7c7c:      	bl	0x7c7c <_stogir.vector.store-inputs+0x190>
		0000000000007c7c:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    7c80:      	add	x16, sp, #0x10
    7c84:      	ldr	x1, [x16]
    7c88:      	add	x16, sp, #0x10
    7c8c:      	ldr	x0, [x16, #0x8]
    7c90:      	add	x16, sp, #0x10
    7c94:      	ldr	x2, [x16, #0x10]
    7c98:      	str	x1, [x19]
    7c9c:      	str	x0, [x19, #0x8]
    7ca0:      	str	x2, [x19, #0x10]
    7ca4:      	ldr	x19, [sp, #0x30]
    7ca8:      	ldr	x29, [sp]
    7cac:      	ldr	x30, [sp, #0x8]
    7cb0:      	add	sp, sp, #0x40
    7cb4:      	ret
    7cb8:      	movz	x6, #0x0, lsl #48
    7cbc:      	b	0x7bb4 <_stogir.vector.store-inputs+0xc8>
    7cc0:      	movz	x6, #0x0, lsl #48
    7cc4:      	b	0x7bac <_stogir.vector.store-inputs+0xc0>
    7cc8:      	brk	#0
    7ccc:      	b	0x7cc8 <_stogir.vector.store-inputs+0x1dc>

0000000000007cd0 <_stogir.types.size>:
    7cd0:      	sxtw	x0, w0
    7cd4:      	sxtw	x1, w1
    7cd8:      	cmp	x0, #0xf
    7cdc:      	cset	w2, gt
    7ce0:      	cmp	x0, #0x0
    7ce4:      	cset	w3, eq
    7ce8:      	cmp	x1, #0x4
    7cec:      	cset	w4, eq
    7cf0:      	cmp	x1, #0x8
    7cf4:      	cset	w5, eq
    7cf8:      	uxtb	w16, w2
    7cfc:      	cmp	w16, wzr
    7d00:      	b.eq	0x7dc8 <_stogir.types.size+0xf8>
    7d04:      	cmp	x0, #0x80
    7d08:      	cset	w6, lt
    7d0c:      	uxtb	w16, w6
    7d10:      	cmp	w16, wzr
    7d14:      	b.eq	0x7dc8 <_stogir.types.size+0xf8>
    7d18:      	and	x7, x0, #0xf
    7d1c:      	lsr	w7, w7, #0
    7d20:      	sxtw	x7, w7
    7d24:      	cmp	x7, #0x1
    7d28:      	cset	w8, ge
    7d2c:      	uxtb	w16, w8
    7d30:      	cmp	w16, wzr
    7d34:      	b.eq	0x7dc8 <_stogir.types.size+0xf8>
    7d38:      	cmp	x7, #0xd
    7d3c:      	cset	w9, le
    7d40:      	uxtb	w16, w9
    7d44:      	cmp	w16, wzr
    7d48:      	b.eq	0x7dc8 <_stogir.types.size+0xf8>
    7d4c:      	cmp	x0, #0x0
    7d50:      	cset	w10, ge
    7d54:      	cmp	x0, #0xd
    7d58:      	cset	w11, le
    7d5c:      	uxtb	w16, w10
    7d60:      	cmp	w16, wzr
    7d64:      	b.eq	0x7d74 <_stogir.types.size+0xa4>
    7d68:      	uxtb	w16, w11
    7d6c:      	cmp	w16, wzr
    7d70:      	b.ne	0x7da8 <_stogir.types.size+0xd8>
    7d74:      	uxtb	w16, w2
    7d78:      	cmp	w16, wzr
    7d7c:      	b.eq	0x7da4 <_stogir.types.size+0xd4>
    7d80:      	uxtb	w16, w6
    7d84:      	cmp	w16, wzr
    7d88:      	b.eq	0x7da4 <_stogir.types.size+0xd4>
    7d8c:      	uxtb	w16, w8
    7d90:      	cmp	w16, wzr
    7d94:      	b.eq	0x7da4 <_stogir.types.size+0xd4>
    7d98:      	uxtb	w16, w9
    7d9c:      	cmp	w16, wzr
    7da0:      	b.ne	0x7da8 <_stogir.types.size+0xd8>
    7da4:      	movn	x7, #0x0, lsl #48
    7da8:      	uxtb	w16, w4
    7dac:      	cmp	w16, wzr
    7db0:      	b.ne	0x7f08 <_stogir.types.size+0x238>
    7db4:      	uxtb	w16, w5
    7db8:      	cmp	w16, wzr
    7dbc:      	b.ne	0x7f08 <_stogir.types.size+0x238>
    7dc0:      	movn	x1, #0x0, lsl #48
    7dc4:      	b	0x7e7c <_stogir.types.size+0x1ac>
    7dc8:      	uxtb	w16, w4
    7dcc:      	cmp	w16, wzr
    7dd0:      	b.ne	0x7de8 <_stogir.types.size+0x118>
    7dd4:      	uxtb	w16, w5
    7dd8:      	cmp	w16, wzr
    7ddc:      	b.ne	0x7de8 <_stogir.types.size+0x118>
    7de0:      	movn	x1, #0x0, lsl #48
    7de4:      	b	0x7e00 <_stogir.types.size+0x130>
    7de8:      	uxtb	w16, w3
    7dec:      	cmp	w16, wzr
    7df0:      	b.eq	0x7e08 <_stogir.types.size+0x138>
    7df4:      	movz	x1, #0x0, lsl #48
    7df8:      	b	0x7e00 <_stogir.types.size+0x130>
    7dfc:      	mov	x1, #0x1                ; =1
    7e00:      	mov	x0, x1
    7e04:      	ret
    7e08:      	cmp	x0, #0x1
    7e0c:      	b.eq	0x7dfc <_stogir.types.size+0x12c>
    7e10:      	cmp	x0, #0x2
    7e14:      	b.eq	0x7dfc <_stogir.types.size+0x12c>
    7e18:      	cmp	x0, #0x7
    7e1c:      	b.eq	0x7dfc <_stogir.types.size+0x12c>
    7e20:      	cmp	x0, #0x8
    7e24:      	b.eq	0x7dfc <_stogir.types.size+0x12c>
    7e28:      	cmp	x0, #0x3
    7e2c:      	b.eq	0x7f90 <_stogir.types.size+0x2c0>
    7e30:      	cmp	x0, #0x9
    7e34:      	b.eq	0x7f90 <_stogir.types.size+0x2c0>
    7e38:      	cmp	x0, #0x4
    7e3c:      	b.eq	0x7fc0 <_stogir.types.size+0x2f0>
    7e40:      	cmp	x0, #0xa
    7e44:      	b.eq	0x7fc0 <_stogir.types.size+0x2f0>
    7e48:      	cmp	x0, #0xd
    7e4c:      	b.eq	0x7fc0 <_stogir.types.size+0x2f0>
    7e50:      	cmp	x0, #0x5
    7e54:      	b.eq	0x7fd0 <_stogir.types.size+0x300>
    7e58:      	cmp	x0, #0xb
    7e5c:      	b.eq	0x7fd0 <_stogir.types.size+0x300>
    7e60:      	cmp	x0, #0xc
    7e64:      	b.eq	0x7fd0 <_stogir.types.size+0x300>
    7e68:      	cmp	x0, #0x6
    7e6c:      	b.eq	0x7e74 <_stogir.types.size+0x1a4>
    7e70:      	movn	x1, #0x0, lsl #48
    7e74:      	b	0x7fd4 <_stogir.types.size+0x304>
    7e78:      	mov	x1, #0x1                ; =1
    7e7c:      	lsr	w1, w1, #0
    7e80:      	sxtw	x1, w1
    7e84:      	cmp	x1, #0x0
    7e88:      	b.ge	0x7e94 <_stogir.types.size+0x1c4>
    7e8c:      	movn	x1, #0x0, lsl #48
    7e90:      	b	0x7e00 <_stogir.types.size+0x130>
    7e94:      	uxtb	w16, w2
    7e98:      	cmp	w16, wzr
    7e9c:      	b.eq	0x7f98 <_stogir.types.size+0x2c8>
    7ea0:      	uxtb	w16, w6
    7ea4:      	cmp	w16, wzr
    7ea8:      	b.eq	0x7f98 <_stogir.types.size+0x2c8>
    7eac:      	uxtb	w16, w8
    7eb0:      	cmp	w16, wzr
    7eb4:      	b.eq	0x7f98 <_stogir.types.size+0x2c8>
    7eb8:      	uxtb	w16, w9
    7ebc:      	cmp	w16, wzr
    7ec0:      	b.eq	0x7f98 <_stogir.types.size+0x2c8>
    7ec4:      	ubfx	x0, x0, #4, #32
    7ec8:      	sxtw	x0, w0
    7ecc:      	sub	x0, x0, #0x1
    7ed0:      	lsr	w0, w0, #0
    7ed4:      	sxtw	x0, w0
    7ed8:      	mov	x16, #0x1               ; =1
    7edc:      	lsl	x0, x16, x0
    7ee0:      	lsr	w0, w0, #0
    7ee4:      	sxtw	x0, w0
    7ee8:      	b	0x7ef0 <_stogir.types.size+0x220>
    7eec:      	movn	x0, #0x0, lsl #48
    7ef0:      	lsr	w0, w0, #0
    7ef4:      	sxtw	x0, w0
    7ef8:      	mul	x0, x0, x1
    7efc:      	lsr	w0, w0, #0
    7f00:      	sxtw	x1, w0
    7f04:      	b	0x7e90 <_stogir.types.size+0x1c0>
    7f08:      	lsr	w7, w7, #0
    7f0c:      	sxtw	x7, w7
    7f10:      	cmp	x7, #0x0
    7f14:      	b.ne	0x7f20 <_stogir.types.size+0x250>
    7f18:      	movz	x1, #0x0, lsl #48
    7f1c:      	b	0x7e7c <_stogir.types.size+0x1ac>
    7f20:      	cmp	x7, #0x1
    7f24:      	b.eq	0x7e78 <_stogir.types.size+0x1a8>
    7f28:      	cmp	x7, #0x2
    7f2c:      	b.eq	0x7e78 <_stogir.types.size+0x1a8>
    7f30:      	cmp	x7, #0x7
    7f34:      	b.eq	0x7e78 <_stogir.types.size+0x1a8>
    7f38:      	cmp	x7, #0x8
    7f3c:      	b.eq	0x7e78 <_stogir.types.size+0x1a8>
    7f40:      	cmp	x7, #0x3
    7f44:      	b.eq	0x7fc8 <_stogir.types.size+0x2f8>
    7f48:      	cmp	x7, #0x9
    7f4c:      	b.eq	0x7fc8 <_stogir.types.size+0x2f8>
    7f50:      	cmp	x7, #0x4
    7f54:      	b.eq	0x7fd8 <_stogir.types.size+0x308>
    7f58:      	cmp	x7, #0xa
    7f5c:      	b.eq	0x7fd8 <_stogir.types.size+0x308>
    7f60:      	cmp	x7, #0xd
    7f64:      	b.eq	0x7fd8 <_stogir.types.size+0x308>
    7f68:      	cmp	x7, #0x5
    7f6c:      	b.eq	0x7fe0 <_stogir.types.size+0x310>
    7f70:      	cmp	x7, #0xb
    7f74:      	b.eq	0x7fe0 <_stogir.types.size+0x310>
    7f78:      	cmp	x7, #0xc
    7f7c:      	b.eq	0x7fe0 <_stogir.types.size+0x310>
    7f80:      	cmp	x7, #0x6
    7f84:      	b.eq	0x7f8c <_stogir.types.size+0x2bc>
    7f88:      	movn	x1, #0x0, lsl #48
    7f8c:      	b	0x7fe4 <_stogir.types.size+0x314>
    7f90:      	mov	x1, #0x2                ; =2
    7f94:      	b	0x7e00 <_stogir.types.size+0x130>
    7f98:      	uxtb	w16, w10
    7f9c:      	cmp	w16, wzr
    7fa0:      	b.eq	0x7eec <_stogir.types.size+0x21c>
    7fa4:      	uxtb	w16, w11
    7fa8:      	cmp	w16, wzr
    7fac:      	b.eq	0x7eec <_stogir.types.size+0x21c>
    7fb0:      	uxtb	w16, w3
    7fb4:      	cmp	w16, wzr
    7fb8:      	cset	x0, eq
    7fbc:      	b	0x7ef0 <_stogir.types.size+0x220>
    7fc0:      	mov	x1, #0x4                ; =4
    7fc4:      	b	0x7f94 <_stogir.types.size+0x2c4>
    7fc8:      	mov	x1, #0x2                ; =2
    7fcc:      	b	0x7e7c <_stogir.types.size+0x1ac>
    7fd0:      	mov	x1, #0x8                ; =8
    7fd4:      	b	0x7fc4 <_stogir.types.size+0x2f4>
    7fd8:      	mov	x1, #0x4                ; =4
    7fdc:      	b	0x7fcc <_stogir.types.size+0x2fc>
    7fe0:      	mov	x1, #0x8                ; =8
    7fe4:      	b	0x7fdc <_stogir.types.size+0x30c>

0000000000007fe8 <_stogir.checked.projection>:
    7fe8:      	sub	sp, sp, #0x40
    7fec:      	str	x29, [sp]
    7ff0:      	str	x30, [sp, #0x8]
    7ff4:      	mov	x29, sp
    7ff8:      	str	x19, [sp, #0x30]
    7ffc:      	sxtw	x2, w1
    8000:      	cmp	x2, #0x0
    8004:      	cset	w3, gt
    8008:      	movz	x16, #0x0, lsl #48
    800c:      	sub	x4, x16, x2
    8010:      	sub	x5, x4, #0x1
    8014:      	uxtb	w16, w3
    8018:      	cmp	w16, wzr
    801c:      	b.eq	0x805c <_stogir.checked.projection+0x74>
    8020:      	ldr	x4, [x0, #0x8]
    8024:      	cmp	x2, x4
    8028:      	b.ge	0x80ac <_stogir.checked.projection+0xc4>
    802c:      	add	x4, x0, #0x78
    8030:      	ldr	x4, [x4, #0x8]
    8034:      	cmp	x2, x4
    8038:      	b.ge	0x81b8 <_stogir.checked.projection+0x1d0>
    803c:      	ldr	x4, [x0, #0x78]
    8040:      	add	x4, x4, x2, lsl #2
    8044:      	ldr	w4, [x4]
    8048:      	sxtw	x4, w4
    804c:      	cmp	x4, #0x0
    8050:      	cset	w4, ge
    8054:      	ubfx	x4, x4, #0, #8
    8058:      	b	0x81bc <_stogir.checked.projection+0x1d4>
    805c:      	cmp	x2, #0x0
    8060:      	b.ge	0x80b4 <_stogir.checked.projection+0xcc>
    8064:      	add	x6, x0, #0x28
    8068:      	add	x7, x0, #0x50
    806c:      	ldr	x6, [x6, #0x8]
    8070:      	ldr	x7, [x7, #0x8]
    8074:      	cmp	x6, x7
    8078:      	b.ne	0x80a4 <_stogir.checked.projection+0xbc>
    807c:      	cmp	x4, x6
    8080:      	b.gt	0x81e8 <_stogir.checked.projection+0x200>
    8084:      	ldr	x4, [x0, #0x50]
    8088:      	add	x4, x4, x5, lsl #2
    808c:      	ldr	w4, [x4]
    8090:      	sxtw	x4, w4
    8094:      	cmp	x4, #0x0
    8098:      	cset	w4, gt
    809c:      	ubfx	x4, x4, #0, #8
    80a0:      	b	0x81ec <_stogir.checked.projection+0x204>
    80a4:      	movz	x4, #0x0, lsl #48
    80a8:      	b	0x80b8 <_stogir.checked.projection+0xd0>
    80ac:      	movz	x4, #0x0, lsl #48
    80b0:      	b	0x80b8 <_stogir.checked.projection+0xd0>
    80b4:      	movz	x4, #0x0, lsl #48
    80b8:      	cmp	x4, #0x0
    80bc:      	b.eq	0x80f0 <_stogir.checked.projection+0x108>
    80c0:      	uxtb	w16, w3
    80c4:      	cmp	w16, wzr
    80c8:      	b.eq	0x80dc <_stogir.checked.projection+0xf4>
    80cc:      	ldr	x3, [x0]
    80d0:      	add	x2, x3, x2, lsl #4
    80d4:      	ldr	x2, [x2]
    80d8:      	b	0x80e8 <_stogir.checked.projection+0x100>
    80dc:      	ldr	x2, [x0, #0x28]
    80e0:      	add	x2, x2, x5, lsl #4
    80e4:      	ldr	x2, [x2]
    80e8:      	mov	x3, #0x1                ; =1
    80ec:      	b	0x80f8 <_stogir.checked.projection+0x110>
    80f0:      	movz	x3, #0x0, lsl #48
    80f4:      	movz	x2, #0x0, lsl #48
    80f8:      	lsr	w3, w3, #0
    80fc:      	lsr	x16, x3, #0
    8100:      	cmp	x16, #0x1
    8104:      	b.eq	0x8120 <_stogir.checked.projection+0x138>
    8108:      	b.lo	0x8110 <_stogir.checked.projection+0x128>
    810c:      	b	0x8124 <_stogir.checked.projection+0x13c>
    8110:      	cmp	x16, #0x0
    8114:      	b.eq	0x811c <_stogir.checked.projection+0x134>
    8118:      	b	0x8124 <_stogir.checked.projection+0x13c>
    811c:      	b	0x8128 <_stogir.checked.projection+0x140>
    8120:      	b	0x8178 <_stogir.checked.projection+0x190>
    8124:      	b	0x81f0 <_stogir.checked.projection+0x208>
    8128:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008128:  ARM64_RELOC_PAGE21	l_stogir.428
    812c:      	ldr	x16, [x16]
		000000000000812c:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    8130:      	orr	x0, x16, xzr
    8134:      	mov	x19, x8
    8138:      	mov	x1, #0x1                ; =1
    813c:      	mov	x2, #0x17               ; =23
    8140:      	b	0x8158 <_stogir.checked.projection+0x170>
    8144:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008144:  ARM64_RELOC_PAGE21	l_stogir.429
    8148:      	ldr	x16, [x16]
		0000000000008148:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    814c:      	orr	x0, x16, xzr
    8150:      	mov	x1, #0x1                ; =1
    8154:      	mov	x2, #0x20               ; =32
    8158:      	str	x1, [x19]
    815c:      	str	x0, [x19, #0x8]
    8160:      	str	x2, [x19, #0x10]
    8164:      	ldr	x19, [sp, #0x30]
    8168:      	ldr	x29, [sp]
    816c:      	ldr	x30, [sp, #0x8]
    8170:      	add	sp, sp, #0x40
    8174:      	ret
    8178:      	uxtb	w3, w2
    817c:      	cmp	x3, #0x29
    8180:      	b.lt	0x81f8 <_stogir.checked.projection+0x210>
    8184:      	cmp	x3, #0x2b
    8188:      	b.gt	0x8200 <_stogir.checked.projection+0x218>
    818c:      	lsr	w1, w1, #0
    8190:      	mov	x19, x8
    8194:      	add	x8, sp, #0x10
    8198:      	bl	0x8198 <_stogir.checked.projection+0x1b0>
		0000000000008198:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    819c:      	add	x16, sp, #0x10
    81a0:      	ldr	x1, [x16]
    81a4:      	add	x16, sp, #0x10
    81a8:      	ldr	x0, [x16, #0x8]
    81ac:      	add	x16, sp, #0x10
    81b0:      	ldr	x2, [x16, #0x10]
    81b4:      	b	0x8158 <_stogir.checked.projection+0x170>
    81b8:      	movz	x4, #0x0, lsl #48
    81bc:      	b	0x80b0 <_stogir.checked.projection+0xc8>
    81c0:      	lsr	w2, w2, #0
    81c4:      	ubfx	x0, x2, #8, #8
    81c8:      	cmp	x0, #0x0
    81cc:      	b.eq	0x8144 <_stogir.checked.projection+0x15c>
    81d0:      	cmp	x0, #0xd
    81d4:      	b.gt	0x8144 <_stogir.checked.projection+0x15c>
    81d8:      	movz	x1, #0x0, lsl #48
    81dc:      	movz	x0, #0x0, lsl #48
    81e0:      	movz	x2, #0x0, lsl #48
    81e4:      	b	0x8158 <_stogir.checked.projection+0x170>
    81e8:      	movz	x4, #0x0, lsl #48
    81ec:      	b	0x80a8 <_stogir.checked.projection+0xc0>
    81f0:      	brk	#0
    81f4:      	b	0x81f0 <_stogir.checked.projection+0x208>
    81f8:      	mov	x19, x8
    81fc:      	b	0x81c0 <_stogir.checked.projection+0x1d8>
    8200:      	mov	x19, x8
    8204:      	b	0x81c0 <_stogir.checked.projection+0x1d8>

0000000000008208 <_stogir.atomic.ordinary?>:
    8208:      	sxtw	x1, w1
    820c:      	cmp	x1, #0x0
    8210:      	cset	w3, gt
    8214:      	movz	x16, #0x0, lsl #48
    8218:      	sub	x4, x16, x1
    821c:      	sub	x5, x4, #0x1
    8220:      	uxtb	w16, w3
    8224:      	cmp	w16, wzr
    8228:      	b.eq	0x8268 <_stogir.atomic.ordinary?+0x60>
    822c:      	ldr	x4, [x0, #0x8]
    8230:      	cmp	x1, x4
    8234:      	b.ge	0x82b8 <_stogir.atomic.ordinary?+0xb0>
    8238:      	add	x4, x0, #0x78
    823c:      	ldr	x4, [x4, #0x8]
    8240:      	cmp	x1, x4
    8244:      	b.ge	0x836c <_stogir.atomic.ordinary?+0x164>
    8248:      	ldr	x4, [x0, #0x78]
    824c:      	add	x4, x4, x1, lsl #2
    8250:      	ldr	w4, [x4]
    8254:      	sxtw	x4, w4
    8258:      	cmp	x4, #0x0
    825c:      	cset	w4, ge
    8260:      	ubfx	x4, x4, #0, #8
    8264:      	b	0x8370 <_stogir.atomic.ordinary?+0x168>
    8268:      	cmp	x1, #0x0
    826c:      	b.ge	0x82c0 <_stogir.atomic.ordinary?+0xb8>
    8270:      	add	x6, x0, #0x28
    8274:      	add	x7, x0, #0x50
    8278:      	ldr	x6, [x6, #0x8]
    827c:      	ldr	x7, [x7, #0x8]
    8280:      	cmp	x6, x7
    8284:      	b.ne	0x82b0 <_stogir.atomic.ordinary?+0xa8>
    8288:      	cmp	x4, x6
    828c:      	b.gt	0x838c <_stogir.atomic.ordinary?+0x184>
    8290:      	ldr	x4, [x0, #0x50]
    8294:      	add	x4, x4, x5, lsl #2
    8298:      	ldr	w4, [x4]
    829c:      	sxtw	x4, w4
    82a0:      	cmp	x4, #0x0
    82a4:      	cset	w4, gt
    82a8:      	ubfx	x4, x4, #0, #8
    82ac:      	b	0x8390 <_stogir.atomic.ordinary?+0x188>
    82b0:      	movz	x4, #0x0, lsl #48
    82b4:      	b	0x82c4 <_stogir.atomic.ordinary?+0xbc>
    82b8:      	movz	x4, #0x0, lsl #48
    82bc:      	b	0x82c4 <_stogir.atomic.ordinary?+0xbc>
    82c0:      	movz	x4, #0x0, lsl #48
    82c4:      	cmp	x4, #0x0
    82c8:      	b.eq	0x82fc <_stogir.atomic.ordinary?+0xf4>
    82cc:      	uxtb	w16, w3
    82d0:      	cmp	w16, wzr
    82d4:      	b.eq	0x82e8 <_stogir.atomic.ordinary?+0xe0>
    82d8:      	ldr	x0, [x0]
    82dc:      	add	x0, x0, x1, lsl #4
    82e0:      	ldr	x0, [x0]
    82e4:      	b	0x82f4 <_stogir.atomic.ordinary?+0xec>
    82e8:      	ldr	x0, [x0, #0x28]
    82ec:      	add	x0, x0, x5, lsl #4
    82f0:      	ldr	x0, [x0]
    82f4:      	mov	x1, #0x1                ; =1
    82f8:      	b	0x8304 <_stogir.atomic.ordinary?+0xfc>
    82fc:      	movz	x1, #0x0, lsl #48
    8300:      	movz	x0, #0x0, lsl #48
    8304:      	lsr	w1, w1, #0
    8308:      	lsr	x16, x1, #0
    830c:      	cmp	x16, #0x1
    8310:      	b.eq	0x832c <_stogir.atomic.ordinary?+0x124>
    8314:      	b.lo	0x831c <_stogir.atomic.ordinary?+0x114>
    8318:      	b	0x8330 <_stogir.atomic.ordinary?+0x128>
    831c:      	cmp	x16, #0x0
    8320:      	b.eq	0x8328 <_stogir.atomic.ordinary?+0x120>
    8324:      	b	0x8330 <_stogir.atomic.ordinary?+0x128>
    8328:      	b	0x8334 <_stogir.atomic.ordinary?+0x12c>
    832c:      	b	0x8344 <_stogir.atomic.ordinary?+0x13c>
    8330:      	b	0x8394 <_stogir.atomic.ordinary?+0x18c>
    8334:      	movz	x0, #0x0, lsl #48
    8338:      	b	0x8340 <_stogir.atomic.ordinary?+0x138>
    833c:      	movz	x0, #0x0, lsl #48
    8340:      	ret
    8344:      	sxtw	x2, w2
    8348:      	lsr	w1, w0, #0
    834c:      	ubfx	x1, x1, #8, #8
    8350:      	cmp	x1, x2
    8354:      	b.ne	0x833c <_stogir.atomic.ordinary?+0x134>
    8358:      	uxtb	w0, w0
    835c:      	cmp	x0, #0x46
    8360:      	b.ne	0x8374 <_stogir.atomic.ordinary?+0x16c>
    8364:      	movz	x0, #0x0, lsl #48
    8368:      	b	0x8388 <_stogir.atomic.ordinary?+0x180>
    836c:      	movz	x4, #0x0, lsl #48
    8370:      	b	0x82bc <_stogir.atomic.ordinary?+0xb4>
    8374:      	cmp	x0, #0x48
    8378:      	cset	w0, eq
    837c:      	uxtb	w16, w0
    8380:      	cmp	w16, wzr
    8384:      	cset	x0, eq
    8388:      	b	0x8340 <_stogir.atomic.ordinary?+0x138>
    838c:      	movz	x4, #0x0, lsl #48
    8390:      	b	0x82b4 <_stogir.atomic.ordinary?+0xac>
    8394:      	brk	#0
    8398:      	b	0x8394 <_stogir.atomic.ordinary?+0x18c>

000000000000839c <_stogir.types.scalar-size>:
    839c:      	sxtw	x1, w1
    83a0:      	cmp	x1, #0x4
    83a4:      	b.eq	0x83b8 <_stogir.types.scalar-size+0x1c>
    83a8:      	cmp	x1, #0x8
    83ac:      	b.eq	0x83b8 <_stogir.types.scalar-size+0x1c>
    83b0:      	movn	x1, #0x0, lsl #48
    83b4:      	b	0x83d0 <_stogir.types.scalar-size+0x34>
    83b8:      	sxtw	x0, w0
    83bc:      	cmp	x0, #0x0
    83c0:      	b.ne	0x83d8 <_stogir.types.scalar-size+0x3c>
    83c4:      	movz	x1, #0x0, lsl #48
    83c8:      	b	0x83d0 <_stogir.types.scalar-size+0x34>
    83cc:      	mov	x1, #0x1                ; =1
    83d0:      	mov	x0, x1
    83d4:      	ret
    83d8:      	cmp	x0, #0x1
    83dc:      	b.eq	0x83cc <_stogir.types.scalar-size+0x30>
    83e0:      	cmp	x0, #0x2
    83e4:      	b.eq	0x83cc <_stogir.types.scalar-size+0x30>
    83e8:      	cmp	x0, #0x7
    83ec:      	b.eq	0x83cc <_stogir.types.scalar-size+0x30>
    83f0:      	cmp	x0, #0x8
    83f4:      	b.eq	0x83cc <_stogir.types.scalar-size+0x30>
    83f8:      	cmp	x0, #0x3
    83fc:      	b.eq	0x8448 <_stogir.types.scalar-size+0xac>
    8400:      	cmp	x0, #0x9
    8404:      	b.eq	0x8448 <_stogir.types.scalar-size+0xac>
    8408:      	cmp	x0, #0x4
    840c:      	b.eq	0x8450 <_stogir.types.scalar-size+0xb4>
    8410:      	cmp	x0, #0xa
    8414:      	b.eq	0x8450 <_stogir.types.scalar-size+0xb4>
    8418:      	cmp	x0, #0xd
    841c:      	b.eq	0x8450 <_stogir.types.scalar-size+0xb4>
    8420:      	cmp	x0, #0x5
    8424:      	b.eq	0x8458 <_stogir.types.scalar-size+0xbc>
    8428:      	cmp	x0, #0xb
    842c:      	b.eq	0x8458 <_stogir.types.scalar-size+0xbc>
    8430:      	cmp	x0, #0xc
    8434:      	b.eq	0x8458 <_stogir.types.scalar-size+0xbc>
    8438:      	cmp	x0, #0x6
    843c:      	b.eq	0x8444 <_stogir.types.scalar-size+0xa8>
    8440:      	movn	x1, #0x0, lsl #48
    8444:      	b	0x845c <_stogir.types.scalar-size+0xc0>
    8448:      	mov	x1, #0x2                ; =2
    844c:      	b	0x83d0 <_stogir.types.scalar-size+0x34>
    8450:      	mov	x1, #0x4                ; =4
    8454:      	b	0x844c <_stogir.types.scalar-size+0xb0>
    8458:      	mov	x1, #0x8                ; =8
    845c:      	b	0x8454 <_stogir.types.scalar-size+0xb8>

0000000000008460 <_stogir.terminal.inputs>:
    8460:      	sxtw	x1, w1
    8464:      	cmp	x1, #0x60
    8468:      	cset	w4, eq
    846c:      	uxtb	w16, w4
    8470:      	cmp	w16, wzr
    8474:      	b.ne	0x84a4 <_stogir.terminal.inputs+0x44>
    8478:      	cmp	x1, #0x79
    847c:      	b.eq	0x84a4 <_stogir.terminal.inputs+0x44>
    8480:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008480:  ARM64_RELOC_PAGE21	l_stogir.430
    8484:      	ldr	x16, [x16]
		0000000000008484:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    8488:      	orr	x0, x16, xzr
    848c:      	mov	x1, #0x1                ; =1
    8490:      	mov	x2, #0x25               ; =37
    8494:      	str	x1, [x8]
    8498:      	str	x0, [x8, #0x8]
    849c:      	str	x2, [x8, #0x10]
    84a0:      	ret
    84a4:      	sxtw	x3, w3
    84a8:      	uxtb	w16, w4
    84ac:      	cmp	w16, wzr
    84b0:      	b.eq	0x84bc <_stogir.terminal.inputs+0x5c>
    84b4:      	cmp	x3, #0x0
    84b8:      	b.ne	0x8480 <_stogir.terminal.inputs+0x20>
    84bc:      	sxtw	x2, w2
    84c0:      	cmp	x2, #0x0
    84c4:      	cset	w1, gt
    84c8:      	movz	x16, #0x0, lsl #48
    84cc:      	sub	x4, x16, x2
    84d0:      	sub	x5, x4, #0x1
    84d4:      	uxtb	w16, w1
    84d8:      	cmp	w16, wzr
    84dc:      	b.eq	0x85b0 <_stogir.terminal.inputs+0x150>
    84e0:      	ldr	x4, [x0, #0x8]
    84e4:      	cmp	x2, x4
    84e8:      	b.ge	0x85a8 <_stogir.terminal.inputs+0x148>
    84ec:      	add	x4, x0, #0x78
    84f0:      	ldr	x4, [x4, #0x8]
    84f4:      	cmp	x2, x4
    84f8:      	b.ge	0x8650 <_stogir.terminal.inputs+0x1f0>
    84fc:      	ldr	x4, [x0, #0x78]
    8500:      	add	x4, x4, x2, lsl #2
    8504:      	ldr	w4, [x4]
    8508:      	sxtw	x4, w4
    850c:      	cmp	x4, #0x0
    8510:      	cset	w4, ge
    8514:      	ubfx	x4, x4, #0, #8
    8518:      	b	0x8654 <_stogir.terminal.inputs+0x1f4>
    851c:      	movz	x4, #0x0, lsl #48
    8520:      	movz	x1, #0x0, lsl #48
    8524:      	lsr	w4, w4, #0
    8528:      	lsr	x16, x4, #0
    852c:      	cmp	x16, #0x1
    8530:      	b.eq	0x854c <_stogir.terminal.inputs+0xec>
    8534:      	b.lo	0x853c <_stogir.terminal.inputs+0xdc>
    8538:      	b	0x8550 <_stogir.terminal.inputs+0xf0>
    853c:      	cmp	x16, #0x0
    8540:      	b.eq	0x8548 <_stogir.terminal.inputs+0xe8>
    8544:      	b	0x8550 <_stogir.terminal.inputs+0xf0>
    8548:      	b	0x8554 <_stogir.terminal.inputs+0xf4>
    854c:      	b	0x85f8 <_stogir.terminal.inputs+0x198>
    8550:      	b	0x879c <_stogir.terminal.inputs+0x33c>
    8554:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008554:  ARM64_RELOC_PAGE21	l_stogir.431
    8558:      	ldr	x16, [x16]
		0000000000008558:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    855c:      	orr	x0, x16, xzr
    8560:      	mov	x1, #0x1                ; =1
    8564:      	mov	x2, #0x1d               ; =29
    8568:      	b	0x8494 <_stogir.terminal.inputs+0x34>
    856c:      	ldr	x1, [x0, #0x28]
    8570:      	add	x1, x1, x5, lsl #4
    8574:      	ldr	x1, [x1]
    8578:      	mov	x4, #0x1                ; =1
    857c:      	b	0x8524 <_stogir.terminal.inputs+0xc4>
    8580:      	movz	x4, #0x0, lsl #48
    8584:      	cmp	x4, #0x0
    8588:      	b.eq	0x851c <_stogir.terminal.inputs+0xbc>
    858c:      	uxtb	w16, w1
    8590:      	cmp	w16, wzr
    8594:      	b.eq	0x856c <_stogir.terminal.inputs+0x10c>
    8598:      	ldr	x1, [x0]
    859c:      	add	x1, x1, x2, lsl #4
    85a0:      	ldr	x1, [x1]
    85a4:      	b	0x8578 <_stogir.terminal.inputs+0x118>
    85a8:      	movz	x4, #0x0, lsl #48
    85ac:      	b	0x8584 <_stogir.terminal.inputs+0x124>
    85b0:      	cmp	x2, #0x0
    85b4:      	b.ge	0x8580 <_stogir.terminal.inputs+0x120>
    85b8:      	add	x6, x0, #0x28
    85bc:      	add	x7, x0, #0x50
    85c0:      	ldr	x6, [x6, #0x8]
    85c4:      	ldr	x7, [x7, #0x8]
    85c8:      	cmp	x6, x7
    85cc:      	b.ne	0x8648 <_stogir.terminal.inputs+0x1e8>
    85d0:      	cmp	x4, x6
    85d4:      	b.gt	0x8658 <_stogir.terminal.inputs+0x1f8>
    85d8:      	ldr	x4, [x0, #0x50]
    85dc:      	add	x4, x4, x5, lsl #2
    85e0:      	ldr	w4, [x4]
    85e4:      	sxtw	x4, w4
    85e8:      	cmp	x4, #0x0
    85ec:      	cset	w4, gt
    85f0:      	ubfx	x4, x4, #0, #8
    85f4:      	b	0x865c <_stogir.terminal.inputs+0x1fc>
    85f8:      	cmp	x2, #0x0
    85fc:      	b.le	0x8630 <_stogir.terminal.inputs+0x1d0>
    8600:      	uxtb	w1, w1
    8604:      	cmp	x1, #0x83
    8608:      	cset	w2, lt
    860c:      	uxtb	w16, w2
    8610:      	cmp	w16, wzr
    8614:      	b.eq	0x8660 <_stogir.terminal.inputs+0x200>
    8618:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008618:  ARM64_RELOC_PAGE21	l_stogir.432
    861c:      	ldr	x16, [x16]
		000000000000861c:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    8620:      	orr	x4, x16, xzr
    8624:      	add	x4, x1, x4
    8628:      	ldrb	w4, [x4]
    862c:      	b	0x8664 <_stogir.terminal.inputs+0x204>
    8630:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008630:  ARM64_RELOC_PAGE21	l_stogir.433
    8634:      	ldr	x16, [x16]
		0000000000008634:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    8638:      	orr	x0, x16, xzr
    863c:      	mov	x1, #0x1                ; =1
    8640:      	mov	x2, #0x2c               ; =44
    8644:      	b	0x8568 <_stogir.terminal.inputs+0x108>
    8648:      	movz	x4, #0x0, lsl #48
    864c:      	b	0x8584 <_stogir.terminal.inputs+0x124>
    8650:      	movz	x4, #0x0, lsl #48
    8654:      	b	0x85ac <_stogir.terminal.inputs+0x14c>
    8658:      	movz	x4, #0x0, lsl #48
    865c:      	b	0x864c <_stogir.terminal.inputs+0x1ec>
    8660:      	movz	x4, #0x0, lsl #48
    8664:      	uxtb	w4, w4
    8668:      	and	x4, x4, #0x1
    866c:      	uxtb	w4, w4
    8670:      	cmp	x4, #0x0
    8674:      	b.eq	0x8630 <_stogir.terminal.inputs+0x1d0>
    8678:      	uxtb	w16, w2
    867c:      	cmp	w16, wzr
    8680:      	b.eq	0x869c <_stogir.terminal.inputs+0x23c>
    8684:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008684:  ARM64_RELOC_PAGE21	l_stogir.432
    8688:      	ldr	x16, [x16]
		0000000000008688:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    868c:      	orr	x2, x16, xzr
    8690:      	add	x1, x1, x2
    8694:      	ldrb	w1, [x1]
    8698:      	b	0x86a0 <_stogir.terminal.inputs+0x240>
    869c:      	movz	x1, #0x0, lsl #48
    86a0:      	uxtb	w1, w1
    86a4:      	and	x1, x1, #0x4
    86a8:      	uxtb	w1, w1
    86ac:      	cmp	x1, #0x0
    86b0:      	cset	w1, eq
    86b4:      	uxtb	w16, w1
    86b8:      	cmp	w16, wzr
    86bc:      	cset	x1, eq
    86c0:      	cmp	x1, #0x0
    86c4:      	b.ne	0x8630 <_stogir.terminal.inputs+0x1d0>
    86c8:      	cmp	x3, #0x0
    86cc:      	b.ne	0x86e0 <_stogir.terminal.inputs+0x280>
    86d0:      	movz	x1, #0x0, lsl #48
    86d4:      	movz	x0, #0x0, lsl #48
    86d8:      	movz	x2, #0x0, lsl #48
    86dc:      	b	0x8644 <_stogir.terminal.inputs+0x1e4>
    86e0:      	cmp	x3, #0x0
    86e4:      	cset	w1, gt
    86e8:      	movz	x16, #0x0, lsl #48
    86ec:      	sub	x2, x16, x3
    86f0:      	sub	x4, x2, #0x1
    86f4:      	uxtb	w16, w1
    86f8:      	cmp	w16, wzr
    86fc:      	b.eq	0x8754 <_stogir.terminal.inputs+0x2f4>
    8700:      	ldr	x2, [x0, #0x8]
    8704:      	cmp	x3, x2
    8708:      	b.ge	0x87a4 <_stogir.terminal.inputs+0x344>
    870c:      	add	x2, x0, #0x78
    8710:      	ldr	x2, [x2, #0x8]
    8714:      	cmp	x3, x2
    8718:      	b.ge	0x886c <_stogir.terminal.inputs+0x40c>
    871c:      	ldr	x2, [x0, #0x78]
    8720:      	add	x2, x2, x3, lsl #2
    8724:      	ldr	w2, [x2]
    8728:      	sxtw	x2, w2
    872c:      	cmp	x2, #0x0
    8730:      	cset	w2, ge
    8734:      	ubfx	x2, x2, #0, #8
    8738:      	b	0x8870 <_stogir.terminal.inputs+0x410>
    873c:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		000000000000873c:  ARM64_RELOC_PAGE21	l_stogir.434
    8740:      	ldr	x16, [x16]
		0000000000008740:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    8744:      	orr	x0, x16, xzr
    8748:      	mov	x1, #0x1                ; =1
    874c:      	mov	x2, #0x2e               ; =46
    8750:      	b	0x86dc <_stogir.terminal.inputs+0x27c>
    8754:      	cmp	x3, #0x0
    8758:      	b.ge	0x87ac <_stogir.terminal.inputs+0x34c>
    875c:      	add	x5, x0, #0x28
    8760:      	add	x6, x0, #0x50
    8764:      	ldr	x5, [x5, #0x8]
    8768:      	ldr	x6, [x6, #0x8]
    876c:      	cmp	x5, x6
    8770:      	b.ne	0x8864 <_stogir.terminal.inputs+0x404>
    8774:      	cmp	x2, x5
    8778:      	b.gt	0x8874 <_stogir.terminal.inputs+0x414>
    877c:      	ldr	x2, [x0, #0x50]
    8780:      	add	x2, x2, x4, lsl #2
    8784:      	ldr	w2, [x2]
    8788:      	sxtw	x2, w2
    878c:      	cmp	x2, #0x0
    8790:      	cset	w2, gt
    8794:      	ubfx	x2, x2, #0, #8
    8798:      	b	0x8878 <_stogir.terminal.inputs+0x418>
    879c:      	brk	#0
    87a0:      	b	0x879c <_stogir.terminal.inputs+0x33c>
    87a4:      	movz	x2, #0x0, lsl #48
    87a8:      	b	0x87b0 <_stogir.terminal.inputs+0x350>
    87ac:      	movz	x2, #0x0, lsl #48
    87b0:      	cmp	x2, #0x0
    87b4:      	b.eq	0x87e8 <_stogir.terminal.inputs+0x388>
    87b8:      	uxtb	w16, w1
    87bc:      	cmp	w16, wzr
    87c0:      	b.eq	0x87d4 <_stogir.terminal.inputs+0x374>
    87c4:      	ldr	x0, [x0]
    87c8:      	add	x0, x0, x3, lsl #4
    87cc:      	ldr	x0, [x0]
    87d0:      	b	0x87e0 <_stogir.terminal.inputs+0x380>
    87d4:      	ldr	x0, [x0, #0x28]
    87d8:      	add	x0, x0, x4, lsl #4
    87dc:      	ldr	x0, [x0]
    87e0:      	mov	x1, #0x1                ; =1
    87e4:      	b	0x87f0 <_stogir.terminal.inputs+0x390>
    87e8:      	movz	x1, #0x0, lsl #48
    87ec:      	movz	x0, #0x0, lsl #48
    87f0:      	lsr	w1, w1, #0
    87f4:      	lsr	x16, x1, #0
    87f8:      	cmp	x16, #0x1
    87fc:      	b.eq	0x8818 <_stogir.terminal.inputs+0x3b8>
    8800:      	b.lo	0x8808 <_stogir.terminal.inputs+0x3a8>
    8804:      	b	0x881c <_stogir.terminal.inputs+0x3bc>
    8808:      	cmp	x16, #0x0
    880c:      	b.eq	0x8814 <_stogir.terminal.inputs+0x3b4>
    8810:      	b	0x881c <_stogir.terminal.inputs+0x3bc>
    8814:      	b	0x8820 <_stogir.terminal.inputs+0x3c0>
    8818:      	b	0x8838 <_stogir.terminal.inputs+0x3d8>
    881c:      	b	0x88b8 <_stogir.terminal.inputs+0x458>
    8820:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008820:  ARM64_RELOC_PAGE21	l_stogir.435
    8824:      	ldr	x16, [x16]
		0000000000008824:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    8828:      	orr	x0, x16, xzr
    882c:      	mov	x1, #0x1                ; =1
    8830:      	mov	x2, #0x1d               ; =29
    8834:      	b	0x8750 <_stogir.terminal.inputs+0x2f0>
    8838:      	cmp	x3, #0x0
    883c:      	b.le	0x873c <_stogir.terminal.inputs+0x2dc>
    8840:      	uxtb	w0, w0
    8844:      	cmp	x0, #0x83
    8848:      	b.ge	0x887c <_stogir.terminal.inputs+0x41c>
    884c:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		000000000000884c:  ARM64_RELOC_PAGE21	l_stogir.432
    8850:      	ldr	x16, [x16]
		0000000000008850:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    8854:      	orr	x1, x16, xzr
    8858:      	add	x0, x0, x1
    885c:      	ldrb	w0, [x0]
    8860:      	b	0x8880 <_stogir.terminal.inputs+0x420>
    8864:      	movz	x2, #0x0, lsl #48
    8868:      	b	0x87b0 <_stogir.terminal.inputs+0x350>
    886c:      	movz	x2, #0x0, lsl #48
    8870:      	b	0x87a8 <_stogir.terminal.inputs+0x348>
    8874:      	movz	x2, #0x0, lsl #48
    8878:      	b	0x8868 <_stogir.terminal.inputs+0x408>
    887c:      	movz	x0, #0x0, lsl #48
    8880:      	uxtb	w0, w0
    8884:      	and	x0, x0, #0x8
    8888:      	uxtb	w0, w0
    888c:      	cmp	x0, #0x0
    8890:      	cset	w0, eq
    8894:      	uxtb	w16, w0
    8898:      	cmp	w16, wzr
    889c:      	cset	x0, eq
    88a0:      	cmp	x0, #0x0
    88a4:      	b.eq	0x873c <_stogir.terminal.inputs+0x2dc>
    88a8:      	and	x0, x3, #0xffffffff
    88ac:      	movz	x1, #0x0, lsl #48
    88b0:      	movz	x2, #0x0, lsl #48
    88b4:      	b	0x8750 <_stogir.terminal.inputs+0x2f0>
    88b8:      	brk	#0
    88bc:      	b	0x88b8 <_stogir.terminal.inputs+0x458>

00000000000088c0 <_stogir.switch.switch-inputs>:
    88c0:      	sxtw	x1, w1
    88c4:      	cmp	x1, #0x0
    88c8:      	cset	w3, gt
    88cc:      	movz	x16, #0x0, lsl #48
    88d0:      	sub	x4, x16, x1
    88d4:      	sub	x5, x4, #0x1
    88d8:      	uxtb	w16, w3
    88dc:      	cmp	w16, wzr
    88e0:      	b.eq	0x8920 <_stogir.switch.switch-inputs+0x60>
    88e4:      	ldr	x4, [x0, #0x8]
    88e8:      	cmp	x1, x4
    88ec:      	b.ge	0x8988 <_stogir.switch.switch-inputs+0xc8>
    88f0:      	add	x4, x0, #0x78
    88f4:      	ldr	x4, [x4, #0x8]
    88f8:      	cmp	x1, x4
    88fc:      	b.ge	0x8a60 <_stogir.switch.switch-inputs+0x1a0>
    8900:      	ldr	x4, [x0, #0x78]
    8904:      	add	x4, x4, x1, lsl #2
    8908:      	ldr	w4, [x4]
    890c:      	sxtw	x4, w4
    8910:      	cmp	x4, #0x0
    8914:      	cset	w4, ge
    8918:      	ubfx	x4, x4, #0, #8
    891c:      	b	0x8a64 <_stogir.switch.switch-inputs+0x1a4>
    8920:      	cmp	x1, #0x0
    8924:      	b.ge	0x8990 <_stogir.switch.switch-inputs+0xd0>
    8928:      	add	x6, x0, #0x28
    892c:      	add	x7, x0, #0x50
    8930:      	ldr	x6, [x6, #0x8]
    8934:      	ldr	x7, [x7, #0x8]
    8938:      	cmp	x6, x7
    893c:      	b.ne	0x8968 <_stogir.switch.switch-inputs+0xa8>
    8940:      	cmp	x4, x6
    8944:      	b.gt	0x8a68 <_stogir.switch.switch-inputs+0x1a8>
    8948:      	ldr	x4, [x0, #0x50]
    894c:      	add	x4, x4, x5, lsl #2
    8950:      	ldr	w4, [x4]
    8954:      	sxtw	x4, w4
    8958:      	cmp	x4, #0x0
    895c:      	cset	w4, gt
    8960:      	ubfx	x4, x4, #0, #8
    8964:      	b	0x8a6c <_stogir.switch.switch-inputs+0x1ac>
    8968:      	movz	x4, #0x0, lsl #48
    896c:      	b	0x8994 <_stogir.switch.switch-inputs+0xd4>
    8970:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008970:  ARM64_RELOC_PAGE21	l_stogir.436
    8974:      	ldr	x16, [x16]
		0000000000008974:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    8978:      	orr	x0, x16, xzr
    897c:      	mov	x1, #0x1                ; =1
    8980:      	mov	x2, #0x16               ; =22
    8984:      	b	0x8a18 <_stogir.switch.switch-inputs+0x158>
    8988:      	movz	x4, #0x0, lsl #48
    898c:      	b	0x8994 <_stogir.switch.switch-inputs+0xd4>
    8990:      	movz	x4, #0x0, lsl #48
    8994:      	cmp	x4, #0x0
    8998:      	b.eq	0x89cc <_stogir.switch.switch-inputs+0x10c>
    899c:      	uxtb	w16, w3
    89a0:      	cmp	w16, wzr
    89a4:      	b.eq	0x89b8 <_stogir.switch.switch-inputs+0xf8>
    89a8:      	ldr	x3, [x0]
    89ac:      	add	x3, x3, x1, lsl #4
    89b0:      	ldr	x3, [x3]
    89b4:      	b	0x89c4 <_stogir.switch.switch-inputs+0x104>
    89b8:      	ldr	x3, [x0, #0x28]
    89bc:      	add	x3, x3, x5, lsl #4
    89c0:      	ldr	x3, [x3]
    89c4:      	mov	x4, #0x1                ; =1
    89c8:      	b	0x89d4 <_stogir.switch.switch-inputs+0x114>
    89cc:      	movz	x4, #0x0, lsl #48
    89d0:      	movz	x3, #0x0, lsl #48
    89d4:      	lsr	w4, w4, #0
    89d8:      	lsr	x16, x4, #0
    89dc:      	cmp	x16, #0x1
    89e0:      	b.eq	0x89fc <_stogir.switch.switch-inputs+0x13c>
    89e4:      	b.lo	0x89ec <_stogir.switch.switch-inputs+0x12c>
    89e8:      	b	0x8a00 <_stogir.switch.switch-inputs+0x140>
    89ec:      	cmp	x16, #0x0
    89f0:      	b.eq	0x89f8 <_stogir.switch.switch-inputs+0x138>
    89f4:      	b	0x8a00 <_stogir.switch.switch-inputs+0x140>
    89f8:      	b	0x8a04 <_stogir.switch.switch-inputs+0x144>
    89fc:      	b	0x8a28 <_stogir.switch.switch-inputs+0x168>
    8a00:      	b	0x8c70 <_stogir.switch.switch-inputs+0x3b0>
    8a04:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008a04:  ARM64_RELOC_PAGE21	l_stogir.437
    8a08:      	ldr	x16, [x16]
		0000000000008a08:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    8a0c:      	orr	x0, x16, xzr
    8a10:      	mov	x1, #0x1                ; =1
    8a14:      	mov	x2, #0x16               ; =22
    8a18:      	str	x1, [x8]
    8a1c:      	str	x0, [x8, #0x8]
    8a20:      	str	x2, [x8, #0x10]
    8a24:      	ret
    8a28:      	cmp	x1, #0x0
    8a2c:      	b.le	0x8970 <_stogir.switch.switch-inputs+0xb0>
    8a30:      	uxtb	w3, w3
    8a34:      	cmp	x3, #0x83
    8a38:      	cset	w1, lt
    8a3c:      	uxtb	w16, w1
    8a40:      	cmp	w16, wzr
    8a44:      	b.eq	0x8a70 <_stogir.switch.switch-inputs+0x1b0>
    8a48:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008a48:  ARM64_RELOC_PAGE21	l_stogir.438
    8a4c:      	ldr	x16, [x16]
		0000000000008a4c:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    8a50:      	orr	x4, x16, xzr
    8a54:      	add	x4, x3, x4
    8a58:      	ldrb	w4, [x4]
    8a5c:      	b	0x8a74 <_stogir.switch.switch-inputs+0x1b4>
    8a60:      	movz	x4, #0x0, lsl #48
    8a64:      	b	0x898c <_stogir.switch.switch-inputs+0xcc>
    8a68:      	movz	x4, #0x0, lsl #48
    8a6c:      	b	0x896c <_stogir.switch.switch-inputs+0xac>
    8a70:      	movz	x4, #0x0, lsl #48
    8a74:      	uxtb	w4, w4
    8a78:      	and	x4, x4, #0x1
    8a7c:      	uxtb	w4, w4
    8a80:      	cmp	x4, #0x0
    8a84:      	b.eq	0x8970 <_stogir.switch.switch-inputs+0xb0>
    8a88:      	uxtb	w16, w1
    8a8c:      	cmp	w16, wzr
    8a90:      	b.eq	0x8aac <_stogir.switch.switch-inputs+0x1ec>
    8a94:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008a94:  ARM64_RELOC_PAGE21	l_stogir.438
    8a98:      	ldr	x16, [x16]
		0000000000008a98:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    8a9c:      	orr	x1, x16, xzr
    8aa0:      	add	x1, x3, x1
    8aa4:      	ldrb	w1, [x1]
    8aa8:      	b	0x8ab0 <_stogir.switch.switch-inputs+0x1f0>
    8aac:      	movz	x1, #0x0, lsl #48
    8ab0:      	uxtb	w1, w1
    8ab4:      	and	x1, x1, #0x4
    8ab8:      	uxtb	w1, w1
    8abc:      	cmp	x1, #0x0
    8ac0:      	cset	w1, eq
    8ac4:      	uxtb	w16, w1
    8ac8:      	cmp	w16, wzr
    8acc:      	cset	x1, eq
    8ad0:      	cmp	x1, #0x0
    8ad4:      	b.ne	0x8970 <_stogir.switch.switch-inputs+0xb0>
    8ad8:      	sxtw	x2, w2
    8adc:      	cmp	x2, #0x0
    8ae0:      	cset	w1, gt
    8ae4:      	movz	x16, #0x0, lsl #48
    8ae8:      	sub	x3, x16, x2
    8aec:      	sub	x4, x3, #0x1
    8af0:      	uxtb	w16, w1
    8af4:      	cmp	w16, wzr
    8af8:      	b.eq	0x8b50 <_stogir.switch.switch-inputs+0x290>
    8afc:      	ldr	x3, [x0, #0x8]
    8b00:      	cmp	x2, x3
    8b04:      	b.ge	0x8b98 <_stogir.switch.switch-inputs+0x2d8>
    8b08:      	add	x3, x0, #0x78
    8b0c:      	ldr	x3, [x3, #0x8]
    8b10:      	cmp	x2, x3
    8b14:      	b.ge	0x8c68 <_stogir.switch.switch-inputs+0x3a8>
    8b18:      	ldr	x3, [x0, #0x78]
    8b1c:      	add	x3, x3, x2, lsl #2
    8b20:      	ldr	w3, [x3]
    8b24:      	sxtw	x3, w3
    8b28:      	cmp	x3, #0x0
    8b2c:      	cset	w3, ge
    8b30:      	ubfx	x3, x3, #0, #8
    8b34:      	b	0x8c6c <_stogir.switch.switch-inputs+0x3ac>
    8b38:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008b38:  ARM64_RELOC_PAGE21	l_stogir.439
    8b3c:      	ldr	x16, [x16]
		0000000000008b3c:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    8b40:      	orr	x0, x16, xzr
    8b44:      	mov	x1, #0x1                ; =1
    8b48:      	mov	x2, #0x20               ; =32
    8b4c:      	b	0x8984 <_stogir.switch.switch-inputs+0xc4>
    8b50:      	cmp	x2, #0x0
    8b54:      	b.ge	0x8ba0 <_stogir.switch.switch-inputs+0x2e0>
    8b58:      	add	x5, x0, #0x28
    8b5c:      	add	x6, x0, #0x50
    8b60:      	ldr	x5, [x5, #0x8]
    8b64:      	ldr	x6, [x6, #0x8]
    8b68:      	cmp	x5, x6
    8b6c:      	b.ne	0x8c60 <_stogir.switch.switch-inputs+0x3a0>
    8b70:      	cmp	x3, x5
    8b74:      	b.gt	0x8c78 <_stogir.switch.switch-inputs+0x3b8>
    8b78:      	ldr	x3, [x0, #0x50]
    8b7c:      	add	x3, x3, x4, lsl #2
    8b80:      	ldr	w3, [x3]
    8b84:      	sxtw	x3, w3
    8b88:      	cmp	x3, #0x0
    8b8c:      	cset	w3, gt
    8b90:      	ubfx	x3, x3, #0, #8
    8b94:      	b	0x8c7c <_stogir.switch.switch-inputs+0x3bc>
    8b98:      	movz	x3, #0x0, lsl #48
    8b9c:      	b	0x8ba4 <_stogir.switch.switch-inputs+0x2e4>
    8ba0:      	movz	x3, #0x0, lsl #48
    8ba4:      	cmp	x3, #0x0
    8ba8:      	b.eq	0x8bdc <_stogir.switch.switch-inputs+0x31c>
    8bac:      	uxtb	w16, w1
    8bb0:      	cmp	w16, wzr
    8bb4:      	b.eq	0x8bc8 <_stogir.switch.switch-inputs+0x308>
    8bb8:      	ldr	x0, [x0]
    8bbc:      	add	x0, x0, x2, lsl #4
    8bc0:      	ldr	x0, [x0]
    8bc4:      	b	0x8bd4 <_stogir.switch.switch-inputs+0x314>
    8bc8:      	ldr	x0, [x0, #0x28]
    8bcc:      	add	x0, x0, x4, lsl #4
    8bd0:      	ldr	x0, [x0]
    8bd4:      	mov	x1, #0x1                ; =1
    8bd8:      	b	0x8be4 <_stogir.switch.switch-inputs+0x324>
    8bdc:      	movz	x1, #0x0, lsl #48
    8be0:      	movz	x0, #0x0, lsl #48
    8be4:      	lsr	w1, w1, #0
    8be8:      	lsr	x16, x1, #0
    8bec:      	cmp	x16, #0x1
    8bf0:      	b.eq	0x8c0c <_stogir.switch.switch-inputs+0x34c>
    8bf4:      	b.lo	0x8bfc <_stogir.switch.switch-inputs+0x33c>
    8bf8:      	b	0x8c10 <_stogir.switch.switch-inputs+0x350>
    8bfc:      	cmp	x16, #0x0
    8c00:      	b.eq	0x8c08 <_stogir.switch.switch-inputs+0x348>
    8c04:      	b	0x8c10 <_stogir.switch.switch-inputs+0x350>
    8c08:      	b	0x8c14 <_stogir.switch.switch-inputs+0x354>
    8c0c:      	b	0x8c2c <_stogir.switch.switch-inputs+0x36c>
    8c10:      	b	0x8c80 <_stogir.switch.switch-inputs+0x3c0>
    8c14:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008c14:  ARM64_RELOC_PAGE21	l_stogir.440
    8c18:      	ldr	x16, [x16]
		0000000000008c18:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    8c1c:      	orr	x0, x16, xzr
    8c20:      	mov	x1, #0x1                ; =1
    8c24:      	mov	x2, #0x17               ; =23
    8c28:      	b	0x8b4c <_stogir.switch.switch-inputs+0x28c>
    8c2c:      	lsr	w1, w0, #0
    8c30:      	ubfx	x1, x1, #8, #8
    8c34:      	cmp	x1, #0x1
    8c38:      	b.lt	0x8b38 <_stogir.switch.switch-inputs+0x278>
    8c3c:      	cmp	x1, #0xb
    8c40:      	b.gt	0x8b38 <_stogir.switch.switch-inputs+0x278>
    8c44:      	uxtb	w0, w0
    8c48:      	cmp	x0, #0x48
    8c4c:      	b.eq	0x8b38 <_stogir.switch.switch-inputs+0x278>
    8c50:      	and	x0, x1, #0xffffffff
    8c54:      	movz	x1, #0x0, lsl #48
    8c58:      	movz	x2, #0x0, lsl #48
    8c5c:      	b	0x8b4c <_stogir.switch.switch-inputs+0x28c>
    8c60:      	movz	x3, #0x0, lsl #48
    8c64:      	b	0x8ba4 <_stogir.switch.switch-inputs+0x2e4>
    8c68:      	movz	x3, #0x0, lsl #48
    8c6c:      	b	0x8b9c <_stogir.switch.switch-inputs+0x2dc>
    8c70:      	brk	#0
    8c74:      	b	0x8c70 <_stogir.switch.switch-inputs+0x3b0>
    8c78:      	movz	x3, #0x0, lsl #48
    8c7c:      	b	0x8c64 <_stogir.switch.switch-inputs+0x3a4>
    8c80:      	brk	#0
    8c84:      	b	0x8c80 <_stogir.switch.switch-inputs+0x3c0>

0000000000008c88 <_stogir.switch.case-inputs>:
    8c88:      	sub	sp, sp, #0xb0
    8c8c:      	str	x29, [sp]
    8c90:      	str	x30, [sp, #0x8]
    8c94:      	mov	x29, sp
    8c98:      	str	x19, [sp, #0x70]
    8c9c:      	str	x20, [sp, #0x78]
    8ca0:      	str	x21, [sp, #0x80]
    8ca4:      	str	x22, [sp, #0x88]
    8ca8:      	str	x23, [sp, #0x90]
    8cac:      	str	x24, [sp, #0x98]
    8cb0:      	str	x25, [sp, #0xa0]
    8cb4:      	str	x26, [sp, #0xa8]
    8cb8:      	sxtw	x2, w2
    8cbc:      	lsl	x5, x2, #2
    8cc0:      	cmp	x2, #0x0
    8cc4:      	cset	w6, gt
    8cc8:      	movz	x16, #0x0, lsl #48
    8ccc:      	sub	x7, x16, x2
    8cd0:      	sub	x9, x7, #0x1
    8cd4:      	uxtb	w16, w6
    8cd8:      	cmp	w16, wzr
    8cdc:      	b.eq	0x8d1c <_stogir.switch.case-inputs+0x94>
    8ce0:      	ldr	x7, [x0, #0x8]
    8ce4:      	cmp	x2, x7
    8ce8:      	b.ge	0x8d6c <_stogir.switch.case-inputs+0xe4>
    8cec:      	add	x7, x0, #0x78
    8cf0:      	ldr	x7, [x7, #0x8]
    8cf4:      	cmp	x2, x7
    8cf8:      	b.ge	0x8e6c <_stogir.switch.case-inputs+0x1e4>
    8cfc:      	ldr	x7, [x0, #0x78]
    8d00:      	add	x7, x5, x7
    8d04:      	ldr	w7, [x7]
    8d08:      	sxtw	x7, w7
    8d0c:      	cmp	x7, #0x0
    8d10:      	cset	w7, ge
    8d14:      	ubfx	x7, x7, #0, #8
    8d18:      	b	0x8e70 <_stogir.switch.case-inputs+0x1e8>
    8d1c:      	cmp	x2, #0x0
    8d20:      	b.ge	0x8d74 <_stogir.switch.case-inputs+0xec>
    8d24:      	add	x10, x0, #0x28
    8d28:      	add	x11, x0, #0x50
    8d2c:      	ldr	x10, [x10, #0x8]
    8d30:      	ldr	x11, [x11, #0x8]
    8d34:      	cmp	x10, x11
    8d38:      	b.ne	0x8d64 <_stogir.switch.case-inputs+0xdc>
    8d3c:      	cmp	x7, x10
    8d40:      	b.gt	0x8f3c <_stogir.switch.case-inputs+0x2b4>
    8d44:      	ldr	x7, [x0, #0x50]
    8d48:      	add	x7, x7, x9, lsl #2
    8d4c:      	ldr	w7, [x7]
    8d50:      	sxtw	x7, w7
    8d54:      	cmp	x7, #0x0
    8d58:      	cset	w7, gt
    8d5c:      	ubfx	x7, x7, #0, #8
    8d60:      	b	0x8f40 <_stogir.switch.case-inputs+0x2b8>
    8d64:      	movz	x7, #0x0, lsl #48
    8d68:      	b	0x8d78 <_stogir.switch.case-inputs+0xf0>
    8d6c:      	movz	x7, #0x0, lsl #48
    8d70:      	b	0x8d78 <_stogir.switch.case-inputs+0xf0>
    8d74:      	movz	x7, #0x0, lsl #48
    8d78:      	cmp	x7, #0x0
    8d7c:      	b.eq	0x8db8 <_stogir.switch.case-inputs+0x130>
    8d80:      	uxtb	w16, w6
    8d84:      	cmp	w16, wzr
    8d88:      	b.eq	0x8da0 <_stogir.switch.case-inputs+0x118>
    8d8c:      	ldr	x6, [x0]
    8d90:      	add	x6, x6, x2, lsl #4
    8d94:      	ldr	x7, [x6]
    8d98:      	ldr	x6, [x6, #0x8]
    8d9c:      	b	0x8db0 <_stogir.switch.case-inputs+0x128>
    8da0:      	ldr	x6, [x0, #0x28]
    8da4:      	add	x6, x6, x9, lsl #4
    8da8:      	ldr	x7, [x6]
    8dac:      	ldr	x6, [x6, #0x8]
    8db0:      	mov	x9, #0x1                ; =1
    8db4:      	b	0x8dc4 <_stogir.switch.case-inputs+0x13c>
    8db8:      	movz	x9, #0x0, lsl #48
    8dbc:      	movz	x7, #0x0, lsl #48
    8dc0:      	movz	x6, #0x0, lsl #48
    8dc4:      	lsr	w9, w9, #0
    8dc8:      	lsr	x16, x9, #0
    8dcc:      	cmp	x16, #0x1
    8dd0:      	b.eq	0x8dec <_stogir.switch.case-inputs+0x164>
    8dd4:      	b.lo	0x8ddc <_stogir.switch.case-inputs+0x154>
    8dd8:      	b	0x8df0 <_stogir.switch.case-inputs+0x168>
    8ddc:      	cmp	x16, #0x0
    8de0:      	b.eq	0x8de8 <_stogir.switch.case-inputs+0x160>
    8de4:      	b	0x8df0 <_stogir.switch.case-inputs+0x168>
    8de8:      	b	0x8df4 <_stogir.switch.case-inputs+0x16c>
    8dec:      	b	0x8e48 <_stogir.switch.case-inputs+0x1c0>
    8df0:      	b	0x8f44 <_stogir.switch.case-inputs+0x2bc>
    8df4:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008df4:  ARM64_RELOC_PAGE21	l_stogir.441
    8df8:      	ldr	x16, [x16]
		0000000000008df8:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    8dfc:      	orr	x19, x16, xzr
    8e00:      	mov	x21, x8
    8e04:      	mov	x1, #0x1                ; =1
    8e08:      	mov	x0, #0x1a               ; =26
    8e0c:      	str	x1, [x21]
    8e10:      	str	x19, [x21, #0x8]
    8e14:      	str	x0, [x21, #0x10]
    8e18:      	ldr	x19, [sp, #0x70]
    8e1c:      	ldr	x20, [sp, #0x78]
    8e20:      	ldr	x21, [sp, #0x80]
    8e24:      	ldr	x22, [sp, #0x88]
    8e28:      	ldr	x23, [sp, #0x90]
    8e2c:      	ldr	x24, [sp, #0x98]
    8e30:      	ldr	x25, [sp, #0xa0]
    8e34:      	ldr	x26, [sp, #0xa8]
    8e38:      	ldr	x29, [sp]
    8e3c:      	ldr	x30, [sp, #0x8]
    8e40:      	add	sp, sp, #0xb0
    8e44:      	ret
    8e48:      	cmp	x2, #0x0
    8e4c:      	b.gt	0x8e74 <_stogir.switch.case-inputs+0x1ec>
    8e50:      	mov	x21, x8
    8e54:      	adrp	x16, 0x8000 <_stogir.checked.projection+0x18>
		0000000000008e54:  ARM64_RELOC_PAGE21	l_stogir.442
    8e58:      	ldr	x16, [x16]
		0000000000008e58:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8e5c:      	orr	x19, x16, xzr
    8e60:      	mov	x1, #0x1                ; =1
    8e64:      	mov	x0, #0x1f               ; =31
    8e68:      	b	0x8e0c <_stogir.switch.case-inputs+0x184>
    8e6c:      	movz	x7, #0x0, lsl #48
    8e70:      	b	0x8d70 <_stogir.switch.case-inputs+0xe8>
    8e74:      	uxtb	w2, w7
    8e78:      	cmp	x2, #0x75
    8e7c:      	b.ne	0x90b8 <_stogir.switch.case-inputs+0x430>
    8e80:      	lsr	w2, w7, #0
    8e84:      	ubfx	x2, x2, #8, #8
    8e88:      	cmp	x2, #0x0
    8e8c:      	b.ne	0x90c0 <_stogir.switch.case-inputs+0x438>
    8e90:      	ldr	x2, [x0, #0x78]
    8e94:      	add	x2, x5, x2
    8e98:      	ldr	w2, [x2]
    8e9c:      	sxtw	x2, w2
    8ea0:      	cmp	x2, #0x2
    8ea4:      	b.ne	0x90c8 <_stogir.switch.case-inputs+0x440>
    8ea8:      	sxtw	x20, w1
    8eac:      	cmp	x20, #0x6d
    8eb0:      	b.lt	0x90d0 <_stogir.switch.case-inputs+0x448>
    8eb4:      	cmp	x20, #0x6f
    8eb8:      	b.gt	0x90d8 <_stogir.switch.case-inputs+0x450>
    8ebc:      	add	x16, sp, #0x10
    8ec0:      	orr	x19, x16, xzr
    8ec4:      	lsr	w6, w6, #0
    8ec8:      	lsr	x1, x7, #32
    8ecc:      	lsr	w6, w6, #0
    8ed0:      	lsr	w1, w1, #0
    8ed4:      	mov	w2, w6
    8ed8:      	mov	x21, x8
    8edc:      	add	x8, sp, #0x10
    8ee0:      	mov	x22, x0
    8ee4:      	mov	w23, w3
    8ee8:      	mov	w24, w4
    8eec:      	bl	0x8eec <_stogir.switch.case-inputs+0x264>
		0000000000008eec:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    8ef0:      	add	x16, sp, #0x10
    8ef4:      	ldr	w0, [x16]
    8ef8:      	lsr	x16, x0, #0
    8efc:      	cmp	x16, #0x1
    8f00:      	b.eq	0x8f1c <_stogir.switch.case-inputs+0x294>
    8f04:      	b.lo	0x8f0c <_stogir.switch.case-inputs+0x284>
    8f08:      	b	0x8f20 <_stogir.switch.case-inputs+0x298>
    8f0c:      	cmp	x16, #0x0
    8f10:      	b.eq	0x8f18 <_stogir.switch.case-inputs+0x290>
    8f14:      	b	0x8f20 <_stogir.switch.case-inputs+0x298>
    8f18:      	b	0x8f4c <_stogir.switch.case-inputs+0x2c4>
    8f1c:      	b	0x8f24 <_stogir.switch.case-inputs+0x29c>
    8f20:      	b	0x90a0 <_stogir.switch.case-inputs+0x418>
    8f24:      	add	x0, x19, #0x8
    8f28:      	add	x16, sp, #0x10
    8f2c:      	ldr	x19, [x16, #0x8]
    8f30:      	ldr	x0, [x0, #0x8]
    8f34:      	mov	x1, #0x1                ; =1
    8f38:      	b	0x8e68 <_stogir.switch.case-inputs+0x1e0>
    8f3c:      	movz	x7, #0x0, lsl #48
    8f40:      	b	0x8d68 <_stogir.switch.case-inputs+0xe0>
    8f44:      	brk	#0
    8f48:      	b	0x8f44 <_stogir.switch.case-inputs+0x2bc>
    8f4c:      	add	x16, sp, #0x10
    8f50:      	ldr	w25, [x16, #0x8]
    8f54:      	sxtw	x0, w25
    8f58:      	and	x19, x0, #0xffffffff
    8f5c:      	cmp	x20, #0x6f
    8f60:      	b.ne	0x8f70 <_stogir.switch.case-inputs+0x2e8>
    8f64:      	movz	x1, #0x0, lsl #48
    8f68:      	movz	x0, #0x0, lsl #48
    8f6c:      	b	0x8f38 <_stogir.switch.case-inputs+0x2b0>
    8f70:      	add	x16, sp, #0x30
    8f74:      	orr	x26, x16, xzr
    8f78:      	lsr	w23, w23, #0
    8f7c:      	lsr	w25, w25, #0
    8f80:      	add	x8, sp, #0x30
    8f84:      	mov	x0, x22
    8f88:      	mov	w1, w23
    8f8c:      	mov	w2, w25
    8f90:      	bl	0x8f90 <_stogir.switch.case-inputs+0x308>
		0000000000008f90:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    8f94:      	add	x16, sp, #0x30
    8f98:      	ldr	w0, [x16]
    8f9c:      	lsr	x16, x0, #0
    8fa0:      	cmp	x16, #0x1
    8fa4:      	b.eq	0x8fc0 <_stogir.switch.case-inputs+0x338>
    8fa8:      	b.lo	0x8fb0 <_stogir.switch.case-inputs+0x328>
    8fac:      	b	0x8fc4 <_stogir.switch.case-inputs+0x33c>
    8fb0:      	cmp	x16, #0x0
    8fb4:      	b.eq	0x8fbc <_stogir.switch.case-inputs+0x334>
    8fb8:      	b	0x8fc4 <_stogir.switch.case-inputs+0x33c>
    8fbc:      	b	0x8fe0 <_stogir.switch.case-inputs+0x358>
    8fc0:      	b	0x8fc8 <_stogir.switch.case-inputs+0x340>
    8fc4:      	b	0x90a8 <_stogir.switch.case-inputs+0x420>
    8fc8:      	add	x0, x26, #0x8
    8fcc:      	add	x16, sp, #0x30
    8fd0:      	ldr	x19, [x16, #0x8]
    8fd4:      	ldr	x0, [x0, #0x8]
    8fd8:      	mov	x1, #0x1                ; =1
    8fdc:      	b	0x8f6c <_stogir.switch.case-inputs+0x2e4>
    8fe0:      	add	x16, sp, #0x30
    8fe4:      	ldr	x26, [x16, #0x8]
    8fe8:      	cmp	x20, #0x6d
    8fec:      	b.ne	0x9004 <_stogir.switch.case-inputs+0x37c>
    8ff0:      	sxtw	x24, w23
    8ff4:      	b	0x9008 <_stogir.switch.case-inputs+0x380>
    8ff8:      	movz	x1, #0x0, lsl #48
    8ffc:      	movz	x0, #0x0, lsl #48
    9000:      	b	0x8fdc <_stogir.switch.case-inputs+0x354>
    9004:      	sxtw	x24, w24
    9008:      	add	x16, sp, #0x50
    900c:      	orr	x20, x16, xzr
    9010:      	lsr	w25, w25, #0
    9014:      	lsr	w24, w24, #0
    9018:      	add	x8, sp, #0x50
    901c:      	mov	x0, x22
    9020:      	mov	w1, w24
    9024:      	mov	w2, w25
    9028:      	bl	0x9028 <_stogir.switch.case-inputs+0x3a0>
		0000000000009028:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    902c:      	add	x16, sp, #0x50
    9030:      	ldr	w0, [x16]
    9034:      	lsr	x16, x0, #0
    9038:      	cmp	x16, #0x1
    903c:      	b.eq	0x9058 <_stogir.switch.case-inputs+0x3d0>
    9040:      	b.lo	0x9048 <_stogir.switch.case-inputs+0x3c0>
    9044:      	b	0x905c <_stogir.switch.case-inputs+0x3d4>
    9048:      	cmp	x16, #0x0
    904c:      	b.eq	0x9054 <_stogir.switch.case-inputs+0x3cc>
    9050:      	b	0x905c <_stogir.switch.case-inputs+0x3d4>
    9054:      	b	0x9078 <_stogir.switch.case-inputs+0x3f0>
    9058:      	b	0x9060 <_stogir.switch.case-inputs+0x3d8>
    905c:      	b	0x90b0 <_stogir.switch.case-inputs+0x428>
    9060:      	add	x0, x20, #0x8
    9064:      	add	x16, sp, #0x50
    9068:      	ldr	x19, [x16, #0x8]
    906c:      	ldr	x0, [x0, #0x8]
    9070:      	mov	x1, #0x1                ; =1
    9074:      	b	0x9000 <_stogir.switch.case-inputs+0x378>
    9078:      	add	x16, sp, #0x50
    907c:      	ldr	x0, [x16, #0x8]
    9080:      	cmp	x26, x0
    9084:      	b.ls	0x8ff8 <_stogir.switch.case-inputs+0x370>
    9088:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009088:  ARM64_RELOC_PAGE21	l_stogir.443
    908c:      	ldr	x16, [x16]
		000000000000908c:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    9090:      	orr	x19, x16, xzr
    9094:      	mov	x1, #0x1                ; =1
    9098:      	mov	x0, #0x1a               ; =26
    909c:      	b	0x9000 <_stogir.switch.case-inputs+0x378>
    90a0:      	brk	#0
    90a4:      	b	0x90a0 <_stogir.switch.case-inputs+0x418>
    90a8:      	brk	#0
    90ac:      	b	0x90a8 <_stogir.switch.case-inputs+0x420>
    90b0:      	brk	#0
    90b4:      	b	0x90b0 <_stogir.switch.case-inputs+0x428>
    90b8:      	mov	x21, x8
    90bc:      	b	0x8e54 <_stogir.switch.case-inputs+0x1cc>
    90c0:      	mov	x21, x8
    90c4:      	b	0x8e54 <_stogir.switch.case-inputs+0x1cc>
    90c8:      	mov	x21, x8
    90cc:      	b	0x8e54 <_stogir.switch.case-inputs+0x1cc>
    90d0:      	mov	x21, x8
    90d4:      	b	0x8e54 <_stogir.switch.case-inputs+0x1cc>
    90d8:      	mov	x21, x8
    90dc:      	b	0x8e54 <_stogir.switch.case-inputs+0x1cc>

00000000000090e0 <_stogir.stack.valid-frame-object-inputs?>:
    90e0:      	sub	sp, sp, #0x50
    90e4:      	str	x29, [sp]
    90e8:      	str	x30, [sp, #0x8]
    90ec:      	mov	x29, sp
    90f0:      	str	x19, [sp, #0x30]
    90f4:      	str	x20, [sp, #0x38]
    90f8:      	str	x21, [sp, #0x40]
    90fc:      	add	x3, x0, #0x78
    9100:      	add	x4, x0, #0x28
    9104:      	add	x5, x0, #0x50
    9108:      	add	x6, x0, #0x78
    910c:      	add	x7, x0, #0x28
    9110:      	add	x8, x0, #0x50
    9114:      	sxtw	x1, w1
    9118:      	mov	x9, sp
    911c:      	sub	sp, sp, #0x10
    9120:      	mov	x10, sp
    9124:      	mov	x11, #0x1               ; =1
    9128:      	movz	x12, #0x0, lsl #48
    912c:      	b	0x9230 <_stogir.stack.valid-frame-object-inputs?+0x150>
    9130:      	movz	x15, #0x0, lsl #48
    9134:      	b	0x91a0 <_stogir.stack.valid-frame-object-inputs?+0xc0>
    9138:      	movz	x14, #0x0, lsl #48
    913c:      	movz	x13, #0x0, lsl #48
    9140:      	lsr	w14, w14, #0
    9144:      	lsr	x16, x14, #0
    9148:      	cmp	x16, #0x1
    914c:      	b.eq	0x9168 <_stogir.stack.valid-frame-object-inputs?+0x88>
    9150:      	b.lo	0x9158 <_stogir.stack.valid-frame-object-inputs?+0x78>
    9154:      	b	0x916c <_stogir.stack.valid-frame-object-inputs?+0x8c>
    9158:      	cmp	x16, #0x0
    915c:      	b.eq	0x9164 <_stogir.stack.valid-frame-object-inputs?+0x84>
    9160:      	b	0x916c <_stogir.stack.valid-frame-object-inputs?+0x8c>
    9164:      	b	0x918c <_stogir.stack.valid-frame-object-inputs?+0xac>
    9168:      	b	0x9170 <_stogir.stack.valid-frame-object-inputs?+0x90>
    916c:      	b	0x94f0 <_stogir.stack.valid-frame-object-inputs?+0x410>
    9170:      	uxtb	w14, w13
    9174:      	lsr	w13, w13, #0
    9178:      	ubfx	x13, x13, #8, #8
    917c:      	cmp	x14, x13
    9180:      	b.eq	0x94dc <_stogir.stack.valid-frame-object-inputs?+0x3fc>
    9184:      	cmp	x14, #0x49
    9188:      	b.eq	0x94dc <_stogir.stack.valid-frame-object-inputs?+0x3fc>
    918c:      	movz	x11, #0x0, lsl #48
    9190:      	b	0x9308 <_stogir.stack.valid-frame-object-inputs?+0x228>
    9194:      	movz	x15, #0x0, lsl #48
    9198:      	b	0x91a8 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    919c:      	movz	x15, #0x0, lsl #48
    91a0:      	b	0x91b0 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    91a4:      	movz	x15, #0x0, lsl #48
    91a8:      	b	0x91b0 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    91ac:      	movz	x15, #0x0, lsl #48
    91b0:      	cmp	x15, #0x0
    91b4:      	b.eq	0x91f0 <_stogir.stack.valid-frame-object-inputs?+0x110>
    91b8:      	uxtb	w16, w14
    91bc:      	cmp	w16, wzr
    91c0:      	b.eq	0x91d8 <_stogir.stack.valid-frame-object-inputs?+0xf8>
    91c4:      	ldr	x14, [x0]
    91c8:      	add	x13, x14, x13, lsl #4
    91cc:      	ldr	x14, [x13]
    91d0:      	ldr	x13, [x13, #0x8]
    91d4:      	b	0x91e8 <_stogir.stack.valid-frame-object-inputs?+0x108>
    91d8:      	ldr	x13, [x0, #0x28]
    91dc:      	add	x13, x13, x19, lsl #4
    91e0:      	ldr	x14, [x13]
    91e4:      	ldr	x13, [x13, #0x8]
    91e8:      	mov	x15, #0x1               ; =1
    91ec:      	b	0x91fc <_stogir.stack.valid-frame-object-inputs?+0x11c>
    91f0:      	movz	x15, #0x0, lsl #48
    91f4:      	movz	x14, #0x0, lsl #48
    91f8:      	movz	x13, #0x0, lsl #48
    91fc:      	lsr	w15, w15, #0
    9200:      	lsr	x16, x15, #0
    9204:      	cmp	x16, #0x1
    9208:      	b.eq	0x9224 <_stogir.stack.valid-frame-object-inputs?+0x144>
    920c:      	b.lo	0x9214 <_stogir.stack.valid-frame-object-inputs?+0x134>
    9210:      	b	0x9228 <_stogir.stack.valid-frame-object-inputs?+0x148>
    9214:      	cmp	x16, #0x0
    9218:      	b.eq	0x9220 <_stogir.stack.valid-frame-object-inputs?+0x140>
    921c:      	b	0x9228 <_stogir.stack.valid-frame-object-inputs?+0x148>
    9220:      	b	0x922c <_stogir.stack.valid-frame-object-inputs?+0x14c>
    9224:      	b	0x92e0 <_stogir.stack.valid-frame-object-inputs?+0x200>
    9228:      	b	0x9448 <_stogir.stack.valid-frame-object-inputs?+0x368>
    922c:      	movz	x11, #0x0, lsl #48
    9230:      	cmp	x11, #0x0
    9234:      	b.eq	0x9394 <_stogir.stack.valid-frame-object-inputs?+0x2b4>
    9238:      	cmp	x12, #0x0
    923c:      	b.ne	0x9394 <_stogir.stack.valid-frame-object-inputs?+0x2b4>
    9240:      	lsr	w13, w1, #0
    9244:      	sxtw	x13, w13
    9248:      	cmp	x13, #0x0
    924c:      	cset	w14, gt
    9250:      	movz	x16, #0x0, lsl #48
    9254:      	sub	x15, x16, x13
    9258:      	sub	x19, x15, #0x1
    925c:      	uxtb	w16, w14
    9260:      	cmp	w16, wzr
    9264:      	b.eq	0x92a0 <_stogir.stack.valid-frame-object-inputs?+0x1c0>
    9268:      	ldr	x15, [x0, #0x8]
    926c:      	cmp	x13, x15
    9270:      	b.ge	0x91a4 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    9274:      	ldr	x15, [x3, #0x8]
    9278:      	cmp	x13, x15
    927c:      	b.ge	0x9194 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    9280:      	ldr	x15, [x0, #0x78]
    9284:      	add	x15, x15, x13, lsl #2
    9288:      	ldr	w15, [x15]
    928c:      	sxtw	x15, w15
    9290:      	cmp	x15, #0x0
    9294:      	cset	w15, ge
    9298:      	ubfx	x15, x15, #0, #8
    929c:      	b	0x9198 <_stogir.stack.valid-frame-object-inputs?+0xb8>
    92a0:      	cmp	x13, #0x0
    92a4:      	b.ge	0x91ac <_stogir.stack.valid-frame-object-inputs?+0xcc>
    92a8:      	ldr	x20, [x4, #0x8]
    92ac:      	ldr	x21, [x5, #0x8]
    92b0:      	cmp	x20, x21
    92b4:      	b.ne	0x919c <_stogir.stack.valid-frame-object-inputs?+0xbc>
    92b8:      	cmp	x15, x20
    92bc:      	b.gt	0x9130 <_stogir.stack.valid-frame-object-inputs?+0x50>
    92c0:      	ldr	x15, [x0, #0x50]
    92c4:      	add	x15, x15, x19, lsl #2
    92c8:      	ldr	w15, [x15]
    92cc:      	sxtw	x15, w15
    92d0:      	cmp	x15, #0x0
    92d4:      	cset	w15, gt
    92d8:      	ubfx	x15, x15, #0, #8
    92dc:      	b	0x9134 <_stogir.stack.valid-frame-object-inputs?+0x54>
    92e0:      	uxtb	w15, w14
    92e4:      	asr	x19, x14, #32
    92e8:      	str	x14, [x10]
    92ec:      	str	x13, [x10, #0x8]
    92f0:      	cmp	x15, #0x68
    92f4:      	b.ne	0x930c <_stogir.stack.valid-frame-object-inputs?+0x22c>
    92f8:      	cmp	x19, #0x0
    92fc:      	cset	w11, eq
    9300:      	ubfx	x11, x11, #0, #8
    9304:      	mov	x12, #0x1               ; =1
    9308:      	b	0x9230 <_stogir.stack.valid-frame-object-inputs?+0x150>
    930c:      	cmp	x1, #0x0
    9310:      	b.le	0x918c <_stogir.stack.valid-frame-object-inputs?+0xac>
    9314:      	cmp	x15, #0x51
    9318:      	b.ne	0x918c <_stogir.stack.valid-frame-object-inputs?+0xac>
    931c:      	cmp	x19, #0x0
    9320:      	b.le	0x918c <_stogir.stack.valid-frame-object-inputs?+0xac>
    9324:      	cmp	x19, x1
    9328:      	b.ge	0x918c <_stogir.stack.valid-frame-object-inputs?+0xac>
    932c:      	lsr	w13, w13, #0
    9330:      	sxtw	x13, w13
    9334:      	cmp	x13, #0x0
    9338:      	b.ge	0x918c <_stogir.stack.valid-frame-object-inputs?+0xac>
    933c:      	cmp	x13, #0x0
    9340:      	cset	w14, gt
    9344:      	movz	x16, #0x0, lsl #48
    9348:      	sub	x15, x16, x13
    934c:      	sub	x19, x15, #0x1
    9350:      	uxtb	w16, w14
    9354:      	cmp	w16, wzr
    9358:      	b.eq	0x9494 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    935c:      	ldr	x15, [x0, #0x8]
    9360:      	cmp	x13, x15
    9364:      	b.ge	0x948c <_stogir.stack.valid-frame-object-inputs?+0x3ac>
    9368:      	ldr	x15, [x6, #0x8]
    936c:      	cmp	x13, x15
    9370:      	b.ge	0x94d4 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    9374:      	ldr	x15, [x0, #0x78]
    9378:      	add	x15, x15, x13, lsl #2
    937c:      	ldr	w15, [x15]
    9380:      	sxtw	x15, w15
    9384:      	cmp	x15, #0x0
    9388:      	cset	w15, ge
    938c:      	ubfx	x15, x15, #0, #8
    9390:      	b	0x94d8 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    9394:      	cmp	x11, #0x0
    9398:      	b.ne	0x93a0 <_stogir.stack.valid-frame-object-inputs?+0x2c0>
    939c:      	movz	x12, #0x0, lsl #48
    93a0:      	mov	sp, x9
    93a4:      	cmp	x12, #0x0
    93a8:      	b.eq	0x9404 <_stogir.stack.valid-frame-object-inputs?+0x324>
    93ac:      	sxtw	x1, w2
    93b0:      	cmp	x1, #0x0
    93b4:      	b.ge	0x9428 <_stogir.stack.valid-frame-object-inputs?+0x348>
    93b8:      	lsr	w2, w2, #0
    93bc:      	add	x8, x29, #0x10
    93c0:      	mov	w1, w2
    93c4:      	bl	0x93c4 <_stogir.stack.valid-frame-object-inputs?+0x2e4>
		00000000000093c4:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    93c8:      	add	x16, x29, #0x10
    93cc:      	ldr	w0, [x16]
    93d0:      	lsr	x16, x0, #0
    93d4:      	cmp	x16, #0x1
    93d8:      	b.eq	0x93f4 <_stogir.stack.valid-frame-object-inputs?+0x314>
    93dc:      	b.lo	0x93e4 <_stogir.stack.valid-frame-object-inputs?+0x304>
    93e0:      	b	0x93f8 <_stogir.stack.valid-frame-object-inputs?+0x318>
    93e4:      	cmp	x16, #0x0
    93e8:      	b.eq	0x93f0 <_stogir.stack.valid-frame-object-inputs?+0x310>
    93ec:      	b	0x93f8 <_stogir.stack.valid-frame-object-inputs?+0x318>
    93f0:      	b	0x9430 <_stogir.stack.valid-frame-object-inputs?+0x350>
    93f4:      	b	0x93fc <_stogir.stack.valid-frame-object-inputs?+0x31c>
    93f8:      	b	0x94e8 <_stogir.stack.valid-frame-object-inputs?+0x408>
    93fc:      	movz	x0, #0x0, lsl #48
    9400:      	b	0x9444 <_stogir.stack.valid-frame-object-inputs?+0x364>
    9404:      	movz	x0, #0x0, lsl #48
    9408:      	sub	sp, x29, #0x0
    940c:      	ldr	x19, [sp, #0x30]
    9410:      	ldr	x20, [sp, #0x38]
    9414:      	ldr	x21, [sp, #0x40]
    9418:      	ldr	x29, [sp]
    941c:      	ldr	x30, [sp, #0x8]
    9420:      	add	sp, sp, #0x50
    9424:      	ret
    9428:      	movz	x0, #0x0, lsl #48
    942c:      	b	0x9408 <_stogir.stack.valid-frame-object-inputs?+0x328>
    9430:      	add	x16, x29, #0x10
    9434:      	ldr	x0, [x16, #0x8]
    9438:      	cmp	x0, #0x0
    943c:      	cset	w0, gt
    9440:      	ubfx	x0, x0, #0, #8
    9444:      	b	0x942c <_stogir.stack.valid-frame-object-inputs?+0x34c>
    9448:      	brk	#0
    944c:      	b	0x9448 <_stogir.stack.valid-frame-object-inputs?+0x368>
    9450:      	ldr	x13, [x0, #0x28]
    9454:      	add	x13, x13, x19, lsl #4
    9458:      	ldr	x13, [x13]
    945c:      	mov	x14, #0x1               ; =1
    9460:      	b	0x9140 <_stogir.stack.valid-frame-object-inputs?+0x60>
    9464:      	movz	x15, #0x0, lsl #48
    9468:      	cmp	x15, #0x0
    946c:      	b.eq	0x9138 <_stogir.stack.valid-frame-object-inputs?+0x58>
    9470:      	uxtb	w16, w14
    9474:      	cmp	w16, wzr
    9478:      	b.eq	0x9450 <_stogir.stack.valid-frame-object-inputs?+0x370>
    947c:      	ldr	x14, [x0]
    9480:      	add	x13, x14, x13, lsl #4
    9484:      	ldr	x13, [x13]
    9488:      	b	0x945c <_stogir.stack.valid-frame-object-inputs?+0x37c>
    948c:      	movz	x15, #0x0, lsl #48
    9490:      	b	0x9468 <_stogir.stack.valid-frame-object-inputs?+0x388>
    9494:      	ldr	x20, [x7, #0x8]
    9498:      	ldr	x21, [x8, #0x8]
    949c:      	cmp	x20, x21
    94a0:      	b.ne	0x9464 <_stogir.stack.valid-frame-object-inputs?+0x384>
    94a4:      	cmp	x15, x20
    94a8:      	b.gt	0x94cc <_stogir.stack.valid-frame-object-inputs?+0x3ec>
    94ac:      	ldr	x15, [x0, #0x50]
    94b0:      	add	x15, x15, x19, lsl #2
    94b4:      	ldr	w15, [x15]
    94b8:      	sxtw	x15, w15
    94bc:      	cmp	x15, #0x0
    94c0:      	cset	w15, gt
    94c4:      	ubfx	x15, x15, #0, #8
    94c8:      	b	0x94d0 <_stogir.stack.valid-frame-object-inputs?+0x3f0>
    94cc:      	movz	x15, #0x0, lsl #48
    94d0:      	b	0x9468 <_stogir.stack.valid-frame-object-inputs?+0x388>
    94d4:      	movz	x15, #0x0, lsl #48
    94d8:      	b	0x9490 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    94dc:      	ldr	w1, [x10, #0x4]
    94e0:      	sxtw	x1, w1
    94e4:      	b	0x9190 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    94e8:      	brk	#0
    94ec:      	b	0x94e8 <_stogir.stack.valid-frame-object-inputs?+0x408>
    94f0:      	brk	#0
    94f4:      	b	0x94f0 <_stogir.stack.valid-frame-object-inputs?+0x410>

00000000000094f8 <_stogir.stack.validate-scope-inputs>:
    94f8:      	sxtw	x1, w1
    94fc:      	cmp	x1, #0x53
    9500:      	cset	w5, eq
    9504:      	uxtb	w16, w5
    9508:      	cmp	w16, wzr
    950c:      	b.ne	0x953c <_stogir.stack.validate-scope-inputs+0x44>
    9510:      	cmp	x1, #0x54
    9514:      	b.eq	0x953c <_stogir.stack.validate-scope-inputs+0x44>
    9518:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009518:  ARM64_RELOC_PAGE21	l_stogir.444
    951c:      	ldr	x16, [x16]
		000000000000951c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    9520:      	orr	x0, x16, xzr
    9524:      	mov	x1, #0x1                ; =1
    9528:      	mov	x2, #0x22               ; =34
    952c:      	str	x1, [x8]
    9530:      	str	x0, [x8, #0x8]
    9534:      	str	x2, [x8, #0x10]
    9538:      	ret
    953c:      	uxtb	w16, w5
    9540:      	cmp	w16, wzr
    9544:      	mov	x16, #0x6               ; =6
    9548:      	movz	x17, #0x0, lsl #48
    954c:      	csel	x1, x16, x17, ne
    9550:      	sxtw	x2, w2
    9554:      	lsr	w1, w1, #0
    9558:      	sxtw	x1, w1
    955c:      	cmp	x2, x1
    9560:      	b.ne	0x9518 <_stogir.stack.validate-scope-inputs+0x20>
    9564:      	sxtw	x3, w3
    9568:      	cmp	x3, #0x0
    956c:      	cset	w1, gt
    9570:      	movz	x16, #0x0, lsl #48
    9574:      	sub	x2, x16, x3
    9578:      	sub	x6, x2, #0x1
    957c:      	uxtb	w16, w1
    9580:      	cmp	w16, wzr
    9584:      	b.eq	0x9658 <_stogir.stack.validate-scope-inputs+0x160>
    9588:      	ldr	x2, [x0, #0x8]
    958c:      	cmp	x3, x2
    9590:      	b.ge	0x9650 <_stogir.stack.validate-scope-inputs+0x158>
    9594:      	add	x2, x0, #0x78
    9598:      	ldr	x2, [x2, #0x8]
    959c:      	cmp	x3, x2
    95a0:      	b.ge	0x96f8 <_stogir.stack.validate-scope-inputs+0x200>
    95a4:      	ldr	x2, [x0, #0x78]
    95a8:      	add	x2, x2, x3, lsl #2
    95ac:      	ldr	w2, [x2]
    95b0:      	sxtw	x2, w2
    95b4:      	cmp	x2, #0x0
    95b8:      	cset	w2, ge
    95bc:      	ubfx	x2, x2, #0, #8
    95c0:      	b	0x96fc <_stogir.stack.validate-scope-inputs+0x204>
    95c4:      	movz	x2, #0x0, lsl #48
    95c8:      	movz	x1, #0x0, lsl #48
    95cc:      	lsr	w2, w2, #0
    95d0:      	lsr	x16, x2, #0
    95d4:      	cmp	x16, #0x1
    95d8:      	b.eq	0x95f4 <_stogir.stack.validate-scope-inputs+0xfc>
    95dc:      	b.lo	0x95e4 <_stogir.stack.validate-scope-inputs+0xec>
    95e0:      	b	0x95f8 <_stogir.stack.validate-scope-inputs+0x100>
    95e4:      	cmp	x16, #0x0
    95e8:      	b.eq	0x95f0 <_stogir.stack.validate-scope-inputs+0xf8>
    95ec:      	b	0x95f8 <_stogir.stack.validate-scope-inputs+0x100>
    95f0:      	b	0x95fc <_stogir.stack.validate-scope-inputs+0x104>
    95f4:      	b	0x96a0 <_stogir.stack.validate-scope-inputs+0x1a8>
    95f8:      	b	0x98c8 <_stogir.stack.validate-scope-inputs+0x3d0>
    95fc:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		00000000000095fc:  ARM64_RELOC_PAGE21	l_stogir.445
    9600:      	ldr	x16, [x16]
		0000000000009600:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    9604:      	orr	x0, x16, xzr
    9608:      	mov	x1, #0x1                ; =1
    960c:      	mov	x2, #0x1b               ; =27
    9610:      	b	0x952c <_stogir.stack.validate-scope-inputs+0x34>
    9614:      	ldr	x1, [x0, #0x28]
    9618:      	add	x1, x1, x6, lsl #4
    961c:      	ldr	x1, [x1]
    9620:      	mov	x2, #0x1                ; =1
    9624:      	b	0x95cc <_stogir.stack.validate-scope-inputs+0xd4>
    9628:      	movz	x2, #0x0, lsl #48
    962c:      	cmp	x2, #0x0
    9630:      	b.eq	0x95c4 <_stogir.stack.validate-scope-inputs+0xcc>
    9634:      	uxtb	w16, w1
    9638:      	cmp	w16, wzr
    963c:      	b.eq	0x9614 <_stogir.stack.validate-scope-inputs+0x11c>
    9640:      	ldr	x1, [x0]
    9644:      	add	x1, x1, x3, lsl #4
    9648:      	ldr	x1, [x1]
    964c:      	b	0x9620 <_stogir.stack.validate-scope-inputs+0x128>
    9650:      	movz	x2, #0x0, lsl #48
    9654:      	b	0x962c <_stogir.stack.validate-scope-inputs+0x134>
    9658:      	cmp	x3, #0x0
    965c:      	b.ge	0x9628 <_stogir.stack.validate-scope-inputs+0x130>
    9660:      	add	x7, x0, #0x28
    9664:      	add	x9, x0, #0x50
    9668:      	ldr	x7, [x7, #0x8]
    966c:      	ldr	x9, [x9, #0x8]
    9670:      	cmp	x7, x9
    9674:      	b.ne	0x96f0 <_stogir.stack.validate-scope-inputs+0x1f8>
    9678:      	cmp	x2, x7
    967c:      	b.gt	0x9700 <_stogir.stack.validate-scope-inputs+0x208>
    9680:      	ldr	x2, [x0, #0x50]
    9684:      	add	x2, x2, x6, lsl #2
    9688:      	ldr	w2, [x2]
    968c:      	sxtw	x2, w2
    9690:      	cmp	x2, #0x0
    9694:      	cset	w2, gt
    9698:      	ubfx	x2, x2, #0, #8
    969c:      	b	0x9704 <_stogir.stack.validate-scope-inputs+0x20c>
    96a0:      	cmp	x3, #0x0
    96a4:      	b.le	0x96d8 <_stogir.stack.validate-scope-inputs+0x1e0>
    96a8:      	uxtb	w1, w1
    96ac:      	cmp	x1, #0x83
    96b0:      	cset	w2, lt
    96b4:      	uxtb	w16, w2
    96b8:      	cmp	w16, wzr
    96bc:      	b.eq	0x9708 <_stogir.stack.validate-scope-inputs+0x210>
    96c0:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		00000000000096c0:  ARM64_RELOC_PAGE21	l_stogir.446
    96c4:      	ldr	x16, [x16]
		00000000000096c4:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    96c8:      	orr	x3, x16, xzr
    96cc:      	add	x3, x1, x3
    96d0:      	ldrb	w3, [x3]
    96d4:      	b	0x970c <_stogir.stack.validate-scope-inputs+0x214>
    96d8:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		00000000000096d8:  ARM64_RELOC_PAGE21	l_stogir.447
    96dc:      	ldr	x16, [x16]
		00000000000096dc:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    96e0:      	orr	x0, x16, xzr
    96e4:      	mov	x1, #0x1                ; =1
    96e8:      	mov	x2, #0x1b               ; =27
    96ec:      	b	0x9610 <_stogir.stack.validate-scope-inputs+0x118>
    96f0:      	movz	x2, #0x0, lsl #48
    96f4:      	b	0x962c <_stogir.stack.validate-scope-inputs+0x134>
    96f8:      	movz	x2, #0x0, lsl #48
    96fc:      	b	0x9654 <_stogir.stack.validate-scope-inputs+0x15c>
    9700:      	movz	x2, #0x0, lsl #48
    9704:      	b	0x96f4 <_stogir.stack.validate-scope-inputs+0x1fc>
    9708:      	movz	x3, #0x0, lsl #48
    970c:      	uxtb	w3, w3
    9710:      	and	x3, x3, #0x1
    9714:      	uxtb	w3, w3
    9718:      	cmp	x3, #0x0
    971c:      	b.eq	0x96d8 <_stogir.stack.validate-scope-inputs+0x1e0>
    9720:      	uxtb	w16, w2
    9724:      	cmp	w16, wzr
    9728:      	b.eq	0x9744 <_stogir.stack.validate-scope-inputs+0x24c>
    972c:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		000000000000972c:  ARM64_RELOC_PAGE21	l_stogir.446
    9730:      	ldr	x16, [x16]
		0000000000009730:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    9734:      	orr	x2, x16, xzr
    9738:      	add	x1, x1, x2
    973c:      	ldrb	w1, [x1]
    9740:      	b	0x9748 <_stogir.stack.validate-scope-inputs+0x250>
    9744:      	movz	x1, #0x0, lsl #48
    9748:      	uxtb	w1, w1
    974c:      	and	x1, x1, #0x4
    9750:      	uxtb	w1, w1
    9754:      	cmp	x1, #0x0
    9758:      	cset	w1, eq
    975c:      	uxtb	w16, w1
    9760:      	cmp	w16, wzr
    9764:      	cset	x1, eq
    9768:      	cmp	x1, #0x0
    976c:      	b.ne	0x96d8 <_stogir.stack.validate-scope-inputs+0x1e0>
    9770:      	uxtb	w16, w5
    9774:      	cmp	w16, wzr
    9778:      	b.eq	0x978c <_stogir.stack.validate-scope-inputs+0x294>
    977c:      	movz	x1, #0x0, lsl #48
    9780:      	mov	x0, #0x8                ; =8
    9784:      	movz	x2, #0x0, lsl #48
    9788:      	b	0x96ec <_stogir.stack.validate-scope-inputs+0x1f4>
    978c:      	sxtw	x4, w4
    9790:      	cmp	x4, #0x0
    9794:      	cset	w1, gt
    9798:      	movz	x16, #0x0, lsl #48
    979c:      	sub	x2, x16, x4
    97a0:      	sub	x3, x2, #0x1
    97a4:      	uxtb	w16, w1
    97a8:      	cmp	w16, wzr
    97ac:      	b.eq	0x9880 <_stogir.stack.validate-scope-inputs+0x388>
    97b0:      	ldr	x2, [x0, #0x8]
    97b4:      	cmp	x4, x2
    97b8:      	b.ge	0x9878 <_stogir.stack.validate-scope-inputs+0x380>
    97bc:      	add	x2, x0, #0x78
    97c0:      	ldr	x2, [x2, #0x8]
    97c4:      	cmp	x4, x2
    97c8:      	b.ge	0x991c <_stogir.stack.validate-scope-inputs+0x424>
    97cc:      	ldr	x2, [x0, #0x78]
    97d0:      	add	x2, x2, x4, lsl #2
    97d4:      	ldr	w2, [x2]
    97d8:      	sxtw	x2, w2
    97dc:      	cmp	x2, #0x0
    97e0:      	cset	w2, ge
    97e4:      	ubfx	x2, x2, #0, #8
    97e8:      	b	0x9920 <_stogir.stack.validate-scope-inputs+0x428>
    97ec:      	movz	x1, #0x0, lsl #48
    97f0:      	movz	x0, #0x0, lsl #48
    97f4:      	lsr	w1, w1, #0
    97f8:      	lsr	x16, x1, #0
    97fc:      	cmp	x16, #0x1
    9800:      	b.eq	0x981c <_stogir.stack.validate-scope-inputs+0x324>
    9804:      	b.lo	0x980c <_stogir.stack.validate-scope-inputs+0x314>
    9808:      	b	0x9820 <_stogir.stack.validate-scope-inputs+0x328>
    980c:      	cmp	x16, #0x0
    9810:      	b.eq	0x9818 <_stogir.stack.validate-scope-inputs+0x320>
    9814:      	b	0x9820 <_stogir.stack.validate-scope-inputs+0x328>
    9818:      	b	0x9824 <_stogir.stack.validate-scope-inputs+0x32c>
    981c:      	b	0x98d0 <_stogir.stack.validate-scope-inputs+0x3d8>
    9820:      	b	0x992c <_stogir.stack.validate-scope-inputs+0x434>
    9824:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009824:  ARM64_RELOC_PAGE21	l_stogir.448
    9828:      	ldr	x16, [x16]
		0000000000009828:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    982c:      	orr	x0, x16, xzr
    9830:      	mov	x1, #0x1                ; =1
    9834:      	mov	x2, #0x1b               ; =27
    9838:      	b	0x9788 <_stogir.stack.validate-scope-inputs+0x290>
    983c:      	ldr	x0, [x0, #0x28]
    9840:      	add	x0, x0, x3, lsl #4
    9844:      	ldr	x0, [x0]
    9848:      	mov	x1, #0x1                ; =1
    984c:      	b	0x97f4 <_stogir.stack.validate-scope-inputs+0x2fc>
    9850:      	movz	x2, #0x0, lsl #48
    9854:      	cmp	x2, #0x0
    9858:      	b.eq	0x97ec <_stogir.stack.validate-scope-inputs+0x2f4>
    985c:      	uxtb	w16, w1
    9860:      	cmp	w16, wzr
    9864:      	b.eq	0x983c <_stogir.stack.validate-scope-inputs+0x344>
    9868:      	ldr	x0, [x0]
    986c:      	add	x0, x0, x4, lsl #4
    9870:      	ldr	x0, [x0]
    9874:      	b	0x9848 <_stogir.stack.validate-scope-inputs+0x350>
    9878:      	movz	x2, #0x0, lsl #48
    987c:      	b	0x9854 <_stogir.stack.validate-scope-inputs+0x35c>
    9880:      	cmp	x4, #0x0
    9884:      	b.ge	0x9850 <_stogir.stack.validate-scope-inputs+0x358>
    9888:      	add	x5, x0, #0x28
    988c:      	add	x6, x0, #0x50
    9890:      	ldr	x5, [x5, #0x8]
    9894:      	ldr	x6, [x6, #0x8]
    9898:      	cmp	x5, x6
    989c:      	b.ne	0x9914 <_stogir.stack.validate-scope-inputs+0x41c>
    98a0:      	cmp	x2, x5
    98a4:      	b.gt	0x9924 <_stogir.stack.validate-scope-inputs+0x42c>
    98a8:      	ldr	x2, [x0, #0x50]
    98ac:      	add	x2, x2, x3, lsl #2
    98b0:      	ldr	w2, [x2]
    98b4:      	sxtw	x2, w2
    98b8:      	cmp	x2, #0x0
    98bc:      	cset	w2, gt
    98c0:      	ubfx	x2, x2, #0, #8
    98c4:      	b	0x9928 <_stogir.stack.validate-scope-inputs+0x430>
    98c8:      	brk	#0
    98cc:      	b	0x98c8 <_stogir.stack.validate-scope-inputs+0x3d0>
    98d0:      	lsr	w1, w0, #0
    98d4:      	ubfx	x1, x1, #8, #8
    98d8:      	cmp	x1, #0x6
    98dc:      	b.ne	0x98fc <_stogir.stack.validate-scope-inputs+0x404>
    98e0:      	uxtb	w0, w0
    98e4:      	cmp	x0, #0x48
    98e8:      	b.eq	0x98fc <_stogir.stack.validate-scope-inputs+0x404>
    98ec:      	movz	x1, #0x0, lsl #48
    98f0:      	mov	x0, #0x8                ; =8
    98f4:      	movz	x2, #0x0, lsl #48
    98f8:      	b	0x9910 <_stogir.stack.validate-scope-inputs+0x418>
    98fc:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		00000000000098fc:  ARM64_RELOC_PAGE21	l_stogir.449
    9900:      	ldr	x16, [x16]
		0000000000009900:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    9904:      	orr	x0, x16, xzr
    9908:      	mov	x1, #0x1                ; =1
    990c:      	mov	x2, #0x29               ; =41
    9910:      	b	0x9838 <_stogir.stack.validate-scope-inputs+0x340>
    9914:      	movz	x2, #0x0, lsl #48
    9918:      	b	0x9854 <_stogir.stack.validate-scope-inputs+0x35c>
    991c:      	movz	x2, #0x0, lsl #48
    9920:      	b	0x987c <_stogir.stack.validate-scope-inputs+0x384>
    9924:      	movz	x2, #0x0, lsl #48
    9928:      	b	0x9918 <_stogir.stack.validate-scope-inputs+0x420>
    992c:      	brk	#0
    9930:      	b	0x992c <_stogir.stack.validate-scope-inputs+0x434>

0000000000009934 <_stogir.stack.validate-inputs>:
    9934:      	sub	sp, sp, #0x110
    9938:      	str	x29, [sp]
    993c:      	str	x30, [sp, #0x8]
    9940:      	mov	x29, sp
    9944:      	str	x19, [sp, #0xb8]
    9948:      	str	x20, [sp, #0xc0]
    994c:      	str	x21, [sp, #0xc8]
    9950:      	str	x22, [sp, #0xd0]
    9954:      	str	x23, [sp, #0xd8]
    9958:      	str	x24, [sp, #0xe0]
    995c:      	str	x25, [sp, #0xe8]
    9960:      	str	x26, [sp, #0xf0]
    9964:      	str	x27, [sp, #0xf8]
    9968:      	str	x28, [sp, #0x100]
    996c:      	sxtw	x1, w1
    9970:      	cmp	x1, #0x51
    9974:      	cset	w19, eq
    9978:      	uxtb	w16, w19
    997c:      	cmp	w16, wzr
    9980:      	b.ne	0x99ec <_stogir.stack.validate-inputs+0xb8>
    9984:      	cmp	x1, #0x52
    9988:      	b.eq	0x99ec <_stogir.stack.validate-inputs+0xb8>
    998c:      	str	x8, [sp, #0x90]
    9990:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009990:  ARM64_RELOC_PAGE21	l_stogir.450
    9994:      	ldr	x16, [x16]
		0000000000009994:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    9998:      	orr	x0, x16, xzr
    999c:      	mov	x2, #0x1                ; =1
    99a0:      	mov	x1, #0x29               ; =41
    99a4:      	ldr	x3, [sp, #0x90]
    99a8:      	str	x2, [x3]
    99ac:      	str	x0, [x3, #0x8]
    99b0:      	str	x1, [x3, #0x10]
    99b4:      	ldr	x19, [sp, #0xb8]
    99b8:      	ldr	x20, [sp, #0xc0]
    99bc:      	ldr	x21, [sp, #0xc8]
    99c0:      	ldr	x22, [sp, #0xd0]
    99c4:      	ldr	x23, [sp, #0xd8]
    99c8:      	ldr	x24, [sp, #0xe0]
    99cc:      	ldr	x25, [sp, #0xe8]
    99d0:      	ldr	x26, [sp, #0xf0]
    99d4:      	ldr	x27, [sp, #0xf8]
    99d8:      	ldr	x28, [sp, #0x100]
    99dc:      	ldr	x29, [sp]
    99e0:      	ldr	x30, [sp, #0x8]
    99e4:      	add	sp, sp, #0x110
    99e8:      	ret
    99ec:      	uxtb	w16, w19
    99f0:      	cmp	w16, wzr
    99f4:      	mov	x16, #0x6               ; =6
    99f8:      	movz	x17, #0x0, lsl #48
    99fc:      	csel	x1, x16, x17, ne
    9a00:      	sxtw	x2, w2
    9a04:      	lsr	w1, w1, #0
    9a08:      	sxtw	x1, w1
    9a0c:      	cmp	x2, x1
    9a10:      	b.ne	0x9f54 <_stogir.stack.validate-inputs+0x620>
    9a14:      	sxtw	x20, w5
    9a18:      	uxtb	w16, w19
    9a1c:      	cmp	w16, wzr
    9a20:      	b.eq	0x9a44 <_stogir.stack.validate-inputs+0x110>
    9a24:      	cmp	x20, #0x0
    9a28:      	b.eq	0x9a44 <_stogir.stack.validate-inputs+0x110>
    9a2c:      	cmp	x20, #0x0
    9a30:      	b.le	0x9ae4 <_stogir.stack.validate-inputs+0x1b0>
    9a34:      	sub	x1, x20, #0x1
    9a38:      	and	x1, x1, x20
    9a3c:      	cmp	x1, #0x0
    9a40:      	b.ne	0x9ae4 <_stogir.stack.validate-inputs+0x1b0>
    9a44:      	lsr	w3, w3, #0
    9a48:      	mov	w1, w3
    9a4c:      	mov	x21, x8
    9a50:      	add	x8, sp, #0x10
    9a54:      	mov	x22, x0
    9a58:      	mov	w23, w3
    9a5c:      	mov	w24, w4
    9a60:      	bl	0x9a60 <_stogir.stack.validate-inputs+0x12c>
		0000000000009a60:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    9a64:      	add	x16, sp, #0x10
    9a68:      	ldr	w0, [x16]
    9a6c:      	lsr	x16, x0, #0
    9a70:      	cmp	x16, #0x1
    9a74:      	b.eq	0x9a90 <_stogir.stack.validate-inputs+0x15c>
    9a78:      	b.lo	0x9a80 <_stogir.stack.validate-inputs+0x14c>
    9a7c:      	b	0x9a94 <_stogir.stack.validate-inputs+0x160>
    9a80:      	cmp	x16, #0x0
    9a84:      	b.eq	0x9a8c <_stogir.stack.validate-inputs+0x158>
    9a88:      	b	0x9a94 <_stogir.stack.validate-inputs+0x160>
    9a8c:      	b	0x9a98 <_stogir.stack.validate-inputs+0x164>
    9a90:      	b	0x9ab4 <_stogir.stack.validate-inputs+0x180>
    9a94:      	b	0x9d68 <_stogir.stack.validate-inputs+0x434>
    9a98:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009a98:  ARM64_RELOC_PAGE21	l_stogir.451
    9a9c:      	ldr	x16, [x16]
		0000000000009a9c:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    9aa0:      	orr	x0, x16, xzr
    9aa4:      	str	x21, [sp, #0x90]
    9aa8:      	mov	x2, #0x1                ; =1
    9aac:      	mov	x1, #0x1f               ; =31
    9ab0:      	b	0x99a4 <_stogir.stack.validate-inputs+0x70>
    9ab4:      	sxtw	x23, w23
    9ab8:      	add	x16, sp, #0x10
    9abc:      	ldr	x0, [x16, #0x8]
    9ac0:      	cmp	x23, #0x0
    9ac4:      	b.gt	0x9aec <_stogir.stack.validate-inputs+0x1b8>
    9ac8:      	str	x21, [sp, #0x90]
    9acc:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009acc:  ARM64_RELOC_PAGE21	l_stogir.452
    9ad0:      	ldr	x16, [x16]
		0000000000009ad0:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9ad4:      	orr	x0, x16, xzr
    9ad8:      	mov	x2, #0x1                ; =1
    9adc:      	mov	x1, #0x1f               ; =31
    9ae0:      	b	0x9ab0 <_stogir.stack.validate-inputs+0x17c>
    9ae4:      	str	x8, [sp, #0x90]
    9ae8:      	b	0x9990 <_stogir.stack.validate-inputs+0x5c>
    9aec:      	uxtb	w0, w0
    9af0:      	cmp	x0, #0x83
    9af4:      	cset	w1, lt
    9af8:      	uxtb	w16, w1
    9afc:      	cmp	w16, wzr
    9b00:      	b.eq	0x9b1c <_stogir.stack.validate-inputs+0x1e8>
    9b04:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009b04:  ARM64_RELOC_PAGE21	l_stogir.453
    9b08:      	ldr	x16, [x16]
		0000000000009b08:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    9b0c:      	orr	x2, x16, xzr
    9b10:      	add	x2, x0, x2
    9b14:      	ldrb	w2, [x2]
    9b18:      	b	0x9b20 <_stogir.stack.validate-inputs+0x1ec>
    9b1c:      	movz	x2, #0x0, lsl #48
    9b20:      	uxtb	w2, w2
    9b24:      	and	x2, x2, #0x1
    9b28:      	uxtb	w2, w2
    9b2c:      	cmp	x2, #0x0
    9b30:      	b.eq	0x9f5c <_stogir.stack.validate-inputs+0x628>
    9b34:      	uxtb	w16, w1
    9b38:      	cmp	w16, wzr
    9b3c:      	b.eq	0x9b58 <_stogir.stack.validate-inputs+0x224>
    9b40:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009b40:  ARM64_RELOC_PAGE21	l_stogir.453
    9b44:      	ldr	x16, [x16]
		0000000000009b44:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    9b48:      	orr	x1, x16, xzr
    9b4c:      	add	x0, x0, x1
    9b50:      	ldrb	w0, [x0]
    9b54:      	b	0x9b5c <_stogir.stack.validate-inputs+0x228>
    9b58:      	movz	x0, #0x0, lsl #48
    9b5c:      	uxtb	w0, w0
    9b60:      	and	x0, x0, #0x4
    9b64:      	uxtb	w0, w0
    9b68:      	cmp	x0, #0x0
    9b6c:      	cset	w0, eq
    9b70:      	uxtb	w16, w0
    9b74:      	cmp	w16, wzr
    9b78:      	cset	x0, eq
    9b7c:      	cmp	x0, #0x0
    9b80:      	b.ne	0x9f64 <_stogir.stack.validate-inputs+0x630>
    9b84:      	lsr	w24, w24, #0
    9b88:      	add	x8, sp, #0x40
    9b8c:      	mov	x0, x22
    9b90:      	mov	w1, w24
    9b94:      	bl	0x9b94 <_stogir.stack.validate-inputs+0x260>
		0000000000009b94:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    9b98:      	add	x16, sp, #0x40
    9b9c:      	ldr	w0, [x16]
    9ba0:      	lsr	x16, x0, #0
    9ba4:      	cmp	x16, #0x1
    9ba8:      	b.eq	0x9bc4 <_stogir.stack.validate-inputs+0x290>
    9bac:      	b.lo	0x9bb4 <_stogir.stack.validate-inputs+0x280>
    9bb0:      	b	0x9bc8 <_stogir.stack.validate-inputs+0x294>
    9bb4:      	cmp	x16, #0x0
    9bb8:      	b.eq	0x9bc0 <_stogir.stack.validate-inputs+0x28c>
    9bbc:      	b	0x9bc8 <_stogir.stack.validate-inputs+0x294>
    9bc0:      	b	0x9bcc <_stogir.stack.validate-inputs+0x298>
    9bc4:      	b	0x9be8 <_stogir.stack.validate-inputs+0x2b4>
    9bc8:      	b	0x9e5c <_stogir.stack.validate-inputs+0x528>
    9bcc:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009bcc:  ARM64_RELOC_PAGE21	l_stogir.454
    9bd0:      	ldr	x16, [x16]
		0000000000009bd0:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    9bd4:      	orr	x0, x16, xzr
    9bd8:      	str	x21, [sp, #0x90]
    9bdc:      	mov	x2, #0x1                ; =1
    9be0:      	mov	x1, #0x18               ; =24
    9be4:      	b	0x9ae0 <_stogir.stack.validate-inputs+0x1ac>
    9be8:      	add	x16, sp, #0x40
    9bec:      	ldr	x0, [x16, #0x8]
    9bf0:      	lsr	w1, w0, #0
    9bf4:      	ubfx	x1, x1, #8, #8
    9bf8:      	cmp	x1, #0x1
    9bfc:      	b.lt	0x9f6c <_stogir.stack.validate-inputs+0x638>
    9c00:      	cmp	x1, #0xb
    9c04:      	b.gt	0x9f74 <_stogir.stack.validate-inputs+0x640>
    9c08:      	uxtb	w0, w0
    9c0c:      	cmp	x0, #0x48
    9c10:      	b.eq	0x9f7c <_stogir.stack.validate-inputs+0x648>
    9c14:      	sxtw	x0, w24
    9c18:      	cmp	x1, #0x0
    9c1c:      	cset	w23, eq
    9c20:      	cmp	x1, #0x1
    9c24:      	cset	w25, eq
    9c28:      	cmp	x1, #0x2
    9c2c:      	cset	w26, eq
    9c30:      	cmp	x1, #0x7
    9c34:      	cset	w27, eq
    9c38:      	cmp	x1, #0x8
    9c3c:      	cset	w28, eq
    9c40:      	cmp	x1, #0x3
    9c44:      	cset	w2, eq
    9c48:      	cmp	x1, #0x9
    9c4c:      	cset	w3, eq
    9c50:      	cmp	x1, #0x4
    9c54:      	cset	w4, eq
    9c58:      	cmp	x1, #0xa
    9c5c:      	cset	w5, eq
    9c60:      	cmp	x1, #0xd
    9c64:      	cset	w6, eq
    9c68:      	cmp	x1, #0x5
    9c6c:      	cset	w7, eq
    9c70:      	cmp	x1, #0xb
    9c74:      	cset	w8, eq
    9c78:      	cmp	x1, #0xc
    9c7c:      	cset	w9, eq
    9c80:      	cmp	x1, #0x6
    9c84:      	cset	w1, eq
    9c88:      	uxtb	w16, w1
    9c8c:      	cmp	w16, wzr
    9c90:      	mov	x16, #0x8               ; =8
    9c94:      	movn	x17, #0x0, lsl #48
    9c98:      	csel	x1, x16, x17, ne
    9c9c:      	cmp	x0, #0x0
    9ca0:      	b.ge	0x9f84 <_stogir.stack.validate-inputs+0x650>
    9ca4:      	uxtb	w16, w19
    9ca8:      	cmp	w16, wzr
    9cac:      	b.eq	0x9cb8 <_stogir.stack.validate-inputs+0x384>
    9cb0:      	cmp	x20, #0x10
    9cb4:      	b.gt	0x9cbc <_stogir.stack.validate-inputs+0x388>
    9cb8:      	mov	x20, #0x10              ; =16
    9cbc:      	lsr	w24, w24, #0
    9cc0:      	mov	x0, x22
    9cc4:      	mov	w19, w2
    9cc8:      	mov	x2, x20
    9ccc:      	mov	w20, w3
    9cd0:      	mov	w22, w4
    9cd4:      	str	w7, [sp, #0x98]
    9cd8:      	str	w8, [sp, #0xa0]
    9cdc:      	add	x8, sp, #0x70
    9ce0:      	str	w9, [sp, #0xa8]
    9ce4:      	str	x1, [sp, #0xb0]
    9ce8:      	mov	w1, w24
    9cec:      	mov	w24, w5
    9cf0:      	str	x21, [sp, #0x90]
    9cf4:      	mov	w21, w6
    9cf8:      	bl	0x9cf8 <_stogir.stack.validate-inputs+0x3c4>
		0000000000009cf8:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    9cfc:      	add	x16, sp, #0x70
    9d00:      	ldr	w0, [x16]
    9d04:      	lsr	x16, x0, #0
    9d08:      	cmp	x16, #0x1
    9d0c:      	b.eq	0x9d28 <_stogir.stack.validate-inputs+0x3f4>
    9d10:      	b.lo	0x9d18 <_stogir.stack.validate-inputs+0x3e4>
    9d14:      	b	0x9d2c <_stogir.stack.validate-inputs+0x3f8>
    9d18:      	cmp	x16, #0x0
    9d1c:      	b.eq	0x9d24 <_stogir.stack.validate-inputs+0x3f0>
    9d20:      	b	0x9d2c <_stogir.stack.validate-inputs+0x3f8>
    9d24:      	b	0x9e64 <_stogir.stack.validate-inputs+0x530>
    9d28:      	b	0x9d30 <_stogir.stack.validate-inputs+0x3fc>
    9d2c:      	b	0x9f38 <_stogir.stack.validate-inputs+0x604>
    9d30:      	add	x16, sp, #0x70
    9d34:      	orr	x0, x16, xzr
    9d38:      	add	x1, x0, #0x8
    9d3c:      	add	x16, sp, #0x70
    9d40:      	ldr	x0, [x16, #0x8]
    9d44:      	ldr	x1, [x1, #0x8]
    9d48:      	mov	x2, #0x1                ; =1
    9d4c:      	b	0x9dc0 <_stogir.stack.validate-inputs+0x48c>
    9d50:      	adrp	x16, 0x9000 <_stogir.switch.case-inputs+0x378>
		0000000000009d50:  ARM64_RELOC_PAGE21	l_stogir.455
    9d54:      	ldr	x16, [x16]
		0000000000009d54:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    9d58:      	orr	x0, x16, xzr
    9d5c:      	mov	x2, #0x1                ; =1
    9d60:      	mov	x1, #0x29               ; =41
    9d64:      	b	0x9be4 <_stogir.stack.validate-inputs+0x2b0>
    9d68:      	brk	#0
    9d6c:      	b	0x9d68 <_stogir.stack.validate-inputs+0x434>
    9d70:      	mov	x3, #0x1                ; =1
    9d74:      	lsr	w3, w3, #0
    9d78:      	sxtw	x3, w3
    9d7c:      	and	x0, x3, #0xffffffff
    9d80:      	movz	x2, #0x0, lsl #48
    9d84:      	movz	x1, #0x0, lsl #48
    9d88:      	b	0x9d64 <_stogir.stack.validate-inputs+0x430>
    9d8c:      	uxtb	w16, w23
    9d90:      	cmp	w16, wzr
    9d94:      	b.eq	0x9dc4 <_stogir.stack.validate-inputs+0x490>
    9d98:      	movz	x3, #0x0, lsl #48
    9d9c:      	b	0x9d74 <_stogir.stack.validate-inputs+0x440>
    9da0:      	mov	x16, #0x1               ; =1
    9da4:      	str	x16, [sp, #0xb0]
    9da8:      	ldr	x3, [sp, #0xb0]
    9dac:      	lsr	w3, w3, #0
    9db0:      	sxtw	x3, w3
    9db4:      	and	x0, x3, #0xffffffff
    9db8:      	movz	x2, #0x0, lsl #48
    9dbc:      	movz	x1, #0x0, lsl #48
    9dc0:      	b	0x9d88 <_stogir.stack.validate-inputs+0x454>
    9dc4:      	uxtb	w16, w25
    9dc8:      	cmp	w16, wzr
    9dcc:      	b.ne	0x9d70 <_stogir.stack.validate-inputs+0x43c>
    9dd0:      	uxtb	w16, w26
    9dd4:      	cmp	w16, wzr
    9dd8:      	b.ne	0x9d70 <_stogir.stack.validate-inputs+0x43c>
    9ddc:      	uxtb	w16, w27
    9de0:      	cmp	w16, wzr
    9de4:      	b.ne	0x9d70 <_stogir.stack.validate-inputs+0x43c>
    9de8:      	uxtb	w16, w28
    9dec:      	cmp	w16, wzr
    9df0:      	b.ne	0x9d70 <_stogir.stack.validate-inputs+0x43c>
    9df4:      	uxtb	w16, w19
    9df8:      	cmp	w16, wzr
    9dfc:      	b.ne	0x9f24 <_stogir.stack.validate-inputs+0x5f0>
    9e00:      	uxtb	w16, w20
    9e04:      	cmp	w16, wzr
    9e08:      	b.ne	0x9f24 <_stogir.stack.validate-inputs+0x5f0>
    9e0c:      	uxtb	w16, w22
    9e10:      	cmp	w16, wzr
    9e14:      	b.ne	0x9f40 <_stogir.stack.validate-inputs+0x60c>
    9e18:      	uxtb	w16, w24
    9e1c:      	cmp	w16, wzr
    9e20:      	b.ne	0x9f40 <_stogir.stack.validate-inputs+0x60c>
    9e24:      	uxtb	w16, w21
    9e28:      	cmp	w16, wzr
    9e2c:      	b.ne	0x9f40 <_stogir.stack.validate-inputs+0x60c>
    9e30:      	uxtb	w16, w0
    9e34:      	cmp	w16, wzr
    9e38:      	b.ne	0x9e54 <_stogir.stack.validate-inputs+0x520>
    9e3c:      	uxtb	w16, w1
    9e40:      	cmp	w16, wzr
    9e44:      	b.ne	0x9e54 <_stogir.stack.validate-inputs+0x520>
    9e48:      	uxtb	w16, w2
    9e4c:      	cmp	w16, wzr
    9e50:      	b.eq	0x9e58 <_stogir.stack.validate-inputs+0x524>
    9e54:      	mov	x3, #0x8                ; =8
    9e58:      	b	0x9f44 <_stogir.stack.validate-inputs+0x610>
    9e5c:      	brk	#0
    9e60:      	b	0x9e5c <_stogir.stack.validate-inputs+0x528>
    9e64:      	uxtb	w16, w23
    9e68:      	cmp	w16, wzr
    9e6c:      	b.eq	0x9e7c <_stogir.stack.validate-inputs+0x548>
    9e70:      	movz	x16, #0x0, lsl #48
    9e74:      	str	x16, [sp, #0xb0]
    9e78:      	b	0x9da8 <_stogir.stack.validate-inputs+0x474>
    9e7c:      	uxtb	w16, w25
    9e80:      	cmp	w16, wzr
    9e84:      	b.ne	0x9da0 <_stogir.stack.validate-inputs+0x46c>
    9e88:      	uxtb	w16, w26
    9e8c:      	cmp	w16, wzr
    9e90:      	b.ne	0x9da0 <_stogir.stack.validate-inputs+0x46c>
    9e94:      	uxtb	w16, w27
    9e98:      	cmp	w16, wzr
    9e9c:      	b.ne	0x9da0 <_stogir.stack.validate-inputs+0x46c>
    9ea0:      	uxtb	w16, w28
    9ea4:      	cmp	w16, wzr
    9ea8:      	b.ne	0x9da0 <_stogir.stack.validate-inputs+0x46c>
    9eac:      	uxtb	w16, w19
    9eb0:      	cmp	w16, wzr
    9eb4:      	b.ne	0x9f2c <_stogir.stack.validate-inputs+0x5f8>
    9eb8:      	uxtb	w16, w20
    9ebc:      	cmp	w16, wzr
    9ec0:      	b.ne	0x9f2c <_stogir.stack.validate-inputs+0x5f8>
    9ec4:      	uxtb	w16, w22
    9ec8:      	cmp	w16, wzr
    9ecc:      	b.ne	0x9f48 <_stogir.stack.validate-inputs+0x614>
    9ed0:      	uxtb	w16, w24
    9ed4:      	cmp	w16, wzr
    9ed8:      	b.ne	0x9f48 <_stogir.stack.validate-inputs+0x614>
    9edc:      	uxtb	w16, w21
    9ee0:      	cmp	w16, wzr
    9ee4:      	b.ne	0x9f48 <_stogir.stack.validate-inputs+0x614>
    9ee8:      	ldr	w0, [sp, #0x98]
    9eec:      	uxtb	w16, w0
    9ef0:      	cmp	w16, wzr
    9ef4:      	b.ne	0x9f18 <_stogir.stack.validate-inputs+0x5e4>
    9ef8:      	ldr	w1, [sp, #0xa0]
    9efc:      	uxtb	w16, w1
    9f00:      	cmp	w16, wzr
    9f04:      	b.ne	0x9f18 <_stogir.stack.validate-inputs+0x5e4>
    9f08:      	ldr	w2, [sp, #0xa8]
    9f0c:      	uxtb	w16, w2
    9f10:      	cmp	w16, wzr
    9f14:      	b.eq	0x9f20 <_stogir.stack.validate-inputs+0x5ec>
    9f18:      	mov	x16, #0x8               ; =8
    9f1c:      	str	x16, [sp, #0xb0]
    9f20:      	b	0x9f50 <_stogir.stack.validate-inputs+0x61c>
    9f24:      	mov	x3, #0x2                ; =2
    9f28:      	b	0x9d74 <_stogir.stack.validate-inputs+0x440>
    9f2c:      	mov	x16, #0x2               ; =2
    9f30:      	str	x16, [sp, #0xb0]
    9f34:      	b	0x9da8 <_stogir.stack.validate-inputs+0x474>
    9f38:      	brk	#0
    9f3c:      	b	0x9f38 <_stogir.stack.validate-inputs+0x604>
    9f40:      	mov	x3, #0x4                ; =4
    9f44:      	b	0x9f28 <_stogir.stack.validate-inputs+0x5f4>
    9f48:      	mov	x16, #0x4               ; =4
    9f4c:      	str	x16, [sp, #0xb0]
    9f50:      	b	0x9f34 <_stogir.stack.validate-inputs+0x600>
    9f54:      	str	x8, [sp, #0x90]
    9f58:      	b	0x9990 <_stogir.stack.validate-inputs+0x5c>
    9f5c:      	str	x21, [sp, #0x90]
    9f60:      	b	0x9acc <_stogir.stack.validate-inputs+0x198>
    9f64:      	str	x21, [sp, #0x90]
    9f68:      	b	0x9acc <_stogir.stack.validate-inputs+0x198>
    9f6c:      	str	x21, [sp, #0x90]
    9f70:      	b	0x9d50 <_stogir.stack.validate-inputs+0x41c>
    9f74:      	str	x21, [sp, #0x90]
    9f78:      	b	0x9d50 <_stogir.stack.validate-inputs+0x41c>
    9f7c:      	str	x21, [sp, #0x90]
    9f80:      	b	0x9d50 <_stogir.stack.validate-inputs+0x41c>
    9f84:      	str	x21, [sp, #0x90]
    9f88:      	mov	w19, w2
    9f8c:      	mov	w20, w3
    9f90:      	mov	x3, x1
    9f94:      	mov	w22, w4
    9f98:      	mov	w24, w5
    9f9c:      	mov	w21, w6
    9fa0:      	mov	w0, w7
    9fa4:      	mov	w1, w8
    9fa8:      	mov	w2, w9
    9fac:      	b	0x9d8c <_stogir.stack.validate-inputs+0x458>

0000000000009fb0 <_stogir.locals.shape>:
    9fb0:      	sub	sp, sp, #0x40
    9fb4:      	str	x29, [sp]
    9fb8:      	str	x30, [sp, #0x8]
    9fbc:      	mov	x29, sp
    9fc0:      	str	x19, [sp, #0x20]
    9fc4:      	str	x20, [sp, #0x28]
    9fc8:      	str	x21, [sp, #0x30]
    9fcc:      	str	x22, [sp, #0x38]
    9fd0:      	sxtw	x19, w1
    9fd4:      	lsl	x20, x19, #2
    9fd8:      	cmp	x19, #0x0
    9fdc:      	cset	w1, gt
    9fe0:      	movz	x16, #0x0, lsl #48
    9fe4:      	sub	x3, x16, x19
    9fe8:      	sub	x4, x3, #0x1
    9fec:      	uxtb	w16, w1
    9ff0:      	cmp	w16, wzr
    9ff4:      	b.eq	0xa034 <_stogir.locals.shape+0x84>
    9ff8:      	ldr	x3, [x0, #0x8]
    9ffc:      	cmp	x19, x3
    a000:      	b.ge	0xa09c <_stogir.locals.shape+0xec>
    a004:      	add	x3, x0, #0x78
    a008:      	ldr	x3, [x3, #0x8]
    a00c:      	cmp	x19, x3
    a010:      	b.ge	0xa23c <_stogir.locals.shape+0x28c>
    a014:      	ldr	x3, [x0, #0x78]
    a018:      	add	x3, x20, x3
    a01c:      	ldr	w3, [x3]
    a020:      	sxtw	x3, w3
    a024:      	cmp	x3, #0x0
    a028:      	cset	w3, ge
    a02c:      	ubfx	x3, x3, #0, #8
    a030:      	b	0xa240 <_stogir.locals.shape+0x290>
    a034:      	cmp	x19, #0x0
    a038:      	b.ge	0xa0a4 <_stogir.locals.shape+0xf4>
    a03c:      	add	x5, x0, #0x28
    a040:      	add	x6, x0, #0x50
    a044:      	ldr	x5, [x5, #0x8]
    a048:      	ldr	x6, [x6, #0x8]
    a04c:      	cmp	x5, x6
    a050:      	b.ne	0xa07c <_stogir.locals.shape+0xcc>
    a054:      	cmp	x3, x5
    a058:      	b.gt	0xa340 <_stogir.locals.shape+0x390>
    a05c:      	ldr	x3, [x0, #0x50]
    a060:      	add	x3, x3, x4, lsl #2
    a064:      	ldr	w3, [x3]
    a068:      	sxtw	x3, w3
    a06c:      	cmp	x3, #0x0
    a070:      	cset	w3, gt
    a074:      	ubfx	x3, x3, #0, #8
    a078:      	b	0xa344 <_stogir.locals.shape+0x394>
    a07c:      	movz	x3, #0x0, lsl #48
    a080:      	b	0xa0a8 <_stogir.locals.shape+0xf8>
    a084:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000a084:  ARM64_RELOC_PAGE21	l_stogir.456
    a088:      	ldr	x16, [x16]
		000000000000a088:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    a08c:      	orr	x0, x16, xzr
    a090:      	mov	x2, #0x1                ; =1
    a094:      	mov	x1, #0x1c               ; =28
    a098:      	b	0xa13c <_stogir.locals.shape+0x18c>
    a09c:      	movz	x3, #0x0, lsl #48
    a0a0:      	b	0xa0a8 <_stogir.locals.shape+0xf8>
    a0a4:      	movz	x3, #0x0, lsl #48
    a0a8:      	cmp	x3, #0x0
    a0ac:      	b.eq	0xa0e8 <_stogir.locals.shape+0x138>
    a0b0:      	uxtb	w16, w1
    a0b4:      	cmp	w16, wzr
    a0b8:      	b.eq	0xa0d0 <_stogir.locals.shape+0x120>
    a0bc:      	ldr	x1, [x0]
    a0c0:      	add	x1, x1, x19, lsl #4
    a0c4:      	ldr	x3, [x1]
    a0c8:      	ldr	x1, [x1, #0x8]
    a0cc:      	b	0xa0e0 <_stogir.locals.shape+0x130>
    a0d0:      	ldr	x1, [x0, #0x28]
    a0d4:      	add	x1, x1, x4, lsl #4
    a0d8:      	ldr	x3, [x1]
    a0dc:      	ldr	x1, [x1, #0x8]
    a0e0:      	mov	x4, #0x1                ; =1
    a0e4:      	b	0xa0f4 <_stogir.locals.shape+0x144>
    a0e8:      	movz	x4, #0x0, lsl #48
    a0ec:      	movz	x3, #0x0, lsl #48
    a0f0:      	movz	x1, #0x0, lsl #48
    a0f4:      	lsr	w4, w4, #0
    a0f8:      	lsr	x16, x4, #0
    a0fc:      	cmp	x16, #0x1
    a100:      	b.eq	0xa11c <_stogir.locals.shape+0x16c>
    a104:      	b.lo	0xa10c <_stogir.locals.shape+0x15c>
    a108:      	b	0xa120 <_stogir.locals.shape+0x170>
    a10c:      	cmp	x16, #0x0
    a110:      	b.eq	0xa118 <_stogir.locals.shape+0x168>
    a114:      	b	0xa120 <_stogir.locals.shape+0x170>
    a118:      	b	0xa124 <_stogir.locals.shape+0x174>
    a11c:      	b	0xa168 <_stogir.locals.shape+0x1b8>
    a120:      	b	0xa350 <_stogir.locals.shape+0x3a0>
    a124:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000a124:  ARM64_RELOC_PAGE21	l_stogir.457
    a128:      	ldr	x16, [x16]
		000000000000a128:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    a12c:      	orr	x0, x16, xzr
    a130:      	mov	x21, x8
    a134:      	mov	x2, #0x1                ; =1
    a138:      	mov	x1, #0x16               ; =22
    a13c:      	str	x2, [x21]
    a140:      	str	x0, [x21, #0x8]
    a144:      	str	x1, [x21, #0x10]
    a148:      	ldr	x19, [sp, #0x20]
    a14c:      	ldr	x20, [sp, #0x28]
    a150:      	ldr	x21, [sp, #0x30]
    a154:      	ldr	x22, [sp, #0x38]
    a158:      	ldr	x29, [sp]
    a15c:      	ldr	x30, [sp, #0x8]
    a160:      	add	sp, sp, #0x40
    a164:      	ret
    a168:      	lsr	w2, w2, #0
    a16c:      	lsr	w4, w3, #0
    a170:      	add	x16, sp, #0x10
    a174:      	str	x3, [x16]
    a178:      	add	x16, sp, #0x10
    a17c:      	str	x1, [x16, #0x8]
    a180:      	ubfx	x1, x4, #8, #8
    a184:      	lsr	w1, w1, #0
    a188:      	mov	x21, x8
    a18c:      	mov	x22, x0
    a190:      	mov	w0, w1
    a194:      	mov	w1, w2
    a198:      	bl	0xa198 <_stogir.locals.shape+0x1e8>
		000000000000a198:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a19c:      	lsr	w0, w0, #0
    a1a0:      	add	x16, sp, #0x10
    a1a4:      	ldr	w1, [x16, #0xc]
    a1a8:      	sxtw	x0, w0
    a1ac:      	sxtw	x1, w1
    a1b0:      	cmp	x1, #0x0
    a1b4:      	b.ne	0xa1bc <_stogir.locals.shape+0x20c>
    a1b8:      	mov	x1, x0
    a1bc:      	add	x16, sp, #0x10
    a1c0:      	ldr	w2, [x16, #0x8]
    a1c4:      	sxtw	x2, w2
    a1c8:      	cmp	x2, #0x0
    a1cc:      	cset	w3, eq
    a1d0:      	ubfx	x3, x3, #0, #8
    a1d4:      	cmp	x2, #0x0
    a1d8:      	b.le	0xa27c <_stogir.locals.shape+0x2cc>
    a1dc:      	add	x4, x22, #0x110
    a1e0:      	add	x5, x4, #0x28
    a1e4:      	ldr	x5, [x5, #0x8]
    a1e8:      	cmp	x2, x5
    a1ec:      	b.gt	0xa244 <_stogir.locals.shape+0x294>
    a1f0:      	sub	x2, x2, #0x1
    a1f4:      	mov	x17, #0x18              ; =24
    a1f8:      	mul	x2, x2, x17
    a1fc:      	ldr	x5, [x4, #0x28]
    a200:      	add	x2, x2, x5
    a204:      	ldr	x5, [x2]
    a208:      	ldr	x2, [x2, #0x8]
    a20c:      	ldr	x4, [x4, #0x8]
    a210:      	cmp	x5, #0x0
    a214:      	b.lt	0xa348 <_stogir.locals.shape+0x398>
    a218:      	cmp	x5, x4
    a21c:      	b.gt	0xa348 <_stogir.locals.shape+0x398>
    a220:      	cmp	x2, #0x0
    a224:      	b.lt	0xa348 <_stogir.locals.shape+0x398>
    a228:      	sub	x4, x4, x5
    a22c:      	cmp	x2, x4
    a230:      	b.gt	0xa348 <_stogir.locals.shape+0x398>
    a234:      	mov	x2, #0x1                ; =1
    a238:      	b	0xa34c <_stogir.locals.shape+0x39c>
    a23c:      	movz	x3, #0x0, lsl #48
    a240:      	b	0xa0a0 <_stogir.locals.shape+0xf0>
    a244:      	movz	x2, #0x0, lsl #48
    a248:      	lsr	w2, w2, #0
    a24c:      	lsr	x16, x2, #0
    a250:      	cmp	x16, #0x1
    a254:      	b.eq	0xa270 <_stogir.locals.shape+0x2c0>
    a258:      	b.lo	0xa260 <_stogir.locals.shape+0x2b0>
    a25c:      	b	0xa274 <_stogir.locals.shape+0x2c4>
    a260:      	cmp	x16, #0x0
    a264:      	b.eq	0xa26c <_stogir.locals.shape+0x2bc>
    a268:      	b	0xa274 <_stogir.locals.shape+0x2c4>
    a26c:      	b	0xa27c <_stogir.locals.shape+0x2cc>
    a270:      	b	0xa278 <_stogir.locals.shape+0x2c8>
    a274:      	b	0xa358 <_stogir.locals.shape+0x3a8>
    a278:      	mov	x3, #0x1                ; =1
    a27c:      	cmp	x19, #0x0
    a280:      	b.le	0xa084 <_stogir.locals.shape+0xd4>
    a284:      	add	x16, sp, #0x10
    a288:      	ldr	w2, [x16]
    a28c:      	uxtb	w2, w2
    a290:      	cmp	x2, #0x48
    a294:      	b.ne	0xa084 <_stogir.locals.shape+0xd4>
    a298:      	ldr	x2, [x22, #0x78]
    a29c:      	add	x2, x20, x2
    a2a0:      	ldr	w2, [x2]
    a2a4:      	sxtw	x2, w2
    a2a8:      	cmp	x2, #0x3
    a2ac:      	b.ne	0xa084 <_stogir.locals.shape+0xd4>
    a2b0:      	cmp	x0, #0x0
    a2b4:      	b.le	0xa084 <_stogir.locals.shape+0xd4>
    a2b8:      	cmp	x3, #0x0
    a2bc:      	b.eq	0xa084 <_stogir.locals.shape+0xd4>
    a2c0:      	cmp	x1, #0x0
    a2c4:      	b.le	0xa084 <_stogir.locals.shape+0xd4>
    a2c8:      	sub	x2, x1, #0x1
    a2cc:      	and	x2, x2, x1
    a2d0:      	cmp	x2, #0x0
    a2d4:      	b.ne	0xa084 <_stogir.locals.shape+0xd4>
    a2d8:      	add	x16, sp, #0x10
    a2dc:      	ldr	w2, [x16, #0x4]
    a2e0:      	sxtw	x2, w2
    a2e4:      	cmp	x2, #0x0
    a2e8:      	cset	w3, gt
    a2ec:      	movz	x16, #0x0, lsl #48
    a2f0:      	sub	x4, x16, x2
    a2f4:      	sub	x5, x4, #0x1
    a2f8:      	uxtb	w16, w3
    a2fc:      	cmp	w16, wzr
    a300:      	b.eq	0xa378 <_stogir.locals.shape+0x3c8>
    a304:      	ldr	x4, [x22, #0x8]
    a308:      	cmp	x2, x4
    a30c:      	b.ge	0xa3c0 <_stogir.locals.shape+0x410>
    a310:      	add	x4, x22, #0x78
    a314:      	ldr	x4, [x4, #0x8]
    a318:      	cmp	x2, x4
    a31c:      	b.ge	0xa494 <_stogir.locals.shape+0x4e4>
    a320:      	ldr	x4, [x22, #0x78]
    a324:      	add	x4, x4, x2, lsl #2
    a328:      	ldr	w4, [x4]
    a32c:      	sxtw	x4, w4
    a330:      	cmp	x4, #0x0
    a334:      	cset	w4, ge
    a338:      	ubfx	x4, x4, #0, #8
    a33c:      	b	0xa498 <_stogir.locals.shape+0x4e8>
    a340:      	movz	x3, #0x0, lsl #48
    a344:      	b	0xa080 <_stogir.locals.shape+0xd0>
    a348:      	movz	x2, #0x0, lsl #48
    a34c:      	b	0xa248 <_stogir.locals.shape+0x298>
    a350:      	brk	#0
    a354:      	b	0xa350 <_stogir.locals.shape+0x3a0>
    a358:      	brk	#0
    a35c:      	b	0xa358 <_stogir.locals.shape+0x3a8>
    a360:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000a360:  ARM64_RELOC_PAGE21	l_stogir.458
    a364:      	ldr	x16, [x16]
		000000000000a364:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    a368:      	orr	x0, x16, xzr
    a36c:      	mov	x2, #0x1                ; =1
    a370:      	mov	x1, #0x2c               ; =44
    a374:      	b	0xa098 <_stogir.locals.shape+0xe8>
    a378:      	cmp	x2, #0x0
    a37c:      	b.ge	0xa3c8 <_stogir.locals.shape+0x418>
    a380:      	add	x6, x22, #0x28
    a384:      	add	x7, x22, #0x50
    a388:      	ldr	x6, [x6, #0x8]
    a38c:      	ldr	x7, [x7, #0x8]
    a390:      	cmp	x6, x7
    a394:      	b.ne	0xa48c <_stogir.locals.shape+0x4dc>
    a398:      	cmp	x4, x6
    a39c:      	b.gt	0xa49c <_stogir.locals.shape+0x4ec>
    a3a0:      	ldr	x4, [x22, #0x50]
    a3a4:      	add	x4, x4, x5, lsl #2
    a3a8:      	ldr	w4, [x4]
    a3ac:      	sxtw	x4, w4
    a3b0:      	cmp	x4, #0x0
    a3b4:      	cset	w4, gt
    a3b8:      	ubfx	x4, x4, #0, #8
    a3bc:      	b	0xa4a0 <_stogir.locals.shape+0x4f0>
    a3c0:      	movz	x4, #0x0, lsl #48
    a3c4:      	b	0xa3cc <_stogir.locals.shape+0x41c>
    a3c8:      	movz	x4, #0x0, lsl #48
    a3cc:      	cmp	x4, #0x0
    a3d0:      	b.eq	0xa404 <_stogir.locals.shape+0x454>
    a3d4:      	uxtb	w16, w3
    a3d8:      	cmp	w16, wzr
    a3dc:      	b.eq	0xa3f0 <_stogir.locals.shape+0x440>
    a3e0:      	ldr	x3, [x22]
    a3e4:      	add	x2, x3, x2, lsl #4
    a3e8:      	ldr	x2, [x2]
    a3ec:      	b	0xa3fc <_stogir.locals.shape+0x44c>
    a3f0:      	ldr	x2, [x22, #0x28]
    a3f4:      	add	x2, x2, x5, lsl #4
    a3f8:      	ldr	x2, [x2]
    a3fc:      	mov	x3, #0x1                ; =1
    a400:      	b	0xa40c <_stogir.locals.shape+0x45c>
    a404:      	movz	x3, #0x0, lsl #48
    a408:      	movz	x2, #0x0, lsl #48
    a40c:      	lsr	w3, w3, #0
    a410:      	lsr	x16, x3, #0
    a414:      	cmp	x16, #0x1
    a418:      	b.eq	0xa434 <_stogir.locals.shape+0x484>
    a41c:      	b.lo	0xa424 <_stogir.locals.shape+0x474>
    a420:      	b	0xa438 <_stogir.locals.shape+0x488>
    a424:      	cmp	x16, #0x0
    a428:      	b.eq	0xa430 <_stogir.locals.shape+0x480>
    a42c:      	b	0xa438 <_stogir.locals.shape+0x488>
    a430:      	b	0xa43c <_stogir.locals.shape+0x48c>
    a434:      	b	0xa454 <_stogir.locals.shape+0x4a4>
    a438:      	b	0xa4d8 <_stogir.locals.shape+0x528>
    a43c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000a43c:  ARM64_RELOC_PAGE21	l_stogir.459
    a440:      	ldr	x16, [x16]
		000000000000a440:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    a444:      	orr	x0, x16, xzr
    a448:      	mov	x2, #0x1                ; =1
    a44c:      	mov	x1, #0x1d               ; =29
    a450:      	b	0xa374 <_stogir.locals.shape+0x3c4>
    a454:      	add	x16, sp, #0x10
    a458:      	ldr	w3, [x16, #0x4]
    a45c:      	sxtw	x3, w3
    a460:      	cmp	x3, #0x0
    a464:      	b.le	0xa360 <_stogir.locals.shape+0x3b0>
    a468:      	uxtb	w2, w2
    a46c:      	cmp	x2, #0x83
    a470:      	b.ge	0xa4a4 <_stogir.locals.shape+0x4f4>
    a474:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000a474:  ARM64_RELOC_PAGE21	l_stogir.460
    a478:      	ldr	x16, [x16]
		000000000000a478:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    a47c:      	orr	x3, x16, xzr
    a480:      	add	x2, x2, x3
    a484:      	ldrb	w2, [x2]
    a488:      	b	0xa4a8 <_stogir.locals.shape+0x4f8>
    a48c:      	movz	x4, #0x0, lsl #48
    a490:      	b	0xa3cc <_stogir.locals.shape+0x41c>
    a494:      	movz	x4, #0x0, lsl #48
    a498:      	b	0xa3c4 <_stogir.locals.shape+0x414>
    a49c:      	movz	x4, #0x0, lsl #48
    a4a0:      	b	0xa490 <_stogir.locals.shape+0x4e0>
    a4a4:      	movz	x2, #0x0, lsl #48
    a4a8:      	uxtb	w2, w2
    a4ac:      	and	x2, x2, #0x2
    a4b0:      	uxtb	w2, w2
    a4b4:      	cmp	x2, #0x0
    a4b8:      	cset	w2, eq
    a4bc:      	uxtb	w16, w2
    a4c0:      	cmp	w16, wzr
    a4c4:      	cset	x2, eq
    a4c8:      	cmp	x2, #0x0
    a4cc:      	b.eq	0xa360 <_stogir.locals.shape+0x3b0>
    a4d0:      	movz	x2, #0x0, lsl #48
    a4d4:      	b	0xa374 <_stogir.locals.shape+0x3c4>
    a4d8:      	brk	#0
    a4dc:      	b	0xa4d8 <_stogir.locals.shape+0x528>

000000000000a4e0 <_stogir.conversion.policy>:
    a4e0:      	sub	sp, sp, #0x70
    a4e4:      	str	x29, [sp]
    a4e8:      	str	x30, [sp, #0x8]
    a4ec:      	mov	x29, sp
    a4f0:      	str	x19, [sp, #0x20]
    a4f4:      	str	x20, [sp, #0x28]
    a4f8:      	str	x21, [sp, #0x30]
    a4fc:      	str	x22, [sp, #0x38]
    a500:      	str	x23, [sp, #0x40]
    a504:      	str	x24, [sp, #0x48]
    a508:      	str	x25, [sp, #0x50]
    a50c:      	str	x26, [sp, #0x58]
    a510:      	str	x27, [sp, #0x60]
    a514:      	str	x28, [sp, #0x68]
    a518:      	sxtw	x19, w0
    a51c:      	sxtw	x20, w1
    a520:      	sxtw	x21, w2
    a524:      	cmp	x19, #0x24
    a528:      	b.ne	0xa568 <_stogir.conversion.policy+0x88>
    a52c:      	cmp	x20, #0xf
    a530:      	b.le	0xa784 <_stogir.conversion.policy+0x2a4>
    a534:      	cmp	x20, #0x80
    a538:      	b.ge	0xa784 <_stogir.conversion.policy+0x2a4>
    a53c:      	and	x0, x20, #0xf
    a540:      	lsr	w0, w0, #0
    a544:      	sxtw	x0, w0
    a548:      	cmp	x0, #0x1
    a54c:      	b.lt	0xa784 <_stogir.conversion.policy+0x2a4>
    a550:      	cmp	x0, #0xd
    a554:      	b.gt	0xa784 <_stogir.conversion.policy+0x2a4>
    a558:      	mov	x22, #0x1               ; =1
    a55c:      	b	0xa564 <_stogir.conversion.policy+0x84>
    a560:      	movz	x22, #0x0, lsl #48
    a564:      	b	0xa56c <_stogir.conversion.policy+0x8c>
    a568:      	movz	x22, #0x0, lsl #48
    a56c:      	sxtw	x23, w3
    a570:      	cmp	x20, #0xd
    a574:      	cset	w24, eq
    a578:      	cmp	x20, #0xc
    a57c:      	cset	w25, eq
    a580:      	cmp	x23, #0x4
    a584:      	cset	w26, eq
    a588:      	cmp	x23, #0x8
    a58c:      	cset	w27, eq
    a590:      	cmp	x22, #0x0
    a594:      	b.eq	0xaa4c <_stogir.conversion.policy+0x56c>
    a598:      	lsr	w1, w1, #0
    a59c:      	lsr	w3, w3, #0
    a5a0:      	mov	w0, w1
    a5a4:      	mov	w1, w3
    a5a8:      	str	x8, [sp, #0x10]
    a5ac:      	mov	w28, w2
    a5b0:      	str	x19, [sp, #0x18]
    a5b4:      	mov	w19, w3
    a5b8:      	bl	0xa5b8 <_stogir.conversion.policy+0xd8>
		000000000000a5b8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a5bc:      	lsr	w0, w0, #0
    a5c0:      	sxtw	x0, w0
    a5c4:      	b	0xa5d4 <_stogir.conversion.policy+0xf4>
    a5c8:      	mov	x0, #0x1                ; =1
    a5cc:      	lsr	w0, w0, #0
    a5d0:      	sxtw	x0, w0
    a5d4:      	cmp	x21, #0xd
    a5d8:      	cset	w1, eq
    a5dc:      	cmp	x21, #0xc
    a5e0:      	cset	w2, eq
    a5e4:      	cmp	x22, #0x0
    a5e8:      	b.eq	0xaa60 <_stogir.conversion.policy+0x580>
    a5ec:      	lsr	w28, w28, #0
    a5f0:      	lsr	w19, w19, #0
    a5f4:      	mov	w22, w1
    a5f8:      	mov	w1, w19
    a5fc:      	mov	x19, x0
    a600:      	mov	w0, w28
    a604:      	mov	w28, w2
    a608:      	bl	0xa608 <_stogir.conversion.policy+0x128>
		000000000000a608:  ARM64_RELOC_BRANCH26	_stogir.types.size
    a60c:      	lsr	w0, w0, #0
    a610:      	sxtw	x0, w0
    a614:      	b	0xa624 <_stogir.conversion.policy+0x144>
    a618:      	mov	x23, #0x1               ; =1
    a61c:      	lsr	w23, w23, #0
    a620:      	sxtw	x0, w23
    a624:      	ldr	x1, [sp, #0x18]
    a628:      	cmp	x1, #0x21
    a62c:      	b.lt	0xa708 <_stogir.conversion.policy+0x228>
    a630:      	cmp	x1, #0x27
    a634:      	b.gt	0xa708 <_stogir.conversion.policy+0x228>
    a638:      	lsl	x2, x19, #3
    a63c:      	lsr	w2, w2, #0
    a640:      	sxtw	x2, w2
    a644:      	cmp	x2, #0x0
    a648:      	b.le	0xa708 <_stogir.conversion.policy+0x228>
    a64c:      	lsl	x0, x0, #3
    a650:      	lsr	w0, w0, #0
    a654:      	sxtw	x0, w0
    a658:      	cmp	x0, #0x0
    a65c:      	b.le	0xa708 <_stogir.conversion.policy+0x228>
    a660:      	cmp	x1, #0x26
    a664:      	cset	w3, eq
    a668:      	cmp	x20, #0x1
    a66c:      	cset	w4, ge
    a670:      	cmp	x20, #0xb
    a674:      	cset	w5, le
    a678:      	cmp	x21, #0x1
    a67c:      	cset	w6, ge
    a680:      	cmp	x21, #0xb
    a684:      	cset	w7, le
    a688:      	cmp	x1, #0x25
    a68c:      	b.lt	0xa908 <_stogir.conversion.policy+0x428>
    a690:      	ubfx	x8, x22, #0, #8
    a694:      	cmp	x1, #0x25
    a698:      	b.ne	0xa978 <_stogir.conversion.policy+0x498>
    a69c:      	uxtb	w16, w4
    a6a0:      	cmp	w16, wzr
    a6a4:      	b.eq	0xa970 <_stogir.conversion.policy+0x490>
    a6a8:      	uxtb	w16, w5
    a6ac:      	cmp	w16, wzr
    a6b0:      	b.eq	0xa970 <_stogir.conversion.policy+0x490>
    a6b4:      	uxtb	w16, w28
    a6b8:      	cmp	w16, wzr
    a6bc:      	b.eq	0xa6c4 <_stogir.conversion.policy+0x1e4>
    a6c0:      	mov	x8, #0x1                ; =1
    a6c4:      	b	0xa974 <_stogir.conversion.policy+0x494>
    a6c8:      	uxtb	w16, w26
    a6cc:      	cmp	w16, wzr
    a6d0:      	b.ne	0xa764 <_stogir.conversion.policy+0x284>
    a6d4:      	uxtb	w16, w27
    a6d8:      	cmp	w16, wzr
    a6dc:      	b.ne	0xa764 <_stogir.conversion.policy+0x284>
    a6e0:      	movn	x23, #0x0, lsl #48
    a6e4:      	b	0xa61c <_stogir.conversion.policy+0x13c>
    a6e8:      	uxtb	w16, w26
    a6ec:      	cmp	w16, wzr
    a6f0:      	b.ne	0xa774 <_stogir.conversion.policy+0x294>
    a6f4:      	uxtb	w16, w27
    a6f8:      	cmp	w16, wzr
    a6fc:      	b.ne	0xa774 <_stogir.conversion.policy+0x294>
    a700:      	movn	x0, #0x0, lsl #48
    a704:      	b	0xa5cc <_stogir.conversion.policy+0xec>
    a708:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000a708:  ARM64_RELOC_PAGE21	l_stogir.461
    a70c:      	ldr	x16, [x16]
		000000000000a70c:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    a710:      	orr	x0, x16, xzr
    a714:      	mov	x1, #0x1                ; =1
    a718:      	mov	x2, #0x22               ; =34
    a71c:      	ldr	x3, [sp, #0x10]
    a720:      	str	x1, [x3]
    a724:      	str	x0, [x3, #0x8]
    a728:      	str	x2, [x3, #0x10]
    a72c:      	ldr	x19, [sp, #0x20]
    a730:      	ldr	x20, [sp, #0x28]
    a734:      	ldr	x21, [sp, #0x30]
    a738:      	ldr	x22, [sp, #0x38]
    a73c:      	ldr	x23, [sp, #0x40]
    a740:      	ldr	x24, [sp, #0x48]
    a744:      	ldr	x25, [sp, #0x50]
    a748:      	ldr	x26, [sp, #0x58]
    a74c:      	ldr	x27, [sp, #0x60]
    a750:      	ldr	x28, [sp, #0x68]
    a754:      	ldr	x29, [sp]
    a758:      	ldr	x30, [sp, #0x8]
    a75c:      	add	sp, sp, #0x70
    a760:      	ret
    a764:      	cmp	x21, #0x0
    a768:      	b.ne	0xa7c0 <_stogir.conversion.policy+0x2e0>
    a76c:      	movz	x23, #0x0, lsl #48
    a770:      	b	0xa61c <_stogir.conversion.policy+0x13c>
    a774:      	cmp	x20, #0x0
    a778:      	b.ne	0xa838 <_stogir.conversion.policy+0x358>
    a77c:      	movz	x0, #0x0, lsl #48
    a780:      	b	0xa5cc <_stogir.conversion.policy+0xec>
    a784:      	cmp	x21, #0xf
    a788:      	b.le	0xa560 <_stogir.conversion.policy+0x80>
    a78c:      	cmp	x21, #0x80
    a790:      	b.ge	0xa7b8 <_stogir.conversion.policy+0x2d8>
    a794:      	and	x0, x21, #0xf
    a798:      	lsr	w0, w0, #0
    a79c:      	sxtw	x0, w0
    a7a0:      	cmp	x0, #0x1
    a7a4:      	b.lt	0xa8b0 <_stogir.conversion.policy+0x3d0>
    a7a8:      	cmp	x0, #0xd
    a7ac:      	cset	w0, le
    a7b0:      	ubfx	x22, x0, #0, #8
    a7b4:      	b	0xa8b4 <_stogir.conversion.policy+0x3d4>
    a7b8:      	movz	x22, #0x0, lsl #48
    a7bc:      	b	0xa564 <_stogir.conversion.policy+0x84>
    a7c0:      	cmp	x21, #0x1
    a7c4:      	b.eq	0xa618 <_stogir.conversion.policy+0x138>
    a7c8:      	cmp	x21, #0x2
    a7cc:      	b.eq	0xa618 <_stogir.conversion.policy+0x138>
    a7d0:      	cmp	x21, #0x7
    a7d4:      	b.eq	0xa618 <_stogir.conversion.policy+0x138>
    a7d8:      	cmp	x21, #0x8
    a7dc:      	b.eq	0xa618 <_stogir.conversion.policy+0x138>
    a7e0:      	cmp	x21, #0x3
    a7e4:      	b.eq	0xa9a4 <_stogir.conversion.policy+0x4c4>
    a7e8:      	cmp	x21, #0x9
    a7ec:      	b.eq	0xa9a4 <_stogir.conversion.policy+0x4c4>
    a7f0:      	cmp	x21, #0x4
    a7f4:      	b.eq	0xaa14 <_stogir.conversion.policy+0x534>
    a7f8:      	cmp	x21, #0xa
    a7fc:      	b.eq	0xaa14 <_stogir.conversion.policy+0x534>
    a800:      	uxtb	w16, w22
    a804:      	cmp	w16, wzr
    a808:      	b.ne	0xaa14 <_stogir.conversion.policy+0x534>
    a80c:      	cmp	x21, #0x5
    a810:      	b.eq	0xaa34 <_stogir.conversion.policy+0x554>
    a814:      	cmp	x21, #0xb
    a818:      	b.eq	0xaa34 <_stogir.conversion.policy+0x554>
    a81c:      	uxtb	w16, w28
    a820:      	cmp	w16, wzr
    a824:      	b.ne	0xaa34 <_stogir.conversion.policy+0x554>
    a828:      	cmp	x21, #0x6
    a82c:      	b.eq	0xa834 <_stogir.conversion.policy+0x354>
    a830:      	movn	x23, #0x0, lsl #48
    a834:      	b	0xaa38 <_stogir.conversion.policy+0x558>
    a838:      	cmp	x20, #0x1
    a83c:      	b.eq	0xa5c8 <_stogir.conversion.policy+0xe8>
    a840:      	cmp	x20, #0x2
    a844:      	b.eq	0xa5c8 <_stogir.conversion.policy+0xe8>
    a848:      	cmp	x20, #0x7
    a84c:      	b.eq	0xa5c8 <_stogir.conversion.policy+0xe8>
    a850:      	cmp	x20, #0x8
    a854:      	b.eq	0xa5c8 <_stogir.conversion.policy+0xe8>
    a858:      	cmp	x20, #0x3
    a85c:      	b.eq	0xa9ac <_stogir.conversion.policy+0x4cc>
    a860:      	cmp	x20, #0x9
    a864:      	b.eq	0xa9ac <_stogir.conversion.policy+0x4cc>
    a868:      	cmp	x20, #0x4
    a86c:      	b.eq	0xaa1c <_stogir.conversion.policy+0x53c>
    a870:      	cmp	x20, #0xa
    a874:      	b.eq	0xaa1c <_stogir.conversion.policy+0x53c>
    a878:      	uxtb	w16, w24
    a87c:      	cmp	w16, wzr
    a880:      	b.ne	0xaa1c <_stogir.conversion.policy+0x53c>
    a884:      	cmp	x20, #0x5
    a888:      	b.eq	0xaa3c <_stogir.conversion.policy+0x55c>
    a88c:      	cmp	x20, #0xb
    a890:      	b.eq	0xaa3c <_stogir.conversion.policy+0x55c>
    a894:      	uxtb	w16, w25
    a898:      	cmp	w16, wzr
    a89c:      	b.ne	0xaa3c <_stogir.conversion.policy+0x55c>
    a8a0:      	cmp	x20, #0x6
    a8a4:      	b.ne	0xaa44 <_stogir.conversion.policy+0x564>
    a8a8:      	mov	x0, x23
    a8ac:      	b	0xaa48 <_stogir.conversion.policy+0x568>
    a8b0:      	movz	x22, #0x0, lsl #48
    a8b4:      	b	0xa7bc <_stogir.conversion.policy+0x2dc>
    a8b8:      	mov	x4, #0x1                ; =1
    a8bc:      	cmp	x4, #0x0
    a8c0:      	b.ne	0xa708 <_stogir.conversion.policy+0x228>
    a8c4:      	cmp	x1, #0x23
    a8c8:      	b.eq	0xa8d8 <_stogir.conversion.policy+0x3f8>
    a8cc:      	uxtb	w16, w3
    a8d0:      	cmp	w16, wzr
    a8d4:      	b.eq	0xa8dc <_stogir.conversion.policy+0x3fc>
    a8d8:      	mov	x2, x0
    a8dc:      	and	x0, x2, #0xffffffff
    a8e0:      	movz	x1, #0x0, lsl #48
    a8e4:      	movz	x2, #0x0, lsl #48
    a8e8:      	b	0xa71c <_stogir.conversion.policy+0x23c>
    a8ec:      	movz	x8, #0x0, lsl #48
    a8f0:      	cmp	x8, #0x0
    a8f4:      	cset	w4, ne
    a8f8:      	uxtb	w16, w4
    a8fc:      	cmp	w16, wzr
    a900:      	cset	x4, eq
    a904:      	b	0xa8bc <_stogir.conversion.policy+0x3dc>
    a908:      	cmp	x1, #0x24
    a90c:      	b.ne	0xa928 <_stogir.conversion.policy+0x448>
    a910:      	cmp	x2, x0
    a914:      	cset	w4, eq
    a918:      	uxtb	w16, w4
    a91c:      	cmp	w16, wzr
    a920:      	cset	x4, eq
    a924:      	b	0xa8bc <_stogir.conversion.policy+0x3dc>
    a928:      	uxtb	w16, w4
    a92c:      	cmp	w16, wzr
    a930:      	b.eq	0xa8b8 <_stogir.conversion.policy+0x3d8>
    a934:      	uxtb	w16, w5
    a938:      	cmp	w16, wzr
    a93c:      	b.eq	0xa8b8 <_stogir.conversion.policy+0x3d8>
    a940:      	uxtb	w16, w6
    a944:      	cmp	w16, wzr
    a948:      	b.eq	0xa9e4 <_stogir.conversion.policy+0x504>
    a94c:      	uxtb	w16, w7
    a950:      	cmp	w16, wzr
    a954:      	b.eq	0xa9e4 <_stogir.conversion.policy+0x504>
    a958:      	cmp	x1, #0x23
    a95c:      	b.ne	0xaa24 <_stogir.conversion.policy+0x544>
    a960:      	cmp	x0, x2
    a964:      	cset	w4, ge
    a968:      	ubfx	x4, x4, #0, #8
    a96c:      	b	0xaa30 <_stogir.conversion.policy+0x550>
    a970:      	movz	x8, #0x0, lsl #48
    a974:      	b	0xa8f0 <_stogir.conversion.policy+0x410>
    a978:      	uxtb	w16, w3
    a97c:      	cmp	w16, wzr
    a980:      	b.eq	0xa9bc <_stogir.conversion.policy+0x4dc>
    a984:      	uxtb	w16, w25
    a988:      	cmp	w16, wzr
    a98c:      	b.ne	0xaa00 <_stogir.conversion.policy+0x520>
    a990:      	uxtb	w16, w24
    a994:      	cmp	w16, wzr
    a998:      	b.ne	0xaa00 <_stogir.conversion.policy+0x520>
    a99c:      	movz	x8, #0x0, lsl #48
    a9a0:      	b	0xa9b8 <_stogir.conversion.policy+0x4d8>
    a9a4:      	mov	x23, #0x2               ; =2
    a9a8:      	b	0xa61c <_stogir.conversion.policy+0x13c>
    a9ac:      	mov	x0, #0x2                ; =2
    a9b0:      	b	0xa5cc <_stogir.conversion.policy+0xec>
    a9b4:      	movz	x8, #0x0, lsl #48
    a9b8:      	b	0xa8f0 <_stogir.conversion.policy+0x410>
    a9bc:      	cmp	x1, #0x27
    a9c0:      	b.ne	0xa8ec <_stogir.conversion.policy+0x40c>
    a9c4:      	uxtb	w16, w25
    a9c8:      	cmp	w16, wzr
    a9cc:      	b.ne	0xa9ec <_stogir.conversion.policy+0x50c>
    a9d0:      	uxtb	w16, w24
    a9d4:      	cmp	w16, wzr
    a9d8:      	b.ne	0xa9ec <_stogir.conversion.policy+0x50c>
    a9dc:      	movz	x8, #0x0, lsl #48
    a9e0:      	b	0xa9fc <_stogir.conversion.policy+0x51c>
    a9e4:      	mov	x4, #0x1                ; =1
    a9e8:      	b	0xa8bc <_stogir.conversion.policy+0x3dc>
    a9ec:      	uxtb	w16, w28
    a9f0:      	cmp	w16, wzr
    a9f4:      	b.eq	0xa9fc <_stogir.conversion.policy+0x51c>
    a9f8:      	mov	x8, #0x1                ; =1
    a9fc:      	b	0xa8f0 <_stogir.conversion.policy+0x410>
    aa00:      	uxtb	w16, w6
    aa04:      	cmp	w16, wzr
    aa08:      	b.eq	0xa9b4 <_stogir.conversion.policy+0x4d4>
    aa0c:      	ubfx	x8, x7, #0, #8
    aa10:      	b	0xa9b8 <_stogir.conversion.policy+0x4d8>
    aa14:      	mov	x23, #0x4               ; =4
    aa18:      	b	0xa9a8 <_stogir.conversion.policy+0x4c8>
    aa1c:      	mov	x0, #0x4                ; =4
    aa20:      	b	0xa9b0 <_stogir.conversion.policy+0x4d0>
    aa24:      	cmp	x0, x2
    aa28:      	cset	w4, le
    aa2c:      	ubfx	x4, x4, #0, #8
    aa30:      	b	0xa9e8 <_stogir.conversion.policy+0x508>
    aa34:      	mov	x23, #0x8               ; =8
    aa38:      	b	0xaa18 <_stogir.conversion.policy+0x538>
    aa3c:      	mov	x0, #0x8                ; =8
    aa40:      	b	0xaa20 <_stogir.conversion.policy+0x540>
    aa44:      	movn	x0, #0x0, lsl #48
    aa48:      	b	0xaa40 <_stogir.conversion.policy+0x560>
    aa4c:      	str	x8, [sp, #0x10]
    aa50:      	str	x19, [sp, #0x18]
    aa54:      	mov	w28, w2
    aa58:      	mov	w19, w3
    aa5c:      	b	0xa6e8 <_stogir.conversion.policy+0x208>
    aa60:      	mov	x19, x0
    aa64:      	mov	w22, w1
    aa68:      	mov	w28, w2
    aa6c:      	b	0xa6c8 <_stogir.conversion.policy+0x1e8>

000000000000aa70 <_stogir.conditional.operands>:
    aa70:      	sub	sp, sp, #0x30
    aa74:      	str	x19, [sp, #0x20]
    aa78:      	str	x20, [sp, #0x28]
    aa7c:      	sxtw	x1, w1
    aa80:      	cmp	x1, #0x0
    aa84:      	b.eq	0xaad8 <_stogir.conditional.operands+0x68>
    aa88:      	cmp	x1, #0x0
    aa8c:      	b.lt	0xaaac <_stogir.conditional.operands+0x3c>
    aa90:      	cmp	x1, #0xd
    aa94:      	b.gt	0xaaac <_stogir.conditional.operands+0x3c>
    aa98:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000aa98:  ARM64_RELOC_PAGE21	l_stogir.462
    aa9c:      	ldr	x16, [x16]
		000000000000aa9c:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    aaa0:      	orr	x5, x16, xzr
    aaa4:      	movz	x6, #0x0, lsl #48
    aaa8:      	b	0xaae8 <_stogir.conditional.operands+0x78>
    aaac:      	cmp	x1, #0xf
    aab0:      	b.le	0xaad8 <_stogir.conditional.operands+0x68>
    aab4:      	cmp	x1, #0x80
    aab8:      	b.ge	0xaad8 <_stogir.conditional.operands+0x68>
    aabc:      	and	x5, x1, #0xf
    aac0:      	lsr	w5, w5, #0
    aac4:      	sxtw	x5, w5
    aac8:      	cmp	x5, #0x1
    aacc:      	b.lt	0xaad8 <_stogir.conditional.operands+0x68>
    aad0:      	cmp	x5, #0xd
    aad4:      	b.le	0xaa98 <_stogir.conditional.operands+0x28>
    aad8:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000aad8:  ARM64_RELOC_PAGE21	l_stogir.463
    aadc:      	ldr	x16, [x16]
		000000000000aadc:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    aae0:      	orr	x5, x16, xzr
    aae4:      	mov	x6, #0x2b               ; =43
    aae8:      	sxtw	x2, w2
    aaec:      	cmp	x2, #0x0
    aaf0:      	cset	w7, gt
    aaf4:      	movz	x16, #0x0, lsl #48
    aaf8:      	sub	x9, x16, x2
    aafc:      	sub	x10, x9, #0x1
    ab00:      	uxtb	w16, w7
    ab04:      	cmp	w16, wzr
    ab08:      	b.eq	0xab48 <_stogir.conditional.operands+0xd8>
    ab0c:      	ldr	x9, [x0, #0x8]
    ab10:      	cmp	x2, x9
    ab14:      	b.ge	0xaba0 <_stogir.conditional.operands+0x130>
    ab18:      	add	x9, x0, #0x78
    ab1c:      	ldr	x9, [x9, #0x8]
    ab20:      	cmp	x2, x9
    ab24:      	b.ge	0xaecc <_stogir.conditional.operands+0x45c>
    ab28:      	ldr	x9, [x0, #0x78]
    ab2c:      	add	x9, x9, x2, lsl #2
    ab30:      	ldr	w9, [x9]
    ab34:      	sxtw	x9, w9
    ab38:      	cmp	x9, #0x0
    ab3c:      	cset	w9, ge
    ab40:      	ubfx	x9, x9, #0, #8
    ab44:      	b	0xaed0 <_stogir.conditional.operands+0x460>
    ab48:      	cmp	x2, #0x0
    ab4c:      	b.ge	0xaba8 <_stogir.conditional.operands+0x138>
    ab50:      	add	x11, x0, #0x28
    ab54:      	add	x12, x0, #0x50
    ab58:      	ldr	x11, [x11, #0x8]
    ab5c:      	ldr	x12, [x12, #0x8]
    ab60:      	cmp	x11, x12
    ab64:      	b.ne	0xab90 <_stogir.conditional.operands+0x120>
    ab68:      	cmp	x9, x11
    ab6c:      	b.gt	0xaed4 <_stogir.conditional.operands+0x464>
    ab70:      	ldr	x9, [x0, #0x50]
    ab74:      	add	x9, x9, x10, lsl #2
    ab78:      	ldr	w9, [x9]
    ab7c:      	sxtw	x9, w9
    ab80:      	cmp	x9, #0x0
    ab84:      	cset	w9, gt
    ab88:      	ubfx	x9, x9, #0, #8
    ab8c:      	b	0xaed8 <_stogir.conditional.operands+0x468>
    ab90:      	movz	x9, #0x0, lsl #48
    ab94:      	b	0xabac <_stogir.conditional.operands+0x13c>
    ab98:      	movz	x14, #0x0, lsl #48
    ab9c:      	b	0xac3c <_stogir.conditional.operands+0x1cc>
    aba0:      	movz	x9, #0x0, lsl #48
    aba4:      	b	0xabac <_stogir.conditional.operands+0x13c>
    aba8:      	movz	x9, #0x0, lsl #48
    abac:      	cmp	x9, #0x0
    abb0:      	b.eq	0xabe4 <_stogir.conditional.operands+0x174>
    abb4:      	uxtb	w16, w7
    abb8:      	cmp	w16, wzr
    abbc:      	b.eq	0xabd0 <_stogir.conditional.operands+0x160>
    abc0:      	ldr	x7, [x0]
    abc4:      	add	x2, x7, x2, lsl #4
    abc8:      	ldr	x2, [x2]
    abcc:      	b	0xabdc <_stogir.conditional.operands+0x16c>
    abd0:      	ldr	x2, [x0, #0x28]
    abd4:      	add	x2, x2, x10, lsl #4
    abd8:      	ldr	x2, [x2]
    abdc:      	mov	x7, #0x1                ; =1
    abe0:      	b	0xabec <_stogir.conditional.operands+0x17c>
    abe4:      	movz	x7, #0x0, lsl #48
    abe8:      	movz	x2, #0x0, lsl #48
    abec:      	lsr	w7, w7, #0
    abf0:      	lsr	x16, x7, #0
    abf4:      	cmp	x16, #0x1
    abf8:      	b.eq	0xac14 <_stogir.conditional.operands+0x1a4>
    abfc:      	b.lo	0xac04 <_stogir.conditional.operands+0x194>
    ac00:      	b	0xac18 <_stogir.conditional.operands+0x1a8>
    ac04:      	cmp	x16, #0x0
    ac08:      	b.eq	0xac10 <_stogir.conditional.operands+0x1a0>
    ac0c:      	b	0xac18 <_stogir.conditional.operands+0x1a8>
    ac10:      	b	0xac1c <_stogir.conditional.operands+0x1ac>
    ac14:      	b	0xac40 <_stogir.conditional.operands+0x1d0>
    ac18:      	b	0xaeec <_stogir.conditional.operands+0x47c>
    ac1c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000ac1c:  ARM64_RELOC_PAGE21	l_stogir.464
    ac20:      	ldr	x16, [x16]
		000000000000ac20:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    ac24:      	orr	x5, x16, xzr
    ac28:      	mov	x6, #0x16               ; =22
    ac2c:      	b	0xac84 <_stogir.conditional.operands+0x214>
    ac30:      	movz	x14, #0x0, lsl #48
    ac34:      	b	0xace4 <_stogir.conditional.operands+0x274>
    ac38:      	movz	x14, #0x0, lsl #48
    ac3c:      	b	0xacec <_stogir.conditional.operands+0x27c>
    ac40:      	uxtb	w7, w2
    ac44:      	cmp	x7, #0x48
    ac48:      	b.eq	0xac74 <_stogir.conditional.operands+0x204>
    ac4c:      	cmp	x7, #0x46
    ac50:      	b.eq	0xac74 <_stogir.conditional.operands+0x204>
    ac54:      	lsr	w2, w2, #0
    ac58:      	orr	x7, x2, xzr
    ac5c:      	ubfx	x7, x7, #8, #8
    ac60:      	cmp	x7, #0x0
    ac64:      	b.eq	0xac74 <_stogir.conditional.operands+0x204>
    ac68:      	ubfx	x2, x2, #8, #8
    ac6c:      	cmp	x2, #0xd
    ac70:      	b.le	0xac84 <_stogir.conditional.operands+0x214>
    ac74:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000ac74:  ARM64_RELOC_PAGE21	l_stogir.465
    ac78:      	ldr	x16, [x16]
		000000000000ac78:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    ac7c:      	orr	x5, x16, xzr
    ac80:      	mov	x6, #0x2a               ; =42
    ac84:      	add	x16, sp, #0x10
    ac88:      	orr	x2, x16, xzr
    ac8c:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000ac8c:  ARM64_RELOC_PAGE21	l_stogir.466
    ac90:      	ldr	x16, [x16]
		000000000000ac90:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    ac94:      	orr	x7, x16, xzr
    ac98:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000ac98:  ARM64_RELOC_PAGE21	l_stogir.467
    ac9c:      	ldr	x16, [x16]
		000000000000ac9c:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    aca0:      	orr	x9, x16, xzr
    aca4:      	lsr	w3, w3, #0
    aca8:      	lsr	w4, w4, #0
    acac:      	add	x10, x0, #0x78
    acb0:      	add	x11, x0, #0x28
    acb4:      	add	x12, x0, #0x50
    acb8:      	mov	x16, sp
    acbc:      	str	w3, [x16]
    acc0:      	mov	x16, sp
    acc4:      	str	w4, [x16, #0x4]
    acc8:      	mov	x16, sp
    accc:      	ldr	x3, [x16]
    acd0:      	add	x16, sp, #0x10
    acd4:      	str	x3, [x16]
    acd8:      	movz	x3, #0x0, lsl #48
    acdc:      	b	0xad94 <_stogir.conditional.operands+0x324>
    ace0:      	movz	x14, #0x0, lsl #48
    ace4:      	b	0xacec <_stogir.conditional.operands+0x27c>
    ace8:      	movz	x14, #0x0, lsl #48
    acec:      	cmp	x14, #0x0
    acf0:      	b.eq	0xad24 <_stogir.conditional.operands+0x2b4>
    acf4:      	uxtb	w16, w4
    acf8:      	cmp	w16, wzr
    acfc:      	b.eq	0xad10 <_stogir.conditional.operands+0x2a0>
    ad00:      	ldr	x4, [x0]
    ad04:      	add	x4, x4, x13, lsl #4
    ad08:      	ldr	x4, [x4]
    ad0c:      	b	0xad1c <_stogir.conditional.operands+0x2ac>
    ad10:      	ldr	x4, [x0, #0x28]
    ad14:      	add	x4, x4, x15, lsl #4
    ad18:      	ldr	x4, [x4]
    ad1c:      	mov	x13, #0x1               ; =1
    ad20:      	b	0xad2c <_stogir.conditional.operands+0x2bc>
    ad24:      	movz	x13, #0x0, lsl #48
    ad28:      	movz	x4, #0x0, lsl #48
    ad2c:      	lsr	w13, w13, #0
    ad30:      	lsr	x16, x13, #0
    ad34:      	cmp	x16, #0x1
    ad38:      	b.eq	0xad54 <_stogir.conditional.operands+0x2e4>
    ad3c:      	b.lo	0xad44 <_stogir.conditional.operands+0x2d4>
    ad40:      	b	0xad58 <_stogir.conditional.operands+0x2e8>
    ad44:      	cmp	x16, #0x0
    ad48:      	b.eq	0xad50 <_stogir.conditional.operands+0x2e0>
    ad4c:      	b	0xad58 <_stogir.conditional.operands+0x2e8>
    ad50:      	b	0xad5c <_stogir.conditional.operands+0x2ec>
    ad54:      	b	0xad68 <_stogir.conditional.operands+0x2f8>
    ad58:      	b	0xaee4 <_stogir.conditional.operands+0x474>
    ad5c:      	mov	x5, x7
    ad60:      	mov	x6, #0x10               ; =16
    ad64:      	b	0xad94 <_stogir.conditional.operands+0x324>
    ad68:      	uxtb	w13, w4
    ad6c:      	cmp	x13, #0x48
    ad70:      	b.eq	0xad8c <_stogir.conditional.operands+0x31c>
    ad74:      	cmp	x13, #0x46
    ad78:      	b.eq	0xad8c <_stogir.conditional.operands+0x31c>
    ad7c:      	lsr	w4, w4, #0
    ad80:      	ubfx	x4, x4, #8, #8
    ad84:      	cmp	x4, x1
    ad88:      	b.eq	0xad94 <_stogir.conditional.operands+0x324>
    ad8c:      	mov	x5, x9
    ad90:      	mov	x6, #0x21               ; =33
    ad94:      	cmp	x3, #0x2
    ad98:      	b.ge	0xadbc <_stogir.conditional.operands+0x34c>
    ad9c:      	add	x4, x3, #0x1
    ada0:      	add	x3, x2, x3, lsl #2
    ada4:      	ldr	w3, [x3]
    ada8:      	sxtw	x3, w3
    adac:      	and	x13, x3, #0xffffffff
    adb0:      	mov	x3, x4
    adb4:      	mov	x4, #0x1                ; =1
    adb8:      	b	0xadc4 <_stogir.conditional.operands+0x354>
    adbc:      	movz	x4, #0x0, lsl #48
    adc0:      	movz	x13, #0x0, lsl #48
    adc4:      	lsr	w4, w4, #0
    adc8:      	lsr	x16, x4, #0
    adcc:      	cmp	x16, #0x1
    add0:      	b.eq	0xadec <_stogir.conditional.operands+0x37c>
    add4:      	b.lo	0xaddc <_stogir.conditional.operands+0x36c>
    add8:      	b	0xadf0 <_stogir.conditional.operands+0x380>
    addc:      	cmp	x16, #0x0
    ade0:      	b.eq	0xade8 <_stogir.conditional.operands+0x378>
    ade4:      	b	0xadf0 <_stogir.conditional.operands+0x380>
    ade8:      	b	0xae54 <_stogir.conditional.operands+0x3e4>
    adec:      	b	0xadf4 <_stogir.conditional.operands+0x384>
    adf0:      	b	0xaedc <_stogir.conditional.operands+0x46c>
    adf4:      	lsr	w13, w13, #0
    adf8:      	sxtw	x13, w13
    adfc:      	cmp	x13, #0x0
    ae00:      	cset	w4, gt
    ae04:      	movz	x16, #0x0, lsl #48
    ae08:      	sub	x14, x16, x13
    ae0c:      	sub	x15, x14, #0x1
    ae10:      	uxtb	w16, w4
    ae14:      	cmp	w16, wzr
    ae18:      	b.eq	0xae8c <_stogir.conditional.operands+0x41c>
    ae1c:      	ldr	x14, [x0, #0x8]
    ae20:      	cmp	x13, x14
    ae24:      	b.ge	0xace0 <_stogir.conditional.operands+0x270>
    ae28:      	ldr	x14, [x10, #0x8]
    ae2c:      	cmp	x13, x14
    ae30:      	b.ge	0xac30 <_stogir.conditional.operands+0x1c0>
    ae34:      	ldr	x14, [x0, #0x78]
    ae38:      	add	x14, x14, x13, lsl #2
    ae3c:      	ldr	w14, [x14]
    ae40:      	sxtw	x14, w14
    ae44:      	cmp	x14, #0x0
    ae48:      	cset	w14, ge
    ae4c:      	ubfx	x14, x14, #0, #8
    ae50:      	b	0xac34 <_stogir.conditional.operands+0x1c4>
    ae54:      	cmp	x6, #0x0
    ae58:      	b.ne	0xae6c <_stogir.conditional.operands+0x3fc>
    ae5c:      	and	x5, x1, #0xffffffff
    ae60:      	movz	x0, #0x0, lsl #48
    ae64:      	movz	x6, #0x0, lsl #48
    ae68:      	b	0xae70 <_stogir.conditional.operands+0x400>
    ae6c:      	mov	x0, #0x1                ; =1
    ae70:      	str	x0, [x8]
    ae74:      	str	x5, [x8, #0x8]
    ae78:      	str	x6, [x8, #0x10]
    ae7c:      	ldr	x19, [sp, #0x20]
    ae80:      	ldr	x20, [sp, #0x28]
    ae84:      	add	sp, sp, #0x30
    ae88:      	ret
    ae8c:      	cmp	x13, #0x0
    ae90:      	b.ge	0xace8 <_stogir.conditional.operands+0x278>
    ae94:      	ldr	x19, [x11, #0x8]
    ae98:      	ldr	x20, [x12, #0x8]
    ae9c:      	cmp	x19, x20
    aea0:      	b.ne	0xac38 <_stogir.conditional.operands+0x1c8>
    aea4:      	cmp	x14, x19
    aea8:      	b.gt	0xab98 <_stogir.conditional.operands+0x128>
    aeac:      	ldr	x14, [x0, #0x50]
    aeb0:      	add	x14, x14, x15, lsl #2
    aeb4:      	ldr	w14, [x14]
    aeb8:      	sxtw	x14, w14
    aebc:      	cmp	x14, #0x0
    aec0:      	cset	w14, gt
    aec4:      	ubfx	x14, x14, #0, #8
    aec8:      	b	0xab9c <_stogir.conditional.operands+0x12c>
    aecc:      	movz	x9, #0x0, lsl #48
    aed0:      	b	0xaba4 <_stogir.conditional.operands+0x134>
    aed4:      	movz	x9, #0x0, lsl #48
    aed8:      	b	0xab94 <_stogir.conditional.operands+0x124>
    aedc:      	brk	#0
    aee0:      	b	0xaedc <_stogir.conditional.operands+0x46c>
    aee4:      	brk	#0
    aee8:      	b	0xaee4 <_stogir.conditional.operands+0x474>
    aeec:      	brk	#0
    aef0:      	b	0xaeec <_stogir.conditional.operands+0x47c>

000000000000aef4 <_stogir.floating.operands>:
    aef4:      	sub	sp, sp, #0x90
    aef8:      	str	x29, [sp]
    aefc:      	str	x30, [sp, #0x8]
    af00:      	mov	x29, sp
    af04:      	str	x19, [sp, #0x60]
    af08:      	str	x20, [sp, #0x68]
    af0c:      	str	x21, [sp, #0x70]
    af10:      	str	x22, [sp, #0x78]
    af14:      	str	x23, [sp, #0x80]
    af18:      	sxtw	x1, w1
    af1c:      	sxtw	x19, w2
    af20:      	cmp	x1, #0x1f
    af24:      	cset	w2, eq
    af28:      	cmp	x1, #0x20
    af2c:      	cset	w6, eq
    af30:      	cmp	x1, #0xe
    af34:      	b.lt	0xaf64 <_stogir.floating.operands+0x70>
    af38:      	cmp	x1, #0x19
    af3c:      	b.gt	0xaf64 <_stogir.floating.operands+0x70>
    af40:      	cmp	x19, #0xc
    af44:      	b.eq	0xafa0 <_stogir.floating.operands+0xac>
    af48:      	cmp	x19, #0xd
    af4c:      	b.eq	0xafa0 <_stogir.floating.operands+0xac>
    af50:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000af50:  ARM64_RELOC_PAGE21	l_stogir.468
    af54:      	ldr	x16, [x16]
		000000000000af54:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    af58:      	orr	x20, x16, xzr
    af5c:      	mov	x21, #0x22              ; =34
    af60:      	b	0xafb0 <_stogir.floating.operands+0xbc>
    af64:      	uxtb	w16, w2
    af68:      	cmp	w16, wzr
    af6c:      	b.ne	0xaf40 <_stogir.floating.operands+0x4c>
    af70:      	uxtb	w16, w6
    af74:      	cmp	w16, wzr
    af78:      	b.ne	0xaf40 <_stogir.floating.operands+0x4c>
    af7c:      	cmp	x1, #0x1a
    af80:      	b.lt	0xaf8c <_stogir.floating.operands+0x98>
    af84:      	cmp	x1, #0x1d
    af88:      	b.le	0xaf40 <_stogir.floating.operands+0x4c>
    af8c:      	cmp	x1, #0x3a
    af90:      	b.eq	0xaf40 <_stogir.floating.operands+0x4c>
    af94:      	cmp	x1, #0x3b
    af98:      	b.eq	0xaf40 <_stogir.floating.operands+0x4c>
    af9c:      	b	0xaf50 <_stogir.floating.operands+0x5c>
    afa0:      	adrp	x16, 0xa000 <_stogir.locals.shape+0x50>
		000000000000afa0:  ARM64_RELOC_PAGE21	l_stogir.469
    afa4:      	ldr	x16, [x16]
		000000000000afa4:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    afa8:      	orr	x20, x16, xzr
    afac:      	movz	x21, #0x0, lsl #48
    afb0:      	lsr	w3, w3, #0
    afb4:      	add	x16, sp, #0x10
    afb8:      	str	w3, [x16]
    afbc:      	uxtb	w16, w2
    afc0:      	cmp	w16, wzr
    afc4:      	b.ne	0xb03c <_stogir.floating.operands+0x148>
    afc8:      	uxtb	w16, w6
    afcc:      	cmp	w16, wzr
    afd0:      	b.ne	0xb03c <_stogir.floating.operands+0x148>
    afd4:      	sxtw	x3, w4
    afd8:      	b	0xb040 <_stogir.floating.operands+0x14c>
    afdc:      	movz	x1, #0x0, lsl #48
    afe0:      	uxtb	w1, w1
    afe4:      	and	x1, x1, #0x2
    afe8:      	uxtb	w1, w1
    afec:      	cmp	x1, #0x0
    aff0:      	cset	w1, eq
    aff4:      	uxtb	w16, w1
    aff8:      	cmp	w16, wzr
    affc:      	cset	x1, eq
    b000:      	cmp	x1, #0x0
    b004:      	b.ne	0xb028 <_stogir.floating.operands+0x134>
    b008:      	cmp	x0, #0x65
    b00c:      	b.eq	0xb028 <_stogir.floating.operands+0x134>
    b010:      	cmp	x0, #0x66
    b014:      	b.eq	0xb028 <_stogir.floating.operands+0x134>
    b018:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b018:  ARM64_RELOC_PAGE21	l_stogir.470
    b01c:      	ldr	x16, [x16]
		000000000000b01c:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    b020:      	orr	x20, x16, xzr
    b024:      	mov	x21, #0x2d              ; =45
    b028:      	b	0xb128 <_stogir.floating.operands+0x234>
    b02c:      	movz	x13, #0x0, lsl #48
    b030:      	b	0xb094 <_stogir.floating.operands+0x1a0>
    b034:      	movz	x13, #0x0, lsl #48
    b038:      	b	0xb09c <_stogir.floating.operands+0x1a8>
    b03c:      	sxtw	x3, w3
    b040:      	add	x16, sp, #0x20
    b044:      	orr	x2, x16, xzr
    b048:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b048:  ARM64_RELOC_PAGE21	l_stogir.471
    b04c:      	ldr	x16, [x16]
		000000000000b04c:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    b050:      	orr	x4, x16, xzr
    b054:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b054:  ARM64_RELOC_PAGE21	l_stogir.472
    b058:      	ldr	x16, [x16]
		000000000000b058:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    b05c:      	orr	x6, x16, xzr
    b060:      	add	x7, x0, #0x78
    b064:      	add	x9, x0, #0x28
    b068:      	add	x10, x0, #0x50
    b06c:      	lsr	w3, w3, #0
    b070:      	add	x16, sp, #0x10
    b074:      	str	w3, [x16, #0x4]
    b078:      	add	x16, sp, #0x10
    b07c:      	ldr	x3, [x16]
    b080:      	add	x16, sp, #0x20
    b084:      	str	x3, [x16]
    b088:      	movz	x3, #0x0, lsl #48
    b08c:      	b	0xb144 <_stogir.floating.operands+0x250>
    b090:      	movz	x13, #0x0, lsl #48
    b094:      	b	0xb09c <_stogir.floating.operands+0x1a8>
    b098:      	movz	x13, #0x0, lsl #48
    b09c:      	cmp	x13, #0x0
    b0a0:      	b.eq	0xb0d4 <_stogir.floating.operands+0x1e0>
    b0a4:      	uxtb	w16, w11
    b0a8:      	cmp	w16, wzr
    b0ac:      	b.eq	0xb0c0 <_stogir.floating.operands+0x1cc>
    b0b0:      	ldr	x11, [x0]
    b0b4:      	add	x11, x11, x12, lsl #4
    b0b8:      	ldr	x11, [x11]
    b0bc:      	b	0xb0cc <_stogir.floating.operands+0x1d8>
    b0c0:      	ldr	x11, [x0, #0x28]
    b0c4:      	add	x11, x11, x14, lsl #4
    b0c8:      	ldr	x11, [x11]
    b0cc:      	mov	x12, #0x1               ; =1
    b0d0:      	b	0xb0dc <_stogir.floating.operands+0x1e8>
    b0d4:      	movz	x12, #0x0, lsl #48
    b0d8:      	movz	x11, #0x0, lsl #48
    b0dc:      	lsr	w12, w12, #0
    b0e0:      	lsr	x16, x12, #0
    b0e4:      	cmp	x16, #0x1
    b0e8:      	b.eq	0xb104 <_stogir.floating.operands+0x210>
    b0ec:      	b.lo	0xb0f4 <_stogir.floating.operands+0x200>
    b0f0:      	b	0xb108 <_stogir.floating.operands+0x214>
    b0f4:      	cmp	x16, #0x0
    b0f8:      	b.eq	0xb100 <_stogir.floating.operands+0x20c>
    b0fc:      	b	0xb108 <_stogir.floating.operands+0x214>
    b100:      	b	0xb10c <_stogir.floating.operands+0x218>
    b104:      	b	0xb12c <_stogir.floating.operands+0x238>
    b108:      	b	0xb348 <_stogir.floating.operands+0x454>
    b10c:      	mov	x20, x4
    b110:      	mov	x21, #0x18              ; =24
    b114:      	b	0xb144 <_stogir.floating.operands+0x250>
    b118:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b118:  ARM64_RELOC_PAGE21	l_stogir.473
    b11c:      	ldr	x16, [x16]
		000000000000b11c:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    b120:      	orr	x20, x16, xzr
    b124:      	mov	x21, #0x21              ; =33
    b128:      	b	0xb214 <_stogir.floating.operands+0x320>
    b12c:      	lsr	w11, w11, #0
    b130:      	ubfx	x11, x11, #8, #8
    b134:      	cmp	x11, x19
    b138:      	b.eq	0xb144 <_stogir.floating.operands+0x250>
    b13c:      	mov	x20, x6
    b140:      	mov	x21, #0x1e              ; =30
    b144:      	cmp	x3, #0x2
    b148:      	b.ge	0xb16c <_stogir.floating.operands+0x278>
    b14c:      	add	x11, x3, #0x1
    b150:      	add	x3, x2, x3, lsl #2
    b154:      	ldr	w3, [x3]
    b158:      	sxtw	x3, w3
    b15c:      	and	x12, x3, #0xffffffff
    b160:      	mov	x3, x11
    b164:      	mov	x11, #0x1               ; =1
    b168:      	b	0xb174 <_stogir.floating.operands+0x280>
    b16c:      	movz	x11, #0x0, lsl #48
    b170:      	movz	x12, #0x0, lsl #48
    b174:      	lsr	w11, w11, #0
    b178:      	lsr	x16, x11, #0
    b17c:      	cmp	x16, #0x1
    b180:      	b.eq	0xb19c <_stogir.floating.operands+0x2a8>
    b184:      	b.lo	0xb18c <_stogir.floating.operands+0x298>
    b188:      	b	0xb1a0 <_stogir.floating.operands+0x2ac>
    b18c:      	cmp	x16, #0x0
    b190:      	b.eq	0xb198 <_stogir.floating.operands+0x2a4>
    b194:      	b	0xb1a0 <_stogir.floating.operands+0x2ac>
    b198:      	b	0xb204 <_stogir.floating.operands+0x310>
    b19c:      	b	0xb1a4 <_stogir.floating.operands+0x2b0>
    b1a0:      	b	0xb340 <_stogir.floating.operands+0x44c>
    b1a4:      	lsr	w12, w12, #0
    b1a8:      	sxtw	x12, w12
    b1ac:      	cmp	x12, #0x0
    b1b0:      	cset	w11, gt
    b1b4:      	movz	x16, #0x0, lsl #48
    b1b8:      	sub	x13, x16, x12
    b1bc:      	sub	x14, x13, #0x1
    b1c0:      	uxtb	w16, w11
    b1c4:      	cmp	w16, wzr
    b1c8:      	b.eq	0xb290 <_stogir.floating.operands+0x39c>
    b1cc:      	ldr	x13, [x0, #0x8]
    b1d0:      	cmp	x12, x13
    b1d4:      	b.ge	0xb090 <_stogir.floating.operands+0x19c>
    b1d8:      	ldr	x13, [x7, #0x8]
    b1dc:      	cmp	x12, x13
    b1e0:      	b.ge	0xb02c <_stogir.floating.operands+0x138>
    b1e4:      	ldr	x13, [x0, #0x78]
    b1e8:      	add	x13, x13, x12, lsl #2
    b1ec:      	ldr	w13, [x13]
    b1f0:      	sxtw	x13, w13
    b1f4:      	cmp	x13, #0x0
    b1f8:      	cset	w13, ge
    b1fc:      	ubfx	x13, x13, #0, #8
    b200:      	b	0xb030 <_stogir.floating.operands+0x13c>
    b204:      	sxtw	x22, w5
    b208:      	cmp	x22, #0x0
    b20c:      	b.ne	0xb22c <_stogir.floating.operands+0x338>
    b210:      	mov	x23, x8
    b214:      	cmp	x21, #0x0
    b218:      	b.ne	0xb2d0 <_stogir.floating.operands+0x3dc>
    b21c:      	and	x20, x19, #0xffffffff
    b220:      	movz	x0, #0x0, lsl #48
    b224:      	movz	x21, #0x0, lsl #48
    b228:      	b	0xb2d4 <_stogir.floating.operands+0x3e0>
    b22c:      	cmp	x1, #0x1d
    b230:      	b.ne	0xb358 <_stogir.floating.operands+0x464>
    b234:      	lsr	w5, w5, #0
    b238:      	mov	w1, w5
    b23c:      	mov	x23, x8
    b240:      	add	x8, sp, #0x30
    b244:      	bl	0xb244 <_stogir.floating.operands+0x350>
		000000000000b244:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b248:      	add	x16, sp, #0x30
    b24c:      	ldr	w0, [x16]
    b250:      	lsr	x16, x0, #0
    b254:      	cmp	x16, #0x1
    b258:      	b.eq	0xb274 <_stogir.floating.operands+0x380>
    b25c:      	b.lo	0xb264 <_stogir.floating.operands+0x370>
    b260:      	b	0xb278 <_stogir.floating.operands+0x384>
    b264:      	cmp	x16, #0x0
    b268:      	b.eq	0xb270 <_stogir.floating.operands+0x37c>
    b26c:      	b	0xb278 <_stogir.floating.operands+0x384>
    b270:      	b	0xb27c <_stogir.floating.operands+0x388>
    b274:      	b	0xb30c <_stogir.floating.operands+0x418>
    b278:      	b	0xb350 <_stogir.floating.operands+0x45c>
    b27c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b27c:  ARM64_RELOC_PAGE21	l_stogir.474
    b280:      	ldr	x16, [x16]
		000000000000b280:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    b284:      	orr	x20, x16, xzr
    b288:      	mov	x21, #0x16              ; =22
    b28c:      	b	0xb028 <_stogir.floating.operands+0x134>
    b290:      	cmp	x12, #0x0
    b294:      	b.ge	0xb098 <_stogir.floating.operands+0x1a4>
    b298:      	ldr	x15, [x9, #0x8]
    b29c:      	ldr	x22, [x10, #0x8]
    b2a0:      	cmp	x15, x22
    b2a4:      	b.ne	0xb034 <_stogir.floating.operands+0x140>
    b2a8:      	cmp	x13, x15
    b2ac:      	b.gt	0xb304 <_stogir.floating.operands+0x410>
    b2b0:      	ldr	x13, [x0, #0x50]
    b2b4:      	add	x13, x13, x14, lsl #2
    b2b8:      	ldr	w13, [x13]
    b2bc:      	sxtw	x13, w13
    b2c0:      	cmp	x13, #0x0
    b2c4:      	cset	w13, gt
    b2c8:      	ubfx	x13, x13, #0, #8
    b2cc:      	b	0xb308 <_stogir.floating.operands+0x414>
    b2d0:      	mov	x0, #0x1                ; =1
    b2d4:      	str	x0, [x23]
    b2d8:      	str	x20, [x23, #0x8]
    b2dc:      	str	x21, [x23, #0x10]
    b2e0:      	ldr	x19, [sp, #0x60]
    b2e4:      	ldr	x20, [sp, #0x68]
    b2e8:      	ldr	x21, [sp, #0x70]
    b2ec:      	ldr	x22, [sp, #0x78]
    b2f0:      	ldr	x23, [sp, #0x80]
    b2f4:      	ldr	x29, [sp]
    b2f8:      	ldr	x30, [sp, #0x8]
    b2fc:      	add	sp, sp, #0x90
    b300:      	ret
    b304:      	movz	x13, #0x0, lsl #48
    b308:      	b	0xb038 <_stogir.floating.operands+0x144>
    b30c:      	add	x16, sp, #0x30
    b310:      	ldr	x0, [x16, #0x8]
    b314:      	cmp	x22, #0x0
    b318:      	b.lt	0xb018 <_stogir.floating.operands+0x124>
    b31c:      	uxtb	w0, w0
    b320:      	cmp	x0, #0x83
    b324:      	b.ge	0xafdc <_stogir.floating.operands+0xe8>
    b328:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b328:  ARM64_RELOC_PAGE21	l_stogir.475
    b32c:      	ldr	x16, [x16]
		000000000000b32c:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    b330:      	orr	x1, x16, xzr
    b334:      	add	x1, x0, x1
    b338:      	ldrb	w1, [x1]
    b33c:      	b	0xafe0 <_stogir.floating.operands+0xec>
    b340:      	brk	#0
    b344:      	b	0xb340 <_stogir.floating.operands+0x44c>
    b348:      	brk	#0
    b34c:      	b	0xb348 <_stogir.floating.operands+0x454>
    b350:      	brk	#0
    b354:      	b	0xb350 <_stogir.floating.operands+0x45c>
    b358:      	mov	x23, x8
    b35c:      	b	0xb118 <_stogir.floating.operands+0x224>

000000000000b360 <_stogir.vector-lanes.operands>:
    b360:      	sub	sp, sp, #0x110
    b364:      	str	x29, [sp]
    b368:      	str	x30, [sp, #0x8]
    b36c:      	mov	x29, sp
    b370:      	str	x19, [sp, #0xc0]
    b374:      	str	x20, [sp, #0xc8]
    b378:      	str	x21, [sp, #0xd0]
    b37c:      	str	x22, [sp, #0xd8]
    b380:      	str	x23, [sp, #0xe0]
    b384:      	str	x24, [sp, #0xe8]
    b388:      	str	x25, [sp, #0xf0]
    b38c:      	str	x26, [sp, #0xf8]
    b390:      	str	x27, [sp, #0x100]
    b394:      	str	x28, [sp, #0x108]
    b398:      	sxtw	x4, w4
    b39c:      	cmp	x4, #0x0
    b3a0:      	cset	w7, gt
    b3a4:      	movz	x16, #0x0, lsl #48
    b3a8:      	sub	x9, x16, x4
    b3ac:      	sub	x10, x9, #0x1
    b3b0:      	uxtb	w16, w7
    b3b4:      	cmp	w16, wzr
    b3b8:      	b.eq	0xb3f8 <_stogir.vector-lanes.operands+0x98>
    b3bc:      	ldr	x9, [x0, #0x8]
    b3c0:      	cmp	x4, x9
    b3c4:      	b.ge	0xb450 <_stogir.vector-lanes.operands+0xf0>
    b3c8:      	add	x9, x0, #0x78
    b3cc:      	ldr	x9, [x9, #0x8]
    b3d0:      	cmp	x4, x9
    b3d4:      	b.ge	0xb550 <_stogir.vector-lanes.operands+0x1f0>
    b3d8:      	ldr	x9, [x0, #0x78]
    b3dc:      	add	x9, x9, x4, lsl #2
    b3e0:      	ldr	w9, [x9]
    b3e4:      	sxtw	x9, w9
    b3e8:      	cmp	x9, #0x0
    b3ec:      	cset	w9, ge
    b3f0:      	ubfx	x9, x9, #0, #8
    b3f4:      	b	0xb554 <_stogir.vector-lanes.operands+0x1f4>
    b3f8:      	cmp	x4, #0x0
    b3fc:      	b.ge	0xb458 <_stogir.vector-lanes.operands+0xf8>
    b400:      	add	x11, x0, #0x28
    b404:      	add	x12, x0, #0x50
    b408:      	ldr	x11, [x11, #0x8]
    b40c:      	ldr	x12, [x12, #0x8]
    b410:      	cmp	x11, x12
    b414:      	b.ne	0xb440 <_stogir.vector-lanes.operands+0xe0>
    b418:      	cmp	x9, x11
    b41c:      	b.gt	0xb718 <_stogir.vector-lanes.operands+0x3b8>
    b420:      	ldr	x9, [x0, #0x50]
    b424:      	add	x9, x9, x10, lsl #2
    b428:      	ldr	w9, [x9]
    b42c:      	sxtw	x9, w9
    b430:      	cmp	x9, #0x0
    b434:      	cset	w9, gt
    b438:      	ubfx	x9, x9, #0, #8
    b43c:      	b	0xb71c <_stogir.vector-lanes.operands+0x3bc>
    b440:      	movz	x9, #0x0, lsl #48
    b444:      	b	0xb45c <_stogir.vector-lanes.operands+0xfc>
    b448:      	mov	x1, #0x1                ; =1
    b44c:      	b	0xb4e4 <_stogir.vector-lanes.operands+0x184>
    b450:      	movz	x9, #0x0, lsl #48
    b454:      	b	0xb45c <_stogir.vector-lanes.operands+0xfc>
    b458:      	movz	x9, #0x0, lsl #48
    b45c:      	cmp	x9, #0x0
    b460:      	b.eq	0xb494 <_stogir.vector-lanes.operands+0x134>
    b464:      	uxtb	w16, w7
    b468:      	cmp	w16, wzr
    b46c:      	b.eq	0xb480 <_stogir.vector-lanes.operands+0x120>
    b470:      	ldr	x7, [x0]
    b474:      	add	x4, x7, x4, lsl #4
    b478:      	ldr	x4, [x4]
    b47c:      	b	0xb48c <_stogir.vector-lanes.operands+0x12c>
    b480:      	ldr	x4, [x0, #0x28]
    b484:      	add	x4, x4, x10, lsl #4
    b488:      	ldr	x4, [x4]
    b48c:      	mov	x7, #0x1                ; =1
    b490:      	b	0xb49c <_stogir.vector-lanes.operands+0x13c>
    b494:      	movz	x7, #0x0, lsl #48
    b498:      	movz	x4, #0x0, lsl #48
    b49c:      	lsr	w7, w7, #0
    b4a0:      	lsr	x16, x7, #0
    b4a4:      	cmp	x16, #0x1
    b4a8:      	b.eq	0xb4c4 <_stogir.vector-lanes.operands+0x164>
    b4ac:      	b.lo	0xb4b4 <_stogir.vector-lanes.operands+0x154>
    b4b0:      	b	0xb4c8 <_stogir.vector-lanes.operands+0x168>
    b4b4:      	cmp	x16, #0x0
    b4b8:      	b.eq	0xb4c0 <_stogir.vector-lanes.operands+0x160>
    b4bc:      	b	0xb4c8 <_stogir.vector-lanes.operands+0x168>
    b4c0:      	b	0xb4cc <_stogir.vector-lanes.operands+0x16c>
    b4c4:      	b	0xb52c <_stogir.vector-lanes.operands+0x1cc>
    b4c8:      	b	0xba14 <_stogir.vector-lanes.operands+0x6b4>
    b4cc:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b4cc:  ARM64_RELOC_PAGE21	l_stogir.476
    b4d0:      	ldr	x16, [x16]
		000000000000b4d0:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    b4d4:      	orr	x19, x16, xzr
    b4d8:      	str	x8, [sp, #0xa0]
    b4dc:      	mov	x1, #0x1                ; =1
    b4e0:      	mov	x0, #0x1b               ; =27
    b4e4:      	ldr	x2, [sp, #0xa0]
    b4e8:      	str	x1, [x2]
    b4ec:      	str	x19, [x2, #0x8]
    b4f0:      	str	x0, [x2, #0x10]
    b4f4:      	ldr	x19, [sp, #0xc0]
    b4f8:      	ldr	x20, [sp, #0xc8]
    b4fc:      	ldr	x21, [sp, #0xd0]
    b500:      	ldr	x22, [sp, #0xd8]
    b504:      	ldr	x23, [sp, #0xe0]
    b508:      	ldr	x24, [sp, #0xe8]
    b50c:      	ldr	x25, [sp, #0xf0]
    b510:      	ldr	x26, [sp, #0xf8]
    b514:      	ldr	x27, [sp, #0x100]
    b518:      	ldr	x28, [sp, #0x108]
    b51c:      	ldr	x29, [sp]
    b520:      	ldr	x30, [sp, #0x8]
    b524:      	add	sp, sp, #0x110
    b528:      	ret
    b52c:      	sxtw	x20, w1
    b530:      	sxtw	x1, w2
    b534:      	lsr	w7, w4, #0
    b538:      	ubfx	x7, x7, #8, #8
    b53c:      	orr	x21, x7, xzr
    b540:      	cmp	x20, #0x3d
    b544:      	b.ne	0xb558 <_stogir.vector-lanes.operands+0x1f8>
    b548:      	mov	x22, x21
    b54c:      	b	0xb55c <_stogir.vector-lanes.operands+0x1fc>
    b550:      	movz	x9, #0x0, lsl #48
    b554:      	b	0xb454 <_stogir.vector-lanes.operands+0xf4>
    b558:      	mov	x22, x1
    b55c:      	cmp	x20, #0x3d
    b560:      	b.eq	0xb568 <_stogir.vector-lanes.operands+0x208>
    b564:      	mov	x1, x21
    b568:      	lsr	w23, w22, #0
    b56c:      	sxtw	x24, w23
    b570:      	cmp	x24, #0xf
    b574:      	cset	w25, gt
    b578:      	cmp	x24, #0x80
    b57c:      	cset	w26, lt
    b580:      	and	x7, x24, #0xf
    b584:      	lsr	w7, w7, #0
    b588:      	sxtw	x7, w7
    b58c:      	cmp	x7, #0x1
    b590:      	cset	w27, ge
    b594:      	cmp	x7, #0xd
    b598:      	cset	w28, le
    b59c:      	cmp	x20, #0x3d
    b5a0:      	b.lt	0xb5f0 <_stogir.vector-lanes.operands+0x290>
    b5a4:      	cmp	x20, #0x3f
    b5a8:      	b.gt	0xb5f0 <_stogir.vector-lanes.operands+0x290>
    b5ac:      	uxtb	w16, w25
    b5b0:      	cmp	w16, wzr
    b5b4:      	b.eq	0xb5f0 <_stogir.vector-lanes.operands+0x290>
    b5b8:      	uxtb	w16, w26
    b5bc:      	cmp	w16, wzr
    b5c0:      	b.eq	0xb5f0 <_stogir.vector-lanes.operands+0x290>
    b5c4:      	uxtb	w16, w27
    b5c8:      	cmp	w16, wzr
    b5cc:      	b.eq	0xb5f0 <_stogir.vector-lanes.operands+0x290>
    b5d0:      	uxtb	w16, w28
    b5d4:      	cmp	w16, wzr
    b5d8:      	b.eq	0xb5f0 <_stogir.vector-lanes.operands+0x290>
    b5dc:      	sxtw	x7, w3
    b5e0:      	cmp	x7, #0x4
    b5e4:      	b.eq	0xba44 <_stogir.vector-lanes.operands+0x6e4>
    b5e8:      	cmp	x7, #0x8
    b5ec:      	b.eq	0xba44 <_stogir.vector-lanes.operands+0x6e4>
    b5f0:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b5f0:  ARM64_RELOC_PAGE21	l_stogir.477
    b5f4:      	ldr	x16, [x16]
		000000000000b5f4:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    b5f8:      	orr	x19, x16, xzr
    b5fc:      	mov	x4, #0x36               ; =54
    b600:      	sxtw	x7, w5
    b604:      	sxtw	x9, w6
    b608:      	cmp	x9, #0x0
    b60c:      	cset	w9, eq
    b610:      	cmp	x20, #0x3f
    b614:      	b.ne	0xba7c <_stogir.vector-lanes.operands+0x71c>
    b618:      	lsr	w1, w1, #0
    b61c:      	lsr	w3, w3, #0
    b620:      	mov	w0, w23
    b624:      	mov	w2, w3
    b628:      	mov	x20, x8
    b62c:      	mov	x21, x4
    b630:      	mov	x23, x7
    b634:      	mov	w24, w9
    b638:      	bl	0xb638 <_stogir.vector-lanes.operands+0x2d8>
		000000000000b638:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b63c:      	cmp	x0, #0x0
    b640:      	b.eq	0xb830 <_stogir.vector-lanes.operands+0x4d0>
    b644:      	movz	x0, #0x0, lsl #48
    b648:      	b	0xb834 <_stogir.vector-lanes.operands+0x4d4>
    b64c:      	cmp	x20, #0x3d
    b650:      	b.ne	0xba88 <_stogir.vector-lanes.operands+0x728>
    b654:      	lsr	w2, w2, #0
    b658:      	lsr	w3, w3, #0
    b65c:      	str	x0, [sp, #0x80]
    b660:      	mov	w0, w23
    b664:      	str	w3, [sp, #0x98]
    b668:      	str	w6, [sp, #0xb0]
    b66c:      	str	x1, [sp, #0xa0]
    b670:      	mov	w1, w2
    b674:      	mov	w2, w3
    b678:      	str	x4, [sp, #0xa8]
    b67c:      	str	w8, [sp, #0xb8]
    b680:      	str	w23, [sp, #0x88]
    b684:      	mov	x23, x7
    b688:      	str	x22, [sp, #0x90]
    b68c:      	mov	w22, w5
    b690:      	bl	0xb690 <_stogir.vector-lanes.operands+0x330>
		000000000000b690:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b694:      	cmp	x0, #0x0
    b698:      	b.ne	0xb6b0 <_stogir.vector-lanes.operands+0x350>
    b69c:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b69c:  ARM64_RELOC_PAGE21	l_stogir.478
    b6a0:      	ldr	x16, [x16]
		000000000000b6a0:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    b6a4:      	orr	x19, x16, xzr
    b6a8:      	mov	x16, #0x26              ; =38
    b6ac:      	str	x16, [sp, #0xa8]
    b6b0:      	cmp	x20, #0x3e
    b6b4:      	b.ne	0xb748 <_stogir.vector-lanes.operands+0x3e8>
    b6b8:      	cmp	x21, x24
    b6bc:      	cset	w0, eq
    b6c0:      	uxtb	w16, w0
    b6c4:      	cmp	w16, wzr
    b6c8:      	cset	x0, eq
    b6cc:      	b	0xb74c <_stogir.vector-lanes.operands+0x3ec>
    b6d0:      	mov	x0, #0x1                ; =1
    b6d4:      	cmp	x0, #0x0
    b6d8:      	b.eq	0xb6ec <_stogir.vector-lanes.operands+0x38c>
    b6dc:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b6dc:  ARM64_RELOC_PAGE21	l_stogir.479
    b6e0:      	ldr	x16, [x16]
		000000000000b6e0:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    b6e4:      	orr	x19, x16, xzr
    b6e8:      	mov	x21, #0x24              ; =36
    b6ec:      	str	x22, [sp, #0x90]
    b6f0:      	str	x20, [sp, #0xa0]
    b6f4:      	str	x21, [sp, #0xa8]
    b6f8:      	ldr	x0, [sp, #0xa8]
    b6fc:      	cmp	x0, #0x0
    b700:      	b.ne	0xb448 <_stogir.vector-lanes.operands+0xe8>
    b704:      	ldr	x0, [sp, #0x90]
    b708:      	and	x19, x0, #0xffffffff
    b70c:      	movz	x1, #0x0, lsl #48
    b710:      	movz	x0, #0x0, lsl #48
    b714:      	b	0xb44c <_stogir.vector-lanes.operands+0xec>
    b718:      	movz	x9, #0x0, lsl #48
    b71c:      	b	0xb444 <_stogir.vector-lanes.operands+0xe4>
    b720:      	ldr	w0, [sp, #0xb8]
    b724:      	uxtb	w16, w0
    b728:      	cmp	w16, wzr
    b72c:      	b.ne	0xb744 <_stogir.vector-lanes.operands+0x3e4>
    b730:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b730:  ARM64_RELOC_PAGE21	l_stogir.480
    b734:      	ldr	x16, [x16]
		000000000000b734:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    b738:      	orr	x19, x16, xzr
    b73c:      	mov	x16, #0x20              ; =32
    b740:      	str	x16, [sp, #0xa8]
    b744:      	b	0xb6f8 <_stogir.vector-lanes.operands+0x398>
    b748:      	movz	x0, #0x0, lsl #48
    b74c:      	cmp	x0, #0x0
    b750:      	b.eq	0xb768 <_stogir.vector-lanes.operands+0x408>
    b754:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b754:  ARM64_RELOC_PAGE21	l_stogir.481
    b758:      	ldr	x16, [x16]
		000000000000b758:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    b75c:      	orr	x19, x16, xzr
    b760:      	mov	x16, #0x27              ; =39
    b764:      	str	x16, [sp, #0xa8]
    b768:      	lsr	w22, w22, #0
    b76c:      	add	x8, sp, #0x10
    b770:      	ldr	x0, [sp, #0x80]
    b774:      	mov	w1, w22
    b778:      	bl	0xb778 <_stogir.vector-lanes.operands+0x418>
		000000000000b778:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b77c:      	add	x16, sp, #0x10
    b780:      	ldr	w0, [x16]
    b784:      	lsr	x16, x0, #0
    b788:      	cmp	x16, #0x1
    b78c:      	b.eq	0xb7a8 <_stogir.vector-lanes.operands+0x448>
    b790:      	b.lo	0xb798 <_stogir.vector-lanes.operands+0x438>
    b794:      	b	0xb7ac <_stogir.vector-lanes.operands+0x44c>
    b798:      	cmp	x16, #0x0
    b79c:      	b.eq	0xb7a4 <_stogir.vector-lanes.operands+0x444>
    b7a0:      	b	0xb7ac <_stogir.vector-lanes.operands+0x44c>
    b7a4:      	b	0xb7b0 <_stogir.vector-lanes.operands+0x450>
    b7a8:      	b	0xb85c <_stogir.vector-lanes.operands+0x4fc>
    b7ac:      	b	0xba6c <_stogir.vector-lanes.operands+0x70c>
    b7b0:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b7b0:  ARM64_RELOC_PAGE21	l_stogir.482
    b7b4:      	ldr	x16, [x16]
		000000000000b7b4:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    b7b8:      	orr	x19, x16, xzr
    b7bc:      	mov	x16, #0x19              ; =25
    b7c0:      	str	x16, [sp, #0xa8]
    b7c4:      	cmp	x20, #0x3e
    b7c8:      	b.ne	0xb720 <_stogir.vector-lanes.operands+0x3c0>
    b7cc:      	ldr	w0, [sp, #0xb0]
    b7d0:      	lsr	w0, w0, #0
    b7d4:      	add	x8, sp, #0x50
    b7d8:      	mov	w1, w0
    b7dc:      	ldr	x0, [sp, #0x80]
    b7e0:      	bl	0xb7e0 <_stogir.vector-lanes.operands+0x480>
		000000000000b7e0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b7e4:      	add	x16, sp, #0x50
    b7e8:      	ldr	w0, [x16]
    b7ec:      	lsr	x16, x0, #0
    b7f0:      	cmp	x16, #0x1
    b7f4:      	b.eq	0xb810 <_stogir.vector-lanes.operands+0x4b0>
    b7f8:      	b.lo	0xb800 <_stogir.vector-lanes.operands+0x4a0>
    b7fc:      	b	0xb814 <_stogir.vector-lanes.operands+0x4b4>
    b800:      	cmp	x16, #0x0
    b804:      	b.eq	0xb80c <_stogir.vector-lanes.operands+0x4ac>
    b808:      	b	0xb814 <_stogir.vector-lanes.operands+0x4b4>
    b80c:      	b	0xb818 <_stogir.vector-lanes.operands+0x4b8>
    b810:      	b	0xb94c <_stogir.vector-lanes.operands+0x5ec>
    b814:      	b	0xba74 <_stogir.vector-lanes.operands+0x714>
    b818:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b818:  ARM64_RELOC_PAGE21	l_stogir.483
    b81c:      	ldr	x16, [x16]
		000000000000b81c:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    b820:      	orr	x19, x16, xzr
    b824:      	mov	x16, #0x20              ; =32
    b828:      	str	x16, [sp, #0xa8]
    b82c:      	b	0xb744 <_stogir.vector-lanes.operands+0x3e4>
    b830:      	mov	x0, #0x1                ; =1
    b834:      	cmp	x0, #0x0
    b838:      	b.eq	0xb844 <_stogir.vector-lanes.operands+0x4e4>
    b83c:      	mov	x0, #0x1                ; =1
    b840:      	b	0xb6d4 <_stogir.vector-lanes.operands+0x374>
    b844:      	cmp	x23, #0x0
    b848:      	b.ne	0xb6d0 <_stogir.vector-lanes.operands+0x370>
    b84c:      	uxtb	w16, w24
    b850:      	cmp	w16, wzr
    b854:      	cset	x0, eq
    b858:      	b	0xb6d4 <_stogir.vector-lanes.operands+0x374>
    b85c:      	add	x16, sp, #0x10
    b860:      	orr	x0, x16, xzr
    b864:      	add	x0, x0, #0x8
    b868:      	add	x16, sp, #0x10
    b86c:      	ldr	x1, [x16, #0x8]
    b870:      	add	x16, sp, #0x40
    b874:      	str	x1, [x16]
    b878:      	lsr	w1, w1, #0
    b87c:      	ldr	x0, [x0, #0x8]
    b880:      	add	x16, sp, #0x40
    b884:      	str	x0, [x16, #0x8]
    b888:      	ubfx	x0, x1, #8, #8
    b88c:      	cmp	x0, #0x1
    b890:      	b.lt	0xb8b8 <_stogir.vector-lanes.operands+0x558>
    b894:      	cmp	x0, #0xb
    b898:      	b.gt	0xb8b8 <_stogir.vector-lanes.operands+0x558>
    b89c:      	add	x16, sp, #0x40
    b8a0:      	ldr	w0, [x16]
    b8a4:      	uxtb	w0, w0
    b8a8:      	cmp	x0, #0x48
    b8ac:      	b.eq	0xb8b8 <_stogir.vector-lanes.operands+0x558>
    b8b0:      	cmp	x0, #0x46
    b8b4:      	b.ne	0xb8cc <_stogir.vector-lanes.operands+0x56c>
    b8b8:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b8b8:  ARM64_RELOC_PAGE21	l_stogir.484
    b8bc:      	ldr	x16, [x16]
		000000000000b8bc:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    b8c0:      	orr	x19, x16, xzr
    b8c4:      	mov	x16, #0x2b              ; =43
    b8c8:      	str	x16, [sp, #0xa8]
    b8cc:      	cmp	x23, #0x0
    b8d0:      	b.ge	0xb8fc <_stogir.vector-lanes.operands+0x59c>
    b8d4:      	add	x16, sp, #0x40
    b8d8:      	ldr	w0, [x16]
    b8dc:      	uxtb	w1, w0
    b8e0:      	ubfx	x0, x0, #8, #8
    b8e4:      	cmp	x1, x0
    b8e8:      	b.eq	0xb9ac <_stogir.vector-lanes.operands+0x64c>
    b8ec:      	cmp	x1, #0x49
    b8f0:      	b.eq	0xb9ac <_stogir.vector-lanes.operands+0x64c>
    b8f4:      	movz	x0, #0x0, lsl #48
    b8f8:      	b	0xb948 <_stogir.vector-lanes.operands+0x5e8>
    b8fc:      	movz	x0, #0x0, lsl #48
    b900:      	cmp	x0, #0x0
    b904:      	b.eq	0xb91c <_stogir.vector-lanes.operands+0x5bc>
    b908:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b908:  ARM64_RELOC_PAGE21	l_stogir.485
    b90c:      	ldr	x16, [x16]
		000000000000b90c:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    b910:      	orr	x19, x16, xzr
    b914:      	mov	x16, #0x28              ; =40
    b918:      	str	x16, [sp, #0xa8]
    b91c:      	b	0xb7c4 <_stogir.vector-lanes.operands+0x464>
    b920:      	movn	x2, #0x0, lsl #48
    b924:      	ubfx	x0, x0, #0, #32
    b928:      	ubfx	x1, x1, #0, #32
    b92c:      	lsl	x1, x1, #32
    b930:      	orr	x0, x1, x0
    b934:      	lsr	w2, w2, #0
    b938:      	sxtw	x2, w2
    b93c:      	cmp	x0, x2
    b940:      	cset	w0, hs
    b944:      	ubfx	x0, x0, #0, #8
    b948:      	b	0xb900 <_stogir.vector-lanes.operands+0x5a0>
    b94c:      	add	x16, sp, #0x50
    b950:      	ldr	x0, [x16, #0x8]
    b954:      	uxtb	w1, w0
    b958:      	cmp	x1, #0x48
    b95c:      	b.eq	0xb994 <_stogir.vector-lanes.operands+0x634>
    b960:      	cmp	x1, #0x46
    b964:      	b.eq	0xb994 <_stogir.vector-lanes.operands+0x634>
    b968:      	ldr	w1, [sp, #0x98]
    b96c:      	lsr	w1, w1, #0
    b970:      	lsr	w0, w0, #0
    b974:      	ubfx	x0, x0, #8, #8
    b978:      	lsr	w0, w0, #0
    b97c:      	mov	w2, w1
    b980:      	mov	w1, w0
    b984:      	ldr	w0, [sp, #0x88]
    b988:      	bl	0xb988 <_stogir.vector-lanes.operands+0x628>
		000000000000b988:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b98c:      	cmp	x0, #0x0
    b990:      	b.ne	0xb9a8 <_stogir.vector-lanes.operands+0x648>
    b994:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000b994:  ARM64_RELOC_PAGE21	l_stogir.486
    b998:      	ldr	x16, [x16]
		000000000000b998:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    b99c:      	orr	x19, x16, xzr
    b9a0:      	mov	x16, #0x27              ; =39
    b9a4:      	str	x16, [sp, #0xa8]
    b9a8:      	b	0xb82c <_stogir.vector-lanes.operands+0x4cc>
    b9ac:      	add	x16, sp, #0x40
    b9b0:      	ldr	w0, [x16, #0x8]
    b9b4:      	add	x16, sp, #0x40
    b9b8:      	ldr	w1, [x16, #0xc]
    b9bc:      	uxtb	w16, w25
    b9c0:      	cmp	w16, wzr
    b9c4:      	b.eq	0xba1c <_stogir.vector-lanes.operands+0x6bc>
    b9c8:      	uxtb	w16, w26
    b9cc:      	cmp	w16, wzr
    b9d0:      	b.eq	0xba1c <_stogir.vector-lanes.operands+0x6bc>
    b9d4:      	uxtb	w16, w27
    b9d8:      	cmp	w16, wzr
    b9dc:      	b.eq	0xba1c <_stogir.vector-lanes.operands+0x6bc>
    b9e0:      	uxtb	w16, w28
    b9e4:      	cmp	w16, wzr
    b9e8:      	b.eq	0xba1c <_stogir.vector-lanes.operands+0x6bc>
    b9ec:      	ubfx	x2, x24, #4, #32
    b9f0:      	sxtw	x2, w2
    b9f4:      	sub	x2, x2, #0x1
    b9f8:      	lsr	w2, w2, #0
    b9fc:      	sxtw	x2, w2
    ba00:      	mov	x16, #0x1               ; =1
    ba04:      	lsl	x2, x16, x2
    ba08:      	lsr	w2, w2, #0
    ba0c:      	sxtw	x2, w2
    ba10:      	b	0xb924 <_stogir.vector-lanes.operands+0x5c4>
    ba14:      	brk	#0
    ba18:      	b	0xba14 <_stogir.vector-lanes.operands+0x6b4>
    ba1c:      	cmp	x24, #0x0
    ba20:      	b.lt	0xb920 <_stogir.vector-lanes.operands+0x5c0>
    ba24:      	cmp	x24, #0xd
    ba28:      	b.gt	0xb920 <_stogir.vector-lanes.operands+0x5c0>
    ba2c:      	cmp	x24, #0x0
    ba30:      	cset	w2, eq
    ba34:      	uxtb	w16, w2
    ba38:      	cmp	w16, wzr
    ba3c:      	cset	x2, eq
    ba40:      	b	0xb924 <_stogir.vector-lanes.operands+0x5c4>
    ba44:      	uxtb	w4, w4
    ba48:      	cmp	x4, #0x48
    ba4c:      	b.eq	0xb5f0 <_stogir.vector-lanes.operands+0x290>
    ba50:      	cmp	x4, #0x46
    ba54:      	b.eq	0xb5f0 <_stogir.vector-lanes.operands+0x290>
    ba58:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000ba58:  ARM64_RELOC_PAGE21	l_stogir.487
    ba5c:      	ldr	x16, [x16]
		000000000000ba5c:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    ba60:      	orr	x19, x16, xzr
    ba64:      	movz	x4, #0x0, lsl #48
    ba68:      	b	0xb600 <_stogir.vector-lanes.operands+0x2a0>
    ba6c:      	brk	#0
    ba70:      	b	0xba6c <_stogir.vector-lanes.operands+0x70c>
    ba74:      	brk	#0
    ba78:      	b	0xba74 <_stogir.vector-lanes.operands+0x714>
    ba7c:      	mov	x1, x8
    ba80:      	mov	w8, w9
    ba84:      	b	0xb64c <_stogir.vector-lanes.operands+0x2ec>
    ba88:      	str	x22, [sp, #0x90]
    ba8c:      	str	x1, [sp, #0xa0]
    ba90:      	str	x0, [sp, #0x80]
    ba94:      	str	w3, [sp, #0x98]
    ba98:      	mov	w22, w5
    ba9c:      	str	w6, [sp, #0xb0]
    baa0:      	str	w23, [sp, #0x88]
    baa4:      	mov	x23, x7
    baa8:      	str	w8, [sp, #0xb8]
    baac:      	str	x4, [sp, #0xa8]
    bab0:      	b	0xb6b0 <_stogir.vector-lanes.operands+0x350>

000000000000bab4 <_stogir.vector-comparison.operands>:
    bab4:      	sub	sp, sp, #0xc0
    bab8:      	str	x29, [sp]
    babc:      	str	x30, [sp, #0x8]
    bac0:      	mov	x29, sp
    bac4:      	str	x19, [sp, #0x70]
    bac8:      	str	x20, [sp, #0x78]
    bacc:      	str	x21, [sp, #0x80]
    bad0:      	str	x22, [sp, #0x88]
    bad4:      	str	x23, [sp, #0x90]
    bad8:      	str	x24, [sp, #0x98]
    badc:      	str	x25, [sp, #0xa0]
    bae0:      	str	x26, [sp, #0xa8]
    bae4:      	str	x27, [sp, #0xb0]
    bae8:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000bae8:  ARM64_RELOC_PAGE21	l_stogir.488
    baec:      	ldr	x16, [x16]
		000000000000baec:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    baf0:      	orr	x19, x16, xzr
    baf4:      	lsr	w4, w4, #0
    baf8:      	mov	x20, x8
    bafc:      	add	x8, sp, #0x10
    bb00:      	mov	x21, x0
    bb04:      	mov	w22, w1
    bb08:      	mov	w1, w4
    bb0c:      	mov	w23, w2
    bb10:      	mov	w24, w3
    bb14:      	mov	w25, w5
    bb18:      	bl	0xbb18 <_stogir.vector-comparison.operands+0x64>
		000000000000bb18:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    bb1c:      	add	x16, sp, #0x10
    bb20:      	ldr	w0, [x16]
    bb24:      	lsr	x16, x0, #0
    bb28:      	cmp	x16, #0x1
    bb2c:      	b.eq	0xbb48 <_stogir.vector-comparison.operands+0x94>
    bb30:      	b.lo	0xbb38 <_stogir.vector-comparison.operands+0x84>
    bb34:      	b	0xbb4c <_stogir.vector-comparison.operands+0x98>
    bb38:      	cmp	x16, #0x0
    bb3c:      	b.eq	0xbb44 <_stogir.vector-comparison.operands+0x90>
    bb40:      	b	0xbb4c <_stogir.vector-comparison.operands+0x98>
    bb44:      	b	0xbb50 <_stogir.vector-comparison.operands+0x9c>
    bb48:      	b	0xbb98 <_stogir.vector-comparison.operands+0xe4>
    bb4c:      	b	0xbd18 <_stogir.vector-comparison.operands+0x264>
    bb50:      	mov	x0, #0x1                ; =1
    bb54:      	mov	x1, #0x21               ; =33
    bb58:      	str	x0, [x20]
    bb5c:      	str	x19, [x20, #0x8]
    bb60:      	str	x1, [x20, #0x10]
    bb64:      	ldr	x19, [sp, #0x70]
    bb68:      	ldr	x20, [sp, #0x78]
    bb6c:      	ldr	x21, [sp, #0x80]
    bb70:      	ldr	x22, [sp, #0x88]
    bb74:      	ldr	x23, [sp, #0x90]
    bb78:      	ldr	x24, [sp, #0x98]
    bb7c:      	ldr	x25, [sp, #0xa0]
    bb80:      	ldr	x26, [sp, #0xa8]
    bb84:      	ldr	x27, [sp, #0xb0]
    bb88:      	ldr	x29, [sp]
    bb8c:      	ldr	x30, [sp, #0x8]
    bb90:      	add	sp, sp, #0xc0
    bb94:      	ret
    bb98:      	lsr	w25, w25, #0
    bb9c:      	add	x16, sp, #0x10
    bba0:      	ldr	x26, [x16, #0x8]
    bba4:      	add	x8, sp, #0x40
    bba8:      	mov	x0, x21
    bbac:      	mov	w1, w25
    bbb0:      	bl	0xbbb0 <_stogir.vector-comparison.operands+0xfc>
		000000000000bbb0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    bbb4:      	add	x16, sp, #0x40
    bbb8:      	ldr	w0, [x16]
    bbbc:      	lsr	x16, x0, #0
    bbc0:      	cmp	x16, #0x1
    bbc4:      	b.eq	0xbbe0 <_stogir.vector-comparison.operands+0x12c>
    bbc8:      	b.lo	0xbbd0 <_stogir.vector-comparison.operands+0x11c>
    bbcc:      	b	0xbbe4 <_stogir.vector-comparison.operands+0x130>
    bbd0:      	cmp	x16, #0x0
    bbd4:      	b.eq	0xbbdc <_stogir.vector-comparison.operands+0x128>
    bbd8:      	b	0xbbe4 <_stogir.vector-comparison.operands+0x130>
    bbdc:      	b	0xbbe8 <_stogir.vector-comparison.operands+0x134>
    bbe0:      	b	0xbbf4 <_stogir.vector-comparison.operands+0x140>
    bbe4:      	b	0xbd20 <_stogir.vector-comparison.operands+0x26c>
    bbe8:      	mov	x0, #0x1                ; =1
    bbec:      	mov	x1, #0x21               ; =33
    bbf0:      	b	0xbb58 <_stogir.vector-comparison.operands+0xa4>
    bbf4:      	sxtw	x0, w24
    bbf8:      	add	x16, sp, #0x40
    bbfc:      	ldr	x19, [x16, #0x8]
    bc00:      	cmp	x0, #0x4
    bc04:      	b.eq	0xbc28 <_stogir.vector-comparison.operands+0x174>
    bc08:      	cmp	x0, #0x8
    bc0c:      	b.eq	0xbc28 <_stogir.vector-comparison.operands+0x174>
    bc10:      	adrp	x16, 0xb000 <_stogir.floating.operands+0x10c>
		000000000000bc10:  ARM64_RELOC_PAGE21	l_stogir.489
    bc14:      	ldr	x16, [x16]
		000000000000bc14:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    bc18:      	orr	x19, x16, xzr
    bc1c:      	mov	x0, #0x1                ; =1
    bc20:      	mov	x1, #0x33               ; =51
    bc24:      	b	0xbbf0 <_stogir.vector-comparison.operands+0x13c>
    bc28:      	lsr	w22, w22, #0
    bc2c:      	lsr	w0, w26, #0
    bc30:      	ubfx	x21, x0, #8, #8
    bc34:      	orr	x0, x21, xzr
    bc38:      	lsr	w0, w0, #0
    bc3c:      	mov	w1, w0
    bc40:      	mov	w0, w22
    bc44:      	bl	0xbc44 <_stogir.vector-comparison.operands+0x190>
		000000000000bc44:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    bc48:      	cmp	x0, #0x0
    bc4c:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bc50:      	lsr	w0, w19, #0
    bc54:      	ubfx	x0, x0, #8, #8
    bc58:      	cmp	x21, x0
    bc5c:      	b.ne	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bc60:      	uxtb	w26, w26
    bc64:      	cmp	x26, #0x48
    bc68:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bc6c:      	cmp	x26, #0x46
    bc70:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bc74:      	uxtb	w19, w19
    bc78:      	cmp	x19, #0x48
    bc7c:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bc80:      	cmp	x19, #0x46
    bc84:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bc88:      	sxtw	x23, w23
    bc8c:      	cmp	x23, #0xf
    bc90:      	cset	w0, gt
    bc94:      	uxtb	w16, w0
    bc98:      	cmp	w16, wzr
    bc9c:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bca0:      	cmp	x23, #0x80
    bca4:      	cset	w1, lt
    bca8:      	uxtb	w16, w1
    bcac:      	cmp	w16, wzr
    bcb0:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bcb4:      	and	x2, x23, #0xf
    bcb8:      	lsr	w2, w2, #0
    bcbc:      	sxtw	x2, w2
    bcc0:      	cmp	x2, #0x1
    bcc4:      	cset	w3, ge
    bcc8:      	uxtb	w16, w3
    bccc:      	cmp	w16, wzr
    bcd0:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bcd4:      	cmp	x2, #0xd
    bcd8:      	cset	w4, le
    bcdc:      	uxtb	w16, w4
    bce0:      	cmp	w16, wzr
    bce4:      	b.eq	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bce8:      	cmp	x23, #0x0
    bcec:      	cset	w5, ge
    bcf0:      	cmp	x23, #0xd
    bcf4:      	cset	w6, le
    bcf8:      	uxtb	w16, w5
    bcfc:      	cmp	w16, wzr
    bd00:      	b.eq	0xbd28 <_stogir.vector-comparison.operands+0x274>
    bd04:      	uxtb	w16, w6
    bd08:      	cmp	w16, wzr
    bd0c:      	b.eq	0xbd28 <_stogir.vector-comparison.operands+0x274>
    bd10:      	mov	x7, x2
    bd14:      	b	0xbd5c <_stogir.vector-comparison.operands+0x2a8>
    bd18:      	brk	#0
    bd1c:      	b	0xbd18 <_stogir.vector-comparison.operands+0x264>
    bd20:      	brk	#0
    bd24:      	b	0xbd20 <_stogir.vector-comparison.operands+0x26c>
    bd28:      	uxtb	w16, w0
    bd2c:      	cmp	w16, wzr
    bd30:      	b.eq	0xbd58 <_stogir.vector-comparison.operands+0x2a4>
    bd34:      	uxtb	w16, w1
    bd38:      	cmp	w16, wzr
    bd3c:      	b.eq	0xbd58 <_stogir.vector-comparison.operands+0x2a4>
    bd40:      	uxtb	w16, w3
    bd44:      	cmp	w16, wzr
    bd48:      	b.eq	0xbd58 <_stogir.vector-comparison.operands+0x2a4>
    bd4c:      	uxtb	w16, w4
    bd50:      	cmp	w16, wzr
    bd54:      	b.ne	0xbd10 <_stogir.vector-comparison.operands+0x25c>
    bd58:      	movn	x7, #0x0, lsl #48
    bd5c:      	lsr	w7, w7, #0
    bd60:      	sxtw	x7, w7
    bd64:      	cmp	x7, #0x1
    bd68:      	b.lt	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bd6c:      	cmp	x7, #0xb
    bd70:      	b.gt	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bd74:      	uxtb	w16, w0
    bd78:      	cmp	w16, wzr
    bd7c:      	b.eq	0xbdcc <_stogir.vector-comparison.operands+0x318>
    bd80:      	uxtb	w16, w1
    bd84:      	cmp	w16, wzr
    bd88:      	b.eq	0xbdcc <_stogir.vector-comparison.operands+0x318>
    bd8c:      	uxtb	w16, w3
    bd90:      	cmp	w16, wzr
    bd94:      	b.eq	0xbdcc <_stogir.vector-comparison.operands+0x318>
    bd98:      	uxtb	w16, w4
    bd9c:      	cmp	w16, wzr
    bda0:      	b.eq	0xbdcc <_stogir.vector-comparison.operands+0x318>
    bda4:      	ubfx	x7, x23, #4, #32
    bda8:      	sxtw	x7, w7
    bdac:      	sub	x7, x7, #0x1
    bdb0:      	lsr	w7, w7, #0
    bdb4:      	sxtw	x7, w7
    bdb8:      	mov	x16, #0x1               ; =1
    bdbc:      	lsl	x7, x16, x7
    bdc0:      	lsr	w7, w7, #0
    bdc4:      	sxtw	x7, w7
    bdc8:      	b	0xbefc <_stogir.vector-comparison.operands+0x448>
    bdcc:      	uxtb	w16, w5
    bdd0:      	cmp	w16, wzr
    bdd4:      	b.eq	0xbef8 <_stogir.vector-comparison.operands+0x444>
    bdd8:      	uxtb	w16, w6
    bddc:      	cmp	w16, wzr
    bde0:      	b.eq	0xbef8 <_stogir.vector-comparison.operands+0x444>
    bde4:      	cmp	x23, #0x0
    bde8:      	cset	w7, eq
    bdec:      	uxtb	w16, w7
    bdf0:      	cmp	w16, wzr
    bdf4:      	cset	x7, eq
    bdf8:      	b	0xbefc <_stogir.vector-comparison.operands+0x448>
    bdfc:      	movn	x8, #0x0, lsl #48
    be00:      	lsr	w7, w7, #0
    be04:      	sxtw	x7, w7
    be08:      	lsr	w8, w8, #0
    be0c:      	sxtw	x8, w8
    be10:      	cmp	x7, x8
    be14:      	b.ne	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    be18:      	uxtb	w16, w5
    be1c:      	cmp	w16, wzr
    be20:      	b.eq	0xbe30 <_stogir.vector-comparison.operands+0x37c>
    be24:      	uxtb	w16, w6
    be28:      	cmp	w16, wzr
    be2c:      	b.ne	0xbe64 <_stogir.vector-comparison.operands+0x3b0>
    be30:      	uxtb	w16, w0
    be34:      	cmp	w16, wzr
    be38:      	b.eq	0xbe60 <_stogir.vector-comparison.operands+0x3ac>
    be3c:      	uxtb	w16, w1
    be40:      	cmp	w16, wzr
    be44:      	b.eq	0xbe60 <_stogir.vector-comparison.operands+0x3ac>
    be48:      	uxtb	w16, w3
    be4c:      	cmp	w16, wzr
    be50:      	b.eq	0xbe60 <_stogir.vector-comparison.operands+0x3ac>
    be54:      	uxtb	w16, w4
    be58:      	cmp	w16, wzr
    be5c:      	b.ne	0xbe64 <_stogir.vector-comparison.operands+0x3b0>
    be60:      	movn	x2, #0x0, lsl #48
    be64:      	lsr	w24, w24, #0
    be68:      	lsr	w2, w2, #0
    be6c:      	lsr	w2, w2, #0
    be70:      	mov	w0, w2
    be74:      	mov	w1, w24
    be78:      	bl	0xbe78 <_stogir.vector-comparison.operands+0x3c4>
		000000000000be78:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    be7c:      	uxtb	w16, w19
    be80:      	cmp	w16, wzr
    be84:      	b.ne	0xbebc <_stogir.vector-comparison.operands+0x408>
    be88:      	uxtb	w16, w22
    be8c:      	cmp	w16, wzr
    be90:      	b.eq	0xbeb8 <_stogir.vector-comparison.operands+0x404>
    be94:      	uxtb	w16, w23
    be98:      	cmp	w16, wzr
    be9c:      	b.eq	0xbeb8 <_stogir.vector-comparison.operands+0x404>
    bea0:      	uxtb	w16, w26
    bea4:      	cmp	w16, wzr
    bea8:      	b.eq	0xbeb8 <_stogir.vector-comparison.operands+0x404>
    beac:      	uxtb	w16, w27
    beb0:      	cmp	w16, wzr
    beb4:      	b.ne	0xbebc <_stogir.vector-comparison.operands+0x408>
    beb8:      	movn	x25, #0x0, lsl #48
    bebc:      	lsr	w0, w0, #0
    bec0:      	sxtw	x19, w0
    bec4:      	lsr	w25, w25, #0
    bec8:      	lsr	w25, w25, #0
    becc:      	mov	w0, w25
    bed0:      	mov	w1, w24
    bed4:      	bl	0xbed4 <_stogir.vector-comparison.operands+0x420>
		000000000000bed4:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    bed8:      	lsr	w0, w0, #0
    bedc:      	sxtw	x0, w0
    bee0:      	cmp	x19, x0
    bee4:      	b.ne	0xbc10 <_stogir.vector-comparison.operands+0x15c>
    bee8:      	and	x19, x21, #0xffffffff
    beec:      	movz	x0, #0x0, lsl #48
    bef0:      	movz	x1, #0x0, lsl #48
    bef4:      	b	0xbc24 <_stogir.vector-comparison.operands+0x170>
    bef8:      	movn	x7, #0x0, lsl #48
    befc:      	and	x8, x21, #0xf
    bf00:      	cmp	x21, #0xd
    bf04:      	cset	w19, le
    bf08:      	cmp	x21, #0xf
    bf0c:      	cset	w22, gt
    bf10:      	cmp	x21, #0x80
    bf14:      	cset	w23, lt
    bf18:      	lsr	w8, w8, #0
    bf1c:      	sxtw	x25, w8
    bf20:      	cmp	x25, #0x1
    bf24:      	cset	w26, ge
    bf28:      	cmp	x25, #0xd
    bf2c:      	cset	w27, le
    bf30:      	uxtb	w16, w22
    bf34:      	cmp	w16, wzr
    bf38:      	b.eq	0xbf88 <_stogir.vector-comparison.operands+0x4d4>
    bf3c:      	uxtb	w16, w23
    bf40:      	cmp	w16, wzr
    bf44:      	b.eq	0xbf88 <_stogir.vector-comparison.operands+0x4d4>
    bf48:      	uxtb	w16, w26
    bf4c:      	cmp	w16, wzr
    bf50:      	b.eq	0xbf88 <_stogir.vector-comparison.operands+0x4d4>
    bf54:      	uxtb	w16, w27
    bf58:      	cmp	w16, wzr
    bf5c:      	b.eq	0xbf88 <_stogir.vector-comparison.operands+0x4d4>
    bf60:      	ubfx	x8, x21, #4, #32
    bf64:      	sxtw	x8, w8
    bf68:      	sub	x8, x8, #0x1
    bf6c:      	lsr	w8, w8, #0
    bf70:      	sxtw	x8, w8
    bf74:      	mov	x16, #0x1               ; =1
    bf78:      	lsl	x8, x16, x8
    bf7c:      	lsr	w8, w8, #0
    bf80:      	sxtw	x8, w8
    bf84:      	b	0xbe00 <_stogir.vector-comparison.operands+0x34c>
    bf88:      	uxtb	w16, w19
    bf8c:      	cmp	w16, wzr
    bf90:      	b.eq	0xbdfc <_stogir.vector-comparison.operands+0x348>
    bf94:      	cmp	x21, #0x0
    bf98:      	cset	w8, eq
    bf9c:      	uxtb	w16, w8
    bfa0:      	cmp	w16, wzr
    bfa4:      	cset	x8, eq
    bfa8:      	b	0xbe00 <_stogir.vector-comparison.operands+0x34c>

000000000000bfac <_stogir.vector-arithmetic.operands>:
    bfac:      	sub	sp, sp, #0x80
    bfb0:      	str	x29, [sp]
    bfb4:      	str	x30, [sp, #0x8]
    bfb8:      	mov	x29, sp
    bfbc:      	str	x19, [sp, #0x30]
    bfc0:      	str	x20, [sp, #0x38]
    bfc4:      	str	x21, [sp, #0x40]
    bfc8:      	str	x22, [sp, #0x48]
    bfcc:      	str	x23, [sp, #0x50]
    bfd0:      	str	x24, [sp, #0x58]
    bfd4:      	str	x25, [sp, #0x60]
    bfd8:      	str	x26, [sp, #0x68]
    bfdc:      	str	x27, [sp, #0x70]
    bfe0:      	str	x28, [sp, #0x78]
    bfe4:      	lsr	w1, w1, #0
    bfe8:      	lsr	w2, w2, #0
    bfec:      	mov	x19, x8
    bff0:      	mov	x20, x0
    bff4:      	mov	w0, w1
    bff8:      	mov	w21, w1
    bffc:      	mov	w1, w2
    c000:      	mov	w22, w2
    c004:      	mov	w23, w3
    c008:      	mov	w24, w4
    c00c:      	mov	w25, w5
    c010:      	bl	0xc010 <_stogir.vector-arithmetic.operands+0x64>
		000000000000c010:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    c014:      	cmp	x0, #0x0
    c018:      	b.eq	0xc030 <_stogir.vector-arithmetic.operands+0x84>
    c01c:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c01c:  ARM64_RELOC_PAGE21	l_stogir.490
    c020:      	ldr	x16, [x16]
		000000000000c020:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    c024:      	orr	x0, x16, xzr
    c028:      	movz	x1, #0x0, lsl #48
    c02c:      	b	0xc040 <_stogir.vector-arithmetic.operands+0x94>
    c030:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c030:  ARM64_RELOC_PAGE21	l_stogir.491
    c034:      	ldr	x16, [x16]
		000000000000c034:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    c038:      	orr	x0, x16, xzr
    c03c:      	mov	x1, #0x37               ; =55
    c040:      	sxtw	x21, w21
    c044:      	sxtw	x22, w22
    c048:      	sxtw	x23, w23
    c04c:      	sxtw	x24, w24
    c050:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c050:  ARM64_RELOC_PAGE21	l_stogir.492
    c054:      	ldr	x16, [x16]
		000000000000c054:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    c058:      	orr	x2, x16, xzr
    c05c:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c05c:  ARM64_RELOC_PAGE21	l_stogir.493
    c060:      	ldr	x16, [x16]
		000000000000c060:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    c064:      	orr	x3, x16, xzr
    c068:      	add	x4, x20, #0x78
    c06c:      	add	x5, x20, #0x28
    c070:      	add	x6, x20, #0x50
    c074:      	cmp	x21, #0x31
    c078:      	cset	w7, ge
    c07c:      	cmp	x21, #0x35
    c080:      	cset	w8, le
    c084:      	cmp	x21, #0x1f
    c088:      	cset	w9, eq
    c08c:      	cmp	x21, #0x20
    c090:      	cset	w10, eq
    c094:      	cmp	x21, #0x2d
    c098:      	cset	w11, eq
    c09c:      	cmp	x21, #0x36
    c0a0:      	cset	w12, eq
    c0a4:      	cmp	x21, #0x37
    c0a8:      	cset	w13, eq
    c0ac:      	cmp	x21, #0x38
    c0b0:      	cset	w14, eq
    c0b4:      	cmp	x21, #0x39
    c0b8:      	cset	w15, eq
    c0bc:      	movz	x26, #0x0, lsl #48
    c0c0:      	b	0xc1e4 <_stogir.vector-arithmetic.operands+0x238>
    c0c4:      	movz	x2, #0x0, lsl #48
    c0c8:      	b	0xc0d8 <_stogir.vector-arithmetic.operands+0x12c>
    c0cc:      	movz	x2, #0x0, lsl #48
    c0d0:      	b	0xc0e0 <_stogir.vector-arithmetic.operands+0x134>
    c0d4:      	movz	x2, #0x0, lsl #48
    c0d8:      	b	0xc0f0 <_stogir.vector-arithmetic.operands+0x144>
    c0dc:      	movz	x2, #0x0, lsl #48
    c0e0:      	str	x4, [sp, #0x20]
    c0e4:      	str	x5, [sp, #0x28]
    c0e8:      	b	0xc0f0 <_stogir.vector-arithmetic.operands+0x144>
    c0ec:      	movz	x2, #0x0, lsl #48
    c0f0:      	cmp	x2, #0x0
    c0f4:      	b.eq	0xc128 <_stogir.vector-arithmetic.operands+0x17c>
    c0f8:      	uxtb	w16, w28
    c0fc:      	cmp	w16, wzr
    c100:      	b.eq	0xc114 <_stogir.vector-arithmetic.operands+0x168>
    c104:      	ldr	x2, [x20]
    c108:      	add	x2, x2, x27, lsl #4
    c10c:      	ldr	x2, [x2]
    c110:      	b	0xc120 <_stogir.vector-arithmetic.operands+0x174>
    c114:      	ldr	x2, [x20, #0x28]
    c118:      	add	x2, x2, x3, lsl #4
    c11c:      	ldr	x2, [x2]
    c120:      	mov	x3, #0x1                ; =1
    c124:      	b	0xc130 <_stogir.vector-arithmetic.operands+0x184>
    c128:      	movz	x3, #0x0, lsl #48
    c12c:      	movz	x2, #0x0, lsl #48
    c130:      	lsr	w3, w3, #0
    c134:      	lsr	x16, x3, #0
    c138:      	cmp	x16, #0x1
    c13c:      	b.eq	0xc158 <_stogir.vector-arithmetic.operands+0x1ac>
    c140:      	b.lo	0xc148 <_stogir.vector-arithmetic.operands+0x19c>
    c144:      	b	0xc15c <_stogir.vector-arithmetic.operands+0x1b0>
    c148:      	cmp	x16, #0x0
    c14c:      	b.eq	0xc154 <_stogir.vector-arithmetic.operands+0x1a8>
    c150:      	b	0xc15c <_stogir.vector-arithmetic.operands+0x1b0>
    c154:      	b	0xc160 <_stogir.vector-arithmetic.operands+0x1b4>
    c158:      	b	0xc16c <_stogir.vector-arithmetic.operands+0x1c0>
    c15c:      	b	0xc4cc <_stogir.vector-arithmetic.operands+0x520>
    c160:      	ldr	x0, [sp, #0x10]
    c164:      	mov	x1, #0x21               ; =33
    c168:      	b	0xc1c8 <_stogir.vector-arithmetic.operands+0x21c>
    c16c:      	lsr	w3, w2, #0
    c170:      	ubfx	x3, x3, #8, #8
    c174:      	cmp	x3, x22
    c178:      	b.eq	0xc1ac <_stogir.vector-arithmetic.operands+0x200>
    c17c:      	cmp	x26, #0x1
    c180:      	b.ne	0xc1c0 <_stogir.vector-arithmetic.operands+0x214>
    c184:      	uxtb	w16, w7
    c188:      	cmp	w16, wzr
    c18c:      	b.eq	0xc1c0 <_stogir.vector-arithmetic.operands+0x214>
    c190:      	uxtb	w16, w8
    c194:      	cmp	w16, wzr
    c198:      	b.eq	0xc1c0 <_stogir.vector-arithmetic.operands+0x214>
    c19c:      	cmp	x3, #0x1
    c1a0:      	b.lt	0xc1c0 <_stogir.vector-arithmetic.operands+0x214>
    c1a4:      	cmp	x3, #0xb
    c1a8:      	b.gt	0xc1c0 <_stogir.vector-arithmetic.operands+0x214>
    c1ac:      	uxtb	w2, w2
    c1b0:      	cmp	x2, #0x48
    c1b4:      	b.eq	0xc1c0 <_stogir.vector-arithmetic.operands+0x214>
    c1b8:      	cmp	x2, #0x46
    c1bc:      	b.ne	0xc1c8 <_stogir.vector-arithmetic.operands+0x21c>
    c1c0:      	ldr	x0, [sp, #0x18]
    c1c4:      	mov	x1, #0x32               ; =50
    c1c8:      	add	x2, x26, #0x1
    c1cc:      	lsr	w2, w2, #0
    c1d0:      	sxtw	x26, w2
    c1d4:      	ldr	x2, [sp, #0x10]
    c1d8:      	ldr	x3, [sp, #0x18]
    c1dc:      	ldr	x4, [sp, #0x20]
    c1e0:      	ldr	x5, [sp, #0x28]
    c1e4:      	uxtb	w16, w9
    c1e8:      	cmp	w16, wzr
    c1ec:      	b.ne	0xc240 <_stogir.vector-arithmetic.operands+0x294>
    c1f0:      	uxtb	w16, w10
    c1f4:      	cmp	w16, wzr
    c1f8:      	b.ne	0xc240 <_stogir.vector-arithmetic.operands+0x294>
    c1fc:      	uxtb	w16, w11
    c200:      	cmp	w16, wzr
    c204:      	b.ne	0xc240 <_stogir.vector-arithmetic.operands+0x294>
    c208:      	uxtb	w16, w12
    c20c:      	cmp	w16, wzr
    c210:      	b.ne	0xc240 <_stogir.vector-arithmetic.operands+0x294>
    c214:      	uxtb	w16, w13
    c218:      	cmp	w16, wzr
    c21c:      	b.ne	0xc240 <_stogir.vector-arithmetic.operands+0x294>
    c220:      	uxtb	w16, w14
    c224:      	cmp	w16, wzr
    c228:      	b.ne	0xc240 <_stogir.vector-arithmetic.operands+0x294>
    c22c:      	uxtb	w16, w15
    c230:      	cmp	w16, wzr
    c234:      	b.ne	0xc240 <_stogir.vector-arithmetic.operands+0x294>
    c238:      	mov	x27, #0x2               ; =2
    c23c:      	b	0xc244 <_stogir.vector-arithmetic.operands+0x298>
    c240:      	mov	x27, #0x1               ; =1
    c244:      	cmp	x26, x27
    c248:      	b.ge	0xc310 <_stogir.vector-arithmetic.operands+0x364>
    c24c:      	cmp	x26, #0x0
    c250:      	b.ne	0xc25c <_stogir.vector-arithmetic.operands+0x2b0>
    c254:      	mov	x27, x23
    c258:      	b	0xc260 <_stogir.vector-arithmetic.operands+0x2b4>
    c25c:      	mov	x27, x24
    c260:      	lsr	w27, w27, #0
    c264:      	sxtw	x27, w27
    c268:      	cmp	x27, #0x0
    c26c:      	cset	w28, gt
    c270:      	str	x2, [sp, #0x10]
    c274:      	movz	x16, #0x0, lsl #48
    c278:      	sub	x2, x16, x27
    c27c:      	str	x3, [sp, #0x18]
    c280:      	sub	x3, x2, #0x1
    c284:      	uxtb	w16, w28
    c288:      	cmp	w16, wzr
    c28c:      	b.eq	0xc2c8 <_stogir.vector-arithmetic.operands+0x31c>
    c290:      	ldr	x2, [x20, #0x8]
    c294:      	cmp	x27, x2
    c298:      	b.ge	0xc0dc <_stogir.vector-arithmetic.operands+0x130>
    c29c:      	ldr	x2, [x4, #0x8]
    c2a0:      	cmp	x27, x2
    c2a4:      	b.ge	0xc0cc <_stogir.vector-arithmetic.operands+0x120>
    c2a8:      	ldr	x2, [x20, #0x78]
    c2ac:      	add	x2, x2, x27, lsl #2
    c2b0:      	ldr	w2, [x2]
    c2b4:      	sxtw	x2, w2
    c2b8:      	cmp	x2, #0x0
    c2bc:      	cset	w2, ge
    c2c0:      	ubfx	x2, x2, #0, #8
    c2c4:      	b	0xc0d0 <_stogir.vector-arithmetic.operands+0x124>
    c2c8:      	cmp	x27, #0x0
    c2cc:      	b.ge	0xc5b0 <_stogir.vector-arithmetic.operands+0x604>
    c2d0:      	str	x4, [sp, #0x20]
    c2d4:      	ldr	x4, [x5, #0x8]
    c2d8:      	str	x5, [sp, #0x28]
    c2dc:      	ldr	x5, [x6, #0x8]
    c2e0:      	cmp	x4, x5
    c2e4:      	b.ne	0xc0d4 <_stogir.vector-arithmetic.operands+0x128>
    c2e8:      	cmp	x2, x4
    c2ec:      	b.gt	0xc0c4 <_stogir.vector-arithmetic.operands+0x118>
    c2f0:      	ldr	x2, [x20, #0x50]
    c2f4:      	add	x2, x2, x3, lsl #2
    c2f8:      	ldr	w2, [x2]
    c2fc:      	sxtw	x2, w2
    c300:      	cmp	x2, #0x0
    c304:      	cset	w2, gt
    c308:      	ubfx	x2, x2, #0, #8
    c30c:      	b	0xc0c8 <_stogir.vector-arithmetic.operands+0x11c>
    c310:      	sxtw	x25, w25
    c314:      	cmp	x25, #0x0
    c318:      	b.ne	0xc324 <_stogir.vector-arithmetic.operands+0x378>
    c31c:      	movz	x2, #0x0, lsl #48
    c320:      	b	0xc328 <_stogir.vector-arithmetic.operands+0x37c>
    c324:      	mov	x2, #0x1                ; =1
    c328:      	cmp	x2, #0x0
    c32c:      	b.eq	0xc35c <_stogir.vector-arithmetic.operands+0x3b0>
    c330:      	cmp	x21, #0x1d
    c334:      	b.ne	0xc418 <_stogir.vector-arithmetic.operands+0x46c>
    c338:      	mov	x2, #0x1                ; =1
    c33c:      	b	0xc424 <_stogir.vector-arithmetic.operands+0x478>
    c340:      	mov	x2, #0x1                ; =1
    c344:      	cmp	x2, #0x0
    c348:      	b.eq	0xc3bc <_stogir.vector-arithmetic.operands+0x410>
    c34c:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c34c:  ARM64_RELOC_PAGE21	l_stogir.494
    c350:      	ldr	x16, [x16]
		000000000000c350:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    c354:      	orr	x0, x16, xzr
    c358:      	mov	x1, #0x23               ; =35
    c35c:      	cmp	x1, #0x0
    c360:      	b.ne	0xc374 <_stogir.vector-arithmetic.operands+0x3c8>
    c364:      	and	x0, x22, #0xffffffff
    c368:      	movz	x2, #0x0, lsl #48
    c36c:      	movz	x1, #0x0, lsl #48
    c370:      	b	0xc378 <_stogir.vector-arithmetic.operands+0x3cc>
    c374:      	mov	x2, #0x1                ; =1
    c378:      	str	x2, [x19]
    c37c:      	str	x0, [x19, #0x8]
    c380:      	str	x1, [x19, #0x10]
    c384:      	ldr	x19, [sp, #0x30]
    c388:      	ldr	x20, [sp, #0x38]
    c38c:      	ldr	x21, [sp, #0x40]
    c390:      	ldr	x22, [sp, #0x48]
    c394:      	ldr	x23, [sp, #0x50]
    c398:      	ldr	x24, [sp, #0x58]
    c39c:      	ldr	x25, [sp, #0x60]
    c3a0:      	ldr	x26, [sp, #0x68]
    c3a4:      	ldr	x27, [sp, #0x70]
    c3a8:      	ldr	x28, [sp, #0x78]
    c3ac:      	ldr	x29, [sp]
    c3b0:      	ldr	x30, [sp, #0x8]
    c3b4:      	add	sp, sp, #0x80
    c3b8:      	ret
    c3bc:      	cmp	x25, #0x0
    c3c0:      	cset	w2, gt
    c3c4:      	movz	x16, #0x0, lsl #48
    c3c8:      	sub	x3, x16, x25
    c3cc:      	sub	x4, x3, #0x1
    c3d0:      	uxtb	w16, w2
    c3d4:      	cmp	w16, wzr
    c3d8:      	b.eq	0xc484 <_stogir.vector-arithmetic.operands+0x4d8>
    c3dc:      	ldr	x3, [x20, #0x8]
    c3e0:      	cmp	x25, x3
    c3e4:      	b.ge	0xc4d4 <_stogir.vector-arithmetic.operands+0x528>
    c3e8:      	add	x3, x20, #0x78
    c3ec:      	ldr	x3, [x3, #0x8]
    c3f0:      	cmp	x25, x3
    c3f4:      	b.ge	0xc598 <_stogir.vector-arithmetic.operands+0x5ec>
    c3f8:      	ldr	x3, [x20, #0x78]
    c3fc:      	add	x3, x3, x25, lsl #2
    c400:      	ldr	w3, [x3]
    c404:      	sxtw	x3, w3
    c408:      	cmp	x3, #0x0
    c40c:      	cset	w3, ge
    c410:      	ubfx	x3, x3, #0, #8
    c414:      	b	0xc59c <_stogir.vector-arithmetic.operands+0x5f0>
    c418:      	cmp	x21, #0x1e
    c41c:      	cset	w2, eq
    c420:      	ubfx	x2, x2, #0, #8
    c424:      	cmp	x2, #0x0
    c428:      	b.eq	0xc340 <_stogir.vector-arithmetic.operands+0x394>
    c42c:      	movz	x2, #0x0, lsl #48
    c430:      	b	0xc344 <_stogir.vector-arithmetic.operands+0x398>
    c434:      	movz	x3, #0x0, lsl #48
    c438:      	uxtb	w3, w3
    c43c:      	and	x3, x3, #0x2
    c440:      	uxtb	w3, w3
    c444:      	cmp	x3, #0x0
    c448:      	cset	w3, eq
    c44c:      	uxtb	w16, w3
    c450:      	cmp	w16, wzr
    c454:      	cset	x3, eq
    c458:      	cmp	x3, #0x0
    c45c:      	b.ne	0xc480 <_stogir.vector-arithmetic.operands+0x4d4>
    c460:      	cmp	x2, #0x65
    c464:      	b.eq	0xc480 <_stogir.vector-arithmetic.operands+0x4d4>
    c468:      	cmp	x2, #0x66
    c46c:      	b.eq	0xc480 <_stogir.vector-arithmetic.operands+0x4d4>
    c470:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c470:  ARM64_RELOC_PAGE21	l_stogir.495
    c474:      	ldr	x16, [x16]
		000000000000c474:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    c478:      	orr	x0, x16, xzr
    c47c:      	mov	x1, #0x34               ; =52
    c480:      	b	0xc35c <_stogir.vector-arithmetic.operands+0x3b0>
    c484:      	cmp	x25, #0x0
    c488:      	b.ge	0xc4dc <_stogir.vector-arithmetic.operands+0x530>
    c48c:      	add	x5, x20, #0x28
    c490:      	add	x6, x20, #0x50
    c494:      	ldr	x5, [x5, #0x8]
    c498:      	ldr	x6, [x6, #0x8]
    c49c:      	cmp	x5, x6
    c4a0:      	b.ne	0xc590 <_stogir.vector-arithmetic.operands+0x5e4>
    c4a4:      	cmp	x3, x5
    c4a8:      	b.gt	0xc5a0 <_stogir.vector-arithmetic.operands+0x5f4>
    c4ac:      	ldr	x3, [x20, #0x50]
    c4b0:      	add	x3, x3, x4, lsl #2
    c4b4:      	ldr	w3, [x3]
    c4b8:      	sxtw	x3, w3
    c4bc:      	cmp	x3, #0x0
    c4c0:      	cset	w3, gt
    c4c4:      	ubfx	x3, x3, #0, #8
    c4c8:      	b	0xc5a4 <_stogir.vector-arithmetic.operands+0x5f8>
    c4cc:      	brk	#0
    c4d0:      	b	0xc4cc <_stogir.vector-arithmetic.operands+0x520>
    c4d4:      	movz	x3, #0x0, lsl #48
    c4d8:      	b	0xc4e0 <_stogir.vector-arithmetic.operands+0x534>
    c4dc:      	movz	x3, #0x0, lsl #48
    c4e0:      	cmp	x3, #0x0
    c4e4:      	b.eq	0xc518 <_stogir.vector-arithmetic.operands+0x56c>
    c4e8:      	uxtb	w16, w2
    c4ec:      	cmp	w16, wzr
    c4f0:      	b.eq	0xc504 <_stogir.vector-arithmetic.operands+0x558>
    c4f4:      	ldr	x2, [x20]
    c4f8:      	add	x2, x2, x25, lsl #4
    c4fc:      	ldr	x2, [x2]
    c500:      	b	0xc510 <_stogir.vector-arithmetic.operands+0x564>
    c504:      	ldr	x2, [x20, #0x28]
    c508:      	add	x2, x2, x4, lsl #4
    c50c:      	ldr	x2, [x2]
    c510:      	mov	x3, #0x1                ; =1
    c514:      	b	0xc520 <_stogir.vector-arithmetic.operands+0x574>
    c518:      	movz	x3, #0x0, lsl #48
    c51c:      	movz	x2, #0x0, lsl #48
    c520:      	lsr	w3, w3, #0
    c524:      	lsr	x16, x3, #0
    c528:      	cmp	x16, #0x1
    c52c:      	b.eq	0xc548 <_stogir.vector-arithmetic.operands+0x59c>
    c530:      	b.lo	0xc538 <_stogir.vector-arithmetic.operands+0x58c>
    c534:      	b	0xc54c <_stogir.vector-arithmetic.operands+0x5a0>
    c538:      	cmp	x16, #0x0
    c53c:      	b.eq	0xc544 <_stogir.vector-arithmetic.operands+0x598>
    c540:      	b	0xc54c <_stogir.vector-arithmetic.operands+0x5a0>
    c544:      	b	0xc550 <_stogir.vector-arithmetic.operands+0x5a4>
    c548:      	b	0xc564 <_stogir.vector-arithmetic.operands+0x5b8>
    c54c:      	b	0xc5a8 <_stogir.vector-arithmetic.operands+0x5fc>
    c550:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c550:  ARM64_RELOC_PAGE21	l_stogir.496
    c554:      	ldr	x16, [x16]
		000000000000c554:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    c558:      	orr	x0, x16, xzr
    c55c:      	mov	x1, #0x1d               ; =29
    c560:      	b	0xc480 <_stogir.vector-arithmetic.operands+0x4d4>
    c564:      	cmp	x25, #0x0
    c568:      	b.le	0xc470 <_stogir.vector-arithmetic.operands+0x4c4>
    c56c:      	uxtb	w2, w2
    c570:      	cmp	x2, #0x83
    c574:      	b.ge	0xc434 <_stogir.vector-arithmetic.operands+0x488>
    c578:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c578:  ARM64_RELOC_PAGE21	l_stogir.497
    c57c:      	ldr	x16, [x16]
		000000000000c57c:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    c580:      	orr	x3, x16, xzr
    c584:      	add	x3, x2, x3
    c588:      	ldrb	w3, [x3]
    c58c:      	b	0xc438 <_stogir.vector-arithmetic.operands+0x48c>
    c590:      	movz	x3, #0x0, lsl #48
    c594:      	b	0xc4e0 <_stogir.vector-arithmetic.operands+0x534>
    c598:      	movz	x3, #0x0, lsl #48
    c59c:      	b	0xc4d8 <_stogir.vector-arithmetic.operands+0x52c>
    c5a0:      	movz	x3, #0x0, lsl #48
    c5a4:      	b	0xc594 <_stogir.vector-arithmetic.operands+0x5e8>
    c5a8:      	brk	#0
    c5ac:      	b	0xc5a8 <_stogir.vector-arithmetic.operands+0x5fc>
    c5b0:      	str	x4, [sp, #0x20]
    c5b4:      	str	x5, [sp, #0x28]
    c5b8:      	b	0xc0ec <_stogir.vector-arithmetic.operands+0x140>

000000000000c5bc <_stogir.switch.key>:
    c5bc:      	sub	sp, sp, #0x30
    c5c0:      	str	x19, [sp]
    c5c4:      	str	x20, [sp, #0x8]
    c5c8:      	str	x21, [sp, #0x10]
    c5cc:      	str	x22, [sp, #0x18]
    c5d0:      	str	x23, [sp, #0x20]
    c5d4:      	sxtw	x2, w2
    c5d8:      	cmp	x2, #0x1
    c5dc:      	b.lt	0xc654 <_stogir.switch.key+0x98>
    c5e0:      	cmp	x2, #0xb
    c5e4:      	cset	w3, le
    c5e8:      	uxtb	w16, w3
    c5ec:      	cmp	w16, wzr
    c5f0:      	b.eq	0xc654 <_stogir.switch.key+0x98>
    c5f4:      	sxtw	x1, w1
    c5f8:      	cmp	x1, #0x0
    c5fc:      	cset	w4, gt
    c600:      	movz	x16, #0x0, lsl #48
    c604:      	sub	x5, x16, x1
    c608:      	sub	x6, x5, #0x1
    c60c:      	uxtb	w16, w4
    c610:      	cmp	w16, wzr
    c614:      	b.eq	0xc6d0 <_stogir.switch.key+0x114>
    c618:      	ldr	x5, [x0, #0x8]
    c61c:      	cmp	x1, x5
    c620:      	b.ge	0xc718 <_stogir.switch.key+0x15c>
    c624:      	add	x5, x0, #0x78
    c628:      	ldr	x5, [x5, #0x8]
    c62c:      	cmp	x1, x5
    c630:      	b.ge	0xc858 <_stogir.switch.key+0x29c>
    c634:      	ldr	x5, [x0, #0x78]
    c638:      	add	x5, x5, x1, lsl #2
    c63c:      	ldr	w5, [x5]
    c640:      	sxtw	x5, w5
    c644:      	cmp	x5, #0x0
    c648:      	cset	w5, ge
    c64c:      	ubfx	x5, x5, #0, #8
    c650:      	b	0xc85c <_stogir.switch.key+0x2a0>
    c654:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c654:  ARM64_RELOC_PAGE21	l_stogir.498
    c658:      	ldr	x16, [x16]
		000000000000c658:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    c65c:      	orr	x0, x16, xzr
    c660:      	mov	x1, #0x1                ; =1
    c664:      	mov	x2, #0x24               ; =36
    c668:      	str	x1, [x8]
    c66c:      	str	x0, [x8, #0x8]
    c670:      	str	x2, [x8, #0x10]
    c674:      	ldr	x19, [sp]
    c678:      	ldr	x20, [sp, #0x8]
    c67c:      	ldr	x21, [sp, #0x10]
    c680:      	ldr	x22, [sp, #0x18]
    c684:      	ldr	x23, [sp, #0x20]
    c688:      	add	sp, sp, #0x30
    c68c:      	ret
    c690:      	mov	x23, #0x1               ; =1
    c694:      	cmp	x1, #0x0
    c698:      	b.ge	0xc6b8 <_stogir.switch.key+0xfc>
    c69c:      	lsr	w1, w4, #0
    c6a0:      	uxtb	w4, w4
    c6a4:      	ubfx	x1, x1, #8, #8
    c6a8:      	cmp	x4, x1
    c6ac:      	b.eq	0xc900 <_stogir.switch.key+0x344>
    c6b0:      	cmp	x4, #0x49
    c6b4:      	b.eq	0xc900 <_stogir.switch.key+0x344>
    c6b8:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c6b8:  ARM64_RELOC_PAGE21	l_stogir.499
    c6bc:      	ldr	x16, [x16]
		000000000000c6bc:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    c6c0:      	orr	x0, x16, xzr
    c6c4:      	mov	x1, #0x1                ; =1
    c6c8:      	mov	x2, #0x30               ; =48
    c6cc:      	b	0xc668 <_stogir.switch.key+0xac>
    c6d0:      	cmp	x1, #0x0
    c6d4:      	b.ge	0xc720 <_stogir.switch.key+0x164>
    c6d8:      	add	x7, x0, #0x28
    c6dc:      	add	x9, x0, #0x50
    c6e0:      	ldr	x7, [x7, #0x8]
    c6e4:      	ldr	x9, [x9, #0x8]
    c6e8:      	cmp	x7, x9
    c6ec:      	b.ne	0xc850 <_stogir.switch.key+0x294>
    c6f0:      	cmp	x5, x7
    c6f4:      	b.gt	0xc8f8 <_stogir.switch.key+0x33c>
    c6f8:      	ldr	x5, [x0, #0x50]
    c6fc:      	add	x5, x5, x6, lsl #2
    c700:      	ldr	w5, [x5]
    c704:      	sxtw	x5, w5
    c708:      	cmp	x5, #0x0
    c70c:      	cset	w5, gt
    c710:      	ubfx	x5, x5, #0, #8
    c714:      	b	0xc8fc <_stogir.switch.key+0x340>
    c718:      	movz	x5, #0x0, lsl #48
    c71c:      	b	0xc724 <_stogir.switch.key+0x168>
    c720:      	movz	x5, #0x0, lsl #48
    c724:      	cmp	x5, #0x0
    c728:      	b.eq	0xc764 <_stogir.switch.key+0x1a8>
    c72c:      	uxtb	w16, w4
    c730:      	cmp	w16, wzr
    c734:      	b.eq	0xc74c <_stogir.switch.key+0x190>
    c738:      	ldr	x0, [x0]
    c73c:      	add	x0, x0, x1, lsl #4
    c740:      	ldr	x4, [x0]
    c744:      	ldr	x0, [x0, #0x8]
    c748:      	b	0xc75c <_stogir.switch.key+0x1a0>
    c74c:      	ldr	x0, [x0, #0x28]
    c750:      	add	x0, x0, x6, lsl #4
    c754:      	ldr	x4, [x0]
    c758:      	ldr	x0, [x0, #0x8]
    c75c:      	mov	x5, #0x1                ; =1
    c760:      	b	0xc770 <_stogir.switch.key+0x1b4>
    c764:      	movz	x5, #0x0, lsl #48
    c768:      	movz	x4, #0x0, lsl #48
    c76c:      	movz	x0, #0x0, lsl #48
    c770:      	lsr	w5, w5, #0
    c774:      	lsr	x16, x5, #0
    c778:      	cmp	x16, #0x1
    c77c:      	b.eq	0xc798 <_stogir.switch.key+0x1dc>
    c780:      	b.lo	0xc788 <_stogir.switch.key+0x1cc>
    c784:      	b	0xc79c <_stogir.switch.key+0x1e0>
    c788:      	cmp	x16, #0x0
    c78c:      	b.eq	0xc794 <_stogir.switch.key+0x1d8>
    c790:      	b	0xc79c <_stogir.switch.key+0x1e0>
    c794:      	b	0xc7a0 <_stogir.switch.key+0x1e4>
    c798:      	b	0xc7b8 <_stogir.switch.key+0x1fc>
    c79c:      	b	0xc9a0 <_stogir.switch.key+0x3e4>
    c7a0:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000c7a0:  ARM64_RELOC_PAGE21	l_stogir.500
    c7a4:      	ldr	x16, [x16]
		000000000000c7a4:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c7a8:      	orr	x0, x16, xzr
    c7ac:      	mov	x1, #0x1                ; =1
    c7b0:      	mov	x2, #0x1c               ; =28
    c7b4:      	b	0xc6cc <_stogir.switch.key+0x110>
    c7b8:      	cmp	x2, #0x1
    c7bc:      	cset	w5, eq
    c7c0:      	cmp	x2, #0x0
    c7c4:      	cset	w6, eq
    c7c8:      	cmp	x2, #0x2
    c7cc:      	cset	w7, eq
    c7d0:      	cmp	x2, #0x7
    c7d4:      	cset	w9, eq
    c7d8:      	cmp	x2, #0x8
    c7dc:      	cset	w10, eq
    c7e0:      	cmp	x2, #0x3
    c7e4:      	cset	w11, eq
    c7e8:      	cmp	x2, #0x9
    c7ec:      	cset	w12, eq
    c7f0:      	cmp	x2, #0x4
    c7f4:      	cset	w13, eq
    c7f8:      	cmp	x2, #0xa
    c7fc:      	cset	w14, eq
    c800:      	cmp	x2, #0xd
    c804:      	cset	w15, eq
    c808:      	cmp	x2, #0x5
    c80c:      	cset	w19, eq
    c810:      	cmp	x2, #0xb
    c814:      	cset	w20, eq
    c818:      	cmp	x2, #0xc
    c81c:      	cset	w21, eq
    c820:      	cmp	x2, #0x6
    c824:      	cset	w22, eq
    c828:      	uxtb	w16, w22
    c82c:      	cmp	w16, wzr
    c830:      	mov	x16, #0x8               ; =8
    c834:      	movn	x17, #0x0, lsl #48
    c838:      	csel	x22, x16, x17, ne
    c83c:      	uxtb	w16, w6
    c840:      	cmp	w16, wzr
    c844:      	b.eq	0xc860 <_stogir.switch.key+0x2a4>
    c848:      	movz	x23, #0x0, lsl #48
    c84c:      	b	0xc694 <_stogir.switch.key+0xd8>
    c850:      	movz	x5, #0x0, lsl #48
    c854:      	b	0xc724 <_stogir.switch.key+0x168>
    c858:      	movz	x5, #0x0, lsl #48
    c85c:      	b	0xc71c <_stogir.switch.key+0x160>
    c860:      	uxtb	w16, w5
    c864:      	cmp	w16, wzr
    c868:      	b.ne	0xc690 <_stogir.switch.key+0xd4>
    c86c:      	uxtb	w16, w7
    c870:      	cmp	w16, wzr
    c874:      	b.ne	0xc690 <_stogir.switch.key+0xd4>
    c878:      	uxtb	w16, w9
    c87c:      	cmp	w16, wzr
    c880:      	b.ne	0xc690 <_stogir.switch.key+0xd4>
    c884:      	uxtb	w16, w10
    c888:      	cmp	w16, wzr
    c88c:      	b.ne	0xc690 <_stogir.switch.key+0xd4>
    c890:      	uxtb	w16, w11
    c894:      	cmp	w16, wzr
    c898:      	b.ne	0xc998 <_stogir.switch.key+0x3dc>
    c89c:      	uxtb	w16, w12
    c8a0:      	cmp	w16, wzr
    c8a4:      	b.ne	0xc998 <_stogir.switch.key+0x3dc>
    c8a8:      	uxtb	w16, w13
    c8ac:      	cmp	w16, wzr
    c8b0:      	b.ne	0xca70 <_stogir.switch.key+0x4b4>
    c8b4:      	uxtb	w16, w14
    c8b8:      	cmp	w16, wzr
    c8bc:      	b.ne	0xca70 <_stogir.switch.key+0x4b4>
    c8c0:      	uxtb	w16, w15
    c8c4:      	cmp	w16, wzr
    c8c8:      	b.ne	0xca70 <_stogir.switch.key+0x4b4>
    c8cc:      	uxtb	w16, w19
    c8d0:      	cmp	w16, wzr
    c8d4:      	b.ne	0xca78 <_stogir.switch.key+0x4bc>
    c8d8:      	uxtb	w16, w20
    c8dc:      	cmp	w16, wzr
    c8e0:      	b.ne	0xca78 <_stogir.switch.key+0x4bc>
    c8e4:      	uxtb	w16, w21
    c8e8:      	cmp	w16, wzr
    c8ec:      	b.ne	0xca78 <_stogir.switch.key+0x4bc>
    c8f0:      	mov	x23, x22
    c8f4:      	b	0xca7c <_stogir.switch.key+0x4c0>
    c8f8:      	movz	x5, #0x0, lsl #48
    c8fc:      	b	0xc854 <_stogir.switch.key+0x298>
    c900:      	cmp	x1, x2
    c904:      	b.ne	0xc6b8 <_stogir.switch.key+0xfc>
    c908:      	lsr	w23, w23, #0
    c90c:      	lsr	w1, w0, #0
    c910:      	sxtw	x23, w23
    c914:      	ubfx	x1, x1, #0, #32
    c918:      	lsr	x0, x0, #32
    c91c:      	lsl	x4, x23, #3
    c920:      	ubfx	x0, x0, #0, #32
    c924:      	lsr	w4, w4, #0
    c928:      	lsl	x0, x0, #32
    c92c:      	sxtw	x4, w4
    c930:      	orr	x0, x0, x1
    c934:      	cmp	x4, #0x40
    c938:      	b.ge	0xc948 <_stogir.switch.key+0x38c>
    c93c:      	lsr	x1, x0, x4
    c940:      	cmp	x1, #0x0
    c944:      	b.ne	0xc6b8 <_stogir.switch.key+0xfc>
    c948:      	uxtb	w16, w5
    c94c:      	cmp	w16, wzr
    c950:      	b.eq	0xc95c <_stogir.switch.key+0x3a0>
    c954:      	cmp	x0, #0x1
    c958:      	b.hi	0xc6b8 <_stogir.switch.key+0xfc>
    c95c:      	cmp	x2, #0x7
    c960:      	b.lt	0xc984 <_stogir.switch.key+0x3c8>
    c964:      	uxtb	w16, w3
    c968:      	cmp	w16, wzr
    c96c:      	b.eq	0xc984 <_stogir.switch.key+0x3c8>
    c970:      	uxtb	w16, w6
    c974:      	cmp	w16, wzr
    c978:      	b.eq	0xc9d8 <_stogir.switch.key+0x41c>
    c97c:      	movz	x22, #0x0, lsl #48
    c980:      	b	0xc9ac <_stogir.switch.key+0x3f0>
    c984:      	movz	x1, #0x0, lsl #48
    c988:      	eor	x0, x1, x0
    c98c:      	movz	x1, #0x0, lsl #48
    c990:      	movz	x2, #0x0, lsl #48
    c994:      	b	0xc6cc <_stogir.switch.key+0x110>
    c998:      	mov	x23, #0x2               ; =2
    c99c:      	b	0xc694 <_stogir.switch.key+0xd8>
    c9a0:      	brk	#0
    c9a4:      	b	0xc9a0 <_stogir.switch.key+0x3e4>
    c9a8:      	mov	x22, #0x1               ; =1
    c9ac:      	lsr	w22, w22, #0
    c9b0:      	sxtw	x22, w22
    c9b4:      	lsl	x1, x22, #3
    c9b8:      	lsr	w1, w1, #0
    c9bc:      	sxtw	x1, w1
    c9c0:      	sub	x1, x1, #0x1
    c9c4:      	lsr	w1, w1, #0
    c9c8:      	sxtw	x1, w1
    c9cc:      	mov	x16, #0x1               ; =1
    c9d0:      	lsl	x1, x16, x1
    c9d4:      	b	0xc988 <_stogir.switch.key+0x3cc>
    c9d8:      	uxtb	w16, w5
    c9dc:      	cmp	w16, wzr
    c9e0:      	b.ne	0xc9a8 <_stogir.switch.key+0x3ec>
    c9e4:      	uxtb	w16, w7
    c9e8:      	cmp	w16, wzr
    c9ec:      	b.ne	0xc9a8 <_stogir.switch.key+0x3ec>
    c9f0:      	uxtb	w16, w9
    c9f4:      	cmp	w16, wzr
    c9f8:      	b.ne	0xc9a8 <_stogir.switch.key+0x3ec>
    c9fc:      	uxtb	w16, w10
    ca00:      	cmp	w16, wzr
    ca04:      	b.ne	0xc9a8 <_stogir.switch.key+0x3ec>
    ca08:      	uxtb	w16, w11
    ca0c:      	cmp	w16, wzr
    ca10:      	b.ne	0xca80 <_stogir.switch.key+0x4c4>
    ca14:      	uxtb	w16, w12
    ca18:      	cmp	w16, wzr
    ca1c:      	b.ne	0xca80 <_stogir.switch.key+0x4c4>
    ca20:      	uxtb	w16, w13
    ca24:      	cmp	w16, wzr
    ca28:      	b.ne	0xca88 <_stogir.switch.key+0x4cc>
    ca2c:      	uxtb	w16, w14
    ca30:      	cmp	w16, wzr
    ca34:      	b.ne	0xca88 <_stogir.switch.key+0x4cc>
    ca38:      	uxtb	w16, w15
    ca3c:      	cmp	w16, wzr
    ca40:      	b.ne	0xca88 <_stogir.switch.key+0x4cc>
    ca44:      	uxtb	w16, w19
    ca48:      	cmp	w16, wzr
    ca4c:      	b.ne	0xca68 <_stogir.switch.key+0x4ac>
    ca50:      	uxtb	w16, w20
    ca54:      	cmp	w16, wzr
    ca58:      	b.ne	0xca68 <_stogir.switch.key+0x4ac>
    ca5c:      	uxtb	w16, w21
    ca60:      	cmp	w16, wzr
    ca64:      	b.eq	0xca6c <_stogir.switch.key+0x4b0>
    ca68:      	mov	x22, #0x8               ; =8
    ca6c:      	b	0xca8c <_stogir.switch.key+0x4d0>
    ca70:      	mov	x23, #0x4               ; =4
    ca74:      	b	0xc99c <_stogir.switch.key+0x3e0>
    ca78:      	mov	x23, #0x8               ; =8
    ca7c:      	b	0xca74 <_stogir.switch.key+0x4b8>
    ca80:      	mov	x22, #0x2               ; =2
    ca84:      	b	0xc9ac <_stogir.switch.key+0x3f0>
    ca88:      	mov	x22, #0x4               ; =4
    ca8c:      	b	0xca84 <_stogir.switch.key+0x4c8>

000000000000ca90 <_stogir.stack.constant-size>:
    ca90:      	sub	sp, sp, #0x10
    ca94:      	str	x29, [sp]
    ca98:      	str	x30, [sp, #0x8]
    ca9c:      	mov	x29, sp
    caa0:      	mov	x2, sp
    caa4:      	sxtw	x1, w1
    caa8:      	sub	sp, sp, #0x10
    caac:      	mov	x3, sp
    cab0:      	cmp	x1, #0x0
    cab4:      	cset	w4, gt
    cab8:      	movz	x16, #0x0, lsl #48
    cabc:      	sub	x5, x16, x1
    cac0:      	sub	x6, x5, #0x1
    cac4:      	uxtb	w16, w4
    cac8:      	cmp	w16, wzr
    cacc:      	b.eq	0xcb0c <_stogir.stack.constant-size+0x7c>
    cad0:      	ldr	x5, [x0, #0x8]
    cad4:      	cmp	x1, x5
    cad8:      	b.ge	0xcb5c <_stogir.stack.constant-size+0xcc>
    cadc:      	add	x5, x0, #0x78
    cae0:      	ldr	x5, [x5, #0x8]
    cae4:      	cmp	x1, x5
    cae8:      	b.ge	0xcca0 <_stogir.stack.constant-size+0x210>
    caec:      	ldr	x5, [x0, #0x78]
    caf0:      	add	x5, x5, x1, lsl #2
    caf4:      	ldr	w5, [x5]
    caf8:      	sxtw	x5, w5
    cafc:      	cmp	x5, #0x0
    cb00:      	cset	w5, ge
    cb04:      	ubfx	x5, x5, #0, #8
    cb08:      	b	0xcca4 <_stogir.stack.constant-size+0x214>
    cb0c:      	cmp	x1, #0x0
    cb10:      	b.ge	0xcb64 <_stogir.stack.constant-size+0xd4>
    cb14:      	add	x7, x0, #0x28
    cb18:      	add	x9, x0, #0x50
    cb1c:      	ldr	x7, [x7, #0x8]
    cb20:      	ldr	x9, [x9, #0x8]
    cb24:      	cmp	x7, x9
    cb28:      	b.ne	0xcb54 <_stogir.stack.constant-size+0xc4>
    cb2c:      	cmp	x5, x7
    cb30:      	b.gt	0xcd28 <_stogir.stack.constant-size+0x298>
    cb34:      	ldr	x5, [x0, #0x50]
    cb38:      	add	x5, x5, x6, lsl #2
    cb3c:      	ldr	w5, [x5]
    cb40:      	sxtw	x5, w5
    cb44:      	cmp	x5, #0x0
    cb48:      	cset	w5, gt
    cb4c:      	ubfx	x5, x5, #0, #8
    cb50:      	b	0xcd2c <_stogir.stack.constant-size+0x29c>
    cb54:      	movz	x5, #0x0, lsl #48
    cb58:      	b	0xcb68 <_stogir.stack.constant-size+0xd8>
    cb5c:      	movz	x5, #0x0, lsl #48
    cb60:      	b	0xcb68 <_stogir.stack.constant-size+0xd8>
    cb64:      	movz	x5, #0x0, lsl #48
    cb68:      	cmp	x5, #0x0
    cb6c:      	b.eq	0xcba8 <_stogir.stack.constant-size+0x118>
    cb70:      	uxtb	w16, w4
    cb74:      	cmp	w16, wzr
    cb78:      	b.eq	0xcb90 <_stogir.stack.constant-size+0x100>
    cb7c:      	ldr	x0, [x0]
    cb80:      	add	x0, x0, x1, lsl #4
    cb84:      	ldr	x4, [x0]
    cb88:      	ldr	x0, [x0, #0x8]
    cb8c:      	b	0xcba0 <_stogir.stack.constant-size+0x110>
    cb90:      	ldr	x0, [x0, #0x28]
    cb94:      	add	x0, x0, x6, lsl #4
    cb98:      	ldr	x4, [x0]
    cb9c:      	ldr	x0, [x0, #0x8]
    cba0:      	mov	x5, #0x1                ; =1
    cba4:      	b	0xcbb4 <_stogir.stack.constant-size+0x124>
    cba8:      	movz	x5, #0x0, lsl #48
    cbac:      	movz	x4, #0x0, lsl #48
    cbb0:      	movz	x0, #0x0, lsl #48
    cbb4:      	lsr	w5, w5, #0
    cbb8:      	lsr	x16, x5, #0
    cbbc:      	cmp	x16, #0x1
    cbc0:      	b.eq	0xcbdc <_stogir.stack.constant-size+0x14c>
    cbc4:      	b.lo	0xcbcc <_stogir.stack.constant-size+0x13c>
    cbc8:      	b	0xcbe0 <_stogir.stack.constant-size+0x150>
    cbcc:      	cmp	x16, #0x0
    cbd0:      	b.eq	0xcbd8 <_stogir.stack.constant-size+0x148>
    cbd4:      	b	0xcbe0 <_stogir.stack.constant-size+0x150>
    cbd8:      	b	0xcbe4 <_stogir.stack.constant-size+0x154>
    cbdc:      	b	0xcc80 <_stogir.stack.constant-size+0x1f0>
    cbe0:      	b	0xcddc <_stogir.stack.constant-size+0x34c>
    cbe4:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000cbe4:  ARM64_RELOC_PAGE21	l_stogir.501
    cbe8:      	ldr	x16, [x16]
		000000000000cbe8:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    cbec:      	orr	x0, x16, xzr
    cbf0:      	mov	x1, #0x1                ; =1
    cbf4:      	mov	x3, #0x18               ; =24
    cbf8:      	b	0xcc5c <_stogir.stack.constant-size+0x1cc>
    cbfc:      	mov	x4, #0x1                ; =1
    cc00:      	ldr	w5, [x3, #0x8]
    cc04:      	ldr	w6, [x3, #0xc]
    cc08:      	cmp	x1, #0x0
    cc0c:      	b.ge	0xcc48 <_stogir.stack.constant-size+0x1b8>
    cc10:      	cmp	x0, #0x1
    cc14:      	b.lt	0xcc48 <_stogir.stack.constant-size+0x1b8>
    cc18:      	cmp	x0, #0xb
    cc1c:      	cset	w1, le
    cc20:      	uxtb	w16, w1
    cc24:      	cmp	w16, wzr
    cc28:      	b.eq	0xcc48 <_stogir.stack.constant-size+0x1b8>
    cc2c:      	ldr	w3, [x3]
    cc30:      	uxtb	w7, w3
    cc34:      	ubfx	x3, x3, #8, #8
    cc38:      	cmp	x7, x3
    cc3c:      	b.eq	0xcd30 <_stogir.stack.constant-size+0x2a0>
    cc40:      	cmp	x7, #0x49
    cc44:      	b.eq	0xcd30 <_stogir.stack.constant-size+0x2a0>
    cc48:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000cc48:  ARM64_RELOC_PAGE21	l_stogir.502
    cc4c:      	ldr	x16, [x16]
		000000000000cc4c:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    cc50:      	orr	x0, x16, xzr
    cc54:      	mov	x1, #0x1                ; =1
    cc58:      	mov	x3, #0x30               ; =48
    cc5c:      	mov	sp, x2
    cc60:      	str	x1, [x8]
    cc64:      	str	x0, [x8, #0x8]
    cc68:      	str	x3, [x8, #0x10]
    cc6c:      	sub	sp, x29, #0x0
    cc70:      	ldr	x29, [sp]
    cc74:      	ldr	x30, [sp, #0x8]
    cc78:      	add	sp, sp, #0x10
    cc7c:      	ret
    cc80:      	lsr	w5, w4, #0
    cc84:      	str	x4, [x3]
    cc88:      	str	x0, [x3, #0x8]
    cc8c:      	ubfx	x0, x5, #8, #8
    cc90:      	cmp	x0, #0x0
    cc94:      	b.ne	0xcca8 <_stogir.stack.constant-size+0x218>
    cc98:      	movz	x4, #0x0, lsl #48
    cc9c:      	b	0xcc00 <_stogir.stack.constant-size+0x170>
    cca0:      	movz	x5, #0x0, lsl #48
    cca4:      	b	0xcb60 <_stogir.stack.constant-size+0xd0>
    cca8:      	cmp	x0, #0x1
    ccac:      	b.eq	0xcbfc <_stogir.stack.constant-size+0x16c>
    ccb0:      	cmp	x0, #0x2
    ccb4:      	b.eq	0xcbfc <_stogir.stack.constant-size+0x16c>
    ccb8:      	cmp	x0, #0x7
    ccbc:      	b.eq	0xcbfc <_stogir.stack.constant-size+0x16c>
    ccc0:      	cmp	x0, #0x8
    ccc4:      	b.eq	0xcbfc <_stogir.stack.constant-size+0x16c>
    ccc8:      	cmp	x0, #0x3
    cccc:      	b.eq	0xcdd4 <_stogir.stack.constant-size+0x344>
    ccd0:      	cmp	x0, #0x9
    ccd4:      	b.eq	0xcdd4 <_stogir.stack.constant-size+0x344>
    ccd8:      	cmp	x0, #0x4
    ccdc:      	b.eq	0xcde4 <_stogir.stack.constant-size+0x354>
    cce0:      	cmp	x0, #0xa
    cce4:      	b.eq	0xcde4 <_stogir.stack.constant-size+0x354>
    cce8:      	cmp	x0, #0xd
    ccec:      	b.eq	0xcde4 <_stogir.stack.constant-size+0x354>
    ccf0:      	cmp	x0, #0x5
    ccf4:      	b.eq	0xcdec <_stogir.stack.constant-size+0x35c>
    ccf8:      	cmp	x0, #0xb
    ccfc:      	b.eq	0xcdec <_stogir.stack.constant-size+0x35c>
    cd00:      	cmp	x0, #0xc
    cd04:      	b.eq	0xcdec <_stogir.stack.constant-size+0x35c>
    cd08:      	cmp	x0, #0x6
    cd0c:      	cset	w4, eq
    cd10:      	uxtb	w16, w4
    cd14:      	cmp	w16, wzr
    cd18:      	mov	x16, #0x8               ; =8
    cd1c:      	movn	x17, #0x0, lsl #48
    cd20:      	csel	x4, x16, x17, ne
    cd24:      	b	0xcdf0 <_stogir.stack.constant-size+0x360>
    cd28:      	movz	x5, #0x0, lsl #48
    cd2c:      	b	0xcb58 <_stogir.stack.constant-size+0xc8>
    cd30:      	lsr	w4, w4, #0
    cd34:      	sxtw	x4, w4
    cd38:      	cmp	x4, #0x0
    cd3c:      	b.le	0xcc48 <_stogir.stack.constant-size+0x1b8>
    cd40:      	ubfx	x5, x5, #0, #32
    cd44:      	ubfx	x6, x6, #0, #32
    cd48:      	lsl	x3, x6, #32
    cd4c:      	orr	x3, x3, x5
    cd50:      	cmp	x4, #0x8
    cd54:      	b.ge	0xcd70 <_stogir.stack.constant-size+0x2e0>
    cd58:      	lsl	x5, x4, #3
    cd5c:      	lsr	w5, w5, #0
    cd60:      	sxtw	x5, w5
    cd64:      	lsr	x5, x3, x5
    cd68:      	cmp	x5, #0x0
    cd6c:      	b.ne	0xcc48 <_stogir.stack.constant-size+0x1b8>
    cd70:      	cmp	x0, #0x7
    cd74:      	b.lt	0xcdb0 <_stogir.stack.constant-size+0x320>
    cd78:      	uxtb	w16, w1
    cd7c:      	cmp	w16, wzr
    cd80:      	b.eq	0xcdb0 <_stogir.stack.constant-size+0x320>
    cd84:      	lsl	x0, x4, #3
    cd88:      	lsr	w0, w0, #0
    cd8c:      	sxtw	x0, w0
    cd90:      	sub	x0, x0, #0x1
    cd94:      	lsr	w0, w0, #0
    cd98:      	sxtw	x0, w0
    cd9c:      	mov	x16, #0x1               ; =1
    cda0:      	lsl	x0, x16, x0
    cda4:      	and	x0, x0, x3
    cda8:      	cmp	x0, #0x0
    cdac:      	b.ne	0xcc48 <_stogir.stack.constant-size+0x1b8>
    cdb0:      	mov	x17, #-0x10             ; =-16
    cdb4:      	movk	x17, #0x7fff, lsl #48
    cdb8:      	cmp	x3, x17
    cdbc:      	b.hi	0xcc48 <_stogir.stack.constant-size+0x1b8>
    cdc0:      	add	x0, x3, #0xf
    cdc4:      	and	x0, x0, #0xfffffffffffffff0
    cdc8:      	movz	x1, #0x0, lsl #48
    cdcc:      	movz	x3, #0x0, lsl #48
    cdd0:      	b	0xcc5c <_stogir.stack.constant-size+0x1cc>
    cdd4:      	mov	x4, #0x2                ; =2
    cdd8:      	b	0xcc00 <_stogir.stack.constant-size+0x170>
    cddc:      	brk	#0
    cde0:      	b	0xcddc <_stogir.stack.constant-size+0x34c>
    cde4:      	mov	x4, #0x4                ; =4
    cde8:      	b	0xcdd8 <_stogir.stack.constant-size+0x348>
    cdec:      	mov	x4, #0x8                ; =8
    cdf0:      	b	0xcde8 <_stogir.stack.constant-size+0x358>

000000000000cdf4 <_stogir.stack.constant-size-aligned>:
    cdf4:      	sub	sp, sp, #0x10
    cdf8:      	cmp	x2, #0x10
    cdfc:      	b.lt	0xce78 <_stogir.stack.constant-size-aligned+0x84>
    ce00:      	cmp	x2, #0x0
    ce04:      	b.le	0xce78 <_stogir.stack.constant-size-aligned+0x84>
    ce08:      	sub	x3, x2, #0x1
    ce0c:      	and	x3, x3, x2
    ce10:      	cmp	x3, #0x0
    ce14:      	b.ne	0xce78 <_stogir.stack.constant-size-aligned+0x84>
    ce18:      	sxtw	x1, w1
    ce1c:      	cmp	x1, #0x0
    ce20:      	cset	w3, gt
    ce24:      	movz	x16, #0x0, lsl #48
    ce28:      	sub	x4, x16, x1
    ce2c:      	sub	x5, x4, #0x1
    ce30:      	uxtb	w16, w3
    ce34:      	cmp	w16, wzr
    ce38:      	b.eq	0xcf10 <_stogir.stack.constant-size-aligned+0x11c>
    ce3c:      	ldr	x4, [x0, #0x8]
    ce40:      	cmp	x1, x4
    ce44:      	b.ge	0xcf58 <_stogir.stack.constant-size-aligned+0x164>
    ce48:      	add	x4, x0, #0x78
    ce4c:      	ldr	x4, [x4, #0x8]
    ce50:      	cmp	x1, x4
    ce54:      	b.ge	0xd028 <_stogir.stack.constant-size-aligned+0x234>
    ce58:      	ldr	x4, [x0, #0x78]
    ce5c:      	add	x4, x4, x1, lsl #2
    ce60:      	ldr	w4, [x4]
    ce64:      	sxtw	x4, w4
    ce68:      	cmp	x4, #0x0
    ce6c:      	cset	w4, ge
    ce70:      	ubfx	x4, x4, #0, #8
    ce74:      	b	0xd02c <_stogir.stack.constant-size-aligned+0x238>
    ce78:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000ce78:  ARM64_RELOC_PAGE21	l_stogir.503
    ce7c:      	ldr	x16, [x16]
		000000000000ce7c:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    ce80:      	orr	x0, x16, xzr
    ce84:      	mov	x1, #0x1                ; =1
    ce88:      	mov	x2, #0x20               ; =32
    ce8c:      	str	x1, [x8]
    ce90:      	str	x0, [x8, #0x8]
    ce94:      	str	x2, [x8, #0x10]
    ce98:      	add	sp, sp, #0x10
    ce9c:      	ret
    cea0:      	mov	x3, #0x1                ; =1
    cea4:      	mov	x16, sp
    cea8:      	ldr	w4, [x16, #0x8]
    ceac:      	mov	x16, sp
    ceb0:      	ldr	w5, [x16, #0xc]
    ceb4:      	cmp	x1, #0x0
    ceb8:      	b.ge	0xcef8 <_stogir.stack.constant-size-aligned+0x104>
    cebc:      	cmp	x0, #0x1
    cec0:      	b.lt	0xcef8 <_stogir.stack.constant-size-aligned+0x104>
    cec4:      	cmp	x0, #0xb
    cec8:      	cset	w1, le
    cecc:      	uxtb	w16, w1
    ced0:      	cmp	w16, wzr
    ced4:      	b.eq	0xcef8 <_stogir.stack.constant-size-aligned+0x104>
    ced8:      	mov	x16, sp
    cedc:      	ldr	w6, [x16]
    cee0:      	uxtb	w7, w6
    cee4:      	ubfx	x6, x6, #8, #8
    cee8:      	cmp	x7, x6
    ceec:      	b.eq	0xd0b8 <_stogir.stack.constant-size-aligned+0x2c4>
    cef0:      	cmp	x7, #0x49
    cef4:      	b.eq	0xd0b8 <_stogir.stack.constant-size-aligned+0x2c4>
    cef8:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000cef8:  ARM64_RELOC_PAGE21	l_stogir.504
    cefc:      	ldr	x16, [x16]
		000000000000cefc:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    cf00:      	orr	x0, x16, xzr
    cf04:      	mov	x1, #0x1                ; =1
    cf08:      	mov	x2, #0x30               ; =48
    cf0c:      	b	0xce8c <_stogir.stack.constant-size-aligned+0x98>
    cf10:      	cmp	x1, #0x0
    cf14:      	b.ge	0xcf60 <_stogir.stack.constant-size-aligned+0x16c>
    cf18:      	add	x6, x0, #0x28
    cf1c:      	add	x7, x0, #0x50
    cf20:      	ldr	x6, [x6, #0x8]
    cf24:      	ldr	x7, [x7, #0x8]
    cf28:      	cmp	x6, x7
    cf2c:      	b.ne	0xd020 <_stogir.stack.constant-size-aligned+0x22c>
    cf30:      	cmp	x4, x6
    cf34:      	b.gt	0xd0b0 <_stogir.stack.constant-size-aligned+0x2bc>
    cf38:      	ldr	x4, [x0, #0x50]
    cf3c:      	add	x4, x4, x5, lsl #2
    cf40:      	ldr	w4, [x4]
    cf44:      	sxtw	x4, w4
    cf48:      	cmp	x4, #0x0
    cf4c:      	cset	w4, gt
    cf50:      	ubfx	x4, x4, #0, #8
    cf54:      	b	0xd0b4 <_stogir.stack.constant-size-aligned+0x2c0>
    cf58:      	movz	x4, #0x0, lsl #48
    cf5c:      	b	0xcf64 <_stogir.stack.constant-size-aligned+0x170>
    cf60:      	movz	x4, #0x0, lsl #48
    cf64:      	cmp	x4, #0x0
    cf68:      	b.eq	0xcfa4 <_stogir.stack.constant-size-aligned+0x1b0>
    cf6c:      	uxtb	w16, w3
    cf70:      	cmp	w16, wzr
    cf74:      	b.eq	0xcf8c <_stogir.stack.constant-size-aligned+0x198>
    cf78:      	ldr	x0, [x0]
    cf7c:      	add	x0, x0, x1, lsl #4
    cf80:      	ldr	x3, [x0]
    cf84:      	ldr	x0, [x0, #0x8]
    cf88:      	b	0xcf9c <_stogir.stack.constant-size-aligned+0x1a8>
    cf8c:      	ldr	x0, [x0, #0x28]
    cf90:      	add	x0, x0, x5, lsl #4
    cf94:      	ldr	x3, [x0]
    cf98:      	ldr	x0, [x0, #0x8]
    cf9c:      	mov	x4, #0x1                ; =1
    cfa0:      	b	0xcfb0 <_stogir.stack.constant-size-aligned+0x1bc>
    cfa4:      	movz	x4, #0x0, lsl #48
    cfa8:      	movz	x3, #0x0, lsl #48
    cfac:      	movz	x0, #0x0, lsl #48
    cfb0:      	lsr	w4, w4, #0
    cfb4:      	lsr	x16, x4, #0
    cfb8:      	cmp	x16, #0x1
    cfbc:      	b.eq	0xcfd8 <_stogir.stack.constant-size-aligned+0x1e4>
    cfc0:      	b.lo	0xcfc8 <_stogir.stack.constant-size-aligned+0x1d4>
    cfc4:      	b	0xcfdc <_stogir.stack.constant-size-aligned+0x1e8>
    cfc8:      	cmp	x16, #0x0
    cfcc:      	b.eq	0xcfd4 <_stogir.stack.constant-size-aligned+0x1e0>
    cfd0:      	b	0xcfdc <_stogir.stack.constant-size-aligned+0x1e8>
    cfd4:      	b	0xcfe0 <_stogir.stack.constant-size-aligned+0x1ec>
    cfd8:      	b	0xcff8 <_stogir.stack.constant-size-aligned+0x204>
    cfdc:      	b	0xd174 <_stogir.stack.constant-size-aligned+0x380>
    cfe0:      	adrp	x16, 0xc000 <_stogir.vector-arithmetic.operands+0x54>
		000000000000cfe0:  ARM64_RELOC_PAGE21	l_stogir.505
    cfe4:      	ldr	x16, [x16]
		000000000000cfe4:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    cfe8:      	orr	x0, x16, xzr
    cfec:      	mov	x1, #0x1                ; =1
    cff0:      	mov	x2, #0x18               ; =24
    cff4:      	b	0xcf0c <_stogir.stack.constant-size-aligned+0x118>
    cff8:      	lsr	w4, w3, #0
    cffc:      	mov	x16, sp
    d000:      	str	x3, [x16]
    d004:      	mov	x16, sp
    d008:      	str	x0, [x16, #0x8]
    d00c:      	ubfx	x0, x4, #8, #8
    d010:      	cmp	x0, #0x0
    d014:      	b.ne	0xd030 <_stogir.stack.constant-size-aligned+0x23c>
    d018:      	movz	x3, #0x0, lsl #48
    d01c:      	b	0xcea4 <_stogir.stack.constant-size-aligned+0xb0>
    d020:      	movz	x4, #0x0, lsl #48
    d024:      	b	0xcf64 <_stogir.stack.constant-size-aligned+0x170>
    d028:      	movz	x4, #0x0, lsl #48
    d02c:      	b	0xcf5c <_stogir.stack.constant-size-aligned+0x168>
    d030:      	cmp	x0, #0x1
    d034:      	b.eq	0xcea0 <_stogir.stack.constant-size-aligned+0xac>
    d038:      	cmp	x0, #0x2
    d03c:      	b.eq	0xcea0 <_stogir.stack.constant-size-aligned+0xac>
    d040:      	cmp	x0, #0x7
    d044:      	b.eq	0xcea0 <_stogir.stack.constant-size-aligned+0xac>
    d048:      	cmp	x0, #0x8
    d04c:      	b.eq	0xcea0 <_stogir.stack.constant-size-aligned+0xac>
    d050:      	cmp	x0, #0x3
    d054:      	b.eq	0xd16c <_stogir.stack.constant-size-aligned+0x378>
    d058:      	cmp	x0, #0x9
    d05c:      	b.eq	0xd16c <_stogir.stack.constant-size-aligned+0x378>
    d060:      	cmp	x0, #0x4
    d064:      	b.eq	0xd17c <_stogir.stack.constant-size-aligned+0x388>
    d068:      	cmp	x0, #0xa
    d06c:      	b.eq	0xd17c <_stogir.stack.constant-size-aligned+0x388>
    d070:      	cmp	x0, #0xd
    d074:      	b.eq	0xd17c <_stogir.stack.constant-size-aligned+0x388>
    d078:      	cmp	x0, #0x5
    d07c:      	b.eq	0xd184 <_stogir.stack.constant-size-aligned+0x390>
    d080:      	cmp	x0, #0xb
    d084:      	b.eq	0xd184 <_stogir.stack.constant-size-aligned+0x390>
    d088:      	cmp	x0, #0xc
    d08c:      	b.eq	0xd184 <_stogir.stack.constant-size-aligned+0x390>
    d090:      	cmp	x0, #0x6
    d094:      	cset	w3, eq
    d098:      	uxtb	w16, w3
    d09c:      	cmp	w16, wzr
    d0a0:      	mov	x16, #0x8               ; =8
    d0a4:      	movn	x17, #0x0, lsl #48
    d0a8:      	csel	x3, x16, x17, ne
    d0ac:      	b	0xd188 <_stogir.stack.constant-size-aligned+0x394>
    d0b0:      	movz	x4, #0x0, lsl #48
    d0b4:      	b	0xd024 <_stogir.stack.constant-size-aligned+0x230>
    d0b8:      	lsr	w3, w3, #0
    d0bc:      	sxtw	x3, w3
    d0c0:      	cmp	x3, #0x0
    d0c4:      	b.le	0xcef8 <_stogir.stack.constant-size-aligned+0x104>
    d0c8:      	ubfx	x4, x4, #0, #32
    d0cc:      	ubfx	x5, x5, #0, #32
    d0d0:      	lsl	x5, x5, #32
    d0d4:      	orr	x4, x5, x4
    d0d8:      	cmp	x3, #0x8
    d0dc:      	b.ge	0xd0f8 <_stogir.stack.constant-size-aligned+0x304>
    d0e0:      	lsl	x5, x3, #3
    d0e4:      	lsr	w5, w5, #0
    d0e8:      	sxtw	x5, w5
    d0ec:      	lsr	x5, x4, x5
    d0f0:      	cmp	x5, #0x0
    d0f4:      	b.ne	0xcef8 <_stogir.stack.constant-size-aligned+0x104>
    d0f8:      	cmp	x0, #0x7
    d0fc:      	b.lt	0xd138 <_stogir.stack.constant-size-aligned+0x344>
    d100:      	uxtb	w16, w1
    d104:      	cmp	w16, wzr
    d108:      	b.eq	0xd138 <_stogir.stack.constant-size-aligned+0x344>
    d10c:      	lsl	x0, x3, #3
    d110:      	lsr	w0, w0, #0
    d114:      	sxtw	x0, w0
    d118:      	sub	x0, x0, #0x1
    d11c:      	lsr	w0, w0, #0
    d120:      	sxtw	x0, w0
    d124:      	mov	x16, #0x1               ; =1
    d128:      	lsl	x0, x16, x0
    d12c:      	and	x0, x0, x4
    d130:      	cmp	x0, #0x0
    d134:      	b.ne	0xcef8 <_stogir.stack.constant-size-aligned+0x104>
    d138:      	sub	x0, x2, #0x1
    d13c:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    d140:      	sub	x0, x16, x0
    d144:      	cmp	x4, x0
    d148:      	b.hi	0xcef8 <_stogir.stack.constant-size-aligned+0x104>
    d14c:      	sub	x0, x2, #0x1
    d150:      	movz	x16, #0x0, lsl #48
    d154:      	sub	x1, x16, x2
    d158:      	add	x0, x0, x4
    d15c:      	and	x0, x1, x0
    d160:      	movz	x1, #0x0, lsl #48
    d164:      	movz	x2, #0x0, lsl #48
    d168:      	b	0xcf0c <_stogir.stack.constant-size-aligned+0x118>
    d16c:      	mov	x3, #0x2                ; =2
    d170:      	b	0xcea4 <_stogir.stack.constant-size-aligned+0xb0>
    d174:      	brk	#0
    d178:      	b	0xd174 <_stogir.stack.constant-size-aligned+0x380>
    d17c:      	mov	x3, #0x4                ; =4
    d180:      	b	0xd170 <_stogir.stack.constant-size-aligned+0x37c>
    d184:      	mov	x3, #0x8                ; =8
    d188:      	b	0xd180 <_stogir.stack.constant-size-aligned+0x38c>

000000000000d18c <_stogir.vector-lanes.compatible?>:
    d18c:      	sxtw	x0, w0
    d190:      	and	x3, x0, #0xf
    d194:      	cmp	x0, #0xf
    d198:      	cset	w4, gt
    d19c:      	cmp	x0, #0x80
    d1a0:      	cset	w5, lt
    d1a4:      	lsr	w3, w3, #0
    d1a8:      	sxtw	x3, w3
    d1ac:      	cmp	x3, #0x1
    d1b0:      	cset	w6, ge
    d1b4:      	cmp	x3, #0xd
    d1b8:      	cset	w7, le
    d1bc:      	cmp	x0, #0x0
    d1c0:      	b.lt	0xd1cc <_stogir.vector-lanes.compatible?+0x40>
    d1c4:      	cmp	x0, #0xd
    d1c8:      	b.le	0xd200 <_stogir.vector-lanes.compatible?+0x74>
    d1cc:      	uxtb	w16, w4
    d1d0:      	cmp	w16, wzr
    d1d4:      	b.eq	0xd1fc <_stogir.vector-lanes.compatible?+0x70>
    d1d8:      	uxtb	w16, w5
    d1dc:      	cmp	w16, wzr
    d1e0:      	b.eq	0xd1fc <_stogir.vector-lanes.compatible?+0x70>
    d1e4:      	uxtb	w16, w6
    d1e8:      	cmp	w16, wzr
    d1ec:      	b.eq	0xd1fc <_stogir.vector-lanes.compatible?+0x70>
    d1f0:      	uxtb	w16, w7
    d1f4:      	cmp	w16, wzr
    d1f8:      	b.ne	0xd200 <_stogir.vector-lanes.compatible?+0x74>
    d1fc:      	movn	x3, #0x0, lsl #48
    d200:      	uxtb	w16, w4
    d204:      	cmp	w16, wzr
    d208:      	b.eq	0xd264 <_stogir.vector-lanes.compatible?+0xd8>
    d20c:      	uxtb	w16, w5
    d210:      	cmp	w16, wzr
    d214:      	b.eq	0xd264 <_stogir.vector-lanes.compatible?+0xd8>
    d218:      	uxtb	w16, w6
    d21c:      	cmp	w16, wzr
    d220:      	b.eq	0xd264 <_stogir.vector-lanes.compatible?+0xd8>
    d224:      	uxtb	w16, w7
    d228:      	cmp	w16, wzr
    d22c:      	b.eq	0xd264 <_stogir.vector-lanes.compatible?+0xd8>
    d230:      	sxtw	x2, w2
    d234:      	cmp	x2, #0x4
    d238:      	cset	w0, eq
    d23c:      	cmp	x2, #0x8
    d240:      	cset	w4, eq
    d244:      	uxtb	w16, w0
    d248:      	cmp	w16, wzr
    d24c:      	b.ne	0xd274 <_stogir.vector-lanes.compatible?+0xe8>
    d250:      	uxtb	w16, w4
    d254:      	cmp	w16, wzr
    d258:      	b.ne	0xd274 <_stogir.vector-lanes.compatible?+0xe8>
    d25c:      	movz	x0, #0x0, lsl #48
    d260:      	b	0xd270 <_stogir.vector-lanes.compatible?+0xe4>
    d264:      	movz	x0, #0x0, lsl #48
    d268:      	ret
    d26c:      	movz	x0, #0x0, lsl #48
    d270:      	b	0xd268 <_stogir.vector-lanes.compatible?+0xdc>
    d274:      	sxtw	x1, w1
    d278:      	cmp	x1, #0x0
    d27c:      	b.lt	0xd26c <_stogir.vector-lanes.compatible?+0xe0>
    d280:      	cmp	x1, #0xd
    d284:      	b.gt	0xd26c <_stogir.vector-lanes.compatible?+0xe0>
    d288:      	cmp	x1, #0x0
    d28c:      	b.le	0xd2a8 <_stogir.vector-lanes.compatible?+0x11c>
    d290:      	lsr	w3, w3, #0
    d294:      	sxtw	x3, w3
    d298:      	cmp	x3, x1
    d29c:      	b.ne	0xd2b0 <_stogir.vector-lanes.compatible?+0x124>
    d2a0:      	mov	x0, #0x1                ; =1
    d2a4:      	b	0xd2ac <_stogir.vector-lanes.compatible?+0x120>
    d2a8:      	movz	x0, #0x0, lsl #48
    d2ac:      	b	0xd270 <_stogir.vector-lanes.compatible?+0xe4>
    d2b0:      	cmp	x3, #0x1
    d2b4:      	b.lt	0xd2f0 <_stogir.vector-lanes.compatible?+0x164>
    d2b8:      	cmp	x3, #0xb
    d2bc:      	b.gt	0xd2f0 <_stogir.vector-lanes.compatible?+0x164>
    d2c0:      	cmp	x1, #0x1
    d2c4:      	b.lt	0xd2f8 <_stogir.vector-lanes.compatible?+0x16c>
    d2c8:      	cmp	x1, #0xb
    d2cc:      	b.gt	0xd2f8 <_stogir.vector-lanes.compatible?+0x16c>
    d2d0:      	uxtb	w16, w0
    d2d4:      	cmp	w16, wzr
    d2d8:      	b.ne	0xd324 <_stogir.vector-lanes.compatible?+0x198>
    d2dc:      	uxtb	w16, w4
    d2e0:      	cmp	w16, wzr
    d2e4:      	b.ne	0xd324 <_stogir.vector-lanes.compatible?+0x198>
    d2e8:      	movn	x3, #0x0, lsl #48
    d2ec:      	b	0xd338 <_stogir.vector-lanes.compatible?+0x1ac>
    d2f0:      	movz	x0, #0x0, lsl #48
    d2f4:      	b	0xd2a4 <_stogir.vector-lanes.compatible?+0x118>
    d2f8:      	movz	x0, #0x0, lsl #48
    d2fc:      	b	0xd2f4 <_stogir.vector-lanes.compatible?+0x168>
    d300:      	mov	x2, #0x1                ; =1
    d304:      	lsr	w3, w3, #0
    d308:      	sxtw	x3, w3
    d30c:      	lsr	w2, w2, #0
    d310:      	sxtw	x2, w2
    d314:      	cmp	x3, x2
    d318:      	cset	w0, eq
    d31c:      	ubfx	x0, x0, #0, #8
    d320:      	b	0xd2fc <_stogir.vector-lanes.compatible?+0x170>
    d324:      	cmp	x3, #0x0
    d328:      	b.ne	0xd3d8 <_stogir.vector-lanes.compatible?+0x24c>
    d32c:      	movz	x3, #0x0, lsl #48
    d330:      	b	0xd338 <_stogir.vector-lanes.compatible?+0x1ac>
    d334:      	mov	x3, #0x1                ; =1
    d338:      	uxtb	w16, w0
    d33c:      	cmp	w16, wzr
    d340:      	b.ne	0xd358 <_stogir.vector-lanes.compatible?+0x1cc>
    d344:      	uxtb	w16, w4
    d348:      	cmp	w16, wzr
    d34c:      	b.ne	0xd358 <_stogir.vector-lanes.compatible?+0x1cc>
    d350:      	movn	x2, #0x0, lsl #48
    d354:      	b	0xd304 <_stogir.vector-lanes.compatible?+0x178>
    d358:      	cmp	x1, #0x0
    d35c:      	b.ne	0xd368 <_stogir.vector-lanes.compatible?+0x1dc>
    d360:      	movz	x2, #0x0, lsl #48
    d364:      	b	0xd304 <_stogir.vector-lanes.compatible?+0x178>
    d368:      	cmp	x1, #0x1
    d36c:      	b.eq	0xd300 <_stogir.vector-lanes.compatible?+0x174>
    d370:      	cmp	x1, #0x2
    d374:      	b.eq	0xd300 <_stogir.vector-lanes.compatible?+0x174>
    d378:      	cmp	x1, #0x7
    d37c:      	b.eq	0xd300 <_stogir.vector-lanes.compatible?+0x174>
    d380:      	cmp	x1, #0x8
    d384:      	b.eq	0xd300 <_stogir.vector-lanes.compatible?+0x174>
    d388:      	cmp	x1, #0x3
    d38c:      	b.eq	0xd448 <_stogir.vector-lanes.compatible?+0x2bc>
    d390:      	cmp	x1, #0x9
    d394:      	b.eq	0xd448 <_stogir.vector-lanes.compatible?+0x2bc>
    d398:      	cmp	x1, #0x4
    d39c:      	b.eq	0xd458 <_stogir.vector-lanes.compatible?+0x2cc>
    d3a0:      	cmp	x1, #0xa
    d3a4:      	b.eq	0xd458 <_stogir.vector-lanes.compatible?+0x2cc>
    d3a8:      	cmp	x1, #0xd
    d3ac:      	b.eq	0xd458 <_stogir.vector-lanes.compatible?+0x2cc>
    d3b0:      	cmp	x1, #0x5
    d3b4:      	b.eq	0xd468 <_stogir.vector-lanes.compatible?+0x2dc>
    d3b8:      	cmp	x1, #0xb
    d3bc:      	b.eq	0xd468 <_stogir.vector-lanes.compatible?+0x2dc>
    d3c0:      	cmp	x1, #0xc
    d3c4:      	b.eq	0xd468 <_stogir.vector-lanes.compatible?+0x2dc>
    d3c8:      	cmp	x1, #0x6
    d3cc:      	b.eq	0xd3d4 <_stogir.vector-lanes.compatible?+0x248>
    d3d0:      	movn	x2, #0x0, lsl #48
    d3d4:      	b	0xd46c <_stogir.vector-lanes.compatible?+0x2e0>
    d3d8:      	cmp	x3, #0x1
    d3dc:      	b.eq	0xd334 <_stogir.vector-lanes.compatible?+0x1a8>
    d3e0:      	cmp	x3, #0x2
    d3e4:      	b.eq	0xd334 <_stogir.vector-lanes.compatible?+0x1a8>
    d3e8:      	cmp	x3, #0x7
    d3ec:      	b.eq	0xd334 <_stogir.vector-lanes.compatible?+0x1a8>
    d3f0:      	cmp	x3, #0x8
    d3f4:      	b.eq	0xd334 <_stogir.vector-lanes.compatible?+0x1a8>
    d3f8:      	cmp	x3, #0x3
    d3fc:      	b.eq	0xd450 <_stogir.vector-lanes.compatible?+0x2c4>
    d400:      	cmp	x3, #0x9
    d404:      	b.eq	0xd450 <_stogir.vector-lanes.compatible?+0x2c4>
    d408:      	cmp	x3, #0x4
    d40c:      	b.eq	0xd460 <_stogir.vector-lanes.compatible?+0x2d4>
    d410:      	cmp	x3, #0xa
    d414:      	b.eq	0xd460 <_stogir.vector-lanes.compatible?+0x2d4>
    d418:      	cmp	x3, #0xd
    d41c:      	b.eq	0xd460 <_stogir.vector-lanes.compatible?+0x2d4>
    d420:      	cmp	x3, #0x5
    d424:      	b.eq	0xd470 <_stogir.vector-lanes.compatible?+0x2e4>
    d428:      	cmp	x3, #0xb
    d42c:      	b.eq	0xd470 <_stogir.vector-lanes.compatible?+0x2e4>
    d430:      	cmp	x3, #0xc
    d434:      	b.eq	0xd470 <_stogir.vector-lanes.compatible?+0x2e4>
    d438:      	cmp	x3, #0x6
    d43c:      	b.ne	0xd478 <_stogir.vector-lanes.compatible?+0x2ec>
    d440:      	mov	x3, x2
    d444:      	b	0xd47c <_stogir.vector-lanes.compatible?+0x2f0>
    d448:      	mov	x2, #0x2                ; =2
    d44c:      	b	0xd304 <_stogir.vector-lanes.compatible?+0x178>
    d450:      	mov	x3, #0x2                ; =2
    d454:      	b	0xd338 <_stogir.vector-lanes.compatible?+0x1ac>
    d458:      	mov	x2, #0x4                ; =4
    d45c:      	b	0xd44c <_stogir.vector-lanes.compatible?+0x2c0>
    d460:      	mov	x3, #0x4                ; =4
    d464:      	b	0xd454 <_stogir.vector-lanes.compatible?+0x2c8>
    d468:      	mov	x2, #0x8                ; =8
    d46c:      	b	0xd45c <_stogir.vector-lanes.compatible?+0x2d0>
    d470:      	mov	x3, #0x8                ; =8
    d474:      	b	0xd464 <_stogir.vector-lanes.compatible?+0x2d8>
    d478:      	movn	x3, #0x0, lsl #48
    d47c:      	b	0xd474 <_stogir.vector-lanes.compatible?+0x2e8>

000000000000d480 <_stogir.vector-comparison.valid-type?>:
    d480:      	sxtw	x0, w0
    d484:      	cmp	x0, #0xe
    d488:      	b.lt	0xd524 <_stogir.vector-comparison.valid-type?+0xa4>
    d48c:      	cmp	x0, #0x19
    d490:      	b.gt	0xd524 <_stogir.vector-comparison.valid-type?+0xa4>
    d494:      	sxtw	x1, w1
    d498:      	cmp	x1, #0xf
    d49c:      	cset	w2, gt
    d4a0:      	uxtb	w16, w2
    d4a4:      	cmp	w16, wzr
    d4a8:      	b.eq	0xd52c <_stogir.vector-comparison.valid-type?+0xac>
    d4ac:      	cmp	x1, #0x80
    d4b0:      	cset	w3, lt
    d4b4:      	uxtb	w16, w3
    d4b8:      	cmp	w16, wzr
    d4bc:      	b.eq	0xd52c <_stogir.vector-comparison.valid-type?+0xac>
    d4c0:      	and	x4, x1, #0xf
    d4c4:      	lsr	w4, w4, #0
    d4c8:      	sxtw	x4, w4
    d4cc:      	cmp	x4, #0x1
    d4d0:      	cset	w5, ge
    d4d4:      	uxtb	w16, w5
    d4d8:      	cmp	w16, wzr
    d4dc:      	b.eq	0xd52c <_stogir.vector-comparison.valid-type?+0xac>
    d4e0:      	cmp	x4, #0xd
    d4e4:      	cset	w6, le
    d4e8:      	uxtb	w16, w6
    d4ec:      	cmp	w16, wzr
    d4f0:      	b.eq	0xd52c <_stogir.vector-comparison.valid-type?+0xac>
    d4f4:      	cmp	x1, #0x0
    d4f8:      	cset	w7, ge
    d4fc:      	cmp	x1, #0xd
    d500:      	cset	w1, le
    d504:      	uxtb	w16, w7
    d508:      	cmp	w16, wzr
    d50c:      	b.eq	0xd53c <_stogir.vector-comparison.valid-type?+0xbc>
    d510:      	uxtb	w16, w1
    d514:      	cmp	w16, wzr
    d518:      	b.eq	0xd53c <_stogir.vector-comparison.valid-type?+0xbc>
    d51c:      	mov	x8, x4
    d520:      	b	0xd570 <_stogir.vector-comparison.valid-type?+0xf0>
    d524:      	movz	x0, #0x0, lsl #48
    d528:      	ret
    d52c:      	movz	x0, #0x0, lsl #48
    d530:      	b	0xd528 <_stogir.vector-comparison.valid-type?+0xa8>
    d534:      	mov	x0, #0x1                ; =1
    d538:      	b	0xd530 <_stogir.vector-comparison.valid-type?+0xb0>
    d53c:      	uxtb	w16, w2
    d540:      	cmp	w16, wzr
    d544:      	b.eq	0xd56c <_stogir.vector-comparison.valid-type?+0xec>
    d548:      	uxtb	w16, w3
    d54c:      	cmp	w16, wzr
    d550:      	b.eq	0xd56c <_stogir.vector-comparison.valid-type?+0xec>
    d554:      	uxtb	w16, w5
    d558:      	cmp	w16, wzr
    d55c:      	b.eq	0xd56c <_stogir.vector-comparison.valid-type?+0xec>
    d560:      	uxtb	w16, w6
    d564:      	cmp	w16, wzr
    d568:      	b.ne	0xd51c <_stogir.vector-comparison.valid-type?+0x9c>
    d56c:      	movn	x8, #0x0, lsl #48
    d570:      	lsr	w8, w8, #0
    d574:      	sxtw	x8, w8
    d578:      	cmp	x8, #0xc
    d57c:      	b.eq	0xd534 <_stogir.vector-comparison.valid-type?+0xb4>
    d580:      	cmp	x8, #0xd
    d584:      	b.eq	0xd534 <_stogir.vector-comparison.valid-type?+0xb4>
    d588:      	uxtb	w16, w7
    d58c:      	cmp	w16, wzr
    d590:      	b.eq	0xd5a0 <_stogir.vector-comparison.valid-type?+0x120>
    d594:      	uxtb	w16, w1
    d598:      	cmp	w16, wzr
    d59c:      	b.ne	0xd5d4 <_stogir.vector-comparison.valid-type?+0x154>
    d5a0:      	uxtb	w16, w2
    d5a4:      	cmp	w16, wzr
    d5a8:      	b.eq	0xd5d0 <_stogir.vector-comparison.valid-type?+0x150>
    d5ac:      	uxtb	w16, w3
    d5b0:      	cmp	w16, wzr
    d5b4:      	b.eq	0xd5d0 <_stogir.vector-comparison.valid-type?+0x150>
    d5b8:      	uxtb	w16, w5
    d5bc:      	cmp	w16, wzr
    d5c0:      	b.eq	0xd5d0 <_stogir.vector-comparison.valid-type?+0x150>
    d5c4:      	uxtb	w16, w6
    d5c8:      	cmp	w16, wzr
    d5cc:      	b.ne	0xd5d4 <_stogir.vector-comparison.valid-type?+0x154>
    d5d0:      	movn	x4, #0x0, lsl #48
    d5d4:      	lsr	w4, w4, #0
    d5d8:      	sxtw	x4, w4
    d5dc:      	cmp	x4, #0x1
    d5e0:      	b.lt	0xd5fc <_stogir.vector-comparison.valid-type?+0x17c>
    d5e4:      	cmp	x4, #0xb
    d5e8:      	b.gt	0xd5fc <_stogir.vector-comparison.valid-type?+0x17c>
    d5ec:      	cmp	x0, #0x17
    d5f0:      	cset	w0, le
    d5f4:      	ubfx	x0, x0, #0, #8
    d5f8:      	b	0xd600 <_stogir.vector-comparison.valid-type?+0x180>
    d5fc:      	movz	x0, #0x0, lsl #48
    d600:      	b	0xd538 <_stogir.vector-comparison.valid-type?+0xb8>

000000000000d604 <_stogir.vector-arithmetic.valid-type?>:
    d604:      	sub	sp, sp, #0x30
    d608:      	str	x29, [sp]
    d60c:      	str	x30, [sp, #0x8]
    d610:      	mov	x29, sp
    d614:      	str	x19, [sp, #0x10]
    d618:      	str	x20, [sp, #0x18]
    d61c:      	str	x21, [sp, #0x20]
    d620:      	str	x22, [sp, #0x28]
    d624:      	sxtw	x1, w1
    d628:      	cmp	x1, #0xf
    d62c:      	cset	w2, gt
    d630:      	cmp	x1, #0x80
    d634:      	cset	w3, lt
    d638:      	and	x4, x1, #0xf
    d63c:      	lsr	w4, w4, #0
    d640:      	sxtw	x4, w4
    d644:      	cmp	x4, #0x1
    d648:      	cset	w5, ge
    d64c:      	cmp	x4, #0xd
    d650:      	cset	w6, le
    d654:      	cmp	x1, #0x0
    d658:      	b.lt	0xd664 <_stogir.vector-arithmetic.valid-type?+0x60>
    d65c:      	cmp	x1, #0xd
    d660:      	b.le	0xd698 <_stogir.vector-arithmetic.valid-type?+0x94>
    d664:      	uxtb	w16, w2
    d668:      	cmp	w16, wzr
    d66c:      	b.eq	0xd694 <_stogir.vector-arithmetic.valid-type?+0x90>
    d670:      	uxtb	w16, w3
    d674:      	cmp	w16, wzr
    d678:      	b.eq	0xd694 <_stogir.vector-arithmetic.valid-type?+0x90>
    d67c:      	uxtb	w16, w5
    d680:      	cmp	w16, wzr
    d684:      	b.eq	0xd694 <_stogir.vector-arithmetic.valid-type?+0x90>
    d688:      	uxtb	w16, w6
    d68c:      	cmp	w16, wzr
    d690:      	b.ne	0xd698 <_stogir.vector-arithmetic.valid-type?+0x94>
    d694:      	movn	x4, #0x0, lsl #48
    d698:      	uxtb	w16, w2
    d69c:      	cmp	w16, wzr
    d6a0:      	b.eq	0xd88c <_stogir.vector-arithmetic.valid-type?+0x288>
    d6a4:      	uxtb	w16, w3
    d6a8:      	cmp	w16, wzr
    d6ac:      	b.eq	0xd88c <_stogir.vector-arithmetic.valid-type?+0x288>
    d6b0:      	uxtb	w16, w5
    d6b4:      	cmp	w16, wzr
    d6b8:      	b.eq	0xd88c <_stogir.vector-arithmetic.valid-type?+0x288>
    d6bc:      	uxtb	w16, w6
    d6c0:      	cmp	w16, wzr
    d6c4:      	b.eq	0xd88c <_stogir.vector-arithmetic.valid-type?+0x288>
    d6c8:      	sxtw	x1, w0
    d6cc:      	cmp	x1, #0x1f
    d6d0:      	cset	w19, eq
    d6d4:      	cmp	x1, #0x20
    d6d8:      	cset	w20, eq
    d6dc:      	cmp	x1, #0x2e
    d6e0:      	cset	w2, eq
    d6e4:      	cmp	x1, #0x2f
    d6e8:      	cset	w3, eq
    d6ec:      	cmp	x1, #0x30
    d6f0:      	cset	w5, eq
    d6f4:      	cmp	x1, #0x1e
    d6f8:      	cset	w6, eq
    d6fc:      	cmp	x1, #0x31
    d700:      	cset	w7, ge
    d704:      	cmp	x1, #0x35
    d708:      	cset	w8, le
    d70c:      	cmp	x1, #0x3a
    d710:      	cset	w9, eq
    d714:      	cmp	x1, #0x3b
    d718:      	cset	w10, eq
    d71c:      	cmp	x1, #0x2d
    d720:      	cset	w11, eq
    d724:      	cmp	x1, #0x36
    d728:      	cset	w12, eq
    d72c:      	cmp	x1, #0x37
    d730:      	cset	w13, eq
    d734:      	cmp	x1, #0x38
    d738:      	cset	w14, eq
    d73c:      	cmp	x1, #0x39
    d740:      	cset	w15, eq
    d744:      	uxtb	w16, w19
    d748:      	cmp	w16, wzr
    d74c:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d750:      	uxtb	w16, w20
    d754:      	cmp	w16, wzr
    d758:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d75c:      	uxtb	w16, w11
    d760:      	cmp	w16, wzr
    d764:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d768:      	uxtb	w16, w12
    d76c:      	cmp	w16, wzr
    d770:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d774:      	uxtb	w16, w13
    d778:      	cmp	w16, wzr
    d77c:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d780:      	uxtb	w16, w14
    d784:      	cmp	w16, wzr
    d788:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d78c:      	uxtb	w16, w15
    d790:      	cmp	w16, wzr
    d794:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d798:      	uxtb	w16, w9
    d79c:      	cmp	w16, wzr
    d7a0:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d7a4:      	uxtb	w16, w10
    d7a8:      	cmp	w16, wzr
    d7ac:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d7b0:      	uxtb	w16, w7
    d7b4:      	cmp	w16, wzr
    d7b8:      	b.eq	0xd9a4 <_stogir.vector-arithmetic.valid-type?+0x3a0>
    d7bc:      	uxtb	w16, w8
    d7c0:      	cmp	w16, wzr
    d7c4:      	b.eq	0xd9a4 <_stogir.vector-arithmetic.valid-type?+0x3a0>
    d7c8:      	lsr	w4, w4, #0
    d7cc:      	sxtw	x1, w4
    d7d0:      	cmp	x1, #0xc
    d7d4:      	cset	w21, eq
    d7d8:      	cmp	x1, #0xd
    d7dc:      	cset	w22, eq
    d7e0:      	uxtb	w16, w19
    d7e4:      	cmp	w16, wzr
    d7e8:      	b.ne	0xd8b8 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d7ec:      	uxtb	w16, w20
    d7f0:      	cmp	w16, wzr
    d7f4:      	b.ne	0xd8b8 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d7f8:      	uxtb	w16, w11
    d7fc:      	cmp	w16, wzr
    d800:      	b.ne	0xd8b8 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d804:      	uxtb	w16, w12
    d808:      	cmp	w16, wzr
    d80c:      	b.ne	0xd8b8 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d810:      	uxtb	w16, w13
    d814:      	cmp	w16, wzr
    d818:      	b.ne	0xd8b8 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d81c:      	uxtb	w16, w14
    d820:      	cmp	w16, wzr
    d824:      	b.ne	0xd8b8 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d828:      	uxtb	w16, w15
    d82c:      	cmp	w16, wzr
    d830:      	b.ne	0xd8b8 <_stogir.vector-arithmetic.valid-type?+0x2b4>
    d834:      	cmp	x1, #0x1
    d838:      	cset	w0, eq
    d83c:      	cmp	x1, #0x1
    d840:      	cset	w4, ge
    d844:      	cmp	x1, #0xb
    d848:      	cset	w1, le
    d84c:      	uxtb	w16, w7
    d850:      	cmp	w16, wzr
    d854:      	b.eq	0xd914 <_stogir.vector-arithmetic.valid-type?+0x310>
    d858:      	uxtb	w16, w8
    d85c:      	cmp	w16, wzr
    d860:      	b.eq	0xd914 <_stogir.vector-arithmetic.valid-type?+0x310>
    d864:      	uxtb	w16, w4
    d868:      	cmp	w16, wzr
    d86c:      	b.eq	0xd99c <_stogir.vector-arithmetic.valid-type?+0x398>
    d870:      	uxtb	w16, w1
    d874:      	cmp	w16, wzr
    d878:      	b.eq	0xd99c <_stogir.vector-arithmetic.valid-type?+0x398>
    d87c:      	uxtb	w16, w0
    d880:      	cmp	w16, wzr
    d884:      	cset	x0, eq
    d888:      	b	0xd9a0 <_stogir.vector-arithmetic.valid-type?+0x39c>
    d88c:      	movz	x0, #0x0, lsl #48
    d890:      	ldr	x19, [sp, #0x10]
    d894:      	ldr	x20, [sp, #0x18]
    d898:      	ldr	x21, [sp, #0x20]
    d89c:      	ldr	x22, [sp, #0x28]
    d8a0:      	ldr	x29, [sp]
    d8a4:      	ldr	x30, [sp, #0x8]
    d8a8:      	add	sp, sp, #0x30
    d8ac:      	ret
    d8b0:      	ubfx	x0, x20, #0, #8
    d8b4:      	b	0xd890 <_stogir.vector-arithmetic.valid-type?+0x28c>
    d8b8:      	lsr	w0, w0, #0
    d8bc:      	lsr	w4, w4, #0
    d8c0:      	mov	w1, w4
    d8c4:      	bl	0xd8c4 <_stogir.vector-arithmetic.valid-type?+0x2c0>
		000000000000d8c4:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    d8c8:      	cmp	x0, #0x0
    d8cc:      	b.eq	0xd8d8 <_stogir.vector-arithmetic.valid-type?+0x2d4>
    d8d0:      	mov	x0, #0x1                ; =1
    d8d4:      	b	0xd8b4 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d8d8:      	uxtb	w16, w21
    d8dc:      	cmp	w16, wzr
    d8e0:      	b.ne	0xd8f8 <_stogir.vector-arithmetic.valid-type?+0x2f4>
    d8e4:      	uxtb	w16, w22
    d8e8:      	cmp	w16, wzr
    d8ec:      	b.ne	0xd8f8 <_stogir.vector-arithmetic.valid-type?+0x2f4>
    d8f0:      	movz	x0, #0x0, lsl #48
    d8f4:      	b	0xd8b4 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d8f8:      	uxtb	w16, w19
    d8fc:      	cmp	w16, wzr
    d900:      	b.eq	0xd8b0 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    d904:      	mov	x0, #0x1                ; =1
    d908:      	b	0xd8b4 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d90c:      	movz	x0, #0x0, lsl #48
    d910:      	b	0xd8b4 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d914:      	uxtb	w16, w2
    d918:      	cmp	w16, wzr
    d91c:      	b.ne	0xd988 <_stogir.vector-arithmetic.valid-type?+0x384>
    d920:      	uxtb	w16, w3
    d924:      	cmp	w16, wzr
    d928:      	b.ne	0xd988 <_stogir.vector-arithmetic.valid-type?+0x384>
    d92c:      	uxtb	w16, w5
    d930:      	cmp	w16, wzr
    d934:      	b.ne	0xd988 <_stogir.vector-arithmetic.valid-type?+0x384>
    d938:      	uxtb	w16, w21
    d93c:      	cmp	w16, wzr
    d940:      	b.ne	0xd9fc <_stogir.vector-arithmetic.valid-type?+0x3f8>
    d944:      	uxtb	w16, w22
    d948:      	cmp	w16, wzr
    d94c:      	b.ne	0xd9fc <_stogir.vector-arithmetic.valid-type?+0x3f8>
    d950:      	uxtb	w16, w4
    d954:      	cmp	w16, wzr
    d958:      	b.eq	0xda0c <_stogir.vector-arithmetic.valid-type?+0x408>
    d95c:      	uxtb	w16, w1
    d960:      	cmp	w16, wzr
    d964:      	b.eq	0xda0c <_stogir.vector-arithmetic.valid-type?+0x408>
    d968:      	uxtb	w16, w0
    d96c:      	cmp	w16, wzr
    d970:      	b.eq	0xda14 <_stogir.vector-arithmetic.valid-type?+0x410>
    d974:      	uxtb	w16, w9
    d978:      	cmp	w16, wzr
    d97c:      	b.eq	0xda1c <_stogir.vector-arithmetic.valid-type?+0x418>
    d980:      	mov	x0, #0x1                ; =1
    d984:      	b	0xda20 <_stogir.vector-arithmetic.valid-type?+0x41c>
    d988:      	uxtb	w16, w4
    d98c:      	cmp	w16, wzr
    d990:      	b.eq	0xd90c <_stogir.vector-arithmetic.valid-type?+0x308>
    d994:      	ubfx	x0, x1, #0, #8
    d998:      	b	0xd910 <_stogir.vector-arithmetic.valid-type?+0x30c>
    d99c:      	movz	x0, #0x0, lsl #48
    d9a0:      	b	0xd910 <_stogir.vector-arithmetic.valid-type?+0x30c>
    d9a4:      	cmp	x1, #0x1a
    d9a8:      	b.eq	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d9ac:      	cmp	x1, #0x1b
    d9b0:      	b.eq	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d9b4:      	cmp	x1, #0x1c
    d9b8:      	b.eq	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d9bc:      	cmp	x1, #0x1d
    d9c0:      	b.eq	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d9c4:      	uxtb	w16, w6
    d9c8:      	cmp	w16, wzr
    d9cc:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d9d0:      	uxtb	w16, w2
    d9d4:      	cmp	w16, wzr
    d9d8:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d9dc:      	uxtb	w16, w3
    d9e0:      	cmp	w16, wzr
    d9e4:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d9e8:      	uxtb	w16, w5
    d9ec:      	cmp	w16, wzr
    d9f0:      	b.ne	0xd7c8 <_stogir.vector-arithmetic.valid-type?+0x1c4>
    d9f4:      	movz	x0, #0x0, lsl #48
    d9f8:      	b	0xd8b4 <_stogir.vector-arithmetic.valid-type?+0x2b0>
    d9fc:      	uxtb	w16, w6
    da00:      	cmp	w16, wzr
    da04:      	cset	x0, eq
    da08:      	b	0xd910 <_stogir.vector-arithmetic.valid-type?+0x30c>
    da0c:      	movz	x0, #0x0, lsl #48
    da10:      	b	0xda08 <_stogir.vector-arithmetic.valid-type?+0x404>
    da14:      	mov	x0, #0x1                ; =1
    da18:      	b	0xda10 <_stogir.vector-arithmetic.valid-type?+0x40c>
    da1c:      	ubfx	x0, x10, #0, #8
    da20:      	b	0xda18 <_stogir.vector-arithmetic.valid-type?+0x414>
