
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-loop-active-splits/build/frontend-providers/stogir-after.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000000aed8 <_coil.compiler.resolve.primitive-providers-in>:
    aed8: d10483ff     	sub	sp, sp, #0x120
    aedc: f90003fd     	str	x29, [sp]
    aee0: f90007fe     	str	x30, [sp, #0x8]
    aee4: 910003fd     	mov	x29, sp
    aee8: f90067f3     	str	x19, [sp, #0xc8]
    aeec: f9006bf4     	str	x20, [sp, #0xd0]
    aef0: f9006ff5     	str	x21, [sp, #0xd8]
    aef4: f90073f6     	str	x22, [sp, #0xe0]
    aef8: f90077f7     	str	x23, [sp, #0xe8]
    aefc: f9007bf8     	str	x24, [sp, #0xf0]
    af00: f9007ff9     	str	x25, [sp, #0xf8]
    af04: f90083fa     	str	x26, [sp, #0x100]
    af08: f90087fb     	str	x27, [sp, #0x108]
    af0c: f9008bfc     	str	x28, [sp, #0x110]
    af10: 910103f0     	add	x16, sp, #0x40
    af14: aa1f0207     	orr	x7, x16, xzr
    af18: f9400009     	ldr	x9, [x0]
    af1c: 910020f3     	add	x19, x7, #0x8
    af20: f9400400     	ldr	x0, [x0, #0x8]
    af24: 910043f0     	add	x16, sp, #0x10
    af28: d2e00011     	movz	x17, #0x0, lsl #48
    af2c: f9000211     	str	x17, [x16]
    af30: 910043f0     	add	x16, sp, #0x10
    af34: d2e00011     	movz	x17, #0x0, lsl #48
    af38: f9000611     	str	x17, [x16, #0x8]
    af3c: 910043f0     	add	x16, sp, #0x10
    af40: d2e00011     	movz	x17, #0x0, lsl #48
    af44: f9000a11     	str	x17, [x16, #0x10]
    af48: 910043f0     	add	x16, sp, #0x10
    af4c: f9000e09     	str	x9, [x16, #0x18]
    af50: 910043f0     	add	x16, sp, #0x10
    af54: f9001200     	str	x0, [x16, #0x20]
    af58: 910043e0     	add	x0, sp, #0x10
    af5c: f90063e8     	str	x8, [sp, #0xc0]
    af60: aa0103f5     	mov	x21, x1
    af64: aa0203f6     	mov	x22, x2
    af68: aa0303f7     	mov	x23, x3
    af6c: aa0403f8     	mov	x24, x4
    af70: aa0503f9     	mov	x25, x5
    af74: aa0603fa     	mov	x26, x6
    af78: d2800041     	mov	x1, #0x2                ; =2
    af7c: 94000000     	bl	0xaf7c <_coil.compiler.resolve.primitive-providers-in+0xa4>
		000000000000af7c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__coil.compiler.resolve.PrimitiveProvider
    af80: 910043f0     	add	x16, sp, #0x10
    af84: f9400200     	ldr	x0, [x16]
    af88: f9000017     	str	x23, [x0]
    af8c: f9000418     	str	x24, [x0, #0x8]
    af90: f9000819     	str	x25, [x0, #0x10]
    af94: f9000c1a     	str	x26, [x0, #0x18]
    af98: 910043f0     	add	x16, sp, #0x10
    af9c: d2800031     	mov	x17, #0x1               ; =1
    afa0: f9000611     	str	x17, [x16, #0x8]
    afa4: d2e00017     	movz	x23, #0x0, lsl #48
    afa8: 140000db     	b	0xb314 <_coil.compiler.resolve.primitive-providers-in+0x43c>
    afac: d1000400     	sub	x0, x0, #0x1
    afb0: 9345fc00     	asr	x0, x0, #5
    afb4: d37be800     	lsl	x0, x0, #5
    afb8: eb00039f     	cmp	x28, x0
    afbc: 5400006b     	b.lt	0xafc8 <_coil.compiler.resolve.primitive-providers-in+0xf0>
    afc0: f94006a0     	ldr	x0, [x21, #0x8]
    afc4: 1400001a     	b	0xb02c <_coil.compiler.resolve.primitive-providers-in+0x154>
    afc8: f94002a0     	ldr	x0, [x21]
    afcc: f9400ea1     	ldr	x1, [x21, #0x18]
    afd0: 14000015     	b	0xb024 <_coil.compiler.resolve.primitive-providers-in+0x14c>
    afd4: d37ff800     	lsl	x0, x0, #1
    afd8: aa0003e1     	mov	x1, x0
    afdc: 910043e0     	add	x0, sp, #0x10
    afe0: 94000000     	bl	0xafe0 <_coil.compiler.resolve.primitive-providers-in+0x108>
		000000000000afe0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__coil.compiler.resolve.PrimitiveProvider
    afe4: 91000680     	add	x0, x20, #0x1
    afe8: 910043f0     	add	x16, sp, #0x10
    afec: f9400201     	ldr	x1, [x16]
    aff0: 8b141421     	add	x1, x1, x20, lsl #5
    aff4: f900003b     	str	x27, [x1]
    aff8: f900043c     	str	x28, [x1, #0x8]
    affc: f9000833     	str	x19, [x1, #0x10]
    b000: f9000c3a     	str	x26, [x1, #0x18]
    b004: 910043f0     	add	x16, sp, #0x10
    b008: f9000600     	str	x0, [x16, #0x8]
    b00c: 14000026     	b	0xb0a4 <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    b010: 9ac12b82     	asr	x2, x28, x1
    b014: d1001421     	sub	x1, x1, #0x5
    b018: 92401042     	and	x2, x2, #0x1f
    b01c: f9401000     	ldr	x0, [x0, #0x20]
    b020: f8627800     	ldr	x0, [x0, x2, lsl #3]
    b024: f100003f     	cmp	x1, #0x0
    b028: 54ffff4c     	b.gt	0xb010 <_coil.compiler.resolve.primitive-providers-in+0x138>
    b02c: 92401381     	and	x1, x28, #0x1f
    b030: d2801e11     	mov	x17, #0xf0              ; =240
    b034: 9b117c21     	mul	x1, x1, x17
    b038: f9400c00     	ldr	x0, [x0, #0x18]
    b03c: 8b000022     	add	x2, x1, x0
    b040: 91004043     	add	x3, x2, #0x10
    b044: 91014064     	add	x4, x3, #0x50
    b048: f9005ffc     	str	x28, [sp, #0xb8]
    b04c: 92e00005     	movn	x5, #0x0, lsl #48
    b050: 14000020     	b	0xb0d0 <_coil.compiler.resolve.primitive-providers-in+0x1f8>
    b054: d503201f     	nop
    b058: d340fce7     	lsr	x7, x7, #0
    b05c: aa0103f6     	mov	x22, x1
    b060: aa1803e1     	mov	x1, x24
    b064: aa0203f9     	mov	x25, x2
    b068: aa0703e2     	mov	x2, x7
    b06c: f9003fe3     	str	x3, [sp, #0x78]
    b070: f90043e4     	str	x4, [sp, #0x80]
    b074: f90047e5     	str	x5, [sp, #0x88]
    b078: f9004be9     	str	x9, [sp, #0x90]
    b07c: f90037f8     	str	x24, [sp, #0x68]
    b080: aa0003f8     	mov	x24, x0
    b084: aa0603e0     	mov	x0, x6
    b088: 94000000     	bl	0xb088 <_coil.compiler.resolve.primitive-providers-in+0x1b0>
		000000000000b088:  ARM64_RELOC_BRANCH26	_memcmp
    b08c: 93407c00     	sxtw	x0, w0
    b090: f100001f     	cmp	x0, #0x0
    b094: 540004e0     	b.eq	0xb130 <_coil.compiler.resolve.primitive-providers-in+0x258>
    b098: f90053fa     	str	x26, [sp, #0xa0]
    b09c: f9005bfb     	str	x27, [sp, #0xb0]
    b0a0: f9004ff3     	str	x19, [sp, #0x98]
    b0a4: f94053fa     	ldr	x26, [sp, #0xa0]
    b0a8: f9405bfb     	ldr	x27, [sp, #0xb0]
    b0ac: f9403fe3     	ldr	x3, [sp, #0x78]
    b0b0: f94043e4     	ldr	x4, [sp, #0x80]
    b0b4: f9404ff3     	ldr	x19, [sp, #0x98]
    b0b8: aa1803e0     	mov	x0, x24
    b0bc: f94037f8     	ldr	x24, [sp, #0x68]
    b0c0: aa1603e1     	mov	x1, x22
    b0c4: aa1903e2     	mov	x2, x25
    b0c8: f9403bf9     	ldr	x25, [sp, #0x70]
    b0cc: f94047e5     	ldr	x5, [sp, #0x88]
    b0d0: f9400486     	ldr	x6, [x4, #0x8]
    b0d4: 910004a5     	add	x5, x5, #0x1
    b0d8: eb0600bf     	cmp	x5, x6
    b0dc: 540018ea     	b.ge	0xb3f8 <_coil.compiler.resolve.primitive-providers-in+0x520>
    b0e0: d2800611     	mov	x17, #0x30              ; =48
    b0e4: 9b117ca6     	mul	x6, x5, x17
    b0e8: f9402867     	ldr	x7, [x3, #0x50]
    b0ec: 8b0700c8     	add	x8, x6, x7
    b0f0: aa1f0109     	orr	x9, x8, xzr
    b0f4: f86768c6     	ldr	x6, [x6, x7]
    b0f8: f9400507     	ldr	x7, [x8, #0x8]
    b0fc: eb1900ff     	cmp	x7, x25
    b100: 54001881     	b.ne	0xb410 <_coil.compiler.resolve.primitive-providers-in+0x538>
    b104: f10000ff     	cmp	x7, #0x0
    b108: 540019c1     	b.ne	0xb440 <_coil.compiler.resolve.primitive-providers-in+0x568>
    b10c: f9003bf9     	str	x25, [sp, #0x70]
    b110: f9003fe3     	str	x3, [sp, #0x78]
    b114: f90043e4     	str	x4, [sp, #0x80]
    b118: f90047e5     	str	x5, [sp, #0x88]
    b11c: f9004be9     	str	x9, [sp, #0x90]
    b120: f90037f8     	str	x24, [sp, #0x68]
    b124: aa0003f8     	mov	x24, x0
    b128: aa0103f6     	mov	x22, x1
    b12c: aa0203f9     	mov	x25, x2
    b130: 910103e8     	add	x8, sp, #0x40
    b134: f9404be0     	ldr	x0, [sp, #0x90]
    b138: aa1a03e1     	mov	x1, x26
    b13c: aa1b03e2     	mov	x2, x27
    b140: 94000000     	bl	0xb140 <_coil.compiler.resolve.primitive-providers-in+0x268>
		000000000000b140:  ARM64_RELOC_BRANCH26	_coil.compiler.loader.use-local-of
    b144: 910103f0     	add	x16, sp, #0x40
    b148: b9400200     	ldr	w0, [x16]
    b14c: d340fc10     	lsr	x16, x0, #0
    b150: f100061f     	cmp	x16, #0x1
    b154: 54000140     	b.eq	0xb17c <_coil.compiler.resolve.primitive-providers-in+0x2a4>
    b158: 54000043     	b.lo	0xb160 <_coil.compiler.resolve.primitive-providers-in+0x288>
    b15c: 14000009     	b	0xb180 <_coil.compiler.resolve.primitive-providers-in+0x2a8>
    b160: f100021f     	cmp	x16, #0x0
    b164: 54000040     	b.eq	0xb16c <_coil.compiler.resolve.primitive-providers-in+0x294>
    b168: 14000006     	b	0xb180 <_coil.compiler.resolve.primitive-providers-in+0x2a8>
    b16c: f90053fa     	str	x26, [sp, #0xa0]
    b170: f9005bfb     	str	x27, [sp, #0xb0]
    b174: f9004ff3     	str	x19, [sp, #0x98]
    b178: 17ffffcb     	b	0xb0a4 <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    b17c: 14000002     	b	0xb184 <_coil.compiler.resolve.primitive-providers-in+0x2ac>
    b180: 14000080     	b	0xb380 <_coil.compiler.resolve.primitive-providers-in+0x4a8>
    b184: 910103f0     	add	x16, sp, #0x40
    b188: f9400600     	ldr	x0, [x16, #0x8]
    b18c: f9400661     	ldr	x1, [x19, #0x8]
    b190: f9004ff3     	str	x19, [sp, #0x98]
    b194: f90053fa     	str	x26, [sp, #0xa0]
    b198: f9005bfb     	str	x27, [sp, #0xb0]
    b19c: 92e00002     	movn	x2, #0x0, lsl #48
    b1a0: d2e00003     	movz	x3, #0x0, lsl #48
    b1a4: 14000006     	b	0xb1bc <_coil.compiler.resolve.primitive-providers-in+0x2e4>
    b1a8: d280003b     	mov	x27, #0x1               ; =1
    b1ac: aa1303e0     	mov	x0, x19
    b1b0: aa1a03e1     	mov	x1, x26
    b1b4: f94057e2     	ldr	x2, [sp, #0xa8]
    b1b8: aa1b03e3     	mov	x3, x27
    b1bc: 910043f0     	add	x16, sp, #0x10
    b1c0: f9400604     	ldr	x4, [x16, #0x8]
    b1c4: 91000442     	add	x2, x2, #0x1
    b1c8: eb04005f     	cmp	x2, x4
    b1cc: 540013ea     	b.ge	0xb448 <_coil.compiler.resolve.primitive-providers-in+0x570>
    b1d0: 910043f0     	add	x16, sp, #0x10
    b1d4: f9400204     	ldr	x4, [x16]
    b1d8: 8b021484     	add	x4, x4, x2, lsl #5
    b1dc: f9400085     	ldr	x5, [x4]
    b1e0: f9400486     	ldr	x6, [x4, #0x8]
    b1e4: f9400887     	ldr	x7, [x4, #0x10]
    b1e8: f9400c84     	ldr	x4, [x4, #0x18]
    b1ec: f8786ac8     	ldr	x8, [x22, x24]
    b1f0: f9400729     	ldr	x9, [x25, #0x8]
    b1f4: eb0900df     	cmp	x6, x9
    b1f8: 54001301     	b.ne	0xb458 <_coil.compiler.resolve.primitive-providers-in+0x580>
    b1fc: f10000df     	cmp	x6, #0x0
    b200: 54000281     	b.ne	0xb250 <_coil.compiler.resolve.primitive-providers-in+0x378>
    b204: aa0303fb     	mov	x27, x3
    b208: aa0003f3     	mov	x19, x0
    b20c: aa0103fa     	mov	x26, x1
    b210: f90057e2     	str	x2, [sp, #0xa8]
    b214: aa0703fc     	mov	x28, x7
    b218: aa0403f4     	mov	x20, x4
    b21c: eb1a029f     	cmp	x20, x26
    b220: 54fffc61     	b.ne	0xb1ac <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    b224: f100029f     	cmp	x20, #0x0
    b228: 54fffc00     	b.eq	0xb1a8 <_coil.compiler.resolve.primitive-providers-in+0x2d0>
    b22c: d340fe80     	lsr	x0, x20, #0
    b230: aa1303e1     	mov	x1, x19
    b234: aa0003e2     	mov	x2, x0
    b238: aa1c03e0     	mov	x0, x28
    b23c: 94000000     	bl	0xb23c <_coil.compiler.resolve.primitive-providers-in+0x364>
		000000000000b23c:  ARM64_RELOC_BRANCH26	_memcmp
    b240: 93407c00     	sxtw	x0, w0
    b244: f100001f     	cmp	x0, #0x0
    b248: 54fffb00     	b.eq	0xb1a8 <_coil.compiler.resolve.primitive-providers-in+0x2d0>
    b24c: 17ffffd8     	b	0xb1ac <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    b250: d340fcc6     	lsr	x6, x6, #0
    b254: aa0003f3     	mov	x19, x0
    b258: aa0503e0     	mov	x0, x5
    b25c: aa0103fa     	mov	x26, x1
    b260: aa0803e1     	mov	x1, x8
    b264: f90057e2     	str	x2, [sp, #0xa8]
    b268: aa0603e2     	mov	x2, x6
    b26c: aa0303fb     	mov	x27, x3
    b270: aa0703fc     	mov	x28, x7
    b274: aa0403f4     	mov	x20, x4
    b278: 94000000     	bl	0xb278 <_coil.compiler.resolve.primitive-providers-in+0x3a0>
		000000000000b278:  ARM64_RELOC_BRANCH26	_memcmp
    b27c: 93407c00     	sxtw	x0, w0
    b280: f100001f     	cmp	x0, #0x0
    b284: 54fffcc0     	b.eq	0xb21c <_coil.compiler.resolve.primitive-providers-in+0x344>
    b288: 17ffffc9     	b	0xb1ac <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    b28c: f100037f     	cmp	x27, #0x0
    b290: 54fff0a1     	b.ne	0xb0a4 <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    b294: aa1f0094     	orr	x20, x4, xzr
    b298: f8786adb     	ldr	x27, [x22, x24]
    b29c: f940073c     	ldr	x28, [x25, #0x8]
    b2a0: 910043f0     	add	x16, sp, #0x10
    b2a4: f9400a00     	ldr	x0, [x16, #0x10]
    b2a8: eb00029f     	cmp	x20, x0
    b2ac: 54ffe9cb     	b.lt	0xafe4 <_coil.compiler.resolve.primitive-providers-in+0x10c>
    b2b0: f100001f     	cmp	x0, #0x0
    b2b4: 54ffe901     	b.ne	0xafd4 <_coil.compiler.resolve.primitive-providers-in+0xfc>
    b2b8: d2800040     	mov	x0, #0x2                ; =2
    b2bc: 17ffff47     	b	0xafd8 <_coil.compiler.resolve.primitive-providers-in+0x100>
    b2c0: f9403bf9     	ldr	x25, [sp, #0x70]
    b2c4: f94053fa     	ldr	x26, [sp, #0xa0]
    b2c8: f9405bfb     	ldr	x27, [sp, #0xb0]
    b2cc: f9404ff3     	ldr	x19, [sp, #0x98]
    b2d0: f94037f8     	ldr	x24, [sp, #0x68]
    b2d4: f9405ffc     	ldr	x28, [sp, #0xb8]
    b2d8: f9400aa0     	ldr	x0, [x21, #0x10]
    b2dc: 9100079c     	add	x28, x28, #0x1
    b2e0: eb00039f     	cmp	x28, x0
    b2e4: 54000c4a     	b.ge	0xb46c <_coil.compiler.resolve.primitive-providers-in+0x594>
    b2e8: f100039f     	cmp	x28, #0x0
    b2ec: 54000c4b     	b.lt	0xb474 <_coil.compiler.resolve.primitive-providers-in+0x59c>
    b2f0: eb00039f     	cmp	x28, x0
    b2f4: 54000c4a     	b.ge	0xb47c <_coil.compiler.resolve.primitive-providers-in+0x5a4>
    b2f8: f100801f     	cmp	x0, #0x20
    b2fc: 54ffe58a     	b.ge	0xafac <_coil.compiler.resolve.primitive-providers-in+0xd4>
    b300: d2e00000     	movz	x0, #0x0, lsl #48
    b304: 17ffff2d     	b	0xafb8 <_coil.compiler.resolve.primitive-providers-in+0xe0>
    b308: 910006f7     	add	x23, x23, #0x1
    b30c: f94033f6     	ldr	x22, [sp, #0x60]
    b310: f9404ff3     	ldr	x19, [sp, #0x98]
    b314: 910043f0     	add	x16, sp, #0x10
    b318: f9400600     	ldr	x0, [x16, #0x8]
    b31c: eb0002ff     	cmp	x23, x0
    b320: 5400034a     	b.ge	0xb388 <_coil.compiler.resolve.primitive-providers-in+0x4b0>
    b324: 910043f0     	add	x16, sp, #0x10
    b328: f9400200     	ldr	x0, [x16]
    b32c: 8b171400     	add	x0, x0, x23, lsl #5
    b330: f9400018     	ldr	x24, [x0]
    b334: f9400419     	ldr	x25, [x0, #0x8]
    b338: f940081a     	ldr	x26, [x0, #0x10]
    b33c: f9400c1b     	ldr	x27, [x0, #0x18]
    b340: aa1603e0     	mov	x0, x22
    b344: aa1803e1     	mov	x1, x24
    b348: aa1903e2     	mov	x2, x25
    b34c: aa1a03e3     	mov	x3, x26
    b350: aa1b03e4     	mov	x4, x27
    b354: 94000000     	bl	0xb354 <_coil.compiler.resolve.primitive-providers-in+0x47c>
		000000000000b354:  ARM64_RELOC_BRANCH26	_coil.compiler.resolve.exports-check
    b358: f100001f     	cmp	x0, #0x0
    b35c: 54000940     	b.eq	0xb484 <_coil.compiler.resolve.primitive-providers-in+0x5ac>
    b360: f90033f6     	str	x22, [sp, #0x60]
    b364: 92e0001c     	movn	x28, #0x0, lsl #48
    b368: 17ffffdc     	b	0xb2d8 <_coil.compiler.resolve.primitive-providers-in+0x400>
    b36c: f9400aa0     	ldr	x0, [x21, #0x10]
    b370: aa0003e1     	mov	x1, x0
    b374: f9405fe0     	ldr	x0, [sp, #0xb8]
    b378: 94000000     	bl	0xb378 <_coil.compiler.resolve.primitive-providers-in+0x4a0>
		000000000000b378:  ARM64_RELOC_BRANCH26	_coil.avec.avec--bounds-error
    b37c: 14000000     	b	0xb37c <_coil.compiler.resolve.primitive-providers-in+0x4a4>
    b380: d4200000     	brk	#0
    b384: 17ffffff     	b	0xb380 <_coil.compiler.resolve.primitive-providers-in+0x4a8>
    b388: 910043f0     	add	x16, sp, #0x10
    b38c: f9400201     	ldr	x1, [x16]
    b390: 910043f0     	add	x16, sp, #0x10
    b394: f9400a02     	ldr	x2, [x16, #0x10]
    b398: 910043f0     	add	x16, sp, #0x10
    b39c: f9400e03     	ldr	x3, [x16, #0x18]
    b3a0: 910043f0     	add	x16, sp, #0x10
    b3a4: f9401204     	ldr	x4, [x16, #0x20]
    b3a8: f94063e5     	ldr	x5, [sp, #0xc0]
    b3ac: f90000a1     	str	x1, [x5]
    b3b0: f90004a0     	str	x0, [x5, #0x8]
    b3b4: f90008a2     	str	x2, [x5, #0x10]
    b3b8: f9000ca3     	str	x3, [x5, #0x18]
    b3bc: f90010a4     	str	x4, [x5, #0x20]
    b3c0: f94067f3     	ldr	x19, [sp, #0xc8]
    b3c4: f9406bf4     	ldr	x20, [sp, #0xd0]
    b3c8: f9406ff5     	ldr	x21, [sp, #0xd8]
    b3cc: f94073f6     	ldr	x22, [sp, #0xe0]
    b3d0: f94077f7     	ldr	x23, [sp, #0xe8]
    b3d4: f9407bf8     	ldr	x24, [sp, #0xf0]
    b3d8: f9407ff9     	ldr	x25, [sp, #0xf8]
    b3dc: f94083fa     	ldr	x26, [sp, #0x100]
    b3e0: f94087fb     	ldr	x27, [sp, #0x108]
    b3e4: f9408bfc     	ldr	x28, [sp, #0x110]
    b3e8: f94003fd     	ldr	x29, [sp]
    b3ec: f94007fe     	ldr	x30, [sp, #0x8]
    b3f0: 910483ff     	add	sp, sp, #0x120
    b3f4: d65f03c0     	ret
    b3f8: f9003bf9     	str	x25, [sp, #0x70]
    b3fc: f90053fa     	str	x26, [sp, #0xa0]
    b400: f9005bfb     	str	x27, [sp, #0xb0]
    b404: f9004ff3     	str	x19, [sp, #0x98]
    b408: f90037f8     	str	x24, [sp, #0x68]
    b40c: 17ffffad     	b	0xb2c0 <_coil.compiler.resolve.primitive-providers-in+0x3e8>
    b410: f9003bf9     	str	x25, [sp, #0x70]
    b414: f90053fa     	str	x26, [sp, #0xa0]
    b418: f9005bfb     	str	x27, [sp, #0xb0]
    b41c: f9003fe3     	str	x3, [sp, #0x78]
    b420: f90043e4     	str	x4, [sp, #0x80]
    b424: f90047e5     	str	x5, [sp, #0x88]
    b428: f9004ff3     	str	x19, [sp, #0x98]
    b42c: f90037f8     	str	x24, [sp, #0x68]
    b430: aa0003f8     	mov	x24, x0
    b434: aa0103f6     	mov	x22, x1
    b438: aa0203f9     	mov	x25, x2
    b43c: 17ffff1a     	b	0xb0a4 <_coil.compiler.resolve.primitive-providers-in+0x1cc>
    b440: f9003bf9     	str	x25, [sp, #0x70]
    b444: 17ffff05     	b	0xb058 <_coil.compiler.resolve.primitive-providers-in+0x180>
    b448: aa0303fb     	mov	x27, x3
    b44c: aa0003f3     	mov	x19, x0
    b450: aa0103fa     	mov	x26, x1
    b454: 17ffff8e     	b	0xb28c <_coil.compiler.resolve.primitive-providers-in+0x3b4>
    b458: aa0303fb     	mov	x27, x3
    b45c: aa0003f3     	mov	x19, x0
    b460: aa0103fa     	mov	x26, x1
    b464: f90057e2     	str	x2, [sp, #0xa8]
    b468: 17ffff51     	b	0xb1ac <_coil.compiler.resolve.primitive-providers-in+0x2d4>
    b46c: f9004ff3     	str	x19, [sp, #0x98]
    b470: 17ffffa6     	b	0xb308 <_coil.compiler.resolve.primitive-providers-in+0x430>
    b474: f9005ffc     	str	x28, [sp, #0xb8]
    b478: 17ffffbd     	b	0xb36c <_coil.compiler.resolve.primitive-providers-in+0x494>
    b47c: f9005ffc     	str	x28, [sp, #0xb8]
    b480: 17ffffbb     	b	0xb36c <_coil.compiler.resolve.primitive-providers-in+0x494>
    b484: f90033f6     	str	x22, [sp, #0x60]
    b488: f9004ff3     	str	x19, [sp, #0x98]
    b48c: 17ffff9f     	b	0xb308 <_coil.compiler.resolve.primitive-providers-in+0x430>
