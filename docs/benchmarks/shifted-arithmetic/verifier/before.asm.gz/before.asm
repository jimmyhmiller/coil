
/Users/jimmyhmiller/Documents/Code/projects/coil-stogir/.worktrees/shifted-arithmetic/build/shifted-verifier/before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x138 <_stogir.verify.integer-operations-target+0x88>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, x0
     130:      	mov	x0, #0x1                ; =1
     134:      	b	0x164 <_stogir.verify.integer-operations-target+0xb4>
     138:      	lsr	w21, w21, #0
     13c:      	add	x8, sp, #0x30
     140:      	mov	x0, x20
     144:      	mov	w1, w21
     148:      	bl	0x148 <_stogir.verify.integer-operations-target+0x98>
		0000000000000148:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     14c:      	add	x16, sp, #0x30
     150:      	ldr	x0, [x16]
     154:      	add	x16, sp, #0x30
     158:      	ldr	x1, [x16, #0x8]
     15c:      	add	x16, sp, #0x30
     160:      	ldr	x2, [x16, #0x10]
     164:      	str	x0, [x19]
     168:      	str	x1, [x19, #0x8]
     16c:      	str	x2, [x19, #0x10]
     170:      	ldr	x19, [sp, #0x50]
     174:      	ldr	x20, [sp, #0x58]
     178:      	ldr	x21, [sp, #0x60]
     17c:      	ldr	x29, [sp]
     180:      	ldr	x30, [sp, #0x8]
     184:      	add	sp, sp, #0x70
     188:      	ret
     18c:      	brk	#0
     190:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>

0000000000000194 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     194:      	ldr	x0, [x0, #0x8]
     198:      	ret
     19c:      	udf	#0x0

00000000000001a0 <_stogir.verify.structure>:
     1a0:      	sub	sp, sp, #0x170
     1a4:      	str	x29, [sp, #0x10]
     1a8:      	str	x30, [sp, #0x18]
     1ac:      	add	x29, sp, #0x10
     1b0:      	str	x19, [sp, #0x120]
     1b4:      	str	x20, [sp, #0x128]
     1b8:      	str	x21, [sp, #0x130]
     1bc:      	str	x22, [sp, #0x138]
     1c0:      	str	x23, [sp, #0x140]
     1c4:      	str	x24, [sp, #0x148]
     1c8:      	str	x25, [sp, #0x150]
     1cc:      	str	x26, [sp, #0x158]
     1d0:      	str	x27, [sp, #0x160]
     1d4:      	str	x28, [sp, #0x168]
     1d8:      	add	x1, x0, #0x78
     1dc:      	ldr	x2, [x0, #0x8]
     1e0:      	ldr	x1, [x1, #0x8]
     1e4:      	cmp	x2, x1
     1e8:      	b.ne	0x224 <_stogir.verify.structure+0x84>
     1ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001ec:  ARM64_RELOC_PAGE21	l_stogir.304
     1f0:      	ldr	x16, [x16]
		00000000000001f0:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1f4:      	orr	x1, x16, xzr
     1f8:      	movz	x2, #0x0, lsl #48
     1fc:      	b	0x234 <_stogir.verify.structure+0x94>
     200:      	ldr	x0, [sp, #0x30]
     204:      	add	x0, x21, x0
     208:      	ldr	x1, [sp, #0xa8]
     20c:      	add	x1, x1, #0x1
     210:      	lsr	w1, w1, #0
     214:      	sxtw	x1, w1
     218:      	ldr	x2, [sp, #0x100]
     21c:      	ldr	x3, [sp, #0xf8]
     220:      	b	0x2e8 <_stogir.verify.structure+0x148>
     224:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000224:  ARM64_RELOC_PAGE21	l_stogir.305
     228:      	ldr	x16, [x16]
		0000000000000228:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     22c:      	orr	x1, x16, xzr
     230:      	mov	x2, #0x2c               ; =44
     234:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000234:  ARM64_RELOC_PAGE21	l_stogir.306
     238:      	ldr	x16, [x16]
		0000000000000238:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     23c:      	orr	x19, x16, xzr
     240:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000240:  ARM64_RELOC_PAGE21	l_stogir.307
     244:      	ldr	x16, [x16]
		0000000000000244:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     248:      	orr	x20, x16, xzr
     24c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000024c:  ARM64_RELOC_PAGE21	l_stogir.308
     250:      	ldr	x16, [x16]
		0000000000000250:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     254:      	orr	x21, x16, xzr
     258:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000258:  ARM64_RELOC_PAGE21	l_stogir.309
     25c:      	ldr	x16, [x16]
		000000000000025c:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     260:      	orr	x22, x16, xzr
     264:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000264:  ARM64_RELOC_PAGE21	l_stogir.310
     268:      	ldr	x16, [x16]
		0000000000000268:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     26c:      	orr	x23, x16, xzr
     270:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000270:  ARM64_RELOC_PAGE21	l_stogir.311
     274:      	ldr	x16, [x16]
		0000000000000274:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     278:      	orr	x24, x16, xzr
     27c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000027c:  ARM64_RELOC_PAGE21	l_stogir.312
     280:      	ldr	x16, [x16]
		0000000000000280:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     284:      	orr	x25, x16, xzr
     288:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000288:  ARM64_RELOC_PAGE21	l_stogir.313
     28c:      	ldr	x16, [x16]
		000000000000028c:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     290:      	orr	x26, x16, xzr
     294:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000294:  ARM64_RELOC_PAGE21	l_stogir.314
     298:      	ldr	x16, [x16]
		0000000000000298:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     29c:      	orr	x27, x16, xzr
     2a0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002a0:  ARM64_RELOC_PAGE21	l_stogir.315
     2a4:      	ldr	x16, [x16]
		00000000000002a4:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     2a8:      	orr	x28, x16, xzr
     2ac:      	add	x3, x0, #0x110
     2b0:      	add	x4, x0, #0x78
     2b4:      	add	x5, x0, #0x28
     2b8:      	add	x6, x0, #0x50
     2bc:      	add	x7, x0, #0x78
     2c0:      	add	x9, x0, #0x28
     2c4:      	add	x10, x0, #0x50
     2c8:      	add	x11, x3, #0x28
     2cc:      	mov	x12, x1
     2d0:      	mov	x13, x2
     2d4:      	mov	x1, #0x1                ; =1
     2d8:      	movz	x2, #0x0, lsl #48
     2dc:      	b	0x3b0 <_stogir.verify.structure+0x210>
     2e0:      	ldr	x2, [sp, #0x58]
     2e4:      	mov	x3, #0x16               ; =22
     2e8:      	b	0x350 <_stogir.verify.structure+0x1b0>
     2ec:      	nop
     2f0:      	mov	x1, x2
     2f4:      	str	x8, [sp, #0xa0]
     2f8:      	str	x19, [sp, #0x50]
     2fc:      	str	x20, [sp, #0x58]
     300:      	mov	x20, x0
     304:      	ldr	x0, [sp, #0x30]
     308:      	str	x21, [sp, #0x60]
     30c:      	str	x22, [sp, #0x68]
     310:      	str	x23, [sp, #0x70]
     314:      	str	x24, [sp, #0x78]
     318:      	str	x25, [sp, #0x80]
     31c:      	str	x26, [sp, #0x88]
     320:      	str	x27, [sp, #0x90]
     324:      	str	x28, [sp, #0x98]
     328:      	str	x3, [sp, #0xd8]
     32c:      	str	x11, [sp, #0xe0]
     330:      	mov	x19, x4
     334:      	str	x5, [sp, #0xc8]
     338:      	str	x6, [sp, #0xc0]
     33c:      	mov	x25, x7
     340:      	mov	x26, x9
     344:      	mov	x27, x10
     348:      	ldr	x2, [sp, #0x50]
     34c:      	mov	x3, #0x23               ; =35
     350:      	ldr	x8, [sp, #0xa0]
     354:      	ldr	x21, [sp, #0x60]
     358:      	ldr	x22, [sp, #0x68]
     35c:      	ldr	x23, [sp, #0x70]
     360:      	ldr	x24, [sp, #0x78]
     364:      	ldr	x28, [sp, #0x98]
     368:      	ldr	x11, [sp, #0xe0]
     36c:      	mov	x4, x19
     370:      	ldr	x19, [sp, #0x50]
     374:      	ldr	x5, [sp, #0xc8]
     378:      	ldr	x6, [sp, #0xc0]
     37c:      	mov	x7, x25
     380:      	ldr	x25, [sp, #0x80]
     384:      	mov	x9, x26
     388:      	ldr	x26, [sp, #0x88]
     38c:      	mov	x10, x27
     390:      	ldr	x27, [sp, #0x90]
     394:      	mov	x12, x2
     398:      	mov	x2, x1
     39c:      	mov	x1, x0
     3a0:      	mov	x0, x20
     3a4:      	ldr	x20, [sp, #0x58]
     3a8:      	mov	x13, x3
     3ac:      	ldr	x3, [sp, #0xd8]
     3b0:      	cmp	x13, #0x0
     3b4:      	b.ne	0xc3c <_stogir.verify.structure+0xa9c>
     3b8:      	ldr	x14, [x0, #0x8]
     3bc:      	cmp	x1, x14
     3c0:      	b.ge	0xc50 <_stogir.verify.structure+0xab0>
     3c4:      	lsl	x14, x1, #4
     3c8:      	lsl	x15, x1, #2
     3cc:      	str	x1, [sp, #0x30]
     3d0:      	ldr	x1, [x0]
     3d4:      	add	x1, x14, x1
     3d8:      	ldr	x1, [x1]
     3dc:      	ldr	x14, [x0, #0x78]
     3e0:      	add	x14, x15, x14
     3e4:      	ldr	w14, [x14]
     3e8:      	sxtw	x14, w14
     3ec:      	cmp	x14, #0x0
     3f0:      	b.lt	0x2f0 <_stogir.verify.structure+0x150>
     3f4:      	mov	x17, #0xffff            ; =65535
     3f8:      	cmp	x14, x17
     3fc:      	b.gt	0xc64 <_stogir.verify.structure+0xac4>
     400:      	uxtb	w15, w1
     404:      	str	x0, [sp, #0x38]
     408:      	orr	x0, x15, xzr
     40c:      	cmp	x0, #0x83
     410:      	b.ge	0xcc0 <_stogir.verify.structure+0xb20>
     414:      	lsr	w1, w1, #0
     418:      	str	x0, [sp, #0x40]
     41c:      	ubfx	x0, x1, #8, #8
     420:      	str	w0, [sp, #0x48]
     424:      	lsr	w0, w0, #0
     428:      	str	x8, [sp, #0xa0]
     42c:      	str	x3, [sp, #0xd8]
     430:      	str	x4, [sp, #0xd0]
     434:      	str	x5, [sp, #0xc8]
     438:      	str	x6, [sp, #0xc0]
     43c:      	str	x11, [sp, #0xe0]
     440:      	str	x2, [sp, #0xa8]
     444:      	str	x12, [sp, #0xb0]
     448:      	str	x13, [sp, #0xb8]
     44c:      	str	x19, [sp, #0x50]
     450:      	ldr	x19, [sp, #0x30]
     454:      	str	x20, [sp, #0x58]
     458:      	ldr	x20, [sp, #0x38]
     45c:      	str	x21, [sp, #0x60]
     460:      	mov	x21, x1
     464:      	str	x22, [sp, #0x68]
     468:      	ldr	x22, [sp, #0x40]
     46c:      	str	x23, [sp, #0x70]
     470:      	mov	w23, w15
     474:      	str	x24, [sp, #0x78]
     478:      	mov	x24, x14
     47c:      	str	x25, [sp, #0x80]
     480:      	mov	x25, x7
     484:      	str	x26, [sp, #0x88]
     488:      	mov	x26, x9
     48c:      	str	x27, [sp, #0x90]
     490:      	mov	x27, x10
     494:      	str	x28, [sp, #0x98]
     498:      	ldr	w28, [sp, #0x48]
     49c:      	bl	0x49c <_stogir.verify.structure+0x2fc>
		000000000000049c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     4a0:      	cmp	x0, #0x0
     4a4:      	b.eq	0xd1c <_stogir.verify.structure+0xb7c>
     4a8:      	lsr	w23, w23, #0
     4ac:      	mov	w0, w23
     4b0:      	bl	0x4b0 <_stogir.verify.structure+0x310>
		00000000000004b0:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4b4:      	lsr	w0, w0, #0
     4b8:      	sxtw	x0, w0
     4bc:      	cmp	x0, #0x0
     4c0:      	b.lt	0x9f0 <_stogir.verify.structure+0x850>
     4c4:      	mov	w0, w23
     4c8:      	bl	0x4c8 <_stogir.verify.structure+0x328>
		00000000000004c8:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4cc:      	lsr	w0, w0, #0
     4d0:      	sxtw	x0, w0
     4d4:      	cmp	x24, x0
     4d8:      	b.eq	0x9f0 <_stogir.verify.structure+0x850>
     4dc:      	mov	x0, x19
     4e0:      	ldr	x19, [sp, #0xd0]
     4e4:      	ldr	x1, [sp, #0xa8]
     4e8:      	ldr	x2, [sp, #0x60]
     4ec:      	mov	x3, #0x23               ; =35
     4f0:      	b	0x220 <_stogir.verify.structure+0x80>
     4f4:      	ldr	x0, [sp, #0xb8]
     4f8:      	cmp	x0, #0x0
     4fc:      	b.ne	0x514 <_stogir.verify.structure+0x374>
     500:      	and	x0, x1, #0xffffffff
     504:      	mov	x1, x0
     508:      	movz	x0, #0x0, lsl #48
     50c:      	movz	x2, #0x0, lsl #48
     510:      	b	0x520 <_stogir.verify.structure+0x380>
     514:      	ldr	x1, [sp, #0xb0]
     518:      	mov	x2, x0
     51c:      	mov	x0, #0x1                ; =1
     520:      	ldr	x3, [sp, #0xa0]
     524:      	str	x0, [x3]
     528:      	str	x1, [x3, #0x8]
     52c:      	str	x2, [x3, #0x10]
     530:      	ldr	x19, [sp, #0x120]
     534:      	ldr	x20, [sp, #0x128]
     538:      	ldr	x21, [sp, #0x130]
     53c:      	ldr	x22, [sp, #0x138]
     540:      	ldr	x23, [sp, #0x140]
     544:      	ldr	x24, [sp, #0x148]
     548:      	ldr	x25, [sp, #0x150]
     54c:      	ldr	x26, [sp, #0x158]
     550:      	ldr	x27, [sp, #0x160]
     554:      	ldr	x28, [sp, #0x168]
     558:      	ldr	x29, [sp, #0x10]
     55c:      	ldr	x30, [sp, #0x18]
     560:      	add	sp, sp, #0x170
     564:      	ret
     568:      	mov	x0, x9
     56c:      	ldr	x1, [sp, #0x110]
     570:      	b	0x62c <_stogir.verify.structure+0x48c>
     574:      	nop
     578:      	mov	x4, x2
     57c:      	movz	x2, #0x0, lsl #48
     580:      	cmp	x2, #0x0
     584:      	b.eq	0xd2c <_stogir.verify.structure+0xb8c>
     588:      	lsr	w2, w1, #0
     58c:      	str	w0, [sp, #0xe8]
     590:      	mov	w0, w23
     594:      	str	x3, [sp, #0xf8]
     598:      	str	x4, [sp, #0x100]
     59c:      	str	w23, [sp, #0xf0]
     5a0:      	mov	x23, x1
     5a4:      	mov	w1, w2
     5a8:      	str	x24, [sp, #0x108]
     5ac:      	mov	w24, w2
     5b0:      	bl	0x5b0 <_stogir.verify.structure+0x410>
		00000000000005b0:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     5b4:      	add	x16, sp, #0x20
     5b8:      	str	x16, [sp]
     5bc:      	ldr	w1, [sp, #0xe8]
     5c0:      	mov	w2, w24
     5c4:      	str	x19, [sp, #0x30]
     5c8:      	mov	x19, x0
     5cc:      	mov	x0, x20
     5d0:      	bl	0x5d0 <_stogir.verify.structure+0x430>
		00000000000005d0:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     5d4:      	ldr	x16, [sp]
     5d8:      	str	x0, [x16]
     5dc:      	str	x1, [x16, #0x8]
     5e0:      	add	x16, sp, #0x20
     5e4:      	ldr	x0, [x16]
     5e8:      	add	x16, sp, #0x20
     5ec:      	ldr	x1, [x16, #0x8]
     5f0:      	lsr	w0, w0, #0
     5f4:      	lsr	x16, x0, #0
     5f8:      	cmp	x16, #0x1
     5fc:      	b.eq	0x618 <_stogir.verify.structure+0x478>
     600:      	b.lo	0x608 <_stogir.verify.structure+0x468>
     604:      	b	0x61c <_stogir.verify.structure+0x47c>
     608:      	cmp	x16, #0x0
     60c:      	b.eq	0x614 <_stogir.verify.structure+0x474>
     610:      	b	0x61c <_stogir.verify.structure+0x47c>
     614:      	b	0x620 <_stogir.verify.structure+0x480>
     618:      	b	0x67c <_stogir.verify.structure+0x4dc>
     61c:      	b	0xba8 <_stogir.verify.structure+0xa08>
     620:      	ldr	x19, [sp, #0xd0]
     624:      	ldr	x0, [sp, #0x80]
     628:      	mov	x1, #0x17               ; =23
     62c:      	add	x2, x23, #0x1
     630:      	lsr	w2, w2, #0
     634:      	sxtw	x2, w2
     638:      	ldr	x24, [sp, #0x108]
     63c:      	ldr	w23, [sp, #0xf0]
     640:      	str	x19, [sp, #0xd0]
     644:      	ldr	x19, [sp, #0x30]
     648:      	mov	x3, x1
     64c:      	mov	x1, x2
     650:      	mov	x2, x0
     654:      	ldr	w0, [sp, #0xe8]
     658:      	cmp	x3, #0x0
     65c:      	b.ne	0x578 <_stogir.verify.structure+0x3d8>
     660:      	cmp	x1, x24
     664:      	cset	w4, le
     668:      	ubfx	x4, x4, #0, #8
     66c:      	fmov	d31, x2
     670:      	mov	x2, x4
     674:      	fmov	x4, d31
     678:      	b	0x580 <_stogir.verify.structure+0x3e0>
     67c:      	lsr	w19, w19, #0
     680:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000680:  ARM64_RELOC_PAGE21	l_stogir.316
     684:      	ldr	x16, [x16]
		0000000000000684:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     688:      	ldr	w0, [x16]
     68c:      	orr	x2, x19, xzr
     690:      	cmp	x2, x0
     694:      	b.ne	0x6a0 <_stogir.verify.structure+0x500>
     698:      	mov	x0, #0x1                ; =1
     69c:      	b	0x6b8 <_stogir.verify.structure+0x518>
     6a0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000006a0:  ARM64_RELOC_PAGE21	l_stogir.317
     6a4:      	ldr	x16, [x16]
		00000000000006a4:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     6a8:      	ldr	w0, [x16]
     6ac:      	cmp	x2, x0
     6b0:      	cset	w0, eq
     6b4:      	ubfx	x0, x0, #0, #8
     6b8:      	lsr	w1, w1, #0
     6bc:      	sxtw	x1, w1
     6c0:      	cmp	x1, #0x0
     6c4:      	cset	w3, gt
     6c8:      	lsl	x4, x1, #2
     6cc:      	cmp	x1, #0x0
     6d0:      	cset	w5, lt
     6d4:      	movz	x16, #0x0, lsl #48
     6d8:      	sub	x6, x16, x1
     6dc:      	sub	x7, x6, #0x1
     6e0:      	lsl	x8, x7, #2
     6e4:      	cmp	x0, #0x0
     6e8:      	b.eq	0x730 <_stogir.verify.structure+0x590>
     6ec:      	uxtb	w16, w3
     6f0:      	cmp	w16, wzr
     6f4:      	b.eq	0x930 <_stogir.verify.structure+0x790>
     6f8:      	ldr	x9, [x20, #0x8]
     6fc:      	cmp	x1, x9
     700:      	b.ge	0x974 <_stogir.verify.structure+0x7d4>
     704:      	ldr	x9, [x25, #0x8]
     708:      	cmp	x1, x9
     70c:      	b.ge	0xa3c <_stogir.verify.structure+0x89c>
     710:      	ldr	x9, [x20, #0x78]
     714:      	add	x9, x4, x9
     718:      	ldr	w9, [x9]
     71c:      	sxtw	x9, w9
     720:      	cmp	x9, #0x0
     724:      	cset	w9, ge
     728:      	ubfx	x9, x9, #0, #8
     72c:      	b	0xa40 <_stogir.verify.structure+0x8a0>
     730:      	ldr	x9, [sp, #0x100]
     734:      	ldr	x10, [sp, #0xf8]
     738:      	movz	x7, #0x0, lsl #48
     73c:      	b	0x754 <_stogir.verify.structure+0x5b4>
     740:      	ldr	x7, [sp, #0x100]
     744:      	ldr	x10, [sp, #0xf8]
     748:      	fmov	d31, x7
     74c:      	mov	x7, x9
     750:      	fmov	x9, d31
     754:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000754:  ARM64_RELOC_PAGE21	l_stogir.318
     758:      	ldr	x16, [x16]
		0000000000000758:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     75c:      	ldr	w11, [x16]
     760:      	cmp	x2, x11
     764:      	b.ne	0xd40 <_stogir.verify.structure+0xba0>
     768:      	cmp	x1, #0x0
     76c:      	b.gt	0x8d0 <_stogir.verify.structure+0x730>
     770:      	ldr	x12, [sp, #0xd8]
     774:      	ldr	x2, [sp, #0xe0]
     778:      	movz	x11, #0x0, lsl #48
     77c:      	lsr	w11, w11, #0
     780:      	lsr	x16, x11, #0
     784:      	cmp	x16, #0x1
     788:      	b.eq	0x7a4 <_stogir.verify.structure+0x604>
     78c:      	b.lo	0x794 <_stogir.verify.structure+0x5f4>
     790:      	b	0x7a8 <_stogir.verify.structure+0x608>
     794:      	cmp	x16, #0x0
     798:      	b.eq	0x7a0 <_stogir.verify.structure+0x600>
     79c:      	b	0x7a8 <_stogir.verify.structure+0x608>
     7a0:      	b	0x7ac <_stogir.verify.structure+0x60c>
     7a4:      	b	0x7b4 <_stogir.verify.structure+0x614>
     7a8:      	b	0xc2c <_stogir.verify.structure+0xa8c>
     7ac:      	ldr	x9, [sp, #0x90]
     7b0:      	mov	x10, #0x21              ; =33
     7b4:      	cmp	x19, #0xf
     7b8:      	b.hs	0xd4c <_stogir.verify.structure+0xbac>
     7bc:      	mov	x16, #0x1               ; =1
     7c0:      	lsl	x11, x16, x19
     7c4:      	lsr	w11, w11, #0
     7c8:      	mov	x17, #0x5e1c            ; =24092
     7cc:      	and	x11, x11, x17
     7d0:      	lsr	w11, w11, #0
     7d4:      	cmp	x11, #0x0
     7d8:      	b.eq	0xd60 <_stogir.verify.structure+0xbc0>
     7dc:      	cmp	x0, #0x0
     7e0:      	b.eq	0xaf0 <_stogir.verify.structure+0x950>
     7e4:      	ldr	x19, [sp, #0xd0]
     7e8:      	ldr	x0, [sp, #0xc8]
     7ec:      	ldr	x4, [sp, #0xc0]
     7f0:      	mov	x3, x7
     7f4:      	mov	x5, x9
     7f8:      	b	0xa7c <_stogir.verify.structure+0x8dc>
     7fc:      	lsr	w0, w19, #0
     800:      	cmp	x22, #0x78
     804:      	cset	w22, eq
     808:      	lsr	w0, w0, #0
     80c:      	cmp	x28, #0x0
     810:      	cset	w28, eq
     814:      	mov	x2, x1
     818:      	mov	x1, #0x1                ; =1
     81c:      	b	0x658 <_stogir.verify.structure+0x4b8>
     820:      	ldr	x1, [sp, #0x78]
     824:      	mov	x2, #0x1b               ; =27
     828:      	add	x0, x0, #0x1
     82c:      	cmp	x2, #0x0
     830:      	b.ne	0x850 <_stogir.verify.structure+0x6b0>
     834:      	cmp	x0, x21
     838:      	cset	w3, lt
     83c:      	ubfx	x3, x3, #0, #8
     840:      	fmov	d31, x2
     844:      	mov	x2, x3
     848:      	fmov	x3, d31
     84c:      	b	0x858 <_stogir.verify.structure+0x6b8>
     850:      	mov	x3, x2
     854:      	movz	x2, #0x0, lsl #48
     858:      	cmp	x2, #0x0
     85c:      	b.eq	0x7fc <_stogir.verify.structure+0x65c>
     860:      	add	x2, x0, x19
     864:      	ldr	x4, [x20, #0x78]
     868:      	lsl	x2, x2, #2
     86c:      	add	x2, x2, x4
     870:      	ldr	w2, [x2]
     874:      	sxtw	x2, w2
     878:      	cmn	x2, #0x1
     87c:      	b.ne	0x820 <_stogir.verify.structure+0x680>
     880:      	mov	x2, x3
     884:      	b	0x828 <_stogir.verify.structure+0x688>
     888:      	ldr	x0, [sp, #0xb0]
     88c:      	ldr	x1, [sp, #0xb8]
     890:      	add	x2, x24, #0x4
     894:      	ldr	x3, [x20, #0x8]
     898:      	asr	x16, x2, #63
     89c:      	lsr	x16, x16, #62
     8a0:      	add	x2, x2, x16
     8a4:      	asr	x2, x2, #2
     8a8:      	orr	x21, x2, xzr
     8ac:      	add	x2, x21, x19
     8b0:      	cmp	x2, x3
     8b4:      	b.le	0x8c0 <_stogir.verify.structure+0x720>
     8b8:      	ldr	x0, [sp, #0x70]
     8bc:      	mov	x1, #0x15               ; =21
     8c0:      	mov	x2, x1
     8c4:      	mov	x1, x0
     8c8:      	mov	x0, #0x1                ; =1
     8cc:      	b	0x82c <_stogir.verify.structure+0x68c>
     8d0:      	ldr	x2, [sp, #0xe0]
     8d4:      	ldr	x11, [x2, #0x8]
     8d8:      	cmp	x1, x11
     8dc:      	b.gt	0xd74 <_stogir.verify.structure+0xbd4>
     8e0:      	sub	x11, x1, #0x1
     8e4:      	ldr	x12, [sp, #0xd8]
     8e8:      	ldr	x13, [x12, #0x28]
     8ec:      	mov	x17, #0x18              ; =24
     8f0:      	mul	x11, x11, x17
     8f4:      	add	x11, x11, x13
     8f8:      	ldr	x13, [x11]
     8fc:      	ldr	x11, [x11, #0x8]
     900:      	ldr	x14, [x12, #0x8]
     904:      	cmp	x13, #0x0
     908:      	b.lt	0xa2c <_stogir.verify.structure+0x88c>
     90c:      	cmp	x13, x14
     910:      	b.gt	0xa2c <_stogir.verify.structure+0x88c>
     914:      	cmp	x11, #0x0
     918:      	b.lt	0xa2c <_stogir.verify.structure+0x88c>
     91c:      	sub	x13, x14, x13
     920:      	cmp	x11, x13
     924:      	b.gt	0xa2c <_stogir.verify.structure+0x88c>
     928:      	mov	x11, #0x1               ; =1
     92c:      	b	0xa30 <_stogir.verify.structure+0x890>
     930:      	uxtb	w16, w5
     934:      	cmp	w16, wzr
     938:      	b.eq	0x97c <_stogir.verify.structure+0x7dc>
     93c:      	ldr	x9, [x26, #0x8]
     940:      	ldr	x10, [x27, #0x8]
     944:      	cmp	x9, x10
     948:      	b.ne	0xa34 <_stogir.verify.structure+0x894>
     94c:      	cmp	x6, x9
     950:      	b.gt	0xb38 <_stogir.verify.structure+0x998>
     954:      	ldr	x9, [x20, #0x50]
     958:      	add	x9, x8, x9
     95c:      	ldr	w9, [x9]
     960:      	sxtw	x9, w9
     964:      	cmp	x9, #0x0
     968:      	cset	w9, gt
     96c:      	ubfx	x9, x9, #0, #8
     970:      	b	0xb3c <_stogir.verify.structure+0x99c>
     974:      	movz	x9, #0x0, lsl #48
     978:      	b	0x980 <_stogir.verify.structure+0x7e0>
     97c:      	movz	x9, #0x0, lsl #48
     980:      	cmp	x9, #0x0
     984:      	b.eq	0x9b4 <_stogir.verify.structure+0x814>
     988:      	uxtb	w16, w3
     98c:      	cmp	w16, wzr
     990:      	b.eq	0x9a4 <_stogir.verify.structure+0x804>
     994:      	lsl	x7, x1, #4
     998:      	ldr	x9, [x20]
     99c:      	add	x7, x7, x9
     9a0:      	b	0x9b0 <_stogir.verify.structure+0x810>
     9a4:      	lsl	x7, x7, #4
     9a8:      	ldr	x9, [x20, #0x28]
     9ac:      	add	x7, x7, x9
     9b0:      	b	0x9b8 <_stogir.verify.structure+0x818>
     9b4:      	movz	x7, #0x0, lsl #48
     9b8:      	cmp	x7, #0x0
     9bc:      	cset	w9, eq
     9c0:      	uxtb	w16, w9
     9c4:      	cmp	w16, wzr
     9c8:      	cset	x9, eq
     9cc:      	cmp	x9, #0x0
     9d0:      	b.eq	0x740 <_stogir.verify.structure+0x5a0>
     9d4:      	ldr	w7, [x7]
     9d8:      	uxtb	w7, w7
     9dc:      	cmp	x7, #0x48
     9e0:      	b.ne	0x740 <_stogir.verify.structure+0x5a0>
     9e4:      	ldr	x7, [sp, #0x88]
     9e8:      	mov	x10, #0x25              ; =37
     9ec:      	b	0x748 <_stogir.verify.structure+0x5a8>
     9f0:      	mov	w0, w23
     9f4:      	bl	0x9f4 <_stogir.verify.structure+0x854>
		00000000000009f4:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     9f8:      	lsr	w0, w0, #0
     9fc:      	sxtw	x0, w0
     a00:      	cmn	x0, #0x1
     a04:      	b.ne	0x888 <_stogir.verify.structure+0x6e8>
     a08:      	ubfx	x0, x21, #16, #16
     a0c:      	cmp	x24, x0
     a10:      	b.eq	0x888 <_stogir.verify.structure+0x6e8>
     a14:      	ldr	x0, [sp, #0x68]
     a18:      	mov	x1, #0x24               ; =36
     a1c:      	b	0x890 <_stogir.verify.structure+0x6f0>
     a20:      	mov	x0, x1
     a24:      	ldr	x1, [sp, #0x110]
     a28:      	b	0x570 <_stogir.verify.structure+0x3d0>
     a2c:      	movz	x11, #0x0, lsl #48
     a30:      	b	0x77c <_stogir.verify.structure+0x5dc>
     a34:      	movz	x9, #0x0, lsl #48
     a38:      	b	0x980 <_stogir.verify.structure+0x7e0>
     a3c:      	movz	x9, #0x0, lsl #48
     a40:      	b	0x978 <_stogir.verify.structure+0x7d8>
     a44:      	mov	x0, #0x1                ; =1
     a48:      	cmp	x0, #0x0
     a4c:      	b.eq	0xa20 <_stogir.verify.structure+0x880>
     a50:      	ldr	x0, [sp, #0x98]
     a54:      	mov	x1, #0x1a               ; =26
     a58:      	b	0xa28 <_stogir.verify.structure+0x888>
     a5c:      	movz	x0, #0x0, lsl #48
     a60:      	ldr	x1, [sp, #0x118]
     a64:      	cmp	x0, #0x0
     a68:      	b.eq	0xa44 <_stogir.verify.structure+0x8a4>
     a6c:      	movz	x0, #0x0, lsl #48
     a70:      	b	0xa48 <_stogir.verify.structure+0x8a8>
     a74:      	movz	x3, #0x0, lsl #48
     a78:      	mov	x5, x9
     a7c:      	cmp	x3, #0x0
     a80:      	b.eq	0xaa4 <_stogir.verify.structure+0x904>
     a84:      	str	x12, [sp, #0xd8]
     a88:      	str	x10, [sp, #0x110]
     a8c:      	str	x2, [sp, #0xe0]
     a90:      	str	x0, [sp, #0xc8]
     a94:      	str	x4, [sp, #0xc0]
     a98:      	mov	x1, x5
     a9c:      	mov	x0, #0x1                ; =1
     aa0:      	b	0xa64 <_stogir.verify.structure+0x8c4>
     aa4:      	cmp	x1, #0x0
     aa8:      	b.ne	0xd7c <_stogir.verify.structure+0xbdc>
     aac:      	mov	w1, w24
     ab0:      	str	x2, [sp, #0xe0]
     ab4:      	str	x12, [sp, #0xd8]
     ab8:      	str	x10, [sp, #0x110]
     abc:      	str	x0, [sp, #0xc8]
     ac0:      	ldr	w0, [sp, #0xf0]
     ac4:      	str	x4, [sp, #0xc0]
     ac8:      	str	x5, [sp, #0x118]
     acc:      	bl	0xacc <_stogir.verify.structure+0x92c>
		0000000000000acc:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     ad0:      	lsr	w0, w0, #0
     ad4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ad4:  ARM64_RELOC_PAGE21	l_stogir.319
     ad8:      	ldr	x16, [x16]
		0000000000000ad8:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     adc:      	ldr	w1, [x16]
     ae0:      	cmp	x0, x1
     ae4:      	b.ne	0xbb0 <_stogir.verify.structure+0xa10>
     ae8:      	mov	x0, #0x1                ; =1
     aec:      	b	0xb44 <_stogir.verify.structure+0x9a4>
     af0:      	uxtb	w16, w3
     af4:      	cmp	w16, wzr
     af8:      	b.eq	0xd98 <_stogir.verify.structure+0xbf8>
     afc:      	ldr	x0, [x20, #0x8]
     b00:      	cmp	x1, x0
     b04:      	b.ge	0xda0 <_stogir.verify.structure+0xc00>
     b08:      	ldr	x19, [sp, #0xd0]
     b0c:      	ldr	x0, [x19, #0x8]
     b10:      	cmp	x1, x0
     b14:      	b.ge	0xbd4 <_stogir.verify.structure+0xa34>
     b18:      	ldr	x0, [x20, #0x78]
     b1c:      	add	x0, x4, x0
     b20:      	ldr	w0, [x0]
     b24:      	sxtw	x0, w0
     b28:      	cmp	x0, #0x0
     b2c:      	cset	w0, ge
     b30:      	ubfx	x0, x0, #0, #8
     b34:      	b	0xbd8 <_stogir.verify.structure+0xa38>
     b38:      	movz	x9, #0x0, lsl #48
     b3c:      	b	0xa38 <_stogir.verify.structure+0x898>
     b40:      	movz	x0, #0x0, lsl #48
     b44:      	b	0xa60 <_stogir.verify.structure+0x8c0>
     b48:      	movz	x0, #0x0, lsl #48
     b4c:      	ldr	x4, [sp, #0xc0]
     b50:      	mov	x3, x0
     b54:      	ldr	x0, [sp, #0xc8]
     b58:      	b	0xa78 <_stogir.verify.structure+0x8d8>
     b5c:      	uxtb	w16, w5
     b60:      	cmp	w16, wzr
     b64:      	b.eq	0xda8 <_stogir.verify.structure+0xc08>
     b68:      	ldr	x0, [sp, #0xc8]
     b6c:      	ldr	x3, [x0, #0x8]
     b70:      	ldr	x4, [sp, #0xc0]
     b74:      	ldr	x5, [x4, #0x8]
     b78:      	cmp	x3, x5
     b7c:      	b.ne	0xbcc <_stogir.verify.structure+0xa2c>
     b80:      	cmp	x6, x3
     b84:      	b.gt	0xbf8 <_stogir.verify.structure+0xa58>
     b88:      	ldr	x3, [x20, #0x50]
     b8c:      	add	x3, x8, x3
     b90:      	ldr	w3, [x3]
     b94:      	sxtw	x3, w3
     b98:      	cmp	x3, #0x0
     b9c:      	cset	w3, gt
     ba0:      	ubfx	x3, x3, #0, #8
     ba4:      	b	0xbfc <_stogir.verify.structure+0xa5c>
     ba8:      	brk	#0
     bac:      	b	0xba8 <_stogir.verify.structure+0xa08>
     bb0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bb0:  ARM64_RELOC_PAGE21	l_stogir.320
     bb4:      	ldr	x16, [x16]
		0000000000000bb4:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     bb8:      	ldr	w1, [x16]
     bbc:      	cmp	x0, x1
     bc0:      	b.ne	0xbdc <_stogir.verify.structure+0xa3c>
     bc4:      	mov	x0, #0x1                ; =1
     bc8:      	b	0xb44 <_stogir.verify.structure+0x9a4>
     bcc:      	movz	x3, #0x0, lsl #48
     bd0:      	b	0xa78 <_stogir.verify.structure+0x8d8>
     bd4:      	movz	x0, #0x0, lsl #48
     bd8:      	b	0xb4c <_stogir.verify.structure+0x9ac>
     bdc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bdc:  ARM64_RELOC_PAGE21	l_stogir.321
     be0:      	ldr	x16, [x16]
		0000000000000be0:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     be4:      	ldr	w1, [x16]
     be8:      	cmp	x0, x1
     bec:      	b.ne	0xc00 <_stogir.verify.structure+0xa60>
     bf0:      	mov	x0, #0x1                ; =1
     bf4:      	b	0xb44 <_stogir.verify.structure+0x9a4>
     bf8:      	movz	x3, #0x0, lsl #48
     bfc:      	b	0xbd0 <_stogir.verify.structure+0xa30>
     c00:      	uxtb	w16, w22
     c04:      	cmp	w16, wzr
     c08:      	b.eq	0xb40 <_stogir.verify.structure+0x9a0>
     c0c:      	uxtb	w16, w28
     c10:      	cmp	w16, wzr
     c14:      	b.eq	0xc34 <_stogir.verify.structure+0xa94>
     c18:      	sxtw	x24, w24
     c1c:      	cmp	x24, #0x2
     c20:      	cset	w0, eq
     c24:      	ubfx	x0, x0, #0, #8
     c28:      	b	0xc38 <_stogir.verify.structure+0xa98>
     c2c:      	brk	#0
     c30:      	b	0xc2c <_stogir.verify.structure+0xa8c>
     c34:      	movz	x0, #0x0, lsl #48
     c38:      	b	0xb44 <_stogir.verify.structure+0x9a4>
     c3c:      	mov	x1, x2
     c40:      	str	x8, [sp, #0xa0]
     c44:      	str	x12, [sp, #0xb0]
     c48:      	str	x13, [sp, #0xb8]
     c4c:      	b	0x4f4 <_stogir.verify.structure+0x354>
     c50:      	mov	x1, x2
     c54:      	str	x8, [sp, #0xa0]
     c58:      	str	x12, [sp, #0xb0]
     c5c:      	str	x13, [sp, #0xb8]
     c60:      	b	0x4f4 <_stogir.verify.structure+0x354>
     c64:      	mov	x1, x2
     c68:      	str	x8, [sp, #0xa0]
     c6c:      	str	x19, [sp, #0x50]
     c70:      	str	x20, [sp, #0x58]
     c74:      	mov	x20, x0
     c78:      	ldr	x0, [sp, #0x30]
     c7c:      	str	x21, [sp, #0x60]
     c80:      	str	x22, [sp, #0x68]
     c84:      	str	x23, [sp, #0x70]
     c88:      	str	x24, [sp, #0x78]
     c8c:      	str	x25, [sp, #0x80]
     c90:      	str	x26, [sp, #0x88]
     c94:      	str	x27, [sp, #0x90]
     c98:      	str	x28, [sp, #0x98]
     c9c:      	str	x3, [sp, #0xd8]
     ca0:      	str	x11, [sp, #0xe0]
     ca4:      	mov	x19, x4
     ca8:      	str	x5, [sp, #0xc8]
     cac:      	str	x6, [sp, #0xc0]
     cb0:      	mov	x25, x7
     cb4:      	mov	x26, x9
     cb8:      	mov	x27, x10
     cbc:      	b	0x348 <_stogir.verify.structure+0x1a8>
     cc0:      	ldr	x0, [sp, #0x30]
     cc4:      	mov	x1, x2
     cc8:      	str	x8, [sp, #0xa0]
     ccc:      	str	x19, [sp, #0x50]
     cd0:      	str	x20, [sp, #0x58]
     cd4:      	ldr	x20, [sp, #0x38]
     cd8:      	str	x21, [sp, #0x60]
     cdc:      	str	x22, [sp, #0x68]
     ce0:      	str	x23, [sp, #0x70]
     ce4:      	str	x24, [sp, #0x78]
     ce8:      	str	x25, [sp, #0x80]
     cec:      	str	x26, [sp, #0x88]
     cf0:      	str	x27, [sp, #0x90]
     cf4:      	str	x28, [sp, #0x98]
     cf8:      	str	x3, [sp, #0xd8]
     cfc:      	str	x11, [sp, #0xe0]
     d00:      	mov	x19, x4
     d04:      	str	x5, [sp, #0xc8]
     d08:      	str	x6, [sp, #0xc0]
     d0c:      	mov	x25, x7
     d10:      	mov	x26, x9
     d14:      	mov	x27, x10
     d18:      	b	0x2e0 <_stogir.verify.structure+0x140>
     d1c:      	mov	x0, x19
     d20:      	ldr	x1, [sp, #0xa8]
     d24:      	ldr	x19, [sp, #0xd0]
     d28:      	b	0x2e0 <_stogir.verify.structure+0x140>
     d2c:      	str	x19, [sp, #0x30]
     d30:      	str	x4, [sp, #0x100]
     d34:      	str	x3, [sp, #0xf8]
     d38:      	ldr	x19, [sp, #0xd0]
     d3c:      	b	0x200 <_stogir.verify.structure+0x60>
     d40:      	ldr	x12, [sp, #0xd8]
     d44:      	ldr	x2, [sp, #0xe0]
     d48:      	b	0x7b4 <_stogir.verify.structure+0x614>
     d4c:      	str	x12, [sp, #0xd8]
     d50:      	str	x10, [sp, #0x110]
     d54:      	str	x2, [sp, #0xe0]
     d58:      	ldr	x19, [sp, #0xd0]
     d5c:      	b	0x568 <_stogir.verify.structure+0x3c8>
     d60:      	str	x12, [sp, #0xd8]
     d64:      	str	x10, [sp, #0x110]
     d68:      	str	x2, [sp, #0xe0]
     d6c:      	ldr	x19, [sp, #0xd0]
     d70:      	b	0x568 <_stogir.verify.structure+0x3c8>
     d74:      	ldr	x12, [sp, #0xd8]
     d78:      	b	0x778 <_stogir.verify.structure+0x5d8>
     d7c:      	str	x12, [sp, #0xd8]
     d80:      	str	x5, [sp, #0x118]
     d84:      	str	x10, [sp, #0x110]
     d88:      	str	x2, [sp, #0xe0]
     d8c:      	str	x0, [sp, #0xc8]
     d90:      	str	x4, [sp, #0xc0]
     d94:      	b	0xa5c <_stogir.verify.structure+0x8bc>
     d98:      	ldr	x19, [sp, #0xd0]
     d9c:      	b	0xb5c <_stogir.verify.structure+0x9bc>
     da0:      	ldr	x19, [sp, #0xd0]
     da4:      	b	0xb48 <_stogir.verify.structure+0x9a8>
     da8:      	ldr	x0, [sp, #0xc8]
     dac:      	ldr	x4, [sp, #0xc0]
     db0:      	b	0xa74 <_stogir.verify.structure+0x8d4>

0000000000000db4 <_stogir.verify.integer-operations-target-structured>:
     db4:      	sub	sp, sp, #0x4a0
     db8:      	str	x29, [sp, #0x10]
     dbc:      	str	x30, [sp, #0x18]
     dc0:      	add	x29, sp, #0x10
     dc4:      	str	x19, [sp, #0x450]
     dc8:      	str	x20, [sp, #0x458]
     dcc:      	str	x21, [sp, #0x460]
     dd0:      	str	x22, [sp, #0x468]
     dd4:      	str	x23, [sp, #0x470]
     dd8:      	str	x24, [sp, #0x478]
     ddc:      	str	x25, [sp, #0x480]
     de0:      	str	x26, [sp, #0x488]
     de4:      	str	x27, [sp, #0x490]
     de8:      	str	x28, [sp, #0x498]
     dec:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000dec:  ARM64_RELOC_PAGE21	l_stogir.322
     df0:      	ldr	x16, [x16]
		0000000000000df0:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     df4:      	orr	x2, x16, xzr
     df8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000df8:  ARM64_RELOC_PAGE21	l_stogir.323
     dfc:      	ldr	x16, [x16]
		0000000000000dfc:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     e00:      	orr	x19, x16, xzr
     e04:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e04:  ARM64_RELOC_PAGE21	l_stogir.324
     e08:      	ldr	x16, [x16]
		0000000000000e08:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     e0c:      	orr	x20, x16, xzr
     e10:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e10:  ARM64_RELOC_PAGE21	l_stogir.325
     e14:      	ldr	x16, [x16]
		0000000000000e14:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     e18:      	orr	x21, x16, xzr
     e1c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e1c:  ARM64_RELOC_PAGE21	l_stogir.326
     e20:      	ldr	x16, [x16]
		0000000000000e20:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     e24:      	orr	x22, x16, xzr
     e28:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e28:  ARM64_RELOC_PAGE21	l_stogir.327
     e2c:      	ldr	x16, [x16]
		0000000000000e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     e30:      	orr	x23, x16, xzr
     e34:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e34:  ARM64_RELOC_PAGE21	l_stogir.328
     e38:      	ldr	x16, [x16]
		0000000000000e38:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     e3c:      	orr	x24, x16, xzr
     e40:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e40:  ARM64_RELOC_PAGE21	l_stogir.329
     e44:      	ldr	x16, [x16]
		0000000000000e44:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     e48:      	orr	x25, x16, xzr
     e4c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e4c:  ARM64_RELOC_PAGE21	l_stogir.330
     e50:      	ldr	x16, [x16]
		0000000000000e50:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     e54:      	orr	x26, x16, xzr
     e58:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e58:  ARM64_RELOC_PAGE21	l_stogir.331
     e5c:      	ldr	x16, [x16]
		0000000000000e5c:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     e60:      	orr	x27, x16, xzr
     e64:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e64:  ARM64_RELOC_PAGE21	l_stogir.332
     e68:      	ldr	x16, [x16]
		0000000000000e68:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     e6c:      	orr	x28, x16, xzr
     e70:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e70:  ARM64_RELOC_PAGE21	l_stogir.333
     e74:      	ldr	x16, [x16]
		0000000000000e74:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     e78:      	orr	x3, x16, xzr
     e7c:      	lsr	w4, w1, #0
     e80:      	lsr	w5, w1, #0
     e84:      	lsr	w1, w1, #0
     e88:      	add	x16, sp, #0x20
     e8c:      	orr	x6, x16, xzr
     e90:      	add	x16, sp, #0x30
     e94:      	orr	x7, x16, xzr
     e98:      	add	x7, x7, #0x8
     e9c:      	add	x16, sp, #0x50
     ea0:      	orr	x9, x16, xzr
     ea4:      	add	x9, x9, #0x8
     ea8:      	add	x16, sp, #0xe0
     eac:      	orr	x10, x16, xzr
     eb0:      	add	x10, x10, #0x8
     eb4:      	add	x16, sp, #0x100
     eb8:      	orr	x11, x16, xzr
     ebc:      	add	x11, x11, #0x8
     ec0:      	add	x16, sp, #0x120
     ec4:      	orr	x12, x16, xzr
     ec8:      	add	x12, x12, #0x8
     ecc:      	add	x16, sp, #0x140
     ed0:      	orr	x13, x16, xzr
     ed4:      	add	x13, x13, #0x8
     ed8:      	add	x16, sp, #0x160
     edc:      	orr	x14, x16, xzr
     ee0:      	add	x14, x14, #0x8
     ee4:      	add	x16, sp, #0x180
     ee8:      	orr	x15, x16, xzr
     eec:      	add	x15, x15, #0x8
     ef0:      	str	w1, [sp, #0x230]
     ef4:      	add	x16, sp, #0x1a0
     ef8:      	orr	x1, x16, xzr
     efc:      	add	x1, x1, #0x8
     f00:      	str	x1, [sp, #0x238]
     f04:      	add	x16, sp, #0x1f0
     f08:      	orr	x1, x16, xzr
     f0c:      	add	x1, x1, #0x8
     f10:      	str	x19, [sp, #0x240]
     f14:      	str	x20, [sp, #0x250]
     f18:      	str	x2, [sp, #0x248]
     f1c:      	mov	x2, #0x1                ; =1
     f20:      	movz	x19, #0x0, lsl #48
     f24:      	movz	x20, #0x0, lsl #48
     f28:      	cmp	x20, #0x0
     f2c:      	b.ne	0x2210 <_stogir.verify.integer-operations-target-structured+0x145c>
     f30:      	str	x1, [sp, #0x258]
     f34:      	ldr	x1, [x0, #0x8]
     f38:      	cmp	x2, x1
     f3c:      	b.ge	0x221c <_stogir.verify.integer-operations-target-structured+0x1468>
     f40:      	lsl	x1, x2, #4
     f44:      	str	x3, [sp, #0x260]
     f48:      	lsl	x3, x2, #2
     f4c:      	str	w4, [sp, #0x268]
     f50:      	ldr	x4, [x0]
     f54:      	add	x1, x1, x4
     f58:      	ldr	x4, [x1]
     f5c:      	str	x21, [sp, #0x270]
     f60:      	uxtb	w21, w4
     f64:      	ldr	x1, [x1, #0x8]
     f68:      	str	x22, [sp, #0x278]
     f6c:      	orr	x22, x21, xzr
     f70:      	add	x16, sp, #0x20
     f74:      	str	x4, [x16]
     f78:      	add	x16, sp, #0x20
     f7c:      	str	x1, [x16, #0x8]
     f80:      	ldr	x1, [x0, #0x78]
     f84:      	add	x1, x3, x1
     f88:      	ldr	w1, [x1]
     f8c:      	cmp	x22, #0xe
     f90:      	b.lt	0x17a8 <_stogir.verify.integer-operations-target-structured+0x9f4>
     f94:      	cmp	x22, #0x17
     f98:      	cset	w3, le
     f9c:      	ubfx	x3, x3, #0, #8
     fa0:      	cmp	x22, #0x1a
     fa4:      	cset	w4, ge
     fa8:      	str	x23, [sp, #0x280]
     fac:      	cmp	x22, #0x1e
     fb0:      	cset	w23, le
     fb4:      	str	x24, [sp, #0x288]
     fb8:      	cmp	x22, #0x2e
     fbc:      	cset	w24, ge
     fc0:      	str	x25, [sp, #0x290]
     fc4:      	cmp	x22, #0x35
     fc8:      	cset	w25, le
     fcc:      	str	x26, [sp, #0x298]
     fd0:      	cmp	x22, #0x3a
     fd4:      	cset	w26, eq
     fd8:      	str	x27, [sp, #0x2a0]
     fdc:      	cmp	x22, #0x3b
     fe0:      	cset	w27, eq
     fe4:      	uxtb	w16, w4
     fe8:      	cmp	w16, wzr
     fec:      	b.eq	0x17b0 <_stogir.verify.integer-operations-target-structured+0x9fc>
     ff0:      	uxtb	w16, w23
     ff4:      	cmp	w16, wzr
     ff8:      	b.eq	0x17b0 <_stogir.verify.integer-operations-target-structured+0x9fc>
     ffc:      	str	x0, [sp, #0x2a8]
    1000:      	mov	x0, #0x1                ; =1
    1004:      	cmp	x22, #0x1f
    1008:      	b.ne	0x17f8 <_stogir.verify.integer-operations-target-structured+0xa44>
    100c:      	str	x0, [sp, #0x2b0]
    1010:      	mov	x0, #0x1                ; =1
    1014:      	str	x0, [sp, #0x2b8]
    1018:      	lsr	w0, w2, #0
    101c:      	lsr	w1, w1, #0
    1020:      	lsr	w0, w0, #0
    1024:      	str	x8, [sp, #0x2c8]
    1028:      	str	w5, [sp, #0x2d0]
    102c:      	str	x6, [sp, #0x2d8]
    1030:      	str	x15, [sp, #0x318]
    1034:      	str	x2, [sp, #0x320]
    1038:      	mov	x2, x6
    103c:      	str	w1, [sp, #0x328]
    1040:      	str	x3, [sp, #0x330]
    1044:      	mov	w3, w1
    1048:      	mov	w1, w0
    104c:      	str	w4, [sp, #0x338]
    1050:      	str	w0, [sp, #0x340]
    1054:      	ldr	x0, [sp, #0x2a8]
    1058:      	str	x28, [sp, #0x2c0]
    105c:      	ldr	x28, [sp, #0x260]
    1060:      	str	x20, [sp, #0x2e0]
    1064:      	mov	x20, x7
    1068:      	str	w27, [sp, #0x2e8]
    106c:      	mov	x27, x9
    1070:      	str	w26, [sp, #0x2f0]
    1074:      	mov	x26, x10
    1078:      	str	w25, [sp, #0x2f8]
    107c:      	mov	x25, x11
    1080:      	str	w24, [sp, #0x300]
    1084:      	mov	x24, x12
    1088:      	str	w23, [sp, #0x308]
    108c:      	mov	x23, x13
    1090:      	str	w21, [sp, #0x310]
    1094:      	mov	x21, x14
    1098:      	bl	0x1098 <_stogir.verify.integer-operations-target-structured+0x2e4>
		0000000000001098:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    109c:      	uxtb	w1, w0
    10a0:      	cmp	x1, #0x0
    10a4:      	cset	w1, ne
    10a8:      	cmp	x22, #0x3d
    10ac:      	b.lt	0x1870 <_stogir.verify.integer-operations-target-structured+0xabc>
    10b0:      	cmp	x22, #0x3f
    10b4:      	b.gt	0x1870 <_stogir.verify.integer-operations-target-structured+0xabc>
    10b8:      	add	x8, sp, #0x30
    10bc:      	ldr	w2, [sp, #0x268]
    10c0:      	str	x0, [sp, #0x348]
    10c4:      	ldr	x0, [sp, #0x2a8]
    10c8:      	str	x21, [sp, #0x350]
    10cc:      	mov	w21, w1
    10d0:      	ldr	w1, [sp, #0x340]
    10d4:      	bl	0x10d4 <_stogir.verify.integer-operations-target-structured+0x320>
		00000000000010d4:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    10d8:      	add	x16, sp, #0x30
    10dc:      	ldr	w0, [x16]
    10e0:      	lsr	x16, x0, #0
    10e4:      	cmp	x16, #0x1
    10e8:      	b.eq	0x1104 <_stogir.verify.integer-operations-target-structured+0x350>
    10ec:      	b.lo	0x10f4 <_stogir.verify.integer-operations-target-structured+0x340>
    10f0:      	b	0x1108 <_stogir.verify.integer-operations-target-structured+0x354>
    10f4:      	cmp	x16, #0x0
    10f8:      	b.eq	0x1100 <_stogir.verify.integer-operations-target-structured+0x34c>
    10fc:      	b	0x1108 <_stogir.verify.integer-operations-target-structured+0x354>
    1100:      	b	0x1894 <_stogir.verify.integer-operations-target-structured+0xae0>
    1104:      	b	0x110c <_stogir.verify.integer-operations-target-structured+0x358>
    1108:      	b	0x2194 <_stogir.verify.integer-operations-target-structured+0x13e0>
    110c:      	add	x16, sp, #0x30
    1110:      	ldr	x0, [x16, #0x8]
    1114:      	ldr	x1, [x20, #0x8]
    1118:      	mov	x2, x1
    111c:      	mov	x1, x0
    1120:      	mov	x0, x19
    1124:      	mov	x19, x0
    1128:      	mov	x0, x1
    112c:      	mov	x1, x2
    1130:      	cmp	x22, #0x44
    1134:      	b.ne	0x18b8 <_stogir.verify.integer-operations-target-structured+0xb04>
    1138:      	uxtb	w16, w21
    113c:      	cmp	w16, wzr
    1140:      	b.eq	0x18ac <_stogir.verify.integer-operations-target-structured+0xaf8>
    1144:      	mov	x2, x0
    1148:      	movz	x0, #0x0, lsl #48
    114c:      	fmov	d31, x1
    1150:      	mov	x1, x2
    1154:      	fmov	x2, d31
    1158:      	cmp	x0, #0x0
    115c:      	b.eq	0x2228 <_stogir.verify.integer-operations-target-structured+0x1474>
    1160:      	add	x8, sp, #0x50
    1164:      	ldr	x0, [sp, #0x2a8]
    1168:      	str	x1, [sp, #0x358]
    116c:      	ldr	w1, [sp, #0x340]
    1170:      	str	x2, [sp, #0x360]
    1174:      	bl	0x1174 <_stogir.verify.integer-operations-target-structured+0x3c0>
		0000000000001174:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    1178:      	add	x16, sp, #0x50
    117c:      	ldr	w0, [x16]
    1180:      	lsr	x16, x0, #0
    1184:      	cmp	x16, #0x1
    1188:      	b.eq	0x11a4 <_stogir.verify.integer-operations-target-structured+0x3f0>
    118c:      	b.lo	0x1194 <_stogir.verify.integer-operations-target-structured+0x3e0>
    1190:      	b	0x11a8 <_stogir.verify.integer-operations-target-structured+0x3f4>
    1194:      	cmp	x16, #0x0
    1198:      	b.eq	0x11a0 <_stogir.verify.integer-operations-target-structured+0x3ec>
    119c:      	b	0x11a8 <_stogir.verify.integer-operations-target-structured+0x3f4>
    11a0:      	b	0x18c8 <_stogir.verify.integer-operations-target-structured+0xb14>
    11a4:      	b	0x11ac <_stogir.verify.integer-operations-target-structured+0x3f8>
    11a8:      	b	0x18e0 <_stogir.verify.integer-operations-target-structured+0xb2c>
    11ac:      	add	x16, sp, #0x50
    11b0:      	ldr	x0, [x16, #0x8]
    11b4:      	ldr	x1, [x27, #0x8]
    11b8:      	mov	x2, x1
    11bc:      	mov	x1, x0
    11c0:      	mov	x0, x19
    11c4:      	mov	x19, x0
    11c8:      	mov	x0, x1
    11cc:      	mov	x1, x2
    11d0:      	cmp	x22, #0x1d
    11d4:      	b.ne	0x18f4 <_stogir.verify.integer-operations-target-structured+0xb40>
    11d8:      	mov	x2, x1
    11dc:      	mov	x1, x0
    11e0:      	mov	x0, #0x1                ; =1
    11e4:      	cmp	x0, #0x0
    11e8:      	b.eq	0x191c <_stogir.verify.integer-operations-target-structured+0xb68>
    11ec:      	add	x16, sp, #0x20
    11f0:      	ldr	w0, [x16, #0xc]
    11f4:      	sxtw	x0, w0
    11f8:      	cmp	x0, #0x0
    11fc:      	b.ne	0x1914 <_stogir.verify.integer-operations-target-structured+0xb60>
    1200:      	movz	x0, #0x0, lsl #48
    1204:      	cmp	x0, #0x0
    1208:      	b.eq	0x2234 <_stogir.verify.integer-operations-target-structured+0x1480>
    120c:      	add	x16, sp, #0x20
    1210:      	ldr	w0, [x16, #0xc]
    1214:      	lsr	w0, w0, #0
    1218:      	add	x8, sp, #0x70
    121c:      	str	x1, [sp, #0x368]
    1220:      	mov	w1, w0
    1224:      	ldr	x0, [sp, #0x2a8]
    1228:      	str	x2, [sp, #0x370]
    122c:      	bl	0x122c <_stogir.verify.integer-operations-target-structured+0x478>
		000000000000122c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1230:      	add	x16, sp, #0x70
    1234:      	ldr	w0, [x16]
    1238:      	lsr	x16, x0, #0
    123c:      	cmp	x16, #0x1
    1240:      	b.eq	0x125c <_stogir.verify.integer-operations-target-structured+0x4a8>
    1244:      	b.lo	0x124c <_stogir.verify.integer-operations-target-structured+0x498>
    1248:      	b	0x1260 <_stogir.verify.integer-operations-target-structured+0x4ac>
    124c:      	cmp	x16, #0x0
    1250:      	b.eq	0x1258 <_stogir.verify.integer-operations-target-structured+0x4a4>
    1254:      	b	0x1260 <_stogir.verify.integer-operations-target-structured+0x4ac>
    1258:      	b	0x1264 <_stogir.verify.integer-operations-target-structured+0x4b0>
    125c:      	b	0x1924 <_stogir.verify.integer-operations-target-structured+0xb70>
    1260:      	b	0x19d8 <_stogir.verify.integer-operations-target-structured+0xc24>
    1264:      	ldr	x0, [sp, #0x240]
    1268:      	mov	x1, #0x16               ; =22
    126c:      	cmp	x22, #0x2c
    1270:      	cset	w2, eq
    1274:      	cmp	x22, #0x29
    1278:      	b.lt	0x19ec <_stogir.verify.integer-operations-target-structured+0xc38>
    127c:      	cmp	x22, #0x2b
    1280:      	b.gt	0x19ec <_stogir.verify.integer-operations-target-structured+0xc38>
    1284:      	uxtb	w16, w2
    1288:      	cmp	w16, wzr
    128c:      	b.eq	0x2240 <_stogir.verify.integer-operations-target-structured+0x148c>
    1290:      	add	x8, sp, #0xa0
    1294:      	str	x0, [sp, #0x378]
    1298:      	ldr	x0, [sp, #0x2a8]
    129c:      	str	x1, [sp, #0x380]
    12a0:      	ldr	w1, [sp, #0x340]
    12a4:      	bl	0x12a4 <_stogir.verify.integer-operations-target-structured+0x4f0>
		00000000000012a4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    12a8:      	add	x16, sp, #0xa0
    12ac:      	ldr	x0, [x16]
    12b0:      	add	x16, sp, #0xa0
    12b4:      	ldr	x1, [x16, #0x8]
    12b8:      	add	x16, sp, #0xa0
    12bc:      	ldr	x2, [x16, #0x10]
    12c0:      	lsr	w0, w0, #0
    12c4:      	lsr	x16, x0, #0
    12c8:      	cmp	x16, #0x1
    12cc:      	b.eq	0x12e8 <_stogir.verify.integer-operations-target-structured+0x534>
    12d0:      	b.lo	0x12d8 <_stogir.verify.integer-operations-target-structured+0x524>
    12d4:      	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x538>
    12d8:      	cmp	x16, #0x0
    12dc:      	b.eq	0x12e4 <_stogir.verify.integer-operations-target-structured+0x530>
    12e0:      	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x538>
    12e4:      	b	0x1a28 <_stogir.verify.integer-operations-target-structured+0xc74>
    12e8:      	b	0x12f0 <_stogir.verify.integer-operations-target-structured+0x53c>
    12ec:      	b	0x218c <_stogir.verify.integer-operations-target-structured+0x13d8>
    12f0:      	mov	x0, x19
    12f4:      	mov	x19, x0
    12f8:      	mov	x0, x1
    12fc:      	mov	x1, x2
    1300:      	cmp	x22, #0x7e
    1304:      	b.lt	0x224c <_stogir.verify.integer-operations-target-structured+0x1498>
    1308:      	cmp	x22, #0x82
    130c:      	b.gt	0x2258 <_stogir.verify.integer-operations-target-structured+0x14a4>
    1310:      	add	x8, sp, #0xe0
    1314:      	str	x0, [sp, #0x388]
    1318:      	ldr	x0, [sp, #0x2a8]
    131c:      	str	x1, [sp, #0x390]
    1320:      	ldr	w1, [sp, #0x340]
    1324:      	bl	0x1324 <_stogir.verify.integer-operations-target-structured+0x570>
		0000000000001324:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    1328:      	add	x16, sp, #0xe0
    132c:      	ldr	w0, [x16]
    1330:      	lsr	x16, x0, #0
    1334:      	cmp	x16, #0x1
    1338:      	b.eq	0x1354 <_stogir.verify.integer-operations-target-structured+0x5a0>
    133c:      	b.lo	0x1344 <_stogir.verify.integer-operations-target-structured+0x590>
    1340:      	b	0x1358 <_stogir.verify.integer-operations-target-structured+0x5a4>
    1344:      	cmp	x16, #0x0
    1348:      	b.eq	0x1350 <_stogir.verify.integer-operations-target-structured+0x59c>
    134c:      	b	0x1358 <_stogir.verify.integer-operations-target-structured+0x5a4>
    1350:      	b	0x1a40 <_stogir.verify.integer-operations-target-structured+0xc8c>
    1354:      	b	0x135c <_stogir.verify.integer-operations-target-structured+0x5a8>
    1358:      	b	0x1a58 <_stogir.verify.integer-operations-target-structured+0xca4>
    135c:      	add	x16, sp, #0xe0
    1360:      	ldr	x0, [x16, #0x8]
    1364:      	ldr	x1, [x26, #0x8]
    1368:      	mov	x2, x1
    136c:      	mov	x1, x0
    1370:      	mov	x0, x19
    1374:      	mov	x19, x0
    1378:      	mov	x0, x1
    137c:      	mov	x1, x2
    1380:      	cmp	x22, #0x60
    1384:      	b.eq	0x1a6c <_stogir.verify.integer-operations-target-structured+0xcb8>
    1388:      	cmp	x22, #0x79
    138c:      	b.eq	0x1a6c <_stogir.verify.integer-operations-target-structured+0xcb8>
    1390:      	cmp	x22, #0x75
    1394:      	b.eq	0x1af8 <_stogir.verify.integer-operations-target-structured+0xd44>
    1398:      	cmp	x22, #0x6d
    139c:      	b.lt	0x2264 <_stogir.verify.integer-operations-target-structured+0x14b0>
    13a0:      	cmp	x22, #0x6f
    13a4:      	b.le	0x1af8 <_stogir.verify.integer-operations-target-structured+0xd44>
    13a8:      	str	x0, [sp, #0x3a8]
    13ac:      	str	x1, [sp, #0x3b0]
    13b0:      	ldr	x0, [sp, #0x3a8]
    13b4:      	ldr	x1, [sp, #0x3b0]
    13b8:      	cmp	x22, #0x42
    13bc:      	b.eq	0x1b8c <_stogir.verify.integer-operations-target-structured+0xdd8>
    13c0:      	cmp	x22, #0x51
    13c4:      	b.eq	0x1b8c <_stogir.verify.integer-operations-target-structured+0xdd8>
    13c8:      	cmp	x22, #0x52
    13cc:      	b.eq	0x1b8c <_stogir.verify.integer-operations-target-structured+0xdd8>
    13d0:      	cmp	x22, #0x53
    13d4:      	b.eq	0x1b8c <_stogir.verify.integer-operations-target-structured+0xdd8>
    13d8:      	cmp	x22, #0x54
    13dc:      	b.eq	0x1b8c <_stogir.verify.integer-operations-target-structured+0xdd8>
    13e0:      	cmp	x22, #0x41
    13e4:      	b.eq	0x1c18 <_stogir.verify.integer-operations-target-structured+0xe64>
    13e8:      	cmp	x22, #0x48
    13ec:      	b.eq	0x1c18 <_stogir.verify.integer-operations-target-structured+0xe64>
    13f0:      	cmp	x22, #0x55
    13f4:      	b.lt	0x2270 <_stogir.verify.integer-operations-target-structured+0x14bc>
    13f8:      	cmp	x22, #0x58
    13fc:      	b.le	0x1c18 <_stogir.verify.integer-operations-target-structured+0xe64>
    1400:      	str	x0, [sp, #0x3c8]
    1404:      	str	x1, [sp, #0x3d0]
    1408:      	ldr	x1, [sp, #0x350]
    140c:      	ldr	x0, [sp, #0x3c8]
    1410:      	ldr	x2, [sp, #0x3d0]
    1414:      	cmp	x22, #0x21
    1418:      	b.lt	0x2280 <_stogir.verify.integer-operations-target-structured+0x14cc>
    141c:      	cmp	x22, #0x27
    1420:      	b.gt	0x2294 <_stogir.verify.integer-operations-target-structured+0x14e0>
    1424:      	add	x8, sp, #0x180
    1428:      	str	x1, [sp, #0x350]
    142c:      	ldr	w1, [sp, #0x340]
    1430:      	str	x0, [sp, #0x3d8]
    1434:      	ldr	x0, [sp, #0x2a8]
    1438:      	str	x2, [sp, #0x3e0]
    143c:      	ldr	w2, [sp, #0x230]
    1440:      	bl	0x1440 <_stogir.verify.integer-operations-target-structured+0x68c>
		0000000000001440:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    1444:      	add	x16, sp, #0x180
    1448:      	ldr	w0, [x16]
    144c:      	lsr	x16, x0, #0
    1450:      	cmp	x16, #0x1
    1454:      	b.eq	0x1474 <_stogir.verify.integer-operations-target-structured+0x6c0>
    1458:      	b.lo	0x1460 <_stogir.verify.integer-operations-target-structured+0x6ac>
    145c:      	b	0x1478 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1460:      	cmp	x16, #0x0
    1464:      	b.eq	0x146c <_stogir.verify.integer-operations-target-structured+0x6b8>
    1468:      	b	0x1478 <_stogir.verify.integer-operations-target-structured+0x6c4>
    146c:      	ldr	x1, [sp, #0x318]
    1470:      	b	0x1cb8 <_stogir.verify.integer-operations-target-structured+0xf04>
    1474:      	b	0x147c <_stogir.verify.integer-operations-target-structured+0x6c8>
    1478:      	b	0x1cd0 <_stogir.verify.integer-operations-target-structured+0xf1c>
    147c:      	add	x16, sp, #0x180
    1480:      	ldr	x0, [x16, #0x8]
    1484:      	ldr	x1, [sp, #0x318]
    1488:      	ldr	x2, [x1, #0x8]
    148c:      	mov	x3, x2
    1490:      	mov	x2, x0
    1494:      	mov	x0, x19
    1498:      	mov	x19, x0
    149c:      	mov	x0, x2
    14a0:      	mov	x2, x3
    14a4:      	cmp	x22, #0x3c
    14a8:      	b.ne	0x22a8 <_stogir.verify.integer-operations-target-structured+0x14f4>
    14ac:      	add	x8, sp, #0x1a0
    14b0:      	str	x1, [sp, #0x318]
    14b4:      	ldr	w1, [sp, #0x340]
    14b8:      	str	x0, [sp, #0x3e8]
    14bc:      	ldr	x0, [sp, #0x2a8]
    14c0:      	str	x2, [sp, #0x3f0]
    14c4:      	bl	0x14c4 <_stogir.verify.integer-operations-target-structured+0x710>
		00000000000014c4:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    14c8:      	add	x16, sp, #0x1a0
    14cc:      	ldr	w0, [x16]
    14d0:      	lsr	x16, x0, #0
    14d4:      	cmp	x16, #0x1
    14d8:      	b.eq	0x14f8 <_stogir.verify.integer-operations-target-structured+0x744>
    14dc:      	b.lo	0x14e4 <_stogir.verify.integer-operations-target-structured+0x730>
    14e0:      	b	0x14fc <_stogir.verify.integer-operations-target-structured+0x748>
    14e4:      	cmp	x16, #0x0
    14e8:      	b.eq	0x14f0 <_stogir.verify.integer-operations-target-structured+0x73c>
    14ec:      	b	0x14fc <_stogir.verify.integer-operations-target-structured+0x748>
    14f0:      	ldr	x1, [sp, #0x238]
    14f4:      	b	0x1ce4 <_stogir.verify.integer-operations-target-structured+0xf30>
    14f8:      	b	0x1500 <_stogir.verify.integer-operations-target-structured+0x74c>
    14fc:      	b	0x1cfc <_stogir.verify.integer-operations-target-structured+0xf48>
    1500:      	add	x16, sp, #0x1a0
    1504:      	ldr	x0, [x16, #0x8]
    1508:      	ldr	x1, [sp, #0x238]
    150c:      	ldr	x2, [x1, #0x8]
    1510:      	mov	x3, x2
    1514:      	mov	x2, x0
    1518:      	mov	x0, x19
    151c:      	mov	x19, x0
    1520:      	mov	x0, x2
    1524:      	mov	x2, x3
    1528:      	cmp	x22, #0x78
    152c:      	b.ne	0x22bc <_stogir.verify.integer-operations-target-structured+0x1508>
    1530:      	add	x16, sp, #0x20
    1534:      	ldr	w3, [x16]
    1538:      	ubfx	x3, x3, #8, #8
    153c:      	cmp	x3, #0x0
    1540:      	b.ne	0x1d10 <_stogir.verify.integer-operations-target-structured+0xf5c>
    1544:      	add	x16, sp, #0x20
    1548:      	ldr	w3, [x16, #0x8]
    154c:      	sxtw	x3, w3
    1550:      	cmp	x3, #0x0
    1554:      	b.eq	0x1560 <_stogir.verify.integer-operations-target-structured+0x7ac>
    1558:      	ldr	x0, [sp, #0x270]
    155c:      	mov	x2, #0x1f               ; =31
    1560:      	str	x1, [sp, #0x238]
    1564:      	mov	x1, x2
    1568:      	add	x2, x19, #0x1
    156c:      	lsr	w2, w2, #0
    1570:      	sxtw	x2, w2
    1574:      	mov	x19, x2
    1578:      	ldr	x2, [sp, #0x348]
    157c:      	uxth	w2, w2
    1580:      	mov	w17, #0x8               ; =8
    1584:      	uxth	w16, w2
    1588:      	ubfx	w17, w17, #0, #4
    158c:      	lsr	w2, w16, w17
    1590:      	uxth	w2, w2
    1594:      	uxtb	w2, w2
    1598:      	cmp	x2, #0x0
    159c:      	b.eq	0x22cc <_stogir.verify.integer-operations-target-structured+0x1518>
    15a0:      	add	x8, sp, #0x1f0
    15a4:      	str	x0, [sp, #0x408]
    15a8:      	ldr	x0, [sp, #0x2a8]
    15ac:      	str	x1, [sp, #0x410]
    15b0:      	ldr	w1, [sp, #0x340]
    15b4:      	str	x20, [sp, #0x418]
    15b8:      	mov	x20, x2
    15bc:      	bl	0x15bc <_stogir.verify.integer-operations-target-structured+0x808>
		00000000000015bc:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    15c0:      	add	x16, sp, #0x1f0
    15c4:      	ldr	w0, [x16]
    15c8:      	lsr	x16, x0, #0
    15cc:      	cmp	x16, #0x1
    15d0:      	b.eq	0x15f0 <_stogir.verify.integer-operations-target-structured+0x83c>
    15d4:      	b.lo	0x15dc <_stogir.verify.integer-operations-target-structured+0x828>
    15d8:      	b	0x15f4 <_stogir.verify.integer-operations-target-structured+0x840>
    15dc:      	cmp	x16, #0x0
    15e0:      	b.eq	0x15e8 <_stogir.verify.integer-operations-target-structured+0x834>
    15e4:      	b	0x15f4 <_stogir.verify.integer-operations-target-structured+0x840>
    15e8:      	ldr	x1, [sp, #0x258]
    15ec:      	b	0x1dc8 <_stogir.verify.integer-operations-target-structured+0x1014>
    15f0:      	b	0x15f8 <_stogir.verify.integer-operations-target-structured+0x844>
    15f4:      	b	0x1de0 <_stogir.verify.integer-operations-target-structured+0x102c>
    15f8:      	add	x16, sp, #0x1f0
    15fc:      	ldr	x0, [x16, #0x8]
    1600:      	ldr	x1, [sp, #0x258]
    1604:      	ldr	x2, [x1, #0x8]
    1608:      	mov	x3, x2
    160c:      	mov	x2, x0
    1610:      	mov	x0, x19
    1614:      	mov	x19, x0
    1618:      	mov	x0, x2
    161c:      	mov	x2, x3
    1620:      	uxtb	w16, w21
    1624:      	cmp	w16, wzr
    1628:      	b.eq	0x1df4 <_stogir.verify.integer-operations-target-structured+0x1040>
    162c:      	mov	x3, x2
    1630:      	mov	x2, x0
    1634:      	movz	x0, #0x0, lsl #48
    1638:      	cmp	x0, #0x0
    163c:      	b.eq	0x22e4 <_stogir.verify.integer-operations-target-structured+0x1530>
    1640:      	cmp	x20, #0x0
    1644:      	b.eq	0x1e04 <_stogir.verify.integer-operations-target-structured+0x1050>
    1648:      	movz	x0, #0x0, lsl #48
    164c:      	cmp	x0, #0x0
    1650:      	b.eq	0x22f0 <_stogir.verify.integer-operations-target-structured+0x153c>
    1654:      	ldr	x20, [sp, #0x330]
    1658:      	cmp	x20, #0x0
    165c:      	b.eq	0x1e0c <_stogir.verify.integer-operations-target-structured+0x1058>
    1660:      	ldr	x21, [sp, #0x2b0]
    1664:      	mov	x0, #0x1                ; =1
    1668:      	cmp	x0, #0x0
    166c:      	b.eq	0x22fc <_stogir.verify.integer-operations-target-structured+0x1548>
    1670:      	add	x16, sp, #0x210
    1674:      	str	x16, [sp]
    1678:      	ldr	x0, [sp, #0x2a8]
    167c:      	str	x1, [sp, #0x258]
    1680:      	ldr	w1, [sp, #0x340]
    1684:      	str	x2, [sp, #0x420]
    1688:      	str	x3, [sp, #0x428]
    168c:      	mov	x2, #0x1                ; =1
    1690:      	bl	0x1690 <_stogir.verify.integer-operations-target-structured+0x8dc>
		0000000000001690:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1694:      	ldr	x16, [sp]
    1698:      	str	x0, [x16]
    169c:      	str	x1, [x16, #0x8]
    16a0:      	add	x16, sp, #0x210
    16a4:      	ldr	x0, [x16]
    16a8:      	add	x16, sp, #0x210
    16ac:      	ldr	x1, [x16, #0x8]
    16b0:      	lsr	w0, w0, #0
    16b4:      	lsr	x16, x0, #0
    16b8:      	cmp	x16, #0x1
    16bc:      	b.eq	0x16d8 <_stogir.verify.integer-operations-target-structured+0x924>
    16c0:      	b.lo	0x16c8 <_stogir.verify.integer-operations-target-structured+0x914>
    16c4:      	b	0x16dc <_stogir.verify.integer-operations-target-structured+0x928>
    16c8:      	cmp	x16, #0x0
    16cc:      	b.eq	0x16d4 <_stogir.verify.integer-operations-target-structured+0x920>
    16d0:      	b	0x16dc <_stogir.verify.integer-operations-target-structured+0x928>
    16d4:      	b	0x16e0 <_stogir.verify.integer-operations-target-structured+0x92c>
    16d8:      	b	0x1e38 <_stogir.verify.integer-operations-target-structured+0x1084>
    16dc:      	b	0x2164 <_stogir.verify.integer-operations-target-structured+0x13b0>
    16e0:      	str	x26, [sp, #0x448]
    16e4:      	str	x25, [sp, #0x440]
    16e8:      	str	x24, [sp, #0x438]
    16ec:      	str	x23, [sp, #0x430]
    16f0:      	ldr	x0, [sp, #0x288]
    16f4:      	mov	x1, #0x17               ; =23
    16f8:      	add	x2, x19, #0x1
    16fc:      	lsr	w2, w2, #0
    1700:      	sxtw	x2, w2
    1704:      	fmov	d31, x0
    1708:      	mov	x0, x2
    170c:      	mov	x2, x1
    1710:      	fmov	x1, d31
    1714:      	ldr	w3, [sp, #0x328]
    1718:      	sxtw	x3, w3
    171c:      	add	x3, x3, #0x4
    1720:      	asr	x16, x3, #63
    1724:      	lsr	x16, x16, #62
    1728:      	add	x3, x3, x16
    172c:      	asr	x3, x3, #2
    1730:      	ldr	x4, [sp, #0x320]
    1734:      	add	x3, x3, x4
    1738:      	ldr	x8, [sp, #0x2c8]
    173c:      	ldr	x6, [sp, #0x2d8]
    1740:      	ldr	x21, [sp, #0x270]
    1744:      	ldr	x22, [sp, #0x278]
    1748:      	ldr	x23, [sp, #0x280]
    174c:      	ldr	x24, [sp, #0x288]
    1750:      	ldr	x25, [sp, #0x290]
    1754:      	ldr	x26, [sp, #0x298]
    1758:      	ldr	w4, [sp, #0x268]
    175c:      	ldr	x7, [sp, #0x418]
    1760:      	mov	x9, x27
    1764:      	ldr	x27, [sp, #0x2a0]
    1768:      	ldr	x10, [sp, #0x448]
    176c:      	ldr	x11, [sp, #0x440]
    1770:      	ldr	x12, [sp, #0x438]
    1774:      	ldr	x13, [sp, #0x430]
    1778:      	ldr	w5, [sp, #0x2d0]
    177c:      	ldr	x14, [sp, #0x350]
    1780:      	ldr	x15, [sp, #0x318]
    1784:      	mov	x19, x0
    1788:      	ldr	x0, [sp, #0x2a8]
    178c:      	str	x1, [sp, #0x248]
    1790:      	ldr	x1, [sp, #0x258]
    1794:      	mov	x20, x2
    1798:      	mov	x2, x3
    179c:      	mov	x3, x28
    17a0:      	ldr	x28, [sp, #0x2c0]
    17a4:      	b	0xf28 <_stogir.verify.integer-operations-target-structured+0x174>
    17a8:      	movz	x3, #0x0, lsl #48
    17ac:      	b	0xfa0 <_stogir.verify.integer-operations-target-structured+0x1ec>
    17b0:      	uxtb	w16, w24
    17b4:      	cmp	w16, wzr
    17b8:      	b.eq	0x17d4 <_stogir.verify.integer-operations-target-structured+0xa20>
    17bc:      	uxtb	w16, w25
    17c0:      	cmp	w16, wzr
    17c4:      	b.eq	0x17d4 <_stogir.verify.integer-operations-target-structured+0xa20>
    17c8:      	str	x0, [sp, #0x2a8]
    17cc:      	mov	x0, #0x1                ; =1
    17d0:      	b	0x1004 <_stogir.verify.integer-operations-target-structured+0x250>
    17d4:      	uxtb	w16, w26
    17d8:      	cmp	w16, wzr
    17dc:      	b.eq	0x17ec <_stogir.verify.integer-operations-target-structured+0xa38>
    17e0:      	str	x0, [sp, #0x2a8]
    17e4:      	mov	x0, #0x1                ; =1
    17e8:      	b	0x17d0 <_stogir.verify.integer-operations-target-structured+0xa1c>
    17ec:      	str	x0, [sp, #0x2a8]
    17f0:      	ubfx	x0, x27, #0, #8
    17f4:      	b	0x17e8 <_stogir.verify.integer-operations-target-structured+0xa34>
    17f8:      	cmp	x22, #0x20
    17fc:      	b.ne	0x180c <_stogir.verify.integer-operations-target-structured+0xa58>
    1800:      	str	x0, [sp, #0x2b0]
    1804:      	mov	x0, #0x1                ; =1
    1808:      	b	0x1014 <_stogir.verify.integer-operations-target-structured+0x260>
    180c:      	cmp	x22, #0x2d
    1810:      	b.ne	0x1820 <_stogir.verify.integer-operations-target-structured+0xa6c>
    1814:      	str	x0, [sp, #0x2b0]
    1818:      	mov	x0, #0x1                ; =1
    181c:      	b	0x1808 <_stogir.verify.integer-operations-target-structured+0xa54>
    1820:      	cmp	x22, #0x36
    1824:      	b.ne	0x1834 <_stogir.verify.integer-operations-target-structured+0xa80>
    1828:      	str	x0, [sp, #0x2b0]
    182c:      	mov	x0, #0x1                ; =1
    1830:      	b	0x181c <_stogir.verify.integer-operations-target-structured+0xa68>
    1834:      	cmp	x22, #0x37
    1838:      	b.ne	0x1848 <_stogir.verify.integer-operations-target-structured+0xa94>
    183c:      	str	x0, [sp, #0x2b0]
    1840:      	mov	x0, #0x1                ; =1
    1844:      	b	0x1830 <_stogir.verify.integer-operations-target-structured+0xa7c>
    1848:      	cmp	x22, #0x38
    184c:      	b.ne	0x185c <_stogir.verify.integer-operations-target-structured+0xaa8>
    1850:      	str	x0, [sp, #0x2b0]
    1854:      	mov	x0, #0x1                ; =1
    1858:      	b	0x1844 <_stogir.verify.integer-operations-target-structured+0xa90>
    185c:      	str	x0, [sp, #0x2b0]
    1860:      	cmp	x22, #0x39
    1864:      	cset	w0, eq
    1868:      	ubfx	x0, x0, #0, #8
    186c:      	b	0x1858 <_stogir.verify.integer-operations-target-structured+0xaa4>
    1870:      	uxtb	w16, w1
    1874:      	cmp	w16, wzr
    1878:      	b.ne	0x10b8 <_stogir.verify.integer-operations-target-structured+0x304>
    187c:      	str	x0, [sp, #0x348]
    1880:      	str	x21, [sp, #0x350]
    1884:      	mov	w21, w1
    1888:      	ldr	x0, [sp, #0x248]
    188c:      	ldr	x1, [sp, #0x2e0]
    1890:      	b	0x1130 <_stogir.verify.integer-operations-target-structured+0x37c>
    1894:      	add	x0, x19, #0x1
    1898:      	lsr	w0, w0, #0
    189c:      	sxtw	x0, w0
    18a0:      	ldr	x1, [sp, #0x248]
    18a4:      	ldr	x2, [sp, #0x2e0]
    18a8:      	b	0x1124 <_stogir.verify.integer-operations-target-structured+0x370>
    18ac:      	mov	x2, x0
    18b0:      	mov	x0, #0x1                ; =1
    18b4:      	b	0x114c <_stogir.verify.integer-operations-target-structured+0x398>
    18b8:      	mov	x2, x1
    18bc:      	mov	x1, x0
    18c0:      	movz	x0, #0x0, lsl #48
    18c4:      	b	0x1158 <_stogir.verify.integer-operations-target-structured+0x3a4>
    18c8:      	add	x0, x19, #0x1
    18cc:      	lsr	w0, w0, #0
    18d0:      	sxtw	x0, w0
    18d4:      	ldr	x1, [sp, #0x358]
    18d8:      	ldr	x2, [sp, #0x360]
    18dc:      	b	0x11c4 <_stogir.verify.integer-operations-target-structured+0x410>
    18e0:      	brk	#0
    18e4:      	b	0x18e0 <_stogir.verify.integer-operations-target-structured+0xb2c>
    18e8:      	ldr	x0, [sp, #0x358]
    18ec:      	ldr	x1, [sp, #0x360]
    18f0:      	b	0x11d0 <_stogir.verify.integer-operations-target-structured+0x41c>
    18f4:      	cmp	x22, #0x1e
    18f8:      	cset	w2, eq
    18fc:      	ubfx	x2, x2, #0, #8
    1900:      	fmov	d31, x0
    1904:      	mov	x0, x2
    1908:      	mov	x2, x1
    190c:      	fmov	x1, d31
    1910:      	b	0x11e4 <_stogir.verify.integer-operations-target-structured+0x430>
    1914:      	mov	x0, #0x1                ; =1
    1918:      	b	0x1204 <_stogir.verify.integer-operations-target-structured+0x450>
    191c:      	movz	x0, #0x0, lsl #48
    1920:      	b	0x1204 <_stogir.verify.integer-operations-target-structured+0x450>
    1924:      	add	x16, sp, #0x70
    1928:      	ldr	x0, [x16, #0x8]
    192c:      	add	x16, sp, #0x20
    1930:      	ldr	w1, [x16, #0xc]
    1934:      	sxtw	x1, w1
    1938:      	cmp	x1, #0x0
    193c:      	b.ge	0x1960 <_stogir.verify.integer-operations-target-structured+0xbac>
    1940:      	ldr	x1, [sp, #0x368]
    1944:      	ldr	x2, [sp, #0x370]
    1948:      	mov	x0, #0x1                ; =1
    194c:      	cmp	x0, #0x0
    1950:      	b.eq	0x19cc <_stogir.verify.integer-operations-target-structured+0xc18>
    1954:      	ldr	x0, [sp, #0x250]
    1958:      	mov	x1, #0x2d               ; =45
    195c:      	b	0x126c <_stogir.verify.integer-operations-target-structured+0x4b8>
    1960:      	uxtb	w0, w0
    1964:      	cmp	x0, #0x83
    1968:      	b.ge	0x19bc <_stogir.verify.integer-operations-target-structured+0xc08>
    196c:      	add	x1, x0, x28
    1970:      	ldrb	w1, [x1]
    1974:      	uxtb	w1, w1
    1978:      	and	x1, x1, #0x2
    197c:      	uxtb	w1, w1
    1980:      	cmp	x1, #0x0
    1984:      	cset	w1, eq
    1988:      	uxtb	w16, w1
    198c:      	cmp	w16, wzr
    1990:      	cset	x1, eq
    1994:      	cmp	x1, #0x0
    1998:      	b.ne	0x19c4 <_stogir.verify.integer-operations-target-structured+0xc10>
    199c:      	cmp	x0, #0x65
    19a0:      	b.eq	0x19c4 <_stogir.verify.integer-operations-target-structured+0xc10>
    19a4:      	cmp	x0, #0x66
    19a8:      	b.eq	0x19c4 <_stogir.verify.integer-operations-target-structured+0xc10>
    19ac:      	mov	x0, #0x1                ; =1
    19b0:      	ldr	x1, [sp, #0x368]
    19b4:      	ldr	x2, [sp, #0x370]
    19b8:      	b	0x194c <_stogir.verify.integer-operations-target-structured+0xb98>
    19bc:      	movz	x1, #0x0, lsl #48
    19c0:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xbc0>
    19c4:      	movz	x0, #0x0, lsl #48
    19c8:      	b	0x19b0 <_stogir.verify.integer-operations-target-structured+0xbfc>
    19cc:      	mov	x0, x1
    19d0:      	mov	x1, x2
    19d4:      	b	0x195c <_stogir.verify.integer-operations-target-structured+0xba8>
    19d8:      	brk	#0
    19dc:      	b	0x19d8 <_stogir.verify.integer-operations-target-structured+0xc24>
    19e0:      	ldr	x0, [sp, #0x368]
    19e4:      	ldr	x1, [sp, #0x370]
    19e8:      	b	0x126c <_stogir.verify.integer-operations-target-structured+0x4b8>
    19ec:      	uxtb	w16, w2
    19f0:      	cmp	w16, wzr
    19f4:      	b.ne	0x1284 <_stogir.verify.integer-operations-target-structured+0x4d0>
    19f8:      	b	0x1300 <_stogir.verify.integer-operations-target-structured+0x54c>
    19fc:      	add	x8, sp, #0xc0
    1a00:      	ldr	x0, [sp, #0x2a8]
    1a04:      	ldr	w1, [sp, #0x340]
    1a08:      	bl	0x1a08 <_stogir.verify.integer-operations-target-structured+0xc54>
		0000000000001a08:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1a0c:      	add	x16, sp, #0xc0
    1a10:      	ldr	x0, [x16]
    1a14:      	add	x16, sp, #0xc0
    1a18:      	ldr	x1, [x16, #0x8]
    1a1c:      	add	x16, sp, #0xc0
    1a20:      	ldr	x2, [x16, #0x10]
    1a24:      	b	0x12c0 <_stogir.verify.integer-operations-target-structured+0x50c>
    1a28:      	add	x0, x19, #0x1
    1a2c:      	lsr	w0, w0, #0
    1a30:      	sxtw	x0, w0
    1a34:      	ldr	x1, [sp, #0x378]
    1a38:      	ldr	x2, [sp, #0x380]
    1a3c:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x540>
    1a40:      	add	x0, x19, #0x1
    1a44:      	lsr	w0, w0, #0
    1a48:      	sxtw	x0, w0
    1a4c:      	ldr	x1, [sp, #0x388]
    1a50:      	ldr	x2, [sp, #0x390]
    1a54:      	b	0x1374 <_stogir.verify.integer-operations-target-structured+0x5c0>
    1a58:      	brk	#0
    1a5c:      	b	0x1a58 <_stogir.verify.integer-operations-target-structured+0xca4>
    1a60:      	ldr	x0, [sp, #0x388]
    1a64:      	ldr	x1, [sp, #0x390]
    1a68:      	b	0x1380 <_stogir.verify.integer-operations-target-structured+0x5cc>
    1a6c:      	add	x8, sp, #0x100
    1a70:      	str	x0, [sp, #0x398]
    1a74:      	ldr	x0, [sp, #0x2a8]
    1a78:      	str	x1, [sp, #0x3a0]
    1a7c:      	ldr	w1, [sp, #0x340]
    1a80:      	bl	0x1a80 <_stogir.verify.integer-operations-target-structured+0xccc>
		0000000000001a80:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    1a84:      	add	x16, sp, #0x100
    1a88:      	ldr	w0, [x16]
    1a8c:      	lsr	x16, x0, #0
    1a90:      	cmp	x16, #0x1
    1a94:      	b.eq	0x1ab0 <_stogir.verify.integer-operations-target-structured+0xcfc>
    1a98:      	b.lo	0x1aa0 <_stogir.verify.integer-operations-target-structured+0xcec>
    1a9c:      	b	0x1ab4 <_stogir.verify.integer-operations-target-structured+0xd00>
    1aa0:      	cmp	x16, #0x0
    1aa4:      	b.eq	0x1aac <_stogir.verify.integer-operations-target-structured+0xcf8>
    1aa8:      	b	0x1ab4 <_stogir.verify.integer-operations-target-structured+0xd00>
    1aac:      	b	0x1ae0 <_stogir.verify.integer-operations-target-structured+0xd2c>
    1ab0:      	b	0x1ab8 <_stogir.verify.integer-operations-target-structured+0xd04>
    1ab4:      	b	0x2184 <_stogir.verify.integer-operations-target-structured+0x13d0>
    1ab8:      	add	x16, sp, #0x100
    1abc:      	ldr	x0, [x16, #0x8]
    1ac0:      	ldr	x1, [x25, #0x8]
    1ac4:      	mov	x2, x1
    1ac8:      	mov	x1, x0
    1acc:      	mov	x0, x19
    1ad0:      	mov	x19, x0
    1ad4:      	mov	x0, x1
    1ad8:      	mov	x1, x2
    1adc:      	b	0x1390 <_stogir.verify.integer-operations-target-structured+0x5dc>
    1ae0:      	add	x0, x19, #0x1
    1ae4:      	lsr	w0, w0, #0
    1ae8:      	sxtw	x0, w0
    1aec:      	ldr	x1, [sp, #0x398]
    1af0:      	ldr	x2, [sp, #0x3a0]
    1af4:      	b	0x1ad0 <_stogir.verify.integer-operations-target-structured+0xd1c>
    1af8:      	add	x8, sp, #0x120
    1afc:      	str	x0, [sp, #0x3a8]
    1b00:      	ldr	x0, [sp, #0x2a8]
    1b04:      	str	x1, [sp, #0x3b0]
    1b08:      	ldr	w1, [sp, #0x340]
    1b0c:      	bl	0x1b0c <_stogir.verify.integer-operations-target-structured+0xd58>
		0000000000001b0c:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    1b10:      	add	x16, sp, #0x120
    1b14:      	ldr	w0, [x16]
    1b18:      	lsr	x16, x0, #0
    1b1c:      	cmp	x16, #0x1
    1b20:      	b.eq	0x1b3c <_stogir.verify.integer-operations-target-structured+0xd88>
    1b24:      	b.lo	0x1b2c <_stogir.verify.integer-operations-target-structured+0xd78>
    1b28:      	b	0x1b40 <_stogir.verify.integer-operations-target-structured+0xd8c>
    1b2c:      	cmp	x16, #0x0
    1b30:      	b.eq	0x1b38 <_stogir.verify.integer-operations-target-structured+0xd84>
    1b34:      	b	0x1b40 <_stogir.verify.integer-operations-target-structured+0xd8c>
    1b38:      	b	0x1b6c <_stogir.verify.integer-operations-target-structured+0xdb8>
    1b3c:      	b	0x1b44 <_stogir.verify.integer-operations-target-structured+0xd90>
    1b40:      	b	0x1b84 <_stogir.verify.integer-operations-target-structured+0xdd0>
    1b44:      	add	x16, sp, #0x120
    1b48:      	ldr	x0, [x16, #0x8]
    1b4c:      	ldr	x1, [x24, #0x8]
    1b50:      	mov	x2, x1
    1b54:      	mov	x1, x0
    1b58:      	mov	x0, x19
    1b5c:      	mov	x19, x0
    1b60:      	mov	x0, x1
    1b64:      	mov	x1, x2
    1b68:      	b	0x13b8 <_stogir.verify.integer-operations-target-structured+0x604>
    1b6c:      	add	x0, x19, #0x1
    1b70:      	lsr	w0, w0, #0
    1b74:      	sxtw	x0, w0
    1b78:      	ldr	x1, [sp, #0x3a8]
    1b7c:      	ldr	x2, [sp, #0x3b0]
    1b80:      	b	0x1b5c <_stogir.verify.integer-operations-target-structured+0xda8>
    1b84:      	brk	#0
    1b88:      	b	0x1b84 <_stogir.verify.integer-operations-target-structured+0xdd0>
    1b8c:      	add	x8, sp, #0x140
    1b90:      	str	x0, [sp, #0x3b8]
    1b94:      	ldr	x0, [sp, #0x2a8]
    1b98:      	str	x1, [sp, #0x3c0]
    1b9c:      	ldr	w1, [sp, #0x340]
    1ba0:      	bl	0x1ba0 <_stogir.verify.integer-operations-target-structured+0xdec>
		0000000000001ba0:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    1ba4:      	add	x16, sp, #0x140
    1ba8:      	ldr	w0, [x16]
    1bac:      	lsr	x16, x0, #0
    1bb0:      	cmp	x16, #0x1
    1bb4:      	b.eq	0x1bd0 <_stogir.verify.integer-operations-target-structured+0xe1c>
    1bb8:      	b.lo	0x1bc0 <_stogir.verify.integer-operations-target-structured+0xe0c>
    1bbc:      	b	0x1bd4 <_stogir.verify.integer-operations-target-structured+0xe20>
    1bc0:      	cmp	x16, #0x0
    1bc4:      	b.eq	0x1bcc <_stogir.verify.integer-operations-target-structured+0xe18>
    1bc8:      	b	0x1bd4 <_stogir.verify.integer-operations-target-structured+0xe20>
    1bcc:      	b	0x1c00 <_stogir.verify.integer-operations-target-structured+0xe4c>
    1bd0:      	b	0x1bd8 <_stogir.verify.integer-operations-target-structured+0xe24>
    1bd4:      	b	0x217c <_stogir.verify.integer-operations-target-structured+0x13c8>
    1bd8:      	add	x16, sp, #0x140
    1bdc:      	ldr	x0, [x16, #0x8]
    1be0:      	ldr	x1, [x23, #0x8]
    1be4:      	mov	x2, x1
    1be8:      	mov	x1, x0
    1bec:      	mov	x0, x19
    1bf0:      	mov	x19, x0
    1bf4:      	mov	x0, x1
    1bf8:      	mov	x1, x2
    1bfc:      	b	0x13e0 <_stogir.verify.integer-operations-target-structured+0x62c>
    1c00:      	add	x0, x19, #0x1
    1c04:      	lsr	w0, w0, #0
    1c08:      	sxtw	x0, w0
    1c0c:      	ldr	x1, [sp, #0x3b8]
    1c10:      	ldr	x2, [sp, #0x3c0]
    1c14:      	b	0x1bf0 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1c18:      	add	x8, sp, #0x160
    1c1c:      	ldr	w2, [sp, #0x2d0]
    1c20:      	str	x0, [sp, #0x3c8]
    1c24:      	ldr	x0, [sp, #0x2a8]
    1c28:      	str	x1, [sp, #0x3d0]
    1c2c:      	ldr	w1, [sp, #0x340]
    1c30:      	bl	0x1c30 <_stogir.verify.integer-operations-target-structured+0xe7c>
		0000000000001c30:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1c34:      	add	x16, sp, #0x160
    1c38:      	ldr	w0, [x16]
    1c3c:      	lsr	x16, x0, #0
    1c40:      	cmp	x16, #0x1
    1c44:      	b.eq	0x1c64 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1c48:      	b.lo	0x1c50 <_stogir.verify.integer-operations-target-structured+0xe9c>
    1c4c:      	b	0x1c68 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1c50:      	cmp	x16, #0x0
    1c54:      	b.eq	0x1c5c <_stogir.verify.integer-operations-target-structured+0xea8>
    1c58:      	b	0x1c68 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1c5c:      	ldr	x1, [sp, #0x350]
    1c60:      	b	0x1c98 <_stogir.verify.integer-operations-target-structured+0xee4>
    1c64:      	b	0x1c6c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1c68:      	b	0x1cb0 <_stogir.verify.integer-operations-target-structured+0xefc>
    1c6c:      	add	x16, sp, #0x160
    1c70:      	ldr	x0, [x16, #0x8]
    1c74:      	ldr	x1, [sp, #0x350]
    1c78:      	ldr	x2, [x1, #0x8]
    1c7c:      	mov	x3, x2
    1c80:      	mov	x2, x0
    1c84:      	mov	x0, x19
    1c88:      	mov	x19, x0
    1c8c:      	mov	x0, x2
    1c90:      	mov	x2, x3
    1c94:      	b	0x1414 <_stogir.verify.integer-operations-target-structured+0x660>
    1c98:      	add	x0, x19, #0x1
    1c9c:      	lsr	w0, w0, #0
    1ca0:      	sxtw	x0, w0
    1ca4:      	ldr	x2, [sp, #0x3c8]
    1ca8:      	ldr	x3, [sp, #0x3d0]
    1cac:      	b	0x1c88 <_stogir.verify.integer-operations-target-structured+0xed4>
    1cb0:      	brk	#0
    1cb4:      	b	0x1cb0 <_stogir.verify.integer-operations-target-structured+0xefc>
    1cb8:      	add	x0, x19, #0x1
    1cbc:      	lsr	w0, w0, #0
    1cc0:      	sxtw	x0, w0
    1cc4:      	ldr	x2, [sp, #0x3d8]
    1cc8:      	ldr	x3, [sp, #0x3e0]
    1ccc:      	b	0x1498 <_stogir.verify.integer-operations-target-structured+0x6e4>
    1cd0:      	brk	#0
    1cd4:      	b	0x1cd0 <_stogir.verify.integer-operations-target-structured+0xf1c>
    1cd8:      	ldr	x0, [sp, #0x3d8]
    1cdc:      	ldr	x2, [sp, #0x3e0]
    1ce0:      	b	0x14a4 <_stogir.verify.integer-operations-target-structured+0x6f0>
    1ce4:      	add	x0, x19, #0x1
    1ce8:      	lsr	w0, w0, #0
    1cec:      	sxtw	x0, w0
    1cf0:      	ldr	x2, [sp, #0x3e8]
    1cf4:      	ldr	x3, [sp, #0x3f0]
    1cf8:      	b	0x151c <_stogir.verify.integer-operations-target-structured+0x768>
    1cfc:      	brk	#0
    1d00:      	b	0x1cfc <_stogir.verify.integer-operations-target-structured+0xf48>
    1d04:      	ldr	x0, [sp, #0x3e8]
    1d08:      	ldr	x2, [sp, #0x3f0]
    1d0c:      	b	0x1528 <_stogir.verify.integer-operations-target-structured+0x774>
    1d10:      	add	x16, sp, #0x20
    1d14:      	ldr	w3, [x16, #0x8]
    1d18:      	lsr	w3, w3, #0
    1d1c:      	add	x8, sp, #0x1c0
    1d20:      	str	x1, [sp, #0x238]
    1d24:      	mov	w1, w3
    1d28:      	str	x0, [sp, #0x3f8]
    1d2c:      	ldr	x0, [sp, #0x2a8]
    1d30:      	str	x2, [sp, #0x400]
    1d34:      	bl	0x1d34 <_stogir.verify.integer-operations-target-structured+0xf80>
		0000000000001d34:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1d38:      	add	x16, sp, #0x1c0
    1d3c:      	ldr	w0, [x16]
    1d40:      	lsr	x16, x0, #0
    1d44:      	cmp	x16, #0x1
    1d48:      	b.eq	0x1d64 <_stogir.verify.integer-operations-target-structured+0xfb0>
    1d4c:      	b.lo	0x1d54 <_stogir.verify.integer-operations-target-structured+0xfa0>
    1d50:      	b	0x1d68 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1d54:      	cmp	x16, #0x0
    1d58:      	b.eq	0x1d60 <_stogir.verify.integer-operations-target-structured+0xfac>
    1d5c:      	b	0x1d68 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1d60:      	b	0x1d6c <_stogir.verify.integer-operations-target-structured+0xfb8>
    1d64:      	b	0x1d78 <_stogir.verify.integer-operations-target-structured+0xfc4>
    1d68:      	b	0x1db4 <_stogir.verify.integer-operations-target-structured+0x1000>
    1d6c:      	ldr	x0, [sp, #0x278]
    1d70:      	mov	x1, #0x14               ; =20
    1d74:      	b	0x1568 <_stogir.verify.integer-operations-target-structured+0x7b4>
    1d78:      	add	x16, sp, #0x1c0
    1d7c:      	ldr	x0, [x16, #0x8]
    1d80:      	add	x16, sp, #0x20
    1d84:      	ldr	w1, [x16]
    1d88:      	lsr	w0, w0, #0
    1d8c:      	ubfx	x1, x1, #8, #8
    1d90:      	ubfx	x0, x0, #8, #8
    1d94:      	cmp	x0, x1
    1d98:      	b.ne	0x1da8 <_stogir.verify.integer-operations-target-structured+0xff4>
    1d9c:      	ldr	x0, [sp, #0x3f8]
    1da0:      	ldr	x1, [sp, #0x400]
    1da4:      	b	0x1d74 <_stogir.verify.integer-operations-target-structured+0xfc0>
    1da8:      	ldr	x0, [sp, #0x280]
    1dac:      	mov	x1, #0x1a               ; =26
    1db0:      	b	0x1da4 <_stogir.verify.integer-operations-target-structured+0xff0>
    1db4:      	brk	#0
    1db8:      	b	0x1db4 <_stogir.verify.integer-operations-target-structured+0x1000>
    1dbc:      	ldr	x0, [sp, #0x3f8]
    1dc0:      	ldr	x1, [sp, #0x400]
    1dc4:      	b	0x1578 <_stogir.verify.integer-operations-target-structured+0x7c4>
    1dc8:      	add	x0, x19, #0x1
    1dcc:      	lsr	w0, w0, #0
    1dd0:      	sxtw	x0, w0
    1dd4:      	ldr	x2, [sp, #0x408]
    1dd8:      	ldr	x3, [sp, #0x410]
    1ddc:      	b	0x1614 <_stogir.verify.integer-operations-target-structured+0x860>
    1de0:      	brk	#0
    1de4:      	b	0x1de0 <_stogir.verify.integer-operations-target-structured+0x102c>
    1de8:      	ldr	x0, [sp, #0x408]
    1dec:      	ldr	x2, [sp, #0x410]
    1df0:      	b	0x1620 <_stogir.verify.integer-operations-target-structured+0x86c>
    1df4:      	mov	x3, x2
    1df8:      	mov	x2, x0
    1dfc:      	mov	x0, #0x1                ; =1
    1e00:      	b	0x1638 <_stogir.verify.integer-operations-target-structured+0x884>
    1e04:      	mov	x0, #0x1                ; =1
    1e08:      	b	0x164c <_stogir.verify.integer-operations-target-structured+0x898>
    1e0c:      	ldr	x21, [sp, #0x2b0]
    1e10:      	cmp	x21, #0x0
    1e14:      	b.eq	0x1e20 <_stogir.verify.integer-operations-target-structured+0x106c>
    1e18:      	mov	x0, #0x1                ; =1
    1e1c:      	b	0x1668 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e20:      	ldr	x0, [sp, #0x2b8]
    1e24:      	b	0x1e1c <_stogir.verify.integer-operations-target-structured+0x1068>
    1e28:      	movz	x0, #0x0, lsl #48
    1e2c:      	b	0x1668 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e30:      	movz	x0, #0x0, lsl #48
    1e34:      	b	0x1668 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e38:      	lsr	w1, w1, #0
    1e3c:      	lsr	w1, w1, #0
    1e40:      	ldr	x0, [sp, #0x2a8]
    1e44:      	bl	0x1e44 <_stogir.verify.integer-operations-target-structured+0x1090>
		0000000000001e44:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1e48:      	cmp	x0, #0x0
    1e4c:      	b.ne	0x1e6c <_stogir.verify.integer-operations-target-structured+0x10b8>
    1e50:      	str	x26, [sp, #0x448]
    1e54:      	str	x25, [sp, #0x440]
    1e58:      	str	x24, [sp, #0x438]
    1e5c:      	str	x23, [sp, #0x430]
    1e60:      	ldr	x0, [sp, #0x288]
    1e64:      	mov	x1, #0x17               ; =23
    1e68:      	b	0x16f8 <_stogir.verify.integer-operations-target-structured+0x944>
    1e6c:      	ldr	w0, [x0]
    1e70:      	add	x16, sp, #0x20
    1e74:      	ldr	w1, [x16]
    1e78:      	ubfx	x0, x0, #8, #8
    1e7c:      	orr	x2, x0, xzr
    1e80:      	ubfx	x1, x1, #8, #8
    1e84:      	cmp	x1, #0x6
    1e88:      	b.ne	0x1ff0 <_stogir.verify.integer-operations-target-structured+0x123c>
    1e8c:      	cmp	x2, #0x6
    1e90:      	b.ne	0x1fe8 <_stogir.verify.integer-operations-target-structured+0x1234>
    1e94:      	cmp	x22, #0x1a
    1e98:      	b.ne	0x1fd8 <_stogir.verify.integer-operations-target-structured+0x1224>
    1e9c:      	mov	x1, #0x1                ; =1
    1ea0:      	cmp	x2, #0x1
    1ea4:      	cset	w3, ge
    1ea8:      	uxtb	w16, w3
    1eac:      	cmp	w16, wzr
    1eb0:      	b.eq	0x231c <_stogir.verify.integer-operations-target-structured+0x1568>
    1eb4:      	cmp	x2, #0xb
    1eb8:      	cset	w4, le
    1ebc:      	uxtb	w16, w4
    1ec0:      	cmp	w16, wzr
    1ec4:      	b.eq	0x2338 <_stogir.verify.integer-operations-target-structured+0x1584>
    1ec8:      	ldr	x5, [sp, #0x2b8]
    1ecc:      	cmp	x5, #0x0
    1ed0:      	b.eq	0x2354 <_stogir.verify.integer-operations-target-structured+0x15a0>
    1ed4:      	ldr	w5, [sp, #0x310]
    1ed8:      	lsr	w5, w5, #0
    1edc:      	lsr	w0, w0, #0
    1ee0:      	str	x23, [sp, #0x430]
    1ee4:      	mov	x23, x2
    1ee8:      	str	x24, [sp, #0x438]
    1eec:      	mov	x24, x1
    1ef0:      	mov	w1, w0
    1ef4:      	mov	w0, w5
    1ef8:      	str	x25, [sp, #0x440]
    1efc:      	mov	w25, w3
    1f00:      	str	x26, [sp, #0x448]
    1f04:      	mov	w26, w4
    1f08:      	bl	0x1f08 <_stogir.verify.integer-operations-target-structured+0x1154>
		0000000000001f08:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1f0c:      	cmp	x0, #0x0
    1f10:      	b.ne	0x1ff8 <_stogir.verify.integer-operations-target-structured+0x1244>
    1f14:      	ldr	x0, [sp, #0x290]
    1f18:      	mov	x1, #0x1c               ; =28
    1f1c:      	add	x16, sp, #0x20
    1f20:      	ldr	w2, [x16]
    1f24:      	cmp	x20, #0x0
    1f28:      	b.eq	0x20c8 <_stogir.verify.integer-operations-target-structured+0x1314>
    1f2c:      	mov	x3, x0
    1f30:      	mov	x0, #0x1                ; =1
    1f34:      	lsr	w0, w0, #0
    1f38:      	ubfx	x2, x2, #8, #8
    1f3c:      	sxtw	x0, w0
    1f40:      	cmp	x2, x0
    1f44:      	b.ne	0x20d4 <_stogir.verify.integer-operations-target-structured+0x1320>
    1f48:      	mov	x0, x3
    1f4c:      	mov	x22, x1
    1f50:      	cmp	x20, #0x0
    1f54:      	b.eq	0x20e0 <_stogir.verify.integer-operations-target-structured+0x132c>
    1f58:      	mov	x20, x0
    1f5c:      	mov	x0, #0x1                ; =1
    1f60:      	cmp	x0, #0x0
    1f64:      	b.eq	0x2158 <_stogir.verify.integer-operations-target-structured+0x13a4>
    1f68:      	add	x16, sp, #0x220
    1f6c:      	str	x16, [sp]
    1f70:      	ldr	x0, [sp, #0x2a8]
    1f74:      	ldr	w1, [sp, #0x340]
    1f78:      	mov	x2, #0x2                ; =2
    1f7c:      	bl	0x1f7c <_stogir.verify.integer-operations-target-structured+0x11c8>
		0000000000001f7c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1f80:      	ldr	x16, [sp]
    1f84:      	str	x0, [x16]
    1f88:      	str	x1, [x16, #0x8]
    1f8c:      	add	x16, sp, #0x220
    1f90:      	ldr	x0, [x16]
    1f94:      	add	x16, sp, #0x220
    1f98:      	ldr	x1, [x16, #0x8]
    1f9c:      	lsr	w0, w0, #0
    1fa0:      	lsr	x16, x0, #0
    1fa4:      	cmp	x16, #0x1
    1fa8:      	b.eq	0x1fc4 <_stogir.verify.integer-operations-target-structured+0x1210>
    1fac:      	b.lo	0x1fb4 <_stogir.verify.integer-operations-target-structured+0x1200>
    1fb0:      	b	0x1fc8 <_stogir.verify.integer-operations-target-structured+0x1214>
    1fb4:      	cmp	x16, #0x0
    1fb8:      	b.eq	0x1fc0 <_stogir.verify.integer-operations-target-structured+0x120c>
    1fbc:      	b	0x1fc8 <_stogir.verify.integer-operations-target-structured+0x1214>
    1fc0:      	b	0x1fcc <_stogir.verify.integer-operations-target-structured+0x1218>
    1fc4:      	b	0x20ec <_stogir.verify.integer-operations-target-structured+0x1338>
    1fc8:      	b	0x2150 <_stogir.verify.integer-operations-target-structured+0x139c>
    1fcc:      	ldr	x0, [sp, #0x2a0]
    1fd0:      	mov	x1, #0x1d               ; =29
    1fd4:      	b	0x1e68 <_stogir.verify.integer-operations-target-structured+0x10b4>
    1fd8:      	cmp	x22, #0x1b
    1fdc:      	cset	w1, eq
    1fe0:      	ubfx	x1, x1, #0, #8
    1fe4:      	b	0x1ea0 <_stogir.verify.integer-operations-target-structured+0x10ec>
    1fe8:      	movz	x1, #0x0, lsl #48
    1fec:      	b	0x1ea0 <_stogir.verify.integer-operations-target-structured+0x10ec>
    1ff0:      	movz	x1, #0x0, lsl #48
    1ff4:      	b	0x1ea0 <_stogir.verify.integer-operations-target-structured+0x10ec>
    1ff8:      	cmp	x21, #0x0
    1ffc:      	b.eq	0x2070 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2000:      	ldr	w0, [sp, #0x338]
    2004:      	uxtb	w16, w0
    2008:      	cmp	w16, wzr
    200c:      	b.eq	0x207c <_stogir.verify.integer-operations-target-structured+0x12c8>
    2010:      	ldr	w0, [sp, #0x308]
    2014:      	uxtb	w16, w0
    2018:      	cmp	w16, wzr
    201c:      	b.eq	0x207c <_stogir.verify.integer-operations-target-structured+0x12c8>
    2020:      	ldr	w0, [sp, #0x2f0]
    2024:      	uxtb	w16, w25
    2028:      	cmp	w16, wzr
    202c:      	b.eq	0x1f14 <_stogir.verify.integer-operations-target-structured+0x1160>
    2030:      	uxtb	w16, w26
    2034:      	cmp	w16, wzr
    2038:      	b.eq	0x1f14 <_stogir.verify.integer-operations-target-structured+0x1160>
    203c:      	cmp	x23, #0x1
    2040:      	b.ne	0x2070 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2044:      	cmp	x22, #0x2e
    2048:      	b.eq	0x2070 <_stogir.verify.integer-operations-target-structured+0x12bc>
    204c:      	cmp	x22, #0x2f
    2050:      	b.eq	0x2070 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2054:      	cmp	x22, #0x30
    2058:      	b.eq	0x2070 <_stogir.verify.integer-operations-target-structured+0x12bc>
    205c:      	uxtb	w16, w0
    2060:      	cmp	w16, wzr
    2064:      	b.ne	0x2070 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2068:      	cmp	x22, #0x3b
    206c:      	b.ne	0x1f14 <_stogir.verify.integer-operations-target-structured+0x1160>
    2070:      	ldr	x0, [sp, #0x420]
    2074:      	ldr	x1, [sp, #0x428]
    2078:      	b	0x1f1c <_stogir.verify.integer-operations-target-structured+0x1168>
    207c:      	ldr	w0, [sp, #0x300]
    2080:      	uxtb	w16, w0
    2084:      	cmp	w16, wzr
    2088:      	b.eq	0x20a4 <_stogir.verify.integer-operations-target-structured+0x12f0>
    208c:      	ldr	w0, [sp, #0x2f8]
    2090:      	uxtb	w16, w0
    2094:      	cmp	w16, wzr
    2098:      	b.eq	0x20a4 <_stogir.verify.integer-operations-target-structured+0x12f0>
    209c:      	ldr	w0, [sp, #0x2f0]
    20a0:      	b	0x2024 <_stogir.verify.integer-operations-target-structured+0x1270>
    20a4:      	ldr	w0, [sp, #0x2f0]
    20a8:      	uxtb	w16, w0
    20ac:      	cmp	w16, wzr
    20b0:      	b.ne	0x2024 <_stogir.verify.integer-operations-target-structured+0x1270>
    20b4:      	ldr	w1, [sp, #0x2e8]
    20b8:      	uxtb	w16, w1
    20bc:      	cmp	w16, wzr
    20c0:      	b.ne	0x2024 <_stogir.verify.integer-operations-target-structured+0x1270>
    20c4:      	b	0x1f14 <_stogir.verify.integer-operations-target-structured+0x1160>
    20c8:      	mov	x3, x0
    20cc:      	mov	x0, x23
    20d0:      	b	0x1f34 <_stogir.verify.integer-operations-target-structured+0x1180>
    20d4:      	ldr	x0, [sp, #0x298]
    20d8:      	mov	x22, #0x26              ; =38
    20dc:      	b	0x1f50 <_stogir.verify.integer-operations-target-structured+0x119c>
    20e0:      	mov	x20, x0
    20e4:      	mov	x0, x21
    20e8:      	b	0x1f60 <_stogir.verify.integer-operations-target-structured+0x11ac>
    20ec:      	lsr	w1, w1, #0
    20f0:      	lsr	w1, w1, #0
    20f4:      	ldr	x0, [sp, #0x2a8]
    20f8:      	bl	0x20f8 <_stogir.verify.integer-operations-target-structured+0x1344>
		00000000000020f8:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    20fc:      	cmp	x0, #0x0
    2100:      	b.ne	0x2110 <_stogir.verify.integer-operations-target-structured+0x135c>
    2104:      	ldr	x0, [sp, #0x2a0]
    2108:      	mov	x1, #0x1d               ; =29
    210c:      	b	0x1fd4 <_stogir.verify.integer-operations-target-structured+0x1220>
    2110:      	ldr	w0, [x0]
    2114:      	ubfx	x0, x0, #8, #8
    2118:      	cmp	x23, x0
    211c:      	b.eq	0x2138 <_stogir.verify.integer-operations-target-structured+0x1384>
    2120:      	cmp	x24, #0x0
    2124:      	b.eq	0x2144 <_stogir.verify.integer-operations-target-structured+0x1390>
    2128:      	cmp	x0, #0x5
    212c:      	b.eq	0x2138 <_stogir.verify.integer-operations-target-structured+0x1384>
    2130:      	cmp	x0, #0xb
    2134:      	b.ne	0x2144 <_stogir.verify.integer-operations-target-structured+0x1390>
    2138:      	mov	x0, x20
    213c:      	mov	x1, x22
    2140:      	b	0x210c <_stogir.verify.integer-operations-target-structured+0x1358>
    2144:      	ldr	x0, [sp, #0x2c0]
    2148:      	mov	x1, #0x1d               ; =29
    214c:      	b	0x2140 <_stogir.verify.integer-operations-target-structured+0x138c>
    2150:      	brk	#0
    2154:      	b	0x2150 <_stogir.verify.integer-operations-target-structured+0x139c>
    2158:      	mov	x0, x20
    215c:      	mov	x1, x22
    2160:      	b	0x1fd4 <_stogir.verify.integer-operations-target-structured+0x1220>
    2164:      	brk	#0
    2168:      	b	0x2164 <_stogir.verify.integer-operations-target-structured+0x13b0>
    216c:      	mov	x0, x19
    2170:      	ldr	x1, [sp, #0x420]
    2174:      	ldr	x2, [sp, #0x428]
    2178:      	b	0x1714 <_stogir.verify.integer-operations-target-structured+0x960>
    217c:      	brk	#0
    2180:      	b	0x217c <_stogir.verify.integer-operations-target-structured+0x13c8>
    2184:      	brk	#0
    2188:      	b	0x2184 <_stogir.verify.integer-operations-target-structured+0x13d0>
    218c:      	brk	#0
    2190:      	b	0x218c <_stogir.verify.integer-operations-target-structured+0x13d8>
    2194:      	brk	#0
    2198:      	b	0x2194 <_stogir.verify.integer-operations-target-structured+0x13e0>
    219c:      	ldr	x0, [sp, #0x2e0]
    21a0:      	cmp	x0, #0x0
    21a4:      	b.ne	0x2200 <_stogir.verify.integer-operations-target-structured+0x144c>
    21a8:      	and	x0, x19, #0xffffffff
    21ac:      	mov	x1, x0
    21b0:      	movz	x0, #0x0, lsl #48
    21b4:      	movz	x2, #0x0, lsl #48
    21b8:      	ldr	x3, [sp, #0x2c8]
    21bc:      	str	x0, [x3]
    21c0:      	str	x1, [x3, #0x8]
    21c4:      	str	x2, [x3, #0x10]
    21c8:      	ldr	x19, [sp, #0x450]
    21cc:      	ldr	x20, [sp, #0x458]
    21d0:      	ldr	x21, [sp, #0x460]
    21d4:      	ldr	x22, [sp, #0x468]
    21d8:      	ldr	x23, [sp, #0x470]
    21dc:      	ldr	x24, [sp, #0x478]
    21e0:      	ldr	x25, [sp, #0x480]
    21e4:      	ldr	x26, [sp, #0x488]
    21e8:      	ldr	x27, [sp, #0x490]
    21ec:      	ldr	x28, [sp, #0x498]
    21f0:      	ldr	x29, [sp, #0x10]
    21f4:      	ldr	x30, [sp, #0x18]
    21f8:      	add	sp, sp, #0x4a0
    21fc:      	ret
    2200:      	ldr	x1, [sp, #0x248]
    2204:      	mov	x2, x0
    2208:      	mov	x0, #0x1                ; =1
    220c:      	b	0x21b8 <_stogir.verify.integer-operations-target-structured+0x1404>
    2210:      	str	x8, [sp, #0x2c8]
    2214:      	str	x20, [sp, #0x2e0]
    2218:      	b	0x219c <_stogir.verify.integer-operations-target-structured+0x13e8>
    221c:      	str	x8, [sp, #0x2c8]
    2220:      	str	x20, [sp, #0x2e0]
    2224:      	b	0x219c <_stogir.verify.integer-operations-target-structured+0x13e8>
    2228:      	str	x1, [sp, #0x358]
    222c:      	str	x2, [sp, #0x360]
    2230:      	b	0x18e8 <_stogir.verify.integer-operations-target-structured+0xb34>
    2234:      	str	x1, [sp, #0x368]
    2238:      	str	x2, [sp, #0x370]
    223c:      	b	0x19e0 <_stogir.verify.integer-operations-target-structured+0xc2c>
    2240:      	str	x0, [sp, #0x378]
    2244:      	str	x1, [sp, #0x380]
    2248:      	b	0x19fc <_stogir.verify.integer-operations-target-structured+0xc48>
    224c:      	str	x0, [sp, #0x388]
    2250:      	str	x1, [sp, #0x390]
    2254:      	b	0x1a60 <_stogir.verify.integer-operations-target-structured+0xcac>
    2258:      	str	x0, [sp, #0x388]
    225c:      	str	x1, [sp, #0x390]
    2260:      	b	0x1a60 <_stogir.verify.integer-operations-target-structured+0xcac>
    2264:      	str	x0, [sp, #0x3a8]
    2268:      	str	x1, [sp, #0x3b0]
    226c:      	b	0x13b0 <_stogir.verify.integer-operations-target-structured+0x5fc>
    2270:      	str	x0, [sp, #0x3c8]
    2274:      	str	x1, [sp, #0x3d0]
    2278:      	ldr	x1, [sp, #0x350]
    227c:      	b	0x140c <_stogir.verify.integer-operations-target-structured+0x658>
    2280:      	str	x1, [sp, #0x350]
    2284:      	ldr	x1, [sp, #0x318]
    2288:      	str	x0, [sp, #0x3d8]
    228c:      	str	x2, [sp, #0x3e0]
    2290:      	b	0x1cd8 <_stogir.verify.integer-operations-target-structured+0xf24>
    2294:      	str	x1, [sp, #0x350]
    2298:      	ldr	x1, [sp, #0x318]
    229c:      	str	x0, [sp, #0x3d8]
    22a0:      	str	x2, [sp, #0x3e0]
    22a4:      	b	0x1cd8 <_stogir.verify.integer-operations-target-structured+0xf24>
    22a8:      	str	x1, [sp, #0x318]
    22ac:      	ldr	x1, [sp, #0x238]
    22b0:      	str	x0, [sp, #0x3e8]
    22b4:      	str	x2, [sp, #0x3f0]
    22b8:      	b	0x1d04 <_stogir.verify.integer-operations-target-structured+0xf50>
    22bc:      	str	x1, [sp, #0x238]
    22c0:      	str	x0, [sp, #0x3f8]
    22c4:      	str	x2, [sp, #0x400]
    22c8:      	b	0x1dbc <_stogir.verify.integer-operations-target-structured+0x1008>
    22cc:      	str	x20, [sp, #0x418]
    22d0:      	mov	x20, x2
    22d4:      	str	x0, [sp, #0x408]
    22d8:      	str	x1, [sp, #0x410]
    22dc:      	ldr	x1, [sp, #0x258]
    22e0:      	b	0x1de8 <_stogir.verify.integer-operations-target-structured+0x1034>
    22e4:      	ldr	x20, [sp, #0x330]
    22e8:      	ldr	x21, [sp, #0x2b0]
    22ec:      	b	0x1e30 <_stogir.verify.integer-operations-target-structured+0x107c>
    22f0:      	ldr	x20, [sp, #0x330]
    22f4:      	ldr	x21, [sp, #0x2b0]
    22f8:      	b	0x1e28 <_stogir.verify.integer-operations-target-structured+0x1074>
    22fc:      	str	x26, [sp, #0x448]
    2300:      	str	x25, [sp, #0x440]
    2304:      	str	x24, [sp, #0x438]
    2308:      	str	x23, [sp, #0x430]
    230c:      	str	x1, [sp, #0x258]
    2310:      	str	x2, [sp, #0x420]
    2314:      	str	x3, [sp, #0x428]
    2318:      	b	0x216c <_stogir.verify.integer-operations-target-structured+0x13b8>
    231c:      	str	x26, [sp, #0x448]
    2320:      	str	x25, [sp, #0x440]
    2324:      	str	x24, [sp, #0x438]
    2328:      	mov	x24, x1
    232c:      	str	x23, [sp, #0x430]
    2330:      	mov	x23, x2
    2334:      	b	0x1f14 <_stogir.verify.integer-operations-target-structured+0x1160>
    2338:      	str	x26, [sp, #0x448]
    233c:      	str	x25, [sp, #0x440]
    2340:      	str	x24, [sp, #0x438]
    2344:      	mov	x24, x1
    2348:      	str	x23, [sp, #0x430]
    234c:      	mov	x23, x2
    2350:      	b	0x1f14 <_stogir.verify.integer-operations-target-structured+0x1160>
    2354:      	str	x26, [sp, #0x448]
    2358:      	str	x25, [sp, #0x440]
    235c:      	str	x24, [sp, #0x438]
    2360:      	mov	x24, x1
    2364:      	str	x23, [sp, #0x430]
    2368:      	mov	x23, x2
    236c:      	mov	w25, w3
    2370:      	mov	w26, w4
    2374:      	b	0x1ff8 <_stogir.verify.integer-operations-target-structured+0x1244>

0000000000002378 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    2378:      	ldr	x0, [x0, #0x8]
    237c:      	ret

0000000000002380 <_coil.core.Eq$slice<u8>$=>:
    2380:      	sub	sp, sp, #0x10
    2384:      	str	x29, [sp]
    2388:      	str	x30, [sp, #0x8]
    238c:      	mov	x29, sp
    2390:      	cmp	x1, x3
    2394:      	b.ne	0x23d4 <_coil.core.Eq$slice<u8>$=+0x54>
    2398:      	cmp	x1, #0x0
    239c:      	b.ne	0x23a8 <_coil.core.Eq$slice<u8>$=+0x28>
    23a0:      	mov	x0, #0x1                ; =1
    23a4:      	b	0x23d0 <_coil.core.Eq$slice<u8>$=+0x50>
    23a8:      	lsr	x1, x1, #0
    23ac:      	fmov	d31, x1
    23b0:      	mov	x1, x2
    23b4:      	fmov	x2, d31
    23b8:      	bl	0x23b8 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000023b8:  ARM64_RELOC_BRANCH26	_memcmp
    23bc:      	lsr	w0, w0, #0
    23c0:      	sxtw	x0, w0
    23c4:      	cmp	x0, #0x0
    23c8:      	cset	w0, eq
    23cc:      	ubfx	x0, x0, #0, #8
    23d0:      	b	0x23d8 <_coil.core.Eq$slice<u8>$=+0x58>
    23d4:      	movz	x0, #0x0, lsl #48
    23d8:      	ldr	x29, [sp]
    23dc:      	ldr	x30, [sp, #0x8]
    23e0:      	add	sp, sp, #0x10
    23e4:      	ret

00000000000023e8 <_stogir.node.opcode>:
    23e8:      	ldr	w0, [x0]
    23ec:      	uxtb	w0, w0
    23f0:      	ret

00000000000023f4 <_stogir.opcode.valid?>:
    23f4:      	sxtw	x0, w0
    23f8:      	cmp	x0, #0x0
    23fc:      	b.lt	0x2410 <_stogir.opcode.valid?+0x1c>
    2400:      	cmp	x0, #0x83
    2404:      	cset	w0, lt
    2408:      	ubfx	x0, x0, #0, #8
    240c:      	b	0x2414 <_stogir.opcode.valid?+0x20>
    2410:      	movz	x0, #0x0, lsl #48
    2414:      	ret

0000000000002418 <_stogir.node.type-id>:
    2418:      	ldr	w0, [x0]
    241c:      	ubfx	x0, x0, #8, #8
    2420:      	ret

0000000000002424 <_stogir.types.valid?>:
    2424:      	sxtw	x0, w0
    2428:      	cmp	x0, #0x0
    242c:      	b.lt	0x2440 <_stogir.types.valid?+0x1c>
    2430:      	cmp	x0, #0xd
    2434:      	b.gt	0x2440 <_stogir.types.valid?+0x1c>
    2438:      	mov	x0, #0x1                ; =1
    243c:      	ret
    2440:      	cmp	x0, #0xf
    2444:      	b.le	0x247c <_stogir.types.valid?+0x58>
    2448:      	cmp	x0, #0x80
    244c:      	b.ge	0x2474 <_stogir.types.valid?+0x50>
    2450:      	and	x0, x0, #0xf
    2454:      	lsr	w0, w0, #0
    2458:      	sxtw	x0, w0
    245c:      	cmp	x0, #0x1
    2460:      	b.lt	0x2484 <_stogir.types.valid?+0x60>
    2464:      	cmp	x0, #0xd
    2468:      	cset	w0, le
    246c:      	ubfx	x0, x0, #0, #8
    2470:      	b	0x2488 <_stogir.types.valid?+0x64>
    2474:      	movz	x0, #0x0, lsl #48
    2478:      	b	0x2480 <_stogir.types.valid?+0x5c>
    247c:      	movz	x0, #0x0, lsl #48
    2480:      	ret
    2484:      	movz	x0, #0x0, lsl #48
    2488:      	b	0x2478 <_stogir.types.valid?+0x54>

000000000000248c <_stogir.opcode.operand-slots>:
    248c:      	sxtw	x0, w0
    2490:      	cmp	x0, #0x0
    2494:      	b.lt	0x24c0 <_stogir.opcode.operand-slots+0x34>
    2498:      	cmp	x0, #0x83
    249c:      	b.ge	0x24c0 <_stogir.opcode.operand-slots+0x34>
    24a0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x124c>
		00000000000024a0:  ARM64_RELOC_PAGE21	l_stogir.334
    24a4:      	ldr	x16, [x16]
		00000000000024a4:  ARM64_RELOC_PAGEOFF12	l_stogir.334
    24a8:      	orr	x1, x16, xzr
    24ac:      	lsr	x0, x0, #0
    24b0:      	add	x0, x0, x1
    24b4:      	ldrsb	w0, [x0]
    24b8:      	sxtb	x0, w0
    24bc:      	b	0x24c4 <_stogir.opcode.operand-slots+0x38>
    24c0:      	mov	x0, #-0x2               ; =-2
    24c4:      	ret

00000000000024c8 <_stogir.opcode.input-count>:
    24c8:      	sxtw	x0, w0
    24cc:      	cmp	x0, #0x0
    24d0:      	b.lt	0x24fc <_stogir.opcode.input-count+0x34>
    24d4:      	cmp	x0, #0x83
    24d8:      	b.ge	0x24fc <_stogir.opcode.input-count+0x34>
    24dc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x124c>
		00000000000024dc:  ARM64_RELOC_PAGE21	l_stogir.335
    24e0:      	ldr	x16, [x16]
		00000000000024e0:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    24e4:      	orr	x1, x16, xzr
    24e8:      	lsr	x0, x0, #0
    24ec:      	add	x0, x0, x1
    24f0:      	ldrsb	w0, [x0]
    24f4:      	sxtb	x0, w0
    24f8:      	b	0x2500 <_stogir.opcode.input-count+0x38>
    24fc:      	mov	x0, #-0x2               ; =-2
    2500:      	ret

0000000000002504 <_stogir.node.auxiliary>:
    2504:      	ldr	w0, [x0]
    2508:      	ubfx	x0, x0, #16, #16
    250c:      	ret

0000000000002510 <_stogir.opcode.operand-code>:
    2510:      	sxtw	x0, w0
    2514:      	cmp	x0, #0x0
    2518:      	b.lt	0x2558 <_stogir.opcode.operand-code+0x48>
    251c:      	cmp	x0, #0x83
    2520:      	b.ge	0x2558 <_stogir.opcode.operand-code+0x48>
    2524:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x124c>
		0000000000002524:  ARM64_RELOC_PAGE21	l_stogir.336
    2528:      	ldr	x16, [x16]
		0000000000002528:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    252c:      	orr	x2, x16, xzr
    2530:      	lsl	x0, x0, #2
    2534:      	sxtw	x1, w1
    2538:      	add	x0, x0, x2
    253c:      	ldr	w0, [x0]
    2540:      	cmp	x1, #0x0
    2544:      	b.le	0x258c <_stogir.opcode.operand-code+0x7c>
    2548:      	cmp	x1, #0x4
    254c:      	b.le	0x2560 <_stogir.opcode.operand-code+0x50>
    2550:      	mov	x1, #0x4                ; =4
    2554:      	b	0x256c <_stogir.opcode.operand-code+0x5c>
    2558:      	movz	x0, #0x0, lsl #48
    255c:      	ret
    2560:      	sub	x1, x1, #0x1
    2564:      	lsr	w1, w1, #0
    2568:      	sxtw	x1, w1
    256c:      	lsl	x1, x1, #2
    2570:      	lsr	w1, w1, #0
    2574:      	ubfx	x1, x1, #0, #32
    2578:      	lsr	x0, x0, x1
    257c:      	lsr	w0, w0, #0
    2580:      	and	x0, x0, #0xf
    2584:      	lsr	w0, w0, #0
    2588:      	b	0x2590 <_stogir.opcode.operand-code+0x80>
    258c:      	movz	x0, #0x0, lsl #48
    2590:      	ret

0000000000002594 <_stogir.graph.operand>:
    2594:      	sub	sp, sp, #0x10
    2598:      	mov	x3, sp
    259c:      	sxtw	x1, w1
    25a0:      	cmp	x1, #0x0
    25a4:      	b.le	0x25e8 <_stogir.graph.operand+0x54>
    25a8:      	lsl	x4, x1, #2
    25ac:      	ldr	x5, [x0, #0x8]
    25b0:      	cmp	x1, x5
    25b4:      	b.ge	0x261c <_stogir.graph.operand+0x88>
    25b8:      	add	x5, x0, #0x78
    25bc:      	ldr	x5, [x5, #0x8]
    25c0:      	cmp	x1, x5
    25c4:      	b.ge	0x2614 <_stogir.graph.operand+0x80>
    25c8:      	ldr	x5, [x0, #0x78]
    25cc:      	add	x5, x4, x5
    25d0:      	ldr	w5, [x5]
    25d4:      	sxtw	x5, w5
    25d8:      	cmp	x5, #0x0
    25dc:      	cset	w5, ge
    25e0:      	ubfx	x5, x5, #0, #8
    25e4:      	b	0x2618 <_stogir.graph.operand+0x84>
    25e8:      	movz	x0, #0x0, lsl #48
    25ec:      	movz	x1, #0x0, lsl #48
    25f0:      	str	x0, [x3]
    25f4:      	str	x1, [x3, #0x8]
    25f8:      	ldr	x0, [sp]
    25fc:      	ldr	x1, [sp, #0x8]
    2600:      	add	sp, sp, #0x10
    2604:      	ret
    2608:      	movz	x0, #0x0, lsl #48
    260c:      	movz	x1, #0x0, lsl #48
    2610:      	b	0x25f0 <_stogir.graph.operand+0x5c>
    2614:      	movz	x5, #0x0, lsl #48
    2618:      	b	0x2620 <_stogir.graph.operand+0x8c>
    261c:      	movz	x5, #0x0, lsl #48
    2620:      	cmp	x5, #0x0
    2624:      	b.eq	0x25e8 <_stogir.graph.operand+0x54>
    2628:      	sxtw	x2, w2
    262c:      	cmp	x2, #0x1
    2630:      	b.lt	0x2608 <_stogir.graph.operand+0x74>
    2634:      	ldr	x5, [x0, #0x78]
    2638:      	add	x4, x4, x5
    263c:      	ldr	w4, [x4]
    2640:      	sxtw	x4, w4
    2644:      	cmp	x2, x4
    2648:      	b.gt	0x2608 <_stogir.graph.operand+0x74>
    264c:      	asr	x16, x2, #63
    2650:      	lsr	x16, x16, #62
    2654:      	add	x4, x2, x16
    2658:      	asr	x4, x4, #2
    265c:      	asr	x16, x2, #63
    2660:      	lsr	x16, x16, #62
    2664:      	add	x2, x2, x16
    2668:      	and	x2, x2, #0x3
    266c:      	sub	x2, x2, x16
    2670:      	ldr	x0, [x0]
    2674:      	add	x1, x4, x1
    2678:      	lsl	x2, x2, #2
    267c:      	lsl	x1, x1, #4
    2680:      	add	x0, x1, x0
    2684:      	add	x0, x2, x0
    2688:      	ldr	w0, [x0]
    268c:      	sxtw	x0, w0
    2690:      	and	x0, x0, #0xffffffff
    2694:      	mov	x1, x0
    2698:      	mov	x0, #0x1                ; =1
    269c:      	b	0x2610 <_stogir.graph.operand+0x7c>

00000000000026a0 <_stogir.graph.borrow-node>:
    26a0:      	sxtw	x1, w1
    26a4:      	cmp	x1, #0x0
    26a8:      	cset	w2, gt
    26ac:      	movz	x16, #0x0, lsl #48
    26b0:      	sub	x3, x16, x1
    26b4:      	sub	x4, x3, #0x1
    26b8:      	uxtb	w16, w2
    26bc:      	cmp	w16, wzr
    26c0:      	b.eq	0x2704 <_stogir.graph.borrow-node+0x64>
    26c4:      	ldr	x3, [x0, #0x8]
    26c8:      	cmp	x1, x3
    26cc:      	b.ge	0x2758 <_stogir.graph.borrow-node+0xb8>
    26d0:      	add	x3, x0, #0x78
    26d4:      	ldr	x3, [x3, #0x8]
    26d8:      	cmp	x1, x3
    26dc:      	b.ge	0x27a0 <_stogir.graph.borrow-node+0x100>
    26e0:      	lsl	x3, x1, #2
    26e4:      	ldr	x5, [x0, #0x78]
    26e8:      	add	x3, x3, x5
    26ec:      	ldr	w3, [x3]
    26f0:      	sxtw	x3, w3
    26f4:      	cmp	x3, #0x0
    26f8:      	cset	w3, ge
    26fc:      	ubfx	x3, x3, #0, #8
    2700:      	b	0x27a4 <_stogir.graph.borrow-node+0x104>
    2704:      	cmp	x1, #0x0
    2708:      	b.ge	0x2760 <_stogir.graph.borrow-node+0xc0>
    270c:      	add	x5, x0, #0x28
    2710:      	add	x6, x0, #0x50
    2714:      	ldr	x5, [x5, #0x8]
    2718:      	ldr	x6, [x6, #0x8]
    271c:      	cmp	x5, x6
    2720:      	b.ne	0x2750 <_stogir.graph.borrow-node+0xb0>
    2724:      	cmp	x3, x5
    2728:      	b.gt	0x27a8 <_stogir.graph.borrow-node+0x108>
    272c:      	lsl	x3, x4, #2
    2730:      	ldr	x5, [x0, #0x50]
    2734:      	add	x3, x3, x5
    2738:      	ldr	w3, [x3]
    273c:      	sxtw	x3, w3
    2740:      	cmp	x3, #0x0
    2744:      	cset	w3, gt
    2748:      	ubfx	x3, x3, #0, #8
    274c:      	b	0x27ac <_stogir.graph.borrow-node+0x10c>
    2750:      	movz	x3, #0x0, lsl #48
    2754:      	b	0x2764 <_stogir.graph.borrow-node+0xc4>
    2758:      	movz	x3, #0x0, lsl #48
    275c:      	b	0x2764 <_stogir.graph.borrow-node+0xc4>
    2760:      	movz	x3, #0x0, lsl #48
    2764:      	cmp	x3, #0x0
    2768:      	b.eq	0x2798 <_stogir.graph.borrow-node+0xf8>
    276c:      	uxtb	w16, w2
    2770:      	cmp	w16, wzr
    2774:      	b.eq	0x2788 <_stogir.graph.borrow-node+0xe8>
    2778:      	lsl	x1, x1, #4
    277c:      	ldr	x0, [x0]
    2780:      	add	x0, x1, x0
    2784:      	b	0x2794 <_stogir.graph.borrow-node+0xf4>
    2788:      	lsl	x1, x4, #4
    278c:      	ldr	x0, [x0, #0x28]
    2790:      	add	x0, x1, x0
    2794:      	b	0x279c <_stogir.graph.borrow-node+0xfc>
    2798:      	movz	x0, #0x0, lsl #48
    279c:      	ret
    27a0:      	movz	x3, #0x0, lsl #48
    27a4:      	b	0x275c <_stogir.graph.borrow-node+0xbc>
    27a8:      	movz	x3, #0x0, lsl #48
    27ac:      	b	0x2754 <_stogir.graph.borrow-node+0xb4>

00000000000027b0 <_stogir.strings.lookup>:
    27b0:      	sxtw	x1, w1
    27b4:      	cmp	x1, #0x0
    27b8:      	b.le	0x2834 <_stogir.strings.lookup+0x84>
    27bc:      	add	x2, x0, #0x28
    27c0:      	ldr	x2, [x2, #0x8]
    27c4:      	cmp	x1, x2
    27c8:      	b.gt	0x2834 <_stogir.strings.lookup+0x84>
    27cc:      	sub	x1, x1, #0x1
    27d0:      	mov	x17, #0x18              ; =24
    27d4:      	mul	x1, x1, x17
    27d8:      	ldr	x2, [x0, #0x28]
    27dc:      	add	x1, x1, x2
    27e0:      	ldr	x2, [x1]
    27e4:      	ldr	x1, [x1, #0x8]
    27e8:      	ldr	x3, [x0, #0x8]
    27ec:      	cmp	x2, #0x0
    27f0:      	b.lt	0x2850 <_stogir.strings.lookup+0xa0>
    27f4:      	cmp	x2, x3
    27f8:      	b.gt	0x2850 <_stogir.strings.lookup+0xa0>
    27fc:      	cmp	x1, #0x0
    2800:      	b.lt	0x2850 <_stogir.strings.lookup+0xa0>
    2804:      	sub	x3, x3, x2
    2808:      	cmp	x1, x3
    280c:      	b.gt	0x2850 <_stogir.strings.lookup+0xa0>
    2810:      	add	x1, x1, x2
    2814:      	lsr	x3, x2, #0
    2818:      	sub	x1, x1, x2
    281c:      	ldr	x0, [x0]
    2820:      	add	x0, x3, x0
    2824:      	mov	x2, x1
    2828:      	mov	x1, x0
    282c:      	mov	x0, #0x1                ; =1
    2830:      	b	0x285c <_stogir.strings.lookup+0xac>
    2834:      	movz	x0, #0x0, lsl #48
    2838:      	movz	x1, #0x0, lsl #48
    283c:      	movz	x2, #0x0, lsl #48
    2840:      	str	x0, [x8]
    2844:      	str	x1, [x8, #0x8]
    2848:      	str	x2, [x8, #0x10]
    284c:      	ret
    2850:      	movz	x0, #0x0, lsl #48
    2854:      	movz	x1, #0x0, lsl #48
    2858:      	movz	x2, #0x0, lsl #48
    285c:      	b	0x2840 <_stogir.strings.lookup+0x90>

0000000000002860 <_stogir.uses.edge-code?>:
    2860:      	ubfx	x0, x0, #0, #32
    2864:      	cmp	x0, #0xf
    2868:      	b.hs	0x289c <_stogir.uses.edge-code?+0x3c>
    286c:      	mov	x16, #0x1               ; =1
    2870:      	lsl	x0, x16, x0
    2874:      	lsr	w0, w0, #0
    2878:      	mov	x17, #0x5e1c            ; =24092
    287c:      	and	x0, x0, x17
    2880:      	lsr	w0, w0, #0
    2884:      	cmp	x0, #0x0
    2888:      	cset	w0, eq
    288c:      	uxtb	w16, w0
    2890:      	cmp	w16, wzr
    2894:      	cset	x0, eq
    2898:      	b	0x28a0 <_stogir.uses.edge-code?+0x40>
    289c:      	movz	x0, #0x0, lsl #48
    28a0:      	ret

00000000000028a4 <_stogir.graph.contains?>:
    28a4:      	sxtw	x1, w1
    28a8:      	cmp	x1, #0x0
    28ac:      	b.le	0x28f0 <_stogir.graph.contains?+0x4c>
    28b0:      	ldr	x2, [x0, #0x8]
    28b4:      	cmp	x1, x2
    28b8:      	b.ge	0x2950 <_stogir.graph.contains?+0xac>
    28bc:      	add	x2, x0, #0x78
    28c0:      	ldr	x2, [x2, #0x8]
    28c4:      	cmp	x1, x2
    28c8:      	b.ge	0x2960 <_stogir.graph.contains?+0xbc>
    28cc:      	lsl	x1, x1, #2
    28d0:      	ldr	x0, [x0, #0x78]
    28d4:      	add	x0, x1, x0
    28d8:      	ldr	w0, [x0]
    28dc:      	sxtw	x0, w0
    28e0:      	cmp	x0, #0x0
    28e4:      	cset	w0, ge
    28e8:      	ubfx	x0, x0, #0, #8
    28ec:      	b	0x2964 <_stogir.graph.contains?+0xc0>
    28f0:      	cmp	x1, #0x0
    28f4:      	b.ge	0x2958 <_stogir.graph.contains?+0xb4>
    28f8:      	add	x2, x0, #0x28
    28fc:      	add	x3, x0, #0x50
    2900:      	ldr	x2, [x2, #0x8]
    2904:      	ldr	x3, [x3, #0x8]
    2908:      	cmp	x2, x3
    290c:      	b.ne	0x2970 <_stogir.graph.contains?+0xcc>
    2910:      	movz	x16, #0x0, lsl #48
    2914:      	sub	x3, x16, x1
    2918:      	cmp	x3, x2
    291c:      	b.gt	0x2968 <_stogir.graph.contains?+0xc4>
    2920:      	movz	x16, #0x0, lsl #48
    2924:      	sub	x1, x16, x1
    2928:      	sub	x1, x1, #0x1
    292c:      	lsl	x1, x1, #2
    2930:      	ldr	x0, [x0, #0x50]
    2934:      	add	x0, x1, x0
    2938:      	ldr	w0, [x0]
    293c:      	sxtw	x0, w0
    2940:      	cmp	x0, #0x0
    2944:      	cset	w0, gt
    2948:      	ubfx	x0, x0, #0, #8
    294c:      	b	0x296c <_stogir.graph.contains?+0xc8>
    2950:      	movz	x0, #0x0, lsl #48
    2954:      	b	0x2964 <_stogir.graph.contains?+0xc0>
    2958:      	movz	x0, #0x0, lsl #48
    295c:      	b	0x296c <_stogir.graph.contains?+0xc8>
    2960:      	movz	x0, #0x0, lsl #48
    2964:      	b	0x296c <_stogir.graph.contains?+0xc8>
    2968:      	movz	x0, #0x0, lsl #48
    296c:      	ret
    2970:      	movz	x0, #0x0, lsl #48
    2974:      	b	0x296c <_stogir.graph.contains?+0xc8>

0000000000002978 <_stogir.opcode.optional-reference?>:
    2978:      	sub	sp, sp, #0x30
    297c:      	str	x29, [sp]
    2980:      	str	x30, [sp, #0x8]
    2984:      	mov	x29, sp
    2988:      	str	x19, [sp, #0x10]
    298c:      	str	x20, [sp, #0x18]
    2990:      	str	x21, [sp, #0x20]
    2994:      	lsr	w0, w0, #0
    2998:      	lsr	w2, w2, #0
    299c:      	mov	w19, w0
    29a0:      	mov	w20, w1
    29a4:      	mov	w1, w2
    29a8:      	mov	w21, w2
    29ac:      	bl	0x29ac <_stogir.opcode.optional-reference?+0x34>
		00000000000029ac:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    29b0:      	lsr	w0, w0, #0
    29b4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x124c>
		00000000000029b4:  ARM64_RELOC_PAGE21	l_stogir.337
    29b8:      	ldr	x16, [x16]
		00000000000029b8:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    29bc:      	ldr	w1, [x16]
    29c0:      	cmp	x0, x1
    29c4:      	b.ne	0x29f0 <_stogir.opcode.optional-reference?+0x78>
    29c8:      	mov	x0, #0x1                ; =1
    29cc:      	b	0x29d4 <_stogir.opcode.optional-reference?+0x5c>
    29d0:      	movz	x0, #0x0, lsl #48
    29d4:      	ldr	x19, [sp, #0x10]
    29d8:      	ldr	x20, [sp, #0x18]
    29dc:      	ldr	x21, [sp, #0x20]
    29e0:      	ldr	x29, [sp]
    29e4:      	ldr	x30, [sp, #0x8]
    29e8:      	add	sp, sp, #0x30
    29ec:      	ret
    29f0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x124c>
		00000000000029f0:  ARM64_RELOC_PAGE21	l_stogir.338
    29f4:      	ldr	x16, [x16]
		00000000000029f4:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    29f8:      	ldr	w1, [x16]
    29fc:      	cmp	x0, x1
    2a00:      	b.ne	0x2a0c <_stogir.opcode.optional-reference?+0x94>
    2a04:      	mov	x0, #0x1                ; =1
    2a08:      	b	0x29d4 <_stogir.opcode.optional-reference?+0x5c>
    2a0c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x124c>
		0000000000002a0c:  ARM64_RELOC_PAGE21	l_stogir.339
    2a10:      	ldr	x16, [x16]
		0000000000002a10:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    2a14:      	ldr	w1, [x16]
    2a18:      	cmp	x0, x1
    2a1c:      	b.ne	0x2a28 <_stogir.opcode.optional-reference?+0xb0>
    2a20:      	mov	x0, #0x1                ; =1
    2a24:      	b	0x29d4 <_stogir.opcode.optional-reference?+0x5c>
    2a28:      	sxtw	x19, w19
    2a2c:      	cmp	x19, #0x78
    2a30:      	b.ne	0x2a54 <_stogir.opcode.optional-reference?+0xdc>
    2a34:      	sxtw	x20, w20
    2a38:      	cmp	x20, #0x0
    2a3c:      	b.ne	0x29d0 <_stogir.opcode.optional-reference?+0x58>
    2a40:      	sxtw	x21, w21
    2a44:      	cmp	x21, #0x2
    2a48:      	cset	w0, eq
    2a4c:      	ubfx	x0, x0, #0, #8
    2a50:      	b	0x29d4 <_stogir.opcode.optional-reference?+0x5c>
    2a54:      	movz	x0, #0x0, lsl #48
    2a58:      	b	0x29d4 <_stogir.opcode.optional-reference?+0x5c>

0000000000002a5c <_stogir.integer-binary.operation?>:
    2a5c:      	sxtw	x0, w0
    2a60:      	cmp	x0, #0x1a
    2a64:      	b.lt	0x2a78 <_stogir.integer-binary.operation?+0x1c>
    2a68:      	cmp	x0, #0x1e
    2a6c:      	b.gt	0x2a78 <_stogir.integer-binary.operation?+0x1c>
    2a70:      	mov	x0, #0x1                ; =1
    2a74:      	b	0x2aac <_stogir.integer-binary.operation?+0x50>
    2a78:      	cmp	x0, #0x2e
    2a7c:      	b.lt	0x2a90 <_stogir.integer-binary.operation?+0x34>
    2a80:      	cmp	x0, #0x35
    2a84:      	b.gt	0x2a90 <_stogir.integer-binary.operation?+0x34>
    2a88:      	mov	x0, #0x1                ; =1
    2a8c:      	b	0x2aac <_stogir.integer-binary.operation?+0x50>
    2a90:      	cmp	x0, #0x3a
    2a94:      	b.ne	0x2aa0 <_stogir.integer-binary.operation?+0x44>
    2a98:      	mov	x0, #0x1                ; =1
    2a9c:      	b	0x2aac <_stogir.integer-binary.operation?+0x50>
    2aa0:      	cmp	x0, #0x3b
    2aa4:      	cset	w0, eq
    2aa8:      	ubfx	x0, x0, #0, #8
    2aac:      	ret

0000000000002ab0 <_stogir.integer-unary.operation?>:
    2ab0:      	sxtw	x0, w0
    2ab4:      	cmp	x0, #0x1f
    2ab8:      	b.ne	0x2ad4 <_stogir.integer-unary.operation?+0x24>
    2abc:      	mov	x0, #0x1                ; =1
    2ac0:      	b	0x2ad0 <_stogir.integer-unary.operation?+0x20>
    2ac4:      	cmp	x0, #0x39
    2ac8:      	cset	w0, eq
    2acc:      	ubfx	x0, x0, #0, #8
    2ad0:      	ret
    2ad4:      	cmp	x0, #0x20
    2ad8:      	b.ne	0x2ae4 <_stogir.integer-unary.operation?+0x34>
    2adc:      	mov	x0, #0x1                ; =1
    2ae0:      	b	0x2ad0 <_stogir.integer-unary.operation?+0x20>
    2ae4:      	cmp	x0, #0x2d
    2ae8:      	b.ne	0x2af4 <_stogir.integer-unary.operation?+0x44>
    2aec:      	mov	x0, #0x1                ; =1
    2af0:      	b	0x2ad0 <_stogir.integer-unary.operation?+0x20>
    2af4:      	cmp	x0, #0x36
    2af8:      	b.ne	0x2b04 <_stogir.integer-unary.operation?+0x54>
    2afc:      	mov	x0, #0x1                ; =1
    2b00:      	b	0x2ad0 <_stogir.integer-unary.operation?+0x20>
    2b04:      	cmp	x0, #0x37
    2b08:      	b.ne	0x2b14 <_stogir.integer-unary.operation?+0x64>
    2b0c:      	mov	x0, #0x1                ; =1
    2b10:      	b	0x2ad0 <_stogir.integer-unary.operation?+0x20>
    2b14:      	cmp	x0, #0x38
    2b18:      	b.ne	0x2ac4 <_stogir.integer-unary.operation?+0x14>
    2b1c:      	mov	x0, #0x1                ; =1
    2b20:      	b	0x2ad0 <_stogir.integer-unary.operation?+0x20>

0000000000002b24 <_stogir.verify.classifications>:
    2b24:      	sub	sp, sp, #0xc0
    2b28:      	str	x29, [sp]
    2b2c:      	str	x30, [sp, #0x8]
    2b30:      	mov	x29, sp
    2b34:      	str	x19, [sp, #0x70]
    2b38:      	str	x20, [sp, #0x78]
    2b3c:      	str	x21, [sp, #0x80]
    2b40:      	str	x22, [sp, #0x88]
    2b44:      	str	x23, [sp, #0x90]
    2b48:      	str	x24, [sp, #0x98]
    2b4c:      	str	x25, [sp, #0xa0]
    2b50:      	str	x26, [sp, #0xa8]
    2b54:      	str	x27, [sp, #0xb0]
    2b58:      	str	x28, [sp, #0xb8]
    2b5c:      	ldr	w4, [x2]
    2b60:      	orr	x5, x4, xzr
    2b64:      	ubfx	x5, x5, #8, #8
    2b68:      	orr	x19, x5, xzr
    2b6c:      	cmp	x19, #0xf
    2b70:      	b.le	0x2bac <_stogir.verify.classifications+0x88>
    2b74:      	cmp	x19, #0x80
    2b78:      	b.ge	0x2ba0 <_stogir.verify.classifications+0x7c>
    2b7c:      	and	x5, x19, #0xf
    2b80:      	lsr	w5, w5, #0
    2b84:      	sxtw	x5, w5
    2b88:      	cmp	x5, #0x1
    2b8c:      	b.lt	0x316c <_stogir.verify.classifications+0x648>
    2b90:      	cmp	x5, #0xd
    2b94:      	cset	w5, le
    2b98:      	ubfx	x5, x5, #0, #8
    2b9c:      	b	0x3170 <_stogir.verify.classifications+0x64c>
    2ba0:      	movz	x5, #0x0, lsl #48
    2ba4:      	mov	x20, x5
    2ba8:      	b	0x2bb0 <_stogir.verify.classifications+0x8c>
    2bac:      	movz	x20, #0x0, lsl #48
    2bb0:      	uxtb	w21, w4
    2bb4:      	orr	x4, x21, xzr
    2bb8:      	lsr	w22, w4, #0
    2bbc:      	mov	x23, x0
    2bc0:      	mov	w0, w22
    2bc4:      	mov	w24, w1
    2bc8:      	mov	x25, x2
    2bcc:      	mov	w26, w3
    2bd0:      	bl	0x2bd0 <_stogir.verify.classifications+0xac>
		0000000000002bd0:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2bd4:      	cmp	x0, #0x0
    2bd8:      	b.eq	0x2bf8 <_stogir.verify.classifications+0xd4>
    2bdc:      	cmp	x20, #0x0
    2be0:      	cset	w0, ne
    2be4:      	uxtb	w16, w0
    2be8:      	cmp	w16, wzr
    2bec:      	cset	x0, eq
    2bf0:      	mov	x27, x0
    2bf4:      	b	0x2bfc <_stogir.verify.classifications+0xd8>
    2bf8:      	movz	x27, #0x0, lsl #48
    2bfc:      	cmp	x27, #0x0
    2c00:      	cset	w28, ne
    2c04:      	uxtb	w16, w28
    2c08:      	cmp	w16, wzr
    2c0c:      	b.eq	0x2c40 <_stogir.verify.classifications+0x11c>
    2c10:      	ldr	w0, [x25, #0x4]
    2c14:      	lsr	w0, w0, #0
    2c18:      	mov	w1, w0
    2c1c:      	mov	x0, x23
    2c20:      	bl	0x2c20 <_stogir.verify.classifications+0xfc>
		0000000000002c20:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2c24:      	cmp	x0, #0x0
    2c28:      	b.ne	0x2c34 <_stogir.verify.classifications+0x110>
    2c2c:      	movn	x0, #0x0, lsl #48
    2c30:      	b	0x2c3c <_stogir.verify.classifications+0x118>
    2c34:      	ldr	w0, [x0]
    2c38:      	ubfx	x0, x0, #8, #8
    2c3c:      	b	0x2c44 <_stogir.verify.classifications+0x120>
    2c40:      	movn	x0, #0x0, lsl #48
    2c44:      	lsr	w0, w0, #0
    2c48:      	sxtw	x0, w0
    2c4c:      	cmp	x0, #0xf
    2c50:      	cset	w1, gt
    2c54:      	cmp	x0, #0x80
    2c58:      	cset	w2, lt
    2c5c:      	and	x3, x0, #0xf
    2c60:      	lsr	w3, w3, #0
    2c64:      	sxtw	x3, w3
    2c68:      	cmp	x3, #0x1
    2c6c:      	cset	w4, ge
    2c70:      	cmp	x3, #0xd
    2c74:      	cset	w3, le
    2c78:      	cmp	x27, #0x0
    2c7c:      	b.eq	0x2cd4 <_stogir.verify.classifications+0x1b0>
    2c80:      	uxtb	w16, w1
    2c84:      	cmp	w16, wzr
    2c88:      	b.eq	0x3174 <_stogir.verify.classifications+0x650>
    2c8c:      	uxtb	w16, w2
    2c90:      	cmp	w16, wzr
    2c94:      	b.eq	0x3174 <_stogir.verify.classifications+0x650>
    2c98:      	uxtb	w16, w4
    2c9c:      	cmp	w16, wzr
    2ca0:      	b.eq	0x3174 <_stogir.verify.classifications+0x650>
    2ca4:      	uxtb	w16, w3
    2ca8:      	cmp	w16, wzr
    2cac:      	b.eq	0x3174 <_stogir.verify.classifications+0x650>
    2cb0:      	movz	x0, #0x0, lsl #48
    2cb4:      	b	0x2cbc <_stogir.verify.classifications+0x198>
    2cb8:      	mov	x0, #0x1                ; =1
    2cbc:      	mov	x19, x0
    2cc0:      	b	0x2cd8 <_stogir.verify.classifications+0x1b4>
    2cc4:      	movz	x3, #0x0, lsl #48
    2cc8:      	b	0x2d14 <_stogir.verify.classifications+0x1f0>
    2ccc:      	movz	x0, #0x0, lsl #48
    2cd0:      	b	0x2d1c <_stogir.verify.classifications+0x1f8>
    2cd4:      	movz	x19, #0x0, lsl #48
    2cd8:      	sxtw	x26, w26
    2cdc:      	ubfx	x21, x3, #0, #8
    2ce0:      	add	x27, x23, #0x78
    2ce4:      	add	x0, x23, #0x28
    2ce8:      	add	x3, x23, #0x50
    2cec:      	sxtw	x24, w24
    2cf0:      	add	x5, x23, #0x78
    2cf4:      	cmp	x24, #0x0
    2cf8:      	cset	w6, le
    2cfc:      	lsl	x7, x24, #2
    2d00:      	mov	x8, #0x1                ; =1
    2d04:      	b	0x2e0c <_stogir.verify.classifications+0x2e8>
    2d08:      	movz	x3, #0x0, lsl #48
    2d0c:      	b	0x2d34 <_stogir.verify.classifications+0x210>
    2d10:      	movz	x3, #0x0, lsl #48
    2d14:      	b	0x2d44 <_stogir.verify.classifications+0x220>
    2d18:      	movz	x0, #0x0, lsl #48
    2d1c:      	ldr	x5, [sp, #0x58]
    2d20:      	ldr	x6, [sp, #0x50]
    2d24:      	ldr	x8, [sp, #0x48]
    2d28:      	ldr	x1, [sp, #0x60]
    2d2c:      	b	0x2dc4 <_stogir.verify.classifications+0x2a0>
    2d30:      	movz	x3, #0x0, lsl #48
    2d34:      	ldr	x6, [sp, #0x50]
    2d38:      	ldr	x8, [sp, #0x48]
    2d3c:      	b	0x2d44 <_stogir.verify.classifications+0x220>
    2d40:      	movz	x3, #0x0, lsl #48
    2d44:      	cmp	x3, #0x0
    2d48:      	b.eq	0x2d78 <_stogir.verify.classifications+0x254>
    2d4c:      	uxtb	w16, w2
    2d50:      	cmp	w16, wzr
    2d54:      	b.eq	0x2d68 <_stogir.verify.classifications+0x244>
    2d58:      	lsl	x0, x0, #4
    2d5c:      	ldr	x2, [x23]
    2d60:      	add	x0, x0, x2
    2d64:      	b	0x2d74 <_stogir.verify.classifications+0x250>
    2d68:      	lsl	x0, x4, #4
    2d6c:      	ldr	x2, [x23, #0x28]
    2d70:      	add	x0, x0, x2
    2d74:      	b	0x2d7c <_stogir.verify.classifications+0x258>
    2d78:      	movz	x0, #0x0, lsl #48
    2d7c:      	cmp	x0, #0x0
    2d80:      	b.eq	0x2dc0 <_stogir.verify.classifications+0x29c>
    2d84:      	ldr	w0, [x0]
    2d88:      	ubfx	x0, x0, #8, #8
    2d8c:      	cmp	x0, #0xf
    2d90:      	b.le	0x2dc0 <_stogir.verify.classifications+0x29c>
    2d94:      	cmp	x0, #0x80
    2d98:      	b.ge	0x2dc0 <_stogir.verify.classifications+0x29c>
    2d9c:      	and	x0, x0, #0xf
    2da0:      	lsr	w0, w0, #0
    2da4:      	sxtw	x0, w0
    2da8:      	cmp	x0, #0x1
    2dac:      	b.lt	0x2dc0 <_stogir.verify.classifications+0x29c>
    2db0:      	cmp	x0, #0xd
    2db4:      	b.gt	0x2dc0 <_stogir.verify.classifications+0x29c>
    2db8:      	mov	x0, #0x1                ; =1
    2dbc:      	b	0x2dc4 <_stogir.verify.classifications+0x2a0>
    2dc0:      	ldr	x0, [sp, #0x40]
    2dc4:      	add	x2, x27, #0x1
    2dc8:      	lsr	w2, w2, #0
    2dcc:      	sxtw	x2, w2
    2dd0:      	mov	w4, w26
    2dd4:      	ldr	x26, [sp, #0x30]
    2dd8:      	mov	x27, x5
    2ddc:      	mov	x3, x8
    2de0:      	mov	x7, x1
    2de4:      	mov	w1, w21
    2de8:      	ldr	x21, [sp, #0x20]
    2dec:      	mov	x5, x20
    2df0:      	mov	x20, x0
    2df4:      	mov	x0, x6
    2df8:      	mov	w6, w19
    2dfc:      	ldr	x19, [sp, #0x38]
    2e00:      	mov	x8, x2
    2e04:      	mov	w2, w22
    2e08:      	ldr	w22, [sp, #0x28]
    2e0c:      	cmp	x20, #0x0
    2e10:      	b.ne	0x31d8 <_stogir.verify.classifications+0x6b4>
    2e14:      	cmp	x8, x26
    2e18:      	b.gt	0x31e4 <_stogir.verify.classifications+0x6c0>
    2e1c:      	lsr	w9, w8, #0
    2e20:      	str	x0, [sp, #0x50]
    2e24:      	mov	w0, w22
    2e28:      	str	x3, [sp, #0x48]
    2e2c:      	str	x7, [sp, #0x60]
    2e30:      	str	w9, [sp, #0x68]
    2e34:      	str	x21, [sp, #0x20]
    2e38:      	mov	w21, w1
    2e3c:      	mov	w1, w9
    2e40:      	str	w22, [sp, #0x28]
    2e44:      	mov	w22, w2
    2e48:      	str	x26, [sp, #0x30]
    2e4c:      	mov	w26, w4
    2e50:      	str	x19, [sp, #0x38]
    2e54:      	mov	w19, w6
    2e58:      	str	x20, [sp, #0x40]
    2e5c:      	mov	x20, x5
    2e60:      	str	x27, [sp, #0x58]
    2e64:      	mov	x27, x8
    2e68:      	bl	0x2e68 <_stogir.verify.classifications+0x344>
		0000000000002e68:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    2e6c:      	lsr	w0, w0, #0
    2e70:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x124c>
		0000000000002e70:  ARM64_RELOC_PAGE21	l_stogir.340
    2e74:      	ldr	x16, [x16]
		0000000000002e74:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    2e78:      	ldr	w1, [x16]
    2e7c:      	cmp	x0, x1
    2e80:      	b.eq	0x2eb0 <_stogir.verify.classifications+0x38c>
    2e84:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x124c>
		0000000000002e84:  ARM64_RELOC_PAGE21	l_stogir.341
    2e88:      	ldr	x16, [x16]
		0000000000002e88:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    2e8c:      	ldr	w1, [x16]
    2e90:      	cmp	x0, x1
    2e94:      	b.eq	0x2eb0 <_stogir.verify.classifications+0x38c>
    2e98:      	ldr	x5, [sp, #0x58]
    2e9c:      	ldr	x6, [sp, #0x50]
    2ea0:      	ldr	x8, [sp, #0x48]
    2ea4:      	ldr	x1, [sp, #0x60]
    2ea8:      	ldr	x0, [sp, #0x40]
    2eac:      	b	0x2dc4 <_stogir.verify.classifications+0x2a0>
    2eb0:      	cmp	x27, #0x1
    2eb4:      	b.ne	0x2ef0 <_stogir.verify.classifications+0x3cc>
    2eb8:      	uxtb	w16, w28
    2ebc:      	cmp	w16, wzr
    2ec0:      	b.eq	0x2ef0 <_stogir.verify.classifications+0x3cc>
    2ec4:      	uxtb	w16, w21
    2ec8:      	cmp	w16, wzr
    2ecc:      	b.eq	0x2d18 <_stogir.verify.classifications+0x1f4>
    2ed0:      	uxtb	w16, w22
    2ed4:      	cmp	w16, wzr
    2ed8:      	b.eq	0x2ccc <_stogir.verify.classifications+0x1a8>
    2edc:      	uxtb	w16, w26
    2ee0:      	cmp	w16, wzr
    2ee4:      	b.eq	0x30a4 <_stogir.verify.classifications+0x580>
    2ee8:      	ldr	x0, [sp, #0x20]
    2eec:      	b	0x30a8 <_stogir.verify.classifications+0x584>
    2ef0:      	cmp	x27, #0x1
    2ef4:      	b.ne	0x2f6c <_stogir.verify.classifications+0x448>
    2ef8:      	ldr	w0, [x25, #0x4]
    2efc:      	sxtw	x0, w0
    2f00:      	ldr	x1, [sp, #0x60]
    2f04:      	lsr	w0, w0, #0
    2f08:      	sxtw	x0, w0
    2f0c:      	cmp	x0, #0x0
    2f10:      	cset	w2, gt
    2f14:      	movz	x16, #0x0, lsl #48
    2f18:      	sub	x3, x16, x0
    2f1c:      	sub	x4, x3, #0x1
    2f20:      	uxtb	w16, w2
    2f24:      	cmp	w16, wzr
    2f28:      	b.eq	0x31f0 <_stogir.verify.classifications+0x6cc>
    2f2c:      	ldr	x3, [x23, #0x8]
    2f30:      	cmp	x0, x3
    2f34:      	b.ge	0x31f8 <_stogir.verify.classifications+0x6d4>
    2f38:      	ldr	x5, [sp, #0x58]
    2f3c:      	ldr	x3, [x5, #0x8]
    2f40:      	cmp	x0, x3
    2f44:      	b.ge	0x2d08 <_stogir.verify.classifications+0x1e4>
    2f48:      	lsl	x3, x0, #2
    2f4c:      	ldr	x6, [x23, #0x78]
    2f50:      	add	x3, x3, x6
    2f54:      	ldr	w3, [x3]
    2f58:      	sxtw	x3, w3
    2f5c:      	cmp	x3, #0x0
    2f60:      	cset	w3, ge
    2f64:      	ubfx	x3, x3, #0, #8
    2f68:      	b	0x2d0c <_stogir.verify.classifications+0x1e8>
    2f6c:      	cmp	x27, #0x2
    2f70:      	b.ne	0x2fd0 <_stogir.verify.classifications+0x4ac>
    2f74:      	ldr	w0, [x25, #0x8]
    2f78:      	sxtw	x0, w0
    2f7c:      	ldr	x1, [sp, #0x60]
    2f80:      	b	0x2f04 <_stogir.verify.classifications+0x3e0>
    2f84:      	cmp	x0, #0x0
    2f88:      	b.ge	0x3200 <_stogir.verify.classifications+0x6dc>
    2f8c:      	ldr	x6, [sp, #0x50]
    2f90:      	ldr	x7, [x6, #0x8]
    2f94:      	ldr	x8, [sp, #0x48]
    2f98:      	ldr	x9, [x8, #0x8]
    2f9c:      	cmp	x7, x9
    2fa0:      	b.ne	0x2d10 <_stogir.verify.classifications+0x1ec>
    2fa4:      	cmp	x3, x7
    2fa8:      	b.gt	0x2cc4 <_stogir.verify.classifications+0x1a0>
    2fac:      	lsl	x3, x4, #2
    2fb0:      	ldr	x7, [x23, #0x50]
    2fb4:      	add	x3, x3, x7
    2fb8:      	ldr	w3, [x3]
    2fbc:      	sxtw	x3, w3
    2fc0:      	cmp	x3, #0x0
    2fc4:      	cset	w3, gt
    2fc8:      	ubfx	x3, x3, #0, #8
    2fcc:      	b	0x2cc8 <_stogir.verify.classifications+0x1a4>
    2fd0:      	cmp	x27, #0x3
    2fd4:      	b.ne	0x3054 <_stogir.verify.classifications+0x530>
    2fd8:      	ldr	w0, [x25, #0xc]
    2fdc:      	sxtw	x0, w0
    2fe0:      	ldr	x1, [sp, #0x60]
    2fe4:      	b	0x2f80 <_stogir.verify.classifications+0x45c>
    2fe8:      	ldr	x0, [sp, #0x40]
    2fec:      	uxtb	w0, w0
    2ff0:      	ldr	x1, [sp, #0x38]
    2ff4:      	uxtb	w1, w1
    2ff8:      	add	x16, sp, #0x10
    2ffc:      	movz	w17, #0x0, lsl #16
    3000:      	strh	w17, [x16]
    3004:      	add	x16, sp, #0x10
    3008:      	strb	w0, [x16]
    300c:      	add	x16, sp, #0x10
    3010:      	strb	w1, [x16, #0x1]
    3014:      	add	x16, sp, #0x10
    3018:      	ldrh	w0, [x16]
    301c:      	ldr	x19, [sp, #0x70]
    3020:      	ldr	x20, [sp, #0x78]
    3024:      	ldr	x21, [sp, #0x80]
    3028:      	ldr	x22, [sp, #0x88]
    302c:      	ldr	x23, [sp, #0x90]
    3030:      	ldr	x24, [sp, #0x98]
    3034:      	ldr	x25, [sp, #0xa0]
    3038:      	ldr	x26, [sp, #0xa8]
    303c:      	ldr	x27, [sp, #0xb0]
    3040:      	ldr	x28, [sp, #0xb8]
    3044:      	ldr	x29, [sp]
    3048:      	ldr	x30, [sp, #0x8]
    304c:      	add	sp, sp, #0xc0
    3050:      	ret
    3054:      	uxtb	w16, w19
    3058:      	cmp	w16, wzr
    305c:      	b.eq	0x30bc <_stogir.verify.classifications+0x598>
    3060:      	ldr	x1, [sp, #0x60]
    3064:      	movz	x0, #0x0, lsl #48
    3068:      	movz	x2, #0x0, lsl #48
    306c:      	lsr	w0, w0, #0
    3070:      	lsr	x16, x0, #0
    3074:      	cmp	x16, #0x1
    3078:      	b.eq	0x3094 <_stogir.verify.classifications+0x570>
    307c:      	b.lo	0x3084 <_stogir.verify.classifications+0x560>
    3080:      	b	0x3098 <_stogir.verify.classifications+0x574>
    3084:      	cmp	x16, #0x0
    3088:      	b.eq	0x3090 <_stogir.verify.classifications+0x56c>
    308c:      	b	0x3098 <_stogir.verify.classifications+0x574>
    3090:      	b	0x309c <_stogir.verify.classifications+0x578>
    3094:      	b	0x30ac <_stogir.verify.classifications+0x588>
    3098:      	b	0x31d0 <_stogir.verify.classifications+0x6ac>
    309c:      	movz	x0, #0x0, lsl #48
    30a0:      	b	0x30b8 <_stogir.verify.classifications+0x594>
    30a4:      	movz	x0, #0x0, lsl #48
    30a8:      	b	0x2cd0 <_stogir.verify.classifications+0x1ac>
    30ac:      	lsr	w2, w2, #0
    30b0:      	sxtw	x2, w2
    30b4:      	mov	x0, x2
    30b8:      	b	0x2fe4 <_stogir.verify.classifications+0x4c0>
    30bc:      	ldr	x0, [x23, #0x8]
    30c0:      	cmp	x24, x0
    30c4:      	b.ge	0x320c <_stogir.verify.classifications+0x6e8>
    30c8:      	ldr	x0, [x20, #0x8]
    30cc:      	cmp	x24, x0
    30d0:      	b.ge	0x3214 <_stogir.verify.classifications+0x6f0>
    30d4:      	ldr	x0, [x23, #0x78]
    30d8:      	ldr	x1, [sp, #0x60]
    30dc:      	add	x0, x1, x0
    30e0:      	ldr	w0, [x0]
    30e4:      	sxtw	x0, w0
    30e8:      	cmp	x0, #0x0
    30ec:      	b.lt	0x3064 <_stogir.verify.classifications+0x540>
    30f0:      	ldr	w0, [sp, #0x68]
    30f4:      	sxtw	x0, w0
    30f8:      	cmp	x0, #0x1
    30fc:      	b.lt	0x31b4 <_stogir.verify.classifications+0x690>
    3100:      	ldr	x2, [x23, #0x78]
    3104:      	add	x2, x1, x2
    3108:      	ldr	w2, [x2]
    310c:      	sxtw	x2, w2
    3110:      	cmp	x0, x2
    3114:      	b.gt	0x31b4 <_stogir.verify.classifications+0x690>
    3118:      	ldr	x2, [x23]
    311c:      	asr	x16, x0, #63
    3120:      	lsr	x16, x16, #62
    3124:      	add	x3, x0, x16
    3128:      	asr	x3, x3, #2
    312c:      	asr	x16, x0, #63
    3130:      	lsr	x16, x16, #62
    3134:      	add	x0, x0, x16
    3138:      	and	x0, x0, #0x3
    313c:      	sub	x0, x0, x16
    3140:      	add	x3, x3, x24
    3144:      	lsl	x0, x0, #2
    3148:      	lsl	x3, x3, #4
    314c:      	add	x2, x3, x2
    3150:      	add	x0, x0, x2
    3154:      	ldr	w0, [x0]
    3158:      	sxtw	x0, w0
    315c:      	and	x0, x0, #0xffffffff
    3160:      	mov	x2, x0
    3164:      	mov	x0, #0x1                ; =1
    3168:      	b	0x31bc <_stogir.verify.classifications+0x698>
    316c:      	movz	x5, #0x0, lsl #48
    3170:      	b	0x2ba4 <_stogir.verify.classifications+0x80>
    3174:      	cmp	x21, #0x18
    3178:      	b.ne	0x3184 <_stogir.verify.classifications+0x660>
    317c:      	mov	x0, #0x1                ; =1
    3180:      	b	0x2cbc <_stogir.verify.classifications+0x198>
    3184:      	cmp	x21, #0x19
    3188:      	b.ne	0x3194 <_stogir.verify.classifications+0x670>
    318c:      	mov	x0, #0x1                ; =1
    3190:      	b	0x2cbc <_stogir.verify.classifications+0x198>
    3194:      	cmp	x19, #0xc
    3198:      	b.eq	0x2cb8 <_stogir.verify.classifications+0x194>
    319c:      	cmp	x19, #0xd
    31a0:      	b.eq	0x2cb8 <_stogir.verify.classifications+0x194>
    31a4:      	cmp	x0, #0xc
    31a8:      	b.ne	0x31c0 <_stogir.verify.classifications+0x69c>
    31ac:      	mov	x0, #0x1                ; =1
    31b0:      	b	0x31cc <_stogir.verify.classifications+0x6a8>
    31b4:      	movz	x0, #0x0, lsl #48
    31b8:      	movz	x2, #0x0, lsl #48
    31bc:      	b	0x306c <_stogir.verify.classifications+0x548>
    31c0:      	cmp	x0, #0xd
    31c4:      	cset	w0, eq
    31c8:      	ubfx	x0, x0, #0, #8
    31cc:      	b	0x2cbc <_stogir.verify.classifications+0x198>
    31d0:      	brk	#0
    31d4:      	b	0x31d0 <_stogir.verify.classifications+0x6ac>
    31d8:      	str	x19, [sp, #0x38]
    31dc:      	str	x20, [sp, #0x40]
    31e0:      	b	0x2fe8 <_stogir.verify.classifications+0x4c4>
    31e4:      	str	x19, [sp, #0x38]
    31e8:      	str	x20, [sp, #0x40]
    31ec:      	b	0x2fe8 <_stogir.verify.classifications+0x4c4>
    31f0:      	ldr	x5, [sp, #0x58]
    31f4:      	b	0x2f84 <_stogir.verify.classifications+0x460>
    31f8:      	ldr	x5, [sp, #0x58]
    31fc:      	b	0x2d30 <_stogir.verify.classifications+0x20c>
    3200:      	ldr	x6, [sp, #0x50]
    3204:      	ldr	x8, [sp, #0x48]
    3208:      	b	0x2d40 <_stogir.verify.classifications+0x21c>
    320c:      	ldr	x1, [sp, #0x60]
    3210:      	b	0x3064 <_stogir.verify.classifications+0x540>
    3214:      	ldr	x1, [sp, #0x60]
    3218:      	b	0x3064 <_stogir.verify.classifications+0x540>

000000000000321c <_stogir.vector-lanes.operation?>:
    321c:      	sxtw	x0, w0
    3220:      	cmp	x0, #0x3d
    3224:      	b.lt	0x3238 <_stogir.vector-lanes.operation?+0x1c>
    3228:      	cmp	x0, #0x3f
    322c:      	cset	w0, le
    3230:      	ubfx	x0, x0, #0, #8
    3234:      	b	0x323c <_stogir.vector-lanes.operation?+0x20>
    3238:      	movz	x0, #0x0, lsl #48
    323c:      	ret

0000000000003240 <_stogir.vector.validate>:
    3240:      	sub	sp, sp, #0x210
    3244:      	str	x29, [sp]
    3248:      	str	x30, [sp, #0x8]
    324c:      	mov	x29, sp
    3250:      	str	x19, [sp, #0x1c0]
    3254:      	str	x20, [sp, #0x1c8]
    3258:      	str	x21, [sp, #0x1d0]
    325c:      	str	x22, [sp, #0x1d8]
    3260:      	str	x23, [sp, #0x1e0]
    3264:      	str	x24, [sp, #0x1e8]
    3268:      	str	x25, [sp, #0x1f0]
    326c:      	str	x26, [sp, #0x1f8]
    3270:      	str	x27, [sp, #0x200]
    3274:      	str	x28, [sp, #0x208]
    3278:      	lsr	w19, w1, #0
    327c:      	mov	x20, x8
    3280:      	add	x8, sp, #0x10
    3284:      	mov	x21, x0
    3288:      	mov	w22, w1
    328c:      	mov	w1, w19
    3290:      	mov	w23, w2
    3294:      	bl	0x3294 <_stogir.vector.validate+0x54>
		0000000000003294:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3298:      	add	x16, sp, #0x10
    329c:      	ldr	w0, [x16]
    32a0:      	lsr	x16, x0, #0
    32a4:      	cmp	x16, #0x1
    32a8:      	b.eq	0x32c4 <_stogir.vector.validate+0x84>
    32ac:      	b.lo	0x32b4 <_stogir.vector.validate+0x74>
    32b0:      	b	0x32c8 <_stogir.vector.validate+0x88>
    32b4:      	cmp	x16, #0x0
    32b8:      	b.eq	0x32c0 <_stogir.vector.validate+0x80>
    32bc:      	b	0x32c8 <_stogir.vector.validate+0x88>
    32c0:      	b	0x32cc <_stogir.vector.validate+0x8c>
    32c4:      	b	0x3364 <_stogir.vector.validate+0x124>
    32c8:      	b	0x3584 <_stogir.vector.validate+0x344>
    32cc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		00000000000032cc:  ARM64_RELOC_PAGE21	l_stogir.342
    32d0:      	ldr	x16, [x16]
		00000000000032d0:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    32d4:      	orr	x0, x16, xzr
    32d8:      	str	x20, [sp, #0x1a8]
    32dc:      	mov	x1, x0
    32e0:      	mov	x0, #0x1                ; =1
    32e4:      	mov	x2, #0x1a               ; =26
    32e8:      	b	0x331c <_stogir.vector.validate+0xdc>
    32ec:      	lsr	w23, w23, #0
    32f0:      	add	x8, sp, #0x70
    32f4:      	mov	x0, x21
    32f8:      	ldr	w1, [sp, #0x1a0]
    32fc:      	mov	w2, w23
    3300:      	bl	0x3300 <_stogir.vector.validate+0xc0>
		0000000000003300:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    3304:      	add	x16, sp, #0x70
    3308:      	ldr	x0, [x16]
    330c:      	add	x16, sp, #0x70
    3310:      	ldr	x1, [x16, #0x8]
    3314:      	add	x16, sp, #0x70
    3318:      	ldr	x2, [x16, #0x10]
    331c:      	ldr	x3, [sp, #0x1a8]
    3320:      	str	x0, [x3]
    3324:      	str	x1, [x3, #0x8]
    3328:      	str	x2, [x3, #0x10]
    332c:      	ldr	x19, [sp, #0x1c0]
    3330:      	ldr	x20, [sp, #0x1c8]
    3334:      	ldr	x21, [sp, #0x1d0]
    3338:      	ldr	x22, [sp, #0x1d8]
    333c:      	ldr	x23, [sp, #0x1e0]
    3340:      	ldr	x24, [sp, #0x1e8]
    3344:      	ldr	x25, [sp, #0x1f0]
    3348:      	ldr	x26, [sp, #0x1f8]
    334c:      	ldr	x27, [sp, #0x200]
    3350:      	ldr	x28, [sp, #0x208]
    3354:      	ldr	x29, [sp]
    3358:      	ldr	x30, [sp, #0x8]
    335c:      	add	sp, sp, #0x210
    3360:      	ret
    3364:      	sxtw	x22, w22
    3368:      	add	x16, sp, #0x10
    336c:      	orr	x0, x16, xzr
    3370:      	cmp	x22, #0x0
    3374:      	cset	w24, le
    3378:      	add	x0, x0, #0x8
    337c:      	add	x16, sp, #0x10
    3380:      	ldr	x25, [x16, #0x8]
    3384:      	add	x16, sp, #0x40
    3388:      	str	x25, [x16]
    338c:      	ldr	x0, [x0, #0x8]
    3390:      	add	x16, sp, #0x40
    3394:      	str	x0, [x16, #0x8]
    3398:      	uxtb	w16, w24
    339c:      	cmp	w16, wzr
    33a0:      	b.eq	0x33c4 <_stogir.vector.validate+0x184>
    33a4:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		00000000000033a4:  ARM64_RELOC_PAGE21	l_stogir.343
    33a8:      	ldr	x16, [x16]
		00000000000033a8:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    33ac:      	orr	x0, x16, xzr
    33b0:      	str	x20, [sp, #0x1a8]
    33b4:      	mov	x1, x0
    33b8:      	mov	x0, #0x1                ; =1
    33bc:      	mov	x2, #0x3b               ; =59
    33c0:      	b	0x331c <_stogir.vector.validate+0xdc>
    33c4:      	lsl	x26, x22, #2
    33c8:      	uxtb	w0, w25
    33cc:      	orr	x27, x0, xzr
    33d0:      	ldr	x0, [x21, #0x78]
    33d4:      	cmp	x27, #0x44
    33d8:      	cset	w1, eq
    33dc:      	add	x0, x26, x0
    33e0:      	ldr	w28, [x0]
    33e4:      	cmp	x27, #0x24
    33e8:      	b.ne	0x342c <_stogir.vector.validate+0x1ec>
    33ec:      	str	x20, [sp, #0x1a8]
    33f0:      	str	w19, [sp, #0x1a0]
    33f4:      	uxtb	w16, w1
    33f8:      	cmp	w16, wzr
    33fc:      	b.eq	0x32ec <_stogir.vector.validate+0xac>
    3400:      	add	x8, sp, #0x50
    3404:      	mov	x0, x21
    3408:      	ldr	w1, [sp, #0x1a0]
    340c:      	bl	0x340c <_stogir.vector.validate+0x1cc>
		000000000000340c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    3410:      	add	x16, sp, #0x50
    3414:      	ldr	x0, [x16]
    3418:      	add	x16, sp, #0x50
    341c:      	ldr	x1, [x16, #0x8]
    3420:      	add	x16, sp, #0x50
    3424:      	ldr	x2, [x16, #0x10]
    3428:      	b	0x331c <_stogir.vector.validate+0xdc>
    342c:      	uxtb	w16, w1
    3430:      	cmp	w16, wzr
    3434:      	b.ne	0x3cfc <_stogir.vector.validate+0xabc>
    3438:      	cmp	x27, #0x3c
    343c:      	b.ne	0x34f0 <_stogir.vector.validate+0x2b0>
    3440:      	add	x8, sp, #0x90
    3444:      	mov	x0, x21
    3448:      	mov	w1, w19
    344c:      	bl	0x344c <_stogir.vector.validate+0x20c>
		000000000000344c:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    3450:      	add	x16, sp, #0x90
    3454:      	ldr	x0, [x16]
    3458:      	add	x16, sp, #0x90
    345c:      	ldr	x1, [x16, #0x8]
    3460:      	add	x16, sp, #0x90
    3464:      	ldr	x2, [x16, #0x10]
    3468:      	str	x20, [sp, #0x1a8]
    346c:      	b	0x34ec <_stogir.vector.validate+0x2ac>
    3470:      	cmp	x27, #0x41
    3474:      	cset	w0, eq
    3478:      	cmp	x27, #0x48
    347c:      	cset	w1, eq
    3480:      	cmp	x27, #0x55
    3484:      	cset	w2, ge
    3488:      	cmp	x27, #0x58
    348c:      	cset	w3, le
    3490:      	cmp	x27, #0x47
    3494:      	b.ne	0x358c <_stogir.vector.validate+0x34c>
    3498:      	str	x20, [sp, #0x1a8]
    349c:      	str	w19, [sp, #0x1a0]
    34a0:      	mov	w19, w0
    34a4:      	mov	w20, w1
    34a8:      	str	w2, [sp, #0x1b0]
    34ac:      	str	w3, [sp, #0x1b8]
    34b0:      	mov	x0, x21
    34b4:      	ldr	w1, [sp, #0x1a0]
    34b8:      	bl	0x34b8 <_stogir.vector.validate+0x278>
		00000000000034b8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    34bc:      	cmp	x0, #0x0
    34c0:      	b.eq	0x35b0 <_stogir.vector.validate+0x370>
    34c4:      	add	x8, sp, #0xf0
    34c8:      	mov	x0, x21
    34cc:      	ldr	w1, [sp, #0x1a0]
    34d0:      	bl	0x34d0 <_stogir.vector.validate+0x290>
		00000000000034d0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    34d4:      	add	x16, sp, #0xf0
    34d8:      	ldr	x0, [x16]
    34dc:      	add	x16, sp, #0xf0
    34e0:      	ldr	x1, [x16, #0x8]
    34e4:      	add	x16, sp, #0xf0
    34e8:      	ldr	x2, [x16, #0x10]
    34ec:      	b	0x331c <_stogir.vector.validate+0xdc>
    34f0:      	cmp	x27, #0x3d
    34f4:      	b.lt	0x3538 <_stogir.vector.validate+0x2f8>
    34f8:      	cmp	x27, #0x3f
    34fc:      	b.gt	0x3538 <_stogir.vector.validate+0x2f8>
    3500:      	lsr	w23, w23, #0
    3504:      	add	x8, sp, #0xb0
    3508:      	mov	x0, x21
    350c:      	mov	w1, w19
    3510:      	mov	w2, w23
    3514:      	bl	0x3514 <_stogir.vector.validate+0x2d4>
		0000000000003514:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    3518:      	add	x16, sp, #0xb0
    351c:      	ldr	x0, [x16]
    3520:      	add	x16, sp, #0xb0
    3524:      	ldr	x1, [x16, #0x8]
    3528:      	add	x16, sp, #0xb0
    352c:      	ldr	x2, [x16, #0x10]
    3530:      	str	x20, [sp, #0x1a8]
    3534:      	b	0x34ec <_stogir.vector.validate+0x2ac>
    3538:      	mov	x0, x21
    353c:      	mov	w1, w19
    3540:      	bl	0x3540 <_stogir.vector.validate+0x300>
		0000000000003540:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    3544:      	cmp	x0, #0x0
    3548:      	b.eq	0x3470 <_stogir.vector.validate+0x230>
    354c:      	lsr	w23, w23, #0
    3550:      	add	x8, sp, #0xd0
    3554:      	mov	x0, x21
    3558:      	mov	w1, w19
    355c:      	mov	w2, w23
    3560:      	bl	0x3560 <_stogir.vector.validate+0x320>
		0000000000003560:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    3564:      	add	x16, sp, #0xd0
    3568:      	ldr	x0, [x16]
    356c:      	add	x16, sp, #0xd0
    3570:      	ldr	x1, [x16, #0x8]
    3574:      	add	x16, sp, #0xd0
    3578:      	ldr	x2, [x16, #0x10]
    357c:      	str	x20, [sp, #0x1a8]
    3580:      	b	0x34ec <_stogir.vector.validate+0x2ac>
    3584:      	brk	#0
    3588:      	b	0x3584 <_stogir.vector.validate+0x344>
    358c:      	cmp	x27, #0x4f
    3590:      	b.ne	0x362c <_stogir.vector.validate+0x3ec>
    3594:      	str	x20, [sp, #0x1a8]
    3598:      	str	w19, [sp, #0x1a0]
    359c:      	mov	w19, w0
    35a0:      	mov	w20, w1
    35a4:      	str	w2, [sp, #0x1b0]
    35a8:      	str	w3, [sp, #0x1b8]
    35ac:      	b	0x34b0 <_stogir.vector.validate+0x270>
    35b0:      	uxtb	w16, w19
    35b4:      	cmp	w16, wzr
    35b8:      	b.ne	0x35f8 <_stogir.vector.validate+0x3b8>
    35bc:      	uxtb	w16, w20
    35c0:      	cmp	w16, wzr
    35c4:      	b.ne	0x35f8 <_stogir.vector.validate+0x3b8>
    35c8:      	ldr	w0, [sp, #0x1b0]
    35cc:      	uxtb	w16, w0
    35d0:      	cmp	w16, wzr
    35d4:      	b.eq	0x35e8 <_stogir.vector.validate+0x3a8>
    35d8:      	ldr	w0, [sp, #0x1b8]
    35dc:      	uxtb	w16, w0
    35e0:      	cmp	w16, wzr
    35e4:      	b.ne	0x35f8 <_stogir.vector.validate+0x3b8>
    35e8:      	movz	x0, #0x0, lsl #48
    35ec:      	movz	x1, #0x0, lsl #48
    35f0:      	movz	x2, #0x0, lsl #48
    35f4:      	b	0x3628 <_stogir.vector.validate+0x3e8>
    35f8:      	lsr	w23, w23, #0
    35fc:      	add	x8, sp, #0x110
    3600:      	mov	x0, x21
    3604:      	ldr	w1, [sp, #0x1a0]
    3608:      	mov	w2, w23
    360c:      	bl	0x360c <_stogir.vector.validate+0x3cc>
		000000000000360c:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    3610:      	add	x16, sp, #0x110
    3614:      	ldr	x0, [x16]
    3618:      	add	x16, sp, #0x110
    361c:      	ldr	x1, [x16, #0x8]
    3620:      	add	x16, sp, #0x110
    3624:      	ldr	x2, [x16, #0x10]
    3628:      	b	0x34ec <_stogir.vector.validate+0x2ac>
    362c:      	cmp	x27, #0x50
    3630:      	b.eq	0x3d08 <_stogir.vector.validate+0xac8>
    3634:      	cmp	x27, #0x78
    3638:      	b.ne	0x3658 <_stogir.vector.validate+0x418>
    363c:      	str	x20, [sp, #0x1a8]
    3640:      	str	w19, [sp, #0x1a0]
    3644:      	mov	w19, w0
    3648:      	mov	w20, w1
    364c:      	str	w2, [sp, #0x1b0]
    3650:      	str	w3, [sp, #0x1b8]
    3654:      	b	0x34b0 <_stogir.vector.validate+0x270>
    3658:      	uxtb	w16, w0
    365c:      	cmp	w16, wzr
    3660:      	b.ne	0x3760 <_stogir.vector.validate+0x520>
    3664:      	uxtb	w16, w1
    3668:      	cmp	w16, wzr
    366c:      	b.ne	0x3760 <_stogir.vector.validate+0x520>
    3670:      	uxtb	w16, w2
    3674:      	cmp	w16, wzr
    3678:      	b.eq	0x3688 <_stogir.vector.validate+0x448>
    367c:      	uxtb	w16, w3
    3680:      	cmp	w16, wzr
    3684:      	b.ne	0x3760 <_stogir.vector.validate+0x520>
    3688:      	str	w2, [sp, #0x1b0]
    368c:      	str	w3, [sp, #0x1b8]
    3690:      	str	w19, [sp, #0x1a0]
    3694:      	str	x20, [sp, #0x1a8]
    3698:      	mov	w20, w1
    369c:      	mov	w1, w19
    36a0:      	mov	w19, w0
    36a4:      	mov	x0, x21
    36a8:      	bl	0x36a8 <_stogir.vector.validate+0x468>
		00000000000036a8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    36ac:      	cmp	x0, #0x0
    36b0:      	b.ne	0x34b0 <_stogir.vector.validate+0x270>
    36b4:      	sxtw	x28, w28
    36b8:      	lsr	w25, w25, #0
    36bc:      	ubfx	x0, x25, #8, #8
    36c0:      	orr	x1, x0, xzr
    36c4:      	lsr	w19, w1, #0
    36c8:      	cmp	x27, #0x5b
    36cc:      	b.eq	0x3798 <_stogir.vector.validate+0x558>
    36d0:      	cmp	x27, #0x5c
    36d4:      	b.eq	0x3798 <_stogir.vector.validate+0x558>
    36d8:      	orr	x20, x0, xzr
    36dc:      	cmp	x27, #0x5d
    36e0:      	b.eq	0x3810 <_stogir.vector.validate+0x5d0>
    36e4:      	cmp	x27, #0x5e
    36e8:      	b.eq	0x3810 <_stogir.vector.validate+0x5d0>
    36ec:      	cmp	x27, #0x43
    36f0:      	b.ne	0x388c <_stogir.vector.validate+0x64c>
    36f4:      	cmp	x20, #0xf
    36f8:      	b.le	0x3bb0 <_stogir.vector.validate+0x970>
    36fc:      	cmp	x20, #0x80
    3700:      	b.ge	0x3bb0 <_stogir.vector.validate+0x970>
    3704:      	and	x0, x20, #0xf
    3708:      	lsr	w0, w0, #0
    370c:      	sxtw	x0, w0
    3710:      	cmp	x0, #0x1
    3714:      	b.lt	0x3bb0 <_stogir.vector.validate+0x970>
    3718:      	cmp	x0, #0xd
    371c:      	b.gt	0x3bb0 <_stogir.vector.validate+0x970>
    3720:      	lsr	w23, w23, #0
    3724:      	mov	w0, w19
    3728:      	mov	w1, w23
    372c:      	bl	0x372c <_stogir.vector.validate+0x4ec>
		000000000000372c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3730:      	lsr	w0, w0, #0
    3734:      	sxtw	x0, w0
    3738:      	cmp	x0, #0x0
    373c:      	b.le	0x3bb0 <_stogir.vector.validate+0x970>
    3740:      	cmp	x28, #0x3
    3744:      	b.lt	0x3bb0 <_stogir.vector.validate+0x970>
    3748:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		0000000000003748:  ARM64_RELOC_PAGE21	l_stogir.344
    374c:      	ldr	x16, [x16]
		000000000000374c:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    3750:      	orr	x0, x16, xzr
    3754:      	mov	x25, x0
    3758:      	movz	x27, #0x0, lsl #48
    375c:      	b	0x3bc4 <_stogir.vector.validate+0x984>
    3760:      	str	x20, [sp, #0x1a8]
    3764:      	str	w19, [sp, #0x1a0]
    3768:      	mov	w19, w0
    376c:      	mov	w20, w1
    3770:      	str	w2, [sp, #0x1b0]
    3774:      	str	w3, [sp, #0x1b8]
    3778:      	b	0x34b0 <_stogir.vector.validate+0x270>
    377c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		000000000000377c:  ARM64_RELOC_PAGE21	l_stogir.345
    3780:      	ldr	x16, [x16]
		0000000000003780:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    3784:      	orr	x0, x16, xzr
    3788:      	mov	x1, x0
    378c:      	mov	x0, #0x1                ; =1
    3790:      	mov	x2, #0x19               ; =25
    3794:      	b	0x34ec <_stogir.vector.validate+0x2ac>
    3798:      	cmp	x28, #0x2
    379c:      	b.ne	0x377c <_stogir.vector.validate+0x53c>
    37a0:      	lsr	w23, w23, #0
    37a4:      	add	x16, sp, #0x40
    37a8:      	ldr	w0, [x16, #0x4]
    37ac:      	add	x16, sp, #0x40
    37b0:      	ldr	w1, [x16, #0x8]
    37b4:      	lsr	w0, w0, #0
    37b8:      	lsr	w1, w1, #0
    37bc:      	add	x8, sp, #0x130
    37c0:      	mov	w2, w23
    37c4:      	mov	w3, w0
    37c8:      	mov	x0, x21
    37cc:      	mov	w4, w1
    37d0:      	mov	w1, w19
    37d4:      	bl	0x37d4 <_stogir.vector.validate+0x594>
		00000000000037d4:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    37d8:      	add	x16, sp, #0x130
    37dc:      	ldr	x0, [x16]
    37e0:      	add	x16, sp, #0x130
    37e4:      	ldr	x1, [x16, #0x8]
    37e8:      	add	x16, sp, #0x130
    37ec:      	ldr	x2, [x16, #0x10]
    37f0:      	b	0x3794 <_stogir.vector.validate+0x554>
    37f4:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		00000000000037f4:  ARM64_RELOC_PAGE21	l_stogir.346
    37f8:      	ldr	x16, [x16]
		00000000000037f8:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    37fc:      	orr	x0, x16, xzr
    3800:      	mov	x1, x0
    3804:      	mov	x0, #0x1                ; =1
    3808:      	mov	x2, #0x1a               ; =26
    380c:      	b	0x3794 <_stogir.vector.validate+0x554>
    3810:      	cmp	x28, #0x3
    3814:      	b.ne	0x37f4 <_stogir.vector.validate+0x5b4>
    3818:      	cmp	x20, #0x0
    381c:      	b.ne	0x37f4 <_stogir.vector.validate+0x5b4>
    3820:      	lsr	w23, w23, #0
    3824:      	add	x16, sp, #0x40
    3828:      	ldr	w0, [x16, #0x4]
    382c:      	add	x16, sp, #0x40
    3830:      	ldr	w1, [x16, #0x8]
    3834:      	lsr	w0, w0, #0
    3838:      	add	x16, sp, #0x40
    383c:      	ldr	w2, [x16, #0xc]
    3840:      	lsr	w1, w1, #0
    3844:      	lsr	w2, w2, #0
    3848:      	add	x8, sp, #0x150
    384c:      	mov	w3, w1
    3850:      	mov	w1, w23
    3854:      	mov	w4, w2
    3858:      	mov	w2, w0
    385c:      	mov	x0, x21
    3860:      	bl	0x3860 <_stogir.vector.validate+0x620>
		0000000000003860:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    3864:      	add	x16, sp, #0x150
    3868:      	ldr	x0, [x16]
    386c:      	add	x16, sp, #0x150
    3870:      	ldr	x1, [x16, #0x8]
    3874:      	add	x16, sp, #0x150
    3878:      	ldr	x2, [x16, #0x10]
    387c:      	b	0x380c <_stogir.vector.validate+0x5cc>
    3880:      	mov	x2, x8
    3884:      	mov	x0, #0x1                ; =1
    3888:      	b	0x380c <_stogir.vector.validate+0x5cc>
    388c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		000000000000388c:  ARM64_RELOC_PAGE21	l_stogir.347
    3890:      	ldr	x16, [x16]
		0000000000003890:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    3894:      	orr	x0, x16, xzr
    3898:      	mov	x1, x0
    389c:      	mov	x0, #0x1                ; =1
    38a0:      	mov	x2, #0x28               ; =40
    38a4:      	b	0x3888 <_stogir.vector.validate+0x648>
    38a8:      	mov	x0, x1
    38ac:      	mov	x1, x27
    38b0:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		00000000000038b0:  ARM64_RELOC_PAGE21	l_stogir.348
    38b4:      	ldr	x16, [x16]
		00000000000038b4:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    38b8:      	orr	x2, x16, xzr
    38bc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		00000000000038bc:  ARM64_RELOC_PAGE21	l_stogir.349
    38c0:      	ldr	x16, [x16]
		00000000000038c0:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    38c4:      	orr	x3, x16, xzr
    38c8:      	add	x4, x21, #0x78
    38cc:      	add	x5, x21, #0x28
    38d0:      	add	x6, x21, #0x50
    38d4:      	add	x7, x21, #0x78
    38d8:      	mov	x8, x1
    38dc:      	mov	x1, x0
    38e0:      	mov	x0, #0x2                ; =2
    38e4:      	b	0x395c <_stogir.vector.validate+0x71c>
    38e8:      	lsr	w10, w10, #0
    38ec:      	ubfx	x9, x10, #8, #8
    38f0:      	cmp	x9, x20
    38f4:      	b.eq	0x3900 <_stogir.vector.validate+0x6c0>
    38f8:      	mov	x1, x3
    38fc:      	mov	x8, #0x1e               ; =30
    3900:      	b	0x3950 <_stogir.vector.validate+0x710>
    3904:      	movz	x9, #0x0, lsl #48
    3908:      	movz	x10, #0x0, lsl #48
    390c:      	b	0x3918 <_stogir.vector.validate+0x6d8>
    3910:      	movz	x9, #0x0, lsl #48
    3914:      	movz	x10, #0x0, lsl #48
    3918:      	lsr	w9, w9, #0
    391c:      	lsr	x16, x9, #0
    3920:      	cmp	x16, #0x1
    3924:      	b.eq	0x3940 <_stogir.vector.validate+0x700>
    3928:      	b.lo	0x3930 <_stogir.vector.validate+0x6f0>
    392c:      	b	0x3944 <_stogir.vector.validate+0x704>
    3930:      	cmp	x16, #0x0
    3934:      	b.eq	0x393c <_stogir.vector.validate+0x6fc>
    3938:      	b	0x3944 <_stogir.vector.validate+0x704>
    393c:      	b	0x3948 <_stogir.vector.validate+0x708>
    3940:      	b	0x39b0 <_stogir.vector.validate+0x770>
    3944:      	b	0x3ce4 <_stogir.vector.validate+0xaa4>
    3948:      	mov	x1, x2
    394c:      	mov	x8, #0x18               ; =24
    3950:      	add	x0, x0, #0x1
    3954:      	lsr	w0, w0, #0
    3958:      	sxtw	x0, w0
    395c:      	cmp	x8, #0x0
    3960:      	b.ne	0x3ae8 <_stogir.vector.validate+0x8a8>
    3964:      	cmp	x0, x28
    3968:      	b.gt	0x3ae8 <_stogir.vector.validate+0x8a8>
    396c:      	uxtb	w16, w24
    3970:      	cmp	w16, wzr
    3974:      	b.ne	0x3910 <_stogir.vector.validate+0x6d0>
    3978:      	ldr	x9, [x21, #0x8]
    397c:      	cmp	x22, x9
    3980:      	b.ge	0x3a1c <_stogir.vector.validate+0x7dc>
    3984:      	ldr	x9, [x7, #0x8]
    3988:      	cmp	x22, x9
    398c:      	b.ge	0x3a14 <_stogir.vector.validate+0x7d4>
    3990:      	ldr	x9, [x21, #0x78]
    3994:      	add	x9, x26, x9
    3998:      	ldr	w9, [x9]
    399c:      	sxtw	x9, w9
    39a0:      	cmp	x9, #0x0
    39a4:      	cset	w9, ge
    39a8:      	ubfx	x9, x9, #0, #8
    39ac:      	b	0x3a18 <_stogir.vector.validate+0x7d8>
    39b0:      	lsr	w10, w10, #0
    39b4:      	sxtw	x10, w10
    39b8:      	cmp	x10, #0x0
    39bc:      	cset	w9, gt
    39c0:      	movz	x16, #0x0, lsl #48
    39c4:      	sub	x11, x16, x10
    39c8:      	sub	x12, x11, #0x1
    39cc:      	uxtb	w16, w9
    39d0:      	cmp	w16, wzr
    39d4:      	b.eq	0x3aa4 <_stogir.vector.validate+0x864>
    39d8:      	ldr	x11, [x21, #0x8]
    39dc:      	cmp	x10, x11
    39e0:      	b.ge	0x3b1c <_stogir.vector.validate+0x8dc>
    39e4:      	ldr	x11, [x4, #0x8]
    39e8:      	cmp	x10, x11
    39ec:      	b.ge	0x3c30 <_stogir.vector.validate+0x9f0>
    39f0:      	lsl	x11, x10, #2
    39f4:      	ldr	x13, [x21, #0x78]
    39f8:      	add	x11, x11, x13
    39fc:      	ldr	w11, [x11]
    3a00:      	sxtw	x11, w11
    3a04:      	cmp	x11, #0x0
    3a08:      	cset	w11, ge
    3a0c:      	ubfx	x11, x11, #0, #8
    3a10:      	b	0x3c34 <_stogir.vector.validate+0x9f4>
    3a14:      	movz	x9, #0x0, lsl #48
    3a18:      	b	0x3a20 <_stogir.vector.validate+0x7e0>
    3a1c:      	movz	x9, #0x0, lsl #48
    3a20:      	cmp	x9, #0x0
    3a24:      	b.eq	0x3910 <_stogir.vector.validate+0x6d0>
    3a28:      	lsr	w9, w0, #0
    3a2c:      	sxtw	x9, w9
    3a30:      	cmp	x9, #0x1
    3a34:      	b.lt	0x3904 <_stogir.vector.validate+0x6c4>
    3a38:      	ldr	x10, [x21, #0x78]
    3a3c:      	add	x10, x26, x10
    3a40:      	ldr	w10, [x10]
    3a44:      	sxtw	x10, w10
    3a48:      	cmp	x9, x10
    3a4c:      	b.gt	0x3904 <_stogir.vector.validate+0x6c4>
    3a50:      	ldr	x10, [x21]
    3a54:      	asr	x16, x9, #63
    3a58:      	lsr	x16, x16, #62
    3a5c:      	add	x11, x9, x16
    3a60:      	asr	x11, x11, #2
    3a64:      	asr	x16, x9, #63
    3a68:      	lsr	x16, x16, #62
    3a6c:      	add	x9, x9, x16
    3a70:      	and	x9, x9, #0x3
    3a74:      	sub	x9, x9, x16
    3a78:      	add	x11, x11, x22
    3a7c:      	lsl	x9, x9, #2
    3a80:      	lsl	x11, x11, #4
    3a84:      	add	x10, x11, x10
    3a88:      	add	x9, x9, x10
    3a8c:      	ldr	w9, [x9]
    3a90:      	sxtw	x9, w9
    3a94:      	and	x9, x9, #0xffffffff
    3a98:      	mov	x10, x9
    3a9c:      	mov	x9, #0x1                ; =1
    3aa0:      	b	0x390c <_stogir.vector.validate+0x6cc>
    3aa4:      	cmp	x10, #0x0
    3aa8:      	b.ge	0x3b24 <_stogir.vector.validate+0x8e4>
    3aac:      	ldr	x13, [x5, #0x8]
    3ab0:      	ldr	x14, [x6, #0x8]
    3ab4:      	cmp	x13, x14
    3ab8:      	b.ne	0x3c28 <_stogir.vector.validate+0x9e8>
    3abc:      	cmp	x11, x13
    3ac0:      	b.gt	0x3c60 <_stogir.vector.validate+0xa20>
    3ac4:      	lsl	x11, x12, #2
    3ac8:      	ldr	x13, [x21, #0x50]
    3acc:      	add	x11, x11, x13
    3ad0:      	ldr	w11, [x11]
    3ad4:      	sxtw	x11, w11
    3ad8:      	cmp	x11, #0x0
    3adc:      	cset	w11, gt
    3ae0:      	ubfx	x11, x11, #0, #8
    3ae4:      	b	0x3c64 <_stogir.vector.validate+0xa24>
    3ae8:      	cmp	x8, #0x0
    3aec:      	b.ne	0x3880 <_stogir.vector.validate+0x640>
    3af0:      	lsr	w23, w23, #0
    3af4:      	mov	w0, w19
    3af8:      	mov	w1, w23
    3afc:      	bl	0x3afc <_stogir.vector.validate+0x8bc>
		0000000000003afc:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3b00:      	lsr	w0, w0, #0
    3b04:      	sxtw	x0, w0
    3b08:      	and	x0, x0, #0xffffffff
    3b0c:      	mov	x1, x0
    3b10:      	movz	x0, #0x0, lsl #48
    3b14:      	movz	x2, #0x0, lsl #48
    3b18:      	b	0x3888 <_stogir.vector.validate+0x648>
    3b1c:      	movz	x11, #0x0, lsl #48
    3b20:      	b	0x3b28 <_stogir.vector.validate+0x8e8>
    3b24:      	movz	x11, #0x0, lsl #48
    3b28:      	cmp	x11, #0x0
    3b2c:      	b.eq	0x3b6c <_stogir.vector.validate+0x92c>
    3b30:      	uxtb	w16, w9
    3b34:      	cmp	w16, wzr
    3b38:      	b.eq	0x3b50 <_stogir.vector.validate+0x910>
    3b3c:      	lsl	x9, x10, #4
    3b40:      	ldr	x10, [x21]
    3b44:      	add	x9, x9, x10
    3b48:      	ldr	x9, [x9]
    3b4c:      	b	0x3b60 <_stogir.vector.validate+0x920>
    3b50:      	lsl	x9, x12, #4
    3b54:      	ldr	x10, [x21, #0x28]
    3b58:      	add	x9, x9, x10
    3b5c:      	ldr	x9, [x9]
    3b60:      	mov	x10, x9
    3b64:      	mov	x9, #0x1                ; =1
    3b68:      	b	0x3b74 <_stogir.vector.validate+0x934>
    3b6c:      	movz	x9, #0x0, lsl #48
    3b70:      	movz	x10, #0x0, lsl #48
    3b74:      	lsr	w9, w9, #0
    3b78:      	lsr	x16, x9, #0
    3b7c:      	cmp	x16, #0x1
    3b80:      	b.eq	0x3b9c <_stogir.vector.validate+0x95c>
    3b84:      	b.lo	0x3b8c <_stogir.vector.validate+0x94c>
    3b88:      	b	0x3ba0 <_stogir.vector.validate+0x960>
    3b8c:      	cmp	x16, #0x0
    3b90:      	b.eq	0x3b98 <_stogir.vector.validate+0x958>
    3b94:      	b	0x3ba0 <_stogir.vector.validate+0x960>
    3b98:      	b	0x3ba4 <_stogir.vector.validate+0x964>
    3b9c:      	b	0x38e8 <_stogir.vector.validate+0x6a8>
    3ba0:      	b	0x3cec <_stogir.vector.validate+0xaac>
    3ba4:      	mov	x1, x2
    3ba8:      	mov	x8, #0x18               ; =24
    3bac:      	b	0x3900 <_stogir.vector.validate+0x6c0>
    3bb0:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		0000000000003bb0:  ARM64_RELOC_PAGE21	l_stogir.350
    3bb4:      	ldr	x16, [x16]
		0000000000003bb4:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    3bb8:      	orr	x0, x16, xzr
    3bbc:      	mov	x25, x0
    3bc0:      	mov	x27, #0x20              ; =32
    3bc4:      	add	x16, sp, #0x40
    3bc8:      	ldr	w0, [x16, #0x4]
    3bcc:      	lsr	w0, w0, #0
    3bd0:      	add	x8, sp, #0x170
    3bd4:      	mov	w1, w0
    3bd8:      	mov	x0, x21
    3bdc:      	bl	0x3bdc <_stogir.vector.validate+0x99c>
		0000000000003bdc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3be0:      	add	x16, sp, #0x170
    3be4:      	ldr	w0, [x16]
    3be8:      	lsr	x16, x0, #0
    3bec:      	cmp	x16, #0x1
    3bf0:      	b.eq	0x3c0c <_stogir.vector.validate+0x9cc>
    3bf4:      	b.lo	0x3bfc <_stogir.vector.validate+0x9bc>
    3bf8:      	b	0x3c10 <_stogir.vector.validate+0x9d0>
    3bfc:      	cmp	x16, #0x0
    3c00:      	b.eq	0x3c08 <_stogir.vector.validate+0x9c8>
    3c04:      	b	0x3c10 <_stogir.vector.validate+0x9d0>
    3c08:      	b	0x3c14 <_stogir.vector.validate+0x9d4>
    3c0c:      	b	0x3c38 <_stogir.vector.validate+0x9f8>
    3c10:      	b	0x3cf4 <_stogir.vector.validate+0xab4>
    3c14:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		0000000000003c14:  ARM64_RELOC_PAGE21	l_stogir.351
    3c18:      	ldr	x16, [x16]
		0000000000003c18:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    3c1c:      	orr	x0, x16, xzr
    3c20:      	mov	x1, #0x19               ; =25
    3c24:      	b	0x38b0 <_stogir.vector.validate+0x670>
    3c28:      	movz	x11, #0x0, lsl #48
    3c2c:      	b	0x3b28 <_stogir.vector.validate+0x8e8>
    3c30:      	movz	x11, #0x0, lsl #48
    3c34:      	b	0x3b20 <_stogir.vector.validate+0x8e0>
    3c38:      	add	x16, sp, #0x170
    3c3c:      	ldr	x0, [x16, #0x8]
    3c40:      	add	x16, sp, #0x40
    3c44:      	ldr	w1, [x16, #0x4]
    3c48:      	sxtw	x1, w1
    3c4c:      	cmp	x1, #0x0
    3c50:      	b.gt	0x3cc8 <_stogir.vector.validate+0xa88>
    3c54:      	mov	x1, x25
    3c58:      	mov	x0, #0x1                ; =1
    3c5c:      	b	0x3cac <_stogir.vector.validate+0xa6c>
    3c60:      	movz	x11, #0x0, lsl #48
    3c64:      	b	0x3c2c <_stogir.vector.validate+0x9ec>
    3c68:      	add	x16, sp, #0x40
    3c6c:      	ldr	w0, [x16, #0x4]
    3c70:      	sxtw	x0, w0
    3c74:      	ldr	x1, [x21, #0x78]
    3c78:      	lsl	x0, x0, #2
    3c7c:      	add	x0, x0, x1
    3c80:      	ldr	w0, [x0]
    3c84:      	sxtw	x0, w0
    3c88:      	add	x0, x0, #0x1
    3c8c:      	lsr	w0, w0, #0
    3c90:      	sxtw	x0, w0
    3c94:      	cmp	x28, x0
    3c98:      	cset	w0, eq
    3c9c:      	uxtb	w16, w0
    3ca0:      	cmp	w16, wzr
    3ca4:      	cset	x0, eq
    3ca8:      	mov	x1, x25
    3cac:      	cmp	x0, #0x0
    3cb0:      	b.eq	0x38a8 <_stogir.vector.validate+0x668>
    3cb4:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		0000000000003cb4:  ARM64_RELOC_PAGE21	l_stogir.352
    3cb8:      	ldr	x16, [x16]
		0000000000003cb8:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    3cbc:      	orr	x0, x16, xzr
    3cc0:      	mov	x1, #0x19               ; =25
    3cc4:      	b	0x38b0 <_stogir.vector.validate+0x670>
    3cc8:      	uxtb	w0, w0
    3ccc:      	cmp	x0, #0x70
    3cd0:      	b.eq	0x3c68 <_stogir.vector.validate+0xa28>
    3cd4:      	cmp	x0, #0x71
    3cd8:      	b.eq	0x3c68 <_stogir.vector.validate+0xa28>
    3cdc:      	mov	x0, #0x1                ; =1
    3ce0:      	b	0x3ca8 <_stogir.vector.validate+0xa68>
    3ce4:      	brk	#0
    3ce8:      	b	0x3ce4 <_stogir.vector.validate+0xaa4>
    3cec:      	brk	#0
    3cf0:      	b	0x3cec <_stogir.vector.validate+0xaac>
    3cf4:      	brk	#0
    3cf8:      	b	0x3cf4 <_stogir.vector.validate+0xab4>
    3cfc:      	str	x20, [sp, #0x1a8]
    3d00:      	str	w19, [sp, #0x1a0]
    3d04:      	b	0x33f4 <_stogir.vector.validate+0x1b4>
    3d08:      	str	x20, [sp, #0x1a8]
    3d0c:      	str	w19, [sp, #0x1a0]
    3d10:      	mov	w19, w0
    3d14:      	mov	w20, w1
    3d18:      	str	w2, [sp, #0x1b0]
    3d1c:      	str	w3, [sp, #0x1b8]
    3d20:      	b	0x34b0 <_stogir.vector.validate+0x270>

0000000000003d24 <_stogir.copy.validate>:
    3d24:      	sub	sp, sp, #0x40
    3d28:      	str	x29, [sp]
    3d2c:      	str	x30, [sp, #0x8]
    3d30:      	mov	x29, sp
    3d34:      	str	x19, [sp, #0x20]
    3d38:      	str	x20, [sp, #0x28]
    3d3c:      	str	x21, [sp, #0x30]
    3d40:      	sxtw	x1, w1
    3d44:      	lsl	x2, x1, #2
    3d48:      	cmp	x1, #0x0
    3d4c:      	cset	w3, gt
    3d50:      	movz	x16, #0x0, lsl #48
    3d54:      	sub	x4, x16, x1
    3d58:      	sub	x5, x4, #0x1
    3d5c:      	uxtb	w16, w3
    3d60:      	cmp	w16, wzr
    3d64:      	b.eq	0x3da4 <_stogir.copy.validate+0x80>
    3d68:      	ldr	x4, [x0, #0x8]
    3d6c:      	cmp	x1, x4
    3d70:      	b.ge	0x3df8 <_stogir.copy.validate+0xd4>
    3d74:      	add	x4, x0, #0x78
    3d78:      	ldr	x4, [x4, #0x8]
    3d7c:      	cmp	x1, x4
    3d80:      	b.ge	0x3f24 <_stogir.copy.validate+0x200>
    3d84:      	ldr	x4, [x0, #0x78]
    3d88:      	add	x4, x2, x4
    3d8c:      	ldr	w4, [x4]
    3d90:      	sxtw	x4, w4
    3d94:      	cmp	x4, #0x0
    3d98:      	cset	w4, ge
    3d9c:      	ubfx	x4, x4, #0, #8
    3da0:      	b	0x3f28 <_stogir.copy.validate+0x204>
    3da4:      	cmp	x1, #0x0
    3da8:      	b.ge	0x3e00 <_stogir.copy.validate+0xdc>
    3dac:      	add	x6, x0, #0x28
    3db0:      	add	x7, x0, #0x50
    3db4:      	ldr	x6, [x6, #0x8]
    3db8:      	ldr	x7, [x7, #0x8]
    3dbc:      	cmp	x6, x7
    3dc0:      	b.ne	0x3df0 <_stogir.copy.validate+0xcc>
    3dc4:      	cmp	x4, x6
    3dc8:      	b.gt	0x3f6c <_stogir.copy.validate+0x248>
    3dcc:      	lsl	x4, x5, #2
    3dd0:      	ldr	x6, [x0, #0x50]
    3dd4:      	add	x4, x4, x6
    3dd8:      	ldr	w4, [x4]
    3ddc:      	sxtw	x4, w4
    3de0:      	cmp	x4, #0x0
    3de4:      	cset	w4, gt
    3de8:      	ubfx	x4, x4, #0, #8
    3dec:      	b	0x3f70 <_stogir.copy.validate+0x24c>
    3df0:      	movz	x4, #0x0, lsl #48
    3df4:      	b	0x3e04 <_stogir.copy.validate+0xe0>
    3df8:      	movz	x4, #0x0, lsl #48
    3dfc:      	b	0x3e04 <_stogir.copy.validate+0xe0>
    3e00:      	movz	x4, #0x0, lsl #48
    3e04:      	cmp	x4, #0x0
    3e08:      	b.eq	0x3e6c <_stogir.copy.validate+0x148>
    3e0c:      	uxtb	w16, w3
    3e10:      	cmp	w16, wzr
    3e14:      	b.eq	0x3e3c <_stogir.copy.validate+0x118>
    3e18:      	lsl	x3, x1, #4
    3e1c:      	ldr	x4, [x0]
    3e20:      	add	x3, x3, x4
    3e24:      	ldr	x4, [x3]
    3e28:      	ldr	x3, [x3, #0x8]
    3e2c:      	fmov	d31, x3
    3e30:      	mov	x3, x4
    3e34:      	fmov	x4, d31
    3e38:      	b	0x3e5c <_stogir.copy.validate+0x138>
    3e3c:      	lsl	x3, x5, #4
    3e40:      	ldr	x4, [x0, #0x28]
    3e44:      	add	x3, x3, x4
    3e48:      	ldr	x4, [x3]
    3e4c:      	ldr	x3, [x3, #0x8]
    3e50:      	fmov	d31, x3
    3e54:      	mov	x3, x4
    3e58:      	fmov	x4, d31
    3e5c:      	mov	x5, x4
    3e60:      	mov	x4, x3
    3e64:      	mov	x3, #0x1                ; =1
    3e68:      	b	0x3e78 <_stogir.copy.validate+0x154>
    3e6c:      	movz	x3, #0x0, lsl #48
    3e70:      	movz	x4, #0x0, lsl #48
    3e74:      	movz	x5, #0x0, lsl #48
    3e78:      	lsr	w3, w3, #0
    3e7c:      	lsr	x16, x3, #0
    3e80:      	cmp	x16, #0x1
    3e84:      	b.eq	0x3ea0 <_stogir.copy.validate+0x17c>
    3e88:      	b.lo	0x3e90 <_stogir.copy.validate+0x16c>
    3e8c:      	b	0x3ea4 <_stogir.copy.validate+0x180>
    3e90:      	cmp	x16, #0x0
    3e94:      	b.eq	0x3e9c <_stogir.copy.validate+0x178>
    3e98:      	b	0x3ea4 <_stogir.copy.validate+0x180>
    3e9c:      	b	0x3ea8 <_stogir.copy.validate+0x184>
    3ea0:      	b	0x3eec <_stogir.copy.validate+0x1c8>
    3ea4:      	b	0x3ffc <_stogir.copy.validate+0x2d8>
    3ea8:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		0000000000003ea8:  ARM64_RELOC_PAGE21	l_stogir.353
    3eac:      	ldr	x16, [x16]
		0000000000003eac:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    3eb0:      	orr	x0, x16, xzr
    3eb4:      	mov	x20, x8
    3eb8:      	mov	x1, x0
    3ebc:      	mov	x0, #0x1                ; =1
    3ec0:      	mov	x2, #0x18               ; =24
    3ec4:      	str	x0, [x20]
    3ec8:      	str	x1, [x20, #0x8]
    3ecc:      	str	x2, [x20, #0x10]
    3ed0:      	ldr	x19, [sp, #0x20]
    3ed4:      	ldr	x20, [sp, #0x28]
    3ed8:      	ldr	x21, [sp, #0x30]
    3edc:      	ldr	x29, [sp]
    3ee0:      	ldr	x30, [sp, #0x8]
    3ee4:      	add	sp, sp, #0x40
    3ee8:      	ret
    3eec:      	add	x16, sp, #0x10
    3ef0:      	str	x4, [x16]
    3ef4:      	add	x16, sp, #0x10
    3ef8:      	str	x5, [x16, #0x8]
    3efc:      	cmp	x1, #0x0
    3f00:      	b.gt	0x3f2c <_stogir.copy.validate+0x208>
    3f04:      	mov	x20, x8
    3f08:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4dc>
		0000000000003f08:  ARM64_RELOC_PAGE21	l_stogir.354
    3f0c:      	ldr	x16, [x16]
		0000000000003f0c:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    3f10:      	orr	x0, x16, xzr
    3f14:      	mov	x1, x0
    3f18:      	mov	x0, #0x1                ; =1
    3f1c:      	mov	x2, #0x21               ; =33
    3f20:      	b	0x3ec4 <_stogir.copy.validate+0x1a0>
    3f24:      	movz	x4, #0x0, lsl #48
    3f28:      	b	0x3dfc <_stogir.copy.validate+0xd8>
    3f2c:      	uxtb	w1, w4
    3f30:      	cmp	x1, #0x44
    3f34:      	b.ne	0x4160 <_stogir.copy.validate+0x43c>
    3f38:      	ldr	x1, [x0, #0x78]
    3f3c:      	add	x1, x2, x1
    3f40:      	ldr	w1, [x1]
    3f44:      	sxtw	x1, w1
    3f48:      	cmp	x1, #0x2
    3f4c:      	b.ne	0x4168 <_stogir.copy.validate+0x444>
    3f50:      	lsr	w4, w4, #0
    3f54:      	ubfx	x1, x4, #8, #8
    3f58:      	orr	x19, x1, xzr
    3f5c:      	cmp	x19, #0x0
    3f60:      	b.ne	0x3f74 <_stogir.copy.validate+0x250>
    3f64:      	mov	x20, x8
    3f68:      	b	0x3f08 <_stogir.copy.validate+0x1e4>
    3f6c:      	movz	x4, #0x0, lsl #48
    3f70:      	b	0x3df4 <_stogir.copy.validate+0xd0>
    3f74:      	lsr	w1, w1, #0
    3f78:      	mov	x20, x8
    3f7c:      	mov	x21, x0
    3f80:      	mov	w0, w1
    3f84:      	bl	0x3f84 <_stogir.copy.validate+0x260>
		0000000000003f84:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    3f88:      	cmp	x0, #0x0
    3f8c:      	b.eq	0x3f08 <_stogir.copy.validate+0x1e4>
    3f90:      	add	x16, sp, #0x10
    3f94:      	ldr	w0, [x16, #0x4]
    3f98:      	sxtw	x0, w0
    3f9c:      	cmp	x0, #0x0
    3fa0:      	cset	w1, gt
    3fa4:      	movz	x16, #0x0, lsl #48
    3fa8:      	sub	x2, x16, x0
    3fac:      	sub	x3, x2, #0x1
    3fb0:      	uxtb	w16, w1
    3fb4:      	cmp	w16, wzr
    3fb8:      	b.eq	0x4020 <_stogir.copy.validate+0x2fc>
    3fbc:      	ldr	x2, [x21, #0x8]
    3fc0:      	cmp	x0, x2
    3fc4:      	b.ge	0x406c <_stogir.copy.validate+0x348>
    3fc8:      	add	x2, x21, #0x78
    3fcc:      	ldr	x2, [x2, #0x8]
    3fd0:      	cmp	x0, x2
    3fd4:      	b.ge	0x4148 <_stogir.copy.validate+0x424>
    3fd8:      	lsl	x2, x0, #2
    3fdc:      	ldr	x4, [x21, #0x78]
    3fe0:      	add	x2, x2, x4
    3fe4:      	ldr	w2, [x2]
    3fe8:      	sxtw	x2, w2
    3fec:      	cmp	x2, #0x0
    3ff0:      	cset	w2, ge
    3ff4:      	ubfx	x2, x2, #0, #8
    3ff8:      	b	0x414c <_stogir.copy.validate+0x428>
    3ffc:      	brk	#0
    4000:      	b	0x3ffc <_stogir.copy.validate+0x2d8>
    4004:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004004:  ARM64_RELOC_PAGE21	l_stogir.355
    4008:      	ldr	x16, [x16]
		0000000000004008:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    400c:      	orr	x0, x16, xzr
    4010:      	mov	x1, x0
    4014:      	mov	x0, #0x1                ; =1
    4018:      	mov	x2, #0x20               ; =32
    401c:      	b	0x3f20 <_stogir.copy.validate+0x1fc>
    4020:      	cmp	x0, #0x0
    4024:      	b.ge	0x4074 <_stogir.copy.validate+0x350>
    4028:      	add	x4, x21, #0x28
    402c:      	add	x5, x21, #0x50
    4030:      	ldr	x4, [x4, #0x8]
    4034:      	ldr	x5, [x5, #0x8]
    4038:      	cmp	x4, x5
    403c:      	b.ne	0x4140 <_stogir.copy.validate+0x41c>
    4040:      	cmp	x2, x4
    4044:      	b.gt	0x4150 <_stogir.copy.validate+0x42c>
    4048:      	lsl	x2, x3, #2
    404c:      	ldr	x4, [x21, #0x50]
    4050:      	add	x2, x2, x4
    4054:      	ldr	w2, [x2]
    4058:      	sxtw	x2, w2
    405c:      	cmp	x2, #0x0
    4060:      	cset	w2, gt
    4064:      	ubfx	x2, x2, #0, #8
    4068:      	b	0x4154 <_stogir.copy.validate+0x430>
    406c:      	movz	x2, #0x0, lsl #48
    4070:      	b	0x4078 <_stogir.copy.validate+0x354>
    4074:      	movz	x2, #0x0, lsl #48
    4078:      	cmp	x2, #0x0
    407c:      	b.eq	0x40bc <_stogir.copy.validate+0x398>
    4080:      	uxtb	w16, w1
    4084:      	cmp	w16, wzr
    4088:      	b.eq	0x40a0 <_stogir.copy.validate+0x37c>
    408c:      	lsl	x0, x0, #4
    4090:      	ldr	x1, [x21]
    4094:      	add	x0, x0, x1
    4098:      	ldr	x0, [x0]
    409c:      	b	0x40b0 <_stogir.copy.validate+0x38c>
    40a0:      	lsl	x0, x3, #4
    40a4:      	ldr	x1, [x21, #0x28]
    40a8:      	add	x0, x0, x1
    40ac:      	ldr	x0, [x0]
    40b0:      	mov	x1, x0
    40b4:      	mov	x0, #0x1                ; =1
    40b8:      	b	0x40c4 <_stogir.copy.validate+0x3a0>
    40bc:      	movz	x0, #0x0, lsl #48
    40c0:      	movz	x1, #0x0, lsl #48
    40c4:      	lsr	w0, w0, #0
    40c8:      	lsr	x16, x0, #0
    40cc:      	cmp	x16, #0x1
    40d0:      	b.eq	0x40ec <_stogir.copy.validate+0x3c8>
    40d4:      	b.lo	0x40dc <_stogir.copy.validate+0x3b8>
    40d8:      	b	0x40f0 <_stogir.copy.validate+0x3cc>
    40dc:      	cmp	x16, #0x0
    40e0:      	b.eq	0x40e8 <_stogir.copy.validate+0x3c4>
    40e4:      	b	0x40f0 <_stogir.copy.validate+0x3cc>
    40e8:      	b	0x40f4 <_stogir.copy.validate+0x3d0>
    40ec:      	b	0x4110 <_stogir.copy.validate+0x3ec>
    40f0:      	b	0x4158 <_stogir.copy.validate+0x434>
    40f4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		00000000000040f4:  ARM64_RELOC_PAGE21	l_stogir.356
    40f8:      	ldr	x16, [x16]
		00000000000040f8:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    40fc:      	orr	x0, x16, xzr
    4100:      	mov	x1, x0
    4104:      	mov	x0, #0x1                ; =1
    4108:      	mov	x2, #0x13               ; =19
    410c:      	b	0x401c <_stogir.copy.validate+0x2f8>
    4110:      	lsr	w1, w1, #0
    4114:      	add	x16, sp, #0x10
    4118:      	ldr	w0, [x16]
    411c:      	ubfx	x1, x1, #8, #8
    4120:      	ubfx	x0, x0, #8, #8
    4124:      	cmp	x1, x0
    4128:      	b.ne	0x4004 <_stogir.copy.validate+0x2e0>
    412c:      	and	x0, x19, #0xffffffff
    4130:      	mov	x1, x0
    4134:      	movz	x0, #0x0, lsl #48
    4138:      	movz	x2, #0x0, lsl #48
    413c:      	b	0x401c <_stogir.copy.validate+0x2f8>
    4140:      	movz	x2, #0x0, lsl #48
    4144:      	b	0x4078 <_stogir.copy.validate+0x354>
    4148:      	movz	x2, #0x0, lsl #48
    414c:      	b	0x4070 <_stogir.copy.validate+0x34c>
    4150:      	movz	x2, #0x0, lsl #48
    4154:      	b	0x4144 <_stogir.copy.validate+0x420>
    4158:      	brk	#0
    415c:      	b	0x4158 <_stogir.copy.validate+0x434>
    4160:      	mov	x20, x8
    4164:      	b	0x3f08 <_stogir.copy.validate+0x1e4>
    4168:      	mov	x20, x8
    416c:      	b	0x3f08 <_stogir.copy.validate+0x1e4>

0000000000004170 <_stogir.graph.lookup>:
    4170:      	sxtw	x1, w1
    4174:      	cmp	x1, #0x0
    4178:      	cset	w2, gt
    417c:      	movz	x16, #0x0, lsl #48
    4180:      	sub	x3, x16, x1
    4184:      	sub	x4, x3, #0x1
    4188:      	uxtb	w16, w2
    418c:      	cmp	w16, wzr
    4190:      	b.eq	0x41d4 <_stogir.graph.lookup+0x64>
    4194:      	ldr	x3, [x0, #0x8]
    4198:      	cmp	x1, x3
    419c:      	b.ge	0x4228 <_stogir.graph.lookup+0xb8>
    41a0:      	add	x3, x0, #0x78
    41a4:      	ldr	x3, [x3, #0x8]
    41a8:      	cmp	x1, x3
    41ac:      	b.ge	0x42c8 <_stogir.graph.lookup+0x158>
    41b0:      	lsl	x3, x1, #2
    41b4:      	ldr	x5, [x0, #0x78]
    41b8:      	add	x3, x3, x5
    41bc:      	ldr	w3, [x3]
    41c0:      	sxtw	x3, w3
    41c4:      	cmp	x3, #0x0
    41c8:      	cset	w3, ge
    41cc:      	ubfx	x3, x3, #0, #8
    41d0:      	b	0x42cc <_stogir.graph.lookup+0x15c>
    41d4:      	cmp	x1, #0x0
    41d8:      	b.ge	0x4230 <_stogir.graph.lookup+0xc0>
    41dc:      	add	x5, x0, #0x28
    41e0:      	add	x6, x0, #0x50
    41e4:      	ldr	x5, [x5, #0x8]
    41e8:      	ldr	x6, [x6, #0x8]
    41ec:      	cmp	x5, x6
    41f0:      	b.ne	0x4220 <_stogir.graph.lookup+0xb0>
    41f4:      	cmp	x3, x5
    41f8:      	b.gt	0x42d0 <_stogir.graph.lookup+0x160>
    41fc:      	lsl	x3, x4, #2
    4200:      	ldr	x5, [x0, #0x50]
    4204:      	add	x3, x3, x5
    4208:      	ldr	w3, [x3]
    420c:      	sxtw	x3, w3
    4210:      	cmp	x3, #0x0
    4214:      	cset	w3, gt
    4218:      	ubfx	x3, x3, #0, #8
    421c:      	b	0x42d4 <_stogir.graph.lookup+0x164>
    4220:      	movz	x3, #0x0, lsl #48
    4224:      	b	0x4234 <_stogir.graph.lookup+0xc4>
    4228:      	movz	x3, #0x0, lsl #48
    422c:      	b	0x4234 <_stogir.graph.lookup+0xc4>
    4230:      	movz	x3, #0x0, lsl #48
    4234:      	cmp	x3, #0x0
    4238:      	b.eq	0x429c <_stogir.graph.lookup+0x12c>
    423c:      	uxtb	w16, w2
    4240:      	cmp	w16, wzr
    4244:      	b.eq	0x426c <_stogir.graph.lookup+0xfc>
    4248:      	lsl	x1, x1, #4
    424c:      	ldr	x0, [x0]
    4250:      	add	x0, x1, x0
    4254:      	ldr	x1, [x0]
    4258:      	ldr	x0, [x0, #0x8]
    425c:      	fmov	d31, x0
    4260:      	mov	x0, x1
    4264:      	fmov	x1, d31
    4268:      	b	0x428c <_stogir.graph.lookup+0x11c>
    426c:      	lsl	x1, x4, #4
    4270:      	ldr	x0, [x0, #0x28]
    4274:      	add	x0, x1, x0
    4278:      	ldr	x1, [x0]
    427c:      	ldr	x0, [x0, #0x8]
    4280:      	fmov	d31, x0
    4284:      	mov	x0, x1
    4288:      	fmov	x1, d31
    428c:      	mov	x2, x1
    4290:      	mov	x1, x0
    4294:      	mov	x0, #0x1                ; =1
    4298:      	b	0x42a8 <_stogir.graph.lookup+0x138>
    429c:      	movz	x0, #0x0, lsl #48
    42a0:      	movz	x1, #0x0, lsl #48
    42a4:      	movz	x2, #0x0, lsl #48
    42a8:      	str	x0, [x8]
    42ac:      	str	x1, [x8, #0x8]
    42b0:      	str	x2, [x8, #0x10]
    42b4:      	movz	x17, #0x0, lsl #48
    42b8:      	str	x17, [x8, #0x18]
    42bc:      	movz	x17, #0x0, lsl #48
    42c0:      	str	x17, [x8, #0x20]
    42c4:      	ret
    42c8:      	movz	x3, #0x0, lsl #48
    42cc:      	b	0x422c <_stogir.graph.lookup+0xbc>
    42d0:      	movz	x3, #0x0, lsl #48
    42d4:      	b	0x4224 <_stogir.graph.lookup+0xb4>

00000000000042d8 <_stogir.opcode.block-start?>:
    42d8:      	sxtw	x0, w0
    42dc:      	cmp	x0, #0x0
    42e0:      	b.lt	0x4308 <_stogir.opcode.block-start?+0x30>
    42e4:      	cmp	x0, #0x83
    42e8:      	b.ge	0x4308 <_stogir.opcode.block-start?+0x30>
    42ec:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		00000000000042ec:  ARM64_RELOC_PAGE21	l_stogir.357
    42f0:      	ldr	x16, [x16]
		00000000000042f0:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    42f4:      	orr	x1, x16, xzr
    42f8:      	lsr	x0, x0, #0
    42fc:      	add	x0, x0, x1
    4300:      	ldrb	w0, [x0]
    4304:      	b	0x430c <_stogir.opcode.block-start?+0x34>
    4308:      	movz	x0, #0x0, lsl #48
    430c:      	uxtb	w0, w0
    4310:      	and	x0, x0, #0x2
    4314:      	uxtb	w0, w0
    4318:      	cmp	x0, #0x0
    431c:      	cset	w0, eq
    4320:      	uxtb	w16, w0
    4324:      	cmp	w16, wzr
    4328:      	cset	x0, eq
    432c:      	ret

0000000000004330 <_stogir.checked.operation?>:
    4330:      	sxtw	x0, w0
    4334:      	cmp	x0, #0x29
    4338:      	b.lt	0x434c <_stogir.checked.operation?+0x1c>
    433c:      	cmp	x0, #0x2b
    4340:      	cset	w0, le
    4344:      	ubfx	x0, x0, #0, #8
    4348:      	b	0x4350 <_stogir.checked.operation?+0x20>
    434c:      	movz	x0, #0x0, lsl #48
    4350:      	ret

0000000000004354 <_stogir.checked.validate-projection>:
    4354:      	sub	sp, sp, #0x40
    4358:      	str	x29, [sp]
    435c:      	str	x30, [sp, #0x8]
    4360:      	mov	x29, sp
    4364:      	str	x19, [sp, #0x30]
    4368:      	sxtw	x1, w1
    436c:      	lsl	x2, x1, #2
    4370:      	cmp	x1, #0x0
    4374:      	cset	w3, gt
    4378:      	movz	x16, #0x0, lsl #48
    437c:      	sub	x4, x16, x1
    4380:      	sub	x5, x4, #0x1
    4384:      	uxtb	w16, w3
    4388:      	cmp	w16, wzr
    438c:      	b.eq	0x43cc <_stogir.checked.validate-projection+0x78>
    4390:      	ldr	x4, [x0, #0x8]
    4394:      	cmp	x1, x4
    4398:      	b.ge	0x4420 <_stogir.checked.validate-projection+0xcc>
    439c:      	add	x4, x0, #0x78
    43a0:      	ldr	x4, [x4, #0x8]
    43a4:      	cmp	x1, x4
    43a8:      	b.ge	0x450c <_stogir.checked.validate-projection+0x1b8>
    43ac:      	ldr	x4, [x0, #0x78]
    43b0:      	add	x4, x2, x4
    43b4:      	ldr	w4, [x4]
    43b8:      	sxtw	x4, w4
    43bc:      	cmp	x4, #0x0
    43c0:      	cset	w4, ge
    43c4:      	ubfx	x4, x4, #0, #8
    43c8:      	b	0x4510 <_stogir.checked.validate-projection+0x1bc>
    43cc:      	cmp	x1, #0x0
    43d0:      	b.ge	0x4428 <_stogir.checked.validate-projection+0xd4>
    43d4:      	add	x6, x0, #0x28
    43d8:      	add	x7, x0, #0x50
    43dc:      	ldr	x6, [x6, #0x8]
    43e0:      	ldr	x7, [x7, #0x8]
    43e4:      	cmp	x6, x7
    43e8:      	b.ne	0x4418 <_stogir.checked.validate-projection+0xc4>
    43ec:      	cmp	x4, x6
    43f0:      	b.gt	0x4578 <_stogir.checked.validate-projection+0x224>
    43f4:      	lsl	x4, x5, #2
    43f8:      	ldr	x6, [x0, #0x50]
    43fc:      	add	x4, x4, x6
    4400:      	ldr	w4, [x4]
    4404:      	sxtw	x4, w4
    4408:      	cmp	x4, #0x0
    440c:      	cset	w4, gt
    4410:      	ubfx	x4, x4, #0, #8
    4414:      	b	0x457c <_stogir.checked.validate-projection+0x228>
    4418:      	movz	x4, #0x0, lsl #48
    441c:      	b	0x442c <_stogir.checked.validate-projection+0xd8>
    4420:      	movz	x4, #0x0, lsl #48
    4424:      	b	0x442c <_stogir.checked.validate-projection+0xd8>
    4428:      	movz	x4, #0x0, lsl #48
    442c:      	cmp	x4, #0x0
    4430:      	b.eq	0x4470 <_stogir.checked.validate-projection+0x11c>
    4434:      	uxtb	w16, w3
    4438:      	cmp	w16, wzr
    443c:      	b.eq	0x4454 <_stogir.checked.validate-projection+0x100>
    4440:      	lsl	x3, x1, #4
    4444:      	ldr	x4, [x0]
    4448:      	add	x3, x3, x4
    444c:      	ldr	x3, [x3]
    4450:      	b	0x4464 <_stogir.checked.validate-projection+0x110>
    4454:      	lsl	x3, x5, #4
    4458:      	ldr	x4, [x0, #0x28]
    445c:      	add	x3, x3, x4
    4460:      	ldr	x3, [x3]
    4464:      	mov	x4, x3
    4468:      	mov	x3, #0x1                ; =1
    446c:      	b	0x4478 <_stogir.checked.validate-projection+0x124>
    4470:      	movz	x3, #0x0, lsl #48
    4474:      	movz	x4, #0x0, lsl #48
    4478:      	lsr	w3, w3, #0
    447c:      	lsr	x16, x3, #0
    4480:      	cmp	x16, #0x1
    4484:      	b.eq	0x44a0 <_stogir.checked.validate-projection+0x14c>
    4488:      	b.lo	0x4490 <_stogir.checked.validate-projection+0x13c>
    448c:      	b	0x44a4 <_stogir.checked.validate-projection+0x150>
    4490:      	cmp	x16, #0x0
    4494:      	b.eq	0x449c <_stogir.checked.validate-projection+0x148>
    4498:      	b	0x44a4 <_stogir.checked.validate-projection+0x150>
    449c:      	b	0x44a8 <_stogir.checked.validate-projection+0x154>
    44a0:      	b	0x44c8 <_stogir.checked.validate-projection+0x174>
    44a4:      	b	0x4580 <_stogir.checked.validate-projection+0x22c>
    44a8:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		00000000000044a8:  ARM64_RELOC_PAGE21	l_stogir.358
    44ac:      	ldr	x16, [x16]
		00000000000044ac:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    44b0:      	orr	x0, x16, xzr
    44b4:      	mov	x19, x8
    44b8:      	mov	x1, x0
    44bc:      	mov	x0, #0x1                ; =1
    44c0:      	mov	x2, #0x10               ; =16
    44c4:      	b	0x44ec <_stogir.checked.validate-projection+0x198>
    44c8:      	cmp	x1, #0x0
    44cc:      	b.gt	0x4514 <_stogir.checked.validate-projection+0x1c0>
    44d0:      	mov	x19, x8
    44d4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		00000000000044d4:  ARM64_RELOC_PAGE21	l_stogir.359
    44d8:      	ldr	x16, [x16]
		00000000000044d8:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    44dc:      	orr	x0, x16, xzr
    44e0:      	mov	x1, x0
    44e4:      	mov	x0, #0x1                ; =1
    44e8:      	mov	x2, #0x1c               ; =28
    44ec:      	str	x0, [x19]
    44f0:      	str	x1, [x19, #0x8]
    44f4:      	str	x2, [x19, #0x10]
    44f8:      	ldr	x19, [sp, #0x30]
    44fc:      	ldr	x29, [sp]
    4500:      	ldr	x30, [sp, #0x8]
    4504:      	add	sp, sp, #0x40
    4508:      	ret
    450c:      	movz	x4, #0x0, lsl #48
    4510:      	b	0x4424 <_stogir.checked.validate-projection+0xd0>
    4514:      	uxtb	w1, w4
    4518:      	cmp	x1, #0x2c
    451c:      	b.ne	0x4588 <_stogir.checked.validate-projection+0x234>
    4520:      	lsr	w1, w4, #0
    4524:      	ubfx	x1, x1, #8, #8
    4528:      	cmp	x1, #0x1
    452c:      	b.ne	0x4590 <_stogir.checked.validate-projection+0x23c>
    4530:      	ldr	x1, [x0, #0x78]
    4534:      	add	x1, x2, x1
    4538:      	ldr	w1, [x1]
    453c:      	sxtw	x1, w1
    4540:      	cmp	x1, #0x1
    4544:      	b.ne	0x4598 <_stogir.checked.validate-projection+0x244>
    4548:      	lsr	x1, x4, #32
    454c:      	lsr	w1, w1, #0
    4550:      	mov	x19, x8
    4554:      	add	x8, sp, #0x10
    4558:      	bl	0x4558 <_stogir.checked.validate-projection+0x204>
		0000000000004558:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    455c:      	add	x16, sp, #0x10
    4560:      	ldr	x0, [x16]
    4564:      	add	x16, sp, #0x10
    4568:      	ldr	x1, [x16, #0x8]
    456c:      	add	x16, sp, #0x10
    4570:      	ldr	x2, [x16, #0x10]
    4574:      	b	0x44ec <_stogir.checked.validate-projection+0x198>
    4578:      	movz	x4, #0x0, lsl #48
    457c:      	b	0x441c <_stogir.checked.validate-projection+0xc8>
    4580:      	brk	#0
    4584:      	b	0x4580 <_stogir.checked.validate-projection+0x22c>
    4588:      	mov	x19, x8
    458c:      	b	0x44d4 <_stogir.checked.validate-projection+0x180>
    4590:      	mov	x19, x8
    4594:      	b	0x44d4 <_stogir.checked.validate-projection+0x180>
    4598:      	mov	x19, x8
    459c:      	b	0x44d4 <_stogir.checked.validate-projection+0x180>

00000000000045a0 <_stogir.checked.validate>:
    45a0:      	sub	sp, sp, #0x30
    45a4:      	str	x29, [sp]
    45a8:      	str	x30, [sp, #0x8]
    45ac:      	mov	x29, sp
    45b0:      	str	x19, [sp, #0x10]
    45b4:      	str	x20, [sp, #0x18]
    45b8:      	str	x21, [sp, #0x20]
    45bc:      	sxtw	x1, w1
    45c0:      	lsl	x2, x1, #2
    45c4:      	cmp	x1, #0x0
    45c8:      	cset	w3, gt
    45cc:      	movz	x16, #0x0, lsl #48
    45d0:      	sub	x4, x16, x1
    45d4:      	sub	x5, x4, #0x1
    45d8:      	uxtb	w16, w3
    45dc:      	cmp	w16, wzr
    45e0:      	b.eq	0x4620 <_stogir.checked.validate+0x80>
    45e4:      	ldr	x4, [x0, #0x8]
    45e8:      	cmp	x1, x4
    45ec:      	b.ge	0x4674 <_stogir.checked.validate+0xd4>
    45f0:      	add	x4, x0, #0x78
    45f4:      	ldr	x4, [x4, #0x8]
    45f8:      	cmp	x1, x4
    45fc:      	b.ge	0x4800 <_stogir.checked.validate+0x260>
    4600:      	ldr	x4, [x0, #0x78]
    4604:      	add	x4, x2, x4
    4608:      	ldr	w4, [x4]
    460c:      	sxtw	x4, w4
    4610:      	cmp	x4, #0x0
    4614:      	cset	w4, ge
    4618:      	ubfx	x4, x4, #0, #8
    461c:      	b	0x4804 <_stogir.checked.validate+0x264>
    4620:      	cmp	x1, #0x0
    4624:      	b.ge	0x467c <_stogir.checked.validate+0xdc>
    4628:      	add	x6, x0, #0x28
    462c:      	add	x7, x0, #0x50
    4630:      	ldr	x6, [x6, #0x8]
    4634:      	ldr	x7, [x7, #0x8]
    4638:      	cmp	x6, x7
    463c:      	b.ne	0x466c <_stogir.checked.validate+0xcc>
    4640:      	cmp	x4, x6
    4644:      	b.gt	0x4808 <_stogir.checked.validate+0x268>
    4648:      	lsl	x4, x5, #2
    464c:      	ldr	x6, [x0, #0x50]
    4650:      	add	x4, x4, x6
    4654:      	ldr	w4, [x4]
    4658:      	sxtw	x4, w4
    465c:      	cmp	x4, #0x0
    4660:      	cset	w4, gt
    4664:      	ubfx	x4, x4, #0, #8
    4668:      	b	0x480c <_stogir.checked.validate+0x26c>
    466c:      	movz	x4, #0x0, lsl #48
    4670:      	b	0x4680 <_stogir.checked.validate+0xe0>
    4674:      	movz	x4, #0x0, lsl #48
    4678:      	b	0x4680 <_stogir.checked.validate+0xe0>
    467c:      	movz	x4, #0x0, lsl #48
    4680:      	cmp	x4, #0x0
    4684:      	b.eq	0x46e8 <_stogir.checked.validate+0x148>
    4688:      	uxtb	w16, w3
    468c:      	cmp	w16, wzr
    4690:      	b.eq	0x46b8 <_stogir.checked.validate+0x118>
    4694:      	lsl	x3, x1, #4
    4698:      	ldr	x4, [x0]
    469c:      	add	x3, x3, x4
    46a0:      	ldr	x4, [x3]
    46a4:      	ldr	x3, [x3, #0x8]
    46a8:      	fmov	d31, x3
    46ac:      	mov	x3, x4
    46b0:      	fmov	x4, d31
    46b4:      	b	0x46d8 <_stogir.checked.validate+0x138>
    46b8:      	lsl	x3, x5, #4
    46bc:      	ldr	x4, [x0, #0x28]
    46c0:      	add	x3, x3, x4
    46c4:      	ldr	x4, [x3]
    46c8:      	ldr	x3, [x3, #0x8]
    46cc:      	fmov	d31, x3
    46d0:      	mov	x3, x4
    46d4:      	fmov	x4, d31
    46d8:      	mov	x5, x4
    46dc:      	mov	x4, x3
    46e0:      	mov	x3, #0x1                ; =1
    46e4:      	b	0x46f4 <_stogir.checked.validate+0x154>
    46e8:      	movz	x3, #0x0, lsl #48
    46ec:      	movz	x4, #0x0, lsl #48
    46f0:      	movz	x5, #0x0, lsl #48
    46f4:      	lsr	w3, w3, #0
    46f8:      	lsr	x16, x3, #0
    46fc:      	cmp	x16, #0x1
    4700:      	b.eq	0x471c <_stogir.checked.validate+0x17c>
    4704:      	b.lo	0x470c <_stogir.checked.validate+0x16c>
    4708:      	b	0x4720 <_stogir.checked.validate+0x180>
    470c:      	cmp	x16, #0x0
    4710:      	b.eq	0x4718 <_stogir.checked.validate+0x178>
    4714:      	b	0x4720 <_stogir.checked.validate+0x180>
    4718:      	b	0x4724 <_stogir.checked.validate+0x184>
    471c:      	b	0x4784 <_stogir.checked.validate+0x1e4>
    4720:      	b	0x4a80 <_stogir.checked.validate+0x4e0>
    4724:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004724:  ARM64_RELOC_PAGE21	l_stogir.360
    4728:      	ldr	x16, [x16]
		0000000000004728:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    472c:      	orr	x0, x16, xzr
    4730:      	mov	x1, x0
    4734:      	mov	x0, #0x1                ; =1
    4738:      	mov	x2, #0x1a               ; =26
    473c:      	b	0x4758 <_stogir.checked.validate+0x1b8>
    4740:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004740:  ARM64_RELOC_PAGE21	l_stogir.361
    4744:      	ldr	x16, [x16]
		0000000000004744:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    4748:      	orr	x0, x16, xzr
    474c:      	mov	x1, x0
    4750:      	mov	x0, #0x1                ; =1
    4754:      	mov	x2, #0x26               ; =38
    4758:      	str	x0, [x8]
    475c:      	str	x1, [x8, #0x8]
    4760:      	str	x2, [x8, #0x10]
    4764:      	sub	sp, x29, #0x0
    4768:      	ldr	x19, [sp, #0x10]
    476c:      	ldr	x20, [sp, #0x18]
    4770:      	ldr	x21, [sp, #0x20]
    4774:      	ldr	x29, [sp]
    4778:      	ldr	x30, [sp, #0x8]
    477c:      	add	sp, sp, #0x30
    4780:      	ret
    4784:      	cmp	x1, #0x0
    4788:      	b.le	0x4740 <_stogir.checked.validate+0x1a0>
    478c:      	uxtb	w1, w4
    4790:      	cmp	x1, #0x29
    4794:      	b.lt	0x4740 <_stogir.checked.validate+0x1a0>
    4798:      	cmp	x1, #0x2b
    479c:      	b.gt	0x4740 <_stogir.checked.validate+0x1a0>
    47a0:      	ldr	x1, [x0, #0x78]
    47a4:      	add	x1, x2, x1
    47a8:      	ldr	w1, [x1]
    47ac:      	sxtw	x1, w1
    47b0:      	cmp	x1, #0x2
    47b4:      	b.ne	0x4740 <_stogir.checked.validate+0x1a0>
    47b8:      	lsr	w1, w4, #0
    47bc:      	mov	x2, sp
    47c0:      	sub	sp, sp, #0x10
    47c4:      	mov	x3, sp
    47c8:      	sub	sp, sp, #0x10
    47cc:      	mov	x6, sp
    47d0:      	ubfx	x1, x1, #8, #8
    47d4:      	cmp	x1, #0x1
    47d8:      	b.lt	0x4a08 <_stogir.checked.validate+0x468>
    47dc:      	cmp	x1, #0xb
    47e0:      	b.gt	0x4a08 <_stogir.checked.validate+0x468>
    47e4:      	cmp	x1, #0x1
    47e8:      	b.eq	0x4a08 <_stogir.checked.validate+0x468>
    47ec:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		00000000000047ec:  ARM64_RELOC_PAGE21	l_stogir.362
    47f0:      	ldr	x16, [x16]
		00000000000047f0:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    47f4:      	orr	x7, x16, xzr
    47f8:      	movz	x9, #0x0, lsl #48
    47fc:      	b	0x4a18 <_stogir.checked.validate+0x478>
    4800:      	movz	x4, #0x0, lsl #48
    4804:      	b	0x4678 <_stogir.checked.validate+0xd8>
    4808:      	movz	x4, #0x0, lsl #48
    480c:      	b	0x4670 <_stogir.checked.validate+0xd0>
    4810:      	mov	x1, x3
    4814:      	mov	x3, x4
    4818:      	mov	x0, #0x1                ; =1
    481c:      	mov	sp, x2
    4820:      	mov	x2, x3
    4824:      	b	0x4758 <_stogir.checked.validate+0x1b8>
    4828:      	movz	x5, #0x0, lsl #48
    482c:      	movz	x6, #0x0, lsl #48
    4830:      	lsr	w5, w5, #0
    4834:      	lsr	x16, x5, #0
    4838:      	cmp	x16, #0x1
    483c:      	b.eq	0x4858 <_stogir.checked.validate+0x2b8>
    4840:      	b.lo	0x4848 <_stogir.checked.validate+0x2a8>
    4844:      	b	0x485c <_stogir.checked.validate+0x2bc>
    4848:      	cmp	x16, #0x0
    484c:      	b.eq	0x4854 <_stogir.checked.validate+0x2b4>
    4850:      	b	0x485c <_stogir.checked.validate+0x2bc>
    4854:      	b	0x4860 <_stogir.checked.validate+0x2c0>
    4858:      	b	0x49ec <_stogir.checked.validate+0x44c>
    485c:      	b	0x4a98 <_stogir.checked.validate+0x4f8>
    4860:      	mov	x3, x11
    4864:      	mov	x4, #0x22               ; =34
    4868:      	mov	x5, x7
    486c:      	cmp	x5, #0x2
    4870:      	b.ge	0x489c <_stogir.checked.validate+0x2fc>
    4874:      	add	x6, x5, #0x1
    4878:      	lsl	x5, x5, #2
    487c:      	add	x5, x5, x10
    4880:      	ldr	w5, [x5]
    4884:      	sxtw	x5, w5
    4888:      	and	x5, x5, #0xffffffff
    488c:      	mov	x7, x6
    4890:      	mov	x6, x5
    4894:      	mov	x5, #0x1                ; =1
    4898:      	b	0x48a8 <_stogir.checked.validate+0x308>
    489c:      	mov	x7, x5
    48a0:      	movz	x5, #0x0, lsl #48
    48a4:      	movz	x6, #0x0, lsl #48
    48a8:      	lsr	w5, w5, #0
    48ac:      	lsr	x16, x5, #0
    48b0:      	cmp	x16, #0x1
    48b4:      	b.eq	0x48d0 <_stogir.checked.validate+0x330>
    48b8:      	b.lo	0x48c0 <_stogir.checked.validate+0x320>
    48bc:      	b	0x48d4 <_stogir.checked.validate+0x334>
    48c0:      	cmp	x16, #0x0
    48c4:      	b.eq	0x48cc <_stogir.checked.validate+0x32c>
    48c8:      	b	0x48d4 <_stogir.checked.validate+0x334>
    48cc:      	b	0x493c <_stogir.checked.validate+0x39c>
    48d0:      	b	0x48d8 <_stogir.checked.validate+0x338>
    48d4:      	b	0x4a90 <_stogir.checked.validate+0x4f0>
    48d8:      	lsr	w6, w6, #0
    48dc:      	sxtw	x6, w6
    48e0:      	cmp	x6, #0x0
    48e4:      	cset	w5, gt
    48e8:      	movz	x16, #0x0, lsl #48
    48ec:      	sub	x9, x16, x6
    48f0:      	sub	x19, x9, #0x1
    48f4:      	uxtb	w16, w5
    48f8:      	cmp	w16, wzr
    48fc:      	b.eq	0x49a8 <_stogir.checked.validate+0x408>
    4900:      	ldr	x9, [x0, #0x8]
    4904:      	cmp	x6, x9
    4908:      	b.ge	0x49a0 <_stogir.checked.validate+0x400>
    490c:      	ldr	x9, [x13, #0x8]
    4910:      	cmp	x6, x9
    4914:      	b.ge	0x4a78 <_stogir.checked.validate+0x4d8>
    4918:      	lsl	x9, x6, #2
    491c:      	ldr	x20, [x0, #0x78]
    4920:      	add	x9, x9, x20
    4924:      	ldr	w9, [x9]
    4928:      	sxtw	x9, w9
    492c:      	cmp	x9, #0x0
    4930:      	cset	w9, ge
    4934:      	ubfx	x9, x9, #0, #8
    4938:      	b	0x4a7c <_stogir.checked.validate+0x4dc>
    493c:      	cmp	x4, #0x0
    4940:      	b.ne	0x4810 <_stogir.checked.validate+0x270>
    4944:      	and	x0, x1, #0xffffffff
    4948:      	mov	x1, x0
    494c:      	movz	x0, #0x0, lsl #48
    4950:      	movz	x3, #0x0, lsl #48
    4954:      	b	0x481c <_stogir.checked.validate+0x27c>
    4958:      	lsl	x5, x19, #4
    495c:      	ldr	x6, [x0, #0x28]
    4960:      	add	x5, x5, x6
    4964:      	ldr	x5, [x5]
    4968:      	mov	x6, x5
    496c:      	mov	x5, #0x1                ; =1
    4970:      	b	0x4830 <_stogir.checked.validate+0x290>
    4974:      	movz	x9, #0x0, lsl #48
    4978:      	cmp	x9, #0x0
    497c:      	b.eq	0x4828 <_stogir.checked.validate+0x288>
    4980:      	uxtb	w16, w5
    4984:      	cmp	w16, wzr
    4988:      	b.eq	0x4958 <_stogir.checked.validate+0x3b8>
    498c:      	lsl	x5, x6, #4
    4990:      	ldr	x6, [x0]
    4994:      	add	x5, x5, x6
    4998:      	ldr	x5, [x5]
    499c:      	b	0x4968 <_stogir.checked.validate+0x3c8>
    49a0:      	movz	x9, #0x0, lsl #48
    49a4:      	b	0x4978 <_stogir.checked.validate+0x3d8>
    49a8:      	cmp	x6, #0x0
    49ac:      	b.ge	0x4974 <_stogir.checked.validate+0x3d4>
    49b0:      	ldr	x20, [x14, #0x8]
    49b4:      	ldr	x21, [x15, #0x8]
    49b8:      	cmp	x20, x21
    49bc:      	b.ne	0x4a70 <_stogir.checked.validate+0x4d0>
    49c0:      	cmp	x9, x20
    49c4:      	b.gt	0x4a88 <_stogir.checked.validate+0x4e8>
    49c8:      	lsl	x9, x19, #2
    49cc:      	ldr	x20, [x0, #0x50]
    49d0:      	add	x9, x9, x20
    49d4:      	ldr	w9, [x9]
    49d8:      	sxtw	x9, w9
    49dc:      	cmp	x9, #0x0
    49e0:      	cset	w9, gt
    49e4:      	ubfx	x9, x9, #0, #8
    49e8:      	b	0x4a8c <_stogir.checked.validate+0x4ec>
    49ec:      	lsr	w6, w6, #0
    49f0:      	ubfx	x5, x6, #8, #8
    49f4:      	cmp	x5, x1
    49f8:      	b.eq	0x4a04 <_stogir.checked.validate+0x464>
    49fc:      	mov	x3, x12
    4a00:      	mov	x4, #0x28               ; =40
    4a04:      	b	0x4868 <_stogir.checked.validate+0x2c8>
    4a08:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004a08:  ARM64_RELOC_PAGE21	l_stogir.363
    4a0c:      	ldr	x16, [x16]
		0000000000004a0c:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    4a10:      	orr	x7, x16, xzr
    4a14:      	mov	x9, #0x36               ; =54
    4a18:      	orr	x10, x6, xzr
    4a1c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004a1c:  ARM64_RELOC_PAGE21	l_stogir.364
    4a20:      	ldr	x16, [x16]
		0000000000004a20:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    4a24:      	orr	x11, x16, xzr
    4a28:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004a28:  ARM64_RELOC_PAGE21	l_stogir.365
    4a2c:      	ldr	x16, [x16]
		0000000000004a2c:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    4a30:      	orr	x12, x16, xzr
    4a34:      	add	x13, x0, #0x78
    4a38:      	add	x14, x0, #0x28
    4a3c:      	add	x15, x0, #0x50
    4a40:      	lsr	w5, w5, #0
    4a44:      	lsr	x4, x4, #32
    4a48:      	lsr	w5, w5, #0
    4a4c:      	lsr	w4, w4, #0
    4a50:      	str	w4, [x3]
    4a54:      	str	w5, [x3, #0x4]
    4a58:      	ldr	x3, [x3]
    4a5c:      	str	x3, [x6]
    4a60:      	mov	x3, x7
    4a64:      	mov	x4, x9
    4a68:      	movz	x5, #0x0, lsl #48
    4a6c:      	b	0x486c <_stogir.checked.validate+0x2cc>
    4a70:      	movz	x9, #0x0, lsl #48
    4a74:      	b	0x4978 <_stogir.checked.validate+0x3d8>
    4a78:      	movz	x9, #0x0, lsl #48
    4a7c:      	b	0x49a4 <_stogir.checked.validate+0x404>
    4a80:      	brk	#0
    4a84:      	b	0x4a80 <_stogir.checked.validate+0x4e0>
    4a88:      	movz	x9, #0x0, lsl #48
    4a8c:      	b	0x4a74 <_stogir.checked.validate+0x4d4>
    4a90:      	brk	#0
    4a94:      	b	0x4a90 <_stogir.checked.validate+0x4f0>
    4a98:      	brk	#0
    4a9c:      	b	0x4a98 <_stogir.checked.validate+0x4f8>

0000000000004aa0 <_stogir.atomic.operation?>:
    4aa0:      	sxtw	x0, w0
    4aa4:      	cmp	x0, #0x7e
    4aa8:      	b.lt	0x4abc <_stogir.atomic.operation?+0x1c>
    4aac:      	cmp	x0, #0x82
    4ab0:      	cset	w0, le
    4ab4:      	ubfx	x0, x0, #0, #8
    4ab8:      	b	0x4ac0 <_stogir.atomic.operation?+0x20>
    4abc:      	movz	x0, #0x0, lsl #48
    4ac0:      	ret

0000000000004ac4 <_stogir.atomic.validate>:
    4ac4:      	sub	sp, sp, #0xf0
    4ac8:      	str	x29, [sp, #0x10]
    4acc:      	str	x30, [sp, #0x18]
    4ad0:      	add	x29, sp, #0x10
    4ad4:      	str	x19, [sp, #0xa0]
    4ad8:      	str	x20, [sp, #0xa8]
    4adc:      	str	x21, [sp, #0xb0]
    4ae0:      	str	x22, [sp, #0xb8]
    4ae4:      	str	x23, [sp, #0xc0]
    4ae8:      	str	x24, [sp, #0xc8]
    4aec:      	str	x25, [sp, #0xd0]
    4af0:      	str	x26, [sp, #0xd8]
    4af4:      	str	x27, [sp, #0xe0]
    4af8:      	sxtw	x2, w1
    4afc:      	lsl	x3, x2, #2
    4b00:      	cmp	x2, #0x0
    4b04:      	cset	w4, gt
    4b08:      	movz	x16, #0x0, lsl #48
    4b0c:      	sub	x5, x16, x2
    4b10:      	sub	x6, x5, #0x1
    4b14:      	uxtb	w16, w4
    4b18:      	cmp	w16, wzr
    4b1c:      	b.eq	0x4b5c <_stogir.atomic.validate+0x98>
    4b20:      	ldr	x5, [x0, #0x8]
    4b24:      	cmp	x2, x5
    4b28:      	b.ge	0x4bb0 <_stogir.atomic.validate+0xec>
    4b2c:      	add	x5, x0, #0x78
    4b30:      	ldr	x5, [x5, #0x8]
    4b34:      	cmp	x2, x5
    4b38:      	b.ge	0x4d18 <_stogir.atomic.validate+0x254>
    4b3c:      	ldr	x5, [x0, #0x78]
    4b40:      	add	x5, x3, x5
    4b44:      	ldr	w5, [x5]
    4b48:      	sxtw	x5, w5
    4b4c:      	cmp	x5, #0x0
    4b50:      	cset	w5, ge
    4b54:      	ubfx	x5, x5, #0, #8
    4b58:      	b	0x4d1c <_stogir.atomic.validate+0x258>
    4b5c:      	cmp	x2, #0x0
    4b60:      	b.ge	0x4bb8 <_stogir.atomic.validate+0xf4>
    4b64:      	add	x7, x0, #0x28
    4b68:      	add	x9, x0, #0x50
    4b6c:      	ldr	x7, [x7, #0x8]
    4b70:      	ldr	x9, [x9, #0x8]
    4b74:      	cmp	x7, x9
    4b78:      	b.ne	0x4ba8 <_stogir.atomic.validate+0xe4>
    4b7c:      	cmp	x5, x7
    4b80:      	b.gt	0x4db0 <_stogir.atomic.validate+0x2ec>
    4b84:      	lsl	x5, x6, #2
    4b88:      	ldr	x7, [x0, #0x50]
    4b8c:      	add	x5, x5, x7
    4b90:      	ldr	w5, [x5]
    4b94:      	sxtw	x5, w5
    4b98:      	cmp	x5, #0x0
    4b9c:      	cset	w5, gt
    4ba0:      	ubfx	x5, x5, #0, #8
    4ba4:      	b	0x4db4 <_stogir.atomic.validate+0x2f0>
    4ba8:      	movz	x5, #0x0, lsl #48
    4bac:      	b	0x4bbc <_stogir.atomic.validate+0xf8>
    4bb0:      	movz	x5, #0x0, lsl #48
    4bb4:      	b	0x4bbc <_stogir.atomic.validate+0xf8>
    4bb8:      	movz	x5, #0x0, lsl #48
    4bbc:      	cmp	x5, #0x0
    4bc0:      	b.eq	0x4c20 <_stogir.atomic.validate+0x15c>
    4bc4:      	uxtb	w16, w4
    4bc8:      	cmp	w16, wzr
    4bcc:      	b.eq	0x4bf4 <_stogir.atomic.validate+0x130>
    4bd0:      	lsl	x4, x2, #4
    4bd4:      	ldr	x5, [x0]
    4bd8:      	add	x4, x4, x5
    4bdc:      	ldr	x5, [x4]
    4be0:      	ldr	x4, [x4, #0x8]
    4be4:      	fmov	d31, x4
    4be8:      	mov	x4, x5
    4bec:      	fmov	x5, d31
    4bf0:      	b	0x4c14 <_stogir.atomic.validate+0x150>
    4bf4:      	lsl	x4, x6, #4
    4bf8:      	ldr	x5, [x0, #0x28]
    4bfc:      	add	x4, x4, x5
    4c00:      	ldr	x5, [x4]
    4c04:      	ldr	x4, [x4, #0x8]
    4c08:      	fmov	d31, x4
    4c0c:      	mov	x4, x5
    4c10:      	fmov	x5, d31
    4c14:      	mov	x19, x4
    4c18:      	mov	x4, #0x1                ; =1
    4c1c:      	b	0x4c2c <_stogir.atomic.validate+0x168>
    4c20:      	movz	x4, #0x0, lsl #48
    4c24:      	movz	x19, #0x0, lsl #48
    4c28:      	movz	x5, #0x0, lsl #48
    4c2c:      	lsr	w4, w4, #0
    4c30:      	lsr	x16, x4, #0
    4c34:      	cmp	x16, #0x1
    4c38:      	b.eq	0x4c54 <_stogir.atomic.validate+0x190>
    4c3c:      	b.lo	0x4c44 <_stogir.atomic.validate+0x180>
    4c40:      	b	0x4c58 <_stogir.atomic.validate+0x194>
    4c44:      	cmp	x16, #0x0
    4c48:      	b.eq	0x4c50 <_stogir.atomic.validate+0x18c>
    4c4c:      	b	0x4c58 <_stogir.atomic.validate+0x194>
    4c50:      	b	0x4c5c <_stogir.atomic.validate+0x198>
    4c54:      	b	0x4cb8 <_stogir.atomic.validate+0x1f4>
    4c58:      	b	0x5360 <_stogir.atomic.validate+0x89c>
    4c5c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004c5c:  ARM64_RELOC_PAGE21	l_stogir.366
    4c60:      	ldr	x16, [x16]
		0000000000004c60:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    4c64:      	orr	x0, x16, xzr
    4c68:      	mov	x23, x8
    4c6c:      	mov	x1, x0
    4c70:      	mov	x0, #0x1                ; =1
    4c74:      	mov	x2, #0x1a               ; =26
    4c78:      	str	x0, [x23]
    4c7c:      	str	x1, [x23, #0x8]
    4c80:      	str	x2, [x23, #0x10]
    4c84:      	ldr	x19, [sp, #0xa0]
    4c88:      	ldr	x20, [sp, #0xa8]
    4c8c:      	ldr	x21, [sp, #0xb0]
    4c90:      	ldr	x22, [sp, #0xb8]
    4c94:      	ldr	x23, [sp, #0xc0]
    4c98:      	ldr	x24, [sp, #0xc8]
    4c9c:      	ldr	x25, [sp, #0xd0]
    4ca0:      	ldr	x26, [sp, #0xd8]
    4ca4:      	ldr	x27, [sp, #0xe0]
    4ca8:      	ldr	x29, [sp, #0x10]
    4cac:      	ldr	x30, [sp, #0x18]
    4cb0:      	add	sp, sp, #0xf0
    4cb4:      	ret
    4cb8:      	uxtb	w4, w19
    4cbc:      	add	x16, sp, #0x20
    4cc0:      	str	x19, [x16]
    4cc4:      	orr	x20, x4, xzr
    4cc8:      	add	x16, sp, #0x20
    4ccc:      	str	x5, [x16, #0x8]
    4cd0:      	cmp	x2, #0x0
    4cd4:      	b.le	0x4d30 <_stogir.atomic.validate+0x26c>
    4cd8:      	cmp	x20, #0x7e
    4cdc:      	b.lt	0x4d30 <_stogir.atomic.validate+0x26c>
    4ce0:      	cmp	x20, #0x82
    4ce4:      	b.gt	0x4d30 <_stogir.atomic.validate+0x26c>
    4ce8:      	ldr	x2, [x0, #0x78]
    4cec:      	add	x2, x3, x2
    4cf0:      	ldr	w2, [x2]
    4cf4:      	cmp	x20, #0x83
    4cf8:      	b.ge	0x5280 <_stogir.atomic.validate+0x7bc>
    4cfc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004cfc:  ARM64_RELOC_PAGE21	l_stogir.367
    4d00:      	ldr	x16, [x16]
		0000000000004d00:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    4d04:      	orr	x3, x16, xzr
    4d08:      	add	x3, x20, x3
    4d0c:      	ldrsb	w3, [x3]
    4d10:      	sxtb	x3, w3
    4d14:      	b	0x5284 <_stogir.atomic.validate+0x7c0>
    4d18:      	movz	x5, #0x0, lsl #48
    4d1c:      	b	0x4bb4 <_stogir.atomic.validate+0xf0>
    4d20:      	mov	x2, x1
    4d24:      	mov	x1, x0
    4d28:      	mov	x0, #0x1                ; =1
    4d2c:      	b	0x4c78 <_stogir.atomic.validate+0x1b4>
    4d30:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004d30:  ARM64_RELOC_PAGE21	l_stogir.368
    4d34:      	ldr	x16, [x16]
		0000000000004d34:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    4d38:      	orr	x2, x16, xzr
    4d3c:      	mov	x21, x2
    4d40:      	mov	x22, #0x20              ; =32
    4d44:      	add	x16, sp, #0x20
    4d48:      	ldr	w2, [x16, #0x4]
    4d4c:      	lsr	w2, w2, #0
    4d50:      	mov	x23, x8
    4d54:      	add	x8, sp, #0x30
    4d58:      	mov	x24, x0
    4d5c:      	mov	w25, w1
    4d60:      	mov	w1, w2
    4d64:      	bl	0x4d64 <_stogir.atomic.validate+0x2a0>
		0000000000004d64:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4d68:      	add	x16, sp, #0x30
    4d6c:      	ldr	w0, [x16]
    4d70:      	lsr	x16, x0, #0
    4d74:      	cmp	x16, #0x1
    4d78:      	b.eq	0x4d94 <_stogir.atomic.validate+0x2d0>
    4d7c:      	b.lo	0x4d84 <_stogir.atomic.validate+0x2c0>
    4d80:      	b	0x4d98 <_stogir.atomic.validate+0x2d4>
    4d84:      	cmp	x16, #0x0
    4d88:      	b.eq	0x4d90 <_stogir.atomic.validate+0x2cc>
    4d8c:      	b	0x4d98 <_stogir.atomic.validate+0x2d4>
    4d90:      	b	0x4d9c <_stogir.atomic.validate+0x2d8>
    4d94:      	b	0x4e94 <_stogir.atomic.validate+0x3d0>
    4d98:      	b	0x5394 <_stogir.atomic.validate+0x8d0>
    4d9c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004d9c:  ARM64_RELOC_PAGE21	l_stogir.369
    4da0:      	ldr	x16, [x16]
		0000000000004da0:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    4da4:      	orr	x0, x16, xzr
    4da8:      	mov	x1, #0x16               ; =22
    4dac:      	b	0x4dc0 <_stogir.atomic.validate+0x2fc>
    4db0:      	movz	x5, #0x0, lsl #48
    4db4:      	b	0x4bac <_stogir.atomic.validate+0xe8>
    4db8:      	mov	x0, x1
    4dbc:      	mov	x1, x22
    4dc0:      	cmp	x20, #0x82
    4dc4:      	cset	w21, eq
    4dc8:      	lsr	w19, w19, #0
    4dcc:      	ubfx	x2, x19, #8, #8
    4dd0:      	orr	x19, x2, xzr
    4dd4:      	cmp	x19, #0x0
    4dd8:      	cset	w22, eq
    4ddc:      	uxtb	w16, w21
    4de0:      	cmp	w16, wzr
    4de4:      	b.eq	0x4e0c <_stogir.atomic.validate+0x348>
    4de8:      	uxtb	w16, w22
    4dec:      	cmp	w16, wzr
    4df0:      	b.ne	0x4e04 <_stogir.atomic.validate+0x340>
    4df4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004df4:  ARM64_RELOC_PAGE21	l_stogir.370
    4df8:      	ldr	x16, [x16]
		0000000000004df8:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    4dfc:      	orr	x0, x16, xzr
    4e00:      	mov	x1, #0x19               ; =25
    4e04:      	mov	x26, x1
    4e08:      	b	0x4e10 <_stogir.atomic.validate+0x34c>
    4e0c:      	mov	x26, x1
    4e10:      	uxtb	w16, w21
    4e14:      	cmp	w16, wzr
    4e18:      	b.eq	0x4e28 <_stogir.atomic.validate+0x364>
    4e1c:      	mov	x27, x0
    4e20:      	movz	x0, #0x0, lsl #48
    4e24:      	b	0x4e30 <_stogir.atomic.validate+0x36c>
    4e28:      	mov	x27, x0
    4e2c:      	mov	x0, #0x1                ; =1
    4e30:      	cmp	x0, #0x0
    4e34:      	b.eq	0x4e68 <_stogir.atomic.validate+0x3a4>
    4e38:      	add	x16, sp, #0x20
    4e3c:      	ldr	w0, [x16, #0x8]
    4e40:      	lsr	w0, w0, #0
    4e44:      	mov	w1, w0
    4e48:      	mov	x0, x24
    4e4c:      	mov	x2, #0x6                ; =6
    4e50:      	bl	0x4e50 <_stogir.atomic.validate+0x38c>
		0000000000004e50:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4e54:      	cmp	x0, #0x0
    4e58:      	b.eq	0x4fcc <_stogir.atomic.validate+0x508>
    4e5c:      	mov	x1, x27
    4e60:      	movz	x0, #0x0, lsl #48
    4e64:      	b	0x4fd4 <_stogir.atomic.validate+0x510>
    4e68:      	mov	x0, x19
    4e6c:      	mov	x1, x27
    4e70:      	mov	x19, x26
    4e74:      	cmp	x20, #0x80
    4e78:      	cset	w22, eq
    4e7c:      	uxtb	w16, w22
    4e80:      	cmp	w16, wzr
    4e84:      	b.eq	0x4ebc <_stogir.atomic.validate+0x3f8>
    4e88:      	mov	x20, x1
    4e8c:      	mov	x1, #0x1                ; =1
    4e90:      	b	0x4ed0 <_stogir.atomic.validate+0x40c>
    4e94:      	add	x16, sp, #0x30
    4e98:      	ldr	x0, [x16, #0x8]
    4e9c:      	add	x16, sp, #0x20
    4ea0:      	ldr	w1, [x16, #0x4]
    4ea4:      	sxtw	x1, w1
    4ea8:      	cmp	x1, #0x0
    4eac:      	b.gt	0x503c <_stogir.atomic.validate+0x578>
    4eb0:      	mov	x1, x21
    4eb4:      	mov	x0, #0x1                ; =1
    4eb8:      	b	0x5020 <_stogir.atomic.validate+0x55c>
    4ebc:      	cmp	x20, #0x81
    4ec0:      	cset	w2, eq
    4ec4:      	ubfx	x2, x2, #0, #8
    4ec8:      	mov	x20, x1
    4ecc:      	mov	x1, x2
    4ed0:      	lsr	w26, w0, #0
    4ed4:      	cmp	x1, #0x0
    4ed8:      	b.eq	0x4f58 <_stogir.atomic.validate+0x494>
    4edc:      	lsr	w25, w25, #0
    4ee0:      	add	x16, sp, #0x90
    4ee4:      	str	x16, [sp]
    4ee8:      	mov	x0, x24
    4eec:      	mov	w1, w25
    4ef0:      	mov	x2, #0x4                ; =4
    4ef4:      	bl	0x4ef4 <_stogir.atomic.validate+0x430>
		0000000000004ef4:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    4ef8:      	ldr	x16, [sp]
    4efc:      	str	x0, [x16]
    4f00:      	str	x1, [x16, #0x8]
    4f04:      	add	x16, sp, #0x90
    4f08:      	ldr	x0, [x16]
    4f0c:      	add	x16, sp, #0x90
    4f10:      	ldr	x1, [x16, #0x8]
    4f14:      	lsr	w0, w0, #0
    4f18:      	lsr	x16, x0, #0
    4f1c:      	cmp	x16, #0x1
    4f20:      	b.eq	0x4f3c <_stogir.atomic.validate+0x478>
    4f24:      	b.lo	0x4f2c <_stogir.atomic.validate+0x468>
    4f28:      	b	0x4f40 <_stogir.atomic.validate+0x47c>
    4f2c:      	cmp	x16, #0x0
    4f30:      	b.eq	0x4f38 <_stogir.atomic.validate+0x474>
    4f34:      	b	0x4f40 <_stogir.atomic.validate+0x47c>
    4f38:      	b	0x4f44 <_stogir.atomic.validate+0x480>
    4f3c:      	b	0x5174 <_stogir.atomic.validate+0x6b0>
    4f40:      	b	0x53a4 <_stogir.atomic.validate+0x8e0>
    4f44:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004f44:  ARM64_RELOC_PAGE21	l_stogir.371
    4f48:      	ldr	x16, [x16]
		0000000000004f48:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    4f4c:      	orr	x0, x16, xzr
    4f50:      	mov	x1, #0x1d               ; =29
    4f54:      	b	0x4fc8 <_stogir.atomic.validate+0x504>
    4f58:      	mov	x0, x20
    4f5c:      	mov	x1, x19
    4f60:      	cmp	x1, #0x0
    4f64:      	b.ne	0x4d20 <_stogir.atomic.validate+0x25c>
    4f68:      	uxtb	w16, w21
    4f6c:      	cmp	w16, wzr
    4f70:      	b.eq	0x5160 <_stogir.atomic.validate+0x69c>
    4f74:      	movz	x0, #0x0, lsl #48
    4f78:      	b	0x4fa4 <_stogir.atomic.validate+0x4e0>
    4f7c:      	mov	x0, x1
    4f80:      	mov	x1, x22
    4f84:      	fmov	d31, x0
    4f88:      	mov	x0, x19
    4f8c:      	mov	x19, x1
    4f90:      	fmov	x1, d31
    4f94:      	b	0x4e74 <_stogir.atomic.validate+0x3b0>
    4f98:      	mov	x0, #0x1                ; =1
    4f9c:      	lsr	w0, w0, #0
    4fa0:      	sxtw	x0, w0
    4fa4:      	and	x0, x0, #0xffffffff
    4fa8:      	mov	x1, x0
    4fac:      	movz	x0, #0x0, lsl #48
    4fb0:      	movz	x2, #0x0, lsl #48
    4fb4:      	b	0x4d2c <_stogir.atomic.validate+0x268>
    4fb8:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004fb8:  ARM64_RELOC_PAGE21	l_stogir.372
    4fbc:      	ldr	x16, [x16]
		0000000000004fbc:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    4fc0:      	orr	x0, x16, xzr
    4fc4:      	mov	x1, #0x24               ; =36
    4fc8:      	b	0x4f60 <_stogir.atomic.validate+0x49c>
    4fcc:      	mov	x1, x27
    4fd0:      	mov	x0, #0x1                ; =1
    4fd4:      	cmp	x0, #0x0
    4fd8:      	b.eq	0x4ff0 <_stogir.atomic.validate+0x52c>
    4fdc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2dc>
		0000000000004fdc:  ARM64_RELOC_PAGE21	l_stogir.373
    4fe0:      	ldr	x16, [x16]
		0000000000004fe0:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    4fe4:      	orr	x0, x16, xzr
    4fe8:      	mov	x1, #0x1b               ; =27
    4fec:      	b	0x4ff8 <_stogir.atomic.validate+0x534>
    4ff0:      	mov	x0, x1
    4ff4:      	mov	x1, x26
    4ff8:      	cmp	x20, #0x7f
    4ffc:      	b.ne	0x5090 <_stogir.atomic.validate+0x5cc>
    5000:      	uxtb	w16, w22
    5004:      	cmp	w16, wzr
    5008:      	b.eq	0x519c <_stogir.atomic.validate+0x6d8>
    500c:      	mov	x22, x0
    5010:      	mov	x26, x1
    5014:      	b	0x51b0 <_stogir.atomic.validate+0x6ec>
    5018:      	mov	x0, #0x1                ; =1
    501c:      	mov	x1, x21
    5020:      	cmp	x0, #0x0
    5024:      	b.eq	0x4db8 <_stogir.atomic.validate+0x2f4>
    5028:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005028:  ARM64_RELOC_PAGE21	l_stogir.374
    502c:      	ldr	x16, [x16]
		000000000000502c:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    5030:      	orr	x0, x16, xzr
    5034:      	mov	x1, #0x16               ; =22
    5038:      	b	0x4dc0 <_stogir.atomic.validate+0x2fc>
    503c:      	uxtb	w0, w0
    5040:      	cmp	x0, #0x83
    5044:      	cset	w1, lt
    5048:      	uxtb	w16, w1
    504c:      	cmp	w16, wzr
    5050:      	b.eq	0x5244 <_stogir.atomic.validate+0x780>
    5054:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005054:  ARM64_RELOC_PAGE21	l_stogir.375
    5058:      	ldr	x16, [x16]
		0000000000005058:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    505c:      	orr	x2, x16, xzr
    5060:      	add	x2, x0, x2
    5064:      	ldrb	w2, [x2]
    5068:      	b	0x5248 <_stogir.atomic.validate+0x784>
    506c:      	add	x16, sp, #0x60
    5070:      	ldr	x0, [x16, #0x8]
    5074:      	lsr	w0, w0, #0
    5078:      	ubfx	x0, x0, #8, #8
    507c:      	mov	x1, x22
    5080:      	mov	x2, x26
    5084:      	mov	x19, x0
    5088:      	mov	x0, x1
    508c:      	mov	x1, x2
    5090:      	cmp	x19, #0x2
    5094:      	b.ge	0x512c <_stogir.atomic.validate+0x668>
    5098:      	mov	x2, x1
    509c:      	mov	x1, #0x1                ; =1
    50a0:      	b	0x5144 <_stogir.atomic.validate+0x680>
    50a4:      	mov	x1, x26
    50a8:      	movz	x0, #0x0, lsl #48
    50ac:      	cmp	x0, #0x0
    50b0:      	b.eq	0x4f7c <_stogir.atomic.validate+0x4b8>
    50b4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		00000000000050b4:  ARM64_RELOC_PAGE21	l_stogir.376
    50b8:      	ldr	x16, [x16]
		00000000000050b8:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    50bc:      	orr	x0, x16, xzr
    50c0:      	mov	x1, #0x22               ; =34
    50c4:      	b	0x4f84 <_stogir.atomic.validate+0x4c0>
    50c8:      	mov	x1, x26
    50cc:      	mov	x0, #0x1                ; =1
    50d0:      	b	0x50ac <_stogir.atomic.validate+0x5e8>
    50d4:      	mov	x26, x0
    50d8:      	mov	x0, #0x1                ; =1
    50dc:      	cmp	x0, #0x0
    50e0:      	b.eq	0x50a4 <_stogir.atomic.validate+0x5e0>
    50e4:      	lsr	w0, w19, #0
    50e8:      	add	x16, sp, #0x20
    50ec:      	ldr	w1, [x16, #0xc]
    50f0:      	lsr	w1, w1, #0
    50f4:      	mov	w2, w0
    50f8:      	mov	x0, x24
    50fc:      	bl	0x50fc <_stogir.atomic.validate+0x638>
		00000000000050fc:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5100:      	cmp	x0, #0x0
    5104:      	b.eq	0x50c8 <_stogir.atomic.validate+0x604>
    5108:      	mov	x1, x26
    510c:      	movz	x0, #0x0, lsl #48
    5110:      	b	0x50d0 <_stogir.atomic.validate+0x60c>
    5114:      	mov	x22, x2
    5118:      	cmp	x20, #0x7e
    511c:      	b.ne	0x50d4 <_stogir.atomic.validate+0x610>
    5120:      	mov	x26, x0
    5124:      	movz	x0, #0x0, lsl #48
    5128:      	b	0x50dc <_stogir.atomic.validate+0x618>
    512c:      	cmp	x19, #0x5
    5130:      	cset	w2, gt
    5134:      	ubfx	x2, x2, #0, #8
    5138:      	fmov	d31, x1
    513c:      	mov	x1, x2
    5140:      	fmov	x2, d31
    5144:      	cmp	x1, #0x0
    5148:      	b.eq	0x5114 <_stogir.atomic.validate+0x650>
    514c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		000000000000514c:  ARM64_RELOC_PAGE21	l_stogir.377
    5150:      	ldr	x16, [x16]
		0000000000005150:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    5154:      	orr	x0, x16, xzr
    5158:      	mov	x22, #0x25              ; =37
    515c:      	b	0x5118 <_stogir.atomic.validate+0x654>
    5160:      	sxtw	x26, w26
    5164:      	cmp	x26, #0x0
    5168:      	b.ne	0x52b0 <_stogir.atomic.validate+0x7ec>
    516c:      	movz	x0, #0x0, lsl #48
    5170:      	b	0x4f9c <_stogir.atomic.validate+0x4d8>
    5174:      	lsr	w1, w1, #0
    5178:      	uxtb	w16, w22
    517c:      	cmp	w16, wzr
    5180:      	b.eq	0x533c <_stogir.atomic.validate+0x878>
    5184:      	sxtw	x1, w1
    5188:      	cmp	x1, #0x0
    518c:      	b.ge	0x5368 <_stogir.atomic.validate+0x8a4>
    5190:      	mov	x1, x20
    5194:      	mov	x0, #0x1                ; =1
    5198:      	b	0x5378 <_stogir.atomic.validate+0x8b4>
    519c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		000000000000519c:  ARM64_RELOC_PAGE21	l_stogir.378
    51a0:      	ldr	x16, [x16]
		00000000000051a0:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    51a4:      	orr	x0, x16, xzr
    51a8:      	mov	x22, x0
    51ac:      	mov	x26, #0x19              ; =25
    51b0:      	add	x16, sp, #0x20
    51b4:      	ldr	w0, [x16, #0xc]
    51b8:      	lsr	w0, w0, #0
    51bc:      	add	x8, sp, #0x60
    51c0:      	mov	w1, w0
    51c4:      	mov	x0, x24
    51c8:      	bl	0x51c8 <_stogir.atomic.validate+0x704>
		00000000000051c8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    51cc:      	add	x16, sp, #0x60
    51d0:      	ldr	w0, [x16]
    51d4:      	lsr	x16, x0, #0
    51d8:      	cmp	x16, #0x1
    51dc:      	b.eq	0x51f8 <_stogir.atomic.validate+0x734>
    51e0:      	b.lo	0x51e8 <_stogir.atomic.validate+0x724>
    51e4:      	b	0x51fc <_stogir.atomic.validate+0x738>
    51e8:      	cmp	x16, #0x0
    51ec:      	b.eq	0x51f4 <_stogir.atomic.validate+0x730>
    51f0:      	b	0x51fc <_stogir.atomic.validate+0x738>
    51f4:      	b	0x5200 <_stogir.atomic.validate+0x73c>
    51f8:      	b	0x506c <_stogir.atomic.validate+0x5a8>
    51fc:      	b	0x53ac <_stogir.atomic.validate+0x8e8>
    5200:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005200:  ARM64_RELOC_PAGE21	l_stogir.379
    5204:      	ldr	x16, [x16]
		0000000000005204:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    5208:      	orr	x0, x16, xzr
    520c:      	mov	x1, x0
    5210:      	mov	x0, x19
    5214:      	mov	x2, #0x1a               ; =26
    5218:      	b	0x5084 <_stogir.atomic.validate+0x5c0>
    521c:      	movz	x0, #0x0, lsl #48
    5220:      	uxtb	w0, w0
    5224:      	and	x0, x0, #0x4
    5228:      	uxtb	w0, w0
    522c:      	cmp	x0, #0x0
    5230:      	cset	w0, eq
    5234:      	uxtb	w16, w0
    5238:      	cmp	w16, wzr
    523c:      	cset	x0, eq
    5240:      	b	0x501c <_stogir.atomic.validate+0x558>
    5244:      	movz	x2, #0x0, lsl #48
    5248:      	uxtb	w2, w2
    524c:      	and	x2, x2, #0x1
    5250:      	uxtb	w2, w2
    5254:      	cmp	x2, #0x0
    5258:      	b.eq	0x5018 <_stogir.atomic.validate+0x554>
    525c:      	uxtb	w16, w1
    5260:      	cmp	w16, wzr
    5264:      	b.eq	0x521c <_stogir.atomic.validate+0x758>
    5268:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005268:  ARM64_RELOC_PAGE21	l_stogir.375
    526c:      	ldr	x16, [x16]
		000000000000526c:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    5270:      	orr	x1, x16, xzr
    5274:      	add	x0, x0, x1
    5278:      	ldrb	w0, [x0]
    527c:      	b	0x5220 <_stogir.atomic.validate+0x75c>
    5280:      	mov	x3, #-0x2               ; =-2
    5284:      	sxtw	x2, w2
    5288:      	lsr	w3, w3, #0
    528c:      	sxtw	x3, w3
    5290:      	cmp	x2, x3
    5294:      	b.ne	0x4d30 <_stogir.atomic.validate+0x26c>
    5298:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005298:  ARM64_RELOC_PAGE21	l_stogir.380
    529c:      	ldr	x16, [x16]
		000000000000529c:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    52a0:      	orr	x2, x16, xzr
    52a4:      	mov	x21, x2
    52a8:      	movz	x22, #0x0, lsl #48
    52ac:      	b	0x4d44 <_stogir.atomic.validate+0x280>
    52b0:      	cmp	x26, #0x1
    52b4:      	b.eq	0x4f98 <_stogir.atomic.validate+0x4d4>
    52b8:      	cmp	x26, #0x2
    52bc:      	b.eq	0x4f98 <_stogir.atomic.validate+0x4d4>
    52c0:      	cmp	x26, #0x7
    52c4:      	b.eq	0x4f98 <_stogir.atomic.validate+0x4d4>
    52c8:      	cmp	x26, #0x8
    52cc:      	b.eq	0x4f98 <_stogir.atomic.validate+0x4d4>
    52d0:      	cmp	x26, #0x3
    52d4:      	b.eq	0x539c <_stogir.atomic.validate+0x8d8>
    52d8:      	cmp	x26, #0x9
    52dc:      	b.eq	0x539c <_stogir.atomic.validate+0x8d8>
    52e0:      	cmp	x26, #0x4
    52e4:      	b.eq	0x53b4 <_stogir.atomic.validate+0x8f0>
    52e8:      	cmp	x26, #0xa
    52ec:      	b.eq	0x53b4 <_stogir.atomic.validate+0x8f0>
    52f0:      	cmp	x26, #0xd
    52f4:      	b.eq	0x53b4 <_stogir.atomic.validate+0x8f0>
    52f8:      	cmp	x26, #0x5
    52fc:      	b.eq	0x53bc <_stogir.atomic.validate+0x8f8>
    5300:      	cmp	x26, #0xb
    5304:      	b.eq	0x53bc <_stogir.atomic.validate+0x8f8>
    5308:      	cmp	x26, #0xc
    530c:      	b.eq	0x53bc <_stogir.atomic.validate+0x8f8>
    5310:      	cmp	x26, #0x6
    5314:      	cset	w0, eq
    5318:      	uxtb	w16, w0
    531c:      	cmp	w16, wzr
    5320:      	mov	x16, #0x8               ; =8
    5324:      	movn	x17, #0x0, lsl #48
    5328:      	csel	x0, x16, x17, ne
    532c:      	b	0x53c0 <_stogir.atomic.validate+0x8fc>
    5330:      	mov	x0, x1
    5334:      	mov	x1, x19
    5338:      	b	0x4fc8 <_stogir.atomic.validate+0x504>
    533c:      	lsr	w1, w1, #0
    5340:      	mov	x0, x24
    5344:      	mov	w2, w26
    5348:      	bl	0x5348 <_stogir.atomic.validate+0x884>
		0000000000005348:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    534c:      	cmp	x0, #0x0
    5350:      	b.eq	0x4fb8 <_stogir.atomic.validate+0x4f4>
    5354:      	mov	x0, x20
    5358:      	mov	x1, x19
    535c:      	b	0x4fc8 <_stogir.atomic.validate+0x504>
    5360:      	brk	#0
    5364:      	b	0x5360 <_stogir.atomic.validate+0x89c>
    5368:      	cmp	x1, #0x9
    536c:      	cset	w0, gt
    5370:      	ubfx	x0, x0, #0, #8
    5374:      	mov	x1, x20
    5378:      	cmp	x0, #0x0
    537c:      	b.eq	0x5330 <_stogir.atomic.validate+0x86c>
    5380:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005380:  ARM64_RELOC_PAGE21	l_stogir.381
    5384:      	ldr	x16, [x16]
		0000000000005384:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    5388:      	orr	x0, x16, xzr
    538c:      	mov	x1, #0x1c               ; =28
    5390:      	b	0x5338 <_stogir.atomic.validate+0x874>
    5394:      	brk	#0
    5398:      	b	0x5394 <_stogir.atomic.validate+0x8d0>
    539c:      	mov	x0, #0x2                ; =2
    53a0:      	b	0x4f9c <_stogir.atomic.validate+0x4d8>
    53a4:      	brk	#0
    53a8:      	b	0x53a4 <_stogir.atomic.validate+0x8e0>
    53ac:      	brk	#0
    53b0:      	b	0x53ac <_stogir.atomic.validate+0x8e8>
    53b4:      	mov	x0, #0x4                ; =4
    53b8:      	b	0x53a0 <_stogir.atomic.validate+0x8dc>
    53bc:      	mov	x0, #0x8                ; =8
    53c0:      	b	0x53b8 <_stogir.atomic.validate+0x8f4>

00000000000053c4 <_stogir.terminal.operation?>:
    53c4:      	sxtw	x0, w0
    53c8:      	cmp	x0, #0x60
    53cc:      	b.ne	0x53d8 <_stogir.terminal.operation?+0x14>
    53d0:      	mov	x0, #0x1                ; =1
    53d4:      	b	0x53e4 <_stogir.terminal.operation?+0x20>
    53d8:      	cmp	x0, #0x79
    53dc:      	cset	w0, eq
    53e0:      	ubfx	x0, x0, #0, #8
    53e4:      	ret

00000000000053e8 <_stogir.terminal.validate>:
    53e8:      	sub	sp, sp, #0x50
    53ec:      	str	x29, [sp]
    53f0:      	str	x30, [sp, #0x8]
    53f4:      	mov	x29, sp
    53f8:      	str	x19, [sp, #0x40]
    53fc:      	sxtw	x1, w1
    5400:      	lsl	x2, x1, #2
    5404:      	cmp	x1, #0x0
    5408:      	cset	w3, gt
    540c:      	movz	x16, #0x0, lsl #48
    5410:      	sub	x4, x16, x1
    5414:      	sub	x5, x4, #0x1
    5418:      	uxtb	w16, w3
    541c:      	cmp	w16, wzr
    5420:      	b.eq	0x5460 <_stogir.terminal.validate+0x78>
    5424:      	ldr	x4, [x0, #0x8]
    5428:      	cmp	x1, x4
    542c:      	b.ge	0x54b4 <_stogir.terminal.validate+0xcc>
    5430:      	add	x4, x0, #0x78
    5434:      	ldr	x4, [x4, #0x8]
    5438:      	cmp	x1, x4
    543c:      	b.ge	0x55d8 <_stogir.terminal.validate+0x1f0>
    5440:      	ldr	x4, [x0, #0x78]
    5444:      	add	x4, x2, x4
    5448:      	ldr	w4, [x4]
    544c:      	sxtw	x4, w4
    5450:      	cmp	x4, #0x0
    5454:      	cset	w4, ge
    5458:      	ubfx	x4, x4, #0, #8
    545c:      	b	0x55dc <_stogir.terminal.validate+0x1f4>
    5460:      	cmp	x1, #0x0
    5464:      	b.ge	0x54bc <_stogir.terminal.validate+0xd4>
    5468:      	add	x6, x0, #0x28
    546c:      	add	x7, x0, #0x50
    5470:      	ldr	x6, [x6, #0x8]
    5474:      	ldr	x7, [x7, #0x8]
    5478:      	cmp	x6, x7
    547c:      	b.ne	0x54ac <_stogir.terminal.validate+0xc4>
    5480:      	cmp	x4, x6
    5484:      	b.gt	0x5618 <_stogir.terminal.validate+0x230>
    5488:      	lsl	x4, x5, #2
    548c:      	ldr	x6, [x0, #0x50]
    5490:      	add	x4, x4, x6
    5494:      	ldr	w4, [x4]
    5498:      	sxtw	x4, w4
    549c:      	cmp	x4, #0x0
    54a0:      	cset	w4, gt
    54a4:      	ubfx	x4, x4, #0, #8
    54a8:      	b	0x561c <_stogir.terminal.validate+0x234>
    54ac:      	movz	x4, #0x0, lsl #48
    54b0:      	b	0x54c0 <_stogir.terminal.validate+0xd8>
    54b4:      	movz	x4, #0x0, lsl #48
    54b8:      	b	0x54c0 <_stogir.terminal.validate+0xd8>
    54bc:      	movz	x4, #0x0, lsl #48
    54c0:      	cmp	x4, #0x0
    54c4:      	b.eq	0x5528 <_stogir.terminal.validate+0x140>
    54c8:      	uxtb	w16, w3
    54cc:      	cmp	w16, wzr
    54d0:      	b.eq	0x54f8 <_stogir.terminal.validate+0x110>
    54d4:      	lsl	x3, x1, #4
    54d8:      	ldr	x4, [x0]
    54dc:      	add	x3, x3, x4
    54e0:      	ldr	x4, [x3]
    54e4:      	ldr	x3, [x3, #0x8]
    54e8:      	fmov	d31, x3
    54ec:      	mov	x3, x4
    54f0:      	fmov	x4, d31
    54f4:      	b	0x5518 <_stogir.terminal.validate+0x130>
    54f8:      	lsl	x3, x5, #4
    54fc:      	ldr	x4, [x0, #0x28]
    5500:      	add	x3, x3, x4
    5504:      	ldr	x4, [x3]
    5508:      	ldr	x3, [x3, #0x8]
    550c:      	fmov	d31, x3
    5510:      	mov	x3, x4
    5514:      	fmov	x4, d31
    5518:      	mov	x5, x4
    551c:      	mov	x4, x3
    5520:      	mov	x3, #0x1                ; =1
    5524:      	b	0x5534 <_stogir.terminal.validate+0x14c>
    5528:      	movz	x3, #0x0, lsl #48
    552c:      	movz	x4, #0x0, lsl #48
    5530:      	movz	x5, #0x0, lsl #48
    5534:      	lsr	w3, w3, #0
    5538:      	lsr	x16, x3, #0
    553c:      	cmp	x16, #0x1
    5540:      	b.eq	0x555c <_stogir.terminal.validate+0x174>
    5544:      	b.lo	0x554c <_stogir.terminal.validate+0x164>
    5548:      	b	0x5560 <_stogir.terminal.validate+0x178>
    554c:      	cmp	x16, #0x0
    5550:      	b.eq	0x5558 <_stogir.terminal.validate+0x170>
    5554:      	b	0x5560 <_stogir.terminal.validate+0x178>
    5558:      	b	0x5564 <_stogir.terminal.validate+0x17c>
    555c:      	b	0x5584 <_stogir.terminal.validate+0x19c>
    5560:      	b	0x56f4 <_stogir.terminal.validate+0x30c>
    5564:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005564:  ARM64_RELOC_PAGE21	l_stogir.382
    5568:      	ldr	x16, [x16]
		0000000000005568:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    556c:      	orr	x0, x16, xzr
    5570:      	mov	x19, x8
    5574:      	mov	x1, x0
    5578:      	mov	x0, #0x1                ; =1
    557c:      	mov	x2, #0x21               ; =33
    5580:      	b	0x55b8 <_stogir.terminal.validate+0x1d0>
    5584:      	add	x16, sp, #0x10
    5588:      	str	x4, [x16]
    558c:      	add	x16, sp, #0x10
    5590:      	str	x5, [x16, #0x8]
    5594:      	cmp	x1, #0x0
    5598:      	b.gt	0x55e0 <_stogir.terminal.validate+0x1f8>
    559c:      	mov	x19, x8
    55a0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		00000000000055a0:  ARM64_RELOC_PAGE21	l_stogir.383
    55a4:      	ldr	x16, [x16]
		00000000000055a4:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    55a8:      	orr	x0, x16, xzr
    55ac:      	mov	x1, x0
    55b0:      	mov	x0, #0x1                ; =1
    55b4:      	mov	x2, #0x1b               ; =27
    55b8:      	str	x0, [x19]
    55bc:      	str	x1, [x19, #0x8]
    55c0:      	str	x2, [x19, #0x10]
    55c4:      	ldr	x19, [sp, #0x40]
    55c8:      	ldr	x29, [sp]
    55cc:      	ldr	x30, [sp, #0x8]
    55d0:      	add	sp, sp, #0x50
    55d4:      	ret
    55d8:      	movz	x4, #0x0, lsl #48
    55dc:      	b	0x54b8 <_stogir.terminal.validate+0xd0>
    55e0:      	uxtb	w4, w4
    55e4:      	orr	x1, x4, xzr
    55e8:      	cmp	x1, #0x60
    55ec:      	cset	w3, eq
    55f0:      	cmp	x1, #0x79
    55f4:      	cset	w1, eq
    55f8:      	uxtb	w16, w3
    55fc:      	cmp	w16, wzr
    5600:      	b.ne	0x5620 <_stogir.terminal.validate+0x238>
    5604:      	uxtb	w16, w1
    5608:      	cmp	w16, wzr
    560c:      	b.ne	0x5620 <_stogir.terminal.validate+0x238>
    5610:      	mov	x19, x8
    5614:      	b	0x55a0 <_stogir.terminal.validate+0x1b8>
    5618:      	movz	x4, #0x0, lsl #48
    561c:      	b	0x54b0 <_stogir.terminal.validate+0xc8>
    5620:      	add	x16, sp, #0x10
    5624:      	ldr	w5, [x16]
    5628:      	ubfx	x5, x5, #8, #8
    562c:      	cmp	x5, #0x0
    5630:      	b.ne	0x56fc <_stogir.terminal.validate+0x314>
    5634:      	uxtb	w16, w3
    5638:      	cmp	w16, wzr
    563c:      	mov	x16, #0x1               ; =1
    5640:      	mov	x17, #0x3               ; =3
    5644:      	csel	x3, x16, x17, ne
    5648:      	lsr	w3, w3, #0
    564c:      	sxtw	x3, w3
    5650:      	ldr	x5, [x0, #0x78]
    5654:      	add	x2, x2, x5
    5658:      	ldr	w2, [x2]
    565c:      	sxtw	x2, w2
    5660:      	cmp	x2, x3
    5664:      	b.ne	0x5704 <_stogir.terminal.validate+0x31c>
    5668:      	uxtb	w16, w1
    566c:      	cmp	w16, wzr
    5670:      	b.eq	0x56d0 <_stogir.terminal.validate+0x2e8>
    5674:      	add	x16, sp, #0x10
    5678:      	ldr	w2, [x16, #0x8]
    567c:      	sxtw	x2, w2
    5680:      	cmp	x2, #0x0
    5684:      	b.eq	0x56d0 <_stogir.terminal.validate+0x2e8>
    5688:      	mov	x19, x8
    568c:      	b	0x55a0 <_stogir.terminal.validate+0x1b8>
    5690:      	movz	x1, #0x0, lsl #48
    5694:      	lsr	w2, w2, #0
    5698:      	lsr	w4, w4, #0
    569c:      	lsr	w1, w1, #0
    56a0:      	mov	w3, w1
    56a4:      	mov	w1, w4
    56a8:      	mov	x19, x8
    56ac:      	add	x8, sp, #0x20
    56b0:      	bl	0x56b0 <_stogir.terminal.validate+0x2c8>
		00000000000056b0:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    56b4:      	add	x16, sp, #0x20
    56b8:      	ldr	x0, [x16]
    56bc:      	add	x16, sp, #0x20
    56c0:      	ldr	x1, [x16, #0x8]
    56c4:      	add	x16, sp, #0x20
    56c8:      	ldr	x2, [x16, #0x10]
    56cc:      	b	0x55b8 <_stogir.terminal.validate+0x1d0>
    56d0:      	add	x16, sp, #0x10
    56d4:      	ldr	w2, [x16, #0x4]
    56d8:      	uxtb	w16, w1
    56dc:      	cmp	w16, wzr
    56e0:      	b.eq	0x5690 <_stogir.terminal.validate+0x2a8>
    56e4:      	add	x16, sp, #0x10
    56e8:      	ldr	w1, [x16, #0xc]
    56ec:      	sxtw	x1, w1
    56f0:      	b	0x5694 <_stogir.terminal.validate+0x2ac>
    56f4:      	brk	#0
    56f8:      	b	0x56f4 <_stogir.terminal.validate+0x30c>
    56fc:      	mov	x19, x8
    5700:      	b	0x55a0 <_stogir.terminal.validate+0x1b8>
    5704:      	mov	x19, x8
    5708:      	b	0x55a0 <_stogir.terminal.validate+0x1b8>

000000000000570c <_stogir.switch.operation?>:
    570c:      	sxtw	x0, w0
    5710:      	cmp	x0, #0x75
    5714:      	b.ne	0x5728 <_stogir.switch.operation?+0x1c>
    5718:      	mov	x0, #0x1                ; =1
    571c:      	b	0x5724 <_stogir.switch.operation?+0x18>
    5720:      	movz	x0, #0x0, lsl #48
    5724:      	ret
    5728:      	cmp	x0, #0x6d
    572c:      	b.lt	0x5720 <_stogir.switch.operation?+0x14>
    5730:      	cmp	x0, #0x6f
    5734:      	cset	w0, le
    5738:      	ubfx	x0, x0, #0, #8
    573c:      	b	0x5724 <_stogir.switch.operation?+0x18>

0000000000005740 <_stogir.switch.validate>:
    5740:      	sub	sp, sp, #0x70
    5744:      	str	x29, [sp]
    5748:      	str	x30, [sp, #0x8]
    574c:      	mov	x29, sp
    5750:      	str	x19, [sp, #0x60]
    5754:      	sxtw	x1, w1
    5758:      	lsl	x2, x1, #2
    575c:      	cmp	x1, #0x0
    5760:      	cset	w3, gt
    5764:      	movz	x16, #0x0, lsl #48
    5768:      	sub	x4, x16, x1
    576c:      	sub	x5, x4, #0x1
    5770:      	uxtb	w16, w3
    5774:      	cmp	w16, wzr
    5778:      	b.eq	0x57b8 <_stogir.switch.validate+0x78>
    577c:      	ldr	x4, [x0, #0x8]
    5780:      	cmp	x1, x4
    5784:      	b.ge	0x580c <_stogir.switch.validate+0xcc>
    5788:      	add	x4, x0, #0x78
    578c:      	ldr	x4, [x4, #0x8]
    5790:      	cmp	x1, x4
    5794:      	b.ge	0x5930 <_stogir.switch.validate+0x1f0>
    5798:      	ldr	x4, [x0, #0x78]
    579c:      	add	x4, x2, x4
    57a0:      	ldr	w4, [x4]
    57a4:      	sxtw	x4, w4
    57a8:      	cmp	x4, #0x0
    57ac:      	cset	w4, ge
    57b0:      	ubfx	x4, x4, #0, #8
    57b4:      	b	0x5934 <_stogir.switch.validate+0x1f4>
    57b8:      	cmp	x1, #0x0
    57bc:      	b.ge	0x5814 <_stogir.switch.validate+0xd4>
    57c0:      	add	x6, x0, #0x28
    57c4:      	add	x7, x0, #0x50
    57c8:      	ldr	x6, [x6, #0x8]
    57cc:      	ldr	x7, [x7, #0x8]
    57d0:      	cmp	x6, x7
    57d4:      	b.ne	0x5804 <_stogir.switch.validate+0xc4>
    57d8:      	cmp	x4, x6
    57dc:      	b.gt	0x596c <_stogir.switch.validate+0x22c>
    57e0:      	lsl	x4, x5, #2
    57e4:      	ldr	x6, [x0, #0x50]
    57e8:      	add	x4, x4, x6
    57ec:      	ldr	w4, [x4]
    57f0:      	sxtw	x4, w4
    57f4:      	cmp	x4, #0x0
    57f8:      	cset	w4, gt
    57fc:      	ubfx	x4, x4, #0, #8
    5800:      	b	0x5970 <_stogir.switch.validate+0x230>
    5804:      	movz	x4, #0x0, lsl #48
    5808:      	b	0x5818 <_stogir.switch.validate+0xd8>
    580c:      	movz	x4, #0x0, lsl #48
    5810:      	b	0x5818 <_stogir.switch.validate+0xd8>
    5814:      	movz	x4, #0x0, lsl #48
    5818:      	cmp	x4, #0x0
    581c:      	b.eq	0x5880 <_stogir.switch.validate+0x140>
    5820:      	uxtb	w16, w3
    5824:      	cmp	w16, wzr
    5828:      	b.eq	0x5850 <_stogir.switch.validate+0x110>
    582c:      	lsl	x3, x1, #4
    5830:      	ldr	x4, [x0]
    5834:      	add	x3, x3, x4
    5838:      	ldr	x4, [x3]
    583c:      	ldr	x3, [x3, #0x8]
    5840:      	fmov	d31, x3
    5844:      	mov	x3, x4
    5848:      	fmov	x4, d31
    584c:      	b	0x5870 <_stogir.switch.validate+0x130>
    5850:      	lsl	x3, x5, #4
    5854:      	ldr	x4, [x0, #0x28]
    5858:      	add	x3, x3, x4
    585c:      	ldr	x4, [x3]
    5860:      	ldr	x3, [x3, #0x8]
    5864:      	fmov	d31, x3
    5868:      	mov	x3, x4
    586c:      	fmov	x4, d31
    5870:      	mov	x5, x4
    5874:      	mov	x4, x3
    5878:      	mov	x3, #0x1                ; =1
    587c:      	b	0x588c <_stogir.switch.validate+0x14c>
    5880:      	movz	x3, #0x0, lsl #48
    5884:      	movz	x4, #0x0, lsl #48
    5888:      	movz	x5, #0x0, lsl #48
    588c:      	lsr	w3, w3, #0
    5890:      	lsr	x16, x3, #0
    5894:      	cmp	x16, #0x1
    5898:      	b.eq	0x58b4 <_stogir.switch.validate+0x174>
    589c:      	b.lo	0x58a4 <_stogir.switch.validate+0x164>
    58a0:      	b	0x58b8 <_stogir.switch.validate+0x178>
    58a4:      	cmp	x16, #0x0
    58a8:      	b.eq	0x58b0 <_stogir.switch.validate+0x170>
    58ac:      	b	0x58b8 <_stogir.switch.validate+0x178>
    58b0:      	b	0x58bc <_stogir.switch.validate+0x17c>
    58b4:      	b	0x58dc <_stogir.switch.validate+0x19c>
    58b8:      	b	0x5a70 <_stogir.switch.validate+0x330>
    58bc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		00000000000058bc:  ARM64_RELOC_PAGE21	l_stogir.384
    58c0:      	ldr	x16, [x16]
		00000000000058c0:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    58c4:      	orr	x0, x16, xzr
    58c8:      	mov	x19, x8
    58cc:      	mov	x1, x0
    58d0:      	mov	x0, #0x1                ; =1
    58d4:      	mov	x2, #0x1a               ; =26
    58d8:      	b	0x5910 <_stogir.switch.validate+0x1d0>
    58dc:      	add	x16, sp, #0x10
    58e0:      	str	x4, [x16]
    58e4:      	add	x16, sp, #0x10
    58e8:      	str	x5, [x16, #0x8]
    58ec:      	cmp	x1, #0x0
    58f0:      	b.gt	0x5938 <_stogir.switch.validate+0x1f8>
    58f4:      	mov	x19, x8
    58f8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		00000000000058f8:  ARM64_RELOC_PAGE21	l_stogir.385
    58fc:      	ldr	x16, [x16]
		00000000000058fc:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    5900:      	orr	x0, x16, xzr
    5904:      	mov	x1, x0
    5908:      	mov	x0, #0x1                ; =1
    590c:      	mov	x2, #0x20               ; =32
    5910:      	str	x0, [x19]
    5914:      	str	x1, [x19, #0x8]
    5918:      	str	x2, [x19, #0x10]
    591c:      	ldr	x19, [sp, #0x60]
    5920:      	ldr	x29, [sp]
    5924:      	ldr	x30, [sp, #0x8]
    5928:      	add	sp, sp, #0x70
    592c:      	ret
    5930:      	movz	x4, #0x0, lsl #48
    5934:      	b	0x5810 <_stogir.switch.validate+0xd0>
    5938:      	uxtb	w4, w4
    593c:      	orr	x1, x4, xzr
    5940:      	cmp	x1, #0x75
    5944:      	cset	w3, eq
    5948:      	uxtb	w16, w3
    594c:      	cmp	w16, wzr
    5950:      	b.ne	0x5974 <_stogir.switch.validate+0x234>
    5954:      	cmp	x1, #0x6d
    5958:      	b.lt	0x5a78 <_stogir.switch.validate+0x338>
    595c:      	cmp	x1, #0x6f
    5960:      	b.le	0x5974 <_stogir.switch.validate+0x234>
    5964:      	mov	x19, x8
    5968:      	b	0x58f8 <_stogir.switch.validate+0x1b8>
    596c:      	movz	x4, #0x0, lsl #48
    5970:      	b	0x5808 <_stogir.switch.validate+0xc8>
    5974:      	add	x16, sp, #0x10
    5978:      	ldr	w5, [x16]
    597c:      	ubfx	x5, x5, #8, #8
    5980:      	cmp	x5, #0x0
    5984:      	b.ne	0x5a80 <_stogir.switch.validate+0x340>
    5988:      	ldr	x5, [x0, #0x78]
    598c:      	add	x2, x2, x5
    5990:      	ldr	w2, [x2]
    5994:      	cmp	x1, #0x6d
    5998:      	b.eq	0x5a0c <_stogir.switch.validate+0x2cc>
    599c:      	cmp	x1, #0x6e
    59a0:      	b.eq	0x5a0c <_stogir.switch.validate+0x2cc>
    59a4:      	mov	x1, #0x2                ; =2
    59a8:      	b	0x5a10 <_stogir.switch.validate+0x2d0>
    59ac:      	lsr	w4, w4, #0
    59b0:      	add	x16, sp, #0x10
    59b4:      	ldr	w1, [x16, #0x4]
    59b8:      	add	x16, sp, #0x10
    59bc:      	ldr	w2, [x16, #0x8]
    59c0:      	lsr	w1, w1, #0
    59c4:      	add	x16, sp, #0x10
    59c8:      	ldr	w3, [x16, #0xc]
    59cc:      	lsr	w2, w2, #0
    59d0:      	lsr	w3, w3, #0
    59d4:      	add	x8, sp, #0x40
    59d8:      	fmov	s31, w1
    59dc:      	mov	w1, w4
    59e0:      	mov	w4, w3
    59e4:      	mov	w3, w2
    59e8:      	fmov	w2, s31
    59ec:      	bl	0x59ec <_stogir.switch.validate+0x2ac>
		00000000000059ec:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    59f0:      	add	x16, sp, #0x40
    59f4:      	ldr	x0, [x16]
    59f8:      	add	x16, sp, #0x40
    59fc:      	ldr	x1, [x16, #0x8]
    5a00:      	add	x16, sp, #0x40
    5a04:      	ldr	x2, [x16, #0x10]
    5a08:      	b	0x5910 <_stogir.switch.validate+0x1d0>
    5a0c:      	mov	x1, #0x3                ; =3
    5a10:      	sxtw	x2, w2
    5a14:      	lsr	w1, w1, #0
    5a18:      	sxtw	x1, w1
    5a1c:      	cmp	x2, x1
    5a20:      	b.ne	0x5a88 <_stogir.switch.validate+0x348>
    5a24:      	uxtb	w16, w3
    5a28:      	cmp	w16, wzr
    5a2c:      	b.eq	0x5a90 <_stogir.switch.validate+0x350>
    5a30:      	add	x16, sp, #0x10
    5a34:      	ldr	w1, [x16, #0x4]
    5a38:      	add	x16, sp, #0x10
    5a3c:      	ldr	w2, [x16, #0x8]
    5a40:      	lsr	w1, w1, #0
    5a44:      	lsr	w2, w2, #0
    5a48:      	mov	x19, x8
    5a4c:      	add	x8, sp, #0x20
    5a50:      	bl	0x5a50 <_stogir.switch.validate+0x310>
		0000000000005a50:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    5a54:      	add	x16, sp, #0x20
    5a58:      	ldr	x0, [x16]
    5a5c:      	add	x16, sp, #0x20
    5a60:      	ldr	x1, [x16, #0x8]
    5a64:      	add	x16, sp, #0x20
    5a68:      	ldr	x2, [x16, #0x10]
    5a6c:      	b	0x5a08 <_stogir.switch.validate+0x2c8>
    5a70:      	brk	#0
    5a74:      	b	0x5a70 <_stogir.switch.validate+0x330>
    5a78:      	mov	x19, x8
    5a7c:      	b	0x58f8 <_stogir.switch.validate+0x1b8>
    5a80:      	mov	x19, x8
    5a84:      	b	0x58f8 <_stogir.switch.validate+0x1b8>
    5a88:      	mov	x19, x8
    5a8c:      	b	0x58f8 <_stogir.switch.validate+0x1b8>
    5a90:      	mov	x19, x8
    5a94:      	b	0x59ac <_stogir.switch.validate+0x26c>

0000000000005a98 <_stogir.stack.operation?>:
    5a98:      	sxtw	x0, w0
    5a9c:      	cmp	x0, #0x42
    5aa0:      	b.ne	0x5abc <_stogir.stack.operation?+0x24>
    5aa4:      	mov	x0, #0x1                ; =1
    5aa8:      	b	0x5ab8 <_stogir.stack.operation?+0x20>
    5aac:      	cmp	x0, #0x54
    5ab0:      	cset	w0, eq
    5ab4:      	ubfx	x0, x0, #0, #8
    5ab8:      	ret
    5abc:      	cmp	x0, #0x51
    5ac0:      	b.ne	0x5acc <_stogir.stack.operation?+0x34>
    5ac4:      	mov	x0, #0x1                ; =1
    5ac8:      	b	0x5ab8 <_stogir.stack.operation?+0x20>
    5acc:      	cmp	x0, #0x52
    5ad0:      	b.ne	0x5adc <_stogir.stack.operation?+0x44>
    5ad4:      	mov	x0, #0x1                ; =1
    5ad8:      	b	0x5ab8 <_stogir.stack.operation?+0x20>
    5adc:      	cmp	x0, #0x53
    5ae0:      	b.ne	0x5aac <_stogir.stack.operation?+0x14>
    5ae4:      	mov	x0, #0x1                ; =1
    5ae8:      	b	0x5ab8 <_stogir.stack.operation?+0x20>

0000000000005aec <_stogir.stack.validate>:
    5aec:      	sub	sp, sp, #0x90
    5af0:      	str	x29, [sp]
    5af4:      	str	x30, [sp, #0x8]
    5af8:      	mov	x29, sp
    5afc:      	str	x19, [sp, #0x60]
    5b00:      	str	x20, [sp, #0x68]
    5b04:      	str	x21, [sp, #0x70]
    5b08:      	str	x22, [sp, #0x78]
    5b0c:      	str	x23, [sp, #0x80]
    5b10:      	sxtw	x1, w1
    5b14:      	lsl	x2, x1, #2
    5b18:      	cmp	x1, #0x0
    5b1c:      	cset	w3, gt
    5b20:      	movz	x16, #0x0, lsl #48
    5b24:      	sub	x4, x16, x1
    5b28:      	cmp	x1, #0x0
    5b2c:      	cset	w5, lt
    5b30:      	sub	x6, x4, #0x1
    5b34:      	lsl	x7, x6, #2
    5b38:      	uxtb	w16, w3
    5b3c:      	cmp	w16, wzr
    5b40:      	b.eq	0x5b80 <_stogir.stack.validate+0x94>
    5b44:      	ldr	x9, [x0, #0x8]
    5b48:      	cmp	x1, x9
    5b4c:      	b.ge	0x5c00 <_stogir.stack.validate+0x114>
    5b50:      	add	x9, x0, #0x78
    5b54:      	ldr	x9, [x9, #0x8]
    5b58:      	cmp	x1, x9
    5b5c:      	b.ge	0x5d6c <_stogir.stack.validate+0x280>
    5b60:      	ldr	x9, [x0, #0x78]
    5b64:      	add	x9, x2, x9
    5b68:      	ldr	w9, [x9]
    5b6c:      	sxtw	x9, w9
    5b70:      	cmp	x9, #0x0
    5b74:      	cset	w9, ge
    5b78:      	ubfx	x9, x9, #0, #8
    5b7c:      	b	0x5d70 <_stogir.stack.validate+0x284>
    5b80:      	uxtb	w16, w5
    5b84:      	cmp	w16, wzr
    5b88:      	b.eq	0x5c08 <_stogir.stack.validate+0x11c>
    5b8c:      	add	x9, x0, #0x28
    5b90:      	add	x10, x0, #0x50
    5b94:      	ldr	x9, [x9, #0x8]
    5b98:      	ldr	x10, [x10, #0x8]
    5b9c:      	cmp	x9, x10
    5ba0:      	b.ne	0x5bcc <_stogir.stack.validate+0xe0>
    5ba4:      	cmp	x4, x9
    5ba8:      	b.gt	0x5d74 <_stogir.stack.validate+0x288>
    5bac:      	ldr	x9, [x0, #0x50]
    5bb0:      	add	x9, x7, x9
    5bb4:      	ldr	w9, [x9]
    5bb8:      	sxtw	x9, w9
    5bbc:      	cmp	x9, #0x0
    5bc0:      	cset	w9, gt
    5bc4:      	ubfx	x9, x9, #0, #8
    5bc8:      	b	0x5d78 <_stogir.stack.validate+0x28c>
    5bcc:      	movz	x9, #0x0, lsl #48
    5bd0:      	b	0x5c0c <_stogir.stack.validate+0x120>
    5bd4:      	uxtb	w16, w9
    5bd8:      	cmp	w16, wzr
    5bdc:      	b.eq	0x5d9c <_stogir.stack.validate+0x2b0>
    5be0:      	mov	x22, x8
    5be4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005be4:  ARM64_RELOC_PAGE21	l_stogir.386
    5be8:      	ldr	x16, [x16]
		0000000000005be8:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    5bec:      	orr	x0, x16, xzr
    5bf0:      	mov	x1, x0
    5bf4:      	mov	x0, #0x1                ; =1
    5bf8:      	mov	x2, #0x19               ; =25
    5bfc:      	b	0x5ccc <_stogir.stack.validate+0x1e0>
    5c00:      	movz	x9, #0x0, lsl #48
    5c04:      	b	0x5c0c <_stogir.stack.validate+0x120>
    5c08:      	movz	x9, #0x0, lsl #48
    5c0c:      	lsl	x10, x1, #4
    5c10:      	lsl	x6, x6, #4
    5c14:      	cmp	x9, #0x0
    5c18:      	b.eq	0x5c74 <_stogir.stack.validate+0x188>
    5c1c:      	uxtb	w16, w3
    5c20:      	cmp	w16, wzr
    5c24:      	b.eq	0x5c48 <_stogir.stack.validate+0x15c>
    5c28:      	ldr	x9, [x0]
    5c2c:      	add	x9, x10, x9
    5c30:      	ldr	x11, [x9]
    5c34:      	ldr	x9, [x9, #0x8]
    5c38:      	fmov	d31, x9
    5c3c:      	mov	x9, x11
    5c40:      	fmov	x11, d31
    5c44:      	b	0x5c64 <_stogir.stack.validate+0x178>
    5c48:      	ldr	x9, [x0, #0x28]
    5c4c:      	add	x9, x6, x9
    5c50:      	ldr	x11, [x9]
    5c54:      	ldr	x9, [x9, #0x8]
    5c58:      	fmov	d31, x9
    5c5c:      	mov	x9, x11
    5c60:      	fmov	x11, d31
    5c64:      	mov	x12, x11
    5c68:      	mov	x11, x9
    5c6c:      	mov	x9, #0x1                ; =1
    5c70:      	b	0x5c80 <_stogir.stack.validate+0x194>
    5c74:      	movz	x9, #0x0, lsl #48
    5c78:      	movz	x11, #0x0, lsl #48
    5c7c:      	movz	x12, #0x0, lsl #48
    5c80:      	lsr	w9, w9, #0
    5c84:      	lsr	x16, x9, #0
    5c88:      	cmp	x16, #0x1
    5c8c:      	b.eq	0x5ca8 <_stogir.stack.validate+0x1bc>
    5c90:      	b.lo	0x5c98 <_stogir.stack.validate+0x1ac>
    5c94:      	b	0x5cac <_stogir.stack.validate+0x1c0>
    5c98:      	cmp	x16, #0x0
    5c9c:      	b.eq	0x5ca4 <_stogir.stack.validate+0x1b8>
    5ca0:      	b	0x5cac <_stogir.stack.validate+0x1c0>
    5ca4:      	b	0x5cb0 <_stogir.stack.validate+0x1c4>
    5ca8:      	b	0x5cfc <_stogir.stack.validate+0x210>
    5cac:      	b	0x60f4 <_stogir.stack.validate+0x608>
    5cb0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005cb0:  ARM64_RELOC_PAGE21	l_stogir.387
    5cb4:      	ldr	x16, [x16]
		0000000000005cb4:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    5cb8:      	orr	x0, x16, xzr
    5cbc:      	mov	x22, x8
    5cc0:      	mov	x1, x0
    5cc4:      	mov	x0, #0x1                ; =1
    5cc8:      	mov	x2, #0x19               ; =25
    5ccc:      	str	x0, [x22]
    5cd0:      	str	x1, [x22, #0x8]
    5cd4:      	str	x2, [x22, #0x10]
    5cd8:      	ldr	x19, [sp, #0x60]
    5cdc:      	ldr	x20, [sp, #0x68]
    5ce0:      	ldr	x21, [sp, #0x70]
    5ce4:      	ldr	x22, [sp, #0x78]
    5ce8:      	ldr	x23, [sp, #0x80]
    5cec:      	ldr	x29, [sp]
    5cf0:      	ldr	x30, [sp, #0x8]
    5cf4:      	add	sp, sp, #0x90
    5cf8:      	ret
    5cfc:      	cmp	x1, #0x0
    5d00:      	cset	w9, le
    5d04:      	uxtb	w19, w11
    5d08:      	add	x16, sp, #0x10
    5d0c:      	str	x11, [x16]
    5d10:      	orr	x11, x19, xzr
    5d14:      	add	x16, sp, #0x10
    5d18:      	str	x12, [x16, #0x8]
    5d1c:      	cmp	x11, #0x42
    5d20:      	b.ne	0x5bd4 <_stogir.stack.validate+0xe8>
    5d24:      	uxtb	w16, w3
    5d28:      	cmp	w16, wzr
    5d2c:      	b.eq	0x5de8 <_stogir.stack.validate+0x2fc>
    5d30:      	ldr	x4, [x0, #0x8]
    5d34:      	cmp	x1, x4
    5d38:      	b.ge	0x5e34 <_stogir.stack.validate+0x348>
    5d3c:      	add	x4, x0, #0x78
    5d40:      	ldr	x4, [x4, #0x8]
    5d44:      	cmp	x1, x4
    5d48:      	b.ge	0x5f28 <_stogir.stack.validate+0x43c>
    5d4c:      	ldr	x1, [x0, #0x78]
    5d50:      	add	x1, x2, x1
    5d54:      	ldr	w1, [x1]
    5d58:      	sxtw	x1, w1
    5d5c:      	cmp	x1, #0x0
    5d60:      	cset	w1, ge
    5d64:      	ubfx	x1, x1, #0, #8
    5d68:      	b	0x5f2c <_stogir.stack.validate+0x440>
    5d6c:      	movz	x9, #0x0, lsl #48
    5d70:      	b	0x5c04 <_stogir.stack.validate+0x118>
    5d74:      	movz	x9, #0x0, lsl #48
    5d78:      	b	0x5bd0 <_stogir.stack.validate+0xe4>
    5d7c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005d7c:  ARM64_RELOC_PAGE21	l_stogir.388
    5d80:      	ldr	x16, [x16]
		0000000000005d80:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    5d84:      	orr	x0, x16, xzr
    5d88:      	mov	x1, x0
    5d8c:      	mov	x0, #0x1                ; =1
    5d90:      	mov	x2, #0x1e               ; =30
    5d94:      	mov	x22, x8
    5d98:      	b	0x5bfc <_stogir.stack.validate+0x110>
    5d9c:      	cmp	x11, #0x51
    5da0:      	cset	w1, eq
    5da4:      	cmp	x11, #0x53
    5da8:      	cset	w20, eq
    5dac:      	cmp	x11, #0x54
    5db0:      	cset	w21, eq
    5db4:      	uxtb	w16, w1
    5db8:      	cmp	w16, wzr
    5dbc:      	b.ne	0x5f30 <_stogir.stack.validate+0x444>
    5dc0:      	cmp	x11, #0x52
    5dc4:      	b.eq	0x5f30 <_stogir.stack.validate+0x444>
    5dc8:      	uxtb	w16, w20
    5dcc:      	cmp	w16, wzr
    5dd0:      	b.ne	0x5f30 <_stogir.stack.validate+0x444>
    5dd4:      	uxtb	w16, w21
    5dd8:      	cmp	w16, wzr
    5ddc:      	b.ne	0x5f30 <_stogir.stack.validate+0x444>
    5de0:      	mov	x22, x8
    5de4:      	b	0x5be4 <_stogir.stack.validate+0xf8>
    5de8:      	uxtb	w16, w5
    5dec:      	cmp	w16, wzr
    5df0:      	b.eq	0x5e3c <_stogir.stack.validate+0x350>
    5df4:      	add	x1, x0, #0x28
    5df8:      	add	x5, x0, #0x50
    5dfc:      	ldr	x1, [x1, #0x8]
    5e00:      	ldr	x5, [x5, #0x8]
    5e04:      	cmp	x1, x5
    5e08:      	b.ne	0x5f20 <_stogir.stack.validate+0x434>
    5e0c:      	cmp	x4, x1
    5e10:      	b.gt	0x608c <_stogir.stack.validate+0x5a0>
    5e14:      	ldr	x1, [x0, #0x50]
    5e18:      	add	x1, x7, x1
    5e1c:      	ldr	w1, [x1]
    5e20:      	sxtw	x1, w1
    5e24:      	cmp	x1, #0x0
    5e28:      	cset	w1, gt
    5e2c:      	ubfx	x1, x1, #0, #8
    5e30:      	b	0x6090 <_stogir.stack.validate+0x5a4>
    5e34:      	movz	x1, #0x0, lsl #48
    5e38:      	b	0x5e40 <_stogir.stack.validate+0x354>
    5e3c:      	movz	x1, #0x0, lsl #48
    5e40:      	cmp	x1, #0x0
    5e44:      	b.eq	0x5e7c <_stogir.stack.validate+0x390>
    5e48:      	uxtb	w16, w3
    5e4c:      	cmp	w16, wzr
    5e50:      	b.eq	0x5e64 <_stogir.stack.validate+0x378>
    5e54:      	ldr	x1, [x0]
    5e58:      	add	x1, x10, x1
    5e5c:      	ldr	x1, [x1]
    5e60:      	b	0x5e70 <_stogir.stack.validate+0x384>
    5e64:      	ldr	x1, [x0, #0x28]
    5e68:      	add	x1, x6, x1
    5e6c:      	ldr	x1, [x1]
    5e70:      	mov	x3, x1
    5e74:      	mov	x1, #0x1                ; =1
    5e78:      	b	0x5e84 <_stogir.stack.validate+0x398>
    5e7c:      	movz	x1, #0x0, lsl #48
    5e80:      	movz	x3, #0x0, lsl #48
    5e84:      	lsr	w1, w1, #0
    5e88:      	lsr	x16, x1, #0
    5e8c:      	cmp	x16, #0x1
    5e90:      	b.eq	0x5eac <_stogir.stack.validate+0x3c0>
    5e94:      	b.lo	0x5e9c <_stogir.stack.validate+0x3b0>
    5e98:      	b	0x5eb0 <_stogir.stack.validate+0x3c4>
    5e9c:      	cmp	x16, #0x0
    5ea0:      	b.eq	0x5ea8 <_stogir.stack.validate+0x3bc>
    5ea4:      	b	0x5eb0 <_stogir.stack.validate+0x3c4>
    5ea8:      	b	0x5eb4 <_stogir.stack.validate+0x3c8>
    5eac:      	b	0x5ed0 <_stogir.stack.validate+0x3e4>
    5eb0:      	b	0x60fc <_stogir.stack.validate+0x610>
    5eb4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x53c>
		0000000000005eb4:  ARM64_RELOC_PAGE21	l_stogir.389
    5eb8:      	ldr	x16, [x16]
		0000000000005eb8:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    5ebc:      	orr	x0, x16, xzr
    5ec0:      	mov	x1, x0
    5ec4:      	mov	x0, #0x1                ; =1
    5ec8:      	mov	x2, #0x21               ; =33
    5ecc:      	b	0x5d94 <_stogir.stack.validate+0x2a8>
    5ed0:      	uxtb	w16, w9
    5ed4:      	cmp	w16, wzr
    5ed8:      	b.ne	0x5d7c <_stogir.stack.validate+0x290>
    5edc:      	uxtb	w1, w3
    5ee0:      	cmp	x1, #0x42
    5ee4:      	b.ne	0x5d7c <_stogir.stack.validate+0x290>
    5ee8:      	lsr	w3, w3, #0
    5eec:      	ubfx	x1, x3, #8, #8
    5ef0:      	cmp	x1, #0x6
    5ef4:      	b.ne	0x5d7c <_stogir.stack.validate+0x290>
    5ef8:      	ldr	x0, [x0, #0x78]
    5efc:      	add	x0, x2, x0
    5f00:      	ldr	w0, [x0]
    5f04:      	sxtw	x0, w0
    5f08:      	cmp	x0, #0x0
    5f0c:      	b.ne	0x5d7c <_stogir.stack.validate+0x290>
    5f10:      	movz	x0, #0x0, lsl #48
    5f14:      	mov	x1, #0x8                ; =8
    5f18:      	movz	x2, #0x0, lsl #48
    5f1c:      	b	0x5d94 <_stogir.stack.validate+0x2a8>
    5f20:      	movz	x1, #0x0, lsl #48
    5f24:      	b	0x5e40 <_stogir.stack.validate+0x354>
    5f28:      	movz	x1, #0x0, lsl #48
    5f2c:      	b	0x5e38 <_stogir.stack.validate+0x34c>
    5f30:      	ldr	x3, [x0, #0x78]
    5f34:      	add	x2, x2, x3
    5f38:      	ldr	w2, [x2]
    5f3c:      	uxtb	w16, w1
    5f40:      	cmp	w16, wzr
    5f44:      	b.eq	0x5fb0 <_stogir.stack.validate+0x4c4>
    5f48:      	mov	x1, #0x3                ; =3
    5f4c:      	b	0x5fc4 <_stogir.stack.validate+0x4d8>
    5f50:      	add	x16, sp, #0x10
    5f54:      	ldr	w0, [x16]
    5f58:      	add	x16, sp, #0x10
    5f5c:      	ldr	w1, [x16, #0x4]
    5f60:      	add	x16, sp, #0x10
    5f64:      	ldr	w2, [x16, #0x8]
    5f68:      	lsr	w1, w1, #0
    5f6c:      	ubfx	x0, x0, #8, #8
    5f70:      	lsr	w2, w2, #0
    5f74:      	lsr	w0, w0, #0
    5f78:      	add	x8, sp, #0x20
    5f7c:      	mov	w3, w1
    5f80:      	mov	w1, w19
    5f84:      	mov	w4, w2
    5f88:      	mov	w2, w0
    5f8c:      	mov	x0, x23
    5f90:      	bl	0x5f90 <_stogir.stack.validate+0x4a4>
		0000000000005f90:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    5f94:      	add	x16, sp, #0x20
    5f98:      	ldr	x0, [x16]
    5f9c:      	add	x16, sp, #0x20
    5fa0:      	ldr	x1, [x16, #0x8]
    5fa4:      	add	x16, sp, #0x20
    5fa8:      	ldr	x2, [x16, #0x10]
    5fac:      	b	0x5bfc <_stogir.stack.validate+0x110>
    5fb0:      	uxtb	w16, w20
    5fb4:      	cmp	w16, wzr
    5fb8:      	mov	x16, #0x1               ; =1
    5fbc:      	mov	x17, #0x2               ; =2
    5fc0:      	csel	x1, x16, x17, ne
    5fc4:      	sxtw	x2, w2
    5fc8:      	lsr	w1, w1, #0
    5fcc:      	sxtw	x1, w1
    5fd0:      	cmp	x2, x1
    5fd4:      	b.ne	0x6104 <_stogir.stack.validate+0x618>
    5fd8:      	add	x16, sp, #0x10
    5fdc:      	ldr	w1, [x16]
    5fe0:      	orr	x2, x1, xzr
    5fe4:      	ubfx	x2, x2, #16, #16
    5fe8:      	and	x2, x2, #0x8000
    5fec:      	uxth	w2, w2
    5ff0:      	cmp	x2, #0x0
    5ff4:      	b.ne	0x6094 <_stogir.stack.validate+0x5a8>
    5ff8:      	mov	x22, x8
    5ffc:      	mov	x23, x0
    6000:      	lsr	w19, w19, #0
    6004:      	uxtb	w16, w20
    6008:      	cmp	w16, wzr
    600c:      	b.ne	0x5f50 <_stogir.stack.validate+0x464>
    6010:      	uxtb	w16, w21
    6014:      	cmp	w16, wzr
    6018:      	b.ne	0x5f50 <_stogir.stack.validate+0x464>
    601c:      	add	x16, sp, #0x10
    6020:      	ldr	w0, [x16]
    6024:      	add	x16, sp, #0x10
    6028:      	ldr	w1, [x16, #0x4]
    602c:      	add	x16, sp, #0x10
    6030:      	ldr	w2, [x16, #0x8]
    6034:      	lsr	w1, w1, #0
    6038:      	ubfx	x0, x0, #8, #8
    603c:      	add	x16, sp, #0x10
    6040:      	ldr	w3, [x16, #0xc]
    6044:      	lsr	w2, w2, #0
    6048:      	lsr	w3, w3, #0
    604c:      	lsr	w0, w0, #0
    6050:      	add	x8, sp, #0x40
    6054:      	mov	w4, w2
    6058:      	mov	w2, w0
    605c:      	mov	x0, x23
    6060:      	mov	w5, w3
    6064:      	mov	w3, w1
    6068:      	mov	w1, w19
    606c:      	bl	0x606c <_stogir.stack.validate+0x580>
		000000000000606c:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    6070:      	add	x16, sp, #0x40
    6074:      	ldr	x0, [x16]
    6078:      	add	x16, sp, #0x40
    607c:      	ldr	x1, [x16, #0x8]
    6080:      	add	x16, sp, #0x40
    6084:      	ldr	x2, [x16, #0x10]
    6088:      	b	0x5fac <_stogir.stack.validate+0x4c0>
    608c:      	movz	x1, #0x0, lsl #48
    6090:      	b	0x5f24 <_stogir.stack.validate+0x438>
    6094:      	uxtb	w2, w1
    6098:      	cmp	x2, #0x51
    609c:      	b.ne	0x610c <_stogir.stack.validate+0x620>
    60a0:      	ubfx	x1, x1, #16, #16
    60a4:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    60a8:      	b.ne	0x6114 <_stogir.stack.validate+0x628>
    60ac:      	add	x16, sp, #0x10
    60b0:      	ldr	w1, [x16, #0x4]
    60b4:      	add	x16, sp, #0x10
    60b8:      	ldr	w2, [x16, #0x8]
    60bc:      	lsr	w1, w1, #0
    60c0:      	lsr	w2, w2, #0
    60c4:      	mov	x22, x8
    60c8:      	mov	x23, x0
    60cc:      	bl	0x60cc <_stogir.stack.validate+0x5e0>
		00000000000060cc:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    60d0:      	cmp	x0, #0x0
    60d4:      	b.ne	0x6000 <_stogir.stack.validate+0x514>
    60d8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		00000000000060d8:  ARM64_RELOC_PAGE21	l_stogir.390
    60dc:      	ldr	x16, [x16]
		00000000000060dc:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    60e0:      	orr	x0, x16, xzr
    60e4:      	mov	x1, x0
    60e8:      	mov	x0, #0x1                ; =1
    60ec:      	mov	x2, #0x26               ; =38
    60f0:      	b	0x5fac <_stogir.stack.validate+0x4c0>
    60f4:      	brk	#0
    60f8:      	b	0x60f4 <_stogir.stack.validate+0x608>
    60fc:      	brk	#0
    6100:      	b	0x60fc <_stogir.stack.validate+0x610>
    6104:      	mov	x22, x8
    6108:      	b	0x5be4 <_stogir.stack.validate+0xf8>
    610c:      	mov	x22, x8
    6110:      	b	0x60d8 <_stogir.stack.validate+0x5ec>
    6114:      	mov	x22, x8
    6118:      	b	0x60d8 <_stogir.stack.validate+0x5ec>

000000000000611c <_stogir.locals.operation?>:
    611c:      	sxtw	x0, w0
    6120:      	cmp	x0, #0x41
    6124:      	b.ne	0x6138 <_stogir.locals.operation?+0x1c>
    6128:      	mov	x0, #0x1                ; =1
    612c:      	b	0x6134 <_stogir.locals.operation?+0x18>
    6130:      	movz	x0, #0x0, lsl #48
    6134:      	ret
    6138:      	cmp	x0, #0x48
    613c:      	b.ne	0x6148 <_stogir.locals.operation?+0x2c>
    6140:      	mov	x0, #0x1                ; =1
    6144:      	b	0x6134 <_stogir.locals.operation?+0x18>
    6148:      	cmp	x0, #0x55
    614c:      	b.lt	0x6130 <_stogir.locals.operation?+0x14>
    6150:      	cmp	x0, #0x58
    6154:      	cset	w0, le
    6158:      	ubfx	x0, x0, #0, #8
    615c:      	b	0x6134 <_stogir.locals.operation?+0x18>

0000000000006160 <_stogir.locals.validate>:
    6160:      	sub	sp, sp, #0xb0
    6164:      	str	x29, [sp]
    6168:      	str	x30, [sp, #0x8]
    616c:      	mov	x29, sp
    6170:      	str	x19, [sp, #0x70]
    6174:      	str	x20, [sp, #0x78]
    6178:      	str	x21, [sp, #0x80]
    617c:      	str	x22, [sp, #0x88]
    6180:      	str	x23, [sp, #0x90]
    6184:      	str	x24, [sp, #0x98]
    6188:      	str	x25, [sp, #0xa0]
    618c:      	sxtw	x1, w1
    6190:      	lsl	x3, x1, #2
    6194:      	cmp	x1, #0x0
    6198:      	cset	w4, gt
    619c:      	movz	x16, #0x0, lsl #48
    61a0:      	sub	x5, x16, x1
    61a4:      	sub	x6, x5, #0x1
    61a8:      	uxtb	w16, w4
    61ac:      	cmp	w16, wzr
    61b0:      	b.eq	0x61f0 <_stogir.locals.validate+0x90>
    61b4:      	ldr	x5, [x0, #0x8]
    61b8:      	cmp	x1, x5
    61bc:      	b.ge	0x6290 <_stogir.locals.validate+0x130>
    61c0:      	add	x5, x0, #0x78
    61c4:      	ldr	x5, [x5, #0x8]
    61c8:      	cmp	x1, x5
    61cc:      	b.ge	0x63b8 <_stogir.locals.validate+0x258>
    61d0:      	ldr	x5, [x0, #0x78]
    61d4:      	add	x5, x3, x5
    61d8:      	ldr	w5, [x5]
    61dc:      	sxtw	x5, w5
    61e0:      	cmp	x5, #0x0
    61e4:      	cset	w5, ge
    61e8:      	ubfx	x5, x5, #0, #8
    61ec:      	b	0x63bc <_stogir.locals.validate+0x25c>
    61f0:      	cmp	x1, #0x0
    61f4:      	b.ge	0x6298 <_stogir.locals.validate+0x138>
    61f8:      	add	x7, x0, #0x28
    61fc:      	add	x9, x0, #0x50
    6200:      	ldr	x7, [x7, #0x8]
    6204:      	ldr	x9, [x9, #0x8]
    6208:      	cmp	x7, x9
    620c:      	b.ne	0x623c <_stogir.locals.validate+0xdc>
    6210:      	cmp	x5, x7
    6214:      	b.gt	0x6440 <_stogir.locals.validate+0x2e0>
    6218:      	lsl	x5, x6, #2
    621c:      	ldr	x7, [x0, #0x50]
    6220:      	add	x5, x5, x7
    6224:      	ldr	w5, [x5]
    6228:      	sxtw	x5, w5
    622c:      	cmp	x5, #0x0
    6230:      	cset	w5, gt
    6234:      	ubfx	x5, x5, #0, #8
    6238:      	b	0x6444 <_stogir.locals.validate+0x2e4>
    623c:      	movz	x5, #0x0, lsl #48
    6240:      	b	0x629c <_stogir.locals.validate+0x13c>
    6244:      	cmp	x5, #0x0
    6248:      	cset	w5, ne
    624c:      	uxtb	w16, w5
    6250:      	cmp	w16, wzr
    6254:      	mov	x16, #0x2               ; =2
    6258:      	mov	x17, #0x3               ; =3
    625c:      	csel	x5, x16, x17, ne
    6260:      	lsr	w5, w5, #0
    6264:      	sxtw	x5, w5
    6268:      	cmp	x1, #0x0
    626c:      	b.gt	0x63c0 <_stogir.locals.validate+0x260>
    6270:      	mov	x23, x8
    6274:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006274:  ARM64_RELOC_PAGE21	l_stogir.391
    6278:      	ldr	x16, [x16]
		0000000000006278:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    627c:      	orr	x0, x16, xzr
    6280:      	mov	x1, x0
    6284:      	mov	x0, #0x1                ; =1
    6288:      	mov	x2, #0x17               ; =23
    628c:      	b	0x635c <_stogir.locals.validate+0x1fc>
    6290:      	movz	x5, #0x0, lsl #48
    6294:      	b	0x629c <_stogir.locals.validate+0x13c>
    6298:      	movz	x5, #0x0, lsl #48
    629c:      	cmp	x5, #0x0
    62a0:      	b.eq	0x6304 <_stogir.locals.validate+0x1a4>
    62a4:      	uxtb	w16, w4
    62a8:      	cmp	w16, wzr
    62ac:      	b.eq	0x62d4 <_stogir.locals.validate+0x174>
    62b0:      	lsl	x4, x1, #4
    62b4:      	ldr	x5, [x0]
    62b8:      	add	x4, x4, x5
    62bc:      	ldr	x5, [x4]
    62c0:      	ldr	x4, [x4, #0x8]
    62c4:      	fmov	d31, x4
    62c8:      	mov	x4, x5
    62cc:      	fmov	x5, d31
    62d0:      	b	0x62f4 <_stogir.locals.validate+0x194>
    62d4:      	lsl	x4, x6, #4
    62d8:      	ldr	x5, [x0, #0x28]
    62dc:      	add	x4, x4, x5
    62e0:      	ldr	x5, [x4]
    62e4:      	ldr	x4, [x4, #0x8]
    62e8:      	fmov	d31, x4
    62ec:      	mov	x4, x5
    62f0:      	fmov	x5, d31
    62f4:      	mov	x6, x5
    62f8:      	mov	x5, x4
    62fc:      	mov	x4, #0x1                ; =1
    6300:      	b	0x6310 <_stogir.locals.validate+0x1b0>
    6304:      	movz	x4, #0x0, lsl #48
    6308:      	movz	x5, #0x0, lsl #48
    630c:      	movz	x6, #0x0, lsl #48
    6310:      	lsr	w4, w4, #0
    6314:      	lsr	x16, x4, #0
    6318:      	cmp	x16, #0x1
    631c:      	b.eq	0x6338 <_stogir.locals.validate+0x1d8>
    6320:      	b.lo	0x6328 <_stogir.locals.validate+0x1c8>
    6324:      	b	0x633c <_stogir.locals.validate+0x1dc>
    6328:      	cmp	x16, #0x0
    632c:      	b.eq	0x6334 <_stogir.locals.validate+0x1d4>
    6330:      	b	0x633c <_stogir.locals.validate+0x1dc>
    6334:      	b	0x6340 <_stogir.locals.validate+0x1e0>
    6338:      	b	0x6394 <_stogir.locals.validate+0x234>
    633c:      	b	0x6584 <_stogir.locals.validate+0x424>
    6340:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006340:  ARM64_RELOC_PAGE21	l_stogir.392
    6344:      	ldr	x16, [x16]
		0000000000006344:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    6348:      	orr	x0, x16, xzr
    634c:      	mov	x23, x8
    6350:      	mov	x1, x0
    6354:      	mov	x0, #0x1                ; =1
    6358:      	mov	x2, #0x17               ; =23
    635c:      	str	x0, [x23]
    6360:      	str	x1, [x23, #0x8]
    6364:      	str	x2, [x23, #0x10]
    6368:      	ldr	x19, [sp, #0x70]
    636c:      	ldr	x20, [sp, #0x78]
    6370:      	ldr	x21, [sp, #0x80]
    6374:      	ldr	x22, [sp, #0x88]
    6378:      	ldr	x23, [sp, #0x90]
    637c:      	ldr	x24, [sp, #0x98]
    6380:      	ldr	x25, [sp, #0xa0]
    6384:      	ldr	x29, [sp]
    6388:      	ldr	x30, [sp, #0x8]
    638c:      	add	sp, sp, #0xb0
    6390:      	ret
    6394:      	uxtb	w4, w5
    6398:      	add	x16, sp, #0x10
    639c:      	str	x5, [x16]
    63a0:      	add	x16, sp, #0x10
    63a4:      	str	x6, [x16, #0x8]
    63a8:      	cmp	x4, #0x55
    63ac:      	b.ne	0x6424 <_stogir.locals.validate+0x2c4>
    63b0:      	mov	x5, #0x1                ; =1
    63b4:      	b	0x6430 <_stogir.locals.validate+0x2d0>
    63b8:      	movz	x5, #0x0, lsl #48
    63bc:      	b	0x6294 <_stogir.locals.validate+0x134>
    63c0:      	cmp	x4, #0x48
    63c4:      	cset	w21, eq
    63c8:      	uxtb	w16, w20
    63cc:      	cmp	w16, wzr
    63d0:      	b.ne	0x6448 <_stogir.locals.validate+0x2e8>
    63d4:      	uxtb	w16, w21
    63d8:      	cmp	w16, wzr
    63dc:      	b.ne	0x6448 <_stogir.locals.validate+0x2e8>
    63e0:      	cmp	x4, #0x55
    63e4:      	b.lt	0x691c <_stogir.locals.validate+0x7bc>
    63e8:      	cmp	x4, #0x58
    63ec:      	b.le	0x6448 <_stogir.locals.validate+0x2e8>
    63f0:      	mov	x23, x8
    63f4:      	b	0x6274 <_stogir.locals.validate+0x114>
    63f8:      	cmp	x4, #0x58
    63fc:      	cset	w6, eq
    6400:      	ubfx	x6, x6, #0, #8
    6404:      	mov	x19, x6
    6408:      	cmp	x4, #0x41
    640c:      	cset	w20, eq
    6410:      	uxtb	w16, w20
    6414:      	cmp	w16, wzr
    6418:      	b.eq	0x6244 <_stogir.locals.validate+0xe4>
    641c:      	mov	x5, #0x1                ; =1
    6420:      	b	0x6268 <_stogir.locals.validate+0x108>
    6424:      	cmp	x4, #0x56
    6428:      	cset	w5, eq
    642c:      	ubfx	x5, x5, #0, #8
    6430:      	cmp	x4, #0x57
    6434:      	b.ne	0x63f8 <_stogir.locals.validate+0x298>
    6438:      	mov	x19, #0x1               ; =1
    643c:      	b	0x6408 <_stogir.locals.validate+0x2a8>
    6440:      	movz	x5, #0x0, lsl #48
    6444:      	b	0x6240 <_stogir.locals.validate+0xe0>
    6448:      	lsr	w5, w5, #0
    644c:      	sxtw	x5, w5
    6450:      	ldr	x4, [x0, #0x78]
    6454:      	add	x3, x3, x4
    6458:      	ldr	w3, [x3]
    645c:      	sxtw	x3, w3
    6460:      	cmp	x3, x5
    6464:      	b.ne	0x6924 <_stogir.locals.validate+0x7c4>
    6468:      	uxtb	w16, w20
    646c:      	cmp	w16, wzr
    6470:      	b.ne	0x6490 <_stogir.locals.validate+0x330>
    6474:      	uxtb	w16, w21
    6478:      	cmp	w16, wzr
    647c:      	b.ne	0x6490 <_stogir.locals.validate+0x330>
    6480:      	add	x16, sp, #0x10
    6484:      	ldr	w1, [x16, #0x8]
    6488:      	sxtw	x1, w1
    648c:      	b	0x64a8 <_stogir.locals.validate+0x348>
    6490:      	uxtb	w16, w21
    6494:      	cmp	w16, wzr
    6498:      	b.ne	0x64a8 <_stogir.locals.validate+0x348>
    649c:      	add	x16, sp, #0x10
    64a0:      	ldr	w1, [x16, #0x4]
    64a4:      	sxtw	x1, w1
    64a8:      	add	x16, sp, #0x20
    64ac:      	orr	x22, x16, xzr
    64b0:      	lsr	w2, w2, #0
    64b4:      	lsr	w1, w1, #0
    64b8:      	mov	x23, x8
    64bc:      	add	x8, sp, #0x20
    64c0:      	mov	x24, x0
    64c4:      	mov	w25, w2
    64c8:      	bl	0x64c8 <_stogir.locals.validate+0x368>
		00000000000064c8:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    64cc:      	add	x16, sp, #0x20
    64d0:      	ldr	w0, [x16]
    64d4:      	lsr	x16, x0, #0
    64d8:      	cmp	x16, #0x1
    64dc:      	b.eq	0x64f8 <_stogir.locals.validate+0x398>
    64e0:      	b.lo	0x64e8 <_stogir.locals.validate+0x388>
    64e4:      	b	0x64fc <_stogir.locals.validate+0x39c>
    64e8:      	cmp	x16, #0x0
    64ec:      	b.eq	0x64f4 <_stogir.locals.validate+0x394>
    64f0:      	b	0x64fc <_stogir.locals.validate+0x39c>
    64f4:      	b	0x651c <_stogir.locals.validate+0x3bc>
    64f8:      	b	0x6500 <_stogir.locals.validate+0x3a0>
    64fc:      	b	0x677c <_stogir.locals.validate+0x61c>
    6500:      	add	x0, x22, #0x8
    6504:      	add	x16, sp, #0x20
    6508:      	ldr	x1, [x16, #0x8]
    650c:      	ldr	x0, [x0, #0x8]
    6510:      	mov	x2, x0
    6514:      	mov	x0, #0x1                ; =1
    6518:      	b	0x628c <_stogir.locals.validate+0x12c>
    651c:      	add	x16, sp, #0x20
    6520:      	ldr	x22, [x16, #0x8]
    6524:      	uxtb	w16, w21
    6528:      	cmp	w16, wzr
    652c:      	b.eq	0x654c <_stogir.locals.validate+0x3ec>
    6530:      	lsr	w22, w22, #0
    6534:      	sxtw	x22, w22
    6538:      	and	x0, x22, #0xffffffff
    653c:      	mov	x1, x0
    6540:      	movz	x0, #0x0, lsl #48
    6544:      	movz	x2, #0x0, lsl #48
    6548:      	b	0x6518 <_stogir.locals.validate+0x3b8>
    654c:      	uxtb	w16, w20
    6550:      	cmp	w16, wzr
    6554:      	b.eq	0x65a8 <_stogir.locals.validate+0x448>
    6558:      	add	x16, sp, #0x10
    655c:      	ldr	w0, [x16]
    6560:      	ubfx	x0, x0, #8, #8
    6564:      	cmp	x0, #0x6
    6568:      	b.ne	0x658c <_stogir.locals.validate+0x42c>
    656c:      	sxtw	x25, w25
    6570:      	and	x0, x25, #0xffffffff
    6574:      	mov	x1, x0
    6578:      	movz	x0, #0x0, lsl #48
    657c:      	movz	x2, #0x0, lsl #48
    6580:      	b	0x65a4 <_stogir.locals.validate+0x444>
    6584:      	brk	#0
    6588:      	b	0x6584 <_stogir.locals.validate+0x424>
    658c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		000000000000658c:  ARM64_RELOC_PAGE21	l_stogir.393
    6590:      	ldr	x16, [x16]
		0000000000006590:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    6594:      	orr	x0, x16, xzr
    6598:      	mov	x1, x0
    659c:      	mov	x0, #0x1                ; =1
    65a0:      	mov	x2, #0x21               ; =33
    65a4:      	b	0x6548 <_stogir.locals.validate+0x3e8>
    65a8:      	add	x16, sp, #0x10
    65ac:      	ldr	w0, [x16, #0x4]
    65b0:      	sxtw	x0, w0
    65b4:      	cmp	x0, #0x0
    65b8:      	cset	w1, gt
    65bc:      	movz	x16, #0x0, lsl #48
    65c0:      	sub	x2, x16, x0
    65c4:      	sub	x3, x2, #0x1
    65c8:      	uxtb	w16, w1
    65cc:      	cmp	w16, wzr
    65d0:      	b.eq	0x66b8 <_stogir.locals.validate+0x558>
    65d4:      	ldr	x2, [x24, #0x8]
    65d8:      	cmp	x0, x2
    65dc:      	b.ge	0x66b0 <_stogir.locals.validate+0x550>
    65e0:      	add	x2, x24, #0x78
    65e4:      	ldr	x2, [x2, #0x8]
    65e8:      	cmp	x0, x2
    65ec:      	b.ge	0x676c <_stogir.locals.validate+0x60c>
    65f0:      	lsl	x2, x0, #2
    65f4:      	ldr	x4, [x24, #0x78]
    65f8:      	add	x2, x2, x4
    65fc:      	ldr	w2, [x2]
    6600:      	sxtw	x2, w2
    6604:      	cmp	x2, #0x0
    6608:      	cset	w2, ge
    660c:      	ubfx	x2, x2, #0, #8
    6610:      	b	0x6770 <_stogir.locals.validate+0x610>
    6614:      	movz	x0, #0x0, lsl #48
    6618:      	movz	x1, #0x0, lsl #48
    661c:      	lsr	w0, w0, #0
    6620:      	lsr	x16, x0, #0
    6624:      	cmp	x16, #0x1
    6628:      	b.eq	0x6644 <_stogir.locals.validate+0x4e4>
    662c:      	b.lo	0x6634 <_stogir.locals.validate+0x4d4>
    6630:      	b	0x6648 <_stogir.locals.validate+0x4e8>
    6634:      	cmp	x16, #0x0
    6638:      	b.eq	0x6640 <_stogir.locals.validate+0x4e0>
    663c:      	b	0x6648 <_stogir.locals.validate+0x4e8>
    6640:      	b	0x664c <_stogir.locals.validate+0x4ec>
    6644:      	b	0x6704 <_stogir.locals.validate+0x5a4>
    6648:      	b	0x68ec <_stogir.locals.validate+0x78c>
    664c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		000000000000664c:  ARM64_RELOC_PAGE21	l_stogir.394
    6650:      	ldr	x16, [x16]
		0000000000006650:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    6654:      	orr	x0, x16, xzr
    6658:      	mov	x1, x0
    665c:      	mov	x0, #0x1                ; =1
    6660:      	mov	x2, #0x1c               ; =28
    6664:      	b	0x65a4 <_stogir.locals.validate+0x444>
    6668:      	lsl	x0, x3, #4
    666c:      	ldr	x1, [x24, #0x28]
    6670:      	add	x0, x0, x1
    6674:      	ldr	x0, [x0]
    6678:      	mov	x1, x0
    667c:      	mov	x0, #0x1                ; =1
    6680:      	b	0x661c <_stogir.locals.validate+0x4bc>
    6684:      	movz	x2, #0x0, lsl #48
    6688:      	cmp	x2, #0x0
    668c:      	b.eq	0x6614 <_stogir.locals.validate+0x4b4>
    6690:      	uxtb	w16, w1
    6694:      	cmp	w16, wzr
    6698:      	b.eq	0x6668 <_stogir.locals.validate+0x508>
    669c:      	lsl	x0, x0, #4
    66a0:      	ldr	x1, [x24]
    66a4:      	add	x0, x0, x1
    66a8:      	ldr	x0, [x0]
    66ac:      	b	0x6678 <_stogir.locals.validate+0x518>
    66b0:      	movz	x2, #0x0, lsl #48
    66b4:      	b	0x6688 <_stogir.locals.validate+0x528>
    66b8:      	cmp	x0, #0x0
    66bc:      	b.ge	0x6684 <_stogir.locals.validate+0x524>
    66c0:      	add	x4, x24, #0x28
    66c4:      	add	x5, x24, #0x50
    66c8:      	ldr	x4, [x4, #0x8]
    66cc:      	ldr	x5, [x5, #0x8]
    66d0:      	cmp	x4, x5
    66d4:      	b.ne	0x6764 <_stogir.locals.validate+0x604>
    66d8:      	cmp	x2, x4
    66dc:      	b.gt	0x6774 <_stogir.locals.validate+0x614>
    66e0:      	lsl	x2, x3, #2
    66e4:      	ldr	x4, [x24, #0x50]
    66e8:      	add	x2, x2, x4
    66ec:      	ldr	w2, [x2]
    66f0:      	sxtw	x2, w2
    66f4:      	cmp	x2, #0x0
    66f8:      	cset	w2, gt
    66fc:      	ubfx	x2, x2, #0, #8
    6700:      	b	0x6778 <_stogir.locals.validate+0x618>
    6704:      	add	x16, sp, #0x10
    6708:      	ldr	w0, [x16, #0x4]
    670c:      	sxtw	x0, w0
    6710:      	cmp	x0, #0x0
    6714:      	b.le	0x6748 <_stogir.locals.validate+0x5e8>
    6718:      	uxtb	w1, w1
    671c:      	cmp	x1, #0x83
    6720:      	cset	w0, lt
    6724:      	uxtb	w16, w0
    6728:      	cmp	w16, wzr
    672c:      	b.eq	0x6784 <_stogir.locals.validate+0x624>
    6730:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006730:  ARM64_RELOC_PAGE21	l_stogir.395
    6734:      	ldr	x16, [x16]
		0000000000006734:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    6738:      	orr	x2, x16, xzr
    673c:      	add	x2, x1, x2
    6740:      	ldrb	w2, [x2]
    6744:      	b	0x6788 <_stogir.locals.validate+0x628>
    6748:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006748:  ARM64_RELOC_PAGE21	l_stogir.396
    674c:      	ldr	x16, [x16]
		000000000000674c:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    6750:      	orr	x0, x16, xzr
    6754:      	mov	x1, x0
    6758:      	mov	x0, #0x1                ; =1
    675c:      	mov	x2, #0x1c               ; =28
    6760:      	b	0x6664 <_stogir.locals.validate+0x504>
    6764:      	movz	x2, #0x0, lsl #48
    6768:      	b	0x6688 <_stogir.locals.validate+0x528>
    676c:      	movz	x2, #0x0, lsl #48
    6770:      	b	0x66b4 <_stogir.locals.validate+0x554>
    6774:      	movz	x2, #0x0, lsl #48
    6778:      	b	0x6768 <_stogir.locals.validate+0x608>
    677c:      	brk	#0
    6780:      	b	0x677c <_stogir.locals.validate+0x61c>
    6784:      	movz	x2, #0x0, lsl #48
    6788:      	uxtb	w2, w2
    678c:      	and	x2, x2, #0x1
    6790:      	uxtb	w2, w2
    6794:      	cmp	x2, #0x0
    6798:      	b.eq	0x6748 <_stogir.locals.validate+0x5e8>
    679c:      	uxtb	w16, w0
    67a0:      	cmp	w16, wzr
    67a4:      	b.eq	0x67c0 <_stogir.locals.validate+0x660>
    67a8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		00000000000067a8:  ARM64_RELOC_PAGE21	l_stogir.395
    67ac:      	ldr	x16, [x16]
		00000000000067ac:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    67b0:      	orr	x0, x16, xzr
    67b4:      	add	x0, x1, x0
    67b8:      	ldrb	w0, [x0]
    67bc:      	b	0x67c4 <_stogir.locals.validate+0x664>
    67c0:      	movz	x0, #0x0, lsl #48
    67c4:      	uxtb	w0, w0
    67c8:      	and	x0, x0, #0x4
    67cc:      	uxtb	w0, w0
    67d0:      	cmp	x0, #0x0
    67d4:      	cset	w0, eq
    67d8:      	uxtb	w16, w0
    67dc:      	cmp	w16, wzr
    67e0:      	cset	x0, eq
    67e4:      	cmp	x0, #0x0
    67e8:      	b.ne	0x6748 <_stogir.locals.validate+0x5e8>
    67ec:      	cmp	x19, #0x0
    67f0:      	b.eq	0x6890 <_stogir.locals.validate+0x730>
    67f4:      	add	x16, sp, #0x10
    67f8:      	ldr	w0, [x16, #0xc]
    67fc:      	lsr	w0, w0, #0
    6800:      	add	x8, sp, #0x40
    6804:      	mov	w1, w0
    6808:      	mov	x0, x24
    680c:      	bl	0x680c <_stogir.locals.validate+0x6ac>
		000000000000680c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    6810:      	add	x16, sp, #0x40
    6814:      	ldr	x0, [x16]
    6818:      	add	x16, sp, #0x40
    681c:      	ldr	x1, [x16, #0x8]
    6820:      	mov	x20, x1
    6824:      	b	0x68a0 <_stogir.locals.validate+0x740>
    6828:      	lsr	w25, w25, #0
    682c:      	lsr	w0, w20, #0
    6830:      	ubfx	x0, x0, #8, #8
    6834:      	lsr	w0, w0, #0
    6838:      	mov	w1, w25
    683c:      	bl	0x683c <_stogir.locals.validate+0x6dc>
		000000000000683c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    6840:      	lsr	w0, w0, #0
    6844:      	sxtw	x0, w0
    6848:      	cmp	x0, #0x0
    684c:      	b.le	0x6874 <_stogir.locals.validate+0x714>
    6850:      	cmp	x0, x22
    6854:      	b.gt	0x6874 <_stogir.locals.validate+0x714>
    6858:      	cmp	x19, #0x0
    685c:      	b.eq	0x68f4 <_stogir.locals.validate+0x794>
    6860:      	add	x16, sp, #0x10
    6864:      	ldr	w1, [x16]
    6868:      	ubfx	x1, x1, #8, #8
    686c:      	cmp	x1, #0x0
    6870:      	b.eq	0x68f4 <_stogir.locals.validate+0x794>
    6874:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006874:  ARM64_RELOC_PAGE21	l_stogir.397
    6878:      	ldr	x16, [x16]
		0000000000006878:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    687c:      	orr	x0, x16, xzr
    6880:      	mov	x1, x0
    6884:      	mov	x0, #0x1                ; =1
    6888:      	mov	x2, #0x23               ; =35
    688c:      	b	0x6760 <_stogir.locals.validate+0x600>
    6890:      	add	x16, sp, #0x10
    6894:      	ldr	x0, [x16]
    6898:      	mov	x20, x0
    689c:      	mov	x0, #0x1                ; =1
    68a0:      	lsr	w0, w0, #0
    68a4:      	lsr	x16, x0, #0
    68a8:      	cmp	x16, #0x1
    68ac:      	b.eq	0x68c8 <_stogir.locals.validate+0x768>
    68b0:      	b.lo	0x68b8 <_stogir.locals.validate+0x758>
    68b4:      	b	0x68cc <_stogir.locals.validate+0x76c>
    68b8:      	cmp	x16, #0x0
    68bc:      	b.eq	0x68c4 <_stogir.locals.validate+0x764>
    68c0:      	b	0x68cc <_stogir.locals.validate+0x76c>
    68c4:      	b	0x68d0 <_stogir.locals.validate+0x770>
    68c8:      	b	0x6828 <_stogir.locals.validate+0x6c8>
    68cc:      	b	0x6914 <_stogir.locals.validate+0x7b4>
    68d0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		00000000000068d0:  ARM64_RELOC_PAGE21	l_stogir.398
    68d4:      	ldr	x16, [x16]
		00000000000068d4:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    68d8:      	orr	x0, x16, xzr
    68dc:      	mov	x1, x0
    68e0:      	mov	x0, #0x1                ; =1
    68e4:      	mov	x2, #0x19               ; =25
    68e8:      	b	0x688c <_stogir.locals.validate+0x72c>
    68ec:      	brk	#0
    68f0:      	b	0x68ec <_stogir.locals.validate+0x78c>
    68f4:      	uxtb	w20, w20
    68f8:      	cmp	x20, #0x48
    68fc:      	b.eq	0x6874 <_stogir.locals.validate+0x714>
    6900:      	and	x0, x0, #0xffffffff
    6904:      	mov	x1, x0
    6908:      	movz	x0, #0x0, lsl #48
    690c:      	movz	x2, #0x0, lsl #48
    6910:      	b	0x688c <_stogir.locals.validate+0x72c>
    6914:      	brk	#0
    6918:      	b	0x6914 <_stogir.locals.validate+0x7b4>
    691c:      	mov	x23, x8
    6920:      	b	0x6274 <_stogir.locals.validate+0x114>
    6924:      	mov	x23, x8
    6928:      	b	0x6274 <_stogir.locals.validate+0x114>

000000000000692c <_stogir.conversion.operation?>:
    692c:      	sxtw	x0, w0
    6930:      	cmp	x0, #0x21
    6934:      	b.lt	0x6948 <_stogir.conversion.operation?+0x1c>
    6938:      	cmp	x0, #0x27
    693c:      	cset	w0, le
    6940:      	ubfx	x0, x0, #0, #8
    6944:      	b	0x694c <_stogir.conversion.operation?+0x20>
    6948:      	movz	x0, #0x0, lsl #48
    694c:      	ret

0000000000006950 <_stogir.conversion.validate>:
    6950:      	sub	sp, sp, #0x40
    6954:      	str	x29, [sp]
    6958:      	str	x30, [sp, #0x8]
    695c:      	mov	x29, sp
    6960:      	str	x19, [sp, #0x30]
    6964:      	sxtw	x1, w1
    6968:      	lsl	x3, x1, #2
    696c:      	cmp	x1, #0x0
    6970:      	cset	w4, gt
    6974:      	movz	x16, #0x0, lsl #48
    6978:      	sub	x5, x16, x1
    697c:      	sub	x6, x5, #0x1
    6980:      	uxtb	w16, w4
    6984:      	cmp	w16, wzr
    6988:      	b.eq	0x69c8 <_stogir.conversion.validate+0x78>
    698c:      	ldr	x5, [x0, #0x8]
    6990:      	cmp	x1, x5
    6994:      	b.ge	0x6a1c <_stogir.conversion.validate+0xcc>
    6998:      	add	x5, x0, #0x78
    699c:      	ldr	x5, [x5, #0x8]
    69a0:      	cmp	x1, x5
    69a4:      	b.ge	0x6b08 <_stogir.conversion.validate+0x1b8>
    69a8:      	ldr	x5, [x0, #0x78]
    69ac:      	add	x5, x3, x5
    69b0:      	ldr	w5, [x5]
    69b4:      	sxtw	x5, w5
    69b8:      	cmp	x5, #0x0
    69bc:      	cset	w5, ge
    69c0:      	ubfx	x5, x5, #0, #8
    69c4:      	b	0x6b0c <_stogir.conversion.validate+0x1bc>
    69c8:      	cmp	x1, #0x0
    69cc:      	b.ge	0x6a24 <_stogir.conversion.validate+0xd4>
    69d0:      	add	x7, x0, #0x28
    69d4:      	add	x9, x0, #0x50
    69d8:      	ldr	x7, [x7, #0x8]
    69dc:      	ldr	x9, [x9, #0x8]
    69e0:      	cmp	x7, x9
    69e4:      	b.ne	0x6a14 <_stogir.conversion.validate+0xc4>
    69e8:      	cmp	x5, x7
    69ec:      	b.gt	0x6ba0 <_stogir.conversion.validate+0x250>
    69f0:      	lsl	x5, x6, #2
    69f4:      	ldr	x7, [x0, #0x50]
    69f8:      	add	x5, x5, x7
    69fc:      	ldr	w5, [x5]
    6a00:      	sxtw	x5, w5
    6a04:      	cmp	x5, #0x0
    6a08:      	cset	w5, gt
    6a0c:      	ubfx	x5, x5, #0, #8
    6a10:      	b	0x6ba4 <_stogir.conversion.validate+0x254>
    6a14:      	movz	x5, #0x0, lsl #48
    6a18:      	b	0x6a28 <_stogir.conversion.validate+0xd8>
    6a1c:      	movz	x5, #0x0, lsl #48
    6a20:      	b	0x6a28 <_stogir.conversion.validate+0xd8>
    6a24:      	movz	x5, #0x0, lsl #48
    6a28:      	cmp	x5, #0x0
    6a2c:      	b.eq	0x6a6c <_stogir.conversion.validate+0x11c>
    6a30:      	uxtb	w16, w4
    6a34:      	cmp	w16, wzr
    6a38:      	b.eq	0x6a50 <_stogir.conversion.validate+0x100>
    6a3c:      	lsl	x4, x1, #4
    6a40:      	ldr	x5, [x0]
    6a44:      	add	x4, x4, x5
    6a48:      	ldr	x4, [x4]
    6a4c:      	b	0x6a60 <_stogir.conversion.validate+0x110>
    6a50:      	lsl	x4, x6, #4
    6a54:      	ldr	x5, [x0, #0x28]
    6a58:      	add	x4, x4, x5
    6a5c:      	ldr	x4, [x4]
    6a60:      	mov	x5, x4
    6a64:      	mov	x4, #0x1                ; =1
    6a68:      	b	0x6a74 <_stogir.conversion.validate+0x124>
    6a6c:      	movz	x4, #0x0, lsl #48
    6a70:      	movz	x5, #0x0, lsl #48
    6a74:      	lsr	w4, w4, #0
    6a78:      	lsr	x16, x4, #0
    6a7c:      	cmp	x16, #0x1
    6a80:      	b.eq	0x6a9c <_stogir.conversion.validate+0x14c>
    6a84:      	b.lo	0x6a8c <_stogir.conversion.validate+0x13c>
    6a88:      	b	0x6aa0 <_stogir.conversion.validate+0x150>
    6a8c:      	cmp	x16, #0x0
    6a90:      	b.eq	0x6a98 <_stogir.conversion.validate+0x148>
    6a94:      	b	0x6aa0 <_stogir.conversion.validate+0x150>
    6a98:      	b	0x6aa4 <_stogir.conversion.validate+0x154>
    6a9c:      	b	0x6ae0 <_stogir.conversion.validate+0x190>
    6aa0:      	b	0x6c20 <_stogir.conversion.validate+0x2d0>
    6aa4:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006aa4:  ARM64_RELOC_PAGE21	l_stogir.399
    6aa8:      	ldr	x16, [x16]
		0000000000006aa8:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    6aac:      	orr	x0, x16, xzr
    6ab0:      	mov	x19, x8
    6ab4:      	mov	x1, x0
    6ab8:      	mov	x0, #0x1                ; =1
    6abc:      	mov	x2, #0x12               ; =18
    6ac0:      	str	x0, [x19]
    6ac4:      	str	x1, [x19, #0x8]
    6ac8:      	str	x2, [x19, #0x10]
    6acc:      	ldr	x19, [sp, #0x30]
    6ad0:      	ldr	x29, [sp]
    6ad4:      	ldr	x30, [sp, #0x8]
    6ad8:      	add	sp, sp, #0x40
    6adc:      	ret
    6ae0:      	cmp	x1, #0x0
    6ae4:      	b.gt	0x6b10 <_stogir.conversion.validate+0x1c0>
    6ae8:      	mov	x19, x8
    6aec:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006aec:  ARM64_RELOC_PAGE21	l_stogir.400
    6af0:      	ldr	x16, [x16]
		0000000000006af0:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    6af4:      	orr	x0, x16, xzr
    6af8:      	mov	x1, x0
    6afc:      	mov	x0, #0x1                ; =1
    6b00:      	mov	x2, #0x1e               ; =30
    6b04:      	b	0x6ac0 <_stogir.conversion.validate+0x170>
    6b08:      	movz	x5, #0x0, lsl #48
    6b0c:      	b	0x6a20 <_stogir.conversion.validate+0xd0>
    6b10:      	uxtb	w1, w5
    6b14:      	orr	x4, x1, xzr
    6b18:      	cmp	x4, #0x21
    6b1c:      	b.lt	0x6d54 <_stogir.conversion.validate+0x404>
    6b20:      	cmp	x4, #0x27
    6b24:      	b.gt	0x6d5c <_stogir.conversion.validate+0x40c>
    6b28:      	ldr	x4, [x0, #0x78]
    6b2c:      	add	x3, x3, x4
    6b30:      	ldr	w3, [x3]
    6b34:      	sxtw	x3, w3
    6b38:      	cmp	x3, #0x1
    6b3c:      	b.ne	0x6d64 <_stogir.conversion.validate+0x414>
    6b40:      	asr	x3, x5, #32
    6b44:      	cmp	x3, #0x0
    6b48:      	cset	w6, gt
    6b4c:      	movz	x16, #0x0, lsl #48
    6b50:      	sub	x7, x16, x3
    6b54:      	sub	x9, x7, #0x1
    6b58:      	uxtb	w16, w6
    6b5c:      	cmp	w16, wzr
    6b60:      	b.eq	0x6bd4 <_stogir.conversion.validate+0x284>
    6b64:      	ldr	x7, [x0, #0x8]
    6b68:      	cmp	x3, x7
    6b6c:      	b.ge	0x6c28 <_stogir.conversion.validate+0x2d8>
    6b70:      	add	x7, x0, #0x78
    6b74:      	ldr	x7, [x7, #0x8]
    6b78:      	cmp	x3, x7
    6b7c:      	b.ge	0x6cd8 <_stogir.conversion.validate+0x388>
    6b80:      	lsl	x7, x3, #2
    6b84:      	add	x4, x7, x4
    6b88:      	ldr	w4, [x4]
    6b8c:      	sxtw	x4, w4
    6b90:      	cmp	x4, #0x0
    6b94:      	cset	w4, ge
    6b98:      	ubfx	x4, x4, #0, #8
    6b9c:      	b	0x6cdc <_stogir.conversion.validate+0x38c>
    6ba0:      	movz	x5, #0x0, lsl #48
    6ba4:      	b	0x6a18 <_stogir.conversion.validate+0xc8>
    6ba8:      	uxtb	w0, w3
    6bac:      	cmp	x0, #0x48
    6bb0:      	b.ne	0x6ce0 <_stogir.conversion.validate+0x390>
    6bb4:      	mov	x19, x8
    6bb8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006bb8:  ARM64_RELOC_PAGE21	l_stogir.401
    6bbc:      	ldr	x16, [x16]
		0000000000006bbc:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    6bc0:      	orr	x0, x16, xzr
    6bc4:      	mov	x1, x0
    6bc8:      	mov	x0, #0x1                ; =1
    6bcc:      	mov	x2, #0x25               ; =37
    6bd0:      	b	0x6b04 <_stogir.conversion.validate+0x1b4>
    6bd4:      	cmp	x3, #0x0
    6bd8:      	b.ge	0x6c30 <_stogir.conversion.validate+0x2e0>
    6bdc:      	add	x4, x0, #0x28
    6be0:      	add	x10, x0, #0x50
    6be4:      	ldr	x4, [x4, #0x8]
    6be8:      	ldr	x10, [x10, #0x8]
    6bec:      	cmp	x4, x10
    6bf0:      	b.ne	0x6cd0 <_stogir.conversion.validate+0x380>
    6bf4:      	cmp	x7, x4
    6bf8:      	b.gt	0x6d44 <_stogir.conversion.validate+0x3f4>
    6bfc:      	lsl	x4, x9, #2
    6c00:      	ldr	x7, [x0, #0x50]
    6c04:      	add	x4, x4, x7
    6c08:      	ldr	w4, [x4]
    6c0c:      	sxtw	x4, w4
    6c10:      	cmp	x4, #0x0
    6c14:      	cset	w4, gt
    6c18:      	ubfx	x4, x4, #0, #8
    6c1c:      	b	0x6d48 <_stogir.conversion.validate+0x3f8>
    6c20:      	brk	#0
    6c24:      	b	0x6c20 <_stogir.conversion.validate+0x2d0>
    6c28:      	movz	x4, #0x0, lsl #48
    6c2c:      	b	0x6c34 <_stogir.conversion.validate+0x2e4>
    6c30:      	movz	x4, #0x0, lsl #48
    6c34:      	cmp	x4, #0x0
    6c38:      	b.eq	0x6c78 <_stogir.conversion.validate+0x328>
    6c3c:      	uxtb	w16, w6
    6c40:      	cmp	w16, wzr
    6c44:      	b.eq	0x6c5c <_stogir.conversion.validate+0x30c>
    6c48:      	lsl	x3, x3, #4
    6c4c:      	ldr	x0, [x0]
    6c50:      	add	x0, x3, x0
    6c54:      	ldr	x0, [x0]
    6c58:      	b	0x6c6c <_stogir.conversion.validate+0x31c>
    6c5c:      	lsl	x3, x9, #4
    6c60:      	ldr	x0, [x0, #0x28]
    6c64:      	add	x0, x3, x0
    6c68:      	ldr	x0, [x0]
    6c6c:      	mov	x3, x0
    6c70:      	mov	x0, #0x1                ; =1
    6c74:      	b	0x6c80 <_stogir.conversion.validate+0x330>
    6c78:      	movz	x0, #0x0, lsl #48
    6c7c:      	movz	x3, #0x0, lsl #48
    6c80:      	lsr	w0, w0, #0
    6c84:      	lsr	x16, x0, #0
    6c88:      	cmp	x16, #0x1
    6c8c:      	b.eq	0x6ca8 <_stogir.conversion.validate+0x358>
    6c90:      	b.lo	0x6c98 <_stogir.conversion.validate+0x348>
    6c94:      	b	0x6cac <_stogir.conversion.validate+0x35c>
    6c98:      	cmp	x16, #0x0
    6c9c:      	b.eq	0x6ca4 <_stogir.conversion.validate+0x354>
    6ca0:      	b	0x6cac <_stogir.conversion.validate+0x35c>
    6ca4:      	b	0x6cb0 <_stogir.conversion.validate+0x360>
    6ca8:      	b	0x6ba8 <_stogir.conversion.validate+0x258>
    6cac:      	b	0x6d4c <_stogir.conversion.validate+0x3fc>
    6cb0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006cb0:  ARM64_RELOC_PAGE21	l_stogir.402
    6cb4:      	ldr	x16, [x16]
		0000000000006cb4:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    6cb8:      	orr	x0, x16, xzr
    6cbc:      	mov	x19, x8
    6cc0:      	mov	x1, x0
    6cc4:      	mov	x0, #0x1                ; =1
    6cc8:      	mov	x2, #0x19               ; =25
    6ccc:      	b	0x6bd0 <_stogir.conversion.validate+0x280>
    6cd0:      	movz	x4, #0x0, lsl #48
    6cd4:      	b	0x6c34 <_stogir.conversion.validate+0x2e4>
    6cd8:      	movz	x4, #0x0, lsl #48
    6cdc:      	b	0x6c2c <_stogir.conversion.validate+0x2dc>
    6ce0:      	cmp	x0, #0x46
    6ce4:      	b.eq	0x6d6c <_stogir.conversion.validate+0x41c>
    6ce8:      	lsr	w2, w2, #0
    6cec:      	lsr	w5, w5, #0
    6cf0:      	lsr	w3, w3, #0
    6cf4:      	lsr	w1, w1, #0
    6cf8:      	ubfx	x0, x5, #8, #8
    6cfc:      	ubfx	x3, x3, #8, #8
    6d00:      	lsr	w0, w0, #0
    6d04:      	lsr	w3, w3, #0
    6d08:      	mov	x19, x8
    6d0c:      	add	x8, sp, #0x10
    6d10:      	fmov	s31, w0
    6d14:      	mov	w0, w1
    6d18:      	mov	w1, w3
    6d1c:      	mov	w3, w2
    6d20:      	fmov	w2, s31
    6d24:      	bl	0x6d24 <_stogir.conversion.validate+0x3d4>
		0000000000006d24:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    6d28:      	add	x16, sp, #0x10
    6d2c:      	ldr	x0, [x16]
    6d30:      	add	x16, sp, #0x10
    6d34:      	ldr	x1, [x16, #0x8]
    6d38:      	add	x16, sp, #0x10
    6d3c:      	ldr	x2, [x16, #0x10]
    6d40:      	b	0x6bd0 <_stogir.conversion.validate+0x280>
    6d44:      	movz	x4, #0x0, lsl #48
    6d48:      	b	0x6cd4 <_stogir.conversion.validate+0x384>
    6d4c:      	brk	#0
    6d50:      	b	0x6d4c <_stogir.conversion.validate+0x3fc>
    6d54:      	mov	x19, x8
    6d58:      	b	0x6aec <_stogir.conversion.validate+0x19c>
    6d5c:      	mov	x19, x8
    6d60:      	b	0x6aec <_stogir.conversion.validate+0x19c>
    6d64:      	mov	x19, x8
    6d68:      	b	0x6aec <_stogir.conversion.validate+0x19c>
    6d6c:      	mov	x19, x8
    6d70:      	b	0x6bb8 <_stogir.conversion.validate+0x268>

0000000000006d74 <_stogir.conditional.validate>:
    6d74:      	sub	sp, sp, #0x40
    6d78:      	str	x29, [sp]
    6d7c:      	str	x30, [sp, #0x8]
    6d80:      	mov	x29, sp
    6d84:      	str	x19, [sp, #0x30]
    6d88:      	sxtw	x1, w1
    6d8c:      	lsl	x2, x1, #2
    6d90:      	cmp	x1, #0x0
    6d94:      	cset	w3, gt
    6d98:      	movz	x16, #0x0, lsl #48
    6d9c:      	sub	x4, x16, x1
    6da0:      	sub	x5, x4, #0x1
    6da4:      	uxtb	w16, w3
    6da8:      	cmp	w16, wzr
    6dac:      	b.eq	0x6dec <_stogir.conditional.validate+0x78>
    6db0:      	ldr	x4, [x0, #0x8]
    6db4:      	cmp	x1, x4
    6db8:      	b.ge	0x6e40 <_stogir.conditional.validate+0xcc>
    6dbc:      	add	x4, x0, #0x78
    6dc0:      	ldr	x4, [x4, #0x8]
    6dc4:      	cmp	x1, x4
    6dc8:      	b.ge	0x6f54 <_stogir.conditional.validate+0x1e0>
    6dcc:      	ldr	x4, [x0, #0x78]
    6dd0:      	add	x4, x2, x4
    6dd4:      	ldr	w4, [x4]
    6dd8:      	sxtw	x4, w4
    6ddc:      	cmp	x4, #0x0
    6de0:      	cset	w4, ge
    6de4:      	ubfx	x4, x4, #0, #8
    6de8:      	b	0x6f58 <_stogir.conditional.validate+0x1e4>
    6dec:      	cmp	x1, #0x0
    6df0:      	b.ge	0x6e48 <_stogir.conditional.validate+0xd4>
    6df4:      	add	x6, x0, #0x28
    6df8:      	add	x7, x0, #0x50
    6dfc:      	ldr	x6, [x6, #0x8]
    6e00:      	ldr	x7, [x7, #0x8]
    6e04:      	cmp	x6, x7
    6e08:      	b.ne	0x6e38 <_stogir.conditional.validate+0xc4>
    6e0c:      	cmp	x4, x6
    6e10:      	b.gt	0x6fdc <_stogir.conditional.validate+0x268>
    6e14:      	lsl	x4, x5, #2
    6e18:      	ldr	x6, [x0, #0x50]
    6e1c:      	add	x4, x4, x6
    6e20:      	ldr	w4, [x4]
    6e24:      	sxtw	x4, w4
    6e28:      	cmp	x4, #0x0
    6e2c:      	cset	w4, gt
    6e30:      	ubfx	x4, x4, #0, #8
    6e34:      	b	0x6fe0 <_stogir.conditional.validate+0x26c>
    6e38:      	movz	x4, #0x0, lsl #48
    6e3c:      	b	0x6e4c <_stogir.conditional.validate+0xd8>
    6e40:      	movz	x4, #0x0, lsl #48
    6e44:      	b	0x6e4c <_stogir.conditional.validate+0xd8>
    6e48:      	movz	x4, #0x0, lsl #48
    6e4c:      	cmp	x4, #0x0
    6e50:      	b.eq	0x6eb4 <_stogir.conditional.validate+0x140>
    6e54:      	uxtb	w16, w3
    6e58:      	cmp	w16, wzr
    6e5c:      	b.eq	0x6e84 <_stogir.conditional.validate+0x110>
    6e60:      	lsl	x3, x1, #4
    6e64:      	ldr	x4, [x0]
    6e68:      	add	x3, x3, x4
    6e6c:      	ldr	x4, [x3]
    6e70:      	ldr	x3, [x3, #0x8]
    6e74:      	fmov	d31, x3
    6e78:      	mov	x3, x4
    6e7c:      	fmov	x4, d31
    6e80:      	b	0x6ea4 <_stogir.conditional.validate+0x130>
    6e84:      	lsl	x3, x5, #4
    6e88:      	ldr	x4, [x0, #0x28]
    6e8c:      	add	x3, x3, x4
    6e90:      	ldr	x4, [x3]
    6e94:      	ldr	x3, [x3, #0x8]
    6e98:      	fmov	d31, x3
    6e9c:      	mov	x3, x4
    6ea0:      	fmov	x4, d31
    6ea4:      	mov	x5, x4
    6ea8:      	mov	x4, x3
    6eac:      	mov	x3, #0x1                ; =1
    6eb0:      	b	0x6ec0 <_stogir.conditional.validate+0x14c>
    6eb4:      	movz	x3, #0x0, lsl #48
    6eb8:      	movz	x4, #0x0, lsl #48
    6ebc:      	movz	x5, #0x0, lsl #48
    6ec0:      	lsr	w3, w3, #0
    6ec4:      	lsr	x16, x3, #0
    6ec8:      	cmp	x16, #0x1
    6ecc:      	b.eq	0x6ee8 <_stogir.conditional.validate+0x174>
    6ed0:      	b.lo	0x6ed8 <_stogir.conditional.validate+0x164>
    6ed4:      	b	0x6eec <_stogir.conditional.validate+0x178>
    6ed8:      	cmp	x16, #0x0
    6edc:      	b.eq	0x6ee4 <_stogir.conditional.validate+0x170>
    6ee0:      	b	0x6eec <_stogir.conditional.validate+0x178>
    6ee4:      	b	0x6ef0 <_stogir.conditional.validate+0x17c>
    6ee8:      	b	0x6f10 <_stogir.conditional.validate+0x19c>
    6eec:      	b	0x6fe4 <_stogir.conditional.validate+0x270>
    6ef0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006ef0:  ARM64_RELOC_PAGE21	l_stogir.403
    6ef4:      	ldr	x16, [x16]
		0000000000006ef4:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    6ef8:      	orr	x0, x16, xzr
    6efc:      	mov	x19, x8
    6f00:      	mov	x1, x0
    6f04:      	mov	x0, #0x1                ; =1
    6f08:      	mov	x2, #0x18               ; =24
    6f0c:      	b	0x6f34 <_stogir.conditional.validate+0x1c0>
    6f10:      	cmp	x1, #0x0
    6f14:      	b.gt	0x6f5c <_stogir.conditional.validate+0x1e8>
    6f18:      	mov	x19, x8
    6f1c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x514>
		0000000000006f1c:  ARM64_RELOC_PAGE21	l_stogir.404
    6f20:      	ldr	x16, [x16]
		0000000000006f20:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    6f24:      	orr	x0, x16, xzr
    6f28:      	mov	x1, x0
    6f2c:      	mov	x0, #0x1                ; =1
    6f30:      	mov	x2, #0x18               ; =24
    6f34:      	str	x0, [x19]
    6f38:      	str	x1, [x19, #0x8]
    6f3c:      	str	x2, [x19, #0x10]
    6f40:      	ldr	x19, [sp, #0x30]
    6f44:      	ldr	x29, [sp]
    6f48:      	ldr	x30, [sp, #0x8]
    6f4c:      	add	sp, sp, #0x40
    6f50:      	ret
    6f54:      	movz	x4, #0x0, lsl #48
    6f58:      	b	0x6e44 <_stogir.conditional.validate+0xd0>
    6f5c:      	uxtb	w1, w4
    6f60:      	cmp	x1, #0x3c
    6f64:      	b.ne	0x6fec <_stogir.conditional.validate+0x278>
    6f68:      	ldr	x1, [x0, #0x78]
    6f6c:      	add	x1, x2, x1
    6f70:      	ldr	w1, [x1]
    6f74:      	sxtw	x1, w1
    6f78:      	cmp	x1, #0x3
    6f7c:      	b.ne	0x6ff4 <_stogir.conditional.validate+0x280>
    6f80:      	lsr	w1, w5, #0
    6f84:      	lsr	w2, w4, #0
    6f88:      	lsr	x3, x4, #32
    6f8c:      	lsr	w1, w1, #0
    6f90:      	lsr	x4, x5, #32
    6f94:      	lsr	w3, w3, #0
    6f98:      	lsr	w4, w4, #0
    6f9c:      	ubfx	x2, x2, #8, #8
    6fa0:      	lsr	w2, w2, #0
    6fa4:      	mov	x19, x8
    6fa8:      	add	x8, sp, #0x10
    6fac:      	fmov	s31, w1
    6fb0:      	mov	w1, w2
    6fb4:      	mov	w2, w3
    6fb8:      	fmov	w3, s31
    6fbc:      	bl	0x6fbc <_stogir.conditional.validate+0x248>
		0000000000006fbc:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    6fc0:      	add	x16, sp, #0x10
    6fc4:      	ldr	x0, [x16]
    6fc8:      	add	x16, sp, #0x10
    6fcc:      	ldr	x1, [x16, #0x8]
    6fd0:      	add	x16, sp, #0x10
    6fd4:      	ldr	x2, [x16, #0x10]
    6fd8:      	b	0x6f34 <_stogir.conditional.validate+0x1c0>
    6fdc:      	movz	x4, #0x0, lsl #48
    6fe0:      	b	0x6e3c <_stogir.conditional.validate+0xc8>
    6fe4:      	brk	#0
    6fe8:      	b	0x6fe4 <_stogir.conditional.validate+0x270>
    6fec:      	mov	x19, x8
    6ff0:      	b	0x6f1c <_stogir.conditional.validate+0x1a8>
    6ff4:      	mov	x19, x8
    6ff8:      	b	0x6f1c <_stogir.conditional.validate+0x1a8>

0000000000006ffc <_stogir.floating.validate>:
    6ffc:      	sub	sp, sp, #0x50
    7000:      	str	x29, [sp]
    7004:      	str	x30, [sp, #0x8]
    7008:      	mov	x29, sp
    700c:      	str	x19, [sp, #0x40]
    7010:      	sxtw	x1, w1
    7014:      	lsl	x2, x1, #2
    7018:      	cmp	x1, #0x0
    701c:      	cset	w3, gt
    7020:      	movz	x16, #0x0, lsl #48
    7024:      	sub	x4, x16, x1
    7028:      	sub	x5, x4, #0x1
    702c:      	uxtb	w16, w3
    7030:      	cmp	w16, wzr
    7034:      	b.eq	0x7074 <_stogir.floating.validate+0x78>
    7038:      	ldr	x4, [x0, #0x8]
    703c:      	cmp	x1, x4
    7040:      	b.ge	0x70c8 <_stogir.floating.validate+0xcc>
    7044:      	add	x4, x0, #0x78
    7048:      	ldr	x4, [x4, #0x8]
    704c:      	cmp	x1, x4
    7050:      	b.ge	0x71ec <_stogir.floating.validate+0x1f0>
    7054:      	ldr	x4, [x0, #0x78]
    7058:      	add	x4, x2, x4
    705c:      	ldr	w4, [x4]
    7060:      	sxtw	x4, w4
    7064:      	cmp	x4, #0x0
    7068:      	cset	w4, ge
    706c:      	ubfx	x4, x4, #0, #8
    7070:      	b	0x71f0 <_stogir.floating.validate+0x1f4>
    7074:      	cmp	x1, #0x0
    7078:      	b.ge	0x70d0 <_stogir.floating.validate+0xd4>
    707c:      	add	x6, x0, #0x28
    7080:      	add	x7, x0, #0x50
    7084:      	ldr	x6, [x6, #0x8]
    7088:      	ldr	x7, [x7, #0x8]
    708c:      	cmp	x6, x7
    7090:      	b.ne	0x70c0 <_stogir.floating.validate+0xc4>
    7094:      	cmp	x4, x6
    7098:      	b.gt	0x7278 <_stogir.floating.validate+0x27c>
    709c:      	lsl	x4, x5, #2
    70a0:      	ldr	x6, [x0, #0x50]
    70a4:      	add	x4, x4, x6
    70a8:      	ldr	w4, [x4]
    70ac:      	sxtw	x4, w4
    70b0:      	cmp	x4, #0x0
    70b4:      	cset	w4, gt
    70b8:      	ubfx	x4, x4, #0, #8
    70bc:      	b	0x727c <_stogir.floating.validate+0x280>
    70c0:      	movz	x4, #0x0, lsl #48
    70c4:      	b	0x70d4 <_stogir.floating.validate+0xd8>
    70c8:      	movz	x4, #0x0, lsl #48
    70cc:      	b	0x70d4 <_stogir.floating.validate+0xd8>
    70d0:      	movz	x4, #0x0, lsl #48
    70d4:      	cmp	x4, #0x0
    70d8:      	b.eq	0x713c <_stogir.floating.validate+0x140>
    70dc:      	uxtb	w16, w3
    70e0:      	cmp	w16, wzr
    70e4:      	b.eq	0x710c <_stogir.floating.validate+0x110>
    70e8:      	lsl	x3, x1, #4
    70ec:      	ldr	x4, [x0]
    70f0:      	add	x3, x3, x4
    70f4:      	ldr	x4, [x3]
    70f8:      	ldr	x3, [x3, #0x8]
    70fc:      	fmov	d31, x3
    7100:      	mov	x3, x4
    7104:      	fmov	x4, d31
    7108:      	b	0x712c <_stogir.floating.validate+0x130>
    710c:      	lsl	x3, x5, #4
    7110:      	ldr	x4, [x0, #0x28]
    7114:      	add	x3, x3, x4
    7118:      	ldr	x4, [x3]
    711c:      	ldr	x3, [x3, #0x8]
    7120:      	fmov	d31, x3
    7124:      	mov	x3, x4
    7128:      	fmov	x4, d31
    712c:      	mov	x5, x4
    7130:      	mov	x4, x3
    7134:      	mov	x3, #0x1                ; =1
    7138:      	b	0x7148 <_stogir.floating.validate+0x14c>
    713c:      	movz	x3, #0x0, lsl #48
    7140:      	movz	x4, #0x0, lsl #48
    7144:      	movz	x5, #0x0, lsl #48
    7148:      	lsr	w3, w3, #0
    714c:      	lsr	x16, x3, #0
    7150:      	cmp	x16, #0x1
    7154:      	b.eq	0x7170 <_stogir.floating.validate+0x174>
    7158:      	b.lo	0x7160 <_stogir.floating.validate+0x164>
    715c:      	b	0x7174 <_stogir.floating.validate+0x178>
    7160:      	cmp	x16, #0x0
    7164:      	b.eq	0x716c <_stogir.floating.validate+0x170>
    7168:      	b	0x7174 <_stogir.floating.validate+0x178>
    716c:      	b	0x7178 <_stogir.floating.validate+0x17c>
    7170:      	b	0x71b4 <_stogir.floating.validate+0x1b8>
    7174:      	b	0x7534 <_stogir.floating.validate+0x538>
    7178:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x4>
		0000000000007178:  ARM64_RELOC_PAGE21	l_stogir.405
    717c:      	ldr	x16, [x16]
		000000000000717c:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    7180:      	orr	x0, x16, xzr
    7184:      	mov	x19, x8
    7188:      	mov	x1, x0
    718c:      	mov	x0, #0x1                ; =1
    7190:      	mov	x2, #0x1c               ; =28
    7194:      	str	x0, [x19]
    7198:      	str	x1, [x19, #0x8]
    719c:      	str	x2, [x19, #0x10]
    71a0:      	ldr	x19, [sp, #0x40]
    71a4:      	ldr	x29, [sp]
    71a8:      	ldr	x30, [sp, #0x8]
    71ac:      	add	sp, sp, #0x50
    71b0:      	ret
    71b4:      	add	x16, sp, #0x10
    71b8:      	str	x4, [x16]
    71bc:      	add	x16, sp, #0x10
    71c0:      	str	x5, [x16, #0x8]
    71c4:      	cmp	x1, #0x0
    71c8:      	b.gt	0x71f4 <_stogir.floating.validate+0x1f8>
    71cc:      	mov	x19, x8
    71d0:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x4>
		00000000000071d0:  ARM64_RELOC_PAGE21	l_stogir.406
    71d4:      	ldr	x16, [x16]
		00000000000071d4:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    71d8:      	orr	x0, x16, xzr
    71dc:      	mov	x1, x0
    71e0:      	mov	x0, #0x1                ; =1
    71e4:      	mov	x2, #0x1c               ; =28
    71e8:      	b	0x7194 <_stogir.floating.validate+0x198>
    71ec:      	movz	x4, #0x0, lsl #48
    71f0:      	b	0x70cc <_stogir.floating.validate+0xd0>
    71f4:      	uxtb	w4, w4
    71f8:      	orr	x1, x4, xzr
    71fc:      	cmp	x1, #0xe
    7200:      	cset	w3, ge
    7204:      	cmp	x1, #0x19
    7208:      	cset	w5, le
    720c:      	cmp	x1, #0x1f
    7210:      	cset	w6, eq
    7214:      	cmp	x1, #0x20
    7218:      	cset	w7, eq
    721c:      	uxtb	w16, w3
    7220:      	cmp	w16, wzr
    7224:      	b.eq	0x7280 <_stogir.floating.validate+0x284>
    7228:      	uxtb	w16, w5
    722c:      	cmp	w16, wzr
    7230:      	b.eq	0x7280 <_stogir.floating.validate+0x284>
    7234:      	cmp	x1, #0x1d
    7238:      	cset	w1, eq
    723c:      	ldr	x9, [x0, #0x78]
    7240:      	add	x2, x2, x9
    7244:      	ldr	w2, [x2]
    7248:      	uxtb	w16, w6
    724c:      	cmp	w16, wzr
    7250:      	b.ne	0x72c0 <_stogir.floating.validate+0x2c4>
    7254:      	uxtb	w16, w7
    7258:      	cmp	w16, wzr
    725c:      	b.ne	0x72c0 <_stogir.floating.validate+0x2c4>
    7260:      	uxtb	w16, w1
    7264:      	cmp	w16, wzr
    7268:      	mov	x16, #0x3               ; =3
    726c:      	mov	x17, #0x2               ; =2
    7270:      	csel	x6, x16, x17, ne
    7274:      	b	0x72c4 <_stogir.floating.validate+0x2c8>
    7278:      	movz	x4, #0x0, lsl #48
    727c:      	b	0x70c4 <_stogir.floating.validate+0xc8>
    7280:      	uxtb	w16, w6
    7284:      	cmp	w16, wzr
    7288:      	b.ne	0x7234 <_stogir.floating.validate+0x238>
    728c:      	uxtb	w16, w7
    7290:      	cmp	w16, wzr
    7294:      	b.ne	0x7234 <_stogir.floating.validate+0x238>
    7298:      	cmp	x1, #0x1a
    729c:      	b.lt	0x72a8 <_stogir.floating.validate+0x2ac>
    72a0:      	cmp	x1, #0x1d
    72a4:      	b.le	0x7234 <_stogir.floating.validate+0x238>
    72a8:      	cmp	x1, #0x3a
    72ac:      	b.eq	0x7234 <_stogir.floating.validate+0x238>
    72b0:      	cmp	x1, #0x3b
    72b4:      	b.eq	0x7234 <_stogir.floating.validate+0x238>
    72b8:      	mov	x19, x8
    72bc:      	b	0x71d0 <_stogir.floating.validate+0x1d4>
    72c0:      	mov	x6, #0x1                ; =1
    72c4:      	sxtw	x2, w2
    72c8:      	lsr	w6, w6, #0
    72cc:      	sxtw	x6, w6
    72d0:      	cmp	x2, x6
    72d4:      	b.ne	0x7544 <_stogir.floating.validate+0x548>
    72d8:      	add	x16, sp, #0x10
    72dc:      	ldr	w2, [x16, #0x4]
    72e0:      	sxtw	x2, w2
    72e4:      	cmp	x2, #0x0
    72e8:      	cset	w6, gt
    72ec:      	movz	x16, #0x0, lsl #48
    72f0:      	sub	x7, x16, x2
    72f4:      	sub	x9, x7, #0x1
    72f8:      	uxtb	w16, w6
    72fc:      	cmp	w16, wzr
    7300:      	b.eq	0x7360 <_stogir.floating.validate+0x364>
    7304:      	ldr	x7, [x0, #0x8]
    7308:      	cmp	x2, x7
    730c:      	b.ge	0x73ac <_stogir.floating.validate+0x3b0>
    7310:      	add	x7, x0, #0x78
    7314:      	ldr	x7, [x7, #0x8]
    7318:      	cmp	x2, x7
    731c:      	b.ge	0x748c <_stogir.floating.validate+0x490>
    7320:      	lsl	x7, x2, #2
    7324:      	ldr	x10, [x0, #0x78]
    7328:      	add	x7, x7, x10
    732c:      	ldr	w7, [x7]
    7330:      	sxtw	x7, w7
    7334:      	cmp	x7, #0x0
    7338:      	cset	w7, ge
    733c:      	ubfx	x7, x7, #0, #8
    7340:      	b	0x7490 <_stogir.floating.validate+0x494>
    7344:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x4>
		0000000000007344:  ARM64_RELOC_PAGE21	l_stogir.407
    7348:      	ldr	x16, [x16]
		0000000000007348:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    734c:      	orr	x0, x16, xzr
    7350:      	mov	x1, x0
    7354:      	mov	x0, #0x1                ; =1
    7358:      	mov	x2, #0x1d               ; =29
    735c:      	b	0x71e8 <_stogir.floating.validate+0x1ec>
    7360:      	cmp	x2, #0x0
    7364:      	b.ge	0x73b4 <_stogir.floating.validate+0x3b8>
    7368:      	add	x10, x0, #0x28
    736c:      	add	x11, x0, #0x50
    7370:      	ldr	x10, [x10, #0x8]
    7374:      	ldr	x11, [x11, #0x8]
    7378:      	cmp	x10, x11
    737c:      	b.ne	0x7484 <_stogir.floating.validate+0x488>
    7380:      	cmp	x7, x10
    7384:      	b.gt	0x752c <_stogir.floating.validate+0x530>
    7388:      	lsl	x7, x9, #2
    738c:      	ldr	x10, [x0, #0x50]
    7390:      	add	x7, x7, x10
    7394:      	ldr	w7, [x7]
    7398:      	sxtw	x7, w7
    739c:      	cmp	x7, #0x0
    73a0:      	cset	w7, gt
    73a4:      	ubfx	x7, x7, #0, #8
    73a8:      	b	0x7530 <_stogir.floating.validate+0x534>
    73ac:      	movz	x7, #0x0, lsl #48
    73b0:      	b	0x73b8 <_stogir.floating.validate+0x3bc>
    73b4:      	movz	x7, #0x0, lsl #48
    73b8:      	cmp	x7, #0x0
    73bc:      	b.eq	0x73fc <_stogir.floating.validate+0x400>
    73c0:      	uxtb	w16, w6
    73c4:      	cmp	w16, wzr
    73c8:      	b.eq	0x73e0 <_stogir.floating.validate+0x3e4>
    73cc:      	lsl	x2, x2, #4
    73d0:      	ldr	x6, [x0]
    73d4:      	add	x2, x2, x6
    73d8:      	ldr	x2, [x2]
    73dc:      	b	0x73f0 <_stogir.floating.validate+0x3f4>
    73e0:      	lsl	x2, x9, #4
    73e4:      	ldr	x6, [x0, #0x28]
    73e8:      	add	x2, x2, x6
    73ec:      	ldr	x2, [x2]
    73f0:      	mov	x6, x2
    73f4:      	mov	x2, #0x1                ; =1
    73f8:      	b	0x7404 <_stogir.floating.validate+0x408>
    73fc:      	movz	x2, #0x0, lsl #48
    7400:      	movz	x6, #0x0, lsl #48
    7404:      	lsr	w2, w2, #0
    7408:      	lsr	x16, x2, #0
    740c:      	cmp	x16, #0x1
    7410:      	b.eq	0x742c <_stogir.floating.validate+0x430>
    7414:      	b.lo	0x741c <_stogir.floating.validate+0x420>
    7418:      	b	0x7430 <_stogir.floating.validate+0x434>
    741c:      	cmp	x16, #0x0
    7420:      	b.eq	0x7428 <_stogir.floating.validate+0x42c>
    7424:      	b	0x7430 <_stogir.floating.validate+0x434>
    7428:      	b	0x7434 <_stogir.floating.validate+0x438>
    742c:      	b	0x7454 <_stogir.floating.validate+0x458>
    7430:      	b	0x753c <_stogir.floating.validate+0x540>
    7434:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x4>
		0000000000007434:  ARM64_RELOC_PAGE21	l_stogir.408
    7438:      	ldr	x16, [x16]
		0000000000007438:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    743c:      	orr	x0, x16, xzr
    7440:      	mov	x19, x8
    7444:      	mov	x1, x0
    7448:      	mov	x0, #0x1                ; =1
    744c:      	mov	x2, #0x18               ; =24
    7450:      	b	0x735c <_stogir.floating.validate+0x360>
    7454:      	lsr	w6, w6, #0
    7458:      	add	x16, sp, #0x10
    745c:      	ldr	w2, [x16]
    7460:      	ubfx	x6, x6, #8, #8
    7464:      	uxtb	w16, w3
    7468:      	cmp	w16, wzr
    746c:      	b.eq	0x74e8 <_stogir.floating.validate+0x4ec>
    7470:      	uxtb	w16, w5
    7474:      	cmp	w16, wzr
    7478:      	b.eq	0x74e8 <_stogir.floating.validate+0x4ec>
    747c:      	mov	x3, #0x1                ; =1
    7480:      	b	0x74ec <_stogir.floating.validate+0x4f0>
    7484:      	movz	x7, #0x0, lsl #48
    7488:      	b	0x73b8 <_stogir.floating.validate+0x3bc>
    748c:      	movz	x7, #0x0, lsl #48
    7490:      	b	0x73b0 <_stogir.floating.validate+0x3b4>
    7494:      	movz	x1, #0x0, lsl #48
    7498:      	lsr	w2, w2, #0
    749c:      	lsr	w3, w3, #0
    74a0:      	lsr	w4, w4, #0
    74a4:      	lsr	w6, w6, #0
    74a8:      	lsr	w1, w1, #0
    74ac:      	mov	w5, w1
    74b0:      	mov	w1, w4
    74b4:      	mov	w4, w3
    74b8:      	mov	w3, w2
    74bc:      	mov	w2, w6
    74c0:      	mov	x19, x8
    74c4:      	add	x8, sp, #0x20
    74c8:      	bl	0x74c8 <_stogir.floating.validate+0x4cc>
		00000000000074c8:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    74cc:      	add	x16, sp, #0x20
    74d0:      	ldr	x0, [x16]
    74d4:      	add	x16, sp, #0x20
    74d8:      	ldr	x1, [x16, #0x8]
    74dc:      	add	x16, sp, #0x20
    74e0:      	ldr	x2, [x16, #0x10]
    74e4:      	b	0x735c <_stogir.floating.validate+0x360>
    74e8:      	orr	x3, x6, xzr
    74ec:      	lsr	w3, w3, #0
    74f0:      	ubfx	x2, x2, #8, #8
    74f4:      	sxtw	x3, w3
    74f8:      	cmp	x2, x3
    74fc:      	b.ne	0x754c <_stogir.floating.validate+0x550>
    7500:      	add	x16, sp, #0x10
    7504:      	ldr	w2, [x16, #0x4]
    7508:      	add	x16, sp, #0x10
    750c:      	ldr	w3, [x16, #0x8]
    7510:      	uxtb	w16, w1
    7514:      	cmp	w16, wzr
    7518:      	b.eq	0x7494 <_stogir.floating.validate+0x498>
    751c:      	add	x16, sp, #0x10
    7520:      	ldr	w1, [x16, #0xc]
    7524:      	sxtw	x1, w1
    7528:      	b	0x7498 <_stogir.floating.validate+0x49c>
    752c:      	movz	x7, #0x0, lsl #48
    7530:      	b	0x7488 <_stogir.floating.validate+0x48c>
    7534:      	brk	#0
    7538:      	b	0x7534 <_stogir.floating.validate+0x538>
    753c:      	brk	#0
    7540:      	b	0x753c <_stogir.floating.validate+0x540>
    7544:      	mov	x19, x8
    7548:      	b	0x71d0 <_stogir.floating.validate+0x1d4>
    754c:      	mov	x19, x8
    7550:      	b	0x7344 <_stogir.floating.validate+0x348>

0000000000007554 <_stogir.types.integer?>:
    7554:      	sxtw	x0, w0
    7558:      	cmp	x0, #0x1
    755c:      	b.lt	0x7570 <_stogir.types.integer?+0x1c>
    7560:      	cmp	x0, #0xb
    7564:      	cset	w0, le
    7568:      	ubfx	x0, x0, #0, #8
    756c:      	b	0x7574 <_stogir.types.integer?+0x20>
    7570:      	movz	x0, #0x0, lsl #48
    7574:      	ret

0000000000007578 <_stogir.integer-unary.valid-type?>:
    7578:      	sxtw	x0, w0
    757c:      	cmp	x0, #0x2d
    7580:      	cset	w2, eq
    7584:      	cmp	x0, #0x1f
    7588:      	cset	w3, eq
    758c:      	cmp	x0, #0x20
    7590:      	cset	w4, eq
    7594:      	cmp	x0, #0x36
    7598:      	cset	w5, eq
    759c:      	uxtb	w16, w3
    75a0:      	cmp	w16, wzr
    75a4:      	b.ne	0x75ec <_stogir.integer-unary.valid-type?+0x74>
    75a8:      	uxtb	w16, w4
    75ac:      	cmp	w16, wzr
    75b0:      	b.ne	0x75ec <_stogir.integer-unary.valid-type?+0x74>
    75b4:      	uxtb	w16, w2
    75b8:      	cmp	w16, wzr
    75bc:      	b.ne	0x75ec <_stogir.integer-unary.valid-type?+0x74>
    75c0:      	uxtb	w16, w5
    75c4:      	cmp	w16, wzr
    75c8:      	b.ne	0x75ec <_stogir.integer-unary.valid-type?+0x74>
    75cc:      	cmp	x0, #0x37
    75d0:      	b.eq	0x75ec <_stogir.integer-unary.valid-type?+0x74>
    75d4:      	cmp	x0, #0x38
    75d8:      	b.eq	0x75ec <_stogir.integer-unary.valid-type?+0x74>
    75dc:      	cmp	x0, #0x39
    75e0:      	b.eq	0x75ec <_stogir.integer-unary.valid-type?+0x74>
    75e4:      	movz	x0, #0x0, lsl #48
    75e8:      	b	0x7624 <_stogir.integer-unary.valid-type?+0xac>
    75ec:      	sxtw	x1, w1
    75f0:      	cmp	x1, #0x1
    75f4:      	b.lt	0x7620 <_stogir.integer-unary.valid-type?+0xa8>
    75f8:      	cmp	x1, #0xb
    75fc:      	cset	w0, le
    7600:      	uxtb	w16, w0
    7604:      	cmp	w16, wzr
    7608:      	b.eq	0x7620 <_stogir.integer-unary.valid-type?+0xa8>
    760c:      	uxtb	w16, w2
    7610:      	cmp	w16, wzr
    7614:      	b.eq	0x7630 <_stogir.integer-unary.valid-type?+0xb8>
    7618:      	mov	x0, #0x1                ; =1
    761c:      	b	0x762c <_stogir.integer-unary.valid-type?+0xb4>
    7620:      	movz	x0, #0x0, lsl #48
    7624:      	ret
    7628:      	mov	x0, #0x1                ; =1
    762c:      	b	0x7624 <_stogir.integer-unary.valid-type?+0xac>
    7630:      	cmp	x1, #0x1
    7634:      	b.ne	0x7640 <_stogir.integer-unary.valid-type?+0xc8>
    7638:      	movz	x0, #0x0, lsl #48
    763c:      	b	0x762c <_stogir.integer-unary.valid-type?+0xb4>
    7640:      	cmp	x1, #0x6
    7644:      	cset	w2, eq
    7648:      	uxtb	w16, w3
    764c:      	cmp	w16, wzr
    7650:      	b.eq	0x7664 <_stogir.integer-unary.valid-type?+0xec>
    7654:      	uxtb	w16, w2
    7658:      	cmp	w16, wzr
    765c:      	cset	x0, eq
    7660:      	b	0x762c <_stogir.integer-unary.valid-type?+0xb4>
    7664:      	uxtb	w16, w4
    7668:      	cmp	w16, wzr
    766c:      	b.eq	0x7688 <_stogir.integer-unary.valid-type?+0x110>
    7670:      	cmp	x1, #0x7
    7674:      	b.lt	0x7680 <_stogir.integer-unary.valid-type?+0x108>
    7678:      	ubfx	x0, x0, #0, #8
    767c:      	b	0x7684 <_stogir.integer-unary.valid-type?+0x10c>
    7680:      	movz	x0, #0x0, lsl #48
    7684:      	b	0x762c <_stogir.integer-unary.valid-type?+0xb4>
    7688:      	uxtb	w16, w5
    768c:      	cmp	w16, wzr
    7690:      	b.eq	0x7628 <_stogir.integer-unary.valid-type?+0xb0>
    7694:      	cmp	x1, #0x3
    7698:      	b.ne	0x76b4 <_stogir.integer-unary.valid-type?+0x13c>
    769c:      	mov	x0, #0x1                ; =1
    76a0:      	b	0x76b0 <_stogir.integer-unary.valid-type?+0x138>
    76a4:      	cmp	x1, #0xb
    76a8:      	cset	w0, eq
    76ac:      	ubfx	x0, x0, #0, #8
    76b0:      	b	0x762c <_stogir.integer-unary.valid-type?+0xb4>
    76b4:      	cmp	x1, #0x4
    76b8:      	b.ne	0x76c4 <_stogir.integer-unary.valid-type?+0x14c>
    76bc:      	mov	x0, #0x1                ; =1
    76c0:      	b	0x76b0 <_stogir.integer-unary.valid-type?+0x138>
    76c4:      	cmp	x1, #0x5
    76c8:      	b.ne	0x76d4 <_stogir.integer-unary.valid-type?+0x15c>
    76cc:      	mov	x0, #0x1                ; =1
    76d0:      	b	0x76b0 <_stogir.integer-unary.valid-type?+0x138>
    76d4:      	uxtb	w16, w2
    76d8:      	cmp	w16, wzr
    76dc:      	b.eq	0x76e8 <_stogir.integer-unary.valid-type?+0x170>
    76e0:      	mov	x0, #0x1                ; =1
    76e4:      	b	0x76b0 <_stogir.integer-unary.valid-type?+0x138>
    76e8:      	cmp	x1, #0x9
    76ec:      	b.ne	0x76f8 <_stogir.integer-unary.valid-type?+0x180>
    76f0:      	mov	x0, #0x1                ; =1
    76f4:      	b	0x76b0 <_stogir.integer-unary.valid-type?+0x138>
    76f8:      	cmp	x1, #0xa
    76fc:      	b.ne	0x76a4 <_stogir.integer-unary.valid-type?+0x12c>
    7700:      	mov	x0, #0x1                ; =1
    7704:      	b	0x76b0 <_stogir.integer-unary.valid-type?+0x138>

0000000000007708 <_stogir.integer-binary.valid-type?>:
    7708:      	sxtw	x0, w0
    770c:      	cmp	x0, #0x3a
    7710:      	cset	w2, eq
    7714:      	cmp	x0, #0x3b
    7718:      	cset	w3, eq
    771c:      	cmp	x0, #0x1a
    7720:      	b.lt	0x7774 <_stogir.integer-binary.valid-type?+0x6c>
    7724:      	cmp	x0, #0x1e
    7728:      	b.gt	0x7774 <_stogir.integer-binary.valid-type?+0x6c>
    772c:      	sxtw	x1, w1
    7730:      	cmp	x1, #0x1
    7734:      	b.lt	0x77a4 <_stogir.integer-binary.valid-type?+0x9c>
    7738:      	cmp	x1, #0xb
    773c:      	b.gt	0x77a4 <_stogir.integer-binary.valid-type?+0x9c>
    7740:      	cmp	x1, #0x1
    7744:      	b.ne	0x77ac <_stogir.integer-binary.valid-type?+0xa4>
    7748:      	cmp	x0, #0x2e
    774c:      	b.eq	0x77b4 <_stogir.integer-binary.valid-type?+0xac>
    7750:      	cmp	x0, #0x2f
    7754:      	b.eq	0x77b4 <_stogir.integer-binary.valid-type?+0xac>
    7758:      	cmp	x0, #0x30
    775c:      	b.eq	0x77b4 <_stogir.integer-binary.valid-type?+0xac>
    7760:      	uxtb	w16, w2
    7764:      	cmp	w16, wzr
    7768:      	b.eq	0x77bc <_stogir.integer-binary.valid-type?+0xb4>
    776c:      	mov	x0, #0x1                ; =1
    7770:      	b	0x77c4 <_stogir.integer-binary.valid-type?+0xbc>
    7774:      	cmp	x0, #0x2e
    7778:      	b.lt	0x7784 <_stogir.integer-binary.valid-type?+0x7c>
    777c:      	cmp	x0, #0x35
    7780:      	b.le	0x772c <_stogir.integer-binary.valid-type?+0x24>
    7784:      	uxtb	w16, w2
    7788:      	cmp	w16, wzr
    778c:      	b.ne	0x772c <_stogir.integer-binary.valid-type?+0x24>
    7790:      	uxtb	w16, w3
    7794:      	cmp	w16, wzr
    7798:      	b.ne	0x772c <_stogir.integer-binary.valid-type?+0x24>
    779c:      	movz	x0, #0x0, lsl #48
    77a0:      	b	0x77a8 <_stogir.integer-binary.valid-type?+0xa0>
    77a4:      	movz	x0, #0x0, lsl #48
    77a8:      	ret
    77ac:      	mov	x0, #0x1                ; =1
    77b0:      	b	0x77a8 <_stogir.integer-binary.valid-type?+0xa0>
    77b4:      	mov	x0, #0x1                ; =1
    77b8:      	b	0x77b0 <_stogir.integer-binary.valid-type?+0xa8>
    77bc:      	ubfx	x3, x3, #0, #8
    77c0:      	mov	x0, x3
    77c4:      	b	0x77b8 <_stogir.integer-binary.valid-type?+0xb0>

00000000000077c8 <_coil.core.Len$slice$len__u8>:
    77c8:      	mov	x0, x1
    77cc:      	ret

00000000000077d0 <_inherent$slice$data__u8>:
    77d0:      	ret

00000000000077d4 <_coil.mem.eql__u8>:
    77d4:      	sub	sp, sp, #0x10
    77d8:      	str	x29, [sp]
    77dc:      	str	x30, [sp, #0x8]
    77e0:      	mov	x29, sp
    77e4:      	cmp	x2, #0x0
    77e8:      	b.ne	0x77f4 <_coil.mem.eql__u8+0x20>
    77ec:      	mov	x0, #0x1                ; =1
    77f0:      	b	0x7810 <_coil.mem.eql__u8+0x3c>
    77f4:      	lsr	x2, x2, #0
    77f8:      	bl	0x77f8 <_coil.mem.eql__u8+0x24>
		00000000000077f8:  ARM64_RELOC_BRANCH26	_memcmp
    77fc:      	lsr	w0, w0, #0
    7800:      	sxtw	x0, w0
    7804:      	cmp	x0, #0x0
    7808:      	cset	w0, eq
    780c:      	ubfx	x0, x0, #0, #8
    7810:      	ldr	x29, [sp]
    7814:      	ldr	x30, [sp, #0x8]
    7818:      	add	sp, sp, #0x10
    781c:      	ret

0000000000007820 <_stogir.opcode.count>:
    7820:      	mov	x0, #0x83               ; =131
    7824:      	ret

0000000000007828 <_stogir.types.valid-scalar?>:
    7828:      	sxtw	x0, w0
    782c:      	cmp	x0, #0x0
    7830:      	b.lt	0x7844 <_stogir.types.valid-scalar?+0x1c>
    7834:      	cmp	x0, #0xd
    7838:      	cset	w0, le
    783c:      	ubfx	x0, x0, #0, #8
    7840:      	b	0x7848 <_stogir.types.valid-scalar?+0x20>
    7844:      	movz	x0, #0x0, lsl #48
    7848:      	ret

000000000000784c <_stogir.types.vector?>:
    784c:      	sxtw	x0, w0
    7850:      	cmp	x0, #0xf
    7854:      	b.le	0x7890 <_stogir.types.vector?+0x44>
    7858:      	cmp	x0, #0x80
    785c:      	b.ge	0x78a0 <_stogir.types.vector?+0x54>
    7860:      	and	x1, x0, #0xf
    7864:      	lsr	w1, w1, #0
    7868:      	sxtw	x1, w1
    786c:      	cmp	x1, #0x1
    7870:      	b.lt	0x7898 <_stogir.types.vector?+0x4c>
    7874:      	and	x0, x0, #0xf
    7878:      	lsr	w0, w0, #0
    787c:      	sxtw	x0, w0
    7880:      	cmp	x0, #0xd
    7884:      	cset	w0, le
    7888:      	ubfx	x0, x0, #0, #8
    788c:      	b	0x789c <_stogir.types.vector?+0x50>
    7890:      	movz	x0, #0x0, lsl #48
    7894:      	b	0x789c <_stogir.types.vector?+0x50>
    7898:      	movz	x0, #0x0, lsl #48
    789c:      	ret
    78a0:      	movz	x0, #0x0, lsl #48
    78a4:      	b	0x789c <_stogir.types.vector?+0x50>

00000000000078a8 <_coil.core.Get$slice$get__i8>:
    78a8:      	lsr	x1, x2, #0
    78ac:      	add	x0, x1, x0
    78b0:      	ldrsb	w0, [x0]
    78b4:      	sxtb	x0, w0
    78b8:      	ret

00000000000078bc <_stogir.opcode.metadata>:
    78bc:      	sub	sp, sp, #0x10
    78c0:      	mov	x0, sp
    78c4:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x4>
		00000000000078c4:  ARM64_RELOC_PAGE21	l_stogir.409
    78c8:      	ldr	x16, [x16]
		00000000000078c8:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    78cc:      	orr	x1, x16, xzr
    78d0:      	str	x1, [x0]
    78d4:      	mov	x17, #0x83              ; =131
    78d8:      	str	x17, [x0, #0x8]
    78dc:      	ldr	x0, [sp]
    78e0:      	ldr	x1, [sp, #0x8]
    78e4:      	add	sp, sp, #0x10
    78e8:      	ret

00000000000078ec <_coil.core.Get$slice$get__u32>:
    78ec:      	lsl	x1, x2, #2
    78f0:      	add	x0, x1, x0
    78f4:      	ldr	w0, [x0]
    78f8:      	ret

00000000000078fc <_stogir.opcode.operand-code-word>:
    78fc:      	sxtw	x1, w1
    7900:      	cmp	x1, #0x0
    7904:      	b.le	0x7918 <_stogir.opcode.operand-code-word+0x1c>
    7908:      	cmp	x1, #0x4
    790c:      	b.le	0x7920 <_stogir.opcode.operand-code-word+0x24>
    7910:      	mov	x1, #0x4                ; =4
    7914:      	b	0x792c <_stogir.opcode.operand-code-word+0x30>
    7918:      	movz	x0, #0x0, lsl #48
    791c:      	b	0x794c <_stogir.opcode.operand-code-word+0x50>
    7920:      	sub	x1, x1, #0x1
    7924:      	lsr	w1, w1, #0
    7928:      	sxtw	x1, w1
    792c:      	ubfx	x0, x0, #0, #32
    7930:      	lsl	x1, x1, #2
    7934:      	lsr	w1, w1, #0
    7938:      	ubfx	x1, x1, #0, #32
    793c:      	lsr	x0, x0, x1
    7940:      	lsr	w0, w0, #0
    7944:      	and	x0, x0, #0xf
    7948:      	lsr	w0, w0, #0
    794c:      	ret

0000000000007950 <_inherent$coil.arraylist.ArrayList$at__stogir.node.Node>:
    7950:      	lsl	x1, x1, #4
    7954:      	ldr	x0, [x0]
    7958:      	add	x0, x1, x0
    795c:      	ret

0000000000007960 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.strings.Entry>:
    7960:      	ldr	x0, [x0, #0x8]
    7964:      	ret

0000000000007968 <_coil.core.Len$coil.arraylist.ArrayList$len__u8>:
    7968:      	ldr	x0, [x0, #0x8]
    796c:      	ret

0000000000007970 <_inherent$coil.arraylist.ArrayList$slice__u8>:
    7970:      	sub	sp, sp, #0x10
    7974:      	mov	x1, sp
    7978:      	ldr	x2, [x0]
    797c:      	ldr	x0, [x0, #0x8]
    7980:      	str	x2, [x1]
    7984:      	str	x0, [x1, #0x8]
    7988:      	ldr	x0, [sp]
    798c:      	ldr	x1, [sp, #0x8]
    7990:      	add	sp, sp, #0x10
    7994:      	ret

0000000000007998 <_coil.slice.subslice__u8>:
    7998:      	sub	sp, sp, #0x10
    799c:      	mov	x1, sp
    79a0:      	lsr	x4, x2, #0
    79a4:      	sub	x2, x3, x2
    79a8:      	add	x0, x4, x0
    79ac:      	str	x0, [x1]
    79b0:      	str	x2, [x1, #0x8]
    79b4:      	ldr	x0, [sp]
    79b8:      	ldr	x1, [sp, #0x8]
    79bc:      	add	sp, sp, #0x10
    79c0:      	ret

00000000000079c4 <_stogir.floating.operation?>:
    79c4:      	sxtw	x0, w0
    79c8:      	cmp	x0, #0xe
    79cc:      	b.lt	0x79e0 <_stogir.floating.operation?+0x1c>
    79d0:      	cmp	x0, #0x19
    79d4:      	b.gt	0x79e0 <_stogir.floating.operation?+0x1c>
    79d8:      	mov	x0, #0x1                ; =1
    79dc:      	b	0x7a0c <_stogir.floating.operation?+0x48>
    79e0:      	cmp	x0, #0x1f
    79e4:      	b.eq	0x7a08 <_stogir.floating.operation?+0x44>
    79e8:      	cmp	x0, #0x20
    79ec:      	b.eq	0x7a08 <_stogir.floating.operation?+0x44>
    79f0:      	cmp	x0, #0x1a
    79f4:      	b.lt	0x7a20 <_stogir.floating.operation?+0x5c>
    79f8:      	cmp	x0, #0x1d
    79fc:      	b.gt	0x7a20 <_stogir.floating.operation?+0x5c>
    7a00:      	mov	x0, #0x1                ; =1
    7a04:      	b	0x7a1c <_stogir.floating.operation?+0x58>
    7a08:      	mov	x0, #0x1                ; =1
    7a0c:      	ret
    7a10:      	cmp	x0, #0x3b
    7a14:      	cset	w0, eq
    7a18:      	ubfx	x0, x0, #0, #8
    7a1c:      	b	0x7a0c <_stogir.floating.operation?+0x48>
    7a20:      	cmp	x0, #0x3a
    7a24:      	b.ne	0x7a10 <_stogir.floating.operation?+0x4c>
    7a28:      	mov	x0, #0x1                ; =1
    7a2c:      	b	0x7a1c <_stogir.floating.operation?+0x58>

0000000000007a30 <_stogir.types.floating?>:
    7a30:      	sxtw	x0, w0
    7a34:      	cmp	x0, #0xc
    7a38:      	b.ne	0x7a44 <_stogir.types.floating?+0x14>
    7a3c:      	mov	x0, #0x1                ; =1
    7a40:      	b	0x7a50 <_stogir.types.floating?+0x20>
    7a44:      	cmp	x0, #0xd
    7a48:      	cset	w0, eq
    7a4c:      	ubfx	x0, x0, #0, #8
    7a50:      	ret

0000000000007a54 <_stogir.vector-lanes.validate>:
    7a54:      	sub	sp, sp, #0x50
    7a58:      	str	x29, [sp]
    7a5c:      	str	x30, [sp, #0x8]
    7a60:      	mov	x29, sp
    7a64:      	str	x19, [sp, #0x40]
    7a68:      	sxtw	x1, w1
    7a6c:      	lsl	x3, x1, #2
    7a70:      	cmp	x1, #0x0
    7a74:      	cset	w4, gt
    7a78:      	movz	x16, #0x0, lsl #48
    7a7c:      	sub	x5, x16, x1
    7a80:      	sub	x6, x5, #0x1
    7a84:      	uxtb	w16, w4
    7a88:      	cmp	w16, wzr
    7a8c:      	b.eq	0x7acc <_stogir.vector-lanes.validate+0x78>
    7a90:      	ldr	x5, [x0, #0x8]
    7a94:      	cmp	x1, x5
    7a98:      	b.ge	0x7b20 <_stogir.vector-lanes.validate+0xcc>
    7a9c:      	add	x5, x0, #0x78
    7aa0:      	ldr	x5, [x5, #0x8]
    7aa4:      	cmp	x1, x5
    7aa8:      	b.ge	0x7c44 <_stogir.vector-lanes.validate+0x1f0>
    7aac:      	ldr	x5, [x0, #0x78]
    7ab0:      	add	x5, x3, x5
    7ab4:      	ldr	w5, [x5]
    7ab8:      	sxtw	x5, w5
    7abc:      	cmp	x5, #0x0
    7ac0:      	cset	w5, ge
    7ac4:      	ubfx	x5, x5, #0, #8
    7ac8:      	b	0x7c48 <_stogir.vector-lanes.validate+0x1f4>
    7acc:      	cmp	x1, #0x0
    7ad0:      	b.ge	0x7b28 <_stogir.vector-lanes.validate+0xd4>
    7ad4:      	add	x7, x0, #0x28
    7ad8:      	add	x9, x0, #0x50
    7adc:      	ldr	x7, [x7, #0x8]
    7ae0:      	ldr	x9, [x9, #0x8]
    7ae4:      	cmp	x7, x9
    7ae8:      	b.ne	0x7b18 <_stogir.vector-lanes.validate+0xc4>
    7aec:      	cmp	x5, x7
    7af0:      	b.gt	0x7c88 <_stogir.vector-lanes.validate+0x234>
    7af4:      	lsl	x5, x6, #2
    7af8:      	ldr	x7, [x0, #0x50]
    7afc:      	add	x5, x5, x7
    7b00:      	ldr	w5, [x5]
    7b04:      	sxtw	x5, w5
    7b08:      	cmp	x5, #0x0
    7b0c:      	cset	w5, gt
    7b10:      	ubfx	x5, x5, #0, #8
    7b14:      	b	0x7c8c <_stogir.vector-lanes.validate+0x238>
    7b18:      	movz	x5, #0x0, lsl #48
    7b1c:      	b	0x7b2c <_stogir.vector-lanes.validate+0xd8>
    7b20:      	movz	x5, #0x0, lsl #48
    7b24:      	b	0x7b2c <_stogir.vector-lanes.validate+0xd8>
    7b28:      	movz	x5, #0x0, lsl #48
    7b2c:      	cmp	x5, #0x0
    7b30:      	b.eq	0x7b94 <_stogir.vector-lanes.validate+0x140>
    7b34:      	uxtb	w16, w4
    7b38:      	cmp	w16, wzr
    7b3c:      	b.eq	0x7b64 <_stogir.vector-lanes.validate+0x110>
    7b40:      	lsl	x4, x1, #4
    7b44:      	ldr	x5, [x0]
    7b48:      	add	x4, x4, x5
    7b4c:      	ldr	x5, [x4]
    7b50:      	ldr	x4, [x4, #0x8]
    7b54:      	fmov	d31, x4
    7b58:      	mov	x4, x5
    7b5c:      	fmov	x5, d31
    7b60:      	b	0x7b84 <_stogir.vector-lanes.validate+0x130>
    7b64:      	lsl	x4, x6, #4
    7b68:      	ldr	x5, [x0, #0x28]
    7b6c:      	add	x4, x4, x5
    7b70:      	ldr	x5, [x4]
    7b74:      	ldr	x4, [x4, #0x8]
    7b78:      	fmov	d31, x4
    7b7c:      	mov	x4, x5
    7b80:      	fmov	x5, d31
    7b84:      	mov	x6, x5
    7b88:      	mov	x5, x4
    7b8c:      	mov	x4, #0x1                ; =1
    7b90:      	b	0x7ba0 <_stogir.vector-lanes.validate+0x14c>
    7b94:      	movz	x4, #0x0, lsl #48
    7b98:      	movz	x5, #0x0, lsl #48
    7b9c:      	movz	x6, #0x0, lsl #48
    7ba0:      	lsr	w4, w4, #0
    7ba4:      	lsr	x16, x4, #0
    7ba8:      	cmp	x16, #0x1
    7bac:      	b.eq	0x7bc8 <_stogir.vector-lanes.validate+0x174>
    7bb0:      	b.lo	0x7bb8 <_stogir.vector-lanes.validate+0x164>
    7bb4:      	b	0x7bcc <_stogir.vector-lanes.validate+0x178>
    7bb8:      	cmp	x16, #0x0
    7bbc:      	b.eq	0x7bc4 <_stogir.vector-lanes.validate+0x170>
    7bc0:      	b	0x7bcc <_stogir.vector-lanes.validate+0x178>
    7bc4:      	b	0x7bd0 <_stogir.vector-lanes.validate+0x17c>
    7bc8:      	b	0x7bf0 <_stogir.vector-lanes.validate+0x19c>
    7bcc:      	b	0x7d6c <_stogir.vector-lanes.validate+0x318>
    7bd0:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x4>
		0000000000007bd0:  ARM64_RELOC_PAGE21	l_stogir.410
    7bd4:      	ldr	x16, [x16]
		0000000000007bd4:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    7bd8:      	orr	x0, x16, xzr
    7bdc:      	mov	x19, x8
    7be0:      	mov	x1, x0
    7be4:      	mov	x0, #0x1                ; =1
    7be8:      	mov	x2, #0x1f               ; =31
    7bec:      	b	0x7c24 <_stogir.vector-lanes.validate+0x1d0>
    7bf0:      	add	x16, sp, #0x10
    7bf4:      	str	x5, [x16]
    7bf8:      	add	x16, sp, #0x10
    7bfc:      	str	x6, [x16, #0x8]
    7c00:      	cmp	x1, #0x0
    7c04:      	b.gt	0x7c4c <_stogir.vector-lanes.validate+0x1f8>
    7c08:      	mov	x19, x8
    7c0c:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x4>
		0000000000007c0c:  ARM64_RELOC_PAGE21	l_stogir.411
    7c10:      	ldr	x16, [x16]
		0000000000007c10:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    7c14:      	orr	x0, x16, xzr
    7c18:      	mov	x1, x0
    7c1c:      	mov	x0, #0x1                ; =1
    7c20:      	mov	x2, #0x25               ; =37
    7c24:      	str	x0, [x19]
    7c28:      	str	x1, [x19, #0x8]
    7c2c:      	str	x2, [x19, #0x10]
    7c30:      	ldr	x19, [sp, #0x40]
    7c34:      	ldr	x29, [sp]
    7c38:      	ldr	x30, [sp, #0x8]
    7c3c:      	add	sp, sp, #0x50
    7c40:      	ret
    7c44:      	movz	x5, #0x0, lsl #48
    7c48:      	b	0x7b24 <_stogir.vector-lanes.validate+0xd0>
    7c4c:      	uxtb	w5, w5
    7c50:      	orr	x1, x5, xzr
    7c54:      	cmp	x1, #0x3d
    7c58:      	b.lt	0x7d74 <_stogir.vector-lanes.validate+0x320>
    7c5c:      	cmp	x1, #0x3f
    7c60:      	b.gt	0x7d7c <_stogir.vector-lanes.validate+0x328>
    7c64:      	cmp	x1, #0x3e
    7c68:      	cset	w4, eq
    7c6c:      	ldr	x6, [x0, #0x78]
    7c70:      	add	x3, x3, x6
    7c74:      	ldr	w3, [x3]
    7c78:      	cmp	x1, #0x3d
    7c7c:      	b.ne	0x7cfc <_stogir.vector-lanes.validate+0x2a8>
    7c80:      	mov	x6, #0x2                ; =2
    7c84:      	b	0x7d10 <_stogir.vector-lanes.validate+0x2bc>
    7c88:      	movz	x5, #0x0, lsl #48
    7c8c:      	b	0x7b1c <_stogir.vector-lanes.validate+0xc8>
    7c90:      	movz	x4, #0x0, lsl #48
    7c94:      	lsr	w2, w2, #0
    7c98:      	lsr	w6, w6, #0
    7c9c:      	lsr	w1, w1, #0
    7ca0:      	lsr	w5, w5, #0
    7ca4:      	lsr	w4, w4, #0
    7ca8:      	ubfx	x3, x3, #8, #8
    7cac:      	lsr	w3, w3, #0
    7cb0:      	mov	x19, x8
    7cb4:      	add	x8, sp, #0x20
    7cb8:      	fmov	s31, w1
    7cbc:      	mov	w1, w5
    7cc0:      	fmov	w5, s31
    7cc4:      	fmov	s31, w2
    7cc8:      	mov	w2, w3
    7ccc:      	fmov	w3, s31
    7cd0:      	fmov	s31, w4
    7cd4:      	mov	w4, w6
    7cd8:      	fmov	w6, s31
    7cdc:      	bl	0x7cdc <_stogir.vector-lanes.validate+0x288>
		0000000000007cdc:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    7ce0:      	add	x16, sp, #0x20
    7ce4:      	ldr	x0, [x16]
    7ce8:      	add	x16, sp, #0x20
    7cec:      	ldr	x1, [x16, #0x8]
    7cf0:      	add	x16, sp, #0x20
    7cf4:      	ldr	x2, [x16, #0x10]
    7cf8:      	b	0x7c24 <_stogir.vector-lanes.validate+0x1d0>
    7cfc:      	uxtb	w16, w4
    7d00:      	cmp	w16, wzr
    7d04:      	mov	x16, #0x3               ; =3
    7d08:      	mov	x17, #0x1               ; =1
    7d0c:      	csel	x6, x16, x17, ne
    7d10:      	sxtw	x3, w3
    7d14:      	lsr	w6, w6, #0
    7d18:      	sxtw	x6, w6
    7d1c:      	cmp	x3, x6
    7d20:      	b.ne	0x7d84 <_stogir.vector-lanes.validate+0x330>
    7d24:      	add	x16, sp, #0x10
    7d28:      	ldr	w3, [x16]
    7d2c:      	add	x16, sp, #0x10
    7d30:      	ldr	w6, [x16, #0x4]
    7d34:      	cmp	x1, #0x3f
    7d38:      	b.ne	0x7d44 <_stogir.vector-lanes.validate+0x2f0>
    7d3c:      	movz	x1, #0x0, lsl #48
    7d40:      	b	0x7d50 <_stogir.vector-lanes.validate+0x2fc>
    7d44:      	add	x16, sp, #0x10
    7d48:      	ldr	w1, [x16, #0x8]
    7d4c:      	sxtw	x1, w1
    7d50:      	uxtb	w16, w4
    7d54:      	cmp	w16, wzr
    7d58:      	b.eq	0x7c90 <_stogir.vector-lanes.validate+0x23c>
    7d5c:      	add	x16, sp, #0x10
    7d60:      	ldr	w4, [x16, #0xc]
    7d64:      	sxtw	x4, w4
    7d68:      	b	0x7c94 <_stogir.vector-lanes.validate+0x240>
    7d6c:      	brk	#0
    7d70:      	b	0x7d6c <_stogir.vector-lanes.validate+0x318>
    7d74:      	mov	x19, x8
    7d78:      	b	0x7c0c <_stogir.vector-lanes.validate+0x1b8>
    7d7c:      	mov	x19, x8
    7d80:      	b	0x7c0c <_stogir.vector-lanes.validate+0x1b8>
    7d84:      	mov	x19, x8
    7d88:      	b	0x7c0c <_stogir.vector-lanes.validate+0x1b8>

0000000000007d8c <_stogir.vector-comparison.node?>:
    7d8c:      	sxtw	x1, w1
    7d90:      	cmp	x1, #0x0
    7d94:      	cset	w2, gt
    7d98:      	movz	x16, #0x0, lsl #48
    7d9c:      	sub	x3, x16, x1
    7da0:      	sub	x4, x3, #0x1
    7da4:      	uxtb	w16, w2
    7da8:      	cmp	w16, wzr
    7dac:      	b.eq	0x7df0 <_stogir.vector-comparison.node?+0x64>
    7db0:      	ldr	x3, [x0, #0x8]
    7db4:      	cmp	x1, x3
    7db8:      	b.ge	0x7e44 <_stogir.vector-comparison.node?+0xb8>
    7dbc:      	add	x3, x0, #0x78
    7dc0:      	ldr	x3, [x3, #0x8]
    7dc4:      	cmp	x1, x3
    7dc8:      	b.ge	0x7f2c <_stogir.vector-comparison.node?+0x1a0>
    7dcc:      	lsl	x3, x1, #2
    7dd0:      	ldr	x5, [x0, #0x78]
    7dd4:      	add	x3, x3, x5
    7dd8:      	ldr	w3, [x3]
    7ddc:      	sxtw	x3, w3
    7de0:      	cmp	x3, #0x0
    7de4:      	cset	w3, ge
    7de8:      	ubfx	x3, x3, #0, #8
    7dec:      	b	0x7f30 <_stogir.vector-comparison.node?+0x1a4>
    7df0:      	cmp	x1, #0x0
    7df4:      	b.ge	0x7e4c <_stogir.vector-comparison.node?+0xc0>
    7df8:      	add	x5, x0, #0x28
    7dfc:      	add	x6, x0, #0x50
    7e00:      	ldr	x5, [x5, #0x8]
    7e04:      	ldr	x6, [x6, #0x8]
    7e08:      	cmp	x5, x6
    7e0c:      	b.ne	0x7e3c <_stogir.vector-comparison.node?+0xb0>
    7e10:      	cmp	x3, x5
    7e14:      	b.gt	0x7f34 <_stogir.vector-comparison.node?+0x1a8>
    7e18:      	lsl	x3, x4, #2
    7e1c:      	ldr	x5, [x0, #0x50]
    7e20:      	add	x3, x3, x5
    7e24:      	ldr	w3, [x3]
    7e28:      	sxtw	x3, w3
    7e2c:      	cmp	x3, #0x0
    7e30:      	cset	w3, gt
    7e34:      	ubfx	x3, x3, #0, #8
    7e38:      	b	0x7f38 <_stogir.vector-comparison.node?+0x1ac>
    7e3c:      	movz	x3, #0x0, lsl #48
    7e40:      	b	0x7e50 <_stogir.vector-comparison.node?+0xc4>
    7e44:      	movz	x3, #0x0, lsl #48
    7e48:      	b	0x7e50 <_stogir.vector-comparison.node?+0xc4>
    7e4c:      	movz	x3, #0x0, lsl #48
    7e50:      	cmp	x3, #0x0
    7e54:      	b.eq	0x7e94 <_stogir.vector-comparison.node?+0x108>
    7e58:      	uxtb	w16, w2
    7e5c:      	cmp	w16, wzr
    7e60:      	b.eq	0x7e78 <_stogir.vector-comparison.node?+0xec>
    7e64:      	lsl	x1, x1, #4
    7e68:      	ldr	x0, [x0]
    7e6c:      	add	x0, x1, x0
    7e70:      	ldr	x0, [x0]
    7e74:      	b	0x7e88 <_stogir.vector-comparison.node?+0xfc>
    7e78:      	lsl	x1, x4, #4
    7e7c:      	ldr	x0, [x0, #0x28]
    7e80:      	add	x0, x1, x0
    7e84:      	ldr	x0, [x0]
    7e88:      	mov	x1, x0
    7e8c:      	mov	x0, #0x1                ; =1
    7e90:      	b	0x7e9c <_stogir.vector-comparison.node?+0x110>
    7e94:      	movz	x0, #0x0, lsl #48
    7e98:      	movz	x1, #0x0, lsl #48
    7e9c:      	lsr	w0, w0, #0
    7ea0:      	lsr	x16, x0, #0
    7ea4:      	cmp	x16, #0x1
    7ea8:      	b.eq	0x7ec4 <_stogir.vector-comparison.node?+0x138>
    7eac:      	b.lo	0x7eb4 <_stogir.vector-comparison.node?+0x128>
    7eb0:      	b	0x7ec8 <_stogir.vector-comparison.node?+0x13c>
    7eb4:      	cmp	x16, #0x0
    7eb8:      	b.eq	0x7ec0 <_stogir.vector-comparison.node?+0x134>
    7ebc:      	b	0x7ec8 <_stogir.vector-comparison.node?+0x13c>
    7ec0:      	b	0x7ecc <_stogir.vector-comparison.node?+0x140>
    7ec4:      	b	0x7edc <_stogir.vector-comparison.node?+0x150>
    7ec8:      	b	0x7f54 <_stogir.vector-comparison.node?+0x1c8>
    7ecc:      	movz	x0, #0x0, lsl #48
    7ed0:      	b	0x7ed8 <_stogir.vector-comparison.node?+0x14c>
    7ed4:      	movz	x0, #0x0, lsl #48
    7ed8:      	ret
    7edc:      	uxtb	w0, w1
    7ee0:      	cmp	x0, #0xe
    7ee4:      	b.lt	0x7ed4 <_stogir.vector-comparison.node?+0x148>
    7ee8:      	cmp	x0, #0x19
    7eec:      	b.gt	0x7ed4 <_stogir.vector-comparison.node?+0x148>
    7ef0:      	lsr	w1, w1, #0
    7ef4:      	ubfx	x0, x1, #8, #8
    7ef8:      	cmp	x0, #0xf
    7efc:      	b.le	0x7f3c <_stogir.vector-comparison.node?+0x1b0>
    7f00:      	cmp	x0, #0x80
    7f04:      	b.ge	0x7f44 <_stogir.vector-comparison.node?+0x1b8>
    7f08:      	and	x0, x0, #0xf
    7f0c:      	lsr	w0, w0, #0
    7f10:      	sxtw	x0, w0
    7f14:      	cmp	x0, #0x1
    7f18:      	b.lt	0x7f4c <_stogir.vector-comparison.node?+0x1c0>
    7f1c:      	cmp	x0, #0xd
    7f20:      	cset	w0, le
    7f24:      	ubfx	x0, x0, #0, #8
    7f28:      	b	0x7f50 <_stogir.vector-comparison.node?+0x1c4>
    7f2c:      	movz	x3, #0x0, lsl #48
    7f30:      	b	0x7e48 <_stogir.vector-comparison.node?+0xbc>
    7f34:      	movz	x3, #0x0, lsl #48
    7f38:      	b	0x7e40 <_stogir.vector-comparison.node?+0xb4>
    7f3c:      	movz	x0, #0x0, lsl #48
    7f40:      	b	0x7ed8 <_stogir.vector-comparison.node?+0x14c>
    7f44:      	movz	x0, #0x0, lsl #48
    7f48:      	b	0x7f40 <_stogir.vector-comparison.node?+0x1b4>
    7f4c:      	movz	x0, #0x0, lsl #48
    7f50:      	b	0x7f48 <_stogir.vector-comparison.node?+0x1bc>
    7f54:      	brk	#0
    7f58:      	b	0x7f54 <_stogir.vector-comparison.node?+0x1c8>

0000000000007f5c <_stogir.vector-comparison.validate>:
    7f5c:      	sub	sp, sp, #0x50
    7f60:      	str	x29, [sp]
    7f64:      	str	x30, [sp, #0x8]
    7f68:      	mov	x29, sp
    7f6c:      	str	x19, [sp, #0x40]
    7f70:      	sxtw	x1, w1
    7f74:      	lsl	x3, x1, #2
    7f78:      	cmp	x1, #0x0
    7f7c:      	cset	w4, gt
    7f80:      	movz	x16, #0x0, lsl #48
    7f84:      	sub	x5, x16, x1
    7f88:      	sub	x6, x5, #0x1
    7f8c:      	uxtb	w16, w4
    7f90:      	cmp	w16, wzr
    7f94:      	b.eq	0x7fd4 <_stogir.vector-comparison.validate+0x78>
    7f98:      	ldr	x5, [x0, #0x8]
    7f9c:      	cmp	x1, x5
    7fa0:      	b.ge	0x8028 <_stogir.vector-comparison.validate+0xcc>
    7fa4:      	add	x5, x0, #0x78
    7fa8:      	ldr	x5, [x5, #0x8]
    7fac:      	cmp	x1, x5
    7fb0:      	b.ge	0x814c <_stogir.vector-comparison.validate+0x1f0>
    7fb4:      	ldr	x5, [x0, #0x78]
    7fb8:      	add	x5, x3, x5
    7fbc:      	ldr	w5, [x5]
    7fc0:      	sxtw	x5, w5
    7fc4:      	cmp	x5, #0x0
    7fc8:      	cset	w5, ge
    7fcc:      	ubfx	x5, x5, #0, #8
    7fd0:      	b	0x8150 <_stogir.vector-comparison.validate+0x1f4>
    7fd4:      	cmp	x1, #0x0
    7fd8:      	b.ge	0x8030 <_stogir.vector-comparison.validate+0xd4>
    7fdc:      	add	x7, x0, #0x28
    7fe0:      	add	x9, x0, #0x50
    7fe4:      	ldr	x7, [x7, #0x8]
    7fe8:      	ldr	x9, [x9, #0x8]
    7fec:      	cmp	x7, x9
    7ff0:      	b.ne	0x8020 <_stogir.vector-comparison.validate+0xc4>
    7ff4:      	cmp	x5, x7
    7ff8:      	b.gt	0x81a0 <_stogir.vector-comparison.validate+0x244>
    7ffc:      	lsl	x5, x6, #2
    8000:      	ldr	x7, [x0, #0x50]
    8004:      	add	x5, x5, x7
    8008:      	ldr	w5, [x5]
    800c:      	sxtw	x5, w5
    8010:      	cmp	x5, #0x0
    8014:      	cset	w5, gt
    8018:      	ubfx	x5, x5, #0, #8
    801c:      	b	0x81a4 <_stogir.vector-comparison.validate+0x248>
    8020:      	movz	x5, #0x0, lsl #48
    8024:      	b	0x8034 <_stogir.vector-comparison.validate+0xd8>
    8028:      	movz	x5, #0x0, lsl #48
    802c:      	b	0x8034 <_stogir.vector-comparison.validate+0xd8>
    8030:      	movz	x5, #0x0, lsl #48
    8034:      	lsl	x7, x1, #4
    8038:      	cmp	x5, #0x0
    803c:      	b.eq	0x809c <_stogir.vector-comparison.validate+0x140>
    8040:      	uxtb	w16, w4
    8044:      	cmp	w16, wzr
    8048:      	b.eq	0x806c <_stogir.vector-comparison.validate+0x110>
    804c:      	ldr	x4, [x0]
    8050:      	add	x4, x7, x4
    8054:      	ldr	x5, [x4]
    8058:      	ldr	x4, [x4, #0x8]
    805c:      	fmov	d31, x4
    8060:      	mov	x4, x5
    8064:      	fmov	x5, d31
    8068:      	b	0x808c <_stogir.vector-comparison.validate+0x130>
    806c:      	lsl	x4, x6, #4
    8070:      	ldr	x5, [x0, #0x28]
    8074:      	add	x4, x4, x5
    8078:      	ldr	x5, [x4]
    807c:      	ldr	x4, [x4, #0x8]
    8080:      	fmov	d31, x4
    8084:      	mov	x4, x5
    8088:      	fmov	x5, d31
    808c:      	mov	x6, x5
    8090:      	mov	x5, x4
    8094:      	mov	x4, #0x1                ; =1
    8098:      	b	0x80a8 <_stogir.vector-comparison.validate+0x14c>
    809c:      	movz	x4, #0x0, lsl #48
    80a0:      	movz	x5, #0x0, lsl #48
    80a4:      	movz	x6, #0x0, lsl #48
    80a8:      	lsr	w4, w4, #0
    80ac:      	lsr	x16, x4, #0
    80b0:      	cmp	x16, #0x1
    80b4:      	b.eq	0x80d0 <_stogir.vector-comparison.validate+0x174>
    80b8:      	b.lo	0x80c0 <_stogir.vector-comparison.validate+0x164>
    80bc:      	b	0x80d4 <_stogir.vector-comparison.validate+0x178>
    80c0:      	cmp	x16, #0x0
    80c4:      	b.eq	0x80cc <_stogir.vector-comparison.validate+0x170>
    80c8:      	b	0x80d4 <_stogir.vector-comparison.validate+0x178>
    80cc:      	b	0x80d8 <_stogir.vector-comparison.validate+0x17c>
    80d0:      	b	0x8114 <_stogir.vector-comparison.validate+0x1b8>
    80d4:      	b	0x82b4 <_stogir.vector-comparison.validate+0x358>
    80d8:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		00000000000080d8:  ARM64_RELOC_PAGE21	l_stogir.412
    80dc:      	ldr	x16, [x16]
		00000000000080dc:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    80e0:      	orr	x0, x16, xzr
    80e4:      	mov	x19, x8
    80e8:      	mov	x1, x0
    80ec:      	mov	x0, #0x1                ; =1
    80f0:      	mov	x2, #0x25               ; =37
    80f4:      	str	x0, [x19]
    80f8:      	str	x1, [x19, #0x8]
    80fc:      	str	x2, [x19, #0x10]
    8100:      	ldr	x19, [sp, #0x40]
    8104:      	ldr	x29, [sp]
    8108:      	ldr	x30, [sp, #0x8]
    810c:      	add	sp, sp, #0x50
    8110:      	ret
    8114:      	add	x16, sp, #0x10
    8118:      	str	x5, [x16]
    811c:      	add	x16, sp, #0x10
    8120:      	str	x6, [x16, #0x8]
    8124:      	cmp	x1, #0x0
    8128:      	b.gt	0x8154 <_stogir.vector-comparison.validate+0x1f8>
    812c:      	mov	x19, x8
    8130:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008130:  ARM64_RELOC_PAGE21	l_stogir.413
    8134:      	ldr	x16, [x16]
		0000000000008134:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    8138:      	orr	x0, x16, xzr
    813c:      	mov	x1, x0
    8140:      	mov	x0, #0x1                ; =1
    8144:      	mov	x2, #0x2b               ; =43
    8148:      	b	0x80f4 <_stogir.vector-comparison.validate+0x198>
    814c:      	movz	x5, #0x0, lsl #48
    8150:      	b	0x802c <_stogir.vector-comparison.validate+0xd0>
    8154:      	ldr	x4, [x0, #0x8]
    8158:      	cmp	x1, x4
    815c:      	b.ge	0x81a8 <_stogir.vector-comparison.validate+0x24c>
    8160:      	add	x4, x0, #0x78
    8164:      	ldr	x4, [x4, #0x8]
    8168:      	cmp	x1, x4
    816c:      	b.ge	0x81a8 <_stogir.vector-comparison.validate+0x24c>
    8170:      	ldr	x1, [x0, #0x78]
    8174:      	add	x1, x3, x1
    8178:      	ldr	w1, [x1]
    817c:      	sxtw	x1, w1
    8180:      	cmp	x1, #0x0
    8184:      	b.lt	0x81a8 <_stogir.vector-comparison.validate+0x24c>
    8188:      	ldr	x1, [x0]
    818c:      	add	x1, x7, x1
    8190:      	ldr	x1, [x1]
    8194:      	mov	x4, x1
    8198:      	mov	x1, #0x1                ; =1
    819c:      	b	0x81b0 <_stogir.vector-comparison.validate+0x254>
    81a0:      	movz	x5, #0x0, lsl #48
    81a4:      	b	0x8024 <_stogir.vector-comparison.validate+0xc8>
    81a8:      	movz	x1, #0x0, lsl #48
    81ac:      	movz	x4, #0x0, lsl #48
    81b0:      	lsr	w1, w1, #0
    81b4:      	lsr	x16, x1, #0
    81b8:      	cmp	x16, #0x1
    81bc:      	b.eq	0x81d8 <_stogir.vector-comparison.validate+0x27c>
    81c0:      	b.lo	0x81c8 <_stogir.vector-comparison.validate+0x26c>
    81c4:      	b	0x81dc <_stogir.vector-comparison.validate+0x280>
    81c8:      	cmp	x16, #0x0
    81cc:      	b.eq	0x81d4 <_stogir.vector-comparison.validate+0x278>
    81d0:      	b	0x81dc <_stogir.vector-comparison.validate+0x280>
    81d4:      	b	0x81e0 <_stogir.vector-comparison.validate+0x284>
    81d8:      	b	0x81e8 <_stogir.vector-comparison.validate+0x28c>
    81dc:      	b	0x82bc <_stogir.vector-comparison.validate+0x360>
    81e0:      	mov	x19, x8
    81e4:      	b	0x8130 <_stogir.vector-comparison.validate+0x1d4>
    81e8:      	uxtb	w1, w4
    81ec:      	cmp	x1, #0xe
    81f0:      	b.lt	0x82c4 <_stogir.vector-comparison.validate+0x368>
    81f4:      	cmp	x1, #0x19
    81f8:      	b.gt	0x82cc <_stogir.vector-comparison.validate+0x370>
    81fc:      	lsr	w4, w4, #0
    8200:      	ubfx	x1, x4, #8, #8
    8204:      	cmp	x1, #0xf
    8208:      	b.le	0x82d4 <_stogir.vector-comparison.validate+0x378>
    820c:      	cmp	x1, #0x80
    8210:      	b.ge	0x82dc <_stogir.vector-comparison.validate+0x380>
    8214:      	and	x1, x1, #0xf
    8218:      	lsr	w1, w1, #0
    821c:      	sxtw	x1, w1
    8220:      	cmp	x1, #0x1
    8224:      	b.lt	0x82e4 <_stogir.vector-comparison.validate+0x388>
    8228:      	cmp	x1, #0xd
    822c:      	b.gt	0x82ec <_stogir.vector-comparison.validate+0x390>
    8230:      	ldr	x1, [x0, #0x78]
    8234:      	add	x1, x3, x1
    8238:      	ldr	w1, [x1]
    823c:      	sxtw	x1, w1
    8240:      	cmp	x1, #0x2
    8244:      	b.ne	0x82f4 <_stogir.vector-comparison.validate+0x398>
    8248:      	lsr	w2, w2, #0
    824c:      	add	x16, sp, #0x10
    8250:      	ldr	w1, [x16]
    8254:      	uxtb	w3, w1
    8258:      	add	x16, sp, #0x10
    825c:      	ldr	w4, [x16, #0x4]
    8260:      	lsr	w3, w3, #0
    8264:      	ubfx	x1, x1, #8, #8
    8268:      	add	x16, sp, #0x10
    826c:      	ldr	w5, [x16, #0x8]
    8270:      	lsr	w4, w4, #0
    8274:      	lsr	w5, w5, #0
    8278:      	lsr	w1, w1, #0
    827c:      	mov	x19, x8
    8280:      	add	x8, sp, #0x20
    8284:      	fmov	s31, w1
    8288:      	mov	w1, w3
    828c:      	mov	w3, w2
    8290:      	fmov	w2, s31
    8294:      	bl	0x8294 <_stogir.vector-comparison.validate+0x338>
		0000000000008294:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    8298:      	add	x16, sp, #0x20
    829c:      	ldr	x0, [x16]
    82a0:      	add	x16, sp, #0x20
    82a4:      	ldr	x1, [x16, #0x8]
    82a8:      	add	x16, sp, #0x20
    82ac:      	ldr	x2, [x16, #0x10]
    82b0:      	b	0x8148 <_stogir.vector-comparison.validate+0x1ec>
    82b4:      	brk	#0
    82b8:      	b	0x82b4 <_stogir.vector-comparison.validate+0x358>
    82bc:      	brk	#0
    82c0:      	b	0x82bc <_stogir.vector-comparison.validate+0x360>
    82c4:      	mov	x19, x8
    82c8:      	b	0x8130 <_stogir.vector-comparison.validate+0x1d4>
    82cc:      	mov	x19, x8
    82d0:      	b	0x8130 <_stogir.vector-comparison.validate+0x1d4>
    82d4:      	mov	x19, x8
    82d8:      	b	0x8130 <_stogir.vector-comparison.validate+0x1d4>
    82dc:      	mov	x19, x8
    82e0:      	b	0x8130 <_stogir.vector-comparison.validate+0x1d4>
    82e4:      	mov	x19, x8
    82e8:      	b	0x8130 <_stogir.vector-comparison.validate+0x1d4>
    82ec:      	mov	x19, x8
    82f0:      	b	0x8130 <_stogir.vector-comparison.validate+0x1d4>
    82f4:      	mov	x19, x8
    82f8:      	b	0x8130 <_stogir.vector-comparison.validate+0x1d4>

00000000000082fc <_stogir.vector-arithmetic.node?>:
    82fc:      	sxtw	x1, w1
    8300:      	cmp	x1, #0x0
    8304:      	cset	w2, gt
    8308:      	movz	x16, #0x0, lsl #48
    830c:      	sub	x3, x16, x1
    8310:      	sub	x4, x3, #0x1
    8314:      	uxtb	w16, w2
    8318:      	cmp	w16, wzr
    831c:      	b.eq	0x8360 <_stogir.vector-arithmetic.node?+0x64>
    8320:      	ldr	x3, [x0, #0x8]
    8324:      	cmp	x1, x3
    8328:      	b.ge	0x83b4 <_stogir.vector-arithmetic.node?+0xb8>
    832c:      	add	x3, x0, #0x78
    8330:      	ldr	x3, [x3, #0x8]
    8334:      	cmp	x1, x3
    8338:      	b.ge	0x84e4 <_stogir.vector-arithmetic.node?+0x1e8>
    833c:      	lsl	x3, x1, #2
    8340:      	ldr	x5, [x0, #0x78]
    8344:      	add	x3, x3, x5
    8348:      	ldr	w3, [x3]
    834c:      	sxtw	x3, w3
    8350:      	cmp	x3, #0x0
    8354:      	cset	w3, ge
    8358:      	ubfx	x3, x3, #0, #8
    835c:      	b	0x84e8 <_stogir.vector-arithmetic.node?+0x1ec>
    8360:      	cmp	x1, #0x0
    8364:      	b.ge	0x83bc <_stogir.vector-arithmetic.node?+0xc0>
    8368:      	add	x5, x0, #0x28
    836c:      	add	x6, x0, #0x50
    8370:      	ldr	x5, [x5, #0x8]
    8374:      	ldr	x6, [x6, #0x8]
    8378:      	cmp	x5, x6
    837c:      	b.ne	0x83ac <_stogir.vector-arithmetic.node?+0xb0>
    8380:      	cmp	x3, x5
    8384:      	b.gt	0x84f4 <_stogir.vector-arithmetic.node?+0x1f8>
    8388:      	lsl	x3, x4, #2
    838c:      	ldr	x5, [x0, #0x50]
    8390:      	add	x3, x3, x5
    8394:      	ldr	w3, [x3]
    8398:      	sxtw	x3, w3
    839c:      	cmp	x3, #0x0
    83a0:      	cset	w3, gt
    83a4:      	ubfx	x3, x3, #0, #8
    83a8:      	b	0x84f8 <_stogir.vector-arithmetic.node?+0x1fc>
    83ac:      	movz	x3, #0x0, lsl #48
    83b0:      	b	0x83c0 <_stogir.vector-arithmetic.node?+0xc4>
    83b4:      	movz	x3, #0x0, lsl #48
    83b8:      	b	0x83c0 <_stogir.vector-arithmetic.node?+0xc4>
    83bc:      	movz	x3, #0x0, lsl #48
    83c0:      	cmp	x3, #0x0
    83c4:      	b.eq	0x8404 <_stogir.vector-arithmetic.node?+0x108>
    83c8:      	uxtb	w16, w2
    83cc:      	cmp	w16, wzr
    83d0:      	b.eq	0x83e8 <_stogir.vector-arithmetic.node?+0xec>
    83d4:      	lsl	x1, x1, #4
    83d8:      	ldr	x0, [x0]
    83dc:      	add	x0, x1, x0
    83e0:      	ldr	x0, [x0]
    83e4:      	b	0x83f8 <_stogir.vector-arithmetic.node?+0xfc>
    83e8:      	lsl	x1, x4, #4
    83ec:      	ldr	x0, [x0, #0x28]
    83f0:      	add	x0, x1, x0
    83f4:      	ldr	x0, [x0]
    83f8:      	mov	x1, x0
    83fc:      	mov	x0, #0x1                ; =1
    8400:      	b	0x840c <_stogir.vector-arithmetic.node?+0x110>
    8404:      	movz	x0, #0x0, lsl #48
    8408:      	movz	x1, #0x0, lsl #48
    840c:      	lsr	w0, w0, #0
    8410:      	lsr	x16, x0, #0
    8414:      	cmp	x16, #0x1
    8418:      	b.eq	0x8434 <_stogir.vector-arithmetic.node?+0x138>
    841c:      	b.lo	0x8424 <_stogir.vector-arithmetic.node?+0x128>
    8420:      	b	0x8438 <_stogir.vector-arithmetic.node?+0x13c>
    8424:      	cmp	x16, #0x0
    8428:      	b.eq	0x8430 <_stogir.vector-arithmetic.node?+0x134>
    842c:      	b	0x8438 <_stogir.vector-arithmetic.node?+0x13c>
    8430:      	b	0x843c <_stogir.vector-arithmetic.node?+0x140>
    8434:      	b	0x844c <_stogir.vector-arithmetic.node?+0x150>
    8438:      	b	0x8504 <_stogir.vector-arithmetic.node?+0x208>
    843c:      	movz	x0, #0x0, lsl #48
    8440:      	b	0x8448 <_stogir.vector-arithmetic.node?+0x14c>
    8444:      	movz	x0, #0x0, lsl #48
    8448:      	ret
    844c:      	uxtb	w0, w1
    8450:      	cmp	x0, #0x1f
    8454:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8458:      	cmp	x0, #0x20
    845c:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8460:      	cmp	x0, #0x2d
    8464:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8468:      	cmp	x0, #0x36
    846c:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8470:      	cmp	x0, #0x37
    8474:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8478:      	cmp	x0, #0x38
    847c:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8480:      	cmp	x0, #0x39
    8484:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8488:      	cmp	x0, #0x3a
    848c:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8490:      	cmp	x0, #0x3b
    8494:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8498:      	cmp	x0, #0x31
    849c:      	b.lt	0x850c <_stogir.vector-arithmetic.node?+0x210>
    84a0:      	cmp	x0, #0x35
    84a4:      	b.gt	0x850c <_stogir.vector-arithmetic.node?+0x210>
    84a8:      	lsr	w1, w1, #0
    84ac:      	ubfx	x0, x1, #8, #8
    84b0:      	cmp	x0, #0xf
    84b4:      	b.le	0x8444 <_stogir.vector-arithmetic.node?+0x148>
    84b8:      	cmp	x0, #0x80
    84bc:      	b.ge	0x84ec <_stogir.vector-arithmetic.node?+0x1f0>
    84c0:      	and	x0, x0, #0xf
    84c4:      	lsr	w0, w0, #0
    84c8:      	sxtw	x0, w0
    84cc:      	cmp	x0, #0x1
    84d0:      	b.lt	0x84fc <_stogir.vector-arithmetic.node?+0x200>
    84d4:      	cmp	x0, #0xd
    84d8:      	cset	w0, le
    84dc:      	ubfx	x0, x0, #0, #8
    84e0:      	b	0x8500 <_stogir.vector-arithmetic.node?+0x204>
    84e4:      	movz	x3, #0x0, lsl #48
    84e8:      	b	0x83b8 <_stogir.vector-arithmetic.node?+0xbc>
    84ec:      	movz	x0, #0x0, lsl #48
    84f0:      	b	0x8448 <_stogir.vector-arithmetic.node?+0x14c>
    84f4:      	movz	x3, #0x0, lsl #48
    84f8:      	b	0x83b0 <_stogir.vector-arithmetic.node?+0xb4>
    84fc:      	movz	x0, #0x0, lsl #48
    8500:      	b	0x84f0 <_stogir.vector-arithmetic.node?+0x1f4>
    8504:      	brk	#0
    8508:      	b	0x8504 <_stogir.vector-arithmetic.node?+0x208>
    850c:      	cmp	x0, #0x1a
    8510:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8514:      	cmp	x0, #0x1b
    8518:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    851c:      	cmp	x0, #0x1c
    8520:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8524:      	cmp	x0, #0x1d
    8528:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    852c:      	cmp	x0, #0x1e
    8530:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8534:      	cmp	x0, #0x2e
    8538:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    853c:      	cmp	x0, #0x2f
    8540:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    8544:      	cmp	x0, #0x30
    8548:      	b.eq	0x84a8 <_stogir.vector-arithmetic.node?+0x1ac>
    854c:      	movz	x0, #0x0, lsl #48
    8550:      	b	0x8448 <_stogir.vector-arithmetic.node?+0x14c>

0000000000008554 <_stogir.vector-arithmetic.validate>:
    8554:      	sub	sp, sp, #0x60
    8558:      	str	x29, [sp]
    855c:      	str	x30, [sp, #0x8]
    8560:      	mov	x29, sp
    8564:      	str	x19, [sp, #0x40]
    8568:      	str	x20, [sp, #0x48]
    856c:      	str	x21, [sp, #0x50]
    8570:      	str	x22, [sp, #0x58]
    8574:      	sxtw	x2, w1
    8578:      	lsl	x19, x2, #2
    857c:      	cmp	x2, #0x0
    8580:      	cset	w3, gt
    8584:      	movz	x16, #0x0, lsl #48
    8588:      	sub	x4, x16, x2
    858c:      	sub	x5, x4, #0x1
    8590:      	uxtb	w16, w3
    8594:      	cmp	w16, wzr
    8598:      	b.eq	0x85d8 <_stogir.vector-arithmetic.validate+0x84>
    859c:      	ldr	x4, [x0, #0x8]
    85a0:      	cmp	x2, x4
    85a4:      	b.ge	0x862c <_stogir.vector-arithmetic.validate+0xd8>
    85a8:      	add	x4, x0, #0x78
    85ac:      	ldr	x4, [x4, #0x8]
    85b0:      	cmp	x2, x4
    85b4:      	b.ge	0x8758 <_stogir.vector-arithmetic.validate+0x204>
    85b8:      	ldr	x4, [x0, #0x78]
    85bc:      	add	x4, x19, x4
    85c0:      	ldr	w4, [x4]
    85c4:      	sxtw	x4, w4
    85c8:      	cmp	x4, #0x0
    85cc:      	cset	w4, ge
    85d0:      	ubfx	x4, x4, #0, #8
    85d4:      	b	0x875c <_stogir.vector-arithmetic.validate+0x208>
    85d8:      	cmp	x2, #0x0
    85dc:      	b.ge	0x8634 <_stogir.vector-arithmetic.validate+0xe0>
    85e0:      	add	x6, x0, #0x28
    85e4:      	add	x7, x0, #0x50
    85e8:      	ldr	x6, [x6, #0x8]
    85ec:      	ldr	x7, [x7, #0x8]
    85f0:      	cmp	x6, x7
    85f4:      	b.ne	0x8624 <_stogir.vector-arithmetic.validate+0xd0>
    85f8:      	cmp	x4, x6
    85fc:      	b.gt	0x87f4 <_stogir.vector-arithmetic.validate+0x2a0>
    8600:      	lsl	x4, x5, #2
    8604:      	ldr	x6, [x0, #0x50]
    8608:      	add	x4, x4, x6
    860c:      	ldr	w4, [x4]
    8610:      	sxtw	x4, w4
    8614:      	cmp	x4, #0x0
    8618:      	cset	w4, gt
    861c:      	ubfx	x4, x4, #0, #8
    8620:      	b	0x87f8 <_stogir.vector-arithmetic.validate+0x2a4>
    8624:      	movz	x4, #0x0, lsl #48
    8628:      	b	0x8638 <_stogir.vector-arithmetic.validate+0xe4>
    862c:      	movz	x4, #0x0, lsl #48
    8630:      	b	0x8638 <_stogir.vector-arithmetic.validate+0xe4>
    8634:      	movz	x4, #0x0, lsl #48
    8638:      	cmp	x4, #0x0
    863c:      	b.eq	0x869c <_stogir.vector-arithmetic.validate+0x148>
    8640:      	uxtb	w16, w3
    8644:      	cmp	w16, wzr
    8648:      	b.eq	0x8670 <_stogir.vector-arithmetic.validate+0x11c>
    864c:      	lsl	x3, x2, #4
    8650:      	ldr	x4, [x0]
    8654:      	add	x3, x3, x4
    8658:      	ldr	x4, [x3]
    865c:      	ldr	x3, [x3, #0x8]
    8660:      	fmov	d31, x3
    8664:      	mov	x3, x4
    8668:      	fmov	x4, d31
    866c:      	b	0x8690 <_stogir.vector-arithmetic.validate+0x13c>
    8670:      	lsl	x3, x5, #4
    8674:      	ldr	x4, [x0, #0x28]
    8678:      	add	x3, x3, x4
    867c:      	ldr	x4, [x3]
    8680:      	ldr	x3, [x3, #0x8]
    8684:      	fmov	d31, x3
    8688:      	mov	x3, x4
    868c:      	fmov	x4, d31
    8690:      	mov	x20, x3
    8694:      	mov	x3, #0x1                ; =1
    8698:      	b	0x86a8 <_stogir.vector-arithmetic.validate+0x154>
    869c:      	movz	x3, #0x0, lsl #48
    86a0:      	movz	x20, #0x0, lsl #48
    86a4:      	movz	x4, #0x0, lsl #48
    86a8:      	lsr	w3, w3, #0
    86ac:      	lsr	x16, x3, #0
    86b0:      	cmp	x16, #0x1
    86b4:      	b.eq	0x86d0 <_stogir.vector-arithmetic.validate+0x17c>
    86b8:      	b.lo	0x86c0 <_stogir.vector-arithmetic.validate+0x16c>
    86bc:      	b	0x86d4 <_stogir.vector-arithmetic.validate+0x180>
    86c0:      	cmp	x16, #0x0
    86c4:      	b.eq	0x86cc <_stogir.vector-arithmetic.validate+0x178>
    86c8:      	b	0x86d4 <_stogir.vector-arithmetic.validate+0x180>
    86cc:      	b	0x86d8 <_stogir.vector-arithmetic.validate+0x184>
    86d0:      	b	0x86f8 <_stogir.vector-arithmetic.validate+0x1a4>
    86d4:      	b	0x88a8 <_stogir.vector-arithmetic.validate+0x354>
    86d8:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		00000000000086d8:  ARM64_RELOC_PAGE21	l_stogir.414
    86dc:      	ldr	x16, [x16]
		00000000000086dc:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    86e0:      	orr	x0, x16, xzr
    86e4:      	mov	x21, x8
    86e8:      	mov	x1, x0
    86ec:      	mov	x0, #0x1                ; =1
    86f0:      	mov	x2, #0x25               ; =37
    86f4:      	b	0x872c <_stogir.vector-arithmetic.validate+0x1d8>
    86f8:      	add	x16, sp, #0x10
    86fc:      	str	x20, [x16]
    8700:      	add	x16, sp, #0x10
    8704:      	str	x4, [x16, #0x8]
    8708:      	cmp	x2, #0x0
    870c:      	b.gt	0x8760 <_stogir.vector-arithmetic.validate+0x20c>
    8710:      	mov	x21, x8
    8714:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008714:  ARM64_RELOC_PAGE21	l_stogir.415
    8718:      	ldr	x16, [x16]
		0000000000008718:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    871c:      	orr	x0, x16, xzr
    8720:      	mov	x1, x0
    8724:      	mov	x0, #0x1                ; =1
    8728:      	mov	x2, #0x2b               ; =43
    872c:      	str	x0, [x21]
    8730:      	str	x1, [x21, #0x8]
    8734:      	str	x2, [x21, #0x10]
    8738:      	ldr	x19, [sp, #0x40]
    873c:      	ldr	x20, [sp, #0x48]
    8740:      	ldr	x21, [sp, #0x50]
    8744:      	ldr	x22, [sp, #0x58]
    8748:      	ldr	x29, [sp]
    874c:      	ldr	x30, [sp, #0x8]
    8750:      	add	sp, sp, #0x60
    8754:      	ret
    8758:      	movz	x4, #0x0, lsl #48
    875c:      	b	0x8630 <_stogir.vector-arithmetic.validate+0xdc>
    8760:      	lsr	w1, w1, #0
    8764:      	mov	x21, x8
    8768:      	mov	x22, x0
    876c:      	bl	0x876c <_stogir.vector-arithmetic.validate+0x218>
		000000000000876c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    8770:      	cmp	x0, #0x0
    8774:      	b.eq	0x8714 <_stogir.vector-arithmetic.validate+0x1c0>
    8778:      	uxtb	w20, w20
    877c:      	orr	x0, x20, xzr
    8780:      	ldr	x1, [x22, #0x78]
    8784:      	cmp	x0, #0x1d
    8788:      	cset	w2, eq
    878c:      	cmp	x0, #0x1e
    8790:      	cset	w3, eq
    8794:      	add	x1, x19, x1
    8798:      	ldr	w1, [x1]
    879c:      	cmp	x0, #0x1f
    87a0:      	b.eq	0x8858 <_stogir.vector-arithmetic.validate+0x304>
    87a4:      	cmp	x0, #0x20
    87a8:      	b.eq	0x8858 <_stogir.vector-arithmetic.validate+0x304>
    87ac:      	cmp	x0, #0x2d
    87b0:      	b.eq	0x8858 <_stogir.vector-arithmetic.validate+0x304>
    87b4:      	cmp	x0, #0x36
    87b8:      	b.eq	0x8858 <_stogir.vector-arithmetic.validate+0x304>
    87bc:      	cmp	x0, #0x37
    87c0:      	b.eq	0x8858 <_stogir.vector-arithmetic.validate+0x304>
    87c4:      	cmp	x0, #0x38
    87c8:      	b.eq	0x8858 <_stogir.vector-arithmetic.validate+0x304>
    87cc:      	cmp	x0, #0x39
    87d0:      	b.eq	0x8858 <_stogir.vector-arithmetic.validate+0x304>
    87d4:      	uxtb	w16, w2
    87d8:      	cmp	w16, wzr
    87dc:      	b.ne	0x88b0 <_stogir.vector-arithmetic.validate+0x35c>
    87e0:      	uxtb	w16, w3
    87e4:      	cmp	w16, wzr
    87e8:      	b.ne	0x88b0 <_stogir.vector-arithmetic.validate+0x35c>
    87ec:      	mov	x0, #0x2                ; =2
    87f0:      	b	0x88b4 <_stogir.vector-arithmetic.validate+0x360>
    87f4:      	movz	x4, #0x0, lsl #48
    87f8:      	b	0x8628 <_stogir.vector-arithmetic.validate+0xd4>
    87fc:      	add	x16, sp, #0x10
    8800:      	ldr	w2, [x16, #0xc]
    8804:      	sxtw	x2, w2
    8808:      	lsr	w1, w1, #0
    880c:      	lsr	w4, w4, #0
    8810:      	lsr	w20, w20, #0
    8814:      	lsr	w2, w2, #0
    8818:      	ubfx	x0, x0, #8, #8
    881c:      	lsr	w0, w0, #0
    8820:      	add	x8, sp, #0x20
    8824:      	mov	w3, w1
    8828:      	mov	w1, w20
    882c:      	mov	w5, w2
    8830:      	mov	w2, w0
    8834:      	mov	x0, x22
    8838:      	bl	0x8838 <_stogir.vector-arithmetic.validate+0x2e4>
		0000000000008838:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    883c:      	add	x16, sp, #0x20
    8840:      	ldr	x0, [x16]
    8844:      	add	x16, sp, #0x20
    8848:      	ldr	x1, [x16, #0x8]
    884c:      	add	x16, sp, #0x20
    8850:      	ldr	x2, [x16, #0x10]
    8854:      	b	0x872c <_stogir.vector-arithmetic.validate+0x1d8>
    8858:      	mov	x0, #0x1                ; =1
    885c:      	sxtw	x1, w1
    8860:      	lsr	w0, w0, #0
    8864:      	sxtw	x0, w0
    8868:      	cmp	x1, x0
    886c:      	b.ne	0x8714 <_stogir.vector-arithmetic.validate+0x1c0>
    8870:      	add	x16, sp, #0x10
    8874:      	ldr	w0, [x16]
    8878:      	add	x16, sp, #0x10
    887c:      	ldr	w1, [x16, #0x4]
    8880:      	add	x16, sp, #0x10
    8884:      	ldr	w4, [x16, #0x8]
    8888:      	uxtb	w16, w2
    888c:      	cmp	w16, wzr
    8890:      	b.ne	0x87fc <_stogir.vector-arithmetic.validate+0x2a8>
    8894:      	uxtb	w16, w3
    8898:      	cmp	w16, wzr
    889c:      	b.ne	0x87fc <_stogir.vector-arithmetic.validate+0x2a8>
    88a0:      	movz	x2, #0x0, lsl #48
    88a4:      	b	0x8808 <_stogir.vector-arithmetic.validate+0x2b4>
    88a8:      	brk	#0
    88ac:      	b	0x88a8 <_stogir.vector-arithmetic.validate+0x354>
    88b0:      	mov	x0, #0x3                ; =3
    88b4:      	b	0x885c <_stogir.vector-arithmetic.validate+0x308>

00000000000088b8 <_stogir.vector.memory-inputs>:
    88b8:      	sub	sp, sp, #0x40
    88bc:      	str	x29, [sp]
    88c0:      	str	x30, [sp, #0x8]
    88c4:      	mov	x29, sp
    88c8:      	str	x19, [sp, #0x10]
    88cc:      	str	x20, [sp, #0x18]
    88d0:      	str	x21, [sp, #0x20]
    88d4:      	str	x22, [sp, #0x28]
    88d8:      	str	x23, [sp, #0x30]
    88dc:      	str	x24, [sp, #0x38]
    88e0:      	sxtw	x5, w1
    88e4:      	cmp	x5, #0xf
    88e8:      	b.le	0x8db8 <_stogir.vector.memory-inputs+0x500>
    88ec:      	cmp	x5, #0x80
    88f0:      	b.ge	0x8dc0 <_stogir.vector.memory-inputs+0x508>
    88f4:      	and	x6, x5, #0xf
    88f8:      	lsr	w6, w6, #0
    88fc:      	sxtw	x6, w6
    8900:      	cmp	x6, #0x1
    8904:      	b.lt	0x8dc8 <_stogir.vector.memory-inputs+0x510>
    8908:      	and	x5, x5, #0xf
    890c:      	lsr	w5, w5, #0
    8910:      	sxtw	x5, w5
    8914:      	cmp	x5, #0xd
    8918:      	b.gt	0x8dd0 <_stogir.vector.memory-inputs+0x518>
    891c:      	lsr	w1, w1, #0
    8920:      	lsr	w2, w2, #0
    8924:      	mov	x19, x8
    8928:      	mov	x20, x0
    892c:      	mov	w0, w1
    8930:      	mov	w21, w1
    8934:      	mov	w1, w2
    8938:      	mov	w22, w2
    893c:      	mov	w23, w3
    8940:      	mov	w24, w4
    8944:      	bl	0x8944 <_stogir.vector.memory-inputs+0x8c>
		0000000000008944:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8948:      	lsr	w0, w0, #0
    894c:      	sxtw	x0, w0
    8950:      	cmp	x0, #0x0
    8954:      	b.le	0x89bc <_stogir.vector.memory-inputs+0x104>
    8958:      	sxtw	x23, w23
    895c:      	cmp	x23, #0x0
    8960:      	cset	w0, gt
    8964:      	movz	x16, #0x0, lsl #48
    8968:      	sub	x1, x16, x23
    896c:      	sub	x2, x1, #0x1
    8970:      	uxtb	w16, w0
    8974:      	cmp	w16, wzr
    8978:      	b.eq	0x8aac <_stogir.vector.memory-inputs+0x1f4>
    897c:      	ldr	x1, [x20, #0x8]
    8980:      	cmp	x23, x1
    8984:      	b.ge	0x8aa4 <_stogir.vector.memory-inputs+0x1ec>
    8988:      	add	x1, x20, #0x78
    898c:      	ldr	x1, [x1, #0x8]
    8990:      	cmp	x23, x1
    8994:      	b.ge	0x8b54 <_stogir.vector.memory-inputs+0x29c>
    8998:      	lsl	x1, x23, #2
    899c:      	ldr	x3, [x20, #0x78]
    89a0:      	add	x1, x1, x3
    89a4:      	ldr	w1, [x1]
    89a8:      	sxtw	x1, w1
    89ac:      	cmp	x1, #0x0
    89b0:      	cset	w1, ge
    89b4:      	ubfx	x1, x1, #0, #8
    89b8:      	b	0x8b58 <_stogir.vector.memory-inputs+0x2a0>
    89bc:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		00000000000089bc:  ARM64_RELOC_PAGE21	l_stogir.416
    89c0:      	ldr	x16, [x16]
		00000000000089c0:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    89c4:      	orr	x0, x16, xzr
    89c8:      	mov	x1, x0
    89cc:      	mov	x0, #0x1                ; =1
    89d0:      	mov	x2, #0x32               ; =50
    89d4:      	str	x0, [x19]
    89d8:      	str	x1, [x19, #0x8]
    89dc:      	str	x2, [x19, #0x10]
    89e0:      	ldr	x19, [sp, #0x10]
    89e4:      	ldr	x20, [sp, #0x18]
    89e8:      	ldr	x21, [sp, #0x20]
    89ec:      	ldr	x22, [sp, #0x28]
    89f0:      	ldr	x23, [sp, #0x30]
    89f4:      	ldr	x24, [sp, #0x38]
    89f8:      	ldr	x29, [sp]
    89fc:      	ldr	x30, [sp, #0x8]
    8a00:      	add	sp, sp, #0x40
    8a04:      	ret
    8a08:      	movz	x0, #0x0, lsl #48
    8a0c:      	movz	x1, #0x0, lsl #48
    8a10:      	lsr	w0, w0, #0
    8a14:      	lsr	x16, x0, #0
    8a18:      	cmp	x16, #0x1
    8a1c:      	b.eq	0x8a38 <_stogir.vector.memory-inputs+0x180>
    8a20:      	b.lo	0x8a28 <_stogir.vector.memory-inputs+0x170>
    8a24:      	b	0x8a3c <_stogir.vector.memory-inputs+0x184>
    8a28:      	cmp	x16, #0x0
    8a2c:      	b.eq	0x8a34 <_stogir.vector.memory-inputs+0x17c>
    8a30:      	b	0x8a3c <_stogir.vector.memory-inputs+0x184>
    8a34:      	b	0x8a40 <_stogir.vector.memory-inputs+0x188>
    8a38:      	b	0x8af8 <_stogir.vector.memory-inputs+0x240>
    8a3c:      	b	0x8da0 <_stogir.vector.memory-inputs+0x4e8>
    8a40:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008a40:  ARM64_RELOC_PAGE21	l_stogir.417
    8a44:      	ldr	x16, [x16]
		0000000000008a44:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    8a48:      	orr	x0, x16, xzr
    8a4c:      	mov	x1, x0
    8a50:      	mov	x0, #0x1                ; =1
    8a54:      	mov	x2, #0x1d               ; =29
    8a58:      	b	0x89d4 <_stogir.vector.memory-inputs+0x11c>
    8a5c:      	lsl	x0, x2, #4
    8a60:      	ldr	x1, [x20, #0x28]
    8a64:      	add	x0, x0, x1
    8a68:      	ldr	x0, [x0]
    8a6c:      	mov	x1, x0
    8a70:      	mov	x0, #0x1                ; =1
    8a74:      	b	0x8a10 <_stogir.vector.memory-inputs+0x158>
    8a78:      	movz	x1, #0x0, lsl #48
    8a7c:      	cmp	x1, #0x0
    8a80:      	b.eq	0x8a08 <_stogir.vector.memory-inputs+0x150>
    8a84:      	uxtb	w16, w0
    8a88:      	cmp	w16, wzr
    8a8c:      	b.eq	0x8a5c <_stogir.vector.memory-inputs+0x1a4>
    8a90:      	lsl	x0, x23, #4
    8a94:      	ldr	x1, [x20]
    8a98:      	add	x0, x0, x1
    8a9c:      	ldr	x0, [x0]
    8aa0:      	b	0x8a6c <_stogir.vector.memory-inputs+0x1b4>
    8aa4:      	movz	x1, #0x0, lsl #48
    8aa8:      	b	0x8a7c <_stogir.vector.memory-inputs+0x1c4>
    8aac:      	cmp	x23, #0x0
    8ab0:      	b.ge	0x8a78 <_stogir.vector.memory-inputs+0x1c0>
    8ab4:      	add	x3, x20, #0x28
    8ab8:      	add	x4, x20, #0x50
    8abc:      	ldr	x3, [x3, #0x8]
    8ac0:      	ldr	x4, [x4, #0x8]
    8ac4:      	cmp	x3, x4
    8ac8:      	b.ne	0x8b4c <_stogir.vector.memory-inputs+0x294>
    8acc:      	cmp	x1, x3
    8ad0:      	b.gt	0x8b5c <_stogir.vector.memory-inputs+0x2a4>
    8ad4:      	lsl	x1, x2, #2
    8ad8:      	ldr	x3, [x20, #0x50]
    8adc:      	add	x1, x1, x3
    8ae0:      	ldr	w1, [x1]
    8ae4:      	sxtw	x1, w1
    8ae8:      	cmp	x1, #0x0
    8aec:      	cset	w1, gt
    8af0:      	ubfx	x1, x1, #0, #8
    8af4:      	b	0x8b60 <_stogir.vector.memory-inputs+0x2a8>
    8af8:      	cmp	x23, #0x0
    8afc:      	b.le	0x8b30 <_stogir.vector.memory-inputs+0x278>
    8b00:      	uxtb	w1, w1
    8b04:      	cmp	x1, #0x83
    8b08:      	cset	w0, lt
    8b0c:      	uxtb	w16, w0
    8b10:      	cmp	w16, wzr
    8b14:      	b.eq	0x8b64 <_stogir.vector.memory-inputs+0x2ac>
    8b18:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008b18:  ARM64_RELOC_PAGE21	l_stogir.418
    8b1c:      	ldr	x16, [x16]
		0000000000008b1c:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8b20:      	orr	x2, x16, xzr
    8b24:      	add	x2, x1, x2
    8b28:      	ldrb	w2, [x2]
    8b2c:      	b	0x8b68 <_stogir.vector.memory-inputs+0x2b0>
    8b30:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008b30:  ARM64_RELOC_PAGE21	l_stogir.419
    8b34:      	ldr	x16, [x16]
		0000000000008b34:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    8b38:      	orr	x0, x16, xzr
    8b3c:      	mov	x1, x0
    8b40:      	mov	x0, #0x1                ; =1
    8b44:      	mov	x2, #0x2c               ; =44
    8b48:      	b	0x8a58 <_stogir.vector.memory-inputs+0x1a0>
    8b4c:      	movz	x1, #0x0, lsl #48
    8b50:      	b	0x8a7c <_stogir.vector.memory-inputs+0x1c4>
    8b54:      	movz	x1, #0x0, lsl #48
    8b58:      	b	0x8aa8 <_stogir.vector.memory-inputs+0x1f0>
    8b5c:      	movz	x1, #0x0, lsl #48
    8b60:      	b	0x8b50 <_stogir.vector.memory-inputs+0x298>
    8b64:      	movz	x2, #0x0, lsl #48
    8b68:      	uxtb	w2, w2
    8b6c:      	and	x2, x2, #0x1
    8b70:      	uxtb	w2, w2
    8b74:      	cmp	x2, #0x0
    8b78:      	b.eq	0x8b30 <_stogir.vector.memory-inputs+0x278>
    8b7c:      	uxtb	w16, w0
    8b80:      	cmp	w16, wzr
    8b84:      	b.eq	0x8ba0 <_stogir.vector.memory-inputs+0x2e8>
    8b88:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008b88:  ARM64_RELOC_PAGE21	l_stogir.418
    8b8c:      	ldr	x16, [x16]
		0000000000008b8c:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8b90:      	orr	x0, x16, xzr
    8b94:      	add	x0, x1, x0
    8b98:      	ldrb	w0, [x0]
    8b9c:      	b	0x8ba4 <_stogir.vector.memory-inputs+0x2ec>
    8ba0:      	movz	x0, #0x0, lsl #48
    8ba4:      	uxtb	w0, w0
    8ba8:      	and	x0, x0, #0x4
    8bac:      	uxtb	w0, w0
    8bb0:      	cmp	x0, #0x0
    8bb4:      	cset	w0, eq
    8bb8:      	uxtb	w16, w0
    8bbc:      	cmp	w16, wzr
    8bc0:      	cset	x0, eq
    8bc4:      	cmp	x0, #0x0
    8bc8:      	b.ne	0x8b30 <_stogir.vector.memory-inputs+0x278>
    8bcc:      	sxtw	x24, w24
    8bd0:      	cmp	x24, #0x0
    8bd4:      	cset	w0, gt
    8bd8:      	movz	x16, #0x0, lsl #48
    8bdc:      	sub	x1, x16, x24
    8be0:      	sub	x2, x1, #0x1
    8be4:      	uxtb	w16, w0
    8be8:      	cmp	w16, wzr
    8bec:      	b.eq	0x8c4c <_stogir.vector.memory-inputs+0x394>
    8bf0:      	ldr	x1, [x20, #0x8]
    8bf4:      	cmp	x24, x1
    8bf8:      	b.ge	0x8c98 <_stogir.vector.memory-inputs+0x3e0>
    8bfc:      	add	x1, x20, #0x78
    8c00:      	ldr	x1, [x1, #0x8]
    8c04:      	cmp	x24, x1
    8c08:      	b.ge	0x8d98 <_stogir.vector.memory-inputs+0x4e0>
    8c0c:      	lsl	x1, x24, #2
    8c10:      	ldr	x3, [x20, #0x78]
    8c14:      	add	x1, x1, x3
    8c18:      	ldr	w1, [x1]
    8c1c:      	sxtw	x1, w1
    8c20:      	cmp	x1, #0x0
    8c24:      	cset	w1, ge
    8c28:      	ubfx	x1, x1, #0, #8
    8c2c:      	b	0x8d9c <_stogir.vector.memory-inputs+0x4e4>
    8c30:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008c30:  ARM64_RELOC_PAGE21	l_stogir.420
    8c34:      	ldr	x16, [x16]
		0000000000008c34:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    8c38:      	orr	x0, x16, xzr
    8c3c:      	mov	x1, x0
    8c40:      	mov	x0, #0x1                ; =1
    8c44:      	mov	x2, #0x2b               ; =43
    8c48:      	b	0x8b48 <_stogir.vector.memory-inputs+0x290>
    8c4c:      	cmp	x24, #0x0
    8c50:      	b.ge	0x8ca0 <_stogir.vector.memory-inputs+0x3e8>
    8c54:      	add	x3, x20, #0x28
    8c58:      	add	x4, x20, #0x50
    8c5c:      	ldr	x3, [x3, #0x8]
    8c60:      	ldr	x4, [x4, #0x8]
    8c64:      	cmp	x3, x4
    8c68:      	b.ne	0x8d90 <_stogir.vector.memory-inputs+0x4d8>
    8c6c:      	cmp	x1, x3
    8c70:      	b.gt	0x8da8 <_stogir.vector.memory-inputs+0x4f0>
    8c74:      	lsl	x1, x2, #2
    8c78:      	ldr	x3, [x20, #0x50]
    8c7c:      	add	x1, x1, x3
    8c80:      	ldr	w1, [x1]
    8c84:      	sxtw	x1, w1
    8c88:      	cmp	x1, #0x0
    8c8c:      	cset	w1, gt
    8c90:      	ubfx	x1, x1, #0, #8
    8c94:      	b	0x8dac <_stogir.vector.memory-inputs+0x4f4>
    8c98:      	movz	x1, #0x0, lsl #48
    8c9c:      	b	0x8ca4 <_stogir.vector.memory-inputs+0x3ec>
    8ca0:      	movz	x1, #0x0, lsl #48
    8ca4:      	cmp	x1, #0x0
    8ca8:      	b.eq	0x8ce8 <_stogir.vector.memory-inputs+0x430>
    8cac:      	uxtb	w16, w0
    8cb0:      	cmp	w16, wzr
    8cb4:      	b.eq	0x8ccc <_stogir.vector.memory-inputs+0x414>
    8cb8:      	lsl	x0, x24, #4
    8cbc:      	ldr	x1, [x20]
    8cc0:      	add	x0, x0, x1
    8cc4:      	ldr	x0, [x0]
    8cc8:      	b	0x8cdc <_stogir.vector.memory-inputs+0x424>
    8ccc:      	lsl	x0, x2, #4
    8cd0:      	ldr	x1, [x20, #0x28]
    8cd4:      	add	x0, x0, x1
    8cd8:      	ldr	x0, [x0]
    8cdc:      	mov	x1, x0
    8ce0:      	mov	x0, #0x1                ; =1
    8ce4:      	b	0x8cf0 <_stogir.vector.memory-inputs+0x438>
    8ce8:      	movz	x0, #0x0, lsl #48
    8cec:      	movz	x1, #0x0, lsl #48
    8cf0:      	lsr	w0, w0, #0
    8cf4:      	lsr	x16, x0, #0
    8cf8:      	cmp	x16, #0x1
    8cfc:      	b.eq	0x8d18 <_stogir.vector.memory-inputs+0x460>
    8d00:      	b.lo	0x8d08 <_stogir.vector.memory-inputs+0x450>
    8d04:      	b	0x8d1c <_stogir.vector.memory-inputs+0x464>
    8d08:      	cmp	x16, #0x0
    8d0c:      	b.eq	0x8d14 <_stogir.vector.memory-inputs+0x45c>
    8d10:      	b	0x8d1c <_stogir.vector.memory-inputs+0x464>
    8d14:      	b	0x8d20 <_stogir.vector.memory-inputs+0x468>
    8d18:      	b	0x8d3c <_stogir.vector.memory-inputs+0x484>
    8d1c:      	b	0x8db0 <_stogir.vector.memory-inputs+0x4f8>
    8d20:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008d20:  ARM64_RELOC_PAGE21	l_stogir.421
    8d24:      	ldr	x16, [x16]
		0000000000008d24:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    8d28:      	orr	x0, x16, xzr
    8d2c:      	mov	x1, x0
    8d30:      	mov	x0, #0x1                ; =1
    8d34:      	mov	x2, #0x1d               ; =29
    8d38:      	b	0x8c48 <_stogir.vector.memory-inputs+0x390>
    8d3c:      	lsr	w0, w1, #0
    8d40:      	ubfx	x0, x0, #8, #8
    8d44:      	cmp	x0, #0x6
    8d48:      	b.ne	0x8c30 <_stogir.vector.memory-inputs+0x378>
    8d4c:      	uxtb	w1, w1
    8d50:      	cmp	x1, #0x48
    8d54:      	b.eq	0x8c30 <_stogir.vector.memory-inputs+0x378>
    8d58:      	cmp	x1, #0x46
    8d5c:      	b.eq	0x8c30 <_stogir.vector.memory-inputs+0x378>
    8d60:      	lsr	w21, w21, #0
    8d64:      	lsr	w22, w22, #0
    8d68:      	mov	w0, w21
    8d6c:      	mov	w1, w22
    8d70:      	bl	0x8d70 <_stogir.vector.memory-inputs+0x4b8>
		0000000000008d70:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8d74:      	lsr	w0, w0, #0
    8d78:      	sxtw	x0, w0
    8d7c:      	and	x0, x0, #0xffffffff
    8d80:      	mov	x1, x0
    8d84:      	movz	x0, #0x0, lsl #48
    8d88:      	movz	x2, #0x0, lsl #48
    8d8c:      	b	0x8c48 <_stogir.vector.memory-inputs+0x390>
    8d90:      	movz	x1, #0x0, lsl #48
    8d94:      	b	0x8ca4 <_stogir.vector.memory-inputs+0x3ec>
    8d98:      	movz	x1, #0x0, lsl #48
    8d9c:      	b	0x8c9c <_stogir.vector.memory-inputs+0x3e4>
    8da0:      	brk	#0
    8da4:      	b	0x8da0 <_stogir.vector.memory-inputs+0x4e8>
    8da8:      	movz	x1, #0x0, lsl #48
    8dac:      	b	0x8d94 <_stogir.vector.memory-inputs+0x4dc>
    8db0:      	brk	#0
    8db4:      	b	0x8db0 <_stogir.vector.memory-inputs+0x4f8>
    8db8:      	mov	x19, x8
    8dbc:      	b	0x89bc <_stogir.vector.memory-inputs+0x104>
    8dc0:      	mov	x19, x8
    8dc4:      	b	0x89bc <_stogir.vector.memory-inputs+0x104>
    8dc8:      	mov	x19, x8
    8dcc:      	b	0x89bc <_stogir.vector.memory-inputs+0x104>
    8dd0:      	mov	x19, x8
    8dd4:      	b	0x89bc <_stogir.vector.memory-inputs+0x104>

0000000000008dd8 <_stogir.vector.store-inputs>:
    8dd8:      	sub	sp, sp, #0x40
    8ddc:      	str	x29, [sp]
    8de0:      	str	x30, [sp, #0x8]
    8de4:      	mov	x29, sp
    8de8:      	str	x19, [sp, #0x30]
    8dec:      	sxtw	x4, w4
    8df0:      	cmp	x4, #0x0
    8df4:      	cset	w5, gt
    8df8:      	movz	x16, #0x0, lsl #48
    8dfc:      	sub	x6, x16, x4
    8e00:      	sub	x7, x6, #0x1
    8e04:      	uxtb	w16, w5
    8e08:      	cmp	w16, wzr
    8e0c:      	b.eq	0x8e50 <_stogir.vector.store-inputs+0x78>
    8e10:      	ldr	x6, [x0, #0x8]
    8e14:      	cmp	x4, x6
    8e18:      	b.ge	0x8ea4 <_stogir.vector.store-inputs+0xcc>
    8e1c:      	add	x6, x0, #0x78
    8e20:      	ldr	x6, [x6, #0x8]
    8e24:      	cmp	x4, x6
    8e28:      	b.ge	0x8fbc <_stogir.vector.store-inputs+0x1e4>
    8e2c:      	lsl	x6, x4, #2
    8e30:      	ldr	x9, [x0, #0x78]
    8e34:      	add	x6, x6, x9
    8e38:      	ldr	w6, [x6]
    8e3c:      	sxtw	x6, w6
    8e40:      	cmp	x6, #0x0
    8e44:      	cset	w6, ge
    8e48:      	ubfx	x6, x6, #0, #8
    8e4c:      	b	0x8fc0 <_stogir.vector.store-inputs+0x1e8>
    8e50:      	cmp	x4, #0x0
    8e54:      	b.ge	0x8eac <_stogir.vector.store-inputs+0xd4>
    8e58:      	add	x9, x0, #0x28
    8e5c:      	add	x10, x0, #0x50
    8e60:      	ldr	x9, [x9, #0x8]
    8e64:      	ldr	x10, [x10, #0x8]
    8e68:      	cmp	x9, x10
    8e6c:      	b.ne	0x8e9c <_stogir.vector.store-inputs+0xc4>
    8e70:      	cmp	x6, x9
    8e74:      	b.gt	0x8fc4 <_stogir.vector.store-inputs+0x1ec>
    8e78:      	lsl	x6, x7, #2
    8e7c:      	ldr	x9, [x0, #0x50]
    8e80:      	add	x6, x6, x9
    8e84:      	ldr	w6, [x6]
    8e88:      	sxtw	x6, w6
    8e8c:      	cmp	x6, #0x0
    8e90:      	cset	w6, gt
    8e94:      	ubfx	x6, x6, #0, #8
    8e98:      	b	0x8fc8 <_stogir.vector.store-inputs+0x1f0>
    8e9c:      	movz	x6, #0x0, lsl #48
    8ea0:      	b	0x8eb0 <_stogir.vector.store-inputs+0xd8>
    8ea4:      	movz	x6, #0x0, lsl #48
    8ea8:      	b	0x8eb0 <_stogir.vector.store-inputs+0xd8>
    8eac:      	movz	x6, #0x0, lsl #48
    8eb0:      	cmp	x6, #0x0
    8eb4:      	b.eq	0x8ef4 <_stogir.vector.store-inputs+0x11c>
    8eb8:      	uxtb	w16, w5
    8ebc:      	cmp	w16, wzr
    8ec0:      	b.eq	0x8ed8 <_stogir.vector.store-inputs+0x100>
    8ec4:      	lsl	x4, x4, #4
    8ec8:      	ldr	x5, [x0]
    8ecc:      	add	x4, x4, x5
    8ed0:      	ldr	x4, [x4]
    8ed4:      	b	0x8ee8 <_stogir.vector.store-inputs+0x110>
    8ed8:      	lsl	x4, x7, #4
    8edc:      	ldr	x5, [x0, #0x28]
    8ee0:      	add	x4, x4, x5
    8ee4:      	ldr	x4, [x4]
    8ee8:      	mov	x5, x4
    8eec:      	mov	x4, #0x1                ; =1
    8ef0:      	b	0x8efc <_stogir.vector.store-inputs+0x124>
    8ef4:      	movz	x4, #0x0, lsl #48
    8ef8:      	movz	x5, #0x0, lsl #48
    8efc:      	lsr	w4, w4, #0
    8f00:      	lsr	x16, x4, #0
    8f04:      	cmp	x16, #0x1
    8f08:      	b.eq	0x8f24 <_stogir.vector.store-inputs+0x14c>
    8f0c:      	b.lo	0x8f14 <_stogir.vector.store-inputs+0x13c>
    8f10:      	b	0x8f28 <_stogir.vector.store-inputs+0x150>
    8f14:      	cmp	x16, #0x0
    8f18:      	b.eq	0x8f20 <_stogir.vector.store-inputs+0x148>
    8f1c:      	b	0x8f28 <_stogir.vector.store-inputs+0x150>
    8f20:      	b	0x8f2c <_stogir.vector.store-inputs+0x154>
    8f24:      	b	0x8f4c <_stogir.vector.store-inputs+0x174>
    8f28:      	b	0x8fcc <_stogir.vector.store-inputs+0x1f4>
    8f2c:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xa4>
		0000000000008f2c:  ARM64_RELOC_PAGE21	l_stogir.422
    8f30:      	ldr	x16, [x16]
		0000000000008f30:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    8f34:      	orr	x0, x16, xzr
    8f38:      	mov	x19, x8
    8f3c:      	mov	x1, x0
    8f40:      	mov	x0, #0x1                ; =1
    8f44:      	mov	x2, #0x1a               ; =26
    8f48:      	b	0x8f9c <_stogir.vector.store-inputs+0x1c4>
    8f4c:      	lsr	w1, w1, #0
    8f50:      	lsr	w2, w2, #0
    8f54:      	lsr	w3, w3, #0
    8f58:      	lsr	w5, w5, #0
    8f5c:      	ubfx	x4, x5, #8, #8
    8f60:      	lsr	w4, w4, #0
    8f64:      	mov	x19, x8
    8f68:      	add	x8, sp, #0x10
    8f6c:      	fmov	s31, w1
    8f70:      	mov	w1, w4
    8f74:      	mov	w4, w3
    8f78:      	mov	w3, w2
    8f7c:      	fmov	w2, s31
    8f80:      	bl	0x8f80 <_stogir.vector.store-inputs+0x1a8>
		0000000000008f80:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    8f84:      	add	x16, sp, #0x10
    8f88:      	ldr	x0, [x16]
    8f8c:      	add	x16, sp, #0x10
    8f90:      	ldr	x1, [x16, #0x8]
    8f94:      	add	x16, sp, #0x10
    8f98:      	ldr	x2, [x16, #0x10]
    8f9c:      	str	x0, [x19]
    8fa0:      	str	x1, [x19, #0x8]
    8fa4:      	str	x2, [x19, #0x10]
    8fa8:      	ldr	x19, [sp, #0x30]
    8fac:      	ldr	x29, [sp]
    8fb0:      	ldr	x30, [sp, #0x8]
    8fb4:      	add	sp, sp, #0x40
    8fb8:      	ret
    8fbc:      	movz	x6, #0x0, lsl #48
    8fc0:      	b	0x8ea8 <_stogir.vector.store-inputs+0xd0>
    8fc4:      	movz	x6, #0x0, lsl #48
    8fc8:      	b	0x8ea0 <_stogir.vector.store-inputs+0xc8>
    8fcc:      	brk	#0
    8fd0:      	b	0x8fcc <_stogir.vector.store-inputs+0x1f4>

0000000000008fd4 <_stogir.types.size>:
    8fd4:      	sub	sp, sp, #0x60
    8fd8:      	str	x29, [sp]
    8fdc:      	str	x30, [sp, #0x8]
    8fe0:      	mov	x29, sp
    8fe4:      	str	x19, [sp, #0x10]
    8fe8:      	str	x20, [sp, #0x18]
    8fec:      	str	x21, [sp, #0x20]
    8ff0:      	str	x22, [sp, #0x28]
    8ff4:      	str	x23, [sp, #0x30]
    8ff8:      	str	x24, [sp, #0x38]
    8ffc:      	str	x25, [sp, #0x40]
    9000:      	str	x26, [sp, #0x48]
    9004:      	str	x27, [sp, #0x50]
    9008:      	str	x28, [sp, #0x58]
    900c:      	sxtw	x19, w0
    9010:      	sxtw	x20, w1
    9014:      	cmp	x19, #0xf
    9018:      	cset	w21, gt
    901c:      	cmp	x19, #0x0
    9020:      	cset	w22, eq
    9024:      	cmp	x20, #0x4
    9028:      	cset	w23, eq
    902c:      	cmp	x20, #0x8
    9030:      	cset	w24, eq
    9034:      	uxtb	w16, w21
    9038:      	cmp	w16, wzr
    903c:      	b.eq	0x90a0 <_stogir.types.size+0xcc>
    9040:      	cmp	x19, #0x80
    9044:      	cset	w25, lt
    9048:      	uxtb	w16, w25
    904c:      	cmp	w16, wzr
    9050:      	b.eq	0x90a0 <_stogir.types.size+0xcc>
    9054:      	and	x1, x19, #0xf
    9058:      	lsr	w1, w1, #0
    905c:      	sxtw	x26, w1
    9060:      	cmp	x26, #0x1
    9064:      	cset	w27, ge
    9068:      	uxtb	w16, w27
    906c:      	cmp	w16, wzr
    9070:      	b.eq	0x90a0 <_stogir.types.size+0xcc>
    9074:      	cmp	x26, #0xd
    9078:      	cset	w28, le
    907c:      	uxtb	w16, w28
    9080:      	cmp	w16, wzr
    9084:      	b.eq	0x90a0 <_stogir.types.size+0xcc>
    9088:      	lsr	w0, w0, #0
    908c:      	bl	0x908c <_stogir.types.size+0xb8>
		000000000000908c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    9090:      	cmp	x0, #0x0
    9094:      	b.eq	0x9180 <_stogir.types.size+0x1ac>
    9098:      	mov	x0, x26
    909c:      	b	0x9184 <_stogir.types.size+0x1b0>
    90a0:      	uxtb	w16, w23
    90a4:      	cmp	w16, wzr
    90a8:      	b.ne	0x90c0 <_stogir.types.size+0xec>
    90ac:      	uxtb	w16, w24
    90b0:      	cmp	w16, wzr
    90b4:      	b.ne	0x90c0 <_stogir.types.size+0xec>
    90b8:      	movn	x0, #0x0, lsl #48
    90bc:      	b	0x90d8 <_stogir.types.size+0x104>
    90c0:      	uxtb	w16, w22
    90c4:      	cmp	w16, wzr
    90c8:      	b.eq	0x9110 <_stogir.types.size+0x13c>
    90cc:      	movz	x0, #0x0, lsl #48
    90d0:      	b	0x90d8 <_stogir.types.size+0x104>
    90d4:      	mov	x0, #0x1                ; =1
    90d8:      	ldr	x19, [sp, #0x10]
    90dc:      	ldr	x20, [sp, #0x18]
    90e0:      	ldr	x21, [sp, #0x20]
    90e4:      	ldr	x22, [sp, #0x28]
    90e8:      	ldr	x23, [sp, #0x30]
    90ec:      	ldr	x24, [sp, #0x38]
    90f0:      	ldr	x25, [sp, #0x40]
    90f4:      	ldr	x26, [sp, #0x48]
    90f8:      	ldr	x27, [sp, #0x50]
    90fc:      	ldr	x28, [sp, #0x58]
    9100:      	ldr	x29, [sp]
    9104:      	ldr	x30, [sp, #0x8]
    9108:      	add	sp, sp, #0x60
    910c:      	ret
    9110:      	cmp	x19, #0x1
    9114:      	b.eq	0x90d4 <_stogir.types.size+0x100>
    9118:      	cmp	x19, #0x2
    911c:      	b.eq	0x90d4 <_stogir.types.size+0x100>
    9120:      	cmp	x19, #0x7
    9124:      	b.eq	0x90d4 <_stogir.types.size+0x100>
    9128:      	cmp	x19, #0x8
    912c:      	b.eq	0x90d4 <_stogir.types.size+0x100>
    9130:      	cmp	x19, #0x3
    9134:      	b.eq	0x92f0 <_stogir.types.size+0x31c>
    9138:      	cmp	x19, #0x9
    913c:      	b.eq	0x92f0 <_stogir.types.size+0x31c>
    9140:      	cmp	x19, #0x4
    9144:      	b.eq	0x9318 <_stogir.types.size+0x344>
    9148:      	cmp	x19, #0xa
    914c:      	b.eq	0x9318 <_stogir.types.size+0x344>
    9150:      	cmp	x19, #0xd
    9154:      	b.eq	0x9318 <_stogir.types.size+0x344>
    9158:      	cmp	x19, #0x5
    915c:      	b.eq	0x9328 <_stogir.types.size+0x354>
    9160:      	cmp	x19, #0xb
    9164:      	b.eq	0x9328 <_stogir.types.size+0x354>
    9168:      	cmp	x19, #0xc
    916c:      	b.eq	0x9328 <_stogir.types.size+0x354>
    9170:      	cmp	x19, #0x6
    9174:      	b.ne	0x9338 <_stogir.types.size+0x364>
    9178:      	mov	x0, x20
    917c:      	b	0x933c <_stogir.types.size+0x368>
    9180:      	movn	x0, #0x0, lsl #48
    9184:      	uxtb	w16, w23
    9188:      	cmp	w16, wzr
    918c:      	b.ne	0x91a4 <_stogir.types.size+0x1d0>
    9190:      	uxtb	w16, w24
    9194:      	cmp	w16, wzr
    9198:      	b.ne	0x91a4 <_stogir.types.size+0x1d0>
    919c:      	movn	x0, #0x0, lsl #48
    91a0:      	b	0x91c0 <_stogir.types.size+0x1ec>
    91a4:      	lsr	w0, w0, #0
    91a8:      	sxtw	x0, w0
    91ac:      	cmp	x0, #0x0
    91b0:      	b.ne	0x9280 <_stogir.types.size+0x2ac>
    91b4:      	movz	x0, #0x0, lsl #48
    91b8:      	b	0x91c0 <_stogir.types.size+0x1ec>
    91bc:      	mov	x0, #0x1                ; =1
    91c0:      	lsr	w0, w0, #0
    91c4:      	sxtw	x0, w0
    91c8:      	cmp	x0, #0x0
    91cc:      	b.ge	0x9228 <_stogir.types.size+0x254>
    91d0:      	movn	x0, #0x0, lsl #48
    91d4:      	b	0x91f0 <_stogir.types.size+0x21c>
    91d8:      	movn	x1, #0x0, lsl #48
    91dc:      	lsr	w1, w1, #0
    91e0:      	sxtw	x1, w1
    91e4:      	mul	x0, x1, x0
    91e8:      	lsr	w0, w0, #0
    91ec:      	sxtw	x0, w0
    91f0:      	ldr	x19, [sp, #0x10]
    91f4:      	ldr	x20, [sp, #0x18]
    91f8:      	ldr	x21, [sp, #0x20]
    91fc:      	ldr	x22, [sp, #0x28]
    9200:      	ldr	x23, [sp, #0x30]
    9204:      	ldr	x24, [sp, #0x38]
    9208:      	ldr	x25, [sp, #0x40]
    920c:      	ldr	x26, [sp, #0x48]
    9210:      	ldr	x27, [sp, #0x50]
    9214:      	ldr	x28, [sp, #0x58]
    9218:      	ldr	x29, [sp]
    921c:      	ldr	x30, [sp, #0x8]
    9220:      	add	sp, sp, #0x60
    9224:      	ret
    9228:      	uxtb	w16, w21
    922c:      	cmp	w16, wzr
    9230:      	b.eq	0x92f8 <_stogir.types.size+0x324>
    9234:      	uxtb	w16, w25
    9238:      	cmp	w16, wzr
    923c:      	b.eq	0x92f8 <_stogir.types.size+0x324>
    9240:      	uxtb	w16, w27
    9244:      	cmp	w16, wzr
    9248:      	b.eq	0x92f8 <_stogir.types.size+0x324>
    924c:      	uxtb	w16, w28
    9250:      	cmp	w16, wzr
    9254:      	b.eq	0x92f8 <_stogir.types.size+0x324>
    9258:      	ubfx	x1, x19, #4, #32
    925c:      	sxtw	x1, w1
    9260:      	sub	x1, x1, #0x1
    9264:      	lsr	w1, w1, #0
    9268:      	sxtw	x1, w1
    926c:      	mov	x16, #0x1               ; =1
    9270:      	lsl	x1, x16, x1
    9274:      	lsr	w1, w1, #0
    9278:      	sxtw	x1, w1
    927c:      	b	0x91dc <_stogir.types.size+0x208>
    9280:      	cmp	x0, #0x1
    9284:      	b.eq	0x91bc <_stogir.types.size+0x1e8>
    9288:      	cmp	x0, #0x2
    928c:      	b.eq	0x91bc <_stogir.types.size+0x1e8>
    9290:      	cmp	x0, #0x7
    9294:      	b.eq	0x91bc <_stogir.types.size+0x1e8>
    9298:      	cmp	x0, #0x8
    929c:      	b.eq	0x91bc <_stogir.types.size+0x1e8>
    92a0:      	cmp	x0, #0x3
    92a4:      	b.eq	0x9320 <_stogir.types.size+0x34c>
    92a8:      	cmp	x0, #0x9
    92ac:      	b.eq	0x9320 <_stogir.types.size+0x34c>
    92b0:      	cmp	x0, #0x4
    92b4:      	b.eq	0x9330 <_stogir.types.size+0x35c>
    92b8:      	cmp	x0, #0xa
    92bc:      	b.eq	0x9330 <_stogir.types.size+0x35c>
    92c0:      	cmp	x0, #0xd
    92c4:      	b.eq	0x9330 <_stogir.types.size+0x35c>
    92c8:      	cmp	x0, #0x5
    92cc:      	b.eq	0x9340 <_stogir.types.size+0x36c>
    92d0:      	cmp	x0, #0xb
    92d4:      	b.eq	0x9340 <_stogir.types.size+0x36c>
    92d8:      	cmp	x0, #0xc
    92dc:      	b.eq	0x9340 <_stogir.types.size+0x36c>
    92e0:      	cmp	x0, #0x6
    92e4:      	b.ne	0x9348 <_stogir.types.size+0x374>
    92e8:      	mov	x0, x20
    92ec:      	b	0x934c <_stogir.types.size+0x378>
    92f0:      	mov	x0, #0x2                ; =2
    92f4:      	b	0x90d8 <_stogir.types.size+0x104>
    92f8:      	cmp	x19, #0x0
    92fc:      	b.lt	0x91d8 <_stogir.types.size+0x204>
    9300:      	cmp	x19, #0xd
    9304:      	b.gt	0x91d8 <_stogir.types.size+0x204>
    9308:      	uxtb	w16, w22
    930c:      	cmp	w16, wzr
    9310:      	cset	x1, eq
    9314:      	b	0x91dc <_stogir.types.size+0x208>
    9318:      	mov	x0, #0x4                ; =4
    931c:      	b	0x92f4 <_stogir.types.size+0x320>
    9320:      	mov	x0, #0x2                ; =2
    9324:      	b	0x91c0 <_stogir.types.size+0x1ec>
    9328:      	mov	x0, #0x8                ; =8
    932c:      	b	0x931c <_stogir.types.size+0x348>
    9330:      	mov	x0, #0x4                ; =4
    9334:      	b	0x9324 <_stogir.types.size+0x350>
    9338:      	movn	x0, #0x0, lsl #48
    933c:      	b	0x932c <_stogir.types.size+0x358>
    9340:      	mov	x0, #0x8                ; =8
    9344:      	b	0x9334 <_stogir.types.size+0x360>
    9348:      	movn	x0, #0x0, lsl #48
    934c:      	b	0x9344 <_stogir.types.size+0x370>

0000000000009350 <_stogir.opcode.properties>:
    9350:      	sxtw	x0, w0
    9354:      	cmp	x0, #0x0
    9358:      	b.lt	0x9380 <_stogir.opcode.properties+0x30>
    935c:      	cmp	x0, #0x83
    9360:      	b.ge	0x9380 <_stogir.opcode.properties+0x30>
    9364:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009364:  ARM64_RELOC_PAGE21	l_stogir.423
    9368:      	ldr	x16, [x16]
		0000000000009368:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    936c:      	orr	x1, x16, xzr
    9370:      	lsr	x0, x0, #0
    9374:      	add	x0, x0, x1
    9378:      	ldrb	w0, [x0]
    937c:      	b	0x9384 <_stogir.opcode.properties+0x34>
    9380:      	movz	x0, #0x0, lsl #48
    9384:      	ret

0000000000009388 <_stogir.checked.projection>:
    9388:      	sub	sp, sp, #0x40
    938c:      	str	x29, [sp]
    9390:      	str	x30, [sp, #0x8]
    9394:      	mov	x29, sp
    9398:      	str	x19, [sp, #0x30]
    939c:      	sxtw	x2, w1
    93a0:      	cmp	x2, #0x0
    93a4:      	cset	w3, gt
    93a8:      	movz	x16, #0x0, lsl #48
    93ac:      	sub	x4, x16, x2
    93b0:      	sub	x5, x4, #0x1
    93b4:      	uxtb	w16, w3
    93b8:      	cmp	w16, wzr
    93bc:      	b.eq	0x9400 <_stogir.checked.projection+0x78>
    93c0:      	ldr	x4, [x0, #0x8]
    93c4:      	cmp	x2, x4
    93c8:      	b.ge	0x9454 <_stogir.checked.projection+0xcc>
    93cc:      	add	x4, x0, #0x78
    93d0:      	ldr	x4, [x4, #0x8]
    93d4:      	cmp	x2, x4
    93d8:      	b.ge	0x9574 <_stogir.checked.projection+0x1ec>
    93dc:      	lsl	x4, x2, #2
    93e0:      	ldr	x6, [x0, #0x78]
    93e4:      	add	x4, x4, x6
    93e8:      	ldr	w4, [x4]
    93ec:      	sxtw	x4, w4
    93f0:      	cmp	x4, #0x0
    93f4:      	cset	w4, ge
    93f8:      	ubfx	x4, x4, #0, #8
    93fc:      	b	0x9578 <_stogir.checked.projection+0x1f0>
    9400:      	cmp	x2, #0x0
    9404:      	b.ge	0x945c <_stogir.checked.projection+0xd4>
    9408:      	add	x6, x0, #0x28
    940c:      	add	x7, x0, #0x50
    9410:      	ldr	x6, [x6, #0x8]
    9414:      	ldr	x7, [x7, #0x8]
    9418:      	cmp	x6, x7
    941c:      	b.ne	0x944c <_stogir.checked.projection+0xc4>
    9420:      	cmp	x4, x6
    9424:      	b.gt	0x95a4 <_stogir.checked.projection+0x21c>
    9428:      	lsl	x4, x5, #2
    942c:      	ldr	x6, [x0, #0x50]
    9430:      	add	x4, x4, x6
    9434:      	ldr	w4, [x4]
    9438:      	sxtw	x4, w4
    943c:      	cmp	x4, #0x0
    9440:      	cset	w4, gt
    9444:      	ubfx	x4, x4, #0, #8
    9448:      	b	0x95a8 <_stogir.checked.projection+0x220>
    944c:      	movz	x4, #0x0, lsl #48
    9450:      	b	0x9460 <_stogir.checked.projection+0xd8>
    9454:      	movz	x4, #0x0, lsl #48
    9458:      	b	0x9460 <_stogir.checked.projection+0xd8>
    945c:      	movz	x4, #0x0, lsl #48
    9460:      	cmp	x4, #0x0
    9464:      	b.eq	0x94a4 <_stogir.checked.projection+0x11c>
    9468:      	uxtb	w16, w3
    946c:      	cmp	w16, wzr
    9470:      	b.eq	0x9488 <_stogir.checked.projection+0x100>
    9474:      	lsl	x2, x2, #4
    9478:      	ldr	x3, [x0]
    947c:      	add	x2, x2, x3
    9480:      	ldr	x2, [x2]
    9484:      	b	0x9498 <_stogir.checked.projection+0x110>
    9488:      	lsl	x2, x5, #4
    948c:      	ldr	x3, [x0, #0x28]
    9490:      	add	x2, x2, x3
    9494:      	ldr	x2, [x2]
    9498:      	mov	x3, x2
    949c:      	mov	x2, #0x1                ; =1
    94a0:      	b	0x94ac <_stogir.checked.projection+0x124>
    94a4:      	movz	x2, #0x0, lsl #48
    94a8:      	movz	x3, #0x0, lsl #48
    94ac:      	lsr	w2, w2, #0
    94b0:      	lsr	x16, x2, #0
    94b4:      	cmp	x16, #0x1
    94b8:      	b.eq	0x94d4 <_stogir.checked.projection+0x14c>
    94bc:      	b.lo	0x94c4 <_stogir.checked.projection+0x13c>
    94c0:      	b	0x94d8 <_stogir.checked.projection+0x150>
    94c4:      	cmp	x16, #0x0
    94c8:      	b.eq	0x94d0 <_stogir.checked.projection+0x148>
    94cc:      	b	0x94d8 <_stogir.checked.projection+0x150>
    94d0:      	b	0x94dc <_stogir.checked.projection+0x154>
    94d4:      	b	0x9534 <_stogir.checked.projection+0x1ac>
    94d8:      	b	0x95ac <_stogir.checked.projection+0x224>
    94dc:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		00000000000094dc:  ARM64_RELOC_PAGE21	l_stogir.424
    94e0:      	ldr	x16, [x16]
		00000000000094e0:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    94e4:      	orr	x0, x16, xzr
    94e8:      	mov	x19, x8
    94ec:      	mov	x1, x0
    94f0:      	mov	x0, #0x1                ; =1
    94f4:      	mov	x2, #0x17               ; =23
    94f8:      	b	0x9514 <_stogir.checked.projection+0x18c>
    94fc:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		00000000000094fc:  ARM64_RELOC_PAGE21	l_stogir.425
    9500:      	ldr	x16, [x16]
		0000000000009500:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    9504:      	orr	x0, x16, xzr
    9508:      	mov	x1, x0
    950c:      	mov	x0, #0x1                ; =1
    9510:      	mov	x2, #0x20               ; =32
    9514:      	str	x0, [x19]
    9518:      	str	x1, [x19, #0x8]
    951c:      	str	x2, [x19, #0x10]
    9520:      	ldr	x19, [sp, #0x30]
    9524:      	ldr	x29, [sp]
    9528:      	ldr	x30, [sp, #0x8]
    952c:      	add	sp, sp, #0x40
    9530:      	ret
    9534:      	uxtb	w2, w3
    9538:      	cmp	x2, #0x29
    953c:      	b.lt	0x95b4 <_stogir.checked.projection+0x22c>
    9540:      	cmp	x2, #0x2b
    9544:      	b.gt	0x95bc <_stogir.checked.projection+0x234>
    9548:      	lsr	w1, w1, #0
    954c:      	mov	x19, x8
    9550:      	add	x8, sp, #0x10
    9554:      	bl	0x9554 <_stogir.checked.projection+0x1cc>
		0000000000009554:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    9558:      	add	x16, sp, #0x10
    955c:      	ldr	x0, [x16]
    9560:      	add	x16, sp, #0x10
    9564:      	ldr	x1, [x16, #0x8]
    9568:      	add	x16, sp, #0x10
    956c:      	ldr	x2, [x16, #0x10]
    9570:      	b	0x9514 <_stogir.checked.projection+0x18c>
    9574:      	movz	x4, #0x0, lsl #48
    9578:      	b	0x9458 <_stogir.checked.projection+0xd0>
    957c:      	lsr	w3, w3, #0
    9580:      	ubfx	x0, x3, #8, #8
    9584:      	cmp	x0, #0x0
    9588:      	b.eq	0x94fc <_stogir.checked.projection+0x174>
    958c:      	cmp	x0, #0xd
    9590:      	b.gt	0x94fc <_stogir.checked.projection+0x174>
    9594:      	movz	x0, #0x0, lsl #48
    9598:      	movz	x1, #0x0, lsl #48
    959c:      	movz	x2, #0x0, lsl #48
    95a0:      	b	0x9514 <_stogir.checked.projection+0x18c>
    95a4:      	movz	x4, #0x0, lsl #48
    95a8:      	b	0x9450 <_stogir.checked.projection+0xc8>
    95ac:      	brk	#0
    95b0:      	b	0x95ac <_stogir.checked.projection+0x224>
    95b4:      	mov	x19, x8
    95b8:      	b	0x957c <_stogir.checked.projection+0x1f4>
    95bc:      	mov	x19, x8
    95c0:      	b	0x957c <_stogir.checked.projection+0x1f4>

00000000000095c4 <_stogir.checked.operands>:
    95c4:      	sub	sp, sp, #0x30
    95c8:      	str	x19, [sp, #0x20]
    95cc:      	str	x20, [sp, #0x28]
    95d0:      	sxtw	x1, w1
    95d4:      	sxtw	x2, w2
    95d8:      	cmp	x1, #0x29
    95dc:      	b.lt	0x9624 <_stogir.checked.operands+0x60>
    95e0:      	cmp	x1, #0x2b
    95e4:      	b.gt	0x9624 <_stogir.checked.operands+0x60>
    95e8:      	cmp	x2, #0x1
    95ec:      	b.lt	0x9624 <_stogir.checked.operands+0x60>
    95f0:      	cmp	x2, #0xb
    95f4:      	b.gt	0x9624 <_stogir.checked.operands+0x60>
    95f8:      	cmp	x2, #0x1
    95fc:      	b.eq	0x9624 <_stogir.checked.operands+0x60>
    9600:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009600:  ARM64_RELOC_PAGE21	l_stogir.426
    9604:      	ldr	x16, [x16]
		0000000000009604:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    9608:      	orr	x1, x16, xzr
    960c:      	movz	x5, #0x0, lsl #48
    9610:      	b	0x9634 <_stogir.checked.operands+0x70>
    9614:      	movz	x14, #0x0, lsl #48
    9618:      	b	0x9698 <_stogir.checked.operands+0xd4>
    961c:      	movz	x14, #0x0, lsl #48
    9620:      	b	0x96ac <_stogir.checked.operands+0xe8>
    9624:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009624:  ARM64_RELOC_PAGE21	l_stogir.427
    9628:      	ldr	x16, [x16]
		0000000000009628:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    962c:      	orr	x1, x16, xzr
    9630:      	mov	x5, #0x36               ; =54
    9634:      	add	x16, sp, #0x10
    9638:      	orr	x6, x16, xzr
    963c:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		000000000000963c:  ARM64_RELOC_PAGE21	l_stogir.428
    9640:      	ldr	x16, [x16]
		0000000000009640:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    9644:      	orr	x7, x16, xzr
    9648:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009648:  ARM64_RELOC_PAGE21	l_stogir.429
    964c:      	ldr	x16, [x16]
		000000000000964c:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    9650:      	orr	x9, x16, xzr
    9654:      	lsr	w3, w3, #0
    9658:      	lsr	w4, w4, #0
    965c:      	add	x10, x0, #0x78
    9660:      	add	x11, x0, #0x28
    9664:      	add	x12, x0, #0x50
    9668:      	mov	x16, sp
    966c:      	str	w3, [x16]
    9670:      	mov	x16, sp
    9674:      	str	w4, [x16, #0x4]
    9678:      	mov	x16, sp
    967c:      	ldr	x3, [x16]
    9680:      	add	x16, sp, #0x10
    9684:      	str	x3, [x16]
    9688:      	mov	x3, x5
    968c:      	movz	x4, #0x0, lsl #48
    9690:      	b	0x975c <_stogir.checked.operands+0x198>
    9694:      	movz	x14, #0x0, lsl #48
    9698:      	fmov	d31, x13
    969c:      	mov	x13, x14
    96a0:      	fmov	x14, d31
    96a4:      	b	0x96b8 <_stogir.checked.operands+0xf4>
    96a8:      	movz	x14, #0x0, lsl #48
    96ac:      	fmov	d31, x13
    96b0:      	mov	x13, x14
    96b4:      	fmov	x14, d31
    96b8:      	cmp	x13, #0x0
    96bc:      	b.eq	0x96fc <_stogir.checked.operands+0x138>
    96c0:      	uxtb	w16, w4
    96c4:      	cmp	w16, wzr
    96c8:      	b.eq	0x96e0 <_stogir.checked.operands+0x11c>
    96cc:      	lsl	x4, x5, #4
    96d0:      	ldr	x5, [x0]
    96d4:      	add	x4, x4, x5
    96d8:      	ldr	x4, [x4]
    96dc:      	b	0x96f0 <_stogir.checked.operands+0x12c>
    96e0:      	lsl	x4, x15, #4
    96e4:      	ldr	x5, [x0, #0x28]
    96e8:      	add	x4, x4, x5
    96ec:      	ldr	x4, [x4]
    96f0:      	mov	x5, x4
    96f4:      	mov	x4, #0x1                ; =1
    96f8:      	b	0x9704 <_stogir.checked.operands+0x140>
    96fc:      	movz	x4, #0x0, lsl #48
    9700:      	movz	x5, #0x0, lsl #48
    9704:      	lsr	w4, w4, #0
    9708:      	lsr	x16, x4, #0
    970c:      	cmp	x16, #0x1
    9710:      	b.eq	0x972c <_stogir.checked.operands+0x168>
    9714:      	b.lo	0x971c <_stogir.checked.operands+0x158>
    9718:      	b	0x9730 <_stogir.checked.operands+0x16c>
    971c:      	cmp	x16, #0x0
    9720:      	b.eq	0x9728 <_stogir.checked.operands+0x164>
    9724:      	b	0x9730 <_stogir.checked.operands+0x16c>
    9728:      	b	0x9734 <_stogir.checked.operands+0x170>
    972c:      	b	0x9740 <_stogir.checked.operands+0x17c>
    9730:      	b	0x98c0 <_stogir.checked.operands+0x2fc>
    9734:      	mov	x1, x7
    9738:      	mov	x3, #0x22               ; =34
    973c:      	b	0x9758 <_stogir.checked.operands+0x194>
    9740:      	lsr	w5, w5, #0
    9744:      	ubfx	x4, x5, #8, #8
    9748:      	cmp	x4, x2
    974c:      	b.eq	0x9758 <_stogir.checked.operands+0x194>
    9750:      	mov	x1, x9
    9754:      	mov	x3, #0x28               ; =40
    9758:      	mov	x4, x14
    975c:      	cmp	x4, #0x2
    9760:      	b.ge	0x978c <_stogir.checked.operands+0x1c8>
    9764:      	add	x5, x4, #0x1
    9768:      	lsl	x4, x4, #2
    976c:      	add	x4, x4, x6
    9770:      	ldr	w4, [x4]
    9774:      	sxtw	x4, w4
    9778:      	and	x4, x4, #0xffffffff
    977c:      	mov	x13, x5
    9780:      	mov	x5, x4
    9784:      	mov	x4, #0x1                ; =1
    9788:      	b	0x9798 <_stogir.checked.operands+0x1d4>
    978c:      	mov	x13, x4
    9790:      	movz	x4, #0x0, lsl #48
    9794:      	movz	x5, #0x0, lsl #48
    9798:      	lsr	w4, w4, #0
    979c:      	lsr	x16, x4, #0
    97a0:      	cmp	x16, #0x1
    97a4:      	b.eq	0x97c0 <_stogir.checked.operands+0x1fc>
    97a8:      	b.lo	0x97b0 <_stogir.checked.operands+0x1ec>
    97ac:      	b	0x97c4 <_stogir.checked.operands+0x200>
    97b0:      	cmp	x16, #0x0
    97b4:      	b.eq	0x97bc <_stogir.checked.operands+0x1f8>
    97b8:      	b	0x97c4 <_stogir.checked.operands+0x200>
    97bc:      	b	0x982c <_stogir.checked.operands+0x268>
    97c0:      	b	0x97c8 <_stogir.checked.operands+0x204>
    97c4:      	b	0x98b8 <_stogir.checked.operands+0x2f4>
    97c8:      	lsr	w5, w5, #0
    97cc:      	sxtw	x5, w5
    97d0:      	cmp	x5, #0x0
    97d4:      	cset	w4, gt
    97d8:      	movz	x16, #0x0, lsl #48
    97dc:      	sub	x14, x16, x5
    97e0:      	sub	x15, x14, #0x1
    97e4:      	uxtb	w16, w4
    97e8:      	cmp	w16, wzr
    97ec:      	b.eq	0x986c <_stogir.checked.operands+0x2a8>
    97f0:      	ldr	x14, [x0, #0x8]
    97f4:      	cmp	x5, x14
    97f8:      	b.ge	0x9694 <_stogir.checked.operands+0xd0>
    97fc:      	ldr	x14, [x10, #0x8]
    9800:      	cmp	x5, x14
    9804:      	b.ge	0x9614 <_stogir.checked.operands+0x50>
    9808:      	lsl	x14, x5, #2
    980c:      	ldr	x19, [x0, #0x78]
    9810:      	add	x14, x14, x19
    9814:      	ldr	w14, [x14]
    9818:      	sxtw	x14, w14
    981c:      	cmp	x14, #0x0
    9820:      	cset	w14, ge
    9824:      	ubfx	x14, x14, #0, #8
    9828:      	b	0x9618 <_stogir.checked.operands+0x54>
    982c:      	cmp	x3, #0x0
    9830:      	b.ne	0x9848 <_stogir.checked.operands+0x284>
    9834:      	and	x0, x2, #0xffffffff
    9838:      	mov	x1, x0
    983c:      	movz	x0, #0x0, lsl #48
    9840:      	movz	x2, #0x0, lsl #48
    9844:      	b	0x9850 <_stogir.checked.operands+0x28c>
    9848:      	mov	x2, x3
    984c:      	mov	x0, #0x1                ; =1
    9850:      	str	x0, [x8]
    9854:      	str	x1, [x8, #0x8]
    9858:      	str	x2, [x8, #0x10]
    985c:      	ldr	x19, [sp, #0x20]
    9860:      	ldr	x20, [sp, #0x28]
    9864:      	add	sp, sp, #0x30
    9868:      	ret
    986c:      	cmp	x5, #0x0
    9870:      	b.ge	0x96a8 <_stogir.checked.operands+0xe4>
    9874:      	ldr	x19, [x11, #0x8]
    9878:      	ldr	x20, [x12, #0x8]
    987c:      	cmp	x19, x20
    9880:      	b.ne	0x961c <_stogir.checked.operands+0x58>
    9884:      	cmp	x14, x19
    9888:      	b.gt	0x98b0 <_stogir.checked.operands+0x2ec>
    988c:      	lsl	x14, x15, #2
    9890:      	ldr	x19, [x0, #0x50]
    9894:      	add	x14, x14, x19
    9898:      	ldr	w14, [x14]
    989c:      	sxtw	x14, w14
    98a0:      	cmp	x14, #0x0
    98a4:      	cset	w14, gt
    98a8:      	ubfx	x14, x14, #0, #8
    98ac:      	b	0x98b4 <_stogir.checked.operands+0x2f0>
    98b0:      	movz	x14, #0x0, lsl #48
    98b4:      	b	0x9620 <_stogir.checked.operands+0x5c>
    98b8:      	brk	#0
    98bc:      	b	0x98b8 <_stogir.checked.operands+0x2f4>
    98c0:      	brk	#0
    98c4:      	b	0x98c0 <_stogir.checked.operands+0x2fc>

00000000000098c8 <_stogir.opcode.control?>:
    98c8:      	sxtw	x0, w0
    98cc:      	cmp	x0, #0x0
    98d0:      	b.lt	0x98f8 <_stogir.opcode.control?+0x30>
    98d4:      	cmp	x0, #0x83
    98d8:      	b.ge	0x98f8 <_stogir.opcode.control?+0x30>
    98dc:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		00000000000098dc:  ARM64_RELOC_PAGE21	l_stogir.430
    98e0:      	ldr	x16, [x16]
		00000000000098e0:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    98e4:      	orr	x1, x16, xzr
    98e8:      	lsr	x0, x0, #0
    98ec:      	add	x0, x0, x1
    98f0:      	ldrb	w0, [x0]
    98f4:      	b	0x98fc <_stogir.opcode.control?+0x34>
    98f8:      	movz	x0, #0x0, lsl #48
    98fc:      	uxtb	w0, w0
    9900:      	and	x0, x0, #0x1
    9904:      	uxtb	w0, w0
    9908:      	ret

000000000000990c <_stogir.opcode.block-end?>:
    990c:      	sxtw	x0, w0
    9910:      	cmp	x0, #0x0
    9914:      	b.lt	0x993c <_stogir.opcode.block-end?+0x30>
    9918:      	cmp	x0, #0x83
    991c:      	b.ge	0x993c <_stogir.opcode.block-end?+0x30>
    9920:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009920:  ARM64_RELOC_PAGE21	l_stogir.431
    9924:      	ldr	x16, [x16]
		0000000000009924:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    9928:      	orr	x1, x16, xzr
    992c:      	lsr	x0, x0, #0
    9930:      	add	x0, x0, x1
    9934:      	ldrb	w0, [x0]
    9938:      	b	0x9940 <_stogir.opcode.block-end?+0x34>
    993c:      	movz	x0, #0x0, lsl #48
    9940:      	uxtb	w0, w0
    9944:      	and	x0, x0, #0x4
    9948:      	uxtb	w0, w0
    994c:      	cmp	x0, #0x0
    9950:      	cset	w0, eq
    9954:      	uxtb	w16, w0
    9958:      	cmp	w16, wzr
    995c:      	cset	x0, eq
    9960:      	ret

0000000000009964 <_stogir.atomic.ordinary?>:
    9964:      	sxtw	x1, w1
    9968:      	cmp	x1, #0x0
    996c:      	cset	w3, gt
    9970:      	movz	x16, #0x0, lsl #48
    9974:      	sub	x4, x16, x1
    9978:      	sub	x5, x4, #0x1
    997c:      	uxtb	w16, w3
    9980:      	cmp	w16, wzr
    9984:      	b.eq	0x99c8 <_stogir.atomic.ordinary?+0x64>
    9988:      	ldr	x4, [x0, #0x8]
    998c:      	cmp	x1, x4
    9990:      	b.ge	0x9a1c <_stogir.atomic.ordinary?+0xb8>
    9994:      	add	x4, x0, #0x78
    9998:      	ldr	x4, [x4, #0x8]
    999c:      	cmp	x1, x4
    99a0:      	b.ge	0x9adc <_stogir.atomic.ordinary?+0x178>
    99a4:      	lsl	x4, x1, #2
    99a8:      	ldr	x6, [x0, #0x78]
    99ac:      	add	x4, x4, x6
    99b0:      	ldr	w4, [x4]
    99b4:      	sxtw	x4, w4
    99b8:      	cmp	x4, #0x0
    99bc:      	cset	w4, ge
    99c0:      	ubfx	x4, x4, #0, #8
    99c4:      	b	0x9ae0 <_stogir.atomic.ordinary?+0x17c>
    99c8:      	cmp	x1, #0x0
    99cc:      	b.ge	0x9a24 <_stogir.atomic.ordinary?+0xc0>
    99d0:      	add	x6, x0, #0x28
    99d4:      	add	x7, x0, #0x50
    99d8:      	ldr	x6, [x6, #0x8]
    99dc:      	ldr	x7, [x7, #0x8]
    99e0:      	cmp	x6, x7
    99e4:      	b.ne	0x9a14 <_stogir.atomic.ordinary?+0xb0>
    99e8:      	cmp	x4, x6
    99ec:      	b.gt	0x9afc <_stogir.atomic.ordinary?+0x198>
    99f0:      	lsl	x4, x5, #2
    99f4:      	ldr	x6, [x0, #0x50]
    99f8:      	add	x4, x4, x6
    99fc:      	ldr	w4, [x4]
    9a00:      	sxtw	x4, w4
    9a04:      	cmp	x4, #0x0
    9a08:      	cset	w4, gt
    9a0c:      	ubfx	x4, x4, #0, #8
    9a10:      	b	0x9b00 <_stogir.atomic.ordinary?+0x19c>
    9a14:      	movz	x4, #0x0, lsl #48
    9a18:      	b	0x9a28 <_stogir.atomic.ordinary?+0xc4>
    9a1c:      	movz	x4, #0x0, lsl #48
    9a20:      	b	0x9a28 <_stogir.atomic.ordinary?+0xc4>
    9a24:      	movz	x4, #0x0, lsl #48
    9a28:      	cmp	x4, #0x0
    9a2c:      	b.eq	0x9a6c <_stogir.atomic.ordinary?+0x108>
    9a30:      	uxtb	w16, w3
    9a34:      	cmp	w16, wzr
    9a38:      	b.eq	0x9a50 <_stogir.atomic.ordinary?+0xec>
    9a3c:      	lsl	x1, x1, #4
    9a40:      	ldr	x0, [x0]
    9a44:      	add	x0, x1, x0
    9a48:      	ldr	x0, [x0]
    9a4c:      	b	0x9a60 <_stogir.atomic.ordinary?+0xfc>
    9a50:      	lsl	x1, x5, #4
    9a54:      	ldr	x0, [x0, #0x28]
    9a58:      	add	x0, x1, x0
    9a5c:      	ldr	x0, [x0]
    9a60:      	mov	x1, x0
    9a64:      	mov	x0, #0x1                ; =1
    9a68:      	b	0x9a74 <_stogir.atomic.ordinary?+0x110>
    9a6c:      	movz	x0, #0x0, lsl #48
    9a70:      	movz	x1, #0x0, lsl #48
    9a74:      	lsr	w0, w0, #0
    9a78:      	lsr	x16, x0, #0
    9a7c:      	cmp	x16, #0x1
    9a80:      	b.eq	0x9a9c <_stogir.atomic.ordinary?+0x138>
    9a84:      	b.lo	0x9a8c <_stogir.atomic.ordinary?+0x128>
    9a88:      	b	0x9aa0 <_stogir.atomic.ordinary?+0x13c>
    9a8c:      	cmp	x16, #0x0
    9a90:      	b.eq	0x9a98 <_stogir.atomic.ordinary?+0x134>
    9a94:      	b	0x9aa0 <_stogir.atomic.ordinary?+0x13c>
    9a98:      	b	0x9aa4 <_stogir.atomic.ordinary?+0x140>
    9a9c:      	b	0x9ab4 <_stogir.atomic.ordinary?+0x150>
    9aa0:      	b	0x9b04 <_stogir.atomic.ordinary?+0x1a0>
    9aa4:      	movz	x0, #0x0, lsl #48
    9aa8:      	b	0x9ab0 <_stogir.atomic.ordinary?+0x14c>
    9aac:      	movz	x0, #0x0, lsl #48
    9ab0:      	ret
    9ab4:      	sxtw	x2, w2
    9ab8:      	lsr	w0, w1, #0
    9abc:      	ubfx	x0, x0, #8, #8
    9ac0:      	cmp	x0, x2
    9ac4:      	b.ne	0x9aac <_stogir.atomic.ordinary?+0x148>
    9ac8:      	uxtb	w1, w1
    9acc:      	cmp	x1, #0x46
    9ad0:      	b.ne	0x9ae4 <_stogir.atomic.ordinary?+0x180>
    9ad4:      	movz	x0, #0x0, lsl #48
    9ad8:      	b	0x9af8 <_stogir.atomic.ordinary?+0x194>
    9adc:      	movz	x4, #0x0, lsl #48
    9ae0:      	b	0x9a20 <_stogir.atomic.ordinary?+0xbc>
    9ae4:      	cmp	x1, #0x48
    9ae8:      	cset	w0, eq
    9aec:      	uxtb	w16, w0
    9af0:      	cmp	w16, wzr
    9af4:      	cset	x0, eq
    9af8:      	b	0x9ab0 <_stogir.atomic.ordinary?+0x14c>
    9afc:      	movz	x4, #0x0, lsl #48
    9b00:      	b	0x9a18 <_stogir.atomic.ordinary?+0xb4>
    9b04:      	brk	#0
    9b08:      	b	0x9b04 <_stogir.atomic.ordinary?+0x1a0>

0000000000009b0c <_stogir.types.scalar-size>:
    9b0c:      	sxtw	x1, w1
    9b10:      	cmp	x1, #0x4
    9b14:      	b.eq	0x9b28 <_stogir.types.scalar-size+0x1c>
    9b18:      	cmp	x1, #0x8
    9b1c:      	b.eq	0x9b28 <_stogir.types.scalar-size+0x1c>
    9b20:      	movn	x0, #0x0, lsl #48
    9b24:      	b	0x9b40 <_stogir.types.scalar-size+0x34>
    9b28:      	sxtw	x0, w0
    9b2c:      	cmp	x0, #0x0
    9b30:      	b.ne	0x9b44 <_stogir.types.scalar-size+0x38>
    9b34:      	movz	x0, #0x0, lsl #48
    9b38:      	b	0x9b40 <_stogir.types.scalar-size+0x34>
    9b3c:      	mov	x0, #0x1                ; =1
    9b40:      	ret
    9b44:      	cmp	x0, #0x1
    9b48:      	b.eq	0x9b3c <_stogir.types.scalar-size+0x30>
    9b4c:      	cmp	x0, #0x2
    9b50:      	b.eq	0x9b3c <_stogir.types.scalar-size+0x30>
    9b54:      	cmp	x0, #0x7
    9b58:      	b.eq	0x9b3c <_stogir.types.scalar-size+0x30>
    9b5c:      	cmp	x0, #0x8
    9b60:      	b.eq	0x9b3c <_stogir.types.scalar-size+0x30>
    9b64:      	cmp	x0, #0x3
    9b68:      	b.eq	0x9bb4 <_stogir.types.scalar-size+0xa8>
    9b6c:      	cmp	x0, #0x9
    9b70:      	b.eq	0x9bb4 <_stogir.types.scalar-size+0xa8>
    9b74:      	cmp	x0, #0x4
    9b78:      	b.eq	0x9bbc <_stogir.types.scalar-size+0xb0>
    9b7c:      	cmp	x0, #0xa
    9b80:      	b.eq	0x9bbc <_stogir.types.scalar-size+0xb0>
    9b84:      	cmp	x0, #0xd
    9b88:      	b.eq	0x9bbc <_stogir.types.scalar-size+0xb0>
    9b8c:      	cmp	x0, #0x5
    9b90:      	b.eq	0x9bc4 <_stogir.types.scalar-size+0xb8>
    9b94:      	cmp	x0, #0xb
    9b98:      	b.eq	0x9bc4 <_stogir.types.scalar-size+0xb8>
    9b9c:      	cmp	x0, #0xc
    9ba0:      	b.eq	0x9bc4 <_stogir.types.scalar-size+0xb8>
    9ba4:      	cmp	x0, #0x6
    9ba8:      	b.ne	0x9bcc <_stogir.types.scalar-size+0xc0>
    9bac:      	mov	x0, x1
    9bb0:      	b	0x9bd0 <_stogir.types.scalar-size+0xc4>
    9bb4:      	mov	x0, #0x2                ; =2
    9bb8:      	b	0x9b40 <_stogir.types.scalar-size+0x34>
    9bbc:      	mov	x0, #0x4                ; =4
    9bc0:      	b	0x9bb8 <_stogir.types.scalar-size+0xac>
    9bc4:      	mov	x0, #0x8                ; =8
    9bc8:      	b	0x9bc0 <_stogir.types.scalar-size+0xb4>
    9bcc:      	movn	x0, #0x0, lsl #48
    9bd0:      	b	0x9bc8 <_stogir.types.scalar-size+0xbc>

0000000000009bd4 <_stogir.terminal.inputs>:
    9bd4:      	sxtw	x1, w1
    9bd8:      	cmp	x1, #0x60
    9bdc:      	cset	w4, eq
    9be0:      	uxtb	w16, w4
    9be4:      	cmp	w16, wzr
    9be8:      	b.ne	0x9c1c <_stogir.terminal.inputs+0x48>
    9bec:      	cmp	x1, #0x79
    9bf0:      	b.eq	0x9c1c <_stogir.terminal.inputs+0x48>
    9bf4:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009bf4:  ARM64_RELOC_PAGE21	l_stogir.432
    9bf8:      	ldr	x16, [x16]
		0000000000009bf8:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    9bfc:      	orr	x0, x16, xzr
    9c00:      	mov	x1, x0
    9c04:      	mov	x0, #0x1                ; =1
    9c08:      	mov	x2, #0x25               ; =37
    9c0c:      	str	x0, [x8]
    9c10:      	str	x1, [x8, #0x8]
    9c14:      	str	x2, [x8, #0x10]
    9c18:      	ret
    9c1c:      	sxtw	x3, w3
    9c20:      	uxtb	w16, w4
    9c24:      	cmp	w16, wzr
    9c28:      	b.eq	0x9c34 <_stogir.terminal.inputs+0x60>
    9c2c:      	cmp	x3, #0x0
    9c30:      	b.ne	0x9bf4 <_stogir.terminal.inputs+0x20>
    9c34:      	sxtw	x2, w2
    9c38:      	cmp	x2, #0x0
    9c3c:      	cset	w1, gt
    9c40:      	movz	x16, #0x0, lsl #48
    9c44:      	sub	x4, x16, x2
    9c48:      	sub	x5, x4, #0x1
    9c4c:      	uxtb	w16, w1
    9c50:      	cmp	w16, wzr
    9c54:      	b.eq	0x9d3c <_stogir.terminal.inputs+0x168>
    9c58:      	ldr	x4, [x0, #0x8]
    9c5c:      	cmp	x2, x4
    9c60:      	b.ge	0x9d34 <_stogir.terminal.inputs+0x160>
    9c64:      	add	x4, x0, #0x78
    9c68:      	ldr	x4, [x4, #0x8]
    9c6c:      	cmp	x2, x4
    9c70:      	b.ge	0x9de4 <_stogir.terminal.inputs+0x210>
    9c74:      	lsl	x4, x2, #2
    9c78:      	ldr	x6, [x0, #0x78]
    9c7c:      	add	x4, x4, x6
    9c80:      	ldr	w4, [x4]
    9c84:      	sxtw	x4, w4
    9c88:      	cmp	x4, #0x0
    9c8c:      	cset	w4, ge
    9c90:      	ubfx	x4, x4, #0, #8
    9c94:      	b	0x9de8 <_stogir.terminal.inputs+0x214>
    9c98:      	movz	x1, #0x0, lsl #48
    9c9c:      	movz	x4, #0x0, lsl #48
    9ca0:      	lsr	w1, w1, #0
    9ca4:      	lsr	x16, x1, #0
    9ca8:      	cmp	x16, #0x1
    9cac:      	b.eq	0x9cc8 <_stogir.terminal.inputs+0xf4>
    9cb0:      	b.lo	0x9cb8 <_stogir.terminal.inputs+0xe4>
    9cb4:      	b	0x9ccc <_stogir.terminal.inputs+0xf8>
    9cb8:      	cmp	x16, #0x0
    9cbc:      	b.eq	0x9cc4 <_stogir.terminal.inputs+0xf0>
    9cc0:      	b	0x9ccc <_stogir.terminal.inputs+0xf8>
    9cc4:      	b	0x9cd0 <_stogir.terminal.inputs+0xfc>
    9cc8:      	b	0x9d88 <_stogir.terminal.inputs+0x1b4>
    9ccc:      	b	0x9f3c <_stogir.terminal.inputs+0x368>
    9cd0:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009cd0:  ARM64_RELOC_PAGE21	l_stogir.433
    9cd4:      	ldr	x16, [x16]
		0000000000009cd4:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    9cd8:      	orr	x0, x16, xzr
    9cdc:      	mov	x1, x0
    9ce0:      	mov	x0, #0x1                ; =1
    9ce4:      	mov	x2, #0x1d               ; =29
    9ce8:      	b	0x9c0c <_stogir.terminal.inputs+0x38>
    9cec:      	lsl	x1, x5, #4
    9cf0:      	ldr	x4, [x0, #0x28]
    9cf4:      	add	x1, x1, x4
    9cf8:      	ldr	x1, [x1]
    9cfc:      	mov	x4, x1
    9d00:      	mov	x1, #0x1                ; =1
    9d04:      	b	0x9ca0 <_stogir.terminal.inputs+0xcc>
    9d08:      	movz	x4, #0x0, lsl #48
    9d0c:      	cmp	x4, #0x0
    9d10:      	b.eq	0x9c98 <_stogir.terminal.inputs+0xc4>
    9d14:      	uxtb	w16, w1
    9d18:      	cmp	w16, wzr
    9d1c:      	b.eq	0x9cec <_stogir.terminal.inputs+0x118>
    9d20:      	lsl	x1, x2, #4
    9d24:      	ldr	x4, [x0]
    9d28:      	add	x1, x1, x4
    9d2c:      	ldr	x1, [x1]
    9d30:      	b	0x9cfc <_stogir.terminal.inputs+0x128>
    9d34:      	movz	x4, #0x0, lsl #48
    9d38:      	b	0x9d0c <_stogir.terminal.inputs+0x138>
    9d3c:      	cmp	x2, #0x0
    9d40:      	b.ge	0x9d08 <_stogir.terminal.inputs+0x134>
    9d44:      	add	x6, x0, #0x28
    9d48:      	add	x7, x0, #0x50
    9d4c:      	ldr	x6, [x6, #0x8]
    9d50:      	ldr	x7, [x7, #0x8]
    9d54:      	cmp	x6, x7
    9d58:      	b.ne	0x9ddc <_stogir.terminal.inputs+0x208>
    9d5c:      	cmp	x4, x6
    9d60:      	b.gt	0x9dec <_stogir.terminal.inputs+0x218>
    9d64:      	lsl	x4, x5, #2
    9d68:      	ldr	x6, [x0, #0x50]
    9d6c:      	add	x4, x4, x6
    9d70:      	ldr	w4, [x4]
    9d74:      	sxtw	x4, w4
    9d78:      	cmp	x4, #0x0
    9d7c:      	cset	w4, gt
    9d80:      	ubfx	x4, x4, #0, #8
    9d84:      	b	0x9df0 <_stogir.terminal.inputs+0x21c>
    9d88:      	cmp	x2, #0x0
    9d8c:      	b.le	0x9dc0 <_stogir.terminal.inputs+0x1ec>
    9d90:      	uxtb	w4, w4
    9d94:      	cmp	x4, #0x83
    9d98:      	cset	w1, lt
    9d9c:      	uxtb	w16, w1
    9da0:      	cmp	w16, wzr
    9da4:      	b.eq	0x9df4 <_stogir.terminal.inputs+0x220>
    9da8:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009da8:  ARM64_RELOC_PAGE21	l_stogir.434
    9dac:      	ldr	x16, [x16]
		0000000000009dac:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    9db0:      	orr	x2, x16, xzr
    9db4:      	add	x2, x4, x2
    9db8:      	ldrb	w2, [x2]
    9dbc:      	b	0x9df8 <_stogir.terminal.inputs+0x224>
    9dc0:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009dc0:  ARM64_RELOC_PAGE21	l_stogir.435
    9dc4:      	ldr	x16, [x16]
		0000000000009dc4:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    9dc8:      	orr	x0, x16, xzr
    9dcc:      	mov	x1, x0
    9dd0:      	mov	x0, #0x1                ; =1
    9dd4:      	mov	x2, #0x2c               ; =44
    9dd8:      	b	0x9ce8 <_stogir.terminal.inputs+0x114>
    9ddc:      	movz	x4, #0x0, lsl #48
    9de0:      	b	0x9d0c <_stogir.terminal.inputs+0x138>
    9de4:      	movz	x4, #0x0, lsl #48
    9de8:      	b	0x9d38 <_stogir.terminal.inputs+0x164>
    9dec:      	movz	x4, #0x0, lsl #48
    9df0:      	b	0x9de0 <_stogir.terminal.inputs+0x20c>
    9df4:      	movz	x2, #0x0, lsl #48
    9df8:      	uxtb	w2, w2
    9dfc:      	and	x2, x2, #0x1
    9e00:      	uxtb	w2, w2
    9e04:      	cmp	x2, #0x0
    9e08:      	b.eq	0x9dc0 <_stogir.terminal.inputs+0x1ec>
    9e0c:      	uxtb	w16, w1
    9e10:      	cmp	w16, wzr
    9e14:      	b.eq	0x9e30 <_stogir.terminal.inputs+0x25c>
    9e18:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009e18:  ARM64_RELOC_PAGE21	l_stogir.434
    9e1c:      	ldr	x16, [x16]
		0000000000009e1c:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    9e20:      	orr	x1, x16, xzr
    9e24:      	add	x1, x4, x1
    9e28:      	ldrb	w1, [x1]
    9e2c:      	b	0x9e34 <_stogir.terminal.inputs+0x260>
    9e30:      	movz	x1, #0x0, lsl #48
    9e34:      	uxtb	w1, w1
    9e38:      	and	x1, x1, #0x4
    9e3c:      	uxtb	w1, w1
    9e40:      	cmp	x1, #0x0
    9e44:      	cset	w1, eq
    9e48:      	uxtb	w16, w1
    9e4c:      	cmp	w16, wzr
    9e50:      	cset	x1, eq
    9e54:      	cmp	x1, #0x0
    9e58:      	b.ne	0x9dc0 <_stogir.terminal.inputs+0x1ec>
    9e5c:      	cmp	x3, #0x0
    9e60:      	b.ne	0x9e74 <_stogir.terminal.inputs+0x2a0>
    9e64:      	movz	x0, #0x0, lsl #48
    9e68:      	movz	x1, #0x0, lsl #48
    9e6c:      	movz	x2, #0x0, lsl #48
    9e70:      	b	0x9dd8 <_stogir.terminal.inputs+0x204>
    9e74:      	cmp	x3, #0x0
    9e78:      	cset	w1, gt
    9e7c:      	movz	x16, #0x0, lsl #48
    9e80:      	sub	x2, x16, x3
    9e84:      	sub	x4, x2, #0x1
    9e88:      	uxtb	w16, w1
    9e8c:      	cmp	w16, wzr
    9e90:      	b.eq	0x9ef0 <_stogir.terminal.inputs+0x31c>
    9e94:      	ldr	x2, [x0, #0x8]
    9e98:      	cmp	x3, x2
    9e9c:      	b.ge	0x9f44 <_stogir.terminal.inputs+0x370>
    9ea0:      	add	x2, x0, #0x78
    9ea4:      	ldr	x2, [x2, #0x8]
    9ea8:      	cmp	x3, x2
    9eac:      	b.ge	0xa01c <_stogir.terminal.inputs+0x448>
    9eb0:      	lsl	x2, x3, #2
    9eb4:      	ldr	x5, [x0, #0x78]
    9eb8:      	add	x2, x2, x5
    9ebc:      	ldr	w2, [x2]
    9ec0:      	sxtw	x2, w2
    9ec4:      	cmp	x2, #0x0
    9ec8:      	cset	w2, ge
    9ecc:      	ubfx	x2, x2, #0, #8
    9ed0:      	b	0xa020 <_stogir.terminal.inputs+0x44c>
    9ed4:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009ed4:  ARM64_RELOC_PAGE21	l_stogir.436
    9ed8:      	ldr	x16, [x16]
		0000000000009ed8:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    9edc:      	orr	x0, x16, xzr
    9ee0:      	mov	x1, x0
    9ee4:      	mov	x0, #0x1                ; =1
    9ee8:      	mov	x2, #0x2e               ; =46
    9eec:      	b	0x9e70 <_stogir.terminal.inputs+0x29c>
    9ef0:      	cmp	x3, #0x0
    9ef4:      	b.ge	0x9f4c <_stogir.terminal.inputs+0x378>
    9ef8:      	add	x5, x0, #0x28
    9efc:      	add	x6, x0, #0x50
    9f00:      	ldr	x5, [x5, #0x8]
    9f04:      	ldr	x6, [x6, #0x8]
    9f08:      	cmp	x5, x6
    9f0c:      	b.ne	0xa014 <_stogir.terminal.inputs+0x440>
    9f10:      	cmp	x2, x5
    9f14:      	b.gt	0xa024 <_stogir.terminal.inputs+0x450>
    9f18:      	lsl	x2, x4, #2
    9f1c:      	ldr	x5, [x0, #0x50]
    9f20:      	add	x2, x2, x5
    9f24:      	ldr	w2, [x2]
    9f28:      	sxtw	x2, w2
    9f2c:      	cmp	x2, #0x0
    9f30:      	cset	w2, gt
    9f34:      	ubfx	x2, x2, #0, #8
    9f38:      	b	0xa028 <_stogir.terminal.inputs+0x454>
    9f3c:      	brk	#0
    9f40:      	b	0x9f3c <_stogir.terminal.inputs+0x368>
    9f44:      	movz	x2, #0x0, lsl #48
    9f48:      	b	0x9f50 <_stogir.terminal.inputs+0x37c>
    9f4c:      	movz	x2, #0x0, lsl #48
    9f50:      	cmp	x2, #0x0
    9f54:      	b.eq	0x9f94 <_stogir.terminal.inputs+0x3c0>
    9f58:      	uxtb	w16, w1
    9f5c:      	cmp	w16, wzr
    9f60:      	b.eq	0x9f78 <_stogir.terminal.inputs+0x3a4>
    9f64:      	lsl	x1, x3, #4
    9f68:      	ldr	x0, [x0]
    9f6c:      	add	x0, x1, x0
    9f70:      	ldr	x0, [x0]
    9f74:      	b	0x9f88 <_stogir.terminal.inputs+0x3b4>
    9f78:      	lsl	x1, x4, #4
    9f7c:      	ldr	x0, [x0, #0x28]
    9f80:      	add	x0, x1, x0
    9f84:      	ldr	x0, [x0]
    9f88:      	mov	x1, x0
    9f8c:      	mov	x0, #0x1                ; =1
    9f90:      	b	0x9f9c <_stogir.terminal.inputs+0x3c8>
    9f94:      	movz	x0, #0x0, lsl #48
    9f98:      	movz	x1, #0x0, lsl #48
    9f9c:      	lsr	w0, w0, #0
    9fa0:      	lsr	x16, x0, #0
    9fa4:      	cmp	x16, #0x1
    9fa8:      	b.eq	0x9fc4 <_stogir.terminal.inputs+0x3f0>
    9fac:      	b.lo	0x9fb4 <_stogir.terminal.inputs+0x3e0>
    9fb0:      	b	0x9fc8 <_stogir.terminal.inputs+0x3f4>
    9fb4:      	cmp	x16, #0x0
    9fb8:      	b.eq	0x9fc0 <_stogir.terminal.inputs+0x3ec>
    9fbc:      	b	0x9fc8 <_stogir.terminal.inputs+0x3f4>
    9fc0:      	b	0x9fcc <_stogir.terminal.inputs+0x3f8>
    9fc4:      	b	0x9fe8 <_stogir.terminal.inputs+0x414>
    9fc8:      	b	0xa06c <_stogir.terminal.inputs+0x498>
    9fcc:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009fcc:  ARM64_RELOC_PAGE21	l_stogir.437
    9fd0:      	ldr	x16, [x16]
		0000000000009fd0:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    9fd4:      	orr	x0, x16, xzr
    9fd8:      	mov	x1, x0
    9fdc:      	mov	x0, #0x1                ; =1
    9fe0:      	mov	x2, #0x1d               ; =29
    9fe4:      	b	0x9eec <_stogir.terminal.inputs+0x318>
    9fe8:      	cmp	x3, #0x0
    9fec:      	b.le	0x9ed4 <_stogir.terminal.inputs+0x300>
    9ff0:      	uxtb	w1, w1
    9ff4:      	cmp	x1, #0x83
    9ff8:      	b.ge	0xa02c <_stogir.terminal.inputs+0x458>
    9ffc:      	adrp	x16, 0x9000 <_stogir.types.size+0x2c>
		0000000000009ffc:  ARM64_RELOC_PAGE21	l_stogir.434
    a000:      	ldr	x16, [x16]
		000000000000a000:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a004:      	orr	x0, x16, xzr
    a008:      	add	x0, x1, x0
    a00c:      	ldrb	w0, [x0]
    a010:      	b	0xa030 <_stogir.terminal.inputs+0x45c>
    a014:      	movz	x2, #0x0, lsl #48
    a018:      	b	0x9f50 <_stogir.terminal.inputs+0x37c>
    a01c:      	movz	x2, #0x0, lsl #48
    a020:      	b	0x9f48 <_stogir.terminal.inputs+0x374>
    a024:      	movz	x2, #0x0, lsl #48
    a028:      	b	0xa018 <_stogir.terminal.inputs+0x444>
    a02c:      	movz	x0, #0x0, lsl #48
    a030:      	uxtb	w0, w0
    a034:      	and	x0, x0, #0x8
    a038:      	uxtb	w0, w0
    a03c:      	cmp	x0, #0x0
    a040:      	cset	w0, eq
    a044:      	uxtb	w16, w0
    a048:      	cmp	w16, wzr
    a04c:      	cset	x0, eq
    a050:      	cmp	x0, #0x0
    a054:      	b.eq	0x9ed4 <_stogir.terminal.inputs+0x300>
    a058:      	and	x0, x3, #0xffffffff
    a05c:      	mov	x1, x0
    a060:      	movz	x0, #0x0, lsl #48
    a064:      	movz	x2, #0x0, lsl #48
    a068:      	b	0x9eec <_stogir.terminal.inputs+0x318>
    a06c:      	brk	#0
    a070:      	b	0xa06c <_stogir.terminal.inputs+0x498>

000000000000a074 <_stogir.switch.switch-inputs>:
    a074:      	sxtw	x1, w1
    a078:      	cmp	x1, #0x0
    a07c:      	cset	w3, gt
    a080:      	movz	x16, #0x0, lsl #48
    a084:      	sub	x4, x16, x1
    a088:      	sub	x5, x4, #0x1
    a08c:      	uxtb	w16, w3
    a090:      	cmp	w16, wzr
    a094:      	b.eq	0xa0d8 <_stogir.switch.switch-inputs+0x64>
    a098:      	ldr	x4, [x0, #0x8]
    a09c:      	cmp	x1, x4
    a0a0:      	b.ge	0xa148 <_stogir.switch.switch-inputs+0xd4>
    a0a4:      	add	x4, x0, #0x78
    a0a8:      	ldr	x4, [x4, #0x8]
    a0ac:      	cmp	x1, x4
    a0b0:      	b.ge	0xa230 <_stogir.switch.switch-inputs+0x1bc>
    a0b4:      	lsl	x4, x1, #2
    a0b8:      	ldr	x6, [x0, #0x78]
    a0bc:      	add	x4, x4, x6
    a0c0:      	ldr	w4, [x4]
    a0c4:      	sxtw	x4, w4
    a0c8:      	cmp	x4, #0x0
    a0cc:      	cset	w4, ge
    a0d0:      	ubfx	x4, x4, #0, #8
    a0d4:      	b	0xa234 <_stogir.switch.switch-inputs+0x1c0>
    a0d8:      	cmp	x1, #0x0
    a0dc:      	b.ge	0xa150 <_stogir.switch.switch-inputs+0xdc>
    a0e0:      	add	x6, x0, #0x28
    a0e4:      	add	x7, x0, #0x50
    a0e8:      	ldr	x6, [x6, #0x8]
    a0ec:      	ldr	x7, [x7, #0x8]
    a0f0:      	cmp	x6, x7
    a0f4:      	b.ne	0xa124 <_stogir.switch.switch-inputs+0xb0>
    a0f8:      	cmp	x4, x6
    a0fc:      	b.gt	0xa238 <_stogir.switch.switch-inputs+0x1c4>
    a100:      	lsl	x4, x5, #2
    a104:      	ldr	x6, [x0, #0x50]
    a108:      	add	x4, x4, x6
    a10c:      	ldr	w4, [x4]
    a110:      	sxtw	x4, w4
    a114:      	cmp	x4, #0x0
    a118:      	cset	w4, gt
    a11c:      	ubfx	x4, x4, #0, #8
    a120:      	b	0xa23c <_stogir.switch.switch-inputs+0x1c8>
    a124:      	movz	x4, #0x0, lsl #48
    a128:      	b	0xa154 <_stogir.switch.switch-inputs+0xe0>
    a12c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a12c:  ARM64_RELOC_PAGE21	l_stogir.438
    a130:      	ldr	x16, [x16]
		000000000000a130:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    a134:      	orr	x0, x16, xzr
    a138:      	mov	x1, x0
    a13c:      	mov	x0, #0x1                ; =1
    a140:      	mov	x2, #0x16               ; =22
    a144:      	b	0xa1e8 <_stogir.switch.switch-inputs+0x174>
    a148:      	movz	x4, #0x0, lsl #48
    a14c:      	b	0xa154 <_stogir.switch.switch-inputs+0xe0>
    a150:      	movz	x4, #0x0, lsl #48
    a154:      	cmp	x4, #0x0
    a158:      	b.eq	0xa198 <_stogir.switch.switch-inputs+0x124>
    a15c:      	uxtb	w16, w3
    a160:      	cmp	w16, wzr
    a164:      	b.eq	0xa17c <_stogir.switch.switch-inputs+0x108>
    a168:      	lsl	x3, x1, #4
    a16c:      	ldr	x4, [x0]
    a170:      	add	x3, x3, x4
    a174:      	ldr	x3, [x3]
    a178:      	b	0xa18c <_stogir.switch.switch-inputs+0x118>
    a17c:      	lsl	x3, x5, #4
    a180:      	ldr	x4, [x0, #0x28]
    a184:      	add	x3, x3, x4
    a188:      	ldr	x3, [x3]
    a18c:      	mov	x4, x3
    a190:      	mov	x3, #0x1                ; =1
    a194:      	b	0xa1a0 <_stogir.switch.switch-inputs+0x12c>
    a198:      	movz	x3, #0x0, lsl #48
    a19c:      	movz	x4, #0x0, lsl #48
    a1a0:      	lsr	w3, w3, #0
    a1a4:      	lsr	x16, x3, #0
    a1a8:      	cmp	x16, #0x1
    a1ac:      	b.eq	0xa1c8 <_stogir.switch.switch-inputs+0x154>
    a1b0:      	b.lo	0xa1b8 <_stogir.switch.switch-inputs+0x144>
    a1b4:      	b	0xa1cc <_stogir.switch.switch-inputs+0x158>
    a1b8:      	cmp	x16, #0x0
    a1bc:      	b.eq	0xa1c4 <_stogir.switch.switch-inputs+0x150>
    a1c0:      	b	0xa1cc <_stogir.switch.switch-inputs+0x158>
    a1c4:      	b	0xa1d0 <_stogir.switch.switch-inputs+0x15c>
    a1c8:      	b	0xa1f8 <_stogir.switch.switch-inputs+0x184>
    a1cc:      	b	0xa460 <_stogir.switch.switch-inputs+0x3ec>
    a1d0:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a1d0:  ARM64_RELOC_PAGE21	l_stogir.439
    a1d4:      	ldr	x16, [x16]
		000000000000a1d4:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    a1d8:      	orr	x0, x16, xzr
    a1dc:      	mov	x1, x0
    a1e0:      	mov	x0, #0x1                ; =1
    a1e4:      	mov	x2, #0x16               ; =22
    a1e8:      	str	x0, [x8]
    a1ec:      	str	x1, [x8, #0x8]
    a1f0:      	str	x2, [x8, #0x10]
    a1f4:      	ret
    a1f8:      	cmp	x1, #0x0
    a1fc:      	b.le	0xa12c <_stogir.switch.switch-inputs+0xb8>
    a200:      	uxtb	w4, w4
    a204:      	cmp	x4, #0x83
    a208:      	cset	w1, lt
    a20c:      	uxtb	w16, w1
    a210:      	cmp	w16, wzr
    a214:      	b.eq	0xa240 <_stogir.switch.switch-inputs+0x1cc>
    a218:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a218:  ARM64_RELOC_PAGE21	l_stogir.440
    a21c:      	ldr	x16, [x16]
		000000000000a21c:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a220:      	orr	x3, x16, xzr
    a224:      	add	x3, x4, x3
    a228:      	ldrb	w3, [x3]
    a22c:      	b	0xa244 <_stogir.switch.switch-inputs+0x1d0>
    a230:      	movz	x4, #0x0, lsl #48
    a234:      	b	0xa14c <_stogir.switch.switch-inputs+0xd8>
    a238:      	movz	x4, #0x0, lsl #48
    a23c:      	b	0xa128 <_stogir.switch.switch-inputs+0xb4>
    a240:      	movz	x3, #0x0, lsl #48
    a244:      	uxtb	w3, w3
    a248:      	and	x3, x3, #0x1
    a24c:      	uxtb	w3, w3
    a250:      	cmp	x3, #0x0
    a254:      	b.eq	0xa12c <_stogir.switch.switch-inputs+0xb8>
    a258:      	uxtb	w16, w1
    a25c:      	cmp	w16, wzr
    a260:      	b.eq	0xa27c <_stogir.switch.switch-inputs+0x208>
    a264:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a264:  ARM64_RELOC_PAGE21	l_stogir.440
    a268:      	ldr	x16, [x16]
		000000000000a268:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a26c:      	orr	x1, x16, xzr
    a270:      	add	x1, x4, x1
    a274:      	ldrb	w1, [x1]
    a278:      	b	0xa280 <_stogir.switch.switch-inputs+0x20c>
    a27c:      	movz	x1, #0x0, lsl #48
    a280:      	uxtb	w1, w1
    a284:      	and	x1, x1, #0x4
    a288:      	uxtb	w1, w1
    a28c:      	cmp	x1, #0x0
    a290:      	cset	w1, eq
    a294:      	uxtb	w16, w1
    a298:      	cmp	w16, wzr
    a29c:      	cset	x1, eq
    a2a0:      	cmp	x1, #0x0
    a2a4:      	b.ne	0xa12c <_stogir.switch.switch-inputs+0xb8>
    a2a8:      	sxtw	x2, w2
    a2ac:      	cmp	x2, #0x0
    a2b0:      	cset	w1, gt
    a2b4:      	movz	x16, #0x0, lsl #48
    a2b8:      	sub	x3, x16, x2
    a2bc:      	sub	x4, x3, #0x1
    a2c0:      	uxtb	w16, w1
    a2c4:      	cmp	w16, wzr
    a2c8:      	b.eq	0xa328 <_stogir.switch.switch-inputs+0x2b4>
    a2cc:      	ldr	x3, [x0, #0x8]
    a2d0:      	cmp	x2, x3
    a2d4:      	b.ge	0xa374 <_stogir.switch.switch-inputs+0x300>
    a2d8:      	add	x3, x0, #0x78
    a2dc:      	ldr	x3, [x3, #0x8]
    a2e0:      	cmp	x2, x3
    a2e4:      	b.ge	0xa458 <_stogir.switch.switch-inputs+0x3e4>
    a2e8:      	lsl	x3, x2, #2
    a2ec:      	ldr	x5, [x0, #0x78]
    a2f0:      	add	x3, x3, x5
    a2f4:      	ldr	w3, [x3]
    a2f8:      	sxtw	x3, w3
    a2fc:      	cmp	x3, #0x0
    a300:      	cset	w3, ge
    a304:      	ubfx	x3, x3, #0, #8
    a308:      	b	0xa45c <_stogir.switch.switch-inputs+0x3e8>
    a30c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a30c:  ARM64_RELOC_PAGE21	l_stogir.441
    a310:      	ldr	x16, [x16]
		000000000000a310:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    a314:      	orr	x0, x16, xzr
    a318:      	mov	x1, x0
    a31c:      	mov	x0, #0x1                ; =1
    a320:      	mov	x2, #0x20               ; =32
    a324:      	b	0xa144 <_stogir.switch.switch-inputs+0xd0>
    a328:      	cmp	x2, #0x0
    a32c:      	b.ge	0xa37c <_stogir.switch.switch-inputs+0x308>
    a330:      	add	x5, x0, #0x28
    a334:      	add	x6, x0, #0x50
    a338:      	ldr	x5, [x5, #0x8]
    a33c:      	ldr	x6, [x6, #0x8]
    a340:      	cmp	x5, x6
    a344:      	b.ne	0xa450 <_stogir.switch.switch-inputs+0x3dc>
    a348:      	cmp	x3, x5
    a34c:      	b.gt	0xa468 <_stogir.switch.switch-inputs+0x3f4>
    a350:      	lsl	x3, x4, #2
    a354:      	ldr	x5, [x0, #0x50]
    a358:      	add	x3, x3, x5
    a35c:      	ldr	w3, [x3]
    a360:      	sxtw	x3, w3
    a364:      	cmp	x3, #0x0
    a368:      	cset	w3, gt
    a36c:      	ubfx	x3, x3, #0, #8
    a370:      	b	0xa46c <_stogir.switch.switch-inputs+0x3f8>
    a374:      	movz	x3, #0x0, lsl #48
    a378:      	b	0xa380 <_stogir.switch.switch-inputs+0x30c>
    a37c:      	movz	x3, #0x0, lsl #48
    a380:      	cmp	x3, #0x0
    a384:      	b.eq	0xa3c4 <_stogir.switch.switch-inputs+0x350>
    a388:      	uxtb	w16, w1
    a38c:      	cmp	w16, wzr
    a390:      	b.eq	0xa3a8 <_stogir.switch.switch-inputs+0x334>
    a394:      	lsl	x1, x2, #4
    a398:      	ldr	x0, [x0]
    a39c:      	add	x0, x1, x0
    a3a0:      	ldr	x0, [x0]
    a3a4:      	b	0xa3b8 <_stogir.switch.switch-inputs+0x344>
    a3a8:      	lsl	x1, x4, #4
    a3ac:      	ldr	x0, [x0, #0x28]
    a3b0:      	add	x0, x1, x0
    a3b4:      	ldr	x0, [x0]
    a3b8:      	mov	x1, x0
    a3bc:      	mov	x0, #0x1                ; =1
    a3c0:      	b	0xa3cc <_stogir.switch.switch-inputs+0x358>
    a3c4:      	movz	x0, #0x0, lsl #48
    a3c8:      	movz	x1, #0x0, lsl #48
    a3cc:      	lsr	w0, w0, #0
    a3d0:      	lsr	x16, x0, #0
    a3d4:      	cmp	x16, #0x1
    a3d8:      	b.eq	0xa3f4 <_stogir.switch.switch-inputs+0x380>
    a3dc:      	b.lo	0xa3e4 <_stogir.switch.switch-inputs+0x370>
    a3e0:      	b	0xa3f8 <_stogir.switch.switch-inputs+0x384>
    a3e4:      	cmp	x16, #0x0
    a3e8:      	b.eq	0xa3f0 <_stogir.switch.switch-inputs+0x37c>
    a3ec:      	b	0xa3f8 <_stogir.switch.switch-inputs+0x384>
    a3f0:      	b	0xa3fc <_stogir.switch.switch-inputs+0x388>
    a3f4:      	b	0xa418 <_stogir.switch.switch-inputs+0x3a4>
    a3f8:      	b	0xa470 <_stogir.switch.switch-inputs+0x3fc>
    a3fc:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a3fc:  ARM64_RELOC_PAGE21	l_stogir.442
    a400:      	ldr	x16, [x16]
		000000000000a400:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    a404:      	orr	x0, x16, xzr
    a408:      	mov	x1, x0
    a40c:      	mov	x0, #0x1                ; =1
    a410:      	mov	x2, #0x17               ; =23
    a414:      	b	0xa324 <_stogir.switch.switch-inputs+0x2b0>
    a418:      	lsr	w0, w1, #0
    a41c:      	ubfx	x0, x0, #8, #8
    a420:      	cmp	x0, #0x1
    a424:      	b.lt	0xa30c <_stogir.switch.switch-inputs+0x298>
    a428:      	cmp	x0, #0xb
    a42c:      	b.gt	0xa30c <_stogir.switch.switch-inputs+0x298>
    a430:      	uxtb	w1, w1
    a434:      	cmp	x1, #0x48
    a438:      	b.eq	0xa30c <_stogir.switch.switch-inputs+0x298>
    a43c:      	and	x0, x0, #0xffffffff
    a440:      	mov	x1, x0
    a444:      	movz	x0, #0x0, lsl #48
    a448:      	movz	x2, #0x0, lsl #48
    a44c:      	b	0xa324 <_stogir.switch.switch-inputs+0x2b0>
    a450:      	movz	x3, #0x0, lsl #48
    a454:      	b	0xa380 <_stogir.switch.switch-inputs+0x30c>
    a458:      	movz	x3, #0x0, lsl #48
    a45c:      	b	0xa378 <_stogir.switch.switch-inputs+0x304>
    a460:      	brk	#0
    a464:      	b	0xa460 <_stogir.switch.switch-inputs+0x3ec>
    a468:      	movz	x3, #0x0, lsl #48
    a46c:      	b	0xa454 <_stogir.switch.switch-inputs+0x3e0>
    a470:      	brk	#0
    a474:      	b	0xa470 <_stogir.switch.switch-inputs+0x3fc>

000000000000a478 <_stogir.switch.case-inputs>:
    a478:      	sub	sp, sp, #0xb0
    a47c:      	str	x29, [sp]
    a480:      	str	x30, [sp, #0x8]
    a484:      	mov	x29, sp
    a488:      	str	x19, [sp, #0x70]
    a48c:      	str	x20, [sp, #0x78]
    a490:      	str	x21, [sp, #0x80]
    a494:      	str	x22, [sp, #0x88]
    a498:      	str	x23, [sp, #0x90]
    a49c:      	str	x24, [sp, #0x98]
    a4a0:      	str	x25, [sp, #0xa0]
    a4a4:      	str	x26, [sp, #0xa8]
    a4a8:      	sxtw	x2, w2
    a4ac:      	lsl	x5, x2, #2
    a4b0:      	cmp	x2, #0x0
    a4b4:      	cset	w6, gt
    a4b8:      	movz	x16, #0x0, lsl #48
    a4bc:      	sub	x7, x16, x2
    a4c0:      	sub	x9, x7, #0x1
    a4c4:      	uxtb	w16, w6
    a4c8:      	cmp	w16, wzr
    a4cc:      	b.eq	0xa50c <_stogir.switch.case-inputs+0x94>
    a4d0:      	ldr	x7, [x0, #0x8]
    a4d4:      	cmp	x2, x7
    a4d8:      	b.ge	0xa560 <_stogir.switch.case-inputs+0xe8>
    a4dc:      	add	x7, x0, #0x78
    a4e0:      	ldr	x7, [x7, #0x8]
    a4e4:      	cmp	x2, x7
    a4e8:      	b.ge	0xa690 <_stogir.switch.case-inputs+0x218>
    a4ec:      	ldr	x7, [x0, #0x78]
    a4f0:      	add	x7, x5, x7
    a4f4:      	ldr	w7, [x7]
    a4f8:      	sxtw	x7, w7
    a4fc:      	cmp	x7, #0x0
    a500:      	cset	w7, ge
    a504:      	ubfx	x7, x7, #0, #8
    a508:      	b	0xa694 <_stogir.switch.case-inputs+0x21c>
    a50c:      	cmp	x2, #0x0
    a510:      	b.ge	0xa568 <_stogir.switch.case-inputs+0xf0>
    a514:      	add	x10, x0, #0x28
    a518:      	add	x11, x0, #0x50
    a51c:      	ldr	x10, [x10, #0x8]
    a520:      	ldr	x11, [x11, #0x8]
    a524:      	cmp	x10, x11
    a528:      	b.ne	0xa558 <_stogir.switch.case-inputs+0xe0>
    a52c:      	cmp	x7, x10
    a530:      	b.gt	0xa764 <_stogir.switch.case-inputs+0x2ec>
    a534:      	lsl	x7, x9, #2
    a538:      	ldr	x10, [x0, #0x50]
    a53c:      	add	x7, x7, x10
    a540:      	ldr	w7, [x7]
    a544:      	sxtw	x7, w7
    a548:      	cmp	x7, #0x0
    a54c:      	cset	w7, gt
    a550:      	ubfx	x7, x7, #0, #8
    a554:      	b	0xa768 <_stogir.switch.case-inputs+0x2f0>
    a558:      	movz	x7, #0x0, lsl #48
    a55c:      	b	0xa56c <_stogir.switch.case-inputs+0xf4>
    a560:      	movz	x7, #0x0, lsl #48
    a564:      	b	0xa56c <_stogir.switch.case-inputs+0xf4>
    a568:      	movz	x7, #0x0, lsl #48
    a56c:      	cmp	x7, #0x0
    a570:      	b.eq	0xa5d4 <_stogir.switch.case-inputs+0x15c>
    a574:      	uxtb	w16, w6
    a578:      	cmp	w16, wzr
    a57c:      	b.eq	0xa5a4 <_stogir.switch.case-inputs+0x12c>
    a580:      	lsl	x6, x2, #4
    a584:      	ldr	x7, [x0]
    a588:      	add	x6, x6, x7
    a58c:      	ldr	x7, [x6]
    a590:      	ldr	x6, [x6, #0x8]
    a594:      	fmov	d31, x6
    a598:      	mov	x6, x7
    a59c:      	fmov	x7, d31
    a5a0:      	b	0xa5c4 <_stogir.switch.case-inputs+0x14c>
    a5a4:      	lsl	x6, x9, #4
    a5a8:      	ldr	x7, [x0, #0x28]
    a5ac:      	add	x6, x6, x7
    a5b0:      	ldr	x7, [x6]
    a5b4:      	ldr	x6, [x6, #0x8]
    a5b8:      	fmov	d31, x6
    a5bc:      	mov	x6, x7
    a5c0:      	fmov	x7, d31
    a5c4:      	mov	x9, x7
    a5c8:      	mov	x7, x6
    a5cc:      	mov	x6, #0x1                ; =1
    a5d0:      	b	0xa5e0 <_stogir.switch.case-inputs+0x168>
    a5d4:      	movz	x6, #0x0, lsl #48
    a5d8:      	movz	x7, #0x0, lsl #48
    a5dc:      	movz	x9, #0x0, lsl #48
    a5e0:      	lsr	w6, w6, #0
    a5e4:      	lsr	x16, x6, #0
    a5e8:      	cmp	x16, #0x1
    a5ec:      	b.eq	0xa608 <_stogir.switch.case-inputs+0x190>
    a5f0:      	b.lo	0xa5f8 <_stogir.switch.case-inputs+0x180>
    a5f4:      	b	0xa60c <_stogir.switch.case-inputs+0x194>
    a5f8:      	cmp	x16, #0x0
    a5fc:      	b.eq	0xa604 <_stogir.switch.case-inputs+0x18c>
    a600:      	b	0xa60c <_stogir.switch.case-inputs+0x194>
    a604:      	b	0xa610 <_stogir.switch.case-inputs+0x198>
    a608:      	b	0xa668 <_stogir.switch.case-inputs+0x1f0>
    a60c:      	b	0xa76c <_stogir.switch.case-inputs+0x2f4>
    a610:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a610:  ARM64_RELOC_PAGE21	l_stogir.443
    a614:      	ldr	x16, [x16]
		000000000000a614:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    a618:      	orr	x0, x16, xzr
    a61c:      	mov	x21, x8
    a620:      	mov	x1, x0
    a624:      	mov	x0, #0x1                ; =1
    a628:      	mov	x2, #0x1a               ; =26
    a62c:      	str	x0, [x21]
    a630:      	str	x1, [x21, #0x8]
    a634:      	str	x2, [x21, #0x10]
    a638:      	ldr	x19, [sp, #0x70]
    a63c:      	ldr	x20, [sp, #0x78]
    a640:      	ldr	x21, [sp, #0x80]
    a644:      	ldr	x22, [sp, #0x88]
    a648:      	ldr	x23, [sp, #0x90]
    a64c:      	ldr	x24, [sp, #0x98]
    a650:      	ldr	x25, [sp, #0xa0]
    a654:      	ldr	x26, [sp, #0xa8]
    a658:      	ldr	x29, [sp]
    a65c:      	ldr	x30, [sp, #0x8]
    a660:      	add	sp, sp, #0xb0
    a664:      	ret
    a668:      	cmp	x2, #0x0
    a66c:      	b.gt	0xa698 <_stogir.switch.case-inputs+0x220>
    a670:      	mov	x21, x8
    a674:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a674:  ARM64_RELOC_PAGE21	l_stogir.444
    a678:      	ldr	x16, [x16]
		000000000000a678:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    a67c:      	orr	x0, x16, xzr
    a680:      	mov	x1, x0
    a684:      	mov	x0, #0x1                ; =1
    a688:      	mov	x2, #0x1f               ; =31
    a68c:      	b	0xa62c <_stogir.switch.case-inputs+0x1b4>
    a690:      	movz	x7, #0x0, lsl #48
    a694:      	b	0xa564 <_stogir.switch.case-inputs+0xec>
    a698:      	uxtb	w2, w7
    a69c:      	cmp	x2, #0x75
    a6a0:      	b.ne	0xa8fc <_stogir.switch.case-inputs+0x484>
    a6a4:      	lsr	w2, w7, #0
    a6a8:      	ubfx	x2, x2, #8, #8
    a6ac:      	cmp	x2, #0x0
    a6b0:      	b.ne	0xa904 <_stogir.switch.case-inputs+0x48c>
    a6b4:      	ldr	x2, [x0, #0x78]
    a6b8:      	add	x2, x5, x2
    a6bc:      	ldr	w2, [x2]
    a6c0:      	sxtw	x2, w2
    a6c4:      	cmp	x2, #0x2
    a6c8:      	b.ne	0xa90c <_stogir.switch.case-inputs+0x494>
    a6cc:      	sxtw	x19, w1
    a6d0:      	cmp	x19, #0x6d
    a6d4:      	b.lt	0xa914 <_stogir.switch.case-inputs+0x49c>
    a6d8:      	cmp	x19, #0x6f
    a6dc:      	b.gt	0xa91c <_stogir.switch.case-inputs+0x4a4>
    a6e0:      	add	x16, sp, #0x10
    a6e4:      	orr	x20, x16, xzr
    a6e8:      	lsr	w9, w9, #0
    a6ec:      	lsr	x1, x7, #32
    a6f0:      	lsr	w9, w9, #0
    a6f4:      	lsr	w1, w1, #0
    a6f8:      	mov	w2, w9
    a6fc:      	mov	x21, x8
    a700:      	add	x8, sp, #0x10
    a704:      	mov	x22, x0
    a708:      	mov	w23, w3
    a70c:      	mov	w24, w4
    a710:      	bl	0xa710 <_stogir.switch.case-inputs+0x298>
		000000000000a710:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    a714:      	add	x16, sp, #0x10
    a718:      	ldr	w0, [x16]
    a71c:      	lsr	x16, x0, #0
    a720:      	cmp	x16, #0x1
    a724:      	b.eq	0xa740 <_stogir.switch.case-inputs+0x2c8>
    a728:      	b.lo	0xa730 <_stogir.switch.case-inputs+0x2b8>
    a72c:      	b	0xa744 <_stogir.switch.case-inputs+0x2cc>
    a730:      	cmp	x16, #0x0
    a734:      	b.eq	0xa73c <_stogir.switch.case-inputs+0x2c4>
    a738:      	b	0xa744 <_stogir.switch.case-inputs+0x2cc>
    a73c:      	b	0xa774 <_stogir.switch.case-inputs+0x2fc>
    a740:      	b	0xa748 <_stogir.switch.case-inputs+0x2d0>
    a744:      	b	0xa8e4 <_stogir.switch.case-inputs+0x46c>
    a748:      	add	x0, x20, #0x8
    a74c:      	add	x16, sp, #0x10
    a750:      	ldr	x1, [x16, #0x8]
    a754:      	ldr	x0, [x0, #0x8]
    a758:      	mov	x2, x0
    a75c:      	mov	x0, #0x1                ; =1
    a760:      	b	0xa68c <_stogir.switch.case-inputs+0x214>
    a764:      	movz	x7, #0x0, lsl #48
    a768:      	b	0xa55c <_stogir.switch.case-inputs+0xe4>
    a76c:      	brk	#0
    a770:      	b	0xa76c <_stogir.switch.case-inputs+0x2f4>
    a774:      	add	x16, sp, #0x10
    a778:      	ldr	w20, [x16, #0x8]
    a77c:      	sxtw	x0, w20
    a780:      	and	x25, x0, #0xffffffff
    a784:      	cmp	x19, #0x6f
    a788:      	b.ne	0xa79c <_stogir.switch.case-inputs+0x324>
    a78c:      	mov	x1, x25
    a790:      	movz	x0, #0x0, lsl #48
    a794:      	movz	x2, #0x0, lsl #48
    a798:      	b	0xa760 <_stogir.switch.case-inputs+0x2e8>
    a79c:      	add	x16, sp, #0x30
    a7a0:      	orr	x26, x16, xzr
    a7a4:      	lsr	w23, w23, #0
    a7a8:      	lsr	w20, w20, #0
    a7ac:      	add	x8, sp, #0x30
    a7b0:      	mov	x0, x22
    a7b4:      	mov	w1, w23
    a7b8:      	mov	w2, w20
    a7bc:      	bl	0xa7bc <_stogir.switch.case-inputs+0x344>
		000000000000a7bc:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    a7c0:      	add	x16, sp, #0x30
    a7c4:      	ldr	w0, [x16]
    a7c8:      	lsr	x16, x0, #0
    a7cc:      	cmp	x16, #0x1
    a7d0:      	b.eq	0xa7ec <_stogir.switch.case-inputs+0x374>
    a7d4:      	b.lo	0xa7dc <_stogir.switch.case-inputs+0x364>
    a7d8:      	b	0xa7f0 <_stogir.switch.case-inputs+0x378>
    a7dc:      	cmp	x16, #0x0
    a7e0:      	b.eq	0xa7e8 <_stogir.switch.case-inputs+0x370>
    a7e4:      	b	0xa7f0 <_stogir.switch.case-inputs+0x378>
    a7e8:      	b	0xa810 <_stogir.switch.case-inputs+0x398>
    a7ec:      	b	0xa7f4 <_stogir.switch.case-inputs+0x37c>
    a7f0:      	b	0xa8ec <_stogir.switch.case-inputs+0x474>
    a7f4:      	add	x0, x26, #0x8
    a7f8:      	add	x16, sp, #0x30
    a7fc:      	ldr	x1, [x16, #0x8]
    a800:      	ldr	x0, [x0, #0x8]
    a804:      	mov	x2, x0
    a808:      	mov	x0, #0x1                ; =1
    a80c:      	b	0xa798 <_stogir.switch.case-inputs+0x320>
    a810:      	add	x16, sp, #0x30
    a814:      	ldr	x26, [x16, #0x8]
    a818:      	cmp	x19, #0x6d
    a81c:      	b.ne	0xa83c <_stogir.switch.case-inputs+0x3c4>
    a820:      	sxtw	x23, w23
    a824:      	mov	x0, x23
    a828:      	b	0xa844 <_stogir.switch.case-inputs+0x3cc>
    a82c:      	mov	x1, x25
    a830:      	movz	x0, #0x0, lsl #48
    a834:      	movz	x2, #0x0, lsl #48
    a838:      	b	0xa80c <_stogir.switch.case-inputs+0x394>
    a83c:      	sxtw	x24, w24
    a840:      	mov	x0, x24
    a844:      	add	x16, sp, #0x50
    a848:      	orr	x19, x16, xzr
    a84c:      	lsr	w20, w20, #0
    a850:      	lsr	w0, w0, #0
    a854:      	add	x8, sp, #0x50
    a858:      	mov	w1, w0
    a85c:      	mov	x0, x22
    a860:      	mov	w2, w20
    a864:      	bl	0xa864 <_stogir.switch.case-inputs+0x3ec>
		000000000000a864:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    a868:      	add	x16, sp, #0x50
    a86c:      	ldr	w0, [x16]
    a870:      	lsr	x16, x0, #0
    a874:      	cmp	x16, #0x1
    a878:      	b.eq	0xa894 <_stogir.switch.case-inputs+0x41c>
    a87c:      	b.lo	0xa884 <_stogir.switch.case-inputs+0x40c>
    a880:      	b	0xa898 <_stogir.switch.case-inputs+0x420>
    a884:      	cmp	x16, #0x0
    a888:      	b.eq	0xa890 <_stogir.switch.case-inputs+0x418>
    a88c:      	b	0xa898 <_stogir.switch.case-inputs+0x420>
    a890:      	b	0xa8b8 <_stogir.switch.case-inputs+0x440>
    a894:      	b	0xa89c <_stogir.switch.case-inputs+0x424>
    a898:      	b	0xa8f4 <_stogir.switch.case-inputs+0x47c>
    a89c:      	add	x0, x19, #0x8
    a8a0:      	add	x16, sp, #0x50
    a8a4:      	ldr	x1, [x16, #0x8]
    a8a8:      	ldr	x0, [x0, #0x8]
    a8ac:      	mov	x2, x0
    a8b0:      	mov	x0, #0x1                ; =1
    a8b4:      	b	0xa838 <_stogir.switch.case-inputs+0x3c0>
    a8b8:      	add	x16, sp, #0x50
    a8bc:      	ldr	x0, [x16, #0x8]
    a8c0:      	cmp	x26, x0
    a8c4:      	b.ls	0xa82c <_stogir.switch.case-inputs+0x3b4>
    a8c8:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000a8c8:  ARM64_RELOC_PAGE21	l_stogir.445
    a8cc:      	ldr	x16, [x16]
		000000000000a8cc:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    a8d0:      	orr	x0, x16, xzr
    a8d4:      	mov	x1, x0
    a8d8:      	mov	x0, #0x1                ; =1
    a8dc:      	mov	x2, #0x1a               ; =26
    a8e0:      	b	0xa838 <_stogir.switch.case-inputs+0x3c0>
    a8e4:      	brk	#0
    a8e8:      	b	0xa8e4 <_stogir.switch.case-inputs+0x46c>
    a8ec:      	brk	#0
    a8f0:      	b	0xa8ec <_stogir.switch.case-inputs+0x474>
    a8f4:      	brk	#0
    a8f8:      	b	0xa8f4 <_stogir.switch.case-inputs+0x47c>
    a8fc:      	mov	x21, x8
    a900:      	b	0xa674 <_stogir.switch.case-inputs+0x1fc>
    a904:      	mov	x21, x8
    a908:      	b	0xa674 <_stogir.switch.case-inputs+0x1fc>
    a90c:      	mov	x21, x8
    a910:      	b	0xa674 <_stogir.switch.case-inputs+0x1fc>
    a914:      	mov	x21, x8
    a918:      	b	0xa674 <_stogir.switch.case-inputs+0x1fc>
    a91c:      	mov	x21, x8
    a920:      	b	0xa674 <_stogir.switch.case-inputs+0x1fc>

000000000000a924 <_stogir.stack.validate-frame-address>:
    a924:      	sxtw	x1, w1
    a928:      	lsl	x2, x1, #2
    a92c:      	cmp	x1, #0x0
    a930:      	cset	w3, gt
    a934:      	movz	x16, #0x0, lsl #48
    a938:      	sub	x4, x16, x1
    a93c:      	sub	x5, x4, #0x1
    a940:      	uxtb	w16, w3
    a944:      	cmp	w16, wzr
    a948:      	b.eq	0xa988 <_stogir.stack.validate-frame-address+0x64>
    a94c:      	ldr	x4, [x0, #0x8]
    a950:      	cmp	x1, x4
    a954:      	b.ge	0xa9dc <_stogir.stack.validate-frame-address+0xb8>
    a958:      	add	x4, x0, #0x78
    a95c:      	ldr	x4, [x4, #0x8]
    a960:      	cmp	x1, x4
    a964:      	b.ge	0xaaf4 <_stogir.stack.validate-frame-address+0x1d0>
    a968:      	ldr	x4, [x0, #0x78]
    a96c:      	add	x4, x2, x4
    a970:      	ldr	w4, [x4]
    a974:      	sxtw	x4, w4
    a978:      	cmp	x4, #0x0
    a97c:      	cset	w4, ge
    a980:      	ubfx	x4, x4, #0, #8
    a984:      	b	0xaaf8 <_stogir.stack.validate-frame-address+0x1d4>
    a988:      	cmp	x1, #0x0
    a98c:      	b.ge	0xa9e4 <_stogir.stack.validate-frame-address+0xc0>
    a990:      	add	x6, x0, #0x28
    a994:      	add	x7, x0, #0x50
    a998:      	ldr	x6, [x6, #0x8]
    a99c:      	ldr	x7, [x7, #0x8]
    a9a0:      	cmp	x6, x7
    a9a4:      	b.ne	0xa9d4 <_stogir.stack.validate-frame-address+0xb0>
    a9a8:      	cmp	x4, x6
    a9ac:      	b.gt	0xaafc <_stogir.stack.validate-frame-address+0x1d8>
    a9b0:      	lsl	x4, x5, #2
    a9b4:      	ldr	x6, [x0, #0x50]
    a9b8:      	add	x4, x4, x6
    a9bc:      	ldr	w4, [x4]
    a9c0:      	sxtw	x4, w4
    a9c4:      	cmp	x4, #0x0
    a9c8:      	cset	w4, gt
    a9cc:      	ubfx	x4, x4, #0, #8
    a9d0:      	b	0xab00 <_stogir.stack.validate-frame-address+0x1dc>
    a9d4:      	movz	x4, #0x0, lsl #48
    a9d8:      	b	0xa9e8 <_stogir.stack.validate-frame-address+0xc4>
    a9dc:      	movz	x4, #0x0, lsl #48
    a9e0:      	b	0xa9e8 <_stogir.stack.validate-frame-address+0xc4>
    a9e4:      	movz	x4, #0x0, lsl #48
    a9e8:      	cmp	x4, #0x0
    a9ec:      	b.eq	0xaa2c <_stogir.stack.validate-frame-address+0x108>
    a9f0:      	uxtb	w16, w3
    a9f4:      	cmp	w16, wzr
    a9f8:      	b.eq	0xaa10 <_stogir.stack.validate-frame-address+0xec>
    a9fc:      	lsl	x3, x1, #4
    aa00:      	ldr	x4, [x0]
    aa04:      	add	x3, x3, x4
    aa08:      	ldr	x3, [x3]
    aa0c:      	b	0xaa20 <_stogir.stack.validate-frame-address+0xfc>
    aa10:      	lsl	x3, x5, #4
    aa14:      	ldr	x4, [x0, #0x28]
    aa18:      	add	x3, x3, x4
    aa1c:      	ldr	x3, [x3]
    aa20:      	mov	x4, x3
    aa24:      	mov	x3, #0x1                ; =1
    aa28:      	b	0xaa34 <_stogir.stack.validate-frame-address+0x110>
    aa2c:      	movz	x3, #0x0, lsl #48
    aa30:      	movz	x4, #0x0, lsl #48
    aa34:      	lsr	w3, w3, #0
    aa38:      	lsr	x16, x3, #0
    aa3c:      	cmp	x16, #0x1
    aa40:      	b.eq	0xaa5c <_stogir.stack.validate-frame-address+0x138>
    aa44:      	b.lo	0xaa4c <_stogir.stack.validate-frame-address+0x128>
    aa48:      	b	0xaa60 <_stogir.stack.validate-frame-address+0x13c>
    aa4c:      	cmp	x16, #0x0
    aa50:      	b.eq	0xaa58 <_stogir.stack.validate-frame-address+0x134>
    aa54:      	b	0xaa60 <_stogir.stack.validate-frame-address+0x13c>
    aa58:      	b	0xaa64 <_stogir.stack.validate-frame-address+0x140>
    aa5c:      	b	0xaaa8 <_stogir.stack.validate-frame-address+0x184>
    aa60:      	b	0xab04 <_stogir.stack.validate-frame-address+0x1e0>
    aa64:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000aa64:  ARM64_RELOC_PAGE21	l_stogir.446
    aa68:      	ldr	x16, [x16]
		000000000000aa68:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    aa6c:      	orr	x0, x16, xzr
    aa70:      	mov	x1, x0
    aa74:      	mov	x0, #0x1                ; =1
    aa78:      	mov	x2, #0x21               ; =33
    aa7c:      	b	0xaa98 <_stogir.stack.validate-frame-address+0x174>
    aa80:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000aa80:  ARM64_RELOC_PAGE21	l_stogir.447
    aa84:      	ldr	x16, [x16]
		000000000000aa84:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    aa88:      	orr	x0, x16, xzr
    aa8c:      	mov	x1, x0
    aa90:      	mov	x0, #0x1                ; =1
    aa94:      	mov	x2, #0x1e               ; =30
    aa98:      	str	x0, [x8]
    aa9c:      	str	x1, [x8, #0x8]
    aaa0:      	str	x2, [x8, #0x10]
    aaa4:      	ret
    aaa8:      	cmp	x1, #0x0
    aaac:      	b.le	0xaa80 <_stogir.stack.validate-frame-address+0x15c>
    aab0:      	uxtb	w1, w4
    aab4:      	cmp	x1, #0x42
    aab8:      	b.ne	0xaa80 <_stogir.stack.validate-frame-address+0x15c>
    aabc:      	lsr	w4, w4, #0
    aac0:      	ubfx	x1, x4, #8, #8
    aac4:      	cmp	x1, #0x6
    aac8:      	b.ne	0xaa80 <_stogir.stack.validate-frame-address+0x15c>
    aacc:      	ldr	x0, [x0, #0x78]
    aad0:      	add	x0, x2, x0
    aad4:      	ldr	w0, [x0]
    aad8:      	sxtw	x0, w0
    aadc:      	cmp	x0, #0x0
    aae0:      	b.ne	0xaa80 <_stogir.stack.validate-frame-address+0x15c>
    aae4:      	movz	x0, #0x0, lsl #48
    aae8:      	mov	x1, #0x8                ; =8
    aaec:      	movz	x2, #0x0, lsl #48
    aaf0:      	b	0xaa98 <_stogir.stack.validate-frame-address+0x174>
    aaf4:      	movz	x4, #0x0, lsl #48
    aaf8:      	b	0xa9e0 <_stogir.stack.validate-frame-address+0xbc>
    aafc:      	movz	x4, #0x0, lsl #48
    ab00:      	b	0xa9d8 <_stogir.stack.validate-frame-address+0xb4>
    ab04:      	brk	#0
    ab08:      	b	0xab04 <_stogir.stack.validate-frame-address+0x1e0>

000000000000ab0c <_stogir.stack.frame-object?>:
    ab0c:      	ldr	w0, [x0]
    ab10:      	uxtb	w1, w0
    ab14:      	cmp	x1, #0x51
    ab18:      	b.ne	0xab30 <_stogir.stack.frame-object?+0x24>
    ab1c:      	ubfx	x0, x0, #16, #16
    ab20:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    ab24:      	cset	w0, eq
    ab28:      	ubfx	x0, x0, #0, #8
    ab2c:      	b	0xab34 <_stogir.stack.frame-object?+0x28>
    ab30:      	movz	x0, #0x0, lsl #48
    ab34:      	ret

000000000000ab38 <_stogir.stack.valid-frame-object-inputs?>:
    ab38:      	sub	sp, sp, #0x50
    ab3c:      	str	x29, [sp]
    ab40:      	str	x30, [sp, #0x8]
    ab44:      	mov	x29, sp
    ab48:      	str	x19, [sp, #0x30]
    ab4c:      	str	x20, [sp, #0x38]
    ab50:      	str	x21, [sp, #0x40]
    ab54:      	add	x3, x0, #0x78
    ab58:      	add	x4, x0, #0x28
    ab5c:      	add	x5, x0, #0x50
    ab60:      	add	x6, x0, #0x78
    ab64:      	add	x7, x0, #0x28
    ab68:      	add	x8, x0, #0x50
    ab6c:      	sxtw	x1, w1
    ab70:      	mov	x9, sp
    ab74:      	sub	sp, sp, #0x10
    ab78:      	mov	x10, sp
    ab7c:      	mov	x12, x1
    ab80:      	mov	x1, #0x1                ; =1
    ab84:      	movz	x11, #0x0, lsl #48
    ab88:      	b	0xacd8 <_stogir.stack.valid-frame-object-inputs?+0x1a0>
    ab8c:      	movz	x15, #0x0, lsl #48
    ab90:      	b	0xac08 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    ab94:      	movz	x13, #0x0, lsl #48
    ab98:      	movz	x14, #0x0, lsl #48
    ab9c:      	lsr	w13, w13, #0
    aba0:      	lsr	x16, x13, #0
    aba4:      	cmp	x16, #0x1
    aba8:      	b.eq	0xabc4 <_stogir.stack.valid-frame-object-inputs?+0x8c>
    abac:      	b.lo	0xabb4 <_stogir.stack.valid-frame-object-inputs?+0x7c>
    abb0:      	b	0xabc8 <_stogir.stack.valid-frame-object-inputs?+0x90>
    abb4:      	cmp	x16, #0x0
    abb8:      	b.eq	0xabc0 <_stogir.stack.valid-frame-object-inputs?+0x88>
    abbc:      	b	0xabc8 <_stogir.stack.valid-frame-object-inputs?+0x90>
    abc0:      	b	0xabe8 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    abc4:      	b	0xabcc <_stogir.stack.valid-frame-object-inputs?+0x94>
    abc8:      	b	0xafc0 <_stogir.stack.valid-frame-object-inputs?+0x488>
    abcc:      	uxtb	w13, w14
    abd0:      	lsr	w14, w14, #0
    abd4:      	ubfx	x14, x14, #8, #8
    abd8:      	cmp	x13, x14
    abdc:      	b.eq	0xafac <_stogir.stack.valid-frame-object-inputs?+0x474>
    abe0:      	cmp	x13, #0x49
    abe4:      	b.eq	0xafac <_stogir.stack.valid-frame-object-inputs?+0x474>
    abe8:      	movz	x1, #0x0, lsl #48
    abec:      	fmov	d31, x11
    abf0:      	mov	x11, x12
    abf4:      	fmov	x12, d31
    abf8:      	b	0xadbc <_stogir.stack.valid-frame-object-inputs?+0x284>
    abfc:      	movz	x15, #0x0, lsl #48
    ac00:      	b	0xac10 <_stogir.stack.valid-frame-object-inputs?+0xd8>
    ac04:      	movz	x15, #0x0, lsl #48
    ac08:      	b	0xac18 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    ac0c:      	movz	x15, #0x0, lsl #48
    ac10:      	b	0xac18 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    ac14:      	movz	x15, #0x0, lsl #48
    ac18:      	cmp	x15, #0x0
    ac1c:      	b.eq	0xac80 <_stogir.stack.valid-frame-object-inputs?+0x148>
    ac20:      	uxtb	w16, w14
    ac24:      	cmp	w16, wzr
    ac28:      	b.eq	0xac50 <_stogir.stack.valid-frame-object-inputs?+0x118>
    ac2c:      	lsl	x13, x13, #4
    ac30:      	ldr	x14, [x0]
    ac34:      	add	x13, x13, x14
    ac38:      	ldr	x14, [x13]
    ac3c:      	ldr	x13, [x13, #0x8]
    ac40:      	fmov	d31, x13
    ac44:      	mov	x13, x14
    ac48:      	fmov	x14, d31
    ac4c:      	b	0xac70 <_stogir.stack.valid-frame-object-inputs?+0x138>
    ac50:      	lsl	x13, x19, #4
    ac54:      	ldr	x14, [x0, #0x28]
    ac58:      	add	x13, x13, x14
    ac5c:      	ldr	x14, [x13]
    ac60:      	ldr	x13, [x13, #0x8]
    ac64:      	fmov	d31, x13
    ac68:      	mov	x13, x14
    ac6c:      	fmov	x14, d31
    ac70:      	mov	x15, x14
    ac74:      	mov	x14, x13
    ac78:      	mov	x13, #0x1               ; =1
    ac7c:      	b	0xac8c <_stogir.stack.valid-frame-object-inputs?+0x154>
    ac80:      	movz	x13, #0x0, lsl #48
    ac84:      	movz	x14, #0x0, lsl #48
    ac88:      	movz	x15, #0x0, lsl #48
    ac8c:      	lsr	w13, w13, #0
    ac90:      	lsr	x16, x13, #0
    ac94:      	cmp	x16, #0x1
    ac98:      	b.eq	0xacb4 <_stogir.stack.valid-frame-object-inputs?+0x17c>
    ac9c:      	b.lo	0xaca4 <_stogir.stack.valid-frame-object-inputs?+0x16c>
    aca0:      	b	0xacb8 <_stogir.stack.valid-frame-object-inputs?+0x180>
    aca4:      	cmp	x16, #0x0
    aca8:      	b.eq	0xacb0 <_stogir.stack.valid-frame-object-inputs?+0x178>
    acac:      	b	0xacb8 <_stogir.stack.valid-frame-object-inputs?+0x180>
    acb0:      	b	0xacbc <_stogir.stack.valid-frame-object-inputs?+0x184>
    acb4:      	b	0xad90 <_stogir.stack.valid-frame-object-inputs?+0x258>
    acb8:      	b	0xaf08 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    acbc:      	fmov	d31, x11
    acc0:      	mov	x11, x12
    acc4:      	fmov	x12, d31
    acc8:      	movz	x1, #0x0, lsl #48
    accc:      	fmov	d31, x11
    acd0:      	mov	x11, x12
    acd4:      	fmov	x12, d31
    acd8:      	cmp	x1, #0x0
    acdc:      	b.eq	0xae4c <_stogir.stack.valid-frame-object-inputs?+0x314>
    ace0:      	cmp	x11, #0x0
    ace4:      	b.ne	0xae4c <_stogir.stack.valid-frame-object-inputs?+0x314>
    ace8:      	lsr	w13, w12, #0
    acec:      	sxtw	x13, w13
    acf0:      	cmp	x13, #0x0
    acf4:      	cset	w14, gt
    acf8:      	movz	x16, #0x0, lsl #48
    acfc:      	sub	x15, x16, x13
    ad00:      	sub	x19, x15, #0x1
    ad04:      	uxtb	w16, w14
    ad08:      	cmp	w16, wzr
    ad0c:      	b.eq	0xad4c <_stogir.stack.valid-frame-object-inputs?+0x214>
    ad10:      	ldr	x15, [x0, #0x8]
    ad14:      	cmp	x13, x15
    ad18:      	b.ge	0xac0c <_stogir.stack.valid-frame-object-inputs?+0xd4>
    ad1c:      	ldr	x15, [x3, #0x8]
    ad20:      	cmp	x13, x15
    ad24:      	b.ge	0xabfc <_stogir.stack.valid-frame-object-inputs?+0xc4>
    ad28:      	lsl	x15, x13, #2
    ad2c:      	ldr	x20, [x0, #0x78]
    ad30:      	add	x15, x15, x20
    ad34:      	ldr	w15, [x15]
    ad38:      	sxtw	x15, w15
    ad3c:      	cmp	x15, #0x0
    ad40:      	cset	w15, ge
    ad44:      	ubfx	x15, x15, #0, #8
    ad48:      	b	0xac00 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    ad4c:      	cmp	x13, #0x0
    ad50:      	b.ge	0xac14 <_stogir.stack.valid-frame-object-inputs?+0xdc>
    ad54:      	ldr	x20, [x4, #0x8]
    ad58:      	ldr	x21, [x5, #0x8]
    ad5c:      	cmp	x20, x21
    ad60:      	b.ne	0xac04 <_stogir.stack.valid-frame-object-inputs?+0xcc>
    ad64:      	cmp	x15, x20
    ad68:      	b.gt	0xab8c <_stogir.stack.valid-frame-object-inputs?+0x54>
    ad6c:      	lsl	x15, x19, #2
    ad70:      	ldr	x20, [x0, #0x50]
    ad74:      	add	x15, x15, x20
    ad78:      	ldr	w15, [x15]
    ad7c:      	sxtw	x15, w15
    ad80:      	cmp	x15, #0x0
    ad84:      	cset	w15, gt
    ad88:      	ubfx	x15, x15, #0, #8
    ad8c:      	b	0xab90 <_stogir.stack.valid-frame-object-inputs?+0x58>
    ad90:      	uxtb	w13, w14
    ad94:      	asr	x19, x14, #32
    ad98:      	str	x14, [x10]
    ad9c:      	str	x15, [x10, #0x8]
    ada0:      	cmp	x13, #0x68
    ada4:      	b.ne	0xadc0 <_stogir.stack.valid-frame-object-inputs?+0x288>
    ada8:      	cmp	x19, #0x0
    adac:      	cset	w1, eq
    adb0:      	ubfx	x1, x1, #0, #8
    adb4:      	mov	x11, x12
    adb8:      	mov	x12, #0x1               ; =1
    adbc:      	b	0xaccc <_stogir.stack.valid-frame-object-inputs?+0x194>
    adc0:      	cmp	x12, #0x0
    adc4:      	b.le	0xabe8 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    adc8:      	cmp	x13, #0x51
    adcc:      	b.ne	0xabe8 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    add0:      	cmp	x19, #0x0
    add4:      	b.le	0xabe8 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    add8:      	cmp	x19, x12
    addc:      	b.ge	0xabe8 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    ade0:      	lsr	w15, w15, #0
    ade4:      	sxtw	x15, w15
    ade8:      	cmp	x15, #0x0
    adec:      	b.ge	0xabe8 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    adf0:      	cmp	x15, #0x0
    adf4:      	cset	w13, gt
    adf8:      	movz	x16, #0x0, lsl #48
    adfc:      	sub	x14, x16, x15
    ae00:      	sub	x19, x14, #0x1
    ae04:      	uxtb	w16, w13
    ae08:      	cmp	w16, wzr
    ae0c:      	b.eq	0xaf60 <_stogir.stack.valid-frame-object-inputs?+0x428>
    ae10:      	ldr	x14, [x0, #0x8]
    ae14:      	cmp	x15, x14
    ae18:      	b.ge	0xaf58 <_stogir.stack.valid-frame-object-inputs?+0x420>
    ae1c:      	ldr	x14, [x6, #0x8]
    ae20:      	cmp	x15, x14
    ae24:      	b.ge	0xafa4 <_stogir.stack.valid-frame-object-inputs?+0x46c>
    ae28:      	lsl	x14, x15, #2
    ae2c:      	ldr	x20, [x0, #0x78]
    ae30:      	add	x14, x14, x20
    ae34:      	ldr	w14, [x14]
    ae38:      	sxtw	x14, w14
    ae3c:      	cmp	x14, #0x0
    ae40:      	cset	w14, ge
    ae44:      	ubfx	x14, x14, #0, #8
    ae48:      	b	0xafa8 <_stogir.stack.valid-frame-object-inputs?+0x470>
    ae4c:      	cmp	x1, #0x0
    ae50:      	b.eq	0xae5c <_stogir.stack.valid-frame-object-inputs?+0x324>
    ae54:      	mov	x1, x11
    ae58:      	b	0xae60 <_stogir.stack.valid-frame-object-inputs?+0x328>
    ae5c:      	movz	x1, #0x0, lsl #48
    ae60:      	mov	sp, x9
    ae64:      	cmp	x1, #0x0
    ae68:      	b.eq	0xaec4 <_stogir.stack.valid-frame-object-inputs?+0x38c>
    ae6c:      	sxtw	x1, w2
    ae70:      	cmp	x1, #0x0
    ae74:      	b.ge	0xaee8 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    ae78:      	lsr	w2, w2, #0
    ae7c:      	add	x8, x29, #0x10
    ae80:      	mov	w1, w2
    ae84:      	bl	0xae84 <_stogir.stack.valid-frame-object-inputs?+0x34c>
		000000000000ae84:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    ae88:      	add	x16, x29, #0x10
    ae8c:      	ldr	w0, [x16]
    ae90:      	lsr	x16, x0, #0
    ae94:      	cmp	x16, #0x1
    ae98:      	b.eq	0xaeb4 <_stogir.stack.valid-frame-object-inputs?+0x37c>
    ae9c:      	b.lo	0xaea4 <_stogir.stack.valid-frame-object-inputs?+0x36c>
    aea0:      	b	0xaeb8 <_stogir.stack.valid-frame-object-inputs?+0x380>
    aea4:      	cmp	x16, #0x0
    aea8:      	b.eq	0xaeb0 <_stogir.stack.valid-frame-object-inputs?+0x378>
    aeac:      	b	0xaeb8 <_stogir.stack.valid-frame-object-inputs?+0x380>
    aeb0:      	b	0xaef0 <_stogir.stack.valid-frame-object-inputs?+0x3b8>
    aeb4:      	b	0xaebc <_stogir.stack.valid-frame-object-inputs?+0x384>
    aeb8:      	b	0xafb8 <_stogir.stack.valid-frame-object-inputs?+0x480>
    aebc:      	movz	x0, #0x0, lsl #48
    aec0:      	b	0xaf04 <_stogir.stack.valid-frame-object-inputs?+0x3cc>
    aec4:      	movz	x0, #0x0, lsl #48
    aec8:      	sub	sp, x29, #0x0
    aecc:      	ldr	x19, [sp, #0x30]
    aed0:      	ldr	x20, [sp, #0x38]
    aed4:      	ldr	x21, [sp, #0x40]
    aed8:      	ldr	x29, [sp]
    aedc:      	ldr	x30, [sp, #0x8]
    aee0:      	add	sp, sp, #0x50
    aee4:      	ret
    aee8:      	movz	x0, #0x0, lsl #48
    aeec:      	b	0xaec8 <_stogir.stack.valid-frame-object-inputs?+0x390>
    aef0:      	add	x16, x29, #0x10
    aef4:      	ldr	x0, [x16, #0x8]
    aef8:      	cmp	x0, #0x0
    aefc:      	cset	w0, gt
    af00:      	ubfx	x0, x0, #0, #8
    af04:      	b	0xaeec <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    af08:      	brk	#0
    af0c:      	b	0xaf08 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    af10:      	lsl	x13, x19, #4
    af14:      	ldr	x14, [x0, #0x28]
    af18:      	add	x13, x13, x14
    af1c:      	ldr	x13, [x13]
    af20:      	mov	x14, x13
    af24:      	mov	x13, #0x1               ; =1
    af28:      	b	0xab9c <_stogir.stack.valid-frame-object-inputs?+0x64>
    af2c:      	movz	x14, #0x0, lsl #48
    af30:      	cmp	x14, #0x0
    af34:      	b.eq	0xab94 <_stogir.stack.valid-frame-object-inputs?+0x5c>
    af38:      	uxtb	w16, w13
    af3c:      	cmp	w16, wzr
    af40:      	b.eq	0xaf10 <_stogir.stack.valid-frame-object-inputs?+0x3d8>
    af44:      	lsl	x13, x15, #4
    af48:      	ldr	x14, [x0]
    af4c:      	add	x13, x13, x14
    af50:      	ldr	x13, [x13]
    af54:      	b	0xaf20 <_stogir.stack.valid-frame-object-inputs?+0x3e8>
    af58:      	movz	x14, #0x0, lsl #48
    af5c:      	b	0xaf30 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    af60:      	ldr	x20, [x7, #0x8]
    af64:      	ldr	x21, [x8, #0x8]
    af68:      	cmp	x20, x21
    af6c:      	b.ne	0xaf2c <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    af70:      	cmp	x14, x20
    af74:      	b.gt	0xaf9c <_stogir.stack.valid-frame-object-inputs?+0x464>
    af78:      	lsl	x14, x19, #2
    af7c:      	ldr	x20, [x0, #0x50]
    af80:      	add	x14, x14, x20
    af84:      	ldr	w14, [x14]
    af88:      	sxtw	x14, w14
    af8c:      	cmp	x14, #0x0
    af90:      	cset	w14, gt
    af94:      	ubfx	x14, x14, #0, #8
    af98:      	b	0xafa0 <_stogir.stack.valid-frame-object-inputs?+0x468>
    af9c:      	movz	x14, #0x0, lsl #48
    afa0:      	b	0xaf30 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    afa4:      	movz	x14, #0x0, lsl #48
    afa8:      	b	0xaf5c <_stogir.stack.valid-frame-object-inputs?+0x424>
    afac:      	ldr	w12, [x10, #0x4]
    afb0:      	sxtw	x12, w12
    afb4:      	b	0xabec <_stogir.stack.valid-frame-object-inputs?+0xb4>
    afb8:      	brk	#0
    afbc:      	b	0xafb8 <_stogir.stack.valid-frame-object-inputs?+0x480>
    afc0:      	brk	#0
    afc4:      	b	0xafc0 <_stogir.stack.valid-frame-object-inputs?+0x488>

000000000000afc8 <_stogir.stack.validate-scope-inputs>:
    afc8:      	sxtw	x1, w1
    afcc:      	cmp	x1, #0x53
    afd0:      	cset	w5, eq
    afd4:      	uxtb	w16, w5
    afd8:      	cmp	w16, wzr
    afdc:      	b.ne	0xb010 <_stogir.stack.validate-scope-inputs+0x48>
    afe0:      	cmp	x1, #0x54
    afe4:      	b.eq	0xb010 <_stogir.stack.validate-scope-inputs+0x48>
    afe8:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x42c>
		000000000000afe8:  ARM64_RELOC_PAGE21	l_stogir.448
    afec:      	ldr	x16, [x16]
		000000000000afec:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    aff0:      	orr	x0, x16, xzr
    aff4:      	mov	x1, x0
    aff8:      	mov	x0, #0x1                ; =1
    affc:      	mov	x2, #0x22               ; =34
    b000:      	str	x0, [x8]
    b004:      	str	x1, [x8, #0x8]
    b008:      	str	x2, [x8, #0x10]
    b00c:      	ret
    b010:      	uxtb	w16, w5
    b014:      	cmp	w16, wzr
    b018:      	mov	x16, #0x6               ; =6
    b01c:      	movz	x17, #0x0, lsl #48
    b020:      	csel	x1, x16, x17, ne
    b024:      	sxtw	x2, w2
    b028:      	lsr	w1, w1, #0
    b02c:      	sxtw	x1, w1
    b030:      	cmp	x2, x1
    b034:      	b.ne	0xafe8 <_stogir.stack.validate-scope-inputs+0x20>
    b038:      	sxtw	x3, w3
    b03c:      	cmp	x3, #0x0
    b040:      	cset	w1, gt
    b044:      	movz	x16, #0x0, lsl #48
    b048:      	sub	x2, x16, x3
    b04c:      	sub	x6, x2, #0x1
    b050:      	uxtb	w16, w1
    b054:      	cmp	w16, wzr
    b058:      	b.eq	0xb140 <_stogir.stack.validate-scope-inputs+0x178>
    b05c:      	ldr	x2, [x0, #0x8]
    b060:      	cmp	x3, x2
    b064:      	b.ge	0xb138 <_stogir.stack.validate-scope-inputs+0x170>
    b068:      	add	x2, x0, #0x78
    b06c:      	ldr	x2, [x2, #0x8]
    b070:      	cmp	x3, x2
    b074:      	b.ge	0xb1e8 <_stogir.stack.validate-scope-inputs+0x220>
    b078:      	lsl	x2, x3, #2
    b07c:      	ldr	x7, [x0, #0x78]
    b080:      	add	x2, x2, x7
    b084:      	ldr	w2, [x2]
    b088:      	sxtw	x2, w2
    b08c:      	cmp	x2, #0x0
    b090:      	cset	w2, ge
    b094:      	ubfx	x2, x2, #0, #8
    b098:      	b	0xb1ec <_stogir.stack.validate-scope-inputs+0x224>
    b09c:      	movz	x1, #0x0, lsl #48
    b0a0:      	movz	x2, #0x0, lsl #48
    b0a4:      	lsr	w1, w1, #0
    b0a8:      	lsr	x16, x1, #0
    b0ac:      	cmp	x16, #0x1
    b0b0:      	b.eq	0xb0cc <_stogir.stack.validate-scope-inputs+0x104>
    b0b4:      	b.lo	0xb0bc <_stogir.stack.validate-scope-inputs+0xf4>
    b0b8:      	b	0xb0d0 <_stogir.stack.validate-scope-inputs+0x108>
    b0bc:      	cmp	x16, #0x0
    b0c0:      	b.eq	0xb0c8 <_stogir.stack.validate-scope-inputs+0x100>
    b0c4:      	b	0xb0d0 <_stogir.stack.validate-scope-inputs+0x108>
    b0c8:      	b	0xb0d4 <_stogir.stack.validate-scope-inputs+0x10c>
    b0cc:      	b	0xb18c <_stogir.stack.validate-scope-inputs+0x1c4>
    b0d0:      	b	0xb3d0 <_stogir.stack.validate-scope-inputs+0x408>
    b0d4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b0d4:  ARM64_RELOC_PAGE21	l_stogir.449
    b0d8:      	ldr	x16, [x16]
		000000000000b0d8:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    b0dc:      	orr	x0, x16, xzr
    b0e0:      	mov	x1, x0
    b0e4:      	mov	x0, #0x1                ; =1
    b0e8:      	mov	x2, #0x1b               ; =27
    b0ec:      	b	0xb000 <_stogir.stack.validate-scope-inputs+0x38>
    b0f0:      	lsl	x1, x6, #4
    b0f4:      	ldr	x2, [x0, #0x28]
    b0f8:      	add	x1, x1, x2
    b0fc:      	ldr	x1, [x1]
    b100:      	mov	x2, x1
    b104:      	mov	x1, #0x1                ; =1
    b108:      	b	0xb0a4 <_stogir.stack.validate-scope-inputs+0xdc>
    b10c:      	movz	x2, #0x0, lsl #48
    b110:      	cmp	x2, #0x0
    b114:      	b.eq	0xb09c <_stogir.stack.validate-scope-inputs+0xd4>
    b118:      	uxtb	w16, w1
    b11c:      	cmp	w16, wzr
    b120:      	b.eq	0xb0f0 <_stogir.stack.validate-scope-inputs+0x128>
    b124:      	lsl	x1, x3, #4
    b128:      	ldr	x2, [x0]
    b12c:      	add	x1, x1, x2
    b130:      	ldr	x1, [x1]
    b134:      	b	0xb100 <_stogir.stack.validate-scope-inputs+0x138>
    b138:      	movz	x2, #0x0, lsl #48
    b13c:      	b	0xb110 <_stogir.stack.validate-scope-inputs+0x148>
    b140:      	cmp	x3, #0x0
    b144:      	b.ge	0xb10c <_stogir.stack.validate-scope-inputs+0x144>
    b148:      	add	x7, x0, #0x28
    b14c:      	add	x9, x0, #0x50
    b150:      	ldr	x7, [x7, #0x8]
    b154:      	ldr	x9, [x9, #0x8]
    b158:      	cmp	x7, x9
    b15c:      	b.ne	0xb1e0 <_stogir.stack.validate-scope-inputs+0x218>
    b160:      	cmp	x2, x7
    b164:      	b.gt	0xb1f0 <_stogir.stack.validate-scope-inputs+0x228>
    b168:      	lsl	x2, x6, #2
    b16c:      	ldr	x7, [x0, #0x50]
    b170:      	add	x2, x2, x7
    b174:      	ldr	w2, [x2]
    b178:      	sxtw	x2, w2
    b17c:      	cmp	x2, #0x0
    b180:      	cset	w2, gt
    b184:      	ubfx	x2, x2, #0, #8
    b188:      	b	0xb1f4 <_stogir.stack.validate-scope-inputs+0x22c>
    b18c:      	cmp	x3, #0x0
    b190:      	b.le	0xb1c4 <_stogir.stack.validate-scope-inputs+0x1fc>
    b194:      	uxtb	w2, w2
    b198:      	cmp	x2, #0x83
    b19c:      	cset	w1, lt
    b1a0:      	uxtb	w16, w1
    b1a4:      	cmp	w16, wzr
    b1a8:      	b.eq	0xb1f8 <_stogir.stack.validate-scope-inputs+0x230>
    b1ac:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b1ac:  ARM64_RELOC_PAGE21	l_stogir.450
    b1b0:      	ldr	x16, [x16]
		000000000000b1b0:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b1b4:      	orr	x3, x16, xzr
    b1b8:      	add	x3, x2, x3
    b1bc:      	ldrb	w3, [x3]
    b1c0:      	b	0xb1fc <_stogir.stack.validate-scope-inputs+0x234>
    b1c4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b1c4:  ARM64_RELOC_PAGE21	l_stogir.451
    b1c8:      	ldr	x16, [x16]
		000000000000b1c8:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    b1cc:      	orr	x0, x16, xzr
    b1d0:      	mov	x1, x0
    b1d4:      	mov	x0, #0x1                ; =1
    b1d8:      	mov	x2, #0x1b               ; =27
    b1dc:      	b	0xb0ec <_stogir.stack.validate-scope-inputs+0x124>
    b1e0:      	movz	x2, #0x0, lsl #48
    b1e4:      	b	0xb110 <_stogir.stack.validate-scope-inputs+0x148>
    b1e8:      	movz	x2, #0x0, lsl #48
    b1ec:      	b	0xb13c <_stogir.stack.validate-scope-inputs+0x174>
    b1f0:      	movz	x2, #0x0, lsl #48
    b1f4:      	b	0xb1e4 <_stogir.stack.validate-scope-inputs+0x21c>
    b1f8:      	movz	x3, #0x0, lsl #48
    b1fc:      	uxtb	w3, w3
    b200:      	and	x3, x3, #0x1
    b204:      	uxtb	w3, w3
    b208:      	cmp	x3, #0x0
    b20c:      	b.eq	0xb1c4 <_stogir.stack.validate-scope-inputs+0x1fc>
    b210:      	uxtb	w16, w1
    b214:      	cmp	w16, wzr
    b218:      	b.eq	0xb234 <_stogir.stack.validate-scope-inputs+0x26c>
    b21c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b21c:  ARM64_RELOC_PAGE21	l_stogir.450
    b220:      	ldr	x16, [x16]
		000000000000b220:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b224:      	orr	x1, x16, xzr
    b228:      	add	x1, x2, x1
    b22c:      	ldrb	w1, [x1]
    b230:      	b	0xb238 <_stogir.stack.validate-scope-inputs+0x270>
    b234:      	movz	x1, #0x0, lsl #48
    b238:      	uxtb	w1, w1
    b23c:      	and	x1, x1, #0x4
    b240:      	uxtb	w1, w1
    b244:      	cmp	x1, #0x0
    b248:      	cset	w1, eq
    b24c:      	uxtb	w16, w1
    b250:      	cmp	w16, wzr
    b254:      	cset	x1, eq
    b258:      	cmp	x1, #0x0
    b25c:      	b.ne	0xb1c4 <_stogir.stack.validate-scope-inputs+0x1fc>
    b260:      	uxtb	w16, w5
    b264:      	cmp	w16, wzr
    b268:      	b.eq	0xb27c <_stogir.stack.validate-scope-inputs+0x2b4>
    b26c:      	movz	x0, #0x0, lsl #48
    b270:      	mov	x1, #0x8                ; =8
    b274:      	movz	x2, #0x0, lsl #48
    b278:      	b	0xb1dc <_stogir.stack.validate-scope-inputs+0x214>
    b27c:      	sxtw	x4, w4
    b280:      	cmp	x4, #0x0
    b284:      	cset	w1, gt
    b288:      	movz	x16, #0x0, lsl #48
    b28c:      	sub	x2, x16, x4
    b290:      	sub	x3, x2, #0x1
    b294:      	uxtb	w16, w1
    b298:      	cmp	w16, wzr
    b29c:      	b.eq	0xb384 <_stogir.stack.validate-scope-inputs+0x3bc>
    b2a0:      	ldr	x2, [x0, #0x8]
    b2a4:      	cmp	x4, x2
    b2a8:      	b.ge	0xb37c <_stogir.stack.validate-scope-inputs+0x3b4>
    b2ac:      	add	x2, x0, #0x78
    b2b0:      	ldr	x2, [x2, #0x8]
    b2b4:      	cmp	x4, x2
    b2b8:      	b.ge	0xb428 <_stogir.stack.validate-scope-inputs+0x460>
    b2bc:      	lsl	x2, x4, #2
    b2c0:      	ldr	x5, [x0, #0x78]
    b2c4:      	add	x2, x2, x5
    b2c8:      	ldr	w2, [x2]
    b2cc:      	sxtw	x2, w2
    b2d0:      	cmp	x2, #0x0
    b2d4:      	cset	w2, ge
    b2d8:      	ubfx	x2, x2, #0, #8
    b2dc:      	b	0xb42c <_stogir.stack.validate-scope-inputs+0x464>
    b2e0:      	movz	x0, #0x0, lsl #48
    b2e4:      	movz	x1, #0x0, lsl #48
    b2e8:      	lsr	w0, w0, #0
    b2ec:      	lsr	x16, x0, #0
    b2f0:      	cmp	x16, #0x1
    b2f4:      	b.eq	0xb310 <_stogir.stack.validate-scope-inputs+0x348>
    b2f8:      	b.lo	0xb300 <_stogir.stack.validate-scope-inputs+0x338>
    b2fc:      	b	0xb314 <_stogir.stack.validate-scope-inputs+0x34c>
    b300:      	cmp	x16, #0x0
    b304:      	b.eq	0xb30c <_stogir.stack.validate-scope-inputs+0x344>
    b308:      	b	0xb314 <_stogir.stack.validate-scope-inputs+0x34c>
    b30c:      	b	0xb318 <_stogir.stack.validate-scope-inputs+0x350>
    b310:      	b	0xb3d8 <_stogir.stack.validate-scope-inputs+0x410>
    b314:      	b	0xb438 <_stogir.stack.validate-scope-inputs+0x470>
    b318:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b318:  ARM64_RELOC_PAGE21	l_stogir.452
    b31c:      	ldr	x16, [x16]
		000000000000b31c:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    b320:      	orr	x0, x16, xzr
    b324:      	mov	x1, x0
    b328:      	mov	x0, #0x1                ; =1
    b32c:      	mov	x2, #0x1b               ; =27
    b330:      	b	0xb278 <_stogir.stack.validate-scope-inputs+0x2b0>
    b334:      	lsl	x1, x3, #4
    b338:      	ldr	x0, [x0, #0x28]
    b33c:      	add	x0, x1, x0
    b340:      	ldr	x0, [x0]
    b344:      	mov	x1, x0
    b348:      	mov	x0, #0x1                ; =1
    b34c:      	b	0xb2e8 <_stogir.stack.validate-scope-inputs+0x320>
    b350:      	movz	x2, #0x0, lsl #48
    b354:      	cmp	x2, #0x0
    b358:      	b.eq	0xb2e0 <_stogir.stack.validate-scope-inputs+0x318>
    b35c:      	uxtb	w16, w1
    b360:      	cmp	w16, wzr
    b364:      	b.eq	0xb334 <_stogir.stack.validate-scope-inputs+0x36c>
    b368:      	lsl	x1, x4, #4
    b36c:      	ldr	x0, [x0]
    b370:      	add	x0, x1, x0
    b374:      	ldr	x0, [x0]
    b378:      	b	0xb344 <_stogir.stack.validate-scope-inputs+0x37c>
    b37c:      	movz	x2, #0x0, lsl #48
    b380:      	b	0xb354 <_stogir.stack.validate-scope-inputs+0x38c>
    b384:      	cmp	x4, #0x0
    b388:      	b.ge	0xb350 <_stogir.stack.validate-scope-inputs+0x388>
    b38c:      	add	x5, x0, #0x28
    b390:      	add	x6, x0, #0x50
    b394:      	ldr	x5, [x5, #0x8]
    b398:      	ldr	x6, [x6, #0x8]
    b39c:      	cmp	x5, x6
    b3a0:      	b.ne	0xb420 <_stogir.stack.validate-scope-inputs+0x458>
    b3a4:      	cmp	x2, x5
    b3a8:      	b.gt	0xb430 <_stogir.stack.validate-scope-inputs+0x468>
    b3ac:      	lsl	x2, x3, #2
    b3b0:      	ldr	x5, [x0, #0x50]
    b3b4:      	add	x2, x2, x5
    b3b8:      	ldr	w2, [x2]
    b3bc:      	sxtw	x2, w2
    b3c0:      	cmp	x2, #0x0
    b3c4:      	cset	w2, gt
    b3c8:      	ubfx	x2, x2, #0, #8
    b3cc:      	b	0xb434 <_stogir.stack.validate-scope-inputs+0x46c>
    b3d0:      	brk	#0
    b3d4:      	b	0xb3d0 <_stogir.stack.validate-scope-inputs+0x408>
    b3d8:      	lsr	w0, w1, #0
    b3dc:      	ubfx	x0, x0, #8, #8
    b3e0:      	cmp	x0, #0x6
    b3e4:      	b.ne	0xb404 <_stogir.stack.validate-scope-inputs+0x43c>
    b3e8:      	uxtb	w1, w1
    b3ec:      	cmp	x1, #0x48
    b3f0:      	b.eq	0xb404 <_stogir.stack.validate-scope-inputs+0x43c>
    b3f4:      	movz	x0, #0x0, lsl #48
    b3f8:      	mov	x1, #0x8                ; =8
    b3fc:      	movz	x2, #0x0, lsl #48
    b400:      	b	0xb41c <_stogir.stack.validate-scope-inputs+0x454>
    b404:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b404:  ARM64_RELOC_PAGE21	l_stogir.453
    b408:      	ldr	x16, [x16]
		000000000000b408:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    b40c:      	orr	x0, x16, xzr
    b410:      	mov	x1, x0
    b414:      	mov	x0, #0x1                ; =1
    b418:      	mov	x2, #0x29               ; =41
    b41c:      	b	0xb330 <_stogir.stack.validate-scope-inputs+0x368>
    b420:      	movz	x2, #0x0, lsl #48
    b424:      	b	0xb354 <_stogir.stack.validate-scope-inputs+0x38c>
    b428:      	movz	x2, #0x0, lsl #48
    b42c:      	b	0xb380 <_stogir.stack.validate-scope-inputs+0x3b8>
    b430:      	movz	x2, #0x0, lsl #48
    b434:      	b	0xb424 <_stogir.stack.validate-scope-inputs+0x45c>
    b438:      	brk	#0
    b43c:      	b	0xb438 <_stogir.stack.validate-scope-inputs+0x470>

000000000000b440 <_stogir.stack.validate-inputs>:
    b440:      	sub	sp, sp, #0x110
    b444:      	str	x29, [sp]
    b448:      	str	x30, [sp, #0x8]
    b44c:      	mov	x29, sp
    b450:      	str	x19, [sp, #0xb8]
    b454:      	str	x20, [sp, #0xc0]
    b458:      	str	x21, [sp, #0xc8]
    b45c:      	str	x22, [sp, #0xd0]
    b460:      	str	x23, [sp, #0xd8]
    b464:      	str	x24, [sp, #0xe0]
    b468:      	str	x25, [sp, #0xe8]
    b46c:      	str	x26, [sp, #0xf0]
    b470:      	str	x27, [sp, #0xf8]
    b474:      	str	x28, [sp, #0x100]
    b478:      	sxtw	x1, w1
    b47c:      	cmp	x1, #0x51
    b480:      	cset	w19, eq
    b484:      	uxtb	w16, w19
    b488:      	cmp	w16, wzr
    b48c:      	b.ne	0xb4fc <_stogir.stack.validate-inputs+0xbc>
    b490:      	cmp	x1, #0x52
    b494:      	b.eq	0xb4fc <_stogir.stack.validate-inputs+0xbc>
    b498:      	str	x8, [sp, #0x90]
    b49c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b49c:  ARM64_RELOC_PAGE21	l_stogir.454
    b4a0:      	ldr	x16, [x16]
		000000000000b4a0:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    b4a4:      	orr	x0, x16, xzr
    b4a8:      	mov	x1, x0
    b4ac:      	mov	x0, #0x1                ; =1
    b4b0:      	mov	x2, #0x29               ; =41
    b4b4:      	ldr	x3, [sp, #0x90]
    b4b8:      	str	x0, [x3]
    b4bc:      	str	x1, [x3, #0x8]
    b4c0:      	str	x2, [x3, #0x10]
    b4c4:      	ldr	x19, [sp, #0xb8]
    b4c8:      	ldr	x20, [sp, #0xc0]
    b4cc:      	ldr	x21, [sp, #0xc8]
    b4d0:      	ldr	x22, [sp, #0xd0]
    b4d4:      	ldr	x23, [sp, #0xd8]
    b4d8:      	ldr	x24, [sp, #0xe0]
    b4dc:      	ldr	x25, [sp, #0xe8]
    b4e0:      	ldr	x26, [sp, #0xf0]
    b4e4:      	ldr	x27, [sp, #0xf8]
    b4e8:      	ldr	x28, [sp, #0x100]
    b4ec:      	ldr	x29, [sp]
    b4f0:      	ldr	x30, [sp, #0x8]
    b4f4:      	add	sp, sp, #0x110
    b4f8:      	ret
    b4fc:      	uxtb	w16, w19
    b500:      	cmp	w16, wzr
    b504:      	mov	x16, #0x6               ; =6
    b508:      	movz	x17, #0x0, lsl #48
    b50c:      	csel	x1, x16, x17, ne
    b510:      	sxtw	x2, w2
    b514:      	lsr	w1, w1, #0
    b518:      	sxtw	x1, w1
    b51c:      	cmp	x2, x1
    b520:      	b.ne	0xba80 <_stogir.stack.validate-inputs+0x640>
    b524:      	sxtw	x20, w5
    b528:      	uxtb	w16, w19
    b52c:      	cmp	w16, wzr
    b530:      	b.eq	0xb554 <_stogir.stack.validate-inputs+0x114>
    b534:      	cmp	x20, #0x0
    b538:      	b.eq	0xb554 <_stogir.stack.validate-inputs+0x114>
    b53c:      	cmp	x20, #0x0
    b540:      	b.le	0xb5fc <_stogir.stack.validate-inputs+0x1bc>
    b544:      	sub	x1, x20, #0x1
    b548:      	and	x1, x1, x20
    b54c:      	cmp	x1, #0x0
    b550:      	b.ne	0xb5fc <_stogir.stack.validate-inputs+0x1bc>
    b554:      	lsr	w3, w3, #0
    b558:      	mov	w1, w3
    b55c:      	mov	x21, x8
    b560:      	add	x8, sp, #0x10
    b564:      	mov	x22, x0
    b568:      	mov	w23, w3
    b56c:      	mov	w24, w4
    b570:      	bl	0xb570 <_stogir.stack.validate-inputs+0x130>
		000000000000b570:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b574:      	add	x16, sp, #0x10
    b578:      	ldr	w0, [x16]
    b57c:      	lsr	x16, x0, #0
    b580:      	cmp	x16, #0x1
    b584:      	b.eq	0xb5a0 <_stogir.stack.validate-inputs+0x160>
    b588:      	b.lo	0xb590 <_stogir.stack.validate-inputs+0x150>
    b58c:      	b	0xb5a4 <_stogir.stack.validate-inputs+0x164>
    b590:      	cmp	x16, #0x0
    b594:      	b.eq	0xb59c <_stogir.stack.validate-inputs+0x15c>
    b598:      	b	0xb5a4 <_stogir.stack.validate-inputs+0x164>
    b59c:      	b	0xb5a8 <_stogir.stack.validate-inputs+0x168>
    b5a0:      	b	0xb5c8 <_stogir.stack.validate-inputs+0x188>
    b5a4:      	b	0xb7f8 <_stogir.stack.validate-inputs+0x3b8>
    b5a8:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b5a8:  ARM64_RELOC_PAGE21	l_stogir.455
    b5ac:      	ldr	x16, [x16]
		000000000000b5ac:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    b5b0:      	orr	x0, x16, xzr
    b5b4:      	str	x21, [sp, #0x90]
    b5b8:      	mov	x1, x0
    b5bc:      	mov	x0, #0x1                ; =1
    b5c0:      	mov	x2, #0x1f               ; =31
    b5c4:      	b	0xb4b4 <_stogir.stack.validate-inputs+0x74>
    b5c8:      	sxtw	x23, w23
    b5cc:      	add	x16, sp, #0x10
    b5d0:      	ldr	x0, [x16, #0x8]
    b5d4:      	cmp	x23, #0x0
    b5d8:      	b.gt	0xb604 <_stogir.stack.validate-inputs+0x1c4>
    b5dc:      	str	x21, [sp, #0x90]
    b5e0:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b5e0:  ARM64_RELOC_PAGE21	l_stogir.456
    b5e4:      	ldr	x16, [x16]
		000000000000b5e4:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    b5e8:      	orr	x0, x16, xzr
    b5ec:      	mov	x1, x0
    b5f0:      	mov	x0, #0x1                ; =1
    b5f4:      	mov	x2, #0x1f               ; =31
    b5f8:      	b	0xb5c4 <_stogir.stack.validate-inputs+0x184>
    b5fc:      	str	x8, [sp, #0x90]
    b600:      	b	0xb49c <_stogir.stack.validate-inputs+0x5c>
    b604:      	uxtb	w0, w0
    b608:      	cmp	x0, #0x83
    b60c:      	cset	w1, lt
    b610:      	uxtb	w16, w1
    b614:      	cmp	w16, wzr
    b618:      	b.eq	0xb634 <_stogir.stack.validate-inputs+0x1f4>
    b61c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b61c:  ARM64_RELOC_PAGE21	l_stogir.457
    b620:      	ldr	x16, [x16]
		000000000000b620:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b624:      	orr	x2, x16, xzr
    b628:      	add	x2, x0, x2
    b62c:      	ldrb	w2, [x2]
    b630:      	b	0xb638 <_stogir.stack.validate-inputs+0x1f8>
    b634:      	movz	x2, #0x0, lsl #48
    b638:      	uxtb	w2, w2
    b63c:      	and	x2, x2, #0x1
    b640:      	uxtb	w2, w2
    b644:      	cmp	x2, #0x0
    b648:      	b.eq	0xba88 <_stogir.stack.validate-inputs+0x648>
    b64c:      	uxtb	w16, w1
    b650:      	cmp	w16, wzr
    b654:      	b.eq	0xb670 <_stogir.stack.validate-inputs+0x230>
    b658:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b658:  ARM64_RELOC_PAGE21	l_stogir.457
    b65c:      	ldr	x16, [x16]
		000000000000b65c:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b660:      	orr	x1, x16, xzr
    b664:      	add	x0, x0, x1
    b668:      	ldrb	w0, [x0]
    b66c:      	b	0xb674 <_stogir.stack.validate-inputs+0x234>
    b670:      	movz	x0, #0x0, lsl #48
    b674:      	uxtb	w0, w0
    b678:      	and	x0, x0, #0x4
    b67c:      	uxtb	w0, w0
    b680:      	cmp	x0, #0x0
    b684:      	cset	w0, eq
    b688:      	uxtb	w16, w0
    b68c:      	cmp	w16, wzr
    b690:      	cset	x0, eq
    b694:      	cmp	x0, #0x0
    b698:      	b.ne	0xba90 <_stogir.stack.validate-inputs+0x650>
    b69c:      	lsr	w24, w24, #0
    b6a0:      	add	x8, sp, #0x40
    b6a4:      	mov	x0, x22
    b6a8:      	mov	w1, w24
    b6ac:      	bl	0xb6ac <_stogir.stack.validate-inputs+0x26c>
		000000000000b6ac:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b6b0:      	add	x16, sp, #0x40
    b6b4:      	ldr	w0, [x16]
    b6b8:      	lsr	x16, x0, #0
    b6bc:      	cmp	x16, #0x1
    b6c0:      	b.eq	0xb6dc <_stogir.stack.validate-inputs+0x29c>
    b6c4:      	b.lo	0xb6cc <_stogir.stack.validate-inputs+0x28c>
    b6c8:      	b	0xb6e0 <_stogir.stack.validate-inputs+0x2a0>
    b6cc:      	cmp	x16, #0x0
    b6d0:      	b.eq	0xb6d8 <_stogir.stack.validate-inputs+0x298>
    b6d4:      	b	0xb6e0 <_stogir.stack.validate-inputs+0x2a0>
    b6d8:      	b	0xb6e4 <_stogir.stack.validate-inputs+0x2a4>
    b6dc:      	b	0xb704 <_stogir.stack.validate-inputs+0x2c4>
    b6e0:      	b	0xb988 <_stogir.stack.validate-inputs+0x548>
    b6e4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b6e4:  ARM64_RELOC_PAGE21	l_stogir.458
    b6e8:      	ldr	x16, [x16]
		000000000000b6e8:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    b6ec:      	orr	x0, x16, xzr
    b6f0:      	str	x21, [sp, #0x90]
    b6f4:      	mov	x1, x0
    b6f8:      	mov	x0, #0x1                ; =1
    b6fc:      	mov	x2, #0x18               ; =24
    b700:      	b	0xb5f8 <_stogir.stack.validate-inputs+0x1b8>
    b704:      	add	x16, sp, #0x40
    b708:      	ldr	x0, [x16, #0x8]
    b70c:      	lsr	w1, w0, #0
    b710:      	ubfx	x1, x1, #8, #8
    b714:      	cmp	x1, #0x1
    b718:      	b.lt	0xba98 <_stogir.stack.validate-inputs+0x658>
    b71c:      	cmp	x1, #0xb
    b720:      	b.gt	0xbaa0 <_stogir.stack.validate-inputs+0x660>
    b724:      	uxtb	w0, w0
    b728:      	cmp	x0, #0x48
    b72c:      	b.eq	0xbaa8 <_stogir.stack.validate-inputs+0x668>
    b730:      	sxtw	x0, w24
    b734:      	cmp	x1, #0x0
    b738:      	cset	w23, eq
    b73c:      	cmp	x1, #0x1
    b740:      	cset	w25, eq
    b744:      	cmp	x1, #0x2
    b748:      	cset	w26, eq
    b74c:      	cmp	x1, #0x7
    b750:      	cset	w27, eq
    b754:      	cmp	x1, #0x8
    b758:      	cset	w28, eq
    b75c:      	cmp	x1, #0x3
    b760:      	cset	w2, eq
    b764:      	cmp	x1, #0x9
    b768:      	cset	w3, eq
    b76c:      	cmp	x1, #0x4
    b770:      	cset	w4, eq
    b774:      	cmp	x1, #0xa
    b778:      	cset	w5, eq
    b77c:      	cmp	x1, #0xd
    b780:      	cset	w6, eq
    b784:      	cmp	x1, #0x5
    b788:      	cset	w7, eq
    b78c:      	cmp	x1, #0xb
    b790:      	cset	w8, eq
    b794:      	cmp	x1, #0xc
    b798:      	cset	w9, eq
    b79c:      	cmp	x1, #0x6
    b7a0:      	cset	w1, eq
    b7a4:      	uxtb	w16, w1
    b7a8:      	cmp	w16, wzr
    b7ac:      	mov	x16, #0x8               ; =8
    b7b0:      	movn	x17, #0x0, lsl #48
    b7b4:      	csel	x1, x16, x17, ne
    b7b8:      	cmp	x0, #0x0
    b7bc:      	b.ge	0xbab0 <_stogir.stack.validate-inputs+0x670>
    b7c0:      	uxtb	w16, w19
    b7c4:      	cmp	w16, wzr
    b7c8:      	b.eq	0xb8ec <_stogir.stack.validate-inputs+0x4ac>
    b7cc:      	cmp	x20, #0x10
    b7d0:      	b.le	0xb8ec <_stogir.stack.validate-inputs+0x4ac>
    b7d4:      	mov	x0, x20
    b7d8:      	b	0xb8f0 <_stogir.stack.validate-inputs+0x4b0>
    b7dc:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000b7dc:  ARM64_RELOC_PAGE21	l_stogir.459
    b7e0:      	ldr	x16, [x16]
		000000000000b7e0:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    b7e4:      	orr	x0, x16, xzr
    b7e8:      	mov	x1, x0
    b7ec:      	mov	x0, #0x1                ; =1
    b7f0:      	mov	x2, #0x29               ; =41
    b7f4:      	b	0xb700 <_stogir.stack.validate-inputs+0x2c0>
    b7f8:      	brk	#0
    b7fc:      	b	0xb7f8 <_stogir.stack.validate-inputs+0x3b8>
    b800:      	mov	x0, #0x1                ; =1
    b804:      	lsr	w0, w0, #0
    b808:      	sxtw	x0, w0
    b80c:      	and	x0, x0, #0xffffffff
    b810:      	mov	x1, x0
    b814:      	movz	x0, #0x0, lsl #48
    b818:      	movz	x2, #0x0, lsl #48
    b81c:      	b	0xb7f4 <_stogir.stack.validate-inputs+0x3b4>
    b820:      	uxtb	w16, w23
    b824:      	cmp	w16, wzr
    b828:      	b.eq	0xb854 <_stogir.stack.validate-inputs+0x414>
    b82c:      	movz	x0, #0x0, lsl #48
    b830:      	b	0xb804 <_stogir.stack.validate-inputs+0x3c4>
    b834:      	mov	x0, #0x1                ; =1
    b838:      	lsr	w0, w0, #0
    b83c:      	sxtw	x0, w0
    b840:      	and	x0, x0, #0xffffffff
    b844:      	mov	x1, x0
    b848:      	movz	x0, #0x0, lsl #48
    b84c:      	movz	x2, #0x0, lsl #48
    b850:      	b	0xb81c <_stogir.stack.validate-inputs+0x3dc>
    b854:      	uxtb	w16, w25
    b858:      	cmp	w16, wzr
    b85c:      	b.ne	0xb800 <_stogir.stack.validate-inputs+0x3c0>
    b860:      	uxtb	w16, w26
    b864:      	cmp	w16, wzr
    b868:      	b.ne	0xb800 <_stogir.stack.validate-inputs+0x3c0>
    b86c:      	uxtb	w16, w27
    b870:      	cmp	w16, wzr
    b874:      	b.ne	0xb800 <_stogir.stack.validate-inputs+0x3c0>
    b878:      	uxtb	w16, w28
    b87c:      	cmp	w16, wzr
    b880:      	b.ne	0xb800 <_stogir.stack.validate-inputs+0x3c0>
    b884:      	uxtb	w16, w19
    b888:      	cmp	w16, wzr
    b88c:      	b.ne	0xba48 <_stogir.stack.validate-inputs+0x608>
    b890:      	uxtb	w16, w20
    b894:      	cmp	w16, wzr
    b898:      	b.ne	0xba48 <_stogir.stack.validate-inputs+0x608>
    b89c:      	uxtb	w16, w22
    b8a0:      	cmp	w16, wzr
    b8a4:      	b.ne	0xba60 <_stogir.stack.validate-inputs+0x620>
    b8a8:      	uxtb	w16, w24
    b8ac:      	cmp	w16, wzr
    b8b0:      	b.ne	0xba60 <_stogir.stack.validate-inputs+0x620>
    b8b4:      	uxtb	w16, w21
    b8b8:      	cmp	w16, wzr
    b8bc:      	b.ne	0xba60 <_stogir.stack.validate-inputs+0x620>
    b8c0:      	uxtb	w16, w0
    b8c4:      	cmp	w16, wzr
    b8c8:      	b.ne	0xba70 <_stogir.stack.validate-inputs+0x630>
    b8cc:      	uxtb	w16, w1
    b8d0:      	cmp	w16, wzr
    b8d4:      	b.ne	0xba70 <_stogir.stack.validate-inputs+0x630>
    b8d8:      	uxtb	w16, w2
    b8dc:      	cmp	w16, wzr
    b8e0:      	b.ne	0xba70 <_stogir.stack.validate-inputs+0x630>
    b8e4:      	ldr	x0, [sp, #0xb0]
    b8e8:      	b	0xba74 <_stogir.stack.validate-inputs+0x634>
    b8ec:      	mov	x0, #0x10               ; =16
    b8f0:      	lsr	w24, w24, #0
    b8f4:      	mov	w19, w2
    b8f8:      	mov	x2, x0
    b8fc:      	mov	x0, x22
    b900:      	mov	w20, w3
    b904:      	mov	w22, w4
    b908:      	str	w7, [sp, #0x98]
    b90c:      	str	w8, [sp, #0xa0]
    b910:      	add	x8, sp, #0x70
    b914:      	str	w9, [sp, #0xa8]
    b918:      	str	x1, [sp, #0xb0]
    b91c:      	mov	w1, w24
    b920:      	mov	w24, w5
    b924:      	str	x21, [sp, #0x90]
    b928:      	mov	w21, w6
    b92c:      	bl	0xb92c <_stogir.stack.validate-inputs+0x4ec>
		000000000000b92c:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    b930:      	add	x16, sp, #0x70
    b934:      	ldr	w0, [x16]
    b938:      	lsr	x16, x0, #0
    b93c:      	cmp	x16, #0x1
    b940:      	b.eq	0xb95c <_stogir.stack.validate-inputs+0x51c>
    b944:      	b.lo	0xb94c <_stogir.stack.validate-inputs+0x50c>
    b948:      	b	0xb960 <_stogir.stack.validate-inputs+0x520>
    b94c:      	cmp	x16, #0x0
    b950:      	b.eq	0xb958 <_stogir.stack.validate-inputs+0x518>
    b954:      	b	0xb960 <_stogir.stack.validate-inputs+0x520>
    b958:      	b	0xb990 <_stogir.stack.validate-inputs+0x550>
    b95c:      	b	0xb964 <_stogir.stack.validate-inputs+0x524>
    b960:      	b	0xba58 <_stogir.stack.validate-inputs+0x618>
    b964:      	add	x16, sp, #0x70
    b968:      	orr	x0, x16, xzr
    b96c:      	add	x0, x0, #0x8
    b970:      	add	x16, sp, #0x70
    b974:      	ldr	x1, [x16, #0x8]
    b978:      	ldr	x0, [x0, #0x8]
    b97c:      	mov	x2, x0
    b980:      	mov	x0, #0x1                ; =1
    b984:      	b	0xb850 <_stogir.stack.validate-inputs+0x410>
    b988:      	brk	#0
    b98c:      	b	0xb988 <_stogir.stack.validate-inputs+0x548>
    b990:      	uxtb	w16, w23
    b994:      	cmp	w16, wzr
    b998:      	b.eq	0xb9a4 <_stogir.stack.validate-inputs+0x564>
    b99c:      	movz	x0, #0x0, lsl #48
    b9a0:      	b	0xb838 <_stogir.stack.validate-inputs+0x3f8>
    b9a4:      	uxtb	w16, w25
    b9a8:      	cmp	w16, wzr
    b9ac:      	b.ne	0xb834 <_stogir.stack.validate-inputs+0x3f4>
    b9b0:      	uxtb	w16, w26
    b9b4:      	cmp	w16, wzr
    b9b8:      	b.ne	0xb834 <_stogir.stack.validate-inputs+0x3f4>
    b9bc:      	uxtb	w16, w27
    b9c0:      	cmp	w16, wzr
    b9c4:      	b.ne	0xb834 <_stogir.stack.validate-inputs+0x3f4>
    b9c8:      	uxtb	w16, w28
    b9cc:      	cmp	w16, wzr
    b9d0:      	b.ne	0xb834 <_stogir.stack.validate-inputs+0x3f4>
    b9d4:      	uxtb	w16, w19
    b9d8:      	cmp	w16, wzr
    b9dc:      	b.ne	0xba50 <_stogir.stack.validate-inputs+0x610>
    b9e0:      	uxtb	w16, w20
    b9e4:      	cmp	w16, wzr
    b9e8:      	b.ne	0xba50 <_stogir.stack.validate-inputs+0x610>
    b9ec:      	uxtb	w16, w22
    b9f0:      	cmp	w16, wzr
    b9f4:      	b.ne	0xba68 <_stogir.stack.validate-inputs+0x628>
    b9f8:      	uxtb	w16, w24
    b9fc:      	cmp	w16, wzr
    ba00:      	b.ne	0xba68 <_stogir.stack.validate-inputs+0x628>
    ba04:      	uxtb	w16, w21
    ba08:      	cmp	w16, wzr
    ba0c:      	b.ne	0xba68 <_stogir.stack.validate-inputs+0x628>
    ba10:      	ldr	w0, [sp, #0x98]
    ba14:      	uxtb	w16, w0
    ba18:      	cmp	w16, wzr
    ba1c:      	b.ne	0xba78 <_stogir.stack.validate-inputs+0x638>
    ba20:      	ldr	w1, [sp, #0xa0]
    ba24:      	uxtb	w16, w1
    ba28:      	cmp	w16, wzr
    ba2c:      	b.ne	0xba78 <_stogir.stack.validate-inputs+0x638>
    ba30:      	ldr	w2, [sp, #0xa8]
    ba34:      	uxtb	w16, w2
    ba38:      	cmp	w16, wzr
    ba3c:      	b.ne	0xba78 <_stogir.stack.validate-inputs+0x638>
    ba40:      	ldr	x0, [sp, #0xb0]
    ba44:      	b	0xba7c <_stogir.stack.validate-inputs+0x63c>
    ba48:      	mov	x0, #0x2                ; =2
    ba4c:      	b	0xb804 <_stogir.stack.validate-inputs+0x3c4>
    ba50:      	mov	x0, #0x2                ; =2
    ba54:      	b	0xb838 <_stogir.stack.validate-inputs+0x3f8>
    ba58:      	brk	#0
    ba5c:      	b	0xba58 <_stogir.stack.validate-inputs+0x618>
    ba60:      	mov	x0, #0x4                ; =4
    ba64:      	b	0xba4c <_stogir.stack.validate-inputs+0x60c>
    ba68:      	mov	x0, #0x4                ; =4
    ba6c:      	b	0xba54 <_stogir.stack.validate-inputs+0x614>
    ba70:      	mov	x0, #0x8                ; =8
    ba74:      	b	0xba64 <_stogir.stack.validate-inputs+0x624>
    ba78:      	mov	x0, #0x8                ; =8
    ba7c:      	b	0xba6c <_stogir.stack.validate-inputs+0x62c>
    ba80:      	str	x8, [sp, #0x90]
    ba84:      	b	0xb49c <_stogir.stack.validate-inputs+0x5c>
    ba88:      	str	x21, [sp, #0x90]
    ba8c:      	b	0xb5e0 <_stogir.stack.validate-inputs+0x1a0>
    ba90:      	str	x21, [sp, #0x90]
    ba94:      	b	0xb5e0 <_stogir.stack.validate-inputs+0x1a0>
    ba98:      	str	x21, [sp, #0x90]
    ba9c:      	b	0xb7dc <_stogir.stack.validate-inputs+0x39c>
    baa0:      	str	x21, [sp, #0x90]
    baa4:      	b	0xb7dc <_stogir.stack.validate-inputs+0x39c>
    baa8:      	str	x21, [sp, #0x90]
    baac:      	b	0xb7dc <_stogir.stack.validate-inputs+0x39c>
    bab0:      	str	x21, [sp, #0x90]
    bab4:      	str	x1, [sp, #0xb0]
    bab8:      	mov	w19, w2
    babc:      	mov	w20, w3
    bac0:      	mov	w22, w4
    bac4:      	mov	w24, w5
    bac8:      	mov	w21, w6
    bacc:      	mov	w0, w7
    bad0:      	mov	w1, w8
    bad4:      	mov	w2, w9
    bad8:      	b	0xb820 <_stogir.stack.validate-inputs+0x3e0>

000000000000badc <_stogir.locals.shape>:
    badc:      	sub	sp, sp, #0x40
    bae0:      	str	x29, [sp]
    bae4:      	str	x30, [sp, #0x8]
    bae8:      	mov	x29, sp
    baec:      	str	x19, [sp, #0x20]
    baf0:      	str	x20, [sp, #0x28]
    baf4:      	str	x21, [sp, #0x30]
    baf8:      	str	x22, [sp, #0x38]
    bafc:      	sxtw	x19, w1
    bb00:      	lsl	x20, x19, #2
    bb04:      	cmp	x19, #0x0
    bb08:      	cset	w1, gt
    bb0c:      	movz	x16, #0x0, lsl #48
    bb10:      	sub	x3, x16, x19
    bb14:      	sub	x4, x3, #0x1
    bb18:      	uxtb	w16, w1
    bb1c:      	cmp	w16, wzr
    bb20:      	b.eq	0xbb60 <_stogir.locals.shape+0x84>
    bb24:      	ldr	x3, [x0, #0x8]
    bb28:      	cmp	x19, x3
    bb2c:      	b.ge	0xbbd0 <_stogir.locals.shape+0xf4>
    bb30:      	add	x3, x0, #0x78
    bb34:      	ldr	x3, [x3, #0x8]
    bb38:      	cmp	x19, x3
    bb3c:      	b.ge	0xbd9c <_stogir.locals.shape+0x2c0>
    bb40:      	ldr	x3, [x0, #0x78]
    bb44:      	add	x3, x20, x3
    bb48:      	ldr	w3, [x3]
    bb4c:      	sxtw	x3, w3
    bb50:      	cmp	x3, #0x0
    bb54:      	cset	w3, ge
    bb58:      	ubfx	x3, x3, #0, #8
    bb5c:      	b	0xbda0 <_stogir.locals.shape+0x2c4>
    bb60:      	cmp	x19, #0x0
    bb64:      	b.ge	0xbbd8 <_stogir.locals.shape+0xfc>
    bb68:      	add	x5, x0, #0x28
    bb6c:      	add	x6, x0, #0x50
    bb70:      	ldr	x5, [x5, #0x8]
    bb74:      	ldr	x6, [x6, #0x8]
    bb78:      	cmp	x5, x6
    bb7c:      	b.ne	0xbbac <_stogir.locals.shape+0xd0>
    bb80:      	cmp	x3, x5
    bb84:      	b.gt	0xbe70 <_stogir.locals.shape+0x394>
    bb88:      	lsl	x3, x4, #2
    bb8c:      	ldr	x5, [x0, #0x50]
    bb90:      	add	x3, x3, x5
    bb94:      	ldr	w3, [x3]
    bb98:      	sxtw	x3, w3
    bb9c:      	cmp	x3, #0x0
    bba0:      	cset	w3, gt
    bba4:      	ubfx	x3, x3, #0, #8
    bba8:      	b	0xbe74 <_stogir.locals.shape+0x398>
    bbac:      	movz	x3, #0x0, lsl #48
    bbb0:      	b	0xbbdc <_stogir.locals.shape+0x100>
    bbb4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000bbb4:  ARM64_RELOC_PAGE21	l_stogir.460
    bbb8:      	ldr	x16, [x16]
		000000000000bbb8:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    bbbc:      	orr	x0, x16, xzr
    bbc0:      	mov	x1, x0
    bbc4:      	mov	x0, #0x1                ; =1
    bbc8:      	mov	x2, #0x1c               ; =28
    bbcc:      	b	0xbc9c <_stogir.locals.shape+0x1c0>
    bbd0:      	movz	x3, #0x0, lsl #48
    bbd4:      	b	0xbbdc <_stogir.locals.shape+0x100>
    bbd8:      	movz	x3, #0x0, lsl #48
    bbdc:      	cmp	x3, #0x0
    bbe0:      	b.eq	0xbc44 <_stogir.locals.shape+0x168>
    bbe4:      	uxtb	w16, w1
    bbe8:      	cmp	w16, wzr
    bbec:      	b.eq	0xbc14 <_stogir.locals.shape+0x138>
    bbf0:      	lsl	x1, x19, #4
    bbf4:      	ldr	x3, [x0]
    bbf8:      	add	x1, x1, x3
    bbfc:      	ldr	x3, [x1]
    bc00:      	ldr	x1, [x1, #0x8]
    bc04:      	fmov	d31, x1
    bc08:      	mov	x1, x3
    bc0c:      	fmov	x3, d31
    bc10:      	b	0xbc34 <_stogir.locals.shape+0x158>
    bc14:      	lsl	x1, x4, #4
    bc18:      	ldr	x3, [x0, #0x28]
    bc1c:      	add	x1, x1, x3
    bc20:      	ldr	x3, [x1]
    bc24:      	ldr	x1, [x1, #0x8]
    bc28:      	fmov	d31, x1
    bc2c:      	mov	x1, x3
    bc30:      	fmov	x3, d31
    bc34:      	mov	x4, x3
    bc38:      	mov	x3, x1
    bc3c:      	mov	x1, #0x1                ; =1
    bc40:      	b	0xbc50 <_stogir.locals.shape+0x174>
    bc44:      	movz	x1, #0x0, lsl #48
    bc48:      	movz	x3, #0x0, lsl #48
    bc4c:      	movz	x4, #0x0, lsl #48
    bc50:      	lsr	w1, w1, #0
    bc54:      	lsr	x16, x1, #0
    bc58:      	cmp	x16, #0x1
    bc5c:      	b.eq	0xbc78 <_stogir.locals.shape+0x19c>
    bc60:      	b.lo	0xbc68 <_stogir.locals.shape+0x18c>
    bc64:      	b	0xbc7c <_stogir.locals.shape+0x1a0>
    bc68:      	cmp	x16, #0x0
    bc6c:      	b.eq	0xbc74 <_stogir.locals.shape+0x198>
    bc70:      	b	0xbc7c <_stogir.locals.shape+0x1a0>
    bc74:      	b	0xbc80 <_stogir.locals.shape+0x1a4>
    bc78:      	b	0xbcc8 <_stogir.locals.shape+0x1ec>
    bc7c:      	b	0xbec4 <_stogir.locals.shape+0x3e8>
    bc80:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000bc80:  ARM64_RELOC_PAGE21	l_stogir.461
    bc84:      	ldr	x16, [x16]
		000000000000bc84:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    bc88:      	orr	x0, x16, xzr
    bc8c:      	mov	x21, x8
    bc90:      	mov	x1, x0
    bc94:      	mov	x0, #0x1                ; =1
    bc98:      	mov	x2, #0x16               ; =22
    bc9c:      	str	x0, [x21]
    bca0:      	str	x1, [x21, #0x8]
    bca4:      	str	x2, [x21, #0x10]
    bca8:      	ldr	x19, [sp, #0x20]
    bcac:      	ldr	x20, [sp, #0x28]
    bcb0:      	ldr	x21, [sp, #0x30]
    bcb4:      	ldr	x22, [sp, #0x38]
    bcb8:      	ldr	x29, [sp]
    bcbc:      	ldr	x30, [sp, #0x8]
    bcc0:      	add	sp, sp, #0x40
    bcc4:      	ret
    bcc8:      	lsr	w2, w2, #0
    bccc:      	lsr	w1, w3, #0
    bcd0:      	add	x16, sp, #0x10
    bcd4:      	str	x3, [x16]
    bcd8:      	add	x16, sp, #0x10
    bcdc:      	str	x4, [x16, #0x8]
    bce0:      	ubfx	x1, x1, #8, #8
    bce4:      	lsr	w1, w1, #0
    bce8:      	mov	x21, x8
    bcec:      	mov	x22, x0
    bcf0:      	mov	w0, w1
    bcf4:      	mov	w1, w2
    bcf8:      	bl	0xbcf8 <_stogir.locals.shape+0x21c>
		000000000000bcf8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    bcfc:      	lsr	w0, w0, #0
    bd00:      	add	x16, sp, #0x10
    bd04:      	ldr	w1, [x16, #0xc]
    bd08:      	sxtw	x0, w0
    bd0c:      	sxtw	x1, w1
    bd10:      	cmp	x1, #0x0
    bd14:      	b.ne	0xbd1c <_stogir.locals.shape+0x240>
    bd18:      	mov	x1, x0
    bd1c:      	add	x16, sp, #0x10
    bd20:      	ldr	w2, [x16, #0x8]
    bd24:      	sxtw	x2, w2
    bd28:      	cmp	x2, #0x0
    bd2c:      	cset	w3, eq
    bd30:      	ubfx	x3, x3, #0, #8
    bd34:      	cmp	x2, #0x0
    bd38:      	b.le	0xbda4 <_stogir.locals.shape+0x2c8>
    bd3c:      	add	x4, x22, #0x110
    bd40:      	add	x5, x4, #0x28
    bd44:      	ldr	x5, [x5, #0x8]
    bd48:      	cmp	x2, x5
    bd4c:      	b.gt	0xbe88 <_stogir.locals.shape+0x3ac>
    bd50:      	sub	x2, x2, #0x1
    bd54:      	mov	x17, #0x18              ; =24
    bd58:      	mul	x2, x2, x17
    bd5c:      	ldr	x5, [x4, #0x28]
    bd60:      	add	x2, x2, x5
    bd64:      	ldr	x5, [x2]
    bd68:      	ldr	x2, [x2, #0x8]
    bd6c:      	ldr	x4, [x4, #0x8]
    bd70:      	cmp	x5, #0x0
    bd74:      	b.lt	0xbe80 <_stogir.locals.shape+0x3a4>
    bd78:      	cmp	x5, x4
    bd7c:      	b.gt	0xbe80 <_stogir.locals.shape+0x3a4>
    bd80:      	cmp	x2, #0x0
    bd84:      	b.lt	0xbe80 <_stogir.locals.shape+0x3a4>
    bd88:      	sub	x4, x4, x5
    bd8c:      	cmp	x2, x4
    bd90:      	b.gt	0xbe80 <_stogir.locals.shape+0x3a4>
    bd94:      	mov	x2, #0x1                ; =1
    bd98:      	b	0xbe84 <_stogir.locals.shape+0x3a8>
    bd9c:      	movz	x3, #0x0, lsl #48
    bda0:      	b	0xbbd4 <_stogir.locals.shape+0xf8>
    bda4:      	mov	x2, x3
    bda8:      	cmp	x19, #0x0
    bdac:      	b.le	0xbbb4 <_stogir.locals.shape+0xd8>
    bdb0:      	add	x16, sp, #0x10
    bdb4:      	ldr	w3, [x16]
    bdb8:      	uxtb	w3, w3
    bdbc:      	cmp	x3, #0x48
    bdc0:      	b.ne	0xbbb4 <_stogir.locals.shape+0xd8>
    bdc4:      	ldr	x3, [x22, #0x78]
    bdc8:      	add	x3, x20, x3
    bdcc:      	ldr	w3, [x3]
    bdd0:      	sxtw	x3, w3
    bdd4:      	cmp	x3, #0x3
    bdd8:      	b.ne	0xbbb4 <_stogir.locals.shape+0xd8>
    bddc:      	cmp	x0, #0x0
    bde0:      	b.le	0xbbb4 <_stogir.locals.shape+0xd8>
    bde4:      	cmp	x2, #0x0
    bde8:      	b.eq	0xbbb4 <_stogir.locals.shape+0xd8>
    bdec:      	cmp	x1, #0x0
    bdf0:      	b.le	0xbbb4 <_stogir.locals.shape+0xd8>
    bdf4:      	sub	x2, x1, #0x1
    bdf8:      	and	x2, x2, x1
    bdfc:      	cmp	x2, #0x0
    be00:      	b.ne	0xbbb4 <_stogir.locals.shape+0xd8>
    be04:      	add	x16, sp, #0x10
    be08:      	ldr	w2, [x16, #0x4]
    be0c:      	sxtw	x2, w2
    be10:      	cmp	x2, #0x0
    be14:      	cset	w3, gt
    be18:      	movz	x16, #0x0, lsl #48
    be1c:      	sub	x4, x16, x2
    be20:      	sub	x5, x4, #0x1
    be24:      	uxtb	w16, w3
    be28:      	cmp	w16, wzr
    be2c:      	b.eq	0xbef0 <_stogir.locals.shape+0x414>
    be30:      	ldr	x4, [x22, #0x8]
    be34:      	cmp	x2, x4
    be38:      	b.ge	0xbf3c <_stogir.locals.shape+0x460>
    be3c:      	add	x4, x22, #0x78
    be40:      	ldr	x4, [x4, #0x8]
    be44:      	cmp	x2, x4
    be48:      	b.ge	0xc020 <_stogir.locals.shape+0x544>
    be4c:      	lsl	x4, x2, #2
    be50:      	ldr	x6, [x22, #0x78]
    be54:      	add	x4, x4, x6
    be58:      	ldr	w4, [x4]
    be5c:      	sxtw	x4, w4
    be60:      	cmp	x4, #0x0
    be64:      	cset	w4, ge
    be68:      	ubfx	x4, x4, #0, #8
    be6c:      	b	0xc024 <_stogir.locals.shape+0x548>
    be70:      	movz	x3, #0x0, lsl #48
    be74:      	b	0xbbb0 <_stogir.locals.shape+0xd4>
    be78:      	mov	x2, #0x1                ; =1
    be7c:      	b	0xbda8 <_stogir.locals.shape+0x2cc>
    be80:      	movz	x2, #0x0, lsl #48
    be84:      	b	0xbe8c <_stogir.locals.shape+0x3b0>
    be88:      	movz	x2, #0x0, lsl #48
    be8c:      	lsr	w2, w2, #0
    be90:      	lsr	x16, x2, #0
    be94:      	cmp	x16, #0x1
    be98:      	b.eq	0xbeb4 <_stogir.locals.shape+0x3d8>
    be9c:      	b.lo	0xbea4 <_stogir.locals.shape+0x3c8>
    bea0:      	b	0xbeb8 <_stogir.locals.shape+0x3dc>
    bea4:      	cmp	x16, #0x0
    bea8:      	b.eq	0xbeb0 <_stogir.locals.shape+0x3d4>
    beac:      	b	0xbeb8 <_stogir.locals.shape+0x3dc>
    beb0:      	b	0xbebc <_stogir.locals.shape+0x3e0>
    beb4:      	b	0xbe78 <_stogir.locals.shape+0x39c>
    beb8:      	b	0xbecc <_stogir.locals.shape+0x3f0>
    bebc:      	mov	x2, x3
    bec0:      	b	0xbe7c <_stogir.locals.shape+0x3a0>
    bec4:      	brk	#0
    bec8:      	b	0xbec4 <_stogir.locals.shape+0x3e8>
    becc:      	brk	#0
    bed0:      	b	0xbecc <_stogir.locals.shape+0x3f0>
    bed4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000bed4:  ARM64_RELOC_PAGE21	l_stogir.462
    bed8:      	ldr	x16, [x16]
		000000000000bed8:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    bedc:      	orr	x0, x16, xzr
    bee0:      	mov	x1, x0
    bee4:      	mov	x0, #0x1                ; =1
    bee8:      	mov	x2, #0x2c               ; =44
    beec:      	b	0xbbcc <_stogir.locals.shape+0xf0>
    bef0:      	cmp	x2, #0x0
    bef4:      	b.ge	0xbf44 <_stogir.locals.shape+0x468>
    bef8:      	add	x6, x22, #0x28
    befc:      	add	x7, x22, #0x50
    bf00:      	ldr	x6, [x6, #0x8]
    bf04:      	ldr	x7, [x7, #0x8]
    bf08:      	cmp	x6, x7
    bf0c:      	b.ne	0xc018 <_stogir.locals.shape+0x53c>
    bf10:      	cmp	x4, x6
    bf14:      	b.gt	0xc028 <_stogir.locals.shape+0x54c>
    bf18:      	lsl	x4, x5, #2
    bf1c:      	ldr	x6, [x22, #0x50]
    bf20:      	add	x4, x4, x6
    bf24:      	ldr	w4, [x4]
    bf28:      	sxtw	x4, w4
    bf2c:      	cmp	x4, #0x0
    bf30:      	cset	w4, gt
    bf34:      	ubfx	x4, x4, #0, #8
    bf38:      	b	0xc02c <_stogir.locals.shape+0x550>
    bf3c:      	movz	x4, #0x0, lsl #48
    bf40:      	b	0xbf48 <_stogir.locals.shape+0x46c>
    bf44:      	movz	x4, #0x0, lsl #48
    bf48:      	cmp	x4, #0x0
    bf4c:      	b.eq	0xbf8c <_stogir.locals.shape+0x4b0>
    bf50:      	uxtb	w16, w3
    bf54:      	cmp	w16, wzr
    bf58:      	b.eq	0xbf70 <_stogir.locals.shape+0x494>
    bf5c:      	lsl	x2, x2, #4
    bf60:      	ldr	x3, [x22]
    bf64:      	add	x2, x2, x3
    bf68:      	ldr	x2, [x2]
    bf6c:      	b	0xbf80 <_stogir.locals.shape+0x4a4>
    bf70:      	lsl	x2, x5, #4
    bf74:      	ldr	x3, [x22, #0x28]
    bf78:      	add	x2, x2, x3
    bf7c:      	ldr	x2, [x2]
    bf80:      	mov	x3, x2
    bf84:      	mov	x2, #0x1                ; =1
    bf88:      	b	0xbf94 <_stogir.locals.shape+0x4b8>
    bf8c:      	movz	x2, #0x0, lsl #48
    bf90:      	movz	x3, #0x0, lsl #48
    bf94:      	lsr	w2, w2, #0
    bf98:      	lsr	x16, x2, #0
    bf9c:      	cmp	x16, #0x1
    bfa0:      	b.eq	0xbfbc <_stogir.locals.shape+0x4e0>
    bfa4:      	b.lo	0xbfac <_stogir.locals.shape+0x4d0>
    bfa8:      	b	0xbfc0 <_stogir.locals.shape+0x4e4>
    bfac:      	cmp	x16, #0x0
    bfb0:      	b.eq	0xbfb8 <_stogir.locals.shape+0x4dc>
    bfb4:      	b	0xbfc0 <_stogir.locals.shape+0x4e4>
    bfb8:      	b	0xbfc4 <_stogir.locals.shape+0x4e8>
    bfbc:      	b	0xbfe0 <_stogir.locals.shape+0x504>
    bfc0:      	b	0xc06c <_stogir.locals.shape+0x590>
    bfc4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x38>
		000000000000bfc4:  ARM64_RELOC_PAGE21	l_stogir.463
    bfc8:      	ldr	x16, [x16]
		000000000000bfc8:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    bfcc:      	orr	x0, x16, xzr
    bfd0:      	mov	x1, x0
    bfd4:      	mov	x0, #0x1                ; =1
    bfd8:      	mov	x2, #0x1d               ; =29
    bfdc:      	b	0xbeec <_stogir.locals.shape+0x410>
    bfe0:      	add	x16, sp, #0x10
    bfe4:      	ldr	w2, [x16, #0x4]
    bfe8:      	sxtw	x2, w2
    bfec:      	cmp	x2, #0x0
    bff0:      	b.le	0xbed4 <_stogir.locals.shape+0x3f8>
    bff4:      	uxtb	w3, w3
    bff8:      	cmp	x3, #0x83
    bffc:      	b.ge	0xc030 <_stogir.locals.shape+0x554>
    c000:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000c000:  ARM64_RELOC_PAGE21	l_stogir.464
    c004:      	ldr	x16, [x16]
		000000000000c004:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    c008:      	orr	x2, x16, xzr
    c00c:      	add	x2, x3, x2
    c010:      	ldrb	w2, [x2]
    c014:      	b	0xc034 <_stogir.locals.shape+0x558>
    c018:      	movz	x4, #0x0, lsl #48
    c01c:      	b	0xbf48 <_stogir.locals.shape+0x46c>
    c020:      	movz	x4, #0x0, lsl #48
    c024:      	b	0xbf40 <_stogir.locals.shape+0x464>
    c028:      	movz	x4, #0x0, lsl #48
    c02c:      	b	0xc01c <_stogir.locals.shape+0x540>
    c030:      	movz	x2, #0x0, lsl #48
    c034:      	uxtb	w2, w2
    c038:      	and	x2, x2, #0x2
    c03c:      	uxtb	w2, w2
    c040:      	cmp	x2, #0x0
    c044:      	cset	w2, eq
    c048:      	uxtb	w16, w2
    c04c:      	cmp	w16, wzr
    c050:      	cset	x2, eq
    c054:      	cmp	x2, #0x0
    c058:      	b.eq	0xbed4 <_stogir.locals.shape+0x3f8>
    c05c:      	mov	x2, x1
    c060:      	mov	x1, x0
    c064:      	movz	x0, #0x0, lsl #48
    c068:      	b	0xbeec <_stogir.locals.shape+0x410>
    c06c:      	brk	#0
    c070:      	b	0xc06c <_stogir.locals.shape+0x590>

000000000000c074 <_stogir.conversion.policy>:
    c074:      	sub	sp, sp, #0x70
    c078:      	str	x29, [sp]
    c07c:      	str	x30, [sp, #0x8]
    c080:      	mov	x29, sp
    c084:      	str	x19, [sp, #0x20]
    c088:      	str	x20, [sp, #0x28]
    c08c:      	str	x21, [sp, #0x30]
    c090:      	str	x22, [sp, #0x38]
    c094:      	str	x23, [sp, #0x40]
    c098:      	str	x24, [sp, #0x48]
    c09c:      	str	x25, [sp, #0x50]
    c0a0:      	str	x26, [sp, #0x58]
    c0a4:      	str	x27, [sp, #0x60]
    c0a8:      	str	x28, [sp, #0x68]
    c0ac:      	sxtw	x19, w0
    c0b0:      	sxtw	x20, w1
    c0b4:      	sxtw	x21, w2
    c0b8:      	cmp	x19, #0x24
    c0bc:      	b.ne	0xc10c <_stogir.conversion.policy+0x98>
    c0c0:      	cmp	x20, #0xf
    c0c4:      	b.le	0xc328 <_stogir.conversion.policy+0x2b4>
    c0c8:      	cmp	x20, #0x80
    c0cc:      	b.ge	0xc328 <_stogir.conversion.policy+0x2b4>
    c0d0:      	and	x0, x20, #0xf
    c0d4:      	lsr	w0, w0, #0
    c0d8:      	sxtw	x0, w0
    c0dc:      	cmp	x0, #0x1
    c0e0:      	b.lt	0xc328 <_stogir.conversion.policy+0x2b4>
    c0e4:      	and	x0, x20, #0xf
    c0e8:      	lsr	w0, w0, #0
    c0ec:      	sxtw	x0, w0
    c0f0:      	cmp	x0, #0xd
    c0f4:      	b.gt	0xc328 <_stogir.conversion.policy+0x2b4>
    c0f8:      	mov	x0, #0x1                ; =1
    c0fc:      	b	0xc104 <_stogir.conversion.policy+0x90>
    c100:      	movz	x0, #0x0, lsl #48
    c104:      	mov	x22, x0
    c108:      	b	0xc110 <_stogir.conversion.policy+0x9c>
    c10c:      	movz	x22, #0x0, lsl #48
    c110:      	sxtw	x23, w3
    c114:      	cmp	x20, #0xd
    c118:      	cset	w24, eq
    c11c:      	cmp	x20, #0xc
    c120:      	cset	w25, eq
    c124:      	cmp	x23, #0x4
    c128:      	cset	w26, eq
    c12c:      	cmp	x23, #0x8
    c130:      	cset	w27, eq
    c134:      	cmp	x22, #0x0
    c138:      	b.eq	0xc61c <_stogir.conversion.policy+0x5a8>
    c13c:      	lsr	w1, w1, #0
    c140:      	lsr	w3, w3, #0
    c144:      	mov	w0, w1
    c148:      	mov	w1, w3
    c14c:      	str	x8, [sp, #0x18]
    c150:      	mov	w28, w3
    c154:      	str	x23, [sp, #0x10]
    c158:      	mov	w23, w2
    c15c:      	bl	0xc15c <_stogir.conversion.policy+0xe8>
		000000000000c15c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c160:      	lsr	w0, w0, #0
    c164:      	sxtw	x0, w0
    c168:      	b	0xc178 <_stogir.conversion.policy+0x104>
    c16c:      	mov	x0, #0x1                ; =1
    c170:      	lsr	w0, w0, #0
    c174:      	sxtw	x0, w0
    c178:      	cmp	x21, #0xd
    c17c:      	cset	w1, eq
    c180:      	cmp	x21, #0xc
    c184:      	cset	w2, eq
    c188:      	cmp	x22, #0x0
    c18c:      	b.eq	0xc630 <_stogir.conversion.policy+0x5bc>
    c190:      	lsr	w23, w23, #0
    c194:      	lsr	w28, w28, #0
    c198:      	mov	x22, x0
    c19c:      	mov	w0, w23
    c1a0:      	mov	w23, w1
    c1a4:      	mov	w1, w28
    c1a8:      	mov	w28, w2
    c1ac:      	bl	0xc1ac <_stogir.conversion.policy+0x138>
		000000000000c1ac:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c1b0:      	lsr	w0, w0, #0
    c1b4:      	sxtw	x0, w0
    c1b8:      	b	0xc1c8 <_stogir.conversion.policy+0x154>
    c1bc:      	mov	x0, #0x1                ; =1
    c1c0:      	lsr	w0, w0, #0
    c1c4:      	sxtw	x0, w0
    c1c8:      	cmp	x19, #0x21
    c1cc:      	b.lt	0xc2a8 <_stogir.conversion.policy+0x234>
    c1d0:      	cmp	x19, #0x27
    c1d4:      	b.gt	0xc2a8 <_stogir.conversion.policy+0x234>
    c1d8:      	lsl	x1, x22, #3
    c1dc:      	lsr	w1, w1, #0
    c1e0:      	sxtw	x1, w1
    c1e4:      	cmp	x1, #0x0
    c1e8:      	b.le	0xc2a8 <_stogir.conversion.policy+0x234>
    c1ec:      	lsl	x0, x0, #3
    c1f0:      	lsr	w0, w0, #0
    c1f4:      	sxtw	x0, w0
    c1f8:      	cmp	x0, #0x0
    c1fc:      	b.le	0xc2a8 <_stogir.conversion.policy+0x234>
    c200:      	cmp	x19, #0x26
    c204:      	cset	w2, eq
    c208:      	cmp	x20, #0x1
    c20c:      	cset	w3, ge
    c210:      	cmp	x20, #0xb
    c214:      	cset	w4, le
    c218:      	cmp	x21, #0x1
    c21c:      	cset	w5, ge
    c220:      	cmp	x21, #0xb
    c224:      	cset	w6, le
    c228:      	cmp	x19, #0x25
    c22c:      	b.lt	0xc4bc <_stogir.conversion.policy+0x448>
    c230:      	ubfx	x23, x23, #0, #8
    c234:      	cmp	x19, #0x25
    c238:      	b.ne	0xc52c <_stogir.conversion.policy+0x4b8>
    c23c:      	uxtb	w16, w3
    c240:      	cmp	w16, wzr
    c244:      	b.eq	0xc524 <_stogir.conversion.policy+0x4b0>
    c248:      	uxtb	w16, w4
    c24c:      	cmp	w16, wzr
    c250:      	b.eq	0xc524 <_stogir.conversion.policy+0x4b0>
    c254:      	uxtb	w16, w28
    c258:      	cmp	w16, wzr
    c25c:      	b.eq	0xc5a0 <_stogir.conversion.policy+0x52c>
    c260:      	mov	x3, #0x1                ; =1
    c264:      	b	0xc5a4 <_stogir.conversion.policy+0x530>
    c268:      	uxtb	w16, w26
    c26c:      	cmp	w16, wzr
    c270:      	b.ne	0xc308 <_stogir.conversion.policy+0x294>
    c274:      	uxtb	w16, w27
    c278:      	cmp	w16, wzr
    c27c:      	b.ne	0xc308 <_stogir.conversion.policy+0x294>
    c280:      	movn	x0, #0x0, lsl #48
    c284:      	b	0xc1c0 <_stogir.conversion.policy+0x14c>
    c288:      	uxtb	w16, w26
    c28c:      	cmp	w16, wzr
    c290:      	b.ne	0xc318 <_stogir.conversion.policy+0x2a4>
    c294:      	uxtb	w16, w27
    c298:      	cmp	w16, wzr
    c29c:      	b.ne	0xc318 <_stogir.conversion.policy+0x2a4>
    c2a0:      	movn	x0, #0x0, lsl #48
    c2a4:      	b	0xc170 <_stogir.conversion.policy+0xfc>
    c2a8:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000c2a8:  ARM64_RELOC_PAGE21	l_stogir.465
    c2ac:      	ldr	x16, [x16]
		000000000000c2ac:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    c2b0:      	orr	x0, x16, xzr
    c2b4:      	mov	x1, x0
    c2b8:      	mov	x0, #0x1                ; =1
    c2bc:      	mov	x2, #0x22               ; =34
    c2c0:      	ldr	x3, [sp, #0x18]
    c2c4:      	str	x0, [x3]
    c2c8:      	str	x1, [x3, #0x8]
    c2cc:      	str	x2, [x3, #0x10]
    c2d0:      	ldr	x19, [sp, #0x20]
    c2d4:      	ldr	x20, [sp, #0x28]
    c2d8:      	ldr	x21, [sp, #0x30]
    c2dc:      	ldr	x22, [sp, #0x38]
    c2e0:      	ldr	x23, [sp, #0x40]
    c2e4:      	ldr	x24, [sp, #0x48]
    c2e8:      	ldr	x25, [sp, #0x50]
    c2ec:      	ldr	x26, [sp, #0x58]
    c2f0:      	ldr	x27, [sp, #0x60]
    c2f4:      	ldr	x28, [sp, #0x68]
    c2f8:      	ldr	x29, [sp]
    c2fc:      	ldr	x30, [sp, #0x8]
    c300:      	add	sp, sp, #0x70
    c304:      	ret
    c308:      	cmp	x21, #0x0
    c30c:      	b.ne	0xc370 <_stogir.conversion.policy+0x2fc>
    c310:      	movz	x0, #0x0, lsl #48
    c314:      	b	0xc1c0 <_stogir.conversion.policy+0x14c>
    c318:      	cmp	x20, #0x0
    c31c:      	b.ne	0xc3e8 <_stogir.conversion.policy+0x374>
    c320:      	movz	x0, #0x0, lsl #48
    c324:      	b	0xc170 <_stogir.conversion.policy+0xfc>
    c328:      	cmp	x21, #0xf
    c32c:      	b.le	0xc100 <_stogir.conversion.policy+0x8c>
    c330:      	cmp	x21, #0x80
    c334:      	b.ge	0xc368 <_stogir.conversion.policy+0x2f4>
    c338:      	and	x0, x21, #0xf
    c33c:      	lsr	w0, w0, #0
    c340:      	sxtw	x0, w0
    c344:      	cmp	x0, #0x1
    c348:      	b.lt	0xc460 <_stogir.conversion.policy+0x3ec>
    c34c:      	and	x0, x21, #0xf
    c350:      	lsr	w0, w0, #0
    c354:      	sxtw	x0, w0
    c358:      	cmp	x0, #0xd
    c35c:      	cset	w0, le
    c360:      	ubfx	x0, x0, #0, #8
    c364:      	b	0xc464 <_stogir.conversion.policy+0x3f0>
    c368:      	movz	x0, #0x0, lsl #48
    c36c:      	b	0xc104 <_stogir.conversion.policy+0x90>
    c370:      	cmp	x21, #0x1
    c374:      	b.eq	0xc1bc <_stogir.conversion.policy+0x148>
    c378:      	cmp	x21, #0x2
    c37c:      	b.eq	0xc1bc <_stogir.conversion.policy+0x148>
    c380:      	cmp	x21, #0x7
    c384:      	b.eq	0xc1bc <_stogir.conversion.policy+0x148>
    c388:      	cmp	x21, #0x8
    c38c:      	b.eq	0xc1bc <_stogir.conversion.policy+0x148>
    c390:      	cmp	x21, #0x3
    c394:      	b.eq	0xc558 <_stogir.conversion.policy+0x4e4>
    c398:      	cmp	x21, #0x9
    c39c:      	b.eq	0xc558 <_stogir.conversion.policy+0x4e4>
    c3a0:      	cmp	x21, #0x4
    c3a4:      	b.eq	0xc5c8 <_stogir.conversion.policy+0x554>
    c3a8:      	cmp	x21, #0xa
    c3ac:      	b.eq	0xc5c8 <_stogir.conversion.policy+0x554>
    c3b0:      	uxtb	w16, w23
    c3b4:      	cmp	w16, wzr
    c3b8:      	b.ne	0xc5c8 <_stogir.conversion.policy+0x554>
    c3bc:      	cmp	x21, #0x5
    c3c0:      	b.eq	0xc5fc <_stogir.conversion.policy+0x588>
    c3c4:      	cmp	x21, #0xb
    c3c8:      	b.eq	0xc5fc <_stogir.conversion.policy+0x588>
    c3cc:      	uxtb	w16, w28
    c3d0:      	cmp	w16, wzr
    c3d4:      	b.ne	0xc5fc <_stogir.conversion.policy+0x588>
    c3d8:      	cmp	x21, #0x6
    c3dc:      	b.ne	0xc60c <_stogir.conversion.policy+0x598>
    c3e0:      	ldr	x0, [sp, #0x10]
    c3e4:      	b	0xc610 <_stogir.conversion.policy+0x59c>
    c3e8:      	cmp	x20, #0x1
    c3ec:      	b.eq	0xc16c <_stogir.conversion.policy+0xf8>
    c3f0:      	cmp	x20, #0x2
    c3f4:      	b.eq	0xc16c <_stogir.conversion.policy+0xf8>
    c3f8:      	cmp	x20, #0x7
    c3fc:      	b.eq	0xc16c <_stogir.conversion.policy+0xf8>
    c400:      	cmp	x20, #0x8
    c404:      	b.eq	0xc16c <_stogir.conversion.policy+0xf8>
    c408:      	cmp	x20, #0x3
    c40c:      	b.eq	0xc560 <_stogir.conversion.policy+0x4ec>
    c410:      	cmp	x20, #0x9
    c414:      	b.eq	0xc560 <_stogir.conversion.policy+0x4ec>
    c418:      	cmp	x20, #0x4
    c41c:      	b.eq	0xc5d0 <_stogir.conversion.policy+0x55c>
    c420:      	cmp	x20, #0xa
    c424:      	b.eq	0xc5d0 <_stogir.conversion.policy+0x55c>
    c428:      	uxtb	w16, w24
    c42c:      	cmp	w16, wzr
    c430:      	b.ne	0xc5d0 <_stogir.conversion.policy+0x55c>
    c434:      	cmp	x20, #0x5
    c438:      	b.eq	0xc604 <_stogir.conversion.policy+0x590>
    c43c:      	cmp	x20, #0xb
    c440:      	b.eq	0xc604 <_stogir.conversion.policy+0x590>
    c444:      	uxtb	w16, w25
    c448:      	cmp	w16, wzr
    c44c:      	b.ne	0xc604 <_stogir.conversion.policy+0x590>
    c450:      	cmp	x20, #0x6
    c454:      	b.ne	0xc614 <_stogir.conversion.policy+0x5a0>
    c458:      	ldr	x0, [sp, #0x10]
    c45c:      	b	0xc618 <_stogir.conversion.policy+0x5a4>
    c460:      	movz	x0, #0x0, lsl #48
    c464:      	b	0xc36c <_stogir.conversion.policy+0x2f8>
    c468:      	mov	x3, #0x1                ; =1
    c46c:      	cmp	x3, #0x0
    c470:      	b.ne	0xc2a8 <_stogir.conversion.policy+0x234>
    c474:      	cmp	x19, #0x23
    c478:      	b.eq	0xc48c <_stogir.conversion.policy+0x418>
    c47c:      	uxtb	w16, w2
    c480:      	cmp	w16, wzr
    c484:      	b.ne	0xc48c <_stogir.conversion.policy+0x418>
    c488:      	mov	x0, x1
    c48c:      	and	x0, x0, #0xffffffff
    c490:      	mov	x1, x0
    c494:      	movz	x0, #0x0, lsl #48
    c498:      	movz	x2, #0x0, lsl #48
    c49c:      	b	0xc2c0 <_stogir.conversion.policy+0x24c>
    c4a0:      	movz	x3, #0x0, lsl #48
    c4a4:      	cmp	x3, #0x0
    c4a8:      	cset	w3, ne
    c4ac:      	uxtb	w16, w3
    c4b0:      	cmp	w16, wzr
    c4b4:      	cset	x3, eq
    c4b8:      	b	0xc46c <_stogir.conversion.policy+0x3f8>
    c4bc:      	cmp	x19, #0x24
    c4c0:      	b.ne	0xc4dc <_stogir.conversion.policy+0x468>
    c4c4:      	cmp	x1, x0
    c4c8:      	cset	w3, eq
    c4cc:      	uxtb	w16, w3
    c4d0:      	cmp	w16, wzr
    c4d4:      	cset	x3, eq
    c4d8:      	b	0xc46c <_stogir.conversion.policy+0x3f8>
    c4dc:      	uxtb	w16, w3
    c4e0:      	cmp	w16, wzr
    c4e4:      	b.eq	0xc468 <_stogir.conversion.policy+0x3f4>
    c4e8:      	uxtb	w16, w4
    c4ec:      	cmp	w16, wzr
    c4f0:      	b.eq	0xc468 <_stogir.conversion.policy+0x3f4>
    c4f4:      	uxtb	w16, w5
    c4f8:      	cmp	w16, wzr
    c4fc:      	b.eq	0xc598 <_stogir.conversion.policy+0x524>
    c500:      	uxtb	w16, w6
    c504:      	cmp	w16, wzr
    c508:      	b.eq	0xc598 <_stogir.conversion.policy+0x524>
    c50c:      	cmp	x19, #0x23
    c510:      	b.ne	0xc5ec <_stogir.conversion.policy+0x578>
    c514:      	cmp	x0, x1
    c518:      	cset	w3, ge
    c51c:      	ubfx	x3, x3, #0, #8
    c520:      	b	0xc5f8 <_stogir.conversion.policy+0x584>
    c524:      	movz	x3, #0x0, lsl #48
    c528:      	b	0xc4a4 <_stogir.conversion.policy+0x430>
    c52c:      	uxtb	w16, w2
    c530:      	cmp	w16, wzr
    c534:      	b.eq	0xc570 <_stogir.conversion.policy+0x4fc>
    c538:      	uxtb	w16, w25
    c53c:      	cmp	w16, wzr
    c540:      	b.ne	0xc5b0 <_stogir.conversion.policy+0x53c>
    c544:      	uxtb	w16, w24
    c548:      	cmp	w16, wzr
    c54c:      	b.ne	0xc5b0 <_stogir.conversion.policy+0x53c>
    c550:      	movz	x3, #0x0, lsl #48
    c554:      	b	0xc56c <_stogir.conversion.policy+0x4f8>
    c558:      	mov	x0, #0x2                ; =2
    c55c:      	b	0xc1c0 <_stogir.conversion.policy+0x14c>
    c560:      	mov	x0, #0x2                ; =2
    c564:      	b	0xc170 <_stogir.conversion.policy+0xfc>
    c568:      	movz	x3, #0x0, lsl #48
    c56c:      	b	0xc4a4 <_stogir.conversion.policy+0x430>
    c570:      	cmp	x19, #0x27
    c574:      	b.ne	0xc4a0 <_stogir.conversion.policy+0x42c>
    c578:      	uxtb	w16, w25
    c57c:      	cmp	w16, wzr
    c580:      	b.ne	0xc5d8 <_stogir.conversion.policy+0x564>
    c584:      	uxtb	w16, w24
    c588:      	cmp	w16, wzr
    c58c:      	b.ne	0xc5d8 <_stogir.conversion.policy+0x564>
    c590:      	movz	x3, #0x0, lsl #48
    c594:      	b	0xc5ac <_stogir.conversion.policy+0x538>
    c598:      	mov	x3, #0x1                ; =1
    c59c:      	b	0xc46c <_stogir.conversion.policy+0x3f8>
    c5a0:      	mov	x3, x23
    c5a4:      	b	0xc528 <_stogir.conversion.policy+0x4b4>
    c5a8:      	mov	x3, x23
    c5ac:      	b	0xc4a4 <_stogir.conversion.policy+0x430>
    c5b0:      	uxtb	w16, w5
    c5b4:      	cmp	w16, wzr
    c5b8:      	b.eq	0xc568 <_stogir.conversion.policy+0x4f4>
    c5bc:      	ubfx	x6, x6, #0, #8
    c5c0:      	mov	x3, x6
    c5c4:      	b	0xc56c <_stogir.conversion.policy+0x4f8>
    c5c8:      	mov	x0, #0x4                ; =4
    c5cc:      	b	0xc55c <_stogir.conversion.policy+0x4e8>
    c5d0:      	mov	x0, #0x4                ; =4
    c5d4:      	b	0xc564 <_stogir.conversion.policy+0x4f0>
    c5d8:      	uxtb	w16, w28
    c5dc:      	cmp	w16, wzr
    c5e0:      	b.eq	0xc5a8 <_stogir.conversion.policy+0x534>
    c5e4:      	mov	x3, #0x1                ; =1
    c5e8:      	b	0xc5ac <_stogir.conversion.policy+0x538>
    c5ec:      	cmp	x0, x1
    c5f0:      	cset	w3, le
    c5f4:      	ubfx	x3, x3, #0, #8
    c5f8:      	b	0xc59c <_stogir.conversion.policy+0x528>
    c5fc:      	mov	x0, #0x8                ; =8
    c600:      	b	0xc5cc <_stogir.conversion.policy+0x558>
    c604:      	mov	x0, #0x8                ; =8
    c608:      	b	0xc5d4 <_stogir.conversion.policy+0x560>
    c60c:      	movn	x0, #0x0, lsl #48
    c610:      	b	0xc600 <_stogir.conversion.policy+0x58c>
    c614:      	movn	x0, #0x0, lsl #48
    c618:      	b	0xc608 <_stogir.conversion.policy+0x594>
    c61c:      	str	x8, [sp, #0x18]
    c620:      	mov	w28, w3
    c624:      	str	x23, [sp, #0x10]
    c628:      	mov	w23, w2
    c62c:      	b	0xc288 <_stogir.conversion.policy+0x214>
    c630:      	mov	x22, x0
    c634:      	mov	w23, w1
    c638:      	mov	w28, w2
    c63c:      	b	0xc268 <_stogir.conversion.policy+0x1f4>

000000000000c640 <_stogir.conditional.operands>:
    c640:      	sub	sp, sp, #0x60
    c644:      	str	x29, [sp]
    c648:      	str	x30, [sp, #0x8]
    c64c:      	mov	x29, sp
    c650:      	str	x19, [sp, #0x30]
    c654:      	str	x20, [sp, #0x38]
    c658:      	str	x21, [sp, #0x40]
    c65c:      	str	x22, [sp, #0x48]
    c660:      	str	x23, [sp, #0x50]
    c664:      	str	x24, [sp, #0x58]
    c668:      	sxtw	x19, w1
    c66c:      	cmp	x19, #0x0
    c670:      	b.ne	0xc748 <_stogir.conditional.operands+0x108>
    c674:      	mov	x20, x8
    c678:      	mov	x21, x0
    c67c:      	mov	w22, w2
    c680:      	mov	w23, w3
    c684:      	mov	w24, w4
    c688:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000c688:  ARM64_RELOC_PAGE21	l_stogir.466
    c68c:      	ldr	x16, [x16]
		000000000000c68c:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    c690:      	orr	x0, x16, xzr
    c694:      	mov	x1, #0x2b               ; =43
    c698:      	sxtw	x22, w22
    c69c:      	cmp	x22, #0x0
    c6a0:      	cset	w2, gt
    c6a4:      	movz	x16, #0x0, lsl #48
    c6a8:      	sub	x3, x16, x22
    c6ac:      	sub	x4, x3, #0x1
    c6b0:      	uxtb	w16, w2
    c6b4:      	cmp	w16, wzr
    c6b8:      	b.eq	0xc6fc <_stogir.conditional.operands+0xbc>
    c6bc:      	ldr	x3, [x21, #0x8]
    c6c0:      	cmp	x22, x3
    c6c4:      	b.ge	0xc794 <_stogir.conditional.operands+0x154>
    c6c8:      	add	x3, x21, #0x78
    c6cc:      	ldr	x3, [x3, #0x8]
    c6d0:      	cmp	x22, x3
    c6d4:      	b.ge	0xcb3c <_stogir.conditional.operands+0x4fc>
    c6d8:      	lsl	x3, x22, #2
    c6dc:      	ldr	x5, [x21, #0x78]
    c6e0:      	add	x3, x3, x5
    c6e4:      	ldr	w3, [x3]
    c6e8:      	sxtw	x3, w3
    c6ec:      	cmp	x3, #0x0
    c6f0:      	cset	w3, ge
    c6f4:      	ubfx	x3, x3, #0, #8
    c6f8:      	b	0xcb40 <_stogir.conditional.operands+0x500>
    c6fc:      	cmp	x22, #0x0
    c700:      	b.ge	0xc79c <_stogir.conditional.operands+0x15c>
    c704:      	add	x5, x21, #0x28
    c708:      	add	x6, x21, #0x50
    c70c:      	ldr	x5, [x5, #0x8]
    c710:      	ldr	x6, [x6, #0x8]
    c714:      	cmp	x5, x6
    c718:      	b.ne	0xc784 <_stogir.conditional.operands+0x144>
    c71c:      	cmp	x3, x5
    c720:      	b.gt	0xcb44 <_stogir.conditional.operands+0x504>
    c724:      	lsl	x3, x4, #2
    c728:      	ldr	x5, [x21, #0x50]
    c72c:      	add	x3, x3, x5
    c730:      	ldr	w3, [x3]
    c734:      	sxtw	x3, w3
    c738:      	cmp	x3, #0x0
    c73c:      	cset	w3, gt
    c740:      	ubfx	x3, x3, #0, #8
    c744:      	b	0xcb48 <_stogir.conditional.operands+0x508>
    c748:      	lsr	w1, w1, #0
    c74c:      	mov	x20, x8
    c750:      	mov	x21, x0
    c754:      	mov	w0, w1
    c758:      	mov	w22, w2
    c75c:      	mov	w23, w3
    c760:      	mov	w24, w4
    c764:      	bl	0xc764 <_stogir.conditional.operands+0x124>
		000000000000c764:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    c768:      	cmp	x0, #0x0
    c76c:      	b.eq	0xc688 <_stogir.conditional.operands+0x48>
    c770:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000c770:  ARM64_RELOC_PAGE21	l_stogir.467
    c774:      	ldr	x16, [x16]
		000000000000c774:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    c778:      	orr	x0, x16, xzr
    c77c:      	movz	x1, #0x0, lsl #48
    c780:      	b	0xc698 <_stogir.conditional.operands+0x58>
    c784:      	movz	x3, #0x0, lsl #48
    c788:      	b	0xc7a0 <_stogir.conditional.operands+0x160>
    c78c:      	movz	x11, #0x0, lsl #48
    c790:      	b	0xc848 <_stogir.conditional.operands+0x208>
    c794:      	movz	x3, #0x0, lsl #48
    c798:      	b	0xc7a0 <_stogir.conditional.operands+0x160>
    c79c:      	movz	x3, #0x0, lsl #48
    c7a0:      	cmp	x3, #0x0
    c7a4:      	b.eq	0xc7e4 <_stogir.conditional.operands+0x1a4>
    c7a8:      	uxtb	w16, w2
    c7ac:      	cmp	w16, wzr
    c7b0:      	b.eq	0xc7c8 <_stogir.conditional.operands+0x188>
    c7b4:      	lsl	x2, x22, #4
    c7b8:      	ldr	x3, [x21]
    c7bc:      	add	x2, x2, x3
    c7c0:      	ldr	x2, [x2]
    c7c4:      	b	0xc7d8 <_stogir.conditional.operands+0x198>
    c7c8:      	lsl	x2, x4, #4
    c7cc:      	ldr	x3, [x21, #0x28]
    c7d0:      	add	x2, x2, x3
    c7d4:      	ldr	x2, [x2]
    c7d8:      	mov	x3, x2
    c7dc:      	mov	x2, #0x1                ; =1
    c7e0:      	b	0xc7ec <_stogir.conditional.operands+0x1ac>
    c7e4:      	movz	x2, #0x0, lsl #48
    c7e8:      	movz	x3, #0x0, lsl #48
    c7ec:      	lsr	w2, w2, #0
    c7f0:      	lsr	x16, x2, #0
    c7f4:      	cmp	x16, #0x1
    c7f8:      	b.eq	0xc814 <_stogir.conditional.operands+0x1d4>
    c7fc:      	b.lo	0xc804 <_stogir.conditional.operands+0x1c4>
    c800:      	b	0xc818 <_stogir.conditional.operands+0x1d8>
    c804:      	cmp	x16, #0x0
    c808:      	b.eq	0xc810 <_stogir.conditional.operands+0x1d0>
    c80c:      	b	0xc818 <_stogir.conditional.operands+0x1d8>
    c810:      	b	0xc81c <_stogir.conditional.operands+0x1dc>
    c814:      	b	0xc84c <_stogir.conditional.operands+0x20c>
    c818:      	b	0xcb5c <_stogir.conditional.operands+0x51c>
    c81c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000c81c:  ARM64_RELOC_PAGE21	l_stogir.468
    c820:      	ldr	x16, [x16]
		000000000000c820:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    c824:      	orr	x0, x16, xzr
    c828:      	mov	x1, #0x16               ; =22
    c82c:      	b	0xc890 <_stogir.conditional.operands+0x250>
    c830:      	movz	x11, #0x0, lsl #48
    c834:      	fmov	d31, x10
    c838:      	mov	x10, x11
    c83c:      	fmov	x11, d31
    c840:      	b	0xc8f4 <_stogir.conditional.operands+0x2b4>
    c844:      	movz	x11, #0x0, lsl #48
    c848:      	b	0xc8fc <_stogir.conditional.operands+0x2bc>
    c84c:      	uxtb	w2, w3
    c850:      	cmp	x2, #0x48
    c854:      	b.eq	0xc880 <_stogir.conditional.operands+0x240>
    c858:      	cmp	x2, #0x46
    c85c:      	b.eq	0xc880 <_stogir.conditional.operands+0x240>
    c860:      	lsr	w3, w3, #0
    c864:      	orr	x2, x3, xzr
    c868:      	ubfx	x2, x2, #8, #8
    c86c:      	cmp	x2, #0x0
    c870:      	b.eq	0xc880 <_stogir.conditional.operands+0x240>
    c874:      	ubfx	x2, x3, #8, #8
    c878:      	cmp	x2, #0xd
    c87c:      	b.le	0xc890 <_stogir.conditional.operands+0x250>
    c880:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000c880:  ARM64_RELOC_PAGE21	l_stogir.469
    c884:      	ldr	x16, [x16]
		000000000000c884:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    c888:      	orr	x0, x16, xzr
    c88c:      	mov	x1, #0x2a               ; =42
    c890:      	add	x16, sp, #0x20
    c894:      	orr	x2, x16, xzr
    c898:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000c898:  ARM64_RELOC_PAGE21	l_stogir.470
    c89c:      	ldr	x16, [x16]
		000000000000c89c:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    c8a0:      	orr	x3, x16, xzr
    c8a4:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000c8a4:  ARM64_RELOC_PAGE21	l_stogir.471
    c8a8:      	ldr	x16, [x16]
		000000000000c8a8:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    c8ac:      	orr	x4, x16, xzr
    c8b0:      	lsr	w23, w23, #0
    c8b4:      	lsr	w24, w24, #0
    c8b8:      	add	x5, x21, #0x78
    c8bc:      	add	x6, x21, #0x28
    c8c0:      	add	x7, x21, #0x50
    c8c4:      	add	x16, sp, #0x10
    c8c8:      	str	w23, [x16]
    c8cc:      	add	x16, sp, #0x10
    c8d0:      	str	w24, [x16, #0x4]
    c8d4:      	add	x16, sp, #0x10
    c8d8:      	ldr	x8, [x16]
    c8dc:      	add	x16, sp, #0x20
    c8e0:      	str	x8, [x16]
    c8e4:      	movz	x8, #0x0, lsl #48
    c8e8:      	b	0xc9cc <_stogir.conditional.operands+0x38c>
    c8ec:      	mov	x11, x10
    c8f0:      	movz	x10, #0x0, lsl #48
    c8f4:      	b	0xc908 <_stogir.conditional.operands+0x2c8>
    c8f8:      	movz	x11, #0x0, lsl #48
    c8fc:      	fmov	d31, x10
    c900:      	mov	x10, x11
    c904:      	fmov	x11, d31
    c908:      	cmp	x10, #0x0
    c90c:      	b.eq	0xc950 <_stogir.conditional.operands+0x310>
    c910:      	uxtb	w16, w8
    c914:      	cmp	w16, wzr
    c918:      	b.eq	0xc930 <_stogir.conditional.operands+0x2f0>
    c91c:      	lsl	x8, x9, #4
    c920:      	ldr	x9, [x21]
    c924:      	add	x8, x8, x9
    c928:      	ldr	x8, [x8]
    c92c:      	b	0xc940 <_stogir.conditional.operands+0x300>
    c930:      	lsl	x8, x12, #4
    c934:      	ldr	x9, [x21, #0x28]
    c938:      	add	x8, x8, x9
    c93c:      	ldr	x8, [x8]
    c940:      	mov	x9, x8
    c944:      	mov	x10, x11
    c948:      	mov	x8, #0x1                ; =1
    c94c:      	b	0xc95c <_stogir.conditional.operands+0x31c>
    c950:      	mov	x10, x11
    c954:      	movz	x8, #0x0, lsl #48
    c958:      	movz	x9, #0x0, lsl #48
    c95c:      	lsr	w8, w8, #0
    c960:      	lsr	x16, x8, #0
    c964:      	cmp	x16, #0x1
    c968:      	b.eq	0xc984 <_stogir.conditional.operands+0x344>
    c96c:      	b.lo	0xc974 <_stogir.conditional.operands+0x334>
    c970:      	b	0xc988 <_stogir.conditional.operands+0x348>
    c974:      	cmp	x16, #0x0
    c978:      	b.eq	0xc980 <_stogir.conditional.operands+0x340>
    c97c:      	b	0xc988 <_stogir.conditional.operands+0x348>
    c980:      	b	0xc98c <_stogir.conditional.operands+0x34c>
    c984:      	b	0xc99c <_stogir.conditional.operands+0x35c>
    c988:      	b	0xcb54 <_stogir.conditional.operands+0x514>
    c98c:      	mov	x0, x3
    c990:      	mov	x8, x10
    c994:      	mov	x1, #0x10               ; =16
    c998:      	b	0xc9cc <_stogir.conditional.operands+0x38c>
    c99c:      	uxtb	w8, w9
    c9a0:      	cmp	x8, #0x48
    c9a4:      	b.eq	0xc9c0 <_stogir.conditional.operands+0x380>
    c9a8:      	cmp	x8, #0x46
    c9ac:      	b.eq	0xc9c0 <_stogir.conditional.operands+0x380>
    c9b0:      	lsr	w9, w9, #0
    c9b4:      	ubfx	x8, x9, #8, #8
    c9b8:      	cmp	x8, x19
    c9bc:      	b.eq	0xc9c8 <_stogir.conditional.operands+0x388>
    c9c0:      	mov	x0, x4
    c9c4:      	mov	x1, #0x21               ; =33
    c9c8:      	mov	x8, x10
    c9cc:      	cmp	x8, #0x2
    c9d0:      	b.ge	0xc9fc <_stogir.conditional.operands+0x3bc>
    c9d4:      	add	x9, x8, #0x1
    c9d8:      	lsl	x8, x8, #2
    c9dc:      	add	x8, x8, x2
    c9e0:      	ldr	w8, [x8]
    c9e4:      	sxtw	x8, w8
    c9e8:      	and	x8, x8, #0xffffffff
    c9ec:      	mov	x10, x9
    c9f0:      	mov	x9, x8
    c9f4:      	mov	x8, #0x1                ; =1
    c9f8:      	b	0xca08 <_stogir.conditional.operands+0x3c8>
    c9fc:      	mov	x10, x8
    ca00:      	movz	x8, #0x0, lsl #48
    ca04:      	movz	x9, #0x0, lsl #48
    ca08:      	lsr	w8, w8, #0
    ca0c:      	lsr	x16, x8, #0
    ca10:      	cmp	x16, #0x1
    ca14:      	b.eq	0xca30 <_stogir.conditional.operands+0x3f0>
    ca18:      	b.lo	0xca20 <_stogir.conditional.operands+0x3e0>
    ca1c:      	b	0xca34 <_stogir.conditional.operands+0x3f4>
    ca20:      	cmp	x16, #0x0
    ca24:      	b.eq	0xca2c <_stogir.conditional.operands+0x3ec>
    ca28:      	b	0xca34 <_stogir.conditional.operands+0x3f4>
    ca2c:      	b	0xca9c <_stogir.conditional.operands+0x45c>
    ca30:      	b	0xca38 <_stogir.conditional.operands+0x3f8>
    ca34:      	b	0xcb4c <_stogir.conditional.operands+0x50c>
    ca38:      	lsr	w9, w9, #0
    ca3c:      	sxtw	x9, w9
    ca40:      	cmp	x9, #0x0
    ca44:      	cset	w8, gt
    ca48:      	movz	x16, #0x0, lsl #48
    ca4c:      	sub	x11, x16, x9
    ca50:      	sub	x12, x11, #0x1
    ca54:      	uxtb	w16, w8
    ca58:      	cmp	w16, wzr
    ca5c:      	b.eq	0xcaf8 <_stogir.conditional.operands+0x4b8>
    ca60:      	ldr	x11, [x21, #0x8]
    ca64:      	cmp	x9, x11
    ca68:      	b.ge	0xc8ec <_stogir.conditional.operands+0x2ac>
    ca6c:      	ldr	x11, [x5, #0x8]
    ca70:      	cmp	x9, x11
    ca74:      	b.ge	0xc830 <_stogir.conditional.operands+0x1f0>
    ca78:      	lsl	x11, x9, #2
    ca7c:      	ldr	x13, [x21, #0x78]
    ca80:      	add	x11, x11, x13
    ca84:      	ldr	w11, [x11]
    ca88:      	sxtw	x11, w11
    ca8c:      	cmp	x11, #0x0
    ca90:      	cset	w11, ge
    ca94:      	ubfx	x11, x11, #0, #8
    ca98:      	b	0xc834 <_stogir.conditional.operands+0x1f4>
    ca9c:      	cmp	x1, #0x0
    caa0:      	b.ne	0xcab8 <_stogir.conditional.operands+0x478>
    caa4:      	and	x0, x19, #0xffffffff
    caa8:      	mov	x1, x0
    caac:      	movz	x0, #0x0, lsl #48
    cab0:      	movz	x2, #0x0, lsl #48
    cab4:      	b	0xcac4 <_stogir.conditional.operands+0x484>
    cab8:      	mov	x2, x1
    cabc:      	mov	x1, x0
    cac0:      	mov	x0, #0x1                ; =1
    cac4:      	str	x0, [x20]
    cac8:      	str	x1, [x20, #0x8]
    cacc:      	str	x2, [x20, #0x10]
    cad0:      	ldr	x19, [sp, #0x30]
    cad4:      	ldr	x20, [sp, #0x38]
    cad8:      	ldr	x21, [sp, #0x40]
    cadc:      	ldr	x22, [sp, #0x48]
    cae0:      	ldr	x23, [sp, #0x50]
    cae4:      	ldr	x24, [sp, #0x58]
    cae8:      	ldr	x29, [sp]
    caec:      	ldr	x30, [sp, #0x8]
    caf0:      	add	sp, sp, #0x60
    caf4:      	ret
    caf8:      	cmp	x9, #0x0
    cafc:      	b.ge	0xc8f8 <_stogir.conditional.operands+0x2b8>
    cb00:      	ldr	x13, [x6, #0x8]
    cb04:      	ldr	x14, [x7, #0x8]
    cb08:      	cmp	x13, x14
    cb0c:      	b.ne	0xc844 <_stogir.conditional.operands+0x204>
    cb10:      	cmp	x11, x13
    cb14:      	b.gt	0xc78c <_stogir.conditional.operands+0x14c>
    cb18:      	lsl	x11, x12, #2
    cb1c:      	ldr	x13, [x21, #0x50]
    cb20:      	add	x11, x11, x13
    cb24:      	ldr	w11, [x11]
    cb28:      	sxtw	x11, w11
    cb2c:      	cmp	x11, #0x0
    cb30:      	cset	w11, gt
    cb34:      	ubfx	x11, x11, #0, #8
    cb38:      	b	0xc790 <_stogir.conditional.operands+0x150>
    cb3c:      	movz	x3, #0x0, lsl #48
    cb40:      	b	0xc798 <_stogir.conditional.operands+0x158>
    cb44:      	movz	x3, #0x0, lsl #48
    cb48:      	b	0xc788 <_stogir.conditional.operands+0x148>
    cb4c:      	brk	#0
    cb50:      	b	0xcb4c <_stogir.conditional.operands+0x50c>
    cb54:      	brk	#0
    cb58:      	b	0xcb54 <_stogir.conditional.operands+0x514>
    cb5c:      	brk	#0
    cb60:      	b	0xcb5c <_stogir.conditional.operands+0x51c>

000000000000cb64 <_stogir.floating.unary?>:
    cb64:      	sxtw	x0, w0
    cb68:      	cmp	x0, #0x1f
    cb6c:      	b.ne	0xcb78 <_stogir.floating.unary?+0x14>
    cb70:      	mov	x0, #0x1                ; =1
    cb74:      	b	0xcb84 <_stogir.floating.unary?+0x20>
    cb78:      	cmp	x0, #0x20
    cb7c:      	cset	w0, eq
    cb80:      	ubfx	x0, x0, #0, #8
    cb84:      	ret

000000000000cb88 <_stogir.floating.comparison?>:
    cb88:      	sxtw	x0, w0
    cb8c:      	cmp	x0, #0xe
    cb90:      	b.lt	0xcba4 <_stogir.floating.comparison?+0x1c>
    cb94:      	cmp	x0, #0x19
    cb98:      	cset	w0, le
    cb9c:      	ubfx	x0, x0, #0, #8
    cba0:      	b	0xcba8 <_stogir.floating.comparison?+0x20>
    cba4:      	movz	x0, #0x0, lsl #48
    cba8:      	ret

000000000000cbac <_stogir.floating.operands>:
    cbac:      	sub	sp, sp, #0x90
    cbb0:      	str	x29, [sp]
    cbb4:      	str	x30, [sp, #0x8]
    cbb8:      	mov	x29, sp
    cbbc:      	str	x19, [sp, #0x60]
    cbc0:      	str	x20, [sp, #0x68]
    cbc4:      	str	x21, [sp, #0x70]
    cbc8:      	str	x22, [sp, #0x78]
    cbcc:      	str	x23, [sp, #0x80]
    cbd0:      	sxtw	x1, w1
    cbd4:      	sxtw	x19, w2
    cbd8:      	cmp	x1, #0x1f
    cbdc:      	cset	w2, eq
    cbe0:      	cmp	x1, #0x20
    cbe4:      	cset	w6, eq
    cbe8:      	cmp	x1, #0xe
    cbec:      	b.lt	0xcc1c <_stogir.floating.operands+0x70>
    cbf0:      	cmp	x1, #0x19
    cbf4:      	b.gt	0xcc1c <_stogir.floating.operands+0x70>
    cbf8:      	cmp	x19, #0xc
    cbfc:      	b.eq	0xcc58 <_stogir.floating.operands+0xac>
    cc00:      	cmp	x19, #0xd
    cc04:      	b.eq	0xcc58 <_stogir.floating.operands+0xac>
    cc08:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000cc08:  ARM64_RELOC_PAGE21	l_stogir.472
    cc0c:      	ldr	x16, [x16]
		000000000000cc0c:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    cc10:      	orr	x7, x16, xzr
    cc14:      	mov	x9, #0x22               ; =34
    cc18:      	b	0xcc68 <_stogir.floating.operands+0xbc>
    cc1c:      	uxtb	w16, w2
    cc20:      	cmp	w16, wzr
    cc24:      	b.ne	0xcbf8 <_stogir.floating.operands+0x4c>
    cc28:      	uxtb	w16, w6
    cc2c:      	cmp	w16, wzr
    cc30:      	b.ne	0xcbf8 <_stogir.floating.operands+0x4c>
    cc34:      	cmp	x1, #0x1a
    cc38:      	b.lt	0xcc44 <_stogir.floating.operands+0x98>
    cc3c:      	cmp	x1, #0x1d
    cc40:      	b.le	0xcbf8 <_stogir.floating.operands+0x4c>
    cc44:      	cmp	x1, #0x3a
    cc48:      	b.eq	0xcbf8 <_stogir.floating.operands+0x4c>
    cc4c:      	cmp	x1, #0x3b
    cc50:      	b.eq	0xcbf8 <_stogir.floating.operands+0x4c>
    cc54:      	b	0xcc08 <_stogir.floating.operands+0x5c>
    cc58:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000cc58:  ARM64_RELOC_PAGE21	l_stogir.473
    cc5c:      	ldr	x16, [x16]
		000000000000cc5c:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    cc60:      	orr	x7, x16, xzr
    cc64:      	movz	x9, #0x0, lsl #48
    cc68:      	lsr	w3, w3, #0
    cc6c:      	add	x16, sp, #0x10
    cc70:      	str	w3, [x16]
    cc74:      	uxtb	w16, w2
    cc78:      	cmp	w16, wzr
    cc7c:      	b.ne	0xcd04 <_stogir.floating.operands+0x158>
    cc80:      	uxtb	w16, w6
    cc84:      	cmp	w16, wzr
    cc88:      	b.ne	0xcd04 <_stogir.floating.operands+0x158>
    cc8c:      	sxtw	x4, w4
    cc90:      	mov	x2, x4
    cc94:      	b	0xcd0c <_stogir.floating.operands+0x160>
    cc98:      	movz	x1, #0x0, lsl #48
    cc9c:      	uxtb	w1, w1
    cca0:      	and	x1, x1, #0x2
    cca4:      	uxtb	w1, w1
    cca8:      	cmp	x1, #0x0
    ccac:      	cset	w1, eq
    ccb0:      	uxtb	w16, w1
    ccb4:      	cmp	w16, wzr
    ccb8:      	cset	x1, eq
    ccbc:      	cmp	x1, #0x0
    ccc0:      	b.ne	0xd078 <_stogir.floating.operands+0x4cc>
    ccc4:      	cmp	x0, #0x65
    ccc8:      	b.eq	0xd078 <_stogir.floating.operands+0x4cc>
    cccc:      	cmp	x0, #0x66
    ccd0:      	b.eq	0xd078 <_stogir.floating.operands+0x4cc>
    ccd4:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000ccd4:  ARM64_RELOC_PAGE21	l_stogir.474
    ccd8:      	ldr	x16, [x16]
		000000000000ccd8:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    ccdc:      	orr	x0, x16, xzr
    cce0:      	mov	x1, #0x2d               ; =45
    cce4:      	b	0xce20 <_stogir.floating.operands+0x274>
    cce8:      	movz	x13, #0x0, lsl #48
    ccec:      	fmov	d31, x9
    ccf0:      	mov	x9, x13
    ccf4:      	fmov	x13, d31
    ccf8:      	b	0xcd6c <_stogir.floating.operands+0x1c0>
    ccfc:      	movz	x13, #0x0, lsl #48
    cd00:      	b	0xcd74 <_stogir.floating.operands+0x1c8>
    cd04:      	sxtw	x3, w3
    cd08:      	mov	x2, x3
    cd0c:      	add	x16, sp, #0x20
    cd10:      	orr	x3, x16, xzr
    cd14:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000cd14:  ARM64_RELOC_PAGE21	l_stogir.475
    cd18:      	ldr	x16, [x16]
		000000000000cd18:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    cd1c:      	orr	x4, x16, xzr
    cd20:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000cd20:  ARM64_RELOC_PAGE21	l_stogir.476
    cd24:      	ldr	x16, [x16]
		000000000000cd24:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    cd28:      	orr	x6, x16, xzr
    cd2c:      	add	x10, x0, #0x78
    cd30:      	add	x11, x0, #0x28
    cd34:      	add	x12, x0, #0x50
    cd38:      	lsr	w2, w2, #0
    cd3c:      	add	x16, sp, #0x10
    cd40:      	str	w2, [x16, #0x4]
    cd44:      	add	x16, sp, #0x10
    cd48:      	ldr	x2, [x16]
    cd4c:      	add	x16, sp, #0x20
    cd50:      	str	x2, [x16]
    cd54:      	mov	x20, x7
    cd58:      	mov	x21, x9
    cd5c:      	movz	x2, #0x0, lsl #48
    cd60:      	b	0xce38 <_stogir.floating.operands+0x28c>
    cd64:      	mov	x13, x9
    cd68:      	movz	x9, #0x0, lsl #48
    cd6c:      	b	0xcd80 <_stogir.floating.operands+0x1d4>
    cd70:      	movz	x13, #0x0, lsl #48
    cd74:      	fmov	d31, x9
    cd78:      	mov	x9, x13
    cd7c:      	fmov	x13, d31
    cd80:      	cmp	x9, #0x0
    cd84:      	b.eq	0xcdc8 <_stogir.floating.operands+0x21c>
    cd88:      	uxtb	w16, w2
    cd8c:      	cmp	w16, wzr
    cd90:      	b.eq	0xcda8 <_stogir.floating.operands+0x1fc>
    cd94:      	lsl	x2, x7, #4
    cd98:      	ldr	x7, [x0]
    cd9c:      	add	x2, x2, x7
    cda0:      	ldr	x2, [x2]
    cda4:      	b	0xcdb8 <_stogir.floating.operands+0x20c>
    cda8:      	lsl	x2, x14, #4
    cdac:      	ldr	x7, [x0, #0x28]
    cdb0:      	add	x2, x2, x7
    cdb4:      	ldr	x2, [x2]
    cdb8:      	mov	x7, x2
    cdbc:      	mov	x9, x13
    cdc0:      	mov	x2, #0x1                ; =1
    cdc4:      	b	0xcdd4 <_stogir.floating.operands+0x228>
    cdc8:      	mov	x9, x13
    cdcc:      	movz	x2, #0x0, lsl #48
    cdd0:      	movz	x7, #0x0, lsl #48
    cdd4:      	lsr	w2, w2, #0
    cdd8:      	lsr	x16, x2, #0
    cddc:      	cmp	x16, #0x1
    cde0:      	b.eq	0xcdfc <_stogir.floating.operands+0x250>
    cde4:      	b.lo	0xcdec <_stogir.floating.operands+0x240>
    cde8:      	b	0xce00 <_stogir.floating.operands+0x254>
    cdec:      	cmp	x16, #0x0
    cdf0:      	b.eq	0xcdf8 <_stogir.floating.operands+0x24c>
    cdf4:      	b	0xce00 <_stogir.floating.operands+0x254>
    cdf8:      	b	0xce04 <_stogir.floating.operands+0x258>
    cdfc:      	b	0xd020 <_stogir.floating.operands+0x474>
    ce00:      	b	0xd08c <_stogir.floating.operands+0x4e0>
    ce04:      	mov	x2, x4
    ce08:      	mov	x7, #0x18               ; =24
    ce0c:      	b	0xce2c <_stogir.floating.operands+0x280>
    ce10:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000ce10:  ARM64_RELOC_PAGE21	l_stogir.477
    ce14:      	ldr	x16, [x16]
		000000000000ce14:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    ce18:      	orr	x0, x16, xzr
    ce1c:      	mov	x1, #0x21               ; =33
    ce20:      	b	0xcf20 <_stogir.floating.operands+0x374>
    ce24:      	mov	x2, x6
    ce28:      	mov	x7, #0x1e               ; =30
    ce2c:      	mov	x20, x2
    ce30:      	mov	x21, x7
    ce34:      	mov	x2, x9
    ce38:      	cmp	x2, #0x2
    ce3c:      	b.ge	0xce68 <_stogir.floating.operands+0x2bc>
    ce40:      	add	x7, x2, #0x1
    ce44:      	lsl	x2, x2, #2
    ce48:      	add	x2, x2, x3
    ce4c:      	ldr	w2, [x2]
    ce50:      	sxtw	x2, w2
    ce54:      	and	x2, x2, #0xffffffff
    ce58:      	mov	x9, x7
    ce5c:      	mov	x7, x2
    ce60:      	mov	x2, #0x1                ; =1
    ce64:      	b	0xce74 <_stogir.floating.operands+0x2c8>
    ce68:      	mov	x9, x2
    ce6c:      	movz	x2, #0x0, lsl #48
    ce70:      	movz	x7, #0x0, lsl #48
    ce74:      	lsr	w2, w2, #0
    ce78:      	lsr	x16, x2, #0
    ce7c:      	cmp	x16, #0x1
    ce80:      	b.eq	0xce9c <_stogir.floating.operands+0x2f0>
    ce84:      	b.lo	0xce8c <_stogir.floating.operands+0x2e0>
    ce88:      	b	0xcea0 <_stogir.floating.operands+0x2f4>
    ce8c:      	cmp	x16, #0x0
    ce90:      	b.eq	0xce98 <_stogir.floating.operands+0x2ec>
    ce94:      	b	0xcea0 <_stogir.floating.operands+0x2f4>
    ce98:      	b	0xcf08 <_stogir.floating.operands+0x35c>
    ce9c:      	b	0xcea4 <_stogir.floating.operands+0x2f8>
    cea0:      	b	0xd084 <_stogir.floating.operands+0x4d8>
    cea4:      	lsr	w7, w7, #0
    cea8:      	sxtw	x7, w7
    ceac:      	cmp	x7, #0x0
    ceb0:      	cset	w2, gt
    ceb4:      	movz	x16, #0x0, lsl #48
    ceb8:      	sub	x13, x16, x7
    cebc:      	sub	x14, x13, #0x1
    cec0:      	uxtb	w16, w2
    cec4:      	cmp	w16, wzr
    cec8:      	b.eq	0xcfa0 <_stogir.floating.operands+0x3f4>
    cecc:      	ldr	x13, [x0, #0x8]
    ced0:      	cmp	x7, x13
    ced4:      	b.ge	0xcd64 <_stogir.floating.operands+0x1b8>
    ced8:      	ldr	x13, [x10, #0x8]
    cedc:      	cmp	x7, x13
    cee0:      	b.ge	0xcce8 <_stogir.floating.operands+0x13c>
    cee4:      	lsl	x13, x7, #2
    cee8:      	ldr	x15, [x0, #0x78]
    ceec:      	add	x13, x13, x15
    cef0:      	ldr	w13, [x13]
    cef4:      	sxtw	x13, w13
    cef8:      	cmp	x13, #0x0
    cefc:      	cset	w13, ge
    cf00:      	ubfx	x13, x13, #0, #8
    cf04:      	b	0xccec <_stogir.floating.operands+0x140>
    cf08:      	sxtw	x22, w5
    cf0c:      	cmp	x22, #0x0
    cf10:      	b.ne	0xcf3c <_stogir.floating.operands+0x390>
    cf14:      	mov	x23, x8
    cf18:      	mov	x0, x20
    cf1c:      	mov	x1, x21
    cf20:      	cmp	x1, #0x0
    cf24:      	b.ne	0xcfe4 <_stogir.floating.operands+0x438>
    cf28:      	and	x0, x19, #0xffffffff
    cf2c:      	mov	x1, x0
    cf30:      	movz	x0, #0x0, lsl #48
    cf34:      	movz	x2, #0x0, lsl #48
    cf38:      	b	0xcff0 <_stogir.floating.operands+0x444>
    cf3c:      	cmp	x1, #0x1d
    cf40:      	b.ne	0xd09c <_stogir.floating.operands+0x4f0>
    cf44:      	lsr	w5, w5, #0
    cf48:      	mov	w1, w5
    cf4c:      	mov	x23, x8
    cf50:      	add	x8, sp, #0x30
    cf54:      	bl	0xcf54 <_stogir.floating.operands+0x3a8>
		000000000000cf54:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    cf58:      	add	x16, sp, #0x30
    cf5c:      	ldr	w0, [x16]
    cf60:      	lsr	x16, x0, #0
    cf64:      	cmp	x16, #0x1
    cf68:      	b.eq	0xcf84 <_stogir.floating.operands+0x3d8>
    cf6c:      	b.lo	0xcf74 <_stogir.floating.operands+0x3c8>
    cf70:      	b	0xcf88 <_stogir.floating.operands+0x3dc>
    cf74:      	cmp	x16, #0x0
    cf78:      	b.eq	0xcf80 <_stogir.floating.operands+0x3d4>
    cf7c:      	b	0xcf88 <_stogir.floating.operands+0x3dc>
    cf80:      	b	0xcf8c <_stogir.floating.operands+0x3e0>
    cf84:      	b	0xd044 <_stogir.floating.operands+0x498>
    cf88:      	b	0xd094 <_stogir.floating.operands+0x4e8>
    cf8c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x524>
		000000000000cf8c:  ARM64_RELOC_PAGE21	l_stogir.478
    cf90:      	ldr	x16, [x16]
		000000000000cf90:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    cf94:      	orr	x0, x16, xzr
    cf98:      	mov	x1, #0x16               ; =22
    cf9c:      	b	0xcce4 <_stogir.floating.operands+0x138>
    cfa0:      	cmp	x7, #0x0
    cfa4:      	b.ge	0xcd70 <_stogir.floating.operands+0x1c4>
    cfa8:      	ldr	x15, [x11, #0x8]
    cfac:      	ldr	x22, [x12, #0x8]
    cfb0:      	cmp	x15, x22
    cfb4:      	b.ne	0xccfc <_stogir.floating.operands+0x150>
    cfb8:      	cmp	x13, x15
    cfbc:      	b.gt	0xd03c <_stogir.floating.operands+0x490>
    cfc0:      	lsl	x13, x14, #2
    cfc4:      	ldr	x15, [x0, #0x50]
    cfc8:      	add	x13, x13, x15
    cfcc:      	ldr	w13, [x13]
    cfd0:      	sxtw	x13, w13
    cfd4:      	cmp	x13, #0x0
    cfd8:      	cset	w13, gt
    cfdc:      	ubfx	x13, x13, #0, #8
    cfe0:      	b	0xd040 <_stogir.floating.operands+0x494>
    cfe4:      	mov	x2, x1
    cfe8:      	mov	x1, x0
    cfec:      	mov	x0, #0x1                ; =1
    cff0:      	str	x0, [x23]
    cff4:      	str	x1, [x23, #0x8]
    cff8:      	str	x2, [x23, #0x10]
    cffc:      	ldr	x19, [sp, #0x60]
    d000:      	ldr	x20, [sp, #0x68]
    d004:      	ldr	x21, [sp, #0x70]
    d008:      	ldr	x22, [sp, #0x78]
    d00c:      	ldr	x23, [sp, #0x80]
    d010:      	ldr	x29, [sp]
    d014:      	ldr	x30, [sp, #0x8]
    d018:      	add	sp, sp, #0x90
    d01c:      	ret
    d020:      	lsr	w7, w7, #0
    d024:      	ubfx	x2, x7, #8, #8
    d028:      	cmp	x2, x19
    d02c:      	b.ne	0xce24 <_stogir.floating.operands+0x278>
    d030:      	mov	x2, x20
    d034:      	mov	x7, x21
    d038:      	b	0xce2c <_stogir.floating.operands+0x280>
    d03c:      	movz	x13, #0x0, lsl #48
    d040:      	b	0xcd00 <_stogir.floating.operands+0x154>
    d044:      	add	x16, sp, #0x30
    d048:      	ldr	x0, [x16, #0x8]
    d04c:      	cmp	x22, #0x0
    d050:      	b.lt	0xccd4 <_stogir.floating.operands+0x128>
    d054:      	uxtb	w0, w0
    d058:      	cmp	x0, #0x83
    d05c:      	b.ge	0xcc98 <_stogir.floating.operands+0xec>
    d060:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d060:  ARM64_RELOC_PAGE21	l_stogir.479
    d064:      	ldr	x16, [x16]
		000000000000d064:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    d068:      	orr	x1, x16, xzr
    d06c:      	add	x1, x0, x1
    d070:      	ldrb	w1, [x1]
    d074:      	b	0xcc9c <_stogir.floating.operands+0xf0>
    d078:      	mov	x0, x20
    d07c:      	mov	x1, x21
    d080:      	b	0xcce4 <_stogir.floating.operands+0x138>
    d084:      	brk	#0
    d088:      	b	0xd084 <_stogir.floating.operands+0x4d8>
    d08c:      	brk	#0
    d090:      	b	0xd08c <_stogir.floating.operands+0x4e0>
    d094:      	brk	#0
    d098:      	b	0xd094 <_stogir.floating.operands+0x4e8>
    d09c:      	mov	x23, x8
    d0a0:      	b	0xce10 <_stogir.floating.operands+0x264>

000000000000d0a4 <_stogir.types.signed?>:
    d0a4:      	sxtw	x0, w0
    d0a8:      	cmp	x0, #0x7
    d0ac:      	b.lt	0xd0c0 <_stogir.types.signed?+0x1c>
    d0b0:      	cmp	x0, #0xb
    d0b4:      	cset	w0, le
    d0b8:      	ubfx	x0, x0, #0, #8
    d0bc:      	b	0xd0c4 <_stogir.types.signed?+0x20>
    d0c0:      	movz	x0, #0x0, lsl #48
    d0c4:      	ret

000000000000d0c8 <_stogir.integer-binary.logical?>:
    d0c8:      	sxtw	x0, w0
    d0cc:      	cmp	x0, #0x2e
    d0d0:      	b.ne	0xd0ec <_stogir.integer-binary.logical?+0x24>
    d0d4:      	mov	x0, #0x1                ; =1
    d0d8:      	b	0xd0e8 <_stogir.integer-binary.logical?+0x20>
    d0dc:      	cmp	x0, #0x30
    d0e0:      	cset	w0, eq
    d0e4:      	ubfx	x0, x0, #0, #8
    d0e8:      	ret
    d0ec:      	cmp	x0, #0x2f
    d0f0:      	b.ne	0xd0dc <_stogir.integer-binary.logical?+0x14>
    d0f4:      	mov	x0, #0x1                ; =1
    d0f8:      	b	0xd0e8 <_stogir.integer-binary.logical?+0x20>

000000000000d0fc <_inherent$slice$data__i8>:
    d0fc:      	ret

000000000000d100 <_inherent$slice$data__u32>:
    d100:      	ret

000000000000d104 <_inherent$coil.arraylist.ArrayList$slice__stogir.node.Node>:
    d104:      	sub	sp, sp, #0x10
    d108:      	mov	x1, sp
    d10c:      	ldr	x2, [x0]
    d110:      	ldr	x0, [x0, #0x8]
    d114:      	str	x2, [x1]
    d118:      	str	x0, [x1, #0x8]
    d11c:      	ldr	x0, [sp]
    d120:      	ldr	x1, [sp, #0x8]
    d124:      	add	sp, sp, #0x10
    d128:      	ret

000000000000d12c <_inherent$slice$at__stogir.node.Node>:
    d12c:      	lsl	x1, x2, #4
    d130:      	add	x0, x1, x0
    d134:      	ret

000000000000d138 <_inherent$slice$new__u8>:
    d138:      	sub	sp, sp, #0x10
    d13c:      	mov	x2, sp
    d140:      	str	x0, [x2]
    d144:      	str	x1, [x2, #0x8]
    d148:      	ldr	x0, [sp]
    d14c:      	ldr	x1, [sp, #0x8]
    d150:      	add	sp, sp, #0x10
    d154:      	ret

000000000000d158 <_stogir.vector-lanes.operands>:
    d158:      	sub	sp, sp, #0x110
    d15c:      	str	x29, [sp]
    d160:      	str	x30, [sp, #0x8]
    d164:      	mov	x29, sp
    d168:      	str	x19, [sp, #0xc0]
    d16c:      	str	x20, [sp, #0xc8]
    d170:      	str	x21, [sp, #0xd0]
    d174:      	str	x22, [sp, #0xd8]
    d178:      	str	x23, [sp, #0xe0]
    d17c:      	str	x24, [sp, #0xe8]
    d180:      	str	x25, [sp, #0xf0]
    d184:      	str	x26, [sp, #0xf8]
    d188:      	str	x27, [sp, #0x100]
    d18c:      	str	x28, [sp, #0x108]
    d190:      	sxtw	x4, w4
    d194:      	cmp	x4, #0x0
    d198:      	cset	w7, gt
    d19c:      	movz	x16, #0x0, lsl #48
    d1a0:      	sub	x9, x16, x4
    d1a4:      	sub	x10, x9, #0x1
    d1a8:      	uxtb	w16, w7
    d1ac:      	cmp	w16, wzr
    d1b0:      	b.eq	0xd1f4 <_stogir.vector-lanes.operands+0x9c>
    d1b4:      	ldr	x9, [x0, #0x8]
    d1b8:      	cmp	x4, x9
    d1bc:      	b.ge	0xd258 <_stogir.vector-lanes.operands+0x100>
    d1c0:      	add	x9, x0, #0x78
    d1c4:      	ldr	x9, [x9, #0x8]
    d1c8:      	cmp	x4, x9
    d1cc:      	b.ge	0xd368 <_stogir.vector-lanes.operands+0x210>
    d1d0:      	lsl	x9, x4, #2
    d1d4:      	ldr	x11, [x0, #0x78]
    d1d8:      	add	x9, x9, x11
    d1dc:      	ldr	w9, [x9]
    d1e0:      	sxtw	x9, w9
    d1e4:      	cmp	x9, #0x0
    d1e8:      	cset	w9, ge
    d1ec:      	ubfx	x9, x9, #0, #8
    d1f0:      	b	0xd36c <_stogir.vector-lanes.operands+0x214>
    d1f4:      	cmp	x4, #0x0
    d1f8:      	b.ge	0xd260 <_stogir.vector-lanes.operands+0x108>
    d1fc:      	add	x11, x0, #0x28
    d200:      	add	x12, x0, #0x50
    d204:      	ldr	x11, [x11, #0x8]
    d208:      	ldr	x12, [x12, #0x8]
    d20c:      	cmp	x11, x12
    d210:      	b.ne	0xd240 <_stogir.vector-lanes.operands+0xe8>
    d214:      	cmp	x9, x11
    d218:      	b.gt	0xd504 <_stogir.vector-lanes.operands+0x3ac>
    d21c:      	lsl	x9, x10, #2
    d220:      	ldr	x11, [x0, #0x50]
    d224:      	add	x9, x9, x11
    d228:      	ldr	w9, [x9]
    d22c:      	sxtw	x9, w9
    d230:      	cmp	x9, #0x0
    d234:      	cset	w9, gt
    d238:      	ubfx	x9, x9, #0, #8
    d23c:      	b	0xd508 <_stogir.vector-lanes.operands+0x3b0>
    d240:      	movz	x9, #0x0, lsl #48
    d244:      	b	0xd264 <_stogir.vector-lanes.operands+0x10c>
    d248:      	mov	x2, x1
    d24c:      	mov	x1, x0
    d250:      	mov	x0, #0x1                ; =1
    d254:      	b	0xd2fc <_stogir.vector-lanes.operands+0x1a4>
    d258:      	movz	x9, #0x0, lsl #48
    d25c:      	b	0xd264 <_stogir.vector-lanes.operands+0x10c>
    d260:      	movz	x9, #0x0, lsl #48
    d264:      	cmp	x9, #0x0
    d268:      	b.eq	0xd2a8 <_stogir.vector-lanes.operands+0x150>
    d26c:      	uxtb	w16, w7
    d270:      	cmp	w16, wzr
    d274:      	b.eq	0xd28c <_stogir.vector-lanes.operands+0x134>
    d278:      	lsl	x4, x4, #4
    d27c:      	ldr	x7, [x0]
    d280:      	add	x4, x4, x7
    d284:      	ldr	x4, [x4]
    d288:      	b	0xd29c <_stogir.vector-lanes.operands+0x144>
    d28c:      	lsl	x4, x10, #4
    d290:      	ldr	x7, [x0, #0x28]
    d294:      	add	x4, x4, x7
    d298:      	ldr	x4, [x4]
    d29c:      	mov	x7, x4
    d2a0:      	mov	x4, #0x1                ; =1
    d2a4:      	b	0xd2b0 <_stogir.vector-lanes.operands+0x158>
    d2a8:      	movz	x4, #0x0, lsl #48
    d2ac:      	movz	x7, #0x0, lsl #48
    d2b0:      	lsr	w4, w4, #0
    d2b4:      	lsr	x16, x4, #0
    d2b8:      	cmp	x16, #0x1
    d2bc:      	b.eq	0xd2d8 <_stogir.vector-lanes.operands+0x180>
    d2c0:      	b.lo	0xd2c8 <_stogir.vector-lanes.operands+0x170>
    d2c4:      	b	0xd2dc <_stogir.vector-lanes.operands+0x184>
    d2c8:      	cmp	x16, #0x0
    d2cc:      	b.eq	0xd2d4 <_stogir.vector-lanes.operands+0x17c>
    d2d0:      	b	0xd2dc <_stogir.vector-lanes.operands+0x184>
    d2d4:      	b	0xd2e0 <_stogir.vector-lanes.operands+0x188>
    d2d8:      	b	0xd344 <_stogir.vector-lanes.operands+0x1ec>
    d2dc:      	b	0xd898 <_stogir.vector-lanes.operands+0x740>
    d2e0:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d2e0:  ARM64_RELOC_PAGE21	l_stogir.480
    d2e4:      	ldr	x16, [x16]
		000000000000d2e4:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    d2e8:      	orr	x0, x16, xzr
    d2ec:      	str	x8, [sp, #0xa0]
    d2f0:      	mov	x1, x0
    d2f4:      	mov	x0, #0x1                ; =1
    d2f8:      	mov	x2, #0x1b               ; =27
    d2fc:      	ldr	x3, [sp, #0xa0]
    d300:      	str	x0, [x3]
    d304:      	str	x1, [x3, #0x8]
    d308:      	str	x2, [x3, #0x10]
    d30c:      	ldr	x19, [sp, #0xc0]
    d310:      	ldr	x20, [sp, #0xc8]
    d314:      	ldr	x21, [sp, #0xd0]
    d318:      	ldr	x22, [sp, #0xd8]
    d31c:      	ldr	x23, [sp, #0xe0]
    d320:      	ldr	x24, [sp, #0xe8]
    d324:      	ldr	x25, [sp, #0xf0]
    d328:      	ldr	x26, [sp, #0xf8]
    d32c:      	ldr	x27, [sp, #0x100]
    d330:      	ldr	x28, [sp, #0x108]
    d334:      	ldr	x29, [sp]
    d338:      	ldr	x30, [sp, #0x8]
    d33c:      	add	sp, sp, #0x110
    d340:      	ret
    d344:      	sxtw	x19, w1
    d348:      	sxtw	x1, w2
    d34c:      	lsr	w4, w7, #0
    d350:      	ubfx	x4, x4, #8, #8
    d354:      	orr	x20, x4, xzr
    d358:      	cmp	x19, #0x3d
    d35c:      	b.ne	0xd370 <_stogir.vector-lanes.operands+0x218>
    d360:      	mov	x21, x20
    d364:      	b	0xd374 <_stogir.vector-lanes.operands+0x21c>
    d368:      	movz	x9, #0x0, lsl #48
    d36c:      	b	0xd25c <_stogir.vector-lanes.operands+0x104>
    d370:      	mov	x21, x1
    d374:      	cmp	x19, #0x3d
    d378:      	b.eq	0xd380 <_stogir.vector-lanes.operands+0x228>
    d37c:      	mov	x1, x20
    d380:      	lsr	w22, w21, #0
    d384:      	sxtw	x23, w22
    d388:      	cmp	x23, #0xf
    d38c:      	cset	w24, gt
    d390:      	cmp	x23, #0x80
    d394:      	cset	w25, lt
    d398:      	and	x4, x23, #0xf
    d39c:      	lsr	w4, w4, #0
    d3a0:      	sxtw	x4, w4
    d3a4:      	cmp	x4, #0x1
    d3a8:      	cset	w26, ge
    d3ac:      	cmp	x4, #0xd
    d3b0:      	cset	w27, le
    d3b4:      	cmp	x19, #0x3d
    d3b8:      	b.lt	0xd408 <_stogir.vector-lanes.operands+0x2b0>
    d3bc:      	cmp	x19, #0x3f
    d3c0:      	b.gt	0xd408 <_stogir.vector-lanes.operands+0x2b0>
    d3c4:      	uxtb	w16, w24
    d3c8:      	cmp	w16, wzr
    d3cc:      	b.eq	0xd408 <_stogir.vector-lanes.operands+0x2b0>
    d3d0:      	uxtb	w16, w25
    d3d4:      	cmp	w16, wzr
    d3d8:      	b.eq	0xd408 <_stogir.vector-lanes.operands+0x2b0>
    d3dc:      	uxtb	w16, w26
    d3e0:      	cmp	w16, wzr
    d3e4:      	b.eq	0xd408 <_stogir.vector-lanes.operands+0x2b0>
    d3e8:      	uxtb	w16, w27
    d3ec:      	cmp	w16, wzr
    d3f0:      	b.eq	0xd408 <_stogir.vector-lanes.operands+0x2b0>
    d3f4:      	sxtw	x4, w3
    d3f8:      	cmp	x4, #0x4
    d3fc:      	b.eq	0xd8c8 <_stogir.vector-lanes.operands+0x770>
    d400:      	cmp	x4, #0x8
    d404:      	b.eq	0xd8c8 <_stogir.vector-lanes.operands+0x770>
    d408:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d408:  ARM64_RELOC_PAGE21	l_stogir.481
    d40c:      	ldr	x16, [x16]
		000000000000d40c:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    d410:      	orr	x4, x16, xzr
    d414:      	mov	x28, x4
    d418:      	mov	x4, #0x36               ; =54
    d41c:      	sxtw	x7, w5
    d420:      	sxtw	x9, w6
    d424:      	cmp	x9, #0x0
    d428:      	cset	w9, eq
    d42c:      	cmp	x19, #0x3f
    d430:      	b.ne	0xd904 <_stogir.vector-lanes.operands+0x7ac>
    d434:      	lsr	w1, w1, #0
    d438:      	lsr	w3, w3, #0
    d43c:      	mov	w0, w22
    d440:      	mov	w2, w3
    d444:      	mov	x19, x8
    d448:      	mov	x20, x4
    d44c:      	mov	x22, x7
    d450:      	mov	w23, w9
    d454:      	bl	0xd454 <_stogir.vector-lanes.operands+0x2fc>
		000000000000d454:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d458:      	cmp	x0, #0x0
    d45c:      	b.eq	0xd540 <_stogir.vector-lanes.operands+0x3e8>
    d460:      	mov	x1, x28
    d464:      	movz	x0, #0x0, lsl #48
    d468:      	b	0xd548 <_stogir.vector-lanes.operands+0x3f0>
    d46c:      	cmp	x19, #0x3d
    d470:      	b.ne	0xd910 <_stogir.vector-lanes.operands+0x7b8>
    d474:      	lsr	w2, w2, #0
    d478:      	lsr	w3, w3, #0
    d47c:      	str	x0, [sp, #0x80]
    d480:      	mov	w0, w22
    d484:      	str	w3, [sp, #0xb0]
    d488:      	str	x1, [sp, #0xa0]
    d48c:      	mov	w1, w2
    d490:      	mov	w2, w3
    d494:      	str	x4, [sp, #0xa8]
    d498:      	str	w8, [sp, #0xb8]
    d49c:      	str	w22, [sp, #0x88]
    d4a0:      	mov	x22, x7
    d4a4:      	str	x28, [sp, #0x90]
    d4a8:      	mov	w28, w5
    d4ac:      	str	x21, [sp, #0x98]
    d4b0:      	mov	w21, w6
    d4b4:      	bl	0xd4b4 <_stogir.vector-lanes.operands+0x35c>
		000000000000d4b4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d4b8:      	cmp	x0, #0x0
    d4bc:      	b.ne	0xd570 <_stogir.vector-lanes.operands+0x418>
    d4c0:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d4c0:  ARM64_RELOC_PAGE21	l_stogir.482
    d4c4:      	ldr	x16, [x16]
		000000000000d4c4:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    d4c8:      	orr	x0, x16, xzr
    d4cc:      	mov	x1, #0x26               ; =38
    d4d0:      	b	0xd578 <_stogir.vector-lanes.operands+0x420>
    d4d4:      	mov	x0, x1
    d4d8:      	mov	x1, x20
    d4dc:      	str	x21, [sp, #0x98]
    d4e0:      	str	x19, [sp, #0xa0]
    d4e4:      	cmp	x1, #0x0
    d4e8:      	b.ne	0xd248 <_stogir.vector-lanes.operands+0xf0>
    d4ec:      	ldr	x0, [sp, #0x98]
    d4f0:      	and	x0, x0, #0xffffffff
    d4f4:      	mov	x1, x0
    d4f8:      	movz	x0, #0x0, lsl #48
    d4fc:      	movz	x2, #0x0, lsl #48
    d500:      	b	0xd254 <_stogir.vector-lanes.operands+0xfc>
    d504:      	movz	x9, #0x0, lsl #48
    d508:      	b	0xd244 <_stogir.vector-lanes.operands+0xec>
    d50c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d50c:  ARM64_RELOC_PAGE21	l_stogir.483
    d510:      	ldr	x16, [x16]
		000000000000d510:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    d514:      	orr	x0, x16, xzr
    d518:      	mov	x1, #0x20               ; =32
    d51c:      	b	0xd4e4 <_stogir.vector-lanes.operands+0x38c>
    d520:      	mov	x0, #0x1                ; =1
    d524:      	cmp	x0, #0x0
    d528:      	b.eq	0xd4d4 <_stogir.vector-lanes.operands+0x37c>
    d52c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d52c:  ARM64_RELOC_PAGE21	l_stogir.484
    d530:      	ldr	x16, [x16]
		000000000000d530:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    d534:      	orr	x0, x16, xzr
    d538:      	mov	x1, #0x24               ; =36
    d53c:      	b	0xd4dc <_stogir.vector-lanes.operands+0x384>
    d540:      	mov	x1, x28
    d544:      	mov	x0, #0x1                ; =1
    d548:      	cmp	x0, #0x0
    d54c:      	b.eq	0xd558 <_stogir.vector-lanes.operands+0x400>
    d550:      	mov	x0, #0x1                ; =1
    d554:      	b	0xd524 <_stogir.vector-lanes.operands+0x3cc>
    d558:      	cmp	x22, #0x0
    d55c:      	b.ne	0xd520 <_stogir.vector-lanes.operands+0x3c8>
    d560:      	uxtb	w16, w23
    d564:      	cmp	w16, wzr
    d568:      	cset	x0, eq
    d56c:      	b	0xd524 <_stogir.vector-lanes.operands+0x3cc>
    d570:      	ldr	x0, [sp, #0x90]
    d574:      	ldr	x1, [sp, #0xa8]
    d578:      	cmp	x19, #0x3e
    d57c:      	b.ne	0xd5a4 <_stogir.vector-lanes.operands+0x44c>
    d580:      	cmp	x20, x23
    d584:      	cset	w2, eq
    d588:      	uxtb	w16, w2
    d58c:      	cmp	w16, wzr
    d590:      	cset	x2, eq
    d594:      	fmov	d31, x0
    d598:      	mov	x0, x2
    d59c:      	fmov	x2, d31
    d5a0:      	b	0xd5ac <_stogir.vector-lanes.operands+0x454>
    d5a4:      	mov	x2, x0
    d5a8:      	movz	x0, #0x0, lsl #48
    d5ac:      	cmp	x0, #0x0
    d5b0:      	b.eq	0xd5cc <_stogir.vector-lanes.operands+0x474>
    d5b4:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d5b4:  ARM64_RELOC_PAGE21	l_stogir.485
    d5b8:      	ldr	x16, [x16]
		000000000000d5b8:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    d5bc:      	orr	x0, x16, xzr
    d5c0:      	mov	x20, x0
    d5c4:      	mov	x0, #0x27               ; =39
    d5c8:      	b	0xd5d4 <_stogir.vector-lanes.operands+0x47c>
    d5cc:      	mov	x20, x2
    d5d0:      	mov	x0, x1
    d5d4:      	lsr	w28, w28, #0
    d5d8:      	add	x8, sp, #0x10
    d5dc:      	mov	w1, w28
    d5e0:      	mov	x28, x0
    d5e4:      	ldr	x0, [sp, #0x80]
    d5e8:      	bl	0xd5e8 <_stogir.vector-lanes.operands+0x490>
		000000000000d5e8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d5ec:      	add	x16, sp, #0x10
    d5f0:      	ldr	w0, [x16]
    d5f4:      	lsr	x16, x0, #0
    d5f8:      	cmp	x16, #0x1
    d5fc:      	b.eq	0xd618 <_stogir.vector-lanes.operands+0x4c0>
    d600:      	b.lo	0xd608 <_stogir.vector-lanes.operands+0x4b0>
    d604:      	b	0xd61c <_stogir.vector-lanes.operands+0x4c4>
    d608:      	cmp	x16, #0x0
    d60c:      	b.eq	0xd614 <_stogir.vector-lanes.operands+0x4bc>
    d610:      	b	0xd61c <_stogir.vector-lanes.operands+0x4c4>
    d614:      	b	0xd620 <_stogir.vector-lanes.operands+0x4c8>
    d618:      	b	0xd698 <_stogir.vector-lanes.operands+0x540>
    d61c:      	b	0xd8f4 <_stogir.vector-lanes.operands+0x79c>
    d620:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d620:  ARM64_RELOC_PAGE21	l_stogir.486
    d624:      	ldr	x16, [x16]
		000000000000d624:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    d628:      	orr	x0, x16, xzr
    d62c:      	mov	x20, x0
    d630:      	mov	x22, #0x19              ; =25
    d634:      	cmp	x19, #0x3e
    d638:      	b.ne	0xd700 <_stogir.vector-lanes.operands+0x5a8>
    d63c:      	lsr	w21, w21, #0
    d640:      	add	x8, sp, #0x50
    d644:      	ldr	x0, [sp, #0x80]
    d648:      	mov	w1, w21
    d64c:      	bl	0xd64c <_stogir.vector-lanes.operands+0x4f4>
		000000000000d64c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d650:      	add	x16, sp, #0x50
    d654:      	ldr	w0, [x16]
    d658:      	lsr	x16, x0, #0
    d65c:      	cmp	x16, #0x1
    d660:      	b.eq	0xd67c <_stogir.vector-lanes.operands+0x524>
    d664:      	b.lo	0xd66c <_stogir.vector-lanes.operands+0x514>
    d668:      	b	0xd680 <_stogir.vector-lanes.operands+0x528>
    d66c:      	cmp	x16, #0x0
    d670:      	b.eq	0xd678 <_stogir.vector-lanes.operands+0x520>
    d674:      	b	0xd680 <_stogir.vector-lanes.operands+0x528>
    d678:      	b	0xd684 <_stogir.vector-lanes.operands+0x52c>
    d67c:      	b	0xd7c8 <_stogir.vector-lanes.operands+0x670>
    d680:      	b	0xd8fc <_stogir.vector-lanes.operands+0x7a4>
    d684:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d684:  ARM64_RELOC_PAGE21	l_stogir.487
    d688:      	ldr	x16, [x16]
		000000000000d688:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    d68c:      	orr	x0, x16, xzr
    d690:      	mov	x1, #0x20               ; =32
    d694:      	b	0xd51c <_stogir.vector-lanes.operands+0x3c4>
    d698:      	add	x16, sp, #0x10
    d69c:      	orr	x0, x16, xzr
    d6a0:      	add	x0, x0, #0x8
    d6a4:      	add	x16, sp, #0x10
    d6a8:      	ldr	x1, [x16, #0x8]
    d6ac:      	add	x16, sp, #0x40
    d6b0:      	str	x1, [x16]
    d6b4:      	lsr	w1, w1, #0
    d6b8:      	ldr	x0, [x0, #0x8]
    d6bc:      	add	x16, sp, #0x40
    d6c0:      	str	x0, [x16, #0x8]
    d6c4:      	ubfx	x0, x1, #8, #8
    d6c8:      	cmp	x0, #0x1
    d6cc:      	b.lt	0xd72c <_stogir.vector-lanes.operands+0x5d4>
    d6d0:      	cmp	x0, #0xb
    d6d4:      	b.gt	0xd72c <_stogir.vector-lanes.operands+0x5d4>
    d6d8:      	add	x16, sp, #0x40
    d6dc:      	ldr	w0, [x16]
    d6e0:      	uxtb	w0, w0
    d6e4:      	cmp	x0, #0x48
    d6e8:      	b.eq	0xd72c <_stogir.vector-lanes.operands+0x5d4>
    d6ec:      	cmp	x0, #0x46
    d6f0:      	b.eq	0xd72c <_stogir.vector-lanes.operands+0x5d4>
    d6f4:      	mov	x0, x20
    d6f8:      	mov	x1, x28
    d6fc:      	b	0xd73c <_stogir.vector-lanes.operands+0x5e4>
    d700:      	ldr	w0, [sp, #0xb8]
    d704:      	uxtb	w16, w0
    d708:      	cmp	w16, wzr
    d70c:      	b.eq	0xd50c <_stogir.vector-lanes.operands+0x3b4>
    d710:      	mov	x0, x20
    d714:      	mov	x1, x22
    d718:      	b	0xd51c <_stogir.vector-lanes.operands+0x3c4>
    d71c:      	mov	x0, x2
    d720:      	mov	x20, x0
    d724:      	mov	x22, x1
    d728:      	b	0xd634 <_stogir.vector-lanes.operands+0x4dc>
    d72c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d72c:  ARM64_RELOC_PAGE21	l_stogir.488
    d730:      	ldr	x16, [x16]
		000000000000d730:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    d734:      	orr	x0, x16, xzr
    d738:      	mov	x1, #0x2b               ; =43
    d73c:      	cmp	x22, #0x0
    d740:      	b.ge	0xd76c <_stogir.vector-lanes.operands+0x614>
    d744:      	add	x16, sp, #0x40
    d748:      	ldr	w2, [x16]
    d74c:      	uxtb	w3, w2
    d750:      	ubfx	x2, x2, #8, #8
    d754:      	cmp	x3, x2
    d758:      	b.eq	0xd830 <_stogir.vector-lanes.operands+0x6d8>
    d75c:      	cmp	x3, #0x49
    d760:      	b.eq	0xd830 <_stogir.vector-lanes.operands+0x6d8>
    d764:      	movz	x2, #0x0, lsl #48
    d768:      	b	0xd7b8 <_stogir.vector-lanes.operands+0x660>
    d76c:      	mov	x2, x0
    d770:      	movz	x0, #0x0, lsl #48
    d774:      	cmp	x0, #0x0
    d778:      	b.eq	0xd71c <_stogir.vector-lanes.operands+0x5c4>
    d77c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d77c:  ARM64_RELOC_PAGE21	l_stogir.489
    d780:      	ldr	x16, [x16]
		000000000000d780:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    d784:      	orr	x0, x16, xzr
    d788:      	mov	x1, #0x28               ; =40
    d78c:      	b	0xd720 <_stogir.vector-lanes.operands+0x5c8>
    d790:      	movn	x4, #0x0, lsl #48
    d794:      	ubfx	x2, x2, #0, #32
    d798:      	ubfx	x3, x3, #0, #32
    d79c:      	lsl	x3, x3, #32
    d7a0:      	orr	x2, x3, x2
    d7a4:      	lsr	w4, w4, #0
    d7a8:      	sxtw	x4, w4
    d7ac:      	cmp	x2, x4
    d7b0:      	cset	w2, hs
    d7b4:      	ubfx	x2, x2, #0, #8
    d7b8:      	fmov	d31, x0
    d7bc:      	mov	x0, x2
    d7c0:      	fmov	x2, d31
    d7c4:      	b	0xd774 <_stogir.vector-lanes.operands+0x61c>
    d7c8:      	add	x16, sp, #0x50
    d7cc:      	ldr	x0, [x16, #0x8]
    d7d0:      	uxtb	w1, w0
    d7d4:      	cmp	x1, #0x48
    d7d8:      	b.eq	0xd81c <_stogir.vector-lanes.operands+0x6c4>
    d7dc:      	cmp	x1, #0x46
    d7e0:      	b.eq	0xd81c <_stogir.vector-lanes.operands+0x6c4>
    d7e4:      	ldr	w1, [sp, #0xb0]
    d7e8:      	lsr	w1, w1, #0
    d7ec:      	lsr	w0, w0, #0
    d7f0:      	ubfx	x0, x0, #8, #8
    d7f4:      	lsr	w0, w0, #0
    d7f8:      	mov	w2, w1
    d7fc:      	mov	w1, w0
    d800:      	ldr	w0, [sp, #0x88]
    d804:      	bl	0xd804 <_stogir.vector-lanes.operands+0x6ac>
		000000000000d804:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d808:      	cmp	x0, #0x0
    d80c:      	b.eq	0xd81c <_stogir.vector-lanes.operands+0x6c4>
    d810:      	mov	x0, x20
    d814:      	mov	x1, x22
    d818:      	b	0xd82c <_stogir.vector-lanes.operands+0x6d4>
    d81c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d81c:  ARM64_RELOC_PAGE21	l_stogir.490
    d820:      	ldr	x16, [x16]
		000000000000d820:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    d824:      	orr	x0, x16, xzr
    d828:      	mov	x1, #0x27               ; =39
    d82c:      	b	0xd694 <_stogir.vector-lanes.operands+0x53c>
    d830:      	add	x16, sp, #0x40
    d834:      	ldr	w2, [x16, #0x8]
    d838:      	add	x16, sp, #0x40
    d83c:      	ldr	w3, [x16, #0xc]
    d840:      	uxtb	w16, w24
    d844:      	cmp	w16, wzr
    d848:      	b.eq	0xd8a0 <_stogir.vector-lanes.operands+0x748>
    d84c:      	uxtb	w16, w25
    d850:      	cmp	w16, wzr
    d854:      	b.eq	0xd8a0 <_stogir.vector-lanes.operands+0x748>
    d858:      	uxtb	w16, w26
    d85c:      	cmp	w16, wzr
    d860:      	b.eq	0xd8a0 <_stogir.vector-lanes.operands+0x748>
    d864:      	uxtb	w16, w27
    d868:      	cmp	w16, wzr
    d86c:      	b.eq	0xd8a0 <_stogir.vector-lanes.operands+0x748>
    d870:      	ubfx	x4, x23, #4, #32
    d874:      	sxtw	x4, w4
    d878:      	sub	x4, x4, #0x1
    d87c:      	lsr	w4, w4, #0
    d880:      	sxtw	x4, w4
    d884:      	mov	x16, #0x1               ; =1
    d888:      	lsl	x4, x16, x4
    d88c:      	lsr	w4, w4, #0
    d890:      	sxtw	x4, w4
    d894:      	b	0xd794 <_stogir.vector-lanes.operands+0x63c>
    d898:      	brk	#0
    d89c:      	b	0xd898 <_stogir.vector-lanes.operands+0x740>
    d8a0:      	cmp	x23, #0x0
    d8a4:      	b.lt	0xd790 <_stogir.vector-lanes.operands+0x638>
    d8a8:      	cmp	x23, #0xd
    d8ac:      	b.gt	0xd790 <_stogir.vector-lanes.operands+0x638>
    d8b0:      	cmp	x23, #0x0
    d8b4:      	cset	w4, eq
    d8b8:      	uxtb	w16, w4
    d8bc:      	cmp	w16, wzr
    d8c0:      	cset	x4, eq
    d8c4:      	b	0xd794 <_stogir.vector-lanes.operands+0x63c>
    d8c8:      	uxtb	w7, w7
    d8cc:      	cmp	x7, #0x48
    d8d0:      	b.eq	0xd408 <_stogir.vector-lanes.operands+0x2b0>
    d8d4:      	cmp	x7, #0x46
    d8d8:      	b.eq	0xd408 <_stogir.vector-lanes.operands+0x2b0>
    d8dc:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d8dc:  ARM64_RELOC_PAGE21	l_stogir.491
    d8e0:      	ldr	x16, [x16]
		000000000000d8e0:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    d8e4:      	orr	x4, x16, xzr
    d8e8:      	mov	x28, x4
    d8ec:      	movz	x4, #0x0, lsl #48
    d8f0:      	b	0xd41c <_stogir.vector-lanes.operands+0x2c4>
    d8f4:      	brk	#0
    d8f8:      	b	0xd8f4 <_stogir.vector-lanes.operands+0x79c>
    d8fc:      	brk	#0
    d900:      	b	0xd8fc <_stogir.vector-lanes.operands+0x7a4>
    d904:      	mov	x1, x8
    d908:      	mov	w8, w9
    d90c:      	b	0xd46c <_stogir.vector-lanes.operands+0x314>
    d910:      	str	x21, [sp, #0x98]
    d914:      	str	x1, [sp, #0xa0]
    d918:      	str	x0, [sp, #0x80]
    d91c:      	str	w3, [sp, #0xb0]
    d920:      	mov	w21, w6
    d924:      	str	w22, [sp, #0x88]
    d928:      	mov	x22, x7
    d92c:      	str	w8, [sp, #0xb8]
    d930:      	str	x28, [sp, #0x90]
    d934:      	mov	w28, w5
    d938:      	str	x4, [sp, #0xa8]
    d93c:      	b	0xd570 <_stogir.vector-lanes.operands+0x418>

000000000000d940 <_stogir.vector-comparison.operation?>:
    d940:      	sxtw	x0, w0
    d944:      	cmp	x0, #0xe
    d948:      	b.lt	0xd95c <_stogir.vector-comparison.operation?+0x1c>
    d94c:      	cmp	x0, #0x19
    d950:      	cset	w0, le
    d954:      	ubfx	x0, x0, #0, #8
    d958:      	b	0xd960 <_stogir.vector-comparison.operation?+0x20>
    d95c:      	movz	x0, #0x0, lsl #48
    d960:      	ret

000000000000d964 <_stogir.vector-comparison.operands>:
    d964:      	sub	sp, sp, #0xe0
    d968:      	str	x29, [sp]
    d96c:      	str	x30, [sp, #0x8]
    d970:      	mov	x29, sp
    d974:      	str	x19, [sp, #0x90]
    d978:      	str	x20, [sp, #0x98]
    d97c:      	str	x21, [sp, #0xa0]
    d980:      	str	x22, [sp, #0xa8]
    d984:      	str	x23, [sp, #0xb0]
    d988:      	str	x24, [sp, #0xb8]
    d98c:      	str	x25, [sp, #0xc0]
    d990:      	str	x26, [sp, #0xc8]
    d994:      	str	x27, [sp, #0xd0]
    d998:      	str	x28, [sp, #0xd8]
    d99c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000d99c:  ARM64_RELOC_PAGE21	l_stogir.492
    d9a0:      	ldr	x16, [x16]
		000000000000d9a0:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    d9a4:      	orr	x19, x16, xzr
    d9a8:      	lsr	w4, w4, #0
    d9ac:      	mov	x20, x8
    d9b0:      	add	x8, sp, #0x10
    d9b4:      	mov	x21, x0
    d9b8:      	mov	w22, w1
    d9bc:      	mov	w1, w4
    d9c0:      	mov	w23, w2
    d9c4:      	mov	w24, w3
    d9c8:      	mov	w25, w5
    d9cc:      	bl	0xd9cc <_stogir.vector-comparison.operands+0x68>
		000000000000d9cc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d9d0:      	add	x16, sp, #0x10
    d9d4:      	ldr	w0, [x16]
    d9d8:      	lsr	x16, x0, #0
    d9dc:      	cmp	x16, #0x1
    d9e0:      	b.eq	0xd9fc <_stogir.vector-comparison.operands+0x98>
    d9e4:      	b.lo	0xd9ec <_stogir.vector-comparison.operands+0x88>
    d9e8:      	b	0xda00 <_stogir.vector-comparison.operands+0x9c>
    d9ec:      	cmp	x16, #0x0
    d9f0:      	b.eq	0xd9f8 <_stogir.vector-comparison.operands+0x94>
    d9f4:      	b	0xda00 <_stogir.vector-comparison.operands+0x9c>
    d9f8:      	b	0xda04 <_stogir.vector-comparison.operands+0xa0>
    d9fc:      	b	0xda54 <_stogir.vector-comparison.operands+0xf0>
    da00:      	b	0xdc04 <_stogir.vector-comparison.operands+0x2a0>
    da04:      	mov	x1, x19
    da08:      	mov	x0, #0x1                ; =1
    da0c:      	mov	x2, #0x21               ; =33
    da10:      	str	x0, [x20]
    da14:      	str	x1, [x20, #0x8]
    da18:      	str	x2, [x20, #0x10]
    da1c:      	ldr	x19, [sp, #0x90]
    da20:      	ldr	x20, [sp, #0x98]
    da24:      	ldr	x21, [sp, #0xa0]
    da28:      	ldr	x22, [sp, #0xa8]
    da2c:      	ldr	x23, [sp, #0xb0]
    da30:      	ldr	x24, [sp, #0xb8]
    da34:      	ldr	x25, [sp, #0xc0]
    da38:      	ldr	x26, [sp, #0xc8]
    da3c:      	ldr	x27, [sp, #0xd0]
    da40:      	ldr	x28, [sp, #0xd8]
    da44:      	ldr	x29, [sp]
    da48:      	ldr	x30, [sp, #0x8]
    da4c:      	add	sp, sp, #0xe0
    da50:      	ret
    da54:      	lsr	w25, w25, #0
    da58:      	add	x16, sp, #0x10
    da5c:      	ldr	x26, [x16, #0x8]
    da60:      	add	x8, sp, #0x40
    da64:      	mov	x0, x21
    da68:      	mov	w1, w25
    da6c:      	bl	0xda6c <_stogir.vector-comparison.operands+0x108>
		000000000000da6c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    da70:      	add	x16, sp, #0x40
    da74:      	ldr	w0, [x16]
    da78:      	lsr	x16, x0, #0
    da7c:      	cmp	x16, #0x1
    da80:      	b.eq	0xda9c <_stogir.vector-comparison.operands+0x138>
    da84:      	b.lo	0xda8c <_stogir.vector-comparison.operands+0x128>
    da88:      	b	0xdaa0 <_stogir.vector-comparison.operands+0x13c>
    da8c:      	cmp	x16, #0x0
    da90:      	b.eq	0xda98 <_stogir.vector-comparison.operands+0x134>
    da94:      	b	0xdaa0 <_stogir.vector-comparison.operands+0x13c>
    da98:      	b	0xdaa4 <_stogir.vector-comparison.operands+0x140>
    da9c:      	b	0xdab4 <_stogir.vector-comparison.operands+0x150>
    daa0:      	b	0xdc0c <_stogir.vector-comparison.operands+0x2a8>
    daa4:      	mov	x1, x19
    daa8:      	mov	x0, #0x1                ; =1
    daac:      	mov	x2, #0x21               ; =33
    dab0:      	b	0xda10 <_stogir.vector-comparison.operands+0xac>
    dab4:      	sxtw	x19, w24
    dab8:      	cmp	x19, #0x4
    dabc:      	cset	w21, eq
    dac0:      	cmp	x19, #0x8
    dac4:      	cset	w25, eq
    dac8:      	add	x16, sp, #0x40
    dacc:      	ldr	x27, [x16, #0x8]
    dad0:      	uxtb	w16, w21
    dad4:      	cmp	w16, wzr
    dad8:      	b.ne	0xdb04 <_stogir.vector-comparison.operands+0x1a0>
    dadc:      	uxtb	w16, w25
    dae0:      	cmp	w16, wzr
    dae4:      	b.ne	0xdb04 <_stogir.vector-comparison.operands+0x1a0>
    dae8:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x454>
		000000000000dae8:  ARM64_RELOC_PAGE21	l_stogir.493
    daec:      	ldr	x16, [x16]
		000000000000daec:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    daf0:      	orr	x0, x16, xzr
    daf4:      	mov	x1, x0
    daf8:      	mov	x0, #0x1                ; =1
    dafc:      	mov	x2, #0x33               ; =51
    db00:      	b	0xdab0 <_stogir.vector-comparison.operands+0x14c>
    db04:      	lsr	w22, w22, #0
    db08:      	lsr	w0, w26, #0
    db0c:      	ubfx	x28, x0, #8, #8
    db10:      	orr	x0, x28, xzr
    db14:      	lsr	w0, w0, #0
    db18:      	mov	w1, w0
    db1c:      	fmov	s31, w0
    db20:      	mov	w0, w22
    db24:      	fmov	w22, s31
    db28:      	bl	0xdb28 <_stogir.vector-comparison.operands+0x1c4>
		000000000000db28:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    db2c:      	cmp	x0, #0x0
    db30:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    db34:      	lsr	w0, w27, #0
    db38:      	ubfx	x0, x0, #8, #8
    db3c:      	cmp	x28, x0
    db40:      	b.ne	0xdae8 <_stogir.vector-comparison.operands+0x184>
    db44:      	uxtb	w26, w26
    db48:      	cmp	x26, #0x48
    db4c:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    db50:      	cmp	x26, #0x46
    db54:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    db58:      	uxtb	w27, w27
    db5c:      	cmp	x27, #0x48
    db60:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    db64:      	cmp	x27, #0x46
    db68:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    db6c:      	sxtw	x26, w23
    db70:      	cmp	x26, #0xf
    db74:      	cset	w27, gt
    db78:      	uxtb	w16, w27
    db7c:      	cmp	w16, wzr
    db80:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    db84:      	cmp	x26, #0x80
    db88:      	cset	w0, lt
    db8c:      	uxtb	w16, w0
    db90:      	cmp	w16, wzr
    db94:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    db98:      	and	x1, x26, #0xf
    db9c:      	lsr	w1, w1, #0
    dba0:      	sxtw	x1, w1
    dba4:      	cmp	x1, #0x1
    dba8:      	cset	w2, ge
    dbac:      	uxtb	w16, w2
    dbb0:      	cmp	w16, wzr
    dbb4:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    dbb8:      	cmp	x1, #0xd
    dbbc:      	cset	w3, le
    dbc0:      	uxtb	w16, w3
    dbc4:      	cmp	w16, wzr
    dbc8:      	b.eq	0xdae8 <_stogir.vector-comparison.operands+0x184>
    dbcc:      	lsr	w23, w23, #0
    dbd0:      	str	x1, [sp, #0x78]
    dbd4:      	str	x19, [sp, #0x70]
    dbd8:      	mov	w19, w0
    dbdc:      	mov	w0, w23
    dbe0:      	str	w22, [sp, #0x80]
    dbe4:      	mov	w22, w2
    dbe8:      	str	w23, [sp, #0x88]
    dbec:      	mov	w23, w3
    dbf0:      	bl	0xdbf0 <_stogir.vector-comparison.operands+0x28c>
		000000000000dbf0:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    dbf4:      	cmp	x0, #0x0
    dbf8:      	b.eq	0xdc14 <_stogir.vector-comparison.operands+0x2b0>
    dbfc:      	ldr	x0, [sp, #0x78]
    dc00:      	b	0xdc18 <_stogir.vector-comparison.operands+0x2b4>
    dc04:      	brk	#0
    dc08:      	b	0xdc04 <_stogir.vector-comparison.operands+0x2a0>
    dc0c:      	brk	#0
    dc10:      	b	0xdc0c <_stogir.vector-comparison.operands+0x2a8>
    dc14:      	movn	x0, #0x0, lsl #48
    dc18:      	lsr	w0, w0, #0
    dc1c:      	sxtw	x0, w0
    dc20:      	cmp	x0, #0x1
    dc24:      	b.lt	0xdae8 <_stogir.vector-comparison.operands+0x184>
    dc28:      	cmp	x0, #0xb
    dc2c:      	b.gt	0xdae8 <_stogir.vector-comparison.operands+0x184>
    dc30:      	uxtb	w16, w27
    dc34:      	cmp	w16, wzr
    dc38:      	b.eq	0xdcbc <_stogir.vector-comparison.operands+0x358>
    dc3c:      	uxtb	w16, w19
    dc40:      	cmp	w16, wzr
    dc44:      	b.eq	0xdcbc <_stogir.vector-comparison.operands+0x358>
    dc48:      	uxtb	w16, w22
    dc4c:      	cmp	w16, wzr
    dc50:      	b.eq	0xdcbc <_stogir.vector-comparison.operands+0x358>
    dc54:      	uxtb	w16, w23
    dc58:      	cmp	w16, wzr
    dc5c:      	b.eq	0xdcbc <_stogir.vector-comparison.operands+0x358>
    dc60:      	ubfx	x0, x26, #4, #32
    dc64:      	sxtw	x0, w0
    dc68:      	sub	x0, x0, #0x1
    dc6c:      	lsr	w0, w0, #0
    dc70:      	sxtw	x0, w0
    dc74:      	mov	x16, #0x1               ; =1
    dc78:      	lsl	x0, x16, x0
    dc7c:      	lsr	w0, w0, #0
    dc80:      	sxtw	x0, w0
    dc84:      	b	0xdce8 <_stogir.vector-comparison.operands+0x384>
    dc88:      	movn	x1, #0x0, lsl #48
    dc8c:      	lsr	w0, w0, #0
    dc90:      	sxtw	x0, w0
    dc94:      	lsr	w1, w1, #0
    dc98:      	sxtw	x1, w1
    dc9c:      	cmp	x0, x1
    dca0:      	b.ne	0xdae8 <_stogir.vector-comparison.operands+0x184>
    dca4:      	ldr	w0, [sp, #0x88]
    dca8:      	bl	0xdca8 <_stogir.vector-comparison.operands+0x344>
		000000000000dca8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    dcac:      	cmp	x0, #0x0
    dcb0:      	b.eq	0xdda0 <_stogir.vector-comparison.operands+0x43c>
    dcb4:      	ldr	x0, [sp, #0x78]
    dcb8:      	b	0xdda4 <_stogir.vector-comparison.operands+0x440>
    dcbc:      	cmp	x26, #0x0
    dcc0:      	b.lt	0xdce4 <_stogir.vector-comparison.operands+0x380>
    dcc4:      	cmp	x26, #0xd
    dcc8:      	b.gt	0xdce4 <_stogir.vector-comparison.operands+0x380>
    dccc:      	cmp	x26, #0x0
    dcd0:      	cset	w0, eq
    dcd4:      	uxtb	w16, w0
    dcd8:      	cmp	w16, wzr
    dcdc:      	cset	x0, eq
    dce0:      	b	0xdce8 <_stogir.vector-comparison.operands+0x384>
    dce4:      	movn	x0, #0x0, lsl #48
    dce8:      	and	x1, x28, #0xf
    dcec:      	lsr	w1, w1, #0
    dcf0:      	sxtw	x19, w1
    dcf4:      	cmp	x28, #0xf
    dcf8:      	b.le	0xdd3c <_stogir.vector-comparison.operands+0x3d8>
    dcfc:      	cmp	x28, #0x80
    dd00:      	b.ge	0xdd3c <_stogir.vector-comparison.operands+0x3d8>
    dd04:      	cmp	x19, #0x1
    dd08:      	b.lt	0xdd3c <_stogir.vector-comparison.operands+0x3d8>
    dd0c:      	cmp	x19, #0xd
    dd10:      	b.gt	0xdd3c <_stogir.vector-comparison.operands+0x3d8>
    dd14:      	ubfx	x1, x28, #4, #32
    dd18:      	sxtw	x1, w1
    dd1c:      	sub	x1, x1, #0x1
    dd20:      	lsr	w1, w1, #0
    dd24:      	sxtw	x1, w1
    dd28:      	mov	x16, #0x1               ; =1
    dd2c:      	lsl	x1, x16, x1
    dd30:      	lsr	w1, w1, #0
    dd34:      	sxtw	x1, w1
    dd38:      	b	0xdc8c <_stogir.vector-comparison.operands+0x328>
    dd3c:      	cmp	x28, #0xd
    dd40:      	b.gt	0xdc88 <_stogir.vector-comparison.operands+0x324>
    dd44:      	cmp	x28, #0x0
    dd48:      	cset	w1, eq
    dd4c:      	uxtb	w16, w1
    dd50:      	cmp	w16, wzr
    dd54:      	cset	x1, eq
    dd58:      	b	0xdc8c <_stogir.vector-comparison.operands+0x328>
    dd5c:      	movn	x0, #0x0, lsl #48
    dd60:      	lsr	w24, w24, #0
    dd64:      	lsr	w21, w21, #0
    dd68:      	sxtw	x21, w21
    dd6c:      	lsr	w0, w0, #0
    dd70:      	lsr	w0, w0, #0
    dd74:      	mov	w1, w24
    dd78:      	bl	0xdd78 <_stogir.vector-comparison.operands+0x414>
		000000000000dd78:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    dd7c:      	lsr	w0, w0, #0
    dd80:      	sxtw	x0, w0
    dd84:      	cmp	x21, x0
    dd88:      	b.ne	0xdae8 <_stogir.vector-comparison.operands+0x184>
    dd8c:      	and	x0, x28, #0xffffffff
    dd90:      	mov	x1, x0
    dd94:      	movz	x0, #0x0, lsl #48
    dd98:      	movz	x2, #0x0, lsl #48
    dd9c:      	b	0xdb00 <_stogir.vector-comparison.operands+0x19c>
    dda0:      	movn	x0, #0x0, lsl #48
    dda4:      	uxtb	w16, w21
    dda8:      	cmp	w16, wzr
    ddac:      	b.ne	0xdde4 <_stogir.vector-comparison.operands+0x480>
    ddb0:      	uxtb	w16, w25
    ddb4:      	cmp	w16, wzr
    ddb8:      	b.ne	0xdde4 <_stogir.vector-comparison.operands+0x480>
    ddbc:      	movn	x21, #0x0, lsl #48
    ddc0:      	b	0xddcc <_stogir.vector-comparison.operands+0x468>
    ddc4:      	mov	x0, #0x1                ; =1
    ddc8:      	mov	x21, x0
    ddcc:      	ldr	w0, [sp, #0x80]
    ddd0:      	bl	0xddd0 <_stogir.vector-comparison.operands+0x46c>
		000000000000ddd0:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    ddd4:      	cmp	x0, #0x0
    ddd8:      	b.eq	0xdd5c <_stogir.vector-comparison.operands+0x3f8>
    dddc:      	mov	x0, x19
    dde0:      	b	0xdd60 <_stogir.vector-comparison.operands+0x3fc>
    dde4:      	lsr	w0, w0, #0
    dde8:      	sxtw	x0, w0
    ddec:      	cmp	x0, #0x0
    ddf0:      	b.ne	0xddfc <_stogir.vector-comparison.operands+0x498>
    ddf4:      	movz	x0, #0x0, lsl #48
    ddf8:      	b	0xddc8 <_stogir.vector-comparison.operands+0x464>
    ddfc:      	cmp	x0, #0x1
    de00:      	b.eq	0xddc4 <_stogir.vector-comparison.operands+0x460>
    de04:      	cmp	x0, #0x2
    de08:      	b.eq	0xddc4 <_stogir.vector-comparison.operands+0x460>
    de0c:      	cmp	x0, #0x7
    de10:      	b.eq	0xddc4 <_stogir.vector-comparison.operands+0x460>
    de14:      	cmp	x0, #0x8
    de18:      	b.eq	0xddc4 <_stogir.vector-comparison.operands+0x460>
    de1c:      	cmp	x0, #0x3
    de20:      	b.eq	0xde6c <_stogir.vector-comparison.operands+0x508>
    de24:      	cmp	x0, #0x9
    de28:      	b.eq	0xde6c <_stogir.vector-comparison.operands+0x508>
    de2c:      	cmp	x0, #0x4
    de30:      	b.eq	0xde74 <_stogir.vector-comparison.operands+0x510>
    de34:      	cmp	x0, #0xa
    de38:      	b.eq	0xde74 <_stogir.vector-comparison.operands+0x510>
    de3c:      	cmp	x0, #0xd
    de40:      	b.eq	0xde74 <_stogir.vector-comparison.operands+0x510>
    de44:      	cmp	x0, #0x5
    de48:      	b.eq	0xde7c <_stogir.vector-comparison.operands+0x518>
    de4c:      	cmp	x0, #0xb
    de50:      	b.eq	0xde7c <_stogir.vector-comparison.operands+0x518>
    de54:      	cmp	x0, #0xc
    de58:      	b.eq	0xde7c <_stogir.vector-comparison.operands+0x518>
    de5c:      	cmp	x0, #0x6
    de60:      	b.ne	0xde84 <_stogir.vector-comparison.operands+0x520>
    de64:      	ldr	x0, [sp, #0x70]
    de68:      	b	0xde88 <_stogir.vector-comparison.operands+0x524>
    de6c:      	mov	x0, #0x2                ; =2
    de70:      	b	0xddc8 <_stogir.vector-comparison.operands+0x464>
    de74:      	mov	x0, #0x4                ; =4
    de78:      	b	0xde70 <_stogir.vector-comparison.operands+0x50c>
    de7c:      	mov	x0, #0x8                ; =8
    de80:      	b	0xde78 <_stogir.vector-comparison.operands+0x514>
    de84:      	movn	x0, #0x0, lsl #48
    de88:      	b	0xde80 <_stogir.vector-comparison.operands+0x51c>

000000000000de8c <_stogir.vector-arithmetic.operation?>:
    de8c:      	sxtw	x0, w0
    de90:      	cmp	x0, #0x1f
    de94:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x64>
    de98:      	cmp	x0, #0x20
    de9c:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x64>
    dea0:      	cmp	x0, #0x2d
    dea4:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x64>
    dea8:      	cmp	x0, #0x36
    deac:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x64>
    deb0:      	cmp	x0, #0x37
    deb4:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x64>
    deb8:      	cmp	x0, #0x38
    debc:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x64>
    dec0:      	cmp	x0, #0x39
    dec4:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x64>
    dec8:      	cmp	x0, #0x3a
    decc:      	b.eq	0xdef8 <_stogir.vector-arithmetic.operation?+0x6c>
    ded0:      	cmp	x0, #0x3b
    ded4:      	b.eq	0xdef8 <_stogir.vector-arithmetic.operation?+0x6c>
    ded8:      	cmp	x0, #0x31
    dedc:      	b.lt	0xdf10 <_stogir.vector-arithmetic.operation?+0x84>
    dee0:      	cmp	x0, #0x35
    dee4:      	b.gt	0xdf10 <_stogir.vector-arithmetic.operation?+0x84>
    dee8:      	mov	x0, #0x1                ; =1
    deec:      	b	0xdf0c <_stogir.vector-arithmetic.operation?+0x80>
    def0:      	mov	x0, #0x1                ; =1
    def4:      	ret
    def8:      	mov	x0, #0x1                ; =1
    defc:      	b	0xdef4 <_stogir.vector-arithmetic.operation?+0x68>
    df00:      	cmp	x0, #0x30
    df04:      	cset	w0, eq
    df08:      	ubfx	x0, x0, #0, #8
    df0c:      	b	0xdefc <_stogir.vector-arithmetic.operation?+0x70>
    df10:      	cmp	x0, #0x1a
    df14:      	b.ne	0xdf20 <_stogir.vector-arithmetic.operation?+0x94>
    df18:      	mov	x0, #0x1                ; =1
    df1c:      	b	0xdf0c <_stogir.vector-arithmetic.operation?+0x80>
    df20:      	cmp	x0, #0x1b
    df24:      	b.ne	0xdf30 <_stogir.vector-arithmetic.operation?+0xa4>
    df28:      	mov	x0, #0x1                ; =1
    df2c:      	b	0xdf0c <_stogir.vector-arithmetic.operation?+0x80>
    df30:      	cmp	x0, #0x1c
    df34:      	b.ne	0xdf40 <_stogir.vector-arithmetic.operation?+0xb4>
    df38:      	mov	x0, #0x1                ; =1
    df3c:      	b	0xdf0c <_stogir.vector-arithmetic.operation?+0x80>
    df40:      	cmp	x0, #0x1d
    df44:      	b.ne	0xdf50 <_stogir.vector-arithmetic.operation?+0xc4>
    df48:      	mov	x0, #0x1                ; =1
    df4c:      	b	0xdf0c <_stogir.vector-arithmetic.operation?+0x80>
    df50:      	cmp	x0, #0x1e
    df54:      	b.ne	0xdf60 <_stogir.vector-arithmetic.operation?+0xd4>
    df58:      	mov	x0, #0x1                ; =1
    df5c:      	b	0xdf0c <_stogir.vector-arithmetic.operation?+0x80>
    df60:      	cmp	x0, #0x2e
    df64:      	b.ne	0xdf70 <_stogir.vector-arithmetic.operation?+0xe4>
    df68:      	mov	x0, #0x1                ; =1
    df6c:      	b	0xdf0c <_stogir.vector-arithmetic.operation?+0x80>
    df70:      	cmp	x0, #0x2f
    df74:      	b.ne	0xdf00 <_stogir.vector-arithmetic.operation?+0x74>
    df78:      	mov	x0, #0x1                ; =1
    df7c:      	b	0xdf0c <_stogir.vector-arithmetic.operation?+0x80>

000000000000df80 <_stogir.vector-arithmetic.unary?>:
    df80:      	sxtw	x0, w0
    df84:      	cmp	x0, #0x1f
    df88:      	b.ne	0xdfa4 <_stogir.vector-arithmetic.unary?+0x24>
    df8c:      	mov	x0, #0x1                ; =1
    df90:      	b	0xdfa0 <_stogir.vector-arithmetic.unary?+0x20>
    df94:      	cmp	x0, #0x39
    df98:      	cset	w0, eq
    df9c:      	ubfx	x0, x0, #0, #8
    dfa0:      	ret
    dfa4:      	cmp	x0, #0x20
    dfa8:      	b.ne	0xdfb4 <_stogir.vector-arithmetic.unary?+0x34>
    dfac:      	mov	x0, #0x1                ; =1
    dfb0:      	b	0xdfa0 <_stogir.vector-arithmetic.unary?+0x20>
    dfb4:      	cmp	x0, #0x2d
    dfb8:      	b.ne	0xdfc4 <_stogir.vector-arithmetic.unary?+0x44>
    dfbc:      	mov	x0, #0x1                ; =1
    dfc0:      	b	0xdfa0 <_stogir.vector-arithmetic.unary?+0x20>
    dfc4:      	cmp	x0, #0x36
    dfc8:      	b.ne	0xdfd4 <_stogir.vector-arithmetic.unary?+0x54>
    dfcc:      	mov	x0, #0x1                ; =1
    dfd0:      	b	0xdfa0 <_stogir.vector-arithmetic.unary?+0x20>
    dfd4:      	cmp	x0, #0x37
    dfd8:      	b.ne	0xdfe4 <_stogir.vector-arithmetic.unary?+0x64>
    dfdc:      	mov	x0, #0x1                ; =1
    dfe0:      	b	0xdfa0 <_stogir.vector-arithmetic.unary?+0x20>
    dfe4:      	cmp	x0, #0x38
    dfe8:      	b.ne	0xdf94 <_stogir.vector-arithmetic.unary?+0x14>
    dfec:      	mov	x0, #0x1                ; =1
    dff0:      	b	0xdfa0 <_stogir.vector-arithmetic.unary?+0x20>

000000000000dff4 <_stogir.vector-arithmetic.operands>:
    dff4:      	sub	sp, sp, #0x80
    dff8:      	str	x29, [sp]
    dffc:      	str	x30, [sp, #0x8]
    e000:      	mov	x29, sp
    e004:      	str	x19, [sp, #0x30]
    e008:      	str	x20, [sp, #0x38]
    e00c:      	str	x21, [sp, #0x40]
    e010:      	str	x22, [sp, #0x48]
    e014:      	str	x23, [sp, #0x50]
    e018:      	str	x24, [sp, #0x58]
    e01c:      	str	x25, [sp, #0x60]
    e020:      	str	x26, [sp, #0x68]
    e024:      	str	x27, [sp, #0x70]
    e028:      	str	x28, [sp, #0x78]
    e02c:      	lsr	w1, w1, #0
    e030:      	lsr	w2, w2, #0
    e034:      	mov	x19, x8
    e038:      	mov	x20, x0
    e03c:      	mov	w0, w1
    e040:      	mov	w21, w1
    e044:      	mov	w1, w2
    e048:      	mov	w22, w2
    e04c:      	mov	w23, w3
    e050:      	mov	w24, w4
    e054:      	mov	w25, w5
    e058:      	bl	0xe058 <_stogir.vector-arithmetic.operands+0x64>
		000000000000e058:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    e05c:      	cmp	x0, #0x0
    e060:      	b.eq	0xe078 <_stogir.vector-arithmetic.operands+0x84>
    e064:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e064:  ARM64_RELOC_PAGE21	l_stogir.494
    e068:      	ldr	x16, [x16]
		000000000000e068:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    e06c:      	orr	x0, x16, xzr
    e070:      	movz	x1, #0x0, lsl #48
    e074:      	b	0xe088 <_stogir.vector-arithmetic.operands+0x94>
    e078:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e078:  ARM64_RELOC_PAGE21	l_stogir.495
    e07c:      	ldr	x16, [x16]
		000000000000e07c:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    e080:      	orr	x0, x16, xzr
    e084:      	mov	x1, #0x37               ; =55
    e088:      	sxtw	x21, w21
    e08c:      	sxtw	x22, w22
    e090:      	sxtw	x23, w23
    e094:      	sxtw	x24, w24
    e098:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e098:  ARM64_RELOC_PAGE21	l_stogir.496
    e09c:      	ldr	x16, [x16]
		000000000000e09c:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    e0a0:      	orr	x2, x16, xzr
    e0a4:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e0a4:  ARM64_RELOC_PAGE21	l_stogir.497
    e0a8:      	ldr	x16, [x16]
		000000000000e0a8:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    e0ac:      	orr	x3, x16, xzr
    e0b0:      	add	x4, x20, #0x78
    e0b4:      	add	x5, x20, #0x28
    e0b8:      	add	x6, x20, #0x50
    e0bc:      	cmp	x21, #0x31
    e0c0:      	cset	w7, ge
    e0c4:      	cmp	x21, #0x35
    e0c8:      	cset	w8, le
    e0cc:      	cmp	x21, #0x1f
    e0d0:      	cset	w9, eq
    e0d4:      	cmp	x21, #0x20
    e0d8:      	cset	w10, eq
    e0dc:      	cmp	x21, #0x2d
    e0e0:      	cset	w11, eq
    e0e4:      	cmp	x21, #0x36
    e0e8:      	cset	w12, eq
    e0ec:      	cmp	x21, #0x37
    e0f0:      	cset	w13, eq
    e0f4:      	cmp	x21, #0x38
    e0f8:      	cset	w14, eq
    e0fc:      	cmp	x21, #0x39
    e100:      	cset	w15, eq
    e104:      	mov	x26, x1
    e108:      	mov	x1, x0
    e10c:      	movz	x0, #0x0, lsl #48
    e110:      	b	0xe1ec <_stogir.vector-arithmetic.operands+0x1f8>
    e114:      	movz	x2, #0x0, lsl #48
    e118:      	b	0xe128 <_stogir.vector-arithmetic.operands+0x134>
    e11c:      	movz	x2, #0x0, lsl #48
    e120:      	b	0xe130 <_stogir.vector-arithmetic.operands+0x13c>
    e124:      	movz	x2, #0x0, lsl #48
    e128:      	b	0xe13c <_stogir.vector-arithmetic.operands+0x148>
    e12c:      	movz	x2, #0x0, lsl #48
    e130:      	str	x5, [sp, #0x28]
    e134:      	b	0xe13c <_stogir.vector-arithmetic.operands+0x148>
    e138:      	movz	x2, #0x0, lsl #48
    e13c:      	cmp	x2, #0x0
    e140:      	b.eq	0xe180 <_stogir.vector-arithmetic.operands+0x18c>
    e144:      	uxtb	w16, w28
    e148:      	cmp	w16, wzr
    e14c:      	b.eq	0xe164 <_stogir.vector-arithmetic.operands+0x170>
    e150:      	lsl	x1, x1, #4
    e154:      	ldr	x2, [x20]
    e158:      	add	x1, x1, x2
    e15c:      	ldr	x1, [x1]
    e160:      	b	0xe174 <_stogir.vector-arithmetic.operands+0x180>
    e164:      	lsl	x1, x3, #4
    e168:      	ldr	x2, [x20, #0x28]
    e16c:      	add	x1, x1, x2
    e170:      	ldr	x1, [x1]
    e174:      	mov	x2, x1
    e178:      	mov	x1, #0x1                ; =1
    e17c:      	b	0xe188 <_stogir.vector-arithmetic.operands+0x194>
    e180:      	movz	x1, #0x0, lsl #48
    e184:      	movz	x2, #0x0, lsl #48
    e188:      	lsr	w1, w1, #0
    e18c:      	lsr	x16, x1, #0
    e190:      	cmp	x16, #0x1
    e194:      	b.eq	0xe1b0 <_stogir.vector-arithmetic.operands+0x1bc>
    e198:      	b.lo	0xe1a0 <_stogir.vector-arithmetic.operands+0x1ac>
    e19c:      	b	0xe1b4 <_stogir.vector-arithmetic.operands+0x1c0>
    e1a0:      	cmp	x16, #0x0
    e1a4:      	b.eq	0xe1ac <_stogir.vector-arithmetic.operands+0x1b8>
    e1a8:      	b	0xe1b4 <_stogir.vector-arithmetic.operands+0x1c0>
    e1ac:      	b	0xe1b8 <_stogir.vector-arithmetic.operands+0x1c4>
    e1b0:      	b	0xe330 <_stogir.vector-arithmetic.operands+0x33c>
    e1b4:      	b	0xe57c <_stogir.vector-arithmetic.operands+0x588>
    e1b8:      	ldr	x1, [sp, #0x10]
    e1bc:      	mov	x2, #0x21               ; =33
    e1c0:      	b	0xe1cc <_stogir.vector-arithmetic.operands+0x1d8>
    e1c4:      	ldr	x1, [sp, #0x18]
    e1c8:      	mov	x2, #0x32               ; =50
    e1cc:      	add	x0, x0, #0x1
    e1d0:      	lsr	w0, w0, #0
    e1d4:      	sxtw	x0, w0
    e1d8:      	ldr	x3, [sp, #0x18]
    e1dc:      	ldr	x4, [sp, #0x20]
    e1e0:      	ldr	x5, [sp, #0x28]
    e1e4:      	mov	x26, x2
    e1e8:      	ldr	x2, [sp, #0x10]
    e1ec:      	uxtb	w16, w9
    e1f0:      	cmp	w16, wzr
    e1f4:      	b.ne	0xe250 <_stogir.vector-arithmetic.operands+0x25c>
    e1f8:      	uxtb	w16, w10
    e1fc:      	cmp	w16, wzr
    e200:      	b.ne	0xe250 <_stogir.vector-arithmetic.operands+0x25c>
    e204:      	uxtb	w16, w11
    e208:      	cmp	w16, wzr
    e20c:      	b.ne	0xe250 <_stogir.vector-arithmetic.operands+0x25c>
    e210:      	uxtb	w16, w12
    e214:      	cmp	w16, wzr
    e218:      	b.ne	0xe250 <_stogir.vector-arithmetic.operands+0x25c>
    e21c:      	uxtb	w16, w13
    e220:      	cmp	w16, wzr
    e224:      	b.ne	0xe250 <_stogir.vector-arithmetic.operands+0x25c>
    e228:      	uxtb	w16, w14
    e22c:      	cmp	w16, wzr
    e230:      	b.ne	0xe250 <_stogir.vector-arithmetic.operands+0x25c>
    e234:      	uxtb	w16, w15
    e238:      	cmp	w16, wzr
    e23c:      	b.ne	0xe250 <_stogir.vector-arithmetic.operands+0x25c>
    e240:      	mov	x27, x26
    e244:      	mov	x26, x1
    e248:      	mov	x1, #0x2                ; =2
    e24c:      	b	0xe25c <_stogir.vector-arithmetic.operands+0x268>
    e250:      	mov	x27, x26
    e254:      	mov	x26, x1
    e258:      	mov	x1, #0x1                ; =1
    e25c:      	cmp	x0, x1
    e260:      	b.ge	0xe390 <_stogir.vector-arithmetic.operands+0x39c>
    e264:      	cmp	x0, #0x0
    e268:      	b.ne	0xe274 <_stogir.vector-arithmetic.operands+0x280>
    e26c:      	mov	x1, x23
    e270:      	b	0xe278 <_stogir.vector-arithmetic.operands+0x284>
    e274:      	mov	x1, x24
    e278:      	lsr	w1, w1, #0
    e27c:      	sxtw	x1, w1
    e280:      	cmp	x1, #0x0
    e284:      	cset	w28, gt
    e288:      	str	x2, [sp, #0x10]
    e28c:      	movz	x16, #0x0, lsl #48
    e290:      	sub	x2, x16, x1
    e294:      	str	x3, [sp, #0x18]
    e298:      	sub	x3, x2, #0x1
    e29c:      	uxtb	w16, w28
    e2a0:      	cmp	w16, wzr
    e2a4:      	b.eq	0xe678 <_stogir.vector-arithmetic.operands+0x684>
    e2a8:      	ldr	x2, [x20, #0x8]
    e2ac:      	cmp	x1, x2
    e2b0:      	b.ge	0xe680 <_stogir.vector-arithmetic.operands+0x68c>
    e2b4:      	ldr	x2, [x4, #0x8]
    e2b8:      	cmp	x1, x2
    e2bc:      	b.ge	0xe688 <_stogir.vector-arithmetic.operands+0x694>
    e2c0:      	lsl	x2, x1, #2
    e2c4:      	str	x4, [sp, #0x20]
    e2c8:      	ldr	x4, [x20, #0x78]
    e2cc:      	add	x2, x2, x4
    e2d0:      	ldr	w2, [x2]
    e2d4:      	sxtw	x2, w2
    e2d8:      	cmp	x2, #0x0
    e2dc:      	cset	w2, ge
    e2e0:      	ubfx	x2, x2, #0, #8
    e2e4:      	b	0xe120 <_stogir.vector-arithmetic.operands+0x12c>
    e2e8:      	cmp	x1, #0x0
    e2ec:      	b.ge	0xe690 <_stogir.vector-arithmetic.operands+0x69c>
    e2f0:      	ldr	x4, [x5, #0x8]
    e2f4:      	str	x5, [sp, #0x28]
    e2f8:      	ldr	x5, [x6, #0x8]
    e2fc:      	cmp	x4, x5
    e300:      	b.ne	0xe124 <_stogir.vector-arithmetic.operands+0x130>
    e304:      	cmp	x2, x4
    e308:      	b.gt	0xe114 <_stogir.vector-arithmetic.operands+0x120>
    e30c:      	lsl	x2, x3, #2
    e310:      	ldr	x4, [x20, #0x50]
    e314:      	add	x2, x2, x4
    e318:      	ldr	w2, [x2]
    e31c:      	sxtw	x2, w2
    e320:      	cmp	x2, #0x0
    e324:      	cset	w2, gt
    e328:      	ubfx	x2, x2, #0, #8
    e32c:      	b	0xe118 <_stogir.vector-arithmetic.operands+0x124>
    e330:      	lsr	w1, w2, #0
    e334:      	ubfx	x1, x1, #8, #8
    e338:      	cmp	x1, x22
    e33c:      	b.eq	0xe370 <_stogir.vector-arithmetic.operands+0x37c>
    e340:      	cmp	x0, #0x1
    e344:      	b.ne	0xe1c4 <_stogir.vector-arithmetic.operands+0x1d0>
    e348:      	uxtb	w16, w7
    e34c:      	cmp	w16, wzr
    e350:      	b.eq	0xe1c4 <_stogir.vector-arithmetic.operands+0x1d0>
    e354:      	uxtb	w16, w8
    e358:      	cmp	w16, wzr
    e35c:      	b.eq	0xe1c4 <_stogir.vector-arithmetic.operands+0x1d0>
    e360:      	cmp	x1, #0x1
    e364:      	b.lt	0xe1c4 <_stogir.vector-arithmetic.operands+0x1d0>
    e368:      	cmp	x1, #0xb
    e36c:      	b.gt	0xe1c4 <_stogir.vector-arithmetic.operands+0x1d0>
    e370:      	uxtb	w2, w2
    e374:      	cmp	x2, #0x48
    e378:      	b.eq	0xe1c4 <_stogir.vector-arithmetic.operands+0x1d0>
    e37c:      	cmp	x2, #0x46
    e380:      	b.eq	0xe1c4 <_stogir.vector-arithmetic.operands+0x1d0>
    e384:      	mov	x1, x26
    e388:      	mov	x2, x27
    e38c:      	b	0xe1cc <_stogir.vector-arithmetic.operands+0x1d8>
    e390:      	sxtw	x25, w25
    e394:      	cmp	x25, #0x0
    e398:      	b.ne	0xe3ac <_stogir.vector-arithmetic.operands+0x3b8>
    e39c:      	mov	x1, x26
    e3a0:      	mov	x2, x27
    e3a4:      	movz	x0, #0x0, lsl #48
    e3a8:      	b	0xe3b8 <_stogir.vector-arithmetic.operands+0x3c4>
    e3ac:      	mov	x1, x26
    e3b0:      	mov	x2, x27
    e3b4:      	mov	x0, #0x1                ; =1
    e3b8:      	cmp	x0, #0x0
    e3bc:      	b.eq	0xe3d0 <_stogir.vector-arithmetic.operands+0x3dc>
    e3c0:      	cmp	x21, #0x1d
    e3c4:      	b.ne	0xe4c4 <_stogir.vector-arithmetic.operands+0x4d0>
    e3c8:      	mov	x0, #0x1                ; =1
    e3cc:      	b	0xe4d0 <_stogir.vector-arithmetic.operands+0x4dc>
    e3d0:      	mov	x0, x1
    e3d4:      	mov	x1, x2
    e3d8:      	cmp	x1, #0x0
    e3dc:      	b.ne	0xe3f4 <_stogir.vector-arithmetic.operands+0x400>
    e3e0:      	and	x0, x22, #0xffffffff
    e3e4:      	mov	x1, x0
    e3e8:      	movz	x0, #0x0, lsl #48
    e3ec:      	movz	x2, #0x0, lsl #48
    e3f0:      	b	0xe400 <_stogir.vector-arithmetic.operands+0x40c>
    e3f4:      	mov	x2, x1
    e3f8:      	mov	x1, x0
    e3fc:      	mov	x0, #0x1                ; =1
    e400:      	str	x0, [x19]
    e404:      	str	x1, [x19, #0x8]
    e408:      	str	x2, [x19, #0x10]
    e40c:      	ldr	x19, [sp, #0x30]
    e410:      	ldr	x20, [sp, #0x38]
    e414:      	ldr	x21, [sp, #0x40]
    e418:      	ldr	x22, [sp, #0x48]
    e41c:      	ldr	x23, [sp, #0x50]
    e420:      	ldr	x24, [sp, #0x58]
    e424:      	ldr	x25, [sp, #0x60]
    e428:      	ldr	x26, [sp, #0x68]
    e42c:      	ldr	x27, [sp, #0x70]
    e430:      	ldr	x28, [sp, #0x78]
    e434:      	ldr	x29, [sp]
    e438:      	ldr	x30, [sp, #0x8]
    e43c:      	add	sp, sp, #0x80
    e440:      	ret
    e444:      	mov	x0, #0x1                ; =1
    e448:      	cmp	x0, #0x0
    e44c:      	b.eq	0xe464 <_stogir.vector-arithmetic.operands+0x470>
    e450:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e450:  ARM64_RELOC_PAGE21	l_stogir.498
    e454:      	ldr	x16, [x16]
		000000000000e454:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    e458:      	orr	x0, x16, xzr
    e45c:      	mov	x1, #0x23               ; =35
    e460:      	b	0xe3d8 <_stogir.vector-arithmetic.operands+0x3e4>
    e464:      	cmp	x25, #0x0
    e468:      	cset	w0, gt
    e46c:      	movz	x16, #0x0, lsl #48
    e470:      	sub	x3, x16, x25
    e474:      	sub	x4, x3, #0x1
    e478:      	uxtb	w16, w0
    e47c:      	cmp	w16, wzr
    e480:      	b.eq	0xe530 <_stogir.vector-arithmetic.operands+0x53c>
    e484:      	ldr	x3, [x20, #0x8]
    e488:      	cmp	x25, x3
    e48c:      	b.ge	0xe584 <_stogir.vector-arithmetic.operands+0x590>
    e490:      	add	x3, x20, #0x78
    e494:      	ldr	x3, [x3, #0x8]
    e498:      	cmp	x25, x3
    e49c:      	b.ge	0xe654 <_stogir.vector-arithmetic.operands+0x660>
    e4a0:      	lsl	x3, x25, #2
    e4a4:      	ldr	x5, [x20, #0x78]
    e4a8:      	add	x3, x3, x5
    e4ac:      	ldr	w3, [x3]
    e4b0:      	sxtw	x3, w3
    e4b4:      	cmp	x3, #0x0
    e4b8:      	cset	w3, ge
    e4bc:      	ubfx	x3, x3, #0, #8
    e4c0:      	b	0xe658 <_stogir.vector-arithmetic.operands+0x664>
    e4c4:      	cmp	x21, #0x1e
    e4c8:      	cset	w0, eq
    e4cc:      	ubfx	x0, x0, #0, #8
    e4d0:      	cmp	x0, #0x0
    e4d4:      	b.eq	0xe444 <_stogir.vector-arithmetic.operands+0x450>
    e4d8:      	movz	x0, #0x0, lsl #48
    e4dc:      	b	0xe448 <_stogir.vector-arithmetic.operands+0x454>
    e4e0:      	movz	x0, #0x0, lsl #48
    e4e4:      	uxtb	w0, w0
    e4e8:      	and	x0, x0, #0x2
    e4ec:      	uxtb	w0, w0
    e4f0:      	cmp	x0, #0x0
    e4f4:      	cset	w0, eq
    e4f8:      	uxtb	w16, w0
    e4fc:      	cmp	w16, wzr
    e500:      	cset	x0, eq
    e504:      	cmp	x0, #0x0
    e508:      	b.ne	0xe65c <_stogir.vector-arithmetic.operands+0x668>
    e50c:      	cmp	x3, #0x65
    e510:      	b.eq	0xe65c <_stogir.vector-arithmetic.operands+0x668>
    e514:      	cmp	x3, #0x66
    e518:      	b.eq	0xe65c <_stogir.vector-arithmetic.operands+0x668>
    e51c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e51c:  ARM64_RELOC_PAGE21	l_stogir.499
    e520:      	ldr	x16, [x16]
		000000000000e520:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    e524:      	orr	x0, x16, xzr
    e528:      	mov	x1, #0x34               ; =52
    e52c:      	b	0xe460 <_stogir.vector-arithmetic.operands+0x46c>
    e530:      	cmp	x25, #0x0
    e534:      	b.ge	0xe58c <_stogir.vector-arithmetic.operands+0x598>
    e538:      	add	x5, x20, #0x28
    e53c:      	add	x6, x20, #0x50
    e540:      	ldr	x5, [x5, #0x8]
    e544:      	ldr	x6, [x6, #0x8]
    e548:      	cmp	x5, x6
    e54c:      	b.ne	0xe64c <_stogir.vector-arithmetic.operands+0x658>
    e550:      	cmp	x3, x5
    e554:      	b.gt	0xe668 <_stogir.vector-arithmetic.operands+0x674>
    e558:      	lsl	x3, x4, #2
    e55c:      	ldr	x5, [x20, #0x50]
    e560:      	add	x3, x3, x5
    e564:      	ldr	w3, [x3]
    e568:      	sxtw	x3, w3
    e56c:      	cmp	x3, #0x0
    e570:      	cset	w3, gt
    e574:      	ubfx	x3, x3, #0, #8
    e578:      	b	0xe66c <_stogir.vector-arithmetic.operands+0x678>
    e57c:      	brk	#0
    e580:      	b	0xe57c <_stogir.vector-arithmetic.operands+0x588>
    e584:      	movz	x3, #0x0, lsl #48
    e588:      	b	0xe590 <_stogir.vector-arithmetic.operands+0x59c>
    e58c:      	movz	x3, #0x0, lsl #48
    e590:      	cmp	x3, #0x0
    e594:      	b.eq	0xe5d4 <_stogir.vector-arithmetic.operands+0x5e0>
    e598:      	uxtb	w16, w0
    e59c:      	cmp	w16, wzr
    e5a0:      	b.eq	0xe5b8 <_stogir.vector-arithmetic.operands+0x5c4>
    e5a4:      	lsl	x0, x25, #4
    e5a8:      	ldr	x3, [x20]
    e5ac:      	add	x0, x0, x3
    e5b0:      	ldr	x0, [x0]
    e5b4:      	b	0xe5c8 <_stogir.vector-arithmetic.operands+0x5d4>
    e5b8:      	lsl	x0, x4, #4
    e5bc:      	ldr	x3, [x20, #0x28]
    e5c0:      	add	x0, x0, x3
    e5c4:      	ldr	x0, [x0]
    e5c8:      	mov	x3, x0
    e5cc:      	mov	x0, #0x1                ; =1
    e5d0:      	b	0xe5dc <_stogir.vector-arithmetic.operands+0x5e8>
    e5d4:      	movz	x0, #0x0, lsl #48
    e5d8:      	movz	x3, #0x0, lsl #48
    e5dc:      	lsr	w0, w0, #0
    e5e0:      	lsr	x16, x0, #0
    e5e4:      	cmp	x16, #0x1
    e5e8:      	b.eq	0xe604 <_stogir.vector-arithmetic.operands+0x610>
    e5ec:      	b.lo	0xe5f4 <_stogir.vector-arithmetic.operands+0x600>
    e5f0:      	b	0xe608 <_stogir.vector-arithmetic.operands+0x614>
    e5f4:      	cmp	x16, #0x0
    e5f8:      	b.eq	0xe600 <_stogir.vector-arithmetic.operands+0x60c>
    e5fc:      	b	0xe608 <_stogir.vector-arithmetic.operands+0x614>
    e600:      	b	0xe60c <_stogir.vector-arithmetic.operands+0x618>
    e604:      	b	0xe620 <_stogir.vector-arithmetic.operands+0x62c>
    e608:      	b	0xe670 <_stogir.vector-arithmetic.operands+0x67c>
    e60c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e60c:  ARM64_RELOC_PAGE21	l_stogir.500
    e610:      	ldr	x16, [x16]
		000000000000e610:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    e614:      	orr	x0, x16, xzr
    e618:      	mov	x1, #0x1d               ; =29
    e61c:      	b	0xe52c <_stogir.vector-arithmetic.operands+0x538>
    e620:      	cmp	x25, #0x0
    e624:      	b.le	0xe51c <_stogir.vector-arithmetic.operands+0x528>
    e628:      	uxtb	w3, w3
    e62c:      	cmp	x3, #0x83
    e630:      	b.ge	0xe4e0 <_stogir.vector-arithmetic.operands+0x4ec>
    e634:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e634:  ARM64_RELOC_PAGE21	l_stogir.501
    e638:      	ldr	x16, [x16]
		000000000000e638:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    e63c:      	orr	x0, x16, xzr
    e640:      	add	x0, x3, x0
    e644:      	ldrb	w0, [x0]
    e648:      	b	0xe4e4 <_stogir.vector-arithmetic.operands+0x4f0>
    e64c:      	movz	x3, #0x0, lsl #48
    e650:      	b	0xe590 <_stogir.vector-arithmetic.operands+0x59c>
    e654:      	movz	x3, #0x0, lsl #48
    e658:      	b	0xe588 <_stogir.vector-arithmetic.operands+0x594>
    e65c:      	mov	x0, x1
    e660:      	mov	x1, x2
    e664:      	b	0xe52c <_stogir.vector-arithmetic.operands+0x538>
    e668:      	movz	x3, #0x0, lsl #48
    e66c:      	b	0xe650 <_stogir.vector-arithmetic.operands+0x65c>
    e670:      	brk	#0
    e674:      	b	0xe670 <_stogir.vector-arithmetic.operands+0x67c>
    e678:      	str	x4, [sp, #0x20]
    e67c:      	b	0xe2e8 <_stogir.vector-arithmetic.operands+0x2f4>
    e680:      	str	x4, [sp, #0x20]
    e684:      	b	0xe12c <_stogir.vector-arithmetic.operands+0x138>
    e688:      	str	x4, [sp, #0x20]
    e68c:      	b	0xe11c <_stogir.vector-arithmetic.operands+0x128>
    e690:      	str	x5, [sp, #0x28]
    e694:      	b	0xe138 <_stogir.vector-arithmetic.operands+0x144>

000000000000e698 <_stogir.types.base-type>:
    e698:      	sub	sp, sp, #0x20
    e69c:      	str	x29, [sp]
    e6a0:      	str	x30, [sp, #0x8]
    e6a4:      	mov	x29, sp
    e6a8:      	str	x19, [sp, #0x10]
    e6ac:      	lsr	w0, w0, #0
    e6b0:      	mov	w19, w0
    e6b4:      	bl	0xe6b4 <_stogir.types.base-type+0x1c>
		000000000000e6b4:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e6b8:      	cmp	x0, #0x0
    e6bc:      	b.eq	0xe6d4 <_stogir.types.base-type+0x3c>
    e6c0:      	sxtw	x19, w19
    e6c4:      	and	x0, x19, #0xf
    e6c8:      	lsr	w0, w0, #0
    e6cc:      	sxtw	x0, w0
    e6d0:      	b	0xe6d8 <_stogir.types.base-type+0x40>
    e6d4:      	movn	x0, #0x0, lsl #48
    e6d8:      	ldr	x19, [sp, #0x10]
    e6dc:      	ldr	x29, [sp]
    e6e0:      	ldr	x30, [sp, #0x8]
    e6e4:      	add	sp, sp, #0x20
    e6e8:      	ret

000000000000e6ec <_stogir.types.lanes>:
    e6ec:      	sxtw	x0, w0
    e6f0:      	cmp	x0, #0xf
    e6f4:      	b.le	0xe744 <_stogir.types.lanes+0x58>
    e6f8:      	cmp	x0, #0x80
    e6fc:      	b.ge	0xe744 <_stogir.types.lanes+0x58>
    e700:      	and	x1, x0, #0xf
    e704:      	lsr	w1, w1, #0
    e708:      	sxtw	x1, w1
    e70c:      	cmp	x1, #0x1
    e710:      	b.lt	0xe744 <_stogir.types.lanes+0x58>
    e714:      	cmp	x1, #0xd
    e718:      	b.gt	0xe744 <_stogir.types.lanes+0x58>
    e71c:      	ubfx	x0, x0, #4, #32
    e720:      	sxtw	x0, w0
    e724:      	sub	x0, x0, #0x1
    e728:      	lsr	w0, w0, #0
    e72c:      	sxtw	x0, w0
    e730:      	mov	x16, #0x1               ; =1
    e734:      	lsl	x0, x16, x0
    e738:      	lsr	w0, w0, #0
    e73c:      	sxtw	x0, w0
    e740:      	b	0xe770 <_stogir.types.lanes+0x84>
    e744:      	cmp	x0, #0x0
    e748:      	b.lt	0xe76c <_stogir.types.lanes+0x80>
    e74c:      	cmp	x0, #0xd
    e750:      	b.gt	0xe76c <_stogir.types.lanes+0x80>
    e754:      	cmp	x0, #0x0
    e758:      	cset	w0, eq
    e75c:      	uxtb	w16, w0
    e760:      	cmp	w16, wzr
    e764:      	cset	x0, eq
    e768:      	b	0xe770 <_stogir.types.lanes+0x84>
    e76c:      	movn	x0, #0x0, lsl #48
    e770:      	ret

000000000000e774 <_coil.core.Get$slice$get__u8>:
    e774:      	lsr	x1, x2, #0
    e778:      	add	x0, x1, x0
    e77c:      	ldrb	w0, [x0]
    e780:      	ret

000000000000e784 <_stogir.checked.valid-type?>:
    e784:      	sxtw	x0, w0
    e788:      	cmp	x0, #0x1
    e78c:      	b.lt	0xe7b0 <_stogir.checked.valid-type?+0x2c>
    e790:      	cmp	x0, #0xb
    e794:      	b.gt	0xe7b0 <_stogir.checked.valid-type?+0x2c>
    e798:      	cmp	x0, #0x1
    e79c:      	cset	w0, eq
    e7a0:      	uxtb	w16, w0
    e7a4:      	cmp	w16, wzr
    e7a8:      	cset	x0, eq
    e7ac:      	b	0xe7b4 <_stogir.checked.valid-type?+0x30>
    e7b0:      	movz	x0, #0x0, lsl #48
    e7b4:      	ret

000000000000e7b8 <_coil.core.Iterable$slice$iter__i32>:
    e7b8:      	str	x0, [x8]
    e7bc:      	str	x1, [x8, #0x8]
    e7c0:      	movz	x17, #0x0, lsl #48
    e7c4:      	str	x17, [x8, #0x10]
    e7c8:      	ret

000000000000e7cc <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
    e7cc:      	sub	sp, sp, #0x10
    e7d0:      	mov	x1, sp
    e7d4:      	ldr	x2, [x0, #0x10]
    e7d8:      	ldr	x3, [x0]
    e7dc:      	ldr	x4, [x0, #0x8]
    e7e0:      	cmp	x2, x4
    e7e4:      	b.ge	0xe810 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
    e7e8:      	add	x4, x2, #0x1
    e7ec:      	lsl	x2, x2, #2
    e7f0:      	add	x2, x2, x3
    e7f4:      	str	x4, [x0, #0x10]
    e7f8:      	ldr	w0, [x2]
    e7fc:      	sxtw	x0, w0
    e800:      	and	x0, x0, #0xffffffff
    e804:      	mov	x2, x0
    e808:      	mov	x0, #0x1                ; =1
    e80c:      	b	0xe818 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x4c>
    e810:      	movz	x0, #0x0, lsl #48
    e814:      	movz	x2, #0x0, lsl #48
    e818:      	str	x0, [x1]
    e81c:      	str	x2, [x1, #0x8]
    e820:      	ldr	x0, [sp]
    e824:      	ldr	x1, [sp, #0x8]
    e828:      	add	sp, sp, #0x10
    e82c:      	ret

000000000000e830 <_stogir.terminal.previous-input>:
    e830:      	sxtw	x1, w1
    e834:      	cmp	x1, #0x0
    e838:      	b.ne	0xe858 <_stogir.terminal.previous-input+0x28>
    e83c:      	movz	x0, #0x0, lsl #48
    e840:      	movz	x1, #0x0, lsl #48
    e844:      	movz	x2, #0x0, lsl #48
    e848:      	str	x0, [x8]
    e84c:      	str	x1, [x8, #0x8]
    e850:      	str	x2, [x8, #0x10]
    e854:      	ret
    e858:      	cmp	x1, #0x0
    e85c:      	cset	w2, gt
    e860:      	movz	x16, #0x0, lsl #48
    e864:      	sub	x3, x16, x1
    e868:      	sub	x4, x3, #0x1
    e86c:      	uxtb	w16, w2
    e870:      	cmp	w16, wzr
    e874:      	b.eq	0xe8d4 <_stogir.terminal.previous-input+0xa4>
    e878:      	ldr	x3, [x0, #0x8]
    e87c:      	cmp	x1, x3
    e880:      	b.ge	0xe920 <_stogir.terminal.previous-input+0xf0>
    e884:      	add	x3, x0, #0x78
    e888:      	ldr	x3, [x3, #0x8]
    e88c:      	cmp	x1, x3
    e890:      	b.ge	0xe9f8 <_stogir.terminal.previous-input+0x1c8>
    e894:      	lsl	x3, x1, #2
    e898:      	ldr	x5, [x0, #0x78]
    e89c:      	add	x3, x3, x5
    e8a0:      	ldr	w3, [x3]
    e8a4:      	sxtw	x3, w3
    e8a8:      	cmp	x3, #0x0
    e8ac:      	cset	w3, ge
    e8b0:      	ubfx	x3, x3, #0, #8
    e8b4:      	b	0xe9fc <_stogir.terminal.previous-input+0x1cc>
    e8b8:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e8b8:  ARM64_RELOC_PAGE21	l_stogir.502
    e8bc:      	ldr	x16, [x16]
		000000000000e8bc:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    e8c0:      	orr	x0, x16, xzr
    e8c4:      	mov	x1, x0
    e8c8:      	mov	x0, #0x1                ; =1
    e8cc:      	mov	x2, #0x2e               ; =46
    e8d0:      	b	0xe848 <_stogir.terminal.previous-input+0x18>
    e8d4:      	cmp	x1, #0x0
    e8d8:      	b.ge	0xe928 <_stogir.terminal.previous-input+0xf8>
    e8dc:      	add	x5, x0, #0x28
    e8e0:      	add	x6, x0, #0x50
    e8e4:      	ldr	x5, [x5, #0x8]
    e8e8:      	ldr	x6, [x6, #0x8]
    e8ec:      	cmp	x5, x6
    e8f0:      	b.ne	0xe9f0 <_stogir.terminal.previous-input+0x1c0>
    e8f4:      	cmp	x3, x5
    e8f8:      	b.gt	0xea00 <_stogir.terminal.previous-input+0x1d0>
    e8fc:      	lsl	x3, x4, #2
    e900:      	ldr	x5, [x0, #0x50]
    e904:      	add	x3, x3, x5
    e908:      	ldr	w3, [x3]
    e90c:      	sxtw	x3, w3
    e910:      	cmp	x3, #0x0
    e914:      	cset	w3, gt
    e918:      	ubfx	x3, x3, #0, #8
    e91c:      	b	0xea04 <_stogir.terminal.previous-input+0x1d4>
    e920:      	movz	x3, #0x0, lsl #48
    e924:      	b	0xe92c <_stogir.terminal.previous-input+0xfc>
    e928:      	movz	x3, #0x0, lsl #48
    e92c:      	cmp	x3, #0x0
    e930:      	b.eq	0xe970 <_stogir.terminal.previous-input+0x140>
    e934:      	uxtb	w16, w2
    e938:      	cmp	w16, wzr
    e93c:      	b.eq	0xe954 <_stogir.terminal.previous-input+0x124>
    e940:      	lsl	x2, x1, #4
    e944:      	ldr	x0, [x0]
    e948:      	add	x0, x2, x0
    e94c:      	ldr	x0, [x0]
    e950:      	b	0xe964 <_stogir.terminal.previous-input+0x134>
    e954:      	lsl	x2, x4, #4
    e958:      	ldr	x0, [x0, #0x28]
    e95c:      	add	x0, x2, x0
    e960:      	ldr	x0, [x0]
    e964:      	mov	x2, x0
    e968:      	mov	x0, #0x1                ; =1
    e96c:      	b	0xe978 <_stogir.terminal.previous-input+0x148>
    e970:      	movz	x0, #0x0, lsl #48
    e974:      	movz	x2, #0x0, lsl #48
    e978:      	lsr	w0, w0, #0
    e97c:      	lsr	x16, x0, #0
    e980:      	cmp	x16, #0x1
    e984:      	b.eq	0xe9a0 <_stogir.terminal.previous-input+0x170>
    e988:      	b.lo	0xe990 <_stogir.terminal.previous-input+0x160>
    e98c:      	b	0xe9a4 <_stogir.terminal.previous-input+0x174>
    e990:      	cmp	x16, #0x0
    e994:      	b.eq	0xe99c <_stogir.terminal.previous-input+0x16c>
    e998:      	b	0xe9a4 <_stogir.terminal.previous-input+0x174>
    e99c:      	b	0xe9a8 <_stogir.terminal.previous-input+0x178>
    e9a0:      	b	0xe9c4 <_stogir.terminal.previous-input+0x194>
    e9a4:      	b	0xea48 <_stogir.terminal.previous-input+0x218>
    e9a8:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e9a8:  ARM64_RELOC_PAGE21	l_stogir.503
    e9ac:      	ldr	x16, [x16]
		000000000000e9ac:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    e9b0:      	orr	x0, x16, xzr
    e9b4:      	mov	x1, x0
    e9b8:      	mov	x0, #0x1                ; =1
    e9bc:      	mov	x2, #0x1d               ; =29
    e9c0:      	b	0xe8d0 <_stogir.terminal.previous-input+0xa0>
    e9c4:      	cmp	x1, #0x0
    e9c8:      	b.le	0xe8b8 <_stogir.terminal.previous-input+0x88>
    e9cc:      	uxtb	w2, w2
    e9d0:      	cmp	x2, #0x83
    e9d4:      	b.ge	0xea08 <_stogir.terminal.previous-input+0x1d8>
    e9d8:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000e9d8:  ARM64_RELOC_PAGE21	l_stogir.504
    e9dc:      	ldr	x16, [x16]
		000000000000e9dc:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    e9e0:      	orr	x0, x16, xzr
    e9e4:      	add	x0, x2, x0
    e9e8:      	ldrb	w0, [x0]
    e9ec:      	b	0xea0c <_stogir.terminal.previous-input+0x1dc>
    e9f0:      	movz	x3, #0x0, lsl #48
    e9f4:      	b	0xe92c <_stogir.terminal.previous-input+0xfc>
    e9f8:      	movz	x3, #0x0, lsl #48
    e9fc:      	b	0xe924 <_stogir.terminal.previous-input+0xf4>
    ea00:      	movz	x3, #0x0, lsl #48
    ea04:      	b	0xe9f4 <_stogir.terminal.previous-input+0x1c4>
    ea08:      	movz	x0, #0x0, lsl #48
    ea0c:      	uxtb	w0, w0
    ea10:      	and	x0, x0, #0x8
    ea14:      	uxtb	w0, w0
    ea18:      	cmp	x0, #0x0
    ea1c:      	cset	w0, eq
    ea20:      	uxtb	w16, w0
    ea24:      	cmp	w16, wzr
    ea28:      	cset	x0, eq
    ea2c:      	cmp	x0, #0x0
    ea30:      	b.eq	0xe8b8 <_stogir.terminal.previous-input+0x88>
    ea34:      	and	x0, x1, #0xffffffff
    ea38:      	mov	x1, x0
    ea3c:      	movz	x0, #0x0, lsl #48
    ea40:      	movz	x2, #0x0, lsl #48
    ea44:      	b	0xe8d0 <_stogir.terminal.previous-input+0xa0>
    ea48:      	brk	#0
    ea4c:      	b	0xea48 <_stogir.terminal.previous-input+0x218>

000000000000ea50 <_stogir.switch.selector-type>:
    ea50:      	sxtw	x1, w1
    ea54:      	cmp	x1, #0x0
    ea58:      	cset	w2, gt
    ea5c:      	movz	x16, #0x0, lsl #48
    ea60:      	sub	x3, x16, x1
    ea64:      	sub	x4, x3, #0x1
    ea68:      	uxtb	w16, w2
    ea6c:      	cmp	w16, wzr
    ea70:      	b.eq	0xeab4 <_stogir.switch.selector-type+0x64>
    ea74:      	ldr	x3, [x0, #0x8]
    ea78:      	cmp	x1, x3
    ea7c:      	b.ge	0xeb08 <_stogir.switch.selector-type+0xb8>
    ea80:      	add	x3, x0, #0x78
    ea84:      	ldr	x3, [x3, #0x8]
    ea88:      	cmp	x1, x3
    ea8c:      	b.ge	0xec0c <_stogir.switch.selector-type+0x1bc>
    ea90:      	lsl	x3, x1, #2
    ea94:      	ldr	x5, [x0, #0x78]
    ea98:      	add	x3, x3, x5
    ea9c:      	ldr	w3, [x3]
    eaa0:      	sxtw	x3, w3
    eaa4:      	cmp	x3, #0x0
    eaa8:      	cset	w3, ge
    eaac:      	ubfx	x3, x3, #0, #8
    eab0:      	b	0xec10 <_stogir.switch.selector-type+0x1c0>
    eab4:      	cmp	x1, #0x0
    eab8:      	b.ge	0xeb10 <_stogir.switch.selector-type+0xc0>
    eabc:      	add	x5, x0, #0x28
    eac0:      	add	x6, x0, #0x50
    eac4:      	ldr	x5, [x5, #0x8]
    eac8:      	ldr	x6, [x6, #0x8]
    eacc:      	cmp	x5, x6
    ead0:      	b.ne	0xeb00 <_stogir.switch.selector-type+0xb0>
    ead4:      	cmp	x3, x5
    ead8:      	b.gt	0xec14 <_stogir.switch.selector-type+0x1c4>
    eadc:      	lsl	x3, x4, #2
    eae0:      	ldr	x5, [x0, #0x50]
    eae4:      	add	x3, x3, x5
    eae8:      	ldr	w3, [x3]
    eaec:      	sxtw	x3, w3
    eaf0:      	cmp	x3, #0x0
    eaf4:      	cset	w3, gt
    eaf8:      	ubfx	x3, x3, #0, #8
    eafc:      	b	0xec18 <_stogir.switch.selector-type+0x1c8>
    eb00:      	movz	x3, #0x0, lsl #48
    eb04:      	b	0xeb14 <_stogir.switch.selector-type+0xc4>
    eb08:      	movz	x3, #0x0, lsl #48
    eb0c:      	b	0xeb14 <_stogir.switch.selector-type+0xc4>
    eb10:      	movz	x3, #0x0, lsl #48
    eb14:      	cmp	x3, #0x0
    eb18:      	b.eq	0xeb58 <_stogir.switch.selector-type+0x108>
    eb1c:      	uxtb	w16, w2
    eb20:      	cmp	w16, wzr
    eb24:      	b.eq	0xeb3c <_stogir.switch.selector-type+0xec>
    eb28:      	lsl	x1, x1, #4
    eb2c:      	ldr	x0, [x0]
    eb30:      	add	x0, x1, x0
    eb34:      	ldr	x0, [x0]
    eb38:      	b	0xeb4c <_stogir.switch.selector-type+0xfc>
    eb3c:      	lsl	x1, x4, #4
    eb40:      	ldr	x0, [x0, #0x28]
    eb44:      	add	x0, x1, x0
    eb48:      	ldr	x0, [x0]
    eb4c:      	mov	x1, x0
    eb50:      	mov	x0, #0x1                ; =1
    eb54:      	b	0xeb60 <_stogir.switch.selector-type+0x110>
    eb58:      	movz	x0, #0x0, lsl #48
    eb5c:      	movz	x1, #0x0, lsl #48
    eb60:      	lsr	w0, w0, #0
    eb64:      	lsr	x16, x0, #0
    eb68:      	cmp	x16, #0x1
    eb6c:      	b.eq	0xeb88 <_stogir.switch.selector-type+0x138>
    eb70:      	b.lo	0xeb78 <_stogir.switch.selector-type+0x128>
    eb74:      	b	0xeb8c <_stogir.switch.selector-type+0x13c>
    eb78:      	cmp	x16, #0x0
    eb7c:      	b.eq	0xeb84 <_stogir.switch.selector-type+0x134>
    eb80:      	b	0xeb8c <_stogir.switch.selector-type+0x13c>
    eb84:      	b	0xeb90 <_stogir.switch.selector-type+0x140>
    eb88:      	b	0xebd4 <_stogir.switch.selector-type+0x184>
    eb8c:      	b	0xec1c <_stogir.switch.selector-type+0x1cc>
    eb90:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000eb90:  ARM64_RELOC_PAGE21	l_stogir.505
    eb94:      	ldr	x16, [x16]
		000000000000eb94:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    eb98:      	orr	x0, x16, xzr
    eb9c:      	mov	x1, x0
    eba0:      	mov	x0, #0x1                ; =1
    eba4:      	mov	x2, #0x17               ; =23
    eba8:      	b	0xebc4 <_stogir.switch.selector-type+0x174>
    ebac:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000ebac:  ARM64_RELOC_PAGE21	l_stogir.506
    ebb0:      	ldr	x16, [x16]
		000000000000ebb0:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    ebb4:      	orr	x0, x16, xzr
    ebb8:      	mov	x1, x0
    ebbc:      	mov	x0, #0x1                ; =1
    ebc0:      	mov	x2, #0x20               ; =32
    ebc4:      	str	x0, [x8]
    ebc8:      	str	x1, [x8, #0x8]
    ebcc:      	str	x2, [x8, #0x10]
    ebd0:      	ret
    ebd4:      	lsr	w0, w1, #0
    ebd8:      	ubfx	x0, x0, #8, #8
    ebdc:      	cmp	x0, #0x1
    ebe0:      	b.lt	0xebac <_stogir.switch.selector-type+0x15c>
    ebe4:      	cmp	x0, #0xb
    ebe8:      	b.gt	0xebac <_stogir.switch.selector-type+0x15c>
    ebec:      	uxtb	w1, w1
    ebf0:      	cmp	x1, #0x48
    ebf4:      	b.eq	0xebac <_stogir.switch.selector-type+0x15c>
    ebf8:      	and	x0, x0, #0xffffffff
    ebfc:      	mov	x1, x0
    ec00:      	movz	x0, #0x0, lsl #48
    ec04:      	movz	x2, #0x0, lsl #48
    ec08:      	b	0xebc4 <_stogir.switch.selector-type+0x174>
    ec0c:      	movz	x3, #0x0, lsl #48
    ec10:      	b	0xeb0c <_stogir.switch.selector-type+0xbc>
    ec14:      	movz	x3, #0x0, lsl #48
    ec18:      	b	0xeb04 <_stogir.switch.selector-type+0xb4>
    ec1c:      	brk	#0
    ec20:      	b	0xec1c <_stogir.switch.selector-type+0x1cc>

000000000000ec24 <_stogir.switch.key>:
    ec24:      	sub	sp, sp, #0x30
    ec28:      	str	x19, [sp]
    ec2c:      	str	x20, [sp, #0x8]
    ec30:      	str	x21, [sp, #0x10]
    ec34:      	str	x22, [sp, #0x18]
    ec38:      	str	x23, [sp, #0x20]
    ec3c:      	sxtw	x2, w2
    ec40:      	cmp	x2, #0x1
    ec44:      	b.lt	0xecc0 <_stogir.switch.key+0x9c>
    ec48:      	cmp	x2, #0xb
    ec4c:      	cset	w3, le
    ec50:      	uxtb	w16, w3
    ec54:      	cmp	w16, wzr
    ec58:      	b.eq	0xecc0 <_stogir.switch.key+0x9c>
    ec5c:      	sxtw	x1, w1
    ec60:      	cmp	x1, #0x0
    ec64:      	cset	w4, gt
    ec68:      	movz	x16, #0x0, lsl #48
    ec6c:      	sub	x5, x16, x1
    ec70:      	sub	x6, x5, #0x1
    ec74:      	uxtb	w16, w4
    ec78:      	cmp	w16, wzr
    ec7c:      	b.eq	0xed44 <_stogir.switch.key+0x120>
    ec80:      	ldr	x5, [x0, #0x8]
    ec84:      	cmp	x1, x5
    ec88:      	b.ge	0xed90 <_stogir.switch.key+0x16c>
    ec8c:      	add	x5, x0, #0x78
    ec90:      	ldr	x5, [x5, #0x8]
    ec94:      	cmp	x1, x5
    ec98:      	b.ge	0xeefc <_stogir.switch.key+0x2d8>
    ec9c:      	lsl	x5, x1, #2
    eca0:      	ldr	x7, [x0, #0x78]
    eca4:      	add	x5, x5, x7
    eca8:      	ldr	w5, [x5]
    ecac:      	sxtw	x5, w5
    ecb0:      	cmp	x5, #0x0
    ecb4:      	cset	w5, ge
    ecb8:      	ubfx	x5, x5, #0, #8
    ecbc:      	b	0xef00 <_stogir.switch.key+0x2dc>
    ecc0:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000ecc0:  ARM64_RELOC_PAGE21	l_stogir.507
    ecc4:      	ldr	x16, [x16]
		000000000000ecc4:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    ecc8:      	orr	x0, x16, xzr
    eccc:      	mov	x1, x0
    ecd0:      	mov	x0, #0x1                ; =1
    ecd4:      	mov	x2, #0x24               ; =36
    ecd8:      	str	x0, [x8]
    ecdc:      	str	x1, [x8, #0x8]
    ece0:      	str	x2, [x8, #0x10]
    ece4:      	ldr	x19, [sp]
    ece8:      	ldr	x20, [sp, #0x8]
    ecec:      	ldr	x21, [sp, #0x10]
    ecf0:      	ldr	x22, [sp, #0x18]
    ecf4:      	ldr	x23, [sp, #0x20]
    ecf8:      	add	sp, sp, #0x30
    ecfc:      	ret
    ed00:      	mov	x23, #0x1               ; =1
    ed04:      	cmp	x1, #0x0
    ed08:      	b.ge	0xed28 <_stogir.switch.key+0x104>
    ed0c:      	lsr	w1, w4, #0
    ed10:      	uxtb	w4, w4
    ed14:      	ubfx	x1, x1, #8, #8
    ed18:      	cmp	x4, x1
    ed1c:      	b.eq	0xefa4 <_stogir.switch.key+0x380>
    ed20:      	cmp	x4, #0x49
    ed24:      	b.eq	0xefa4 <_stogir.switch.key+0x380>
    ed28:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000ed28:  ARM64_RELOC_PAGE21	l_stogir.508
    ed2c:      	ldr	x16, [x16]
		000000000000ed2c:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    ed30:      	orr	x0, x16, xzr
    ed34:      	mov	x1, x0
    ed38:      	mov	x0, #0x1                ; =1
    ed3c:      	mov	x2, #0x30               ; =48
    ed40:      	b	0xecd8 <_stogir.switch.key+0xb4>
    ed44:      	cmp	x1, #0x0
    ed48:      	b.ge	0xed98 <_stogir.switch.key+0x174>
    ed4c:      	add	x7, x0, #0x28
    ed50:      	add	x9, x0, #0x50
    ed54:      	ldr	x7, [x7, #0x8]
    ed58:      	ldr	x9, [x9, #0x8]
    ed5c:      	cmp	x7, x9
    ed60:      	b.ne	0xeef4 <_stogir.switch.key+0x2d0>
    ed64:      	cmp	x5, x7
    ed68:      	b.gt	0xef9c <_stogir.switch.key+0x378>
    ed6c:      	lsl	x5, x6, #2
    ed70:      	ldr	x7, [x0, #0x50]
    ed74:      	add	x5, x5, x7
    ed78:      	ldr	w5, [x5]
    ed7c:      	sxtw	x5, w5
    ed80:      	cmp	x5, #0x0
    ed84:      	cset	w5, gt
    ed88:      	ubfx	x5, x5, #0, #8
    ed8c:      	b	0xefa0 <_stogir.switch.key+0x37c>
    ed90:      	movz	x5, #0x0, lsl #48
    ed94:      	b	0xed9c <_stogir.switch.key+0x178>
    ed98:      	movz	x5, #0x0, lsl #48
    ed9c:      	cmp	x5, #0x0
    eda0:      	b.eq	0xee04 <_stogir.switch.key+0x1e0>
    eda4:      	uxtb	w16, w4
    eda8:      	cmp	w16, wzr
    edac:      	b.eq	0xedd4 <_stogir.switch.key+0x1b0>
    edb0:      	lsl	x4, x1, #4
    edb4:      	ldr	x0, [x0]
    edb8:      	add	x0, x4, x0
    edbc:      	ldr	x4, [x0]
    edc0:      	ldr	x0, [x0, #0x8]
    edc4:      	fmov	d31, x0
    edc8:      	mov	x0, x4
    edcc:      	fmov	x4, d31
    edd0:      	b	0xedf4 <_stogir.switch.key+0x1d0>
    edd4:      	lsl	x4, x6, #4
    edd8:      	ldr	x0, [x0, #0x28]
    eddc:      	add	x0, x4, x0
    ede0:      	ldr	x4, [x0]
    ede4:      	ldr	x0, [x0, #0x8]
    ede8:      	fmov	d31, x0
    edec:      	mov	x0, x4
    edf0:      	fmov	x4, d31
    edf4:      	mov	x5, x4
    edf8:      	mov	x4, x0
    edfc:      	mov	x0, #0x1                ; =1
    ee00:      	b	0xee10 <_stogir.switch.key+0x1ec>
    ee04:      	movz	x0, #0x0, lsl #48
    ee08:      	movz	x4, #0x0, lsl #48
    ee0c:      	movz	x5, #0x0, lsl #48
    ee10:      	lsr	w0, w0, #0
    ee14:      	lsr	x16, x0, #0
    ee18:      	cmp	x16, #0x1
    ee1c:      	b.eq	0xee38 <_stogir.switch.key+0x214>
    ee20:      	b.lo	0xee28 <_stogir.switch.key+0x204>
    ee24:      	b	0xee3c <_stogir.switch.key+0x218>
    ee28:      	cmp	x16, #0x0
    ee2c:      	b.eq	0xee34 <_stogir.switch.key+0x210>
    ee30:      	b	0xee3c <_stogir.switch.key+0x218>
    ee34:      	b	0xee40 <_stogir.switch.key+0x21c>
    ee38:      	b	0xee5c <_stogir.switch.key+0x238>
    ee3c:      	b	0xf048 <_stogir.switch.key+0x424>
    ee40:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0xc>
		000000000000ee40:  ARM64_RELOC_PAGE21	l_stogir.509
    ee44:      	ldr	x16, [x16]
		000000000000ee44:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    ee48:      	orr	x0, x16, xzr
    ee4c:      	mov	x1, x0
    ee50:      	mov	x0, #0x1                ; =1
    ee54:      	mov	x2, #0x1c               ; =28
    ee58:      	b	0xed40 <_stogir.switch.key+0x11c>
    ee5c:      	cmp	x2, #0x1
    ee60:      	cset	w0, eq
    ee64:      	cmp	x2, #0x0
    ee68:      	cset	w6, eq
    ee6c:      	cmp	x2, #0x2
    ee70:      	cset	w7, eq
    ee74:      	cmp	x2, #0x7
    ee78:      	cset	w9, eq
    ee7c:      	cmp	x2, #0x8
    ee80:      	cset	w10, eq
    ee84:      	cmp	x2, #0x3
    ee88:      	cset	w11, eq
    ee8c:      	cmp	x2, #0x9
    ee90:      	cset	w12, eq
    ee94:      	cmp	x2, #0x4
    ee98:      	cset	w13, eq
    ee9c:      	cmp	x2, #0xa
    eea0:      	cset	w14, eq
    eea4:      	cmp	x2, #0xd
    eea8:      	cset	w15, eq
    eeac:      	cmp	x2, #0x5
    eeb0:      	cset	w19, eq
    eeb4:      	cmp	x2, #0xb
    eeb8:      	cset	w20, eq
    eebc:      	cmp	x2, #0xc
    eec0:      	cset	w21, eq
    eec4:      	cmp	x2, #0x6
    eec8:      	cset	w22, eq
    eecc:      	uxtb	w16, w22
    eed0:      	cmp	w16, wzr
    eed4:      	mov	x16, #0x8               ; =8
    eed8:      	movn	x17, #0x0, lsl #48
    eedc:      	csel	x22, x16, x17, ne
    eee0:      	uxtb	w16, w6
    eee4:      	cmp	w16, wzr
    eee8:      	b.eq	0xef04 <_stogir.switch.key+0x2e0>
    eeec:      	movz	x23, #0x0, lsl #48
    eef0:      	b	0xed04 <_stogir.switch.key+0xe0>
    eef4:      	movz	x5, #0x0, lsl #48
    eef8:      	b	0xed9c <_stogir.switch.key+0x178>
    eefc:      	movz	x5, #0x0, lsl #48
    ef00:      	b	0xed94 <_stogir.switch.key+0x170>
    ef04:      	uxtb	w16, w0
    ef08:      	cmp	w16, wzr
    ef0c:      	b.ne	0xed00 <_stogir.switch.key+0xdc>
    ef10:      	uxtb	w16, w7
    ef14:      	cmp	w16, wzr
    ef18:      	b.ne	0xed00 <_stogir.switch.key+0xdc>
    ef1c:      	uxtb	w16, w9
    ef20:      	cmp	w16, wzr
    ef24:      	b.ne	0xed00 <_stogir.switch.key+0xdc>
    ef28:      	uxtb	w16, w10
    ef2c:      	cmp	w16, wzr
    ef30:      	b.ne	0xed00 <_stogir.switch.key+0xdc>
    ef34:      	uxtb	w16, w11
    ef38:      	cmp	w16, wzr
    ef3c:      	b.ne	0xf040 <_stogir.switch.key+0x41c>
    ef40:      	uxtb	w16, w12
    ef44:      	cmp	w16, wzr
    ef48:      	b.ne	0xf040 <_stogir.switch.key+0x41c>
    ef4c:      	uxtb	w16, w13
    ef50:      	cmp	w16, wzr
    ef54:      	b.ne	0xf118 <_stogir.switch.key+0x4f4>
    ef58:      	uxtb	w16, w14
    ef5c:      	cmp	w16, wzr
    ef60:      	b.ne	0xf118 <_stogir.switch.key+0x4f4>
    ef64:      	uxtb	w16, w15
    ef68:      	cmp	w16, wzr
    ef6c:      	b.ne	0xf118 <_stogir.switch.key+0x4f4>
    ef70:      	uxtb	w16, w19
    ef74:      	cmp	w16, wzr
    ef78:      	b.ne	0xf120 <_stogir.switch.key+0x4fc>
    ef7c:      	uxtb	w16, w20
    ef80:      	cmp	w16, wzr
    ef84:      	b.ne	0xf120 <_stogir.switch.key+0x4fc>
    ef88:      	uxtb	w16, w21
    ef8c:      	cmp	w16, wzr
    ef90:      	b.ne	0xf120 <_stogir.switch.key+0x4fc>
    ef94:      	mov	x23, x22
    ef98:      	b	0xf124 <_stogir.switch.key+0x500>
    ef9c:      	movz	x5, #0x0, lsl #48
    efa0:      	b	0xeef8 <_stogir.switch.key+0x2d4>
    efa4:      	cmp	x1, x2
    efa8:      	b.ne	0xed28 <_stogir.switch.key+0x104>
    efac:      	lsr	w23, w23, #0
    efb0:      	lsr	w1, w5, #0
    efb4:      	sxtw	x23, w23
    efb8:      	ubfx	x1, x1, #0, #32
    efbc:      	lsr	x4, x5, #32
    efc0:      	lsl	x5, x23, #3
    efc4:      	ubfx	x4, x4, #0, #32
    efc8:      	lsr	w5, w5, #0
    efcc:      	lsl	x4, x4, #32
    efd0:      	sxtw	x5, w5
    efd4:      	orr	x1, x4, x1
    efd8:      	cmp	x5, #0x40
    efdc:      	b.ge	0xefec <_stogir.switch.key+0x3c8>
    efe0:      	lsr	x4, x1, x5
    efe4:      	cmp	x4, #0x0
    efe8:      	b.ne	0xed28 <_stogir.switch.key+0x104>
    efec:      	uxtb	w16, w0
    eff0:      	cmp	w16, wzr
    eff4:      	b.eq	0xf000 <_stogir.switch.key+0x3dc>
    eff8:      	cmp	x1, #0x1
    effc:      	b.hi	0xed28 <_stogir.switch.key+0x104>
    f000:      	cmp	x2, #0x7
    f004:      	b.lt	0xf028 <_stogir.switch.key+0x404>
    f008:      	uxtb	w16, w3
    f00c:      	cmp	w16, wzr
    f010:      	b.eq	0xf028 <_stogir.switch.key+0x404>
    f014:      	uxtb	w16, w6
    f018:      	cmp	w16, wzr
    f01c:      	b.eq	0xf080 <_stogir.switch.key+0x45c>
    f020:      	movz	x0, #0x0, lsl #48
    f024:      	b	0xf054 <_stogir.switch.key+0x430>
    f028:      	movz	x0, #0x0, lsl #48
    f02c:      	eor	x0, x0, x1
    f030:      	mov	x1, x0
    f034:      	movz	x0, #0x0, lsl #48
    f038:      	movz	x2, #0x0, lsl #48
    f03c:      	b	0xed40 <_stogir.switch.key+0x11c>
    f040:      	mov	x23, #0x2               ; =2
    f044:      	b	0xed04 <_stogir.switch.key+0xe0>
    f048:      	brk	#0
    f04c:      	b	0xf048 <_stogir.switch.key+0x424>
    f050:      	mov	x0, #0x1                ; =1
    f054:      	lsr	w0, w0, #0
    f058:      	sxtw	x0, w0
    f05c:      	lsl	x0, x0, #3
    f060:      	lsr	w0, w0, #0
    f064:      	sxtw	x0, w0
    f068:      	sub	x0, x0, #0x1
    f06c:      	lsr	w0, w0, #0
    f070:      	sxtw	x0, w0
    f074:      	mov	x16, #0x1               ; =1
    f078:      	lsl	x0, x16, x0
    f07c:      	b	0xf02c <_stogir.switch.key+0x408>
    f080:      	uxtb	w16, w0
    f084:      	cmp	w16, wzr
    f088:      	b.ne	0xf050 <_stogir.switch.key+0x42c>
    f08c:      	uxtb	w16, w7
    f090:      	cmp	w16, wzr
    f094:      	b.ne	0xf050 <_stogir.switch.key+0x42c>
    f098:      	uxtb	w16, w9
    f09c:      	cmp	w16, wzr
    f0a0:      	b.ne	0xf050 <_stogir.switch.key+0x42c>
    f0a4:      	uxtb	w16, w10
    f0a8:      	cmp	w16, wzr
    f0ac:      	b.ne	0xf050 <_stogir.switch.key+0x42c>
    f0b0:      	uxtb	w16, w11
    f0b4:      	cmp	w16, wzr
    f0b8:      	b.ne	0xf128 <_stogir.switch.key+0x504>
    f0bc:      	uxtb	w16, w12
    f0c0:      	cmp	w16, wzr
    f0c4:      	b.ne	0xf128 <_stogir.switch.key+0x504>
    f0c8:      	uxtb	w16, w13
    f0cc:      	cmp	w16, wzr
    f0d0:      	b.ne	0xf130 <_stogir.switch.key+0x50c>
    f0d4:      	uxtb	w16, w14
    f0d8:      	cmp	w16, wzr
    f0dc:      	b.ne	0xf130 <_stogir.switch.key+0x50c>
    f0e0:      	uxtb	w16, w15
    f0e4:      	cmp	w16, wzr
    f0e8:      	b.ne	0xf130 <_stogir.switch.key+0x50c>
    f0ec:      	uxtb	w16, w19
    f0f0:      	cmp	w16, wzr
    f0f4:      	b.ne	0xf138 <_stogir.switch.key+0x514>
    f0f8:      	uxtb	w16, w20
    f0fc:      	cmp	w16, wzr
    f100:      	b.ne	0xf138 <_stogir.switch.key+0x514>
    f104:      	uxtb	w16, w21
    f108:      	cmp	w16, wzr
    f10c:      	b.ne	0xf138 <_stogir.switch.key+0x514>
    f110:      	mov	x0, x22
    f114:      	b	0xf13c <_stogir.switch.key+0x518>
    f118:      	mov	x23, #0x4               ; =4
    f11c:      	b	0xf044 <_stogir.switch.key+0x420>
    f120:      	mov	x23, #0x8               ; =8
    f124:      	b	0xf11c <_stogir.switch.key+0x4f8>
    f128:      	mov	x0, #0x2                ; =2
    f12c:      	b	0xf054 <_stogir.switch.key+0x430>
    f130:      	mov	x0, #0x4                ; =4
    f134:      	b	0xf12c <_stogir.switch.key+0x508>
    f138:      	mov	x0, #0x8                ; =8
    f13c:      	b	0xf134 <_stogir.switch.key+0x510>

000000000000f140 <_stogir.stack.entry-allocation?>:
    f140:      	sub	sp, sp, #0x10
    f144:      	add	x2, x0, #0x78
    f148:      	add	x3, x0, #0x28
    f14c:      	add	x4, x0, #0x50
    f150:      	add	x5, x0, #0x78
    f154:      	add	x6, x0, #0x28
    f158:      	add	x7, x0, #0x50
    f15c:      	sxtw	x1, w1
    f160:      	mov	x9, x1
    f164:      	mov	x1, #0x1                ; =1
    f168:      	movz	x8, #0x0, lsl #48
    f16c:      	b	0xf2bc <_stogir.stack.entry-allocation?+0x17c>
    f170:      	movz	x12, #0x0, lsl #48
    f174:      	b	0xf1ec <_stogir.stack.entry-allocation?+0xac>
    f178:      	movz	x10, #0x0, lsl #48
    f17c:      	movz	x11, #0x0, lsl #48
    f180:      	lsr	w10, w10, #0
    f184:      	lsr	x16, x10, #0
    f188:      	cmp	x16, #0x1
    f18c:      	b.eq	0xf1a8 <_stogir.stack.entry-allocation?+0x68>
    f190:      	b.lo	0xf198 <_stogir.stack.entry-allocation?+0x58>
    f194:      	b	0xf1ac <_stogir.stack.entry-allocation?+0x6c>
    f198:      	cmp	x16, #0x0
    f19c:      	b.eq	0xf1a4 <_stogir.stack.entry-allocation?+0x64>
    f1a0:      	b	0xf1ac <_stogir.stack.entry-allocation?+0x6c>
    f1a4:      	b	0xf1cc <_stogir.stack.entry-allocation?+0x8c>
    f1a8:      	b	0xf1b0 <_stogir.stack.entry-allocation?+0x70>
    f1ac:      	b	0xf508 <_stogir.stack.entry-allocation?+0x3c8>
    f1b0:      	uxtb	w10, w11
    f1b4:      	lsr	w11, w11, #0
    f1b8:      	ubfx	x11, x11, #8, #8
    f1bc:      	cmp	x10, x11
    f1c0:      	b.eq	0xf4f8 <_stogir.stack.entry-allocation?+0x3b8>
    f1c4:      	cmp	x10, #0x49
    f1c8:      	b.eq	0xf4f8 <_stogir.stack.entry-allocation?+0x3b8>
    f1cc:      	movz	x1, #0x0, lsl #48
    f1d0:      	fmov	d31, x8
    f1d4:      	mov	x8, x9
    f1d8:      	fmov	x9, d31
    f1dc:      	b	0xf3a8 <_stogir.stack.entry-allocation?+0x268>
    f1e0:      	movz	x12, #0x0, lsl #48
    f1e4:      	b	0xf1f4 <_stogir.stack.entry-allocation?+0xb4>
    f1e8:      	movz	x12, #0x0, lsl #48
    f1ec:      	b	0xf1fc <_stogir.stack.entry-allocation?+0xbc>
    f1f0:      	movz	x12, #0x0, lsl #48
    f1f4:      	b	0xf1fc <_stogir.stack.entry-allocation?+0xbc>
    f1f8:      	movz	x12, #0x0, lsl #48
    f1fc:      	cmp	x12, #0x0
    f200:      	b.eq	0xf264 <_stogir.stack.entry-allocation?+0x124>
    f204:      	uxtb	w16, w11
    f208:      	cmp	w16, wzr
    f20c:      	b.eq	0xf234 <_stogir.stack.entry-allocation?+0xf4>
    f210:      	lsl	x10, x10, #4
    f214:      	ldr	x11, [x0]
    f218:      	add	x10, x10, x11
    f21c:      	ldr	x11, [x10]
    f220:      	ldr	x10, [x10, #0x8]
    f224:      	fmov	d31, x10
    f228:      	mov	x10, x11
    f22c:      	fmov	x11, d31
    f230:      	b	0xf254 <_stogir.stack.entry-allocation?+0x114>
    f234:      	lsl	x10, x13, #4
    f238:      	ldr	x11, [x0, #0x28]
    f23c:      	add	x10, x10, x11
    f240:      	ldr	x11, [x10]
    f244:      	ldr	x10, [x10, #0x8]
    f248:      	fmov	d31, x10
    f24c:      	mov	x10, x11
    f250:      	fmov	x11, d31
    f254:      	mov	x12, x11
    f258:      	mov	x11, x10
    f25c:      	mov	x10, #0x1               ; =1
    f260:      	b	0xf270 <_stogir.stack.entry-allocation?+0x130>
    f264:      	movz	x10, #0x0, lsl #48
    f268:      	movz	x11, #0x0, lsl #48
    f26c:      	movz	x12, #0x0, lsl #48
    f270:      	lsr	w10, w10, #0
    f274:      	lsr	x16, x10, #0
    f278:      	cmp	x16, #0x1
    f27c:      	b.eq	0xf298 <_stogir.stack.entry-allocation?+0x158>
    f280:      	b.lo	0xf288 <_stogir.stack.entry-allocation?+0x148>
    f284:      	b	0xf29c <_stogir.stack.entry-allocation?+0x15c>
    f288:      	cmp	x16, #0x0
    f28c:      	b.eq	0xf294 <_stogir.stack.entry-allocation?+0x154>
    f290:      	b	0xf29c <_stogir.stack.entry-allocation?+0x15c>
    f294:      	b	0xf2a0 <_stogir.stack.entry-allocation?+0x160>
    f298:      	b	0xf374 <_stogir.stack.entry-allocation?+0x234>
    f29c:      	b	0xf454 <_stogir.stack.entry-allocation?+0x314>
    f2a0:      	fmov	d31, x8
    f2a4:      	mov	x8, x9
    f2a8:      	fmov	x9, d31
    f2ac:      	movz	x1, #0x0, lsl #48
    f2b0:      	fmov	d31, x8
    f2b4:      	mov	x8, x9
    f2b8:      	fmov	x9, d31
    f2bc:      	cmp	x1, #0x0
    f2c0:      	b.eq	0xf438 <_stogir.stack.entry-allocation?+0x2f8>
    f2c4:      	cmp	x8, #0x0
    f2c8:      	b.ne	0xf438 <_stogir.stack.entry-allocation?+0x2f8>
    f2cc:      	lsr	w10, w9, #0
    f2d0:      	sxtw	x10, w10
    f2d4:      	cmp	x10, #0x0
    f2d8:      	cset	w11, gt
    f2dc:      	movz	x16, #0x0, lsl #48
    f2e0:      	sub	x12, x16, x10
    f2e4:      	sub	x13, x12, #0x1
    f2e8:      	uxtb	w16, w11
    f2ec:      	cmp	w16, wzr
    f2f0:      	b.eq	0xf330 <_stogir.stack.entry-allocation?+0x1f0>
    f2f4:      	ldr	x12, [x0, #0x8]
    f2f8:      	cmp	x10, x12
    f2fc:      	b.ge	0xf1f0 <_stogir.stack.entry-allocation?+0xb0>
    f300:      	ldr	x12, [x2, #0x8]
    f304:      	cmp	x10, x12
    f308:      	b.ge	0xf1e0 <_stogir.stack.entry-allocation?+0xa0>
    f30c:      	lsl	x12, x10, #2
    f310:      	ldr	x14, [x0, #0x78]
    f314:      	add	x12, x12, x14
    f318:      	ldr	w12, [x12]
    f31c:      	sxtw	x12, w12
    f320:      	cmp	x12, #0x0
    f324:      	cset	w12, ge
    f328:      	ubfx	x12, x12, #0, #8
    f32c:      	b	0xf1e4 <_stogir.stack.entry-allocation?+0xa4>
    f330:      	cmp	x10, #0x0
    f334:      	b.ge	0xf1f8 <_stogir.stack.entry-allocation?+0xb8>
    f338:      	ldr	x14, [x3, #0x8]
    f33c:      	ldr	x15, [x4, #0x8]
    f340:      	cmp	x14, x15
    f344:      	b.ne	0xf1e8 <_stogir.stack.entry-allocation?+0xa8>
    f348:      	cmp	x12, x14
    f34c:      	b.gt	0xf170 <_stogir.stack.entry-allocation?+0x30>
    f350:      	lsl	x12, x13, #2
    f354:      	ldr	x14, [x0, #0x50]
    f358:      	add	x12, x12, x14
    f35c:      	ldr	w12, [x12]
    f360:      	sxtw	x12, w12
    f364:      	cmp	x12, #0x0
    f368:      	cset	w12, gt
    f36c:      	ubfx	x12, x12, #0, #8
    f370:      	b	0xf174 <_stogir.stack.entry-allocation?+0x34>
    f374:      	uxtb	w10, w11
    f378:      	asr	x13, x11, #32
    f37c:      	mov	x16, sp
    f380:      	str	x11, [x16]
    f384:      	mov	x16, sp
    f388:      	str	x12, [x16, #0x8]
    f38c:      	cmp	x10, #0x68
    f390:      	b.ne	0xf3ac <_stogir.stack.entry-allocation?+0x26c>
    f394:      	cmp	x13, #0x0
    f398:      	cset	w1, eq
    f39c:      	ubfx	x1, x1, #0, #8
    f3a0:      	mov	x8, x9
    f3a4:      	mov	x9, #0x1                ; =1
    f3a8:      	b	0xf2b0 <_stogir.stack.entry-allocation?+0x170>
    f3ac:      	cmp	x9, #0x0
    f3b0:      	b.le	0xf1cc <_stogir.stack.entry-allocation?+0x8c>
    f3b4:      	cmp	x10, #0x51
    f3b8:      	b.ne	0xf1cc <_stogir.stack.entry-allocation?+0x8c>
    f3bc:      	cmp	x13, #0x0
    f3c0:      	b.le	0xf1cc <_stogir.stack.entry-allocation?+0x8c>
    f3c4:      	cmp	x13, x9
    f3c8:      	b.ge	0xf1cc <_stogir.stack.entry-allocation?+0x8c>
    f3cc:      	lsr	w12, w12, #0
    f3d0:      	sxtw	x12, w12
    f3d4:      	cmp	x12, #0x0
    f3d8:      	b.ge	0xf1cc <_stogir.stack.entry-allocation?+0x8c>
    f3dc:      	cmp	x12, #0x0
    f3e0:      	cset	w10, gt
    f3e4:      	movz	x16, #0x0, lsl #48
    f3e8:      	sub	x11, x16, x12
    f3ec:      	sub	x13, x11, #0x1
    f3f0:      	uxtb	w16, w10
    f3f4:      	cmp	w16, wzr
    f3f8:      	b.eq	0xf4ac <_stogir.stack.entry-allocation?+0x36c>
    f3fc:      	ldr	x11, [x0, #0x8]
    f400:      	cmp	x12, x11
    f404:      	b.ge	0xf4a4 <_stogir.stack.entry-allocation?+0x364>
    f408:      	ldr	x11, [x5, #0x8]
    f40c:      	cmp	x12, x11
    f410:      	b.ge	0xf4f0 <_stogir.stack.entry-allocation?+0x3b0>
    f414:      	lsl	x11, x12, #2
    f418:      	ldr	x14, [x0, #0x78]
    f41c:      	add	x11, x11, x14
    f420:      	ldr	w11, [x11]
    f424:      	sxtw	x11, w11
    f428:      	cmp	x11, #0x0
    f42c:      	cset	w11, ge
    f430:      	ubfx	x11, x11, #0, #8
    f434:      	b	0xf4f4 <_stogir.stack.entry-allocation?+0x3b4>
    f438:      	cmp	x1, #0x0
    f43c:      	b.eq	0xf448 <_stogir.stack.entry-allocation?+0x308>
    f440:      	mov	x0, x8
    f444:      	b	0xf44c <_stogir.stack.entry-allocation?+0x30c>
    f448:      	movz	x0, #0x0, lsl #48
    f44c:      	add	sp, sp, #0x10
    f450:      	ret
    f454:      	brk	#0
    f458:      	b	0xf454 <_stogir.stack.entry-allocation?+0x314>
    f45c:      	lsl	x10, x13, #4
    f460:      	ldr	x11, [x0, #0x28]
    f464:      	add	x10, x10, x11
    f468:      	ldr	x10, [x10]
    f46c:      	mov	x11, x10
    f470:      	mov	x10, #0x1               ; =1
    f474:      	b	0xf180 <_stogir.stack.entry-allocation?+0x40>
    f478:      	movz	x11, #0x0, lsl #48
    f47c:      	cmp	x11, #0x0
    f480:      	b.eq	0xf178 <_stogir.stack.entry-allocation?+0x38>
    f484:      	uxtb	w16, w10
    f488:      	cmp	w16, wzr
    f48c:      	b.eq	0xf45c <_stogir.stack.entry-allocation?+0x31c>
    f490:      	lsl	x10, x12, #4
    f494:      	ldr	x11, [x0]
    f498:      	add	x10, x10, x11
    f49c:      	ldr	x10, [x10]
    f4a0:      	b	0xf46c <_stogir.stack.entry-allocation?+0x32c>
    f4a4:      	movz	x11, #0x0, lsl #48
    f4a8:      	b	0xf47c <_stogir.stack.entry-allocation?+0x33c>
    f4ac:      	ldr	x14, [x6, #0x8]
    f4b0:      	ldr	x15, [x7, #0x8]
    f4b4:      	cmp	x14, x15
    f4b8:      	b.ne	0xf478 <_stogir.stack.entry-allocation?+0x338>
    f4bc:      	cmp	x11, x14
    f4c0:      	b.gt	0xf4e8 <_stogir.stack.entry-allocation?+0x3a8>
    f4c4:      	lsl	x11, x13, #2
    f4c8:      	ldr	x14, [x0, #0x50]
    f4cc:      	add	x11, x11, x14
    f4d0:      	ldr	w11, [x11]
    f4d4:      	sxtw	x11, w11
    f4d8:      	cmp	x11, #0x0
    f4dc:      	cset	w11, gt
    f4e0:      	ubfx	x11, x11, #0, #8
    f4e4:      	b	0xf4ec <_stogir.stack.entry-allocation?+0x3ac>
    f4e8:      	movz	x11, #0x0, lsl #48
    f4ec:      	b	0xf47c <_stogir.stack.entry-allocation?+0x33c>
    f4f0:      	movz	x11, #0x0, lsl #48
    f4f4:      	b	0xf4a8 <_stogir.stack.entry-allocation?+0x368>
    f4f8:      	mov	x16, sp
    f4fc:      	ldr	w9, [x16, #0x4]
    f500:      	sxtw	x9, w9
    f504:      	b	0xf1d0 <_stogir.stack.entry-allocation?+0x90>
    f508:      	brk	#0
    f50c:      	b	0xf508 <_stogir.stack.entry-allocation?+0x3c8>

000000000000f510 <_stogir.stack.constant-size>:
    f510:      	sub	sp, sp, #0x10
    f514:      	str	x29, [sp]
    f518:      	str	x30, [sp, #0x8]
    f51c:      	mov	x29, sp
    f520:      	mov	x2, sp
    f524:      	sxtw	x1, w1
    f528:      	sub	sp, sp, #0x10
    f52c:      	mov	x3, sp
    f530:      	cmp	x1, #0x0
    f534:      	cset	w4, gt
    f538:      	movz	x16, #0x0, lsl #48
    f53c:      	sub	x5, x16, x1
    f540:      	sub	x6, x5, #0x1
    f544:      	uxtb	w16, w4
    f548:      	cmp	w16, wzr
    f54c:      	b.eq	0xf590 <_stogir.stack.constant-size+0x80>
    f550:      	ldr	x5, [x0, #0x8]
    f554:      	cmp	x1, x5
    f558:      	b.ge	0xf5e4 <_stogir.stack.constant-size+0xd4>
    f55c:      	add	x5, x0, #0x78
    f560:      	ldr	x5, [x5, #0x8]
    f564:      	cmp	x1, x5
    f568:      	b.ge	0xf758 <_stogir.stack.constant-size+0x248>
    f56c:      	lsl	x5, x1, #2
    f570:      	ldr	x7, [x0, #0x78]
    f574:      	add	x5, x5, x7
    f578:      	ldr	w5, [x5]
    f57c:      	sxtw	x5, w5
    f580:      	cmp	x5, #0x0
    f584:      	cset	w5, ge
    f588:      	ubfx	x5, x5, #0, #8
    f58c:      	b	0xf75c <_stogir.stack.constant-size+0x24c>
    f590:      	cmp	x1, #0x0
    f594:      	b.ge	0xf5ec <_stogir.stack.constant-size+0xdc>
    f598:      	add	x7, x0, #0x28
    f59c:      	add	x9, x0, #0x50
    f5a0:      	ldr	x7, [x7, #0x8]
    f5a4:      	ldr	x9, [x9, #0x8]
    f5a8:      	cmp	x7, x9
    f5ac:      	b.ne	0xf5dc <_stogir.stack.constant-size+0xcc>
    f5b0:      	cmp	x5, x7
    f5b4:      	b.gt	0xf7e0 <_stogir.stack.constant-size+0x2d0>
    f5b8:      	lsl	x5, x6, #2
    f5bc:      	ldr	x7, [x0, #0x50]
    f5c0:      	add	x5, x5, x7
    f5c4:      	ldr	w5, [x5]
    f5c8:      	sxtw	x5, w5
    f5cc:      	cmp	x5, #0x0
    f5d0:      	cset	w5, gt
    f5d4:      	ubfx	x5, x5, #0, #8
    f5d8:      	b	0xf7e4 <_stogir.stack.constant-size+0x2d4>
    f5dc:      	movz	x5, #0x0, lsl #48
    f5e0:      	b	0xf5f0 <_stogir.stack.constant-size+0xe0>
    f5e4:      	movz	x5, #0x0, lsl #48
    f5e8:      	b	0xf5f0 <_stogir.stack.constant-size+0xe0>
    f5ec:      	movz	x5, #0x0, lsl #48
    f5f0:      	cmp	x5, #0x0
    f5f4:      	b.eq	0xf658 <_stogir.stack.constant-size+0x148>
    f5f8:      	uxtb	w16, w4
    f5fc:      	cmp	w16, wzr
    f600:      	b.eq	0xf628 <_stogir.stack.constant-size+0x118>
    f604:      	lsl	x4, x1, #4
    f608:      	ldr	x0, [x0]
    f60c:      	add	x0, x4, x0
    f610:      	ldr	x4, [x0]
    f614:      	ldr	x0, [x0, #0x8]
    f618:      	fmov	d31, x0
    f61c:      	mov	x0, x4
    f620:      	fmov	x4, d31
    f624:      	b	0xf648 <_stogir.stack.constant-size+0x138>
    f628:      	lsl	x4, x6, #4
    f62c:      	ldr	x0, [x0, #0x28]
    f630:      	add	x0, x4, x0
    f634:      	ldr	x4, [x0]
    f638:      	ldr	x0, [x0, #0x8]
    f63c:      	fmov	d31, x0
    f640:      	mov	x0, x4
    f644:      	fmov	x4, d31
    f648:      	mov	x5, x4
    f64c:      	mov	x4, x0
    f650:      	mov	x0, #0x1                ; =1
    f654:      	b	0xf664 <_stogir.stack.constant-size+0x154>
    f658:      	movz	x0, #0x0, lsl #48
    f65c:      	movz	x4, #0x0, lsl #48
    f660:      	movz	x5, #0x0, lsl #48
    f664:      	lsr	w0, w0, #0
    f668:      	lsr	x16, x0, #0
    f66c:      	cmp	x16, #0x1
    f670:      	b.eq	0xf68c <_stogir.stack.constant-size+0x17c>
    f674:      	b.lo	0xf67c <_stogir.stack.constant-size+0x16c>
    f678:      	b	0xf690 <_stogir.stack.constant-size+0x180>
    f67c:      	cmp	x16, #0x0
    f680:      	b.eq	0xf688 <_stogir.stack.constant-size+0x178>
    f684:      	b	0xf690 <_stogir.stack.constant-size+0x180>
    f688:      	b	0xf694 <_stogir.stack.constant-size+0x184>
    f68c:      	b	0xf738 <_stogir.stack.constant-size+0x228>
    f690:      	b	0xf898 <_stogir.stack.constant-size+0x388>
    f694:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3dc>
		000000000000f694:  ARM64_RELOC_PAGE21	l_stogir.510
    f698:      	ldr	x16, [x16]
		000000000000f698:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    f69c:      	orr	x0, x16, xzr
    f6a0:      	mov	x1, x0
    f6a4:      	mov	x0, #0x1                ; =1
    f6a8:      	mov	x3, #0x18               ; =24
    f6ac:      	b	0xf714 <_stogir.stack.constant-size+0x204>
    f6b0:      	mov	x4, #0x1                ; =1
    f6b4:      	ldr	w5, [x3, #0x8]
    f6b8:      	ldr	w6, [x3, #0xc]
    f6bc:      	cmp	x1, #0x0
    f6c0:      	b.ge	0xf6fc <_stogir.stack.constant-size+0x1ec>
    f6c4:      	cmp	x0, #0x1
    f6c8:      	b.lt	0xf6fc <_stogir.stack.constant-size+0x1ec>
    f6cc:      	cmp	x0, #0xb
    f6d0:      	cset	w1, le
    f6d4:      	uxtb	w16, w1
    f6d8:      	cmp	w16, wzr
    f6dc:      	b.eq	0xf6fc <_stogir.stack.constant-size+0x1ec>
    f6e0:      	ldr	w3, [x3]
    f6e4:      	uxtb	w7, w3
    f6e8:      	ubfx	x3, x3, #8, #8
    f6ec:      	cmp	x7, x3
    f6f0:      	b.eq	0xf7e8 <_stogir.stack.constant-size+0x2d8>
    f6f4:      	cmp	x7, #0x49
    f6f8:      	b.eq	0xf7e8 <_stogir.stack.constant-size+0x2d8>
    f6fc:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3dc>
		000000000000f6fc:  ARM64_RELOC_PAGE21	l_stogir.511
    f700:      	ldr	x16, [x16]
		000000000000f700:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    f704:      	orr	x0, x16, xzr
    f708:      	mov	x1, x0
    f70c:      	mov	x0, #0x1                ; =1
    f710:      	mov	x3, #0x30               ; =48
    f714:      	mov	sp, x2
    f718:      	str	x0, [x8]
    f71c:      	str	x1, [x8, #0x8]
    f720:      	str	x3, [x8, #0x10]
    f724:      	sub	sp, x29, #0x0
    f728:      	ldr	x29, [sp]
    f72c:      	ldr	x30, [sp, #0x8]
    f730:      	add	sp, sp, #0x10
    f734:      	ret
    f738:      	lsr	w0, w4, #0
    f73c:      	str	x4, [x3]
    f740:      	str	x5, [x3, #0x8]
    f744:      	ubfx	x0, x0, #8, #8
    f748:      	cmp	x0, #0x0
    f74c:      	b.ne	0xf760 <_stogir.stack.constant-size+0x250>
    f750:      	movz	x4, #0x0, lsl #48
    f754:      	b	0xf6b4 <_stogir.stack.constant-size+0x1a4>
    f758:      	movz	x5, #0x0, lsl #48
    f75c:      	b	0xf5e8 <_stogir.stack.constant-size+0xd8>
    f760:      	cmp	x0, #0x1
    f764:      	b.eq	0xf6b0 <_stogir.stack.constant-size+0x1a0>
    f768:      	cmp	x0, #0x2
    f76c:      	b.eq	0xf6b0 <_stogir.stack.constant-size+0x1a0>
    f770:      	cmp	x0, #0x7
    f774:      	b.eq	0xf6b0 <_stogir.stack.constant-size+0x1a0>
    f778:      	cmp	x0, #0x8
    f77c:      	b.eq	0xf6b0 <_stogir.stack.constant-size+0x1a0>
    f780:      	cmp	x0, #0x3
    f784:      	b.eq	0xf890 <_stogir.stack.constant-size+0x380>
    f788:      	cmp	x0, #0x9
    f78c:      	b.eq	0xf890 <_stogir.stack.constant-size+0x380>
    f790:      	cmp	x0, #0x4
    f794:      	b.eq	0xf8a0 <_stogir.stack.constant-size+0x390>
    f798:      	cmp	x0, #0xa
    f79c:      	b.eq	0xf8a0 <_stogir.stack.constant-size+0x390>
    f7a0:      	cmp	x0, #0xd
    f7a4:      	b.eq	0xf8a0 <_stogir.stack.constant-size+0x390>
    f7a8:      	cmp	x0, #0x5
    f7ac:      	b.eq	0xf8a8 <_stogir.stack.constant-size+0x398>
    f7b0:      	cmp	x0, #0xb
    f7b4:      	b.eq	0xf8a8 <_stogir.stack.constant-size+0x398>
    f7b8:      	cmp	x0, #0xc
    f7bc:      	b.eq	0xf8a8 <_stogir.stack.constant-size+0x398>
    f7c0:      	cmp	x0, #0x6
    f7c4:      	cset	w4, eq
    f7c8:      	uxtb	w16, w4
    f7cc:      	cmp	w16, wzr
    f7d0:      	mov	x16, #0x8               ; =8
    f7d4:      	movn	x17, #0x0, lsl #48
    f7d8:      	csel	x4, x16, x17, ne
    f7dc:      	b	0xf8ac <_stogir.stack.constant-size+0x39c>
    f7e0:      	movz	x5, #0x0, lsl #48
    f7e4:      	b	0xf5e0 <_stogir.stack.constant-size+0xd0>
    f7e8:      	lsr	w4, w4, #0
    f7ec:      	sxtw	x4, w4
    f7f0:      	cmp	x4, #0x0
    f7f4:      	b.le	0xf6fc <_stogir.stack.constant-size+0x1ec>
    f7f8:      	ubfx	x5, x5, #0, #32
    f7fc:      	ubfx	x6, x6, #0, #32
    f800:      	lsl	x3, x6, #32
    f804:      	orr	x3, x3, x5
    f808:      	cmp	x4, #0x8
    f80c:      	b.ge	0xf828 <_stogir.stack.constant-size+0x318>
    f810:      	lsl	x5, x4, #3
    f814:      	lsr	w5, w5, #0
    f818:      	sxtw	x5, w5
    f81c:      	lsr	x5, x3, x5
    f820:      	cmp	x5, #0x0
    f824:      	b.ne	0xf6fc <_stogir.stack.constant-size+0x1ec>
    f828:      	cmp	x0, #0x7
    f82c:      	b.lt	0xf868 <_stogir.stack.constant-size+0x358>
    f830:      	uxtb	w16, w1
    f834:      	cmp	w16, wzr
    f838:      	b.eq	0xf868 <_stogir.stack.constant-size+0x358>
    f83c:      	lsl	x0, x4, #3
    f840:      	lsr	w0, w0, #0
    f844:      	sxtw	x0, w0
    f848:      	sub	x0, x0, #0x1
    f84c:      	lsr	w0, w0, #0
    f850:      	sxtw	x0, w0
    f854:      	mov	x16, #0x1               ; =1
    f858:      	lsl	x0, x16, x0
    f85c:      	and	x0, x0, x3
    f860:      	cmp	x0, #0x0
    f864:      	b.ne	0xf6fc <_stogir.stack.constant-size+0x1ec>
    f868:      	mov	x17, #-0x10             ; =-16
    f86c:      	movk	x17, #0x7fff, lsl #48
    f870:      	cmp	x3, x17
    f874:      	b.hi	0xf6fc <_stogir.stack.constant-size+0x1ec>
    f878:      	add	x0, x3, #0xf
    f87c:      	and	x0, x0, #0xfffffffffffffff0
    f880:      	mov	x1, x0
    f884:      	movz	x0, #0x0, lsl #48
    f888:      	movz	x3, #0x0, lsl #48
    f88c:      	b	0xf714 <_stogir.stack.constant-size+0x204>
    f890:      	mov	x4, #0x2                ; =2
    f894:      	b	0xf6b4 <_stogir.stack.constant-size+0x1a4>
    f898:      	brk	#0
    f89c:      	b	0xf898 <_stogir.stack.constant-size+0x388>
    f8a0:      	mov	x4, #0x4                ; =4
    f8a4:      	b	0xf894 <_stogir.stack.constant-size+0x384>
    f8a8:      	mov	x4, #0x8                ; =8
    f8ac:      	b	0xf8a4 <_stogir.stack.constant-size+0x394>

000000000000f8b0 <_stogir.frame.valid-alignment?>:
    f8b0:      	cmp	x0, #0x0
    f8b4:      	b.le	0xf8d0 <_stogir.frame.valid-alignment?+0x20>
    f8b8:      	sub	x1, x0, #0x1
    f8bc:      	and	x0, x1, x0
    f8c0:      	cmp	x0, #0x0
    f8c4:      	cset	w0, eq
    f8c8:      	ubfx	x0, x0, #0, #8
    f8cc:      	b	0xf8d4 <_stogir.frame.valid-alignment?+0x24>
    f8d0:      	movz	x0, #0x0, lsl #48
    f8d4:      	ret

000000000000f8d8 <_stogir.stack.constant-size-aligned>:
    f8d8:      	sub	sp, sp, #0x10
    f8dc:      	cmp	x2, #0x10
    f8e0:      	b.lt	0xf960 <_stogir.stack.constant-size-aligned+0x88>
    f8e4:      	cmp	x2, #0x0
    f8e8:      	b.le	0xf960 <_stogir.stack.constant-size-aligned+0x88>
    f8ec:      	sub	x3, x2, #0x1
    f8f0:      	and	x3, x3, x2
    f8f4:      	cmp	x3, #0x0
    f8f8:      	b.ne	0xf960 <_stogir.stack.constant-size-aligned+0x88>
    f8fc:      	sxtw	x1, w1
    f900:      	cmp	x1, #0x0
    f904:      	cset	w3, gt
    f908:      	movz	x16, #0x0, lsl #48
    f90c:      	sub	x4, x16, x1
    f910:      	sub	x5, x4, #0x1
    f914:      	uxtb	w16, w3
    f918:      	cmp	w16, wzr
    f91c:      	b.eq	0xfa00 <_stogir.stack.constant-size-aligned+0x128>
    f920:      	ldr	x4, [x0, #0x8]
    f924:      	cmp	x1, x4
    f928:      	b.ge	0xfa4c <_stogir.stack.constant-size-aligned+0x174>
    f92c:      	add	x4, x0, #0x78
    f930:      	ldr	x4, [x4, #0x8]
    f934:      	cmp	x1, x4
    f938:      	b.ge	0xfb48 <_stogir.stack.constant-size-aligned+0x270>
    f93c:      	lsl	x4, x1, #2
    f940:      	ldr	x6, [x0, #0x78]
    f944:      	add	x4, x4, x6
    f948:      	ldr	w4, [x4]
    f94c:      	sxtw	x4, w4
    f950:      	cmp	x4, #0x0
    f954:      	cset	w4, ge
    f958:      	ubfx	x4, x4, #0, #8
    f95c:      	b	0xfb4c <_stogir.stack.constant-size-aligned+0x274>
    f960:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3dc>
		000000000000f960:  ARM64_RELOC_PAGE21	l_stogir.512
    f964:      	ldr	x16, [x16]
		000000000000f964:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    f968:      	orr	x0, x16, xzr
    f96c:      	mov	x1, x0
    f970:      	mov	x0, #0x1                ; =1
    f974:      	mov	x2, #0x20               ; =32
    f978:      	str	x0, [x8]
    f97c:      	str	x1, [x8, #0x8]
    f980:      	str	x2, [x8, #0x10]
    f984:      	add	sp, sp, #0x10
    f988:      	ret
    f98c:      	mov	x3, #0x1                ; =1
    f990:      	mov	x16, sp
    f994:      	ldr	w4, [x16, #0x8]
    f998:      	mov	x16, sp
    f99c:      	ldr	w5, [x16, #0xc]
    f9a0:      	cmp	x1, #0x0
    f9a4:      	b.ge	0xf9e4 <_stogir.stack.constant-size-aligned+0x10c>
    f9a8:      	cmp	x0, #0x1
    f9ac:      	b.lt	0xf9e4 <_stogir.stack.constant-size-aligned+0x10c>
    f9b0:      	cmp	x0, #0xb
    f9b4:      	cset	w1, le
    f9b8:      	uxtb	w16, w1
    f9bc:      	cmp	w16, wzr
    f9c0:      	b.eq	0xf9e4 <_stogir.stack.constant-size-aligned+0x10c>
    f9c4:      	mov	x16, sp
    f9c8:      	ldr	w6, [x16]
    f9cc:      	uxtb	w7, w6
    f9d0:      	ubfx	x6, x6, #8, #8
    f9d4:      	cmp	x7, x6
    f9d8:      	b.eq	0xfbd8 <_stogir.stack.constant-size-aligned+0x300>
    f9dc:      	cmp	x7, #0x49
    f9e0:      	b.eq	0xfbd8 <_stogir.stack.constant-size-aligned+0x300>
    f9e4:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3dc>
		000000000000f9e4:  ARM64_RELOC_PAGE21	l_stogir.513
    f9e8:      	ldr	x16, [x16]
		000000000000f9e8:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    f9ec:      	orr	x0, x16, xzr
    f9f0:      	mov	x1, x0
    f9f4:      	mov	x0, #0x1                ; =1
    f9f8:      	mov	x2, #0x30               ; =48
    f9fc:      	b	0xf978 <_stogir.stack.constant-size-aligned+0xa0>
    fa00:      	cmp	x1, #0x0
    fa04:      	b.ge	0xfa54 <_stogir.stack.constant-size-aligned+0x17c>
    fa08:      	add	x6, x0, #0x28
    fa0c:      	add	x7, x0, #0x50
    fa10:      	ldr	x6, [x6, #0x8]
    fa14:      	ldr	x7, [x7, #0x8]
    fa18:      	cmp	x6, x7
    fa1c:      	b.ne	0xfb40 <_stogir.stack.constant-size-aligned+0x268>
    fa20:      	cmp	x4, x6
    fa24:      	b.gt	0xfbd0 <_stogir.stack.constant-size-aligned+0x2f8>
    fa28:      	lsl	x4, x5, #2
    fa2c:      	ldr	x6, [x0, #0x50]
    fa30:      	add	x4, x4, x6
    fa34:      	ldr	w4, [x4]
    fa38:      	sxtw	x4, w4
    fa3c:      	cmp	x4, #0x0
    fa40:      	cset	w4, gt
    fa44:      	ubfx	x4, x4, #0, #8
    fa48:      	b	0xfbd4 <_stogir.stack.constant-size-aligned+0x2fc>
    fa4c:      	movz	x4, #0x0, lsl #48
    fa50:      	b	0xfa58 <_stogir.stack.constant-size-aligned+0x180>
    fa54:      	movz	x4, #0x0, lsl #48
    fa58:      	cmp	x4, #0x0
    fa5c:      	b.eq	0xfac0 <_stogir.stack.constant-size-aligned+0x1e8>
    fa60:      	uxtb	w16, w3
    fa64:      	cmp	w16, wzr
    fa68:      	b.eq	0xfa90 <_stogir.stack.constant-size-aligned+0x1b8>
    fa6c:      	lsl	x3, x1, #4
    fa70:      	ldr	x0, [x0]
    fa74:      	add	x0, x3, x0
    fa78:      	ldr	x3, [x0]
    fa7c:      	ldr	x0, [x0, #0x8]
    fa80:      	fmov	d31, x0
    fa84:      	mov	x0, x3
    fa88:      	fmov	x3, d31
    fa8c:      	b	0xfab0 <_stogir.stack.constant-size-aligned+0x1d8>
    fa90:      	lsl	x3, x5, #4
    fa94:      	ldr	x0, [x0, #0x28]
    fa98:      	add	x0, x3, x0
    fa9c:      	ldr	x3, [x0]
    faa0:      	ldr	x0, [x0, #0x8]
    faa4:      	fmov	d31, x0
    faa8:      	mov	x0, x3
    faac:      	fmov	x3, d31
    fab0:      	mov	x4, x3
    fab4:      	mov	x3, x0
    fab8:      	mov	x0, #0x1                ; =1
    fabc:      	b	0xfacc <_stogir.stack.constant-size-aligned+0x1f4>
    fac0:      	movz	x0, #0x0, lsl #48
    fac4:      	movz	x3, #0x0, lsl #48
    fac8:      	movz	x4, #0x0, lsl #48
    facc:      	lsr	w0, w0, #0
    fad0:      	lsr	x16, x0, #0
    fad4:      	cmp	x16, #0x1
    fad8:      	b.eq	0xfaf4 <_stogir.stack.constant-size-aligned+0x21c>
    fadc:      	b.lo	0xfae4 <_stogir.stack.constant-size-aligned+0x20c>
    fae0:      	b	0xfaf8 <_stogir.stack.constant-size-aligned+0x220>
    fae4:      	cmp	x16, #0x0
    fae8:      	b.eq	0xfaf0 <_stogir.stack.constant-size-aligned+0x218>
    faec:      	b	0xfaf8 <_stogir.stack.constant-size-aligned+0x220>
    faf0:      	b	0xfafc <_stogir.stack.constant-size-aligned+0x224>
    faf4:      	b	0xfb18 <_stogir.stack.constant-size-aligned+0x240>
    faf8:      	b	0xfc98 <_stogir.stack.constant-size-aligned+0x3c0>
    fafc:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3dc>
		000000000000fafc:  ARM64_RELOC_PAGE21	l_stogir.514
    fb00:      	ldr	x16, [x16]
		000000000000fb00:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    fb04:      	orr	x0, x16, xzr
    fb08:      	mov	x1, x0
    fb0c:      	mov	x0, #0x1                ; =1
    fb10:      	mov	x2, #0x18               ; =24
    fb14:      	b	0xf9fc <_stogir.stack.constant-size-aligned+0x124>
    fb18:      	lsr	w0, w3, #0
    fb1c:      	mov	x16, sp
    fb20:      	str	x3, [x16]
    fb24:      	mov	x16, sp
    fb28:      	str	x4, [x16, #0x8]
    fb2c:      	ubfx	x0, x0, #8, #8
    fb30:      	cmp	x0, #0x0
    fb34:      	b.ne	0xfb50 <_stogir.stack.constant-size-aligned+0x278>
    fb38:      	movz	x3, #0x0, lsl #48
    fb3c:      	b	0xf990 <_stogir.stack.constant-size-aligned+0xb8>
    fb40:      	movz	x4, #0x0, lsl #48
    fb44:      	b	0xfa58 <_stogir.stack.constant-size-aligned+0x180>
    fb48:      	movz	x4, #0x0, lsl #48
    fb4c:      	b	0xfa50 <_stogir.stack.constant-size-aligned+0x178>
    fb50:      	cmp	x0, #0x1
    fb54:      	b.eq	0xf98c <_stogir.stack.constant-size-aligned+0xb4>
    fb58:      	cmp	x0, #0x2
    fb5c:      	b.eq	0xf98c <_stogir.stack.constant-size-aligned+0xb4>
    fb60:      	cmp	x0, #0x7
    fb64:      	b.eq	0xf98c <_stogir.stack.constant-size-aligned+0xb4>
    fb68:      	cmp	x0, #0x8
    fb6c:      	b.eq	0xf98c <_stogir.stack.constant-size-aligned+0xb4>
    fb70:      	cmp	x0, #0x3
    fb74:      	b.eq	0xfc90 <_stogir.stack.constant-size-aligned+0x3b8>
    fb78:      	cmp	x0, #0x9
    fb7c:      	b.eq	0xfc90 <_stogir.stack.constant-size-aligned+0x3b8>
    fb80:      	cmp	x0, #0x4
    fb84:      	b.eq	0xfca0 <_stogir.stack.constant-size-aligned+0x3c8>
    fb88:      	cmp	x0, #0xa
    fb8c:      	b.eq	0xfca0 <_stogir.stack.constant-size-aligned+0x3c8>
    fb90:      	cmp	x0, #0xd
    fb94:      	b.eq	0xfca0 <_stogir.stack.constant-size-aligned+0x3c8>
    fb98:      	cmp	x0, #0x5
    fb9c:      	b.eq	0xfca8 <_stogir.stack.constant-size-aligned+0x3d0>
    fba0:      	cmp	x0, #0xb
    fba4:      	b.eq	0xfca8 <_stogir.stack.constant-size-aligned+0x3d0>
    fba8:      	cmp	x0, #0xc
    fbac:      	b.eq	0xfca8 <_stogir.stack.constant-size-aligned+0x3d0>
    fbb0:      	cmp	x0, #0x6
    fbb4:      	cset	w3, eq
    fbb8:      	uxtb	w16, w3
    fbbc:      	cmp	w16, wzr
    fbc0:      	mov	x16, #0x8               ; =8
    fbc4:      	movn	x17, #0x0, lsl #48
    fbc8:      	csel	x3, x16, x17, ne
    fbcc:      	b	0xfcac <_stogir.stack.constant-size-aligned+0x3d4>
    fbd0:      	movz	x4, #0x0, lsl #48
    fbd4:      	b	0xfb44 <_stogir.stack.constant-size-aligned+0x26c>
    fbd8:      	lsr	w3, w3, #0
    fbdc:      	sxtw	x3, w3
    fbe0:      	cmp	x3, #0x0
    fbe4:      	b.le	0xf9e4 <_stogir.stack.constant-size-aligned+0x10c>
    fbe8:      	ubfx	x4, x4, #0, #32
    fbec:      	ubfx	x5, x5, #0, #32
    fbf0:      	lsl	x5, x5, #32
    fbf4:      	orr	x4, x5, x4
    fbf8:      	cmp	x3, #0x8
    fbfc:      	b.ge	0xfc18 <_stogir.stack.constant-size-aligned+0x340>
    fc00:      	lsl	x5, x3, #3
    fc04:      	lsr	w5, w5, #0
    fc08:      	sxtw	x5, w5
    fc0c:      	lsr	x5, x4, x5
    fc10:      	cmp	x5, #0x0
    fc14:      	b.ne	0xf9e4 <_stogir.stack.constant-size-aligned+0x10c>
    fc18:      	cmp	x0, #0x7
    fc1c:      	b.lt	0xfc58 <_stogir.stack.constant-size-aligned+0x380>
    fc20:      	uxtb	w16, w1
    fc24:      	cmp	w16, wzr
    fc28:      	b.eq	0xfc58 <_stogir.stack.constant-size-aligned+0x380>
    fc2c:      	lsl	x0, x3, #3
    fc30:      	lsr	w0, w0, #0
    fc34:      	sxtw	x0, w0
    fc38:      	sub	x0, x0, #0x1
    fc3c:      	lsr	w0, w0, #0
    fc40:      	sxtw	x0, w0
    fc44:      	mov	x16, #0x1               ; =1
    fc48:      	lsl	x0, x16, x0
    fc4c:      	and	x0, x0, x4
    fc50:      	cmp	x0, #0x0
    fc54:      	b.ne	0xf9e4 <_stogir.stack.constant-size-aligned+0x10c>
    fc58:      	sub	x0, x2, #0x1
    fc5c:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    fc60:      	sub	x0, x16, x0
    fc64:      	cmp	x4, x0
    fc68:      	b.hi	0xf9e4 <_stogir.stack.constant-size-aligned+0x10c>
    fc6c:      	sub	x0, x2, #0x1
    fc70:      	movz	x16, #0x0, lsl #48
    fc74:      	sub	x1, x16, x2
    fc78:      	add	x0, x0, x4
    fc7c:      	and	x0, x1, x0
    fc80:      	mov	x1, x0
    fc84:      	movz	x0, #0x0, lsl #48
    fc88:      	movz	x2, #0x0, lsl #48
    fc8c:      	b	0xf9fc <_stogir.stack.constant-size-aligned+0x124>
    fc90:      	mov	x3, #0x2                ; =2
    fc94:      	b	0xf990 <_stogir.stack.constant-size-aligned+0xb8>
    fc98:      	brk	#0
    fc9c:      	b	0xfc98 <_stogir.stack.constant-size-aligned+0x3c0>
    fca0:      	mov	x3, #0x4                ; =4
    fca4:      	b	0xfc94 <_stogir.stack.constant-size-aligned+0x3bc>
    fca8:      	mov	x3, #0x8                ; =8
    fcac:      	b	0xfca4 <_stogir.stack.constant-size-aligned+0x3cc>

000000000000fcb0 <_stogir.numeric-conversion.operation?>:
    fcb0:      	sxtw	x0, w0
    fcb4:      	cmp	x0, #0x25
    fcb8:      	b.lt	0xfccc <_stogir.numeric-conversion.operation?+0x1c>
    fcbc:      	cmp	x0, #0x27
    fcc0:      	cset	w0, le
    fcc4:      	ubfx	x0, x0, #0, #8
    fcc8:      	b	0xfcd0 <_stogir.numeric-conversion.operation?+0x20>
    fccc:      	movz	x0, #0x0, lsl #48
    fcd0:      	ret

000000000000fcd4 <_stogir.numeric-conversion.valid-types?>:
    fcd4:      	sxtw	x0, w0
    fcd8:      	sxtw	x1, w1
    fcdc:      	sxtw	x2, w2
    fce0:      	cmp	x2, #0xc
    fce4:      	cset	w3, eq
    fce8:      	cmp	x2, #0xd
    fcec:      	cset	w4, eq
    fcf0:      	ubfx	x4, x4, #0, #8
    fcf4:      	cmp	x0, #0x25
    fcf8:      	b.ne	0xfd20 <_stogir.numeric-conversion.valid-types?+0x4c>
    fcfc:      	cmp	x1, #0x1
    fd00:      	b.lt	0xfd88 <_stogir.numeric-conversion.valid-types?+0xb4>
    fd04:      	cmp	x1, #0xb
    fd08:      	b.gt	0xfd88 <_stogir.numeric-conversion.valid-types?+0xb4>
    fd0c:      	uxtb	w16, w3
    fd10:      	cmp	w16, wzr
    fd14:      	b.eq	0xfd98 <_stogir.numeric-conversion.valid-types?+0xc4>
    fd18:      	mov	x0, #0x1                ; =1
    fd1c:      	b	0xfd9c <_stogir.numeric-conversion.valid-types?+0xc8>
    fd20:      	cmp	x1, #0xc
    fd24:      	cset	w5, eq
    fd28:      	cmp	x1, #0xd
    fd2c:      	cset	w1, eq
    fd30:      	cmp	x0, #0x26
    fd34:      	b.ne	0xfd58 <_stogir.numeric-conversion.valid-types?+0x84>
    fd38:      	uxtb	w16, w5
    fd3c:      	cmp	w16, wzr
    fd40:      	b.ne	0xfda8 <_stogir.numeric-conversion.valid-types?+0xd4>
    fd44:      	uxtb	w16, w1
    fd48:      	cmp	w16, wzr
    fd4c:      	b.ne	0xfda8 <_stogir.numeric-conversion.valid-types?+0xd4>
    fd50:      	movz	x0, #0x0, lsl #48
    fd54:      	b	0xfd84 <_stogir.numeric-conversion.valid-types?+0xb0>
    fd58:      	cmp	x0, #0x27
    fd5c:      	b.ne	0xfd90 <_stogir.numeric-conversion.valid-types?+0xbc>
    fd60:      	uxtb	w16, w5
    fd64:      	cmp	w16, wzr
    fd68:      	b.ne	0xfdc0 <_stogir.numeric-conversion.valid-types?+0xec>
    fd6c:      	uxtb	w16, w1
    fd70:      	cmp	w16, wzr
    fd74:      	b.ne	0xfdc0 <_stogir.numeric-conversion.valid-types?+0xec>
    fd78:      	movz	x0, #0x0, lsl #48
    fd7c:      	b	0xfda4 <_stogir.numeric-conversion.valid-types?+0xd0>
    fd80:      	movz	x0, #0x0, lsl #48
    fd84:      	b	0xfd94 <_stogir.numeric-conversion.valid-types?+0xc0>
    fd88:      	movz	x0, #0x0, lsl #48
    fd8c:      	b	0xfd94 <_stogir.numeric-conversion.valid-types?+0xc0>
    fd90:      	movz	x0, #0x0, lsl #48
    fd94:      	ret
    fd98:      	mov	x0, x4
    fd9c:      	b	0xfd8c <_stogir.numeric-conversion.valid-types?+0xb8>
    fda0:      	mov	x0, x4
    fda4:      	b	0xfd94 <_stogir.numeric-conversion.valid-types?+0xc0>
    fda8:      	cmp	x2, #0x1
    fdac:      	b.lt	0xfd80 <_stogir.numeric-conversion.valid-types?+0xac>
    fdb0:      	cmp	x2, #0xb
    fdb4:      	cset	w0, le
    fdb8:      	ubfx	x0, x0, #0, #8
    fdbc:      	b	0xfd84 <_stogir.numeric-conversion.valid-types?+0xb0>
    fdc0:      	uxtb	w16, w3
    fdc4:      	cmp	w16, wzr
    fdc8:      	b.eq	0xfda0 <_stogir.numeric-conversion.valid-types?+0xcc>
    fdcc:      	mov	x0, #0x1                ; =1
    fdd0:      	b	0xfda4 <_stogir.numeric-conversion.valid-types?+0xd0>

000000000000fdd4 <_inherent$slice$new__stogir.node.Node>:
    fdd4:      	sub	sp, sp, #0x10
    fdd8:      	mov	x2, sp
    fddc:      	str	x0, [x2]
    fde0:      	str	x1, [x2, #0x8]
    fde4:      	ldr	x0, [sp]
    fde8:      	ldr	x1, [sp, #0x8]
    fdec:      	add	sp, sp, #0x10
    fdf0:      	ret

000000000000fdf4 <_inherent$slice$data__stogir.node.Node>:
    fdf4:      	ret

000000000000fdf8 <_coil.slice.element-ref__stogir.node.Node>:
    fdf8:      	ret

000000000000fdfc <_stogir.vector-lanes.ordinary?>:
    fdfc:      	ldr	w0, [x0]
    fe00:      	uxtb	w0, w0
    fe04:      	cmp	x0, #0x48
    fe08:      	b.ne	0xfe14 <_stogir.vector-lanes.ordinary?+0x18>
    fe0c:      	movz	x0, #0x0, lsl #48
    fe10:      	b	0xfe28 <_stogir.vector-lanes.ordinary?+0x2c>
    fe14:      	cmp	x0, #0x46
    fe18:      	cset	w0, eq
    fe1c:      	uxtb	w16, w0
    fe20:      	cmp	w16, wzr
    fe24:      	cset	x0, eq
    fe28:      	ret

000000000000fe2c <_stogir.vector-lanes.compatible?>:
    fe2c:      	sub	sp, sp, #0x30
    fe30:      	str	x29, [sp]
    fe34:      	str	x30, [sp, #0x8]
    fe38:      	mov	x29, sp
    fe3c:      	str	x19, [sp, #0x10]
    fe40:      	str	x20, [sp, #0x18]
    fe44:      	str	x21, [sp, #0x20]
    fe48:      	lsr	w3, w0, #0
    fe4c:      	sxtw	x19, w0
    fe50:      	mov	w0, w3
    fe54:      	mov	w20, w1
    fe58:      	mov	w21, w2
    fe5c:      	bl	0xfe5c <_stogir.vector-lanes.compatible?+0x30>
		000000000000fe5c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    fe60:      	and	x1, x19, #0xf
    fe64:      	lsr	w1, w1, #0
    fe68:      	sxtw	x1, w1
    fe6c:      	cmp	x0, #0x0
    fe70:      	b.eq	0xfe7c <_stogir.vector-lanes.compatible?+0x50>
    fe74:      	mov	x0, x1
    fe78:      	b	0xfe80 <_stogir.vector-lanes.compatible?+0x54>
    fe7c:      	movn	x0, #0x0, lsl #48
    fe80:      	cmp	x19, #0xf
    fe84:      	b.le	0xfed4 <_stogir.vector-lanes.compatible?+0xa8>
    fe88:      	cmp	x19, #0x80
    fe8c:      	b.ge	0xfed4 <_stogir.vector-lanes.compatible?+0xa8>
    fe90:      	cmp	x1, #0x1
    fe94:      	b.lt	0xfed4 <_stogir.vector-lanes.compatible?+0xa8>
    fe98:      	cmp	x1, #0xd
    fe9c:      	b.gt	0xfed4 <_stogir.vector-lanes.compatible?+0xa8>
    fea0:      	sxtw	x21, w21
    fea4:      	cmp	x21, #0x4
    fea8:      	cset	w1, eq
    feac:      	cmp	x21, #0x8
    feb0:      	cset	w2, eq
    feb4:      	uxtb	w16, w1
    feb8:      	cmp	w16, wzr
    febc:      	b.ne	0xfefc <_stogir.vector-lanes.compatible?+0xd0>
    fec0:      	uxtb	w16, w2
    fec4:      	cmp	w16, wzr
    fec8:      	b.ne	0xfefc <_stogir.vector-lanes.compatible?+0xd0>
    fecc:      	movz	x0, #0x0, lsl #48
    fed0:      	b	0xfef8 <_stogir.vector-lanes.compatible?+0xcc>
    fed4:      	movz	x0, #0x0, lsl #48
    fed8:      	ldr	x19, [sp, #0x10]
    fedc:      	ldr	x20, [sp, #0x18]
    fee0:      	ldr	x21, [sp, #0x20]
    fee4:      	ldr	x29, [sp]
    fee8:      	ldr	x30, [sp, #0x8]
    feec:      	add	sp, sp, #0x30
    fef0:      	ret
    fef4:      	movz	x0, #0x0, lsl #48
    fef8:      	b	0xfed8 <_stogir.vector-lanes.compatible?+0xac>
    fefc:      	sxtw	x20, w20
    ff00:      	cmp	x20, #0x0
    ff04:      	b.lt	0xfef4 <_stogir.vector-lanes.compatible?+0xc8>
    ff08:      	cmp	x20, #0xd
    ff0c:      	b.gt	0xfef4 <_stogir.vector-lanes.compatible?+0xc8>
    ff10:      	cmp	x20, #0x0
    ff14:      	b.le	0xff30 <_stogir.vector-lanes.compatible?+0x104>
    ff18:      	lsr	w0, w0, #0
    ff1c:      	sxtw	x0, w0
    ff20:      	cmp	x0, x20
    ff24:      	b.ne	0xff38 <_stogir.vector-lanes.compatible?+0x10c>
    ff28:      	mov	x0, #0x1                ; =1
    ff2c:      	b	0xff34 <_stogir.vector-lanes.compatible?+0x108>
    ff30:      	movz	x0, #0x0, lsl #48
    ff34:      	b	0xfef8 <_stogir.vector-lanes.compatible?+0xcc>
    ff38:      	cmp	x0, #0x1
    ff3c:      	b.lt	0xff78 <_stogir.vector-lanes.compatible?+0x14c>
    ff40:      	cmp	x0, #0xb
    ff44:      	b.gt	0xff78 <_stogir.vector-lanes.compatible?+0x14c>
    ff48:      	cmp	x20, #0x1
    ff4c:      	b.lt	0xff80 <_stogir.vector-lanes.compatible?+0x154>
    ff50:      	cmp	x20, #0xb
    ff54:      	b.gt	0xff80 <_stogir.vector-lanes.compatible?+0x154>
    ff58:      	uxtb	w16, w1
    ff5c:      	cmp	w16, wzr
    ff60:      	b.ne	0xffac <_stogir.vector-lanes.compatible?+0x180>
    ff64:      	uxtb	w16, w2
    ff68:      	cmp	w16, wzr
    ff6c:      	b.ne	0xffac <_stogir.vector-lanes.compatible?+0x180>
    ff70:      	movn	x0, #0x0, lsl #48
    ff74:      	b	0xffc0 <_stogir.vector-lanes.compatible?+0x194>
    ff78:      	movz	x0, #0x0, lsl #48
    ff7c:      	b	0xff2c <_stogir.vector-lanes.compatible?+0x100>
    ff80:      	movz	x0, #0x0, lsl #48
    ff84:      	b	0xff7c <_stogir.vector-lanes.compatible?+0x150>
    ff88:      	mov	x1, #0x1                ; =1
    ff8c:      	lsr	w0, w0, #0
    ff90:      	sxtw	x0, w0
    ff94:      	lsr	w1, w1, #0
    ff98:      	sxtw	x1, w1
    ff9c:      	cmp	x0, x1
    ffa0:      	cset	w0, eq
    ffa4:      	ubfx	x0, x0, #0, #8
    ffa8:      	b	0xff84 <_stogir.vector-lanes.compatible?+0x158>
    ffac:      	cmp	x0, #0x0
    ffb0:      	b.ne	0x10060 <_stogir.vector-lanes.compatible?+0x234>
    ffb4:      	movz	x0, #0x0, lsl #48
    ffb8:      	b	0xffc0 <_stogir.vector-lanes.compatible?+0x194>
    ffbc:      	mov	x0, #0x1                ; =1
    ffc0:      	uxtb	w16, w1
    ffc4:      	cmp	w16, wzr
    ffc8:      	b.ne	0xffe0 <_stogir.vector-lanes.compatible?+0x1b4>
    ffcc:      	uxtb	w16, w2
    ffd0:      	cmp	w16, wzr
    ffd4:      	b.ne	0xffe0 <_stogir.vector-lanes.compatible?+0x1b4>
    ffd8:      	movn	x1, #0x0, lsl #48
    ffdc:      	b	0xff8c <_stogir.vector-lanes.compatible?+0x160>
    ffe0:      	cmp	x20, #0x0
    ffe4:      	b.ne	0xfff0 <_stogir.vector-lanes.compatible?+0x1c4>
    ffe8:      	movz	x1, #0x0, lsl #48
    ffec:      	b	0xff8c <_stogir.vector-lanes.compatible?+0x160>
    fff0:      	cmp	x20, #0x1
    fff4:      	b.eq	0xff88 <_stogir.vector-lanes.compatible?+0x15c>
    fff8:      	cmp	x20, #0x2
    fffc:      	b.eq	0xff88 <_stogir.vector-lanes.compatible?+0x15c>
   10000:      	cmp	x20, #0x7
   10004:      	b.eq	0xff88 <_stogir.vector-lanes.compatible?+0x15c>
   10008:      	cmp	x20, #0x8
   1000c:      	b.eq	0xff88 <_stogir.vector-lanes.compatible?+0x15c>
   10010:      	cmp	x20, #0x3
   10014:      	b.eq	0x100d0 <_stogir.vector-lanes.compatible?+0x2a4>
   10018:      	cmp	x20, #0x9
   1001c:      	b.eq	0x100d0 <_stogir.vector-lanes.compatible?+0x2a4>
   10020:      	cmp	x20, #0x4
   10024:      	b.eq	0x100e0 <_stogir.vector-lanes.compatible?+0x2b4>
   10028:      	cmp	x20, #0xa
   1002c:      	b.eq	0x100e0 <_stogir.vector-lanes.compatible?+0x2b4>
   10030:      	cmp	x20, #0xd
   10034:      	b.eq	0x100e0 <_stogir.vector-lanes.compatible?+0x2b4>
   10038:      	cmp	x20, #0x5
   1003c:      	b.eq	0x100f0 <_stogir.vector-lanes.compatible?+0x2c4>
   10040:      	cmp	x20, #0xb
   10044:      	b.eq	0x100f0 <_stogir.vector-lanes.compatible?+0x2c4>
   10048:      	cmp	x20, #0xc
   1004c:      	b.eq	0x100f0 <_stogir.vector-lanes.compatible?+0x2c4>
   10050:      	cmp	x20, #0x6
   10054:      	b.ne	0x10100 <_stogir.vector-lanes.compatible?+0x2d4>
   10058:      	mov	x1, x21
   1005c:      	b	0x10104 <_stogir.vector-lanes.compatible?+0x2d8>
   10060:      	cmp	x0, #0x1
   10064:      	b.eq	0xffbc <_stogir.vector-lanes.compatible?+0x190>
   10068:      	cmp	x0, #0x2
   1006c:      	b.eq	0xffbc <_stogir.vector-lanes.compatible?+0x190>
   10070:      	cmp	x0, #0x7
   10074:      	b.eq	0xffbc <_stogir.vector-lanes.compatible?+0x190>
   10078:      	cmp	x0, #0x8
   1007c:      	b.eq	0xffbc <_stogir.vector-lanes.compatible?+0x190>
   10080:      	cmp	x0, #0x3
   10084:      	b.eq	0x100d8 <_stogir.vector-lanes.compatible?+0x2ac>
   10088:      	cmp	x0, #0x9
   1008c:      	b.eq	0x100d8 <_stogir.vector-lanes.compatible?+0x2ac>
   10090:      	cmp	x0, #0x4
   10094:      	b.eq	0x100e8 <_stogir.vector-lanes.compatible?+0x2bc>
   10098:      	cmp	x0, #0xa
   1009c:      	b.eq	0x100e8 <_stogir.vector-lanes.compatible?+0x2bc>
   100a0:      	cmp	x0, #0xd
   100a4:      	b.eq	0x100e8 <_stogir.vector-lanes.compatible?+0x2bc>
   100a8:      	cmp	x0, #0x5
   100ac:      	b.eq	0x100f8 <_stogir.vector-lanes.compatible?+0x2cc>
   100b0:      	cmp	x0, #0xb
   100b4:      	b.eq	0x100f8 <_stogir.vector-lanes.compatible?+0x2cc>
   100b8:      	cmp	x0, #0xc
   100bc:      	b.eq	0x100f8 <_stogir.vector-lanes.compatible?+0x2cc>
   100c0:      	cmp	x0, #0x6
   100c4:      	b.ne	0x10108 <_stogir.vector-lanes.compatible?+0x2dc>
   100c8:      	mov	x0, x21
   100cc:      	b	0x1010c <_stogir.vector-lanes.compatible?+0x2e0>
   100d0:      	mov	x1, #0x2                ; =2
   100d4:      	b	0xff8c <_stogir.vector-lanes.compatible?+0x160>
   100d8:      	mov	x0, #0x2                ; =2
   100dc:      	b	0xffc0 <_stogir.vector-lanes.compatible?+0x194>
   100e0:      	mov	x1, #0x4                ; =4
   100e4:      	b	0x100d4 <_stogir.vector-lanes.compatible?+0x2a8>
   100e8:      	mov	x0, #0x4                ; =4
   100ec:      	b	0x100dc <_stogir.vector-lanes.compatible?+0x2b0>
   100f0:      	mov	x1, #0x8                ; =8
   100f4:      	b	0x100e4 <_stogir.vector-lanes.compatible?+0x2b8>
   100f8:      	mov	x0, #0x8                ; =8
   100fc:      	b	0x100ec <_stogir.vector-lanes.compatible?+0x2c0>
   10100:      	movn	x1, #0x0, lsl #48
   10104:      	b	0x100f4 <_stogir.vector-lanes.compatible?+0x2c8>
   10108:      	movn	x0, #0x0, lsl #48
   1010c:      	b	0x100fc <_stogir.vector-lanes.compatible?+0x2d0>

0000000000010110 <_stogir.symbols.numeric?>:
   10110:      	ldr	w0, [x0]
   10114:      	uxtb	w1, w0
   10118:      	ubfx	x0, x0, #8, #8
   1011c:      	cmp	x1, x0
   10120:      	b.ne	0x1012c <_stogir.symbols.numeric?+0x1c>
   10124:      	mov	x0, #0x1                ; =1
   10128:      	b	0x10138 <_stogir.symbols.numeric?+0x28>
   1012c:      	cmp	x1, #0x49
   10130:      	cset	w0, eq
   10134:      	ubfx	x0, x0, #0, #8
   10138:      	ret

000000000001013c <_stogir.node.constant-bits>:
   1013c:      	ldr	w1, [x0, #0x8]
   10140:      	ubfx	x1, x1, #0, #32
   10144:      	ldr	w0, [x0, #0xc]
   10148:      	ubfx	x0, x0, #0, #32
   1014c:      	lsl	x0, x0, #32
   10150:      	orr	x0, x0, x1
   10154:      	ret

0000000000010158 <_stogir.vector-comparison.valid-type?>:
   10158:      	sub	sp, sp, #0x30
   1015c:      	str	x29, [sp]
   10160:      	str	x30, [sp, #0x8]
   10164:      	mov	x29, sp
   10168:      	str	x19, [sp, #0x10]
   1016c:      	str	x20, [sp, #0x18]
   10170:      	str	x21, [sp, #0x20]
   10174:      	sxtw	x19, w0
   10178:      	cmp	x19, #0xe
   1017c:      	b.lt	0x101d4 <_stogir.vector-comparison.valid-type?+0x7c>
   10180:      	cmp	x19, #0x19
   10184:      	b.gt	0x101d4 <_stogir.vector-comparison.valid-type?+0x7c>
   10188:      	sxtw	x0, w1
   1018c:      	cmp	x0, #0xf
   10190:      	b.le	0x101f4 <_stogir.vector-comparison.valid-type?+0x9c>
   10194:      	cmp	x0, #0x80
   10198:      	b.ge	0x101f4 <_stogir.vector-comparison.valid-type?+0x9c>
   1019c:      	and	x0, x0, #0xf
   101a0:      	lsr	w0, w0, #0
   101a4:      	sxtw	x20, w0
   101a8:      	cmp	x20, #0x1
   101ac:      	b.lt	0x101f4 <_stogir.vector-comparison.valid-type?+0x9c>
   101b0:      	cmp	x20, #0xd
   101b4:      	b.gt	0x101f4 <_stogir.vector-comparison.valid-type?+0x9c>
   101b8:      	lsr	w21, w1, #0
   101bc:      	mov	w0, w21
   101c0:      	bl	0x101c0 <_stogir.vector-comparison.valid-type?+0x68>
		00000000000101c0:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   101c4:      	cmp	x0, #0x0
   101c8:      	b.eq	0x10204 <_stogir.vector-comparison.valid-type?+0xac>
   101cc:      	mov	x0, x20
   101d0:      	b	0x10208 <_stogir.vector-comparison.valid-type?+0xb0>
   101d4:      	movz	x0, #0x0, lsl #48
   101d8:      	ldr	x19, [sp, #0x10]
   101dc:      	ldr	x20, [sp, #0x18]
   101e0:      	ldr	x21, [sp, #0x20]
   101e4:      	ldr	x29, [sp]
   101e8:      	ldr	x30, [sp, #0x8]
   101ec:      	add	sp, sp, #0x30
   101f0:      	ret
   101f4:      	movz	x0, #0x0, lsl #48
   101f8:      	b	0x101d8 <_stogir.vector-comparison.valid-type?+0x80>
   101fc:      	mov	x0, #0x1                ; =1
   10200:      	b	0x101f8 <_stogir.vector-comparison.valid-type?+0xa0>
   10204:      	movn	x0, #0x0, lsl #48
   10208:      	lsr	w0, w0, #0
   1020c:      	sxtw	x0, w0
   10210:      	cmp	x0, #0xc
   10214:      	b.eq	0x101fc <_stogir.vector-comparison.valid-type?+0xa4>
   10218:      	cmp	x0, #0xd
   1021c:      	b.eq	0x101fc <_stogir.vector-comparison.valid-type?+0xa4>
   10220:      	mov	w0, w21
   10224:      	bl	0x10224 <_stogir.vector-comparison.valid-type?+0xcc>
		0000000000010224:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10228:      	cmp	x0, #0x0
   1022c:      	b.eq	0x10240 <_stogir.vector-comparison.valid-type?+0xe8>
   10230:      	mov	x0, x20
   10234:      	b	0x10244 <_stogir.vector-comparison.valid-type?+0xec>
   10238:      	movz	x0, #0x0, lsl #48
   1023c:      	b	0x10200 <_stogir.vector-comparison.valid-type?+0xa8>
   10240:      	movn	x0, #0x0, lsl #48
   10244:      	lsr	w0, w0, #0
   10248:      	sxtw	x0, w0
   1024c:      	cmp	x0, #0x1
   10250:      	b.lt	0x10238 <_stogir.vector-comparison.valid-type?+0xe0>
   10254:      	cmp	x0, #0xb
   10258:      	b.gt	0x10238 <_stogir.vector-comparison.valid-type?+0xe0>
   1025c:      	cmp	x19, #0x17
   10260:      	cset	w0, le
   10264:      	ubfx	x0, x0, #0, #8
   10268:      	b	0x1023c <_stogir.vector-comparison.valid-type?+0xe4>

000000000001026c <_stogir.vector-arithmetic.extrema?>:
   1026c:      	sxtw	x0, w0
   10270:      	cmp	x0, #0x3a
   10274:      	b.ne	0x10280 <_stogir.vector-arithmetic.extrema?+0x14>
   10278:      	mov	x0, #0x1                ; =1
   1027c:      	b	0x1028c <_stogir.vector-arithmetic.extrema?+0x20>
   10280:      	cmp	x0, #0x3b
   10284:      	cset	w0, eq
   10288:      	ubfx	x0, x0, #0, #8
   1028c:      	ret

0000000000010290 <_stogir.vector-arithmetic.shift?>:
   10290:      	sxtw	x0, w0
   10294:      	cmp	x0, #0x31
   10298:      	b.lt	0x102ac <_stogir.vector-arithmetic.shift?+0x1c>
   1029c:      	cmp	x0, #0x35
   102a0:      	cset	w0, le
   102a4:      	ubfx	x0, x0, #0, #8
   102a8:      	b	0x102b0 <_stogir.vector-arithmetic.shift?+0x20>
   102ac:      	movz	x0, #0x0, lsl #48
   102b0:      	ret

00000000000102b4 <_stogir.vector-arithmetic.valid-type?>:
   102b4:      	sub	sp, sp, #0x40
   102b8:      	str	x29, [sp]
   102bc:      	str	x30, [sp, #0x8]
   102c0:      	mov	x29, sp
   102c4:      	str	x19, [sp, #0x10]
   102c8:      	str	x20, [sp, #0x18]
   102cc:      	str	x21, [sp, #0x20]
   102d0:      	str	x22, [sp, #0x28]
   102d4:      	str	x23, [sp, #0x30]
   102d8:      	lsr	w2, w1, #0
   102dc:      	sxtw	x19, w1
   102e0:      	mov	w20, w0
   102e4:      	mov	w0, w2
   102e8:      	bl	0x102e8 <_stogir.vector-arithmetic.valid-type?+0x34>
		00000000000102e8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   102ec:      	and	x1, x19, #0xf
   102f0:      	lsr	w1, w1, #0
   102f4:      	sxtw	x1, w1
   102f8:      	cmp	x0, #0x0
   102fc:      	b.eq	0x10308 <_stogir.vector-arithmetic.valid-type?+0x54>
   10300:      	mov	x0, x1
   10304:      	b	0x1030c <_stogir.vector-arithmetic.valid-type?+0x58>
   10308:      	movn	x0, #0x0, lsl #48
   1030c:      	cmp	x19, #0xf
   10310:      	b.le	0x104f0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   10314:      	cmp	x19, #0x80
   10318:      	b.ge	0x104f0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   1031c:      	cmp	x1, #0x1
   10320:      	b.lt	0x104f0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   10324:      	cmp	x1, #0xd
   10328:      	b.gt	0x104f0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   1032c:      	sxtw	x1, w20
   10330:      	cmp	x1, #0x1f
   10334:      	cset	w19, eq
   10338:      	cmp	x1, #0x20
   1033c:      	cset	w21, eq
   10340:      	cmp	x1, #0x2e
   10344:      	cset	w2, eq
   10348:      	cmp	x1, #0x2f
   1034c:      	cset	w3, eq
   10350:      	cmp	x1, #0x30
   10354:      	cset	w4, eq
   10358:      	cmp	x1, #0x1e
   1035c:      	cset	w5, eq
   10360:      	cmp	x1, #0x31
   10364:      	cset	w6, ge
   10368:      	cmp	x1, #0x35
   1036c:      	cset	w7, le
   10370:      	cmp	x1, #0x3a
   10374:      	cset	w8, eq
   10378:      	cmp	x1, #0x3b
   1037c:      	cset	w9, eq
   10380:      	cmp	x1, #0x2d
   10384:      	cset	w10, eq
   10388:      	cmp	x1, #0x36
   1038c:      	cset	w11, eq
   10390:      	cmp	x1, #0x37
   10394:      	cset	w12, eq
   10398:      	cmp	x1, #0x38
   1039c:      	cset	w13, eq
   103a0:      	cmp	x1, #0x39
   103a4:      	cset	w14, eq
   103a8:      	uxtb	w16, w19
   103ac:      	cmp	w16, wzr
   103b0:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   103b4:      	uxtb	w16, w21
   103b8:      	cmp	w16, wzr
   103bc:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   103c0:      	uxtb	w16, w10
   103c4:      	cmp	w16, wzr
   103c8:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   103cc:      	uxtb	w16, w11
   103d0:      	cmp	w16, wzr
   103d4:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   103d8:      	uxtb	w16, w12
   103dc:      	cmp	w16, wzr
   103e0:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   103e4:      	uxtb	w16, w13
   103e8:      	cmp	w16, wzr
   103ec:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   103f0:      	uxtb	w16, w14
   103f4:      	cmp	w16, wzr
   103f8:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   103fc:      	uxtb	w16, w8
   10400:      	cmp	w16, wzr
   10404:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10408:      	uxtb	w16, w9
   1040c:      	cmp	w16, wzr
   10410:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10414:      	uxtb	w16, w6
   10418:      	cmp	w16, wzr
   1041c:      	b.eq	0x10618 <_stogir.vector-arithmetic.valid-type?+0x364>
   10420:      	uxtb	w16, w7
   10424:      	cmp	w16, wzr
   10428:      	b.eq	0x10618 <_stogir.vector-arithmetic.valid-type?+0x364>
   1042c:      	lsr	w0, w0, #0
   10430:      	sxtw	x1, w0
   10434:      	cmp	x1, #0xc
   10438:      	cset	w22, eq
   1043c:      	cmp	x1, #0xd
   10440:      	cset	w23, eq
   10444:      	uxtb	w16, w19
   10448:      	cmp	w16, wzr
   1044c:      	b.ne	0x10524 <_stogir.vector-arithmetic.valid-type?+0x270>
   10450:      	uxtb	w16, w21
   10454:      	cmp	w16, wzr
   10458:      	b.ne	0x10524 <_stogir.vector-arithmetic.valid-type?+0x270>
   1045c:      	uxtb	w16, w10
   10460:      	cmp	w16, wzr
   10464:      	b.ne	0x10524 <_stogir.vector-arithmetic.valid-type?+0x270>
   10468:      	uxtb	w16, w11
   1046c:      	cmp	w16, wzr
   10470:      	b.ne	0x10524 <_stogir.vector-arithmetic.valid-type?+0x270>
   10474:      	uxtb	w16, w12
   10478:      	cmp	w16, wzr
   1047c:      	b.ne	0x10524 <_stogir.vector-arithmetic.valid-type?+0x270>
   10480:      	uxtb	w16, w13
   10484:      	cmp	w16, wzr
   10488:      	b.ne	0x10524 <_stogir.vector-arithmetic.valid-type?+0x270>
   1048c:      	uxtb	w16, w14
   10490:      	cmp	w16, wzr
   10494:      	b.ne	0x10524 <_stogir.vector-arithmetic.valid-type?+0x270>
   10498:      	cmp	x1, #0x1
   1049c:      	cset	w0, eq
   104a0:      	cmp	x1, #0x1
   104a4:      	cset	w10, ge
   104a8:      	cmp	x1, #0xb
   104ac:      	cset	w1, le
   104b0:      	uxtb	w16, w6
   104b4:      	cmp	w16, wzr
   104b8:      	b.eq	0x10584 <_stogir.vector-arithmetic.valid-type?+0x2d0>
   104bc:      	uxtb	w16, w7
   104c0:      	cmp	w16, wzr
   104c4:      	b.eq	0x10584 <_stogir.vector-arithmetic.valid-type?+0x2d0>
   104c8:      	uxtb	w16, w10
   104cc:      	cmp	w16, wzr
   104d0:      	b.eq	0x10610 <_stogir.vector-arithmetic.valid-type?+0x35c>
   104d4:      	uxtb	w16, w1
   104d8:      	cmp	w16, wzr
   104dc:      	b.eq	0x10610 <_stogir.vector-arithmetic.valid-type?+0x35c>
   104e0:      	uxtb	w16, w0
   104e4:      	cmp	w16, wzr
   104e8:      	cset	x0, eq
   104ec:      	b	0x10614 <_stogir.vector-arithmetic.valid-type?+0x360>
   104f0:      	movz	x0, #0x0, lsl #48
   104f4:      	ldr	x19, [sp, #0x10]
   104f8:      	ldr	x20, [sp, #0x18]
   104fc:      	ldr	x21, [sp, #0x20]
   10500:      	ldr	x22, [sp, #0x28]
   10504:      	ldr	x23, [sp, #0x30]
   10508:      	ldr	x29, [sp]
   1050c:      	ldr	x30, [sp, #0x8]
   10510:      	add	sp, sp, #0x40
   10514:      	ret
   10518:      	ubfx	x21, x21, #0, #8
   1051c:      	mov	x0, x21
   10520:      	b	0x104f4 <_stogir.vector-arithmetic.valid-type?+0x240>
   10524:      	lsr	w20, w20, #0
   10528:      	lsr	w0, w0, #0
   1052c:      	mov	w1, w0
   10530:      	mov	w0, w20
   10534:      	bl	0x10534 <_stogir.vector-arithmetic.valid-type?+0x280>
		0000000000010534:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
   10538:      	cmp	x0, #0x0
   1053c:      	b.eq	0x10548 <_stogir.vector-arithmetic.valid-type?+0x294>
   10540:      	mov	x0, #0x1                ; =1
   10544:      	b	0x10520 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10548:      	uxtb	w16, w22
   1054c:      	cmp	w16, wzr
   10550:      	b.ne	0x10568 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10554:      	uxtb	w16, w23
   10558:      	cmp	w16, wzr
   1055c:      	b.ne	0x10568 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10560:      	movz	x0, #0x0, lsl #48
   10564:      	b	0x10520 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10568:      	uxtb	w16, w19
   1056c:      	cmp	w16, wzr
   10570:      	b.eq	0x10518 <_stogir.vector-arithmetic.valid-type?+0x264>
   10574:      	mov	x0, #0x1                ; =1
   10578:      	b	0x10520 <_stogir.vector-arithmetic.valid-type?+0x26c>
   1057c:      	movz	x0, #0x0, lsl #48
   10580:      	b	0x10520 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10584:      	uxtb	w16, w2
   10588:      	cmp	w16, wzr
   1058c:      	b.ne	0x105f8 <_stogir.vector-arithmetic.valid-type?+0x344>
   10590:      	uxtb	w16, w3
   10594:      	cmp	w16, wzr
   10598:      	b.ne	0x105f8 <_stogir.vector-arithmetic.valid-type?+0x344>
   1059c:      	uxtb	w16, w4
   105a0:      	cmp	w16, wzr
   105a4:      	b.ne	0x105f8 <_stogir.vector-arithmetic.valid-type?+0x344>
   105a8:      	uxtb	w16, w22
   105ac:      	cmp	w16, wzr
   105b0:      	b.ne	0x10670 <_stogir.vector-arithmetic.valid-type?+0x3bc>
   105b4:      	uxtb	w16, w23
   105b8:      	cmp	w16, wzr
   105bc:      	b.ne	0x10670 <_stogir.vector-arithmetic.valid-type?+0x3bc>
   105c0:      	uxtb	w16, w10
   105c4:      	cmp	w16, wzr
   105c8:      	b.eq	0x10680 <_stogir.vector-arithmetic.valid-type?+0x3cc>
   105cc:      	uxtb	w16, w1
   105d0:      	cmp	w16, wzr
   105d4:      	b.eq	0x10680 <_stogir.vector-arithmetic.valid-type?+0x3cc>
   105d8:      	uxtb	w16, w0
   105dc:      	cmp	w16, wzr
   105e0:      	b.eq	0x10688 <_stogir.vector-arithmetic.valid-type?+0x3d4>
   105e4:      	uxtb	w16, w8
   105e8:      	cmp	w16, wzr
   105ec:      	b.eq	0x10690 <_stogir.vector-arithmetic.valid-type?+0x3dc>
   105f0:      	mov	x0, #0x1                ; =1
   105f4:      	b	0x10698 <_stogir.vector-arithmetic.valid-type?+0x3e4>
   105f8:      	uxtb	w16, w10
   105fc:      	cmp	w16, wzr
   10600:      	b.eq	0x1057c <_stogir.vector-arithmetic.valid-type?+0x2c8>
   10604:      	ubfx	x1, x1, #0, #8
   10608:      	mov	x0, x1
   1060c:      	b	0x10580 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10610:      	movz	x0, #0x0, lsl #48
   10614:      	b	0x10580 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10618:      	cmp	x1, #0x1a
   1061c:      	b.eq	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10620:      	cmp	x1, #0x1b
   10624:      	b.eq	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10628:      	cmp	x1, #0x1c
   1062c:      	b.eq	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10630:      	cmp	x1, #0x1d
   10634:      	b.eq	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10638:      	uxtb	w16, w5
   1063c:      	cmp	w16, wzr
   10640:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10644:      	uxtb	w16, w2
   10648:      	cmp	w16, wzr
   1064c:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10650:      	uxtb	w16, w3
   10654:      	cmp	w16, wzr
   10658:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   1065c:      	uxtb	w16, w4
   10660:      	cmp	w16, wzr
   10664:      	b.ne	0x1042c <_stogir.vector-arithmetic.valid-type?+0x178>
   10668:      	movz	x0, #0x0, lsl #48
   1066c:      	b	0x10520 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10670:      	uxtb	w16, w5
   10674:      	cmp	w16, wzr
   10678:      	cset	x0, eq
   1067c:      	b	0x10580 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10680:      	movz	x0, #0x0, lsl #48
   10684:      	b	0x1067c <_stogir.vector-arithmetic.valid-type?+0x3c8>
   10688:      	mov	x0, #0x1                ; =1
   1068c:      	b	0x10684 <_stogir.vector-arithmetic.valid-type?+0x3d0>
   10690:      	ubfx	x9, x9, #0, #8
   10694:      	mov	x0, x9
   10698:      	b	0x1068c <_stogir.vector-arithmetic.valid-type?+0x3d8>

000000000001069c <_coil.core.Len$slice$len__i32>:
   1069c:      	mov	x0, x1
   106a0:      	ret

00000000000106a4 <_inherent$slice$data__i32>:
   106a4:      	ret

00000000000106a8 <_stogir.opcode.terminator?>:
   106a8:      	sxtw	x0, w0
   106ac:      	cmp	x0, #0x0
   106b0:      	b.lt	0x106d8 <_stogir.opcode.terminator?+0x30>
   106b4:      	cmp	x0, #0x83
   106b8:      	b.ge	0x106d8 <_stogir.opcode.terminator?+0x30>
   106bc:      	adrp	x16, 0x10000 <_stogir.vector-lanes.compatible?+0x1d4>
		00000000000106bc:  ARM64_RELOC_PAGE21	l_stogir.515
   106c0:      	ldr	x16, [x16]
		00000000000106c0:  ARM64_RELOC_PAGEOFF12	l_stogir.515
   106c4:      	orr	x1, x16, xzr
   106c8:      	lsr	x0, x0, #0
   106cc:      	add	x0, x0, x1
   106d0:      	ldrb	w0, [x0]
   106d4:      	b	0x106dc <_stogir.opcode.terminator?+0x34>
   106d8:      	movz	x0, #0x0, lsl #48
   106dc:      	uxtb	w0, w0
   106e0:      	and	x0, x0, #0x8
   106e4:      	uxtb	w0, w0
   106e8:      	cmp	x0, #0x0
   106ec:      	cset	w0, eq
   106f0:      	uxtb	w16, w0
   106f4:      	cmp	w16, wzr
   106f8:      	cset	x0, eq
   106fc:      	ret

0000000000010700 <_stogir.switch.sign-mask>:
   10700:      	sxtw	x0, w0
   10704:      	cmp	x0, #0x7
   10708:      	b.lt	0x10724 <_stogir.switch.sign-mask+0x24>
   1070c:      	cmp	x0, #0xb
   10710:      	b.gt	0x10724 <_stogir.switch.sign-mask+0x24>
   10714:      	cmp	x0, #0x0
   10718:      	b.ne	0x1075c <_stogir.switch.sign-mask+0x5c>
   1071c:      	movz	x0, #0x0, lsl #48
   10720:      	b	0x10730 <_stogir.switch.sign-mask+0x30>
   10724:      	movz	x0, #0x0, lsl #48
   10728:      	ret
   1072c:      	mov	x0, #0x1                ; =1
   10730:      	lsr	w0, w0, #0
   10734:      	sxtw	x0, w0
   10738:      	lsl	x0, x0, #3
   1073c:      	lsr	w0, w0, #0
   10740:      	sxtw	x0, w0
   10744:      	sub	x0, x0, #0x1
   10748:      	lsr	w0, w0, #0
   1074c:      	sxtw	x0, w0
   10750:      	mov	x16, #0x1               ; =1
   10754:      	lsl	x0, x16, x0
   10758:      	b	0x10728 <_stogir.switch.sign-mask+0x28>
   1075c:      	cmp	x0, #0x1
   10760:      	b.eq	0x1072c <_stogir.switch.sign-mask+0x2c>
   10764:      	cmp	x0, #0x2
   10768:      	b.eq	0x1072c <_stogir.switch.sign-mask+0x2c>
   1076c:      	cmp	x0, #0x7
   10770:      	b.eq	0x1072c <_stogir.switch.sign-mask+0x2c>
   10774:      	cmp	x0, #0x8
   10778:      	b.eq	0x1072c <_stogir.switch.sign-mask+0x2c>
   1077c:      	cmp	x0, #0x3
   10780:      	b.eq	0x107dc <_stogir.switch.sign-mask+0xdc>
   10784:      	cmp	x0, #0x9
   10788:      	b.eq	0x107dc <_stogir.switch.sign-mask+0xdc>
   1078c:      	cmp	x0, #0x4
   10790:      	b.eq	0x107e4 <_stogir.switch.sign-mask+0xe4>
   10794:      	cmp	x0, #0xa
   10798:      	b.eq	0x107e4 <_stogir.switch.sign-mask+0xe4>
   1079c:      	cmp	x0, #0xd
   107a0:      	b.eq	0x107e4 <_stogir.switch.sign-mask+0xe4>
   107a4:      	cmp	x0, #0x5
   107a8:      	b.eq	0x107ec <_stogir.switch.sign-mask+0xec>
   107ac:      	cmp	x0, #0xb
   107b0:      	b.eq	0x107ec <_stogir.switch.sign-mask+0xec>
   107b4:      	cmp	x0, #0xc
   107b8:      	b.eq	0x107ec <_stogir.switch.sign-mask+0xec>
   107bc:      	cmp	x0, #0x6
   107c0:      	cset	w0, eq
   107c4:      	uxtb	w16, w0
   107c8:      	cmp	w16, wzr
   107cc:      	mov	x16, #0x8               ; =8
   107d0:      	movn	x17, #0x0, lsl #48
   107d4:      	csel	x0, x16, x17, ne
   107d8:      	b	0x107f0 <_stogir.switch.sign-mask+0xf0>
   107dc:      	mov	x0, #0x2                ; =2
   107e0:      	b	0x10730 <_stogir.switch.sign-mask+0x30>
   107e4:      	mov	x0, #0x4                ; =4
   107e8:      	b	0x107e0 <_stogir.switch.sign-mask+0xe0>
   107ec:      	mov	x0, #0x8                ; =8
   107f0:      	b	0x107e8 <_stogir.switch.sign-mask+0xe8>
