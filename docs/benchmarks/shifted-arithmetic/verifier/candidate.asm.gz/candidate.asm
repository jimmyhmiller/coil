
/Users/jimmyhmiller/Documents/Code/projects/coil-stogir/.worktrees/shifted-arithmetic/build/shifted-verifier/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x138 <_stogir.verify.integer-operations-target+0x88>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, x0
     130:      	mov	x0, #0x1                ; =1
     134:      	b	0x164 <_stogir.verify.integer-operations-target+0xb4>
     138:      	lsr	w21, w21, #0
     13c:      	add	x8, sp, #0x30
     140:      	mov	x0, x20
     144:      	mov	w1, w21
     148:      	bl	0x148 <_stogir.verify.integer-operations-target+0x98>
		0000000000000148:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     14c:      	add	x16, sp, #0x30
     150:      	ldr	x0, [x16]
     154:      	add	x16, sp, #0x30
     158:      	ldr	x1, [x16, #0x8]
     15c:      	add	x16, sp, #0x30
     160:      	ldr	x2, [x16, #0x10]
     164:      	str	x0, [x19]
     168:      	str	x1, [x19, #0x8]
     16c:      	str	x2, [x19, #0x10]
     170:      	ldr	x19, [sp, #0x50]
     174:      	ldr	x20, [sp, #0x58]
     178:      	ldr	x21, [sp, #0x60]
     17c:      	ldr	x29, [sp]
     180:      	ldr	x30, [sp, #0x8]
     184:      	add	sp, sp, #0x70
     188:      	ret
     18c:      	brk	#0
     190:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>

0000000000000194 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     194:      	ldr	x0, [x0, #0x8]
     198:      	ret
     19c:      	udf	#0x0

00000000000001a0 <_stogir.verify.structure>:
     1a0:      	sub	sp, sp, #0x180
     1a4:      	str	x29, [sp, #0x10]
     1a8:      	str	x30, [sp, #0x18]
     1ac:      	add	x29, sp, #0x10
     1b0:      	str	x19, [sp, #0x128]
     1b4:      	str	x20, [sp, #0x130]
     1b8:      	str	x21, [sp, #0x138]
     1bc:      	str	x22, [sp, #0x140]
     1c0:      	str	x23, [sp, #0x148]
     1c4:      	str	x24, [sp, #0x150]
     1c8:      	str	x25, [sp, #0x158]
     1cc:      	str	x26, [sp, #0x160]
     1d0:      	str	x27, [sp, #0x168]
     1d4:      	str	x28, [sp, #0x170]
     1d8:      	add	x1, x0, #0x78
     1dc:      	ldr	x2, [x0, #0x8]
     1e0:      	ldr	x1, [x1, #0x8]
     1e4:      	cmp	x2, x1
     1e8:      	b.ne	0x224 <_stogir.verify.structure+0x84>
     1ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001ec:  ARM64_RELOC_PAGE21	l_stogir.304
     1f0:      	ldr	x16, [x16]
		00000000000001f0:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1f4:      	orr	x1, x16, xzr
     1f8:      	movz	x2, #0x0, lsl #48
     1fc:      	b	0x234 <_stogir.verify.structure+0x94>
     200:      	ldr	x0, [sp, #0x110]
     204:      	add	x0, x21, x0
     208:      	ldr	x1, [sp, #0xa8]
     20c:      	add	x1, x1, #0x1
     210:      	lsr	w1, w1, #0
     214:      	sxtw	x1, w1
     218:      	ldr	x2, [sp, #0x100]
     21c:      	ldr	x3, [sp, #0xf8]
     220:      	b	0x2e8 <_stogir.verify.structure+0x148>
     224:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000224:  ARM64_RELOC_PAGE21	l_stogir.305
     228:      	ldr	x16, [x16]
		0000000000000228:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     22c:      	orr	x1, x16, xzr
     230:      	mov	x2, #0x2c               ; =44
     234:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000234:  ARM64_RELOC_PAGE21	l_stogir.306
     238:      	ldr	x16, [x16]
		0000000000000238:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     23c:      	orr	x19, x16, xzr
     240:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000240:  ARM64_RELOC_PAGE21	l_stogir.307
     244:      	ldr	x16, [x16]
		0000000000000244:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     248:      	orr	x20, x16, xzr
     24c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000024c:  ARM64_RELOC_PAGE21	l_stogir.308
     250:      	ldr	x16, [x16]
		0000000000000250:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     254:      	orr	x21, x16, xzr
     258:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000258:  ARM64_RELOC_PAGE21	l_stogir.309
     25c:      	ldr	x16, [x16]
		000000000000025c:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     260:      	orr	x22, x16, xzr
     264:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000264:  ARM64_RELOC_PAGE21	l_stogir.310
     268:      	ldr	x16, [x16]
		0000000000000268:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     26c:      	orr	x23, x16, xzr
     270:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000270:  ARM64_RELOC_PAGE21	l_stogir.311
     274:      	ldr	x16, [x16]
		0000000000000274:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     278:      	orr	x24, x16, xzr
     27c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000027c:  ARM64_RELOC_PAGE21	l_stogir.312
     280:      	ldr	x16, [x16]
		0000000000000280:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     284:      	orr	x25, x16, xzr
     288:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000288:  ARM64_RELOC_PAGE21	l_stogir.313
     28c:      	ldr	x16, [x16]
		000000000000028c:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     290:      	orr	x26, x16, xzr
     294:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000294:  ARM64_RELOC_PAGE21	l_stogir.314
     298:      	ldr	x16, [x16]
		0000000000000298:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     29c:      	orr	x27, x16, xzr
     2a0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002a0:  ARM64_RELOC_PAGE21	l_stogir.315
     2a4:      	ldr	x16, [x16]
		00000000000002a4:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     2a8:      	orr	x28, x16, xzr
     2ac:      	add	x3, x0, #0x110
     2b0:      	add	x4, x0, #0x78
     2b4:      	add	x5, x0, #0x28
     2b8:      	add	x6, x0, #0x50
     2bc:      	add	x7, x0, #0x78
     2c0:      	add	x9, x0, #0x28
     2c4:      	add	x10, x0, #0x50
     2c8:      	add	x11, x3, #0x28
     2cc:      	mov	x12, x1
     2d0:      	mov	x13, x2
     2d4:      	mov	x1, #0x1                ; =1
     2d8:      	movz	x2, #0x0, lsl #48
     2dc:      	b	0x3b0 <_stogir.verify.structure+0x210>
     2e0:      	ldr	x2, [sp, #0x58]
     2e4:      	mov	x3, #0x16               ; =22
     2e8:      	b	0x350 <_stogir.verify.structure+0x1b0>
     2ec:      	nop
     2f0:      	str	x8, [sp, #0xa0]
     2f4:      	str	x19, [sp, #0x50]
     2f8:      	str	x20, [sp, #0x58]
     2fc:      	mov	x20, x0
     300:      	mov	x0, x1
     304:      	mov	x1, x2
     308:      	str	x21, [sp, #0x60]
     30c:      	str	x22, [sp, #0x68]
     310:      	str	x23, [sp, #0x70]
     314:      	str	x24, [sp, #0x78]
     318:      	str	x25, [sp, #0x80]
     31c:      	str	x26, [sp, #0x88]
     320:      	str	x27, [sp, #0x90]
     324:      	str	x28, [sp, #0x98]
     328:      	str	x3, [sp, #0xd8]
     32c:      	str	x11, [sp, #0xe0]
     330:      	mov	x19, x4
     334:      	str	x5, [sp, #0xc8]
     338:      	str	x6, [sp, #0xc0]
     33c:      	mov	x25, x7
     340:      	mov	x26, x9
     344:      	mov	x27, x10
     348:      	ldr	x2, [sp, #0x50]
     34c:      	mov	x3, #0x23               ; =35
     350:      	ldr	x8, [sp, #0xa0]
     354:      	ldr	x21, [sp, #0x60]
     358:      	ldr	x22, [sp, #0x68]
     35c:      	ldr	x23, [sp, #0x70]
     360:      	ldr	x24, [sp, #0x78]
     364:      	ldr	x28, [sp, #0x98]
     368:      	ldr	x11, [sp, #0xe0]
     36c:      	mov	x4, x19
     370:      	ldr	x19, [sp, #0x50]
     374:      	ldr	x5, [sp, #0xc8]
     378:      	ldr	x6, [sp, #0xc0]
     37c:      	mov	x7, x25
     380:      	ldr	x25, [sp, #0x80]
     384:      	mov	x9, x26
     388:      	ldr	x26, [sp, #0x88]
     38c:      	mov	x10, x27
     390:      	ldr	x27, [sp, #0x90]
     394:      	mov	x12, x2
     398:      	mov	x2, x1
     39c:      	mov	x1, x0
     3a0:      	mov	x0, x20
     3a4:      	ldr	x20, [sp, #0x58]
     3a8:      	mov	x13, x3
     3ac:      	ldr	x3, [sp, #0xd8]
     3b0:      	cmp	x13, #0x0
     3b4:      	b.ne	0xc34 <_stogir.verify.structure+0xa94>
     3b8:      	ldr	x14, [x0, #0x8]
     3bc:      	cmp	x1, x14
     3c0:      	b.ge	0xc48 <_stogir.verify.structure+0xaa8>
     3c4:      	lsl	x14, x1, #4
     3c8:      	lsl	x14, x1, #2
     3cc:      	ldr	x14, [x0]
     3d0:      	add	x14, x14, x1, lsl #4
     3d4:      	ldr	x14, [x14]
     3d8:      	ldr	x15, [x0, #0x78]
     3dc:      	add	x15, x15, x1, lsl #2
     3e0:      	ldr	w15, [x15]
     3e4:      	sxtw	x15, w15
     3e8:      	cmp	x15, #0x0
     3ec:      	b.lt	0x2f0 <_stogir.verify.structure+0x150>
     3f0:      	mov	x17, #0xffff            ; =65535
     3f4:      	cmp	x15, x17
     3f8:      	b.gt	0xc5c <_stogir.verify.structure+0xabc>
     3fc:      	str	x0, [sp, #0x30]
     400:      	uxtb	w0, w14
     404:      	str	w0, [sp, #0x38]
     408:      	cmp	x0, #0x83
     40c:      	b.ge	0xcb8 <_stogir.verify.structure+0xb18>
     410:      	lsr	w14, w14, #0
     414:      	str	x0, [sp, #0x40]
     418:      	ubfx	x0, x14, #8, #8
     41c:      	str	w0, [sp, #0x48]
     420:      	lsr	w0, w0, #0
     424:      	str	x8, [sp, #0xa0]
     428:      	str	x3, [sp, #0xd8]
     42c:      	str	x4, [sp, #0xd0]
     430:      	str	x5, [sp, #0xc8]
     434:      	str	x6, [sp, #0xc0]
     438:      	str	x11, [sp, #0xe0]
     43c:      	str	x2, [sp, #0xa8]
     440:      	str	x12, [sp, #0xb0]
     444:      	str	x13, [sp, #0xb8]
     448:      	str	x19, [sp, #0x50]
     44c:      	mov	x19, x1
     450:      	str	x20, [sp, #0x58]
     454:      	ldr	x20, [sp, #0x30]
     458:      	str	x21, [sp, #0x60]
     45c:      	mov	x21, x14
     460:      	str	x22, [sp, #0x68]
     464:      	ldr	x22, [sp, #0x40]
     468:      	str	x23, [sp, #0x70]
     46c:      	ldr	w23, [sp, #0x38]
     470:      	str	x24, [sp, #0x78]
     474:      	mov	x24, x15
     478:      	str	x25, [sp, #0x80]
     47c:      	mov	x25, x7
     480:      	str	x26, [sp, #0x88]
     484:      	mov	x26, x9
     488:      	str	x27, [sp, #0x90]
     48c:      	mov	x27, x10
     490:      	str	x28, [sp, #0x98]
     494:      	ldr	w28, [sp, #0x48]
     498:      	bl	0x498 <_stogir.verify.structure+0x2f8>
		0000000000000498:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     49c:      	cmp	x0, #0x0
     4a0:      	b.eq	0xd14 <_stogir.verify.structure+0xb74>
     4a4:      	lsr	w23, w23, #0
     4a8:      	mov	w0, w23
     4ac:      	bl	0x4ac <_stogir.verify.structure+0x30c>
		00000000000004ac:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4b0:      	lsr	w0, w0, #0
     4b4:      	sxtw	x0, w0
     4b8:      	cmp	x0, #0x0
     4bc:      	b.lt	0x9e8 <_stogir.verify.structure+0x848>
     4c0:      	mov	w0, w23
     4c4:      	bl	0x4c4 <_stogir.verify.structure+0x324>
		00000000000004c4:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4c8:      	lsr	w0, w0, #0
     4cc:      	sxtw	x0, w0
     4d0:      	cmp	x24, x0
     4d4:      	b.eq	0x9e8 <_stogir.verify.structure+0x848>
     4d8:      	mov	x0, x19
     4dc:      	ldr	x19, [sp, #0xd0]
     4e0:      	ldr	x1, [sp, #0xa8]
     4e4:      	ldr	x2, [sp, #0x60]
     4e8:      	mov	x3, #0x23               ; =35
     4ec:      	b	0x220 <_stogir.verify.structure+0x80>
     4f0:      	ldr	x0, [sp, #0xb8]
     4f4:      	cmp	x0, #0x0
     4f8:      	b.ne	0x510 <_stogir.verify.structure+0x370>
     4fc:      	and	x0, x1, #0xffffffff
     500:      	mov	x1, x0
     504:      	movz	x0, #0x0, lsl #48
     508:      	movz	x2, #0x0, lsl #48
     50c:      	b	0x51c <_stogir.verify.structure+0x37c>
     510:      	ldr	x1, [sp, #0xb0]
     514:      	mov	x2, x0
     518:      	mov	x0, #0x1                ; =1
     51c:      	ldr	x3, [sp, #0xa0]
     520:      	str	x0, [x3]
     524:      	str	x1, [x3, #0x8]
     528:      	str	x2, [x3, #0x10]
     52c:      	ldr	x19, [sp, #0x128]
     530:      	ldr	x20, [sp, #0x130]
     534:      	ldr	x21, [sp, #0x138]
     538:      	ldr	x22, [sp, #0x140]
     53c:      	ldr	x23, [sp, #0x148]
     540:      	ldr	x24, [sp, #0x150]
     544:      	ldr	x25, [sp, #0x158]
     548:      	ldr	x26, [sp, #0x160]
     54c:      	ldr	x27, [sp, #0x168]
     550:      	ldr	x28, [sp, #0x170]
     554:      	ldr	x29, [sp, #0x10]
     558:      	ldr	x30, [sp, #0x18]
     55c:      	add	sp, sp, #0x180
     560:      	ret
     564:      	mov	x0, x9
     568:      	ldr	x1, [sp, #0x118]
     56c:      	b	0x624 <_stogir.verify.structure+0x484>
     570:      	mov	x4, x2
     574:      	movz	x2, #0x0, lsl #48
     578:      	cmp	x2, #0x0
     57c:      	b.eq	0xd24 <_stogir.verify.structure+0xb84>
     580:      	lsr	w2, w1, #0
     584:      	str	w0, [sp, #0xe8]
     588:      	mov	w0, w23
     58c:      	str	x3, [sp, #0xf8]
     590:      	str	x4, [sp, #0x100]
     594:      	str	w23, [sp, #0xf0]
     598:      	mov	x23, x1
     59c:      	mov	w1, w2
     5a0:      	str	x24, [sp, #0x108]
     5a4:      	mov	w24, w2
     5a8:      	bl	0x5a8 <_stogir.verify.structure+0x408>
		00000000000005a8:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     5ac:      	add	x16, sp, #0x20
     5b0:      	str	x16, [sp]
     5b4:      	ldr	w1, [sp, #0xe8]
     5b8:      	mov	w2, w24
     5bc:      	str	x19, [sp, #0x110]
     5c0:      	mov	x19, x0
     5c4:      	mov	x0, x20
     5c8:      	bl	0x5c8 <_stogir.verify.structure+0x428>
		00000000000005c8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     5cc:      	ldr	x16, [sp]
     5d0:      	str	x0, [x16]
     5d4:      	str	x1, [x16, #0x8]
     5d8:      	add	x16, sp, #0x20
     5dc:      	ldr	x0, [x16]
     5e0:      	add	x16, sp, #0x20
     5e4:      	ldr	x1, [x16, #0x8]
     5e8:      	lsr	w0, w0, #0
     5ec:      	lsr	x16, x0, #0
     5f0:      	cmp	x16, #0x1
     5f4:      	b.eq	0x610 <_stogir.verify.structure+0x470>
     5f8:      	b.lo	0x600 <_stogir.verify.structure+0x460>
     5fc:      	b	0x614 <_stogir.verify.structure+0x474>
     600:      	cmp	x16, #0x0
     604:      	b.eq	0x60c <_stogir.verify.structure+0x46c>
     608:      	b	0x614 <_stogir.verify.structure+0x474>
     60c:      	b	0x618 <_stogir.verify.structure+0x478>
     610:      	b	0x674 <_stogir.verify.structure+0x4d4>
     614:      	b	0xba0 <_stogir.verify.structure+0xa00>
     618:      	ldr	x19, [sp, #0xd0]
     61c:      	ldr	x0, [sp, #0x80]
     620:      	mov	x1, #0x17               ; =23
     624:      	add	x2, x23, #0x1
     628:      	lsr	w2, w2, #0
     62c:      	sxtw	x2, w2
     630:      	ldr	x24, [sp, #0x108]
     634:      	ldr	w23, [sp, #0xf0]
     638:      	str	x19, [sp, #0xd0]
     63c:      	ldr	x19, [sp, #0x110]
     640:      	mov	x3, x1
     644:      	mov	x1, x2
     648:      	mov	x2, x0
     64c:      	ldr	w0, [sp, #0xe8]
     650:      	cmp	x3, #0x0
     654:      	b.ne	0x570 <_stogir.verify.structure+0x3d0>
     658:      	cmp	x1, x24
     65c:      	cset	w4, le
     660:      	ubfx	x4, x4, #0, #8
     664:      	fmov	d31, x2
     668:      	mov	x2, x4
     66c:      	fmov	x4, d31
     670:      	b	0x578 <_stogir.verify.structure+0x3d8>
     674:      	lsr	w19, w19, #0
     678:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000678:  ARM64_RELOC_PAGE21	l_stogir.316
     67c:      	ldr	x16, [x16]
		000000000000067c:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     680:      	ldr	w0, [x16]
     684:      	orr	x2, x19, xzr
     688:      	cmp	x2, x0
     68c:      	b.ne	0x698 <_stogir.verify.structure+0x4f8>
     690:      	mov	x0, #0x1                ; =1
     694:      	b	0x6b0 <_stogir.verify.structure+0x510>
     698:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000698:  ARM64_RELOC_PAGE21	l_stogir.317
     69c:      	ldr	x16, [x16]
		000000000000069c:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     6a0:      	ldr	w0, [x16]
     6a4:      	cmp	x2, x0
     6a8:      	cset	w0, eq
     6ac:      	ubfx	x0, x0, #0, #8
     6b0:      	lsr	w1, w1, #0
     6b4:      	sxtw	x1, w1
     6b8:      	cmp	x1, #0x0
     6bc:      	cset	w3, gt
     6c0:      	lsl	x4, x1, #2
     6c4:      	cmp	x1, #0x0
     6c8:      	cset	w5, lt
     6cc:      	movz	x16, #0x0, lsl #48
     6d0:      	sub	x6, x16, x1
     6d4:      	sub	x7, x6, #0x1
     6d8:      	lsl	x8, x7, #2
     6dc:      	cmp	x0, #0x0
     6e0:      	b.eq	0x728 <_stogir.verify.structure+0x588>
     6e4:      	uxtb	w16, w3
     6e8:      	cmp	w16, wzr
     6ec:      	b.eq	0x928 <_stogir.verify.structure+0x788>
     6f0:      	ldr	x9, [x20, #0x8]
     6f4:      	cmp	x1, x9
     6f8:      	b.ge	0x96c <_stogir.verify.structure+0x7cc>
     6fc:      	ldr	x9, [x25, #0x8]
     700:      	cmp	x1, x9
     704:      	b.ge	0xa34 <_stogir.verify.structure+0x894>
     708:      	ldr	x9, [x20, #0x78]
     70c:      	add	x9, x4, x9
     710:      	ldr	w9, [x9]
     714:      	sxtw	x9, w9
     718:      	cmp	x9, #0x0
     71c:      	cset	w9, ge
     720:      	ubfx	x9, x9, #0, #8
     724:      	b	0xa38 <_stogir.verify.structure+0x898>
     728:      	ldr	x9, [sp, #0x100]
     72c:      	ldr	x10, [sp, #0xf8]
     730:      	movz	x7, #0x0, lsl #48
     734:      	b	0x74c <_stogir.verify.structure+0x5ac>
     738:      	ldr	x7, [sp, #0x100]
     73c:      	ldr	x10, [sp, #0xf8]
     740:      	fmov	d31, x7
     744:      	mov	x7, x9
     748:      	fmov	x9, d31
     74c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000074c:  ARM64_RELOC_PAGE21	l_stogir.318
     750:      	ldr	x16, [x16]
		0000000000000750:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     754:      	ldr	w11, [x16]
     758:      	cmp	x2, x11
     75c:      	b.ne	0xd38 <_stogir.verify.structure+0xb98>
     760:      	cmp	x1, #0x0
     764:      	b.gt	0x8c8 <_stogir.verify.structure+0x728>
     768:      	ldr	x12, [sp, #0xd8]
     76c:      	ldr	x2, [sp, #0xe0]
     770:      	movz	x11, #0x0, lsl #48
     774:      	lsr	w11, w11, #0
     778:      	lsr	x16, x11, #0
     77c:      	cmp	x16, #0x1
     780:      	b.eq	0x79c <_stogir.verify.structure+0x5fc>
     784:      	b.lo	0x78c <_stogir.verify.structure+0x5ec>
     788:      	b	0x7a0 <_stogir.verify.structure+0x600>
     78c:      	cmp	x16, #0x0
     790:      	b.eq	0x798 <_stogir.verify.structure+0x5f8>
     794:      	b	0x7a0 <_stogir.verify.structure+0x600>
     798:      	b	0x7a4 <_stogir.verify.structure+0x604>
     79c:      	b	0x7ac <_stogir.verify.structure+0x60c>
     7a0:      	b	0xc24 <_stogir.verify.structure+0xa84>
     7a4:      	ldr	x9, [sp, #0x90]
     7a8:      	mov	x10, #0x21              ; =33
     7ac:      	cmp	x19, #0xf
     7b0:      	b.hs	0xd44 <_stogir.verify.structure+0xba4>
     7b4:      	mov	x16, #0x1               ; =1
     7b8:      	lsl	x11, x16, x19
     7bc:      	lsr	w11, w11, #0
     7c0:      	mov	x17, #0x5e1c            ; =24092
     7c4:      	and	x11, x11, x17
     7c8:      	lsr	w11, w11, #0
     7cc:      	cmp	x11, #0x0
     7d0:      	b.eq	0xd58 <_stogir.verify.structure+0xbb8>
     7d4:      	cmp	x0, #0x0
     7d8:      	b.eq	0xae8 <_stogir.verify.structure+0x948>
     7dc:      	ldr	x19, [sp, #0xd0]
     7e0:      	ldr	x0, [sp, #0xc8]
     7e4:      	ldr	x4, [sp, #0xc0]
     7e8:      	mov	x3, x7
     7ec:      	mov	x5, x9
     7f0:      	b	0xa74 <_stogir.verify.structure+0x8d4>
     7f4:      	lsr	w0, w19, #0
     7f8:      	cmp	x22, #0x78
     7fc:      	cset	w22, eq
     800:      	lsr	w0, w0, #0
     804:      	cmp	x28, #0x0
     808:      	cset	w28, eq
     80c:      	mov	x2, x1
     810:      	mov	x1, #0x1                ; =1
     814:      	b	0x650 <_stogir.verify.structure+0x4b0>
     818:      	ldr	x1, [sp, #0x78]
     81c:      	mov	x2, #0x1b               ; =27
     820:      	add	x0, x0, #0x1
     824:      	cmp	x2, #0x0
     828:      	b.ne	0x848 <_stogir.verify.structure+0x6a8>
     82c:      	cmp	x0, x21
     830:      	cset	w3, lt
     834:      	ubfx	x3, x3, #0, #8
     838:      	fmov	d31, x2
     83c:      	mov	x2, x3
     840:      	fmov	x3, d31
     844:      	b	0x850 <_stogir.verify.structure+0x6b0>
     848:      	mov	x3, x2
     84c:      	movz	x2, #0x0, lsl #48
     850:      	cmp	x2, #0x0
     854:      	b.eq	0x7f4 <_stogir.verify.structure+0x654>
     858:      	add	x2, x0, x19
     85c:      	ldr	x4, [x20, #0x78]
     860:      	lsl	x5, x2, #2
     864:      	add	x2, x4, x2, lsl #2
     868:      	ldr	w2, [x2]
     86c:      	sxtw	x2, w2
     870:      	cmn	x2, #0x1
     874:      	b.ne	0x818 <_stogir.verify.structure+0x678>
     878:      	mov	x2, x3
     87c:      	b	0x820 <_stogir.verify.structure+0x680>
     880:      	ldr	x0, [sp, #0xb0]
     884:      	ldr	x1, [sp, #0xb8]
     888:      	add	x2, x24, #0x4
     88c:      	ldr	x3, [x20, #0x8]
     890:      	asr	x16, x2, #63
     894:      	lsr	x16, x16, #62
     898:      	add	x2, x2, x16
     89c:      	asr	x2, x2, #2
     8a0:      	orr	x21, x2, xzr
     8a4:      	add	x2, x21, x19
     8a8:      	cmp	x2, x3
     8ac:      	b.le	0x8b8 <_stogir.verify.structure+0x718>
     8b0:      	ldr	x0, [sp, #0x70]
     8b4:      	mov	x1, #0x15               ; =21
     8b8:      	mov	x2, x1
     8bc:      	mov	x1, x0
     8c0:      	mov	x0, #0x1                ; =1
     8c4:      	b	0x824 <_stogir.verify.structure+0x684>
     8c8:      	ldr	x2, [sp, #0xe0]
     8cc:      	ldr	x11, [x2, #0x8]
     8d0:      	cmp	x1, x11
     8d4:      	b.gt	0xd6c <_stogir.verify.structure+0xbcc>
     8d8:      	sub	x11, x1, #0x1
     8dc:      	ldr	x12, [sp, #0xd8]
     8e0:      	ldr	x13, [x12, #0x28]
     8e4:      	mov	x17, #0x18              ; =24
     8e8:      	mul	x11, x11, x17
     8ec:      	add	x11, x11, x13
     8f0:      	ldr	x13, [x11]
     8f4:      	ldr	x11, [x11, #0x8]
     8f8:      	ldr	x14, [x12, #0x8]
     8fc:      	cmp	x13, #0x0
     900:      	b.lt	0xa24 <_stogir.verify.structure+0x884>
     904:      	cmp	x13, x14
     908:      	b.gt	0xa24 <_stogir.verify.structure+0x884>
     90c:      	cmp	x11, #0x0
     910:      	b.lt	0xa24 <_stogir.verify.structure+0x884>
     914:      	sub	x13, x14, x13
     918:      	cmp	x11, x13
     91c:      	b.gt	0xa24 <_stogir.verify.structure+0x884>
     920:      	mov	x11, #0x1               ; =1
     924:      	b	0xa28 <_stogir.verify.structure+0x888>
     928:      	uxtb	w16, w5
     92c:      	cmp	w16, wzr
     930:      	b.eq	0x974 <_stogir.verify.structure+0x7d4>
     934:      	ldr	x9, [x26, #0x8]
     938:      	ldr	x10, [x27, #0x8]
     93c:      	cmp	x9, x10
     940:      	b.ne	0xa2c <_stogir.verify.structure+0x88c>
     944:      	cmp	x6, x9
     948:      	b.gt	0xb30 <_stogir.verify.structure+0x990>
     94c:      	ldr	x9, [x20, #0x50]
     950:      	add	x9, x8, x9
     954:      	ldr	w9, [x9]
     958:      	sxtw	x9, w9
     95c:      	cmp	x9, #0x0
     960:      	cset	w9, gt
     964:      	ubfx	x9, x9, #0, #8
     968:      	b	0xb34 <_stogir.verify.structure+0x994>
     96c:      	movz	x9, #0x0, lsl #48
     970:      	b	0x978 <_stogir.verify.structure+0x7d8>
     974:      	movz	x9, #0x0, lsl #48
     978:      	cmp	x9, #0x0
     97c:      	b.eq	0x9ac <_stogir.verify.structure+0x80c>
     980:      	uxtb	w16, w3
     984:      	cmp	w16, wzr
     988:      	b.eq	0x99c <_stogir.verify.structure+0x7fc>
     98c:      	lsl	x7, x1, #4
     990:      	ldr	x7, [x20]
     994:      	add	x7, x7, x1, lsl #4
     998:      	b	0x9a8 <_stogir.verify.structure+0x808>
     99c:      	lsl	x9, x7, #4
     9a0:      	ldr	x9, [x20, #0x28]
     9a4:      	add	x7, x9, x7, lsl #4
     9a8:      	b	0x9b0 <_stogir.verify.structure+0x810>
     9ac:      	movz	x7, #0x0, lsl #48
     9b0:      	cmp	x7, #0x0
     9b4:      	cset	w9, eq
     9b8:      	uxtb	w16, w9
     9bc:      	cmp	w16, wzr
     9c0:      	cset	x9, eq
     9c4:      	cmp	x9, #0x0
     9c8:      	b.eq	0x738 <_stogir.verify.structure+0x598>
     9cc:      	ldr	w7, [x7]
     9d0:      	uxtb	w7, w7
     9d4:      	cmp	x7, #0x48
     9d8:      	b.ne	0x738 <_stogir.verify.structure+0x598>
     9dc:      	ldr	x7, [sp, #0x88]
     9e0:      	mov	x10, #0x25              ; =37
     9e4:      	b	0x740 <_stogir.verify.structure+0x5a0>
     9e8:      	mov	w0, w23
     9ec:      	bl	0x9ec <_stogir.verify.structure+0x84c>
		00000000000009ec:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     9f0:      	lsr	w0, w0, #0
     9f4:      	sxtw	x0, w0
     9f8:      	cmn	x0, #0x1
     9fc:      	b.ne	0x880 <_stogir.verify.structure+0x6e0>
     a00:      	ubfx	x0, x21, #16, #16
     a04:      	cmp	x24, x0
     a08:      	b.eq	0x880 <_stogir.verify.structure+0x6e0>
     a0c:      	ldr	x0, [sp, #0x68]
     a10:      	mov	x1, #0x24               ; =36
     a14:      	b	0x888 <_stogir.verify.structure+0x6e8>
     a18:      	mov	x0, x1
     a1c:      	ldr	x1, [sp, #0x118]
     a20:      	b	0x56c <_stogir.verify.structure+0x3cc>
     a24:      	movz	x11, #0x0, lsl #48
     a28:      	b	0x774 <_stogir.verify.structure+0x5d4>
     a2c:      	movz	x9, #0x0, lsl #48
     a30:      	b	0x978 <_stogir.verify.structure+0x7d8>
     a34:      	movz	x9, #0x0, lsl #48
     a38:      	b	0x970 <_stogir.verify.structure+0x7d0>
     a3c:      	mov	x0, #0x1                ; =1
     a40:      	cmp	x0, #0x0
     a44:      	b.eq	0xa18 <_stogir.verify.structure+0x878>
     a48:      	ldr	x0, [sp, #0x98]
     a4c:      	mov	x1, #0x1a               ; =26
     a50:      	b	0xa20 <_stogir.verify.structure+0x880>
     a54:      	movz	x0, #0x0, lsl #48
     a58:      	ldr	x1, [sp, #0x120]
     a5c:      	cmp	x0, #0x0
     a60:      	b.eq	0xa3c <_stogir.verify.structure+0x89c>
     a64:      	movz	x0, #0x0, lsl #48
     a68:      	b	0xa40 <_stogir.verify.structure+0x8a0>
     a6c:      	movz	x3, #0x0, lsl #48
     a70:      	mov	x5, x9
     a74:      	cmp	x3, #0x0
     a78:      	b.eq	0xa9c <_stogir.verify.structure+0x8fc>
     a7c:      	str	x12, [sp, #0xd8]
     a80:      	str	x10, [sp, #0x118]
     a84:      	str	x2, [sp, #0xe0]
     a88:      	str	x0, [sp, #0xc8]
     a8c:      	str	x4, [sp, #0xc0]
     a90:      	mov	x1, x5
     a94:      	mov	x0, #0x1                ; =1
     a98:      	b	0xa5c <_stogir.verify.structure+0x8bc>
     a9c:      	cmp	x1, #0x0
     aa0:      	b.ne	0xd74 <_stogir.verify.structure+0xbd4>
     aa4:      	mov	w1, w24
     aa8:      	str	x2, [sp, #0xe0]
     aac:      	str	x12, [sp, #0xd8]
     ab0:      	str	x10, [sp, #0x118]
     ab4:      	str	x0, [sp, #0xc8]
     ab8:      	ldr	w0, [sp, #0xf0]
     abc:      	str	x4, [sp, #0xc0]
     ac0:      	str	x5, [sp, #0x120]
     ac4:      	bl	0xac4 <_stogir.verify.structure+0x924>
		0000000000000ac4:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     ac8:      	lsr	w0, w0, #0
     acc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000acc:  ARM64_RELOC_PAGE21	l_stogir.319
     ad0:      	ldr	x16, [x16]
		0000000000000ad0:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     ad4:      	ldr	w1, [x16]
     ad8:      	cmp	x0, x1
     adc:      	b.ne	0xba8 <_stogir.verify.structure+0xa08>
     ae0:      	mov	x0, #0x1                ; =1
     ae4:      	b	0xb3c <_stogir.verify.structure+0x99c>
     ae8:      	uxtb	w16, w3
     aec:      	cmp	w16, wzr
     af0:      	b.eq	0xd90 <_stogir.verify.structure+0xbf0>
     af4:      	ldr	x0, [x20, #0x8]
     af8:      	cmp	x1, x0
     afc:      	b.ge	0xd98 <_stogir.verify.structure+0xbf8>
     b00:      	ldr	x19, [sp, #0xd0]
     b04:      	ldr	x0, [x19, #0x8]
     b08:      	cmp	x1, x0
     b0c:      	b.ge	0xbcc <_stogir.verify.structure+0xa2c>
     b10:      	ldr	x0, [x20, #0x78]
     b14:      	add	x0, x4, x0
     b18:      	ldr	w0, [x0]
     b1c:      	sxtw	x0, w0
     b20:      	cmp	x0, #0x0
     b24:      	cset	w0, ge
     b28:      	ubfx	x0, x0, #0, #8
     b2c:      	b	0xbd0 <_stogir.verify.structure+0xa30>
     b30:      	movz	x9, #0x0, lsl #48
     b34:      	b	0xa30 <_stogir.verify.structure+0x890>
     b38:      	movz	x0, #0x0, lsl #48
     b3c:      	b	0xa58 <_stogir.verify.structure+0x8b8>
     b40:      	movz	x0, #0x0, lsl #48
     b44:      	ldr	x4, [sp, #0xc0]
     b48:      	mov	x3, x0
     b4c:      	ldr	x0, [sp, #0xc8]
     b50:      	b	0xa70 <_stogir.verify.structure+0x8d0>
     b54:      	uxtb	w16, w5
     b58:      	cmp	w16, wzr
     b5c:      	b.eq	0xda0 <_stogir.verify.structure+0xc00>
     b60:      	ldr	x0, [sp, #0xc8]
     b64:      	ldr	x3, [x0, #0x8]
     b68:      	ldr	x4, [sp, #0xc0]
     b6c:      	ldr	x5, [x4, #0x8]
     b70:      	cmp	x3, x5
     b74:      	b.ne	0xbc4 <_stogir.verify.structure+0xa24>
     b78:      	cmp	x6, x3
     b7c:      	b.gt	0xbf0 <_stogir.verify.structure+0xa50>
     b80:      	ldr	x3, [x20, #0x50]
     b84:      	add	x3, x8, x3
     b88:      	ldr	w3, [x3]
     b8c:      	sxtw	x3, w3
     b90:      	cmp	x3, #0x0
     b94:      	cset	w3, gt
     b98:      	ubfx	x3, x3, #0, #8
     b9c:      	b	0xbf4 <_stogir.verify.structure+0xa54>
     ba0:      	brk	#0
     ba4:      	b	0xba0 <_stogir.verify.structure+0xa00>
     ba8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ba8:  ARM64_RELOC_PAGE21	l_stogir.320
     bac:      	ldr	x16, [x16]
		0000000000000bac:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     bb0:      	ldr	w1, [x16]
     bb4:      	cmp	x0, x1
     bb8:      	b.ne	0xbd4 <_stogir.verify.structure+0xa34>
     bbc:      	mov	x0, #0x1                ; =1
     bc0:      	b	0xb3c <_stogir.verify.structure+0x99c>
     bc4:      	movz	x3, #0x0, lsl #48
     bc8:      	b	0xa70 <_stogir.verify.structure+0x8d0>
     bcc:      	movz	x0, #0x0, lsl #48
     bd0:      	b	0xb44 <_stogir.verify.structure+0x9a4>
     bd4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bd4:  ARM64_RELOC_PAGE21	l_stogir.321
     bd8:      	ldr	x16, [x16]
		0000000000000bd8:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     bdc:      	ldr	w1, [x16]
     be0:      	cmp	x0, x1
     be4:      	b.ne	0xbf8 <_stogir.verify.structure+0xa58>
     be8:      	mov	x0, #0x1                ; =1
     bec:      	b	0xb3c <_stogir.verify.structure+0x99c>
     bf0:      	movz	x3, #0x0, lsl #48
     bf4:      	b	0xbc8 <_stogir.verify.structure+0xa28>
     bf8:      	uxtb	w16, w22
     bfc:      	cmp	w16, wzr
     c00:      	b.eq	0xb38 <_stogir.verify.structure+0x998>
     c04:      	uxtb	w16, w28
     c08:      	cmp	w16, wzr
     c0c:      	b.eq	0xc2c <_stogir.verify.structure+0xa8c>
     c10:      	sxtw	x24, w24
     c14:      	cmp	x24, #0x2
     c18:      	cset	w0, eq
     c1c:      	ubfx	x0, x0, #0, #8
     c20:      	b	0xc30 <_stogir.verify.structure+0xa90>
     c24:      	brk	#0
     c28:      	b	0xc24 <_stogir.verify.structure+0xa84>
     c2c:      	movz	x0, #0x0, lsl #48
     c30:      	b	0xb3c <_stogir.verify.structure+0x99c>
     c34:      	mov	x1, x2
     c38:      	str	x8, [sp, #0xa0]
     c3c:      	str	x12, [sp, #0xb0]
     c40:      	str	x13, [sp, #0xb8]
     c44:      	b	0x4f0 <_stogir.verify.structure+0x350>
     c48:      	mov	x1, x2
     c4c:      	str	x8, [sp, #0xa0]
     c50:      	str	x12, [sp, #0xb0]
     c54:      	str	x13, [sp, #0xb8]
     c58:      	b	0x4f0 <_stogir.verify.structure+0x350>
     c5c:      	str	x8, [sp, #0xa0]
     c60:      	str	x19, [sp, #0x50]
     c64:      	str	x20, [sp, #0x58]
     c68:      	mov	x20, x0
     c6c:      	mov	x0, x1
     c70:      	mov	x1, x2
     c74:      	str	x21, [sp, #0x60]
     c78:      	str	x22, [sp, #0x68]
     c7c:      	str	x23, [sp, #0x70]
     c80:      	str	x24, [sp, #0x78]
     c84:      	str	x25, [sp, #0x80]
     c88:      	str	x26, [sp, #0x88]
     c8c:      	str	x27, [sp, #0x90]
     c90:      	str	x28, [sp, #0x98]
     c94:      	str	x3, [sp, #0xd8]
     c98:      	str	x11, [sp, #0xe0]
     c9c:      	mov	x19, x4
     ca0:      	str	x5, [sp, #0xc8]
     ca4:      	str	x6, [sp, #0xc0]
     ca8:      	mov	x25, x7
     cac:      	mov	x26, x9
     cb0:      	mov	x27, x10
     cb4:      	b	0x348 <_stogir.verify.structure+0x1a8>
     cb8:      	mov	x0, x1
     cbc:      	mov	x1, x2
     cc0:      	str	x8, [sp, #0xa0]
     cc4:      	str	x19, [sp, #0x50]
     cc8:      	str	x20, [sp, #0x58]
     ccc:      	ldr	x20, [sp, #0x30]
     cd0:      	str	x21, [sp, #0x60]
     cd4:      	str	x22, [sp, #0x68]
     cd8:      	str	x23, [sp, #0x70]
     cdc:      	str	x24, [sp, #0x78]
     ce0:      	str	x25, [sp, #0x80]
     ce4:      	str	x26, [sp, #0x88]
     ce8:      	str	x27, [sp, #0x90]
     cec:      	str	x28, [sp, #0x98]
     cf0:      	str	x3, [sp, #0xd8]
     cf4:      	str	x11, [sp, #0xe0]
     cf8:      	mov	x19, x4
     cfc:      	str	x5, [sp, #0xc8]
     d00:      	str	x6, [sp, #0xc0]
     d04:      	mov	x25, x7
     d08:      	mov	x26, x9
     d0c:      	mov	x27, x10
     d10:      	b	0x2e0 <_stogir.verify.structure+0x140>
     d14:      	mov	x0, x19
     d18:      	ldr	x1, [sp, #0xa8]
     d1c:      	ldr	x19, [sp, #0xd0]
     d20:      	b	0x2e0 <_stogir.verify.structure+0x140>
     d24:      	str	x19, [sp, #0x110]
     d28:      	str	x4, [sp, #0x100]
     d2c:      	str	x3, [sp, #0xf8]
     d30:      	ldr	x19, [sp, #0xd0]
     d34:      	b	0x200 <_stogir.verify.structure+0x60>
     d38:      	ldr	x12, [sp, #0xd8]
     d3c:      	ldr	x2, [sp, #0xe0]
     d40:      	b	0x7ac <_stogir.verify.structure+0x60c>
     d44:      	str	x12, [sp, #0xd8]
     d48:      	str	x10, [sp, #0x118]
     d4c:      	str	x2, [sp, #0xe0]
     d50:      	ldr	x19, [sp, #0xd0]
     d54:      	b	0x564 <_stogir.verify.structure+0x3c4>
     d58:      	str	x12, [sp, #0xd8]
     d5c:      	str	x10, [sp, #0x118]
     d60:      	str	x2, [sp, #0xe0]
     d64:      	ldr	x19, [sp, #0xd0]
     d68:      	b	0x564 <_stogir.verify.structure+0x3c4>
     d6c:      	ldr	x12, [sp, #0xd8]
     d70:      	b	0x770 <_stogir.verify.structure+0x5d0>
     d74:      	str	x12, [sp, #0xd8]
     d78:      	str	x5, [sp, #0x120]
     d7c:      	str	x10, [sp, #0x118]
     d80:      	str	x2, [sp, #0xe0]
     d84:      	str	x0, [sp, #0xc8]
     d88:      	str	x4, [sp, #0xc0]
     d8c:      	b	0xa54 <_stogir.verify.structure+0x8b4>
     d90:      	ldr	x19, [sp, #0xd0]
     d94:      	b	0xb54 <_stogir.verify.structure+0x9b4>
     d98:      	ldr	x19, [sp, #0xd0]
     d9c:      	b	0xb40 <_stogir.verify.structure+0x9a0>
     da0:      	ldr	x0, [sp, #0xc8]
     da4:      	ldr	x4, [sp, #0xc0]
     da8:      	b	0xa6c <_stogir.verify.structure+0x8cc>

0000000000000dac <_stogir.verify.integer-operations-target-structured>:
     dac:      	sub	sp, sp, #0x4a0
     db0:      	str	x29, [sp, #0x10]
     db4:      	str	x30, [sp, #0x18]
     db8:      	add	x29, sp, #0x10
     dbc:      	str	x19, [sp, #0x448]
     dc0:      	str	x20, [sp, #0x450]
     dc4:      	str	x21, [sp, #0x458]
     dc8:      	str	x22, [sp, #0x460]
     dcc:      	str	x23, [sp, #0x468]
     dd0:      	str	x24, [sp, #0x470]
     dd4:      	str	x25, [sp, #0x478]
     dd8:      	str	x26, [sp, #0x480]
     ddc:      	str	x27, [sp, #0x488]
     de0:      	str	x28, [sp, #0x490]
     de4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000de4:  ARM64_RELOC_PAGE21	l_stogir.322
     de8:      	ldr	x16, [x16]
		0000000000000de8:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     dec:      	orr	x2, x16, xzr
     df0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000df0:  ARM64_RELOC_PAGE21	l_stogir.323
     df4:      	ldr	x16, [x16]
		0000000000000df4:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     df8:      	orr	x19, x16, xzr
     dfc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000dfc:  ARM64_RELOC_PAGE21	l_stogir.324
     e00:      	ldr	x16, [x16]
		0000000000000e00:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     e04:      	orr	x20, x16, xzr
     e08:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e08:  ARM64_RELOC_PAGE21	l_stogir.325
     e0c:      	ldr	x16, [x16]
		0000000000000e0c:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     e10:      	orr	x21, x16, xzr
     e14:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e14:  ARM64_RELOC_PAGE21	l_stogir.326
     e18:      	ldr	x16, [x16]
		0000000000000e18:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     e1c:      	orr	x22, x16, xzr
     e20:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e20:  ARM64_RELOC_PAGE21	l_stogir.327
     e24:      	ldr	x16, [x16]
		0000000000000e24:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     e28:      	orr	x23, x16, xzr
     e2c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e2c:  ARM64_RELOC_PAGE21	l_stogir.328
     e30:      	ldr	x16, [x16]
		0000000000000e30:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     e34:      	orr	x24, x16, xzr
     e38:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e38:  ARM64_RELOC_PAGE21	l_stogir.329
     e3c:      	ldr	x16, [x16]
		0000000000000e3c:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     e40:      	orr	x25, x16, xzr
     e44:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e44:  ARM64_RELOC_PAGE21	l_stogir.330
     e48:      	ldr	x16, [x16]
		0000000000000e48:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     e4c:      	orr	x26, x16, xzr
     e50:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e50:  ARM64_RELOC_PAGE21	l_stogir.331
     e54:      	ldr	x16, [x16]
		0000000000000e54:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     e58:      	orr	x27, x16, xzr
     e5c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e5c:  ARM64_RELOC_PAGE21	l_stogir.332
     e60:      	ldr	x16, [x16]
		0000000000000e60:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     e64:      	orr	x28, x16, xzr
     e68:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e68:  ARM64_RELOC_PAGE21	l_stogir.333
     e6c:      	ldr	x16, [x16]
		0000000000000e6c:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     e70:      	orr	x3, x16, xzr
     e74:      	lsr	w4, w1, #0
     e78:      	lsr	w5, w1, #0
     e7c:      	lsr	w1, w1, #0
     e80:      	add	x16, sp, #0x20
     e84:      	orr	x6, x16, xzr
     e88:      	add	x16, sp, #0x30
     e8c:      	orr	x7, x16, xzr
     e90:      	add	x7, x7, #0x8
     e94:      	add	x16, sp, #0x50
     e98:      	orr	x9, x16, xzr
     e9c:      	add	x9, x9, #0x8
     ea0:      	add	x16, sp, #0xe0
     ea4:      	orr	x10, x16, xzr
     ea8:      	add	x10, x10, #0x8
     eac:      	add	x16, sp, #0x100
     eb0:      	orr	x11, x16, xzr
     eb4:      	add	x11, x11, #0x8
     eb8:      	add	x16, sp, #0x120
     ebc:      	orr	x12, x16, xzr
     ec0:      	add	x12, x12, #0x8
     ec4:      	add	x16, sp, #0x140
     ec8:      	orr	x13, x16, xzr
     ecc:      	add	x13, x13, #0x8
     ed0:      	add	x16, sp, #0x160
     ed4:      	orr	x14, x16, xzr
     ed8:      	add	x14, x14, #0x8
     edc:      	add	x16, sp, #0x180
     ee0:      	orr	x15, x16, xzr
     ee4:      	add	x15, x15, #0x8
     ee8:      	str	w1, [sp, #0x230]
     eec:      	add	x16, sp, #0x1a0
     ef0:      	orr	x1, x16, xzr
     ef4:      	add	x1, x1, #0x8
     ef8:      	str	x1, [sp, #0x238]
     efc:      	add	x16, sp, #0x1f0
     f00:      	orr	x1, x16, xzr
     f04:      	add	x1, x1, #0x8
     f08:      	str	x19, [sp, #0x240]
     f0c:      	str	x20, [sp, #0x250]
     f10:      	str	x2, [sp, #0x248]
     f14:      	mov	x2, #0x1                ; =1
     f18:      	movz	x19, #0x0, lsl #48
     f1c:      	movz	x20, #0x0, lsl #48
     f20:      	cmp	x20, #0x0
     f24:      	b.ne	0x2208 <_stogir.verify.integer-operations-target-structured+0x145c>
     f28:      	str	x1, [sp, #0x258]
     f2c:      	ldr	x1, [x0, #0x8]
     f30:      	cmp	x2, x1
     f34:      	b.ge	0x2214 <_stogir.verify.integer-operations-target-structured+0x1468>
     f38:      	lsl	x1, x2, #4
     f3c:      	lsl	x1, x2, #2
     f40:      	ldr	x1, [x0]
     f44:      	add	x1, x1, x2, lsl #4
     f48:      	str	x3, [sp, #0x260]
     f4c:      	ldr	x3, [x1]
     f50:      	str	x21, [sp, #0x268]
     f54:      	uxtb	w21, w3
     f58:      	ldr	x1, [x1, #0x8]
     f5c:      	str	x22, [sp, #0x270]
     f60:      	orr	x22, x21, xzr
     f64:      	add	x16, sp, #0x20
     f68:      	str	x3, [x16]
     f6c:      	add	x16, sp, #0x20
     f70:      	str	x1, [x16, #0x8]
     f74:      	ldr	x1, [x0, #0x78]
     f78:      	add	x1, x1, x2, lsl #2
     f7c:      	ldr	w1, [x1]
     f80:      	cmp	x22, #0xe
     f84:      	b.lt	0x17a0 <_stogir.verify.integer-operations-target-structured+0x9f4>
     f88:      	cmp	x22, #0x17
     f8c:      	cset	w3, le
     f90:      	ubfx	x3, x3, #0, #8
     f94:      	str	x23, [sp, #0x278]
     f98:      	cmp	x22, #0x1a
     f9c:      	cset	w23, ge
     fa0:      	str	x24, [sp, #0x280]
     fa4:      	cmp	x22, #0x1e
     fa8:      	cset	w24, le
     fac:      	str	x25, [sp, #0x288]
     fb0:      	cmp	x22, #0x2e
     fb4:      	cset	w25, ge
     fb8:      	str	x26, [sp, #0x290]
     fbc:      	cmp	x22, #0x35
     fc0:      	cset	w26, le
     fc4:      	str	x27, [sp, #0x298]
     fc8:      	cmp	x22, #0x3a
     fcc:      	cset	w27, eq
     fd0:      	str	x28, [sp, #0x2a0]
     fd4:      	cmp	x22, #0x3b
     fd8:      	cset	w28, eq
     fdc:      	uxtb	w16, w23
     fe0:      	cmp	w16, wzr
     fe4:      	b.eq	0x17a8 <_stogir.verify.integer-operations-target-structured+0x9fc>
     fe8:      	uxtb	w16, w24
     fec:      	cmp	w16, wzr
     ff0:      	b.eq	0x17a8 <_stogir.verify.integer-operations-target-structured+0x9fc>
     ff4:      	str	x0, [sp, #0x2a8]
     ff8:      	mov	x0, #0x1                ; =1
     ffc:      	cmp	x22, #0x1f
    1000:      	b.ne	0x17f0 <_stogir.verify.integer-operations-target-structured+0xa44>
    1004:      	str	x0, [sp, #0x2b0]
    1008:      	mov	x0, #0x1                ; =1
    100c:      	str	x0, [sp, #0x2b8]
    1010:      	lsr	w0, w2, #0
    1014:      	lsr	w1, w1, #0
    1018:      	lsr	w0, w0, #0
    101c:      	str	x8, [sp, #0x2c0]
    1020:      	str	w4, [sp, #0x2d0]
    1024:      	str	w5, [sp, #0x2d8]
    1028:      	str	x6, [sp, #0x2e0]
    102c:      	str	x15, [sp, #0x320]
    1030:      	str	x2, [sp, #0x328]
    1034:      	mov	x2, x6
    1038:      	str	w1, [sp, #0x330]
    103c:      	str	x3, [sp, #0x338]
    1040:      	mov	w3, w1
    1044:      	mov	w1, w0
    1048:      	str	w0, [sp, #0x340]
    104c:      	ldr	x0, [sp, #0x2a8]
    1050:      	str	x20, [sp, #0x2c8]
    1054:      	ldr	x20, [sp, #0x260]
    1058:      	str	w28, [sp, #0x2e8]
    105c:      	mov	x28, x7
    1060:      	str	w27, [sp, #0x2f0]
    1064:      	mov	x27, x9
    1068:      	str	w26, [sp, #0x2f8]
    106c:      	mov	x26, x10
    1070:      	str	w25, [sp, #0x300]
    1074:      	mov	x25, x11
    1078:      	str	w24, [sp, #0x308]
    107c:      	mov	x24, x12
    1080:      	str	w23, [sp, #0x310]
    1084:      	mov	x23, x13
    1088:      	str	w21, [sp, #0x318]
    108c:      	mov	x21, x14
    1090:      	bl	0x1090 <_stogir.verify.integer-operations-target-structured+0x2e4>
		0000000000001090:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    1094:      	uxtb	w1, w0
    1098:      	cmp	x1, #0x0
    109c:      	cset	w1, ne
    10a0:      	cmp	x22, #0x3d
    10a4:      	b.lt	0x1868 <_stogir.verify.integer-operations-target-structured+0xabc>
    10a8:      	cmp	x22, #0x3f
    10ac:      	b.gt	0x1868 <_stogir.verify.integer-operations-target-structured+0xabc>
    10b0:      	add	x8, sp, #0x30
    10b4:      	ldr	w2, [sp, #0x2d0]
    10b8:      	str	x0, [sp, #0x348]
    10bc:      	ldr	x0, [sp, #0x2a8]
    10c0:      	str	x21, [sp, #0x350]
    10c4:      	mov	w21, w1
    10c8:      	ldr	w1, [sp, #0x340]
    10cc:      	bl	0x10cc <_stogir.verify.integer-operations-target-structured+0x320>
		00000000000010cc:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    10d0:      	add	x16, sp, #0x30
    10d4:      	ldr	w0, [x16]
    10d8:      	lsr	x16, x0, #0
    10dc:      	cmp	x16, #0x1
    10e0:      	b.eq	0x10fc <_stogir.verify.integer-operations-target-structured+0x350>
    10e4:      	b.lo	0x10ec <_stogir.verify.integer-operations-target-structured+0x340>
    10e8:      	b	0x1100 <_stogir.verify.integer-operations-target-structured+0x354>
    10ec:      	cmp	x16, #0x0
    10f0:      	b.eq	0x10f8 <_stogir.verify.integer-operations-target-structured+0x34c>
    10f4:      	b	0x1100 <_stogir.verify.integer-operations-target-structured+0x354>
    10f8:      	b	0x188c <_stogir.verify.integer-operations-target-structured+0xae0>
    10fc:      	b	0x1104 <_stogir.verify.integer-operations-target-structured+0x358>
    1100:      	b	0x218c <_stogir.verify.integer-operations-target-structured+0x13e0>
    1104:      	add	x16, sp, #0x30
    1108:      	ldr	x0, [x16, #0x8]
    110c:      	ldr	x1, [x28, #0x8]
    1110:      	mov	x2, x1
    1114:      	mov	x1, x0
    1118:      	mov	x0, x19
    111c:      	mov	x19, x0
    1120:      	mov	x0, x1
    1124:      	mov	x1, x2
    1128:      	cmp	x22, #0x44
    112c:      	b.ne	0x18b0 <_stogir.verify.integer-operations-target-structured+0xb04>
    1130:      	uxtb	w16, w21
    1134:      	cmp	w16, wzr
    1138:      	b.eq	0x18a4 <_stogir.verify.integer-operations-target-structured+0xaf8>
    113c:      	mov	x2, x0
    1140:      	movz	x0, #0x0, lsl #48
    1144:      	fmov	d31, x1
    1148:      	mov	x1, x2
    114c:      	fmov	x2, d31
    1150:      	cmp	x0, #0x0
    1154:      	b.eq	0x2220 <_stogir.verify.integer-operations-target-structured+0x1474>
    1158:      	add	x8, sp, #0x50
    115c:      	ldr	x0, [sp, #0x2a8]
    1160:      	str	x1, [sp, #0x358]
    1164:      	ldr	w1, [sp, #0x340]
    1168:      	str	x2, [sp, #0x360]
    116c:      	bl	0x116c <_stogir.verify.integer-operations-target-structured+0x3c0>
		000000000000116c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    1170:      	add	x16, sp, #0x50
    1174:      	ldr	w0, [x16]
    1178:      	lsr	x16, x0, #0
    117c:      	cmp	x16, #0x1
    1180:      	b.eq	0x119c <_stogir.verify.integer-operations-target-structured+0x3f0>
    1184:      	b.lo	0x118c <_stogir.verify.integer-operations-target-structured+0x3e0>
    1188:      	b	0x11a0 <_stogir.verify.integer-operations-target-structured+0x3f4>
    118c:      	cmp	x16, #0x0
    1190:      	b.eq	0x1198 <_stogir.verify.integer-operations-target-structured+0x3ec>
    1194:      	b	0x11a0 <_stogir.verify.integer-operations-target-structured+0x3f4>
    1198:      	b	0x18c0 <_stogir.verify.integer-operations-target-structured+0xb14>
    119c:      	b	0x11a4 <_stogir.verify.integer-operations-target-structured+0x3f8>
    11a0:      	b	0x18d8 <_stogir.verify.integer-operations-target-structured+0xb2c>
    11a4:      	add	x16, sp, #0x50
    11a8:      	ldr	x0, [x16, #0x8]
    11ac:      	ldr	x1, [x27, #0x8]
    11b0:      	mov	x2, x1
    11b4:      	mov	x1, x0
    11b8:      	mov	x0, x19
    11bc:      	mov	x19, x0
    11c0:      	mov	x0, x1
    11c4:      	mov	x1, x2
    11c8:      	cmp	x22, #0x1d
    11cc:      	b.ne	0x18ec <_stogir.verify.integer-operations-target-structured+0xb40>
    11d0:      	mov	x2, x1
    11d4:      	mov	x1, x0
    11d8:      	mov	x0, #0x1                ; =1
    11dc:      	cmp	x0, #0x0
    11e0:      	b.eq	0x1914 <_stogir.verify.integer-operations-target-structured+0xb68>
    11e4:      	add	x16, sp, #0x20
    11e8:      	ldr	w0, [x16, #0xc]
    11ec:      	sxtw	x0, w0
    11f0:      	cmp	x0, #0x0
    11f4:      	b.ne	0x190c <_stogir.verify.integer-operations-target-structured+0xb60>
    11f8:      	movz	x0, #0x0, lsl #48
    11fc:      	cmp	x0, #0x0
    1200:      	b.eq	0x222c <_stogir.verify.integer-operations-target-structured+0x1480>
    1204:      	add	x16, sp, #0x20
    1208:      	ldr	w0, [x16, #0xc]
    120c:      	lsr	w0, w0, #0
    1210:      	add	x8, sp, #0x70
    1214:      	str	x1, [sp, #0x368]
    1218:      	mov	w1, w0
    121c:      	ldr	x0, [sp, #0x2a8]
    1220:      	str	x2, [sp, #0x370]
    1224:      	bl	0x1224 <_stogir.verify.integer-operations-target-structured+0x478>
		0000000000001224:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1228:      	add	x16, sp, #0x70
    122c:      	ldr	w0, [x16]
    1230:      	lsr	x16, x0, #0
    1234:      	cmp	x16, #0x1
    1238:      	b.eq	0x1254 <_stogir.verify.integer-operations-target-structured+0x4a8>
    123c:      	b.lo	0x1244 <_stogir.verify.integer-operations-target-structured+0x498>
    1240:      	b	0x1258 <_stogir.verify.integer-operations-target-structured+0x4ac>
    1244:      	cmp	x16, #0x0
    1248:      	b.eq	0x1250 <_stogir.verify.integer-operations-target-structured+0x4a4>
    124c:      	b	0x1258 <_stogir.verify.integer-operations-target-structured+0x4ac>
    1250:      	b	0x125c <_stogir.verify.integer-operations-target-structured+0x4b0>
    1254:      	b	0x191c <_stogir.verify.integer-operations-target-structured+0xb70>
    1258:      	b	0x19d0 <_stogir.verify.integer-operations-target-structured+0xc24>
    125c:      	ldr	x0, [sp, #0x240]
    1260:      	mov	x1, #0x16               ; =22
    1264:      	cmp	x22, #0x2c
    1268:      	cset	w2, eq
    126c:      	cmp	x22, #0x29
    1270:      	b.lt	0x19e4 <_stogir.verify.integer-operations-target-structured+0xc38>
    1274:      	cmp	x22, #0x2b
    1278:      	b.gt	0x19e4 <_stogir.verify.integer-operations-target-structured+0xc38>
    127c:      	uxtb	w16, w2
    1280:      	cmp	w16, wzr
    1284:      	b.eq	0x2238 <_stogir.verify.integer-operations-target-structured+0x148c>
    1288:      	add	x8, sp, #0xa0
    128c:      	str	x0, [sp, #0x378]
    1290:      	ldr	x0, [sp, #0x2a8]
    1294:      	str	x1, [sp, #0x380]
    1298:      	ldr	w1, [sp, #0x340]
    129c:      	bl	0x129c <_stogir.verify.integer-operations-target-structured+0x4f0>
		000000000000129c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    12a0:      	add	x16, sp, #0xa0
    12a4:      	ldr	x0, [x16]
    12a8:      	add	x16, sp, #0xa0
    12ac:      	ldr	x1, [x16, #0x8]
    12b0:      	add	x16, sp, #0xa0
    12b4:      	ldr	x2, [x16, #0x10]
    12b8:      	lsr	w0, w0, #0
    12bc:      	lsr	x16, x0, #0
    12c0:      	cmp	x16, #0x1
    12c4:      	b.eq	0x12e0 <_stogir.verify.integer-operations-target-structured+0x534>
    12c8:      	b.lo	0x12d0 <_stogir.verify.integer-operations-target-structured+0x524>
    12cc:      	b	0x12e4 <_stogir.verify.integer-operations-target-structured+0x538>
    12d0:      	cmp	x16, #0x0
    12d4:      	b.eq	0x12dc <_stogir.verify.integer-operations-target-structured+0x530>
    12d8:      	b	0x12e4 <_stogir.verify.integer-operations-target-structured+0x538>
    12dc:      	b	0x1a20 <_stogir.verify.integer-operations-target-structured+0xc74>
    12e0:      	b	0x12e8 <_stogir.verify.integer-operations-target-structured+0x53c>
    12e4:      	b	0x2184 <_stogir.verify.integer-operations-target-structured+0x13d8>
    12e8:      	mov	x0, x19
    12ec:      	mov	x19, x0
    12f0:      	mov	x0, x1
    12f4:      	mov	x1, x2
    12f8:      	cmp	x22, #0x7e
    12fc:      	b.lt	0x2244 <_stogir.verify.integer-operations-target-structured+0x1498>
    1300:      	cmp	x22, #0x82
    1304:      	b.gt	0x2250 <_stogir.verify.integer-operations-target-structured+0x14a4>
    1308:      	add	x8, sp, #0xe0
    130c:      	str	x0, [sp, #0x388]
    1310:      	ldr	x0, [sp, #0x2a8]
    1314:      	str	x1, [sp, #0x390]
    1318:      	ldr	w1, [sp, #0x340]
    131c:      	bl	0x131c <_stogir.verify.integer-operations-target-structured+0x570>
		000000000000131c:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    1320:      	add	x16, sp, #0xe0
    1324:      	ldr	w0, [x16]
    1328:      	lsr	x16, x0, #0
    132c:      	cmp	x16, #0x1
    1330:      	b.eq	0x134c <_stogir.verify.integer-operations-target-structured+0x5a0>
    1334:      	b.lo	0x133c <_stogir.verify.integer-operations-target-structured+0x590>
    1338:      	b	0x1350 <_stogir.verify.integer-operations-target-structured+0x5a4>
    133c:      	cmp	x16, #0x0
    1340:      	b.eq	0x1348 <_stogir.verify.integer-operations-target-structured+0x59c>
    1344:      	b	0x1350 <_stogir.verify.integer-operations-target-structured+0x5a4>
    1348:      	b	0x1a38 <_stogir.verify.integer-operations-target-structured+0xc8c>
    134c:      	b	0x1354 <_stogir.verify.integer-operations-target-structured+0x5a8>
    1350:      	b	0x1a50 <_stogir.verify.integer-operations-target-structured+0xca4>
    1354:      	add	x16, sp, #0xe0
    1358:      	ldr	x0, [x16, #0x8]
    135c:      	ldr	x1, [x26, #0x8]
    1360:      	mov	x2, x1
    1364:      	mov	x1, x0
    1368:      	mov	x0, x19
    136c:      	mov	x19, x0
    1370:      	mov	x0, x1
    1374:      	mov	x1, x2
    1378:      	cmp	x22, #0x60
    137c:      	b.eq	0x1a64 <_stogir.verify.integer-operations-target-structured+0xcb8>
    1380:      	cmp	x22, #0x79
    1384:      	b.eq	0x1a64 <_stogir.verify.integer-operations-target-structured+0xcb8>
    1388:      	cmp	x22, #0x75
    138c:      	b.eq	0x1af0 <_stogir.verify.integer-operations-target-structured+0xd44>
    1390:      	cmp	x22, #0x6d
    1394:      	b.lt	0x225c <_stogir.verify.integer-operations-target-structured+0x14b0>
    1398:      	cmp	x22, #0x6f
    139c:      	b.le	0x1af0 <_stogir.verify.integer-operations-target-structured+0xd44>
    13a0:      	str	x0, [sp, #0x3a8]
    13a4:      	str	x1, [sp, #0x3b0]
    13a8:      	ldr	x0, [sp, #0x3a8]
    13ac:      	ldr	x1, [sp, #0x3b0]
    13b0:      	cmp	x22, #0x42
    13b4:      	b.eq	0x1b84 <_stogir.verify.integer-operations-target-structured+0xdd8>
    13b8:      	cmp	x22, #0x51
    13bc:      	b.eq	0x1b84 <_stogir.verify.integer-operations-target-structured+0xdd8>
    13c0:      	cmp	x22, #0x52
    13c4:      	b.eq	0x1b84 <_stogir.verify.integer-operations-target-structured+0xdd8>
    13c8:      	cmp	x22, #0x53
    13cc:      	b.eq	0x1b84 <_stogir.verify.integer-operations-target-structured+0xdd8>
    13d0:      	cmp	x22, #0x54
    13d4:      	b.eq	0x1b84 <_stogir.verify.integer-operations-target-structured+0xdd8>
    13d8:      	cmp	x22, #0x41
    13dc:      	b.eq	0x1c10 <_stogir.verify.integer-operations-target-structured+0xe64>
    13e0:      	cmp	x22, #0x48
    13e4:      	b.eq	0x1c10 <_stogir.verify.integer-operations-target-structured+0xe64>
    13e8:      	cmp	x22, #0x55
    13ec:      	b.lt	0x2268 <_stogir.verify.integer-operations-target-structured+0x14bc>
    13f0:      	cmp	x22, #0x58
    13f4:      	b.le	0x1c10 <_stogir.verify.integer-operations-target-structured+0xe64>
    13f8:      	str	x0, [sp, #0x3c8]
    13fc:      	str	x1, [sp, #0x3d0]
    1400:      	ldr	x1, [sp, #0x350]
    1404:      	ldr	x0, [sp, #0x3c8]
    1408:      	ldr	x2, [sp, #0x3d0]
    140c:      	cmp	x22, #0x21
    1410:      	b.lt	0x2278 <_stogir.verify.integer-operations-target-structured+0x14cc>
    1414:      	cmp	x22, #0x27
    1418:      	b.gt	0x228c <_stogir.verify.integer-operations-target-structured+0x14e0>
    141c:      	add	x8, sp, #0x180
    1420:      	str	x1, [sp, #0x350]
    1424:      	ldr	w1, [sp, #0x340]
    1428:      	str	x0, [sp, #0x3d8]
    142c:      	ldr	x0, [sp, #0x2a8]
    1430:      	str	x2, [sp, #0x3e0]
    1434:      	ldr	w2, [sp, #0x230]
    1438:      	bl	0x1438 <_stogir.verify.integer-operations-target-structured+0x68c>
		0000000000001438:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    143c:      	add	x16, sp, #0x180
    1440:      	ldr	w0, [x16]
    1444:      	lsr	x16, x0, #0
    1448:      	cmp	x16, #0x1
    144c:      	b.eq	0x146c <_stogir.verify.integer-operations-target-structured+0x6c0>
    1450:      	b.lo	0x1458 <_stogir.verify.integer-operations-target-structured+0x6ac>
    1454:      	b	0x1470 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1458:      	cmp	x16, #0x0
    145c:      	b.eq	0x1464 <_stogir.verify.integer-operations-target-structured+0x6b8>
    1460:      	b	0x1470 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1464:      	ldr	x1, [sp, #0x320]
    1468:      	b	0x1cb0 <_stogir.verify.integer-operations-target-structured+0xf04>
    146c:      	b	0x1474 <_stogir.verify.integer-operations-target-structured+0x6c8>
    1470:      	b	0x1cc8 <_stogir.verify.integer-operations-target-structured+0xf1c>
    1474:      	add	x16, sp, #0x180
    1478:      	ldr	x0, [x16, #0x8]
    147c:      	ldr	x1, [sp, #0x320]
    1480:      	ldr	x2, [x1, #0x8]
    1484:      	mov	x3, x2
    1488:      	mov	x2, x0
    148c:      	mov	x0, x19
    1490:      	mov	x19, x0
    1494:      	mov	x0, x2
    1498:      	mov	x2, x3
    149c:      	cmp	x22, #0x3c
    14a0:      	b.ne	0x22a0 <_stogir.verify.integer-operations-target-structured+0x14f4>
    14a4:      	add	x8, sp, #0x1a0
    14a8:      	str	x1, [sp, #0x320]
    14ac:      	ldr	w1, [sp, #0x340]
    14b0:      	str	x0, [sp, #0x3e8]
    14b4:      	ldr	x0, [sp, #0x2a8]
    14b8:      	str	x2, [sp, #0x3f0]
    14bc:      	bl	0x14bc <_stogir.verify.integer-operations-target-structured+0x710>
		00000000000014bc:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    14c0:      	add	x16, sp, #0x1a0
    14c4:      	ldr	w0, [x16]
    14c8:      	lsr	x16, x0, #0
    14cc:      	cmp	x16, #0x1
    14d0:      	b.eq	0x14f0 <_stogir.verify.integer-operations-target-structured+0x744>
    14d4:      	b.lo	0x14dc <_stogir.verify.integer-operations-target-structured+0x730>
    14d8:      	b	0x14f4 <_stogir.verify.integer-operations-target-structured+0x748>
    14dc:      	cmp	x16, #0x0
    14e0:      	b.eq	0x14e8 <_stogir.verify.integer-operations-target-structured+0x73c>
    14e4:      	b	0x14f4 <_stogir.verify.integer-operations-target-structured+0x748>
    14e8:      	ldr	x1, [sp, #0x238]
    14ec:      	b	0x1cdc <_stogir.verify.integer-operations-target-structured+0xf30>
    14f0:      	b	0x14f8 <_stogir.verify.integer-operations-target-structured+0x74c>
    14f4:      	b	0x1cf4 <_stogir.verify.integer-operations-target-structured+0xf48>
    14f8:      	add	x16, sp, #0x1a0
    14fc:      	ldr	x0, [x16, #0x8]
    1500:      	ldr	x1, [sp, #0x238]
    1504:      	ldr	x2, [x1, #0x8]
    1508:      	mov	x3, x2
    150c:      	mov	x2, x0
    1510:      	mov	x0, x19
    1514:      	mov	x19, x0
    1518:      	mov	x0, x2
    151c:      	mov	x2, x3
    1520:      	cmp	x22, #0x78
    1524:      	b.ne	0x22b4 <_stogir.verify.integer-operations-target-structured+0x1508>
    1528:      	add	x16, sp, #0x20
    152c:      	ldr	w3, [x16]
    1530:      	ubfx	x3, x3, #8, #8
    1534:      	cmp	x3, #0x0
    1538:      	b.ne	0x1d08 <_stogir.verify.integer-operations-target-structured+0xf5c>
    153c:      	add	x16, sp, #0x20
    1540:      	ldr	w3, [x16, #0x8]
    1544:      	sxtw	x3, w3
    1548:      	cmp	x3, #0x0
    154c:      	b.eq	0x1558 <_stogir.verify.integer-operations-target-structured+0x7ac>
    1550:      	ldr	x0, [sp, #0x268]
    1554:      	mov	x2, #0x1f               ; =31
    1558:      	str	x1, [sp, #0x238]
    155c:      	mov	x1, x2
    1560:      	add	x2, x19, #0x1
    1564:      	lsr	w2, w2, #0
    1568:      	sxtw	x2, w2
    156c:      	mov	x19, x2
    1570:      	ldr	x2, [sp, #0x348]
    1574:      	uxth	w2, w2
    1578:      	mov	w17, #0x8               ; =8
    157c:      	uxth	w16, w2
    1580:      	ubfx	w17, w17, #0, #4
    1584:      	lsr	w2, w16, w17
    1588:      	uxth	w2, w2
    158c:      	uxtb	w2, w2
    1590:      	cmp	x2, #0x0
    1594:      	b.eq	0x22c4 <_stogir.verify.integer-operations-target-structured+0x1518>
    1598:      	add	x8, sp, #0x1f0
    159c:      	str	x0, [sp, #0x408]
    15a0:      	ldr	x0, [sp, #0x2a8]
    15a4:      	str	x1, [sp, #0x410]
    15a8:      	ldr	w1, [sp, #0x340]
    15ac:      	str	x20, [sp, #0x260]
    15b0:      	mov	x20, x2
    15b4:      	bl	0x15b4 <_stogir.verify.integer-operations-target-structured+0x808>
		00000000000015b4:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    15b8:      	add	x16, sp, #0x1f0
    15bc:      	ldr	w0, [x16]
    15c0:      	lsr	x16, x0, #0
    15c4:      	cmp	x16, #0x1
    15c8:      	b.eq	0x15e8 <_stogir.verify.integer-operations-target-structured+0x83c>
    15cc:      	b.lo	0x15d4 <_stogir.verify.integer-operations-target-structured+0x828>
    15d0:      	b	0x15ec <_stogir.verify.integer-operations-target-structured+0x840>
    15d4:      	cmp	x16, #0x0
    15d8:      	b.eq	0x15e0 <_stogir.verify.integer-operations-target-structured+0x834>
    15dc:      	b	0x15ec <_stogir.verify.integer-operations-target-structured+0x840>
    15e0:      	ldr	x1, [sp, #0x258]
    15e4:      	b	0x1dc0 <_stogir.verify.integer-operations-target-structured+0x1014>
    15e8:      	b	0x15f0 <_stogir.verify.integer-operations-target-structured+0x844>
    15ec:      	b	0x1dd8 <_stogir.verify.integer-operations-target-structured+0x102c>
    15f0:      	add	x16, sp, #0x1f0
    15f4:      	ldr	x0, [x16, #0x8]
    15f8:      	ldr	x1, [sp, #0x258]
    15fc:      	ldr	x2, [x1, #0x8]
    1600:      	mov	x3, x2
    1604:      	mov	x2, x0
    1608:      	mov	x0, x19
    160c:      	mov	x19, x0
    1610:      	mov	x0, x2
    1614:      	mov	x2, x3
    1618:      	uxtb	w16, w21
    161c:      	cmp	w16, wzr
    1620:      	b.eq	0x1dec <_stogir.verify.integer-operations-target-structured+0x1040>
    1624:      	mov	x3, x2
    1628:      	mov	x2, x0
    162c:      	movz	x0, #0x0, lsl #48
    1630:      	cmp	x0, #0x0
    1634:      	b.eq	0x22dc <_stogir.verify.integer-operations-target-structured+0x1530>
    1638:      	cmp	x20, #0x0
    163c:      	b.eq	0x1dfc <_stogir.verify.integer-operations-target-structured+0x1050>
    1640:      	movz	x0, #0x0, lsl #48
    1644:      	cmp	x0, #0x0
    1648:      	b.eq	0x22e8 <_stogir.verify.integer-operations-target-structured+0x153c>
    164c:      	ldr	x20, [sp, #0x338]
    1650:      	cmp	x20, #0x0
    1654:      	b.eq	0x1e04 <_stogir.verify.integer-operations-target-structured+0x1058>
    1658:      	ldr	x21, [sp, #0x2b0]
    165c:      	mov	x0, #0x1                ; =1
    1660:      	cmp	x0, #0x0
    1664:      	b.eq	0x22f4 <_stogir.verify.integer-operations-target-structured+0x1548>
    1668:      	add	x16, sp, #0x210
    166c:      	str	x16, [sp]
    1670:      	ldr	x0, [sp, #0x2a8]
    1674:      	str	x1, [sp, #0x258]
    1678:      	ldr	w1, [sp, #0x340]
    167c:      	str	x2, [sp, #0x418]
    1680:      	str	x3, [sp, #0x420]
    1684:      	mov	x2, #0x1                ; =1
    1688:      	bl	0x1688 <_stogir.verify.integer-operations-target-structured+0x8dc>
		0000000000001688:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    168c:      	ldr	x16, [sp]
    1690:      	str	x0, [x16]
    1694:      	str	x1, [x16, #0x8]
    1698:      	add	x16, sp, #0x210
    169c:      	ldr	x0, [x16]
    16a0:      	add	x16, sp, #0x210
    16a4:      	ldr	x1, [x16, #0x8]
    16a8:      	lsr	w0, w0, #0
    16ac:      	lsr	x16, x0, #0
    16b0:      	cmp	x16, #0x1
    16b4:      	b.eq	0x16d0 <_stogir.verify.integer-operations-target-structured+0x924>
    16b8:      	b.lo	0x16c0 <_stogir.verify.integer-operations-target-structured+0x914>
    16bc:      	b	0x16d4 <_stogir.verify.integer-operations-target-structured+0x928>
    16c0:      	cmp	x16, #0x0
    16c4:      	b.eq	0x16cc <_stogir.verify.integer-operations-target-structured+0x920>
    16c8:      	b	0x16d4 <_stogir.verify.integer-operations-target-structured+0x928>
    16cc:      	b	0x16d8 <_stogir.verify.integer-operations-target-structured+0x92c>
    16d0:      	b	0x1e30 <_stogir.verify.integer-operations-target-structured+0x1084>
    16d4:      	b	0x215c <_stogir.verify.integer-operations-target-structured+0x13b0>
    16d8:      	str	x26, [sp, #0x440]
    16dc:      	str	x25, [sp, #0x438]
    16e0:      	str	x24, [sp, #0x430]
    16e4:      	str	x23, [sp, #0x428]
    16e8:      	ldr	x0, [sp, #0x280]
    16ec:      	mov	x1, #0x17               ; =23
    16f0:      	add	x2, x19, #0x1
    16f4:      	lsr	w2, w2, #0
    16f8:      	sxtw	x2, w2
    16fc:      	fmov	d31, x0
    1700:      	mov	x0, x2
    1704:      	mov	x2, x1
    1708:      	fmov	x1, d31
    170c:      	ldr	w3, [sp, #0x330]
    1710:      	sxtw	x3, w3
    1714:      	add	x3, x3, #0x4
    1718:      	asr	x16, x3, #63
    171c:      	lsr	x16, x16, #62
    1720:      	add	x3, x3, x16
    1724:      	asr	x3, x3, #2
    1728:      	ldr	x4, [sp, #0x328]
    172c:      	add	x3, x3, x4
    1730:      	ldr	x8, [sp, #0x2c0]
    1734:      	ldr	x6, [sp, #0x2e0]
    1738:      	ldr	x21, [sp, #0x268]
    173c:      	ldr	x22, [sp, #0x270]
    1740:      	ldr	x23, [sp, #0x278]
    1744:      	ldr	x24, [sp, #0x280]
    1748:      	ldr	x25, [sp, #0x288]
    174c:      	ldr	x26, [sp, #0x290]
    1750:      	ldr	w4, [sp, #0x2d0]
    1754:      	mov	x7, x28
    1758:      	ldr	x28, [sp, #0x2a0]
    175c:      	mov	x9, x27
    1760:      	ldr	x27, [sp, #0x298]
    1764:      	ldr	x10, [sp, #0x440]
    1768:      	ldr	x11, [sp, #0x438]
    176c:      	ldr	x12, [sp, #0x430]
    1770:      	ldr	x13, [sp, #0x428]
    1774:      	ldr	w5, [sp, #0x2d8]
    1778:      	ldr	x14, [sp, #0x350]
    177c:      	ldr	x15, [sp, #0x320]
    1780:      	mov	x19, x0
    1784:      	ldr	x0, [sp, #0x2a8]
    1788:      	str	x1, [sp, #0x248]
    178c:      	ldr	x1, [sp, #0x258]
    1790:      	mov	x20, x2
    1794:      	mov	x2, x3
    1798:      	ldr	x3, [sp, #0x260]
    179c:      	b	0xf20 <_stogir.verify.integer-operations-target-structured+0x174>
    17a0:      	movz	x3, #0x0, lsl #48
    17a4:      	b	0xf94 <_stogir.verify.integer-operations-target-structured+0x1e8>
    17a8:      	uxtb	w16, w25
    17ac:      	cmp	w16, wzr
    17b0:      	b.eq	0x17cc <_stogir.verify.integer-operations-target-structured+0xa20>
    17b4:      	uxtb	w16, w26
    17b8:      	cmp	w16, wzr
    17bc:      	b.eq	0x17cc <_stogir.verify.integer-operations-target-structured+0xa20>
    17c0:      	str	x0, [sp, #0x2a8]
    17c4:      	mov	x0, #0x1                ; =1
    17c8:      	b	0xffc <_stogir.verify.integer-operations-target-structured+0x250>
    17cc:      	uxtb	w16, w27
    17d0:      	cmp	w16, wzr
    17d4:      	b.eq	0x17e4 <_stogir.verify.integer-operations-target-structured+0xa38>
    17d8:      	str	x0, [sp, #0x2a8]
    17dc:      	mov	x0, #0x1                ; =1
    17e0:      	b	0x17c8 <_stogir.verify.integer-operations-target-structured+0xa1c>
    17e4:      	str	x0, [sp, #0x2a8]
    17e8:      	ubfx	x0, x28, #0, #8
    17ec:      	b	0x17e0 <_stogir.verify.integer-operations-target-structured+0xa34>
    17f0:      	cmp	x22, #0x20
    17f4:      	b.ne	0x1804 <_stogir.verify.integer-operations-target-structured+0xa58>
    17f8:      	str	x0, [sp, #0x2b0]
    17fc:      	mov	x0, #0x1                ; =1
    1800:      	b	0x100c <_stogir.verify.integer-operations-target-structured+0x260>
    1804:      	cmp	x22, #0x2d
    1808:      	b.ne	0x1818 <_stogir.verify.integer-operations-target-structured+0xa6c>
    180c:      	str	x0, [sp, #0x2b0]
    1810:      	mov	x0, #0x1                ; =1
    1814:      	b	0x1800 <_stogir.verify.integer-operations-target-structured+0xa54>
    1818:      	cmp	x22, #0x36
    181c:      	b.ne	0x182c <_stogir.verify.integer-operations-target-structured+0xa80>
    1820:      	str	x0, [sp, #0x2b0]
    1824:      	mov	x0, #0x1                ; =1
    1828:      	b	0x1814 <_stogir.verify.integer-operations-target-structured+0xa68>
    182c:      	cmp	x22, #0x37
    1830:      	b.ne	0x1840 <_stogir.verify.integer-operations-target-structured+0xa94>
    1834:      	str	x0, [sp, #0x2b0]
    1838:      	mov	x0, #0x1                ; =1
    183c:      	b	0x1828 <_stogir.verify.integer-operations-target-structured+0xa7c>
    1840:      	cmp	x22, #0x38
    1844:      	b.ne	0x1854 <_stogir.verify.integer-operations-target-structured+0xaa8>
    1848:      	str	x0, [sp, #0x2b0]
    184c:      	mov	x0, #0x1                ; =1
    1850:      	b	0x183c <_stogir.verify.integer-operations-target-structured+0xa90>
    1854:      	str	x0, [sp, #0x2b0]
    1858:      	cmp	x22, #0x39
    185c:      	cset	w0, eq
    1860:      	ubfx	x0, x0, #0, #8
    1864:      	b	0x1850 <_stogir.verify.integer-operations-target-structured+0xaa4>
    1868:      	uxtb	w16, w1
    186c:      	cmp	w16, wzr
    1870:      	b.ne	0x10b0 <_stogir.verify.integer-operations-target-structured+0x304>
    1874:      	str	x0, [sp, #0x348]
    1878:      	str	x21, [sp, #0x350]
    187c:      	mov	w21, w1
    1880:      	ldr	x0, [sp, #0x248]
    1884:      	ldr	x1, [sp, #0x2c8]
    1888:      	b	0x1128 <_stogir.verify.integer-operations-target-structured+0x37c>
    188c:      	add	x0, x19, #0x1
    1890:      	lsr	w0, w0, #0
    1894:      	sxtw	x0, w0
    1898:      	ldr	x1, [sp, #0x248]
    189c:      	ldr	x2, [sp, #0x2c8]
    18a0:      	b	0x111c <_stogir.verify.integer-operations-target-structured+0x370>
    18a4:      	mov	x2, x0
    18a8:      	mov	x0, #0x1                ; =1
    18ac:      	b	0x1144 <_stogir.verify.integer-operations-target-structured+0x398>
    18b0:      	mov	x2, x1
    18b4:      	mov	x1, x0
    18b8:      	movz	x0, #0x0, lsl #48
    18bc:      	b	0x1150 <_stogir.verify.integer-operations-target-structured+0x3a4>
    18c0:      	add	x0, x19, #0x1
    18c4:      	lsr	w0, w0, #0
    18c8:      	sxtw	x0, w0
    18cc:      	ldr	x1, [sp, #0x358]
    18d0:      	ldr	x2, [sp, #0x360]
    18d4:      	b	0x11bc <_stogir.verify.integer-operations-target-structured+0x410>
    18d8:      	brk	#0
    18dc:      	b	0x18d8 <_stogir.verify.integer-operations-target-structured+0xb2c>
    18e0:      	ldr	x0, [sp, #0x358]
    18e4:      	ldr	x1, [sp, #0x360]
    18e8:      	b	0x11c8 <_stogir.verify.integer-operations-target-structured+0x41c>
    18ec:      	cmp	x22, #0x1e
    18f0:      	cset	w2, eq
    18f4:      	ubfx	x2, x2, #0, #8
    18f8:      	fmov	d31, x0
    18fc:      	mov	x0, x2
    1900:      	mov	x2, x1
    1904:      	fmov	x1, d31
    1908:      	b	0x11dc <_stogir.verify.integer-operations-target-structured+0x430>
    190c:      	mov	x0, #0x1                ; =1
    1910:      	b	0x11fc <_stogir.verify.integer-operations-target-structured+0x450>
    1914:      	movz	x0, #0x0, lsl #48
    1918:      	b	0x11fc <_stogir.verify.integer-operations-target-structured+0x450>
    191c:      	add	x16, sp, #0x70
    1920:      	ldr	x0, [x16, #0x8]
    1924:      	add	x16, sp, #0x20
    1928:      	ldr	w1, [x16, #0xc]
    192c:      	sxtw	x1, w1
    1930:      	cmp	x1, #0x0
    1934:      	b.ge	0x1958 <_stogir.verify.integer-operations-target-structured+0xbac>
    1938:      	ldr	x1, [sp, #0x368]
    193c:      	ldr	x2, [sp, #0x370]
    1940:      	mov	x0, #0x1                ; =1
    1944:      	cmp	x0, #0x0
    1948:      	b.eq	0x19c4 <_stogir.verify.integer-operations-target-structured+0xc18>
    194c:      	ldr	x0, [sp, #0x250]
    1950:      	mov	x1, #0x2d               ; =45
    1954:      	b	0x1264 <_stogir.verify.integer-operations-target-structured+0x4b8>
    1958:      	uxtb	w0, w0
    195c:      	cmp	x0, #0x83
    1960:      	b.ge	0x19b4 <_stogir.verify.integer-operations-target-structured+0xc08>
    1964:      	add	x1, x0, x20
    1968:      	ldrb	w1, [x1]
    196c:      	uxtb	w1, w1
    1970:      	and	x1, x1, #0x2
    1974:      	uxtb	w1, w1
    1978:      	cmp	x1, #0x0
    197c:      	cset	w1, eq
    1980:      	uxtb	w16, w1
    1984:      	cmp	w16, wzr
    1988:      	cset	x1, eq
    198c:      	cmp	x1, #0x0
    1990:      	b.ne	0x19bc <_stogir.verify.integer-operations-target-structured+0xc10>
    1994:      	cmp	x0, #0x65
    1998:      	b.eq	0x19bc <_stogir.verify.integer-operations-target-structured+0xc10>
    199c:      	cmp	x0, #0x66
    19a0:      	b.eq	0x19bc <_stogir.verify.integer-operations-target-structured+0xc10>
    19a4:      	mov	x0, #0x1                ; =1
    19a8:      	ldr	x1, [sp, #0x368]
    19ac:      	ldr	x2, [sp, #0x370]
    19b0:      	b	0x1944 <_stogir.verify.integer-operations-target-structured+0xb98>
    19b4:      	movz	x1, #0x0, lsl #48
    19b8:      	b	0x196c <_stogir.verify.integer-operations-target-structured+0xbc0>
    19bc:      	movz	x0, #0x0, lsl #48
    19c0:      	b	0x19a8 <_stogir.verify.integer-operations-target-structured+0xbfc>
    19c4:      	mov	x0, x1
    19c8:      	mov	x1, x2
    19cc:      	b	0x1954 <_stogir.verify.integer-operations-target-structured+0xba8>
    19d0:      	brk	#0
    19d4:      	b	0x19d0 <_stogir.verify.integer-operations-target-structured+0xc24>
    19d8:      	ldr	x0, [sp, #0x368]
    19dc:      	ldr	x1, [sp, #0x370]
    19e0:      	b	0x1264 <_stogir.verify.integer-operations-target-structured+0x4b8>
    19e4:      	uxtb	w16, w2
    19e8:      	cmp	w16, wzr
    19ec:      	b.ne	0x127c <_stogir.verify.integer-operations-target-structured+0x4d0>
    19f0:      	b	0x12f8 <_stogir.verify.integer-operations-target-structured+0x54c>
    19f4:      	add	x8, sp, #0xc0
    19f8:      	ldr	x0, [sp, #0x2a8]
    19fc:      	ldr	w1, [sp, #0x340]
    1a00:      	bl	0x1a00 <_stogir.verify.integer-operations-target-structured+0xc54>
		0000000000001a00:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1a04:      	add	x16, sp, #0xc0
    1a08:      	ldr	x0, [x16]
    1a0c:      	add	x16, sp, #0xc0
    1a10:      	ldr	x1, [x16, #0x8]
    1a14:      	add	x16, sp, #0xc0
    1a18:      	ldr	x2, [x16, #0x10]
    1a1c:      	b	0x12b8 <_stogir.verify.integer-operations-target-structured+0x50c>
    1a20:      	add	x0, x19, #0x1
    1a24:      	lsr	w0, w0, #0
    1a28:      	sxtw	x0, w0
    1a2c:      	ldr	x1, [sp, #0x378]
    1a30:      	ldr	x2, [sp, #0x380]
    1a34:      	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x540>
    1a38:      	add	x0, x19, #0x1
    1a3c:      	lsr	w0, w0, #0
    1a40:      	sxtw	x0, w0
    1a44:      	ldr	x1, [sp, #0x388]
    1a48:      	ldr	x2, [sp, #0x390]
    1a4c:      	b	0x136c <_stogir.verify.integer-operations-target-structured+0x5c0>
    1a50:      	brk	#0
    1a54:      	b	0x1a50 <_stogir.verify.integer-operations-target-structured+0xca4>
    1a58:      	ldr	x0, [sp, #0x388]
    1a5c:      	ldr	x1, [sp, #0x390]
    1a60:      	b	0x1378 <_stogir.verify.integer-operations-target-structured+0x5cc>
    1a64:      	add	x8, sp, #0x100
    1a68:      	str	x0, [sp, #0x398]
    1a6c:      	ldr	x0, [sp, #0x2a8]
    1a70:      	str	x1, [sp, #0x3a0]
    1a74:      	ldr	w1, [sp, #0x340]
    1a78:      	bl	0x1a78 <_stogir.verify.integer-operations-target-structured+0xccc>
		0000000000001a78:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    1a7c:      	add	x16, sp, #0x100
    1a80:      	ldr	w0, [x16]
    1a84:      	lsr	x16, x0, #0
    1a88:      	cmp	x16, #0x1
    1a8c:      	b.eq	0x1aa8 <_stogir.verify.integer-operations-target-structured+0xcfc>
    1a90:      	b.lo	0x1a98 <_stogir.verify.integer-operations-target-structured+0xcec>
    1a94:      	b	0x1aac <_stogir.verify.integer-operations-target-structured+0xd00>
    1a98:      	cmp	x16, #0x0
    1a9c:      	b.eq	0x1aa4 <_stogir.verify.integer-operations-target-structured+0xcf8>
    1aa0:      	b	0x1aac <_stogir.verify.integer-operations-target-structured+0xd00>
    1aa4:      	b	0x1ad8 <_stogir.verify.integer-operations-target-structured+0xd2c>
    1aa8:      	b	0x1ab0 <_stogir.verify.integer-operations-target-structured+0xd04>
    1aac:      	b	0x217c <_stogir.verify.integer-operations-target-structured+0x13d0>
    1ab0:      	add	x16, sp, #0x100
    1ab4:      	ldr	x0, [x16, #0x8]
    1ab8:      	ldr	x1, [x25, #0x8]
    1abc:      	mov	x2, x1
    1ac0:      	mov	x1, x0
    1ac4:      	mov	x0, x19
    1ac8:      	mov	x19, x0
    1acc:      	mov	x0, x1
    1ad0:      	mov	x1, x2
    1ad4:      	b	0x1388 <_stogir.verify.integer-operations-target-structured+0x5dc>
    1ad8:      	add	x0, x19, #0x1
    1adc:      	lsr	w0, w0, #0
    1ae0:      	sxtw	x0, w0
    1ae4:      	ldr	x1, [sp, #0x398]
    1ae8:      	ldr	x2, [sp, #0x3a0]
    1aec:      	b	0x1ac8 <_stogir.verify.integer-operations-target-structured+0xd1c>
    1af0:      	add	x8, sp, #0x120
    1af4:      	str	x0, [sp, #0x3a8]
    1af8:      	ldr	x0, [sp, #0x2a8]
    1afc:      	str	x1, [sp, #0x3b0]
    1b00:      	ldr	w1, [sp, #0x340]
    1b04:      	bl	0x1b04 <_stogir.verify.integer-operations-target-structured+0xd58>
		0000000000001b04:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    1b08:      	add	x16, sp, #0x120
    1b0c:      	ldr	w0, [x16]
    1b10:      	lsr	x16, x0, #0
    1b14:      	cmp	x16, #0x1
    1b18:      	b.eq	0x1b34 <_stogir.verify.integer-operations-target-structured+0xd88>
    1b1c:      	b.lo	0x1b24 <_stogir.verify.integer-operations-target-structured+0xd78>
    1b20:      	b	0x1b38 <_stogir.verify.integer-operations-target-structured+0xd8c>
    1b24:      	cmp	x16, #0x0
    1b28:      	b.eq	0x1b30 <_stogir.verify.integer-operations-target-structured+0xd84>
    1b2c:      	b	0x1b38 <_stogir.verify.integer-operations-target-structured+0xd8c>
    1b30:      	b	0x1b64 <_stogir.verify.integer-operations-target-structured+0xdb8>
    1b34:      	b	0x1b3c <_stogir.verify.integer-operations-target-structured+0xd90>
    1b38:      	b	0x1b7c <_stogir.verify.integer-operations-target-structured+0xdd0>
    1b3c:      	add	x16, sp, #0x120
    1b40:      	ldr	x0, [x16, #0x8]
    1b44:      	ldr	x1, [x24, #0x8]
    1b48:      	mov	x2, x1
    1b4c:      	mov	x1, x0
    1b50:      	mov	x0, x19
    1b54:      	mov	x19, x0
    1b58:      	mov	x0, x1
    1b5c:      	mov	x1, x2
    1b60:      	b	0x13b0 <_stogir.verify.integer-operations-target-structured+0x604>
    1b64:      	add	x0, x19, #0x1
    1b68:      	lsr	w0, w0, #0
    1b6c:      	sxtw	x0, w0
    1b70:      	ldr	x1, [sp, #0x3a8]
    1b74:      	ldr	x2, [sp, #0x3b0]
    1b78:      	b	0x1b54 <_stogir.verify.integer-operations-target-structured+0xda8>
    1b7c:      	brk	#0
    1b80:      	b	0x1b7c <_stogir.verify.integer-operations-target-structured+0xdd0>
    1b84:      	add	x8, sp, #0x140
    1b88:      	str	x0, [sp, #0x3b8]
    1b8c:      	ldr	x0, [sp, #0x2a8]
    1b90:      	str	x1, [sp, #0x3c0]
    1b94:      	ldr	w1, [sp, #0x340]
    1b98:      	bl	0x1b98 <_stogir.verify.integer-operations-target-structured+0xdec>
		0000000000001b98:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    1b9c:      	add	x16, sp, #0x140
    1ba0:      	ldr	w0, [x16]
    1ba4:      	lsr	x16, x0, #0
    1ba8:      	cmp	x16, #0x1
    1bac:      	b.eq	0x1bc8 <_stogir.verify.integer-operations-target-structured+0xe1c>
    1bb0:      	b.lo	0x1bb8 <_stogir.verify.integer-operations-target-structured+0xe0c>
    1bb4:      	b	0x1bcc <_stogir.verify.integer-operations-target-structured+0xe20>
    1bb8:      	cmp	x16, #0x0
    1bbc:      	b.eq	0x1bc4 <_stogir.verify.integer-operations-target-structured+0xe18>
    1bc0:      	b	0x1bcc <_stogir.verify.integer-operations-target-structured+0xe20>
    1bc4:      	b	0x1bf8 <_stogir.verify.integer-operations-target-structured+0xe4c>
    1bc8:      	b	0x1bd0 <_stogir.verify.integer-operations-target-structured+0xe24>
    1bcc:      	b	0x2174 <_stogir.verify.integer-operations-target-structured+0x13c8>
    1bd0:      	add	x16, sp, #0x140
    1bd4:      	ldr	x0, [x16, #0x8]
    1bd8:      	ldr	x1, [x23, #0x8]
    1bdc:      	mov	x2, x1
    1be0:      	mov	x1, x0
    1be4:      	mov	x0, x19
    1be8:      	mov	x19, x0
    1bec:      	mov	x0, x1
    1bf0:      	mov	x1, x2
    1bf4:      	b	0x13d8 <_stogir.verify.integer-operations-target-structured+0x62c>
    1bf8:      	add	x0, x19, #0x1
    1bfc:      	lsr	w0, w0, #0
    1c00:      	sxtw	x0, w0
    1c04:      	ldr	x1, [sp, #0x3b8]
    1c08:      	ldr	x2, [sp, #0x3c0]
    1c0c:      	b	0x1be8 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1c10:      	add	x8, sp, #0x160
    1c14:      	ldr	w2, [sp, #0x2d8]
    1c18:      	str	x0, [sp, #0x3c8]
    1c1c:      	ldr	x0, [sp, #0x2a8]
    1c20:      	str	x1, [sp, #0x3d0]
    1c24:      	ldr	w1, [sp, #0x340]
    1c28:      	bl	0x1c28 <_stogir.verify.integer-operations-target-structured+0xe7c>
		0000000000001c28:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1c2c:      	add	x16, sp, #0x160
    1c30:      	ldr	w0, [x16]
    1c34:      	lsr	x16, x0, #0
    1c38:      	cmp	x16, #0x1
    1c3c:      	b.eq	0x1c5c <_stogir.verify.integer-operations-target-structured+0xeb0>
    1c40:      	b.lo	0x1c48 <_stogir.verify.integer-operations-target-structured+0xe9c>
    1c44:      	b	0x1c60 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1c48:      	cmp	x16, #0x0
    1c4c:      	b.eq	0x1c54 <_stogir.verify.integer-operations-target-structured+0xea8>
    1c50:      	b	0x1c60 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1c54:      	ldr	x1, [sp, #0x350]
    1c58:      	b	0x1c90 <_stogir.verify.integer-operations-target-structured+0xee4>
    1c5c:      	b	0x1c64 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1c60:      	b	0x1ca8 <_stogir.verify.integer-operations-target-structured+0xefc>
    1c64:      	add	x16, sp, #0x160
    1c68:      	ldr	x0, [x16, #0x8]
    1c6c:      	ldr	x1, [sp, #0x350]
    1c70:      	ldr	x2, [x1, #0x8]
    1c74:      	mov	x3, x2
    1c78:      	mov	x2, x0
    1c7c:      	mov	x0, x19
    1c80:      	mov	x19, x0
    1c84:      	mov	x0, x2
    1c88:      	mov	x2, x3
    1c8c:      	b	0x140c <_stogir.verify.integer-operations-target-structured+0x660>
    1c90:      	add	x0, x19, #0x1
    1c94:      	lsr	w0, w0, #0
    1c98:      	sxtw	x0, w0
    1c9c:      	ldr	x2, [sp, #0x3c8]
    1ca0:      	ldr	x3, [sp, #0x3d0]
    1ca4:      	b	0x1c80 <_stogir.verify.integer-operations-target-structured+0xed4>
    1ca8:      	brk	#0
    1cac:      	b	0x1ca8 <_stogir.verify.integer-operations-target-structured+0xefc>
    1cb0:      	add	x0, x19, #0x1
    1cb4:      	lsr	w0, w0, #0
    1cb8:      	sxtw	x0, w0
    1cbc:      	ldr	x2, [sp, #0x3d8]
    1cc0:      	ldr	x3, [sp, #0x3e0]
    1cc4:      	b	0x1490 <_stogir.verify.integer-operations-target-structured+0x6e4>
    1cc8:      	brk	#0
    1ccc:      	b	0x1cc8 <_stogir.verify.integer-operations-target-structured+0xf1c>
    1cd0:      	ldr	x0, [sp, #0x3d8]
    1cd4:      	ldr	x2, [sp, #0x3e0]
    1cd8:      	b	0x149c <_stogir.verify.integer-operations-target-structured+0x6f0>
    1cdc:      	add	x0, x19, #0x1
    1ce0:      	lsr	w0, w0, #0
    1ce4:      	sxtw	x0, w0
    1ce8:      	ldr	x2, [sp, #0x3e8]
    1cec:      	ldr	x3, [sp, #0x3f0]
    1cf0:      	b	0x1514 <_stogir.verify.integer-operations-target-structured+0x768>
    1cf4:      	brk	#0
    1cf8:      	b	0x1cf4 <_stogir.verify.integer-operations-target-structured+0xf48>
    1cfc:      	ldr	x0, [sp, #0x3e8]
    1d00:      	ldr	x2, [sp, #0x3f0]
    1d04:      	b	0x1520 <_stogir.verify.integer-operations-target-structured+0x774>
    1d08:      	add	x16, sp, #0x20
    1d0c:      	ldr	w3, [x16, #0x8]
    1d10:      	lsr	w3, w3, #0
    1d14:      	add	x8, sp, #0x1c0
    1d18:      	str	x1, [sp, #0x238]
    1d1c:      	mov	w1, w3
    1d20:      	str	x0, [sp, #0x3f8]
    1d24:      	ldr	x0, [sp, #0x2a8]
    1d28:      	str	x2, [sp, #0x400]
    1d2c:      	bl	0x1d2c <_stogir.verify.integer-operations-target-structured+0xf80>
		0000000000001d2c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1d30:      	add	x16, sp, #0x1c0
    1d34:      	ldr	w0, [x16]
    1d38:      	lsr	x16, x0, #0
    1d3c:      	cmp	x16, #0x1
    1d40:      	b.eq	0x1d5c <_stogir.verify.integer-operations-target-structured+0xfb0>
    1d44:      	b.lo	0x1d4c <_stogir.verify.integer-operations-target-structured+0xfa0>
    1d48:      	b	0x1d60 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1d4c:      	cmp	x16, #0x0
    1d50:      	b.eq	0x1d58 <_stogir.verify.integer-operations-target-structured+0xfac>
    1d54:      	b	0x1d60 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1d58:      	b	0x1d64 <_stogir.verify.integer-operations-target-structured+0xfb8>
    1d5c:      	b	0x1d70 <_stogir.verify.integer-operations-target-structured+0xfc4>
    1d60:      	b	0x1dac <_stogir.verify.integer-operations-target-structured+0x1000>
    1d64:      	ldr	x0, [sp, #0x270]
    1d68:      	mov	x1, #0x14               ; =20
    1d6c:      	b	0x1560 <_stogir.verify.integer-operations-target-structured+0x7b4>
    1d70:      	add	x16, sp, #0x1c0
    1d74:      	ldr	x0, [x16, #0x8]
    1d78:      	add	x16, sp, #0x20
    1d7c:      	ldr	w1, [x16]
    1d80:      	lsr	w0, w0, #0
    1d84:      	ubfx	x1, x1, #8, #8
    1d88:      	ubfx	x0, x0, #8, #8
    1d8c:      	cmp	x0, x1
    1d90:      	b.ne	0x1da0 <_stogir.verify.integer-operations-target-structured+0xff4>
    1d94:      	ldr	x0, [sp, #0x3f8]
    1d98:      	ldr	x1, [sp, #0x400]
    1d9c:      	b	0x1d6c <_stogir.verify.integer-operations-target-structured+0xfc0>
    1da0:      	ldr	x0, [sp, #0x278]
    1da4:      	mov	x1, #0x1a               ; =26
    1da8:      	b	0x1d9c <_stogir.verify.integer-operations-target-structured+0xff0>
    1dac:      	brk	#0
    1db0:      	b	0x1dac <_stogir.verify.integer-operations-target-structured+0x1000>
    1db4:      	ldr	x0, [sp, #0x3f8]
    1db8:      	ldr	x1, [sp, #0x400]
    1dbc:      	b	0x1570 <_stogir.verify.integer-operations-target-structured+0x7c4>
    1dc0:      	add	x0, x19, #0x1
    1dc4:      	lsr	w0, w0, #0
    1dc8:      	sxtw	x0, w0
    1dcc:      	ldr	x2, [sp, #0x408]
    1dd0:      	ldr	x3, [sp, #0x410]
    1dd4:      	b	0x160c <_stogir.verify.integer-operations-target-structured+0x860>
    1dd8:      	brk	#0
    1ddc:      	b	0x1dd8 <_stogir.verify.integer-operations-target-structured+0x102c>
    1de0:      	ldr	x0, [sp, #0x408]
    1de4:      	ldr	x2, [sp, #0x410]
    1de8:      	b	0x1618 <_stogir.verify.integer-operations-target-structured+0x86c>
    1dec:      	mov	x3, x2
    1df0:      	mov	x2, x0
    1df4:      	mov	x0, #0x1                ; =1
    1df8:      	b	0x1630 <_stogir.verify.integer-operations-target-structured+0x884>
    1dfc:      	mov	x0, #0x1                ; =1
    1e00:      	b	0x1644 <_stogir.verify.integer-operations-target-structured+0x898>
    1e04:      	ldr	x21, [sp, #0x2b0]
    1e08:      	cmp	x21, #0x0
    1e0c:      	b.eq	0x1e18 <_stogir.verify.integer-operations-target-structured+0x106c>
    1e10:      	mov	x0, #0x1                ; =1
    1e14:      	b	0x1660 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e18:      	ldr	x0, [sp, #0x2b8]
    1e1c:      	b	0x1e14 <_stogir.verify.integer-operations-target-structured+0x1068>
    1e20:      	movz	x0, #0x0, lsl #48
    1e24:      	b	0x1660 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e28:      	movz	x0, #0x0, lsl #48
    1e2c:      	b	0x1660 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e30:      	lsr	w1, w1, #0
    1e34:      	lsr	w1, w1, #0
    1e38:      	ldr	x0, [sp, #0x2a8]
    1e3c:      	bl	0x1e3c <_stogir.verify.integer-operations-target-structured+0x1090>
		0000000000001e3c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1e40:      	cmp	x0, #0x0
    1e44:      	b.ne	0x1e64 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1e48:      	str	x26, [sp, #0x440]
    1e4c:      	str	x25, [sp, #0x438]
    1e50:      	str	x24, [sp, #0x430]
    1e54:      	str	x23, [sp, #0x428]
    1e58:      	ldr	x0, [sp, #0x280]
    1e5c:      	mov	x1, #0x17               ; =23
    1e60:      	b	0x16f0 <_stogir.verify.integer-operations-target-structured+0x944>
    1e64:      	ldr	w0, [x0]
    1e68:      	add	x16, sp, #0x20
    1e6c:      	ldr	w1, [x16]
    1e70:      	ubfx	x0, x0, #8, #8
    1e74:      	orr	x2, x0, xzr
    1e78:      	ubfx	x1, x1, #8, #8
    1e7c:      	cmp	x1, #0x6
    1e80:      	b.ne	0x1fe8 <_stogir.verify.integer-operations-target-structured+0x123c>
    1e84:      	cmp	x2, #0x6
    1e88:      	b.ne	0x1fe0 <_stogir.verify.integer-operations-target-structured+0x1234>
    1e8c:      	cmp	x22, #0x1a
    1e90:      	b.ne	0x1fd0 <_stogir.verify.integer-operations-target-structured+0x1224>
    1e94:      	mov	x1, #0x1                ; =1
    1e98:      	cmp	x2, #0x1
    1e9c:      	cset	w3, ge
    1ea0:      	uxtb	w16, w3
    1ea4:      	cmp	w16, wzr
    1ea8:      	b.eq	0x2314 <_stogir.verify.integer-operations-target-structured+0x1568>
    1eac:      	cmp	x2, #0xb
    1eb0:      	cset	w4, le
    1eb4:      	uxtb	w16, w4
    1eb8:      	cmp	w16, wzr
    1ebc:      	b.eq	0x2330 <_stogir.verify.integer-operations-target-structured+0x1584>
    1ec0:      	ldr	x5, [sp, #0x2b8]
    1ec4:      	cmp	x5, #0x0
    1ec8:      	b.eq	0x234c <_stogir.verify.integer-operations-target-structured+0x15a0>
    1ecc:      	ldr	w5, [sp, #0x318]
    1ed0:      	lsr	w5, w5, #0
    1ed4:      	lsr	w0, w0, #0
    1ed8:      	str	x23, [sp, #0x428]
    1edc:      	mov	x23, x2
    1ee0:      	str	x24, [sp, #0x430]
    1ee4:      	mov	x24, x1
    1ee8:      	mov	w1, w0
    1eec:      	mov	w0, w5
    1ef0:      	str	x25, [sp, #0x438]
    1ef4:      	mov	w25, w3
    1ef8:      	str	x26, [sp, #0x440]
    1efc:      	mov	w26, w4
    1f00:      	bl	0x1f00 <_stogir.verify.integer-operations-target-structured+0x1154>
		0000000000001f00:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1f04:      	cmp	x0, #0x0
    1f08:      	b.ne	0x1ff0 <_stogir.verify.integer-operations-target-structured+0x1244>
    1f0c:      	ldr	x0, [sp, #0x288]
    1f10:      	mov	x1, #0x1c               ; =28
    1f14:      	add	x16, sp, #0x20
    1f18:      	ldr	w2, [x16]
    1f1c:      	cmp	x20, #0x0
    1f20:      	b.eq	0x20c0 <_stogir.verify.integer-operations-target-structured+0x1314>
    1f24:      	mov	x3, x0
    1f28:      	mov	x0, #0x1                ; =1
    1f2c:      	lsr	w0, w0, #0
    1f30:      	ubfx	x2, x2, #8, #8
    1f34:      	sxtw	x0, w0
    1f38:      	cmp	x2, x0
    1f3c:      	b.ne	0x20cc <_stogir.verify.integer-operations-target-structured+0x1320>
    1f40:      	mov	x0, x3
    1f44:      	mov	x22, x1
    1f48:      	cmp	x20, #0x0
    1f4c:      	b.eq	0x20d8 <_stogir.verify.integer-operations-target-structured+0x132c>
    1f50:      	mov	x20, x0
    1f54:      	mov	x0, #0x1                ; =1
    1f58:      	cmp	x0, #0x0
    1f5c:      	b.eq	0x2150 <_stogir.verify.integer-operations-target-structured+0x13a4>
    1f60:      	add	x16, sp, #0x220
    1f64:      	str	x16, [sp]
    1f68:      	ldr	x0, [sp, #0x2a8]
    1f6c:      	ldr	w1, [sp, #0x340]
    1f70:      	mov	x2, #0x2                ; =2
    1f74:      	bl	0x1f74 <_stogir.verify.integer-operations-target-structured+0x11c8>
		0000000000001f74:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1f78:      	ldr	x16, [sp]
    1f7c:      	str	x0, [x16]
    1f80:      	str	x1, [x16, #0x8]
    1f84:      	add	x16, sp, #0x220
    1f88:      	ldr	x0, [x16]
    1f8c:      	add	x16, sp, #0x220
    1f90:      	ldr	x1, [x16, #0x8]
    1f94:      	lsr	w0, w0, #0
    1f98:      	lsr	x16, x0, #0
    1f9c:      	cmp	x16, #0x1
    1fa0:      	b.eq	0x1fbc <_stogir.verify.integer-operations-target-structured+0x1210>
    1fa4:      	b.lo	0x1fac <_stogir.verify.integer-operations-target-structured+0x1200>
    1fa8:      	b	0x1fc0 <_stogir.verify.integer-operations-target-structured+0x1214>
    1fac:      	cmp	x16, #0x0
    1fb0:      	b.eq	0x1fb8 <_stogir.verify.integer-operations-target-structured+0x120c>
    1fb4:      	b	0x1fc0 <_stogir.verify.integer-operations-target-structured+0x1214>
    1fb8:      	b	0x1fc4 <_stogir.verify.integer-operations-target-structured+0x1218>
    1fbc:      	b	0x20e4 <_stogir.verify.integer-operations-target-structured+0x1338>
    1fc0:      	b	0x2148 <_stogir.verify.integer-operations-target-structured+0x139c>
    1fc4:      	ldr	x0, [sp, #0x298]
    1fc8:      	mov	x1, #0x1d               ; =29
    1fcc:      	b	0x1e60 <_stogir.verify.integer-operations-target-structured+0x10b4>
    1fd0:      	cmp	x22, #0x1b
    1fd4:      	cset	w1, eq
    1fd8:      	ubfx	x1, x1, #0, #8
    1fdc:      	b	0x1e98 <_stogir.verify.integer-operations-target-structured+0x10ec>
    1fe0:      	movz	x1, #0x0, lsl #48
    1fe4:      	b	0x1e98 <_stogir.verify.integer-operations-target-structured+0x10ec>
    1fe8:      	movz	x1, #0x0, lsl #48
    1fec:      	b	0x1e98 <_stogir.verify.integer-operations-target-structured+0x10ec>
    1ff0:      	cmp	x21, #0x0
    1ff4:      	b.eq	0x2068 <_stogir.verify.integer-operations-target-structured+0x12bc>
    1ff8:      	ldr	w0, [sp, #0x310]
    1ffc:      	uxtb	w16, w0
    2000:      	cmp	w16, wzr
    2004:      	b.eq	0x2074 <_stogir.verify.integer-operations-target-structured+0x12c8>
    2008:      	ldr	w0, [sp, #0x308]
    200c:      	uxtb	w16, w0
    2010:      	cmp	w16, wzr
    2014:      	b.eq	0x2074 <_stogir.verify.integer-operations-target-structured+0x12c8>
    2018:      	ldr	w0, [sp, #0x2f0]
    201c:      	uxtb	w16, w25
    2020:      	cmp	w16, wzr
    2024:      	b.eq	0x1f0c <_stogir.verify.integer-operations-target-structured+0x1160>
    2028:      	uxtb	w16, w26
    202c:      	cmp	w16, wzr
    2030:      	b.eq	0x1f0c <_stogir.verify.integer-operations-target-structured+0x1160>
    2034:      	cmp	x23, #0x1
    2038:      	b.ne	0x2068 <_stogir.verify.integer-operations-target-structured+0x12bc>
    203c:      	cmp	x22, #0x2e
    2040:      	b.eq	0x2068 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2044:      	cmp	x22, #0x2f
    2048:      	b.eq	0x2068 <_stogir.verify.integer-operations-target-structured+0x12bc>
    204c:      	cmp	x22, #0x30
    2050:      	b.eq	0x2068 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2054:      	uxtb	w16, w0
    2058:      	cmp	w16, wzr
    205c:      	b.ne	0x2068 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2060:      	cmp	x22, #0x3b
    2064:      	b.ne	0x1f0c <_stogir.verify.integer-operations-target-structured+0x1160>
    2068:      	ldr	x0, [sp, #0x418]
    206c:      	ldr	x1, [sp, #0x420]
    2070:      	b	0x1f14 <_stogir.verify.integer-operations-target-structured+0x1168>
    2074:      	ldr	w0, [sp, #0x300]
    2078:      	uxtb	w16, w0
    207c:      	cmp	w16, wzr
    2080:      	b.eq	0x209c <_stogir.verify.integer-operations-target-structured+0x12f0>
    2084:      	ldr	w0, [sp, #0x2f8]
    2088:      	uxtb	w16, w0
    208c:      	cmp	w16, wzr
    2090:      	b.eq	0x209c <_stogir.verify.integer-operations-target-structured+0x12f0>
    2094:      	ldr	w0, [sp, #0x2f0]
    2098:      	b	0x201c <_stogir.verify.integer-operations-target-structured+0x1270>
    209c:      	ldr	w0, [sp, #0x2f0]
    20a0:      	uxtb	w16, w0
    20a4:      	cmp	w16, wzr
    20a8:      	b.ne	0x201c <_stogir.verify.integer-operations-target-structured+0x1270>
    20ac:      	ldr	w1, [sp, #0x2e8]
    20b0:      	uxtb	w16, w1
    20b4:      	cmp	w16, wzr
    20b8:      	b.ne	0x201c <_stogir.verify.integer-operations-target-structured+0x1270>
    20bc:      	b	0x1f0c <_stogir.verify.integer-operations-target-structured+0x1160>
    20c0:      	mov	x3, x0
    20c4:      	mov	x0, x23
    20c8:      	b	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1180>
    20cc:      	ldr	x0, [sp, #0x290]
    20d0:      	mov	x22, #0x26              ; =38
    20d4:      	b	0x1f48 <_stogir.verify.integer-operations-target-structured+0x119c>
    20d8:      	mov	x20, x0
    20dc:      	mov	x0, x21
    20e0:      	b	0x1f58 <_stogir.verify.integer-operations-target-structured+0x11ac>
    20e4:      	lsr	w1, w1, #0
    20e8:      	lsr	w1, w1, #0
    20ec:      	ldr	x0, [sp, #0x2a8]
    20f0:      	bl	0x20f0 <_stogir.verify.integer-operations-target-structured+0x1344>
		00000000000020f0:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    20f4:      	cmp	x0, #0x0
    20f8:      	b.ne	0x2108 <_stogir.verify.integer-operations-target-structured+0x135c>
    20fc:      	ldr	x0, [sp, #0x298]
    2100:      	mov	x1, #0x1d               ; =29
    2104:      	b	0x1fcc <_stogir.verify.integer-operations-target-structured+0x1220>
    2108:      	ldr	w0, [x0]
    210c:      	ubfx	x0, x0, #8, #8
    2110:      	cmp	x23, x0
    2114:      	b.eq	0x2130 <_stogir.verify.integer-operations-target-structured+0x1384>
    2118:      	cmp	x24, #0x0
    211c:      	b.eq	0x213c <_stogir.verify.integer-operations-target-structured+0x1390>
    2120:      	cmp	x0, #0x5
    2124:      	b.eq	0x2130 <_stogir.verify.integer-operations-target-structured+0x1384>
    2128:      	cmp	x0, #0xb
    212c:      	b.ne	0x213c <_stogir.verify.integer-operations-target-structured+0x1390>
    2130:      	mov	x0, x20
    2134:      	mov	x1, x22
    2138:      	b	0x2104 <_stogir.verify.integer-operations-target-structured+0x1358>
    213c:      	ldr	x0, [sp, #0x2a0]
    2140:      	mov	x1, #0x1d               ; =29
    2144:      	b	0x2138 <_stogir.verify.integer-operations-target-structured+0x138c>
    2148:      	brk	#0
    214c:      	b	0x2148 <_stogir.verify.integer-operations-target-structured+0x139c>
    2150:      	mov	x0, x20
    2154:      	mov	x1, x22
    2158:      	b	0x1fcc <_stogir.verify.integer-operations-target-structured+0x1220>
    215c:      	brk	#0
    2160:      	b	0x215c <_stogir.verify.integer-operations-target-structured+0x13b0>
    2164:      	mov	x0, x19
    2168:      	ldr	x1, [sp, #0x418]
    216c:      	ldr	x2, [sp, #0x420]
    2170:      	b	0x170c <_stogir.verify.integer-operations-target-structured+0x960>
    2174:      	brk	#0
    2178:      	b	0x2174 <_stogir.verify.integer-operations-target-structured+0x13c8>
    217c:      	brk	#0
    2180:      	b	0x217c <_stogir.verify.integer-operations-target-structured+0x13d0>
    2184:      	brk	#0
    2188:      	b	0x2184 <_stogir.verify.integer-operations-target-structured+0x13d8>
    218c:      	brk	#0
    2190:      	b	0x218c <_stogir.verify.integer-operations-target-structured+0x13e0>
    2194:      	ldr	x0, [sp, #0x2c8]
    2198:      	cmp	x0, #0x0
    219c:      	b.ne	0x21f8 <_stogir.verify.integer-operations-target-structured+0x144c>
    21a0:      	and	x0, x19, #0xffffffff
    21a4:      	mov	x1, x0
    21a8:      	movz	x0, #0x0, lsl #48
    21ac:      	movz	x2, #0x0, lsl #48
    21b0:      	ldr	x3, [sp, #0x2c0]
    21b4:      	str	x0, [x3]
    21b8:      	str	x1, [x3, #0x8]
    21bc:      	str	x2, [x3, #0x10]
    21c0:      	ldr	x19, [sp, #0x448]
    21c4:      	ldr	x20, [sp, #0x450]
    21c8:      	ldr	x21, [sp, #0x458]
    21cc:      	ldr	x22, [sp, #0x460]
    21d0:      	ldr	x23, [sp, #0x468]
    21d4:      	ldr	x24, [sp, #0x470]
    21d8:      	ldr	x25, [sp, #0x478]
    21dc:      	ldr	x26, [sp, #0x480]
    21e0:      	ldr	x27, [sp, #0x488]
    21e4:      	ldr	x28, [sp, #0x490]
    21e8:      	ldr	x29, [sp, #0x10]
    21ec:      	ldr	x30, [sp, #0x18]
    21f0:      	add	sp, sp, #0x4a0
    21f4:      	ret
    21f8:      	ldr	x1, [sp, #0x248]
    21fc:      	mov	x2, x0
    2200:      	mov	x0, #0x1                ; =1
    2204:      	b	0x21b0 <_stogir.verify.integer-operations-target-structured+0x1404>
    2208:      	str	x8, [sp, #0x2c0]
    220c:      	str	x20, [sp, #0x2c8]
    2210:      	b	0x2194 <_stogir.verify.integer-operations-target-structured+0x13e8>
    2214:      	str	x8, [sp, #0x2c0]
    2218:      	str	x20, [sp, #0x2c8]
    221c:      	b	0x2194 <_stogir.verify.integer-operations-target-structured+0x13e8>
    2220:      	str	x1, [sp, #0x358]
    2224:      	str	x2, [sp, #0x360]
    2228:      	b	0x18e0 <_stogir.verify.integer-operations-target-structured+0xb34>
    222c:      	str	x1, [sp, #0x368]
    2230:      	str	x2, [sp, #0x370]
    2234:      	b	0x19d8 <_stogir.verify.integer-operations-target-structured+0xc2c>
    2238:      	str	x0, [sp, #0x378]
    223c:      	str	x1, [sp, #0x380]
    2240:      	b	0x19f4 <_stogir.verify.integer-operations-target-structured+0xc48>
    2244:      	str	x0, [sp, #0x388]
    2248:      	str	x1, [sp, #0x390]
    224c:      	b	0x1a58 <_stogir.verify.integer-operations-target-structured+0xcac>
    2250:      	str	x0, [sp, #0x388]
    2254:      	str	x1, [sp, #0x390]
    2258:      	b	0x1a58 <_stogir.verify.integer-operations-target-structured+0xcac>
    225c:      	str	x0, [sp, #0x3a8]
    2260:      	str	x1, [sp, #0x3b0]
    2264:      	b	0x13a8 <_stogir.verify.integer-operations-target-structured+0x5fc>
    2268:      	str	x0, [sp, #0x3c8]
    226c:      	str	x1, [sp, #0x3d0]
    2270:      	ldr	x1, [sp, #0x350]
    2274:      	b	0x1404 <_stogir.verify.integer-operations-target-structured+0x658>
    2278:      	str	x1, [sp, #0x350]
    227c:      	ldr	x1, [sp, #0x320]
    2280:      	str	x0, [sp, #0x3d8]
    2284:      	str	x2, [sp, #0x3e0]
    2288:      	b	0x1cd0 <_stogir.verify.integer-operations-target-structured+0xf24>
    228c:      	str	x1, [sp, #0x350]
    2290:      	ldr	x1, [sp, #0x320]
    2294:      	str	x0, [sp, #0x3d8]
    2298:      	str	x2, [sp, #0x3e0]
    229c:      	b	0x1cd0 <_stogir.verify.integer-operations-target-structured+0xf24>
    22a0:      	str	x1, [sp, #0x320]
    22a4:      	ldr	x1, [sp, #0x238]
    22a8:      	str	x0, [sp, #0x3e8]
    22ac:      	str	x2, [sp, #0x3f0]
    22b0:      	b	0x1cfc <_stogir.verify.integer-operations-target-structured+0xf50>
    22b4:      	str	x1, [sp, #0x238]
    22b8:      	str	x0, [sp, #0x3f8]
    22bc:      	str	x2, [sp, #0x400]
    22c0:      	b	0x1db4 <_stogir.verify.integer-operations-target-structured+0x1008>
    22c4:      	str	x0, [sp, #0x408]
    22c8:      	str	x1, [sp, #0x410]
    22cc:      	ldr	x1, [sp, #0x258]
    22d0:      	str	x20, [sp, #0x260]
    22d4:      	mov	x20, x2
    22d8:      	b	0x1de0 <_stogir.verify.integer-operations-target-structured+0x1034>
    22dc:      	ldr	x20, [sp, #0x338]
    22e0:      	ldr	x21, [sp, #0x2b0]
    22e4:      	b	0x1e28 <_stogir.verify.integer-operations-target-structured+0x107c>
    22e8:      	ldr	x20, [sp, #0x338]
    22ec:      	ldr	x21, [sp, #0x2b0]
    22f0:      	b	0x1e20 <_stogir.verify.integer-operations-target-structured+0x1074>
    22f4:      	str	x26, [sp, #0x440]
    22f8:      	str	x25, [sp, #0x438]
    22fc:      	str	x24, [sp, #0x430]
    2300:      	str	x23, [sp, #0x428]
    2304:      	str	x1, [sp, #0x258]
    2308:      	str	x2, [sp, #0x418]
    230c:      	str	x3, [sp, #0x420]
    2310:      	b	0x2164 <_stogir.verify.integer-operations-target-structured+0x13b8>
    2314:      	str	x26, [sp, #0x440]
    2318:      	str	x25, [sp, #0x438]
    231c:      	str	x24, [sp, #0x430]
    2320:      	mov	x24, x1
    2324:      	str	x23, [sp, #0x428]
    2328:      	mov	x23, x2
    232c:      	b	0x1f0c <_stogir.verify.integer-operations-target-structured+0x1160>
    2330:      	str	x26, [sp, #0x440]
    2334:      	str	x25, [sp, #0x438]
    2338:      	str	x24, [sp, #0x430]
    233c:      	mov	x24, x1
    2340:      	str	x23, [sp, #0x428]
    2344:      	mov	x23, x2
    2348:      	b	0x1f0c <_stogir.verify.integer-operations-target-structured+0x1160>
    234c:      	str	x26, [sp, #0x440]
    2350:      	str	x25, [sp, #0x438]
    2354:      	str	x24, [sp, #0x430]
    2358:      	mov	x24, x1
    235c:      	str	x23, [sp, #0x428]
    2360:      	mov	x23, x2
    2364:      	mov	w25, w3
    2368:      	mov	w26, w4
    236c:      	b	0x1ff0 <_stogir.verify.integer-operations-target-structured+0x1244>

0000000000002370 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    2370:      	ldr	x0, [x0, #0x8]
    2374:      	ret

0000000000002378 <_coil.core.Eq$slice<u8>$=>:
    2378:      	sub	sp, sp, #0x10
    237c:      	str	x29, [sp]
    2380:      	str	x30, [sp, #0x8]
    2384:      	mov	x29, sp
    2388:      	cmp	x1, x3
    238c:      	b.ne	0x23cc <_coil.core.Eq$slice<u8>$=+0x54>
    2390:      	cmp	x1, #0x0
    2394:      	b.ne	0x23a0 <_coil.core.Eq$slice<u8>$=+0x28>
    2398:      	mov	x0, #0x1                ; =1
    239c:      	b	0x23c8 <_coil.core.Eq$slice<u8>$=+0x50>
    23a0:      	lsr	x1, x1, #0
    23a4:      	fmov	d31, x1
    23a8:      	mov	x1, x2
    23ac:      	fmov	x2, d31
    23b0:      	bl	0x23b0 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000023b0:  ARM64_RELOC_BRANCH26	_memcmp
    23b4:      	lsr	w0, w0, #0
    23b8:      	sxtw	x0, w0
    23bc:      	cmp	x0, #0x0
    23c0:      	cset	w0, eq
    23c4:      	ubfx	x0, x0, #0, #8
    23c8:      	b	0x23d0 <_coil.core.Eq$slice<u8>$=+0x58>
    23cc:      	movz	x0, #0x0, lsl #48
    23d0:      	ldr	x29, [sp]
    23d4:      	ldr	x30, [sp, #0x8]
    23d8:      	add	sp, sp, #0x10
    23dc:      	ret

00000000000023e0 <_stogir.node.opcode>:
    23e0:      	ldr	w0, [x0]
    23e4:      	uxtb	w0, w0
    23e8:      	ret

00000000000023ec <_stogir.opcode.valid?>:
    23ec:      	sxtw	x0, w0
    23f0:      	cmp	x0, #0x0
    23f4:      	b.lt	0x2408 <_stogir.opcode.valid?+0x1c>
    23f8:      	cmp	x0, #0x83
    23fc:      	cset	w0, lt
    2400:      	ubfx	x0, x0, #0, #8
    2404:      	b	0x240c <_stogir.opcode.valid?+0x20>
    2408:      	movz	x0, #0x0, lsl #48
    240c:      	ret

0000000000002410 <_stogir.node.type-id>:
    2410:      	ldr	w0, [x0]
    2414:      	ubfx	x0, x0, #8, #8
    2418:      	ret

000000000000241c <_stogir.types.valid?>:
    241c:      	sxtw	x0, w0
    2420:      	cmp	x0, #0x0
    2424:      	b.lt	0x2438 <_stogir.types.valid?+0x1c>
    2428:      	cmp	x0, #0xd
    242c:      	b.gt	0x2438 <_stogir.types.valid?+0x1c>
    2430:      	mov	x0, #0x1                ; =1
    2434:      	ret
    2438:      	cmp	x0, #0xf
    243c:      	b.le	0x2474 <_stogir.types.valid?+0x58>
    2440:      	cmp	x0, #0x80
    2444:      	b.ge	0x246c <_stogir.types.valid?+0x50>
    2448:      	and	x0, x0, #0xf
    244c:      	lsr	w0, w0, #0
    2450:      	sxtw	x0, w0
    2454:      	cmp	x0, #0x1
    2458:      	b.lt	0x247c <_stogir.types.valid?+0x60>
    245c:      	cmp	x0, #0xd
    2460:      	cset	w0, le
    2464:      	ubfx	x0, x0, #0, #8
    2468:      	b	0x2480 <_stogir.types.valid?+0x64>
    246c:      	movz	x0, #0x0, lsl #48
    2470:      	b	0x2478 <_stogir.types.valid?+0x5c>
    2474:      	movz	x0, #0x0, lsl #48
    2478:      	ret
    247c:      	movz	x0, #0x0, lsl #48
    2480:      	b	0x2470 <_stogir.types.valid?+0x54>

0000000000002484 <_stogir.opcode.operand-slots>:
    2484:      	sxtw	x0, w0
    2488:      	cmp	x0, #0x0
    248c:      	b.lt	0x24b8 <_stogir.opcode.operand-slots+0x34>
    2490:      	cmp	x0, #0x83
    2494:      	b.ge	0x24b8 <_stogir.opcode.operand-slots+0x34>
    2498:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1254>
		0000000000002498:  ARM64_RELOC_PAGE21	l_stogir.334
    249c:      	ldr	x16, [x16]
		000000000000249c:  ARM64_RELOC_PAGEOFF12	l_stogir.334
    24a0:      	orr	x1, x16, xzr
    24a4:      	lsr	x2, x0, #0
    24a8:      	add	x0, x1, x0
    24ac:      	ldrsb	w0, [x0]
    24b0:      	sxtb	x0, w0
    24b4:      	b	0x24bc <_stogir.opcode.operand-slots+0x38>
    24b8:      	mov	x0, #-0x2               ; =-2
    24bc:      	ret

00000000000024c0 <_stogir.opcode.input-count>:
    24c0:      	sxtw	x0, w0
    24c4:      	cmp	x0, #0x0
    24c8:      	b.lt	0x24f4 <_stogir.opcode.input-count+0x34>
    24cc:      	cmp	x0, #0x83
    24d0:      	b.ge	0x24f4 <_stogir.opcode.input-count+0x34>
    24d4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1254>
		00000000000024d4:  ARM64_RELOC_PAGE21	l_stogir.335
    24d8:      	ldr	x16, [x16]
		00000000000024d8:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    24dc:      	orr	x1, x16, xzr
    24e0:      	lsr	x2, x0, #0
    24e4:      	add	x0, x1, x0
    24e8:      	ldrsb	w0, [x0]
    24ec:      	sxtb	x0, w0
    24f0:      	b	0x24f8 <_stogir.opcode.input-count+0x38>
    24f4:      	mov	x0, #-0x2               ; =-2
    24f8:      	ret

00000000000024fc <_stogir.node.auxiliary>:
    24fc:      	ldr	w0, [x0]
    2500:      	ubfx	x0, x0, #16, #16
    2504:      	ret

0000000000002508 <_stogir.opcode.operand-code>:
    2508:      	sxtw	x0, w0
    250c:      	cmp	x0, #0x0
    2510:      	b.lt	0x2550 <_stogir.opcode.operand-code+0x48>
    2514:      	cmp	x0, #0x83
    2518:      	b.ge	0x2550 <_stogir.opcode.operand-code+0x48>
    251c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1254>
		000000000000251c:  ARM64_RELOC_PAGE21	l_stogir.336
    2520:      	ldr	x16, [x16]
		0000000000002520:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    2524:      	orr	x2, x16, xzr
    2528:      	lsl	x3, x0, #2
    252c:      	sxtw	x1, w1
    2530:      	add	x0, x2, x0, lsl #2
    2534:      	ldr	w0, [x0]
    2538:      	cmp	x1, #0x0
    253c:      	b.le	0x2584 <_stogir.opcode.operand-code+0x7c>
    2540:      	cmp	x1, #0x4
    2544:      	b.le	0x2558 <_stogir.opcode.operand-code+0x50>
    2548:      	mov	x1, #0x4                ; =4
    254c:      	b	0x2564 <_stogir.opcode.operand-code+0x5c>
    2550:      	movz	x0, #0x0, lsl #48
    2554:      	ret
    2558:      	sub	x1, x1, #0x1
    255c:      	lsr	w1, w1, #0
    2560:      	sxtw	x1, w1
    2564:      	lsl	x1, x1, #2
    2568:      	lsr	w1, w1, #0
    256c:      	ubfx	x1, x1, #0, #32
    2570:      	lsr	x0, x0, x1
    2574:      	lsr	w0, w0, #0
    2578:      	and	x0, x0, #0xf
    257c:      	lsr	w0, w0, #0
    2580:      	b	0x2588 <_stogir.opcode.operand-code+0x80>
    2584:      	movz	x0, #0x0, lsl #48
    2588:      	ret

000000000000258c <_stogir.graph.operand>:
    258c:      	sub	sp, sp, #0x10
    2590:      	mov	x3, sp
    2594:      	sxtw	x1, w1
    2598:      	cmp	x1, #0x0
    259c:      	b.le	0x25e0 <_stogir.graph.operand+0x54>
    25a0:      	lsl	x4, x1, #2
    25a4:      	ldr	x5, [x0, #0x8]
    25a8:      	cmp	x1, x5
    25ac:      	b.ge	0x2614 <_stogir.graph.operand+0x88>
    25b0:      	add	x5, x0, #0x78
    25b4:      	ldr	x5, [x5, #0x8]
    25b8:      	cmp	x1, x5
    25bc:      	b.ge	0x260c <_stogir.graph.operand+0x80>
    25c0:      	ldr	x5, [x0, #0x78]
    25c4:      	add	x5, x4, x5
    25c8:      	ldr	w5, [x5]
    25cc:      	sxtw	x5, w5
    25d0:      	cmp	x5, #0x0
    25d4:      	cset	w5, ge
    25d8:      	ubfx	x5, x5, #0, #8
    25dc:      	b	0x2610 <_stogir.graph.operand+0x84>
    25e0:      	movz	x0, #0x0, lsl #48
    25e4:      	movz	x1, #0x0, lsl #48
    25e8:      	str	x0, [x3]
    25ec:      	str	x1, [x3, #0x8]
    25f0:      	ldr	x0, [sp]
    25f4:      	ldr	x1, [sp, #0x8]
    25f8:      	add	sp, sp, #0x10
    25fc:      	ret
    2600:      	movz	x0, #0x0, lsl #48
    2604:      	movz	x1, #0x0, lsl #48
    2608:      	b	0x25e8 <_stogir.graph.operand+0x5c>
    260c:      	movz	x5, #0x0, lsl #48
    2610:      	b	0x2618 <_stogir.graph.operand+0x8c>
    2614:      	movz	x5, #0x0, lsl #48
    2618:      	cmp	x5, #0x0
    261c:      	b.eq	0x25e0 <_stogir.graph.operand+0x54>
    2620:      	sxtw	x2, w2
    2624:      	cmp	x2, #0x1
    2628:      	b.lt	0x2600 <_stogir.graph.operand+0x74>
    262c:      	ldr	x5, [x0, #0x78]
    2630:      	add	x4, x4, x5
    2634:      	ldr	w4, [x4]
    2638:      	sxtw	x4, w4
    263c:      	cmp	x2, x4
    2640:      	b.gt	0x2600 <_stogir.graph.operand+0x74>
    2644:      	asr	x16, x2, #63
    2648:      	lsr	x16, x16, #62
    264c:      	add	x4, x2, x16
    2650:      	asr	x4, x4, #2
    2654:      	asr	x16, x2, #63
    2658:      	lsr	x16, x16, #62
    265c:      	add	x2, x2, x16
    2660:      	and	x2, x2, #0x3
    2664:      	sub	x2, x2, x16
    2668:      	ldr	x0, [x0]
    266c:      	add	x1, x4, x1
    2670:      	lsl	x4, x2, #2
    2674:      	lsl	x4, x1, #4
    2678:      	add	x0, x0, x1, lsl #4
    267c:      	add	x0, x0, x2, lsl #2
    2680:      	ldr	w0, [x0]
    2684:      	sxtw	x0, w0
    2688:      	and	x0, x0, #0xffffffff
    268c:      	mov	x1, x0
    2690:      	mov	x0, #0x1                ; =1
    2694:      	b	0x2608 <_stogir.graph.operand+0x7c>

0000000000002698 <_stogir.graph.borrow-node>:
    2698:      	sxtw	x1, w1
    269c:      	cmp	x1, #0x0
    26a0:      	cset	w2, gt
    26a4:      	movz	x16, #0x0, lsl #48
    26a8:      	sub	x3, x16, x1
    26ac:      	sub	x4, x3, #0x1
    26b0:      	uxtb	w16, w2
    26b4:      	cmp	w16, wzr
    26b8:      	b.eq	0x26fc <_stogir.graph.borrow-node+0x64>
    26bc:      	ldr	x3, [x0, #0x8]
    26c0:      	cmp	x1, x3
    26c4:      	b.ge	0x2750 <_stogir.graph.borrow-node+0xb8>
    26c8:      	add	x3, x0, #0x78
    26cc:      	ldr	x3, [x3, #0x8]
    26d0:      	cmp	x1, x3
    26d4:      	b.ge	0x2798 <_stogir.graph.borrow-node+0x100>
    26d8:      	lsl	x3, x1, #2
    26dc:      	ldr	x3, [x0, #0x78]
    26e0:      	add	x3, x3, x1, lsl #2
    26e4:      	ldr	w3, [x3]
    26e8:      	sxtw	x3, w3
    26ec:      	cmp	x3, #0x0
    26f0:      	cset	w3, ge
    26f4:      	ubfx	x3, x3, #0, #8
    26f8:      	b	0x279c <_stogir.graph.borrow-node+0x104>
    26fc:      	cmp	x1, #0x0
    2700:      	b.ge	0x2758 <_stogir.graph.borrow-node+0xc0>
    2704:      	add	x5, x0, #0x28
    2708:      	add	x6, x0, #0x50
    270c:      	ldr	x5, [x5, #0x8]
    2710:      	ldr	x6, [x6, #0x8]
    2714:      	cmp	x5, x6
    2718:      	b.ne	0x2748 <_stogir.graph.borrow-node+0xb0>
    271c:      	cmp	x3, x5
    2720:      	b.gt	0x27a0 <_stogir.graph.borrow-node+0x108>
    2724:      	lsl	x3, x4, #2
    2728:      	ldr	x3, [x0, #0x50]
    272c:      	add	x3, x3, x4, lsl #2
    2730:      	ldr	w3, [x3]
    2734:      	sxtw	x3, w3
    2738:      	cmp	x3, #0x0
    273c:      	cset	w3, gt
    2740:      	ubfx	x3, x3, #0, #8
    2744:      	b	0x27a4 <_stogir.graph.borrow-node+0x10c>
    2748:      	movz	x3, #0x0, lsl #48
    274c:      	b	0x275c <_stogir.graph.borrow-node+0xc4>
    2750:      	movz	x3, #0x0, lsl #48
    2754:      	b	0x275c <_stogir.graph.borrow-node+0xc4>
    2758:      	movz	x3, #0x0, lsl #48
    275c:      	cmp	x3, #0x0
    2760:      	b.eq	0x2790 <_stogir.graph.borrow-node+0xf8>
    2764:      	uxtb	w16, w2
    2768:      	cmp	w16, wzr
    276c:      	b.eq	0x2780 <_stogir.graph.borrow-node+0xe8>
    2770:      	lsl	x2, x1, #4
    2774:      	ldr	x0, [x0]
    2778:      	add	x0, x0, x1, lsl #4
    277c:      	b	0x278c <_stogir.graph.borrow-node+0xf4>
    2780:      	lsl	x1, x4, #4
    2784:      	ldr	x0, [x0, #0x28]
    2788:      	add	x0, x0, x4, lsl #4
    278c:      	b	0x2794 <_stogir.graph.borrow-node+0xfc>
    2790:      	movz	x0, #0x0, lsl #48
    2794:      	ret
    2798:      	movz	x3, #0x0, lsl #48
    279c:      	b	0x2754 <_stogir.graph.borrow-node+0xbc>
    27a0:      	movz	x3, #0x0, lsl #48
    27a4:      	b	0x274c <_stogir.graph.borrow-node+0xb4>

00000000000027a8 <_stogir.strings.lookup>:
    27a8:      	sxtw	x1, w1
    27ac:      	cmp	x1, #0x0
    27b0:      	b.le	0x282c <_stogir.strings.lookup+0x84>
    27b4:      	add	x2, x0, #0x28
    27b8:      	ldr	x2, [x2, #0x8]
    27bc:      	cmp	x1, x2
    27c0:      	b.gt	0x282c <_stogir.strings.lookup+0x84>
    27c4:      	sub	x1, x1, #0x1
    27c8:      	mov	x17, #0x18              ; =24
    27cc:      	mul	x1, x1, x17
    27d0:      	ldr	x2, [x0, #0x28]
    27d4:      	add	x1, x1, x2
    27d8:      	ldr	x2, [x1]
    27dc:      	ldr	x1, [x1, #0x8]
    27e0:      	ldr	x3, [x0, #0x8]
    27e4:      	cmp	x2, #0x0
    27e8:      	b.lt	0x2848 <_stogir.strings.lookup+0xa0>
    27ec:      	cmp	x2, x3
    27f0:      	b.gt	0x2848 <_stogir.strings.lookup+0xa0>
    27f4:      	cmp	x1, #0x0
    27f8:      	b.lt	0x2848 <_stogir.strings.lookup+0xa0>
    27fc:      	sub	x3, x3, x2
    2800:      	cmp	x1, x3
    2804:      	b.gt	0x2848 <_stogir.strings.lookup+0xa0>
    2808:      	add	x1, x1, x2
    280c:      	lsr	x3, x2, #0
    2810:      	sub	x1, x1, x2
    2814:      	ldr	x0, [x0]
    2818:      	add	x0, x0, x2
    281c:      	mov	x2, x1
    2820:      	mov	x1, x0
    2824:      	mov	x0, #0x1                ; =1
    2828:      	b	0x2854 <_stogir.strings.lookup+0xac>
    282c:      	movz	x0, #0x0, lsl #48
    2830:      	movz	x1, #0x0, lsl #48
    2834:      	movz	x2, #0x0, lsl #48
    2838:      	str	x0, [x8]
    283c:      	str	x1, [x8, #0x8]
    2840:      	str	x2, [x8, #0x10]
    2844:      	ret
    2848:      	movz	x0, #0x0, lsl #48
    284c:      	movz	x1, #0x0, lsl #48
    2850:      	movz	x2, #0x0, lsl #48
    2854:      	b	0x2838 <_stogir.strings.lookup+0x90>

0000000000002858 <_stogir.uses.edge-code?>:
    2858:      	ubfx	x0, x0, #0, #32
    285c:      	cmp	x0, #0xf
    2860:      	b.hs	0x2894 <_stogir.uses.edge-code?+0x3c>
    2864:      	mov	x16, #0x1               ; =1
    2868:      	lsl	x0, x16, x0
    286c:      	lsr	w0, w0, #0
    2870:      	mov	x17, #0x5e1c            ; =24092
    2874:      	and	x0, x0, x17
    2878:      	lsr	w0, w0, #0
    287c:      	cmp	x0, #0x0
    2880:      	cset	w0, eq
    2884:      	uxtb	w16, w0
    2888:      	cmp	w16, wzr
    288c:      	cset	x0, eq
    2890:      	b	0x2898 <_stogir.uses.edge-code?+0x40>
    2894:      	movz	x0, #0x0, lsl #48
    2898:      	ret

000000000000289c <_stogir.graph.contains?>:
    289c:      	sxtw	x1, w1
    28a0:      	cmp	x1, #0x0
    28a4:      	b.le	0x28e8 <_stogir.graph.contains?+0x4c>
    28a8:      	ldr	x2, [x0, #0x8]
    28ac:      	cmp	x1, x2
    28b0:      	b.ge	0x2948 <_stogir.graph.contains?+0xac>
    28b4:      	add	x2, x0, #0x78
    28b8:      	ldr	x2, [x2, #0x8]
    28bc:      	cmp	x1, x2
    28c0:      	b.ge	0x2958 <_stogir.graph.contains?+0xbc>
    28c4:      	lsl	x2, x1, #2
    28c8:      	ldr	x0, [x0, #0x78]
    28cc:      	add	x0, x0, x1, lsl #2
    28d0:      	ldr	w0, [x0]
    28d4:      	sxtw	x0, w0
    28d8:      	cmp	x0, #0x0
    28dc:      	cset	w0, ge
    28e0:      	ubfx	x0, x0, #0, #8
    28e4:      	b	0x295c <_stogir.graph.contains?+0xc0>
    28e8:      	cmp	x1, #0x0
    28ec:      	b.ge	0x2950 <_stogir.graph.contains?+0xb4>
    28f0:      	add	x2, x0, #0x28
    28f4:      	add	x3, x0, #0x50
    28f8:      	ldr	x2, [x2, #0x8]
    28fc:      	ldr	x3, [x3, #0x8]
    2900:      	cmp	x2, x3
    2904:      	b.ne	0x2968 <_stogir.graph.contains?+0xcc>
    2908:      	movz	x16, #0x0, lsl #48
    290c:      	sub	x3, x16, x1
    2910:      	cmp	x3, x2
    2914:      	b.gt	0x2960 <_stogir.graph.contains?+0xc4>
    2918:      	movz	x16, #0x0, lsl #48
    291c:      	sub	x1, x16, x1
    2920:      	sub	x1, x1, #0x1
    2924:      	lsl	x2, x1, #2
    2928:      	ldr	x0, [x0, #0x50]
    292c:      	add	x0, x0, x1, lsl #2
    2930:      	ldr	w0, [x0]
    2934:      	sxtw	x0, w0
    2938:      	cmp	x0, #0x0
    293c:      	cset	w0, gt
    2940:      	ubfx	x0, x0, #0, #8
    2944:      	b	0x2964 <_stogir.graph.contains?+0xc8>
    2948:      	movz	x0, #0x0, lsl #48
    294c:      	b	0x295c <_stogir.graph.contains?+0xc0>
    2950:      	movz	x0, #0x0, lsl #48
    2954:      	b	0x2964 <_stogir.graph.contains?+0xc8>
    2958:      	movz	x0, #0x0, lsl #48
    295c:      	b	0x2964 <_stogir.graph.contains?+0xc8>
    2960:      	movz	x0, #0x0, lsl #48
    2964:      	ret
    2968:      	movz	x0, #0x0, lsl #48
    296c:      	b	0x2964 <_stogir.graph.contains?+0xc8>

0000000000002970 <_stogir.opcode.optional-reference?>:
    2970:      	sub	sp, sp, #0x30
    2974:      	str	x29, [sp]
    2978:      	str	x30, [sp, #0x8]
    297c:      	mov	x29, sp
    2980:      	str	x19, [sp, #0x10]
    2984:      	str	x20, [sp, #0x18]
    2988:      	str	x21, [sp, #0x20]
    298c:      	lsr	w0, w0, #0
    2990:      	lsr	w2, w2, #0
    2994:      	mov	w19, w0
    2998:      	mov	w20, w1
    299c:      	mov	w1, w2
    29a0:      	mov	w21, w2
    29a4:      	bl	0x29a4 <_stogir.opcode.optional-reference?+0x34>
		00000000000029a4:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    29a8:      	lsr	w0, w0, #0
    29ac:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1254>
		00000000000029ac:  ARM64_RELOC_PAGE21	l_stogir.337
    29b0:      	ldr	x16, [x16]
		00000000000029b0:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    29b4:      	ldr	w1, [x16]
    29b8:      	cmp	x0, x1
    29bc:      	b.ne	0x29e8 <_stogir.opcode.optional-reference?+0x78>
    29c0:      	mov	x0, #0x1                ; =1
    29c4:      	b	0x29cc <_stogir.opcode.optional-reference?+0x5c>
    29c8:      	movz	x0, #0x0, lsl #48
    29cc:      	ldr	x19, [sp, #0x10]
    29d0:      	ldr	x20, [sp, #0x18]
    29d4:      	ldr	x21, [sp, #0x20]
    29d8:      	ldr	x29, [sp]
    29dc:      	ldr	x30, [sp, #0x8]
    29e0:      	add	sp, sp, #0x30
    29e4:      	ret
    29e8:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1254>
		00000000000029e8:  ARM64_RELOC_PAGE21	l_stogir.338
    29ec:      	ldr	x16, [x16]
		00000000000029ec:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    29f0:      	ldr	w1, [x16]
    29f4:      	cmp	x0, x1
    29f8:      	b.ne	0x2a04 <_stogir.opcode.optional-reference?+0x94>
    29fc:      	mov	x0, #0x1                ; =1
    2a00:      	b	0x29cc <_stogir.opcode.optional-reference?+0x5c>
    2a04:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1254>
		0000000000002a04:  ARM64_RELOC_PAGE21	l_stogir.339
    2a08:      	ldr	x16, [x16]
		0000000000002a08:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    2a0c:      	ldr	w1, [x16]
    2a10:      	cmp	x0, x1
    2a14:      	b.ne	0x2a20 <_stogir.opcode.optional-reference?+0xb0>
    2a18:      	mov	x0, #0x1                ; =1
    2a1c:      	b	0x29cc <_stogir.opcode.optional-reference?+0x5c>
    2a20:      	sxtw	x19, w19
    2a24:      	cmp	x19, #0x78
    2a28:      	b.ne	0x2a4c <_stogir.opcode.optional-reference?+0xdc>
    2a2c:      	sxtw	x20, w20
    2a30:      	cmp	x20, #0x0
    2a34:      	b.ne	0x29c8 <_stogir.opcode.optional-reference?+0x58>
    2a38:      	sxtw	x21, w21
    2a3c:      	cmp	x21, #0x2
    2a40:      	cset	w0, eq
    2a44:      	ubfx	x0, x0, #0, #8
    2a48:      	b	0x29cc <_stogir.opcode.optional-reference?+0x5c>
    2a4c:      	movz	x0, #0x0, lsl #48
    2a50:      	b	0x29cc <_stogir.opcode.optional-reference?+0x5c>

0000000000002a54 <_stogir.integer-binary.operation?>:
    2a54:      	sxtw	x0, w0
    2a58:      	cmp	x0, #0x1a
    2a5c:      	b.lt	0x2a70 <_stogir.integer-binary.operation?+0x1c>
    2a60:      	cmp	x0, #0x1e
    2a64:      	b.gt	0x2a70 <_stogir.integer-binary.operation?+0x1c>
    2a68:      	mov	x0, #0x1                ; =1
    2a6c:      	b	0x2aa4 <_stogir.integer-binary.operation?+0x50>
    2a70:      	cmp	x0, #0x2e
    2a74:      	b.lt	0x2a88 <_stogir.integer-binary.operation?+0x34>
    2a78:      	cmp	x0, #0x35
    2a7c:      	b.gt	0x2a88 <_stogir.integer-binary.operation?+0x34>
    2a80:      	mov	x0, #0x1                ; =1
    2a84:      	b	0x2aa4 <_stogir.integer-binary.operation?+0x50>
    2a88:      	cmp	x0, #0x3a
    2a8c:      	b.ne	0x2a98 <_stogir.integer-binary.operation?+0x44>
    2a90:      	mov	x0, #0x1                ; =1
    2a94:      	b	0x2aa4 <_stogir.integer-binary.operation?+0x50>
    2a98:      	cmp	x0, #0x3b
    2a9c:      	cset	w0, eq
    2aa0:      	ubfx	x0, x0, #0, #8
    2aa4:      	ret

0000000000002aa8 <_stogir.integer-unary.operation?>:
    2aa8:      	sxtw	x0, w0
    2aac:      	cmp	x0, #0x1f
    2ab0:      	b.ne	0x2acc <_stogir.integer-unary.operation?+0x24>
    2ab4:      	mov	x0, #0x1                ; =1
    2ab8:      	b	0x2ac8 <_stogir.integer-unary.operation?+0x20>
    2abc:      	cmp	x0, #0x39
    2ac0:      	cset	w0, eq
    2ac4:      	ubfx	x0, x0, #0, #8
    2ac8:      	ret
    2acc:      	cmp	x0, #0x20
    2ad0:      	b.ne	0x2adc <_stogir.integer-unary.operation?+0x34>
    2ad4:      	mov	x0, #0x1                ; =1
    2ad8:      	b	0x2ac8 <_stogir.integer-unary.operation?+0x20>
    2adc:      	cmp	x0, #0x2d
    2ae0:      	b.ne	0x2aec <_stogir.integer-unary.operation?+0x44>
    2ae4:      	mov	x0, #0x1                ; =1
    2ae8:      	b	0x2ac8 <_stogir.integer-unary.operation?+0x20>
    2aec:      	cmp	x0, #0x36
    2af0:      	b.ne	0x2afc <_stogir.integer-unary.operation?+0x54>
    2af4:      	mov	x0, #0x1                ; =1
    2af8:      	b	0x2ac8 <_stogir.integer-unary.operation?+0x20>
    2afc:      	cmp	x0, #0x37
    2b00:      	b.ne	0x2b0c <_stogir.integer-unary.operation?+0x64>
    2b04:      	mov	x0, #0x1                ; =1
    2b08:      	b	0x2ac8 <_stogir.integer-unary.operation?+0x20>
    2b0c:      	cmp	x0, #0x38
    2b10:      	b.ne	0x2abc <_stogir.integer-unary.operation?+0x14>
    2b14:      	mov	x0, #0x1                ; =1
    2b18:      	b	0x2ac8 <_stogir.integer-unary.operation?+0x20>

0000000000002b1c <_stogir.verify.classifications>:
    2b1c:      	sub	sp, sp, #0xc0
    2b20:      	str	x29, [sp]
    2b24:      	str	x30, [sp, #0x8]
    2b28:      	mov	x29, sp
    2b2c:      	str	x19, [sp, #0x70]
    2b30:      	str	x20, [sp, #0x78]
    2b34:      	str	x21, [sp, #0x80]
    2b38:      	str	x22, [sp, #0x88]
    2b3c:      	str	x23, [sp, #0x90]
    2b40:      	str	x24, [sp, #0x98]
    2b44:      	str	x25, [sp, #0xa0]
    2b48:      	str	x26, [sp, #0xa8]
    2b4c:      	str	x27, [sp, #0xb0]
    2b50:      	str	x28, [sp, #0xb8]
    2b54:      	ldr	w4, [x2]
    2b58:      	orr	x5, x4, xzr
    2b5c:      	ubfx	x5, x5, #8, #8
    2b60:      	orr	x19, x5, xzr
    2b64:      	cmp	x19, #0xf
    2b68:      	b.le	0x2ba4 <_stogir.verify.classifications+0x88>
    2b6c:      	cmp	x19, #0x80
    2b70:      	b.ge	0x2b98 <_stogir.verify.classifications+0x7c>
    2b74:      	and	x5, x19, #0xf
    2b78:      	lsr	w5, w5, #0
    2b7c:      	sxtw	x5, w5
    2b80:      	cmp	x5, #0x1
    2b84:      	b.lt	0x3164 <_stogir.verify.classifications+0x648>
    2b88:      	cmp	x5, #0xd
    2b8c:      	cset	w5, le
    2b90:      	ubfx	x5, x5, #0, #8
    2b94:      	b	0x3168 <_stogir.verify.classifications+0x64c>
    2b98:      	movz	x5, #0x0, lsl #48
    2b9c:      	mov	x20, x5
    2ba0:      	b	0x2ba8 <_stogir.verify.classifications+0x8c>
    2ba4:      	movz	x20, #0x0, lsl #48
    2ba8:      	uxtb	w21, w4
    2bac:      	orr	x4, x21, xzr
    2bb0:      	lsr	w22, w4, #0
    2bb4:      	mov	x23, x0
    2bb8:      	mov	w0, w22
    2bbc:      	mov	w24, w1
    2bc0:      	mov	x25, x2
    2bc4:      	mov	w26, w3
    2bc8:      	bl	0x2bc8 <_stogir.verify.classifications+0xac>
		0000000000002bc8:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2bcc:      	cmp	x0, #0x0
    2bd0:      	b.eq	0x2bf0 <_stogir.verify.classifications+0xd4>
    2bd4:      	cmp	x20, #0x0
    2bd8:      	cset	w0, ne
    2bdc:      	uxtb	w16, w0
    2be0:      	cmp	w16, wzr
    2be4:      	cset	x0, eq
    2be8:      	mov	x27, x0
    2bec:      	b	0x2bf4 <_stogir.verify.classifications+0xd8>
    2bf0:      	movz	x27, #0x0, lsl #48
    2bf4:      	cmp	x27, #0x0
    2bf8:      	cset	w28, ne
    2bfc:      	uxtb	w16, w28
    2c00:      	cmp	w16, wzr
    2c04:      	b.eq	0x2c38 <_stogir.verify.classifications+0x11c>
    2c08:      	ldr	w0, [x25, #0x4]
    2c0c:      	lsr	w0, w0, #0
    2c10:      	mov	w1, w0
    2c14:      	mov	x0, x23
    2c18:      	bl	0x2c18 <_stogir.verify.classifications+0xfc>
		0000000000002c18:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2c1c:      	cmp	x0, #0x0
    2c20:      	b.ne	0x2c2c <_stogir.verify.classifications+0x110>
    2c24:      	movn	x0, #0x0, lsl #48
    2c28:      	b	0x2c34 <_stogir.verify.classifications+0x118>
    2c2c:      	ldr	w0, [x0]
    2c30:      	ubfx	x0, x0, #8, #8
    2c34:      	b	0x2c3c <_stogir.verify.classifications+0x120>
    2c38:      	movn	x0, #0x0, lsl #48
    2c3c:      	lsr	w0, w0, #0
    2c40:      	sxtw	x0, w0
    2c44:      	cmp	x0, #0xf
    2c48:      	cset	w1, gt
    2c4c:      	cmp	x0, #0x80
    2c50:      	cset	w2, lt
    2c54:      	and	x3, x0, #0xf
    2c58:      	lsr	w3, w3, #0
    2c5c:      	sxtw	x3, w3
    2c60:      	cmp	x3, #0x1
    2c64:      	cset	w4, ge
    2c68:      	cmp	x3, #0xd
    2c6c:      	cset	w3, le
    2c70:      	cmp	x27, #0x0
    2c74:      	b.eq	0x2ccc <_stogir.verify.classifications+0x1b0>
    2c78:      	uxtb	w16, w1
    2c7c:      	cmp	w16, wzr
    2c80:      	b.eq	0x316c <_stogir.verify.classifications+0x650>
    2c84:      	uxtb	w16, w2
    2c88:      	cmp	w16, wzr
    2c8c:      	b.eq	0x316c <_stogir.verify.classifications+0x650>
    2c90:      	uxtb	w16, w4
    2c94:      	cmp	w16, wzr
    2c98:      	b.eq	0x316c <_stogir.verify.classifications+0x650>
    2c9c:      	uxtb	w16, w3
    2ca0:      	cmp	w16, wzr
    2ca4:      	b.eq	0x316c <_stogir.verify.classifications+0x650>
    2ca8:      	movz	x0, #0x0, lsl #48
    2cac:      	b	0x2cb4 <_stogir.verify.classifications+0x198>
    2cb0:      	mov	x0, #0x1                ; =1
    2cb4:      	mov	x19, x0
    2cb8:      	b	0x2cd0 <_stogir.verify.classifications+0x1b4>
    2cbc:      	movz	x3, #0x0, lsl #48
    2cc0:      	b	0x2d0c <_stogir.verify.classifications+0x1f0>
    2cc4:      	movz	x0, #0x0, lsl #48
    2cc8:      	b	0x2d14 <_stogir.verify.classifications+0x1f8>
    2ccc:      	movz	x19, #0x0, lsl #48
    2cd0:      	sxtw	x26, w26
    2cd4:      	ubfx	x21, x3, #0, #8
    2cd8:      	add	x27, x23, #0x78
    2cdc:      	add	x0, x23, #0x28
    2ce0:      	add	x3, x23, #0x50
    2ce4:      	sxtw	x24, w24
    2ce8:      	add	x5, x23, #0x78
    2cec:      	cmp	x24, #0x0
    2cf0:      	cset	w6, le
    2cf4:      	lsl	x7, x24, #2
    2cf8:      	mov	x8, #0x1                ; =1
    2cfc:      	b	0x2e04 <_stogir.verify.classifications+0x2e8>
    2d00:      	movz	x3, #0x0, lsl #48
    2d04:      	b	0x2d2c <_stogir.verify.classifications+0x210>
    2d08:      	movz	x3, #0x0, lsl #48
    2d0c:      	b	0x2d3c <_stogir.verify.classifications+0x220>
    2d10:      	movz	x0, #0x0, lsl #48
    2d14:      	ldr	x5, [sp, #0x58]
    2d18:      	ldr	x6, [sp, #0x50]
    2d1c:      	ldr	x8, [sp, #0x48]
    2d20:      	ldr	x1, [sp, #0x60]
    2d24:      	b	0x2dbc <_stogir.verify.classifications+0x2a0>
    2d28:      	movz	x3, #0x0, lsl #48
    2d2c:      	ldr	x6, [sp, #0x50]
    2d30:      	ldr	x8, [sp, #0x48]
    2d34:      	b	0x2d3c <_stogir.verify.classifications+0x220>
    2d38:      	movz	x3, #0x0, lsl #48
    2d3c:      	cmp	x3, #0x0
    2d40:      	b.eq	0x2d70 <_stogir.verify.classifications+0x254>
    2d44:      	uxtb	w16, w2
    2d48:      	cmp	w16, wzr
    2d4c:      	b.eq	0x2d60 <_stogir.verify.classifications+0x244>
    2d50:      	lsl	x2, x0, #4
    2d54:      	ldr	x2, [x23]
    2d58:      	add	x0, x2, x0, lsl #4
    2d5c:      	b	0x2d6c <_stogir.verify.classifications+0x250>
    2d60:      	lsl	x0, x4, #4
    2d64:      	ldr	x0, [x23, #0x28]
    2d68:      	add	x0, x0, x4, lsl #4
    2d6c:      	b	0x2d74 <_stogir.verify.classifications+0x258>
    2d70:      	movz	x0, #0x0, lsl #48
    2d74:      	cmp	x0, #0x0
    2d78:      	b.eq	0x2db8 <_stogir.verify.classifications+0x29c>
    2d7c:      	ldr	w0, [x0]
    2d80:      	ubfx	x0, x0, #8, #8
    2d84:      	cmp	x0, #0xf
    2d88:      	b.le	0x2db8 <_stogir.verify.classifications+0x29c>
    2d8c:      	cmp	x0, #0x80
    2d90:      	b.ge	0x2db8 <_stogir.verify.classifications+0x29c>
    2d94:      	and	x0, x0, #0xf
    2d98:      	lsr	w0, w0, #0
    2d9c:      	sxtw	x0, w0
    2da0:      	cmp	x0, #0x1
    2da4:      	b.lt	0x2db8 <_stogir.verify.classifications+0x29c>
    2da8:      	cmp	x0, #0xd
    2dac:      	b.gt	0x2db8 <_stogir.verify.classifications+0x29c>
    2db0:      	mov	x0, #0x1                ; =1
    2db4:      	b	0x2dbc <_stogir.verify.classifications+0x2a0>
    2db8:      	ldr	x0, [sp, #0x40]
    2dbc:      	add	x2, x27, #0x1
    2dc0:      	lsr	w2, w2, #0
    2dc4:      	sxtw	x2, w2
    2dc8:      	mov	w4, w26
    2dcc:      	ldr	x26, [sp, #0x30]
    2dd0:      	mov	x27, x5
    2dd4:      	mov	x3, x8
    2dd8:      	mov	x7, x1
    2ddc:      	mov	w1, w21
    2de0:      	ldr	x21, [sp, #0x20]
    2de4:      	mov	x5, x20
    2de8:      	mov	x20, x0
    2dec:      	mov	x0, x6
    2df0:      	mov	w6, w19
    2df4:      	ldr	x19, [sp, #0x38]
    2df8:      	mov	x8, x2
    2dfc:      	mov	w2, w22
    2e00:      	ldr	w22, [sp, #0x28]
    2e04:      	cmp	x20, #0x0
    2e08:      	b.ne	0x31d0 <_stogir.verify.classifications+0x6b4>
    2e0c:      	cmp	x8, x26
    2e10:      	b.gt	0x31dc <_stogir.verify.classifications+0x6c0>
    2e14:      	lsr	w9, w8, #0
    2e18:      	str	x0, [sp, #0x50]
    2e1c:      	mov	w0, w22
    2e20:      	str	x3, [sp, #0x48]
    2e24:      	str	x7, [sp, #0x60]
    2e28:      	str	w9, [sp, #0x68]
    2e2c:      	str	x21, [sp, #0x20]
    2e30:      	mov	w21, w1
    2e34:      	mov	w1, w9
    2e38:      	str	w22, [sp, #0x28]
    2e3c:      	mov	w22, w2
    2e40:      	str	x26, [sp, #0x30]
    2e44:      	mov	w26, w4
    2e48:      	str	x19, [sp, #0x38]
    2e4c:      	mov	w19, w6
    2e50:      	str	x20, [sp, #0x40]
    2e54:      	mov	x20, x5
    2e58:      	str	x27, [sp, #0x58]
    2e5c:      	mov	x27, x8
    2e60:      	bl	0x2e60 <_stogir.verify.classifications+0x344>
		0000000000002e60:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    2e64:      	lsr	w0, w0, #0
    2e68:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1254>
		0000000000002e68:  ARM64_RELOC_PAGE21	l_stogir.340
    2e6c:      	ldr	x16, [x16]
		0000000000002e6c:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    2e70:      	ldr	w1, [x16]
    2e74:      	cmp	x0, x1
    2e78:      	b.eq	0x2ea8 <_stogir.verify.classifications+0x38c>
    2e7c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1254>
		0000000000002e7c:  ARM64_RELOC_PAGE21	l_stogir.341
    2e80:      	ldr	x16, [x16]
		0000000000002e80:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    2e84:      	ldr	w1, [x16]
    2e88:      	cmp	x0, x1
    2e8c:      	b.eq	0x2ea8 <_stogir.verify.classifications+0x38c>
    2e90:      	ldr	x5, [sp, #0x58]
    2e94:      	ldr	x6, [sp, #0x50]
    2e98:      	ldr	x8, [sp, #0x48]
    2e9c:      	ldr	x1, [sp, #0x60]
    2ea0:      	ldr	x0, [sp, #0x40]
    2ea4:      	b	0x2dbc <_stogir.verify.classifications+0x2a0>
    2ea8:      	cmp	x27, #0x1
    2eac:      	b.ne	0x2ee8 <_stogir.verify.classifications+0x3cc>
    2eb0:      	uxtb	w16, w28
    2eb4:      	cmp	w16, wzr
    2eb8:      	b.eq	0x2ee8 <_stogir.verify.classifications+0x3cc>
    2ebc:      	uxtb	w16, w21
    2ec0:      	cmp	w16, wzr
    2ec4:      	b.eq	0x2d10 <_stogir.verify.classifications+0x1f4>
    2ec8:      	uxtb	w16, w22
    2ecc:      	cmp	w16, wzr
    2ed0:      	b.eq	0x2cc4 <_stogir.verify.classifications+0x1a8>
    2ed4:      	uxtb	w16, w26
    2ed8:      	cmp	w16, wzr
    2edc:      	b.eq	0x309c <_stogir.verify.classifications+0x580>
    2ee0:      	ldr	x0, [sp, #0x20]
    2ee4:      	b	0x30a0 <_stogir.verify.classifications+0x584>
    2ee8:      	cmp	x27, #0x1
    2eec:      	b.ne	0x2f64 <_stogir.verify.classifications+0x448>
    2ef0:      	ldr	w0, [x25, #0x4]
    2ef4:      	sxtw	x0, w0
    2ef8:      	ldr	x1, [sp, #0x60]
    2efc:      	lsr	w0, w0, #0
    2f00:      	sxtw	x0, w0
    2f04:      	cmp	x0, #0x0
    2f08:      	cset	w2, gt
    2f0c:      	movz	x16, #0x0, lsl #48
    2f10:      	sub	x3, x16, x0
    2f14:      	sub	x4, x3, #0x1
    2f18:      	uxtb	w16, w2
    2f1c:      	cmp	w16, wzr
    2f20:      	b.eq	0x31e8 <_stogir.verify.classifications+0x6cc>
    2f24:      	ldr	x3, [x23, #0x8]
    2f28:      	cmp	x0, x3
    2f2c:      	b.ge	0x31f0 <_stogir.verify.classifications+0x6d4>
    2f30:      	ldr	x5, [sp, #0x58]
    2f34:      	ldr	x3, [x5, #0x8]
    2f38:      	cmp	x0, x3
    2f3c:      	b.ge	0x2d00 <_stogir.verify.classifications+0x1e4>
    2f40:      	lsl	x3, x0, #2
    2f44:      	ldr	x3, [x23, #0x78]
    2f48:      	add	x3, x3, x0, lsl #2
    2f4c:      	ldr	w3, [x3]
    2f50:      	sxtw	x3, w3
    2f54:      	cmp	x3, #0x0
    2f58:      	cset	w3, ge
    2f5c:      	ubfx	x3, x3, #0, #8
    2f60:      	b	0x2d04 <_stogir.verify.classifications+0x1e8>
    2f64:      	cmp	x27, #0x2
    2f68:      	b.ne	0x2fc8 <_stogir.verify.classifications+0x4ac>
    2f6c:      	ldr	w0, [x25, #0x8]
    2f70:      	sxtw	x0, w0
    2f74:      	ldr	x1, [sp, #0x60]
    2f78:      	b	0x2efc <_stogir.verify.classifications+0x3e0>
    2f7c:      	cmp	x0, #0x0
    2f80:      	b.ge	0x31f8 <_stogir.verify.classifications+0x6dc>
    2f84:      	ldr	x6, [sp, #0x50]
    2f88:      	ldr	x7, [x6, #0x8]
    2f8c:      	ldr	x8, [sp, #0x48]
    2f90:      	ldr	x9, [x8, #0x8]
    2f94:      	cmp	x7, x9
    2f98:      	b.ne	0x2d08 <_stogir.verify.classifications+0x1ec>
    2f9c:      	cmp	x3, x7
    2fa0:      	b.gt	0x2cbc <_stogir.verify.classifications+0x1a0>
    2fa4:      	lsl	x3, x4, #2
    2fa8:      	ldr	x3, [x23, #0x50]
    2fac:      	add	x3, x3, x4, lsl #2
    2fb0:      	ldr	w3, [x3]
    2fb4:      	sxtw	x3, w3
    2fb8:      	cmp	x3, #0x0
    2fbc:      	cset	w3, gt
    2fc0:      	ubfx	x3, x3, #0, #8
    2fc4:      	b	0x2cc0 <_stogir.verify.classifications+0x1a4>
    2fc8:      	cmp	x27, #0x3
    2fcc:      	b.ne	0x304c <_stogir.verify.classifications+0x530>
    2fd0:      	ldr	w0, [x25, #0xc]
    2fd4:      	sxtw	x0, w0
    2fd8:      	ldr	x1, [sp, #0x60]
    2fdc:      	b	0x2f78 <_stogir.verify.classifications+0x45c>
    2fe0:      	ldr	x0, [sp, #0x40]
    2fe4:      	uxtb	w0, w0
    2fe8:      	ldr	x1, [sp, #0x38]
    2fec:      	uxtb	w1, w1
    2ff0:      	add	x16, sp, #0x10
    2ff4:      	movz	w17, #0x0, lsl #16
    2ff8:      	strh	w17, [x16]
    2ffc:      	add	x16, sp, #0x10
    3000:      	strb	w0, [x16]
    3004:      	add	x16, sp, #0x10
    3008:      	strb	w1, [x16, #0x1]
    300c:      	add	x16, sp, #0x10
    3010:      	ldrh	w0, [x16]
    3014:      	ldr	x19, [sp, #0x70]
    3018:      	ldr	x20, [sp, #0x78]
    301c:      	ldr	x21, [sp, #0x80]
    3020:      	ldr	x22, [sp, #0x88]
    3024:      	ldr	x23, [sp, #0x90]
    3028:      	ldr	x24, [sp, #0x98]
    302c:      	ldr	x25, [sp, #0xa0]
    3030:      	ldr	x26, [sp, #0xa8]
    3034:      	ldr	x27, [sp, #0xb0]
    3038:      	ldr	x28, [sp, #0xb8]
    303c:      	ldr	x29, [sp]
    3040:      	ldr	x30, [sp, #0x8]
    3044:      	add	sp, sp, #0xc0
    3048:      	ret
    304c:      	uxtb	w16, w19
    3050:      	cmp	w16, wzr
    3054:      	b.eq	0x30b4 <_stogir.verify.classifications+0x598>
    3058:      	ldr	x1, [sp, #0x60]
    305c:      	movz	x0, #0x0, lsl #48
    3060:      	movz	x2, #0x0, lsl #48
    3064:      	lsr	w0, w0, #0
    3068:      	lsr	x16, x0, #0
    306c:      	cmp	x16, #0x1
    3070:      	b.eq	0x308c <_stogir.verify.classifications+0x570>
    3074:      	b.lo	0x307c <_stogir.verify.classifications+0x560>
    3078:      	b	0x3090 <_stogir.verify.classifications+0x574>
    307c:      	cmp	x16, #0x0
    3080:      	b.eq	0x3088 <_stogir.verify.classifications+0x56c>
    3084:      	b	0x3090 <_stogir.verify.classifications+0x574>
    3088:      	b	0x3094 <_stogir.verify.classifications+0x578>
    308c:      	b	0x30a4 <_stogir.verify.classifications+0x588>
    3090:      	b	0x31c8 <_stogir.verify.classifications+0x6ac>
    3094:      	movz	x0, #0x0, lsl #48
    3098:      	b	0x30b0 <_stogir.verify.classifications+0x594>
    309c:      	movz	x0, #0x0, lsl #48
    30a0:      	b	0x2cc8 <_stogir.verify.classifications+0x1ac>
    30a4:      	lsr	w2, w2, #0
    30a8:      	sxtw	x2, w2
    30ac:      	mov	x0, x2
    30b0:      	b	0x2fdc <_stogir.verify.classifications+0x4c0>
    30b4:      	ldr	x0, [x23, #0x8]
    30b8:      	cmp	x24, x0
    30bc:      	b.ge	0x3204 <_stogir.verify.classifications+0x6e8>
    30c0:      	ldr	x0, [x20, #0x8]
    30c4:      	cmp	x24, x0
    30c8:      	b.ge	0x320c <_stogir.verify.classifications+0x6f0>
    30cc:      	ldr	x0, [x23, #0x78]
    30d0:      	ldr	x1, [sp, #0x60]
    30d4:      	add	x0, x1, x0
    30d8:      	ldr	w0, [x0]
    30dc:      	sxtw	x0, w0
    30e0:      	cmp	x0, #0x0
    30e4:      	b.lt	0x305c <_stogir.verify.classifications+0x540>
    30e8:      	ldr	w0, [sp, #0x68]
    30ec:      	sxtw	x0, w0
    30f0:      	cmp	x0, #0x1
    30f4:      	b.lt	0x31ac <_stogir.verify.classifications+0x690>
    30f8:      	ldr	x2, [x23, #0x78]
    30fc:      	add	x2, x1, x2
    3100:      	ldr	w2, [x2]
    3104:      	sxtw	x2, w2
    3108:      	cmp	x0, x2
    310c:      	b.gt	0x31ac <_stogir.verify.classifications+0x690>
    3110:      	ldr	x2, [x23]
    3114:      	asr	x16, x0, #63
    3118:      	lsr	x16, x16, #62
    311c:      	add	x3, x0, x16
    3120:      	asr	x3, x3, #2
    3124:      	asr	x16, x0, #63
    3128:      	lsr	x16, x16, #62
    312c:      	add	x0, x0, x16
    3130:      	and	x0, x0, #0x3
    3134:      	sub	x0, x0, x16
    3138:      	add	x3, x3, x24
    313c:      	lsl	x4, x0, #2
    3140:      	lsl	x4, x3, #4
    3144:      	add	x2, x2, x3, lsl #4
    3148:      	add	x0, x2, x0, lsl #2
    314c:      	ldr	w0, [x0]
    3150:      	sxtw	x0, w0
    3154:      	and	x0, x0, #0xffffffff
    3158:      	mov	x2, x0
    315c:      	mov	x0, #0x1                ; =1
    3160:      	b	0x31b4 <_stogir.verify.classifications+0x698>
    3164:      	movz	x5, #0x0, lsl #48
    3168:      	b	0x2b9c <_stogir.verify.classifications+0x80>
    316c:      	cmp	x21, #0x18
    3170:      	b.ne	0x317c <_stogir.verify.classifications+0x660>
    3174:      	mov	x0, #0x1                ; =1
    3178:      	b	0x2cb4 <_stogir.verify.classifications+0x198>
    317c:      	cmp	x21, #0x19
    3180:      	b.ne	0x318c <_stogir.verify.classifications+0x670>
    3184:      	mov	x0, #0x1                ; =1
    3188:      	b	0x2cb4 <_stogir.verify.classifications+0x198>
    318c:      	cmp	x19, #0xc
    3190:      	b.eq	0x2cb0 <_stogir.verify.classifications+0x194>
    3194:      	cmp	x19, #0xd
    3198:      	b.eq	0x2cb0 <_stogir.verify.classifications+0x194>
    319c:      	cmp	x0, #0xc
    31a0:      	b.ne	0x31b8 <_stogir.verify.classifications+0x69c>
    31a4:      	mov	x0, #0x1                ; =1
    31a8:      	b	0x31c4 <_stogir.verify.classifications+0x6a8>
    31ac:      	movz	x0, #0x0, lsl #48
    31b0:      	movz	x2, #0x0, lsl #48
    31b4:      	b	0x3064 <_stogir.verify.classifications+0x548>
    31b8:      	cmp	x0, #0xd
    31bc:      	cset	w0, eq
    31c0:      	ubfx	x0, x0, #0, #8
    31c4:      	b	0x2cb4 <_stogir.verify.classifications+0x198>
    31c8:      	brk	#0
    31cc:      	b	0x31c8 <_stogir.verify.classifications+0x6ac>
    31d0:      	str	x19, [sp, #0x38]
    31d4:      	str	x20, [sp, #0x40]
    31d8:      	b	0x2fe0 <_stogir.verify.classifications+0x4c4>
    31dc:      	str	x19, [sp, #0x38]
    31e0:      	str	x20, [sp, #0x40]
    31e4:      	b	0x2fe0 <_stogir.verify.classifications+0x4c4>
    31e8:      	ldr	x5, [sp, #0x58]
    31ec:      	b	0x2f7c <_stogir.verify.classifications+0x460>
    31f0:      	ldr	x5, [sp, #0x58]
    31f4:      	b	0x2d28 <_stogir.verify.classifications+0x20c>
    31f8:      	ldr	x6, [sp, #0x50]
    31fc:      	ldr	x8, [sp, #0x48]
    3200:      	b	0x2d38 <_stogir.verify.classifications+0x21c>
    3204:      	ldr	x1, [sp, #0x60]
    3208:      	b	0x305c <_stogir.verify.classifications+0x540>
    320c:      	ldr	x1, [sp, #0x60]
    3210:      	b	0x305c <_stogir.verify.classifications+0x540>

0000000000003214 <_stogir.vector-lanes.operation?>:
    3214:      	sxtw	x0, w0
    3218:      	cmp	x0, #0x3d
    321c:      	b.lt	0x3230 <_stogir.vector-lanes.operation?+0x1c>
    3220:      	cmp	x0, #0x3f
    3224:      	cset	w0, le
    3228:      	ubfx	x0, x0, #0, #8
    322c:      	b	0x3234 <_stogir.vector-lanes.operation?+0x20>
    3230:      	movz	x0, #0x0, lsl #48
    3234:      	ret

0000000000003238 <_stogir.vector.validate>:
    3238:      	sub	sp, sp, #0x210
    323c:      	str	x29, [sp]
    3240:      	str	x30, [sp, #0x8]
    3244:      	mov	x29, sp
    3248:      	str	x19, [sp, #0x1c0]
    324c:      	str	x20, [sp, #0x1c8]
    3250:      	str	x21, [sp, #0x1d0]
    3254:      	str	x22, [sp, #0x1d8]
    3258:      	str	x23, [sp, #0x1e0]
    325c:      	str	x24, [sp, #0x1e8]
    3260:      	str	x25, [sp, #0x1f0]
    3264:      	str	x26, [sp, #0x1f8]
    3268:      	str	x27, [sp, #0x200]
    326c:      	str	x28, [sp, #0x208]
    3270:      	lsr	w19, w1, #0
    3274:      	mov	x20, x8
    3278:      	add	x8, sp, #0x10
    327c:      	mov	x21, x0
    3280:      	mov	w22, w1
    3284:      	mov	w1, w19
    3288:      	mov	w23, w2
    328c:      	bl	0x328c <_stogir.vector.validate+0x54>
		000000000000328c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3290:      	add	x16, sp, #0x10
    3294:      	ldr	w0, [x16]
    3298:      	lsr	x16, x0, #0
    329c:      	cmp	x16, #0x1
    32a0:      	b.eq	0x32bc <_stogir.vector.validate+0x84>
    32a4:      	b.lo	0x32ac <_stogir.vector.validate+0x74>
    32a8:      	b	0x32c0 <_stogir.vector.validate+0x88>
    32ac:      	cmp	x16, #0x0
    32b0:      	b.eq	0x32b8 <_stogir.vector.validate+0x80>
    32b4:      	b	0x32c0 <_stogir.vector.validate+0x88>
    32b8:      	b	0x32c4 <_stogir.vector.validate+0x8c>
    32bc:      	b	0x335c <_stogir.vector.validate+0x124>
    32c0:      	b	0x357c <_stogir.vector.validate+0x344>
    32c4:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		00000000000032c4:  ARM64_RELOC_PAGE21	l_stogir.342
    32c8:      	ldr	x16, [x16]
		00000000000032c8:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    32cc:      	orr	x0, x16, xzr
    32d0:      	str	x20, [sp, #0x1a8]
    32d4:      	mov	x1, x0
    32d8:      	mov	x0, #0x1                ; =1
    32dc:      	mov	x2, #0x1a               ; =26
    32e0:      	b	0x3314 <_stogir.vector.validate+0xdc>
    32e4:      	lsr	w23, w23, #0
    32e8:      	add	x8, sp, #0x70
    32ec:      	mov	x0, x21
    32f0:      	ldr	w1, [sp, #0x1a0]
    32f4:      	mov	w2, w23
    32f8:      	bl	0x32f8 <_stogir.vector.validate+0xc0>
		00000000000032f8:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    32fc:      	add	x16, sp, #0x70
    3300:      	ldr	x0, [x16]
    3304:      	add	x16, sp, #0x70
    3308:      	ldr	x1, [x16, #0x8]
    330c:      	add	x16, sp, #0x70
    3310:      	ldr	x2, [x16, #0x10]
    3314:      	ldr	x3, [sp, #0x1a8]
    3318:      	str	x0, [x3]
    331c:      	str	x1, [x3, #0x8]
    3320:      	str	x2, [x3, #0x10]
    3324:      	ldr	x19, [sp, #0x1c0]
    3328:      	ldr	x20, [sp, #0x1c8]
    332c:      	ldr	x21, [sp, #0x1d0]
    3330:      	ldr	x22, [sp, #0x1d8]
    3334:      	ldr	x23, [sp, #0x1e0]
    3338:      	ldr	x24, [sp, #0x1e8]
    333c:      	ldr	x25, [sp, #0x1f0]
    3340:      	ldr	x26, [sp, #0x1f8]
    3344:      	ldr	x27, [sp, #0x200]
    3348:      	ldr	x28, [sp, #0x208]
    334c:      	ldr	x29, [sp]
    3350:      	ldr	x30, [sp, #0x8]
    3354:      	add	sp, sp, #0x210
    3358:      	ret
    335c:      	sxtw	x22, w22
    3360:      	add	x16, sp, #0x10
    3364:      	orr	x0, x16, xzr
    3368:      	cmp	x22, #0x0
    336c:      	cset	w24, le
    3370:      	add	x0, x0, #0x8
    3374:      	add	x16, sp, #0x10
    3378:      	ldr	x25, [x16, #0x8]
    337c:      	add	x16, sp, #0x40
    3380:      	str	x25, [x16]
    3384:      	ldr	x0, [x0, #0x8]
    3388:      	add	x16, sp, #0x40
    338c:      	str	x0, [x16, #0x8]
    3390:      	uxtb	w16, w24
    3394:      	cmp	w16, wzr
    3398:      	b.eq	0x33bc <_stogir.vector.validate+0x184>
    339c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		000000000000339c:  ARM64_RELOC_PAGE21	l_stogir.343
    33a0:      	ldr	x16, [x16]
		00000000000033a0:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    33a4:      	orr	x0, x16, xzr
    33a8:      	str	x20, [sp, #0x1a8]
    33ac:      	mov	x1, x0
    33b0:      	mov	x0, #0x1                ; =1
    33b4:      	mov	x2, #0x3b               ; =59
    33b8:      	b	0x3314 <_stogir.vector.validate+0xdc>
    33bc:      	lsl	x26, x22, #2
    33c0:      	uxtb	w0, w25
    33c4:      	orr	x27, x0, xzr
    33c8:      	ldr	x0, [x21, #0x78]
    33cc:      	cmp	x27, #0x44
    33d0:      	cset	w1, eq
    33d4:      	add	x0, x0, x22, lsl #2
    33d8:      	ldr	w28, [x0]
    33dc:      	cmp	x27, #0x24
    33e0:      	b.ne	0x3424 <_stogir.vector.validate+0x1ec>
    33e4:      	str	x20, [sp, #0x1a8]
    33e8:      	str	w19, [sp, #0x1a0]
    33ec:      	uxtb	w16, w1
    33f0:      	cmp	w16, wzr
    33f4:      	b.eq	0x32e4 <_stogir.vector.validate+0xac>
    33f8:      	add	x8, sp, #0x50
    33fc:      	mov	x0, x21
    3400:      	ldr	w1, [sp, #0x1a0]
    3404:      	bl	0x3404 <_stogir.vector.validate+0x1cc>
		0000000000003404:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    3408:      	add	x16, sp, #0x50
    340c:      	ldr	x0, [x16]
    3410:      	add	x16, sp, #0x50
    3414:      	ldr	x1, [x16, #0x8]
    3418:      	add	x16, sp, #0x50
    341c:      	ldr	x2, [x16, #0x10]
    3420:      	b	0x3314 <_stogir.vector.validate+0xdc>
    3424:      	uxtb	w16, w1
    3428:      	cmp	w16, wzr
    342c:      	b.ne	0x3cf4 <_stogir.vector.validate+0xabc>
    3430:      	cmp	x27, #0x3c
    3434:      	b.ne	0x34e8 <_stogir.vector.validate+0x2b0>
    3438:      	add	x8, sp, #0x90
    343c:      	mov	x0, x21
    3440:      	mov	w1, w19
    3444:      	bl	0x3444 <_stogir.vector.validate+0x20c>
		0000000000003444:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    3448:      	add	x16, sp, #0x90
    344c:      	ldr	x0, [x16]
    3450:      	add	x16, sp, #0x90
    3454:      	ldr	x1, [x16, #0x8]
    3458:      	add	x16, sp, #0x90
    345c:      	ldr	x2, [x16, #0x10]
    3460:      	str	x20, [sp, #0x1a8]
    3464:      	b	0x34e4 <_stogir.vector.validate+0x2ac>
    3468:      	cmp	x27, #0x41
    346c:      	cset	w0, eq
    3470:      	cmp	x27, #0x48
    3474:      	cset	w1, eq
    3478:      	cmp	x27, #0x55
    347c:      	cset	w2, ge
    3480:      	cmp	x27, #0x58
    3484:      	cset	w3, le
    3488:      	cmp	x27, #0x47
    348c:      	b.ne	0x3584 <_stogir.vector.validate+0x34c>
    3490:      	str	x20, [sp, #0x1a8]
    3494:      	str	w19, [sp, #0x1a0]
    3498:      	mov	w19, w0
    349c:      	mov	w20, w1
    34a0:      	str	w2, [sp, #0x1b0]
    34a4:      	str	w3, [sp, #0x1b8]
    34a8:      	mov	x0, x21
    34ac:      	ldr	w1, [sp, #0x1a0]
    34b0:      	bl	0x34b0 <_stogir.vector.validate+0x278>
		00000000000034b0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    34b4:      	cmp	x0, #0x0
    34b8:      	b.eq	0x35a8 <_stogir.vector.validate+0x370>
    34bc:      	add	x8, sp, #0xf0
    34c0:      	mov	x0, x21
    34c4:      	ldr	w1, [sp, #0x1a0]
    34c8:      	bl	0x34c8 <_stogir.vector.validate+0x290>
		00000000000034c8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    34cc:      	add	x16, sp, #0xf0
    34d0:      	ldr	x0, [x16]
    34d4:      	add	x16, sp, #0xf0
    34d8:      	ldr	x1, [x16, #0x8]
    34dc:      	add	x16, sp, #0xf0
    34e0:      	ldr	x2, [x16, #0x10]
    34e4:      	b	0x3314 <_stogir.vector.validate+0xdc>
    34e8:      	cmp	x27, #0x3d
    34ec:      	b.lt	0x3530 <_stogir.vector.validate+0x2f8>
    34f0:      	cmp	x27, #0x3f
    34f4:      	b.gt	0x3530 <_stogir.vector.validate+0x2f8>
    34f8:      	lsr	w23, w23, #0
    34fc:      	add	x8, sp, #0xb0
    3500:      	mov	x0, x21
    3504:      	mov	w1, w19
    3508:      	mov	w2, w23
    350c:      	bl	0x350c <_stogir.vector.validate+0x2d4>
		000000000000350c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    3510:      	add	x16, sp, #0xb0
    3514:      	ldr	x0, [x16]
    3518:      	add	x16, sp, #0xb0
    351c:      	ldr	x1, [x16, #0x8]
    3520:      	add	x16, sp, #0xb0
    3524:      	ldr	x2, [x16, #0x10]
    3528:      	str	x20, [sp, #0x1a8]
    352c:      	b	0x34e4 <_stogir.vector.validate+0x2ac>
    3530:      	mov	x0, x21
    3534:      	mov	w1, w19
    3538:      	bl	0x3538 <_stogir.vector.validate+0x300>
		0000000000003538:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    353c:      	cmp	x0, #0x0
    3540:      	b.eq	0x3468 <_stogir.vector.validate+0x230>
    3544:      	lsr	w23, w23, #0
    3548:      	add	x8, sp, #0xd0
    354c:      	mov	x0, x21
    3550:      	mov	w1, w19
    3554:      	mov	w2, w23
    3558:      	bl	0x3558 <_stogir.vector.validate+0x320>
		0000000000003558:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    355c:      	add	x16, sp, #0xd0
    3560:      	ldr	x0, [x16]
    3564:      	add	x16, sp, #0xd0
    3568:      	ldr	x1, [x16, #0x8]
    356c:      	add	x16, sp, #0xd0
    3570:      	ldr	x2, [x16, #0x10]
    3574:      	str	x20, [sp, #0x1a8]
    3578:      	b	0x34e4 <_stogir.vector.validate+0x2ac>
    357c:      	brk	#0
    3580:      	b	0x357c <_stogir.vector.validate+0x344>
    3584:      	cmp	x27, #0x4f
    3588:      	b.ne	0x3624 <_stogir.vector.validate+0x3ec>
    358c:      	str	x20, [sp, #0x1a8]
    3590:      	str	w19, [sp, #0x1a0]
    3594:      	mov	w19, w0
    3598:      	mov	w20, w1
    359c:      	str	w2, [sp, #0x1b0]
    35a0:      	str	w3, [sp, #0x1b8]
    35a4:      	b	0x34a8 <_stogir.vector.validate+0x270>
    35a8:      	uxtb	w16, w19
    35ac:      	cmp	w16, wzr
    35b0:      	b.ne	0x35f0 <_stogir.vector.validate+0x3b8>
    35b4:      	uxtb	w16, w20
    35b8:      	cmp	w16, wzr
    35bc:      	b.ne	0x35f0 <_stogir.vector.validate+0x3b8>
    35c0:      	ldr	w0, [sp, #0x1b0]
    35c4:      	uxtb	w16, w0
    35c8:      	cmp	w16, wzr
    35cc:      	b.eq	0x35e0 <_stogir.vector.validate+0x3a8>
    35d0:      	ldr	w0, [sp, #0x1b8]
    35d4:      	uxtb	w16, w0
    35d8:      	cmp	w16, wzr
    35dc:      	b.ne	0x35f0 <_stogir.vector.validate+0x3b8>
    35e0:      	movz	x0, #0x0, lsl #48
    35e4:      	movz	x1, #0x0, lsl #48
    35e8:      	movz	x2, #0x0, lsl #48
    35ec:      	b	0x3620 <_stogir.vector.validate+0x3e8>
    35f0:      	lsr	w23, w23, #0
    35f4:      	add	x8, sp, #0x110
    35f8:      	mov	x0, x21
    35fc:      	ldr	w1, [sp, #0x1a0]
    3600:      	mov	w2, w23
    3604:      	bl	0x3604 <_stogir.vector.validate+0x3cc>
		0000000000003604:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    3608:      	add	x16, sp, #0x110
    360c:      	ldr	x0, [x16]
    3610:      	add	x16, sp, #0x110
    3614:      	ldr	x1, [x16, #0x8]
    3618:      	add	x16, sp, #0x110
    361c:      	ldr	x2, [x16, #0x10]
    3620:      	b	0x34e4 <_stogir.vector.validate+0x2ac>
    3624:      	cmp	x27, #0x50
    3628:      	b.eq	0x3d00 <_stogir.vector.validate+0xac8>
    362c:      	cmp	x27, #0x78
    3630:      	b.ne	0x3650 <_stogir.vector.validate+0x418>
    3634:      	str	x20, [sp, #0x1a8]
    3638:      	str	w19, [sp, #0x1a0]
    363c:      	mov	w19, w0
    3640:      	mov	w20, w1
    3644:      	str	w2, [sp, #0x1b0]
    3648:      	str	w3, [sp, #0x1b8]
    364c:      	b	0x34a8 <_stogir.vector.validate+0x270>
    3650:      	uxtb	w16, w0
    3654:      	cmp	w16, wzr
    3658:      	b.ne	0x3758 <_stogir.vector.validate+0x520>
    365c:      	uxtb	w16, w1
    3660:      	cmp	w16, wzr
    3664:      	b.ne	0x3758 <_stogir.vector.validate+0x520>
    3668:      	uxtb	w16, w2
    366c:      	cmp	w16, wzr
    3670:      	b.eq	0x3680 <_stogir.vector.validate+0x448>
    3674:      	uxtb	w16, w3
    3678:      	cmp	w16, wzr
    367c:      	b.ne	0x3758 <_stogir.vector.validate+0x520>
    3680:      	str	w2, [sp, #0x1b0]
    3684:      	str	w3, [sp, #0x1b8]
    3688:      	str	w19, [sp, #0x1a0]
    368c:      	str	x20, [sp, #0x1a8]
    3690:      	mov	w20, w1
    3694:      	mov	w1, w19
    3698:      	mov	w19, w0
    369c:      	mov	x0, x21
    36a0:      	bl	0x36a0 <_stogir.vector.validate+0x468>
		00000000000036a0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    36a4:      	cmp	x0, #0x0
    36a8:      	b.ne	0x34a8 <_stogir.vector.validate+0x270>
    36ac:      	sxtw	x28, w28
    36b0:      	lsr	w25, w25, #0
    36b4:      	ubfx	x0, x25, #8, #8
    36b8:      	orr	x1, x0, xzr
    36bc:      	lsr	w19, w1, #0
    36c0:      	cmp	x27, #0x5b
    36c4:      	b.eq	0x3790 <_stogir.vector.validate+0x558>
    36c8:      	cmp	x27, #0x5c
    36cc:      	b.eq	0x3790 <_stogir.vector.validate+0x558>
    36d0:      	orr	x20, x0, xzr
    36d4:      	cmp	x27, #0x5d
    36d8:      	b.eq	0x3808 <_stogir.vector.validate+0x5d0>
    36dc:      	cmp	x27, #0x5e
    36e0:      	b.eq	0x3808 <_stogir.vector.validate+0x5d0>
    36e4:      	cmp	x27, #0x43
    36e8:      	b.ne	0x3884 <_stogir.vector.validate+0x64c>
    36ec:      	cmp	x20, #0xf
    36f0:      	b.le	0x3ba8 <_stogir.vector.validate+0x970>
    36f4:      	cmp	x20, #0x80
    36f8:      	b.ge	0x3ba8 <_stogir.vector.validate+0x970>
    36fc:      	and	x0, x20, #0xf
    3700:      	lsr	w0, w0, #0
    3704:      	sxtw	x0, w0
    3708:      	cmp	x0, #0x1
    370c:      	b.lt	0x3ba8 <_stogir.vector.validate+0x970>
    3710:      	cmp	x0, #0xd
    3714:      	b.gt	0x3ba8 <_stogir.vector.validate+0x970>
    3718:      	lsr	w23, w23, #0
    371c:      	mov	w0, w19
    3720:      	mov	w1, w23
    3724:      	bl	0x3724 <_stogir.vector.validate+0x4ec>
		0000000000003724:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3728:      	lsr	w0, w0, #0
    372c:      	sxtw	x0, w0
    3730:      	cmp	x0, #0x0
    3734:      	b.le	0x3ba8 <_stogir.vector.validate+0x970>
    3738:      	cmp	x28, #0x3
    373c:      	b.lt	0x3ba8 <_stogir.vector.validate+0x970>
    3740:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003740:  ARM64_RELOC_PAGE21	l_stogir.344
    3744:      	ldr	x16, [x16]
		0000000000003744:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    3748:      	orr	x0, x16, xzr
    374c:      	mov	x25, x0
    3750:      	movz	x27, #0x0, lsl #48
    3754:      	b	0x3bbc <_stogir.vector.validate+0x984>
    3758:      	str	x20, [sp, #0x1a8]
    375c:      	str	w19, [sp, #0x1a0]
    3760:      	mov	w19, w0
    3764:      	mov	w20, w1
    3768:      	str	w2, [sp, #0x1b0]
    376c:      	str	w3, [sp, #0x1b8]
    3770:      	b	0x34a8 <_stogir.vector.validate+0x270>
    3774:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003774:  ARM64_RELOC_PAGE21	l_stogir.345
    3778:      	ldr	x16, [x16]
		0000000000003778:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    377c:      	orr	x0, x16, xzr
    3780:      	mov	x1, x0
    3784:      	mov	x0, #0x1                ; =1
    3788:      	mov	x2, #0x19               ; =25
    378c:      	b	0x34e4 <_stogir.vector.validate+0x2ac>
    3790:      	cmp	x28, #0x2
    3794:      	b.ne	0x3774 <_stogir.vector.validate+0x53c>
    3798:      	lsr	w23, w23, #0
    379c:      	add	x16, sp, #0x40
    37a0:      	ldr	w0, [x16, #0x4]
    37a4:      	add	x16, sp, #0x40
    37a8:      	ldr	w1, [x16, #0x8]
    37ac:      	lsr	w0, w0, #0
    37b0:      	lsr	w1, w1, #0
    37b4:      	add	x8, sp, #0x130
    37b8:      	mov	w2, w23
    37bc:      	mov	w3, w0
    37c0:      	mov	x0, x21
    37c4:      	mov	w4, w1
    37c8:      	mov	w1, w19
    37cc:      	bl	0x37cc <_stogir.vector.validate+0x594>
		00000000000037cc:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    37d0:      	add	x16, sp, #0x130
    37d4:      	ldr	x0, [x16]
    37d8:      	add	x16, sp, #0x130
    37dc:      	ldr	x1, [x16, #0x8]
    37e0:      	add	x16, sp, #0x130
    37e4:      	ldr	x2, [x16, #0x10]
    37e8:      	b	0x378c <_stogir.vector.validate+0x554>
    37ec:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		00000000000037ec:  ARM64_RELOC_PAGE21	l_stogir.346
    37f0:      	ldr	x16, [x16]
		00000000000037f0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    37f4:      	orr	x0, x16, xzr
    37f8:      	mov	x1, x0
    37fc:      	mov	x0, #0x1                ; =1
    3800:      	mov	x2, #0x1a               ; =26
    3804:      	b	0x378c <_stogir.vector.validate+0x554>
    3808:      	cmp	x28, #0x3
    380c:      	b.ne	0x37ec <_stogir.vector.validate+0x5b4>
    3810:      	cmp	x20, #0x0
    3814:      	b.ne	0x37ec <_stogir.vector.validate+0x5b4>
    3818:      	lsr	w23, w23, #0
    381c:      	add	x16, sp, #0x40
    3820:      	ldr	w0, [x16, #0x4]
    3824:      	add	x16, sp, #0x40
    3828:      	ldr	w1, [x16, #0x8]
    382c:      	lsr	w0, w0, #0
    3830:      	add	x16, sp, #0x40
    3834:      	ldr	w2, [x16, #0xc]
    3838:      	lsr	w1, w1, #0
    383c:      	lsr	w2, w2, #0
    3840:      	add	x8, sp, #0x150
    3844:      	mov	w3, w1
    3848:      	mov	w1, w23
    384c:      	mov	w4, w2
    3850:      	mov	w2, w0
    3854:      	mov	x0, x21
    3858:      	bl	0x3858 <_stogir.vector.validate+0x620>
		0000000000003858:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    385c:      	add	x16, sp, #0x150
    3860:      	ldr	x0, [x16]
    3864:      	add	x16, sp, #0x150
    3868:      	ldr	x1, [x16, #0x8]
    386c:      	add	x16, sp, #0x150
    3870:      	ldr	x2, [x16, #0x10]
    3874:      	b	0x3804 <_stogir.vector.validate+0x5cc>
    3878:      	mov	x2, x8
    387c:      	mov	x0, #0x1                ; =1
    3880:      	b	0x3804 <_stogir.vector.validate+0x5cc>
    3884:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003884:  ARM64_RELOC_PAGE21	l_stogir.347
    3888:      	ldr	x16, [x16]
		0000000000003888:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    388c:      	orr	x0, x16, xzr
    3890:      	mov	x1, x0
    3894:      	mov	x0, #0x1                ; =1
    3898:      	mov	x2, #0x28               ; =40
    389c:      	b	0x3880 <_stogir.vector.validate+0x648>
    38a0:      	mov	x0, x1
    38a4:      	mov	x1, x27
    38a8:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		00000000000038a8:  ARM64_RELOC_PAGE21	l_stogir.348
    38ac:      	ldr	x16, [x16]
		00000000000038ac:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    38b0:      	orr	x2, x16, xzr
    38b4:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		00000000000038b4:  ARM64_RELOC_PAGE21	l_stogir.349
    38b8:      	ldr	x16, [x16]
		00000000000038b8:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    38bc:      	orr	x3, x16, xzr
    38c0:      	add	x4, x21, #0x78
    38c4:      	add	x5, x21, #0x28
    38c8:      	add	x6, x21, #0x50
    38cc:      	add	x7, x21, #0x78
    38d0:      	mov	x8, x1
    38d4:      	mov	x1, x0
    38d8:      	mov	x0, #0x2                ; =2
    38dc:      	b	0x3954 <_stogir.vector.validate+0x71c>
    38e0:      	lsr	w10, w10, #0
    38e4:      	ubfx	x9, x10, #8, #8
    38e8:      	cmp	x9, x20
    38ec:      	b.eq	0x38f8 <_stogir.vector.validate+0x6c0>
    38f0:      	mov	x1, x3
    38f4:      	mov	x8, #0x1e               ; =30
    38f8:      	b	0x3948 <_stogir.vector.validate+0x710>
    38fc:      	movz	x9, #0x0, lsl #48
    3900:      	movz	x10, #0x0, lsl #48
    3904:      	b	0x3910 <_stogir.vector.validate+0x6d8>
    3908:      	movz	x9, #0x0, lsl #48
    390c:      	movz	x10, #0x0, lsl #48
    3910:      	lsr	w9, w9, #0
    3914:      	lsr	x16, x9, #0
    3918:      	cmp	x16, #0x1
    391c:      	b.eq	0x3938 <_stogir.vector.validate+0x700>
    3920:      	b.lo	0x3928 <_stogir.vector.validate+0x6f0>
    3924:      	b	0x393c <_stogir.vector.validate+0x704>
    3928:      	cmp	x16, #0x0
    392c:      	b.eq	0x3934 <_stogir.vector.validate+0x6fc>
    3930:      	b	0x393c <_stogir.vector.validate+0x704>
    3934:      	b	0x3940 <_stogir.vector.validate+0x708>
    3938:      	b	0x39a8 <_stogir.vector.validate+0x770>
    393c:      	b	0x3cdc <_stogir.vector.validate+0xaa4>
    3940:      	mov	x1, x2
    3944:      	mov	x8, #0x18               ; =24
    3948:      	add	x0, x0, #0x1
    394c:      	lsr	w0, w0, #0
    3950:      	sxtw	x0, w0
    3954:      	cmp	x8, #0x0
    3958:      	b.ne	0x3ae0 <_stogir.vector.validate+0x8a8>
    395c:      	cmp	x0, x28
    3960:      	b.gt	0x3ae0 <_stogir.vector.validate+0x8a8>
    3964:      	uxtb	w16, w24
    3968:      	cmp	w16, wzr
    396c:      	b.ne	0x3908 <_stogir.vector.validate+0x6d0>
    3970:      	ldr	x9, [x21, #0x8]
    3974:      	cmp	x22, x9
    3978:      	b.ge	0x3a14 <_stogir.vector.validate+0x7dc>
    397c:      	ldr	x9, [x7, #0x8]
    3980:      	cmp	x22, x9
    3984:      	b.ge	0x3a0c <_stogir.vector.validate+0x7d4>
    3988:      	ldr	x9, [x21, #0x78]
    398c:      	add	x9, x26, x9
    3990:      	ldr	w9, [x9]
    3994:      	sxtw	x9, w9
    3998:      	cmp	x9, #0x0
    399c:      	cset	w9, ge
    39a0:      	ubfx	x9, x9, #0, #8
    39a4:      	b	0x3a10 <_stogir.vector.validate+0x7d8>
    39a8:      	lsr	w10, w10, #0
    39ac:      	sxtw	x10, w10
    39b0:      	cmp	x10, #0x0
    39b4:      	cset	w9, gt
    39b8:      	movz	x16, #0x0, lsl #48
    39bc:      	sub	x11, x16, x10
    39c0:      	sub	x12, x11, #0x1
    39c4:      	uxtb	w16, w9
    39c8:      	cmp	w16, wzr
    39cc:      	b.eq	0x3a9c <_stogir.vector.validate+0x864>
    39d0:      	ldr	x11, [x21, #0x8]
    39d4:      	cmp	x10, x11
    39d8:      	b.ge	0x3b14 <_stogir.vector.validate+0x8dc>
    39dc:      	ldr	x11, [x4, #0x8]
    39e0:      	cmp	x10, x11
    39e4:      	b.ge	0x3c28 <_stogir.vector.validate+0x9f0>
    39e8:      	lsl	x11, x10, #2
    39ec:      	ldr	x11, [x21, #0x78]
    39f0:      	add	x11, x11, x10, lsl #2
    39f4:      	ldr	w11, [x11]
    39f8:      	sxtw	x11, w11
    39fc:      	cmp	x11, #0x0
    3a00:      	cset	w11, ge
    3a04:      	ubfx	x11, x11, #0, #8
    3a08:      	b	0x3c2c <_stogir.vector.validate+0x9f4>
    3a0c:      	movz	x9, #0x0, lsl #48
    3a10:      	b	0x3a18 <_stogir.vector.validate+0x7e0>
    3a14:      	movz	x9, #0x0, lsl #48
    3a18:      	cmp	x9, #0x0
    3a1c:      	b.eq	0x3908 <_stogir.vector.validate+0x6d0>
    3a20:      	lsr	w9, w0, #0
    3a24:      	sxtw	x9, w9
    3a28:      	cmp	x9, #0x1
    3a2c:      	b.lt	0x38fc <_stogir.vector.validate+0x6c4>
    3a30:      	ldr	x10, [x21, #0x78]
    3a34:      	add	x10, x26, x10
    3a38:      	ldr	w10, [x10]
    3a3c:      	sxtw	x10, w10
    3a40:      	cmp	x9, x10
    3a44:      	b.gt	0x38fc <_stogir.vector.validate+0x6c4>
    3a48:      	ldr	x10, [x21]
    3a4c:      	asr	x16, x9, #63
    3a50:      	lsr	x16, x16, #62
    3a54:      	add	x11, x9, x16
    3a58:      	asr	x11, x11, #2
    3a5c:      	asr	x16, x9, #63
    3a60:      	lsr	x16, x16, #62
    3a64:      	add	x9, x9, x16
    3a68:      	and	x9, x9, #0x3
    3a6c:      	sub	x9, x9, x16
    3a70:      	add	x11, x11, x22
    3a74:      	lsl	x12, x9, #2
    3a78:      	lsl	x12, x11, #4
    3a7c:      	add	x10, x10, x11, lsl #4
    3a80:      	add	x9, x10, x9, lsl #2
    3a84:      	ldr	w9, [x9]
    3a88:      	sxtw	x9, w9
    3a8c:      	and	x9, x9, #0xffffffff
    3a90:      	mov	x10, x9
    3a94:      	mov	x9, #0x1                ; =1
    3a98:      	b	0x3904 <_stogir.vector.validate+0x6cc>
    3a9c:      	cmp	x10, #0x0
    3aa0:      	b.ge	0x3b1c <_stogir.vector.validate+0x8e4>
    3aa4:      	ldr	x13, [x5, #0x8]
    3aa8:      	ldr	x14, [x6, #0x8]
    3aac:      	cmp	x13, x14
    3ab0:      	b.ne	0x3c20 <_stogir.vector.validate+0x9e8>
    3ab4:      	cmp	x11, x13
    3ab8:      	b.gt	0x3c58 <_stogir.vector.validate+0xa20>
    3abc:      	lsl	x11, x12, #2
    3ac0:      	ldr	x11, [x21, #0x50]
    3ac4:      	add	x11, x11, x12, lsl #2
    3ac8:      	ldr	w11, [x11]
    3acc:      	sxtw	x11, w11
    3ad0:      	cmp	x11, #0x0
    3ad4:      	cset	w11, gt
    3ad8:      	ubfx	x11, x11, #0, #8
    3adc:      	b	0x3c5c <_stogir.vector.validate+0xa24>
    3ae0:      	cmp	x8, #0x0
    3ae4:      	b.ne	0x3878 <_stogir.vector.validate+0x640>
    3ae8:      	lsr	w23, w23, #0
    3aec:      	mov	w0, w19
    3af0:      	mov	w1, w23
    3af4:      	bl	0x3af4 <_stogir.vector.validate+0x8bc>
		0000000000003af4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3af8:      	lsr	w0, w0, #0
    3afc:      	sxtw	x0, w0
    3b00:      	and	x0, x0, #0xffffffff
    3b04:      	mov	x1, x0
    3b08:      	movz	x0, #0x0, lsl #48
    3b0c:      	movz	x2, #0x0, lsl #48
    3b10:      	b	0x3880 <_stogir.vector.validate+0x648>
    3b14:      	movz	x11, #0x0, lsl #48
    3b18:      	b	0x3b20 <_stogir.vector.validate+0x8e8>
    3b1c:      	movz	x11, #0x0, lsl #48
    3b20:      	cmp	x11, #0x0
    3b24:      	b.eq	0x3b64 <_stogir.vector.validate+0x92c>
    3b28:      	uxtb	w16, w9
    3b2c:      	cmp	w16, wzr
    3b30:      	b.eq	0x3b48 <_stogir.vector.validate+0x910>
    3b34:      	lsl	x9, x10, #4
    3b38:      	ldr	x9, [x21]
    3b3c:      	add	x9, x9, x10, lsl #4
    3b40:      	ldr	x9, [x9]
    3b44:      	b	0x3b58 <_stogir.vector.validate+0x920>
    3b48:      	lsl	x9, x12, #4
    3b4c:      	ldr	x9, [x21, #0x28]
    3b50:      	add	x9, x9, x12, lsl #4
    3b54:      	ldr	x9, [x9]
    3b58:      	mov	x10, x9
    3b5c:      	mov	x9, #0x1                ; =1
    3b60:      	b	0x3b6c <_stogir.vector.validate+0x934>
    3b64:      	movz	x9, #0x0, lsl #48
    3b68:      	movz	x10, #0x0, lsl #48
    3b6c:      	lsr	w9, w9, #0
    3b70:      	lsr	x16, x9, #0
    3b74:      	cmp	x16, #0x1
    3b78:      	b.eq	0x3b94 <_stogir.vector.validate+0x95c>
    3b7c:      	b.lo	0x3b84 <_stogir.vector.validate+0x94c>
    3b80:      	b	0x3b98 <_stogir.vector.validate+0x960>
    3b84:      	cmp	x16, #0x0
    3b88:      	b.eq	0x3b90 <_stogir.vector.validate+0x958>
    3b8c:      	b	0x3b98 <_stogir.vector.validate+0x960>
    3b90:      	b	0x3b9c <_stogir.vector.validate+0x964>
    3b94:      	b	0x38e0 <_stogir.vector.validate+0x6a8>
    3b98:      	b	0x3ce4 <_stogir.vector.validate+0xaac>
    3b9c:      	mov	x1, x2
    3ba0:      	mov	x8, #0x18               ; =24
    3ba4:      	b	0x38f8 <_stogir.vector.validate+0x6c0>
    3ba8:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003ba8:  ARM64_RELOC_PAGE21	l_stogir.350
    3bac:      	ldr	x16, [x16]
		0000000000003bac:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    3bb0:      	orr	x0, x16, xzr
    3bb4:      	mov	x25, x0
    3bb8:      	mov	x27, #0x20              ; =32
    3bbc:      	add	x16, sp, #0x40
    3bc0:      	ldr	w0, [x16, #0x4]
    3bc4:      	lsr	w0, w0, #0
    3bc8:      	add	x8, sp, #0x170
    3bcc:      	mov	w1, w0
    3bd0:      	mov	x0, x21
    3bd4:      	bl	0x3bd4 <_stogir.vector.validate+0x99c>
		0000000000003bd4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3bd8:      	add	x16, sp, #0x170
    3bdc:      	ldr	w0, [x16]
    3be0:      	lsr	x16, x0, #0
    3be4:      	cmp	x16, #0x1
    3be8:      	b.eq	0x3c04 <_stogir.vector.validate+0x9cc>
    3bec:      	b.lo	0x3bf4 <_stogir.vector.validate+0x9bc>
    3bf0:      	b	0x3c08 <_stogir.vector.validate+0x9d0>
    3bf4:      	cmp	x16, #0x0
    3bf8:      	b.eq	0x3c00 <_stogir.vector.validate+0x9c8>
    3bfc:      	b	0x3c08 <_stogir.vector.validate+0x9d0>
    3c00:      	b	0x3c0c <_stogir.vector.validate+0x9d4>
    3c04:      	b	0x3c30 <_stogir.vector.validate+0x9f8>
    3c08:      	b	0x3cec <_stogir.vector.validate+0xab4>
    3c0c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003c0c:  ARM64_RELOC_PAGE21	l_stogir.351
    3c10:      	ldr	x16, [x16]
		0000000000003c10:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    3c14:      	orr	x0, x16, xzr
    3c18:      	mov	x1, #0x19               ; =25
    3c1c:      	b	0x38a8 <_stogir.vector.validate+0x670>
    3c20:      	movz	x11, #0x0, lsl #48
    3c24:      	b	0x3b20 <_stogir.vector.validate+0x8e8>
    3c28:      	movz	x11, #0x0, lsl #48
    3c2c:      	b	0x3b18 <_stogir.vector.validate+0x8e0>
    3c30:      	add	x16, sp, #0x170
    3c34:      	ldr	x0, [x16, #0x8]
    3c38:      	add	x16, sp, #0x40
    3c3c:      	ldr	w1, [x16, #0x4]
    3c40:      	sxtw	x1, w1
    3c44:      	cmp	x1, #0x0
    3c48:      	b.gt	0x3cc0 <_stogir.vector.validate+0xa88>
    3c4c:      	mov	x1, x25
    3c50:      	mov	x0, #0x1                ; =1
    3c54:      	b	0x3ca4 <_stogir.vector.validate+0xa6c>
    3c58:      	movz	x11, #0x0, lsl #48
    3c5c:      	b	0x3c24 <_stogir.vector.validate+0x9ec>
    3c60:      	add	x16, sp, #0x40
    3c64:      	ldr	w0, [x16, #0x4]
    3c68:      	sxtw	x0, w0
    3c6c:      	ldr	x1, [x21, #0x78]
    3c70:      	lsl	x2, x0, #2
    3c74:      	add	x0, x1, x0, lsl #2
    3c78:      	ldr	w0, [x0]
    3c7c:      	sxtw	x0, w0
    3c80:      	add	x0, x0, #0x1
    3c84:      	lsr	w0, w0, #0
    3c88:      	sxtw	x0, w0
    3c8c:      	cmp	x28, x0
    3c90:      	cset	w0, eq
    3c94:      	uxtb	w16, w0
    3c98:      	cmp	w16, wzr
    3c9c:      	cset	x0, eq
    3ca0:      	mov	x1, x25
    3ca4:      	cmp	x0, #0x0
    3ca8:      	b.eq	0x38a0 <_stogir.vector.validate+0x668>
    3cac:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003cac:  ARM64_RELOC_PAGE21	l_stogir.352
    3cb0:      	ldr	x16, [x16]
		0000000000003cb0:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    3cb4:      	orr	x0, x16, xzr
    3cb8:      	mov	x1, #0x19               ; =25
    3cbc:      	b	0x38a8 <_stogir.vector.validate+0x670>
    3cc0:      	uxtb	w0, w0
    3cc4:      	cmp	x0, #0x70
    3cc8:      	b.eq	0x3c60 <_stogir.vector.validate+0xa28>
    3ccc:      	cmp	x0, #0x71
    3cd0:      	b.eq	0x3c60 <_stogir.vector.validate+0xa28>
    3cd4:      	mov	x0, #0x1                ; =1
    3cd8:      	b	0x3ca0 <_stogir.vector.validate+0xa68>
    3cdc:      	brk	#0
    3ce0:      	b	0x3cdc <_stogir.vector.validate+0xaa4>
    3ce4:      	brk	#0
    3ce8:      	b	0x3ce4 <_stogir.vector.validate+0xaac>
    3cec:      	brk	#0
    3cf0:      	b	0x3cec <_stogir.vector.validate+0xab4>
    3cf4:      	str	x20, [sp, #0x1a8]
    3cf8:      	str	w19, [sp, #0x1a0]
    3cfc:      	b	0x33ec <_stogir.vector.validate+0x1b4>
    3d00:      	str	x20, [sp, #0x1a8]
    3d04:      	str	w19, [sp, #0x1a0]
    3d08:      	mov	w19, w0
    3d0c:      	mov	w20, w1
    3d10:      	str	w2, [sp, #0x1b0]
    3d14:      	str	w3, [sp, #0x1b8]
    3d18:      	b	0x34a8 <_stogir.vector.validate+0x270>

0000000000003d1c <_stogir.copy.validate>:
    3d1c:      	sub	sp, sp, #0x40
    3d20:      	str	x29, [sp]
    3d24:      	str	x30, [sp, #0x8]
    3d28:      	mov	x29, sp
    3d2c:      	str	x19, [sp, #0x20]
    3d30:      	str	x20, [sp, #0x28]
    3d34:      	str	x21, [sp, #0x30]
    3d38:      	sxtw	x1, w1
    3d3c:      	lsl	x2, x1, #2
    3d40:      	cmp	x1, #0x0
    3d44:      	cset	w3, gt
    3d48:      	movz	x16, #0x0, lsl #48
    3d4c:      	sub	x4, x16, x1
    3d50:      	sub	x5, x4, #0x1
    3d54:      	uxtb	w16, w3
    3d58:      	cmp	w16, wzr
    3d5c:      	b.eq	0x3d9c <_stogir.copy.validate+0x80>
    3d60:      	ldr	x4, [x0, #0x8]
    3d64:      	cmp	x1, x4
    3d68:      	b.ge	0x3df0 <_stogir.copy.validate+0xd4>
    3d6c:      	add	x4, x0, #0x78
    3d70:      	ldr	x4, [x4, #0x8]
    3d74:      	cmp	x1, x4
    3d78:      	b.ge	0x3f1c <_stogir.copy.validate+0x200>
    3d7c:      	ldr	x4, [x0, #0x78]
    3d80:      	add	x4, x2, x4
    3d84:      	ldr	w4, [x4]
    3d88:      	sxtw	x4, w4
    3d8c:      	cmp	x4, #0x0
    3d90:      	cset	w4, ge
    3d94:      	ubfx	x4, x4, #0, #8
    3d98:      	b	0x3f20 <_stogir.copy.validate+0x204>
    3d9c:      	cmp	x1, #0x0
    3da0:      	b.ge	0x3df8 <_stogir.copy.validate+0xdc>
    3da4:      	add	x6, x0, #0x28
    3da8:      	add	x7, x0, #0x50
    3dac:      	ldr	x6, [x6, #0x8]
    3db0:      	ldr	x7, [x7, #0x8]
    3db4:      	cmp	x6, x7
    3db8:      	b.ne	0x3de8 <_stogir.copy.validate+0xcc>
    3dbc:      	cmp	x4, x6
    3dc0:      	b.gt	0x3f64 <_stogir.copy.validate+0x248>
    3dc4:      	lsl	x4, x5, #2
    3dc8:      	ldr	x4, [x0, #0x50]
    3dcc:      	add	x4, x4, x5, lsl #2
    3dd0:      	ldr	w4, [x4]
    3dd4:      	sxtw	x4, w4
    3dd8:      	cmp	x4, #0x0
    3ddc:      	cset	w4, gt
    3de0:      	ubfx	x4, x4, #0, #8
    3de4:      	b	0x3f68 <_stogir.copy.validate+0x24c>
    3de8:      	movz	x4, #0x0, lsl #48
    3dec:      	b	0x3dfc <_stogir.copy.validate+0xe0>
    3df0:      	movz	x4, #0x0, lsl #48
    3df4:      	b	0x3dfc <_stogir.copy.validate+0xe0>
    3df8:      	movz	x4, #0x0, lsl #48
    3dfc:      	cmp	x4, #0x0
    3e00:      	b.eq	0x3e64 <_stogir.copy.validate+0x148>
    3e04:      	uxtb	w16, w3
    3e08:      	cmp	w16, wzr
    3e0c:      	b.eq	0x3e34 <_stogir.copy.validate+0x118>
    3e10:      	lsl	x3, x1, #4
    3e14:      	ldr	x3, [x0]
    3e18:      	add	x3, x3, x1, lsl #4
    3e1c:      	ldr	x4, [x3]
    3e20:      	ldr	x3, [x3, #0x8]
    3e24:      	fmov	d31, x3
    3e28:      	mov	x3, x4
    3e2c:      	fmov	x4, d31
    3e30:      	b	0x3e54 <_stogir.copy.validate+0x138>
    3e34:      	lsl	x3, x5, #4
    3e38:      	ldr	x3, [x0, #0x28]
    3e3c:      	add	x3, x3, x5, lsl #4
    3e40:      	ldr	x4, [x3]
    3e44:      	ldr	x3, [x3, #0x8]
    3e48:      	fmov	d31, x3
    3e4c:      	mov	x3, x4
    3e50:      	fmov	x4, d31
    3e54:      	mov	x5, x4
    3e58:      	mov	x4, x3
    3e5c:      	mov	x3, #0x1                ; =1
    3e60:      	b	0x3e70 <_stogir.copy.validate+0x154>
    3e64:      	movz	x3, #0x0, lsl #48
    3e68:      	movz	x4, #0x0, lsl #48
    3e6c:      	movz	x5, #0x0, lsl #48
    3e70:      	lsr	w3, w3, #0
    3e74:      	lsr	x16, x3, #0
    3e78:      	cmp	x16, #0x1
    3e7c:      	b.eq	0x3e98 <_stogir.copy.validate+0x17c>
    3e80:      	b.lo	0x3e88 <_stogir.copy.validate+0x16c>
    3e84:      	b	0x3e9c <_stogir.copy.validate+0x180>
    3e88:      	cmp	x16, #0x0
    3e8c:      	b.eq	0x3e94 <_stogir.copy.validate+0x178>
    3e90:      	b	0x3e9c <_stogir.copy.validate+0x180>
    3e94:      	b	0x3ea0 <_stogir.copy.validate+0x184>
    3e98:      	b	0x3ee4 <_stogir.copy.validate+0x1c8>
    3e9c:      	b	0x3ff4 <_stogir.copy.validate+0x2d8>
    3ea0:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003ea0:  ARM64_RELOC_PAGE21	l_stogir.353
    3ea4:      	ldr	x16, [x16]
		0000000000003ea4:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    3ea8:      	orr	x0, x16, xzr
    3eac:      	mov	x20, x8
    3eb0:      	mov	x1, x0
    3eb4:      	mov	x0, #0x1                ; =1
    3eb8:      	mov	x2, #0x18               ; =24
    3ebc:      	str	x0, [x20]
    3ec0:      	str	x1, [x20, #0x8]
    3ec4:      	str	x2, [x20, #0x10]
    3ec8:      	ldr	x19, [sp, #0x20]
    3ecc:      	ldr	x20, [sp, #0x28]
    3ed0:      	ldr	x21, [sp, #0x30]
    3ed4:      	ldr	x29, [sp]
    3ed8:      	ldr	x30, [sp, #0x8]
    3edc:      	add	sp, sp, #0x40
    3ee0:      	ret
    3ee4:      	add	x16, sp, #0x10
    3ee8:      	str	x4, [x16]
    3eec:      	add	x16, sp, #0x10
    3ef0:      	str	x5, [x16, #0x8]
    3ef4:      	cmp	x1, #0x0
    3ef8:      	b.gt	0x3f24 <_stogir.copy.validate+0x208>
    3efc:      	mov	x20, x8
    3f00:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003f00:  ARM64_RELOC_PAGE21	l_stogir.354
    3f04:      	ldr	x16, [x16]
		0000000000003f04:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    3f08:      	orr	x0, x16, xzr
    3f0c:      	mov	x1, x0
    3f10:      	mov	x0, #0x1                ; =1
    3f14:      	mov	x2, #0x21               ; =33
    3f18:      	b	0x3ebc <_stogir.copy.validate+0x1a0>
    3f1c:      	movz	x4, #0x0, lsl #48
    3f20:      	b	0x3df4 <_stogir.copy.validate+0xd8>
    3f24:      	uxtb	w1, w4
    3f28:      	cmp	x1, #0x44
    3f2c:      	b.ne	0x4158 <_stogir.copy.validate+0x43c>
    3f30:      	ldr	x1, [x0, #0x78]
    3f34:      	add	x1, x2, x1
    3f38:      	ldr	w1, [x1]
    3f3c:      	sxtw	x1, w1
    3f40:      	cmp	x1, #0x2
    3f44:      	b.ne	0x4160 <_stogir.copy.validate+0x444>
    3f48:      	lsr	w4, w4, #0
    3f4c:      	ubfx	x1, x4, #8, #8
    3f50:      	orr	x19, x1, xzr
    3f54:      	cmp	x19, #0x0
    3f58:      	b.ne	0x3f6c <_stogir.copy.validate+0x250>
    3f5c:      	mov	x20, x8
    3f60:      	b	0x3f00 <_stogir.copy.validate+0x1e4>
    3f64:      	movz	x4, #0x0, lsl #48
    3f68:      	b	0x3dec <_stogir.copy.validate+0xd0>
    3f6c:      	lsr	w1, w1, #0
    3f70:      	mov	x20, x8
    3f74:      	mov	x21, x0
    3f78:      	mov	w0, w1
    3f7c:      	bl	0x3f7c <_stogir.copy.validate+0x260>
		0000000000003f7c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    3f80:      	cmp	x0, #0x0
    3f84:      	b.eq	0x3f00 <_stogir.copy.validate+0x1e4>
    3f88:      	add	x16, sp, #0x10
    3f8c:      	ldr	w0, [x16, #0x4]
    3f90:      	sxtw	x0, w0
    3f94:      	cmp	x0, #0x0
    3f98:      	cset	w1, gt
    3f9c:      	movz	x16, #0x0, lsl #48
    3fa0:      	sub	x2, x16, x0
    3fa4:      	sub	x3, x2, #0x1
    3fa8:      	uxtb	w16, w1
    3fac:      	cmp	w16, wzr
    3fb0:      	b.eq	0x4018 <_stogir.copy.validate+0x2fc>
    3fb4:      	ldr	x2, [x21, #0x8]
    3fb8:      	cmp	x0, x2
    3fbc:      	b.ge	0x4064 <_stogir.copy.validate+0x348>
    3fc0:      	add	x2, x21, #0x78
    3fc4:      	ldr	x2, [x2, #0x8]
    3fc8:      	cmp	x0, x2
    3fcc:      	b.ge	0x4140 <_stogir.copy.validate+0x424>
    3fd0:      	lsl	x2, x0, #2
    3fd4:      	ldr	x2, [x21, #0x78]
    3fd8:      	add	x2, x2, x0, lsl #2
    3fdc:      	ldr	w2, [x2]
    3fe0:      	sxtw	x2, w2
    3fe4:      	cmp	x2, #0x0
    3fe8:      	cset	w2, ge
    3fec:      	ubfx	x2, x2, #0, #8
    3ff0:      	b	0x4144 <_stogir.copy.validate+0x428>
    3ff4:      	brk	#0
    3ff8:      	b	0x3ff4 <_stogir.copy.validate+0x2d8>
    3ffc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4e4>
		0000000000003ffc:  ARM64_RELOC_PAGE21	l_stogir.355
    4000:      	ldr	x16, [x16]
		0000000000004000:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    4004:      	orr	x0, x16, xzr
    4008:      	mov	x1, x0
    400c:      	mov	x0, #0x1                ; =1
    4010:      	mov	x2, #0x20               ; =32
    4014:      	b	0x3f18 <_stogir.copy.validate+0x1fc>
    4018:      	cmp	x0, #0x0
    401c:      	b.ge	0x406c <_stogir.copy.validate+0x350>
    4020:      	add	x4, x21, #0x28
    4024:      	add	x5, x21, #0x50
    4028:      	ldr	x4, [x4, #0x8]
    402c:      	ldr	x5, [x5, #0x8]
    4030:      	cmp	x4, x5
    4034:      	b.ne	0x4138 <_stogir.copy.validate+0x41c>
    4038:      	cmp	x2, x4
    403c:      	b.gt	0x4148 <_stogir.copy.validate+0x42c>
    4040:      	lsl	x2, x3, #2
    4044:      	ldr	x2, [x21, #0x50]
    4048:      	add	x2, x2, x3, lsl #2
    404c:      	ldr	w2, [x2]
    4050:      	sxtw	x2, w2
    4054:      	cmp	x2, #0x0
    4058:      	cset	w2, gt
    405c:      	ubfx	x2, x2, #0, #8
    4060:      	b	0x414c <_stogir.copy.validate+0x430>
    4064:      	movz	x2, #0x0, lsl #48
    4068:      	b	0x4070 <_stogir.copy.validate+0x354>
    406c:      	movz	x2, #0x0, lsl #48
    4070:      	cmp	x2, #0x0
    4074:      	b.eq	0x40b4 <_stogir.copy.validate+0x398>
    4078:      	uxtb	w16, w1
    407c:      	cmp	w16, wzr
    4080:      	b.eq	0x4098 <_stogir.copy.validate+0x37c>
    4084:      	lsl	x1, x0, #4
    4088:      	ldr	x1, [x21]
    408c:      	add	x0, x1, x0, lsl #4
    4090:      	ldr	x0, [x0]
    4094:      	b	0x40a8 <_stogir.copy.validate+0x38c>
    4098:      	lsl	x0, x3, #4
    409c:      	ldr	x0, [x21, #0x28]
    40a0:      	add	x0, x0, x3, lsl #4
    40a4:      	ldr	x0, [x0]
    40a8:      	mov	x1, x0
    40ac:      	mov	x0, #0x1                ; =1
    40b0:      	b	0x40bc <_stogir.copy.validate+0x3a0>
    40b4:      	movz	x0, #0x0, lsl #48
    40b8:      	movz	x1, #0x0, lsl #48
    40bc:      	lsr	w0, w0, #0
    40c0:      	lsr	x16, x0, #0
    40c4:      	cmp	x16, #0x1
    40c8:      	b.eq	0x40e4 <_stogir.copy.validate+0x3c8>
    40cc:      	b.lo	0x40d4 <_stogir.copy.validate+0x3b8>
    40d0:      	b	0x40e8 <_stogir.copy.validate+0x3cc>
    40d4:      	cmp	x16, #0x0
    40d8:      	b.eq	0x40e0 <_stogir.copy.validate+0x3c4>
    40dc:      	b	0x40e8 <_stogir.copy.validate+0x3cc>
    40e0:      	b	0x40ec <_stogir.copy.validate+0x3d0>
    40e4:      	b	0x4108 <_stogir.copy.validate+0x3ec>
    40e8:      	b	0x4150 <_stogir.copy.validate+0x434>
    40ec:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		00000000000040ec:  ARM64_RELOC_PAGE21	l_stogir.356
    40f0:      	ldr	x16, [x16]
		00000000000040f0:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    40f4:      	orr	x0, x16, xzr
    40f8:      	mov	x1, x0
    40fc:      	mov	x0, #0x1                ; =1
    4100:      	mov	x2, #0x13               ; =19
    4104:      	b	0x4014 <_stogir.copy.validate+0x2f8>
    4108:      	lsr	w1, w1, #0
    410c:      	add	x16, sp, #0x10
    4110:      	ldr	w0, [x16]
    4114:      	ubfx	x1, x1, #8, #8
    4118:      	ubfx	x0, x0, #8, #8
    411c:      	cmp	x1, x0
    4120:      	b.ne	0x3ffc <_stogir.copy.validate+0x2e0>
    4124:      	and	x0, x19, #0xffffffff
    4128:      	mov	x1, x0
    412c:      	movz	x0, #0x0, lsl #48
    4130:      	movz	x2, #0x0, lsl #48
    4134:      	b	0x4014 <_stogir.copy.validate+0x2f8>
    4138:      	movz	x2, #0x0, lsl #48
    413c:      	b	0x4070 <_stogir.copy.validate+0x354>
    4140:      	movz	x2, #0x0, lsl #48
    4144:      	b	0x4068 <_stogir.copy.validate+0x34c>
    4148:      	movz	x2, #0x0, lsl #48
    414c:      	b	0x413c <_stogir.copy.validate+0x420>
    4150:      	brk	#0
    4154:      	b	0x4150 <_stogir.copy.validate+0x434>
    4158:      	mov	x20, x8
    415c:      	b	0x3f00 <_stogir.copy.validate+0x1e4>
    4160:      	mov	x20, x8
    4164:      	b	0x3f00 <_stogir.copy.validate+0x1e4>

0000000000004168 <_stogir.graph.lookup>:
    4168:      	sxtw	x1, w1
    416c:      	cmp	x1, #0x0
    4170:      	cset	w2, gt
    4174:      	movz	x16, #0x0, lsl #48
    4178:      	sub	x3, x16, x1
    417c:      	sub	x4, x3, #0x1
    4180:      	uxtb	w16, w2
    4184:      	cmp	w16, wzr
    4188:      	b.eq	0x41cc <_stogir.graph.lookup+0x64>
    418c:      	ldr	x3, [x0, #0x8]
    4190:      	cmp	x1, x3
    4194:      	b.ge	0x4220 <_stogir.graph.lookup+0xb8>
    4198:      	add	x3, x0, #0x78
    419c:      	ldr	x3, [x3, #0x8]
    41a0:      	cmp	x1, x3
    41a4:      	b.ge	0x42c0 <_stogir.graph.lookup+0x158>
    41a8:      	lsl	x3, x1, #2
    41ac:      	ldr	x3, [x0, #0x78]
    41b0:      	add	x3, x3, x1, lsl #2
    41b4:      	ldr	w3, [x3]
    41b8:      	sxtw	x3, w3
    41bc:      	cmp	x3, #0x0
    41c0:      	cset	w3, ge
    41c4:      	ubfx	x3, x3, #0, #8
    41c8:      	b	0x42c4 <_stogir.graph.lookup+0x15c>
    41cc:      	cmp	x1, #0x0
    41d0:      	b.ge	0x4228 <_stogir.graph.lookup+0xc0>
    41d4:      	add	x5, x0, #0x28
    41d8:      	add	x6, x0, #0x50
    41dc:      	ldr	x5, [x5, #0x8]
    41e0:      	ldr	x6, [x6, #0x8]
    41e4:      	cmp	x5, x6
    41e8:      	b.ne	0x4218 <_stogir.graph.lookup+0xb0>
    41ec:      	cmp	x3, x5
    41f0:      	b.gt	0x42c8 <_stogir.graph.lookup+0x160>
    41f4:      	lsl	x3, x4, #2
    41f8:      	ldr	x3, [x0, #0x50]
    41fc:      	add	x3, x3, x4, lsl #2
    4200:      	ldr	w3, [x3]
    4204:      	sxtw	x3, w3
    4208:      	cmp	x3, #0x0
    420c:      	cset	w3, gt
    4210:      	ubfx	x3, x3, #0, #8
    4214:      	b	0x42cc <_stogir.graph.lookup+0x164>
    4218:      	movz	x3, #0x0, lsl #48
    421c:      	b	0x422c <_stogir.graph.lookup+0xc4>
    4220:      	movz	x3, #0x0, lsl #48
    4224:      	b	0x422c <_stogir.graph.lookup+0xc4>
    4228:      	movz	x3, #0x0, lsl #48
    422c:      	cmp	x3, #0x0
    4230:      	b.eq	0x4294 <_stogir.graph.lookup+0x12c>
    4234:      	uxtb	w16, w2
    4238:      	cmp	w16, wzr
    423c:      	b.eq	0x4264 <_stogir.graph.lookup+0xfc>
    4240:      	lsl	x2, x1, #4
    4244:      	ldr	x0, [x0]
    4248:      	add	x0, x0, x1, lsl #4
    424c:      	ldr	x1, [x0]
    4250:      	ldr	x0, [x0, #0x8]
    4254:      	fmov	d31, x0
    4258:      	mov	x0, x1
    425c:      	fmov	x1, d31
    4260:      	b	0x4284 <_stogir.graph.lookup+0x11c>
    4264:      	lsl	x1, x4, #4
    4268:      	ldr	x0, [x0, #0x28]
    426c:      	add	x0, x0, x4, lsl #4
    4270:      	ldr	x1, [x0]
    4274:      	ldr	x0, [x0, #0x8]
    4278:      	fmov	d31, x0
    427c:      	mov	x0, x1
    4280:      	fmov	x1, d31
    4284:      	mov	x2, x1
    4288:      	mov	x1, x0
    428c:      	mov	x0, #0x1                ; =1
    4290:      	b	0x42a0 <_stogir.graph.lookup+0x138>
    4294:      	movz	x0, #0x0, lsl #48
    4298:      	movz	x1, #0x0, lsl #48
    429c:      	movz	x2, #0x0, lsl #48
    42a0:      	str	x0, [x8]
    42a4:      	str	x1, [x8, #0x8]
    42a8:      	str	x2, [x8, #0x10]
    42ac:      	movz	x17, #0x0, lsl #48
    42b0:      	str	x17, [x8, #0x18]
    42b4:      	movz	x17, #0x0, lsl #48
    42b8:      	str	x17, [x8, #0x20]
    42bc:      	ret
    42c0:      	movz	x3, #0x0, lsl #48
    42c4:      	b	0x4224 <_stogir.graph.lookup+0xbc>
    42c8:      	movz	x3, #0x0, lsl #48
    42cc:      	b	0x421c <_stogir.graph.lookup+0xb4>

00000000000042d0 <_stogir.opcode.block-start?>:
    42d0:      	sxtw	x0, w0
    42d4:      	cmp	x0, #0x0
    42d8:      	b.lt	0x4300 <_stogir.opcode.block-start?+0x30>
    42dc:      	cmp	x0, #0x83
    42e0:      	b.ge	0x4300 <_stogir.opcode.block-start?+0x30>
    42e4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		00000000000042e4:  ARM64_RELOC_PAGE21	l_stogir.357
    42e8:      	ldr	x16, [x16]
		00000000000042e8:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    42ec:      	orr	x1, x16, xzr
    42f0:      	lsr	x2, x0, #0
    42f4:      	add	x0, x1, x0
    42f8:      	ldrb	w0, [x0]
    42fc:      	b	0x4304 <_stogir.opcode.block-start?+0x34>
    4300:      	movz	x0, #0x0, lsl #48
    4304:      	uxtb	w0, w0
    4308:      	and	x0, x0, #0x2
    430c:      	uxtb	w0, w0
    4310:      	cmp	x0, #0x0
    4314:      	cset	w0, eq
    4318:      	uxtb	w16, w0
    431c:      	cmp	w16, wzr
    4320:      	cset	x0, eq
    4324:      	ret

0000000000004328 <_stogir.checked.operation?>:
    4328:      	sxtw	x0, w0
    432c:      	cmp	x0, #0x29
    4330:      	b.lt	0x4344 <_stogir.checked.operation?+0x1c>
    4334:      	cmp	x0, #0x2b
    4338:      	cset	w0, le
    433c:      	ubfx	x0, x0, #0, #8
    4340:      	b	0x4348 <_stogir.checked.operation?+0x20>
    4344:      	movz	x0, #0x0, lsl #48
    4348:      	ret

000000000000434c <_stogir.checked.validate-projection>:
    434c:      	sub	sp, sp, #0x40
    4350:      	str	x29, [sp]
    4354:      	str	x30, [sp, #0x8]
    4358:      	mov	x29, sp
    435c:      	str	x19, [sp, #0x30]
    4360:      	sxtw	x1, w1
    4364:      	lsl	x2, x1, #2
    4368:      	cmp	x1, #0x0
    436c:      	cset	w3, gt
    4370:      	movz	x16, #0x0, lsl #48
    4374:      	sub	x4, x16, x1
    4378:      	sub	x5, x4, #0x1
    437c:      	uxtb	w16, w3
    4380:      	cmp	w16, wzr
    4384:      	b.eq	0x43c4 <_stogir.checked.validate-projection+0x78>
    4388:      	ldr	x4, [x0, #0x8]
    438c:      	cmp	x1, x4
    4390:      	b.ge	0x4418 <_stogir.checked.validate-projection+0xcc>
    4394:      	add	x4, x0, #0x78
    4398:      	ldr	x4, [x4, #0x8]
    439c:      	cmp	x1, x4
    43a0:      	b.ge	0x4504 <_stogir.checked.validate-projection+0x1b8>
    43a4:      	ldr	x4, [x0, #0x78]
    43a8:      	add	x4, x2, x4
    43ac:      	ldr	w4, [x4]
    43b0:      	sxtw	x4, w4
    43b4:      	cmp	x4, #0x0
    43b8:      	cset	w4, ge
    43bc:      	ubfx	x4, x4, #0, #8
    43c0:      	b	0x4508 <_stogir.checked.validate-projection+0x1bc>
    43c4:      	cmp	x1, #0x0
    43c8:      	b.ge	0x4420 <_stogir.checked.validate-projection+0xd4>
    43cc:      	add	x6, x0, #0x28
    43d0:      	add	x7, x0, #0x50
    43d4:      	ldr	x6, [x6, #0x8]
    43d8:      	ldr	x7, [x7, #0x8]
    43dc:      	cmp	x6, x7
    43e0:      	b.ne	0x4410 <_stogir.checked.validate-projection+0xc4>
    43e4:      	cmp	x4, x6
    43e8:      	b.gt	0x4570 <_stogir.checked.validate-projection+0x224>
    43ec:      	lsl	x4, x5, #2
    43f0:      	ldr	x4, [x0, #0x50]
    43f4:      	add	x4, x4, x5, lsl #2
    43f8:      	ldr	w4, [x4]
    43fc:      	sxtw	x4, w4
    4400:      	cmp	x4, #0x0
    4404:      	cset	w4, gt
    4408:      	ubfx	x4, x4, #0, #8
    440c:      	b	0x4574 <_stogir.checked.validate-projection+0x228>
    4410:      	movz	x4, #0x0, lsl #48
    4414:      	b	0x4424 <_stogir.checked.validate-projection+0xd8>
    4418:      	movz	x4, #0x0, lsl #48
    441c:      	b	0x4424 <_stogir.checked.validate-projection+0xd8>
    4420:      	movz	x4, #0x0, lsl #48
    4424:      	cmp	x4, #0x0
    4428:      	b.eq	0x4468 <_stogir.checked.validate-projection+0x11c>
    442c:      	uxtb	w16, w3
    4430:      	cmp	w16, wzr
    4434:      	b.eq	0x444c <_stogir.checked.validate-projection+0x100>
    4438:      	lsl	x3, x1, #4
    443c:      	ldr	x3, [x0]
    4440:      	add	x3, x3, x1, lsl #4
    4444:      	ldr	x3, [x3]
    4448:      	b	0x445c <_stogir.checked.validate-projection+0x110>
    444c:      	lsl	x3, x5, #4
    4450:      	ldr	x3, [x0, #0x28]
    4454:      	add	x3, x3, x5, lsl #4
    4458:      	ldr	x3, [x3]
    445c:      	mov	x4, x3
    4460:      	mov	x3, #0x1                ; =1
    4464:      	b	0x4470 <_stogir.checked.validate-projection+0x124>
    4468:      	movz	x3, #0x0, lsl #48
    446c:      	movz	x4, #0x0, lsl #48
    4470:      	lsr	w3, w3, #0
    4474:      	lsr	x16, x3, #0
    4478:      	cmp	x16, #0x1
    447c:      	b.eq	0x4498 <_stogir.checked.validate-projection+0x14c>
    4480:      	b.lo	0x4488 <_stogir.checked.validate-projection+0x13c>
    4484:      	b	0x449c <_stogir.checked.validate-projection+0x150>
    4488:      	cmp	x16, #0x0
    448c:      	b.eq	0x4494 <_stogir.checked.validate-projection+0x148>
    4490:      	b	0x449c <_stogir.checked.validate-projection+0x150>
    4494:      	b	0x44a0 <_stogir.checked.validate-projection+0x154>
    4498:      	b	0x44c0 <_stogir.checked.validate-projection+0x174>
    449c:      	b	0x4578 <_stogir.checked.validate-projection+0x22c>
    44a0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		00000000000044a0:  ARM64_RELOC_PAGE21	l_stogir.358
    44a4:      	ldr	x16, [x16]
		00000000000044a4:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    44a8:      	orr	x0, x16, xzr
    44ac:      	mov	x19, x8
    44b0:      	mov	x1, x0
    44b4:      	mov	x0, #0x1                ; =1
    44b8:      	mov	x2, #0x10               ; =16
    44bc:      	b	0x44e4 <_stogir.checked.validate-projection+0x198>
    44c0:      	cmp	x1, #0x0
    44c4:      	b.gt	0x450c <_stogir.checked.validate-projection+0x1c0>
    44c8:      	mov	x19, x8
    44cc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		00000000000044cc:  ARM64_RELOC_PAGE21	l_stogir.359
    44d0:      	ldr	x16, [x16]
		00000000000044d0:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    44d4:      	orr	x0, x16, xzr
    44d8:      	mov	x1, x0
    44dc:      	mov	x0, #0x1                ; =1
    44e0:      	mov	x2, #0x1c               ; =28
    44e4:      	str	x0, [x19]
    44e8:      	str	x1, [x19, #0x8]
    44ec:      	str	x2, [x19, #0x10]
    44f0:      	ldr	x19, [sp, #0x30]
    44f4:      	ldr	x29, [sp]
    44f8:      	ldr	x30, [sp, #0x8]
    44fc:      	add	sp, sp, #0x40
    4500:      	ret
    4504:      	movz	x4, #0x0, lsl #48
    4508:      	b	0x441c <_stogir.checked.validate-projection+0xd0>
    450c:      	uxtb	w1, w4
    4510:      	cmp	x1, #0x2c
    4514:      	b.ne	0x4580 <_stogir.checked.validate-projection+0x234>
    4518:      	lsr	w1, w4, #0
    451c:      	ubfx	x1, x1, #8, #8
    4520:      	cmp	x1, #0x1
    4524:      	b.ne	0x4588 <_stogir.checked.validate-projection+0x23c>
    4528:      	ldr	x1, [x0, #0x78]
    452c:      	add	x1, x2, x1
    4530:      	ldr	w1, [x1]
    4534:      	sxtw	x1, w1
    4538:      	cmp	x1, #0x1
    453c:      	b.ne	0x4590 <_stogir.checked.validate-projection+0x244>
    4540:      	lsr	x1, x4, #32
    4544:      	lsr	w1, w1, #0
    4548:      	mov	x19, x8
    454c:      	add	x8, sp, #0x10
    4550:      	bl	0x4550 <_stogir.checked.validate-projection+0x204>
		0000000000004550:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    4554:      	add	x16, sp, #0x10
    4558:      	ldr	x0, [x16]
    455c:      	add	x16, sp, #0x10
    4560:      	ldr	x1, [x16, #0x8]
    4564:      	add	x16, sp, #0x10
    4568:      	ldr	x2, [x16, #0x10]
    456c:      	b	0x44e4 <_stogir.checked.validate-projection+0x198>
    4570:      	movz	x4, #0x0, lsl #48
    4574:      	b	0x4414 <_stogir.checked.validate-projection+0xc8>
    4578:      	brk	#0
    457c:      	b	0x4578 <_stogir.checked.validate-projection+0x22c>
    4580:      	mov	x19, x8
    4584:      	b	0x44cc <_stogir.checked.validate-projection+0x180>
    4588:      	mov	x19, x8
    458c:      	b	0x44cc <_stogir.checked.validate-projection+0x180>
    4590:      	mov	x19, x8
    4594:      	b	0x44cc <_stogir.checked.validate-projection+0x180>

0000000000004598 <_stogir.checked.validate>:
    4598:      	sub	sp, sp, #0x30
    459c:      	str	x29, [sp]
    45a0:      	str	x30, [sp, #0x8]
    45a4:      	mov	x29, sp
    45a8:      	str	x19, [sp, #0x10]
    45ac:      	str	x20, [sp, #0x18]
    45b0:      	str	x21, [sp, #0x20]
    45b4:      	sxtw	x1, w1
    45b8:      	lsl	x2, x1, #2
    45bc:      	cmp	x1, #0x0
    45c0:      	cset	w3, gt
    45c4:      	movz	x16, #0x0, lsl #48
    45c8:      	sub	x4, x16, x1
    45cc:      	sub	x5, x4, #0x1
    45d0:      	uxtb	w16, w3
    45d4:      	cmp	w16, wzr
    45d8:      	b.eq	0x4618 <_stogir.checked.validate+0x80>
    45dc:      	ldr	x4, [x0, #0x8]
    45e0:      	cmp	x1, x4
    45e4:      	b.ge	0x466c <_stogir.checked.validate+0xd4>
    45e8:      	add	x4, x0, #0x78
    45ec:      	ldr	x4, [x4, #0x8]
    45f0:      	cmp	x1, x4
    45f4:      	b.ge	0x47f8 <_stogir.checked.validate+0x260>
    45f8:      	ldr	x4, [x0, #0x78]
    45fc:      	add	x4, x2, x4
    4600:      	ldr	w4, [x4]
    4604:      	sxtw	x4, w4
    4608:      	cmp	x4, #0x0
    460c:      	cset	w4, ge
    4610:      	ubfx	x4, x4, #0, #8
    4614:      	b	0x47fc <_stogir.checked.validate+0x264>
    4618:      	cmp	x1, #0x0
    461c:      	b.ge	0x4674 <_stogir.checked.validate+0xdc>
    4620:      	add	x6, x0, #0x28
    4624:      	add	x7, x0, #0x50
    4628:      	ldr	x6, [x6, #0x8]
    462c:      	ldr	x7, [x7, #0x8]
    4630:      	cmp	x6, x7
    4634:      	b.ne	0x4664 <_stogir.checked.validate+0xcc>
    4638:      	cmp	x4, x6
    463c:      	b.gt	0x4800 <_stogir.checked.validate+0x268>
    4640:      	lsl	x4, x5, #2
    4644:      	ldr	x4, [x0, #0x50]
    4648:      	add	x4, x4, x5, lsl #2
    464c:      	ldr	w4, [x4]
    4650:      	sxtw	x4, w4
    4654:      	cmp	x4, #0x0
    4658:      	cset	w4, gt
    465c:      	ubfx	x4, x4, #0, #8
    4660:      	b	0x4804 <_stogir.checked.validate+0x26c>
    4664:      	movz	x4, #0x0, lsl #48
    4668:      	b	0x4678 <_stogir.checked.validate+0xe0>
    466c:      	movz	x4, #0x0, lsl #48
    4670:      	b	0x4678 <_stogir.checked.validate+0xe0>
    4674:      	movz	x4, #0x0, lsl #48
    4678:      	cmp	x4, #0x0
    467c:      	b.eq	0x46e0 <_stogir.checked.validate+0x148>
    4680:      	uxtb	w16, w3
    4684:      	cmp	w16, wzr
    4688:      	b.eq	0x46b0 <_stogir.checked.validate+0x118>
    468c:      	lsl	x3, x1, #4
    4690:      	ldr	x3, [x0]
    4694:      	add	x3, x3, x1, lsl #4
    4698:      	ldr	x4, [x3]
    469c:      	ldr	x3, [x3, #0x8]
    46a0:      	fmov	d31, x3
    46a4:      	mov	x3, x4
    46a8:      	fmov	x4, d31
    46ac:      	b	0x46d0 <_stogir.checked.validate+0x138>
    46b0:      	lsl	x3, x5, #4
    46b4:      	ldr	x3, [x0, #0x28]
    46b8:      	add	x3, x3, x5, lsl #4
    46bc:      	ldr	x4, [x3]
    46c0:      	ldr	x3, [x3, #0x8]
    46c4:      	fmov	d31, x3
    46c8:      	mov	x3, x4
    46cc:      	fmov	x4, d31
    46d0:      	mov	x5, x4
    46d4:      	mov	x4, x3
    46d8:      	mov	x3, #0x1                ; =1
    46dc:      	b	0x46ec <_stogir.checked.validate+0x154>
    46e0:      	movz	x3, #0x0, lsl #48
    46e4:      	movz	x4, #0x0, lsl #48
    46e8:      	movz	x5, #0x0, lsl #48
    46ec:      	lsr	w3, w3, #0
    46f0:      	lsr	x16, x3, #0
    46f4:      	cmp	x16, #0x1
    46f8:      	b.eq	0x4714 <_stogir.checked.validate+0x17c>
    46fc:      	b.lo	0x4704 <_stogir.checked.validate+0x16c>
    4700:      	b	0x4718 <_stogir.checked.validate+0x180>
    4704:      	cmp	x16, #0x0
    4708:      	b.eq	0x4710 <_stogir.checked.validate+0x178>
    470c:      	b	0x4718 <_stogir.checked.validate+0x180>
    4710:      	b	0x471c <_stogir.checked.validate+0x184>
    4714:      	b	0x477c <_stogir.checked.validate+0x1e4>
    4718:      	b	0x4a78 <_stogir.checked.validate+0x4e0>
    471c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		000000000000471c:  ARM64_RELOC_PAGE21	l_stogir.360
    4720:      	ldr	x16, [x16]
		0000000000004720:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    4724:      	orr	x0, x16, xzr
    4728:      	mov	x1, x0
    472c:      	mov	x0, #0x1                ; =1
    4730:      	mov	x2, #0x1a               ; =26
    4734:      	b	0x4750 <_stogir.checked.validate+0x1b8>
    4738:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004738:  ARM64_RELOC_PAGE21	l_stogir.361
    473c:      	ldr	x16, [x16]
		000000000000473c:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    4740:      	orr	x0, x16, xzr
    4744:      	mov	x1, x0
    4748:      	mov	x0, #0x1                ; =1
    474c:      	mov	x2, #0x26               ; =38
    4750:      	str	x0, [x8]
    4754:      	str	x1, [x8, #0x8]
    4758:      	str	x2, [x8, #0x10]
    475c:      	sub	sp, x29, #0x0
    4760:      	ldr	x19, [sp, #0x10]
    4764:      	ldr	x20, [sp, #0x18]
    4768:      	ldr	x21, [sp, #0x20]
    476c:      	ldr	x29, [sp]
    4770:      	ldr	x30, [sp, #0x8]
    4774:      	add	sp, sp, #0x30
    4778:      	ret
    477c:      	cmp	x1, #0x0
    4780:      	b.le	0x4738 <_stogir.checked.validate+0x1a0>
    4784:      	uxtb	w1, w4
    4788:      	cmp	x1, #0x29
    478c:      	b.lt	0x4738 <_stogir.checked.validate+0x1a0>
    4790:      	cmp	x1, #0x2b
    4794:      	b.gt	0x4738 <_stogir.checked.validate+0x1a0>
    4798:      	ldr	x1, [x0, #0x78]
    479c:      	add	x1, x2, x1
    47a0:      	ldr	w1, [x1]
    47a4:      	sxtw	x1, w1
    47a8:      	cmp	x1, #0x2
    47ac:      	b.ne	0x4738 <_stogir.checked.validate+0x1a0>
    47b0:      	lsr	w1, w4, #0
    47b4:      	mov	x2, sp
    47b8:      	sub	sp, sp, #0x10
    47bc:      	mov	x3, sp
    47c0:      	sub	sp, sp, #0x10
    47c4:      	mov	x6, sp
    47c8:      	ubfx	x1, x1, #8, #8
    47cc:      	cmp	x1, #0x1
    47d0:      	b.lt	0x4a00 <_stogir.checked.validate+0x468>
    47d4:      	cmp	x1, #0xb
    47d8:      	b.gt	0x4a00 <_stogir.checked.validate+0x468>
    47dc:      	cmp	x1, #0x1
    47e0:      	b.eq	0x4a00 <_stogir.checked.validate+0x468>
    47e4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		00000000000047e4:  ARM64_RELOC_PAGE21	l_stogir.362
    47e8:      	ldr	x16, [x16]
		00000000000047e8:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    47ec:      	orr	x7, x16, xzr
    47f0:      	movz	x9, #0x0, lsl #48
    47f4:      	b	0x4a10 <_stogir.checked.validate+0x478>
    47f8:      	movz	x4, #0x0, lsl #48
    47fc:      	b	0x4670 <_stogir.checked.validate+0xd8>
    4800:      	movz	x4, #0x0, lsl #48
    4804:      	b	0x4668 <_stogir.checked.validate+0xd0>
    4808:      	mov	x1, x3
    480c:      	mov	x3, x4
    4810:      	mov	x0, #0x1                ; =1
    4814:      	mov	sp, x2
    4818:      	mov	x2, x3
    481c:      	b	0x4750 <_stogir.checked.validate+0x1b8>
    4820:      	movz	x5, #0x0, lsl #48
    4824:      	movz	x6, #0x0, lsl #48
    4828:      	lsr	w5, w5, #0
    482c:      	lsr	x16, x5, #0
    4830:      	cmp	x16, #0x1
    4834:      	b.eq	0x4850 <_stogir.checked.validate+0x2b8>
    4838:      	b.lo	0x4840 <_stogir.checked.validate+0x2a8>
    483c:      	b	0x4854 <_stogir.checked.validate+0x2bc>
    4840:      	cmp	x16, #0x0
    4844:      	b.eq	0x484c <_stogir.checked.validate+0x2b4>
    4848:      	b	0x4854 <_stogir.checked.validate+0x2bc>
    484c:      	b	0x4858 <_stogir.checked.validate+0x2c0>
    4850:      	b	0x49e4 <_stogir.checked.validate+0x44c>
    4854:      	b	0x4a90 <_stogir.checked.validate+0x4f8>
    4858:      	mov	x3, x11
    485c:      	mov	x4, #0x22               ; =34
    4860:      	mov	x5, x7
    4864:      	cmp	x5, #0x2
    4868:      	b.ge	0x4894 <_stogir.checked.validate+0x2fc>
    486c:      	add	x6, x5, #0x1
    4870:      	lsl	x7, x5, #2
    4874:      	add	x5, x10, x5, lsl #2
    4878:      	ldr	w5, [x5]
    487c:      	sxtw	x5, w5
    4880:      	and	x5, x5, #0xffffffff
    4884:      	mov	x7, x6
    4888:      	mov	x6, x5
    488c:      	mov	x5, #0x1                ; =1
    4890:      	b	0x48a0 <_stogir.checked.validate+0x308>
    4894:      	mov	x7, x5
    4898:      	movz	x5, #0x0, lsl #48
    489c:      	movz	x6, #0x0, lsl #48
    48a0:      	lsr	w5, w5, #0
    48a4:      	lsr	x16, x5, #0
    48a8:      	cmp	x16, #0x1
    48ac:      	b.eq	0x48c8 <_stogir.checked.validate+0x330>
    48b0:      	b.lo	0x48b8 <_stogir.checked.validate+0x320>
    48b4:      	b	0x48cc <_stogir.checked.validate+0x334>
    48b8:      	cmp	x16, #0x0
    48bc:      	b.eq	0x48c4 <_stogir.checked.validate+0x32c>
    48c0:      	b	0x48cc <_stogir.checked.validate+0x334>
    48c4:      	b	0x4934 <_stogir.checked.validate+0x39c>
    48c8:      	b	0x48d0 <_stogir.checked.validate+0x338>
    48cc:      	b	0x4a88 <_stogir.checked.validate+0x4f0>
    48d0:      	lsr	w6, w6, #0
    48d4:      	sxtw	x6, w6
    48d8:      	cmp	x6, #0x0
    48dc:      	cset	w5, gt
    48e0:      	movz	x16, #0x0, lsl #48
    48e4:      	sub	x9, x16, x6
    48e8:      	sub	x19, x9, #0x1
    48ec:      	uxtb	w16, w5
    48f0:      	cmp	w16, wzr
    48f4:      	b.eq	0x49a0 <_stogir.checked.validate+0x408>
    48f8:      	ldr	x9, [x0, #0x8]
    48fc:      	cmp	x6, x9
    4900:      	b.ge	0x4998 <_stogir.checked.validate+0x400>
    4904:      	ldr	x9, [x13, #0x8]
    4908:      	cmp	x6, x9
    490c:      	b.ge	0x4a70 <_stogir.checked.validate+0x4d8>
    4910:      	lsl	x9, x6, #2
    4914:      	ldr	x9, [x0, #0x78]
    4918:      	add	x9, x9, x6, lsl #2
    491c:      	ldr	w9, [x9]
    4920:      	sxtw	x9, w9
    4924:      	cmp	x9, #0x0
    4928:      	cset	w9, ge
    492c:      	ubfx	x9, x9, #0, #8
    4930:      	b	0x4a74 <_stogir.checked.validate+0x4dc>
    4934:      	cmp	x4, #0x0
    4938:      	b.ne	0x4808 <_stogir.checked.validate+0x270>
    493c:      	and	x0, x1, #0xffffffff
    4940:      	mov	x1, x0
    4944:      	movz	x0, #0x0, lsl #48
    4948:      	movz	x3, #0x0, lsl #48
    494c:      	b	0x4814 <_stogir.checked.validate+0x27c>
    4950:      	lsl	x5, x19, #4
    4954:      	ldr	x5, [x0, #0x28]
    4958:      	add	x5, x5, x19, lsl #4
    495c:      	ldr	x5, [x5]
    4960:      	mov	x6, x5
    4964:      	mov	x5, #0x1                ; =1
    4968:      	b	0x4828 <_stogir.checked.validate+0x290>
    496c:      	movz	x9, #0x0, lsl #48
    4970:      	cmp	x9, #0x0
    4974:      	b.eq	0x4820 <_stogir.checked.validate+0x288>
    4978:      	uxtb	w16, w5
    497c:      	cmp	w16, wzr
    4980:      	b.eq	0x4950 <_stogir.checked.validate+0x3b8>
    4984:      	lsl	x5, x6, #4
    4988:      	ldr	x5, [x0]
    498c:      	add	x5, x5, x6, lsl #4
    4990:      	ldr	x5, [x5]
    4994:      	b	0x4960 <_stogir.checked.validate+0x3c8>
    4998:      	movz	x9, #0x0, lsl #48
    499c:      	b	0x4970 <_stogir.checked.validate+0x3d8>
    49a0:      	cmp	x6, #0x0
    49a4:      	b.ge	0x496c <_stogir.checked.validate+0x3d4>
    49a8:      	ldr	x20, [x14, #0x8]
    49ac:      	ldr	x21, [x15, #0x8]
    49b0:      	cmp	x20, x21
    49b4:      	b.ne	0x4a68 <_stogir.checked.validate+0x4d0>
    49b8:      	cmp	x9, x20
    49bc:      	b.gt	0x4a80 <_stogir.checked.validate+0x4e8>
    49c0:      	lsl	x9, x19, #2
    49c4:      	ldr	x9, [x0, #0x50]
    49c8:      	add	x9, x9, x19, lsl #2
    49cc:      	ldr	w9, [x9]
    49d0:      	sxtw	x9, w9
    49d4:      	cmp	x9, #0x0
    49d8:      	cset	w9, gt
    49dc:      	ubfx	x9, x9, #0, #8
    49e0:      	b	0x4a84 <_stogir.checked.validate+0x4ec>
    49e4:      	lsr	w6, w6, #0
    49e8:      	ubfx	x5, x6, #8, #8
    49ec:      	cmp	x5, x1
    49f0:      	b.eq	0x49fc <_stogir.checked.validate+0x464>
    49f4:      	mov	x3, x12
    49f8:      	mov	x4, #0x28               ; =40
    49fc:      	b	0x4860 <_stogir.checked.validate+0x2c8>
    4a00:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004a00:  ARM64_RELOC_PAGE21	l_stogir.363
    4a04:      	ldr	x16, [x16]
		0000000000004a04:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    4a08:      	orr	x7, x16, xzr
    4a0c:      	mov	x9, #0x36               ; =54
    4a10:      	orr	x10, x6, xzr
    4a14:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004a14:  ARM64_RELOC_PAGE21	l_stogir.364
    4a18:      	ldr	x16, [x16]
		0000000000004a18:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    4a1c:      	orr	x11, x16, xzr
    4a20:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004a20:  ARM64_RELOC_PAGE21	l_stogir.365
    4a24:      	ldr	x16, [x16]
		0000000000004a24:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    4a28:      	orr	x12, x16, xzr
    4a2c:      	add	x13, x0, #0x78
    4a30:      	add	x14, x0, #0x28
    4a34:      	add	x15, x0, #0x50
    4a38:      	lsr	w5, w5, #0
    4a3c:      	lsr	x4, x4, #32
    4a40:      	lsr	w5, w5, #0
    4a44:      	lsr	w4, w4, #0
    4a48:      	str	w4, [x3]
    4a4c:      	str	w5, [x3, #0x4]
    4a50:      	ldr	x3, [x3]
    4a54:      	str	x3, [x6]
    4a58:      	mov	x3, x7
    4a5c:      	mov	x4, x9
    4a60:      	movz	x5, #0x0, lsl #48
    4a64:      	b	0x4864 <_stogir.checked.validate+0x2cc>
    4a68:      	movz	x9, #0x0, lsl #48
    4a6c:      	b	0x4970 <_stogir.checked.validate+0x3d8>
    4a70:      	movz	x9, #0x0, lsl #48
    4a74:      	b	0x499c <_stogir.checked.validate+0x404>
    4a78:      	brk	#0
    4a7c:      	b	0x4a78 <_stogir.checked.validate+0x4e0>
    4a80:      	movz	x9, #0x0, lsl #48
    4a84:      	b	0x4a6c <_stogir.checked.validate+0x4d4>
    4a88:      	brk	#0
    4a8c:      	b	0x4a88 <_stogir.checked.validate+0x4f0>
    4a90:      	brk	#0
    4a94:      	b	0x4a90 <_stogir.checked.validate+0x4f8>

0000000000004a98 <_stogir.atomic.operation?>:
    4a98:      	sxtw	x0, w0
    4a9c:      	cmp	x0, #0x7e
    4aa0:      	b.lt	0x4ab4 <_stogir.atomic.operation?+0x1c>
    4aa4:      	cmp	x0, #0x82
    4aa8:      	cset	w0, le
    4aac:      	ubfx	x0, x0, #0, #8
    4ab0:      	b	0x4ab8 <_stogir.atomic.operation?+0x20>
    4ab4:      	movz	x0, #0x0, lsl #48
    4ab8:      	ret

0000000000004abc <_stogir.atomic.validate>:
    4abc:      	sub	sp, sp, #0xf0
    4ac0:      	str	x29, [sp, #0x10]
    4ac4:      	str	x30, [sp, #0x18]
    4ac8:      	add	x29, sp, #0x10
    4acc:      	str	x19, [sp, #0xa0]
    4ad0:      	str	x20, [sp, #0xa8]
    4ad4:      	str	x21, [sp, #0xb0]
    4ad8:      	str	x22, [sp, #0xb8]
    4adc:      	str	x23, [sp, #0xc0]
    4ae0:      	str	x24, [sp, #0xc8]
    4ae4:      	str	x25, [sp, #0xd0]
    4ae8:      	str	x26, [sp, #0xd8]
    4aec:      	str	x27, [sp, #0xe0]
    4af0:      	sxtw	x2, w1
    4af4:      	lsl	x3, x2, #2
    4af8:      	cmp	x2, #0x0
    4afc:      	cset	w4, gt
    4b00:      	movz	x16, #0x0, lsl #48
    4b04:      	sub	x5, x16, x2
    4b08:      	sub	x6, x5, #0x1
    4b0c:      	uxtb	w16, w4
    4b10:      	cmp	w16, wzr
    4b14:      	b.eq	0x4b54 <_stogir.atomic.validate+0x98>
    4b18:      	ldr	x5, [x0, #0x8]
    4b1c:      	cmp	x2, x5
    4b20:      	b.ge	0x4ba8 <_stogir.atomic.validate+0xec>
    4b24:      	add	x5, x0, #0x78
    4b28:      	ldr	x5, [x5, #0x8]
    4b2c:      	cmp	x2, x5
    4b30:      	b.ge	0x4d10 <_stogir.atomic.validate+0x254>
    4b34:      	ldr	x5, [x0, #0x78]
    4b38:      	add	x5, x3, x5
    4b3c:      	ldr	w5, [x5]
    4b40:      	sxtw	x5, w5
    4b44:      	cmp	x5, #0x0
    4b48:      	cset	w5, ge
    4b4c:      	ubfx	x5, x5, #0, #8
    4b50:      	b	0x4d14 <_stogir.atomic.validate+0x258>
    4b54:      	cmp	x2, #0x0
    4b58:      	b.ge	0x4bb0 <_stogir.atomic.validate+0xf4>
    4b5c:      	add	x7, x0, #0x28
    4b60:      	add	x9, x0, #0x50
    4b64:      	ldr	x7, [x7, #0x8]
    4b68:      	ldr	x9, [x9, #0x8]
    4b6c:      	cmp	x7, x9
    4b70:      	b.ne	0x4ba0 <_stogir.atomic.validate+0xe4>
    4b74:      	cmp	x5, x7
    4b78:      	b.gt	0x4da8 <_stogir.atomic.validate+0x2ec>
    4b7c:      	lsl	x5, x6, #2
    4b80:      	ldr	x5, [x0, #0x50]
    4b84:      	add	x5, x5, x6, lsl #2
    4b88:      	ldr	w5, [x5]
    4b8c:      	sxtw	x5, w5
    4b90:      	cmp	x5, #0x0
    4b94:      	cset	w5, gt
    4b98:      	ubfx	x5, x5, #0, #8
    4b9c:      	b	0x4dac <_stogir.atomic.validate+0x2f0>
    4ba0:      	movz	x5, #0x0, lsl #48
    4ba4:      	b	0x4bb4 <_stogir.atomic.validate+0xf8>
    4ba8:      	movz	x5, #0x0, lsl #48
    4bac:      	b	0x4bb4 <_stogir.atomic.validate+0xf8>
    4bb0:      	movz	x5, #0x0, lsl #48
    4bb4:      	cmp	x5, #0x0
    4bb8:      	b.eq	0x4c18 <_stogir.atomic.validate+0x15c>
    4bbc:      	uxtb	w16, w4
    4bc0:      	cmp	w16, wzr
    4bc4:      	b.eq	0x4bec <_stogir.atomic.validate+0x130>
    4bc8:      	lsl	x4, x2, #4
    4bcc:      	ldr	x4, [x0]
    4bd0:      	add	x4, x4, x2, lsl #4
    4bd4:      	ldr	x5, [x4]
    4bd8:      	ldr	x4, [x4, #0x8]
    4bdc:      	fmov	d31, x4
    4be0:      	mov	x4, x5
    4be4:      	fmov	x5, d31
    4be8:      	b	0x4c0c <_stogir.atomic.validate+0x150>
    4bec:      	lsl	x4, x6, #4
    4bf0:      	ldr	x4, [x0, #0x28]
    4bf4:      	add	x4, x4, x6, lsl #4
    4bf8:      	ldr	x5, [x4]
    4bfc:      	ldr	x4, [x4, #0x8]
    4c00:      	fmov	d31, x4
    4c04:      	mov	x4, x5
    4c08:      	fmov	x5, d31
    4c0c:      	mov	x19, x4
    4c10:      	mov	x4, #0x1                ; =1
    4c14:      	b	0x4c24 <_stogir.atomic.validate+0x168>
    4c18:      	movz	x4, #0x0, lsl #48
    4c1c:      	movz	x19, #0x0, lsl #48
    4c20:      	movz	x5, #0x0, lsl #48
    4c24:      	lsr	w4, w4, #0
    4c28:      	lsr	x16, x4, #0
    4c2c:      	cmp	x16, #0x1
    4c30:      	b.eq	0x4c4c <_stogir.atomic.validate+0x190>
    4c34:      	b.lo	0x4c3c <_stogir.atomic.validate+0x180>
    4c38:      	b	0x4c50 <_stogir.atomic.validate+0x194>
    4c3c:      	cmp	x16, #0x0
    4c40:      	b.eq	0x4c48 <_stogir.atomic.validate+0x18c>
    4c44:      	b	0x4c50 <_stogir.atomic.validate+0x194>
    4c48:      	b	0x4c54 <_stogir.atomic.validate+0x198>
    4c4c:      	b	0x4cb0 <_stogir.atomic.validate+0x1f4>
    4c50:      	b	0x5358 <_stogir.atomic.validate+0x89c>
    4c54:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004c54:  ARM64_RELOC_PAGE21	l_stogir.366
    4c58:      	ldr	x16, [x16]
		0000000000004c58:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    4c5c:      	orr	x0, x16, xzr
    4c60:      	mov	x23, x8
    4c64:      	mov	x1, x0
    4c68:      	mov	x0, #0x1                ; =1
    4c6c:      	mov	x2, #0x1a               ; =26
    4c70:      	str	x0, [x23]
    4c74:      	str	x1, [x23, #0x8]
    4c78:      	str	x2, [x23, #0x10]
    4c7c:      	ldr	x19, [sp, #0xa0]
    4c80:      	ldr	x20, [sp, #0xa8]
    4c84:      	ldr	x21, [sp, #0xb0]
    4c88:      	ldr	x22, [sp, #0xb8]
    4c8c:      	ldr	x23, [sp, #0xc0]
    4c90:      	ldr	x24, [sp, #0xc8]
    4c94:      	ldr	x25, [sp, #0xd0]
    4c98:      	ldr	x26, [sp, #0xd8]
    4c9c:      	ldr	x27, [sp, #0xe0]
    4ca0:      	ldr	x29, [sp, #0x10]
    4ca4:      	ldr	x30, [sp, #0x18]
    4ca8:      	add	sp, sp, #0xf0
    4cac:      	ret
    4cb0:      	uxtb	w4, w19
    4cb4:      	add	x16, sp, #0x20
    4cb8:      	str	x19, [x16]
    4cbc:      	orr	x20, x4, xzr
    4cc0:      	add	x16, sp, #0x20
    4cc4:      	str	x5, [x16, #0x8]
    4cc8:      	cmp	x2, #0x0
    4ccc:      	b.le	0x4d28 <_stogir.atomic.validate+0x26c>
    4cd0:      	cmp	x20, #0x7e
    4cd4:      	b.lt	0x4d28 <_stogir.atomic.validate+0x26c>
    4cd8:      	cmp	x20, #0x82
    4cdc:      	b.gt	0x4d28 <_stogir.atomic.validate+0x26c>
    4ce0:      	ldr	x2, [x0, #0x78]
    4ce4:      	add	x2, x3, x2
    4ce8:      	ldr	w2, [x2]
    4cec:      	cmp	x20, #0x83
    4cf0:      	b.ge	0x5278 <_stogir.atomic.validate+0x7bc>
    4cf4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004cf4:  ARM64_RELOC_PAGE21	l_stogir.367
    4cf8:      	ldr	x16, [x16]
		0000000000004cf8:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    4cfc:      	orr	x3, x16, xzr
    4d00:      	add	x3, x20, x3
    4d04:      	ldrsb	w3, [x3]
    4d08:      	sxtb	x3, w3
    4d0c:      	b	0x527c <_stogir.atomic.validate+0x7c0>
    4d10:      	movz	x5, #0x0, lsl #48
    4d14:      	b	0x4bac <_stogir.atomic.validate+0xf0>
    4d18:      	mov	x2, x1
    4d1c:      	mov	x1, x0
    4d20:      	mov	x0, #0x1                ; =1
    4d24:      	b	0x4c70 <_stogir.atomic.validate+0x1b4>
    4d28:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004d28:  ARM64_RELOC_PAGE21	l_stogir.368
    4d2c:      	ldr	x16, [x16]
		0000000000004d2c:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    4d30:      	orr	x2, x16, xzr
    4d34:      	mov	x21, x2
    4d38:      	mov	x22, #0x20              ; =32
    4d3c:      	add	x16, sp, #0x20
    4d40:      	ldr	w2, [x16, #0x4]
    4d44:      	lsr	w2, w2, #0
    4d48:      	mov	x23, x8
    4d4c:      	add	x8, sp, #0x30
    4d50:      	mov	x24, x0
    4d54:      	mov	w25, w1
    4d58:      	mov	w1, w2
    4d5c:      	bl	0x4d5c <_stogir.atomic.validate+0x2a0>
		0000000000004d5c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4d60:      	add	x16, sp, #0x30
    4d64:      	ldr	w0, [x16]
    4d68:      	lsr	x16, x0, #0
    4d6c:      	cmp	x16, #0x1
    4d70:      	b.eq	0x4d8c <_stogir.atomic.validate+0x2d0>
    4d74:      	b.lo	0x4d7c <_stogir.atomic.validate+0x2c0>
    4d78:      	b	0x4d90 <_stogir.atomic.validate+0x2d4>
    4d7c:      	cmp	x16, #0x0
    4d80:      	b.eq	0x4d88 <_stogir.atomic.validate+0x2cc>
    4d84:      	b	0x4d90 <_stogir.atomic.validate+0x2d4>
    4d88:      	b	0x4d94 <_stogir.atomic.validate+0x2d8>
    4d8c:      	b	0x4e8c <_stogir.atomic.validate+0x3d0>
    4d90:      	b	0x538c <_stogir.atomic.validate+0x8d0>
    4d94:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004d94:  ARM64_RELOC_PAGE21	l_stogir.369
    4d98:      	ldr	x16, [x16]
		0000000000004d98:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    4d9c:      	orr	x0, x16, xzr
    4da0:      	mov	x1, #0x16               ; =22
    4da4:      	b	0x4db8 <_stogir.atomic.validate+0x2fc>
    4da8:      	movz	x5, #0x0, lsl #48
    4dac:      	b	0x4ba4 <_stogir.atomic.validate+0xe8>
    4db0:      	mov	x0, x1
    4db4:      	mov	x1, x22
    4db8:      	cmp	x20, #0x82
    4dbc:      	cset	w21, eq
    4dc0:      	lsr	w19, w19, #0
    4dc4:      	ubfx	x2, x19, #8, #8
    4dc8:      	orr	x19, x2, xzr
    4dcc:      	cmp	x19, #0x0
    4dd0:      	cset	w22, eq
    4dd4:      	uxtb	w16, w21
    4dd8:      	cmp	w16, wzr
    4ddc:      	b.eq	0x4e04 <_stogir.atomic.validate+0x348>
    4de0:      	uxtb	w16, w22
    4de4:      	cmp	w16, wzr
    4de8:      	b.ne	0x4dfc <_stogir.atomic.validate+0x340>
    4dec:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004dec:  ARM64_RELOC_PAGE21	l_stogir.370
    4df0:      	ldr	x16, [x16]
		0000000000004df0:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    4df4:      	orr	x0, x16, xzr
    4df8:      	mov	x1, #0x19               ; =25
    4dfc:      	mov	x26, x1
    4e00:      	b	0x4e08 <_stogir.atomic.validate+0x34c>
    4e04:      	mov	x26, x1
    4e08:      	uxtb	w16, w21
    4e0c:      	cmp	w16, wzr
    4e10:      	b.eq	0x4e20 <_stogir.atomic.validate+0x364>
    4e14:      	mov	x27, x0
    4e18:      	movz	x0, #0x0, lsl #48
    4e1c:      	b	0x4e28 <_stogir.atomic.validate+0x36c>
    4e20:      	mov	x27, x0
    4e24:      	mov	x0, #0x1                ; =1
    4e28:      	cmp	x0, #0x0
    4e2c:      	b.eq	0x4e60 <_stogir.atomic.validate+0x3a4>
    4e30:      	add	x16, sp, #0x20
    4e34:      	ldr	w0, [x16, #0x8]
    4e38:      	lsr	w0, w0, #0
    4e3c:      	mov	w1, w0
    4e40:      	mov	x0, x24
    4e44:      	mov	x2, #0x6                ; =6
    4e48:      	bl	0x4e48 <_stogir.atomic.validate+0x38c>
		0000000000004e48:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4e4c:      	cmp	x0, #0x0
    4e50:      	b.eq	0x4fc4 <_stogir.atomic.validate+0x508>
    4e54:      	mov	x1, x27
    4e58:      	movz	x0, #0x0, lsl #48
    4e5c:      	b	0x4fcc <_stogir.atomic.validate+0x510>
    4e60:      	mov	x0, x19
    4e64:      	mov	x1, x27
    4e68:      	mov	x19, x26
    4e6c:      	cmp	x20, #0x80
    4e70:      	cset	w22, eq
    4e74:      	uxtb	w16, w22
    4e78:      	cmp	w16, wzr
    4e7c:      	b.eq	0x4eb4 <_stogir.atomic.validate+0x3f8>
    4e80:      	mov	x20, x1
    4e84:      	mov	x1, #0x1                ; =1
    4e88:      	b	0x4ec8 <_stogir.atomic.validate+0x40c>
    4e8c:      	add	x16, sp, #0x30
    4e90:      	ldr	x0, [x16, #0x8]
    4e94:      	add	x16, sp, #0x20
    4e98:      	ldr	w1, [x16, #0x4]
    4e9c:      	sxtw	x1, w1
    4ea0:      	cmp	x1, #0x0
    4ea4:      	b.gt	0x5034 <_stogir.atomic.validate+0x578>
    4ea8:      	mov	x1, x21
    4eac:      	mov	x0, #0x1                ; =1
    4eb0:      	b	0x5018 <_stogir.atomic.validate+0x55c>
    4eb4:      	cmp	x20, #0x81
    4eb8:      	cset	w2, eq
    4ebc:      	ubfx	x2, x2, #0, #8
    4ec0:      	mov	x20, x1
    4ec4:      	mov	x1, x2
    4ec8:      	lsr	w26, w0, #0
    4ecc:      	cmp	x1, #0x0
    4ed0:      	b.eq	0x4f50 <_stogir.atomic.validate+0x494>
    4ed4:      	lsr	w25, w25, #0
    4ed8:      	add	x16, sp, #0x90
    4edc:      	str	x16, [sp]
    4ee0:      	mov	x0, x24
    4ee4:      	mov	w1, w25
    4ee8:      	mov	x2, #0x4                ; =4
    4eec:      	bl	0x4eec <_stogir.atomic.validate+0x430>
		0000000000004eec:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    4ef0:      	ldr	x16, [sp]
    4ef4:      	str	x0, [x16]
    4ef8:      	str	x1, [x16, #0x8]
    4efc:      	add	x16, sp, #0x90
    4f00:      	ldr	x0, [x16]
    4f04:      	add	x16, sp, #0x90
    4f08:      	ldr	x1, [x16, #0x8]
    4f0c:      	lsr	w0, w0, #0
    4f10:      	lsr	x16, x0, #0
    4f14:      	cmp	x16, #0x1
    4f18:      	b.eq	0x4f34 <_stogir.atomic.validate+0x478>
    4f1c:      	b.lo	0x4f24 <_stogir.atomic.validate+0x468>
    4f20:      	b	0x4f38 <_stogir.atomic.validate+0x47c>
    4f24:      	cmp	x16, #0x0
    4f28:      	b.eq	0x4f30 <_stogir.atomic.validate+0x474>
    4f2c:      	b	0x4f38 <_stogir.atomic.validate+0x47c>
    4f30:      	b	0x4f3c <_stogir.atomic.validate+0x480>
    4f34:      	b	0x516c <_stogir.atomic.validate+0x6b0>
    4f38:      	b	0x539c <_stogir.atomic.validate+0x8e0>
    4f3c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004f3c:  ARM64_RELOC_PAGE21	l_stogir.371
    4f40:      	ldr	x16, [x16]
		0000000000004f40:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    4f44:      	orr	x0, x16, xzr
    4f48:      	mov	x1, #0x1d               ; =29
    4f4c:      	b	0x4fc0 <_stogir.atomic.validate+0x504>
    4f50:      	mov	x0, x20
    4f54:      	mov	x1, x19
    4f58:      	cmp	x1, #0x0
    4f5c:      	b.ne	0x4d18 <_stogir.atomic.validate+0x25c>
    4f60:      	uxtb	w16, w21
    4f64:      	cmp	w16, wzr
    4f68:      	b.eq	0x5158 <_stogir.atomic.validate+0x69c>
    4f6c:      	movz	x0, #0x0, lsl #48
    4f70:      	b	0x4f9c <_stogir.atomic.validate+0x4e0>
    4f74:      	mov	x0, x1
    4f78:      	mov	x1, x22
    4f7c:      	fmov	d31, x0
    4f80:      	mov	x0, x19
    4f84:      	mov	x19, x1
    4f88:      	fmov	x1, d31
    4f8c:      	b	0x4e6c <_stogir.atomic.validate+0x3b0>
    4f90:      	mov	x0, #0x1                ; =1
    4f94:      	lsr	w0, w0, #0
    4f98:      	sxtw	x0, w0
    4f9c:      	and	x0, x0, #0xffffffff
    4fa0:      	mov	x1, x0
    4fa4:      	movz	x0, #0x0, lsl #48
    4fa8:      	movz	x2, #0x0, lsl #48
    4fac:      	b	0x4d24 <_stogir.atomic.validate+0x268>
    4fb0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004fb0:  ARM64_RELOC_PAGE21	l_stogir.372
    4fb4:      	ldr	x16, [x16]
		0000000000004fb4:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    4fb8:      	orr	x0, x16, xzr
    4fbc:      	mov	x1, #0x24               ; =36
    4fc0:      	b	0x4f58 <_stogir.atomic.validate+0x49c>
    4fc4:      	mov	x1, x27
    4fc8:      	mov	x0, #0x1                ; =1
    4fcc:      	cmp	x0, #0x0
    4fd0:      	b.eq	0x4fe8 <_stogir.atomic.validate+0x52c>
    4fd4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x2e4>
		0000000000004fd4:  ARM64_RELOC_PAGE21	l_stogir.373
    4fd8:      	ldr	x16, [x16]
		0000000000004fd8:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    4fdc:      	orr	x0, x16, xzr
    4fe0:      	mov	x1, #0x1b               ; =27
    4fe4:      	b	0x4ff0 <_stogir.atomic.validate+0x534>
    4fe8:      	mov	x0, x1
    4fec:      	mov	x1, x26
    4ff0:      	cmp	x20, #0x7f
    4ff4:      	b.ne	0x5088 <_stogir.atomic.validate+0x5cc>
    4ff8:      	uxtb	w16, w22
    4ffc:      	cmp	w16, wzr
    5000:      	b.eq	0x5194 <_stogir.atomic.validate+0x6d8>
    5004:      	mov	x22, x0
    5008:      	mov	x26, x1
    500c:      	b	0x51a8 <_stogir.atomic.validate+0x6ec>
    5010:      	mov	x0, #0x1                ; =1
    5014:      	mov	x1, x21
    5018:      	cmp	x0, #0x0
    501c:      	b.eq	0x4db0 <_stogir.atomic.validate+0x2f4>
    5020:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005020:  ARM64_RELOC_PAGE21	l_stogir.374
    5024:      	ldr	x16, [x16]
		0000000000005024:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    5028:      	orr	x0, x16, xzr
    502c:      	mov	x1, #0x16               ; =22
    5030:      	b	0x4db8 <_stogir.atomic.validate+0x2fc>
    5034:      	uxtb	w0, w0
    5038:      	cmp	x0, #0x83
    503c:      	cset	w1, lt
    5040:      	uxtb	w16, w1
    5044:      	cmp	w16, wzr
    5048:      	b.eq	0x523c <_stogir.atomic.validate+0x780>
    504c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		000000000000504c:  ARM64_RELOC_PAGE21	l_stogir.375
    5050:      	ldr	x16, [x16]
		0000000000005050:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    5054:      	orr	x2, x16, xzr
    5058:      	add	x2, x0, x2
    505c:      	ldrb	w2, [x2]
    5060:      	b	0x5240 <_stogir.atomic.validate+0x784>
    5064:      	add	x16, sp, #0x60
    5068:      	ldr	x0, [x16, #0x8]
    506c:      	lsr	w0, w0, #0
    5070:      	ubfx	x0, x0, #8, #8
    5074:      	mov	x1, x22
    5078:      	mov	x2, x26
    507c:      	mov	x19, x0
    5080:      	mov	x0, x1
    5084:      	mov	x1, x2
    5088:      	cmp	x19, #0x2
    508c:      	b.ge	0x5124 <_stogir.atomic.validate+0x668>
    5090:      	mov	x2, x1
    5094:      	mov	x1, #0x1                ; =1
    5098:      	b	0x513c <_stogir.atomic.validate+0x680>
    509c:      	mov	x1, x26
    50a0:      	movz	x0, #0x0, lsl #48
    50a4:      	cmp	x0, #0x0
    50a8:      	b.eq	0x4f74 <_stogir.atomic.validate+0x4b8>
    50ac:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		00000000000050ac:  ARM64_RELOC_PAGE21	l_stogir.376
    50b0:      	ldr	x16, [x16]
		00000000000050b0:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    50b4:      	orr	x0, x16, xzr
    50b8:      	mov	x1, #0x22               ; =34
    50bc:      	b	0x4f7c <_stogir.atomic.validate+0x4c0>
    50c0:      	mov	x1, x26
    50c4:      	mov	x0, #0x1                ; =1
    50c8:      	b	0x50a4 <_stogir.atomic.validate+0x5e8>
    50cc:      	mov	x26, x0
    50d0:      	mov	x0, #0x1                ; =1
    50d4:      	cmp	x0, #0x0
    50d8:      	b.eq	0x509c <_stogir.atomic.validate+0x5e0>
    50dc:      	lsr	w0, w19, #0
    50e0:      	add	x16, sp, #0x20
    50e4:      	ldr	w1, [x16, #0xc]
    50e8:      	lsr	w1, w1, #0
    50ec:      	mov	w2, w0
    50f0:      	mov	x0, x24
    50f4:      	bl	0x50f4 <_stogir.atomic.validate+0x638>
		00000000000050f4:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    50f8:      	cmp	x0, #0x0
    50fc:      	b.eq	0x50c0 <_stogir.atomic.validate+0x604>
    5100:      	mov	x1, x26
    5104:      	movz	x0, #0x0, lsl #48
    5108:      	b	0x50c8 <_stogir.atomic.validate+0x60c>
    510c:      	mov	x22, x2
    5110:      	cmp	x20, #0x7e
    5114:      	b.ne	0x50cc <_stogir.atomic.validate+0x610>
    5118:      	mov	x26, x0
    511c:      	movz	x0, #0x0, lsl #48
    5120:      	b	0x50d4 <_stogir.atomic.validate+0x618>
    5124:      	cmp	x19, #0x5
    5128:      	cset	w2, gt
    512c:      	ubfx	x2, x2, #0, #8
    5130:      	fmov	d31, x1
    5134:      	mov	x1, x2
    5138:      	fmov	x2, d31
    513c:      	cmp	x1, #0x0
    5140:      	b.eq	0x510c <_stogir.atomic.validate+0x650>
    5144:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005144:  ARM64_RELOC_PAGE21	l_stogir.377
    5148:      	ldr	x16, [x16]
		0000000000005148:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    514c:      	orr	x0, x16, xzr
    5150:      	mov	x22, #0x25              ; =37
    5154:      	b	0x5110 <_stogir.atomic.validate+0x654>
    5158:      	sxtw	x26, w26
    515c:      	cmp	x26, #0x0
    5160:      	b.ne	0x52a8 <_stogir.atomic.validate+0x7ec>
    5164:      	movz	x0, #0x0, lsl #48
    5168:      	b	0x4f94 <_stogir.atomic.validate+0x4d8>
    516c:      	lsr	w1, w1, #0
    5170:      	uxtb	w16, w22
    5174:      	cmp	w16, wzr
    5178:      	b.eq	0x5334 <_stogir.atomic.validate+0x878>
    517c:      	sxtw	x1, w1
    5180:      	cmp	x1, #0x0
    5184:      	b.ge	0x5360 <_stogir.atomic.validate+0x8a4>
    5188:      	mov	x1, x20
    518c:      	mov	x0, #0x1                ; =1
    5190:      	b	0x5370 <_stogir.atomic.validate+0x8b4>
    5194:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005194:  ARM64_RELOC_PAGE21	l_stogir.378
    5198:      	ldr	x16, [x16]
		0000000000005198:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    519c:      	orr	x0, x16, xzr
    51a0:      	mov	x22, x0
    51a4:      	mov	x26, #0x19              ; =25
    51a8:      	add	x16, sp, #0x20
    51ac:      	ldr	w0, [x16, #0xc]
    51b0:      	lsr	w0, w0, #0
    51b4:      	add	x8, sp, #0x60
    51b8:      	mov	w1, w0
    51bc:      	mov	x0, x24
    51c0:      	bl	0x51c0 <_stogir.atomic.validate+0x704>
		00000000000051c0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    51c4:      	add	x16, sp, #0x60
    51c8:      	ldr	w0, [x16]
    51cc:      	lsr	x16, x0, #0
    51d0:      	cmp	x16, #0x1
    51d4:      	b.eq	0x51f0 <_stogir.atomic.validate+0x734>
    51d8:      	b.lo	0x51e0 <_stogir.atomic.validate+0x724>
    51dc:      	b	0x51f4 <_stogir.atomic.validate+0x738>
    51e0:      	cmp	x16, #0x0
    51e4:      	b.eq	0x51ec <_stogir.atomic.validate+0x730>
    51e8:      	b	0x51f4 <_stogir.atomic.validate+0x738>
    51ec:      	b	0x51f8 <_stogir.atomic.validate+0x73c>
    51f0:      	b	0x5064 <_stogir.atomic.validate+0x5a8>
    51f4:      	b	0x53a4 <_stogir.atomic.validate+0x8e8>
    51f8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		00000000000051f8:  ARM64_RELOC_PAGE21	l_stogir.379
    51fc:      	ldr	x16, [x16]
		00000000000051fc:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    5200:      	orr	x0, x16, xzr
    5204:      	mov	x1, x0
    5208:      	mov	x0, x19
    520c:      	mov	x2, #0x1a               ; =26
    5210:      	b	0x507c <_stogir.atomic.validate+0x5c0>
    5214:      	movz	x0, #0x0, lsl #48
    5218:      	uxtb	w0, w0
    521c:      	and	x0, x0, #0x4
    5220:      	uxtb	w0, w0
    5224:      	cmp	x0, #0x0
    5228:      	cset	w0, eq
    522c:      	uxtb	w16, w0
    5230:      	cmp	w16, wzr
    5234:      	cset	x0, eq
    5238:      	b	0x5014 <_stogir.atomic.validate+0x558>
    523c:      	movz	x2, #0x0, lsl #48
    5240:      	uxtb	w2, w2
    5244:      	and	x2, x2, #0x1
    5248:      	uxtb	w2, w2
    524c:      	cmp	x2, #0x0
    5250:      	b.eq	0x5010 <_stogir.atomic.validate+0x554>
    5254:      	uxtb	w16, w1
    5258:      	cmp	w16, wzr
    525c:      	b.eq	0x5214 <_stogir.atomic.validate+0x758>
    5260:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005260:  ARM64_RELOC_PAGE21	l_stogir.375
    5264:      	ldr	x16, [x16]
		0000000000005264:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    5268:      	orr	x1, x16, xzr
    526c:      	add	x0, x0, x1
    5270:      	ldrb	w0, [x0]
    5274:      	b	0x5218 <_stogir.atomic.validate+0x75c>
    5278:      	mov	x3, #-0x2               ; =-2
    527c:      	sxtw	x2, w2
    5280:      	lsr	w3, w3, #0
    5284:      	sxtw	x3, w3
    5288:      	cmp	x2, x3
    528c:      	b.ne	0x4d28 <_stogir.atomic.validate+0x26c>
    5290:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005290:  ARM64_RELOC_PAGE21	l_stogir.380
    5294:      	ldr	x16, [x16]
		0000000000005294:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    5298:      	orr	x2, x16, xzr
    529c:      	mov	x21, x2
    52a0:      	movz	x22, #0x0, lsl #48
    52a4:      	b	0x4d3c <_stogir.atomic.validate+0x280>
    52a8:      	cmp	x26, #0x1
    52ac:      	b.eq	0x4f90 <_stogir.atomic.validate+0x4d4>
    52b0:      	cmp	x26, #0x2
    52b4:      	b.eq	0x4f90 <_stogir.atomic.validate+0x4d4>
    52b8:      	cmp	x26, #0x7
    52bc:      	b.eq	0x4f90 <_stogir.atomic.validate+0x4d4>
    52c0:      	cmp	x26, #0x8
    52c4:      	b.eq	0x4f90 <_stogir.atomic.validate+0x4d4>
    52c8:      	cmp	x26, #0x3
    52cc:      	b.eq	0x5394 <_stogir.atomic.validate+0x8d8>
    52d0:      	cmp	x26, #0x9
    52d4:      	b.eq	0x5394 <_stogir.atomic.validate+0x8d8>
    52d8:      	cmp	x26, #0x4
    52dc:      	b.eq	0x53ac <_stogir.atomic.validate+0x8f0>
    52e0:      	cmp	x26, #0xa
    52e4:      	b.eq	0x53ac <_stogir.atomic.validate+0x8f0>
    52e8:      	cmp	x26, #0xd
    52ec:      	b.eq	0x53ac <_stogir.atomic.validate+0x8f0>
    52f0:      	cmp	x26, #0x5
    52f4:      	b.eq	0x53b4 <_stogir.atomic.validate+0x8f8>
    52f8:      	cmp	x26, #0xb
    52fc:      	b.eq	0x53b4 <_stogir.atomic.validate+0x8f8>
    5300:      	cmp	x26, #0xc
    5304:      	b.eq	0x53b4 <_stogir.atomic.validate+0x8f8>
    5308:      	cmp	x26, #0x6
    530c:      	cset	w0, eq
    5310:      	uxtb	w16, w0
    5314:      	cmp	w16, wzr
    5318:      	mov	x16, #0x8               ; =8
    531c:      	movn	x17, #0x0, lsl #48
    5320:      	csel	x0, x16, x17, ne
    5324:      	b	0x53b8 <_stogir.atomic.validate+0x8fc>
    5328:      	mov	x0, x1
    532c:      	mov	x1, x19
    5330:      	b	0x4fc0 <_stogir.atomic.validate+0x504>
    5334:      	lsr	w1, w1, #0
    5338:      	mov	x0, x24
    533c:      	mov	w2, w26
    5340:      	bl	0x5340 <_stogir.atomic.validate+0x884>
		0000000000005340:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5344:      	cmp	x0, #0x0
    5348:      	b.eq	0x4fb0 <_stogir.atomic.validate+0x4f4>
    534c:      	mov	x0, x20
    5350:      	mov	x1, x19
    5354:      	b	0x4fc0 <_stogir.atomic.validate+0x504>
    5358:      	brk	#0
    535c:      	b	0x5358 <_stogir.atomic.validate+0x89c>
    5360:      	cmp	x1, #0x9
    5364:      	cset	w0, gt
    5368:      	ubfx	x0, x0, #0, #8
    536c:      	mov	x1, x20
    5370:      	cmp	x0, #0x0
    5374:      	b.eq	0x5328 <_stogir.atomic.validate+0x86c>
    5378:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005378:  ARM64_RELOC_PAGE21	l_stogir.381
    537c:      	ldr	x16, [x16]
		000000000000537c:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    5380:      	orr	x0, x16, xzr
    5384:      	mov	x1, #0x1c               ; =28
    5388:      	b	0x5330 <_stogir.atomic.validate+0x874>
    538c:      	brk	#0
    5390:      	b	0x538c <_stogir.atomic.validate+0x8d0>
    5394:      	mov	x0, #0x2                ; =2
    5398:      	b	0x4f94 <_stogir.atomic.validate+0x4d8>
    539c:      	brk	#0
    53a0:      	b	0x539c <_stogir.atomic.validate+0x8e0>
    53a4:      	brk	#0
    53a8:      	b	0x53a4 <_stogir.atomic.validate+0x8e8>
    53ac:      	mov	x0, #0x4                ; =4
    53b0:      	b	0x5398 <_stogir.atomic.validate+0x8dc>
    53b4:      	mov	x0, #0x8                ; =8
    53b8:      	b	0x53b0 <_stogir.atomic.validate+0x8f4>

00000000000053bc <_stogir.terminal.operation?>:
    53bc:      	sxtw	x0, w0
    53c0:      	cmp	x0, #0x60
    53c4:      	b.ne	0x53d0 <_stogir.terminal.operation?+0x14>
    53c8:      	mov	x0, #0x1                ; =1
    53cc:      	b	0x53dc <_stogir.terminal.operation?+0x20>
    53d0:      	cmp	x0, #0x79
    53d4:      	cset	w0, eq
    53d8:      	ubfx	x0, x0, #0, #8
    53dc:      	ret

00000000000053e0 <_stogir.terminal.validate>:
    53e0:      	sub	sp, sp, #0x50
    53e4:      	str	x29, [sp]
    53e8:      	str	x30, [sp, #0x8]
    53ec:      	mov	x29, sp
    53f0:      	str	x19, [sp, #0x40]
    53f4:      	sxtw	x1, w1
    53f8:      	lsl	x2, x1, #2
    53fc:      	cmp	x1, #0x0
    5400:      	cset	w3, gt
    5404:      	movz	x16, #0x0, lsl #48
    5408:      	sub	x4, x16, x1
    540c:      	sub	x5, x4, #0x1
    5410:      	uxtb	w16, w3
    5414:      	cmp	w16, wzr
    5418:      	b.eq	0x5458 <_stogir.terminal.validate+0x78>
    541c:      	ldr	x4, [x0, #0x8]
    5420:      	cmp	x1, x4
    5424:      	b.ge	0x54ac <_stogir.terminal.validate+0xcc>
    5428:      	add	x4, x0, #0x78
    542c:      	ldr	x4, [x4, #0x8]
    5430:      	cmp	x1, x4
    5434:      	b.ge	0x55d0 <_stogir.terminal.validate+0x1f0>
    5438:      	ldr	x4, [x0, #0x78]
    543c:      	add	x4, x2, x4
    5440:      	ldr	w4, [x4]
    5444:      	sxtw	x4, w4
    5448:      	cmp	x4, #0x0
    544c:      	cset	w4, ge
    5450:      	ubfx	x4, x4, #0, #8
    5454:      	b	0x55d4 <_stogir.terminal.validate+0x1f4>
    5458:      	cmp	x1, #0x0
    545c:      	b.ge	0x54b4 <_stogir.terminal.validate+0xd4>
    5460:      	add	x6, x0, #0x28
    5464:      	add	x7, x0, #0x50
    5468:      	ldr	x6, [x6, #0x8]
    546c:      	ldr	x7, [x7, #0x8]
    5470:      	cmp	x6, x7
    5474:      	b.ne	0x54a4 <_stogir.terminal.validate+0xc4>
    5478:      	cmp	x4, x6
    547c:      	b.gt	0x5610 <_stogir.terminal.validate+0x230>
    5480:      	lsl	x4, x5, #2
    5484:      	ldr	x4, [x0, #0x50]
    5488:      	add	x4, x4, x5, lsl #2
    548c:      	ldr	w4, [x4]
    5490:      	sxtw	x4, w4
    5494:      	cmp	x4, #0x0
    5498:      	cset	w4, gt
    549c:      	ubfx	x4, x4, #0, #8
    54a0:      	b	0x5614 <_stogir.terminal.validate+0x234>
    54a4:      	movz	x4, #0x0, lsl #48
    54a8:      	b	0x54b8 <_stogir.terminal.validate+0xd8>
    54ac:      	movz	x4, #0x0, lsl #48
    54b0:      	b	0x54b8 <_stogir.terminal.validate+0xd8>
    54b4:      	movz	x4, #0x0, lsl #48
    54b8:      	cmp	x4, #0x0
    54bc:      	b.eq	0x5520 <_stogir.terminal.validate+0x140>
    54c0:      	uxtb	w16, w3
    54c4:      	cmp	w16, wzr
    54c8:      	b.eq	0x54f0 <_stogir.terminal.validate+0x110>
    54cc:      	lsl	x3, x1, #4
    54d0:      	ldr	x3, [x0]
    54d4:      	add	x3, x3, x1, lsl #4
    54d8:      	ldr	x4, [x3]
    54dc:      	ldr	x3, [x3, #0x8]
    54e0:      	fmov	d31, x3
    54e4:      	mov	x3, x4
    54e8:      	fmov	x4, d31
    54ec:      	b	0x5510 <_stogir.terminal.validate+0x130>
    54f0:      	lsl	x3, x5, #4
    54f4:      	ldr	x3, [x0, #0x28]
    54f8:      	add	x3, x3, x5, lsl #4
    54fc:      	ldr	x4, [x3]
    5500:      	ldr	x3, [x3, #0x8]
    5504:      	fmov	d31, x3
    5508:      	mov	x3, x4
    550c:      	fmov	x4, d31
    5510:      	mov	x5, x4
    5514:      	mov	x4, x3
    5518:      	mov	x3, #0x1                ; =1
    551c:      	b	0x552c <_stogir.terminal.validate+0x14c>
    5520:      	movz	x3, #0x0, lsl #48
    5524:      	movz	x4, #0x0, lsl #48
    5528:      	movz	x5, #0x0, lsl #48
    552c:      	lsr	w3, w3, #0
    5530:      	lsr	x16, x3, #0
    5534:      	cmp	x16, #0x1
    5538:      	b.eq	0x5554 <_stogir.terminal.validate+0x174>
    553c:      	b.lo	0x5544 <_stogir.terminal.validate+0x164>
    5540:      	b	0x5558 <_stogir.terminal.validate+0x178>
    5544:      	cmp	x16, #0x0
    5548:      	b.eq	0x5550 <_stogir.terminal.validate+0x170>
    554c:      	b	0x5558 <_stogir.terminal.validate+0x178>
    5550:      	b	0x555c <_stogir.terminal.validate+0x17c>
    5554:      	b	0x557c <_stogir.terminal.validate+0x19c>
    5558:      	b	0x56ec <_stogir.terminal.validate+0x30c>
    555c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		000000000000555c:  ARM64_RELOC_PAGE21	l_stogir.382
    5560:      	ldr	x16, [x16]
		0000000000005560:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    5564:      	orr	x0, x16, xzr
    5568:      	mov	x19, x8
    556c:      	mov	x1, x0
    5570:      	mov	x0, #0x1                ; =1
    5574:      	mov	x2, #0x21               ; =33
    5578:      	b	0x55b0 <_stogir.terminal.validate+0x1d0>
    557c:      	add	x16, sp, #0x10
    5580:      	str	x4, [x16]
    5584:      	add	x16, sp, #0x10
    5588:      	str	x5, [x16, #0x8]
    558c:      	cmp	x1, #0x0
    5590:      	b.gt	0x55d8 <_stogir.terminal.validate+0x1f8>
    5594:      	mov	x19, x8
    5598:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005598:  ARM64_RELOC_PAGE21	l_stogir.383
    559c:      	ldr	x16, [x16]
		000000000000559c:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    55a0:      	orr	x0, x16, xzr
    55a4:      	mov	x1, x0
    55a8:      	mov	x0, #0x1                ; =1
    55ac:      	mov	x2, #0x1b               ; =27
    55b0:      	str	x0, [x19]
    55b4:      	str	x1, [x19, #0x8]
    55b8:      	str	x2, [x19, #0x10]
    55bc:      	ldr	x19, [sp, #0x40]
    55c0:      	ldr	x29, [sp]
    55c4:      	ldr	x30, [sp, #0x8]
    55c8:      	add	sp, sp, #0x50
    55cc:      	ret
    55d0:      	movz	x4, #0x0, lsl #48
    55d4:      	b	0x54b0 <_stogir.terminal.validate+0xd0>
    55d8:      	uxtb	w4, w4
    55dc:      	orr	x1, x4, xzr
    55e0:      	cmp	x1, #0x60
    55e4:      	cset	w3, eq
    55e8:      	cmp	x1, #0x79
    55ec:      	cset	w1, eq
    55f0:      	uxtb	w16, w3
    55f4:      	cmp	w16, wzr
    55f8:      	b.ne	0x5618 <_stogir.terminal.validate+0x238>
    55fc:      	uxtb	w16, w1
    5600:      	cmp	w16, wzr
    5604:      	b.ne	0x5618 <_stogir.terminal.validate+0x238>
    5608:      	mov	x19, x8
    560c:      	b	0x5598 <_stogir.terminal.validate+0x1b8>
    5610:      	movz	x4, #0x0, lsl #48
    5614:      	b	0x54a8 <_stogir.terminal.validate+0xc8>
    5618:      	add	x16, sp, #0x10
    561c:      	ldr	w5, [x16]
    5620:      	ubfx	x5, x5, #8, #8
    5624:      	cmp	x5, #0x0
    5628:      	b.ne	0x56f4 <_stogir.terminal.validate+0x314>
    562c:      	uxtb	w16, w3
    5630:      	cmp	w16, wzr
    5634:      	mov	x16, #0x1               ; =1
    5638:      	mov	x17, #0x3               ; =3
    563c:      	csel	x3, x16, x17, ne
    5640:      	lsr	w3, w3, #0
    5644:      	sxtw	x3, w3
    5648:      	ldr	x5, [x0, #0x78]
    564c:      	add	x2, x2, x5
    5650:      	ldr	w2, [x2]
    5654:      	sxtw	x2, w2
    5658:      	cmp	x2, x3
    565c:      	b.ne	0x56fc <_stogir.terminal.validate+0x31c>
    5660:      	uxtb	w16, w1
    5664:      	cmp	w16, wzr
    5668:      	b.eq	0x56c8 <_stogir.terminal.validate+0x2e8>
    566c:      	add	x16, sp, #0x10
    5670:      	ldr	w2, [x16, #0x8]
    5674:      	sxtw	x2, w2
    5678:      	cmp	x2, #0x0
    567c:      	b.eq	0x56c8 <_stogir.terminal.validate+0x2e8>
    5680:      	mov	x19, x8
    5684:      	b	0x5598 <_stogir.terminal.validate+0x1b8>
    5688:      	movz	x1, #0x0, lsl #48
    568c:      	lsr	w2, w2, #0
    5690:      	lsr	w4, w4, #0
    5694:      	lsr	w1, w1, #0
    5698:      	mov	w3, w1
    569c:      	mov	w1, w4
    56a0:      	mov	x19, x8
    56a4:      	add	x8, sp, #0x20
    56a8:      	bl	0x56a8 <_stogir.terminal.validate+0x2c8>
		00000000000056a8:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    56ac:      	add	x16, sp, #0x20
    56b0:      	ldr	x0, [x16]
    56b4:      	add	x16, sp, #0x20
    56b8:      	ldr	x1, [x16, #0x8]
    56bc:      	add	x16, sp, #0x20
    56c0:      	ldr	x2, [x16, #0x10]
    56c4:      	b	0x55b0 <_stogir.terminal.validate+0x1d0>
    56c8:      	add	x16, sp, #0x10
    56cc:      	ldr	w2, [x16, #0x4]
    56d0:      	uxtb	w16, w1
    56d4:      	cmp	w16, wzr
    56d8:      	b.eq	0x5688 <_stogir.terminal.validate+0x2a8>
    56dc:      	add	x16, sp, #0x10
    56e0:      	ldr	w1, [x16, #0xc]
    56e4:      	sxtw	x1, w1
    56e8:      	b	0x568c <_stogir.terminal.validate+0x2ac>
    56ec:      	brk	#0
    56f0:      	b	0x56ec <_stogir.terminal.validate+0x30c>
    56f4:      	mov	x19, x8
    56f8:      	b	0x5598 <_stogir.terminal.validate+0x1b8>
    56fc:      	mov	x19, x8
    5700:      	b	0x5598 <_stogir.terminal.validate+0x1b8>

0000000000005704 <_stogir.switch.operation?>:
    5704:      	sxtw	x0, w0
    5708:      	cmp	x0, #0x75
    570c:      	b.ne	0x5720 <_stogir.switch.operation?+0x1c>
    5710:      	mov	x0, #0x1                ; =1
    5714:      	b	0x571c <_stogir.switch.operation?+0x18>
    5718:      	movz	x0, #0x0, lsl #48
    571c:      	ret
    5720:      	cmp	x0, #0x6d
    5724:      	b.lt	0x5718 <_stogir.switch.operation?+0x14>
    5728:      	cmp	x0, #0x6f
    572c:      	cset	w0, le
    5730:      	ubfx	x0, x0, #0, #8
    5734:      	b	0x571c <_stogir.switch.operation?+0x18>

0000000000005738 <_stogir.switch.validate>:
    5738:      	sub	sp, sp, #0x70
    573c:      	str	x29, [sp]
    5740:      	str	x30, [sp, #0x8]
    5744:      	mov	x29, sp
    5748:      	str	x19, [sp, #0x60]
    574c:      	sxtw	x1, w1
    5750:      	lsl	x2, x1, #2
    5754:      	cmp	x1, #0x0
    5758:      	cset	w3, gt
    575c:      	movz	x16, #0x0, lsl #48
    5760:      	sub	x4, x16, x1
    5764:      	sub	x5, x4, #0x1
    5768:      	uxtb	w16, w3
    576c:      	cmp	w16, wzr
    5770:      	b.eq	0x57b0 <_stogir.switch.validate+0x78>
    5774:      	ldr	x4, [x0, #0x8]
    5778:      	cmp	x1, x4
    577c:      	b.ge	0x5804 <_stogir.switch.validate+0xcc>
    5780:      	add	x4, x0, #0x78
    5784:      	ldr	x4, [x4, #0x8]
    5788:      	cmp	x1, x4
    578c:      	b.ge	0x5928 <_stogir.switch.validate+0x1f0>
    5790:      	ldr	x4, [x0, #0x78]
    5794:      	add	x4, x2, x4
    5798:      	ldr	w4, [x4]
    579c:      	sxtw	x4, w4
    57a0:      	cmp	x4, #0x0
    57a4:      	cset	w4, ge
    57a8:      	ubfx	x4, x4, #0, #8
    57ac:      	b	0x592c <_stogir.switch.validate+0x1f4>
    57b0:      	cmp	x1, #0x0
    57b4:      	b.ge	0x580c <_stogir.switch.validate+0xd4>
    57b8:      	add	x6, x0, #0x28
    57bc:      	add	x7, x0, #0x50
    57c0:      	ldr	x6, [x6, #0x8]
    57c4:      	ldr	x7, [x7, #0x8]
    57c8:      	cmp	x6, x7
    57cc:      	b.ne	0x57fc <_stogir.switch.validate+0xc4>
    57d0:      	cmp	x4, x6
    57d4:      	b.gt	0x5964 <_stogir.switch.validate+0x22c>
    57d8:      	lsl	x4, x5, #2
    57dc:      	ldr	x4, [x0, #0x50]
    57e0:      	add	x4, x4, x5, lsl #2
    57e4:      	ldr	w4, [x4]
    57e8:      	sxtw	x4, w4
    57ec:      	cmp	x4, #0x0
    57f0:      	cset	w4, gt
    57f4:      	ubfx	x4, x4, #0, #8
    57f8:      	b	0x5968 <_stogir.switch.validate+0x230>
    57fc:      	movz	x4, #0x0, lsl #48
    5800:      	b	0x5810 <_stogir.switch.validate+0xd8>
    5804:      	movz	x4, #0x0, lsl #48
    5808:      	b	0x5810 <_stogir.switch.validate+0xd8>
    580c:      	movz	x4, #0x0, lsl #48
    5810:      	cmp	x4, #0x0
    5814:      	b.eq	0x5878 <_stogir.switch.validate+0x140>
    5818:      	uxtb	w16, w3
    581c:      	cmp	w16, wzr
    5820:      	b.eq	0x5848 <_stogir.switch.validate+0x110>
    5824:      	lsl	x3, x1, #4
    5828:      	ldr	x3, [x0]
    582c:      	add	x3, x3, x1, lsl #4
    5830:      	ldr	x4, [x3]
    5834:      	ldr	x3, [x3, #0x8]
    5838:      	fmov	d31, x3
    583c:      	mov	x3, x4
    5840:      	fmov	x4, d31
    5844:      	b	0x5868 <_stogir.switch.validate+0x130>
    5848:      	lsl	x3, x5, #4
    584c:      	ldr	x3, [x0, #0x28]
    5850:      	add	x3, x3, x5, lsl #4
    5854:      	ldr	x4, [x3]
    5858:      	ldr	x3, [x3, #0x8]
    585c:      	fmov	d31, x3
    5860:      	mov	x3, x4
    5864:      	fmov	x4, d31
    5868:      	mov	x5, x4
    586c:      	mov	x4, x3
    5870:      	mov	x3, #0x1                ; =1
    5874:      	b	0x5884 <_stogir.switch.validate+0x14c>
    5878:      	movz	x3, #0x0, lsl #48
    587c:      	movz	x4, #0x0, lsl #48
    5880:      	movz	x5, #0x0, lsl #48
    5884:      	lsr	w3, w3, #0
    5888:      	lsr	x16, x3, #0
    588c:      	cmp	x16, #0x1
    5890:      	b.eq	0x58ac <_stogir.switch.validate+0x174>
    5894:      	b.lo	0x589c <_stogir.switch.validate+0x164>
    5898:      	b	0x58b0 <_stogir.switch.validate+0x178>
    589c:      	cmp	x16, #0x0
    58a0:      	b.eq	0x58a8 <_stogir.switch.validate+0x170>
    58a4:      	b	0x58b0 <_stogir.switch.validate+0x178>
    58a8:      	b	0x58b4 <_stogir.switch.validate+0x17c>
    58ac:      	b	0x58d4 <_stogir.switch.validate+0x19c>
    58b0:      	b	0x5a68 <_stogir.switch.validate+0x330>
    58b4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		00000000000058b4:  ARM64_RELOC_PAGE21	l_stogir.384
    58b8:      	ldr	x16, [x16]
		00000000000058b8:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    58bc:      	orr	x0, x16, xzr
    58c0:      	mov	x19, x8
    58c4:      	mov	x1, x0
    58c8:      	mov	x0, #0x1                ; =1
    58cc:      	mov	x2, #0x1a               ; =26
    58d0:      	b	0x5908 <_stogir.switch.validate+0x1d0>
    58d4:      	add	x16, sp, #0x10
    58d8:      	str	x4, [x16]
    58dc:      	add	x16, sp, #0x10
    58e0:      	str	x5, [x16, #0x8]
    58e4:      	cmp	x1, #0x0
    58e8:      	b.gt	0x5930 <_stogir.switch.validate+0x1f8>
    58ec:      	mov	x19, x8
    58f0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		00000000000058f0:  ARM64_RELOC_PAGE21	l_stogir.385
    58f4:      	ldr	x16, [x16]
		00000000000058f4:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    58f8:      	orr	x0, x16, xzr
    58fc:      	mov	x1, x0
    5900:      	mov	x0, #0x1                ; =1
    5904:      	mov	x2, #0x20               ; =32
    5908:      	str	x0, [x19]
    590c:      	str	x1, [x19, #0x8]
    5910:      	str	x2, [x19, #0x10]
    5914:      	ldr	x19, [sp, #0x60]
    5918:      	ldr	x29, [sp]
    591c:      	ldr	x30, [sp, #0x8]
    5920:      	add	sp, sp, #0x70
    5924:      	ret
    5928:      	movz	x4, #0x0, lsl #48
    592c:      	b	0x5808 <_stogir.switch.validate+0xd0>
    5930:      	uxtb	w4, w4
    5934:      	orr	x1, x4, xzr
    5938:      	cmp	x1, #0x75
    593c:      	cset	w3, eq
    5940:      	uxtb	w16, w3
    5944:      	cmp	w16, wzr
    5948:      	b.ne	0x596c <_stogir.switch.validate+0x234>
    594c:      	cmp	x1, #0x6d
    5950:      	b.lt	0x5a70 <_stogir.switch.validate+0x338>
    5954:      	cmp	x1, #0x6f
    5958:      	b.le	0x596c <_stogir.switch.validate+0x234>
    595c:      	mov	x19, x8
    5960:      	b	0x58f0 <_stogir.switch.validate+0x1b8>
    5964:      	movz	x4, #0x0, lsl #48
    5968:      	b	0x5800 <_stogir.switch.validate+0xc8>
    596c:      	add	x16, sp, #0x10
    5970:      	ldr	w5, [x16]
    5974:      	ubfx	x5, x5, #8, #8
    5978:      	cmp	x5, #0x0
    597c:      	b.ne	0x5a78 <_stogir.switch.validate+0x340>
    5980:      	ldr	x5, [x0, #0x78]
    5984:      	add	x2, x2, x5
    5988:      	ldr	w2, [x2]
    598c:      	cmp	x1, #0x6d
    5990:      	b.eq	0x5a04 <_stogir.switch.validate+0x2cc>
    5994:      	cmp	x1, #0x6e
    5998:      	b.eq	0x5a04 <_stogir.switch.validate+0x2cc>
    599c:      	mov	x1, #0x2                ; =2
    59a0:      	b	0x5a08 <_stogir.switch.validate+0x2d0>
    59a4:      	lsr	w4, w4, #0
    59a8:      	add	x16, sp, #0x10
    59ac:      	ldr	w1, [x16, #0x4]
    59b0:      	add	x16, sp, #0x10
    59b4:      	ldr	w2, [x16, #0x8]
    59b8:      	lsr	w1, w1, #0
    59bc:      	add	x16, sp, #0x10
    59c0:      	ldr	w3, [x16, #0xc]
    59c4:      	lsr	w2, w2, #0
    59c8:      	lsr	w3, w3, #0
    59cc:      	add	x8, sp, #0x40
    59d0:      	fmov	s31, w1
    59d4:      	mov	w1, w4
    59d8:      	mov	w4, w3
    59dc:      	mov	w3, w2
    59e0:      	fmov	w2, s31
    59e4:      	bl	0x59e4 <_stogir.switch.validate+0x2ac>
		00000000000059e4:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    59e8:      	add	x16, sp, #0x40
    59ec:      	ldr	x0, [x16]
    59f0:      	add	x16, sp, #0x40
    59f4:      	ldr	x1, [x16, #0x8]
    59f8:      	add	x16, sp, #0x40
    59fc:      	ldr	x2, [x16, #0x10]
    5a00:      	b	0x5908 <_stogir.switch.validate+0x1d0>
    5a04:      	mov	x1, #0x3                ; =3
    5a08:      	sxtw	x2, w2
    5a0c:      	lsr	w1, w1, #0
    5a10:      	sxtw	x1, w1
    5a14:      	cmp	x2, x1
    5a18:      	b.ne	0x5a80 <_stogir.switch.validate+0x348>
    5a1c:      	uxtb	w16, w3
    5a20:      	cmp	w16, wzr
    5a24:      	b.eq	0x5a88 <_stogir.switch.validate+0x350>
    5a28:      	add	x16, sp, #0x10
    5a2c:      	ldr	w1, [x16, #0x4]
    5a30:      	add	x16, sp, #0x10
    5a34:      	ldr	w2, [x16, #0x8]
    5a38:      	lsr	w1, w1, #0
    5a3c:      	lsr	w2, w2, #0
    5a40:      	mov	x19, x8
    5a44:      	add	x8, sp, #0x20
    5a48:      	bl	0x5a48 <_stogir.switch.validate+0x310>
		0000000000005a48:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    5a4c:      	add	x16, sp, #0x20
    5a50:      	ldr	x0, [x16]
    5a54:      	add	x16, sp, #0x20
    5a58:      	ldr	x1, [x16, #0x8]
    5a5c:      	add	x16, sp, #0x20
    5a60:      	ldr	x2, [x16, #0x10]
    5a64:      	b	0x5a00 <_stogir.switch.validate+0x2c8>
    5a68:      	brk	#0
    5a6c:      	b	0x5a68 <_stogir.switch.validate+0x330>
    5a70:      	mov	x19, x8
    5a74:      	b	0x58f0 <_stogir.switch.validate+0x1b8>
    5a78:      	mov	x19, x8
    5a7c:      	b	0x58f0 <_stogir.switch.validate+0x1b8>
    5a80:      	mov	x19, x8
    5a84:      	b	0x58f0 <_stogir.switch.validate+0x1b8>
    5a88:      	mov	x19, x8
    5a8c:      	b	0x59a4 <_stogir.switch.validate+0x26c>

0000000000005a90 <_stogir.stack.operation?>:
    5a90:      	sxtw	x0, w0
    5a94:      	cmp	x0, #0x42
    5a98:      	b.ne	0x5ab4 <_stogir.stack.operation?+0x24>
    5a9c:      	mov	x0, #0x1                ; =1
    5aa0:      	b	0x5ab0 <_stogir.stack.operation?+0x20>
    5aa4:      	cmp	x0, #0x54
    5aa8:      	cset	w0, eq
    5aac:      	ubfx	x0, x0, #0, #8
    5ab0:      	ret
    5ab4:      	cmp	x0, #0x51
    5ab8:      	b.ne	0x5ac4 <_stogir.stack.operation?+0x34>
    5abc:      	mov	x0, #0x1                ; =1
    5ac0:      	b	0x5ab0 <_stogir.stack.operation?+0x20>
    5ac4:      	cmp	x0, #0x52
    5ac8:      	b.ne	0x5ad4 <_stogir.stack.operation?+0x44>
    5acc:      	mov	x0, #0x1                ; =1
    5ad0:      	b	0x5ab0 <_stogir.stack.operation?+0x20>
    5ad4:      	cmp	x0, #0x53
    5ad8:      	b.ne	0x5aa4 <_stogir.stack.operation?+0x14>
    5adc:      	mov	x0, #0x1                ; =1
    5ae0:      	b	0x5ab0 <_stogir.stack.operation?+0x20>

0000000000005ae4 <_stogir.stack.validate>:
    5ae4:      	sub	sp, sp, #0x90
    5ae8:      	str	x29, [sp]
    5aec:      	str	x30, [sp, #0x8]
    5af0:      	mov	x29, sp
    5af4:      	str	x19, [sp, #0x60]
    5af8:      	str	x20, [sp, #0x68]
    5afc:      	str	x21, [sp, #0x70]
    5b00:      	str	x22, [sp, #0x78]
    5b04:      	str	x23, [sp, #0x80]
    5b08:      	sxtw	x1, w1
    5b0c:      	lsl	x2, x1, #2
    5b10:      	cmp	x1, #0x0
    5b14:      	cset	w3, gt
    5b18:      	movz	x16, #0x0, lsl #48
    5b1c:      	sub	x4, x16, x1
    5b20:      	cmp	x1, #0x0
    5b24:      	cset	w5, lt
    5b28:      	sub	x6, x4, #0x1
    5b2c:      	lsl	x7, x6, #2
    5b30:      	uxtb	w16, w3
    5b34:      	cmp	w16, wzr
    5b38:      	b.eq	0x5b78 <_stogir.stack.validate+0x94>
    5b3c:      	ldr	x9, [x0, #0x8]
    5b40:      	cmp	x1, x9
    5b44:      	b.ge	0x5bf8 <_stogir.stack.validate+0x114>
    5b48:      	add	x9, x0, #0x78
    5b4c:      	ldr	x9, [x9, #0x8]
    5b50:      	cmp	x1, x9
    5b54:      	b.ge	0x5d64 <_stogir.stack.validate+0x280>
    5b58:      	ldr	x9, [x0, #0x78]
    5b5c:      	add	x9, x2, x9
    5b60:      	ldr	w9, [x9]
    5b64:      	sxtw	x9, w9
    5b68:      	cmp	x9, #0x0
    5b6c:      	cset	w9, ge
    5b70:      	ubfx	x9, x9, #0, #8
    5b74:      	b	0x5d68 <_stogir.stack.validate+0x284>
    5b78:      	uxtb	w16, w5
    5b7c:      	cmp	w16, wzr
    5b80:      	b.eq	0x5c00 <_stogir.stack.validate+0x11c>
    5b84:      	add	x9, x0, #0x28
    5b88:      	add	x10, x0, #0x50
    5b8c:      	ldr	x9, [x9, #0x8]
    5b90:      	ldr	x10, [x10, #0x8]
    5b94:      	cmp	x9, x10
    5b98:      	b.ne	0x5bc4 <_stogir.stack.validate+0xe0>
    5b9c:      	cmp	x4, x9
    5ba0:      	b.gt	0x5d6c <_stogir.stack.validate+0x288>
    5ba4:      	ldr	x9, [x0, #0x50]
    5ba8:      	add	x9, x7, x9
    5bac:      	ldr	w9, [x9]
    5bb0:      	sxtw	x9, w9
    5bb4:      	cmp	x9, #0x0
    5bb8:      	cset	w9, gt
    5bbc:      	ubfx	x9, x9, #0, #8
    5bc0:      	b	0x5d70 <_stogir.stack.validate+0x28c>
    5bc4:      	movz	x9, #0x0, lsl #48
    5bc8:      	b	0x5c04 <_stogir.stack.validate+0x120>
    5bcc:      	uxtb	w16, w9
    5bd0:      	cmp	w16, wzr
    5bd4:      	b.eq	0x5d94 <_stogir.stack.validate+0x2b0>
    5bd8:      	mov	x22, x8
    5bdc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005bdc:  ARM64_RELOC_PAGE21	l_stogir.386
    5be0:      	ldr	x16, [x16]
		0000000000005be0:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    5be4:      	orr	x0, x16, xzr
    5be8:      	mov	x1, x0
    5bec:      	mov	x0, #0x1                ; =1
    5bf0:      	mov	x2, #0x19               ; =25
    5bf4:      	b	0x5cc4 <_stogir.stack.validate+0x1e0>
    5bf8:      	movz	x9, #0x0, lsl #48
    5bfc:      	b	0x5c04 <_stogir.stack.validate+0x120>
    5c00:      	movz	x9, #0x0, lsl #48
    5c04:      	lsl	x10, x1, #4
    5c08:      	lsl	x6, x6, #4
    5c0c:      	cmp	x9, #0x0
    5c10:      	b.eq	0x5c6c <_stogir.stack.validate+0x188>
    5c14:      	uxtb	w16, w3
    5c18:      	cmp	w16, wzr
    5c1c:      	b.eq	0x5c40 <_stogir.stack.validate+0x15c>
    5c20:      	ldr	x9, [x0]
    5c24:      	add	x9, x10, x9
    5c28:      	ldr	x11, [x9]
    5c2c:      	ldr	x9, [x9, #0x8]
    5c30:      	fmov	d31, x9
    5c34:      	mov	x9, x11
    5c38:      	fmov	x11, d31
    5c3c:      	b	0x5c5c <_stogir.stack.validate+0x178>
    5c40:      	ldr	x9, [x0, #0x28]
    5c44:      	add	x9, x6, x9
    5c48:      	ldr	x11, [x9]
    5c4c:      	ldr	x9, [x9, #0x8]
    5c50:      	fmov	d31, x9
    5c54:      	mov	x9, x11
    5c58:      	fmov	x11, d31
    5c5c:      	mov	x12, x11
    5c60:      	mov	x11, x9
    5c64:      	mov	x9, #0x1                ; =1
    5c68:      	b	0x5c78 <_stogir.stack.validate+0x194>
    5c6c:      	movz	x9, #0x0, lsl #48
    5c70:      	movz	x11, #0x0, lsl #48
    5c74:      	movz	x12, #0x0, lsl #48
    5c78:      	lsr	w9, w9, #0
    5c7c:      	lsr	x16, x9, #0
    5c80:      	cmp	x16, #0x1
    5c84:      	b.eq	0x5ca0 <_stogir.stack.validate+0x1bc>
    5c88:      	b.lo	0x5c90 <_stogir.stack.validate+0x1ac>
    5c8c:      	b	0x5ca4 <_stogir.stack.validate+0x1c0>
    5c90:      	cmp	x16, #0x0
    5c94:      	b.eq	0x5c9c <_stogir.stack.validate+0x1b8>
    5c98:      	b	0x5ca4 <_stogir.stack.validate+0x1c0>
    5c9c:      	b	0x5ca8 <_stogir.stack.validate+0x1c4>
    5ca0:      	b	0x5cf4 <_stogir.stack.validate+0x210>
    5ca4:      	b	0x60ec <_stogir.stack.validate+0x608>
    5ca8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005ca8:  ARM64_RELOC_PAGE21	l_stogir.387
    5cac:      	ldr	x16, [x16]
		0000000000005cac:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    5cb0:      	orr	x0, x16, xzr
    5cb4:      	mov	x22, x8
    5cb8:      	mov	x1, x0
    5cbc:      	mov	x0, #0x1                ; =1
    5cc0:      	mov	x2, #0x19               ; =25
    5cc4:      	str	x0, [x22]
    5cc8:      	str	x1, [x22, #0x8]
    5ccc:      	str	x2, [x22, #0x10]
    5cd0:      	ldr	x19, [sp, #0x60]
    5cd4:      	ldr	x20, [sp, #0x68]
    5cd8:      	ldr	x21, [sp, #0x70]
    5cdc:      	ldr	x22, [sp, #0x78]
    5ce0:      	ldr	x23, [sp, #0x80]
    5ce4:      	ldr	x29, [sp]
    5ce8:      	ldr	x30, [sp, #0x8]
    5cec:      	add	sp, sp, #0x90
    5cf0:      	ret
    5cf4:      	cmp	x1, #0x0
    5cf8:      	cset	w9, le
    5cfc:      	uxtb	w19, w11
    5d00:      	add	x16, sp, #0x10
    5d04:      	str	x11, [x16]
    5d08:      	orr	x11, x19, xzr
    5d0c:      	add	x16, sp, #0x10
    5d10:      	str	x12, [x16, #0x8]
    5d14:      	cmp	x11, #0x42
    5d18:      	b.ne	0x5bcc <_stogir.stack.validate+0xe8>
    5d1c:      	uxtb	w16, w3
    5d20:      	cmp	w16, wzr
    5d24:      	b.eq	0x5de0 <_stogir.stack.validate+0x2fc>
    5d28:      	ldr	x4, [x0, #0x8]
    5d2c:      	cmp	x1, x4
    5d30:      	b.ge	0x5e2c <_stogir.stack.validate+0x348>
    5d34:      	add	x4, x0, #0x78
    5d38:      	ldr	x4, [x4, #0x8]
    5d3c:      	cmp	x1, x4
    5d40:      	b.ge	0x5f20 <_stogir.stack.validate+0x43c>
    5d44:      	ldr	x1, [x0, #0x78]
    5d48:      	add	x1, x2, x1
    5d4c:      	ldr	w1, [x1]
    5d50:      	sxtw	x1, w1
    5d54:      	cmp	x1, #0x0
    5d58:      	cset	w1, ge
    5d5c:      	ubfx	x1, x1, #0, #8
    5d60:      	b	0x5f24 <_stogir.stack.validate+0x440>
    5d64:      	movz	x9, #0x0, lsl #48
    5d68:      	b	0x5bfc <_stogir.stack.validate+0x118>
    5d6c:      	movz	x9, #0x0, lsl #48
    5d70:      	b	0x5bc8 <_stogir.stack.validate+0xe4>
    5d74:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005d74:  ARM64_RELOC_PAGE21	l_stogir.388
    5d78:      	ldr	x16, [x16]
		0000000000005d78:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    5d7c:      	orr	x0, x16, xzr
    5d80:      	mov	x1, x0
    5d84:      	mov	x0, #0x1                ; =1
    5d88:      	mov	x2, #0x1e               ; =30
    5d8c:      	mov	x22, x8
    5d90:      	b	0x5bf4 <_stogir.stack.validate+0x110>
    5d94:      	cmp	x11, #0x51
    5d98:      	cset	w1, eq
    5d9c:      	cmp	x11, #0x53
    5da0:      	cset	w20, eq
    5da4:      	cmp	x11, #0x54
    5da8:      	cset	w21, eq
    5dac:      	uxtb	w16, w1
    5db0:      	cmp	w16, wzr
    5db4:      	b.ne	0x5f28 <_stogir.stack.validate+0x444>
    5db8:      	cmp	x11, #0x52
    5dbc:      	b.eq	0x5f28 <_stogir.stack.validate+0x444>
    5dc0:      	uxtb	w16, w20
    5dc4:      	cmp	w16, wzr
    5dc8:      	b.ne	0x5f28 <_stogir.stack.validate+0x444>
    5dcc:      	uxtb	w16, w21
    5dd0:      	cmp	w16, wzr
    5dd4:      	b.ne	0x5f28 <_stogir.stack.validate+0x444>
    5dd8:      	mov	x22, x8
    5ddc:      	b	0x5bdc <_stogir.stack.validate+0xf8>
    5de0:      	uxtb	w16, w5
    5de4:      	cmp	w16, wzr
    5de8:      	b.eq	0x5e34 <_stogir.stack.validate+0x350>
    5dec:      	add	x1, x0, #0x28
    5df0:      	add	x5, x0, #0x50
    5df4:      	ldr	x1, [x1, #0x8]
    5df8:      	ldr	x5, [x5, #0x8]
    5dfc:      	cmp	x1, x5
    5e00:      	b.ne	0x5f18 <_stogir.stack.validate+0x434>
    5e04:      	cmp	x4, x1
    5e08:      	b.gt	0x6084 <_stogir.stack.validate+0x5a0>
    5e0c:      	ldr	x1, [x0, #0x50]
    5e10:      	add	x1, x7, x1
    5e14:      	ldr	w1, [x1]
    5e18:      	sxtw	x1, w1
    5e1c:      	cmp	x1, #0x0
    5e20:      	cset	w1, gt
    5e24:      	ubfx	x1, x1, #0, #8
    5e28:      	b	0x6088 <_stogir.stack.validate+0x5a4>
    5e2c:      	movz	x1, #0x0, lsl #48
    5e30:      	b	0x5e38 <_stogir.stack.validate+0x354>
    5e34:      	movz	x1, #0x0, lsl #48
    5e38:      	cmp	x1, #0x0
    5e3c:      	b.eq	0x5e74 <_stogir.stack.validate+0x390>
    5e40:      	uxtb	w16, w3
    5e44:      	cmp	w16, wzr
    5e48:      	b.eq	0x5e5c <_stogir.stack.validate+0x378>
    5e4c:      	ldr	x1, [x0]
    5e50:      	add	x1, x10, x1
    5e54:      	ldr	x1, [x1]
    5e58:      	b	0x5e68 <_stogir.stack.validate+0x384>
    5e5c:      	ldr	x1, [x0, #0x28]
    5e60:      	add	x1, x6, x1
    5e64:      	ldr	x1, [x1]
    5e68:      	mov	x3, x1
    5e6c:      	mov	x1, #0x1                ; =1
    5e70:      	b	0x5e7c <_stogir.stack.validate+0x398>
    5e74:      	movz	x1, #0x0, lsl #48
    5e78:      	movz	x3, #0x0, lsl #48
    5e7c:      	lsr	w1, w1, #0
    5e80:      	lsr	x16, x1, #0
    5e84:      	cmp	x16, #0x1
    5e88:      	b.eq	0x5ea4 <_stogir.stack.validate+0x3c0>
    5e8c:      	b.lo	0x5e94 <_stogir.stack.validate+0x3b0>
    5e90:      	b	0x5ea8 <_stogir.stack.validate+0x3c4>
    5e94:      	cmp	x16, #0x0
    5e98:      	b.eq	0x5ea0 <_stogir.stack.validate+0x3bc>
    5e9c:      	b	0x5ea8 <_stogir.stack.validate+0x3c4>
    5ea0:      	b	0x5eac <_stogir.stack.validate+0x3c8>
    5ea4:      	b	0x5ec8 <_stogir.stack.validate+0x3e4>
    5ea8:      	b	0x60f4 <_stogir.stack.validate+0x610>
    5eac:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x544>
		0000000000005eac:  ARM64_RELOC_PAGE21	l_stogir.389
    5eb0:      	ldr	x16, [x16]
		0000000000005eb0:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    5eb4:      	orr	x0, x16, xzr
    5eb8:      	mov	x1, x0
    5ebc:      	mov	x0, #0x1                ; =1
    5ec0:      	mov	x2, #0x21               ; =33
    5ec4:      	b	0x5d8c <_stogir.stack.validate+0x2a8>
    5ec8:      	uxtb	w16, w9
    5ecc:      	cmp	w16, wzr
    5ed0:      	b.ne	0x5d74 <_stogir.stack.validate+0x290>
    5ed4:      	uxtb	w1, w3
    5ed8:      	cmp	x1, #0x42
    5edc:      	b.ne	0x5d74 <_stogir.stack.validate+0x290>
    5ee0:      	lsr	w3, w3, #0
    5ee4:      	ubfx	x1, x3, #8, #8
    5ee8:      	cmp	x1, #0x6
    5eec:      	b.ne	0x5d74 <_stogir.stack.validate+0x290>
    5ef0:      	ldr	x0, [x0, #0x78]
    5ef4:      	add	x0, x2, x0
    5ef8:      	ldr	w0, [x0]
    5efc:      	sxtw	x0, w0
    5f00:      	cmp	x0, #0x0
    5f04:      	b.ne	0x5d74 <_stogir.stack.validate+0x290>
    5f08:      	movz	x0, #0x0, lsl #48
    5f0c:      	mov	x1, #0x8                ; =8
    5f10:      	movz	x2, #0x0, lsl #48
    5f14:      	b	0x5d8c <_stogir.stack.validate+0x2a8>
    5f18:      	movz	x1, #0x0, lsl #48
    5f1c:      	b	0x5e38 <_stogir.stack.validate+0x354>
    5f20:      	movz	x1, #0x0, lsl #48
    5f24:      	b	0x5e30 <_stogir.stack.validate+0x34c>
    5f28:      	ldr	x3, [x0, #0x78]
    5f2c:      	add	x2, x2, x3
    5f30:      	ldr	w2, [x2]
    5f34:      	uxtb	w16, w1
    5f38:      	cmp	w16, wzr
    5f3c:      	b.eq	0x5fa8 <_stogir.stack.validate+0x4c4>
    5f40:      	mov	x1, #0x3                ; =3
    5f44:      	b	0x5fbc <_stogir.stack.validate+0x4d8>
    5f48:      	add	x16, sp, #0x10
    5f4c:      	ldr	w0, [x16]
    5f50:      	add	x16, sp, #0x10
    5f54:      	ldr	w1, [x16, #0x4]
    5f58:      	add	x16, sp, #0x10
    5f5c:      	ldr	w2, [x16, #0x8]
    5f60:      	lsr	w1, w1, #0
    5f64:      	ubfx	x0, x0, #8, #8
    5f68:      	lsr	w2, w2, #0
    5f6c:      	lsr	w0, w0, #0
    5f70:      	add	x8, sp, #0x20
    5f74:      	mov	w3, w1
    5f78:      	mov	w1, w19
    5f7c:      	mov	w4, w2
    5f80:      	mov	w2, w0
    5f84:      	mov	x0, x23
    5f88:      	bl	0x5f88 <_stogir.stack.validate+0x4a4>
		0000000000005f88:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    5f8c:      	add	x16, sp, #0x20
    5f90:      	ldr	x0, [x16]
    5f94:      	add	x16, sp, #0x20
    5f98:      	ldr	x1, [x16, #0x8]
    5f9c:      	add	x16, sp, #0x20
    5fa0:      	ldr	x2, [x16, #0x10]
    5fa4:      	b	0x5bf4 <_stogir.stack.validate+0x110>
    5fa8:      	uxtb	w16, w20
    5fac:      	cmp	w16, wzr
    5fb0:      	mov	x16, #0x1               ; =1
    5fb4:      	mov	x17, #0x2               ; =2
    5fb8:      	csel	x1, x16, x17, ne
    5fbc:      	sxtw	x2, w2
    5fc0:      	lsr	w1, w1, #0
    5fc4:      	sxtw	x1, w1
    5fc8:      	cmp	x2, x1
    5fcc:      	b.ne	0x60fc <_stogir.stack.validate+0x618>
    5fd0:      	add	x16, sp, #0x10
    5fd4:      	ldr	w1, [x16]
    5fd8:      	orr	x2, x1, xzr
    5fdc:      	ubfx	x2, x2, #16, #16
    5fe0:      	and	x2, x2, #0x8000
    5fe4:      	uxth	w2, w2
    5fe8:      	cmp	x2, #0x0
    5fec:      	b.ne	0x608c <_stogir.stack.validate+0x5a8>
    5ff0:      	mov	x22, x8
    5ff4:      	mov	x23, x0
    5ff8:      	lsr	w19, w19, #0
    5ffc:      	uxtb	w16, w20
    6000:      	cmp	w16, wzr
    6004:      	b.ne	0x5f48 <_stogir.stack.validate+0x464>
    6008:      	uxtb	w16, w21
    600c:      	cmp	w16, wzr
    6010:      	b.ne	0x5f48 <_stogir.stack.validate+0x464>
    6014:      	add	x16, sp, #0x10
    6018:      	ldr	w0, [x16]
    601c:      	add	x16, sp, #0x10
    6020:      	ldr	w1, [x16, #0x4]
    6024:      	add	x16, sp, #0x10
    6028:      	ldr	w2, [x16, #0x8]
    602c:      	lsr	w1, w1, #0
    6030:      	ubfx	x0, x0, #8, #8
    6034:      	add	x16, sp, #0x10
    6038:      	ldr	w3, [x16, #0xc]
    603c:      	lsr	w2, w2, #0
    6040:      	lsr	w3, w3, #0
    6044:      	lsr	w0, w0, #0
    6048:      	add	x8, sp, #0x40
    604c:      	mov	w4, w2
    6050:      	mov	w2, w0
    6054:      	mov	x0, x23
    6058:      	mov	w5, w3
    605c:      	mov	w3, w1
    6060:      	mov	w1, w19
    6064:      	bl	0x6064 <_stogir.stack.validate+0x580>
		0000000000006064:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    6068:      	add	x16, sp, #0x40
    606c:      	ldr	x0, [x16]
    6070:      	add	x16, sp, #0x40
    6074:      	ldr	x1, [x16, #0x8]
    6078:      	add	x16, sp, #0x40
    607c:      	ldr	x2, [x16, #0x10]
    6080:      	b	0x5fa4 <_stogir.stack.validate+0x4c0>
    6084:      	movz	x1, #0x0, lsl #48
    6088:      	b	0x5f1c <_stogir.stack.validate+0x438>
    608c:      	uxtb	w2, w1
    6090:      	cmp	x2, #0x51
    6094:      	b.ne	0x6104 <_stogir.stack.validate+0x620>
    6098:      	ubfx	x1, x1, #16, #16
    609c:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    60a0:      	b.ne	0x610c <_stogir.stack.validate+0x628>
    60a4:      	add	x16, sp, #0x10
    60a8:      	ldr	w1, [x16, #0x4]
    60ac:      	add	x16, sp, #0x10
    60b0:      	ldr	w2, [x16, #0x8]
    60b4:      	lsr	w1, w1, #0
    60b8:      	lsr	w2, w2, #0
    60bc:      	mov	x22, x8
    60c0:      	mov	x23, x0
    60c4:      	bl	0x60c4 <_stogir.stack.validate+0x5e0>
		00000000000060c4:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    60c8:      	cmp	x0, #0x0
    60cc:      	b.ne	0x5ff8 <_stogir.stack.validate+0x514>
    60d0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		00000000000060d0:  ARM64_RELOC_PAGE21	l_stogir.390
    60d4:      	ldr	x16, [x16]
		00000000000060d4:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    60d8:      	orr	x0, x16, xzr
    60dc:      	mov	x1, x0
    60e0:      	mov	x0, #0x1                ; =1
    60e4:      	mov	x2, #0x26               ; =38
    60e8:      	b	0x5fa4 <_stogir.stack.validate+0x4c0>
    60ec:      	brk	#0
    60f0:      	b	0x60ec <_stogir.stack.validate+0x608>
    60f4:      	brk	#0
    60f8:      	b	0x60f4 <_stogir.stack.validate+0x610>
    60fc:      	mov	x22, x8
    6100:      	b	0x5bdc <_stogir.stack.validate+0xf8>
    6104:      	mov	x22, x8
    6108:      	b	0x60d0 <_stogir.stack.validate+0x5ec>
    610c:      	mov	x22, x8
    6110:      	b	0x60d0 <_stogir.stack.validate+0x5ec>

0000000000006114 <_stogir.locals.operation?>:
    6114:      	sxtw	x0, w0
    6118:      	cmp	x0, #0x41
    611c:      	b.ne	0x6130 <_stogir.locals.operation?+0x1c>
    6120:      	mov	x0, #0x1                ; =1
    6124:      	b	0x612c <_stogir.locals.operation?+0x18>
    6128:      	movz	x0, #0x0, lsl #48
    612c:      	ret
    6130:      	cmp	x0, #0x48
    6134:      	b.ne	0x6140 <_stogir.locals.operation?+0x2c>
    6138:      	mov	x0, #0x1                ; =1
    613c:      	b	0x612c <_stogir.locals.operation?+0x18>
    6140:      	cmp	x0, #0x55
    6144:      	b.lt	0x6128 <_stogir.locals.operation?+0x14>
    6148:      	cmp	x0, #0x58
    614c:      	cset	w0, le
    6150:      	ubfx	x0, x0, #0, #8
    6154:      	b	0x612c <_stogir.locals.operation?+0x18>

0000000000006158 <_stogir.locals.validate>:
    6158:      	sub	sp, sp, #0xb0
    615c:      	str	x29, [sp]
    6160:      	str	x30, [sp, #0x8]
    6164:      	mov	x29, sp
    6168:      	str	x19, [sp, #0x70]
    616c:      	str	x20, [sp, #0x78]
    6170:      	str	x21, [sp, #0x80]
    6174:      	str	x22, [sp, #0x88]
    6178:      	str	x23, [sp, #0x90]
    617c:      	str	x24, [sp, #0x98]
    6180:      	str	x25, [sp, #0xa0]
    6184:      	sxtw	x1, w1
    6188:      	lsl	x3, x1, #2
    618c:      	cmp	x1, #0x0
    6190:      	cset	w4, gt
    6194:      	movz	x16, #0x0, lsl #48
    6198:      	sub	x5, x16, x1
    619c:      	sub	x6, x5, #0x1
    61a0:      	uxtb	w16, w4
    61a4:      	cmp	w16, wzr
    61a8:      	b.eq	0x61e8 <_stogir.locals.validate+0x90>
    61ac:      	ldr	x5, [x0, #0x8]
    61b0:      	cmp	x1, x5
    61b4:      	b.ge	0x6288 <_stogir.locals.validate+0x130>
    61b8:      	add	x5, x0, #0x78
    61bc:      	ldr	x5, [x5, #0x8]
    61c0:      	cmp	x1, x5
    61c4:      	b.ge	0x63b0 <_stogir.locals.validate+0x258>
    61c8:      	ldr	x5, [x0, #0x78]
    61cc:      	add	x5, x3, x5
    61d0:      	ldr	w5, [x5]
    61d4:      	sxtw	x5, w5
    61d8:      	cmp	x5, #0x0
    61dc:      	cset	w5, ge
    61e0:      	ubfx	x5, x5, #0, #8
    61e4:      	b	0x63b4 <_stogir.locals.validate+0x25c>
    61e8:      	cmp	x1, #0x0
    61ec:      	b.ge	0x6290 <_stogir.locals.validate+0x138>
    61f0:      	add	x7, x0, #0x28
    61f4:      	add	x9, x0, #0x50
    61f8:      	ldr	x7, [x7, #0x8]
    61fc:      	ldr	x9, [x9, #0x8]
    6200:      	cmp	x7, x9
    6204:      	b.ne	0x6234 <_stogir.locals.validate+0xdc>
    6208:      	cmp	x5, x7
    620c:      	b.gt	0x6438 <_stogir.locals.validate+0x2e0>
    6210:      	lsl	x5, x6, #2
    6214:      	ldr	x5, [x0, #0x50]
    6218:      	add	x5, x5, x6, lsl #2
    621c:      	ldr	w5, [x5]
    6220:      	sxtw	x5, w5
    6224:      	cmp	x5, #0x0
    6228:      	cset	w5, gt
    622c:      	ubfx	x5, x5, #0, #8
    6230:      	b	0x643c <_stogir.locals.validate+0x2e4>
    6234:      	movz	x5, #0x0, lsl #48
    6238:      	b	0x6294 <_stogir.locals.validate+0x13c>
    623c:      	cmp	x5, #0x0
    6240:      	cset	w5, ne
    6244:      	uxtb	w16, w5
    6248:      	cmp	w16, wzr
    624c:      	mov	x16, #0x2               ; =2
    6250:      	mov	x17, #0x3               ; =3
    6254:      	csel	x5, x16, x17, ne
    6258:      	lsr	w5, w5, #0
    625c:      	sxtw	x5, w5
    6260:      	cmp	x1, #0x0
    6264:      	b.gt	0x63b8 <_stogir.locals.validate+0x260>
    6268:      	mov	x23, x8
    626c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		000000000000626c:  ARM64_RELOC_PAGE21	l_stogir.391
    6270:      	ldr	x16, [x16]
		0000000000006270:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    6274:      	orr	x0, x16, xzr
    6278:      	mov	x1, x0
    627c:      	mov	x0, #0x1                ; =1
    6280:      	mov	x2, #0x17               ; =23
    6284:      	b	0x6354 <_stogir.locals.validate+0x1fc>
    6288:      	movz	x5, #0x0, lsl #48
    628c:      	b	0x6294 <_stogir.locals.validate+0x13c>
    6290:      	movz	x5, #0x0, lsl #48
    6294:      	cmp	x5, #0x0
    6298:      	b.eq	0x62fc <_stogir.locals.validate+0x1a4>
    629c:      	uxtb	w16, w4
    62a0:      	cmp	w16, wzr
    62a4:      	b.eq	0x62cc <_stogir.locals.validate+0x174>
    62a8:      	lsl	x4, x1, #4
    62ac:      	ldr	x4, [x0]
    62b0:      	add	x4, x4, x1, lsl #4
    62b4:      	ldr	x5, [x4]
    62b8:      	ldr	x4, [x4, #0x8]
    62bc:      	fmov	d31, x4
    62c0:      	mov	x4, x5
    62c4:      	fmov	x5, d31
    62c8:      	b	0x62ec <_stogir.locals.validate+0x194>
    62cc:      	lsl	x4, x6, #4
    62d0:      	ldr	x4, [x0, #0x28]
    62d4:      	add	x4, x4, x6, lsl #4
    62d8:      	ldr	x5, [x4]
    62dc:      	ldr	x4, [x4, #0x8]
    62e0:      	fmov	d31, x4
    62e4:      	mov	x4, x5
    62e8:      	fmov	x5, d31
    62ec:      	mov	x6, x5
    62f0:      	mov	x5, x4
    62f4:      	mov	x4, #0x1                ; =1
    62f8:      	b	0x6308 <_stogir.locals.validate+0x1b0>
    62fc:      	movz	x4, #0x0, lsl #48
    6300:      	movz	x5, #0x0, lsl #48
    6304:      	movz	x6, #0x0, lsl #48
    6308:      	lsr	w4, w4, #0
    630c:      	lsr	x16, x4, #0
    6310:      	cmp	x16, #0x1
    6314:      	b.eq	0x6330 <_stogir.locals.validate+0x1d8>
    6318:      	b.lo	0x6320 <_stogir.locals.validate+0x1c8>
    631c:      	b	0x6334 <_stogir.locals.validate+0x1dc>
    6320:      	cmp	x16, #0x0
    6324:      	b.eq	0x632c <_stogir.locals.validate+0x1d4>
    6328:      	b	0x6334 <_stogir.locals.validate+0x1dc>
    632c:      	b	0x6338 <_stogir.locals.validate+0x1e0>
    6330:      	b	0x638c <_stogir.locals.validate+0x234>
    6334:      	b	0x657c <_stogir.locals.validate+0x424>
    6338:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006338:  ARM64_RELOC_PAGE21	l_stogir.392
    633c:      	ldr	x16, [x16]
		000000000000633c:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    6340:      	orr	x0, x16, xzr
    6344:      	mov	x23, x8
    6348:      	mov	x1, x0
    634c:      	mov	x0, #0x1                ; =1
    6350:      	mov	x2, #0x17               ; =23
    6354:      	str	x0, [x23]
    6358:      	str	x1, [x23, #0x8]
    635c:      	str	x2, [x23, #0x10]
    6360:      	ldr	x19, [sp, #0x70]
    6364:      	ldr	x20, [sp, #0x78]
    6368:      	ldr	x21, [sp, #0x80]
    636c:      	ldr	x22, [sp, #0x88]
    6370:      	ldr	x23, [sp, #0x90]
    6374:      	ldr	x24, [sp, #0x98]
    6378:      	ldr	x25, [sp, #0xa0]
    637c:      	ldr	x29, [sp]
    6380:      	ldr	x30, [sp, #0x8]
    6384:      	add	sp, sp, #0xb0
    6388:      	ret
    638c:      	uxtb	w4, w5
    6390:      	add	x16, sp, #0x10
    6394:      	str	x5, [x16]
    6398:      	add	x16, sp, #0x10
    639c:      	str	x6, [x16, #0x8]
    63a0:      	cmp	x4, #0x55
    63a4:      	b.ne	0x641c <_stogir.locals.validate+0x2c4>
    63a8:      	mov	x5, #0x1                ; =1
    63ac:      	b	0x6428 <_stogir.locals.validate+0x2d0>
    63b0:      	movz	x5, #0x0, lsl #48
    63b4:      	b	0x628c <_stogir.locals.validate+0x134>
    63b8:      	cmp	x4, #0x48
    63bc:      	cset	w21, eq
    63c0:      	uxtb	w16, w20
    63c4:      	cmp	w16, wzr
    63c8:      	b.ne	0x6440 <_stogir.locals.validate+0x2e8>
    63cc:      	uxtb	w16, w21
    63d0:      	cmp	w16, wzr
    63d4:      	b.ne	0x6440 <_stogir.locals.validate+0x2e8>
    63d8:      	cmp	x4, #0x55
    63dc:      	b.lt	0x6914 <_stogir.locals.validate+0x7bc>
    63e0:      	cmp	x4, #0x58
    63e4:      	b.le	0x6440 <_stogir.locals.validate+0x2e8>
    63e8:      	mov	x23, x8
    63ec:      	b	0x626c <_stogir.locals.validate+0x114>
    63f0:      	cmp	x4, #0x58
    63f4:      	cset	w6, eq
    63f8:      	ubfx	x6, x6, #0, #8
    63fc:      	mov	x19, x6
    6400:      	cmp	x4, #0x41
    6404:      	cset	w20, eq
    6408:      	uxtb	w16, w20
    640c:      	cmp	w16, wzr
    6410:      	b.eq	0x623c <_stogir.locals.validate+0xe4>
    6414:      	mov	x5, #0x1                ; =1
    6418:      	b	0x6260 <_stogir.locals.validate+0x108>
    641c:      	cmp	x4, #0x56
    6420:      	cset	w5, eq
    6424:      	ubfx	x5, x5, #0, #8
    6428:      	cmp	x4, #0x57
    642c:      	b.ne	0x63f0 <_stogir.locals.validate+0x298>
    6430:      	mov	x19, #0x1               ; =1
    6434:      	b	0x6400 <_stogir.locals.validate+0x2a8>
    6438:      	movz	x5, #0x0, lsl #48
    643c:      	b	0x6238 <_stogir.locals.validate+0xe0>
    6440:      	lsr	w5, w5, #0
    6444:      	sxtw	x5, w5
    6448:      	ldr	x4, [x0, #0x78]
    644c:      	add	x3, x3, x4
    6450:      	ldr	w3, [x3]
    6454:      	sxtw	x3, w3
    6458:      	cmp	x3, x5
    645c:      	b.ne	0x691c <_stogir.locals.validate+0x7c4>
    6460:      	uxtb	w16, w20
    6464:      	cmp	w16, wzr
    6468:      	b.ne	0x6488 <_stogir.locals.validate+0x330>
    646c:      	uxtb	w16, w21
    6470:      	cmp	w16, wzr
    6474:      	b.ne	0x6488 <_stogir.locals.validate+0x330>
    6478:      	add	x16, sp, #0x10
    647c:      	ldr	w1, [x16, #0x8]
    6480:      	sxtw	x1, w1
    6484:      	b	0x64a0 <_stogir.locals.validate+0x348>
    6488:      	uxtb	w16, w21
    648c:      	cmp	w16, wzr
    6490:      	b.ne	0x64a0 <_stogir.locals.validate+0x348>
    6494:      	add	x16, sp, #0x10
    6498:      	ldr	w1, [x16, #0x4]
    649c:      	sxtw	x1, w1
    64a0:      	add	x16, sp, #0x20
    64a4:      	orr	x22, x16, xzr
    64a8:      	lsr	w2, w2, #0
    64ac:      	lsr	w1, w1, #0
    64b0:      	mov	x23, x8
    64b4:      	add	x8, sp, #0x20
    64b8:      	mov	x24, x0
    64bc:      	mov	w25, w2
    64c0:      	bl	0x64c0 <_stogir.locals.validate+0x368>
		00000000000064c0:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    64c4:      	add	x16, sp, #0x20
    64c8:      	ldr	w0, [x16]
    64cc:      	lsr	x16, x0, #0
    64d0:      	cmp	x16, #0x1
    64d4:      	b.eq	0x64f0 <_stogir.locals.validate+0x398>
    64d8:      	b.lo	0x64e0 <_stogir.locals.validate+0x388>
    64dc:      	b	0x64f4 <_stogir.locals.validate+0x39c>
    64e0:      	cmp	x16, #0x0
    64e4:      	b.eq	0x64ec <_stogir.locals.validate+0x394>
    64e8:      	b	0x64f4 <_stogir.locals.validate+0x39c>
    64ec:      	b	0x6514 <_stogir.locals.validate+0x3bc>
    64f0:      	b	0x64f8 <_stogir.locals.validate+0x3a0>
    64f4:      	b	0x6774 <_stogir.locals.validate+0x61c>
    64f8:      	add	x0, x22, #0x8
    64fc:      	add	x16, sp, #0x20
    6500:      	ldr	x1, [x16, #0x8]
    6504:      	ldr	x0, [x0, #0x8]
    6508:      	mov	x2, x0
    650c:      	mov	x0, #0x1                ; =1
    6510:      	b	0x6284 <_stogir.locals.validate+0x12c>
    6514:      	add	x16, sp, #0x20
    6518:      	ldr	x22, [x16, #0x8]
    651c:      	uxtb	w16, w21
    6520:      	cmp	w16, wzr
    6524:      	b.eq	0x6544 <_stogir.locals.validate+0x3ec>
    6528:      	lsr	w22, w22, #0
    652c:      	sxtw	x22, w22
    6530:      	and	x0, x22, #0xffffffff
    6534:      	mov	x1, x0
    6538:      	movz	x0, #0x0, lsl #48
    653c:      	movz	x2, #0x0, lsl #48
    6540:      	b	0x6510 <_stogir.locals.validate+0x3b8>
    6544:      	uxtb	w16, w20
    6548:      	cmp	w16, wzr
    654c:      	b.eq	0x65a0 <_stogir.locals.validate+0x448>
    6550:      	add	x16, sp, #0x10
    6554:      	ldr	w0, [x16]
    6558:      	ubfx	x0, x0, #8, #8
    655c:      	cmp	x0, #0x6
    6560:      	b.ne	0x6584 <_stogir.locals.validate+0x42c>
    6564:      	sxtw	x25, w25
    6568:      	and	x0, x25, #0xffffffff
    656c:      	mov	x1, x0
    6570:      	movz	x0, #0x0, lsl #48
    6574:      	movz	x2, #0x0, lsl #48
    6578:      	b	0x659c <_stogir.locals.validate+0x444>
    657c:      	brk	#0
    6580:      	b	0x657c <_stogir.locals.validate+0x424>
    6584:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006584:  ARM64_RELOC_PAGE21	l_stogir.393
    6588:      	ldr	x16, [x16]
		0000000000006588:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    658c:      	orr	x0, x16, xzr
    6590:      	mov	x1, x0
    6594:      	mov	x0, #0x1                ; =1
    6598:      	mov	x2, #0x21               ; =33
    659c:      	b	0x6540 <_stogir.locals.validate+0x3e8>
    65a0:      	add	x16, sp, #0x10
    65a4:      	ldr	w0, [x16, #0x4]
    65a8:      	sxtw	x0, w0
    65ac:      	cmp	x0, #0x0
    65b0:      	cset	w1, gt
    65b4:      	movz	x16, #0x0, lsl #48
    65b8:      	sub	x2, x16, x0
    65bc:      	sub	x3, x2, #0x1
    65c0:      	uxtb	w16, w1
    65c4:      	cmp	w16, wzr
    65c8:      	b.eq	0x66b0 <_stogir.locals.validate+0x558>
    65cc:      	ldr	x2, [x24, #0x8]
    65d0:      	cmp	x0, x2
    65d4:      	b.ge	0x66a8 <_stogir.locals.validate+0x550>
    65d8:      	add	x2, x24, #0x78
    65dc:      	ldr	x2, [x2, #0x8]
    65e0:      	cmp	x0, x2
    65e4:      	b.ge	0x6764 <_stogir.locals.validate+0x60c>
    65e8:      	lsl	x2, x0, #2
    65ec:      	ldr	x2, [x24, #0x78]
    65f0:      	add	x2, x2, x0, lsl #2
    65f4:      	ldr	w2, [x2]
    65f8:      	sxtw	x2, w2
    65fc:      	cmp	x2, #0x0
    6600:      	cset	w2, ge
    6604:      	ubfx	x2, x2, #0, #8
    6608:      	b	0x6768 <_stogir.locals.validate+0x610>
    660c:      	movz	x0, #0x0, lsl #48
    6610:      	movz	x1, #0x0, lsl #48
    6614:      	lsr	w0, w0, #0
    6618:      	lsr	x16, x0, #0
    661c:      	cmp	x16, #0x1
    6620:      	b.eq	0x663c <_stogir.locals.validate+0x4e4>
    6624:      	b.lo	0x662c <_stogir.locals.validate+0x4d4>
    6628:      	b	0x6640 <_stogir.locals.validate+0x4e8>
    662c:      	cmp	x16, #0x0
    6630:      	b.eq	0x6638 <_stogir.locals.validate+0x4e0>
    6634:      	b	0x6640 <_stogir.locals.validate+0x4e8>
    6638:      	b	0x6644 <_stogir.locals.validate+0x4ec>
    663c:      	b	0x66fc <_stogir.locals.validate+0x5a4>
    6640:      	b	0x68e4 <_stogir.locals.validate+0x78c>
    6644:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006644:  ARM64_RELOC_PAGE21	l_stogir.394
    6648:      	ldr	x16, [x16]
		0000000000006648:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    664c:      	orr	x0, x16, xzr
    6650:      	mov	x1, x0
    6654:      	mov	x0, #0x1                ; =1
    6658:      	mov	x2, #0x1c               ; =28
    665c:      	b	0x659c <_stogir.locals.validate+0x444>
    6660:      	lsl	x0, x3, #4
    6664:      	ldr	x0, [x24, #0x28]
    6668:      	add	x0, x0, x3, lsl #4
    666c:      	ldr	x0, [x0]
    6670:      	mov	x1, x0
    6674:      	mov	x0, #0x1                ; =1
    6678:      	b	0x6614 <_stogir.locals.validate+0x4bc>
    667c:      	movz	x2, #0x0, lsl #48
    6680:      	cmp	x2, #0x0
    6684:      	b.eq	0x660c <_stogir.locals.validate+0x4b4>
    6688:      	uxtb	w16, w1
    668c:      	cmp	w16, wzr
    6690:      	b.eq	0x6660 <_stogir.locals.validate+0x508>
    6694:      	lsl	x1, x0, #4
    6698:      	ldr	x1, [x24]
    669c:      	add	x0, x1, x0, lsl #4
    66a0:      	ldr	x0, [x0]
    66a4:      	b	0x6670 <_stogir.locals.validate+0x518>
    66a8:      	movz	x2, #0x0, lsl #48
    66ac:      	b	0x6680 <_stogir.locals.validate+0x528>
    66b0:      	cmp	x0, #0x0
    66b4:      	b.ge	0x667c <_stogir.locals.validate+0x524>
    66b8:      	add	x4, x24, #0x28
    66bc:      	add	x5, x24, #0x50
    66c0:      	ldr	x4, [x4, #0x8]
    66c4:      	ldr	x5, [x5, #0x8]
    66c8:      	cmp	x4, x5
    66cc:      	b.ne	0x675c <_stogir.locals.validate+0x604>
    66d0:      	cmp	x2, x4
    66d4:      	b.gt	0x676c <_stogir.locals.validate+0x614>
    66d8:      	lsl	x2, x3, #2
    66dc:      	ldr	x2, [x24, #0x50]
    66e0:      	add	x2, x2, x3, lsl #2
    66e4:      	ldr	w2, [x2]
    66e8:      	sxtw	x2, w2
    66ec:      	cmp	x2, #0x0
    66f0:      	cset	w2, gt
    66f4:      	ubfx	x2, x2, #0, #8
    66f8:      	b	0x6770 <_stogir.locals.validate+0x618>
    66fc:      	add	x16, sp, #0x10
    6700:      	ldr	w0, [x16, #0x4]
    6704:      	sxtw	x0, w0
    6708:      	cmp	x0, #0x0
    670c:      	b.le	0x6740 <_stogir.locals.validate+0x5e8>
    6710:      	uxtb	w1, w1
    6714:      	cmp	x1, #0x83
    6718:      	cset	w0, lt
    671c:      	uxtb	w16, w0
    6720:      	cmp	w16, wzr
    6724:      	b.eq	0x677c <_stogir.locals.validate+0x624>
    6728:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006728:  ARM64_RELOC_PAGE21	l_stogir.395
    672c:      	ldr	x16, [x16]
		000000000000672c:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    6730:      	orr	x2, x16, xzr
    6734:      	add	x2, x1, x2
    6738:      	ldrb	w2, [x2]
    673c:      	b	0x6780 <_stogir.locals.validate+0x628>
    6740:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006740:  ARM64_RELOC_PAGE21	l_stogir.396
    6744:      	ldr	x16, [x16]
		0000000000006744:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    6748:      	orr	x0, x16, xzr
    674c:      	mov	x1, x0
    6750:      	mov	x0, #0x1                ; =1
    6754:      	mov	x2, #0x1c               ; =28
    6758:      	b	0x665c <_stogir.locals.validate+0x504>
    675c:      	movz	x2, #0x0, lsl #48
    6760:      	b	0x6680 <_stogir.locals.validate+0x528>
    6764:      	movz	x2, #0x0, lsl #48
    6768:      	b	0x66ac <_stogir.locals.validate+0x554>
    676c:      	movz	x2, #0x0, lsl #48
    6770:      	b	0x6760 <_stogir.locals.validate+0x608>
    6774:      	brk	#0
    6778:      	b	0x6774 <_stogir.locals.validate+0x61c>
    677c:      	movz	x2, #0x0, lsl #48
    6780:      	uxtb	w2, w2
    6784:      	and	x2, x2, #0x1
    6788:      	uxtb	w2, w2
    678c:      	cmp	x2, #0x0
    6790:      	b.eq	0x6740 <_stogir.locals.validate+0x5e8>
    6794:      	uxtb	w16, w0
    6798:      	cmp	w16, wzr
    679c:      	b.eq	0x67b8 <_stogir.locals.validate+0x660>
    67a0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		00000000000067a0:  ARM64_RELOC_PAGE21	l_stogir.395
    67a4:      	ldr	x16, [x16]
		00000000000067a4:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    67a8:      	orr	x0, x16, xzr
    67ac:      	add	x0, x1, x0
    67b0:      	ldrb	w0, [x0]
    67b4:      	b	0x67bc <_stogir.locals.validate+0x664>
    67b8:      	movz	x0, #0x0, lsl #48
    67bc:      	uxtb	w0, w0
    67c0:      	and	x0, x0, #0x4
    67c4:      	uxtb	w0, w0
    67c8:      	cmp	x0, #0x0
    67cc:      	cset	w0, eq
    67d0:      	uxtb	w16, w0
    67d4:      	cmp	w16, wzr
    67d8:      	cset	x0, eq
    67dc:      	cmp	x0, #0x0
    67e0:      	b.ne	0x6740 <_stogir.locals.validate+0x5e8>
    67e4:      	cmp	x19, #0x0
    67e8:      	b.eq	0x6888 <_stogir.locals.validate+0x730>
    67ec:      	add	x16, sp, #0x10
    67f0:      	ldr	w0, [x16, #0xc]
    67f4:      	lsr	w0, w0, #0
    67f8:      	add	x8, sp, #0x40
    67fc:      	mov	w1, w0
    6800:      	mov	x0, x24
    6804:      	bl	0x6804 <_stogir.locals.validate+0x6ac>
		0000000000006804:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    6808:      	add	x16, sp, #0x40
    680c:      	ldr	x0, [x16]
    6810:      	add	x16, sp, #0x40
    6814:      	ldr	x1, [x16, #0x8]
    6818:      	mov	x20, x1
    681c:      	b	0x6898 <_stogir.locals.validate+0x740>
    6820:      	lsr	w25, w25, #0
    6824:      	lsr	w0, w20, #0
    6828:      	ubfx	x0, x0, #8, #8
    682c:      	lsr	w0, w0, #0
    6830:      	mov	w1, w25
    6834:      	bl	0x6834 <_stogir.locals.validate+0x6dc>
		0000000000006834:  ARM64_RELOC_BRANCH26	_stogir.types.size
    6838:      	lsr	w0, w0, #0
    683c:      	sxtw	x0, w0
    6840:      	cmp	x0, #0x0
    6844:      	b.le	0x686c <_stogir.locals.validate+0x714>
    6848:      	cmp	x0, x22
    684c:      	b.gt	0x686c <_stogir.locals.validate+0x714>
    6850:      	cmp	x19, #0x0
    6854:      	b.eq	0x68ec <_stogir.locals.validate+0x794>
    6858:      	add	x16, sp, #0x10
    685c:      	ldr	w1, [x16]
    6860:      	ubfx	x1, x1, #8, #8
    6864:      	cmp	x1, #0x0
    6868:      	b.eq	0x68ec <_stogir.locals.validate+0x794>
    686c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		000000000000686c:  ARM64_RELOC_PAGE21	l_stogir.397
    6870:      	ldr	x16, [x16]
		0000000000006870:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    6874:      	orr	x0, x16, xzr
    6878:      	mov	x1, x0
    687c:      	mov	x0, #0x1                ; =1
    6880:      	mov	x2, #0x23               ; =35
    6884:      	b	0x6758 <_stogir.locals.validate+0x600>
    6888:      	add	x16, sp, #0x10
    688c:      	ldr	x0, [x16]
    6890:      	mov	x20, x0
    6894:      	mov	x0, #0x1                ; =1
    6898:      	lsr	w0, w0, #0
    689c:      	lsr	x16, x0, #0
    68a0:      	cmp	x16, #0x1
    68a4:      	b.eq	0x68c0 <_stogir.locals.validate+0x768>
    68a8:      	b.lo	0x68b0 <_stogir.locals.validate+0x758>
    68ac:      	b	0x68c4 <_stogir.locals.validate+0x76c>
    68b0:      	cmp	x16, #0x0
    68b4:      	b.eq	0x68bc <_stogir.locals.validate+0x764>
    68b8:      	b	0x68c4 <_stogir.locals.validate+0x76c>
    68bc:      	b	0x68c8 <_stogir.locals.validate+0x770>
    68c0:      	b	0x6820 <_stogir.locals.validate+0x6c8>
    68c4:      	b	0x690c <_stogir.locals.validate+0x7b4>
    68c8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		00000000000068c8:  ARM64_RELOC_PAGE21	l_stogir.398
    68cc:      	ldr	x16, [x16]
		00000000000068cc:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    68d0:      	orr	x0, x16, xzr
    68d4:      	mov	x1, x0
    68d8:      	mov	x0, #0x1                ; =1
    68dc:      	mov	x2, #0x19               ; =25
    68e0:      	b	0x6884 <_stogir.locals.validate+0x72c>
    68e4:      	brk	#0
    68e8:      	b	0x68e4 <_stogir.locals.validate+0x78c>
    68ec:      	uxtb	w20, w20
    68f0:      	cmp	x20, #0x48
    68f4:      	b.eq	0x686c <_stogir.locals.validate+0x714>
    68f8:      	and	x0, x0, #0xffffffff
    68fc:      	mov	x1, x0
    6900:      	movz	x0, #0x0, lsl #48
    6904:      	movz	x2, #0x0, lsl #48
    6908:      	b	0x6884 <_stogir.locals.validate+0x72c>
    690c:      	brk	#0
    6910:      	b	0x690c <_stogir.locals.validate+0x7b4>
    6914:      	mov	x23, x8
    6918:      	b	0x626c <_stogir.locals.validate+0x114>
    691c:      	mov	x23, x8
    6920:      	b	0x626c <_stogir.locals.validate+0x114>

0000000000006924 <_stogir.conversion.operation?>:
    6924:      	sxtw	x0, w0
    6928:      	cmp	x0, #0x21
    692c:      	b.lt	0x6940 <_stogir.conversion.operation?+0x1c>
    6930:      	cmp	x0, #0x27
    6934:      	cset	w0, le
    6938:      	ubfx	x0, x0, #0, #8
    693c:      	b	0x6944 <_stogir.conversion.operation?+0x20>
    6940:      	movz	x0, #0x0, lsl #48
    6944:      	ret

0000000000006948 <_stogir.conversion.validate>:
    6948:      	sub	sp, sp, #0x40
    694c:      	str	x29, [sp]
    6950:      	str	x30, [sp, #0x8]
    6954:      	mov	x29, sp
    6958:      	str	x19, [sp, #0x30]
    695c:      	sxtw	x1, w1
    6960:      	lsl	x3, x1, #2
    6964:      	cmp	x1, #0x0
    6968:      	cset	w4, gt
    696c:      	movz	x16, #0x0, lsl #48
    6970:      	sub	x5, x16, x1
    6974:      	sub	x6, x5, #0x1
    6978:      	uxtb	w16, w4
    697c:      	cmp	w16, wzr
    6980:      	b.eq	0x69c0 <_stogir.conversion.validate+0x78>
    6984:      	ldr	x5, [x0, #0x8]
    6988:      	cmp	x1, x5
    698c:      	b.ge	0x6a14 <_stogir.conversion.validate+0xcc>
    6990:      	add	x5, x0, #0x78
    6994:      	ldr	x5, [x5, #0x8]
    6998:      	cmp	x1, x5
    699c:      	b.ge	0x6b00 <_stogir.conversion.validate+0x1b8>
    69a0:      	ldr	x5, [x0, #0x78]
    69a4:      	add	x5, x3, x5
    69a8:      	ldr	w5, [x5]
    69ac:      	sxtw	x5, w5
    69b0:      	cmp	x5, #0x0
    69b4:      	cset	w5, ge
    69b8:      	ubfx	x5, x5, #0, #8
    69bc:      	b	0x6b04 <_stogir.conversion.validate+0x1bc>
    69c0:      	cmp	x1, #0x0
    69c4:      	b.ge	0x6a1c <_stogir.conversion.validate+0xd4>
    69c8:      	add	x7, x0, #0x28
    69cc:      	add	x9, x0, #0x50
    69d0:      	ldr	x7, [x7, #0x8]
    69d4:      	ldr	x9, [x9, #0x8]
    69d8:      	cmp	x7, x9
    69dc:      	b.ne	0x6a0c <_stogir.conversion.validate+0xc4>
    69e0:      	cmp	x5, x7
    69e4:      	b.gt	0x6b98 <_stogir.conversion.validate+0x250>
    69e8:      	lsl	x5, x6, #2
    69ec:      	ldr	x5, [x0, #0x50]
    69f0:      	add	x5, x5, x6, lsl #2
    69f4:      	ldr	w5, [x5]
    69f8:      	sxtw	x5, w5
    69fc:      	cmp	x5, #0x0
    6a00:      	cset	w5, gt
    6a04:      	ubfx	x5, x5, #0, #8
    6a08:      	b	0x6b9c <_stogir.conversion.validate+0x254>
    6a0c:      	movz	x5, #0x0, lsl #48
    6a10:      	b	0x6a20 <_stogir.conversion.validate+0xd8>
    6a14:      	movz	x5, #0x0, lsl #48
    6a18:      	b	0x6a20 <_stogir.conversion.validate+0xd8>
    6a1c:      	movz	x5, #0x0, lsl #48
    6a20:      	cmp	x5, #0x0
    6a24:      	b.eq	0x6a64 <_stogir.conversion.validate+0x11c>
    6a28:      	uxtb	w16, w4
    6a2c:      	cmp	w16, wzr
    6a30:      	b.eq	0x6a48 <_stogir.conversion.validate+0x100>
    6a34:      	lsl	x4, x1, #4
    6a38:      	ldr	x4, [x0]
    6a3c:      	add	x4, x4, x1, lsl #4
    6a40:      	ldr	x4, [x4]
    6a44:      	b	0x6a58 <_stogir.conversion.validate+0x110>
    6a48:      	lsl	x4, x6, #4
    6a4c:      	ldr	x4, [x0, #0x28]
    6a50:      	add	x4, x4, x6, lsl #4
    6a54:      	ldr	x4, [x4]
    6a58:      	mov	x5, x4
    6a5c:      	mov	x4, #0x1                ; =1
    6a60:      	b	0x6a6c <_stogir.conversion.validate+0x124>
    6a64:      	movz	x4, #0x0, lsl #48
    6a68:      	movz	x5, #0x0, lsl #48
    6a6c:      	lsr	w4, w4, #0
    6a70:      	lsr	x16, x4, #0
    6a74:      	cmp	x16, #0x1
    6a78:      	b.eq	0x6a94 <_stogir.conversion.validate+0x14c>
    6a7c:      	b.lo	0x6a84 <_stogir.conversion.validate+0x13c>
    6a80:      	b	0x6a98 <_stogir.conversion.validate+0x150>
    6a84:      	cmp	x16, #0x0
    6a88:      	b.eq	0x6a90 <_stogir.conversion.validate+0x148>
    6a8c:      	b	0x6a98 <_stogir.conversion.validate+0x150>
    6a90:      	b	0x6a9c <_stogir.conversion.validate+0x154>
    6a94:      	b	0x6ad8 <_stogir.conversion.validate+0x190>
    6a98:      	b	0x6c18 <_stogir.conversion.validate+0x2d0>
    6a9c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006a9c:  ARM64_RELOC_PAGE21	l_stogir.399
    6aa0:      	ldr	x16, [x16]
		0000000000006aa0:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    6aa4:      	orr	x0, x16, xzr
    6aa8:      	mov	x19, x8
    6aac:      	mov	x1, x0
    6ab0:      	mov	x0, #0x1                ; =1
    6ab4:      	mov	x2, #0x12               ; =18
    6ab8:      	str	x0, [x19]
    6abc:      	str	x1, [x19, #0x8]
    6ac0:      	str	x2, [x19, #0x10]
    6ac4:      	ldr	x19, [sp, #0x30]
    6ac8:      	ldr	x29, [sp]
    6acc:      	ldr	x30, [sp, #0x8]
    6ad0:      	add	sp, sp, #0x40
    6ad4:      	ret
    6ad8:      	cmp	x1, #0x0
    6adc:      	b.gt	0x6b08 <_stogir.conversion.validate+0x1c0>
    6ae0:      	mov	x19, x8
    6ae4:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006ae4:  ARM64_RELOC_PAGE21	l_stogir.400
    6ae8:      	ldr	x16, [x16]
		0000000000006ae8:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    6aec:      	orr	x0, x16, xzr
    6af0:      	mov	x1, x0
    6af4:      	mov	x0, #0x1                ; =1
    6af8:      	mov	x2, #0x1e               ; =30
    6afc:      	b	0x6ab8 <_stogir.conversion.validate+0x170>
    6b00:      	movz	x5, #0x0, lsl #48
    6b04:      	b	0x6a18 <_stogir.conversion.validate+0xd0>
    6b08:      	uxtb	w1, w5
    6b0c:      	orr	x4, x1, xzr
    6b10:      	cmp	x4, #0x21
    6b14:      	b.lt	0x6d4c <_stogir.conversion.validate+0x404>
    6b18:      	cmp	x4, #0x27
    6b1c:      	b.gt	0x6d54 <_stogir.conversion.validate+0x40c>
    6b20:      	ldr	x4, [x0, #0x78]
    6b24:      	add	x3, x3, x4
    6b28:      	ldr	w3, [x3]
    6b2c:      	sxtw	x3, w3
    6b30:      	cmp	x3, #0x1
    6b34:      	b.ne	0x6d5c <_stogir.conversion.validate+0x414>
    6b38:      	asr	x3, x5, #32
    6b3c:      	cmp	x3, #0x0
    6b40:      	cset	w6, gt
    6b44:      	movz	x16, #0x0, lsl #48
    6b48:      	sub	x7, x16, x3
    6b4c:      	sub	x9, x7, #0x1
    6b50:      	uxtb	w16, w6
    6b54:      	cmp	w16, wzr
    6b58:      	b.eq	0x6bcc <_stogir.conversion.validate+0x284>
    6b5c:      	ldr	x7, [x0, #0x8]
    6b60:      	cmp	x3, x7
    6b64:      	b.ge	0x6c20 <_stogir.conversion.validate+0x2d8>
    6b68:      	add	x7, x0, #0x78
    6b6c:      	ldr	x7, [x7, #0x8]
    6b70:      	cmp	x3, x7
    6b74:      	b.ge	0x6cd0 <_stogir.conversion.validate+0x388>
    6b78:      	lsl	x7, x3, #2
    6b7c:      	add	x4, x4, x3, lsl #2
    6b80:      	ldr	w4, [x4]
    6b84:      	sxtw	x4, w4
    6b88:      	cmp	x4, #0x0
    6b8c:      	cset	w4, ge
    6b90:      	ubfx	x4, x4, #0, #8
    6b94:      	b	0x6cd4 <_stogir.conversion.validate+0x38c>
    6b98:      	movz	x5, #0x0, lsl #48
    6b9c:      	b	0x6a10 <_stogir.conversion.validate+0xc8>
    6ba0:      	uxtb	w0, w3
    6ba4:      	cmp	x0, #0x48
    6ba8:      	b.ne	0x6cd8 <_stogir.conversion.validate+0x390>
    6bac:      	mov	x19, x8
    6bb0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006bb0:  ARM64_RELOC_PAGE21	l_stogir.401
    6bb4:      	ldr	x16, [x16]
		0000000000006bb4:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    6bb8:      	orr	x0, x16, xzr
    6bbc:      	mov	x1, x0
    6bc0:      	mov	x0, #0x1                ; =1
    6bc4:      	mov	x2, #0x25               ; =37
    6bc8:      	b	0x6afc <_stogir.conversion.validate+0x1b4>
    6bcc:      	cmp	x3, #0x0
    6bd0:      	b.ge	0x6c28 <_stogir.conversion.validate+0x2e0>
    6bd4:      	add	x4, x0, #0x28
    6bd8:      	add	x10, x0, #0x50
    6bdc:      	ldr	x4, [x4, #0x8]
    6be0:      	ldr	x10, [x10, #0x8]
    6be4:      	cmp	x4, x10
    6be8:      	b.ne	0x6cc8 <_stogir.conversion.validate+0x380>
    6bec:      	cmp	x7, x4
    6bf0:      	b.gt	0x6d3c <_stogir.conversion.validate+0x3f4>
    6bf4:      	lsl	x4, x9, #2
    6bf8:      	ldr	x4, [x0, #0x50]
    6bfc:      	add	x4, x4, x9, lsl #2
    6c00:      	ldr	w4, [x4]
    6c04:      	sxtw	x4, w4
    6c08:      	cmp	x4, #0x0
    6c0c:      	cset	w4, gt
    6c10:      	ubfx	x4, x4, #0, #8
    6c14:      	b	0x6d40 <_stogir.conversion.validate+0x3f8>
    6c18:      	brk	#0
    6c1c:      	b	0x6c18 <_stogir.conversion.validate+0x2d0>
    6c20:      	movz	x4, #0x0, lsl #48
    6c24:      	b	0x6c2c <_stogir.conversion.validate+0x2e4>
    6c28:      	movz	x4, #0x0, lsl #48
    6c2c:      	cmp	x4, #0x0
    6c30:      	b.eq	0x6c70 <_stogir.conversion.validate+0x328>
    6c34:      	uxtb	w16, w6
    6c38:      	cmp	w16, wzr
    6c3c:      	b.eq	0x6c54 <_stogir.conversion.validate+0x30c>
    6c40:      	lsl	x4, x3, #4
    6c44:      	ldr	x0, [x0]
    6c48:      	add	x0, x0, x3, lsl #4
    6c4c:      	ldr	x0, [x0]
    6c50:      	b	0x6c64 <_stogir.conversion.validate+0x31c>
    6c54:      	lsl	x3, x9, #4
    6c58:      	ldr	x0, [x0, #0x28]
    6c5c:      	add	x0, x0, x9, lsl #4
    6c60:      	ldr	x0, [x0]
    6c64:      	mov	x3, x0
    6c68:      	mov	x0, #0x1                ; =1
    6c6c:      	b	0x6c78 <_stogir.conversion.validate+0x330>
    6c70:      	movz	x0, #0x0, lsl #48
    6c74:      	movz	x3, #0x0, lsl #48
    6c78:      	lsr	w0, w0, #0
    6c7c:      	lsr	x16, x0, #0
    6c80:      	cmp	x16, #0x1
    6c84:      	b.eq	0x6ca0 <_stogir.conversion.validate+0x358>
    6c88:      	b.lo	0x6c90 <_stogir.conversion.validate+0x348>
    6c8c:      	b	0x6ca4 <_stogir.conversion.validate+0x35c>
    6c90:      	cmp	x16, #0x0
    6c94:      	b.eq	0x6c9c <_stogir.conversion.validate+0x354>
    6c98:      	b	0x6ca4 <_stogir.conversion.validate+0x35c>
    6c9c:      	b	0x6ca8 <_stogir.conversion.validate+0x360>
    6ca0:      	b	0x6ba0 <_stogir.conversion.validate+0x258>
    6ca4:      	b	0x6d44 <_stogir.conversion.validate+0x3fc>
    6ca8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006ca8:  ARM64_RELOC_PAGE21	l_stogir.402
    6cac:      	ldr	x16, [x16]
		0000000000006cac:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    6cb0:      	orr	x0, x16, xzr
    6cb4:      	mov	x19, x8
    6cb8:      	mov	x1, x0
    6cbc:      	mov	x0, #0x1                ; =1
    6cc0:      	mov	x2, #0x19               ; =25
    6cc4:      	b	0x6bc8 <_stogir.conversion.validate+0x280>
    6cc8:      	movz	x4, #0x0, lsl #48
    6ccc:      	b	0x6c2c <_stogir.conversion.validate+0x2e4>
    6cd0:      	movz	x4, #0x0, lsl #48
    6cd4:      	b	0x6c24 <_stogir.conversion.validate+0x2dc>
    6cd8:      	cmp	x0, #0x46
    6cdc:      	b.eq	0x6d64 <_stogir.conversion.validate+0x41c>
    6ce0:      	lsr	w2, w2, #0
    6ce4:      	lsr	w5, w5, #0
    6ce8:      	lsr	w3, w3, #0
    6cec:      	lsr	w1, w1, #0
    6cf0:      	ubfx	x0, x5, #8, #8
    6cf4:      	ubfx	x3, x3, #8, #8
    6cf8:      	lsr	w0, w0, #0
    6cfc:      	lsr	w3, w3, #0
    6d00:      	mov	x19, x8
    6d04:      	add	x8, sp, #0x10
    6d08:      	fmov	s31, w0
    6d0c:      	mov	w0, w1
    6d10:      	mov	w1, w3
    6d14:      	mov	w3, w2
    6d18:      	fmov	w2, s31
    6d1c:      	bl	0x6d1c <_stogir.conversion.validate+0x3d4>
		0000000000006d1c:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    6d20:      	add	x16, sp, #0x10
    6d24:      	ldr	x0, [x16]
    6d28:      	add	x16, sp, #0x10
    6d2c:      	ldr	x1, [x16, #0x8]
    6d30:      	add	x16, sp, #0x10
    6d34:      	ldr	x2, [x16, #0x10]
    6d38:      	b	0x6bc8 <_stogir.conversion.validate+0x280>
    6d3c:      	movz	x4, #0x0, lsl #48
    6d40:      	b	0x6ccc <_stogir.conversion.validate+0x384>
    6d44:      	brk	#0
    6d48:      	b	0x6d44 <_stogir.conversion.validate+0x3fc>
    6d4c:      	mov	x19, x8
    6d50:      	b	0x6ae4 <_stogir.conversion.validate+0x19c>
    6d54:      	mov	x19, x8
    6d58:      	b	0x6ae4 <_stogir.conversion.validate+0x19c>
    6d5c:      	mov	x19, x8
    6d60:      	b	0x6ae4 <_stogir.conversion.validate+0x19c>
    6d64:      	mov	x19, x8
    6d68:      	b	0x6bb0 <_stogir.conversion.validate+0x268>

0000000000006d6c <_stogir.conditional.validate>:
    6d6c:      	sub	sp, sp, #0x40
    6d70:      	str	x29, [sp]
    6d74:      	str	x30, [sp, #0x8]
    6d78:      	mov	x29, sp
    6d7c:      	str	x19, [sp, #0x30]
    6d80:      	sxtw	x1, w1
    6d84:      	lsl	x2, x1, #2
    6d88:      	cmp	x1, #0x0
    6d8c:      	cset	w3, gt
    6d90:      	movz	x16, #0x0, lsl #48
    6d94:      	sub	x4, x16, x1
    6d98:      	sub	x5, x4, #0x1
    6d9c:      	uxtb	w16, w3
    6da0:      	cmp	w16, wzr
    6da4:      	b.eq	0x6de4 <_stogir.conditional.validate+0x78>
    6da8:      	ldr	x4, [x0, #0x8]
    6dac:      	cmp	x1, x4
    6db0:      	b.ge	0x6e38 <_stogir.conditional.validate+0xcc>
    6db4:      	add	x4, x0, #0x78
    6db8:      	ldr	x4, [x4, #0x8]
    6dbc:      	cmp	x1, x4
    6dc0:      	b.ge	0x6f4c <_stogir.conditional.validate+0x1e0>
    6dc4:      	ldr	x4, [x0, #0x78]
    6dc8:      	add	x4, x2, x4
    6dcc:      	ldr	w4, [x4]
    6dd0:      	sxtw	x4, w4
    6dd4:      	cmp	x4, #0x0
    6dd8:      	cset	w4, ge
    6ddc:      	ubfx	x4, x4, #0, #8
    6de0:      	b	0x6f50 <_stogir.conditional.validate+0x1e4>
    6de4:      	cmp	x1, #0x0
    6de8:      	b.ge	0x6e40 <_stogir.conditional.validate+0xd4>
    6dec:      	add	x6, x0, #0x28
    6df0:      	add	x7, x0, #0x50
    6df4:      	ldr	x6, [x6, #0x8]
    6df8:      	ldr	x7, [x7, #0x8]
    6dfc:      	cmp	x6, x7
    6e00:      	b.ne	0x6e30 <_stogir.conditional.validate+0xc4>
    6e04:      	cmp	x4, x6
    6e08:      	b.gt	0x6fd4 <_stogir.conditional.validate+0x268>
    6e0c:      	lsl	x4, x5, #2
    6e10:      	ldr	x4, [x0, #0x50]
    6e14:      	add	x4, x4, x5, lsl #2
    6e18:      	ldr	w4, [x4]
    6e1c:      	sxtw	x4, w4
    6e20:      	cmp	x4, #0x0
    6e24:      	cset	w4, gt
    6e28:      	ubfx	x4, x4, #0, #8
    6e2c:      	b	0x6fd8 <_stogir.conditional.validate+0x26c>
    6e30:      	movz	x4, #0x0, lsl #48
    6e34:      	b	0x6e44 <_stogir.conditional.validate+0xd8>
    6e38:      	movz	x4, #0x0, lsl #48
    6e3c:      	b	0x6e44 <_stogir.conditional.validate+0xd8>
    6e40:      	movz	x4, #0x0, lsl #48
    6e44:      	cmp	x4, #0x0
    6e48:      	b.eq	0x6eac <_stogir.conditional.validate+0x140>
    6e4c:      	uxtb	w16, w3
    6e50:      	cmp	w16, wzr
    6e54:      	b.eq	0x6e7c <_stogir.conditional.validate+0x110>
    6e58:      	lsl	x3, x1, #4
    6e5c:      	ldr	x3, [x0]
    6e60:      	add	x3, x3, x1, lsl #4
    6e64:      	ldr	x4, [x3]
    6e68:      	ldr	x3, [x3, #0x8]
    6e6c:      	fmov	d31, x3
    6e70:      	mov	x3, x4
    6e74:      	fmov	x4, d31
    6e78:      	b	0x6e9c <_stogir.conditional.validate+0x130>
    6e7c:      	lsl	x3, x5, #4
    6e80:      	ldr	x3, [x0, #0x28]
    6e84:      	add	x3, x3, x5, lsl #4
    6e88:      	ldr	x4, [x3]
    6e8c:      	ldr	x3, [x3, #0x8]
    6e90:      	fmov	d31, x3
    6e94:      	mov	x3, x4
    6e98:      	fmov	x4, d31
    6e9c:      	mov	x5, x4
    6ea0:      	mov	x4, x3
    6ea4:      	mov	x3, #0x1                ; =1
    6ea8:      	b	0x6eb8 <_stogir.conditional.validate+0x14c>
    6eac:      	movz	x3, #0x0, lsl #48
    6eb0:      	movz	x4, #0x0, lsl #48
    6eb4:      	movz	x5, #0x0, lsl #48
    6eb8:      	lsr	w3, w3, #0
    6ebc:      	lsr	x16, x3, #0
    6ec0:      	cmp	x16, #0x1
    6ec4:      	b.eq	0x6ee0 <_stogir.conditional.validate+0x174>
    6ec8:      	b.lo	0x6ed0 <_stogir.conditional.validate+0x164>
    6ecc:      	b	0x6ee4 <_stogir.conditional.validate+0x178>
    6ed0:      	cmp	x16, #0x0
    6ed4:      	b.eq	0x6edc <_stogir.conditional.validate+0x170>
    6ed8:      	b	0x6ee4 <_stogir.conditional.validate+0x178>
    6edc:      	b	0x6ee8 <_stogir.conditional.validate+0x17c>
    6ee0:      	b	0x6f08 <_stogir.conditional.validate+0x19c>
    6ee4:      	b	0x6fdc <_stogir.conditional.validate+0x270>
    6ee8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006ee8:  ARM64_RELOC_PAGE21	l_stogir.403
    6eec:      	ldr	x16, [x16]
		0000000000006eec:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    6ef0:      	orr	x0, x16, xzr
    6ef4:      	mov	x19, x8
    6ef8:      	mov	x1, x0
    6efc:      	mov	x0, #0x1                ; =1
    6f00:      	mov	x2, #0x18               ; =24
    6f04:      	b	0x6f2c <_stogir.conditional.validate+0x1c0>
    6f08:      	cmp	x1, #0x0
    6f0c:      	b.gt	0x6f54 <_stogir.conditional.validate+0x1e8>
    6f10:      	mov	x19, x8
    6f14:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x51c>
		0000000000006f14:  ARM64_RELOC_PAGE21	l_stogir.404
    6f18:      	ldr	x16, [x16]
		0000000000006f18:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    6f1c:      	orr	x0, x16, xzr
    6f20:      	mov	x1, x0
    6f24:      	mov	x0, #0x1                ; =1
    6f28:      	mov	x2, #0x18               ; =24
    6f2c:      	str	x0, [x19]
    6f30:      	str	x1, [x19, #0x8]
    6f34:      	str	x2, [x19, #0x10]
    6f38:      	ldr	x19, [sp, #0x30]
    6f3c:      	ldr	x29, [sp]
    6f40:      	ldr	x30, [sp, #0x8]
    6f44:      	add	sp, sp, #0x40
    6f48:      	ret
    6f4c:      	movz	x4, #0x0, lsl #48
    6f50:      	b	0x6e3c <_stogir.conditional.validate+0xd0>
    6f54:      	uxtb	w1, w4
    6f58:      	cmp	x1, #0x3c
    6f5c:      	b.ne	0x6fe4 <_stogir.conditional.validate+0x278>
    6f60:      	ldr	x1, [x0, #0x78]
    6f64:      	add	x1, x2, x1
    6f68:      	ldr	w1, [x1]
    6f6c:      	sxtw	x1, w1
    6f70:      	cmp	x1, #0x3
    6f74:      	b.ne	0x6fec <_stogir.conditional.validate+0x280>
    6f78:      	lsr	w1, w5, #0
    6f7c:      	lsr	w2, w4, #0
    6f80:      	lsr	x3, x4, #32
    6f84:      	lsr	w1, w1, #0
    6f88:      	lsr	x4, x5, #32
    6f8c:      	lsr	w3, w3, #0
    6f90:      	lsr	w4, w4, #0
    6f94:      	ubfx	x2, x2, #8, #8
    6f98:      	lsr	w2, w2, #0
    6f9c:      	mov	x19, x8
    6fa0:      	add	x8, sp, #0x10
    6fa4:      	fmov	s31, w1
    6fa8:      	mov	w1, w2
    6fac:      	mov	w2, w3
    6fb0:      	fmov	w3, s31
    6fb4:      	bl	0x6fb4 <_stogir.conditional.validate+0x248>
		0000000000006fb4:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    6fb8:      	add	x16, sp, #0x10
    6fbc:      	ldr	x0, [x16]
    6fc0:      	add	x16, sp, #0x10
    6fc4:      	ldr	x1, [x16, #0x8]
    6fc8:      	add	x16, sp, #0x10
    6fcc:      	ldr	x2, [x16, #0x10]
    6fd0:      	b	0x6f2c <_stogir.conditional.validate+0x1c0>
    6fd4:      	movz	x4, #0x0, lsl #48
    6fd8:      	b	0x6e34 <_stogir.conditional.validate+0xc8>
    6fdc:      	brk	#0
    6fe0:      	b	0x6fdc <_stogir.conditional.validate+0x270>
    6fe4:      	mov	x19, x8
    6fe8:      	b	0x6f14 <_stogir.conditional.validate+0x1a8>
    6fec:      	mov	x19, x8
    6ff0:      	b	0x6f14 <_stogir.conditional.validate+0x1a8>

0000000000006ff4 <_stogir.floating.validate>:
    6ff4:      	sub	sp, sp, #0x50
    6ff8:      	str	x29, [sp]
    6ffc:      	str	x30, [sp, #0x8]
    7000:      	mov	x29, sp
    7004:      	str	x19, [sp, #0x40]
    7008:      	sxtw	x1, w1
    700c:      	lsl	x2, x1, #2
    7010:      	cmp	x1, #0x0
    7014:      	cset	w3, gt
    7018:      	movz	x16, #0x0, lsl #48
    701c:      	sub	x4, x16, x1
    7020:      	sub	x5, x4, #0x1
    7024:      	uxtb	w16, w3
    7028:      	cmp	w16, wzr
    702c:      	b.eq	0x706c <_stogir.floating.validate+0x78>
    7030:      	ldr	x4, [x0, #0x8]
    7034:      	cmp	x1, x4
    7038:      	b.ge	0x70c0 <_stogir.floating.validate+0xcc>
    703c:      	add	x4, x0, #0x78
    7040:      	ldr	x4, [x4, #0x8]
    7044:      	cmp	x1, x4
    7048:      	b.ge	0x71e4 <_stogir.floating.validate+0x1f0>
    704c:      	ldr	x4, [x0, #0x78]
    7050:      	add	x4, x2, x4
    7054:      	ldr	w4, [x4]
    7058:      	sxtw	x4, w4
    705c:      	cmp	x4, #0x0
    7060:      	cset	w4, ge
    7064:      	ubfx	x4, x4, #0, #8
    7068:      	b	0x71e8 <_stogir.floating.validate+0x1f4>
    706c:      	cmp	x1, #0x0
    7070:      	b.ge	0x70c8 <_stogir.floating.validate+0xd4>
    7074:      	add	x6, x0, #0x28
    7078:      	add	x7, x0, #0x50
    707c:      	ldr	x6, [x6, #0x8]
    7080:      	ldr	x7, [x7, #0x8]
    7084:      	cmp	x6, x7
    7088:      	b.ne	0x70b8 <_stogir.floating.validate+0xc4>
    708c:      	cmp	x4, x6
    7090:      	b.gt	0x7270 <_stogir.floating.validate+0x27c>
    7094:      	lsl	x4, x5, #2
    7098:      	ldr	x4, [x0, #0x50]
    709c:      	add	x4, x4, x5, lsl #2
    70a0:      	ldr	w4, [x4]
    70a4:      	sxtw	x4, w4
    70a8:      	cmp	x4, #0x0
    70ac:      	cset	w4, gt
    70b0:      	ubfx	x4, x4, #0, #8
    70b4:      	b	0x7274 <_stogir.floating.validate+0x280>
    70b8:      	movz	x4, #0x0, lsl #48
    70bc:      	b	0x70cc <_stogir.floating.validate+0xd8>
    70c0:      	movz	x4, #0x0, lsl #48
    70c4:      	b	0x70cc <_stogir.floating.validate+0xd8>
    70c8:      	movz	x4, #0x0, lsl #48
    70cc:      	cmp	x4, #0x0
    70d0:      	b.eq	0x7134 <_stogir.floating.validate+0x140>
    70d4:      	uxtb	w16, w3
    70d8:      	cmp	w16, wzr
    70dc:      	b.eq	0x7104 <_stogir.floating.validate+0x110>
    70e0:      	lsl	x3, x1, #4
    70e4:      	ldr	x3, [x0]
    70e8:      	add	x3, x3, x1, lsl #4
    70ec:      	ldr	x4, [x3]
    70f0:      	ldr	x3, [x3, #0x8]
    70f4:      	fmov	d31, x3
    70f8:      	mov	x3, x4
    70fc:      	fmov	x4, d31
    7100:      	b	0x7124 <_stogir.floating.validate+0x130>
    7104:      	lsl	x3, x5, #4
    7108:      	ldr	x3, [x0, #0x28]
    710c:      	add	x3, x3, x5, lsl #4
    7110:      	ldr	x4, [x3]
    7114:      	ldr	x3, [x3, #0x8]
    7118:      	fmov	d31, x3
    711c:      	mov	x3, x4
    7120:      	fmov	x4, d31
    7124:      	mov	x5, x4
    7128:      	mov	x4, x3
    712c:      	mov	x3, #0x1                ; =1
    7130:      	b	0x7140 <_stogir.floating.validate+0x14c>
    7134:      	movz	x3, #0x0, lsl #48
    7138:      	movz	x4, #0x0, lsl #48
    713c:      	movz	x5, #0x0, lsl #48
    7140:      	lsr	w3, w3, #0
    7144:      	lsr	x16, x3, #0
    7148:      	cmp	x16, #0x1
    714c:      	b.eq	0x7168 <_stogir.floating.validate+0x174>
    7150:      	b.lo	0x7158 <_stogir.floating.validate+0x164>
    7154:      	b	0x716c <_stogir.floating.validate+0x178>
    7158:      	cmp	x16, #0x0
    715c:      	b.eq	0x7164 <_stogir.floating.validate+0x170>
    7160:      	b	0x716c <_stogir.floating.validate+0x178>
    7164:      	b	0x7170 <_stogir.floating.validate+0x17c>
    7168:      	b	0x71ac <_stogir.floating.validate+0x1b8>
    716c:      	b	0x752c <_stogir.floating.validate+0x538>
    7170:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xc>
		0000000000007170:  ARM64_RELOC_PAGE21	l_stogir.405
    7174:      	ldr	x16, [x16]
		0000000000007174:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    7178:      	orr	x0, x16, xzr
    717c:      	mov	x19, x8
    7180:      	mov	x1, x0
    7184:      	mov	x0, #0x1                ; =1
    7188:      	mov	x2, #0x1c               ; =28
    718c:      	str	x0, [x19]
    7190:      	str	x1, [x19, #0x8]
    7194:      	str	x2, [x19, #0x10]
    7198:      	ldr	x19, [sp, #0x40]
    719c:      	ldr	x29, [sp]
    71a0:      	ldr	x30, [sp, #0x8]
    71a4:      	add	sp, sp, #0x50
    71a8:      	ret
    71ac:      	add	x16, sp, #0x10
    71b0:      	str	x4, [x16]
    71b4:      	add	x16, sp, #0x10
    71b8:      	str	x5, [x16, #0x8]
    71bc:      	cmp	x1, #0x0
    71c0:      	b.gt	0x71ec <_stogir.floating.validate+0x1f8>
    71c4:      	mov	x19, x8
    71c8:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xc>
		00000000000071c8:  ARM64_RELOC_PAGE21	l_stogir.406
    71cc:      	ldr	x16, [x16]
		00000000000071cc:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    71d0:      	orr	x0, x16, xzr
    71d4:      	mov	x1, x0
    71d8:      	mov	x0, #0x1                ; =1
    71dc:      	mov	x2, #0x1c               ; =28
    71e0:      	b	0x718c <_stogir.floating.validate+0x198>
    71e4:      	movz	x4, #0x0, lsl #48
    71e8:      	b	0x70c4 <_stogir.floating.validate+0xd0>
    71ec:      	uxtb	w4, w4
    71f0:      	orr	x1, x4, xzr
    71f4:      	cmp	x1, #0xe
    71f8:      	cset	w3, ge
    71fc:      	cmp	x1, #0x19
    7200:      	cset	w5, le
    7204:      	cmp	x1, #0x1f
    7208:      	cset	w6, eq
    720c:      	cmp	x1, #0x20
    7210:      	cset	w7, eq
    7214:      	uxtb	w16, w3
    7218:      	cmp	w16, wzr
    721c:      	b.eq	0x7278 <_stogir.floating.validate+0x284>
    7220:      	uxtb	w16, w5
    7224:      	cmp	w16, wzr
    7228:      	b.eq	0x7278 <_stogir.floating.validate+0x284>
    722c:      	cmp	x1, #0x1d
    7230:      	cset	w1, eq
    7234:      	ldr	x9, [x0, #0x78]
    7238:      	add	x2, x2, x9
    723c:      	ldr	w2, [x2]
    7240:      	uxtb	w16, w6
    7244:      	cmp	w16, wzr
    7248:      	b.ne	0x72b8 <_stogir.floating.validate+0x2c4>
    724c:      	uxtb	w16, w7
    7250:      	cmp	w16, wzr
    7254:      	b.ne	0x72b8 <_stogir.floating.validate+0x2c4>
    7258:      	uxtb	w16, w1
    725c:      	cmp	w16, wzr
    7260:      	mov	x16, #0x3               ; =3
    7264:      	mov	x17, #0x2               ; =2
    7268:      	csel	x6, x16, x17, ne
    726c:      	b	0x72bc <_stogir.floating.validate+0x2c8>
    7270:      	movz	x4, #0x0, lsl #48
    7274:      	b	0x70bc <_stogir.floating.validate+0xc8>
    7278:      	uxtb	w16, w6
    727c:      	cmp	w16, wzr
    7280:      	b.ne	0x722c <_stogir.floating.validate+0x238>
    7284:      	uxtb	w16, w7
    7288:      	cmp	w16, wzr
    728c:      	b.ne	0x722c <_stogir.floating.validate+0x238>
    7290:      	cmp	x1, #0x1a
    7294:      	b.lt	0x72a0 <_stogir.floating.validate+0x2ac>
    7298:      	cmp	x1, #0x1d
    729c:      	b.le	0x722c <_stogir.floating.validate+0x238>
    72a0:      	cmp	x1, #0x3a
    72a4:      	b.eq	0x722c <_stogir.floating.validate+0x238>
    72a8:      	cmp	x1, #0x3b
    72ac:      	b.eq	0x722c <_stogir.floating.validate+0x238>
    72b0:      	mov	x19, x8
    72b4:      	b	0x71c8 <_stogir.floating.validate+0x1d4>
    72b8:      	mov	x6, #0x1                ; =1
    72bc:      	sxtw	x2, w2
    72c0:      	lsr	w6, w6, #0
    72c4:      	sxtw	x6, w6
    72c8:      	cmp	x2, x6
    72cc:      	b.ne	0x753c <_stogir.floating.validate+0x548>
    72d0:      	add	x16, sp, #0x10
    72d4:      	ldr	w2, [x16, #0x4]
    72d8:      	sxtw	x2, w2
    72dc:      	cmp	x2, #0x0
    72e0:      	cset	w6, gt
    72e4:      	movz	x16, #0x0, lsl #48
    72e8:      	sub	x7, x16, x2
    72ec:      	sub	x9, x7, #0x1
    72f0:      	uxtb	w16, w6
    72f4:      	cmp	w16, wzr
    72f8:      	b.eq	0x7358 <_stogir.floating.validate+0x364>
    72fc:      	ldr	x7, [x0, #0x8]
    7300:      	cmp	x2, x7
    7304:      	b.ge	0x73a4 <_stogir.floating.validate+0x3b0>
    7308:      	add	x7, x0, #0x78
    730c:      	ldr	x7, [x7, #0x8]
    7310:      	cmp	x2, x7
    7314:      	b.ge	0x7484 <_stogir.floating.validate+0x490>
    7318:      	lsl	x7, x2, #2
    731c:      	ldr	x7, [x0, #0x78]
    7320:      	add	x7, x7, x2, lsl #2
    7324:      	ldr	w7, [x7]
    7328:      	sxtw	x7, w7
    732c:      	cmp	x7, #0x0
    7330:      	cset	w7, ge
    7334:      	ubfx	x7, x7, #0, #8
    7338:      	b	0x7488 <_stogir.floating.validate+0x494>
    733c:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xc>
		000000000000733c:  ARM64_RELOC_PAGE21	l_stogir.407
    7340:      	ldr	x16, [x16]
		0000000000007340:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    7344:      	orr	x0, x16, xzr
    7348:      	mov	x1, x0
    734c:      	mov	x0, #0x1                ; =1
    7350:      	mov	x2, #0x1d               ; =29
    7354:      	b	0x71e0 <_stogir.floating.validate+0x1ec>
    7358:      	cmp	x2, #0x0
    735c:      	b.ge	0x73ac <_stogir.floating.validate+0x3b8>
    7360:      	add	x10, x0, #0x28
    7364:      	add	x11, x0, #0x50
    7368:      	ldr	x10, [x10, #0x8]
    736c:      	ldr	x11, [x11, #0x8]
    7370:      	cmp	x10, x11
    7374:      	b.ne	0x747c <_stogir.floating.validate+0x488>
    7378:      	cmp	x7, x10
    737c:      	b.gt	0x7524 <_stogir.floating.validate+0x530>
    7380:      	lsl	x7, x9, #2
    7384:      	ldr	x7, [x0, #0x50]
    7388:      	add	x7, x7, x9, lsl #2
    738c:      	ldr	w7, [x7]
    7390:      	sxtw	x7, w7
    7394:      	cmp	x7, #0x0
    7398:      	cset	w7, gt
    739c:      	ubfx	x7, x7, #0, #8
    73a0:      	b	0x7528 <_stogir.floating.validate+0x534>
    73a4:      	movz	x7, #0x0, lsl #48
    73a8:      	b	0x73b0 <_stogir.floating.validate+0x3bc>
    73ac:      	movz	x7, #0x0, lsl #48
    73b0:      	cmp	x7, #0x0
    73b4:      	b.eq	0x73f4 <_stogir.floating.validate+0x400>
    73b8:      	uxtb	w16, w6
    73bc:      	cmp	w16, wzr
    73c0:      	b.eq	0x73d8 <_stogir.floating.validate+0x3e4>
    73c4:      	lsl	x6, x2, #4
    73c8:      	ldr	x6, [x0]
    73cc:      	add	x2, x6, x2, lsl #4
    73d0:      	ldr	x2, [x2]
    73d4:      	b	0x73e8 <_stogir.floating.validate+0x3f4>
    73d8:      	lsl	x2, x9, #4
    73dc:      	ldr	x2, [x0, #0x28]
    73e0:      	add	x2, x2, x9, lsl #4
    73e4:      	ldr	x2, [x2]
    73e8:      	mov	x6, x2
    73ec:      	mov	x2, #0x1                ; =1
    73f0:      	b	0x73fc <_stogir.floating.validate+0x408>
    73f4:      	movz	x2, #0x0, lsl #48
    73f8:      	movz	x6, #0x0, lsl #48
    73fc:      	lsr	w2, w2, #0
    7400:      	lsr	x16, x2, #0
    7404:      	cmp	x16, #0x1
    7408:      	b.eq	0x7424 <_stogir.floating.validate+0x430>
    740c:      	b.lo	0x7414 <_stogir.floating.validate+0x420>
    7410:      	b	0x7428 <_stogir.floating.validate+0x434>
    7414:      	cmp	x16, #0x0
    7418:      	b.eq	0x7420 <_stogir.floating.validate+0x42c>
    741c:      	b	0x7428 <_stogir.floating.validate+0x434>
    7420:      	b	0x742c <_stogir.floating.validate+0x438>
    7424:      	b	0x744c <_stogir.floating.validate+0x458>
    7428:      	b	0x7534 <_stogir.floating.validate+0x540>
    742c:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xc>
		000000000000742c:  ARM64_RELOC_PAGE21	l_stogir.408
    7430:      	ldr	x16, [x16]
		0000000000007430:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    7434:      	orr	x0, x16, xzr
    7438:      	mov	x19, x8
    743c:      	mov	x1, x0
    7440:      	mov	x0, #0x1                ; =1
    7444:      	mov	x2, #0x18               ; =24
    7448:      	b	0x7354 <_stogir.floating.validate+0x360>
    744c:      	lsr	w6, w6, #0
    7450:      	add	x16, sp, #0x10
    7454:      	ldr	w2, [x16]
    7458:      	ubfx	x6, x6, #8, #8
    745c:      	uxtb	w16, w3
    7460:      	cmp	w16, wzr
    7464:      	b.eq	0x74e0 <_stogir.floating.validate+0x4ec>
    7468:      	uxtb	w16, w5
    746c:      	cmp	w16, wzr
    7470:      	b.eq	0x74e0 <_stogir.floating.validate+0x4ec>
    7474:      	mov	x3, #0x1                ; =1
    7478:      	b	0x74e4 <_stogir.floating.validate+0x4f0>
    747c:      	movz	x7, #0x0, lsl #48
    7480:      	b	0x73b0 <_stogir.floating.validate+0x3bc>
    7484:      	movz	x7, #0x0, lsl #48
    7488:      	b	0x73a8 <_stogir.floating.validate+0x3b4>
    748c:      	movz	x1, #0x0, lsl #48
    7490:      	lsr	w2, w2, #0
    7494:      	lsr	w3, w3, #0
    7498:      	lsr	w4, w4, #0
    749c:      	lsr	w6, w6, #0
    74a0:      	lsr	w1, w1, #0
    74a4:      	mov	w5, w1
    74a8:      	mov	w1, w4
    74ac:      	mov	w4, w3
    74b0:      	mov	w3, w2
    74b4:      	mov	w2, w6
    74b8:      	mov	x19, x8
    74bc:      	add	x8, sp, #0x20
    74c0:      	bl	0x74c0 <_stogir.floating.validate+0x4cc>
		00000000000074c0:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    74c4:      	add	x16, sp, #0x20
    74c8:      	ldr	x0, [x16]
    74cc:      	add	x16, sp, #0x20
    74d0:      	ldr	x1, [x16, #0x8]
    74d4:      	add	x16, sp, #0x20
    74d8:      	ldr	x2, [x16, #0x10]
    74dc:      	b	0x7354 <_stogir.floating.validate+0x360>
    74e0:      	orr	x3, x6, xzr
    74e4:      	lsr	w3, w3, #0
    74e8:      	ubfx	x2, x2, #8, #8
    74ec:      	sxtw	x3, w3
    74f0:      	cmp	x2, x3
    74f4:      	b.ne	0x7544 <_stogir.floating.validate+0x550>
    74f8:      	add	x16, sp, #0x10
    74fc:      	ldr	w2, [x16, #0x4]
    7500:      	add	x16, sp, #0x10
    7504:      	ldr	w3, [x16, #0x8]
    7508:      	uxtb	w16, w1
    750c:      	cmp	w16, wzr
    7510:      	b.eq	0x748c <_stogir.floating.validate+0x498>
    7514:      	add	x16, sp, #0x10
    7518:      	ldr	w1, [x16, #0xc]
    751c:      	sxtw	x1, w1
    7520:      	b	0x7490 <_stogir.floating.validate+0x49c>
    7524:      	movz	x7, #0x0, lsl #48
    7528:      	b	0x7480 <_stogir.floating.validate+0x48c>
    752c:      	brk	#0
    7530:      	b	0x752c <_stogir.floating.validate+0x538>
    7534:      	brk	#0
    7538:      	b	0x7534 <_stogir.floating.validate+0x540>
    753c:      	mov	x19, x8
    7540:      	b	0x71c8 <_stogir.floating.validate+0x1d4>
    7544:      	mov	x19, x8
    7548:      	b	0x733c <_stogir.floating.validate+0x348>

000000000000754c <_stogir.types.integer?>:
    754c:      	sxtw	x0, w0
    7550:      	cmp	x0, #0x1
    7554:      	b.lt	0x7568 <_stogir.types.integer?+0x1c>
    7558:      	cmp	x0, #0xb
    755c:      	cset	w0, le
    7560:      	ubfx	x0, x0, #0, #8
    7564:      	b	0x756c <_stogir.types.integer?+0x20>
    7568:      	movz	x0, #0x0, lsl #48
    756c:      	ret

0000000000007570 <_stogir.integer-unary.valid-type?>:
    7570:      	sxtw	x0, w0
    7574:      	cmp	x0, #0x2d
    7578:      	cset	w2, eq
    757c:      	cmp	x0, #0x1f
    7580:      	cset	w3, eq
    7584:      	cmp	x0, #0x20
    7588:      	cset	w4, eq
    758c:      	cmp	x0, #0x36
    7590:      	cset	w5, eq
    7594:      	uxtb	w16, w3
    7598:      	cmp	w16, wzr
    759c:      	b.ne	0x75e4 <_stogir.integer-unary.valid-type?+0x74>
    75a0:      	uxtb	w16, w4
    75a4:      	cmp	w16, wzr
    75a8:      	b.ne	0x75e4 <_stogir.integer-unary.valid-type?+0x74>
    75ac:      	uxtb	w16, w2
    75b0:      	cmp	w16, wzr
    75b4:      	b.ne	0x75e4 <_stogir.integer-unary.valid-type?+0x74>
    75b8:      	uxtb	w16, w5
    75bc:      	cmp	w16, wzr
    75c0:      	b.ne	0x75e4 <_stogir.integer-unary.valid-type?+0x74>
    75c4:      	cmp	x0, #0x37
    75c8:      	b.eq	0x75e4 <_stogir.integer-unary.valid-type?+0x74>
    75cc:      	cmp	x0, #0x38
    75d0:      	b.eq	0x75e4 <_stogir.integer-unary.valid-type?+0x74>
    75d4:      	cmp	x0, #0x39
    75d8:      	b.eq	0x75e4 <_stogir.integer-unary.valid-type?+0x74>
    75dc:      	movz	x0, #0x0, lsl #48
    75e0:      	b	0x761c <_stogir.integer-unary.valid-type?+0xac>
    75e4:      	sxtw	x1, w1
    75e8:      	cmp	x1, #0x1
    75ec:      	b.lt	0x7618 <_stogir.integer-unary.valid-type?+0xa8>
    75f0:      	cmp	x1, #0xb
    75f4:      	cset	w0, le
    75f8:      	uxtb	w16, w0
    75fc:      	cmp	w16, wzr
    7600:      	b.eq	0x7618 <_stogir.integer-unary.valid-type?+0xa8>
    7604:      	uxtb	w16, w2
    7608:      	cmp	w16, wzr
    760c:      	b.eq	0x7628 <_stogir.integer-unary.valid-type?+0xb8>
    7610:      	mov	x0, #0x1                ; =1
    7614:      	b	0x7624 <_stogir.integer-unary.valid-type?+0xb4>
    7618:      	movz	x0, #0x0, lsl #48
    761c:      	ret
    7620:      	mov	x0, #0x1                ; =1
    7624:      	b	0x761c <_stogir.integer-unary.valid-type?+0xac>
    7628:      	cmp	x1, #0x1
    762c:      	b.ne	0x7638 <_stogir.integer-unary.valid-type?+0xc8>
    7630:      	movz	x0, #0x0, lsl #48
    7634:      	b	0x7624 <_stogir.integer-unary.valid-type?+0xb4>
    7638:      	cmp	x1, #0x6
    763c:      	cset	w2, eq
    7640:      	uxtb	w16, w3
    7644:      	cmp	w16, wzr
    7648:      	b.eq	0x765c <_stogir.integer-unary.valid-type?+0xec>
    764c:      	uxtb	w16, w2
    7650:      	cmp	w16, wzr
    7654:      	cset	x0, eq
    7658:      	b	0x7624 <_stogir.integer-unary.valid-type?+0xb4>
    765c:      	uxtb	w16, w4
    7660:      	cmp	w16, wzr
    7664:      	b.eq	0x7680 <_stogir.integer-unary.valid-type?+0x110>
    7668:      	cmp	x1, #0x7
    766c:      	b.lt	0x7678 <_stogir.integer-unary.valid-type?+0x108>
    7670:      	ubfx	x0, x0, #0, #8
    7674:      	b	0x767c <_stogir.integer-unary.valid-type?+0x10c>
    7678:      	movz	x0, #0x0, lsl #48
    767c:      	b	0x7624 <_stogir.integer-unary.valid-type?+0xb4>
    7680:      	uxtb	w16, w5
    7684:      	cmp	w16, wzr
    7688:      	b.eq	0x7620 <_stogir.integer-unary.valid-type?+0xb0>
    768c:      	cmp	x1, #0x3
    7690:      	b.ne	0x76ac <_stogir.integer-unary.valid-type?+0x13c>
    7694:      	mov	x0, #0x1                ; =1
    7698:      	b	0x76a8 <_stogir.integer-unary.valid-type?+0x138>
    769c:      	cmp	x1, #0xb
    76a0:      	cset	w0, eq
    76a4:      	ubfx	x0, x0, #0, #8
    76a8:      	b	0x7624 <_stogir.integer-unary.valid-type?+0xb4>
    76ac:      	cmp	x1, #0x4
    76b0:      	b.ne	0x76bc <_stogir.integer-unary.valid-type?+0x14c>
    76b4:      	mov	x0, #0x1                ; =1
    76b8:      	b	0x76a8 <_stogir.integer-unary.valid-type?+0x138>
    76bc:      	cmp	x1, #0x5
    76c0:      	b.ne	0x76cc <_stogir.integer-unary.valid-type?+0x15c>
    76c4:      	mov	x0, #0x1                ; =1
    76c8:      	b	0x76a8 <_stogir.integer-unary.valid-type?+0x138>
    76cc:      	uxtb	w16, w2
    76d0:      	cmp	w16, wzr
    76d4:      	b.eq	0x76e0 <_stogir.integer-unary.valid-type?+0x170>
    76d8:      	mov	x0, #0x1                ; =1
    76dc:      	b	0x76a8 <_stogir.integer-unary.valid-type?+0x138>
    76e0:      	cmp	x1, #0x9
    76e4:      	b.ne	0x76f0 <_stogir.integer-unary.valid-type?+0x180>
    76e8:      	mov	x0, #0x1                ; =1
    76ec:      	b	0x76a8 <_stogir.integer-unary.valid-type?+0x138>
    76f0:      	cmp	x1, #0xa
    76f4:      	b.ne	0x769c <_stogir.integer-unary.valid-type?+0x12c>
    76f8:      	mov	x0, #0x1                ; =1
    76fc:      	b	0x76a8 <_stogir.integer-unary.valid-type?+0x138>

0000000000007700 <_stogir.integer-binary.valid-type?>:
    7700:      	sxtw	x0, w0
    7704:      	cmp	x0, #0x3a
    7708:      	cset	w2, eq
    770c:      	cmp	x0, #0x3b
    7710:      	cset	w3, eq
    7714:      	cmp	x0, #0x1a
    7718:      	b.lt	0x776c <_stogir.integer-binary.valid-type?+0x6c>
    771c:      	cmp	x0, #0x1e
    7720:      	b.gt	0x776c <_stogir.integer-binary.valid-type?+0x6c>
    7724:      	sxtw	x1, w1
    7728:      	cmp	x1, #0x1
    772c:      	b.lt	0x779c <_stogir.integer-binary.valid-type?+0x9c>
    7730:      	cmp	x1, #0xb
    7734:      	b.gt	0x779c <_stogir.integer-binary.valid-type?+0x9c>
    7738:      	cmp	x1, #0x1
    773c:      	b.ne	0x77a4 <_stogir.integer-binary.valid-type?+0xa4>
    7740:      	cmp	x0, #0x2e
    7744:      	b.eq	0x77ac <_stogir.integer-binary.valid-type?+0xac>
    7748:      	cmp	x0, #0x2f
    774c:      	b.eq	0x77ac <_stogir.integer-binary.valid-type?+0xac>
    7750:      	cmp	x0, #0x30
    7754:      	b.eq	0x77ac <_stogir.integer-binary.valid-type?+0xac>
    7758:      	uxtb	w16, w2
    775c:      	cmp	w16, wzr
    7760:      	b.eq	0x77b4 <_stogir.integer-binary.valid-type?+0xb4>
    7764:      	mov	x0, #0x1                ; =1
    7768:      	b	0x77bc <_stogir.integer-binary.valid-type?+0xbc>
    776c:      	cmp	x0, #0x2e
    7770:      	b.lt	0x777c <_stogir.integer-binary.valid-type?+0x7c>
    7774:      	cmp	x0, #0x35
    7778:      	b.le	0x7724 <_stogir.integer-binary.valid-type?+0x24>
    777c:      	uxtb	w16, w2
    7780:      	cmp	w16, wzr
    7784:      	b.ne	0x7724 <_stogir.integer-binary.valid-type?+0x24>
    7788:      	uxtb	w16, w3
    778c:      	cmp	w16, wzr
    7790:      	b.ne	0x7724 <_stogir.integer-binary.valid-type?+0x24>
    7794:      	movz	x0, #0x0, lsl #48
    7798:      	b	0x77a0 <_stogir.integer-binary.valid-type?+0xa0>
    779c:      	movz	x0, #0x0, lsl #48
    77a0:      	ret
    77a4:      	mov	x0, #0x1                ; =1
    77a8:      	b	0x77a0 <_stogir.integer-binary.valid-type?+0xa0>
    77ac:      	mov	x0, #0x1                ; =1
    77b0:      	b	0x77a8 <_stogir.integer-binary.valid-type?+0xa8>
    77b4:      	ubfx	x3, x3, #0, #8
    77b8:      	mov	x0, x3
    77bc:      	b	0x77b0 <_stogir.integer-binary.valid-type?+0xb0>

00000000000077c0 <_coil.core.Len$slice$len__u8>:
    77c0:      	mov	x0, x1
    77c4:      	ret

00000000000077c8 <_inherent$slice$data__u8>:
    77c8:      	ret

00000000000077cc <_coil.mem.eql__u8>:
    77cc:      	sub	sp, sp, #0x10
    77d0:      	str	x29, [sp]
    77d4:      	str	x30, [sp, #0x8]
    77d8:      	mov	x29, sp
    77dc:      	cmp	x2, #0x0
    77e0:      	b.ne	0x77ec <_coil.mem.eql__u8+0x20>
    77e4:      	mov	x0, #0x1                ; =1
    77e8:      	b	0x7808 <_coil.mem.eql__u8+0x3c>
    77ec:      	lsr	x2, x2, #0
    77f0:      	bl	0x77f0 <_coil.mem.eql__u8+0x24>
		00000000000077f0:  ARM64_RELOC_BRANCH26	_memcmp
    77f4:      	lsr	w0, w0, #0
    77f8:      	sxtw	x0, w0
    77fc:      	cmp	x0, #0x0
    7800:      	cset	w0, eq
    7804:      	ubfx	x0, x0, #0, #8
    7808:      	ldr	x29, [sp]
    780c:      	ldr	x30, [sp, #0x8]
    7810:      	add	sp, sp, #0x10
    7814:      	ret

0000000000007818 <_stogir.opcode.count>:
    7818:      	mov	x0, #0x83               ; =131
    781c:      	ret

0000000000007820 <_stogir.types.valid-scalar?>:
    7820:      	sxtw	x0, w0
    7824:      	cmp	x0, #0x0
    7828:      	b.lt	0x783c <_stogir.types.valid-scalar?+0x1c>
    782c:      	cmp	x0, #0xd
    7830:      	cset	w0, le
    7834:      	ubfx	x0, x0, #0, #8
    7838:      	b	0x7840 <_stogir.types.valid-scalar?+0x20>
    783c:      	movz	x0, #0x0, lsl #48
    7840:      	ret

0000000000007844 <_stogir.types.vector?>:
    7844:      	sxtw	x0, w0
    7848:      	cmp	x0, #0xf
    784c:      	b.le	0x7888 <_stogir.types.vector?+0x44>
    7850:      	cmp	x0, #0x80
    7854:      	b.ge	0x7898 <_stogir.types.vector?+0x54>
    7858:      	and	x1, x0, #0xf
    785c:      	lsr	w1, w1, #0
    7860:      	sxtw	x1, w1
    7864:      	cmp	x1, #0x1
    7868:      	b.lt	0x7890 <_stogir.types.vector?+0x4c>
    786c:      	and	x0, x0, #0xf
    7870:      	lsr	w0, w0, #0
    7874:      	sxtw	x0, w0
    7878:      	cmp	x0, #0xd
    787c:      	cset	w0, le
    7880:      	ubfx	x0, x0, #0, #8
    7884:      	b	0x7894 <_stogir.types.vector?+0x50>
    7888:      	movz	x0, #0x0, lsl #48
    788c:      	b	0x7894 <_stogir.types.vector?+0x50>
    7890:      	movz	x0, #0x0, lsl #48
    7894:      	ret
    7898:      	movz	x0, #0x0, lsl #48
    789c:      	b	0x7894 <_stogir.types.vector?+0x50>

00000000000078a0 <_coil.core.Get$slice$get__i8>:
    78a0:      	lsr	x1, x2, #0
    78a4:      	add	x0, x0, x2
    78a8:      	ldrsb	w0, [x0]
    78ac:      	sxtb	x0, w0
    78b0:      	ret

00000000000078b4 <_stogir.opcode.metadata>:
    78b4:      	sub	sp, sp, #0x10
    78b8:      	mov	x0, sp
    78bc:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xc>
		00000000000078bc:  ARM64_RELOC_PAGE21	l_stogir.409
    78c0:      	ldr	x16, [x16]
		00000000000078c0:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    78c4:      	orr	x1, x16, xzr
    78c8:      	str	x1, [x0]
    78cc:      	mov	x17, #0x83              ; =131
    78d0:      	str	x17, [x0, #0x8]
    78d4:      	ldr	x0, [sp]
    78d8:      	ldr	x1, [sp, #0x8]
    78dc:      	add	sp, sp, #0x10
    78e0:      	ret

00000000000078e4 <_coil.core.Get$slice$get__u32>:
    78e4:      	lsl	x1, x2, #2
    78e8:      	add	x0, x0, x2, lsl #2
    78ec:      	ldr	w0, [x0]
    78f0:      	ret

00000000000078f4 <_stogir.opcode.operand-code-word>:
    78f4:      	sxtw	x1, w1
    78f8:      	cmp	x1, #0x0
    78fc:      	b.le	0x7910 <_stogir.opcode.operand-code-word+0x1c>
    7900:      	cmp	x1, #0x4
    7904:      	b.le	0x7918 <_stogir.opcode.operand-code-word+0x24>
    7908:      	mov	x1, #0x4                ; =4
    790c:      	b	0x7924 <_stogir.opcode.operand-code-word+0x30>
    7910:      	movz	x0, #0x0, lsl #48
    7914:      	b	0x7944 <_stogir.opcode.operand-code-word+0x50>
    7918:      	sub	x1, x1, #0x1
    791c:      	lsr	w1, w1, #0
    7920:      	sxtw	x1, w1
    7924:      	ubfx	x0, x0, #0, #32
    7928:      	lsl	x1, x1, #2
    792c:      	lsr	w1, w1, #0
    7930:      	ubfx	x1, x1, #0, #32
    7934:      	lsr	x0, x0, x1
    7938:      	lsr	w0, w0, #0
    793c:      	and	x0, x0, #0xf
    7940:      	lsr	w0, w0, #0
    7944:      	ret

0000000000007948 <_inherent$coil.arraylist.ArrayList$at__stogir.node.Node>:
    7948:      	lsl	x2, x1, #4
    794c:      	ldr	x0, [x0]
    7950:      	add	x0, x0, x1, lsl #4
    7954:      	ret

0000000000007958 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.strings.Entry>:
    7958:      	ldr	x0, [x0, #0x8]
    795c:      	ret

0000000000007960 <_coil.core.Len$coil.arraylist.ArrayList$len__u8>:
    7960:      	ldr	x0, [x0, #0x8]
    7964:      	ret

0000000000007968 <_inherent$coil.arraylist.ArrayList$slice__u8>:
    7968:      	sub	sp, sp, #0x10
    796c:      	mov	x1, sp
    7970:      	ldr	x2, [x0]
    7974:      	ldr	x0, [x0, #0x8]
    7978:      	str	x2, [x1]
    797c:      	str	x0, [x1, #0x8]
    7980:      	ldr	x0, [sp]
    7984:      	ldr	x1, [sp, #0x8]
    7988:      	add	sp, sp, #0x10
    798c:      	ret

0000000000007990 <_coil.slice.subslice__u8>:
    7990:      	sub	sp, sp, #0x10
    7994:      	mov	x1, sp
    7998:      	lsr	x4, x2, #0
    799c:      	sub	x3, x3, x2
    79a0:      	add	x0, x0, x2
    79a4:      	str	x0, [x1]
    79a8:      	str	x3, [x1, #0x8]
    79ac:      	ldr	x0, [sp]
    79b0:      	ldr	x1, [sp, #0x8]
    79b4:      	add	sp, sp, #0x10
    79b8:      	ret

00000000000079bc <_stogir.floating.operation?>:
    79bc:      	sxtw	x0, w0
    79c0:      	cmp	x0, #0xe
    79c4:      	b.lt	0x79d8 <_stogir.floating.operation?+0x1c>
    79c8:      	cmp	x0, #0x19
    79cc:      	b.gt	0x79d8 <_stogir.floating.operation?+0x1c>
    79d0:      	mov	x0, #0x1                ; =1
    79d4:      	b	0x7a04 <_stogir.floating.operation?+0x48>
    79d8:      	cmp	x0, #0x1f
    79dc:      	b.eq	0x7a00 <_stogir.floating.operation?+0x44>
    79e0:      	cmp	x0, #0x20
    79e4:      	b.eq	0x7a00 <_stogir.floating.operation?+0x44>
    79e8:      	cmp	x0, #0x1a
    79ec:      	b.lt	0x7a18 <_stogir.floating.operation?+0x5c>
    79f0:      	cmp	x0, #0x1d
    79f4:      	b.gt	0x7a18 <_stogir.floating.operation?+0x5c>
    79f8:      	mov	x0, #0x1                ; =1
    79fc:      	b	0x7a14 <_stogir.floating.operation?+0x58>
    7a00:      	mov	x0, #0x1                ; =1
    7a04:      	ret
    7a08:      	cmp	x0, #0x3b
    7a0c:      	cset	w0, eq
    7a10:      	ubfx	x0, x0, #0, #8
    7a14:      	b	0x7a04 <_stogir.floating.operation?+0x48>
    7a18:      	cmp	x0, #0x3a
    7a1c:      	b.ne	0x7a08 <_stogir.floating.operation?+0x4c>
    7a20:      	mov	x0, #0x1                ; =1
    7a24:      	b	0x7a14 <_stogir.floating.operation?+0x58>

0000000000007a28 <_stogir.types.floating?>:
    7a28:      	sxtw	x0, w0
    7a2c:      	cmp	x0, #0xc
    7a30:      	b.ne	0x7a3c <_stogir.types.floating?+0x14>
    7a34:      	mov	x0, #0x1                ; =1
    7a38:      	b	0x7a48 <_stogir.types.floating?+0x20>
    7a3c:      	cmp	x0, #0xd
    7a40:      	cset	w0, eq
    7a44:      	ubfx	x0, x0, #0, #8
    7a48:      	ret

0000000000007a4c <_stogir.vector-lanes.validate>:
    7a4c:      	sub	sp, sp, #0x50
    7a50:      	str	x29, [sp]
    7a54:      	str	x30, [sp, #0x8]
    7a58:      	mov	x29, sp
    7a5c:      	str	x19, [sp, #0x40]
    7a60:      	sxtw	x1, w1
    7a64:      	lsl	x3, x1, #2
    7a68:      	cmp	x1, #0x0
    7a6c:      	cset	w4, gt
    7a70:      	movz	x16, #0x0, lsl #48
    7a74:      	sub	x5, x16, x1
    7a78:      	sub	x6, x5, #0x1
    7a7c:      	uxtb	w16, w4
    7a80:      	cmp	w16, wzr
    7a84:      	b.eq	0x7ac4 <_stogir.vector-lanes.validate+0x78>
    7a88:      	ldr	x5, [x0, #0x8]
    7a8c:      	cmp	x1, x5
    7a90:      	b.ge	0x7b18 <_stogir.vector-lanes.validate+0xcc>
    7a94:      	add	x5, x0, #0x78
    7a98:      	ldr	x5, [x5, #0x8]
    7a9c:      	cmp	x1, x5
    7aa0:      	b.ge	0x7c3c <_stogir.vector-lanes.validate+0x1f0>
    7aa4:      	ldr	x5, [x0, #0x78]
    7aa8:      	add	x5, x3, x5
    7aac:      	ldr	w5, [x5]
    7ab0:      	sxtw	x5, w5
    7ab4:      	cmp	x5, #0x0
    7ab8:      	cset	w5, ge
    7abc:      	ubfx	x5, x5, #0, #8
    7ac0:      	b	0x7c40 <_stogir.vector-lanes.validate+0x1f4>
    7ac4:      	cmp	x1, #0x0
    7ac8:      	b.ge	0x7b20 <_stogir.vector-lanes.validate+0xd4>
    7acc:      	add	x7, x0, #0x28
    7ad0:      	add	x9, x0, #0x50
    7ad4:      	ldr	x7, [x7, #0x8]
    7ad8:      	ldr	x9, [x9, #0x8]
    7adc:      	cmp	x7, x9
    7ae0:      	b.ne	0x7b10 <_stogir.vector-lanes.validate+0xc4>
    7ae4:      	cmp	x5, x7
    7ae8:      	b.gt	0x7c80 <_stogir.vector-lanes.validate+0x234>
    7aec:      	lsl	x5, x6, #2
    7af0:      	ldr	x5, [x0, #0x50]
    7af4:      	add	x5, x5, x6, lsl #2
    7af8:      	ldr	w5, [x5]
    7afc:      	sxtw	x5, w5
    7b00:      	cmp	x5, #0x0
    7b04:      	cset	w5, gt
    7b08:      	ubfx	x5, x5, #0, #8
    7b0c:      	b	0x7c84 <_stogir.vector-lanes.validate+0x238>
    7b10:      	movz	x5, #0x0, lsl #48
    7b14:      	b	0x7b24 <_stogir.vector-lanes.validate+0xd8>
    7b18:      	movz	x5, #0x0, lsl #48
    7b1c:      	b	0x7b24 <_stogir.vector-lanes.validate+0xd8>
    7b20:      	movz	x5, #0x0, lsl #48
    7b24:      	cmp	x5, #0x0
    7b28:      	b.eq	0x7b8c <_stogir.vector-lanes.validate+0x140>
    7b2c:      	uxtb	w16, w4
    7b30:      	cmp	w16, wzr
    7b34:      	b.eq	0x7b5c <_stogir.vector-lanes.validate+0x110>
    7b38:      	lsl	x4, x1, #4
    7b3c:      	ldr	x4, [x0]
    7b40:      	add	x4, x4, x1, lsl #4
    7b44:      	ldr	x5, [x4]
    7b48:      	ldr	x4, [x4, #0x8]
    7b4c:      	fmov	d31, x4
    7b50:      	mov	x4, x5
    7b54:      	fmov	x5, d31
    7b58:      	b	0x7b7c <_stogir.vector-lanes.validate+0x130>
    7b5c:      	lsl	x4, x6, #4
    7b60:      	ldr	x4, [x0, #0x28]
    7b64:      	add	x4, x4, x6, lsl #4
    7b68:      	ldr	x5, [x4]
    7b6c:      	ldr	x4, [x4, #0x8]
    7b70:      	fmov	d31, x4
    7b74:      	mov	x4, x5
    7b78:      	fmov	x5, d31
    7b7c:      	mov	x6, x5
    7b80:      	mov	x5, x4
    7b84:      	mov	x4, #0x1                ; =1
    7b88:      	b	0x7b98 <_stogir.vector-lanes.validate+0x14c>
    7b8c:      	movz	x4, #0x0, lsl #48
    7b90:      	movz	x5, #0x0, lsl #48
    7b94:      	movz	x6, #0x0, lsl #48
    7b98:      	lsr	w4, w4, #0
    7b9c:      	lsr	x16, x4, #0
    7ba0:      	cmp	x16, #0x1
    7ba4:      	b.eq	0x7bc0 <_stogir.vector-lanes.validate+0x174>
    7ba8:      	b.lo	0x7bb0 <_stogir.vector-lanes.validate+0x164>
    7bac:      	b	0x7bc4 <_stogir.vector-lanes.validate+0x178>
    7bb0:      	cmp	x16, #0x0
    7bb4:      	b.eq	0x7bbc <_stogir.vector-lanes.validate+0x170>
    7bb8:      	b	0x7bc4 <_stogir.vector-lanes.validate+0x178>
    7bbc:      	b	0x7bc8 <_stogir.vector-lanes.validate+0x17c>
    7bc0:      	b	0x7be8 <_stogir.vector-lanes.validate+0x19c>
    7bc4:      	b	0x7d64 <_stogir.vector-lanes.validate+0x318>
    7bc8:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xc>
		0000000000007bc8:  ARM64_RELOC_PAGE21	l_stogir.410
    7bcc:      	ldr	x16, [x16]
		0000000000007bcc:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    7bd0:      	orr	x0, x16, xzr
    7bd4:      	mov	x19, x8
    7bd8:      	mov	x1, x0
    7bdc:      	mov	x0, #0x1                ; =1
    7be0:      	mov	x2, #0x1f               ; =31
    7be4:      	b	0x7c1c <_stogir.vector-lanes.validate+0x1d0>
    7be8:      	add	x16, sp, #0x10
    7bec:      	str	x5, [x16]
    7bf0:      	add	x16, sp, #0x10
    7bf4:      	str	x6, [x16, #0x8]
    7bf8:      	cmp	x1, #0x0
    7bfc:      	b.gt	0x7c44 <_stogir.vector-lanes.validate+0x1f8>
    7c00:      	mov	x19, x8
    7c04:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xc>
		0000000000007c04:  ARM64_RELOC_PAGE21	l_stogir.411
    7c08:      	ldr	x16, [x16]
		0000000000007c08:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    7c0c:      	orr	x0, x16, xzr
    7c10:      	mov	x1, x0
    7c14:      	mov	x0, #0x1                ; =1
    7c18:      	mov	x2, #0x25               ; =37
    7c1c:      	str	x0, [x19]
    7c20:      	str	x1, [x19, #0x8]
    7c24:      	str	x2, [x19, #0x10]
    7c28:      	ldr	x19, [sp, #0x40]
    7c2c:      	ldr	x29, [sp]
    7c30:      	ldr	x30, [sp, #0x8]
    7c34:      	add	sp, sp, #0x50
    7c38:      	ret
    7c3c:      	movz	x5, #0x0, lsl #48
    7c40:      	b	0x7b1c <_stogir.vector-lanes.validate+0xd0>
    7c44:      	uxtb	w5, w5
    7c48:      	orr	x1, x5, xzr
    7c4c:      	cmp	x1, #0x3d
    7c50:      	b.lt	0x7d6c <_stogir.vector-lanes.validate+0x320>
    7c54:      	cmp	x1, #0x3f
    7c58:      	b.gt	0x7d74 <_stogir.vector-lanes.validate+0x328>
    7c5c:      	cmp	x1, #0x3e
    7c60:      	cset	w4, eq
    7c64:      	ldr	x6, [x0, #0x78]
    7c68:      	add	x3, x3, x6
    7c6c:      	ldr	w3, [x3]
    7c70:      	cmp	x1, #0x3d
    7c74:      	b.ne	0x7cf4 <_stogir.vector-lanes.validate+0x2a8>
    7c78:      	mov	x6, #0x2                ; =2
    7c7c:      	b	0x7d08 <_stogir.vector-lanes.validate+0x2bc>
    7c80:      	movz	x5, #0x0, lsl #48
    7c84:      	b	0x7b14 <_stogir.vector-lanes.validate+0xc8>
    7c88:      	movz	x4, #0x0, lsl #48
    7c8c:      	lsr	w2, w2, #0
    7c90:      	lsr	w6, w6, #0
    7c94:      	lsr	w1, w1, #0
    7c98:      	lsr	w5, w5, #0
    7c9c:      	lsr	w4, w4, #0
    7ca0:      	ubfx	x3, x3, #8, #8
    7ca4:      	lsr	w3, w3, #0
    7ca8:      	mov	x19, x8
    7cac:      	add	x8, sp, #0x20
    7cb0:      	fmov	s31, w1
    7cb4:      	mov	w1, w5
    7cb8:      	fmov	w5, s31
    7cbc:      	fmov	s31, w2
    7cc0:      	mov	w2, w3
    7cc4:      	fmov	w3, s31
    7cc8:      	fmov	s31, w4
    7ccc:      	mov	w4, w6
    7cd0:      	fmov	w6, s31
    7cd4:      	bl	0x7cd4 <_stogir.vector-lanes.validate+0x288>
		0000000000007cd4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    7cd8:      	add	x16, sp, #0x20
    7cdc:      	ldr	x0, [x16]
    7ce0:      	add	x16, sp, #0x20
    7ce4:      	ldr	x1, [x16, #0x8]
    7ce8:      	add	x16, sp, #0x20
    7cec:      	ldr	x2, [x16, #0x10]
    7cf0:      	b	0x7c1c <_stogir.vector-lanes.validate+0x1d0>
    7cf4:      	uxtb	w16, w4
    7cf8:      	cmp	w16, wzr
    7cfc:      	mov	x16, #0x3               ; =3
    7d00:      	mov	x17, #0x1               ; =1
    7d04:      	csel	x6, x16, x17, ne
    7d08:      	sxtw	x3, w3
    7d0c:      	lsr	w6, w6, #0
    7d10:      	sxtw	x6, w6
    7d14:      	cmp	x3, x6
    7d18:      	b.ne	0x7d7c <_stogir.vector-lanes.validate+0x330>
    7d1c:      	add	x16, sp, #0x10
    7d20:      	ldr	w3, [x16]
    7d24:      	add	x16, sp, #0x10
    7d28:      	ldr	w6, [x16, #0x4]
    7d2c:      	cmp	x1, #0x3f
    7d30:      	b.ne	0x7d3c <_stogir.vector-lanes.validate+0x2f0>
    7d34:      	movz	x1, #0x0, lsl #48
    7d38:      	b	0x7d48 <_stogir.vector-lanes.validate+0x2fc>
    7d3c:      	add	x16, sp, #0x10
    7d40:      	ldr	w1, [x16, #0x8]
    7d44:      	sxtw	x1, w1
    7d48:      	uxtb	w16, w4
    7d4c:      	cmp	w16, wzr
    7d50:      	b.eq	0x7c88 <_stogir.vector-lanes.validate+0x23c>
    7d54:      	add	x16, sp, #0x10
    7d58:      	ldr	w4, [x16, #0xc]
    7d5c:      	sxtw	x4, w4
    7d60:      	b	0x7c8c <_stogir.vector-lanes.validate+0x240>
    7d64:      	brk	#0
    7d68:      	b	0x7d64 <_stogir.vector-lanes.validate+0x318>
    7d6c:      	mov	x19, x8
    7d70:      	b	0x7c04 <_stogir.vector-lanes.validate+0x1b8>
    7d74:      	mov	x19, x8
    7d78:      	b	0x7c04 <_stogir.vector-lanes.validate+0x1b8>
    7d7c:      	mov	x19, x8
    7d80:      	b	0x7c04 <_stogir.vector-lanes.validate+0x1b8>

0000000000007d84 <_stogir.vector-comparison.node?>:
    7d84:      	sxtw	x1, w1
    7d88:      	cmp	x1, #0x0
    7d8c:      	cset	w2, gt
    7d90:      	movz	x16, #0x0, lsl #48
    7d94:      	sub	x3, x16, x1
    7d98:      	sub	x4, x3, #0x1
    7d9c:      	uxtb	w16, w2
    7da0:      	cmp	w16, wzr
    7da4:      	b.eq	0x7de8 <_stogir.vector-comparison.node?+0x64>
    7da8:      	ldr	x3, [x0, #0x8]
    7dac:      	cmp	x1, x3
    7db0:      	b.ge	0x7e3c <_stogir.vector-comparison.node?+0xb8>
    7db4:      	add	x3, x0, #0x78
    7db8:      	ldr	x3, [x3, #0x8]
    7dbc:      	cmp	x1, x3
    7dc0:      	b.ge	0x7f24 <_stogir.vector-comparison.node?+0x1a0>
    7dc4:      	lsl	x3, x1, #2
    7dc8:      	ldr	x3, [x0, #0x78]
    7dcc:      	add	x3, x3, x1, lsl #2
    7dd0:      	ldr	w3, [x3]
    7dd4:      	sxtw	x3, w3
    7dd8:      	cmp	x3, #0x0
    7ddc:      	cset	w3, ge
    7de0:      	ubfx	x3, x3, #0, #8
    7de4:      	b	0x7f28 <_stogir.vector-comparison.node?+0x1a4>
    7de8:      	cmp	x1, #0x0
    7dec:      	b.ge	0x7e44 <_stogir.vector-comparison.node?+0xc0>
    7df0:      	add	x5, x0, #0x28
    7df4:      	add	x6, x0, #0x50
    7df8:      	ldr	x5, [x5, #0x8]
    7dfc:      	ldr	x6, [x6, #0x8]
    7e00:      	cmp	x5, x6
    7e04:      	b.ne	0x7e34 <_stogir.vector-comparison.node?+0xb0>
    7e08:      	cmp	x3, x5
    7e0c:      	b.gt	0x7f2c <_stogir.vector-comparison.node?+0x1a8>
    7e10:      	lsl	x3, x4, #2
    7e14:      	ldr	x3, [x0, #0x50]
    7e18:      	add	x3, x3, x4, lsl #2
    7e1c:      	ldr	w3, [x3]
    7e20:      	sxtw	x3, w3
    7e24:      	cmp	x3, #0x0
    7e28:      	cset	w3, gt
    7e2c:      	ubfx	x3, x3, #0, #8
    7e30:      	b	0x7f30 <_stogir.vector-comparison.node?+0x1ac>
    7e34:      	movz	x3, #0x0, lsl #48
    7e38:      	b	0x7e48 <_stogir.vector-comparison.node?+0xc4>
    7e3c:      	movz	x3, #0x0, lsl #48
    7e40:      	b	0x7e48 <_stogir.vector-comparison.node?+0xc4>
    7e44:      	movz	x3, #0x0, lsl #48
    7e48:      	cmp	x3, #0x0
    7e4c:      	b.eq	0x7e8c <_stogir.vector-comparison.node?+0x108>
    7e50:      	uxtb	w16, w2
    7e54:      	cmp	w16, wzr
    7e58:      	b.eq	0x7e70 <_stogir.vector-comparison.node?+0xec>
    7e5c:      	lsl	x2, x1, #4
    7e60:      	ldr	x0, [x0]
    7e64:      	add	x0, x0, x1, lsl #4
    7e68:      	ldr	x0, [x0]
    7e6c:      	b	0x7e80 <_stogir.vector-comparison.node?+0xfc>
    7e70:      	lsl	x1, x4, #4
    7e74:      	ldr	x0, [x0, #0x28]
    7e78:      	add	x0, x0, x4, lsl #4
    7e7c:      	ldr	x0, [x0]
    7e80:      	mov	x1, x0
    7e84:      	mov	x0, #0x1                ; =1
    7e88:      	b	0x7e94 <_stogir.vector-comparison.node?+0x110>
    7e8c:      	movz	x0, #0x0, lsl #48
    7e90:      	movz	x1, #0x0, lsl #48
    7e94:      	lsr	w0, w0, #0
    7e98:      	lsr	x16, x0, #0
    7e9c:      	cmp	x16, #0x1
    7ea0:      	b.eq	0x7ebc <_stogir.vector-comparison.node?+0x138>
    7ea4:      	b.lo	0x7eac <_stogir.vector-comparison.node?+0x128>
    7ea8:      	b	0x7ec0 <_stogir.vector-comparison.node?+0x13c>
    7eac:      	cmp	x16, #0x0
    7eb0:      	b.eq	0x7eb8 <_stogir.vector-comparison.node?+0x134>
    7eb4:      	b	0x7ec0 <_stogir.vector-comparison.node?+0x13c>
    7eb8:      	b	0x7ec4 <_stogir.vector-comparison.node?+0x140>
    7ebc:      	b	0x7ed4 <_stogir.vector-comparison.node?+0x150>
    7ec0:      	b	0x7f4c <_stogir.vector-comparison.node?+0x1c8>
    7ec4:      	movz	x0, #0x0, lsl #48
    7ec8:      	b	0x7ed0 <_stogir.vector-comparison.node?+0x14c>
    7ecc:      	movz	x0, #0x0, lsl #48
    7ed0:      	ret
    7ed4:      	uxtb	w0, w1
    7ed8:      	cmp	x0, #0xe
    7edc:      	b.lt	0x7ecc <_stogir.vector-comparison.node?+0x148>
    7ee0:      	cmp	x0, #0x19
    7ee4:      	b.gt	0x7ecc <_stogir.vector-comparison.node?+0x148>
    7ee8:      	lsr	w1, w1, #0
    7eec:      	ubfx	x0, x1, #8, #8
    7ef0:      	cmp	x0, #0xf
    7ef4:      	b.le	0x7f34 <_stogir.vector-comparison.node?+0x1b0>
    7ef8:      	cmp	x0, #0x80
    7efc:      	b.ge	0x7f3c <_stogir.vector-comparison.node?+0x1b8>
    7f00:      	and	x0, x0, #0xf
    7f04:      	lsr	w0, w0, #0
    7f08:      	sxtw	x0, w0
    7f0c:      	cmp	x0, #0x1
    7f10:      	b.lt	0x7f44 <_stogir.vector-comparison.node?+0x1c0>
    7f14:      	cmp	x0, #0xd
    7f18:      	cset	w0, le
    7f1c:      	ubfx	x0, x0, #0, #8
    7f20:      	b	0x7f48 <_stogir.vector-comparison.node?+0x1c4>
    7f24:      	movz	x3, #0x0, lsl #48
    7f28:      	b	0x7e40 <_stogir.vector-comparison.node?+0xbc>
    7f2c:      	movz	x3, #0x0, lsl #48
    7f30:      	b	0x7e38 <_stogir.vector-comparison.node?+0xb4>
    7f34:      	movz	x0, #0x0, lsl #48
    7f38:      	b	0x7ed0 <_stogir.vector-comparison.node?+0x14c>
    7f3c:      	movz	x0, #0x0, lsl #48
    7f40:      	b	0x7f38 <_stogir.vector-comparison.node?+0x1b4>
    7f44:      	movz	x0, #0x0, lsl #48
    7f48:      	b	0x7f40 <_stogir.vector-comparison.node?+0x1bc>
    7f4c:      	brk	#0
    7f50:      	b	0x7f4c <_stogir.vector-comparison.node?+0x1c8>

0000000000007f54 <_stogir.vector-comparison.validate>:
    7f54:      	sub	sp, sp, #0x50
    7f58:      	str	x29, [sp]
    7f5c:      	str	x30, [sp, #0x8]
    7f60:      	mov	x29, sp
    7f64:      	str	x19, [sp, #0x40]
    7f68:      	sxtw	x1, w1
    7f6c:      	lsl	x3, x1, #2
    7f70:      	cmp	x1, #0x0
    7f74:      	cset	w4, gt
    7f78:      	movz	x16, #0x0, lsl #48
    7f7c:      	sub	x5, x16, x1
    7f80:      	sub	x6, x5, #0x1
    7f84:      	uxtb	w16, w4
    7f88:      	cmp	w16, wzr
    7f8c:      	b.eq	0x7fcc <_stogir.vector-comparison.validate+0x78>
    7f90:      	ldr	x5, [x0, #0x8]
    7f94:      	cmp	x1, x5
    7f98:      	b.ge	0x8020 <_stogir.vector-comparison.validate+0xcc>
    7f9c:      	add	x5, x0, #0x78
    7fa0:      	ldr	x5, [x5, #0x8]
    7fa4:      	cmp	x1, x5
    7fa8:      	b.ge	0x8144 <_stogir.vector-comparison.validate+0x1f0>
    7fac:      	ldr	x5, [x0, #0x78]
    7fb0:      	add	x5, x3, x5
    7fb4:      	ldr	w5, [x5]
    7fb8:      	sxtw	x5, w5
    7fbc:      	cmp	x5, #0x0
    7fc0:      	cset	w5, ge
    7fc4:      	ubfx	x5, x5, #0, #8
    7fc8:      	b	0x8148 <_stogir.vector-comparison.validate+0x1f4>
    7fcc:      	cmp	x1, #0x0
    7fd0:      	b.ge	0x8028 <_stogir.vector-comparison.validate+0xd4>
    7fd4:      	add	x7, x0, #0x28
    7fd8:      	add	x9, x0, #0x50
    7fdc:      	ldr	x7, [x7, #0x8]
    7fe0:      	ldr	x9, [x9, #0x8]
    7fe4:      	cmp	x7, x9
    7fe8:      	b.ne	0x8018 <_stogir.vector-comparison.validate+0xc4>
    7fec:      	cmp	x5, x7
    7ff0:      	b.gt	0x8198 <_stogir.vector-comparison.validate+0x244>
    7ff4:      	lsl	x5, x6, #2
    7ff8:      	ldr	x5, [x0, #0x50]
    7ffc:      	add	x5, x5, x6, lsl #2
    8000:      	ldr	w5, [x5]
    8004:      	sxtw	x5, w5
    8008:      	cmp	x5, #0x0
    800c:      	cset	w5, gt
    8010:      	ubfx	x5, x5, #0, #8
    8014:      	b	0x819c <_stogir.vector-comparison.validate+0x248>
    8018:      	movz	x5, #0x0, lsl #48
    801c:      	b	0x802c <_stogir.vector-comparison.validate+0xd8>
    8020:      	movz	x5, #0x0, lsl #48
    8024:      	b	0x802c <_stogir.vector-comparison.validate+0xd8>
    8028:      	movz	x5, #0x0, lsl #48
    802c:      	lsl	x7, x1, #4
    8030:      	cmp	x5, #0x0
    8034:      	b.eq	0x8094 <_stogir.vector-comparison.validate+0x140>
    8038:      	uxtb	w16, w4
    803c:      	cmp	w16, wzr
    8040:      	b.eq	0x8064 <_stogir.vector-comparison.validate+0x110>
    8044:      	ldr	x4, [x0]
    8048:      	add	x4, x7, x4
    804c:      	ldr	x5, [x4]
    8050:      	ldr	x4, [x4, #0x8]
    8054:      	fmov	d31, x4
    8058:      	mov	x4, x5
    805c:      	fmov	x5, d31
    8060:      	b	0x8084 <_stogir.vector-comparison.validate+0x130>
    8064:      	lsl	x4, x6, #4
    8068:      	ldr	x4, [x0, #0x28]
    806c:      	add	x4, x4, x6, lsl #4
    8070:      	ldr	x5, [x4]
    8074:      	ldr	x4, [x4, #0x8]
    8078:      	fmov	d31, x4
    807c:      	mov	x4, x5
    8080:      	fmov	x5, d31
    8084:      	mov	x6, x5
    8088:      	mov	x5, x4
    808c:      	mov	x4, #0x1                ; =1
    8090:      	b	0x80a0 <_stogir.vector-comparison.validate+0x14c>
    8094:      	movz	x4, #0x0, lsl #48
    8098:      	movz	x5, #0x0, lsl #48
    809c:      	movz	x6, #0x0, lsl #48
    80a0:      	lsr	w4, w4, #0
    80a4:      	lsr	x16, x4, #0
    80a8:      	cmp	x16, #0x1
    80ac:      	b.eq	0x80c8 <_stogir.vector-comparison.validate+0x174>
    80b0:      	b.lo	0x80b8 <_stogir.vector-comparison.validate+0x164>
    80b4:      	b	0x80cc <_stogir.vector-comparison.validate+0x178>
    80b8:      	cmp	x16, #0x0
    80bc:      	b.eq	0x80c4 <_stogir.vector-comparison.validate+0x170>
    80c0:      	b	0x80cc <_stogir.vector-comparison.validate+0x178>
    80c4:      	b	0x80d0 <_stogir.vector-comparison.validate+0x17c>
    80c8:      	b	0x810c <_stogir.vector-comparison.validate+0x1b8>
    80cc:      	b	0x82ac <_stogir.vector-comparison.validate+0x358>
    80d0:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		00000000000080d0:  ARM64_RELOC_PAGE21	l_stogir.412
    80d4:      	ldr	x16, [x16]
		00000000000080d4:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    80d8:      	orr	x0, x16, xzr
    80dc:      	mov	x19, x8
    80e0:      	mov	x1, x0
    80e4:      	mov	x0, #0x1                ; =1
    80e8:      	mov	x2, #0x25               ; =37
    80ec:      	str	x0, [x19]
    80f0:      	str	x1, [x19, #0x8]
    80f4:      	str	x2, [x19, #0x10]
    80f8:      	ldr	x19, [sp, #0x40]
    80fc:      	ldr	x29, [sp]
    8100:      	ldr	x30, [sp, #0x8]
    8104:      	add	sp, sp, #0x50
    8108:      	ret
    810c:      	add	x16, sp, #0x10
    8110:      	str	x5, [x16]
    8114:      	add	x16, sp, #0x10
    8118:      	str	x6, [x16, #0x8]
    811c:      	cmp	x1, #0x0
    8120:      	b.gt	0x814c <_stogir.vector-comparison.validate+0x1f8>
    8124:      	mov	x19, x8
    8128:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		0000000000008128:  ARM64_RELOC_PAGE21	l_stogir.413
    812c:      	ldr	x16, [x16]
		000000000000812c:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    8130:      	orr	x0, x16, xzr
    8134:      	mov	x1, x0
    8138:      	mov	x0, #0x1                ; =1
    813c:      	mov	x2, #0x2b               ; =43
    8140:      	b	0x80ec <_stogir.vector-comparison.validate+0x198>
    8144:      	movz	x5, #0x0, lsl #48
    8148:      	b	0x8024 <_stogir.vector-comparison.validate+0xd0>
    814c:      	ldr	x4, [x0, #0x8]
    8150:      	cmp	x1, x4
    8154:      	b.ge	0x81a0 <_stogir.vector-comparison.validate+0x24c>
    8158:      	add	x4, x0, #0x78
    815c:      	ldr	x4, [x4, #0x8]
    8160:      	cmp	x1, x4
    8164:      	b.ge	0x81a0 <_stogir.vector-comparison.validate+0x24c>
    8168:      	ldr	x1, [x0, #0x78]
    816c:      	add	x1, x3, x1
    8170:      	ldr	w1, [x1]
    8174:      	sxtw	x1, w1
    8178:      	cmp	x1, #0x0
    817c:      	b.lt	0x81a0 <_stogir.vector-comparison.validate+0x24c>
    8180:      	ldr	x1, [x0]
    8184:      	add	x1, x7, x1
    8188:      	ldr	x1, [x1]
    818c:      	mov	x4, x1
    8190:      	mov	x1, #0x1                ; =1
    8194:      	b	0x81a8 <_stogir.vector-comparison.validate+0x254>
    8198:      	movz	x5, #0x0, lsl #48
    819c:      	b	0x801c <_stogir.vector-comparison.validate+0xc8>
    81a0:      	movz	x1, #0x0, lsl #48
    81a4:      	movz	x4, #0x0, lsl #48
    81a8:      	lsr	w1, w1, #0
    81ac:      	lsr	x16, x1, #0
    81b0:      	cmp	x16, #0x1
    81b4:      	b.eq	0x81d0 <_stogir.vector-comparison.validate+0x27c>
    81b8:      	b.lo	0x81c0 <_stogir.vector-comparison.validate+0x26c>
    81bc:      	b	0x81d4 <_stogir.vector-comparison.validate+0x280>
    81c0:      	cmp	x16, #0x0
    81c4:      	b.eq	0x81cc <_stogir.vector-comparison.validate+0x278>
    81c8:      	b	0x81d4 <_stogir.vector-comparison.validate+0x280>
    81cc:      	b	0x81d8 <_stogir.vector-comparison.validate+0x284>
    81d0:      	b	0x81e0 <_stogir.vector-comparison.validate+0x28c>
    81d4:      	b	0x82b4 <_stogir.vector-comparison.validate+0x360>
    81d8:      	mov	x19, x8
    81dc:      	b	0x8128 <_stogir.vector-comparison.validate+0x1d4>
    81e0:      	uxtb	w1, w4
    81e4:      	cmp	x1, #0xe
    81e8:      	b.lt	0x82bc <_stogir.vector-comparison.validate+0x368>
    81ec:      	cmp	x1, #0x19
    81f0:      	b.gt	0x82c4 <_stogir.vector-comparison.validate+0x370>
    81f4:      	lsr	w4, w4, #0
    81f8:      	ubfx	x1, x4, #8, #8
    81fc:      	cmp	x1, #0xf
    8200:      	b.le	0x82cc <_stogir.vector-comparison.validate+0x378>
    8204:      	cmp	x1, #0x80
    8208:      	b.ge	0x82d4 <_stogir.vector-comparison.validate+0x380>
    820c:      	and	x1, x1, #0xf
    8210:      	lsr	w1, w1, #0
    8214:      	sxtw	x1, w1
    8218:      	cmp	x1, #0x1
    821c:      	b.lt	0x82dc <_stogir.vector-comparison.validate+0x388>
    8220:      	cmp	x1, #0xd
    8224:      	b.gt	0x82e4 <_stogir.vector-comparison.validate+0x390>
    8228:      	ldr	x1, [x0, #0x78]
    822c:      	add	x1, x3, x1
    8230:      	ldr	w1, [x1]
    8234:      	sxtw	x1, w1
    8238:      	cmp	x1, #0x2
    823c:      	b.ne	0x82ec <_stogir.vector-comparison.validate+0x398>
    8240:      	lsr	w2, w2, #0
    8244:      	add	x16, sp, #0x10
    8248:      	ldr	w1, [x16]
    824c:      	uxtb	w3, w1
    8250:      	add	x16, sp, #0x10
    8254:      	ldr	w4, [x16, #0x4]
    8258:      	lsr	w3, w3, #0
    825c:      	ubfx	x1, x1, #8, #8
    8260:      	add	x16, sp, #0x10
    8264:      	ldr	w5, [x16, #0x8]
    8268:      	lsr	w4, w4, #0
    826c:      	lsr	w5, w5, #0
    8270:      	lsr	w1, w1, #0
    8274:      	mov	x19, x8
    8278:      	add	x8, sp, #0x20
    827c:      	fmov	s31, w1
    8280:      	mov	w1, w3
    8284:      	mov	w3, w2
    8288:      	fmov	w2, s31
    828c:      	bl	0x828c <_stogir.vector-comparison.validate+0x338>
		000000000000828c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    8290:      	add	x16, sp, #0x20
    8294:      	ldr	x0, [x16]
    8298:      	add	x16, sp, #0x20
    829c:      	ldr	x1, [x16, #0x8]
    82a0:      	add	x16, sp, #0x20
    82a4:      	ldr	x2, [x16, #0x10]
    82a8:      	b	0x8140 <_stogir.vector-comparison.validate+0x1ec>
    82ac:      	brk	#0
    82b0:      	b	0x82ac <_stogir.vector-comparison.validate+0x358>
    82b4:      	brk	#0
    82b8:      	b	0x82b4 <_stogir.vector-comparison.validate+0x360>
    82bc:      	mov	x19, x8
    82c0:      	b	0x8128 <_stogir.vector-comparison.validate+0x1d4>
    82c4:      	mov	x19, x8
    82c8:      	b	0x8128 <_stogir.vector-comparison.validate+0x1d4>
    82cc:      	mov	x19, x8
    82d0:      	b	0x8128 <_stogir.vector-comparison.validate+0x1d4>
    82d4:      	mov	x19, x8
    82d8:      	b	0x8128 <_stogir.vector-comparison.validate+0x1d4>
    82dc:      	mov	x19, x8
    82e0:      	b	0x8128 <_stogir.vector-comparison.validate+0x1d4>
    82e4:      	mov	x19, x8
    82e8:      	b	0x8128 <_stogir.vector-comparison.validate+0x1d4>
    82ec:      	mov	x19, x8
    82f0:      	b	0x8128 <_stogir.vector-comparison.validate+0x1d4>

00000000000082f4 <_stogir.vector-arithmetic.node?>:
    82f4:      	sxtw	x1, w1
    82f8:      	cmp	x1, #0x0
    82fc:      	cset	w2, gt
    8300:      	movz	x16, #0x0, lsl #48
    8304:      	sub	x3, x16, x1
    8308:      	sub	x4, x3, #0x1
    830c:      	uxtb	w16, w2
    8310:      	cmp	w16, wzr
    8314:      	b.eq	0x8358 <_stogir.vector-arithmetic.node?+0x64>
    8318:      	ldr	x3, [x0, #0x8]
    831c:      	cmp	x1, x3
    8320:      	b.ge	0x83ac <_stogir.vector-arithmetic.node?+0xb8>
    8324:      	add	x3, x0, #0x78
    8328:      	ldr	x3, [x3, #0x8]
    832c:      	cmp	x1, x3
    8330:      	b.ge	0x84dc <_stogir.vector-arithmetic.node?+0x1e8>
    8334:      	lsl	x3, x1, #2
    8338:      	ldr	x3, [x0, #0x78]
    833c:      	add	x3, x3, x1, lsl #2
    8340:      	ldr	w3, [x3]
    8344:      	sxtw	x3, w3
    8348:      	cmp	x3, #0x0
    834c:      	cset	w3, ge
    8350:      	ubfx	x3, x3, #0, #8
    8354:      	b	0x84e0 <_stogir.vector-arithmetic.node?+0x1ec>
    8358:      	cmp	x1, #0x0
    835c:      	b.ge	0x83b4 <_stogir.vector-arithmetic.node?+0xc0>
    8360:      	add	x5, x0, #0x28
    8364:      	add	x6, x0, #0x50
    8368:      	ldr	x5, [x5, #0x8]
    836c:      	ldr	x6, [x6, #0x8]
    8370:      	cmp	x5, x6
    8374:      	b.ne	0x83a4 <_stogir.vector-arithmetic.node?+0xb0>
    8378:      	cmp	x3, x5
    837c:      	b.gt	0x84ec <_stogir.vector-arithmetic.node?+0x1f8>
    8380:      	lsl	x3, x4, #2
    8384:      	ldr	x3, [x0, #0x50]
    8388:      	add	x3, x3, x4, lsl #2
    838c:      	ldr	w3, [x3]
    8390:      	sxtw	x3, w3
    8394:      	cmp	x3, #0x0
    8398:      	cset	w3, gt
    839c:      	ubfx	x3, x3, #0, #8
    83a0:      	b	0x84f0 <_stogir.vector-arithmetic.node?+0x1fc>
    83a4:      	movz	x3, #0x0, lsl #48
    83a8:      	b	0x83b8 <_stogir.vector-arithmetic.node?+0xc4>
    83ac:      	movz	x3, #0x0, lsl #48
    83b0:      	b	0x83b8 <_stogir.vector-arithmetic.node?+0xc4>
    83b4:      	movz	x3, #0x0, lsl #48
    83b8:      	cmp	x3, #0x0
    83bc:      	b.eq	0x83fc <_stogir.vector-arithmetic.node?+0x108>
    83c0:      	uxtb	w16, w2
    83c4:      	cmp	w16, wzr
    83c8:      	b.eq	0x83e0 <_stogir.vector-arithmetic.node?+0xec>
    83cc:      	lsl	x2, x1, #4
    83d0:      	ldr	x0, [x0]
    83d4:      	add	x0, x0, x1, lsl #4
    83d8:      	ldr	x0, [x0]
    83dc:      	b	0x83f0 <_stogir.vector-arithmetic.node?+0xfc>
    83e0:      	lsl	x1, x4, #4
    83e4:      	ldr	x0, [x0, #0x28]
    83e8:      	add	x0, x0, x4, lsl #4
    83ec:      	ldr	x0, [x0]
    83f0:      	mov	x1, x0
    83f4:      	mov	x0, #0x1                ; =1
    83f8:      	b	0x8404 <_stogir.vector-arithmetic.node?+0x110>
    83fc:      	movz	x0, #0x0, lsl #48
    8400:      	movz	x1, #0x0, lsl #48
    8404:      	lsr	w0, w0, #0
    8408:      	lsr	x16, x0, #0
    840c:      	cmp	x16, #0x1
    8410:      	b.eq	0x842c <_stogir.vector-arithmetic.node?+0x138>
    8414:      	b.lo	0x841c <_stogir.vector-arithmetic.node?+0x128>
    8418:      	b	0x8430 <_stogir.vector-arithmetic.node?+0x13c>
    841c:      	cmp	x16, #0x0
    8420:      	b.eq	0x8428 <_stogir.vector-arithmetic.node?+0x134>
    8424:      	b	0x8430 <_stogir.vector-arithmetic.node?+0x13c>
    8428:      	b	0x8434 <_stogir.vector-arithmetic.node?+0x140>
    842c:      	b	0x8444 <_stogir.vector-arithmetic.node?+0x150>
    8430:      	b	0x84fc <_stogir.vector-arithmetic.node?+0x208>
    8434:      	movz	x0, #0x0, lsl #48
    8438:      	b	0x8440 <_stogir.vector-arithmetic.node?+0x14c>
    843c:      	movz	x0, #0x0, lsl #48
    8440:      	ret
    8444:      	uxtb	w0, w1
    8448:      	cmp	x0, #0x1f
    844c:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8450:      	cmp	x0, #0x20
    8454:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8458:      	cmp	x0, #0x2d
    845c:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8460:      	cmp	x0, #0x36
    8464:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8468:      	cmp	x0, #0x37
    846c:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8470:      	cmp	x0, #0x38
    8474:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8478:      	cmp	x0, #0x39
    847c:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8480:      	cmp	x0, #0x3a
    8484:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8488:      	cmp	x0, #0x3b
    848c:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8490:      	cmp	x0, #0x31
    8494:      	b.lt	0x8504 <_stogir.vector-arithmetic.node?+0x210>
    8498:      	cmp	x0, #0x35
    849c:      	b.gt	0x8504 <_stogir.vector-arithmetic.node?+0x210>
    84a0:      	lsr	w1, w1, #0
    84a4:      	ubfx	x0, x1, #8, #8
    84a8:      	cmp	x0, #0xf
    84ac:      	b.le	0x843c <_stogir.vector-arithmetic.node?+0x148>
    84b0:      	cmp	x0, #0x80
    84b4:      	b.ge	0x84e4 <_stogir.vector-arithmetic.node?+0x1f0>
    84b8:      	and	x0, x0, #0xf
    84bc:      	lsr	w0, w0, #0
    84c0:      	sxtw	x0, w0
    84c4:      	cmp	x0, #0x1
    84c8:      	b.lt	0x84f4 <_stogir.vector-arithmetic.node?+0x200>
    84cc:      	cmp	x0, #0xd
    84d0:      	cset	w0, le
    84d4:      	ubfx	x0, x0, #0, #8
    84d8:      	b	0x84f8 <_stogir.vector-arithmetic.node?+0x204>
    84dc:      	movz	x3, #0x0, lsl #48
    84e0:      	b	0x83b0 <_stogir.vector-arithmetic.node?+0xbc>
    84e4:      	movz	x0, #0x0, lsl #48
    84e8:      	b	0x8440 <_stogir.vector-arithmetic.node?+0x14c>
    84ec:      	movz	x3, #0x0, lsl #48
    84f0:      	b	0x83a8 <_stogir.vector-arithmetic.node?+0xb4>
    84f4:      	movz	x0, #0x0, lsl #48
    84f8:      	b	0x84e8 <_stogir.vector-arithmetic.node?+0x1f4>
    84fc:      	brk	#0
    8500:      	b	0x84fc <_stogir.vector-arithmetic.node?+0x208>
    8504:      	cmp	x0, #0x1a
    8508:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    850c:      	cmp	x0, #0x1b
    8510:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8514:      	cmp	x0, #0x1c
    8518:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    851c:      	cmp	x0, #0x1d
    8520:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8524:      	cmp	x0, #0x1e
    8528:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    852c:      	cmp	x0, #0x2e
    8530:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8534:      	cmp	x0, #0x2f
    8538:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    853c:      	cmp	x0, #0x30
    8540:      	b.eq	0x84a0 <_stogir.vector-arithmetic.node?+0x1ac>
    8544:      	movz	x0, #0x0, lsl #48
    8548:      	b	0x8440 <_stogir.vector-arithmetic.node?+0x14c>

000000000000854c <_stogir.vector-arithmetic.validate>:
    854c:      	sub	sp, sp, #0x60
    8550:      	str	x29, [sp]
    8554:      	str	x30, [sp, #0x8]
    8558:      	mov	x29, sp
    855c:      	str	x19, [sp, #0x40]
    8560:      	str	x20, [sp, #0x48]
    8564:      	str	x21, [sp, #0x50]
    8568:      	str	x22, [sp, #0x58]
    856c:      	sxtw	x2, w1
    8570:      	lsl	x19, x2, #2
    8574:      	cmp	x2, #0x0
    8578:      	cset	w3, gt
    857c:      	movz	x16, #0x0, lsl #48
    8580:      	sub	x4, x16, x2
    8584:      	sub	x5, x4, #0x1
    8588:      	uxtb	w16, w3
    858c:      	cmp	w16, wzr
    8590:      	b.eq	0x85d0 <_stogir.vector-arithmetic.validate+0x84>
    8594:      	ldr	x4, [x0, #0x8]
    8598:      	cmp	x2, x4
    859c:      	b.ge	0x8624 <_stogir.vector-arithmetic.validate+0xd8>
    85a0:      	add	x4, x0, #0x78
    85a4:      	ldr	x4, [x4, #0x8]
    85a8:      	cmp	x2, x4
    85ac:      	b.ge	0x8750 <_stogir.vector-arithmetic.validate+0x204>
    85b0:      	ldr	x4, [x0, #0x78]
    85b4:      	add	x4, x19, x4
    85b8:      	ldr	w4, [x4]
    85bc:      	sxtw	x4, w4
    85c0:      	cmp	x4, #0x0
    85c4:      	cset	w4, ge
    85c8:      	ubfx	x4, x4, #0, #8
    85cc:      	b	0x8754 <_stogir.vector-arithmetic.validate+0x208>
    85d0:      	cmp	x2, #0x0
    85d4:      	b.ge	0x862c <_stogir.vector-arithmetic.validate+0xe0>
    85d8:      	add	x6, x0, #0x28
    85dc:      	add	x7, x0, #0x50
    85e0:      	ldr	x6, [x6, #0x8]
    85e4:      	ldr	x7, [x7, #0x8]
    85e8:      	cmp	x6, x7
    85ec:      	b.ne	0x861c <_stogir.vector-arithmetic.validate+0xd0>
    85f0:      	cmp	x4, x6
    85f4:      	b.gt	0x87ec <_stogir.vector-arithmetic.validate+0x2a0>
    85f8:      	lsl	x4, x5, #2
    85fc:      	ldr	x4, [x0, #0x50]
    8600:      	add	x4, x4, x5, lsl #2
    8604:      	ldr	w4, [x4]
    8608:      	sxtw	x4, w4
    860c:      	cmp	x4, #0x0
    8610:      	cset	w4, gt
    8614:      	ubfx	x4, x4, #0, #8
    8618:      	b	0x87f0 <_stogir.vector-arithmetic.validate+0x2a4>
    861c:      	movz	x4, #0x0, lsl #48
    8620:      	b	0x8630 <_stogir.vector-arithmetic.validate+0xe4>
    8624:      	movz	x4, #0x0, lsl #48
    8628:      	b	0x8630 <_stogir.vector-arithmetic.validate+0xe4>
    862c:      	movz	x4, #0x0, lsl #48
    8630:      	cmp	x4, #0x0
    8634:      	b.eq	0x8694 <_stogir.vector-arithmetic.validate+0x148>
    8638:      	uxtb	w16, w3
    863c:      	cmp	w16, wzr
    8640:      	b.eq	0x8668 <_stogir.vector-arithmetic.validate+0x11c>
    8644:      	lsl	x3, x2, #4
    8648:      	ldr	x3, [x0]
    864c:      	add	x3, x3, x2, lsl #4
    8650:      	ldr	x4, [x3]
    8654:      	ldr	x3, [x3, #0x8]
    8658:      	fmov	d31, x3
    865c:      	mov	x3, x4
    8660:      	fmov	x4, d31
    8664:      	b	0x8688 <_stogir.vector-arithmetic.validate+0x13c>
    8668:      	lsl	x3, x5, #4
    866c:      	ldr	x3, [x0, #0x28]
    8670:      	add	x3, x3, x5, lsl #4
    8674:      	ldr	x4, [x3]
    8678:      	ldr	x3, [x3, #0x8]
    867c:      	fmov	d31, x3
    8680:      	mov	x3, x4
    8684:      	fmov	x4, d31
    8688:      	mov	x20, x3
    868c:      	mov	x3, #0x1                ; =1
    8690:      	b	0x86a0 <_stogir.vector-arithmetic.validate+0x154>
    8694:      	movz	x3, #0x0, lsl #48
    8698:      	movz	x20, #0x0, lsl #48
    869c:      	movz	x4, #0x0, lsl #48
    86a0:      	lsr	w3, w3, #0
    86a4:      	lsr	x16, x3, #0
    86a8:      	cmp	x16, #0x1
    86ac:      	b.eq	0x86c8 <_stogir.vector-arithmetic.validate+0x17c>
    86b0:      	b.lo	0x86b8 <_stogir.vector-arithmetic.validate+0x16c>
    86b4:      	b	0x86cc <_stogir.vector-arithmetic.validate+0x180>
    86b8:      	cmp	x16, #0x0
    86bc:      	b.eq	0x86c4 <_stogir.vector-arithmetic.validate+0x178>
    86c0:      	b	0x86cc <_stogir.vector-arithmetic.validate+0x180>
    86c4:      	b	0x86d0 <_stogir.vector-arithmetic.validate+0x184>
    86c8:      	b	0x86f0 <_stogir.vector-arithmetic.validate+0x1a4>
    86cc:      	b	0x88a0 <_stogir.vector-arithmetic.validate+0x354>
    86d0:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		00000000000086d0:  ARM64_RELOC_PAGE21	l_stogir.414
    86d4:      	ldr	x16, [x16]
		00000000000086d4:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    86d8:      	orr	x0, x16, xzr
    86dc:      	mov	x21, x8
    86e0:      	mov	x1, x0
    86e4:      	mov	x0, #0x1                ; =1
    86e8:      	mov	x2, #0x25               ; =37
    86ec:      	b	0x8724 <_stogir.vector-arithmetic.validate+0x1d8>
    86f0:      	add	x16, sp, #0x10
    86f4:      	str	x20, [x16]
    86f8:      	add	x16, sp, #0x10
    86fc:      	str	x4, [x16, #0x8]
    8700:      	cmp	x2, #0x0
    8704:      	b.gt	0x8758 <_stogir.vector-arithmetic.validate+0x20c>
    8708:      	mov	x21, x8
    870c:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		000000000000870c:  ARM64_RELOC_PAGE21	l_stogir.415
    8710:      	ldr	x16, [x16]
		0000000000008710:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    8714:      	orr	x0, x16, xzr
    8718:      	mov	x1, x0
    871c:      	mov	x0, #0x1                ; =1
    8720:      	mov	x2, #0x2b               ; =43
    8724:      	str	x0, [x21]
    8728:      	str	x1, [x21, #0x8]
    872c:      	str	x2, [x21, #0x10]
    8730:      	ldr	x19, [sp, #0x40]
    8734:      	ldr	x20, [sp, #0x48]
    8738:      	ldr	x21, [sp, #0x50]
    873c:      	ldr	x22, [sp, #0x58]
    8740:      	ldr	x29, [sp]
    8744:      	ldr	x30, [sp, #0x8]
    8748:      	add	sp, sp, #0x60
    874c:      	ret
    8750:      	movz	x4, #0x0, lsl #48
    8754:      	b	0x8628 <_stogir.vector-arithmetic.validate+0xdc>
    8758:      	lsr	w1, w1, #0
    875c:      	mov	x21, x8
    8760:      	mov	x22, x0
    8764:      	bl	0x8764 <_stogir.vector-arithmetic.validate+0x218>
		0000000000008764:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    8768:      	cmp	x0, #0x0
    876c:      	b.eq	0x870c <_stogir.vector-arithmetic.validate+0x1c0>
    8770:      	uxtb	w20, w20
    8774:      	orr	x0, x20, xzr
    8778:      	ldr	x1, [x22, #0x78]
    877c:      	cmp	x0, #0x1d
    8780:      	cset	w2, eq
    8784:      	cmp	x0, #0x1e
    8788:      	cset	w3, eq
    878c:      	add	x1, x19, x1
    8790:      	ldr	w1, [x1]
    8794:      	cmp	x0, #0x1f
    8798:      	b.eq	0x8850 <_stogir.vector-arithmetic.validate+0x304>
    879c:      	cmp	x0, #0x20
    87a0:      	b.eq	0x8850 <_stogir.vector-arithmetic.validate+0x304>
    87a4:      	cmp	x0, #0x2d
    87a8:      	b.eq	0x8850 <_stogir.vector-arithmetic.validate+0x304>
    87ac:      	cmp	x0, #0x36
    87b0:      	b.eq	0x8850 <_stogir.vector-arithmetic.validate+0x304>
    87b4:      	cmp	x0, #0x37
    87b8:      	b.eq	0x8850 <_stogir.vector-arithmetic.validate+0x304>
    87bc:      	cmp	x0, #0x38
    87c0:      	b.eq	0x8850 <_stogir.vector-arithmetic.validate+0x304>
    87c4:      	cmp	x0, #0x39
    87c8:      	b.eq	0x8850 <_stogir.vector-arithmetic.validate+0x304>
    87cc:      	uxtb	w16, w2
    87d0:      	cmp	w16, wzr
    87d4:      	b.ne	0x88a8 <_stogir.vector-arithmetic.validate+0x35c>
    87d8:      	uxtb	w16, w3
    87dc:      	cmp	w16, wzr
    87e0:      	b.ne	0x88a8 <_stogir.vector-arithmetic.validate+0x35c>
    87e4:      	mov	x0, #0x2                ; =2
    87e8:      	b	0x88ac <_stogir.vector-arithmetic.validate+0x360>
    87ec:      	movz	x4, #0x0, lsl #48
    87f0:      	b	0x8620 <_stogir.vector-arithmetic.validate+0xd4>
    87f4:      	add	x16, sp, #0x10
    87f8:      	ldr	w2, [x16, #0xc]
    87fc:      	sxtw	x2, w2
    8800:      	lsr	w1, w1, #0
    8804:      	lsr	w4, w4, #0
    8808:      	lsr	w20, w20, #0
    880c:      	lsr	w2, w2, #0
    8810:      	ubfx	x0, x0, #8, #8
    8814:      	lsr	w0, w0, #0
    8818:      	add	x8, sp, #0x20
    881c:      	mov	w3, w1
    8820:      	mov	w1, w20
    8824:      	mov	w5, w2
    8828:      	mov	w2, w0
    882c:      	mov	x0, x22
    8830:      	bl	0x8830 <_stogir.vector-arithmetic.validate+0x2e4>
		0000000000008830:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    8834:      	add	x16, sp, #0x20
    8838:      	ldr	x0, [x16]
    883c:      	add	x16, sp, #0x20
    8840:      	ldr	x1, [x16, #0x8]
    8844:      	add	x16, sp, #0x20
    8848:      	ldr	x2, [x16, #0x10]
    884c:      	b	0x8724 <_stogir.vector-arithmetic.validate+0x1d8>
    8850:      	mov	x0, #0x1                ; =1
    8854:      	sxtw	x1, w1
    8858:      	lsr	w0, w0, #0
    885c:      	sxtw	x0, w0
    8860:      	cmp	x1, x0
    8864:      	b.ne	0x870c <_stogir.vector-arithmetic.validate+0x1c0>
    8868:      	add	x16, sp, #0x10
    886c:      	ldr	w0, [x16]
    8870:      	add	x16, sp, #0x10
    8874:      	ldr	w1, [x16, #0x4]
    8878:      	add	x16, sp, #0x10
    887c:      	ldr	w4, [x16, #0x8]
    8880:      	uxtb	w16, w2
    8884:      	cmp	w16, wzr
    8888:      	b.ne	0x87f4 <_stogir.vector-arithmetic.validate+0x2a8>
    888c:      	uxtb	w16, w3
    8890:      	cmp	w16, wzr
    8894:      	b.ne	0x87f4 <_stogir.vector-arithmetic.validate+0x2a8>
    8898:      	movz	x2, #0x0, lsl #48
    889c:      	b	0x8800 <_stogir.vector-arithmetic.validate+0x2b4>
    88a0:      	brk	#0
    88a4:      	b	0x88a0 <_stogir.vector-arithmetic.validate+0x354>
    88a8:      	mov	x0, #0x3                ; =3
    88ac:      	b	0x8854 <_stogir.vector-arithmetic.validate+0x308>

00000000000088b0 <_stogir.vector.memory-inputs>:
    88b0:      	sub	sp, sp, #0x40
    88b4:      	str	x29, [sp]
    88b8:      	str	x30, [sp, #0x8]
    88bc:      	mov	x29, sp
    88c0:      	str	x19, [sp, #0x10]
    88c4:      	str	x20, [sp, #0x18]
    88c8:      	str	x21, [sp, #0x20]
    88cc:      	str	x22, [sp, #0x28]
    88d0:      	str	x23, [sp, #0x30]
    88d4:      	str	x24, [sp, #0x38]
    88d8:      	sxtw	x5, w1
    88dc:      	cmp	x5, #0xf
    88e0:      	b.le	0x8db0 <_stogir.vector.memory-inputs+0x500>
    88e4:      	cmp	x5, #0x80
    88e8:      	b.ge	0x8db8 <_stogir.vector.memory-inputs+0x508>
    88ec:      	and	x6, x5, #0xf
    88f0:      	lsr	w6, w6, #0
    88f4:      	sxtw	x6, w6
    88f8:      	cmp	x6, #0x1
    88fc:      	b.lt	0x8dc0 <_stogir.vector.memory-inputs+0x510>
    8900:      	and	x5, x5, #0xf
    8904:      	lsr	w5, w5, #0
    8908:      	sxtw	x5, w5
    890c:      	cmp	x5, #0xd
    8910:      	b.gt	0x8dc8 <_stogir.vector.memory-inputs+0x518>
    8914:      	lsr	w1, w1, #0
    8918:      	lsr	w2, w2, #0
    891c:      	mov	x19, x8
    8920:      	mov	x20, x0
    8924:      	mov	w0, w1
    8928:      	mov	w21, w1
    892c:      	mov	w1, w2
    8930:      	mov	w22, w2
    8934:      	mov	w23, w3
    8938:      	mov	w24, w4
    893c:      	bl	0x893c <_stogir.vector.memory-inputs+0x8c>
		000000000000893c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8940:      	lsr	w0, w0, #0
    8944:      	sxtw	x0, w0
    8948:      	cmp	x0, #0x0
    894c:      	b.le	0x89b4 <_stogir.vector.memory-inputs+0x104>
    8950:      	sxtw	x23, w23
    8954:      	cmp	x23, #0x0
    8958:      	cset	w0, gt
    895c:      	movz	x16, #0x0, lsl #48
    8960:      	sub	x1, x16, x23
    8964:      	sub	x2, x1, #0x1
    8968:      	uxtb	w16, w0
    896c:      	cmp	w16, wzr
    8970:      	b.eq	0x8aa4 <_stogir.vector.memory-inputs+0x1f4>
    8974:      	ldr	x1, [x20, #0x8]
    8978:      	cmp	x23, x1
    897c:      	b.ge	0x8a9c <_stogir.vector.memory-inputs+0x1ec>
    8980:      	add	x1, x20, #0x78
    8984:      	ldr	x1, [x1, #0x8]
    8988:      	cmp	x23, x1
    898c:      	b.ge	0x8b4c <_stogir.vector.memory-inputs+0x29c>
    8990:      	lsl	x1, x23, #2
    8994:      	ldr	x1, [x20, #0x78]
    8998:      	add	x1, x1, x23, lsl #2
    899c:      	ldr	w1, [x1]
    89a0:      	sxtw	x1, w1
    89a4:      	cmp	x1, #0x0
    89a8:      	cset	w1, ge
    89ac:      	ubfx	x1, x1, #0, #8
    89b0:      	b	0x8b50 <_stogir.vector.memory-inputs+0x2a0>
    89b4:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		00000000000089b4:  ARM64_RELOC_PAGE21	l_stogir.416
    89b8:      	ldr	x16, [x16]
		00000000000089b8:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    89bc:      	orr	x0, x16, xzr
    89c0:      	mov	x1, x0
    89c4:      	mov	x0, #0x1                ; =1
    89c8:      	mov	x2, #0x32               ; =50
    89cc:      	str	x0, [x19]
    89d0:      	str	x1, [x19, #0x8]
    89d4:      	str	x2, [x19, #0x10]
    89d8:      	ldr	x19, [sp, #0x10]
    89dc:      	ldr	x20, [sp, #0x18]
    89e0:      	ldr	x21, [sp, #0x20]
    89e4:      	ldr	x22, [sp, #0x28]
    89e8:      	ldr	x23, [sp, #0x30]
    89ec:      	ldr	x24, [sp, #0x38]
    89f0:      	ldr	x29, [sp]
    89f4:      	ldr	x30, [sp, #0x8]
    89f8:      	add	sp, sp, #0x40
    89fc:      	ret
    8a00:      	movz	x0, #0x0, lsl #48
    8a04:      	movz	x1, #0x0, lsl #48
    8a08:      	lsr	w0, w0, #0
    8a0c:      	lsr	x16, x0, #0
    8a10:      	cmp	x16, #0x1
    8a14:      	b.eq	0x8a30 <_stogir.vector.memory-inputs+0x180>
    8a18:      	b.lo	0x8a20 <_stogir.vector.memory-inputs+0x170>
    8a1c:      	b	0x8a34 <_stogir.vector.memory-inputs+0x184>
    8a20:      	cmp	x16, #0x0
    8a24:      	b.eq	0x8a2c <_stogir.vector.memory-inputs+0x17c>
    8a28:      	b	0x8a34 <_stogir.vector.memory-inputs+0x184>
    8a2c:      	b	0x8a38 <_stogir.vector.memory-inputs+0x188>
    8a30:      	b	0x8af0 <_stogir.vector.memory-inputs+0x240>
    8a34:      	b	0x8d98 <_stogir.vector.memory-inputs+0x4e8>
    8a38:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		0000000000008a38:  ARM64_RELOC_PAGE21	l_stogir.417
    8a3c:      	ldr	x16, [x16]
		0000000000008a3c:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    8a40:      	orr	x0, x16, xzr
    8a44:      	mov	x1, x0
    8a48:      	mov	x0, #0x1                ; =1
    8a4c:      	mov	x2, #0x1d               ; =29
    8a50:      	b	0x89cc <_stogir.vector.memory-inputs+0x11c>
    8a54:      	lsl	x0, x2, #4
    8a58:      	ldr	x0, [x20, #0x28]
    8a5c:      	add	x0, x0, x2, lsl #4
    8a60:      	ldr	x0, [x0]
    8a64:      	mov	x1, x0
    8a68:      	mov	x0, #0x1                ; =1
    8a6c:      	b	0x8a08 <_stogir.vector.memory-inputs+0x158>
    8a70:      	movz	x1, #0x0, lsl #48
    8a74:      	cmp	x1, #0x0
    8a78:      	b.eq	0x8a00 <_stogir.vector.memory-inputs+0x150>
    8a7c:      	uxtb	w16, w0
    8a80:      	cmp	w16, wzr
    8a84:      	b.eq	0x8a54 <_stogir.vector.memory-inputs+0x1a4>
    8a88:      	lsl	x0, x23, #4
    8a8c:      	ldr	x0, [x20]
    8a90:      	add	x0, x0, x23, lsl #4
    8a94:      	ldr	x0, [x0]
    8a98:      	b	0x8a64 <_stogir.vector.memory-inputs+0x1b4>
    8a9c:      	movz	x1, #0x0, lsl #48
    8aa0:      	b	0x8a74 <_stogir.vector.memory-inputs+0x1c4>
    8aa4:      	cmp	x23, #0x0
    8aa8:      	b.ge	0x8a70 <_stogir.vector.memory-inputs+0x1c0>
    8aac:      	add	x3, x20, #0x28
    8ab0:      	add	x4, x20, #0x50
    8ab4:      	ldr	x3, [x3, #0x8]
    8ab8:      	ldr	x4, [x4, #0x8]
    8abc:      	cmp	x3, x4
    8ac0:      	b.ne	0x8b44 <_stogir.vector.memory-inputs+0x294>
    8ac4:      	cmp	x1, x3
    8ac8:      	b.gt	0x8b54 <_stogir.vector.memory-inputs+0x2a4>
    8acc:      	lsl	x1, x2, #2
    8ad0:      	ldr	x1, [x20, #0x50]
    8ad4:      	add	x1, x1, x2, lsl #2
    8ad8:      	ldr	w1, [x1]
    8adc:      	sxtw	x1, w1
    8ae0:      	cmp	x1, #0x0
    8ae4:      	cset	w1, gt
    8ae8:      	ubfx	x1, x1, #0, #8
    8aec:      	b	0x8b58 <_stogir.vector.memory-inputs+0x2a8>
    8af0:      	cmp	x23, #0x0
    8af4:      	b.le	0x8b28 <_stogir.vector.memory-inputs+0x278>
    8af8:      	uxtb	w1, w1
    8afc:      	cmp	x1, #0x83
    8b00:      	cset	w0, lt
    8b04:      	uxtb	w16, w0
    8b08:      	cmp	w16, wzr
    8b0c:      	b.eq	0x8b5c <_stogir.vector.memory-inputs+0x2ac>
    8b10:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		0000000000008b10:  ARM64_RELOC_PAGE21	l_stogir.418
    8b14:      	ldr	x16, [x16]
		0000000000008b14:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8b18:      	orr	x2, x16, xzr
    8b1c:      	add	x2, x1, x2
    8b20:      	ldrb	w2, [x2]
    8b24:      	b	0x8b60 <_stogir.vector.memory-inputs+0x2b0>
    8b28:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		0000000000008b28:  ARM64_RELOC_PAGE21	l_stogir.419
    8b2c:      	ldr	x16, [x16]
		0000000000008b2c:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    8b30:      	orr	x0, x16, xzr
    8b34:      	mov	x1, x0
    8b38:      	mov	x0, #0x1                ; =1
    8b3c:      	mov	x2, #0x2c               ; =44
    8b40:      	b	0x8a50 <_stogir.vector.memory-inputs+0x1a0>
    8b44:      	movz	x1, #0x0, lsl #48
    8b48:      	b	0x8a74 <_stogir.vector.memory-inputs+0x1c4>
    8b4c:      	movz	x1, #0x0, lsl #48
    8b50:      	b	0x8aa0 <_stogir.vector.memory-inputs+0x1f0>
    8b54:      	movz	x1, #0x0, lsl #48
    8b58:      	b	0x8b48 <_stogir.vector.memory-inputs+0x298>
    8b5c:      	movz	x2, #0x0, lsl #48
    8b60:      	uxtb	w2, w2
    8b64:      	and	x2, x2, #0x1
    8b68:      	uxtb	w2, w2
    8b6c:      	cmp	x2, #0x0
    8b70:      	b.eq	0x8b28 <_stogir.vector.memory-inputs+0x278>
    8b74:      	uxtb	w16, w0
    8b78:      	cmp	w16, wzr
    8b7c:      	b.eq	0x8b98 <_stogir.vector.memory-inputs+0x2e8>
    8b80:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		0000000000008b80:  ARM64_RELOC_PAGE21	l_stogir.418
    8b84:      	ldr	x16, [x16]
		0000000000008b84:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8b88:      	orr	x0, x16, xzr
    8b8c:      	add	x0, x1, x0
    8b90:      	ldrb	w0, [x0]
    8b94:      	b	0x8b9c <_stogir.vector.memory-inputs+0x2ec>
    8b98:      	movz	x0, #0x0, lsl #48
    8b9c:      	uxtb	w0, w0
    8ba0:      	and	x0, x0, #0x4
    8ba4:      	uxtb	w0, w0
    8ba8:      	cmp	x0, #0x0
    8bac:      	cset	w0, eq
    8bb0:      	uxtb	w16, w0
    8bb4:      	cmp	w16, wzr
    8bb8:      	cset	x0, eq
    8bbc:      	cmp	x0, #0x0
    8bc0:      	b.ne	0x8b28 <_stogir.vector.memory-inputs+0x278>
    8bc4:      	sxtw	x24, w24
    8bc8:      	cmp	x24, #0x0
    8bcc:      	cset	w0, gt
    8bd0:      	movz	x16, #0x0, lsl #48
    8bd4:      	sub	x1, x16, x24
    8bd8:      	sub	x2, x1, #0x1
    8bdc:      	uxtb	w16, w0
    8be0:      	cmp	w16, wzr
    8be4:      	b.eq	0x8c44 <_stogir.vector.memory-inputs+0x394>
    8be8:      	ldr	x1, [x20, #0x8]
    8bec:      	cmp	x24, x1
    8bf0:      	b.ge	0x8c90 <_stogir.vector.memory-inputs+0x3e0>
    8bf4:      	add	x1, x20, #0x78
    8bf8:      	ldr	x1, [x1, #0x8]
    8bfc:      	cmp	x24, x1
    8c00:      	b.ge	0x8d90 <_stogir.vector.memory-inputs+0x4e0>
    8c04:      	lsl	x1, x24, #2
    8c08:      	ldr	x1, [x20, #0x78]
    8c0c:      	add	x1, x1, x24, lsl #2
    8c10:      	ldr	w1, [x1]
    8c14:      	sxtw	x1, w1
    8c18:      	cmp	x1, #0x0
    8c1c:      	cset	w1, ge
    8c20:      	ubfx	x1, x1, #0, #8
    8c24:      	b	0x8d94 <_stogir.vector.memory-inputs+0x4e4>
    8c28:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		0000000000008c28:  ARM64_RELOC_PAGE21	l_stogir.420
    8c2c:      	ldr	x16, [x16]
		0000000000008c2c:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    8c30:      	orr	x0, x16, xzr
    8c34:      	mov	x1, x0
    8c38:      	mov	x0, #0x1                ; =1
    8c3c:      	mov	x2, #0x2b               ; =43
    8c40:      	b	0x8b40 <_stogir.vector.memory-inputs+0x290>
    8c44:      	cmp	x24, #0x0
    8c48:      	b.ge	0x8c98 <_stogir.vector.memory-inputs+0x3e8>
    8c4c:      	add	x3, x20, #0x28
    8c50:      	add	x4, x20, #0x50
    8c54:      	ldr	x3, [x3, #0x8]
    8c58:      	ldr	x4, [x4, #0x8]
    8c5c:      	cmp	x3, x4
    8c60:      	b.ne	0x8d88 <_stogir.vector.memory-inputs+0x4d8>
    8c64:      	cmp	x1, x3
    8c68:      	b.gt	0x8da0 <_stogir.vector.memory-inputs+0x4f0>
    8c6c:      	lsl	x1, x2, #2
    8c70:      	ldr	x1, [x20, #0x50]
    8c74:      	add	x1, x1, x2, lsl #2
    8c78:      	ldr	w1, [x1]
    8c7c:      	sxtw	x1, w1
    8c80:      	cmp	x1, #0x0
    8c84:      	cset	w1, gt
    8c88:      	ubfx	x1, x1, #0, #8
    8c8c:      	b	0x8da4 <_stogir.vector.memory-inputs+0x4f4>
    8c90:      	movz	x1, #0x0, lsl #48
    8c94:      	b	0x8c9c <_stogir.vector.memory-inputs+0x3ec>
    8c98:      	movz	x1, #0x0, lsl #48
    8c9c:      	cmp	x1, #0x0
    8ca0:      	b.eq	0x8ce0 <_stogir.vector.memory-inputs+0x430>
    8ca4:      	uxtb	w16, w0
    8ca8:      	cmp	w16, wzr
    8cac:      	b.eq	0x8cc4 <_stogir.vector.memory-inputs+0x414>
    8cb0:      	lsl	x0, x24, #4
    8cb4:      	ldr	x0, [x20]
    8cb8:      	add	x0, x0, x24, lsl #4
    8cbc:      	ldr	x0, [x0]
    8cc0:      	b	0x8cd4 <_stogir.vector.memory-inputs+0x424>
    8cc4:      	lsl	x0, x2, #4
    8cc8:      	ldr	x0, [x20, #0x28]
    8ccc:      	add	x0, x0, x2, lsl #4
    8cd0:      	ldr	x0, [x0]
    8cd4:      	mov	x1, x0
    8cd8:      	mov	x0, #0x1                ; =1
    8cdc:      	b	0x8ce8 <_stogir.vector.memory-inputs+0x438>
    8ce0:      	movz	x0, #0x0, lsl #48
    8ce4:      	movz	x1, #0x0, lsl #48
    8ce8:      	lsr	w0, w0, #0
    8cec:      	lsr	x16, x0, #0
    8cf0:      	cmp	x16, #0x1
    8cf4:      	b.eq	0x8d10 <_stogir.vector.memory-inputs+0x460>
    8cf8:      	b.lo	0x8d00 <_stogir.vector.memory-inputs+0x450>
    8cfc:      	b	0x8d14 <_stogir.vector.memory-inputs+0x464>
    8d00:      	cmp	x16, #0x0
    8d04:      	b.eq	0x8d0c <_stogir.vector.memory-inputs+0x45c>
    8d08:      	b	0x8d14 <_stogir.vector.memory-inputs+0x464>
    8d0c:      	b	0x8d18 <_stogir.vector.memory-inputs+0x468>
    8d10:      	b	0x8d34 <_stogir.vector.memory-inputs+0x484>
    8d14:      	b	0x8da8 <_stogir.vector.memory-inputs+0x4f8>
    8d18:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		0000000000008d18:  ARM64_RELOC_PAGE21	l_stogir.421
    8d1c:      	ldr	x16, [x16]
		0000000000008d1c:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    8d20:      	orr	x0, x16, xzr
    8d24:      	mov	x1, x0
    8d28:      	mov	x0, #0x1                ; =1
    8d2c:      	mov	x2, #0x1d               ; =29
    8d30:      	b	0x8c40 <_stogir.vector.memory-inputs+0x390>
    8d34:      	lsr	w0, w1, #0
    8d38:      	ubfx	x0, x0, #8, #8
    8d3c:      	cmp	x0, #0x6
    8d40:      	b.ne	0x8c28 <_stogir.vector.memory-inputs+0x378>
    8d44:      	uxtb	w1, w1
    8d48:      	cmp	x1, #0x48
    8d4c:      	b.eq	0x8c28 <_stogir.vector.memory-inputs+0x378>
    8d50:      	cmp	x1, #0x46
    8d54:      	b.eq	0x8c28 <_stogir.vector.memory-inputs+0x378>
    8d58:      	lsr	w21, w21, #0
    8d5c:      	lsr	w22, w22, #0
    8d60:      	mov	w0, w21
    8d64:      	mov	w1, w22
    8d68:      	bl	0x8d68 <_stogir.vector.memory-inputs+0x4b8>
		0000000000008d68:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8d6c:      	lsr	w0, w0, #0
    8d70:      	sxtw	x0, w0
    8d74:      	and	x0, x0, #0xffffffff
    8d78:      	mov	x1, x0
    8d7c:      	movz	x0, #0x0, lsl #48
    8d80:      	movz	x2, #0x0, lsl #48
    8d84:      	b	0x8c40 <_stogir.vector.memory-inputs+0x390>
    8d88:      	movz	x1, #0x0, lsl #48
    8d8c:      	b	0x8c9c <_stogir.vector.memory-inputs+0x3ec>
    8d90:      	movz	x1, #0x0, lsl #48
    8d94:      	b	0x8c94 <_stogir.vector.memory-inputs+0x3e4>
    8d98:      	brk	#0
    8d9c:      	b	0x8d98 <_stogir.vector.memory-inputs+0x4e8>
    8da0:      	movz	x1, #0x0, lsl #48
    8da4:      	b	0x8d8c <_stogir.vector.memory-inputs+0x4dc>
    8da8:      	brk	#0
    8dac:      	b	0x8da8 <_stogir.vector.memory-inputs+0x4f8>
    8db0:      	mov	x19, x8
    8db4:      	b	0x89b4 <_stogir.vector.memory-inputs+0x104>
    8db8:      	mov	x19, x8
    8dbc:      	b	0x89b4 <_stogir.vector.memory-inputs+0x104>
    8dc0:      	mov	x19, x8
    8dc4:      	b	0x89b4 <_stogir.vector.memory-inputs+0x104>
    8dc8:      	mov	x19, x8
    8dcc:      	b	0x89b4 <_stogir.vector.memory-inputs+0x104>

0000000000008dd0 <_stogir.vector.store-inputs>:
    8dd0:      	sub	sp, sp, #0x40
    8dd4:      	str	x29, [sp]
    8dd8:      	str	x30, [sp, #0x8]
    8ddc:      	mov	x29, sp
    8de0:      	str	x19, [sp, #0x30]
    8de4:      	sxtw	x4, w4
    8de8:      	cmp	x4, #0x0
    8dec:      	cset	w5, gt
    8df0:      	movz	x16, #0x0, lsl #48
    8df4:      	sub	x6, x16, x4
    8df8:      	sub	x7, x6, #0x1
    8dfc:      	uxtb	w16, w5
    8e00:      	cmp	w16, wzr
    8e04:      	b.eq	0x8e48 <_stogir.vector.store-inputs+0x78>
    8e08:      	ldr	x6, [x0, #0x8]
    8e0c:      	cmp	x4, x6
    8e10:      	b.ge	0x8e9c <_stogir.vector.store-inputs+0xcc>
    8e14:      	add	x6, x0, #0x78
    8e18:      	ldr	x6, [x6, #0x8]
    8e1c:      	cmp	x4, x6
    8e20:      	b.ge	0x8fb4 <_stogir.vector.store-inputs+0x1e4>
    8e24:      	lsl	x6, x4, #2
    8e28:      	ldr	x6, [x0, #0x78]
    8e2c:      	add	x6, x6, x4, lsl #2
    8e30:      	ldr	w6, [x6]
    8e34:      	sxtw	x6, w6
    8e38:      	cmp	x6, #0x0
    8e3c:      	cset	w6, ge
    8e40:      	ubfx	x6, x6, #0, #8
    8e44:      	b	0x8fb8 <_stogir.vector.store-inputs+0x1e8>
    8e48:      	cmp	x4, #0x0
    8e4c:      	b.ge	0x8ea4 <_stogir.vector.store-inputs+0xd4>
    8e50:      	add	x9, x0, #0x28
    8e54:      	add	x10, x0, #0x50
    8e58:      	ldr	x9, [x9, #0x8]
    8e5c:      	ldr	x10, [x10, #0x8]
    8e60:      	cmp	x9, x10
    8e64:      	b.ne	0x8e94 <_stogir.vector.store-inputs+0xc4>
    8e68:      	cmp	x6, x9
    8e6c:      	b.gt	0x8fbc <_stogir.vector.store-inputs+0x1ec>
    8e70:      	lsl	x6, x7, #2
    8e74:      	ldr	x6, [x0, #0x50]
    8e78:      	add	x6, x6, x7, lsl #2
    8e7c:      	ldr	w6, [x6]
    8e80:      	sxtw	x6, w6
    8e84:      	cmp	x6, #0x0
    8e88:      	cset	w6, gt
    8e8c:      	ubfx	x6, x6, #0, #8
    8e90:      	b	0x8fc0 <_stogir.vector.store-inputs+0x1f0>
    8e94:      	movz	x6, #0x0, lsl #48
    8e98:      	b	0x8ea8 <_stogir.vector.store-inputs+0xd8>
    8e9c:      	movz	x6, #0x0, lsl #48
    8ea0:      	b	0x8ea8 <_stogir.vector.store-inputs+0xd8>
    8ea4:      	movz	x6, #0x0, lsl #48
    8ea8:      	cmp	x6, #0x0
    8eac:      	b.eq	0x8eec <_stogir.vector.store-inputs+0x11c>
    8eb0:      	uxtb	w16, w5
    8eb4:      	cmp	w16, wzr
    8eb8:      	b.eq	0x8ed0 <_stogir.vector.store-inputs+0x100>
    8ebc:      	lsl	x5, x4, #4
    8ec0:      	ldr	x5, [x0]
    8ec4:      	add	x4, x5, x4, lsl #4
    8ec8:      	ldr	x4, [x4]
    8ecc:      	b	0x8ee0 <_stogir.vector.store-inputs+0x110>
    8ed0:      	lsl	x4, x7, #4
    8ed4:      	ldr	x4, [x0, #0x28]
    8ed8:      	add	x4, x4, x7, lsl #4
    8edc:      	ldr	x4, [x4]
    8ee0:      	mov	x5, x4
    8ee4:      	mov	x4, #0x1                ; =1
    8ee8:      	b	0x8ef4 <_stogir.vector.store-inputs+0x124>
    8eec:      	movz	x4, #0x0, lsl #48
    8ef0:      	movz	x5, #0x0, lsl #48
    8ef4:      	lsr	w4, w4, #0
    8ef8:      	lsr	x16, x4, #0
    8efc:      	cmp	x16, #0x1
    8f00:      	b.eq	0x8f1c <_stogir.vector.store-inputs+0x14c>
    8f04:      	b.lo	0x8f0c <_stogir.vector.store-inputs+0x13c>
    8f08:      	b	0x8f20 <_stogir.vector.store-inputs+0x150>
    8f0c:      	cmp	x16, #0x0
    8f10:      	b.eq	0x8f18 <_stogir.vector.store-inputs+0x148>
    8f14:      	b	0x8f20 <_stogir.vector.store-inputs+0x150>
    8f18:      	b	0x8f24 <_stogir.vector.store-inputs+0x154>
    8f1c:      	b	0x8f44 <_stogir.vector.store-inputs+0x174>
    8f20:      	b	0x8fc4 <_stogir.vector.store-inputs+0x1f4>
    8f24:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0xac>
		0000000000008f24:  ARM64_RELOC_PAGE21	l_stogir.422
    8f28:      	ldr	x16, [x16]
		0000000000008f28:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    8f2c:      	orr	x0, x16, xzr
    8f30:      	mov	x19, x8
    8f34:      	mov	x1, x0
    8f38:      	mov	x0, #0x1                ; =1
    8f3c:      	mov	x2, #0x1a               ; =26
    8f40:      	b	0x8f94 <_stogir.vector.store-inputs+0x1c4>
    8f44:      	lsr	w1, w1, #0
    8f48:      	lsr	w2, w2, #0
    8f4c:      	lsr	w3, w3, #0
    8f50:      	lsr	w5, w5, #0
    8f54:      	ubfx	x4, x5, #8, #8
    8f58:      	lsr	w4, w4, #0
    8f5c:      	mov	x19, x8
    8f60:      	add	x8, sp, #0x10
    8f64:      	fmov	s31, w1
    8f68:      	mov	w1, w4
    8f6c:      	mov	w4, w3
    8f70:      	mov	w3, w2
    8f74:      	fmov	w2, s31
    8f78:      	bl	0x8f78 <_stogir.vector.store-inputs+0x1a8>
		0000000000008f78:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    8f7c:      	add	x16, sp, #0x10
    8f80:      	ldr	x0, [x16]
    8f84:      	add	x16, sp, #0x10
    8f88:      	ldr	x1, [x16, #0x8]
    8f8c:      	add	x16, sp, #0x10
    8f90:      	ldr	x2, [x16, #0x10]
    8f94:      	str	x0, [x19]
    8f98:      	str	x1, [x19, #0x8]
    8f9c:      	str	x2, [x19, #0x10]
    8fa0:      	ldr	x19, [sp, #0x30]
    8fa4:      	ldr	x29, [sp]
    8fa8:      	ldr	x30, [sp, #0x8]
    8fac:      	add	sp, sp, #0x40
    8fb0:      	ret
    8fb4:      	movz	x6, #0x0, lsl #48
    8fb8:      	b	0x8ea0 <_stogir.vector.store-inputs+0xd0>
    8fbc:      	movz	x6, #0x0, lsl #48
    8fc0:      	b	0x8e98 <_stogir.vector.store-inputs+0xc8>
    8fc4:      	brk	#0
    8fc8:      	b	0x8fc4 <_stogir.vector.store-inputs+0x1f4>

0000000000008fcc <_stogir.types.size>:
    8fcc:      	sub	sp, sp, #0x60
    8fd0:      	str	x29, [sp]
    8fd4:      	str	x30, [sp, #0x8]
    8fd8:      	mov	x29, sp
    8fdc:      	str	x19, [sp, #0x10]
    8fe0:      	str	x20, [sp, #0x18]
    8fe4:      	str	x21, [sp, #0x20]
    8fe8:      	str	x22, [sp, #0x28]
    8fec:      	str	x23, [sp, #0x30]
    8ff0:      	str	x24, [sp, #0x38]
    8ff4:      	str	x25, [sp, #0x40]
    8ff8:      	str	x26, [sp, #0x48]
    8ffc:      	str	x27, [sp, #0x50]
    9000:      	str	x28, [sp, #0x58]
    9004:      	sxtw	x19, w0
    9008:      	sxtw	x20, w1
    900c:      	cmp	x19, #0xf
    9010:      	cset	w21, gt
    9014:      	cmp	x19, #0x0
    9018:      	cset	w22, eq
    901c:      	cmp	x20, #0x4
    9020:      	cset	w23, eq
    9024:      	cmp	x20, #0x8
    9028:      	cset	w24, eq
    902c:      	uxtb	w16, w21
    9030:      	cmp	w16, wzr
    9034:      	b.eq	0x9098 <_stogir.types.size+0xcc>
    9038:      	cmp	x19, #0x80
    903c:      	cset	w25, lt
    9040:      	uxtb	w16, w25
    9044:      	cmp	w16, wzr
    9048:      	b.eq	0x9098 <_stogir.types.size+0xcc>
    904c:      	and	x1, x19, #0xf
    9050:      	lsr	w1, w1, #0
    9054:      	sxtw	x26, w1
    9058:      	cmp	x26, #0x1
    905c:      	cset	w27, ge
    9060:      	uxtb	w16, w27
    9064:      	cmp	w16, wzr
    9068:      	b.eq	0x9098 <_stogir.types.size+0xcc>
    906c:      	cmp	x26, #0xd
    9070:      	cset	w28, le
    9074:      	uxtb	w16, w28
    9078:      	cmp	w16, wzr
    907c:      	b.eq	0x9098 <_stogir.types.size+0xcc>
    9080:      	lsr	w0, w0, #0
    9084:      	bl	0x9084 <_stogir.types.size+0xb8>
		0000000000009084:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    9088:      	cmp	x0, #0x0
    908c:      	b.eq	0x9178 <_stogir.types.size+0x1ac>
    9090:      	mov	x0, x26
    9094:      	b	0x917c <_stogir.types.size+0x1b0>
    9098:      	uxtb	w16, w23
    909c:      	cmp	w16, wzr
    90a0:      	b.ne	0x90b8 <_stogir.types.size+0xec>
    90a4:      	uxtb	w16, w24
    90a8:      	cmp	w16, wzr
    90ac:      	b.ne	0x90b8 <_stogir.types.size+0xec>
    90b0:      	movn	x0, #0x0, lsl #48
    90b4:      	b	0x90d0 <_stogir.types.size+0x104>
    90b8:      	uxtb	w16, w22
    90bc:      	cmp	w16, wzr
    90c0:      	b.eq	0x9108 <_stogir.types.size+0x13c>
    90c4:      	movz	x0, #0x0, lsl #48
    90c8:      	b	0x90d0 <_stogir.types.size+0x104>
    90cc:      	mov	x0, #0x1                ; =1
    90d0:      	ldr	x19, [sp, #0x10]
    90d4:      	ldr	x20, [sp, #0x18]
    90d8:      	ldr	x21, [sp, #0x20]
    90dc:      	ldr	x22, [sp, #0x28]
    90e0:      	ldr	x23, [sp, #0x30]
    90e4:      	ldr	x24, [sp, #0x38]
    90e8:      	ldr	x25, [sp, #0x40]
    90ec:      	ldr	x26, [sp, #0x48]
    90f0:      	ldr	x27, [sp, #0x50]
    90f4:      	ldr	x28, [sp, #0x58]
    90f8:      	ldr	x29, [sp]
    90fc:      	ldr	x30, [sp, #0x8]
    9100:      	add	sp, sp, #0x60
    9104:      	ret
    9108:      	cmp	x19, #0x1
    910c:      	b.eq	0x90cc <_stogir.types.size+0x100>
    9110:      	cmp	x19, #0x2
    9114:      	b.eq	0x90cc <_stogir.types.size+0x100>
    9118:      	cmp	x19, #0x7
    911c:      	b.eq	0x90cc <_stogir.types.size+0x100>
    9120:      	cmp	x19, #0x8
    9124:      	b.eq	0x90cc <_stogir.types.size+0x100>
    9128:      	cmp	x19, #0x3
    912c:      	b.eq	0x92e8 <_stogir.types.size+0x31c>
    9130:      	cmp	x19, #0x9
    9134:      	b.eq	0x92e8 <_stogir.types.size+0x31c>
    9138:      	cmp	x19, #0x4
    913c:      	b.eq	0x9310 <_stogir.types.size+0x344>
    9140:      	cmp	x19, #0xa
    9144:      	b.eq	0x9310 <_stogir.types.size+0x344>
    9148:      	cmp	x19, #0xd
    914c:      	b.eq	0x9310 <_stogir.types.size+0x344>
    9150:      	cmp	x19, #0x5
    9154:      	b.eq	0x9320 <_stogir.types.size+0x354>
    9158:      	cmp	x19, #0xb
    915c:      	b.eq	0x9320 <_stogir.types.size+0x354>
    9160:      	cmp	x19, #0xc
    9164:      	b.eq	0x9320 <_stogir.types.size+0x354>
    9168:      	cmp	x19, #0x6
    916c:      	b.ne	0x9330 <_stogir.types.size+0x364>
    9170:      	mov	x0, x20
    9174:      	b	0x9334 <_stogir.types.size+0x368>
    9178:      	movn	x0, #0x0, lsl #48
    917c:      	uxtb	w16, w23
    9180:      	cmp	w16, wzr
    9184:      	b.ne	0x919c <_stogir.types.size+0x1d0>
    9188:      	uxtb	w16, w24
    918c:      	cmp	w16, wzr
    9190:      	b.ne	0x919c <_stogir.types.size+0x1d0>
    9194:      	movn	x0, #0x0, lsl #48
    9198:      	b	0x91b8 <_stogir.types.size+0x1ec>
    919c:      	lsr	w0, w0, #0
    91a0:      	sxtw	x0, w0
    91a4:      	cmp	x0, #0x0
    91a8:      	b.ne	0x9278 <_stogir.types.size+0x2ac>
    91ac:      	movz	x0, #0x0, lsl #48
    91b0:      	b	0x91b8 <_stogir.types.size+0x1ec>
    91b4:      	mov	x0, #0x1                ; =1
    91b8:      	lsr	w0, w0, #0
    91bc:      	sxtw	x0, w0
    91c0:      	cmp	x0, #0x0
    91c4:      	b.ge	0x9220 <_stogir.types.size+0x254>
    91c8:      	movn	x0, #0x0, lsl #48
    91cc:      	b	0x91e8 <_stogir.types.size+0x21c>
    91d0:      	movn	x1, #0x0, lsl #48
    91d4:      	lsr	w1, w1, #0
    91d8:      	sxtw	x1, w1
    91dc:      	mul	x0, x1, x0
    91e0:      	lsr	w0, w0, #0
    91e4:      	sxtw	x0, w0
    91e8:      	ldr	x19, [sp, #0x10]
    91ec:      	ldr	x20, [sp, #0x18]
    91f0:      	ldr	x21, [sp, #0x20]
    91f4:      	ldr	x22, [sp, #0x28]
    91f8:      	ldr	x23, [sp, #0x30]
    91fc:      	ldr	x24, [sp, #0x38]
    9200:      	ldr	x25, [sp, #0x40]
    9204:      	ldr	x26, [sp, #0x48]
    9208:      	ldr	x27, [sp, #0x50]
    920c:      	ldr	x28, [sp, #0x58]
    9210:      	ldr	x29, [sp]
    9214:      	ldr	x30, [sp, #0x8]
    9218:      	add	sp, sp, #0x60
    921c:      	ret
    9220:      	uxtb	w16, w21
    9224:      	cmp	w16, wzr
    9228:      	b.eq	0x92f0 <_stogir.types.size+0x324>
    922c:      	uxtb	w16, w25
    9230:      	cmp	w16, wzr
    9234:      	b.eq	0x92f0 <_stogir.types.size+0x324>
    9238:      	uxtb	w16, w27
    923c:      	cmp	w16, wzr
    9240:      	b.eq	0x92f0 <_stogir.types.size+0x324>
    9244:      	uxtb	w16, w28
    9248:      	cmp	w16, wzr
    924c:      	b.eq	0x92f0 <_stogir.types.size+0x324>
    9250:      	ubfx	x1, x19, #4, #32
    9254:      	sxtw	x1, w1
    9258:      	sub	x1, x1, #0x1
    925c:      	lsr	w1, w1, #0
    9260:      	sxtw	x1, w1
    9264:      	mov	x16, #0x1               ; =1
    9268:      	lsl	x1, x16, x1
    926c:      	lsr	w1, w1, #0
    9270:      	sxtw	x1, w1
    9274:      	b	0x91d4 <_stogir.types.size+0x208>
    9278:      	cmp	x0, #0x1
    927c:      	b.eq	0x91b4 <_stogir.types.size+0x1e8>
    9280:      	cmp	x0, #0x2
    9284:      	b.eq	0x91b4 <_stogir.types.size+0x1e8>
    9288:      	cmp	x0, #0x7
    928c:      	b.eq	0x91b4 <_stogir.types.size+0x1e8>
    9290:      	cmp	x0, #0x8
    9294:      	b.eq	0x91b4 <_stogir.types.size+0x1e8>
    9298:      	cmp	x0, #0x3
    929c:      	b.eq	0x9318 <_stogir.types.size+0x34c>
    92a0:      	cmp	x0, #0x9
    92a4:      	b.eq	0x9318 <_stogir.types.size+0x34c>
    92a8:      	cmp	x0, #0x4
    92ac:      	b.eq	0x9328 <_stogir.types.size+0x35c>
    92b0:      	cmp	x0, #0xa
    92b4:      	b.eq	0x9328 <_stogir.types.size+0x35c>
    92b8:      	cmp	x0, #0xd
    92bc:      	b.eq	0x9328 <_stogir.types.size+0x35c>
    92c0:      	cmp	x0, #0x5
    92c4:      	b.eq	0x9338 <_stogir.types.size+0x36c>
    92c8:      	cmp	x0, #0xb
    92cc:      	b.eq	0x9338 <_stogir.types.size+0x36c>
    92d0:      	cmp	x0, #0xc
    92d4:      	b.eq	0x9338 <_stogir.types.size+0x36c>
    92d8:      	cmp	x0, #0x6
    92dc:      	b.ne	0x9340 <_stogir.types.size+0x374>
    92e0:      	mov	x0, x20
    92e4:      	b	0x9344 <_stogir.types.size+0x378>
    92e8:      	mov	x0, #0x2                ; =2
    92ec:      	b	0x90d0 <_stogir.types.size+0x104>
    92f0:      	cmp	x19, #0x0
    92f4:      	b.lt	0x91d0 <_stogir.types.size+0x204>
    92f8:      	cmp	x19, #0xd
    92fc:      	b.gt	0x91d0 <_stogir.types.size+0x204>
    9300:      	uxtb	w16, w22
    9304:      	cmp	w16, wzr
    9308:      	cset	x1, eq
    930c:      	b	0x91d4 <_stogir.types.size+0x208>
    9310:      	mov	x0, #0x4                ; =4
    9314:      	b	0x92ec <_stogir.types.size+0x320>
    9318:      	mov	x0, #0x2                ; =2
    931c:      	b	0x91b8 <_stogir.types.size+0x1ec>
    9320:      	mov	x0, #0x8                ; =8
    9324:      	b	0x9314 <_stogir.types.size+0x348>
    9328:      	mov	x0, #0x4                ; =4
    932c:      	b	0x931c <_stogir.types.size+0x350>
    9330:      	movn	x0, #0x0, lsl #48
    9334:      	b	0x9324 <_stogir.types.size+0x358>
    9338:      	mov	x0, #0x8                ; =8
    933c:      	b	0x932c <_stogir.types.size+0x360>
    9340:      	movn	x0, #0x0, lsl #48
    9344:      	b	0x933c <_stogir.types.size+0x370>

0000000000009348 <_stogir.opcode.properties>:
    9348:      	sxtw	x0, w0
    934c:      	cmp	x0, #0x0
    9350:      	b.lt	0x9378 <_stogir.opcode.properties+0x30>
    9354:      	cmp	x0, #0x83
    9358:      	b.ge	0x9378 <_stogir.opcode.properties+0x30>
    935c:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		000000000000935c:  ARM64_RELOC_PAGE21	l_stogir.423
    9360:      	ldr	x16, [x16]
		0000000000009360:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    9364:      	orr	x1, x16, xzr
    9368:      	lsr	x2, x0, #0
    936c:      	add	x0, x1, x0
    9370:      	ldrb	w0, [x0]
    9374:      	b	0x937c <_stogir.opcode.properties+0x34>
    9378:      	movz	x0, #0x0, lsl #48
    937c:      	ret

0000000000009380 <_stogir.checked.projection>:
    9380:      	sub	sp, sp, #0x40
    9384:      	str	x29, [sp]
    9388:      	str	x30, [sp, #0x8]
    938c:      	mov	x29, sp
    9390:      	str	x19, [sp, #0x30]
    9394:      	sxtw	x2, w1
    9398:      	cmp	x2, #0x0
    939c:      	cset	w3, gt
    93a0:      	movz	x16, #0x0, lsl #48
    93a4:      	sub	x4, x16, x2
    93a8:      	sub	x5, x4, #0x1
    93ac:      	uxtb	w16, w3
    93b0:      	cmp	w16, wzr
    93b4:      	b.eq	0x93f8 <_stogir.checked.projection+0x78>
    93b8:      	ldr	x4, [x0, #0x8]
    93bc:      	cmp	x2, x4
    93c0:      	b.ge	0x944c <_stogir.checked.projection+0xcc>
    93c4:      	add	x4, x0, #0x78
    93c8:      	ldr	x4, [x4, #0x8]
    93cc:      	cmp	x2, x4
    93d0:      	b.ge	0x956c <_stogir.checked.projection+0x1ec>
    93d4:      	lsl	x4, x2, #2
    93d8:      	ldr	x4, [x0, #0x78]
    93dc:      	add	x4, x4, x2, lsl #2
    93e0:      	ldr	w4, [x4]
    93e4:      	sxtw	x4, w4
    93e8:      	cmp	x4, #0x0
    93ec:      	cset	w4, ge
    93f0:      	ubfx	x4, x4, #0, #8
    93f4:      	b	0x9570 <_stogir.checked.projection+0x1f0>
    93f8:      	cmp	x2, #0x0
    93fc:      	b.ge	0x9454 <_stogir.checked.projection+0xd4>
    9400:      	add	x6, x0, #0x28
    9404:      	add	x7, x0, #0x50
    9408:      	ldr	x6, [x6, #0x8]
    940c:      	ldr	x7, [x7, #0x8]
    9410:      	cmp	x6, x7
    9414:      	b.ne	0x9444 <_stogir.checked.projection+0xc4>
    9418:      	cmp	x4, x6
    941c:      	b.gt	0x959c <_stogir.checked.projection+0x21c>
    9420:      	lsl	x4, x5, #2
    9424:      	ldr	x4, [x0, #0x50]
    9428:      	add	x4, x4, x5, lsl #2
    942c:      	ldr	w4, [x4]
    9430:      	sxtw	x4, w4
    9434:      	cmp	x4, #0x0
    9438:      	cset	w4, gt
    943c:      	ubfx	x4, x4, #0, #8
    9440:      	b	0x95a0 <_stogir.checked.projection+0x220>
    9444:      	movz	x4, #0x0, lsl #48
    9448:      	b	0x9458 <_stogir.checked.projection+0xd8>
    944c:      	movz	x4, #0x0, lsl #48
    9450:      	b	0x9458 <_stogir.checked.projection+0xd8>
    9454:      	movz	x4, #0x0, lsl #48
    9458:      	cmp	x4, #0x0
    945c:      	b.eq	0x949c <_stogir.checked.projection+0x11c>
    9460:      	uxtb	w16, w3
    9464:      	cmp	w16, wzr
    9468:      	b.eq	0x9480 <_stogir.checked.projection+0x100>
    946c:      	lsl	x3, x2, #4
    9470:      	ldr	x3, [x0]
    9474:      	add	x2, x3, x2, lsl #4
    9478:      	ldr	x2, [x2]
    947c:      	b	0x9490 <_stogir.checked.projection+0x110>
    9480:      	lsl	x2, x5, #4
    9484:      	ldr	x2, [x0, #0x28]
    9488:      	add	x2, x2, x5, lsl #4
    948c:      	ldr	x2, [x2]
    9490:      	mov	x3, x2
    9494:      	mov	x2, #0x1                ; =1
    9498:      	b	0x94a4 <_stogir.checked.projection+0x124>
    949c:      	movz	x2, #0x0, lsl #48
    94a0:      	movz	x3, #0x0, lsl #48
    94a4:      	lsr	w2, w2, #0
    94a8:      	lsr	x16, x2, #0
    94ac:      	cmp	x16, #0x1
    94b0:      	b.eq	0x94cc <_stogir.checked.projection+0x14c>
    94b4:      	b.lo	0x94bc <_stogir.checked.projection+0x13c>
    94b8:      	b	0x94d0 <_stogir.checked.projection+0x150>
    94bc:      	cmp	x16, #0x0
    94c0:      	b.eq	0x94c8 <_stogir.checked.projection+0x148>
    94c4:      	b	0x94d0 <_stogir.checked.projection+0x150>
    94c8:      	b	0x94d4 <_stogir.checked.projection+0x154>
    94cc:      	b	0x952c <_stogir.checked.projection+0x1ac>
    94d0:      	b	0x95a4 <_stogir.checked.projection+0x224>
    94d4:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		00000000000094d4:  ARM64_RELOC_PAGE21	l_stogir.424
    94d8:      	ldr	x16, [x16]
		00000000000094d8:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    94dc:      	orr	x0, x16, xzr
    94e0:      	mov	x19, x8
    94e4:      	mov	x1, x0
    94e8:      	mov	x0, #0x1                ; =1
    94ec:      	mov	x2, #0x17               ; =23
    94f0:      	b	0x950c <_stogir.checked.projection+0x18c>
    94f4:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		00000000000094f4:  ARM64_RELOC_PAGE21	l_stogir.425
    94f8:      	ldr	x16, [x16]
		00000000000094f8:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    94fc:      	orr	x0, x16, xzr
    9500:      	mov	x1, x0
    9504:      	mov	x0, #0x1                ; =1
    9508:      	mov	x2, #0x20               ; =32
    950c:      	str	x0, [x19]
    9510:      	str	x1, [x19, #0x8]
    9514:      	str	x2, [x19, #0x10]
    9518:      	ldr	x19, [sp, #0x30]
    951c:      	ldr	x29, [sp]
    9520:      	ldr	x30, [sp, #0x8]
    9524:      	add	sp, sp, #0x40
    9528:      	ret
    952c:      	uxtb	w2, w3
    9530:      	cmp	x2, #0x29
    9534:      	b.lt	0x95ac <_stogir.checked.projection+0x22c>
    9538:      	cmp	x2, #0x2b
    953c:      	b.gt	0x95b4 <_stogir.checked.projection+0x234>
    9540:      	lsr	w1, w1, #0
    9544:      	mov	x19, x8
    9548:      	add	x8, sp, #0x10
    954c:      	bl	0x954c <_stogir.checked.projection+0x1cc>
		000000000000954c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    9550:      	add	x16, sp, #0x10
    9554:      	ldr	x0, [x16]
    9558:      	add	x16, sp, #0x10
    955c:      	ldr	x1, [x16, #0x8]
    9560:      	add	x16, sp, #0x10
    9564:      	ldr	x2, [x16, #0x10]
    9568:      	b	0x950c <_stogir.checked.projection+0x18c>
    956c:      	movz	x4, #0x0, lsl #48
    9570:      	b	0x9450 <_stogir.checked.projection+0xd0>
    9574:      	lsr	w3, w3, #0
    9578:      	ubfx	x0, x3, #8, #8
    957c:      	cmp	x0, #0x0
    9580:      	b.eq	0x94f4 <_stogir.checked.projection+0x174>
    9584:      	cmp	x0, #0xd
    9588:      	b.gt	0x94f4 <_stogir.checked.projection+0x174>
    958c:      	movz	x0, #0x0, lsl #48
    9590:      	movz	x1, #0x0, lsl #48
    9594:      	movz	x2, #0x0, lsl #48
    9598:      	b	0x950c <_stogir.checked.projection+0x18c>
    959c:      	movz	x4, #0x0, lsl #48
    95a0:      	b	0x9448 <_stogir.checked.projection+0xc8>
    95a4:      	brk	#0
    95a8:      	b	0x95a4 <_stogir.checked.projection+0x224>
    95ac:      	mov	x19, x8
    95b0:      	b	0x9574 <_stogir.checked.projection+0x1f4>
    95b4:      	mov	x19, x8
    95b8:      	b	0x9574 <_stogir.checked.projection+0x1f4>

00000000000095bc <_stogir.checked.operands>:
    95bc:      	sub	sp, sp, #0x30
    95c0:      	str	x19, [sp, #0x20]
    95c4:      	str	x20, [sp, #0x28]
    95c8:      	sxtw	x1, w1
    95cc:      	sxtw	x2, w2
    95d0:      	cmp	x1, #0x29
    95d4:      	b.lt	0x961c <_stogir.checked.operands+0x60>
    95d8:      	cmp	x1, #0x2b
    95dc:      	b.gt	0x961c <_stogir.checked.operands+0x60>
    95e0:      	cmp	x2, #0x1
    95e4:      	b.lt	0x961c <_stogir.checked.operands+0x60>
    95e8:      	cmp	x2, #0xb
    95ec:      	b.gt	0x961c <_stogir.checked.operands+0x60>
    95f0:      	cmp	x2, #0x1
    95f4:      	b.eq	0x961c <_stogir.checked.operands+0x60>
    95f8:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		00000000000095f8:  ARM64_RELOC_PAGE21	l_stogir.426
    95fc:      	ldr	x16, [x16]
		00000000000095fc:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    9600:      	orr	x1, x16, xzr
    9604:      	movz	x5, #0x0, lsl #48
    9608:      	b	0x962c <_stogir.checked.operands+0x70>
    960c:      	movz	x14, #0x0, lsl #48
    9610:      	b	0x9690 <_stogir.checked.operands+0xd4>
    9614:      	movz	x14, #0x0, lsl #48
    9618:      	b	0x96a4 <_stogir.checked.operands+0xe8>
    961c:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		000000000000961c:  ARM64_RELOC_PAGE21	l_stogir.427
    9620:      	ldr	x16, [x16]
		0000000000009620:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    9624:      	orr	x1, x16, xzr
    9628:      	mov	x5, #0x36               ; =54
    962c:      	add	x16, sp, #0x10
    9630:      	orr	x6, x16, xzr
    9634:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009634:  ARM64_RELOC_PAGE21	l_stogir.428
    9638:      	ldr	x16, [x16]
		0000000000009638:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    963c:      	orr	x7, x16, xzr
    9640:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009640:  ARM64_RELOC_PAGE21	l_stogir.429
    9644:      	ldr	x16, [x16]
		0000000000009644:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    9648:      	orr	x9, x16, xzr
    964c:      	lsr	w3, w3, #0
    9650:      	lsr	w4, w4, #0
    9654:      	add	x10, x0, #0x78
    9658:      	add	x11, x0, #0x28
    965c:      	add	x12, x0, #0x50
    9660:      	mov	x16, sp
    9664:      	str	w3, [x16]
    9668:      	mov	x16, sp
    966c:      	str	w4, [x16, #0x4]
    9670:      	mov	x16, sp
    9674:      	ldr	x3, [x16]
    9678:      	add	x16, sp, #0x10
    967c:      	str	x3, [x16]
    9680:      	mov	x3, x5
    9684:      	movz	x4, #0x0, lsl #48
    9688:      	b	0x9754 <_stogir.checked.operands+0x198>
    968c:      	movz	x14, #0x0, lsl #48
    9690:      	fmov	d31, x13
    9694:      	mov	x13, x14
    9698:      	fmov	x14, d31
    969c:      	b	0x96b0 <_stogir.checked.operands+0xf4>
    96a0:      	movz	x14, #0x0, lsl #48
    96a4:      	fmov	d31, x13
    96a8:      	mov	x13, x14
    96ac:      	fmov	x14, d31
    96b0:      	cmp	x13, #0x0
    96b4:      	b.eq	0x96f4 <_stogir.checked.operands+0x138>
    96b8:      	uxtb	w16, w4
    96bc:      	cmp	w16, wzr
    96c0:      	b.eq	0x96d8 <_stogir.checked.operands+0x11c>
    96c4:      	lsl	x4, x5, #4
    96c8:      	ldr	x4, [x0]
    96cc:      	add	x4, x4, x5, lsl #4
    96d0:      	ldr	x4, [x4]
    96d4:      	b	0x96e8 <_stogir.checked.operands+0x12c>
    96d8:      	lsl	x4, x15, #4
    96dc:      	ldr	x4, [x0, #0x28]
    96e0:      	add	x4, x4, x15, lsl #4
    96e4:      	ldr	x4, [x4]
    96e8:      	mov	x5, x4
    96ec:      	mov	x4, #0x1                ; =1
    96f0:      	b	0x96fc <_stogir.checked.operands+0x140>
    96f4:      	movz	x4, #0x0, lsl #48
    96f8:      	movz	x5, #0x0, lsl #48
    96fc:      	lsr	w4, w4, #0
    9700:      	lsr	x16, x4, #0
    9704:      	cmp	x16, #0x1
    9708:      	b.eq	0x9724 <_stogir.checked.operands+0x168>
    970c:      	b.lo	0x9714 <_stogir.checked.operands+0x158>
    9710:      	b	0x9728 <_stogir.checked.operands+0x16c>
    9714:      	cmp	x16, #0x0
    9718:      	b.eq	0x9720 <_stogir.checked.operands+0x164>
    971c:      	b	0x9728 <_stogir.checked.operands+0x16c>
    9720:      	b	0x972c <_stogir.checked.operands+0x170>
    9724:      	b	0x9738 <_stogir.checked.operands+0x17c>
    9728:      	b	0x98b8 <_stogir.checked.operands+0x2fc>
    972c:      	mov	x1, x7
    9730:      	mov	x3, #0x22               ; =34
    9734:      	b	0x9750 <_stogir.checked.operands+0x194>
    9738:      	lsr	w5, w5, #0
    973c:      	ubfx	x4, x5, #8, #8
    9740:      	cmp	x4, x2
    9744:      	b.eq	0x9750 <_stogir.checked.operands+0x194>
    9748:      	mov	x1, x9
    974c:      	mov	x3, #0x28               ; =40
    9750:      	mov	x4, x14
    9754:      	cmp	x4, #0x2
    9758:      	b.ge	0x9784 <_stogir.checked.operands+0x1c8>
    975c:      	add	x5, x4, #0x1
    9760:      	lsl	x13, x4, #2
    9764:      	add	x4, x6, x4, lsl #2
    9768:      	ldr	w4, [x4]
    976c:      	sxtw	x4, w4
    9770:      	and	x4, x4, #0xffffffff
    9774:      	mov	x13, x5
    9778:      	mov	x5, x4
    977c:      	mov	x4, #0x1                ; =1
    9780:      	b	0x9790 <_stogir.checked.operands+0x1d4>
    9784:      	mov	x13, x4
    9788:      	movz	x4, #0x0, lsl #48
    978c:      	movz	x5, #0x0, lsl #48
    9790:      	lsr	w4, w4, #0
    9794:      	lsr	x16, x4, #0
    9798:      	cmp	x16, #0x1
    979c:      	b.eq	0x97b8 <_stogir.checked.operands+0x1fc>
    97a0:      	b.lo	0x97a8 <_stogir.checked.operands+0x1ec>
    97a4:      	b	0x97bc <_stogir.checked.operands+0x200>
    97a8:      	cmp	x16, #0x0
    97ac:      	b.eq	0x97b4 <_stogir.checked.operands+0x1f8>
    97b0:      	b	0x97bc <_stogir.checked.operands+0x200>
    97b4:      	b	0x9824 <_stogir.checked.operands+0x268>
    97b8:      	b	0x97c0 <_stogir.checked.operands+0x204>
    97bc:      	b	0x98b0 <_stogir.checked.operands+0x2f4>
    97c0:      	lsr	w5, w5, #0
    97c4:      	sxtw	x5, w5
    97c8:      	cmp	x5, #0x0
    97cc:      	cset	w4, gt
    97d0:      	movz	x16, #0x0, lsl #48
    97d4:      	sub	x14, x16, x5
    97d8:      	sub	x15, x14, #0x1
    97dc:      	uxtb	w16, w4
    97e0:      	cmp	w16, wzr
    97e4:      	b.eq	0x9864 <_stogir.checked.operands+0x2a8>
    97e8:      	ldr	x14, [x0, #0x8]
    97ec:      	cmp	x5, x14
    97f0:      	b.ge	0x968c <_stogir.checked.operands+0xd0>
    97f4:      	ldr	x14, [x10, #0x8]
    97f8:      	cmp	x5, x14
    97fc:      	b.ge	0x960c <_stogir.checked.operands+0x50>
    9800:      	lsl	x14, x5, #2
    9804:      	ldr	x14, [x0, #0x78]
    9808:      	add	x14, x14, x5, lsl #2
    980c:      	ldr	w14, [x14]
    9810:      	sxtw	x14, w14
    9814:      	cmp	x14, #0x0
    9818:      	cset	w14, ge
    981c:      	ubfx	x14, x14, #0, #8
    9820:      	b	0x9610 <_stogir.checked.operands+0x54>
    9824:      	cmp	x3, #0x0
    9828:      	b.ne	0x9840 <_stogir.checked.operands+0x284>
    982c:      	and	x0, x2, #0xffffffff
    9830:      	mov	x1, x0
    9834:      	movz	x0, #0x0, lsl #48
    9838:      	movz	x2, #0x0, lsl #48
    983c:      	b	0x9848 <_stogir.checked.operands+0x28c>
    9840:      	mov	x2, x3
    9844:      	mov	x0, #0x1                ; =1
    9848:      	str	x0, [x8]
    984c:      	str	x1, [x8, #0x8]
    9850:      	str	x2, [x8, #0x10]
    9854:      	ldr	x19, [sp, #0x20]
    9858:      	ldr	x20, [sp, #0x28]
    985c:      	add	sp, sp, #0x30
    9860:      	ret
    9864:      	cmp	x5, #0x0
    9868:      	b.ge	0x96a0 <_stogir.checked.operands+0xe4>
    986c:      	ldr	x19, [x11, #0x8]
    9870:      	ldr	x20, [x12, #0x8]
    9874:      	cmp	x19, x20
    9878:      	b.ne	0x9614 <_stogir.checked.operands+0x58>
    987c:      	cmp	x14, x19
    9880:      	b.gt	0x98a8 <_stogir.checked.operands+0x2ec>
    9884:      	lsl	x14, x15, #2
    9888:      	ldr	x14, [x0, #0x50]
    988c:      	add	x14, x14, x15, lsl #2
    9890:      	ldr	w14, [x14]
    9894:      	sxtw	x14, w14
    9898:      	cmp	x14, #0x0
    989c:      	cset	w14, gt
    98a0:      	ubfx	x14, x14, #0, #8
    98a4:      	b	0x98ac <_stogir.checked.operands+0x2f0>
    98a8:      	movz	x14, #0x0, lsl #48
    98ac:      	b	0x9618 <_stogir.checked.operands+0x5c>
    98b0:      	brk	#0
    98b4:      	b	0x98b0 <_stogir.checked.operands+0x2f4>
    98b8:      	brk	#0
    98bc:      	b	0x98b8 <_stogir.checked.operands+0x2fc>

00000000000098c0 <_stogir.opcode.control?>:
    98c0:      	sxtw	x0, w0
    98c4:      	cmp	x0, #0x0
    98c8:      	b.lt	0x98f0 <_stogir.opcode.control?+0x30>
    98cc:      	cmp	x0, #0x83
    98d0:      	b.ge	0x98f0 <_stogir.opcode.control?+0x30>
    98d4:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		00000000000098d4:  ARM64_RELOC_PAGE21	l_stogir.430
    98d8:      	ldr	x16, [x16]
		00000000000098d8:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    98dc:      	orr	x1, x16, xzr
    98e0:      	lsr	x2, x0, #0
    98e4:      	add	x0, x1, x0
    98e8:      	ldrb	w0, [x0]
    98ec:      	b	0x98f4 <_stogir.opcode.control?+0x34>
    98f0:      	movz	x0, #0x0, lsl #48
    98f4:      	uxtb	w0, w0
    98f8:      	and	x0, x0, #0x1
    98fc:      	uxtb	w0, w0
    9900:      	ret

0000000000009904 <_stogir.opcode.block-end?>:
    9904:      	sxtw	x0, w0
    9908:      	cmp	x0, #0x0
    990c:      	b.lt	0x9934 <_stogir.opcode.block-end?+0x30>
    9910:      	cmp	x0, #0x83
    9914:      	b.ge	0x9934 <_stogir.opcode.block-end?+0x30>
    9918:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009918:  ARM64_RELOC_PAGE21	l_stogir.431
    991c:      	ldr	x16, [x16]
		000000000000991c:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    9920:      	orr	x1, x16, xzr
    9924:      	lsr	x2, x0, #0
    9928:      	add	x0, x1, x0
    992c:      	ldrb	w0, [x0]
    9930:      	b	0x9938 <_stogir.opcode.block-end?+0x34>
    9934:      	movz	x0, #0x0, lsl #48
    9938:      	uxtb	w0, w0
    993c:      	and	x0, x0, #0x4
    9940:      	uxtb	w0, w0
    9944:      	cmp	x0, #0x0
    9948:      	cset	w0, eq
    994c:      	uxtb	w16, w0
    9950:      	cmp	w16, wzr
    9954:      	cset	x0, eq
    9958:      	ret

000000000000995c <_stogir.atomic.ordinary?>:
    995c:      	sxtw	x1, w1
    9960:      	cmp	x1, #0x0
    9964:      	cset	w3, gt
    9968:      	movz	x16, #0x0, lsl #48
    996c:      	sub	x4, x16, x1
    9970:      	sub	x5, x4, #0x1
    9974:      	uxtb	w16, w3
    9978:      	cmp	w16, wzr
    997c:      	b.eq	0x99c0 <_stogir.atomic.ordinary?+0x64>
    9980:      	ldr	x4, [x0, #0x8]
    9984:      	cmp	x1, x4
    9988:      	b.ge	0x9a14 <_stogir.atomic.ordinary?+0xb8>
    998c:      	add	x4, x0, #0x78
    9990:      	ldr	x4, [x4, #0x8]
    9994:      	cmp	x1, x4
    9998:      	b.ge	0x9ad4 <_stogir.atomic.ordinary?+0x178>
    999c:      	lsl	x4, x1, #2
    99a0:      	ldr	x4, [x0, #0x78]
    99a4:      	add	x4, x4, x1, lsl #2
    99a8:      	ldr	w4, [x4]
    99ac:      	sxtw	x4, w4
    99b0:      	cmp	x4, #0x0
    99b4:      	cset	w4, ge
    99b8:      	ubfx	x4, x4, #0, #8
    99bc:      	b	0x9ad8 <_stogir.atomic.ordinary?+0x17c>
    99c0:      	cmp	x1, #0x0
    99c4:      	b.ge	0x9a1c <_stogir.atomic.ordinary?+0xc0>
    99c8:      	add	x6, x0, #0x28
    99cc:      	add	x7, x0, #0x50
    99d0:      	ldr	x6, [x6, #0x8]
    99d4:      	ldr	x7, [x7, #0x8]
    99d8:      	cmp	x6, x7
    99dc:      	b.ne	0x9a0c <_stogir.atomic.ordinary?+0xb0>
    99e0:      	cmp	x4, x6
    99e4:      	b.gt	0x9af4 <_stogir.atomic.ordinary?+0x198>
    99e8:      	lsl	x4, x5, #2
    99ec:      	ldr	x4, [x0, #0x50]
    99f0:      	add	x4, x4, x5, lsl #2
    99f4:      	ldr	w4, [x4]
    99f8:      	sxtw	x4, w4
    99fc:      	cmp	x4, #0x0
    9a00:      	cset	w4, gt
    9a04:      	ubfx	x4, x4, #0, #8
    9a08:      	b	0x9af8 <_stogir.atomic.ordinary?+0x19c>
    9a0c:      	movz	x4, #0x0, lsl #48
    9a10:      	b	0x9a20 <_stogir.atomic.ordinary?+0xc4>
    9a14:      	movz	x4, #0x0, lsl #48
    9a18:      	b	0x9a20 <_stogir.atomic.ordinary?+0xc4>
    9a1c:      	movz	x4, #0x0, lsl #48
    9a20:      	cmp	x4, #0x0
    9a24:      	b.eq	0x9a64 <_stogir.atomic.ordinary?+0x108>
    9a28:      	uxtb	w16, w3
    9a2c:      	cmp	w16, wzr
    9a30:      	b.eq	0x9a48 <_stogir.atomic.ordinary?+0xec>
    9a34:      	lsl	x3, x1, #4
    9a38:      	ldr	x0, [x0]
    9a3c:      	add	x0, x0, x1, lsl #4
    9a40:      	ldr	x0, [x0]
    9a44:      	b	0x9a58 <_stogir.atomic.ordinary?+0xfc>
    9a48:      	lsl	x1, x5, #4
    9a4c:      	ldr	x0, [x0, #0x28]
    9a50:      	add	x0, x0, x5, lsl #4
    9a54:      	ldr	x0, [x0]
    9a58:      	mov	x1, x0
    9a5c:      	mov	x0, #0x1                ; =1
    9a60:      	b	0x9a6c <_stogir.atomic.ordinary?+0x110>
    9a64:      	movz	x0, #0x0, lsl #48
    9a68:      	movz	x1, #0x0, lsl #48
    9a6c:      	lsr	w0, w0, #0
    9a70:      	lsr	x16, x0, #0
    9a74:      	cmp	x16, #0x1
    9a78:      	b.eq	0x9a94 <_stogir.atomic.ordinary?+0x138>
    9a7c:      	b.lo	0x9a84 <_stogir.atomic.ordinary?+0x128>
    9a80:      	b	0x9a98 <_stogir.atomic.ordinary?+0x13c>
    9a84:      	cmp	x16, #0x0
    9a88:      	b.eq	0x9a90 <_stogir.atomic.ordinary?+0x134>
    9a8c:      	b	0x9a98 <_stogir.atomic.ordinary?+0x13c>
    9a90:      	b	0x9a9c <_stogir.atomic.ordinary?+0x140>
    9a94:      	b	0x9aac <_stogir.atomic.ordinary?+0x150>
    9a98:      	b	0x9afc <_stogir.atomic.ordinary?+0x1a0>
    9a9c:      	movz	x0, #0x0, lsl #48
    9aa0:      	b	0x9aa8 <_stogir.atomic.ordinary?+0x14c>
    9aa4:      	movz	x0, #0x0, lsl #48
    9aa8:      	ret
    9aac:      	sxtw	x2, w2
    9ab0:      	lsr	w0, w1, #0
    9ab4:      	ubfx	x0, x0, #8, #8
    9ab8:      	cmp	x0, x2
    9abc:      	b.ne	0x9aa4 <_stogir.atomic.ordinary?+0x148>
    9ac0:      	uxtb	w1, w1
    9ac4:      	cmp	x1, #0x46
    9ac8:      	b.ne	0x9adc <_stogir.atomic.ordinary?+0x180>
    9acc:      	movz	x0, #0x0, lsl #48
    9ad0:      	b	0x9af0 <_stogir.atomic.ordinary?+0x194>
    9ad4:      	movz	x4, #0x0, lsl #48
    9ad8:      	b	0x9a18 <_stogir.atomic.ordinary?+0xbc>
    9adc:      	cmp	x1, #0x48
    9ae0:      	cset	w0, eq
    9ae4:      	uxtb	w16, w0
    9ae8:      	cmp	w16, wzr
    9aec:      	cset	x0, eq
    9af0:      	b	0x9aa8 <_stogir.atomic.ordinary?+0x14c>
    9af4:      	movz	x4, #0x0, lsl #48
    9af8:      	b	0x9a10 <_stogir.atomic.ordinary?+0xb4>
    9afc:      	brk	#0
    9b00:      	b	0x9afc <_stogir.atomic.ordinary?+0x1a0>

0000000000009b04 <_stogir.types.scalar-size>:
    9b04:      	sxtw	x1, w1
    9b08:      	cmp	x1, #0x4
    9b0c:      	b.eq	0x9b20 <_stogir.types.scalar-size+0x1c>
    9b10:      	cmp	x1, #0x8
    9b14:      	b.eq	0x9b20 <_stogir.types.scalar-size+0x1c>
    9b18:      	movn	x0, #0x0, lsl #48
    9b1c:      	b	0x9b38 <_stogir.types.scalar-size+0x34>
    9b20:      	sxtw	x0, w0
    9b24:      	cmp	x0, #0x0
    9b28:      	b.ne	0x9b3c <_stogir.types.scalar-size+0x38>
    9b2c:      	movz	x0, #0x0, lsl #48
    9b30:      	b	0x9b38 <_stogir.types.scalar-size+0x34>
    9b34:      	mov	x0, #0x1                ; =1
    9b38:      	ret
    9b3c:      	cmp	x0, #0x1
    9b40:      	b.eq	0x9b34 <_stogir.types.scalar-size+0x30>
    9b44:      	cmp	x0, #0x2
    9b48:      	b.eq	0x9b34 <_stogir.types.scalar-size+0x30>
    9b4c:      	cmp	x0, #0x7
    9b50:      	b.eq	0x9b34 <_stogir.types.scalar-size+0x30>
    9b54:      	cmp	x0, #0x8
    9b58:      	b.eq	0x9b34 <_stogir.types.scalar-size+0x30>
    9b5c:      	cmp	x0, #0x3
    9b60:      	b.eq	0x9bac <_stogir.types.scalar-size+0xa8>
    9b64:      	cmp	x0, #0x9
    9b68:      	b.eq	0x9bac <_stogir.types.scalar-size+0xa8>
    9b6c:      	cmp	x0, #0x4
    9b70:      	b.eq	0x9bb4 <_stogir.types.scalar-size+0xb0>
    9b74:      	cmp	x0, #0xa
    9b78:      	b.eq	0x9bb4 <_stogir.types.scalar-size+0xb0>
    9b7c:      	cmp	x0, #0xd
    9b80:      	b.eq	0x9bb4 <_stogir.types.scalar-size+0xb0>
    9b84:      	cmp	x0, #0x5
    9b88:      	b.eq	0x9bbc <_stogir.types.scalar-size+0xb8>
    9b8c:      	cmp	x0, #0xb
    9b90:      	b.eq	0x9bbc <_stogir.types.scalar-size+0xb8>
    9b94:      	cmp	x0, #0xc
    9b98:      	b.eq	0x9bbc <_stogir.types.scalar-size+0xb8>
    9b9c:      	cmp	x0, #0x6
    9ba0:      	b.ne	0x9bc4 <_stogir.types.scalar-size+0xc0>
    9ba4:      	mov	x0, x1
    9ba8:      	b	0x9bc8 <_stogir.types.scalar-size+0xc4>
    9bac:      	mov	x0, #0x2                ; =2
    9bb0:      	b	0x9b38 <_stogir.types.scalar-size+0x34>
    9bb4:      	mov	x0, #0x4                ; =4
    9bb8:      	b	0x9bb0 <_stogir.types.scalar-size+0xac>
    9bbc:      	mov	x0, #0x8                ; =8
    9bc0:      	b	0x9bb8 <_stogir.types.scalar-size+0xb4>
    9bc4:      	movn	x0, #0x0, lsl #48
    9bc8:      	b	0x9bc0 <_stogir.types.scalar-size+0xbc>

0000000000009bcc <_stogir.terminal.inputs>:
    9bcc:      	sxtw	x1, w1
    9bd0:      	cmp	x1, #0x60
    9bd4:      	cset	w4, eq
    9bd8:      	uxtb	w16, w4
    9bdc:      	cmp	w16, wzr
    9be0:      	b.ne	0x9c14 <_stogir.terminal.inputs+0x48>
    9be4:      	cmp	x1, #0x79
    9be8:      	b.eq	0x9c14 <_stogir.terminal.inputs+0x48>
    9bec:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009bec:  ARM64_RELOC_PAGE21	l_stogir.432
    9bf0:      	ldr	x16, [x16]
		0000000000009bf0:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    9bf4:      	orr	x0, x16, xzr
    9bf8:      	mov	x1, x0
    9bfc:      	mov	x0, #0x1                ; =1
    9c00:      	mov	x2, #0x25               ; =37
    9c04:      	str	x0, [x8]
    9c08:      	str	x1, [x8, #0x8]
    9c0c:      	str	x2, [x8, #0x10]
    9c10:      	ret
    9c14:      	sxtw	x3, w3
    9c18:      	uxtb	w16, w4
    9c1c:      	cmp	w16, wzr
    9c20:      	b.eq	0x9c2c <_stogir.terminal.inputs+0x60>
    9c24:      	cmp	x3, #0x0
    9c28:      	b.ne	0x9bec <_stogir.terminal.inputs+0x20>
    9c2c:      	sxtw	x2, w2
    9c30:      	cmp	x2, #0x0
    9c34:      	cset	w1, gt
    9c38:      	movz	x16, #0x0, lsl #48
    9c3c:      	sub	x4, x16, x2
    9c40:      	sub	x5, x4, #0x1
    9c44:      	uxtb	w16, w1
    9c48:      	cmp	w16, wzr
    9c4c:      	b.eq	0x9d34 <_stogir.terminal.inputs+0x168>
    9c50:      	ldr	x4, [x0, #0x8]
    9c54:      	cmp	x2, x4
    9c58:      	b.ge	0x9d2c <_stogir.terminal.inputs+0x160>
    9c5c:      	add	x4, x0, #0x78
    9c60:      	ldr	x4, [x4, #0x8]
    9c64:      	cmp	x2, x4
    9c68:      	b.ge	0x9ddc <_stogir.terminal.inputs+0x210>
    9c6c:      	lsl	x4, x2, #2
    9c70:      	ldr	x4, [x0, #0x78]
    9c74:      	add	x4, x4, x2, lsl #2
    9c78:      	ldr	w4, [x4]
    9c7c:      	sxtw	x4, w4
    9c80:      	cmp	x4, #0x0
    9c84:      	cset	w4, ge
    9c88:      	ubfx	x4, x4, #0, #8
    9c8c:      	b	0x9de0 <_stogir.terminal.inputs+0x214>
    9c90:      	movz	x1, #0x0, lsl #48
    9c94:      	movz	x4, #0x0, lsl #48
    9c98:      	lsr	w1, w1, #0
    9c9c:      	lsr	x16, x1, #0
    9ca0:      	cmp	x16, #0x1
    9ca4:      	b.eq	0x9cc0 <_stogir.terminal.inputs+0xf4>
    9ca8:      	b.lo	0x9cb0 <_stogir.terminal.inputs+0xe4>
    9cac:      	b	0x9cc4 <_stogir.terminal.inputs+0xf8>
    9cb0:      	cmp	x16, #0x0
    9cb4:      	b.eq	0x9cbc <_stogir.terminal.inputs+0xf0>
    9cb8:      	b	0x9cc4 <_stogir.terminal.inputs+0xf8>
    9cbc:      	b	0x9cc8 <_stogir.terminal.inputs+0xfc>
    9cc0:      	b	0x9d80 <_stogir.terminal.inputs+0x1b4>
    9cc4:      	b	0x9f34 <_stogir.terminal.inputs+0x368>
    9cc8:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009cc8:  ARM64_RELOC_PAGE21	l_stogir.433
    9ccc:      	ldr	x16, [x16]
		0000000000009ccc:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    9cd0:      	orr	x0, x16, xzr
    9cd4:      	mov	x1, x0
    9cd8:      	mov	x0, #0x1                ; =1
    9cdc:      	mov	x2, #0x1d               ; =29
    9ce0:      	b	0x9c04 <_stogir.terminal.inputs+0x38>
    9ce4:      	lsl	x1, x5, #4
    9ce8:      	ldr	x1, [x0, #0x28]
    9cec:      	add	x1, x1, x5, lsl #4
    9cf0:      	ldr	x1, [x1]
    9cf4:      	mov	x4, x1
    9cf8:      	mov	x1, #0x1                ; =1
    9cfc:      	b	0x9c98 <_stogir.terminal.inputs+0xcc>
    9d00:      	movz	x4, #0x0, lsl #48
    9d04:      	cmp	x4, #0x0
    9d08:      	b.eq	0x9c90 <_stogir.terminal.inputs+0xc4>
    9d0c:      	uxtb	w16, w1
    9d10:      	cmp	w16, wzr
    9d14:      	b.eq	0x9ce4 <_stogir.terminal.inputs+0x118>
    9d18:      	lsl	x1, x2, #4
    9d1c:      	ldr	x1, [x0]
    9d20:      	add	x1, x1, x2, lsl #4
    9d24:      	ldr	x1, [x1]
    9d28:      	b	0x9cf4 <_stogir.terminal.inputs+0x128>
    9d2c:      	movz	x4, #0x0, lsl #48
    9d30:      	b	0x9d04 <_stogir.terminal.inputs+0x138>
    9d34:      	cmp	x2, #0x0
    9d38:      	b.ge	0x9d00 <_stogir.terminal.inputs+0x134>
    9d3c:      	add	x6, x0, #0x28
    9d40:      	add	x7, x0, #0x50
    9d44:      	ldr	x6, [x6, #0x8]
    9d48:      	ldr	x7, [x7, #0x8]
    9d4c:      	cmp	x6, x7
    9d50:      	b.ne	0x9dd4 <_stogir.terminal.inputs+0x208>
    9d54:      	cmp	x4, x6
    9d58:      	b.gt	0x9de4 <_stogir.terminal.inputs+0x218>
    9d5c:      	lsl	x4, x5, #2
    9d60:      	ldr	x4, [x0, #0x50]
    9d64:      	add	x4, x4, x5, lsl #2
    9d68:      	ldr	w4, [x4]
    9d6c:      	sxtw	x4, w4
    9d70:      	cmp	x4, #0x0
    9d74:      	cset	w4, gt
    9d78:      	ubfx	x4, x4, #0, #8
    9d7c:      	b	0x9de8 <_stogir.terminal.inputs+0x21c>
    9d80:      	cmp	x2, #0x0
    9d84:      	b.le	0x9db8 <_stogir.terminal.inputs+0x1ec>
    9d88:      	uxtb	w4, w4
    9d8c:      	cmp	x4, #0x83
    9d90:      	cset	w1, lt
    9d94:      	uxtb	w16, w1
    9d98:      	cmp	w16, wzr
    9d9c:      	b.eq	0x9dec <_stogir.terminal.inputs+0x220>
    9da0:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009da0:  ARM64_RELOC_PAGE21	l_stogir.434
    9da4:      	ldr	x16, [x16]
		0000000000009da4:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    9da8:      	orr	x2, x16, xzr
    9dac:      	add	x2, x4, x2
    9db0:      	ldrb	w2, [x2]
    9db4:      	b	0x9df0 <_stogir.terminal.inputs+0x224>
    9db8:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009db8:  ARM64_RELOC_PAGE21	l_stogir.435
    9dbc:      	ldr	x16, [x16]
		0000000000009dbc:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    9dc0:      	orr	x0, x16, xzr
    9dc4:      	mov	x1, x0
    9dc8:      	mov	x0, #0x1                ; =1
    9dcc:      	mov	x2, #0x2c               ; =44
    9dd0:      	b	0x9ce0 <_stogir.terminal.inputs+0x114>
    9dd4:      	movz	x4, #0x0, lsl #48
    9dd8:      	b	0x9d04 <_stogir.terminal.inputs+0x138>
    9ddc:      	movz	x4, #0x0, lsl #48
    9de0:      	b	0x9d30 <_stogir.terminal.inputs+0x164>
    9de4:      	movz	x4, #0x0, lsl #48
    9de8:      	b	0x9dd8 <_stogir.terminal.inputs+0x20c>
    9dec:      	movz	x2, #0x0, lsl #48
    9df0:      	uxtb	w2, w2
    9df4:      	and	x2, x2, #0x1
    9df8:      	uxtb	w2, w2
    9dfc:      	cmp	x2, #0x0
    9e00:      	b.eq	0x9db8 <_stogir.terminal.inputs+0x1ec>
    9e04:      	uxtb	w16, w1
    9e08:      	cmp	w16, wzr
    9e0c:      	b.eq	0x9e28 <_stogir.terminal.inputs+0x25c>
    9e10:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009e10:  ARM64_RELOC_PAGE21	l_stogir.434
    9e14:      	ldr	x16, [x16]
		0000000000009e14:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    9e18:      	orr	x1, x16, xzr
    9e1c:      	add	x1, x4, x1
    9e20:      	ldrb	w1, [x1]
    9e24:      	b	0x9e2c <_stogir.terminal.inputs+0x260>
    9e28:      	movz	x1, #0x0, lsl #48
    9e2c:      	uxtb	w1, w1
    9e30:      	and	x1, x1, #0x4
    9e34:      	uxtb	w1, w1
    9e38:      	cmp	x1, #0x0
    9e3c:      	cset	w1, eq
    9e40:      	uxtb	w16, w1
    9e44:      	cmp	w16, wzr
    9e48:      	cset	x1, eq
    9e4c:      	cmp	x1, #0x0
    9e50:      	b.ne	0x9db8 <_stogir.terminal.inputs+0x1ec>
    9e54:      	cmp	x3, #0x0
    9e58:      	b.ne	0x9e6c <_stogir.terminal.inputs+0x2a0>
    9e5c:      	movz	x0, #0x0, lsl #48
    9e60:      	movz	x1, #0x0, lsl #48
    9e64:      	movz	x2, #0x0, lsl #48
    9e68:      	b	0x9dd0 <_stogir.terminal.inputs+0x204>
    9e6c:      	cmp	x3, #0x0
    9e70:      	cset	w1, gt
    9e74:      	movz	x16, #0x0, lsl #48
    9e78:      	sub	x2, x16, x3
    9e7c:      	sub	x4, x2, #0x1
    9e80:      	uxtb	w16, w1
    9e84:      	cmp	w16, wzr
    9e88:      	b.eq	0x9ee8 <_stogir.terminal.inputs+0x31c>
    9e8c:      	ldr	x2, [x0, #0x8]
    9e90:      	cmp	x3, x2
    9e94:      	b.ge	0x9f3c <_stogir.terminal.inputs+0x370>
    9e98:      	add	x2, x0, #0x78
    9e9c:      	ldr	x2, [x2, #0x8]
    9ea0:      	cmp	x3, x2
    9ea4:      	b.ge	0xa014 <_stogir.terminal.inputs+0x448>
    9ea8:      	lsl	x2, x3, #2
    9eac:      	ldr	x2, [x0, #0x78]
    9eb0:      	add	x2, x2, x3, lsl #2
    9eb4:      	ldr	w2, [x2]
    9eb8:      	sxtw	x2, w2
    9ebc:      	cmp	x2, #0x0
    9ec0:      	cset	w2, ge
    9ec4:      	ubfx	x2, x2, #0, #8
    9ec8:      	b	0xa018 <_stogir.terminal.inputs+0x44c>
    9ecc:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009ecc:  ARM64_RELOC_PAGE21	l_stogir.436
    9ed0:      	ldr	x16, [x16]
		0000000000009ed0:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    9ed4:      	orr	x0, x16, xzr
    9ed8:      	mov	x1, x0
    9edc:      	mov	x0, #0x1                ; =1
    9ee0:      	mov	x2, #0x2e               ; =46
    9ee4:      	b	0x9e68 <_stogir.terminal.inputs+0x29c>
    9ee8:      	cmp	x3, #0x0
    9eec:      	b.ge	0x9f44 <_stogir.terminal.inputs+0x378>
    9ef0:      	add	x5, x0, #0x28
    9ef4:      	add	x6, x0, #0x50
    9ef8:      	ldr	x5, [x5, #0x8]
    9efc:      	ldr	x6, [x6, #0x8]
    9f00:      	cmp	x5, x6
    9f04:      	b.ne	0xa00c <_stogir.terminal.inputs+0x440>
    9f08:      	cmp	x2, x5
    9f0c:      	b.gt	0xa01c <_stogir.terminal.inputs+0x450>
    9f10:      	lsl	x2, x4, #2
    9f14:      	ldr	x2, [x0, #0x50]
    9f18:      	add	x2, x2, x4, lsl #2
    9f1c:      	ldr	w2, [x2]
    9f20:      	sxtw	x2, w2
    9f24:      	cmp	x2, #0x0
    9f28:      	cset	w2, gt
    9f2c:      	ubfx	x2, x2, #0, #8
    9f30:      	b	0xa020 <_stogir.terminal.inputs+0x454>
    9f34:      	brk	#0
    9f38:      	b	0x9f34 <_stogir.terminal.inputs+0x368>
    9f3c:      	movz	x2, #0x0, lsl #48
    9f40:      	b	0x9f48 <_stogir.terminal.inputs+0x37c>
    9f44:      	movz	x2, #0x0, lsl #48
    9f48:      	cmp	x2, #0x0
    9f4c:      	b.eq	0x9f8c <_stogir.terminal.inputs+0x3c0>
    9f50:      	uxtb	w16, w1
    9f54:      	cmp	w16, wzr
    9f58:      	b.eq	0x9f70 <_stogir.terminal.inputs+0x3a4>
    9f5c:      	lsl	x1, x3, #4
    9f60:      	ldr	x0, [x0]
    9f64:      	add	x0, x0, x3, lsl #4
    9f68:      	ldr	x0, [x0]
    9f6c:      	b	0x9f80 <_stogir.terminal.inputs+0x3b4>
    9f70:      	lsl	x1, x4, #4
    9f74:      	ldr	x0, [x0, #0x28]
    9f78:      	add	x0, x0, x4, lsl #4
    9f7c:      	ldr	x0, [x0]
    9f80:      	mov	x1, x0
    9f84:      	mov	x0, #0x1                ; =1
    9f88:      	b	0x9f94 <_stogir.terminal.inputs+0x3c8>
    9f8c:      	movz	x0, #0x0, lsl #48
    9f90:      	movz	x1, #0x0, lsl #48
    9f94:      	lsr	w0, w0, #0
    9f98:      	lsr	x16, x0, #0
    9f9c:      	cmp	x16, #0x1
    9fa0:      	b.eq	0x9fbc <_stogir.terminal.inputs+0x3f0>
    9fa4:      	b.lo	0x9fac <_stogir.terminal.inputs+0x3e0>
    9fa8:      	b	0x9fc0 <_stogir.terminal.inputs+0x3f4>
    9fac:      	cmp	x16, #0x0
    9fb0:      	b.eq	0x9fb8 <_stogir.terminal.inputs+0x3ec>
    9fb4:      	b	0x9fc0 <_stogir.terminal.inputs+0x3f4>
    9fb8:      	b	0x9fc4 <_stogir.terminal.inputs+0x3f8>
    9fbc:      	b	0x9fe0 <_stogir.terminal.inputs+0x414>
    9fc0:      	b	0xa064 <_stogir.terminal.inputs+0x498>
    9fc4:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009fc4:  ARM64_RELOC_PAGE21	l_stogir.437
    9fc8:      	ldr	x16, [x16]
		0000000000009fc8:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    9fcc:      	orr	x0, x16, xzr
    9fd0:      	mov	x1, x0
    9fd4:      	mov	x0, #0x1                ; =1
    9fd8:      	mov	x2, #0x1d               ; =29
    9fdc:      	b	0x9ee4 <_stogir.terminal.inputs+0x318>
    9fe0:      	cmp	x3, #0x0
    9fe4:      	b.le	0x9ecc <_stogir.terminal.inputs+0x300>
    9fe8:      	uxtb	w1, w1
    9fec:      	cmp	x1, #0x83
    9ff0:      	b.ge	0xa024 <_stogir.terminal.inputs+0x458>
    9ff4:      	adrp	x16, 0x9000 <_stogir.types.size+0x34>
		0000000000009ff4:  ARM64_RELOC_PAGE21	l_stogir.434
    9ff8:      	ldr	x16, [x16]
		0000000000009ff8:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    9ffc:      	orr	x0, x16, xzr
    a000:      	add	x0, x1, x0
    a004:      	ldrb	w0, [x0]
    a008:      	b	0xa028 <_stogir.terminal.inputs+0x45c>
    a00c:      	movz	x2, #0x0, lsl #48
    a010:      	b	0x9f48 <_stogir.terminal.inputs+0x37c>
    a014:      	movz	x2, #0x0, lsl #48
    a018:      	b	0x9f40 <_stogir.terminal.inputs+0x374>
    a01c:      	movz	x2, #0x0, lsl #48
    a020:      	b	0xa010 <_stogir.terminal.inputs+0x444>
    a024:      	movz	x0, #0x0, lsl #48
    a028:      	uxtb	w0, w0
    a02c:      	and	x0, x0, #0x8
    a030:      	uxtb	w0, w0
    a034:      	cmp	x0, #0x0
    a038:      	cset	w0, eq
    a03c:      	uxtb	w16, w0
    a040:      	cmp	w16, wzr
    a044:      	cset	x0, eq
    a048:      	cmp	x0, #0x0
    a04c:      	b.eq	0x9ecc <_stogir.terminal.inputs+0x300>
    a050:      	and	x0, x3, #0xffffffff
    a054:      	mov	x1, x0
    a058:      	movz	x0, #0x0, lsl #48
    a05c:      	movz	x2, #0x0, lsl #48
    a060:      	b	0x9ee4 <_stogir.terminal.inputs+0x318>
    a064:      	brk	#0
    a068:      	b	0xa064 <_stogir.terminal.inputs+0x498>

000000000000a06c <_stogir.switch.switch-inputs>:
    a06c:      	sxtw	x1, w1
    a070:      	cmp	x1, #0x0
    a074:      	cset	w3, gt
    a078:      	movz	x16, #0x0, lsl #48
    a07c:      	sub	x4, x16, x1
    a080:      	sub	x5, x4, #0x1
    a084:      	uxtb	w16, w3
    a088:      	cmp	w16, wzr
    a08c:      	b.eq	0xa0d0 <_stogir.switch.switch-inputs+0x64>
    a090:      	ldr	x4, [x0, #0x8]
    a094:      	cmp	x1, x4
    a098:      	b.ge	0xa140 <_stogir.switch.switch-inputs+0xd4>
    a09c:      	add	x4, x0, #0x78
    a0a0:      	ldr	x4, [x4, #0x8]
    a0a4:      	cmp	x1, x4
    a0a8:      	b.ge	0xa228 <_stogir.switch.switch-inputs+0x1bc>
    a0ac:      	lsl	x4, x1, #2
    a0b0:      	ldr	x4, [x0, #0x78]
    a0b4:      	add	x4, x4, x1, lsl #2
    a0b8:      	ldr	w4, [x4]
    a0bc:      	sxtw	x4, w4
    a0c0:      	cmp	x4, #0x0
    a0c4:      	cset	w4, ge
    a0c8:      	ubfx	x4, x4, #0, #8
    a0cc:      	b	0xa22c <_stogir.switch.switch-inputs+0x1c0>
    a0d0:      	cmp	x1, #0x0
    a0d4:      	b.ge	0xa148 <_stogir.switch.switch-inputs+0xdc>
    a0d8:      	add	x6, x0, #0x28
    a0dc:      	add	x7, x0, #0x50
    a0e0:      	ldr	x6, [x6, #0x8]
    a0e4:      	ldr	x7, [x7, #0x8]
    a0e8:      	cmp	x6, x7
    a0ec:      	b.ne	0xa11c <_stogir.switch.switch-inputs+0xb0>
    a0f0:      	cmp	x4, x6
    a0f4:      	b.gt	0xa230 <_stogir.switch.switch-inputs+0x1c4>
    a0f8:      	lsl	x4, x5, #2
    a0fc:      	ldr	x4, [x0, #0x50]
    a100:      	add	x4, x4, x5, lsl #2
    a104:      	ldr	w4, [x4]
    a108:      	sxtw	x4, w4
    a10c:      	cmp	x4, #0x0
    a110:      	cset	w4, gt
    a114:      	ubfx	x4, x4, #0, #8
    a118:      	b	0xa234 <_stogir.switch.switch-inputs+0x1c8>
    a11c:      	movz	x4, #0x0, lsl #48
    a120:      	b	0xa14c <_stogir.switch.switch-inputs+0xe0>
    a124:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a124:  ARM64_RELOC_PAGE21	l_stogir.438
    a128:      	ldr	x16, [x16]
		000000000000a128:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    a12c:      	orr	x0, x16, xzr
    a130:      	mov	x1, x0
    a134:      	mov	x0, #0x1                ; =1
    a138:      	mov	x2, #0x16               ; =22
    a13c:      	b	0xa1e0 <_stogir.switch.switch-inputs+0x174>
    a140:      	movz	x4, #0x0, lsl #48
    a144:      	b	0xa14c <_stogir.switch.switch-inputs+0xe0>
    a148:      	movz	x4, #0x0, lsl #48
    a14c:      	cmp	x4, #0x0
    a150:      	b.eq	0xa190 <_stogir.switch.switch-inputs+0x124>
    a154:      	uxtb	w16, w3
    a158:      	cmp	w16, wzr
    a15c:      	b.eq	0xa174 <_stogir.switch.switch-inputs+0x108>
    a160:      	lsl	x3, x1, #4
    a164:      	ldr	x3, [x0]
    a168:      	add	x3, x3, x1, lsl #4
    a16c:      	ldr	x3, [x3]
    a170:      	b	0xa184 <_stogir.switch.switch-inputs+0x118>
    a174:      	lsl	x3, x5, #4
    a178:      	ldr	x3, [x0, #0x28]
    a17c:      	add	x3, x3, x5, lsl #4
    a180:      	ldr	x3, [x3]
    a184:      	mov	x4, x3
    a188:      	mov	x3, #0x1                ; =1
    a18c:      	b	0xa198 <_stogir.switch.switch-inputs+0x12c>
    a190:      	movz	x3, #0x0, lsl #48
    a194:      	movz	x4, #0x0, lsl #48
    a198:      	lsr	w3, w3, #0
    a19c:      	lsr	x16, x3, #0
    a1a0:      	cmp	x16, #0x1
    a1a4:      	b.eq	0xa1c0 <_stogir.switch.switch-inputs+0x154>
    a1a8:      	b.lo	0xa1b0 <_stogir.switch.switch-inputs+0x144>
    a1ac:      	b	0xa1c4 <_stogir.switch.switch-inputs+0x158>
    a1b0:      	cmp	x16, #0x0
    a1b4:      	b.eq	0xa1bc <_stogir.switch.switch-inputs+0x150>
    a1b8:      	b	0xa1c4 <_stogir.switch.switch-inputs+0x158>
    a1bc:      	b	0xa1c8 <_stogir.switch.switch-inputs+0x15c>
    a1c0:      	b	0xa1f0 <_stogir.switch.switch-inputs+0x184>
    a1c4:      	b	0xa458 <_stogir.switch.switch-inputs+0x3ec>
    a1c8:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a1c8:  ARM64_RELOC_PAGE21	l_stogir.439
    a1cc:      	ldr	x16, [x16]
		000000000000a1cc:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    a1d0:      	orr	x0, x16, xzr
    a1d4:      	mov	x1, x0
    a1d8:      	mov	x0, #0x1                ; =1
    a1dc:      	mov	x2, #0x16               ; =22
    a1e0:      	str	x0, [x8]
    a1e4:      	str	x1, [x8, #0x8]
    a1e8:      	str	x2, [x8, #0x10]
    a1ec:      	ret
    a1f0:      	cmp	x1, #0x0
    a1f4:      	b.le	0xa124 <_stogir.switch.switch-inputs+0xb8>
    a1f8:      	uxtb	w4, w4
    a1fc:      	cmp	x4, #0x83
    a200:      	cset	w1, lt
    a204:      	uxtb	w16, w1
    a208:      	cmp	w16, wzr
    a20c:      	b.eq	0xa238 <_stogir.switch.switch-inputs+0x1cc>
    a210:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a210:  ARM64_RELOC_PAGE21	l_stogir.440
    a214:      	ldr	x16, [x16]
		000000000000a214:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a218:      	orr	x3, x16, xzr
    a21c:      	add	x3, x4, x3
    a220:      	ldrb	w3, [x3]
    a224:      	b	0xa23c <_stogir.switch.switch-inputs+0x1d0>
    a228:      	movz	x4, #0x0, lsl #48
    a22c:      	b	0xa144 <_stogir.switch.switch-inputs+0xd8>
    a230:      	movz	x4, #0x0, lsl #48
    a234:      	b	0xa120 <_stogir.switch.switch-inputs+0xb4>
    a238:      	movz	x3, #0x0, lsl #48
    a23c:      	uxtb	w3, w3
    a240:      	and	x3, x3, #0x1
    a244:      	uxtb	w3, w3
    a248:      	cmp	x3, #0x0
    a24c:      	b.eq	0xa124 <_stogir.switch.switch-inputs+0xb8>
    a250:      	uxtb	w16, w1
    a254:      	cmp	w16, wzr
    a258:      	b.eq	0xa274 <_stogir.switch.switch-inputs+0x208>
    a25c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a25c:  ARM64_RELOC_PAGE21	l_stogir.440
    a260:      	ldr	x16, [x16]
		000000000000a260:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a264:      	orr	x1, x16, xzr
    a268:      	add	x1, x4, x1
    a26c:      	ldrb	w1, [x1]
    a270:      	b	0xa278 <_stogir.switch.switch-inputs+0x20c>
    a274:      	movz	x1, #0x0, lsl #48
    a278:      	uxtb	w1, w1
    a27c:      	and	x1, x1, #0x4
    a280:      	uxtb	w1, w1
    a284:      	cmp	x1, #0x0
    a288:      	cset	w1, eq
    a28c:      	uxtb	w16, w1
    a290:      	cmp	w16, wzr
    a294:      	cset	x1, eq
    a298:      	cmp	x1, #0x0
    a29c:      	b.ne	0xa124 <_stogir.switch.switch-inputs+0xb8>
    a2a0:      	sxtw	x2, w2
    a2a4:      	cmp	x2, #0x0
    a2a8:      	cset	w1, gt
    a2ac:      	movz	x16, #0x0, lsl #48
    a2b0:      	sub	x3, x16, x2
    a2b4:      	sub	x4, x3, #0x1
    a2b8:      	uxtb	w16, w1
    a2bc:      	cmp	w16, wzr
    a2c0:      	b.eq	0xa320 <_stogir.switch.switch-inputs+0x2b4>
    a2c4:      	ldr	x3, [x0, #0x8]
    a2c8:      	cmp	x2, x3
    a2cc:      	b.ge	0xa36c <_stogir.switch.switch-inputs+0x300>
    a2d0:      	add	x3, x0, #0x78
    a2d4:      	ldr	x3, [x3, #0x8]
    a2d8:      	cmp	x2, x3
    a2dc:      	b.ge	0xa450 <_stogir.switch.switch-inputs+0x3e4>
    a2e0:      	lsl	x3, x2, #2
    a2e4:      	ldr	x3, [x0, #0x78]
    a2e8:      	add	x3, x3, x2, lsl #2
    a2ec:      	ldr	w3, [x3]
    a2f0:      	sxtw	x3, w3
    a2f4:      	cmp	x3, #0x0
    a2f8:      	cset	w3, ge
    a2fc:      	ubfx	x3, x3, #0, #8
    a300:      	b	0xa454 <_stogir.switch.switch-inputs+0x3e8>
    a304:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a304:  ARM64_RELOC_PAGE21	l_stogir.441
    a308:      	ldr	x16, [x16]
		000000000000a308:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    a30c:      	orr	x0, x16, xzr
    a310:      	mov	x1, x0
    a314:      	mov	x0, #0x1                ; =1
    a318:      	mov	x2, #0x20               ; =32
    a31c:      	b	0xa13c <_stogir.switch.switch-inputs+0xd0>
    a320:      	cmp	x2, #0x0
    a324:      	b.ge	0xa374 <_stogir.switch.switch-inputs+0x308>
    a328:      	add	x5, x0, #0x28
    a32c:      	add	x6, x0, #0x50
    a330:      	ldr	x5, [x5, #0x8]
    a334:      	ldr	x6, [x6, #0x8]
    a338:      	cmp	x5, x6
    a33c:      	b.ne	0xa448 <_stogir.switch.switch-inputs+0x3dc>
    a340:      	cmp	x3, x5
    a344:      	b.gt	0xa460 <_stogir.switch.switch-inputs+0x3f4>
    a348:      	lsl	x3, x4, #2
    a34c:      	ldr	x3, [x0, #0x50]
    a350:      	add	x3, x3, x4, lsl #2
    a354:      	ldr	w3, [x3]
    a358:      	sxtw	x3, w3
    a35c:      	cmp	x3, #0x0
    a360:      	cset	w3, gt
    a364:      	ubfx	x3, x3, #0, #8
    a368:      	b	0xa464 <_stogir.switch.switch-inputs+0x3f8>
    a36c:      	movz	x3, #0x0, lsl #48
    a370:      	b	0xa378 <_stogir.switch.switch-inputs+0x30c>
    a374:      	movz	x3, #0x0, lsl #48
    a378:      	cmp	x3, #0x0
    a37c:      	b.eq	0xa3bc <_stogir.switch.switch-inputs+0x350>
    a380:      	uxtb	w16, w1
    a384:      	cmp	w16, wzr
    a388:      	b.eq	0xa3a0 <_stogir.switch.switch-inputs+0x334>
    a38c:      	lsl	x1, x2, #4
    a390:      	ldr	x0, [x0]
    a394:      	add	x0, x0, x2, lsl #4
    a398:      	ldr	x0, [x0]
    a39c:      	b	0xa3b0 <_stogir.switch.switch-inputs+0x344>
    a3a0:      	lsl	x1, x4, #4
    a3a4:      	ldr	x0, [x0, #0x28]
    a3a8:      	add	x0, x0, x4, lsl #4
    a3ac:      	ldr	x0, [x0]
    a3b0:      	mov	x1, x0
    a3b4:      	mov	x0, #0x1                ; =1
    a3b8:      	b	0xa3c4 <_stogir.switch.switch-inputs+0x358>
    a3bc:      	movz	x0, #0x0, lsl #48
    a3c0:      	movz	x1, #0x0, lsl #48
    a3c4:      	lsr	w0, w0, #0
    a3c8:      	lsr	x16, x0, #0
    a3cc:      	cmp	x16, #0x1
    a3d0:      	b.eq	0xa3ec <_stogir.switch.switch-inputs+0x380>
    a3d4:      	b.lo	0xa3dc <_stogir.switch.switch-inputs+0x370>
    a3d8:      	b	0xa3f0 <_stogir.switch.switch-inputs+0x384>
    a3dc:      	cmp	x16, #0x0
    a3e0:      	b.eq	0xa3e8 <_stogir.switch.switch-inputs+0x37c>
    a3e4:      	b	0xa3f0 <_stogir.switch.switch-inputs+0x384>
    a3e8:      	b	0xa3f4 <_stogir.switch.switch-inputs+0x388>
    a3ec:      	b	0xa410 <_stogir.switch.switch-inputs+0x3a4>
    a3f0:      	b	0xa468 <_stogir.switch.switch-inputs+0x3fc>
    a3f4:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a3f4:  ARM64_RELOC_PAGE21	l_stogir.442
    a3f8:      	ldr	x16, [x16]
		000000000000a3f8:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    a3fc:      	orr	x0, x16, xzr
    a400:      	mov	x1, x0
    a404:      	mov	x0, #0x1                ; =1
    a408:      	mov	x2, #0x17               ; =23
    a40c:      	b	0xa31c <_stogir.switch.switch-inputs+0x2b0>
    a410:      	lsr	w0, w1, #0
    a414:      	ubfx	x0, x0, #8, #8
    a418:      	cmp	x0, #0x1
    a41c:      	b.lt	0xa304 <_stogir.switch.switch-inputs+0x298>
    a420:      	cmp	x0, #0xb
    a424:      	b.gt	0xa304 <_stogir.switch.switch-inputs+0x298>
    a428:      	uxtb	w1, w1
    a42c:      	cmp	x1, #0x48
    a430:      	b.eq	0xa304 <_stogir.switch.switch-inputs+0x298>
    a434:      	and	x0, x0, #0xffffffff
    a438:      	mov	x1, x0
    a43c:      	movz	x0, #0x0, lsl #48
    a440:      	movz	x2, #0x0, lsl #48
    a444:      	b	0xa31c <_stogir.switch.switch-inputs+0x2b0>
    a448:      	movz	x3, #0x0, lsl #48
    a44c:      	b	0xa378 <_stogir.switch.switch-inputs+0x30c>
    a450:      	movz	x3, #0x0, lsl #48
    a454:      	b	0xa370 <_stogir.switch.switch-inputs+0x304>
    a458:      	brk	#0
    a45c:      	b	0xa458 <_stogir.switch.switch-inputs+0x3ec>
    a460:      	movz	x3, #0x0, lsl #48
    a464:      	b	0xa44c <_stogir.switch.switch-inputs+0x3e0>
    a468:      	brk	#0
    a46c:      	b	0xa468 <_stogir.switch.switch-inputs+0x3fc>

000000000000a470 <_stogir.switch.case-inputs>:
    a470:      	sub	sp, sp, #0xb0
    a474:      	str	x29, [sp]
    a478:      	str	x30, [sp, #0x8]
    a47c:      	mov	x29, sp
    a480:      	str	x19, [sp, #0x70]
    a484:      	str	x20, [sp, #0x78]
    a488:      	str	x21, [sp, #0x80]
    a48c:      	str	x22, [sp, #0x88]
    a490:      	str	x23, [sp, #0x90]
    a494:      	str	x24, [sp, #0x98]
    a498:      	str	x25, [sp, #0xa0]
    a49c:      	str	x26, [sp, #0xa8]
    a4a0:      	sxtw	x2, w2
    a4a4:      	lsl	x5, x2, #2
    a4a8:      	cmp	x2, #0x0
    a4ac:      	cset	w6, gt
    a4b0:      	movz	x16, #0x0, lsl #48
    a4b4:      	sub	x7, x16, x2
    a4b8:      	sub	x9, x7, #0x1
    a4bc:      	uxtb	w16, w6
    a4c0:      	cmp	w16, wzr
    a4c4:      	b.eq	0xa504 <_stogir.switch.case-inputs+0x94>
    a4c8:      	ldr	x7, [x0, #0x8]
    a4cc:      	cmp	x2, x7
    a4d0:      	b.ge	0xa558 <_stogir.switch.case-inputs+0xe8>
    a4d4:      	add	x7, x0, #0x78
    a4d8:      	ldr	x7, [x7, #0x8]
    a4dc:      	cmp	x2, x7
    a4e0:      	b.ge	0xa688 <_stogir.switch.case-inputs+0x218>
    a4e4:      	ldr	x7, [x0, #0x78]
    a4e8:      	add	x7, x5, x7
    a4ec:      	ldr	w7, [x7]
    a4f0:      	sxtw	x7, w7
    a4f4:      	cmp	x7, #0x0
    a4f8:      	cset	w7, ge
    a4fc:      	ubfx	x7, x7, #0, #8
    a500:      	b	0xa68c <_stogir.switch.case-inputs+0x21c>
    a504:      	cmp	x2, #0x0
    a508:      	b.ge	0xa560 <_stogir.switch.case-inputs+0xf0>
    a50c:      	add	x10, x0, #0x28
    a510:      	add	x11, x0, #0x50
    a514:      	ldr	x10, [x10, #0x8]
    a518:      	ldr	x11, [x11, #0x8]
    a51c:      	cmp	x10, x11
    a520:      	b.ne	0xa550 <_stogir.switch.case-inputs+0xe0>
    a524:      	cmp	x7, x10
    a528:      	b.gt	0xa75c <_stogir.switch.case-inputs+0x2ec>
    a52c:      	lsl	x7, x9, #2
    a530:      	ldr	x7, [x0, #0x50]
    a534:      	add	x7, x7, x9, lsl #2
    a538:      	ldr	w7, [x7]
    a53c:      	sxtw	x7, w7
    a540:      	cmp	x7, #0x0
    a544:      	cset	w7, gt
    a548:      	ubfx	x7, x7, #0, #8
    a54c:      	b	0xa760 <_stogir.switch.case-inputs+0x2f0>
    a550:      	movz	x7, #0x0, lsl #48
    a554:      	b	0xa564 <_stogir.switch.case-inputs+0xf4>
    a558:      	movz	x7, #0x0, lsl #48
    a55c:      	b	0xa564 <_stogir.switch.case-inputs+0xf4>
    a560:      	movz	x7, #0x0, lsl #48
    a564:      	cmp	x7, #0x0
    a568:      	b.eq	0xa5cc <_stogir.switch.case-inputs+0x15c>
    a56c:      	uxtb	w16, w6
    a570:      	cmp	w16, wzr
    a574:      	b.eq	0xa59c <_stogir.switch.case-inputs+0x12c>
    a578:      	lsl	x6, x2, #4
    a57c:      	ldr	x6, [x0]
    a580:      	add	x6, x6, x2, lsl #4
    a584:      	ldr	x7, [x6]
    a588:      	ldr	x6, [x6, #0x8]
    a58c:      	fmov	d31, x6
    a590:      	mov	x6, x7
    a594:      	fmov	x7, d31
    a598:      	b	0xa5bc <_stogir.switch.case-inputs+0x14c>
    a59c:      	lsl	x6, x9, #4
    a5a0:      	ldr	x6, [x0, #0x28]
    a5a4:      	add	x6, x6, x9, lsl #4
    a5a8:      	ldr	x7, [x6]
    a5ac:      	ldr	x6, [x6, #0x8]
    a5b0:      	fmov	d31, x6
    a5b4:      	mov	x6, x7
    a5b8:      	fmov	x7, d31
    a5bc:      	mov	x9, x7
    a5c0:      	mov	x7, x6
    a5c4:      	mov	x6, #0x1                ; =1
    a5c8:      	b	0xa5d8 <_stogir.switch.case-inputs+0x168>
    a5cc:      	movz	x6, #0x0, lsl #48
    a5d0:      	movz	x7, #0x0, lsl #48
    a5d4:      	movz	x9, #0x0, lsl #48
    a5d8:      	lsr	w6, w6, #0
    a5dc:      	lsr	x16, x6, #0
    a5e0:      	cmp	x16, #0x1
    a5e4:      	b.eq	0xa600 <_stogir.switch.case-inputs+0x190>
    a5e8:      	b.lo	0xa5f0 <_stogir.switch.case-inputs+0x180>
    a5ec:      	b	0xa604 <_stogir.switch.case-inputs+0x194>
    a5f0:      	cmp	x16, #0x0
    a5f4:      	b.eq	0xa5fc <_stogir.switch.case-inputs+0x18c>
    a5f8:      	b	0xa604 <_stogir.switch.case-inputs+0x194>
    a5fc:      	b	0xa608 <_stogir.switch.case-inputs+0x198>
    a600:      	b	0xa660 <_stogir.switch.case-inputs+0x1f0>
    a604:      	b	0xa764 <_stogir.switch.case-inputs+0x2f4>
    a608:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a608:  ARM64_RELOC_PAGE21	l_stogir.443
    a60c:      	ldr	x16, [x16]
		000000000000a60c:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    a610:      	orr	x0, x16, xzr
    a614:      	mov	x21, x8
    a618:      	mov	x1, x0
    a61c:      	mov	x0, #0x1                ; =1
    a620:      	mov	x2, #0x1a               ; =26
    a624:      	str	x0, [x21]
    a628:      	str	x1, [x21, #0x8]
    a62c:      	str	x2, [x21, #0x10]
    a630:      	ldr	x19, [sp, #0x70]
    a634:      	ldr	x20, [sp, #0x78]
    a638:      	ldr	x21, [sp, #0x80]
    a63c:      	ldr	x22, [sp, #0x88]
    a640:      	ldr	x23, [sp, #0x90]
    a644:      	ldr	x24, [sp, #0x98]
    a648:      	ldr	x25, [sp, #0xa0]
    a64c:      	ldr	x26, [sp, #0xa8]
    a650:      	ldr	x29, [sp]
    a654:      	ldr	x30, [sp, #0x8]
    a658:      	add	sp, sp, #0xb0
    a65c:      	ret
    a660:      	cmp	x2, #0x0
    a664:      	b.gt	0xa690 <_stogir.switch.case-inputs+0x220>
    a668:      	mov	x21, x8
    a66c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a66c:  ARM64_RELOC_PAGE21	l_stogir.444
    a670:      	ldr	x16, [x16]
		000000000000a670:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    a674:      	orr	x0, x16, xzr
    a678:      	mov	x1, x0
    a67c:      	mov	x0, #0x1                ; =1
    a680:      	mov	x2, #0x1f               ; =31
    a684:      	b	0xa624 <_stogir.switch.case-inputs+0x1b4>
    a688:      	movz	x7, #0x0, lsl #48
    a68c:      	b	0xa55c <_stogir.switch.case-inputs+0xec>
    a690:      	uxtb	w2, w7
    a694:      	cmp	x2, #0x75
    a698:      	b.ne	0xa8f4 <_stogir.switch.case-inputs+0x484>
    a69c:      	lsr	w2, w7, #0
    a6a0:      	ubfx	x2, x2, #8, #8
    a6a4:      	cmp	x2, #0x0
    a6a8:      	b.ne	0xa8fc <_stogir.switch.case-inputs+0x48c>
    a6ac:      	ldr	x2, [x0, #0x78]
    a6b0:      	add	x2, x5, x2
    a6b4:      	ldr	w2, [x2]
    a6b8:      	sxtw	x2, w2
    a6bc:      	cmp	x2, #0x2
    a6c0:      	b.ne	0xa904 <_stogir.switch.case-inputs+0x494>
    a6c4:      	sxtw	x19, w1
    a6c8:      	cmp	x19, #0x6d
    a6cc:      	b.lt	0xa90c <_stogir.switch.case-inputs+0x49c>
    a6d0:      	cmp	x19, #0x6f
    a6d4:      	b.gt	0xa914 <_stogir.switch.case-inputs+0x4a4>
    a6d8:      	add	x16, sp, #0x10
    a6dc:      	orr	x20, x16, xzr
    a6e0:      	lsr	w9, w9, #0
    a6e4:      	lsr	x1, x7, #32
    a6e8:      	lsr	w9, w9, #0
    a6ec:      	lsr	w1, w1, #0
    a6f0:      	mov	w2, w9
    a6f4:      	mov	x21, x8
    a6f8:      	add	x8, sp, #0x10
    a6fc:      	mov	x22, x0
    a700:      	mov	w23, w3
    a704:      	mov	w24, w4
    a708:      	bl	0xa708 <_stogir.switch.case-inputs+0x298>
		000000000000a708:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    a70c:      	add	x16, sp, #0x10
    a710:      	ldr	w0, [x16]
    a714:      	lsr	x16, x0, #0
    a718:      	cmp	x16, #0x1
    a71c:      	b.eq	0xa738 <_stogir.switch.case-inputs+0x2c8>
    a720:      	b.lo	0xa728 <_stogir.switch.case-inputs+0x2b8>
    a724:      	b	0xa73c <_stogir.switch.case-inputs+0x2cc>
    a728:      	cmp	x16, #0x0
    a72c:      	b.eq	0xa734 <_stogir.switch.case-inputs+0x2c4>
    a730:      	b	0xa73c <_stogir.switch.case-inputs+0x2cc>
    a734:      	b	0xa76c <_stogir.switch.case-inputs+0x2fc>
    a738:      	b	0xa740 <_stogir.switch.case-inputs+0x2d0>
    a73c:      	b	0xa8dc <_stogir.switch.case-inputs+0x46c>
    a740:      	add	x0, x20, #0x8
    a744:      	add	x16, sp, #0x10
    a748:      	ldr	x1, [x16, #0x8]
    a74c:      	ldr	x0, [x0, #0x8]
    a750:      	mov	x2, x0
    a754:      	mov	x0, #0x1                ; =1
    a758:      	b	0xa684 <_stogir.switch.case-inputs+0x214>
    a75c:      	movz	x7, #0x0, lsl #48
    a760:      	b	0xa554 <_stogir.switch.case-inputs+0xe4>
    a764:      	brk	#0
    a768:      	b	0xa764 <_stogir.switch.case-inputs+0x2f4>
    a76c:      	add	x16, sp, #0x10
    a770:      	ldr	w20, [x16, #0x8]
    a774:      	sxtw	x0, w20
    a778:      	and	x25, x0, #0xffffffff
    a77c:      	cmp	x19, #0x6f
    a780:      	b.ne	0xa794 <_stogir.switch.case-inputs+0x324>
    a784:      	mov	x1, x25
    a788:      	movz	x0, #0x0, lsl #48
    a78c:      	movz	x2, #0x0, lsl #48
    a790:      	b	0xa758 <_stogir.switch.case-inputs+0x2e8>
    a794:      	add	x16, sp, #0x30
    a798:      	orr	x26, x16, xzr
    a79c:      	lsr	w23, w23, #0
    a7a0:      	lsr	w20, w20, #0
    a7a4:      	add	x8, sp, #0x30
    a7a8:      	mov	x0, x22
    a7ac:      	mov	w1, w23
    a7b0:      	mov	w2, w20
    a7b4:      	bl	0xa7b4 <_stogir.switch.case-inputs+0x344>
		000000000000a7b4:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    a7b8:      	add	x16, sp, #0x30
    a7bc:      	ldr	w0, [x16]
    a7c0:      	lsr	x16, x0, #0
    a7c4:      	cmp	x16, #0x1
    a7c8:      	b.eq	0xa7e4 <_stogir.switch.case-inputs+0x374>
    a7cc:      	b.lo	0xa7d4 <_stogir.switch.case-inputs+0x364>
    a7d0:      	b	0xa7e8 <_stogir.switch.case-inputs+0x378>
    a7d4:      	cmp	x16, #0x0
    a7d8:      	b.eq	0xa7e0 <_stogir.switch.case-inputs+0x370>
    a7dc:      	b	0xa7e8 <_stogir.switch.case-inputs+0x378>
    a7e0:      	b	0xa808 <_stogir.switch.case-inputs+0x398>
    a7e4:      	b	0xa7ec <_stogir.switch.case-inputs+0x37c>
    a7e8:      	b	0xa8e4 <_stogir.switch.case-inputs+0x474>
    a7ec:      	add	x0, x26, #0x8
    a7f0:      	add	x16, sp, #0x30
    a7f4:      	ldr	x1, [x16, #0x8]
    a7f8:      	ldr	x0, [x0, #0x8]
    a7fc:      	mov	x2, x0
    a800:      	mov	x0, #0x1                ; =1
    a804:      	b	0xa790 <_stogir.switch.case-inputs+0x320>
    a808:      	add	x16, sp, #0x30
    a80c:      	ldr	x26, [x16, #0x8]
    a810:      	cmp	x19, #0x6d
    a814:      	b.ne	0xa834 <_stogir.switch.case-inputs+0x3c4>
    a818:      	sxtw	x23, w23
    a81c:      	mov	x0, x23
    a820:      	b	0xa83c <_stogir.switch.case-inputs+0x3cc>
    a824:      	mov	x1, x25
    a828:      	movz	x0, #0x0, lsl #48
    a82c:      	movz	x2, #0x0, lsl #48
    a830:      	b	0xa804 <_stogir.switch.case-inputs+0x394>
    a834:      	sxtw	x24, w24
    a838:      	mov	x0, x24
    a83c:      	add	x16, sp, #0x50
    a840:      	orr	x19, x16, xzr
    a844:      	lsr	w20, w20, #0
    a848:      	lsr	w0, w0, #0
    a84c:      	add	x8, sp, #0x50
    a850:      	mov	w1, w0
    a854:      	mov	x0, x22
    a858:      	mov	w2, w20
    a85c:      	bl	0xa85c <_stogir.switch.case-inputs+0x3ec>
		000000000000a85c:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    a860:      	add	x16, sp, #0x50
    a864:      	ldr	w0, [x16]
    a868:      	lsr	x16, x0, #0
    a86c:      	cmp	x16, #0x1
    a870:      	b.eq	0xa88c <_stogir.switch.case-inputs+0x41c>
    a874:      	b.lo	0xa87c <_stogir.switch.case-inputs+0x40c>
    a878:      	b	0xa890 <_stogir.switch.case-inputs+0x420>
    a87c:      	cmp	x16, #0x0
    a880:      	b.eq	0xa888 <_stogir.switch.case-inputs+0x418>
    a884:      	b	0xa890 <_stogir.switch.case-inputs+0x420>
    a888:      	b	0xa8b0 <_stogir.switch.case-inputs+0x440>
    a88c:      	b	0xa894 <_stogir.switch.case-inputs+0x424>
    a890:      	b	0xa8ec <_stogir.switch.case-inputs+0x47c>
    a894:      	add	x0, x19, #0x8
    a898:      	add	x16, sp, #0x50
    a89c:      	ldr	x1, [x16, #0x8]
    a8a0:      	ldr	x0, [x0, #0x8]
    a8a4:      	mov	x2, x0
    a8a8:      	mov	x0, #0x1                ; =1
    a8ac:      	b	0xa830 <_stogir.switch.case-inputs+0x3c0>
    a8b0:      	add	x16, sp, #0x50
    a8b4:      	ldr	x0, [x16, #0x8]
    a8b8:      	cmp	x26, x0
    a8bc:      	b.ls	0xa824 <_stogir.switch.case-inputs+0x3b4>
    a8c0:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000a8c0:  ARM64_RELOC_PAGE21	l_stogir.445
    a8c4:      	ldr	x16, [x16]
		000000000000a8c4:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    a8c8:      	orr	x0, x16, xzr
    a8cc:      	mov	x1, x0
    a8d0:      	mov	x0, #0x1                ; =1
    a8d4:      	mov	x2, #0x1a               ; =26
    a8d8:      	b	0xa830 <_stogir.switch.case-inputs+0x3c0>
    a8dc:      	brk	#0
    a8e0:      	b	0xa8dc <_stogir.switch.case-inputs+0x46c>
    a8e4:      	brk	#0
    a8e8:      	b	0xa8e4 <_stogir.switch.case-inputs+0x474>
    a8ec:      	brk	#0
    a8f0:      	b	0xa8ec <_stogir.switch.case-inputs+0x47c>
    a8f4:      	mov	x21, x8
    a8f8:      	b	0xa66c <_stogir.switch.case-inputs+0x1fc>
    a8fc:      	mov	x21, x8
    a900:      	b	0xa66c <_stogir.switch.case-inputs+0x1fc>
    a904:      	mov	x21, x8
    a908:      	b	0xa66c <_stogir.switch.case-inputs+0x1fc>
    a90c:      	mov	x21, x8
    a910:      	b	0xa66c <_stogir.switch.case-inputs+0x1fc>
    a914:      	mov	x21, x8
    a918:      	b	0xa66c <_stogir.switch.case-inputs+0x1fc>

000000000000a91c <_stogir.stack.validate-frame-address>:
    a91c:      	sxtw	x1, w1
    a920:      	lsl	x2, x1, #2
    a924:      	cmp	x1, #0x0
    a928:      	cset	w3, gt
    a92c:      	movz	x16, #0x0, lsl #48
    a930:      	sub	x4, x16, x1
    a934:      	sub	x5, x4, #0x1
    a938:      	uxtb	w16, w3
    a93c:      	cmp	w16, wzr
    a940:      	b.eq	0xa980 <_stogir.stack.validate-frame-address+0x64>
    a944:      	ldr	x4, [x0, #0x8]
    a948:      	cmp	x1, x4
    a94c:      	b.ge	0xa9d4 <_stogir.stack.validate-frame-address+0xb8>
    a950:      	add	x4, x0, #0x78
    a954:      	ldr	x4, [x4, #0x8]
    a958:      	cmp	x1, x4
    a95c:      	b.ge	0xaaec <_stogir.stack.validate-frame-address+0x1d0>
    a960:      	ldr	x4, [x0, #0x78]
    a964:      	add	x4, x2, x4
    a968:      	ldr	w4, [x4]
    a96c:      	sxtw	x4, w4
    a970:      	cmp	x4, #0x0
    a974:      	cset	w4, ge
    a978:      	ubfx	x4, x4, #0, #8
    a97c:      	b	0xaaf0 <_stogir.stack.validate-frame-address+0x1d4>
    a980:      	cmp	x1, #0x0
    a984:      	b.ge	0xa9dc <_stogir.stack.validate-frame-address+0xc0>
    a988:      	add	x6, x0, #0x28
    a98c:      	add	x7, x0, #0x50
    a990:      	ldr	x6, [x6, #0x8]
    a994:      	ldr	x7, [x7, #0x8]
    a998:      	cmp	x6, x7
    a99c:      	b.ne	0xa9cc <_stogir.stack.validate-frame-address+0xb0>
    a9a0:      	cmp	x4, x6
    a9a4:      	b.gt	0xaaf4 <_stogir.stack.validate-frame-address+0x1d8>
    a9a8:      	lsl	x4, x5, #2
    a9ac:      	ldr	x4, [x0, #0x50]
    a9b0:      	add	x4, x4, x5, lsl #2
    a9b4:      	ldr	w4, [x4]
    a9b8:      	sxtw	x4, w4
    a9bc:      	cmp	x4, #0x0
    a9c0:      	cset	w4, gt
    a9c4:      	ubfx	x4, x4, #0, #8
    a9c8:      	b	0xaaf8 <_stogir.stack.validate-frame-address+0x1dc>
    a9cc:      	movz	x4, #0x0, lsl #48
    a9d0:      	b	0xa9e0 <_stogir.stack.validate-frame-address+0xc4>
    a9d4:      	movz	x4, #0x0, lsl #48
    a9d8:      	b	0xa9e0 <_stogir.stack.validate-frame-address+0xc4>
    a9dc:      	movz	x4, #0x0, lsl #48
    a9e0:      	cmp	x4, #0x0
    a9e4:      	b.eq	0xaa24 <_stogir.stack.validate-frame-address+0x108>
    a9e8:      	uxtb	w16, w3
    a9ec:      	cmp	w16, wzr
    a9f0:      	b.eq	0xaa08 <_stogir.stack.validate-frame-address+0xec>
    a9f4:      	lsl	x3, x1, #4
    a9f8:      	ldr	x3, [x0]
    a9fc:      	add	x3, x3, x1, lsl #4
    aa00:      	ldr	x3, [x3]
    aa04:      	b	0xaa18 <_stogir.stack.validate-frame-address+0xfc>
    aa08:      	lsl	x3, x5, #4
    aa0c:      	ldr	x3, [x0, #0x28]
    aa10:      	add	x3, x3, x5, lsl #4
    aa14:      	ldr	x3, [x3]
    aa18:      	mov	x4, x3
    aa1c:      	mov	x3, #0x1                ; =1
    aa20:      	b	0xaa2c <_stogir.stack.validate-frame-address+0x110>
    aa24:      	movz	x3, #0x0, lsl #48
    aa28:      	movz	x4, #0x0, lsl #48
    aa2c:      	lsr	w3, w3, #0
    aa30:      	lsr	x16, x3, #0
    aa34:      	cmp	x16, #0x1
    aa38:      	b.eq	0xaa54 <_stogir.stack.validate-frame-address+0x138>
    aa3c:      	b.lo	0xaa44 <_stogir.stack.validate-frame-address+0x128>
    aa40:      	b	0xaa58 <_stogir.stack.validate-frame-address+0x13c>
    aa44:      	cmp	x16, #0x0
    aa48:      	b.eq	0xaa50 <_stogir.stack.validate-frame-address+0x134>
    aa4c:      	b	0xaa58 <_stogir.stack.validate-frame-address+0x13c>
    aa50:      	b	0xaa5c <_stogir.stack.validate-frame-address+0x140>
    aa54:      	b	0xaaa0 <_stogir.stack.validate-frame-address+0x184>
    aa58:      	b	0xaafc <_stogir.stack.validate-frame-address+0x1e0>
    aa5c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000aa5c:  ARM64_RELOC_PAGE21	l_stogir.446
    aa60:      	ldr	x16, [x16]
		000000000000aa60:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    aa64:      	orr	x0, x16, xzr
    aa68:      	mov	x1, x0
    aa6c:      	mov	x0, #0x1                ; =1
    aa70:      	mov	x2, #0x21               ; =33
    aa74:      	b	0xaa90 <_stogir.stack.validate-frame-address+0x174>
    aa78:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000aa78:  ARM64_RELOC_PAGE21	l_stogir.447
    aa7c:      	ldr	x16, [x16]
		000000000000aa7c:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    aa80:      	orr	x0, x16, xzr
    aa84:      	mov	x1, x0
    aa88:      	mov	x0, #0x1                ; =1
    aa8c:      	mov	x2, #0x1e               ; =30
    aa90:      	str	x0, [x8]
    aa94:      	str	x1, [x8, #0x8]
    aa98:      	str	x2, [x8, #0x10]
    aa9c:      	ret
    aaa0:      	cmp	x1, #0x0
    aaa4:      	b.le	0xaa78 <_stogir.stack.validate-frame-address+0x15c>
    aaa8:      	uxtb	w1, w4
    aaac:      	cmp	x1, #0x42
    aab0:      	b.ne	0xaa78 <_stogir.stack.validate-frame-address+0x15c>
    aab4:      	lsr	w4, w4, #0
    aab8:      	ubfx	x1, x4, #8, #8
    aabc:      	cmp	x1, #0x6
    aac0:      	b.ne	0xaa78 <_stogir.stack.validate-frame-address+0x15c>
    aac4:      	ldr	x0, [x0, #0x78]
    aac8:      	add	x0, x2, x0
    aacc:      	ldr	w0, [x0]
    aad0:      	sxtw	x0, w0
    aad4:      	cmp	x0, #0x0
    aad8:      	b.ne	0xaa78 <_stogir.stack.validate-frame-address+0x15c>
    aadc:      	movz	x0, #0x0, lsl #48
    aae0:      	mov	x1, #0x8                ; =8
    aae4:      	movz	x2, #0x0, lsl #48
    aae8:      	b	0xaa90 <_stogir.stack.validate-frame-address+0x174>
    aaec:      	movz	x4, #0x0, lsl #48
    aaf0:      	b	0xa9d8 <_stogir.stack.validate-frame-address+0xbc>
    aaf4:      	movz	x4, #0x0, lsl #48
    aaf8:      	b	0xa9d0 <_stogir.stack.validate-frame-address+0xb4>
    aafc:      	brk	#0
    ab00:      	b	0xaafc <_stogir.stack.validate-frame-address+0x1e0>

000000000000ab04 <_stogir.stack.frame-object?>:
    ab04:      	ldr	w0, [x0]
    ab08:      	uxtb	w1, w0
    ab0c:      	cmp	x1, #0x51
    ab10:      	b.ne	0xab28 <_stogir.stack.frame-object?+0x24>
    ab14:      	ubfx	x0, x0, #16, #16
    ab18:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    ab1c:      	cset	w0, eq
    ab20:      	ubfx	x0, x0, #0, #8
    ab24:      	b	0xab2c <_stogir.stack.frame-object?+0x28>
    ab28:      	movz	x0, #0x0, lsl #48
    ab2c:      	ret

000000000000ab30 <_stogir.stack.valid-frame-object-inputs?>:
    ab30:      	sub	sp, sp, #0x50
    ab34:      	str	x29, [sp]
    ab38:      	str	x30, [sp, #0x8]
    ab3c:      	mov	x29, sp
    ab40:      	str	x19, [sp, #0x30]
    ab44:      	str	x20, [sp, #0x38]
    ab48:      	str	x21, [sp, #0x40]
    ab4c:      	add	x3, x0, #0x78
    ab50:      	add	x4, x0, #0x28
    ab54:      	add	x5, x0, #0x50
    ab58:      	add	x6, x0, #0x78
    ab5c:      	add	x7, x0, #0x28
    ab60:      	add	x8, x0, #0x50
    ab64:      	sxtw	x1, w1
    ab68:      	mov	x9, sp
    ab6c:      	sub	sp, sp, #0x10
    ab70:      	mov	x10, sp
    ab74:      	mov	x12, x1
    ab78:      	mov	x1, #0x1                ; =1
    ab7c:      	movz	x11, #0x0, lsl #48
    ab80:      	b	0xacd0 <_stogir.stack.valid-frame-object-inputs?+0x1a0>
    ab84:      	movz	x15, #0x0, lsl #48
    ab88:      	b	0xac00 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    ab8c:      	movz	x13, #0x0, lsl #48
    ab90:      	movz	x14, #0x0, lsl #48
    ab94:      	lsr	w13, w13, #0
    ab98:      	lsr	x16, x13, #0
    ab9c:      	cmp	x16, #0x1
    aba0:      	b.eq	0xabbc <_stogir.stack.valid-frame-object-inputs?+0x8c>
    aba4:      	b.lo	0xabac <_stogir.stack.valid-frame-object-inputs?+0x7c>
    aba8:      	b	0xabc0 <_stogir.stack.valid-frame-object-inputs?+0x90>
    abac:      	cmp	x16, #0x0
    abb0:      	b.eq	0xabb8 <_stogir.stack.valid-frame-object-inputs?+0x88>
    abb4:      	b	0xabc0 <_stogir.stack.valid-frame-object-inputs?+0x90>
    abb8:      	b	0xabe0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    abbc:      	b	0xabc4 <_stogir.stack.valid-frame-object-inputs?+0x94>
    abc0:      	b	0xafb8 <_stogir.stack.valid-frame-object-inputs?+0x488>
    abc4:      	uxtb	w13, w14
    abc8:      	lsr	w14, w14, #0
    abcc:      	ubfx	x14, x14, #8, #8
    abd0:      	cmp	x13, x14
    abd4:      	b.eq	0xafa4 <_stogir.stack.valid-frame-object-inputs?+0x474>
    abd8:      	cmp	x13, #0x49
    abdc:      	b.eq	0xafa4 <_stogir.stack.valid-frame-object-inputs?+0x474>
    abe0:      	movz	x1, #0x0, lsl #48
    abe4:      	fmov	d31, x11
    abe8:      	mov	x11, x12
    abec:      	fmov	x12, d31
    abf0:      	b	0xadb4 <_stogir.stack.valid-frame-object-inputs?+0x284>
    abf4:      	movz	x15, #0x0, lsl #48
    abf8:      	b	0xac08 <_stogir.stack.valid-frame-object-inputs?+0xd8>
    abfc:      	movz	x15, #0x0, lsl #48
    ac00:      	b	0xac10 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    ac04:      	movz	x15, #0x0, lsl #48
    ac08:      	b	0xac10 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    ac0c:      	movz	x15, #0x0, lsl #48
    ac10:      	cmp	x15, #0x0
    ac14:      	b.eq	0xac78 <_stogir.stack.valid-frame-object-inputs?+0x148>
    ac18:      	uxtb	w16, w14
    ac1c:      	cmp	w16, wzr
    ac20:      	b.eq	0xac48 <_stogir.stack.valid-frame-object-inputs?+0x118>
    ac24:      	lsl	x14, x13, #4
    ac28:      	ldr	x14, [x0]
    ac2c:      	add	x13, x14, x13, lsl #4
    ac30:      	ldr	x14, [x13]
    ac34:      	ldr	x13, [x13, #0x8]
    ac38:      	fmov	d31, x13
    ac3c:      	mov	x13, x14
    ac40:      	fmov	x14, d31
    ac44:      	b	0xac68 <_stogir.stack.valid-frame-object-inputs?+0x138>
    ac48:      	lsl	x13, x19, #4
    ac4c:      	ldr	x13, [x0, #0x28]
    ac50:      	add	x13, x13, x19, lsl #4
    ac54:      	ldr	x14, [x13]
    ac58:      	ldr	x13, [x13, #0x8]
    ac5c:      	fmov	d31, x13
    ac60:      	mov	x13, x14
    ac64:      	fmov	x14, d31
    ac68:      	mov	x15, x14
    ac6c:      	mov	x14, x13
    ac70:      	mov	x13, #0x1               ; =1
    ac74:      	b	0xac84 <_stogir.stack.valid-frame-object-inputs?+0x154>
    ac78:      	movz	x13, #0x0, lsl #48
    ac7c:      	movz	x14, #0x0, lsl #48
    ac80:      	movz	x15, #0x0, lsl #48
    ac84:      	lsr	w13, w13, #0
    ac88:      	lsr	x16, x13, #0
    ac8c:      	cmp	x16, #0x1
    ac90:      	b.eq	0xacac <_stogir.stack.valid-frame-object-inputs?+0x17c>
    ac94:      	b.lo	0xac9c <_stogir.stack.valid-frame-object-inputs?+0x16c>
    ac98:      	b	0xacb0 <_stogir.stack.valid-frame-object-inputs?+0x180>
    ac9c:      	cmp	x16, #0x0
    aca0:      	b.eq	0xaca8 <_stogir.stack.valid-frame-object-inputs?+0x178>
    aca4:      	b	0xacb0 <_stogir.stack.valid-frame-object-inputs?+0x180>
    aca8:      	b	0xacb4 <_stogir.stack.valid-frame-object-inputs?+0x184>
    acac:      	b	0xad88 <_stogir.stack.valid-frame-object-inputs?+0x258>
    acb0:      	b	0xaf00 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    acb4:      	fmov	d31, x11
    acb8:      	mov	x11, x12
    acbc:      	fmov	x12, d31
    acc0:      	movz	x1, #0x0, lsl #48
    acc4:      	fmov	d31, x11
    acc8:      	mov	x11, x12
    accc:      	fmov	x12, d31
    acd0:      	cmp	x1, #0x0
    acd4:      	b.eq	0xae44 <_stogir.stack.valid-frame-object-inputs?+0x314>
    acd8:      	cmp	x11, #0x0
    acdc:      	b.ne	0xae44 <_stogir.stack.valid-frame-object-inputs?+0x314>
    ace0:      	lsr	w13, w12, #0
    ace4:      	sxtw	x13, w13
    ace8:      	cmp	x13, #0x0
    acec:      	cset	w14, gt
    acf0:      	movz	x16, #0x0, lsl #48
    acf4:      	sub	x15, x16, x13
    acf8:      	sub	x19, x15, #0x1
    acfc:      	uxtb	w16, w14
    ad00:      	cmp	w16, wzr
    ad04:      	b.eq	0xad44 <_stogir.stack.valid-frame-object-inputs?+0x214>
    ad08:      	ldr	x15, [x0, #0x8]
    ad0c:      	cmp	x13, x15
    ad10:      	b.ge	0xac04 <_stogir.stack.valid-frame-object-inputs?+0xd4>
    ad14:      	ldr	x15, [x3, #0x8]
    ad18:      	cmp	x13, x15
    ad1c:      	b.ge	0xabf4 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    ad20:      	lsl	x15, x13, #2
    ad24:      	ldr	x15, [x0, #0x78]
    ad28:      	add	x15, x15, x13, lsl #2
    ad2c:      	ldr	w15, [x15]
    ad30:      	sxtw	x15, w15
    ad34:      	cmp	x15, #0x0
    ad38:      	cset	w15, ge
    ad3c:      	ubfx	x15, x15, #0, #8
    ad40:      	b	0xabf8 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    ad44:      	cmp	x13, #0x0
    ad48:      	b.ge	0xac0c <_stogir.stack.valid-frame-object-inputs?+0xdc>
    ad4c:      	ldr	x20, [x4, #0x8]
    ad50:      	ldr	x21, [x5, #0x8]
    ad54:      	cmp	x20, x21
    ad58:      	b.ne	0xabfc <_stogir.stack.valid-frame-object-inputs?+0xcc>
    ad5c:      	cmp	x15, x20
    ad60:      	b.gt	0xab84 <_stogir.stack.valid-frame-object-inputs?+0x54>
    ad64:      	lsl	x15, x19, #2
    ad68:      	ldr	x15, [x0, #0x50]
    ad6c:      	add	x15, x15, x19, lsl #2
    ad70:      	ldr	w15, [x15]
    ad74:      	sxtw	x15, w15
    ad78:      	cmp	x15, #0x0
    ad7c:      	cset	w15, gt
    ad80:      	ubfx	x15, x15, #0, #8
    ad84:      	b	0xab88 <_stogir.stack.valid-frame-object-inputs?+0x58>
    ad88:      	uxtb	w13, w14
    ad8c:      	asr	x19, x14, #32
    ad90:      	str	x14, [x10]
    ad94:      	str	x15, [x10, #0x8]
    ad98:      	cmp	x13, #0x68
    ad9c:      	b.ne	0xadb8 <_stogir.stack.valid-frame-object-inputs?+0x288>
    ada0:      	cmp	x19, #0x0
    ada4:      	cset	w1, eq
    ada8:      	ubfx	x1, x1, #0, #8
    adac:      	mov	x11, x12
    adb0:      	mov	x12, #0x1               ; =1
    adb4:      	b	0xacc4 <_stogir.stack.valid-frame-object-inputs?+0x194>
    adb8:      	cmp	x12, #0x0
    adbc:      	b.le	0xabe0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    adc0:      	cmp	x13, #0x51
    adc4:      	b.ne	0xabe0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    adc8:      	cmp	x19, #0x0
    adcc:      	b.le	0xabe0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    add0:      	cmp	x19, x12
    add4:      	b.ge	0xabe0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    add8:      	lsr	w15, w15, #0
    addc:      	sxtw	x15, w15
    ade0:      	cmp	x15, #0x0
    ade4:      	b.ge	0xabe0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    ade8:      	cmp	x15, #0x0
    adec:      	cset	w13, gt
    adf0:      	movz	x16, #0x0, lsl #48
    adf4:      	sub	x14, x16, x15
    adf8:      	sub	x19, x14, #0x1
    adfc:      	uxtb	w16, w13
    ae00:      	cmp	w16, wzr
    ae04:      	b.eq	0xaf58 <_stogir.stack.valid-frame-object-inputs?+0x428>
    ae08:      	ldr	x14, [x0, #0x8]
    ae0c:      	cmp	x15, x14
    ae10:      	b.ge	0xaf50 <_stogir.stack.valid-frame-object-inputs?+0x420>
    ae14:      	ldr	x14, [x6, #0x8]
    ae18:      	cmp	x15, x14
    ae1c:      	b.ge	0xaf9c <_stogir.stack.valid-frame-object-inputs?+0x46c>
    ae20:      	lsl	x14, x15, #2
    ae24:      	ldr	x14, [x0, #0x78]
    ae28:      	add	x14, x14, x15, lsl #2
    ae2c:      	ldr	w14, [x14]
    ae30:      	sxtw	x14, w14
    ae34:      	cmp	x14, #0x0
    ae38:      	cset	w14, ge
    ae3c:      	ubfx	x14, x14, #0, #8
    ae40:      	b	0xafa0 <_stogir.stack.valid-frame-object-inputs?+0x470>
    ae44:      	cmp	x1, #0x0
    ae48:      	b.eq	0xae54 <_stogir.stack.valid-frame-object-inputs?+0x324>
    ae4c:      	mov	x1, x11
    ae50:      	b	0xae58 <_stogir.stack.valid-frame-object-inputs?+0x328>
    ae54:      	movz	x1, #0x0, lsl #48
    ae58:      	mov	sp, x9
    ae5c:      	cmp	x1, #0x0
    ae60:      	b.eq	0xaebc <_stogir.stack.valid-frame-object-inputs?+0x38c>
    ae64:      	sxtw	x1, w2
    ae68:      	cmp	x1, #0x0
    ae6c:      	b.ge	0xaee0 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    ae70:      	lsr	w2, w2, #0
    ae74:      	add	x8, x29, #0x10
    ae78:      	mov	w1, w2
    ae7c:      	bl	0xae7c <_stogir.stack.valid-frame-object-inputs?+0x34c>
		000000000000ae7c:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    ae80:      	add	x16, x29, #0x10
    ae84:      	ldr	w0, [x16]
    ae88:      	lsr	x16, x0, #0
    ae8c:      	cmp	x16, #0x1
    ae90:      	b.eq	0xaeac <_stogir.stack.valid-frame-object-inputs?+0x37c>
    ae94:      	b.lo	0xae9c <_stogir.stack.valid-frame-object-inputs?+0x36c>
    ae98:      	b	0xaeb0 <_stogir.stack.valid-frame-object-inputs?+0x380>
    ae9c:      	cmp	x16, #0x0
    aea0:      	b.eq	0xaea8 <_stogir.stack.valid-frame-object-inputs?+0x378>
    aea4:      	b	0xaeb0 <_stogir.stack.valid-frame-object-inputs?+0x380>
    aea8:      	b	0xaee8 <_stogir.stack.valid-frame-object-inputs?+0x3b8>
    aeac:      	b	0xaeb4 <_stogir.stack.valid-frame-object-inputs?+0x384>
    aeb0:      	b	0xafb0 <_stogir.stack.valid-frame-object-inputs?+0x480>
    aeb4:      	movz	x0, #0x0, lsl #48
    aeb8:      	b	0xaefc <_stogir.stack.valid-frame-object-inputs?+0x3cc>
    aebc:      	movz	x0, #0x0, lsl #48
    aec0:      	sub	sp, x29, #0x0
    aec4:      	ldr	x19, [sp, #0x30]
    aec8:      	ldr	x20, [sp, #0x38]
    aecc:      	ldr	x21, [sp, #0x40]
    aed0:      	ldr	x29, [sp]
    aed4:      	ldr	x30, [sp, #0x8]
    aed8:      	add	sp, sp, #0x50
    aedc:      	ret
    aee0:      	movz	x0, #0x0, lsl #48
    aee4:      	b	0xaec0 <_stogir.stack.valid-frame-object-inputs?+0x390>
    aee8:      	add	x16, x29, #0x10
    aeec:      	ldr	x0, [x16, #0x8]
    aef0:      	cmp	x0, #0x0
    aef4:      	cset	w0, gt
    aef8:      	ubfx	x0, x0, #0, #8
    aefc:      	b	0xaee4 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    af00:      	brk	#0
    af04:      	b	0xaf00 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    af08:      	lsl	x13, x19, #4
    af0c:      	ldr	x13, [x0, #0x28]
    af10:      	add	x13, x13, x19, lsl #4
    af14:      	ldr	x13, [x13]
    af18:      	mov	x14, x13
    af1c:      	mov	x13, #0x1               ; =1
    af20:      	b	0xab94 <_stogir.stack.valid-frame-object-inputs?+0x64>
    af24:      	movz	x14, #0x0, lsl #48
    af28:      	cmp	x14, #0x0
    af2c:      	b.eq	0xab8c <_stogir.stack.valid-frame-object-inputs?+0x5c>
    af30:      	uxtb	w16, w13
    af34:      	cmp	w16, wzr
    af38:      	b.eq	0xaf08 <_stogir.stack.valid-frame-object-inputs?+0x3d8>
    af3c:      	lsl	x13, x15, #4
    af40:      	ldr	x13, [x0]
    af44:      	add	x13, x13, x15, lsl #4
    af48:      	ldr	x13, [x13]
    af4c:      	b	0xaf18 <_stogir.stack.valid-frame-object-inputs?+0x3e8>
    af50:      	movz	x14, #0x0, lsl #48
    af54:      	b	0xaf28 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    af58:      	ldr	x20, [x7, #0x8]
    af5c:      	ldr	x21, [x8, #0x8]
    af60:      	cmp	x20, x21
    af64:      	b.ne	0xaf24 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    af68:      	cmp	x14, x20
    af6c:      	b.gt	0xaf94 <_stogir.stack.valid-frame-object-inputs?+0x464>
    af70:      	lsl	x14, x19, #2
    af74:      	ldr	x14, [x0, #0x50]
    af78:      	add	x14, x14, x19, lsl #2
    af7c:      	ldr	w14, [x14]
    af80:      	sxtw	x14, w14
    af84:      	cmp	x14, #0x0
    af88:      	cset	w14, gt
    af8c:      	ubfx	x14, x14, #0, #8
    af90:      	b	0xaf98 <_stogir.stack.valid-frame-object-inputs?+0x468>
    af94:      	movz	x14, #0x0, lsl #48
    af98:      	b	0xaf28 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    af9c:      	movz	x14, #0x0, lsl #48
    afa0:      	b	0xaf54 <_stogir.stack.valid-frame-object-inputs?+0x424>
    afa4:      	ldr	w12, [x10, #0x4]
    afa8:      	sxtw	x12, w12
    afac:      	b	0xabe4 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    afb0:      	brk	#0
    afb4:      	b	0xafb0 <_stogir.stack.valid-frame-object-inputs?+0x480>
    afb8:      	brk	#0
    afbc:      	b	0xafb8 <_stogir.stack.valid-frame-object-inputs?+0x488>

000000000000afc0 <_stogir.stack.validate-scope-inputs>:
    afc0:      	sxtw	x1, w1
    afc4:      	cmp	x1, #0x53
    afc8:      	cset	w5, eq
    afcc:      	uxtb	w16, w5
    afd0:      	cmp	w16, wzr
    afd4:      	b.ne	0xb008 <_stogir.stack.validate-scope-inputs+0x48>
    afd8:      	cmp	x1, #0x54
    afdc:      	b.eq	0xb008 <_stogir.stack.validate-scope-inputs+0x48>
    afe0:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x434>
		000000000000afe0:  ARM64_RELOC_PAGE21	l_stogir.448
    afe4:      	ldr	x16, [x16]
		000000000000afe4:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    afe8:      	orr	x0, x16, xzr
    afec:      	mov	x1, x0
    aff0:      	mov	x0, #0x1                ; =1
    aff4:      	mov	x2, #0x22               ; =34
    aff8:      	str	x0, [x8]
    affc:      	str	x1, [x8, #0x8]
    b000:      	str	x2, [x8, #0x10]
    b004:      	ret
    b008:      	uxtb	w16, w5
    b00c:      	cmp	w16, wzr
    b010:      	mov	x16, #0x6               ; =6
    b014:      	movz	x17, #0x0, lsl #48
    b018:      	csel	x1, x16, x17, ne
    b01c:      	sxtw	x2, w2
    b020:      	lsr	w1, w1, #0
    b024:      	sxtw	x1, w1
    b028:      	cmp	x2, x1
    b02c:      	b.ne	0xafe0 <_stogir.stack.validate-scope-inputs+0x20>
    b030:      	sxtw	x3, w3
    b034:      	cmp	x3, #0x0
    b038:      	cset	w1, gt
    b03c:      	movz	x16, #0x0, lsl #48
    b040:      	sub	x2, x16, x3
    b044:      	sub	x6, x2, #0x1
    b048:      	uxtb	w16, w1
    b04c:      	cmp	w16, wzr
    b050:      	b.eq	0xb138 <_stogir.stack.validate-scope-inputs+0x178>
    b054:      	ldr	x2, [x0, #0x8]
    b058:      	cmp	x3, x2
    b05c:      	b.ge	0xb130 <_stogir.stack.validate-scope-inputs+0x170>
    b060:      	add	x2, x0, #0x78
    b064:      	ldr	x2, [x2, #0x8]
    b068:      	cmp	x3, x2
    b06c:      	b.ge	0xb1e0 <_stogir.stack.validate-scope-inputs+0x220>
    b070:      	lsl	x2, x3, #2
    b074:      	ldr	x2, [x0, #0x78]
    b078:      	add	x2, x2, x3, lsl #2
    b07c:      	ldr	w2, [x2]
    b080:      	sxtw	x2, w2
    b084:      	cmp	x2, #0x0
    b088:      	cset	w2, ge
    b08c:      	ubfx	x2, x2, #0, #8
    b090:      	b	0xb1e4 <_stogir.stack.validate-scope-inputs+0x224>
    b094:      	movz	x1, #0x0, lsl #48
    b098:      	movz	x2, #0x0, lsl #48
    b09c:      	lsr	w1, w1, #0
    b0a0:      	lsr	x16, x1, #0
    b0a4:      	cmp	x16, #0x1
    b0a8:      	b.eq	0xb0c4 <_stogir.stack.validate-scope-inputs+0x104>
    b0ac:      	b.lo	0xb0b4 <_stogir.stack.validate-scope-inputs+0xf4>
    b0b0:      	b	0xb0c8 <_stogir.stack.validate-scope-inputs+0x108>
    b0b4:      	cmp	x16, #0x0
    b0b8:      	b.eq	0xb0c0 <_stogir.stack.validate-scope-inputs+0x100>
    b0bc:      	b	0xb0c8 <_stogir.stack.validate-scope-inputs+0x108>
    b0c0:      	b	0xb0cc <_stogir.stack.validate-scope-inputs+0x10c>
    b0c4:      	b	0xb184 <_stogir.stack.validate-scope-inputs+0x1c4>
    b0c8:      	b	0xb3c8 <_stogir.stack.validate-scope-inputs+0x408>
    b0cc:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b0cc:  ARM64_RELOC_PAGE21	l_stogir.449
    b0d0:      	ldr	x16, [x16]
		000000000000b0d0:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    b0d4:      	orr	x0, x16, xzr
    b0d8:      	mov	x1, x0
    b0dc:      	mov	x0, #0x1                ; =1
    b0e0:      	mov	x2, #0x1b               ; =27
    b0e4:      	b	0xaff8 <_stogir.stack.validate-scope-inputs+0x38>
    b0e8:      	lsl	x1, x6, #4
    b0ec:      	ldr	x1, [x0, #0x28]
    b0f0:      	add	x1, x1, x6, lsl #4
    b0f4:      	ldr	x1, [x1]
    b0f8:      	mov	x2, x1
    b0fc:      	mov	x1, #0x1                ; =1
    b100:      	b	0xb09c <_stogir.stack.validate-scope-inputs+0xdc>
    b104:      	movz	x2, #0x0, lsl #48
    b108:      	cmp	x2, #0x0
    b10c:      	b.eq	0xb094 <_stogir.stack.validate-scope-inputs+0xd4>
    b110:      	uxtb	w16, w1
    b114:      	cmp	w16, wzr
    b118:      	b.eq	0xb0e8 <_stogir.stack.validate-scope-inputs+0x128>
    b11c:      	lsl	x1, x3, #4
    b120:      	ldr	x1, [x0]
    b124:      	add	x1, x1, x3, lsl #4
    b128:      	ldr	x1, [x1]
    b12c:      	b	0xb0f8 <_stogir.stack.validate-scope-inputs+0x138>
    b130:      	movz	x2, #0x0, lsl #48
    b134:      	b	0xb108 <_stogir.stack.validate-scope-inputs+0x148>
    b138:      	cmp	x3, #0x0
    b13c:      	b.ge	0xb104 <_stogir.stack.validate-scope-inputs+0x144>
    b140:      	add	x7, x0, #0x28
    b144:      	add	x9, x0, #0x50
    b148:      	ldr	x7, [x7, #0x8]
    b14c:      	ldr	x9, [x9, #0x8]
    b150:      	cmp	x7, x9
    b154:      	b.ne	0xb1d8 <_stogir.stack.validate-scope-inputs+0x218>
    b158:      	cmp	x2, x7
    b15c:      	b.gt	0xb1e8 <_stogir.stack.validate-scope-inputs+0x228>
    b160:      	lsl	x2, x6, #2
    b164:      	ldr	x2, [x0, #0x50]
    b168:      	add	x2, x2, x6, lsl #2
    b16c:      	ldr	w2, [x2]
    b170:      	sxtw	x2, w2
    b174:      	cmp	x2, #0x0
    b178:      	cset	w2, gt
    b17c:      	ubfx	x2, x2, #0, #8
    b180:      	b	0xb1ec <_stogir.stack.validate-scope-inputs+0x22c>
    b184:      	cmp	x3, #0x0
    b188:      	b.le	0xb1bc <_stogir.stack.validate-scope-inputs+0x1fc>
    b18c:      	uxtb	w2, w2
    b190:      	cmp	x2, #0x83
    b194:      	cset	w1, lt
    b198:      	uxtb	w16, w1
    b19c:      	cmp	w16, wzr
    b1a0:      	b.eq	0xb1f0 <_stogir.stack.validate-scope-inputs+0x230>
    b1a4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b1a4:  ARM64_RELOC_PAGE21	l_stogir.450
    b1a8:      	ldr	x16, [x16]
		000000000000b1a8:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b1ac:      	orr	x3, x16, xzr
    b1b0:      	add	x3, x2, x3
    b1b4:      	ldrb	w3, [x3]
    b1b8:      	b	0xb1f4 <_stogir.stack.validate-scope-inputs+0x234>
    b1bc:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b1bc:  ARM64_RELOC_PAGE21	l_stogir.451
    b1c0:      	ldr	x16, [x16]
		000000000000b1c0:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    b1c4:      	orr	x0, x16, xzr
    b1c8:      	mov	x1, x0
    b1cc:      	mov	x0, #0x1                ; =1
    b1d0:      	mov	x2, #0x1b               ; =27
    b1d4:      	b	0xb0e4 <_stogir.stack.validate-scope-inputs+0x124>
    b1d8:      	movz	x2, #0x0, lsl #48
    b1dc:      	b	0xb108 <_stogir.stack.validate-scope-inputs+0x148>
    b1e0:      	movz	x2, #0x0, lsl #48
    b1e4:      	b	0xb134 <_stogir.stack.validate-scope-inputs+0x174>
    b1e8:      	movz	x2, #0x0, lsl #48
    b1ec:      	b	0xb1dc <_stogir.stack.validate-scope-inputs+0x21c>
    b1f0:      	movz	x3, #0x0, lsl #48
    b1f4:      	uxtb	w3, w3
    b1f8:      	and	x3, x3, #0x1
    b1fc:      	uxtb	w3, w3
    b200:      	cmp	x3, #0x0
    b204:      	b.eq	0xb1bc <_stogir.stack.validate-scope-inputs+0x1fc>
    b208:      	uxtb	w16, w1
    b20c:      	cmp	w16, wzr
    b210:      	b.eq	0xb22c <_stogir.stack.validate-scope-inputs+0x26c>
    b214:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b214:  ARM64_RELOC_PAGE21	l_stogir.450
    b218:      	ldr	x16, [x16]
		000000000000b218:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b21c:      	orr	x1, x16, xzr
    b220:      	add	x1, x2, x1
    b224:      	ldrb	w1, [x1]
    b228:      	b	0xb230 <_stogir.stack.validate-scope-inputs+0x270>
    b22c:      	movz	x1, #0x0, lsl #48
    b230:      	uxtb	w1, w1
    b234:      	and	x1, x1, #0x4
    b238:      	uxtb	w1, w1
    b23c:      	cmp	x1, #0x0
    b240:      	cset	w1, eq
    b244:      	uxtb	w16, w1
    b248:      	cmp	w16, wzr
    b24c:      	cset	x1, eq
    b250:      	cmp	x1, #0x0
    b254:      	b.ne	0xb1bc <_stogir.stack.validate-scope-inputs+0x1fc>
    b258:      	uxtb	w16, w5
    b25c:      	cmp	w16, wzr
    b260:      	b.eq	0xb274 <_stogir.stack.validate-scope-inputs+0x2b4>
    b264:      	movz	x0, #0x0, lsl #48
    b268:      	mov	x1, #0x8                ; =8
    b26c:      	movz	x2, #0x0, lsl #48
    b270:      	b	0xb1d4 <_stogir.stack.validate-scope-inputs+0x214>
    b274:      	sxtw	x4, w4
    b278:      	cmp	x4, #0x0
    b27c:      	cset	w1, gt
    b280:      	movz	x16, #0x0, lsl #48
    b284:      	sub	x2, x16, x4
    b288:      	sub	x3, x2, #0x1
    b28c:      	uxtb	w16, w1
    b290:      	cmp	w16, wzr
    b294:      	b.eq	0xb37c <_stogir.stack.validate-scope-inputs+0x3bc>
    b298:      	ldr	x2, [x0, #0x8]
    b29c:      	cmp	x4, x2
    b2a0:      	b.ge	0xb374 <_stogir.stack.validate-scope-inputs+0x3b4>
    b2a4:      	add	x2, x0, #0x78
    b2a8:      	ldr	x2, [x2, #0x8]
    b2ac:      	cmp	x4, x2
    b2b0:      	b.ge	0xb420 <_stogir.stack.validate-scope-inputs+0x460>
    b2b4:      	lsl	x2, x4, #2
    b2b8:      	ldr	x2, [x0, #0x78]
    b2bc:      	add	x2, x2, x4, lsl #2
    b2c0:      	ldr	w2, [x2]
    b2c4:      	sxtw	x2, w2
    b2c8:      	cmp	x2, #0x0
    b2cc:      	cset	w2, ge
    b2d0:      	ubfx	x2, x2, #0, #8
    b2d4:      	b	0xb424 <_stogir.stack.validate-scope-inputs+0x464>
    b2d8:      	movz	x0, #0x0, lsl #48
    b2dc:      	movz	x1, #0x0, lsl #48
    b2e0:      	lsr	w0, w0, #0
    b2e4:      	lsr	x16, x0, #0
    b2e8:      	cmp	x16, #0x1
    b2ec:      	b.eq	0xb308 <_stogir.stack.validate-scope-inputs+0x348>
    b2f0:      	b.lo	0xb2f8 <_stogir.stack.validate-scope-inputs+0x338>
    b2f4:      	b	0xb30c <_stogir.stack.validate-scope-inputs+0x34c>
    b2f8:      	cmp	x16, #0x0
    b2fc:      	b.eq	0xb304 <_stogir.stack.validate-scope-inputs+0x344>
    b300:      	b	0xb30c <_stogir.stack.validate-scope-inputs+0x34c>
    b304:      	b	0xb310 <_stogir.stack.validate-scope-inputs+0x350>
    b308:      	b	0xb3d0 <_stogir.stack.validate-scope-inputs+0x410>
    b30c:      	b	0xb430 <_stogir.stack.validate-scope-inputs+0x470>
    b310:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b310:  ARM64_RELOC_PAGE21	l_stogir.452
    b314:      	ldr	x16, [x16]
		000000000000b314:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    b318:      	orr	x0, x16, xzr
    b31c:      	mov	x1, x0
    b320:      	mov	x0, #0x1                ; =1
    b324:      	mov	x2, #0x1b               ; =27
    b328:      	b	0xb270 <_stogir.stack.validate-scope-inputs+0x2b0>
    b32c:      	lsl	x1, x3, #4
    b330:      	ldr	x0, [x0, #0x28]
    b334:      	add	x0, x0, x3, lsl #4
    b338:      	ldr	x0, [x0]
    b33c:      	mov	x1, x0
    b340:      	mov	x0, #0x1                ; =1
    b344:      	b	0xb2e0 <_stogir.stack.validate-scope-inputs+0x320>
    b348:      	movz	x2, #0x0, lsl #48
    b34c:      	cmp	x2, #0x0
    b350:      	b.eq	0xb2d8 <_stogir.stack.validate-scope-inputs+0x318>
    b354:      	uxtb	w16, w1
    b358:      	cmp	w16, wzr
    b35c:      	b.eq	0xb32c <_stogir.stack.validate-scope-inputs+0x36c>
    b360:      	lsl	x1, x4, #4
    b364:      	ldr	x0, [x0]
    b368:      	add	x0, x0, x4, lsl #4
    b36c:      	ldr	x0, [x0]
    b370:      	b	0xb33c <_stogir.stack.validate-scope-inputs+0x37c>
    b374:      	movz	x2, #0x0, lsl #48
    b378:      	b	0xb34c <_stogir.stack.validate-scope-inputs+0x38c>
    b37c:      	cmp	x4, #0x0
    b380:      	b.ge	0xb348 <_stogir.stack.validate-scope-inputs+0x388>
    b384:      	add	x5, x0, #0x28
    b388:      	add	x6, x0, #0x50
    b38c:      	ldr	x5, [x5, #0x8]
    b390:      	ldr	x6, [x6, #0x8]
    b394:      	cmp	x5, x6
    b398:      	b.ne	0xb418 <_stogir.stack.validate-scope-inputs+0x458>
    b39c:      	cmp	x2, x5
    b3a0:      	b.gt	0xb428 <_stogir.stack.validate-scope-inputs+0x468>
    b3a4:      	lsl	x2, x3, #2
    b3a8:      	ldr	x2, [x0, #0x50]
    b3ac:      	add	x2, x2, x3, lsl #2
    b3b0:      	ldr	w2, [x2]
    b3b4:      	sxtw	x2, w2
    b3b8:      	cmp	x2, #0x0
    b3bc:      	cset	w2, gt
    b3c0:      	ubfx	x2, x2, #0, #8
    b3c4:      	b	0xb42c <_stogir.stack.validate-scope-inputs+0x46c>
    b3c8:      	brk	#0
    b3cc:      	b	0xb3c8 <_stogir.stack.validate-scope-inputs+0x408>
    b3d0:      	lsr	w0, w1, #0
    b3d4:      	ubfx	x0, x0, #8, #8
    b3d8:      	cmp	x0, #0x6
    b3dc:      	b.ne	0xb3fc <_stogir.stack.validate-scope-inputs+0x43c>
    b3e0:      	uxtb	w1, w1
    b3e4:      	cmp	x1, #0x48
    b3e8:      	b.eq	0xb3fc <_stogir.stack.validate-scope-inputs+0x43c>
    b3ec:      	movz	x0, #0x0, lsl #48
    b3f0:      	mov	x1, #0x8                ; =8
    b3f4:      	movz	x2, #0x0, lsl #48
    b3f8:      	b	0xb414 <_stogir.stack.validate-scope-inputs+0x454>
    b3fc:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b3fc:  ARM64_RELOC_PAGE21	l_stogir.453
    b400:      	ldr	x16, [x16]
		000000000000b400:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    b404:      	orr	x0, x16, xzr
    b408:      	mov	x1, x0
    b40c:      	mov	x0, #0x1                ; =1
    b410:      	mov	x2, #0x29               ; =41
    b414:      	b	0xb328 <_stogir.stack.validate-scope-inputs+0x368>
    b418:      	movz	x2, #0x0, lsl #48
    b41c:      	b	0xb34c <_stogir.stack.validate-scope-inputs+0x38c>
    b420:      	movz	x2, #0x0, lsl #48
    b424:      	b	0xb378 <_stogir.stack.validate-scope-inputs+0x3b8>
    b428:      	movz	x2, #0x0, lsl #48
    b42c:      	b	0xb41c <_stogir.stack.validate-scope-inputs+0x45c>
    b430:      	brk	#0
    b434:      	b	0xb430 <_stogir.stack.validate-scope-inputs+0x470>

000000000000b438 <_stogir.stack.validate-inputs>:
    b438:      	sub	sp, sp, #0x110
    b43c:      	str	x29, [sp]
    b440:      	str	x30, [sp, #0x8]
    b444:      	mov	x29, sp
    b448:      	str	x19, [sp, #0xb8]
    b44c:      	str	x20, [sp, #0xc0]
    b450:      	str	x21, [sp, #0xc8]
    b454:      	str	x22, [sp, #0xd0]
    b458:      	str	x23, [sp, #0xd8]
    b45c:      	str	x24, [sp, #0xe0]
    b460:      	str	x25, [sp, #0xe8]
    b464:      	str	x26, [sp, #0xf0]
    b468:      	str	x27, [sp, #0xf8]
    b46c:      	str	x28, [sp, #0x100]
    b470:      	sxtw	x1, w1
    b474:      	cmp	x1, #0x51
    b478:      	cset	w19, eq
    b47c:      	uxtb	w16, w19
    b480:      	cmp	w16, wzr
    b484:      	b.ne	0xb4f4 <_stogir.stack.validate-inputs+0xbc>
    b488:      	cmp	x1, #0x52
    b48c:      	b.eq	0xb4f4 <_stogir.stack.validate-inputs+0xbc>
    b490:      	str	x8, [sp, #0x90]
    b494:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b494:  ARM64_RELOC_PAGE21	l_stogir.454
    b498:      	ldr	x16, [x16]
		000000000000b498:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    b49c:      	orr	x0, x16, xzr
    b4a0:      	mov	x1, x0
    b4a4:      	mov	x0, #0x1                ; =1
    b4a8:      	mov	x2, #0x29               ; =41
    b4ac:      	ldr	x3, [sp, #0x90]
    b4b0:      	str	x0, [x3]
    b4b4:      	str	x1, [x3, #0x8]
    b4b8:      	str	x2, [x3, #0x10]
    b4bc:      	ldr	x19, [sp, #0xb8]
    b4c0:      	ldr	x20, [sp, #0xc0]
    b4c4:      	ldr	x21, [sp, #0xc8]
    b4c8:      	ldr	x22, [sp, #0xd0]
    b4cc:      	ldr	x23, [sp, #0xd8]
    b4d0:      	ldr	x24, [sp, #0xe0]
    b4d4:      	ldr	x25, [sp, #0xe8]
    b4d8:      	ldr	x26, [sp, #0xf0]
    b4dc:      	ldr	x27, [sp, #0xf8]
    b4e0:      	ldr	x28, [sp, #0x100]
    b4e4:      	ldr	x29, [sp]
    b4e8:      	ldr	x30, [sp, #0x8]
    b4ec:      	add	sp, sp, #0x110
    b4f0:      	ret
    b4f4:      	uxtb	w16, w19
    b4f8:      	cmp	w16, wzr
    b4fc:      	mov	x16, #0x6               ; =6
    b500:      	movz	x17, #0x0, lsl #48
    b504:      	csel	x1, x16, x17, ne
    b508:      	sxtw	x2, w2
    b50c:      	lsr	w1, w1, #0
    b510:      	sxtw	x1, w1
    b514:      	cmp	x2, x1
    b518:      	b.ne	0xba78 <_stogir.stack.validate-inputs+0x640>
    b51c:      	sxtw	x20, w5
    b520:      	uxtb	w16, w19
    b524:      	cmp	w16, wzr
    b528:      	b.eq	0xb54c <_stogir.stack.validate-inputs+0x114>
    b52c:      	cmp	x20, #0x0
    b530:      	b.eq	0xb54c <_stogir.stack.validate-inputs+0x114>
    b534:      	cmp	x20, #0x0
    b538:      	b.le	0xb5f4 <_stogir.stack.validate-inputs+0x1bc>
    b53c:      	sub	x1, x20, #0x1
    b540:      	and	x1, x1, x20
    b544:      	cmp	x1, #0x0
    b548:      	b.ne	0xb5f4 <_stogir.stack.validate-inputs+0x1bc>
    b54c:      	lsr	w3, w3, #0
    b550:      	mov	w1, w3
    b554:      	mov	x21, x8
    b558:      	add	x8, sp, #0x10
    b55c:      	mov	x22, x0
    b560:      	mov	w23, w3
    b564:      	mov	w24, w4
    b568:      	bl	0xb568 <_stogir.stack.validate-inputs+0x130>
		000000000000b568:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b56c:      	add	x16, sp, #0x10
    b570:      	ldr	w0, [x16]
    b574:      	lsr	x16, x0, #0
    b578:      	cmp	x16, #0x1
    b57c:      	b.eq	0xb598 <_stogir.stack.validate-inputs+0x160>
    b580:      	b.lo	0xb588 <_stogir.stack.validate-inputs+0x150>
    b584:      	b	0xb59c <_stogir.stack.validate-inputs+0x164>
    b588:      	cmp	x16, #0x0
    b58c:      	b.eq	0xb594 <_stogir.stack.validate-inputs+0x15c>
    b590:      	b	0xb59c <_stogir.stack.validate-inputs+0x164>
    b594:      	b	0xb5a0 <_stogir.stack.validate-inputs+0x168>
    b598:      	b	0xb5c0 <_stogir.stack.validate-inputs+0x188>
    b59c:      	b	0xb7f0 <_stogir.stack.validate-inputs+0x3b8>
    b5a0:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b5a0:  ARM64_RELOC_PAGE21	l_stogir.455
    b5a4:      	ldr	x16, [x16]
		000000000000b5a4:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    b5a8:      	orr	x0, x16, xzr
    b5ac:      	str	x21, [sp, #0x90]
    b5b0:      	mov	x1, x0
    b5b4:      	mov	x0, #0x1                ; =1
    b5b8:      	mov	x2, #0x1f               ; =31
    b5bc:      	b	0xb4ac <_stogir.stack.validate-inputs+0x74>
    b5c0:      	sxtw	x23, w23
    b5c4:      	add	x16, sp, #0x10
    b5c8:      	ldr	x0, [x16, #0x8]
    b5cc:      	cmp	x23, #0x0
    b5d0:      	b.gt	0xb5fc <_stogir.stack.validate-inputs+0x1c4>
    b5d4:      	str	x21, [sp, #0x90]
    b5d8:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b5d8:  ARM64_RELOC_PAGE21	l_stogir.456
    b5dc:      	ldr	x16, [x16]
		000000000000b5dc:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    b5e0:      	orr	x0, x16, xzr
    b5e4:      	mov	x1, x0
    b5e8:      	mov	x0, #0x1                ; =1
    b5ec:      	mov	x2, #0x1f               ; =31
    b5f0:      	b	0xb5bc <_stogir.stack.validate-inputs+0x184>
    b5f4:      	str	x8, [sp, #0x90]
    b5f8:      	b	0xb494 <_stogir.stack.validate-inputs+0x5c>
    b5fc:      	uxtb	w0, w0
    b600:      	cmp	x0, #0x83
    b604:      	cset	w1, lt
    b608:      	uxtb	w16, w1
    b60c:      	cmp	w16, wzr
    b610:      	b.eq	0xb62c <_stogir.stack.validate-inputs+0x1f4>
    b614:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b614:  ARM64_RELOC_PAGE21	l_stogir.457
    b618:      	ldr	x16, [x16]
		000000000000b618:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b61c:      	orr	x2, x16, xzr
    b620:      	add	x2, x0, x2
    b624:      	ldrb	w2, [x2]
    b628:      	b	0xb630 <_stogir.stack.validate-inputs+0x1f8>
    b62c:      	movz	x2, #0x0, lsl #48
    b630:      	uxtb	w2, w2
    b634:      	and	x2, x2, #0x1
    b638:      	uxtb	w2, w2
    b63c:      	cmp	x2, #0x0
    b640:      	b.eq	0xba80 <_stogir.stack.validate-inputs+0x648>
    b644:      	uxtb	w16, w1
    b648:      	cmp	w16, wzr
    b64c:      	b.eq	0xb668 <_stogir.stack.validate-inputs+0x230>
    b650:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b650:  ARM64_RELOC_PAGE21	l_stogir.457
    b654:      	ldr	x16, [x16]
		000000000000b654:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b658:      	orr	x1, x16, xzr
    b65c:      	add	x0, x0, x1
    b660:      	ldrb	w0, [x0]
    b664:      	b	0xb66c <_stogir.stack.validate-inputs+0x234>
    b668:      	movz	x0, #0x0, lsl #48
    b66c:      	uxtb	w0, w0
    b670:      	and	x0, x0, #0x4
    b674:      	uxtb	w0, w0
    b678:      	cmp	x0, #0x0
    b67c:      	cset	w0, eq
    b680:      	uxtb	w16, w0
    b684:      	cmp	w16, wzr
    b688:      	cset	x0, eq
    b68c:      	cmp	x0, #0x0
    b690:      	b.ne	0xba88 <_stogir.stack.validate-inputs+0x650>
    b694:      	lsr	w24, w24, #0
    b698:      	add	x8, sp, #0x40
    b69c:      	mov	x0, x22
    b6a0:      	mov	w1, w24
    b6a4:      	bl	0xb6a4 <_stogir.stack.validate-inputs+0x26c>
		000000000000b6a4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b6a8:      	add	x16, sp, #0x40
    b6ac:      	ldr	w0, [x16]
    b6b0:      	lsr	x16, x0, #0
    b6b4:      	cmp	x16, #0x1
    b6b8:      	b.eq	0xb6d4 <_stogir.stack.validate-inputs+0x29c>
    b6bc:      	b.lo	0xb6c4 <_stogir.stack.validate-inputs+0x28c>
    b6c0:      	b	0xb6d8 <_stogir.stack.validate-inputs+0x2a0>
    b6c4:      	cmp	x16, #0x0
    b6c8:      	b.eq	0xb6d0 <_stogir.stack.validate-inputs+0x298>
    b6cc:      	b	0xb6d8 <_stogir.stack.validate-inputs+0x2a0>
    b6d0:      	b	0xb6dc <_stogir.stack.validate-inputs+0x2a4>
    b6d4:      	b	0xb6fc <_stogir.stack.validate-inputs+0x2c4>
    b6d8:      	b	0xb980 <_stogir.stack.validate-inputs+0x548>
    b6dc:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b6dc:  ARM64_RELOC_PAGE21	l_stogir.458
    b6e0:      	ldr	x16, [x16]
		000000000000b6e0:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    b6e4:      	orr	x0, x16, xzr
    b6e8:      	str	x21, [sp, #0x90]
    b6ec:      	mov	x1, x0
    b6f0:      	mov	x0, #0x1                ; =1
    b6f4:      	mov	x2, #0x18               ; =24
    b6f8:      	b	0xb5f0 <_stogir.stack.validate-inputs+0x1b8>
    b6fc:      	add	x16, sp, #0x40
    b700:      	ldr	x0, [x16, #0x8]
    b704:      	lsr	w1, w0, #0
    b708:      	ubfx	x1, x1, #8, #8
    b70c:      	cmp	x1, #0x1
    b710:      	b.lt	0xba90 <_stogir.stack.validate-inputs+0x658>
    b714:      	cmp	x1, #0xb
    b718:      	b.gt	0xba98 <_stogir.stack.validate-inputs+0x660>
    b71c:      	uxtb	w0, w0
    b720:      	cmp	x0, #0x48
    b724:      	b.eq	0xbaa0 <_stogir.stack.validate-inputs+0x668>
    b728:      	sxtw	x0, w24
    b72c:      	cmp	x1, #0x0
    b730:      	cset	w23, eq
    b734:      	cmp	x1, #0x1
    b738:      	cset	w25, eq
    b73c:      	cmp	x1, #0x2
    b740:      	cset	w26, eq
    b744:      	cmp	x1, #0x7
    b748:      	cset	w27, eq
    b74c:      	cmp	x1, #0x8
    b750:      	cset	w28, eq
    b754:      	cmp	x1, #0x3
    b758:      	cset	w2, eq
    b75c:      	cmp	x1, #0x9
    b760:      	cset	w3, eq
    b764:      	cmp	x1, #0x4
    b768:      	cset	w4, eq
    b76c:      	cmp	x1, #0xa
    b770:      	cset	w5, eq
    b774:      	cmp	x1, #0xd
    b778:      	cset	w6, eq
    b77c:      	cmp	x1, #0x5
    b780:      	cset	w7, eq
    b784:      	cmp	x1, #0xb
    b788:      	cset	w8, eq
    b78c:      	cmp	x1, #0xc
    b790:      	cset	w9, eq
    b794:      	cmp	x1, #0x6
    b798:      	cset	w1, eq
    b79c:      	uxtb	w16, w1
    b7a0:      	cmp	w16, wzr
    b7a4:      	mov	x16, #0x8               ; =8
    b7a8:      	movn	x17, #0x0, lsl #48
    b7ac:      	csel	x1, x16, x17, ne
    b7b0:      	cmp	x0, #0x0
    b7b4:      	b.ge	0xbaa8 <_stogir.stack.validate-inputs+0x670>
    b7b8:      	uxtb	w16, w19
    b7bc:      	cmp	w16, wzr
    b7c0:      	b.eq	0xb8e4 <_stogir.stack.validate-inputs+0x4ac>
    b7c4:      	cmp	x20, #0x10
    b7c8:      	b.le	0xb8e4 <_stogir.stack.validate-inputs+0x4ac>
    b7cc:      	mov	x0, x20
    b7d0:      	b	0xb8e8 <_stogir.stack.validate-inputs+0x4b0>
    b7d4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000b7d4:  ARM64_RELOC_PAGE21	l_stogir.459
    b7d8:      	ldr	x16, [x16]
		000000000000b7d8:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    b7dc:      	orr	x0, x16, xzr
    b7e0:      	mov	x1, x0
    b7e4:      	mov	x0, #0x1                ; =1
    b7e8:      	mov	x2, #0x29               ; =41
    b7ec:      	b	0xb6f8 <_stogir.stack.validate-inputs+0x2c0>
    b7f0:      	brk	#0
    b7f4:      	b	0xb7f0 <_stogir.stack.validate-inputs+0x3b8>
    b7f8:      	mov	x0, #0x1                ; =1
    b7fc:      	lsr	w0, w0, #0
    b800:      	sxtw	x0, w0
    b804:      	and	x0, x0, #0xffffffff
    b808:      	mov	x1, x0
    b80c:      	movz	x0, #0x0, lsl #48
    b810:      	movz	x2, #0x0, lsl #48
    b814:      	b	0xb7ec <_stogir.stack.validate-inputs+0x3b4>
    b818:      	uxtb	w16, w23
    b81c:      	cmp	w16, wzr
    b820:      	b.eq	0xb84c <_stogir.stack.validate-inputs+0x414>
    b824:      	movz	x0, #0x0, lsl #48
    b828:      	b	0xb7fc <_stogir.stack.validate-inputs+0x3c4>
    b82c:      	mov	x0, #0x1                ; =1
    b830:      	lsr	w0, w0, #0
    b834:      	sxtw	x0, w0
    b838:      	and	x0, x0, #0xffffffff
    b83c:      	mov	x1, x0
    b840:      	movz	x0, #0x0, lsl #48
    b844:      	movz	x2, #0x0, lsl #48
    b848:      	b	0xb814 <_stogir.stack.validate-inputs+0x3dc>
    b84c:      	uxtb	w16, w25
    b850:      	cmp	w16, wzr
    b854:      	b.ne	0xb7f8 <_stogir.stack.validate-inputs+0x3c0>
    b858:      	uxtb	w16, w26
    b85c:      	cmp	w16, wzr
    b860:      	b.ne	0xb7f8 <_stogir.stack.validate-inputs+0x3c0>
    b864:      	uxtb	w16, w27
    b868:      	cmp	w16, wzr
    b86c:      	b.ne	0xb7f8 <_stogir.stack.validate-inputs+0x3c0>
    b870:      	uxtb	w16, w28
    b874:      	cmp	w16, wzr
    b878:      	b.ne	0xb7f8 <_stogir.stack.validate-inputs+0x3c0>
    b87c:      	uxtb	w16, w19
    b880:      	cmp	w16, wzr
    b884:      	b.ne	0xba40 <_stogir.stack.validate-inputs+0x608>
    b888:      	uxtb	w16, w20
    b88c:      	cmp	w16, wzr
    b890:      	b.ne	0xba40 <_stogir.stack.validate-inputs+0x608>
    b894:      	uxtb	w16, w22
    b898:      	cmp	w16, wzr
    b89c:      	b.ne	0xba58 <_stogir.stack.validate-inputs+0x620>
    b8a0:      	uxtb	w16, w24
    b8a4:      	cmp	w16, wzr
    b8a8:      	b.ne	0xba58 <_stogir.stack.validate-inputs+0x620>
    b8ac:      	uxtb	w16, w21
    b8b0:      	cmp	w16, wzr
    b8b4:      	b.ne	0xba58 <_stogir.stack.validate-inputs+0x620>
    b8b8:      	uxtb	w16, w0
    b8bc:      	cmp	w16, wzr
    b8c0:      	b.ne	0xba68 <_stogir.stack.validate-inputs+0x630>
    b8c4:      	uxtb	w16, w1
    b8c8:      	cmp	w16, wzr
    b8cc:      	b.ne	0xba68 <_stogir.stack.validate-inputs+0x630>
    b8d0:      	uxtb	w16, w2
    b8d4:      	cmp	w16, wzr
    b8d8:      	b.ne	0xba68 <_stogir.stack.validate-inputs+0x630>
    b8dc:      	ldr	x0, [sp, #0xb0]
    b8e0:      	b	0xba6c <_stogir.stack.validate-inputs+0x634>
    b8e4:      	mov	x0, #0x10               ; =16
    b8e8:      	lsr	w24, w24, #0
    b8ec:      	mov	w19, w2
    b8f0:      	mov	x2, x0
    b8f4:      	mov	x0, x22
    b8f8:      	mov	w20, w3
    b8fc:      	mov	w22, w4
    b900:      	str	w7, [sp, #0x98]
    b904:      	str	w8, [sp, #0xa0]
    b908:      	add	x8, sp, #0x70
    b90c:      	str	w9, [sp, #0xa8]
    b910:      	str	x1, [sp, #0xb0]
    b914:      	mov	w1, w24
    b918:      	mov	w24, w5
    b91c:      	str	x21, [sp, #0x90]
    b920:      	mov	w21, w6
    b924:      	bl	0xb924 <_stogir.stack.validate-inputs+0x4ec>
		000000000000b924:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    b928:      	add	x16, sp, #0x70
    b92c:      	ldr	w0, [x16]
    b930:      	lsr	x16, x0, #0
    b934:      	cmp	x16, #0x1
    b938:      	b.eq	0xb954 <_stogir.stack.validate-inputs+0x51c>
    b93c:      	b.lo	0xb944 <_stogir.stack.validate-inputs+0x50c>
    b940:      	b	0xb958 <_stogir.stack.validate-inputs+0x520>
    b944:      	cmp	x16, #0x0
    b948:      	b.eq	0xb950 <_stogir.stack.validate-inputs+0x518>
    b94c:      	b	0xb958 <_stogir.stack.validate-inputs+0x520>
    b950:      	b	0xb988 <_stogir.stack.validate-inputs+0x550>
    b954:      	b	0xb95c <_stogir.stack.validate-inputs+0x524>
    b958:      	b	0xba50 <_stogir.stack.validate-inputs+0x618>
    b95c:      	add	x16, sp, #0x70
    b960:      	orr	x0, x16, xzr
    b964:      	add	x0, x0, #0x8
    b968:      	add	x16, sp, #0x70
    b96c:      	ldr	x1, [x16, #0x8]
    b970:      	ldr	x0, [x0, #0x8]
    b974:      	mov	x2, x0
    b978:      	mov	x0, #0x1                ; =1
    b97c:      	b	0xb848 <_stogir.stack.validate-inputs+0x410>
    b980:      	brk	#0
    b984:      	b	0xb980 <_stogir.stack.validate-inputs+0x548>
    b988:      	uxtb	w16, w23
    b98c:      	cmp	w16, wzr
    b990:      	b.eq	0xb99c <_stogir.stack.validate-inputs+0x564>
    b994:      	movz	x0, #0x0, lsl #48
    b998:      	b	0xb830 <_stogir.stack.validate-inputs+0x3f8>
    b99c:      	uxtb	w16, w25
    b9a0:      	cmp	w16, wzr
    b9a4:      	b.ne	0xb82c <_stogir.stack.validate-inputs+0x3f4>
    b9a8:      	uxtb	w16, w26
    b9ac:      	cmp	w16, wzr
    b9b0:      	b.ne	0xb82c <_stogir.stack.validate-inputs+0x3f4>
    b9b4:      	uxtb	w16, w27
    b9b8:      	cmp	w16, wzr
    b9bc:      	b.ne	0xb82c <_stogir.stack.validate-inputs+0x3f4>
    b9c0:      	uxtb	w16, w28
    b9c4:      	cmp	w16, wzr
    b9c8:      	b.ne	0xb82c <_stogir.stack.validate-inputs+0x3f4>
    b9cc:      	uxtb	w16, w19
    b9d0:      	cmp	w16, wzr
    b9d4:      	b.ne	0xba48 <_stogir.stack.validate-inputs+0x610>
    b9d8:      	uxtb	w16, w20
    b9dc:      	cmp	w16, wzr
    b9e0:      	b.ne	0xba48 <_stogir.stack.validate-inputs+0x610>
    b9e4:      	uxtb	w16, w22
    b9e8:      	cmp	w16, wzr
    b9ec:      	b.ne	0xba60 <_stogir.stack.validate-inputs+0x628>
    b9f0:      	uxtb	w16, w24
    b9f4:      	cmp	w16, wzr
    b9f8:      	b.ne	0xba60 <_stogir.stack.validate-inputs+0x628>
    b9fc:      	uxtb	w16, w21
    ba00:      	cmp	w16, wzr
    ba04:      	b.ne	0xba60 <_stogir.stack.validate-inputs+0x628>
    ba08:      	ldr	w0, [sp, #0x98]
    ba0c:      	uxtb	w16, w0
    ba10:      	cmp	w16, wzr
    ba14:      	b.ne	0xba70 <_stogir.stack.validate-inputs+0x638>
    ba18:      	ldr	w1, [sp, #0xa0]
    ba1c:      	uxtb	w16, w1
    ba20:      	cmp	w16, wzr
    ba24:      	b.ne	0xba70 <_stogir.stack.validate-inputs+0x638>
    ba28:      	ldr	w2, [sp, #0xa8]
    ba2c:      	uxtb	w16, w2
    ba30:      	cmp	w16, wzr
    ba34:      	b.ne	0xba70 <_stogir.stack.validate-inputs+0x638>
    ba38:      	ldr	x0, [sp, #0xb0]
    ba3c:      	b	0xba74 <_stogir.stack.validate-inputs+0x63c>
    ba40:      	mov	x0, #0x2                ; =2
    ba44:      	b	0xb7fc <_stogir.stack.validate-inputs+0x3c4>
    ba48:      	mov	x0, #0x2                ; =2
    ba4c:      	b	0xb830 <_stogir.stack.validate-inputs+0x3f8>
    ba50:      	brk	#0
    ba54:      	b	0xba50 <_stogir.stack.validate-inputs+0x618>
    ba58:      	mov	x0, #0x4                ; =4
    ba5c:      	b	0xba44 <_stogir.stack.validate-inputs+0x60c>
    ba60:      	mov	x0, #0x4                ; =4
    ba64:      	b	0xba4c <_stogir.stack.validate-inputs+0x614>
    ba68:      	mov	x0, #0x8                ; =8
    ba6c:      	b	0xba5c <_stogir.stack.validate-inputs+0x624>
    ba70:      	mov	x0, #0x8                ; =8
    ba74:      	b	0xba64 <_stogir.stack.validate-inputs+0x62c>
    ba78:      	str	x8, [sp, #0x90]
    ba7c:      	b	0xb494 <_stogir.stack.validate-inputs+0x5c>
    ba80:      	str	x21, [sp, #0x90]
    ba84:      	b	0xb5d8 <_stogir.stack.validate-inputs+0x1a0>
    ba88:      	str	x21, [sp, #0x90]
    ba8c:      	b	0xb5d8 <_stogir.stack.validate-inputs+0x1a0>
    ba90:      	str	x21, [sp, #0x90]
    ba94:      	b	0xb7d4 <_stogir.stack.validate-inputs+0x39c>
    ba98:      	str	x21, [sp, #0x90]
    ba9c:      	b	0xb7d4 <_stogir.stack.validate-inputs+0x39c>
    baa0:      	str	x21, [sp, #0x90]
    baa4:      	b	0xb7d4 <_stogir.stack.validate-inputs+0x39c>
    baa8:      	str	x21, [sp, #0x90]
    baac:      	str	x1, [sp, #0xb0]
    bab0:      	mov	w19, w2
    bab4:      	mov	w20, w3
    bab8:      	mov	w22, w4
    babc:      	mov	w24, w5
    bac0:      	mov	w21, w6
    bac4:      	mov	w0, w7
    bac8:      	mov	w1, w8
    bacc:      	mov	w2, w9
    bad0:      	b	0xb818 <_stogir.stack.validate-inputs+0x3e0>

000000000000bad4 <_stogir.locals.shape>:
    bad4:      	sub	sp, sp, #0x40
    bad8:      	str	x29, [sp]
    badc:      	str	x30, [sp, #0x8]
    bae0:      	mov	x29, sp
    bae4:      	str	x19, [sp, #0x20]
    bae8:      	str	x20, [sp, #0x28]
    baec:      	str	x21, [sp, #0x30]
    baf0:      	str	x22, [sp, #0x38]
    baf4:      	sxtw	x19, w1
    baf8:      	lsl	x20, x19, #2
    bafc:      	cmp	x19, #0x0
    bb00:      	cset	w1, gt
    bb04:      	movz	x16, #0x0, lsl #48
    bb08:      	sub	x3, x16, x19
    bb0c:      	sub	x4, x3, #0x1
    bb10:      	uxtb	w16, w1
    bb14:      	cmp	w16, wzr
    bb18:      	b.eq	0xbb58 <_stogir.locals.shape+0x84>
    bb1c:      	ldr	x3, [x0, #0x8]
    bb20:      	cmp	x19, x3
    bb24:      	b.ge	0xbbc8 <_stogir.locals.shape+0xf4>
    bb28:      	add	x3, x0, #0x78
    bb2c:      	ldr	x3, [x3, #0x8]
    bb30:      	cmp	x19, x3
    bb34:      	b.ge	0xbd94 <_stogir.locals.shape+0x2c0>
    bb38:      	ldr	x3, [x0, #0x78]
    bb3c:      	add	x3, x20, x3
    bb40:      	ldr	w3, [x3]
    bb44:      	sxtw	x3, w3
    bb48:      	cmp	x3, #0x0
    bb4c:      	cset	w3, ge
    bb50:      	ubfx	x3, x3, #0, #8
    bb54:      	b	0xbd98 <_stogir.locals.shape+0x2c4>
    bb58:      	cmp	x19, #0x0
    bb5c:      	b.ge	0xbbd0 <_stogir.locals.shape+0xfc>
    bb60:      	add	x5, x0, #0x28
    bb64:      	add	x6, x0, #0x50
    bb68:      	ldr	x5, [x5, #0x8]
    bb6c:      	ldr	x6, [x6, #0x8]
    bb70:      	cmp	x5, x6
    bb74:      	b.ne	0xbba4 <_stogir.locals.shape+0xd0>
    bb78:      	cmp	x3, x5
    bb7c:      	b.gt	0xbe68 <_stogir.locals.shape+0x394>
    bb80:      	lsl	x3, x4, #2
    bb84:      	ldr	x3, [x0, #0x50]
    bb88:      	add	x3, x3, x4, lsl #2
    bb8c:      	ldr	w3, [x3]
    bb90:      	sxtw	x3, w3
    bb94:      	cmp	x3, #0x0
    bb98:      	cset	w3, gt
    bb9c:      	ubfx	x3, x3, #0, #8
    bba0:      	b	0xbe6c <_stogir.locals.shape+0x398>
    bba4:      	movz	x3, #0x0, lsl #48
    bba8:      	b	0xbbd4 <_stogir.locals.shape+0x100>
    bbac:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000bbac:  ARM64_RELOC_PAGE21	l_stogir.460
    bbb0:      	ldr	x16, [x16]
		000000000000bbb0:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    bbb4:      	orr	x0, x16, xzr
    bbb8:      	mov	x1, x0
    bbbc:      	mov	x0, #0x1                ; =1
    bbc0:      	mov	x2, #0x1c               ; =28
    bbc4:      	b	0xbc94 <_stogir.locals.shape+0x1c0>
    bbc8:      	movz	x3, #0x0, lsl #48
    bbcc:      	b	0xbbd4 <_stogir.locals.shape+0x100>
    bbd0:      	movz	x3, #0x0, lsl #48
    bbd4:      	cmp	x3, #0x0
    bbd8:      	b.eq	0xbc3c <_stogir.locals.shape+0x168>
    bbdc:      	uxtb	w16, w1
    bbe0:      	cmp	w16, wzr
    bbe4:      	b.eq	0xbc0c <_stogir.locals.shape+0x138>
    bbe8:      	lsl	x1, x19, #4
    bbec:      	ldr	x1, [x0]
    bbf0:      	add	x1, x1, x19, lsl #4
    bbf4:      	ldr	x3, [x1]
    bbf8:      	ldr	x1, [x1, #0x8]
    bbfc:      	fmov	d31, x1
    bc00:      	mov	x1, x3
    bc04:      	fmov	x3, d31
    bc08:      	b	0xbc2c <_stogir.locals.shape+0x158>
    bc0c:      	lsl	x1, x4, #4
    bc10:      	ldr	x1, [x0, #0x28]
    bc14:      	add	x1, x1, x4, lsl #4
    bc18:      	ldr	x3, [x1]
    bc1c:      	ldr	x1, [x1, #0x8]
    bc20:      	fmov	d31, x1
    bc24:      	mov	x1, x3
    bc28:      	fmov	x3, d31
    bc2c:      	mov	x4, x3
    bc30:      	mov	x3, x1
    bc34:      	mov	x1, #0x1                ; =1
    bc38:      	b	0xbc48 <_stogir.locals.shape+0x174>
    bc3c:      	movz	x1, #0x0, lsl #48
    bc40:      	movz	x3, #0x0, lsl #48
    bc44:      	movz	x4, #0x0, lsl #48
    bc48:      	lsr	w1, w1, #0
    bc4c:      	lsr	x16, x1, #0
    bc50:      	cmp	x16, #0x1
    bc54:      	b.eq	0xbc70 <_stogir.locals.shape+0x19c>
    bc58:      	b.lo	0xbc60 <_stogir.locals.shape+0x18c>
    bc5c:      	b	0xbc74 <_stogir.locals.shape+0x1a0>
    bc60:      	cmp	x16, #0x0
    bc64:      	b.eq	0xbc6c <_stogir.locals.shape+0x198>
    bc68:      	b	0xbc74 <_stogir.locals.shape+0x1a0>
    bc6c:      	b	0xbc78 <_stogir.locals.shape+0x1a4>
    bc70:      	b	0xbcc0 <_stogir.locals.shape+0x1ec>
    bc74:      	b	0xbebc <_stogir.locals.shape+0x3e8>
    bc78:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000bc78:  ARM64_RELOC_PAGE21	l_stogir.461
    bc7c:      	ldr	x16, [x16]
		000000000000bc7c:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    bc80:      	orr	x0, x16, xzr
    bc84:      	mov	x21, x8
    bc88:      	mov	x1, x0
    bc8c:      	mov	x0, #0x1                ; =1
    bc90:      	mov	x2, #0x16               ; =22
    bc94:      	str	x0, [x21]
    bc98:      	str	x1, [x21, #0x8]
    bc9c:      	str	x2, [x21, #0x10]
    bca0:      	ldr	x19, [sp, #0x20]
    bca4:      	ldr	x20, [sp, #0x28]
    bca8:      	ldr	x21, [sp, #0x30]
    bcac:      	ldr	x22, [sp, #0x38]
    bcb0:      	ldr	x29, [sp]
    bcb4:      	ldr	x30, [sp, #0x8]
    bcb8:      	add	sp, sp, #0x40
    bcbc:      	ret
    bcc0:      	lsr	w2, w2, #0
    bcc4:      	lsr	w1, w3, #0
    bcc8:      	add	x16, sp, #0x10
    bccc:      	str	x3, [x16]
    bcd0:      	add	x16, sp, #0x10
    bcd4:      	str	x4, [x16, #0x8]
    bcd8:      	ubfx	x1, x1, #8, #8
    bcdc:      	lsr	w1, w1, #0
    bce0:      	mov	x21, x8
    bce4:      	mov	x22, x0
    bce8:      	mov	w0, w1
    bcec:      	mov	w1, w2
    bcf0:      	bl	0xbcf0 <_stogir.locals.shape+0x21c>
		000000000000bcf0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    bcf4:      	lsr	w0, w0, #0
    bcf8:      	add	x16, sp, #0x10
    bcfc:      	ldr	w1, [x16, #0xc]
    bd00:      	sxtw	x0, w0
    bd04:      	sxtw	x1, w1
    bd08:      	cmp	x1, #0x0
    bd0c:      	b.ne	0xbd14 <_stogir.locals.shape+0x240>
    bd10:      	mov	x1, x0
    bd14:      	add	x16, sp, #0x10
    bd18:      	ldr	w2, [x16, #0x8]
    bd1c:      	sxtw	x2, w2
    bd20:      	cmp	x2, #0x0
    bd24:      	cset	w3, eq
    bd28:      	ubfx	x3, x3, #0, #8
    bd2c:      	cmp	x2, #0x0
    bd30:      	b.le	0xbd9c <_stogir.locals.shape+0x2c8>
    bd34:      	add	x4, x22, #0x110
    bd38:      	add	x5, x4, #0x28
    bd3c:      	ldr	x5, [x5, #0x8]
    bd40:      	cmp	x2, x5
    bd44:      	b.gt	0xbe80 <_stogir.locals.shape+0x3ac>
    bd48:      	sub	x2, x2, #0x1
    bd4c:      	mov	x17, #0x18              ; =24
    bd50:      	mul	x2, x2, x17
    bd54:      	ldr	x5, [x4, #0x28]
    bd58:      	add	x2, x2, x5
    bd5c:      	ldr	x5, [x2]
    bd60:      	ldr	x2, [x2, #0x8]
    bd64:      	ldr	x4, [x4, #0x8]
    bd68:      	cmp	x5, #0x0
    bd6c:      	b.lt	0xbe78 <_stogir.locals.shape+0x3a4>
    bd70:      	cmp	x5, x4
    bd74:      	b.gt	0xbe78 <_stogir.locals.shape+0x3a4>
    bd78:      	cmp	x2, #0x0
    bd7c:      	b.lt	0xbe78 <_stogir.locals.shape+0x3a4>
    bd80:      	sub	x4, x4, x5
    bd84:      	cmp	x2, x4
    bd88:      	b.gt	0xbe78 <_stogir.locals.shape+0x3a4>
    bd8c:      	mov	x2, #0x1                ; =1
    bd90:      	b	0xbe7c <_stogir.locals.shape+0x3a8>
    bd94:      	movz	x3, #0x0, lsl #48
    bd98:      	b	0xbbcc <_stogir.locals.shape+0xf8>
    bd9c:      	mov	x2, x3
    bda0:      	cmp	x19, #0x0
    bda4:      	b.le	0xbbac <_stogir.locals.shape+0xd8>
    bda8:      	add	x16, sp, #0x10
    bdac:      	ldr	w3, [x16]
    bdb0:      	uxtb	w3, w3
    bdb4:      	cmp	x3, #0x48
    bdb8:      	b.ne	0xbbac <_stogir.locals.shape+0xd8>
    bdbc:      	ldr	x3, [x22, #0x78]
    bdc0:      	add	x3, x20, x3
    bdc4:      	ldr	w3, [x3]
    bdc8:      	sxtw	x3, w3
    bdcc:      	cmp	x3, #0x3
    bdd0:      	b.ne	0xbbac <_stogir.locals.shape+0xd8>
    bdd4:      	cmp	x0, #0x0
    bdd8:      	b.le	0xbbac <_stogir.locals.shape+0xd8>
    bddc:      	cmp	x2, #0x0
    bde0:      	b.eq	0xbbac <_stogir.locals.shape+0xd8>
    bde4:      	cmp	x1, #0x0
    bde8:      	b.le	0xbbac <_stogir.locals.shape+0xd8>
    bdec:      	sub	x2, x1, #0x1
    bdf0:      	and	x2, x2, x1
    bdf4:      	cmp	x2, #0x0
    bdf8:      	b.ne	0xbbac <_stogir.locals.shape+0xd8>
    bdfc:      	add	x16, sp, #0x10
    be00:      	ldr	w2, [x16, #0x4]
    be04:      	sxtw	x2, w2
    be08:      	cmp	x2, #0x0
    be0c:      	cset	w3, gt
    be10:      	movz	x16, #0x0, lsl #48
    be14:      	sub	x4, x16, x2
    be18:      	sub	x5, x4, #0x1
    be1c:      	uxtb	w16, w3
    be20:      	cmp	w16, wzr
    be24:      	b.eq	0xbee8 <_stogir.locals.shape+0x414>
    be28:      	ldr	x4, [x22, #0x8]
    be2c:      	cmp	x2, x4
    be30:      	b.ge	0xbf34 <_stogir.locals.shape+0x460>
    be34:      	add	x4, x22, #0x78
    be38:      	ldr	x4, [x4, #0x8]
    be3c:      	cmp	x2, x4
    be40:      	b.ge	0xc018 <_stogir.locals.shape+0x544>
    be44:      	lsl	x4, x2, #2
    be48:      	ldr	x4, [x22, #0x78]
    be4c:      	add	x4, x4, x2, lsl #2
    be50:      	ldr	w4, [x4]
    be54:      	sxtw	x4, w4
    be58:      	cmp	x4, #0x0
    be5c:      	cset	w4, ge
    be60:      	ubfx	x4, x4, #0, #8
    be64:      	b	0xc01c <_stogir.locals.shape+0x548>
    be68:      	movz	x3, #0x0, lsl #48
    be6c:      	b	0xbba8 <_stogir.locals.shape+0xd4>
    be70:      	mov	x2, #0x1                ; =1
    be74:      	b	0xbda0 <_stogir.locals.shape+0x2cc>
    be78:      	movz	x2, #0x0, lsl #48
    be7c:      	b	0xbe84 <_stogir.locals.shape+0x3b0>
    be80:      	movz	x2, #0x0, lsl #48
    be84:      	lsr	w2, w2, #0
    be88:      	lsr	x16, x2, #0
    be8c:      	cmp	x16, #0x1
    be90:      	b.eq	0xbeac <_stogir.locals.shape+0x3d8>
    be94:      	b.lo	0xbe9c <_stogir.locals.shape+0x3c8>
    be98:      	b	0xbeb0 <_stogir.locals.shape+0x3dc>
    be9c:      	cmp	x16, #0x0
    bea0:      	b.eq	0xbea8 <_stogir.locals.shape+0x3d4>
    bea4:      	b	0xbeb0 <_stogir.locals.shape+0x3dc>
    bea8:      	b	0xbeb4 <_stogir.locals.shape+0x3e0>
    beac:      	b	0xbe70 <_stogir.locals.shape+0x39c>
    beb0:      	b	0xbec4 <_stogir.locals.shape+0x3f0>
    beb4:      	mov	x2, x3
    beb8:      	b	0xbe74 <_stogir.locals.shape+0x3a0>
    bebc:      	brk	#0
    bec0:      	b	0xbebc <_stogir.locals.shape+0x3e8>
    bec4:      	brk	#0
    bec8:      	b	0xbec4 <_stogir.locals.shape+0x3f0>
    becc:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000becc:  ARM64_RELOC_PAGE21	l_stogir.462
    bed0:      	ldr	x16, [x16]
		000000000000bed0:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    bed4:      	orr	x0, x16, xzr
    bed8:      	mov	x1, x0
    bedc:      	mov	x0, #0x1                ; =1
    bee0:      	mov	x2, #0x2c               ; =44
    bee4:      	b	0xbbc4 <_stogir.locals.shape+0xf0>
    bee8:      	cmp	x2, #0x0
    beec:      	b.ge	0xbf3c <_stogir.locals.shape+0x468>
    bef0:      	add	x6, x22, #0x28
    bef4:      	add	x7, x22, #0x50
    bef8:      	ldr	x6, [x6, #0x8]
    befc:      	ldr	x7, [x7, #0x8]
    bf00:      	cmp	x6, x7
    bf04:      	b.ne	0xc010 <_stogir.locals.shape+0x53c>
    bf08:      	cmp	x4, x6
    bf0c:      	b.gt	0xc020 <_stogir.locals.shape+0x54c>
    bf10:      	lsl	x4, x5, #2
    bf14:      	ldr	x4, [x22, #0x50]
    bf18:      	add	x4, x4, x5, lsl #2
    bf1c:      	ldr	w4, [x4]
    bf20:      	sxtw	x4, w4
    bf24:      	cmp	x4, #0x0
    bf28:      	cset	w4, gt
    bf2c:      	ubfx	x4, x4, #0, #8
    bf30:      	b	0xc024 <_stogir.locals.shape+0x550>
    bf34:      	movz	x4, #0x0, lsl #48
    bf38:      	b	0xbf40 <_stogir.locals.shape+0x46c>
    bf3c:      	movz	x4, #0x0, lsl #48
    bf40:      	cmp	x4, #0x0
    bf44:      	b.eq	0xbf84 <_stogir.locals.shape+0x4b0>
    bf48:      	uxtb	w16, w3
    bf4c:      	cmp	w16, wzr
    bf50:      	b.eq	0xbf68 <_stogir.locals.shape+0x494>
    bf54:      	lsl	x3, x2, #4
    bf58:      	ldr	x3, [x22]
    bf5c:      	add	x2, x3, x2, lsl #4
    bf60:      	ldr	x2, [x2]
    bf64:      	b	0xbf78 <_stogir.locals.shape+0x4a4>
    bf68:      	lsl	x2, x5, #4
    bf6c:      	ldr	x2, [x22, #0x28]
    bf70:      	add	x2, x2, x5, lsl #4
    bf74:      	ldr	x2, [x2]
    bf78:      	mov	x3, x2
    bf7c:      	mov	x2, #0x1                ; =1
    bf80:      	b	0xbf8c <_stogir.locals.shape+0x4b8>
    bf84:      	movz	x2, #0x0, lsl #48
    bf88:      	movz	x3, #0x0, lsl #48
    bf8c:      	lsr	w2, w2, #0
    bf90:      	lsr	x16, x2, #0
    bf94:      	cmp	x16, #0x1
    bf98:      	b.eq	0xbfb4 <_stogir.locals.shape+0x4e0>
    bf9c:      	b.lo	0xbfa4 <_stogir.locals.shape+0x4d0>
    bfa0:      	b	0xbfb8 <_stogir.locals.shape+0x4e4>
    bfa4:      	cmp	x16, #0x0
    bfa8:      	b.eq	0xbfb0 <_stogir.locals.shape+0x4dc>
    bfac:      	b	0xbfb8 <_stogir.locals.shape+0x4e4>
    bfb0:      	b	0xbfbc <_stogir.locals.shape+0x4e8>
    bfb4:      	b	0xbfd8 <_stogir.locals.shape+0x504>
    bfb8:      	b	0xc064 <_stogir.locals.shape+0x590>
    bfbc:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000bfbc:  ARM64_RELOC_PAGE21	l_stogir.463
    bfc0:      	ldr	x16, [x16]
		000000000000bfc0:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    bfc4:      	orr	x0, x16, xzr
    bfc8:      	mov	x1, x0
    bfcc:      	mov	x0, #0x1                ; =1
    bfd0:      	mov	x2, #0x1d               ; =29
    bfd4:      	b	0xbee4 <_stogir.locals.shape+0x410>
    bfd8:      	add	x16, sp, #0x10
    bfdc:      	ldr	w2, [x16, #0x4]
    bfe0:      	sxtw	x2, w2
    bfe4:      	cmp	x2, #0x0
    bfe8:      	b.le	0xbecc <_stogir.locals.shape+0x3f8>
    bfec:      	uxtb	w3, w3
    bff0:      	cmp	x3, #0x83
    bff4:      	b.ge	0xc028 <_stogir.locals.shape+0x554>
    bff8:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x40>
		000000000000bff8:  ARM64_RELOC_PAGE21	l_stogir.464
    bffc:      	ldr	x16, [x16]
		000000000000bffc:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    c000:      	orr	x2, x16, xzr
    c004:      	add	x2, x3, x2
    c008:      	ldrb	w2, [x2]
    c00c:      	b	0xc02c <_stogir.locals.shape+0x558>
    c010:      	movz	x4, #0x0, lsl #48
    c014:      	b	0xbf40 <_stogir.locals.shape+0x46c>
    c018:      	movz	x4, #0x0, lsl #48
    c01c:      	b	0xbf38 <_stogir.locals.shape+0x464>
    c020:      	movz	x4, #0x0, lsl #48
    c024:      	b	0xc014 <_stogir.locals.shape+0x540>
    c028:      	movz	x2, #0x0, lsl #48
    c02c:      	uxtb	w2, w2
    c030:      	and	x2, x2, #0x2
    c034:      	uxtb	w2, w2
    c038:      	cmp	x2, #0x0
    c03c:      	cset	w2, eq
    c040:      	uxtb	w16, w2
    c044:      	cmp	w16, wzr
    c048:      	cset	x2, eq
    c04c:      	cmp	x2, #0x0
    c050:      	b.eq	0xbecc <_stogir.locals.shape+0x3f8>
    c054:      	mov	x2, x1
    c058:      	mov	x1, x0
    c05c:      	movz	x0, #0x0, lsl #48
    c060:      	b	0xbee4 <_stogir.locals.shape+0x410>
    c064:      	brk	#0
    c068:      	b	0xc064 <_stogir.locals.shape+0x590>

000000000000c06c <_stogir.conversion.policy>:
    c06c:      	sub	sp, sp, #0x70
    c070:      	str	x29, [sp]
    c074:      	str	x30, [sp, #0x8]
    c078:      	mov	x29, sp
    c07c:      	str	x19, [sp, #0x20]
    c080:      	str	x20, [sp, #0x28]
    c084:      	str	x21, [sp, #0x30]
    c088:      	str	x22, [sp, #0x38]
    c08c:      	str	x23, [sp, #0x40]
    c090:      	str	x24, [sp, #0x48]
    c094:      	str	x25, [sp, #0x50]
    c098:      	str	x26, [sp, #0x58]
    c09c:      	str	x27, [sp, #0x60]
    c0a0:      	str	x28, [sp, #0x68]
    c0a4:      	sxtw	x19, w0
    c0a8:      	sxtw	x20, w1
    c0ac:      	sxtw	x21, w2
    c0b0:      	cmp	x19, #0x24
    c0b4:      	b.ne	0xc104 <_stogir.conversion.policy+0x98>
    c0b8:      	cmp	x20, #0xf
    c0bc:      	b.le	0xc320 <_stogir.conversion.policy+0x2b4>
    c0c0:      	cmp	x20, #0x80
    c0c4:      	b.ge	0xc320 <_stogir.conversion.policy+0x2b4>
    c0c8:      	and	x0, x20, #0xf
    c0cc:      	lsr	w0, w0, #0
    c0d0:      	sxtw	x0, w0
    c0d4:      	cmp	x0, #0x1
    c0d8:      	b.lt	0xc320 <_stogir.conversion.policy+0x2b4>
    c0dc:      	and	x0, x20, #0xf
    c0e0:      	lsr	w0, w0, #0
    c0e4:      	sxtw	x0, w0
    c0e8:      	cmp	x0, #0xd
    c0ec:      	b.gt	0xc320 <_stogir.conversion.policy+0x2b4>
    c0f0:      	mov	x0, #0x1                ; =1
    c0f4:      	b	0xc0fc <_stogir.conversion.policy+0x90>
    c0f8:      	movz	x0, #0x0, lsl #48
    c0fc:      	mov	x22, x0
    c100:      	b	0xc108 <_stogir.conversion.policy+0x9c>
    c104:      	movz	x22, #0x0, lsl #48
    c108:      	sxtw	x23, w3
    c10c:      	cmp	x20, #0xd
    c110:      	cset	w24, eq
    c114:      	cmp	x20, #0xc
    c118:      	cset	w25, eq
    c11c:      	cmp	x23, #0x4
    c120:      	cset	w26, eq
    c124:      	cmp	x23, #0x8
    c128:      	cset	w27, eq
    c12c:      	cmp	x22, #0x0
    c130:      	b.eq	0xc614 <_stogir.conversion.policy+0x5a8>
    c134:      	lsr	w1, w1, #0
    c138:      	lsr	w3, w3, #0
    c13c:      	mov	w0, w1
    c140:      	mov	w1, w3
    c144:      	str	x8, [sp, #0x18]
    c148:      	mov	w28, w3
    c14c:      	str	x23, [sp, #0x10]
    c150:      	mov	w23, w2
    c154:      	bl	0xc154 <_stogir.conversion.policy+0xe8>
		000000000000c154:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c158:      	lsr	w0, w0, #0
    c15c:      	sxtw	x0, w0
    c160:      	b	0xc170 <_stogir.conversion.policy+0x104>
    c164:      	mov	x0, #0x1                ; =1
    c168:      	lsr	w0, w0, #0
    c16c:      	sxtw	x0, w0
    c170:      	cmp	x21, #0xd
    c174:      	cset	w1, eq
    c178:      	cmp	x21, #0xc
    c17c:      	cset	w2, eq
    c180:      	cmp	x22, #0x0
    c184:      	b.eq	0xc628 <_stogir.conversion.policy+0x5bc>
    c188:      	lsr	w23, w23, #0
    c18c:      	lsr	w28, w28, #0
    c190:      	mov	x22, x0
    c194:      	mov	w0, w23
    c198:      	mov	w23, w1
    c19c:      	mov	w1, w28
    c1a0:      	mov	w28, w2
    c1a4:      	bl	0xc1a4 <_stogir.conversion.policy+0x138>
		000000000000c1a4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c1a8:      	lsr	w0, w0, #0
    c1ac:      	sxtw	x0, w0
    c1b0:      	b	0xc1c0 <_stogir.conversion.policy+0x154>
    c1b4:      	mov	x0, #0x1                ; =1
    c1b8:      	lsr	w0, w0, #0
    c1bc:      	sxtw	x0, w0
    c1c0:      	cmp	x19, #0x21
    c1c4:      	b.lt	0xc2a0 <_stogir.conversion.policy+0x234>
    c1c8:      	cmp	x19, #0x27
    c1cc:      	b.gt	0xc2a0 <_stogir.conversion.policy+0x234>
    c1d0:      	lsl	x1, x22, #3
    c1d4:      	lsr	w1, w1, #0
    c1d8:      	sxtw	x1, w1
    c1dc:      	cmp	x1, #0x0
    c1e0:      	b.le	0xc2a0 <_stogir.conversion.policy+0x234>
    c1e4:      	lsl	x0, x0, #3
    c1e8:      	lsr	w0, w0, #0
    c1ec:      	sxtw	x0, w0
    c1f0:      	cmp	x0, #0x0
    c1f4:      	b.le	0xc2a0 <_stogir.conversion.policy+0x234>
    c1f8:      	cmp	x19, #0x26
    c1fc:      	cset	w2, eq
    c200:      	cmp	x20, #0x1
    c204:      	cset	w3, ge
    c208:      	cmp	x20, #0xb
    c20c:      	cset	w4, le
    c210:      	cmp	x21, #0x1
    c214:      	cset	w5, ge
    c218:      	cmp	x21, #0xb
    c21c:      	cset	w6, le
    c220:      	cmp	x19, #0x25
    c224:      	b.lt	0xc4b4 <_stogir.conversion.policy+0x448>
    c228:      	ubfx	x23, x23, #0, #8
    c22c:      	cmp	x19, #0x25
    c230:      	b.ne	0xc524 <_stogir.conversion.policy+0x4b8>
    c234:      	uxtb	w16, w3
    c238:      	cmp	w16, wzr
    c23c:      	b.eq	0xc51c <_stogir.conversion.policy+0x4b0>
    c240:      	uxtb	w16, w4
    c244:      	cmp	w16, wzr
    c248:      	b.eq	0xc51c <_stogir.conversion.policy+0x4b0>
    c24c:      	uxtb	w16, w28
    c250:      	cmp	w16, wzr
    c254:      	b.eq	0xc598 <_stogir.conversion.policy+0x52c>
    c258:      	mov	x3, #0x1                ; =1
    c25c:      	b	0xc59c <_stogir.conversion.policy+0x530>
    c260:      	uxtb	w16, w26
    c264:      	cmp	w16, wzr
    c268:      	b.ne	0xc300 <_stogir.conversion.policy+0x294>
    c26c:      	uxtb	w16, w27
    c270:      	cmp	w16, wzr
    c274:      	b.ne	0xc300 <_stogir.conversion.policy+0x294>
    c278:      	movn	x0, #0x0, lsl #48
    c27c:      	b	0xc1b8 <_stogir.conversion.policy+0x14c>
    c280:      	uxtb	w16, w26
    c284:      	cmp	w16, wzr
    c288:      	b.ne	0xc310 <_stogir.conversion.policy+0x2a4>
    c28c:      	uxtb	w16, w27
    c290:      	cmp	w16, wzr
    c294:      	b.ne	0xc310 <_stogir.conversion.policy+0x2a4>
    c298:      	movn	x0, #0x0, lsl #48
    c29c:      	b	0xc168 <_stogir.conversion.policy+0xfc>
    c2a0:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000c2a0:  ARM64_RELOC_PAGE21	l_stogir.465
    c2a4:      	ldr	x16, [x16]
		000000000000c2a4:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    c2a8:      	orr	x0, x16, xzr
    c2ac:      	mov	x1, x0
    c2b0:      	mov	x0, #0x1                ; =1
    c2b4:      	mov	x2, #0x22               ; =34
    c2b8:      	ldr	x3, [sp, #0x18]
    c2bc:      	str	x0, [x3]
    c2c0:      	str	x1, [x3, #0x8]
    c2c4:      	str	x2, [x3, #0x10]
    c2c8:      	ldr	x19, [sp, #0x20]
    c2cc:      	ldr	x20, [sp, #0x28]
    c2d0:      	ldr	x21, [sp, #0x30]
    c2d4:      	ldr	x22, [sp, #0x38]
    c2d8:      	ldr	x23, [sp, #0x40]
    c2dc:      	ldr	x24, [sp, #0x48]
    c2e0:      	ldr	x25, [sp, #0x50]
    c2e4:      	ldr	x26, [sp, #0x58]
    c2e8:      	ldr	x27, [sp, #0x60]
    c2ec:      	ldr	x28, [sp, #0x68]
    c2f0:      	ldr	x29, [sp]
    c2f4:      	ldr	x30, [sp, #0x8]
    c2f8:      	add	sp, sp, #0x70
    c2fc:      	ret
    c300:      	cmp	x21, #0x0
    c304:      	b.ne	0xc368 <_stogir.conversion.policy+0x2fc>
    c308:      	movz	x0, #0x0, lsl #48
    c30c:      	b	0xc1b8 <_stogir.conversion.policy+0x14c>
    c310:      	cmp	x20, #0x0
    c314:      	b.ne	0xc3e0 <_stogir.conversion.policy+0x374>
    c318:      	movz	x0, #0x0, lsl #48
    c31c:      	b	0xc168 <_stogir.conversion.policy+0xfc>
    c320:      	cmp	x21, #0xf
    c324:      	b.le	0xc0f8 <_stogir.conversion.policy+0x8c>
    c328:      	cmp	x21, #0x80
    c32c:      	b.ge	0xc360 <_stogir.conversion.policy+0x2f4>
    c330:      	and	x0, x21, #0xf
    c334:      	lsr	w0, w0, #0
    c338:      	sxtw	x0, w0
    c33c:      	cmp	x0, #0x1
    c340:      	b.lt	0xc458 <_stogir.conversion.policy+0x3ec>
    c344:      	and	x0, x21, #0xf
    c348:      	lsr	w0, w0, #0
    c34c:      	sxtw	x0, w0
    c350:      	cmp	x0, #0xd
    c354:      	cset	w0, le
    c358:      	ubfx	x0, x0, #0, #8
    c35c:      	b	0xc45c <_stogir.conversion.policy+0x3f0>
    c360:      	movz	x0, #0x0, lsl #48
    c364:      	b	0xc0fc <_stogir.conversion.policy+0x90>
    c368:      	cmp	x21, #0x1
    c36c:      	b.eq	0xc1b4 <_stogir.conversion.policy+0x148>
    c370:      	cmp	x21, #0x2
    c374:      	b.eq	0xc1b4 <_stogir.conversion.policy+0x148>
    c378:      	cmp	x21, #0x7
    c37c:      	b.eq	0xc1b4 <_stogir.conversion.policy+0x148>
    c380:      	cmp	x21, #0x8
    c384:      	b.eq	0xc1b4 <_stogir.conversion.policy+0x148>
    c388:      	cmp	x21, #0x3
    c38c:      	b.eq	0xc550 <_stogir.conversion.policy+0x4e4>
    c390:      	cmp	x21, #0x9
    c394:      	b.eq	0xc550 <_stogir.conversion.policy+0x4e4>
    c398:      	cmp	x21, #0x4
    c39c:      	b.eq	0xc5c0 <_stogir.conversion.policy+0x554>
    c3a0:      	cmp	x21, #0xa
    c3a4:      	b.eq	0xc5c0 <_stogir.conversion.policy+0x554>
    c3a8:      	uxtb	w16, w23
    c3ac:      	cmp	w16, wzr
    c3b0:      	b.ne	0xc5c0 <_stogir.conversion.policy+0x554>
    c3b4:      	cmp	x21, #0x5
    c3b8:      	b.eq	0xc5f4 <_stogir.conversion.policy+0x588>
    c3bc:      	cmp	x21, #0xb
    c3c0:      	b.eq	0xc5f4 <_stogir.conversion.policy+0x588>
    c3c4:      	uxtb	w16, w28
    c3c8:      	cmp	w16, wzr
    c3cc:      	b.ne	0xc5f4 <_stogir.conversion.policy+0x588>
    c3d0:      	cmp	x21, #0x6
    c3d4:      	b.ne	0xc604 <_stogir.conversion.policy+0x598>
    c3d8:      	ldr	x0, [sp, #0x10]
    c3dc:      	b	0xc608 <_stogir.conversion.policy+0x59c>
    c3e0:      	cmp	x20, #0x1
    c3e4:      	b.eq	0xc164 <_stogir.conversion.policy+0xf8>
    c3e8:      	cmp	x20, #0x2
    c3ec:      	b.eq	0xc164 <_stogir.conversion.policy+0xf8>
    c3f0:      	cmp	x20, #0x7
    c3f4:      	b.eq	0xc164 <_stogir.conversion.policy+0xf8>
    c3f8:      	cmp	x20, #0x8
    c3fc:      	b.eq	0xc164 <_stogir.conversion.policy+0xf8>
    c400:      	cmp	x20, #0x3
    c404:      	b.eq	0xc558 <_stogir.conversion.policy+0x4ec>
    c408:      	cmp	x20, #0x9
    c40c:      	b.eq	0xc558 <_stogir.conversion.policy+0x4ec>
    c410:      	cmp	x20, #0x4
    c414:      	b.eq	0xc5c8 <_stogir.conversion.policy+0x55c>
    c418:      	cmp	x20, #0xa
    c41c:      	b.eq	0xc5c8 <_stogir.conversion.policy+0x55c>
    c420:      	uxtb	w16, w24
    c424:      	cmp	w16, wzr
    c428:      	b.ne	0xc5c8 <_stogir.conversion.policy+0x55c>
    c42c:      	cmp	x20, #0x5
    c430:      	b.eq	0xc5fc <_stogir.conversion.policy+0x590>
    c434:      	cmp	x20, #0xb
    c438:      	b.eq	0xc5fc <_stogir.conversion.policy+0x590>
    c43c:      	uxtb	w16, w25
    c440:      	cmp	w16, wzr
    c444:      	b.ne	0xc5fc <_stogir.conversion.policy+0x590>
    c448:      	cmp	x20, #0x6
    c44c:      	b.ne	0xc60c <_stogir.conversion.policy+0x5a0>
    c450:      	ldr	x0, [sp, #0x10]
    c454:      	b	0xc610 <_stogir.conversion.policy+0x5a4>
    c458:      	movz	x0, #0x0, lsl #48
    c45c:      	b	0xc364 <_stogir.conversion.policy+0x2f8>
    c460:      	mov	x3, #0x1                ; =1
    c464:      	cmp	x3, #0x0
    c468:      	b.ne	0xc2a0 <_stogir.conversion.policy+0x234>
    c46c:      	cmp	x19, #0x23
    c470:      	b.eq	0xc484 <_stogir.conversion.policy+0x418>
    c474:      	uxtb	w16, w2
    c478:      	cmp	w16, wzr
    c47c:      	b.ne	0xc484 <_stogir.conversion.policy+0x418>
    c480:      	mov	x0, x1
    c484:      	and	x0, x0, #0xffffffff
    c488:      	mov	x1, x0
    c48c:      	movz	x0, #0x0, lsl #48
    c490:      	movz	x2, #0x0, lsl #48
    c494:      	b	0xc2b8 <_stogir.conversion.policy+0x24c>
    c498:      	movz	x3, #0x0, lsl #48
    c49c:      	cmp	x3, #0x0
    c4a0:      	cset	w3, ne
    c4a4:      	uxtb	w16, w3
    c4a8:      	cmp	w16, wzr
    c4ac:      	cset	x3, eq
    c4b0:      	b	0xc464 <_stogir.conversion.policy+0x3f8>
    c4b4:      	cmp	x19, #0x24
    c4b8:      	b.ne	0xc4d4 <_stogir.conversion.policy+0x468>
    c4bc:      	cmp	x1, x0
    c4c0:      	cset	w3, eq
    c4c4:      	uxtb	w16, w3
    c4c8:      	cmp	w16, wzr
    c4cc:      	cset	x3, eq
    c4d0:      	b	0xc464 <_stogir.conversion.policy+0x3f8>
    c4d4:      	uxtb	w16, w3
    c4d8:      	cmp	w16, wzr
    c4dc:      	b.eq	0xc460 <_stogir.conversion.policy+0x3f4>
    c4e0:      	uxtb	w16, w4
    c4e4:      	cmp	w16, wzr
    c4e8:      	b.eq	0xc460 <_stogir.conversion.policy+0x3f4>
    c4ec:      	uxtb	w16, w5
    c4f0:      	cmp	w16, wzr
    c4f4:      	b.eq	0xc590 <_stogir.conversion.policy+0x524>
    c4f8:      	uxtb	w16, w6
    c4fc:      	cmp	w16, wzr
    c500:      	b.eq	0xc590 <_stogir.conversion.policy+0x524>
    c504:      	cmp	x19, #0x23
    c508:      	b.ne	0xc5e4 <_stogir.conversion.policy+0x578>
    c50c:      	cmp	x0, x1
    c510:      	cset	w3, ge
    c514:      	ubfx	x3, x3, #0, #8
    c518:      	b	0xc5f0 <_stogir.conversion.policy+0x584>
    c51c:      	movz	x3, #0x0, lsl #48
    c520:      	b	0xc49c <_stogir.conversion.policy+0x430>
    c524:      	uxtb	w16, w2
    c528:      	cmp	w16, wzr
    c52c:      	b.eq	0xc568 <_stogir.conversion.policy+0x4fc>
    c530:      	uxtb	w16, w25
    c534:      	cmp	w16, wzr
    c538:      	b.ne	0xc5a8 <_stogir.conversion.policy+0x53c>
    c53c:      	uxtb	w16, w24
    c540:      	cmp	w16, wzr
    c544:      	b.ne	0xc5a8 <_stogir.conversion.policy+0x53c>
    c548:      	movz	x3, #0x0, lsl #48
    c54c:      	b	0xc564 <_stogir.conversion.policy+0x4f8>
    c550:      	mov	x0, #0x2                ; =2
    c554:      	b	0xc1b8 <_stogir.conversion.policy+0x14c>
    c558:      	mov	x0, #0x2                ; =2
    c55c:      	b	0xc168 <_stogir.conversion.policy+0xfc>
    c560:      	movz	x3, #0x0, lsl #48
    c564:      	b	0xc49c <_stogir.conversion.policy+0x430>
    c568:      	cmp	x19, #0x27
    c56c:      	b.ne	0xc498 <_stogir.conversion.policy+0x42c>
    c570:      	uxtb	w16, w25
    c574:      	cmp	w16, wzr
    c578:      	b.ne	0xc5d0 <_stogir.conversion.policy+0x564>
    c57c:      	uxtb	w16, w24
    c580:      	cmp	w16, wzr
    c584:      	b.ne	0xc5d0 <_stogir.conversion.policy+0x564>
    c588:      	movz	x3, #0x0, lsl #48
    c58c:      	b	0xc5a4 <_stogir.conversion.policy+0x538>
    c590:      	mov	x3, #0x1                ; =1
    c594:      	b	0xc464 <_stogir.conversion.policy+0x3f8>
    c598:      	mov	x3, x23
    c59c:      	b	0xc520 <_stogir.conversion.policy+0x4b4>
    c5a0:      	mov	x3, x23
    c5a4:      	b	0xc49c <_stogir.conversion.policy+0x430>
    c5a8:      	uxtb	w16, w5
    c5ac:      	cmp	w16, wzr
    c5b0:      	b.eq	0xc560 <_stogir.conversion.policy+0x4f4>
    c5b4:      	ubfx	x6, x6, #0, #8
    c5b8:      	mov	x3, x6
    c5bc:      	b	0xc564 <_stogir.conversion.policy+0x4f8>
    c5c0:      	mov	x0, #0x4                ; =4
    c5c4:      	b	0xc554 <_stogir.conversion.policy+0x4e8>
    c5c8:      	mov	x0, #0x4                ; =4
    c5cc:      	b	0xc55c <_stogir.conversion.policy+0x4f0>
    c5d0:      	uxtb	w16, w28
    c5d4:      	cmp	w16, wzr
    c5d8:      	b.eq	0xc5a0 <_stogir.conversion.policy+0x534>
    c5dc:      	mov	x3, #0x1                ; =1
    c5e0:      	b	0xc5a4 <_stogir.conversion.policy+0x538>
    c5e4:      	cmp	x0, x1
    c5e8:      	cset	w3, le
    c5ec:      	ubfx	x3, x3, #0, #8
    c5f0:      	b	0xc594 <_stogir.conversion.policy+0x528>
    c5f4:      	mov	x0, #0x8                ; =8
    c5f8:      	b	0xc5c4 <_stogir.conversion.policy+0x558>
    c5fc:      	mov	x0, #0x8                ; =8
    c600:      	b	0xc5cc <_stogir.conversion.policy+0x560>
    c604:      	movn	x0, #0x0, lsl #48
    c608:      	b	0xc5f8 <_stogir.conversion.policy+0x58c>
    c60c:      	movn	x0, #0x0, lsl #48
    c610:      	b	0xc600 <_stogir.conversion.policy+0x594>
    c614:      	str	x8, [sp, #0x18]
    c618:      	mov	w28, w3
    c61c:      	str	x23, [sp, #0x10]
    c620:      	mov	w23, w2
    c624:      	b	0xc280 <_stogir.conversion.policy+0x214>
    c628:      	mov	x22, x0
    c62c:      	mov	w23, w1
    c630:      	mov	w28, w2
    c634:      	b	0xc260 <_stogir.conversion.policy+0x1f4>

000000000000c638 <_stogir.conditional.operands>:
    c638:      	sub	sp, sp, #0x60
    c63c:      	str	x29, [sp]
    c640:      	str	x30, [sp, #0x8]
    c644:      	mov	x29, sp
    c648:      	str	x19, [sp, #0x30]
    c64c:      	str	x20, [sp, #0x38]
    c650:      	str	x21, [sp, #0x40]
    c654:      	str	x22, [sp, #0x48]
    c658:      	str	x23, [sp, #0x50]
    c65c:      	str	x24, [sp, #0x58]
    c660:      	sxtw	x19, w1
    c664:      	cmp	x19, #0x0
    c668:      	b.ne	0xc740 <_stogir.conditional.operands+0x108>
    c66c:      	mov	x20, x8
    c670:      	mov	x21, x0
    c674:      	mov	w22, w2
    c678:      	mov	w23, w3
    c67c:      	mov	w24, w4
    c680:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000c680:  ARM64_RELOC_PAGE21	l_stogir.466
    c684:      	ldr	x16, [x16]
		000000000000c684:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    c688:      	orr	x0, x16, xzr
    c68c:      	mov	x1, #0x2b               ; =43
    c690:      	sxtw	x22, w22
    c694:      	cmp	x22, #0x0
    c698:      	cset	w2, gt
    c69c:      	movz	x16, #0x0, lsl #48
    c6a0:      	sub	x3, x16, x22
    c6a4:      	sub	x4, x3, #0x1
    c6a8:      	uxtb	w16, w2
    c6ac:      	cmp	w16, wzr
    c6b0:      	b.eq	0xc6f4 <_stogir.conditional.operands+0xbc>
    c6b4:      	ldr	x3, [x21, #0x8]
    c6b8:      	cmp	x22, x3
    c6bc:      	b.ge	0xc78c <_stogir.conditional.operands+0x154>
    c6c0:      	add	x3, x21, #0x78
    c6c4:      	ldr	x3, [x3, #0x8]
    c6c8:      	cmp	x22, x3
    c6cc:      	b.ge	0xcb34 <_stogir.conditional.operands+0x4fc>
    c6d0:      	lsl	x3, x22, #2
    c6d4:      	ldr	x3, [x21, #0x78]
    c6d8:      	add	x3, x3, x22, lsl #2
    c6dc:      	ldr	w3, [x3]
    c6e0:      	sxtw	x3, w3
    c6e4:      	cmp	x3, #0x0
    c6e8:      	cset	w3, ge
    c6ec:      	ubfx	x3, x3, #0, #8
    c6f0:      	b	0xcb38 <_stogir.conditional.operands+0x500>
    c6f4:      	cmp	x22, #0x0
    c6f8:      	b.ge	0xc794 <_stogir.conditional.operands+0x15c>
    c6fc:      	add	x5, x21, #0x28
    c700:      	add	x6, x21, #0x50
    c704:      	ldr	x5, [x5, #0x8]
    c708:      	ldr	x6, [x6, #0x8]
    c70c:      	cmp	x5, x6
    c710:      	b.ne	0xc77c <_stogir.conditional.operands+0x144>
    c714:      	cmp	x3, x5
    c718:      	b.gt	0xcb3c <_stogir.conditional.operands+0x504>
    c71c:      	lsl	x3, x4, #2
    c720:      	ldr	x3, [x21, #0x50]
    c724:      	add	x3, x3, x4, lsl #2
    c728:      	ldr	w3, [x3]
    c72c:      	sxtw	x3, w3
    c730:      	cmp	x3, #0x0
    c734:      	cset	w3, gt
    c738:      	ubfx	x3, x3, #0, #8
    c73c:      	b	0xcb40 <_stogir.conditional.operands+0x508>
    c740:      	lsr	w1, w1, #0
    c744:      	mov	x20, x8
    c748:      	mov	x21, x0
    c74c:      	mov	w0, w1
    c750:      	mov	w22, w2
    c754:      	mov	w23, w3
    c758:      	mov	w24, w4
    c75c:      	bl	0xc75c <_stogir.conditional.operands+0x124>
		000000000000c75c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    c760:      	cmp	x0, #0x0
    c764:      	b.eq	0xc680 <_stogir.conditional.operands+0x48>
    c768:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000c768:  ARM64_RELOC_PAGE21	l_stogir.467
    c76c:      	ldr	x16, [x16]
		000000000000c76c:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    c770:      	orr	x0, x16, xzr
    c774:      	movz	x1, #0x0, lsl #48
    c778:      	b	0xc690 <_stogir.conditional.operands+0x58>
    c77c:      	movz	x3, #0x0, lsl #48
    c780:      	b	0xc798 <_stogir.conditional.operands+0x160>
    c784:      	movz	x11, #0x0, lsl #48
    c788:      	b	0xc840 <_stogir.conditional.operands+0x208>
    c78c:      	movz	x3, #0x0, lsl #48
    c790:      	b	0xc798 <_stogir.conditional.operands+0x160>
    c794:      	movz	x3, #0x0, lsl #48
    c798:      	cmp	x3, #0x0
    c79c:      	b.eq	0xc7dc <_stogir.conditional.operands+0x1a4>
    c7a0:      	uxtb	w16, w2
    c7a4:      	cmp	w16, wzr
    c7a8:      	b.eq	0xc7c0 <_stogir.conditional.operands+0x188>
    c7ac:      	lsl	x2, x22, #4
    c7b0:      	ldr	x2, [x21]
    c7b4:      	add	x2, x2, x22, lsl #4
    c7b8:      	ldr	x2, [x2]
    c7bc:      	b	0xc7d0 <_stogir.conditional.operands+0x198>
    c7c0:      	lsl	x2, x4, #4
    c7c4:      	ldr	x2, [x21, #0x28]
    c7c8:      	add	x2, x2, x4, lsl #4
    c7cc:      	ldr	x2, [x2]
    c7d0:      	mov	x3, x2
    c7d4:      	mov	x2, #0x1                ; =1
    c7d8:      	b	0xc7e4 <_stogir.conditional.operands+0x1ac>
    c7dc:      	movz	x2, #0x0, lsl #48
    c7e0:      	movz	x3, #0x0, lsl #48
    c7e4:      	lsr	w2, w2, #0
    c7e8:      	lsr	x16, x2, #0
    c7ec:      	cmp	x16, #0x1
    c7f0:      	b.eq	0xc80c <_stogir.conditional.operands+0x1d4>
    c7f4:      	b.lo	0xc7fc <_stogir.conditional.operands+0x1c4>
    c7f8:      	b	0xc810 <_stogir.conditional.operands+0x1d8>
    c7fc:      	cmp	x16, #0x0
    c800:      	b.eq	0xc808 <_stogir.conditional.operands+0x1d0>
    c804:      	b	0xc810 <_stogir.conditional.operands+0x1d8>
    c808:      	b	0xc814 <_stogir.conditional.operands+0x1dc>
    c80c:      	b	0xc844 <_stogir.conditional.operands+0x20c>
    c810:      	b	0xcb54 <_stogir.conditional.operands+0x51c>
    c814:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000c814:  ARM64_RELOC_PAGE21	l_stogir.468
    c818:      	ldr	x16, [x16]
		000000000000c818:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    c81c:      	orr	x0, x16, xzr
    c820:      	mov	x1, #0x16               ; =22
    c824:      	b	0xc888 <_stogir.conditional.operands+0x250>
    c828:      	movz	x11, #0x0, lsl #48
    c82c:      	fmov	d31, x10
    c830:      	mov	x10, x11
    c834:      	fmov	x11, d31
    c838:      	b	0xc8ec <_stogir.conditional.operands+0x2b4>
    c83c:      	movz	x11, #0x0, lsl #48
    c840:      	b	0xc8f4 <_stogir.conditional.operands+0x2bc>
    c844:      	uxtb	w2, w3
    c848:      	cmp	x2, #0x48
    c84c:      	b.eq	0xc878 <_stogir.conditional.operands+0x240>
    c850:      	cmp	x2, #0x46
    c854:      	b.eq	0xc878 <_stogir.conditional.operands+0x240>
    c858:      	lsr	w3, w3, #0
    c85c:      	orr	x2, x3, xzr
    c860:      	ubfx	x2, x2, #8, #8
    c864:      	cmp	x2, #0x0
    c868:      	b.eq	0xc878 <_stogir.conditional.operands+0x240>
    c86c:      	ubfx	x2, x3, #8, #8
    c870:      	cmp	x2, #0xd
    c874:      	b.le	0xc888 <_stogir.conditional.operands+0x250>
    c878:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000c878:  ARM64_RELOC_PAGE21	l_stogir.469
    c87c:      	ldr	x16, [x16]
		000000000000c87c:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    c880:      	orr	x0, x16, xzr
    c884:      	mov	x1, #0x2a               ; =42
    c888:      	add	x16, sp, #0x20
    c88c:      	orr	x2, x16, xzr
    c890:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000c890:  ARM64_RELOC_PAGE21	l_stogir.470
    c894:      	ldr	x16, [x16]
		000000000000c894:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    c898:      	orr	x3, x16, xzr
    c89c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000c89c:  ARM64_RELOC_PAGE21	l_stogir.471
    c8a0:      	ldr	x16, [x16]
		000000000000c8a0:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    c8a4:      	orr	x4, x16, xzr
    c8a8:      	lsr	w23, w23, #0
    c8ac:      	lsr	w24, w24, #0
    c8b0:      	add	x5, x21, #0x78
    c8b4:      	add	x6, x21, #0x28
    c8b8:      	add	x7, x21, #0x50
    c8bc:      	add	x16, sp, #0x10
    c8c0:      	str	w23, [x16]
    c8c4:      	add	x16, sp, #0x10
    c8c8:      	str	w24, [x16, #0x4]
    c8cc:      	add	x16, sp, #0x10
    c8d0:      	ldr	x8, [x16]
    c8d4:      	add	x16, sp, #0x20
    c8d8:      	str	x8, [x16]
    c8dc:      	movz	x8, #0x0, lsl #48
    c8e0:      	b	0xc9c4 <_stogir.conditional.operands+0x38c>
    c8e4:      	mov	x11, x10
    c8e8:      	movz	x10, #0x0, lsl #48
    c8ec:      	b	0xc900 <_stogir.conditional.operands+0x2c8>
    c8f0:      	movz	x11, #0x0, lsl #48
    c8f4:      	fmov	d31, x10
    c8f8:      	mov	x10, x11
    c8fc:      	fmov	x11, d31
    c900:      	cmp	x10, #0x0
    c904:      	b.eq	0xc948 <_stogir.conditional.operands+0x310>
    c908:      	uxtb	w16, w8
    c90c:      	cmp	w16, wzr
    c910:      	b.eq	0xc928 <_stogir.conditional.operands+0x2f0>
    c914:      	lsl	x8, x9, #4
    c918:      	ldr	x8, [x21]
    c91c:      	add	x8, x8, x9, lsl #4
    c920:      	ldr	x8, [x8]
    c924:      	b	0xc938 <_stogir.conditional.operands+0x300>
    c928:      	lsl	x8, x12, #4
    c92c:      	ldr	x8, [x21, #0x28]
    c930:      	add	x8, x8, x12, lsl #4
    c934:      	ldr	x8, [x8]
    c938:      	mov	x9, x8
    c93c:      	mov	x10, x11
    c940:      	mov	x8, #0x1                ; =1
    c944:      	b	0xc954 <_stogir.conditional.operands+0x31c>
    c948:      	mov	x10, x11
    c94c:      	movz	x8, #0x0, lsl #48
    c950:      	movz	x9, #0x0, lsl #48
    c954:      	lsr	w8, w8, #0
    c958:      	lsr	x16, x8, #0
    c95c:      	cmp	x16, #0x1
    c960:      	b.eq	0xc97c <_stogir.conditional.operands+0x344>
    c964:      	b.lo	0xc96c <_stogir.conditional.operands+0x334>
    c968:      	b	0xc980 <_stogir.conditional.operands+0x348>
    c96c:      	cmp	x16, #0x0
    c970:      	b.eq	0xc978 <_stogir.conditional.operands+0x340>
    c974:      	b	0xc980 <_stogir.conditional.operands+0x348>
    c978:      	b	0xc984 <_stogir.conditional.operands+0x34c>
    c97c:      	b	0xc994 <_stogir.conditional.operands+0x35c>
    c980:      	b	0xcb4c <_stogir.conditional.operands+0x514>
    c984:      	mov	x0, x3
    c988:      	mov	x8, x10
    c98c:      	mov	x1, #0x10               ; =16
    c990:      	b	0xc9c4 <_stogir.conditional.operands+0x38c>
    c994:      	uxtb	w8, w9
    c998:      	cmp	x8, #0x48
    c99c:      	b.eq	0xc9b8 <_stogir.conditional.operands+0x380>
    c9a0:      	cmp	x8, #0x46
    c9a4:      	b.eq	0xc9b8 <_stogir.conditional.operands+0x380>
    c9a8:      	lsr	w9, w9, #0
    c9ac:      	ubfx	x8, x9, #8, #8
    c9b0:      	cmp	x8, x19
    c9b4:      	b.eq	0xc9c0 <_stogir.conditional.operands+0x388>
    c9b8:      	mov	x0, x4
    c9bc:      	mov	x1, #0x21               ; =33
    c9c0:      	mov	x8, x10
    c9c4:      	cmp	x8, #0x2
    c9c8:      	b.ge	0xc9f4 <_stogir.conditional.operands+0x3bc>
    c9cc:      	add	x9, x8, #0x1
    c9d0:      	lsl	x10, x8, #2
    c9d4:      	add	x8, x2, x8, lsl #2
    c9d8:      	ldr	w8, [x8]
    c9dc:      	sxtw	x8, w8
    c9e0:      	and	x8, x8, #0xffffffff
    c9e4:      	mov	x10, x9
    c9e8:      	mov	x9, x8
    c9ec:      	mov	x8, #0x1                ; =1
    c9f0:      	b	0xca00 <_stogir.conditional.operands+0x3c8>
    c9f4:      	mov	x10, x8
    c9f8:      	movz	x8, #0x0, lsl #48
    c9fc:      	movz	x9, #0x0, lsl #48
    ca00:      	lsr	w8, w8, #0
    ca04:      	lsr	x16, x8, #0
    ca08:      	cmp	x16, #0x1
    ca0c:      	b.eq	0xca28 <_stogir.conditional.operands+0x3f0>
    ca10:      	b.lo	0xca18 <_stogir.conditional.operands+0x3e0>
    ca14:      	b	0xca2c <_stogir.conditional.operands+0x3f4>
    ca18:      	cmp	x16, #0x0
    ca1c:      	b.eq	0xca24 <_stogir.conditional.operands+0x3ec>
    ca20:      	b	0xca2c <_stogir.conditional.operands+0x3f4>
    ca24:      	b	0xca94 <_stogir.conditional.operands+0x45c>
    ca28:      	b	0xca30 <_stogir.conditional.operands+0x3f8>
    ca2c:      	b	0xcb44 <_stogir.conditional.operands+0x50c>
    ca30:      	lsr	w9, w9, #0
    ca34:      	sxtw	x9, w9
    ca38:      	cmp	x9, #0x0
    ca3c:      	cset	w8, gt
    ca40:      	movz	x16, #0x0, lsl #48
    ca44:      	sub	x11, x16, x9
    ca48:      	sub	x12, x11, #0x1
    ca4c:      	uxtb	w16, w8
    ca50:      	cmp	w16, wzr
    ca54:      	b.eq	0xcaf0 <_stogir.conditional.operands+0x4b8>
    ca58:      	ldr	x11, [x21, #0x8]
    ca5c:      	cmp	x9, x11
    ca60:      	b.ge	0xc8e4 <_stogir.conditional.operands+0x2ac>
    ca64:      	ldr	x11, [x5, #0x8]
    ca68:      	cmp	x9, x11
    ca6c:      	b.ge	0xc828 <_stogir.conditional.operands+0x1f0>
    ca70:      	lsl	x11, x9, #2
    ca74:      	ldr	x11, [x21, #0x78]
    ca78:      	add	x11, x11, x9, lsl #2
    ca7c:      	ldr	w11, [x11]
    ca80:      	sxtw	x11, w11
    ca84:      	cmp	x11, #0x0
    ca88:      	cset	w11, ge
    ca8c:      	ubfx	x11, x11, #0, #8
    ca90:      	b	0xc82c <_stogir.conditional.operands+0x1f4>
    ca94:      	cmp	x1, #0x0
    ca98:      	b.ne	0xcab0 <_stogir.conditional.operands+0x478>
    ca9c:      	and	x0, x19, #0xffffffff
    caa0:      	mov	x1, x0
    caa4:      	movz	x0, #0x0, lsl #48
    caa8:      	movz	x2, #0x0, lsl #48
    caac:      	b	0xcabc <_stogir.conditional.operands+0x484>
    cab0:      	mov	x2, x1
    cab4:      	mov	x1, x0
    cab8:      	mov	x0, #0x1                ; =1
    cabc:      	str	x0, [x20]
    cac0:      	str	x1, [x20, #0x8]
    cac4:      	str	x2, [x20, #0x10]
    cac8:      	ldr	x19, [sp, #0x30]
    cacc:      	ldr	x20, [sp, #0x38]
    cad0:      	ldr	x21, [sp, #0x40]
    cad4:      	ldr	x22, [sp, #0x48]
    cad8:      	ldr	x23, [sp, #0x50]
    cadc:      	ldr	x24, [sp, #0x58]
    cae0:      	ldr	x29, [sp]
    cae4:      	ldr	x30, [sp, #0x8]
    cae8:      	add	sp, sp, #0x60
    caec:      	ret
    caf0:      	cmp	x9, #0x0
    caf4:      	b.ge	0xc8f0 <_stogir.conditional.operands+0x2b8>
    caf8:      	ldr	x13, [x6, #0x8]
    cafc:      	ldr	x14, [x7, #0x8]
    cb00:      	cmp	x13, x14
    cb04:      	b.ne	0xc83c <_stogir.conditional.operands+0x204>
    cb08:      	cmp	x11, x13
    cb0c:      	b.gt	0xc784 <_stogir.conditional.operands+0x14c>
    cb10:      	lsl	x11, x12, #2
    cb14:      	ldr	x11, [x21, #0x50]
    cb18:      	add	x11, x11, x12, lsl #2
    cb1c:      	ldr	w11, [x11]
    cb20:      	sxtw	x11, w11
    cb24:      	cmp	x11, #0x0
    cb28:      	cset	w11, gt
    cb2c:      	ubfx	x11, x11, #0, #8
    cb30:      	b	0xc788 <_stogir.conditional.operands+0x150>
    cb34:      	movz	x3, #0x0, lsl #48
    cb38:      	b	0xc790 <_stogir.conditional.operands+0x158>
    cb3c:      	movz	x3, #0x0, lsl #48
    cb40:      	b	0xc780 <_stogir.conditional.operands+0x148>
    cb44:      	brk	#0
    cb48:      	b	0xcb44 <_stogir.conditional.operands+0x50c>
    cb4c:      	brk	#0
    cb50:      	b	0xcb4c <_stogir.conditional.operands+0x514>
    cb54:      	brk	#0
    cb58:      	b	0xcb54 <_stogir.conditional.operands+0x51c>

000000000000cb5c <_stogir.floating.unary?>:
    cb5c:      	sxtw	x0, w0
    cb60:      	cmp	x0, #0x1f
    cb64:      	b.ne	0xcb70 <_stogir.floating.unary?+0x14>
    cb68:      	mov	x0, #0x1                ; =1
    cb6c:      	b	0xcb7c <_stogir.floating.unary?+0x20>
    cb70:      	cmp	x0, #0x20
    cb74:      	cset	w0, eq
    cb78:      	ubfx	x0, x0, #0, #8
    cb7c:      	ret

000000000000cb80 <_stogir.floating.comparison?>:
    cb80:      	sxtw	x0, w0
    cb84:      	cmp	x0, #0xe
    cb88:      	b.lt	0xcb9c <_stogir.floating.comparison?+0x1c>
    cb8c:      	cmp	x0, #0x19
    cb90:      	cset	w0, le
    cb94:      	ubfx	x0, x0, #0, #8
    cb98:      	b	0xcba0 <_stogir.floating.comparison?+0x20>
    cb9c:      	movz	x0, #0x0, lsl #48
    cba0:      	ret

000000000000cba4 <_stogir.floating.operands>:
    cba4:      	sub	sp, sp, #0x90
    cba8:      	str	x29, [sp]
    cbac:      	str	x30, [sp, #0x8]
    cbb0:      	mov	x29, sp
    cbb4:      	str	x19, [sp, #0x60]
    cbb8:      	str	x20, [sp, #0x68]
    cbbc:      	str	x21, [sp, #0x70]
    cbc0:      	str	x22, [sp, #0x78]
    cbc4:      	str	x23, [sp, #0x80]
    cbc8:      	sxtw	x1, w1
    cbcc:      	sxtw	x19, w2
    cbd0:      	cmp	x1, #0x1f
    cbd4:      	cset	w2, eq
    cbd8:      	cmp	x1, #0x20
    cbdc:      	cset	w6, eq
    cbe0:      	cmp	x1, #0xe
    cbe4:      	b.lt	0xcc14 <_stogir.floating.operands+0x70>
    cbe8:      	cmp	x1, #0x19
    cbec:      	b.gt	0xcc14 <_stogir.floating.operands+0x70>
    cbf0:      	cmp	x19, #0xc
    cbf4:      	b.eq	0xcc50 <_stogir.floating.operands+0xac>
    cbf8:      	cmp	x19, #0xd
    cbfc:      	b.eq	0xcc50 <_stogir.floating.operands+0xac>
    cc00:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000cc00:  ARM64_RELOC_PAGE21	l_stogir.472
    cc04:      	ldr	x16, [x16]
		000000000000cc04:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    cc08:      	orr	x7, x16, xzr
    cc0c:      	mov	x9, #0x22               ; =34
    cc10:      	b	0xcc60 <_stogir.floating.operands+0xbc>
    cc14:      	uxtb	w16, w2
    cc18:      	cmp	w16, wzr
    cc1c:      	b.ne	0xcbf0 <_stogir.floating.operands+0x4c>
    cc20:      	uxtb	w16, w6
    cc24:      	cmp	w16, wzr
    cc28:      	b.ne	0xcbf0 <_stogir.floating.operands+0x4c>
    cc2c:      	cmp	x1, #0x1a
    cc30:      	b.lt	0xcc3c <_stogir.floating.operands+0x98>
    cc34:      	cmp	x1, #0x1d
    cc38:      	b.le	0xcbf0 <_stogir.floating.operands+0x4c>
    cc3c:      	cmp	x1, #0x3a
    cc40:      	b.eq	0xcbf0 <_stogir.floating.operands+0x4c>
    cc44:      	cmp	x1, #0x3b
    cc48:      	b.eq	0xcbf0 <_stogir.floating.operands+0x4c>
    cc4c:      	b	0xcc00 <_stogir.floating.operands+0x5c>
    cc50:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000cc50:  ARM64_RELOC_PAGE21	l_stogir.473
    cc54:      	ldr	x16, [x16]
		000000000000cc54:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    cc58:      	orr	x7, x16, xzr
    cc5c:      	movz	x9, #0x0, lsl #48
    cc60:      	lsr	w3, w3, #0
    cc64:      	add	x16, sp, #0x10
    cc68:      	str	w3, [x16]
    cc6c:      	uxtb	w16, w2
    cc70:      	cmp	w16, wzr
    cc74:      	b.ne	0xccfc <_stogir.floating.operands+0x158>
    cc78:      	uxtb	w16, w6
    cc7c:      	cmp	w16, wzr
    cc80:      	b.ne	0xccfc <_stogir.floating.operands+0x158>
    cc84:      	sxtw	x4, w4
    cc88:      	mov	x2, x4
    cc8c:      	b	0xcd04 <_stogir.floating.operands+0x160>
    cc90:      	movz	x1, #0x0, lsl #48
    cc94:      	uxtb	w1, w1
    cc98:      	and	x1, x1, #0x2
    cc9c:      	uxtb	w1, w1
    cca0:      	cmp	x1, #0x0
    cca4:      	cset	w1, eq
    cca8:      	uxtb	w16, w1
    ccac:      	cmp	w16, wzr
    ccb0:      	cset	x1, eq
    ccb4:      	cmp	x1, #0x0
    ccb8:      	b.ne	0xd070 <_stogir.floating.operands+0x4cc>
    ccbc:      	cmp	x0, #0x65
    ccc0:      	b.eq	0xd070 <_stogir.floating.operands+0x4cc>
    ccc4:      	cmp	x0, #0x66
    ccc8:      	b.eq	0xd070 <_stogir.floating.operands+0x4cc>
    cccc:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000cccc:  ARM64_RELOC_PAGE21	l_stogir.474
    ccd0:      	ldr	x16, [x16]
		000000000000ccd0:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    ccd4:      	orr	x0, x16, xzr
    ccd8:      	mov	x1, #0x2d               ; =45
    ccdc:      	b	0xce18 <_stogir.floating.operands+0x274>
    cce0:      	movz	x13, #0x0, lsl #48
    cce4:      	fmov	d31, x9
    cce8:      	mov	x9, x13
    ccec:      	fmov	x13, d31
    ccf0:      	b	0xcd64 <_stogir.floating.operands+0x1c0>
    ccf4:      	movz	x13, #0x0, lsl #48
    ccf8:      	b	0xcd6c <_stogir.floating.operands+0x1c8>
    ccfc:      	sxtw	x3, w3
    cd00:      	mov	x2, x3
    cd04:      	add	x16, sp, #0x20
    cd08:      	orr	x3, x16, xzr
    cd0c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000cd0c:  ARM64_RELOC_PAGE21	l_stogir.475
    cd10:      	ldr	x16, [x16]
		000000000000cd10:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    cd14:      	orr	x4, x16, xzr
    cd18:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000cd18:  ARM64_RELOC_PAGE21	l_stogir.476
    cd1c:      	ldr	x16, [x16]
		000000000000cd1c:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    cd20:      	orr	x6, x16, xzr
    cd24:      	add	x10, x0, #0x78
    cd28:      	add	x11, x0, #0x28
    cd2c:      	add	x12, x0, #0x50
    cd30:      	lsr	w2, w2, #0
    cd34:      	add	x16, sp, #0x10
    cd38:      	str	w2, [x16, #0x4]
    cd3c:      	add	x16, sp, #0x10
    cd40:      	ldr	x2, [x16]
    cd44:      	add	x16, sp, #0x20
    cd48:      	str	x2, [x16]
    cd4c:      	mov	x20, x7
    cd50:      	mov	x21, x9
    cd54:      	movz	x2, #0x0, lsl #48
    cd58:      	b	0xce30 <_stogir.floating.operands+0x28c>
    cd5c:      	mov	x13, x9
    cd60:      	movz	x9, #0x0, lsl #48
    cd64:      	b	0xcd78 <_stogir.floating.operands+0x1d4>
    cd68:      	movz	x13, #0x0, lsl #48
    cd6c:      	fmov	d31, x9
    cd70:      	mov	x9, x13
    cd74:      	fmov	x13, d31
    cd78:      	cmp	x9, #0x0
    cd7c:      	b.eq	0xcdc0 <_stogir.floating.operands+0x21c>
    cd80:      	uxtb	w16, w2
    cd84:      	cmp	w16, wzr
    cd88:      	b.eq	0xcda0 <_stogir.floating.operands+0x1fc>
    cd8c:      	lsl	x2, x7, #4
    cd90:      	ldr	x2, [x0]
    cd94:      	add	x2, x2, x7, lsl #4
    cd98:      	ldr	x2, [x2]
    cd9c:      	b	0xcdb0 <_stogir.floating.operands+0x20c>
    cda0:      	lsl	x2, x14, #4
    cda4:      	ldr	x2, [x0, #0x28]
    cda8:      	add	x2, x2, x14, lsl #4
    cdac:      	ldr	x2, [x2]
    cdb0:      	mov	x7, x2
    cdb4:      	mov	x9, x13
    cdb8:      	mov	x2, #0x1                ; =1
    cdbc:      	b	0xcdcc <_stogir.floating.operands+0x228>
    cdc0:      	mov	x9, x13
    cdc4:      	movz	x2, #0x0, lsl #48
    cdc8:      	movz	x7, #0x0, lsl #48
    cdcc:      	lsr	w2, w2, #0
    cdd0:      	lsr	x16, x2, #0
    cdd4:      	cmp	x16, #0x1
    cdd8:      	b.eq	0xcdf4 <_stogir.floating.operands+0x250>
    cddc:      	b.lo	0xcde4 <_stogir.floating.operands+0x240>
    cde0:      	b	0xcdf8 <_stogir.floating.operands+0x254>
    cde4:      	cmp	x16, #0x0
    cde8:      	b.eq	0xcdf0 <_stogir.floating.operands+0x24c>
    cdec:      	b	0xcdf8 <_stogir.floating.operands+0x254>
    cdf0:      	b	0xcdfc <_stogir.floating.operands+0x258>
    cdf4:      	b	0xd018 <_stogir.floating.operands+0x474>
    cdf8:      	b	0xd084 <_stogir.floating.operands+0x4e0>
    cdfc:      	mov	x2, x4
    ce00:      	mov	x7, #0x18               ; =24
    ce04:      	b	0xce24 <_stogir.floating.operands+0x280>
    ce08:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000ce08:  ARM64_RELOC_PAGE21	l_stogir.477
    ce0c:      	ldr	x16, [x16]
		000000000000ce0c:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    ce10:      	orr	x0, x16, xzr
    ce14:      	mov	x1, #0x21               ; =33
    ce18:      	b	0xcf18 <_stogir.floating.operands+0x374>
    ce1c:      	mov	x2, x6
    ce20:      	mov	x7, #0x1e               ; =30
    ce24:      	mov	x20, x2
    ce28:      	mov	x21, x7
    ce2c:      	mov	x2, x9
    ce30:      	cmp	x2, #0x2
    ce34:      	b.ge	0xce60 <_stogir.floating.operands+0x2bc>
    ce38:      	add	x7, x2, #0x1
    ce3c:      	lsl	x9, x2, #2
    ce40:      	add	x2, x3, x2, lsl #2
    ce44:      	ldr	w2, [x2]
    ce48:      	sxtw	x2, w2
    ce4c:      	and	x2, x2, #0xffffffff
    ce50:      	mov	x9, x7
    ce54:      	mov	x7, x2
    ce58:      	mov	x2, #0x1                ; =1
    ce5c:      	b	0xce6c <_stogir.floating.operands+0x2c8>
    ce60:      	mov	x9, x2
    ce64:      	movz	x2, #0x0, lsl #48
    ce68:      	movz	x7, #0x0, lsl #48
    ce6c:      	lsr	w2, w2, #0
    ce70:      	lsr	x16, x2, #0
    ce74:      	cmp	x16, #0x1
    ce78:      	b.eq	0xce94 <_stogir.floating.operands+0x2f0>
    ce7c:      	b.lo	0xce84 <_stogir.floating.operands+0x2e0>
    ce80:      	b	0xce98 <_stogir.floating.operands+0x2f4>
    ce84:      	cmp	x16, #0x0
    ce88:      	b.eq	0xce90 <_stogir.floating.operands+0x2ec>
    ce8c:      	b	0xce98 <_stogir.floating.operands+0x2f4>
    ce90:      	b	0xcf00 <_stogir.floating.operands+0x35c>
    ce94:      	b	0xce9c <_stogir.floating.operands+0x2f8>
    ce98:      	b	0xd07c <_stogir.floating.operands+0x4d8>
    ce9c:      	lsr	w7, w7, #0
    cea0:      	sxtw	x7, w7
    cea4:      	cmp	x7, #0x0
    cea8:      	cset	w2, gt
    ceac:      	movz	x16, #0x0, lsl #48
    ceb0:      	sub	x13, x16, x7
    ceb4:      	sub	x14, x13, #0x1
    ceb8:      	uxtb	w16, w2
    cebc:      	cmp	w16, wzr
    cec0:      	b.eq	0xcf98 <_stogir.floating.operands+0x3f4>
    cec4:      	ldr	x13, [x0, #0x8]
    cec8:      	cmp	x7, x13
    cecc:      	b.ge	0xcd5c <_stogir.floating.operands+0x1b8>
    ced0:      	ldr	x13, [x10, #0x8]
    ced4:      	cmp	x7, x13
    ced8:      	b.ge	0xcce0 <_stogir.floating.operands+0x13c>
    cedc:      	lsl	x13, x7, #2
    cee0:      	ldr	x13, [x0, #0x78]
    cee4:      	add	x13, x13, x7, lsl #2
    cee8:      	ldr	w13, [x13]
    ceec:      	sxtw	x13, w13
    cef0:      	cmp	x13, #0x0
    cef4:      	cset	w13, ge
    cef8:      	ubfx	x13, x13, #0, #8
    cefc:      	b	0xcce4 <_stogir.floating.operands+0x140>
    cf00:      	sxtw	x22, w5
    cf04:      	cmp	x22, #0x0
    cf08:      	b.ne	0xcf34 <_stogir.floating.operands+0x390>
    cf0c:      	mov	x23, x8
    cf10:      	mov	x0, x20
    cf14:      	mov	x1, x21
    cf18:      	cmp	x1, #0x0
    cf1c:      	b.ne	0xcfdc <_stogir.floating.operands+0x438>
    cf20:      	and	x0, x19, #0xffffffff
    cf24:      	mov	x1, x0
    cf28:      	movz	x0, #0x0, lsl #48
    cf2c:      	movz	x2, #0x0, lsl #48
    cf30:      	b	0xcfe8 <_stogir.floating.operands+0x444>
    cf34:      	cmp	x1, #0x1d
    cf38:      	b.ne	0xd094 <_stogir.floating.operands+0x4f0>
    cf3c:      	lsr	w5, w5, #0
    cf40:      	mov	w1, w5
    cf44:      	mov	x23, x8
    cf48:      	add	x8, sp, #0x30
    cf4c:      	bl	0xcf4c <_stogir.floating.operands+0x3a8>
		000000000000cf4c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    cf50:      	add	x16, sp, #0x30
    cf54:      	ldr	w0, [x16]
    cf58:      	lsr	x16, x0, #0
    cf5c:      	cmp	x16, #0x1
    cf60:      	b.eq	0xcf7c <_stogir.floating.operands+0x3d8>
    cf64:      	b.lo	0xcf6c <_stogir.floating.operands+0x3c8>
    cf68:      	b	0xcf80 <_stogir.floating.operands+0x3dc>
    cf6c:      	cmp	x16, #0x0
    cf70:      	b.eq	0xcf78 <_stogir.floating.operands+0x3d4>
    cf74:      	b	0xcf80 <_stogir.floating.operands+0x3dc>
    cf78:      	b	0xcf84 <_stogir.floating.operands+0x3e0>
    cf7c:      	b	0xd03c <_stogir.floating.operands+0x498>
    cf80:      	b	0xd08c <_stogir.floating.operands+0x4e8>
    cf84:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x52c>
		000000000000cf84:  ARM64_RELOC_PAGE21	l_stogir.478
    cf88:      	ldr	x16, [x16]
		000000000000cf88:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    cf8c:      	orr	x0, x16, xzr
    cf90:      	mov	x1, #0x16               ; =22
    cf94:      	b	0xccdc <_stogir.floating.operands+0x138>
    cf98:      	cmp	x7, #0x0
    cf9c:      	b.ge	0xcd68 <_stogir.floating.operands+0x1c4>
    cfa0:      	ldr	x15, [x11, #0x8]
    cfa4:      	ldr	x22, [x12, #0x8]
    cfa8:      	cmp	x15, x22
    cfac:      	b.ne	0xccf4 <_stogir.floating.operands+0x150>
    cfb0:      	cmp	x13, x15
    cfb4:      	b.gt	0xd034 <_stogir.floating.operands+0x490>
    cfb8:      	lsl	x13, x14, #2
    cfbc:      	ldr	x13, [x0, #0x50]
    cfc0:      	add	x13, x13, x14, lsl #2
    cfc4:      	ldr	w13, [x13]
    cfc8:      	sxtw	x13, w13
    cfcc:      	cmp	x13, #0x0
    cfd0:      	cset	w13, gt
    cfd4:      	ubfx	x13, x13, #0, #8
    cfd8:      	b	0xd038 <_stogir.floating.operands+0x494>
    cfdc:      	mov	x2, x1
    cfe0:      	mov	x1, x0
    cfe4:      	mov	x0, #0x1                ; =1
    cfe8:      	str	x0, [x23]
    cfec:      	str	x1, [x23, #0x8]
    cff0:      	str	x2, [x23, #0x10]
    cff4:      	ldr	x19, [sp, #0x60]
    cff8:      	ldr	x20, [sp, #0x68]
    cffc:      	ldr	x21, [sp, #0x70]
    d000:      	ldr	x22, [sp, #0x78]
    d004:      	ldr	x23, [sp, #0x80]
    d008:      	ldr	x29, [sp]
    d00c:      	ldr	x30, [sp, #0x8]
    d010:      	add	sp, sp, #0x90
    d014:      	ret
    d018:      	lsr	w7, w7, #0
    d01c:      	ubfx	x2, x7, #8, #8
    d020:      	cmp	x2, x19
    d024:      	b.ne	0xce1c <_stogir.floating.operands+0x278>
    d028:      	mov	x2, x20
    d02c:      	mov	x7, x21
    d030:      	b	0xce24 <_stogir.floating.operands+0x280>
    d034:      	movz	x13, #0x0, lsl #48
    d038:      	b	0xccf8 <_stogir.floating.operands+0x154>
    d03c:      	add	x16, sp, #0x30
    d040:      	ldr	x0, [x16, #0x8]
    d044:      	cmp	x22, #0x0
    d048:      	b.lt	0xcccc <_stogir.floating.operands+0x128>
    d04c:      	uxtb	w0, w0
    d050:      	cmp	x0, #0x83
    d054:      	b.ge	0xcc90 <_stogir.floating.operands+0xec>
    d058:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d058:  ARM64_RELOC_PAGE21	l_stogir.479
    d05c:      	ldr	x16, [x16]
		000000000000d05c:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    d060:      	orr	x1, x16, xzr
    d064:      	add	x1, x0, x1
    d068:      	ldrb	w1, [x1]
    d06c:      	b	0xcc94 <_stogir.floating.operands+0xf0>
    d070:      	mov	x0, x20
    d074:      	mov	x1, x21
    d078:      	b	0xccdc <_stogir.floating.operands+0x138>
    d07c:      	brk	#0
    d080:      	b	0xd07c <_stogir.floating.operands+0x4d8>
    d084:      	brk	#0
    d088:      	b	0xd084 <_stogir.floating.operands+0x4e0>
    d08c:      	brk	#0
    d090:      	b	0xd08c <_stogir.floating.operands+0x4e8>
    d094:      	mov	x23, x8
    d098:      	b	0xce08 <_stogir.floating.operands+0x264>

000000000000d09c <_stogir.types.signed?>:
    d09c:      	sxtw	x0, w0
    d0a0:      	cmp	x0, #0x7
    d0a4:      	b.lt	0xd0b8 <_stogir.types.signed?+0x1c>
    d0a8:      	cmp	x0, #0xb
    d0ac:      	cset	w0, le
    d0b0:      	ubfx	x0, x0, #0, #8
    d0b4:      	b	0xd0bc <_stogir.types.signed?+0x20>
    d0b8:      	movz	x0, #0x0, lsl #48
    d0bc:      	ret

000000000000d0c0 <_stogir.integer-binary.logical?>:
    d0c0:      	sxtw	x0, w0
    d0c4:      	cmp	x0, #0x2e
    d0c8:      	b.ne	0xd0e4 <_stogir.integer-binary.logical?+0x24>
    d0cc:      	mov	x0, #0x1                ; =1
    d0d0:      	b	0xd0e0 <_stogir.integer-binary.logical?+0x20>
    d0d4:      	cmp	x0, #0x30
    d0d8:      	cset	w0, eq
    d0dc:      	ubfx	x0, x0, #0, #8
    d0e0:      	ret
    d0e4:      	cmp	x0, #0x2f
    d0e8:      	b.ne	0xd0d4 <_stogir.integer-binary.logical?+0x14>
    d0ec:      	mov	x0, #0x1                ; =1
    d0f0:      	b	0xd0e0 <_stogir.integer-binary.logical?+0x20>

000000000000d0f4 <_inherent$slice$data__i8>:
    d0f4:      	ret

000000000000d0f8 <_inherent$slice$data__u32>:
    d0f8:      	ret

000000000000d0fc <_inherent$coil.arraylist.ArrayList$slice__stogir.node.Node>:
    d0fc:      	sub	sp, sp, #0x10
    d100:      	mov	x1, sp
    d104:      	ldr	x2, [x0]
    d108:      	ldr	x0, [x0, #0x8]
    d10c:      	str	x2, [x1]
    d110:      	str	x0, [x1, #0x8]
    d114:      	ldr	x0, [sp]
    d118:      	ldr	x1, [sp, #0x8]
    d11c:      	add	sp, sp, #0x10
    d120:      	ret

000000000000d124 <_inherent$slice$at__stogir.node.Node>:
    d124:      	lsl	x1, x2, #4
    d128:      	add	x0, x0, x2, lsl #4
    d12c:      	ret

000000000000d130 <_inherent$slice$new__u8>:
    d130:      	sub	sp, sp, #0x10
    d134:      	mov	x2, sp
    d138:      	str	x0, [x2]
    d13c:      	str	x1, [x2, #0x8]
    d140:      	ldr	x0, [sp]
    d144:      	ldr	x1, [sp, #0x8]
    d148:      	add	sp, sp, #0x10
    d14c:      	ret

000000000000d150 <_stogir.vector-lanes.operands>:
    d150:      	sub	sp, sp, #0x110
    d154:      	str	x29, [sp]
    d158:      	str	x30, [sp, #0x8]
    d15c:      	mov	x29, sp
    d160:      	str	x19, [sp, #0xc0]
    d164:      	str	x20, [sp, #0xc8]
    d168:      	str	x21, [sp, #0xd0]
    d16c:      	str	x22, [sp, #0xd8]
    d170:      	str	x23, [sp, #0xe0]
    d174:      	str	x24, [sp, #0xe8]
    d178:      	str	x25, [sp, #0xf0]
    d17c:      	str	x26, [sp, #0xf8]
    d180:      	str	x27, [sp, #0x100]
    d184:      	str	x28, [sp, #0x108]
    d188:      	sxtw	x4, w4
    d18c:      	cmp	x4, #0x0
    d190:      	cset	w7, gt
    d194:      	movz	x16, #0x0, lsl #48
    d198:      	sub	x9, x16, x4
    d19c:      	sub	x10, x9, #0x1
    d1a0:      	uxtb	w16, w7
    d1a4:      	cmp	w16, wzr
    d1a8:      	b.eq	0xd1ec <_stogir.vector-lanes.operands+0x9c>
    d1ac:      	ldr	x9, [x0, #0x8]
    d1b0:      	cmp	x4, x9
    d1b4:      	b.ge	0xd250 <_stogir.vector-lanes.operands+0x100>
    d1b8:      	add	x9, x0, #0x78
    d1bc:      	ldr	x9, [x9, #0x8]
    d1c0:      	cmp	x4, x9
    d1c4:      	b.ge	0xd360 <_stogir.vector-lanes.operands+0x210>
    d1c8:      	lsl	x9, x4, #2
    d1cc:      	ldr	x9, [x0, #0x78]
    d1d0:      	add	x9, x9, x4, lsl #2
    d1d4:      	ldr	w9, [x9]
    d1d8:      	sxtw	x9, w9
    d1dc:      	cmp	x9, #0x0
    d1e0:      	cset	w9, ge
    d1e4:      	ubfx	x9, x9, #0, #8
    d1e8:      	b	0xd364 <_stogir.vector-lanes.operands+0x214>
    d1ec:      	cmp	x4, #0x0
    d1f0:      	b.ge	0xd258 <_stogir.vector-lanes.operands+0x108>
    d1f4:      	add	x11, x0, #0x28
    d1f8:      	add	x12, x0, #0x50
    d1fc:      	ldr	x11, [x11, #0x8]
    d200:      	ldr	x12, [x12, #0x8]
    d204:      	cmp	x11, x12
    d208:      	b.ne	0xd238 <_stogir.vector-lanes.operands+0xe8>
    d20c:      	cmp	x9, x11
    d210:      	b.gt	0xd4fc <_stogir.vector-lanes.operands+0x3ac>
    d214:      	lsl	x9, x10, #2
    d218:      	ldr	x9, [x0, #0x50]
    d21c:      	add	x9, x9, x10, lsl #2
    d220:      	ldr	w9, [x9]
    d224:      	sxtw	x9, w9
    d228:      	cmp	x9, #0x0
    d22c:      	cset	w9, gt
    d230:      	ubfx	x9, x9, #0, #8
    d234:      	b	0xd500 <_stogir.vector-lanes.operands+0x3b0>
    d238:      	movz	x9, #0x0, lsl #48
    d23c:      	b	0xd25c <_stogir.vector-lanes.operands+0x10c>
    d240:      	mov	x2, x1
    d244:      	mov	x1, x0
    d248:      	mov	x0, #0x1                ; =1
    d24c:      	b	0xd2f4 <_stogir.vector-lanes.operands+0x1a4>
    d250:      	movz	x9, #0x0, lsl #48
    d254:      	b	0xd25c <_stogir.vector-lanes.operands+0x10c>
    d258:      	movz	x9, #0x0, lsl #48
    d25c:      	cmp	x9, #0x0
    d260:      	b.eq	0xd2a0 <_stogir.vector-lanes.operands+0x150>
    d264:      	uxtb	w16, w7
    d268:      	cmp	w16, wzr
    d26c:      	b.eq	0xd284 <_stogir.vector-lanes.operands+0x134>
    d270:      	lsl	x7, x4, #4
    d274:      	ldr	x7, [x0]
    d278:      	add	x4, x7, x4, lsl #4
    d27c:      	ldr	x4, [x4]
    d280:      	b	0xd294 <_stogir.vector-lanes.operands+0x144>
    d284:      	lsl	x4, x10, #4
    d288:      	ldr	x4, [x0, #0x28]
    d28c:      	add	x4, x4, x10, lsl #4
    d290:      	ldr	x4, [x4]
    d294:      	mov	x7, x4
    d298:      	mov	x4, #0x1                ; =1
    d29c:      	b	0xd2a8 <_stogir.vector-lanes.operands+0x158>
    d2a0:      	movz	x4, #0x0, lsl #48
    d2a4:      	movz	x7, #0x0, lsl #48
    d2a8:      	lsr	w4, w4, #0
    d2ac:      	lsr	x16, x4, #0
    d2b0:      	cmp	x16, #0x1
    d2b4:      	b.eq	0xd2d0 <_stogir.vector-lanes.operands+0x180>
    d2b8:      	b.lo	0xd2c0 <_stogir.vector-lanes.operands+0x170>
    d2bc:      	b	0xd2d4 <_stogir.vector-lanes.operands+0x184>
    d2c0:      	cmp	x16, #0x0
    d2c4:      	b.eq	0xd2cc <_stogir.vector-lanes.operands+0x17c>
    d2c8:      	b	0xd2d4 <_stogir.vector-lanes.operands+0x184>
    d2cc:      	b	0xd2d8 <_stogir.vector-lanes.operands+0x188>
    d2d0:      	b	0xd33c <_stogir.vector-lanes.operands+0x1ec>
    d2d4:      	b	0xd890 <_stogir.vector-lanes.operands+0x740>
    d2d8:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d2d8:  ARM64_RELOC_PAGE21	l_stogir.480
    d2dc:      	ldr	x16, [x16]
		000000000000d2dc:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    d2e0:      	orr	x0, x16, xzr
    d2e4:      	str	x8, [sp, #0xa0]
    d2e8:      	mov	x1, x0
    d2ec:      	mov	x0, #0x1                ; =1
    d2f0:      	mov	x2, #0x1b               ; =27
    d2f4:      	ldr	x3, [sp, #0xa0]
    d2f8:      	str	x0, [x3]
    d2fc:      	str	x1, [x3, #0x8]
    d300:      	str	x2, [x3, #0x10]
    d304:      	ldr	x19, [sp, #0xc0]
    d308:      	ldr	x20, [sp, #0xc8]
    d30c:      	ldr	x21, [sp, #0xd0]
    d310:      	ldr	x22, [sp, #0xd8]
    d314:      	ldr	x23, [sp, #0xe0]
    d318:      	ldr	x24, [sp, #0xe8]
    d31c:      	ldr	x25, [sp, #0xf0]
    d320:      	ldr	x26, [sp, #0xf8]
    d324:      	ldr	x27, [sp, #0x100]
    d328:      	ldr	x28, [sp, #0x108]
    d32c:      	ldr	x29, [sp]
    d330:      	ldr	x30, [sp, #0x8]
    d334:      	add	sp, sp, #0x110
    d338:      	ret
    d33c:      	sxtw	x19, w1
    d340:      	sxtw	x1, w2
    d344:      	lsr	w4, w7, #0
    d348:      	ubfx	x4, x4, #8, #8
    d34c:      	orr	x20, x4, xzr
    d350:      	cmp	x19, #0x3d
    d354:      	b.ne	0xd368 <_stogir.vector-lanes.operands+0x218>
    d358:      	mov	x21, x20
    d35c:      	b	0xd36c <_stogir.vector-lanes.operands+0x21c>
    d360:      	movz	x9, #0x0, lsl #48
    d364:      	b	0xd254 <_stogir.vector-lanes.operands+0x104>
    d368:      	mov	x21, x1
    d36c:      	cmp	x19, #0x3d
    d370:      	b.eq	0xd378 <_stogir.vector-lanes.operands+0x228>
    d374:      	mov	x1, x20
    d378:      	lsr	w22, w21, #0
    d37c:      	sxtw	x23, w22
    d380:      	cmp	x23, #0xf
    d384:      	cset	w24, gt
    d388:      	cmp	x23, #0x80
    d38c:      	cset	w25, lt
    d390:      	and	x4, x23, #0xf
    d394:      	lsr	w4, w4, #0
    d398:      	sxtw	x4, w4
    d39c:      	cmp	x4, #0x1
    d3a0:      	cset	w26, ge
    d3a4:      	cmp	x4, #0xd
    d3a8:      	cset	w27, le
    d3ac:      	cmp	x19, #0x3d
    d3b0:      	b.lt	0xd400 <_stogir.vector-lanes.operands+0x2b0>
    d3b4:      	cmp	x19, #0x3f
    d3b8:      	b.gt	0xd400 <_stogir.vector-lanes.operands+0x2b0>
    d3bc:      	uxtb	w16, w24
    d3c0:      	cmp	w16, wzr
    d3c4:      	b.eq	0xd400 <_stogir.vector-lanes.operands+0x2b0>
    d3c8:      	uxtb	w16, w25
    d3cc:      	cmp	w16, wzr
    d3d0:      	b.eq	0xd400 <_stogir.vector-lanes.operands+0x2b0>
    d3d4:      	uxtb	w16, w26
    d3d8:      	cmp	w16, wzr
    d3dc:      	b.eq	0xd400 <_stogir.vector-lanes.operands+0x2b0>
    d3e0:      	uxtb	w16, w27
    d3e4:      	cmp	w16, wzr
    d3e8:      	b.eq	0xd400 <_stogir.vector-lanes.operands+0x2b0>
    d3ec:      	sxtw	x4, w3
    d3f0:      	cmp	x4, #0x4
    d3f4:      	b.eq	0xd8c0 <_stogir.vector-lanes.operands+0x770>
    d3f8:      	cmp	x4, #0x8
    d3fc:      	b.eq	0xd8c0 <_stogir.vector-lanes.operands+0x770>
    d400:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d400:  ARM64_RELOC_PAGE21	l_stogir.481
    d404:      	ldr	x16, [x16]
		000000000000d404:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    d408:      	orr	x4, x16, xzr
    d40c:      	mov	x28, x4
    d410:      	mov	x4, #0x36               ; =54
    d414:      	sxtw	x7, w5
    d418:      	sxtw	x9, w6
    d41c:      	cmp	x9, #0x0
    d420:      	cset	w9, eq
    d424:      	cmp	x19, #0x3f
    d428:      	b.ne	0xd8fc <_stogir.vector-lanes.operands+0x7ac>
    d42c:      	lsr	w1, w1, #0
    d430:      	lsr	w3, w3, #0
    d434:      	mov	w0, w22
    d438:      	mov	w2, w3
    d43c:      	mov	x19, x8
    d440:      	mov	x20, x4
    d444:      	mov	x22, x7
    d448:      	mov	w23, w9
    d44c:      	bl	0xd44c <_stogir.vector-lanes.operands+0x2fc>
		000000000000d44c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d450:      	cmp	x0, #0x0
    d454:      	b.eq	0xd538 <_stogir.vector-lanes.operands+0x3e8>
    d458:      	mov	x1, x28
    d45c:      	movz	x0, #0x0, lsl #48
    d460:      	b	0xd540 <_stogir.vector-lanes.operands+0x3f0>
    d464:      	cmp	x19, #0x3d
    d468:      	b.ne	0xd908 <_stogir.vector-lanes.operands+0x7b8>
    d46c:      	lsr	w2, w2, #0
    d470:      	lsr	w3, w3, #0
    d474:      	str	x0, [sp, #0x80]
    d478:      	mov	w0, w22
    d47c:      	str	w3, [sp, #0xb0]
    d480:      	str	x1, [sp, #0xa0]
    d484:      	mov	w1, w2
    d488:      	mov	w2, w3
    d48c:      	str	x4, [sp, #0xa8]
    d490:      	str	w8, [sp, #0xb8]
    d494:      	str	w22, [sp, #0x88]
    d498:      	mov	x22, x7
    d49c:      	str	x28, [sp, #0x90]
    d4a0:      	mov	w28, w5
    d4a4:      	str	x21, [sp, #0x98]
    d4a8:      	mov	w21, w6
    d4ac:      	bl	0xd4ac <_stogir.vector-lanes.operands+0x35c>
		000000000000d4ac:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d4b0:      	cmp	x0, #0x0
    d4b4:      	b.ne	0xd568 <_stogir.vector-lanes.operands+0x418>
    d4b8:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d4b8:  ARM64_RELOC_PAGE21	l_stogir.482
    d4bc:      	ldr	x16, [x16]
		000000000000d4bc:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    d4c0:      	orr	x0, x16, xzr
    d4c4:      	mov	x1, #0x26               ; =38
    d4c8:      	b	0xd570 <_stogir.vector-lanes.operands+0x420>
    d4cc:      	mov	x0, x1
    d4d0:      	mov	x1, x20
    d4d4:      	str	x21, [sp, #0x98]
    d4d8:      	str	x19, [sp, #0xa0]
    d4dc:      	cmp	x1, #0x0
    d4e0:      	b.ne	0xd240 <_stogir.vector-lanes.operands+0xf0>
    d4e4:      	ldr	x0, [sp, #0x98]
    d4e8:      	and	x0, x0, #0xffffffff
    d4ec:      	mov	x1, x0
    d4f0:      	movz	x0, #0x0, lsl #48
    d4f4:      	movz	x2, #0x0, lsl #48
    d4f8:      	b	0xd24c <_stogir.vector-lanes.operands+0xfc>
    d4fc:      	movz	x9, #0x0, lsl #48
    d500:      	b	0xd23c <_stogir.vector-lanes.operands+0xec>
    d504:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d504:  ARM64_RELOC_PAGE21	l_stogir.483
    d508:      	ldr	x16, [x16]
		000000000000d508:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    d50c:      	orr	x0, x16, xzr
    d510:      	mov	x1, #0x20               ; =32
    d514:      	b	0xd4dc <_stogir.vector-lanes.operands+0x38c>
    d518:      	mov	x0, #0x1                ; =1
    d51c:      	cmp	x0, #0x0
    d520:      	b.eq	0xd4cc <_stogir.vector-lanes.operands+0x37c>
    d524:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d524:  ARM64_RELOC_PAGE21	l_stogir.484
    d528:      	ldr	x16, [x16]
		000000000000d528:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    d52c:      	orr	x0, x16, xzr
    d530:      	mov	x1, #0x24               ; =36
    d534:      	b	0xd4d4 <_stogir.vector-lanes.operands+0x384>
    d538:      	mov	x1, x28
    d53c:      	mov	x0, #0x1                ; =1
    d540:      	cmp	x0, #0x0
    d544:      	b.eq	0xd550 <_stogir.vector-lanes.operands+0x400>
    d548:      	mov	x0, #0x1                ; =1
    d54c:      	b	0xd51c <_stogir.vector-lanes.operands+0x3cc>
    d550:      	cmp	x22, #0x0
    d554:      	b.ne	0xd518 <_stogir.vector-lanes.operands+0x3c8>
    d558:      	uxtb	w16, w23
    d55c:      	cmp	w16, wzr
    d560:      	cset	x0, eq
    d564:      	b	0xd51c <_stogir.vector-lanes.operands+0x3cc>
    d568:      	ldr	x0, [sp, #0x90]
    d56c:      	ldr	x1, [sp, #0xa8]
    d570:      	cmp	x19, #0x3e
    d574:      	b.ne	0xd59c <_stogir.vector-lanes.operands+0x44c>
    d578:      	cmp	x20, x23
    d57c:      	cset	w2, eq
    d580:      	uxtb	w16, w2
    d584:      	cmp	w16, wzr
    d588:      	cset	x2, eq
    d58c:      	fmov	d31, x0
    d590:      	mov	x0, x2
    d594:      	fmov	x2, d31
    d598:      	b	0xd5a4 <_stogir.vector-lanes.operands+0x454>
    d59c:      	mov	x2, x0
    d5a0:      	movz	x0, #0x0, lsl #48
    d5a4:      	cmp	x0, #0x0
    d5a8:      	b.eq	0xd5c4 <_stogir.vector-lanes.operands+0x474>
    d5ac:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d5ac:  ARM64_RELOC_PAGE21	l_stogir.485
    d5b0:      	ldr	x16, [x16]
		000000000000d5b0:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    d5b4:      	orr	x0, x16, xzr
    d5b8:      	mov	x20, x0
    d5bc:      	mov	x0, #0x27               ; =39
    d5c0:      	b	0xd5cc <_stogir.vector-lanes.operands+0x47c>
    d5c4:      	mov	x20, x2
    d5c8:      	mov	x0, x1
    d5cc:      	lsr	w28, w28, #0
    d5d0:      	add	x8, sp, #0x10
    d5d4:      	mov	w1, w28
    d5d8:      	mov	x28, x0
    d5dc:      	ldr	x0, [sp, #0x80]
    d5e0:      	bl	0xd5e0 <_stogir.vector-lanes.operands+0x490>
		000000000000d5e0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d5e4:      	add	x16, sp, #0x10
    d5e8:      	ldr	w0, [x16]
    d5ec:      	lsr	x16, x0, #0
    d5f0:      	cmp	x16, #0x1
    d5f4:      	b.eq	0xd610 <_stogir.vector-lanes.operands+0x4c0>
    d5f8:      	b.lo	0xd600 <_stogir.vector-lanes.operands+0x4b0>
    d5fc:      	b	0xd614 <_stogir.vector-lanes.operands+0x4c4>
    d600:      	cmp	x16, #0x0
    d604:      	b.eq	0xd60c <_stogir.vector-lanes.operands+0x4bc>
    d608:      	b	0xd614 <_stogir.vector-lanes.operands+0x4c4>
    d60c:      	b	0xd618 <_stogir.vector-lanes.operands+0x4c8>
    d610:      	b	0xd690 <_stogir.vector-lanes.operands+0x540>
    d614:      	b	0xd8ec <_stogir.vector-lanes.operands+0x79c>
    d618:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d618:  ARM64_RELOC_PAGE21	l_stogir.486
    d61c:      	ldr	x16, [x16]
		000000000000d61c:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    d620:      	orr	x0, x16, xzr
    d624:      	mov	x20, x0
    d628:      	mov	x22, #0x19              ; =25
    d62c:      	cmp	x19, #0x3e
    d630:      	b.ne	0xd6f8 <_stogir.vector-lanes.operands+0x5a8>
    d634:      	lsr	w21, w21, #0
    d638:      	add	x8, sp, #0x50
    d63c:      	ldr	x0, [sp, #0x80]
    d640:      	mov	w1, w21
    d644:      	bl	0xd644 <_stogir.vector-lanes.operands+0x4f4>
		000000000000d644:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d648:      	add	x16, sp, #0x50
    d64c:      	ldr	w0, [x16]
    d650:      	lsr	x16, x0, #0
    d654:      	cmp	x16, #0x1
    d658:      	b.eq	0xd674 <_stogir.vector-lanes.operands+0x524>
    d65c:      	b.lo	0xd664 <_stogir.vector-lanes.operands+0x514>
    d660:      	b	0xd678 <_stogir.vector-lanes.operands+0x528>
    d664:      	cmp	x16, #0x0
    d668:      	b.eq	0xd670 <_stogir.vector-lanes.operands+0x520>
    d66c:      	b	0xd678 <_stogir.vector-lanes.operands+0x528>
    d670:      	b	0xd67c <_stogir.vector-lanes.operands+0x52c>
    d674:      	b	0xd7c0 <_stogir.vector-lanes.operands+0x670>
    d678:      	b	0xd8f4 <_stogir.vector-lanes.operands+0x7a4>
    d67c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d67c:  ARM64_RELOC_PAGE21	l_stogir.487
    d680:      	ldr	x16, [x16]
		000000000000d680:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    d684:      	orr	x0, x16, xzr
    d688:      	mov	x1, #0x20               ; =32
    d68c:      	b	0xd514 <_stogir.vector-lanes.operands+0x3c4>
    d690:      	add	x16, sp, #0x10
    d694:      	orr	x0, x16, xzr
    d698:      	add	x0, x0, #0x8
    d69c:      	add	x16, sp, #0x10
    d6a0:      	ldr	x1, [x16, #0x8]
    d6a4:      	add	x16, sp, #0x40
    d6a8:      	str	x1, [x16]
    d6ac:      	lsr	w1, w1, #0
    d6b0:      	ldr	x0, [x0, #0x8]
    d6b4:      	add	x16, sp, #0x40
    d6b8:      	str	x0, [x16, #0x8]
    d6bc:      	ubfx	x0, x1, #8, #8
    d6c0:      	cmp	x0, #0x1
    d6c4:      	b.lt	0xd724 <_stogir.vector-lanes.operands+0x5d4>
    d6c8:      	cmp	x0, #0xb
    d6cc:      	b.gt	0xd724 <_stogir.vector-lanes.operands+0x5d4>
    d6d0:      	add	x16, sp, #0x40
    d6d4:      	ldr	w0, [x16]
    d6d8:      	uxtb	w0, w0
    d6dc:      	cmp	x0, #0x48
    d6e0:      	b.eq	0xd724 <_stogir.vector-lanes.operands+0x5d4>
    d6e4:      	cmp	x0, #0x46
    d6e8:      	b.eq	0xd724 <_stogir.vector-lanes.operands+0x5d4>
    d6ec:      	mov	x0, x20
    d6f0:      	mov	x1, x28
    d6f4:      	b	0xd734 <_stogir.vector-lanes.operands+0x5e4>
    d6f8:      	ldr	w0, [sp, #0xb8]
    d6fc:      	uxtb	w16, w0
    d700:      	cmp	w16, wzr
    d704:      	b.eq	0xd504 <_stogir.vector-lanes.operands+0x3b4>
    d708:      	mov	x0, x20
    d70c:      	mov	x1, x22
    d710:      	b	0xd514 <_stogir.vector-lanes.operands+0x3c4>
    d714:      	mov	x0, x2
    d718:      	mov	x20, x0
    d71c:      	mov	x22, x1
    d720:      	b	0xd62c <_stogir.vector-lanes.operands+0x4dc>
    d724:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d724:  ARM64_RELOC_PAGE21	l_stogir.488
    d728:      	ldr	x16, [x16]
		000000000000d728:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    d72c:      	orr	x0, x16, xzr
    d730:      	mov	x1, #0x2b               ; =43
    d734:      	cmp	x22, #0x0
    d738:      	b.ge	0xd764 <_stogir.vector-lanes.operands+0x614>
    d73c:      	add	x16, sp, #0x40
    d740:      	ldr	w2, [x16]
    d744:      	uxtb	w3, w2
    d748:      	ubfx	x2, x2, #8, #8
    d74c:      	cmp	x3, x2
    d750:      	b.eq	0xd828 <_stogir.vector-lanes.operands+0x6d8>
    d754:      	cmp	x3, #0x49
    d758:      	b.eq	0xd828 <_stogir.vector-lanes.operands+0x6d8>
    d75c:      	movz	x2, #0x0, lsl #48
    d760:      	b	0xd7b0 <_stogir.vector-lanes.operands+0x660>
    d764:      	mov	x2, x0
    d768:      	movz	x0, #0x0, lsl #48
    d76c:      	cmp	x0, #0x0
    d770:      	b.eq	0xd714 <_stogir.vector-lanes.operands+0x5c4>
    d774:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d774:  ARM64_RELOC_PAGE21	l_stogir.489
    d778:      	ldr	x16, [x16]
		000000000000d778:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    d77c:      	orr	x0, x16, xzr
    d780:      	mov	x1, #0x28               ; =40
    d784:      	b	0xd718 <_stogir.vector-lanes.operands+0x5c8>
    d788:      	movn	x4, #0x0, lsl #48
    d78c:      	ubfx	x2, x2, #0, #32
    d790:      	ubfx	x3, x3, #0, #32
    d794:      	lsl	x3, x3, #32
    d798:      	orr	x2, x3, x2
    d79c:      	lsr	w4, w4, #0
    d7a0:      	sxtw	x4, w4
    d7a4:      	cmp	x2, x4
    d7a8:      	cset	w2, hs
    d7ac:      	ubfx	x2, x2, #0, #8
    d7b0:      	fmov	d31, x0
    d7b4:      	mov	x0, x2
    d7b8:      	fmov	x2, d31
    d7bc:      	b	0xd76c <_stogir.vector-lanes.operands+0x61c>
    d7c0:      	add	x16, sp, #0x50
    d7c4:      	ldr	x0, [x16, #0x8]
    d7c8:      	uxtb	w1, w0
    d7cc:      	cmp	x1, #0x48
    d7d0:      	b.eq	0xd814 <_stogir.vector-lanes.operands+0x6c4>
    d7d4:      	cmp	x1, #0x46
    d7d8:      	b.eq	0xd814 <_stogir.vector-lanes.operands+0x6c4>
    d7dc:      	ldr	w1, [sp, #0xb0]
    d7e0:      	lsr	w1, w1, #0
    d7e4:      	lsr	w0, w0, #0
    d7e8:      	ubfx	x0, x0, #8, #8
    d7ec:      	lsr	w0, w0, #0
    d7f0:      	mov	w2, w1
    d7f4:      	mov	w1, w0
    d7f8:      	ldr	w0, [sp, #0x88]
    d7fc:      	bl	0xd7fc <_stogir.vector-lanes.operands+0x6ac>
		000000000000d7fc:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d800:      	cmp	x0, #0x0
    d804:      	b.eq	0xd814 <_stogir.vector-lanes.operands+0x6c4>
    d808:      	mov	x0, x20
    d80c:      	mov	x1, x22
    d810:      	b	0xd824 <_stogir.vector-lanes.operands+0x6d4>
    d814:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d814:  ARM64_RELOC_PAGE21	l_stogir.490
    d818:      	ldr	x16, [x16]
		000000000000d818:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    d81c:      	orr	x0, x16, xzr
    d820:      	mov	x1, #0x27               ; =39
    d824:      	b	0xd68c <_stogir.vector-lanes.operands+0x53c>
    d828:      	add	x16, sp, #0x40
    d82c:      	ldr	w2, [x16, #0x8]
    d830:      	add	x16, sp, #0x40
    d834:      	ldr	w3, [x16, #0xc]
    d838:      	uxtb	w16, w24
    d83c:      	cmp	w16, wzr
    d840:      	b.eq	0xd898 <_stogir.vector-lanes.operands+0x748>
    d844:      	uxtb	w16, w25
    d848:      	cmp	w16, wzr
    d84c:      	b.eq	0xd898 <_stogir.vector-lanes.operands+0x748>
    d850:      	uxtb	w16, w26
    d854:      	cmp	w16, wzr
    d858:      	b.eq	0xd898 <_stogir.vector-lanes.operands+0x748>
    d85c:      	uxtb	w16, w27
    d860:      	cmp	w16, wzr
    d864:      	b.eq	0xd898 <_stogir.vector-lanes.operands+0x748>
    d868:      	ubfx	x4, x23, #4, #32
    d86c:      	sxtw	x4, w4
    d870:      	sub	x4, x4, #0x1
    d874:      	lsr	w4, w4, #0
    d878:      	sxtw	x4, w4
    d87c:      	mov	x16, #0x1               ; =1
    d880:      	lsl	x4, x16, x4
    d884:      	lsr	w4, w4, #0
    d888:      	sxtw	x4, w4
    d88c:      	b	0xd78c <_stogir.vector-lanes.operands+0x63c>
    d890:      	brk	#0
    d894:      	b	0xd890 <_stogir.vector-lanes.operands+0x740>
    d898:      	cmp	x23, #0x0
    d89c:      	b.lt	0xd788 <_stogir.vector-lanes.operands+0x638>
    d8a0:      	cmp	x23, #0xd
    d8a4:      	b.gt	0xd788 <_stogir.vector-lanes.operands+0x638>
    d8a8:      	cmp	x23, #0x0
    d8ac:      	cset	w4, eq
    d8b0:      	uxtb	w16, w4
    d8b4:      	cmp	w16, wzr
    d8b8:      	cset	x4, eq
    d8bc:      	b	0xd78c <_stogir.vector-lanes.operands+0x63c>
    d8c0:      	uxtb	w7, w7
    d8c4:      	cmp	x7, #0x48
    d8c8:      	b.eq	0xd400 <_stogir.vector-lanes.operands+0x2b0>
    d8cc:      	cmp	x7, #0x46
    d8d0:      	b.eq	0xd400 <_stogir.vector-lanes.operands+0x2b0>
    d8d4:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d8d4:  ARM64_RELOC_PAGE21	l_stogir.491
    d8d8:      	ldr	x16, [x16]
		000000000000d8d8:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    d8dc:      	orr	x4, x16, xzr
    d8e0:      	mov	x28, x4
    d8e4:      	movz	x4, #0x0, lsl #48
    d8e8:      	b	0xd414 <_stogir.vector-lanes.operands+0x2c4>
    d8ec:      	brk	#0
    d8f0:      	b	0xd8ec <_stogir.vector-lanes.operands+0x79c>
    d8f4:      	brk	#0
    d8f8:      	b	0xd8f4 <_stogir.vector-lanes.operands+0x7a4>
    d8fc:      	mov	x1, x8
    d900:      	mov	w8, w9
    d904:      	b	0xd464 <_stogir.vector-lanes.operands+0x314>
    d908:      	str	x21, [sp, #0x98]
    d90c:      	str	x1, [sp, #0xa0]
    d910:      	str	x0, [sp, #0x80]
    d914:      	str	w3, [sp, #0xb0]
    d918:      	mov	w21, w6
    d91c:      	str	w22, [sp, #0x88]
    d920:      	mov	x22, x7
    d924:      	str	w8, [sp, #0xb8]
    d928:      	str	x28, [sp, #0x90]
    d92c:      	mov	w28, w5
    d930:      	str	x4, [sp, #0xa8]
    d934:      	b	0xd568 <_stogir.vector-lanes.operands+0x418>

000000000000d938 <_stogir.vector-comparison.operation?>:
    d938:      	sxtw	x0, w0
    d93c:      	cmp	x0, #0xe
    d940:      	b.lt	0xd954 <_stogir.vector-comparison.operation?+0x1c>
    d944:      	cmp	x0, #0x19
    d948:      	cset	w0, le
    d94c:      	ubfx	x0, x0, #0, #8
    d950:      	b	0xd958 <_stogir.vector-comparison.operation?+0x20>
    d954:      	movz	x0, #0x0, lsl #48
    d958:      	ret

000000000000d95c <_stogir.vector-comparison.operands>:
    d95c:      	sub	sp, sp, #0xe0
    d960:      	str	x29, [sp]
    d964:      	str	x30, [sp, #0x8]
    d968:      	mov	x29, sp
    d96c:      	str	x19, [sp, #0x90]
    d970:      	str	x20, [sp, #0x98]
    d974:      	str	x21, [sp, #0xa0]
    d978:      	str	x22, [sp, #0xa8]
    d97c:      	str	x23, [sp, #0xb0]
    d980:      	str	x24, [sp, #0xb8]
    d984:      	str	x25, [sp, #0xc0]
    d988:      	str	x26, [sp, #0xc8]
    d98c:      	str	x27, [sp, #0xd0]
    d990:      	str	x28, [sp, #0xd8]
    d994:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000d994:  ARM64_RELOC_PAGE21	l_stogir.492
    d998:      	ldr	x16, [x16]
		000000000000d998:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    d99c:      	orr	x19, x16, xzr
    d9a0:      	lsr	w4, w4, #0
    d9a4:      	mov	x20, x8
    d9a8:      	add	x8, sp, #0x10
    d9ac:      	mov	x21, x0
    d9b0:      	mov	w22, w1
    d9b4:      	mov	w1, w4
    d9b8:      	mov	w23, w2
    d9bc:      	mov	w24, w3
    d9c0:      	mov	w25, w5
    d9c4:      	bl	0xd9c4 <_stogir.vector-comparison.operands+0x68>
		000000000000d9c4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d9c8:      	add	x16, sp, #0x10
    d9cc:      	ldr	w0, [x16]
    d9d0:      	lsr	x16, x0, #0
    d9d4:      	cmp	x16, #0x1
    d9d8:      	b.eq	0xd9f4 <_stogir.vector-comparison.operands+0x98>
    d9dc:      	b.lo	0xd9e4 <_stogir.vector-comparison.operands+0x88>
    d9e0:      	b	0xd9f8 <_stogir.vector-comparison.operands+0x9c>
    d9e4:      	cmp	x16, #0x0
    d9e8:      	b.eq	0xd9f0 <_stogir.vector-comparison.operands+0x94>
    d9ec:      	b	0xd9f8 <_stogir.vector-comparison.operands+0x9c>
    d9f0:      	b	0xd9fc <_stogir.vector-comparison.operands+0xa0>
    d9f4:      	b	0xda4c <_stogir.vector-comparison.operands+0xf0>
    d9f8:      	b	0xdbfc <_stogir.vector-comparison.operands+0x2a0>
    d9fc:      	mov	x1, x19
    da00:      	mov	x0, #0x1                ; =1
    da04:      	mov	x2, #0x21               ; =33
    da08:      	str	x0, [x20]
    da0c:      	str	x1, [x20, #0x8]
    da10:      	str	x2, [x20, #0x10]
    da14:      	ldr	x19, [sp, #0x90]
    da18:      	ldr	x20, [sp, #0x98]
    da1c:      	ldr	x21, [sp, #0xa0]
    da20:      	ldr	x22, [sp, #0xa8]
    da24:      	ldr	x23, [sp, #0xb0]
    da28:      	ldr	x24, [sp, #0xb8]
    da2c:      	ldr	x25, [sp, #0xc0]
    da30:      	ldr	x26, [sp, #0xc8]
    da34:      	ldr	x27, [sp, #0xd0]
    da38:      	ldr	x28, [sp, #0xd8]
    da3c:      	ldr	x29, [sp]
    da40:      	ldr	x30, [sp, #0x8]
    da44:      	add	sp, sp, #0xe0
    da48:      	ret
    da4c:      	lsr	w25, w25, #0
    da50:      	add	x16, sp, #0x10
    da54:      	ldr	x26, [x16, #0x8]
    da58:      	add	x8, sp, #0x40
    da5c:      	mov	x0, x21
    da60:      	mov	w1, w25
    da64:      	bl	0xda64 <_stogir.vector-comparison.operands+0x108>
		000000000000da64:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    da68:      	add	x16, sp, #0x40
    da6c:      	ldr	w0, [x16]
    da70:      	lsr	x16, x0, #0
    da74:      	cmp	x16, #0x1
    da78:      	b.eq	0xda94 <_stogir.vector-comparison.operands+0x138>
    da7c:      	b.lo	0xda84 <_stogir.vector-comparison.operands+0x128>
    da80:      	b	0xda98 <_stogir.vector-comparison.operands+0x13c>
    da84:      	cmp	x16, #0x0
    da88:      	b.eq	0xda90 <_stogir.vector-comparison.operands+0x134>
    da8c:      	b	0xda98 <_stogir.vector-comparison.operands+0x13c>
    da90:      	b	0xda9c <_stogir.vector-comparison.operands+0x140>
    da94:      	b	0xdaac <_stogir.vector-comparison.operands+0x150>
    da98:      	b	0xdc04 <_stogir.vector-comparison.operands+0x2a8>
    da9c:      	mov	x1, x19
    daa0:      	mov	x0, #0x1                ; =1
    daa4:      	mov	x2, #0x21               ; =33
    daa8:      	b	0xda08 <_stogir.vector-comparison.operands+0xac>
    daac:      	sxtw	x19, w24
    dab0:      	cmp	x19, #0x4
    dab4:      	cset	w21, eq
    dab8:      	cmp	x19, #0x8
    dabc:      	cset	w25, eq
    dac0:      	add	x16, sp, #0x40
    dac4:      	ldr	x27, [x16, #0x8]
    dac8:      	uxtb	w16, w21
    dacc:      	cmp	w16, wzr
    dad0:      	b.ne	0xdafc <_stogir.vector-comparison.operands+0x1a0>
    dad4:      	uxtb	w16, w25
    dad8:      	cmp	w16, wzr
    dadc:      	b.ne	0xdafc <_stogir.vector-comparison.operands+0x1a0>
    dae0:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x45c>
		000000000000dae0:  ARM64_RELOC_PAGE21	l_stogir.493
    dae4:      	ldr	x16, [x16]
		000000000000dae4:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    dae8:      	orr	x0, x16, xzr
    daec:      	mov	x1, x0
    daf0:      	mov	x0, #0x1                ; =1
    daf4:      	mov	x2, #0x33               ; =51
    daf8:      	b	0xdaa8 <_stogir.vector-comparison.operands+0x14c>
    dafc:      	lsr	w22, w22, #0
    db00:      	lsr	w0, w26, #0
    db04:      	ubfx	x28, x0, #8, #8
    db08:      	orr	x0, x28, xzr
    db0c:      	lsr	w0, w0, #0
    db10:      	mov	w1, w0
    db14:      	fmov	s31, w0
    db18:      	mov	w0, w22
    db1c:      	fmov	w22, s31
    db20:      	bl	0xdb20 <_stogir.vector-comparison.operands+0x1c4>
		000000000000db20:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    db24:      	cmp	x0, #0x0
    db28:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    db2c:      	lsr	w0, w27, #0
    db30:      	ubfx	x0, x0, #8, #8
    db34:      	cmp	x28, x0
    db38:      	b.ne	0xdae0 <_stogir.vector-comparison.operands+0x184>
    db3c:      	uxtb	w26, w26
    db40:      	cmp	x26, #0x48
    db44:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    db48:      	cmp	x26, #0x46
    db4c:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    db50:      	uxtb	w27, w27
    db54:      	cmp	x27, #0x48
    db58:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    db5c:      	cmp	x27, #0x46
    db60:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    db64:      	sxtw	x26, w23
    db68:      	cmp	x26, #0xf
    db6c:      	cset	w27, gt
    db70:      	uxtb	w16, w27
    db74:      	cmp	w16, wzr
    db78:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    db7c:      	cmp	x26, #0x80
    db80:      	cset	w0, lt
    db84:      	uxtb	w16, w0
    db88:      	cmp	w16, wzr
    db8c:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    db90:      	and	x1, x26, #0xf
    db94:      	lsr	w1, w1, #0
    db98:      	sxtw	x1, w1
    db9c:      	cmp	x1, #0x1
    dba0:      	cset	w2, ge
    dba4:      	uxtb	w16, w2
    dba8:      	cmp	w16, wzr
    dbac:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    dbb0:      	cmp	x1, #0xd
    dbb4:      	cset	w3, le
    dbb8:      	uxtb	w16, w3
    dbbc:      	cmp	w16, wzr
    dbc0:      	b.eq	0xdae0 <_stogir.vector-comparison.operands+0x184>
    dbc4:      	lsr	w23, w23, #0
    dbc8:      	str	x1, [sp, #0x78]
    dbcc:      	str	x19, [sp, #0x70]
    dbd0:      	mov	w19, w0
    dbd4:      	mov	w0, w23
    dbd8:      	str	w22, [sp, #0x80]
    dbdc:      	mov	w22, w2
    dbe0:      	str	w23, [sp, #0x88]
    dbe4:      	mov	w23, w3
    dbe8:      	bl	0xdbe8 <_stogir.vector-comparison.operands+0x28c>
		000000000000dbe8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    dbec:      	cmp	x0, #0x0
    dbf0:      	b.eq	0xdc0c <_stogir.vector-comparison.operands+0x2b0>
    dbf4:      	ldr	x0, [sp, #0x78]
    dbf8:      	b	0xdc10 <_stogir.vector-comparison.operands+0x2b4>
    dbfc:      	brk	#0
    dc00:      	b	0xdbfc <_stogir.vector-comparison.operands+0x2a0>
    dc04:      	brk	#0
    dc08:      	b	0xdc04 <_stogir.vector-comparison.operands+0x2a8>
    dc0c:      	movn	x0, #0x0, lsl #48
    dc10:      	lsr	w0, w0, #0
    dc14:      	sxtw	x0, w0
    dc18:      	cmp	x0, #0x1
    dc1c:      	b.lt	0xdae0 <_stogir.vector-comparison.operands+0x184>
    dc20:      	cmp	x0, #0xb
    dc24:      	b.gt	0xdae0 <_stogir.vector-comparison.operands+0x184>
    dc28:      	uxtb	w16, w27
    dc2c:      	cmp	w16, wzr
    dc30:      	b.eq	0xdcb4 <_stogir.vector-comparison.operands+0x358>
    dc34:      	uxtb	w16, w19
    dc38:      	cmp	w16, wzr
    dc3c:      	b.eq	0xdcb4 <_stogir.vector-comparison.operands+0x358>
    dc40:      	uxtb	w16, w22
    dc44:      	cmp	w16, wzr
    dc48:      	b.eq	0xdcb4 <_stogir.vector-comparison.operands+0x358>
    dc4c:      	uxtb	w16, w23
    dc50:      	cmp	w16, wzr
    dc54:      	b.eq	0xdcb4 <_stogir.vector-comparison.operands+0x358>
    dc58:      	ubfx	x0, x26, #4, #32
    dc5c:      	sxtw	x0, w0
    dc60:      	sub	x0, x0, #0x1
    dc64:      	lsr	w0, w0, #0
    dc68:      	sxtw	x0, w0
    dc6c:      	mov	x16, #0x1               ; =1
    dc70:      	lsl	x0, x16, x0
    dc74:      	lsr	w0, w0, #0
    dc78:      	sxtw	x0, w0
    dc7c:      	b	0xdce0 <_stogir.vector-comparison.operands+0x384>
    dc80:      	movn	x1, #0x0, lsl #48
    dc84:      	lsr	w0, w0, #0
    dc88:      	sxtw	x0, w0
    dc8c:      	lsr	w1, w1, #0
    dc90:      	sxtw	x1, w1
    dc94:      	cmp	x0, x1
    dc98:      	b.ne	0xdae0 <_stogir.vector-comparison.operands+0x184>
    dc9c:      	ldr	w0, [sp, #0x88]
    dca0:      	bl	0xdca0 <_stogir.vector-comparison.operands+0x344>
		000000000000dca0:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    dca4:      	cmp	x0, #0x0
    dca8:      	b.eq	0xdd98 <_stogir.vector-comparison.operands+0x43c>
    dcac:      	ldr	x0, [sp, #0x78]
    dcb0:      	b	0xdd9c <_stogir.vector-comparison.operands+0x440>
    dcb4:      	cmp	x26, #0x0
    dcb8:      	b.lt	0xdcdc <_stogir.vector-comparison.operands+0x380>
    dcbc:      	cmp	x26, #0xd
    dcc0:      	b.gt	0xdcdc <_stogir.vector-comparison.operands+0x380>
    dcc4:      	cmp	x26, #0x0
    dcc8:      	cset	w0, eq
    dccc:      	uxtb	w16, w0
    dcd0:      	cmp	w16, wzr
    dcd4:      	cset	x0, eq
    dcd8:      	b	0xdce0 <_stogir.vector-comparison.operands+0x384>
    dcdc:      	movn	x0, #0x0, lsl #48
    dce0:      	and	x1, x28, #0xf
    dce4:      	lsr	w1, w1, #0
    dce8:      	sxtw	x19, w1
    dcec:      	cmp	x28, #0xf
    dcf0:      	b.le	0xdd34 <_stogir.vector-comparison.operands+0x3d8>
    dcf4:      	cmp	x28, #0x80
    dcf8:      	b.ge	0xdd34 <_stogir.vector-comparison.operands+0x3d8>
    dcfc:      	cmp	x19, #0x1
    dd00:      	b.lt	0xdd34 <_stogir.vector-comparison.operands+0x3d8>
    dd04:      	cmp	x19, #0xd
    dd08:      	b.gt	0xdd34 <_stogir.vector-comparison.operands+0x3d8>
    dd0c:      	ubfx	x1, x28, #4, #32
    dd10:      	sxtw	x1, w1
    dd14:      	sub	x1, x1, #0x1
    dd18:      	lsr	w1, w1, #0
    dd1c:      	sxtw	x1, w1
    dd20:      	mov	x16, #0x1               ; =1
    dd24:      	lsl	x1, x16, x1
    dd28:      	lsr	w1, w1, #0
    dd2c:      	sxtw	x1, w1
    dd30:      	b	0xdc84 <_stogir.vector-comparison.operands+0x328>
    dd34:      	cmp	x28, #0xd
    dd38:      	b.gt	0xdc80 <_stogir.vector-comparison.operands+0x324>
    dd3c:      	cmp	x28, #0x0
    dd40:      	cset	w1, eq
    dd44:      	uxtb	w16, w1
    dd48:      	cmp	w16, wzr
    dd4c:      	cset	x1, eq
    dd50:      	b	0xdc84 <_stogir.vector-comparison.operands+0x328>
    dd54:      	movn	x0, #0x0, lsl #48
    dd58:      	lsr	w24, w24, #0
    dd5c:      	lsr	w21, w21, #0
    dd60:      	sxtw	x21, w21
    dd64:      	lsr	w0, w0, #0
    dd68:      	lsr	w0, w0, #0
    dd6c:      	mov	w1, w24
    dd70:      	bl	0xdd70 <_stogir.vector-comparison.operands+0x414>
		000000000000dd70:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    dd74:      	lsr	w0, w0, #0
    dd78:      	sxtw	x0, w0
    dd7c:      	cmp	x21, x0
    dd80:      	b.ne	0xdae0 <_stogir.vector-comparison.operands+0x184>
    dd84:      	and	x0, x28, #0xffffffff
    dd88:      	mov	x1, x0
    dd8c:      	movz	x0, #0x0, lsl #48
    dd90:      	movz	x2, #0x0, lsl #48
    dd94:      	b	0xdaf8 <_stogir.vector-comparison.operands+0x19c>
    dd98:      	movn	x0, #0x0, lsl #48
    dd9c:      	uxtb	w16, w21
    dda0:      	cmp	w16, wzr
    dda4:      	b.ne	0xdddc <_stogir.vector-comparison.operands+0x480>
    dda8:      	uxtb	w16, w25
    ddac:      	cmp	w16, wzr
    ddb0:      	b.ne	0xdddc <_stogir.vector-comparison.operands+0x480>
    ddb4:      	movn	x21, #0x0, lsl #48
    ddb8:      	b	0xddc4 <_stogir.vector-comparison.operands+0x468>
    ddbc:      	mov	x0, #0x1                ; =1
    ddc0:      	mov	x21, x0
    ddc4:      	ldr	w0, [sp, #0x80]
    ddc8:      	bl	0xddc8 <_stogir.vector-comparison.operands+0x46c>
		000000000000ddc8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    ddcc:      	cmp	x0, #0x0
    ddd0:      	b.eq	0xdd54 <_stogir.vector-comparison.operands+0x3f8>
    ddd4:      	mov	x0, x19
    ddd8:      	b	0xdd58 <_stogir.vector-comparison.operands+0x3fc>
    dddc:      	lsr	w0, w0, #0
    dde0:      	sxtw	x0, w0
    dde4:      	cmp	x0, #0x0
    dde8:      	b.ne	0xddf4 <_stogir.vector-comparison.operands+0x498>
    ddec:      	movz	x0, #0x0, lsl #48
    ddf0:      	b	0xddc0 <_stogir.vector-comparison.operands+0x464>
    ddf4:      	cmp	x0, #0x1
    ddf8:      	b.eq	0xddbc <_stogir.vector-comparison.operands+0x460>
    ddfc:      	cmp	x0, #0x2
    de00:      	b.eq	0xddbc <_stogir.vector-comparison.operands+0x460>
    de04:      	cmp	x0, #0x7
    de08:      	b.eq	0xddbc <_stogir.vector-comparison.operands+0x460>
    de0c:      	cmp	x0, #0x8
    de10:      	b.eq	0xddbc <_stogir.vector-comparison.operands+0x460>
    de14:      	cmp	x0, #0x3
    de18:      	b.eq	0xde64 <_stogir.vector-comparison.operands+0x508>
    de1c:      	cmp	x0, #0x9
    de20:      	b.eq	0xde64 <_stogir.vector-comparison.operands+0x508>
    de24:      	cmp	x0, #0x4
    de28:      	b.eq	0xde6c <_stogir.vector-comparison.operands+0x510>
    de2c:      	cmp	x0, #0xa
    de30:      	b.eq	0xde6c <_stogir.vector-comparison.operands+0x510>
    de34:      	cmp	x0, #0xd
    de38:      	b.eq	0xde6c <_stogir.vector-comparison.operands+0x510>
    de3c:      	cmp	x0, #0x5
    de40:      	b.eq	0xde74 <_stogir.vector-comparison.operands+0x518>
    de44:      	cmp	x0, #0xb
    de48:      	b.eq	0xde74 <_stogir.vector-comparison.operands+0x518>
    de4c:      	cmp	x0, #0xc
    de50:      	b.eq	0xde74 <_stogir.vector-comparison.operands+0x518>
    de54:      	cmp	x0, #0x6
    de58:      	b.ne	0xde7c <_stogir.vector-comparison.operands+0x520>
    de5c:      	ldr	x0, [sp, #0x70]
    de60:      	b	0xde80 <_stogir.vector-comparison.operands+0x524>
    de64:      	mov	x0, #0x2                ; =2
    de68:      	b	0xddc0 <_stogir.vector-comparison.operands+0x464>
    de6c:      	mov	x0, #0x4                ; =4
    de70:      	b	0xde68 <_stogir.vector-comparison.operands+0x50c>
    de74:      	mov	x0, #0x8                ; =8
    de78:      	b	0xde70 <_stogir.vector-comparison.operands+0x514>
    de7c:      	movn	x0, #0x0, lsl #48
    de80:      	b	0xde78 <_stogir.vector-comparison.operands+0x51c>

000000000000de84 <_stogir.vector-arithmetic.operation?>:
    de84:      	sxtw	x0, w0
    de88:      	cmp	x0, #0x1f
    de8c:      	b.eq	0xdee8 <_stogir.vector-arithmetic.operation?+0x64>
    de90:      	cmp	x0, #0x20
    de94:      	b.eq	0xdee8 <_stogir.vector-arithmetic.operation?+0x64>
    de98:      	cmp	x0, #0x2d
    de9c:      	b.eq	0xdee8 <_stogir.vector-arithmetic.operation?+0x64>
    dea0:      	cmp	x0, #0x36
    dea4:      	b.eq	0xdee8 <_stogir.vector-arithmetic.operation?+0x64>
    dea8:      	cmp	x0, #0x37
    deac:      	b.eq	0xdee8 <_stogir.vector-arithmetic.operation?+0x64>
    deb0:      	cmp	x0, #0x38
    deb4:      	b.eq	0xdee8 <_stogir.vector-arithmetic.operation?+0x64>
    deb8:      	cmp	x0, #0x39
    debc:      	b.eq	0xdee8 <_stogir.vector-arithmetic.operation?+0x64>
    dec0:      	cmp	x0, #0x3a
    dec4:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x6c>
    dec8:      	cmp	x0, #0x3b
    decc:      	b.eq	0xdef0 <_stogir.vector-arithmetic.operation?+0x6c>
    ded0:      	cmp	x0, #0x31
    ded4:      	b.lt	0xdf08 <_stogir.vector-arithmetic.operation?+0x84>
    ded8:      	cmp	x0, #0x35
    dedc:      	b.gt	0xdf08 <_stogir.vector-arithmetic.operation?+0x84>
    dee0:      	mov	x0, #0x1                ; =1
    dee4:      	b	0xdf04 <_stogir.vector-arithmetic.operation?+0x80>
    dee8:      	mov	x0, #0x1                ; =1
    deec:      	ret
    def0:      	mov	x0, #0x1                ; =1
    def4:      	b	0xdeec <_stogir.vector-arithmetic.operation?+0x68>
    def8:      	cmp	x0, #0x30
    defc:      	cset	w0, eq
    df00:      	ubfx	x0, x0, #0, #8
    df04:      	b	0xdef4 <_stogir.vector-arithmetic.operation?+0x70>
    df08:      	cmp	x0, #0x1a
    df0c:      	b.ne	0xdf18 <_stogir.vector-arithmetic.operation?+0x94>
    df10:      	mov	x0, #0x1                ; =1
    df14:      	b	0xdf04 <_stogir.vector-arithmetic.operation?+0x80>
    df18:      	cmp	x0, #0x1b
    df1c:      	b.ne	0xdf28 <_stogir.vector-arithmetic.operation?+0xa4>
    df20:      	mov	x0, #0x1                ; =1
    df24:      	b	0xdf04 <_stogir.vector-arithmetic.operation?+0x80>
    df28:      	cmp	x0, #0x1c
    df2c:      	b.ne	0xdf38 <_stogir.vector-arithmetic.operation?+0xb4>
    df30:      	mov	x0, #0x1                ; =1
    df34:      	b	0xdf04 <_stogir.vector-arithmetic.operation?+0x80>
    df38:      	cmp	x0, #0x1d
    df3c:      	b.ne	0xdf48 <_stogir.vector-arithmetic.operation?+0xc4>
    df40:      	mov	x0, #0x1                ; =1
    df44:      	b	0xdf04 <_stogir.vector-arithmetic.operation?+0x80>
    df48:      	cmp	x0, #0x1e
    df4c:      	b.ne	0xdf58 <_stogir.vector-arithmetic.operation?+0xd4>
    df50:      	mov	x0, #0x1                ; =1
    df54:      	b	0xdf04 <_stogir.vector-arithmetic.operation?+0x80>
    df58:      	cmp	x0, #0x2e
    df5c:      	b.ne	0xdf68 <_stogir.vector-arithmetic.operation?+0xe4>
    df60:      	mov	x0, #0x1                ; =1
    df64:      	b	0xdf04 <_stogir.vector-arithmetic.operation?+0x80>
    df68:      	cmp	x0, #0x2f
    df6c:      	b.ne	0xdef8 <_stogir.vector-arithmetic.operation?+0x74>
    df70:      	mov	x0, #0x1                ; =1
    df74:      	b	0xdf04 <_stogir.vector-arithmetic.operation?+0x80>

000000000000df78 <_stogir.vector-arithmetic.unary?>:
    df78:      	sxtw	x0, w0
    df7c:      	cmp	x0, #0x1f
    df80:      	b.ne	0xdf9c <_stogir.vector-arithmetic.unary?+0x24>
    df84:      	mov	x0, #0x1                ; =1
    df88:      	b	0xdf98 <_stogir.vector-arithmetic.unary?+0x20>
    df8c:      	cmp	x0, #0x39
    df90:      	cset	w0, eq
    df94:      	ubfx	x0, x0, #0, #8
    df98:      	ret
    df9c:      	cmp	x0, #0x20
    dfa0:      	b.ne	0xdfac <_stogir.vector-arithmetic.unary?+0x34>
    dfa4:      	mov	x0, #0x1                ; =1
    dfa8:      	b	0xdf98 <_stogir.vector-arithmetic.unary?+0x20>
    dfac:      	cmp	x0, #0x2d
    dfb0:      	b.ne	0xdfbc <_stogir.vector-arithmetic.unary?+0x44>
    dfb4:      	mov	x0, #0x1                ; =1
    dfb8:      	b	0xdf98 <_stogir.vector-arithmetic.unary?+0x20>
    dfbc:      	cmp	x0, #0x36
    dfc0:      	b.ne	0xdfcc <_stogir.vector-arithmetic.unary?+0x54>
    dfc4:      	mov	x0, #0x1                ; =1
    dfc8:      	b	0xdf98 <_stogir.vector-arithmetic.unary?+0x20>
    dfcc:      	cmp	x0, #0x37
    dfd0:      	b.ne	0xdfdc <_stogir.vector-arithmetic.unary?+0x64>
    dfd4:      	mov	x0, #0x1                ; =1
    dfd8:      	b	0xdf98 <_stogir.vector-arithmetic.unary?+0x20>
    dfdc:      	cmp	x0, #0x38
    dfe0:      	b.ne	0xdf8c <_stogir.vector-arithmetic.unary?+0x14>
    dfe4:      	mov	x0, #0x1                ; =1
    dfe8:      	b	0xdf98 <_stogir.vector-arithmetic.unary?+0x20>

000000000000dfec <_stogir.vector-arithmetic.operands>:
    dfec:      	sub	sp, sp, #0x80
    dff0:      	str	x29, [sp]
    dff4:      	str	x30, [sp, #0x8]
    dff8:      	mov	x29, sp
    dffc:      	str	x19, [sp, #0x30]
    e000:      	str	x20, [sp, #0x38]
    e004:      	str	x21, [sp, #0x40]
    e008:      	str	x22, [sp, #0x48]
    e00c:      	str	x23, [sp, #0x50]
    e010:      	str	x24, [sp, #0x58]
    e014:      	str	x25, [sp, #0x60]
    e018:      	str	x26, [sp, #0x68]
    e01c:      	str	x27, [sp, #0x70]
    e020:      	str	x28, [sp, #0x78]
    e024:      	lsr	w1, w1, #0
    e028:      	lsr	w2, w2, #0
    e02c:      	mov	x19, x8
    e030:      	mov	x20, x0
    e034:      	mov	w0, w1
    e038:      	mov	w21, w1
    e03c:      	mov	w1, w2
    e040:      	mov	w22, w2
    e044:      	mov	w23, w3
    e048:      	mov	w24, w4
    e04c:      	mov	w25, w5
    e050:      	bl	0xe050 <_stogir.vector-arithmetic.operands+0x64>
		000000000000e050:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    e054:      	cmp	x0, #0x0
    e058:      	b.eq	0xe070 <_stogir.vector-arithmetic.operands+0x84>
    e05c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e05c:  ARM64_RELOC_PAGE21	l_stogir.494
    e060:      	ldr	x16, [x16]
		000000000000e060:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    e064:      	orr	x0, x16, xzr
    e068:      	movz	x1, #0x0, lsl #48
    e06c:      	b	0xe080 <_stogir.vector-arithmetic.operands+0x94>
    e070:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e070:  ARM64_RELOC_PAGE21	l_stogir.495
    e074:      	ldr	x16, [x16]
		000000000000e074:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    e078:      	orr	x0, x16, xzr
    e07c:      	mov	x1, #0x37               ; =55
    e080:      	sxtw	x21, w21
    e084:      	sxtw	x22, w22
    e088:      	sxtw	x23, w23
    e08c:      	sxtw	x24, w24
    e090:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e090:  ARM64_RELOC_PAGE21	l_stogir.496
    e094:      	ldr	x16, [x16]
		000000000000e094:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    e098:      	orr	x2, x16, xzr
    e09c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e09c:  ARM64_RELOC_PAGE21	l_stogir.497
    e0a0:      	ldr	x16, [x16]
		000000000000e0a0:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    e0a4:      	orr	x3, x16, xzr
    e0a8:      	add	x4, x20, #0x78
    e0ac:      	add	x5, x20, #0x28
    e0b0:      	add	x6, x20, #0x50
    e0b4:      	cmp	x21, #0x31
    e0b8:      	cset	w7, ge
    e0bc:      	cmp	x21, #0x35
    e0c0:      	cset	w8, le
    e0c4:      	cmp	x21, #0x1f
    e0c8:      	cset	w9, eq
    e0cc:      	cmp	x21, #0x20
    e0d0:      	cset	w10, eq
    e0d4:      	cmp	x21, #0x2d
    e0d8:      	cset	w11, eq
    e0dc:      	cmp	x21, #0x36
    e0e0:      	cset	w12, eq
    e0e4:      	cmp	x21, #0x37
    e0e8:      	cset	w13, eq
    e0ec:      	cmp	x21, #0x38
    e0f0:      	cset	w14, eq
    e0f4:      	cmp	x21, #0x39
    e0f8:      	cset	w15, eq
    e0fc:      	mov	x26, x1
    e100:      	mov	x1, x0
    e104:      	movz	x0, #0x0, lsl #48
    e108:      	b	0xe1e8 <_stogir.vector-arithmetic.operands+0x1fc>
    e10c:      	movz	x2, #0x0, lsl #48
    e110:      	b	0xe120 <_stogir.vector-arithmetic.operands+0x134>
    e114:      	movz	x2, #0x0, lsl #48
    e118:      	b	0xe128 <_stogir.vector-arithmetic.operands+0x13c>
    e11c:      	movz	x2, #0x0, lsl #48
    e120:      	b	0xe138 <_stogir.vector-arithmetic.operands+0x14c>
    e124:      	movz	x2, #0x0, lsl #48
    e128:      	str	x4, [sp, #0x20]
    e12c:      	str	x5, [sp, #0x28]
    e130:      	b	0xe138 <_stogir.vector-arithmetic.operands+0x14c>
    e134:      	movz	x2, #0x0, lsl #48
    e138:      	cmp	x2, #0x0
    e13c:      	b.eq	0xe17c <_stogir.vector-arithmetic.operands+0x190>
    e140:      	uxtb	w16, w28
    e144:      	cmp	w16, wzr
    e148:      	b.eq	0xe160 <_stogir.vector-arithmetic.operands+0x174>
    e14c:      	lsl	x2, x1, #4
    e150:      	ldr	x2, [x20]
    e154:      	add	x1, x2, x1, lsl #4
    e158:      	ldr	x1, [x1]
    e15c:      	b	0xe170 <_stogir.vector-arithmetic.operands+0x184>
    e160:      	lsl	x1, x3, #4
    e164:      	ldr	x1, [x20, #0x28]
    e168:      	add	x1, x1, x3, lsl #4
    e16c:      	ldr	x1, [x1]
    e170:      	mov	x2, x1
    e174:      	mov	x1, #0x1                ; =1
    e178:      	b	0xe184 <_stogir.vector-arithmetic.operands+0x198>
    e17c:      	movz	x1, #0x0, lsl #48
    e180:      	movz	x2, #0x0, lsl #48
    e184:      	lsr	w1, w1, #0
    e188:      	lsr	x16, x1, #0
    e18c:      	cmp	x16, #0x1
    e190:      	b.eq	0xe1ac <_stogir.vector-arithmetic.operands+0x1c0>
    e194:      	b.lo	0xe19c <_stogir.vector-arithmetic.operands+0x1b0>
    e198:      	b	0xe1b0 <_stogir.vector-arithmetic.operands+0x1c4>
    e19c:      	cmp	x16, #0x0
    e1a0:      	b.eq	0xe1a8 <_stogir.vector-arithmetic.operands+0x1bc>
    e1a4:      	b	0xe1b0 <_stogir.vector-arithmetic.operands+0x1c4>
    e1a8:      	b	0xe1b4 <_stogir.vector-arithmetic.operands+0x1c8>
    e1ac:      	b	0xe32c <_stogir.vector-arithmetic.operands+0x340>
    e1b0:      	b	0xe578 <_stogir.vector-arithmetic.operands+0x58c>
    e1b4:      	ldr	x1, [sp, #0x10]
    e1b8:      	mov	x2, #0x21               ; =33
    e1bc:      	b	0xe1c8 <_stogir.vector-arithmetic.operands+0x1dc>
    e1c0:      	ldr	x1, [sp, #0x18]
    e1c4:      	mov	x2, #0x32               ; =50
    e1c8:      	add	x0, x0, #0x1
    e1cc:      	lsr	w0, w0, #0
    e1d0:      	sxtw	x0, w0
    e1d4:      	ldr	x3, [sp, #0x18]
    e1d8:      	ldr	x4, [sp, #0x20]
    e1dc:      	ldr	x5, [sp, #0x28]
    e1e0:      	mov	x26, x2
    e1e4:      	ldr	x2, [sp, #0x10]
    e1e8:      	uxtb	w16, w9
    e1ec:      	cmp	w16, wzr
    e1f0:      	b.ne	0xe24c <_stogir.vector-arithmetic.operands+0x260>
    e1f4:      	uxtb	w16, w10
    e1f8:      	cmp	w16, wzr
    e1fc:      	b.ne	0xe24c <_stogir.vector-arithmetic.operands+0x260>
    e200:      	uxtb	w16, w11
    e204:      	cmp	w16, wzr
    e208:      	b.ne	0xe24c <_stogir.vector-arithmetic.operands+0x260>
    e20c:      	uxtb	w16, w12
    e210:      	cmp	w16, wzr
    e214:      	b.ne	0xe24c <_stogir.vector-arithmetic.operands+0x260>
    e218:      	uxtb	w16, w13
    e21c:      	cmp	w16, wzr
    e220:      	b.ne	0xe24c <_stogir.vector-arithmetic.operands+0x260>
    e224:      	uxtb	w16, w14
    e228:      	cmp	w16, wzr
    e22c:      	b.ne	0xe24c <_stogir.vector-arithmetic.operands+0x260>
    e230:      	uxtb	w16, w15
    e234:      	cmp	w16, wzr
    e238:      	b.ne	0xe24c <_stogir.vector-arithmetic.operands+0x260>
    e23c:      	mov	x27, x26
    e240:      	mov	x26, x1
    e244:      	mov	x1, #0x2                ; =2
    e248:      	b	0xe258 <_stogir.vector-arithmetic.operands+0x26c>
    e24c:      	mov	x27, x26
    e250:      	mov	x26, x1
    e254:      	mov	x1, #0x1                ; =1
    e258:      	cmp	x0, x1
    e25c:      	b.ge	0xe38c <_stogir.vector-arithmetic.operands+0x3a0>
    e260:      	cmp	x0, #0x0
    e264:      	b.ne	0xe270 <_stogir.vector-arithmetic.operands+0x284>
    e268:      	mov	x1, x23
    e26c:      	b	0xe274 <_stogir.vector-arithmetic.operands+0x288>
    e270:      	mov	x1, x24
    e274:      	lsr	w1, w1, #0
    e278:      	sxtw	x1, w1
    e27c:      	cmp	x1, #0x0
    e280:      	cset	w28, gt
    e284:      	str	x2, [sp, #0x10]
    e288:      	movz	x16, #0x0, lsl #48
    e28c:      	sub	x2, x16, x1
    e290:      	str	x3, [sp, #0x18]
    e294:      	sub	x3, x2, #0x1
    e298:      	uxtb	w16, w28
    e29c:      	cmp	w16, wzr
    e2a0:      	b.eq	0xe2e0 <_stogir.vector-arithmetic.operands+0x2f4>
    e2a4:      	ldr	x2, [x20, #0x8]
    e2a8:      	cmp	x1, x2
    e2ac:      	b.ge	0xe124 <_stogir.vector-arithmetic.operands+0x138>
    e2b0:      	ldr	x2, [x4, #0x8]
    e2b4:      	cmp	x1, x2
    e2b8:      	b.ge	0xe114 <_stogir.vector-arithmetic.operands+0x128>
    e2bc:      	lsl	x2, x1, #2
    e2c0:      	ldr	x2, [x20, #0x78]
    e2c4:      	add	x2, x2, x1, lsl #2
    e2c8:      	ldr	w2, [x2]
    e2cc:      	sxtw	x2, w2
    e2d0:      	cmp	x2, #0x0
    e2d4:      	cset	w2, ge
    e2d8:      	ubfx	x2, x2, #0, #8
    e2dc:      	b	0xe118 <_stogir.vector-arithmetic.operands+0x12c>
    e2e0:      	cmp	x1, #0x0
    e2e4:      	b.ge	0xe674 <_stogir.vector-arithmetic.operands+0x688>
    e2e8:      	str	x4, [sp, #0x20]
    e2ec:      	ldr	x4, [x5, #0x8]
    e2f0:      	str	x5, [sp, #0x28]
    e2f4:      	ldr	x5, [x6, #0x8]
    e2f8:      	cmp	x4, x5
    e2fc:      	b.ne	0xe11c <_stogir.vector-arithmetic.operands+0x130>
    e300:      	cmp	x2, x4
    e304:      	b.gt	0xe10c <_stogir.vector-arithmetic.operands+0x120>
    e308:      	lsl	x2, x3, #2
    e30c:      	ldr	x2, [x20, #0x50]
    e310:      	add	x2, x2, x3, lsl #2
    e314:      	ldr	w2, [x2]
    e318:      	sxtw	x2, w2
    e31c:      	cmp	x2, #0x0
    e320:      	cset	w2, gt
    e324:      	ubfx	x2, x2, #0, #8
    e328:      	b	0xe110 <_stogir.vector-arithmetic.operands+0x124>
    e32c:      	lsr	w1, w2, #0
    e330:      	ubfx	x1, x1, #8, #8
    e334:      	cmp	x1, x22
    e338:      	b.eq	0xe36c <_stogir.vector-arithmetic.operands+0x380>
    e33c:      	cmp	x0, #0x1
    e340:      	b.ne	0xe1c0 <_stogir.vector-arithmetic.operands+0x1d4>
    e344:      	uxtb	w16, w7
    e348:      	cmp	w16, wzr
    e34c:      	b.eq	0xe1c0 <_stogir.vector-arithmetic.operands+0x1d4>
    e350:      	uxtb	w16, w8
    e354:      	cmp	w16, wzr
    e358:      	b.eq	0xe1c0 <_stogir.vector-arithmetic.operands+0x1d4>
    e35c:      	cmp	x1, #0x1
    e360:      	b.lt	0xe1c0 <_stogir.vector-arithmetic.operands+0x1d4>
    e364:      	cmp	x1, #0xb
    e368:      	b.gt	0xe1c0 <_stogir.vector-arithmetic.operands+0x1d4>
    e36c:      	uxtb	w2, w2
    e370:      	cmp	x2, #0x48
    e374:      	b.eq	0xe1c0 <_stogir.vector-arithmetic.operands+0x1d4>
    e378:      	cmp	x2, #0x46
    e37c:      	b.eq	0xe1c0 <_stogir.vector-arithmetic.operands+0x1d4>
    e380:      	mov	x1, x26
    e384:      	mov	x2, x27
    e388:      	b	0xe1c8 <_stogir.vector-arithmetic.operands+0x1dc>
    e38c:      	sxtw	x25, w25
    e390:      	cmp	x25, #0x0
    e394:      	b.ne	0xe3a8 <_stogir.vector-arithmetic.operands+0x3bc>
    e398:      	mov	x1, x26
    e39c:      	mov	x2, x27
    e3a0:      	movz	x0, #0x0, lsl #48
    e3a4:      	b	0xe3b4 <_stogir.vector-arithmetic.operands+0x3c8>
    e3a8:      	mov	x1, x26
    e3ac:      	mov	x2, x27
    e3b0:      	mov	x0, #0x1                ; =1
    e3b4:      	cmp	x0, #0x0
    e3b8:      	b.eq	0xe3cc <_stogir.vector-arithmetic.operands+0x3e0>
    e3bc:      	cmp	x21, #0x1d
    e3c0:      	b.ne	0xe4c0 <_stogir.vector-arithmetic.operands+0x4d4>
    e3c4:      	mov	x0, #0x1                ; =1
    e3c8:      	b	0xe4cc <_stogir.vector-arithmetic.operands+0x4e0>
    e3cc:      	mov	x0, x1
    e3d0:      	mov	x1, x2
    e3d4:      	cmp	x1, #0x0
    e3d8:      	b.ne	0xe3f0 <_stogir.vector-arithmetic.operands+0x404>
    e3dc:      	and	x0, x22, #0xffffffff
    e3e0:      	mov	x1, x0
    e3e4:      	movz	x0, #0x0, lsl #48
    e3e8:      	movz	x2, #0x0, lsl #48
    e3ec:      	b	0xe3fc <_stogir.vector-arithmetic.operands+0x410>
    e3f0:      	mov	x2, x1
    e3f4:      	mov	x1, x0
    e3f8:      	mov	x0, #0x1                ; =1
    e3fc:      	str	x0, [x19]
    e400:      	str	x1, [x19, #0x8]
    e404:      	str	x2, [x19, #0x10]
    e408:      	ldr	x19, [sp, #0x30]
    e40c:      	ldr	x20, [sp, #0x38]
    e410:      	ldr	x21, [sp, #0x40]
    e414:      	ldr	x22, [sp, #0x48]
    e418:      	ldr	x23, [sp, #0x50]
    e41c:      	ldr	x24, [sp, #0x58]
    e420:      	ldr	x25, [sp, #0x60]
    e424:      	ldr	x26, [sp, #0x68]
    e428:      	ldr	x27, [sp, #0x70]
    e42c:      	ldr	x28, [sp, #0x78]
    e430:      	ldr	x29, [sp]
    e434:      	ldr	x30, [sp, #0x8]
    e438:      	add	sp, sp, #0x80
    e43c:      	ret
    e440:      	mov	x0, #0x1                ; =1
    e444:      	cmp	x0, #0x0
    e448:      	b.eq	0xe460 <_stogir.vector-arithmetic.operands+0x474>
    e44c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e44c:  ARM64_RELOC_PAGE21	l_stogir.498
    e450:      	ldr	x16, [x16]
		000000000000e450:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    e454:      	orr	x0, x16, xzr
    e458:      	mov	x1, #0x23               ; =35
    e45c:      	b	0xe3d4 <_stogir.vector-arithmetic.operands+0x3e8>
    e460:      	cmp	x25, #0x0
    e464:      	cset	w0, gt
    e468:      	movz	x16, #0x0, lsl #48
    e46c:      	sub	x3, x16, x25
    e470:      	sub	x4, x3, #0x1
    e474:      	uxtb	w16, w0
    e478:      	cmp	w16, wzr
    e47c:      	b.eq	0xe52c <_stogir.vector-arithmetic.operands+0x540>
    e480:      	ldr	x3, [x20, #0x8]
    e484:      	cmp	x25, x3
    e488:      	b.ge	0xe580 <_stogir.vector-arithmetic.operands+0x594>
    e48c:      	add	x3, x20, #0x78
    e490:      	ldr	x3, [x3, #0x8]
    e494:      	cmp	x25, x3
    e498:      	b.ge	0xe650 <_stogir.vector-arithmetic.operands+0x664>
    e49c:      	lsl	x3, x25, #2
    e4a0:      	ldr	x3, [x20, #0x78]
    e4a4:      	add	x3, x3, x25, lsl #2
    e4a8:      	ldr	w3, [x3]
    e4ac:      	sxtw	x3, w3
    e4b0:      	cmp	x3, #0x0
    e4b4:      	cset	w3, ge
    e4b8:      	ubfx	x3, x3, #0, #8
    e4bc:      	b	0xe654 <_stogir.vector-arithmetic.operands+0x668>
    e4c0:      	cmp	x21, #0x1e
    e4c4:      	cset	w0, eq
    e4c8:      	ubfx	x0, x0, #0, #8
    e4cc:      	cmp	x0, #0x0
    e4d0:      	b.eq	0xe440 <_stogir.vector-arithmetic.operands+0x454>
    e4d4:      	movz	x0, #0x0, lsl #48
    e4d8:      	b	0xe444 <_stogir.vector-arithmetic.operands+0x458>
    e4dc:      	movz	x0, #0x0, lsl #48
    e4e0:      	uxtb	w0, w0
    e4e4:      	and	x0, x0, #0x2
    e4e8:      	uxtb	w0, w0
    e4ec:      	cmp	x0, #0x0
    e4f0:      	cset	w0, eq
    e4f4:      	uxtb	w16, w0
    e4f8:      	cmp	w16, wzr
    e4fc:      	cset	x0, eq
    e500:      	cmp	x0, #0x0
    e504:      	b.ne	0xe658 <_stogir.vector-arithmetic.operands+0x66c>
    e508:      	cmp	x3, #0x65
    e50c:      	b.eq	0xe658 <_stogir.vector-arithmetic.operands+0x66c>
    e510:      	cmp	x3, #0x66
    e514:      	b.eq	0xe658 <_stogir.vector-arithmetic.operands+0x66c>
    e518:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e518:  ARM64_RELOC_PAGE21	l_stogir.499
    e51c:      	ldr	x16, [x16]
		000000000000e51c:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    e520:      	orr	x0, x16, xzr
    e524:      	mov	x1, #0x34               ; =52
    e528:      	b	0xe45c <_stogir.vector-arithmetic.operands+0x470>
    e52c:      	cmp	x25, #0x0
    e530:      	b.ge	0xe588 <_stogir.vector-arithmetic.operands+0x59c>
    e534:      	add	x5, x20, #0x28
    e538:      	add	x6, x20, #0x50
    e53c:      	ldr	x5, [x5, #0x8]
    e540:      	ldr	x6, [x6, #0x8]
    e544:      	cmp	x5, x6
    e548:      	b.ne	0xe648 <_stogir.vector-arithmetic.operands+0x65c>
    e54c:      	cmp	x3, x5
    e550:      	b.gt	0xe664 <_stogir.vector-arithmetic.operands+0x678>
    e554:      	lsl	x3, x4, #2
    e558:      	ldr	x3, [x20, #0x50]
    e55c:      	add	x3, x3, x4, lsl #2
    e560:      	ldr	w3, [x3]
    e564:      	sxtw	x3, w3
    e568:      	cmp	x3, #0x0
    e56c:      	cset	w3, gt
    e570:      	ubfx	x3, x3, #0, #8
    e574:      	b	0xe668 <_stogir.vector-arithmetic.operands+0x67c>
    e578:      	brk	#0
    e57c:      	b	0xe578 <_stogir.vector-arithmetic.operands+0x58c>
    e580:      	movz	x3, #0x0, lsl #48
    e584:      	b	0xe58c <_stogir.vector-arithmetic.operands+0x5a0>
    e588:      	movz	x3, #0x0, lsl #48
    e58c:      	cmp	x3, #0x0
    e590:      	b.eq	0xe5d0 <_stogir.vector-arithmetic.operands+0x5e4>
    e594:      	uxtb	w16, w0
    e598:      	cmp	w16, wzr
    e59c:      	b.eq	0xe5b4 <_stogir.vector-arithmetic.operands+0x5c8>
    e5a0:      	lsl	x0, x25, #4
    e5a4:      	ldr	x0, [x20]
    e5a8:      	add	x0, x0, x25, lsl #4
    e5ac:      	ldr	x0, [x0]
    e5b0:      	b	0xe5c4 <_stogir.vector-arithmetic.operands+0x5d8>
    e5b4:      	lsl	x0, x4, #4
    e5b8:      	ldr	x0, [x20, #0x28]
    e5bc:      	add	x0, x0, x4, lsl #4
    e5c0:      	ldr	x0, [x0]
    e5c4:      	mov	x3, x0
    e5c8:      	mov	x0, #0x1                ; =1
    e5cc:      	b	0xe5d8 <_stogir.vector-arithmetic.operands+0x5ec>
    e5d0:      	movz	x0, #0x0, lsl #48
    e5d4:      	movz	x3, #0x0, lsl #48
    e5d8:      	lsr	w0, w0, #0
    e5dc:      	lsr	x16, x0, #0
    e5e0:      	cmp	x16, #0x1
    e5e4:      	b.eq	0xe600 <_stogir.vector-arithmetic.operands+0x614>
    e5e8:      	b.lo	0xe5f0 <_stogir.vector-arithmetic.operands+0x604>
    e5ec:      	b	0xe604 <_stogir.vector-arithmetic.operands+0x618>
    e5f0:      	cmp	x16, #0x0
    e5f4:      	b.eq	0xe5fc <_stogir.vector-arithmetic.operands+0x610>
    e5f8:      	b	0xe604 <_stogir.vector-arithmetic.operands+0x618>
    e5fc:      	b	0xe608 <_stogir.vector-arithmetic.operands+0x61c>
    e600:      	b	0xe61c <_stogir.vector-arithmetic.operands+0x630>
    e604:      	b	0xe66c <_stogir.vector-arithmetic.operands+0x680>
    e608:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e608:  ARM64_RELOC_PAGE21	l_stogir.500
    e60c:      	ldr	x16, [x16]
		000000000000e60c:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    e610:      	orr	x0, x16, xzr
    e614:      	mov	x1, #0x1d               ; =29
    e618:      	b	0xe528 <_stogir.vector-arithmetic.operands+0x53c>
    e61c:      	cmp	x25, #0x0
    e620:      	b.le	0xe518 <_stogir.vector-arithmetic.operands+0x52c>
    e624:      	uxtb	w3, w3
    e628:      	cmp	x3, #0x83
    e62c:      	b.ge	0xe4dc <_stogir.vector-arithmetic.operands+0x4f0>
    e630:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e630:  ARM64_RELOC_PAGE21	l_stogir.501
    e634:      	ldr	x16, [x16]
		000000000000e634:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    e638:      	orr	x0, x16, xzr
    e63c:      	add	x0, x3, x0
    e640:      	ldrb	w0, [x0]
    e644:      	b	0xe4e0 <_stogir.vector-arithmetic.operands+0x4f4>
    e648:      	movz	x3, #0x0, lsl #48
    e64c:      	b	0xe58c <_stogir.vector-arithmetic.operands+0x5a0>
    e650:      	movz	x3, #0x0, lsl #48
    e654:      	b	0xe584 <_stogir.vector-arithmetic.operands+0x598>
    e658:      	mov	x0, x1
    e65c:      	mov	x1, x2
    e660:      	b	0xe528 <_stogir.vector-arithmetic.operands+0x53c>
    e664:      	movz	x3, #0x0, lsl #48
    e668:      	b	0xe64c <_stogir.vector-arithmetic.operands+0x660>
    e66c:      	brk	#0
    e670:      	b	0xe66c <_stogir.vector-arithmetic.operands+0x680>
    e674:      	str	x4, [sp, #0x20]
    e678:      	str	x5, [sp, #0x28]
    e67c:      	b	0xe134 <_stogir.vector-arithmetic.operands+0x148>

000000000000e680 <_stogir.types.base-type>:
    e680:      	sub	sp, sp, #0x20
    e684:      	str	x29, [sp]
    e688:      	str	x30, [sp, #0x8]
    e68c:      	mov	x29, sp
    e690:      	str	x19, [sp, #0x10]
    e694:      	lsr	w0, w0, #0
    e698:      	mov	w19, w0
    e69c:      	bl	0xe69c <_stogir.types.base-type+0x1c>
		000000000000e69c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e6a0:      	cmp	x0, #0x0
    e6a4:      	b.eq	0xe6bc <_stogir.types.base-type+0x3c>
    e6a8:      	sxtw	x19, w19
    e6ac:      	and	x0, x19, #0xf
    e6b0:      	lsr	w0, w0, #0
    e6b4:      	sxtw	x0, w0
    e6b8:      	b	0xe6c0 <_stogir.types.base-type+0x40>
    e6bc:      	movn	x0, #0x0, lsl #48
    e6c0:      	ldr	x19, [sp, #0x10]
    e6c4:      	ldr	x29, [sp]
    e6c8:      	ldr	x30, [sp, #0x8]
    e6cc:      	add	sp, sp, #0x20
    e6d0:      	ret

000000000000e6d4 <_stogir.types.lanes>:
    e6d4:      	sxtw	x0, w0
    e6d8:      	cmp	x0, #0xf
    e6dc:      	b.le	0xe72c <_stogir.types.lanes+0x58>
    e6e0:      	cmp	x0, #0x80
    e6e4:      	b.ge	0xe72c <_stogir.types.lanes+0x58>
    e6e8:      	and	x1, x0, #0xf
    e6ec:      	lsr	w1, w1, #0
    e6f0:      	sxtw	x1, w1
    e6f4:      	cmp	x1, #0x1
    e6f8:      	b.lt	0xe72c <_stogir.types.lanes+0x58>
    e6fc:      	cmp	x1, #0xd
    e700:      	b.gt	0xe72c <_stogir.types.lanes+0x58>
    e704:      	ubfx	x0, x0, #4, #32
    e708:      	sxtw	x0, w0
    e70c:      	sub	x0, x0, #0x1
    e710:      	lsr	w0, w0, #0
    e714:      	sxtw	x0, w0
    e718:      	mov	x16, #0x1               ; =1
    e71c:      	lsl	x0, x16, x0
    e720:      	lsr	w0, w0, #0
    e724:      	sxtw	x0, w0
    e728:      	b	0xe758 <_stogir.types.lanes+0x84>
    e72c:      	cmp	x0, #0x0
    e730:      	b.lt	0xe754 <_stogir.types.lanes+0x80>
    e734:      	cmp	x0, #0xd
    e738:      	b.gt	0xe754 <_stogir.types.lanes+0x80>
    e73c:      	cmp	x0, #0x0
    e740:      	cset	w0, eq
    e744:      	uxtb	w16, w0
    e748:      	cmp	w16, wzr
    e74c:      	cset	x0, eq
    e750:      	b	0xe758 <_stogir.types.lanes+0x84>
    e754:      	movn	x0, #0x0, lsl #48
    e758:      	ret

000000000000e75c <_coil.core.Get$slice$get__u8>:
    e75c:      	lsr	x1, x2, #0
    e760:      	add	x0, x0, x2
    e764:      	ldrb	w0, [x0]
    e768:      	ret

000000000000e76c <_stogir.checked.valid-type?>:
    e76c:      	sxtw	x0, w0
    e770:      	cmp	x0, #0x1
    e774:      	b.lt	0xe798 <_stogir.checked.valid-type?+0x2c>
    e778:      	cmp	x0, #0xb
    e77c:      	b.gt	0xe798 <_stogir.checked.valid-type?+0x2c>
    e780:      	cmp	x0, #0x1
    e784:      	cset	w0, eq
    e788:      	uxtb	w16, w0
    e78c:      	cmp	w16, wzr
    e790:      	cset	x0, eq
    e794:      	b	0xe79c <_stogir.checked.valid-type?+0x30>
    e798:      	movz	x0, #0x0, lsl #48
    e79c:      	ret

000000000000e7a0 <_coil.core.Iterable$slice$iter__i32>:
    e7a0:      	str	x0, [x8]
    e7a4:      	str	x1, [x8, #0x8]
    e7a8:      	movz	x17, #0x0, lsl #48
    e7ac:      	str	x17, [x8, #0x10]
    e7b0:      	ret

000000000000e7b4 <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
    e7b4:      	sub	sp, sp, #0x10
    e7b8:      	mov	x1, sp
    e7bc:      	ldr	x2, [x0, #0x10]
    e7c0:      	ldr	x3, [x0]
    e7c4:      	ldr	x4, [x0, #0x8]
    e7c8:      	cmp	x2, x4
    e7cc:      	b.ge	0xe7f8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
    e7d0:      	add	x4, x2, #0x1
    e7d4:      	lsl	x5, x2, #2
    e7d8:      	add	x2, x3, x2, lsl #2
    e7dc:      	str	x4, [x0, #0x10]
    e7e0:      	ldr	w0, [x2]
    e7e4:      	sxtw	x0, w0
    e7e8:      	and	x0, x0, #0xffffffff
    e7ec:      	mov	x2, x0
    e7f0:      	mov	x0, #0x1                ; =1
    e7f4:      	b	0xe800 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x4c>
    e7f8:      	movz	x0, #0x0, lsl #48
    e7fc:      	movz	x2, #0x0, lsl #48
    e800:      	str	x0, [x1]
    e804:      	str	x2, [x1, #0x8]
    e808:      	ldr	x0, [sp]
    e80c:      	ldr	x1, [sp, #0x8]
    e810:      	add	sp, sp, #0x10
    e814:      	ret

000000000000e818 <_stogir.terminal.previous-input>:
    e818:      	sxtw	x1, w1
    e81c:      	cmp	x1, #0x0
    e820:      	b.ne	0xe840 <_stogir.terminal.previous-input+0x28>
    e824:      	movz	x0, #0x0, lsl #48
    e828:      	movz	x1, #0x0, lsl #48
    e82c:      	movz	x2, #0x0, lsl #48
    e830:      	str	x0, [x8]
    e834:      	str	x1, [x8, #0x8]
    e838:      	str	x2, [x8, #0x10]
    e83c:      	ret
    e840:      	cmp	x1, #0x0
    e844:      	cset	w2, gt
    e848:      	movz	x16, #0x0, lsl #48
    e84c:      	sub	x3, x16, x1
    e850:      	sub	x4, x3, #0x1
    e854:      	uxtb	w16, w2
    e858:      	cmp	w16, wzr
    e85c:      	b.eq	0xe8bc <_stogir.terminal.previous-input+0xa4>
    e860:      	ldr	x3, [x0, #0x8]
    e864:      	cmp	x1, x3
    e868:      	b.ge	0xe908 <_stogir.terminal.previous-input+0xf0>
    e86c:      	add	x3, x0, #0x78
    e870:      	ldr	x3, [x3, #0x8]
    e874:      	cmp	x1, x3
    e878:      	b.ge	0xe9e0 <_stogir.terminal.previous-input+0x1c8>
    e87c:      	lsl	x3, x1, #2
    e880:      	ldr	x3, [x0, #0x78]
    e884:      	add	x3, x3, x1, lsl #2
    e888:      	ldr	w3, [x3]
    e88c:      	sxtw	x3, w3
    e890:      	cmp	x3, #0x0
    e894:      	cset	w3, ge
    e898:      	ubfx	x3, x3, #0, #8
    e89c:      	b	0xe9e4 <_stogir.terminal.previous-input+0x1cc>
    e8a0:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e8a0:  ARM64_RELOC_PAGE21	l_stogir.502
    e8a4:      	ldr	x16, [x16]
		000000000000e8a4:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    e8a8:      	orr	x0, x16, xzr
    e8ac:      	mov	x1, x0
    e8b0:      	mov	x0, #0x1                ; =1
    e8b4:      	mov	x2, #0x2e               ; =46
    e8b8:      	b	0xe830 <_stogir.terminal.previous-input+0x18>
    e8bc:      	cmp	x1, #0x0
    e8c0:      	b.ge	0xe910 <_stogir.terminal.previous-input+0xf8>
    e8c4:      	add	x5, x0, #0x28
    e8c8:      	add	x6, x0, #0x50
    e8cc:      	ldr	x5, [x5, #0x8]
    e8d0:      	ldr	x6, [x6, #0x8]
    e8d4:      	cmp	x5, x6
    e8d8:      	b.ne	0xe9d8 <_stogir.terminal.previous-input+0x1c0>
    e8dc:      	cmp	x3, x5
    e8e0:      	b.gt	0xe9e8 <_stogir.terminal.previous-input+0x1d0>
    e8e4:      	lsl	x3, x4, #2
    e8e8:      	ldr	x3, [x0, #0x50]
    e8ec:      	add	x3, x3, x4, lsl #2
    e8f0:      	ldr	w3, [x3]
    e8f4:      	sxtw	x3, w3
    e8f8:      	cmp	x3, #0x0
    e8fc:      	cset	w3, gt
    e900:      	ubfx	x3, x3, #0, #8
    e904:      	b	0xe9ec <_stogir.terminal.previous-input+0x1d4>
    e908:      	movz	x3, #0x0, lsl #48
    e90c:      	b	0xe914 <_stogir.terminal.previous-input+0xfc>
    e910:      	movz	x3, #0x0, lsl #48
    e914:      	cmp	x3, #0x0
    e918:      	b.eq	0xe958 <_stogir.terminal.previous-input+0x140>
    e91c:      	uxtb	w16, w2
    e920:      	cmp	w16, wzr
    e924:      	b.eq	0xe93c <_stogir.terminal.previous-input+0x124>
    e928:      	lsl	x2, x1, #4
    e92c:      	ldr	x0, [x0]
    e930:      	add	x0, x0, x1, lsl #4
    e934:      	ldr	x0, [x0]
    e938:      	b	0xe94c <_stogir.terminal.previous-input+0x134>
    e93c:      	lsl	x2, x4, #4
    e940:      	ldr	x0, [x0, #0x28]
    e944:      	add	x0, x0, x4, lsl #4
    e948:      	ldr	x0, [x0]
    e94c:      	mov	x2, x0
    e950:      	mov	x0, #0x1                ; =1
    e954:      	b	0xe960 <_stogir.terminal.previous-input+0x148>
    e958:      	movz	x0, #0x0, lsl #48
    e95c:      	movz	x2, #0x0, lsl #48
    e960:      	lsr	w0, w0, #0
    e964:      	lsr	x16, x0, #0
    e968:      	cmp	x16, #0x1
    e96c:      	b.eq	0xe988 <_stogir.terminal.previous-input+0x170>
    e970:      	b.lo	0xe978 <_stogir.terminal.previous-input+0x160>
    e974:      	b	0xe98c <_stogir.terminal.previous-input+0x174>
    e978:      	cmp	x16, #0x0
    e97c:      	b.eq	0xe984 <_stogir.terminal.previous-input+0x16c>
    e980:      	b	0xe98c <_stogir.terminal.previous-input+0x174>
    e984:      	b	0xe990 <_stogir.terminal.previous-input+0x178>
    e988:      	b	0xe9ac <_stogir.terminal.previous-input+0x194>
    e98c:      	b	0xea30 <_stogir.terminal.previous-input+0x218>
    e990:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e990:  ARM64_RELOC_PAGE21	l_stogir.503
    e994:      	ldr	x16, [x16]
		000000000000e994:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    e998:      	orr	x0, x16, xzr
    e99c:      	mov	x1, x0
    e9a0:      	mov	x0, #0x1                ; =1
    e9a4:      	mov	x2, #0x1d               ; =29
    e9a8:      	b	0xe8b8 <_stogir.terminal.previous-input+0xa0>
    e9ac:      	cmp	x1, #0x0
    e9b0:      	b.le	0xe8a0 <_stogir.terminal.previous-input+0x88>
    e9b4:      	uxtb	w2, w2
    e9b8:      	cmp	x2, #0x83
    e9bc:      	b.ge	0xe9f0 <_stogir.terminal.previous-input+0x1d8>
    e9c0:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000e9c0:  ARM64_RELOC_PAGE21	l_stogir.504
    e9c4:      	ldr	x16, [x16]
		000000000000e9c4:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    e9c8:      	orr	x0, x16, xzr
    e9cc:      	add	x0, x2, x0
    e9d0:      	ldrb	w0, [x0]
    e9d4:      	b	0xe9f4 <_stogir.terminal.previous-input+0x1dc>
    e9d8:      	movz	x3, #0x0, lsl #48
    e9dc:      	b	0xe914 <_stogir.terminal.previous-input+0xfc>
    e9e0:      	movz	x3, #0x0, lsl #48
    e9e4:      	b	0xe90c <_stogir.terminal.previous-input+0xf4>
    e9e8:      	movz	x3, #0x0, lsl #48
    e9ec:      	b	0xe9dc <_stogir.terminal.previous-input+0x1c4>
    e9f0:      	movz	x0, #0x0, lsl #48
    e9f4:      	uxtb	w0, w0
    e9f8:      	and	x0, x0, #0x8
    e9fc:      	uxtb	w0, w0
    ea00:      	cmp	x0, #0x0
    ea04:      	cset	w0, eq
    ea08:      	uxtb	w16, w0
    ea0c:      	cmp	w16, wzr
    ea10:      	cset	x0, eq
    ea14:      	cmp	x0, #0x0
    ea18:      	b.eq	0xe8a0 <_stogir.terminal.previous-input+0x88>
    ea1c:      	and	x0, x1, #0xffffffff
    ea20:      	mov	x1, x0
    ea24:      	movz	x0, #0x0, lsl #48
    ea28:      	movz	x2, #0x0, lsl #48
    ea2c:      	b	0xe8b8 <_stogir.terminal.previous-input+0xa0>
    ea30:      	brk	#0
    ea34:      	b	0xea30 <_stogir.terminal.previous-input+0x218>

000000000000ea38 <_stogir.switch.selector-type>:
    ea38:      	sxtw	x1, w1
    ea3c:      	cmp	x1, #0x0
    ea40:      	cset	w2, gt
    ea44:      	movz	x16, #0x0, lsl #48
    ea48:      	sub	x3, x16, x1
    ea4c:      	sub	x4, x3, #0x1
    ea50:      	uxtb	w16, w2
    ea54:      	cmp	w16, wzr
    ea58:      	b.eq	0xea9c <_stogir.switch.selector-type+0x64>
    ea5c:      	ldr	x3, [x0, #0x8]
    ea60:      	cmp	x1, x3
    ea64:      	b.ge	0xeaf0 <_stogir.switch.selector-type+0xb8>
    ea68:      	add	x3, x0, #0x78
    ea6c:      	ldr	x3, [x3, #0x8]
    ea70:      	cmp	x1, x3
    ea74:      	b.ge	0xebf4 <_stogir.switch.selector-type+0x1bc>
    ea78:      	lsl	x3, x1, #2
    ea7c:      	ldr	x3, [x0, #0x78]
    ea80:      	add	x3, x3, x1, lsl #2
    ea84:      	ldr	w3, [x3]
    ea88:      	sxtw	x3, w3
    ea8c:      	cmp	x3, #0x0
    ea90:      	cset	w3, ge
    ea94:      	ubfx	x3, x3, #0, #8
    ea98:      	b	0xebf8 <_stogir.switch.selector-type+0x1c0>
    ea9c:      	cmp	x1, #0x0
    eaa0:      	b.ge	0xeaf8 <_stogir.switch.selector-type+0xc0>
    eaa4:      	add	x5, x0, #0x28
    eaa8:      	add	x6, x0, #0x50
    eaac:      	ldr	x5, [x5, #0x8]
    eab0:      	ldr	x6, [x6, #0x8]
    eab4:      	cmp	x5, x6
    eab8:      	b.ne	0xeae8 <_stogir.switch.selector-type+0xb0>
    eabc:      	cmp	x3, x5
    eac0:      	b.gt	0xebfc <_stogir.switch.selector-type+0x1c4>
    eac4:      	lsl	x3, x4, #2
    eac8:      	ldr	x3, [x0, #0x50]
    eacc:      	add	x3, x3, x4, lsl #2
    ead0:      	ldr	w3, [x3]
    ead4:      	sxtw	x3, w3
    ead8:      	cmp	x3, #0x0
    eadc:      	cset	w3, gt
    eae0:      	ubfx	x3, x3, #0, #8
    eae4:      	b	0xec00 <_stogir.switch.selector-type+0x1c8>
    eae8:      	movz	x3, #0x0, lsl #48
    eaec:      	b	0xeafc <_stogir.switch.selector-type+0xc4>
    eaf0:      	movz	x3, #0x0, lsl #48
    eaf4:      	b	0xeafc <_stogir.switch.selector-type+0xc4>
    eaf8:      	movz	x3, #0x0, lsl #48
    eafc:      	cmp	x3, #0x0
    eb00:      	b.eq	0xeb40 <_stogir.switch.selector-type+0x108>
    eb04:      	uxtb	w16, w2
    eb08:      	cmp	w16, wzr
    eb0c:      	b.eq	0xeb24 <_stogir.switch.selector-type+0xec>
    eb10:      	lsl	x2, x1, #4
    eb14:      	ldr	x0, [x0]
    eb18:      	add	x0, x0, x1, lsl #4
    eb1c:      	ldr	x0, [x0]
    eb20:      	b	0xeb34 <_stogir.switch.selector-type+0xfc>
    eb24:      	lsl	x1, x4, #4
    eb28:      	ldr	x0, [x0, #0x28]
    eb2c:      	add	x0, x0, x4, lsl #4
    eb30:      	ldr	x0, [x0]
    eb34:      	mov	x1, x0
    eb38:      	mov	x0, #0x1                ; =1
    eb3c:      	b	0xeb48 <_stogir.switch.selector-type+0x110>
    eb40:      	movz	x0, #0x0, lsl #48
    eb44:      	movz	x1, #0x0, lsl #48
    eb48:      	lsr	w0, w0, #0
    eb4c:      	lsr	x16, x0, #0
    eb50:      	cmp	x16, #0x1
    eb54:      	b.eq	0xeb70 <_stogir.switch.selector-type+0x138>
    eb58:      	b.lo	0xeb60 <_stogir.switch.selector-type+0x128>
    eb5c:      	b	0xeb74 <_stogir.switch.selector-type+0x13c>
    eb60:      	cmp	x16, #0x0
    eb64:      	b.eq	0xeb6c <_stogir.switch.selector-type+0x134>
    eb68:      	b	0xeb74 <_stogir.switch.selector-type+0x13c>
    eb6c:      	b	0xeb78 <_stogir.switch.selector-type+0x140>
    eb70:      	b	0xebbc <_stogir.switch.selector-type+0x184>
    eb74:      	b	0xec04 <_stogir.switch.selector-type+0x1cc>
    eb78:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000eb78:  ARM64_RELOC_PAGE21	l_stogir.505
    eb7c:      	ldr	x16, [x16]
		000000000000eb7c:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    eb80:      	orr	x0, x16, xzr
    eb84:      	mov	x1, x0
    eb88:      	mov	x0, #0x1                ; =1
    eb8c:      	mov	x2, #0x17               ; =23
    eb90:      	b	0xebac <_stogir.switch.selector-type+0x174>
    eb94:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000eb94:  ARM64_RELOC_PAGE21	l_stogir.506
    eb98:      	ldr	x16, [x16]
		000000000000eb98:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    eb9c:      	orr	x0, x16, xzr
    eba0:      	mov	x1, x0
    eba4:      	mov	x0, #0x1                ; =1
    eba8:      	mov	x2, #0x20               ; =32
    ebac:      	str	x0, [x8]
    ebb0:      	str	x1, [x8, #0x8]
    ebb4:      	str	x2, [x8, #0x10]
    ebb8:      	ret
    ebbc:      	lsr	w0, w1, #0
    ebc0:      	ubfx	x0, x0, #8, #8
    ebc4:      	cmp	x0, #0x1
    ebc8:      	b.lt	0xeb94 <_stogir.switch.selector-type+0x15c>
    ebcc:      	cmp	x0, #0xb
    ebd0:      	b.gt	0xeb94 <_stogir.switch.selector-type+0x15c>
    ebd4:      	uxtb	w1, w1
    ebd8:      	cmp	x1, #0x48
    ebdc:      	b.eq	0xeb94 <_stogir.switch.selector-type+0x15c>
    ebe0:      	and	x0, x0, #0xffffffff
    ebe4:      	mov	x1, x0
    ebe8:      	movz	x0, #0x0, lsl #48
    ebec:      	movz	x2, #0x0, lsl #48
    ebf0:      	b	0xebac <_stogir.switch.selector-type+0x174>
    ebf4:      	movz	x3, #0x0, lsl #48
    ebf8:      	b	0xeaf4 <_stogir.switch.selector-type+0xbc>
    ebfc:      	movz	x3, #0x0, lsl #48
    ec00:      	b	0xeaec <_stogir.switch.selector-type+0xb4>
    ec04:      	brk	#0
    ec08:      	b	0xec04 <_stogir.switch.selector-type+0x1cc>

000000000000ec0c <_stogir.switch.key>:
    ec0c:      	sub	sp, sp, #0x30
    ec10:      	str	x19, [sp]
    ec14:      	str	x20, [sp, #0x8]
    ec18:      	str	x21, [sp, #0x10]
    ec1c:      	str	x22, [sp, #0x18]
    ec20:      	str	x23, [sp, #0x20]
    ec24:      	sxtw	x2, w2
    ec28:      	cmp	x2, #0x1
    ec2c:      	b.lt	0xeca8 <_stogir.switch.key+0x9c>
    ec30:      	cmp	x2, #0xb
    ec34:      	cset	w3, le
    ec38:      	uxtb	w16, w3
    ec3c:      	cmp	w16, wzr
    ec40:      	b.eq	0xeca8 <_stogir.switch.key+0x9c>
    ec44:      	sxtw	x1, w1
    ec48:      	cmp	x1, #0x0
    ec4c:      	cset	w4, gt
    ec50:      	movz	x16, #0x0, lsl #48
    ec54:      	sub	x5, x16, x1
    ec58:      	sub	x6, x5, #0x1
    ec5c:      	uxtb	w16, w4
    ec60:      	cmp	w16, wzr
    ec64:      	b.eq	0xed2c <_stogir.switch.key+0x120>
    ec68:      	ldr	x5, [x0, #0x8]
    ec6c:      	cmp	x1, x5
    ec70:      	b.ge	0xed78 <_stogir.switch.key+0x16c>
    ec74:      	add	x5, x0, #0x78
    ec78:      	ldr	x5, [x5, #0x8]
    ec7c:      	cmp	x1, x5
    ec80:      	b.ge	0xeee4 <_stogir.switch.key+0x2d8>
    ec84:      	lsl	x5, x1, #2
    ec88:      	ldr	x5, [x0, #0x78]
    ec8c:      	add	x5, x5, x1, lsl #2
    ec90:      	ldr	w5, [x5]
    ec94:      	sxtw	x5, w5
    ec98:      	cmp	x5, #0x0
    ec9c:      	cset	w5, ge
    eca0:      	ubfx	x5, x5, #0, #8
    eca4:      	b	0xeee8 <_stogir.switch.key+0x2dc>
    eca8:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000eca8:  ARM64_RELOC_PAGE21	l_stogir.507
    ecac:      	ldr	x16, [x16]
		000000000000ecac:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    ecb0:      	orr	x0, x16, xzr
    ecb4:      	mov	x1, x0
    ecb8:      	mov	x0, #0x1                ; =1
    ecbc:      	mov	x2, #0x24               ; =36
    ecc0:      	str	x0, [x8]
    ecc4:      	str	x1, [x8, #0x8]
    ecc8:      	str	x2, [x8, #0x10]
    eccc:      	ldr	x19, [sp]
    ecd0:      	ldr	x20, [sp, #0x8]
    ecd4:      	ldr	x21, [sp, #0x10]
    ecd8:      	ldr	x22, [sp, #0x18]
    ecdc:      	ldr	x23, [sp, #0x20]
    ece0:      	add	sp, sp, #0x30
    ece4:      	ret
    ece8:      	mov	x23, #0x1               ; =1
    ecec:      	cmp	x1, #0x0
    ecf0:      	b.ge	0xed10 <_stogir.switch.key+0x104>
    ecf4:      	lsr	w1, w4, #0
    ecf8:      	uxtb	w4, w4
    ecfc:      	ubfx	x1, x1, #8, #8
    ed00:      	cmp	x4, x1
    ed04:      	b.eq	0xef8c <_stogir.switch.key+0x380>
    ed08:      	cmp	x4, #0x49
    ed0c:      	b.eq	0xef8c <_stogir.switch.key+0x380>
    ed10:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000ed10:  ARM64_RELOC_PAGE21	l_stogir.508
    ed14:      	ldr	x16, [x16]
		000000000000ed14:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    ed18:      	orr	x0, x16, xzr
    ed1c:      	mov	x1, x0
    ed20:      	mov	x0, #0x1                ; =1
    ed24:      	mov	x2, #0x30               ; =48
    ed28:      	b	0xecc0 <_stogir.switch.key+0xb4>
    ed2c:      	cmp	x1, #0x0
    ed30:      	b.ge	0xed80 <_stogir.switch.key+0x174>
    ed34:      	add	x7, x0, #0x28
    ed38:      	add	x9, x0, #0x50
    ed3c:      	ldr	x7, [x7, #0x8]
    ed40:      	ldr	x9, [x9, #0x8]
    ed44:      	cmp	x7, x9
    ed48:      	b.ne	0xeedc <_stogir.switch.key+0x2d0>
    ed4c:      	cmp	x5, x7
    ed50:      	b.gt	0xef84 <_stogir.switch.key+0x378>
    ed54:      	lsl	x5, x6, #2
    ed58:      	ldr	x5, [x0, #0x50]
    ed5c:      	add	x5, x5, x6, lsl #2
    ed60:      	ldr	w5, [x5]
    ed64:      	sxtw	x5, w5
    ed68:      	cmp	x5, #0x0
    ed6c:      	cset	w5, gt
    ed70:      	ubfx	x5, x5, #0, #8
    ed74:      	b	0xef88 <_stogir.switch.key+0x37c>
    ed78:      	movz	x5, #0x0, lsl #48
    ed7c:      	b	0xed84 <_stogir.switch.key+0x178>
    ed80:      	movz	x5, #0x0, lsl #48
    ed84:      	cmp	x5, #0x0
    ed88:      	b.eq	0xedec <_stogir.switch.key+0x1e0>
    ed8c:      	uxtb	w16, w4
    ed90:      	cmp	w16, wzr
    ed94:      	b.eq	0xedbc <_stogir.switch.key+0x1b0>
    ed98:      	lsl	x4, x1, #4
    ed9c:      	ldr	x0, [x0]
    eda0:      	add	x0, x0, x1, lsl #4
    eda4:      	ldr	x4, [x0]
    eda8:      	ldr	x0, [x0, #0x8]
    edac:      	fmov	d31, x0
    edb0:      	mov	x0, x4
    edb4:      	fmov	x4, d31
    edb8:      	b	0xeddc <_stogir.switch.key+0x1d0>
    edbc:      	lsl	x4, x6, #4
    edc0:      	ldr	x0, [x0, #0x28]
    edc4:      	add	x0, x0, x6, lsl #4
    edc8:      	ldr	x4, [x0]
    edcc:      	ldr	x0, [x0, #0x8]
    edd0:      	fmov	d31, x0
    edd4:      	mov	x0, x4
    edd8:      	fmov	x4, d31
    eddc:      	mov	x5, x4
    ede0:      	mov	x4, x0
    ede4:      	mov	x0, #0x1                ; =1
    ede8:      	b	0xedf8 <_stogir.switch.key+0x1ec>
    edec:      	movz	x0, #0x0, lsl #48
    edf0:      	movz	x4, #0x0, lsl #48
    edf4:      	movz	x5, #0x0, lsl #48
    edf8:      	lsr	w0, w0, #0
    edfc:      	lsr	x16, x0, #0
    ee00:      	cmp	x16, #0x1
    ee04:      	b.eq	0xee20 <_stogir.switch.key+0x214>
    ee08:      	b.lo	0xee10 <_stogir.switch.key+0x204>
    ee0c:      	b	0xee24 <_stogir.switch.key+0x218>
    ee10:      	cmp	x16, #0x0
    ee14:      	b.eq	0xee1c <_stogir.switch.key+0x210>
    ee18:      	b	0xee24 <_stogir.switch.key+0x218>
    ee1c:      	b	0xee28 <_stogir.switch.key+0x21c>
    ee20:      	b	0xee44 <_stogir.switch.key+0x238>
    ee24:      	b	0xf030 <_stogir.switch.key+0x424>
    ee28:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x14>
		000000000000ee28:  ARM64_RELOC_PAGE21	l_stogir.509
    ee2c:      	ldr	x16, [x16]
		000000000000ee2c:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    ee30:      	orr	x0, x16, xzr
    ee34:      	mov	x1, x0
    ee38:      	mov	x0, #0x1                ; =1
    ee3c:      	mov	x2, #0x1c               ; =28
    ee40:      	b	0xed28 <_stogir.switch.key+0x11c>
    ee44:      	cmp	x2, #0x1
    ee48:      	cset	w0, eq
    ee4c:      	cmp	x2, #0x0
    ee50:      	cset	w6, eq
    ee54:      	cmp	x2, #0x2
    ee58:      	cset	w7, eq
    ee5c:      	cmp	x2, #0x7
    ee60:      	cset	w9, eq
    ee64:      	cmp	x2, #0x8
    ee68:      	cset	w10, eq
    ee6c:      	cmp	x2, #0x3
    ee70:      	cset	w11, eq
    ee74:      	cmp	x2, #0x9
    ee78:      	cset	w12, eq
    ee7c:      	cmp	x2, #0x4
    ee80:      	cset	w13, eq
    ee84:      	cmp	x2, #0xa
    ee88:      	cset	w14, eq
    ee8c:      	cmp	x2, #0xd
    ee90:      	cset	w15, eq
    ee94:      	cmp	x2, #0x5
    ee98:      	cset	w19, eq
    ee9c:      	cmp	x2, #0xb
    eea0:      	cset	w20, eq
    eea4:      	cmp	x2, #0xc
    eea8:      	cset	w21, eq
    eeac:      	cmp	x2, #0x6
    eeb0:      	cset	w22, eq
    eeb4:      	uxtb	w16, w22
    eeb8:      	cmp	w16, wzr
    eebc:      	mov	x16, #0x8               ; =8
    eec0:      	movn	x17, #0x0, lsl #48
    eec4:      	csel	x22, x16, x17, ne
    eec8:      	uxtb	w16, w6
    eecc:      	cmp	w16, wzr
    eed0:      	b.eq	0xeeec <_stogir.switch.key+0x2e0>
    eed4:      	movz	x23, #0x0, lsl #48
    eed8:      	b	0xecec <_stogir.switch.key+0xe0>
    eedc:      	movz	x5, #0x0, lsl #48
    eee0:      	b	0xed84 <_stogir.switch.key+0x178>
    eee4:      	movz	x5, #0x0, lsl #48
    eee8:      	b	0xed7c <_stogir.switch.key+0x170>
    eeec:      	uxtb	w16, w0
    eef0:      	cmp	w16, wzr
    eef4:      	b.ne	0xece8 <_stogir.switch.key+0xdc>
    eef8:      	uxtb	w16, w7
    eefc:      	cmp	w16, wzr
    ef00:      	b.ne	0xece8 <_stogir.switch.key+0xdc>
    ef04:      	uxtb	w16, w9
    ef08:      	cmp	w16, wzr
    ef0c:      	b.ne	0xece8 <_stogir.switch.key+0xdc>
    ef10:      	uxtb	w16, w10
    ef14:      	cmp	w16, wzr
    ef18:      	b.ne	0xece8 <_stogir.switch.key+0xdc>
    ef1c:      	uxtb	w16, w11
    ef20:      	cmp	w16, wzr
    ef24:      	b.ne	0xf028 <_stogir.switch.key+0x41c>
    ef28:      	uxtb	w16, w12
    ef2c:      	cmp	w16, wzr
    ef30:      	b.ne	0xf028 <_stogir.switch.key+0x41c>
    ef34:      	uxtb	w16, w13
    ef38:      	cmp	w16, wzr
    ef3c:      	b.ne	0xf100 <_stogir.switch.key+0x4f4>
    ef40:      	uxtb	w16, w14
    ef44:      	cmp	w16, wzr
    ef48:      	b.ne	0xf100 <_stogir.switch.key+0x4f4>
    ef4c:      	uxtb	w16, w15
    ef50:      	cmp	w16, wzr
    ef54:      	b.ne	0xf100 <_stogir.switch.key+0x4f4>
    ef58:      	uxtb	w16, w19
    ef5c:      	cmp	w16, wzr
    ef60:      	b.ne	0xf108 <_stogir.switch.key+0x4fc>
    ef64:      	uxtb	w16, w20
    ef68:      	cmp	w16, wzr
    ef6c:      	b.ne	0xf108 <_stogir.switch.key+0x4fc>
    ef70:      	uxtb	w16, w21
    ef74:      	cmp	w16, wzr
    ef78:      	b.ne	0xf108 <_stogir.switch.key+0x4fc>
    ef7c:      	mov	x23, x22
    ef80:      	b	0xf10c <_stogir.switch.key+0x500>
    ef84:      	movz	x5, #0x0, lsl #48
    ef88:      	b	0xeee0 <_stogir.switch.key+0x2d4>
    ef8c:      	cmp	x1, x2
    ef90:      	b.ne	0xed10 <_stogir.switch.key+0x104>
    ef94:      	lsr	w23, w23, #0
    ef98:      	lsr	w1, w5, #0
    ef9c:      	sxtw	x23, w23
    efa0:      	ubfx	x1, x1, #0, #32
    efa4:      	lsr	x4, x5, #32
    efa8:      	lsl	x5, x23, #3
    efac:      	ubfx	x4, x4, #0, #32
    efb0:      	lsr	w5, w5, #0
    efb4:      	lsl	x4, x4, #32
    efb8:      	sxtw	x5, w5
    efbc:      	orr	x1, x4, x1
    efc0:      	cmp	x5, #0x40
    efc4:      	b.ge	0xefd4 <_stogir.switch.key+0x3c8>
    efc8:      	lsr	x4, x1, x5
    efcc:      	cmp	x4, #0x0
    efd0:      	b.ne	0xed10 <_stogir.switch.key+0x104>
    efd4:      	uxtb	w16, w0
    efd8:      	cmp	w16, wzr
    efdc:      	b.eq	0xefe8 <_stogir.switch.key+0x3dc>
    efe0:      	cmp	x1, #0x1
    efe4:      	b.hi	0xed10 <_stogir.switch.key+0x104>
    efe8:      	cmp	x2, #0x7
    efec:      	b.lt	0xf010 <_stogir.switch.key+0x404>
    eff0:      	uxtb	w16, w3
    eff4:      	cmp	w16, wzr
    eff8:      	b.eq	0xf010 <_stogir.switch.key+0x404>
    effc:      	uxtb	w16, w6
    f000:      	cmp	w16, wzr
    f004:      	b.eq	0xf068 <_stogir.switch.key+0x45c>
    f008:      	movz	x0, #0x0, lsl #48
    f00c:      	b	0xf03c <_stogir.switch.key+0x430>
    f010:      	movz	x0, #0x0, lsl #48
    f014:      	eor	x0, x0, x1
    f018:      	mov	x1, x0
    f01c:      	movz	x0, #0x0, lsl #48
    f020:      	movz	x2, #0x0, lsl #48
    f024:      	b	0xed28 <_stogir.switch.key+0x11c>
    f028:      	mov	x23, #0x2               ; =2
    f02c:      	b	0xecec <_stogir.switch.key+0xe0>
    f030:      	brk	#0
    f034:      	b	0xf030 <_stogir.switch.key+0x424>
    f038:      	mov	x0, #0x1                ; =1
    f03c:      	lsr	w0, w0, #0
    f040:      	sxtw	x0, w0
    f044:      	lsl	x0, x0, #3
    f048:      	lsr	w0, w0, #0
    f04c:      	sxtw	x0, w0
    f050:      	sub	x0, x0, #0x1
    f054:      	lsr	w0, w0, #0
    f058:      	sxtw	x0, w0
    f05c:      	mov	x16, #0x1               ; =1
    f060:      	lsl	x0, x16, x0
    f064:      	b	0xf014 <_stogir.switch.key+0x408>
    f068:      	uxtb	w16, w0
    f06c:      	cmp	w16, wzr
    f070:      	b.ne	0xf038 <_stogir.switch.key+0x42c>
    f074:      	uxtb	w16, w7
    f078:      	cmp	w16, wzr
    f07c:      	b.ne	0xf038 <_stogir.switch.key+0x42c>
    f080:      	uxtb	w16, w9
    f084:      	cmp	w16, wzr
    f088:      	b.ne	0xf038 <_stogir.switch.key+0x42c>
    f08c:      	uxtb	w16, w10
    f090:      	cmp	w16, wzr
    f094:      	b.ne	0xf038 <_stogir.switch.key+0x42c>
    f098:      	uxtb	w16, w11
    f09c:      	cmp	w16, wzr
    f0a0:      	b.ne	0xf110 <_stogir.switch.key+0x504>
    f0a4:      	uxtb	w16, w12
    f0a8:      	cmp	w16, wzr
    f0ac:      	b.ne	0xf110 <_stogir.switch.key+0x504>
    f0b0:      	uxtb	w16, w13
    f0b4:      	cmp	w16, wzr
    f0b8:      	b.ne	0xf118 <_stogir.switch.key+0x50c>
    f0bc:      	uxtb	w16, w14
    f0c0:      	cmp	w16, wzr
    f0c4:      	b.ne	0xf118 <_stogir.switch.key+0x50c>
    f0c8:      	uxtb	w16, w15
    f0cc:      	cmp	w16, wzr
    f0d0:      	b.ne	0xf118 <_stogir.switch.key+0x50c>
    f0d4:      	uxtb	w16, w19
    f0d8:      	cmp	w16, wzr
    f0dc:      	b.ne	0xf120 <_stogir.switch.key+0x514>
    f0e0:      	uxtb	w16, w20
    f0e4:      	cmp	w16, wzr
    f0e8:      	b.ne	0xf120 <_stogir.switch.key+0x514>
    f0ec:      	uxtb	w16, w21
    f0f0:      	cmp	w16, wzr
    f0f4:      	b.ne	0xf120 <_stogir.switch.key+0x514>
    f0f8:      	mov	x0, x22
    f0fc:      	b	0xf124 <_stogir.switch.key+0x518>
    f100:      	mov	x23, #0x4               ; =4
    f104:      	b	0xf02c <_stogir.switch.key+0x420>
    f108:      	mov	x23, #0x8               ; =8
    f10c:      	b	0xf104 <_stogir.switch.key+0x4f8>
    f110:      	mov	x0, #0x2                ; =2
    f114:      	b	0xf03c <_stogir.switch.key+0x430>
    f118:      	mov	x0, #0x4                ; =4
    f11c:      	b	0xf114 <_stogir.switch.key+0x508>
    f120:      	mov	x0, #0x8                ; =8
    f124:      	b	0xf11c <_stogir.switch.key+0x510>

000000000000f128 <_stogir.stack.entry-allocation?>:
    f128:      	sub	sp, sp, #0x10
    f12c:      	add	x2, x0, #0x78
    f130:      	add	x3, x0, #0x28
    f134:      	add	x4, x0, #0x50
    f138:      	add	x5, x0, #0x78
    f13c:      	add	x6, x0, #0x28
    f140:      	add	x7, x0, #0x50
    f144:      	sxtw	x1, w1
    f148:      	mov	x9, x1
    f14c:      	mov	x1, #0x1                ; =1
    f150:      	movz	x8, #0x0, lsl #48
    f154:      	b	0xf2a4 <_stogir.stack.entry-allocation?+0x17c>
    f158:      	movz	x12, #0x0, lsl #48
    f15c:      	b	0xf1d4 <_stogir.stack.entry-allocation?+0xac>
    f160:      	movz	x10, #0x0, lsl #48
    f164:      	movz	x11, #0x0, lsl #48
    f168:      	lsr	w10, w10, #0
    f16c:      	lsr	x16, x10, #0
    f170:      	cmp	x16, #0x1
    f174:      	b.eq	0xf190 <_stogir.stack.entry-allocation?+0x68>
    f178:      	b.lo	0xf180 <_stogir.stack.entry-allocation?+0x58>
    f17c:      	b	0xf194 <_stogir.stack.entry-allocation?+0x6c>
    f180:      	cmp	x16, #0x0
    f184:      	b.eq	0xf18c <_stogir.stack.entry-allocation?+0x64>
    f188:      	b	0xf194 <_stogir.stack.entry-allocation?+0x6c>
    f18c:      	b	0xf1b4 <_stogir.stack.entry-allocation?+0x8c>
    f190:      	b	0xf198 <_stogir.stack.entry-allocation?+0x70>
    f194:      	b	0xf4f0 <_stogir.stack.entry-allocation?+0x3c8>
    f198:      	uxtb	w10, w11
    f19c:      	lsr	w11, w11, #0
    f1a0:      	ubfx	x11, x11, #8, #8
    f1a4:      	cmp	x10, x11
    f1a8:      	b.eq	0xf4e0 <_stogir.stack.entry-allocation?+0x3b8>
    f1ac:      	cmp	x10, #0x49
    f1b0:      	b.eq	0xf4e0 <_stogir.stack.entry-allocation?+0x3b8>
    f1b4:      	movz	x1, #0x0, lsl #48
    f1b8:      	fmov	d31, x8
    f1bc:      	mov	x8, x9
    f1c0:      	fmov	x9, d31
    f1c4:      	b	0xf390 <_stogir.stack.entry-allocation?+0x268>
    f1c8:      	movz	x12, #0x0, lsl #48
    f1cc:      	b	0xf1dc <_stogir.stack.entry-allocation?+0xb4>
    f1d0:      	movz	x12, #0x0, lsl #48
    f1d4:      	b	0xf1e4 <_stogir.stack.entry-allocation?+0xbc>
    f1d8:      	movz	x12, #0x0, lsl #48
    f1dc:      	b	0xf1e4 <_stogir.stack.entry-allocation?+0xbc>
    f1e0:      	movz	x12, #0x0, lsl #48
    f1e4:      	cmp	x12, #0x0
    f1e8:      	b.eq	0xf24c <_stogir.stack.entry-allocation?+0x124>
    f1ec:      	uxtb	w16, w11
    f1f0:      	cmp	w16, wzr
    f1f4:      	b.eq	0xf21c <_stogir.stack.entry-allocation?+0xf4>
    f1f8:      	lsl	x11, x10, #4
    f1fc:      	ldr	x11, [x0]
    f200:      	add	x10, x11, x10, lsl #4
    f204:      	ldr	x11, [x10]
    f208:      	ldr	x10, [x10, #0x8]
    f20c:      	fmov	d31, x10
    f210:      	mov	x10, x11
    f214:      	fmov	x11, d31
    f218:      	b	0xf23c <_stogir.stack.entry-allocation?+0x114>
    f21c:      	lsl	x10, x13, #4
    f220:      	ldr	x10, [x0, #0x28]
    f224:      	add	x10, x10, x13, lsl #4
    f228:      	ldr	x11, [x10]
    f22c:      	ldr	x10, [x10, #0x8]
    f230:      	fmov	d31, x10
    f234:      	mov	x10, x11
    f238:      	fmov	x11, d31
    f23c:      	mov	x12, x11
    f240:      	mov	x11, x10
    f244:      	mov	x10, #0x1               ; =1
    f248:      	b	0xf258 <_stogir.stack.entry-allocation?+0x130>
    f24c:      	movz	x10, #0x0, lsl #48
    f250:      	movz	x11, #0x0, lsl #48
    f254:      	movz	x12, #0x0, lsl #48
    f258:      	lsr	w10, w10, #0
    f25c:      	lsr	x16, x10, #0
    f260:      	cmp	x16, #0x1
    f264:      	b.eq	0xf280 <_stogir.stack.entry-allocation?+0x158>
    f268:      	b.lo	0xf270 <_stogir.stack.entry-allocation?+0x148>
    f26c:      	b	0xf284 <_stogir.stack.entry-allocation?+0x15c>
    f270:      	cmp	x16, #0x0
    f274:      	b.eq	0xf27c <_stogir.stack.entry-allocation?+0x154>
    f278:      	b	0xf284 <_stogir.stack.entry-allocation?+0x15c>
    f27c:      	b	0xf288 <_stogir.stack.entry-allocation?+0x160>
    f280:      	b	0xf35c <_stogir.stack.entry-allocation?+0x234>
    f284:      	b	0xf43c <_stogir.stack.entry-allocation?+0x314>
    f288:      	fmov	d31, x8
    f28c:      	mov	x8, x9
    f290:      	fmov	x9, d31
    f294:      	movz	x1, #0x0, lsl #48
    f298:      	fmov	d31, x8
    f29c:      	mov	x8, x9
    f2a0:      	fmov	x9, d31
    f2a4:      	cmp	x1, #0x0
    f2a8:      	b.eq	0xf420 <_stogir.stack.entry-allocation?+0x2f8>
    f2ac:      	cmp	x8, #0x0
    f2b0:      	b.ne	0xf420 <_stogir.stack.entry-allocation?+0x2f8>
    f2b4:      	lsr	w10, w9, #0
    f2b8:      	sxtw	x10, w10
    f2bc:      	cmp	x10, #0x0
    f2c0:      	cset	w11, gt
    f2c4:      	movz	x16, #0x0, lsl #48
    f2c8:      	sub	x12, x16, x10
    f2cc:      	sub	x13, x12, #0x1
    f2d0:      	uxtb	w16, w11
    f2d4:      	cmp	w16, wzr
    f2d8:      	b.eq	0xf318 <_stogir.stack.entry-allocation?+0x1f0>
    f2dc:      	ldr	x12, [x0, #0x8]
    f2e0:      	cmp	x10, x12
    f2e4:      	b.ge	0xf1d8 <_stogir.stack.entry-allocation?+0xb0>
    f2e8:      	ldr	x12, [x2, #0x8]
    f2ec:      	cmp	x10, x12
    f2f0:      	b.ge	0xf1c8 <_stogir.stack.entry-allocation?+0xa0>
    f2f4:      	lsl	x12, x10, #2
    f2f8:      	ldr	x12, [x0, #0x78]
    f2fc:      	add	x12, x12, x10, lsl #2
    f300:      	ldr	w12, [x12]
    f304:      	sxtw	x12, w12
    f308:      	cmp	x12, #0x0
    f30c:      	cset	w12, ge
    f310:      	ubfx	x12, x12, #0, #8
    f314:      	b	0xf1cc <_stogir.stack.entry-allocation?+0xa4>
    f318:      	cmp	x10, #0x0
    f31c:      	b.ge	0xf1e0 <_stogir.stack.entry-allocation?+0xb8>
    f320:      	ldr	x14, [x3, #0x8]
    f324:      	ldr	x15, [x4, #0x8]
    f328:      	cmp	x14, x15
    f32c:      	b.ne	0xf1d0 <_stogir.stack.entry-allocation?+0xa8>
    f330:      	cmp	x12, x14
    f334:      	b.gt	0xf158 <_stogir.stack.entry-allocation?+0x30>
    f338:      	lsl	x12, x13, #2
    f33c:      	ldr	x12, [x0, #0x50]
    f340:      	add	x12, x12, x13, lsl #2
    f344:      	ldr	w12, [x12]
    f348:      	sxtw	x12, w12
    f34c:      	cmp	x12, #0x0
    f350:      	cset	w12, gt
    f354:      	ubfx	x12, x12, #0, #8
    f358:      	b	0xf15c <_stogir.stack.entry-allocation?+0x34>
    f35c:      	uxtb	w10, w11
    f360:      	asr	x13, x11, #32
    f364:      	mov	x16, sp
    f368:      	str	x11, [x16]
    f36c:      	mov	x16, sp
    f370:      	str	x12, [x16, #0x8]
    f374:      	cmp	x10, #0x68
    f378:      	b.ne	0xf394 <_stogir.stack.entry-allocation?+0x26c>
    f37c:      	cmp	x13, #0x0
    f380:      	cset	w1, eq
    f384:      	ubfx	x1, x1, #0, #8
    f388:      	mov	x8, x9
    f38c:      	mov	x9, #0x1                ; =1
    f390:      	b	0xf298 <_stogir.stack.entry-allocation?+0x170>
    f394:      	cmp	x9, #0x0
    f398:      	b.le	0xf1b4 <_stogir.stack.entry-allocation?+0x8c>
    f39c:      	cmp	x10, #0x51
    f3a0:      	b.ne	0xf1b4 <_stogir.stack.entry-allocation?+0x8c>
    f3a4:      	cmp	x13, #0x0
    f3a8:      	b.le	0xf1b4 <_stogir.stack.entry-allocation?+0x8c>
    f3ac:      	cmp	x13, x9
    f3b0:      	b.ge	0xf1b4 <_stogir.stack.entry-allocation?+0x8c>
    f3b4:      	lsr	w12, w12, #0
    f3b8:      	sxtw	x12, w12
    f3bc:      	cmp	x12, #0x0
    f3c0:      	b.ge	0xf1b4 <_stogir.stack.entry-allocation?+0x8c>
    f3c4:      	cmp	x12, #0x0
    f3c8:      	cset	w10, gt
    f3cc:      	movz	x16, #0x0, lsl #48
    f3d0:      	sub	x11, x16, x12
    f3d4:      	sub	x13, x11, #0x1
    f3d8:      	uxtb	w16, w10
    f3dc:      	cmp	w16, wzr
    f3e0:      	b.eq	0xf494 <_stogir.stack.entry-allocation?+0x36c>
    f3e4:      	ldr	x11, [x0, #0x8]
    f3e8:      	cmp	x12, x11
    f3ec:      	b.ge	0xf48c <_stogir.stack.entry-allocation?+0x364>
    f3f0:      	ldr	x11, [x5, #0x8]
    f3f4:      	cmp	x12, x11
    f3f8:      	b.ge	0xf4d8 <_stogir.stack.entry-allocation?+0x3b0>
    f3fc:      	lsl	x11, x12, #2
    f400:      	ldr	x11, [x0, #0x78]
    f404:      	add	x11, x11, x12, lsl #2
    f408:      	ldr	w11, [x11]
    f40c:      	sxtw	x11, w11
    f410:      	cmp	x11, #0x0
    f414:      	cset	w11, ge
    f418:      	ubfx	x11, x11, #0, #8
    f41c:      	b	0xf4dc <_stogir.stack.entry-allocation?+0x3b4>
    f420:      	cmp	x1, #0x0
    f424:      	b.eq	0xf430 <_stogir.stack.entry-allocation?+0x308>
    f428:      	mov	x0, x8
    f42c:      	b	0xf434 <_stogir.stack.entry-allocation?+0x30c>
    f430:      	movz	x0, #0x0, lsl #48
    f434:      	add	sp, sp, #0x10
    f438:      	ret
    f43c:      	brk	#0
    f440:      	b	0xf43c <_stogir.stack.entry-allocation?+0x314>
    f444:      	lsl	x10, x13, #4
    f448:      	ldr	x10, [x0, #0x28]
    f44c:      	add	x10, x10, x13, lsl #4
    f450:      	ldr	x10, [x10]
    f454:      	mov	x11, x10
    f458:      	mov	x10, #0x1               ; =1
    f45c:      	b	0xf168 <_stogir.stack.entry-allocation?+0x40>
    f460:      	movz	x11, #0x0, lsl #48
    f464:      	cmp	x11, #0x0
    f468:      	b.eq	0xf160 <_stogir.stack.entry-allocation?+0x38>
    f46c:      	uxtb	w16, w10
    f470:      	cmp	w16, wzr
    f474:      	b.eq	0xf444 <_stogir.stack.entry-allocation?+0x31c>
    f478:      	lsl	x10, x12, #4
    f47c:      	ldr	x10, [x0]
    f480:      	add	x10, x10, x12, lsl #4
    f484:      	ldr	x10, [x10]
    f488:      	b	0xf454 <_stogir.stack.entry-allocation?+0x32c>
    f48c:      	movz	x11, #0x0, lsl #48
    f490:      	b	0xf464 <_stogir.stack.entry-allocation?+0x33c>
    f494:      	ldr	x14, [x6, #0x8]
    f498:      	ldr	x15, [x7, #0x8]
    f49c:      	cmp	x14, x15
    f4a0:      	b.ne	0xf460 <_stogir.stack.entry-allocation?+0x338>
    f4a4:      	cmp	x11, x14
    f4a8:      	b.gt	0xf4d0 <_stogir.stack.entry-allocation?+0x3a8>
    f4ac:      	lsl	x11, x13, #2
    f4b0:      	ldr	x11, [x0, #0x50]
    f4b4:      	add	x11, x11, x13, lsl #2
    f4b8:      	ldr	w11, [x11]
    f4bc:      	sxtw	x11, w11
    f4c0:      	cmp	x11, #0x0
    f4c4:      	cset	w11, gt
    f4c8:      	ubfx	x11, x11, #0, #8
    f4cc:      	b	0xf4d4 <_stogir.stack.entry-allocation?+0x3ac>
    f4d0:      	movz	x11, #0x0, lsl #48
    f4d4:      	b	0xf464 <_stogir.stack.entry-allocation?+0x33c>
    f4d8:      	movz	x11, #0x0, lsl #48
    f4dc:      	b	0xf490 <_stogir.stack.entry-allocation?+0x368>
    f4e0:      	mov	x16, sp
    f4e4:      	ldr	w9, [x16, #0x4]
    f4e8:      	sxtw	x9, w9
    f4ec:      	b	0xf1b8 <_stogir.stack.entry-allocation?+0x90>
    f4f0:      	brk	#0
    f4f4:      	b	0xf4f0 <_stogir.stack.entry-allocation?+0x3c8>

000000000000f4f8 <_stogir.stack.constant-size>:
    f4f8:      	sub	sp, sp, #0x10
    f4fc:      	str	x29, [sp]
    f500:      	str	x30, [sp, #0x8]
    f504:      	mov	x29, sp
    f508:      	mov	x2, sp
    f50c:      	sxtw	x1, w1
    f510:      	sub	sp, sp, #0x10
    f514:      	mov	x3, sp
    f518:      	cmp	x1, #0x0
    f51c:      	cset	w4, gt
    f520:      	movz	x16, #0x0, lsl #48
    f524:      	sub	x5, x16, x1
    f528:      	sub	x6, x5, #0x1
    f52c:      	uxtb	w16, w4
    f530:      	cmp	w16, wzr
    f534:      	b.eq	0xf578 <_stogir.stack.constant-size+0x80>
    f538:      	ldr	x5, [x0, #0x8]
    f53c:      	cmp	x1, x5
    f540:      	b.ge	0xf5cc <_stogir.stack.constant-size+0xd4>
    f544:      	add	x5, x0, #0x78
    f548:      	ldr	x5, [x5, #0x8]
    f54c:      	cmp	x1, x5
    f550:      	b.ge	0xf740 <_stogir.stack.constant-size+0x248>
    f554:      	lsl	x5, x1, #2
    f558:      	ldr	x5, [x0, #0x78]
    f55c:      	add	x5, x5, x1, lsl #2
    f560:      	ldr	w5, [x5]
    f564:      	sxtw	x5, w5
    f568:      	cmp	x5, #0x0
    f56c:      	cset	w5, ge
    f570:      	ubfx	x5, x5, #0, #8
    f574:      	b	0xf744 <_stogir.stack.constant-size+0x24c>
    f578:      	cmp	x1, #0x0
    f57c:      	b.ge	0xf5d4 <_stogir.stack.constant-size+0xdc>
    f580:      	add	x7, x0, #0x28
    f584:      	add	x9, x0, #0x50
    f588:      	ldr	x7, [x7, #0x8]
    f58c:      	ldr	x9, [x9, #0x8]
    f590:      	cmp	x7, x9
    f594:      	b.ne	0xf5c4 <_stogir.stack.constant-size+0xcc>
    f598:      	cmp	x5, x7
    f59c:      	b.gt	0xf7c8 <_stogir.stack.constant-size+0x2d0>
    f5a0:      	lsl	x5, x6, #2
    f5a4:      	ldr	x5, [x0, #0x50]
    f5a8:      	add	x5, x5, x6, lsl #2
    f5ac:      	ldr	w5, [x5]
    f5b0:      	sxtw	x5, w5
    f5b4:      	cmp	x5, #0x0
    f5b8:      	cset	w5, gt
    f5bc:      	ubfx	x5, x5, #0, #8
    f5c0:      	b	0xf7cc <_stogir.stack.constant-size+0x2d4>
    f5c4:      	movz	x5, #0x0, lsl #48
    f5c8:      	b	0xf5d8 <_stogir.stack.constant-size+0xe0>
    f5cc:      	movz	x5, #0x0, lsl #48
    f5d0:      	b	0xf5d8 <_stogir.stack.constant-size+0xe0>
    f5d4:      	movz	x5, #0x0, lsl #48
    f5d8:      	cmp	x5, #0x0
    f5dc:      	b.eq	0xf640 <_stogir.stack.constant-size+0x148>
    f5e0:      	uxtb	w16, w4
    f5e4:      	cmp	w16, wzr
    f5e8:      	b.eq	0xf610 <_stogir.stack.constant-size+0x118>
    f5ec:      	lsl	x4, x1, #4
    f5f0:      	ldr	x0, [x0]
    f5f4:      	add	x0, x0, x1, lsl #4
    f5f8:      	ldr	x4, [x0]
    f5fc:      	ldr	x0, [x0, #0x8]
    f600:      	fmov	d31, x0
    f604:      	mov	x0, x4
    f608:      	fmov	x4, d31
    f60c:      	b	0xf630 <_stogir.stack.constant-size+0x138>
    f610:      	lsl	x4, x6, #4
    f614:      	ldr	x0, [x0, #0x28]
    f618:      	add	x0, x0, x6, lsl #4
    f61c:      	ldr	x4, [x0]
    f620:      	ldr	x0, [x0, #0x8]
    f624:      	fmov	d31, x0
    f628:      	mov	x0, x4
    f62c:      	fmov	x4, d31
    f630:      	mov	x5, x4
    f634:      	mov	x4, x0
    f638:      	mov	x0, #0x1                ; =1
    f63c:      	b	0xf64c <_stogir.stack.constant-size+0x154>
    f640:      	movz	x0, #0x0, lsl #48
    f644:      	movz	x4, #0x0, lsl #48
    f648:      	movz	x5, #0x0, lsl #48
    f64c:      	lsr	w0, w0, #0
    f650:      	lsr	x16, x0, #0
    f654:      	cmp	x16, #0x1
    f658:      	b.eq	0xf674 <_stogir.stack.constant-size+0x17c>
    f65c:      	b.lo	0xf664 <_stogir.stack.constant-size+0x16c>
    f660:      	b	0xf678 <_stogir.stack.constant-size+0x180>
    f664:      	cmp	x16, #0x0
    f668:      	b.eq	0xf670 <_stogir.stack.constant-size+0x178>
    f66c:      	b	0xf678 <_stogir.stack.constant-size+0x180>
    f670:      	b	0xf67c <_stogir.stack.constant-size+0x184>
    f674:      	b	0xf720 <_stogir.stack.constant-size+0x228>
    f678:      	b	0xf880 <_stogir.stack.constant-size+0x388>
    f67c:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3f4>
		000000000000f67c:  ARM64_RELOC_PAGE21	l_stogir.510
    f680:      	ldr	x16, [x16]
		000000000000f680:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    f684:      	orr	x0, x16, xzr
    f688:      	mov	x1, x0
    f68c:      	mov	x0, #0x1                ; =1
    f690:      	mov	x3, #0x18               ; =24
    f694:      	b	0xf6fc <_stogir.stack.constant-size+0x204>
    f698:      	mov	x4, #0x1                ; =1
    f69c:      	ldr	w5, [x3, #0x8]
    f6a0:      	ldr	w6, [x3, #0xc]
    f6a4:      	cmp	x1, #0x0
    f6a8:      	b.ge	0xf6e4 <_stogir.stack.constant-size+0x1ec>
    f6ac:      	cmp	x0, #0x1
    f6b0:      	b.lt	0xf6e4 <_stogir.stack.constant-size+0x1ec>
    f6b4:      	cmp	x0, #0xb
    f6b8:      	cset	w1, le
    f6bc:      	uxtb	w16, w1
    f6c0:      	cmp	w16, wzr
    f6c4:      	b.eq	0xf6e4 <_stogir.stack.constant-size+0x1ec>
    f6c8:      	ldr	w3, [x3]
    f6cc:      	uxtb	w7, w3
    f6d0:      	ubfx	x3, x3, #8, #8
    f6d4:      	cmp	x7, x3
    f6d8:      	b.eq	0xf7d0 <_stogir.stack.constant-size+0x2d8>
    f6dc:      	cmp	x7, #0x49
    f6e0:      	b.eq	0xf7d0 <_stogir.stack.constant-size+0x2d8>
    f6e4:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3f4>
		000000000000f6e4:  ARM64_RELOC_PAGE21	l_stogir.511
    f6e8:      	ldr	x16, [x16]
		000000000000f6e8:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    f6ec:      	orr	x0, x16, xzr
    f6f0:      	mov	x1, x0
    f6f4:      	mov	x0, #0x1                ; =1
    f6f8:      	mov	x3, #0x30               ; =48
    f6fc:      	mov	sp, x2
    f700:      	str	x0, [x8]
    f704:      	str	x1, [x8, #0x8]
    f708:      	str	x3, [x8, #0x10]
    f70c:      	sub	sp, x29, #0x0
    f710:      	ldr	x29, [sp]
    f714:      	ldr	x30, [sp, #0x8]
    f718:      	add	sp, sp, #0x10
    f71c:      	ret
    f720:      	lsr	w0, w4, #0
    f724:      	str	x4, [x3]
    f728:      	str	x5, [x3, #0x8]
    f72c:      	ubfx	x0, x0, #8, #8
    f730:      	cmp	x0, #0x0
    f734:      	b.ne	0xf748 <_stogir.stack.constant-size+0x250>
    f738:      	movz	x4, #0x0, lsl #48
    f73c:      	b	0xf69c <_stogir.stack.constant-size+0x1a4>
    f740:      	movz	x5, #0x0, lsl #48
    f744:      	b	0xf5d0 <_stogir.stack.constant-size+0xd8>
    f748:      	cmp	x0, #0x1
    f74c:      	b.eq	0xf698 <_stogir.stack.constant-size+0x1a0>
    f750:      	cmp	x0, #0x2
    f754:      	b.eq	0xf698 <_stogir.stack.constant-size+0x1a0>
    f758:      	cmp	x0, #0x7
    f75c:      	b.eq	0xf698 <_stogir.stack.constant-size+0x1a0>
    f760:      	cmp	x0, #0x8
    f764:      	b.eq	0xf698 <_stogir.stack.constant-size+0x1a0>
    f768:      	cmp	x0, #0x3
    f76c:      	b.eq	0xf878 <_stogir.stack.constant-size+0x380>
    f770:      	cmp	x0, #0x9
    f774:      	b.eq	0xf878 <_stogir.stack.constant-size+0x380>
    f778:      	cmp	x0, #0x4
    f77c:      	b.eq	0xf888 <_stogir.stack.constant-size+0x390>
    f780:      	cmp	x0, #0xa
    f784:      	b.eq	0xf888 <_stogir.stack.constant-size+0x390>
    f788:      	cmp	x0, #0xd
    f78c:      	b.eq	0xf888 <_stogir.stack.constant-size+0x390>
    f790:      	cmp	x0, #0x5
    f794:      	b.eq	0xf890 <_stogir.stack.constant-size+0x398>
    f798:      	cmp	x0, #0xb
    f79c:      	b.eq	0xf890 <_stogir.stack.constant-size+0x398>
    f7a0:      	cmp	x0, #0xc
    f7a4:      	b.eq	0xf890 <_stogir.stack.constant-size+0x398>
    f7a8:      	cmp	x0, #0x6
    f7ac:      	cset	w4, eq
    f7b0:      	uxtb	w16, w4
    f7b4:      	cmp	w16, wzr
    f7b8:      	mov	x16, #0x8               ; =8
    f7bc:      	movn	x17, #0x0, lsl #48
    f7c0:      	csel	x4, x16, x17, ne
    f7c4:      	b	0xf894 <_stogir.stack.constant-size+0x39c>
    f7c8:      	movz	x5, #0x0, lsl #48
    f7cc:      	b	0xf5c8 <_stogir.stack.constant-size+0xd0>
    f7d0:      	lsr	w4, w4, #0
    f7d4:      	sxtw	x4, w4
    f7d8:      	cmp	x4, #0x0
    f7dc:      	b.le	0xf6e4 <_stogir.stack.constant-size+0x1ec>
    f7e0:      	ubfx	x5, x5, #0, #32
    f7e4:      	ubfx	x6, x6, #0, #32
    f7e8:      	lsl	x3, x6, #32
    f7ec:      	orr	x3, x3, x5
    f7f0:      	cmp	x4, #0x8
    f7f4:      	b.ge	0xf810 <_stogir.stack.constant-size+0x318>
    f7f8:      	lsl	x5, x4, #3
    f7fc:      	lsr	w5, w5, #0
    f800:      	sxtw	x5, w5
    f804:      	lsr	x5, x3, x5
    f808:      	cmp	x5, #0x0
    f80c:      	b.ne	0xf6e4 <_stogir.stack.constant-size+0x1ec>
    f810:      	cmp	x0, #0x7
    f814:      	b.lt	0xf850 <_stogir.stack.constant-size+0x358>
    f818:      	uxtb	w16, w1
    f81c:      	cmp	w16, wzr
    f820:      	b.eq	0xf850 <_stogir.stack.constant-size+0x358>
    f824:      	lsl	x0, x4, #3
    f828:      	lsr	w0, w0, #0
    f82c:      	sxtw	x0, w0
    f830:      	sub	x0, x0, #0x1
    f834:      	lsr	w0, w0, #0
    f838:      	sxtw	x0, w0
    f83c:      	mov	x16, #0x1               ; =1
    f840:      	lsl	x0, x16, x0
    f844:      	and	x0, x0, x3
    f848:      	cmp	x0, #0x0
    f84c:      	b.ne	0xf6e4 <_stogir.stack.constant-size+0x1ec>
    f850:      	mov	x17, #-0x10             ; =-16
    f854:      	movk	x17, #0x7fff, lsl #48
    f858:      	cmp	x3, x17
    f85c:      	b.hi	0xf6e4 <_stogir.stack.constant-size+0x1ec>
    f860:      	add	x0, x3, #0xf
    f864:      	and	x0, x0, #0xfffffffffffffff0
    f868:      	mov	x1, x0
    f86c:      	movz	x0, #0x0, lsl #48
    f870:      	movz	x3, #0x0, lsl #48
    f874:      	b	0xf6fc <_stogir.stack.constant-size+0x204>
    f878:      	mov	x4, #0x2                ; =2
    f87c:      	b	0xf69c <_stogir.stack.constant-size+0x1a4>
    f880:      	brk	#0
    f884:      	b	0xf880 <_stogir.stack.constant-size+0x388>
    f888:      	mov	x4, #0x4                ; =4
    f88c:      	b	0xf87c <_stogir.stack.constant-size+0x384>
    f890:      	mov	x4, #0x8                ; =8
    f894:      	b	0xf88c <_stogir.stack.constant-size+0x394>

000000000000f898 <_stogir.frame.valid-alignment?>:
    f898:      	cmp	x0, #0x0
    f89c:      	b.le	0xf8b8 <_stogir.frame.valid-alignment?+0x20>
    f8a0:      	sub	x1, x0, #0x1
    f8a4:      	and	x0, x1, x0
    f8a8:      	cmp	x0, #0x0
    f8ac:      	cset	w0, eq
    f8b0:      	ubfx	x0, x0, #0, #8
    f8b4:      	b	0xf8bc <_stogir.frame.valid-alignment?+0x24>
    f8b8:      	movz	x0, #0x0, lsl #48
    f8bc:      	ret

000000000000f8c0 <_stogir.stack.constant-size-aligned>:
    f8c0:      	sub	sp, sp, #0x10
    f8c4:      	cmp	x2, #0x10
    f8c8:      	b.lt	0xf948 <_stogir.stack.constant-size-aligned+0x88>
    f8cc:      	cmp	x2, #0x0
    f8d0:      	b.le	0xf948 <_stogir.stack.constant-size-aligned+0x88>
    f8d4:      	sub	x3, x2, #0x1
    f8d8:      	and	x3, x3, x2
    f8dc:      	cmp	x3, #0x0
    f8e0:      	b.ne	0xf948 <_stogir.stack.constant-size-aligned+0x88>
    f8e4:      	sxtw	x1, w1
    f8e8:      	cmp	x1, #0x0
    f8ec:      	cset	w3, gt
    f8f0:      	movz	x16, #0x0, lsl #48
    f8f4:      	sub	x4, x16, x1
    f8f8:      	sub	x5, x4, #0x1
    f8fc:      	uxtb	w16, w3
    f900:      	cmp	w16, wzr
    f904:      	b.eq	0xf9e8 <_stogir.stack.constant-size-aligned+0x128>
    f908:      	ldr	x4, [x0, #0x8]
    f90c:      	cmp	x1, x4
    f910:      	b.ge	0xfa34 <_stogir.stack.constant-size-aligned+0x174>
    f914:      	add	x4, x0, #0x78
    f918:      	ldr	x4, [x4, #0x8]
    f91c:      	cmp	x1, x4
    f920:      	b.ge	0xfb30 <_stogir.stack.constant-size-aligned+0x270>
    f924:      	lsl	x4, x1, #2
    f928:      	ldr	x4, [x0, #0x78]
    f92c:      	add	x4, x4, x1, lsl #2
    f930:      	ldr	w4, [x4]
    f934:      	sxtw	x4, w4
    f938:      	cmp	x4, #0x0
    f93c:      	cset	w4, ge
    f940:      	ubfx	x4, x4, #0, #8
    f944:      	b	0xfb34 <_stogir.stack.constant-size-aligned+0x274>
    f948:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3f4>
		000000000000f948:  ARM64_RELOC_PAGE21	l_stogir.512
    f94c:      	ldr	x16, [x16]
		000000000000f94c:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    f950:      	orr	x0, x16, xzr
    f954:      	mov	x1, x0
    f958:      	mov	x0, #0x1                ; =1
    f95c:      	mov	x2, #0x20               ; =32
    f960:      	str	x0, [x8]
    f964:      	str	x1, [x8, #0x8]
    f968:      	str	x2, [x8, #0x10]
    f96c:      	add	sp, sp, #0x10
    f970:      	ret
    f974:      	mov	x3, #0x1                ; =1
    f978:      	mov	x16, sp
    f97c:      	ldr	w4, [x16, #0x8]
    f980:      	mov	x16, sp
    f984:      	ldr	w5, [x16, #0xc]
    f988:      	cmp	x1, #0x0
    f98c:      	b.ge	0xf9cc <_stogir.stack.constant-size-aligned+0x10c>
    f990:      	cmp	x0, #0x1
    f994:      	b.lt	0xf9cc <_stogir.stack.constant-size-aligned+0x10c>
    f998:      	cmp	x0, #0xb
    f99c:      	cset	w1, le
    f9a0:      	uxtb	w16, w1
    f9a4:      	cmp	w16, wzr
    f9a8:      	b.eq	0xf9cc <_stogir.stack.constant-size-aligned+0x10c>
    f9ac:      	mov	x16, sp
    f9b0:      	ldr	w6, [x16]
    f9b4:      	uxtb	w7, w6
    f9b8:      	ubfx	x6, x6, #8, #8
    f9bc:      	cmp	x7, x6
    f9c0:      	b.eq	0xfbc0 <_stogir.stack.constant-size-aligned+0x300>
    f9c4:      	cmp	x7, #0x49
    f9c8:      	b.eq	0xfbc0 <_stogir.stack.constant-size-aligned+0x300>
    f9cc:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3f4>
		000000000000f9cc:  ARM64_RELOC_PAGE21	l_stogir.513
    f9d0:      	ldr	x16, [x16]
		000000000000f9d0:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    f9d4:      	orr	x0, x16, xzr
    f9d8:      	mov	x1, x0
    f9dc:      	mov	x0, #0x1                ; =1
    f9e0:      	mov	x2, #0x30               ; =48
    f9e4:      	b	0xf960 <_stogir.stack.constant-size-aligned+0xa0>
    f9e8:      	cmp	x1, #0x0
    f9ec:      	b.ge	0xfa3c <_stogir.stack.constant-size-aligned+0x17c>
    f9f0:      	add	x6, x0, #0x28
    f9f4:      	add	x7, x0, #0x50
    f9f8:      	ldr	x6, [x6, #0x8]
    f9fc:      	ldr	x7, [x7, #0x8]
    fa00:      	cmp	x6, x7
    fa04:      	b.ne	0xfb28 <_stogir.stack.constant-size-aligned+0x268>
    fa08:      	cmp	x4, x6
    fa0c:      	b.gt	0xfbb8 <_stogir.stack.constant-size-aligned+0x2f8>
    fa10:      	lsl	x4, x5, #2
    fa14:      	ldr	x4, [x0, #0x50]
    fa18:      	add	x4, x4, x5, lsl #2
    fa1c:      	ldr	w4, [x4]
    fa20:      	sxtw	x4, w4
    fa24:      	cmp	x4, #0x0
    fa28:      	cset	w4, gt
    fa2c:      	ubfx	x4, x4, #0, #8
    fa30:      	b	0xfbbc <_stogir.stack.constant-size-aligned+0x2fc>
    fa34:      	movz	x4, #0x0, lsl #48
    fa38:      	b	0xfa40 <_stogir.stack.constant-size-aligned+0x180>
    fa3c:      	movz	x4, #0x0, lsl #48
    fa40:      	cmp	x4, #0x0
    fa44:      	b.eq	0xfaa8 <_stogir.stack.constant-size-aligned+0x1e8>
    fa48:      	uxtb	w16, w3
    fa4c:      	cmp	w16, wzr
    fa50:      	b.eq	0xfa78 <_stogir.stack.constant-size-aligned+0x1b8>
    fa54:      	lsl	x3, x1, #4
    fa58:      	ldr	x0, [x0]
    fa5c:      	add	x0, x0, x1, lsl #4
    fa60:      	ldr	x3, [x0]
    fa64:      	ldr	x0, [x0, #0x8]
    fa68:      	fmov	d31, x0
    fa6c:      	mov	x0, x3
    fa70:      	fmov	x3, d31
    fa74:      	b	0xfa98 <_stogir.stack.constant-size-aligned+0x1d8>
    fa78:      	lsl	x3, x5, #4
    fa7c:      	ldr	x0, [x0, #0x28]
    fa80:      	add	x0, x0, x5, lsl #4
    fa84:      	ldr	x3, [x0]
    fa88:      	ldr	x0, [x0, #0x8]
    fa8c:      	fmov	d31, x0
    fa90:      	mov	x0, x3
    fa94:      	fmov	x3, d31
    fa98:      	mov	x4, x3
    fa9c:      	mov	x3, x0
    faa0:      	mov	x0, #0x1                ; =1
    faa4:      	b	0xfab4 <_stogir.stack.constant-size-aligned+0x1f4>
    faa8:      	movz	x0, #0x0, lsl #48
    faac:      	movz	x3, #0x0, lsl #48
    fab0:      	movz	x4, #0x0, lsl #48
    fab4:      	lsr	w0, w0, #0
    fab8:      	lsr	x16, x0, #0
    fabc:      	cmp	x16, #0x1
    fac0:      	b.eq	0xfadc <_stogir.stack.constant-size-aligned+0x21c>
    fac4:      	b.lo	0xfacc <_stogir.stack.constant-size-aligned+0x20c>
    fac8:      	b	0xfae0 <_stogir.stack.constant-size-aligned+0x220>
    facc:      	cmp	x16, #0x0
    fad0:      	b.eq	0xfad8 <_stogir.stack.constant-size-aligned+0x218>
    fad4:      	b	0xfae0 <_stogir.stack.constant-size-aligned+0x220>
    fad8:      	b	0xfae4 <_stogir.stack.constant-size-aligned+0x224>
    fadc:      	b	0xfb00 <_stogir.stack.constant-size-aligned+0x240>
    fae0:      	b	0xfc80 <_stogir.stack.constant-size-aligned+0x3c0>
    fae4:      	adrp	x16, 0xf000 <_stogir.switch.key+0x3f4>
		000000000000fae4:  ARM64_RELOC_PAGE21	l_stogir.514
    fae8:      	ldr	x16, [x16]
		000000000000fae8:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    faec:      	orr	x0, x16, xzr
    faf0:      	mov	x1, x0
    faf4:      	mov	x0, #0x1                ; =1
    faf8:      	mov	x2, #0x18               ; =24
    fafc:      	b	0xf9e4 <_stogir.stack.constant-size-aligned+0x124>
    fb00:      	lsr	w0, w3, #0
    fb04:      	mov	x16, sp
    fb08:      	str	x3, [x16]
    fb0c:      	mov	x16, sp
    fb10:      	str	x4, [x16, #0x8]
    fb14:      	ubfx	x0, x0, #8, #8
    fb18:      	cmp	x0, #0x0
    fb1c:      	b.ne	0xfb38 <_stogir.stack.constant-size-aligned+0x278>
    fb20:      	movz	x3, #0x0, lsl #48
    fb24:      	b	0xf978 <_stogir.stack.constant-size-aligned+0xb8>
    fb28:      	movz	x4, #0x0, lsl #48
    fb2c:      	b	0xfa40 <_stogir.stack.constant-size-aligned+0x180>
    fb30:      	movz	x4, #0x0, lsl #48
    fb34:      	b	0xfa38 <_stogir.stack.constant-size-aligned+0x178>
    fb38:      	cmp	x0, #0x1
    fb3c:      	b.eq	0xf974 <_stogir.stack.constant-size-aligned+0xb4>
    fb40:      	cmp	x0, #0x2
    fb44:      	b.eq	0xf974 <_stogir.stack.constant-size-aligned+0xb4>
    fb48:      	cmp	x0, #0x7
    fb4c:      	b.eq	0xf974 <_stogir.stack.constant-size-aligned+0xb4>
    fb50:      	cmp	x0, #0x8
    fb54:      	b.eq	0xf974 <_stogir.stack.constant-size-aligned+0xb4>
    fb58:      	cmp	x0, #0x3
    fb5c:      	b.eq	0xfc78 <_stogir.stack.constant-size-aligned+0x3b8>
    fb60:      	cmp	x0, #0x9
    fb64:      	b.eq	0xfc78 <_stogir.stack.constant-size-aligned+0x3b8>
    fb68:      	cmp	x0, #0x4
    fb6c:      	b.eq	0xfc88 <_stogir.stack.constant-size-aligned+0x3c8>
    fb70:      	cmp	x0, #0xa
    fb74:      	b.eq	0xfc88 <_stogir.stack.constant-size-aligned+0x3c8>
    fb78:      	cmp	x0, #0xd
    fb7c:      	b.eq	0xfc88 <_stogir.stack.constant-size-aligned+0x3c8>
    fb80:      	cmp	x0, #0x5
    fb84:      	b.eq	0xfc90 <_stogir.stack.constant-size-aligned+0x3d0>
    fb88:      	cmp	x0, #0xb
    fb8c:      	b.eq	0xfc90 <_stogir.stack.constant-size-aligned+0x3d0>
    fb90:      	cmp	x0, #0xc
    fb94:      	b.eq	0xfc90 <_stogir.stack.constant-size-aligned+0x3d0>
    fb98:      	cmp	x0, #0x6
    fb9c:      	cset	w3, eq
    fba0:      	uxtb	w16, w3
    fba4:      	cmp	w16, wzr
    fba8:      	mov	x16, #0x8               ; =8
    fbac:      	movn	x17, #0x0, lsl #48
    fbb0:      	csel	x3, x16, x17, ne
    fbb4:      	b	0xfc94 <_stogir.stack.constant-size-aligned+0x3d4>
    fbb8:      	movz	x4, #0x0, lsl #48
    fbbc:      	b	0xfb2c <_stogir.stack.constant-size-aligned+0x26c>
    fbc0:      	lsr	w3, w3, #0
    fbc4:      	sxtw	x3, w3
    fbc8:      	cmp	x3, #0x0
    fbcc:      	b.le	0xf9cc <_stogir.stack.constant-size-aligned+0x10c>
    fbd0:      	ubfx	x4, x4, #0, #32
    fbd4:      	ubfx	x5, x5, #0, #32
    fbd8:      	lsl	x5, x5, #32
    fbdc:      	orr	x4, x5, x4
    fbe0:      	cmp	x3, #0x8
    fbe4:      	b.ge	0xfc00 <_stogir.stack.constant-size-aligned+0x340>
    fbe8:      	lsl	x5, x3, #3
    fbec:      	lsr	w5, w5, #0
    fbf0:      	sxtw	x5, w5
    fbf4:      	lsr	x5, x4, x5
    fbf8:      	cmp	x5, #0x0
    fbfc:      	b.ne	0xf9cc <_stogir.stack.constant-size-aligned+0x10c>
    fc00:      	cmp	x0, #0x7
    fc04:      	b.lt	0xfc40 <_stogir.stack.constant-size-aligned+0x380>
    fc08:      	uxtb	w16, w1
    fc0c:      	cmp	w16, wzr
    fc10:      	b.eq	0xfc40 <_stogir.stack.constant-size-aligned+0x380>
    fc14:      	lsl	x0, x3, #3
    fc18:      	lsr	w0, w0, #0
    fc1c:      	sxtw	x0, w0
    fc20:      	sub	x0, x0, #0x1
    fc24:      	lsr	w0, w0, #0
    fc28:      	sxtw	x0, w0
    fc2c:      	mov	x16, #0x1               ; =1
    fc30:      	lsl	x0, x16, x0
    fc34:      	and	x0, x0, x4
    fc38:      	cmp	x0, #0x0
    fc3c:      	b.ne	0xf9cc <_stogir.stack.constant-size-aligned+0x10c>
    fc40:      	sub	x0, x2, #0x1
    fc44:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    fc48:      	sub	x0, x16, x0
    fc4c:      	cmp	x4, x0
    fc50:      	b.hi	0xf9cc <_stogir.stack.constant-size-aligned+0x10c>
    fc54:      	sub	x0, x2, #0x1
    fc58:      	movz	x16, #0x0, lsl #48
    fc5c:      	sub	x1, x16, x2
    fc60:      	add	x0, x0, x4
    fc64:      	and	x0, x1, x0
    fc68:      	mov	x1, x0
    fc6c:      	movz	x0, #0x0, lsl #48
    fc70:      	movz	x2, #0x0, lsl #48
    fc74:      	b	0xf9e4 <_stogir.stack.constant-size-aligned+0x124>
    fc78:      	mov	x3, #0x2                ; =2
    fc7c:      	b	0xf978 <_stogir.stack.constant-size-aligned+0xb8>
    fc80:      	brk	#0
    fc84:      	b	0xfc80 <_stogir.stack.constant-size-aligned+0x3c0>
    fc88:      	mov	x3, #0x4                ; =4
    fc8c:      	b	0xfc7c <_stogir.stack.constant-size-aligned+0x3bc>
    fc90:      	mov	x3, #0x8                ; =8
    fc94:      	b	0xfc8c <_stogir.stack.constant-size-aligned+0x3cc>

000000000000fc98 <_stogir.numeric-conversion.operation?>:
    fc98:      	sxtw	x0, w0
    fc9c:      	cmp	x0, #0x25
    fca0:      	b.lt	0xfcb4 <_stogir.numeric-conversion.operation?+0x1c>
    fca4:      	cmp	x0, #0x27
    fca8:      	cset	w0, le
    fcac:      	ubfx	x0, x0, #0, #8
    fcb0:      	b	0xfcb8 <_stogir.numeric-conversion.operation?+0x20>
    fcb4:      	movz	x0, #0x0, lsl #48
    fcb8:      	ret

000000000000fcbc <_stogir.numeric-conversion.valid-types?>:
    fcbc:      	sxtw	x0, w0
    fcc0:      	sxtw	x1, w1
    fcc4:      	sxtw	x2, w2
    fcc8:      	cmp	x2, #0xc
    fccc:      	cset	w3, eq
    fcd0:      	cmp	x2, #0xd
    fcd4:      	cset	w4, eq
    fcd8:      	ubfx	x4, x4, #0, #8
    fcdc:      	cmp	x0, #0x25
    fce0:      	b.ne	0xfd08 <_stogir.numeric-conversion.valid-types?+0x4c>
    fce4:      	cmp	x1, #0x1
    fce8:      	b.lt	0xfd70 <_stogir.numeric-conversion.valid-types?+0xb4>
    fcec:      	cmp	x1, #0xb
    fcf0:      	b.gt	0xfd70 <_stogir.numeric-conversion.valid-types?+0xb4>
    fcf4:      	uxtb	w16, w3
    fcf8:      	cmp	w16, wzr
    fcfc:      	b.eq	0xfd80 <_stogir.numeric-conversion.valid-types?+0xc4>
    fd00:      	mov	x0, #0x1                ; =1
    fd04:      	b	0xfd84 <_stogir.numeric-conversion.valid-types?+0xc8>
    fd08:      	cmp	x1, #0xc
    fd0c:      	cset	w5, eq
    fd10:      	cmp	x1, #0xd
    fd14:      	cset	w1, eq
    fd18:      	cmp	x0, #0x26
    fd1c:      	b.ne	0xfd40 <_stogir.numeric-conversion.valid-types?+0x84>
    fd20:      	uxtb	w16, w5
    fd24:      	cmp	w16, wzr
    fd28:      	b.ne	0xfd90 <_stogir.numeric-conversion.valid-types?+0xd4>
    fd2c:      	uxtb	w16, w1
    fd30:      	cmp	w16, wzr
    fd34:      	b.ne	0xfd90 <_stogir.numeric-conversion.valid-types?+0xd4>
    fd38:      	movz	x0, #0x0, lsl #48
    fd3c:      	b	0xfd6c <_stogir.numeric-conversion.valid-types?+0xb0>
    fd40:      	cmp	x0, #0x27
    fd44:      	b.ne	0xfd78 <_stogir.numeric-conversion.valid-types?+0xbc>
    fd48:      	uxtb	w16, w5
    fd4c:      	cmp	w16, wzr
    fd50:      	b.ne	0xfda8 <_stogir.numeric-conversion.valid-types?+0xec>
    fd54:      	uxtb	w16, w1
    fd58:      	cmp	w16, wzr
    fd5c:      	b.ne	0xfda8 <_stogir.numeric-conversion.valid-types?+0xec>
    fd60:      	movz	x0, #0x0, lsl #48
    fd64:      	b	0xfd8c <_stogir.numeric-conversion.valid-types?+0xd0>
    fd68:      	movz	x0, #0x0, lsl #48
    fd6c:      	b	0xfd7c <_stogir.numeric-conversion.valid-types?+0xc0>
    fd70:      	movz	x0, #0x0, lsl #48
    fd74:      	b	0xfd7c <_stogir.numeric-conversion.valid-types?+0xc0>
    fd78:      	movz	x0, #0x0, lsl #48
    fd7c:      	ret
    fd80:      	mov	x0, x4
    fd84:      	b	0xfd74 <_stogir.numeric-conversion.valid-types?+0xb8>
    fd88:      	mov	x0, x4
    fd8c:      	b	0xfd7c <_stogir.numeric-conversion.valid-types?+0xc0>
    fd90:      	cmp	x2, #0x1
    fd94:      	b.lt	0xfd68 <_stogir.numeric-conversion.valid-types?+0xac>
    fd98:      	cmp	x2, #0xb
    fd9c:      	cset	w0, le
    fda0:      	ubfx	x0, x0, #0, #8
    fda4:      	b	0xfd6c <_stogir.numeric-conversion.valid-types?+0xb0>
    fda8:      	uxtb	w16, w3
    fdac:      	cmp	w16, wzr
    fdb0:      	b.eq	0xfd88 <_stogir.numeric-conversion.valid-types?+0xcc>
    fdb4:      	mov	x0, #0x1                ; =1
    fdb8:      	b	0xfd8c <_stogir.numeric-conversion.valid-types?+0xd0>

000000000000fdbc <_inherent$slice$new__stogir.node.Node>:
    fdbc:      	sub	sp, sp, #0x10
    fdc0:      	mov	x2, sp
    fdc4:      	str	x0, [x2]
    fdc8:      	str	x1, [x2, #0x8]
    fdcc:      	ldr	x0, [sp]
    fdd0:      	ldr	x1, [sp, #0x8]
    fdd4:      	add	sp, sp, #0x10
    fdd8:      	ret

000000000000fddc <_inherent$slice$data__stogir.node.Node>:
    fddc:      	ret

000000000000fde0 <_coil.slice.element-ref__stogir.node.Node>:
    fde0:      	ret

000000000000fde4 <_stogir.vector-lanes.ordinary?>:
    fde4:      	ldr	w0, [x0]
    fde8:      	uxtb	w0, w0
    fdec:      	cmp	x0, #0x48
    fdf0:      	b.ne	0xfdfc <_stogir.vector-lanes.ordinary?+0x18>
    fdf4:      	movz	x0, #0x0, lsl #48
    fdf8:      	b	0xfe10 <_stogir.vector-lanes.ordinary?+0x2c>
    fdfc:      	cmp	x0, #0x46
    fe00:      	cset	w0, eq
    fe04:      	uxtb	w16, w0
    fe08:      	cmp	w16, wzr
    fe0c:      	cset	x0, eq
    fe10:      	ret

000000000000fe14 <_stogir.vector-lanes.compatible?>:
    fe14:      	sub	sp, sp, #0x30
    fe18:      	str	x29, [sp]
    fe1c:      	str	x30, [sp, #0x8]
    fe20:      	mov	x29, sp
    fe24:      	str	x19, [sp, #0x10]
    fe28:      	str	x20, [sp, #0x18]
    fe2c:      	str	x21, [sp, #0x20]
    fe30:      	lsr	w3, w0, #0
    fe34:      	sxtw	x19, w0
    fe38:      	mov	w0, w3
    fe3c:      	mov	w20, w1
    fe40:      	mov	w21, w2
    fe44:      	bl	0xfe44 <_stogir.vector-lanes.compatible?+0x30>
		000000000000fe44:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    fe48:      	and	x1, x19, #0xf
    fe4c:      	lsr	w1, w1, #0
    fe50:      	sxtw	x1, w1
    fe54:      	cmp	x0, #0x0
    fe58:      	b.eq	0xfe64 <_stogir.vector-lanes.compatible?+0x50>
    fe5c:      	mov	x0, x1
    fe60:      	b	0xfe68 <_stogir.vector-lanes.compatible?+0x54>
    fe64:      	movn	x0, #0x0, lsl #48
    fe68:      	cmp	x19, #0xf
    fe6c:      	b.le	0xfebc <_stogir.vector-lanes.compatible?+0xa8>
    fe70:      	cmp	x19, #0x80
    fe74:      	b.ge	0xfebc <_stogir.vector-lanes.compatible?+0xa8>
    fe78:      	cmp	x1, #0x1
    fe7c:      	b.lt	0xfebc <_stogir.vector-lanes.compatible?+0xa8>
    fe80:      	cmp	x1, #0xd
    fe84:      	b.gt	0xfebc <_stogir.vector-lanes.compatible?+0xa8>
    fe88:      	sxtw	x21, w21
    fe8c:      	cmp	x21, #0x4
    fe90:      	cset	w1, eq
    fe94:      	cmp	x21, #0x8
    fe98:      	cset	w2, eq
    fe9c:      	uxtb	w16, w1
    fea0:      	cmp	w16, wzr
    fea4:      	b.ne	0xfee4 <_stogir.vector-lanes.compatible?+0xd0>
    fea8:      	uxtb	w16, w2
    feac:      	cmp	w16, wzr
    feb0:      	b.ne	0xfee4 <_stogir.vector-lanes.compatible?+0xd0>
    feb4:      	movz	x0, #0x0, lsl #48
    feb8:      	b	0xfee0 <_stogir.vector-lanes.compatible?+0xcc>
    febc:      	movz	x0, #0x0, lsl #48
    fec0:      	ldr	x19, [sp, #0x10]
    fec4:      	ldr	x20, [sp, #0x18]
    fec8:      	ldr	x21, [sp, #0x20]
    fecc:      	ldr	x29, [sp]
    fed0:      	ldr	x30, [sp, #0x8]
    fed4:      	add	sp, sp, #0x30
    fed8:      	ret
    fedc:      	movz	x0, #0x0, lsl #48
    fee0:      	b	0xfec0 <_stogir.vector-lanes.compatible?+0xac>
    fee4:      	sxtw	x20, w20
    fee8:      	cmp	x20, #0x0
    feec:      	b.lt	0xfedc <_stogir.vector-lanes.compatible?+0xc8>
    fef0:      	cmp	x20, #0xd
    fef4:      	b.gt	0xfedc <_stogir.vector-lanes.compatible?+0xc8>
    fef8:      	cmp	x20, #0x0
    fefc:      	b.le	0xff18 <_stogir.vector-lanes.compatible?+0x104>
    ff00:      	lsr	w0, w0, #0
    ff04:      	sxtw	x0, w0
    ff08:      	cmp	x0, x20
    ff0c:      	b.ne	0xff20 <_stogir.vector-lanes.compatible?+0x10c>
    ff10:      	mov	x0, #0x1                ; =1
    ff14:      	b	0xff1c <_stogir.vector-lanes.compatible?+0x108>
    ff18:      	movz	x0, #0x0, lsl #48
    ff1c:      	b	0xfee0 <_stogir.vector-lanes.compatible?+0xcc>
    ff20:      	cmp	x0, #0x1
    ff24:      	b.lt	0xff60 <_stogir.vector-lanes.compatible?+0x14c>
    ff28:      	cmp	x0, #0xb
    ff2c:      	b.gt	0xff60 <_stogir.vector-lanes.compatible?+0x14c>
    ff30:      	cmp	x20, #0x1
    ff34:      	b.lt	0xff68 <_stogir.vector-lanes.compatible?+0x154>
    ff38:      	cmp	x20, #0xb
    ff3c:      	b.gt	0xff68 <_stogir.vector-lanes.compatible?+0x154>
    ff40:      	uxtb	w16, w1
    ff44:      	cmp	w16, wzr
    ff48:      	b.ne	0xff94 <_stogir.vector-lanes.compatible?+0x180>
    ff4c:      	uxtb	w16, w2
    ff50:      	cmp	w16, wzr
    ff54:      	b.ne	0xff94 <_stogir.vector-lanes.compatible?+0x180>
    ff58:      	movn	x0, #0x0, lsl #48
    ff5c:      	b	0xffa8 <_stogir.vector-lanes.compatible?+0x194>
    ff60:      	movz	x0, #0x0, lsl #48
    ff64:      	b	0xff14 <_stogir.vector-lanes.compatible?+0x100>
    ff68:      	movz	x0, #0x0, lsl #48
    ff6c:      	b	0xff64 <_stogir.vector-lanes.compatible?+0x150>
    ff70:      	mov	x1, #0x1                ; =1
    ff74:      	lsr	w0, w0, #0
    ff78:      	sxtw	x0, w0
    ff7c:      	lsr	w1, w1, #0
    ff80:      	sxtw	x1, w1
    ff84:      	cmp	x0, x1
    ff88:      	cset	w0, eq
    ff8c:      	ubfx	x0, x0, #0, #8
    ff90:      	b	0xff6c <_stogir.vector-lanes.compatible?+0x158>
    ff94:      	cmp	x0, #0x0
    ff98:      	b.ne	0x10048 <_stogir.vector-lanes.compatible?+0x234>
    ff9c:      	movz	x0, #0x0, lsl #48
    ffa0:      	b	0xffa8 <_stogir.vector-lanes.compatible?+0x194>
    ffa4:      	mov	x0, #0x1                ; =1
    ffa8:      	uxtb	w16, w1
    ffac:      	cmp	w16, wzr
    ffb0:      	b.ne	0xffc8 <_stogir.vector-lanes.compatible?+0x1b4>
    ffb4:      	uxtb	w16, w2
    ffb8:      	cmp	w16, wzr
    ffbc:      	b.ne	0xffc8 <_stogir.vector-lanes.compatible?+0x1b4>
    ffc0:      	movn	x1, #0x0, lsl #48
    ffc4:      	b	0xff74 <_stogir.vector-lanes.compatible?+0x160>
    ffc8:      	cmp	x20, #0x0
    ffcc:      	b.ne	0xffd8 <_stogir.vector-lanes.compatible?+0x1c4>
    ffd0:      	movz	x1, #0x0, lsl #48
    ffd4:      	b	0xff74 <_stogir.vector-lanes.compatible?+0x160>
    ffd8:      	cmp	x20, #0x1
    ffdc:      	b.eq	0xff70 <_stogir.vector-lanes.compatible?+0x15c>
    ffe0:      	cmp	x20, #0x2
    ffe4:      	b.eq	0xff70 <_stogir.vector-lanes.compatible?+0x15c>
    ffe8:      	cmp	x20, #0x7
    ffec:      	b.eq	0xff70 <_stogir.vector-lanes.compatible?+0x15c>
    fff0:      	cmp	x20, #0x8
    fff4:      	b.eq	0xff70 <_stogir.vector-lanes.compatible?+0x15c>
    fff8:      	cmp	x20, #0x3
    fffc:      	b.eq	0x100b8 <_stogir.vector-lanes.compatible?+0x2a4>
   10000:      	cmp	x20, #0x9
   10004:      	b.eq	0x100b8 <_stogir.vector-lanes.compatible?+0x2a4>
   10008:      	cmp	x20, #0x4
   1000c:      	b.eq	0x100c8 <_stogir.vector-lanes.compatible?+0x2b4>
   10010:      	cmp	x20, #0xa
   10014:      	b.eq	0x100c8 <_stogir.vector-lanes.compatible?+0x2b4>
   10018:      	cmp	x20, #0xd
   1001c:      	b.eq	0x100c8 <_stogir.vector-lanes.compatible?+0x2b4>
   10020:      	cmp	x20, #0x5
   10024:      	b.eq	0x100d8 <_stogir.vector-lanes.compatible?+0x2c4>
   10028:      	cmp	x20, #0xb
   1002c:      	b.eq	0x100d8 <_stogir.vector-lanes.compatible?+0x2c4>
   10030:      	cmp	x20, #0xc
   10034:      	b.eq	0x100d8 <_stogir.vector-lanes.compatible?+0x2c4>
   10038:      	cmp	x20, #0x6
   1003c:      	b.ne	0x100e8 <_stogir.vector-lanes.compatible?+0x2d4>
   10040:      	mov	x1, x21
   10044:      	b	0x100ec <_stogir.vector-lanes.compatible?+0x2d8>
   10048:      	cmp	x0, #0x1
   1004c:      	b.eq	0xffa4 <_stogir.vector-lanes.compatible?+0x190>
   10050:      	cmp	x0, #0x2
   10054:      	b.eq	0xffa4 <_stogir.vector-lanes.compatible?+0x190>
   10058:      	cmp	x0, #0x7
   1005c:      	b.eq	0xffa4 <_stogir.vector-lanes.compatible?+0x190>
   10060:      	cmp	x0, #0x8
   10064:      	b.eq	0xffa4 <_stogir.vector-lanes.compatible?+0x190>
   10068:      	cmp	x0, #0x3
   1006c:      	b.eq	0x100c0 <_stogir.vector-lanes.compatible?+0x2ac>
   10070:      	cmp	x0, #0x9
   10074:      	b.eq	0x100c0 <_stogir.vector-lanes.compatible?+0x2ac>
   10078:      	cmp	x0, #0x4
   1007c:      	b.eq	0x100d0 <_stogir.vector-lanes.compatible?+0x2bc>
   10080:      	cmp	x0, #0xa
   10084:      	b.eq	0x100d0 <_stogir.vector-lanes.compatible?+0x2bc>
   10088:      	cmp	x0, #0xd
   1008c:      	b.eq	0x100d0 <_stogir.vector-lanes.compatible?+0x2bc>
   10090:      	cmp	x0, #0x5
   10094:      	b.eq	0x100e0 <_stogir.vector-lanes.compatible?+0x2cc>
   10098:      	cmp	x0, #0xb
   1009c:      	b.eq	0x100e0 <_stogir.vector-lanes.compatible?+0x2cc>
   100a0:      	cmp	x0, #0xc
   100a4:      	b.eq	0x100e0 <_stogir.vector-lanes.compatible?+0x2cc>
   100a8:      	cmp	x0, #0x6
   100ac:      	b.ne	0x100f0 <_stogir.vector-lanes.compatible?+0x2dc>
   100b0:      	mov	x0, x21
   100b4:      	b	0x100f4 <_stogir.vector-lanes.compatible?+0x2e0>
   100b8:      	mov	x1, #0x2                ; =2
   100bc:      	b	0xff74 <_stogir.vector-lanes.compatible?+0x160>
   100c0:      	mov	x0, #0x2                ; =2
   100c4:      	b	0xffa8 <_stogir.vector-lanes.compatible?+0x194>
   100c8:      	mov	x1, #0x4                ; =4
   100cc:      	b	0x100bc <_stogir.vector-lanes.compatible?+0x2a8>
   100d0:      	mov	x0, #0x4                ; =4
   100d4:      	b	0x100c4 <_stogir.vector-lanes.compatible?+0x2b0>
   100d8:      	mov	x1, #0x8                ; =8
   100dc:      	b	0x100cc <_stogir.vector-lanes.compatible?+0x2b8>
   100e0:      	mov	x0, #0x8                ; =8
   100e4:      	b	0x100d4 <_stogir.vector-lanes.compatible?+0x2c0>
   100e8:      	movn	x1, #0x0, lsl #48
   100ec:      	b	0x100dc <_stogir.vector-lanes.compatible?+0x2c8>
   100f0:      	movn	x0, #0x0, lsl #48
   100f4:      	b	0x100e4 <_stogir.vector-lanes.compatible?+0x2d0>

00000000000100f8 <_stogir.symbols.numeric?>:
   100f8:      	ldr	w0, [x0]
   100fc:      	uxtb	w1, w0
   10100:      	ubfx	x0, x0, #8, #8
   10104:      	cmp	x1, x0
   10108:      	b.ne	0x10114 <_stogir.symbols.numeric?+0x1c>
   1010c:      	mov	x0, #0x1                ; =1
   10110:      	b	0x10120 <_stogir.symbols.numeric?+0x28>
   10114:      	cmp	x1, #0x49
   10118:      	cset	w0, eq
   1011c:      	ubfx	x0, x0, #0, #8
   10120:      	ret

0000000000010124 <_stogir.node.constant-bits>:
   10124:      	ldr	w1, [x0, #0x8]
   10128:      	ubfx	x1, x1, #0, #32
   1012c:      	ldr	w0, [x0, #0xc]
   10130:      	ubfx	x0, x0, #0, #32
   10134:      	lsl	x0, x0, #32
   10138:      	orr	x0, x0, x1
   1013c:      	ret

0000000000010140 <_stogir.vector-comparison.valid-type?>:
   10140:      	sub	sp, sp, #0x30
   10144:      	str	x29, [sp]
   10148:      	str	x30, [sp, #0x8]
   1014c:      	mov	x29, sp
   10150:      	str	x19, [sp, #0x10]
   10154:      	str	x20, [sp, #0x18]
   10158:      	str	x21, [sp, #0x20]
   1015c:      	sxtw	x19, w0
   10160:      	cmp	x19, #0xe
   10164:      	b.lt	0x101bc <_stogir.vector-comparison.valid-type?+0x7c>
   10168:      	cmp	x19, #0x19
   1016c:      	b.gt	0x101bc <_stogir.vector-comparison.valid-type?+0x7c>
   10170:      	sxtw	x0, w1
   10174:      	cmp	x0, #0xf
   10178:      	b.le	0x101dc <_stogir.vector-comparison.valid-type?+0x9c>
   1017c:      	cmp	x0, #0x80
   10180:      	b.ge	0x101dc <_stogir.vector-comparison.valid-type?+0x9c>
   10184:      	and	x0, x0, #0xf
   10188:      	lsr	w0, w0, #0
   1018c:      	sxtw	x20, w0
   10190:      	cmp	x20, #0x1
   10194:      	b.lt	0x101dc <_stogir.vector-comparison.valid-type?+0x9c>
   10198:      	cmp	x20, #0xd
   1019c:      	b.gt	0x101dc <_stogir.vector-comparison.valid-type?+0x9c>
   101a0:      	lsr	w21, w1, #0
   101a4:      	mov	w0, w21
   101a8:      	bl	0x101a8 <_stogir.vector-comparison.valid-type?+0x68>
		00000000000101a8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   101ac:      	cmp	x0, #0x0
   101b0:      	b.eq	0x101ec <_stogir.vector-comparison.valid-type?+0xac>
   101b4:      	mov	x0, x20
   101b8:      	b	0x101f0 <_stogir.vector-comparison.valid-type?+0xb0>
   101bc:      	movz	x0, #0x0, lsl #48
   101c0:      	ldr	x19, [sp, #0x10]
   101c4:      	ldr	x20, [sp, #0x18]
   101c8:      	ldr	x21, [sp, #0x20]
   101cc:      	ldr	x29, [sp]
   101d0:      	ldr	x30, [sp, #0x8]
   101d4:      	add	sp, sp, #0x30
   101d8:      	ret
   101dc:      	movz	x0, #0x0, lsl #48
   101e0:      	b	0x101c0 <_stogir.vector-comparison.valid-type?+0x80>
   101e4:      	mov	x0, #0x1                ; =1
   101e8:      	b	0x101e0 <_stogir.vector-comparison.valid-type?+0xa0>
   101ec:      	movn	x0, #0x0, lsl #48
   101f0:      	lsr	w0, w0, #0
   101f4:      	sxtw	x0, w0
   101f8:      	cmp	x0, #0xc
   101fc:      	b.eq	0x101e4 <_stogir.vector-comparison.valid-type?+0xa4>
   10200:      	cmp	x0, #0xd
   10204:      	b.eq	0x101e4 <_stogir.vector-comparison.valid-type?+0xa4>
   10208:      	mov	w0, w21
   1020c:      	bl	0x1020c <_stogir.vector-comparison.valid-type?+0xcc>
		000000000001020c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10210:      	cmp	x0, #0x0
   10214:      	b.eq	0x10228 <_stogir.vector-comparison.valid-type?+0xe8>
   10218:      	mov	x0, x20
   1021c:      	b	0x1022c <_stogir.vector-comparison.valid-type?+0xec>
   10220:      	movz	x0, #0x0, lsl #48
   10224:      	b	0x101e8 <_stogir.vector-comparison.valid-type?+0xa8>
   10228:      	movn	x0, #0x0, lsl #48
   1022c:      	lsr	w0, w0, #0
   10230:      	sxtw	x0, w0
   10234:      	cmp	x0, #0x1
   10238:      	b.lt	0x10220 <_stogir.vector-comparison.valid-type?+0xe0>
   1023c:      	cmp	x0, #0xb
   10240:      	b.gt	0x10220 <_stogir.vector-comparison.valid-type?+0xe0>
   10244:      	cmp	x19, #0x17
   10248:      	cset	w0, le
   1024c:      	ubfx	x0, x0, #0, #8
   10250:      	b	0x10224 <_stogir.vector-comparison.valid-type?+0xe4>

0000000000010254 <_stogir.vector-arithmetic.extrema?>:
   10254:      	sxtw	x0, w0
   10258:      	cmp	x0, #0x3a
   1025c:      	b.ne	0x10268 <_stogir.vector-arithmetic.extrema?+0x14>
   10260:      	mov	x0, #0x1                ; =1
   10264:      	b	0x10274 <_stogir.vector-arithmetic.extrema?+0x20>
   10268:      	cmp	x0, #0x3b
   1026c:      	cset	w0, eq
   10270:      	ubfx	x0, x0, #0, #8
   10274:      	ret

0000000000010278 <_stogir.vector-arithmetic.shift?>:
   10278:      	sxtw	x0, w0
   1027c:      	cmp	x0, #0x31
   10280:      	b.lt	0x10294 <_stogir.vector-arithmetic.shift?+0x1c>
   10284:      	cmp	x0, #0x35
   10288:      	cset	w0, le
   1028c:      	ubfx	x0, x0, #0, #8
   10290:      	b	0x10298 <_stogir.vector-arithmetic.shift?+0x20>
   10294:      	movz	x0, #0x0, lsl #48
   10298:      	ret

000000000001029c <_stogir.vector-arithmetic.valid-type?>:
   1029c:      	sub	sp, sp, #0x40
   102a0:      	str	x29, [sp]
   102a4:      	str	x30, [sp, #0x8]
   102a8:      	mov	x29, sp
   102ac:      	str	x19, [sp, #0x10]
   102b0:      	str	x20, [sp, #0x18]
   102b4:      	str	x21, [sp, #0x20]
   102b8:      	str	x22, [sp, #0x28]
   102bc:      	str	x23, [sp, #0x30]
   102c0:      	lsr	w2, w1, #0
   102c4:      	sxtw	x19, w1
   102c8:      	mov	w20, w0
   102cc:      	mov	w0, w2
   102d0:      	bl	0x102d0 <_stogir.vector-arithmetic.valid-type?+0x34>
		00000000000102d0:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   102d4:      	and	x1, x19, #0xf
   102d8:      	lsr	w1, w1, #0
   102dc:      	sxtw	x1, w1
   102e0:      	cmp	x0, #0x0
   102e4:      	b.eq	0x102f0 <_stogir.vector-arithmetic.valid-type?+0x54>
   102e8:      	mov	x0, x1
   102ec:      	b	0x102f4 <_stogir.vector-arithmetic.valid-type?+0x58>
   102f0:      	movn	x0, #0x0, lsl #48
   102f4:      	cmp	x19, #0xf
   102f8:      	b.le	0x104d8 <_stogir.vector-arithmetic.valid-type?+0x23c>
   102fc:      	cmp	x19, #0x80
   10300:      	b.ge	0x104d8 <_stogir.vector-arithmetic.valid-type?+0x23c>
   10304:      	cmp	x1, #0x1
   10308:      	b.lt	0x104d8 <_stogir.vector-arithmetic.valid-type?+0x23c>
   1030c:      	cmp	x1, #0xd
   10310:      	b.gt	0x104d8 <_stogir.vector-arithmetic.valid-type?+0x23c>
   10314:      	sxtw	x1, w20
   10318:      	cmp	x1, #0x1f
   1031c:      	cset	w19, eq
   10320:      	cmp	x1, #0x20
   10324:      	cset	w21, eq
   10328:      	cmp	x1, #0x2e
   1032c:      	cset	w2, eq
   10330:      	cmp	x1, #0x2f
   10334:      	cset	w3, eq
   10338:      	cmp	x1, #0x30
   1033c:      	cset	w4, eq
   10340:      	cmp	x1, #0x1e
   10344:      	cset	w5, eq
   10348:      	cmp	x1, #0x31
   1034c:      	cset	w6, ge
   10350:      	cmp	x1, #0x35
   10354:      	cset	w7, le
   10358:      	cmp	x1, #0x3a
   1035c:      	cset	w8, eq
   10360:      	cmp	x1, #0x3b
   10364:      	cset	w9, eq
   10368:      	cmp	x1, #0x2d
   1036c:      	cset	w10, eq
   10370:      	cmp	x1, #0x36
   10374:      	cset	w11, eq
   10378:      	cmp	x1, #0x37
   1037c:      	cset	w12, eq
   10380:      	cmp	x1, #0x38
   10384:      	cset	w13, eq
   10388:      	cmp	x1, #0x39
   1038c:      	cset	w14, eq
   10390:      	uxtb	w16, w19
   10394:      	cmp	w16, wzr
   10398:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   1039c:      	uxtb	w16, w21
   103a0:      	cmp	w16, wzr
   103a4:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   103a8:      	uxtb	w16, w10
   103ac:      	cmp	w16, wzr
   103b0:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   103b4:      	uxtb	w16, w11
   103b8:      	cmp	w16, wzr
   103bc:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   103c0:      	uxtb	w16, w12
   103c4:      	cmp	w16, wzr
   103c8:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   103cc:      	uxtb	w16, w13
   103d0:      	cmp	w16, wzr
   103d4:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   103d8:      	uxtb	w16, w14
   103dc:      	cmp	w16, wzr
   103e0:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   103e4:      	uxtb	w16, w8
   103e8:      	cmp	w16, wzr
   103ec:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   103f0:      	uxtb	w16, w9
   103f4:      	cmp	w16, wzr
   103f8:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   103fc:      	uxtb	w16, w6
   10400:      	cmp	w16, wzr
   10404:      	b.eq	0x10600 <_stogir.vector-arithmetic.valid-type?+0x364>
   10408:      	uxtb	w16, w7
   1040c:      	cmp	w16, wzr
   10410:      	b.eq	0x10600 <_stogir.vector-arithmetic.valid-type?+0x364>
   10414:      	lsr	w0, w0, #0
   10418:      	sxtw	x1, w0
   1041c:      	cmp	x1, #0xc
   10420:      	cset	w22, eq
   10424:      	cmp	x1, #0xd
   10428:      	cset	w23, eq
   1042c:      	uxtb	w16, w19
   10430:      	cmp	w16, wzr
   10434:      	b.ne	0x1050c <_stogir.vector-arithmetic.valid-type?+0x270>
   10438:      	uxtb	w16, w21
   1043c:      	cmp	w16, wzr
   10440:      	b.ne	0x1050c <_stogir.vector-arithmetic.valid-type?+0x270>
   10444:      	uxtb	w16, w10
   10448:      	cmp	w16, wzr
   1044c:      	b.ne	0x1050c <_stogir.vector-arithmetic.valid-type?+0x270>
   10450:      	uxtb	w16, w11
   10454:      	cmp	w16, wzr
   10458:      	b.ne	0x1050c <_stogir.vector-arithmetic.valid-type?+0x270>
   1045c:      	uxtb	w16, w12
   10460:      	cmp	w16, wzr
   10464:      	b.ne	0x1050c <_stogir.vector-arithmetic.valid-type?+0x270>
   10468:      	uxtb	w16, w13
   1046c:      	cmp	w16, wzr
   10470:      	b.ne	0x1050c <_stogir.vector-arithmetic.valid-type?+0x270>
   10474:      	uxtb	w16, w14
   10478:      	cmp	w16, wzr
   1047c:      	b.ne	0x1050c <_stogir.vector-arithmetic.valid-type?+0x270>
   10480:      	cmp	x1, #0x1
   10484:      	cset	w0, eq
   10488:      	cmp	x1, #0x1
   1048c:      	cset	w10, ge
   10490:      	cmp	x1, #0xb
   10494:      	cset	w1, le
   10498:      	uxtb	w16, w6
   1049c:      	cmp	w16, wzr
   104a0:      	b.eq	0x1056c <_stogir.vector-arithmetic.valid-type?+0x2d0>
   104a4:      	uxtb	w16, w7
   104a8:      	cmp	w16, wzr
   104ac:      	b.eq	0x1056c <_stogir.vector-arithmetic.valid-type?+0x2d0>
   104b0:      	uxtb	w16, w10
   104b4:      	cmp	w16, wzr
   104b8:      	b.eq	0x105f8 <_stogir.vector-arithmetic.valid-type?+0x35c>
   104bc:      	uxtb	w16, w1
   104c0:      	cmp	w16, wzr
   104c4:      	b.eq	0x105f8 <_stogir.vector-arithmetic.valid-type?+0x35c>
   104c8:      	uxtb	w16, w0
   104cc:      	cmp	w16, wzr
   104d0:      	cset	x0, eq
   104d4:      	b	0x105fc <_stogir.vector-arithmetic.valid-type?+0x360>
   104d8:      	movz	x0, #0x0, lsl #48
   104dc:      	ldr	x19, [sp, #0x10]
   104e0:      	ldr	x20, [sp, #0x18]
   104e4:      	ldr	x21, [sp, #0x20]
   104e8:      	ldr	x22, [sp, #0x28]
   104ec:      	ldr	x23, [sp, #0x30]
   104f0:      	ldr	x29, [sp]
   104f4:      	ldr	x30, [sp, #0x8]
   104f8:      	add	sp, sp, #0x40
   104fc:      	ret
   10500:      	ubfx	x21, x21, #0, #8
   10504:      	mov	x0, x21
   10508:      	b	0x104dc <_stogir.vector-arithmetic.valid-type?+0x240>
   1050c:      	lsr	w20, w20, #0
   10510:      	lsr	w0, w0, #0
   10514:      	mov	w1, w0
   10518:      	mov	w0, w20
   1051c:      	bl	0x1051c <_stogir.vector-arithmetic.valid-type?+0x280>
		000000000001051c:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
   10520:      	cmp	x0, #0x0
   10524:      	b.eq	0x10530 <_stogir.vector-arithmetic.valid-type?+0x294>
   10528:      	mov	x0, #0x1                ; =1
   1052c:      	b	0x10508 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10530:      	uxtb	w16, w22
   10534:      	cmp	w16, wzr
   10538:      	b.ne	0x10550 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   1053c:      	uxtb	w16, w23
   10540:      	cmp	w16, wzr
   10544:      	b.ne	0x10550 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10548:      	movz	x0, #0x0, lsl #48
   1054c:      	b	0x10508 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10550:      	uxtb	w16, w19
   10554:      	cmp	w16, wzr
   10558:      	b.eq	0x10500 <_stogir.vector-arithmetic.valid-type?+0x264>
   1055c:      	mov	x0, #0x1                ; =1
   10560:      	b	0x10508 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10564:      	movz	x0, #0x0, lsl #48
   10568:      	b	0x10508 <_stogir.vector-arithmetic.valid-type?+0x26c>
   1056c:      	uxtb	w16, w2
   10570:      	cmp	w16, wzr
   10574:      	b.ne	0x105e0 <_stogir.vector-arithmetic.valid-type?+0x344>
   10578:      	uxtb	w16, w3
   1057c:      	cmp	w16, wzr
   10580:      	b.ne	0x105e0 <_stogir.vector-arithmetic.valid-type?+0x344>
   10584:      	uxtb	w16, w4
   10588:      	cmp	w16, wzr
   1058c:      	b.ne	0x105e0 <_stogir.vector-arithmetic.valid-type?+0x344>
   10590:      	uxtb	w16, w22
   10594:      	cmp	w16, wzr
   10598:      	b.ne	0x10658 <_stogir.vector-arithmetic.valid-type?+0x3bc>
   1059c:      	uxtb	w16, w23
   105a0:      	cmp	w16, wzr
   105a4:      	b.ne	0x10658 <_stogir.vector-arithmetic.valid-type?+0x3bc>
   105a8:      	uxtb	w16, w10
   105ac:      	cmp	w16, wzr
   105b0:      	b.eq	0x10668 <_stogir.vector-arithmetic.valid-type?+0x3cc>
   105b4:      	uxtb	w16, w1
   105b8:      	cmp	w16, wzr
   105bc:      	b.eq	0x10668 <_stogir.vector-arithmetic.valid-type?+0x3cc>
   105c0:      	uxtb	w16, w0
   105c4:      	cmp	w16, wzr
   105c8:      	b.eq	0x10670 <_stogir.vector-arithmetic.valid-type?+0x3d4>
   105cc:      	uxtb	w16, w8
   105d0:      	cmp	w16, wzr
   105d4:      	b.eq	0x10678 <_stogir.vector-arithmetic.valid-type?+0x3dc>
   105d8:      	mov	x0, #0x1                ; =1
   105dc:      	b	0x10680 <_stogir.vector-arithmetic.valid-type?+0x3e4>
   105e0:      	uxtb	w16, w10
   105e4:      	cmp	w16, wzr
   105e8:      	b.eq	0x10564 <_stogir.vector-arithmetic.valid-type?+0x2c8>
   105ec:      	ubfx	x1, x1, #0, #8
   105f0:      	mov	x0, x1
   105f4:      	b	0x10568 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   105f8:      	movz	x0, #0x0, lsl #48
   105fc:      	b	0x10568 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10600:      	cmp	x1, #0x1a
   10604:      	b.eq	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   10608:      	cmp	x1, #0x1b
   1060c:      	b.eq	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   10610:      	cmp	x1, #0x1c
   10614:      	b.eq	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   10618:      	cmp	x1, #0x1d
   1061c:      	b.eq	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   10620:      	uxtb	w16, w5
   10624:      	cmp	w16, wzr
   10628:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   1062c:      	uxtb	w16, w2
   10630:      	cmp	w16, wzr
   10634:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   10638:      	uxtb	w16, w3
   1063c:      	cmp	w16, wzr
   10640:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   10644:      	uxtb	w16, w4
   10648:      	cmp	w16, wzr
   1064c:      	b.ne	0x10414 <_stogir.vector-arithmetic.valid-type?+0x178>
   10650:      	movz	x0, #0x0, lsl #48
   10654:      	b	0x10508 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10658:      	uxtb	w16, w5
   1065c:      	cmp	w16, wzr
   10660:      	cset	x0, eq
   10664:      	b	0x10568 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10668:      	movz	x0, #0x0, lsl #48
   1066c:      	b	0x10664 <_stogir.vector-arithmetic.valid-type?+0x3c8>
   10670:      	mov	x0, #0x1                ; =1
   10674:      	b	0x1066c <_stogir.vector-arithmetic.valid-type?+0x3d0>
   10678:      	ubfx	x9, x9, #0, #8
   1067c:      	mov	x0, x9
   10680:      	b	0x10674 <_stogir.vector-arithmetic.valid-type?+0x3d8>

0000000000010684 <_coil.core.Len$slice$len__i32>:
   10684:      	mov	x0, x1
   10688:      	ret

000000000001068c <_inherent$slice$data__i32>:
   1068c:      	ret

0000000000010690 <_stogir.opcode.terminator?>:
   10690:      	sxtw	x0, w0
   10694:      	cmp	x0, #0x0
   10698:      	b.lt	0x106c0 <_stogir.opcode.terminator?+0x30>
   1069c:      	cmp	x0, #0x83
   106a0:      	b.ge	0x106c0 <_stogir.opcode.terminator?+0x30>
   106a4:      	adrp	x16, 0x10000 <_stogir.vector-lanes.compatible?+0x1ec>
		00000000000106a4:  ARM64_RELOC_PAGE21	l_stogir.515
   106a8:      	ldr	x16, [x16]
		00000000000106a8:  ARM64_RELOC_PAGEOFF12	l_stogir.515
   106ac:      	orr	x1, x16, xzr
   106b0:      	lsr	x2, x0, #0
   106b4:      	add	x0, x1, x0
   106b8:      	ldrb	w0, [x0]
   106bc:      	b	0x106c4 <_stogir.opcode.terminator?+0x34>
   106c0:      	movz	x0, #0x0, lsl #48
   106c4:      	uxtb	w0, w0
   106c8:      	and	x0, x0, #0x8
   106cc:      	uxtb	w0, w0
   106d0:      	cmp	x0, #0x0
   106d4:      	cset	w0, eq
   106d8:      	uxtb	w16, w0
   106dc:      	cmp	w16, wzr
   106e0:      	cset	x0, eq
   106e4:      	ret

00000000000106e8 <_stogir.switch.sign-mask>:
   106e8:      	sxtw	x0, w0
   106ec:      	cmp	x0, #0x7
   106f0:      	b.lt	0x1070c <_stogir.switch.sign-mask+0x24>
   106f4:      	cmp	x0, #0xb
   106f8:      	b.gt	0x1070c <_stogir.switch.sign-mask+0x24>
   106fc:      	cmp	x0, #0x0
   10700:      	b.ne	0x10744 <_stogir.switch.sign-mask+0x5c>
   10704:      	movz	x0, #0x0, lsl #48
   10708:      	b	0x10718 <_stogir.switch.sign-mask+0x30>
   1070c:      	movz	x0, #0x0, lsl #48
   10710:      	ret
   10714:      	mov	x0, #0x1                ; =1
   10718:      	lsr	w0, w0, #0
   1071c:      	sxtw	x0, w0
   10720:      	lsl	x0, x0, #3
   10724:      	lsr	w0, w0, #0
   10728:      	sxtw	x0, w0
   1072c:      	sub	x0, x0, #0x1
   10730:      	lsr	w0, w0, #0
   10734:      	sxtw	x0, w0
   10738:      	mov	x16, #0x1               ; =1
   1073c:      	lsl	x0, x16, x0
   10740:      	b	0x10710 <_stogir.switch.sign-mask+0x28>
   10744:      	cmp	x0, #0x1
   10748:      	b.eq	0x10714 <_stogir.switch.sign-mask+0x2c>
   1074c:      	cmp	x0, #0x2
   10750:      	b.eq	0x10714 <_stogir.switch.sign-mask+0x2c>
   10754:      	cmp	x0, #0x7
   10758:      	b.eq	0x10714 <_stogir.switch.sign-mask+0x2c>
   1075c:      	cmp	x0, #0x8
   10760:      	b.eq	0x10714 <_stogir.switch.sign-mask+0x2c>
   10764:      	cmp	x0, #0x3
   10768:      	b.eq	0x107c4 <_stogir.switch.sign-mask+0xdc>
   1076c:      	cmp	x0, #0x9
   10770:      	b.eq	0x107c4 <_stogir.switch.sign-mask+0xdc>
   10774:      	cmp	x0, #0x4
   10778:      	b.eq	0x107cc <_stogir.switch.sign-mask+0xe4>
   1077c:      	cmp	x0, #0xa
   10780:      	b.eq	0x107cc <_stogir.switch.sign-mask+0xe4>
   10784:      	cmp	x0, #0xd
   10788:      	b.eq	0x107cc <_stogir.switch.sign-mask+0xe4>
   1078c:      	cmp	x0, #0x5
   10790:      	b.eq	0x107d4 <_stogir.switch.sign-mask+0xec>
   10794:      	cmp	x0, #0xb
   10798:      	b.eq	0x107d4 <_stogir.switch.sign-mask+0xec>
   1079c:      	cmp	x0, #0xc
   107a0:      	b.eq	0x107d4 <_stogir.switch.sign-mask+0xec>
   107a4:      	cmp	x0, #0x6
   107a8:      	cset	w0, eq
   107ac:      	uxtb	w16, w0
   107b0:      	cmp	w16, wzr
   107b4:      	mov	x16, #0x8               ; =8
   107b8:      	movn	x17, #0x0, lsl #48
   107bc:      	csel	x0, x16, x17, ne
   107c0:      	b	0x107d8 <_stogir.switch.sign-mask+0xf0>
   107c4:      	mov	x0, #0x2                ; =2
   107c8:      	b	0x10718 <_stogir.switch.sign-mask+0x30>
   107cc:      	mov	x0, #0x4                ; =4
   107d0:      	b	0x107c8 <_stogir.switch.sign-mask+0xe0>
   107d4:      	mov	x0, #0x8                ; =8
   107d8:      	b	0x107d0 <_stogir.switch.sign-mask+0xe8>
