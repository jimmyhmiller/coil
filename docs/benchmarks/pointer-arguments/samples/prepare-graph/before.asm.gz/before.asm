
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-pointer-arguments/build/pointer-comparison/prepare-graph/before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_prepare_graph>:
       0:      	sub	sp, sp, #0x2e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x2c0]
      14:      	str	x20, [sp, #0x2c8]
      18:      	str	x21, [sp, #0x2d0]
      1c:      	str	x22, [sp, #0x2d8]
      20:      	add	x16, sp, #0x10
      24:      	orr	x3, x16, xzr
      28:      	add	x16, sp, #0x20
      2c:      	orr	x4, x16, xzr
      30:      	add	x16, sp, #0x10
      34:      	str	w2, [x16]
      38:      	add	x16, sp, #0x20
      3c:      	adrp	x17, 0x0 <_gap_prepare_graph>
		000000000000003c:  ARM64_RELOC_PAGE21	l_stogir.388
      40:      	ldr	x17, [x17]
		0000000000000040:  ARM64_RELOC_PAGEOFF12	l_stogir.388
      44:      	str	x17, [x16]
      48:      	add	x16, sp, #0x20
      4c:      	adrp	x17, 0x0 <_gap_prepare_graph>
		000000000000004c:  ARM64_RELOC_PAGE21	l_stogir.389
      50:      	ldr	x17, [x17]
		0000000000000050:  ARM64_RELOC_PAGEOFF12	l_stogir.389
      54:      	str	x17, [x16, #0x8]
      58:      	add	x8, sp, #0x30
      5c:      	mov	x2, x3
      60:      	mov	x3, #0x1                ; =1
      64:      	bl	0x64 <_gap_prepare_graph+0x64>
		0000000000000064:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare
      68:      	add	x16, sp, #0x30
      6c:      	ldr	w0, [x16]
      70:      	lsr	x16, x0, #0
      74:      	cmp	x16, #0x1
      78:      	b.eq	0x94 <_gap_prepare_graph+0x94>
      7c:      	b.lo	0x84 <_gap_prepare_graph+0x84>
      80:      	b	0x98 <_gap_prepare_graph+0x98>
      84:      	cmp	x16, #0x0
      88:      	b.eq	0x90 <_gap_prepare_graph+0x90>
      8c:      	b	0x98 <_gap_prepare_graph+0x98>
      90:      	b	0xa4 <_gap_prepare_graph+0xa4>
      94:      	b	0x9c <_gap_prepare_graph+0x9c>
      98:      	b	0x540 <_gap_prepare_graph+0x540>
      9c:      	movz	x20, #0x0, lsl #48
      a0:      	b	0x514 <_gap_prepare_graph+0x514>
      a4:      	add	x16, sp, #0x30
      a8:      	orr	x0, x16, xzr
      ac:      	add	x16, sp, #0x180
      b0:      	orr	x19, x16, xzr
      b4:      	add	x0, x0, #0x8
      b8:      	add	x20, x19, #0xa0
      bc:      	add	x21, x20, #0x28
      c0:      	mov	x1, x0
      c4:      	add	x0, sp, #0x180
      c8:      	mov	x2, #0x140              ; =320
      cc:      	bl	0xcc <_gap_prepare_graph+0xcc>
		00000000000000cc:  ARM64_RELOC_BRANCH26	_memmove
      d0:      	ldr	x0, [x20, #0x28]
      d4:      	ldr	x1, [x21, #0x8]
      d8:      	movz	x20, #0x0, lsl #48
      dc:      	movz	x2, #0x0, lsl #48
      e0:      	b	0x128 <_gap_prepare_graph+0x128>
      e4:      	nop
      e8:      	movz	w3, #0x0, lsl #16
      ec:      	movz	w4, #0x0, lsl #16
      f0:      	ubfx	x3, x3, #0, #32
      f4:      	lsr	x16, x3, #0
      f8:      	cmp	x16, #0x1
      fc:      	b.eq	0x118 <_gap_prepare_graph+0x118>
     100:      	b.lo	0x108 <_gap_prepare_graph+0x108>
     104:      	b	0x11c <_gap_prepare_graph+0x11c>
     108:      	cmp	x16, #0x0
     10c:      	b.eq	0x114 <_gap_prepare_graph+0x114>
     110:      	b	0x11c <_gap_prepare_graph+0x11c>
     114:      	b	0x150 <_gap_prepare_graph+0x150>
     118:      	b	0x120 <_gap_prepare_graph+0x120>
     11c:      	b	0x538 <_gap_prepare_graph+0x538>
     120:      	sxtw	x4, w4
     124:      	add	x20, x4, x20
     128:      	cmp	x2, x1
     12c:      	b.ge	0xe8 <_gap_prepare_graph+0xe8>
     130:      	add	x3, x2, #0x1
     134:      	add	x2, x0, x2, lsl #2
     138:      	ldr	w2, [x2]
     13c:      	movn	w17, #0x0, lsl #16
     140:      	and	w4, w2, w17
     144:      	mov	x2, x3
     148:      	mov	w3, #0x1                ; =1
     14c:      	b	0xf0 <_gap_prepare_graph+0xf0>
     150:      	b	0x164 <_gap_prepare_graph+0x164>
     154:      	nop
     158:      	sub	x0, x0, #0x1
     15c:      	add	x16, sp, #0x180
     160:      	str	x0, [x16, #0x8]
     164:      	add	x16, sp, #0x180
     168:      	ldr	x0, [x16, #0x8]
     16c:      	cmp	x0, #0x0
     170:      	b.ne	0x158 <_gap_prepare_graph+0x158>
     174:      	add	x16, sp, #0x180
     178:      	ldr	x0, [x16, #0x10]
     17c:      	cmp	x0, #0x0
     180:      	b.le	0x1b4 <_gap_prepare_graph+0x1b4>
     184:      	add	x1, x19, #0x18
     188:      	add	x16, sp, #0x180
     18c:      	ldr	x2, [x16]
     190:      	fmov	d31, x0
     194:      	mov	x0, x1
     198:      	mov	x1, x2
     19c:      	fmov	x2, d31
     1a0:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000001a0:  ARM64_RELOC_PAGE21	l_stogir.390
     1a4:      	ldr	x3, [x3]
		00000000000001a4:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     1a8:      	mov	x4, #0x4                ; =4
     1ac:      	mov	x5, #0x4                ; =4
     1b0:      	bl	0x1b0 <_gap_prepare_graph+0x1b0>
		00000000000001b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     1b4:      	add	x21, x19, #0x28
     1b8:      	add	x16, sp, #0x180
     1bc:      	movz	x17, #0x0, lsl #48
     1c0:      	str	x17, [x16]
     1c4:      	add	x16, sp, #0x180
     1c8:      	movz	x17, #0x0, lsl #48
     1cc:      	str	x17, [x16, #0x8]
     1d0:      	add	x16, sp, #0x180
     1d4:      	movz	x17, #0x0, lsl #48
     1d8:      	str	x17, [x16, #0x10]
     1dc:      	b	0x1e8 <_gap_prepare_graph+0x1e8>
     1e0:      	sub	x0, x0, #0x1
     1e4:      	str	x0, [x21, #0x8]
     1e8:      	ldr	x0, [x21, #0x8]
     1ec:      	cmp	x0, #0x0
     1f0:      	b.ne	0x1e0 <_gap_prepare_graph+0x1e0>
     1f4:      	ldr	x0, [x21, #0x10]
     1f8:      	cmp	x0, #0x0
     1fc:      	b.le	0x230 <_gap_prepare_graph+0x230>
     200:      	add	x1, x21, #0x18
     204:      	add	x16, sp, #0x180
     208:      	ldr	x2, [x16, #0x28]
     20c:      	fmov	d31, x0
     210:      	mov	x0, x1
     214:      	mov	x1, x2
     218:      	fmov	x2, d31
     21c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000021c:  ARM64_RELOC_PAGE21	l_stogir.390
     220:      	ldr	x3, [x3]
		0000000000000220:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     224:      	mov	x4, #0x4                ; =4
     228:      	mov	x5, #0x4                ; =4
     22c:      	bl	0x22c <_gap_prepare_graph+0x22c>
		000000000000022c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     230:      	add	x22, x19, #0x50
     234:      	add	x16, sp, #0x180
     238:      	movz	x17, #0x0, lsl #48
     23c:      	str	x17, [x16, #0x28]
     240:      	movz	x17, #0x0, lsl #48
     244:      	str	x17, [x21, #0x8]
     248:      	movz	x17, #0x0, lsl #48
     24c:      	str	x17, [x21, #0x10]
     250:      	b	0x260 <_gap_prepare_graph+0x260>
     254:      	nop
     258:      	sub	x0, x0, #0x1
     25c:      	str	x0, [x22, #0x8]
     260:      	ldr	x0, [x22, #0x8]
     264:      	cmp	x0, #0x0
     268:      	b.ne	0x258 <_gap_prepare_graph+0x258>
     26c:      	ldr	x0, [x22, #0x10]
     270:      	cmp	x0, #0x0
     274:      	b.le	0x2a8 <_gap_prepare_graph+0x2a8>
     278:      	add	x1, x22, #0x18
     27c:      	add	x16, sp, #0x180
     280:      	ldr	x2, [x16, #0x50]
     284:      	fmov	d31, x0
     288:      	mov	x0, x1
     28c:      	mov	x1, x2
     290:      	fmov	x2, d31
     294:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000294:  ARM64_RELOC_PAGE21	l_stogir.391
     298:      	ldr	x3, [x3]
		0000000000000298:  ARM64_RELOC_PAGEOFF12	l_stogir.391
     29c:      	mov	x4, #0x10               ; =16
     2a0:      	mov	x5, #0x4                ; =4
     2a4:      	bl	0x2a4 <_gap_prepare_graph+0x2a4>
		00000000000002a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     2a8:      	add	x21, x19, #0x78
     2ac:      	add	x16, sp, #0x180
     2b0:      	movz	x17, #0x0, lsl #48
     2b4:      	str	x17, [x16, #0x50]
     2b8:      	movz	x17, #0x0, lsl #48
     2bc:      	str	x17, [x22, #0x8]
     2c0:      	movz	x17, #0x0, lsl #48
     2c4:      	str	x17, [x22, #0x10]
     2c8:      	b	0x2d8 <_gap_prepare_graph+0x2d8>
     2cc:      	nop
     2d0:      	sub	x0, x0, #0x1
     2d4:      	str	x0, [x21, #0x8]
     2d8:      	ldr	x0, [x21, #0x8]
     2dc:      	cmp	x0, #0x0
     2e0:      	b.ne	0x2d0 <_gap_prepare_graph+0x2d0>
     2e4:      	ldr	x0, [x21, #0x10]
     2e8:      	cmp	x0, #0x0
     2ec:      	b.le	0x320 <_gap_prepare_graph+0x320>
     2f0:      	add	x1, x21, #0x18
     2f4:      	add	x16, sp, #0x180
     2f8:      	ldr	x2, [x16, #0x78]
     2fc:      	fmov	d31, x0
     300:      	mov	x0, x1
     304:      	mov	x1, x2
     308:      	fmov	x2, d31
     30c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000030c:  ARM64_RELOC_PAGE21	l_stogir.390
     310:      	ldr	x3, [x3]
		0000000000000310:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     314:      	mov	x4, #0x4                ; =4
     318:      	mov	x5, #0x4                ; =4
     31c:      	bl	0x31c <_gap_prepare_graph+0x31c>
		000000000000031c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     320:      	add	x22, x19, #0xf0
     324:      	add	x16, sp, #0x180
     328:      	movz	x17, #0x0, lsl #48
     32c:      	str	x17, [x16, #0x78]
     330:      	movz	x17, #0x0, lsl #48
     334:      	str	x17, [x21, #0x8]
     338:      	movz	x17, #0x0, lsl #48
     33c:      	str	x17, [x21, #0x10]
     340:      	b	0x350 <_gap_prepare_graph+0x350>
     344:      	nop
     348:      	sub	x0, x0, #0x1
     34c:      	str	x0, [x22, #0x8]
     350:      	ldr	x0, [x22, #0x8]
     354:      	cmp	x0, #0x0
     358:      	b.ne	0x348 <_gap_prepare_graph+0x348>
     35c:      	ldr	x0, [x22, #0x10]
     360:      	cmp	x0, #0x0
     364:      	b.le	0x398 <_gap_prepare_graph+0x398>
     368:      	add	x1, x22, #0x18
     36c:      	add	x16, sp, #0x180
     370:      	ldr	x2, [x16, #0xf0]
     374:      	fmov	d31, x0
     378:      	mov	x0, x1
     37c:      	mov	x1, x2
     380:      	fmov	x2, d31
     384:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000384:  ARM64_RELOC_PAGE21	l_stogir.390
     388:      	ldr	x3, [x3]
		0000000000000388:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     38c:      	mov	x4, #0x4                ; =4
     390:      	mov	x5, #0x4                ; =4
     394:      	bl	0x394 <_gap_prepare_graph+0x394>
		0000000000000394:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     398:      	add	x21, x19, #0x118
     39c:      	add	x16, sp, #0x180
     3a0:      	movz	x17, #0x0, lsl #48
     3a4:      	str	x17, [x16, #0xf0]
     3a8:      	movz	x17, #0x0, lsl #48
     3ac:      	str	x17, [x22, #0x8]
     3b0:      	movz	x17, #0x0, lsl #48
     3b4:      	str	x17, [x22, #0x10]
     3b8:      	b	0x3c8 <_gap_prepare_graph+0x3c8>
     3bc:      	nop
     3c0:      	sub	x0, x0, #0x1
     3c4:      	str	x0, [x21, #0x8]
     3c8:      	ldr	x0, [x21, #0x8]
     3cc:      	cmp	x0, #0x0
     3d0:      	b.ne	0x3c0 <_gap_prepare_graph+0x3c0>
     3d4:      	ldr	x0, [x21, #0x10]
     3d8:      	cmp	x0, #0x0
     3dc:      	b.le	0x410 <_gap_prepare_graph+0x410>
     3e0:      	add	x1, x21, #0x18
     3e4:      	add	x16, sp, #0x180
     3e8:      	ldr	x2, [x16, #0x118]
     3ec:      	fmov	d31, x0
     3f0:      	mov	x0, x1
     3f4:      	mov	x1, x2
     3f8:      	fmov	x2, d31
     3fc:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000003fc:  ARM64_RELOC_PAGE21	l_stogir.390
     400:      	ldr	x3, [x3]
		0000000000000400:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     404:      	mov	x4, #0x4                ; =4
     408:      	mov	x5, #0x4                ; =4
     40c:      	bl	0x40c <_gap_prepare_graph+0x40c>
		000000000000040c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     410:      	add	x19, x19, #0xa0
     414:      	add	x16, sp, #0x180
     418:      	movz	x17, #0x0, lsl #48
     41c:      	str	x17, [x16, #0x118]
     420:      	movz	x17, #0x0, lsl #48
     424:      	str	x17, [x21, #0x8]
     428:      	movz	x17, #0x0, lsl #48
     42c:      	str	x17, [x21, #0x10]
     430:      	b	0x440 <_gap_prepare_graph+0x440>
     434:      	nop
     438:      	sub	x0, x0, #0x1
     43c:      	str	x0, [x19, #0x8]
     440:      	ldr	x0, [x19, #0x8]
     444:      	cmp	x0, #0x0
     448:      	b.ne	0x438 <_gap_prepare_graph+0x438>
     44c:      	ldr	x0, [x19, #0x10]
     450:      	cmp	x0, #0x0
     454:      	b.le	0x488 <_gap_prepare_graph+0x488>
     458:      	add	x1, x19, #0x18
     45c:      	add	x16, sp, #0x180
     460:      	ldr	x2, [x16, #0xa0]
     464:      	fmov	d31, x0
     468:      	mov	x0, x1
     46c:      	mov	x1, x2
     470:      	fmov	x2, d31
     474:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000474:  ARM64_RELOC_PAGE21	l_stogir.392
     478:      	ldr	x3, [x3]
		0000000000000478:  ARM64_RELOC_PAGEOFF12	l_stogir.392
     47c:      	mov	x4, #0x10               ; =16
     480:      	mov	x5, #0x8                ; =8
     484:      	bl	0x484 <_gap_prepare_graph+0x484>
		0000000000000484:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     488:      	add	x21, x19, #0x28
     48c:      	add	x16, sp, #0x180
     490:      	movz	x17, #0x0, lsl #48
     494:      	str	x17, [x16, #0xa0]
     498:      	movz	x17, #0x0, lsl #48
     49c:      	str	x17, [x19, #0x8]
     4a0:      	movz	x17, #0x0, lsl #48
     4a4:      	str	x17, [x19, #0x10]
     4a8:      	b	0x4b8 <_gap_prepare_graph+0x4b8>
     4ac:      	nop
     4b0:      	sub	x0, x0, #0x1
     4b4:      	str	x0, [x21, #0x8]
     4b8:      	ldr	x0, [x21, #0x8]
     4bc:      	cmp	x0, #0x0
     4c0:      	b.ne	0x4b0 <_gap_prepare_graph+0x4b0>
     4c4:      	ldr	x0, [x21, #0x10]
     4c8:      	cmp	x0, #0x0
     4cc:      	b.le	0x4fc <_gap_prepare_graph+0x4fc>
     4d0:      	add	x1, x21, #0x18
     4d4:      	ldr	x2, [x19, #0x28]
     4d8:      	fmov	d31, x0
     4dc:      	mov	x0, x1
     4e0:      	mov	x1, x2
     4e4:      	fmov	x2, d31
     4e8:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000004e8:  ARM64_RELOC_PAGE21	l_stogir.390
     4ec:      	ldr	x3, [x3]
		00000000000004ec:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     4f0:      	mov	x4, #0x4                ; =4
     4f4:      	mov	x5, #0x4                ; =4
     4f8:      	bl	0x4f8 <_gap_prepare_graph+0x4f8>
		00000000000004f8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     4fc:      	movz	x17, #0x0, lsl #48
     500:      	str	x17, [x19, #0x28]
     504:      	movz	x17, #0x0, lsl #48
     508:      	str	x17, [x21, #0x8]
     50c:      	movz	x17, #0x0, lsl #48
     510:      	str	x17, [x21, #0x10]
     514:      	mov	x0, x20
     518:      	ldr	x19, [sp, #0x2c0]
     51c:      	ldr	x20, [sp, #0x2c8]
     520:      	ldr	x21, [sp, #0x2d0]
     524:      	ldr	x22, [sp, #0x2d8]
     528:      	ldr	x29, [sp]
     52c:      	ldr	x30, [sp, #0x8]
     530:      	add	sp, sp, #0x2e0
     534:      	ret
     538:      	brk	#0
     53c:      	b	0x538 <_gap_prepare_graph+0x538>
     540:      	brk	#0
     544:      	b	0x540 <_gap_prepare_graph+0x540>

0000000000000548 <_stogir.pipeline.prepare>:
     548:      	sub	sp, sp, #0x310
     54c:      	str	x29, [sp]
     550:      	str	x30, [sp, #0x8]
     554:      	mov	x29, sp
     558:      	str	x19, [sp, #0x2d0]
     55c:      	str	x20, [sp, #0x2d8]
     560:      	str	x21, [sp, #0x2e0]
     564:      	str	x22, [sp, #0x2e8]
     568:      	str	x23, [sp, #0x2f0]
     56c:      	str	x24, [sp, #0x2f8]
     570:      	str	x25, [sp, #0x300]
     574:      	mov	x19, x8
     578:      	add	x8, sp, #0x10
     57c:      	mov	x20, x0
     580:      	mov	w21, w1
     584:      	mov	x22, x2
     588:      	mov	x23, x3
     58c:      	mov	x24, x4
     590:      	bl	0x590 <_stogir.pipeline.prepare+0x48>
		0000000000000590:  ARM64_RELOC_BRANCH26	_stogir.pipeline.validate-input
     594:      	add	x16, sp, #0x10
     598:      	ldr	w0, [x16]
     59c:      	lsr	x16, x0, #0
     5a0:      	cmp	x16, #0x1
     5a4:      	b.eq	0x5c0 <_stogir.pipeline.prepare+0x78>
     5a8:      	b.lo	0x5b0 <_stogir.pipeline.prepare+0x68>
     5ac:      	b	0x5c4 <_stogir.pipeline.prepare+0x7c>
     5b0:      	cmp	x16, #0x0
     5b4:      	b.eq	0x5bc <_stogir.pipeline.prepare+0x74>
     5b8:      	b	0x5c4 <_stogir.pipeline.prepare+0x7c>
     5bc:      	b	0x608 <_stogir.pipeline.prepare+0xc0>
     5c0:      	b	0x5c8 <_stogir.pipeline.prepare+0x80>
     5c4:      	b	0x668 <_stogir.pipeline.prepare+0x120>
     5c8:      	add	x16, sp, #0x10
     5cc:      	orr	x0, x16, xzr
     5d0:      	add	x16, sp, #0x30
     5d4:      	orr	x25, x16, xzr
     5d8:      	add	x0, x0, #0x8
     5dc:      	add	x1, x25, #0x8
     5e0:      	add	x16, sp, #0x10
     5e4:      	ldr	x2, [x16, #0x8]
     5e8:      	ldr	x0, [x0, #0x8]
     5ec:      	add	x16, sp, #0x30
     5f0:      	mov	w17, #0x1               ; =1
     5f4:      	str	w17, [x16]
     5f8:      	add	x16, sp, #0x30
     5fc:      	str	x2, [x16, #0x8]
     600:      	str	x0, [x1, #0x8]
     604:      	b	0x62c <_stogir.pipeline.prepare+0xe4>
     608:      	add	x16, sp, #0x180
     60c:      	orr	x25, x16, xzr
     610:      	add	x8, sp, #0x180
     614:      	mov	x0, x20
     618:      	mov	w1, w21
     61c:      	mov	x2, x22
     620:      	mov	x3, x23
     624:      	mov	x4, x24
     628:      	bl	0x628 <_stogir.pipeline.prepare+0xe0>
		0000000000000628:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare-checked
     62c:      	mov	x0, x19
     630:      	mov	x1, x25
     634:      	mov	x2, #0x148              ; =328
     638:      	bl	0x638 <_stogir.pipeline.prepare+0xf0>
		0000000000000638:  ARM64_RELOC_BRANCH26	_memmove
     63c:      	ldr	x19, [sp, #0x2d0]
     640:      	ldr	x20, [sp, #0x2d8]
     644:      	ldr	x21, [sp, #0x2e0]
     648:      	ldr	x22, [sp, #0x2e8]
     64c:      	ldr	x23, [sp, #0x2f0]
     650:      	ldr	x24, [sp, #0x2f8]
     654:      	ldr	x25, [sp, #0x300]
     658:      	ldr	x29, [sp]
     65c:      	ldr	x30, [sp, #0x8]
     660:      	add	sp, sp, #0x310
     664:      	ret
     668:      	brk	#0
     66c:      	b	0x668 <_stogir.pipeline.prepare+0x120>

0000000000000670 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32>:
     670:      	ldr	x1, [x0]
     674:      	ldr	x0, [x0, #0x8]
     678:      	str	x1, [x8]
     67c:      	str	x0, [x8, #0x8]
     680:      	movz	x17, #0x0, lsl #48
     684:      	str	x17, [x8, #0x10]
     688:      	ret

000000000000068c <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
     68c:      	sub	sp, sp, #0x10
     690:      	mov	x1, sp
     694:      	ldr	x2, [x0, #0x10]
     698:      	ldr	x3, [x0]
     69c:      	ldr	x4, [x0, #0x8]
     6a0:      	cmp	x2, x4
     6a4:      	b.ge	0x6c8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x3c>
     6a8:      	add	x4, x2, #0x1
     6ac:      	add	x2, x3, x2, lsl #2
     6b0:      	str	x4, [x0, #0x10]
     6b4:      	ldr	w0, [x2]
     6b8:      	sxtw	x0, w0
     6bc:      	and	x0, x0, #0xffffffff
     6c0:      	mov	x2, #0x1                ; =1
     6c4:      	b	0x6d0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
     6c8:      	movz	x2, #0x0, lsl #48
     6cc:      	movz	x0, #0x0, lsl #48
     6d0:      	str	x2, [x1]
     6d4:      	str	x0, [x1, #0x8]
     6d8:      	ldr	x0, [sp]
     6dc:      	ldr	x1, [sp, #0x8]
     6e0:      	add	sp, sp, #0x10
     6e4:      	ret

00000000000006e8 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate>:
     6e8:      	sub	sp, sp, #0x40
     6ec:      	str	x29, [sp]
     6f0:      	str	x30, [sp, #0x8]
     6f4:      	mov	x29, sp
     6f8:      	str	x19, [sp, #0x20]
     6fc:      	str	x20, [sp, #0x28]
     700:      	str	x21, [sp, #0x30]
     704:      	add	x19, x29, #0x10
     708:      	mov	x20, sp
     70c:      	sub	sp, sp, #0x10
     710:      	mov	x21, sp
     714:      	ldr	x0, [x1, #0x18]
     718:      	ldr	x1, [x1, #0x10]
     71c:      	cmp	x0, #0x10
     720:      	b.gt	0x740 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x58>
     724:      	mov	x0, x1
     728:      	bl	0x728 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x40>
		0000000000000728:  ARM64_RELOC_BRANCH26	_malloc
     72c:      	cmp	x0, #0x0
     730:      	b.ne	0x770 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x88>
     734:      	movz	x1, #0x0, lsl #48
     738:      	movz	x0, #0x0, lsl #48
     73c:      	b	0x774 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x8c>
     740:      	movz	x17, #0x0, lsl #48
     744:      	str	x17, [x21]
     748:      	mov	x2, x1
     74c:      	mov	x1, x0
     750:      	mov	x0, x21
     754:      	bl	0x754 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x6c>
		0000000000000754:  ARM64_RELOC_BRANCH26	_posix_memalign
     758:      	sxtw	x0, w0
     75c:      	cmp	x0, #0x0
     760:      	b.ne	0x778 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x90>
     764:      	ldr	x0, [x21]
     768:      	mov	x1, #0x1                ; =1
     76c:      	b	0x780 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     770:      	mov	x1, #0x1                ; =1
     774:      	b	0x780 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     778:      	movz	x1, #0x0, lsl #48
     77c:      	movz	x0, #0x0, lsl #48
     780:      	mov	sp, x20
     784:      	str	x1, [x19]
     788:      	str	x0, [x19, #0x8]
     78c:      	ldr	x0, [x29, #0x10]
     790:      	ldr	x1, [x29, #0x18]
     794:      	sub	sp, x29, #0x0
     798:      	ldr	x19, [sp, #0x20]
     79c:      	ldr	x20, [sp, #0x28]
     7a0:      	ldr	x21, [sp, #0x30]
     7a4:      	ldr	x29, [sp]
     7a8:      	ldr	x30, [sp, #0x8]
     7ac:      	add	sp, sp, #0x40
     7b0:      	ret

00000000000007b4 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$resize>:
     7b4:      	ldr	x0, [x3, #0x10]
     7b8:      	ldr	x1, [x2, #0x10]
     7bc:      	cmp	x0, x1
     7c0:      	cset	w0, le
     7c4:      	ubfx	x0, x0, #0, #8
     7c8:      	ret

00000000000007cc <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap>:
     7cc:      	sub	sp, sp, #0x30
     7d0:      	str	x29, [sp]
     7d4:      	str	x30, [sp, #0x8]
     7d8:      	mov	x29, sp
     7dc:      	str	x19, [sp, #0x20]
     7e0:      	add	x19, sp, #0x10
     7e4:      	ldr	x0, [x3, #0x18]
     7e8:      	cmp	x0, #0x10
     7ec:      	b.le	0x824 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x58>
     7f0:      	movz	x1, #0x0, lsl #48
     7f4:      	movz	x0, #0x0, lsl #48
     7f8:      	b	0x800 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x34>
     7fc:      	mov	x1, #0x1                ; =1
     800:      	str	x1, [x19]
     804:      	str	x0, [x19, #0x8]
     808:      	ldr	x0, [sp, #0x10]
     80c:      	ldr	x1, [sp, #0x18]
     810:      	ldr	x19, [sp, #0x20]
     814:      	ldr	x29, [sp]
     818:      	ldr	x30, [sp, #0x8]
     81c:      	add	sp, sp, #0x30
     820:      	ret
     824:      	ldr	x0, [x3, #0x10]
     828:      	fmov	d31, x0
     82c:      	mov	x0, x1
     830:      	fmov	x1, d31
     834:      	bl	0x834 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x68>
		0000000000000834:  ARM64_RELOC_BRANCH26	_realloc
     838:      	cmp	x0, #0x0
     83c:      	b.ne	0x7fc <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x30>
     840:      	movz	x1, #0x0, lsl #48
     844:      	movz	x0, #0x0, lsl #48
     848:      	b	0x800 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x34>

000000000000084c <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate>:
     84c:      	sub	sp, sp, #0x10
     850:      	str	x29, [sp]
     854:      	str	x30, [sp, #0x8]
     858:      	mov	x29, sp
     85c:      	mov	x0, x1
     860:      	bl	0x860 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate+0x14>
		0000000000000860:  ARM64_RELOC_BRANCH26	_free
     864:      	movz	x0, #0x0, lsl #48
     868:      	ldr	x29, [sp]
     86c:      	ldr	x30, [sp, #0x8]
     870:      	add	sp, sp, #0x10
     874:      	ret

0000000000000878 <_stogir.pipeline.validate-input>:
     878:      	sub	sp, sp, #0x40
     87c:      	str	x29, [sp]
     880:      	str	x30, [sp, #0x8]
     884:      	mov	x29, sp
     888:      	str	x19, [sp, #0x30]
     88c:      	mov	x19, x8
     890:      	add	x8, sp, #0x10
     894:      	bl	0x894 <_stogir.pipeline.validate-input+0x1c>
		0000000000000894:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input
     898:      	add	x16, sp, #0x10
     89c:      	ldr	x0, [x16]
     8a0:      	str	x0, [x19]
     8a4:      	add	x16, sp, #0x10
     8a8:      	ldr	x0, [x16, #0x8]
     8ac:      	str	x0, [x19, #0x8]
     8b0:      	add	x16, sp, #0x10
     8b4:      	ldr	x0, [x16, #0x10]
     8b8:      	str	x0, [x19, #0x10]
     8bc:      	ldr	x19, [sp, #0x30]
     8c0:      	ldr	x29, [sp]
     8c4:      	ldr	x30, [sp, #0x8]
     8c8:      	add	sp, sp, #0x40
     8cc:      	ret

00000000000008d0 <_stogir.pipeline.prepare-checked>:
     8d0:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
     8d4:      	str	x29, [sp]
     8d8:      	str	x30, [sp, #0x8]
     8dc:      	mov	x29, sp
     8e0:      	str	x19, [sp, #0xfb0]
     8e4:      	str	x20, [sp, #0xfb8]
     8e8:      	str	x21, [sp, #0xfc0]
     8ec:      	str	x22, [sp, #0xfc8]
     8f0:      	str	x23, [sp, #0xfd0]
     8f4:      	str	x24, [sp, #0xfd8]
     8f8:      	str	x25, [sp, #0xfe0]
     8fc:      	str	x26, [sp, #0xfe8]
     900:      	str	x27, [sp, #0xff0]
     904:      	str	x28, [sp, #0xff8]
     908:      	sxtw	x5, w1
     90c:      	cmp	x5, #0x0
     910:      	b.gt	0x990 <_stogir.pipeline.prepare-checked+0xc0>
     914:      	str	x8, [sp, #0xe58]
     918:      	add	x16, sp, #0x10
     91c:      	orr	x19, x16, xzr
     920:      	add	x16, sp, #0x10
     924:      	mov	w17, #0x1               ; =1
     928:      	str	w17, [x16]
     92c:      	add	x0, x19, #0x8
     930:      	add	x16, sp, #0x10
     934:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000934:  ARM64_RELOC_PAGE21	l_stogir.393
     938:      	ldr	x17, [x17]
		0000000000000938:  ARM64_RELOC_PAGEOFF12	l_stogir.393
     93c:      	str	x17, [x16, #0x8]
     940:      	mov	x17, #0x17              ; =23
     944:      	str	x17, [x0, #0x8]
     948:      	ldr	x0, [sp, #0xe58]
     94c:      	mov	x1, x19
     950:      	mov	x2, #0x148              ; =328
     954:      	bl	0x954 <_stogir.pipeline.prepare-checked+0x84>
		0000000000000954:  ARM64_RELOC_BRANCH26	_memmove
     958:      	ldr	x19, [sp, #0xfb0]
     95c:      	ldr	x20, [sp, #0xfb8]
     960:      	ldr	x21, [sp, #0xfc0]
     964:      	ldr	x22, [sp, #0xfc8]
     968:      	ldr	x23, [sp, #0xfd0]
     96c:      	ldr	x24, [sp, #0xfd8]
     970:      	ldr	x25, [sp, #0xfe0]
     974:      	ldr	x26, [sp, #0xfe8]
     978:      	ldr	x27, [sp, #0xff0]
     97c:      	ldr	x28, [sp, #0xff8]
     980:      	ldr	x29, [sp]
     984:      	ldr	x30, [sp, #0x8]
     988:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     98c:      	ret
     990:      	mov	x19, x8
     994:      	mov	x20, x0
     998:      	mov	w21, w1
     99c:      	mov	x22, x2
     9a0:      	mov	x23, x3
     9a4:      	mov	x24, x4
     9a8:      	bl	0x9a8 <_stogir.pipeline.prepare-checked+0xd8>
		00000000000009a8:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
     9ac:      	cmp	x0, #0x0
     9b0:      	b.eq	0x1db4 <_stogir.pipeline.prepare-checked+0x14e4>
     9b4:      	add	x16, sp, #0x160
     9b8:      	orr	x25, x16, xzr
     9bc:      	add	x8, sp, #0x160
     9c0:      	mov	x0, x20
     9c4:      	mov	x1, x24
     9c8:      	bl	0x9c8 <_stogir.pipeline.prepare-checked+0xf8>
		00000000000009c8:  ARM64_RELOC_BRANCH26	_stogir.cfg.build
     9cc:      	add	x16, sp, #0x160
     9d0:      	ldr	w0, [x16]
     9d4:      	lsr	x16, x0, #0
     9d8:      	cmp	x16, #0x1
     9dc:      	b.eq	0x9f8 <_stogir.pipeline.prepare-checked+0x128>
     9e0:      	b.lo	0x9e8 <_stogir.pipeline.prepare-checked+0x118>
     9e4:      	b	0x9fc <_stogir.pipeline.prepare-checked+0x12c>
     9e8:      	cmp	x16, #0x0
     9ec:      	b.eq	0x9f4 <_stogir.pipeline.prepare-checked+0x124>
     9f0:      	b	0x9fc <_stogir.pipeline.prepare-checked+0x12c>
     9f4:      	b	0xa40 <_stogir.pipeline.prepare-checked+0x170>
     9f8:      	b	0xa00 <_stogir.pipeline.prepare-checked+0x130>
     9fc:      	b	0x1a84 <_stogir.pipeline.prepare-checked+0x11b4>
     a00:      	add	x16, sp, #0x1e0
     a04:      	orr	x20, x16, xzr
     a08:      	add	x0, x25, #0x8
     a0c:      	add	x1, x20, #0x8
     a10:      	add	x16, sp, #0x160
     a14:      	ldr	x2, [x16, #0x8]
     a18:      	ldr	x0, [x0, #0x8]
     a1c:      	add	x16, sp, #0x1e0
     a20:      	mov	w17, #0x1               ; =1
     a24:      	str	w17, [x16]
     a28:      	add	x16, sp, #0x1e0
     a2c:      	str	x2, [x16, #0x8]
     a30:      	str	x0, [x1, #0x8]
     a34:      	str	x19, [sp, #0xe58]
     a38:      	mov	x19, x20
     a3c:      	b	0x948 <_stogir.pipeline.prepare-checked+0x78>
     a40:      	add	x16, sp, #0x330
     a44:      	orr	x26, x16, xzr
     a48:      	add	x16, sp, #0x3b0
     a4c:      	orr	x27, x16, xzr
     a50:      	add	x16, sp, #0x450
     a54:      	orr	x28, x16, xzr
     a58:      	add	x16, sp, #0x4f0
     a5c:      	orr	x0, x16, xzr
     a60:      	add	x16, sp, #0x550
     a64:      	orr	x1, x16, xzr
     a68:      	add	x16, sp, #0x5b0
     a6c:      	orr	x2, x16, xzr
     a70:      	add	x16, sp, #0x610
     a74:      	orr	x3, x16, xzr
     a78:      	add	x16, sp, #0x670
     a7c:      	orr	x4, x16, xzr
     a80:      	add	x16, sp, #0x710
     a84:      	orr	x5, x16, xzr
     a88:      	add	x16, sp, #0x760
     a8c:      	orr	x6, x16, xzr
     a90:      	add	x7, x25, #0x8
     a94:      	add	x16, sp, #0x160
     a98:      	ldr	x8, [x16, #0x8]
     a9c:      	ldr	x9, [x7, #0x8]
     aa0:      	ldr	x10, [x7, #0x10]
     aa4:      	ldr	x11, [x7, #0x18]
     aa8:      	ldr	x12, [x7, #0x20]
     aac:      	ldr	x13, [x7, #0x28]
     ab0:      	ldr	x14, [x7, #0x30]
     ab4:      	ldr	x15, [x7, #0x38]
     ab8:      	ldr	x25, [x7, #0x40]
     abc:      	str	x0, [sp, #0xe30]
     ac0:      	ldr	x0, [x7, #0x48]
     ac4:      	str	x1, [sp, #0xe38]
     ac8:      	ldr	x1, [x7, #0x50]
     acc:      	str	x2, [sp, #0xe40]
     ad0:      	ldr	x2, [x7, #0x58]
     ad4:      	str	x3, [sp, #0xe48]
     ad8:      	ldr	x3, [x7, #0x60]
     adc:      	str	x4, [sp, #0xe50]
     ae0:      	ldr	x4, [x7, #0x68]
     ae4:      	ldr	x7, [x7, #0x70]
     ae8:      	add	x16, sp, #0x330
     aec:      	str	x8, [x16]
     af0:      	add	x16, sp, #0x330
     af4:      	str	x9, [x16, #0x8]
     af8:      	add	x16, sp, #0x330
     afc:      	str	x10, [x16, #0x10]
     b00:      	add	x16, sp, #0x330
     b04:      	str	x11, [x16, #0x18]
     b08:      	add	x16, sp, #0x330
     b0c:      	str	x12, [x16, #0x20]
     b10:      	add	x16, sp, #0x330
     b14:      	str	x13, [x16, #0x28]
     b18:      	add	x16, sp, #0x330
     b1c:      	str	x14, [x16, #0x30]
     b20:      	add	x16, sp, #0x330
     b24:      	str	x15, [x16, #0x38]
     b28:      	add	x16, sp, #0x330
     b2c:      	str	x25, [x16, #0x40]
     b30:      	add	x16, sp, #0x330
     b34:      	str	x0, [x16, #0x48]
     b38:      	add	x16, sp, #0x330
     b3c:      	str	x1, [x16, #0x50]
     b40:      	add	x16, sp, #0x330
     b44:      	str	x2, [x16, #0x58]
     b48:      	add	x16, sp, #0x330
     b4c:      	str	x3, [x16, #0x60]
     b50:      	add	x16, sp, #0x330
     b54:      	str	x4, [x16, #0x68]
     b58:      	add	x16, sp, #0x330
     b5c:      	str	x7, [x16, #0x70]
     b60:      	add	x8, sp, #0x400
     b64:      	mov	x0, x26
     b68:      	mov	x2, x24
     b6c:      	ldr	x25, [sp, #0xe30]
     b70:      	str	x19, [sp, #0xe58]
     b74:      	ldr	x19, [sp, #0xe38]
     b78:      	str	x20, [sp, #0xe60]
     b7c:      	ldr	x20, [sp, #0xe40]
     b80:      	str	x22, [sp, #0xe68]
     b84:      	ldr	x22, [sp, #0xe48]
     b88:      	str	x23, [sp, #0xe70]
     b8c:      	mov	x23, x5
     b90:      	str	x26, [sp, #0xe78]
     b94:      	mov	x26, x6
     b98:      	mov	x1, #0x1                ; =1
     b9c:      	uxtb	w1, w1
     ba0:      	bl	0xba0 <_stogir.pipeline.prepare-checked+0x2d0>
		0000000000000ba0:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     ba4:      	add	x16, sp, #0x400
     ba8:      	ldr	x0, [x16]
     bac:      	add	x16, sp, #0x3b0
     bb0:      	str	x0, [x16]
     bb4:      	add	x16, sp, #0x400
     bb8:      	ldr	x0, [x16, #0x8]
     bbc:      	add	x16, sp, #0x3b0
     bc0:      	str	x0, [x16, #0x8]
     bc4:      	add	x16, sp, #0x400
     bc8:      	ldr	x0, [x16, #0x10]
     bcc:      	add	x16, sp, #0x3b0
     bd0:      	str	x0, [x16, #0x10]
     bd4:      	add	x16, sp, #0x400
     bd8:      	ldr	x0, [x16, #0x18]
     bdc:      	add	x16, sp, #0x3b0
     be0:      	str	x0, [x16, #0x18]
     be4:      	add	x16, sp, #0x400
     be8:      	ldr	x0, [x16, #0x20]
     bec:      	add	x16, sp, #0x3b0
     bf0:      	str	x0, [x16, #0x20]
     bf4:      	add	x16, sp, #0x400
     bf8:      	ldr	x0, [x16, #0x28]
     bfc:      	add	x16, sp, #0x3b0
     c00:      	str	x0, [x16, #0x28]
     c04:      	add	x16, sp, #0x400
     c08:      	ldr	x0, [x16, #0x30]
     c0c:      	add	x16, sp, #0x3b0
     c10:      	str	x0, [x16, #0x30]
     c14:      	add	x16, sp, #0x400
     c18:      	ldr	x0, [x16, #0x38]
     c1c:      	add	x16, sp, #0x3b0
     c20:      	str	x0, [x16, #0x38]
     c24:      	add	x16, sp, #0x400
     c28:      	ldr	x0, [x16, #0x40]
     c2c:      	add	x16, sp, #0x3b0
     c30:      	str	x0, [x16, #0x40]
     c34:      	add	x16, sp, #0x400
     c38:      	ldr	x0, [x16, #0x48]
     c3c:      	add	x16, sp, #0x3b0
     c40:      	str	x0, [x16, #0x48]
     c44:      	add	x8, sp, #0x4a0
     c48:      	ldr	x0, [sp, #0xe78]
     c4c:      	mov	x2, x24
     c50:      	movz	x1, #0x0, lsl #48
     c54:      	uxtb	w1, w1
     c58:      	bl	0xc58 <_stogir.pipeline.prepare-checked+0x388>
		0000000000000c58:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     c5c:      	add	x16, sp, #0x4a0
     c60:      	ldr	x0, [x16]
     c64:      	add	x16, sp, #0x450
     c68:      	str	x0, [x16]
     c6c:      	add	x16, sp, #0x4a0
     c70:      	ldr	x0, [x16, #0x8]
     c74:      	add	x16, sp, #0x450
     c78:      	str	x0, [x16, #0x8]
     c7c:      	add	x16, sp, #0x4a0
     c80:      	ldr	x0, [x16, #0x10]
     c84:      	add	x16, sp, #0x450
     c88:      	str	x0, [x16, #0x10]
     c8c:      	add	x16, sp, #0x4a0
     c90:      	ldr	x0, [x16, #0x18]
     c94:      	add	x16, sp, #0x450
     c98:      	str	x0, [x16, #0x18]
     c9c:      	add	x16, sp, #0x4a0
     ca0:      	ldr	x0, [x16, #0x20]
     ca4:      	add	x16, sp, #0x450
     ca8:      	str	x0, [x16, #0x20]
     cac:      	add	x16, sp, #0x4a0
     cb0:      	ldr	x0, [x16, #0x28]
     cb4:      	add	x16, sp, #0x450
     cb8:      	str	x0, [x16, #0x28]
     cbc:      	add	x16, sp, #0x4a0
     cc0:      	ldr	x0, [x16, #0x30]
     cc4:      	add	x16, sp, #0x450
     cc8:      	str	x0, [x16, #0x30]
     ccc:      	add	x16, sp, #0x4a0
     cd0:      	ldr	x0, [x16, #0x38]
     cd4:      	add	x16, sp, #0x450
     cd8:      	str	x0, [x16, #0x38]
     cdc:      	add	x16, sp, #0x4a0
     ce0:      	ldr	x0, [x16, #0x40]
     ce4:      	add	x16, sp, #0x450
     ce8:      	str	x0, [x16, #0x40]
     cec:      	add	x16, sp, #0x4a0
     cf0:      	ldr	x0, [x16, #0x48]
     cf4:      	add	x16, sp, #0x450
     cf8:      	str	x0, [x16, #0x48]
     cfc:      	add	x8, sp, #0x520
     d00:      	ldr	x0, [sp, #0xe78]
     d04:      	mov	x1, x28
     d08:      	mov	w2, w21
     d0c:      	mov	x3, x24
     d10:      	bl	0xd10 <_stogir.pipeline.prepare-checked+0x440>
		0000000000000d10:  ARM64_RELOC_BRANCH26	_stogir.adjacency.reverse-postorder
     d14:      	add	x16, sp, #0x520
     d18:      	ldr	x0, [x16]
     d1c:      	add	x16, sp, #0x4f0
     d20:      	str	x0, [x16]
     d24:      	add	x16, sp, #0x520
     d28:      	ldr	x0, [x16, #0x8]
     d2c:      	add	x16, sp, #0x4f0
     d30:      	str	x0, [x16, #0x8]
     d34:      	add	x16, sp, #0x520
     d38:      	ldr	x0, [x16, #0x10]
     d3c:      	add	x16, sp, #0x4f0
     d40:      	str	x0, [x16, #0x10]
     d44:      	add	x16, sp, #0x520
     d48:      	ldr	x0, [x16, #0x18]
     d4c:      	add	x16, sp, #0x4f0
     d50:      	str	x0, [x16, #0x18]
     d54:      	add	x16, sp, #0x520
     d58:      	ldr	x0, [x16, #0x20]
     d5c:      	add	x16, sp, #0x4f0
     d60:      	str	x0, [x16, #0x20]
     d64:      	add	x8, sp, #0x580
     d68:      	ldr	x0, [sp, #0xe78]
     d6c:      	mov	x1, x27
     d70:      	mov	x2, x25
     d74:      	mov	x3, x24
     d78:      	bl	0xd78 <_stogir.pipeline.prepare-checked+0x4a8>
		0000000000000d78:  ARM64_RELOC_BRANCH26	_stogir.dominators.build
     d7c:      	add	x16, sp, #0x580
     d80:      	ldr	x0, [x16]
     d84:      	add	x16, sp, #0x550
     d88:      	str	x0, [x16]
     d8c:      	add	x16, sp, #0x580
     d90:      	ldr	x0, [x16, #0x8]
     d94:      	add	x16, sp, #0x550
     d98:      	str	x0, [x16, #0x8]
     d9c:      	add	x16, sp, #0x580
     da0:      	ldr	x0, [x16, #0x10]
     da4:      	add	x16, sp, #0x550
     da8:      	str	x0, [x16, #0x10]
     dac:      	add	x16, sp, #0x580
     db0:      	ldr	x0, [x16, #0x18]
     db4:      	add	x16, sp, #0x550
     db8:      	str	x0, [x16, #0x18]
     dbc:      	add	x16, sp, #0x580
     dc0:      	ldr	x0, [x16, #0x20]
     dc4:      	add	x16, sp, #0x550
     dc8:      	str	x0, [x16, #0x20]
     dcc:      	add	x8, sp, #0x5e0
     dd0:      	ldr	x0, [sp, #0xe78]
     dd4:      	mov	x1, x27
     dd8:      	mov	x2, x19
     ddc:      	mov	x3, x24
     de0:      	bl	0xde0 <_stogir.pipeline.prepare-checked+0x510>
		0000000000000de0:  ARM64_RELOC_BRANCH26	_stogir.loops.depths
     de4:      	add	x16, sp, #0x5e0
     de8:      	ldr	x0, [x16]
     dec:      	add	x16, sp, #0x5b0
     df0:      	str	x0, [x16]
     df4:      	add	x16, sp, #0x5e0
     df8:      	ldr	x0, [x16, #0x8]
     dfc:      	add	x16, sp, #0x5b0
     e00:      	str	x0, [x16, #0x8]
     e04:      	add	x16, sp, #0x5e0
     e08:      	ldr	x0, [x16, #0x10]
     e0c:      	add	x16, sp, #0x5b0
     e10:      	str	x0, [x16, #0x10]
     e14:      	add	x16, sp, #0x5e0
     e18:      	ldr	x0, [x16, #0x18]
     e1c:      	add	x16, sp, #0x5b0
     e20:      	str	x0, [x16, #0x18]
     e24:      	add	x16, sp, #0x5e0
     e28:      	ldr	x0, [x16, #0x20]
     e2c:      	add	x16, sp, #0x5b0
     e30:      	str	x0, [x16, #0x20]
     e34:      	add	x8, sp, #0x640
     e38:      	ldr	x0, [sp, #0xe60]
     e3c:      	ldr	x1, [sp, #0xe68]
     e40:      	ldr	x2, [sp, #0xe70]
     e44:      	mov	x3, x24
     e48:      	bl	0xe48 <_stogir.pipeline.prepare-checked+0x578>
		0000000000000e48:  ARM64_RELOC_BRANCH26	_stogir.liveness.mark
     e4c:      	add	x16, sp, #0x640
     e50:      	ldr	x0, [x16]
     e54:      	add	x16, sp, #0x610
     e58:      	str	x0, [x16]
     e5c:      	add	x16, sp, #0x640
     e60:      	ldr	x0, [x16, #0x8]
     e64:      	add	x16, sp, #0x610
     e68:      	str	x0, [x16, #0x8]
     e6c:      	add	x16, sp, #0x640
     e70:      	ldr	x0, [x16, #0x10]
     e74:      	add	x16, sp, #0x610
     e78:      	str	x0, [x16, #0x10]
     e7c:      	add	x16, sp, #0x640
     e80:      	ldr	x0, [x16, #0x18]
     e84:      	add	x16, sp, #0x610
     e88:      	str	x0, [x16, #0x18]
     e8c:      	add	x16, sp, #0x640
     e90:      	ldr	x0, [x16, #0x20]
     e94:      	add	x16, sp, #0x610
     e98:      	str	x0, [x16, #0x20]
     e9c:      	add	x8, sp, #0x6c0
     ea0:      	ldr	x0, [sp, #0xe60]
     ea4:      	mov	x1, x24
     ea8:      	bl	0xea8 <_stogir.pipeline.prepare-checked+0x5d8>
		0000000000000ea8:  ARM64_RELOC_BRANCH26	_stogir.uses.build
     eac:      	add	x16, sp, #0x6c0
     eb0:      	ldr	x0, [x16]
     eb4:      	add	x16, sp, #0x670
     eb8:      	str	x0, [x16]
     ebc:      	add	x16, sp, #0x6c0
     ec0:      	ldr	x0, [x16, #0x8]
     ec4:      	add	x16, sp, #0x670
     ec8:      	str	x0, [x16, #0x8]
     ecc:      	add	x16, sp, #0x6c0
     ed0:      	ldr	x0, [x16, #0x10]
     ed4:      	add	x16, sp, #0x670
     ed8:      	str	x0, [x16, #0x10]
     edc:      	add	x16, sp, #0x6c0
     ee0:      	ldr	x0, [x16, #0x18]
     ee4:      	add	x16, sp, #0x670
     ee8:      	str	x0, [x16, #0x18]
     eec:      	add	x16, sp, #0x6c0
     ef0:      	ldr	x0, [x16, #0x20]
     ef4:      	add	x16, sp, #0x670
     ef8:      	str	x0, [x16, #0x20]
     efc:      	add	x16, sp, #0x6c0
     f00:      	ldr	x0, [x16, #0x28]
     f04:      	add	x16, sp, #0x670
     f08:      	str	x0, [x16, #0x28]
     f0c:      	add	x16, sp, #0x6c0
     f10:      	ldr	x0, [x16, #0x30]
     f14:      	add	x16, sp, #0x670
     f18:      	str	x0, [x16, #0x30]
     f1c:      	add	x16, sp, #0x6c0
     f20:      	ldr	x0, [x16, #0x38]
     f24:      	add	x16, sp, #0x670
     f28:      	str	x0, [x16, #0x38]
     f2c:      	add	x16, sp, #0x6c0
     f30:      	ldr	x0, [x16, #0x40]
     f34:      	add	x16, sp, #0x670
     f38:      	str	x0, [x16, #0x40]
     f3c:      	add	x16, sp, #0x6c0
     f40:      	ldr	x0, [x16, #0x48]
     f44:      	add	x16, sp, #0x670
     f48:      	str	x0, [x16, #0x48]
     f4c:      	ldr	x0, [x24]
     f50:      	ldr	x1, [x24, #0x8]
     f54:      	ldr	x2, [x24]
     f58:      	ldr	x3, [x24, #0x8]
     f5c:      	add	x16, sp, #0x710
     f60:      	movz	x17, #0x0, lsl #48
     f64:      	str	x17, [x16]
     f68:      	add	x16, sp, #0x710
     f6c:      	movz	x17, #0x0, lsl #48
     f70:      	str	x17, [x16, #0x8]
     f74:      	add	x16, sp, #0x710
     f78:      	movz	x17, #0x0, lsl #48
     f7c:      	str	x17, [x16, #0x10]
     f80:      	add	x16, sp, #0x710
     f84:      	str	x0, [x16, #0x18]
     f88:      	add	x16, sp, #0x710
     f8c:      	str	x1, [x16, #0x20]
     f90:      	add	x16, sp, #0x710
     f94:      	movz	x17, #0x0, lsl #48
     f98:      	str	x17, [x16, #0x28]
     f9c:      	add	x16, sp, #0x710
     fa0:      	movz	x17, #0x0, lsl #48
     fa4:      	str	x17, [x16, #0x30]
     fa8:      	add	x16, sp, #0x710
     fac:      	movz	x17, #0x0, lsl #48
     fb0:      	str	x17, [x16, #0x38]
     fb4:      	add	x16, sp, #0x710
     fb8:      	str	x2, [x16, #0x40]
     fbc:      	add	x16, sp, #0x710
     fc0:      	str	x3, [x16, #0x48]
     fc4:      	add	x8, sp, #0x760
     fc8:      	ldr	x0, [sp, #0xe60]
     fcc:      	ldr	x1, [sp, #0xe78]
     fd0:      	mov	x2, x24
     fd4:      	bl	0xfd4 <_stogir.pipeline.prepare-checked+0x704>
		0000000000000fd4:  ARM64_RELOC_BRANCH26	_stogir.placement.pinned
     fd8:      	add	x16, sp, #0x760
     fdc:      	ldr	w0, [x16]
     fe0:      	lsr	x16, x0, #0
     fe4:      	cmp	x16, #0x1
     fe8:      	b.eq	0x1004 <_stogir.pipeline.prepare-checked+0x734>
     fec:      	b.lo	0xff4 <_stogir.pipeline.prepare-checked+0x724>
     ff0:      	b	0x1008 <_stogir.pipeline.prepare-checked+0x738>
     ff4:      	cmp	x16, #0x0
     ff8:      	b.eq	0x1000 <_stogir.pipeline.prepare-checked+0x730>
     ffc:      	b	0x1008 <_stogir.pipeline.prepare-checked+0x738>
    1000:      	b	0x1590 <_stogir.pipeline.prepare-checked+0xcc0>
    1004:      	b	0x100c <_stogir.pipeline.prepare-checked+0x73c>
    1008:      	b	0x1d7c <_stogir.pipeline.prepare-checked+0x14ac>
    100c:      	add	x0, x26, #0x8
    1010:      	add	x16, sp, #0x760
    1014:      	ldr	x21, [x16, #0x8]
    1018:      	ldr	x26, [x0, #0x8]
    101c:      	str	x28, [sp, #0xe88]
    1020:      	b	0x1514 <_stogir.pipeline.prepare-checked+0xc44>
    1024:      	nop
    1028:      	sub	x0, x0, #0x1
    102c:      	add	x16, sp, #0x610
    1030:      	str	x0, [x16, #0x8]
    1034:      	add	x16, sp, #0x610
    1038:      	ldr	x0, [x16, #0x8]
    103c:      	cmp	x0, #0x0
    1040:      	b.ne	0x1028 <_stogir.pipeline.prepare-checked+0x758>
    1044:      	add	x16, sp, #0x610
    1048:      	ldr	x0, [x16, #0x10]
    104c:      	cmp	x0, #0x0
    1050:      	b.le	0x1084 <_stogir.pipeline.prepare-checked+0x7b4>
    1054:      	add	x1, x22, #0x18
    1058:      	add	x16, sp, #0x610
    105c:      	ldr	x2, [x16]
    1060:      	fmov	d31, x0
    1064:      	mov	x0, x1
    1068:      	mov	x1, x2
    106c:      	fmov	x2, d31
    1070:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001070:  ARM64_RELOC_PAGE21	l_stogir.394
    1074:      	ldr	x3, [x3]
		0000000000001074:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    1078:      	mov	x4, #0x1                ; =1
    107c:      	mov	x5, #0x1                ; =1
    1080:      	bl	0x1080 <_stogir.pipeline.prepare-checked+0x7b0>
		0000000000001080:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1084:      	add	x16, sp, #0x610
    1088:      	movz	x17, #0x0, lsl #48
    108c:      	str	x17, [x16]
    1090:      	add	x16, sp, #0x610
    1094:      	movz	x17, #0x0, lsl #48
    1098:      	str	x17, [x16, #0x8]
    109c:      	add	x16, sp, #0x610
    10a0:      	movz	x17, #0x0, lsl #48
    10a4:      	str	x17, [x16, #0x10]
    10a8:      	ldr	x0, [sp, #0xe50]
    10ac:      	bl	0x10ac <_stogir.pipeline.prepare-checked+0x7dc>
		00000000000010ac:  ARM64_RELOC_BRANCH26	_stogir.uses.release!
    10b0:      	cmp	x26, #0x0
    10b4:      	b.ne	0x181c <_stogir.pipeline.prepare-checked+0xf4c>
    10b8:      	add	x16, sp, #0xa60
    10bc:      	orr	x20, x16, xzr
    10c0:      	add	x16, sp, #0xbb0
    10c4:      	orr	x0, x16, xzr
    10c8:      	add	x16, sp, #0xa60
    10cc:      	movz	w17, #0x0, lsl #16
    10d0:      	str	w17, [x16]
    10d4:      	add	x1, x20, #0x8
    10d8:      	add	x19, x0, #0x78
    10dc:      	add	x21, x0, #0xa0
    10e0:      	add	x22, x0, #0xf0
    10e4:      	add	x23, x0, #0x118
    10e8:      	add	x16, sp, #0x550
    10ec:      	ldr	x24, [x16]
    10f0:      	orr	x25, x1, xzr
    10f4:      	add	x16, sp, #0x550
    10f8:      	ldr	x26, [x16, #0x8]
    10fc:      	add	x16, sp, #0x550
    1100:      	ldr	x27, [x16, #0x10]
    1104:      	add	x16, sp, #0x550
    1108:      	ldr	x28, [x16, #0x18]
    110c:      	add	x16, sp, #0x550
    1110:      	ldr	x0, [x16, #0x20]
    1114:      	add	x16, sp, #0x5b0
    1118:      	ldr	x1, [x16]
    111c:      	add	x16, sp, #0x5b0
    1120:      	ldr	x2, [x16, #0x8]
    1124:      	add	x16, sp, #0x5b0
    1128:      	ldr	x3, [x16, #0x10]
    112c:      	add	x16, sp, #0x5b0
    1130:      	ldr	x4, [x16, #0x18]
    1134:      	add	x16, sp, #0x5b0
    1138:      	ldr	x5, [x16, #0x20]
    113c:      	add	x16, sp, #0x330
    1140:      	ldr	x6, [x16]
    1144:      	add	x16, sp, #0x330
    1148:      	ldr	x7, [x16, #0x8]
    114c:      	add	x16, sp, #0x330
    1150:      	ldr	x8, [x16, #0x10]
    1154:      	add	x16, sp, #0x330
    1158:      	ldr	x9, [x16, #0x18]
    115c:      	add	x16, sp, #0x330
    1160:      	ldr	x10, [x16, #0x20]
    1164:      	add	x16, sp, #0x330
    1168:      	ldr	x11, [x16, #0x28]
    116c:      	add	x16, sp, #0x330
    1170:      	ldr	x12, [x16, #0x30]
    1174:      	add	x16, sp, #0x330
    1178:      	ldr	x13, [x16, #0x38]
    117c:      	add	x16, sp, #0x330
    1180:      	ldr	x14, [x16, #0x40]
    1184:      	add	x16, sp, #0x330
    1188:      	ldr	x15, [x16, #0x48]
    118c:      	str	x0, [sp, #0xe90]
    1190:      	add	x16, sp, #0x330
    1194:      	ldr	x0, [x16, #0x50]
    1198:      	str	x0, [sp, #0xe98]
    119c:      	add	x16, sp, #0x330
    11a0:      	ldr	x0, [x16, #0x58]
    11a4:      	str	x0, [sp, #0xea0]
    11a8:      	add	x16, sp, #0x330
    11ac:      	ldr	x0, [x16, #0x60]
    11b0:      	str	x0, [sp, #0xea8]
    11b4:      	add	x16, sp, #0x330
    11b8:      	ldr	x0, [x16, #0x68]
    11bc:      	str	x0, [sp, #0xeb0]
    11c0:      	add	x16, sp, #0x330
    11c4:      	ldr	x0, [x16, #0x70]
    11c8:      	str	x0, [sp, #0xeb8]
    11cc:      	add	x16, sp, #0x4f0
    11d0:      	ldr	x0, [x16]
    11d4:      	str	x0, [sp, #0xec0]
    11d8:      	add	x16, sp, #0x4f0
    11dc:      	ldr	x0, [x16, #0x8]
    11e0:      	str	x0, [sp, #0xec8]
    11e4:      	add	x16, sp, #0x4f0
    11e8:      	ldr	x0, [x16, #0x10]
    11ec:      	str	x0, [sp, #0xed0]
    11f0:      	add	x16, sp, #0x4f0
    11f4:      	ldr	x0, [x16, #0x18]
    11f8:      	str	x0, [sp, #0xed8]
    11fc:      	add	x16, sp, #0x4f0
    1200:      	ldr	x0, [x16, #0x20]
    1204:      	str	x0, [sp, #0xee0]
    1208:      	add	x16, sp, #0x710
    120c:      	ldr	x0, [x16]
    1210:      	str	x0, [sp, #0xee8]
    1214:      	add	x16, sp, #0x710
    1218:      	ldr	x0, [x16, #0x8]
    121c:      	str	x0, [sp, #0xef0]
    1220:      	add	x16, sp, #0x710
    1224:      	ldr	x0, [x16, #0x10]
    1228:      	str	x0, [sp, #0xef8]
    122c:      	add	x16, sp, #0x710
    1230:      	ldr	x0, [x16, #0x18]
    1234:      	str	x0, [sp, #0xf00]
    1238:      	add	x16, sp, #0x710
    123c:      	ldr	x0, [x16, #0x20]
    1240:      	str	x0, [sp, #0xf08]
    1244:      	add	x16, sp, #0x710
    1248:      	ldr	x0, [x16, #0x28]
    124c:      	str	x0, [sp, #0xf10]
    1250:      	add	x16, sp, #0x710
    1254:      	ldr	x0, [x16, #0x30]
    1258:      	str	x0, [sp, #0xf18]
    125c:      	add	x16, sp, #0x710
    1260:      	ldr	x0, [x16, #0x38]
    1264:      	str	x0, [sp, #0xf20]
    1268:      	add	x16, sp, #0x710
    126c:      	ldr	x0, [x16, #0x40]
    1270:      	str	x0, [sp, #0xf28]
    1274:      	add	x16, sp, #0x710
    1278:      	ldr	x0, [x16, #0x48]
    127c:      	str	x1, [sp, #0xf68]
    1280:      	str	x2, [sp, #0xf40]
    1284:      	str	x3, [sp, #0xf48]
    1288:      	str	x4, [sp, #0xf50]
    128c:      	str	x5, [sp, #0xf58]
    1290:      	str	x0, [sp, #0xfa8]
    1294:      	add	x0, sp, #0xbb0
    1298:      	str	x25, [sp, #0xf30]
    129c:      	mov	x25, x8
    12a0:      	str	x20, [sp, #0xf38]
    12a4:      	mov	x20, x7
    12a8:      	str	x23, [sp, #0xf60]
    12ac:      	mov	x23, x6
    12b0:      	str	x28, [sp, #0xf70]
    12b4:      	mov	x28, x9
    12b8:      	str	x27, [sp, #0xf78]
    12bc:      	mov	x27, x10
    12c0:      	str	x22, [sp, #0xf80]
    12c4:      	mov	x22, x11
    12c8:      	str	x26, [sp, #0xf88]
    12cc:      	mov	x26, x12
    12d0:      	str	x24, [sp, #0xf90]
    12d4:      	mov	x24, x13
    12d8:      	str	x21, [sp, #0xf98]
    12dc:      	mov	x21, x14
    12e0:      	str	x19, [sp, #0xfa0]
    12e4:      	mov	x19, x15
    12e8:      	movz	x1, #0x0, lsl #48
    12ec:      	mov	x2, #0x140              ; =320
    12f0:      	bl	0x12f0 <_stogir.pipeline.prepare-checked+0xa20>
		00000000000012f0:  ARM64_RELOC_BRANCH26	_memset
    12f4:      	add	x16, sp, #0xbb0
    12f8:      	str	x23, [x16]
    12fc:      	add	x16, sp, #0xbb0
    1300:      	str	x20, [x16, #0x8]
    1304:      	add	x16, sp, #0xbb0
    1308:      	str	x25, [x16, #0x10]
    130c:      	add	x16, sp, #0xbb0
    1310:      	str	x28, [x16, #0x18]
    1314:      	add	x16, sp, #0xbb0
    1318:      	str	x27, [x16, #0x20]
    131c:      	add	x16, sp, #0xbb0
    1320:      	str	x22, [x16, #0x28]
    1324:      	add	x16, sp, #0xbb0
    1328:      	str	x26, [x16, #0x30]
    132c:      	add	x16, sp, #0xbb0
    1330:      	str	x24, [x16, #0x38]
    1334:      	add	x16, sp, #0xbb0
    1338:      	str	x21, [x16, #0x40]
    133c:      	add	x16, sp, #0xbb0
    1340:      	str	x19, [x16, #0x48]
    1344:      	ldr	x0, [sp, #0xe98]
    1348:      	add	x16, sp, #0xbb0
    134c:      	str	x0, [x16, #0x50]
    1350:      	ldr	x0, [sp, #0xea0]
    1354:      	add	x16, sp, #0xbb0
    1358:      	str	x0, [x16, #0x58]
    135c:      	ldr	x0, [sp, #0xea8]
    1360:      	add	x16, sp, #0xbb0
    1364:      	str	x0, [x16, #0x60]
    1368:      	ldr	x0, [sp, #0xeb0]
    136c:      	add	x16, sp, #0xbb0
    1370:      	str	x0, [x16, #0x68]
    1374:      	ldr	x0, [sp, #0xeb8]
    1378:      	add	x16, sp, #0xbb0
    137c:      	str	x0, [x16, #0x70]
    1380:      	ldr	x0, [sp, #0xec0]
    1384:      	add	x16, sp, #0xbb0
    1388:      	str	x0, [x16, #0x78]
    138c:      	ldr	x0, [sp, #0xfa0]
    1390:      	ldr	x1, [sp, #0xec8]
    1394:      	str	x1, [x0, #0x8]
    1398:      	ldr	x1, [sp, #0xed0]
    139c:      	str	x1, [x0, #0x10]
    13a0:      	ldr	x1, [sp, #0xed8]
    13a4:      	str	x1, [x0, #0x18]
    13a8:      	ldr	x1, [sp, #0xee0]
    13ac:      	str	x1, [x0, #0x20]
    13b0:      	ldr	x0, [sp, #0xee8]
    13b4:      	add	x16, sp, #0xbb0
    13b8:      	str	x0, [x16, #0xa0]
    13bc:      	ldr	x0, [sp, #0xf98]
    13c0:      	ldr	x1, [sp, #0xef0]
    13c4:      	str	x1, [x0, #0x8]
    13c8:      	ldr	x1, [sp, #0xef8]
    13cc:      	str	x1, [x0, #0x10]
    13d0:      	ldr	x1, [sp, #0xf00]
    13d4:      	str	x1, [x0, #0x18]
    13d8:      	ldr	x1, [sp, #0xf08]
    13dc:      	str	x1, [x0, #0x20]
    13e0:      	ldr	x1, [sp, #0xf10]
    13e4:      	str	x1, [x0, #0x28]
    13e8:      	ldr	x1, [sp, #0xf18]
    13ec:      	str	x1, [x0, #0x30]
    13f0:      	ldr	x1, [sp, #0xf20]
    13f4:      	str	x1, [x0, #0x38]
    13f8:      	ldr	x1, [sp, #0xf28]
    13fc:      	str	x1, [x0, #0x40]
    1400:      	ldr	x1, [sp, #0xfa8]
    1404:      	str	x1, [x0, #0x48]
    1408:      	ldr	x0, [sp, #0xf90]
    140c:      	add	x16, sp, #0xbb0
    1410:      	str	x0, [x16, #0xf0]
    1414:      	ldr	x0, [sp, #0xf80]
    1418:      	ldr	x1, [sp, #0xf88]
    141c:      	str	x1, [x0, #0x8]
    1420:      	ldr	x1, [sp, #0xf78]
    1424:      	str	x1, [x0, #0x10]
    1428:      	ldr	x1, [sp, #0xf70]
    142c:      	str	x1, [x0, #0x18]
    1430:      	ldr	x1, [sp, #0xe90]
    1434:      	str	x1, [x0, #0x20]
    1438:      	ldr	x0, [sp, #0xf68]
    143c:      	add	x16, sp, #0xbb0
    1440:      	str	x0, [x16, #0x118]
    1444:      	ldr	x0, [sp, #0xf40]
    1448:      	ldr	x1, [sp, #0xf60]
    144c:      	str	x0, [x1, #0x8]
    1450:      	ldr	x0, [sp, #0xf48]
    1454:      	str	x0, [x1, #0x10]
    1458:      	ldr	x0, [sp, #0xf50]
    145c:      	str	x0, [x1, #0x18]
    1460:      	ldr	x0, [sp, #0xf58]
    1464:      	str	x0, [x1, #0x20]
    1468:      	add	x0, sp, #0xcf0
    146c:      	add	x1, sp, #0xbb0
    1470:      	mov	x2, #0x140              ; =320
    1474:      	bl	0x1474 <_stogir.pipeline.prepare-checked+0xba4>
		0000000000001474:  ARM64_RELOC_BRANCH26	_memmove
    1478:      	ldr	x0, [sp, #0xf30]
    147c:      	add	x1, sp, #0xcf0
    1480:      	mov	x2, #0x140              ; =320
    1484:      	bl	0x1484 <_stogir.pipeline.prepare-checked+0xbb4>
		0000000000001484:  ARM64_RELOC_BRANCH26	_memmove
    1488:      	ldr	x19, [sp, #0xf38]
    148c:      	b	0xa3c <_stogir.pipeline.prepare-checked+0x16c>
    1490:      	sub	x0, x0, #0x1
    1494:      	str	x0, [x24, #0x8]
    1498:      	ldr	x0, [x24, #0x8]
    149c:      	cmp	x0, #0x0
    14a0:      	b.ne	0x1490 <_stogir.pipeline.prepare-checked+0xbc0>
    14a4:      	ldr	x0, [x24, #0x10]
    14a8:      	cmp	x0, #0x0
    14ac:      	b.le	0x14e0 <_stogir.pipeline.prepare-checked+0xc10>
    14b0:      	add	x1, x24, #0x18
    14b4:      	add	x16, sp, #0x3b0
    14b8:      	ldr	x2, [x16, #0x28]
    14bc:      	fmov	d31, x0
    14c0:      	mov	x0, x1
    14c4:      	mov	x1, x2
    14c8:      	fmov	x2, d31
    14cc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		00000000000014cc:  ARM64_RELOC_PAGE21	l_stogir.395
    14d0:      	ldr	x3, [x3]
		00000000000014d0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    14d4:      	mov	x4, #0x8                ; =8
    14d8:      	mov	x5, #0x8                ; =8
    14dc:      	bl	0x14dc <_stogir.pipeline.prepare-checked+0xc0c>
		00000000000014dc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    14e0:      	add	x16, sp, #0x3b0
    14e4:      	movz	x17, #0x0, lsl #48
    14e8:      	str	x17, [x16, #0x28]
    14ec:      	movz	x17, #0x0, lsl #48
    14f0:      	str	x17, [x24, #0x8]
    14f4:      	movz	x17, #0x0, lsl #48
    14f8:      	str	x17, [x24, #0x10]
    14fc:      	ldr	x0, [sp, #0xe88]
    1500:      	bl	0x1500 <_stogir.pipeline.prepare-checked+0xc30>
		0000000000001500:  ARM64_RELOC_BRANCH26	_stogir.adjacency.release!
    1504:      	b	0x1034 <_stogir.pipeline.prepare-checked+0x764>
    1508:      	sub	x0, x0, #0x1
    150c:      	add	x16, sp, #0x3b0
    1510:      	str	x0, [x16, #0x8]
    1514:      	add	x16, sp, #0x3b0
    1518:      	ldr	x0, [x16, #0x8]
    151c:      	cmp	x0, #0x0
    1520:      	b.ne	0x1508 <_stogir.pipeline.prepare-checked+0xc38>
    1524:      	add	x16, sp, #0x3b0
    1528:      	ldr	x0, [x16, #0x10]
    152c:      	cmp	x0, #0x0
    1530:      	b.le	0x1564 <_stogir.pipeline.prepare-checked+0xc94>
    1534:      	add	x1, x27, #0x18
    1538:      	add	x16, sp, #0x3b0
    153c:      	ldr	x2, [x16]
    1540:      	fmov	d31, x0
    1544:      	mov	x0, x1
    1548:      	mov	x1, x2
    154c:      	fmov	x2, d31
    1550:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001550:  ARM64_RELOC_PAGE21	l_stogir.396
    1554:      	ldr	x3, [x3]
		0000000000001554:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    1558:      	mov	x4, #0x10               ; =16
    155c:      	mov	x5, #0x8                ; =8
    1560:      	bl	0x1560 <_stogir.pipeline.prepare-checked+0xc90>
		0000000000001560:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1564:      	add	x24, x27, #0x28
    1568:      	add	x16, sp, #0x3b0
    156c:      	movz	x17, #0x0, lsl #48
    1570:      	str	x17, [x16]
    1574:      	add	x16, sp, #0x3b0
    1578:      	movz	x17, #0x0, lsl #48
    157c:      	str	x17, [x16, #0x8]
    1580:      	add	x16, sp, #0x3b0
    1584:      	movz	x17, #0x0, lsl #48
    1588:      	str	x17, [x16, #0x10]
    158c:      	b	0x1498 <_stogir.pipeline.prepare-checked+0xbc8>
    1590:      	add	x16, sp, #0x790
    1594:      	orr	x0, x16, xzr
    1598:      	add	x1, x26, #0x8
    159c:      	add	x16, sp, #0x760
    15a0:      	ldr	x2, [x16, #0x8]
    15a4:      	ldr	x3, [x1, #0x8]
    15a8:      	ldr	x4, [x1, #0x10]
    15ac:      	ldr	x5, [x1, #0x18]
    15b0:      	ldr	x1, [x1, #0x20]
    15b4:      	add	x16, sp, #0x790
    15b8:      	str	x2, [x16]
    15bc:      	add	x16, sp, #0x790
    15c0:      	str	x3, [x16, #0x8]
    15c4:      	add	x16, sp, #0x790
    15c8:      	str	x4, [x16, #0x10]
    15cc:      	add	x16, sp, #0x790
    15d0:      	str	x5, [x16, #0x18]
    15d4:      	add	x16, sp, #0x790
    15d8:      	str	x1, [x16, #0x20]
    15dc:      	add	x8, sp, #0x7c0
    15e0:      	mov	x1, x0
    15e4:      	mov	x2, x19
    15e8:      	mov	w3, w21
    15ec:      	ldr	x4, [sp, #0xe50]
    15f0:      	mov	x5, x24
    15f4:      	mov	x26, x0
    15f8:      	ldr	x0, [sp, #0xe60]
    15fc:      	bl	0x15fc <_stogir.pipeline.prepare-checked+0xd2c>
		00000000000015fc:  ARM64_RELOC_BRANCH26	_stogir.placement.early-with-uses!
    1600:      	add	x16, sp, #0x7c0
    1604:      	ldr	w0, [x16]
    1608:      	lsr	x16, x0, #0
    160c:      	cmp	x16, #0x1
    1610:      	b.eq	0x1630 <_stogir.pipeline.prepare-checked+0xd60>
    1614:      	b.lo	0x161c <_stogir.pipeline.prepare-checked+0xd4c>
    1618:      	b	0x1634 <_stogir.pipeline.prepare-checked+0xd64>
    161c:      	cmp	x16, #0x0
    1620:      	b.eq	0x1628 <_stogir.pipeline.prepare-checked+0xd58>
    1624:      	b	0x1634 <_stogir.pipeline.prepare-checked+0xd64>
    1628:      	mov	x1, x26
    162c:      	b	0x1820 <_stogir.pipeline.prepare-checked+0xf50>
    1630:      	b	0x1638 <_stogir.pipeline.prepare-checked+0xd68>
    1634:      	b	0x1d84 <_stogir.pipeline.prepare-checked+0x14b4>
    1638:      	add	x16, sp, #0x7c0
    163c:      	orr	x0, x16, xzr
    1640:      	add	x0, x0, #0x8
    1644:      	add	x16, sp, #0x7c0
    1648:      	ldr	x21, [x16, #0x8]
    164c:      	mov	x1, x26
    1650:      	ldr	x26, [x0, #0x8]
    1654:      	b	0x182c <_stogir.pipeline.prepare-checked+0xf5c>
    1658:      	sub	x0, x0, #0x1
    165c:      	add	x16, sp, #0x4f0
    1660:      	str	x0, [x16, #0x8]
    1664:      	add	x16, sp, #0x4f0
    1668:      	ldr	x0, [x16, #0x8]
    166c:      	cmp	x0, #0x0
    1670:      	b.ne	0x1658 <_stogir.pipeline.prepare-checked+0xd88>
    1674:      	add	x16, sp, #0x4f0
    1678:      	ldr	x0, [x16, #0x10]
    167c:      	cmp	x0, #0x0
    1680:      	b.le	0x16b4 <_stogir.pipeline.prepare-checked+0xde4>
    1684:      	add	x1, x25, #0x18
    1688:      	add	x16, sp, #0x4f0
    168c:      	ldr	x2, [x16]
    1690:      	fmov	d31, x0
    1694:      	mov	x0, x1
    1698:      	mov	x1, x2
    169c:      	fmov	x2, d31
    16a0:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		00000000000016a0:  ARM64_RELOC_PAGE21	l_stogir.397
    16a4:      	ldr	x3, [x3]
		00000000000016a4:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    16a8:      	mov	x4, #0x4                ; =4
    16ac:      	mov	x5, #0x4                ; =4
    16b0:      	bl	0x16b0 <_stogir.pipeline.prepare-checked+0xde0>
		00000000000016b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    16b4:      	add	x16, sp, #0x910
    16b8:      	orr	x19, x16, xzr
    16bc:      	add	x20, x19, #0x8
    16c0:      	add	x16, sp, #0x4f0
    16c4:      	movz	x17, #0x0, lsl #48
    16c8:      	str	x17, [x16]
    16cc:      	add	x16, sp, #0x4f0
    16d0:      	movz	x17, #0x0, lsl #48
    16d4:      	str	x17, [x16, #0x8]
    16d8:      	add	x16, sp, #0x4f0
    16dc:      	movz	x17, #0x0, lsl #48
    16e0:      	str	x17, [x16, #0x10]
    16e4:      	mov	x0, x23
    16e8:      	bl	0x16e8 <_stogir.pipeline.prepare-checked+0xe18>
		00000000000016e8:  ARM64_RELOC_BRANCH26	_stogir.schedule.release!
    16ec:      	add	x16, sp, #0x910
    16f0:      	mov	w17, #0x1               ; =1
    16f4:      	str	w17, [x16]
    16f8:      	add	x16, sp, #0x910
    16fc:      	str	x21, [x16, #0x8]
    1700:      	str	x26, [x20, #0x8]
    1704:      	b	0x148c <_stogir.pipeline.prepare-checked+0xbbc>
    1708:      	sub	x0, x0, #0x1
    170c:      	add	x16, sp, #0x5b0
    1710:      	str	x0, [x16, #0x8]
    1714:      	add	x16, sp, #0x5b0
    1718:      	ldr	x0, [x16, #0x8]
    171c:      	cmp	x0, #0x0
    1720:      	b.ne	0x1708 <_stogir.pipeline.prepare-checked+0xe38>
    1724:      	add	x16, sp, #0x5b0
    1728:      	ldr	x0, [x16, #0x10]
    172c:      	cmp	x0, #0x0
    1730:      	b.le	0x1764 <_stogir.pipeline.prepare-checked+0xe94>
    1734:      	add	x1, x20, #0x18
    1738:      	add	x16, sp, #0x5b0
    173c:      	ldr	x2, [x16]
    1740:      	fmov	d31, x0
    1744:      	mov	x0, x1
    1748:      	mov	x1, x2
    174c:      	fmov	x2, d31
    1750:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001750:  ARM64_RELOC_PAGE21	l_stogir.397
    1754:      	ldr	x3, [x3]
		0000000000001754:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    1758:      	mov	x4, #0x4                ; =4
    175c:      	mov	x5, #0x4                ; =4
    1760:      	bl	0x1760 <_stogir.pipeline.prepare-checked+0xe90>
		0000000000001760:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1764:      	add	x16, sp, #0x5b0
    1768:      	movz	x17, #0x0, lsl #48
    176c:      	str	x17, [x16]
    1770:      	add	x16, sp, #0x5b0
    1774:      	movz	x17, #0x0, lsl #48
    1778:      	str	x17, [x16, #0x8]
    177c:      	add	x16, sp, #0x5b0
    1780:      	movz	x17, #0x0, lsl #48
    1784:      	str	x17, [x16, #0x10]
    1788:      	ldr	x0, [sp, #0xe78]
    178c:      	bl	0x178c <_stogir.pipeline.prepare-checked+0xebc>
		000000000000178c:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    1790:      	b	0x1664 <_stogir.pipeline.prepare-checked+0xd94>
    1794:      	nop
    1798:      	sub	x0, x0, #0x1
    179c:      	add	x16, sp, #0x550
    17a0:      	str	x0, [x16, #0x8]
    17a4:      	add	x16, sp, #0x550
    17a8:      	ldr	x0, [x16, #0x8]
    17ac:      	cmp	x0, #0x0
    17b0:      	b.ne	0x1798 <_stogir.pipeline.prepare-checked+0xec8>
    17b4:      	add	x16, sp, #0x550
    17b8:      	ldr	x0, [x16, #0x10]
    17bc:      	cmp	x0, #0x0
    17c0:      	b.le	0x17f4 <_stogir.pipeline.prepare-checked+0xf24>
    17c4:      	add	x1, x19, #0x18
    17c8:      	add	x16, sp, #0x550
    17cc:      	ldr	x2, [x16]
    17d0:      	fmov	d31, x0
    17d4:      	mov	x0, x1
    17d8:      	mov	x1, x2
    17dc:      	fmov	x2, d31
    17e0:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		00000000000017e0:  ARM64_RELOC_PAGE21	l_stogir.397
    17e4:      	ldr	x3, [x3]
		00000000000017e4:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    17e8:      	mov	x4, #0x4                ; =4
    17ec:      	mov	x5, #0x4                ; =4
    17f0:      	bl	0x17f0 <_stogir.pipeline.prepare-checked+0xf20>
		00000000000017f0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    17f4:      	add	x16, sp, #0x550
    17f8:      	movz	x17, #0x0, lsl #48
    17fc:      	str	x17, [x16]
    1800:      	add	x16, sp, #0x550
    1804:      	movz	x17, #0x0, lsl #48
    1808:      	str	x17, [x16, #0x8]
    180c:      	add	x16, sp, #0x550
    1810:      	movz	x17, #0x0, lsl #48
    1814:      	str	x17, [x16, #0x10]
    1818:      	b	0x1714 <_stogir.pipeline.prepare-checked+0xe44>
    181c:      	b	0x17a4 <_stogir.pipeline.prepare-checked+0xed4>
    1820:      	adrp	x21, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001820:  ARM64_RELOC_PAGE21	l_stogir.398
    1824:      	ldr	x21, [x21]
		0000000000001824:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    1828:      	movz	x26, #0x0, lsl #48
    182c:      	cmp	x26, #0x0
    1830:      	b.ne	0x1dbc <_stogir.pipeline.prepare-checked+0x14ec>
    1834:      	add	x8, sp, #0x7e0
    1838:      	ldr	x0, [sp, #0xe60]
    183c:      	mov	x2, x19
    1840:      	mov	x3, x20
    1844:      	mov	x4, x22
    1848:      	ldr	x5, [sp, #0xe50]
    184c:      	mov	x6, x24
    1850:      	str	x24, [sp, #0xe80]
    1854:      	mov	x24, x1
    1858:      	bl	0x1858 <_stogir.pipeline.prepare-checked+0xf88>
		0000000000001858:  ARM64_RELOC_BRANCH26	_stogir.placement.late-with-uses!
    185c:      	add	x16, sp, #0x7e0
    1860:      	ldr	w0, [x16]
    1864:      	lsr	x16, x0, #0
    1868:      	cmp	x16, #0x1
    186c:      	b.eq	0x1888 <_stogir.pipeline.prepare-checked+0xfb8>
    1870:      	b.lo	0x1878 <_stogir.pipeline.prepare-checked+0xfa8>
    1874:      	b	0x188c <_stogir.pipeline.prepare-checked+0xfbc>
    1878:      	cmp	x16, #0x0
    187c:      	b.eq	0x1884 <_stogir.pipeline.prepare-checked+0xfb4>
    1880:      	b	0x188c <_stogir.pipeline.prepare-checked+0xfbc>
    1884:      	b	0x18a8 <_stogir.pipeline.prepare-checked+0xfd8>
    1888:      	b	0x1890 <_stogir.pipeline.prepare-checked+0xfc0>
    188c:      	b	0x1d8c <_stogir.pipeline.prepare-checked+0x14bc>
    1890:      	add	x16, sp, #0x7e0
    1894:      	orr	x0, x16, xzr
    1898:      	add	x0, x0, #0x8
    189c:      	add	x16, sp, #0x7e0
    18a0:      	ldr	x21, [x16, #0x8]
    18a4:      	ldr	x26, [x0, #0x8]
    18a8:      	cmp	x26, #0x0
    18ac:      	b.ne	0x1910 <_stogir.pipeline.prepare-checked+0x1040>
    18b0:      	add	x8, sp, #0x800
    18b4:      	ldr	x0, [sp, #0xe60]
    18b8:      	mov	x1, x24
    18bc:      	mov	x2, x22
    18c0:      	bl	0x18c0 <_stogir.pipeline.prepare-checked+0xff0>
		00000000000018c0:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.place!
    18c4:      	add	x16, sp, #0x800
    18c8:      	ldr	w0, [x16]
    18cc:      	lsr	x16, x0, #0
    18d0:      	cmp	x16, #0x1
    18d4:      	b.eq	0x18f0 <_stogir.pipeline.prepare-checked+0x1020>
    18d8:      	b.lo	0x18e0 <_stogir.pipeline.prepare-checked+0x1010>
    18dc:      	b	0x18f4 <_stogir.pipeline.prepare-checked+0x1024>
    18e0:      	cmp	x16, #0x0
    18e4:      	b.eq	0x18ec <_stogir.pipeline.prepare-checked+0x101c>
    18e8:      	b	0x18f4 <_stogir.pipeline.prepare-checked+0x1024>
    18ec:      	b	0x1910 <_stogir.pipeline.prepare-checked+0x1040>
    18f0:      	b	0x18f8 <_stogir.pipeline.prepare-checked+0x1028>
    18f4:      	b	0x1d94 <_stogir.pipeline.prepare-checked+0x14c4>
    18f8:      	add	x16, sp, #0x800
    18fc:      	orr	x0, x16, xzr
    1900:      	add	x0, x0, #0x8
    1904:      	add	x16, sp, #0x800
    1908:      	ldr	x21, [x16, #0x8]
    190c:      	ldr	x26, [x0, #0x8]
    1910:      	cmp	x26, #0x0
    1914:      	b.ne	0x1984 <_stogir.pipeline.prepare-checked+0x10b4>
    1918:      	add	x8, sp, #0x820
    191c:      	ldr	x0, [sp, #0xe78]
    1920:      	mov	x1, x28
    1924:      	mov	x2, x19
    1928:      	mov	x3, x20
    192c:      	mov	x4, x25
    1930:      	ldr	x5, [sp, #0xe80]
    1934:      	bl	0x1934 <_stogir.pipeline.prepare-checked+0x1064>
		0000000000001934:  ARM64_RELOC_BRANCH26	_stogir.loops.reorder!
    1938:      	add	x16, sp, #0x820
    193c:      	ldr	w0, [x16]
    1940:      	lsr	x16, x0, #0
    1944:      	cmp	x16, #0x1
    1948:      	b.eq	0x1964 <_stogir.pipeline.prepare-checked+0x1094>
    194c:      	b.lo	0x1954 <_stogir.pipeline.prepare-checked+0x1084>
    1950:      	b	0x1968 <_stogir.pipeline.prepare-checked+0x1098>
    1954:      	cmp	x16, #0x0
    1958:      	b.eq	0x1960 <_stogir.pipeline.prepare-checked+0x1090>
    195c:      	b	0x1968 <_stogir.pipeline.prepare-checked+0x1098>
    1960:      	b	0x1984 <_stogir.pipeline.prepare-checked+0x10b4>
    1964:      	b	0x196c <_stogir.pipeline.prepare-checked+0x109c>
    1968:      	b	0x1d9c <_stogir.pipeline.prepare-checked+0x14cc>
    196c:      	add	x16, sp, #0x820
    1970:      	orr	x0, x16, xzr
    1974:      	add	x0, x0, #0x8
    1978:      	add	x16, sp, #0x820
    197c:      	ldr	x21, [x16, #0x8]
    1980:      	ldr	x26, [x0, #0x8]
    1984:      	cmp	x26, #0x0
    1988:      	b.ne	0x1dc8 <_stogir.pipeline.prepare-checked+0x14f8>
    198c:      	add	x16, sp, #0x840
    1990:      	orr	x0, x16, xzr
    1994:      	add	x8, sp, #0x840
    1998:      	mov	x1, x24
    199c:      	mov	x2, x22
    19a0:      	ldr	x3, [sp, #0xe50]
    19a4:      	ldr	x4, [sp, #0xe80]
    19a8:      	str	x28, [sp, #0xe88]
    19ac:      	mov	x28, x0
    19b0:      	ldr	x0, [sp, #0xe60]
    19b4:      	bl	0x19b4 <_stogir.pipeline.prepare-checked+0x10e4>
		00000000000019b4:  ARM64_RELOC_BRANCH26	_stogir.schedule.order-with-uses
    19b8:      	add	x16, sp, #0x840
    19bc:      	ldr	w0, [x16]
    19c0:      	lsr	x16, x0, #0
    19c4:      	cmp	x16, #0x1
    19c8:      	b.eq	0x19e4 <_stogir.pipeline.prepare-checked+0x1114>
    19cc:      	b.lo	0x19d4 <_stogir.pipeline.prepare-checked+0x1104>
    19d0:      	b	0x19e8 <_stogir.pipeline.prepare-checked+0x1118>
    19d4:      	cmp	x16, #0x0
    19d8:      	b.eq	0x19e0 <_stogir.pipeline.prepare-checked+0x1110>
    19dc:      	b	0x19e8 <_stogir.pipeline.prepare-checked+0x1118>
    19e0:      	b	0x1a8c <_stogir.pipeline.prepare-checked+0x11bc>
    19e4:      	b	0x19ec <_stogir.pipeline.prepare-checked+0x111c>
    19e8:      	b	0x1da4 <_stogir.pipeline.prepare-checked+0x14d4>
    19ec:      	add	x0, x28, #0x8
    19f0:      	add	x16, sp, #0x840
    19f4:      	ldr	x21, [x16, #0x8]
    19f8:      	ldr	x26, [x0, #0x8]
    19fc:      	b	0x1a0c <_stogir.pipeline.prepare-checked+0x113c>
    1a00:      	sub	x0, x0, #0x1
    1a04:      	add	x16, sp, #0x790
    1a08:      	str	x0, [x16, #0x8]
    1a0c:      	add	x16, sp, #0x790
    1a10:      	ldr	x0, [x16, #0x8]
    1a14:      	cmp	x0, #0x0
    1a18:      	b.ne	0x1a00 <_stogir.pipeline.prepare-checked+0x1130>
    1a1c:      	add	x16, sp, #0x790
    1a20:      	ldr	x0, [x16, #0x10]
    1a24:      	cmp	x0, #0x0
    1a28:      	b.le	0x1a5c <_stogir.pipeline.prepare-checked+0x118c>
    1a2c:      	add	x1, x24, #0x18
    1a30:      	add	x16, sp, #0x790
    1a34:      	ldr	x2, [x16]
    1a38:      	fmov	d31, x0
    1a3c:      	mov	x0, x1
    1a40:      	mov	x1, x2
    1a44:      	fmov	x2, d31
    1a48:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001a48:  ARM64_RELOC_PAGE21	l_stogir.397
    1a4c:      	ldr	x3, [x3]
		0000000000001a4c:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    1a50:      	mov	x4, #0x4                ; =4
    1a54:      	mov	x5, #0x4                ; =4
    1a58:      	bl	0x1a58 <_stogir.pipeline.prepare-checked+0x1188>
		0000000000001a58:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1a5c:      	add	x16, sp, #0x790
    1a60:      	movz	x17, #0x0, lsl #48
    1a64:      	str	x17, [x16]
    1a68:      	add	x16, sp, #0x790
    1a6c:      	movz	x17, #0x0, lsl #48
    1a70:      	str	x17, [x16, #0x8]
    1a74:      	add	x16, sp, #0x790
    1a78:      	movz	x17, #0x0, lsl #48
    1a7c:      	str	x17, [x16, #0x10]
    1a80:      	b	0x1020 <_stogir.pipeline.prepare-checked+0x750>
    1a84:      	brk	#0
    1a88:      	b	0x1a84 <_stogir.pipeline.prepare-checked+0x11b4>
    1a8c:      	add	x0, x28, #0x8
    1a90:      	add	x16, sp, #0x840
    1a94:      	ldr	x1, [x16, #0x8]
    1a98:      	ldr	x2, [x0, #0x8]
    1a9c:      	ldr	x3, [x0, #0x10]
    1aa0:      	ldr	x4, [x0, #0x18]
    1aa4:      	ldr	x0, [x0, #0x20]
    1aa8:      	add	x16, sp, #0x870
    1aac:      	str	x1, [x16]
    1ab0:      	add	x16, sp, #0x870
    1ab4:      	str	x2, [x16, #0x8]
    1ab8:      	add	x16, sp, #0x870
    1abc:      	str	x3, [x16, #0x10]
    1ac0:      	add	x16, sp, #0x870
    1ac4:      	str	x4, [x16, #0x18]
    1ac8:      	add	x16, sp, #0x870
    1acc:      	str	x0, [x16, #0x20]
    1ad0:      	b	0x1ae4 <_stogir.pipeline.prepare-checked+0x1214>
    1ad4:      	nop
    1ad8:      	sub	x0, x0, #0x1
    1adc:      	add	x16, sp, #0x710
    1ae0:      	str	x0, [x16, #0x8]
    1ae4:      	add	x16, sp, #0x710
    1ae8:      	ldr	x0, [x16, #0x8]
    1aec:      	cmp	x0, #0x0
    1af0:      	b.ne	0x1ad8 <_stogir.pipeline.prepare-checked+0x1208>
    1af4:      	add	x16, sp, #0x710
    1af8:      	ldr	x0, [x16, #0x10]
    1afc:      	cmp	x0, #0x0
    1b00:      	b.le	0x1b34 <_stogir.pipeline.prepare-checked+0x1264>
    1b04:      	add	x1, x23, #0x18
    1b08:      	add	x16, sp, #0x710
    1b0c:      	ldr	x2, [x16]
    1b10:      	fmov	d31, x0
    1b14:      	mov	x0, x1
    1b18:      	mov	x1, x2
    1b1c:      	fmov	x2, d31
    1b20:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001b20:  ARM64_RELOC_PAGE21	l_stogir.399
    1b24:      	ldr	x3, [x3]
		0000000000001b24:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    1b28:      	mov	x4, #0x10               ; =16
    1b2c:      	mov	x5, #0x8                ; =8
    1b30:      	bl	0x1b30 <_stogir.pipeline.prepare-checked+0x1260>
		0000000000001b30:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1b34:      	add	x28, x23, #0x28
    1b38:      	add	x16, sp, #0x710
    1b3c:      	movz	x17, #0x0, lsl #48
    1b40:      	str	x17, [x16]
    1b44:      	add	x16, sp, #0x710
    1b48:      	movz	x17, #0x0, lsl #48
    1b4c:      	str	x17, [x16, #0x8]
    1b50:      	add	x16, sp, #0x710
    1b54:      	movz	x17, #0x0, lsl #48
    1b58:      	str	x17, [x16, #0x10]
    1b5c:      	b	0x1b68 <_stogir.pipeline.prepare-checked+0x1298>
    1b60:      	sub	x0, x0, #0x1
    1b64:      	str	x0, [x28, #0x8]
    1b68:      	ldr	x0, [x28, #0x8]
    1b6c:      	cmp	x0, #0x0
    1b70:      	b.ne	0x1b60 <_stogir.pipeline.prepare-checked+0x1290>
    1b74:      	ldr	x0, [x28, #0x10]
    1b78:      	cmp	x0, #0x0
    1b7c:      	b.le	0x1bb0 <_stogir.pipeline.prepare-checked+0x12e0>
    1b80:      	add	x1, x28, #0x18
    1b84:      	add	x16, sp, #0x710
    1b88:      	ldr	x2, [x16, #0x28]
    1b8c:      	fmov	d31, x0
    1b90:      	mov	x0, x1
    1b94:      	mov	x1, x2
    1b98:      	fmov	x2, d31
    1b9c:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001b9c:  ARM64_RELOC_PAGE21	l_stogir.397
    1ba0:      	ldr	x3, [x3]
		0000000000001ba0:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    1ba4:      	mov	x4, #0x4                ; =4
    1ba8:      	mov	x5, #0x4                ; =4
    1bac:      	bl	0x1bac <_stogir.pipeline.prepare-checked+0x12dc>
		0000000000001bac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1bb0:      	add	x16, sp, #0x870
    1bb4:      	orr	x0, x16, xzr
    1bb8:      	add	x16, sp, #0x710
    1bbc:      	movz	x17, #0x0, lsl #48
    1bc0:      	str	x17, [x16, #0x28]
    1bc4:      	movz	x17, #0x0, lsl #48
    1bc8:      	str	x17, [x28, #0x8]
    1bcc:      	movz	x17, #0x0, lsl #48
    1bd0:      	str	x17, [x28, #0x10]
    1bd4:      	add	x8, sp, #0x8a0
    1bd8:      	mov	x1, x24
    1bdc:      	mov	x2, x25
    1be0:      	ldr	x3, [sp, #0xe80]
    1be4:      	mov	x28, x0
    1be8:      	bl	0x1be8 <_stogir.pipeline.prepare-checked+0x1318>
		0000000000001be8:  ARM64_RELOC_BRANCH26	_stogir.schedule.pack
    1bec:      	add	x16, sp, #0x8a0
    1bf0:      	ldr	x0, [x16]
    1bf4:      	add	x16, sp, #0x710
    1bf8:      	str	x0, [x16]
    1bfc:      	add	x16, sp, #0x8a0
    1c00:      	ldr	x0, [x16, #0x8]
    1c04:      	add	x16, sp, #0x710
    1c08:      	str	x0, [x16, #0x8]
    1c0c:      	add	x16, sp, #0x8a0
    1c10:      	ldr	x0, [x16, #0x10]
    1c14:      	add	x16, sp, #0x710
    1c18:      	str	x0, [x16, #0x10]
    1c1c:      	add	x16, sp, #0x8a0
    1c20:      	ldr	x0, [x16, #0x18]
    1c24:      	add	x16, sp, #0x710
    1c28:      	str	x0, [x16, #0x18]
    1c2c:      	add	x16, sp, #0x8a0
    1c30:      	ldr	x0, [x16, #0x20]
    1c34:      	add	x16, sp, #0x710
    1c38:      	str	x0, [x16, #0x20]
    1c3c:      	add	x16, sp, #0x8a0
    1c40:      	ldr	x0, [x16, #0x28]
    1c44:      	add	x16, sp, #0x710
    1c48:      	str	x0, [x16, #0x28]
    1c4c:      	add	x16, sp, #0x8a0
    1c50:      	ldr	x0, [x16, #0x30]
    1c54:      	add	x16, sp, #0x710
    1c58:      	str	x0, [x16, #0x30]
    1c5c:      	add	x16, sp, #0x8a0
    1c60:      	ldr	x0, [x16, #0x38]
    1c64:      	add	x16, sp, #0x710
    1c68:      	str	x0, [x16, #0x38]
    1c6c:      	add	x16, sp, #0x8a0
    1c70:      	ldr	x0, [x16, #0x40]
    1c74:      	add	x16, sp, #0x710
    1c78:      	str	x0, [x16, #0x40]
    1c7c:      	add	x16, sp, #0x8a0
    1c80:      	ldr	x0, [x16, #0x48]
    1c84:      	add	x16, sp, #0x710
    1c88:      	str	x0, [x16, #0x48]
    1c8c:      	add	x8, sp, #0x8f0
    1c90:      	ldr	x0, [sp, #0xe60]
    1c94:      	mov	x1, x24
    1c98:      	mov	x2, x23
    1c9c:      	ldr	x3, [sp, #0xe80]
    1ca0:      	bl	0x1ca0 <_stogir.pipeline.prepare-checked+0x13d0>
		0000000000001ca0:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.cluster!
    1ca4:      	add	x16, sp, #0x8f0
    1ca8:      	ldr	w0, [x16]
    1cac:      	lsr	x16, x0, #0
    1cb0:      	cmp	x16, #0x1
    1cb4:      	b.eq	0x1cd0 <_stogir.pipeline.prepare-checked+0x1400>
    1cb8:      	b.lo	0x1cc0 <_stogir.pipeline.prepare-checked+0x13f0>
    1cbc:      	b	0x1cd4 <_stogir.pipeline.prepare-checked+0x1404>
    1cc0:      	cmp	x16, #0x0
    1cc4:      	b.eq	0x1ccc <_stogir.pipeline.prepare-checked+0x13fc>
    1cc8:      	b	0x1cd4 <_stogir.pipeline.prepare-checked+0x1404>
    1ccc:      	b	0x1cf0 <_stogir.pipeline.prepare-checked+0x1420>
    1cd0:      	b	0x1cd8 <_stogir.pipeline.prepare-checked+0x1408>
    1cd4:      	b	0x1dac <_stogir.pipeline.prepare-checked+0x14dc>
    1cd8:      	add	x16, sp, #0x8f0
    1cdc:      	orr	x0, x16, xzr
    1ce0:      	add	x0, x0, #0x8
    1ce4:      	add	x16, sp, #0x8f0
    1ce8:      	ldr	x21, [x16, #0x8]
    1cec:      	ldr	x26, [x0, #0x8]
    1cf0:      	b	0x1d04 <_stogir.pipeline.prepare-checked+0x1434>
    1cf4:      	nop
    1cf8:      	sub	x0, x0, #0x1
    1cfc:      	add	x16, sp, #0x870
    1d00:      	str	x0, [x16, #0x8]
    1d04:      	add	x16, sp, #0x870
    1d08:      	ldr	x0, [x16, #0x8]
    1d0c:      	cmp	x0, #0x0
    1d10:      	b.ne	0x1cf8 <_stogir.pipeline.prepare-checked+0x1428>
    1d14:      	add	x16, sp, #0x870
    1d18:      	ldr	x0, [x16, #0x10]
    1d1c:      	cmp	x0, #0x0
    1d20:      	b.le	0x1d54 <_stogir.pipeline.prepare-checked+0x1484>
    1d24:      	add	x1, x28, #0x18
    1d28:      	add	x16, sp, #0x870
    1d2c:      	ldr	x2, [x16]
    1d30:      	fmov	d31, x0
    1d34:      	mov	x0, x1
    1d38:      	mov	x1, x2
    1d3c:      	fmov	x2, d31
    1d40:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001d40:  ARM64_RELOC_PAGE21	l_stogir.397
    1d44:      	ldr	x3, [x3]
		0000000000001d44:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    1d48:      	mov	x4, #0x4                ; =4
    1d4c:      	mov	x5, #0x4                ; =4
    1d50:      	bl	0x1d50 <_stogir.pipeline.prepare-checked+0x1480>
		0000000000001d50:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1d54:      	add	x16, sp, #0x870
    1d58:      	movz	x17, #0x0, lsl #48
    1d5c:      	str	x17, [x16]
    1d60:      	add	x16, sp, #0x870
    1d64:      	movz	x17, #0x0, lsl #48
    1d68:      	str	x17, [x16, #0x8]
    1d6c:      	add	x16, sp, #0x870
    1d70:      	movz	x17, #0x0, lsl #48
    1d74:      	str	x17, [x16, #0x10]
    1d78:      	b	0x19fc <_stogir.pipeline.prepare-checked+0x112c>
    1d7c:      	brk	#0
    1d80:      	b	0x1d7c <_stogir.pipeline.prepare-checked+0x14ac>
    1d84:      	brk	#0
    1d88:      	b	0x1d84 <_stogir.pipeline.prepare-checked+0x14b4>
    1d8c:      	brk	#0
    1d90:      	b	0x1d8c <_stogir.pipeline.prepare-checked+0x14bc>
    1d94:      	brk	#0
    1d98:      	b	0x1d94 <_stogir.pipeline.prepare-checked+0x14c4>
    1d9c:      	brk	#0
    1da0:      	b	0x1d9c <_stogir.pipeline.prepare-checked+0x14cc>
    1da4:      	brk	#0
    1da8:      	b	0x1da4 <_stogir.pipeline.prepare-checked+0x14d4>
    1dac:      	brk	#0
    1db0:      	b	0x1dac <_stogir.pipeline.prepare-checked+0x14dc>
    1db4:      	str	x19, [sp, #0xe58]
    1db8:      	b	0x918 <_stogir.pipeline.prepare-checked+0x48>
    1dbc:      	str	x24, [sp, #0xe80]
    1dc0:      	mov	x24, x1
    1dc4:      	b	0x18a8 <_stogir.pipeline.prepare-checked+0xfd8>
    1dc8:      	str	x28, [sp, #0xe88]
    1dcc:      	b	0x19fc <_stogir.pipeline.prepare-checked+0x112c>

0000000000001dd0 <_stogir.cfg.release!>:
    1dd0:      	sub	sp, sp, #0x30
    1dd4:      	str	x29, [sp]
    1dd8:      	str	x30, [sp, #0x8]
    1ddc:      	mov	x29, sp
    1de0:      	str	x19, [sp, #0x10]
    1de4:      	str	x20, [sp, #0x18]
    1de8:      	str	x21, [sp, #0x20]
    1dec:      	b	0x1df8 <_stogir.cfg.release!+0x28>
    1df0:      	sub	x1, x1, #0x1
    1df4:      	str	x1, [x0, #0x8]
    1df8:      	ldr	x1, [x0, #0x8]
    1dfc:      	cmp	x1, #0x0
    1e00:      	b.ne	0x1df0 <_stogir.cfg.release!+0x20>
    1e04:      	ldr	x1, [x0, #0x10]
    1e08:      	cmp	x1, #0x0
    1e0c:      	b.le	0x1f50 <_stogir.cfg.release!+0x180>
    1e10:      	add	x2, x0, #0x18
    1e14:      	ldr	x3, [x0]
    1e18:      	mov	x19, x0
    1e1c:      	mov	x0, x2
    1e20:      	mov	x2, x1
    1e24:      	mov	x1, x3
    1e28:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001e28:  ARM64_RELOC_PAGE21	l_stogir.400
    1e2c:      	ldr	x3, [x3]
		0000000000001e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    1e30:      	mov	x4, #0x4                ; =4
    1e34:      	mov	x5, #0x4                ; =4
    1e38:      	bl	0x1e38 <_stogir.cfg.release!+0x68>
		0000000000001e38:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1e3c:      	add	x20, x19, #0x28
    1e40:      	movz	x17, #0x0, lsl #48
    1e44:      	str	x17, [x19]
    1e48:      	movz	x17, #0x0, lsl #48
    1e4c:      	str	x17, [x19, #0x8]
    1e50:      	movz	x17, #0x0, lsl #48
    1e54:      	str	x17, [x19, #0x10]
    1e58:      	b	0x1e68 <_stogir.cfg.release!+0x98>
    1e5c:      	nop
    1e60:      	sub	x0, x0, #0x1
    1e64:      	str	x0, [x20, #0x8]
    1e68:      	ldr	x0, [x20, #0x8]
    1e6c:      	cmp	x0, #0x0
    1e70:      	b.ne	0x1e60 <_stogir.cfg.release!+0x90>
    1e74:      	ldr	x0, [x20, #0x10]
    1e78:      	cmp	x0, #0x0
    1e7c:      	b.le	0x1eac <_stogir.cfg.release!+0xdc>
    1e80:      	add	x1, x20, #0x18
    1e84:      	ldr	x2, [x19, #0x28]
    1e88:      	fmov	d31, x0
    1e8c:      	mov	x0, x1
    1e90:      	mov	x1, x2
    1e94:      	fmov	x2, d31
    1e98:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001e98:  ARM64_RELOC_PAGE21	l_stogir.400
    1e9c:      	ldr	x3, [x3]
		0000000000001e9c:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    1ea0:      	mov	x4, #0x4                ; =4
    1ea4:      	mov	x5, #0x4                ; =4
    1ea8:      	bl	0x1ea8 <_stogir.cfg.release!+0xd8>
		0000000000001ea8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1eac:      	add	x21, x19, #0x50
    1eb0:      	movz	x17, #0x0, lsl #48
    1eb4:      	str	x17, [x19, #0x28]
    1eb8:      	movz	x17, #0x0, lsl #48
    1ebc:      	str	x17, [x20, #0x8]
    1ec0:      	movz	x17, #0x0, lsl #48
    1ec4:      	str	x17, [x20, #0x10]
    1ec8:      	b	0x1ed8 <_stogir.cfg.release!+0x108>
    1ecc:      	nop
    1ed0:      	sub	x0, x0, #0x1
    1ed4:      	str	x0, [x21, #0x8]
    1ed8:      	ldr	x0, [x21, #0x8]
    1edc:      	cmp	x0, #0x0
    1ee0:      	b.ne	0x1ed0 <_stogir.cfg.release!+0x100>
    1ee4:      	ldr	x0, [x21, #0x10]
    1ee8:      	cmp	x0, #0x0
    1eec:      	b.le	0x1f1c <_stogir.cfg.release!+0x14c>
    1ef0:      	add	x1, x21, #0x18
    1ef4:      	ldr	x2, [x19, #0x50]
    1ef8:      	fmov	d31, x0
    1efc:      	mov	x0, x1
    1f00:      	mov	x1, x2
    1f04:      	fmov	x2, d31
    1f08:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001f08:  ARM64_RELOC_PAGE21	l_stogir.401
    1f0c:      	ldr	x3, [x3]
		0000000000001f0c:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    1f10:      	mov	x4, #0x10               ; =16
    1f14:      	mov	x5, #0x4                ; =4
    1f18:      	bl	0x1f18 <_stogir.cfg.release!+0x148>
		0000000000001f18:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1f1c:      	movz	x17, #0x0, lsl #48
    1f20:      	str	x17, [x19, #0x50]
    1f24:      	movz	x17, #0x0, lsl #48
    1f28:      	str	x17, [x21, #0x8]
    1f2c:      	movz	x17, #0x0, lsl #48
    1f30:      	str	x17, [x21, #0x10]
    1f34:      	ldr	x19, [sp, #0x10]
    1f38:      	ldr	x20, [sp, #0x18]
    1f3c:      	ldr	x21, [sp, #0x20]
    1f40:      	ldr	x29, [sp]
    1f44:      	ldr	x30, [sp, #0x8]
    1f48:      	add	sp, sp, #0x30
    1f4c:      	ret
    1f50:      	mov	x19, x0
    1f54:      	b	0x1e3c <_stogir.cfg.release!+0x6c>

0000000000001f58 <_inherent$coil.arraylist.ArrayList$free!__i32>:
    1f58:      	sub	sp, sp, #0x20
    1f5c:      	str	x29, [sp]
    1f60:      	str	x30, [sp, #0x8]
    1f64:      	mov	x29, sp
    1f68:      	str	x19, [sp, #0x10]
    1f6c:      	b	0x1f78 <_inherent$coil.arraylist.ArrayList$free!__i32+0x20>
    1f70:      	sub	x1, x1, #0x1
    1f74:      	str	x1, [x0, #0x8]
    1f78:      	ldr	x1, [x0, #0x8]
    1f7c:      	cmp	x1, #0x0
    1f80:      	b.ne	0x1f70 <_inherent$coil.arraylist.ArrayList$free!__i32+0x18>
    1f84:      	ldr	x1, [x0, #0x10]
    1f88:      	cmp	x1, #0x0
    1f8c:      	b.le	0x1fec <_inherent$coil.arraylist.ArrayList$free!__i32+0x94>
    1f90:      	add	x2, x0, #0x18
    1f94:      	ldr	x3, [x0]
    1f98:      	mov	x19, x0
    1f9c:      	mov	x0, x2
    1fa0:      	mov	x2, x1
    1fa4:      	mov	x1, x3
    1fa8:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x730>
		0000000000001fa8:  ARM64_RELOC_PAGE21	l_stogir.402
    1fac:      	ldr	x3, [x3]
		0000000000001fac:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    1fb0:      	mov	x4, #0x4                ; =4
    1fb4:      	mov	x5, #0x4                ; =4
    1fb8:      	bl	0x1fb8 <_inherent$coil.arraylist.ArrayList$free!__i32+0x60>
		0000000000001fb8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1fbc:      	movz	x17, #0x0, lsl #48
    1fc0:      	str	x17, [x19]
    1fc4:      	movz	x17, #0x0, lsl #48
    1fc8:      	str	x17, [x19, #0x8]
    1fcc:      	movz	x17, #0x0, lsl #48
    1fd0:      	str	x17, [x19, #0x10]
    1fd4:      	movz	x0, #0x0, lsl #48
    1fd8:      	ldr	x19, [sp, #0x10]
    1fdc:      	ldr	x29, [sp]
    1fe0:      	ldr	x30, [sp, #0x8]
    1fe4:      	add	sp, sp, #0x20
    1fe8:      	ret
    1fec:      	mov	x19, x0
    1ff0:      	b	0x1fbc <_inherent$coil.arraylist.ArrayList$free!__i32+0x64>
    1ff4:      	udf	#0x0

0000000000001ff8 <_stogir.schedule.release!>:
    1ff8:      	sub	sp, sp, #0x20
    1ffc:      	str	x29, [sp]
    2000:      	str	x30, [sp, #0x8]
    2004:      	mov	x29, sp
    2008:      	str	x19, [sp, #0x10]
    200c:      	str	x20, [sp, #0x18]
    2010:      	b	0x2020 <_stogir.schedule.release!+0x28>
    2014:      	nop
    2018:      	sub	x1, x1, #0x1
    201c:      	str	x1, [x0, #0x8]
    2020:      	ldr	x1, [x0, #0x8]
    2024:      	cmp	x1, #0x0
    2028:      	b.ne	0x2018 <_stogir.schedule.release!+0x20>
    202c:      	ldr	x1, [x0, #0x10]
    2030:      	cmp	x1, #0x0
    2034:      	b.le	0x2104 <_stogir.schedule.release!+0x10c>
    2038:      	add	x2, x0, #0x18
    203c:      	ldr	x3, [x0]
    2040:      	mov	x19, x0
    2044:      	mov	x0, x2
    2048:      	mov	x2, x1
    204c:      	mov	x1, x3
    2050:      	adrp	x3, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002050:  ARM64_RELOC_PAGE21	l_stogir.403
    2054:      	ldr	x3, [x3]
		0000000000002054:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    2058:      	mov	x4, #0x10               ; =16
    205c:      	mov	x5, #0x8                ; =8
    2060:      	bl	0x2060 <_stogir.schedule.release!+0x68>
		0000000000002060:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    2064:      	add	x20, x19, #0x28
    2068:      	movz	x17, #0x0, lsl #48
    206c:      	str	x17, [x19]
    2070:      	movz	x17, #0x0, lsl #48
    2074:      	str	x17, [x19, #0x8]
    2078:      	movz	x17, #0x0, lsl #48
    207c:      	str	x17, [x19, #0x10]
    2080:      	b	0x2090 <_stogir.schedule.release!+0x98>
    2084:      	nop
    2088:      	sub	x0, x0, #0x1
    208c:      	str	x0, [x20, #0x8]
    2090:      	ldr	x0, [x20, #0x8]
    2094:      	cmp	x0, #0x0
    2098:      	b.ne	0x2088 <_stogir.schedule.release!+0x90>
    209c:      	ldr	x0, [x20, #0x10]
    20a0:      	cmp	x0, #0x0
    20a4:      	b.le	0x20d4 <_stogir.schedule.release!+0xdc>
    20a8:      	add	x1, x20, #0x18
    20ac:      	ldr	x2, [x19, #0x28]
    20b0:      	fmov	d31, x0
    20b4:      	mov	x0, x1
    20b8:      	mov	x1, x2
    20bc:      	fmov	x2, d31
    20c0:      	adrp	x3, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000020c0:  ARM64_RELOC_PAGE21	l_stogir.404
    20c4:      	ldr	x3, [x3]
		00000000000020c4:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    20c8:      	mov	x4, #0x4                ; =4
    20cc:      	mov	x5, #0x4                ; =4
    20d0:      	bl	0x20d0 <_stogir.schedule.release!+0xd8>
		00000000000020d0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    20d4:      	movz	x17, #0x0, lsl #48
    20d8:      	str	x17, [x19, #0x28]
    20dc:      	movz	x17, #0x0, lsl #48
    20e0:      	str	x17, [x20, #0x8]
    20e4:      	movz	x17, #0x0, lsl #48
    20e8:      	str	x17, [x20, #0x10]
    20ec:      	ldr	x19, [sp, #0x10]
    20f0:      	ldr	x20, [sp, #0x18]
    20f4:      	ldr	x29, [sp]
    20f8:      	ldr	x30, [sp, #0x8]
    20fc:      	add	sp, sp, #0x20
    2100:      	ret
    2104:      	mov	x19, x0
    2108:      	b	0x2064 <_stogir.schedule.release!+0x6c>

000000000000210c <_stogir.verify.schedule-input>:
    210c:      	sub	sp, sp, #0x80
    2110:      	str	x29, [sp]
    2114:      	str	x30, [sp, #0x8]
    2118:      	mov	x29, sp
    211c:      	str	x19, [sp, #0x50]
    2120:      	str	x20, [sp, #0x58]
    2124:      	str	x21, [sp, #0x60]
    2128:      	str	x22, [sp, #0x68]
    212c:      	str	x23, [sp, #0x70]
    2130:      	mov	x19, x8
    2134:      	add	x8, sp, #0x10
    2138:      	mov	x20, x0
    213c:      	mov	w21, w1
    2140:      	mov	x22, x2
    2144:      	mov	x23, x3
    2148:      	bl	0x2148 <_stogir.verify.schedule-input+0x3c>
		0000000000002148:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    214c:      	add	x16, sp, #0x10
    2150:      	ldr	w0, [x16]
    2154:      	lsr	x16, x0, #0
    2158:      	cmp	x16, #0x1
    215c:      	b.eq	0x2178 <_stogir.verify.schedule-input+0x6c>
    2160:      	b.lo	0x2168 <_stogir.verify.schedule-input+0x5c>
    2164:      	b	0x217c <_stogir.verify.schedule-input+0x70>
    2168:      	cmp	x16, #0x0
    216c:      	b.eq	0x2174 <_stogir.verify.schedule-input+0x68>
    2170:      	b	0x217c <_stogir.verify.schedule-input+0x70>
    2174:      	b	0x21a0 <_stogir.verify.schedule-input+0x94>
    2178:      	b	0x2180 <_stogir.verify.schedule-input+0x74>
    217c:      	b	0x2200 <_stogir.verify.schedule-input+0xf4>
    2180:      	add	x16, sp, #0x10
    2184:      	orr	x0, x16, xzr
    2188:      	add	x0, x0, #0x8
    218c:      	add	x16, sp, #0x10
    2190:      	ldr	x1, [x16, #0x8]
    2194:      	ldr	x0, [x0, #0x8]
    2198:      	mov	x2, #0x1                ; =1
    219c:      	b	0x21d0 <_stogir.verify.schedule-input+0xc4>
    21a0:      	add	x8, sp, #0x30
    21a4:      	mov	x0, x20
    21a8:      	mov	w1, w21
    21ac:      	mov	x2, x22
    21b0:      	mov	x3, x23
    21b4:      	bl	0x21b4 <_stogir.verify.schedule-input+0xa8>
		00000000000021b4:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input-structured
    21b8:      	add	x16, sp, #0x30
    21bc:      	ldr	x2, [x16]
    21c0:      	add	x16, sp, #0x30
    21c4:      	ldr	x1, [x16, #0x8]
    21c8:      	add	x16, sp, #0x30
    21cc:      	ldr	x0, [x16, #0x10]
    21d0:      	str	x2, [x19]
    21d4:      	str	x1, [x19, #0x8]
    21d8:      	str	x0, [x19, #0x10]
    21dc:      	ldr	x19, [sp, #0x50]
    21e0:      	ldr	x20, [sp, #0x58]
    21e4:      	ldr	x21, [sp, #0x60]
    21e8:      	ldr	x22, [sp, #0x68]
    21ec:      	ldr	x23, [sp, #0x70]
    21f0:      	ldr	x29, [sp]
    21f4:      	ldr	x30, [sp, #0x8]
    21f8:      	add	sp, sp, #0x80
    21fc:      	ret
    2200:      	brk	#0
    2204:      	b	0x2200 <_stogir.verify.schedule-input+0xf4>

0000000000002208 <_stogir.graph.contains?>:
    2208:      	sxtw	x1, w1
    220c:      	cmp	x1, #0x0
    2210:      	b.le	0x2250 <_stogir.graph.contains?+0x48>
    2214:      	ldr	x2, [x0, #0x8]
    2218:      	cmp	x1, x2
    221c:      	b.ge	0x22ac <_stogir.graph.contains?+0xa4>
    2220:      	add	x2, x0, #0x78
    2224:      	ldr	x2, [x2, #0x8]
    2228:      	cmp	x1, x2
    222c:      	b.ge	0x22bc <_stogir.graph.contains?+0xb4>
    2230:      	ldr	x0, [x0, #0x78]
    2234:      	add	x0, x0, x1, lsl #2
    2238:      	ldr	w0, [x0]
    223c:      	sxtw	x0, w0
    2240:      	cmp	x0, #0x0
    2244:      	cset	w0, ge
    2248:      	ubfx	x0, x0, #0, #8
    224c:      	b	0x22c0 <_stogir.graph.contains?+0xb8>
    2250:      	cmp	x1, #0x0
    2254:      	b.ge	0x22b4 <_stogir.graph.contains?+0xac>
    2258:      	add	x2, x0, #0x28
    225c:      	add	x3, x0, #0x50
    2260:      	ldr	x2, [x2, #0x8]
    2264:      	ldr	x3, [x3, #0x8]
    2268:      	cmp	x2, x3
    226c:      	b.ne	0x22cc <_stogir.graph.contains?+0xc4>
    2270:      	movz	x16, #0x0, lsl #48
    2274:      	sub	x3, x16, x1
    2278:      	cmp	x3, x2
    227c:      	b.gt	0x22c4 <_stogir.graph.contains?+0xbc>
    2280:      	movz	x16, #0x0, lsl #48
    2284:      	sub	x1, x16, x1
    2288:      	sub	x1, x1, #0x1
    228c:      	ldr	x0, [x0, #0x50]
    2290:      	add	x0, x0, x1, lsl #2
    2294:      	ldr	w0, [x0]
    2298:      	sxtw	x0, w0
    229c:      	cmp	x0, #0x0
    22a0:      	cset	w0, gt
    22a4:      	ubfx	x0, x0, #0, #8
    22a8:      	b	0x22c8 <_stogir.graph.contains?+0xc0>
    22ac:      	movz	x0, #0x0, lsl #48
    22b0:      	b	0x22c0 <_stogir.graph.contains?+0xb8>
    22b4:      	movz	x0, #0x0, lsl #48
    22b8:      	b	0x22c8 <_stogir.graph.contains?+0xc0>
    22bc:      	movz	x0, #0x0, lsl #48
    22c0:      	b	0x22c8 <_stogir.graph.contains?+0xc0>
    22c4:      	movz	x0, #0x0, lsl #48
    22c8:      	ret
    22cc:      	movz	x0, #0x0, lsl #48
    22d0:      	b	0x22c8 <_stogir.graph.contains?+0xc0>
    22d4:      	udf	#0x0

00000000000022d8 <_stogir.cfg.build>:
    22d8:      	sub	sp, sp, #0x2e0
    22dc:      	str	x29, [sp, #0x10]
    22e0:      	str	x30, [sp, #0x18]
    22e4:      	add	x29, sp, #0x10
    22e8:      	str	x19, [sp, #0x288]
    22ec:      	str	x20, [sp, #0x290]
    22f0:      	str	x21, [sp, #0x298]
    22f4:      	str	x22, [sp, #0x2a0]
    22f8:      	str	x23, [sp, #0x2a8]
    22fc:      	str	x24, [sp, #0x2b0]
    2300:      	str	x25, [sp, #0x2b8]
    2304:      	str	x26, [sp, #0x2c0]
    2308:      	str	x27, [sp, #0x2c8]
    230c:      	str	x28, [sp, #0x2d0]
    2310:      	mov	x19, x8
    2314:      	add	x8, sp, #0x20
    2318:      	mov	x20, x0
    231c:      	mov	x21, x1
    2320:      	bl	0x2320 <_stogir.cfg.build+0x48>
		0000000000002320:  ARM64_RELOC_BRANCH26	_stogir.verify.control-sources
    2324:      	add	x16, sp, #0x20
    2328:      	ldr	w0, [x16]
    232c:      	lsr	x16, x0, #0
    2330:      	cmp	x16, #0x1
    2334:      	b.eq	0x2350 <_stogir.cfg.build+0x78>
    2338:      	b.lo	0x2340 <_stogir.cfg.build+0x68>
    233c:      	b	0x2354 <_stogir.cfg.build+0x7c>
    2340:      	cmp	x16, #0x0
    2344:      	b.eq	0x234c <_stogir.cfg.build+0x74>
    2348:      	b	0x2354 <_stogir.cfg.build+0x7c>
    234c:      	b	0x279c <_stogir.cfg.build+0x4c4>
    2350:      	b	0x2358 <_stogir.cfg.build+0x80>
    2354:      	b	0x2e20 <_stogir.cfg.build+0xb48>
    2358:      	add	x16, sp, #0x20
    235c:      	orr	x0, x16, xzr
    2360:      	add	x0, x0, #0x8
    2364:      	add	x16, sp, #0x20
    2368:      	ldr	x21, [x16, #0x8]
    236c:      	ldr	x22, [x0, #0x8]
    2370:      	str	x19, [sp, #0x250]
    2374:      	mov	x13, #0x1               ; =1
    2378:      	movz	x0, #0x0, lsl #48
    237c:      	movz	x1, #0x0, lsl #48
    2380:      	movz	x2, #0x0, lsl #48
    2384:      	movz	x3, #0x0, lsl #48
    2388:      	movz	x4, #0x0, lsl #48
    238c:      	movz	x5, #0x0, lsl #48
    2390:      	movz	x6, #0x0, lsl #48
    2394:      	movz	x7, #0x0, lsl #48
    2398:      	movz	x8, #0x0, lsl #48
    239c:      	movz	x9, #0x0, lsl #48
    23a0:      	movz	x10, #0x0, lsl #48
    23a4:      	movz	x11, #0x0, lsl #48
    23a8:      	movz	x12, #0x0, lsl #48
    23ac:      	b	0x2720 <_stogir.cfg.build+0x448>
    23b0:      	sub	w3, w2, #0x1
    23b4:      	lsl	w3, w3, #2
    23b8:      	ubfx	x3, x3, #0, #32
    23bc:      	lsr	x3, x4, x3
    23c0:      	and	w3, w3, #0xf
    23c4:      	b	0x247c <_stogir.cfg.build+0x1a4>
    23c8:      	lsl	x2, x2, #1
    23cc:      	str	x23, [sp, #0x258]
    23d0:      	mov	x23, x0
    23d4:      	mov	x0, x24
    23d8:      	str	w25, [sp, #0x280]
    23dc:      	mov	x25, x1
    23e0:      	mov	x1, x2
    23e4:      	bl	0x23e4 <_stogir.cfg.build+0x10c>
		00000000000023e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge
    23e8:      	add	x0, x25, #0x1
    23ec:      	add	x16, sp, #0x40
    23f0:      	ldr	x1, [x16, #0x50]
    23f4:      	add	x1, x1, x25, lsl #4
    23f8:      	str	x20, [x1]
    23fc:      	str	x23, [x1, #0x8]
    2400:      	str	x0, [x24, #0x8]
    2404:      	add	x0, x19, #0x1
    2408:      	sxtw	x19, w0
    240c:      	ldr	x20, [sp, #0x260]
    2410:      	ldr	x23, [sp, #0x258]
    2414:      	ldr	x0, [sp, #0x270]
    2418:      	ldr	w25, [sp, #0x280]
    241c:      	mov	x1, x19
    2420:      	ldr	x19, [sp, #0x278]
    2424:      	cmp	x22, #0x0
    2428:      	b.ne	0x243c <_stogir.cfg.build+0x164>
    242c:      	cmp	x1, x0
    2430:      	cset	w2, le
    2434:      	ubfx	x2, x2, #0, #8
    2438:      	b	0x2440 <_stogir.cfg.build+0x168>
    243c:      	movz	x2, #0x0, lsl #48
    2440:      	cmp	x2, #0x0
    2444:      	b.eq	0x2e28 <_stogir.cfg.build+0xb50>
    2448:      	orr	w2, w1, wzr
    244c:      	uxtb	w16, w27
    2450:      	cmp	w16, wzr
    2454:      	b.eq	0x2480 <_stogir.cfg.build+0x1a8>
    2458:      	sxtw	x3, w2
    245c:      	ldr	w4, [x28]
    2460:      	cmp	x3, #0x0
    2464:      	b.le	0x2478 <_stogir.cfg.build+0x1a0>
    2468:      	cmp	x3, #0x4
    246c:      	b.le	0x23b0 <_stogir.cfg.build+0xd8>
    2470:      	mov	w3, #0x4                ; =4
    2474:      	b	0x23b4 <_stogir.cfg.build+0xdc>
    2478:      	movz	w3, #0x0, lsl #16
    247c:      	b	0x2484 <_stogir.cfg.build+0x1ac>
    2480:      	movz	w3, #0x0, lsl #16
    2484:      	adrp	x16, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002484:  ARM64_RELOC_PAGE21	l_stogir.405
    2488:      	ldr	x16, [x16]
		0000000000002488:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    248c:      	ldr	w4, [x16]
    2490:      	ubfx	x3, x3, #0, #32
    2494:      	cmp	x3, x4
    2498:      	b.ne	0x2e38 <_stogir.cfg.build+0xb60>
    249c:      	str	x0, [sp, #0x270]
    24a0:      	mov	x0, x20
    24a4:      	str	x19, [sp, #0x278]
    24a8:      	mov	x19, x1
    24ac:      	mov	w1, w25
    24b0:      	str	x20, [sp, #0x260]
    24b4:      	mov	w20, w2
    24b8:      	bl	0x24b8 <_stogir.cfg.build+0x1e0>
		00000000000024b8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    24bc:      	ubfx	x0, x0, #0, #32
    24c0:      	lsr	x16, x0, #0
    24c4:      	cmp	x16, #0x1
    24c8:      	b.eq	0x24e4 <_stogir.cfg.build+0x20c>
    24cc:      	b.lo	0x24d4 <_stogir.cfg.build+0x1fc>
    24d0:      	b	0x24e8 <_stogir.cfg.build+0x210>
    24d4:      	cmp	x16, #0x0
    24d8:      	b.eq	0x24e0 <_stogir.cfg.build+0x208>
    24dc:      	b	0x24e8 <_stogir.cfg.build+0x210>
    24e0:      	b	0x24ec <_stogir.cfg.build+0x214>
    24e4:      	b	0x2504 <_stogir.cfg.build+0x22c>
    24e8:      	b	0x2e10 <_stogir.cfg.build+0xb38>
    24ec:      	str	x23, [sp, #0x258]
    24f0:      	str	w25, [sp, #0x280]
    24f4:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000024f4:  ARM64_RELOC_PAGE21	l_stogir.406
    24f8:      	ldr	x21, [x21]
		00000000000024f8:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    24fc:      	mov	x22, #0x19              ; =25
    2500:      	b	0x2404 <_stogir.cfg.build+0x12c>
    2504:      	add	x16, sp, #0x40
    2508:      	ldr	x0, [x16, #0x28]
    250c:      	sxtw	x2, w1
    2510:      	add	x0, x0, x2, lsl #2
    2514:      	ldr	w0, [x0]
    2518:      	sxtw	x2, w0
    251c:      	cmp	x2, #0x0
    2520:      	b.ne	0x2678 <_stogir.cfg.build+0x3a0>
    2524:      	str	x23, [sp, #0x258]
    2528:      	str	w25, [sp, #0x280]
    252c:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		000000000000252c:  ARM64_RELOC_PAGE21	l_stogir.407
    2530:      	ldr	x21, [x21]
		0000000000002530:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2534:      	mov	x22, #0x1e              ; =30
    2538:      	b	0x2404 <_stogir.cfg.build+0x12c>
    253c:      	ldr	x20, [sp, #0x260]
    2540:      	ldr	x23, [sp, #0x258]
    2544:      	ldr	x19, [sp, #0x278]
    2548:      	mov	x0, x19
    254c:      	bl	0x254c <_stogir.cfg.build+0x274>
		000000000000254c:  ARM64_RELOC_BRANCH26	_coil.core.Iterator$coil.slice.SliceIter$next__i32
    2550:      	ubfx	x0, x0, #0, #32
    2554:      	lsr	x16, x0, #0
    2558:      	cmp	x16, #0x1
    255c:      	b.eq	0x257c <_stogir.cfg.build+0x2a4>
    2560:      	b.lo	0x2568 <_stogir.cfg.build+0x290>
    2564:      	b	0x2580 <_stogir.cfg.build+0x2a8>
    2568:      	cmp	x16, #0x0
    256c:      	b.eq	0x2574 <_stogir.cfg.build+0x29c>
    2570:      	b	0x2580 <_stogir.cfg.build+0x2a8>
    2574:      	str	x23, [sp, #0x258]
    2578:      	b	0x25d0 <_stogir.cfg.build+0x2f8>
    257c:      	b	0x2584 <_stogir.cfg.build+0x2ac>
    2580:      	b	0x2e18 <_stogir.cfg.build+0xb40>
    2584:      	ldr	x0, [x20]
    2588:      	sxtw	x2, w1
    258c:      	orr	w25, w1, wzr
    2590:      	orr	w26, w1, wzr
    2594:      	add	x0, x0, x2, lsl #4
    2598:      	ldr	x0, [x0]
    259c:      	ldr	x1, [x20, #0x78]
    25a0:      	uxtb	w0, w0
    25a4:      	add	x1, x1, x2, lsl #2
    25a8:      	cmp	x0, #0x83
    25ac:      	cset	w27, lt
    25b0:      	adrp	x16, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000025b0:  ARM64_RELOC_PAGE21	l_stogir.408
    25b4:      	ldr	x16, [x16]
		00000000000025b4:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    25b8:      	add	x0, x16, x0, lsl #2
    25bc:      	ldr	w1, [x1]
    25c0:      	orr	x28, x0, xzr
    25c4:      	sxtw	x0, w1
    25c8:      	mov	x1, #0x1                ; =1
    25cc:      	b	0x2424 <_stogir.cfg.build+0x14c>
    25d0:      	ldr	x0, [sp, #0x268]
    25d4:      	bl	0x25d4 <_stogir.cfg.build+0x2fc>
		00000000000025d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    25d8:      	mov	x0, x21
    25dc:      	mov	x1, x22
    25e0:      	adrp	x2, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000025e0:  ARM64_RELOC_PAGE21	l_stogir.409
    25e4:      	ldr	x2, [x2]
		00000000000025e4:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    25e8:      	movz	x3, #0x0, lsl #48
    25ec:      	bl	0x25ec <_stogir.cfg.build+0x314>
		00000000000025ec:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    25f0:      	cmp	x0, #0x0
    25f4:      	b.eq	0x26e0 <_stogir.cfg.build+0x408>
    25f8:      	add	x16, sp, #0x40
    25fc:      	ldr	x21, [x16]
    2600:      	add	x16, sp, #0x40
    2604:      	ldr	x22, [x16, #0x8]
    2608:      	add	x16, sp, #0x40
    260c:      	ldr	x0, [x16, #0x10]
    2610:      	add	x16, sp, #0x40
    2614:      	ldr	x1, [x16, #0x18]
    2618:      	add	x16, sp, #0x40
    261c:      	ldr	x2, [x16, #0x20]
    2620:      	add	x16, sp, #0x40
    2624:      	ldr	x3, [x16, #0x28]
    2628:      	add	x16, sp, #0x40
    262c:      	ldr	x4, [x16, #0x30]
    2630:      	add	x16, sp, #0x40
    2634:      	ldr	x5, [x16, #0x38]
    2638:      	add	x16, sp, #0x40
    263c:      	ldr	x6, [x16, #0x40]
    2640:      	add	x16, sp, #0x40
    2644:      	ldr	x7, [x16, #0x48]
    2648:      	add	x16, sp, #0x40
    264c:      	ldr	x8, [x16, #0x50]
    2650:      	add	x16, sp, #0x40
    2654:      	ldr	x9, [x16, #0x58]
    2658:      	add	x16, sp, #0x40
    265c:      	ldr	x10, [x16, #0x60]
    2660:      	add	x16, sp, #0x40
    2664:      	ldr	x11, [x16, #0x68]
    2668:      	add	x16, sp, #0x40
    266c:      	ldr	x12, [x16, #0x70]
    2670:      	movz	x13, #0x0, lsl #48
    2674:      	b	0x2720 <_stogir.cfg.build+0x448>
    2678:      	add	x16, sp, #0x210
    267c:      	movz	x17, #0x0, lsl #48
    2680:      	str	x17, [x16]
    2684:      	add	x16, sp, #0x210
    2688:      	movz	x17, #0x0, lsl #48
    268c:      	str	x17, [x16, #0x8]
    2690:      	add	x16, sp, #0x210
    2694:      	str	w0, [x16]
    2698:      	add	x16, sp, #0x210
    269c:      	str	w26, [x16, #0x4]
    26a0:      	add	x16, sp, #0x210
    26a4:      	str	w1, [x16, #0x8]
    26a8:      	add	x16, sp, #0x210
    26ac:      	str	w20, [x16, #0xc]
    26b0:      	add	x16, sp, #0x210
    26b4:      	ldr	x20, [x16]
    26b8:      	add	x16, sp, #0x210
    26bc:      	ldr	x0, [x16, #0x8]
    26c0:      	ldr	x1, [x24, #0x8]
    26c4:      	ldr	x2, [x24, #0x10]
    26c8:      	cmp	x1, x2
    26cc:      	b.lt	0x2e54 <_stogir.cfg.build+0xb7c>
    26d0:      	cmp	x2, #0x0
    26d4:      	b.ne	0x23c8 <_stogir.cfg.build+0xf0>
    26d8:      	mov	x2, #0x2                ; =2
    26dc:      	b	0x23cc <_stogir.cfg.build+0xf4>
    26e0:      	ldr	x0, [sp, #0x258]
    26e4:      	bl	0x26e4 <_stogir.cfg.build+0x40c>
		00000000000026e4:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    26e8:      	mov	x13, #0x1               ; =1
    26ec:      	movz	x0, #0x0, lsl #48
    26f0:      	movz	x1, #0x0, lsl #48
    26f4:      	movz	x2, #0x0, lsl #48
    26f8:      	movz	x3, #0x0, lsl #48
    26fc:      	movz	x4, #0x0, lsl #48
    2700:      	movz	x5, #0x0, lsl #48
    2704:      	movz	x6, #0x0, lsl #48
    2708:      	movz	x7, #0x0, lsl #48
    270c:      	movz	x8, #0x0, lsl #48
    2710:      	movz	x9, #0x0, lsl #48
    2714:      	movz	x10, #0x0, lsl #48
    2718:      	movz	x11, #0x0, lsl #48
    271c:      	movz	x12, #0x0, lsl #48
    2720:      	ldr	x14, [sp, #0x250]
    2724:      	str	x13, [x14]
    2728:      	str	x21, [x14, #0x8]
    272c:      	str	x22, [x14, #0x10]
    2730:      	str	x0, [x14, #0x18]
    2734:      	str	x1, [x14, #0x20]
    2738:      	str	x2, [x14, #0x28]
    273c:      	str	x3, [x14, #0x30]
    2740:      	str	x4, [x14, #0x38]
    2744:      	str	x5, [x14, #0x40]
    2748:      	str	x6, [x14, #0x48]
    274c:      	str	x7, [x14, #0x50]
    2750:      	str	x8, [x14, #0x58]
    2754:      	str	x9, [x14, #0x60]
    2758:      	str	x10, [x14, #0x68]
    275c:      	str	x11, [x14, #0x70]
    2760:      	str	x12, [x14, #0x78]
    2764:      	ldr	x19, [sp, #0x288]
    2768:      	ldr	x20, [sp, #0x290]
    276c:      	ldr	x21, [sp, #0x298]
    2770:      	ldr	x22, [sp, #0x2a0]
    2774:      	ldr	x23, [sp, #0x2a8]
    2778:      	ldr	x24, [sp, #0x2b0]
    277c:      	ldr	x25, [sp, #0x2b8]
    2780:      	ldr	x26, [sp, #0x2c0]
    2784:      	ldr	x27, [sp, #0x2c8]
    2788:      	ldr	x28, [sp, #0x2d0]
    278c:      	ldr	x29, [sp, #0x10]
    2790:      	ldr	x30, [sp, #0x18]
    2794:      	add	sp, sp, #0x2e0
    2798:      	ret
    279c:      	add	x16, sp, #0x40
    27a0:      	orr	x23, x16, xzr
    27a4:      	add	x8, sp, #0xc0
    27a8:      	mov	x0, x21
    27ac:      	bl	0x27ac <_stogir.cfg.build+0x4d4>
		00000000000027ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    27b0:      	add	x22, x23, #0x28
    27b4:      	add	x16, sp, #0xc0
    27b8:      	ldr	x24, [x16]
    27bc:      	add	x16, sp, #0xc0
    27c0:      	ldr	x25, [x16, #0x8]
    27c4:      	add	x16, sp, #0xc0
    27c8:      	ldr	x26, [x16, #0x10]
    27cc:      	add	x16, sp, #0xc0
    27d0:      	ldr	x27, [x16, #0x18]
    27d4:      	add	x16, sp, #0xc0
    27d8:      	ldr	x28, [x16, #0x20]
    27dc:      	add	x8, sp, #0xf0
    27e0:      	mov	x0, x21
    27e4:      	bl	0x27e4 <_stogir.cfg.build+0x50c>
		00000000000027e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    27e8:      	add	x16, sp, #0xf0
    27ec:      	ldr	x0, [x16]
    27f0:      	add	x16, sp, #0xf0
    27f4:      	ldr	x1, [x16, #0x8]
    27f8:      	add	x16, sp, #0xf0
    27fc:      	ldr	x2, [x16, #0x10]
    2800:      	add	x16, sp, #0xf0
    2804:      	ldr	x3, [x16, #0x18]
    2808:      	add	x16, sp, #0xf0
    280c:      	ldr	x4, [x16, #0x20]
    2810:      	add	x8, sp, #0x120
    2814:      	str	x21, [sp, #0x240]
    2818:      	str	x22, [sp, #0x248]
    281c:      	mov	x22, x1
    2820:      	str	x19, [sp, #0x250]
    2824:      	mov	x19, x2
    2828:      	str	x23, [sp, #0x258]
    282c:      	mov	x23, x3
    2830:      	str	x20, [sp, #0x260]
    2834:      	mov	x20, x4
    2838:      	fmov	d31, x0
    283c:      	mov	x0, x21
    2840:      	fmov	x21, d31
    2844:      	bl	0x2844 <_stogir.cfg.build+0x56c>
		0000000000002844:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge
    2848:      	add	x16, sp, #0x120
    284c:      	ldr	x0, [x16]
    2850:      	add	x16, sp, #0x120
    2854:      	ldr	x1, [x16, #0x8]
    2858:      	add	x16, sp, #0x120
    285c:      	ldr	x2, [x16, #0x10]
    2860:      	add	x16, sp, #0x120
    2864:      	ldr	x3, [x16, #0x18]
    2868:      	add	x16, sp, #0x120
    286c:      	ldr	x4, [x16, #0x20]
    2870:      	add	x16, sp, #0x40
    2874:      	str	x24, [x16]
    2878:      	add	x16, sp, #0x40
    287c:      	str	x25, [x16, #0x8]
    2880:      	add	x16, sp, #0x40
    2884:      	str	x26, [x16, #0x10]
    2888:      	add	x16, sp, #0x40
    288c:      	str	x27, [x16, #0x18]
    2890:      	add	x16, sp, #0x40
    2894:      	str	x28, [x16, #0x20]
    2898:      	add	x16, sp, #0x40
    289c:      	str	x21, [x16, #0x28]
    28a0:      	add	x16, sp, #0x40
    28a4:      	str	x22, [x16, #0x30]
    28a8:      	add	x16, sp, #0x40
    28ac:      	str	x19, [x16, #0x38]
    28b0:      	add	x16, sp, #0x40
    28b4:      	str	x23, [x16, #0x40]
    28b8:      	add	x16, sp, #0x40
    28bc:      	str	x20, [x16, #0x48]
    28c0:      	add	x16, sp, #0x40
    28c4:      	str	x0, [x16, #0x50]
    28c8:      	add	x16, sp, #0x40
    28cc:      	str	x1, [x16, #0x58]
    28d0:      	add	x16, sp, #0x40
    28d4:      	str	x2, [x16, #0x60]
    28d8:      	add	x16, sp, #0x40
    28dc:      	str	x3, [x16, #0x68]
    28e0:      	add	x16, sp, #0x40
    28e4:      	str	x4, [x16, #0x70]
    28e8:      	add	x8, sp, #0x180
    28ec:      	ldr	x0, [sp, #0x240]
    28f0:      	bl	0x28f0 <_stogir.cfg.build+0x618>
		00000000000028f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    28f4:      	add	x16, sp, #0x180
    28f8:      	ldr	x0, [x16]
    28fc:      	add	x16, sp, #0x150
    2900:      	str	x0, [x16]
    2904:      	add	x16, sp, #0x180
    2908:      	ldr	x0, [x16, #0x8]
    290c:      	add	x16, sp, #0x150
    2910:      	str	x0, [x16, #0x8]
    2914:      	add	x16, sp, #0x180
    2918:      	ldr	x0, [x16, #0x10]
    291c:      	add	x16, sp, #0x150
    2920:      	str	x0, [x16, #0x10]
    2924:      	add	x16, sp, #0x180
    2928:      	ldr	x0, [x16, #0x18]
    292c:      	add	x16, sp, #0x150
    2930:      	str	x0, [x16, #0x18]
    2934:      	add	x16, sp, #0x180
    2938:      	ldr	x0, [x16, #0x20]
    293c:      	add	x16, sp, #0x150
    2940:      	str	x0, [x16, #0x20]
    2944:      	ldr	x0, [sp, #0x260]
    2948:      	bl	0x2948 <_stogir.cfg.build+0x670>
		0000000000002948:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    294c:      	mov	x1, x0
    2950:      	ldr	x0, [sp, #0x248]
    2954:      	bl	0x2954 <_stogir.cfg.build+0x67c>
		0000000000002954:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    2958:      	mov	x19, #0x1               ; =1
    295c:      	b	0x29a4 <_stogir.cfg.build+0x6cc>
    2960:      	orr	w0, w19, wzr
    2964:      	orr	w22, w0, wzr
    2968:      	ldr	x0, [sp, #0x258]
    296c:      	mov	w1, w22
    2970:      	bl	0x2970 <_stogir.cfg.build+0x698>
		0000000000002970:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    2974:      	add	x16, sp, #0x40
    2978:      	ldr	x0, [x16, #0x28]
    297c:      	add	x0, x0, x19, lsl #2
    2980:      	str	w22, [x0]
    2984:      	sxtw	x21, w21
    2988:      	add	x0, x21, #0x4
    298c:      	asr	x16, x0, #63
    2990:      	lsr	x16, x16, #62
    2994:      	add	x0, x0, x16
    2998:      	asr	x0, x0, #2
    299c:      	add	x19, x0, x19
    29a0:      	str	x20, [sp, #0x260]
    29a4:      	ldr	x20, [sp, #0x260]
    29a8:      	ldr	x0, [x20, #0x8]
    29ac:      	cmp	x19, x0
    29b0:      	b.ge	0x29e0 <_stogir.cfg.build+0x708>
    29b4:      	ldr	x0, [x20]
    29b8:      	add	x0, x0, x19, lsl #4
    29bc:      	ldr	x0, [x0]
    29c0:      	ldr	x1, [x20, #0x78]
    29c4:      	uxtb	w0, w0
    29c8:      	add	x1, x1, x19, lsl #2
    29cc:      	ldr	w21, [x1]
    29d0:      	bl	0x29d0 <_stogir.cfg.build+0x6f8>
		00000000000029d0:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-start?
    29d4:      	cmp	x0, #0x0
    29d8:      	b.ne	0x2960 <_stogir.cfg.build+0x688>
    29dc:      	b	0x2984 <_stogir.cfg.build+0x6ac>
    29e0:      	add	x16, sp, #0x150
    29e4:      	orr	x19, x16, xzr
    29e8:      	add	x23, x20, #0x78
    29ec:      	add	x24, x20, #0x78
    29f0:      	mov	x25, #0x1               ; =1
    29f4:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		00000000000029f4:  ARM64_RELOC_PAGE21	l_stogir.409
    29f8:      	ldr	x21, [x21]
		00000000000029f8:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    29fc:      	movz	x22, #0x0, lsl #48
    2a00:      	b	0x2aa4 <_stogir.cfg.build+0x7cc>
    2a04:      	movz	w1, #0x0, lsl #16
    2a08:      	movz	w0, #0x0, lsl #16
    2a0c:      	b	0x2c60 <_stogir.cfg.build+0x988>
    2a10:      	movz	w3, #0x0, lsl #16
    2a14:      	movz	w4, #0x0, lsl #16
    2a18:      	ubfx	x3, x3, #0, #32
    2a1c:      	lsr	x16, x3, #0
    2a20:      	cmp	x16, #0x1
    2a24:      	b.eq	0x2a40 <_stogir.cfg.build+0x768>
    2a28:      	b.lo	0x2a30 <_stogir.cfg.build+0x758>
    2a2c:      	b	0x2a44 <_stogir.cfg.build+0x76c>
    2a30:      	cmp	x16, #0x0
    2a34:      	b.eq	0x2a3c <_stogir.cfg.build+0x764>
    2a38:      	b	0x2a44 <_stogir.cfg.build+0x76c>
    2a3c:      	b	0x2a84 <_stogir.cfg.build+0x7ac>
    2a40:      	b	0x2a48 <_stogir.cfg.build+0x770>
    2a44:      	b	0x2e00 <_stogir.cfg.build+0xb28>
    2a48:      	sxtw	x4, w4
    2a4c:      	add	x16, sp, #0x40
    2a50:      	ldr	x3, [x16, #0x28]
    2a54:      	add	x3, x3, x4, lsl #2
    2a58:      	str	w28, [x3]
    2a5c:      	cmp	x2, x1
    2a60:      	b.ge	0x2a10 <_stogir.cfg.build+0x738>
    2a64:      	add	x3, x2, #0x1
    2a68:      	add	x2, x0, x2, lsl #2
    2a6c:      	ldr	w2, [x2]
    2a70:      	movn	w17, #0x0, lsl #16
    2a74:      	and	w4, w2, w17
    2a78:      	mov	x2, x3
    2a7c:      	mov	w3, #0x1                ; =1
    2a80:      	b	0x2a18 <_stogir.cfg.build+0x740>
    2a84:      	sxtw	x26, w26
    2a88:      	add	x0, x26, #0x4
    2a8c:      	asr	x16, x0, #63
    2a90:      	lsr	x16, x16, #62
    2a94:      	add	x0, x0, x16
    2a98:      	asr	x0, x0, #2
    2a9c:      	add	x25, x0, x25
    2aa0:      	ldr	x19, [sp, #0x268]
    2aa4:      	cmp	x22, #0x0
    2aa8:      	b.ne	0x2ac0 <_stogir.cfg.build+0x7e8>
    2aac:      	ldr	x0, [x20, #0x8]
    2ab0:      	cmp	x25, x0
    2ab4:      	cset	w0, lt
    2ab8:      	ubfx	x0, x0, #0, #8
    2abc:      	b	0x2ac4 <_stogir.cfg.build+0x7ec>
    2ac0:      	movz	x0, #0x0, lsl #48
    2ac4:      	cmp	x0, #0x0
    2ac8:      	b.eq	0x2e68 <_stogir.cfg.build+0xb90>
    2acc:      	ldr	x0, [x20]
    2ad0:      	add	x0, x0, x25, lsl #4
    2ad4:      	ldr	x0, [x0]
    2ad8:      	ldr	x1, [x20, #0x78]
    2adc:      	uxtb	w0, w0
    2ae0:      	add	x1, x1, x25, lsl #2
    2ae4:      	ldr	w26, [x1]
    2ae8:      	bl	0x2ae8 <_stogir.cfg.build+0x810>
		0000000000002ae8:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    2aec:      	cmp	x0, #0x0
    2af0:      	b.eq	0x2b18 <_stogir.cfg.build+0x840>
    2af4:      	add	x16, sp, #0x40
    2af8:      	ldr	x0, [x16, #0x28]
    2afc:      	add	x0, x0, x25, lsl #2
    2b00:      	ldr	w0, [x0]
    2b04:      	sxtw	x0, w0
    2b08:      	cmp	x0, #0x0
    2b0c:      	cset	w0, eq
    2b10:      	ubfx	x0, x0, #0, #8
    2b14:      	b	0x2b1c <_stogir.cfg.build+0x844>
    2b18:      	movz	x0, #0x0, lsl #48
    2b1c:      	cmp	x0, #0x0
    2b20:      	b.eq	0x2e70 <_stogir.cfg.build+0xb98>
    2b24:      	orr	w27, w25, wzr
    2b28:      	mov	x0, x19
    2b2c:      	bl	0x2b2c <_stogir.cfg.build+0x854>
		0000000000002b2c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$clear!__i32
    2b30:      	sxtw	x27, w27
    2b34:      	movz	x28, #0x0, lsl #48
    2b38:      	b	0x2ba0 <_stogir.cfg.build+0x8c8>
    2b3c:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002b3c:  ARM64_RELOC_PAGE21	l_stogir.410
    2b40:      	ldr	x21, [x21]
		0000000000002b40:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    2b44:      	mov	x22, #0x1b              ; =27
    2b48:      	b	0x2b9c <_stogir.cfg.build+0x8c4>
    2b4c:      	nop
    2b50:      	movz	x0, #0x0, lsl #48
    2b54:      	cmp	x0, #0x0
    2b58:      	b.eq	0x2e78 <_stogir.cfg.build+0xba0>
    2b5c:      	add	x16, sp, #0x40
    2b60:      	ldr	x0, [x16, #0x28]
    2b64:      	add	x0, x0, x27, lsl #2
    2b68:      	ldr	w0, [x0]
    2b6c:      	sxtw	x28, w0
    2b70:      	cmp	x28, #0x0
    2b74:      	b.ne	0x2e80 <_stogir.cfg.build+0xba8>
    2b78:      	add	x16, sp, #0x150
    2b7c:      	ldr	x0, [x16, #0x8]
    2b80:      	ldr	x1, [x20, #0x8]
    2b84:      	cmp	x0, x1
    2b88:      	b.lt	0x2bb8 <_stogir.cfg.build+0x8e0>
    2b8c:      	str	x19, [sp, #0x268]
    2b90:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002b90:  ARM64_RELOC_PAGE21	l_stogir.411
    2b94:      	ldr	x21, [x21]
		0000000000002b94:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    2b98:      	mov	x22, #0x27              ; =39
    2b9c:      	ldr	x19, [sp, #0x268]
    2ba0:      	cmp	x22, #0x0
    2ba4:      	b.ne	0x2b50 <_stogir.cfg.build+0x878>
    2ba8:      	cmp	x28, #0x0
    2bac:      	cset	w0, eq
    2bb0:      	ubfx	x0, x0, #0, #8
    2bb4:      	b	0x2b54 <_stogir.cfg.build+0x87c>
    2bb8:      	add	x16, sp, #0x150
    2bbc:      	ldr	x1, [x16, #0x10]
    2bc0:      	cmp	x0, x1
    2bc4:      	b.lt	0x2e88 <_stogir.cfg.build+0xbb0>
    2bc8:      	cmp	x1, #0x0
    2bcc:      	b.ne	0x2bd8 <_stogir.cfg.build+0x900>
    2bd0:      	mov	x1, #0x2                ; =2
    2bd4:      	b	0x2bdc <_stogir.cfg.build+0x904>
    2bd8:      	lsl	x1, x1, #1
    2bdc:      	str	x19, [sp, #0x268]
    2be0:      	fmov	d31, x0
    2be4:      	mov	x0, x19
    2be8:      	fmov	x19, d31
    2bec:      	bl	0x2bec <_stogir.cfg.build+0x914>
		0000000000002bec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    2bf0:      	orr	w0, w27, wzr
    2bf4:      	add	x1, x19, #0x1
    2bf8:      	sxtw	x2, w0
    2bfc:      	add	x16, sp, #0x150
    2c00:      	ldr	x3, [x16]
    2c04:      	add	x3, x3, x19, lsl #2
    2c08:      	str	w0, [x3]
    2c0c:      	add	x16, sp, #0x150
    2c10:      	str	x1, [x16, #0x8]
    2c14:      	cmp	x2, #0x0
    2c18:      	b.le	0x2c58 <_stogir.cfg.build+0x980>
    2c1c:      	lsl	x0, x2, #2
    2c20:      	ldr	x1, [x20, #0x8]
    2c24:      	cmp	x2, x1
    2c28:      	b.ge	0x2d34 <_stogir.cfg.build+0xa5c>
    2c2c:      	ldr	x1, [x24, #0x8]
    2c30:      	cmp	x2, x1
    2c34:      	b.ge	0x2d2c <_stogir.cfg.build+0xa54>
    2c38:      	ldr	x1, [x20, #0x78]
    2c3c:      	add	x1, x0, x1
    2c40:      	ldr	w1, [x1]
    2c44:      	sxtw	x1, w1
    2c48:      	cmp	x1, #0x0
    2c4c:      	cset	w1, ge
    2c50:      	ubfx	x1, x1, #0, #8
    2c54:      	b	0x2d30 <_stogir.cfg.build+0xa58>
    2c58:      	movz	w1, #0x0, lsl #16
    2c5c:      	movz	w0, #0x0, lsl #16
    2c60:      	ubfx	x1, x1, #0, #32
    2c64:      	lsr	x16, x1, #0
    2c68:      	cmp	x16, #0x1
    2c6c:      	b.eq	0x2c88 <_stogir.cfg.build+0x9b0>
    2c70:      	b.lo	0x2c78 <_stogir.cfg.build+0x9a0>
    2c74:      	b	0x2c8c <_stogir.cfg.build+0x9b4>
    2c78:      	cmp	x16, #0x0
    2c7c:      	b.eq	0x2c84 <_stogir.cfg.build+0x9ac>
    2c80:      	b	0x2c8c <_stogir.cfg.build+0x9b4>
    2c84:      	b	0x2c90 <_stogir.cfg.build+0x9b8>
    2c88:      	b	0x2ce8 <_stogir.cfg.build+0xa10>
    2c8c:      	b	0x2e08 <_stogir.cfg.build+0xb30>
    2c90:      	adrp	x21, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002c90:  ARM64_RELOC_PAGE21	l_stogir.412
    2c94:      	ldr	x21, [x21]
		0000000000002c94:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    2c98:      	mov	x22, #0x1e              ; =30
    2c9c:      	b	0x2b48 <_stogir.cfg.build+0x870>
    2ca0:      	mov	x0, x21
    2ca4:      	mov	x1, x22
    2ca8:      	adrp	x2, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002ca8:  ARM64_RELOC_PAGE21	l_stogir.409
    2cac:      	ldr	x2, [x2]
		0000000000002cac:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    2cb0:      	movz	x3, #0x0, lsl #48
    2cb4:      	bl	0x2cb4 <_stogir.cfg.build+0x9dc>
		0000000000002cb4:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2cb8:      	cmp	x0, #0x0
    2cbc:      	b.eq	0x2a84 <_stogir.cfg.build+0x7ac>
    2cc0:      	add	x8, sp, #0x1b0
    2cc4:      	ldr	x0, [sp, #0x268]
    2cc8:      	bl	0x2cc8 <_stogir.cfg.build+0x9f0>
		0000000000002cc8:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2ccc:      	add	x16, sp, #0x1b0
    2cd0:      	ldr	x0, [x16]
    2cd4:      	add	x16, sp, #0x1b0
    2cd8:      	ldr	x1, [x16, #0x8]
    2cdc:      	add	x16, sp, #0x1b0
    2ce0:      	ldr	x2, [x16, #0x10]
    2ce4:      	b	0x2a5c <_stogir.cfg.build+0x784>
    2ce8:      	sxtw	x0, w0
    2cec:      	cmp	x0, #0x0
    2cf0:      	b.le	0x2b3c <_stogir.cfg.build+0x864>
    2cf4:      	ldr	x1, [x20, #0x8]
    2cf8:      	cmp	x0, x1
    2cfc:      	b.ge	0x2de4 <_stogir.cfg.build+0xb0c>
    2d00:      	ldr	x1, [x23, #0x8]
    2d04:      	cmp	x0, x1
    2d08:      	b.ge	0x2df8 <_stogir.cfg.build+0xb20>
    2d0c:      	ldr	x1, [x20, #0x78]
    2d10:      	add	x1, x1, x0, lsl #2
    2d14:      	ldr	w1, [x1]
    2d18:      	sxtw	x1, w1
    2d1c:      	cmp	x1, #0x0
    2d20:      	cset	w1, ge
    2d24:      	ubfx	x1, x1, #0, #8
    2d28:      	b	0x2dfc <_stogir.cfg.build+0xb24>
    2d2c:      	movz	x1, #0x0, lsl #48
    2d30:      	b	0x2d38 <_stogir.cfg.build+0xa60>
    2d34:      	movz	x1, #0x0, lsl #48
    2d38:      	cmp	x1, #0x0
    2d3c:      	b.eq	0x2c58 <_stogir.cfg.build+0x980>
    2d40:      	ldr	x1, [x20, #0x78]
    2d44:      	add	x0, x0, x1
    2d48:      	ldr	w0, [x0]
    2d4c:      	sxtw	x0, w0
    2d50:      	cmp	x0, #0x1
    2d54:      	b.lt	0x2a04 <_stogir.cfg.build+0x72c>
    2d58:      	ldr	x0, [x20]
    2d5c:      	add	x0, x0, x2, lsl #4
    2d60:      	ldr	w0, [x0, #0x4]
    2d64:      	movn	w17, #0x0, lsl #16
    2d68:      	and	w0, w0, w17
    2d6c:      	mov	w1, #0x1                ; =1
    2d70:      	b	0x2a0c <_stogir.cfg.build+0x734>
    2d74:      	mov	x0, x21
    2d78:      	mov	x1, x22
    2d7c:      	adrp	x2, 0x2000 <_stogir.schedule.release!+0x8>
		0000000000002d7c:  ARM64_RELOC_PAGE21	l_stogir.409
    2d80:      	ldr	x2, [x2]
		0000000000002d80:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    2d84:      	movz	x3, #0x0, lsl #48
    2d88:      	bl	0x2d88 <_stogir.cfg.build+0xab0>
		0000000000002d88:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2d8c:      	cmp	x0, #0x0
    2d90:      	b.eq	0x25d0 <_stogir.cfg.build+0x2f8>
    2d94:      	add	x16, sp, #0x1d0
    2d98:      	orr	x19, x16, xzr
    2d9c:      	ldr	x23, [sp, #0x258]
    2da0:      	add	x24, x23, #0x50
    2da4:      	add	x8, sp, #0x1f0
    2da8:      	mov	x0, x23
    2dac:      	bl	0x2dac <_stogir.cfg.build+0xad4>
		0000000000002dac:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2db0:      	add	x16, sp, #0x1f0
    2db4:      	ldr	x0, [x16]
    2db8:      	add	x16, sp, #0x1d0
    2dbc:      	str	x0, [x16]
    2dc0:      	add	x16, sp, #0x1f0
    2dc4:      	ldr	x0, [x16, #0x8]
    2dc8:      	add	x16, sp, #0x1d0
    2dcc:      	str	x0, [x16, #0x8]
    2dd0:      	add	x16, sp, #0x1f0
    2dd4:      	ldr	x0, [x16, #0x10]
    2dd8:      	add	x16, sp, #0x1d0
    2ddc:      	str	x0, [x16, #0x10]
    2de0:      	b	0x2548 <_stogir.cfg.build+0x270>
    2de4:      	movz	x1, #0x0, lsl #48
    2de8:      	cmp	x1, #0x0
    2dec:      	b.eq	0x2b3c <_stogir.cfg.build+0x864>
    2df0:      	mov	x27, x0
    2df4:      	b	0x2b48 <_stogir.cfg.build+0x870>
    2df8:      	movz	x1, #0x0, lsl #48
    2dfc:      	b	0x2de8 <_stogir.cfg.build+0xb10>
    2e00:      	brk	#0
    2e04:      	b	0x2e00 <_stogir.cfg.build+0xb28>
    2e08:      	brk	#0
    2e0c:      	b	0x2e08 <_stogir.cfg.build+0xb30>
    2e10:      	brk	#0
    2e14:      	b	0x2e10 <_stogir.cfg.build+0xb38>
    2e18:      	brk	#0
    2e1c:      	b	0x2e18 <_stogir.cfg.build+0xb40>
    2e20:      	brk	#0
    2e24:      	b	0x2e20 <_stogir.cfg.build+0xb48>
    2e28:      	str	x20, [sp, #0x260]
    2e2c:      	str	x23, [sp, #0x258]
    2e30:      	str	x19, [sp, #0x278]
    2e34:      	b	0x253c <_stogir.cfg.build+0x264>
    2e38:      	str	x20, [sp, #0x260]
    2e3c:      	str	x23, [sp, #0x258]
    2e40:      	str	x19, [sp, #0x278]
    2e44:      	mov	x19, x1
    2e48:      	str	x0, [sp, #0x270]
    2e4c:      	str	w25, [sp, #0x280]
    2e50:      	b	0x2404 <_stogir.cfg.build+0x12c>
    2e54:      	str	x23, [sp, #0x258]
    2e58:      	str	w25, [sp, #0x280]
    2e5c:      	mov	x23, x0
    2e60:      	mov	x25, x1
    2e64:      	b	0x23e8 <_stogir.cfg.build+0x110>
    2e68:      	str	x19, [sp, #0x268]
    2e6c:      	b	0x2d74 <_stogir.cfg.build+0xa9c>
    2e70:      	str	x19, [sp, #0x268]
    2e74:      	b	0x2a84 <_stogir.cfg.build+0x7ac>
    2e78:      	str	x19, [sp, #0x268]
    2e7c:      	b	0x2ca0 <_stogir.cfg.build+0x9c8>
    2e80:      	str	x19, [sp, #0x268]
    2e84:      	b	0x2b9c <_stogir.cfg.build+0x8c4>
    2e88:      	str	x19, [sp, #0x268]
    2e8c:      	mov	x19, x0
    2e90:      	b	0x2bf0 <_stogir.cfg.build+0x918>
    2e94:      	udf	#0x0

0000000000002e98 <_stogir.adjacency.build>:
    2e98:      	sub	sp, sp, #0x70
    2e9c:      	str	x29, [sp]
    2ea0:      	str	x30, [sp, #0x8]
    2ea4:      	mov	x29, sp
    2ea8:      	str	x19, [sp, #0x18]
    2eac:      	str	x20, [sp, #0x20]
    2eb0:      	str	x21, [sp, #0x28]
    2eb4:      	str	x22, [sp, #0x30]
    2eb8:      	str	x23, [sp, #0x38]
    2ebc:      	str	x24, [sp, #0x40]
    2ec0:      	str	x25, [sp, #0x48]
    2ec4:      	str	x26, [sp, #0x50]
    2ec8:      	str	x27, [sp, #0x58]
    2ecc:      	str	x28, [sp, #0x60]
    2ed0:      	add	x3, x0, #0x28
    2ed4:      	ldr	x3, [x3, #0x8]
    2ed8:      	orr	x19, x3, xzr
    2edc:      	mov	x20, sp
    2ee0:      	sub	sp, sp, #0x50
    2ee4:      	mov	x21, sp
    2ee8:      	sub	sp, sp, #0x30
    2eec:      	mov	x22, sp
    2ef0:      	ldr	x3, [x2]
    2ef4:      	ldr	x4, [x2, #0x8]
    2ef8:      	movz	x17, #0x0, lsl #48
    2efc:      	str	x17, [x21]
    2f00:      	movz	x17, #0x0, lsl #48
    2f04:      	str	x17, [x21, #0x8]
    2f08:      	movz	x17, #0x0, lsl #48
    2f0c:      	str	x17, [x21, #0x10]
    2f10:      	str	x3, [x21, #0x18]
    2f14:      	str	x4, [x21, #0x20]
    2f18:      	movz	x17, #0x0, lsl #48
    2f1c:      	str	x17, [x21, #0x28]
    2f20:      	movz	x17, #0x0, lsl #48
    2f24:      	str	x17, [x21, #0x30]
    2f28:      	movz	x17, #0x0, lsl #48
    2f2c:      	str	x17, [x21, #0x38]
    2f30:      	str	x3, [x21, #0x40]
    2f34:      	str	x4, [x21, #0x48]
    2f38:      	ldr	x3, [x2]
    2f3c:      	ldr	x2, [x2, #0x8]
    2f40:      	movz	x17, #0x0, lsl #48
    2f44:      	str	x17, [x22]
    2f48:      	movz	x17, #0x0, lsl #48
    2f4c:      	str	x17, [x22, #0x8]
    2f50:      	movz	x17, #0x0, lsl #48
    2f54:      	str	x17, [x22, #0x10]
    2f58:      	str	x3, [x22, #0x18]
    2f5c:      	str	x2, [x22, #0x20]
    2f60:      	cmp	x19, #0x0
    2f64:      	b.le	0x3310 <_stogir.adjacency.build+0x478>
    2f68:      	cmp	x19, #0x0
    2f6c:      	b.ge	0x2f78 <_stogir.adjacency.build+0xe0>
    2f70:      	movz	x2, #0x0, lsl #48
    2f74:      	b	0x2f7c <_stogir.adjacency.build+0xe4>
    2f78:      	mov	x2, x19
    2f7c:      	mov	x23, x8
    2f80:      	mov	x24, x0
    2f84:      	mov	x0, x21
    2f88:      	mov	w25, w1
    2f8c:      	mov	x1, x2
    2f90:      	bl	0x2f90 <_stogir.adjacency.build+0xf8>
		0000000000002f90:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range
    2f94:      	lsl	x0, x19, #4
    2f98:      	ldr	x1, [x21]
    2f9c:      	mov	x2, x0
    2fa0:      	mov	x0, x1
    2fa4:      	movz	x1, #0x0, lsl #48
    2fa8:      	bl	0x2fa8 <_stogir.adjacency.build+0x110>
		0000000000002fa8:  ARM64_RELOC_BRANCH26	_memset
    2fac:      	str	x19, [x21, #0x8]
    2fb0:      	ldr	x0, [x22, #0x8]
    2fb4:      	orr	x26, x0, xzr
    2fb8:      	ldr	x0, [x22, #0x10]
    2fbc:      	add	x27, x26, x19
    2fc0:      	cmp	x27, x0
    2fc4:      	b.le	0x2ff8 <_stogir.adjacency.build+0x160>
    2fc8:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2fcc:      	cmp	x0, x17
    2fd0:      	b.gt	0x2fdc <_stogir.adjacency.build+0x144>
    2fd4:      	lsl	x0, x0, #1
    2fd8:      	b	0x2fe0 <_stogir.adjacency.build+0x148>
    2fdc:      	mov	x0, x27
    2fe0:      	cmp	x0, x27
    2fe4:      	b.gt	0x2fec <_stogir.adjacency.build+0x154>
    2fe8:      	mov	x0, x27
    2fec:      	mov	x1, x0
    2ff0:      	mov	x0, x22
    2ff4:      	bl	0x2ff4 <_stogir.adjacency.build+0x15c>
		0000000000002ff4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    2ff8:      	add	x28, x24, #0x50
    2ffc:      	ubfx	x25, x25, #0, #8
    3000:      	lsl	x0, x19, #3
    3004:      	cmp	x25, #0x0
    3008:      	cset	w19, ne
    300c:      	ldr	x1, [x22]
    3010:      	add	x1, x1, x26, lsl #3
    3014:      	mov	x2, x0
    3018:      	mov	x0, x1
    301c:      	movz	x1, #0x0, lsl #48
    3020:      	bl	0x3020 <_stogir.adjacency.build+0x188>
		0000000000003020:  ARM64_RELOC_BRANCH26	_memset
    3024:      	str	x27, [x22, #0x8]
    3028:      	ldr	x0, [x24, #0x50]
    302c:      	ldr	x1, [x28, #0x8]
    3030:      	movz	x2, #0x0, lsl #48
    3034:      	b	0x3060 <_stogir.adjacency.build+0x1c8>
    3038:      	sxtw	x3, w4
    303c:      	ldr	x4, [x21]
    3040:      	orr	x5, x4, xzr
    3044:      	add	x5, x5, x3, lsl #4
    3048:      	add	x3, x4, x3, lsl #4
    304c:      	ldr	x4, [x5]
    3050:      	ldr	x5, [x5, #0x8]
    3054:      	add	x5, x5, #0x1
    3058:      	str	x4, [x3]
    305c:      	str	x5, [x3, #0x8]
    3060:      	cmp	x2, x1
    3064:      	b.ge	0x3080 <_stogir.adjacency.build+0x1e8>
    3068:      	add	x3, x2, #0x1
    306c:      	add	x2, x0, x2, lsl #4
    3070:      	ldr	x4, [x2]
    3074:      	mov	x2, x3
    3078:      	mov	w3, #0x1                ; =1
    307c:      	b	0x3088 <_stogir.adjacency.build+0x1f0>
    3080:      	movz	w3, #0x0, lsl #16
    3084:      	movz	x4, #0x0, lsl #48
    3088:      	ubfx	x3, x3, #0, #32
    308c:      	lsr	x16, x3, #0
    3090:      	cmp	x16, #0x1
    3094:      	b.eq	0x30b0 <_stogir.adjacency.build+0x218>
    3098:      	b.lo	0x30a0 <_stogir.adjacency.build+0x208>
    309c:      	b	0x30b4 <_stogir.adjacency.build+0x21c>
    30a0:      	cmp	x16, #0x0
    30a4:      	b.eq	0x30ac <_stogir.adjacency.build+0x214>
    30a8:      	b	0x30b4 <_stogir.adjacency.build+0x21c>
    30ac:      	b	0x30cc <_stogir.adjacency.build+0x234>
    30b0:      	b	0x30b8 <_stogir.adjacency.build+0x220>
    30b4:      	b	0x3308 <_stogir.adjacency.build+0x470>
    30b8:      	uxtb	w16, w19
    30bc:      	cmp	w16, wzr
    30c0:      	b.eq	0x3038 <_stogir.adjacency.build+0x1a0>
    30c4:      	asr	x3, x4, #32
    30c8:      	b	0x303c <_stogir.adjacency.build+0x1a4>
    30cc:      	movz	x0, #0x0, lsl #48
    30d0:      	movz	x1, #0x0, lsl #48
    30d4:      	b	0x3110 <_stogir.adjacency.build+0x278>
    30d8:      	add	x2, x0, #0x1
    30dc:      	ldr	x3, [x21]
    30e0:      	orr	x4, x3, xzr
    30e4:      	add	x4, x4, x0, lsl #4
    30e8:      	add	x3, x3, x0, lsl #4
    30ec:      	ldr	x4, [x4, #0x8]
    30f0:      	add	x5, x4, x1
    30f4:      	str	x1, [x3]
    30f8:      	str	x4, [x3, #0x8]
    30fc:      	ldr	x3, [x22]
    3100:      	add	x0, x3, x0, lsl #3
    3104:      	str	x1, [x0]
    3108:      	mov	x0, x2
    310c:      	mov	x1, x5
    3110:      	ldr	x2, [x21, #0x8]
    3114:      	cmp	x0, x2
    3118:      	b.lt	0x30d8 <_stogir.adjacency.build+0x240>
    311c:      	add	x19, x21, #0x28
    3120:      	ldr	x0, [x28, #0x8]
    3124:      	orr	x26, x0, xzr
    3128:      	ldr	x0, [x19, #0x8]
    312c:      	orr	x27, x0, xzr
    3130:      	ldr	x0, [x19, #0x10]
    3134:      	add	x1, x27, x26
    3138:      	cmp	x1, x0
    313c:      	b.le	0x3320 <_stogir.adjacency.build+0x488>
    3140:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    3144:      	cmp	x0, x17
    3148:      	b.gt	0x3154 <_stogir.adjacency.build+0x2bc>
    314c:      	lsl	x0, x0, #1
    3150:      	b	0x3158 <_stogir.adjacency.build+0x2c0>
    3154:      	mov	x0, x1
    3158:      	cmp	x0, x1
    315c:      	b.gt	0x3164 <_stogir.adjacency.build+0x2cc>
    3160:      	mov	x0, x1
    3164:      	str	x23, [x29, #0x10]
    3168:      	mov	x23, x1
    316c:      	mov	x1, x0
    3170:      	mov	x0, x19
    3174:      	bl	0x3174 <_stogir.adjacency.build+0x2dc>
		0000000000003174:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    3178:      	cmp	x25, #0x0
    317c:      	cset	w25, ne
    3180:      	lsl	x0, x26, #3
    3184:      	ldr	x1, [x21, #0x28]
    3188:      	add	x1, x1, x27, lsl #3
    318c:      	mov	x2, x0
    3190:      	mov	x0, x1
    3194:      	movz	x1, #0x0, lsl #48
    3198:      	bl	0x3198 <_stogir.adjacency.build+0x300>
		0000000000003198:  ARM64_RELOC_BRANCH26	_memset
    319c:      	str	x23, [x19, #0x8]
    31a0:      	movz	x0, #0x0, lsl #48
    31a4:      	b	0x31dc <_stogir.adjacency.build+0x344>
    31a8:      	sxtw	x1, w1
    31ac:      	add	x2, x0, #0x1
    31b0:      	ldr	x3, [x22]
    31b4:      	add	x3, x3, x1, lsl #3
    31b8:      	ldr	x3, [x3]
    31bc:      	ldr	x4, [x21, #0x28]
    31c0:      	add	x5, x3, #0x1
    31c4:      	add	x3, x4, x3, lsl #3
    31c8:      	str	x0, [x3]
    31cc:      	ldr	x0, [x22]
    31d0:      	add	x0, x0, x1, lsl #3
    31d4:      	str	x5, [x0]
    31d8:      	mov	x0, x2
    31dc:      	ldr	x1, [x28, #0x8]
    31e0:      	cmp	x0, x1
    31e4:      	b.ge	0x3208 <_stogir.adjacency.build+0x370>
    31e8:      	ldr	x1, [x24, #0x50]
    31ec:      	add	x1, x1, x0, lsl #4
    31f0:      	ldr	x1, [x1]
    31f4:      	uxtb	w16, w25
    31f8:      	cmp	w16, wzr
    31fc:      	b.eq	0x31a8 <_stogir.adjacency.build+0x310>
    3200:      	asr	x1, x1, #32
    3204:      	b	0x31ac <_stogir.adjacency.build+0x314>
    3208:      	b	0x3218 <_stogir.adjacency.build+0x380>
    320c:      	nop
    3210:      	sub	x0, x0, #0x1
    3214:      	str	x0, [x22, #0x8]
    3218:      	ldr	x0, [x22, #0x8]
    321c:      	cmp	x0, #0x0
    3220:      	b.ne	0x3210 <_stogir.adjacency.build+0x378>
    3224:      	ldr	x0, [x22, #0x10]
    3228:      	cmp	x0, #0x0
    322c:      	b.le	0x325c <_stogir.adjacency.build+0x3c4>
    3230:      	add	x1, x22, #0x18
    3234:      	ldr	x2, [x22]
    3238:      	fmov	d31, x0
    323c:      	mov	x0, x1
    3240:      	mov	x1, x2
    3244:      	fmov	x2, d31
    3248:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003248:  ARM64_RELOC_PAGE21	l_stogir.413
    324c:      	ldr	x3, [x3]
		000000000000324c:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    3250:      	mov	x4, #0x8                ; =8
    3254:      	mov	x5, #0x8                ; =8
    3258:      	bl	0x3258 <_stogir.adjacency.build+0x3c0>
		0000000000003258:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    325c:      	movz	x17, #0x0, lsl #48
    3260:      	str	x17, [x22]
    3264:      	movz	x17, #0x0, lsl #48
    3268:      	str	x17, [x22, #0x8]
    326c:      	movz	x17, #0x0, lsl #48
    3270:      	str	x17, [x22, #0x10]
    3274:      	ldr	x0, [x21]
    3278:      	ldr	x1, [x21, #0x8]
    327c:      	ldr	x2, [x21, #0x10]
    3280:      	ldr	x3, [x21, #0x18]
    3284:      	ldr	x4, [x21, #0x20]
    3288:      	ldr	x5, [x21, #0x28]
    328c:      	ldr	x6, [x21, #0x30]
    3290:      	ldr	x7, [x21, #0x38]
    3294:      	ldr	x8, [x21, #0x40]
    3298:      	ldr	x9, [x21, #0x48]
    329c:      	mov	sp, x20
    32a0:      	ldr	x10, [x29, #0x10]
    32a4:      	str	x0, [x10]
    32a8:      	str	x1, [x10, #0x8]
    32ac:      	str	x2, [x10, #0x10]
    32b0:      	str	x3, [x10, #0x18]
    32b4:      	str	x4, [x10, #0x20]
    32b8:      	str	x5, [x10, #0x28]
    32bc:      	str	x6, [x10, #0x30]
    32c0:      	str	x7, [x10, #0x38]
    32c4:      	str	x8, [x10, #0x40]
    32c8:      	str	x9, [x10, #0x48]
    32cc:      	sub	sp, x29, #0x0
    32d0:      	ldr	x19, [sp, #0x18]
    32d4:      	ldr	x20, [sp, #0x20]
    32d8:      	ldr	x21, [sp, #0x28]
    32dc:      	ldr	x22, [sp, #0x30]
    32e0:      	ldr	x23, [sp, #0x38]
    32e4:      	ldr	x24, [sp, #0x40]
    32e8:      	ldr	x25, [sp, #0x48]
    32ec:      	ldr	x26, [sp, #0x50]
    32f0:      	ldr	x27, [sp, #0x58]
    32f4:      	ldr	x28, [sp, #0x60]
    32f8:      	ldr	x29, [sp]
    32fc:      	ldr	x30, [sp, #0x8]
    3300:      	add	sp, sp, #0x70
    3304:      	ret
    3308:      	brk	#0
    330c:      	b	0x3308 <_stogir.adjacency.build+0x470>
    3310:      	mov	x23, x8
    3314:      	mov	x24, x0
    3318:      	mov	w25, w1
    331c:      	b	0x2f94 <_stogir.adjacency.build+0xfc>
    3320:      	str	x23, [x29, #0x10]
    3324:      	mov	x23, x1
    3328:      	b	0x3178 <_stogir.adjacency.build+0x2e0>
    332c:      	udf	#0x0

0000000000003330 <_stogir.adjacency.reverse-postorder>:
    3330:      	sub	sp, sp, #0x140
    3334:      	str	x29, [sp]
    3338:      	str	x30, [sp, #0x8]
    333c:      	mov	x29, sp
    3340:      	str	x19, [sp, #0xf0]
    3344:      	str	x20, [sp, #0xf8]
    3348:      	str	x21, [sp, #0x100]
    334c:      	str	x22, [sp, #0x108]
    3350:      	str	x23, [sp, #0x110]
    3354:      	str	x24, [sp, #0x118]
    3358:      	str	x25, [sp, #0x120]
    335c:      	str	x26, [sp, #0x128]
    3360:      	str	x27, [sp, #0x130]
    3364:      	add	x4, x0, #0x28
    3368:      	add	x16, sp, #0x10
    336c:      	orr	x19, x16, xzr
    3370:      	ldr	x5, [x3]
    3374:      	ldr	x6, [x3, #0x8]
    3378:      	add	x16, sp, #0x10
    337c:      	movz	x17, #0x0, lsl #48
    3380:      	str	x17, [x16]
    3384:      	add	x16, sp, #0x10
    3388:      	movz	x17, #0x0, lsl #48
    338c:      	str	x17, [x16, #0x8]
    3390:      	add	x16, sp, #0x10
    3394:      	movz	x17, #0x0, lsl #48
    3398:      	str	x17, [x16, #0x10]
    339c:      	add	x16, sp, #0x10
    33a0:      	str	x5, [x16, #0x18]
    33a4:      	add	x16, sp, #0x10
    33a8:      	str	x6, [x16, #0x20]
    33ac:      	ldr	x5, [x3]
    33b0:      	ldr	x6, [x3, #0x8]
    33b4:      	add	x16, sp, #0x40
    33b8:      	movz	x17, #0x0, lsl #48
    33bc:      	str	x17, [x16]
    33c0:      	add	x16, sp, #0x40
    33c4:      	movz	x17, #0x0, lsl #48
    33c8:      	str	x17, [x16, #0x8]
    33cc:      	add	x16, sp, #0x40
    33d0:      	movz	x17, #0x0, lsl #48
    33d4:      	str	x17, [x16, #0x10]
    33d8:      	add	x16, sp, #0x40
    33dc:      	str	x5, [x16, #0x18]
    33e0:      	add	x16, sp, #0x40
    33e4:      	str	x6, [x16, #0x20]
    33e8:      	ldr	x5, [x3]
    33ec:      	ldr	x6, [x3, #0x8]
    33f0:      	add	x16, sp, #0x70
    33f4:      	movz	x17, #0x0, lsl #48
    33f8:      	str	x17, [x16]
    33fc:      	add	x16, sp, #0x70
    3400:      	movz	x17, #0x0, lsl #48
    3404:      	str	x17, [x16, #0x8]
    3408:      	add	x16, sp, #0x70
    340c:      	movz	x17, #0x0, lsl #48
    3410:      	str	x17, [x16, #0x10]
    3414:      	add	x16, sp, #0x70
    3418:      	str	x5, [x16, #0x18]
    341c:      	add	x16, sp, #0x70
    3420:      	str	x6, [x16, #0x20]
    3424:      	ldr	x5, [x3]
    3428:      	ldr	x3, [x3, #0x8]
    342c:      	add	x16, sp, #0xa0
    3430:      	movz	x17, #0x0, lsl #48
    3434:      	str	x17, [x16]
    3438:      	add	x16, sp, #0xa0
    343c:      	movz	x17, #0x0, lsl #48
    3440:      	str	x17, [x16, #0x8]
    3444:      	add	x16, sp, #0xa0
    3448:      	movz	x17, #0x0, lsl #48
    344c:      	str	x17, [x16, #0x10]
    3450:      	add	x16, sp, #0xa0
    3454:      	str	x5, [x16, #0x18]
    3458:      	add	x16, sp, #0xa0
    345c:      	str	x3, [x16, #0x20]
    3460:      	ldr	x3, [x4, #0x8]
    3464:      	orr	x20, x3, xzr
    3468:      	cmp	x20, #0x0
    346c:      	b.le	0x39b8 <_stogir.adjacency.reverse-postorder+0x688>
    3470:      	cmp	x20, #0x0
    3474:      	b.ge	0x3480 <_stogir.adjacency.reverse-postorder+0x150>
    3478:      	movz	x3, #0x0, lsl #48
    347c:      	b	0x3484 <_stogir.adjacency.reverse-postorder+0x154>
    3480:      	mov	x3, x20
    3484:      	mov	x21, x8
    3488:      	mov	x22, x0
    348c:      	mov	x0, x19
    3490:      	mov	x23, x1
    3494:      	mov	x1, x3
    3498:      	mov	w24, w2
    349c:      	bl	0x349c <_stogir.adjacency.reverse-postorder+0x16c>
		000000000000349c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    34a0:      	add	x16, sp, #0x40
    34a4:      	orr	x25, x16, xzr
    34a8:      	add	x16, sp, #0x10
    34ac:      	ldr	x0, [x16]
    34b0:      	mov	x2, x20
    34b4:      	movz	x1, #0x0, lsl #48
    34b8:      	bl	0x34b8 <_stogir.adjacency.reverse-postorder+0x188>
		00000000000034b8:  ARM64_RELOC_BRANCH26	_memset
    34bc:      	add	x16, sp, #0x10
    34c0:      	str	x20, [x16, #0x8]
    34c4:      	add	x16, sp, #0xd0
    34c8:      	movz	x17, #0x0, lsl #48
    34cc:      	str	x17, [x16]
    34d0:      	add	x16, sp, #0xd0
    34d4:      	movz	x17, #0x0, lsl #48
    34d8:      	str	x17, [x16, #0x8]
    34dc:      	add	x16, sp, #0xd0
    34e0:      	str	w24, [x16]
    34e4:      	add	x16, sp, #0xd0
    34e8:      	movz	x17, #0x0, lsl #48
    34ec:      	str	x17, [x16, #0x8]
    34f0:      	add	x16, sp, #0xd0
    34f4:      	ldr	x20, [x16]
    34f8:      	add	x16, sp, #0x40
    34fc:      	ldr	x0, [x16, #0x8]
    3500:      	orr	x26, x0, xzr
    3504:      	add	x16, sp, #0x40
    3508:      	ldr	x0, [x16, #0x10]
    350c:      	cmp	x26, x0
    3510:      	b.lt	0x3534 <_stogir.adjacency.reverse-postorder+0x204>
    3514:      	cmp	x0, #0x0
    3518:      	b.ne	0x3524 <_stogir.adjacency.reverse-postorder+0x1f4>
    351c:      	mov	x0, #0x2                ; =2
    3520:      	b	0x3528 <_stogir.adjacency.reverse-postorder+0x1f8>
    3524:      	lsl	x0, x0, #1
    3528:      	mov	x1, x0
    352c:      	mov	x0, x25
    3530:      	bl	0x3530 <_stogir.adjacency.reverse-postorder+0x200>
		0000000000003530:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    3534:      	sxtw	x24, w24
    3538:      	add	x16, sp, #0x70
    353c:      	orr	x27, x16, xzr
    3540:      	add	x0, x26, #0x1
    3544:      	add	x16, sp, #0x40
    3548:      	ldr	x1, [x16]
    354c:      	add	x1, x1, x26, lsl #4
    3550:      	str	x20, [x1]
    3554:      	movz	x17, #0x0, lsl #48
    3558:      	str	x17, [x1, #0x8]
    355c:      	add	x16, sp, #0x40
    3560:      	str	x0, [x16, #0x8]
    3564:      	add	x16, sp, #0x10
    3568:      	ldr	x0, [x16]
    356c:      	add	x0, x0, x24
    3570:      	mov	w17, #0x1               ; =1
    3574:      	strb	w17, [x0]
    3578:      	b	0x35fc <_stogir.adjacency.reverse-postorder+0x2cc>
    357c:      	lsl	x0, x0, #1
    3580:      	mov	x1, x0
    3584:      	mov	x0, x27
    3588:      	bl	0x3588 <_stogir.adjacency.reverse-postorder+0x258>
		0000000000003588:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    358c:      	add	x0, x24, #0x1
    3590:      	add	x16, sp, #0x70
    3594:      	ldr	x1, [x16]
    3598:      	add	x1, x1, x24, lsl #2
    359c:      	str	w20, [x1]
    35a0:      	add	x16, sp, #0x70
    35a4:      	str	x0, [x16, #0x8]
    35a8:      	add	x16, sp, #0x40
    35ac:      	ldr	x0, [x16, #0x8]
    35b0:      	cmp	x0, #0x0
    35b4:      	b.eq	0x35fc <_stogir.adjacency.reverse-postorder+0x2cc>
    35b8:      	sub	x0, x0, #0x1
    35bc:      	add	x16, sp, #0x40
    35c0:      	str	x0, [x16, #0x8]
    35c4:      	b	0x35fc <_stogir.adjacency.reverse-postorder+0x2cc>
    35c8:      	lsl	x0, x0, #1
    35cc:      	mov	x1, x0
    35d0:      	mov	x0, x25
    35d4:      	bl	0x35d4 <_stogir.adjacency.reverse-postorder+0x2a4>
		00000000000035d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    35d8:      	add	x0, x24, #0x1
    35dc:      	add	x16, sp, #0x40
    35e0:      	ldr	x1, [x16]
    35e4:      	add	x1, x1, x24, lsl #4
    35e8:      	str	x20, [x1]
    35ec:      	movz	x17, #0x0, lsl #48
    35f0:      	str	x17, [x1, #0x8]
    35f4:      	add	x16, sp, #0x40
    35f8:      	str	x0, [x16, #0x8]
    35fc:      	add	x16, sp, #0x40
    3600:      	ldr	x0, [x16, #0x8]
    3604:      	cmp	x0, #0x0
    3608:      	b.le	0x3728 <_stogir.adjacency.reverse-postorder+0x3f8>
    360c:      	add	x16, sp, #0x40
    3610:      	ldr	x1, [x16]
    3614:      	sub	x0, x0, #0x1
    3618:      	add	x2, x1, x0, lsl #4
    361c:      	ldr	x3, [x2]
    3620:      	orr	w20, w3, wzr
    3624:      	ldr	x2, [x2, #0x8]
    3628:      	sxtw	x4, w20
    362c:      	ldr	x5, [x23]
    3630:      	add	x4, x5, x4, lsl #4
    3634:      	ldr	x5, [x4]
    3638:      	ldr	x4, [x4, #0x8]
    363c:      	cmp	x2, x4
    3640:      	b.lt	0x3670 <_stogir.adjacency.reverse-postorder+0x340>
    3644:      	add	x16, sp, #0x70
    3648:      	ldr	x0, [x16, #0x8]
    364c:      	orr	x24, x0, xzr
    3650:      	add	x16, sp, #0x70
    3654:      	ldr	x0, [x16, #0x10]
    3658:      	cmp	x24, x0
    365c:      	b.lt	0x358c <_stogir.adjacency.reverse-postorder+0x25c>
    3660:      	cmp	x0, #0x0
    3664:      	b.ne	0x357c <_stogir.adjacency.reverse-postorder+0x24c>
    3668:      	mov	x0, #0x2                ; =2
    366c:      	b	0x3580 <_stogir.adjacency.reverse-postorder+0x250>
    3670:      	add	x4, x2, x5
    3674:      	add	x2, x2, #0x1
    3678:      	ldr	x5, [x23, #0x28]
    367c:      	add	x0, x1, x0, lsl #4
    3680:      	add	x1, x5, x4, lsl #3
    3684:      	ldr	x1, [x1]
    3688:      	ldr	x4, [x22, #0x50]
    368c:      	add	x1, x4, x1, lsl #4
    3690:      	ldr	x1, [x1]
    3694:      	str	x3, [x0]
    3698:      	lsr	x1, x1, #32
    369c:      	str	x2, [x0, #0x8]
    36a0:      	sxtw	x0, w1
    36a4:      	add	x16, sp, #0x10
    36a8:      	ldr	x2, [x16]
    36ac:      	add	x3, x2, x0
    36b0:      	ldrb	w3, [x3]
    36b4:      	cmp	x3, #0x0
    36b8:      	b.ne	0x35fc <_stogir.adjacency.reverse-postorder+0x2cc>
    36bc:      	add	x0, x2, x0
    36c0:      	mov	w17, #0x1               ; =1
    36c4:      	strb	w17, [x0]
    36c8:      	add	x16, sp, #0xe0
    36cc:      	movz	x17, #0x0, lsl #48
    36d0:      	str	x17, [x16]
    36d4:      	add	x16, sp, #0xe0
    36d8:      	movz	x17, #0x0, lsl #48
    36dc:      	str	x17, [x16, #0x8]
    36e0:      	add	x16, sp, #0xe0
    36e4:      	str	w1, [x16]
    36e8:      	add	x16, sp, #0xe0
    36ec:      	movz	x17, #0x0, lsl #48
    36f0:      	str	x17, [x16, #0x8]
    36f4:      	add	x16, sp, #0xe0
    36f8:      	ldr	x20, [x16]
    36fc:      	add	x16, sp, #0x40
    3700:      	ldr	x0, [x16, #0x8]
    3704:      	orr	x24, x0, xzr
    3708:      	add	x16, sp, #0x40
    370c:      	ldr	x0, [x16, #0x10]
    3710:      	cmp	x24, x0
    3714:      	b.lt	0x35d8 <_stogir.adjacency.reverse-postorder+0x2a8>
    3718:      	cmp	x0, #0x0
    371c:      	b.ne	0x35c8 <_stogir.adjacency.reverse-postorder+0x298>
    3720:      	mov	x0, #0x2                ; =2
    3724:      	b	0x35cc <_stogir.adjacency.reverse-postorder+0x29c>
    3728:      	add	x16, sp, #0xa0
    372c:      	orr	x20, x16, xzr
    3730:      	add	x16, sp, #0x70
    3734:      	ldr	x0, [x16, #0x8]
    3738:      	orr	x22, x0, xzr
    373c:      	b	0x376c <_stogir.adjacency.reverse-postorder+0x43c>
    3740:      	lsl	x0, x0, #1
    3744:      	mov	x1, x0
    3748:      	mov	x0, x20
    374c:      	bl	0x374c <_stogir.adjacency.reverse-postorder+0x41c>
		000000000000374c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3750:      	add	x0, x24, #0x1
    3754:      	add	x16, sp, #0xa0
    3758:      	ldr	x1, [x16]
    375c:      	add	x1, x1, x24, lsl #2
    3760:      	str	w23, [x1]
    3764:      	add	x16, sp, #0xa0
    3768:      	str	x0, [x16, #0x8]
    376c:      	cmp	x22, #0x0
    3770:      	b.le	0x37b4 <_stogir.adjacency.reverse-postorder+0x484>
    3774:      	sub	x22, x22, #0x1
    3778:      	add	x16, sp, #0x70
    377c:      	ldr	x0, [x16]
    3780:      	add	x0, x0, x22, lsl #2
    3784:      	ldr	w23, [x0]
    3788:      	add	x16, sp, #0xa0
    378c:      	ldr	x0, [x16, #0x8]
    3790:      	orr	x24, x0, xzr
    3794:      	add	x16, sp, #0xa0
    3798:      	ldr	x0, [x16, #0x10]
    379c:      	cmp	x24, x0
    37a0:      	b.lt	0x3750 <_stogir.adjacency.reverse-postorder+0x420>
    37a4:      	cmp	x0, #0x0
    37a8:      	b.ne	0x3740 <_stogir.adjacency.reverse-postorder+0x410>
    37ac:      	mov	x0, #0x2                ; =2
    37b0:      	b	0x3744 <_stogir.adjacency.reverse-postorder+0x414>
    37b4:      	b	0x37c4 <_stogir.adjacency.reverse-postorder+0x494>
    37b8:      	sub	x0, x0, #0x1
    37bc:      	add	x16, sp, #0x10
    37c0:      	str	x0, [x16, #0x8]
    37c4:      	add	x16, sp, #0x10
    37c8:      	ldr	x0, [x16, #0x8]
    37cc:      	cmp	x0, #0x0
    37d0:      	b.ne	0x37b8 <_stogir.adjacency.reverse-postorder+0x488>
    37d4:      	add	x16, sp, #0x10
    37d8:      	ldr	x0, [x16, #0x10]
    37dc:      	cmp	x0, #0x0
    37e0:      	b.le	0x3814 <_stogir.adjacency.reverse-postorder+0x4e4>
    37e4:      	add	x1, x19, #0x18
    37e8:      	add	x16, sp, #0x10
    37ec:      	ldr	x2, [x16]
    37f0:      	fmov	d31, x0
    37f4:      	mov	x0, x1
    37f8:      	mov	x1, x2
    37fc:      	fmov	x2, d31
    3800:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003800:  ARM64_RELOC_PAGE21	l_stogir.414
    3804:      	ldr	x3, [x3]
		0000000000003804:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    3808:      	mov	x4, #0x1                ; =1
    380c:      	mov	x5, #0x1                ; =1
    3810:      	bl	0x3810 <_stogir.adjacency.reverse-postorder+0x4e0>
		0000000000003810:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3814:      	add	x16, sp, #0x10
    3818:      	movz	x17, #0x0, lsl #48
    381c:      	str	x17, [x16]
    3820:      	add	x16, sp, #0x10
    3824:      	movz	x17, #0x0, lsl #48
    3828:      	str	x17, [x16, #0x8]
    382c:      	add	x16, sp, #0x10
    3830:      	movz	x17, #0x0, lsl #48
    3834:      	str	x17, [x16, #0x10]
    3838:      	b	0x384c <_stogir.adjacency.reverse-postorder+0x51c>
    383c:      	nop
    3840:      	sub	x0, x0, #0x1
    3844:      	add	x16, sp, #0x40
    3848:      	str	x0, [x16, #0x8]
    384c:      	add	x16, sp, #0x40
    3850:      	ldr	x0, [x16, #0x8]
    3854:      	cmp	x0, #0x0
    3858:      	b.ne	0x3840 <_stogir.adjacency.reverse-postorder+0x510>
    385c:      	add	x16, sp, #0x40
    3860:      	ldr	x0, [x16, #0x10]
    3864:      	cmp	x0, #0x0
    3868:      	b.le	0x389c <_stogir.adjacency.reverse-postorder+0x56c>
    386c:      	add	x1, x25, #0x18
    3870:      	add	x16, sp, #0x40
    3874:      	ldr	x2, [x16]
    3878:      	fmov	d31, x0
    387c:      	mov	x0, x1
    3880:      	mov	x1, x2
    3884:      	fmov	x2, d31
    3888:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003888:  ARM64_RELOC_PAGE21	l_stogir.415
    388c:      	ldr	x3, [x3]
		000000000000388c:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    3890:      	mov	x4, #0x10               ; =16
    3894:      	mov	x5, #0x8                ; =8
    3898:      	bl	0x3898 <_stogir.adjacency.reverse-postorder+0x568>
		0000000000003898:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    389c:      	add	x16, sp, #0x40
    38a0:      	movz	x17, #0x0, lsl #48
    38a4:      	str	x17, [x16]
    38a8:      	add	x16, sp, #0x40
    38ac:      	movz	x17, #0x0, lsl #48
    38b0:      	str	x17, [x16, #0x8]
    38b4:      	add	x16, sp, #0x40
    38b8:      	movz	x17, #0x0, lsl #48
    38bc:      	str	x17, [x16, #0x10]
    38c0:      	b	0x38d4 <_stogir.adjacency.reverse-postorder+0x5a4>
    38c4:      	nop
    38c8:      	sub	x0, x0, #0x1
    38cc:      	add	x16, sp, #0x70
    38d0:      	str	x0, [x16, #0x8]
    38d4:      	add	x16, sp, #0x70
    38d8:      	ldr	x0, [x16, #0x8]
    38dc:      	cmp	x0, #0x0
    38e0:      	b.ne	0x38c8 <_stogir.adjacency.reverse-postorder+0x598>
    38e4:      	add	x16, sp, #0x70
    38e8:      	ldr	x0, [x16, #0x10]
    38ec:      	cmp	x0, #0x0
    38f0:      	b.le	0x3924 <_stogir.adjacency.reverse-postorder+0x5f4>
    38f4:      	add	x1, x27, #0x18
    38f8:      	add	x16, sp, #0x70
    38fc:      	ldr	x2, [x16]
    3900:      	fmov	d31, x0
    3904:      	mov	x0, x1
    3908:      	mov	x1, x2
    390c:      	fmov	x2, d31
    3910:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003910:  ARM64_RELOC_PAGE21	l_stogir.416
    3914:      	ldr	x3, [x3]
		0000000000003914:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    3918:      	mov	x4, #0x4                ; =4
    391c:      	mov	x5, #0x4                ; =4
    3920:      	bl	0x3920 <_stogir.adjacency.reverse-postorder+0x5f0>
		0000000000003920:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3924:      	add	x16, sp, #0x70
    3928:      	movz	x17, #0x0, lsl #48
    392c:      	str	x17, [x16]
    3930:      	add	x16, sp, #0x70
    3934:      	movz	x17, #0x0, lsl #48
    3938:      	str	x17, [x16, #0x8]
    393c:      	add	x16, sp, #0x70
    3940:      	movz	x17, #0x0, lsl #48
    3944:      	str	x17, [x16, #0x10]
    3948:      	add	x16, sp, #0xa0
    394c:      	ldr	x0, [x16]
    3950:      	add	x16, sp, #0xa0
    3954:      	ldr	x1, [x16, #0x8]
    3958:      	add	x16, sp, #0xa0
    395c:      	ldr	x2, [x16, #0x10]
    3960:      	add	x16, sp, #0xa0
    3964:      	ldr	x3, [x16, #0x18]
    3968:      	add	x16, sp, #0xa0
    396c:      	ldr	x4, [x16, #0x20]
    3970:      	str	x0, [x21]
    3974:      	str	x1, [x21, #0x8]
    3978:      	str	x2, [x21, #0x10]
    397c:      	str	x3, [x21, #0x18]
    3980:      	str	x4, [x21, #0x20]
    3984:      	ldr	x19, [sp, #0xf0]
    3988:      	ldr	x20, [sp, #0xf8]
    398c:      	ldr	x21, [sp, #0x100]
    3990:      	ldr	x22, [sp, #0x108]
    3994:      	ldr	x23, [sp, #0x110]
    3998:      	ldr	x24, [sp, #0x118]
    399c:      	ldr	x25, [sp, #0x120]
    39a0:      	ldr	x26, [sp, #0x128]
    39a4:      	ldr	x27, [sp, #0x130]
    39a8:      	ldr	x29, [sp]
    39ac:      	ldr	x30, [sp, #0x8]
    39b0:      	add	sp, sp, #0x140
    39b4:      	ret
    39b8:      	mov	x21, x8
    39bc:      	mov	x22, x0
    39c0:      	mov	x23, x1
    39c4:      	mov	w24, w2
    39c8:      	b	0x34a0 <_stogir.adjacency.reverse-postorder+0x170>
    39cc:      	udf	#0x0

00000000000039d0 <_stogir.dominators.build>:
    39d0:      	sub	sp, sp, #0xb0
    39d4:      	str	x29, [sp]
    39d8:      	str	x30, [sp, #0x8]
    39dc:      	mov	x29, sp
    39e0:      	str	x19, [sp, #0x70]
    39e4:      	str	x20, [sp, #0x78]
    39e8:      	str	x21, [sp, #0x80]
    39ec:      	str	x22, [sp, #0x88]
    39f0:      	str	x23, [sp, #0x90]
    39f4:      	str	x24, [sp, #0x98]
    39f8:      	str	x25, [sp, #0xa0]
    39fc:      	str	x26, [sp, #0xa8]
    3a00:      	add	x4, x0, #0x28
    3a04:      	add	x16, sp, #0x10
    3a08:      	orr	x5, x16, xzr
    3a0c:      	ldr	x6, [x3]
    3a10:      	ldr	x7, [x3, #0x8]
    3a14:      	add	x16, sp, #0x10
    3a18:      	movz	x17, #0x0, lsl #48
    3a1c:      	str	x17, [x16]
    3a20:      	add	x16, sp, #0x10
    3a24:      	movz	x17, #0x0, lsl #48
    3a28:      	str	x17, [x16, #0x8]
    3a2c:      	add	x16, sp, #0x10
    3a30:      	movz	x17, #0x0, lsl #48
    3a34:      	str	x17, [x16, #0x10]
    3a38:      	add	x16, sp, #0x10
    3a3c:      	str	x6, [x16, #0x18]
    3a40:      	add	x16, sp, #0x10
    3a44:      	str	x7, [x16, #0x20]
    3a48:      	ldr	x6, [x3]
    3a4c:      	ldr	x3, [x3, #0x8]
    3a50:      	add	x16, sp, #0x40
    3a54:      	movz	x17, #0x0, lsl #48
    3a58:      	str	x17, [x16]
    3a5c:      	add	x16, sp, #0x40
    3a60:      	movz	x17, #0x0, lsl #48
    3a64:      	str	x17, [x16, #0x8]
    3a68:      	add	x16, sp, #0x40
    3a6c:      	movz	x17, #0x0, lsl #48
    3a70:      	str	x17, [x16, #0x10]
    3a74:      	add	x16, sp, #0x40
    3a78:      	str	x6, [x16, #0x18]
    3a7c:      	add	x16, sp, #0x40
    3a80:      	str	x3, [x16, #0x20]
    3a84:      	ldr	x3, [x4, #0x8]
    3a88:      	orr	x19, x3, xzr
    3a8c:      	cmp	x19, #0x0
    3a90:      	b.le	0x3e34 <_stogir.dominators.build+0x464>
    3a94:      	cmp	x19, #0x0
    3a98:      	b.ge	0x3aa4 <_stogir.dominators.build+0xd4>
    3a9c:      	movz	x3, #0x0, lsl #48
    3aa0:      	b	0x3aa8 <_stogir.dominators.build+0xd8>
    3aa4:      	mov	x3, x19
    3aa8:      	mov	x20, x8
    3aac:      	mov	x21, x0
    3ab0:      	mov	x0, x5
    3ab4:      	mov	x22, x1
    3ab8:      	mov	x1, x3
    3abc:      	mov	x23, x2
    3ac0:      	bl	0x3ac0 <_stogir.dominators.build+0xf0>
		0000000000003ac0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3ac4:      	add	x16, sp, #0x40
    3ac8:      	orr	x24, x16, xzr
    3acc:      	add	x25, x21, #0x28
    3ad0:      	lsl	x0, x19, #2
    3ad4:      	add	x16, sp, #0x10
    3ad8:      	ldr	x1, [x16]
    3adc:      	mov	x2, x0
    3ae0:      	mov	x0, x1
    3ae4:      	movz	x1, #0x0, lsl #48
    3ae8:      	bl	0x3ae8 <_stogir.dominators.build+0x118>
		0000000000003ae8:  ARM64_RELOC_BRANCH26	_memset
    3aec:      	add	x16, sp, #0x10
    3af0:      	str	x19, [x16, #0x8]
    3af4:      	movz	x19, #0x0, lsl #48
    3af8:      	b	0x3b34 <_stogir.dominators.build+0x164>
    3afc:      	nop
    3b00:      	lsl	x0, x0, #1
    3b04:      	mov	x1, x0
    3b08:      	mov	x0, x24
    3b0c:      	bl	0x3b0c <_stogir.dominators.build+0x13c>
		0000000000003b0c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    3b10:      	add	x19, x19, #0x1
    3b14:      	add	x0, x26, #0x1
    3b18:      	add	x16, sp, #0x40
    3b1c:      	ldr	x1, [x16]
    3b20:      	add	x1, x1, x26, lsl #3
    3b24:      	movn	x17, #0x0, lsl #48
    3b28:      	str	x17, [x1]
    3b2c:      	add	x16, sp, #0x40
    3b30:      	str	x0, [x16, #0x8]
    3b34:      	ldr	x0, [x25, #0x8]
    3b38:      	cmp	x19, x0
    3b3c:      	b.ge	0x3b6c <_stogir.dominators.build+0x19c>
    3b40:      	add	x16, sp, #0x40
    3b44:      	ldr	x0, [x16, #0x8]
    3b48:      	orr	x26, x0, xzr
    3b4c:      	add	x16, sp, #0x40
    3b50:      	ldr	x0, [x16, #0x10]
    3b54:      	cmp	x26, x0
    3b58:      	b.lt	0x3b10 <_stogir.dominators.build+0x140>
    3b5c:      	cmp	x0, #0x0
    3b60:      	b.ne	0x3b00 <_stogir.dominators.build+0x130>
    3b64:      	mov	x0, #0x2                ; =2
    3b68:      	b	0x3b04 <_stogir.dominators.build+0x134>
    3b6c:      	movz	x0, #0x0, lsl #48
    3b70:      	b	0x3ba0 <_stogir.dominators.build+0x1d0>
    3b74:      	nop
    3b78:      	add	x1, x0, #0x1
    3b7c:      	ldr	x2, [x23]
    3b80:      	add	x2, x2, x0, lsl #2
    3b84:      	ldr	w2, [x2]
    3b88:      	sxtw	x2, w2
    3b8c:      	add	x16, sp, #0x40
    3b90:      	ldr	x3, [x16]
    3b94:      	add	x2, x3, x2, lsl #3
    3b98:      	str	x0, [x2]
    3b9c:      	mov	x0, x1
    3ba0:      	ldr	x1, [x23, #0x8]
    3ba4:      	cmp	x0, x1
    3ba8:      	b.lt	0x3b78 <_stogir.dominators.build+0x1a8>
    3bac:      	cmp	x1, #0x0
    3bb0:      	b.le	0x3d40 <_stogir.dominators.build+0x370>
    3bb4:      	ldr	x0, [x23]
    3bb8:      	ldr	w0, [x0]
    3bbc:      	sxtw	x1, w0
    3bc0:      	add	x16, sp, #0x10
    3bc4:      	ldr	x2, [x16]
    3bc8:      	add	x1, x2, x1, lsl #2
    3bcc:      	str	w0, [x1]
    3bd0:      	b	0x3d34 <_stogir.dominators.build+0x364>
    3bd4:      	nop
    3bd8:      	add	x16, sp, #0x10
    3bdc:      	ldr	x6, [x16]
    3be0:      	add	x6, x6, x11, lsl #2
    3be4:      	ldr	w6, [x6]
    3be8:      	add	x16, sp, #0x40
    3bec:      	ldr	x9, [x16]
    3bf0:      	orr	x10, x9, xzr
    3bf4:      	sxtw	x11, w6
    3bf8:      	add	x9, x8, x9
    3bfc:      	lsl	x12, x11, #3
    3c00:      	add	x10, x10, x11, lsl #3
    3c04:      	ldr	x10, [x10]
    3c08:      	ldr	x9, [x9]
    3c0c:      	cmp	x10, x9
    3c10:      	b.gt	0x3bd8 <_stogir.dominators.build+0x208>
    3c14:      	b	0x3c28 <_stogir.dominators.build+0x258>
    3c18:      	add	x16, sp, #0x10
    3c1c:      	ldr	x7, [x16]
    3c20:      	add	x7, x7, x10, lsl #2
    3c24:      	ldr	w7, [x7]
    3c28:      	add	x16, sp, #0x40
    3c2c:      	ldr	x8, [x16]
    3c30:      	orr	x9, x8, xzr
    3c34:      	sxtw	x10, w7
    3c38:      	add	x8, x12, x8
    3c3c:      	add	x9, x9, x10, lsl #3
    3c40:      	ldr	x9, [x9]
    3c44:      	ldr	x8, [x8]
    3c48:      	cmp	x9, x8
    3c4c:      	b.gt	0x3c18 <_stogir.dominators.build+0x248>
    3c50:      	sxtw	x10, w6
    3c54:      	sxtw	x8, w7
    3c58:      	cmp	x10, x8
    3c5c:      	b.eq	0x3c68 <_stogir.dominators.build+0x298>
    3c60:      	lsl	x8, x8, #3
    3c64:      	b	0x3be8 <_stogir.dominators.build+0x218>
    3c68:      	orr	w6, w10, wzr
    3c6c:      	add	x5, x5, #0x1
    3c70:      	sxtw	x7, w6
    3c74:      	cmp	x5, x3
    3c78:      	b.ge	0x3cc8 <_stogir.dominators.build+0x2f8>
    3c7c:      	add	x8, x4, x5
    3c80:      	ldr	x9, [x22, #0x28]
    3c84:      	add	x8, x9, x8, lsl #3
    3c88:      	ldr	x8, [x8]
    3c8c:      	ldr	x9, [x21, #0x50]
    3c90:      	add	x8, x9, x8, lsl #4
    3c94:      	ldr	x8, [x8]
    3c98:      	add	x16, sp, #0x10
    3c9c:      	ldr	x9, [x16]
    3ca0:      	sxtw	x10, w8
    3ca4:      	add	x9, x9, x10, lsl #2
    3ca8:      	ldr	w9, [x9]
    3cac:      	sxtw	x9, w9
    3cb0:      	cmp	x9, #0x0
    3cb4:      	b.eq	0x3c6c <_stogir.dominators.build+0x29c>
    3cb8:      	cmp	x7, #0x0
    3cbc:      	b.eq	0x3c68 <_stogir.dominators.build+0x298>
    3cc0:      	orr	w7, w8, wzr
    3cc4:      	b	0x3c50 <_stogir.dominators.build+0x280>
    3cc8:      	add	x16, sp, #0x10
    3ccc:      	ldr	x3, [x16]
    3cd0:      	add	x4, x3, x2, lsl #2
    3cd4:      	ldr	w4, [x4]
    3cd8:      	sxtw	x4, w4
    3cdc:      	cmp	x4, x7
    3ce0:      	b.eq	0x3cf0 <_stogir.dominators.build+0x320>
    3ce4:      	add	x1, x3, x2, lsl #2
    3ce8:      	str	w6, [x1]
    3cec:      	mov	x1, #0x1                ; =1
    3cf0:      	add	x0, x0, #0x1
    3cf4:      	ldr	x2, [x23, #0x8]
    3cf8:      	cmp	x0, x2
    3cfc:      	b.ge	0x3d2c <_stogir.dominators.build+0x35c>
    3d00:      	ldr	x2, [x23]
    3d04:      	add	x2, x2, x0, lsl #2
    3d08:      	ldr	w2, [x2]
    3d0c:      	sxtw	x2, w2
    3d10:      	ldr	x3, [x22]
    3d14:      	add	x3, x3, x2, lsl #4
    3d18:      	ldr	x4, [x3]
    3d1c:      	ldr	x3, [x3, #0x8]
    3d20:      	movz	x5, #0x0, lsl #48
    3d24:      	movz	w6, #0x0, lsl #16
    3d28:      	b	0x3c70 <_stogir.dominators.build+0x2a0>
    3d2c:      	cmp	x1, #0x0
    3d30:      	b.eq	0x3d40 <_stogir.dominators.build+0x370>
    3d34:      	mov	x0, #0x1                ; =1
    3d38:      	movz	x1, #0x0, lsl #48
    3d3c:      	b	0x3cf4 <_stogir.dominators.build+0x324>
    3d40:      	b	0x3d54 <_stogir.dominators.build+0x384>
    3d44:      	nop
    3d48:      	sub	x0, x0, #0x1
    3d4c:      	add	x16, sp, #0x40
    3d50:      	str	x0, [x16, #0x8]
    3d54:      	add	x16, sp, #0x40
    3d58:      	ldr	x0, [x16, #0x8]
    3d5c:      	cmp	x0, #0x0
    3d60:      	b.ne	0x3d48 <_stogir.dominators.build+0x378>
    3d64:      	add	x16, sp, #0x40
    3d68:      	ldr	x0, [x16, #0x10]
    3d6c:      	cmp	x0, #0x0
    3d70:      	b.le	0x3da4 <_stogir.dominators.build+0x3d4>
    3d74:      	add	x1, x24, #0x18
    3d78:      	add	x16, sp, #0x40
    3d7c:      	ldr	x2, [x16]
    3d80:      	fmov	d31, x0
    3d84:      	mov	x0, x1
    3d88:      	mov	x1, x2
    3d8c:      	fmov	x2, d31
    3d90:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x168>
		0000000000003d90:  ARM64_RELOC_PAGE21	l_stogir.417
    3d94:      	ldr	x3, [x3]
		0000000000003d94:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    3d98:      	mov	x4, #0x8                ; =8
    3d9c:      	mov	x5, #0x8                ; =8
    3da0:      	bl	0x3da0 <_stogir.dominators.build+0x3d0>
		0000000000003da0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3da4:      	add	x16, sp, #0x40
    3da8:      	movz	x17, #0x0, lsl #48
    3dac:      	str	x17, [x16]
    3db0:      	add	x16, sp, #0x40
    3db4:      	movz	x17, #0x0, lsl #48
    3db8:      	str	x17, [x16, #0x8]
    3dbc:      	add	x16, sp, #0x40
    3dc0:      	movz	x17, #0x0, lsl #48
    3dc4:      	str	x17, [x16, #0x10]
    3dc8:      	add	x16, sp, #0x10
    3dcc:      	ldr	x0, [x16]
    3dd0:      	add	x16, sp, #0x10
    3dd4:      	ldr	x1, [x16, #0x8]
    3dd8:      	add	x16, sp, #0x10
    3ddc:      	ldr	x2, [x16, #0x10]
    3de0:      	add	x16, sp, #0x10
    3de4:      	ldr	x3, [x16, #0x18]
    3de8:      	add	x16, sp, #0x10
    3dec:      	ldr	x4, [x16, #0x20]
    3df0:      	str	x0, [x20]
    3df4:      	str	x1, [x20, #0x8]
    3df8:      	str	x2, [x20, #0x10]
    3dfc:      	str	x3, [x20, #0x18]
    3e00:      	str	x4, [x20, #0x20]
    3e04:      	ldr	x19, [sp, #0x70]
    3e08:      	ldr	x20, [sp, #0x78]
    3e0c:      	ldr	x21, [sp, #0x80]
    3e10:      	ldr	x22, [sp, #0x88]
    3e14:      	ldr	x23, [sp, #0x90]
    3e18:      	ldr	x24, [sp, #0x98]
    3e1c:      	ldr	x25, [sp, #0xa0]
    3e20:      	ldr	x26, [sp, #0xa8]
    3e24:      	ldr	x29, [sp]
    3e28:      	ldr	x30, [sp, #0x8]
    3e2c:      	add	sp, sp, #0xb0
    3e30:      	ret
    3e34:      	mov	x20, x8
    3e38:      	mov	x21, x0
    3e3c:      	mov	x22, x1
    3e40:      	mov	x23, x2
    3e44:      	b	0x3ac4 <_stogir.dominators.build+0xf4>

0000000000003e48 <_stogir.loops.depths>:
    3e48:      	sub	sp, sp, #0x1f0
    3e4c:      	str	x29, [sp]
    3e50:      	str	x30, [sp, #0x8]
    3e54:      	mov	x29, sp
    3e58:      	str	x19, [sp, #0x1a0]
    3e5c:      	str	x20, [sp, #0x1a8]
    3e60:      	str	x21, [sp, #0x1b0]
    3e64:      	str	x22, [sp, #0x1b8]
    3e68:      	str	x23, [sp, #0x1c0]
    3e6c:      	str	x24, [sp, #0x1c8]
    3e70:      	str	x25, [sp, #0x1d0]
    3e74:      	str	x26, [sp, #0x1d8]
    3e78:      	str	x27, [sp, #0x1e0]
    3e7c:      	str	x28, [sp, #0x1e8]
    3e80:      	add	x19, x0, #0x28
    3e84:      	add	x16, sp, #0xb0
    3e88:      	orr	x20, x16, xzr
    3e8c:      	mov	x21, x8
    3e90:      	add	x8, sp, #0x60
    3e94:      	mov	x22, x0
    3e98:      	mov	x0, x2
    3e9c:      	mov	x23, x1
    3ea0:      	mov	x1, x3
    3ea4:      	mov	x24, x2
    3ea8:      	mov	x25, x3
    3eac:      	bl	0x3eac <_stogir.loops.depths+0x64>
		0000000000003eac:  ARM64_RELOC_BRANCH26	_stogir.dominators.build-index
    3eb0:      	add	x16, sp, #0x60
    3eb4:      	ldr	x0, [x16]
    3eb8:      	add	x16, sp, #0x10
    3ebc:      	str	x0, [x16]
    3ec0:      	add	x16, sp, #0x60
    3ec4:      	ldr	x0, [x16, #0x8]
    3ec8:      	add	x16, sp, #0x10
    3ecc:      	str	x0, [x16, #0x8]
    3ed0:      	add	x16, sp, #0x60
    3ed4:      	ldr	x0, [x16, #0x10]
    3ed8:      	add	x16, sp, #0x10
    3edc:      	str	x0, [x16, #0x10]
    3ee0:      	add	x16, sp, #0x60
    3ee4:      	ldr	x0, [x16, #0x18]
    3ee8:      	add	x16, sp, #0x10
    3eec:      	str	x0, [x16, #0x18]
    3ef0:      	add	x16, sp, #0x60
    3ef4:      	ldr	x0, [x16, #0x20]
    3ef8:      	add	x16, sp, #0x10
    3efc:      	str	x0, [x16, #0x20]
    3f00:      	add	x16, sp, #0x60
    3f04:      	ldr	x0, [x16, #0x28]
    3f08:      	add	x16, sp, #0x10
    3f0c:      	str	x0, [x16, #0x28]
    3f10:      	add	x16, sp, #0x60
    3f14:      	ldr	x0, [x16, #0x30]
    3f18:      	add	x16, sp, #0x10
    3f1c:      	str	x0, [x16, #0x30]
    3f20:      	add	x16, sp, #0x60
    3f24:      	ldr	x0, [x16, #0x38]
    3f28:      	add	x16, sp, #0x10
    3f2c:      	str	x0, [x16, #0x38]
    3f30:      	add	x16, sp, #0x60
    3f34:      	ldr	x0, [x16, #0x40]
    3f38:      	add	x16, sp, #0x10
    3f3c:      	str	x0, [x16, #0x40]
    3f40:      	add	x16, sp, #0x60
    3f44:      	ldr	x0, [x16, #0x48]
    3f48:      	add	x16, sp, #0x10
    3f4c:      	str	x0, [x16, #0x48]
    3f50:      	ldr	x0, [x25]
    3f54:      	ldr	x1, [x25, #0x8]
    3f58:      	add	x16, sp, #0xb0
    3f5c:      	movz	x17, #0x0, lsl #48
    3f60:      	str	x17, [x16]
    3f64:      	add	x16, sp, #0xb0
    3f68:      	movz	x17, #0x0, lsl #48
    3f6c:      	str	x17, [x16, #0x8]
    3f70:      	add	x16, sp, #0xb0
    3f74:      	movz	x17, #0x0, lsl #48
    3f78:      	str	x17, [x16, #0x10]
    3f7c:      	add	x16, sp, #0xb0
    3f80:      	str	x0, [x16, #0x18]
    3f84:      	add	x16, sp, #0xb0
    3f88:      	str	x1, [x16, #0x20]
    3f8c:      	ldr	x0, [x25]
    3f90:      	ldr	x1, [x25, #0x8]
    3f94:      	add	x16, sp, #0xe0
    3f98:      	movz	x17, #0x0, lsl #48
    3f9c:      	str	x17, [x16]
    3fa0:      	add	x16, sp, #0xe0
    3fa4:      	movz	x17, #0x0, lsl #48
    3fa8:      	str	x17, [x16, #0x8]
    3fac:      	add	x16, sp, #0xe0
    3fb0:      	movz	x17, #0x0, lsl #48
    3fb4:      	str	x17, [x16, #0x10]
    3fb8:      	add	x16, sp, #0xe0
    3fbc:      	str	x0, [x16, #0x18]
    3fc0:      	add	x16, sp, #0xe0
    3fc4:      	str	x1, [x16, #0x20]
    3fc8:      	ldr	x0, [x25]
    3fcc:      	ldr	x1, [x25, #0x8]
    3fd0:      	add	x16, sp, #0x110
    3fd4:      	movz	x17, #0x0, lsl #48
    3fd8:      	str	x17, [x16]
    3fdc:      	add	x16, sp, #0x110
    3fe0:      	movz	x17, #0x0, lsl #48
    3fe4:      	str	x17, [x16, #0x8]
    3fe8:      	add	x16, sp, #0x110
    3fec:      	movz	x17, #0x0, lsl #48
    3ff0:      	str	x17, [x16, #0x10]
    3ff4:      	add	x16, sp, #0x110
    3ff8:      	str	x0, [x16, #0x18]
    3ffc:      	add	x16, sp, #0x110
    4000:      	str	x1, [x16, #0x20]
    4004:      	ldr	x0, [x19, #0x8]
    4008:      	orr	x25, x0, xzr
    400c:      	add	x16, sp, #0xb0
    4010:      	ldr	x0, [x16, #0x8]
    4014:      	orr	x26, x0, xzr
    4018:      	add	x16, sp, #0xb0
    401c:      	ldr	x0, [x16, #0x10]
    4020:      	add	x27, x26, x25
    4024:      	cmp	x27, x0
    4028:      	b.le	0x405c <_stogir.loops.depths+0x214>
    402c:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    4030:      	cmp	x0, x17
    4034:      	b.gt	0x4040 <_stogir.loops.depths+0x1f8>
    4038:      	lsl	x0, x0, #1
    403c:      	b	0x4044 <_stogir.loops.depths+0x1fc>
    4040:      	mov	x0, x27
    4044:      	cmp	x0, x27
    4048:      	b.gt	0x4050 <_stogir.loops.depths+0x208>
    404c:      	mov	x0, x27
    4050:      	mov	x1, x0
    4054:      	mov	x0, x20
    4058:      	bl	0x4058 <_stogir.loops.depths+0x210>
		0000000000004058:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    405c:      	add	x16, sp, #0x10
    4060:      	orr	x20, x16, xzr
    4064:      	add	x16, sp, #0xe0
    4068:      	orr	x28, x16, xzr
    406c:      	add	x16, sp, #0x110
    4070:      	orr	x0, x16, xzr
    4074:      	lsl	x1, x25, #2
    4078:      	add	x16, sp, #0xb0
    407c:      	ldr	x2, [x16]
    4080:      	add	x2, x2, x26, lsl #2
    4084:      	mov	x25, x0
    4088:      	mov	x0, x2
    408c:      	mov	x2, x1
    4090:      	movz	x1, #0x0, lsl #48
    4094:      	bl	0x4094 <_stogir.loops.depths+0x24c>
		0000000000004094:  ARM64_RELOC_BRANCH26	_memset
    4098:      	add	x16, sp, #0xb0
    409c:      	str	x27, [x16, #0x8]
    40a0:      	ldr	x0, [x19, #0x8]
    40a4:      	mov	x1, x0
    40a8:      	mov	x0, x28
    40ac:      	bl	0x40ac <_stogir.loops.depths+0x264>
		00000000000040ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    40b0:      	ldr	x0, [x22]
    40b4:      	orr	x19, x0, xzr
    40b8:      	ldr	x0, [x22, #0x8]
    40bc:      	orr	x26, x0, xzr
    40c0:      	movz	x27, #0x0, lsl #48
    40c4:      	b	0x4244 <_stogir.loops.depths+0x3fc>
    40c8:      	lsl	x3, x3, #1
    40cc:      	str	x19, [sp, #0x188]
    40d0:      	mov	x19, x0
    40d4:      	mov	x0, x25
    40d8:      	str	w20, [sp, #0x190]
    40dc:      	mov	w20, w1
    40e0:      	mov	x1, x3
    40e4:      	str	x22, [sp, #0x198]
    40e8:      	mov	x22, x2
    40ec:      	bl	0x40ec <_stogir.loops.depths+0x2a4>
		00000000000040ec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    40f0:      	add	x0, x22, #0x1
    40f4:      	add	x16, sp, #0x110
    40f8:      	ldr	x1, [x16]
    40fc:      	add	x1, x1, x22, lsl #2
    4100:      	str	w20, [x1]
    4104:      	add	x16, sp, #0x110
    4108:      	str	x0, [x16, #0x8]
    410c:      	b	0x4120 <_stogir.loops.depths+0x2d8>
    4110:      	str	x22, [sp, #0x198]
    4114:      	str	x19, [sp, #0x188]
    4118:      	mov	x19, x0
    411c:      	str	w20, [sp, #0x190]
    4120:      	add	x19, x19, #0x1
    4124:      	ldr	x22, [sp, #0x198]
    4128:      	ldr	w20, [sp, #0x190]
    412c:      	mov	x0, x19
    4130:      	ldr	x19, [sp, #0x188]
    4134:      	cmp	x0, x27
    4138:      	b.ge	0x46c8 <_stogir.loops.depths+0x880>
    413c:      	add	x1, x26, x0
    4140:      	ldr	x2, [x23, #0x28]
    4144:      	add	x1, x2, x1, lsl #3
    4148:      	ldr	x1, [x1]
    414c:      	ldr	x2, [x22, #0x50]
    4150:      	add	x1, x2, x1, lsl #4
    4154:      	ldr	x1, [x1]
    4158:      	ldr	x2, [x24]
    415c:      	sxtw	x3, w1
    4160:      	add	x2, x2, x3, lsl #2
    4164:      	ldr	w2, [x2]
    4168:      	sxtw	x2, w2
    416c:      	cmp	x2, #0x0
    4170:      	b.eq	0x4110 <_stogir.loops.depths+0x2c8>
    4174:      	add	x16, sp, #0xe0
    4178:      	ldr	x2, [x16]
    417c:      	add	x4, x2, x3, lsl #2
    4180:      	ldr	w4, [x4]
    4184:      	sxtw	x4, w4
    4188:      	cmp	x4, x19
    418c:      	b.eq	0x46d8 <_stogir.loops.depths+0x890>
    4190:      	add	x2, x2, x3, lsl #2
    4194:      	str	w20, [x2]
    4198:      	add	x16, sp, #0xb0
    419c:      	ldr	x2, [x16]
    41a0:      	orr	x4, x2, xzr
    41a4:      	add	x4, x4, x3, lsl #2
    41a8:      	add	x2, x2, x3, lsl #2
    41ac:      	ldr	w3, [x4]
    41b0:      	add	w3, w3, #0x1
    41b4:      	str	w3, [x2]
    41b8:      	add	x16, sp, #0x110
    41bc:      	ldr	x2, [x16, #0x8]
    41c0:      	add	x16, sp, #0x110
    41c4:      	ldr	x3, [x16, #0x10]
    41c8:      	cmp	x2, x3
    41cc:      	b.lt	0x46ec <_stogir.loops.depths+0x8a4>
    41d0:      	cmp	x3, #0x0
    41d4:      	b.ne	0x40c8 <_stogir.loops.depths+0x280>
    41d8:      	mov	x3, #0x2                ; =2
    41dc:      	b	0x40cc <_stogir.loops.depths+0x284>
    41e0:      	add	x21, x21, #0x1
    41e4:      	ldr	x22, [sp, #0x198]
    41e8:      	ldr	x19, [sp, #0x188]
    41ec:      	ldr	w20, [sp, #0x190]
    41f0:      	add	x16, sp, #0x110
    41f4:      	ldr	x0, [x16, #0x8]
    41f8:      	cmp	x21, x0
    41fc:      	b.ge	0x4708 <_stogir.loops.depths+0x8c0>
    4200:      	add	x16, sp, #0x110
    4204:      	ldr	x0, [x16]
    4208:      	add	x0, x0, x21, lsl #2
    420c:      	ldr	w0, [x0]
    4210:      	sxtw	x0, w0
    4214:      	ldr	x1, [x23]
    4218:      	add	x0, x1, x0, lsl #4
    421c:      	ldr	x26, [x0]
    4220:      	ldr	x27, [x0, #0x8]
    4224:      	movz	x0, #0x0, lsl #48
    4228:      	b	0x4134 <_stogir.loops.depths+0x2ec>
    422c:      	ldr	x21, [sp, #0x180]
    4230:      	ldr	x22, [sp, #0x198]
    4234:      	ldr	x20, [sp, #0x148]
    4238:      	ldr	x19, [sp, #0x140]
    423c:      	ldr	x26, [sp, #0x170]
    4240:      	ldr	x27, [sp, #0x178]
    4244:      	cmp	x27, x26
    4248:      	b.ge	0x426c <_stogir.loops.depths+0x424>
    424c:      	add	x0, x27, #0x1
    4250:      	add	x1, x19, x27, lsl #2
    4254:      	ldr	w1, [x1]
    4258:      	movn	w17, #0x0, lsl #16
    425c:      	and	w1, w1, w17
    4260:      	mov	x27, x0
    4264:      	mov	w0, #0x1                ; =1
    4268:      	b	0x4274 <_stogir.loops.depths+0x42c>
    426c:      	movz	w0, #0x0, lsl #16
    4270:      	movz	w1, #0x0, lsl #16
    4274:      	ubfx	x0, x0, #0, #32
    4278:      	lsr	x16, x0, #0
    427c:      	cmp	x16, #0x1
    4280:      	b.eq	0x42a4 <_stogir.loops.depths+0x45c>
    4284:      	b.lo	0x428c <_stogir.loops.depths+0x444>
    4288:      	b	0x42a8 <_stogir.loops.depths+0x460>
    428c:      	cmp	x16, #0x0
    4290:      	b.eq	0x4298 <_stogir.loops.depths+0x450>
    4294:      	b	0x42a8 <_stogir.loops.depths+0x460>
    4298:      	str	x21, [sp, #0x180]
    429c:      	str	x20, [sp, #0x148]
    42a0:      	b	0x42ac <_stogir.loops.depths+0x464>
    42a4:      	b	0x4444 <_stogir.loops.depths+0x5fc>
    42a8:      	b	0x4670 <_stogir.loops.depths+0x828>
    42ac:      	ldr	x0, [sp, #0x148]
    42b0:      	bl	0x42b0 <_stogir.loops.depths+0x468>
		00000000000042b0:  ARM64_RELOC_BRANCH26	_stogir.dominators.release-index!
    42b4:      	b	0x42c4 <_stogir.loops.depths+0x47c>
    42b8:      	sub	x0, x0, #0x1
    42bc:      	add	x16, sp, #0xe0
    42c0:      	str	x0, [x16, #0x8]
    42c4:      	add	x16, sp, #0xe0
    42c8:      	ldr	x0, [x16, #0x8]
    42cc:      	cmp	x0, #0x0
    42d0:      	b.ne	0x42b8 <_stogir.loops.depths+0x470>
    42d4:      	add	x16, sp, #0xe0
    42d8:      	ldr	x0, [x16, #0x10]
    42dc:      	cmp	x0, #0x0
    42e0:      	b.le	0x4314 <_stogir.loops.depths+0x4cc>
    42e4:      	add	x1, x28, #0x18
    42e8:      	add	x16, sp, #0xe0
    42ec:      	ldr	x2, [x16]
    42f0:      	fmov	d31, x0
    42f4:      	mov	x0, x1
    42f8:      	mov	x1, x2
    42fc:      	fmov	x2, d31
    4300:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x1b8>
		0000000000004300:  ARM64_RELOC_PAGE21	l_stogir.418
    4304:      	ldr	x3, [x3]
		0000000000004304:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    4308:      	mov	x4, #0x4                ; =4
    430c:      	mov	x5, #0x4                ; =4
    4310:      	bl	0x4310 <_stogir.loops.depths+0x4c8>
		0000000000004310:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4314:      	add	x16, sp, #0xe0
    4318:      	movz	x17, #0x0, lsl #48
    431c:      	str	x17, [x16]
    4320:      	add	x16, sp, #0xe0
    4324:      	movz	x17, #0x0, lsl #48
    4328:      	str	x17, [x16, #0x8]
    432c:      	add	x16, sp, #0xe0
    4330:      	movz	x17, #0x0, lsl #48
    4334:      	str	x17, [x16, #0x10]
    4338:      	b	0x434c <_stogir.loops.depths+0x504>
    433c:      	nop
    4340:      	sub	x0, x0, #0x1
    4344:      	add	x16, sp, #0x110
    4348:      	str	x0, [x16, #0x8]
    434c:      	add	x16, sp, #0x110
    4350:      	ldr	x0, [x16, #0x8]
    4354:      	cmp	x0, #0x0
    4358:      	b.ne	0x4340 <_stogir.loops.depths+0x4f8>
    435c:      	add	x16, sp, #0x110
    4360:      	ldr	x0, [x16, #0x10]
    4364:      	cmp	x0, #0x0
    4368:      	b.le	0x439c <_stogir.loops.depths+0x554>
    436c:      	add	x1, x25, #0x18
    4370:      	add	x16, sp, #0x110
    4374:      	ldr	x2, [x16]
    4378:      	fmov	d31, x0
    437c:      	mov	x0, x1
    4380:      	mov	x1, x2
    4384:      	fmov	x2, d31
    4388:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x1b8>
		0000000000004388:  ARM64_RELOC_PAGE21	l_stogir.418
    438c:      	ldr	x3, [x3]
		000000000000438c:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    4390:      	mov	x4, #0x4                ; =4
    4394:      	mov	x5, #0x4                ; =4
    4398:      	bl	0x4398 <_stogir.loops.depths+0x550>
		0000000000004398:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    439c:      	add	x16, sp, #0x110
    43a0:      	movz	x17, #0x0, lsl #48
    43a4:      	str	x17, [x16]
    43a8:      	add	x16, sp, #0x110
    43ac:      	movz	x17, #0x0, lsl #48
    43b0:      	str	x17, [x16, #0x8]
    43b4:      	add	x16, sp, #0x110
    43b8:      	movz	x17, #0x0, lsl #48
    43bc:      	str	x17, [x16, #0x10]
    43c0:      	add	x16, sp, #0xb0
    43c4:      	ldr	x0, [x16]
    43c8:      	add	x16, sp, #0xb0
    43cc:      	ldr	x1, [x16, #0x8]
    43d0:      	add	x16, sp, #0xb0
    43d4:      	ldr	x2, [x16, #0x10]
    43d8:      	add	x16, sp, #0xb0
    43dc:      	ldr	x3, [x16, #0x18]
    43e0:      	add	x16, sp, #0xb0
    43e4:      	ldr	x4, [x16, #0x20]
    43e8:      	ldr	x5, [sp, #0x180]
    43ec:      	str	x0, [x5]
    43f0:      	str	x1, [x5, #0x8]
    43f4:      	str	x2, [x5, #0x10]
    43f8:      	str	x3, [x5, #0x18]
    43fc:      	str	x4, [x5, #0x20]
    4400:      	ldr	x19, [sp, #0x1a0]
    4404:      	ldr	x20, [sp, #0x1a8]
    4408:      	ldr	x21, [sp, #0x1b0]
    440c:      	ldr	x22, [sp, #0x1b8]
    4410:      	ldr	x23, [sp, #0x1c0]
    4414:      	ldr	x24, [sp, #0x1c8]
    4418:      	ldr	x25, [sp, #0x1d0]
    441c:      	ldr	x26, [sp, #0x1d8]
    4420:      	ldr	x27, [sp, #0x1e0]
    4424:      	ldr	x28, [sp, #0x1e8]
    4428:      	ldr	x29, [sp]
    442c:      	ldr	x30, [sp, #0x8]
    4430:      	add	sp, sp, #0x1f0
    4434:      	ret
    4438:      	sub	x0, x0, #0x1
    443c:      	add	x16, sp, #0x110
    4440:      	str	x0, [x16, #0x8]
    4444:      	add	x16, sp, #0x110
    4448:      	ldr	x0, [x16, #0x8]
    444c:      	cmp	x0, #0x0
    4450:      	b.ne	0x4438 <_stogir.loops.depths+0x5f0>
    4454:      	sxtw	x0, w1
    4458:      	lsl	x2, x0, #2
    445c:      	cmp	x0, #0x0
    4460:      	cset	w3, gt
    4464:      	add	x16, sp, #0xe0
    4468:      	ldr	x4, [x16]
    446c:      	add	x4, x4, x0, lsl #2
    4470:      	str	w1, [x4]
    4474:      	ldr	x4, [x23]
    4478:      	add	x4, x4, x0, lsl #4
    447c:      	ldr	x5, [x4]
    4480:      	ldr	x4, [x4, #0x8]
    4484:      	movz	x6, #0x0, lsl #48
    4488:      	movz	x7, #0x0, lsl #48
    448c:      	b	0x452c <_stogir.loops.depths+0x6e4>
    4490:      	lsl	x9, x9, #1
    4494:      	str	x2, [sp, #0x150]
    4498:      	str	w3, [sp, #0x158]
    449c:      	str	x5, [sp, #0x160]
    44a0:      	str	x4, [sp, #0x168]
    44a4:      	str	x19, [sp, #0x140]
    44a8:      	mov	x19, x0
    44ac:      	mov	x0, x25
    44b0:      	str	x20, [sp, #0x148]
    44b4:      	mov	w20, w1
    44b8:      	mov	x1, x9
    44bc:      	str	x26, [sp, #0x170]
    44c0:      	mov	x26, x6
    44c4:      	str	x27, [sp, #0x178]
    44c8:      	mov	w27, w8
    44cc:      	str	x21, [sp, #0x180]
    44d0:      	mov	x21, x7
    44d4:      	bl	0x44d4 <_stogir.loops.depths+0x68c>
		00000000000044d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    44d8:      	add	x0, x21, #0x1
    44dc:      	add	x16, sp, #0x110
    44e0:      	ldr	x1, [x16]
    44e4:      	add	x1, x1, x21, lsl #2
    44e8:      	str	w27, [x1]
    44ec:      	add	x16, sp, #0x110
    44f0:      	str	x0, [x16, #0x8]
    44f4:      	mov	x7, #0x1                ; =1
    44f8:      	add	x26, x26, #0x1
    44fc:      	ldr	x21, [sp, #0x180]
    4500:      	mov	x0, x19
    4504:      	mov	w1, w20
    4508:      	ldr	x20, [sp, #0x148]
    450c:      	ldr	x5, [sp, #0x160]
    4510:      	ldr	x4, [sp, #0x168]
    4514:      	ldr	x2, [sp, #0x150]
    4518:      	ldr	w3, [sp, #0x158]
    451c:      	ldr	x19, [sp, #0x140]
    4520:      	ldr	x27, [sp, #0x178]
    4524:      	mov	x6, x26
    4528:      	ldr	x26, [sp, #0x170]
    452c:      	cmp	x6, x4
    4530:      	b.ge	0x4710 <_stogir.loops.depths+0x8c8>
    4534:      	add	x8, x5, x6
    4538:      	ldr	x9, [x23, #0x28]
    453c:      	add	x8, x9, x8, lsl #3
    4540:      	ldr	x8, [x8]
    4544:      	ldr	x9, [x22, #0x50]
    4548:      	add	x8, x9, x8, lsl #4
    454c:      	ldr	x8, [x8]
    4550:      	uxtb	w16, w3
    4554:      	cmp	w16, wzr
    4558:      	b.eq	0x4730 <_stogir.loops.depths+0x8e8>
    455c:      	sxtw	x9, w8
    4560:      	cmp	x9, #0x0
    4564:      	b.le	0x4764 <_stogir.loops.depths+0x91c>
    4568:      	add	x16, sp, #0x10
    456c:      	ldr	x10, [x16, #0x8]
    4570:      	cmp	x0, x10
    4574:      	b.ge	0x4798 <_stogir.loops.depths+0x950>
    4578:      	cmp	x9, x10
    457c:      	b.ge	0x47cc <_stogir.loops.depths+0x984>
    4580:      	add	x16, sp, #0x10
    4584:      	ldr	x10, [x16]
    4588:      	add	x11, x2, x10
    458c:      	ldr	w11, [x11]
    4590:      	sxtw	x11, w11
    4594:      	cmp	x11, #0x0
    4598:      	b.le	0x4800 <_stogir.loops.depths+0x9b8>
    459c:      	lsl	x12, x9, #2
    45a0:      	add	x9, x10, x9, lsl #2
    45a4:      	ldr	w9, [x9]
    45a8:      	sxtw	x9, w9
    45ac:      	cmp	x9, #0x0
    45b0:      	b.le	0x4834 <_stogir.loops.depths+0x9ec>
    45b4:      	cmp	x11, x9
    45b8:      	b.gt	0x4868 <_stogir.loops.depths+0xa20>
    45bc:      	add	x16, sp, #0x10
    45c0:      	ldr	x9, [x16, #0x28]
    45c4:      	orr	x10, x9, xzr
    45c8:      	add	x10, x2, x10
    45cc:      	add	x9, x12, x9
    45d0:      	ldr	w10, [x10]
    45d4:      	sxtw	x10, w10
    45d8:      	ldr	w9, [x9]
    45dc:      	sxtw	x9, w9
    45e0:      	cmp	x10, x9
    45e4:      	b.lt	0x489c <_stogir.loops.depths+0xa54>
    45e8:      	cmp	x7, #0x0
    45ec:      	b.ne	0x4610 <_stogir.loops.depths+0x7c8>
    45f0:      	add	x16, sp, #0xb0
    45f4:      	ldr	x7, [x16]
    45f8:      	orr	x9, x7, xzr
    45fc:      	add	x9, x2, x9
    4600:      	add	x7, x2, x7
    4604:      	ldr	w9, [x9]
    4608:      	add	w9, w9, #0x1
    460c:      	str	w9, [x7]
    4610:      	add	x16, sp, #0xe0
    4614:      	ldr	x7, [x16]
    4618:      	add	x9, x12, x7
    461c:      	ldr	w9, [x9]
    4620:      	sxtw	x9, w9
    4624:      	cmp	x9, x0
    4628:      	b.ne	0x4678 <_stogir.loops.depths+0x830>
    462c:      	str	x21, [sp, #0x180]
    4630:      	str	x20, [sp, #0x148]
    4634:      	mov	w20, w1
    4638:      	str	x5, [sp, #0x160]
    463c:      	str	x4, [sp, #0x168]
    4640:      	str	x2, [sp, #0x150]
    4644:      	str	w3, [sp, #0x158]
    4648:      	str	x19, [sp, #0x140]
    464c:      	mov	x19, x0
    4650:      	str	x26, [sp, #0x170]
    4654:      	mov	x26, x6
    4658:      	str	x27, [sp, #0x178]
    465c:      	b	0x44f4 <_stogir.loops.depths+0x6ac>
    4660:      	cmp	x7, #0x0
    4664:      	b.eq	0x48d0 <_stogir.loops.depths+0xa88>
    4668:      	movz	x21, #0x0, lsl #48
    466c:      	b	0x41f0 <_stogir.loops.depths+0x3a8>
    4670:      	brk	#0
    4674:      	b	0x4670 <_stogir.loops.depths+0x828>
    4678:      	add	x7, x12, x7
    467c:      	str	w1, [x7]
    4680:      	add	x16, sp, #0xb0
    4684:      	ldr	x7, [x16]
    4688:      	orr	x9, x7, xzr
    468c:      	add	x9, x12, x9
    4690:      	add	x7, x12, x7
    4694:      	ldr	w9, [x9]
    4698:      	add	w9, w9, #0x1
    469c:      	str	w9, [x7]
    46a0:      	add	x16, sp, #0x110
    46a4:      	ldr	x7, [x16, #0x8]
    46a8:      	add	x16, sp, #0x110
    46ac:      	ldr	x9, [x16, #0x10]
    46b0:      	cmp	x7, x9
    46b4:      	b.lt	0x48d8 <_stogir.loops.depths+0xa90>
    46b8:      	cmp	x9, #0x0
    46bc:      	b.ne	0x4490 <_stogir.loops.depths+0x648>
    46c0:      	mov	x9, #0x2                ; =2
    46c4:      	b	0x4494 <_stogir.loops.depths+0x64c>
    46c8:      	str	x22, [sp, #0x198]
    46cc:      	str	x19, [sp, #0x188]
    46d0:      	str	w20, [sp, #0x190]
    46d4:      	b	0x41e0 <_stogir.loops.depths+0x398>
    46d8:      	str	x22, [sp, #0x198]
    46dc:      	str	x19, [sp, #0x188]
    46e0:      	mov	x19, x0
    46e4:      	str	w20, [sp, #0x190]
    46e8:      	b	0x4120 <_stogir.loops.depths+0x2d8>
    46ec:      	str	x22, [sp, #0x198]
    46f0:      	str	x19, [sp, #0x188]
    46f4:      	mov	x19, x0
    46f8:      	str	w20, [sp, #0x190]
    46fc:      	mov	w20, w1
    4700:      	mov	x22, x2
    4704:      	b	0x40f0 <_stogir.loops.depths+0x2a8>
    4708:      	str	x22, [sp, #0x198]
    470c:      	b	0x422c <_stogir.loops.depths+0x3e4>
    4710:      	str	x21, [sp, #0x180]
    4714:      	str	x20, [sp, #0x148]
    4718:      	mov	w20, w1
    471c:      	str	x19, [sp, #0x140]
    4720:      	mov	x19, x0
    4724:      	str	x26, [sp, #0x170]
    4728:      	str	x27, [sp, #0x178]
    472c:      	b	0x4660 <_stogir.loops.depths+0x818>
    4730:      	str	x21, [sp, #0x180]
    4734:      	str	x20, [sp, #0x148]
    4738:      	mov	w20, w1
    473c:      	str	x5, [sp, #0x160]
    4740:      	str	x4, [sp, #0x168]
    4744:      	str	x2, [sp, #0x150]
    4748:      	str	w3, [sp, #0x158]
    474c:      	str	x19, [sp, #0x140]
    4750:      	mov	x19, x0
    4754:      	str	x26, [sp, #0x170]
    4758:      	mov	x26, x6
    475c:      	str	x27, [sp, #0x178]
    4760:      	b	0x44f8 <_stogir.loops.depths+0x6b0>
    4764:      	str	x21, [sp, #0x180]
    4768:      	str	x20, [sp, #0x148]
    476c:      	mov	w20, w1
    4770:      	str	x5, [sp, #0x160]
    4774:      	str	x4, [sp, #0x168]
    4778:      	str	x2, [sp, #0x150]
    477c:      	str	w3, [sp, #0x158]
    4780:      	str	x19, [sp, #0x140]
    4784:      	mov	x19, x0
    4788:      	str	x26, [sp, #0x170]
    478c:      	mov	x26, x6
    4790:      	str	x27, [sp, #0x178]
    4794:      	b	0x44f8 <_stogir.loops.depths+0x6b0>
    4798:      	str	x21, [sp, #0x180]
    479c:      	str	x20, [sp, #0x148]
    47a0:      	mov	w20, w1
    47a4:      	str	x5, [sp, #0x160]
    47a8:      	str	x4, [sp, #0x168]
    47ac:      	str	x2, [sp, #0x150]
    47b0:      	str	w3, [sp, #0x158]
    47b4:      	str	x19, [sp, #0x140]
    47b8:      	mov	x19, x0
    47bc:      	str	x26, [sp, #0x170]
    47c0:      	mov	x26, x6
    47c4:      	str	x27, [sp, #0x178]
    47c8:      	b	0x44f8 <_stogir.loops.depths+0x6b0>
    47cc:      	str	x21, [sp, #0x180]
    47d0:      	str	x20, [sp, #0x148]
    47d4:      	mov	w20, w1
    47d8:      	str	x5, [sp, #0x160]
    47dc:      	str	x4, [sp, #0x168]
    47e0:      	str	x2, [sp, #0x150]
    47e4:      	str	w3, [sp, #0x158]
    47e8:      	str	x19, [sp, #0x140]
    47ec:      	mov	x19, x0
    47f0:      	str	x26, [sp, #0x170]
    47f4:      	mov	x26, x6
    47f8:      	str	x27, [sp, #0x178]
    47fc:      	b	0x44f8 <_stogir.loops.depths+0x6b0>
    4800:      	str	x21, [sp, #0x180]
    4804:      	str	x20, [sp, #0x148]
    4808:      	mov	w20, w1
    480c:      	str	x5, [sp, #0x160]
    4810:      	str	x4, [sp, #0x168]
    4814:      	str	x2, [sp, #0x150]
    4818:      	str	w3, [sp, #0x158]
    481c:      	str	x19, [sp, #0x140]
    4820:      	mov	x19, x0
    4824:      	str	x26, [sp, #0x170]
    4828:      	mov	x26, x6
    482c:      	str	x27, [sp, #0x178]
    4830:      	b	0x44f8 <_stogir.loops.depths+0x6b0>
    4834:      	str	x21, [sp, #0x180]
    4838:      	str	x20, [sp, #0x148]
    483c:      	mov	w20, w1
    4840:      	str	x5, [sp, #0x160]
    4844:      	str	x4, [sp, #0x168]
    4848:      	str	x2, [sp, #0x150]
    484c:      	str	w3, [sp, #0x158]
    4850:      	str	x19, [sp, #0x140]
    4854:      	mov	x19, x0
    4858:      	str	x26, [sp, #0x170]
    485c:      	mov	x26, x6
    4860:      	str	x27, [sp, #0x178]
    4864:      	b	0x44f8 <_stogir.loops.depths+0x6b0>
    4868:      	str	x21, [sp, #0x180]
    486c:      	str	x20, [sp, #0x148]
    4870:      	mov	w20, w1
    4874:      	str	x5, [sp, #0x160]
    4878:      	str	x4, [sp, #0x168]
    487c:      	str	x2, [sp, #0x150]
    4880:      	str	w3, [sp, #0x158]
    4884:      	str	x19, [sp, #0x140]
    4888:      	mov	x19, x0
    488c:      	str	x26, [sp, #0x170]
    4890:      	mov	x26, x6
    4894:      	str	x27, [sp, #0x178]
    4898:      	b	0x44f8 <_stogir.loops.depths+0x6b0>
    489c:      	str	x21, [sp, #0x180]
    48a0:      	str	x20, [sp, #0x148]
    48a4:      	mov	w20, w1
    48a8:      	str	x5, [sp, #0x160]
    48ac:      	str	x4, [sp, #0x168]
    48b0:      	str	x2, [sp, #0x150]
    48b4:      	str	w3, [sp, #0x158]
    48b8:      	str	x19, [sp, #0x140]
    48bc:      	mov	x19, x0
    48c0:      	str	x26, [sp, #0x170]
    48c4:      	mov	x26, x6
    48c8:      	str	x27, [sp, #0x178]
    48cc:      	b	0x44f8 <_stogir.loops.depths+0x6b0>
    48d0:      	str	x22, [sp, #0x198]
    48d4:      	b	0x422c <_stogir.loops.depths+0x3e4>
    48d8:      	str	x21, [sp, #0x180]
    48dc:      	str	x20, [sp, #0x148]
    48e0:      	mov	w20, w1
    48e4:      	str	x5, [sp, #0x160]
    48e8:      	str	x4, [sp, #0x168]
    48ec:      	str	x2, [sp, #0x150]
    48f0:      	mov	x21, x7
    48f4:      	str	w3, [sp, #0x158]
    48f8:      	str	x19, [sp, #0x140]
    48fc:      	mov	x19, x0
    4900:      	str	x26, [sp, #0x170]
    4904:      	mov	x26, x6
    4908:      	str	x27, [sp, #0x178]
    490c:      	mov	w27, w8
    4910:      	b	0x44d8 <_stogir.loops.depths+0x690>

0000000000004914 <_stogir.liveness.mark>:
    4914:      	sub	sp, sp, #0x110
    4918:      	str	x29, [sp]
    491c:      	str	x30, [sp, #0x8]
    4920:      	mov	x29, sp
    4924:      	str	x19, [sp, #0xc0]
    4928:      	str	x20, [sp, #0xc8]
    492c:      	str	x21, [sp, #0xd0]
    4930:      	str	x22, [sp, #0xd8]
    4934:      	str	x23, [sp, #0xe0]
    4938:      	str	x24, [sp, #0xe8]
    493c:      	str	x25, [sp, #0xf0]
    4940:      	str	x26, [sp, #0xf8]
    4944:      	str	x27, [sp, #0x100]
    4948:      	str	x28, [sp, #0x108]
    494c:      	add	x19, x0, #0x78
    4950:      	add	x16, sp, #0x10
    4954:      	orr	x20, x16, xzr
    4958:      	add	x16, sp, #0x40
    495c:      	orr	x21, x16, xzr
    4960:      	ldr	x4, [x3]
    4964:      	ldr	x5, [x3, #0x8]
    4968:      	add	x16, sp, #0x10
    496c:      	movz	x17, #0x0, lsl #48
    4970:      	str	x17, [x16]
    4974:      	add	x16, sp, #0x10
    4978:      	movz	x17, #0x0, lsl #48
    497c:      	str	x17, [x16, #0x8]
    4980:      	add	x16, sp, #0x10
    4984:      	movz	x17, #0x0, lsl #48
    4988:      	str	x17, [x16, #0x10]
    498c:      	add	x16, sp, #0x10
    4990:      	str	x4, [x16, #0x18]
    4994:      	add	x16, sp, #0x10
    4998:      	str	x5, [x16, #0x20]
    499c:      	mov	x22, x8
    49a0:      	add	x8, sp, #0x70
    49a4:      	mov	x23, x0
    49a8:      	mov	x0, x3
    49ac:      	mov	x24, x1
    49b0:      	mov	x25, x2
    49b4:      	bl	0x49b4 <_stogir.liveness.mark+0xa0>
		00000000000049b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    49b8:      	add	x16, sp, #0x70
    49bc:      	ldr	x0, [x16]
    49c0:      	add	x16, sp, #0x40
    49c4:      	str	x0, [x16]
    49c8:      	add	x16, sp, #0x70
    49cc:      	ldr	x0, [x16, #0x8]
    49d0:      	add	x16, sp, #0x40
    49d4:      	str	x0, [x16, #0x8]
    49d8:      	add	x16, sp, #0x70
    49dc:      	ldr	x0, [x16, #0x10]
    49e0:      	add	x16, sp, #0x40
    49e4:      	str	x0, [x16, #0x10]
    49e8:      	add	x16, sp, #0x70
    49ec:      	ldr	x0, [x16, #0x18]
    49f0:      	add	x16, sp, #0x40
    49f4:      	str	x0, [x16, #0x18]
    49f8:      	add	x16, sp, #0x70
    49fc:      	ldr	x0, [x16, #0x20]
    4a00:      	add	x16, sp, #0x40
    4a04:      	str	x0, [x16, #0x20]
    4a08:      	ldr	x0, [x23, #0x8]
    4a0c:      	mov	x1, x0
    4a10:      	mov	x0, x20
    4a14:      	bl	0x4a14 <_stogir.liveness.mark+0x100>
		0000000000004a14:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool
    4a18:      	movz	x20, #0x0, lsl #48
    4a1c:      	cmp	x20, x25
    4a20:      	b.ge	0x4a44 <_stogir.liveness.mark+0x130>
    4a24:      	add	x0, x20, #0x1
    4a28:      	add	x1, x24, x20, lsl #2
    4a2c:      	ldr	w1, [x1]
    4a30:      	movn	w17, #0x0, lsl #16
    4a34:      	and	w26, w1, w17
    4a38:      	mov	x20, x0
    4a3c:      	mov	w0, #0x1                ; =1
    4a40:      	b	0x4a4c <_stogir.liveness.mark+0x138>
    4a44:      	movz	w0, #0x0, lsl #16
    4a48:      	movz	w26, #0x0, lsl #16
    4a4c:      	ubfx	x0, x0, #0, #32
    4a50:      	lsr	x16, x0, #0
    4a54:      	cmp	x16, #0x1
    4a58:      	b.eq	0x4a74 <_stogir.liveness.mark+0x160>
    4a5c:      	b.lo	0x4a64 <_stogir.liveness.mark+0x150>
    4a60:      	b	0x4a78 <_stogir.liveness.mark+0x164>
    4a64:      	cmp	x16, #0x0
    4a68:      	b.eq	0x4a70 <_stogir.liveness.mark+0x15c>
    4a6c:      	b	0x4a78 <_stogir.liveness.mark+0x164>
    4a70:      	b	0x4b08 <_stogir.liveness.mark+0x1f4>
    4a74:      	b	0x4a7c <_stogir.liveness.mark+0x168>
    4a78:      	b	0x4e98 <_stogir.liveness.mark+0x584>
    4a7c:      	sxtw	x0, w26
    4a80:      	cmp	x0, #0x0
    4a84:      	b.le	0x4a1c <_stogir.liveness.mark+0x108>
    4a88:      	ldr	x1, [x23, #0x8]
    4a8c:      	cmp	x0, x1
    4a90:      	b.ge	0x4a1c <_stogir.liveness.mark+0x108>
    4a94:      	ldr	x1, [x19, #0x8]
    4a98:      	cmp	x0, x1
    4a9c:      	b.ge	0x4a1c <_stogir.liveness.mark+0x108>
    4aa0:      	ldr	x1, [x23, #0x78]
    4aa4:      	add	x1, x1, x0, lsl #2
    4aa8:      	ldr	w1, [x1]
    4aac:      	sxtw	x1, w1
    4ab0:      	cmp	x1, #0x0
    4ab4:      	b.lt	0x4a1c <_stogir.liveness.mark+0x108>
    4ab8:      	add	x16, sp, #0x10
    4abc:      	ldr	x1, [x16]
    4ac0:      	add	x2, x1, x0
    4ac4:      	ldrb	w2, [x2]
    4ac8:      	cmp	x2, #0x0
    4acc:      	b.ne	0x4a1c <_stogir.liveness.mark+0x108>
    4ad0:      	add	x0, x1, x0
    4ad4:      	mov	w17, #0x1               ; =1
    4ad8:      	strb	w17, [x0]
    4adc:      	add	x16, sp, #0x40
    4ae0:      	ldr	x0, [x16, #0x8]
    4ae4:      	orr	x27, x0, xzr
    4ae8:      	add	x16, sp, #0x40
    4aec:      	ldr	x0, [x16, #0x10]
    4af0:      	cmp	x27, x0
    4af4:      	b.lt	0x4e78 <_stogir.liveness.mark+0x564>
    4af8:      	cmp	x0, #0x0
    4afc:      	b.ne	0x4e68 <_stogir.liveness.mark+0x554>
    4b00:      	mov	x0, #0x2                ; =2
    4b04:      	b	0x4e6c <_stogir.liveness.mark+0x558>
    4b08:      	add	x19, x23, #0x78
    4b0c:      	movz	x20, #0x0, lsl #48
    4b10:      	b	0x4d44 <_stogir.liveness.mark+0x430>
    4b14:      	movz	w3, #0x0, lsl #16
    4b18:      	movz	w2, #0x0, lsl #16
    4b1c:      	b	0x4cb4 <_stogir.liveness.mark+0x3a0>
    4b20:      	sub	w2, w2, #0x1
    4b24:      	lsl	w2, w2, #2
    4b28:      	ubfx	x2, x2, #0, #32
    4b2c:      	lsr	x2, x4, x2
    4b30:      	and	w2, w2, #0xf
    4b34:      	b	0x4bd8 <_stogir.liveness.mark+0x2c4>
    4b38:      	lsl	x4, x4, #1
    4b3c:      	str	x0, [sp, #0xa0]
    4b40:      	mov	x0, x21
    4b44:      	str	x19, [sp, #0xa8]
    4b48:      	mov	x19, x1
    4b4c:      	mov	x1, x4
    4b50:      	str	x21, [sp, #0xb0]
    4b54:      	mov	w21, w2
    4b58:      	str	x23, [sp, #0xb8]
    4b5c:      	mov	x23, x3
    4b60:      	bl	0x4b60 <_stogir.liveness.mark+0x24c>
		0000000000004b60:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4b64:      	add	x0, x23, #0x1
    4b68:      	add	x16, sp, #0x40
    4b6c:      	ldr	x1, [x16]
    4b70:      	add	x1, x1, x23, lsl #2
    4b74:      	str	w21, [x1]
    4b78:      	add	x16, sp, #0x40
    4b7c:      	str	x0, [x16, #0x8]
    4b80:      	add	x0, x19, #0x1
    4b84:      	sxtw	x19, w0
    4b88:      	ldr	x23, [sp, #0xb8]
    4b8c:      	ldr	x21, [sp, #0xb0]
    4b90:      	ldr	x0, [sp, #0xa0]
    4b94:      	mov	x1, x19
    4b98:      	ldr	x19, [sp, #0xa8]
    4b9c:      	cmp	x1, x0
    4ba0:      	b.gt	0x4ea0 <_stogir.liveness.mark+0x58c>
    4ba4:      	orr	w2, w1, wzr
    4ba8:      	sxtw	x3, w2
    4bac:      	uxtb	w16, w27
    4bb0:      	cmp	w16, wzr
    4bb4:      	b.eq	0x4bdc <_stogir.liveness.mark+0x2c8>
    4bb8:      	ldr	w4, [x28]
    4bbc:      	cmp	x3, #0x0
    4bc0:      	b.le	0x4bd4 <_stogir.liveness.mark+0x2c0>
    4bc4:      	cmp	x3, #0x4
    4bc8:      	b.le	0x4b20 <_stogir.liveness.mark+0x20c>
    4bcc:      	mov	w2, #0x4                ; =4
    4bd0:      	b	0x4b24 <_stogir.liveness.mark+0x210>
    4bd4:      	movz	w2, #0x0, lsl #16
    4bd8:      	b	0x4be0 <_stogir.liveness.mark+0x2cc>
    4bdc:      	movz	w2, #0x0, lsl #16
    4be0:      	ubfx	x2, x2, #0, #32
    4be4:      	cmp	x2, #0xf
    4be8:      	b.hs	0x4eb0 <_stogir.liveness.mark+0x59c>
    4bec:      	mov	x16, #0x1               ; =1
    4bf0:      	lsl	x2, x16, x2
    4bf4:      	mov	w17, #0x5e1c            ; =24092
    4bf8:      	and	w2, w2, w17
    4bfc:      	ubfx	x2, x2, #0, #32
    4c00:      	cmp	x2, #0x0
    4c04:      	b.eq	0x4ec8 <_stogir.liveness.mark+0x5b4>
    4c08:      	uxtb	w16, w26
    4c0c:      	cmp	w16, wzr
    4c10:      	b.ne	0x4cac <_stogir.liveness.mark+0x398>
    4c14:      	ldr	x2, [x23, #0x8]
    4c18:      	cmp	x24, x2
    4c1c:      	b.ge	0x4cac <_stogir.liveness.mark+0x398>
    4c20:      	ldr	x2, [x19, #0x8]
    4c24:      	cmp	x24, x2
    4c28:      	b.ge	0x4cac <_stogir.liveness.mark+0x398>
    4c2c:      	ldr	x2, [x23, #0x78]
    4c30:      	add	x2, x25, x2
    4c34:      	ldr	w2, [x2]
    4c38:      	sxtw	x2, w2
    4c3c:      	cmp	x2, #0x0
    4c40:      	b.lt	0x4cac <_stogir.liveness.mark+0x398>
    4c44:      	cmp	x3, #0x1
    4c48:      	b.lt	0x4b14 <_stogir.liveness.mark+0x200>
    4c4c:      	ldr	x2, [x23, #0x78]
    4c50:      	add	x2, x25, x2
    4c54:      	ldr	w2, [x2]
    4c58:      	sxtw	x2, w2
    4c5c:      	cmp	x3, x2
    4c60:      	b.gt	0x4b14 <_stogir.liveness.mark+0x200>
    4c64:      	ldr	x2, [x23]
    4c68:      	asr	x16, x3, #63
    4c6c:      	lsr	x16, x16, #62
    4c70:      	add	x4, x3, x16
    4c74:      	asr	x4, x4, #2
    4c78:      	asr	x16, x3, #63
    4c7c:      	lsr	x16, x16, #62
    4c80:      	add	x3, x3, x16
    4c84:      	and	x3, x3, #0x3
    4c88:      	sub	x3, x3, x16
    4c8c:      	add	x4, x4, x24
    4c90:      	add	x2, x2, x4, lsl #4
    4c94:      	add	x2, x2, x3, lsl #2
    4c98:      	ldr	w2, [x2]
    4c9c:      	movn	w17, #0x0, lsl #16
    4ca0:      	and	w2, w2, w17
    4ca4:      	mov	w3, #0x1                ; =1
    4ca8:      	b	0x4b1c <_stogir.liveness.mark+0x208>
    4cac:      	movz	w3, #0x0, lsl #16
    4cb0:      	movz	w2, #0x0, lsl #16
    4cb4:      	ubfx	x3, x3, #0, #32
    4cb8:      	lsr	x16, x3, #0
    4cbc:      	cmp	x16, #0x1
    4cc0:      	b.eq	0x4cf0 <_stogir.liveness.mark+0x3dc>
    4cc4:      	b.lo	0x4ccc <_stogir.liveness.mark+0x3b8>
    4cc8:      	b	0x4cf4 <_stogir.liveness.mark+0x3e0>
    4ccc:      	cmp	x16, #0x0
    4cd0:      	b.eq	0x4cd8 <_stogir.liveness.mark+0x3c4>
    4cd4:      	b	0x4cf4 <_stogir.liveness.mark+0x3e0>
    4cd8:      	str	x23, [sp, #0xb8]
    4cdc:      	str	x21, [sp, #0xb0]
    4ce0:      	str	x0, [sp, #0xa0]
    4ce4:      	str	x19, [sp, #0xa8]
    4ce8:      	mov	x19, x1
    4cec:      	b	0x4b80 <_stogir.liveness.mark+0x26c>
    4cf0:      	b	0x4cf8 <_stogir.liveness.mark+0x3e4>
    4cf4:      	b	0x4e60 <_stogir.liveness.mark+0x54c>
    4cf8:      	sxtw	x3, w2
    4cfc:      	cmp	x3, #0x0
    4d00:      	b.le	0x4ee0 <_stogir.liveness.mark+0x5cc>
    4d04:      	add	x16, sp, #0x10
    4d08:      	ldr	x4, [x16]
    4d0c:      	add	x3, x3, x4
    4d10:      	ldrb	w4, [x3]
    4d14:      	cmp	x4, #0x0
    4d18:      	b.eq	0x4db4 <_stogir.liveness.mark+0x4a0>
    4d1c:      	str	x23, [sp, #0xb8]
    4d20:      	str	x21, [sp, #0xb0]
    4d24:      	str	x0, [sp, #0xa0]
    4d28:      	str	x19, [sp, #0xa8]
    4d2c:      	mov	x19, x1
    4d30:      	b	0x4b80 <_stogir.liveness.mark+0x26c>
    4d34:      	add	x20, x20, #0x1
    4d38:      	ldr	x23, [sp, #0xb8]
    4d3c:      	ldr	x21, [sp, #0xb0]
    4d40:      	ldr	x19, [sp, #0xa8]
    4d44:      	add	x16, sp, #0x40
    4d48:      	ldr	x0, [x16, #0x8]
    4d4c:      	cmp	x20, x0
    4d50:      	b.ge	0x4ef8 <_stogir.liveness.mark+0x5e4>
    4d54:      	add	x16, sp, #0x40
    4d58:      	ldr	x0, [x16]
    4d5c:      	add	x0, x0, x20, lsl #2
    4d60:      	ldr	w0, [x0]
    4d64:      	sxtw	x24, w0
    4d68:      	ldr	x0, [x23]
    4d6c:      	lsl	x25, x24, #2
    4d70:      	cmp	x24, #0x0
    4d74:      	cset	w26, le
    4d78:      	add	x0, x0, x24, lsl #4
    4d7c:      	ldr	x0, [x0]
    4d80:      	ldr	x1, [x23, #0x78]
    4d84:      	uxtb	w0, w0
    4d88:      	add	x1, x1, x24, lsl #2
    4d8c:      	cmp	x0, #0x83
    4d90:      	cset	w27, lt
    4d94:      	adrp	x16, 0x4000 <_stogir.loops.depths+0x1b8>
		0000000000004d94:  ARM64_RELOC_PAGE21	l_stogir.419
    4d98:      	ldr	x16, [x16]
		0000000000004d98:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    4d9c:      	add	x0, x16, x0, lsl #2
    4da0:      	ldr	w1, [x1]
    4da4:      	orr	x28, x0, xzr
    4da8:      	sxtw	x0, w1
    4dac:      	mov	x1, #0x1                ; =1
    4db0:      	b	0x4b9c <_stogir.liveness.mark+0x288>
    4db4:      	mov	w17, #0x1               ; =1
    4db8:      	strb	w17, [x3]
    4dbc:      	add	x16, sp, #0x40
    4dc0:      	ldr	x3, [x16, #0x8]
    4dc4:      	add	x16, sp, #0x40
    4dc8:      	ldr	x4, [x16, #0x10]
    4dcc:      	cmp	x3, x4
    4dd0:      	b.lt	0x4f00 <_stogir.liveness.mark+0x5ec>
    4dd4:      	cmp	x4, #0x0
    4dd8:      	b.ne	0x4b38 <_stogir.liveness.mark+0x224>
    4ddc:      	mov	x4, #0x2                ; =2
    4de0:      	b	0x4b3c <_stogir.liveness.mark+0x228>
    4de4:      	ldr	x0, [sp, #0xb0]
    4de8:      	bl	0x4de8 <_stogir.liveness.mark+0x4d4>
		0000000000004de8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    4dec:      	add	x16, sp, #0x10
    4df0:      	ldr	x0, [x16]
    4df4:      	add	x16, sp, #0x10
    4df8:      	ldr	x1, [x16, #0x8]
    4dfc:      	add	x16, sp, #0x10
    4e00:      	ldr	x2, [x16, #0x10]
    4e04:      	add	x16, sp, #0x10
    4e08:      	ldr	x3, [x16, #0x18]
    4e0c:      	add	x16, sp, #0x10
    4e10:      	ldr	x4, [x16, #0x20]
    4e14:      	str	x0, [x22]
    4e18:      	str	x1, [x22, #0x8]
    4e1c:      	str	x2, [x22, #0x10]
    4e20:      	str	x3, [x22, #0x18]
    4e24:      	str	x4, [x22, #0x20]
    4e28:      	ldr	x19, [sp, #0xc0]
    4e2c:      	ldr	x20, [sp, #0xc8]
    4e30:      	ldr	x21, [sp, #0xd0]
    4e34:      	ldr	x22, [sp, #0xd8]
    4e38:      	ldr	x23, [sp, #0xe0]
    4e3c:      	ldr	x24, [sp, #0xe8]
    4e40:      	ldr	x25, [sp, #0xf0]
    4e44:      	ldr	x26, [sp, #0xf8]
    4e48:      	ldr	x27, [sp, #0x100]
    4e4c:      	ldr	x28, [sp, #0x108]
    4e50:      	ldr	x29, [sp]
    4e54:      	ldr	x30, [sp, #0x8]
    4e58:      	add	sp, sp, #0x110
    4e5c:      	ret
    4e60:      	brk	#0
    4e64:      	b	0x4e60 <_stogir.liveness.mark+0x54c>
    4e68:      	lsl	x0, x0, #1
    4e6c:      	mov	x1, x0
    4e70:      	mov	x0, x21
    4e74:      	bl	0x4e74 <_stogir.liveness.mark+0x560>
		0000000000004e74:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4e78:      	add	x0, x27, #0x1
    4e7c:      	add	x16, sp, #0x40
    4e80:      	ldr	x1, [x16]
    4e84:      	add	x1, x1, x27, lsl #2
    4e88:      	str	w26, [x1]
    4e8c:      	add	x16, sp, #0x40
    4e90:      	str	x0, [x16, #0x8]
    4e94:      	b	0x4a1c <_stogir.liveness.mark+0x108>
    4e98:      	brk	#0
    4e9c:      	b	0x4e98 <_stogir.liveness.mark+0x584>
    4ea0:      	str	x23, [sp, #0xb8]
    4ea4:      	str	x21, [sp, #0xb0]
    4ea8:      	str	x19, [sp, #0xa8]
    4eac:      	b	0x4d34 <_stogir.liveness.mark+0x420>
    4eb0:      	str	x23, [sp, #0xb8]
    4eb4:      	str	x21, [sp, #0xb0]
    4eb8:      	str	x0, [sp, #0xa0]
    4ebc:      	str	x19, [sp, #0xa8]
    4ec0:      	mov	x19, x1
    4ec4:      	b	0x4b80 <_stogir.liveness.mark+0x26c>
    4ec8:      	str	x23, [sp, #0xb8]
    4ecc:      	str	x21, [sp, #0xb0]
    4ed0:      	str	x0, [sp, #0xa0]
    4ed4:      	str	x19, [sp, #0xa8]
    4ed8:      	mov	x19, x1
    4edc:      	b	0x4b80 <_stogir.liveness.mark+0x26c>
    4ee0:      	str	x23, [sp, #0xb8]
    4ee4:      	str	x21, [sp, #0xb0]
    4ee8:      	str	x0, [sp, #0xa0]
    4eec:      	str	x19, [sp, #0xa8]
    4ef0:      	mov	x19, x1
    4ef4:      	b	0x4b80 <_stogir.liveness.mark+0x26c>
    4ef8:      	str	x21, [sp, #0xb0]
    4efc:      	b	0x4de4 <_stogir.liveness.mark+0x4d0>
    4f00:      	str	x23, [sp, #0xb8]
    4f04:      	str	x21, [sp, #0xb0]
    4f08:      	str	x0, [sp, #0xa0]
    4f0c:      	mov	x23, x3
    4f10:      	mov	w21, w2
    4f14:      	str	x19, [sp, #0xa8]
    4f18:      	mov	x19, x1
    4f1c:      	b	0x4b64 <_stogir.liveness.mark+0x250>

0000000000004f20 <_stogir.uses.build>:
    4f20:      	sub	sp, sp, #0xd0
    4f24:      	str	x29, [sp]
    4f28:      	str	x30, [sp, #0x8]
    4f2c:      	mov	x29, sp
    4f30:      	str	x19, [sp, #0x90]
    4f34:      	str	x20, [sp, #0x98]
    4f38:      	str	x21, [sp, #0xa0]
    4f3c:      	str	x22, [sp, #0xa8]
    4f40:      	str	x23, [sp, #0xb0]
    4f44:      	str	x24, [sp, #0xb8]
    4f48:      	str	x25, [sp, #0xc0]
    4f4c:      	str	x26, [sp, #0xc8]
    4f50:      	add	x16, sp, #0x10
    4f54:      	orr	x19, x16, xzr
    4f58:      	ldr	x2, [x1]
    4f5c:      	ldr	x3, [x1, #0x8]
    4f60:      	add	x16, sp, #0x10
    4f64:      	movz	x17, #0x0, lsl #48
    4f68:      	str	x17, [x16]
    4f6c:      	add	x16, sp, #0x10
    4f70:      	movz	x17, #0x0, lsl #48
    4f74:      	str	x17, [x16, #0x8]
    4f78:      	add	x16, sp, #0x10
    4f7c:      	movz	x17, #0x0, lsl #48
    4f80:      	str	x17, [x16, #0x10]
    4f84:      	add	x16, sp, #0x10
    4f88:      	str	x2, [x16, #0x18]
    4f8c:      	add	x16, sp, #0x10
    4f90:      	str	x3, [x16, #0x20]
    4f94:      	add	x16, sp, #0x10
    4f98:      	movz	x17, #0x0, lsl #48
    4f9c:      	str	x17, [x16, #0x28]
    4fa0:      	add	x16, sp, #0x10
    4fa4:      	movz	x17, #0x0, lsl #48
    4fa8:      	str	x17, [x16, #0x30]
    4fac:      	add	x16, sp, #0x10
    4fb0:      	movz	x17, #0x0, lsl #48
    4fb4:      	str	x17, [x16, #0x38]
    4fb8:      	add	x16, sp, #0x10
    4fbc:      	str	x2, [x16, #0x40]
    4fc0:      	add	x16, sp, #0x10
    4fc4:      	str	x3, [x16, #0x48]
    4fc8:      	ldr	x2, [x1]
    4fcc:      	ldr	x1, [x1, #0x8]
    4fd0:      	add	x16, sp, #0x60
    4fd4:      	movz	x17, #0x0, lsl #48
    4fd8:      	str	x17, [x16]
    4fdc:      	add	x16, sp, #0x60
    4fe0:      	movz	x17, #0x0, lsl #48
    4fe4:      	str	x17, [x16, #0x8]
    4fe8:      	add	x16, sp, #0x60
    4fec:      	movz	x17, #0x0, lsl #48
    4ff0:      	str	x17, [x16, #0x10]
    4ff4:      	add	x16, sp, #0x60
    4ff8:      	str	x2, [x16, #0x18]
    4ffc:      	add	x16, sp, #0x60
    5000:      	str	x1, [x16, #0x20]
    5004:      	ldr	x1, [x0, #0x8]
    5008:      	orr	x20, x1, xzr
    500c:      	cmp	x20, #0x0
    5010:      	b.le	0x5430 <_stogir.uses.build+0x510>
    5014:      	cmp	x20, #0x0
    5018:      	b.ge	0x5024 <_stogir.uses.build+0x104>
    501c:      	movz	x1, #0x0, lsl #48
    5020:      	b	0x5028 <_stogir.uses.build+0x108>
    5024:      	mov	x1, x20
    5028:      	mov	x21, x8
    502c:      	mov	x22, x0
    5030:      	mov	x0, x19
    5034:      	bl	0x5034 <_stogir.uses.build+0x114>
		0000000000005034:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range
    5038:      	add	x16, sp, #0x60
    503c:      	orr	x23, x16, xzr
    5040:      	lsl	x0, x20, #4
    5044:      	add	x16, sp, #0x10
    5048:      	ldr	x1, [x16]
    504c:      	mov	x2, x0
    5050:      	mov	x0, x1
    5054:      	movz	x1, #0x0, lsl #48
    5058:      	bl	0x5058 <_stogir.uses.build+0x138>
		0000000000005058:  ARM64_RELOC_BRANCH26	_memset
    505c:      	add	x16, sp, #0x10
    5060:      	str	x20, [x16, #0x8]
    5064:      	ldr	x0, [x22, #0x8]
    5068:      	orr	x20, x0, xzr
    506c:      	add	x16, sp, #0x60
    5070:      	ldr	x0, [x16, #0x8]
    5074:      	orr	x24, x0, xzr
    5078:      	add	x16, sp, #0x60
    507c:      	ldr	x0, [x16, #0x10]
    5080:      	add	x25, x24, x20
    5084:      	cmp	x25, x0
    5088:      	b.le	0x50bc <_stogir.uses.build+0x19c>
    508c:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    5090:      	cmp	x0, x17
    5094:      	b.gt	0x50a0 <_stogir.uses.build+0x180>
    5098:      	lsl	x0, x0, #1
    509c:      	b	0x50a4 <_stogir.uses.build+0x184>
    50a0:      	mov	x0, x25
    50a4:      	cmp	x0, x25
    50a8:      	b.gt	0x50b0 <_stogir.uses.build+0x190>
    50ac:      	mov	x0, x25
    50b0:      	mov	x1, x0
    50b4:      	mov	x0, x23
    50b8:      	bl	0x50b8 <_stogir.uses.build+0x198>
		00000000000050b8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    50bc:      	lsl	x0, x20, #3
    50c0:      	add	x16, sp, #0x60
    50c4:      	ldr	x1, [x16]
    50c8:      	add	x1, x1, x24, lsl #3
    50cc:      	mov	x2, x0
    50d0:      	mov	x0, x1
    50d4:      	movz	x1, #0x0, lsl #48
    50d8:      	bl	0x50d8 <_stogir.uses.build+0x1b8>
		00000000000050d8:  ARM64_RELOC_BRANCH26	_memset
    50dc:      	add	x16, sp, #0x60
    50e0:      	str	x25, [x16, #0x8]
    50e4:      	mov	x0, #0x1                ; =1
    50e8:      	b	0x51e8 <_stogir.uses.build+0x2c8>
    50ec:      	sub	w4, w4, #0x1
    50f0:      	lsl	w4, w4, #2
    50f4:      	ubfx	x4, x4, #0, #32
    50f8:      	lsr	x4, x1, x4
    50fc:      	and	w4, w4, #0xf
    5100:      	b	0x510c <_stogir.uses.build+0x1ec>
    5104:      	nop
    5108:      	movz	w4, #0x0, lsl #16
    510c:      	ubfx	x4, x4, #0, #32
    5110:      	cmp	x4, #0xf
    5114:      	b.hs	0x51a0 <_stogir.uses.build+0x280>
    5118:      	mov	x16, #0x1               ; =1
    511c:      	lsl	x4, x16, x4
    5120:      	mov	w17, #0x5e1c            ; =24092
    5124:      	and	w4, w4, w17
    5128:      	ubfx	x4, x4, #0, #32
    512c:      	cmp	x4, #0x0
    5130:      	b.eq	0x51a0 <_stogir.uses.build+0x280>
    5134:      	ldr	x4, [x22]
    5138:      	asr	x16, x5, #63
    513c:      	lsr	x16, x16, #62
    5140:      	add	x6, x5, x16
    5144:      	asr	x6, x6, #2
    5148:      	asr	x16, x5, #63
    514c:      	lsr	x16, x16, #62
    5150:      	add	x5, x5, x16
    5154:      	and	x5, x5, #0x3
    5158:      	sub	x5, x5, x16
    515c:      	add	x6, x6, x0
    5160:      	add	x4, x4, x6, lsl #4
    5164:      	add	x4, x4, x5, lsl #2
    5168:      	ldr	w4, [x4]
    516c:      	sxtw	x4, w4
    5170:      	cmp	x4, #0x0
    5174:      	b.le	0x51a0 <_stogir.uses.build+0x280>
    5178:      	add	x16, sp, #0x10
    517c:      	ldr	x5, [x16]
    5180:      	orr	x6, x5, xzr
    5184:      	add	x6, x6, x4, lsl #4
    5188:      	add	x4, x5, x4, lsl #4
    518c:      	ldr	x5, [x6]
    5190:      	ldr	x6, [x6, #0x8]
    5194:      	add	x6, x6, #0x1
    5198:      	str	x5, [x4]
    519c:      	str	x6, [x4, #0x8]
    51a0:      	add	x3, x3, #0x1
    51a4:      	sxtw	x3, w3
    51a8:      	cmp	x3, x2
    51ac:      	b.gt	0x51d0 <_stogir.uses.build+0x2b0>
    51b0:      	orr	w4, w3, wzr
    51b4:      	sxtw	x5, w4
    51b8:      	cmp	x5, #0x0
    51bc:      	b.le	0x5108 <_stogir.uses.build+0x1e8>
    51c0:      	cmp	x5, #0x4
    51c4:      	b.le	0x50ec <_stogir.uses.build+0x1cc>
    51c8:      	mov	w4, #0x4                ; =4
    51cc:      	b	0x50f0 <_stogir.uses.build+0x1d0>
    51d0:      	add	x1, x2, #0x4
    51d4:      	asr	x16, x1, #63
    51d8:      	lsr	x16, x16, #62
    51dc:      	add	x1, x1, x16
    51e0:      	asr	x1, x1, #2
    51e4:      	add	x0, x1, x0
    51e8:      	ldr	x1, [x22, #0x8]
    51ec:      	cmp	x0, x1
    51f0:      	b.ge	0x522c <_stogir.uses.build+0x30c>
    51f4:      	ldr	x1, [x22]
    51f8:      	add	x1, x1, x0, lsl #4
    51fc:      	ldr	x1, [x1]
    5200:      	ldr	x2, [x22, #0x78]
    5204:      	uxtb	w1, w1
    5208:      	add	x2, x2, x0, lsl #2
    520c:      	adrp	x16, 0x5000 <_stogir.uses.build+0xe0>
		000000000000520c:  ARM64_RELOC_PAGE21	l_stogir.420
    5210:      	ldr	x16, [x16]
		0000000000005210:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    5214:      	add	x1, x16, x1, lsl #2
    5218:      	ldr	w2, [x2]
    521c:      	sxtw	x2, w2
    5220:      	ldr	w1, [x1]
    5224:      	mov	x3, #0x1                ; =1
    5228:      	b	0x51a8 <_stogir.uses.build+0x288>
    522c:      	movn	x0, #0x0, lsl #48
    5230:      	movz	x20, #0x0, lsl #48
    5234:      	b	0x5270 <_stogir.uses.build+0x350>
    5238:      	add	x16, sp, #0x10
    523c:      	ldr	x1, [x16]
    5240:      	orr	x2, x1, xzr
    5244:      	add	x2, x2, x0, lsl #4
    5248:      	add	x1, x1, x0, lsl #4
    524c:      	ldr	x2, [x2, #0x8]
    5250:      	add	x3, x2, x20
    5254:      	str	x20, [x1]
    5258:      	str	x2, [x1, #0x8]
    525c:      	add	x16, sp, #0x60
    5260:      	ldr	x1, [x16]
    5264:      	add	x1, x1, x0, lsl #3
    5268:      	str	x20, [x1]
    526c:      	mov	x20, x3
    5270:      	add	x16, sp, #0x10
    5274:      	ldr	x1, [x16, #0x8]
    5278:      	add	x0, x0, #0x1
    527c:      	cmp	x0, x1
    5280:      	b.lt	0x5238 <_stogir.uses.build+0x318>
    5284:      	add	x24, x19, #0x28
    5288:      	ldr	x0, [x24, #0x8]
    528c:      	orr	x25, x0, xzr
    5290:      	ldr	x0, [x24, #0x10]
    5294:      	add	x26, x25, x20
    5298:      	cmp	x26, x0
    529c:      	b.le	0x52d0 <_stogir.uses.build+0x3b0>
    52a0:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    52a4:      	cmp	x0, x17
    52a8:      	b.gt	0x52b4 <_stogir.uses.build+0x394>
    52ac:      	lsl	x0, x0, #1
    52b0:      	b	0x52b8 <_stogir.uses.build+0x398>
    52b4:      	mov	x0, x26
    52b8:      	cmp	x0, x26
    52bc:      	b.gt	0x52c4 <_stogir.uses.build+0x3a4>
    52c0:      	mov	x0, x26
    52c4:      	mov	x1, x0
    52c8:      	mov	x0, x24
    52cc:      	bl	0x52cc <_stogir.uses.build+0x3ac>
		00000000000052cc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use
    52d0:      	lsl	x0, x20, #3
    52d4:      	add	x16, sp, #0x10
    52d8:      	ldr	x1, [x16, #0x28]
    52dc:      	add	x1, x1, x25, lsl #3
    52e0:      	mov	x2, x0
    52e4:      	mov	x0, x1
    52e8:      	movz	x1, #0x0, lsl #48
    52ec:      	bl	0x52ec <_stogir.uses.build+0x3cc>
		00000000000052ec:  ARM64_RELOC_BRANCH26	_memset
    52f0:      	str	x26, [x24, #0x8]
    52f4:      	mov	x0, x22
    52f8:      	mov	x1, x19
    52fc:      	mov	x2, x23
    5300:      	bl	0x5300 <_stogir.uses.build+0x3e0>
		0000000000005300:  ARM64_RELOC_BRANCH26	_stogir.uses.scan!__constfalse
    5304:      	b	0x5314 <_stogir.uses.build+0x3f4>
    5308:      	sub	x0, x0, #0x1
    530c:      	add	x16, sp, #0x60
    5310:      	str	x0, [x16, #0x8]
    5314:      	add	x16, sp, #0x60
    5318:      	ldr	x0, [x16, #0x8]
    531c:      	cmp	x0, #0x0
    5320:      	b.ne	0x5308 <_stogir.uses.build+0x3e8>
    5324:      	add	x16, sp, #0x60
    5328:      	ldr	x0, [x16, #0x10]
    532c:      	cmp	x0, #0x0
    5330:      	b.le	0x5364 <_stogir.uses.build+0x444>
    5334:      	add	x1, x23, #0x18
    5338:      	add	x16, sp, #0x60
    533c:      	ldr	x2, [x16]
    5340:      	fmov	d31, x0
    5344:      	mov	x0, x1
    5348:      	mov	x1, x2
    534c:      	fmov	x2, d31
    5350:      	adrp	x3, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005350:  ARM64_RELOC_PAGE21	l_stogir.421
    5354:      	ldr	x3, [x3]
		0000000000005354:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    5358:      	mov	x4, #0x8                ; =8
    535c:      	mov	x5, #0x8                ; =8
    5360:      	bl	0x5360 <_stogir.uses.build+0x440>
		0000000000005360:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    5364:      	add	x16, sp, #0x60
    5368:      	movz	x17, #0x0, lsl #48
    536c:      	str	x17, [x16]
    5370:      	add	x16, sp, #0x60
    5374:      	movz	x17, #0x0, lsl #48
    5378:      	str	x17, [x16, #0x8]
    537c:      	add	x16, sp, #0x60
    5380:      	movz	x17, #0x0, lsl #48
    5384:      	str	x17, [x16, #0x10]
    5388:      	add	x16, sp, #0x10
    538c:      	ldr	x0, [x16]
    5390:      	add	x16, sp, #0x10
    5394:      	ldr	x1, [x16, #0x8]
    5398:      	add	x16, sp, #0x10
    539c:      	ldr	x2, [x16, #0x10]
    53a0:      	add	x16, sp, #0x10
    53a4:      	ldr	x3, [x16, #0x18]
    53a8:      	add	x16, sp, #0x10
    53ac:      	ldr	x4, [x16, #0x20]
    53b0:      	add	x16, sp, #0x10
    53b4:      	ldr	x5, [x16, #0x28]
    53b8:      	add	x16, sp, #0x10
    53bc:      	ldr	x6, [x16, #0x30]
    53c0:      	add	x16, sp, #0x10
    53c4:      	ldr	x7, [x16, #0x38]
    53c8:      	add	x16, sp, #0x10
    53cc:      	ldr	x8, [x16, #0x40]
    53d0:      	add	x16, sp, #0x10
    53d4:      	ldr	x9, [x16, #0x48]
    53d8:      	str	x0, [x21]
    53dc:      	str	x1, [x21, #0x8]
    53e0:      	str	x2, [x21, #0x10]
    53e4:      	str	x3, [x21, #0x18]
    53e8:      	str	x4, [x21, #0x20]
    53ec:      	str	x5, [x21, #0x28]
    53f0:      	str	x6, [x21, #0x30]
    53f4:      	str	x7, [x21, #0x38]
    53f8:      	str	x8, [x21, #0x40]
    53fc:      	str	x9, [x21, #0x48]
    5400:      	ldr	x19, [sp, #0x90]
    5404:      	ldr	x20, [sp, #0x98]
    5408:      	ldr	x21, [sp, #0xa0]
    540c:      	ldr	x22, [sp, #0xa8]
    5410:      	ldr	x23, [sp, #0xb0]
    5414:      	ldr	x24, [sp, #0xb8]
    5418:      	ldr	x25, [sp, #0xc0]
    541c:      	ldr	x26, [sp, #0xc8]
    5420:      	ldr	x29, [sp]
    5424:      	ldr	x30, [sp, #0x8]
    5428:      	add	sp, sp, #0xd0
    542c:      	ret
    5430:      	mov	x21, x8
    5434:      	mov	x22, x0
    5438:      	b	0x5038 <_stogir.uses.build+0x118>

000000000000543c <_inherent$coil.arraylist.ArrayList$new__i32>:
    543c:      	ldr	x1, [x0]
    5440:      	ldr	x0, [x0, #0x8]
    5444:      	movz	x17, #0x0, lsl #48
    5448:      	str	x17, [x8]
    544c:      	movz	x17, #0x0, lsl #48
    5450:      	str	x17, [x8, #0x8]
    5454:      	movz	x17, #0x0, lsl #48
    5458:      	str	x17, [x8, #0x10]
    545c:      	str	x1, [x8, #0x18]
    5460:      	str	x0, [x8, #0x20]
    5464:      	ret

0000000000005468 <_stogir.placement.pinned>:
    5468:      	sub	sp, sp, #0xc0
    546c:      	str	x29, [sp, #0x10]
    5470:      	str	x30, [sp, #0x18]
    5474:      	add	x29, sp, #0x10
    5478:      	str	x19, [sp, #0x68]
    547c:      	str	x20, [sp, #0x70]
    5480:      	str	x21, [sp, #0x78]
    5484:      	str	x22, [sp, #0x80]
    5488:      	str	x23, [sp, #0x88]
    548c:      	str	x24, [sp, #0x90]
    5490:      	str	x25, [sp, #0x98]
    5494:      	str	x26, [sp, #0xa0]
    5498:      	str	x27, [sp, #0xa8]
    549c:      	str	x28, [sp, #0xb0]
    54a0:      	add	x19, x1, #0x28
    54a4:      	add	x16, sp, #0x20
    54a8:      	orr	x20, x16, xzr
    54ac:      	ldr	x3, [x2]
    54b0:      	ldr	x2, [x2, #0x8]
    54b4:      	add	x16, sp, #0x20
    54b8:      	movz	x17, #0x0, lsl #48
    54bc:      	str	x17, [x16]
    54c0:      	add	x16, sp, #0x20
    54c4:      	movz	x17, #0x0, lsl #48
    54c8:      	str	x17, [x16, #0x8]
    54cc:      	add	x16, sp, #0x20
    54d0:      	movz	x17, #0x0, lsl #48
    54d4:      	str	x17, [x16, #0x10]
    54d8:      	add	x16, sp, #0x20
    54dc:      	str	x3, [x16, #0x18]
    54e0:      	add	x16, sp, #0x20
    54e4:      	str	x2, [x16, #0x20]
    54e8:      	movz	x21, #0x0, lsl #48
    54ec:      	b	0x5538 <_stogir.placement.pinned+0xd0>
    54f0:      	lsl	x2, x2, #1
    54f4:      	mov	x24, x8
    54f8:      	mov	x25, x0
    54fc:      	mov	x0, x20
    5500:      	mov	x26, x1
    5504:      	mov	x1, x2
    5508:      	bl	0x5508 <_stogir.placement.pinned+0xa0>
		0000000000005508:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    550c:      	add	x21, x21, #0x1
    5510:      	add	x0, x23, #0x1
    5514:      	add	x16, sp, #0x20
    5518:      	ldr	x1, [x16]
    551c:      	add	x1, x1, x23, lsl #2
    5520:      	str	w22, [x1]
    5524:      	add	x16, sp, #0x20
    5528:      	str	x0, [x16, #0x8]
    552c:      	mov	x8, x24
    5530:      	mov	x0, x25
    5534:      	mov	x1, x26
    5538:      	ldr	x2, [x19, #0x8]
    553c:      	cmp	x21, x2
    5540:      	b.ge	0x59d8 <_stogir.placement.pinned+0x570>
    5544:      	ldr	x2, [x1, #0x28]
    5548:      	add	x2, x2, x21, lsl #2
    554c:      	ldr	w22, [x2]
    5550:      	add	x16, sp, #0x20
    5554:      	ldr	x2, [x16, #0x8]
    5558:      	orr	x23, x2, xzr
    555c:      	add	x16, sp, #0x20
    5560:      	ldr	x2, [x16, #0x10]
    5564:      	cmp	x23, x2
    5568:      	b.lt	0x59e4 <_stogir.placement.pinned+0x57c>
    556c:      	cmp	x2, #0x0
    5570:      	b.ne	0x54f0 <_stogir.placement.pinned+0x88>
    5574:      	mov	x2, #0x2                ; =2
    5578:      	b	0x54f4 <_stogir.placement.pinned+0x8c>
    557c:      	add	x19, x25, #0x78
    5580:      	add	x21, x25, #0x78
    5584:      	add	x22, x25, #0x28
    5588:      	add	x23, x25, #0x50
    558c:      	mov	x26, #0x1               ; =1
    5590:      	adrp	x27, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005590:  ARM64_RELOC_PAGE21	l_stogir.422
    5594:      	ldr	x27, [x27]
		0000000000005594:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    5598:      	movz	x28, #0x0, lsl #48
    559c:      	b	0x55f4 <_stogir.placement.pinned+0x18c>
    55a0:      	adrp	x27, 0x5000 <_stogir.uses.build+0xe0>
		00000000000055a0:  ARM64_RELOC_PAGE21	l_stogir.423
    55a4:      	ldr	x27, [x27]
		00000000000055a4:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    55a8:      	mov	x28, #0x15              ; =21
    55ac:      	b	0x5698 <_stogir.placement.pinned+0x230>
    55b0:      	movz	w0, #0x0, lsl #16
    55b4:      	uxtb	w16, w0
    55b8:      	and	w0, w16, #0x20
    55bc:      	uxtb	w0, w0
    55c0:      	ubfx	x0, x0, #0, #8
    55c4:      	cmp	x0, #0x0
    55c8:      	b.ne	0x5640 <_stogir.placement.pinned+0x1d8>
    55cc:      	str	x24, [sp, #0x60]
    55d0:      	mov	w24, w1
    55d4:      	sxtw	x24, w24
    55d8:      	add	x0, x24, #0x4
    55dc:      	asr	x16, x0, #63
    55e0:      	lsr	x16, x16, #62
    55e4:      	add	x0, x0, x16
    55e8:      	asr	x0, x0, #2
    55ec:      	add	x26, x0, x26
    55f0:      	ldr	x24, [sp, #0x60]
    55f4:      	cmp	x28, #0x0
    55f8:      	b.ne	0x59f4 <_stogir.placement.pinned+0x58c>
    55fc:      	ldr	x0, [x25, #0x8]
    5600:      	cmp	x26, x0
    5604:      	b.ge	0x59fc <_stogir.placement.pinned+0x594>
    5608:      	ldr	x0, [x25]
    560c:      	add	x0, x0, x26, lsl #4
    5610:      	ldr	x0, [x0]
    5614:      	ldr	x1, [x25, #0x78]
    5618:      	uxtb	w0, w0
    561c:      	add	x1, x1, x26, lsl #2
    5620:      	ldr	w1, [x1]
    5624:      	cmp	x0, #0x83
    5628:      	b.ge	0x55b0 <_stogir.placement.pinned+0x148>
    562c:      	adrp	x17, 0x5000 <_stogir.uses.build+0xe0>
		000000000000562c:  ARM64_RELOC_PAGE21	l_stogir.424
    5630:      	ldr	x17, [x17]
		0000000000005630:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    5634:      	add	x0, x0, x17
    5638:      	ldrb	w0, [x0]
    563c:      	b	0x55b4 <_stogir.placement.pinned+0x14c>
    5640:      	orr	w0, w26, wzr
    5644:      	str	x24, [sp, #0x60]
    5648:      	mov	w24, w1
    564c:      	mov	w1, w0
    5650:      	mov	x0, x25
    5654:      	mov	x2, #0x1                ; =1
    5658:      	bl	0x5658 <_stogir.placement.pinned+0x1f0>
		0000000000005658:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    565c:      	ubfx	x0, x0, #0, #32
    5660:      	lsr	x16, x0, #0
    5664:      	cmp	x16, #0x1
    5668:      	b.eq	0x5684 <_stogir.placement.pinned+0x21c>
    566c:      	b.lo	0x5674 <_stogir.placement.pinned+0x20c>
    5670:      	b	0x5688 <_stogir.placement.pinned+0x220>
    5674:      	cmp	x16, #0x0
    5678:      	b.eq	0x5680 <_stogir.placement.pinned+0x218>
    567c:      	b	0x5688 <_stogir.placement.pinned+0x220>
    5680:      	b	0x568c <_stogir.placement.pinned+0x224>
    5684:      	b	0x569c <_stogir.placement.pinned+0x234>
    5688:      	b	0x59c8 <_stogir.placement.pinned+0x560>
    568c:      	adrp	x27, 0x5000 <_stogir.uses.build+0xe0>
		000000000000568c:  ARM64_RELOC_PAGE21	l_stogir.425
    5690:      	ldr	x27, [x27]
		0000000000005690:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    5694:      	mov	x28, #0x19              ; =25
    5698:      	b	0x55d4 <_stogir.placement.pinned+0x16c>
    569c:      	sxtw	x0, w1
    56a0:      	cmp	x0, #0x0
    56a4:      	b.le	0x55a0 <_stogir.placement.pinned+0x138>
    56a8:      	lsl	x2, x0, #2
    56ac:      	ldr	x3, [x25, #0x8]
    56b0:      	cmp	x0, x3
    56b4:      	b.ge	0x580c <_stogir.placement.pinned+0x3a4>
    56b8:      	ldr	x3, [x19, #0x8]
    56bc:      	cmp	x0, x3
    56c0:      	b.ge	0x5804 <_stogir.placement.pinned+0x39c>
    56c4:      	ldr	x3, [x25, #0x78]
    56c8:      	add	x3, x2, x3
    56cc:      	ldr	w3, [x3]
    56d0:      	sxtw	x3, w3
    56d4:      	cmp	x3, #0x0
    56d8:      	cset	w3, ge
    56dc:      	ubfx	x3, x3, #0, #8
    56e0:      	b	0x5808 <_stogir.placement.pinned+0x3a0>
    56e4:      	cmp	x28, #0x0
    56e8:      	b.ne	0x571c <_stogir.placement.pinned+0x2b4>
    56ec:      	add	x16, sp, #0x20
    56f0:      	ldr	x27, [x16]
    56f4:      	add	x16, sp, #0x20
    56f8:      	ldr	x28, [x16, #0x8]
    56fc:      	add	x16, sp, #0x20
    5700:      	ldr	x0, [x16, #0x10]
    5704:      	add	x16, sp, #0x20
    5708:      	ldr	x1, [x16, #0x18]
    570c:      	add	x16, sp, #0x20
    5710:      	ldr	x2, [x16, #0x20]
    5714:      	movz	x3, #0x0, lsl #48
    5718:      	b	0x57b0 <_stogir.placement.pinned+0x348>
    571c:      	b	0x572c <_stogir.placement.pinned+0x2c4>
    5720:      	sub	x0, x0, #0x1
    5724:      	add	x16, sp, #0x20
    5728:      	str	x0, [x16, #0x8]
    572c:      	add	x16, sp, #0x20
    5730:      	ldr	x0, [x16, #0x8]
    5734:      	cmp	x0, #0x0
    5738:      	b.ne	0x5720 <_stogir.placement.pinned+0x2b8>
    573c:      	add	x16, sp, #0x20
    5740:      	ldr	x0, [x16, #0x10]
    5744:      	cmp	x0, #0x0
    5748:      	b.le	0x577c <_stogir.placement.pinned+0x314>
    574c:      	add	x1, x20, #0x18
    5750:      	add	x16, sp, #0x20
    5754:      	ldr	x2, [x16]
    5758:      	fmov	d31, x0
    575c:      	mov	x0, x1
    5760:      	mov	x1, x2
    5764:      	fmov	x2, d31
    5768:      	adrp	x3, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005768:  ARM64_RELOC_PAGE21	l_stogir.426
    576c:      	ldr	x3, [x3]
		000000000000576c:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    5770:      	mov	x4, #0x4                ; =4
    5774:      	mov	x5, #0x4                ; =4
    5778:      	bl	0x5778 <_stogir.placement.pinned+0x310>
		0000000000005778:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    577c:      	add	x16, sp, #0x20
    5780:      	movz	x17, #0x0, lsl #48
    5784:      	str	x17, [x16]
    5788:      	add	x16, sp, #0x20
    578c:      	movz	x17, #0x0, lsl #48
    5790:      	str	x17, [x16, #0x8]
    5794:      	add	x16, sp, #0x20
    5798:      	movz	x17, #0x0, lsl #48
    579c:      	str	x17, [x16, #0x10]
    57a0:      	mov	x3, #0x1                ; =1
    57a4:      	movz	x0, #0x0, lsl #48
    57a8:      	movz	x1, #0x0, lsl #48
    57ac:      	movz	x2, #0x0, lsl #48
    57b0:      	ldr	x4, [sp, #0x60]
    57b4:      	str	x3, [x4]
    57b8:      	str	x27, [x4, #0x8]
    57bc:      	str	x28, [x4, #0x10]
    57c0:      	str	x0, [x4, #0x18]
    57c4:      	str	x1, [x4, #0x20]
    57c8:      	str	x2, [x4, #0x28]
    57cc:      	ldr	x19, [sp, #0x68]
    57d0:      	ldr	x20, [sp, #0x70]
    57d4:      	ldr	x21, [sp, #0x78]
    57d8:      	ldr	x22, [sp, #0x80]
    57dc:      	ldr	x23, [sp, #0x88]
    57e0:      	ldr	x24, [sp, #0x90]
    57e4:      	ldr	x25, [sp, #0x98]
    57e8:      	ldr	x26, [sp, #0xa0]
    57ec:      	ldr	x27, [sp, #0xa8]
    57f0:      	ldr	x28, [sp, #0xb0]
    57f4:      	ldr	x29, [sp, #0x10]
    57f8:      	ldr	x30, [sp, #0x18]
    57fc:      	add	sp, sp, #0xc0
    5800:      	ret
    5804:      	movz	x3, #0x0, lsl #48
    5808:      	b	0x5810 <_stogir.placement.pinned+0x3a8>
    580c:      	movz	x3, #0x0, lsl #48
    5810:      	cmp	x3, #0x0
    5814:      	b.eq	0x55a0 <_stogir.placement.pinned+0x138>
    5818:      	movz	x16, #0x0, lsl #48
    581c:      	sub	x3, x16, x0
    5820:      	cmp	x0, #0x0
    5824:      	cset	w4, gt
    5828:      	sub	x5, x3, #0x1
    582c:      	uxtb	w16, w4
    5830:      	cmp	w16, wzr
    5834:      	b.eq	0x5880 <_stogir.placement.pinned+0x418>
    5838:      	ldr	x3, [x25, #0x8]
    583c:      	cmp	x0, x3
    5840:      	b.ge	0x58c0 <_stogir.placement.pinned+0x458>
    5844:      	ldr	x3, [x21, #0x8]
    5848:      	cmp	x0, x3
    584c:      	b.ge	0x5974 <_stogir.placement.pinned+0x50c>
    5850:      	ldr	x3, [x25, #0x78]
    5854:      	add	x2, x2, x3
    5858:      	ldr	w2, [x2]
    585c:      	sxtw	x2, w2
    5860:      	cmp	x2, #0x0
    5864:      	cset	w2, ge
    5868:      	ubfx	x2, x2, #0, #8
    586c:      	b	0x5978 <_stogir.placement.pinned+0x510>
    5870:      	adrp	x27, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005870:  ARM64_RELOC_PAGE21	l_stogir.427
    5874:      	ldr	x27, [x27]
		0000000000005874:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    5878:      	mov	x28, #0x20              ; =32
    587c:      	b	0x55ac <_stogir.placement.pinned+0x144>
    5880:      	cmp	x0, #0x0
    5884:      	b.ge	0x58c8 <_stogir.placement.pinned+0x460>
    5888:      	ldr	x2, [x22, #0x8]
    588c:      	ldr	x6, [x23, #0x8]
    5890:      	cmp	x2, x6
    5894:      	b.ne	0x596c <_stogir.placement.pinned+0x504>
    5898:      	cmp	x3, x2
    589c:      	b.gt	0x59c0 <_stogir.placement.pinned+0x558>
    58a0:      	ldr	x2, [x25, #0x50]
    58a4:      	add	x2, x2, x5, lsl #2
    58a8:      	ldr	w2, [x2]
    58ac:      	sxtw	x2, w2
    58b0:      	cmp	x2, #0x0
    58b4:      	cset	w2, gt
    58b8:      	ubfx	x2, x2, #0, #8
    58bc:      	b	0x59c4 <_stogir.placement.pinned+0x55c>
    58c0:      	movz	x2, #0x0, lsl #48
    58c4:      	b	0x58cc <_stogir.placement.pinned+0x464>
    58c8:      	movz	x2, #0x0, lsl #48
    58cc:      	cmp	x2, #0x0
    58d0:      	b.eq	0x5904 <_stogir.placement.pinned+0x49c>
    58d4:      	uxtb	w16, w4
    58d8:      	cmp	w16, wzr
    58dc:      	b.eq	0x58f0 <_stogir.placement.pinned+0x488>
    58e0:      	ldr	x2, [x25]
    58e4:      	add	x0, x2, x0, lsl #4
    58e8:      	ldr	x0, [x0]
    58ec:      	b	0x58fc <_stogir.placement.pinned+0x494>
    58f0:      	ldr	x0, [x25, #0x28]
    58f4:      	add	x0, x0, x5, lsl #4
    58f8:      	ldr	x0, [x0]
    58fc:      	mov	w2, #0x1                ; =1
    5900:      	b	0x590c <_stogir.placement.pinned+0x4a4>
    5904:      	movz	w2, #0x0, lsl #16
    5908:      	movz	x0, #0x0, lsl #48
    590c:      	ubfx	x2, x2, #0, #32
    5910:      	lsr	x16, x2, #0
    5914:      	cmp	x16, #0x1
    5918:      	b.eq	0x5934 <_stogir.placement.pinned+0x4cc>
    591c:      	b.lo	0x5924 <_stogir.placement.pinned+0x4bc>
    5920:      	b	0x5938 <_stogir.placement.pinned+0x4d0>
    5924:      	cmp	x16, #0x0
    5928:      	b.eq	0x5930 <_stogir.placement.pinned+0x4c8>
    592c:      	b	0x5938 <_stogir.placement.pinned+0x4d0>
    5930:      	b	0x593c <_stogir.placement.pinned+0x4d4>
    5934:      	b	0x594c <_stogir.placement.pinned+0x4e4>
    5938:      	b	0x59d0 <_stogir.placement.pinned+0x568>
    593c:      	adrp	x27, 0x5000 <_stogir.uses.build+0xe0>
		000000000000593c:  ARM64_RELOC_PAGE21	l_stogir.423
    5940:      	ldr	x27, [x27]
		0000000000005940:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    5944:      	mov	x28, #0x15              ; =21
    5948:      	b	0x587c <_stogir.placement.pinned+0x414>
    594c:      	uxtb	w0, w0
    5950:      	cmp	x0, #0x83
    5954:      	b.ge	0x597c <_stogir.placement.pinned+0x514>
    5958:      	adrp	x17, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005958:  ARM64_RELOC_PAGE21	l_stogir.424
    595c:      	ldr	x17, [x17]
		000000000000595c:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    5960:      	add	x0, x0, x17
    5964:      	ldrb	w0, [x0]
    5968:      	b	0x5980 <_stogir.placement.pinned+0x518>
    596c:      	movz	x2, #0x0, lsl #48
    5970:      	b	0x58cc <_stogir.placement.pinned+0x464>
    5974:      	movz	x2, #0x0, lsl #48
    5978:      	b	0x58c4 <_stogir.placement.pinned+0x45c>
    597c:      	movz	w0, #0x0, lsl #16
    5980:      	uxtb	w16, w0
    5984:      	and	w0, w16, #0x2
    5988:      	uxtb	w0, w0
    598c:      	ubfx	x0, x0, #0, #8
    5990:      	cmp	x0, #0x0
    5994:      	cset	w0, eq
    5998:      	uxtb	w16, w0
    599c:      	cmp	w16, wzr
    59a0:      	cset	x0, eq
    59a4:      	cmp	x0, #0x0
    59a8:      	b.eq	0x5870 <_stogir.placement.pinned+0x408>
    59ac:      	add	x16, sp, #0x20
    59b0:      	ldr	x0, [x16]
    59b4:      	add	x0, x0, x26, lsl #2
    59b8:      	str	w1, [x0]
    59bc:      	b	0x587c <_stogir.placement.pinned+0x414>
    59c0:      	movz	x2, #0x0, lsl #48
    59c4:      	b	0x5970 <_stogir.placement.pinned+0x508>
    59c8:      	brk	#0
    59cc:      	b	0x59c8 <_stogir.placement.pinned+0x560>
    59d0:      	brk	#0
    59d4:      	b	0x59d0 <_stogir.placement.pinned+0x568>
    59d8:      	mov	x24, x8
    59dc:      	mov	x25, x0
    59e0:      	b	0x557c <_stogir.placement.pinned+0x114>
    59e4:      	mov	x24, x8
    59e8:      	mov	x25, x0
    59ec:      	mov	x26, x1
    59f0:      	b	0x550c <_stogir.placement.pinned+0xa4>
    59f4:      	str	x24, [sp, #0x60]
    59f8:      	b	0x56e4 <_stogir.placement.pinned+0x27c>
    59fc:      	str	x24, [sp, #0x60]
    5a00:      	b	0x56e4 <_stogir.placement.pinned+0x27c>
    5a04:      	udf	#0x0

0000000000005a08 <_stogir.placement.early-with-uses!>:
    5a08:      	sub	sp, sp, #0x1e0
    5a0c:      	str	x29, [sp, #0x10]
    5a10:      	str	x30, [sp, #0x18]
    5a14:      	add	x29, sp, #0x10
    5a18:      	str	x19, [sp, #0x188]
    5a1c:      	str	x20, [sp, #0x190]
    5a20:      	str	x21, [sp, #0x198]
    5a24:      	str	x22, [sp, #0x1a0]
    5a28:      	str	x23, [sp, #0x1a8]
    5a2c:      	str	x24, [sp, #0x1b0]
    5a30:      	str	x25, [sp, #0x1b8]
    5a34:      	str	x26, [sp, #0x1c0]
    5a38:      	str	x27, [sp, #0x1c8]
    5a3c:      	str	x28, [sp, #0x1d0]
    5a40:      	add	x16, sp, #0x20
    5a44:      	orr	x19, x16, xzr
    5a48:      	mov	x20, x8
    5a4c:      	add	x8, sp, #0x50
    5a50:      	mov	x21, x0
    5a54:      	mov	x0, x5
    5a58:      	mov	x22, x1
    5a5c:      	mov	x23, x2
    5a60:      	mov	w24, w3
    5a64:      	mov	x25, x4
    5a68:      	mov	x26, x5
    5a6c:      	bl	0x5a6c <_stogir.placement.early-with-uses!+0x64>
		0000000000005a6c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    5a70:      	add	x16, sp, #0x50
    5a74:      	ldr	x0, [x16]
    5a78:      	add	x16, sp, #0x20
    5a7c:      	str	x0, [x16]
    5a80:      	add	x16, sp, #0x50
    5a84:      	ldr	x0, [x16, #0x8]
    5a88:      	add	x16, sp, #0x20
    5a8c:      	str	x0, [x16, #0x8]
    5a90:      	add	x16, sp, #0x50
    5a94:      	ldr	x0, [x16, #0x10]
    5a98:      	add	x16, sp, #0x20
    5a9c:      	str	x0, [x16, #0x10]
    5aa0:      	add	x16, sp, #0x50
    5aa4:      	ldr	x0, [x16, #0x18]
    5aa8:      	add	x16, sp, #0x20
    5aac:      	str	x0, [x16, #0x18]
    5ab0:      	add	x16, sp, #0x50
    5ab4:      	ldr	x0, [x16, #0x20]
    5ab8:      	add	x16, sp, #0x20
    5abc:      	str	x0, [x16, #0x20]
    5ac0:      	add	x8, sp, #0xb0
    5ac4:      	mov	x0, x26
    5ac8:      	bl	0x5ac8 <_stogir.placement.early-with-uses!+0xc0>
		0000000000005ac8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    5acc:      	add	x16, sp, #0xb0
    5ad0:      	ldr	x0, [x16]
    5ad4:      	add	x16, sp, #0x80
    5ad8:      	str	x0, [x16]
    5adc:      	add	x16, sp, #0xb0
    5ae0:      	ldr	x0, [x16, #0x8]
    5ae4:      	add	x16, sp, #0x80
    5ae8:      	str	x0, [x16, #0x8]
    5aec:      	add	x16, sp, #0xb0
    5af0:      	ldr	x0, [x16, #0x10]
    5af4:      	add	x16, sp, #0x80
    5af8:      	str	x0, [x16, #0x10]
    5afc:      	add	x16, sp, #0xb0
    5b00:      	ldr	x0, [x16, #0x18]
    5b04:      	add	x16, sp, #0x80
    5b08:      	str	x0, [x16, #0x18]
    5b0c:      	add	x16, sp, #0xb0
    5b10:      	ldr	x0, [x16, #0x20]
    5b14:      	add	x16, sp, #0x80
    5b18:      	str	x0, [x16, #0x20]
    5b1c:      	movz	x26, #0x0, lsl #48
    5b20:      	b	0x5b5c <_stogir.placement.early-with-uses!+0x154>
    5b24:      	nop
    5b28:      	lsl	x0, x0, #1
    5b2c:      	mov	x1, x0
    5b30:      	mov	x0, x19
    5b34:      	bl	0x5b34 <_stogir.placement.early-with-uses!+0x12c>
		0000000000005b34:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5b38:      	add	x26, x26, #0x1
    5b3c:      	add	x0, x27, #0x1
    5b40:      	add	x16, sp, #0x20
    5b44:      	ldr	x1, [x16]
    5b48:      	add	x1, x1, x27, lsl #2
    5b4c:      	movn	w17, #0x0, lsl #16
    5b50:      	str	w17, [x1]
    5b54:      	add	x16, sp, #0x20
    5b58:      	str	x0, [x16, #0x8]
    5b5c:      	ldr	x0, [x21, #0x8]
    5b60:      	cmp	x26, x0
    5b64:      	b.ge	0x5b94 <_stogir.placement.early-with-uses!+0x18c>
    5b68:      	add	x16, sp, #0x20
    5b6c:      	ldr	x0, [x16, #0x8]
    5b70:      	orr	x27, x0, xzr
    5b74:      	add	x16, sp, #0x20
    5b78:      	ldr	x0, [x16, #0x10]
    5b7c:      	cmp	x27, x0
    5b80:      	b.lt	0x5b38 <_stogir.placement.early-with-uses!+0x130>
    5b84:      	cmp	x0, #0x0
    5b88:      	b.ne	0x5b28 <_stogir.placement.early-with-uses!+0x120>
    5b8c:      	mov	x0, #0x2                ; =2
    5b90:      	b	0x5b2c <_stogir.placement.early-with-uses!+0x124>
    5b94:      	add	x16, sp, #0x80
    5b98:      	orr	x26, x16, xzr
    5b9c:      	mov	x27, #0x1               ; =1
    5ba0:      	movz	x28, #0x0, lsl #48
    5ba4:      	adrp	x0, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005ba4:  ARM64_RELOC_PAGE21	l_stogir.428
    5ba8:      	ldr	x0, [x0]
		0000000000005ba8:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    5bac:      	movz	x1, #0x0, lsl #48
    5bb0:      	b	0x5c18 <_stogir.placement.early-with-uses!+0x210>
    5bb4:      	lsl	x0, x0, #1
    5bb8:      	mov	x1, x0
    5bbc:      	ldr	x0, [sp, #0x108]
    5bc0:      	bl	0x5bc0 <_stogir.placement.early-with-uses!+0x1b8>
		0000000000005bc0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5bc4:      	add	x0, x23, #0x1
    5bc8:      	add	x16, sp, #0x80
    5bcc:      	ldr	x1, [x16]
    5bd0:      	add	x1, x1, x23, lsl #2
    5bd4:      	str	w19, [x1]
    5bd8:      	add	x16, sp, #0x80
    5bdc:      	str	x0, [x16, #0x8]
    5be0:      	add	x0, x28, #0x1
    5be4:      	sxtw	x28, w0
    5be8:      	add	x0, x20, #0x4
    5bec:      	asr	x16, x0, #63
    5bf0:      	lsr	x16, x16, #62
    5bf4:      	add	x0, x0, x16
    5bf8:      	asr	x0, x0, #2
    5bfc:      	add	x27, x0, x27
    5c00:      	ldr	x20, [sp, #0x118]
    5c04:      	ldr	x23, [sp, #0x138]
    5c08:      	ldr	x19, [sp, #0x100]
    5c0c:      	ldr	x26, [sp, #0x108]
    5c10:      	ldr	x0, [sp, #0x120]
    5c14:      	ldr	x1, [sp, #0x130]
    5c18:      	ldr	x2, [x21, #0x8]
    5c1c:      	cmp	x27, x2
    5c20:      	b.ge	0x6384 <_stogir.placement.early-with-uses!+0x97c>
    5c24:      	lsl	x2, x27, #2
    5c28:      	ldr	x3, [x21]
    5c2c:      	add	x3, x3, x27, lsl #4
    5c30:      	ldr	x3, [x3]
    5c34:      	ldr	x4, [x21, #0x78]
    5c38:      	uxtb	w3, w3
    5c3c:      	add	x4, x4, x27, lsl #2
    5c40:      	cmp	x3, #0x83
    5c44:      	cset	w5, lt
    5c48:      	ldr	w4, [x4]
    5c4c:      	uxtb	w16, w5
    5c50:      	cmp	w16, wzr
    5c54:      	b.eq	0x5c6c <_stogir.placement.early-with-uses!+0x264>
    5c58:      	adrp	x17, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005c58:  ARM64_RELOC_PAGE21	l_stogir.429
    5c5c:      	ldr	x17, [x17]
		0000000000005c5c:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    5c60:      	add	x6, x3, x17
    5c64:      	ldrb	w6, [x6]
    5c68:      	b	0x5c70 <_stogir.placement.early-with-uses!+0x268>
    5c6c:      	movz	w6, #0x0, lsl #16
    5c70:      	ldr	x7, [x22]
    5c74:      	add	x2, x7, x2
    5c78:      	ldr	w2, [x2]
    5c7c:      	sxtw	x2, w2
    5c80:      	cmp	x2, #0x0
    5c84:      	b.ne	0x5cb0 <_stogir.placement.early-with-uses!+0x2a8>
    5c88:      	uxtb	w16, w6
    5c8c:      	and	w2, w16, #0x40
    5c90:      	uxtb	w2, w2
    5c94:      	ubfx	x2, x2, #0, #8
    5c98:      	cmp	x2, #0x0
    5c9c:      	b.ne	0x5ca8 <_stogir.placement.early-with-uses!+0x2a0>
    5ca0:      	movz	x2, #0x0, lsl #48
    5ca4:      	b	0x5cac <_stogir.placement.early-with-uses!+0x2a4>
    5ca8:      	mov	x2, #0x1                ; =1
    5cac:      	b	0x5cb4 <_stogir.placement.early-with-uses!+0x2ac>
    5cb0:      	movz	x2, #0x0, lsl #48
    5cb4:      	sxtw	x4, w4
    5cb8:      	cmp	x2, #0x0
    5cbc:      	b.eq	0x63a0 <_stogir.placement.early-with-uses!+0x998>
    5cc0:      	orr	w2, w27, wzr
    5cc4:      	adrp	x16, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005cc4:  ARM64_RELOC_PAGE21	l_stogir.430
    5cc8:      	ldr	x16, [x16]
		0000000000005cc8:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    5ccc:      	add	x3, x16, x3, lsl #2
    5cd0:      	mov	x6, #0x1                ; =1
    5cd4:      	movz	x7, #0x0, lsl #48
    5cd8:      	b	0x5d58 <_stogir.placement.early-with-uses!+0x350>
    5cdc:      	sub	w9, w8, #0x1
    5ce0:      	lsl	w9, w9, #2
    5ce4:      	ubfx	x9, x9, #0, #32
    5ce8:      	lsr	x9, x10, x9
    5cec:      	and	w9, w9, #0xf
    5cf0:      	b	0x5d94 <_stogir.placement.early-with-uses!+0x38c>
    5cf4:      	sxtw	x1, w1
    5cf8:      	cmp	x1, #0x0
    5cfc:      	b.le	0x5d20 <_stogir.placement.early-with-uses!+0x318>
    5d00:      	ldr	x0, [x22]
    5d04:      	add	x0, x0, x1, lsl #2
    5d08:      	ldr	w0, [x0]
    5d0c:      	sxtw	x0, w0
    5d10:      	cmp	x0, #0x0
    5d14:      	b.ne	0x5d20 <_stogir.placement.early-with-uses!+0x318>
    5d18:      	add	x0, x23, #0x1
    5d1c:      	sxtw	x23, w0
    5d20:      	add	x0, x26, #0x1
    5d24:      	sxtw	x26, w0
    5d28:      	mov	x4, x20
    5d2c:      	ldr	x20, [sp, #0x118]
    5d30:      	mov	w2, w19
    5d34:      	ldr	x19, [sp, #0x100]
    5d38:      	ldr	w5, [sp, #0x110]
    5d3c:      	ldr	x3, [sp, #0x128]
    5d40:      	mov	x6, x26
    5d44:      	ldr	x26, [sp, #0x108]
    5d48:      	mov	x7, x23
    5d4c:      	ldr	x23, [sp, #0x138]
    5d50:      	ldr	x0, [sp, #0x120]
    5d54:      	ldr	x1, [sp, #0x130]
    5d58:      	cmp	x6, x4
    5d5c:      	b.gt	0x63c0 <_stogir.placement.early-with-uses!+0x9b8>
    5d60:      	orr	w8, w6, wzr
    5d64:      	uxtb	w16, w5
    5d68:      	cmp	w16, wzr
    5d6c:      	b.eq	0x5d98 <_stogir.placement.early-with-uses!+0x390>
    5d70:      	sxtw	x9, w8
    5d74:      	ldr	w10, [x3]
    5d78:      	cmp	x9, #0x0
    5d7c:      	b.le	0x5d90 <_stogir.placement.early-with-uses!+0x388>
    5d80:      	cmp	x9, #0x4
    5d84:      	b.le	0x5cdc <_stogir.placement.early-with-uses!+0x2d4>
    5d88:      	mov	w9, #0x4                ; =4
    5d8c:      	b	0x5ce0 <_stogir.placement.early-with-uses!+0x2d8>
    5d90:      	movz	w9, #0x0, lsl #16
    5d94:      	b	0x5d9c <_stogir.placement.early-with-uses!+0x394>
    5d98:      	movz	w9, #0x0, lsl #16
    5d9c:      	ubfx	x9, x9, #0, #32
    5da0:      	cmp	x9, #0xf
    5da4:      	b.hs	0x63e8 <_stogir.placement.early-with-uses!+0x9e0>
    5da8:      	mov	x16, #0x1               ; =1
    5dac:      	lsl	x9, x16, x9
    5db0:      	mov	w17, #0x5e1c            ; =24092
    5db4:      	and	w9, w9, w17
    5db8:      	ubfx	x9, x9, #0, #32
    5dbc:      	cmp	x9, #0x0
    5dc0:      	b.eq	0x641c <_stogir.placement.early-with-uses!+0xa14>
    5dc4:      	str	x0, [sp, #0x120]
    5dc8:      	mov	x0, x21
    5dcc:      	str	x1, [sp, #0x130]
    5dd0:      	mov	w1, w2
    5dd4:      	str	w5, [sp, #0x110]
    5dd8:      	str	x3, [sp, #0x128]
    5ddc:      	str	x19, [sp, #0x100]
    5de0:      	mov	w19, w2
    5de4:      	mov	w2, w8
    5de8:      	str	x26, [sp, #0x108]
    5dec:      	mov	x26, x6
    5df0:      	str	x20, [sp, #0x118]
    5df4:      	mov	x20, x4
    5df8:      	str	x23, [sp, #0x138]
    5dfc:      	mov	x23, x7
    5e00:      	bl	0x5e00 <_stogir.placement.early-with-uses!+0x3f8>
		0000000000005e00:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5e04:      	ubfx	x0, x0, #0, #32
    5e08:      	lsr	x16, x0, #0
    5e0c:      	cmp	x16, #0x1
    5e10:      	b.eq	0x5e2c <_stogir.placement.early-with-uses!+0x424>
    5e14:      	b.lo	0x5e1c <_stogir.placement.early-with-uses!+0x414>
    5e18:      	b	0x5e30 <_stogir.placement.early-with-uses!+0x428>
    5e1c:      	cmp	x16, #0x0
    5e20:      	b.eq	0x5e28 <_stogir.placement.early-with-uses!+0x420>
    5e24:      	b	0x5e30 <_stogir.placement.early-with-uses!+0x428>
    5e28:      	b	0x5e34 <_stogir.placement.early-with-uses!+0x42c>
    5e2c:      	b	0x5cf4 <_stogir.placement.early-with-uses!+0x2ec>
    5e30:      	b	0x637c <_stogir.placement.early-with-uses!+0x974>
    5e34:      	adrp	x16, 0x5000 <_stogir.uses.build+0xe0>
		0000000000005e34:  ARM64_RELOC_PAGE21	l_stogir.431
    5e38:      	ldr	x16, [x16]
		0000000000005e38:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    5e3c:      	str	x16, [sp, #0x120]
    5e40:      	mov	x16, #0x18              ; =24
    5e44:      	str	x16, [sp, #0x130]
    5e48:      	b	0x5d20 <_stogir.placement.early-with-uses!+0x318>
    5e4c:      	orr	w0, w23, wzr
    5e50:      	add	x16, sp, #0x20
    5e54:      	ldr	x1, [x16]
    5e58:      	add	x1, x1, x27, lsl #2
    5e5c:      	str	w0, [x1]
    5e60:      	cmp	x23, #0x0
    5e64:      	b.ne	0x5be0 <_stogir.placement.early-with-uses!+0x1d8>
    5e68:      	add	x16, sp, #0x80
    5e6c:      	ldr	x0, [x16, #0x8]
    5e70:      	orr	x23, x0, xzr
    5e74:      	add	x16, sp, #0x80
    5e78:      	ldr	x0, [x16, #0x10]
    5e7c:      	cmp	x23, x0
    5e80:      	b.lt	0x5bc4 <_stogir.placement.early-with-uses!+0x1bc>
    5e84:      	cmp	x0, #0x0
    5e88:      	b.ne	0x5bb4 <_stogir.placement.early-with-uses!+0x1ac>
    5e8c:      	mov	x0, #0x2                ; =2
    5e90:      	b	0x5bb8 <_stogir.placement.early-with-uses!+0x1b0>
    5e94:      	sxtw	x24, w24
    5e98:      	orr	x19, x22, xzr
    5e9c:      	ldr	x20, [sp, #0x138]
    5ea0:      	movz	x23, #0x0, lsl #48
    5ea4:      	movz	x26, #0x0, lsl #48
    5ea8:      	b	0x6004 <_stogir.placement.early-with-uses!+0x5fc>
    5eac:      	movz	x1, #0x0, lsl #48
    5eb0:      	movz	x2, #0x0, lsl #48
    5eb4:      	b	0x5ec4 <_stogir.placement.early-with-uses!+0x4bc>
    5eb8:      	mov	x23, x3
    5ebc:      	b	0x5ec4 <_stogir.placement.early-with-uses!+0x4bc>
    5ec0:      	mov	x1, #0x1                ; =1
    5ec4:      	cmp	x1, #0x0
    5ec8:      	b.ne	0x608c <_stogir.placement.early-with-uses!+0x684>
    5ecc:      	cmp	x23, #0x0
    5ed0:      	b.le	0x5ec0 <_stogir.placement.early-with-uses!+0x4b8>
    5ed4:      	ldr	x3, [x20, #0x8]
    5ed8:      	cmp	x23, x3
    5edc:      	b.ge	0x5ec0 <_stogir.placement.early-with-uses!+0x4b8>
    5ee0:      	ldr	x3, [x20]
    5ee4:      	add	x3, x3, x23, lsl #2
    5ee8:      	ldr	w3, [x3]
    5eec:      	sxtw	x3, w3
    5ef0:      	cmp	x3, #0x0
    5ef4:      	b.ne	0x5f00 <_stogir.placement.early-with-uses!+0x4f8>
    5ef8:      	mov	x1, #0x1                ; =1
    5efc:      	b	0x5ebc <_stogir.placement.early-with-uses!+0x4b4>
    5f00:      	cmp	x23, x0
    5f04:      	b.ne	0x6364 <_stogir.placement.early-with-uses!+0x95c>
    5f08:      	mov	x1, #0x1                ; =1
    5f0c:      	mov	x2, #0x1                ; =1
    5f10:      	b	0x5ebc <_stogir.placement.early-with-uses!+0x4b4>
    5f14:      	nop
    5f18:      	lsl	x2, x2, #1
    5f1c:      	str	x19, [sp, #0x180]
    5f20:      	mov	w19, w0
    5f24:      	ldr	x0, [sp, #0x108]
    5f28:      	str	x20, [sp, #0x138]
    5f2c:      	mov	x20, x1
    5f30:      	mov	x1, x2
    5f34:      	bl	0x5f34 <_stogir.placement.early-with-uses!+0x52c>
		0000000000005f34:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5f38:      	add	x0, x20, #0x1
    5f3c:      	add	x16, sp, #0x80
    5f40:      	ldr	x1, [x16]
    5f44:      	add	x1, x1, x20, lsl #2
    5f48:      	str	w19, [x1]
    5f4c:      	add	x16, sp, #0x80
    5f50:      	str	x0, [x16, #0x8]
    5f54:      	add	x24, x24, #0x1
    5f58:      	ldr	x20, [sp, #0x138]
    5f5c:      	ldr	x19, [sp, #0x180]
    5f60:      	cmp	x24, x23
    5f64:      	b.ge	0x6450 <_stogir.placement.early-with-uses!+0xa48>
    5f68:      	add	x0, x21, x24
    5f6c:      	ldr	x1, [x25, #0x28]
    5f70:      	add	x0, x1, x0, lsl #3
    5f74:      	ldr	x0, [x0]
    5f78:      	add	x16, sp, #0x20
    5f7c:      	ldr	x1, [x16]
    5f80:      	sxtw	x2, w0
    5f84:      	add	x3, x1, x2, lsl #2
    5f88:      	ldr	w3, [x3]
    5f8c:      	sxtw	x4, w3
    5f90:      	cmp	x4, #0x0
    5f94:      	b.le	0x645c <_stogir.placement.early-with-uses!+0xa54>
    5f98:      	sub	w3, w3, #0x1
    5f9c:      	add	x1, x1, x2, lsl #2
    5fa0:      	str	w3, [x1]
    5fa4:      	cmp	x4, #0x1
    5fa8:      	b.ne	0x6468 <_stogir.placement.early-with-uses!+0xa60>
    5fac:      	add	x16, sp, #0x80
    5fb0:      	ldr	x1, [x16, #0x8]
    5fb4:      	add	x16, sp, #0x80
    5fb8:      	ldr	x2, [x16, #0x10]
    5fbc:      	cmp	x1, x2
    5fc0:      	b.lt	0x6474 <_stogir.placement.early-with-uses!+0xa6c>
    5fc4:      	cmp	x2, #0x0
    5fc8:      	b.ne	0x5f18 <_stogir.placement.early-with-uses!+0x510>
    5fcc:      	mov	x2, #0x2                ; =2
    5fd0:      	b	0x5f1c <_stogir.placement.early-with-uses!+0x514>
    5fd4:      	add	x0, x26, #0x1
    5fd8:      	sub	x1, x28, #0x1
    5fdc:      	sxtw	x26, w0
    5fe0:      	sxtw	x28, w1
    5fe4:      	ldr	x0, [sp, #0x178]
    5fe8:      	add	x0, x0, #0x1
    5fec:      	ldr	x21, [sp, #0x140]
    5ff0:      	ldr	x20, [sp, #0x138]
    5ff4:      	ldr	x24, [sp, #0x168]
    5ff8:      	ldr	x19, [sp, #0x180]
    5ffc:      	mov	x23, x0
    6000:      	str	x27, [sp, #0x130]
    6004:      	ldr	x27, [sp, #0x130]
    6008:      	cmp	x27, #0x0
    600c:      	b.ne	0x62bc <_stogir.placement.early-with-uses!+0x8b4>
    6010:      	add	x16, sp, #0x80
    6014:      	ldr	x0, [x16, #0x8]
    6018:      	cmp	x23, x0
    601c:      	b.ge	0x62bc <_stogir.placement.early-with-uses!+0x8b4>
    6020:      	add	x16, sp, #0x80
    6024:      	ldr	x0, [x16]
    6028:      	add	x0, x0, x23, lsl #2
    602c:      	ldr	w0, [x0]
    6030:      	sxtw	x1, w0
    6034:      	ldr	x2, [x21]
    6038:      	add	x2, x2, x1, lsl #4
    603c:      	ldr	x2, [x2]
    6040:      	ldr	x3, [x21, #0x78]
    6044:      	uxtb	w2, w2
    6048:      	add	x3, x3, x1, lsl #2
    604c:      	cmp	x2, #0x83
    6050:      	cset	w4, lt
    6054:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		0000000000006054:  ARM64_RELOC_PAGE21	l_stogir.430
    6058:      	ldr	x16, [x16]
		0000000000006058:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    605c:      	add	x2, x16, x2, lsl #2
    6060:      	ldr	w3, [x3]
    6064:      	sxtw	x3, w3
    6068:      	mov	x6, x24
    606c:      	mov	x5, #0x1                ; =1
    6070:      	b	0x60d4 <_stogir.placement.early-with-uses!+0x6cc>
    6074:      	sub	w9, w7, #0x1
    6078:      	lsl	w9, w9, #2
    607c:      	ubfx	x9, x9, #0, #32
    6080:      	lsr	x9, x10, x9
    6084:      	and	w9, w9, #0xf
    6088:      	b	0x6130 <_stogir.placement.early-with-uses!+0x728>
    608c:      	cmp	x2, #0x0
    6090:      	b.ne	0x60a4 <_stogir.placement.early-with-uses!+0x69c>
    6094:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		0000000000006094:  ARM64_RELOC_PAGE21	l_stogir.432
    6098:      	ldr	x16, [x16]
		0000000000006098:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    609c:      	str	x16, [sp, #0x120]
    60a0:      	mov	x27, #0x2b              ; =43
    60a4:      	add	x0, x24, #0x1
    60a8:      	sxtw	x24, w0
    60ac:      	ldr	x23, [sp, #0x178]
    60b0:      	mov	x1, x21
    60b4:      	ldr	x21, [sp, #0x140]
    60b8:      	ldr	x3, [sp, #0x160]
    60bc:      	ldr	w0, [sp, #0x148]
    60c0:      	ldr	w4, [sp, #0x150]
    60c4:      	ldr	x2, [sp, #0x158]
    60c8:      	mov	x5, x24
    60cc:      	ldr	x24, [sp, #0x168]
    60d0:      	ldr	x6, [sp, #0x170]
    60d4:      	cmp	x27, #0x0
    60d8:      	b.ne	0x60ec <_stogir.placement.early-with-uses!+0x6e4>
    60dc:      	cmp	x5, x3
    60e0:      	cset	w7, le
    60e4:      	ubfx	x7, x7, #0, #8
    60e8:      	b	0x60f0 <_stogir.placement.early-with-uses!+0x6e8>
    60ec:      	movz	x7, #0x0, lsl #48
    60f0:      	orr	w8, w6, wzr
    60f4:      	cmp	x7, #0x0
    60f8:      	b.eq	0x6488 <_stogir.placement.early-with-uses!+0xa80>
    60fc:      	orr	w7, w5, wzr
    6100:      	uxtb	w16, w4
    6104:      	cmp	w16, wzr
    6108:      	b.eq	0x6134 <_stogir.placement.early-with-uses!+0x72c>
    610c:      	sxtw	x9, w7
    6110:      	ldr	w10, [x2]
    6114:      	cmp	x9, #0x0
    6118:      	b.le	0x612c <_stogir.placement.early-with-uses!+0x724>
    611c:      	cmp	x9, #0x4
    6120:      	b.le	0x6074 <_stogir.placement.early-with-uses!+0x66c>
    6124:      	mov	w9, #0x4                ; =4
    6128:      	b	0x6078 <_stogir.placement.early-with-uses!+0x670>
    612c:      	movz	w9, #0x0, lsl #16
    6130:      	b	0x6138 <_stogir.placement.early-with-uses!+0x730>
    6134:      	movz	w9, #0x0, lsl #16
    6138:      	ubfx	x9, x9, #0, #32
    613c:      	cmp	x9, #0xf
    6140:      	b.hs	0x64a0 <_stogir.placement.early-with-uses!+0xa98>
    6144:      	mov	x16, #0x1               ; =1
    6148:      	lsl	x9, x16, x9
    614c:      	mov	w17, #0x5e1c            ; =24092
    6150:      	and	w9, w9, w17
    6154:      	ubfx	x9, x9, #0, #32
    6158:      	cmp	x9, #0x0
    615c:      	b.eq	0x64cc <_stogir.placement.early-with-uses!+0xac4>
    6160:      	str	w0, [sp, #0x148]
    6164:      	str	w4, [sp, #0x150]
    6168:      	str	x2, [sp, #0x158]
    616c:      	mov	w2, w7
    6170:      	str	x3, [sp, #0x160]
    6174:      	str	x6, [sp, #0x170]
    6178:      	str	x21, [sp, #0x140]
    617c:      	str	x24, [sp, #0x168]
    6180:      	mov	x24, x5
    6184:      	str	x23, [sp, #0x178]
    6188:      	mov	w23, w8
    618c:      	fmov	s31, w0
    6190:      	mov	x0, x21
    6194:      	mov	x21, x1
    6198:      	fmov	w1, s31
    619c:      	bl	0x619c <_stogir.placement.early-with-uses!+0x794>
		000000000000619c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    61a0:      	ubfx	x0, x0, #0, #32
    61a4:      	lsr	x16, x0, #0
    61a8:      	cmp	x16, #0x1
    61ac:      	b.eq	0x61c8 <_stogir.placement.early-with-uses!+0x7c0>
    61b0:      	b.lo	0x61b8 <_stogir.placement.early-with-uses!+0x7b0>
    61b4:      	b	0x61cc <_stogir.placement.early-with-uses!+0x7c4>
    61b8:      	cmp	x16, #0x0
    61bc:      	b.eq	0x61c4 <_stogir.placement.early-with-uses!+0x7bc>
    61c0:      	b	0x61cc <_stogir.placement.early-with-uses!+0x7c4>
    61c4:      	b	0x61d0 <_stogir.placement.early-with-uses!+0x7c8>
    61c8:      	b	0x6210 <_stogir.placement.early-with-uses!+0x808>
    61cc:      	b	0x6374 <_stogir.placement.early-with-uses!+0x96c>
    61d0:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		00000000000061d0:  ARM64_RELOC_PAGE21	l_stogir.431
    61d4:      	ldr	x16, [x16]
		00000000000061d4:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    61d8:      	str	x16, [sp, #0x120]
    61dc:      	mov	x27, #0x18              ; =24
    61e0:      	b	0x60a4 <_stogir.placement.early-with-uses!+0x69c>
    61e4:      	cmp	x27, #0x0
    61e8:      	b.ne	0x64f8 <_stogir.placement.early-with-uses!+0xaf0>
    61ec:      	ldr	x0, [x22]
    61f0:      	add	x0, x0, x21, lsl #2
    61f4:      	str	w23, [x0]
    61f8:      	ldr	x0, [x25]
    61fc:      	add	x0, x0, x21, lsl #4
    6200:      	ldr	x21, [x0]
    6204:      	ldr	x23, [x0, #0x8]
    6208:      	movz	x24, #0x0, lsl #48
    620c:      	b	0x5f60 <_stogir.placement.early-with-uses!+0x558>
    6210:      	sxtw	x1, w1
    6214:      	cmp	x1, #0x0
    6218:      	b.le	0x60a4 <_stogir.placement.early-with-uses!+0x69c>
    621c:      	sxtw	x23, w23
    6220:      	ldr	x0, [x19]
    6224:      	add	x0, x0, x1, lsl #2
    6228:      	ldr	w0, [x0]
    622c:      	sxtw	x0, w0
    6230:      	mov	x2, x0
    6234:      	movz	x1, #0x0, lsl #48
    6238:      	movz	x3, #0x0, lsl #48
    623c:      	b	0x624c <_stogir.placement.early-with-uses!+0x844>
    6240:      	mov	x2, x4
    6244:      	b	0x624c <_stogir.placement.early-with-uses!+0x844>
    6248:      	mov	x1, #0x1                ; =1
    624c:      	cmp	x1, #0x0
    6250:      	b.ne	0x629c <_stogir.placement.early-with-uses!+0x894>
    6254:      	cmp	x2, #0x0
    6258:      	b.le	0x6248 <_stogir.placement.early-with-uses!+0x840>
    625c:      	ldr	x4, [x20, #0x8]
    6260:      	cmp	x2, x4
    6264:      	b.ge	0x6248 <_stogir.placement.early-with-uses!+0x840>
    6268:      	ldr	x4, [x20]
    626c:      	add	x4, x4, x2, lsl #2
    6270:      	ldr	w4, [x4]
    6274:      	sxtw	x4, w4
    6278:      	cmp	x4, #0x0
    627c:      	b.ne	0x6288 <_stogir.placement.early-with-uses!+0x880>
    6280:      	mov	x1, #0x1                ; =1
    6284:      	b	0x6244 <_stogir.placement.early-with-uses!+0x83c>
    6288:      	cmp	x2, x23
    628c:      	b.ne	0x62ac <_stogir.placement.early-with-uses!+0x8a4>
    6290:      	mov	x1, #0x1                ; =1
    6294:      	mov	x3, #0x1                ; =1
    6298:      	b	0x6244 <_stogir.placement.early-with-uses!+0x83c>
    629c:      	cmp	x3, #0x0
    62a0:      	b.eq	0x5eac <_stogir.placement.early-with-uses!+0x4a4>
    62a4:      	str	x0, [sp, #0x170]
    62a8:      	b	0x60a4 <_stogir.placement.early-with-uses!+0x69c>
    62ac:      	cmp	x2, x4
    62b0:      	b.ne	0x6240 <_stogir.placement.early-with-uses!+0x838>
    62b4:      	mov	x1, #0x1                ; =1
    62b8:      	b	0x6244 <_stogir.placement.early-with-uses!+0x83c>
    62bc:      	ldr	x0, [sp, #0x100]
    62c0:      	bl	0x62c0 <_stogir.placement.early-with-uses!+0x8b8>
		00000000000062c0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    62c4:      	ldr	x0, [sp, #0x108]
    62c8:      	bl	0x62c8 <_stogir.placement.early-with-uses!+0x8c0>
		00000000000062c8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    62cc:      	ldr	x0, [sp, #0x120]
    62d0:      	mov	x1, x27
    62d4:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		00000000000062d4:  ARM64_RELOC_PAGE21	l_stogir.428
    62d8:      	ldr	x2, [x2]
		00000000000062d8:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    62dc:      	movz	x3, #0x0, lsl #48
    62e0:      	bl	0x62e0 <_stogir.placement.early-with-uses!+0x8d8>
		00000000000062e0:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    62e4:      	cmp	x0, #0x0
    62e8:      	b.eq	0x6504 <_stogir.placement.early-with-uses!+0xafc>
    62ec:      	cmp	x28, #0x0
    62f0:      	b.le	0x6308 <_stogir.placement.early-with-uses!+0x900>
    62f4:      	mov	x1, #0x1                ; =1
    62f8:      	adrp	x0, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		00000000000062f8:  ARM64_RELOC_PAGE21	l_stogir.433
    62fc:      	ldr	x0, [x0]
		00000000000062fc:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    6300:      	mov	x27, #0x39              ; =57
    6304:      	b	0x6314 <_stogir.placement.early-with-uses!+0x90c>
    6308:      	and	x0, x26, #0xffffffff
    630c:      	movz	x1, #0x0, lsl #48
    6310:      	movz	x27, #0x0, lsl #48
    6314:      	b	0x631c <_stogir.placement.early-with-uses!+0x914>
    6318:      	mov	x1, #0x1                ; =1
    631c:      	ldr	x2, [sp, #0x118]
    6320:      	str	x1, [x2]
    6324:      	str	x0, [x2, #0x8]
    6328:      	str	x27, [x2, #0x10]
    632c:      	ldr	x19, [sp, #0x188]
    6330:      	ldr	x20, [sp, #0x190]
    6334:      	ldr	x21, [sp, #0x198]
    6338:      	ldr	x22, [sp, #0x1a0]
    633c:      	ldr	x23, [sp, #0x1a8]
    6340:      	ldr	x24, [sp, #0x1b0]
    6344:      	ldr	x25, [sp, #0x1b8]
    6348:      	ldr	x26, [sp, #0x1c0]
    634c:      	ldr	x27, [sp, #0x1c8]
    6350:      	ldr	x28, [sp, #0x1d0]
    6354:      	ldr	x29, [sp, #0x10]
    6358:      	ldr	x30, [sp, #0x18]
    635c:      	add	sp, sp, #0x1e0
    6360:      	ret
    6364:      	cmp	x23, x3
    6368:      	b.ne	0x5eb8 <_stogir.placement.early-with-uses!+0x4b0>
    636c:      	mov	x1, #0x1                ; =1
    6370:      	b	0x5ebc <_stogir.placement.early-with-uses!+0x4b4>
    6374:      	brk	#0
    6378:      	b	0x6374 <_stogir.placement.early-with-uses!+0x96c>
    637c:      	brk	#0
    6380:      	b	0x637c <_stogir.placement.early-with-uses!+0x974>
    6384:      	str	x20, [sp, #0x118]
    6388:      	str	x23, [sp, #0x138]
    638c:      	str	x19, [sp, #0x100]
    6390:      	str	x26, [sp, #0x108]
    6394:      	str	x0, [sp, #0x120]
    6398:      	str	x1, [sp, #0x130]
    639c:      	b	0x5e94 <_stogir.placement.early-with-uses!+0x48c>
    63a0:      	str	x20, [sp, #0x118]
    63a4:      	str	x23, [sp, #0x138]
    63a8:      	str	x19, [sp, #0x100]
    63ac:      	str	x26, [sp, #0x108]
    63b0:      	mov	x20, x4
    63b4:      	str	x0, [sp, #0x120]
    63b8:      	str	x1, [sp, #0x130]
    63bc:      	b	0x5be8 <_stogir.placement.early-with-uses!+0x1e0>
    63c0:      	str	x20, [sp, #0x118]
    63c4:      	str	x23, [sp, #0x138]
    63c8:      	mov	x23, x7
    63cc:      	str	x19, [sp, #0x100]
    63d0:      	str	x26, [sp, #0x108]
    63d4:      	mov	x20, x4
    63d8:      	mov	w19, w2
    63dc:      	str	x0, [sp, #0x120]
    63e0:      	str	x1, [sp, #0x130]
    63e4:      	b	0x5e4c <_stogir.placement.early-with-uses!+0x444>
    63e8:      	str	x20, [sp, #0x118]
    63ec:      	str	x23, [sp, #0x138]
    63f0:      	mov	x23, x7
    63f4:      	str	x19, [sp, #0x100]
    63f8:      	str	x26, [sp, #0x108]
    63fc:      	mov	x26, x6
    6400:      	mov	x20, x4
    6404:      	mov	w19, w2
    6408:      	str	x0, [sp, #0x120]
    640c:      	str	x1, [sp, #0x130]
    6410:      	str	w5, [sp, #0x110]
    6414:      	str	x3, [sp, #0x128]
    6418:      	b	0x5d20 <_stogir.placement.early-with-uses!+0x318>
    641c:      	str	x20, [sp, #0x118]
    6420:      	str	x23, [sp, #0x138]
    6424:      	mov	x23, x7
    6428:      	str	x19, [sp, #0x100]
    642c:      	str	x26, [sp, #0x108]
    6430:      	mov	x26, x6
    6434:      	mov	x20, x4
    6438:      	mov	w19, w2
    643c:      	str	x0, [sp, #0x120]
    6440:      	str	x1, [sp, #0x130]
    6444:      	str	w5, [sp, #0x110]
    6448:      	str	x3, [sp, #0x128]
    644c:      	b	0x5d20 <_stogir.placement.early-with-uses!+0x318>
    6450:      	str	x20, [sp, #0x138]
    6454:      	str	x19, [sp, #0x180]
    6458:      	b	0x5fd4 <_stogir.placement.early-with-uses!+0x5cc>
    645c:      	str	x20, [sp, #0x138]
    6460:      	str	x19, [sp, #0x180]
    6464:      	b	0x5f54 <_stogir.placement.early-with-uses!+0x54c>
    6468:      	str	x20, [sp, #0x138]
    646c:      	str	x19, [sp, #0x180]
    6470:      	b	0x5f54 <_stogir.placement.early-with-uses!+0x54c>
    6474:      	str	x20, [sp, #0x138]
    6478:      	str	x19, [sp, #0x180]
    647c:      	mov	w19, w0
    6480:      	mov	x20, x1
    6484:      	b	0x5f38 <_stogir.placement.early-with-uses!+0x530>
    6488:      	str	x23, [sp, #0x178]
    648c:      	str	x21, [sp, #0x140]
    6490:      	str	x24, [sp, #0x168]
    6494:      	mov	x21, x1
    6498:      	mov	w23, w8
    649c:      	b	0x61e4 <_stogir.placement.early-with-uses!+0x7dc>
    64a0:      	str	x23, [sp, #0x178]
    64a4:      	str	x6, [sp, #0x170]
    64a8:      	str	x21, [sp, #0x140]
    64ac:      	str	x24, [sp, #0x168]
    64b0:      	mov	x24, x5
    64b4:      	mov	x21, x1
    64b8:      	str	x3, [sp, #0x160]
    64bc:      	str	w0, [sp, #0x148]
    64c0:      	str	w4, [sp, #0x150]
    64c4:      	str	x2, [sp, #0x158]
    64c8:      	b	0x60a4 <_stogir.placement.early-with-uses!+0x69c>
    64cc:      	str	x23, [sp, #0x178]
    64d0:      	str	x6, [sp, #0x170]
    64d4:      	str	x21, [sp, #0x140]
    64d8:      	str	x24, [sp, #0x168]
    64dc:      	mov	x24, x5
    64e0:      	mov	x21, x1
    64e4:      	str	x3, [sp, #0x160]
    64e8:      	str	w0, [sp, #0x148]
    64ec:      	str	w4, [sp, #0x150]
    64f0:      	str	x2, [sp, #0x158]
    64f4:      	b	0x60a4 <_stogir.placement.early-with-uses!+0x69c>
    64f8:      	str	x20, [sp, #0x138]
    64fc:      	str	x19, [sp, #0x180]
    6500:      	b	0x5fe4 <_stogir.placement.early-with-uses!+0x5dc>
    6504:      	ldr	x0, [sp, #0x120]
    6508:      	b	0x6318 <_stogir.placement.early-with-uses!+0x910>

000000000000650c <_coil.core.Eq$slice<u8>$=>:
    650c:      	sub	sp, sp, #0x10
    6510:      	str	x29, [sp]
    6514:      	str	x30, [sp, #0x8]
    6518:      	mov	x29, sp
    651c:      	cmp	x1, x3
    6520:      	b.ne	0x655c <_coil.core.Eq$slice<u8>$=+0x50>
    6524:      	cmp	x1, #0x0
    6528:      	b.ne	0x6534 <_coil.core.Eq$slice<u8>$=+0x28>
    652c:      	mov	x0, #0x1                ; =1
    6530:      	b	0x6558 <_coil.core.Eq$slice<u8>$=+0x4c>
    6534:      	lsr	x1, x1, #0
    6538:      	fmov	d31, x1
    653c:      	mov	x1, x2
    6540:      	fmov	x2, d31
    6544:      	bl	0x6544 <_coil.core.Eq$slice<u8>$=+0x38>
		0000000000006544:  ARM64_RELOC_BRANCH26	_memcmp
    6548:      	sxtw	x0, w0
    654c:      	cmp	x0, #0x0
    6550:      	cset	w0, eq
    6554:      	ubfx	x0, x0, #0, #8
    6558:      	b	0x6560 <_coil.core.Eq$slice<u8>$=+0x54>
    655c:      	movz	x0, #0x0, lsl #48
    6560:      	ldr	x29, [sp]
    6564:      	ldr	x30, [sp, #0x8]
    6568:      	add	sp, sp, #0x10
    656c:      	ret

0000000000006570 <_stogir.placement.late-with-uses!>:
    6570:      	sub	sp, sp, #0x1f0
    6574:      	str	x29, [sp]
    6578:      	str	x30, [sp, #0x8]
    657c:      	mov	x29, sp
    6580:      	str	x19, [sp, #0x1a0]
    6584:      	str	x20, [sp, #0x1a8]
    6588:      	str	x21, [sp, #0x1b0]
    658c:      	str	x22, [sp, #0x1b8]
    6590:      	str	x23, [sp, #0x1c0]
    6594:      	str	x24, [sp, #0x1c8]
    6598:      	str	x25, [sp, #0x1d0]
    659c:      	str	x26, [sp, #0x1d8]
    65a0:      	str	x27, [sp, #0x1e0]
    65a4:      	str	x28, [sp, #0x1e8]
    65a8:      	add	x16, sp, #0x10
    65ac:      	orr	x19, x16, xzr
    65b0:      	mov	x20, x8
    65b4:      	add	x8, sp, #0x40
    65b8:      	mov	x21, x0
    65bc:      	mov	x0, x6
    65c0:      	mov	x22, x1
    65c4:      	mov	x23, x2
    65c8:      	mov	x24, x3
    65cc:      	mov	x25, x4
    65d0:      	mov	x26, x5
    65d4:      	mov	x27, x6
    65d8:      	bl	0x65d8 <_stogir.placement.late-with-uses!+0x68>
		00000000000065d8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    65dc:      	add	x16, sp, #0x40
    65e0:      	ldr	x0, [x16]
    65e4:      	add	x16, sp, #0x10
    65e8:      	str	x0, [x16]
    65ec:      	add	x16, sp, #0x40
    65f0:      	ldr	x0, [x16, #0x8]
    65f4:      	add	x16, sp, #0x10
    65f8:      	str	x0, [x16, #0x8]
    65fc:      	add	x16, sp, #0x40
    6600:      	ldr	x0, [x16, #0x10]
    6604:      	add	x16, sp, #0x10
    6608:      	str	x0, [x16, #0x10]
    660c:      	add	x16, sp, #0x40
    6610:      	ldr	x0, [x16, #0x18]
    6614:      	add	x16, sp, #0x10
    6618:      	str	x0, [x16, #0x18]
    661c:      	add	x16, sp, #0x40
    6620:      	ldr	x0, [x16, #0x20]
    6624:      	add	x16, sp, #0x10
    6628:      	str	x0, [x16, #0x20]
    662c:      	add	x8, sp, #0xa0
    6630:      	mov	x0, x27
    6634:      	bl	0x6634 <_stogir.placement.late-with-uses!+0xc4>
		0000000000006634:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    6638:      	add	x16, sp, #0xa0
    663c:      	ldr	x0, [x16]
    6640:      	add	x16, sp, #0x70
    6644:      	str	x0, [x16]
    6648:      	add	x16, sp, #0xa0
    664c:      	ldr	x0, [x16, #0x8]
    6650:      	add	x16, sp, #0x70
    6654:      	str	x0, [x16, #0x8]
    6658:      	add	x16, sp, #0xa0
    665c:      	ldr	x0, [x16, #0x10]
    6660:      	add	x16, sp, #0x70
    6664:      	str	x0, [x16, #0x10]
    6668:      	add	x16, sp, #0xa0
    666c:      	ldr	x0, [x16, #0x18]
    6670:      	add	x16, sp, #0x70
    6674:      	str	x0, [x16, #0x18]
    6678:      	add	x16, sp, #0xa0
    667c:      	ldr	x0, [x16, #0x20]
    6680:      	add	x16, sp, #0x70
    6684:      	str	x0, [x16, #0x20]
    6688:      	movz	x27, #0x0, lsl #48
    668c:      	b	0x66a4 <_stogir.placement.late-with-uses!+0x134>
    6690:      	add	x27, x27, #0x1
    6694:      	mov	x0, x19
    6698:      	mov	x1, #0xffff             ; =65535
    669c:      	movk	x1, #0xffff, lsl #16
    66a0:      	bl	0x66a0 <_stogir.placement.late-with-uses!+0x130>
		00000000000066a0:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    66a4:      	ldr	x0, [x21, #0x8]
    66a8:      	cmp	x27, x0
    66ac:      	b.lt	0x6690 <_stogir.placement.late-with-uses!+0x120>
    66b0:      	mov	x27, #0x1               ; =1
    66b4:      	movz	x28, #0x0, lsl #48
    66b8:      	b	0x66f8 <_stogir.placement.late-with-uses!+0x188>
    66bc:      	nop
    66c0:      	add	x28, x28, #0x1
    66c4:      	ldr	x0, [sp, #0x110]
    66c8:      	mov	x1, x27
    66cc:      	movz	x2, #0x0, lsl #48
    66d0:      	bl	0x66d0 <_stogir.placement.late-with-uses!+0x160>
		00000000000066d0:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    66d4:      	sxtw	x28, w28
    66d8:      	sxtw	x19, w19
    66dc:      	add	x0, x19, #0x4
    66e0:      	asr	x16, x0, #63
    66e4:      	lsr	x16, x16, #62
    66e8:      	add	x0, x0, x16
    66ec:      	asr	x0, x0, #2
    66f0:      	add	x27, x0, x27
    66f4:      	ldr	x19, [sp, #0x110]
    66f8:      	ldr	x0, [x21, #0x8]
    66fc:      	cmp	x27, x0
    6700:      	b.ge	0x7050 <_stogir.placement.late-with-uses!+0xae0>
    6704:      	ldr	x0, [x21]
    6708:      	add	x0, x0, x27, lsl #4
    670c:      	ldr	x0, [x0]
    6710:      	ldr	x1, [x21, #0x78]
    6714:      	uxtb	w0, w0
    6718:      	add	x1, x1, x27, lsl #2
    671c:      	ldr	w1, [x1]
    6720:      	str	x19, [sp, #0x110]
    6724:      	mov	w19, w1
    6728:      	bl	0x6728 <_stogir.placement.late-with-uses!+0x1b8>
		0000000000006728:  ARM64_RELOC_BRANCH26	_stogir.opcode.properties
    672c:      	ldr	x1, [x25]
    6730:      	add	x1, x27, x1
    6734:      	ldrb	w1, [x1]
    6738:      	cmp	x1, #0x0
    673c:      	b.eq	0x66d8 <_stogir.placement.late-with-uses!+0x168>
    6740:      	uxtb	w0, w0
    6744:      	uxtb	w16, w0
    6748:      	and	w0, w16, #0x40
    674c:      	uxtb	w0, w0
    6750:      	ubfx	x0, x0, #0, #8
    6754:      	cmp	x0, #0x0
    6758:      	b.ne	0x66c0 <_stogir.placement.late-with-uses!+0x150>
    675c:      	b	0x66d8 <_stogir.placement.late-with-uses!+0x168>
    6760:      	add	x16, sp, #0x70
    6764:      	orr	x19, x16, xzr
    6768:      	mov	x27, #0x1               ; =1
    676c:      	b	0x67f4 <_stogir.placement.late-with-uses!+0x284>
    6770:      	add	x3, x3, #0x1
    6774:      	sxtw	x3, w3
    6778:      	add	x2, x2, #0x1
    677c:      	cmp	x2, x0
    6780:      	b.ge	0x67b8 <_stogir.placement.late-with-uses!+0x248>
    6784:      	add	x4, x1, x2
    6788:      	ldr	x5, [x26, #0x28]
    678c:      	add	x4, x5, x4, lsl #3
    6790:      	ldr	x4, [x4]
    6794:      	add	x16, sp, #0x10
    6798:      	ldr	x5, [x16]
    679c:      	sxtw	x4, w4
    67a0:      	add	x4, x5, x4, lsl #2
    67a4:      	ldr	w4, [x4]
    67a8:      	sxtw	x4, w4
    67ac:      	cmp	x4, #0x0
    67b0:      	b.ge	0x6770 <_stogir.placement.late-with-uses!+0x200>
    67b4:      	b	0x6778 <_stogir.placement.late-with-uses!+0x208>
    67b8:      	orr	w0, w3, wzr
    67bc:      	mov	x1, x27
    67c0:      	mov	w2, w0
    67c4:      	ldr	x0, [sp, #0x110]
    67c8:      	str	x19, [sp, #0x118]
    67cc:      	mov	x19, x3
    67d0:      	bl	0x67d0 <_stogir.placement.late-with-uses!+0x260>
		00000000000067d0:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    67d4:      	cmp	x19, #0x0
    67d8:      	b.ne	0x67ec <_stogir.placement.late-with-uses!+0x27c>
    67dc:      	orr	w0, w27, wzr
    67e0:      	mov	w1, w0
    67e4:      	ldr	x0, [sp, #0x118]
    67e8:      	bl	0x67e8 <_stogir.placement.late-with-uses!+0x278>
		00000000000067e8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    67ec:      	add	x27, x27, #0x1
    67f0:      	ldr	x19, [sp, #0x118]
    67f4:      	add	x16, sp, #0x10
    67f8:      	ldr	x0, [x16, #0x8]
    67fc:      	cmp	x27, x0
    6800:      	b.ge	0x7058 <_stogir.placement.late-with-uses!+0xae8>
    6804:      	add	x16, sp, #0x10
    6808:      	ldr	x0, [x16]
    680c:      	add	x0, x0, x27, lsl #2
    6810:      	ldr	w0, [x0]
    6814:      	sxtw	x0, w0
    6818:      	cmp	x0, #0x0
    681c:      	b.ne	0x7060 <_stogir.placement.late-with-uses!+0xaf0>
    6820:      	ldr	x0, [x26]
    6824:      	add	x0, x0, x27, lsl #4
    6828:      	ldr	x1, [x0]
    682c:      	ldr	x0, [x0, #0x8]
    6830:      	movz	x2, #0x0, lsl #48
    6834:      	movz	x3, #0x0, lsl #48
    6838:      	b	0x677c <_stogir.placement.late-with-uses!+0x20c>
    683c:      	add	x16, sp, #0xd0
    6840:      	orr	x0, x16, xzr
    6844:      	add	x16, sp, #0xf0
    6848:      	orr	x1, x16, xzr
    684c:      	add	x19, x21, #0x78
    6850:      	add	x27, x0, #0x8
    6854:      	add	x0, x1, #0x8
    6858:      	movz	x1, #0x0, lsl #48
    685c:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		000000000000685c:  ARM64_RELOC_PAGE21	l_stogir.434
    6860:      	ldr	x2, [x2]
		0000000000006860:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    6864:      	movz	x3, #0x0, lsl #48
    6868:      	b	0x68bc <_stogir.placement.late-with-uses!+0x34c>
    686c:      	movz	w6, #0x0, lsl #16
    6870:      	movz	w5, #0x0, lsl #16
    6874:      	b	0x6c84 <_stogir.placement.late-with-uses!+0x714>
    6878:      	ldr	x20, [sp, #0x130]
    687c:      	sub	x0, x20, #0x1
    6880:      	sxtw	x20, w0
    6884:      	ldr	x0, [sp, #0x160]
    6888:      	add	x0, x0, #0x1
    688c:      	mov	x21, x26
    6890:      	ldr	x22, [sp, #0x198]
    6894:      	ldr	x24, [sp, #0x120]
    6898:      	ldr	x26, [sp, #0x158]
    689c:      	ldr	x25, [sp, #0x140]
    68a0:      	mov	x1, x0
    68a4:      	ldr	x0, [sp, #0x170]
    68a8:      	mov	x2, x28
    68ac:      	mov	x28, x20
    68b0:      	ldr	x20, [sp, #0x128]
    68b4:      	mov	x3, x19
    68b8:      	ldr	x19, [sp, #0x138]
    68bc:      	str	x24, [sp, #0x120]
    68c0:      	mov	x24, x0
    68c4:      	mov	x0, x2
    68c8:      	str	x20, [sp, #0x128]
    68cc:      	mov	x20, x1
    68d0:      	mov	x1, x3
    68d4:      	str	x28, [sp, #0x130]
    68d8:      	mov	x28, x2
    68dc:      	str	x19, [sp, #0x138]
    68e0:      	mov	x19, x3
    68e4:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		00000000000068e4:  ARM64_RELOC_PAGE21	l_stogir.434
    68e8:      	ldr	x2, [x2]
		00000000000068e8:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    68ec:      	movz	x3, #0x0, lsl #48
    68f0:      	bl	0x68f0 <_stogir.placement.late-with-uses!+0x380>
		00000000000068f0:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    68f4:      	cmp	x0, #0x0
    68f8:      	b.eq	0x6914 <_stogir.placement.late-with-uses!+0x3a4>
    68fc:      	add	x16, sp, #0x70
    6900:      	ldr	x0, [x16, #0x8]
    6904:      	cmp	x20, x0
    6908:      	cset	w0, lt
    690c:      	ubfx	x0, x0, #0, #8
    6910:      	b	0x6918 <_stogir.placement.late-with-uses!+0x3a8>
    6914:      	movz	x0, #0x0, lsl #48
    6918:      	cmp	x0, #0x0
    691c:      	b.eq	0x7068 <_stogir.placement.late-with-uses!+0xaf8>
    6920:      	add	x16, sp, #0x70
    6924:      	ldr	x0, [x16]
    6928:      	add	x0, x0, x20, lsl #2
    692c:      	ldr	w0, [x0]
    6930:      	sxtw	x0, w0
    6934:      	ldr	x1, [x26]
    6938:      	add	x1, x1, x0, lsl #4
    693c:      	ldr	x2, [x1]
    6940:      	ldr	x1, [x1, #0x8]
    6944:      	movz	x3, #0x0, lsl #48
    6948:      	movz	w4, #0x0, lsl #16
    694c:      	b	0x6980 <_stogir.placement.late-with-uses!+0x410>
    6950:      	movz	x20, #0x0, lsl #48
    6954:      	add	x26, x26, #0x1
    6958:      	ldr	x21, [sp, #0x168]
    695c:      	mov	x0, x25
    6960:      	ldr	x2, [sp, #0x148]
    6964:      	ldr	x1, [sp, #0x150]
    6968:      	ldr	x25, [sp, #0x140]
    696c:      	ldr	x24, [sp, #0x170]
    6970:      	mov	x3, x26
    6974:      	ldr	x26, [sp, #0x158]
    6978:      	mov	w4, w20
    697c:      	ldr	x20, [sp, #0x160]
    6980:      	cmp	x19, #0x0
    6984:      	b.ne	0x6998 <_stogir.placement.late-with-uses!+0x428>
    6988:      	cmp	x3, x1
    698c:      	cset	w5, lt
    6990:      	ubfx	x5, x5, #0, #8
    6994:      	b	0x699c <_stogir.placement.late-with-uses!+0x42c>
    6998:      	movz	x5, #0x0, lsl #48
    699c:      	sxtw	x6, w4
    69a0:      	cmp	x6, #0x0
    69a4:      	cset	w7, eq
    69a8:      	cmp	x5, #0x0
    69ac:      	b.eq	0x7070 <_stogir.placement.late-with-uses!+0xb00>
    69b0:      	add	x5, x2, x3
    69b4:      	ldr	x8, [x26, #0x28]
    69b8:      	add	x5, x8, x5, lsl #3
    69bc:      	ldr	x5, [x5]
    69c0:      	ldr	x8, [x25]
    69c4:      	orr	w9, w5, wzr
    69c8:      	sxtw	x10, w9
    69cc:      	add	x8, x8, x10
    69d0:      	ldrb	w8, [x8]
    69d4:      	cmp	x8, #0x0
    69d8:      	b.eq	0x7094 <_stogir.placement.late-with-uses!+0xb24>
    69dc:      	lsr	x5, x5, #32
    69e0:      	add	x8, sp, #0xd0
    69e4:      	str	x2, [sp, #0x148]
    69e8:      	mov	w2, w9
    69ec:      	str	x1, [sp, #0x150]
    69f0:      	mov	x1, x22
    69f4:      	str	x25, [sp, #0x140]
    69f8:      	mov	x25, x0
    69fc:      	mov	x0, x21
    6a00:      	str	x26, [sp, #0x158]
    6a04:      	mov	x26, x3
    6a08:      	mov	w3, w5
    6a0c:      	str	x20, [sp, #0x160]
    6a10:      	mov	w20, w4
    6a14:      	str	x21, [sp, #0x168]
    6a18:      	mov	x21, x6
    6a1c:      	str	x24, [sp, #0x170]
    6a20:      	mov	w24, w7
    6a24:      	bl	0x6a24 <_stogir.placement.late-with-uses!+0x4b4>
		0000000000006a24:  ARM64_RELOC_BRANCH26	_stogir.placement.use-block
    6a28:      	add	x16, sp, #0xd0
    6a2c:      	ldr	w0, [x16]
    6a30:      	lsr	x16, x0, #0
    6a34:      	cmp	x16, #0x1
    6a38:      	b.eq	0x6a54 <_stogir.placement.late-with-uses!+0x4e4>
    6a3c:      	b.lo	0x6a44 <_stogir.placement.late-with-uses!+0x4d4>
    6a40:      	b	0x6a58 <_stogir.placement.late-with-uses!+0x4e8>
    6a44:      	cmp	x16, #0x0
    6a48:      	b.eq	0x6a50 <_stogir.placement.late-with-uses!+0x4e0>
    6a4c:      	b	0x6a58 <_stogir.placement.late-with-uses!+0x4e8>
    6a50:      	b	0x6a6c <_stogir.placement.late-with-uses!+0x4fc>
    6a54:      	b	0x6a5c <_stogir.placement.late-with-uses!+0x4ec>
    6a58:      	b	0x6f08 <_stogir.placement.late-with-uses!+0x998>
    6a5c:      	add	x16, sp, #0xd0
    6a60:      	ldr	x28, [x16, #0x8]
    6a64:      	ldr	x19, [x27, #0x8]
    6a68:      	b	0x6954 <_stogir.placement.late-with-uses!+0x3e4>
    6a6c:      	add	x16, sp, #0xd0
    6a70:      	ldr	w0, [x16, #0x8]
    6a74:      	orr	w1, w0, wzr
    6a78:      	uxtb	w16, w24
    6a7c:      	cmp	w16, wzr
    6a80:      	b.eq	0x6abc <_stogir.placement.late-with-uses!+0x54c>
    6a84:      	mov	w20, w1
    6a88:      	b	0x6954 <_stogir.placement.late-with-uses!+0x3e4>
    6a8c:      	mov	x0, x28
    6a90:      	mov	x1, x19
    6a94:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		0000000000006a94:  ARM64_RELOC_PAGE21	l_stogir.434
    6a98:      	ldr	x2, [x2]
		0000000000006a98:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    6a9c:      	movz	x3, #0x0, lsl #48
    6aa0:      	bl	0x6aa0 <_stogir.placement.late-with-uses!+0x530>
		0000000000006aa0:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6aa4:      	cmp	x0, #0x0
    6aa8:      	b.eq	0x6b1c <_stogir.placement.late-with-uses!+0x5ac>
    6aac:      	uxtb	w16, w24
    6ab0:      	cmp	w16, wzr
    6ab4:      	cset	x0, eq
    6ab8:      	b	0x6b20 <_stogir.placement.late-with-uses!+0x5b0>
    6abc:      	cmp	x21, #0x0
    6ac0:      	b.le	0x6950 <_stogir.placement.late-with-uses!+0x3e0>
    6ac4:      	sxtw	x0, w0
    6ac8:      	cmp	x0, #0x0
    6acc:      	b.le	0x6950 <_stogir.placement.late-with-uses!+0x3e0>
    6ad0:      	ldr	x2, [x23, #0x8]
    6ad4:      	cmp	x21, x2
    6ad8:      	b.ge	0x6950 <_stogir.placement.late-with-uses!+0x3e0>
    6adc:      	cmp	x0, x2
    6ae0:      	b.ge	0x6950 <_stogir.placement.late-with-uses!+0x3e0>
    6ae4:      	ldr	x2, [x23]
    6ae8:      	add	x3, x2, x21, lsl #2
    6aec:      	ldr	w3, [x3]
    6af0:      	sxtw	x3, w3
    6af4:      	cmp	x3, #0x0
    6af8:      	b.eq	0x6f00 <_stogir.placement.late-with-uses!+0x990>
    6afc:      	add	x0, x2, x0, lsl #2
    6b00:      	ldr	w0, [x0]
    6b04:      	sxtw	x0, w0
    6b08:      	cmp	x0, #0x0
    6b0c:      	b.eq	0x6f00 <_stogir.placement.late-with-uses!+0x990>
    6b10:      	mov	w2, w20
    6b14:      	movz	x0, #0x0, lsl #48
    6b18:      	b	0x7018 <_stogir.placement.late-with-uses!+0xaa8>
    6b1c:      	movz	x0, #0x0, lsl #48
    6b20:      	lsl	x21, x25, #2
    6b24:      	cmp	x0, #0x0
    6b28:      	b.eq	0x70c0 <_stogir.placement.late-with-uses!+0xb50>
    6b2c:      	ldr	x0, [x22]
    6b30:      	add	x0, x21, x0
    6b34:      	ldr	w0, [x0]
    6b38:      	add	x8, sp, #0xf0
    6b3c:      	ldr	x1, [sp, #0x120]
    6b40:      	mov	w2, w0
    6b44:      	mov	x0, x23
    6b48:      	mov	w3, w20
    6b4c:      	bl	0x6b4c <_stogir.placement.late-with-uses!+0x5dc>
		0000000000006b4c:  ARM64_RELOC_BRANCH26	_stogir.placement.choose-block
    6b50:      	add	x16, sp, #0xf0
    6b54:      	ldr	w0, [x16]
    6b58:      	lsr	x16, x0, #0
    6b5c:      	cmp	x16, #0x1
    6b60:      	b.eq	0x6b80 <_stogir.placement.late-with-uses!+0x610>
    6b64:      	b.lo	0x6b6c <_stogir.placement.late-with-uses!+0x5fc>
    6b68:      	b	0x6b84 <_stogir.placement.late-with-uses!+0x614>
    6b6c:      	cmp	x16, #0x0
    6b70:      	b.eq	0x6b78 <_stogir.placement.late-with-uses!+0x608>
    6b74:      	b	0x6b84 <_stogir.placement.late-with-uses!+0x614>
    6b78:      	ldr	x20, [sp, #0x170]
    6b7c:      	b	0x6b9c <_stogir.placement.late-with-uses!+0x62c>
    6b80:      	b	0x6b88 <_stogir.placement.late-with-uses!+0x618>
    6b84:      	b	0x7048 <_stogir.placement.late-with-uses!+0xad8>
    6b88:      	add	x16, sp, #0xf0
    6b8c:      	ldr	x28, [x16, #0x8]
    6b90:      	ldr	x20, [sp, #0x170]
    6b94:      	ldr	x19, [x20, #0x8]
    6b98:      	b	0x6bb4 <_stogir.placement.late-with-uses!+0x644>
    6b9c:      	add	x16, sp, #0xf0
    6ba0:      	ldr	w0, [x16, #0x8]
    6ba4:      	mov	x1, x25
    6ba8:      	mov	w2, w0
    6bac:      	mov	x0, x22
    6bb0:      	bl	0x6bb0 <_stogir.placement.late-with-uses!+0x640>
		0000000000006bb0:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    6bb4:      	mov	x0, x28
    6bb8:      	mov	x1, x19
    6bbc:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		0000000000006bbc:  ARM64_RELOC_PAGE21	l_stogir.434
    6bc0:      	ldr	x2, [x2]
		0000000000006bc0:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    6bc4:      	movz	x3, #0x0, lsl #48
    6bc8:      	bl	0x6bc8 <_stogir.placement.late-with-uses!+0x658>
		0000000000006bc8:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6bcc:      	cmp	x0, #0x0
    6bd0:      	b.eq	0x70c8 <_stogir.placement.late-with-uses!+0xb58>
    6bd4:      	cmp	x25, #0x0
    6bd8:      	cset	w24, le
    6bdc:      	ldr	x26, [sp, #0x168]
    6be0:      	ldr	x0, [x26]
    6be4:      	add	x0, x0, x25, lsl #4
    6be8:      	ldr	x0, [x0]
    6bec:      	ldr	x1, [x26, #0x78]
    6bf0:      	uxtb	w0, w0
    6bf4:      	add	x1, x1, x25, lsl #2
    6bf8:      	cmp	x0, #0x83
    6bfc:      	cset	w2, lt
    6c00:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		0000000000006c00:  ARM64_RELOC_PAGE21	l_stogir.435
    6c04:      	ldr	x16, [x16]
		0000000000006c04:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    6c08:      	add	x0, x16, x0, lsl #2
    6c0c:      	ldr	w1, [x1]
    6c10:      	sxtw	x1, w1
    6c14:      	mov	x3, #0x1                ; =1
    6c18:      	b	0x6d04 <_stogir.placement.late-with-uses!+0x794>
    6c1c:      	sub	w4, w4, #0x1
    6c20:      	lsl	w4, w4, #2
    6c24:      	ubfx	x4, x4, #0, #32
    6c28:      	lsr	x4, x6, x4
    6c2c:      	and	w4, w4, #0xf
    6c30:      	b	0x6c38 <_stogir.placement.late-with-uses!+0x6c8>
    6c34:      	movz	w4, #0x0, lsl #16
    6c38:      	b	0x6c44 <_stogir.placement.late-with-uses!+0x6d4>
    6c3c:      	nop
    6c40:      	movz	w4, #0x0, lsl #16
    6c44:      	ubfx	x4, x4, #0, #32
    6c48:      	cmp	x4, #0xf
    6c4c:      	b.hs	0x70dc <_stogir.placement.late-with-uses!+0xb6c>
    6c50:      	mov	x16, #0x1               ; =1
    6c54:      	lsl	x4, x16, x4
    6c58:      	mov	w17, #0x5e1c            ; =24092
    6c5c:      	and	w4, w4, w17
    6c60:      	ubfx	x4, x4, #0, #32
    6c64:      	cmp	x4, #0x0
    6c68:      	b.eq	0x70fc <_stogir.placement.late-with-uses!+0xb8c>
    6c6c:      	uxtb	w16, w24
    6c70:      	cmp	w16, wzr
    6c74:      	b.eq	0x6d3c <_stogir.placement.late-with-uses!+0x7cc>
    6c78:      	ldr	x4, [sp, #0x138]
    6c7c:      	movz	w6, #0x0, lsl #16
    6c80:      	movz	w5, #0x0, lsl #16
    6c84:      	ubfx	x6, x6, #0, #32
    6c88:      	lsr	x16, x6, #0
    6c8c:      	cmp	x16, #0x1
    6c90:      	b.eq	0x6cac <_stogir.placement.late-with-uses!+0x73c>
    6c94:      	b.lo	0x6c9c <_stogir.placement.late-with-uses!+0x72c>
    6c98:      	b	0x6cb0 <_stogir.placement.late-with-uses!+0x740>
    6c9c:      	cmp	x16, #0x0
    6ca0:      	b.eq	0x6ca8 <_stogir.placement.late-with-uses!+0x738>
    6ca4:      	b	0x6cb0 <_stogir.placement.late-with-uses!+0x740>
    6ca8:      	b	0x6cb4 <_stogir.placement.late-with-uses!+0x744>
    6cac:      	b	0x6d78 <_stogir.placement.late-with-uses!+0x808>
    6cb0:      	b	0x7040 <_stogir.placement.late-with-uses!+0xad0>
    6cb4:      	str	x22, [sp, #0x198]
    6cb8:      	str	x21, [sp, #0x190]
    6cbc:      	str	x20, [sp, #0x170]
    6cc0:      	mov	x20, x3
    6cc4:      	str	x1, [sp, #0x188]
    6cc8:      	str	w2, [sp, #0x178]
    6ccc:      	str	x0, [sp, #0x180]
    6cd0:      	str	x4, [sp, #0x138]
    6cd4:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		0000000000006cd4:  ARM64_RELOC_PAGE21	l_stogir.436
    6cd8:      	ldr	x28, [x28]
		0000000000006cd8:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    6cdc:      	mov	x19, #0x1e              ; =30
    6ce0:      	add	x0, x20, #0x1
    6ce4:      	sxtw	x20, w0
    6ce8:      	ldr	x22, [sp, #0x198]
    6cec:      	ldr	x21, [sp, #0x190]
    6cf0:      	ldr	x1, [sp, #0x188]
    6cf4:      	ldr	w2, [sp, #0x178]
    6cf8:      	ldr	x0, [sp, #0x180]
    6cfc:      	mov	x3, x20
    6d00:      	ldr	x20, [sp, #0x170]
    6d04:      	cmp	x3, x1
    6d08:      	b.gt	0x711c <_stogir.placement.late-with-uses!+0xbac>
    6d0c:      	orr	w4, w3, wzr
    6d10:      	sxtw	x5, w4
    6d14:      	uxtb	w16, w2
    6d18:      	cmp	w16, wzr
    6d1c:      	b.eq	0x6c40 <_stogir.placement.late-with-uses!+0x6d0>
    6d20:      	ldr	w6, [x0]
    6d24:      	cmp	x5, #0x0
    6d28:      	b.le	0x6c34 <_stogir.placement.late-with-uses!+0x6c4>
    6d2c:      	cmp	x5, #0x4
    6d30:      	b.le	0x6c1c <_stogir.placement.late-with-uses!+0x6ac>
    6d34:      	mov	w4, #0x4                ; =4
    6d38:      	b	0x6c20 <_stogir.placement.late-with-uses!+0x6b0>
    6d3c:      	ldr	x4, [x26, #0x8]
    6d40:      	cmp	x25, x4
    6d44:      	b.ge	0x7128 <_stogir.placement.late-with-uses!+0xbb8>
    6d48:      	ldr	x4, [sp, #0x138]
    6d4c:      	ldr	x6, [x4, #0x8]
    6d50:      	cmp	x25, x6
    6d54:      	b.ge	0x6ddc <_stogir.placement.late-with-uses!+0x86c>
    6d58:      	ldr	x6, [x26, #0x78]
    6d5c:      	add	x6, x21, x6
    6d60:      	ldr	w6, [x6]
    6d64:      	sxtw	x6, w6
    6d68:      	cmp	x6, #0x0
    6d6c:      	cset	w6, ge
    6d70:      	ubfx	x6, x6, #0, #8
    6d74:      	b	0x6de0 <_stogir.placement.late-with-uses!+0x870>
    6d78:      	sxtw	x6, w5
    6d7c:      	cmp	x6, #0x0
    6d80:      	b.le	0x7130 <_stogir.placement.late-with-uses!+0xbc0>
    6d84:      	add	x16, sp, #0x10
    6d88:      	ldr	x7, [x16]
    6d8c:      	add	x8, x7, x6, lsl #2
    6d90:      	ldr	w8, [x8]
    6d94:      	sxtw	x9, w8
    6d98:      	cmp	x9, #0x0
    6d9c:      	b.le	0x7154 <_stogir.placement.late-with-uses!+0xbe4>
    6da0:      	sub	w8, w8, #0x1
    6da4:      	add	x6, x7, x6, lsl #2
    6da8:      	str	w8, [x6]
    6dac:      	cmp	x9, #0x1
    6db0:      	b.ne	0x7178 <_stogir.placement.late-with-uses!+0xc08>
    6db4:      	add	x16, sp, #0x70
    6db8:      	ldr	x6, [x16, #0x8]
    6dbc:      	add	x16, sp, #0x70
    6dc0:      	ldr	x7, [x16, #0x10]
    6dc4:      	cmp	x6, x7
    6dc8:      	b.lt	0x719c <_stogir.placement.late-with-uses!+0xc2c>
    6dcc:      	cmp	x7, #0x0
    6dd0:      	b.ne	0x6f10 <_stogir.placement.late-with-uses!+0x9a0>
    6dd4:      	mov	x7, #0x2                ; =2
    6dd8:      	b	0x6f14 <_stogir.placement.late-with-uses!+0x9a4>
    6ddc:      	movz	x6, #0x0, lsl #48
    6de0:      	b	0x6de8 <_stogir.placement.late-with-uses!+0x878>
    6de4:      	movz	x6, #0x0, lsl #48
    6de8:      	cmp	x6, #0x0
    6dec:      	b.eq	0x6c7c <_stogir.placement.late-with-uses!+0x70c>
    6df0:      	cmp	x5, #0x1
    6df4:      	b.lt	0x686c <_stogir.placement.late-with-uses!+0x2fc>
    6df8:      	ldr	x6, [x26, #0x78]
    6dfc:      	add	x6, x21, x6
    6e00:      	ldr	w6, [x6]
    6e04:      	sxtw	x6, w6
    6e08:      	cmp	x5, x6
    6e0c:      	b.gt	0x686c <_stogir.placement.late-with-uses!+0x2fc>
    6e10:      	ldr	x6, [x26]
    6e14:      	asr	x16, x5, #63
    6e18:      	lsr	x16, x16, #62
    6e1c:      	add	x7, x5, x16
    6e20:      	asr	x7, x7, #2
    6e24:      	asr	x16, x5, #63
    6e28:      	lsr	x16, x16, #62
    6e2c:      	add	x5, x5, x16
    6e30:      	and	x5, x5, #0x3
    6e34:      	sub	x5, x5, x16
    6e38:      	add	x7, x7, x25
    6e3c:      	add	x6, x6, x7, lsl #4
    6e40:      	add	x5, x6, x5, lsl #2
    6e44:      	ldr	w5, [x5]
    6e48:      	movn	w17, #0x0, lsl #16
    6e4c:      	and	w5, w5, w17
    6e50:      	mov	w6, #0x1                ; =1
    6e54:      	b	0x6874 <_stogir.placement.late-with-uses!+0x304>
    6e58:      	ldr	x0, [sp, #0x110]
    6e5c:      	bl	0x6e5c <_stogir.placement.late-with-uses!+0x8ec>
		0000000000006e5c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    6e60:      	ldr	x0, [sp, #0x118]
    6e64:      	bl	0x6e64 <_stogir.placement.late-with-uses!+0x8f4>
		0000000000006e64:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    6e68:      	mov	x0, x28
    6e6c:      	mov	x1, x19
    6e70:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		0000000000006e70:  ARM64_RELOC_PAGE21	l_stogir.434
    6e74:      	ldr	x2, [x2]
		0000000000006e74:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    6e78:      	movz	x3, #0x0, lsl #48
    6e7c:      	bl	0x6e7c <_stogir.placement.late-with-uses!+0x90c>
		0000000000006e7c:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6e80:      	cmp	x0, #0x0
    6e84:      	b.eq	0x6eb4 <_stogir.placement.late-with-uses!+0x944>
    6e88:      	cmp	x20, #0x0
    6e8c:      	b.le	0x6ea4 <_stogir.placement.late-with-uses!+0x934>
    6e90:      	mov	x0, #0x1                ; =1
    6e94:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x5f8>
		0000000000006e94:  ARM64_RELOC_PAGE21	l_stogir.437
    6e98:      	ldr	x28, [x28]
		0000000000006e98:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    6e9c:      	mov	x19, #0x26              ; =38
    6ea0:      	b	0x6eb0 <_stogir.placement.late-with-uses!+0x940>
    6ea4:      	movz	x0, #0x0, lsl #48
    6ea8:      	movz	x28, #0x0, lsl #48
    6eac:      	movz	x19, #0x0, lsl #48
    6eb0:      	b	0x6eb8 <_stogir.placement.late-with-uses!+0x948>
    6eb4:      	mov	x0, #0x1                ; =1
    6eb8:      	ldr	x1, [sp, #0x128]
    6ebc:      	str	x0, [x1]
    6ec0:      	str	x28, [x1, #0x8]
    6ec4:      	str	x19, [x1, #0x10]
    6ec8:      	ldr	x19, [sp, #0x1a0]
    6ecc:      	ldr	x20, [sp, #0x1a8]
    6ed0:      	ldr	x21, [sp, #0x1b0]
    6ed4:      	ldr	x22, [sp, #0x1b8]
    6ed8:      	ldr	x23, [sp, #0x1c0]
    6edc:      	ldr	x24, [sp, #0x1c8]
    6ee0:      	ldr	x25, [sp, #0x1d0]
    6ee4:      	ldr	x26, [sp, #0x1d8]
    6ee8:      	ldr	x27, [sp, #0x1e0]
    6eec:      	ldr	x28, [sp, #0x1e8]
    6ef0:      	ldr	x29, [sp]
    6ef4:      	ldr	x30, [sp, #0x8]
    6ef8:      	add	sp, sp, #0x1f0
    6efc:      	ret
    6f00:      	movz	x20, #0x0, lsl #48
    6f04:      	b	0x6954 <_stogir.placement.late-with-uses!+0x3e4>
    6f08:      	brk	#0
    6f0c:      	b	0x6f08 <_stogir.placement.late-with-uses!+0x998>
    6f10:      	lsl	x7, x7, #1
    6f14:      	str	w2, [sp, #0x178]
    6f18:      	str	x0, [sp, #0x180]
    6f1c:      	ldr	x0, [sp, #0x118]
    6f20:      	str	x1, [sp, #0x188]
    6f24:      	mov	x1, x7
    6f28:      	str	x4, [sp, #0x138]
    6f2c:      	str	x20, [sp, #0x170]
    6f30:      	mov	x20, x3
    6f34:      	str	x21, [sp, #0x190]
    6f38:      	mov	w21, w5
    6f3c:      	str	x22, [sp, #0x198]
    6f40:      	mov	x22, x6
    6f44:      	bl	0x6f44 <_stogir.placement.late-with-uses!+0x9d4>
		0000000000006f44:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    6f48:      	add	x0, x22, #0x1
    6f4c:      	add	x16, sp, #0x70
    6f50:      	ldr	x1, [x16]
    6f54:      	add	x1, x1, x22, lsl #2
    6f58:      	str	w21, [x1]
    6f5c:      	add	x16, sp, #0x70
    6f60:      	str	x0, [x16, #0x8]
    6f64:      	b	0x6ce0 <_stogir.placement.late-with-uses!+0x770>
    6f68:      	ldr	x0, [x23]
    6f6c:      	orr	x2, x0, xzr
    6f70:      	add	x2, x2, x20, lsl #2
    6f74:      	add	x0, x0, x1, lsl #2
    6f78:      	ldr	w1, [x2]
    6f7c:      	orr	w20, w1, wzr
    6f80:      	ldr	w0, [x0]
    6f84:      	orr	w1, w0, wzr
    6f88:      	sxtw	x20, w20
    6f8c:      	sxtw	x1, w1
    6f90:      	cmp	x20, x1
    6f94:      	b.eq	0x6f04 <_stogir.placement.late-with-uses!+0x994>
    6f98:      	b	0x6f68 <_stogir.placement.late-with-uses!+0x9f8>
    6f9c:      	nop
    6fa0:      	sxtw	x1, w1
    6fa4:      	sub	x2, x2, #0x1
    6fa8:      	ldr	x3, [x23]
    6fac:      	add	x1, x3, x1, lsl #2
    6fb0:      	ldr	w1, [x1]
    6fb4:      	cmp	x2, x0
    6fb8:      	b.gt	0x6fa0 <_stogir.placement.late-with-uses!+0xa30>
    6fbc:      	b	0x6f88 <_stogir.placement.late-with-uses!+0xa18>
    6fc0:      	sxtw	x20, w20
    6fc4:      	sub	x0, x0, #0x1
    6fc8:      	ldr	x3, [x23]
    6fcc:      	add	x3, x3, x20, lsl #2
    6fd0:      	ldr	w3, [x3]
    6fd4:      	orr	w20, w3, wzr
    6fd8:      	cmp	x0, x2
    6fdc:      	b.gt	0x6fc0 <_stogir.placement.late-with-uses!+0xa50>
    6fe0:      	b	0x6fb4 <_stogir.placement.late-with-uses!+0xa44>
    6fe4:      	nop
    6fe8:      	orr	w3, w4, wzr
    6fec:      	add	x2, x2, #0x1
    6ff0:      	ldr	x4, [x23]
    6ff4:      	sxtw	x3, w3
    6ff8:      	add	x4, x4, x3, lsl #2
    6ffc:      	ldr	w4, [x4]
    7000:      	sxtw	x5, w4
    7004:      	cmp	x3, x5
    7008:      	b.eq	0x6fd8 <_stogir.placement.late-with-uses!+0xa68>
    700c:      	b	0x6fe8 <_stogir.placement.late-with-uses!+0xa78>
    7010:      	orr	w2, w3, wzr
    7014:      	add	x0, x0, #0x1
    7018:      	ldr	x3, [x23]
    701c:      	sxtw	x2, w2
    7020:      	add	x3, x3, x2, lsl #2
    7024:      	ldr	w3, [x3]
    7028:      	sxtw	x4, w3
    702c:      	cmp	x2, x4
    7030:      	b.ne	0x7010 <_stogir.placement.late-with-uses!+0xaa0>
    7034:      	mov	w3, w1
    7038:      	movz	x2, #0x0, lsl #48
    703c:      	b	0x6ff0 <_stogir.placement.late-with-uses!+0xa80>
    7040:      	brk	#0
    7044:      	b	0x7040 <_stogir.placement.late-with-uses!+0xad0>
    7048:      	brk	#0
    704c:      	b	0x7048 <_stogir.placement.late-with-uses!+0xad8>
    7050:      	str	x19, [sp, #0x110]
    7054:      	b	0x6760 <_stogir.placement.late-with-uses!+0x1f0>
    7058:      	str	x19, [sp, #0x118]
    705c:      	b	0x683c <_stogir.placement.late-with-uses!+0x2cc>
    7060:      	str	x19, [sp, #0x118]
    7064:      	b	0x67ec <_stogir.placement.late-with-uses!+0x27c>
    7068:      	ldr	x20, [sp, #0x130]
    706c:      	b	0x6e58 <_stogir.placement.late-with-uses!+0x8e8>
    7070:      	str	x20, [sp, #0x160]
    7074:      	str	x21, [sp, #0x168]
    7078:      	str	x26, [sp, #0x158]
    707c:      	str	x25, [sp, #0x140]
    7080:      	mov	x25, x0
    7084:      	str	x24, [sp, #0x170]
    7088:      	mov	w24, w7
    708c:      	mov	w20, w4
    7090:      	b	0x6a8c <_stogir.placement.late-with-uses!+0x51c>
    7094:      	str	x20, [sp, #0x160]
    7098:      	str	x21, [sp, #0x168]
    709c:      	str	x26, [sp, #0x158]
    70a0:      	mov	x26, x3
    70a4:      	str	x2, [sp, #0x148]
    70a8:      	str	x1, [sp, #0x150]
    70ac:      	str	x25, [sp, #0x140]
    70b0:      	mov	x25, x0
    70b4:      	str	x24, [sp, #0x170]
    70b8:      	mov	w20, w4
    70bc:      	b	0x6954 <_stogir.placement.late-with-uses!+0x3e4>
    70c0:      	ldr	x20, [sp, #0x170]
    70c4:      	b	0x6bb4 <_stogir.placement.late-with-uses!+0x644>
    70c8:      	ldr	x26, [sp, #0x168]
    70cc:      	str	x22, [sp, #0x198]
    70d0:      	str	x20, [sp, #0x170]
    70d4:      	ldr	x20, [sp, #0x130]
    70d8:      	b	0x6884 <_stogir.placement.late-with-uses!+0x314>
    70dc:      	str	x22, [sp, #0x198]
    70e0:      	str	x21, [sp, #0x190]
    70e4:      	str	x20, [sp, #0x170]
    70e8:      	mov	x20, x3
    70ec:      	str	x1, [sp, #0x188]
    70f0:      	str	w2, [sp, #0x178]
    70f4:      	str	x0, [sp, #0x180]
    70f8:      	b	0x6ce0 <_stogir.placement.late-with-uses!+0x770>
    70fc:      	str	x22, [sp, #0x198]
    7100:      	str	x21, [sp, #0x190]
    7104:      	str	x20, [sp, #0x170]
    7108:      	mov	x20, x3
    710c:      	str	x1, [sp, #0x188]
    7110:      	str	w2, [sp, #0x178]
    7114:      	str	x0, [sp, #0x180]
    7118:      	b	0x6ce0 <_stogir.placement.late-with-uses!+0x770>
    711c:      	str	x22, [sp, #0x198]
    7120:      	str	x20, [sp, #0x170]
    7124:      	b	0x6878 <_stogir.placement.late-with-uses!+0x308>
    7128:      	ldr	x4, [sp, #0x138]
    712c:      	b	0x6de4 <_stogir.placement.late-with-uses!+0x874>
    7130:      	str	x22, [sp, #0x198]
    7134:      	str	x21, [sp, #0x190]
    7138:      	str	x20, [sp, #0x170]
    713c:      	mov	x20, x3
    7140:      	str	x1, [sp, #0x188]
    7144:      	str	w2, [sp, #0x178]
    7148:      	str	x0, [sp, #0x180]
    714c:      	str	x4, [sp, #0x138]
    7150:      	b	0x6ce0 <_stogir.placement.late-with-uses!+0x770>
    7154:      	str	x22, [sp, #0x198]
    7158:      	str	x21, [sp, #0x190]
    715c:      	str	x20, [sp, #0x170]
    7160:      	mov	x20, x3
    7164:      	str	x1, [sp, #0x188]
    7168:      	str	w2, [sp, #0x178]
    716c:      	str	x0, [sp, #0x180]
    7170:      	str	x4, [sp, #0x138]
    7174:      	b	0x6ce0 <_stogir.placement.late-with-uses!+0x770>
    7178:      	str	x22, [sp, #0x198]
    717c:      	str	x21, [sp, #0x190]
    7180:      	str	x20, [sp, #0x170]
    7184:      	mov	x20, x3
    7188:      	str	x1, [sp, #0x188]
    718c:      	str	w2, [sp, #0x178]
    7190:      	str	x0, [sp, #0x180]
    7194:      	str	x4, [sp, #0x138]
    7198:      	b	0x6ce0 <_stogir.placement.late-with-uses!+0x770>
    719c:      	str	x22, [sp, #0x198]
    71a0:      	str	x21, [sp, #0x190]
    71a4:      	str	x20, [sp, #0x170]
    71a8:      	mov	x20, x3
    71ac:      	str	x1, [sp, #0x188]
    71b0:      	mov	x22, x6
    71b4:      	str	w2, [sp, #0x178]
    71b8:      	str	x0, [sp, #0x180]
    71bc:      	mov	w21, w5
    71c0:      	str	x4, [sp, #0x138]
    71c4:      	b	0x6f48 <_stogir.placement.late-with-uses!+0x9d8>

00000000000071c8 <_stogir.checked-schedule.place!>:
    71c8:      	sub	sp, sp, #0x90
    71cc:      	str	x29, [sp]
    71d0:      	str	x30, [sp, #0x8]
    71d4:      	mov	x29, sp
    71d8:      	str	x19, [sp, #0x40]
    71dc:      	str	x20, [sp, #0x48]
    71e0:      	str	x21, [sp, #0x50]
    71e4:      	str	x22, [sp, #0x58]
    71e8:      	str	x23, [sp, #0x60]
    71ec:      	str	x24, [sp, #0x68]
    71f0:      	str	x25, [sp, #0x70]
    71f4:      	str	x26, [sp, #0x78]
    71f8:      	str	x27, [sp, #0x80]
    71fc:      	str	x28, [sp, #0x88]
    7200:      	orr	x19, x1, xzr
    7204:      	orr	x20, x2, xzr
    7208:      	add	x16, sp, #0x20
    720c:      	orr	x1, x16, xzr
    7210:      	add	x21, x1, #0x8
    7214:      	mov	x22, #0x1               ; =1
    7218:      	movz	x23, #0x0, lsl #48
    721c:      	adrp	x24, 0x7000 <_stogir.placement.late-with-uses!+0xa90>
		000000000000721c:  ARM64_RELOC_PAGE21	l_stogir.438
    7220:      	ldr	x24, [x24]
		0000000000007220:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    7224:      	movz	x25, #0x0, lsl #48
    7228:      	b	0x7260 <_stogir.checked-schedule.place!+0x98>
    722c:      	nop
    7230:      	add	x16, sp, #0x20
    7234:      	ldr	x24, [x16, #0x8]
    7238:      	ldr	x25, [x21, #0x8]
    723c:      	sxtw	x26, w26
    7240:      	add	x0, x26, #0x4
    7244:      	asr	x16, x0, #63
    7248:      	lsr	x16, x16, #62
    724c:      	add	x0, x0, x16
    7250:      	asr	x0, x0, #2
    7254:      	add	x22, x0, x22
    7258:      	mov	x8, x27
    725c:      	mov	x0, x28
    7260:      	cmp	x25, #0x0
    7264:      	b.ne	0x73cc <_stogir.checked-schedule.place!+0x204>
    7268:      	ldr	x1, [x0, #0x8]
    726c:      	cmp	x22, x1
    7270:      	b.ge	0x73d4 <_stogir.checked-schedule.place!+0x20c>
    7274:      	ldr	x1, [x0]
    7278:      	add	x1, x1, x22, lsl #4
    727c:      	ldr	x2, [x1]
    7280:      	uxtb	w3, w2
    7284:      	ldr	x1, [x1, #0x8]
    7288:      	add	x16, sp, #0x10
    728c:      	str	x2, [x16]
    7290:      	add	x16, sp, #0x10
    7294:      	str	x1, [x16, #0x8]
    7298:      	ldr	x1, [x0, #0x78]
    729c:      	add	x1, x1, x22, lsl #2
    72a0:      	ldr	w26, [x1]
    72a4:      	cmp	x3, #0x2c
    72a8:      	b.ne	0x73dc <_stogir.checked-schedule.place!+0x214>
    72ac:      	ldr	x1, [x20]
    72b0:      	add	x1, x22, x1
    72b4:      	ldrb	w1, [x1]
    72b8:      	cmp	x1, #0x0
    72bc:      	b.eq	0x73e8 <_stogir.checked-schedule.place!+0x220>
    72c0:      	orr	w1, w22, wzr
    72c4:      	mov	x27, x8
    72c8:      	add	x8, sp, #0x20
    72cc:      	mov	x28, x0
    72d0:      	bl	0x72d0 <_stogir.checked-schedule.place!+0x108>
		00000000000072d0:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    72d4:      	add	x16, sp, #0x20
    72d8:      	ldr	w0, [x16]
    72dc:      	lsr	x16, x0, #0
    72e0:      	cmp	x16, #0x1
    72e4:      	b.eq	0x7300 <_stogir.checked-schedule.place!+0x138>
    72e8:      	b.lo	0x72f0 <_stogir.checked-schedule.place!+0x128>
    72ec:      	b	0x7304 <_stogir.checked-schedule.place!+0x13c>
    72f0:      	cmp	x16, #0x0
    72f4:      	b.eq	0x72fc <_stogir.checked-schedule.place!+0x134>
    72f8:      	b	0x7304 <_stogir.checked-schedule.place!+0x13c>
    72fc:      	b	0x7308 <_stogir.checked-schedule.place!+0x140>
    7300:      	b	0x7230 <_stogir.checked-schedule.place!+0x68>
    7304:      	b	0x73c4 <_stogir.checked-schedule.place!+0x1fc>
    7308:      	add	x16, sp, #0x20
    730c:      	ldr	w0, [x16, #0x8]
    7310:      	sxtw	x0, w0
    7314:      	cmp	x0, #0x0
    7318:      	b.eq	0x73c0 <_stogir.checked-schedule.place!+0x1f8>
    731c:      	add	x16, sp, #0x10
    7320:      	ldr	w0, [x16, #0x4]
    7324:      	sxtw	x0, w0
    7328:      	ldr	x1, [x19]
    732c:      	add	x0, x1, x0, lsl #2
    7330:      	ldr	w0, [x0]
    7334:      	sxtw	x2, w0
    7338:      	cmp	x2, #0x0
    733c:      	b.gt	0x73b0 <_stogir.checked-schedule.place!+0x1e8>
    7340:      	adrp	x24, 0x7000 <_stogir.placement.late-with-uses!+0xa90>
		0000000000007340:  ARM64_RELOC_PAGE21	l_stogir.439
    7344:      	ldr	x24, [x24]
		0000000000007344:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    7348:      	mov	x25, #0x21              ; =33
    734c:      	b	0x73c0 <_stogir.checked-schedule.place!+0x1f8>
    7350:      	cmp	x25, #0x0
    7354:      	b.ne	0x7368 <_stogir.checked-schedule.place!+0x1a0>
    7358:      	and	x24, x23, #0xffffffff
    735c:      	movz	x0, #0x0, lsl #48
    7360:      	movz	x25, #0x0, lsl #48
    7364:      	b	0x736c <_stogir.checked-schedule.place!+0x1a4>
    7368:      	mov	x0, #0x1                ; =1
    736c:      	str	x0, [x27]
    7370:      	str	x24, [x27, #0x8]
    7374:      	str	x25, [x27, #0x10]
    7378:      	ldr	x19, [sp, #0x40]
    737c:      	ldr	x20, [sp, #0x48]
    7380:      	ldr	x21, [sp, #0x50]
    7384:      	ldr	x22, [sp, #0x58]
    7388:      	ldr	x23, [sp, #0x60]
    738c:      	ldr	x24, [sp, #0x68]
    7390:      	ldr	x25, [sp, #0x70]
    7394:      	ldr	x26, [sp, #0x78]
    7398:      	ldr	x27, [sp, #0x80]
    739c:      	ldr	x28, [sp, #0x88]
    73a0:      	ldr	x29, [sp]
    73a4:      	ldr	x30, [sp, #0x8]
    73a8:      	add	sp, sp, #0x90
    73ac:      	ret
    73b0:      	add	x2, x23, #0x1
    73b4:      	add	x1, x1, x22, lsl #2
    73b8:      	sxtw	x23, w2
    73bc:      	str	w0, [x1]
    73c0:      	b	0x723c <_stogir.checked-schedule.place!+0x74>
    73c4:      	brk	#0
    73c8:      	b	0x73c4 <_stogir.checked-schedule.place!+0x1fc>
    73cc:      	mov	x27, x8
    73d0:      	b	0x7350 <_stogir.checked-schedule.place!+0x188>
    73d4:      	mov	x27, x8
    73d8:      	b	0x7350 <_stogir.checked-schedule.place!+0x188>
    73dc:      	mov	x27, x8
    73e0:      	mov	x28, x0
    73e4:      	b	0x723c <_stogir.checked-schedule.place!+0x74>
    73e8:      	mov	x27, x8
    73ec:      	mov	x28, x0
    73f0:      	b	0x723c <_stogir.checked-schedule.place!+0x74>
    73f4:      	udf	#0x0

00000000000073f8 <_stogir.loops.reorder!>:
    73f8:      	sub	sp, sp, #0x2e0
    73fc:      	str	x29, [sp]
    7400:      	str	x30, [sp, #0x8]
    7404:      	mov	x29, sp
    7408:      	str	x19, [sp, #0x290]
    740c:      	str	x20, [sp, #0x298]
    7410:      	str	x21, [sp, #0x2a0]
    7414:      	str	x22, [sp, #0x2a8]
    7418:      	str	x23, [sp, #0x2b0]
    741c:      	str	x24, [sp, #0x2b8]
    7420:      	str	x25, [sp, #0x2c0]
    7424:      	str	x26, [sp, #0x2c8]
    7428:      	str	x27, [sp, #0x2d0]
    742c:      	str	x28, [sp, #0x2d8]
    7430:      	add	x6, x0, #0x50
    7434:      	ldr	x7, [x0, #0x50]
    7438:      	orr	x19, x7, xzr
    743c:      	ldr	x6, [x6, #0x8]
    7440:      	orr	x20, x6, xzr
    7444:      	movz	x21, #0x0, lsl #48
    7448:      	movz	x22, #0x0, lsl #48
    744c:      	b	0x788c <_stogir.loops.reorder!+0x494>
    7450:      	movz	w1, #0x0, lsl #16
    7454:      	movz	x2, #0x0, lsl #48
    7458:      	ubfx	x1, x1, #0, #32
    745c:      	lsr	x16, x1, #0
    7460:      	cmp	x16, #0x1
    7464:      	b.eq	0x7488 <_stogir.loops.reorder!+0x90>
    7468:      	b.lo	0x7470 <_stogir.loops.reorder!+0x78>
    746c:      	b	0x748c <_stogir.loops.reorder!+0x94>
    7470:      	cmp	x16, #0x0
    7474:      	b.eq	0x747c <_stogir.loops.reorder!+0x84>
    7478:      	b	0x748c <_stogir.loops.reorder!+0x94>
    747c:      	str	x19, [sp, #0x258]
    7480:      	mov	x19, x0
    7484:      	b	0x752c <_stogir.loops.reorder!+0x134>
    7488:      	b	0x7490 <_stogir.loops.reorder!+0x98>
    748c:      	b	0x802c <_stogir.loops.reorder!+0xc34>
    7490:      	orr	w1, w2, wzr
    7494:      	asr	x3, x2, #32
    7498:      	add	x16, sp, #0x50
    749c:      	ldr	x4, [x16]
    74a0:      	sxtw	x5, w1
    74a4:      	orr	x6, x4, xzr
    74a8:      	add	x3, x4, x3, lsl #2
    74ac:      	add	x4, x6, x5, lsl #2
    74b0:      	ldr	w4, [x4]
    74b4:      	sxtw	x4, w4
    74b8:      	ldr	w3, [x3]
    74bc:      	cmp	x4, #0x0
    74c0:      	b.lt	0x8034 <_stogir.loops.reorder!+0xc3c>
    74c4:      	sxtw	x3, w3
    74c8:      	cmp	x3, #0x0
    74cc:      	b.lt	0x8040 <_stogir.loops.reorder!+0xc48>
    74d0:      	cmp	x4, x3
    74d4:      	b.lt	0x804c <_stogir.loops.reorder!+0xc54>
    74d8:      	lsr	x2, x2, #32
    74dc:      	str	x19, [sp, #0x258]
    74e0:      	mov	x19, x0
    74e4:      	mov	x0, x26
    74e8:      	fmov	s31, w1
    74ec:      	mov	w1, w2
    74f0:      	fmov	w2, s31
    74f4:      	bl	0x74f4 <_stogir.loops.reorder!+0xfc>
		00000000000074f4:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    74f8:      	cmp	x0, #0x0
    74fc:      	b.ne	0x7504 <_stogir.loops.reorder!+0x10c>
    7500:      	movz	x19, #0x0, lsl #48
    7504:      	mov	x0, x19
    7508:      	ldr	x19, [sp, #0x258]
    750c:      	cmp	x22, x21
    7510:      	b.ge	0x7450 <_stogir.loops.reorder!+0x58>
    7514:      	add	x1, x22, #0x1
    7518:      	add	x2, x20, x22, lsl #4
    751c:      	ldr	x2, [x2]
    7520:      	mov	x22, x1
    7524:      	mov	w1, #0x1                ; =1
    7528:      	b	0x7458 <_stogir.loops.reorder!+0x60>
    752c:      	cmp	x19, #0x0
    7530:      	b.eq	0x76b0 <_stogir.loops.reorder!+0x2b8>
    7534:      	add	x8, sp, #0x100
    7538:      	ldr	x0, [sp, #0x250]
    753c:      	bl	0x753c <_stogir.loops.reorder!+0x144>
		000000000000753c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7540:      	add	x16, sp, #0x100
    7544:      	ldr	x0, [x16]
    7548:      	add	x16, sp, #0xd0
    754c:      	str	x0, [x16]
    7550:      	add	x16, sp, #0x100
    7554:      	ldr	x0, [x16, #0x8]
    7558:      	add	x16, sp, #0xd0
    755c:      	str	x0, [x16, #0x8]
    7560:      	add	x16, sp, #0x100
    7564:      	ldr	x0, [x16, #0x10]
    7568:      	add	x16, sp, #0xd0
    756c:      	str	x0, [x16, #0x10]
    7570:      	add	x16, sp, #0x100
    7574:      	ldr	x0, [x16, #0x18]
    7578:      	add	x16, sp, #0xd0
    757c:      	str	x0, [x16, #0x18]
    7580:      	add	x16, sp, #0x100
    7584:      	ldr	x0, [x16, #0x20]
    7588:      	add	x16, sp, #0xd0
    758c:      	str	x0, [x16, #0x20]
    7590:      	add	x8, sp, #0x160
    7594:      	ldr	x0, [sp, #0x250]
    7598:      	bl	0x7598 <_stogir.loops.reorder!+0x1a0>
		0000000000007598:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame
    759c:      	add	x16, sp, #0x160
    75a0:      	ldr	x0, [x16]
    75a4:      	add	x16, sp, #0x130
    75a8:      	str	x0, [x16]
    75ac:      	add	x16, sp, #0x160
    75b0:      	ldr	x0, [x16, #0x8]
    75b4:      	add	x16, sp, #0x130
    75b8:      	str	x0, [x16, #0x8]
    75bc:      	add	x16, sp, #0x160
    75c0:      	ldr	x0, [x16, #0x10]
    75c4:      	add	x16, sp, #0x130
    75c8:      	str	x0, [x16, #0x10]
    75cc:      	add	x16, sp, #0x160
    75d0:      	ldr	x0, [x16, #0x18]
    75d4:      	add	x16, sp, #0x130
    75d8:      	str	x0, [x16, #0x18]
    75dc:      	add	x16, sp, #0x160
    75e0:      	ldr	x0, [x16, #0x20]
    75e4:      	add	x16, sp, #0x130
    75e8:      	str	x0, [x16, #0x20]
    75ec:      	add	x8, sp, #0x1c0
    75f0:      	ldr	x0, [sp, #0x250]
    75f4:      	bl	0x75f4 <_stogir.loops.reorder!+0x1fc>
		00000000000075f4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    75f8:      	add	x16, sp, #0x1c0
    75fc:      	ldr	x0, [x16]
    7600:      	add	x16, sp, #0x190
    7604:      	str	x0, [x16]
    7608:      	add	x16, sp, #0x1c0
    760c:      	ldr	x0, [x16, #0x8]
    7610:      	add	x16, sp, #0x190
    7614:      	str	x0, [x16, #0x8]
    7618:      	add	x16, sp, #0x1c0
    761c:      	ldr	x0, [x16, #0x10]
    7620:      	add	x16, sp, #0x190
    7624:      	str	x0, [x16, #0x10]
    7628:      	add	x16, sp, #0x1c0
    762c:      	ldr	x0, [x16, #0x18]
    7630:      	add	x16, sp, #0x190
    7634:      	str	x0, [x16, #0x18]
    7638:      	add	x16, sp, #0x1c0
    763c:      	ldr	x0, [x16, #0x20]
    7640:      	add	x16, sp, #0x190
    7644:      	str	x0, [x16, #0x20]
    7648:      	ldr	x0, [x28]
    764c:      	ldr	w19, [x0]
    7650:      	movn	x0, #0x0, lsl #48
    7654:      	b	0x766c <_stogir.loops.reorder!+0x274>
    7658:      	add	x16, sp, #0x50
    765c:      	ldr	x1, [x16]
    7660:      	add	x1, x1, x0, lsl #2
    7664:      	movz	w17, #0x0, lsl #16
    7668:      	str	w17, [x1]
    766c:      	add	x16, sp, #0x50
    7670:      	ldr	x1, [x16, #0x8]
    7674:      	add	x0, x0, #0x1
    7678:      	cmp	x0, x1
    767c:      	b.lt	0x7658 <_stogir.loops.reorder!+0x260>
    7680:      	add	x16, sp, #0xd0
    7684:      	orr	x20, x16, xzr
    7688:      	add	x0, x25, #0x28
    768c:      	add	x8, sp, #0x1f0
    7690:      	bl	0x7690 <_stogir.loops.reorder!+0x298>
		0000000000007690:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64
    7694:      	add	x16, sp, #0x1f0
    7698:      	ldr	x21, [x16]
    769c:      	add	x16, sp, #0x1f0
    76a0:      	ldr	x22, [x16, #0x8]
    76a4:      	add	x16, sp, #0x1f0
    76a8:      	ldr	x26, [x16, #0x10]
    76ac:      	b	0x790c <_stogir.loops.reorder!+0x514>
    76b0:      	ldr	x0, [sp, #0x258]
    76b4:      	bl	0x76b4 <_stogir.loops.reorder!+0x2bc>
		00000000000076b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    76b8:      	movz	x1, #0x0, lsl #48
    76bc:      	movz	x0, #0x0, lsl #48
    76c0:      	movz	x2, #0x0, lsl #48
    76c4:      	b	0x7e44 <_stogir.loops.reorder!+0xa4c>
    76c8:      	movz	w4, #0x0, lsl #16
    76cc:      	movz	w5, #0x0, lsl #16
    76d0:      	ubfx	x4, x4, #0, #32
    76d4:      	lsr	x16, x4, #0
    76d8:      	cmp	x16, #0x1
    76dc:      	b.eq	0x76f8 <_stogir.loops.reorder!+0x300>
    76e0:      	b.lo	0x76e8 <_stogir.loops.reorder!+0x2f0>
    76e4:      	b	0x76fc <_stogir.loops.reorder!+0x304>
    76e8:      	cmp	x16, #0x0
    76ec:      	b.eq	0x76f4 <_stogir.loops.reorder!+0x2fc>
    76f0:      	b	0x76fc <_stogir.loops.reorder!+0x304>
    76f4:      	b	0x7748 <_stogir.loops.reorder!+0x350>
    76f8:      	b	0x7700 <_stogir.loops.reorder!+0x308>
    76fc:      	b	0x8024 <_stogir.loops.reorder!+0xc2c>
    7700:      	sxtw	x5, w5
    7704:      	ldr	x4, [x26]
    7708:      	add	x4, x4, x5, lsl #2
    770c:      	ldr	w4, [x4]
    7710:      	sxtw	x4, w4
    7714:      	cmp	x4, #0x0
    7718:      	b.le	0x7720 <_stogir.loops.reorder!+0x328>
    771c:      	add	x3, x3, #0x1
    7720:      	cmp	x2, x1
    7724:      	b.ge	0x76c8 <_stogir.loops.reorder!+0x2d0>
    7728:      	add	x4, x2, #0x1
    772c:      	add	x2, x0, x2, lsl #2
    7730:      	ldr	w2, [x2]
    7734:      	movn	w17, #0x0, lsl #16
    7738:      	and	w5, w2, w17
    773c:      	mov	x2, x4
    7740:      	mov	w4, #0x1                ; =1
    7744:      	b	0x76d0 <_stogir.loops.reorder!+0x2d8>
    7748:      	ldr	x0, [x28, #0x8]
    774c:      	cmp	x3, x0
    7750:      	b.ne	0x7788 <_stogir.loops.reorder!+0x390>
    7754:      	orr	x19, x28, xzr
    7758:      	add	x8, sp, #0x30
    775c:      	mov	x0, x24
    7760:      	bl	0x7760 <_stogir.loops.reorder!+0x368>
		0000000000007760:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    7764:      	add	x16, sp, #0x30
    7768:      	ldr	x0, [x16]
    776c:      	add	x16, sp, #0x30
    7770:      	ldr	x1, [x16, #0x8]
    7774:      	add	x16, sp, #0x30
    7778:      	ldr	x2, [x16, #0x10]
    777c:      	movz	x3, #0x0, lsl #48
    7780:      	movz	x4, #0x0, lsl #48
    7784:      	b	0x7e0c <_stogir.loops.reorder!+0xa14>
    7788:      	mov	x1, #0x1                ; =1
    778c:      	adrp	x0, 0x7000 <_stogir.placement.late-with-uses!+0xa90>
		000000000000778c:  ARM64_RELOC_PAGE21	l_stogir.440
    7790:      	ldr	x0, [x0]
		0000000000007790:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    7794:      	mov	x2, #0x32               ; =50
    7798:      	b	0x7e54 <_stogir.loops.reorder!+0xa5c>
    779c:      	nop
    77a0:      	movz	w6, #0x0, lsl #16
    77a4:      	movz	x7, #0x0, lsl #48
    77a8:      	ubfx	x6, x6, #0, #32
    77ac:      	lsr	x16, x6, #0
    77b0:      	cmp	x16, #0x1
    77b4:      	b.eq	0x77ec <_stogir.loops.reorder!+0x3f4>
    77b8:      	b.lo	0x77c0 <_stogir.loops.reorder!+0x3c8>
    77bc:      	b	0x77f0 <_stogir.loops.reorder!+0x3f8>
    77c0:      	cmp	x16, #0x0
    77c4:      	b.eq	0x77cc <_stogir.loops.reorder!+0x3d4>
    77c8:      	b	0x77f0 <_stogir.loops.reorder!+0x3f8>
    77cc:      	mov	x23, x8
    77d0:      	mov	x24, x0
    77d4:      	mov	x25, x1
    77d8:      	mov	x26, x2
    77dc:      	mov	x27, x3
    77e0:      	mov	x28, x4
    77e4:      	str	x5, [sp, #0x250]
    77e8:      	b	0x78ac <_stogir.loops.reorder!+0x4b4>
    77ec:      	b	0x77f4 <_stogir.loops.reorder!+0x3fc>
    77f0:      	b	0x801c <_stogir.loops.reorder!+0xc24>
    77f4:      	orr	w6, w7, wzr
    77f8:      	ldr	x9, [x2]
    77fc:      	sxtw	x10, w6
    7800:      	add	x11, x9, x10, lsl #2
    7804:      	ldr	w11, [x11]
    7808:      	sxtw	x11, w11
    780c:      	cmp	x11, #0x0
    7810:      	b.le	0x8058 <_stogir.loops.reorder!+0xc60>
    7814:      	lsr	x7, x7, #32
    7818:      	sxtw	x11, w7
    781c:      	add	x9, x9, x11, lsl #2
    7820:      	ldr	w9, [x9]
    7824:      	sxtw	x9, w9
    7828:      	cmp	x9, #0x0
    782c:      	b.le	0x8078 <_stogir.loops.reorder!+0xc80>
    7830:      	cmp	x10, x11
    7834:      	b.lt	0x8098 <_stogir.loops.reorder!+0xca0>
    7838:      	mov	x23, x8
    783c:      	mov	x24, x0
    7840:      	mov	x0, x2
    7844:      	mov	x25, x1
    7848:      	mov	w1, w7
    784c:      	mov	x26, x2
    7850:      	mov	w2, w6
    7854:      	mov	x27, x3
    7858:      	mov	x28, x4
    785c:      	str	x5, [sp, #0x250]
    7860:      	bl	0x7860 <_stogir.loops.reorder!+0x468>
		0000000000007860:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    7864:      	cmp	x0, #0x0
    7868:      	b.ne	0x7870 <_stogir.loops.reorder!+0x478>
    786c:      	mov	x21, #0x1               ; =1
    7870:      	mov	x8, x23
    7874:      	mov	x0, x24
    7878:      	mov	x1, x25
    787c:      	mov	x2, x26
    7880:      	mov	x3, x27
    7884:      	mov	x4, x28
    7888:      	ldr	x5, [sp, #0x250]
    788c:      	cmp	x22, x20
    7890:      	b.ge	0x77a0 <_stogir.loops.reorder!+0x3a8>
    7894:      	add	x6, x22, #0x1
    7898:      	add	x7, x19, x22, lsl #4
    789c:      	ldr	x7, [x7]
    78a0:      	mov	x22, x6
    78a4:      	mov	w6, #0x1                ; =1
    78a8:      	b	0x77a8 <_stogir.loops.reorder!+0x3b0>
    78ac:      	ldr	x0, [x28, #0x8]
    78b0:      	cmp	x0, #0x0
    78b4:      	b.ne	0x7e98 <_stogir.loops.reorder!+0xaa0>
    78b8:      	movz	x1, #0x0, lsl #48
    78bc:      	movz	x0, #0x0, lsl #48
    78c0:      	movz	x2, #0x0, lsl #48
    78c4:      	b	0x7e54 <_stogir.loops.reorder!+0xa5c>
    78c8:      	lsl	x2, x2, #1
    78cc:      	str	x20, [sp, #0x260]
    78d0:      	str	x21, [sp, #0x268]
    78d4:      	mov	x21, x0
    78d8:      	mov	x0, x20
    78dc:      	mov	x20, x1
    78e0:      	mov	x1, x2
    78e4:      	bl	0x78e4 <_stogir.loops.reorder!+0x4ec>
		00000000000078e4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    78e8:      	add	x0, x21, #0x1
    78ec:      	add	x16, sp, #0xd0
    78f0:      	ldr	x1, [x16]
    78f4:      	add	x1, x1, x21, lsl #3
    78f8:      	str	x20, [x1]
    78fc:      	add	x16, sp, #0xd0
    7900:      	str	x0, [x16, #0x8]
    7904:      	ldr	x20, [sp, #0x260]
    7908:      	ldr	x21, [sp, #0x268]
    790c:      	cmp	x26, x22
    7910:      	b.ge	0x792c <_stogir.loops.reorder!+0x534>
    7914:      	add	x0, x26, #0x1
    7918:      	add	x1, x21, x26, lsl #3
    791c:      	ldr	x1, [x1]
    7920:      	mov	x26, x0
    7924:      	mov	w0, #0x1                ; =1
    7928:      	b	0x7934 <_stogir.loops.reorder!+0x53c>
    792c:      	movz	w0, #0x0, lsl #16
    7930:      	movz	x1, #0x0, lsl #48
    7934:      	ubfx	x0, x0, #0, #32
    7938:      	lsr	x16, x0, #0
    793c:      	cmp	x16, #0x1
    7940:      	b.eq	0x7960 <_stogir.loops.reorder!+0x568>
    7944:      	b.lo	0x794c <_stogir.loops.reorder!+0x554>
    7948:      	b	0x7964 <_stogir.loops.reorder!+0x56c>
    794c:      	cmp	x16, #0x0
    7950:      	b.eq	0x7958 <_stogir.loops.reorder!+0x560>
    7954:      	b	0x7964 <_stogir.loops.reorder!+0x56c>
    7958:      	str	x20, [sp, #0x260]
    795c:      	b	0x7990 <_stogir.loops.reorder!+0x598>
    7960:      	b	0x7968 <_stogir.loops.reorder!+0x570>
    7964:      	b	0x8014 <_stogir.loops.reorder!+0xc1c>
    7968:      	add	x16, sp, #0xd0
    796c:      	ldr	x0, [x16, #0x8]
    7970:      	add	x16, sp, #0xd0
    7974:      	ldr	x2, [x16, #0x10]
    7978:      	cmp	x0, x2
    797c:      	b.lt	0x80b8 <_stogir.loops.reorder!+0xcc0>
    7980:      	cmp	x2, #0x0
    7984:      	b.ne	0x78c8 <_stogir.loops.reorder!+0x4d0>
    7988:      	mov	x2, #0x2                ; =2
    798c:      	b	0x78cc <_stogir.loops.reorder!+0x4d4>
    7990:      	add	x16, sp, #0x130
    7994:      	orr	x20, x16, xzr
    7998:      	add	x16, sp, #0x190
    799c:      	orr	x21, x16, xzr
    79a0:      	add	x16, sp, #0x210
    79a4:      	orr	x0, x16, xzr
    79a8:      	add	x16, sp, #0x230
    79ac:      	orr	x22, x16, xzr
    79b0:      	sxtw	x26, w19
    79b4:      	orr	x1, x25, xzr
    79b8:      	orr	x2, x25, xzr
    79bc:      	ldr	x1, [x1]
    79c0:      	add	x1, x1, x26, lsl #4
    79c4:      	ldr	x3, [x1]
    79c8:      	ldr	x1, [x1, #0x8]
    79cc:      	add	x16, sp, #0x210
    79d0:      	str	x3, [x16]
    79d4:      	add	x16, sp, #0x210
    79d8:      	str	x1, [x16, #0x8]
    79dc:      	mov	x1, x0
    79e0:      	ldr	x0, [sp, #0x260]
    79e4:      	mov	x3, x27
    79e8:      	str	x20, [sp, #0x270]
    79ec:      	mov	x20, x2
    79f0:      	mov	x2, x24
    79f4:      	bl	0x79f4 <_stogir.loops.reorder!+0x5fc>
		00000000000079f4:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    79f8:      	add	x16, sp, #0x220
    79fc:      	movz	x17, #0x0, lsl #48
    7a00:      	str	x17, [x16]
    7a04:      	add	x16, sp, #0x220
    7a08:      	movz	x17, #0x0, lsl #48
    7a0c:      	str	x17, [x16, #0x8]
    7a10:      	add	x16, sp, #0x220
    7a14:      	str	w19, [x16]
    7a18:      	add	x16, sp, #0x210
    7a1c:      	ldr	x0, [x16, #0x8]
    7a20:      	add	x16, sp, #0x220
    7a24:      	str	x0, [x16, #0x8]
    7a28:      	add	x16, sp, #0x220
    7a2c:      	ldr	x1, [x16]
    7a30:      	mov	x2, x0
    7a34:      	ldr	x0, [sp, #0x270]
    7a38:      	bl	0x7a38 <_stogir.loops.reorder!+0x640>
		0000000000007a38:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame
    7a3c:      	add	x16, sp, #0x50
    7a40:      	ldr	x0, [x16]
    7a44:      	add	x0, x0, x26, lsl #2
    7a48:      	mov	w17, #0x1               ; =1
    7a4c:      	str	w17, [x0]
    7a50:      	b	0x7b04 <_stogir.loops.reorder!+0x70c>
    7a54:      	lsl	x0, x0, #1
    7a58:      	mov	x1, x0
    7a5c:      	ldr	x0, [sp, #0x270]
    7a60:      	bl	0x7a60 <_stogir.loops.reorder!+0x668>
		0000000000007a60:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    7a64:      	add	x0, x21, #0x1
    7a68:      	add	x16, sp, #0x130
    7a6c:      	ldr	x1, [x16]
    7a70:      	add	x1, x1, x21, lsl #4
    7a74:      	str	x20, [x1]
    7a78:      	str	x19, [x1, #0x8]
    7a7c:      	add	x16, sp, #0x130
    7a80:      	str	x0, [x16, #0x8]
    7a84:      	add	x16, sp, #0x50
    7a88:      	ldr	x0, [x16]
    7a8c:      	add	x0, x0, x22, lsl #2
    7a90:      	mov	w17, #0x1               ; =1
    7a94:      	str	w17, [x0]
    7a98:      	b	0x7af8 <_stogir.loops.reorder!+0x700>
    7a9c:      	nop
    7aa0:      	lsl	x0, x0, #1
    7aa4:      	mov	w26, w1
    7aa8:      	mov	x1, x0
    7aac:      	mov	x0, x21
    7ab0:      	bl	0x7ab0 <_stogir.loops.reorder!+0x6b8>
		0000000000007ab0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    7ab4:      	add	x0, x19, #0x1
    7ab8:      	add	x16, sp, #0x190
    7abc:      	ldr	x1, [x16]
    7ac0:      	add	x1, x1, x19, lsl #2
    7ac4:      	str	w26, [x1]
    7ac8:      	add	x16, sp, #0x190
    7acc:      	str	x0, [x16, #0x8]
    7ad0:      	add	x16, sp, #0x130
    7ad4:      	ldr	x0, [x16, #0x8]
    7ad8:      	cmp	x0, #0x0
    7adc:      	b.eq	0x7aec <_stogir.loops.reorder!+0x6f4>
    7ae0:      	sub	x0, x0, #0x1
    7ae4:      	add	x16, sp, #0x130
    7ae8:      	str	x0, [x16, #0x8]
    7aec:      	str	x21, [sp, #0x280]
    7af0:      	str	x22, [sp, #0x288]
    7af4:      	str	x20, [sp, #0x278]
    7af8:      	ldr	x21, [sp, #0x280]
    7afc:      	ldr	x22, [sp, #0x288]
    7b00:      	ldr	x20, [sp, #0x278]
    7b04:      	add	x16, sp, #0x130
    7b08:      	ldr	x0, [x16, #0x8]
    7b0c:      	cmp	x0, #0x0
    7b10:      	b.le	0x80cc <_stogir.loops.reorder!+0xcd4>
    7b14:      	add	x16, sp, #0x130
    7b18:      	ldr	x1, [x16]
    7b1c:      	sub	x19, x0, #0x1
    7b20:      	add	x0, x1, x19, lsl #4
    7b24:      	ldr	x26, [x0]
    7b28:      	orr	w1, w26, wzr
    7b2c:      	ldr	x0, [x0, #0x8]
    7b30:      	sxtw	x2, w1
    7b34:      	ldr	x3, [x20]
    7b38:      	add	x2, x3, x2, lsl #4
    7b3c:      	ldr	x2, [x2]
    7b40:      	cmp	x0, #0x0
    7b44:      	b.ne	0x7b74 <_stogir.loops.reorder!+0x77c>
    7b48:      	add	x16, sp, #0x190
    7b4c:      	ldr	x0, [x16, #0x8]
    7b50:      	orr	x19, x0, xzr
    7b54:      	add	x16, sp, #0x190
    7b58:      	ldr	x0, [x16, #0x10]
    7b5c:      	cmp	x19, x0
    7b60:      	b.lt	0x80d4 <_stogir.loops.reorder!+0xcdc>
    7b64:      	cmp	x0, #0x0
    7b68:      	b.ne	0x7aa0 <_stogir.loops.reorder!+0x6a8>
    7b6c:      	mov	x0, #0x2                ; =2
    7b70:      	b	0x7aa4 <_stogir.loops.reorder!+0x6ac>
    7b74:      	sub	x0, x0, #0x1
    7b78:      	add	x16, sp, #0xd0
    7b7c:      	ldr	x1, [x16]
    7b80:      	add	x3, x0, x2
    7b84:      	orr	x4, x1, xzr
    7b88:      	orr	x5, x1, xzr
    7b8c:      	add	x4, x4, x2, lsl #3
    7b90:      	add	x1, x1, x2, lsl #3
    7b94:      	add	x3, x5, x3, lsl #3
    7b98:      	ldr	x4, [x4]
    7b9c:      	ldr	x5, [x24, #0x50]
    7ba0:      	add	x4, x5, x4, lsl #4
    7ba4:      	ldr	x4, [x4]
    7ba8:      	ldr	x3, [x3]
    7bac:      	lsr	x4, x4, #32
    7bb0:      	str	x3, [x1]
    7bb4:      	sxtw	x1, w4
    7bb8:      	mov	x5, x27
    7bbc:      	str	x20, [sp, #0x278]
    7bc0:      	mov	x20, x0
    7bc4:      	str	x21, [sp, #0x280]
    7bc8:      	mov	w21, w4
    7bcc:      	mov	x4, x24
    7bd0:      	str	x22, [sp, #0x288]
    7bd4:      	mov	x22, x1
    7bd8:      	mov	x1, x2
    7bdc:      	mov	x2, x0
    7be0:      	ldr	x0, [sp, #0x260]
    7be4:      	movz	x3, #0x0, lsl #48
    7be8:      	bl	0x7be8 <_stogir.loops.reorder!+0x7f0>
		0000000000007be8:  ARM64_RELOC_BRANCH26	_stogir.loops.sift!
    7bec:      	add	x16, sp, #0x130
    7bf0:      	ldr	x0, [x16]
    7bf4:      	add	x0, x0, x19, lsl #4
    7bf8:      	str	x26, [x0]
    7bfc:      	str	x20, [x0, #0x8]
    7c00:      	add	x16, sp, #0x50
    7c04:      	ldr	x0, [x16]
    7c08:      	add	x0, x0, x22, lsl #2
    7c0c:      	ldr	w0, [x0]
    7c10:      	sxtw	x0, w0
    7c14:      	cmp	x0, #0x0
    7c18:      	b.ne	0x7af8 <_stogir.loops.reorder!+0x700>
    7c1c:      	ldr	x0, [x25]
    7c20:      	add	x0, x0, x22, lsl #4
    7c24:      	ldr	x1, [x0]
    7c28:      	ldr	x0, [x0, #0x8]
    7c2c:      	add	x16, sp, #0x230
    7c30:      	str	x1, [x16]
    7c34:      	add	x16, sp, #0x230
    7c38:      	str	x0, [x16, #0x8]
    7c3c:      	ldr	x0, [sp, #0x260]
    7c40:      	ldr	x1, [sp, #0x288]
    7c44:      	mov	x2, x24
    7c48:      	mov	x3, x27
    7c4c:      	bl	0x7c4c <_stogir.loops.reorder!+0x854>
		0000000000007c4c:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    7c50:      	add	x16, sp, #0x240
    7c54:      	movz	x17, #0x0, lsl #48
    7c58:      	str	x17, [x16]
    7c5c:      	add	x16, sp, #0x240
    7c60:      	movz	x17, #0x0, lsl #48
    7c64:      	str	x17, [x16, #0x8]
    7c68:      	add	x16, sp, #0x240
    7c6c:      	str	w21, [x16]
    7c70:      	add	x16, sp, #0x230
    7c74:      	ldr	x0, [x16, #0x8]
    7c78:      	orr	x19, x0, xzr
    7c7c:      	add	x16, sp, #0x240
    7c80:      	str	x19, [x16, #0x8]
    7c84:      	add	x16, sp, #0x240
    7c88:      	ldr	x20, [x16]
    7c8c:      	add	x16, sp, #0x130
    7c90:      	ldr	x0, [x16, #0x8]
    7c94:      	orr	x21, x0, xzr
    7c98:      	add	x16, sp, #0x130
    7c9c:      	ldr	x0, [x16, #0x10]
    7ca0:      	cmp	x21, x0
    7ca4:      	b.lt	0x7a64 <_stogir.loops.reorder!+0x66c>
    7ca8:      	cmp	x0, #0x0
    7cac:      	b.ne	0x7a54 <_stogir.loops.reorder!+0x65c>
    7cb0:      	mov	x0, #0x2                ; =2
    7cb4:      	b	0x7a58 <_stogir.loops.reorder!+0x660>
    7cb8:      	add	x16, sp, #0x190
    7cbc:      	ldr	x0, [x16, #0x8]
    7cc0:      	ldr	x1, [x28, #0x8]
    7cc4:      	cmp	x0, x1
    7cc8:      	cset	w19, eq
    7ccc:      	uxtb	w16, w19
    7cd0:      	cmp	w16, wzr
    7cd4:      	b.eq	0x7d48 <_stogir.loops.reorder!+0x950>
    7cd8:      	movn	x0, #0x0, lsl #48
    7cdc:      	movz	x20, #0x0, lsl #48
    7ce0:      	b	0x7cf8 <_stogir.loops.reorder!+0x900>
    7ce4:      	nop
    7ce8:      	mov	x20, #0x1               ; =1
    7cec:      	ldr	x2, [x28]
    7cf0:      	add	x2, x2, x0, lsl #2
    7cf4:      	str	w1, [x2]
    7cf8:      	ldr	x1, [x28, #0x8]
    7cfc:      	add	x0, x0, #0x1
    7d00:      	cmp	x0, x1
    7d04:      	b.ge	0x7d4c <_stogir.loops.reorder!+0x954>
    7d08:      	add	x16, sp, #0x190
    7d0c:      	ldr	x1, [x16, #0x8]
    7d10:      	add	x16, sp, #0x190
    7d14:      	ldr	x2, [x16]
    7d18:      	sub	x1, x1, #0x1
    7d1c:      	sub	x1, x1, x0
    7d20:      	add	x1, x2, x1, lsl #2
    7d24:      	ldr	w1, [x1]
    7d28:      	ldr	x2, [x28]
    7d2c:      	sxtw	x3, w1
    7d30:      	add	x2, x2, x0, lsl #2
    7d34:      	ldr	w2, [x2]
    7d38:      	sxtw	x2, w2
    7d3c:      	cmp	x2, x3
    7d40:      	b.eq	0x7cec <_stogir.loops.reorder!+0x8f4>
    7d44:      	b	0x7ce8 <_stogir.loops.reorder!+0x8f0>
    7d48:      	movz	x20, #0x0, lsl #48
    7d4c:      	ldr	x0, [sp, #0x258]
    7d50:      	bl	0x7d50 <_stogir.loops.reorder!+0x958>
		0000000000007d50:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7d54:      	ldr	x0, [sp, #0x260]
    7d58:      	bl	0x7d58 <_stogir.loops.reorder!+0x960>
		0000000000007d58:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    7d5c:      	ldr	x0, [sp, #0x270]
    7d60:      	bl	0x7d60 <_stogir.loops.reorder!+0x968>
		0000000000007d60:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame
    7d64:      	ldr	x0, [sp, #0x280]
    7d68:      	bl	0x7d68 <_stogir.loops.reorder!+0x970>
		0000000000007d68:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7d6c:      	uxtb	w16, w19
    7d70:      	cmp	w16, wzr
    7d74:      	b.eq	0x7e34 <_stogir.loops.reorder!+0xa3c>
    7d78:      	and	x0, x20, #0xff
    7d7c:      	movz	x1, #0x0, lsl #48
    7d80:      	movz	x2, #0x0, lsl #48
    7d84:      	b	0x7e44 <_stogir.loops.reorder!+0xa4c>
    7d88:      	movz	w5, #0x0, lsl #16
    7d8c:      	movz	w6, #0x0, lsl #16
    7d90:      	ubfx	x5, x5, #0, #32
    7d94:      	lsr	x16, x5, #0
    7d98:      	cmp	x16, #0x1
    7d9c:      	b.eq	0x7db8 <_stogir.loops.reorder!+0x9c0>
    7da0:      	b.lo	0x7da8 <_stogir.loops.reorder!+0x9b0>
    7da4:      	b	0x7dbc <_stogir.loops.reorder!+0x9c4>
    7da8:      	cmp	x16, #0x0
    7dac:      	b.eq	0x7db4 <_stogir.loops.reorder!+0x9bc>
    7db0:      	b	0x7dbc <_stogir.loops.reorder!+0x9c4>
    7db4:      	b	0x7e48 <_stogir.loops.reorder!+0xa50>
    7db8:      	b	0x7dc0 <_stogir.loops.reorder!+0x9c8>
    7dbc:      	b	0x800c <_stogir.loops.reorder!+0xc14>
    7dc0:      	sxtw	x5, w6
    7dc4:      	ldr	x7, [x26]
    7dc8:      	add	x7, x7, x5, lsl #2
    7dcc:      	ldr	w7, [x7]
    7dd0:      	sxtw	x7, w7
    7dd4:      	cmp	x7, #0x0
    7dd8:      	b.le	0x7e0c <_stogir.loops.reorder!+0xa14>
    7ddc:      	ldr	x7, [x19]
    7de0:      	add	x7, x7, x4, lsl #2
    7de4:      	ldr	w7, [x7]
    7de8:      	sxtw	x7, w7
    7dec:      	cmp	x7, x5
    7df0:      	b.eq	0x7df8 <_stogir.loops.reorder!+0xa00>
    7df4:      	mov	x3, #0x1                ; =1
    7df8:      	add	x5, x4, #0x1
    7dfc:      	ldr	x7, [x28]
    7e00:      	add	x4, x7, x4, lsl #2
    7e04:      	str	w6, [x4]
    7e08:      	mov	x4, x5
    7e0c:      	cmp	x2, x1
    7e10:      	b.ge	0x7d88 <_stogir.loops.reorder!+0x990>
    7e14:      	add	x5, x2, #0x1
    7e18:      	add	x2, x0, x2, lsl #2
    7e1c:      	ldr	w2, [x2]
    7e20:      	movn	w17, #0x0, lsl #16
    7e24:      	and	w6, w2, w17
    7e28:      	mov	x2, x5
    7e2c:      	mov	w5, #0x1                ; =1
    7e30:      	b	0x7d90 <_stogir.loops.reorder!+0x998>
    7e34:      	mov	x1, #0x1                ; =1
    7e38:      	adrp	x0, 0x7000 <_stogir.placement.late-with-uses!+0xa90>
		0000000000007e38:  ARM64_RELOC_PAGE21	l_stogir.441
    7e3c:      	ldr	x0, [x0]
		0000000000007e3c:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    7e40:      	mov	x2, #0x33               ; =51
    7e44:      	b	0x7e54 <_stogir.loops.reorder!+0xa5c>
    7e48:      	and	x0, x3, #0xff
    7e4c:      	movz	x1, #0x0, lsl #48
    7e50:      	movz	x2, #0x0, lsl #48
    7e54:      	str	x1, [x23]
    7e58:      	str	x0, [x23, #0x8]
    7e5c:      	str	x2, [x23, #0x10]
    7e60:      	ldr	x19, [sp, #0x290]
    7e64:      	ldr	x20, [sp, #0x298]
    7e68:      	ldr	x21, [sp, #0x2a0]
    7e6c:      	ldr	x22, [sp, #0x2a8]
    7e70:      	ldr	x23, [sp, #0x2b0]
    7e74:      	ldr	x24, [sp, #0x2b8]
    7e78:      	ldr	x25, [sp, #0x2c0]
    7e7c:      	ldr	x26, [sp, #0x2c8]
    7e80:      	ldr	x27, [sp, #0x2d0]
    7e84:      	ldr	x28, [sp, #0x2d8]
    7e88:      	ldr	x29, [sp]
    7e8c:      	ldr	x30, [sp, #0x8]
    7e90:      	add	sp, sp, #0x2e0
    7e94:      	ret
    7e98:      	cmp	x21, #0x0
    7e9c:      	b.eq	0x7f0c <_stogir.loops.reorder!+0xb14>
    7ea0:      	add	x16, sp, #0x50
    7ea4:      	orr	x19, x16, xzr
    7ea8:      	add	x8, sp, #0x80
    7eac:      	ldr	x0, [sp, #0x250]
    7eb0:      	bl	0x7eb0 <_stogir.loops.reorder!+0xab8>
		0000000000007eb0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7eb4:      	add	x16, sp, #0x80
    7eb8:      	ldr	x0, [x16]
    7ebc:      	add	x16, sp, #0x50
    7ec0:      	str	x0, [x16]
    7ec4:      	add	x16, sp, #0x80
    7ec8:      	ldr	x0, [x16, #0x8]
    7ecc:      	add	x16, sp, #0x50
    7ed0:      	str	x0, [x16, #0x8]
    7ed4:      	add	x16, sp, #0x80
    7ed8:      	ldr	x0, [x16, #0x10]
    7edc:      	add	x16, sp, #0x50
    7ee0:      	str	x0, [x16, #0x10]
    7ee4:      	add	x16, sp, #0x80
    7ee8:      	ldr	x0, [x16, #0x18]
    7eec:      	add	x16, sp, #0x50
    7ef0:      	str	x0, [x16, #0x18]
    7ef4:      	add	x16, sp, #0x80
    7ef8:      	ldr	x0, [x16, #0x20]
    7efc:      	add	x16, sp, #0x50
    7f00:      	str	x0, [x16, #0x20]
    7f04:      	movn	x20, #0x0, lsl #48
    7f08:      	b	0x7fd0 <_stogir.loops.reorder!+0xbd8>
    7f0c:      	add	x8, sp, #0x10
    7f10:      	mov	x0, x24
    7f14:      	bl	0x7f14 <_stogir.loops.reorder!+0xb1c>
		0000000000007f14:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    7f18:      	add	x16, sp, #0x10
    7f1c:      	ldr	x0, [x16]
    7f20:      	add	x16, sp, #0x10
    7f24:      	ldr	x1, [x16, #0x8]
    7f28:      	add	x16, sp, #0x10
    7f2c:      	ldr	x2, [x16, #0x10]
    7f30:      	movz	x3, #0x0, lsl #48
    7f34:      	b	0x7720 <_stogir.loops.reorder!+0x328>
    7f38:      	orr	w1, w0, wzr
    7f3c:      	ldr	x2, [x28]
    7f40:      	add	x2, x2, x0, lsl #2
    7f44:      	ldr	w2, [x2]
    7f48:      	sxtw	x2, w2
    7f4c:      	add	x16, sp, #0x50
    7f50:      	ldr	x3, [x16]
    7f54:      	add	x2, x3, x2, lsl #2
    7f58:      	str	w1, [x2]
    7f5c:      	ldr	x1, [x28, #0x8]
    7f60:      	add	x0, x0, #0x1
    7f64:      	cmp	x0, x1
    7f68:      	b.lt	0x7f38 <_stogir.loops.reorder!+0xb40>
    7f6c:      	add	x0, x24, #0x50
    7f70:      	add	x8, sp, #0xb0
    7f74:      	bl	0x7f74 <_stogir.loops.reorder!+0xb7c>
		0000000000007f74:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge
    7f78:      	add	x16, sp, #0xb0
    7f7c:      	ldr	x20, [x16]
    7f80:      	add	x16, sp, #0xb0
    7f84:      	ldr	x21, [x16, #0x8]
    7f88:      	add	x16, sp, #0xb0
    7f8c:      	ldr	x22, [x16, #0x10]
    7f90:      	mov	x0, #0x1                ; =1
    7f94:      	b	0x750c <_stogir.loops.reorder!+0x114>
    7f98:      	movn	x0, #0x0, lsl #48
    7f9c:      	b	0x7f5c <_stogir.loops.reorder!+0xb64>
    7fa0:      	lsl	x0, x0, #1
    7fa4:      	mov	x1, x0
    7fa8:      	mov	x0, x19
    7fac:      	bl	0x7fac <_stogir.loops.reorder!+0xbb4>
		0000000000007fac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    7fb0:      	add	x0, x21, #0x1
    7fb4:      	add	x16, sp, #0x50
    7fb8:      	ldr	x1, [x16]
    7fbc:      	add	x1, x1, x21, lsl #2
    7fc0:      	movn	w17, #0x0, lsl #16
    7fc4:      	str	w17, [x1]
    7fc8:      	add	x16, sp, #0x50
    7fcc:      	str	x0, [x16, #0x8]
    7fd0:      	ldr	x0, [x26, #0x8]
    7fd4:      	add	x20, x20, #0x1
    7fd8:      	cmp	x20, x0
    7fdc:      	b.ge	0x7f98 <_stogir.loops.reorder!+0xba0>
    7fe0:      	add	x16, sp, #0x50
    7fe4:      	ldr	x0, [x16, #0x8]
    7fe8:      	orr	x21, x0, xzr
    7fec:      	add	x16, sp, #0x50
    7ff0:      	ldr	x0, [x16, #0x10]
    7ff4:      	cmp	x21, x0
    7ff8:      	b.lt	0x7fb0 <_stogir.loops.reorder!+0xbb8>
    7ffc:      	cmp	x0, #0x0
    8000:      	b.ne	0x7fa0 <_stogir.loops.reorder!+0xba8>
    8004:      	mov	x0, #0x2                ; =2
    8008:      	b	0x7fa4 <_stogir.loops.reorder!+0xbac>
    800c:      	brk	#0
    8010:      	b	0x800c <_stogir.loops.reorder!+0xc14>
    8014:      	brk	#0
    8018:      	b	0x8014 <_stogir.loops.reorder!+0xc1c>
    801c:      	brk	#0
    8020:      	b	0x801c <_stogir.loops.reorder!+0xc24>
    8024:      	brk	#0
    8028:      	b	0x8024 <_stogir.loops.reorder!+0xc2c>
    802c:      	brk	#0
    8030:      	b	0x802c <_stogir.loops.reorder!+0xc34>
    8034:      	str	x19, [sp, #0x258]
    8038:      	mov	x19, x0
    803c:      	b	0x7504 <_stogir.loops.reorder!+0x10c>
    8040:      	str	x19, [sp, #0x258]
    8044:      	mov	x19, x0
    8048:      	b	0x7504 <_stogir.loops.reorder!+0x10c>
    804c:      	str	x19, [sp, #0x258]
    8050:      	mov	x19, x0
    8054:      	b	0x7504 <_stogir.loops.reorder!+0x10c>
    8058:      	mov	x23, x8
    805c:      	mov	x24, x0
    8060:      	mov	x25, x1
    8064:      	mov	x26, x2
    8068:      	mov	x27, x3
    806c:      	mov	x28, x4
    8070:      	str	x5, [sp, #0x250]
    8074:      	b	0x7870 <_stogir.loops.reorder!+0x478>
    8078:      	mov	x23, x8
    807c:      	mov	x24, x0
    8080:      	mov	x25, x1
    8084:      	mov	x26, x2
    8088:      	mov	x27, x3
    808c:      	mov	x28, x4
    8090:      	str	x5, [sp, #0x250]
    8094:      	b	0x7870 <_stogir.loops.reorder!+0x478>
    8098:      	mov	x23, x8
    809c:      	mov	x24, x0
    80a0:      	mov	x25, x1
    80a4:      	mov	x26, x2
    80a8:      	mov	x27, x3
    80ac:      	mov	x28, x4
    80b0:      	str	x5, [sp, #0x250]
    80b4:      	b	0x7870 <_stogir.loops.reorder!+0x478>
    80b8:      	str	x20, [sp, #0x260]
    80bc:      	str	x21, [sp, #0x268]
    80c0:      	mov	x20, x1
    80c4:      	mov	x21, x0
    80c8:      	b	0x78e8 <_stogir.loops.reorder!+0x4f0>
    80cc:      	str	x21, [sp, #0x280]
    80d0:      	b	0x7cb8 <_stogir.loops.reorder!+0x8c0>
    80d4:      	mov	w26, w1
    80d8:      	b	0x7ab4 <_stogir.loops.reorder!+0x6bc>
    80dc:      	udf	#0x0

00000000000080e0 <_stogir.schedule.order-with-uses>:
    80e0:      	sub	sp, sp, #0x2d0
    80e4:      	str	x29, [sp, #0x10]
    80e8:      	str	x30, [sp, #0x18]
    80ec:      	add	x29, sp, #0x10
    80f0:      	str	x19, [sp, #0x278]
    80f4:      	str	x20, [sp, #0x280]
    80f8:      	str	x21, [sp, #0x288]
    80fc:      	str	x22, [sp, #0x290]
    8100:      	str	x23, [sp, #0x298]
    8104:      	str	x24, [sp, #0x2a0]
    8108:      	str	x25, [sp, #0x2a8]
    810c:      	str	x26, [sp, #0x2b0]
    8110:      	str	x27, [sp, #0x2b8]
    8114:      	str	x28, [sp, #0x2c0]
    8118:      	add	x16, sp, #0x20
    811c:      	orr	x19, x16, xzr
    8120:      	add	x16, sp, #0x80
    8124:      	orr	x20, x16, xzr
    8128:      	add	x16, sp, #0xe0
    812c:      	orr	x21, x16, xzr
    8130:      	mov	x22, x8
    8134:      	add	x8, sp, #0x50
    8138:      	mov	x23, x0
    813c:      	mov	x0, x4
    8140:      	mov	x24, x1
    8144:      	mov	x25, x2
    8148:      	mov	x26, x3
    814c:      	mov	x27, x4
    8150:      	bl	0x8150 <_stogir.schedule.order-with-uses+0x70>
		0000000000008150:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    8154:      	add	x16, sp, #0x50
    8158:      	ldr	x0, [x16]
    815c:      	add	x16, sp, #0x20
    8160:      	str	x0, [x16]
    8164:      	add	x16, sp, #0x50
    8168:      	ldr	x0, [x16, #0x8]
    816c:      	add	x16, sp, #0x20
    8170:      	str	x0, [x16, #0x8]
    8174:      	add	x16, sp, #0x50
    8178:      	ldr	x0, [x16, #0x10]
    817c:      	add	x16, sp, #0x20
    8180:      	str	x0, [x16, #0x10]
    8184:      	add	x16, sp, #0x50
    8188:      	ldr	x0, [x16, #0x18]
    818c:      	add	x16, sp, #0x20
    8190:      	str	x0, [x16, #0x18]
    8194:      	add	x16, sp, #0x50
    8198:      	ldr	x0, [x16, #0x20]
    819c:      	add	x16, sp, #0x20
    81a0:      	str	x0, [x16, #0x20]
    81a4:      	add	x8, sp, #0xb0
    81a8:      	mov	x0, x27
    81ac:      	bl	0x81ac <_stogir.schedule.order-with-uses+0xcc>
		00000000000081ac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    81b0:      	add	x16, sp, #0xb0
    81b4:      	ldr	x0, [x16]
    81b8:      	add	x16, sp, #0x80
    81bc:      	str	x0, [x16]
    81c0:      	add	x16, sp, #0xb0
    81c4:      	ldr	x0, [x16, #0x8]
    81c8:      	add	x16, sp, #0x80
    81cc:      	str	x0, [x16, #0x8]
    81d0:      	add	x16, sp, #0xb0
    81d4:      	ldr	x0, [x16, #0x10]
    81d8:      	add	x16, sp, #0x80
    81dc:      	str	x0, [x16, #0x10]
    81e0:      	add	x16, sp, #0xb0
    81e4:      	ldr	x0, [x16, #0x18]
    81e8:      	add	x16, sp, #0x80
    81ec:      	str	x0, [x16, #0x18]
    81f0:      	add	x16, sp, #0xb0
    81f4:      	ldr	x0, [x16, #0x20]
    81f8:      	add	x16, sp, #0x80
    81fc:      	str	x0, [x16, #0x20]
    8200:      	add	x8, sp, #0x110
    8204:      	mov	x0, x27
    8208:      	bl	0x8208 <_stogir.schedule.order-with-uses+0x128>
		0000000000008208:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    820c:      	add	x16, sp, #0x110
    8210:      	ldr	x0, [x16]
    8214:      	add	x16, sp, #0xe0
    8218:      	str	x0, [x16]
    821c:      	add	x16, sp, #0x110
    8220:      	ldr	x0, [x16, #0x8]
    8224:      	add	x16, sp, #0xe0
    8228:      	str	x0, [x16, #0x8]
    822c:      	add	x16, sp, #0x110
    8230:      	ldr	x0, [x16, #0x10]
    8234:      	add	x16, sp, #0xe0
    8238:      	str	x0, [x16, #0x10]
    823c:      	add	x16, sp, #0x110
    8240:      	ldr	x0, [x16, #0x18]
    8244:      	add	x16, sp, #0xe0
    8248:      	str	x0, [x16, #0x18]
    824c:      	add	x16, sp, #0x110
    8250:      	ldr	x0, [x16, #0x20]
    8254:      	add	x16, sp, #0xe0
    8258:      	str	x0, [x16, #0x20]
    825c:      	add	x8, sp, #0x170
    8260:      	mov	x0, x27
    8264:      	bl	0x8264 <_stogir.schedule.order-with-uses+0x184>
		0000000000008264:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    8268:      	add	x16, sp, #0x170
    826c:      	ldr	x0, [x16]
    8270:      	add	x16, sp, #0x140
    8274:      	str	x0, [x16]
    8278:      	add	x16, sp, #0x170
    827c:      	ldr	x0, [x16, #0x8]
    8280:      	add	x16, sp, #0x140
    8284:      	str	x0, [x16, #0x8]
    8288:      	add	x16, sp, #0x170
    828c:      	ldr	x0, [x16, #0x10]
    8290:      	add	x16, sp, #0x140
    8294:      	str	x0, [x16, #0x10]
    8298:      	add	x16, sp, #0x170
    829c:      	ldr	x0, [x16, #0x18]
    82a0:      	add	x16, sp, #0x140
    82a4:      	str	x0, [x16, #0x18]
    82a8:      	add	x16, sp, #0x170
    82ac:      	ldr	x0, [x16, #0x20]
    82b0:      	add	x16, sp, #0x140
    82b4:      	str	x0, [x16, #0x20]
    82b8:      	ldr	x0, [x23, #0x8]
    82bc:      	mov	x1, x0
    82c0:      	mov	x0, x20
    82c4:      	bl	0x82c4 <_stogir.schedule.order-with-uses+0x1e4>
		00000000000082c4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    82c8:      	mov	x0, x23
    82cc:      	bl	0x82cc <_stogir.schedule.order-with-uses+0x1ec>
		00000000000082cc:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    82d0:      	mov	x1, x0
    82d4:      	mov	x0, x21
    82d8:      	bl	0x82d8 <_stogir.schedule.order-with-uses+0x1f8>
		00000000000082d8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64
    82dc:      	movz	x28, #0x0, lsl #48
    82e0:      	b	0x8328 <_stogir.schedule.order-with-uses+0x248>
    82e4:      	nop
    82e8:      	lsl	x1, x1, #1
    82ec:      	str	x19, [sp, #0x1e0]
    82f0:      	fmov	d31, x0
    82f4:      	mov	x0, x19
    82f8:      	fmov	x19, d31
    82fc:      	bl	0x82fc <_stogir.schedule.order-with-uses+0x21c>
		00000000000082fc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    8300:      	add	x28, x28, #0x1
    8304:      	add	x0, x19, #0x1
    8308:      	add	x16, sp, #0x20
    830c:      	ldr	x1, [x16]
    8310:      	add	x1, x1, x19, lsl #3
    8314:      	movn	x17, #0x0, lsl #48
    8318:      	str	x17, [x1]
    831c:      	add	x16, sp, #0x20
    8320:      	str	x0, [x16, #0x8]
    8324:      	ldr	x19, [sp, #0x1e0]
    8328:      	ldr	x0, [x23, #0x8]
    832c:      	cmp	x28, x0
    8330:      	b.ge	0x8cb8 <_stogir.schedule.order-with-uses+0xbd8>
    8334:      	add	x16, sp, #0x20
    8338:      	ldr	x0, [x16, #0x8]
    833c:      	add	x16, sp, #0x20
    8340:      	ldr	x1, [x16, #0x10]
    8344:      	cmp	x0, x1
    8348:      	b.lt	0x8cc0 <_stogir.schedule.order-with-uses+0xbe0>
    834c:      	cmp	x1, #0x0
    8350:      	b.ne	0x82e8 <_stogir.schedule.order-with-uses+0x208>
    8354:      	mov	x1, #0x2                ; =2
    8358:      	b	0x82ec <_stogir.schedule.order-with-uses+0x20c>
    835c:      	mov	x19, #0x1               ; =1
    8360:      	adrp	x0, 0x8000 <_stogir.loops.reorder!+0xc08>
		0000000000008360:  ARM64_RELOC_PAGE21	l_stogir.442
    8364:      	ldr	x0, [x0]
		0000000000008364:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8368:      	movz	x1, #0x0, lsl #48
    836c:      	movz	x28, #0x0, lsl #48
    8370:      	b	0x8598 <_stogir.schedule.order-with-uses+0x4b8>
    8374:      	add	x16, sp, #0xe0
    8378:      	ldr	x0, [x16]
    837c:      	orr	x1, x0, xzr
    8380:      	add	x1, x1, x22, lsl #3
    8384:      	add	x0, x0, x22, lsl #3
    8388:      	ldr	x1, [x1]
    838c:      	add	x1, x1, #0x1
    8390:      	str	x1, [x0]
    8394:      	sxtw	x20, w20
    8398:      	cmp	x21, #0x43
    839c:      	cset	w0, eq
    83a0:      	cmp	x21, #0x83
    83a4:      	cset	w1, lt
    83a8:      	adrp	x17, 0x8000 <_stogir.loops.reorder!+0xc08>
		00000000000083a8:  ARM64_RELOC_PAGE21	l_stogir.443
    83ac:      	ldr	x17, [x17]
		00000000000083ac:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    83b0:      	add	x2, x21, x17
    83b4:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xc08>
		00000000000083b4:  ARM64_RELOC_PAGE21	l_stogir.444
    83b8:      	ldr	x16, [x16]
		00000000000083b8:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    83bc:      	add	x3, x16, x21, lsl #2
    83c0:      	orr	x21, x3, xzr
    83c4:      	mov	x3, #0x1                ; =1
    83c8:      	movz	x4, #0x0, lsl #48
    83cc:      	b	0x8440 <_stogir.schedule.order-with-uses+0x360>
    83d0:      	movz	w5, #0x0, lsl #16
    83d4:      	uxtb	w16, w5
    83d8:      	and	w5, w16, #0x2
    83dc:      	uxtb	w5, w5
    83e0:      	ubfx	x5, x5, #0, #8
    83e4:      	cmp	x5, #0x0
    83e8:      	cset	w5, eq
    83ec:      	uxtb	w16, w5
    83f0:      	cmp	w16, wzr
    83f4:      	cset	x5, eq
    83f8:      	cmp	x5, #0x0
    83fc:      	b.eq	0x845c <_stogir.schedule.order-with-uses+0x37c>
    8400:      	str	x20, [sp, #0x230]
    8404:      	mov	x20, x3
    8408:      	str	w0, [sp, #0x218]
    840c:      	str	w1, [sp, #0x220]
    8410:      	str	x2, [sp, #0x228]
    8414:      	str	x21, [sp, #0x238]
    8418:      	mov	x21, x4
    841c:      	add	x0, x20, #0x1
    8420:      	sxtw	x20, w0
    8424:      	ldr	w0, [sp, #0x218]
    8428:      	ldr	w1, [sp, #0x220]
    842c:      	ldr	x2, [sp, #0x228]
    8430:      	mov	x3, x20
    8434:      	ldr	x20, [sp, #0x230]
    8438:      	mov	x4, x21
    843c:      	ldr	x21, [sp, #0x238]
    8440:      	cmp	x3, x20
    8444:      	b.gt	0x8ccc <_stogir.schedule.order-with-uses+0xbec>
    8448:      	uxtb	w16, w1
    844c:      	cmp	w16, wzr
    8450:      	b.eq	0x83d0 <_stogir.schedule.order-with-uses+0x2f0>
    8454:      	ldrb	w5, [x2]
    8458:      	b	0x83d4 <_stogir.schedule.order-with-uses+0x2f4>
    845c:      	orr	w5, w3, wzr
    8460:      	sxtw	x6, w5
    8464:      	uxtb	w16, w0
    8468:      	cmp	w16, wzr
    846c:      	b.eq	0x8498 <_stogir.schedule.order-with-uses+0x3b8>
    8470:      	cmp	x6, #0x2
    8474:      	b.lt	0x8498 <_stogir.schedule.order-with-uses+0x3b8>
    8478:      	str	x20, [sp, #0x230]
    847c:      	mov	x20, x3
    8480:      	str	w0, [sp, #0x218]
    8484:      	str	w1, [sp, #0x220]
    8488:      	str	x2, [sp, #0x228]
    848c:      	str	x21, [sp, #0x238]
    8490:      	mov	x21, x4
    8494:      	b	0x841c <_stogir.schedule.order-with-uses+0x33c>
    8498:      	uxtb	w16, w1
    849c:      	cmp	w16, wzr
    84a0:      	b.eq	0x84c8 <_stogir.schedule.order-with-uses+0x3e8>
    84a4:      	ldr	w7, [x21]
    84a8:      	cmp	x6, #0x0
    84ac:      	b.le	0x84c0 <_stogir.schedule.order-with-uses+0x3e0>
    84b0:      	cmp	x6, #0x4
    84b4:      	b.le	0x8c54 <_stogir.schedule.order-with-uses+0xb74>
    84b8:      	mov	w6, #0x4                ; =4
    84bc:      	b	0x8c58 <_stogir.schedule.order-with-uses+0xb78>
    84c0:      	movz	w6, #0x0, lsl #16
    84c4:      	b	0x84cc <_stogir.schedule.order-with-uses+0x3ec>
    84c8:      	movz	w6, #0x0, lsl #16
    84cc:      	ubfx	x6, x6, #0, #32
    84d0:      	cmp	x6, #0xf
    84d4:      	b.hs	0x8cd4 <_stogir.schedule.order-with-uses+0xbf4>
    84d8:      	mov	x16, #0x1               ; =1
    84dc:      	lsl	x6, x16, x6
    84e0:      	mov	w17, #0x5e1c            ; =24092
    84e4:      	and	w6, w6, w17
    84e8:      	ubfx	x6, x6, #0, #32
    84ec:      	cmp	x6, #0x0
    84f0:      	b.eq	0x8cf4 <_stogir.schedule.order-with-uses+0xc14>
    84f4:      	str	w0, [sp, #0x218]
    84f8:      	mov	x0, x23
    84fc:      	str	w1, [sp, #0x220]
    8500:      	mov	w1, w27
    8504:      	str	x2, [sp, #0x228]
    8508:      	mov	w2, w5
    850c:      	str	x20, [sp, #0x230]
    8510:      	mov	x20, x3
    8514:      	str	x21, [sp, #0x238]
    8518:      	mov	x21, x4
    851c:      	bl	0x851c <_stogir.schedule.order-with-uses+0x43c>
		000000000000851c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    8520:      	ubfx	x0, x0, #0, #32
    8524:      	lsr	x16, x0, #0
    8528:      	cmp	x16, #0x1
    852c:      	b.eq	0x8548 <_stogir.schedule.order-with-uses+0x468>
    8530:      	b.lo	0x8538 <_stogir.schedule.order-with-uses+0x458>
    8534:      	b	0x854c <_stogir.schedule.order-with-uses+0x46c>
    8538:      	cmp	x16, #0x0
    853c:      	b.eq	0x8544 <_stogir.schedule.order-with-uses+0x464>
    8540:      	b	0x854c <_stogir.schedule.order-with-uses+0x46c>
    8544:      	b	0x8550 <_stogir.schedule.order-with-uses+0x470>
    8548:      	b	0x8c6c <_stogir.schedule.order-with-uses+0xb8c>
    854c:      	b	0x8cb0 <_stogir.schedule.order-with-uses+0xbd0>
    8550:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xc08>
		0000000000008550:  ARM64_RELOC_PAGE21	l_stogir.445
    8554:      	ldr	x16, [x16]
		0000000000008554:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    8558:      	str	x16, [sp, #0x208]
    855c:      	mov	x16, #0x19              ; =25
    8560:      	str	x16, [sp, #0x210]
    8564:      	b	0x8c94 <_stogir.schedule.order-with-uses+0xbb4>
    8568:      	add	x28, x28, #0x1
    856c:      	add	x16, sp, #0x20
    8570:      	ldr	x0, [x16]
    8574:      	add	x0, x0, x19, lsl #3
    8578:      	str	x21, [x0]
    857c:      	add	x19, x19, #0x1
    8580:      	ldr	x22, [sp, #0x200]
    8584:      	ldr	x27, [sp, #0x1f8]
    8588:      	ldr	x20, [sp, #0x1e8]
    858c:      	ldr	x21, [sp, #0x1f0]
    8590:      	ldr	x0, [sp, #0x208]
    8594:      	ldr	x1, [sp, #0x210]
    8598:      	cmp	x1, #0x0
    859c:      	b.ne	0x8d14 <_stogir.schedule.order-with-uses+0xc34>
    85a0:      	add	x16, sp, #0x20
    85a4:      	ldr	x2, [x16, #0x8]
    85a8:      	cmp	x19, x2
    85ac:      	b.ge	0x8d30 <_stogir.schedule.order-with-uses+0xc50>
    85b0:      	orr	w2, w19, wzr
    85b4:      	str	x20, [sp, #0x1e8]
    85b8:      	mov	x20, x0
    85bc:      	mov	x0, x23
    85c0:      	str	x21, [sp, #0x1f0]
    85c4:      	mov	x21, x1
    85c8:      	mov	w1, w2
    85cc:      	str	x27, [sp, #0x1f8]
    85d0:      	mov	w27, w2
    85d4:      	bl	0x85d4 <_stogir.schedule.order-with-uses+0x4f4>
		00000000000085d4:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
    85d8:      	cmp	x0, #0x0
    85dc:      	b.eq	0x8d4c <_stogir.schedule.order-with-uses+0xc6c>
    85e0:      	ldr	x0, [x25]
    85e4:      	add	x0, x19, x0
    85e8:      	ldrb	w0, [x0]
    85ec:      	cmp	x0, #0x0
    85f0:      	b.eq	0x8d5c <_stogir.schedule.order-with-uses+0xc7c>
    85f4:      	ldr	x0, [x24]
    85f8:      	add	x0, x0, x19, lsl #2
    85fc:      	ldr	w0, [x0]
    8600:      	sxtw	x0, w0
    8604:      	ldr	x1, [x23]
    8608:      	add	x1, x1, x19, lsl #4
    860c:      	ldr	x1, [x1]
    8610:      	ldr	x2, [x23, #0x78]
    8614:      	add	x2, x2, x19, lsl #2
    8618:      	ldr	w2, [x2]
    861c:      	cmp	x0, #0x0
    8620:      	b.gt	0x8640 <_stogir.schedule.order-with-uses+0x560>
    8624:      	str	x22, [sp, #0x200]
    8628:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xc08>
		0000000000008628:  ARM64_RELOC_PAGE21	l_stogir.446
    862c:      	ldr	x16, [x16]
		000000000000862c:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    8630:      	str	x16, [sp, #0x208]
    8634:      	mov	x16, #0x19              ; =25
    8638:      	str	x16, [sp, #0x210]
    863c:      	b	0x857c <_stogir.schedule.order-with-uses+0x49c>
    8640:      	uxtb	w1, w1
    8644:      	orr	x3, x1, xzr
    8648:      	str	x22, [sp, #0x200]
    864c:      	mov	x22, x0
    8650:      	mov	w0, w3
    8654:      	str	x20, [sp, #0x208]
    8658:      	mov	w20, w2
    865c:      	str	x21, [sp, #0x210]
    8660:      	mov	w21, w1
    8664:      	bl	0x8664 <_stogir.schedule.order-with-uses+0x584>
		0000000000008664:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    8668:      	cmp	x0, #0x0
    866c:      	b.eq	0x8374 <_stogir.schedule.order-with-uses+0x294>
    8670:      	add	x16, sp, #0x80
    8674:      	ldr	x0, [x16]
    8678:      	add	x1, x0, x22, lsl #2
    867c:      	ldr	w1, [x1]
    8680:      	sxtw	x1, w1
    8684:      	cmp	x1, #0x0
    8688:      	b.ne	0x8c98 <_stogir.schedule.order-with-uses+0xbb8>
    868c:      	add	x0, x0, x22, lsl #2
    8690:      	str	w27, [x0]
    8694:      	b	0x8cac <_stogir.schedule.order-with-uses+0xbcc>
    8698:      	lsl	x6, x6, #1
    869c:      	str	x3, [sp, #0x250]
    86a0:      	str	x2, [sp, #0x258]
    86a4:      	str	x19, [sp, #0x240]
    86a8:      	str	x20, [sp, #0x248]
    86ac:      	mov	x20, x1
    86b0:      	mov	x1, x6
    86b4:      	str	w22, [sp, #0x260]
    86b8:      	mov	x22, x4
    86bc:      	str	x23, [sp, #0x268]
    86c0:      	mov	w23, w7
    86c4:      	str	x24, [sp, #0x270]
    86c8:      	mov	x24, x5
    86cc:      	fmov	d31, x0
    86d0:      	mov	x0, x19
    86d4:      	fmov	x19, d31
    86d8:      	bl	0x86d8 <_stogir.schedule.order-with-uses+0x5f8>
		00000000000086d8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    86dc:      	add	x0, x24, #0x1
    86e0:      	add	x16, sp, #0x140
    86e4:      	ldr	x1, [x16]
    86e8:      	add	x1, x1, x24, lsl #2
    86ec:      	str	w23, [x1]
    86f0:      	add	x16, sp, #0x140
    86f4:      	str	x0, [x16, #0x8]
    86f8:      	b	0x8890 <_stogir.schedule.order-with-uses+0x7b0>
    86fc:      	add	x16, sp, #0x140
    8700:      	orr	x19, x16, xzr
    8704:      	mov	x20, #0x1               ; =1
    8708:      	b	0x8740 <_stogir.schedule.order-with-uses+0x660>
    870c:      	nop
    8710:      	lsl	x0, x0, #1
    8714:      	mov	x1, x0
    8718:      	mov	x0, x19
    871c:      	bl	0x871c <_stogir.schedule.order-with-uses+0x63c>
		000000000000871c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8720:      	add	x0, x22, #0x1
    8724:      	add	x16, sp, #0x140
    8728:      	ldr	x1, [x16]
    872c:      	add	x1, x1, x22, lsl #2
    8730:      	str	w21, [x1]
    8734:      	add	x16, sp, #0x140
    8738:      	str	x0, [x16, #0x8]
    873c:      	add	x20, x20, #0x1
    8740:      	add	x16, sp, #0x20
    8744:      	ldr	x0, [x16, #0x8]
    8748:      	cmp	x20, x0
    874c:      	b.ge	0x8808 <_stogir.schedule.order-with-uses+0x728>
    8750:      	add	x16, sp, #0x20
    8754:      	ldr	x0, [x16]
    8758:      	orr	x1, x0, xzr
    875c:      	add	x2, x1, x20, lsl #3
    8760:      	ldr	x2, [x2]
    8764:      	cmp	x2, #0x0
    8768:      	b.lt	0x873c <_stogir.schedule.order-with-uses+0x65c>
    876c:      	orr	w21, w20, wzr
    8770:      	ldr	x2, [x24]
    8774:      	sxtw	x3, w21
    8778:      	add	x2, x2, x20, lsl #2
    877c:      	ldr	w2, [x2]
    8780:      	sxtw	x2, w2
    8784:      	add	x16, sp, #0x80
    8788:      	ldr	x4, [x16]
    878c:      	add	x4, x4, x2, lsl #2
    8790:      	ldr	w4, [x4]
    8794:      	sxtw	x4, w4
    8798:      	cmp	x4, x3
    879c:      	b.ne	0x87c4 <_stogir.schedule.order-with-uses+0x6e4>
    87a0:      	add	x1, x1, x20, lsl #3
    87a4:      	add	x0, x0, x20, lsl #3
    87a8:      	ldr	x1, [x1]
    87ac:      	add	x16, sp, #0xe0
    87b0:      	ldr	x3, [x16]
    87b4:      	add	x2, x3, x2, lsl #3
    87b8:      	ldr	x2, [x2]
    87bc:      	add	x1, x2, x1
    87c0:      	str	x1, [x0]
    87c4:      	add	x16, sp, #0x20
    87c8:      	ldr	x0, [x16]
    87cc:      	add	x0, x0, x20, lsl #3
    87d0:      	ldr	x0, [x0]
    87d4:      	cmp	x0, #0x0
    87d8:      	b.ne	0x873c <_stogir.schedule.order-with-uses+0x65c>
    87dc:      	add	x16, sp, #0x140
    87e0:      	ldr	x0, [x16, #0x8]
    87e4:      	orr	x22, x0, xzr
    87e8:      	add	x16, sp, #0x140
    87ec:      	ldr	x0, [x16, #0x10]
    87f0:      	cmp	x22, x0
    87f4:      	b.lt	0x8720 <_stogir.schedule.order-with-uses+0x640>
    87f8:      	cmp	x0, #0x0
    87fc:      	b.ne	0x8710 <_stogir.schedule.order-with-uses+0x630>
    8800:      	mov	x0, #0x2                ; =2
    8804:      	b	0x8714 <_stogir.schedule.order-with-uses+0x634>
    8808:      	orr	x20, x24, xzr
    880c:      	ldr	x21, [sp, #0x210]
    8810:      	cmp	x21, #0x0
    8814:      	cset	w22, eq
    8818:      	movz	x27, #0x0, lsl #48
    881c:      	b	0x8a04 <_stogir.schedule.order-with-uses+0x924>
    8820:      	sub	w5, w5, #0x1
    8824:      	lsl	w5, w5, #2
    8828:      	ubfx	x5, x5, #0, #32
    882c:      	lsr	x5, x6, x5
    8830:      	and	w5, w5, #0xf
    8834:      	b	0x8a94 <_stogir.schedule.order-with-uses+0x9b4>
    8838:      	movz	w10, #0x0, lsl #16
    883c:      	uxtb	w16, w10
    8840:      	and	w10, w16, #0x2
    8844:      	uxtb	w10, w10
    8848:      	ubfx	x10, x10, #0, #8
    884c:      	cmp	x10, #0x0
    8850:      	cset	w10, eq
    8854:      	uxtb	w16, w10
    8858:      	cmp	w16, wzr
    885c:      	cset	x10, eq
    8860:      	cmp	x10, #0x0
    8864:      	b.eq	0x8940 <_stogir.schedule.order-with-uses+0x860>
    8868:      	str	x23, [sp, #0x268]
    886c:      	str	x19, [sp, #0x240]
    8870:      	mov	x19, x0
    8874:      	str	x20, [sp, #0x248]
    8878:      	mov	x20, x1
    887c:      	str	x3, [sp, #0x250]
    8880:      	str	x2, [sp, #0x258]
    8884:      	str	x24, [sp, #0x270]
    8888:      	str	w22, [sp, #0x260]
    888c:      	mov	x22, x4
    8890:      	add	x22, x22, #0x1
    8894:      	ldr	x23, [sp, #0x268]
    8898:      	mov	x0, x19
    889c:      	ldr	x19, [sp, #0x240]
    88a0:      	mov	x1, x20
    88a4:      	ldr	x20, [sp, #0x248]
    88a8:      	ldr	x3, [sp, #0x250]
    88ac:      	ldr	x2, [sp, #0x258]
    88b0:      	ldr	x24, [sp, #0x270]
    88b4:      	mov	x4, x22
    88b8:      	ldr	w22, [sp, #0x260]
    88bc:      	cmp	x4, x2
    88c0:      	b.ge	0x8d6c <_stogir.schedule.order-with-uses+0xc8c>
    88c4:      	add	x5, x3, x4
    88c8:      	ldr	x6, [x26, #0x28]
    88cc:      	add	x5, x6, x5, lsl #3
    88d0:      	ldr	x5, [x5]
    88d4:      	ldr	x6, [x23]
    88d8:      	orr	w7, w5, wzr
    88dc:      	sxtw	x8, w7
    88e0:      	add	x6, x6, x8, lsl #4
    88e4:      	ldr	x6, [x6]
    88e8:      	ldr	x9, [x25]
    88ec:      	add	x9, x9, x8
    88f0:      	ldrb	w9, [x9]
    88f4:      	cmp	x9, #0x0
    88f8:      	b.eq	0x8d8c <_stogir.schedule.order-with-uses+0xcac>
    88fc:      	ldr	x9, [x24]
    8900:      	add	x9, x9, x8, lsl #2
    8904:      	ldr	w9, [x9]
    8908:      	sxtw	x9, w9
    890c:      	cmp	x9, x1
    8910:      	b.ne	0x8db8 <_stogir.schedule.order-with-uses+0xcd8>
    8914:      	uxtb	w6, w6
    8918:      	cmp	x6, #0x83
    891c:      	cset	w9, lt
    8920:      	uxtb	w16, w9
    8924:      	cmp	w16, wzr
    8928:      	b.eq	0x8838 <_stogir.schedule.order-with-uses+0x758>
    892c:      	adrp	x17, 0x8000 <_stogir.loops.reorder!+0xc08>
		000000000000892c:  ARM64_RELOC_PAGE21	l_stogir.443
    8930:      	ldr	x17, [x17]
		0000000000008930:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    8934:      	add	x10, x6, x17
    8938:      	ldrb	w10, [x10]
    893c:      	b	0x883c <_stogir.schedule.order-with-uses+0x75c>
    8940:      	lsr	x5, x5, #32
    8944:      	sxtw	x10, w5
    8948:      	cmp	x6, #0x43
    894c:      	b.ne	0x8a5c <_stogir.schedule.order-with-uses+0x97c>
    8950:      	cmp	x10, #0x2
    8954:      	b.lt	0x8a5c <_stogir.schedule.order-with-uses+0x97c>
    8958:      	str	x23, [sp, #0x268]
    895c:      	str	x19, [sp, #0x240]
    8960:      	mov	x19, x0
    8964:      	str	x20, [sp, #0x248]
    8968:      	mov	x20, x1
    896c:      	str	x3, [sp, #0x250]
    8970:      	str	x2, [sp, #0x258]
    8974:      	str	x24, [sp, #0x270]
    8978:      	str	w22, [sp, #0x260]
    897c:      	mov	x22, x4
    8980:      	b	0x8890 <_stogir.schedule.order-with-uses+0x7b0>
    8984:      	add	x16, sp, #0x80
    8988:      	ldr	x0, [x16]
    898c:      	add	x0, x0, x20, lsl #2
    8990:      	ldr	w0, [x0]
    8994:      	sxtw	x1, w0
    8998:      	cmp	x1, #0x0
    899c:      	b.le	0x89ec <_stogir.schedule.order-with-uses+0x90c>
    89a0:      	cmp	x1, x19
    89a4:      	b.eq	0x89ec <_stogir.schedule.order-with-uses+0x90c>
    89a8:      	add	x16, sp, #0x20
    89ac:      	ldr	x2, [x16]
    89b0:      	orr	x3, x2, xzr
    89b4:      	add	x3, x3, x1, lsl #3
    89b8:      	add	x2, x2, x1, lsl #3
    89bc:      	ldr	x3, [x3]
    89c0:      	sub	x3, x3, #0x1
    89c4:      	str	x3, [x2]
    89c8:      	add	x16, sp, #0x20
    89cc:      	ldr	x2, [x16]
    89d0:      	add	x1, x2, x1, lsl #3
    89d4:      	ldr	x1, [x1]
    89d8:      	cmp	x1, #0x0
    89dc:      	b.ne	0x89ec <_stogir.schedule.order-with-uses+0x90c>
    89e0:      	mov	w1, w0
    89e4:      	ldr	x0, [sp, #0x240]
    89e8:      	bl	0x89e8 <_stogir.schedule.order-with-uses+0x908>
		00000000000089e8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    89ec:      	add	x27, x27, #0x1
    89f0:      	ldr	x23, [sp, #0x268]
    89f4:      	ldr	x19, [sp, #0x240]
    89f8:      	ldr	x20, [sp, #0x248]
    89fc:      	ldr	x24, [sp, #0x270]
    8a00:      	ldr	w22, [sp, #0x260]
    8a04:      	uxtb	w16, w22
    8a08:      	cmp	w16, wzr
    8a0c:      	b.eq	0x8de4 <_stogir.schedule.order-with-uses+0xd04>
    8a10:      	add	x16, sp, #0x140
    8a14:      	ldr	x0, [x16, #0x8]
    8a18:      	cmp	x27, x0
    8a1c:      	b.ge	0x8df0 <_stogir.schedule.order-with-uses+0xd10>
    8a20:      	add	x16, sp, #0x140
    8a24:      	ldr	x0, [x16]
    8a28:      	add	x0, x0, x27, lsl #2
    8a2c:      	ldr	w0, [x0]
    8a30:      	sxtw	x0, w0
    8a34:      	ldr	x1, [x20]
    8a38:      	add	x1, x1, x0, lsl #2
    8a3c:      	ldr	w1, [x1]
    8a40:      	sxtw	x1, w1
    8a44:      	ldr	x2, [x26]
    8a48:      	add	x2, x2, x0, lsl #4
    8a4c:      	ldr	x3, [x2]
    8a50:      	ldr	x2, [x2, #0x8]
    8a54:      	movz	x4, #0x0, lsl #48
    8a58:      	b	0x88bc <_stogir.schedule.order-with-uses+0x7dc>
    8a5c:      	uxtb	w16, w9
    8a60:      	cmp	w16, wzr
    8a64:      	b.eq	0x8a98 <_stogir.schedule.order-with-uses+0x9b8>
    8a68:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xc08>
		0000000000008a68:  ARM64_RELOC_PAGE21	l_stogir.444
    8a6c:      	ldr	x16, [x16]
		0000000000008a6c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    8a70:      	add	x6, x16, x6, lsl #2
    8a74:      	ldr	w6, [x6]
    8a78:      	cmp	x10, #0x0
    8a7c:      	b.le	0x8a90 <_stogir.schedule.order-with-uses+0x9b0>
    8a80:      	cmp	x10, #0x4
    8a84:      	b.le	0x8820 <_stogir.schedule.order-with-uses+0x740>
    8a88:      	mov	w5, #0x4                ; =4
    8a8c:      	b	0x8824 <_stogir.schedule.order-with-uses+0x744>
    8a90:      	movz	w5, #0x0, lsl #16
    8a94:      	b	0x8a9c <_stogir.schedule.order-with-uses+0x9bc>
    8a98:      	movz	w5, #0x0, lsl #16
    8a9c:      	ubfx	x5, x5, #0, #32
    8aa0:      	cmp	x5, #0xf
    8aa4:      	b.hs	0x8dfc <_stogir.schedule.order-with-uses+0xd1c>
    8aa8:      	mov	x16, #0x1               ; =1
    8aac:      	lsl	x5, x16, x5
    8ab0:      	mov	w17, #0x5e1c            ; =24092
    8ab4:      	and	w5, w5, w17
    8ab8:      	ubfx	x5, x5, #0, #32
    8abc:      	cmp	x5, #0x0
    8ac0:      	b.eq	0x8e28 <_stogir.schedule.order-with-uses+0xd48>
    8ac4:      	add	x16, sp, #0x20
    8ac8:      	ldr	x5, [x16]
    8acc:      	orr	x6, x5, xzr
    8ad0:      	add	x6, x6, x8, lsl #3
    8ad4:      	add	x5, x5, x8, lsl #3
    8ad8:      	ldr	x6, [x6]
    8adc:      	sub	x6, x6, #0x1
    8ae0:      	str	x6, [x5]
    8ae4:      	add	x16, sp, #0x20
    8ae8:      	ldr	x5, [x16]
    8aec:      	add	x5, x5, x8, lsl #3
    8af0:      	ldr	x5, [x5]
    8af4:      	cmp	x5, #0x0
    8af8:      	b.ne	0x8e54 <_stogir.schedule.order-with-uses+0xd74>
    8afc:      	add	x16, sp, #0x140
    8b00:      	ldr	x5, [x16, #0x8]
    8b04:      	add	x16, sp, #0x140
    8b08:      	ldr	x6, [x16, #0x10]
    8b0c:      	cmp	x5, x6
    8b10:      	b.lt	0x8e80 <_stogir.schedule.order-with-uses+0xda0>
    8b14:      	cmp	x6, #0x0
    8b18:      	b.ne	0x8698 <_stogir.schedule.order-with-uses+0x5b8>
    8b1c:      	mov	x6, #0x2                ; =2
    8b20:      	b	0x869c <_stogir.schedule.order-with-uses+0x5bc>
    8b24:      	ldr	x0, [sp, #0x1e0]
    8b28:      	bl	0x8b28 <_stogir.schedule.order-with-uses+0xa48>
		0000000000008b28:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    8b2c:      	ldr	x0, [sp, #0x1e8]
    8b30:      	bl	0x8b30 <_stogir.schedule.order-with-uses+0xa50>
		0000000000008b30:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    8b34:      	ldr	x0, [sp, #0x1f0]
    8b38:      	bl	0x8b38 <_stogir.schedule.order-with-uses+0xa58>
		0000000000008b38:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    8b3c:      	ldr	x0, [sp, #0x208]
    8b40:      	mov	x1, x21
    8b44:      	adrp	x2, 0x8000 <_stogir.loops.reorder!+0xc08>
		0000000000008b44:  ARM64_RELOC_PAGE21	l_stogir.442
    8b48:      	ldr	x2, [x2]
		0000000000008b48:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8b4c:      	movz	x3, #0x0, lsl #48
    8b50:      	bl	0x8b50 <_stogir.schedule.order-with-uses+0xa70>
		0000000000008b50:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    8b54:      	cmp	x0, #0x0
    8b58:      	b.eq	0x8b7c <_stogir.schedule.order-with-uses+0xa9c>
    8b5c:      	ldr	x0, [sp, #0x240]
    8b60:      	bl	0x8b60 <_stogir.schedule.order-with-uses+0xa80>
		0000000000008b60:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    8b64:      	cmp	x0, x28
    8b68:      	b.eq	0x8b7c <_stogir.schedule.order-with-uses+0xa9c>
    8b6c:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xc08>
		0000000000008b6c:  ARM64_RELOC_PAGE21	l_stogir.447
    8b70:      	ldr	x16, [x16]
		0000000000008b70:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    8b74:      	str	x16, [sp, #0x208]
    8b78:      	mov	x21, #0x16              ; =22
    8b7c:      	ldr	x0, [sp, #0x208]
    8b80:      	mov	x1, x21
    8b84:      	adrp	x2, 0x8000 <_stogir.loops.reorder!+0xc08>
		0000000000008b84:  ARM64_RELOC_PAGE21	l_stogir.442
    8b88:      	ldr	x2, [x2]
		0000000000008b88:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8b8c:      	movz	x3, #0x0, lsl #48
    8b90:      	bl	0x8b90 <_stogir.schedule.order-with-uses+0xab0>
		0000000000008b90:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    8b94:      	cmp	x0, #0x0
    8b98:      	b.eq	0x8eb4 <_stogir.schedule.order-with-uses+0xdd4>
    8b9c:      	add	x8, sp, #0x1a0
    8ba0:      	ldr	x0, [sp, #0x268]
    8ba4:      	ldr	x1, [sp, #0x240]
    8ba8:      	ldr	x2, [sp, #0x1f8]
    8bac:      	bl	0x8bac <_stogir.schedule.order-with-uses+0xacc>
		0000000000008bac:  ARM64_RELOC_BRANCH26	_stogir.schedule.entry-prefix
    8bb0:      	add	x16, sp, #0x1a0
    8bb4:      	ldr	x19, [x16]
    8bb8:      	add	x16, sp, #0x1a0
    8bbc:      	ldr	x21, [x16, #0x8]
    8bc0:      	add	x16, sp, #0x1a0
    8bc4:      	ldr	x20, [x16, #0x10]
    8bc8:      	add	x16, sp, #0x1a0
    8bcc:      	ldr	x22, [x16, #0x18]
    8bd0:      	add	x16, sp, #0x1a0
    8bd4:      	ldr	x23, [x16, #0x20]
    8bd8:      	ldr	x0, [sp, #0x240]
    8bdc:      	bl	0x8bdc <_stogir.schedule.order-with-uses+0xafc>
		0000000000008bdc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    8be0:      	movz	x0, #0x0, lsl #48
    8be4:      	b	0x8c00 <_stogir.schedule.order-with-uses+0xb20>
    8be8:      	ldr	x0, [sp, #0x240]
    8bec:      	bl	0x8bec <_stogir.schedule.order-with-uses+0xb0c>
		0000000000008bec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    8bf0:      	mov	x0, #0x1                ; =1
    8bf4:      	movz	x20, #0x0, lsl #48
    8bf8:      	movz	x22, #0x0, lsl #48
    8bfc:      	movz	x23, #0x0, lsl #48
    8c00:      	ldr	x1, [sp, #0x200]
    8c04:      	str	x0, [x1]
    8c08:      	str	x19, [x1, #0x8]
    8c0c:      	str	x21, [x1, #0x10]
    8c10:      	str	x20, [x1, #0x18]
    8c14:      	str	x22, [x1, #0x20]
    8c18:      	str	x23, [x1, #0x28]
    8c1c:      	ldr	x19, [sp, #0x278]
    8c20:      	ldr	x20, [sp, #0x280]
    8c24:      	ldr	x21, [sp, #0x288]
    8c28:      	ldr	x22, [sp, #0x290]
    8c2c:      	ldr	x23, [sp, #0x298]
    8c30:      	ldr	x24, [sp, #0x2a0]
    8c34:      	ldr	x25, [sp, #0x2a8]
    8c38:      	ldr	x26, [sp, #0x2b0]
    8c3c:      	ldr	x27, [sp, #0x2b8]
    8c40:      	ldr	x28, [sp, #0x2c0]
    8c44:      	ldr	x29, [sp, #0x10]
    8c48:      	ldr	x30, [sp, #0x18]
    8c4c:      	add	sp, sp, #0x2d0
    8c50:      	ret
    8c54:      	sub	w6, w5, #0x1
    8c58:      	lsl	w6, w6, #2
    8c5c:      	ubfx	x6, x6, #0, #32
    8c60:      	lsr	x6, x7, x6
    8c64:      	and	w6, w6, #0xf
    8c68:      	b	0x84c4 <_stogir.schedule.order-with-uses+0x3e4>
    8c6c:      	sxtw	x1, w1
    8c70:      	cmp	x1, #0x0
    8c74:      	b.le	0x8c94 <_stogir.schedule.order-with-uses+0xbb4>
    8c78:      	ldr	x0, [x24]
    8c7c:      	add	x0, x0, x1, lsl #2
    8c80:      	ldr	w0, [x0]
    8c84:      	sxtw	x0, w0
    8c88:      	cmp	x0, x22
    8c8c:      	b.ne	0x8c94 <_stogir.schedule.order-with-uses+0xbb4>
    8c90:      	add	x21, x21, #0x1
    8c94:      	b	0x841c <_stogir.schedule.order-with-uses+0x33c>
    8c98:      	adrp	x16, 0x8000 <_stogir.loops.reorder!+0xc08>
		0000000000008c98:  ARM64_RELOC_PAGE21	l_stogir.448
    8c9c:      	ldr	x16, [x16]
		0000000000008c9c:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    8ca0:      	str	x16, [sp, #0x208]
    8ca4:      	mov	x16, #0x13              ; =19
    8ca8:      	str	x16, [sp, #0x210]
    8cac:      	b	0x8394 <_stogir.schedule.order-with-uses+0x2b4>
    8cb0:      	brk	#0
    8cb4:      	b	0x8cb0 <_stogir.schedule.order-with-uses+0xbd0>
    8cb8:      	str	x19, [sp, #0x1e0]
    8cbc:      	b	0x835c <_stogir.schedule.order-with-uses+0x27c>
    8cc0:      	str	x19, [sp, #0x1e0]
    8cc4:      	mov	x19, x0
    8cc8:      	b	0x8300 <_stogir.schedule.order-with-uses+0x220>
    8ccc:      	mov	x21, x4
    8cd0:      	b	0x8568 <_stogir.schedule.order-with-uses+0x488>
    8cd4:      	str	x20, [sp, #0x230]
    8cd8:      	mov	x20, x3
    8cdc:      	str	w0, [sp, #0x218]
    8ce0:      	str	w1, [sp, #0x220]
    8ce4:      	str	x2, [sp, #0x228]
    8ce8:      	str	x21, [sp, #0x238]
    8cec:      	mov	x21, x4
    8cf0:      	b	0x841c <_stogir.schedule.order-with-uses+0x33c>
    8cf4:      	str	x20, [sp, #0x230]
    8cf8:      	mov	x20, x3
    8cfc:      	str	w0, [sp, #0x218]
    8d00:      	str	w1, [sp, #0x220]
    8d04:      	str	x2, [sp, #0x228]
    8d08:      	str	x21, [sp, #0x238]
    8d0c:      	mov	x21, x4
    8d10:      	b	0x841c <_stogir.schedule.order-with-uses+0x33c>
    8d14:      	str	x22, [sp, #0x200]
    8d18:      	str	x27, [sp, #0x1f8]
    8d1c:      	str	x20, [sp, #0x1e8]
    8d20:      	str	x21, [sp, #0x1f0]
    8d24:      	str	x0, [sp, #0x208]
    8d28:      	str	x1, [sp, #0x210]
    8d2c:      	b	0x86fc <_stogir.schedule.order-with-uses+0x61c>
    8d30:      	str	x22, [sp, #0x200]
    8d34:      	str	x27, [sp, #0x1f8]
    8d38:      	str	x20, [sp, #0x1e8]
    8d3c:      	str	x21, [sp, #0x1f0]
    8d40:      	str	x0, [sp, #0x208]
    8d44:      	str	x1, [sp, #0x210]
    8d48:      	b	0x86fc <_stogir.schedule.order-with-uses+0x61c>
    8d4c:      	str	x22, [sp, #0x200]
    8d50:      	str	x20, [sp, #0x208]
    8d54:      	str	x21, [sp, #0x210]
    8d58:      	b	0x857c <_stogir.schedule.order-with-uses+0x49c>
    8d5c:      	str	x22, [sp, #0x200]
    8d60:      	str	x20, [sp, #0x208]
    8d64:      	str	x21, [sp, #0x210]
    8d68:      	b	0x857c <_stogir.schedule.order-with-uses+0x49c>
    8d6c:      	str	x23, [sp, #0x268]
    8d70:      	str	x19, [sp, #0x240]
    8d74:      	mov	x19, x0
    8d78:      	str	x20, [sp, #0x248]
    8d7c:      	mov	x20, x1
    8d80:      	str	x24, [sp, #0x270]
    8d84:      	str	w22, [sp, #0x260]
    8d88:      	b	0x8984 <_stogir.schedule.order-with-uses+0x8a4>
    8d8c:      	str	x23, [sp, #0x268]
    8d90:      	str	x19, [sp, #0x240]
    8d94:      	mov	x19, x0
    8d98:      	str	x20, [sp, #0x248]
    8d9c:      	mov	x20, x1
    8da0:      	str	x3, [sp, #0x250]
    8da4:      	str	x2, [sp, #0x258]
    8da8:      	str	x24, [sp, #0x270]
    8dac:      	str	w22, [sp, #0x260]
    8db0:      	mov	x22, x4
    8db4:      	b	0x8890 <_stogir.schedule.order-with-uses+0x7b0>
    8db8:      	str	x23, [sp, #0x268]
    8dbc:      	str	x19, [sp, #0x240]
    8dc0:      	mov	x19, x0
    8dc4:      	str	x20, [sp, #0x248]
    8dc8:      	mov	x20, x1
    8dcc:      	str	x3, [sp, #0x250]
    8dd0:      	str	x2, [sp, #0x258]
    8dd4:      	str	x24, [sp, #0x270]
    8dd8:      	str	w22, [sp, #0x260]
    8ddc:      	mov	x22, x4
    8de0:      	b	0x8890 <_stogir.schedule.order-with-uses+0x7b0>
    8de4:      	str	x23, [sp, #0x268]
    8de8:      	str	x19, [sp, #0x240]
    8dec:      	b	0x8b24 <_stogir.schedule.order-with-uses+0xa44>
    8df0:      	str	x23, [sp, #0x268]
    8df4:      	str	x19, [sp, #0x240]
    8df8:      	b	0x8b24 <_stogir.schedule.order-with-uses+0xa44>
    8dfc:      	str	x23, [sp, #0x268]
    8e00:      	str	x19, [sp, #0x240]
    8e04:      	mov	x19, x0
    8e08:      	str	x20, [sp, #0x248]
    8e0c:      	mov	x20, x1
    8e10:      	str	x3, [sp, #0x250]
    8e14:      	str	x2, [sp, #0x258]
    8e18:      	str	x24, [sp, #0x270]
    8e1c:      	str	w22, [sp, #0x260]
    8e20:      	mov	x22, x4
    8e24:      	b	0x8890 <_stogir.schedule.order-with-uses+0x7b0>
    8e28:      	str	x23, [sp, #0x268]
    8e2c:      	str	x19, [sp, #0x240]
    8e30:      	mov	x19, x0
    8e34:      	str	x20, [sp, #0x248]
    8e38:      	mov	x20, x1
    8e3c:      	str	x3, [sp, #0x250]
    8e40:      	str	x2, [sp, #0x258]
    8e44:      	str	x24, [sp, #0x270]
    8e48:      	str	w22, [sp, #0x260]
    8e4c:      	mov	x22, x4
    8e50:      	b	0x8890 <_stogir.schedule.order-with-uses+0x7b0>
    8e54:      	str	x23, [sp, #0x268]
    8e58:      	str	x19, [sp, #0x240]
    8e5c:      	mov	x19, x0
    8e60:      	str	x20, [sp, #0x248]
    8e64:      	mov	x20, x1
    8e68:      	str	x3, [sp, #0x250]
    8e6c:      	str	x2, [sp, #0x258]
    8e70:      	str	x24, [sp, #0x270]
    8e74:      	str	w22, [sp, #0x260]
    8e78:      	mov	x22, x4
    8e7c:      	b	0x8890 <_stogir.schedule.order-with-uses+0x7b0>
    8e80:      	str	x23, [sp, #0x268]
    8e84:      	str	x19, [sp, #0x240]
    8e88:      	mov	x19, x0
    8e8c:      	str	x20, [sp, #0x248]
    8e90:      	mov	x20, x1
    8e94:      	str	x3, [sp, #0x250]
    8e98:      	str	x2, [sp, #0x258]
    8e9c:      	str	x24, [sp, #0x270]
    8ea0:      	mov	w23, w7
    8ea4:      	mov	x24, x5
    8ea8:      	str	w22, [sp, #0x260]
    8eac:      	mov	x22, x4
    8eb0:      	b	0x86dc <_stogir.schedule.order-with-uses+0x5fc>
    8eb4:      	ldr	x19, [sp, #0x208]
    8eb8:      	b	0x8be8 <_stogir.schedule.order-with-uses+0xb08>
    8ebc:      	udf	#0x0

0000000000008ec0 <_stogir.schedule.pack>:
    8ec0:      	sub	sp, sp, #0xe0
    8ec4:      	str	x29, [sp]
    8ec8:      	str	x30, [sp, #0x8]
    8ecc:      	mov	x29, sp
    8ed0:      	str	x19, [sp, #0x90]
    8ed4:      	str	x20, [sp, #0x98]
    8ed8:      	str	x21, [sp, #0xa0]
    8edc:      	str	x22, [sp, #0xa8]
    8ee0:      	str	x23, [sp, #0xb0]
    8ee4:      	str	x24, [sp, #0xb8]
    8ee8:      	str	x25, [sp, #0xc0]
    8eec:      	str	x26, [sp, #0xc8]
    8ef0:      	str	x27, [sp, #0xd0]
    8ef4:      	add	x16, sp, #0x10
    8ef8:      	orr	x19, x16, xzr
    8efc:      	ldr	x4, [x3]
    8f00:      	ldr	x5, [x3, #0x8]
    8f04:      	add	x16, sp, #0x10
    8f08:      	movz	x17, #0x0, lsl #48
    8f0c:      	str	x17, [x16]
    8f10:      	add	x16, sp, #0x10
    8f14:      	movz	x17, #0x0, lsl #48
    8f18:      	str	x17, [x16, #0x8]
    8f1c:      	add	x16, sp, #0x10
    8f20:      	movz	x17, #0x0, lsl #48
    8f24:      	str	x17, [x16, #0x10]
    8f28:      	add	x16, sp, #0x10
    8f2c:      	str	x4, [x16, #0x18]
    8f30:      	add	x16, sp, #0x10
    8f34:      	str	x5, [x16, #0x20]
    8f38:      	add	x16, sp, #0x10
    8f3c:      	movz	x17, #0x0, lsl #48
    8f40:      	str	x17, [x16, #0x28]
    8f44:      	add	x16, sp, #0x10
    8f48:      	movz	x17, #0x0, lsl #48
    8f4c:      	str	x17, [x16, #0x30]
    8f50:      	add	x16, sp, #0x10
    8f54:      	movz	x17, #0x0, lsl #48
    8f58:      	str	x17, [x16, #0x38]
    8f5c:      	add	x16, sp, #0x10
    8f60:      	str	x4, [x16, #0x40]
    8f64:      	add	x16, sp, #0x10
    8f68:      	str	x5, [x16, #0x48]
    8f6c:      	ldr	x4, [x3]
    8f70:      	ldr	x3, [x3, #0x8]
    8f74:      	add	x16, sp, #0x60
    8f78:      	movz	x17, #0x0, lsl #48
    8f7c:      	str	x17, [x16]
    8f80:      	add	x16, sp, #0x60
    8f84:      	movz	x17, #0x0, lsl #48
    8f88:      	str	x17, [x16, #0x8]
    8f8c:      	add	x16, sp, #0x60
    8f90:      	movz	x17, #0x0, lsl #48
    8f94:      	str	x17, [x16, #0x10]
    8f98:      	add	x16, sp, #0x60
    8f9c:      	str	x4, [x16, #0x18]
    8fa0:      	add	x16, sp, #0x60
    8fa4:      	str	x3, [x16, #0x20]
    8fa8:      	ldr	x3, [x1, #0x8]
    8fac:      	orr	x20, x3, xzr
    8fb0:      	cmp	x20, #0x0
    8fb4:      	b.le	0x9474 <_stogir.schedule.pack+0x5b4>
    8fb8:      	cmp	x20, #0x0
    8fbc:      	b.ge	0x8fc8 <_stogir.schedule.pack+0x108>
    8fc0:      	movz	x3, #0x0, lsl #48
    8fc4:      	b	0x8fcc <_stogir.schedule.pack+0x10c>
    8fc8:      	mov	x3, x20
    8fcc:      	mov	x21, x8
    8fd0:      	mov	x22, x0
    8fd4:      	mov	x0, x19
    8fd8:      	mov	x23, x1
    8fdc:      	mov	x1, x3
    8fe0:      	mov	x24, x2
    8fe4:      	bl	0x8fe4 <_stogir.schedule.pack+0x124>
		0000000000008fe4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range
    8fe8:      	add	x16, sp, #0x60
    8fec:      	orr	x25, x16, xzr
    8ff0:      	lsl	x0, x20, #4
    8ff4:      	add	x16, sp, #0x10
    8ff8:      	ldr	x1, [x16]
    8ffc:      	mov	x2, x0
    9000:      	mov	x0, x1
    9004:      	movz	x1, #0x0, lsl #48
    9008:      	bl	0x9008 <_stogir.schedule.pack+0x148>
		0000000000009008:  ARM64_RELOC_BRANCH26	_memset
    900c:      	add	x16, sp, #0x10
    9010:      	str	x20, [x16, #0x8]
    9014:      	ldr	x0, [x23, #0x8]
    9018:      	orr	x20, x0, xzr
    901c:      	add	x16, sp, #0x60
    9020:      	ldr	x0, [x16, #0x8]
    9024:      	orr	x26, x0, xzr
    9028:      	add	x16, sp, #0x60
    902c:      	ldr	x0, [x16, #0x10]
    9030:      	add	x27, x26, x20
    9034:      	cmp	x27, x0
    9038:      	b.le	0x906c <_stogir.schedule.pack+0x1ac>
    903c:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    9040:      	cmp	x0, x17
    9044:      	b.gt	0x9050 <_stogir.schedule.pack+0x190>
    9048:      	lsl	x0, x0, #1
    904c:      	b	0x9054 <_stogir.schedule.pack+0x194>
    9050:      	mov	x0, x27
    9054:      	cmp	x0, x27
    9058:      	b.gt	0x9060 <_stogir.schedule.pack+0x1a0>
    905c:      	mov	x0, x27
    9060:      	mov	x1, x0
    9064:      	mov	x0, x25
    9068:      	bl	0x9068 <_stogir.schedule.pack+0x1a8>
		0000000000009068:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    906c:      	lsl	x0, x20, #3
    9070:      	add	x16, sp, #0x60
    9074:      	ldr	x1, [x16]
    9078:      	add	x1, x1, x26, lsl #3
    907c:      	mov	x2, x0
    9080:      	mov	x0, x1
    9084:      	movz	x1, #0x0, lsl #48
    9088:      	bl	0x9088 <_stogir.schedule.pack+0x1c8>
		0000000000009088:  ARM64_RELOC_BRANCH26	_memset
    908c:      	add	x16, sp, #0x60
    9090:      	str	x27, [x16, #0x8]
    9094:      	ldr	x0, [x22]
    9098:      	ldr	x1, [x22, #0x8]
    909c:      	movz	x2, #0x0, lsl #48
    90a0:      	b	0x911c <_stogir.schedule.pack+0x25c>
    90a4:      	nop
    90a8:      	movz	w3, #0x0, lsl #16
    90ac:      	movz	w4, #0x0, lsl #16
    90b0:      	ubfx	x3, x3, #0, #32
    90b4:      	lsr	x16, x3, #0
    90b8:      	cmp	x16, #0x1
    90bc:      	b.eq	0x90d8 <_stogir.schedule.pack+0x218>
    90c0:      	b.lo	0x90c8 <_stogir.schedule.pack+0x208>
    90c4:      	b	0x90dc <_stogir.schedule.pack+0x21c>
    90c8:      	cmp	x16, #0x0
    90cc:      	b.eq	0x90d4 <_stogir.schedule.pack+0x214>
    90d0:      	b	0x90dc <_stogir.schedule.pack+0x21c>
    90d4:      	b	0x9144 <_stogir.schedule.pack+0x284>
    90d8:      	b	0x90e0 <_stogir.schedule.pack+0x220>
    90dc:      	b	0x946c <_stogir.schedule.pack+0x5ac>
    90e0:      	sxtw	x4, w4
    90e4:      	ldr	x3, [x23]
    90e8:      	add	x3, x3, x4, lsl #2
    90ec:      	ldr	w3, [x3]
    90f0:      	sxtw	x3, w3
    90f4:      	add	x16, sp, #0x10
    90f8:      	ldr	x4, [x16]
    90fc:      	orr	x5, x4, xzr
    9100:      	add	x5, x5, x3, lsl #4
    9104:      	add	x3, x4, x3, lsl #4
    9108:      	ldr	x4, [x5]
    910c:      	ldr	x5, [x5, #0x8]
    9110:      	add	x5, x5, #0x1
    9114:      	str	x4, [x3]
    9118:      	str	x5, [x3, #0x8]
    911c:      	cmp	x2, x1
    9120:      	b.ge	0x90a8 <_stogir.schedule.pack+0x1e8>
    9124:      	add	x3, x2, #0x1
    9128:      	add	x2, x0, x2, lsl #2
    912c:      	ldr	w2, [x2]
    9130:      	movn	w17, #0x0, lsl #16
    9134:      	and	w4, w2, w17
    9138:      	mov	x2, x3
    913c:      	mov	w3, #0x1                ; =1
    9140:      	b	0x90b0 <_stogir.schedule.pack+0x1f0>
    9144:      	ldr	x0, [x24]
    9148:      	ldr	x1, [x24, #0x8]
    914c:      	movz	x2, #0x0, lsl #48
    9150:      	movz	x3, #0x0, lsl #48
    9154:      	b	0x91cc <_stogir.schedule.pack+0x30c>
    9158:      	movz	w4, #0x0, lsl #16
    915c:      	movz	w5, #0x0, lsl #16
    9160:      	ubfx	x4, x4, #0, #32
    9164:      	lsr	x16, x4, #0
    9168:      	cmp	x16, #0x1
    916c:      	b.eq	0x9188 <_stogir.schedule.pack+0x2c8>
    9170:      	b.lo	0x9178 <_stogir.schedule.pack+0x2b8>
    9174:      	b	0x918c <_stogir.schedule.pack+0x2cc>
    9178:      	cmp	x16, #0x0
    917c:      	b.eq	0x9184 <_stogir.schedule.pack+0x2c4>
    9180:      	b	0x918c <_stogir.schedule.pack+0x2cc>
    9184:      	b	0x91f4 <_stogir.schedule.pack+0x334>
    9188:      	b	0x9190 <_stogir.schedule.pack+0x2d0>
    918c:      	b	0x9464 <_stogir.schedule.pack+0x5a4>
    9190:      	sxtw	x5, w5
    9194:      	add	x16, sp, #0x10
    9198:      	ldr	x4, [x16]
    919c:      	orr	x6, x4, xzr
    91a0:      	add	x6, x6, x5, lsl #4
    91a4:      	add	x4, x4, x5, lsl #4
    91a8:      	ldr	x6, [x6, #0x8]
    91ac:      	add	x7, x6, x2
    91b0:      	str	x2, [x4]
    91b4:      	str	x6, [x4, #0x8]
    91b8:      	add	x16, sp, #0x60
    91bc:      	ldr	x4, [x16]
    91c0:      	add	x4, x4, x5, lsl #3
    91c4:      	str	x2, [x4]
    91c8:      	mov	x2, x7
    91cc:      	cmp	x3, x1
    91d0:      	b.ge	0x9158 <_stogir.schedule.pack+0x298>
    91d4:      	add	x4, x3, #0x1
    91d8:      	add	x3, x0, x3, lsl #2
    91dc:      	ldr	w3, [x3]
    91e0:      	movn	w17, #0x0, lsl #16
    91e4:      	and	w5, w3, w17
    91e8:      	mov	x3, x4
    91ec:      	mov	w4, #0x1                ; =1
    91f0:      	b	0x9160 <_stogir.schedule.pack+0x2a0>
    91f4:      	add	x19, x19, #0x28
    91f8:      	ldr	x0, [x22, #0x8]
    91fc:      	orr	x20, x0, xzr
    9200:      	ldr	x0, [x19, #0x8]
    9204:      	orr	x24, x0, xzr
    9208:      	ldr	x0, [x19, #0x10]
    920c:      	add	x26, x24, x20
    9210:      	cmp	x26, x0
    9214:      	b.le	0x9248 <_stogir.schedule.pack+0x388>
    9218:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    921c:      	cmp	x0, x17
    9220:      	b.gt	0x922c <_stogir.schedule.pack+0x36c>
    9224:      	lsl	x0, x0, #1
    9228:      	b	0x9230 <_stogir.schedule.pack+0x370>
    922c:      	mov	x0, x26
    9230:      	cmp	x0, x26
    9234:      	b.gt	0x923c <_stogir.schedule.pack+0x37c>
    9238:      	mov	x0, x26
    923c:      	mov	x1, x0
    9240:      	mov	x0, x19
    9244:      	bl	0x9244 <_stogir.schedule.pack+0x384>
		0000000000009244:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9248:      	lsl	x0, x20, #2
    924c:      	add	x16, sp, #0x10
    9250:      	ldr	x1, [x16, #0x28]
    9254:      	add	x1, x1, x24, lsl #2
    9258:      	mov	x2, x0
    925c:      	mov	x0, x1
    9260:      	movz	x1, #0x0, lsl #48
    9264:      	bl	0x9264 <_stogir.schedule.pack+0x3a4>
		0000000000009264:  ARM64_RELOC_BRANCH26	_memset
    9268:      	str	x26, [x19, #0x8]
    926c:      	ldr	x0, [x22]
    9270:      	ldr	x1, [x22, #0x8]
    9274:      	movz	x2, #0x0, lsl #48
    9278:      	b	0x9300 <_stogir.schedule.pack+0x440>
    927c:      	nop
    9280:      	movz	w3, #0x0, lsl #16
    9284:      	movz	w4, #0x0, lsl #16
    9288:      	ubfx	x3, x3, #0, #32
    928c:      	lsr	x16, x3, #0
    9290:      	cmp	x16, #0x1
    9294:      	b.eq	0x92b0 <_stogir.schedule.pack+0x3f0>
    9298:      	b.lo	0x92a0 <_stogir.schedule.pack+0x3e0>
    929c:      	b	0x92b4 <_stogir.schedule.pack+0x3f4>
    92a0:      	cmp	x16, #0x0
    92a4:      	b.eq	0x92ac <_stogir.schedule.pack+0x3ec>
    92a8:      	b	0x92b4 <_stogir.schedule.pack+0x3f4>
    92ac:      	b	0x9328 <_stogir.schedule.pack+0x468>
    92b0:      	b	0x92b8 <_stogir.schedule.pack+0x3f8>
    92b4:      	b	0x945c <_stogir.schedule.pack+0x59c>
    92b8:      	sxtw	x3, w4
    92bc:      	ldr	x5, [x23]
    92c0:      	add	x3, x5, x3, lsl #2
    92c4:      	ldr	w3, [x3]
    92c8:      	sxtw	x3, w3
    92cc:      	add	x16, sp, #0x60
    92d0:      	ldr	x5, [x16]
    92d4:      	add	x5, x5, x3, lsl #3
    92d8:      	ldr	x5, [x5]
    92dc:      	add	x16, sp, #0x10
    92e0:      	ldr	x6, [x16, #0x28]
    92e4:      	add	x7, x5, #0x1
    92e8:      	add	x5, x6, x5, lsl #2
    92ec:      	str	w4, [x5]
    92f0:      	add	x16, sp, #0x60
    92f4:      	ldr	x4, [x16]
    92f8:      	add	x3, x4, x3, lsl #3
    92fc:      	str	x7, [x3]
    9300:      	cmp	x2, x1
    9304:      	b.ge	0x9280 <_stogir.schedule.pack+0x3c0>
    9308:      	add	x3, x2, #0x1
    930c:      	add	x2, x0, x2, lsl #2
    9310:      	ldr	w2, [x2]
    9314:      	movn	w17, #0x0, lsl #16
    9318:      	and	w4, w2, w17
    931c:      	mov	x2, x3
    9320:      	mov	w3, #0x1                ; =1
    9324:      	b	0x9288 <_stogir.schedule.pack+0x3c8>
    9328:      	b	0x933c <_stogir.schedule.pack+0x47c>
    932c:      	nop
    9330:      	sub	x0, x0, #0x1
    9334:      	add	x16, sp, #0x60
    9338:      	str	x0, [x16, #0x8]
    933c:      	add	x16, sp, #0x60
    9340:      	ldr	x0, [x16, #0x8]
    9344:      	cmp	x0, #0x0
    9348:      	b.ne	0x9330 <_stogir.schedule.pack+0x470>
    934c:      	add	x16, sp, #0x60
    9350:      	ldr	x0, [x16, #0x10]
    9354:      	cmp	x0, #0x0
    9358:      	b.le	0x938c <_stogir.schedule.pack+0x4cc>
    935c:      	add	x1, x25, #0x18
    9360:      	add	x16, sp, #0x60
    9364:      	ldr	x2, [x16]
    9368:      	fmov	d31, x0
    936c:      	mov	x0, x1
    9370:      	mov	x1, x2
    9374:      	fmov	x2, d31
    9378:      	adrp	x3, 0x9000 <_stogir.schedule.pack+0x140>
		0000000000009378:  ARM64_RELOC_PAGE21	l_stogir.449
    937c:      	ldr	x3, [x3]
		000000000000937c:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    9380:      	mov	x4, #0x8                ; =8
    9384:      	mov	x5, #0x8                ; =8
    9388:      	bl	0x9388 <_stogir.schedule.pack+0x4c8>
		0000000000009388:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    938c:      	add	x16, sp, #0x60
    9390:      	movz	x17, #0x0, lsl #48
    9394:      	str	x17, [x16]
    9398:      	add	x16, sp, #0x60
    939c:      	movz	x17, #0x0, lsl #48
    93a0:      	str	x17, [x16, #0x8]
    93a4:      	add	x16, sp, #0x60
    93a8:      	movz	x17, #0x0, lsl #48
    93ac:      	str	x17, [x16, #0x10]
    93b0:      	add	x16, sp, #0x10
    93b4:      	ldr	x0, [x16]
    93b8:      	add	x16, sp, #0x10
    93bc:      	ldr	x1, [x16, #0x8]
    93c0:      	add	x16, sp, #0x10
    93c4:      	ldr	x2, [x16, #0x10]
    93c8:      	add	x16, sp, #0x10
    93cc:      	ldr	x3, [x16, #0x18]
    93d0:      	add	x16, sp, #0x10
    93d4:      	ldr	x4, [x16, #0x20]
    93d8:      	add	x16, sp, #0x10
    93dc:      	ldr	x5, [x16, #0x28]
    93e0:      	add	x16, sp, #0x10
    93e4:      	ldr	x6, [x16, #0x30]
    93e8:      	add	x16, sp, #0x10
    93ec:      	ldr	x7, [x16, #0x38]
    93f0:      	add	x16, sp, #0x10
    93f4:      	ldr	x8, [x16, #0x40]
    93f8:      	add	x16, sp, #0x10
    93fc:      	ldr	x9, [x16, #0x48]
    9400:      	str	x0, [x21]
    9404:      	str	x1, [x21, #0x8]
    9408:      	str	x2, [x21, #0x10]
    940c:      	str	x3, [x21, #0x18]
    9410:      	str	x4, [x21, #0x20]
    9414:      	str	x5, [x21, #0x28]
    9418:      	str	x6, [x21, #0x30]
    941c:      	str	x7, [x21, #0x38]
    9420:      	str	x8, [x21, #0x40]
    9424:      	str	x9, [x21, #0x48]
    9428:      	ldr	x19, [sp, #0x90]
    942c:      	ldr	x20, [sp, #0x98]
    9430:      	ldr	x21, [sp, #0xa0]
    9434:      	ldr	x22, [sp, #0xa8]
    9438:      	ldr	x23, [sp, #0xb0]
    943c:      	ldr	x24, [sp, #0xb8]
    9440:      	ldr	x25, [sp, #0xc0]
    9444:      	ldr	x26, [sp, #0xc8]
    9448:      	ldr	x27, [sp, #0xd0]
    944c:      	ldr	x29, [sp]
    9450:      	ldr	x30, [sp, #0x8]
    9454:      	add	sp, sp, #0xe0
    9458:      	ret
    945c:      	brk	#0
    9460:      	b	0x945c <_stogir.schedule.pack+0x59c>
    9464:      	brk	#0
    9468:      	b	0x9464 <_stogir.schedule.pack+0x5a4>
    946c:      	brk	#0
    9470:      	b	0x946c <_stogir.schedule.pack+0x5ac>
    9474:      	mov	x21, x8
    9478:      	mov	x22, x0
    947c:      	mov	x23, x1
    9480:      	mov	x24, x2
    9484:      	b	0x8fe8 <_stogir.schedule.pack+0x128>

0000000000009488 <_stogir.checked-schedule.cluster!>:
    9488:      	sub	sp, sp, #0x270
    948c:      	str	x29, [sp]
    9490:      	str	x30, [sp, #0x8]
    9494:      	mov	x29, sp
    9498:      	str	x19, [sp, #0x220]
    949c:      	str	x20, [sp, #0x228]
    94a0:      	str	x21, [sp, #0x230]
    94a4:      	str	x22, [sp, #0x238]
    94a8:      	str	x23, [sp, #0x240]
    94ac:      	str	x24, [sp, #0x248]
    94b0:      	str	x25, [sp, #0x250]
    94b4:      	str	x26, [sp, #0x258]
    94b8:      	str	x27, [sp, #0x260]
    94bc:      	str	x28, [sp, #0x268]
    94c0:      	add	x4, x2, #0x28
    94c4:      	add	x16, sp, #0x10
    94c8:      	orr	x5, x16, xzr
    94cc:      	add	x19, x5, #0x8
    94d0:      	ldr	x5, [x2, #0x28]
    94d4:      	orr	x20, x5, xzr
    94d8:      	ldr	x4, [x4, #0x8]
    94dc:      	orr	x21, x4, xzr
    94e0:      	movz	x22, #0x0, lsl #48
    94e4:      	adrp	x23, 0x9000 <_stogir.schedule.pack+0x140>
		00000000000094e4:  ARM64_RELOC_PAGE21	l_stogir.450
    94e8:      	ldr	x23, [x23]
		00000000000094e8:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    94ec:      	movz	x24, #0x0, lsl #48
    94f0:      	movz	x25, #0x0, lsl #48
    94f4:      	b	0x9530 <_stogir.checked-schedule.cluster!+0xa8>
    94f8:      	add	x16, sp, #0x10
    94fc:      	ldr	w0, [x16, #0x8]
    9500:      	sxtw	x0, w0
    9504:      	cmp	x0, #0x0
    9508:      	b.eq	0x9514 <_stogir.checked-schedule.cluster!+0x8c>
    950c:      	add	x0, x22, #0x1
    9510:      	sxtw	x22, w0
    9514:      	mov	x8, x26
    9518:      	mov	x0, x27
    951c:      	mov	x1, x28
    9520:      	mov	x2, x20
    9524:      	mov	x3, x21
    9528:      	ldr	x20, [sp, #0x1c0]
    952c:      	ldr	x21, [sp, #0x1c8]
    9530:      	cmp	x25, x21
    9534:      	b.ge	0x9558 <_stogir.checked-schedule.cluster!+0xd0>
    9538:      	add	x4, x25, #0x1
    953c:      	add	x5, x20, x25, lsl #2
    9540:      	ldr	w5, [x5]
    9544:      	movn	w17, #0x0, lsl #16
    9548:      	and	w5, w5, w17
    954c:      	mov	x25, x4
    9550:      	mov	w4, #0x1                ; =1
    9554:      	b	0x9560 <_stogir.checked-schedule.cluster!+0xd8>
    9558:      	movz	w4, #0x0, lsl #16
    955c:      	movz	w5, #0x0, lsl #16
    9560:      	ubfx	x4, x4, #0, #32
    9564:      	lsr	x16, x4, #0
    9568:      	cmp	x16, #0x1
    956c:      	b.eq	0x959c <_stogir.checked-schedule.cluster!+0x114>
    9570:      	b.lo	0x9578 <_stogir.checked-schedule.cluster!+0xf0>
    9574:      	b	0x95a0 <_stogir.checked-schedule.cluster!+0x118>
    9578:      	cmp	x16, #0x0
    957c:      	b.eq	0x9584 <_stogir.checked-schedule.cluster!+0xfc>
    9580:      	b	0x95a0 <_stogir.checked-schedule.cluster!+0x118>
    9584:      	mov	x26, x8
    9588:      	mov	x27, x0
    958c:      	mov	x28, x1
    9590:      	mov	x20, x2
    9594:      	mov	x21, x3
    9598:      	b	0x962c <_stogir.checked-schedule.cluster!+0x1a4>
    959c:      	b	0x95a4 <_stogir.checked-schedule.cluster!+0x11c>
    95a0:      	b	0x9e98 <_stogir.checked-schedule.cluster!+0xa10>
    95a4:      	sxtw	x4, w5
    95a8:      	ldr	x6, [x0]
    95ac:      	add	x4, x6, x4, lsl #4
    95b0:      	ldr	x4, [x4]
    95b4:      	uxtb	w4, w4
    95b8:      	cmp	x4, #0x2c
    95bc:      	b.ne	0x9ec0 <_stogir.checked-schedule.cluster!+0xa38>
    95c0:      	mov	x26, x8
    95c4:      	add	x8, sp, #0x10
    95c8:      	mov	x27, x0
    95cc:      	mov	x28, x1
    95d0:      	mov	w1, w5
    95d4:      	str	x20, [sp, #0x1c0]
    95d8:      	mov	x20, x2
    95dc:      	str	x21, [sp, #0x1c8]
    95e0:      	mov	x21, x3
    95e4:      	bl	0x95e4 <_stogir.checked-schedule.cluster!+0x15c>
		00000000000095e4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    95e8:      	add	x16, sp, #0x10
    95ec:      	ldr	w0, [x16]
    95f0:      	lsr	x16, x0, #0
    95f4:      	cmp	x16, #0x1
    95f8:      	b.eq	0x9614 <_stogir.checked-schedule.cluster!+0x18c>
    95fc:      	b.lo	0x9604 <_stogir.checked-schedule.cluster!+0x17c>
    9600:      	b	0x9618 <_stogir.checked-schedule.cluster!+0x190>
    9604:      	cmp	x16, #0x0
    9608:      	b.eq	0x9610 <_stogir.checked-schedule.cluster!+0x188>
    960c:      	b	0x9618 <_stogir.checked-schedule.cluster!+0x190>
    9610:      	b	0x94f8 <_stogir.checked-schedule.cluster!+0x70>
    9614:      	b	0x961c <_stogir.checked-schedule.cluster!+0x194>
    9618:      	b	0x9eb0 <_stogir.checked-schedule.cluster!+0xa28>
    961c:      	add	x16, sp, #0x10
    9620:      	ldr	x23, [x16, #0x8]
    9624:      	ldr	x24, [x19, #0x8]
    9628:      	b	0x9514 <_stogir.checked-schedule.cluster!+0x8c>
    962c:      	cmp	x24, #0x0
    9630:      	b.ne	0x9668 <_stogir.checked-schedule.cluster!+0x1e0>
    9634:      	cmp	x22, #0x0
    9638:      	b.ne	0x9c8c <_stogir.checked-schedule.cluster!+0x804>
    963c:      	add	x8, sp, #0x30
    9640:      	mov	x0, x27
    9644:      	mov	x1, x20
    9648:      	bl	0x9648 <_stogir.checked-schedule.cluster!+0x1c0>
		0000000000009648:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate
    964c:      	add	x16, sp, #0x30
    9650:      	ldr	x0, [x16]
    9654:      	add	x16, sp, #0x30
    9658:      	ldr	x23, [x16, #0x8]
    965c:      	add	x16, sp, #0x30
    9660:      	ldr	x24, [x16, #0x10]
    9664:      	b	0x9a60 <_stogir.checked-schedule.cluster!+0x5d8>
    9668:      	mov	x0, #0x1                ; =1
    966c:      	b	0x9a60 <_stogir.checked-schedule.cluster!+0x5d8>
    9670:      	add	x16, sp, #0xb0
    9674:      	ldr	x2, [x16]
    9678:      	add	x1, x2, x1, lsl #2
    967c:      	str	w21, [x1]
    9680:      	add	x16, sp, #0x80
    9684:      	ldr	x1, [x16]
    9688:      	add	x0, x1, x0, lsl #2
    968c:      	str	w21, [x0]
    9690:      	add	x16, sp, #0xe0
    9694:      	ldr	x0, [x16]
    9698:      	add	x0, x0, x25
    969c:      	mov	w17, #0x1               ; =1
    96a0:      	strb	w17, [x0]
    96a4:      	ldr	x25, [sp, #0x200]
    96a8:      	ldr	x21, [sp, #0x1f8]
    96ac:      	ldr	x0, [sp, #0x1e8]
    96b0:      	ldr	x1, [sp, #0x1f0]
    96b4:      	cmp	x1, x0
    96b8:      	b.ge	0x96dc <_stogir.checked-schedule.cluster!+0x254>
    96bc:      	add	x2, x1, #0x1
    96c0:      	add	x1, x21, x1, lsl #2
    96c4:      	ldr	w1, [x1]
    96c8:      	movn	w17, #0x0, lsl #16
    96cc:      	and	w3, w1, w17
    96d0:      	mov	x1, x2
    96d4:      	mov	w2, #0x1                ; =1
    96d8:      	b	0x96e4 <_stogir.checked-schedule.cluster!+0x25c>
    96dc:      	movz	w2, #0x0, lsl #16
    96e0:      	movz	w3, #0x0, lsl #16
    96e4:      	ubfx	x2, x2, #0, #32
    96e8:      	lsr	x16, x2, #0
    96ec:      	cmp	x16, #0x1
    96f0:      	b.eq	0x9710 <_stogir.checked-schedule.cluster!+0x288>
    96f4:      	b.lo	0x96fc <_stogir.checked-schedule.cluster!+0x274>
    96f8:      	b	0x9714 <_stogir.checked-schedule.cluster!+0x28c>
    96fc:      	cmp	x16, #0x0
    9700:      	b.eq	0x9708 <_stogir.checked-schedule.cluster!+0x280>
    9704:      	b	0x9714 <_stogir.checked-schedule.cluster!+0x28c>
    9708:      	str	x25, [sp, #0x200]
    970c:      	b	0x97b8 <_stogir.checked-schedule.cluster!+0x330>
    9710:      	b	0x9718 <_stogir.checked-schedule.cluster!+0x290>
    9714:      	b	0x9ea0 <_stogir.checked-schedule.cluster!+0xa18>
    9718:      	sxtw	x2, w3
    971c:      	ldr	x4, [x27]
    9720:      	add	x4, x4, x2, lsl #4
    9724:      	ldr	x5, [x4]
    9728:      	uxtb	w6, w5
    972c:      	ldr	x4, [x4, #0x8]
    9730:      	add	x16, sp, #0x170
    9734:      	str	x5, [x16]
    9738:      	add	x16, sp, #0x170
    973c:      	str	x4, [x16, #0x8]
    9740:      	cmp	x6, #0x2c
    9744:      	b.ne	0x9ee0 <_stogir.checked-schedule.cluster!+0xa58>
    9748:      	lsr	x4, x5, #32
    974c:      	add	x8, sp, #0x180
    9750:      	str	x0, [sp, #0x1e8]
    9754:      	mov	x0, x27
    9758:      	str	x1, [sp, #0x1f0]
    975c:      	mov	w1, w4
    9760:      	str	x21, [sp, #0x1f8]
    9764:      	mov	w21, w3
    9768:      	str	x25, [sp, #0x200]
    976c:      	mov	x25, x2
    9770:      	bl	0x9770 <_stogir.checked-schedule.cluster!+0x2e8>
		0000000000009770:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    9774:      	add	x16, sp, #0x180
    9778:      	ldr	w0, [x16]
    977c:      	lsr	x16, x0, #0
    9780:      	cmp	x16, #0x1
    9784:      	b.eq	0x97a0 <_stogir.checked-schedule.cluster!+0x318>
    9788:      	b.lo	0x9790 <_stogir.checked-schedule.cluster!+0x308>
    978c:      	b	0x97a4 <_stogir.checked-schedule.cluster!+0x31c>
    9790:      	cmp	x16, #0x0
    9794:      	b.eq	0x979c <_stogir.checked-schedule.cluster!+0x314>
    9798:      	b	0x97a4 <_stogir.checked-schedule.cluster!+0x31c>
    979c:      	b	0x9e0c <_stogir.checked-schedule.cluster!+0x984>
    97a0:      	b	0x97a8 <_stogir.checked-schedule.cluster!+0x320>
    97a4:      	b	0x9eb8 <_stogir.checked-schedule.cluster!+0xa30>
    97a8:      	add	x16, sp, #0x180
    97ac:      	ldr	x23, [x16, #0x8]
    97b0:      	ldr	x24, [x19, #0x8]
    97b4:      	b	0x96a4 <_stogir.checked-schedule.cluster!+0x21c>
    97b8:      	add	x16, sp, #0x110
    97bc:      	orr	x19, x16, xzr
    97c0:      	add	x0, x20, #0x28
    97c4:      	ldr	x1, [x20, #0x28]
    97c8:      	orr	x21, x1, xzr
    97cc:      	ldr	x0, [x0, #0x8]
    97d0:      	orr	x25, x0, xzr
    97d4:      	movz	x28, #0x0, lsl #48
    97d8:      	b	0x9940 <_stogir.checked-schedule.cluster!+0x4b8>
    97dc:      	ldr	x0, [sp, #0x208]
    97e0:      	bl	0x97e0 <_stogir.checked-schedule.cluster!+0x358>
		00000000000097e0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    97e4:      	mov	x0, #0x1                ; =1
    97e8:      	b	0x9a60 <_stogir.checked-schedule.cluster!+0x5d8>
    97ec:      	adrp	x23, 0x9000 <_stogir.schedule.pack+0x140>
		00000000000097ec:  ARM64_RELOC_PAGE21	l_stogir.451
    97f0:      	ldr	x23, [x23]
		00000000000097f0:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    97f4:      	mov	x24, #0x32              ; =50
    97f8:      	b	0x9980 <_stogir.checked-schedule.cluster!+0x4f8>
    97fc:      	lsl	x3, x3, #1
    9800:      	str	x19, [sp, #0x208]
    9804:      	str	x21, [sp, #0x210]
    9808:      	mov	x21, x0
    980c:      	mov	x0, x19
    9810:      	mov	w19, w1
    9814:      	mov	x1, x3
    9818:      	str	x25, [sp, #0x218]
    981c:      	mov	x25, x2
    9820:      	bl	0x9820 <_stogir.checked-schedule.cluster!+0x398>
		0000000000009820:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9824:      	add	x0, x25, #0x1
    9828:      	add	x16, sp, #0x110
    982c:      	ldr	x1, [x16]
    9830:      	add	x1, x1, x25, lsl #2
    9834:      	str	w19, [x1]
    9838:      	add	x16, sp, #0x110
    983c:      	str	x0, [x16, #0x8]
    9840:      	add	x16, sp, #0x50
    9844:      	ldr	x0, [x16]
    9848:      	add	x0, x0, x21, lsl #2
    984c:      	ldr	w0, [x0]
    9850:      	orr	w19, w0, wzr
    9854:      	b	0x9898 <_stogir.checked-schedule.cluster!+0x410>
    9858:      	lsl	x0, x0, #1
    985c:      	mov	x1, x0
    9860:      	ldr	x0, [sp, #0x208]
    9864:      	bl	0x9864 <_stogir.checked-schedule.cluster!+0x3dc>
		0000000000009864:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9868:      	add	x0, x25, #0x1
    986c:      	add	x16, sp, #0x110
    9870:      	ldr	x1, [x16]
    9874:      	add	x1, x1, x25, lsl #2
    9878:      	str	w19, [x1]
    987c:      	add	x16, sp, #0x110
    9880:      	str	x0, [x16, #0x8]
    9884:      	add	x16, sp, #0xb0
    9888:      	ldr	x0, [x16]
    988c:      	add	x0, x0, x21, lsl #2
    9890:      	ldr	w0, [x0]
    9894:      	orr	w19, w0, wzr
    9898:      	sxtw	x21, w19
    989c:      	cmp	x21, #0x0
    98a0:      	b.eq	0x9934 <_stogir.checked-schedule.cluster!+0x4ac>
    98a4:      	add	x16, sp, #0x110
    98a8:      	ldr	x0, [x16, #0x8]
    98ac:      	orr	x25, x0, xzr
    98b0:      	add	x16, sp, #0x110
    98b4:      	ldr	x0, [x16, #0x10]
    98b8:      	cmp	x25, x0
    98bc:      	b.lt	0x9868 <_stogir.checked-schedule.cluster!+0x3e0>
    98c0:      	cmp	x0, #0x0
    98c4:      	b.ne	0x9858 <_stogir.checked-schedule.cluster!+0x3d0>
    98c8:      	mov	x0, #0x2                ; =2
    98cc:      	b	0x985c <_stogir.checked-schedule.cluster!+0x3d4>
    98d0:      	movz	w0, #0x0, lsl #16
    98d4:      	movz	w1, #0x0, lsl #16
    98d8:      	ubfx	x0, x0, #0, #32
    98dc:      	lsr	x16, x0, #0
    98e0:      	cmp	x16, #0x1
    98e4:      	b.eq	0x9904 <_stogir.checked-schedule.cluster!+0x47c>
    98e8:      	b.lo	0x98f0 <_stogir.checked-schedule.cluster!+0x468>
    98ec:      	b	0x9908 <_stogir.checked-schedule.cluster!+0x480>
    98f0:      	cmp	x16, #0x0
    98f4:      	b.eq	0x98fc <_stogir.checked-schedule.cluster!+0x474>
    98f8:      	b	0x9908 <_stogir.checked-schedule.cluster!+0x480>
    98fc:      	str	x19, [sp, #0x208]
    9900:      	b	0x9968 <_stogir.checked-schedule.cluster!+0x4e0>
    9904:      	b	0x990c <_stogir.checked-schedule.cluster!+0x484>
    9908:      	b	0x9e90 <_stogir.checked-schedule.cluster!+0xa08>
    990c:      	sxtw	x0, w1
    9910:      	add	x16, sp, #0xe0
    9914:      	ldr	x2, [x16]
    9918:      	add	x2, x2, x0
    991c:      	ldrb	w2, [x2]
    9920:      	cmp	x2, #0x0
    9924:      	b.eq	0x9aa4 <_stogir.checked-schedule.cluster!+0x61c>
    9928:      	str	x19, [sp, #0x208]
    992c:      	str	x21, [sp, #0x210]
    9930:      	str	x25, [sp, #0x218]
    9934:      	ldr	x19, [sp, #0x208]
    9938:      	ldr	x21, [sp, #0x210]
    993c:      	ldr	x25, [sp, #0x218]
    9940:      	cmp	x28, x25
    9944:      	b.ge	0x98d0 <_stogir.checked-schedule.cluster!+0x448>
    9948:      	add	x0, x28, #0x1
    994c:      	add	x1, x21, x28, lsl #2
    9950:      	ldr	w1, [x1]
    9954:      	movn	w17, #0x0, lsl #16
    9958:      	and	w1, w1, w17
    995c:      	mov	x28, x0
    9960:      	mov	w0, #0x1                ; =1
    9964:      	b	0x98d8 <_stogir.checked-schedule.cluster!+0x450>
    9968:      	add	x0, x20, #0x28
    996c:      	add	x16, sp, #0x110
    9970:      	ldr	x1, [x16, #0x8]
    9974:      	ldr	x0, [x0, #0x8]
    9978:      	cmp	x1, x0
    997c:      	b.ne	0x97ec <_stogir.checked-schedule.cluster!+0x364>
    9980:      	cmp	x24, #0x0
    9984:      	b.ne	0x99e4 <_stogir.checked-schedule.cluster!+0x55c>
    9988:      	add	x8, sp, #0x1a0
    998c:      	mov	x0, x27
    9990:      	ldr	x1, [sp, #0x208]
    9994:      	bl	0x9994 <_stogir.checked-schedule.cluster!+0x50c>
		0000000000009994:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    9998:      	add	x16, sp, #0x1a0
    999c:      	ldr	w0, [x16]
    99a0:      	lsr	x16, x0, #0
    99a4:      	cmp	x16, #0x1
    99a8:      	b.eq	0x99c4 <_stogir.checked-schedule.cluster!+0x53c>
    99ac:      	b.lo	0x99b4 <_stogir.checked-schedule.cluster!+0x52c>
    99b0:      	b	0x99c8 <_stogir.checked-schedule.cluster!+0x540>
    99b4:      	cmp	x16, #0x0
    99b8:      	b.eq	0x99c0 <_stogir.checked-schedule.cluster!+0x538>
    99bc:      	b	0x99c8 <_stogir.checked-schedule.cluster!+0x540>
    99c0:      	b	0x99e4 <_stogir.checked-schedule.cluster!+0x55c>
    99c4:      	b	0x99cc <_stogir.checked-schedule.cluster!+0x544>
    99c8:      	b	0x9ea8 <_stogir.checked-schedule.cluster!+0xa20>
    99cc:      	add	x16, sp, #0x1a0
    99d0:      	orr	x0, x16, xzr
    99d4:      	add	x0, x0, #0x8
    99d8:      	add	x16, sp, #0x1a0
    99dc:      	ldr	x23, [x16, #0x8]
    99e0:      	ldr	x24, [x0, #0x8]
    99e4:      	ldr	x0, [sp, #0x1d8]
    99e8:      	bl	0x99e8 <_stogir.checked-schedule.cluster!+0x560>
		00000000000099e8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    99ec:      	ldr	x0, [sp, #0x200]
    99f0:      	bl	0x99f0 <_stogir.checked-schedule.cluster!+0x568>
		00000000000099f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    99f4:      	ldr	x0, [sp, #0x1e0]
    99f8:      	bl	0x99f8 <_stogir.checked-schedule.cluster!+0x570>
		00000000000099f8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    99fc:      	ldr	x0, [sp, #0x1d0]
    9a00:      	bl	0x9a00 <_stogir.checked-schedule.cluster!+0x578>
		0000000000009a00:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__bool
    9a04:      	cmp	x24, #0x0
    9a08:      	b.ne	0x97dc <_stogir.checked-schedule.cluster!+0x354>
    9a0c:      	add	x19, x20, #0x28
    9a10:      	and	x23, x22, #0xffffffff
    9a14:      	mov	x0, x19
    9a18:      	bl	0x9a18 <_stogir.checked-schedule.cluster!+0x590>
		0000000000009a18:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9a1c:      	add	x16, sp, #0x110
    9a20:      	ldr	x0, [x16]
    9a24:      	add	x16, sp, #0x110
    9a28:      	ldr	x1, [x16, #0x8]
    9a2c:      	add	x16, sp, #0x110
    9a30:      	ldr	x2, [x16, #0x10]
    9a34:      	add	x16, sp, #0x110
    9a38:      	ldr	x3, [x16, #0x18]
    9a3c:      	add	x16, sp, #0x110
    9a40:      	ldr	x4, [x16, #0x20]
    9a44:      	str	x0, [x20, #0x28]
    9a48:      	str	x1, [x19, #0x8]
    9a4c:      	str	x2, [x19, #0x10]
    9a50:      	str	x3, [x19, #0x18]
    9a54:      	str	x4, [x19, #0x20]
    9a58:      	movz	x0, #0x0, lsl #48
    9a5c:      	movz	x24, #0x0, lsl #48
    9a60:      	str	x0, [x26]
    9a64:      	str	x23, [x26, #0x8]
    9a68:      	str	x24, [x26, #0x10]
    9a6c:      	ldr	x19, [sp, #0x220]
    9a70:      	ldr	x20, [sp, #0x228]
    9a74:      	ldr	x21, [sp, #0x230]
    9a78:      	ldr	x22, [sp, #0x238]
    9a7c:      	ldr	x23, [sp, #0x240]
    9a80:      	ldr	x24, [sp, #0x248]
    9a84:      	ldr	x25, [sp, #0x250]
    9a88:      	ldr	x26, [sp, #0x258]
    9a8c:      	ldr	x27, [sp, #0x260]
    9a90:      	ldr	x28, [sp, #0x268]
    9a94:      	ldr	x29, [sp]
    9a98:      	ldr	x30, [sp, #0x8]
    9a9c:      	add	sp, sp, #0x270
    9aa0:      	ret
    9aa4:      	add	x16, sp, #0x110
    9aa8:      	ldr	x2, [x16, #0x8]
    9aac:      	add	x16, sp, #0x110
    9ab0:      	ldr	x3, [x16, #0x10]
    9ab4:      	cmp	x2, x3
    9ab8:      	b.lt	0x9ef4 <_stogir.checked-schedule.cluster!+0xa6c>
    9abc:      	cmp	x3, #0x0
    9ac0:      	b.ne	0x97fc <_stogir.checked-schedule.cluster!+0x374>
    9ac4:      	mov	x3, #0x2                ; =2
    9ac8:      	b	0x9800 <_stogir.checked-schedule.cluster!+0x378>
    9acc:      	add	x16, sp, #0x180
    9ad0:      	orr	x0, x16, xzr
    9ad4:      	add	x1, x20, #0x28
    9ad8:      	add	x19, x0, #0x8
    9adc:      	ldr	x0, [x20, #0x28]
    9ae0:      	orr	x21, x0, xzr
    9ae4:      	ldr	x0, [x1, #0x8]
    9ae8:      	movz	x1, #0x0, lsl #48
    9aec:      	b	0x96b4 <_stogir.checked-schedule.cluster!+0x22c>
    9af0:      	lsl	x2, x2, #1
    9af4:      	str	x19, [sp, #0x1d8]
    9af8:      	str	x21, [sp, #0x1e0]
    9afc:      	mov	x21, x1
    9b00:      	mov	x1, x2
    9b04:      	fmov	d31, x0
    9b08:      	mov	x0, x19
    9b0c:      	fmov	x19, d31
    9b10:      	bl	0x9b10 <_stogir.checked-schedule.cluster!+0x688>
		0000000000009b10:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9b14:      	add	x0, x21, #0x1
    9b18:      	add	x16, sp, #0x50
    9b1c:      	ldr	x1, [x16]
    9b20:      	add	x1, x1, x21, lsl #2
    9b24:      	movz	w17, #0x0, lsl #16
    9b28:      	str	w17, [x1]
    9b2c:      	add	x16, sp, #0x50
    9b30:      	str	x0, [x16, #0x8]
    9b34:      	add	x16, sp, #0x80
    9b38:      	ldr	x0, [x16, #0x8]
    9b3c:      	orr	x21, x0, xzr
    9b40:      	add	x16, sp, #0x80
    9b44:      	ldr	x0, [x16, #0x10]
    9b48:      	cmp	x21, x0
    9b4c:      	b.lt	0x9b70 <_stogir.checked-schedule.cluster!+0x6e8>
    9b50:      	cmp	x0, #0x0
    9b54:      	b.ne	0x9b60 <_stogir.checked-schedule.cluster!+0x6d8>
    9b58:      	mov	x0, #0x2                ; =2
    9b5c:      	b	0x9b64 <_stogir.checked-schedule.cluster!+0x6dc>
    9b60:      	lsl	x0, x0, #1
    9b64:      	mov	x1, x0
    9b68:      	mov	x0, x25
    9b6c:      	bl	0x9b6c <_stogir.checked-schedule.cluster!+0x6e4>
		0000000000009b6c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9b70:      	add	x0, x21, #0x1
    9b74:      	add	x16, sp, #0x80
    9b78:      	ldr	x1, [x16]
    9b7c:      	add	x1, x1, x21, lsl #2
    9b80:      	movz	w17, #0x0, lsl #16
    9b84:      	str	w17, [x1]
    9b88:      	add	x16, sp, #0x80
    9b8c:      	str	x0, [x16, #0x8]
    9b90:      	add	x16, sp, #0xb0
    9b94:      	ldr	x0, [x16, #0x8]
    9b98:      	orr	x21, x0, xzr
    9b9c:      	add	x16, sp, #0xb0
    9ba0:      	ldr	x0, [x16, #0x10]
    9ba4:      	cmp	x21, x0
    9ba8:      	b.lt	0x9bcc <_stogir.checked-schedule.cluster!+0x744>
    9bac:      	cmp	x0, #0x0
    9bb0:      	b.ne	0x9bbc <_stogir.checked-schedule.cluster!+0x734>
    9bb4:      	mov	x0, #0x2                ; =2
    9bb8:      	b	0x9bc0 <_stogir.checked-schedule.cluster!+0x738>
    9bbc:      	lsl	x0, x0, #1
    9bc0:      	mov	x1, x0
    9bc4:      	ldr	x0, [sp, #0x1e0]
    9bc8:      	bl	0x9bc8 <_stogir.checked-schedule.cluster!+0x740>
		0000000000009bc8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9bcc:      	add	x0, x21, #0x1
    9bd0:      	add	x16, sp, #0xb0
    9bd4:      	ldr	x1, [x16]
    9bd8:      	add	x1, x1, x21, lsl #2
    9bdc:      	movz	w17, #0x0, lsl #16
    9be0:      	str	w17, [x1]
    9be4:      	add	x16, sp, #0xb0
    9be8:      	str	x0, [x16, #0x8]
    9bec:      	add	x16, sp, #0xe0
    9bf0:      	ldr	x0, [x16, #0x8]
    9bf4:      	orr	x21, x0, xzr
    9bf8:      	add	x16, sp, #0xe0
    9bfc:      	ldr	x0, [x16, #0x10]
    9c00:      	cmp	x21, x0
    9c04:      	b.lt	0x9c28 <_stogir.checked-schedule.cluster!+0x7a0>
    9c08:      	cmp	x0, #0x0
    9c0c:      	b.ne	0x9c18 <_stogir.checked-schedule.cluster!+0x790>
    9c10:      	mov	x0, #0x2                ; =2
    9c14:      	b	0x9c1c <_stogir.checked-schedule.cluster!+0x794>
    9c18:      	lsl	x0, x0, #1
    9c1c:      	mov	x1, x0
    9c20:      	ldr	x0, [sp, #0x1d0]
    9c24:      	bl	0x9c24 <_stogir.checked-schedule.cluster!+0x79c>
		0000000000009c24:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    9c28:      	add	x19, x19, #0x1
    9c2c:      	add	x0, x21, #0x1
    9c30:      	add	x16, sp, #0xe0
    9c34:      	ldr	x1, [x16]
    9c38:      	add	x1, x1, x21
    9c3c:      	movz	w17, #0x0, lsl #16
    9c40:      	strb	w17, [x1]
    9c44:      	add	x16, sp, #0xe0
    9c48:      	str	x0, [x16, #0x8]
    9c4c:      	ldr	x21, [sp, #0x1e0]
    9c50:      	mov	x0, x19
    9c54:      	ldr	x19, [sp, #0x1d8]
    9c58:      	ldr	x1, [x27, #0x8]
    9c5c:      	cmp	x0, x1
    9c60:      	b.ge	0x9f10 <_stogir.checked-schedule.cluster!+0xa88>
    9c64:      	add	x16, sp, #0x50
    9c68:      	ldr	x1, [x16, #0x8]
    9c6c:      	add	x16, sp, #0x50
    9c70:      	ldr	x2, [x16, #0x10]
    9c74:      	cmp	x1, x2
    9c78:      	b.lt	0x9f1c <_stogir.checked-schedule.cluster!+0xa94>
    9c7c:      	cmp	x2, #0x0
    9c80:      	b.ne	0x9af0 <_stogir.checked-schedule.cluster!+0x668>
    9c84:      	mov	x2, #0x2                ; =2
    9c88:      	b	0x9af4 <_stogir.checked-schedule.cluster!+0x66c>
    9c8c:      	add	x16, sp, #0x50
    9c90:      	orr	x19, x16, xzr
    9c94:      	add	x16, sp, #0x80
    9c98:      	orr	x25, x16, xzr
    9c9c:      	add	x16, sp, #0xb0
    9ca0:      	orr	x0, x16, xzr
    9ca4:      	add	x16, sp, #0xe0
    9ca8:      	orr	x1, x16, xzr
    9cac:      	ldr	x2, [x21]
    9cb0:      	ldr	x3, [x21, #0x8]
    9cb4:      	add	x16, sp, #0x50
    9cb8:      	movz	x17, #0x0, lsl #48
    9cbc:      	str	x17, [x16]
    9cc0:      	add	x16, sp, #0x50
    9cc4:      	movz	x17, #0x0, lsl #48
    9cc8:      	str	x17, [x16, #0x8]
    9ccc:      	add	x16, sp, #0x50
    9cd0:      	movz	x17, #0x0, lsl #48
    9cd4:      	str	x17, [x16, #0x10]
    9cd8:      	add	x16, sp, #0x50
    9cdc:      	str	x2, [x16, #0x18]
    9ce0:      	add	x16, sp, #0x50
    9ce4:      	str	x3, [x16, #0x20]
    9ce8:      	ldr	x2, [x21]
    9cec:      	ldr	x3, [x21, #0x8]
    9cf0:      	add	x16, sp, #0x80
    9cf4:      	movz	x17, #0x0, lsl #48
    9cf8:      	str	x17, [x16]
    9cfc:      	add	x16, sp, #0x80
    9d00:      	movz	x17, #0x0, lsl #48
    9d04:      	str	x17, [x16, #0x8]
    9d08:      	add	x16, sp, #0x80
    9d0c:      	movz	x17, #0x0, lsl #48
    9d10:      	str	x17, [x16, #0x10]
    9d14:      	add	x16, sp, #0x80
    9d18:      	str	x2, [x16, #0x18]
    9d1c:      	add	x16, sp, #0x80
    9d20:      	str	x3, [x16, #0x20]
    9d24:      	ldr	x2, [x21]
    9d28:      	ldr	x3, [x21, #0x8]
    9d2c:      	add	x16, sp, #0xb0
    9d30:      	movz	x17, #0x0, lsl #48
    9d34:      	str	x17, [x16]
    9d38:      	add	x16, sp, #0xb0
    9d3c:      	movz	x17, #0x0, lsl #48
    9d40:      	str	x17, [x16, #0x8]
    9d44:      	add	x16, sp, #0xb0
    9d48:      	movz	x17, #0x0, lsl #48
    9d4c:      	str	x17, [x16, #0x10]
    9d50:      	add	x16, sp, #0xb0
    9d54:      	str	x2, [x16, #0x18]
    9d58:      	add	x16, sp, #0xb0
    9d5c:      	str	x3, [x16, #0x20]
    9d60:      	ldr	x2, [x21]
    9d64:      	ldr	x3, [x21, #0x8]
    9d68:      	add	x16, sp, #0xe0
    9d6c:      	movz	x17, #0x0, lsl #48
    9d70:      	str	x17, [x16]
    9d74:      	add	x16, sp, #0xe0
    9d78:      	movz	x17, #0x0, lsl #48
    9d7c:      	str	x17, [x16, #0x8]
    9d80:      	add	x16, sp, #0xe0
    9d84:      	movz	x17, #0x0, lsl #48
    9d88:      	str	x17, [x16, #0x10]
    9d8c:      	add	x16, sp, #0xe0
    9d90:      	str	x2, [x16, #0x18]
    9d94:      	add	x16, sp, #0xe0
    9d98:      	str	x3, [x16, #0x20]
    9d9c:      	add	x8, sp, #0x140
    9da0:      	str	x1, [sp, #0x1d0]
    9da4:      	fmov	d31, x0
    9da8:      	mov	x0, x21
    9dac:      	fmov	x21, d31
    9db0:      	bl	0x9db0 <_stogir.checked-schedule.cluster!+0x928>
		0000000000009db0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    9db4:      	add	x16, sp, #0x140
    9db8:      	ldr	x0, [x16]
    9dbc:      	add	x16, sp, #0x110
    9dc0:      	str	x0, [x16]
    9dc4:      	add	x16, sp, #0x140
    9dc8:      	ldr	x0, [x16, #0x8]
    9dcc:      	add	x16, sp, #0x110
    9dd0:      	str	x0, [x16, #0x8]
    9dd4:      	add	x16, sp, #0x140
    9dd8:      	ldr	x0, [x16, #0x10]
    9ddc:      	add	x16, sp, #0x110
    9de0:      	str	x0, [x16, #0x10]
    9de4:      	add	x16, sp, #0x140
    9de8:      	ldr	x0, [x16, #0x18]
    9dec:      	add	x16, sp, #0x110
    9df0:      	str	x0, [x16, #0x18]
    9df4:      	add	x16, sp, #0x140
    9df8:      	ldr	x0, [x16, #0x20]
    9dfc:      	add	x16, sp, #0x110
    9e00:      	str	x0, [x16, #0x20]
    9e04:      	movz	x0, #0x0, lsl #48
    9e08:      	b	0x9c58 <_stogir.checked-schedule.cluster!+0x7d0>
    9e0c:      	add	x16, sp, #0x180
    9e10:      	ldr	w0, [x16, #0x8]
    9e14:      	sxtw	x0, w0
    9e18:      	cmp	x0, #0x0
    9e1c:      	b.eq	0x96a4 <_stogir.checked-schedule.cluster!+0x21c>
    9e20:      	add	x16, sp, #0x170
    9e24:      	ldr	w0, [x16, #0x4]
    9e28:      	sxtw	x0, w0
    9e2c:      	add	x16, sp, #0x80
    9e30:      	ldr	x1, [x16]
    9e34:      	add	x1, x1, x0, lsl #2
    9e38:      	ldr	w1, [x1]
    9e3c:      	ldr	x2, [x28]
    9e40:      	orr	x3, x2, xzr
    9e44:      	add	x3, x3, x0, lsl #2
    9e48:      	add	x2, x2, x25, lsl #2
    9e4c:      	ldr	w3, [x3]
    9e50:      	ldr	w2, [x2]
    9e54:      	sxtw	x3, w3
    9e58:      	sxtw	x2, w2
    9e5c:      	cmp	x3, x2
    9e60:      	b.eq	0x9e70 <_stogir.checked-schedule.cluster!+0x9e8>
    9e64:      	adrp	x23, 0x9000 <_stogir.schedule.pack+0x140>
		0000000000009e64:  ARM64_RELOC_PAGE21	l_stogir.452
    9e68:      	ldr	x23, [x23]
		0000000000009e68:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9e6c:      	mov	x24, #0x30              ; =48
    9e70:      	sxtw	x1, w1
    9e74:      	cmp	x1, #0x0
    9e78:      	b.ne	0x9670 <_stogir.checked-schedule.cluster!+0x1e8>
    9e7c:      	add	x16, sp, #0x50
    9e80:      	ldr	x1, [x16]
    9e84:      	add	x1, x1, x0, lsl #2
    9e88:      	str	w21, [x1]
    9e8c:      	b	0x9680 <_stogir.checked-schedule.cluster!+0x1f8>
    9e90:      	brk	#0
    9e94:      	b	0x9e90 <_stogir.checked-schedule.cluster!+0xa08>
    9e98:      	brk	#0
    9e9c:      	b	0x9e98 <_stogir.checked-schedule.cluster!+0xa10>
    9ea0:      	brk	#0
    9ea4:      	b	0x9ea0 <_stogir.checked-schedule.cluster!+0xa18>
    9ea8:      	brk	#0
    9eac:      	b	0x9ea8 <_stogir.checked-schedule.cluster!+0xa20>
    9eb0:      	brk	#0
    9eb4:      	b	0x9eb0 <_stogir.checked-schedule.cluster!+0xa28>
    9eb8:      	brk	#0
    9ebc:      	b	0x9eb8 <_stogir.checked-schedule.cluster!+0xa30>
    9ec0:      	mov	x26, x8
    9ec4:      	mov	x27, x0
    9ec8:      	mov	x28, x1
    9ecc:      	str	x20, [sp, #0x1c0]
    9ed0:      	mov	x20, x2
    9ed4:      	str	x21, [sp, #0x1c8]
    9ed8:      	mov	x21, x3
    9edc:      	b	0x9514 <_stogir.checked-schedule.cluster!+0x8c>
    9ee0:      	str	x25, [sp, #0x200]
    9ee4:      	str	x21, [sp, #0x1f8]
    9ee8:      	str	x0, [sp, #0x1e8]
    9eec:      	str	x1, [sp, #0x1f0]
    9ef0:      	b	0x96a4 <_stogir.checked-schedule.cluster!+0x21c>
    9ef4:      	str	x19, [sp, #0x208]
    9ef8:      	mov	w19, w1
    9efc:      	str	x21, [sp, #0x210]
    9f00:      	mov	x21, x0
    9f04:      	str	x25, [sp, #0x218]
    9f08:      	mov	x25, x2
    9f0c:      	b	0x9824 <_stogir.checked-schedule.cluster!+0x39c>
    9f10:      	str	x19, [sp, #0x1d8]
    9f14:      	str	x21, [sp, #0x1e0]
    9f18:      	b	0x9acc <_stogir.checked-schedule.cluster!+0x644>
    9f1c:      	str	x19, [sp, #0x1d8]
    9f20:      	mov	x19, x0
    9f24:      	str	x21, [sp, #0x1e0]
    9f28:      	mov	x21, x1
    9f2c:      	b	0x9b14 <_stogir.checked-schedule.cluster!+0x68c>

0000000000009f30 <_stogir.adjacency.release!>:
    9f30:      	sub	sp, sp, #0x20
    9f34:      	str	x29, [sp]
    9f38:      	str	x30, [sp, #0x8]
    9f3c:      	mov	x29, sp
    9f40:      	str	x19, [sp, #0x10]
    9f44:      	str	x20, [sp, #0x18]
    9f48:      	b	0x9f58 <_stogir.adjacency.release!+0x28>
    9f4c:      	nop
    9f50:      	sub	x1, x1, #0x1
    9f54:      	str	x1, [x0, #0x8]
    9f58:      	ldr	x1, [x0, #0x8]
    9f5c:      	cmp	x1, #0x0
    9f60:      	b.ne	0x9f50 <_stogir.adjacency.release!+0x20>
    9f64:      	ldr	x1, [x0, #0x10]
    9f68:      	cmp	x1, #0x0
    9f6c:      	b.le	0xa03c <_stogir.adjacency.release!+0x10c>
    9f70:      	add	x2, x0, #0x18
    9f74:      	ldr	x3, [x0]
    9f78:      	mov	x19, x0
    9f7c:      	mov	x0, x2
    9f80:      	mov	x2, x1
    9f84:      	mov	x1, x3
    9f88:      	adrp	x3, 0x9000 <_stogir.schedule.pack+0x140>
		0000000000009f88:  ARM64_RELOC_PAGE21	l_stogir.453
    9f8c:      	ldr	x3, [x3]
		0000000000009f8c:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    9f90:      	mov	x4, #0x10               ; =16
    9f94:      	mov	x5, #0x8                ; =8
    9f98:      	bl	0x9f98 <_stogir.adjacency.release!+0x68>
		0000000000009f98:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    9f9c:      	add	x20, x19, #0x28
    9fa0:      	movz	x17, #0x0, lsl #48
    9fa4:      	str	x17, [x19]
    9fa8:      	movz	x17, #0x0, lsl #48
    9fac:      	str	x17, [x19, #0x8]
    9fb0:      	movz	x17, #0x0, lsl #48
    9fb4:      	str	x17, [x19, #0x10]
    9fb8:      	b	0x9fc8 <_stogir.adjacency.release!+0x98>
    9fbc:      	nop
    9fc0:      	sub	x0, x0, #0x1
    9fc4:      	str	x0, [x20, #0x8]
    9fc8:      	ldr	x0, [x20, #0x8]
    9fcc:      	cmp	x0, #0x0
    9fd0:      	b.ne	0x9fc0 <_stogir.adjacency.release!+0x90>
    9fd4:      	ldr	x0, [x20, #0x10]
    9fd8:      	cmp	x0, #0x0
    9fdc:      	b.le	0xa00c <_stogir.adjacency.release!+0xdc>
    9fe0:      	add	x1, x20, #0x18
    9fe4:      	ldr	x2, [x19, #0x28]
    9fe8:      	fmov	d31, x0
    9fec:      	mov	x0, x1
    9ff0:      	mov	x1, x2
    9ff4:      	fmov	x2, d31
    9ff8:      	adrp	x3, 0x9000 <_stogir.schedule.pack+0x140>
		0000000000009ff8:  ARM64_RELOC_PAGE21	l_stogir.454
    9ffc:      	ldr	x3, [x3]
		0000000000009ffc:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    a000:      	mov	x4, #0x8                ; =8
    a004:      	mov	x5, #0x8                ; =8
    a008:      	bl	0xa008 <_stogir.adjacency.release!+0xd8>
		000000000000a008:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a00c:      	movz	x17, #0x0, lsl #48
    a010:      	str	x17, [x19, #0x28]
    a014:      	movz	x17, #0x0, lsl #48
    a018:      	str	x17, [x20, #0x8]
    a01c:      	movz	x17, #0x0, lsl #48
    a020:      	str	x17, [x20, #0x10]
    a024:      	ldr	x19, [sp, #0x10]
    a028:      	ldr	x20, [sp, #0x18]
    a02c:      	ldr	x29, [sp]
    a030:      	ldr	x30, [sp, #0x8]
    a034:      	add	sp, sp, #0x20
    a038:      	ret
    a03c:      	mov	x19, x0
    a040:      	b	0x9f9c <_stogir.adjacency.release!+0x6c>
    a044:      	udf	#0x0

000000000000a048 <_inherent$coil.arraylist.ArrayList$free!__bool>:
    a048:      	sub	sp, sp, #0x20
    a04c:      	str	x29, [sp]
    a050:      	str	x30, [sp, #0x8]
    a054:      	mov	x29, sp
    a058:      	str	x19, [sp, #0x10]
    a05c:      	b	0xa068 <_inherent$coil.arraylist.ArrayList$free!__bool+0x20>
    a060:      	sub	x1, x1, #0x1
    a064:      	str	x1, [x0, #0x8]
    a068:      	ldr	x1, [x0, #0x8]
    a06c:      	cmp	x1, #0x0
    a070:      	b.ne	0xa060 <_inherent$coil.arraylist.ArrayList$free!__bool+0x18>
    a074:      	ldr	x1, [x0, #0x10]
    a078:      	cmp	x1, #0x0
    a07c:      	b.le	0xa0dc <_inherent$coil.arraylist.ArrayList$free!__bool+0x94>
    a080:      	add	x2, x0, #0x18
    a084:      	ldr	x3, [x0]
    a088:      	mov	x19, x0
    a08c:      	mov	x0, x2
    a090:      	mov	x2, x1
    a094:      	mov	x1, x3
    a098:      	adrp	x3, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a098:  ARM64_RELOC_PAGE21	l_stogir.455
    a09c:      	ldr	x3, [x3]
		000000000000a09c:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    a0a0:      	mov	x4, #0x1                ; =1
    a0a4:      	mov	x5, #0x1                ; =1
    a0a8:      	bl	0xa0a8 <_inherent$coil.arraylist.ArrayList$free!__bool+0x60>
		000000000000a0a8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a0ac:      	movz	x17, #0x0, lsl #48
    a0b0:      	str	x17, [x19]
    a0b4:      	movz	x17, #0x0, lsl #48
    a0b8:      	str	x17, [x19, #0x8]
    a0bc:      	movz	x17, #0x0, lsl #48
    a0c0:      	str	x17, [x19, #0x10]
    a0c4:      	movz	x0, #0x0, lsl #48
    a0c8:      	ldr	x19, [sp, #0x10]
    a0cc:      	ldr	x29, [sp]
    a0d0:      	ldr	x30, [sp, #0x8]
    a0d4:      	add	sp, sp, #0x20
    a0d8:      	ret
    a0dc:      	mov	x19, x0
    a0e0:      	b	0xa0ac <_inherent$coil.arraylist.ArrayList$free!__bool+0x64>
    a0e4:      	udf	#0x0

000000000000a0e8 <_stogir.uses.release!>:
    a0e8:      	sub	sp, sp, #0x20
    a0ec:      	str	x29, [sp]
    a0f0:      	str	x30, [sp, #0x8]
    a0f4:      	mov	x29, sp
    a0f8:      	str	x19, [sp, #0x10]
    a0fc:      	str	x20, [sp, #0x18]
    a100:      	b	0xa110 <_stogir.uses.release!+0x28>
    a104:      	nop
    a108:      	sub	x1, x1, #0x1
    a10c:      	str	x1, [x0, #0x8]
    a110:      	ldr	x1, [x0, #0x8]
    a114:      	cmp	x1, #0x0
    a118:      	b.ne	0xa108 <_stogir.uses.release!+0x20>
    a11c:      	ldr	x1, [x0, #0x10]
    a120:      	cmp	x1, #0x0
    a124:      	b.le	0xa1f4 <_stogir.uses.release!+0x10c>
    a128:      	add	x2, x0, #0x18
    a12c:      	ldr	x3, [x0]
    a130:      	mov	x19, x0
    a134:      	mov	x0, x2
    a138:      	mov	x2, x1
    a13c:      	mov	x1, x3
    a140:      	adrp	x3, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a140:  ARM64_RELOC_PAGE21	l_stogir.456
    a144:      	ldr	x3, [x3]
		000000000000a144:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    a148:      	mov	x4, #0x10               ; =16
    a14c:      	mov	x5, #0x8                ; =8
    a150:      	bl	0xa150 <_stogir.uses.release!+0x68>
		000000000000a150:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a154:      	add	x20, x19, #0x28
    a158:      	movz	x17, #0x0, lsl #48
    a15c:      	str	x17, [x19]
    a160:      	movz	x17, #0x0, lsl #48
    a164:      	str	x17, [x19, #0x8]
    a168:      	movz	x17, #0x0, lsl #48
    a16c:      	str	x17, [x19, #0x10]
    a170:      	b	0xa180 <_stogir.uses.release!+0x98>
    a174:      	nop
    a178:      	sub	x0, x0, #0x1
    a17c:      	str	x0, [x20, #0x8]
    a180:      	ldr	x0, [x20, #0x8]
    a184:      	cmp	x0, #0x0
    a188:      	b.ne	0xa178 <_stogir.uses.release!+0x90>
    a18c:      	ldr	x0, [x20, #0x10]
    a190:      	cmp	x0, #0x0
    a194:      	b.le	0xa1c4 <_stogir.uses.release!+0xdc>
    a198:      	add	x1, x20, #0x18
    a19c:      	ldr	x2, [x19, #0x28]
    a1a0:      	fmov	d31, x0
    a1a4:      	mov	x0, x1
    a1a8:      	mov	x1, x2
    a1ac:      	fmov	x2, d31
    a1b0:      	adrp	x3, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a1b0:  ARM64_RELOC_PAGE21	l_stogir.457
    a1b4:      	ldr	x3, [x3]
		000000000000a1b4:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    a1b8:      	mov	x4, #0x8                ; =8
    a1bc:      	mov	x5, #0x4                ; =4
    a1c0:      	bl	0xa1c0 <_stogir.uses.release!+0xd8>
		000000000000a1c0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    a1c4:      	movz	x17, #0x0, lsl #48
    a1c8:      	str	x17, [x19, #0x28]
    a1cc:      	movz	x17, #0x0, lsl #48
    a1d0:      	str	x17, [x20, #0x8]
    a1d4:      	movz	x17, #0x0, lsl #48
    a1d8:      	str	x17, [x20, #0x10]
    a1dc:      	ldr	x19, [sp, #0x10]
    a1e0:      	ldr	x20, [sp, #0x18]
    a1e4:      	ldr	x29, [sp]
    a1e8:      	ldr	x30, [sp, #0x8]
    a1ec:      	add	sp, sp, #0x20
    a1f0:      	ret
    a1f4:      	mov	x19, x0
    a1f8:      	b	0xa154 <_stogir.uses.release!+0x6c>
    a1fc:      	udf	#0x0

000000000000a200 <_stogir.verify.structure>:
    a200:      	sub	sp, sp, #0x110
    a204:      	str	x29, [sp, #0x10]
    a208:      	str	x30, [sp, #0x18]
    a20c:      	add	x29, sp, #0x10
    a210:      	str	x19, [sp, #0xb8]
    a214:      	str	x20, [sp, #0xc0]
    a218:      	str	x21, [sp, #0xc8]
    a21c:      	str	x22, [sp, #0xd0]
    a220:      	str	x23, [sp, #0xd8]
    a224:      	str	x24, [sp, #0xe0]
    a228:      	str	x25, [sp, #0xe8]
    a22c:      	str	x26, [sp, #0xf0]
    a230:      	str	x27, [sp, #0xf8]
    a234:      	str	x28, [sp, #0x100]
    a238:      	add	x1, x0, #0x78
    a23c:      	ldr	x2, [x0, #0x8]
    a240:      	ldr	x1, [x1, #0x8]
    a244:      	cmp	x2, x1
    a248:      	b.ne	0xa278 <_stogir.verify.structure+0x78>
    a24c:      	adrp	x19, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a24c:  ARM64_RELOC_PAGE21	l_stogir.458
    a250:      	ldr	x19, [x19]
		000000000000a250:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    a254:      	movz	x20, #0x0, lsl #48
    a258:      	b	0xa284 <_stogir.verify.structure+0x84>
    a25c:      	ldr	x1, [sp, #0x88]
    a260:      	ldr	x5, [sp, #0x90]
    a264:      	add	x5, x1, x5
    a268:      	ldr	x20, [sp, #0x40]
    a26c:      	add	x1, x20, #0x1
    a270:      	sxtw	x20, w1
    a274:      	b	0xa2b8 <_stogir.verify.structure+0xb8>
    a278:      	adrp	x19, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a278:  ARM64_RELOC_PAGE21	l_stogir.459
    a27c:      	ldr	x19, [x19]
		000000000000a27c:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    a280:      	mov	x20, #0x2c              ; =44
    a284:      	add	x21, x0, #0x110
    a288:      	add	x22, x0, #0x78
    a28c:      	add	x23, x0, #0x28
    a290:      	add	x24, x0, #0x50
    a294:      	add	x25, x21, #0x28
    a298:      	mov	x26, #0x1               ; =1
    a29c:      	movz	x27, #0x0, lsl #48
    a2a0:      	b	0xa31c <_stogir.verify.structure+0x11c>
    a2a4:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a2a4:  ARM64_RELOC_PAGE21	l_stogir.460
    a2a8:      	ldr	x16, [x16]
		000000000000a2a8:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    a2ac:      	str	x16, [sp, #0x38]
    a2b0:      	mov	x16, #0x16              ; =22
    a2b4:      	str	x16, [sp, #0x80]
    a2b8:      	b	0xa2f4 <_stogir.verify.structure+0xf4>
    a2bc:      	nop
    a2c0:      	mov	x5, x26
    a2c4:      	mov	x20, x27
    a2c8:      	str	x8, [sp, #0x30]
    a2cc:      	mov	x19, x0
    a2d0:      	mov	x2, x21
    a2d4:      	mov	x0, x22
    a2d8:      	mov	x3, x23
    a2dc:      	mov	x4, x24
    a2e0:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a2e0:  ARM64_RELOC_PAGE21	l_stogir.461
    a2e4:      	ldr	x16, [x16]
		000000000000a2e4:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    a2e8:      	str	x16, [sp, #0x38]
    a2ec:      	mov	x16, #0x23              ; =35
    a2f0:      	str	x16, [sp, #0x80]
    a2f4:      	ldr	x8, [sp, #0x30]
    a2f8:      	mov	x21, x2
    a2fc:      	mov	x22, x0
    a300:      	mov	x0, x19
    a304:      	mov	x23, x3
    a308:      	mov	x24, x4
    a30c:      	mov	x26, x5
    a310:      	mov	x27, x20
    a314:      	ldr	x19, [sp, #0x38]
    a318:      	ldr	x20, [sp, #0x80]
    a31c:      	cmp	x20, #0x0
    a320:      	b.ne	0xaadc <_stogir.verify.structure+0x8dc>
    a324:      	ldr	x1, [x0, #0x8]
    a328:      	cmp	x26, x1
    a32c:      	b.ge	0xaaf0 <_stogir.verify.structure+0x8f0>
    a330:      	ldr	x1, [x0]
    a334:      	add	x1, x1, x26, lsl #4
    a338:      	ldr	x1, [x1]
    a33c:      	ldr	x2, [x0, #0x78]
    a340:      	add	x2, x2, x26, lsl #2
    a344:      	ldr	w2, [x2]
    a348:      	sxtw	x28, w2
    a34c:      	cmp	x28, #0x0
    a350:      	b.lt	0xa2c0 <_stogir.verify.structure+0xc0>
    a354:      	mov	x17, #0xffff            ; =65535
    a358:      	cmp	x28, x17
    a35c:      	b.gt	0xab04 <_stogir.verify.structure+0x904>
    a360:      	uxtb	w2, w1
    a364:      	orr	x3, x2, xzr
    a368:      	cmp	x3, #0x83
    a36c:      	cset	w4, lt
    a370:      	uxtb	w16, w4
    a374:      	cmp	w16, wzr
    a378:      	b.eq	0xab28 <_stogir.verify.structure+0x928>
    a37c:      	ubfx	x1, x1, #0, #32
    a380:      	ubfx	x5, x1, #8, #8
    a384:      	orr	x6, x5, xzr
    a388:      	str	x8, [sp, #0x30]
    a38c:      	str	x19, [sp, #0x38]
    a390:      	mov	x19, x0
    a394:      	mov	w0, w6
    a398:      	str	x27, [sp, #0x40]
    a39c:      	mov	w27, w2
    a3a0:      	str	x24, [sp, #0x48]
    a3a4:      	mov	x24, x3
    a3a8:      	str	x23, [sp, #0x50]
    a3ac:      	mov	w23, w4
    a3b0:      	str	x22, [sp, #0x58]
    a3b4:      	mov	x22, x1
    a3b8:      	str	x21, [sp, #0x60]
    a3bc:      	mov	w21, w5
    a3c0:      	bl	0xa3c0 <_stogir.verify.structure+0x1c0>
		000000000000a3c0:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    a3c4:      	cmp	x0, #0x0
    a3c8:      	b.eq	0xab4c <_stogir.verify.structure+0x94c>
    a3cc:      	adrp	x17, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a3cc:  ARM64_RELOC_PAGE21	l_stogir.462
    a3d0:      	ldr	x17, [x17]
		000000000000a3d0:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    a3d4:      	add	x0, x24, x17
    a3d8:      	ldrsb	w0, [x0]
    a3dc:      	sxtb	x0, w0
    a3e0:      	cmp	x0, #0x0
    a3e4:      	b.lt	0xa7fc <_stogir.verify.structure+0x5fc>
    a3e8:      	uxtb	w16, w23
    a3ec:      	cmp	w16, wzr
    a3f0:      	b.eq	0xa8d0 <_stogir.verify.structure+0x6d0>
    a3f4:      	adrp	x17, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a3f4:  ARM64_RELOC_PAGE21	l_stogir.462
    a3f8:      	ldr	x17, [x17]
		000000000000a3f8:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    a3fc:      	add	x0, x24, x17
    a400:      	ldrsb	w0, [x0]
    a404:      	sxtb	w0, w0
    a408:      	b	0xa8d4 <_stogir.verify.structure+0x6d4>
    a40c:      	ldr	x0, [sp, #0x38]
    a410:      	ldr	x1, [sp, #0x80]
    a414:      	adrp	x2, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a414:  ARM64_RELOC_PAGE21	l_stogir.458
    a418:      	ldr	x2, [x2]
		000000000000a418:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    a41c:      	movz	x3, #0x0, lsl #48
    a420:      	bl	0xa420 <_stogir.verify.structure+0x220>
		000000000000a420:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    a424:      	cmp	x0, #0x0
    a428:      	b.eq	0xab68 <_stogir.verify.structure+0x968>
    a42c:      	and	x0, x20, #0xffffffff
    a430:      	movz	x1, #0x0, lsl #48
    a434:      	movz	x16, #0x0, lsl #48
    a438:      	str	x16, [sp, #0x80]
    a43c:      	b	0xa444 <_stogir.verify.structure+0x244>
    a440:      	mov	x1, #0x1                ; =1
    a444:      	ldr	x2, [sp, #0x30]
    a448:      	str	x1, [x2]
    a44c:      	str	x0, [x2, #0x8]
    a450:      	ldr	x0, [sp, #0x80]
    a454:      	str	x0, [x2, #0x10]
    a458:      	ldr	x19, [sp, #0xb8]
    a45c:      	ldr	x20, [sp, #0xc0]
    a460:      	ldr	x21, [sp, #0xc8]
    a464:      	ldr	x22, [sp, #0xd0]
    a468:      	ldr	x23, [sp, #0xd8]
    a46c:      	ldr	x24, [sp, #0xe0]
    a470:      	ldr	x25, [sp, #0xe8]
    a474:      	ldr	x26, [sp, #0xf0]
    a478:      	ldr	x27, [sp, #0xf8]
    a47c:      	ldr	x28, [sp, #0x100]
    a480:      	ldr	x29, [sp, #0x10]
    a484:      	ldr	x30, [sp, #0x18]
    a488:      	add	sp, sp, #0x110
    a48c:      	ret
    a490:      	mov	w9, w5
    a494:      	lsl	w9, w9, #2
    a498:      	ubfx	x9, x9, #0, #32
    a49c:      	lsr	x8, x8, x9
    a4a0:      	and	w8, w8, #0xf
    a4a4:      	b	0xa4c4 <_stogir.verify.structure+0x2c4>
    a4a8:      	movz	x1, #0x0, lsl #48
    a4ac:      	cmp	x1, #0x0
    a4b0:      	b.eq	0xa910 <_stogir.verify.structure+0x710>
    a4b4:      	ldr	w1, [sp, #0xb0]
    a4b8:      	ldr	w5, [sp, #0xa8]
    a4bc:      	b	0xa56c <_stogir.verify.structure+0x36c>
    a4c0:      	movz	w8, #0x0, lsl #16
    a4c4:      	b	0xa4cc <_stogir.verify.structure+0x2cc>
    a4c8:      	movz	w8, #0x0, lsl #16
    a4cc:      	str	w0, [sp, #0x68]
    a4d0:      	str	x2, [sp, #0x98]
    a4d4:      	mov	w2, w3
    a4d8:      	str	x4, [sp, #0xa0]
    a4dc:      	str	x24, [sp, #0x70]
    a4e0:      	mov	x24, x1
    a4e4:      	mov	w1, w0
    a4e8:      	mov	x0, x19
    a4ec:      	str	x28, [sp, #0x78]
    a4f0:      	mov	w28, w7
    a4f4:      	str	x20, [sp, #0x80]
    a4f8:      	mov	w20, w8
    a4fc:      	str	x22, [sp, #0x88]
    a500:      	mov	w22, w5
    a504:      	str	x26, [sp, #0x90]
    a508:      	mov	w26, w6
    a50c:      	bl	0xa50c <_stogir.verify.structure+0x30c>
		000000000000a50c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    a510:      	ubfx	x0, x0, #0, #32
    a514:      	lsr	x16, x0, #0
    a518:      	cmp	x16, #0x1
    a51c:      	b.eq	0xa538 <_stogir.verify.structure+0x338>
    a520:      	b.lo	0xa528 <_stogir.verify.structure+0x328>
    a524:      	b	0xa53c <_stogir.verify.structure+0x33c>
    a528:      	cmp	x16, #0x0
    a52c:      	b.eq	0xa534 <_stogir.verify.structure+0x334>
    a530:      	b	0xa53c <_stogir.verify.structure+0x33c>
    a534:      	b	0xa540 <_stogir.verify.structure+0x340>
    a538:      	b	0xa620 <_stogir.verify.structure+0x420>
    a53c:      	b	0xaa44 <_stogir.verify.structure+0x844>
    a540:      	ldr	x2, [sp, #0x60]
    a544:      	ldr	x0, [sp, #0x58]
    a548:      	ldr	x3, [sp, #0x50]
    a54c:      	ldr	x4, [sp, #0x48]
    a550:      	mov	w1, w27
    a554:      	mov	w5, w21
    a558:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a558:  ARM64_RELOC_PAGE21	l_stogir.463
    a55c:      	ldr	x16, [x16]
		000000000000a55c:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    a560:      	str	x16, [sp, #0x38]
    a564:      	mov	x16, #0x17              ; =23
    a568:      	str	x16, [sp, #0x80]
    a56c:      	ldr	x6, [sp, #0x98]
    a570:      	add	x6, x6, #0x1
    a574:      	sxtw	x6, w6
    a578:      	ldr	x26, [sp, #0x90]
    a57c:      	ldr	x28, [sp, #0x78]
    a580:      	ldr	x22, [sp, #0x88]
    a584:      	str	x2, [sp, #0x60]
    a588:      	str	x0, [sp, #0x58]
    a58c:      	ldr	w0, [sp, #0x68]
    a590:      	str	x3, [sp, #0x50]
    a594:      	str	x4, [sp, #0x48]
    a598:      	mov	w27, w1
    a59c:      	mov	w21, w5
    a5a0:      	mov	x1, x24
    a5a4:      	ldr	x24, [sp, #0x70]
    a5a8:      	mov	x2, x6
    a5ac:      	ldr	x20, [sp, #0x80]
    a5b0:      	cmp	x20, #0x0
    a5b4:      	b.ne	0xa5c8 <_stogir.verify.structure+0x3c8>
    a5b8:      	cmp	x2, x28
    a5bc:      	cset	w3, le
    a5c0:      	ubfx	x3, x3, #0, #8
    a5c4:      	b	0xa5cc <_stogir.verify.structure+0x3cc>
    a5c8:      	movz	x3, #0x0, lsl #48
    a5cc:      	cmp	x3, #0x0
    a5d0:      	b.eq	0xab70 <_stogir.verify.structure+0x970>
    a5d4:      	orr	w3, w2, wzr
    a5d8:      	sxtw	x4, w3
    a5dc:      	sub	w5, w3, #0x1
    a5e0:      	cmp	x4, #0x0
    a5e4:      	cset	w6, gt
    a5e8:      	cmp	x4, #0x4
    a5ec:      	cset	w7, gt
    a5f0:      	uxtb	w16, w23
    a5f4:      	cmp	w16, wzr
    a5f8:      	b.eq	0xa4c8 <_stogir.verify.structure+0x2c8>
    a5fc:      	ldr	w8, [x24]
    a600:      	uxtb	w16, w6
    a604:      	cmp	w16, wzr
    a608:      	b.eq	0xa4c0 <_stogir.verify.structure+0x2c0>
    a60c:      	uxtb	w16, w7
    a610:      	cmp	w16, wzr
    a614:      	b.eq	0xa490 <_stogir.verify.structure+0x290>
    a618:      	mov	w9, #0x4                ; =4
    a61c:      	b	0xa494 <_stogir.verify.structure+0x294>
    a620:      	ubfx	x20, x20, #0, #32
    a624:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a624:  ARM64_RELOC_PAGE21	l_stogir.464
    a628:      	ldr	x16, [x16]
		000000000000a628:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    a62c:      	ldr	w0, [x16]
    a630:      	cmp	x20, x0
    a634:      	b.ne	0xa648 <_stogir.verify.structure+0x448>
    a638:      	mov	x0, #0x1                ; =1
    a63c:      	b	0xa660 <_stogir.verify.structure+0x460>
    a640:      	movz	x1, #0x0, lsl #48
    a644:      	b	0xa6c0 <_stogir.verify.structure+0x4c0>
    a648:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a648:  ARM64_RELOC_PAGE21	l_stogir.465
    a64c:      	ldr	x16, [x16]
		000000000000a64c:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    a650:      	ldr	w0, [x16]
    a654:      	cmp	x20, x0
    a658:      	cset	w0, eq
    a65c:      	ubfx	x0, x0, #0, #8
    a660:      	cmp	x0, #0x0
    a664:      	b.eq	0xab90 <_stogir.verify.structure+0x990>
    a668:      	str	w21, [sp, #0xa8]
    a66c:      	mov	x21, x0
    a670:      	mov	x0, x19
    a674:      	str	w27, [sp, #0xb0]
    a678:      	mov	w27, w1
    a67c:      	bl	0xa67c <_stogir.verify.structure+0x47c>
		000000000000a67c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    a680:      	cmp	x0, #0x0
    a684:      	cset	w1, eq
    a688:      	uxtb	w16, w1
    a68c:      	cmp	w16, wzr
    a690:      	cset	x1, eq
    a694:      	cmp	x1, #0x0
    a698:      	b.eq	0xa6c0 <_stogir.verify.structure+0x4c0>
    a69c:      	ldr	w0, [x0]
    a6a0:      	uxtb	w0, w0
    a6a4:      	cmp	x0, #0x48
    a6a8:      	b.ne	0xa6c0 <_stogir.verify.structure+0x4c0>
    a6ac:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a6ac:  ARM64_RELOC_PAGE21	l_stogir.466
    a6b0:      	ldr	x16, [x16]
		000000000000a6b0:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    a6b4:      	str	x16, [sp, #0x38]
    a6b8:      	mov	x16, #0x25              ; =37
    a6bc:      	str	x16, [sp, #0x80]
    a6c0:      	sxtw	x27, w27
    a6c4:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a6c4:  ARM64_RELOC_PAGE21	l_stogir.467
    a6c8:      	ldr	x16, [x16]
		000000000000a6c8:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    a6cc:      	ldr	w0, [x16]
    a6d0:      	cmp	x20, x0
    a6d4:      	b.ne	0xaba4 <_stogir.verify.structure+0x9a4>
    a6d8:      	cmp	x27, #0x0
    a6dc:      	b.gt	0xa86c <_stogir.verify.structure+0x66c>
    a6e0:      	ldr	x2, [sp, #0x60]
    a6e4:      	movz	w0, #0x0, lsl #16
    a6e8:      	ubfx	x0, x0, #0, #32
    a6ec:      	lsr	x16, x0, #0
    a6f0:      	cmp	x16, #0x1
    a6f4:      	b.eq	0xa710 <_stogir.verify.structure+0x510>
    a6f8:      	b.lo	0xa700 <_stogir.verify.structure+0x500>
    a6fc:      	b	0xa714 <_stogir.verify.structure+0x514>
    a700:      	cmp	x16, #0x0
    a704:      	b.eq	0xa70c <_stogir.verify.structure+0x50c>
    a708:      	b	0xa714 <_stogir.verify.structure+0x514>
    a70c:      	b	0xa718 <_stogir.verify.structure+0x518>
    a710:      	b	0xa72c <_stogir.verify.structure+0x52c>
    a714:      	b	0xaad4 <_stogir.verify.structure+0x8d4>
    a718:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a718:  ARM64_RELOC_PAGE21	l_stogir.468
    a71c:      	ldr	x16, [x16]
		000000000000a71c:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    a720:      	str	x16, [sp, #0x38]
    a724:      	mov	x16, #0x21              ; =33
    a728:      	str	x16, [sp, #0x80]
    a72c:      	cmp	x20, #0xf
    a730:      	b.hs	0xabac <_stogir.verify.structure+0x9ac>
    a734:      	mov	x16, #0x1               ; =1
    a738:      	lsl	x0, x16, x20
    a73c:      	mov	w17, #0x5e1c            ; =24092
    a740:      	and	w0, w0, w17
    a744:      	ubfx	x0, x0, #0, #32
    a748:      	cmp	x0, #0x0
    a74c:      	b.eq	0xabc4 <_stogir.verify.structure+0x9c4>
    a750:      	cmp	x21, #0x0
    a754:      	b.eq	0xa958 <_stogir.verify.structure+0x758>
    a758:      	ldr	x0, [sp, #0x58]
    a75c:      	ldr	x3, [sp, #0x50]
    a760:      	ldr	x4, [sp, #0x48]
    a764:      	b	0xa4ac <_stogir.verify.structure+0x2ac>
    a768:      	orr	w0, w26, wzr
    a76c:      	cmp	x24, #0x78
    a770:      	cset	w27, eq
    a774:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a774:  ARM64_RELOC_PAGE21	l_stogir.469
    a778:      	ldr	x16, [x16]
		000000000000a778:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a77c:      	add	x1, x16, x24, lsl #2
    a780:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a780:  ARM64_RELOC_PAGE21	l_stogir.469
    a784:      	ldr	x16, [x16]
		000000000000a784:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a788:      	add	x2, x16, x24, lsl #2
    a78c:      	cmp	x21, #0x0
    a790:      	cset	w21, eq
    a794:      	orr	x24, x1, xzr
    a798:      	orr	x1, x2, xzr
    a79c:      	mov	x2, #0x1                ; =1
    a7a0:      	b	0xa5b0 <_stogir.verify.structure+0x3b0>
    a7a4:      	nop
    a7a8:      	movz	x1, #0x0, lsl #48
    a7ac:      	cmp	x1, #0x0
    a7b0:      	b.eq	0xa768 <_stogir.verify.structure+0x568>
    a7b4:      	add	x1, x0, x26
    a7b8:      	ldr	x2, [x19, #0x78]
    a7bc:      	add	x1, x2, x1, lsl #2
    a7c0:      	ldr	w1, [x1]
    a7c4:      	sxtw	x1, w1
    a7c8:      	cmn	x1, #0x1
    a7cc:      	b.eq	0xa7e0 <_stogir.verify.structure+0x5e0>
    a7d0:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a7d0:  ARM64_RELOC_PAGE21	l_stogir.470
    a7d4:      	ldr	x16, [x16]
		000000000000a7d4:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    a7d8:      	str	x16, [sp, #0x38]
    a7dc:      	mov	x20, #0x1b              ; =27
    a7e0:      	add	x0, x0, #0x1
    a7e4:      	cmp	x20, #0x0
    a7e8:      	b.ne	0xa7a8 <_stogir.verify.structure+0x5a8>
    a7ec:      	cmp	x0, x22
    a7f0:      	cset	w1, lt
    a7f4:      	ubfx	x1, x1, #0, #8
    a7f8:      	b	0xa7ac <_stogir.verify.structure+0x5ac>
    a7fc:      	mov	w0, w27
    a800:      	bl	0xa800 <_stogir.verify.structure+0x600>
		000000000000a800:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
    a804:      	sxtw	x0, w0
    a808:      	cmn	x0, #0x1
    a80c:      	b.ne	0xa82c <_stogir.verify.structure+0x62c>
    a810:      	ubfx	x0, x22, #16, #16
    a814:      	cmp	x28, x0
    a818:      	b.eq	0xa82c <_stogir.verify.structure+0x62c>
    a81c:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a81c:  ARM64_RELOC_PAGE21	l_stogir.471
    a820:      	ldr	x16, [x16]
		000000000000a820:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    a824:      	str	x16, [sp, #0x38]
    a828:      	mov	x20, #0x24              ; =36
    a82c:      	add	x0, x28, #0x4
    a830:      	ldr	x1, [x19, #0x8]
    a834:      	asr	x16, x0, #63
    a838:      	lsr	x16, x16, #62
    a83c:      	add	x0, x0, x16
    a840:      	asr	x0, x0, #2
    a844:      	orr	x22, x0, xzr
    a848:      	add	x0, x22, x26
    a84c:      	cmp	x0, x1
    a850:      	b.le	0xa864 <_stogir.verify.structure+0x664>
    a854:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a854:  ARM64_RELOC_PAGE21	l_stogir.472
    a858:      	ldr	x16, [x16]
		000000000000a858:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    a85c:      	str	x16, [sp, #0x38]
    a860:      	mov	x20, #0x15              ; =21
    a864:      	mov	x0, #0x1                ; =1
    a868:      	b	0xa7e4 <_stogir.verify.structure+0x5e4>
    a86c:      	ldr	x0, [x25, #0x8]
    a870:      	cmp	x27, x0
    a874:      	b.gt	0xabdc <_stogir.verify.structure+0x9dc>
    a878:      	sub	x0, x27, #0x1
    a87c:      	ldr	x2, [sp, #0x60]
    a880:      	ldr	x3, [x2, #0x28]
    a884:      	mov	x17, #0x18              ; =24
    a888:      	mul	x0, x0, x17
    a88c:      	add	x0, x0, x3
    a890:      	ldr	x3, [x0]
    a894:      	ldr	x0, [x0, #0x8]
    a898:      	ldr	x4, [x2, #0x8]
    a89c:      	cmp	x3, #0x0
    a8a0:      	b.lt	0xa8c8 <_stogir.verify.structure+0x6c8>
    a8a4:      	cmp	x3, x4
    a8a8:      	b.gt	0xa8c8 <_stogir.verify.structure+0x6c8>
    a8ac:      	cmp	x0, #0x0
    a8b0:      	b.lt	0xa8c8 <_stogir.verify.structure+0x6c8>
    a8b4:      	sub	x3, x4, x3
    a8b8:      	cmp	x0, x3
    a8bc:      	b.gt	0xa8c8 <_stogir.verify.structure+0x6c8>
    a8c0:      	mov	w0, #0x1                ; =1
    a8c4:      	b	0xa8cc <_stogir.verify.structure+0x6cc>
    a8c8:      	movz	w0, #0x0, lsl #16
    a8cc:      	b	0xa6e8 <_stogir.verify.structure+0x4e8>
    a8d0:      	mov	w0, #-0x2               ; =-2
    a8d4:      	sxtw	x0, w0
    a8d8:      	cmp	x28, x0
    a8dc:      	b.eq	0xa7fc <_stogir.verify.structure+0x5fc>
    a8e0:      	ldr	x2, [sp, #0x60]
    a8e4:      	ldr	x0, [sp, #0x58]
    a8e8:      	ldr	x3, [sp, #0x50]
    a8ec:      	ldr	x4, [sp, #0x48]
    a8f0:      	mov	x5, x26
    a8f4:      	ldr	x20, [sp, #0x40]
    a8f8:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a8f8:  ARM64_RELOC_PAGE21	l_stogir.473
    a8fc:      	ldr	x16, [x16]
		000000000000a8fc:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    a900:      	str	x16, [sp, #0x38]
    a904:      	mov	x16, #0x23              ; =35
    a908:      	str	x16, [sp, #0x80]
    a90c:      	b	0xa274 <_stogir.verify.structure+0x74>
    a910:      	cmp	x27, #0x0
    a914:      	b.ne	0xabe4 <_stogir.verify.structure+0x9e4>
    a918:      	uxtb	w16, w23
    a91c:      	cmp	w16, wzr
    a920:      	b.eq	0xaa4c <_stogir.verify.structure+0x84c>
    a924:      	ldr	w1, [x24]
    a928:      	uxtb	w16, w26
    a92c:      	cmp	w16, wzr
    a930:      	b.eq	0xaa94 <_stogir.verify.structure+0x894>
    a934:      	uxtb	w16, w28
    a938:      	cmp	w16, wzr
    a93c:      	b.eq	0xa944 <_stogir.verify.structure+0x744>
    a940:      	mov	w22, #0x4               ; =4
    a944:      	lsl	w5, w22, #2
    a948:      	ubfx	x5, x5, #0, #32
    a94c:      	lsr	x1, x1, x5
    a950:      	and	w1, w1, #0xf
    a954:      	b	0xaa98 <_stogir.verify.structure+0x898>
    a958:      	cmp	x27, #0x0
    a95c:      	b.le	0xabf0 <_stogir.verify.structure+0x9f0>
    a960:      	ldr	x0, [x19, #0x8]
    a964:      	cmp	x27, x0
    a968:      	b.ge	0xabf8 <_stogir.verify.structure+0x9f8>
    a96c:      	ldr	x0, [sp, #0x58]
    a970:      	ldr	x1, [x0, #0x8]
    a974:      	cmp	x27, x1
    a978:      	b.ge	0xaaa4 <_stogir.verify.structure+0x8a4>
    a97c:      	ldr	x1, [x19, #0x78]
    a980:      	add	x1, x1, x27, lsl #2
    a984:      	ldr	w1, [x1]
    a988:      	sxtw	x1, w1
    a98c:      	cmp	x1, #0x0
    a990:      	cset	w1, ge
    a994:      	ubfx	x1, x1, #0, #8
    a998:      	b	0xaaa8 <_stogir.verify.structure+0x8a8>
    a99c:      	ldr	w1, [sp, #0xb0]
    a9a0:      	uxtb	w16, w1
    a9a4:      	cmp	w16, wzr
    a9a8:      	b.eq	0xac00 <_stogir.verify.structure+0xa00>
    a9ac:      	ldr	w5, [sp, #0xa8]
    a9b0:      	uxtb	w16, w5
    a9b4:      	cmp	w16, wzr
    a9b8:      	b.eq	0xa9c8 <_stogir.verify.structure+0x7c8>
    a9bc:      	ldr	x6, [sp, #0xa0]
    a9c0:      	cmp	x6, #0x2
    a9c4:      	b.eq	0xa4bc <_stogir.verify.structure+0x2bc>
    a9c8:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000a9c8:  ARM64_RELOC_PAGE21	l_stogir.474
    a9cc:      	ldr	x16, [x16]
		000000000000a9cc:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    a9d0:      	str	x16, [sp, #0x38]
    a9d4:      	mov	x16, #0x1a              ; =26
    a9d8:      	str	x16, [sp, #0x80]
    a9dc:      	b	0xa4bc <_stogir.verify.structure+0x2bc>
    a9e0:      	movz	x1, #0x0, lsl #48
    a9e4:      	ldr	x3, [sp, #0x50]
    a9e8:      	ldr	x4, [sp, #0x48]
    a9ec:      	b	0xa4ac <_stogir.verify.structure+0x2ac>
    a9f0:      	cmp	x27, #0x0
    a9f4:      	b.ge	0xac08 <_stogir.verify.structure+0xa08>
    a9f8:      	ldr	x3, [sp, #0x50]
    a9fc:      	ldr	x1, [x3, #0x8]
    aa00:      	ldr	x4, [sp, #0x48]
    aa04:      	ldr	x5, [x4, #0x8]
    aa08:      	cmp	x1, x5
    aa0c:      	b.ne	0xaa9c <_stogir.verify.structure+0x89c>
    aa10:      	movz	x16, #0x0, lsl #48
    aa14:      	sub	x5, x16, x27
    aa18:      	cmp	x5, x1
    aa1c:      	b.gt	0xaacc <_stogir.verify.structure+0x8cc>
    aa20:      	sub	x1, x5, #0x1
    aa24:      	ldr	x5, [x19, #0x50]
    aa28:      	add	x1, x5, x1, lsl #2
    aa2c:      	ldr	w1, [x1]
    aa30:      	sxtw	x1, w1
    aa34:      	cmp	x1, #0x0
    aa38:      	cset	w1, gt
    aa3c:      	ubfx	x1, x1, #0, #8
    aa40:      	b	0xaad0 <_stogir.verify.structure+0x8d0>
    aa44:      	brk	#0
    aa48:      	b	0xaa44 <_stogir.verify.structure+0x844>
    aa4c:      	movz	w1, #0x0, lsl #16
    aa50:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000aa50:  ARM64_RELOC_PAGE21	l_stogir.475
    aa54:      	ldr	x16, [x16]
		000000000000aa54:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    aa58:      	ldr	w5, [x16]
    aa5c:      	ubfx	x1, x1, #0, #32
    aa60:      	cmp	x1, x5
    aa64:      	b.ne	0xaa74 <_stogir.verify.structure+0x874>
    aa68:      	ldr	w1, [sp, #0xb0]
    aa6c:      	ldr	w5, [sp, #0xa8]
    aa70:      	b	0xa4bc <_stogir.verify.structure+0x2bc>
    aa74:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000aa74:  ARM64_RELOC_PAGE21	l_stogir.476
    aa78:      	ldr	x16, [x16]
		000000000000aa78:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    aa7c:      	ldr	w5, [x16]
    aa80:      	cmp	x1, x5
    aa84:      	b.ne	0xaaac <_stogir.verify.structure+0x8ac>
    aa88:      	ldr	w1, [sp, #0xb0]
    aa8c:      	ldr	w5, [sp, #0xa8]
    aa90:      	b	0xa4bc <_stogir.verify.structure+0x2bc>
    aa94:      	movz	w1, #0x0, lsl #16
    aa98:      	b	0xaa50 <_stogir.verify.structure+0x850>
    aa9c:      	movz	x1, #0x0, lsl #48
    aaa0:      	b	0xa4ac <_stogir.verify.structure+0x2ac>
    aaa4:      	movz	x1, #0x0, lsl #48
    aaa8:      	b	0xa9e4 <_stogir.verify.structure+0x7e4>
    aaac:      	adrp	x16, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000aaac:  ARM64_RELOC_PAGE21	l_stogir.477
    aab0:      	ldr	x16, [x16]
		000000000000aab0:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    aab4:      	ldr	w5, [x16]
    aab8:      	cmp	x1, x5
    aabc:      	b.ne	0xa99c <_stogir.verify.structure+0x79c>
    aac0:      	ldr	w1, [sp, #0xb0]
    aac4:      	ldr	w5, [sp, #0xa8]
    aac8:      	b	0xa4bc <_stogir.verify.structure+0x2bc>
    aacc:      	movz	x1, #0x0, lsl #48
    aad0:      	b	0xaaa0 <_stogir.verify.structure+0x8a0>
    aad4:      	brk	#0
    aad8:      	b	0xaad4 <_stogir.verify.structure+0x8d4>
    aadc:      	str	x8, [sp, #0x30]
    aae0:      	str	x19, [sp, #0x38]
    aae4:      	str	x20, [sp, #0x80]
    aae8:      	mov	x20, x27
    aaec:      	b	0xa40c <_stogir.verify.structure+0x20c>
    aaf0:      	str	x8, [sp, #0x30]
    aaf4:      	str	x19, [sp, #0x38]
    aaf8:      	str	x20, [sp, #0x80]
    aafc:      	mov	x20, x27
    ab00:      	b	0xa40c <_stogir.verify.structure+0x20c>
    ab04:      	mov	x5, x26
    ab08:      	mov	x20, x27
    ab0c:      	str	x8, [sp, #0x30]
    ab10:      	mov	x19, x0
    ab14:      	mov	x2, x21
    ab18:      	mov	x0, x22
    ab1c:      	mov	x3, x23
    ab20:      	mov	x4, x24
    ab24:      	b	0xa2e0 <_stogir.verify.structure+0xe0>
    ab28:      	mov	x5, x26
    ab2c:      	mov	x20, x27
    ab30:      	str	x8, [sp, #0x30]
    ab34:      	mov	x19, x0
    ab38:      	mov	x2, x21
    ab3c:      	mov	x0, x22
    ab40:      	mov	x3, x23
    ab44:      	mov	x4, x24
    ab48:      	b	0xa2a4 <_stogir.verify.structure+0xa4>
    ab4c:      	mov	x5, x26
    ab50:      	ldr	x20, [sp, #0x40]
    ab54:      	ldr	x2, [sp, #0x60]
    ab58:      	ldr	x0, [sp, #0x58]
    ab5c:      	ldr	x3, [sp, #0x50]
    ab60:      	ldr	x4, [sp, #0x48]
    ab64:      	b	0xa2a4 <_stogir.verify.structure+0xa4>
    ab68:      	ldr	x0, [sp, #0x38]
    ab6c:      	b	0xa440 <_stogir.verify.structure+0x240>
    ab70:      	str	x26, [sp, #0x90]
    ab74:      	str	x22, [sp, #0x88]
    ab78:      	ldr	x2, [sp, #0x60]
    ab7c:      	str	x20, [sp, #0x80]
    ab80:      	ldr	x0, [sp, #0x58]
    ab84:      	ldr	x3, [sp, #0x50]
    ab88:      	ldr	x4, [sp, #0x48]
    ab8c:      	b	0xa25c <_stogir.verify.structure+0x5c>
    ab90:      	str	w27, [sp, #0xb0]
    ab94:      	mov	w27, w1
    ab98:      	str	w21, [sp, #0xa8]
    ab9c:      	mov	x21, x0
    aba0:      	b	0xa640 <_stogir.verify.structure+0x440>
    aba4:      	ldr	x2, [sp, #0x60]
    aba8:      	b	0xa72c <_stogir.verify.structure+0x52c>
    abac:      	ldr	x0, [sp, #0x58]
    abb0:      	ldr	x3, [sp, #0x50]
    abb4:      	ldr	x4, [sp, #0x48]
    abb8:      	ldr	w1, [sp, #0xb0]
    abbc:      	ldr	w5, [sp, #0xa8]
    abc0:      	b	0xa4bc <_stogir.verify.structure+0x2bc>
    abc4:      	ldr	x0, [sp, #0x58]
    abc8:      	ldr	x3, [sp, #0x50]
    abcc:      	ldr	x4, [sp, #0x48]
    abd0:      	ldr	w1, [sp, #0xb0]
    abd4:      	ldr	w5, [sp, #0xa8]
    abd8:      	b	0xa4bc <_stogir.verify.structure+0x2bc>
    abdc:      	ldr	x2, [sp, #0x60]
    abe0:      	b	0xa6e4 <_stogir.verify.structure+0x4e4>
    abe4:      	ldr	w1, [sp, #0xb0]
    abe8:      	ldr	w5, [sp, #0xa8]
    abec:      	b	0xa9c8 <_stogir.verify.structure+0x7c8>
    abf0:      	ldr	x0, [sp, #0x58]
    abf4:      	b	0xa9f0 <_stogir.verify.structure+0x7f0>
    abf8:      	ldr	x0, [sp, #0x58]
    abfc:      	b	0xa9e0 <_stogir.verify.structure+0x7e0>
    ac00:      	ldr	w5, [sp, #0xa8]
    ac04:      	b	0xa9c8 <_stogir.verify.structure+0x7c8>
    ac08:      	ldr	x3, [sp, #0x50]
    ac0c:      	ldr	x4, [sp, #0x48]
    ac10:      	b	0xa4a8 <_stogir.verify.structure+0x2a8>
    ac14:      	udf	#0x0

000000000000ac18 <_stogir.verify.schedule-input-structured>:
    ac18:      	sub	sp, sp, #0x40
    ac1c:      	str	x29, [sp]
    ac20:      	str	x30, [sp, #0x8]
    ac24:      	mov	x29, sp
    ac28:      	str	x19, [sp, #0x30]
    ac2c:      	sxtw	x1, w1
    ac30:      	cmp	x1, #0x0
    ac34:      	cset	w4, gt
    ac38:      	movz	x16, #0x0, lsl #48
    ac3c:      	sub	x5, x16, x1
    ac40:      	sub	x6, x5, #0x1
    ac44:      	uxtb	w16, w4
    ac48:      	cmp	w16, wzr
    ac4c:      	b.eq	0xac8c <_stogir.verify.schedule-input-structured+0x74>
    ac50:      	ldr	x5, [x0, #0x8]
    ac54:      	cmp	x1, x5
    ac58:      	b.ge	0xacdc <_stogir.verify.schedule-input-structured+0xc4>
    ac5c:      	add	x5, x0, #0x78
    ac60:      	ldr	x5, [x5, #0x8]
    ac64:      	cmp	x1, x5
    ac68:      	b.ge	0xaebc <_stogir.verify.schedule-input-structured+0x2a4>
    ac6c:      	ldr	x5, [x0, #0x78]
    ac70:      	add	x5, x5, x1, lsl #2
    ac74:      	ldr	w5, [x5]
    ac78:      	sxtw	x5, w5
    ac7c:      	cmp	x5, #0x0
    ac80:      	cset	w5, ge
    ac84:      	ubfx	x5, x5, #0, #8
    ac88:      	b	0xaec0 <_stogir.verify.schedule-input-structured+0x2a8>
    ac8c:      	cmp	x1, #0x0
    ac90:      	b.ge	0xace4 <_stogir.verify.schedule-input-structured+0xcc>
    ac94:      	add	x7, x0, #0x28
    ac98:      	add	x9, x0, #0x50
    ac9c:      	ldr	x7, [x7, #0x8]
    aca0:      	ldr	x9, [x9, #0x8]
    aca4:      	cmp	x7, x9
    aca8:      	b.ne	0xacd4 <_stogir.verify.schedule-input-structured+0xbc>
    acac:      	cmp	x5, x7
    acb0:      	b.gt	0xaec4 <_stogir.verify.schedule-input-structured+0x2ac>
    acb4:      	ldr	x5, [x0, #0x50]
    acb8:      	add	x5, x5, x6, lsl #2
    acbc:      	ldr	w5, [x5]
    acc0:      	sxtw	x5, w5
    acc4:      	cmp	x5, #0x0
    acc8:      	cset	w5, gt
    accc:      	ubfx	x5, x5, #0, #8
    acd0:      	b	0xaec8 <_stogir.verify.schedule-input-structured+0x2b0>
    acd4:      	movz	x5, #0x0, lsl #48
    acd8:      	b	0xace8 <_stogir.verify.schedule-input-structured+0xd0>
    acdc:      	movz	x5, #0x0, lsl #48
    ace0:      	b	0xace8 <_stogir.verify.schedule-input-structured+0xd0>
    ace4:      	movz	x5, #0x0, lsl #48
    ace8:      	cmp	x5, #0x0
    acec:      	b.eq	0xad20 <_stogir.verify.schedule-input-structured+0x108>
    acf0:      	uxtb	w16, w4
    acf4:      	cmp	w16, wzr
    acf8:      	b.eq	0xad0c <_stogir.verify.schedule-input-structured+0xf4>
    acfc:      	ldr	x4, [x0]
    ad00:      	add	x4, x4, x1, lsl #4
    ad04:      	ldr	x4, [x4]
    ad08:      	b	0xad18 <_stogir.verify.schedule-input-structured+0x100>
    ad0c:      	ldr	x4, [x0, #0x28]
    ad10:      	add	x4, x4, x6, lsl #4
    ad14:      	ldr	x4, [x4]
    ad18:      	mov	w5, #0x1                ; =1
    ad1c:      	b	0xad28 <_stogir.verify.schedule-input-structured+0x110>
    ad20:      	movz	w5, #0x0, lsl #16
    ad24:      	movz	x4, #0x0, lsl #48
    ad28:      	ubfx	x5, x5, #0, #32
    ad2c:      	lsr	x16, x5, #0
    ad30:      	cmp	x16, #0x1
    ad34:      	b.eq	0xad50 <_stogir.verify.schedule-input-structured+0x138>
    ad38:      	b.lo	0xad40 <_stogir.verify.schedule-input-structured+0x128>
    ad3c:      	b	0xad54 <_stogir.verify.schedule-input-structured+0x13c>
    ad40:      	cmp	x16, #0x0
    ad44:      	b.eq	0xad4c <_stogir.verify.schedule-input-structured+0x134>
    ad48:      	b	0xad54 <_stogir.verify.schedule-input-structured+0x13c>
    ad4c:      	b	0xad58 <_stogir.verify.schedule-input-structured+0x140>
    ad50:      	b	0xae94 <_stogir.verify.schedule-input-structured+0x27c>
    ad54:      	b	0xaf14 <_stogir.verify.schedule-input-structured+0x2fc>
    ad58:      	adrp	x1, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000ad58:  ARM64_RELOC_PAGE21	l_stogir.478
    ad5c:      	ldr	x1, [x1]
		000000000000ad5c:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    ad60:      	mov	x4, #0xd                ; =13
    ad64:      	b	0xad74 <_stogir.verify.schedule-input-structured+0x15c>
    ad68:      	adrp	x1, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000ad68:  ARM64_RELOC_PAGE21	l_stogir.479
    ad6c:      	ldr	x1, [x1]
		000000000000ad6c:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    ad70:      	mov	x4, #0x1b               ; =27
    ad74:      	cmp	x3, #0x0
    ad78:      	b.ne	0xad88 <_stogir.verify.schedule-input-structured+0x170>
    ad7c:      	adrp	x1, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000ad7c:  ARM64_RELOC_PAGE21	l_stogir.480
    ad80:      	ldr	x1, [x1]
		000000000000ad80:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    ad84:      	mov	x4, #0x25               ; =37
    ad88:      	add	x5, x0, #0x78
    ad8c:      	movz	x6, #0x0, lsl #48
    ad90:      	b	0xae18 <_stogir.verify.schedule-input-structured+0x200>
    ad94:      	nop
    ad98:      	movz	w7, #0x0, lsl #16
    ad9c:      	movz	w9, #0x0, lsl #16
    ada0:      	ubfx	x7, x7, #0, #32
    ada4:      	lsr	x16, x7, #0
    ada8:      	cmp	x16, #0x1
    adac:      	b.eq	0xadc8 <_stogir.verify.schedule-input-structured+0x1b0>
    adb0:      	b.lo	0xadb8 <_stogir.verify.schedule-input-structured+0x1a0>
    adb4:      	b	0xadcc <_stogir.verify.schedule-input-structured+0x1b4>
    adb8:      	cmp	x16, #0x0
    adbc:      	b.eq	0xadc4 <_stogir.verify.schedule-input-structured+0x1ac>
    adc0:      	b	0xadcc <_stogir.verify.schedule-input-structured+0x1b4>
    adc4:      	b	0xae40 <_stogir.verify.schedule-input-structured+0x228>
    adc8:      	b	0xadd0 <_stogir.verify.schedule-input-structured+0x1b8>
    adcc:      	b	0xaf0c <_stogir.verify.schedule-input-structured+0x2f4>
    add0:      	sxtw	x9, w9
    add4:      	cmp	x9, #0x0
    add8:      	b.le	0xae0c <_stogir.verify.schedule-input-structured+0x1f4>
    addc:      	ldr	x7, [x0, #0x8]
    ade0:      	cmp	x9, x7
    ade4:      	b.ge	0xae0c <_stogir.verify.schedule-input-structured+0x1f4>
    ade8:      	ldr	x7, [x5, #0x8]
    adec:      	cmp	x9, x7
    adf0:      	b.ge	0xae0c <_stogir.verify.schedule-input-structured+0x1f4>
    adf4:      	ldr	x7, [x0, #0x78]
    adf8:      	add	x7, x7, x9, lsl #2
    adfc:      	ldr	w7, [x7]
    ae00:      	sxtw	x7, w7
    ae04:      	cmp	x7, #0x0
    ae08:      	b.ge	0xae18 <_stogir.verify.schedule-input-structured+0x200>
    ae0c:      	adrp	x1, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000ae0c:  ARM64_RELOC_PAGE21	l_stogir.481
    ae10:      	ldr	x1, [x1]
		000000000000ae10:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    ae14:      	mov	x4, #0x16               ; =22
    ae18:      	cmp	x6, x3
    ae1c:      	b.ge	0xad98 <_stogir.verify.schedule-input-structured+0x180>
    ae20:      	add	x7, x6, #0x1
    ae24:      	add	x6, x2, x6, lsl #2
    ae28:      	ldr	w6, [x6]
    ae2c:      	movn	w17, #0x0, lsl #16
    ae30:      	and	w9, w6, w17
    ae34:      	mov	x6, x7
    ae38:      	mov	w7, #0x1                ; =1
    ae3c:      	b	0xada0 <_stogir.verify.schedule-input-structured+0x188>
    ae40:      	cmp	x4, #0x0
    ae44:      	b.ne	0xaf1c <_stogir.verify.schedule-input-structured+0x304>
    ae48:      	mov	x19, x8
    ae4c:      	add	x8, sp, #0x10
    ae50:      	bl	0xae50 <_stogir.verify.schedule-input-structured+0x238>
		000000000000ae50:  ARM64_RELOC_BRANCH26	_stogir.verify.phis-structured
    ae54:      	add	x16, sp, #0x10
    ae58:      	ldr	x0, [x16]
    ae5c:      	add	x16, sp, #0x10
    ae60:      	ldr	x1, [x16, #0x8]
    ae64:      	add	x16, sp, #0x10
    ae68:      	ldr	x4, [x16, #0x10]
    ae6c:      	b	0xae74 <_stogir.verify.schedule-input-structured+0x25c>
    ae70:      	mov	x0, #0x1                ; =1
    ae74:      	str	x0, [x19]
    ae78:      	str	x1, [x19, #0x8]
    ae7c:      	str	x4, [x19, #0x10]
    ae80:      	ldr	x19, [sp, #0x30]
    ae84:      	ldr	x29, [sp]
    ae88:      	ldr	x30, [sp, #0x8]
    ae8c:      	add	sp, sp, #0x40
    ae90:      	ret
    ae94:      	cmp	x1, #0x0
    ae98:      	b.le	0xad68 <_stogir.verify.schedule-input-structured+0x150>
    ae9c:      	uxtb	w4, w4
    aea0:      	cmp	x4, #0x83
    aea4:      	b.ge	0xaecc <_stogir.verify.schedule-input-structured+0x2b4>
    aea8:      	adrp	x17, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000aea8:  ARM64_RELOC_PAGE21	l_stogir.482
    aeac:      	ldr	x17, [x17]
		000000000000aeac:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    aeb0:      	add	x1, x4, x17
    aeb4:      	ldrb	w1, [x1]
    aeb8:      	b	0xaed0 <_stogir.verify.schedule-input-structured+0x2b8>
    aebc:      	movz	x5, #0x0, lsl #48
    aec0:      	b	0xace0 <_stogir.verify.schedule-input-structured+0xc8>
    aec4:      	movz	x5, #0x0, lsl #48
    aec8:      	b	0xacd8 <_stogir.verify.schedule-input-structured+0xc0>
    aecc:      	movz	w1, #0x0, lsl #16
    aed0:      	uxtb	w16, w1
    aed4:      	and	w1, w16, #0x2
    aed8:      	uxtb	w1, w1
    aedc:      	ubfx	x1, x1, #0, #8
    aee0:      	cmp	x1, #0x0
    aee4:      	cset	w1, eq
    aee8:      	uxtb	w16, w1
    aeec:      	cmp	w16, wzr
    aef0:      	cset	x1, eq
    aef4:      	cmp	x1, #0x0
    aef8:      	b.eq	0xad68 <_stogir.verify.schedule-input-structured+0x150>
    aefc:      	adrp	x1, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000aefc:  ARM64_RELOC_PAGE21	l_stogir.483
    af00:      	ldr	x1, [x1]
		000000000000af00:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    af04:      	movz	x4, #0x0, lsl #48
    af08:      	b	0xad74 <_stogir.verify.schedule-input-structured+0x15c>
    af0c:      	brk	#0
    af10:      	b	0xaf0c <_stogir.verify.schedule-input-structured+0x2f4>
    af14:      	brk	#0
    af18:      	b	0xaf14 <_stogir.verify.schedule-input-structured+0x2fc>
    af1c:      	mov	x19, x8
    af20:      	b	0xae70 <_stogir.verify.schedule-input-structured+0x258>

000000000000af24 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
    af24:      	ldr	x0, [x0, #0x8]
    af28:      	ret

000000000000af2c <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    af2c:      	ldr	x0, [x0, #0x8]
    af30:      	ret

000000000000af34 <_stogir.verify.control-sources>:
    af34:      	sub	sp, sp, #0x40
    af38:      	str	x29, [sp]
    af3c:      	str	x30, [sp, #0x8]
    af40:      	mov	x29, sp
    af44:      	str	x19, [sp, #0x30]
    af48:      	str	x20, [sp, #0x38]
    af4c:      	mov	x19, x8
    af50:      	add	x8, sp, #0x10
    af54:      	mov	x20, x0
    af58:      	bl	0xaf58 <_stogir.verify.control-sources+0x24>
		000000000000af58:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    af5c:      	add	x16, sp, #0x10
    af60:      	ldr	w0, [x16]
    af64:      	lsr	x16, x0, #0
    af68:      	cmp	x16, #0x1
    af6c:      	b.eq	0xaf88 <_stogir.verify.control-sources+0x54>
    af70:      	b.lo	0xaf78 <_stogir.verify.control-sources+0x44>
    af74:      	b	0xaf8c <_stogir.verify.control-sources+0x58>
    af78:      	cmp	x16, #0x0
    af7c:      	b.eq	0xaf84 <_stogir.verify.control-sources+0x50>
    af80:      	b	0xaf8c <_stogir.verify.control-sources+0x58>
    af84:      	b	0xafd8 <_stogir.verify.control-sources+0xa4>
    af88:      	b	0xaf90 <_stogir.verify.control-sources+0x5c>
    af8c:      	b	0xb394 <_stogir.verify.control-sources+0x460>
    af90:      	add	x16, sp, #0x10
    af94:      	orr	x0, x16, xzr
    af98:      	add	x0, x0, #0x8
    af9c:      	add	x16, sp, #0x10
    afa0:      	ldr	x1, [x16, #0x8]
    afa4:      	ldr	x0, [x0, #0x8]
    afa8:      	mov	x2, #0x1                ; =1
    afac:      	b	0xafb4 <_stogir.verify.control-sources+0x80>
    afb0:      	mov	x2, #0x1                ; =1
    afb4:      	str	x2, [x19]
    afb8:      	str	x1, [x19, #0x8]
    afbc:      	str	x0, [x19, #0x10]
    afc0:      	ldr	x19, [sp, #0x30]
    afc4:      	ldr	x20, [sp, #0x38]
    afc8:      	ldr	x29, [sp]
    afcc:      	ldr	x30, [sp, #0x8]
    afd0:      	add	sp, sp, #0x40
    afd4:      	ret
    afd8:      	add	x2, x20, #0x78
    afdc:      	add	x3, x20, #0x78
    afe0:      	mov	x4, #0x1                ; =1
    afe4:      	movz	x5, #0x0, lsl #48
    afe8:      	adrp	x1, 0xa000 <_stogir.adjacency.release!+0xd0>
		000000000000afe8:  ARM64_RELOC_PAGE21	l_stogir.484
    afec:      	ldr	x1, [x1]
		000000000000afec:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    aff0:      	movz	x0, #0x0, lsl #48
    aff4:      	b	0xb264 <_stogir.verify.control-sources+0x330>
    aff8:      	movz	w13, #0x0, lsl #16
    affc:      	uxtb	w16, w13
    b000:      	and	w13, w16, #0x1
    b004:      	uxtb	w13, w13
    b008:      	ubfx	x13, x13, #0, #8
    b00c:      	cmp	x13, #0x0
    b010:      	b.ne	0xb020 <_stogir.verify.control-sources+0xec>
    b014:      	adrp	x1, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b014:  ARM64_RELOC_PAGE21	l_stogir.485
    b018:      	ldr	x1, [x1]
		000000000000b018:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    b01c:      	mov	x0, #0x1d               ; =29
    b020:      	b	0xb1cc <_stogir.verify.control-sources+0x298>
    b024:      	movz	x6, #0x0, lsl #48
    b028:      	cmp	x6, #0x0
    b02c:      	b.eq	0xb36c <_stogir.verify.control-sources+0x438>
    b030:      	orr	w6, w4, wzr
    b034:      	ldr	x7, [x20]
    b038:      	sxtw	x6, w6
    b03c:      	cmp	x6, #0x0
    b040:      	cset	w8, le
    b044:      	lsl	x9, x6, #2
    b048:      	add	x7, x7, x4, lsl #4
    b04c:      	ldr	x7, [x7]
    b050:      	ldr	x10, [x20, #0x78]
    b054:      	uxtb	w7, w7
    b058:      	add	x10, x10, x4, lsl #2
    b05c:      	cmp	x7, #0x83
    b060:      	cset	w11, lt
    b064:      	adrp	x16, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b064:  ARM64_RELOC_PAGE21	l_stogir.486
    b068:      	ldr	x16, [x16]
		000000000000b068:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    b06c:      	add	x7, x16, x7, lsl #2
    b070:      	ldr	w10, [x10]
    b074:      	sxtw	x10, w10
    b078:      	mov	x12, #0x1               ; =1
    b07c:      	b	0xb0f8 <_stogir.verify.control-sources+0x1c4>
    b080:      	movz	w14, #0x0, lsl #16
    b084:      	movz	w13, #0x0, lsl #16
    b088:      	b	0xb0ac <_stogir.verify.control-sources+0x178>
    b08c:      	sub	w13, w13, #0x1
    b090:      	lsl	w13, w13, #2
    b094:      	ubfx	x13, x13, #0, #32
    b098:      	lsr	x13, x15, x13
    b09c:      	and	w13, w13, #0xf
    b0a0:      	b	0xb150 <_stogir.verify.control-sources+0x21c>
    b0a4:      	movz	w14, #0x0, lsl #16
    b0a8:      	movz	w13, #0x0, lsl #16
    b0ac:      	ubfx	x14, x14, #0, #32
    b0b0:      	lsr	x16, x14, #0
    b0b4:      	cmp	x16, #0x1
    b0b8:      	b.eq	0xb0d4 <_stogir.verify.control-sources+0x1a0>
    b0bc:      	b.lo	0xb0c4 <_stogir.verify.control-sources+0x190>
    b0c0:      	b	0xb0d8 <_stogir.verify.control-sources+0x1a4>
    b0c4:      	cmp	x16, #0x0
    b0c8:      	b.eq	0xb0d0 <_stogir.verify.control-sources+0x19c>
    b0cc:      	b	0xb0d8 <_stogir.verify.control-sources+0x1a4>
    b0d0:      	b	0xb0dc <_stogir.verify.control-sources+0x1a8>
    b0d4:      	b	0xb1b4 <_stogir.verify.control-sources+0x280>
    b0d8:      	b	0xb384 <_stogir.verify.control-sources+0x450>
    b0dc:      	adrp	x1, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b0dc:  ARM64_RELOC_PAGE21	l_stogir.487
    b0e0:      	ldr	x1, [x1]
		000000000000b0e0:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b0e4:      	mov	x0, #0x16               ; =22
    b0e8:      	add	x5, x5, #0x1
    b0ec:      	sxtw	x5, w5
    b0f0:      	add	x12, x12, #0x1
    b0f4:      	sxtw	x12, w12
    b0f8:      	cmp	x0, #0x0
    b0fc:      	b.ne	0xb110 <_stogir.verify.control-sources+0x1dc>
    b100:      	cmp	x12, x10
    b104:      	cset	w13, le
    b108:      	ubfx	x13, x13, #0, #8
    b10c:      	b	0xb114 <_stogir.verify.control-sources+0x1e0>
    b110:      	movz	x13, #0x0, lsl #48
    b114:      	cmp	x13, #0x0
    b118:      	b.eq	0xb24c <_stogir.verify.control-sources+0x318>
    b11c:      	orr	w13, w12, wzr
    b120:      	sxtw	x14, w13
    b124:      	uxtb	w16, w11
    b128:      	cmp	w16, wzr
    b12c:      	b.eq	0xb154 <_stogir.verify.control-sources+0x220>
    b130:      	ldr	w15, [x7]
    b134:      	cmp	x14, #0x0
    b138:      	b.le	0xb14c <_stogir.verify.control-sources+0x218>
    b13c:      	cmp	x14, #0x4
    b140:      	b.le	0xb08c <_stogir.verify.control-sources+0x158>
    b144:      	mov	w13, #0x4               ; =4
    b148:      	b	0xb090 <_stogir.verify.control-sources+0x15c>
    b14c:      	movz	w13, #0x0, lsl #16
    b150:      	b	0xb158 <_stogir.verify.control-sources+0x224>
    b154:      	movz	w13, #0x0, lsl #16
    b158:      	adrp	x16, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b158:  ARM64_RELOC_PAGE21	l_stogir.488
    b15c:      	ldr	x16, [x16]
		000000000000b15c:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    b160:      	ldr	w15, [x16]
    b164:      	ubfx	x13, x13, #0, #32
    b168:      	cmp	x13, x15
    b16c:      	b.ne	0xb0f0 <_stogir.verify.control-sources+0x1bc>
    b170:      	uxtb	w16, w8
    b174:      	cmp	w16, wzr
    b178:      	b.ne	0xb0a4 <_stogir.verify.control-sources+0x170>
    b17c:      	ldr	x13, [x20, #0x8]
    b180:      	cmp	x6, x13
    b184:      	b.ge	0xb1d8 <_stogir.verify.control-sources+0x2a4>
    b188:      	ldr	x13, [x2, #0x8]
    b18c:      	cmp	x6, x13
    b190:      	b.ge	0xb1d0 <_stogir.verify.control-sources+0x29c>
    b194:      	ldr	x13, [x20, #0x78]
    b198:      	add	x13, x9, x13
    b19c:      	ldr	w13, [x13]
    b1a0:      	sxtw	x13, w13
    b1a4:      	cmp	x13, #0x0
    b1a8:      	cset	w13, ge
    b1ac:      	ubfx	x13, x13, #0, #8
    b1b0:      	b	0xb1d4 <_stogir.verify.control-sources+0x2a0>
    b1b4:      	sxtw	x13, w13
    b1b8:      	cmp	x13, #0x0
    b1bc:      	b.gt	0xb280 <_stogir.verify.control-sources+0x34c>
    b1c0:      	adrp	x1, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b1c0:  ARM64_RELOC_PAGE21	l_stogir.489
    b1c4:      	ldr	x1, [x1]
		000000000000b1c4:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    b1c8:      	mov	x0, #0x25               ; =37
    b1cc:      	b	0xb0e8 <_stogir.verify.control-sources+0x1b4>
    b1d0:      	movz	x13, #0x0, lsl #48
    b1d4:      	b	0xb1dc <_stogir.verify.control-sources+0x2a8>
    b1d8:      	movz	x13, #0x0, lsl #48
    b1dc:      	cmp	x13, #0x0
    b1e0:      	b.eq	0xb0a4 <_stogir.verify.control-sources+0x170>
    b1e4:      	cmp	x14, #0x1
    b1e8:      	b.lt	0xb080 <_stogir.verify.control-sources+0x14c>
    b1ec:      	ldr	x13, [x20, #0x78]
    b1f0:      	add	x13, x9, x13
    b1f4:      	ldr	w13, [x13]
    b1f8:      	sxtw	x13, w13
    b1fc:      	cmp	x14, x13
    b200:      	b.gt	0xb080 <_stogir.verify.control-sources+0x14c>
    b204:      	ldr	x13, [x20]
    b208:      	asr	x16, x14, #63
    b20c:      	lsr	x16, x16, #62
    b210:      	add	x15, x14, x16
    b214:      	asr	x15, x15, #2
    b218:      	asr	x16, x14, #63
    b21c:      	lsr	x16, x16, #62
    b220:      	add	x14, x14, x16
    b224:      	and	x14, x14, #0x3
    b228:      	sub	x14, x14, x16
    b22c:      	add	x15, x15, x6
    b230:      	add	x13, x13, x15, lsl #4
    b234:      	add	x13, x13, x14, lsl #2
    b238:      	ldr	w13, [x13]
    b23c:      	movn	w17, #0x0, lsl #16
    b240:      	and	w13, w13, w17
    b244:      	mov	w14, #0x1               ; =1
    b248:      	b	0xb088 <_stogir.verify.control-sources+0x154>
    b24c:      	add	x6, x10, #0x4
    b250:      	asr	x16, x6, #63
    b254:      	lsr	x16, x16, #62
    b258:      	add	x6, x6, x16
    b25c:      	asr	x6, x6, #2
    b260:      	add	x4, x6, x4
    b264:      	cmp	x0, #0x0
    b268:      	b.ne	0xb024 <_stogir.verify.control-sources+0xf0>
    b26c:      	ldr	x6, [x20, #0x8]
    b270:      	cmp	x4, x6
    b274:      	cset	w6, lt
    b278:      	ubfx	x6, x6, #0, #8
    b27c:      	b	0xb028 <_stogir.verify.control-sources+0xf4>
    b280:      	ldr	x14, [x20, #0x8]
    b284:      	cmp	x13, x14
    b288:      	b.ge	0xb2c0 <_stogir.verify.control-sources+0x38c>
    b28c:      	ldr	x14, [x3, #0x8]
    b290:      	cmp	x13, x14
    b294:      	b.ge	0xb2b8 <_stogir.verify.control-sources+0x384>
    b298:      	ldr	x14, [x20, #0x78]
    b29c:      	add	x14, x14, x13, lsl #2
    b2a0:      	ldr	w14, [x14]
    b2a4:      	sxtw	x14, w14
    b2a8:      	cmp	x14, #0x0
    b2ac:      	cset	w14, ge
    b2b0:      	ubfx	x14, x14, #0, #8
    b2b4:      	b	0xb2bc <_stogir.verify.control-sources+0x388>
    b2b8:      	movz	x14, #0x0, lsl #48
    b2bc:      	b	0xb2c4 <_stogir.verify.control-sources+0x390>
    b2c0:      	movz	x14, #0x0, lsl #48
    b2c4:      	cmp	x14, #0x0
    b2c8:      	b.eq	0xb304 <_stogir.verify.control-sources+0x3d0>
    b2cc:      	cmp	x13, #0x0
    b2d0:      	b.le	0xb2e4 <_stogir.verify.control-sources+0x3b0>
    b2d4:      	ldr	x14, [x20]
    b2d8:      	add	x13, x14, x13, lsl #4
    b2dc:      	ldr	x13, [x13]
    b2e0:      	b	0xb2fc <_stogir.verify.control-sources+0x3c8>
    b2e4:      	movz	x16, #0x0, lsl #48
    b2e8:      	sub	x13, x16, x13
    b2ec:      	ldr	x14, [x20, #0x28]
    b2f0:      	sub	x13, x13, #0x1
    b2f4:      	add	x13, x14, x13, lsl #4
    b2f8:      	ldr	x13, [x13]
    b2fc:      	mov	w14, #0x1               ; =1
    b300:      	b	0xb30c <_stogir.verify.control-sources+0x3d8>
    b304:      	movz	w14, #0x0, lsl #16
    b308:      	movz	x13, #0x0, lsl #48
    b30c:      	ubfx	x14, x14, #0, #32
    b310:      	lsr	x16, x14, #0
    b314:      	cmp	x16, #0x1
    b318:      	b.eq	0xb334 <_stogir.verify.control-sources+0x400>
    b31c:      	b.lo	0xb324 <_stogir.verify.control-sources+0x3f0>
    b320:      	b	0xb338 <_stogir.verify.control-sources+0x404>
    b324:      	cmp	x16, #0x0
    b328:      	b.eq	0xb330 <_stogir.verify.control-sources+0x3fc>
    b32c:      	b	0xb338 <_stogir.verify.control-sources+0x404>
    b330:      	b	0xb33c <_stogir.verify.control-sources+0x408>
    b334:      	b	0xb34c <_stogir.verify.control-sources+0x418>
    b338:      	b	0xb38c <_stogir.verify.control-sources+0x458>
    b33c:      	adrp	x1, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b33c:  ARM64_RELOC_PAGE21	l_stogir.487
    b340:      	ldr	x1, [x1]
		000000000000b340:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b344:      	mov	x0, #0x16               ; =22
    b348:      	b	0xb020 <_stogir.verify.control-sources+0xec>
    b34c:      	uxtb	w13, w13
    b350:      	cmp	x13, #0x83
    b354:      	b.ge	0xaff8 <_stogir.verify.control-sources+0xc4>
    b358:      	adrp	x17, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b358:  ARM64_RELOC_PAGE21	l_stogir.490
    b35c:      	ldr	x17, [x17]
		000000000000b35c:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    b360:      	add	x13, x13, x17
    b364:      	ldrb	w13, [x13]
    b368:      	b	0xaffc <_stogir.verify.control-sources+0xc8>
    b36c:      	cmp	x0, #0x0
    b370:      	b.ne	0xafb0 <_stogir.verify.control-sources+0x7c>
    b374:      	and	x1, x5, #0xffffffff
    b378:      	movz	x2, #0x0, lsl #48
    b37c:      	movz	x0, #0x0, lsl #48
    b380:      	b	0xafb4 <_stogir.verify.control-sources+0x80>
    b384:      	brk	#0
    b388:      	b	0xb384 <_stogir.verify.control-sources+0x450>
    b38c:      	brk	#0
    b390:      	b	0xb38c <_stogir.verify.control-sources+0x458>
    b394:      	brk	#0
    b398:      	b	0xb394 <_stogir.verify.control-sources+0x460>

000000000000b39c <_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge>:
    b39c:      	ldr	x1, [x0]
    b3a0:      	ldr	x0, [x0, #0x8]
    b3a4:      	movz	x17, #0x0, lsl #48
    b3a8:      	str	x17, [x8]
    b3ac:      	movz	x17, #0x0, lsl #48
    b3b0:      	str	x17, [x8, #0x8]
    b3b4:      	movz	x17, #0x0, lsl #48
    b3b8:      	str	x17, [x8, #0x10]
    b3bc:      	str	x1, [x8, #0x18]
    b3c0:      	str	x0, [x8, #0x20]
    b3c4:      	ret

000000000000b3c8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32>:
    b3c8:      	sub	sp, sp, #0x30
    b3cc:      	str	x29, [sp]
    b3d0:      	str	x30, [sp, #0x8]
    b3d4:      	mov	x29, sp
    b3d8:      	str	x19, [sp, #0x10]
    b3dc:      	str	x20, [sp, #0x18]
    b3e0:      	str	x21, [sp, #0x20]
    b3e4:      	str	x22, [sp, #0x28]
    b3e8:      	ldr	x2, [x0, #0x8]
    b3ec:      	orr	x19, x2, xzr
    b3f0:      	ldr	x2, [x0, #0x10]
    b3f4:      	add	x20, x19, x1
    b3f8:      	cmp	x20, x2
    b3fc:      	b.le	0xb478 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0xb0>
    b400:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b404:      	cmp	x2, x17
    b408:      	b.gt	0xb414 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x4c>
    b40c:      	lsl	x2, x2, #1
    b410:      	b	0xb418 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x50>
    b414:      	mov	x2, x20
    b418:      	cmp	x2, x20
    b41c:      	b.gt	0xb424 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x5c>
    b420:      	mov	x2, x20
    b424:      	mov	x21, x0
    b428:      	mov	x22, x1
    b42c:      	mov	x1, x2
    b430:      	bl	0xb430 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x68>
		000000000000b430:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b434:      	lsl	x0, x22, #2
    b438:      	ldr	x1, [x21]
    b43c:      	add	x1, x1, x19, lsl #2
    b440:      	mov	x2, x0
    b444:      	mov	x0, x1
    b448:      	movz	x1, #0x0, lsl #48
    b44c:      	bl	0xb44c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x84>
		000000000000b44c:  ARM64_RELOC_BRANCH26	_memset
    b450:      	str	x20, [x21, #0x8]
    b454:      	mov	x0, x20
    b458:      	ldr	x19, [sp, #0x10]
    b45c:      	ldr	x20, [sp, #0x18]
    b460:      	ldr	x21, [sp, #0x20]
    b464:      	ldr	x22, [sp, #0x28]
    b468:      	ldr	x29, [sp]
    b46c:      	ldr	x30, [sp, #0x8]
    b470:      	add	sp, sp, #0x30
    b474:      	ret
    b478:      	mov	x21, x0
    b47c:      	mov	x22, x1
    b480:      	b	0xb434 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x6c>

000000000000b484 <_stogir.opcode.block-start?>:
    b484:      	sxtw	x0, w0
    b488:      	cmp	x0, #0x0
    b48c:      	b.lt	0xb4ac <_stogir.opcode.block-start?+0x28>
    b490:      	cmp	x0, #0x83
    b494:      	b.ge	0xb4ac <_stogir.opcode.block-start?+0x28>
    b498:      	adrp	x16, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b498:  ARM64_RELOC_PAGE21	l_stogir.491
    b49c:      	ldr	x16, [x16]
		000000000000b49c:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    b4a0:      	add	x0, x16, x0
    b4a4:      	ldrb	w0, [x0]
    b4a8:      	b	0xb4b0 <_stogir.opcode.block-start?+0x2c>
    b4ac:      	movz	w0, #0x0, lsl #16
    b4b0:      	uxtb	w16, w0
    b4b4:      	and	w0, w16, #0x2
    b4b8:      	uxtb	w0, w0
    b4bc:      	ubfx	x0, x0, #0, #8
    b4c0:      	cmp	x0, #0x0
    b4c4:      	cset	w0, eq
    b4c8:      	uxtb	w16, w0
    b4cc:      	cmp	w16, wzr
    b4d0:      	cset	x0, eq
    b4d4:      	ret

000000000000b4d8 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32>:
    b4d8:      	sub	sp, sp, #0x30
    b4dc:      	str	x29, [sp]
    b4e0:      	str	x30, [sp, #0x8]
    b4e4:      	mov	x29, sp
    b4e8:      	str	x19, [sp, #0x10]
    b4ec:      	str	x20, [sp, #0x18]
    b4f0:      	str	x21, [sp, #0x20]
    b4f4:      	ldr	x2, [x0, #0x8]
    b4f8:      	orr	x19, x2, xzr
    b4fc:      	ldr	x2, [x0, #0x10]
    b500:      	cmp	x19, x2
    b504:      	b.lt	0xb518 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x40>
    b508:      	cmp	x2, #0x0
    b50c:      	b.ne	0xb524 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x4c>
    b510:      	mov	x2, #0x2                ; =2
    b514:      	b	0xb528 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x50>
    b518:      	mov	x20, x0
    b51c:      	mov	w21, w1
    b520:      	b	0xb538 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x60>
    b524:      	lsl	x2, x2, #1
    b528:      	mov	x20, x0
    b52c:      	mov	w21, w1
    b530:      	mov	x1, x2
    b534:      	bl	0xb534 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x5c>
		000000000000b534:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b538:      	add	x0, x19, #0x1
    b53c:      	ldr	x1, [x20]
    b540:      	add	x1, x1, x19, lsl #2
    b544:      	str	w21, [x1]
    b548:      	str	x0, [x20, #0x8]
    b54c:      	ldr	x19, [sp, #0x10]
    b550:      	ldr	x20, [sp, #0x18]
    b554:      	ldr	x21, [sp, #0x20]
    b558:      	ldr	x29, [sp]
    b55c:      	ldr	x30, [sp, #0x8]
    b560:      	add	sp, sp, #0x30
    b564:      	ret

000000000000b568 <_coil.core.Set$coil.arraylist.ArrayList$set!__i32>:
    b568:      	ldr	x0, [x0]
    b56c:      	add	x0, x0, x1, lsl #2
    b570:      	str	w2, [x0]
    b574:      	movz	x0, #0x0, lsl #48
    b578:      	ret

000000000000b57c <_stogir.opcode.control?>:
    b57c:      	sxtw	x0, w0
    b580:      	cmp	x0, #0x0
    b584:      	b.lt	0xb5a4 <_stogir.opcode.control?+0x28>
    b588:      	cmp	x0, #0x83
    b58c:      	b.ge	0xb5a4 <_stogir.opcode.control?+0x28>
    b590:      	adrp	x16, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b590:  ARM64_RELOC_PAGE21	l_stogir.492
    b594:      	ldr	x16, [x16]
		000000000000b594:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    b598:      	add	x0, x16, x0
    b59c:      	ldrb	w0, [x0]
    b5a0:      	b	0xb5a8 <_stogir.opcode.control?+0x2c>
    b5a4:      	movz	w0, #0x0, lsl #16
    b5a8:      	uxtb	w16, w0
    b5ac:      	and	w0, w16, #0x1
    b5b0:      	uxtb	w0, w0
    b5b4:      	ubfx	x0, x0, #0, #8
    b5b8:      	ret
    b5bc:      	udf	#0x0

000000000000b5c0 <_inherent$coil.arraylist.ArrayList$clear!__i32>:
    b5c0:      	b	0xb5d0 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x10>
    b5c4:      	nop
    b5c8:      	sub	x1, x1, #0x1
    b5cc:      	str	x1, [x0, #0x8]
    b5d0:      	ldr	x1, [x0, #0x8]
    b5d4:      	cmp	x1, #0x0
    b5d8:      	b.ne	0xb5c8 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x8>
    b5dc:      	movz	x0, #0x0, lsl #48
    b5e0:      	ret

000000000000b5e4 <_stogir.graph.operand>:
    b5e4:      	sub	sp, sp, #0x10
    b5e8:      	mov	x3, sp
    b5ec:      	sxtw	x1, w1
    b5f0:      	cmp	x1, #0x0
    b5f4:      	b.le	0xb638 <_stogir.graph.operand+0x54>
    b5f8:      	lsl	x4, x1, #2
    b5fc:      	ldr	x5, [x0, #0x8]
    b600:      	cmp	x1, x5
    b604:      	b.ge	0xb66c <_stogir.graph.operand+0x88>
    b608:      	add	x5, x0, #0x78
    b60c:      	ldr	x5, [x5, #0x8]
    b610:      	cmp	x1, x5
    b614:      	b.ge	0xb664 <_stogir.graph.operand+0x80>
    b618:      	ldr	x5, [x0, #0x78]
    b61c:      	add	x5, x4, x5
    b620:      	ldr	w5, [x5]
    b624:      	sxtw	x5, w5
    b628:      	cmp	x5, #0x0
    b62c:      	cset	w5, ge
    b630:      	ubfx	x5, x5, #0, #8
    b634:      	b	0xb668 <_stogir.graph.operand+0x84>
    b638:      	movz	x1, #0x0, lsl #48
    b63c:      	movz	x0, #0x0, lsl #48
    b640:      	str	x1, [x3]
    b644:      	str	x0, [x3, #0x8]
    b648:      	ldr	x0, [sp]
    b64c:      	ldr	x1, [sp, #0x8]
    b650:      	add	sp, sp, #0x10
    b654:      	ret
    b658:      	movz	x1, #0x0, lsl #48
    b65c:      	movz	x0, #0x0, lsl #48
    b660:      	b	0xb640 <_stogir.graph.operand+0x5c>
    b664:      	movz	x5, #0x0, lsl #48
    b668:      	b	0xb670 <_stogir.graph.operand+0x8c>
    b66c:      	movz	x5, #0x0, lsl #48
    b670:      	cmp	x5, #0x0
    b674:      	b.eq	0xb638 <_stogir.graph.operand+0x54>
    b678:      	sxtw	x2, w2
    b67c:      	cmp	x2, #0x1
    b680:      	b.lt	0xb658 <_stogir.graph.operand+0x74>
    b684:      	ldr	x5, [x0, #0x78]
    b688:      	add	x4, x4, x5
    b68c:      	ldr	w4, [x4]
    b690:      	sxtw	x4, w4
    b694:      	cmp	x2, x4
    b698:      	b.gt	0xb658 <_stogir.graph.operand+0x74>
    b69c:      	asr	x16, x2, #63
    b6a0:      	lsr	x16, x16, #62
    b6a4:      	add	x4, x2, x16
    b6a8:      	asr	x4, x4, #2
    b6ac:      	asr	x16, x2, #63
    b6b0:      	lsr	x16, x16, #62
    b6b4:      	add	x2, x2, x16
    b6b8:      	and	x2, x2, #0x3
    b6bc:      	sub	x2, x2, x16
    b6c0:      	ldr	x0, [x0]
    b6c4:      	add	x1, x4, x1
    b6c8:      	add	x0, x0, x1, lsl #4
    b6cc:      	add	x0, x0, x2, lsl #2
    b6d0:      	ldr	w0, [x0]
    b6d4:      	sxtw	x0, w0
    b6d8:      	and	x0, x0, #0xffffffff
    b6dc:      	mov	x1, #0x1                ; =1
    b6e0:      	b	0xb660 <_stogir.graph.operand+0x7c>

000000000000b6e4 <_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame>:
    b6e4:      	ldr	x1, [x0]
    b6e8:      	ldr	x0, [x0, #0x8]
    b6ec:      	movz	x17, #0x0, lsl #48
    b6f0:      	str	x17, [x8]
    b6f4:      	movz	x17, #0x0, lsl #48
    b6f8:      	str	x17, [x8, #0x8]
    b6fc:      	movz	x17, #0x0, lsl #48
    b700:      	str	x17, [x8, #0x10]
    b704:      	str	x1, [x8, #0x18]
    b708:      	str	x0, [x8, #0x20]
    b70c:      	ret

000000000000b710 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool>:
    b710:      	sub	sp, sp, #0x30
    b714:      	str	x29, [sp]
    b718:      	str	x30, [sp, #0x8]
    b71c:      	mov	x29, sp
    b720:      	str	x19, [sp, #0x10]
    b724:      	str	x20, [sp, #0x18]
    b728:      	str	x21, [sp, #0x20]
    b72c:      	str	x22, [sp, #0x28]
    b730:      	ldr	x2, [x0, #0x8]
    b734:      	orr	x19, x2, xzr
    b738:      	ldr	x2, [x0, #0x10]
    b73c:      	add	x20, x19, x1
    b740:      	cmp	x20, x2
    b744:      	b.le	0xb7c0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xb0>
    b748:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b74c:      	cmp	x2, x17
    b750:      	b.gt	0xb75c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x4c>
    b754:      	lsl	x2, x2, #1
    b758:      	b	0xb760 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x50>
    b75c:      	mov	x2, x20
    b760:      	cmp	x2, x20
    b764:      	b.gt	0xb76c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x5c>
    b768:      	mov	x2, x20
    b76c:      	mov	x21, x0
    b770:      	mov	x22, x1
    b774:      	mov	x1, x2
    b778:      	bl	0xb778 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x68>
		000000000000b778:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    b77c:      	lsr	x0, x22, #0
    b780:      	ldr	x1, [x21]
    b784:      	add	x1, x1, x19
    b788:      	mov	x2, x0
    b78c:      	mov	x0, x1
    b790:      	movz	x1, #0x0, lsl #48
    b794:      	bl	0xb794 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x84>
		000000000000b794:  ARM64_RELOC_BRANCH26	_memset
    b798:      	str	x20, [x21, #0x8]
    b79c:      	mov	x0, x20
    b7a0:      	ldr	x19, [sp, #0x10]
    b7a4:      	ldr	x20, [sp, #0x18]
    b7a8:      	ldr	x21, [sp, #0x20]
    b7ac:      	ldr	x22, [sp, #0x28]
    b7b0:      	ldr	x29, [sp]
    b7b4:      	ldr	x30, [sp, #0x8]
    b7b8:      	add	sp, sp, #0x30
    b7bc:      	ret
    b7c0:      	mov	x21, x0
    b7c4:      	mov	x22, x1
    b7c8:      	b	0xb77c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x6c>

000000000000b7cc <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame>:
    b7cc:      	sub	sp, sp, #0x30
    b7d0:      	str	x29, [sp]
    b7d4:      	str	x30, [sp, #0x8]
    b7d8:      	mov	x29, sp
    b7dc:      	str	x19, [sp, #0x10]
    b7e0:      	str	x20, [sp, #0x18]
    b7e4:      	str	x21, [sp, #0x20]
    b7e8:      	str	x22, [sp, #0x28]
    b7ec:      	ldr	x3, [x0, #0x8]
    b7f0:      	orr	x19, x3, xzr
    b7f4:      	ldr	x3, [x0, #0x10]
    b7f8:      	cmp	x19, x3
    b7fc:      	b.lt	0xb810 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x44>
    b800:      	cmp	x3, #0x0
    b804:      	b.ne	0xb820 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x54>
    b808:      	mov	x3, #0x2                ; =2
    b80c:      	b	0xb824 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x58>
    b810:      	mov	x20, x0
    b814:      	mov	x21, x1
    b818:      	mov	x22, x2
    b81c:      	b	0xb838 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x6c>
    b820:      	lsl	x3, x3, #1
    b824:      	mov	x20, x0
    b828:      	mov	x21, x1
    b82c:      	mov	x1, x3
    b830:      	mov	x22, x2
    b834:      	bl	0xb834 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x68>
		000000000000b834:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    b838:      	add	x0, x19, #0x1
    b83c:      	ldr	x1, [x20]
    b840:      	add	x1, x1, x19, lsl #4
    b844:      	str	x21, [x1]
    b848:      	str	x22, [x1, #0x8]
    b84c:      	str	x0, [x20, #0x8]
    b850:      	ldr	x19, [sp, #0x10]
    b854:      	ldr	x20, [sp, #0x18]
    b858:      	ldr	x21, [sp, #0x20]
    b85c:      	ldr	x22, [sp, #0x28]
    b860:      	ldr	x29, [sp]
    b864:      	ldr	x30, [sp, #0x8]
    b868:      	add	sp, sp, #0x30
    b86c:      	ret

000000000000b870 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame>:
    b870:      	sub	sp, sp, #0x20
    b874:      	str	x29, [sp]
    b878:      	str	x30, [sp, #0x8]
    b87c:      	mov	x29, sp
    b880:      	str	x19, [sp, #0x10]
    b884:      	b	0xb890 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x20>
    b888:      	sub	x1, x1, #0x1
    b88c:      	str	x1, [x0, #0x8]
    b890:      	ldr	x1, [x0, #0x8]
    b894:      	cmp	x1, #0x0
    b898:      	b.ne	0xb888 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x18>
    b89c:      	ldr	x1, [x0, #0x10]
    b8a0:      	cmp	x1, #0x0
    b8a4:      	b.le	0xb904 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x94>
    b8a8:      	add	x2, x0, #0x18
    b8ac:      	ldr	x3, [x0]
    b8b0:      	mov	x19, x0
    b8b4:      	mov	x0, x2
    b8b8:      	mov	x2, x1
    b8bc:      	mov	x1, x3
    b8c0:      	adrp	x3, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b8c0:  ARM64_RELOC_PAGE21	l_stogir.493
    b8c4:      	ldr	x3, [x3]
		000000000000b8c4:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b8c8:      	mov	x4, #0x10               ; =16
    b8cc:      	mov	x5, #0x8                ; =8
    b8d0:      	bl	0xb8d0 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x60>
		000000000000b8d0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b8d4:      	movz	x17, #0x0, lsl #48
    b8d8:      	str	x17, [x19]
    b8dc:      	movz	x17, #0x0, lsl #48
    b8e0:      	str	x17, [x19, #0x8]
    b8e4:      	movz	x17, #0x0, lsl #48
    b8e8:      	str	x17, [x19, #0x10]
    b8ec:      	movz	x0, #0x0, lsl #48
    b8f0:      	ldr	x19, [sp, #0x10]
    b8f4:      	ldr	x29, [sp]
    b8f8:      	ldr	x30, [sp, #0x8]
    b8fc:      	add	sp, sp, #0x20
    b900:      	ret
    b904:      	mov	x19, x0
    b908:      	b	0xb8d4 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x64>

000000000000b90c <_inherent$coil.arraylist.ArrayList$new__i64>:
    b90c:      	ldr	x1, [x0]
    b910:      	ldr	x0, [x0, #0x8]
    b914:      	movz	x17, #0x0, lsl #48
    b918:      	str	x17, [x8]
    b91c:      	movz	x17, #0x0, lsl #48
    b920:      	str	x17, [x8, #0x8]
    b924:      	movz	x17, #0x0, lsl #48
    b928:      	str	x17, [x8, #0x10]
    b92c:      	str	x1, [x8, #0x18]
    b930:      	str	x0, [x8, #0x20]
    b934:      	ret

000000000000b938 <_inherent$coil.arraylist.ArrayList$free!__i64>:
    b938:      	sub	sp, sp, #0x20
    b93c:      	str	x29, [sp]
    b940:      	str	x30, [sp, #0x8]
    b944:      	mov	x29, sp
    b948:      	str	x19, [sp, #0x10]
    b94c:      	b	0xb958 <_inherent$coil.arraylist.ArrayList$free!__i64+0x20>
    b950:      	sub	x1, x1, #0x1
    b954:      	str	x1, [x0, #0x8]
    b958:      	ldr	x1, [x0, #0x8]
    b95c:      	cmp	x1, #0x0
    b960:      	b.ne	0xb950 <_inherent$coil.arraylist.ArrayList$free!__i64+0x18>
    b964:      	ldr	x1, [x0, #0x10]
    b968:      	cmp	x1, #0x0
    b96c:      	b.le	0xb9cc <_inherent$coil.arraylist.ArrayList$free!__i64+0x94>
    b970:      	add	x2, x0, #0x18
    b974:      	ldr	x3, [x0]
    b978:      	mov	x19, x0
    b97c:      	mov	x0, x2
    b980:      	mov	x2, x1
    b984:      	mov	x1, x3
    b988:      	adrp	x3, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000b988:  ARM64_RELOC_PAGE21	l_stogir.494
    b98c:      	ldr	x3, [x3]
		000000000000b98c:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    b990:      	mov	x4, #0x8                ; =8
    b994:      	mov	x5, #0x8                ; =8
    b998:      	bl	0xb998 <_inherent$coil.arraylist.ArrayList$free!__i64+0x60>
		000000000000b998:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b99c:      	movz	x17, #0x0, lsl #48
    b9a0:      	str	x17, [x19]
    b9a4:      	movz	x17, #0x0, lsl #48
    b9a8:      	str	x17, [x19, #0x8]
    b9ac:      	movz	x17, #0x0, lsl #48
    b9b0:      	str	x17, [x19, #0x10]
    b9b4:      	movz	x0, #0x0, lsl #48
    b9b8:      	ldr	x19, [sp, #0x10]
    b9bc:      	ldr	x29, [sp]
    b9c0:      	ldr	x30, [sp, #0x8]
    b9c4:      	add	sp, sp, #0x20
    b9c8:      	ret
    b9cc:      	mov	x19, x0
    b9d0:      	b	0xb99c <_inherent$coil.arraylist.ArrayList$free!__i64+0x64>
    b9d4:      	udf	#0x0

000000000000b9d8 <_stogir.dominators.build-index>:
    b9d8:      	sub	sp, sp, #0x140
    b9dc:      	str	x29, [sp]
    b9e0:      	str	x30, [sp, #0x8]
    b9e4:      	mov	x29, sp
    b9e8:      	str	x19, [sp, #0xf0]
    b9ec:      	str	x20, [sp, #0xf8]
    b9f0:      	str	x21, [sp, #0x100]
    b9f4:      	str	x22, [sp, #0x108]
    b9f8:      	str	x23, [sp, #0x110]
    b9fc:      	str	x24, [sp, #0x118]
    ba00:      	str	x25, [sp, #0x120]
    ba04:      	str	x26, [sp, #0x128]
    ba08:      	str	x27, [sp, #0x130]
    ba0c:      	str	x28, [sp, #0x138]
    ba10:      	add	x16, sp, #0x10
    ba14:      	orr	x19, x16, xzr
    ba18:      	ldr	x2, [x0, #0x8]
    ba1c:      	orr	x20, x2, xzr
    ba20:      	ldr	x2, [x1]
    ba24:      	ldr	x3, [x1, #0x8]
    ba28:      	add	x16, sp, #0x10
    ba2c:      	movz	x17, #0x0, lsl #48
    ba30:      	str	x17, [x16]
    ba34:      	add	x16, sp, #0x10
    ba38:      	movz	x17, #0x0, lsl #48
    ba3c:      	str	x17, [x16, #0x8]
    ba40:      	add	x16, sp, #0x10
    ba44:      	movz	x17, #0x0, lsl #48
    ba48:      	str	x17, [x16, #0x10]
    ba4c:      	add	x16, sp, #0x10
    ba50:      	str	x2, [x16, #0x18]
    ba54:      	add	x16, sp, #0x10
    ba58:      	str	x3, [x16, #0x20]
    ba5c:      	add	x16, sp, #0x10
    ba60:      	movz	x17, #0x0, lsl #48
    ba64:      	str	x17, [x16, #0x28]
    ba68:      	add	x16, sp, #0x10
    ba6c:      	movz	x17, #0x0, lsl #48
    ba70:      	str	x17, [x16, #0x30]
    ba74:      	add	x16, sp, #0x10
    ba78:      	movz	x17, #0x0, lsl #48
    ba7c:      	str	x17, [x16, #0x38]
    ba80:      	add	x16, sp, #0x10
    ba84:      	str	x2, [x16, #0x40]
    ba88:      	add	x16, sp, #0x10
    ba8c:      	str	x3, [x16, #0x48]
    ba90:      	ldr	x2, [x1]
    ba94:      	ldr	x3, [x1, #0x8]
    ba98:      	add	x16, sp, #0x60
    ba9c:      	movz	x17, #0x0, lsl #48
    baa0:      	str	x17, [x16]
    baa4:      	add	x16, sp, #0x60
    baa8:      	movz	x17, #0x0, lsl #48
    baac:      	str	x17, [x16, #0x8]
    bab0:      	add	x16, sp, #0x60
    bab4:      	movz	x17, #0x0, lsl #48
    bab8:      	str	x17, [x16, #0x10]
    babc:      	add	x16, sp, #0x60
    bac0:      	str	x2, [x16, #0x18]
    bac4:      	add	x16, sp, #0x60
    bac8:      	str	x3, [x16, #0x20]
    bacc:      	ldr	x2, [x1]
    bad0:      	ldr	x3, [x1, #0x8]
    bad4:      	add	x16, sp, #0x90
    bad8:      	movz	x17, #0x0, lsl #48
    badc:      	str	x17, [x16]
    bae0:      	add	x16, sp, #0x90
    bae4:      	movz	x17, #0x0, lsl #48
    bae8:      	str	x17, [x16, #0x8]
    baec:      	add	x16, sp, #0x90
    baf0:      	movz	x17, #0x0, lsl #48
    baf4:      	str	x17, [x16, #0x10]
    baf8:      	add	x16, sp, #0x90
    bafc:      	str	x2, [x16, #0x18]
    bb00:      	add	x16, sp, #0x90
    bb04:      	str	x3, [x16, #0x20]
    bb08:      	ldr	x2, [x1]
    bb0c:      	ldr	x1, [x1, #0x8]
    bb10:      	add	x16, sp, #0xc0
    bb14:      	movz	x17, #0x0, lsl #48
    bb18:      	str	x17, [x16]
    bb1c:      	add	x16, sp, #0xc0
    bb20:      	movz	x17, #0x0, lsl #48
    bb24:      	str	x17, [x16, #0x8]
    bb28:      	add	x16, sp, #0xc0
    bb2c:      	movz	x17, #0x0, lsl #48
    bb30:      	str	x17, [x16, #0x10]
    bb34:      	add	x16, sp, #0xc0
    bb38:      	str	x2, [x16, #0x18]
    bb3c:      	add	x16, sp, #0xc0
    bb40:      	str	x1, [x16, #0x20]
    bb44:      	cmp	x20, #0x0
    bb48:      	b.le	0xc0f8 <_stogir.dominators.build-index+0x720>
    bb4c:      	cmp	x20, #0x0
    bb50:      	b.ge	0xbb5c <_stogir.dominators.build-index+0x184>
    bb54:      	movz	x1, #0x0, lsl #48
    bb58:      	b	0xbb60 <_stogir.dominators.build-index+0x188>
    bb5c:      	mov	x1, x20
    bb60:      	mov	x21, x8
    bb64:      	mov	x22, x0
    bb68:      	mov	x0, x19
    bb6c:      	bl	0xbb6c <_stogir.dominators.build-index+0x194>
		000000000000bb6c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    bb70:      	add	x19, x19, #0x28
    bb74:      	lsl	x23, x20, #2
    bb78:      	add	x16, sp, #0x10
    bb7c:      	ldr	x0, [x16]
    bb80:      	mov	x2, x23
    bb84:      	movz	x1, #0x0, lsl #48
    bb88:      	bl	0xbb88 <_stogir.dominators.build-index+0x1b0>
		000000000000bb88:  ARM64_RELOC_BRANCH26	_memset
    bb8c:      	add	x16, sp, #0x10
    bb90:      	str	x20, [x16, #0x8]
    bb94:      	ldr	x0, [x19, #0x8]
    bb98:      	orr	x24, x0, xzr
    bb9c:      	ldr	x0, [x19, #0x10]
    bba0:      	add	x25, x24, x20
    bba4:      	cmp	x25, x0
    bba8:      	b.le	0xbbdc <_stogir.dominators.build-index+0x204>
    bbac:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    bbb0:      	cmp	x0, x17
    bbb4:      	b.gt	0xbbc0 <_stogir.dominators.build-index+0x1e8>
    bbb8:      	lsl	x0, x0, #1
    bbbc:      	b	0xbbc4 <_stogir.dominators.build-index+0x1ec>
    bbc0:      	mov	x0, x25
    bbc4:      	cmp	x0, x25
    bbc8:      	b.gt	0xbbd0 <_stogir.dominators.build-index+0x1f8>
    bbcc:      	mov	x0, x25
    bbd0:      	mov	x1, x0
    bbd4:      	mov	x0, x19
    bbd8:      	bl	0xbbd8 <_stogir.dominators.build-index+0x200>
		000000000000bbd8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    bbdc:      	add	x16, sp, #0x60
    bbe0:      	orr	x26, x16, xzr
    bbe4:      	add	x16, sp, #0x10
    bbe8:      	ldr	x0, [x16, #0x28]
    bbec:      	add	x0, x0, x24, lsl #2
    bbf0:      	mov	x2, x23
    bbf4:      	movz	x1, #0x0, lsl #48
    bbf8:      	bl	0xbbf8 <_stogir.dominators.build-index+0x220>
		000000000000bbf8:  ARM64_RELOC_BRANCH26	_memset
    bbfc:      	str	x25, [x19, #0x8]
    bc00:      	add	x16, sp, #0x60
    bc04:      	ldr	x0, [x16, #0x8]
    bc08:      	orr	x19, x0, xzr
    bc0c:      	add	x16, sp, #0x60
    bc10:      	ldr	x0, [x16, #0x10]
    bc14:      	add	x24, x19, x20
    bc18:      	cmp	x24, x0
    bc1c:      	b.le	0xbc50 <_stogir.dominators.build-index+0x278>
    bc20:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    bc24:      	cmp	x0, x17
    bc28:      	b.gt	0xbc34 <_stogir.dominators.build-index+0x25c>
    bc2c:      	lsl	x0, x0, #1
    bc30:      	b	0xbc38 <_stogir.dominators.build-index+0x260>
    bc34:      	mov	x0, x24
    bc38:      	cmp	x0, x24
    bc3c:      	b.gt	0xbc44 <_stogir.dominators.build-index+0x26c>
    bc40:      	mov	x0, x24
    bc44:      	mov	x1, x0
    bc48:      	mov	x0, x26
    bc4c:      	bl	0xbc4c <_stogir.dominators.build-index+0x274>
		000000000000bc4c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    bc50:      	add	x16, sp, #0x90
    bc54:      	orr	x25, x16, xzr
    bc58:      	add	x16, sp, #0x60
    bc5c:      	ldr	x0, [x16]
    bc60:      	add	x0, x0, x19, lsl #2
    bc64:      	mov	x2, x23
    bc68:      	movz	x1, #0x0, lsl #48
    bc6c:      	bl	0xbc6c <_stogir.dominators.build-index+0x294>
		000000000000bc6c:  ARM64_RELOC_BRANCH26	_memset
    bc70:      	add	x16, sp, #0x60
    bc74:      	str	x24, [x16, #0x8]
    bc78:      	mov	x0, x25
    bc7c:      	mov	x1, x20
    bc80:      	bl	0xbc80 <_stogir.dominators.build-index+0x2a8>
		000000000000bc80:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    bc84:      	movz	x0, #0x0, lsl #48
    bc88:      	b	0xbcc4 <_stogir.dominators.build-index+0x2ec>
    bc8c:      	nop
    bc90:      	orr	w2, w0, wzr
    bc94:      	add	x16, sp, #0x60
    bc98:      	ldr	x3, [x16]
    bc9c:      	add	x3, x3, x1, lsl #2
    bca0:      	ldr	w3, [x3]
    bca4:      	add	x16, sp, #0x90
    bca8:      	ldr	x4, [x16]
    bcac:      	add	x4, x4, x0, lsl #2
    bcb0:      	str	w3, [x4]
    bcb4:      	add	x16, sp, #0x60
    bcb8:      	ldr	x3, [x16]
    bcbc:      	add	x1, x3, x1, lsl #2
    bcc0:      	str	w2, [x1]
    bcc4:      	add	x0, x0, #0x1
    bcc8:      	cmp	x0, x20
    bccc:      	b.ge	0xbcf4 <_stogir.dominators.build-index+0x31c>
    bcd0:      	ldr	x1, [x22]
    bcd4:      	add	x1, x1, x0, lsl #2
    bcd8:      	ldr	w1, [x1]
    bcdc:      	sxtw	x1, w1
    bce0:      	cmp	x1, #0x0
    bce4:      	b.le	0xbcc4 <_stogir.dominators.build-index+0x2ec>
    bce8:      	cmp	x1, x0
    bcec:      	b.ne	0xbc90 <_stogir.dominators.build-index+0x2b8>
    bcf0:      	b	0xbcc4 <_stogir.dominators.build-index+0x2ec>
    bcf4:      	add	x16, sp, #0xc0
    bcf8:      	orr	x19, x16, xzr
    bcfc:      	movz	x23, #0x0, lsl #48
    bd00:      	movz	x0, #0x0, lsl #48
    bd04:      	b	0xbe48 <_stogir.dominators.build-index+0x470>
    bd08:      	lsl	x0, x0, #1
    bd0c:      	mov	x1, x0
    bd10:      	mov	x0, x19
    bd14:      	bl	0xbd14 <_stogir.dominators.build-index+0x33c>
		000000000000bd14:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    bd18:      	sxtw	x0, w24
    bd1c:      	orr	w1, w23, wzr
    bd20:      	add	x2, x27, #0x1
    bd24:      	add	x16, sp, #0xc0
    bd28:      	ldr	x3, [x16]
    bd2c:      	add	x3, x3, x27, lsl #2
    bd30:      	str	w1, [x3]
    bd34:      	add	x16, sp, #0xc0
    bd38:      	str	x2, [x16, #0x8]
    bd3c:      	b	0xbd70 <_stogir.dominators.build-index+0x398>
    bd40:      	lsl	x0, x0, #1
    bd44:      	mov	x1, x0
    bd48:      	mov	x0, x19
    bd4c:      	bl	0xbd4c <_stogir.dominators.build-index+0x374>
		000000000000bd4c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    bd50:      	sxtw	x0, w27
    bd54:      	add	x1, x28, #0x1
    bd58:      	add	x16, sp, #0xc0
    bd5c:      	ldr	x2, [x16]
    bd60:      	add	x2, x2, x28, lsl #2
    bd64:      	str	w24, [x2]
    bd68:      	add	x16, sp, #0xc0
    bd6c:      	str	x1, [x16, #0x8]
    bd70:      	add	x16, sp, #0xc0
    bd74:      	ldr	x1, [x16, #0x8]
    bd78:      	cmp	x1, #0x0
    bd7c:      	b.le	0xbe48 <_stogir.dominators.build-index+0x470>
    bd80:      	add	x16, sp, #0xc0
    bd84:      	ldr	x2, [x16]
    bd88:      	sub	x1, x1, #0x1
    bd8c:      	add	x1, x2, x1, lsl #2
    bd90:      	ldr	w1, [x1]
    bd94:      	sxtw	x1, w1
    bd98:      	add	x16, sp, #0x60
    bd9c:      	ldr	x2, [x16]
    bda0:      	add	x3, x2, x1, lsl #2
    bda4:      	ldr	w24, [x3]
    bda8:      	sxtw	x3, w24
    bdac:      	cmp	x3, #0x0
    bdb0:      	b.le	0xbe10 <_stogir.dominators.build-index+0x438>
    bdb4:      	add	x0, x0, #0x1
    bdb8:      	add	x16, sp, #0x90
    bdbc:      	ldr	x4, [x16]
    bdc0:      	orr	w27, w0, wzr
    bdc4:      	add	x0, x2, x1, lsl #2
    bdc8:      	add	x1, x4, x3, lsl #2
    bdcc:      	ldr	w1, [x1]
    bdd0:      	str	w1, [x0]
    bdd4:      	add	x16, sp, #0x10
    bdd8:      	ldr	x0, [x16]
    bddc:      	add	x0, x0, x3, lsl #2
    bde0:      	str	w27, [x0]
    bde4:      	add	x16, sp, #0xc0
    bde8:      	ldr	x0, [x16, #0x8]
    bdec:      	orr	x28, x0, xzr
    bdf0:      	add	x16, sp, #0xc0
    bdf4:      	ldr	x0, [x16, #0x10]
    bdf8:      	cmp	x28, x0
    bdfc:      	b.lt	0xbd50 <_stogir.dominators.build-index+0x378>
    be00:      	cmp	x0, #0x0
    be04:      	b.ne	0xbd40 <_stogir.dominators.build-index+0x368>
    be08:      	mov	x0, #0x2                ; =2
    be0c:      	b	0xbd44 <_stogir.dominators.build-index+0x36c>
    be10:      	orr	w2, w0, wzr
    be14:      	add	x16, sp, #0x10
    be18:      	ldr	x3, [x16, #0x28]
    be1c:      	add	x1, x3, x1, lsl #2
    be20:      	str	w2, [x1]
    be24:      	add	x16, sp, #0xc0
    be28:      	ldr	x1, [x16, #0x8]
    be2c:      	cmp	x1, #0x0
    be30:      	b.eq	0xbd70 <_stogir.dominators.build-index+0x398>
    be34:      	sub	x1, x1, #0x1
    be38:      	add	x16, sp, #0xc0
    be3c:      	str	x1, [x16, #0x8]
    be40:      	b	0xbd70 <_stogir.dominators.build-index+0x398>
    be44:      	nop
    be48:      	add	x23, x23, #0x1
    be4c:      	cmp	x23, x20
    be50:      	b.ge	0xbeb0 <_stogir.dominators.build-index+0x4d8>
    be54:      	ldr	x1, [x22]
    be58:      	add	x1, x1, x23, lsl #2
    be5c:      	ldr	w1, [x1]
    be60:      	sxtw	x1, w1
    be64:      	cmp	x1, x23
    be68:      	b.ne	0xbe48 <_stogir.dominators.build-index+0x470>
    be6c:      	add	x0, x0, #0x1
    be70:      	add	x16, sp, #0x10
    be74:      	ldr	x1, [x16]
    be78:      	orr	w24, w0, wzr
    be7c:      	add	x0, x1, x23, lsl #2
    be80:      	str	w24, [x0]
    be84:      	add	x16, sp, #0xc0
    be88:      	ldr	x0, [x16, #0x8]
    be8c:      	orr	x27, x0, xzr
    be90:      	add	x16, sp, #0xc0
    be94:      	ldr	x0, [x16, #0x10]
    be98:      	cmp	x27, x0
    be9c:      	b.lt	0xbd18 <_stogir.dominators.build-index+0x340>
    bea0:      	cmp	x0, #0x0
    bea4:      	b.ne	0xbd08 <_stogir.dominators.build-index+0x330>
    bea8:      	mov	x0, #0x2                ; =2
    beac:      	b	0xbd0c <_stogir.dominators.build-index+0x334>
    beb0:      	b	0xbec4 <_stogir.dominators.build-index+0x4ec>
    beb4:      	nop
    beb8:      	sub	x0, x0, #0x1
    bebc:      	add	x16, sp, #0xc0
    bec0:      	str	x0, [x16, #0x8]
    bec4:      	add	x16, sp, #0xc0
    bec8:      	ldr	x0, [x16, #0x8]
    becc:      	cmp	x0, #0x0
    bed0:      	b.ne	0xbeb8 <_stogir.dominators.build-index+0x4e0>
    bed4:      	add	x16, sp, #0xc0
    bed8:      	ldr	x0, [x16, #0x10]
    bedc:      	cmp	x0, #0x0
    bee0:      	b.le	0xbf14 <_stogir.dominators.build-index+0x53c>
    bee4:      	add	x1, x19, #0x18
    bee8:      	add	x16, sp, #0xc0
    beec:      	ldr	x2, [x16]
    bef0:      	fmov	d31, x0
    bef4:      	mov	x0, x1
    bef8:      	mov	x1, x2
    befc:      	fmov	x2, d31
    bf00:      	adrp	x3, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000bf00:  ARM64_RELOC_PAGE21	l_stogir.495
    bf04:      	ldr	x3, [x3]
		000000000000bf04:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    bf08:      	mov	x4, #0x4                ; =4
    bf0c:      	mov	x5, #0x4                ; =4
    bf10:      	bl	0xbf10 <_stogir.dominators.build-index+0x538>
		000000000000bf10:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    bf14:      	add	x16, sp, #0xc0
    bf18:      	movz	x17, #0x0, lsl #48
    bf1c:      	str	x17, [x16]
    bf20:      	add	x16, sp, #0xc0
    bf24:      	movz	x17, #0x0, lsl #48
    bf28:      	str	x17, [x16, #0x8]
    bf2c:      	add	x16, sp, #0xc0
    bf30:      	movz	x17, #0x0, lsl #48
    bf34:      	str	x17, [x16, #0x10]
    bf38:      	b	0xbf4c <_stogir.dominators.build-index+0x574>
    bf3c:      	nop
    bf40:      	sub	x0, x0, #0x1
    bf44:      	add	x16, sp, #0x90
    bf48:      	str	x0, [x16, #0x8]
    bf4c:      	add	x16, sp, #0x90
    bf50:      	ldr	x0, [x16, #0x8]
    bf54:      	cmp	x0, #0x0
    bf58:      	b.ne	0xbf40 <_stogir.dominators.build-index+0x568>
    bf5c:      	add	x16, sp, #0x90
    bf60:      	ldr	x0, [x16, #0x10]
    bf64:      	cmp	x0, #0x0
    bf68:      	b.le	0xbf9c <_stogir.dominators.build-index+0x5c4>
    bf6c:      	add	x1, x25, #0x18
    bf70:      	add	x16, sp, #0x90
    bf74:      	ldr	x2, [x16]
    bf78:      	fmov	d31, x0
    bf7c:      	mov	x0, x1
    bf80:      	mov	x1, x2
    bf84:      	fmov	x2, d31
    bf88:      	adrp	x3, 0xb000 <_stogir.verify.control-sources+0xcc>
		000000000000bf88:  ARM64_RELOC_PAGE21	l_stogir.495
    bf8c:      	ldr	x3, [x3]
		000000000000bf8c:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    bf90:      	mov	x4, #0x4                ; =4
    bf94:      	mov	x5, #0x4                ; =4
    bf98:      	bl	0xbf98 <_stogir.dominators.build-index+0x5c0>
		000000000000bf98:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    bf9c:      	add	x16, sp, #0x90
    bfa0:      	movz	x17, #0x0, lsl #48
    bfa4:      	str	x17, [x16]
    bfa8:      	add	x16, sp, #0x90
    bfac:      	movz	x17, #0x0, lsl #48
    bfb0:      	str	x17, [x16, #0x8]
    bfb4:      	add	x16, sp, #0x90
    bfb8:      	movz	x17, #0x0, lsl #48
    bfbc:      	str	x17, [x16, #0x10]
    bfc0:      	b	0xbfd4 <_stogir.dominators.build-index+0x5fc>
    bfc4:      	nop
    bfc8:      	sub	x0, x0, #0x1
    bfcc:      	add	x16, sp, #0x60
    bfd0:      	str	x0, [x16, #0x8]
    bfd4:      	add	x16, sp, #0x60
    bfd8:      	ldr	x0, [x16, #0x8]
    bfdc:      	cmp	x0, #0x0
    bfe0:      	b.ne	0xbfc8 <_stogir.dominators.build-index+0x5f0>
    bfe4:      	add	x16, sp, #0x60
    bfe8:      	ldr	x0, [x16, #0x10]
    bfec:      	cmp	x0, #0x0
    bff0:      	b.le	0xc024 <_stogir.dominators.build-index+0x64c>
    bff4:      	add	x1, x26, #0x18
    bff8:      	add	x16, sp, #0x60
    bffc:      	ldr	x2, [x16]
    c000:      	fmov	d31, x0
    c004:      	mov	x0, x1
    c008:      	mov	x1, x2
    c00c:      	fmov	x2, d31
    c010:      	adrp	x3, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c010:  ARM64_RELOC_PAGE21	l_stogir.495
    c014:      	ldr	x3, [x3]
		000000000000c014:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    c018:      	mov	x4, #0x4                ; =4
    c01c:      	mov	x5, #0x4                ; =4
    c020:      	bl	0xc020 <_stogir.dominators.build-index+0x648>
		000000000000c020:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    c024:      	add	x16, sp, #0x60
    c028:      	movz	x17, #0x0, lsl #48
    c02c:      	str	x17, [x16]
    c030:      	add	x16, sp, #0x60
    c034:      	movz	x17, #0x0, lsl #48
    c038:      	str	x17, [x16, #0x8]
    c03c:      	add	x16, sp, #0x60
    c040:      	movz	x17, #0x0, lsl #48
    c044:      	str	x17, [x16, #0x10]
    c048:      	add	x16, sp, #0x10
    c04c:      	ldr	x0, [x16]
    c050:      	add	x16, sp, #0x10
    c054:      	ldr	x1, [x16, #0x8]
    c058:      	add	x16, sp, #0x10
    c05c:      	ldr	x2, [x16, #0x10]
    c060:      	add	x16, sp, #0x10
    c064:      	ldr	x3, [x16, #0x18]
    c068:      	add	x16, sp, #0x10
    c06c:      	ldr	x4, [x16, #0x20]
    c070:      	add	x16, sp, #0x10
    c074:      	ldr	x5, [x16, #0x28]
    c078:      	add	x16, sp, #0x10
    c07c:      	ldr	x6, [x16, #0x30]
    c080:      	add	x16, sp, #0x10
    c084:      	ldr	x7, [x16, #0x38]
    c088:      	add	x16, sp, #0x10
    c08c:      	ldr	x8, [x16, #0x40]
    c090:      	add	x16, sp, #0x10
    c094:      	ldr	x9, [x16, #0x48]
    c098:      	str	x0, [x21]
    c09c:      	str	x1, [x21, #0x8]
    c0a0:      	str	x2, [x21, #0x10]
    c0a4:      	str	x3, [x21, #0x18]
    c0a8:      	str	x4, [x21, #0x20]
    c0ac:      	str	x5, [x21, #0x28]
    c0b0:      	str	x6, [x21, #0x30]
    c0b4:      	str	x7, [x21, #0x38]
    c0b8:      	str	x8, [x21, #0x40]
    c0bc:      	str	x9, [x21, #0x48]
    c0c0:      	ldr	x19, [sp, #0xf0]
    c0c4:      	ldr	x20, [sp, #0xf8]
    c0c8:      	ldr	x21, [sp, #0x100]
    c0cc:      	ldr	x22, [sp, #0x108]
    c0d0:      	ldr	x23, [sp, #0x110]
    c0d4:      	ldr	x24, [sp, #0x118]
    c0d8:      	ldr	x25, [sp, #0x120]
    c0dc:      	ldr	x26, [sp, #0x128]
    c0e0:      	ldr	x27, [sp, #0x130]
    c0e4:      	ldr	x28, [sp, #0x138]
    c0e8:      	ldr	x29, [sp]
    c0ec:      	ldr	x30, [sp, #0x8]
    c0f0:      	add	sp, sp, #0x140
    c0f4:      	ret
    c0f8:      	mov	x21, x8
    c0fc:      	mov	x22, x0
    c100:      	b	0xbb70 <_stogir.dominators.build-index+0x198>
    c104:      	udf	#0x0

000000000000c108 <_stogir.dominators.release-index!>:
    c108:      	sub	sp, sp, #0x20
    c10c:      	str	x29, [sp]
    c110:      	str	x30, [sp, #0x8]
    c114:      	mov	x29, sp
    c118:      	str	x19, [sp, #0x10]
    c11c:      	str	x20, [sp, #0x18]
    c120:      	b	0xc130 <_stogir.dominators.release-index!+0x28>
    c124:      	nop
    c128:      	sub	x1, x1, #0x1
    c12c:      	str	x1, [x0, #0x8]
    c130:      	ldr	x1, [x0, #0x8]
    c134:      	cmp	x1, #0x0
    c138:      	b.ne	0xc128 <_stogir.dominators.release-index!+0x20>
    c13c:      	ldr	x1, [x0, #0x10]
    c140:      	cmp	x1, #0x0
    c144:      	b.le	0xc214 <_stogir.dominators.release-index!+0x10c>
    c148:      	add	x2, x0, #0x18
    c14c:      	ldr	x3, [x0]
    c150:      	mov	x19, x0
    c154:      	mov	x0, x2
    c158:      	mov	x2, x1
    c15c:      	mov	x1, x3
    c160:      	adrp	x3, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c160:  ARM64_RELOC_PAGE21	l_stogir.496
    c164:      	ldr	x3, [x3]
		000000000000c164:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    c168:      	mov	x4, #0x4                ; =4
    c16c:      	mov	x5, #0x4                ; =4
    c170:      	bl	0xc170 <_stogir.dominators.release-index!+0x68>
		000000000000c170:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    c174:      	add	x20, x19, #0x28
    c178:      	movz	x17, #0x0, lsl #48
    c17c:      	str	x17, [x19]
    c180:      	movz	x17, #0x0, lsl #48
    c184:      	str	x17, [x19, #0x8]
    c188:      	movz	x17, #0x0, lsl #48
    c18c:      	str	x17, [x19, #0x10]
    c190:      	b	0xc1a0 <_stogir.dominators.release-index!+0x98>
    c194:      	nop
    c198:      	sub	x0, x0, #0x1
    c19c:      	str	x0, [x20, #0x8]
    c1a0:      	ldr	x0, [x20, #0x8]
    c1a4:      	cmp	x0, #0x0
    c1a8:      	b.ne	0xc198 <_stogir.dominators.release-index!+0x90>
    c1ac:      	ldr	x0, [x20, #0x10]
    c1b0:      	cmp	x0, #0x0
    c1b4:      	b.le	0xc1e4 <_stogir.dominators.release-index!+0xdc>
    c1b8:      	add	x1, x20, #0x18
    c1bc:      	ldr	x2, [x19, #0x28]
    c1c0:      	fmov	d31, x0
    c1c4:      	mov	x0, x1
    c1c8:      	mov	x1, x2
    c1cc:      	fmov	x2, d31
    c1d0:      	adrp	x3, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c1d0:  ARM64_RELOC_PAGE21	l_stogir.496
    c1d4:      	ldr	x3, [x3]
		000000000000c1d4:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    c1d8:      	mov	x4, #0x4                ; =4
    c1dc:      	mov	x5, #0x4                ; =4
    c1e0:      	bl	0xc1e0 <_stogir.dominators.release-index!+0xd8>
		000000000000c1e0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    c1e4:      	movz	x17, #0x0, lsl #48
    c1e8:      	str	x17, [x19, #0x28]
    c1ec:      	movz	x17, #0x0, lsl #48
    c1f0:      	str	x17, [x20, #0x8]
    c1f4:      	movz	x17, #0x0, lsl #48
    c1f8:      	str	x17, [x20, #0x10]
    c1fc:      	ldr	x19, [sp, #0x10]
    c200:      	ldr	x20, [sp, #0x18]
    c204:      	ldr	x29, [sp]
    c208:      	ldr	x30, [sp, #0x8]
    c20c:      	add	sp, sp, #0x20
    c210:      	ret
    c214:      	mov	x19, x0
    c218:      	b	0xc174 <_stogir.dominators.release-index!+0x6c>

000000000000c21c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64>:
    c21c:      	sub	sp, sp, #0x30
    c220:      	str	x29, [sp]
    c224:      	str	x30, [sp, #0x8]
    c228:      	mov	x29, sp
    c22c:      	str	x19, [sp, #0x10]
    c230:      	str	x20, [sp, #0x18]
    c234:      	str	x21, [sp, #0x20]
    c238:      	str	x22, [sp, #0x28]
    c23c:      	ldr	x2, [x0, #0x8]
    c240:      	orr	x19, x2, xzr
    c244:      	ldr	x2, [x0, #0x10]
    c248:      	add	x20, x19, x1
    c24c:      	cmp	x20, x2
    c250:      	b.le	0xc2cc <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0xb0>
    c254:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    c258:      	cmp	x2, x17
    c25c:      	b.gt	0xc268 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x4c>
    c260:      	lsl	x2, x2, #1
    c264:      	b	0xc26c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x50>
    c268:      	mov	x2, x20
    c26c:      	cmp	x2, x20
    c270:      	b.gt	0xc278 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x5c>
    c274:      	mov	x2, x20
    c278:      	mov	x21, x0
    c27c:      	mov	x22, x1
    c280:      	mov	x1, x2
    c284:      	bl	0xc284 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x68>
		000000000000c284:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    c288:      	lsl	x0, x22, #3
    c28c:      	ldr	x1, [x21]
    c290:      	add	x1, x1, x19, lsl #3
    c294:      	mov	x2, x0
    c298:      	mov	x0, x1
    c29c:      	movz	x1, #0x0, lsl #48
    c2a0:      	bl	0xc2a0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x84>
		000000000000c2a0:  ARM64_RELOC_BRANCH26	_memset
    c2a4:      	str	x20, [x21, #0x8]
    c2a8:      	mov	x0, x20
    c2ac:      	ldr	x19, [sp, #0x10]
    c2b0:      	ldr	x20, [sp, #0x18]
    c2b4:      	ldr	x21, [sp, #0x20]
    c2b8:      	ldr	x22, [sp, #0x28]
    c2bc:      	ldr	x29, [sp]
    c2c0:      	ldr	x30, [sp, #0x8]
    c2c4:      	add	sp, sp, #0x30
    c2c8:      	ret
    c2cc:      	mov	x21, x0
    c2d0:      	mov	x22, x1
    c2d4:      	b	0xc288 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x6c>

000000000000c2d8 <_stogir.uses.scan!__constfalse>:
    c2d8:      	sub	sp, sp, #0x10
    c2dc:      	orr	x3, x2, xzr
    c2e0:      	mov	x4, #0x1                ; =1
    c2e4:      	b	0xc404 <_stogir.uses.scan!__constfalse+0x12c>
    c2e8:      	sub	w11, w9, #0x1
    c2ec:      	lsl	w11, w11, #2
    c2f0:      	ubfx	x11, x11, #0, #32
    c2f4:      	lsr	x11, x6, x11
    c2f8:      	and	w11, w11, #0xf
    c2fc:      	b	0xc304 <_stogir.uses.scan!__constfalse+0x2c>
    c300:      	movz	w11, #0x0, lsl #16
    c304:      	ubfx	x11, x11, #0, #32
    c308:      	cmp	x11, #0xf
    c30c:      	b.hs	0xc3bc <_stogir.uses.scan!__constfalse+0xe4>
    c310:      	mov	x16, #0x1               ; =1
    c314:      	lsl	x11, x16, x11
    c318:      	mov	w17, #0x5e1c            ; =24092
    c31c:      	and	w11, w11, w17
    c320:      	ubfx	x11, x11, #0, #32
    c324:      	cmp	x11, #0x0
    c328:      	b.eq	0xc3bc <_stogir.uses.scan!__constfalse+0xe4>
    c32c:      	ldr	x11, [x0]
    c330:      	asr	x16, x10, #63
    c334:      	lsr	x16, x16, #62
    c338:      	add	x12, x10, x16
    c33c:      	asr	x12, x12, #2
    c340:      	asr	x16, x10, #63
    c344:      	lsr	x16, x16, #62
    c348:      	add	x10, x10, x16
    c34c:      	and	x10, x10, #0x3
    c350:      	sub	x10, x10, x16
    c354:      	add	x12, x12, x4
    c358:      	add	x11, x11, x12, lsl #4
    c35c:      	add	x10, x11, x10, lsl #2
    c360:      	ldr	w10, [x10]
    c364:      	sxtw	x10, w10
    c368:      	cmp	x10, #0x0
    c36c:      	b.le	0xc3bc <_stogir.uses.scan!__constfalse+0xe4>
    c370:      	ldr	x11, [x3]
    c374:      	add	x11, x11, x10, lsl #3
    c378:      	ldr	x11, [x11]
    c37c:      	mov	x16, sp
    c380:      	movz	x17, #0x0, lsl #48
    c384:      	str	x17, [x16]
    c388:      	add	x12, x11, #0x1
    c38c:      	mov	x16, sp
    c390:      	str	w5, [x16]
    c394:      	mov	x16, sp
    c398:      	str	w9, [x16, #0x4]
    c39c:      	mov	x16, sp
    c3a0:      	ldr	x9, [x16]
    c3a4:      	ldr	x13, [x1, #0x28]
    c3a8:      	add	x11, x13, x11, lsl #3
    c3ac:      	str	x9, [x11]
    c3b0:      	ldr	x9, [x2]
    c3b4:      	add	x9, x9, x10, lsl #3
    c3b8:      	str	x12, [x9]
    c3bc:      	add	x8, x8, #0x1
    c3c0:      	sxtw	x8, w8
    c3c4:      	cmp	x8, x7
    c3c8:      	b.gt	0xc3ec <_stogir.uses.scan!__constfalse+0x114>
    c3cc:      	orr	w9, w8, wzr
    c3d0:      	sxtw	x10, w9
    c3d4:      	cmp	x10, #0x0
    c3d8:      	b.le	0xc300 <_stogir.uses.scan!__constfalse+0x28>
    c3dc:      	cmp	x10, #0x4
    c3e0:      	b.le	0xc2e8 <_stogir.uses.scan!__constfalse+0x10>
    c3e4:      	mov	w11, #0x4               ; =4
    c3e8:      	b	0xc2ec <_stogir.uses.scan!__constfalse+0x14>
    c3ec:      	add	x5, x7, #0x4
    c3f0:      	asr	x16, x5, #63
    c3f4:      	lsr	x16, x16, #62
    c3f8:      	add	x5, x5, x16
    c3fc:      	asr	x5, x5, #2
    c400:      	add	x4, x5, x4
    c404:      	ldr	x5, [x0, #0x8]
    c408:      	cmp	x4, x5
    c40c:      	b.ge	0xc44c <_stogir.uses.scan!__constfalse+0x174>
    c410:      	orr	w5, w4, wzr
    c414:      	ldr	x6, [x0]
    c418:      	add	x6, x6, x4, lsl #4
    c41c:      	ldr	x6, [x6]
    c420:      	ldr	x7, [x0, #0x78]
    c424:      	uxtb	w6, w6
    c428:      	add	x7, x7, x4, lsl #2
    c42c:      	adrp	x16, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c42c:  ARM64_RELOC_PAGE21	l_stogir.497
    c430:      	ldr	x16, [x16]
		000000000000c430:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    c434:      	add	x6, x16, x6, lsl #2
    c438:      	ldr	w7, [x7]
    c43c:      	sxtw	x7, w7
    c440:      	ldr	w6, [x6]
    c444:      	mov	x8, #0x1                ; =1
    c448:      	b	0xc3c4 <_stogir.uses.scan!__constfalse+0xec>
    c44c:      	add	sp, sp, #0x10
    c450:      	ret

000000000000c454 <_stogir.opcode.properties>:
    c454:      	sxtw	x0, w0
    c458:      	cmp	x0, #0x0
    c45c:      	b.lt	0xc47c <_stogir.opcode.properties+0x28>
    c460:      	cmp	x0, #0x83
    c464:      	b.ge	0xc47c <_stogir.opcode.properties+0x28>
    c468:      	adrp	x16, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c468:  ARM64_RELOC_PAGE21	l_stogir.498
    c46c:      	ldr	x16, [x16]
		000000000000c46c:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    c470:      	add	x0, x16, x0
    c474:      	ldrb	w0, [x0]
    c478:      	b	0xc480 <_stogir.opcode.properties+0x2c>
    c47c:      	movz	x0, #0x0, lsl #48
    c480:      	ret

000000000000c484 <_stogir.graph.lookup>:
    c484:      	sxtw	x1, w1
    c488:      	cmp	x1, #0x0
    c48c:      	cset	w2, gt
    c490:      	movz	x16, #0x0, lsl #48
    c494:      	sub	x3, x16, x1
    c498:      	sub	x4, x3, #0x1
    c49c:      	uxtb	w16, w2
    c4a0:      	cmp	w16, wzr
    c4a4:      	b.eq	0xc4e4 <_stogir.graph.lookup+0x60>
    c4a8:      	ldr	x3, [x0, #0x8]
    c4ac:      	cmp	x1, x3
    c4b0:      	b.ge	0xc534 <_stogir.graph.lookup+0xb0>
    c4b4:      	add	x3, x0, #0x78
    c4b8:      	ldr	x3, [x3, #0x8]
    c4bc:      	cmp	x1, x3
    c4c0:      	b.ge	0xc5ac <_stogir.graph.lookup+0x128>
    c4c4:      	ldr	x3, [x0, #0x78]
    c4c8:      	add	x3, x3, x1, lsl #2
    c4cc:      	ldr	w3, [x3]
    c4d0:      	sxtw	x3, w3
    c4d4:      	cmp	x3, #0x0
    c4d8:      	cset	w3, ge
    c4dc:      	ubfx	x3, x3, #0, #8
    c4e0:      	b	0xc5b0 <_stogir.graph.lookup+0x12c>
    c4e4:      	cmp	x1, #0x0
    c4e8:      	b.ge	0xc53c <_stogir.graph.lookup+0xb8>
    c4ec:      	add	x5, x0, #0x28
    c4f0:      	add	x6, x0, #0x50
    c4f4:      	ldr	x5, [x5, #0x8]
    c4f8:      	ldr	x6, [x6, #0x8]
    c4fc:      	cmp	x5, x6
    c500:      	b.ne	0xc52c <_stogir.graph.lookup+0xa8>
    c504:      	cmp	x3, x5
    c508:      	b.gt	0xc5b4 <_stogir.graph.lookup+0x130>
    c50c:      	ldr	x3, [x0, #0x50]
    c510:      	add	x3, x3, x4, lsl #2
    c514:      	ldr	w3, [x3]
    c518:      	sxtw	x3, w3
    c51c:      	cmp	x3, #0x0
    c520:      	cset	w3, gt
    c524:      	ubfx	x3, x3, #0, #8
    c528:      	b	0xc5b8 <_stogir.graph.lookup+0x134>
    c52c:      	movz	x3, #0x0, lsl #48
    c530:      	b	0xc540 <_stogir.graph.lookup+0xbc>
    c534:      	movz	x3, #0x0, lsl #48
    c538:      	b	0xc540 <_stogir.graph.lookup+0xbc>
    c53c:      	movz	x3, #0x0, lsl #48
    c540:      	cmp	x3, #0x0
    c544:      	b.eq	0xc580 <_stogir.graph.lookup+0xfc>
    c548:      	uxtb	w16, w2
    c54c:      	cmp	w16, wzr
    c550:      	b.eq	0xc568 <_stogir.graph.lookup+0xe4>
    c554:      	ldr	x0, [x0]
    c558:      	add	x0, x0, x1, lsl #4
    c55c:      	ldr	x1, [x0]
    c560:      	ldr	x0, [x0, #0x8]
    c564:      	b	0xc578 <_stogir.graph.lookup+0xf4>
    c568:      	ldr	x0, [x0, #0x28]
    c56c:      	add	x0, x0, x4, lsl #4
    c570:      	ldr	x1, [x0]
    c574:      	ldr	x0, [x0, #0x8]
    c578:      	mov	x2, #0x1                ; =1
    c57c:      	b	0xc58c <_stogir.graph.lookup+0x108>
    c580:      	movz	x2, #0x0, lsl #48
    c584:      	movz	x1, #0x0, lsl #48
    c588:      	movz	x0, #0x0, lsl #48
    c58c:      	str	x2, [x8]
    c590:      	str	x1, [x8, #0x8]
    c594:      	str	x0, [x8, #0x10]
    c598:      	movz	x17, #0x0, lsl #48
    c59c:      	str	x17, [x8, #0x18]
    c5a0:      	movz	x17, #0x0, lsl #48
    c5a4:      	str	x17, [x8, #0x20]
    c5a8:      	ret
    c5ac:      	movz	x3, #0x0, lsl #48
    c5b0:      	b	0xc538 <_stogir.graph.lookup+0xb4>
    c5b4:      	movz	x3, #0x0, lsl #48
    c5b8:      	b	0xc530 <_stogir.graph.lookup+0xac>
    c5bc:      	udf	#0x0

000000000000c5c0 <_stogir.dominators.dominates?>:
    c5c0:      	sxtw	x1, w1
    c5c4:      	sxtw	x2, w2
    c5c8:      	movz	x3, #0x0, lsl #48
    c5cc:      	movz	x4, #0x0, lsl #48
    c5d0:      	b	0xc5e4 <_stogir.dominators.dominates?+0x24>
    c5d4:      	mov	x2, x5
    c5d8:      	b	0xc5e4 <_stogir.dominators.dominates?+0x24>
    c5dc:      	nop
    c5e0:      	mov	x3, #0x1                ; =1
    c5e4:      	cmp	x3, #0x0
    c5e8:      	b.ne	0xc634 <_stogir.dominators.dominates?+0x74>
    c5ec:      	cmp	x2, #0x0
    c5f0:      	b.le	0xc5e0 <_stogir.dominators.dominates?+0x20>
    c5f4:      	ldr	x5, [x0, #0x8]
    c5f8:      	cmp	x2, x5
    c5fc:      	b.ge	0xc5e0 <_stogir.dominators.dominates?+0x20>
    c600:      	ldr	x5, [x0]
    c604:      	add	x5, x5, x2, lsl #2
    c608:      	ldr	w5, [x5]
    c60c:      	sxtw	x5, w5
    c610:      	cmp	x5, #0x0
    c614:      	b.ne	0xc620 <_stogir.dominators.dominates?+0x60>
    c618:      	mov	x3, #0x1                ; =1
    c61c:      	b	0xc5d8 <_stogir.dominators.dominates?+0x18>
    c620:      	cmp	x2, x1
    c624:      	b.ne	0xc63c <_stogir.dominators.dominates?+0x7c>
    c628:      	mov	x3, #0x1                ; =1
    c62c:      	mov	x4, #0x1                ; =1
    c630:      	b	0xc5d8 <_stogir.dominators.dominates?+0x18>
    c634:      	mov	x0, x4
    c638:      	ret
    c63c:      	cmp	x2, x5
    c640:      	b.ne	0xc5d4 <_stogir.dominators.dominates?+0x14>
    c644:      	mov	x3, #0x1                ; =1
    c648:      	b	0xc5d8 <_stogir.dominators.dominates?+0x18>

000000000000c64c <_stogir.placement.use-block>:
    c64c:      	sub	sp, sp, #0x50
    c650:      	str	x29, [sp, #0x10]
    c654:      	str	x30, [sp, #0x18]
    c658:      	add	x29, sp, #0x10
    c65c:      	str	x19, [sp, #0x30]
    c660:      	str	x20, [sp, #0x38]
    c664:      	str	x21, [sp, #0x40]
    c668:      	sxtw	x2, w2
    c66c:      	lsl	x4, x2, #2
    c670:      	cmp	x2, #0x0
    c674:      	cset	w5, gt
    c678:      	movz	x16, #0x0, lsl #48
    c67c:      	sub	x6, x16, x2
    c680:      	sub	x7, x6, #0x1
    c684:      	uxtb	w16, w5
    c688:      	cmp	w16, wzr
    c68c:      	b.eq	0xc6cc <_stogir.placement.use-block+0x80>
    c690:      	ldr	x6, [x0, #0x8]
    c694:      	cmp	x2, x6
    c698:      	b.ge	0xc71c <_stogir.placement.use-block+0xd0>
    c69c:      	add	x6, x0, #0x78
    c6a0:      	ldr	x6, [x6, #0x8]
    c6a4:      	cmp	x2, x6
    c6a8:      	b.ge	0xc7f8 <_stogir.placement.use-block+0x1ac>
    c6ac:      	ldr	x6, [x0, #0x78]
    c6b0:      	add	x6, x4, x6
    c6b4:      	ldr	w6, [x6]
    c6b8:      	sxtw	x6, w6
    c6bc:      	cmp	x6, #0x0
    c6c0:      	cset	w6, ge
    c6c4:      	ubfx	x6, x6, #0, #8
    c6c8:      	b	0xc7fc <_stogir.placement.use-block+0x1b0>
    c6cc:      	cmp	x2, #0x0
    c6d0:      	b.ge	0xc724 <_stogir.placement.use-block+0xd8>
    c6d4:      	add	x9, x0, #0x28
    c6d8:      	add	x10, x0, #0x50
    c6dc:      	ldr	x9, [x9, #0x8]
    c6e0:      	ldr	x10, [x10, #0x8]
    c6e4:      	cmp	x9, x10
    c6e8:      	b.ne	0xc714 <_stogir.placement.use-block+0xc8>
    c6ec:      	cmp	x6, x9
    c6f0:      	b.gt	0xc814 <_stogir.placement.use-block+0x1c8>
    c6f4:      	ldr	x6, [x0, #0x50]
    c6f8:      	add	x6, x6, x7, lsl #2
    c6fc:      	ldr	w6, [x6]
    c700:      	sxtw	x6, w6
    c704:      	cmp	x6, #0x0
    c708:      	cset	w6, gt
    c70c:      	ubfx	x6, x6, #0, #8
    c710:      	b	0xc818 <_stogir.placement.use-block+0x1cc>
    c714:      	movz	x6, #0x0, lsl #48
    c718:      	b	0xc728 <_stogir.placement.use-block+0xdc>
    c71c:      	movz	x6, #0x0, lsl #48
    c720:      	b	0xc728 <_stogir.placement.use-block+0xdc>
    c724:      	movz	x6, #0x0, lsl #48
    c728:      	lsl	x9, x2, #4
    c72c:      	cmp	x6, #0x0
    c730:      	b.eq	0xc764 <_stogir.placement.use-block+0x118>
    c734:      	uxtb	w16, w5
    c738:      	cmp	w16, wzr
    c73c:      	b.eq	0xc750 <_stogir.placement.use-block+0x104>
    c740:      	ldr	x5, [x0]
    c744:      	add	x5, x9, x5
    c748:      	ldr	x5, [x5]
    c74c:      	b	0xc75c <_stogir.placement.use-block+0x110>
    c750:      	ldr	x5, [x0, #0x28]
    c754:      	add	x5, x5, x7, lsl #4
    c758:      	ldr	x5, [x5]
    c75c:      	mov	w6, #0x1                ; =1
    c760:      	b	0xc76c <_stogir.placement.use-block+0x120>
    c764:      	movz	w6, #0x0, lsl #16
    c768:      	movz	x5, #0x0, lsl #48
    c76c:      	ubfx	x6, x6, #0, #32
    c770:      	lsr	x16, x6, #0
    c774:      	cmp	x16, #0x1
    c778:      	b.eq	0xc794 <_stogir.placement.use-block+0x148>
    c77c:      	b.lo	0xc784 <_stogir.placement.use-block+0x138>
    c780:      	b	0xc798 <_stogir.placement.use-block+0x14c>
    c784:      	cmp	x16, #0x0
    c788:      	b.eq	0xc790 <_stogir.placement.use-block+0x144>
    c78c:      	b	0xc798 <_stogir.placement.use-block+0x14c>
    c790:      	b	0xc79c <_stogir.placement.use-block+0x150>
    c794:      	b	0xc7d8 <_stogir.placement.use-block+0x18c>
    c798:      	b	0xc8bc <_stogir.placement.use-block+0x270>
    c79c:      	mov	x19, x8
    c7a0:      	mov	x1, #0x1                ; =1
    c7a4:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c7a4:  ARM64_RELOC_PAGE21	l_stogir.499
    c7a8:      	ldr	x0, [x0]
		000000000000c7a8:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    c7ac:      	mov	x2, #0x21               ; =33
    c7b0:      	str	x1, [x19]
    c7b4:      	str	x0, [x19, #0x8]
    c7b8:      	str	x2, [x19, #0x10]
    c7bc:      	ldr	x19, [sp, #0x30]
    c7c0:      	ldr	x20, [sp, #0x38]
    c7c4:      	ldr	x21, [sp, #0x40]
    c7c8:      	ldr	x29, [sp, #0x10]
    c7cc:      	ldr	x30, [sp, #0x18]
    c7d0:      	add	sp, sp, #0x50
    c7d4:      	ret
    c7d8:      	cmp	x2, #0x0
    c7dc:      	b.gt	0xc800 <_stogir.placement.use-block+0x1b4>
    c7e0:      	mov	x19, x8
    c7e4:      	mov	x1, #0x1                ; =1
    c7e8:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c7e8:  ARM64_RELOC_PAGE21	l_stogir.500
    c7ec:      	ldr	x0, [x0]
		000000000000c7ec:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c7f0:      	mov	x2, #0x13               ; =19
    c7f4:      	b	0xc7b0 <_stogir.placement.use-block+0x164>
    c7f8:      	movz	x6, #0x0, lsl #48
    c7fc:      	b	0xc720 <_stogir.placement.use-block+0xd4>
    c800:      	sxtw	x6, w3
    c804:      	cmp	x6, #0x1
    c808:      	b.ge	0xc81c <_stogir.placement.use-block+0x1d0>
    c80c:      	mov	x19, x8
    c810:      	b	0xc7e4 <_stogir.placement.use-block+0x198>
    c814:      	movz	x6, #0x0, lsl #48
    c818:      	b	0xc718 <_stogir.placement.use-block+0xcc>
    c81c:      	ldr	x7, [x0, #0x78]
    c820:      	add	x10, x4, x7
    c824:      	ldr	w10, [x10]
    c828:      	sxtw	x10, w10
    c82c:      	cmp	x6, x10
    c830:      	b.gt	0xca88 <_stogir.placement.use-block+0x43c>
    c834:      	uxtb	w5, w5
    c838:      	cmp	x5, #0x43
    c83c:      	b.ne	0xca90 <_stogir.placement.use-block+0x444>
    c840:      	cmp	x6, #0x2
    c844:      	b.lt	0xca9c <_stogir.placement.use-block+0x450>
    c848:      	ldr	x5, [x0, #0x8]
    c84c:      	cmp	x2, x5
    c850:      	b.ge	0xc920 <_stogir.placement.use-block+0x2d4>
    c854:      	add	x5, x0, #0x78
    c858:      	ldr	x5, [x5, #0x8]
    c85c:      	cmp	x2, x5
    c860:      	b.ge	0xc960 <_stogir.placement.use-block+0x314>
    c864:      	add	x2, x4, x7
    c868:      	ldr	w2, [x2]
    c86c:      	sxtw	x2, w2
    c870:      	cmp	x2, #0x0
    c874:      	cset	w2, ge
    c878:      	ubfx	x2, x2, #0, #8
    c87c:      	b	0xc964 <_stogir.placement.use-block+0x318>
    c880:      	and	x0, x0, #0xffffffff
    c884:      	movz	x1, #0x0, lsl #48
    c888:      	movz	x2, #0x0, lsl #48
    c88c:      	b	0xc7f4 <_stogir.placement.use-block+0x1a8>
    c890:      	ldr	x0, [x21]
    c894:      	add	x0, x0, x2, lsl #2
    c898:      	ldr	w0, [x0]
    c89c:      	sxtw	x0, w0
    c8a0:      	cmp	x0, #0x0
    c8a4:      	b.ne	0xc880 <_stogir.placement.use-block+0x234>
    c8a8:      	mov	x1, #0x1                ; =1
    c8ac:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c8ac:  ARM64_RELOC_PAGE21	l_stogir.501
    c8b0:      	ldr	x0, [x0]
		000000000000c8b0:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    c8b4:      	mov	x2, #0xf                ; =15
    c8b8:      	b	0xc88c <_stogir.placement.use-block+0x240>
    c8bc:      	brk	#0
    c8c0:      	b	0xc8bc <_stogir.placement.use-block+0x270>
    c8c4:      	movz	w4, #0x0, lsl #16
    c8c8:      	movz	w2, #0x0, lsl #16
    c8cc:      	ubfx	x4, x4, #0, #32
    c8d0:      	lsr	x16, x4, #0
    c8d4:      	cmp	x16, #0x1
    c8d8:      	b.eq	0xc8f4 <_stogir.placement.use-block+0x2a8>
    c8dc:      	b.lo	0xc8e4 <_stogir.placement.use-block+0x298>
    c8e0:      	b	0xc8f8 <_stogir.placement.use-block+0x2ac>
    c8e4:      	cmp	x16, #0x0
    c8e8:      	b.eq	0xc8f0 <_stogir.placement.use-block+0x2a4>
    c8ec:      	b	0xc8f8 <_stogir.placement.use-block+0x2ac>
    c8f0:      	b	0xc8fc <_stogir.placement.use-block+0x2b0>
    c8f4:      	b	0xc968 <_stogir.placement.use-block+0x31c>
    c8f8:      	b	0xca78 <_stogir.placement.use-block+0x42c>
    c8fc:      	mov	x19, x8
    c900:      	mov	x1, #0x1                ; =1
    c904:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c904:  ARM64_RELOC_PAGE21	l_stogir.502
    c908:      	ldr	x0, [x0]
		000000000000c908:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    c90c:      	mov	x2, #0x12               ; =18
    c910:      	b	0xc88c <_stogir.placement.use-block+0x240>
    c914:      	movz	w4, #0x0, lsl #16
    c918:      	movz	w2, #0x0, lsl #16
    c91c:      	b	0xc8cc <_stogir.placement.use-block+0x280>
    c920:      	movz	x2, #0x0, lsl #48
    c924:      	cmp	x2, #0x0
    c928:      	b.eq	0xc8c4 <_stogir.placement.use-block+0x278>
    c92c:      	ldr	x2, [x0, #0x78]
    c930:      	add	x2, x4, x2
    c934:      	ldr	w2, [x2]
    c938:      	sxtw	x2, w2
    c93c:      	cmp	x2, #0x1
    c940:      	b.lt	0xc914 <_stogir.placement.use-block+0x2c8>
    c944:      	ldr	x2, [x0]
    c948:      	add	x2, x9, x2
    c94c:      	ldr	w2, [x2, #0x4]
    c950:      	movn	w17, #0x0, lsl #16
    c954:      	and	w2, w2, w17
    c958:      	mov	w4, #0x1                ; =1
    c95c:      	b	0xc91c <_stogir.placement.use-block+0x2d0>
    c960:      	movz	x2, #0x0, lsl #48
    c964:      	b	0xc924 <_stogir.placement.use-block+0x2d8>
    c968:      	sub	w3, w3, #0x1
    c96c:      	mov	x19, x8
    c970:      	mov	x20, x0
    c974:      	mov	x21, x1
    c978:      	mov	w1, w2
    c97c:      	mov	w2, w3
    c980:      	bl	0xc980 <_stogir.placement.use-block+0x334>
		000000000000c980:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    c984:      	ubfx	x0, x0, #0, #32
    c988:      	lsr	x16, x0, #0
    c98c:      	cmp	x16, #0x1
    c990:      	b.eq	0xc9ac <_stogir.placement.use-block+0x360>
    c994:      	b.lo	0xc99c <_stogir.placement.use-block+0x350>
    c998:      	b	0xc9b0 <_stogir.placement.use-block+0x364>
    c99c:      	cmp	x16, #0x0
    c9a0:      	b.eq	0xc9a8 <_stogir.placement.use-block+0x35c>
    c9a4:      	b	0xc9b0 <_stogir.placement.use-block+0x364>
    c9a8:      	b	0xc9b4 <_stogir.placement.use-block+0x368>
    c9ac:      	b	0xc9dc <_stogir.placement.use-block+0x390>
    c9b0:      	b	0xca80 <_stogir.placement.use-block+0x434>
    c9b4:      	mov	x1, #0x1                ; =1
    c9b8:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c9b8:  ARM64_RELOC_PAGE21	l_stogir.503
    c9bc:      	ldr	x0, [x0]
		000000000000c9bc:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    c9c0:      	mov	x2, #0x17               ; =23
    c9c4:      	b	0xc9d8 <_stogir.placement.use-block+0x38c>
    c9c8:      	mov	x1, #0x1                ; =1
    c9cc:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000c9cc:  ARM64_RELOC_PAGE21	l_stogir.504
    c9d0:      	ldr	x0, [x0]
		000000000000c9d0:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    c9d4:      	mov	x2, #0x25               ; =37
    c9d8:      	b	0xc910 <_stogir.placement.use-block+0x2c4>
    c9dc:      	sxtw	x1, w1
    c9e0:      	cmp	x1, #0x0
    c9e4:      	b.le	0xc9c8 <_stogir.placement.use-block+0x37c>
    c9e8:      	lsl	x0, x1, #2
    c9ec:      	ldr	x2, [x20, #0x8]
    c9f0:      	cmp	x1, x2
    c9f4:      	b.ge	0xca40 <_stogir.placement.use-block+0x3f4>
    c9f8:      	add	x2, x20, #0x78
    c9fc:      	ldr	x2, [x2, #0x8]
    ca00:      	cmp	x1, x2
    ca04:      	b.ge	0xca38 <_stogir.placement.use-block+0x3ec>
    ca08:      	ldr	x1, [x20, #0x78]
    ca0c:      	add	x1, x0, x1
    ca10:      	ldr	w1, [x1]
    ca14:      	sxtw	x1, w1
    ca18:      	cmp	x1, #0x0
    ca1c:      	cset	w1, ge
    ca20:      	ubfx	x1, x1, #0, #8
    ca24:      	b	0xca3c <_stogir.placement.use-block+0x3f0>
    ca28:      	and	x0, x0, #0xffffffff
    ca2c:      	movz	x1, #0x0, lsl #48
    ca30:      	movz	x2, #0x0, lsl #48
    ca34:      	b	0xc9d8 <_stogir.placement.use-block+0x38c>
    ca38:      	movz	x1, #0x0, lsl #48
    ca3c:      	b	0xca44 <_stogir.placement.use-block+0x3f8>
    ca40:      	movz	x1, #0x0, lsl #48
    ca44:      	cmp	x1, #0x0
    ca48:      	b.eq	0xc9c8 <_stogir.placement.use-block+0x37c>
    ca4c:      	ldr	x1, [x21]
    ca50:      	add	x0, x0, x1
    ca54:      	ldr	w0, [x0]
    ca58:      	sxtw	x0, w0
    ca5c:      	cmp	x0, #0x0
    ca60:      	b.ne	0xca28 <_stogir.placement.use-block+0x3dc>
    ca64:      	mov	x1, #0x1                ; =1
    ca68:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000ca68:  ARM64_RELOC_PAGE21	l_stogir.505
    ca6c:      	ldr	x0, [x0]
		000000000000ca6c:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    ca70:      	mov	x2, #0x1a               ; =26
    ca74:      	b	0xca34 <_stogir.placement.use-block+0x3e8>
    ca78:      	brk	#0
    ca7c:      	b	0xca78 <_stogir.placement.use-block+0x42c>
    ca80:      	brk	#0
    ca84:      	b	0xca80 <_stogir.placement.use-block+0x434>
    ca88:      	mov	x19, x8
    ca8c:      	b	0xc7e4 <_stogir.placement.use-block+0x198>
    ca90:      	mov	x19, x8
    ca94:      	mov	x21, x1
    ca98:      	b	0xc890 <_stogir.placement.use-block+0x244>
    ca9c:      	mov	x19, x8
    caa0:      	mov	x21, x1
    caa4:      	b	0xc890 <_stogir.placement.use-block+0x244>

000000000000caa8 <_stogir.placement.choose-block>:
    caa8:      	sxtw	x2, w2
    caac:      	sxtw	x4, w3
    cab0:      	mov	x6, x4
    cab4:      	movz	x5, #0x0, lsl #48
    cab8:      	movz	x7, #0x0, lsl #48
    cabc:      	b	0xcacc <_stogir.placement.choose-block+0x24>
    cac0:      	mov	x6, x9
    cac4:      	b	0xcacc <_stogir.placement.choose-block+0x24>
    cac8:      	mov	x5, #0x1                ; =1
    cacc:      	cmp	x5, #0x0
    cad0:      	b.ne	0xcb1c <_stogir.placement.choose-block+0x74>
    cad4:      	cmp	x6, #0x0
    cad8:      	b.le	0xcac8 <_stogir.placement.choose-block+0x20>
    cadc:      	ldr	x9, [x0, #0x8]
    cae0:      	cmp	x6, x9
    cae4:      	b.ge	0xcac8 <_stogir.placement.choose-block+0x20>
    cae8:      	ldr	x9, [x0]
    caec:      	add	x9, x9, x6, lsl #2
    caf0:      	ldr	w9, [x9]
    caf4:      	sxtw	x9, w9
    caf8:      	cmp	x9, #0x0
    cafc:      	b.ne	0xcb08 <_stogir.placement.choose-block+0x60>
    cb00:      	mov	x5, #0x1                ; =1
    cb04:      	b	0xcac4 <_stogir.placement.choose-block+0x1c>
    cb08:      	cmp	x6, x2
    cb0c:      	b.ne	0xcb28 <_stogir.placement.choose-block+0x80>
    cb10:      	mov	x5, #0x1                ; =1
    cb14:      	mov	x7, #0x1                ; =1
    cb18:      	b	0xcac4 <_stogir.placement.choose-block+0x1c>
    cb1c:      	cmp	x7, #0x0
    cb20:      	b.eq	0xcb94 <_stogir.placement.choose-block+0xec>
    cb24:      	b	0xcb3c <_stogir.placement.choose-block+0x94>
    cb28:      	cmp	x6, x9
    cb2c:      	b.ne	0xcac0 <_stogir.placement.choose-block+0x18>
    cb30:      	mov	x5, #0x1                ; =1
    cb34:      	b	0xcac4 <_stogir.placement.choose-block+0x1c>
    cb38:      	mov	x4, x5
    cb3c:      	sxtw	x3, w3
    cb40:      	cmp	x3, x2
    cb44:      	b.eq	0xcb84 <_stogir.placement.choose-block+0xdc>
    cb48:      	ldr	x5, [x0]
    cb4c:      	add	x3, x5, x3, lsl #2
    cb50:      	ldr	w3, [x3]
    cb54:      	sxtw	x5, w3
    cb58:      	ldr	x6, [x1]
    cb5c:      	orr	x7, x6, xzr
    cb60:      	add	x7, x7, x5, lsl #2
    cb64:      	add	x6, x6, x4, lsl #2
    cb68:      	ldr	w7, [x7]
    cb6c:      	sxtw	x7, w7
    cb70:      	ldr	w6, [x6]
    cb74:      	sxtw	x6, w6
    cb78:      	cmp	x7, x6
    cb7c:      	b.lt	0xcb38 <_stogir.placement.choose-block+0x90>
    cb80:      	b	0xcb3c <_stogir.placement.choose-block+0x94>
    cb84:      	and	x0, x4, #0xffffffff
    cb88:      	movz	x1, #0x0, lsl #48
    cb8c:      	movz	x2, #0x0, lsl #48
    cb90:      	b	0xcba4 <_stogir.placement.choose-block+0xfc>
    cb94:      	mov	x1, #0x1                ; =1
    cb98:      	adrp	x0, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000cb98:  ARM64_RELOC_PAGE21	l_stogir.506
    cb9c:      	ldr	x0, [x0]
		000000000000cb9c:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    cba0:      	mov	x2, #0x29               ; =41
    cba4:      	str	x1, [x8]
    cba8:      	str	x0, [x8, #0x8]
    cbac:      	str	x2, [x8, #0x10]
    cbb0:      	ret

000000000000cbb4 <_stogir.checked.validate-projection>:
    cbb4:      	sub	sp, sp, #0x40
    cbb8:      	str	x29, [sp]
    cbbc:      	str	x30, [sp, #0x8]
    cbc0:      	mov	x29, sp
    cbc4:      	str	x19, [sp, #0x30]
    cbc8:      	sxtw	x1, w1
    cbcc:      	lsl	x2, x1, #2
    cbd0:      	cmp	x1, #0x0
    cbd4:      	cset	w3, gt
    cbd8:      	movz	x16, #0x0, lsl #48
    cbdc:      	sub	x4, x16, x1
    cbe0:      	sub	x5, x4, #0x1
    cbe4:      	uxtb	w16, w3
    cbe8:      	cmp	w16, wzr
    cbec:      	b.eq	0xcc2c <_stogir.checked.validate-projection+0x78>
    cbf0:      	ldr	x4, [x0, #0x8]
    cbf4:      	cmp	x1, x4
    cbf8:      	b.ge	0xcc7c <_stogir.checked.validate-projection+0xc8>
    cbfc:      	add	x4, x0, #0x78
    cc00:      	ldr	x4, [x4, #0x8]
    cc04:      	cmp	x1, x4
    cc08:      	b.ge	0xcd4c <_stogir.checked.validate-projection+0x198>
    cc0c:      	ldr	x4, [x0, #0x78]
    cc10:      	add	x4, x2, x4
    cc14:      	ldr	w4, [x4]
    cc18:      	sxtw	x4, w4
    cc1c:      	cmp	x4, #0x0
    cc20:      	cset	w4, ge
    cc24:      	ubfx	x4, x4, #0, #8
    cc28:      	b	0xcd50 <_stogir.checked.validate-projection+0x19c>
    cc2c:      	cmp	x1, #0x0
    cc30:      	b.ge	0xcc84 <_stogir.checked.validate-projection+0xd0>
    cc34:      	add	x6, x0, #0x28
    cc38:      	add	x7, x0, #0x50
    cc3c:      	ldr	x6, [x6, #0x8]
    cc40:      	ldr	x7, [x7, #0x8]
    cc44:      	cmp	x6, x7
    cc48:      	b.ne	0xcc74 <_stogir.checked.validate-projection+0xc0>
    cc4c:      	cmp	x4, x6
    cc50:      	b.gt	0xcdb8 <_stogir.checked.validate-projection+0x204>
    cc54:      	ldr	x4, [x0, #0x50]
    cc58:      	add	x4, x4, x5, lsl #2
    cc5c:      	ldr	w4, [x4]
    cc60:      	sxtw	x4, w4
    cc64:      	cmp	x4, #0x0
    cc68:      	cset	w4, gt
    cc6c:      	ubfx	x4, x4, #0, #8
    cc70:      	b	0xcdbc <_stogir.checked.validate-projection+0x208>
    cc74:      	movz	x4, #0x0, lsl #48
    cc78:      	b	0xcc88 <_stogir.checked.validate-projection+0xd4>
    cc7c:      	movz	x4, #0x0, lsl #48
    cc80:      	b	0xcc88 <_stogir.checked.validate-projection+0xd4>
    cc84:      	movz	x4, #0x0, lsl #48
    cc88:      	cmp	x4, #0x0
    cc8c:      	b.eq	0xccc0 <_stogir.checked.validate-projection+0x10c>
    cc90:      	uxtb	w16, w3
    cc94:      	cmp	w16, wzr
    cc98:      	b.eq	0xccac <_stogir.checked.validate-projection+0xf8>
    cc9c:      	ldr	x3, [x0]
    cca0:      	add	x3, x3, x1, lsl #4
    cca4:      	ldr	x3, [x3]
    cca8:      	b	0xccb8 <_stogir.checked.validate-projection+0x104>
    ccac:      	ldr	x3, [x0, #0x28]
    ccb0:      	add	x3, x3, x5, lsl #4
    ccb4:      	ldr	x3, [x3]
    ccb8:      	mov	w4, #0x1                ; =1
    ccbc:      	b	0xccc8 <_stogir.checked.validate-projection+0x114>
    ccc0:      	movz	w4, #0x0, lsl #16
    ccc4:      	movz	x3, #0x0, lsl #48
    ccc8:      	ubfx	x4, x4, #0, #32
    cccc:      	lsr	x16, x4, #0
    ccd0:      	cmp	x16, #0x1
    ccd4:      	b.eq	0xccf0 <_stogir.checked.validate-projection+0x13c>
    ccd8:      	b.lo	0xcce0 <_stogir.checked.validate-projection+0x12c>
    ccdc:      	b	0xccf4 <_stogir.checked.validate-projection+0x140>
    cce0:      	cmp	x16, #0x0
    cce4:      	b.eq	0xccec <_stogir.checked.validate-projection+0x138>
    cce8:      	b	0xccf4 <_stogir.checked.validate-projection+0x140>
    ccec:      	b	0xccf8 <_stogir.checked.validate-projection+0x144>
    ccf0:      	b	0xcd10 <_stogir.checked.validate-projection+0x15c>
    ccf4:      	b	0xcdc0 <_stogir.checked.validate-projection+0x20c>
    ccf8:      	mov	x19, x8
    ccfc:      	mov	x0, #0x1                ; =1
    cd00:      	adrp	x1, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000cd00:  ARM64_RELOC_PAGE21	l_stogir.507
    cd04:      	ldr	x1, [x1]
		000000000000cd04:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    cd08:      	mov	x2, #0x10               ; =16
    cd0c:      	b	0xcd2c <_stogir.checked.validate-projection+0x178>
    cd10:      	cmp	x1, #0x0
    cd14:      	b.gt	0xcd54 <_stogir.checked.validate-projection+0x1a0>
    cd18:      	mov	x19, x8
    cd1c:      	mov	x0, #0x1                ; =1
    cd20:      	adrp	x1, 0xc000 <_stogir.dominators.build-index+0x628>
		000000000000cd20:  ARM64_RELOC_PAGE21	l_stogir.508
    cd24:      	ldr	x1, [x1]
		000000000000cd24:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    cd28:      	mov	x2, #0x1c               ; =28
    cd2c:      	str	x0, [x19]
    cd30:      	str	x1, [x19, #0x8]
    cd34:      	str	x2, [x19, #0x10]
    cd38:      	ldr	x19, [sp, #0x30]
    cd3c:      	ldr	x29, [sp]
    cd40:      	ldr	x30, [sp, #0x8]
    cd44:      	add	sp, sp, #0x40
    cd48:      	ret
    cd4c:      	movz	x4, #0x0, lsl #48
    cd50:      	b	0xcc80 <_stogir.checked.validate-projection+0xcc>
    cd54:      	uxtb	w1, w3
    cd58:      	cmp	x1, #0x2c
    cd5c:      	b.ne	0xcdc8 <_stogir.checked.validate-projection+0x214>
    cd60:      	orr	w1, w3, wzr
    cd64:      	ubfx	x1, x1, #0, #32
    cd68:      	ubfx	x1, x1, #8, #8
    cd6c:      	cmp	x1, #0x1
    cd70:      	b.ne	0xcdd0 <_stogir.checked.validate-projection+0x21c>
    cd74:      	ldr	x1, [x0, #0x78]
    cd78:      	add	x1, x2, x1
    cd7c:      	ldr	w1, [x1]
    cd80:      	sxtw	x1, w1
    cd84:      	cmp	x1, #0x1
    cd88:      	b.ne	0xcdd8 <_stogir.checked.validate-projection+0x224>
    cd8c:      	lsr	x1, x3, #32
    cd90:      	mov	x19, x8
    cd94:      	add	x8, sp, #0x10
    cd98:      	bl	0xcd98 <_stogir.checked.validate-projection+0x1e4>
		000000000000cd98:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    cd9c:      	add	x16, sp, #0x10
    cda0:      	ldr	x0, [x16]
    cda4:      	add	x16, sp, #0x10
    cda8:      	ldr	x1, [x16, #0x8]
    cdac:      	add	x16, sp, #0x10
    cdb0:      	ldr	x2, [x16, #0x10]
    cdb4:      	b	0xcd2c <_stogir.checked.validate-projection+0x178>
    cdb8:      	movz	x4, #0x0, lsl #48
    cdbc:      	b	0xcc78 <_stogir.checked.validate-projection+0xc4>
    cdc0:      	brk	#0
    cdc4:      	b	0xcdc0 <_stogir.checked.validate-projection+0x20c>
    cdc8:      	mov	x19, x8
    cdcc:      	b	0xcd1c <_stogir.checked.validate-projection+0x168>
    cdd0:      	mov	x19, x8
    cdd4:      	b	0xcd1c <_stogir.checked.validate-projection+0x168>
    cdd8:      	mov	x19, x8
    cddc:      	b	0xcd1c <_stogir.checked.validate-projection+0x168>

000000000000cde0 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge>:
    cde0:      	ldr	x1, [x0]
    cde4:      	ldr	x0, [x0, #0x8]
    cde8:      	str	x1, [x8]
    cdec:      	str	x0, [x8, #0x8]
    cdf0:      	movz	x17, #0x0, lsl #48
    cdf4:      	str	x17, [x8, #0x10]
    cdf8:      	ret

000000000000cdfc <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64>:
    cdfc:      	ldr	x1, [x0]
    ce00:      	ldr	x0, [x0, #0x8]
    ce04:      	str	x1, [x8]
    ce08:      	str	x0, [x8, #0x8]
    ce0c:      	movz	x17, #0x0, lsl #48
    ce10:      	str	x17, [x8, #0x10]
    ce14:      	ret

000000000000ce18 <_stogir.loops.heapify!>:
    ce18:      	sub	sp, sp, #0x20
    ce1c:      	str	x19, [sp]
    ce20:      	str	x20, [sp, #0x8]
    ce24:      	str	x21, [sp, #0x10]
    ce28:      	orr	x4, x0, xzr
    ce2c:      	orr	x5, x0, xzr
    ce30:      	orr	x6, x0, xzr
    ce34:      	orr	x7, x3, xzr
    ce38:      	ldr	x8, [x1, #0x8]
    ce3c:      	asr	x16, x8, #63
    ce40:      	lsr	x16, x16, #63
    ce44:      	add	x8, x8, x16
    ce48:      	asr	x8, x8, #1
    ce4c:      	cmp	x8, #0x0
    ce50:      	b.le	0xcfcc <_stogir.loops.heapify!+0x1b4>
    ce54:      	sub	x8, x8, #0x1
    ce58:      	ldr	x9, [x1]
    ce5c:      	ldr	x10, [x1, #0x8]
    ce60:      	mov	x12, x8
    ce64:      	movz	x11, #0x0, lsl #48
    ce68:      	b	0xceac <_stogir.loops.heapify!+0x94>
    ce6c:      	nop
    ce70:      	add	x12, x9, x12
    ce74:      	add	x14, x9, x13
    ce78:      	ldr	x15, [x6]
    ce7c:      	orr	x19, x15, xzr
    ce80:      	orr	x20, x15, xzr
    ce84:      	add	x19, x19, x12, lsl #3
    ce88:      	add	x20, x20, x14, lsl #3
    ce8c:      	add	x12, x15, x12, lsl #3
    ce90:      	ldr	x15, [x19]
    ce94:      	ldr	x19, [x20]
    ce98:      	str	x19, [x12]
    ce9c:      	ldr	x12, [x0]
    cea0:      	add	x12, x12, x14, lsl #3
    cea4:      	str	x15, [x12]
    cea8:      	mov	x12, x13
    ceac:      	cmp	x11, #0x0
    ceb0:      	b.ne	0xce4c <_stogir.loops.heapify!+0x34>
    ceb4:      	lsl	x13, x12, #1
    ceb8:      	add	x13, x13, #0x1
    cebc:      	cmp	x13, x10
    cec0:      	b.ge	0xce4c <_stogir.loops.heapify!+0x34>
    cec4:      	lsl	x13, x12, #1
    cec8:      	add	x13, x13, #0x1
    cecc:      	add	x14, x13, #0x1
    ced0:      	cmp	x14, x10
    ced4:      	b.ge	0xcf50 <_stogir.loops.heapify!+0x138>
    ced8:      	add	x14, x13, x9
    cedc:      	ldr	x15, [x4]
    cee0:      	add	x19, x14, #0x1
    cee4:      	orr	x20, x15, xzr
    cee8:      	add	x14, x15, x14, lsl #3
    ceec:      	add	x15, x20, x19, lsl #3
    cef0:      	ldr	x15, [x15]
    cef4:      	ldr	x14, [x14]
    cef8:      	ldr	x19, [x2, #0x50]
    cefc:      	orr	x20, x19, xzr
    cf00:      	add	x20, x20, x15, lsl #4
    cf04:      	add	x19, x19, x14, lsl #4
    cf08:      	ldr	x20, [x20]
    cf0c:      	ldr	x21, [x7]
    cf10:      	asr	x20, x20, #32
    cf14:      	add	x20, x21, x20, lsl #2
    cf18:      	ldr	w20, [x20]
    cf1c:      	sxtw	x20, w20
    cf20:      	ldr	x19, [x19]
    cf24:      	asr	x19, x19, #32
    cf28:      	add	x19, x21, x19, lsl #2
    cf2c:      	ldr	w19, [x19]
    cf30:      	sxtw	x19, w19
    cf34:      	cmp	x20, x19
    cf38:      	b.lt	0xcf4c <_stogir.loops.heapify!+0x134>
    cf3c:      	cmp	x20, x19
    cf40:      	b.ne	0xcf50 <_stogir.loops.heapify!+0x138>
    cf44:      	cmp	x15, x14
    cf48:      	b.le	0xcf50 <_stogir.loops.heapify!+0x138>
    cf4c:      	add	x13, x13, #0x1
    cf50:      	add	x14, x9, x12
    cf54:      	ldr	x15, [x5]
    cf58:      	add	x19, x9, x13
    cf5c:      	orr	x20, x15, xzr
    cf60:      	add	x14, x15, x14, lsl #3
    cf64:      	add	x15, x20, x19, lsl #3
    cf68:      	ldr	x15, [x15]
    cf6c:      	ldr	x14, [x14]
    cf70:      	ldr	x19, [x2, #0x50]
    cf74:      	orr	x20, x19, xzr
    cf78:      	add	x20, x20, x15, lsl #4
    cf7c:      	add	x19, x19, x14, lsl #4
    cf80:      	ldr	x20, [x20]
    cf84:      	ldr	x21, [x3]
    cf88:      	asr	x20, x20, #32
    cf8c:      	add	x20, x21, x20, lsl #2
    cf90:      	ldr	w20, [x20]
    cf94:      	sxtw	x20, w20
    cf98:      	ldr	x19, [x19]
    cf9c:      	asr	x19, x19, #32
    cfa0:      	add	x19, x21, x19, lsl #2
    cfa4:      	ldr	w19, [x19]
    cfa8:      	sxtw	x19, w19
    cfac:      	cmp	x20, x19
    cfb0:      	b.lt	0xce70 <_stogir.loops.heapify!+0x58>
    cfb4:      	cmp	x20, x19
    cfb8:      	b.ne	0xcfc4 <_stogir.loops.heapify!+0x1ac>
    cfbc:      	cmp	x15, x14
    cfc0:      	b.gt	0xce70 <_stogir.loops.heapify!+0x58>
    cfc4:      	mov	x11, #0x1               ; =1
    cfc8:      	b	0xceac <_stogir.loops.heapify!+0x94>
    cfcc:      	ldr	x19, [sp]
    cfd0:      	ldr	x20, [sp, #0x8]
    cfd4:      	ldr	x21, [sp, #0x10]
    cfd8:      	add	sp, sp, #0x20
    cfdc:      	ret

000000000000cfe0 <_stogir.loops.sift!>:
    cfe0:      	sub	sp, sp, #0x10
    cfe4:      	str	x19, [sp]
    cfe8:      	orr	x6, x0, xzr
    cfec:      	orr	x7, x0, xzr
    cff0:      	orr	x8, x0, xzr
    cff4:      	orr	x9, x5, xzr
    cff8:      	movz	x10, #0x0, lsl #48
    cffc:      	b	0xd03c <_stogir.loops.sift!+0x5c>
    d000:      	add	x3, x1, x3
    d004:      	add	x12, x1, x11
    d008:      	ldr	x13, [x8]
    d00c:      	orr	x14, x13, xzr
    d010:      	orr	x15, x13, xzr
    d014:      	add	x14, x14, x3, lsl #3
    d018:      	add	x15, x15, x12, lsl #3
    d01c:      	add	x3, x13, x3, lsl #3
    d020:      	ldr	x13, [x14]
    d024:      	ldr	x14, [x15]
    d028:      	str	x14, [x3]
    d02c:      	ldr	x3, [x0]
    d030:      	add	x3, x3, x12, lsl #3
    d034:      	str	x13, [x3]
    d038:      	mov	x3, x11
    d03c:      	cmp	x10, #0x0
    d040:      	b.ne	0xd15c <_stogir.loops.sift!+0x17c>
    d044:      	lsl	x11, x3, #1
    d048:      	add	x11, x11, #0x1
    d04c:      	cmp	x11, x2
    d050:      	b.ge	0xd15c <_stogir.loops.sift!+0x17c>
    d054:      	lsl	x11, x3, #1
    d058:      	add	x11, x11, #0x1
    d05c:      	add	x12, x11, #0x1
    d060:      	cmp	x12, x2
    d064:      	b.ge	0xd0e0 <_stogir.loops.sift!+0x100>
    d068:      	add	x12, x11, x1
    d06c:      	ldr	x13, [x6]
    d070:      	add	x14, x12, #0x1
    d074:      	orr	x15, x13, xzr
    d078:      	add	x12, x13, x12, lsl #3
    d07c:      	add	x13, x15, x14, lsl #3
    d080:      	ldr	x13, [x13]
    d084:      	ldr	x12, [x12]
    d088:      	ldr	x14, [x4, #0x50]
    d08c:      	orr	x15, x14, xzr
    d090:      	add	x15, x15, x13, lsl #4
    d094:      	add	x14, x14, x12, lsl #4
    d098:      	ldr	x15, [x15]
    d09c:      	ldr	x19, [x9]
    d0a0:      	asr	x15, x15, #32
    d0a4:      	add	x15, x19, x15, lsl #2
    d0a8:      	ldr	w15, [x15]
    d0ac:      	sxtw	x15, w15
    d0b0:      	ldr	x14, [x14]
    d0b4:      	asr	x14, x14, #32
    d0b8:      	add	x14, x19, x14, lsl #2
    d0bc:      	ldr	w14, [x14]
    d0c0:      	sxtw	x14, w14
    d0c4:      	cmp	x15, x14
    d0c8:      	b.lt	0xd0dc <_stogir.loops.sift!+0xfc>
    d0cc:      	cmp	x15, x14
    d0d0:      	b.ne	0xd0e0 <_stogir.loops.sift!+0x100>
    d0d4:      	cmp	x13, x12
    d0d8:      	b.le	0xd0e0 <_stogir.loops.sift!+0x100>
    d0dc:      	add	x11, x11, #0x1
    d0e0:      	add	x12, x1, x3
    d0e4:      	ldr	x13, [x7]
    d0e8:      	add	x14, x1, x11
    d0ec:      	orr	x15, x13, xzr
    d0f0:      	add	x12, x13, x12, lsl #3
    d0f4:      	add	x13, x15, x14, lsl #3
    d0f8:      	ldr	x13, [x13]
    d0fc:      	ldr	x12, [x12]
    d100:      	ldr	x14, [x4, #0x50]
    d104:      	orr	x15, x14, xzr
    d108:      	add	x15, x15, x13, lsl #4
    d10c:      	add	x14, x14, x12, lsl #4
    d110:      	ldr	x15, [x15]
    d114:      	ldr	x19, [x5]
    d118:      	asr	x15, x15, #32
    d11c:      	add	x15, x19, x15, lsl #2
    d120:      	ldr	w15, [x15]
    d124:      	sxtw	x15, w15
    d128:      	ldr	x14, [x14]
    d12c:      	asr	x14, x14, #32
    d130:      	add	x14, x19, x14, lsl #2
    d134:      	ldr	w14, [x14]
    d138:      	sxtw	x14, w14
    d13c:      	cmp	x15, x14
    d140:      	b.lt	0xd000 <_stogir.loops.sift!+0x20>
    d144:      	cmp	x15, x14
    d148:      	b.ne	0xd154 <_stogir.loops.sift!+0x174>
    d14c:      	cmp	x13, x12
    d150:      	b.gt	0xd000 <_stogir.loops.sift!+0x20>
    d154:      	mov	x10, #0x1               ; =1
    d158:      	b	0xd03c <_stogir.loops.sift!+0x5c>
    d15c:      	ldr	x19, [sp]
    d160:      	add	sp, sp, #0x10
    d164:      	ret

000000000000d168 <_stogir.opcode.block-end?>:
    d168:      	sxtw	x0, w0
    d16c:      	cmp	x0, #0x0
    d170:      	b.lt	0xd190 <_stogir.opcode.block-end?+0x28>
    d174:      	cmp	x0, #0x83
    d178:      	b.ge	0xd190 <_stogir.opcode.block-end?+0x28>
    d17c:      	adrp	x16, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000d17c:  ARM64_RELOC_PAGE21	l_stogir.509
    d180:      	ldr	x16, [x16]
		000000000000d180:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    d184:      	add	x0, x16, x0
    d188:      	ldrb	w0, [x0]
    d18c:      	b	0xd194 <_stogir.opcode.block-end?+0x2c>
    d190:      	movz	w0, #0x0, lsl #16
    d194:      	uxtb	w16, w0
    d198:      	and	w0, w16, #0x4
    d19c:      	uxtb	w0, w0
    d1a0:      	ubfx	x0, x0, #0, #8
    d1a4:      	cmp	x0, #0x0
    d1a8:      	cset	w0, eq
    d1ac:      	uxtb	w16, w0
    d1b0:      	cmp	w16, wzr
    d1b4:      	cset	x0, eq
    d1b8:      	ret

000000000000d1bc <_stogir.schedule.entry-prefix>:
    d1bc:      	sub	sp, sp, #0x90
    d1c0:      	str	x29, [sp]
    d1c4:      	str	x30, [sp, #0x8]
    d1c8:      	mov	x29, sp
    d1cc:      	str	x19, [sp, #0x40]
    d1d0:      	str	x20, [sp, #0x48]
    d1d4:      	str	x21, [sp, #0x50]
    d1d8:      	str	x22, [sp, #0x58]
    d1dc:      	str	x23, [sp, #0x60]
    d1e0:      	str	x24, [sp, #0x68]
    d1e4:      	str	x25, [sp, #0x70]
    d1e8:      	str	x26, [sp, #0x78]
    d1ec:      	str	x27, [sp, #0x80]
    d1f0:      	str	x28, [sp, #0x88]
    d1f4:      	orr	x19, x0, xzr
    d1f8:      	add	x16, sp, #0x10
    d1fc:      	orr	x20, x16, xzr
    d200:      	ldr	x0, [x2]
    d204:      	ldr	x2, [x2, #0x8]
    d208:      	add	x16, sp, #0x10
    d20c:      	movz	x17, #0x0, lsl #48
    d210:      	str	x17, [x16]
    d214:      	add	x16, sp, #0x10
    d218:      	movz	x17, #0x0, lsl #48
    d21c:      	str	x17, [x16, #0x8]
    d220:      	add	x16, sp, #0x10
    d224:      	movz	x17, #0x0, lsl #48
    d228:      	str	x17, [x16, #0x10]
    d22c:      	add	x16, sp, #0x10
    d230:      	str	x0, [x16, #0x18]
    d234:      	add	x16, sp, #0x10
    d238:      	str	x2, [x16, #0x20]
    d23c:      	movz	x21, #0x0, lsl #48
    d240:      	b	0xd324 <_stogir.schedule.entry-prefix+0x168>
    d244:      	lsl	x0, x0, #1
    d248:      	mov	x27, x8
    d24c:      	mov	x28, x1
    d250:      	mov	x1, x0
    d254:      	mov	x0, x20
    d258:      	bl	0xd258 <_stogir.schedule.entry-prefix+0x9c>
		000000000000d258:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    d25c:      	add	x0, x26, #0x1
    d260:      	add	x16, sp, #0x10
    d264:      	ldr	x1, [x16]
    d268:      	add	x1, x1, x26, lsl #2
    d26c:      	str	w25, [x1]
    d270:      	add	x16, sp, #0x10
    d274:      	str	x0, [x16, #0x8]
    d278:      	mov	x8, x27
    d27c:      	mov	x1, x28
    d280:      	cmp	x24, x23
    d284:      	b.ge	0xd2a8 <_stogir.schedule.entry-prefix+0xec>
    d288:      	add	x0, x24, #0x1
    d28c:      	add	x2, x22, x24, lsl #2
    d290:      	ldr	w2, [x2]
    d294:      	movn	w17, #0x0, lsl #16
    d298:      	and	w25, w2, w17
    d29c:      	mov	x24, x0
    d2a0:      	mov	w0, #0x1                ; =1
    d2a4:      	b	0xd2b0 <_stogir.schedule.entry-prefix+0xf4>
    d2a8:      	movz	w0, #0x0, lsl #16
    d2ac:      	movz	w25, #0x0, lsl #16
    d2b0:      	ubfx	x0, x0, #0, #32
    d2b4:      	lsr	x16, x0, #0
    d2b8:      	cmp	x16, #0x1
    d2bc:      	b.eq	0xd2e0 <_stogir.schedule.entry-prefix+0x124>
    d2c0:      	b.lo	0xd2c8 <_stogir.schedule.entry-prefix+0x10c>
    d2c4:      	b	0xd2e4 <_stogir.schedule.entry-prefix+0x128>
    d2c8:      	cmp	x16, #0x0
    d2cc:      	b.eq	0xd2d4 <_stogir.schedule.entry-prefix+0x118>
    d2d0:      	b	0xd2e4 <_stogir.schedule.entry-prefix+0x128>
    d2d4:      	mov	x27, x8
    d2d8:      	mov	x28, x1
    d2dc:      	b	0xd318 <_stogir.schedule.entry-prefix+0x15c>
    d2e0:      	b	0xd2e8 <_stogir.schedule.entry-prefix+0x12c>
    d2e4:      	b	0xd440 <_stogir.schedule.entry-prefix+0x284>
    d2e8:      	sxtw	x0, w25
    d2ec:      	ldr	x2, [x19]
    d2f0:      	add	x0, x2, x0, lsl #4
    d2f4:      	ldr	x0, [x0]
    d2f8:      	uxtb	w0, w0
    d2fc:      	cmp	x0, #0x83
    d300:      	b.ge	0xd344 <_stogir.schedule.entry-prefix+0x188>
    d304:      	adrp	x17, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000d304:  ARM64_RELOC_PAGE21	l_stogir.510
    d308:      	ldr	x17, [x17]
		000000000000d308:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    d30c:      	add	x2, x0, x17
    d310:      	ldrb	w2, [x2]
    d314:      	b	0xd348 <_stogir.schedule.entry-prefix+0x18c>
    d318:      	add	x21, x21, #0x1
    d31c:      	mov	x8, x27
    d320:      	mov	x1, x28
    d324:      	cmp	x21, #0x3
    d328:      	b.ge	0xd448 <_stogir.schedule.entry-prefix+0x28c>
    d32c:      	ldr	x0, [x1]
    d330:      	orr	x22, x0, xzr
    d334:      	ldr	x0, [x1, #0x8]
    d338:      	orr	x23, x0, xzr
    d33c:      	movz	x24, #0x0, lsl #48
    d340:      	b	0xd280 <_stogir.schedule.entry-prefix+0xc4>
    d344:      	movz	w2, #0x0, lsl #16
    d348:      	uxtb	w16, w2
    d34c:      	and	w2, w16, #0x2
    d350:      	uxtb	w2, w2
    d354:      	ubfx	x2, x2, #0, #8
    d358:      	cmp	x2, #0x0
    d35c:      	cset	w2, eq
    d360:      	uxtb	w16, w2
    d364:      	cmp	w16, wzr
    d368:      	cset	x2, eq
    d36c:      	cmp	x2, #0x0
    d370:      	b.eq	0xd37c <_stogir.schedule.entry-prefix+0x1c0>
    d374:      	movz	x0, #0x0, lsl #48
    d378:      	b	0xd398 <_stogir.schedule.entry-prefix+0x1dc>
    d37c:      	cmp	x0, #0x47
    d380:      	cset	w0, eq
    d384:      	uxtb	w16, w0
    d388:      	cmp	w16, wzr
    d38c:      	mov	x16, #0x1               ; =1
    d390:      	mov	x17, #0x2               ; =2
    d394:      	csel	x0, x16, x17, ne
    d398:      	cmp	x0, x21
    d39c:      	b.ne	0xd450 <_stogir.schedule.entry-prefix+0x294>
    d3a0:      	add	x16, sp, #0x10
    d3a4:      	ldr	x0, [x16, #0x8]
    d3a8:      	orr	x26, x0, xzr
    d3ac:      	add	x16, sp, #0x10
    d3b0:      	ldr	x0, [x16, #0x10]
    d3b4:      	cmp	x26, x0
    d3b8:      	b.lt	0xd45c <_stogir.schedule.entry-prefix+0x2a0>
    d3bc:      	cmp	x0, #0x0
    d3c0:      	b.ne	0xd244 <_stogir.schedule.entry-prefix+0x88>
    d3c4:      	mov	x0, #0x2                ; =2
    d3c8:      	b	0xd248 <_stogir.schedule.entry-prefix+0x8c>
    d3cc:      	add	x16, sp, #0x10
    d3d0:      	ldr	x0, [x16]
    d3d4:      	add	x16, sp, #0x10
    d3d8:      	ldr	x1, [x16, #0x8]
    d3dc:      	add	x16, sp, #0x10
    d3e0:      	ldr	x2, [x16, #0x10]
    d3e4:      	add	x16, sp, #0x10
    d3e8:      	ldr	x3, [x16, #0x18]
    d3ec:      	add	x16, sp, #0x10
    d3f0:      	ldr	x4, [x16, #0x20]
    d3f4:      	str	x0, [x27]
    d3f8:      	str	x1, [x27, #0x8]
    d3fc:      	str	x2, [x27, #0x10]
    d400:      	str	x3, [x27, #0x18]
    d404:      	str	x4, [x27, #0x20]
    d408:      	ldr	x19, [sp, #0x40]
    d40c:      	ldr	x20, [sp, #0x48]
    d410:      	ldr	x21, [sp, #0x50]
    d414:      	ldr	x22, [sp, #0x58]
    d418:      	ldr	x23, [sp, #0x60]
    d41c:      	ldr	x24, [sp, #0x68]
    d420:      	ldr	x25, [sp, #0x70]
    d424:      	ldr	x26, [sp, #0x78]
    d428:      	ldr	x27, [sp, #0x80]
    d42c:      	ldr	x28, [sp, #0x88]
    d430:      	ldr	x29, [sp]
    d434:      	ldr	x30, [sp, #0x8]
    d438:      	add	sp, sp, #0x90
    d43c:      	ret
    d440:      	brk	#0
    d444:      	b	0xd440 <_stogir.schedule.entry-prefix+0x284>
    d448:      	mov	x27, x8
    d44c:      	b	0xd3cc <_stogir.schedule.entry-prefix+0x210>
    d450:      	mov	x27, x8
    d454:      	mov	x28, x1
    d458:      	b	0xd278 <_stogir.schedule.entry-prefix+0xbc>
    d45c:      	mov	x27, x8
    d460:      	mov	x28, x1
    d464:      	b	0xd25c <_stogir.schedule.entry-prefix+0xa0>

000000000000d468 <_stogir.checked-schedule.validate>:
    d468:      	sub	sp, sp, #0x40
    d46c:      	str	x29, [sp]
    d470:      	str	x30, [sp, #0x8]
    d474:      	mov	x29, sp
    d478:      	str	x19, [sp, #0x30]
    d47c:      	add	x1, x1, #0x28
    d480:      	mov	x19, x8
    d484:      	add	x8, sp, #0x10
    d488:      	bl	0xd488 <_stogir.checked-schedule.validate+0x20>
		000000000000d488:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    d48c:      	add	x16, sp, #0x10
    d490:      	ldr	x0, [x16]
    d494:      	str	x0, [x19]
    d498:      	add	x16, sp, #0x10
    d49c:      	ldr	x0, [x16, #0x8]
    d4a0:      	str	x0, [x19, #0x8]
    d4a4:      	add	x16, sp, #0x10
    d4a8:      	ldr	x0, [x16, #0x10]
    d4ac:      	str	x0, [x19, #0x10]
    d4b0:      	ldr	x19, [sp, #0x30]
    d4b4:      	ldr	x29, [sp]
    d4b8:      	ldr	x30, [sp, #0x8]
    d4bc:      	add	sp, sp, #0x40
    d4c0:      	ret

000000000000d4c4 <_stogir.checked.projection>:
    d4c4:      	sub	sp, sp, #0x40
    d4c8:      	str	x29, [sp]
    d4cc:      	str	x30, [sp, #0x8]
    d4d0:      	mov	x29, sp
    d4d4:      	str	x19, [sp, #0x30]
    d4d8:      	sxtw	x2, w1
    d4dc:      	cmp	x2, #0x0
    d4e0:      	cset	w3, gt
    d4e4:      	movz	x16, #0x0, lsl #48
    d4e8:      	sub	x4, x16, x2
    d4ec:      	sub	x5, x4, #0x1
    d4f0:      	uxtb	w16, w3
    d4f4:      	cmp	w16, wzr
    d4f8:      	b.eq	0xd538 <_stogir.checked.projection+0x74>
    d4fc:      	ldr	x4, [x0, #0x8]
    d500:      	cmp	x2, x4
    d504:      	b.ge	0xd588 <_stogir.checked.projection+0xc4>
    d508:      	add	x4, x0, #0x78
    d50c:      	ldr	x4, [x4, #0x8]
    d510:      	cmp	x2, x4
    d514:      	b.ge	0xd688 <_stogir.checked.projection+0x1c4>
    d518:      	ldr	x4, [x0, #0x78]
    d51c:      	add	x4, x4, x2, lsl #2
    d520:      	ldr	w4, [x4]
    d524:      	sxtw	x4, w4
    d528:      	cmp	x4, #0x0
    d52c:      	cset	w4, ge
    d530:      	ubfx	x4, x4, #0, #8
    d534:      	b	0xd68c <_stogir.checked.projection+0x1c8>
    d538:      	cmp	x2, #0x0
    d53c:      	b.ge	0xd590 <_stogir.checked.projection+0xcc>
    d540:      	add	x6, x0, #0x28
    d544:      	add	x7, x0, #0x50
    d548:      	ldr	x6, [x6, #0x8]
    d54c:      	ldr	x7, [x7, #0x8]
    d550:      	cmp	x6, x7
    d554:      	b.ne	0xd580 <_stogir.checked.projection+0xbc>
    d558:      	cmp	x4, x6
    d55c:      	b.gt	0xd6b8 <_stogir.checked.projection+0x1f4>
    d560:      	ldr	x4, [x0, #0x50]
    d564:      	add	x4, x4, x5, lsl #2
    d568:      	ldr	w4, [x4]
    d56c:      	sxtw	x4, w4
    d570:      	cmp	x4, #0x0
    d574:      	cset	w4, gt
    d578:      	ubfx	x4, x4, #0, #8
    d57c:      	b	0xd6bc <_stogir.checked.projection+0x1f8>
    d580:      	movz	x4, #0x0, lsl #48
    d584:      	b	0xd594 <_stogir.checked.projection+0xd0>
    d588:      	movz	x4, #0x0, lsl #48
    d58c:      	b	0xd594 <_stogir.checked.projection+0xd0>
    d590:      	movz	x4, #0x0, lsl #48
    d594:      	cmp	x4, #0x0
    d598:      	b.eq	0xd5cc <_stogir.checked.projection+0x108>
    d59c:      	uxtb	w16, w3
    d5a0:      	cmp	w16, wzr
    d5a4:      	b.eq	0xd5b8 <_stogir.checked.projection+0xf4>
    d5a8:      	ldr	x3, [x0]
    d5ac:      	add	x2, x3, x2, lsl #4
    d5b0:      	ldr	x2, [x2]
    d5b4:      	b	0xd5c4 <_stogir.checked.projection+0x100>
    d5b8:      	ldr	x2, [x0, #0x28]
    d5bc:      	add	x2, x2, x5, lsl #4
    d5c0:      	ldr	x2, [x2]
    d5c4:      	mov	w3, #0x1                ; =1
    d5c8:      	b	0xd5d4 <_stogir.checked.projection+0x110>
    d5cc:      	movz	w3, #0x0, lsl #16
    d5d0:      	movz	x2, #0x0, lsl #48
    d5d4:      	ubfx	x3, x3, #0, #32
    d5d8:      	lsr	x16, x3, #0
    d5dc:      	cmp	x16, #0x1
    d5e0:      	b.eq	0xd5fc <_stogir.checked.projection+0x138>
    d5e4:      	b.lo	0xd5ec <_stogir.checked.projection+0x128>
    d5e8:      	b	0xd600 <_stogir.checked.projection+0x13c>
    d5ec:      	cmp	x16, #0x0
    d5f0:      	b.eq	0xd5f8 <_stogir.checked.projection+0x134>
    d5f4:      	b	0xd600 <_stogir.checked.projection+0x13c>
    d5f8:      	b	0xd604 <_stogir.checked.projection+0x140>
    d5fc:      	b	0xd64c <_stogir.checked.projection+0x188>
    d600:      	b	0xd6c0 <_stogir.checked.projection+0x1fc>
    d604:      	mov	x19, x8
    d608:      	mov	x0, #0x1                ; =1
    d60c:      	adrp	x1, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000d60c:  ARM64_RELOC_PAGE21	l_stogir.511
    d610:      	ldr	x1, [x1]
		000000000000d610:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    d614:      	mov	x2, #0x17               ; =23
    d618:      	b	0xd62c <_stogir.checked.projection+0x168>
    d61c:      	mov	x0, #0x1                ; =1
    d620:      	adrp	x1, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000d620:  ARM64_RELOC_PAGE21	l_stogir.512
    d624:      	ldr	x1, [x1]
		000000000000d624:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    d628:      	mov	x2, #0x20               ; =32
    d62c:      	str	x0, [x19]
    d630:      	str	x1, [x19, #0x8]
    d634:      	str	x2, [x19, #0x10]
    d638:      	ldr	x19, [sp, #0x30]
    d63c:      	ldr	x29, [sp]
    d640:      	ldr	x30, [sp, #0x8]
    d644:      	add	sp, sp, #0x40
    d648:      	ret
    d64c:      	uxtb	w3, w2
    d650:      	cmp	x3, #0x29
    d654:      	b.lt	0xd6c8 <_stogir.checked.projection+0x204>
    d658:      	cmp	x3, #0x2b
    d65c:      	b.gt	0xd6d0 <_stogir.checked.projection+0x20c>
    d660:      	mov	x19, x8
    d664:      	add	x8, sp, #0x10
    d668:      	bl	0xd668 <_stogir.checked.projection+0x1a4>
		000000000000d668:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    d66c:      	add	x16, sp, #0x10
    d670:      	ldr	x0, [x16]
    d674:      	add	x16, sp, #0x10
    d678:      	ldr	x1, [x16, #0x8]
    d67c:      	add	x16, sp, #0x10
    d680:      	ldr	x2, [x16, #0x10]
    d684:      	b	0xd62c <_stogir.checked.projection+0x168>
    d688:      	movz	x4, #0x0, lsl #48
    d68c:      	b	0xd58c <_stogir.checked.projection+0xc8>
    d690:      	ubfx	x2, x2, #0, #32
    d694:      	ubfx	x0, x2, #8, #8
    d698:      	cmp	x0, #0x0
    d69c:      	b.eq	0xd61c <_stogir.checked.projection+0x158>
    d6a0:      	cmp	x0, #0xd
    d6a4:      	b.gt	0xd61c <_stogir.checked.projection+0x158>
    d6a8:      	movz	x0, #0x0, lsl #48
    d6ac:      	movz	x1, #0x0, lsl #48
    d6b0:      	movz	x2, #0x0, lsl #48
    d6b4:      	b	0xd62c <_stogir.checked.projection+0x168>
    d6b8:      	movz	x4, #0x0, lsl #48
    d6bc:      	b	0xd584 <_stogir.checked.projection+0xc0>
    d6c0:      	brk	#0
    d6c4:      	b	0xd6c0 <_stogir.checked.projection+0x1fc>
    d6c8:      	mov	x19, x8
    d6cc:      	b	0xd690 <_stogir.checked.projection+0x1cc>
    d6d0:      	mov	x19, x8
    d6d4:      	b	0xd690 <_stogir.checked.projection+0x1cc>

000000000000d6d8 <_stogir.checked-schedule.validate-nodes>:
    d6d8:      	sub	sp, sp, #0xe0
    d6dc:      	str	x29, [sp]
    d6e0:      	str	x30, [sp, #0x8]
    d6e4:      	mov	x29, sp
    d6e8:      	str	x19, [sp, #0x88]
    d6ec:      	str	x20, [sp, #0x90]
    d6f0:      	str	x21, [sp, #0x98]
    d6f4:      	str	x22, [sp, #0xa0]
    d6f8:      	str	x23, [sp, #0xa8]
    d6fc:      	str	x24, [sp, #0xb0]
    d700:      	str	x25, [sp, #0xb8]
    d704:      	str	x26, [sp, #0xc0]
    d708:      	str	x27, [sp, #0xc8]
    d70c:      	str	x28, [sp, #0xd0]
    d710:      	add	x19, x0, #0x78
    d714:      	add	x20, x0, #0x28
    d718:      	add	x21, x0, #0x50
    d71c:      	add	x16, sp, #0x20
    d720:      	orr	x2, x16, xzr
    d724:      	add	x22, x2, #0x8
    d728:      	add	x16, sp, #0x40
    d72c:      	orr	x2, x16, xzr
    d730:      	ldr	x3, [x1]
    d734:      	add	x23, x2, #0x8
    d738:      	orr	x24, x3, xzr
    d73c:      	ldr	x1, [x1, #0x8]
    d740:      	orr	x25, x1, xzr
    d744:      	movz	x26, #0x0, lsl #48
    d748:      	adrp	x27, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000d748:  ARM64_RELOC_PAGE21	l_stogir.513
    d74c:      	ldr	x27, [x27]
		000000000000d74c:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    d750:      	movz	x28, #0x0, lsl #48
    d754:      	movz	w1, #0x0, lsl #16
    d758:      	movz	x2, #0x0, lsl #48
    d75c:      	b	0xd784 <_stogir.checked-schedule.validate-nodes+0xac>
    d760:      	adrp	x27, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000d760:  ARM64_RELOC_PAGE21	l_stogir.514
    d764:      	ldr	x27, [x27]
		000000000000d764:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    d768:      	mov	x28, #0x24              ; =36
    d76c:      	mov	x8, x19
    d770:      	ldr	x0, [sp, #0x68]
    d774:      	ldr	x19, [sp, #0x60]
    d778:      	mov	w1, w20
    d77c:      	ldr	x20, [sp, #0x70]
    d780:      	ldr	x2, [sp, #0x78]
    d784:      	cmp	x2, x25
    d788:      	b.ge	0xd7ac <_stogir.checked-schedule.validate-nodes+0xd4>
    d78c:      	add	x3, x2, #0x1
    d790:      	add	x2, x24, x2, lsl #2
    d794:      	ldr	w2, [x2]
    d798:      	movn	w17, #0x0, lsl #16
    d79c:      	and	w4, w2, w17
    d7a0:      	mov	x2, x3
    d7a4:      	mov	w3, #0x1                ; =1
    d7a8:      	b	0xd7b4 <_stogir.checked-schedule.validate-nodes+0xdc>
    d7ac:      	movz	w3, #0x0, lsl #16
    d7b0:      	movz	w4, #0x0, lsl #16
    d7b4:      	ubfx	x3, x3, #0, #32
    d7b8:      	lsr	x16, x3, #0
    d7bc:      	cmp	x16, #0x1
    d7c0:      	b.eq	0xd7e0 <_stogir.checked-schedule.validate-nodes+0x108>
    d7c4:      	b.lo	0xd7cc <_stogir.checked-schedule.validate-nodes+0xf4>
    d7c8:      	b	0xd7e4 <_stogir.checked-schedule.validate-nodes+0x10c>
    d7cc:      	cmp	x16, #0x0
    d7d0:      	b.eq	0xd7d8 <_stogir.checked-schedule.validate-nodes+0x100>
    d7d4:      	b	0xd7e4 <_stogir.checked-schedule.validate-nodes+0x10c>
    d7d8:      	mov	x19, x8
    d7dc:      	b	0xd84c <_stogir.checked-schedule.validate-nodes+0x174>
    d7e0:      	b	0xd7e8 <_stogir.checked-schedule.validate-nodes+0x110>
    d7e4:      	b	0xdab4 <_stogir.checked-schedule.validate-nodes+0x3dc>
    d7e8:      	cmp	x28, #0x0
    d7ec:      	b.ne	0xdb1c <_stogir.checked-schedule.validate-nodes+0x444>
    d7f0:      	sxtw	x3, w4
    d7f4:      	cmp	x3, #0x0
    d7f8:      	cset	w5, gt
    d7fc:      	movz	x16, #0x0, lsl #48
    d800:      	sub	x6, x16, x3
    d804:      	sub	x7, x6, #0x1
    d808:      	uxtb	w16, w5
    d80c:      	cmp	w16, wzr
    d810:      	b.eq	0xd8ac <_stogir.checked-schedule.validate-nodes+0x1d4>
    d814:      	ldr	x6, [x0, #0x8]
    d818:      	cmp	x3, x6
    d81c:      	b.ge	0xd8ec <_stogir.checked-schedule.validate-nodes+0x214>
    d820:      	ldr	x6, [x19, #0x8]
    d824:      	cmp	x3, x6
    d828:      	b.ge	0xda2c <_stogir.checked-schedule.validate-nodes+0x354>
    d82c:      	ldr	x6, [x0, #0x78]
    d830:      	add	x6, x6, x3, lsl #2
    d834:      	ldr	w6, [x6]
    d838:      	sxtw	x6, w6
    d83c:      	cmp	x6, #0x0
    d840:      	cset	w6, ge
    d844:      	ubfx	x6, x6, #0, #8
    d848:      	b	0xda30 <_stogir.checked-schedule.validate-nodes+0x358>
    d84c:      	cmp	x28, #0x0
    d850:      	b.ne	0xd864 <_stogir.checked-schedule.validate-nodes+0x18c>
    d854:      	and	x27, x26, #0xffffffff
    d858:      	movz	x0, #0x0, lsl #48
    d85c:      	movz	x28, #0x0, lsl #48
    d860:      	b	0xd868 <_stogir.checked-schedule.validate-nodes+0x190>
    d864:      	mov	x0, #0x1                ; =1
    d868:      	str	x0, [x19]
    d86c:      	str	x27, [x19, #0x8]
    d870:      	str	x28, [x19, #0x10]
    d874:      	ldr	x19, [sp, #0x88]
    d878:      	ldr	x20, [sp, #0x90]
    d87c:      	ldr	x21, [sp, #0x98]
    d880:      	ldr	x22, [sp, #0xa0]
    d884:      	ldr	x23, [sp, #0xa8]
    d888:      	ldr	x24, [sp, #0xb0]
    d88c:      	ldr	x25, [sp, #0xb8]
    d890:      	ldr	x26, [sp, #0xc0]
    d894:      	ldr	x27, [sp, #0xc8]
    d898:      	ldr	x28, [sp, #0xd0]
    d89c:      	ldr	x29, [sp]
    d8a0:      	ldr	x30, [sp, #0x8]
    d8a4:      	add	sp, sp, #0xe0
    d8a8:      	ret
    d8ac:      	cmp	x3, #0x0
    d8b0:      	b.ge	0xd8f4 <_stogir.checked-schedule.validate-nodes+0x21c>
    d8b4:      	ldr	x9, [x20, #0x8]
    d8b8:      	ldr	x10, [x21, #0x8]
    d8bc:      	cmp	x9, x10
    d8c0:      	b.ne	0xda24 <_stogir.checked-schedule.validate-nodes+0x34c>
    d8c4:      	cmp	x6, x9
    d8c8:      	b.gt	0xda9c <_stogir.checked-schedule.validate-nodes+0x3c4>
    d8cc:      	ldr	x6, [x0, #0x50]
    d8d0:      	add	x6, x6, x7, lsl #2
    d8d4:      	ldr	w6, [x6]
    d8d8:      	sxtw	x6, w6
    d8dc:      	cmp	x6, #0x0
    d8e0:      	cset	w6, gt
    d8e4:      	ubfx	x6, x6, #0, #8
    d8e8:      	b	0xdaa0 <_stogir.checked-schedule.validate-nodes+0x3c8>
    d8ec:      	movz	x6, #0x0, lsl #48
    d8f0:      	b	0xd8f8 <_stogir.checked-schedule.validate-nodes+0x220>
    d8f4:      	movz	x6, #0x0, lsl #48
    d8f8:      	cmp	x6, #0x0
    d8fc:      	b.eq	0xd938 <_stogir.checked-schedule.validate-nodes+0x260>
    d900:      	uxtb	w16, w5
    d904:      	cmp	w16, wzr
    d908:      	b.eq	0xd920 <_stogir.checked-schedule.validate-nodes+0x248>
    d90c:      	ldr	x5, [x0]
    d910:      	add	x3, x5, x3, lsl #4
    d914:      	ldr	x5, [x3]
    d918:      	ldr	x3, [x3, #0x8]
    d91c:      	b	0xd930 <_stogir.checked-schedule.validate-nodes+0x258>
    d920:      	ldr	x3, [x0, #0x28]
    d924:      	add	x3, x3, x7, lsl #4
    d928:      	ldr	x5, [x3]
    d92c:      	ldr	x3, [x3, #0x8]
    d930:      	mov	w6, #0x1                ; =1
    d934:      	b	0xd944 <_stogir.checked-schedule.validate-nodes+0x26c>
    d938:      	movz	w6, #0x0, lsl #16
    d93c:      	movz	x5, #0x0, lsl #48
    d940:      	movz	x3, #0x0, lsl #48
    d944:      	ubfx	x6, x6, #0, #32
    d948:      	lsr	x16, x6, #0
    d94c:      	cmp	x16, #0x1
    d950:      	b.eq	0xd984 <_stogir.checked-schedule.validate-nodes+0x2ac>
    d954:      	b.lo	0xd95c <_stogir.checked-schedule.validate-nodes+0x284>
    d958:      	b	0xd988 <_stogir.checked-schedule.validate-nodes+0x2b0>
    d95c:      	cmp	x16, #0x0
    d960:      	b.eq	0xd968 <_stogir.checked-schedule.validate-nodes+0x290>
    d964:      	b	0xd988 <_stogir.checked-schedule.validate-nodes+0x2b0>
    d968:      	str	x0, [sp, #0x68]
    d96c:      	str	x19, [sp, #0x60]
    d970:      	mov	x19, x8
    d974:      	str	x20, [sp, #0x70]
    d978:      	mov	w20, w1
    d97c:      	str	x2, [sp, #0x78]
    d980:      	b	0xd760 <_stogir.checked-schedule.validate-nodes+0x88>
    d984:      	b	0xd98c <_stogir.checked-schedule.validate-nodes+0x2b4>
    d988:      	b	0xdb04 <_stogir.checked-schedule.validate-nodes+0x42c>
    d98c:      	uxtb	w6, w5
    d990:      	add	x16, sp, #0x10
    d994:      	str	x5, [x16]
    d998:      	add	x16, sp, #0x10
    d99c:      	str	x3, [x16, #0x8]
    d9a0:      	cmp	x6, #0x29
    d9a4:      	b.lt	0xdb38 <_stogir.checked-schedule.validate-nodes+0x460>
    d9a8:      	cmp	x6, #0x2b
    d9ac:      	b.gt	0xdb58 <_stogir.checked-schedule.validate-nodes+0x480>
    d9b0:      	str	x0, [sp, #0x68]
    d9b4:      	str	x2, [sp, #0x78]
    d9b8:      	str	w4, [sp, #0x80]
    d9bc:      	str	x19, [sp, #0x60]
    d9c0:      	mov	x19, x8
    d9c4:      	add	x8, sp, #0x20
    d9c8:      	str	x20, [sp, #0x70]
    d9cc:      	mov	w20, w1
    d9d0:      	mov	w1, w4
    d9d4:      	bl	0xd9d4 <_stogir.checked-schedule.validate-nodes+0x2fc>
		000000000000d9d4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    d9d8:      	add	x16, sp, #0x20
    d9dc:      	ldr	w0, [x16]
    d9e0:      	lsr	x16, x0, #0
    d9e4:      	cmp	x16, #0x1
    d9e8:      	b.eq	0xda04 <_stogir.checked-schedule.validate-nodes+0x32c>
    d9ec:      	b.lo	0xd9f4 <_stogir.checked-schedule.validate-nodes+0x31c>
    d9f0:      	b	0xda08 <_stogir.checked-schedule.validate-nodes+0x330>
    d9f4:      	cmp	x16, #0x0
    d9f8:      	b.eq	0xda00 <_stogir.checked-schedule.validate-nodes+0x328>
    d9fc:      	b	0xda08 <_stogir.checked-schedule.validate-nodes+0x330>
    da00:      	b	0xdabc <_stogir.checked-schedule.validate-nodes+0x3e4>
    da04:      	b	0xda0c <_stogir.checked-schedule.validate-nodes+0x334>
    da08:      	b	0xdb14 <_stogir.checked-schedule.validate-nodes+0x43c>
    da0c:      	add	x16, sp, #0x20
    da10:      	ldr	x27, [x16, #0x8]
    da14:      	ldr	x28, [x22, #0x8]
    da18:      	b	0xdac0 <_stogir.checked-schedule.validate-nodes+0x3e8>
    da1c:      	movz	w20, #0x0, lsl #16
    da20:      	b	0xd76c <_stogir.checked-schedule.validate-nodes+0x94>
    da24:      	movz	x6, #0x0, lsl #48
    da28:      	b	0xd8f8 <_stogir.checked-schedule.validate-nodes+0x220>
    da2c:      	movz	x6, #0x0, lsl #48
    da30:      	b	0xd8f0 <_stogir.checked-schedule.validate-nodes+0x218>
    da34:      	add	x16, sp, #0x10
    da38:      	ldr	w0, [x16]
    da3c:      	uxtb	w0, w0
    da40:      	cmp	x0, #0x2c
    da44:      	b.ne	0xda1c <_stogir.checked-schedule.validate-nodes+0x344>
    da48:      	add	x8, sp, #0x40
    da4c:      	ldr	x0, [sp, #0x68]
    da50:      	ldr	w1, [sp, #0x80]
    da54:      	bl	0xda54 <_stogir.checked-schedule.validate-nodes+0x37c>
		000000000000da54:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    da58:      	add	x16, sp, #0x40
    da5c:      	ldr	w0, [x16]
    da60:      	lsr	x16, x0, #0
    da64:      	cmp	x16, #0x1
    da68:      	b.eq	0xda84 <_stogir.checked-schedule.validate-nodes+0x3ac>
    da6c:      	b.lo	0xda74 <_stogir.checked-schedule.validate-nodes+0x39c>
    da70:      	b	0xda88 <_stogir.checked-schedule.validate-nodes+0x3b0>
    da74:      	cmp	x16, #0x0
    da78:      	b.eq	0xda80 <_stogir.checked-schedule.validate-nodes+0x3a8>
    da7c:      	b	0xda88 <_stogir.checked-schedule.validate-nodes+0x3b0>
    da80:      	b	0xdac4 <_stogir.checked-schedule.validate-nodes+0x3ec>
    da84:      	b	0xda8c <_stogir.checked-schedule.validate-nodes+0x3b4>
    da88:      	b	0xdb0c <_stogir.checked-schedule.validate-nodes+0x434>
    da8c:      	add	x16, sp, #0x40
    da90:      	ldr	x27, [x16, #0x8]
    da94:      	ldr	x28, [x23, #0x8]
    da98:      	b	0xdab0 <_stogir.checked-schedule.validate-nodes+0x3d8>
    da9c:      	movz	x6, #0x0, lsl #48
    daa0:      	b	0xda28 <_stogir.checked-schedule.validate-nodes+0x350>
    daa4:      	adrp	x27, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000daa4:  ARM64_RELOC_PAGE21	l_stogir.515
    daa8:      	ldr	x27, [x27]
		000000000000daa8:  ARM64_RELOC_PAGEOFF12	l_stogir.515
    daac:      	mov	x28, #0x35              ; =53
    dab0:      	b	0xda20 <_stogir.checked-schedule.validate-nodes+0x348>
    dab4:      	brk	#0
    dab8:      	b	0xdab4 <_stogir.checked-schedule.validate-nodes+0x3dc>
    dabc:      	ldr	w20, [sp, #0x80]
    dac0:      	b	0xda20 <_stogir.checked-schedule.validate-nodes+0x348>
    dac4:      	add	x16, sp, #0x40
    dac8:      	ldr	w0, [x16, #0x8]
    dacc:      	sxtw	x0, w0
    dad0:      	cmp	x0, #0x0
    dad4:      	b.ne	0xdae0 <_stogir.checked-schedule.validate-nodes+0x408>
    dad8:      	movz	w20, #0x0, lsl #16
    dadc:      	b	0xdab0 <_stogir.checked-schedule.validate-nodes+0x3d8>
    dae0:      	sxtw	x0, w20
    dae4:      	add	x16, sp, #0x10
    dae8:      	ldr	w1, [x16, #0x4]
    daec:      	sxtw	x1, w1
    daf0:      	cmp	x0, x1
    daf4:      	b.ne	0xdaa4 <_stogir.checked-schedule.validate-nodes+0x3cc>
    daf8:      	add	x0, x26, #0x1
    dafc:      	sxtw	x26, w0
    db00:      	b	0xdab0 <_stogir.checked-schedule.validate-nodes+0x3d8>
    db04:      	brk	#0
    db08:      	b	0xdb04 <_stogir.checked-schedule.validate-nodes+0x42c>
    db0c:      	brk	#0
    db10:      	b	0xdb0c <_stogir.checked-schedule.validate-nodes+0x434>
    db14:      	brk	#0
    db18:      	b	0xdb14 <_stogir.checked-schedule.validate-nodes+0x43c>
    db1c:      	str	x0, [sp, #0x68]
    db20:      	str	x19, [sp, #0x60]
    db24:      	mov	x19, x8
    db28:      	str	x20, [sp, #0x70]
    db2c:      	mov	w20, w1
    db30:      	str	x2, [sp, #0x78]
    db34:      	b	0xd76c <_stogir.checked-schedule.validate-nodes+0x94>
    db38:      	str	x0, [sp, #0x68]
    db3c:      	str	w4, [sp, #0x80]
    db40:      	str	x19, [sp, #0x60]
    db44:      	mov	x19, x8
    db48:      	str	x20, [sp, #0x70]
    db4c:      	mov	w20, w1
    db50:      	str	x2, [sp, #0x78]
    db54:      	b	0xda34 <_stogir.checked-schedule.validate-nodes+0x35c>
    db58:      	str	x0, [sp, #0x68]
    db5c:      	str	w4, [sp, #0x80]
    db60:      	str	x19, [sp, #0x60]
    db64:      	mov	x19, x8
    db68:      	str	x20, [sp, #0x70]
    db6c:      	mov	w20, w1
    db70:      	str	x2, [sp, #0x78]
    db74:      	b	0xda34 <_stogir.checked-schedule.validate-nodes+0x35c>

000000000000db78 <_coil.alloc.sized-free>:
    db78:      	sub	sp, sp, #0x70
    db7c:      	str	x29, [sp]
    db80:      	str	x30, [sp, #0x8]
    db84:      	mov	x29, sp
    db88:      	str	x19, [sp, #0x60]
    db8c:      	str	x20, [sp, #0x68]
    db90:      	cmp	x2, #0x0
    db94:      	b.ne	0xdbb4 <_coil.alloc.sized-free+0x3c>
    db98:      	movz	x0, #0x0, lsl #48
    db9c:      	ldr	x19, [sp, #0x60]
    dba0:      	ldr	x20, [sp, #0x68]
    dba4:      	ldr	x29, [sp]
    dba8:      	ldr	x30, [sp, #0x8]
    dbac:      	add	sp, sp, #0x70
    dbb0:      	ret
    dbb4:      	add	x8, sp, #0x10
    dbb8:      	mov	x19, x0
    dbbc:      	mov	x0, x3
    dbc0:      	mov	x3, x2
    dbc4:      	mov	x2, x5
    dbc8:      	mov	x20, x1
    dbcc:      	mov	x1, x4
    dbd0:      	bl	0xdbd0 <_coil.alloc.sized-free+0x58>
		000000000000dbd0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    dbd4:      	add	x16, sp, #0x10
    dbd8:      	ldr	w0, [x16]
    dbdc:      	lsr	x16, x0, #0
    dbe0:      	cmp	x16, #0x1
    dbe4:      	b.eq	0xdc00 <_coil.alloc.sized-free+0x88>
    dbe8:      	b.lo	0xdbf0 <_coil.alloc.sized-free+0x78>
    dbec:      	b	0xdc04 <_coil.alloc.sized-free+0x8c>
    dbf0:      	cmp	x16, #0x0
    dbf4:      	b.eq	0xdbfc <_coil.alloc.sized-free+0x84>
    dbf8:      	b	0xdc04 <_coil.alloc.sized-free+0x8c>
    dbfc:      	b	0xdc08 <_coil.alloc.sized-free+0x90>
    dc00:      	b	0xdc10 <_coil.alloc.sized-free+0x98>
    dc04:      	b	0xdc6c <_coil.alloc.sized-free+0xf4>
    dc08:      	movz	x0, #0x0, lsl #48
    dc0c:      	b	0xdc68 <_coil.alloc.sized-free+0xf0>
    dc10:      	add	x16, sp, #0x10
    dc14:      	orr	x0, x16, xzr
    dc18:      	add	x16, sp, #0x40
    dc1c:      	orr	x1, x16, xzr
    dc20:      	add	x0, x0, #0x8
    dc24:      	add	x16, sp, #0x10
    dc28:      	ldr	x2, [x16, #0x8]
    dc2c:      	add	x16, sp, #0x40
    dc30:      	str	x2, [x16]
    dc34:      	ldr	x2, [x0, #0x8]
    dc38:      	add	x16, sp, #0x40
    dc3c:      	str	x2, [x16, #0x8]
    dc40:      	ldr	x2, [x0, #0x10]
    dc44:      	add	x16, sp, #0x40
    dc48:      	str	x2, [x16, #0x10]
    dc4c:      	ldr	x0, [x0, #0x18]
    dc50:      	add	x16, sp, #0x40
    dc54:      	str	x0, [x16, #0x18]
    dc58:      	mov	x0, x19
    dc5c:      	mov	x2, x1
    dc60:      	mov	x1, x20
    dc64:      	bl	0xdc64 <_coil.alloc.sized-free+0xec>
		000000000000dc64:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-free
    dc68:      	b	0xdb9c <_coil.alloc.sized-free+0x24>
    dc6c:      	brk	#0
    dc70:      	b	0xdc6c <_coil.alloc.sized-free+0xf4>

000000000000dc74 <_stogir.types.valid?>:
    dc74:      	sxtw	x1, w0
    dc78:      	cmp	x1, #0x0
    dc7c:      	b.lt	0xdc90 <_stogir.types.valid?+0x1c>
    dc80:      	cmp	x1, #0xd
    dc84:      	b.gt	0xdc90 <_stogir.types.valid?+0x1c>
    dc88:      	mov	x0, #0x1                ; =1
    dc8c:      	b	0xdccc <_stogir.types.valid?+0x58>
    dc90:      	cmp	x1, #0xf
    dc94:      	b.le	0xdcc8 <_stogir.types.valid?+0x54>
    dc98:      	cmp	x1, #0x80
    dc9c:      	b.ge	0xdcc0 <_stogir.types.valid?+0x4c>
    dca0:      	and	w0, w0, #0xf
    dca4:      	ubfx	x0, x0, #0, #32
    dca8:      	cmp	x0, #0x1
    dcac:      	b.lt	0xdcd0 <_stogir.types.valid?+0x5c>
    dcb0:      	cmp	x0, #0xd
    dcb4:      	cset	w0, le
    dcb8:      	ubfx	x0, x0, #0, #8
    dcbc:      	b	0xdcd4 <_stogir.types.valid?+0x60>
    dcc0:      	movz	x0, #0x0, lsl #48
    dcc4:      	b	0xdccc <_stogir.types.valid?+0x58>
    dcc8:      	movz	x0, #0x0, lsl #48
    dccc:      	ret
    dcd0:      	movz	x0, #0x0, lsl #48
    dcd4:      	b	0xdcc4 <_stogir.types.valid?+0x50>

000000000000dcd8 <_stogir.opcode.input-count>:
    dcd8:      	sxtw	x0, w0
    dcdc:      	cmp	x0, #0x0
    dce0:      	b.lt	0xdd04 <_stogir.opcode.input-count+0x2c>
    dce4:      	cmp	x0, #0x83
    dce8:      	b.ge	0xdd04 <_stogir.opcode.input-count+0x2c>
    dcec:      	adrp	x16, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000dcec:  ARM64_RELOC_PAGE21	l_stogir.516
    dcf0:      	ldr	x16, [x16]
		000000000000dcf0:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    dcf4:      	add	x0, x16, x0
    dcf8:      	ldrsb	w0, [x0]
    dcfc:      	sxtb	x0, w0
    dd00:      	b	0xdd08 <_stogir.opcode.input-count+0x30>
    dd04:      	mov	x0, #-0x2               ; =-2
    dd08:      	ret

000000000000dd0c <_stogir.graph.borrow-node>:
    dd0c:      	sxtw	x1, w1
    dd10:      	cmp	x1, #0x0
    dd14:      	cset	w2, gt
    dd18:      	movz	x16, #0x0, lsl #48
    dd1c:      	sub	x3, x16, x1
    dd20:      	sub	x4, x3, #0x1
    dd24:      	uxtb	w16, w2
    dd28:      	cmp	w16, wzr
    dd2c:      	b.eq	0xdd6c <_stogir.graph.borrow-node+0x60>
    dd30:      	ldr	x3, [x0, #0x8]
    dd34:      	cmp	x1, x3
    dd38:      	b.ge	0xddbc <_stogir.graph.borrow-node+0xb0>
    dd3c:      	add	x3, x0, #0x78
    dd40:      	ldr	x3, [x3, #0x8]
    dd44:      	cmp	x1, x3
    dd48:      	b.ge	0xddfc <_stogir.graph.borrow-node+0xf0>
    dd4c:      	ldr	x3, [x0, #0x78]
    dd50:      	add	x3, x3, x1, lsl #2
    dd54:      	ldr	w3, [x3]
    dd58:      	sxtw	x3, w3
    dd5c:      	cmp	x3, #0x0
    dd60:      	cset	w3, ge
    dd64:      	ubfx	x3, x3, #0, #8
    dd68:      	b	0xde00 <_stogir.graph.borrow-node+0xf4>
    dd6c:      	cmp	x1, #0x0
    dd70:      	b.ge	0xddc4 <_stogir.graph.borrow-node+0xb8>
    dd74:      	add	x5, x0, #0x28
    dd78:      	add	x6, x0, #0x50
    dd7c:      	ldr	x5, [x5, #0x8]
    dd80:      	ldr	x6, [x6, #0x8]
    dd84:      	cmp	x5, x6
    dd88:      	b.ne	0xddb4 <_stogir.graph.borrow-node+0xa8>
    dd8c:      	cmp	x3, x5
    dd90:      	b.gt	0xde04 <_stogir.graph.borrow-node+0xf8>
    dd94:      	ldr	x3, [x0, #0x50]
    dd98:      	add	x3, x3, x4, lsl #2
    dd9c:      	ldr	w3, [x3]
    dda0:      	sxtw	x3, w3
    dda4:      	cmp	x3, #0x0
    dda8:      	cset	w3, gt
    ddac:      	ubfx	x3, x3, #0, #8
    ddb0:      	b	0xde08 <_stogir.graph.borrow-node+0xfc>
    ddb4:      	movz	x3, #0x0, lsl #48
    ddb8:      	b	0xddc8 <_stogir.graph.borrow-node+0xbc>
    ddbc:      	movz	x3, #0x0, lsl #48
    ddc0:      	b	0xddc8 <_stogir.graph.borrow-node+0xbc>
    ddc4:      	movz	x3, #0x0, lsl #48
    ddc8:      	cmp	x3, #0x0
    ddcc:      	b.eq	0xddf4 <_stogir.graph.borrow-node+0xe8>
    ddd0:      	uxtb	w16, w2
    ddd4:      	cmp	w16, wzr
    ddd8:      	b.eq	0xdde8 <_stogir.graph.borrow-node+0xdc>
    dddc:      	ldr	x0, [x0]
    dde0:      	add	x0, x0, x1, lsl #4
    dde4:      	b	0xddf0 <_stogir.graph.borrow-node+0xe4>
    dde8:      	ldr	x0, [x0, #0x28]
    ddec:      	add	x0, x0, x4, lsl #4
    ddf0:      	b	0xddf8 <_stogir.graph.borrow-node+0xec>
    ddf4:      	movz	x0, #0x0, lsl #48
    ddf8:      	ret
    ddfc:      	movz	x3, #0x0, lsl #48
    de00:      	b	0xddc0 <_stogir.graph.borrow-node+0xb4>
    de04:      	movz	x3, #0x0, lsl #48
    de08:      	b	0xddb8 <_stogir.graph.borrow-node+0xac>

000000000000de0c <_stogir.verify.phis-structured>:
    de0c:      	sub	sp, sp, #0xd0
    de10:      	str	x29, [sp, #0x10]
    de14:      	str	x30, [sp, #0x18]
    de18:      	add	x29, sp, #0x10
    de1c:      	str	x19, [sp, #0x80]
    de20:      	str	x20, [sp, #0x88]
    de24:      	str	x21, [sp, #0x90]
    de28:      	str	x22, [sp, #0x98]
    de2c:      	str	x23, [sp, #0xa0]
    de30:      	str	x24, [sp, #0xa8]
    de34:      	str	x25, [sp, #0xb0]
    de38:      	str	x26, [sp, #0xb8]
    de3c:      	str	x27, [sp, #0xc0]
    de40:      	str	x28, [sp, #0xc8]
    de44:      	add	x19, x0, #0x78
    de48:      	add	x20, x0, #0x28
    de4c:      	add	x21, x0, #0x50
    de50:      	add	x22, x0, #0x78
    de54:      	mov	x23, #0x1               ; =1
    de58:      	movz	x24, #0x0, lsl #48
    de5c:      	adrp	x25, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000de5c:  ARM64_RELOC_PAGE21	l_stogir.517
    de60:      	ldr	x25, [x25]
		000000000000de60:  ARM64_RELOC_PAGEOFF12	l_stogir.517
    de64:      	movz	x26, #0x0, lsl #48
    de68:      	b	0xe158 <_stogir.verify.phis-structured+0x34c>
    de6c:      	movz	x6, #0x0, lsl #48
    de70:      	b	0xde80 <_stogir.verify.phis-structured+0x74>
    de74:      	movz	x6, #0x0, lsl #48
    de78:      	b	0xde88 <_stogir.verify.phis-structured+0x7c>
    de7c:      	movz	x6, #0x0, lsl #48
    de80:      	b	0xde90 <_stogir.verify.phis-structured+0x84>
    de84:      	movz	x6, #0x0, lsl #48
    de88:      	b	0xde90 <_stogir.verify.phis-structured+0x84>
    de8c:      	movz	x6, #0x0, lsl #48
    de90:      	cmp	x6, #0x0
    de94:      	b.eq	0xdec8 <_stogir.verify.phis-structured+0xbc>
    de98:      	uxtb	w16, w5
    de9c:      	cmp	w16, wzr
    dea0:      	b.eq	0xdeb4 <_stogir.verify.phis-structured+0xa8>
    dea4:      	ldr	x5, [x25]
    dea8:      	add	x4, x5, x4, lsl #4
    deac:      	ldr	x4, [x4]
    deb0:      	b	0xdec0 <_stogir.verify.phis-structured+0xb4>
    deb4:      	ldr	x4, [x25, #0x28]
    deb8:      	add	x4, x4, x7, lsl #4
    debc:      	ldr	x4, [x4]
    dec0:      	mov	w5, #0x1                ; =1
    dec4:      	b	0xded0 <_stogir.verify.phis-structured+0xc4>
    dec8:      	movz	w5, #0x0, lsl #16
    decc:      	movz	x4, #0x0, lsl #48
    ded0:      	ubfx	x5, x5, #0, #32
    ded4:      	lsr	x16, x5, #0
    ded8:      	cmp	x16, #0x1
    dedc:      	b.eq	0xdef8 <_stogir.verify.phis-structured+0xec>
    dee0:      	b.lo	0xdee8 <_stogir.verify.phis-structured+0xdc>
    dee4:      	b	0xdefc <_stogir.verify.phis-structured+0xf0>
    dee8:      	cmp	x16, #0x0
    deec:      	b.eq	0xdef4 <_stogir.verify.phis-structured+0xe8>
    def0:      	b	0xdefc <_stogir.verify.phis-structured+0xf0>
    def4:      	b	0xdf00 <_stogir.verify.phis-structured+0xf4>
    def8:      	b	0xdf14 <_stogir.verify.phis-structured+0x108>
    defc:      	b	0xe36c <_stogir.verify.phis-structured+0x560>
    df00:      	adrp	x16, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000df00:  ARM64_RELOC_PAGE21	l_stogir.518
    df04:      	ldr	x16, [x16]
		000000000000df04:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    df08:      	str	x16, [sp, #0x68]
    df0c:      	mov	x26, #0x11              ; =17
    df10:      	b	0xdf34 <_stogir.verify.phis-structured+0x128>
    df14:      	ubfx	x4, x4, #0, #32
    df18:      	ubfx	x4, x4, #8, #8
    df1c:      	cmp	x4, x0
    df20:      	b.eq	0xdf34 <_stogir.verify.phis-structured+0x128>
    df24:      	adrp	x16, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000df24:  ARM64_RELOC_PAGE21	l_stogir.519
    df28:      	ldr	x16, [x16]
		000000000000df28:  ARM64_RELOC_PAGEOFF12	l_stogir.519
    df2c:      	str	x16, [sp, #0x68]
    df30:      	mov	x26, #0x1a              ; =26
    df34:      	b	0xdf8c <_stogir.verify.phis-structured+0x180>
    df38:      	movz	w5, #0x0, lsl #16
    df3c:      	movz	w4, #0x0, lsl #16
    df40:      	b	0xdf4c <_stogir.verify.phis-structured+0x140>
    df44:      	movz	w5, #0x0, lsl #16
    df48:      	movz	w4, #0x0, lsl #16
    df4c:      	ubfx	x5, x5, #0, #32
    df50:      	lsr	x16, x5, #0
    df54:      	cmp	x16, #0x1
    df58:      	b.eq	0xdf74 <_stogir.verify.phis-structured+0x168>
    df5c:      	b.lo	0xdf64 <_stogir.verify.phis-structured+0x158>
    df60:      	b	0xdf78 <_stogir.verify.phis-structured+0x16c>
    df64:      	cmp	x16, #0x0
    df68:      	b.eq	0xdf70 <_stogir.verify.phis-structured+0x164>
    df6c:      	b	0xdf78 <_stogir.verify.phis-structured+0x16c>
    df70:      	b	0xdf7c <_stogir.verify.phis-structured+0x170>
    df74:      	b	0xdffc <_stogir.verify.phis-structured+0x1f0>
    df78:      	b	0xe364 <_stogir.verify.phis-structured+0x558>
    df7c:      	adrp	x16, 0xd000 <_stogir.loops.sift!+0x20>
		000000000000df7c:  ARM64_RELOC_PAGE21	l_stogir.518
    df80:      	ldr	x16, [x16]
		000000000000df80:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    df84:      	str	x16, [sp, #0x68]
    df88:      	mov	x26, #0x11              ; =17
    df8c:      	add	x3, x3, #0x1
    df90:      	sxtw	x3, w3
    df94:      	cmp	x26, #0x0
    df98:      	b.ne	0xdfac <_stogir.verify.phis-structured+0x1a0>
    df9c:      	cmp	x3, x28
    dfa0:      	cset	w4, le
    dfa4:      	ubfx	x4, x4, #0, #8
    dfa8:      	b	0xdfb0 <_stogir.verify.phis-structured+0x1a4>
    dfac:      	movz	x4, #0x0, lsl #48
    dfb0:      	cmp	x4, #0x0
    dfb4:      	b.eq	0xe11c <_stogir.verify.phis-structured+0x310>
    dfb8:      	uxtb	w16, w1
    dfbc:      	cmp	w16, wzr
    dfc0:      	b.ne	0xdf44 <_stogir.verify.phis-structured+0x138>
    dfc4:      	ldr	x4, [x25, #0x8]
    dfc8:      	cmp	x23, x4
    dfcc:      	b.ge	0xe060 <_stogir.verify.phis-structured+0x254>
    dfd0:      	ldr	x4, [x22, #0x8]
    dfd4:      	cmp	x23, x4
    dfd8:      	b.ge	0xe058 <_stogir.verify.phis-structured+0x24c>
    dfdc:      	ldr	x4, [x25, #0x78]
    dfe0:      	add	x4, x2, x4
    dfe4:      	ldr	w4, [x4]
    dfe8:      	sxtw	x4, w4
    dfec:      	cmp	x4, #0x0
    dff0:      	cset	w4, ge
    dff4:      	ubfx	x4, x4, #0, #8
    dff8:      	b	0xe05c <_stogir.verify.phis-structured+0x250>
    dffc:      	sxtw	x4, w4
    e000:      	cmp	x4, #0x0
    e004:      	cset	w5, gt
    e008:      	movz	x16, #0x0, lsl #48
    e00c:      	sub	x6, x16, x4
    e010:      	sub	x7, x6, #0x1
    e014:      	uxtb	w16, w5
    e018:      	cmp	w16, wzr
    e01c:      	b.eq	0xe0dc <_stogir.verify.phis-structured+0x2d0>
    e020:      	ldr	x6, [x25, #0x8]
    e024:      	cmp	x4, x6
    e028:      	b.ge	0xde84 <_stogir.verify.phis-structured+0x78>
    e02c:      	ldr	x6, [x19, #0x8]
    e030:      	cmp	x4, x6
    e034:      	b.ge	0xde74 <_stogir.verify.phis-structured+0x68>
    e038:      	ldr	x6, [x25, #0x78]
    e03c:      	add	x6, x6, x4, lsl #2
    e040:      	ldr	w6, [x6]
    e044:      	sxtw	x6, w6
    e048:      	cmp	x6, #0x0
    e04c:      	cset	w6, ge
    e050:      	ubfx	x6, x6, #0, #8
    e054:      	b	0xde78 <_stogir.verify.phis-structured+0x6c>
    e058:      	movz	x4, #0x0, lsl #48
    e05c:      	b	0xe064 <_stogir.verify.phis-structured+0x258>
    e060:      	movz	x4, #0x0, lsl #48
    e064:      	cmp	x4, #0x0
    e068:      	b.eq	0xdf44 <_stogir.verify.phis-structured+0x138>
    e06c:      	orr	w4, w3, wzr
    e070:      	sxtw	x4, w4
    e074:      	cmp	x4, #0x1
    e078:      	b.lt	0xdf38 <_stogir.verify.phis-structured+0x12c>
    e07c:      	ldr	x5, [x25, #0x78]
    e080:      	add	x5, x2, x5
    e084:      	ldr	w5, [x5]
    e088:      	sxtw	x5, w5
    e08c:      	cmp	x4, x5
    e090:      	b.gt	0xdf38 <_stogir.verify.phis-structured+0x12c>
    e094:      	ldr	x5, [x25]
    e098:      	asr	x16, x4, #63
    e09c:      	lsr	x16, x16, #62
    e0a0:      	add	x6, x4, x16
    e0a4:      	asr	x6, x6, #2
    e0a8:      	asr	x16, x4, #63
    e0ac:      	lsr	x16, x16, #62
    e0b0:      	add	x4, x4, x16
    e0b4:      	and	x4, x4, #0x3
    e0b8:      	sub	x4, x4, x16
    e0bc:      	add	x6, x6, x23
    e0c0:      	add	x5, x5, x6, lsl #4
    e0c4:      	add	x4, x5, x4, lsl #2
    e0c8:      	ldr	w4, [x4]
    e0cc:      	movn	w17, #0x0, lsl #16
    e0d0:      	and	w4, w4, w17
    e0d4:      	mov	w5, #0x1                ; =1
    e0d8:      	b	0xdf40 <_stogir.verify.phis-structured+0x134>
    e0dc:      	cmp	x4, #0x0
    e0e0:      	b.ge	0xde8c <_stogir.verify.phis-structured+0x80>
    e0e4:      	ldr	x8, [x20, #0x8]
    e0e8:      	ldr	x9, [x21, #0x8]
    e0ec:      	cmp	x8, x9
    e0f0:      	b.ne	0xde7c <_stogir.verify.phis-structured+0x70>
    e0f4:      	cmp	x6, x8
    e0f8:      	b.gt	0xde6c <_stogir.verify.phis-structured+0x60>
    e0fc:      	ldr	x6, [x25, #0x50]
    e100:      	add	x6, x6, x7, lsl #2
    e104:      	ldr	w6, [x6]
    e108:      	sxtw	x6, w6
    e10c:      	cmp	x6, #0x0
    e110:      	cset	w6, gt
    e114:      	ubfx	x6, x6, #0, #8
    e118:      	b	0xde70 <_stogir.verify.phis-structured+0x64>
    e11c:      	ldr	x0, [sp, #0x78]
    e120:      	add	x0, x0, #0x1
    e124:      	sxtw	x0, w0
    e128:      	add	x1, x28, #0x4
    e12c:      	asr	x16, x1, #63
    e130:      	lsr	x16, x16, #62
    e134:      	add	x1, x1, x16
    e138:      	asr	x1, x1, #2
    e13c:      	ldr	x2, [sp, #0x70]
    e140:      	add	x2, x1, x2
    e144:      	ldr	x8, [sp, #0x60]
    e148:      	mov	x23, x2
    e14c:      	mov	x24, x0
    e150:      	mov	x0, x25
    e154:      	ldr	x25, [sp, #0x68]
    e158:      	cmp	x26, #0x0
    e15c:      	b.ne	0xe3b4 <_stogir.verify.phis-structured+0x5a8>
    e160:      	ldr	x1, [x0, #0x8]
    e164:      	cmp	x23, x1
    e168:      	b.ge	0xe3c4 <_stogir.verify.phis-structured+0x5b8>
    e16c:      	ldr	x1, [x0]
    e170:      	add	x1, x1, x23, lsl #4
    e174:      	ldr	x27, [x1]
    e178:      	ldr	x1, [x0, #0x78]
    e17c:      	uxtb	w2, w27
    e180:      	add	x1, x1, x23, lsl #2
    e184:      	ldr	w1, [x1]
    e188:      	sxtw	x28, w1
    e18c:      	cmp	x2, #0x43
    e190:      	b.ne	0xe3d4 <_stogir.verify.phis-structured+0x5c8>
    e194:      	orr	w1, w23, wzr
    e198:      	cmp	x28, #0x3
    e19c:      	b.ge	0xe1fc <_stogir.verify.phis-structured+0x3f0>
    e1a0:      	str	x23, [sp, #0x70]
    e1a4:      	str	x24, [sp, #0x78]
    e1a8:      	str	x8, [sp, #0x60]
    e1ac:      	mov	x25, x0
    e1b0:      	mov	w23, w1
    e1b4:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e1b4:  ARM64_RELOC_PAGE21	l_stogir.520
    e1b8:      	ldr	x16, [x16]
		000000000000e1b8:  ARM64_RELOC_PAGEOFF12	l_stogir.520
    e1bc:      	str	x16, [sp, #0x68]
    e1c0:      	mov	x26, #0x2b              ; =43
    e1c4:      	ubfx	x27, x27, #0, #32
    e1c8:      	ubfx	x0, x27, #8, #8
    e1cc:      	cmp	x0, #0x0
    e1d0:      	b.ne	0xe1e4 <_stogir.verify.phis-structured+0x3d8>
    e1d4:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e1d4:  ARM64_RELOC_PAGE21	l_stogir.521
    e1d8:      	ldr	x16, [x16]
		000000000000e1d8:  ARM64_RELOC_PAGEOFF12	l_stogir.521
    e1dc:      	str	x16, [sp, #0x68]
    e1e0:      	mov	x26, #0x19              ; =25
    e1e4:      	sxtw	x23, w23
    e1e8:      	cmp	x23, #0x0
    e1ec:      	cset	w1, le
    e1f0:      	lsl	x2, x23, #2
    e1f4:      	mov	x3, #0x2                ; =2
    e1f8:      	b	0xdf94 <_stogir.verify.phis-structured+0x188>
    e1fc:      	str	x8, [sp, #0x60]
    e200:      	str	x25, [sp, #0x68]
    e204:      	mov	x25, x0
    e208:      	str	x23, [sp, #0x70]
    e20c:      	mov	w23, w1
    e210:      	mov	x2, #0x1                ; =1
    e214:      	bl	0xe214 <_stogir.verify.phis-structured+0x408>
		000000000000e214:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    e218:      	ubfx	x0, x0, #0, #32
    e21c:      	lsr	x16, x0, #0
    e220:      	cmp	x16, #0x1
    e224:      	b.eq	0xe240 <_stogir.verify.phis-structured+0x434>
    e228:      	b.lo	0xe230 <_stogir.verify.phis-structured+0x424>
    e22c:      	b	0xe244 <_stogir.verify.phis-structured+0x438>
    e230:      	cmp	x16, #0x0
    e234:      	b.eq	0xe23c <_stogir.verify.phis-structured+0x430>
    e238:      	b	0xe244 <_stogir.verify.phis-structured+0x438>
    e23c:      	b	0xe248 <_stogir.verify.phis-structured+0x43c>
    e240:      	b	0xe2c4 <_stogir.verify.phis-structured+0x4b8>
    e244:      	b	0xe3a4 <_stogir.verify.phis-structured+0x598>
    e248:      	str	x24, [sp, #0x78]
    e24c:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e24c:  ARM64_RELOC_PAGE21	l_stogir.522
    e250:      	ldr	x16, [x16]
		000000000000e250:  ARM64_RELOC_PAGEOFF12	l_stogir.522
    e254:      	str	x16, [sp, #0x68]
    e258:      	mov	x26, #0x10              ; =16
    e25c:      	b	0xe1c4 <_stogir.verify.phis-structured+0x3b8>
    e260:      	cmp	x26, #0x0
    e264:      	b.ne	0xe3ec <_stogir.verify.phis-structured+0x5e0>
    e268:      	and	x0, x0, #0xffffffff
    e26c:      	movz	x1, #0x0, lsl #48
    e270:      	movz	x26, #0x0, lsl #48
    e274:      	b	0xe27c <_stogir.verify.phis-structured+0x470>
    e278:      	mov	x1, #0x1                ; =1
    e27c:      	ldr	x2, [sp, #0x60]
    e280:      	str	x1, [x2]
    e284:      	str	x0, [x2, #0x8]
    e288:      	str	x26, [x2, #0x10]
    e28c:      	ldr	x19, [sp, #0x80]
    e290:      	ldr	x20, [sp, #0x88]
    e294:      	ldr	x21, [sp, #0x90]
    e298:      	ldr	x22, [sp, #0x98]
    e29c:      	ldr	x23, [sp, #0xa0]
    e2a0:      	ldr	x24, [sp, #0xa8]
    e2a4:      	ldr	x25, [sp, #0xb0]
    e2a8:      	ldr	x26, [sp, #0xb8]
    e2ac:      	ldr	x27, [sp, #0xc0]
    e2b0:      	ldr	x28, [sp, #0xc8]
    e2b4:      	ldr	x29, [sp, #0x10]
    e2b8:      	ldr	x30, [sp, #0x18]
    e2bc:      	add	sp, sp, #0xd0
    e2c0:      	ret
    e2c4:      	orr	w0, w1, wzr
    e2c8:      	add	x8, sp, #0x20
    e2cc:      	mov	w1, w0
    e2d0:      	str	x24, [sp, #0x78]
    e2d4:      	mov	w24, w0
    e2d8:      	mov	x0, x25
    e2dc:      	bl	0xe2dc <_stogir.verify.phis-structured+0x4d0>
		000000000000e2dc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    e2e0:      	add	x16, sp, #0x20
    e2e4:      	ldr	w0, [x16]
    e2e8:      	lsr	x16, x0, #0
    e2ec:      	cmp	x16, #0x1
    e2f0:      	b.eq	0xe30c <_stogir.verify.phis-structured+0x500>
    e2f4:      	b.lo	0xe2fc <_stogir.verify.phis-structured+0x4f0>
    e2f8:      	b	0xe310 <_stogir.verify.phis-structured+0x504>
    e2fc:      	cmp	x16, #0x0
    e300:      	b.eq	0xe308 <_stogir.verify.phis-structured+0x4fc>
    e304:      	b	0xe310 <_stogir.verify.phis-structured+0x504>
    e308:      	b	0xe314 <_stogir.verify.phis-structured+0x508>
    e30c:      	b	0xe328 <_stogir.verify.phis-structured+0x51c>
    e310:      	b	0xe3ac <_stogir.verify.phis-structured+0x5a0>
    e314:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e314:  ARM64_RELOC_PAGE21	l_stogir.523
    e318:      	ldr	x16, [x16]
		000000000000e318:  ARM64_RELOC_PAGEOFF12	l_stogir.523
    e31c:      	str	x16, [sp, #0x68]
    e320:      	mov	x26, #0x12              ; =18
    e324:      	b	0xe360 <_stogir.verify.phis-structured+0x554>
    e328:      	sxtw	x24, w24
    e32c:      	add	x16, sp, #0x20
    e330:      	ldr	x0, [x16, #0x8]
    e334:      	cmp	x24, #0x0
    e338:      	b.le	0xe350 <_stogir.verify.phis-structured+0x544>
    e33c:      	uxtb	w0, w0
    e340:      	cmp	x0, #0x70
    e344:      	b.eq	0xe374 <_stogir.verify.phis-structured+0x568>
    e348:      	cmp	x0, #0x71
    e34c:      	b.eq	0xe374 <_stogir.verify.phis-structured+0x568>
    e350:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e350:  ARM64_RELOC_PAGE21	l_stogir.524
    e354:      	ldr	x16, [x16]
		000000000000e354:  ARM64_RELOC_PAGEOFF12	l_stogir.524
    e358:      	str	x16, [sp, #0x68]
    e35c:      	mov	x26, #0x26              ; =38
    e360:      	b	0xe25c <_stogir.verify.phis-structured+0x450>
    e364:      	brk	#0
    e368:      	b	0xe364 <_stogir.verify.phis-structured+0x558>
    e36c:      	brk	#0
    e370:      	b	0xe36c <_stogir.verify.phis-structured+0x560>
    e374:      	ldr	x0, [x25, #0x78]
    e378:      	add	x0, x0, x24, lsl #2
    e37c:      	ldr	w0, [x0]
    e380:      	add	w0, w0, #0x1
    e384:      	sxtw	x0, w0
    e388:      	cmp	x28, x0
    e38c:      	b.eq	0xe3a0 <_stogir.verify.phis-structured+0x594>
    e390:      	adrp	x16, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e390:  ARM64_RELOC_PAGE21	l_stogir.525
    e394:      	ldr	x16, [x16]
		000000000000e394:  ARM64_RELOC_PAGEOFF12	l_stogir.525
    e398:      	str	x16, [sp, #0x68]
    e39c:      	mov	x26, #0x2b              ; =43
    e3a0:      	b	0xe360 <_stogir.verify.phis-structured+0x554>
    e3a4:      	brk	#0
    e3a8:      	b	0xe3a4 <_stogir.verify.phis-structured+0x598>
    e3ac:      	brk	#0
    e3b0:      	b	0xe3ac <_stogir.verify.phis-structured+0x5a0>
    e3b4:      	mov	x0, x24
    e3b8:      	str	x8, [sp, #0x60]
    e3bc:      	str	x25, [sp, #0x68]
    e3c0:      	b	0xe260 <_stogir.verify.phis-structured+0x454>
    e3c4:      	mov	x0, x24
    e3c8:      	str	x8, [sp, #0x60]
    e3cc:      	str	x25, [sp, #0x68]
    e3d0:      	b	0xe260 <_stogir.verify.phis-structured+0x454>
    e3d4:      	str	x23, [sp, #0x70]
    e3d8:      	str	x8, [sp, #0x60]
    e3dc:      	str	x25, [sp, #0x68]
    e3e0:      	mov	x25, x0
    e3e4:      	mov	x0, x24
    e3e8:      	b	0xe128 <_stogir.verify.phis-structured+0x31c>
    e3ec:      	ldr	x0, [sp, #0x68]
    e3f0:      	b	0xe278 <_stogir.verify.phis-structured+0x46c>

000000000000e3f4 <_inherent$coil.arraylist.ArrayList$reserve!__i32>:
    e3f4:      	sub	sp, sp, #0x50
    e3f8:      	str	x29, [sp]
    e3fc:      	str	x30, [sp, #0x8]
    e400:      	mov	x29, sp
    e404:      	str	x19, [sp, #0x40]
    e408:      	str	x20, [sp, #0x48]
    e40c:      	add	x2, x0, #0x18
    e410:      	ldr	x3, [x0, #0x10]
    e414:      	ldr	x4, [x0, #0x18]
    e418:      	ldr	x2, [x2, #0x8]
    e41c:      	add	x16, sp, #0x10
    e420:      	str	x4, [x16]
    e424:      	add	x16, sp, #0x10
    e428:      	str	x2, [x16, #0x8]
    e42c:      	cmp	x1, x3
    e430:      	b.le	0xe4a4 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xb0>
    e434:      	add	x16, sp, #0x10
    e438:      	orr	x2, x16, xzr
    e43c:      	ldr	x4, [x0]
    e440:      	add	x8, sp, #0x20
    e444:      	mov	x19, x0
    e448:      	mov	x0, x2
    e44c:      	mov	x2, x3
    e450:      	mov	x3, x1
    e454:      	mov	x20, x1
    e458:      	mov	x1, x4
    e45c:      	bl	0xe45c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x68>
		000000000000e45c:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i32
    e460:      	add	x16, sp, #0x20
    e464:      	ldr	w0, [x16]
    e468:      	lsr	x16, x0, #0
    e46c:      	cmp	x16, #0x1
    e470:      	b.eq	0xe48c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x98>
    e474:      	b.lo	0xe47c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x88>
    e478:      	b	0xe490 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x9c>
    e47c:      	cmp	x16, #0x0
    e480:      	b.eq	0xe488 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x94>
    e484:      	b	0xe490 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x9c>
    e488:      	b	0xe4c0 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xcc>
    e48c:      	b	0xe494 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xa0>
    e490:      	b	0xe4d8 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe4>
    e494:      	add	x16, sp, #0x20
    e498:      	ldr	x0, [x16, #0x8]
    e49c:      	str	x0, [x19]
    e4a0:      	str	x20, [x19, #0x10]
    e4a4:      	movz	x0, #0x0, lsl #48
    e4a8:      	ldr	x19, [sp, #0x40]
    e4ac:      	ldr	x20, [sp, #0x48]
    e4b0:      	ldr	x29, [sp]
    e4b4:      	ldr	x30, [sp, #0x8]
    e4b8:      	add	sp, sp, #0x50
    e4bc:      	ret
    e4c0:      	lsl	x0, x20, #2
    e4c4:      	mov	x1, x0
    e4c8:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e4c8:  ARM64_RELOC_PAGE21	l_stogir.526
    e4cc:      	ldr	x0, [x0]
		000000000000e4cc:  ARM64_RELOC_PAGEOFF12	l_stogir.526
    e4d0:      	bl	0xe4d0 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xdc>
		000000000000e4d0:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e4d4:      	b	0xe4d4 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe0>
    e4d8:      	brk	#0
    e4dc:      	b	0xe4d8 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe4>

000000000000e4e0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge>:
    e4e0:      	sub	sp, sp, #0x50
    e4e4:      	str	x29, [sp]
    e4e8:      	str	x30, [sp, #0x8]
    e4ec:      	mov	x29, sp
    e4f0:      	str	x19, [sp, #0x40]
    e4f4:      	str	x20, [sp, #0x48]
    e4f8:      	add	x2, x0, #0x18
    e4fc:      	ldr	x3, [x0, #0x10]
    e500:      	ldr	x4, [x0, #0x18]
    e504:      	ldr	x2, [x2, #0x8]
    e508:      	add	x16, sp, #0x10
    e50c:      	str	x4, [x16]
    e510:      	add	x16, sp, #0x10
    e514:      	str	x2, [x16, #0x8]
    e518:      	cmp	x1, x3
    e51c:      	b.le	0xe590 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xb0>
    e520:      	add	x16, sp, #0x10
    e524:      	orr	x2, x16, xzr
    e528:      	ldr	x4, [x0]
    e52c:      	add	x8, sp, #0x20
    e530:      	mov	x19, x0
    e534:      	mov	x0, x2
    e538:      	mov	x2, x3
    e53c:      	mov	x3, x1
    e540:      	mov	x20, x1
    e544:      	mov	x1, x4
    e548:      	bl	0xe548 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x68>
		000000000000e548:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.cfg.Edge
    e54c:      	add	x16, sp, #0x20
    e550:      	ldr	w0, [x16]
    e554:      	lsr	x16, x0, #0
    e558:      	cmp	x16, #0x1
    e55c:      	b.eq	0xe578 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x98>
    e560:      	b.lo	0xe568 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x88>
    e564:      	b	0xe57c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x9c>
    e568:      	cmp	x16, #0x0
    e56c:      	b.eq	0xe574 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x94>
    e570:      	b	0xe57c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x9c>
    e574:      	b	0xe5ac <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xcc>
    e578:      	b	0xe580 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xa0>
    e57c:      	b	0xe5c4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe4>
    e580:      	add	x16, sp, #0x20
    e584:      	ldr	x0, [x16, #0x8]
    e588:      	str	x0, [x19]
    e58c:      	str	x20, [x19, #0x10]
    e590:      	movz	x0, #0x0, lsl #48
    e594:      	ldr	x19, [sp, #0x40]
    e598:      	ldr	x20, [sp, #0x48]
    e59c:      	ldr	x29, [sp]
    e5a0:      	ldr	x30, [sp, #0x8]
    e5a4:      	add	sp, sp, #0x50
    e5a8:      	ret
    e5ac:      	lsl	x0, x20, #4
    e5b0:      	mov	x1, x0
    e5b4:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e5b4:  ARM64_RELOC_PAGE21	l_stogir.527
    e5b8:      	ldr	x0, [x0]
		000000000000e5b8:  ARM64_RELOC_PAGEOFF12	l_stogir.527
    e5bc:      	bl	0xe5bc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xdc>
		000000000000e5bc:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e5c0:      	b	0xe5c0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe0>
    e5c4:      	brk	#0
    e5c8:      	b	0xe5c4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe4>

000000000000e5cc <_inherent$coil.arraylist.ArrayList$reserve!__bool>:
    e5cc:      	sub	sp, sp, #0x50
    e5d0:      	str	x29, [sp]
    e5d4:      	str	x30, [sp, #0x8]
    e5d8:      	mov	x29, sp
    e5dc:      	str	x19, [sp, #0x40]
    e5e0:      	str	x20, [sp, #0x48]
    e5e4:      	add	x2, x0, #0x18
    e5e8:      	ldr	x3, [x0, #0x10]
    e5ec:      	ldr	x4, [x0, #0x18]
    e5f0:      	ldr	x2, [x2, #0x8]
    e5f4:      	add	x16, sp, #0x10
    e5f8:      	str	x4, [x16]
    e5fc:      	add	x16, sp, #0x10
    e600:      	str	x2, [x16, #0x8]
    e604:      	cmp	x1, x3
    e608:      	b.le	0xe67c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xb0>
    e60c:      	add	x16, sp, #0x10
    e610:      	orr	x2, x16, xzr
    e614:      	ldr	x4, [x0]
    e618:      	add	x8, sp, #0x20
    e61c:      	mov	x19, x0
    e620:      	mov	x0, x2
    e624:      	mov	x2, x3
    e628:      	mov	x3, x1
    e62c:      	mov	x20, x1
    e630:      	mov	x1, x4
    e634:      	bl	0xe634 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x68>
		000000000000e634:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__bool
    e638:      	add	x16, sp, #0x20
    e63c:      	ldr	w0, [x16]
    e640:      	lsr	x16, x0, #0
    e644:      	cmp	x16, #0x1
    e648:      	b.eq	0xe664 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x98>
    e64c:      	b.lo	0xe654 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x88>
    e650:      	b	0xe668 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x9c>
    e654:      	cmp	x16, #0x0
    e658:      	b.eq	0xe660 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x94>
    e65c:      	b	0xe668 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x9c>
    e660:      	b	0xe698 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xcc>
    e664:      	b	0xe66c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xa0>
    e668:      	b	0xe6b0 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe4>
    e66c:      	add	x16, sp, #0x20
    e670:      	ldr	x0, [x16, #0x8]
    e674:      	str	x0, [x19]
    e678:      	str	x20, [x19, #0x10]
    e67c:      	movz	x0, #0x0, lsl #48
    e680:      	ldr	x19, [sp, #0x40]
    e684:      	ldr	x20, [sp, #0x48]
    e688:      	ldr	x29, [sp]
    e68c:      	ldr	x30, [sp, #0x8]
    e690:      	add	sp, sp, #0x50
    e694:      	ret
    e698:      	lsr	x0, x20, #0
    e69c:      	mov	x1, x0
    e6a0:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e6a0:  ARM64_RELOC_PAGE21	l_stogir.528
    e6a4:      	ldr	x0, [x0]
		000000000000e6a4:  ARM64_RELOC_PAGEOFF12	l_stogir.528
    e6a8:      	bl	0xe6a8 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xdc>
		000000000000e6a8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e6ac:      	b	0xe6ac <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe0>
    e6b0:      	brk	#0
    e6b4:      	b	0xe6b0 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe4>

000000000000e6b8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame>:
    e6b8:      	sub	sp, sp, #0x50
    e6bc:      	str	x29, [sp]
    e6c0:      	str	x30, [sp, #0x8]
    e6c4:      	mov	x29, sp
    e6c8:      	str	x19, [sp, #0x40]
    e6cc:      	str	x20, [sp, #0x48]
    e6d0:      	add	x2, x0, #0x18
    e6d4:      	ldr	x3, [x0, #0x10]
    e6d8:      	ldr	x4, [x0, #0x18]
    e6dc:      	ldr	x2, [x2, #0x8]
    e6e0:      	add	x16, sp, #0x10
    e6e4:      	str	x4, [x16]
    e6e8:      	add	x16, sp, #0x10
    e6ec:      	str	x2, [x16, #0x8]
    e6f0:      	cmp	x1, x3
    e6f4:      	b.le	0xe768 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xb0>
    e6f8:      	add	x16, sp, #0x10
    e6fc:      	orr	x2, x16, xzr
    e700:      	ldr	x4, [x0]
    e704:      	add	x8, sp, #0x20
    e708:      	mov	x19, x0
    e70c:      	mov	x0, x2
    e710:      	mov	x2, x3
    e714:      	mov	x3, x1
    e718:      	mov	x20, x1
    e71c:      	mov	x1, x4
    e720:      	bl	0xe720 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x68>
		000000000000e720:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Frame
    e724:      	add	x16, sp, #0x20
    e728:      	ldr	w0, [x16]
    e72c:      	lsr	x16, x0, #0
    e730:      	cmp	x16, #0x1
    e734:      	b.eq	0xe750 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x98>
    e738:      	b.lo	0xe740 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x88>
    e73c:      	b	0xe754 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x9c>
    e740:      	cmp	x16, #0x0
    e744:      	b.eq	0xe74c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x94>
    e748:      	b	0xe754 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x9c>
    e74c:      	b	0xe784 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xcc>
    e750:      	b	0xe758 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xa0>
    e754:      	b	0xe79c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe4>
    e758:      	add	x16, sp, #0x20
    e75c:      	ldr	x0, [x16, #0x8]
    e760:      	str	x0, [x19]
    e764:      	str	x20, [x19, #0x10]
    e768:      	movz	x0, #0x0, lsl #48
    e76c:      	ldr	x19, [sp, #0x40]
    e770:      	ldr	x20, [sp, #0x48]
    e774:      	ldr	x29, [sp]
    e778:      	ldr	x30, [sp, #0x8]
    e77c:      	add	sp, sp, #0x50
    e780:      	ret
    e784:      	lsl	x0, x20, #4
    e788:      	mov	x1, x0
    e78c:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e78c:  ARM64_RELOC_PAGE21	l_stogir.529
    e790:      	ldr	x0, [x0]
		000000000000e790:  ARM64_RELOC_PAGEOFF12	l_stogir.529
    e794:      	bl	0xe794 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xdc>
		000000000000e794:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e798:      	b	0xe798 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe0>
    e79c:      	brk	#0
    e7a0:      	b	0xe79c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe4>

000000000000e7a4 <_inherent$coil.arraylist.ArrayList$reserve!__i64>:
    e7a4:      	sub	sp, sp, #0x50
    e7a8:      	str	x29, [sp]
    e7ac:      	str	x30, [sp, #0x8]
    e7b0:      	mov	x29, sp
    e7b4:      	str	x19, [sp, #0x40]
    e7b8:      	str	x20, [sp, #0x48]
    e7bc:      	add	x2, x0, #0x18
    e7c0:      	ldr	x3, [x0, #0x10]
    e7c4:      	ldr	x4, [x0, #0x18]
    e7c8:      	ldr	x2, [x2, #0x8]
    e7cc:      	add	x16, sp, #0x10
    e7d0:      	str	x4, [x16]
    e7d4:      	add	x16, sp, #0x10
    e7d8:      	str	x2, [x16, #0x8]
    e7dc:      	cmp	x1, x3
    e7e0:      	b.le	0xe854 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xb0>
    e7e4:      	add	x16, sp, #0x10
    e7e8:      	orr	x2, x16, xzr
    e7ec:      	ldr	x4, [x0]
    e7f0:      	add	x8, sp, #0x20
    e7f4:      	mov	x19, x0
    e7f8:      	mov	x0, x2
    e7fc:      	mov	x2, x3
    e800:      	mov	x3, x1
    e804:      	mov	x20, x1
    e808:      	mov	x1, x4
    e80c:      	bl	0xe80c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x68>
		000000000000e80c:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i64
    e810:      	add	x16, sp, #0x20
    e814:      	ldr	w0, [x16]
    e818:      	lsr	x16, x0, #0
    e81c:      	cmp	x16, #0x1
    e820:      	b.eq	0xe83c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x98>
    e824:      	b.lo	0xe82c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x88>
    e828:      	b	0xe840 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x9c>
    e82c:      	cmp	x16, #0x0
    e830:      	b.eq	0xe838 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
    e834:      	b	0xe840 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x9c>
    e838:      	b	0xe870 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xcc>
    e83c:      	b	0xe844 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xa0>
    e840:      	b	0xe888 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe4>
    e844:      	add	x16, sp, #0x20
    e848:      	ldr	x0, [x16, #0x8]
    e84c:      	str	x0, [x19]
    e850:      	str	x20, [x19, #0x10]
    e854:      	movz	x0, #0x0, lsl #48
    e858:      	ldr	x19, [sp, #0x40]
    e85c:      	ldr	x20, [sp, #0x48]
    e860:      	ldr	x29, [sp]
    e864:      	ldr	x30, [sp, #0x8]
    e868:      	add	sp, sp, #0x50
    e86c:      	ret
    e870:      	lsl	x0, x20, #3
    e874:      	mov	x1, x0
    e878:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e878:  ARM64_RELOC_PAGE21	l_stogir.530
    e87c:      	ldr	x0, [x0]
		000000000000e87c:  ARM64_RELOC_PAGEOFF12	l_stogir.530
    e880:      	bl	0xe880 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xdc>
		000000000000e880:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e884:      	b	0xe884 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe0>
    e888:      	brk	#0
    e88c:      	b	0xe888 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe4>

000000000000e890 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range>:
    e890:      	sub	sp, sp, #0x50
    e894:      	str	x29, [sp]
    e898:      	str	x30, [sp, #0x8]
    e89c:      	mov	x29, sp
    e8a0:      	str	x19, [sp, #0x40]
    e8a4:      	str	x20, [sp, #0x48]
    e8a8:      	add	x2, x0, #0x18
    e8ac:      	ldr	x3, [x0, #0x10]
    e8b0:      	ldr	x4, [x0, #0x18]
    e8b4:      	ldr	x2, [x2, #0x8]
    e8b8:      	add	x16, sp, #0x10
    e8bc:      	str	x4, [x16]
    e8c0:      	add	x16, sp, #0x10
    e8c4:      	str	x2, [x16, #0x8]
    e8c8:      	cmp	x1, x3
    e8cc:      	b.le	0xe940 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xb0>
    e8d0:      	add	x16, sp, #0x10
    e8d4:      	orr	x2, x16, xzr
    e8d8:      	ldr	x4, [x0]
    e8dc:      	add	x8, sp, #0x20
    e8e0:      	mov	x19, x0
    e8e4:      	mov	x0, x2
    e8e8:      	mov	x2, x3
    e8ec:      	mov	x3, x1
    e8f0:      	mov	x20, x1
    e8f4:      	mov	x1, x4
    e8f8:      	bl	0xe8f8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x68>
		000000000000e8f8:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Range
    e8fc:      	add	x16, sp, #0x20
    e900:      	ldr	w0, [x16]
    e904:      	lsr	x16, x0, #0
    e908:      	cmp	x16, #0x1
    e90c:      	b.eq	0xe928 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x98>
    e910:      	b.lo	0xe918 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x88>
    e914:      	b	0xe92c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x9c>
    e918:      	cmp	x16, #0x0
    e91c:      	b.eq	0xe924 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x94>
    e920:      	b	0xe92c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x9c>
    e924:      	b	0xe95c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xcc>
    e928:      	b	0xe930 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xa0>
    e92c:      	b	0xe974 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe4>
    e930:      	add	x16, sp, #0x20
    e934:      	ldr	x0, [x16, #0x8]
    e938:      	str	x0, [x19]
    e93c:      	str	x20, [x19, #0x10]
    e940:      	movz	x0, #0x0, lsl #48
    e944:      	ldr	x19, [sp, #0x40]
    e948:      	ldr	x20, [sp, #0x48]
    e94c:      	ldr	x29, [sp]
    e950:      	ldr	x30, [sp, #0x8]
    e954:      	add	sp, sp, #0x50
    e958:      	ret
    e95c:      	lsl	x0, x20, #4
    e960:      	mov	x1, x0
    e964:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000e964:  ARM64_RELOC_PAGE21	l_stogir.531
    e968:      	ldr	x0, [x0]
		000000000000e968:  ARM64_RELOC_PAGEOFF12	l_stogir.531
    e96c:      	bl	0xe96c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xdc>
		000000000000e96c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e970:      	b	0xe970 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe0>
    e974:      	brk	#0
    e978:      	b	0xe974 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe4>

000000000000e97c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use>:
    e97c:      	sub	sp, sp, #0x50
    e980:      	str	x29, [sp]
    e984:      	str	x30, [sp, #0x8]
    e988:      	mov	x29, sp
    e98c:      	str	x19, [sp, #0x40]
    e990:      	str	x20, [sp, #0x48]
    e994:      	add	x2, x0, #0x18
    e998:      	ldr	x3, [x0, #0x10]
    e99c:      	ldr	x4, [x0, #0x18]
    e9a0:      	ldr	x2, [x2, #0x8]
    e9a4:      	add	x16, sp, #0x10
    e9a8:      	str	x4, [x16]
    e9ac:      	add	x16, sp, #0x10
    e9b0:      	str	x2, [x16, #0x8]
    e9b4:      	cmp	x1, x3
    e9b8:      	b.le	0xea2c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xb0>
    e9bc:      	add	x16, sp, #0x10
    e9c0:      	orr	x2, x16, xzr
    e9c4:      	ldr	x4, [x0]
    e9c8:      	add	x8, sp, #0x20
    e9cc:      	mov	x19, x0
    e9d0:      	mov	x0, x2
    e9d4:      	mov	x2, x3
    e9d8:      	mov	x3, x1
    e9dc:      	mov	x20, x1
    e9e0:      	mov	x1, x4
    e9e4:      	bl	0xe9e4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x68>
		000000000000e9e4:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Use
    e9e8:      	add	x16, sp, #0x20
    e9ec:      	ldr	w0, [x16]
    e9f0:      	lsr	x16, x0, #0
    e9f4:      	cmp	x16, #0x1
    e9f8:      	b.eq	0xea14 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x98>
    e9fc:      	b.lo	0xea04 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x88>
    ea00:      	b	0xea18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x9c>
    ea04:      	cmp	x16, #0x0
    ea08:      	b.eq	0xea10 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x94>
    ea0c:      	b	0xea18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x9c>
    ea10:      	b	0xea48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xcc>
    ea14:      	b	0xea1c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xa0>
    ea18:      	b	0xea60 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe4>
    ea1c:      	add	x16, sp, #0x20
    ea20:      	ldr	x0, [x16, #0x8]
    ea24:      	str	x0, [x19]
    ea28:      	str	x20, [x19, #0x10]
    ea2c:      	movz	x0, #0x0, lsl #48
    ea30:      	ldr	x19, [sp, #0x40]
    ea34:      	ldr	x20, [sp, #0x48]
    ea38:      	ldr	x29, [sp]
    ea3c:      	ldr	x30, [sp, #0x8]
    ea40:      	add	sp, sp, #0x50
    ea44:      	ret
    ea48:      	lsl	x0, x20, #3
    ea4c:      	mov	x1, x0
    ea50:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000ea50:  ARM64_RELOC_PAGE21	l_stogir.532
    ea54:      	ldr	x0, [x0]
		000000000000ea54:  ARM64_RELOC_PAGEOFF12	l_stogir.532
    ea58:      	bl	0xea58 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xdc>
		000000000000ea58:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    ea5c:      	b	0xea5c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe0>
    ea60:      	brk	#0
    ea64:      	b	0xea60 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe4>

000000000000ea68 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range>:
    ea68:      	sub	sp, sp, #0x50
    ea6c:      	str	x29, [sp]
    ea70:      	str	x30, [sp, #0x8]
    ea74:      	mov	x29, sp
    ea78:      	str	x19, [sp, #0x40]
    ea7c:      	str	x20, [sp, #0x48]
    ea80:      	add	x2, x0, #0x18
    ea84:      	ldr	x3, [x0, #0x10]
    ea88:      	ldr	x4, [x0, #0x18]
    ea8c:      	ldr	x2, [x2, #0x8]
    ea90:      	add	x16, sp, #0x10
    ea94:      	str	x4, [x16]
    ea98:      	add	x16, sp, #0x10
    ea9c:      	str	x2, [x16, #0x8]
    eaa0:      	cmp	x1, x3
    eaa4:      	b.le	0xeb18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xb0>
    eaa8:      	add	x16, sp, #0x10
    eaac:      	orr	x2, x16, xzr
    eab0:      	ldr	x4, [x0]
    eab4:      	add	x8, sp, #0x20
    eab8:      	mov	x19, x0
    eabc:      	mov	x0, x2
    eac0:      	mov	x2, x3
    eac4:      	mov	x3, x1
    eac8:      	mov	x20, x1
    eacc:      	mov	x1, x4
    ead0:      	bl	0xead0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x68>
		000000000000ead0:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.schedule.Range
    ead4:      	add	x16, sp, #0x20
    ead8:      	ldr	w0, [x16]
    eadc:      	lsr	x16, x0, #0
    eae0:      	cmp	x16, #0x1
    eae4:      	b.eq	0xeb00 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x98>
    eae8:      	b.lo	0xeaf0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x88>
    eaec:      	b	0xeb04 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x9c>
    eaf0:      	cmp	x16, #0x0
    eaf4:      	b.eq	0xeafc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x94>
    eaf8:      	b	0xeb04 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x9c>
    eafc:      	b	0xeb34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xcc>
    eb00:      	b	0xeb08 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xa0>
    eb04:      	b	0xeb4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe4>
    eb08:      	add	x16, sp, #0x20
    eb0c:      	ldr	x0, [x16, #0x8]
    eb10:      	str	x0, [x19]
    eb14:      	str	x20, [x19, #0x10]
    eb18:      	movz	x0, #0x0, lsl #48
    eb1c:      	ldr	x19, [sp, #0x40]
    eb20:      	ldr	x20, [sp, #0x48]
    eb24:      	ldr	x29, [sp]
    eb28:      	ldr	x30, [sp, #0x8]
    eb2c:      	add	sp, sp, #0x50
    eb30:      	ret
    eb34:      	lsl	x0, x20, #4
    eb38:      	mov	x1, x0
    eb3c:      	adrp	x0, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000eb3c:  ARM64_RELOC_PAGE21	l_stogir.533
    eb40:      	ldr	x0, [x0]
		000000000000eb40:  ARM64_RELOC_PAGEOFF12	l_stogir.533
    eb44:      	bl	0xeb44 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xdc>
		000000000000eb44:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    eb48:      	b	0xeb48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe0>
    eb4c:      	brk	#0
    eb50:      	b	0xeb4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe4>

000000000000eb54 <_stogir.checked.validate>:
    eb54:      	sub	sp, sp, #0x20
    eb58:      	str	x29, [sp]
    eb5c:      	str	x30, [sp, #0x8]
    eb60:      	mov	x29, sp
    eb64:      	str	x19, [sp, #0x10]
    eb68:      	sxtw	x1, w1
    eb6c:      	lsl	x2, x1, #2
    eb70:      	cmp	x1, #0x0
    eb74:      	cset	w3, gt
    eb78:      	movz	x16, #0x0, lsl #48
    eb7c:      	sub	x4, x16, x1
    eb80:      	sub	x5, x4, #0x1
    eb84:      	uxtb	w16, w3
    eb88:      	cmp	w16, wzr
    eb8c:      	b.eq	0xebcc <_stogir.checked.validate+0x78>
    eb90:      	ldr	x4, [x0, #0x8]
    eb94:      	cmp	x1, x4
    eb98:      	b.ge	0xec1c <_stogir.checked.validate+0xc8>
    eb9c:      	add	x4, x0, #0x78
    eba0:      	ldr	x4, [x4, #0x8]
    eba4:      	cmp	x1, x4
    eba8:      	b.ge	0xed68 <_stogir.checked.validate+0x214>
    ebac:      	ldr	x4, [x0, #0x78]
    ebb0:      	add	x4, x2, x4
    ebb4:      	ldr	w4, [x4]
    ebb8:      	sxtw	x4, w4
    ebbc:      	cmp	x4, #0x0
    ebc0:      	cset	w4, ge
    ebc4:      	ubfx	x4, x4, #0, #8
    ebc8:      	b	0xed6c <_stogir.checked.validate+0x218>
    ebcc:      	cmp	x1, #0x0
    ebd0:      	b.ge	0xec24 <_stogir.checked.validate+0xd0>
    ebd4:      	add	x6, x0, #0x28
    ebd8:      	add	x7, x0, #0x50
    ebdc:      	ldr	x6, [x6, #0x8]
    ebe0:      	ldr	x7, [x7, #0x8]
    ebe4:      	cmp	x6, x7
    ebe8:      	b.ne	0xec14 <_stogir.checked.validate+0xc0>
    ebec:      	cmp	x4, x6
    ebf0:      	b.gt	0xed70 <_stogir.checked.validate+0x21c>
    ebf4:      	ldr	x4, [x0, #0x50]
    ebf8:      	add	x4, x4, x5, lsl #2
    ebfc:      	ldr	w4, [x4]
    ec00:      	sxtw	x4, w4
    ec04:      	cmp	x4, #0x0
    ec08:      	cset	w4, gt
    ec0c:      	ubfx	x4, x4, #0, #8
    ec10:      	b	0xed74 <_stogir.checked.validate+0x220>
    ec14:      	movz	x4, #0x0, lsl #48
    ec18:      	b	0xec28 <_stogir.checked.validate+0xd4>
    ec1c:      	movz	x4, #0x0, lsl #48
    ec20:      	b	0xec28 <_stogir.checked.validate+0xd4>
    ec24:      	movz	x4, #0x0, lsl #48
    ec28:      	cmp	x4, #0x0
    ec2c:      	b.eq	0xec68 <_stogir.checked.validate+0x114>
    ec30:      	uxtb	w16, w3
    ec34:      	cmp	w16, wzr
    ec38:      	b.eq	0xec50 <_stogir.checked.validate+0xfc>
    ec3c:      	ldr	x3, [x0]
    ec40:      	add	x3, x3, x1, lsl #4
    ec44:      	ldr	x4, [x3]
    ec48:      	ldr	x3, [x3, #0x8]
    ec4c:      	b	0xec60 <_stogir.checked.validate+0x10c>
    ec50:      	ldr	x3, [x0, #0x28]
    ec54:      	add	x3, x3, x5, lsl #4
    ec58:      	ldr	x4, [x3]
    ec5c:      	ldr	x3, [x3, #0x8]
    ec60:      	mov	w5, #0x1                ; =1
    ec64:      	b	0xec74 <_stogir.checked.validate+0x120>
    ec68:      	movz	w5, #0x0, lsl #16
    ec6c:      	movz	x4, #0x0, lsl #48
    ec70:      	movz	x3, #0x0, lsl #48
    ec74:      	ubfx	x5, x5, #0, #32
    ec78:      	lsr	x16, x5, #0
    ec7c:      	cmp	x16, #0x1
    ec80:      	b.eq	0xec9c <_stogir.checked.validate+0x148>
    ec84:      	b.lo	0xec8c <_stogir.checked.validate+0x138>
    ec88:      	b	0xeca0 <_stogir.checked.validate+0x14c>
    ec8c:      	cmp	x16, #0x0
    ec90:      	b.eq	0xec98 <_stogir.checked.validate+0x144>
    ec94:      	b	0xeca0 <_stogir.checked.validate+0x14c>
    ec98:      	b	0xeca4 <_stogir.checked.validate+0x150>
    ec9c:      	b	0xecec <_stogir.checked.validate+0x198>
    eca0:      	b	0xef88 <_stogir.checked.validate+0x434>
    eca4:      	mov	x0, #0x1                ; =1
    eca8:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000eca8:  ARM64_RELOC_PAGE21	l_stogir.534
    ecac:      	ldr	x7, [x7]
		000000000000ecac:  ARM64_RELOC_PAGEOFF12	l_stogir.534
    ecb0:      	mov	x9, #0x1a               ; =26
    ecb4:      	b	0xecc8 <_stogir.checked.validate+0x174>
    ecb8:      	mov	x0, #0x1                ; =1
    ecbc:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000ecbc:  ARM64_RELOC_PAGE21	l_stogir.535
    ecc0:      	ldr	x7, [x7]
		000000000000ecc0:  ARM64_RELOC_PAGEOFF12	l_stogir.535
    ecc4:      	mov	x9, #0x26               ; =38
    ecc8:      	str	x0, [x8]
    eccc:      	str	x7, [x8, #0x8]
    ecd0:      	str	x9, [x8, #0x10]
    ecd4:      	sub	sp, x29, #0x0
    ecd8:      	ldr	x19, [sp, #0x10]
    ecdc:      	ldr	x29, [sp]
    ece0:      	ldr	x30, [sp, #0x8]
    ece4:      	add	sp, sp, #0x20
    ece8:      	ret
    ecec:      	cmp	x1, #0x0
    ecf0:      	b.le	0xecb8 <_stogir.checked.validate+0x164>
    ecf4:      	uxtb	w1, w4
    ecf8:      	cmp	x1, #0x29
    ecfc:      	b.lt	0xecb8 <_stogir.checked.validate+0x164>
    ed00:      	cmp	x1, #0x2b
    ed04:      	b.gt	0xecb8 <_stogir.checked.validate+0x164>
    ed08:      	ldr	x1, [x0, #0x78]
    ed0c:      	add	x1, x2, x1
    ed10:      	ldr	w1, [x1]
    ed14:      	sxtw	x1, w1
    ed18:      	cmp	x1, #0x2
    ed1c:      	b.ne	0xecb8 <_stogir.checked.validate+0x164>
    ed20:      	orr	w1, w4, wzr
    ed24:      	mov	x2, sp
    ed28:      	ubfx	x1, x1, #0, #32
    ed2c:      	sub	sp, sp, #0x10
    ed30:      	mov	x5, sp
    ed34:      	sub	sp, sp, #0x10
    ed38:      	mov	x6, sp
    ed3c:      	ubfx	x1, x1, #8, #8
    ed40:      	cmp	x1, #0x1
    ed44:      	b.lt	0xef40 <_stogir.checked.validate+0x3ec>
    ed48:      	cmp	x1, #0xb
    ed4c:      	b.gt	0xef40 <_stogir.checked.validate+0x3ec>
    ed50:      	cmp	x1, #0x1
    ed54:      	b.eq	0xef40 <_stogir.checked.validate+0x3ec>
    ed58:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000ed58:  ARM64_RELOC_PAGE21	l_stogir.536
    ed5c:      	ldr	x7, [x7]
		000000000000ed5c:  ARM64_RELOC_PAGEOFF12	l_stogir.536
    ed60:      	movz	x9, #0x0, lsl #48
    ed64:      	b	0xef4c <_stogir.checked.validate+0x3f8>
    ed68:      	movz	x4, #0x0, lsl #48
    ed6c:      	b	0xec20 <_stogir.checked.validate+0xcc>
    ed70:      	movz	x4, #0x0, lsl #48
    ed74:      	b	0xec18 <_stogir.checked.validate+0xc4>
    ed78:      	mov	x0, #0x1                ; =1
    ed7c:      	mov	sp, x2
    ed80:      	b	0xecc8 <_stogir.checked.validate+0x174>
    ed84:      	movz	w5, #0x0, lsl #16
    ed88:      	movz	x4, #0x0, lsl #48
    ed8c:      	ubfx	x5, x5, #0, #32
    ed90:      	lsr	x16, x5, #0
    ed94:      	cmp	x16, #0x1
    ed98:      	b.eq	0xedb4 <_stogir.checked.validate+0x260>
    ed9c:      	b.lo	0xeda4 <_stogir.checked.validate+0x250>
    eda0:      	b	0xedb8 <_stogir.checked.validate+0x264>
    eda4:      	cmp	x16, #0x0
    eda8:      	b.eq	0xedb0 <_stogir.checked.validate+0x25c>
    edac:      	b	0xedb8 <_stogir.checked.validate+0x264>
    edb0:      	b	0xedbc <_stogir.checked.validate+0x268>
    edb4:      	b	0xef20 <_stogir.checked.validate+0x3cc>
    edb8:      	b	0xefa0 <_stogir.checked.validate+0x44c>
    edbc:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000edbc:  ARM64_RELOC_PAGE21	l_stogir.537
    edc0:      	ldr	x7, [x7]
		000000000000edc0:  ARM64_RELOC_PAGEOFF12	l_stogir.537
    edc4:      	mov	x9, #0x22               ; =34
    edc8:      	cmp	x3, #0x2
    edcc:      	b.ge	0xedf0 <_stogir.checked.validate+0x29c>
    edd0:      	add	x4, x3, #0x1
    edd4:      	add	x3, x10, x3, lsl #2
    edd8:      	ldr	w3, [x3]
    eddc:      	movn	w17, #0x0, lsl #16
    ede0:      	and	w5, w3, w17
    ede4:      	mov	x3, x4
    ede8:      	mov	w4, #0x1                ; =1
    edec:      	b	0xedf8 <_stogir.checked.validate+0x2a4>
    edf0:      	movz	w4, #0x0, lsl #16
    edf4:      	movz	w5, #0x0, lsl #16
    edf8:      	ubfx	x4, x4, #0, #32
    edfc:      	lsr	x16, x4, #0
    ee00:      	cmp	x16, #0x1
    ee04:      	b.eq	0xee20 <_stogir.checked.validate+0x2cc>
    ee08:      	b.lo	0xee10 <_stogir.checked.validate+0x2bc>
    ee0c:      	b	0xee24 <_stogir.checked.validate+0x2d0>
    ee10:      	cmp	x16, #0x0
    ee14:      	b.eq	0xee1c <_stogir.checked.validate+0x2c8>
    ee18:      	b	0xee24 <_stogir.checked.validate+0x2d0>
    ee1c:      	b	0xee84 <_stogir.checked.validate+0x330>
    ee20:      	b	0xee28 <_stogir.checked.validate+0x2d4>
    ee24:      	b	0xef98 <_stogir.checked.validate+0x444>
    ee28:      	sxtw	x5, w5
    ee2c:      	cmp	x5, #0x0
    ee30:      	cset	w4, gt
    ee34:      	movz	x16, #0x0, lsl #48
    ee38:      	sub	x6, x16, x5
    ee3c:      	sub	x14, x6, #0x1
    ee40:      	uxtb	w16, w4
    ee44:      	cmp	w16, wzr
    ee48:      	b.eq	0xeee0 <_stogir.checked.validate+0x38c>
    ee4c:      	ldr	x6, [x0, #0x8]
    ee50:      	cmp	x5, x6
    ee54:      	b.ge	0xeed8 <_stogir.checked.validate+0x384>
    ee58:      	ldr	x6, [x11, #0x8]
    ee5c:      	cmp	x5, x6
    ee60:      	b.ge	0xef80 <_stogir.checked.validate+0x42c>
    ee64:      	ldr	x6, [x0, #0x78]
    ee68:      	add	x6, x6, x5, lsl #2
    ee6c:      	ldr	w6, [x6]
    ee70:      	sxtw	x6, w6
    ee74:      	cmp	x6, #0x0
    ee78:      	cset	w6, ge
    ee7c:      	ubfx	x6, x6, #0, #8
    ee80:      	b	0xef84 <_stogir.checked.validate+0x430>
    ee84:      	cmp	x9, #0x0
    ee88:      	b.ne	0xed78 <_stogir.checked.validate+0x224>
    ee8c:      	and	x7, x1, #0xffffffff
    ee90:      	movz	x0, #0x0, lsl #48
    ee94:      	movz	x9, #0x0, lsl #48
    ee98:      	b	0xed7c <_stogir.checked.validate+0x228>
    ee9c:      	ldr	x4, [x0, #0x28]
    eea0:      	add	x4, x4, x14, lsl #4
    eea4:      	ldr	x4, [x4]
    eea8:      	mov	w5, #0x1                ; =1
    eeac:      	b	0xed8c <_stogir.checked.validate+0x238>
    eeb0:      	movz	x6, #0x0, lsl #48
    eeb4:      	cmp	x6, #0x0
    eeb8:      	b.eq	0xed84 <_stogir.checked.validate+0x230>
    eebc:      	uxtb	w16, w4
    eec0:      	cmp	w16, wzr
    eec4:      	b.eq	0xee9c <_stogir.checked.validate+0x348>
    eec8:      	ldr	x4, [x0]
    eecc:      	add	x4, x4, x5, lsl #4
    eed0:      	ldr	x4, [x4]
    eed4:      	b	0xeea8 <_stogir.checked.validate+0x354>
    eed8:      	movz	x6, #0x0, lsl #48
    eedc:      	b	0xeeb4 <_stogir.checked.validate+0x360>
    eee0:      	cmp	x5, #0x0
    eee4:      	b.ge	0xeeb0 <_stogir.checked.validate+0x35c>
    eee8:      	ldr	x15, [x12, #0x8]
    eeec:      	ldr	x19, [x13, #0x8]
    eef0:      	cmp	x15, x19
    eef4:      	b.ne	0xef78 <_stogir.checked.validate+0x424>
    eef8:      	cmp	x6, x15
    eefc:      	b.gt	0xef90 <_stogir.checked.validate+0x43c>
    ef00:      	ldr	x6, [x0, #0x50]
    ef04:      	add	x6, x6, x14, lsl #2
    ef08:      	ldr	w6, [x6]
    ef0c:      	sxtw	x6, w6
    ef10:      	cmp	x6, #0x0
    ef14:      	cset	w6, gt
    ef18:      	ubfx	x6, x6, #0, #8
    ef1c:      	b	0xef94 <_stogir.checked.validate+0x440>
    ef20:      	ubfx	x4, x4, #0, #32
    ef24:      	ubfx	x4, x4, #8, #8
    ef28:      	cmp	x4, x1
    ef2c:      	b.eq	0xef3c <_stogir.checked.validate+0x3e8>
    ef30:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000ef30:  ARM64_RELOC_PAGE21	l_stogir.538
    ef34:      	ldr	x7, [x7]
		000000000000ef34:  ARM64_RELOC_PAGEOFF12	l_stogir.538
    ef38:      	mov	x9, #0x28               ; =40
    ef3c:      	b	0xedc8 <_stogir.checked.validate+0x274>
    ef40:      	adrp	x7, 0xe000 <_stogir.verify.phis-structured+0x1f4>
		000000000000ef40:  ARM64_RELOC_PAGE21	l_stogir.539
    ef44:      	ldr	x7, [x7]
		000000000000ef44:  ARM64_RELOC_PAGEOFF12	l_stogir.539
    ef48:      	mov	x9, #0x36               ; =54
    ef4c:      	orr	x10, x6, xzr
    ef50:      	add	x11, x0, #0x78
    ef54:      	add	x12, x0, #0x28
    ef58:      	add	x13, x0, #0x50
    ef5c:      	lsr	x4, x4, #32
    ef60:      	str	w4, [x5]
    ef64:      	str	w3, [x5, #0x4]
    ef68:      	ldr	x3, [x5]
    ef6c:      	str	x3, [x6]
    ef70:      	movz	x3, #0x0, lsl #48
    ef74:      	b	0xedc8 <_stogir.checked.validate+0x274>
    ef78:      	movz	x6, #0x0, lsl #48
    ef7c:      	b	0xeeb4 <_stogir.checked.validate+0x360>
    ef80:      	movz	x6, #0x0, lsl #48
    ef84:      	b	0xeedc <_stogir.checked.validate+0x388>
    ef88:      	brk	#0
    ef8c:      	b	0xef88 <_stogir.checked.validate+0x434>
    ef90:      	movz	x6, #0x0, lsl #48
    ef94:      	b	0xef7c <_stogir.checked.validate+0x428>
    ef98:      	brk	#0
    ef9c:      	b	0xef98 <_stogir.checked.validate+0x444>
    efa0:      	brk	#0
    efa4:      	b	0xefa0 <_stogir.checked.validate+0x44c>

000000000000efa8 <_coil.alloc.sized-request>:
    efa8:      	cmp	x3, #0x0
    efac:      	b.le	0xefd4 <_coil.alloc.sized-request+0x2c>
    efb0:      	cmp	x1, #0x0
    efb4:      	b.le	0xefd4 <_coil.alloc.sized-request+0x2c>
    efb8:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    efbc:      	sdiv	x4, x16, x1
    efc0:      	cmp	x3, x4
    efc4:      	b.gt	0xefd4 <_coil.alloc.sized-request+0x2c>
    efc8:      	mul	x1, x3, x1
    efcc:      	mov	x4, #0x1                ; =1
    efd0:      	b	0xefe8 <_coil.alloc.sized-request+0x40>
    efd4:      	movz	x4, #0x0, lsl #48
    efd8:      	movz	x0, #0x0, lsl #48
    efdc:      	movz	x3, #0x0, lsl #48
    efe0:      	movz	x1, #0x0, lsl #48
    efe4:      	movz	x2, #0x0, lsl #48
    efe8:      	str	x4, [x8]
    efec:      	str	x0, [x8, #0x8]
    eff0:      	str	x3, [x8, #0x10]
    eff4:      	str	x1, [x8, #0x18]
    eff8:      	str	x2, [x8, #0x20]
    effc:      	ret

000000000000f000 <_coil.alloc.raw-free>:
    f000:      	sub	sp, sp, #0x10
    f004:      	str	x29, [sp]
    f008:      	str	x30, [sp, #0x8]
    f00c:      	mov	x29, sp
    f010:      	ldr	x3, [x2, #0x8]
    f014:      	cmp	x3, #0x0
    f018:      	b.le	0xf060 <_coil.alloc.raw-free+0x60>
    f01c:      	ldr	x3, [x2, #0x10]
    f020:      	cmp	x3, #0x0
    f024:      	b.le	0xf060 <_coil.alloc.raw-free+0x60>
    f028:      	ldr	x3, [x2, #0x18]
    f02c:      	cmp	x3, #0x0
    f030:      	b.le	0xf060 <_coil.alloc.raw-free+0x60>
    f034:      	sub	x4, x3, #0x1
    f038:      	and	x3, x4, x3
    f03c:      	cmp	x3, #0x0
    f040:      	b.ne	0xf060 <_coil.alloc.raw-free+0x60>
    f044:      	ldr	x3, [x0]
    f048:      	ldr	x0, [x0, #0x8]
    f04c:      	ldr	x0, [x0, #0x18]
    f050:      	mov	x30, x0
    f054:      	mov	x0, x3
    f058:      	blr	x30
    f05c:      	b	0xf064 <_coil.alloc.raw-free+0x64>
    f060:      	movz	x0, #0x0, lsl #48
    f064:      	ldr	x29, [sp]
    f068:      	ldr	x30, [sp, #0x8]
    f06c:      	add	sp, sp, #0x10
    f070:      	ret

000000000000f074 <_coil.alloc.reallocate__i32>:
    f074:      	sub	sp, sp, #0x40
    f078:      	str	x29, [sp, #0x10]
    f07c:      	str	x30, [sp, #0x18]
    f080:      	add	x29, sp, #0x10
    f084:      	str	x19, [sp, #0x30]
    f088:      	str	x20, [sp, #0x38]
    f08c:      	mov	x19, x8
    f090:      	mov	x20, x3
    f094:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000f094:  ARM64_RELOC_PAGE21	l_stogir.540
    f098:      	ldr	x4, [x4]
		000000000000f098:  ARM64_RELOC_PAGEOFF12	l_stogir.540
    f09c:      	mov	x5, #0x4                ; =4
    f0a0:      	mov	x6, #0x4                ; =4
    f0a4:      	bl	0xf0a4 <_coil.alloc.reallocate__i32+0x30>
		000000000000f0a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f0a8:      	ubfx	x0, x0, #0, #32
    f0ac:      	lsr	x16, x0, #0
    f0b0:      	cmp	x16, #0x1
    f0b4:      	b.eq	0xf0d0 <_coil.alloc.reallocate__i32+0x5c>
    f0b8:      	b.lo	0xf0c0 <_coil.alloc.reallocate__i32+0x4c>
    f0bc:      	b	0xf0d4 <_coil.alloc.reallocate__i32+0x60>
    f0c0:      	cmp	x16, #0x0
    f0c4:      	b.eq	0xf0cc <_coil.alloc.reallocate__i32+0x58>
    f0c8:      	b	0xf0d4 <_coil.alloc.reallocate__i32+0x60>
    f0cc:      	b	0xf0d8 <_coil.alloc.reallocate__i32+0x64>
    f0d0:      	b	0xf0e8 <_coil.alloc.reallocate__i32+0x74>
    f0d4:      	b	0xf110 <_coil.alloc.reallocate__i32+0x9c>
    f0d8:      	movz	x0, #0x0, lsl #48
    f0dc:      	movz	x1, #0x0, lsl #48
    f0e0:      	movz	x20, #0x0, lsl #48
    f0e4:      	b	0xf0ec <_coil.alloc.reallocate__i32+0x78>
    f0e8:      	mov	x0, #0x1                ; =1
    f0ec:      	str	x0, [x19]
    f0f0:      	str	x1, [x19, #0x8]
    f0f4:      	str	x20, [x19, #0x10]
    f0f8:      	ldr	x19, [sp, #0x30]
    f0fc:      	ldr	x20, [sp, #0x38]
    f100:      	ldr	x29, [sp, #0x10]
    f104:      	ldr	x30, [sp, #0x18]
    f108:      	add	sp, sp, #0x40
    f10c:      	ret
    f110:      	brk	#0
    f114:      	b	0xf110 <_coil.alloc.reallocate__i32+0x9c>

000000000000f118 <_coil.alloc.oom-at>:
    f118:      	sub	sp, sp, #0x20
    f11c:      	str	x29, [sp]
    f120:      	str	x30, [sp, #0x8]
    f124:      	mov	x29, sp
    f128:      	str	x19, [sp, #0x10]
    f12c:      	str	x20, [sp, #0x18]
    f130:      	movz	x2, #0x0, lsl #48
    f134:      	b	0xf13c <_coil.alloc.oom-at+0x24>
    f138:      	add	x2, x2, #0x1
    f13c:      	adrp	x17, 0xf000 <_coil.alloc.raw-free>
		000000000000f13c:  ARM64_RELOC_PAGE21	l_stogir.541
    f140:      	ldr	x17, [x17]
		000000000000f140:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    f144:      	add	x3, x2, x17
    f148:      	ldrsb	w3, [x3]
    f14c:      	sxtb	x3, w3
    f150:      	cmp	x3, #0x0
    f154:      	b.ne	0xf138 <_coil.alloc.oom-at+0x20>
    f158:      	mov	x19, x0
    f15c:      	mov	x20, x1
    f160:      	mov	x0, #0x2                ; =2
    f164:      	adrp	x1, 0xf000 <_coil.alloc.raw-free>
		000000000000f164:  ARM64_RELOC_PAGE21	l_stogir.541
    f168:      	ldr	x1, [x1]
		000000000000f168:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    f16c:      	bl	0xf16c <_coil.alloc.oom-at+0x54>
		000000000000f16c:  ARM64_RELOC_BRANCH26	_write
    f170:      	movz	x0, #0x0, lsl #48
    f174:      	b	0xf17c <_coil.alloc.oom-at+0x64>
    f178:      	add	x0, x0, #0x1
    f17c:      	add	x1, x0, x19
    f180:      	ldrsb	w1, [x1]
    f184:      	sxtb	x1, w1
    f188:      	cmp	x1, #0x0
    f18c:      	b.ne	0xf178 <_coil.alloc.oom-at+0x60>
    f190:      	mov	x1, x19
    f194:      	mov	x2, x0
    f198:      	mov	x0, #0x2                ; =2
    f19c:      	bl	0xf19c <_coil.alloc.oom-at+0x84>
		000000000000f19c:  ARM64_RELOC_BRANCH26	_write
    f1a0:      	movz	x0, #0x0, lsl #48
    f1a4:      	b	0xf1ac <_coil.alloc.oom-at+0x94>
    f1a8:      	add	x0, x0, #0x1
    f1ac:      	adrp	x17, 0xf000 <_coil.alloc.raw-free>
		000000000000f1ac:  ARM64_RELOC_PAGE21	l_stogir.542
    f1b0:      	ldr	x17, [x17]
		000000000000f1b0:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    f1b4:      	add	x1, x0, x17
    f1b8:      	ldrsb	w1, [x1]
    f1bc:      	sxtb	x1, w1
    f1c0:      	cmp	x1, #0x0
    f1c4:      	b.ne	0xf1a8 <_coil.alloc.oom-at+0x90>
    f1c8:      	mov	x2, x0
    f1cc:      	mov	x0, #0x2                ; =2
    f1d0:      	adrp	x1, 0xf000 <_coil.alloc.raw-free>
		000000000000f1d0:  ARM64_RELOC_PAGE21	l_stogir.542
    f1d4:      	ldr	x1, [x1]
		000000000000f1d4:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    f1d8:      	bl	0xf1d8 <_coil.alloc.oom-at+0xc0>
		000000000000f1d8:  ARM64_RELOC_BRANCH26	_write
    f1dc:      	cmp	x20, #0x0
    f1e0:      	b.lt	0xf2cc <_coil.alloc.oom-at+0x1b4>
    f1e4:      	movz	x0, #0x0, lsl #48
    f1e8:      	b	0xf1f4 <_coil.alloc.oom-at+0xdc>
    f1ec:      	nop
    f1f0:      	add	x0, x0, #0x1
    f1f4:      	adrp	x17, 0xf000 <_coil.alloc.raw-free>
		000000000000f1f4:  ARM64_RELOC_PAGE21	l_stogir.543
    f1f8:      	ldr	x17, [x17]
		000000000000f1f8:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    f1fc:      	add	x1, x0, x17
    f200:      	ldrsb	w1, [x1]
    f204:      	sxtb	x1, w1
    f208:      	cmp	x1, #0x0
    f20c:      	b.ne	0xf1f0 <_coil.alloc.oom-at+0xd8>
    f210:      	mov	x2, x0
    f214:      	mov	x0, #0x2                ; =2
    f218:      	adrp	x1, 0xf000 <_coil.alloc.raw-free>
		000000000000f218:  ARM64_RELOC_PAGE21	l_stogir.543
    f21c:      	ldr	x1, [x1]
		000000000000f21c:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    f220:      	bl	0xf220 <_coil.alloc.oom-at+0x108>
		000000000000f220:  ARM64_RELOC_BRANCH26	_write
    f224:      	mov	x0, #0x18               ; =24
    f228:      	sub	x0, x0, #0x1
    f22c:      	adrp	x17, 0xf000 <_coil.alloc.raw-free>
		000000000000f22c:  ARM64_RELOC_PAGE21	l_stogir.544
    f230:      	ldr	x17, [x17]
		000000000000f230:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    f234:      	add	x1, x0, x17
    f238:      	mov	x17, #0xa               ; =10
    f23c:      	sdiv	x16, x20, x17
    f240:      	msub	x2, x16, x17, x20
    f244:      	mov	x17, #0xa               ; =10
    f248:      	sdiv	x3, x20, x17
    f24c:      	orr	x20, x3, xzr
    f250:      	add	x2, x2, #0x30
    f254:      	uxtb	w2, w2
    f258:      	uxtb	w2, w2
    f25c:      	strb	w2, [x1]
    f260:      	cmp	x20, #0x0
    f264:      	b.ne	0xf228 <_coil.alloc.oom-at+0x110>
    f268:      	mov	x16, #0x18              ; =24
    f26c:      	sub	x1, x16, x0
    f270:      	adrp	x16, 0xf000 <_coil.alloc.raw-free>
		000000000000f270:  ARM64_RELOC_PAGE21	l_stogir.544
    f274:      	ldr	x16, [x16]
		000000000000f274:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    f278:      	add	x0, x16, x0
    f27c:      	mov	x2, x1
    f280:      	mov	x1, x0
    f284:      	mov	x0, #0x2                ; =2
    f288:      	bl	0xf288 <_coil.alloc.oom-at+0x170>
		000000000000f288:  ARM64_RELOC_BRANCH26	_write
    f28c:      	movz	x0, #0x0, lsl #48
    f290:      	b	0xf29c <_coil.alloc.oom-at+0x184>
    f294:      	nop
    f298:      	add	x0, x0, #0x1
    f29c:      	adrp	x17, 0xf000 <_coil.alloc.raw-free>
		000000000000f29c:  ARM64_RELOC_PAGE21	l_stogir.545
    f2a0:      	ldr	x17, [x17]
		000000000000f2a0:  ARM64_RELOC_PAGEOFF12	l_stogir.545
    f2a4:      	add	x1, x0, x17
    f2a8:      	ldrsb	w1, [x1]
    f2ac:      	sxtb	x1, w1
    f2b0:      	cmp	x1, #0x0
    f2b4:      	b.ne	0xf298 <_coil.alloc.oom-at+0x180>
    f2b8:      	mov	x2, x0
    f2bc:      	mov	x0, #0x2                ; =2
    f2c0:      	adrp	x1, 0xf000 <_coil.alloc.raw-free>
		000000000000f2c0:  ARM64_RELOC_PAGE21	l_stogir.545
    f2c4:      	ldr	x1, [x1]
		000000000000f2c4:  ARM64_RELOC_PAGEOFF12	l_stogir.545
    f2c8:      	bl	0xf2c8 <_coil.alloc.oom-at+0x1b0>
		000000000000f2c8:  ARM64_RELOC_BRANCH26	_write
    f2cc:      	movz	x0, #0x0, lsl #48
    f2d0:      	b	0xf2dc <_coil.alloc.oom-at+0x1c4>
    f2d4:      	nop
    f2d8:      	add	x0, x0, #0x1
    f2dc:      	adrp	x17, 0xf000 <_coil.alloc.raw-free>
		000000000000f2dc:  ARM64_RELOC_PAGE21	l_stogir.546
    f2e0:      	ldr	x17, [x17]
		000000000000f2e0:  ARM64_RELOC_PAGEOFF12	l_stogir.546
    f2e4:      	add	x1, x0, x17
    f2e8:      	ldrsb	w1, [x1]
    f2ec:      	sxtb	x1, w1
    f2f0:      	cmp	x1, #0x0
    f2f4:      	b.ne	0xf2d8 <_coil.alloc.oom-at+0x1c0>
    f2f8:      	mov	x2, x0
    f2fc:      	mov	x0, #0x2                ; =2
    f300:      	adrp	x1, 0xf000 <_coil.alloc.raw-free>
		000000000000f300:  ARM64_RELOC_PAGE21	l_stogir.546
    f304:      	ldr	x1, [x1]
		000000000000f304:  ARM64_RELOC_PAGEOFF12	l_stogir.546
    f308:      	bl	0xf308 <_coil.alloc.oom-at+0x1f0>
		000000000000f308:  ARM64_RELOC_BRANCH26	_write
    f30c:      	bl	0xf30c <_coil.alloc.oom-at+0x1f4>
		000000000000f30c:  ARM64_RELOC_BRANCH26	_abort
    f310:      	b	0xf310 <_coil.alloc.oom-at+0x1f8>

000000000000f314 <_coil.alloc.reallocate__stogir.cfg.Edge>:
    f314:      	sub	sp, sp, #0x40
    f318:      	str	x29, [sp, #0x10]
    f31c:      	str	x30, [sp, #0x18]
    f320:      	add	x29, sp, #0x10
    f324:      	str	x19, [sp, #0x30]
    f328:      	str	x20, [sp, #0x38]
    f32c:      	mov	x19, x8
    f330:      	mov	x20, x3
    f334:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000f334:  ARM64_RELOC_PAGE21	l_stogir.547
    f338:      	ldr	x4, [x4]
		000000000000f338:  ARM64_RELOC_PAGEOFF12	l_stogir.547
    f33c:      	mov	x5, #0x10               ; =16
    f340:      	mov	x6, #0x4                ; =4
    f344:      	bl	0xf344 <_coil.alloc.reallocate__stogir.cfg.Edge+0x30>
		000000000000f344:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f348:      	ubfx	x0, x0, #0, #32
    f34c:      	lsr	x16, x0, #0
    f350:      	cmp	x16, #0x1
    f354:      	b.eq	0xf370 <_coil.alloc.reallocate__stogir.cfg.Edge+0x5c>
    f358:      	b.lo	0xf360 <_coil.alloc.reallocate__stogir.cfg.Edge+0x4c>
    f35c:      	b	0xf374 <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    f360:      	cmp	x16, #0x0
    f364:      	b.eq	0xf36c <_coil.alloc.reallocate__stogir.cfg.Edge+0x58>
    f368:      	b	0xf374 <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    f36c:      	b	0xf378 <_coil.alloc.reallocate__stogir.cfg.Edge+0x64>
    f370:      	b	0xf388 <_coil.alloc.reallocate__stogir.cfg.Edge+0x74>
    f374:      	b	0xf3b0 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>
    f378:      	movz	x0, #0x0, lsl #48
    f37c:      	movz	x1, #0x0, lsl #48
    f380:      	movz	x20, #0x0, lsl #48
    f384:      	b	0xf38c <_coil.alloc.reallocate__stogir.cfg.Edge+0x78>
    f388:      	mov	x0, #0x1                ; =1
    f38c:      	str	x0, [x19]
    f390:      	str	x1, [x19, #0x8]
    f394:      	str	x20, [x19, #0x10]
    f398:      	ldr	x19, [sp, #0x30]
    f39c:      	ldr	x20, [sp, #0x38]
    f3a0:      	ldr	x29, [sp, #0x10]
    f3a4:      	ldr	x30, [sp, #0x18]
    f3a8:      	add	sp, sp, #0x40
    f3ac:      	ret
    f3b0:      	brk	#0
    f3b4:      	b	0xf3b0 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>

000000000000f3b8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range>:
    f3b8:      	sub	sp, sp, #0x50
    f3bc:      	str	x29, [sp]
    f3c0:      	str	x30, [sp, #0x8]
    f3c4:      	mov	x29, sp
    f3c8:      	str	x19, [sp, #0x40]
    f3cc:      	str	x20, [sp, #0x48]
    f3d0:      	add	x2, x0, #0x18
    f3d4:      	ldr	x3, [x0, #0x10]
    f3d8:      	ldr	x4, [x0, #0x18]
    f3dc:      	ldr	x2, [x2, #0x8]
    f3e0:      	add	x16, sp, #0x10
    f3e4:      	str	x4, [x16]
    f3e8:      	add	x16, sp, #0x10
    f3ec:      	str	x2, [x16, #0x8]
    f3f0:      	cmp	x1, x3
    f3f4:      	b.le	0xf468 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xb0>
    f3f8:      	add	x16, sp, #0x10
    f3fc:      	orr	x2, x16, xzr
    f400:      	ldr	x4, [x0]
    f404:      	add	x8, sp, #0x20
    f408:      	mov	x19, x0
    f40c:      	mov	x0, x2
    f410:      	mov	x2, x3
    f414:      	mov	x3, x1
    f418:      	mov	x20, x1
    f41c:      	mov	x1, x4
    f420:      	bl	0xf420 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x68>
		000000000000f420:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Range
    f424:      	add	x16, sp, #0x20
    f428:      	ldr	w0, [x16]
    f42c:      	lsr	x16, x0, #0
    f430:      	cmp	x16, #0x1
    f434:      	b.eq	0xf450 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x98>
    f438:      	b.lo	0xf440 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x88>
    f43c:      	b	0xf454 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x9c>
    f440:      	cmp	x16, #0x0
    f444:      	b.eq	0xf44c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x94>
    f448:      	b	0xf454 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x9c>
    f44c:      	b	0xf484 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xcc>
    f450:      	b	0xf458 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xa0>
    f454:      	b	0xf49c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe4>
    f458:      	add	x16, sp, #0x20
    f45c:      	ldr	x0, [x16, #0x8]
    f460:      	str	x0, [x19]
    f464:      	str	x20, [x19, #0x10]
    f468:      	movz	x0, #0x0, lsl #48
    f46c:      	ldr	x19, [sp, #0x40]
    f470:      	ldr	x20, [sp, #0x48]
    f474:      	ldr	x29, [sp]
    f478:      	ldr	x30, [sp, #0x8]
    f47c:      	add	sp, sp, #0x50
    f480:      	ret
    f484:      	lsl	x0, x20, #4
    f488:      	mov	x1, x0
    f48c:      	adrp	x0, 0xf000 <_coil.alloc.raw-free>
		000000000000f48c:  ARM64_RELOC_PAGE21	l_stogir.548
    f490:      	ldr	x0, [x0]
		000000000000f490:  ARM64_RELOC_PAGEOFF12	l_stogir.548
    f494:      	bl	0xf494 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xdc>
		000000000000f494:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    f498:      	b	0xf498 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe0>
    f49c:      	brk	#0
    f4a0:      	b	0xf49c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe4>

000000000000f4a4 <_coil.alloc.reallocate__bool>:
    f4a4:      	sub	sp, sp, #0x40
    f4a8:      	str	x29, [sp, #0x10]
    f4ac:      	str	x30, [sp, #0x18]
    f4b0:      	add	x29, sp, #0x10
    f4b4:      	str	x19, [sp, #0x30]
    f4b8:      	str	x20, [sp, #0x38]
    f4bc:      	mov	x19, x8
    f4c0:      	mov	x20, x3
    f4c4:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000f4c4:  ARM64_RELOC_PAGE21	l_stogir.549
    f4c8:      	ldr	x4, [x4]
		000000000000f4c8:  ARM64_RELOC_PAGEOFF12	l_stogir.549
    f4cc:      	mov	x5, #0x1                ; =1
    f4d0:      	mov	x6, #0x1                ; =1
    f4d4:      	bl	0xf4d4 <_coil.alloc.reallocate__bool+0x30>
		000000000000f4d4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f4d8:      	ubfx	x0, x0, #0, #32
    f4dc:      	lsr	x16, x0, #0
    f4e0:      	cmp	x16, #0x1
    f4e4:      	b.eq	0xf500 <_coil.alloc.reallocate__bool+0x5c>
    f4e8:      	b.lo	0xf4f0 <_coil.alloc.reallocate__bool+0x4c>
    f4ec:      	b	0xf504 <_coil.alloc.reallocate__bool+0x60>
    f4f0:      	cmp	x16, #0x0
    f4f4:      	b.eq	0xf4fc <_coil.alloc.reallocate__bool+0x58>
    f4f8:      	b	0xf504 <_coil.alloc.reallocate__bool+0x60>
    f4fc:      	b	0xf508 <_coil.alloc.reallocate__bool+0x64>
    f500:      	b	0xf518 <_coil.alloc.reallocate__bool+0x74>
    f504:      	b	0xf540 <_coil.alloc.reallocate__bool+0x9c>
    f508:      	movz	x0, #0x0, lsl #48
    f50c:      	movz	x1, #0x0, lsl #48
    f510:      	movz	x20, #0x0, lsl #48
    f514:      	b	0xf51c <_coil.alloc.reallocate__bool+0x78>
    f518:      	mov	x0, #0x1                ; =1
    f51c:      	str	x0, [x19]
    f520:      	str	x1, [x19, #0x8]
    f524:      	str	x20, [x19, #0x10]
    f528:      	ldr	x19, [sp, #0x30]
    f52c:      	ldr	x20, [sp, #0x38]
    f530:      	ldr	x29, [sp, #0x10]
    f534:      	ldr	x30, [sp, #0x18]
    f538:      	add	sp, sp, #0x40
    f53c:      	ret
    f540:      	brk	#0
    f544:      	b	0xf540 <_coil.alloc.reallocate__bool+0x9c>

000000000000f548 <_coil.alloc.reallocate__stogir.adjacency.Frame>:
    f548:      	sub	sp, sp, #0x40
    f54c:      	str	x29, [sp, #0x10]
    f550:      	str	x30, [sp, #0x18]
    f554:      	add	x29, sp, #0x10
    f558:      	str	x19, [sp, #0x30]
    f55c:      	str	x20, [sp, #0x38]
    f560:      	mov	x19, x8
    f564:      	mov	x20, x3
    f568:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000f568:  ARM64_RELOC_PAGE21	l_stogir.550
    f56c:      	ldr	x4, [x4]
		000000000000f56c:  ARM64_RELOC_PAGEOFF12	l_stogir.550
    f570:      	mov	x5, #0x10               ; =16
    f574:      	mov	x6, #0x8                ; =8
    f578:      	bl	0xf578 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x30>
		000000000000f578:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f57c:      	ubfx	x0, x0, #0, #32
    f580:      	lsr	x16, x0, #0
    f584:      	cmp	x16, #0x1
    f588:      	b.eq	0xf5a4 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x5c>
    f58c:      	b.lo	0xf594 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x4c>
    f590:      	b	0xf5a8 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    f594:      	cmp	x16, #0x0
    f598:      	b.eq	0xf5a0 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x58>
    f59c:      	b	0xf5a8 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    f5a0:      	b	0xf5ac <_coil.alloc.reallocate__stogir.adjacency.Frame+0x64>
    f5a4:      	b	0xf5bc <_coil.alloc.reallocate__stogir.adjacency.Frame+0x74>
    f5a8:      	b	0xf5e4 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>
    f5ac:      	movz	x0, #0x0, lsl #48
    f5b0:      	movz	x1, #0x0, lsl #48
    f5b4:      	movz	x20, #0x0, lsl #48
    f5b8:      	b	0xf5c0 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x78>
    f5bc:      	mov	x0, #0x1                ; =1
    f5c0:      	str	x0, [x19]
    f5c4:      	str	x1, [x19, #0x8]
    f5c8:      	str	x20, [x19, #0x10]
    f5cc:      	ldr	x19, [sp, #0x30]
    f5d0:      	ldr	x20, [sp, #0x38]
    f5d4:      	ldr	x29, [sp, #0x10]
    f5d8:      	ldr	x30, [sp, #0x18]
    f5dc:      	add	sp, sp, #0x40
    f5e0:      	ret
    f5e4:      	brk	#0
    f5e8:      	b	0xf5e4 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>

000000000000f5ec <_coil.alloc.reallocate__i64>:
    f5ec:      	sub	sp, sp, #0x40
    f5f0:      	str	x29, [sp, #0x10]
    f5f4:      	str	x30, [sp, #0x18]
    f5f8:      	add	x29, sp, #0x10
    f5fc:      	str	x19, [sp, #0x30]
    f600:      	str	x20, [sp, #0x38]
    f604:      	mov	x19, x8
    f608:      	mov	x20, x3
    f60c:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000f60c:  ARM64_RELOC_PAGE21	l_stogir.551
    f610:      	ldr	x4, [x4]
		000000000000f610:  ARM64_RELOC_PAGEOFF12	l_stogir.551
    f614:      	mov	x5, #0x8                ; =8
    f618:      	mov	x6, #0x8                ; =8
    f61c:      	bl	0xf61c <_coil.alloc.reallocate__i64+0x30>
		000000000000f61c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f620:      	ubfx	x0, x0, #0, #32
    f624:      	lsr	x16, x0, #0
    f628:      	cmp	x16, #0x1
    f62c:      	b.eq	0xf648 <_coil.alloc.reallocate__i64+0x5c>
    f630:      	b.lo	0xf638 <_coil.alloc.reallocate__i64+0x4c>
    f634:      	b	0xf64c <_coil.alloc.reallocate__i64+0x60>
    f638:      	cmp	x16, #0x0
    f63c:      	b.eq	0xf644 <_coil.alloc.reallocate__i64+0x58>
    f640:      	b	0xf64c <_coil.alloc.reallocate__i64+0x60>
    f644:      	b	0xf650 <_coil.alloc.reallocate__i64+0x64>
    f648:      	b	0xf660 <_coil.alloc.reallocate__i64+0x74>
    f64c:      	b	0xf688 <_coil.alloc.reallocate__i64+0x9c>
    f650:      	movz	x0, #0x0, lsl #48
    f654:      	movz	x1, #0x0, lsl #48
    f658:      	movz	x20, #0x0, lsl #48
    f65c:      	b	0xf664 <_coil.alloc.reallocate__i64+0x78>
    f660:      	mov	x0, #0x1                ; =1
    f664:      	str	x0, [x19]
    f668:      	str	x1, [x19, #0x8]
    f66c:      	str	x20, [x19, #0x10]
    f670:      	ldr	x19, [sp, #0x30]
    f674:      	ldr	x20, [sp, #0x38]
    f678:      	ldr	x29, [sp, #0x10]
    f67c:      	ldr	x30, [sp, #0x18]
    f680:      	add	sp, sp, #0x40
    f684:      	ret
    f688:      	brk	#0
    f68c:      	b	0xf688 <_coil.alloc.reallocate__i64+0x9c>

000000000000f690 <_coil.alloc.reallocate__stogir.uses.Range>:
    f690:      	sub	sp, sp, #0x40
    f694:      	str	x29, [sp, #0x10]
    f698:      	str	x30, [sp, #0x18]
    f69c:      	add	x29, sp, #0x10
    f6a0:      	str	x19, [sp, #0x30]
    f6a4:      	str	x20, [sp, #0x38]
    f6a8:      	mov	x19, x8
    f6ac:      	mov	x20, x3
    f6b0:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000f6b0:  ARM64_RELOC_PAGE21	l_stogir.552
    f6b4:      	ldr	x4, [x4]
		000000000000f6b4:  ARM64_RELOC_PAGEOFF12	l_stogir.552
    f6b8:      	mov	x5, #0x10               ; =16
    f6bc:      	mov	x6, #0x8                ; =8
    f6c0:      	bl	0xf6c0 <_coil.alloc.reallocate__stogir.uses.Range+0x30>
		000000000000f6c0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f6c4:      	ubfx	x0, x0, #0, #32
    f6c8:      	lsr	x16, x0, #0
    f6cc:      	cmp	x16, #0x1
    f6d0:      	b.eq	0xf6ec <_coil.alloc.reallocate__stogir.uses.Range+0x5c>
    f6d4:      	b.lo	0xf6dc <_coil.alloc.reallocate__stogir.uses.Range+0x4c>
    f6d8:      	b	0xf6f0 <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    f6dc:      	cmp	x16, #0x0
    f6e0:      	b.eq	0xf6e8 <_coil.alloc.reallocate__stogir.uses.Range+0x58>
    f6e4:      	b	0xf6f0 <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    f6e8:      	b	0xf6f4 <_coil.alloc.reallocate__stogir.uses.Range+0x64>
    f6ec:      	b	0xf704 <_coil.alloc.reallocate__stogir.uses.Range+0x74>
    f6f0:      	b	0xf72c <_coil.alloc.reallocate__stogir.uses.Range+0x9c>
    f6f4:      	movz	x0, #0x0, lsl #48
    f6f8:      	movz	x1, #0x0, lsl #48
    f6fc:      	movz	x20, #0x0, lsl #48
    f700:      	b	0xf708 <_coil.alloc.reallocate__stogir.uses.Range+0x78>
    f704:      	mov	x0, #0x1                ; =1
    f708:      	str	x0, [x19]
    f70c:      	str	x1, [x19, #0x8]
    f710:      	str	x20, [x19, #0x10]
    f714:      	ldr	x19, [sp, #0x30]
    f718:      	ldr	x20, [sp, #0x38]
    f71c:      	ldr	x29, [sp, #0x10]
    f720:      	ldr	x30, [sp, #0x18]
    f724:      	add	sp, sp, #0x40
    f728:      	ret
    f72c:      	brk	#0
    f730:      	b	0xf72c <_coil.alloc.reallocate__stogir.uses.Range+0x9c>

000000000000f734 <_coil.alloc.reallocate__stogir.uses.Use>:
    f734:      	sub	sp, sp, #0x40
    f738:      	str	x29, [sp, #0x10]
    f73c:      	str	x30, [sp, #0x18]
    f740:      	add	x29, sp, #0x10
    f744:      	str	x19, [sp, #0x30]
    f748:      	str	x20, [sp, #0x38]
    f74c:      	mov	x19, x8
    f750:      	mov	x20, x3
    f754:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000f754:  ARM64_RELOC_PAGE21	l_stogir.553
    f758:      	ldr	x4, [x4]
		000000000000f758:  ARM64_RELOC_PAGEOFF12	l_stogir.553
    f75c:      	mov	x5, #0x8                ; =8
    f760:      	mov	x6, #0x4                ; =4
    f764:      	bl	0xf764 <_coil.alloc.reallocate__stogir.uses.Use+0x30>
		000000000000f764:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f768:      	ubfx	x0, x0, #0, #32
    f76c:      	lsr	x16, x0, #0
    f770:      	cmp	x16, #0x1
    f774:      	b.eq	0xf790 <_coil.alloc.reallocate__stogir.uses.Use+0x5c>
    f778:      	b.lo	0xf780 <_coil.alloc.reallocate__stogir.uses.Use+0x4c>
    f77c:      	b	0xf794 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    f780:      	cmp	x16, #0x0
    f784:      	b.eq	0xf78c <_coil.alloc.reallocate__stogir.uses.Use+0x58>
    f788:      	b	0xf794 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    f78c:      	b	0xf798 <_coil.alloc.reallocate__stogir.uses.Use+0x64>
    f790:      	b	0xf7a8 <_coil.alloc.reallocate__stogir.uses.Use+0x74>
    f794:      	b	0xf7d0 <_coil.alloc.reallocate__stogir.uses.Use+0x9c>
    f798:      	movz	x0, #0x0, lsl #48
    f79c:      	movz	x1, #0x0, lsl #48
    f7a0:      	movz	x20, #0x0, lsl #48
    f7a4:      	b	0xf7ac <_coil.alloc.reallocate__stogir.uses.Use+0x78>
    f7a8:      	mov	x0, #0x1                ; =1
    f7ac:      	str	x0, [x19]
    f7b0:      	str	x1, [x19, #0x8]
    f7b4:      	str	x20, [x19, #0x10]
    f7b8:      	ldr	x19, [sp, #0x30]
    f7bc:      	ldr	x20, [sp, #0x38]
    f7c0:      	ldr	x29, [sp, #0x10]
    f7c4:      	ldr	x30, [sp, #0x18]
    f7c8:      	add	sp, sp, #0x40
    f7cc:      	ret
    f7d0:      	brk	#0
    f7d4:      	b	0xf7d0 <_coil.alloc.reallocate__stogir.uses.Use+0x9c>

000000000000f7d8 <_coil.alloc.reallocate__stogir.schedule.Range>:
    f7d8:      	sub	sp, sp, #0x40
    f7dc:      	str	x29, [sp, #0x10]
    f7e0:      	str	x30, [sp, #0x18]
    f7e4:      	add	x29, sp, #0x10
    f7e8:      	str	x19, [sp, #0x30]
    f7ec:      	str	x20, [sp, #0x38]
    f7f0:      	mov	x19, x8
    f7f4:      	mov	x20, x3
    f7f8:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000f7f8:  ARM64_RELOC_PAGE21	l_stogir.554
    f7fc:      	ldr	x4, [x4]
		000000000000f7fc:  ARM64_RELOC_PAGEOFF12	l_stogir.554
    f800:      	mov	x5, #0x10               ; =16
    f804:      	mov	x6, #0x8                ; =8
    f808:      	bl	0xf808 <_coil.alloc.reallocate__stogir.schedule.Range+0x30>
		000000000000f808:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f80c:      	ubfx	x0, x0, #0, #32
    f810:      	lsr	x16, x0, #0
    f814:      	cmp	x16, #0x1
    f818:      	b.eq	0xf834 <_coil.alloc.reallocate__stogir.schedule.Range+0x5c>
    f81c:      	b.lo	0xf824 <_coil.alloc.reallocate__stogir.schedule.Range+0x4c>
    f820:      	b	0xf838 <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    f824:      	cmp	x16, #0x0
    f828:      	b.eq	0xf830 <_coil.alloc.reallocate__stogir.schedule.Range+0x58>
    f82c:      	b	0xf838 <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    f830:      	b	0xf83c <_coil.alloc.reallocate__stogir.schedule.Range+0x64>
    f834:      	b	0xf84c <_coil.alloc.reallocate__stogir.schedule.Range+0x74>
    f838:      	b	0xf874 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>
    f83c:      	movz	x0, #0x0, lsl #48
    f840:      	movz	x1, #0x0, lsl #48
    f844:      	movz	x20, #0x0, lsl #48
    f848:      	b	0xf850 <_coil.alloc.reallocate__stogir.schedule.Range+0x78>
    f84c:      	mov	x0, #0x1                ; =1
    f850:      	str	x0, [x19]
    f854:      	str	x1, [x19, #0x8]
    f858:      	str	x20, [x19, #0x10]
    f85c:      	ldr	x19, [sp, #0x30]
    f860:      	ldr	x20, [sp, #0x38]
    f864:      	ldr	x29, [sp, #0x10]
    f868:      	ldr	x30, [sp, #0x18]
    f86c:      	add	sp, sp, #0x40
    f870:      	ret
    f874:      	brk	#0
    f878:      	b	0xf874 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>

000000000000f87c <_coil.alloc.sized-reallocate>:
    f87c:      	sub	sp, sp, #0x90
    f880:      	str	x29, [sp, #0x10]
    f884:      	str	x30, [sp, #0x18]
    f888:      	add	x29, sp, #0x10
    f88c:      	str	x19, [sp, #0x50]
    f890:      	str	x20, [sp, #0x58]
    f894:      	str	x21, [sp, #0x60]
    f898:      	str	x22, [sp, #0x68]
    f89c:      	str	x23, [sp, #0x70]
    f8a0:      	str	x24, [sp, #0x78]
    f8a4:      	str	x25, [sp, #0x80]
    f8a8:      	str	x26, [sp, #0x88]
    f8ac:      	add	x19, sp, #0x20
    f8b0:      	mov	x20, x0
    f8b4:      	mov	x21, x1
    f8b8:      	mov	x22, x2
    f8bc:      	mov	x23, x3
    f8c0:      	mov	x24, x4
    f8c4:      	mov	x25, x5
    f8c8:      	mov	x26, x6
    f8cc:      	movz	x7, #0x0, lsl #48
    f8d0:      	uxtb	w7, w7
    f8d4:      	bl	0xf8d4 <_coil.alloc.sized-reallocate+0x58>
		000000000000f8d4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-resize
    f8d8:      	ubfx	x0, x0, #0, #32
    f8dc:      	lsr	x16, x0, #0
    f8e0:      	cmp	x16, #0x1
    f8e4:      	b.eq	0xf900 <_coil.alloc.sized-reallocate+0x84>
    f8e8:      	b.lo	0xf8f0 <_coil.alloc.sized-reallocate+0x74>
    f8ec:      	b	0xf904 <_coil.alloc.sized-reallocate+0x88>
    f8f0:      	cmp	x16, #0x0
    f8f4:      	b.eq	0xf8fc <_coil.alloc.sized-reallocate+0x80>
    f8f8:      	b	0xf904 <_coil.alloc.sized-reallocate+0x88>
    f8fc:      	b	0xf950 <_coil.alloc.sized-reallocate+0xd4>
    f900:      	b	0xf908 <_coil.alloc.sized-reallocate+0x8c>
    f904:      	b	0xf9f0 <_coil.alloc.sized-reallocate+0x174>
    f908:      	mov	x23, x1
    f90c:      	mov	x0, #0x1                ; =1
    f910:      	str	x0, [x19]
    f914:      	str	x23, [x19, #0x8]
    f918:      	ldr	x0, [sp, #0x20]
    f91c:      	ldr	x1, [sp, #0x28]
    f920:      	ldr	x19, [sp, #0x50]
    f924:      	ldr	x20, [sp, #0x58]
    f928:      	ldr	x21, [sp, #0x60]
    f92c:      	ldr	x22, [sp, #0x68]
    f930:      	ldr	x23, [sp, #0x70]
    f934:      	ldr	x24, [sp, #0x78]
    f938:      	ldr	x25, [sp, #0x80]
    f93c:      	ldr	x26, [sp, #0x88]
    f940:      	ldr	x29, [sp, #0x10]
    f944:      	ldr	x30, [sp, #0x18]
    f948:      	add	sp, sp, #0x90
    f94c:      	ret
    f950:      	mov	x0, x20
    f954:      	mov	x1, x24
    f958:      	mov	x2, x25
    f95c:      	mov	x3, x26
    f960:      	mov	x4, x23
    f964:      	bl	0xf964 <_coil.alloc.sized-reallocate+0xe8>
		000000000000f964:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    f968:      	ubfx	x0, x0, #0, #32
    f96c:      	lsr	x16, x0, #0
    f970:      	cmp	x16, #0x1
    f974:      	b.eq	0xf990 <_coil.alloc.sized-reallocate+0x114>
    f978:      	b.lo	0xf980 <_coil.alloc.sized-reallocate+0x104>
    f97c:      	b	0xf994 <_coil.alloc.sized-reallocate+0x118>
    f980:      	cmp	x16, #0x0
    f984:      	b.eq	0xf98c <_coil.alloc.sized-reallocate+0x110>
    f988:      	b	0xf994 <_coil.alloc.sized-reallocate+0x118>
    f98c:      	b	0xf998 <_coil.alloc.sized-reallocate+0x11c>
    f990:      	b	0xf9a4 <_coil.alloc.sized-reallocate+0x128>
    f994:      	b	0xf9f8 <_coil.alloc.sized-reallocate+0x17c>
    f998:      	movz	x0, #0x0, lsl #48
    f99c:      	movz	x23, #0x0, lsl #48
    f9a0:      	b	0xf9ec <_coil.alloc.sized-reallocate+0x170>
    f9a4:      	cmp	x22, x23
    f9a8:      	b.ge	0xf9b0 <_coil.alloc.sized-reallocate+0x134>
    f9ac:      	mov	x23, x22
    f9b0:      	mul	x0, x25, x23
    f9b4:      	lsr	x0, x0, #0
    f9b8:      	mov	x2, x0
    f9bc:      	mov	x0, x1
    f9c0:      	mov	x23, x1
    f9c4:      	mov	x1, x21
    f9c8:      	bl	0xf9c8 <_coil.alloc.sized-reallocate+0x14c>
		000000000000f9c8:  ARM64_RELOC_BRANCH26	_memcpy
    f9cc:      	mov	x0, x20
    f9d0:      	mov	x1, x21
    f9d4:      	mov	x2, x22
    f9d8:      	mov	x3, x24
    f9dc:      	mov	x4, x25
    f9e0:      	mov	x5, x26
    f9e4:      	bl	0xf9e4 <_coil.alloc.sized-reallocate+0x168>
		000000000000f9e4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    f9e8:      	mov	x0, #0x1                ; =1
    f9ec:      	b	0xf910 <_coil.alloc.sized-reallocate+0x94>
    f9f0:      	brk	#0
    f9f4:      	b	0xf9f0 <_coil.alloc.sized-reallocate+0x174>
    f9f8:      	brk	#0
    f9fc:      	b	0xf9f8 <_coil.alloc.sized-reallocate+0x17c>

000000000000fa00 <_coil.alloc.reallocate__stogir.adjacency.Range>:
    fa00:      	sub	sp, sp, #0x40
    fa04:      	str	x29, [sp, #0x10]
    fa08:      	str	x30, [sp, #0x18]
    fa0c:      	add	x29, sp, #0x10
    fa10:      	str	x19, [sp, #0x30]
    fa14:      	str	x20, [sp, #0x38]
    fa18:      	mov	x19, x8
    fa1c:      	mov	x20, x3
    fa20:      	adrp	x4, 0xf000 <_coil.alloc.raw-free>
		000000000000fa20:  ARM64_RELOC_PAGE21	l_stogir.555
    fa24:      	ldr	x4, [x4]
		000000000000fa24:  ARM64_RELOC_PAGEOFF12	l_stogir.555
    fa28:      	mov	x5, #0x10               ; =16
    fa2c:      	mov	x6, #0x8                ; =8
    fa30:      	bl	0xfa30 <_coil.alloc.reallocate__stogir.adjacency.Range+0x30>
		000000000000fa30:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    fa34:      	ubfx	x0, x0, #0, #32
    fa38:      	lsr	x16, x0, #0
    fa3c:      	cmp	x16, #0x1
    fa40:      	b.eq	0xfa5c <_coil.alloc.reallocate__stogir.adjacency.Range+0x5c>
    fa44:      	b.lo	0xfa4c <_coil.alloc.reallocate__stogir.adjacency.Range+0x4c>
    fa48:      	b	0xfa60 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    fa4c:      	cmp	x16, #0x0
    fa50:      	b.eq	0xfa58 <_coil.alloc.reallocate__stogir.adjacency.Range+0x58>
    fa54:      	b	0xfa60 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    fa58:      	b	0xfa64 <_coil.alloc.reallocate__stogir.adjacency.Range+0x64>
    fa5c:      	b	0xfa74 <_coil.alloc.reallocate__stogir.adjacency.Range+0x74>
    fa60:      	b	0xfa9c <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>
    fa64:      	movz	x0, #0x0, lsl #48
    fa68:      	movz	x1, #0x0, lsl #48
    fa6c:      	movz	x20, #0x0, lsl #48
    fa70:      	b	0xfa78 <_coil.alloc.reallocate__stogir.adjacency.Range+0x78>
    fa74:      	mov	x0, #0x1                ; =1
    fa78:      	str	x0, [x19]
    fa7c:      	str	x1, [x19, #0x8]
    fa80:      	str	x20, [x19, #0x10]
    fa84:      	ldr	x19, [sp, #0x30]
    fa88:      	ldr	x20, [sp, #0x38]
    fa8c:      	ldr	x29, [sp, #0x10]
    fa90:      	ldr	x30, [sp, #0x18]
    fa94:      	add	sp, sp, #0x40
    fa98:      	ret
    fa9c:      	brk	#0
    faa0:      	b	0xfa9c <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>

000000000000faa4 <_coil.alloc.sized-resize>:
    faa4:      	sub	sp, sp, #0x130
    faa8:      	str	x29, [sp, #0x10]
    faac:      	str	x30, [sp, #0x18]
    fab0:      	add	x29, sp, #0x10
    fab4:      	str	x19, [sp, #0xf0]
    fab8:      	str	x20, [sp, #0xf8]
    fabc:      	str	x21, [sp, #0x100]
    fac0:      	str	x22, [sp, #0x108]
    fac4:      	str	x23, [sp, #0x110]
    fac8:      	str	x24, [sp, #0x118]
    facc:      	str	x25, [sp, #0x120]
    fad0:      	str	x26, [sp, #0x128]
    fad4:      	add	x19, sp, #0x20
    fad8:      	cmp	x3, #0x0
    fadc:      	b.ne	0xfb38 <_coil.alloc.sized-resize+0x94>
    fae0:      	mov	x3, x4
    fae4:      	mov	x4, x5
    fae8:      	mov	x5, x6
    faec:      	bl	0xfaec <_coil.alloc.sized-resize+0x48>
		000000000000faec:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    faf0:      	mov	x0, #0x1                ; =1
    faf4:      	movz	x1, #0x0, lsl #48
    faf8:      	str	x0, [x19]
    fafc:      	str	x1, [x19, #0x8]
    fb00:      	ldr	x0, [sp, #0x20]
    fb04:      	ldr	x1, [sp, #0x28]
    fb08:      	ldr	x19, [sp, #0xf0]
    fb0c:      	ldr	x20, [sp, #0xf8]
    fb10:      	ldr	x21, [sp, #0x100]
    fb14:      	ldr	x22, [sp, #0x108]
    fb18:      	ldr	x23, [sp, #0x110]
    fb1c:      	ldr	x24, [sp, #0x118]
    fb20:      	ldr	x25, [sp, #0x120]
    fb24:      	ldr	x26, [sp, #0x128]
    fb28:      	ldr	x29, [sp, #0x10]
    fb2c:      	ldr	x30, [sp, #0x18]
    fb30:      	add	sp, sp, #0x130
    fb34:      	ret
    fb38:      	cmp	x2, #0x0
    fb3c:      	b.ne	0xfb58 <_coil.alloc.sized-resize+0xb4>
    fb40:      	mov	x1, x4
    fb44:      	mov	x2, x5
    fb48:      	mov	x4, x3
    fb4c:      	mov	x3, x6
    fb50:      	bl	0xfb50 <_coil.alloc.sized-resize+0xac>
		000000000000fb50:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    fb54:      	b	0xfaf8 <_coil.alloc.sized-resize+0x54>
    fb58:      	add	x8, sp, #0x30
    fb5c:      	mov	x20, x0
    fb60:      	mov	x0, x4
    fb64:      	mov	x21, x1
    fb68:      	mov	x1, x5
    fb6c:      	mov	x22, x3
    fb70:      	mov	x3, x2
    fb74:      	mov	x2, x6
    fb78:      	mov	x23, x4
    fb7c:      	mov	x24, x5
    fb80:      	mov	x25, x6
    fb84:      	mov	w26, w7
    fb88:      	bl	0xfb88 <_coil.alloc.sized-resize+0xe4>
		000000000000fb88:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    fb8c:      	add	x16, sp, #0x30
    fb90:      	ldr	w0, [x16]
    fb94:      	lsr	x16, x0, #0
    fb98:      	cmp	x16, #0x1
    fb9c:      	b.eq	0xfbb8 <_coil.alloc.sized-resize+0x114>
    fba0:      	b.lo	0xfba8 <_coil.alloc.sized-resize+0x104>
    fba4:      	b	0xfbbc <_coil.alloc.sized-resize+0x118>
    fba8:      	cmp	x16, #0x0
    fbac:      	b.eq	0xfbb4 <_coil.alloc.sized-resize+0x110>
    fbb0:      	b	0xfbbc <_coil.alloc.sized-resize+0x118>
    fbb4:      	b	0xfbc0 <_coil.alloc.sized-resize+0x11c>
    fbb8:      	b	0xfbcc <_coil.alloc.sized-resize+0x128>
    fbbc:      	b	0xfd0c <_coil.alloc.sized-resize+0x268>
    fbc0:      	movz	x0, #0x0, lsl #48
    fbc4:      	movz	x1, #0x0, lsl #48
    fbc8:      	b	0xfb54 <_coil.alloc.sized-resize+0xb0>
    fbcc:      	add	x16, sp, #0x30
    fbd0:      	orr	x0, x16, xzr
    fbd4:      	add	x0, x0, #0x8
    fbd8:      	add	x16, sp, #0x30
    fbdc:      	ldr	x1, [x16, #0x8]
    fbe0:      	add	x16, sp, #0x60
    fbe4:      	str	x1, [x16]
    fbe8:      	ldr	x1, [x0, #0x8]
    fbec:      	add	x16, sp, #0x60
    fbf0:      	str	x1, [x16, #0x8]
    fbf4:      	ldr	x1, [x0, #0x10]
    fbf8:      	add	x16, sp, #0x60
    fbfc:      	str	x1, [x16, #0x10]
    fc00:      	ldr	x0, [x0, #0x18]
    fc04:      	add	x16, sp, #0x60
    fc08:      	str	x0, [x16, #0x18]
    fc0c:      	add	x8, sp, #0x80
    fc10:      	mov	x0, x23
    fc14:      	mov	x1, x24
    fc18:      	mov	x2, x25
    fc1c:      	mov	x3, x22
    fc20:      	bl	0xfc20 <_coil.alloc.sized-resize+0x17c>
		000000000000fc20:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    fc24:      	add	x16, sp, #0x80
    fc28:      	ldr	w0, [x16]
    fc2c:      	lsr	x16, x0, #0
    fc30:      	cmp	x16, #0x1
    fc34:      	b.eq	0xfc50 <_coil.alloc.sized-resize+0x1ac>
    fc38:      	b.lo	0xfc40 <_coil.alloc.sized-resize+0x19c>
    fc3c:      	b	0xfc54 <_coil.alloc.sized-resize+0x1b0>
    fc40:      	cmp	x16, #0x0
    fc44:      	b.eq	0xfc4c <_coil.alloc.sized-resize+0x1a8>
    fc48:      	b	0xfc54 <_coil.alloc.sized-resize+0x1b0>
    fc4c:      	b	0xfc58 <_coil.alloc.sized-resize+0x1b4>
    fc50:      	b	0xfc70 <_coil.alloc.sized-resize+0x1cc>
    fc54:      	b	0xfd14 <_coil.alloc.sized-resize+0x270>
    fc58:      	movz	x0, #0x0, lsl #48
    fc5c:      	movz	x1, #0x0, lsl #48
    fc60:      	b	0xfc6c <_coil.alloc.sized-resize+0x1c8>
    fc64:      	movz	x0, #0x0, lsl #48
    fc68:      	movz	x1, #0x0, lsl #48
    fc6c:      	b	0xfbc8 <_coil.alloc.sized-resize+0x124>
    fc70:      	ubfx	x26, x26, #0, #8
    fc74:      	add	x16, sp, #0x60
    fc78:      	orr	x0, x16, xzr
    fc7c:      	add	x16, sp, #0x80
    fc80:      	orr	x1, x16, xzr
    fc84:      	add	x16, sp, #0xb0
    fc88:      	orr	x2, x16, xzr
    fc8c:      	add	x1, x1, #0x8
    fc90:      	add	x16, sp, #0x80
    fc94:      	ldr	x3, [x16, #0x8]
    fc98:      	add	x16, sp, #0xb0
    fc9c:      	str	x3, [x16]
    fca0:      	ldr	x3, [x1, #0x8]
    fca4:      	add	x16, sp, #0xb0
    fca8:      	str	x3, [x16, #0x8]
    fcac:      	ldr	x3, [x1, #0x10]
    fcb0:      	add	x16, sp, #0xb0
    fcb4:      	str	x3, [x16, #0x10]
    fcb8:      	ldr	x1, [x1, #0x18]
    fcbc:      	add	x16, sp, #0xb0
    fcc0:      	str	x1, [x16, #0x18]
    fcc4:      	cmp	x26, #0x0
    fcc8:      	b.eq	0xfcf4 <_coil.alloc.sized-resize+0x250>
    fccc:      	mov	x1, x21
    fcd0:      	mov	x3, x2
    fcd4:      	mov	x2, x0
    fcd8:      	mov	x0, x20
    fcdc:      	bl	0xfcdc <_coil.alloc.sized-resize+0x238>
		000000000000fcdc:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-resize
    fce0:      	cmp	x0, #0x0
    fce4:      	b.eq	0xfc64 <_coil.alloc.sized-resize+0x1c0>
    fce8:      	mov	x1, x21
    fcec:      	mov	x0, #0x1                ; =1
    fcf0:      	b	0xfc6c <_coil.alloc.sized-resize+0x1c8>
    fcf4:      	mov	x1, x21
    fcf8:      	mov	x3, x2
    fcfc:      	mov	x2, x0
    fd00:      	mov	x0, x20
    fd04:      	bl	0xfd04 <_coil.alloc.sized-resize+0x260>
		000000000000fd04:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-remap
    fd08:      	b	0xfc6c <_coil.alloc.sized-resize+0x1c8>
    fd0c:      	brk	#0
    fd10:      	b	0xfd0c <_coil.alloc.sized-resize+0x268>
    fd14:      	brk	#0
    fd18:      	b	0xfd14 <_coil.alloc.sized-resize+0x270>

000000000000fd1c <_coil.alloc.sized-alloc>:
    fd1c:      	sub	sp, sp, #0xa0
    fd20:      	str	x29, [sp, #0x10]
    fd24:      	str	x30, [sp, #0x18]
    fd28:      	add	x29, sp, #0x10
    fd2c:      	str	x19, [sp, #0x90]
    fd30:      	str	x20, [sp, #0x98]
    fd34:      	add	x19, sp, #0x20
    fd38:      	cmp	x4, #0x0
    fd3c:      	b.ne	0xfd70 <_coil.alloc.sized-alloc+0x54>
    fd40:      	mov	x0, #0x1                ; =1
    fd44:      	movz	x1, #0x0, lsl #48
    fd48:      	str	x0, [x19]
    fd4c:      	str	x1, [x19, #0x8]
    fd50:      	ldr	x0, [sp, #0x20]
    fd54:      	ldr	x1, [sp, #0x28]
    fd58:      	ldr	x19, [sp, #0x90]
    fd5c:      	ldr	x20, [sp, #0x98]
    fd60:      	ldr	x29, [sp, #0x10]
    fd64:      	ldr	x30, [sp, #0x18]
    fd68:      	add	sp, sp, #0xa0
    fd6c:      	ret
    fd70:      	add	x8, sp, #0x30
    fd74:      	mov	x20, x0
    fd78:      	mov	x0, x1
    fd7c:      	mov	x1, x2
    fd80:      	mov	x2, x3
    fd84:      	mov	x3, x4
    fd88:      	bl	0xfd88 <_coil.alloc.sized-alloc+0x6c>
		000000000000fd88:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    fd8c:      	add	x16, sp, #0x30
    fd90:      	ldr	w0, [x16]
    fd94:      	lsr	x16, x0, #0
    fd98:      	cmp	x16, #0x1
    fd9c:      	b.eq	0xfdb8 <_coil.alloc.sized-alloc+0x9c>
    fda0:      	b.lo	0xfda8 <_coil.alloc.sized-alloc+0x8c>
    fda4:      	b	0xfdbc <_coil.alloc.sized-alloc+0xa0>
    fda8:      	cmp	x16, #0x0
    fdac:      	b.eq	0xfdb4 <_coil.alloc.sized-alloc+0x98>
    fdb0:      	b	0xfdbc <_coil.alloc.sized-alloc+0xa0>
    fdb4:      	b	0xfdc0 <_coil.alloc.sized-alloc+0xa4>
    fdb8:      	b	0xfdcc <_coil.alloc.sized-alloc+0xb0>
    fdbc:      	b	0xfe20 <_coil.alloc.sized-alloc+0x104>
    fdc0:      	movz	x0, #0x0, lsl #48
    fdc4:      	movz	x1, #0x0, lsl #48
    fdc8:      	b	0xfe1c <_coil.alloc.sized-alloc+0x100>
    fdcc:      	add	x16, sp, #0x30
    fdd0:      	orr	x0, x16, xzr
    fdd4:      	add	x16, sp, #0x60
    fdd8:      	orr	x1, x16, xzr
    fddc:      	add	x0, x0, #0x8
    fde0:      	add	x16, sp, #0x30
    fde4:      	ldr	x2, [x16, #0x8]
    fde8:      	add	x16, sp, #0x60
    fdec:      	str	x2, [x16]
    fdf0:      	ldr	x2, [x0, #0x8]
    fdf4:      	add	x16, sp, #0x60
    fdf8:      	str	x2, [x16, #0x8]
    fdfc:      	ldr	x2, [x0, #0x10]
    fe00:      	add	x16, sp, #0x60
    fe04:      	str	x2, [x16, #0x10]
    fe08:      	ldr	x0, [x0, #0x18]
    fe0c:      	add	x16, sp, #0x60
    fe10:      	str	x0, [x16, #0x18]
    fe14:      	mov	x0, x20
    fe18:      	bl	0xfe18 <_coil.alloc.sized-alloc+0xfc>
		000000000000fe18:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-alloc
    fe1c:      	b	0xfd48 <_coil.alloc.sized-alloc+0x2c>
    fe20:      	brk	#0
    fe24:      	b	0xfe20 <_coil.alloc.sized-alloc+0x104>

000000000000fe28 <_coil.alloc.raw-resize>:
    fe28:      	sub	sp, sp, #0x10
    fe2c:      	str	x29, [sp]
    fe30:      	str	x30, [sp, #0x8]
    fe34:      	mov	x29, sp
    fe38:      	ldr	x4, [x2, #0x8]
    fe3c:      	cmp	x4, #0x0
    fe40:      	b.le	0xfebc <_coil.alloc.raw-resize+0x94>
    fe44:      	ldr	x4, [x2, #0x10]
    fe48:      	cmp	x4, #0x0
    fe4c:      	b.le	0xfebc <_coil.alloc.raw-resize+0x94>
    fe50:      	ldr	x4, [x2, #0x18]
    fe54:      	cmp	x4, #0x0
    fe58:      	b.le	0xfebc <_coil.alloc.raw-resize+0x94>
    fe5c:      	sub	x5, x4, #0x1
    fe60:      	and	x4, x5, x4
    fe64:      	cmp	x4, #0x0
    fe68:      	b.ne	0xfebc <_coil.alloc.raw-resize+0x94>
    fe6c:      	ldr	x4, [x3, #0x8]
    fe70:      	cmp	x4, #0x0
    fe74:      	b.le	0xfebc <_coil.alloc.raw-resize+0x94>
    fe78:      	ldr	x4, [x3, #0x10]
    fe7c:      	cmp	x4, #0x0
    fe80:      	b.le	0xfebc <_coil.alloc.raw-resize+0x94>
    fe84:      	ldr	x4, [x3, #0x18]
    fe88:      	cmp	x4, #0x0
    fe8c:      	b.le	0xfebc <_coil.alloc.raw-resize+0x94>
    fe90:      	sub	x5, x4, #0x1
    fe94:      	and	x4, x5, x4
    fe98:      	cmp	x4, #0x0
    fe9c:      	b.ne	0xfebc <_coil.alloc.raw-resize+0x94>
    fea0:      	ldr	x4, [x0]
    fea4:      	ldr	x0, [x0, #0x8]
    fea8:      	ldr	x0, [x0, #0x8]
    feac:      	mov	x30, x0
    feb0:      	mov	x0, x4
    feb4:      	blr	x30
    feb8:      	b	0xfec0 <_coil.alloc.raw-resize+0x98>
    febc:      	movz	x0, #0x0, lsl #48
    fec0:      	ldr	x29, [sp]
    fec4:      	ldr	x30, [sp, #0x8]
    fec8:      	add	sp, sp, #0x10
    fecc:      	ret

000000000000fed0 <_coil.alloc.raw-remap>:
    fed0:      	sub	sp, sp, #0x50
    fed4:      	str	x29, [sp, #0x10]
    fed8:      	str	x30, [sp, #0x18]
    fedc:      	add	x29, sp, #0x10
    fee0:      	str	x19, [sp, #0x40]
    fee4:      	add	x19, sp, #0x20
    fee8:      	ldr	x4, [x2, #0x8]
    feec:      	cmp	x4, #0x0
    fef0:      	b.le	0xff6c <_coil.alloc.raw-remap+0x9c>
    fef4:      	ldr	x4, [x2, #0x10]
    fef8:      	cmp	x4, #0x0
    fefc:      	b.le	0xff6c <_coil.alloc.raw-remap+0x9c>
    ff00:      	ldr	x4, [x2, #0x18]
    ff04:      	cmp	x4, #0x0
    ff08:      	b.le	0xff6c <_coil.alloc.raw-remap+0x9c>
    ff0c:      	sub	x5, x4, #0x1
    ff10:      	and	x4, x5, x4
    ff14:      	cmp	x4, #0x0
    ff18:      	b.ne	0xff6c <_coil.alloc.raw-remap+0x9c>
    ff1c:      	ldr	x4, [x3, #0x8]
    ff20:      	cmp	x4, #0x0
    ff24:      	b.le	0xff6c <_coil.alloc.raw-remap+0x9c>
    ff28:      	ldr	x4, [x3, #0x10]
    ff2c:      	cmp	x4, #0x0
    ff30:      	b.le	0xff6c <_coil.alloc.raw-remap+0x9c>
    ff34:      	ldr	x4, [x3, #0x18]
    ff38:      	cmp	x4, #0x0
    ff3c:      	b.le	0xff6c <_coil.alloc.raw-remap+0x9c>
    ff40:      	sub	x5, x4, #0x1
    ff44:      	and	x4, x5, x4
    ff48:      	cmp	x4, #0x0
    ff4c:      	b.ne	0xff6c <_coil.alloc.raw-remap+0x9c>
    ff50:      	ldr	x4, [x0]
    ff54:      	ldr	x0, [x0, #0x8]
    ff58:      	ldr	x0, [x0, #0x10]
    ff5c:      	mov	x30, x0
    ff60:      	mov	x0, x4
    ff64:      	blr	x30
    ff68:      	b	0xff74 <_coil.alloc.raw-remap+0xa4>
    ff6c:      	movz	x0, #0x0, lsl #48
    ff70:      	movz	x1, #0x0, lsl #48
    ff74:      	str	x0, [x19]
    ff78:      	str	x1, [x19, #0x8]
    ff7c:      	ldr	x0, [sp, #0x20]
    ff80:      	ldr	x1, [sp, #0x28]
    ff84:      	ldr	x19, [sp, #0x40]
    ff88:      	ldr	x29, [sp, #0x10]
    ff8c:      	ldr	x30, [sp, #0x18]
    ff90:      	add	sp, sp, #0x50
    ff94:      	ret

000000000000ff98 <_coil.alloc.raw-alloc>:
    ff98:      	sub	sp, sp, #0x50
    ff9c:      	str	x29, [sp, #0x10]
    ffa0:      	str	x30, [sp, #0x18]
    ffa4:      	add	x29, sp, #0x10
    ffa8:      	str	x19, [sp, #0x40]
    ffac:      	add	x19, sp, #0x20
    ffb0:      	ldr	x2, [x1, #0x8]
    ffb4:      	cmp	x2, #0x0
    ffb8:      	b.le	0x10000 <_coil.alloc.raw-alloc+0x68>
    ffbc:      	ldr	x2, [x1, #0x10]
    ffc0:      	cmp	x2, #0x0
    ffc4:      	b.le	0x10000 <_coil.alloc.raw-alloc+0x68>
    ffc8:      	ldr	x2, [x1, #0x18]
    ffcc:      	cmp	x2, #0x0
    ffd0:      	b.le	0x10000 <_coil.alloc.raw-alloc+0x68>
    ffd4:      	sub	x3, x2, #0x1
    ffd8:      	and	x2, x3, x2
    ffdc:      	cmp	x2, #0x0
    ffe0:      	b.ne	0x10000 <_coil.alloc.raw-alloc+0x68>
    ffe4:      	ldr	x2, [x0]
    ffe8:      	ldr	x0, [x0, #0x8]
    ffec:      	ldr	x0, [x0]
    fff0:      	mov	x30, x0
    fff4:      	mov	x0, x2
    fff8:      	blr	x30
    fffc:      	b	0x10008 <_coil.alloc.raw-alloc+0x70>
   10000:      	movz	x0, #0x0, lsl #48
   10004:      	movz	x1, #0x0, lsl #48
   10008:      	str	x0, [x19]
   1000c:      	str	x1, [x19, #0x8]
   10010:      	ldr	x0, [sp, #0x20]
   10014:      	ldr	x1, [sp, #0x28]
   10018:      	ldr	x19, [sp, #0x40]
   1001c:      	ldr	x29, [sp, #0x10]
   10020:      	ldr	x30, [sp, #0x18]
   10024:      	add	sp, sp, #0x50
   10028:      	ret
