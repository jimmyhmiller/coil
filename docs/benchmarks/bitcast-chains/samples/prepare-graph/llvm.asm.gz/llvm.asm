
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-bitcast-chains/build/bitcast-comparison/prepare-graph/llvm.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x20
       4:      	stp	x29, x30, [sp, #0x10]
       8:      	add	x29, sp, #0x10
       c:      	mov	x8, x1
      10:      	ldr	x1, [x1, #0x18]
      14:      	ldr	x2, [x8, #0x10]
      18:      	cmp	x1, #0x10
      1c:      	b.gt	0x40 <ltmp0+0x40>
      20:      	mov	x0, x2
      24:      	bl	0x24 <ltmp0+0x24>
		0000000000000024:  ARM64_RELOC_BRANCH26	_malloc
      28:      	cmp	x0, #0x0
      2c:      	csel	x1, x8, x0, eq
      30:      	cset	x0, ne
      34:      	ldp	x29, x30, [sp, #0x10]
      38:      	add	sp, sp, #0x20
      3c:      	ret
      40:      	add	x0, sp, #0x8
      44:      	str	xzr, [sp, #0x8]
      48:      	bl	0x48 <ltmp0+0x48>
		0000000000000048:  ARM64_RELOC_BRANCH26	_posix_memalign
      4c:      	cbz	w0, 0x60 <ltmp0+0x60>
      50:      	mov	x0, xzr
      54:      	ldp	x29, x30, [sp, #0x10]
      58:      	add	sp, sp, #0x20
      5c:      	ret
      60:      	ldr	x1, [sp, #0x8]
      64:      	mov	w0, #0x1                ; =1
      68:      	ldp	x29, x30, [sp, #0x10]
      6c:      	add	sp, sp, #0x20
      70:      	ret

0000000000000074 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate>:
      74:      	stp	x29, x30, [sp, #-0x10]!
      78:      	mov	x0, x1
      7c:      	mov	x29, sp
      80:      	bl	0x80 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate+0xc>
		0000000000000080:  ARM64_RELOC_BRANCH26	_free
      84:      	mov	x0, xzr
      88:      	ldp	x29, x30, [sp], #0x10
      8c:      	ret

0000000000000090 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap>:
      90:      	ldr	x8, [x3, #0x18]
      94:      	cmp	x8, #0x11
      98:      	b.lt	0xa4 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x14>
      9c:      	mov	x0, xzr
      a0:      	ret
      a4:      	stp	x29, x30, [sp, #-0x10]!
      a8:      	ldr	x8, [x3, #0x10]
      ac:      	mov	x0, x1
      b0:      	mov	x29, sp
      b4:      	mov	x1, x8
      b8:      	bl	0xb8 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x28>
		00000000000000b8:  ARM64_RELOC_BRANCH26	_realloc
      bc:      	cmp	x0, #0x0
      c0:      	csel	x1, x8, x0, eq
      c4:      	cset	x0, ne
      c8:      	ldp	x29, x30, [sp], #0x10
      cc:      	ret

00000000000000d0 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$resize>:
      d0:      	ldr	x8, [x3, #0x10]
      d4:      	ldr	x9, [x2, #0x10]
      d8:      	cmp	x8, x9
      dc:      	cset	w0, le
      e0:      	ret

00000000000000e4 <_coil.alloc.oom-at>:
      e4:      	stp	x20, x19, [sp, #-0x20]!
      e8:      	stp	x29, x30, [sp, #0x10]
      ec:      	add	x29, sp, #0x10
      f0:      	mov	x19, x1
      f4:      	mov	x20, x0
      f8:      	adrp	x1, 0x0 <ltmp0>
		00000000000000f8:  ARM64_RELOC_PAGE21	l_cstr.59
      fc:      	add	x1, x1, #0x0
		00000000000000fc:  ARM64_RELOC_PAGEOFF12	l_cstr.59
     100:      	mov	w0, #0x2                ; =2
     104:      	mov	w2, #0xf                ; =15
     108:      	bl	0x108 <_coil.alloc.oom-at+0x24>
		0000000000000108:  ARM64_RELOC_BRANCH26	_write
     10c:      	mov	x0, x20
     110:      	bl	0x110 <_coil.alloc.oom-at+0x2c>
		0000000000000110:  ARM64_RELOC_BRANCH26	_strlen
     114:      	mov	x2, x0
     118:      	mov	w0, #0x2                ; =2
     11c:      	mov	x1, x20
     120:      	bl	0x120 <_coil.alloc.oom-at+0x3c>
		0000000000000120:  ARM64_RELOC_BRANCH26	_write
     124:      	adrp	x1, 0x0 <ltmp0>
		0000000000000124:  ARM64_RELOC_PAGE21	l_cstr.60
     128:      	add	x1, x1, #0x0
		0000000000000128:  ARM64_RELOC_PAGEOFF12	l_cstr.60
     12c:      	mov	w0, #0x2                ; =2
     130:      	mov	w2, #0x13               ; =19
     134:      	bl	0x134 <_coil.alloc.oom-at+0x50>
		0000000000000134:  ARM64_RELOC_BRANCH26	_write
     138:      	tbnz	x19, #0x3f, 0x1b8 <_coil.alloc.oom-at+0xd4>
     13c:      	adrp	x1, 0x0 <ltmp0>
		000000000000013c:  ARM64_RELOC_PAGE21	l_cstr.61
     140:      	add	x1, x1, #0x0
		0000000000000140:  ARM64_RELOC_PAGEOFF12	l_cstr.61
     144:      	mov	w0, #0x2                ; =2
     148:      	mov	w2, #0x1                ; =1
     14c:      	bl	0x14c <_coil.alloc.oom-at+0x68>
		000000000000014c:  ARM64_RELOC_BRANCH26	_write
     150:      	mov	x10, #-0x3333333333333334 ; =-3689348814741910324
     154:      	mov	x8, xzr
     158:      	adrp	x9, 0x0 <ltmp0>
		0000000000000158:  ARM64_RELOC_PAGE21	_repl_static.coil.alloc.oom-putd.0
     15c:      	add	x9, x9, #0x0
		000000000000015c:  ARM64_RELOC_PAGEOFF12	_repl_static.coil.alloc.oom-putd.0
     160:      	movk	x10, #0xcccd
     164:      	mov	w11, #0xa               ; =10
     168:      	umulh	x12, x19, x10
     16c:      	add	x14, x9, x8
     170:      	cmp	x19, #0x9
     174:      	sub	x8, x8, #0x1
     178:      	lsr	x12, x12, #3
     17c:      	msub	w13, w12, w11, w19
     180:      	mov	x19, x12
     184:      	orr	w13, w13, #0x30
     188:      	strb	w13, [x14, #0x17]
     18c:      	b.hi	0x168 <_coil.alloc.oom-at+0x84>
     190:      	neg	x2, x8
     194:      	add	x8, x9, x8
     198:      	mov	w0, #0x2                ; =2
     19c:      	add	x1, x8, #0x18
     1a0:      	bl	0x1a0 <_coil.alloc.oom-at+0xbc>
		00000000000001a0:  ARM64_RELOC_BRANCH26	_write
     1a4:      	adrp	x1, 0x0 <ltmp0>
		00000000000001a4:  ARM64_RELOC_PAGE21	l_cstr.62
     1a8:      	add	x1, x1, #0x0
		00000000000001a8:  ARM64_RELOC_PAGEOFF12	l_cstr.62
     1ac:      	mov	w0, #0x2                ; =2
     1b0:      	mov	w2, #0x6                ; =6
     1b4:      	bl	0x1b4 <_coil.alloc.oom-at+0xd0>
		00000000000001b4:  ARM64_RELOC_BRANCH26	_write
     1b8:      	adrp	x0, 0x0 <ltmp0>
		00000000000001b8:  ARM64_RELOC_PAGE21	l_cstr.63
     1bc:      	add	x0, x0, #0x0
		00000000000001bc:  ARM64_RELOC_PAGEOFF12	l_cstr.63
     1c0:      	bl	0x1c0 <_coil.alloc.oom-at+0xdc>
		00000000000001c0:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-puts
     1c4:      	bl	0x1c4 <_coil.alloc.oom-at+0xe0>
		00000000000001c4:  ARM64_RELOC_BRANCH26	_abort

00000000000001c8 <_coil.alloc.oom-puts>:
     1c8:      	stp	x20, x19, [sp, #-0x20]!
     1cc:      	stp	x29, x30, [sp, #0x10]
     1d0:      	add	x29, sp, #0x10
     1d4:      	mov	x19, x0
     1d8:      	bl	0x1d8 <_coil.alloc.oom-puts+0x10>
		00000000000001d8:  ARM64_RELOC_BRANCH26	_strlen
     1dc:      	ldp	x29, x30, [sp, #0x10]
     1e0:      	mov	x2, x0
     1e4:      	mov	w0, #0x2                ; =2
     1e8:      	mov	x1, x19
     1ec:      	ldp	x20, x19, [sp], #0x20
     1f0:      	b	0x1f0 <_coil.alloc.oom-puts+0x28>
		00000000000001f0:  ARM64_RELOC_BRANCH26	_write

00000000000001f4 <_coil.alloc.sized-alloc>:
     1f4:      	cbz	x4, 0x278 <_coil.alloc.sized-alloc+0x84>
     1f8:      	sub	sp, sp, #0x70
     1fc:      	stp	x20, x19, [sp, #0x50]
     200:      	stp	x29, x30, [sp, #0x60]
     204:      	add	x29, sp, #0x60
     208:      	mov	x19, x0
     20c:      	add	x0, sp, #0x8
     210:      	bl	0x210 <_coil.alloc.sized-alloc+0x1c>
		0000000000000210:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
     214:      	ldr	w8, [sp, #0x8]
     218:      	cbz	w8, 0x284 <_coil.alloc.sized-alloc+0x90>
     21c:      	ldp	q0, q1, [sp, #0x10]
     220:      	mov	x0, xzr
     224:      	stp	q0, q1, [sp, #0x30]
     228:      	ldr	x8, [sp, #0x38]
     22c:      	cmp	x8, #0x1
     230:      	b.lt	0x288 <_coil.alloc.sized-alloc+0x94>
     234:      	ldr	x8, [sp, #0x40]
     238:      	cmp	x8, #0x1
     23c:      	b.lt	0x268 <_coil.alloc.sized-alloc+0x74>
     240:      	ldr	x8, [sp, #0x48]
     244:      	mov	x0, xzr
     248:      	subs	x9, x8, #0x1
     24c:      	b.lt	0x288 <_coil.alloc.sized-alloc+0x94>
     250:      	and	x8, x8, x9
     254:      	cbnz	x8, 0x268 <_coil.alloc.sized-alloc+0x74>
     258:      	ldp	x0, x8, [x19]
     25c:      	add	x1, sp, #0x30
     260:      	ldr	x8, [x8]
     264:      	blr	x8
     268:      	ldp	x29, x30, [sp, #0x60]
     26c:      	ldp	x20, x19, [sp, #0x50]
     270:      	add	sp, sp, #0x70
     274:      	ret
     278:      	mov	x1, xzr
     27c:      	mov	w0, #0x1                ; =1
     280:      	ret
     284:      	mov	x0, xzr
     288:      	ldp	x29, x30, [sp, #0x60]
     28c:      	ldp	x20, x19, [sp, #0x50]
     290:      	add	sp, sp, #0x70
     294:      	ret

0000000000000298 <_coil.alloc.sized-free>:
     298:      	cbz	x2, 0x32c <_coil.alloc.sized-free+0x94>
     29c:      	sub	sp, sp, #0x70
     2a0:      	stp	x20, x19, [sp, #0x50]
     2a4:      	stp	x29, x30, [sp, #0x60]
     2a8:      	add	x29, sp, #0x60
     2ac:      	mov	x8, x2
     2b0:      	mov	x19, x1
     2b4:      	mov	x20, x0
     2b8:      	add	x0, sp, #0x8
     2bc:      	mov	x1, x3
     2c0:      	mov	x2, x4
     2c4:      	mov	x3, x5
     2c8:      	mov	x4, x8
     2cc:      	bl	0x2cc <_coil.alloc.sized-free+0x34>
		00000000000002cc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
     2d0:      	ldr	w8, [sp, #0x8]
     2d4:      	cbz	w8, 0x320 <_coil.alloc.sized-free+0x88>
     2d8:      	ldp	q0, q1, [sp, #0x10]
     2dc:      	stp	q0, q1, [sp, #0x30]
     2e0:      	ldr	x8, [sp, #0x38]
     2e4:      	cmp	x8, #0x1
     2e8:      	b.lt	0x320 <_coil.alloc.sized-free+0x88>
     2ec:      	ldr	x8, [sp, #0x40]
     2f0:      	cmp	x8, #0x1
     2f4:      	b.lt	0x320 <_coil.alloc.sized-free+0x88>
     2f8:      	ldr	x8, [sp, #0x48]
     2fc:      	subs	x9, x8, #0x1
     300:      	b.lt	0x320 <_coil.alloc.sized-free+0x88>
     304:      	and	x8, x8, x9
     308:      	cbnz	x8, 0x320 <_coil.alloc.sized-free+0x88>
     30c:      	ldp	x0, x8, [x20]
     310:      	add	x2, sp, #0x30
     314:      	mov	x1, x19
     318:      	ldr	x8, [x8, #0x18]
     31c:      	blr	x8
     320:      	ldp	x29, x30, [sp, #0x60]
     324:      	ldp	x20, x19, [sp, #0x50]
     328:      	add	sp, sp, #0x70
     32c:      	ret

0000000000000330 <_coil.alloc.sized-reallocate>:
     330:      	stp	x26, x25, [sp, #-0x50]!
     334:      	stp	x24, x23, [sp, #0x10]
     338:      	stp	x22, x21, [sp, #0x20]
     33c:      	stp	x20, x19, [sp, #0x30]
     340:      	stp	x29, x30, [sp, #0x40]
     344:      	add	x29, sp, #0x40
     348:      	mov	x19, x6
     34c:      	mov	x20, x5
     350:      	mov	x21, x4
     354:      	mov	x25, x3
     358:      	mov	x22, x2
     35c:      	mov	x23, x1
     360:      	mov	x24, x0
     364:      	bl	0x364 <_coil.alloc.sized-reallocate+0x34>
		0000000000000364:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-resize
     368:      	cmp	w0, #0x1
     36c:      	b.eq	0x3c8 <_coil.alloc.sized-reallocate+0x98>
     370:      	mov	x0, x24
     374:      	mov	x1, x21
     378:      	mov	x2, x20
     37c:      	mov	x3, x19
     380:      	mov	x4, x25
     384:      	bl	0x384 <_coil.alloc.sized-reallocate+0x54>
		0000000000000384:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
     388:      	cbz	w0, 0x3e4 <_coil.alloc.sized-reallocate+0xb4>
     38c:      	cmp	x22, x25
     390:      	mov	x0, x1
     394:      	csel	x8, x22, x25, lt
     398:      	mov	x25, x1
     39c:      	mov	x1, x23
     3a0:      	mul	x2, x20, x8
     3a4:      	bl	0x3a4 <_coil.alloc.sized-reallocate+0x74>
		00000000000003a4:  ARM64_RELOC_BRANCH26	_memcpy
     3a8:      	mov	x0, x24
     3ac:      	mov	x1, x23
     3b0:      	mov	x2, x22
     3b4:      	mov	x3, x21
     3b8:      	mov	x4, x20
     3bc:      	mov	x5, x19
     3c0:      	bl	0x3c0 <_coil.alloc.sized-reallocate+0x90>
		00000000000003c0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     3c4:      	mov	x1, x25
     3c8:      	mov	w0, #0x1                ; =1
     3cc:      	ldp	x29, x30, [sp, #0x40]
     3d0:      	ldp	x20, x19, [sp, #0x30]
     3d4:      	ldp	x22, x21, [sp, #0x20]
     3d8:      	ldp	x24, x23, [sp, #0x10]
     3dc:      	ldp	x26, x25, [sp], #0x50
     3e0:      	ret
     3e4:      	mov	x0, xzr
     3e8:      	ldp	x29, x30, [sp, #0x40]
     3ec:      	ldp	x20, x19, [sp, #0x30]
     3f0:      	ldp	x22, x21, [sp, #0x20]
     3f4:      	ldp	x24, x23, [sp, #0x10]
     3f8:      	ldp	x26, x25, [sp], #0x50
     3fc:      	ret

0000000000000400 <_coil.alloc.sized-request>:
     400:      	cmp	x4, #0x1
     404:      	b.lt	0x418 <_coil.alloc.sized-request+0x18>
     408:      	mov	x8, #0x7fffffffffffffff ; =9223372036854775807
     40c:      	udiv	x8, x8, x2
     410:      	cmp	x4, x8
     414:      	b.ls	0x420 <_coil.alloc.sized-request+0x20>
     418:      	str	wzr, [x0]
     41c:      	ret
     420:      	mul	x8, x4, x2
     424:      	mov	w9, #0x1                ; =1
     428:      	stp	x1, x4, [x0, #0x8]
     42c:      	str	w9, [x0]
     430:      	stp	x8, x3, [x0, #0x18]
     434:      	ret

0000000000000438 <_coil.alloc.sized-resize>:
     438:      	sub	sp, sp, #0xe0
     43c:      	stp	x26, x25, [sp, #0x90]
     440:      	stp	x24, x23, [sp, #0xa0]
     444:      	stp	x22, x21, [sp, #0xb0]
     448:      	stp	x20, x19, [sp, #0xc0]
     44c:      	stp	x29, x30, [sp, #0xd0]
     450:      	add	x29, sp, #0xd0
     454:      	cbz	x3, 0x544 <_coil.alloc.sized-resize+0x10c>
     458:      	mov	x19, x3
     45c:      	cbz	x2, 0x584 <_coil.alloc.sized-resize+0x14c>
     460:      	mov	x23, x0
     464:      	mov	x24, x1
     468:      	mov	x0, sp
     46c:      	mov	x22, x4
     470:      	mov	x1, x4
     474:      	mov	x4, x2
     478:      	mov	x2, x5
     47c:      	mov	x3, x6
     480:      	mov	x21, x5
     484:      	mov	x20, x6
     488:      	mov	x25, sp
     48c:      	bl	0x48c <_coil.alloc.sized-resize+0x54>
		000000000000048c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
     490:      	ldr	w8, [sp]
     494:      	cbz	w8, 0x560 <_coil.alloc.sized-resize+0x128>
     498:      	add	x0, sp, #0x28
     49c:      	mov	x1, x22
     4a0:      	mov	x2, x21
     4a4:      	mov	x3, x20
     4a8:      	mov	x4, x19
     4ac:      	bl	0x4ac <_coil.alloc.sized-resize+0x74>
		00000000000004ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
     4b0:      	ldr	w8, [sp, #0x28]
     4b4:      	cbz	w8, 0x560 <_coil.alloc.sized-resize+0x128>
     4b8:      	ldur	q0, [x25, #0x8]
     4bc:      	ldur	q1, [x25, #0x18]
     4c0:      	mov	x0, xzr
     4c4:      	stp	q0, q1, [sp, #0x50]
     4c8:      	ldp	q0, q1, [sp, #0x30]
     4cc:      	ldr	x8, [sp, #0x58]
     4d0:      	cmp	x8, #0x1
     4d4:      	stp	q0, q1, [x29, #-0x60]
     4d8:      	b.lt	0x564 <_coil.alloc.sized-resize+0x12c>
     4dc:      	ldr	x8, [sp, #0x60]
     4e0:      	cmp	x8, #0x1
     4e4:      	b.lt	0x564 <_coil.alloc.sized-resize+0x12c>
     4e8:      	ldr	x8, [sp, #0x68]
     4ec:      	ldp	x11, x9, [x29, #-0x58]
     4f0:      	sub	x10, x8, #0x1
     4f4:      	and	x10, x8, x10
     4f8:      	cmp	x9, #0x0
     4fc:      	ccmp	x10, #0x0, #0x0, gt
     500:      	ccmp	x11, #0x0, #0x4, eq
     504:      	ccmp	x8, #0x0, #0x4, gt
     508:      	b.le	0x560 <_coil.alloc.sized-resize+0x128>
     50c:      	ldur	x8, [x29, #-0x48]
     510:      	mov	x0, xzr
     514:      	subs	x9, x8, #0x1
     518:      	b.lt	0x564 <_coil.alloc.sized-resize+0x12c>
     51c:      	and	x8, x8, x9
     520:      	cbnz	x8, 0x564 <_coil.alloc.sized-resize+0x12c>
     524:      	ldp	x0, x8, [x23]
     528:      	mov	x1, x24
     52c:      	add	x2, sp, #0x50
     530:      	sub	x3, x29, #0x60
     534:      	ldr	x8, [x8, #0x10]
     538:      	blr	x8
     53c:      	mov	x2, x1
     540:      	b	0x564 <_coil.alloc.sized-resize+0x12c>
     544:      	mov	x3, x4
     548:      	mov	x4, x5
     54c:      	mov	x5, x6
     550:      	bl	0x550 <_coil.alloc.sized-resize+0x118>
		0000000000000550:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     554:      	mov	x2, xzr
     558:      	mov	w0, #0x1                ; =1
     55c:      	b	0x564 <_coil.alloc.sized-resize+0x12c>
     560:      	mov	x0, xzr
     564:      	ldp	x29, x30, [sp, #0xd0]
     568:      	mov	x1, x2
     56c:      	ldp	x20, x19, [sp, #0xc0]
     570:      	ldp	x22, x21, [sp, #0xb0]
     574:      	ldp	x24, x23, [sp, #0xa0]
     578:      	ldp	x26, x25, [sp, #0x90]
     57c:      	add	sp, sp, #0xe0
     580:      	ret
     584:      	mov	x1, x4
     588:      	mov	x4, x19
     58c:      	mov	x2, x5
     590:      	ldp	x29, x30, [sp, #0xd0]
     594:      	mov	x3, x6
     598:      	ldp	x20, x19, [sp, #0xc0]
     59c:      	ldp	x22, x21, [sp, #0xb0]
     5a0:      	ldp	x24, x23, [sp, #0xa0]
     5a4:      	ldp	x26, x25, [sp, #0x90]
     5a8:      	add	sp, sp, #0xe0
     5ac:      	b	0x5ac <_coil.alloc.sized-resize+0x174>
		00000000000005ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc

00000000000005b0 <_coil.hashmap.bytewise-eq>:
     5b0:      	cbz	x2, 0x5d0 <_coil.hashmap.bytewise-eq+0x20>
     5b4:      	stp	x29, x30, [sp, #-0x10]!
     5b8:      	mov	x29, sp
     5bc:      	bl	0x5bc <_coil.hashmap.bytewise-eq+0xc>
		00000000000005bc:  ARM64_RELOC_BRANCH26	_memcmp
     5c0:      	cmp	w0, #0x0
     5c4:      	cset	w0, eq
     5c8:      	ldp	x29, x30, [sp], #0x10
     5cc:      	ret
     5d0:      	mov	w0, #0x1                ; =1
     5d4:      	ret

00000000000005d8 <_coil.hashmap.bytewise-hash>:
     5d8:      	mov	x8, x0
     5dc:      	mov	x0, #0x2325             ; =8997
     5e0:      	cmp	x1, #0x1
     5e4:      	movk	x0, #0x8422, lsl #16
     5e8:      	movk	x0, #0x9ce4, lsl #32
     5ec:      	movk	x0, #0xcbf2, lsl #48
     5f0:      	b.lt	0x610 <_coil.hashmap.bytewise-hash+0x38>
     5f4:      	mov	x9, #0x1b3              ; =435
     5f8:      	movk	x9, #0x100, lsl #32
     5fc:      	ldrsb	x10, [x8], #0x1
     600:      	subs	x1, x1, #0x1
     604:      	eor	x10, x0, x10
     608:      	mul	x0, x10, x9
     60c:      	b.ne	0x5fc <_coil.hashmap.bytewise-hash+0x24>
     610:      	ret

0000000000000614 <_gap_prepare_graph>:
     614:      	stp	x28, x27, [sp, #-0x60]!
     618:      	stp	x26, x25, [sp, #0x10]
     61c:      	stp	x24, x23, [sp, #0x20]
     620:      	stp	x22, x21, [sp, #0x30]
     624:      	stp	x20, x19, [sp, #0x40]
     628:      	stp	x29, x30, [sp, #0x50]
     62c:      	add	x29, sp, #0x50
     630:      	sub	sp, sp, #0x2c0
     634:      	mov	x20, x0
     638:      	mov	w19, w1
     63c:      	adrp	x8, 0x0 <ltmp0>
		000000000000063c:  ARM64_RELOC_PAGE21	_repl_static.coil.alloc.malloc-allocator.0
     640:      	add	x8, x8, #0x0
		0000000000000640:  ARM64_RELOC_PAGEOFF12	_repl_static.coil.alloc.malloc-allocator.0
     644:      	adrp	x9, 0x0 <ltmp0>
		0000000000000644:  ARM64_RELOC_PAGE21	l_vtable.coil.alloc.Allocator-dyn.3
     648:      	add	x9, x9, #0x0
		0000000000000648:  ARM64_RELOC_PAGEOFF12	l_vtable.coil.alloc.Allocator-dyn.3
     64c:      	sub	x0, x29, #0x70
     650:      	mov	x1, x20
     654:      	mov	w21, w2
     658:      	str	w2, [sp, #0x4]
     65c:      	stp	x8, x9, [sp, #0x8]
     660:      	bl	0x660 <_gap_prepare_graph+0x4c>
		0000000000000660:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
     664:      	ldur	w8, [x29, #-0x70]
     668:      	cmp	w8, #0x1
     66c:      	b.eq	0xa18 <_gap_prepare_graph+0x404>
     670:      	cmp	w19, #0x1
     674:      	b.lt	0x6c8 <_gap_prepare_graph+0xb4>
     678:      	ldr	x9, [x20, #0x8]
     67c:      	mov	w8, w19
     680:      	cmp	x9, x8
     684:      	b.le	0x6c8 <_gap_prepare_graph+0xb4>
     688:      	ldr	x9, [x20, #0x80]
     68c:      	cmp	x9, x8
     690:      	b.le	0x6c8 <_gap_prepare_graph+0xb4>
     694:      	ldr	x9, [x20, #0x78]
     698:      	ldr	w9, [x9, x8, lsl #2]
     69c:      	tbnz	w9, #0x1f, 0x6c8 <_gap_prepare_graph+0xb4>
     6a0:      	ldr	x9, [x20]
     6a4:      	lsl	x8, x8, #4
     6a8:      	ldr	w8, [x9, x8]
     6ac:      	and	w8, w8, #0xfe
     6b0:      	sub	w8, w8, #0x68
     6b4:      	cmp	w8, #0xa
     6b8:      	cset	w8, lo
     6bc:      	cmp	w21, #0x1
     6c0:      	b.ge	0x6d4 <_gap_prepare_graph+0xc0>
     6c4:      	b	0xa18 <_gap_prepare_graph+0x404>
     6c8:      	mov	w8, wzr
     6cc:      	cmp	w21, #0x1
     6d0:      	b.lt	0xa18 <_gap_prepare_graph+0x404>
     6d4:      	ldr	x10, [x20, #0x8]
     6d8:      	mov	w9, w21
     6dc:      	cmp	x10, x9
     6e0:      	b.le	0xa18 <_gap_prepare_graph+0x404>
     6e4:      	ldr	x10, [x20, #0x80]
     6e8:      	cmp	x10, x9
     6ec:      	b.le	0xa18 <_gap_prepare_graph+0x404>
     6f0:      	ldr	x10, [x20, #0x78]
     6f4:      	ldr	w9, [x10, x9, lsl #2]
     6f8:      	cmn	w9, #0x1
     6fc:      	cset	w9, gt
     700:      	tst	w9, w8
     704:      	b.eq	0xa18 <_gap_prepare_graph+0x404>
     708:      	ldr	x8, [x20, #0x8]
     70c:      	add	x21, sp, #0x160
     710:      	adrp	x7, 0x0 <ltmp0>
		0000000000000710:  ARM64_RELOC_PAGE21	l_str.839
     714:      	add	x7, x7, #0x0
		0000000000000714:  ARM64_RELOC_PAGEOFF12	l_str.839
     718:      	adrp	x9, 0x0 <ltmp0>
		0000000000000718:  ARM64_RELOC_PAGE21	l_str.841
     71c:      	add	x9, x9, #0x0
		000000000000071c:  ARM64_RELOC_PAGEOFF12	l_str.841
     720:      	mov	w10, #0x1               ; =1
     724:      	adrp	x11, 0x0 <ltmp0>
		0000000000000724:  ARM64_RELOC_PAGE21	l_str.846
     728:      	add	x11, x11, #0x0
		0000000000000728:  ARM64_RELOC_PAGEOFF12	l_str.846
     72c:      	mov	w12, #0x2b              ; =43
     730:      	adrp	x13, 0x0 <ltmp0>
		0000000000000730:  ARM64_RELOC_PAGE21	l_str.850
     734:      	add	x13, x13, #0x0
		0000000000000734:  ARM64_RELOC_PAGEOFF12	l_str.850
     738:      	mov	w14, #0xff              ; =255
     73c:      	adrp	x15, 0x0 <ltmp0>
		000000000000073c:  ARM64_RELOC_PAGE21	l_str.842
     740:      	add	x15, x15, #0x0
		0000000000000740:  ARM64_RELOC_PAGEOFF12	l_str.842
     744:      	mov	w16, #0x19              ; =25
     748:      	adrp	x17, 0x0 <ltmp0>
		0000000000000748:  ARM64_RELOC_PAGE21	l_str.843
     74c:      	add	x17, x17, #0x0
		000000000000074c:  ARM64_RELOC_PAGEOFF12	l_str.843
     750:      	mov	w0, #0x12               ; =18
     754:      	adrp	x1, 0x0 <ltmp0>
		0000000000000754:  ARM64_RELOC_PAGE21	l_str.844
     758:      	add	x1, x1, #0x0
		0000000000000758:  ARM64_RELOC_PAGEOFF12	l_str.844
     75c:      	mov	w2, #0x26               ; =38
     760:      	adrp	x3, 0x0 <ltmp0>
		0000000000000760:  ARM64_RELOC_PAGE21	l_str.845
     764:      	add	x3, x3, #0x0
		0000000000000764:  ARM64_RELOC_PAGEOFF12	l_str.845
     768:      	cmp	x10, x8
     76c:      	b.ge	0x9ec <_gap_prepare_graph+0x3d8>
     770:      	ldr	x5, [x20]
     774:      	lsl	x4, x10, #4
     778:      	ldr	x6, [x20, #0x78]
     77c:      	ldr	x22, [x5, x4]
     780:      	ldrsw	x4, [x6, x10, lsl #2]
     784:      	and	x23, x22, #0xff
     788:      	cmp	x23, #0x43
     78c:      	b.ne	0x9b0 <_gap_prepare_graph+0x39c>
     790:      	cmp	w4, #0x3
     794:      	b.ge	0x7a4 <_gap_prepare_graph+0x190>
     798:      	mov	w23, #0x2b              ; =43
     79c:      	mov	x7, x9
     7a0:      	b	0x86c <_gap_prepare_graph+0x258>
     7a4:      	cmp	w10, #0x1
     7a8:      	b.lt	0x7e0 <_gap_prepare_graph+0x1cc>
     7ac:      	and	x23, x10, #0x7fffffff
     7b0:      	cmp	x8, x23
     7b4:      	b.le	0x7e0 <_gap_prepare_graph+0x1cc>
     7b8:      	ldr	x24, [x20, #0x80]
     7bc:      	cmp	x24, x23
     7c0:      	b.le	0x7e0 <_gap_prepare_graph+0x1cc>
     7c4:      	ldr	w24, [x6, x23, lsl #2]
     7c8:      	cmp	w24, #0x1
     7cc:      	b.lt	0x7e0 <_gap_prepare_graph+0x1cc>
     7d0:      	add	x23, x5, x23, lsl #4
     7d4:      	mov	w24, #0x1               ; =1
     7d8:      	ldr	w23, [x23, #0x4]
     7dc:      	b	0x7e4 <_gap_prepare_graph+0x1d0>
     7e0:      	mov	x24, xzr
     7e4:      	cbz	w24, 0x838 <_gap_prepare_graph+0x224>
     7e8:      	cmp	w23, #0x1
     7ec:      	b.lt	0x844 <_gap_prepare_graph+0x230>
     7f0:      	and	x23, x23, #0x7fffffff
     7f4:      	cmp	x8, x23
     7f8:      	b.le	0x864 <_gap_prepare_graph+0x250>
     7fc:      	ldr	x24, [x20, #0x80]
     800:      	cmp	x24, x23
     804:      	b.le	0x864 <_gap_prepare_graph+0x250>
     808:      	ldr	w24, [x6, x23, lsl #2]
     80c:      	tbnz	w24, #0x1f, 0x864 <_gap_prepare_graph+0x250>
     810:      	lsl	x23, x23, #4
     814:      	ldr	x23, [x5, x23]
     818:      	and	x23, x23, #0xfe
     81c:      	cmp	x23, #0x70
     820:      	b.ne	0x9c4 <_gap_prepare_graph+0x3b0>
     824:      	add	w23, w24, #0x1
     828:      	cmp	w4, w23
     82c:      	csel	x23, xzr, x12, eq
     830:      	csel	x7, x7, x3, eq
     834:      	b	0x86c <_gap_prepare_graph+0x258>
     838:      	mov	w23, #0x10              ; =16
     83c:      	mov	x7, x15
     840:      	b	0x86c <_gap_prepare_graph+0x258>
     844:      	tbz	w23, #0x1f, 0x864 <_gap_prepare_graph+0x250>
     848:      	ldr	x7, [x20, #0x30]
     84c:      	ldr	x24, [x20, #0x58]
     850:      	cmp	x7, x24
     854:      	b.ne	0x864 <_gap_prepare_graph+0x250>
     858:      	sxtw	x23, w23
     85c:      	cmn	x7, x23
     860:      	b.ge	0x9d0 <_gap_prepare_graph+0x3bc>
     864:      	mov	w23, #0x12              ; =18
     868:      	mov	x7, x17
     86c:      	ands	w22, w14, w22, lsr #8
     870:      	csel	x23, x16, x23, eq
     874:      	csel	x26, x11, x7, eq
     878:      	cbnz	x23, 0x98c <_gap_prepare_graph+0x378>
     87c:      	cmp	w4, #0x2
     880:      	b.lt	0x98c <_gap_prepare_graph+0x378>
     884:      	cmp	w10, #0x1
     888:      	b.lt	0xa18 <_gap_prepare_graph+0x404>
     88c:      	and	x7, x10, #0x7fffffff
     890:      	cmp	x8, x7
     894:      	b.le	0xa18 <_gap_prepare_graph+0x404>
     898:      	ldr	x24, [x20, #0x80]
     89c:      	cmp	x8, x24
     8a0:      	csel	x23, x8, x24, lt
     8a4:      	cmp	x24, x7
     8a8:      	b.le	0xa18 <_gap_prepare_graph+0x404>
     8ac:      	ldr	w24, [x6, x7, lsl #2]
     8b0:      	tbnz	w24, #0x1f, 0xa18 <_gap_prepare_graph+0x404>
     8b4:      	mov	w25, #0x2               ; =2
     8b8:      	b	0x8c8 <_gap_prepare_graph+0x2b4>
     8bc:      	add	w25, w25, #0x1
     8c0:      	cmp	w25, w4
     8c4:      	b.gt	0x9a8 <_gap_prepare_graph+0x394>
     8c8:      	mov	x27, xzr
     8cc:      	cmp	w25, #0x1
     8d0:      	mov	x7, x26
     8d4:      	b.lt	0x984 <_gap_prepare_graph+0x370>
     8d8:      	cmp	w25, w24
     8dc:      	b.hi	0x8f4 <_gap_prepare_graph+0x2e0>
     8e0:      	add	w26, w10, w25, lsr #2
     8e4:      	and	w27, w25, #0x3
     8e8:      	add	x26, x5, w26, uxtw #4
     8ec:      	ldr	w26, [x26, w27, uxtw #2]
     8f0:      	mov	w27, #0x1               ; =1
     8f4:      	cbz	w27, 0xa18 <_gap_prepare_graph+0x404>
     8f8:      	cmp	w26, #0x0
     8fc:      	b.le	0x92c <_gap_prepare_graph+0x318>
     900:      	and	x26, x26, #0x7fffffff
     904:      	cmp	x26, x23
     908:      	b.ge	0xa18 <_gap_prepare_graph+0x404>
     90c:      	ldr	w27, [x6, x26, lsl #2]
     910:      	tbnz	w27, #0x1f, 0xa18 <_gap_prepare_graph+0x404>
     914:      	add	x26, x5, x26, lsl #4
     918:      	ldrb	w27, [x26, #0x1]
     91c:      	cmp	w27, w22
     920:      	csel	x26, x7, x13, eq
     924:      	b.eq	0x8bc <_gap_prepare_graph+0x2a8>
     928:      	b	0x9a8 <_gap_prepare_graph+0x394>
     92c:      	tbz	w26, #0x1f, 0xa18 <_gap_prepare_graph+0x404>
     930:      	ldr	x27, [x20, #0x30]
     934:      	ldr	x28, [x20, #0x58]
     938:      	cmp	x27, x28
     93c:      	b.ne	0xa18 <_gap_prepare_graph+0x404>
     940:      	sxtw	x28, w26
     944:      	cmn	x27, x28
     948:      	b.lt	0xa18 <_gap_prepare_graph+0x404>
     94c:      	ldr	x27, [x20, #0x50]
     950:      	mvn	x28, x28
     954:      	ldr	w27, [x27, x28, lsl #2]
     958:      	cmp	w27, #0x1
     95c:      	b.lt	0xa18 <_gap_prepare_graph+0x404>
     960:      	mvn	w26, w26
     964:      	ldr	x27, [x20, #0x28]
     968:      	and	x26, x26, #0x7fffffff
     96c:      	add	x26, x27, x26, lsl #4
     970:      	ldrb	w27, [x26, #0x1]
     974:      	cmp	w27, w22
     978:      	csel	x26, x7, x13, eq
     97c:      	b.eq	0x8bc <_gap_prepare_graph+0x2a8>
     980:      	b	0x9a8 <_gap_prepare_graph+0x394>
     984:      	cbnz	w27, 0x8f8 <_gap_prepare_graph+0x2e4>
     988:      	b	0xa18 <_gap_prepare_graph+0x404>
     98c:      	mov	x7, x26
     990:      	adds	x5, x4, #0x4
     994:      	add	x4, x4, #0x7
     998:      	csel	x4, x4, x5, mi
     99c:      	add	x10, x10, x4, asr #2
     9a0:      	cbz	x23, 0x768 <_gap_prepare_graph+0x154>
     9a4:      	b	0xa18 <_gap_prepare_graph+0x404>
     9a8:      	cmp	w27, w22
     9ac:      	b.ne	0xa18 <_gap_prepare_graph+0x404>
     9b0:      	adds	x5, x4, #0x4
     9b4:      	add	x4, x4, #0x7
     9b8:      	csel	x4, x4, x5, mi
     9bc:      	add	x10, x10, x4, asr #2
     9c0:      	b	0x768 <_gap_prepare_graph+0x154>
     9c4:      	mov	w23, #0x26              ; =38
     9c8:      	mov	x7, x1
     9cc:      	b	0x86c <_gap_prepare_graph+0x258>
     9d0:      	ldr	x7, [x20, #0x50]
     9d4:      	mvn	x23, x23
     9d8:      	ldr	w7, [x7, x23, lsl #2]
     9dc:      	cmp	w7, #0x0
     9e0:      	csel	x23, x2, x0, gt
     9e4:      	csel	x7, x1, x17, gt
     9e8:      	b	0x86c <_gap_prepare_graph+0x258>
     9ec:      	add	x0, sp, #0x18
     9f0:      	add	x3, sp, #0x4
     9f4:      	add	x5, sp, #0x8
     9f8:      	mov	x1, x20
     9fc:      	mov	w2, w19
     a00:      	mov	w4, #0x1                ; =1
     a04:      	add	x19, sp, #0x18
     a08:      	bl	0xa08 <_gap_prepare_graph+0x3f4>
		0000000000000a08:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare-checked
     a0c:      	ldr	w8, [sp, #0x18]
     a10:      	cmp	w8, #0x1
     a14:      	b.ne	0xa3c <_gap_prepare_graph+0x428>
     a18:      	mov	x0, xzr
     a1c:      	add	sp, sp, #0x2c0
     a20:      	ldp	x29, x30, [sp, #0x50]
     a24:      	ldp	x20, x19, [sp, #0x40]
     a28:      	ldp	x22, x21, [sp, #0x30]
     a2c:      	ldp	x24, x23, [sp, #0x20]
     a30:      	ldp	x26, x25, [sp, #0x10]
     a34:      	ldp	x28, x27, [sp], #0x60
     a38:      	ret
     a3c:      	add	x0, sp, #0x160
     a40:      	add	x1, x19, #0x8
     a44:      	mov	w2, #0x140              ; =320
     a48:      	bl	0xa48 <_gap_prepare_graph+0x434>
		0000000000000a48:  ARM64_RELOC_BRANCH26	_memcpy
     a4c:      	ldp	x8, x10, [x21, #0xc8]
     a50:      	mov	x9, xzr
     a54:      	mov	x19, xzr
     a58:      	cmp	xzr, x10
     a5c:      	b.ge	0xa70 <_gap_prepare_graph+0x45c>
     a60:      	b	0xa78 <_gap_prepare_graph+0x464>
     a64:      	add	x19, x19, w11, sxtw
     a68:      	cmp	x9, x10
     a6c:      	b.lt	0xa78 <_gap_prepare_graph+0x464>
     a70:      	mov	x12, xzr
     a74:      	b	0xa84 <_gap_prepare_graph+0x470>
     a78:      	ldr	w11, [x8, x9, lsl #2]
     a7c:      	add	x9, x9, #0x1
     a80:      	mov	w12, #0x1               ; =1
     a84:      	cbnz	w12, 0xa64 <_gap_prepare_graph+0x450>
     a88:      	add	x0, sp, #0x160
     a8c:      	add	x20, sp, #0x160
     a90:      	bl	0xa90 <_gap_prepare_graph+0x47c>
		0000000000000a90:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
     a94:      	ldr	x2, [x21, #0x88]
     a98:      	str	xzr, [x21, #0x80]
     a9c:      	cmp	x2, #0x1
     aa0:      	b.lt	0xac0 <_gap_prepare_graph+0x4ac>
     aa4:      	adrp	x3, 0x0 <ltmp0>
		0000000000000aa4:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
     aa8:      	ldr	x1, [x21, #0x78]
     aac:      	add	x0, x20, #0x90
     ab0:      	ldr	x3, [x3]
		0000000000000ab0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
     ab4:      	mov	w4, #0x4                ; =4
     ab8:      	mov	w5, #0x4                ; =4
     abc:      	bl	0xabc <_gap_prepare_graph+0x4a8>
		0000000000000abc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     ac0:      	ldr	x2, [x21, #0x100]
     ac4:      	stp	xzr, xzr, [x20, #0x78]
     ac8:      	stur	xzr, [x20, #0x88]
     acc:      	cmp	x2, #0x1
     ad0:      	str	xzr, [x21, #0xf8]
     ad4:      	b.lt	0xaf8 <_gap_prepare_graph+0x4e4>
     ad8:      	adrp	x3, 0x0 <ltmp0>
		0000000000000ad8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
     adc:      	ldr	x1, [x21, #0xf0]
     ae0:      	add	x8, sp, #0x160
     ae4:      	ldr	x3, [x3]
		0000000000000ae4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
     ae8:      	add	x0, x8, #0x108
     aec:      	mov	w4, #0x4                ; =4
     af0:      	mov	w5, #0x4                ; =4
     af4:      	bl	0xaf4 <_gap_prepare_graph+0x4e0>
		0000000000000af4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     af8:      	ldr	x2, [x21, #0x128]
     afc:      	stp	xzr, xzr, [x20, #0xf0]
     b00:      	str	xzr, [x20, #0x100]
     b04:      	add	x20, sp, #0x160
     b08:      	cmp	x2, #0x1
     b0c:      	str	xzr, [x21, #0x120]
     b10:      	b.lt	0xb30 <_gap_prepare_graph+0x51c>
     b14:      	adrp	x3, 0x0 <ltmp0>
		0000000000000b14:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
     b18:      	ldr	x1, [x21, #0x118]
     b1c:      	add	x0, x20, #0x130
     b20:      	ldr	x3, [x3]
		0000000000000b20:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
     b24:      	mov	w4, #0x4                ; =4
     b28:      	mov	w5, #0x4                ; =4
     b2c:      	bl	0xb2c <_gap_prepare_graph+0x518>
		0000000000000b2c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     b30:      	ldr	x2, [x21, #0xb0]
     b34:      	stp	xzr, xzr, [x20, #0x118]
     b38:      	str	xzr, [x20, #0x128]
     b3c:      	cmp	x2, #0x1
     b40:      	str	xzr, [x21, #0xa8]
     b44:      	b.lt	0xb68 <_gap_prepare_graph+0x554>
     b48:      	adrp	x3, 0x0 <ltmp0>
		0000000000000b48:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.schedule.Range.0
     b4c:      	ldr	x1, [x21, #0xa0]
     b50:      	add	x8, sp, #0x160
     b54:      	ldr	x3, [x3]
		0000000000000b54:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.schedule.Range.0
     b58:      	add	x0, x8, #0xb8
     b5c:      	mov	w4, #0x10               ; =16
     b60:      	mov	w5, #0x8                ; =8
     b64:      	bl	0xb64 <_gap_prepare_graph+0x550>
		0000000000000b64:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     b68:      	ldr	x2, [x21, #0xd8]
     b6c:      	stp	xzr, xzr, [x20, #0xa0]
     b70:      	stur	xzr, [x20, #0xb0]
     b74:      	cmp	x2, #0x1
     b78:      	str	xzr, [x21, #0xd0]
     b7c:      	b.lt	0xba0 <_gap_prepare_graph+0x58c>
     b80:      	adrp	x3, 0x0 <ltmp0>
		0000000000000b80:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
     b84:      	ldr	x1, [x21, #0xc8]
     b88:      	add	x8, sp, #0x160
     b8c:      	ldr	x3, [x3]
		0000000000000b8c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
     b90:      	add	x0, x8, #0xe0
     b94:      	mov	w4, #0x4                ; =4
     b98:      	mov	w5, #0x4                ; =4
     b9c:      	bl	0xb9c <_gap_prepare_graph+0x588>
		0000000000000b9c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     ba0:      	mov	x0, x19
     ba4:      	b	0xa1c <_gap_prepare_graph+0x408>

0000000000000ba8 <_inherent$coil.arraylist.ArrayList$free!__i32>:
     ba8:      	stp	x20, x19, [sp, #-0x20]!
     bac:      	stp	x29, x30, [sp, #0x10]
     bb0:      	add	x29, sp, #0x10
     bb4:      	ldr	x8, [x0, #0x8]
     bb8:      	mov	x19, x0
     bbc:      	cbz	x8, 0xbc4 <_inherent$coil.arraylist.ArrayList$free!__i32+0x1c>
     bc0:      	str	xzr, [x19, #0x8]
     bc4:      	ldr	x2, [x19, #0x10]
     bc8:      	cmp	x2, #0x1
     bcc:      	b.lt	0xbec <_inherent$coil.arraylist.ArrayList$free!__i32+0x44>
     bd0:      	mov	x0, x19
     bd4:      	adrp	x3, 0x0 <ltmp0>
		0000000000000bd4:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
     bd8:      	mov	w4, #0x4                ; =4
     bdc:      	ldr	x1, [x0], #0x18
     be0:      	ldr	x3, [x3]
		0000000000000be0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
     be4:      	mov	w5, #0x4                ; =4
     be8:      	bl	0xbe8 <_inherent$coil.arraylist.ArrayList$free!__i32+0x40>
		0000000000000be8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     bec:      	ldp	x29, x30, [sp, #0x10]
     bf0:      	stp	xzr, xzr, [x19]
     bf4:      	str	xzr, [x19, #0x10]
     bf8:      	ldp	x20, x19, [sp], #0x20
     bfc:      	ret

0000000000000c00 <_stogir.adjacency.build>:
     c00:      	sub	sp, sp, #0xc0
     c04:      	stp	x28, x27, [sp, #0x60]
     c08:      	stp	x26, x25, [sp, #0x70]
     c0c:      	stp	x24, x23, [sp, #0x80]
     c10:      	stp	x22, x21, [sp, #0x90]
     c14:      	stp	x20, x19, [sp, #0xa0]
     c18:      	stp	x29, x30, [sp, #0xb0]
     c1c:      	add	x29, sp, #0xb0
     c20:      	ldr	x20, [x1, #0x30]
     c24:      	ldr	q0, [x3]
     c28:      	mov	w23, w2
     c2c:      	ldr	q1, [x3]
     c30:      	mov	x21, x1
     c34:      	mov	x19, x0
     c38:      	cmp	x20, #0x1
     c3c:      	add	x24, sp, #0x28
     c40:      	stp	xzr, xzr, [sp, #0x28]
     c44:      	str	xzr, [sp, #0x38]
     c48:      	stp	q0, q0, [sp, #0x40]
     c4c:      	str	q1, [sp]
     c50:      	b.lt	0xcd0 <_stogir.adjacency.build+0xd0>
     c54:      	ldr	q0, [x3]
     c58:      	adrp	x4, 0x0 <ltmp0>
		0000000000000c58:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Range.0
     c5c:      	add	x0, sp, #0x10
     c60:      	mov	x1, xzr
     c64:      	mov	x2, xzr
     c68:      	mov	x3, x20
     c6c:      	str	q0, [sp, #0x10]
     c70:      	mov	w5, #0x10               ; =16
     c74:      	mov	w6, #0x8                ; =8
     c78:      	ldr	x4, [x4]
		0000000000000c78:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Range.0
     c7c:      	bl	0xc7c <_stogir.adjacency.build+0x7c>
		0000000000000c7c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
     c80:      	cbz	w0, 0xed0 <_stogir.adjacency.build+0x2d0>
     c84:      	mov	x22, x1
     c88:      	lsl	x1, x20, #4
     c8c:      	mov	x0, x22
     c90:      	bl	0xc90 <_stogir.adjacency.build+0x90>
		0000000000000c90:  ARM64_RELOC_BRANCH26	_bzero
     c94:      	adrp	x4, 0x0 <ltmp0>
		0000000000000c94:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
     c98:      	add	x0, x24, #0x18
     c9c:      	mov	x1, xzr
     ca0:      	ldr	x4, [x4]
		0000000000000ca0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
     ca4:      	mov	x2, xzr
     ca8:      	mov	x3, x20
     cac:      	mov	w5, #0x8                ; =8
     cb0:      	mov	w6, #0x8                ; =8
     cb4:      	bl	0xcb4 <_stogir.adjacency.build+0xb4>
		0000000000000cb4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
     cb8:      	cbz	w0, 0xee0 <_stogir.adjacency.build+0x2e0>
     cbc:      	mov	x25, x1
     cc0:      	str	x1, [sp, #0x28]
     cc4:      	mov	x24, x20
     cc8:      	str	x20, [sp, #0x38]
     ccc:      	b	0xcdc <_stogir.adjacency.build+0xdc>
     cd0:      	mov	x24, xzr
     cd4:      	mov	x22, xzr
     cd8:      	mov	x25, xzr
     cdc:      	lsl	x1, x20, #3
     ce0:      	mov	x0, x25
     ce4:      	bl	0xce4 <_stogir.adjacency.build+0xe4>
		0000000000000ce4:  ARM64_RELOC_BRANCH26	_bzero
     ce8:      	ldr	x8, [x21, #0x58]
     cec:      	str	x20, [sp, #0x30]
     cf0:      	cmp	x8, #0x1
     cf4:      	b.lt	0xd40 <_stogir.adjacency.build+0x140>
     cf8:      	ldr	x9, [x21, #0x50]
     cfc:      	tbz	w23, #0x0, 0xd24 <_stogir.adjacency.build+0x124>
     d00:      	add	x9, x9, #0x4
     d04:      	ldrsw	x10, [x9], #0x10
     d08:      	subs	x8, x8, #0x1
     d0c:      	add	x10, x22, x10, lsl #4
     d10:      	ldr	x11, [x10, #0x8]
     d14:      	add	x11, x11, #0x1
     d18:      	str	x11, [x10, #0x8]
     d1c:      	b.ne	0xd04 <_stogir.adjacency.build+0x104>
     d20:      	b	0xd40 <_stogir.adjacency.build+0x140>
     d24:      	ldrsw	x10, [x9], #0x10
     d28:      	subs	x8, x8, #0x1
     d2c:      	add	x10, x22, x10, lsl #4
     d30:      	ldr	x11, [x10, #0x8]
     d34:      	add	x11, x11, #0x1
     d38:      	str	x11, [x10, #0x8]
     d3c:      	b.ne	0xd24 <_stogir.adjacency.build+0x124>
     d40:      	cmp	x20, #0x1
     d44:      	b.lt	0xd74 <_stogir.adjacency.build+0x174>
     d48:      	mov	x8, xzr
     d4c:      	add	x9, x22, #0x8
     d50:      	mov	x10, x25
     d54:      	mov	x11, x20
     d58:      	ldr	x12, [x9]
     d5c:      	stur	x8, [x9, #-0x8]
     d60:      	subs	x11, x11, #0x1
     d64:      	str	x8, [x10], #0x8
     d68:      	add	x9, x9, #0x10
     d6c:      	add	x8, x12, x8
     d70:      	b.ne	0xd58 <_stogir.adjacency.build+0x158>
     d74:      	ldr	x26, [x21, #0x58]
     d78:      	cmp	x26, #0x1
     d7c:      	b.lt	0xdcc <_stogir.adjacency.build+0x1cc>
     d80:      	adrp	x4, 0x0 <ltmp0>
		0000000000000d80:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
     d84:      	add	x0, sp, #0x50
     d88:      	mov	x1, xzr
     d8c:      	ldr	x4, [x4]
		0000000000000d8c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
     d90:      	mov	x2, xzr
     d94:      	mov	x3, x26
     d98:      	mov	w5, #0x8                ; =8
     d9c:      	mov	w6, #0x8                ; =8
     da0:      	bl	0xda0 <_stogir.adjacency.build+0x1a0>
		0000000000000da0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
     da4:      	cbz	w0, 0xef0 <_stogir.adjacency.build+0x2f0>
     da8:      	mov	x27, x1
     dac:      	mov	x28, x26
     db0:      	lsl	x1, x26, #3
     db4:      	mov	x0, x27
     db8:      	bl	0xdb8 <_stogir.adjacency.build+0x1b8>
		0000000000000db8:  ARM64_RELOC_BRANCH26	_bzero
     dbc:      	ldr	x8, [x21, #0x58]
     dc0:      	cmp	x8, #0x1
     dc4:      	b.ge	0xdec <_stogir.adjacency.build+0x1ec>
     dc8:      	b	0xe60 <_stogir.adjacency.build+0x260>
     dcc:      	mov	x27, xzr
     dd0:      	mov	x28, xzr
     dd4:      	lsl	x1, x26, #3
     dd8:      	mov	x0, x27
     ddc:      	bl	0xddc <_stogir.adjacency.build+0x1dc>
		0000000000000ddc:  ARM64_RELOC_BRANCH26	_bzero
     de0:      	ldr	x8, [x21, #0x58]
     de4:      	cmp	x8, #0x1
     de8:      	b.lt	0xe60 <_stogir.adjacency.build+0x260>
     dec:      	mov	x8, xzr
     df0:      	mov	x9, xzr
     df4:      	tbz	w23, #0x0, 0xe30 <_stogir.adjacency.build+0x230>
     df8:      	ldr	x10, [x21, #0x50]
     dfc:      	ldr	x10, [x10, x8]
     e00:      	add	x8, x8, #0x10
     e04:      	asr	x10, x10, #29
     e08:      	and	x10, x10, #0xfffffffffffffff8
     e0c:      	ldr	x11, [x25, x10]
     e10:      	str	x9, [x27, x11, lsl #3]
     e14:      	add	x11, x11, #0x1
     e18:      	add	x9, x9, #0x1
     e1c:      	str	x11, [x25, x10]
     e20:      	ldr	x10, [x21, #0x58]
     e24:      	cmp	x9, x10
     e28:      	b.lt	0xdf8 <_stogir.adjacency.build+0x1f8>
     e2c:      	b	0xe60 <_stogir.adjacency.build+0x260>
     e30:      	ldr	x10, [x21, #0x50]
     e34:      	ldr	x10, [x10, x8]
     e38:      	add	x8, x8, #0x10
     e3c:      	sbfiz	x10, x10, #3, #32
     e40:      	ldr	x11, [x25, x10]
     e44:      	str	x9, [x27, x11, lsl #3]
     e48:      	add	x11, x11, #0x1
     e4c:      	add	x9, x9, #0x1
     e50:      	str	x11, [x25, x10]
     e54:      	ldr	x10, [x21, #0x58]
     e58:      	cmp	x9, x10
     e5c:      	b.lt	0xe30 <_stogir.adjacency.build+0x230>
     e60:      	cbz	x20, 0xe68 <_stogir.adjacency.build+0x268>
     e64:      	str	xzr, [sp, #0x30]
     e68:      	cbz	x24, 0xe90 <_stogir.adjacency.build+0x290>
     e6c:      	adrp	x3, 0x0 <ltmp0>
		0000000000000e6c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
     e70:      	add	x8, sp, #0x28
     e74:      	mov	x1, x25
     e78:      	ldr	x3, [x3]
		0000000000000e78:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
     e7c:      	add	x0, x8, #0x18
     e80:      	mov	x2, x24
     e84:      	mov	w4, #0x8                ; =8
     e88:      	mov	w5, #0x8                ; =8
     e8c:      	bl	0xe8c <_stogir.adjacency.build+0x28c>
		0000000000000e8c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     e90:      	ldr	q0, [sp]
     e94:      	stp	x22, x20, [x19]
     e98:      	str	x24, [x19, #0x10]
     e9c:      	ldp	x29, x30, [sp, #0xb0]
     ea0:      	stur	q0, [x19, #0x18]
     ea4:      	ldr	q0, [sp, #0x50]
     ea8:      	stp	x27, x26, [x19, #0x28]
     eac:      	ldp	x22, x21, [sp, #0x90]
     eb0:      	str	x28, [x19, #0x38]
     eb4:      	ldp	x24, x23, [sp, #0x80]
     eb8:      	str	q0, [x19, #0x40]
     ebc:      	ldp	x20, x19, [sp, #0xa0]
     ec0:      	ldp	x26, x25, [sp, #0x70]
     ec4:      	ldp	x28, x27, [sp, #0x60]
     ec8:      	add	sp, sp, #0xc0
     ecc:      	ret
     ed0:      	lsl	x1, x20, #4
     ed4:      	adrp	x0, 0x0 <ltmp0>
		0000000000000ed4:  ARM64_RELOC_PAGE21	l_cstr.208
     ed8:      	add	x0, x0, #0x0
		0000000000000ed8:  ARM64_RELOC_PAGEOFF12	l_cstr.208
     edc:      	bl	0xedc <_stogir.adjacency.build+0x2dc>
		0000000000000edc:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
     ee0:      	lsl	x1, x20, #3
     ee4:      	adrp	x0, 0x0 <ltmp0>
		0000000000000ee4:  ARM64_RELOC_PAGE21	l_cstr.205
     ee8:      	add	x0, x0, #0x0
		0000000000000ee8:  ARM64_RELOC_PAGEOFF12	l_cstr.205
     eec:      	bl	0xeec <_stogir.adjacency.build+0x2ec>
		0000000000000eec:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
     ef0:      	lsl	x1, x26, #3
     ef4:      	adrp	x0, 0x0 <ltmp0>
		0000000000000ef4:  ARM64_RELOC_PAGE21	l_cstr.205
     ef8:      	add	x0, x0, #0x0
		0000000000000ef8:  ARM64_RELOC_PAGEOFF12	l_cstr.205
     efc:      	bl	0xefc <_stogir.adjacency.build+0x2fc>
		0000000000000efc:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at

0000000000000f00 <_stogir.cfg.release!>:
     f00:      	stp	x20, x19, [sp, #-0x20]!
     f04:      	stp	x29, x30, [sp, #0x10]
     f08:      	add	x29, sp, #0x10
     f0c:      	ldr	x8, [x0, #0x8]
     f10:      	mov	x19, x0
     f14:      	cbz	x8, 0xf1c <_stogir.cfg.release!+0x1c>
     f18:      	str	xzr, [x19, #0x8]
     f1c:      	ldr	x2, [x19, #0x10]
     f20:      	cmp	x2, #0x1
     f24:      	b.lt	0xf44 <_stogir.cfg.release!+0x44>
     f28:      	mov	x0, x19
     f2c:      	adrp	x3, 0x0 <ltmp0>
		0000000000000f2c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
     f30:      	mov	w4, #0x4                ; =4
     f34:      	ldr	x1, [x0], #0x18
     f38:      	ldr	x3, [x3]
		0000000000000f38:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
     f3c:      	mov	w5, #0x4                ; =4
     f40:      	bl	0xf40 <_stogir.cfg.release!+0x40>
		0000000000000f40:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     f44:      	ldr	x8, [x19, #0x30]
     f48:      	stp	xzr, xzr, [x19]
     f4c:      	str	xzr, [x19, #0x10]
     f50:      	cbz	x8, 0xf58 <_stogir.cfg.release!+0x58>
     f54:      	str	xzr, [x19, #0x30]
     f58:      	ldr	x2, [x19, #0x38]
     f5c:      	cmp	x2, #0x1
     f60:      	b.lt	0xf80 <_stogir.cfg.release!+0x80>
     f64:      	adrp	x3, 0x0 <ltmp0>
		0000000000000f64:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
     f68:      	ldr	x1, [x19, #0x28]
     f6c:      	add	x0, x19, #0x40
     f70:      	ldr	x3, [x3]
		0000000000000f70:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
     f74:      	mov	w4, #0x4                ; =4
     f78:      	mov	w5, #0x4                ; =4
     f7c:      	bl	0xf7c <_stogir.cfg.release!+0x7c>
		0000000000000f7c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     f80:      	ldr	x8, [x19, #0x58]
     f84:      	stp	xzr, xzr, [x19, #0x28]
     f88:      	stur	xzr, [x19, #0x38]
     f8c:      	cbz	x8, 0xf94 <_stogir.cfg.release!+0x94>
     f90:      	str	xzr, [x19, #0x58]
     f94:      	ldr	x2, [x19, #0x60]
     f98:      	cmp	x2, #0x1
     f9c:      	b.lt	0xfbc <_stogir.cfg.release!+0xbc>
     fa0:      	adrp	x3, 0x0 <ltmp0>
		0000000000000fa0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.cfg.Edge.0
     fa4:      	ldr	x1, [x19, #0x50]
     fa8:      	add	x0, x19, #0x68
     fac:      	ldr	x3, [x3]
		0000000000000fac:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.cfg.Edge.0
     fb0:      	mov	w4, #0x10               ; =16
     fb4:      	mov	w5, #0x4                ; =4
     fb8:      	bl	0xfb8 <_stogir.cfg.release!+0xb8>
		0000000000000fb8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     fbc:      	ldp	x29, x30, [sp, #0x10]
     fc0:      	stp	xzr, xzr, [x19, #0x50]
     fc4:      	stur	xzr, [x19, #0x60]
     fc8:      	ldp	x20, x19, [sp], #0x20
     fcc:      	ret

0000000000000fd0 <_stogir.checked-schedule.cluster!>:
     fd0:      	sub	sp, sp, #0x1e0
     fd4:      	stp	x28, x27, [sp, #0x180]
     fd8:      	stp	x26, x25, [sp, #0x190]
     fdc:      	stp	x24, x23, [sp, #0x1a0]
     fe0:      	stp	x22, x21, [sp, #0x1b0]
     fe4:      	stp	x20, x19, [sp, #0x1c0]
     fe8:      	stp	x29, x30, [sp, #0x1d0]
     fec:      	add	x29, sp, #0x1d0
     ff0:      	mov	x24, x3
     ff4:      	mov	x23, x4
     ff8:      	mov	x25, x3
     ffc:      	ldp	x27, x28, [x24, #0x28]!
    1000:      	mov	x21, x1
    1004:      	mov	x26, x0
    1008:      	mov	x19, xzr
    100c:      	mov	x20, xzr
    1010:      	mov	w22, wzr
    1014:      	adrp	x8, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001014:  ARM64_RELOC_PAGE21	l_str.383
    1018:      	add	x8, x8, #0x0
		0000000000001018:  ARM64_RELOC_PAGEOFF12	l_str.383
    101c:      	stp	x2, x8, [sp, #0x40]
    1020:      	b	0x1040 <_stogir.checked-schedule.cluster!+0x70>
    1024:      	mov	x8, xzr
    1028:      	cbz	w8, 0x1090 <_stogir.checked-schedule.cluster!+0xc0>
    102c:      	ldr	x8, [x21]
    1030:      	sbfiz	x9, x2, #4, #32
    1034:      	ldrb	w8, [x8, x9]
    1038:      	cmp	x8, #0x2c
    103c:      	b.eq	0x105c <_stogir.checked-schedule.cluster!+0x8c>
    1040:      	cmp	x20, x28
    1044:      	b.ge	0x1024 <_stogir.checked-schedule.cluster!+0x54>
    1048:      	ldr	w2, [x27, x20, lsl #2]
    104c:      	add	x20, x20, #0x1
    1050:      	mov	w8, #0x1                ; =1
    1054:      	cbnz	w8, 0x102c <_stogir.checked-schedule.cluster!+0x5c>
    1058:      	b	0x1090 <_stogir.checked-schedule.cluster!+0xc0>
    105c:      	add	x0, sp, #0x50
    1060:      	mov	x1, x21
    1064:      	bl	0x1064 <_stogir.checked-schedule.cluster!+0x94>
		0000000000001064:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    1068:      	ldr	w8, [sp, #0x50]
    106c:      	cmp	w8, #0x1
    1070:      	b.eq	0x1084 <_stogir.checked-schedule.cluster!+0xb4>
    1074:      	ldr	w8, [sp, #0x58]
    1078:      	cmp	w8, #0x0
    107c:      	cinc	w22, w22, ne
    1080:      	b	0x1040 <_stogir.checked-schedule.cluster!+0x70>
    1084:      	ldp	x8, x19, [sp, #0x58]
    1088:      	str	x8, [sp, #0x48]
    108c:      	b	0x1040 <_stogir.checked-schedule.cluster!+0x70>
    1090:      	cbz	x19, 0x10c4 <_stogir.checked-schedule.cluster!+0xf4>
    1094:      	mov	w8, #0x1                ; =1
    1098:      	str	w8, [x26]
    109c:      	ldr	x8, [sp, #0x48]
    10a0:      	stp	x8, x19, [x26, #0x8]
    10a4:      	ldp	x29, x30, [sp, #0x1d0]
    10a8:      	ldp	x20, x19, [sp, #0x1c0]
    10ac:      	ldp	x22, x21, [sp, #0x1b0]
    10b0:      	ldp	x24, x23, [sp, #0x1a0]
    10b4:      	ldp	x26, x25, [sp, #0x190]
    10b8:      	ldp	x28, x27, [sp, #0x180]
    10bc:      	add	sp, sp, #0x1e0
    10c0:      	ret
    10c4:      	cbz	w22, 0x1308 <_stogir.checked-schedule.cluster!+0x338>
    10c8:      	ldr	q0, [x23]
    10cc:      	add	x9, sp, #0xb8
    10d0:      	ldr	x8, [x21, #0x8]
    10d4:      	stp	x26, x25, [sp, #0x28]
    10d8:      	stur	q0, [sp, #0x80]
    10dc:      	cmp	x8, #0x1
    10e0:      	stur	q0, [sp, #0xa8]
    10e4:      	stur	q0, [x9, #0x18]
    10e8:      	stur	q0, [x9, #0x40]
    10ec:      	ldr	q0, [x23]
    10f0:      	str	x24, [sp, #0x18]
    10f4:      	str	w22, [sp, #0x24]
    10f8:      	stp	xzr, xzr, [sp, #0x68]
    10fc:      	str	xzr, [sp, #0x78]
    1100:      	stp	xzr, xzr, [sp, #0x98]
    1104:      	str	xzr, [sp, #0x90]
    1108:      	stp	xzr, xzr, [sp, #0xc0]
    110c:      	str	xzr, [sp, #0xb8]
    1110:      	stp	xzr, xzr, [sp, #0xe8]
    1114:      	str	xzr, [sp, #0xe0]
    1118:      	stp	xzr, xzr, [x29, #-0x98]
    111c:      	stur	xzr, [x29, #-0x88]
    1120:      	stur	q0, [x9, #0x98]
    1124:      	b.lt	0x1338 <_stogir.checked-schedule.cluster!+0x368>
    1128:      	mov	x19, xzr
    112c:      	mov	x1, xzr
    1130:      	mov	x23, xzr
    1134:      	mov	x26, xzr
    1138:      	mov	x25, xzr
    113c:      	mov	w27, #0x2               ; =2
    1140:      	b	0x116c <_stogir.checked-schedule.cluster!+0x19c>
    1144:      	mov	x25, x1
    1148:      	str	x22, [sp, #0xf0]
    114c:      	strb	wzr, [x25, x20]
    1150:      	add	x19, x19, #0x1
    1154:      	add	x9, x20, #0x1
    1158:      	ldr	x8, [x21, #0x8]
    115c:      	mov	x1, x28
    1160:      	str	x9, [sp, #0xe8]
    1164:      	cmp	x19, x8
    1168:      	b.ge	0x12fc <_stogir.checked-schedule.cluster!+0x32c>
    116c:      	ldp	x24, x2, [sp, #0x70]
    1170:      	cmp	x24, x2
    1174:      	b.lt	0x11bc <_stogir.checked-schedule.cluster!+0x1ec>
    1178:      	lsl	x8, x2, #1
    117c:      	cmp	x2, #0x0
    1180:      	csel	x22, x27, x8, eq
    1184:      	add	x8, sp, #0x68
    1188:      	ldur	q0, [x8, #0x18]
    118c:      	cmp	x22, x2
    1190:      	stur	q0, [x29, #-0x70]
    1194:      	b.le	0x11bc <_stogir.checked-schedule.cluster!+0x1ec>
    1198:      	adrp	x4, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001198:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    119c:      	sub	x0, x29, #0x70
    11a0:      	mov	x3, x22
    11a4:      	ldr	x4, [x4]
		00000000000011a4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    11a8:      	mov	w5, #0x4                ; =4
    11ac:      	mov	w6, #0x4                ; =4
    11b0:      	bl	0x11b0 <_stogir.checked-schedule.cluster!+0x1e0>
		00000000000011b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    11b4:      	cbz	w0, 0x1848 <_stogir.checked-schedule.cluster!+0x878>
    11b8:      	str	x22, [sp, #0x78]
    11bc:      	str	wzr, [x1, x24, lsl #2]
    11c0:      	mov	x28, x1
    11c4:      	add	x8, x24, #0x1
    11c8:      	ldp	x20, x2, [sp, #0x98]
    11cc:      	str	x8, [sp, #0x70]
    11d0:      	cmp	x20, x2
    11d4:      	b.lt	0x1224 <_stogir.checked-schedule.cluster!+0x254>
    11d8:      	lsl	x8, x2, #1
    11dc:      	cmp	x2, #0x0
    11e0:      	csel	x22, x27, x8, eq
    11e4:      	add	x8, sp, #0x90
    11e8:      	ldur	q0, [x8, #0x18]
    11ec:      	cmp	x22, x2
    11f0:      	stur	q0, [x29, #-0x70]
    11f4:      	b.le	0x1224 <_stogir.checked-schedule.cluster!+0x254>
    11f8:      	adrp	x4, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		00000000000011f8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    11fc:      	sub	x0, x29, #0x70
    1200:      	mov	x1, x23
    1204:      	ldr	x4, [x4]
		0000000000001204:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    1208:      	mov	x3, x22
    120c:      	mov	w5, #0x4                ; =4
    1210:      	mov	w6, #0x4                ; =4
    1214:      	bl	0x1214 <_stogir.checked-schedule.cluster!+0x244>
		0000000000001214:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    1218:      	cbz	w0, 0x1848 <_stogir.checked-schedule.cluster!+0x878>
    121c:      	mov	x23, x1
    1220:      	str	x22, [sp, #0xa0]
    1224:      	str	wzr, [x23, x20, lsl #2]
    1228:      	add	x8, x20, #0x1
    122c:      	ldp	x24, x2, [sp, #0xc0]
    1230:      	str	x8, [sp, #0x98]
    1234:      	cmp	x24, x2
    1238:      	b.lt	0x1288 <_stogir.checked-schedule.cluster!+0x2b8>
    123c:      	lsl	x8, x2, #1
    1240:      	cmp	x2, #0x0
    1244:      	csel	x22, x27, x8, eq
    1248:      	add	x8, sp, #0xb8
    124c:      	ldur	q0, [x8, #0x18]
    1250:      	cmp	x22, x2
    1254:      	stur	q0, [x29, #-0x70]
    1258:      	b.le	0x1288 <_stogir.checked-schedule.cluster!+0x2b8>
    125c:      	adrp	x4, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000125c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    1260:      	sub	x0, x29, #0x70
    1264:      	mov	x1, x26
    1268:      	ldr	x4, [x4]
		0000000000001268:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    126c:      	mov	x3, x22
    1270:      	mov	w5, #0x4                ; =4
    1274:      	mov	w6, #0x4                ; =4
    1278:      	bl	0x1278 <_stogir.checked-schedule.cluster!+0x2a8>
		0000000000001278:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    127c:      	cbz	w0, 0x1848 <_stogir.checked-schedule.cluster!+0x878>
    1280:      	str	x22, [sp, #0xc8]
    1284:      	b	0x128c <_stogir.checked-schedule.cluster!+0x2bc>
    1288:      	mov	x1, x26
    128c:      	str	wzr, [x1, x24, lsl #2]
    1290:      	mov	x26, x1
    1294:      	add	x8, x24, #0x1
    1298:      	ldp	x20, x2, [sp, #0xe8]
    129c:      	str	x8, [sp, #0xc0]
    12a0:      	cmp	x20, x2
    12a4:      	b.lt	0x114c <_stogir.checked-schedule.cluster!+0x17c>
    12a8:      	lsl	x8, x2, #1
    12ac:      	cmp	x2, #0x0
    12b0:      	csel	x22, x27, x8, eq
    12b4:      	add	x8, sp, #0xe0
    12b8:      	ldur	q0, [x8, #0x18]
    12bc:      	cmp	x22, x2
    12c0:      	stur	q0, [x29, #-0x70]
    12c4:      	b.le	0x114c <_stogir.checked-schedule.cluster!+0x17c>
    12c8:      	adrp	x4, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		00000000000012c8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__bool.0
    12cc:      	sub	x0, x29, #0x70
    12d0:      	mov	x1, x25
    12d4:      	ldr	x4, [x4]
		00000000000012d4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__bool.0
    12d8:      	mov	x3, x22
    12dc:      	mov	w5, #0x1                ; =1
    12e0:      	mov	w6, #0x1                ; =1
    12e4:      	bl	0x12e4 <_stogir.checked-schedule.cluster!+0x314>
		00000000000012e4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    12e8:      	cbnz	w0, 0x1144 <_stogir.checked-schedule.cluster!+0x174>
    12ec:      	adrp	x0, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		00000000000012ec:  ARM64_RELOC_PAGE21	l_cstr.203
    12f0:      	add	x0, x0, #0x0
		00000000000012f0:  ARM64_RELOC_PAGEOFF12	l_cstr.203
    12f4:      	mov	x1, x22
    12f8:      	bl	0x12f8 <_stogir.checked-schedule.cluster!+0x328>
		00000000000012f8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    12fc:      	ldr	x8, [sp, #0x30]
    1300:      	ldp	x27, x28, [x8, #0x28]
    1304:      	b	0x1348 <_stogir.checked-schedule.cluster!+0x378>
    1308:      	mov	x0, x26
    130c:      	mov	x1, x21
    1310:      	mov	x2, x27
    1314:      	mov	x3, x28
    1318:      	ldp	x29, x30, [sp, #0x1d0]
    131c:      	ldp	x20, x19, [sp, #0x1c0]
    1320:      	ldp	x22, x21, [sp, #0x1b0]
    1324:      	ldp	x24, x23, [sp, #0x1a0]
    1328:      	ldp	x26, x25, [sp, #0x190]
    132c:      	ldp	x28, x27, [sp, #0x180]
    1330:      	add	sp, sp, #0x1e0
    1334:      	b	0x1334 <_stogir.checked-schedule.cluster!+0x364>
		0000000000001334:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    1338:      	mov	x25, xzr
    133c:      	mov	x26, xzr
    1340:      	mov	x23, xzr
    1344:      	mov	x1, xzr
    1348:      	mov	x22, xzr
    134c:      	sub	x19, x29, #0x98
    1350:      	str	xzr, [sp, #0x38]
    1354:      	stp	x1, x26, [sp, #0x8]
    1358:      	str	x1, [sp, #0x68]
    135c:      	str	x23, [sp, #0x90]
    1360:      	str	x26, [sp, #0xb8]
    1364:      	str	x25, [sp, #0xe0]
    1368:      	b	0x1390 <_stogir.checked-schedule.cluster!+0x3c0>
    136c:      	mov	w8, #0x1                ; =1
    1370:      	adrp	x9, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001370:  ARM64_RELOC_PAGE21	l_str.407
    1374:      	add	x9, x9, #0x0
		0000000000001374:  ARM64_RELOC_PAGEOFF12	l_str.407
    1378:      	stur	w8, [x29, #-0xc8]
    137c:      	mov	w8, #0x17               ; =23
    1380:      	str	x8, [sp, #0x38]
    1384:      	mov	w8, #0x17               ; =23
    1388:      	str	x9, [sp, #0x48]
    138c:      	stp	x9, x8, [x29, #-0xc0]
    1390:      	cmp	x22, x28
    1394:      	b.ge	0x13ac <_stogir.checked-schedule.cluster!+0x3dc>
    1398:      	ldr	w20, [x27, x22, lsl #2]
    139c:      	add	x22, x22, #0x1
    13a0:      	mov	w8, #0x1                ; =1
    13a4:      	cbnz	w8, 0x13b4 <_stogir.checked-schedule.cluster!+0x3e4>
    13a8:      	b	0x1548 <_stogir.checked-schedule.cluster!+0x578>
    13ac:      	mov	x8, xzr
    13b0:      	cbz	w8, 0x1548 <_stogir.checked-schedule.cluster!+0x578>
    13b4:      	sxtw	x26, w20
    13b8:      	ldr	x8, [x21]
    13bc:      	lsl	x9, x26, #4
    13c0:      	ldr	x24, [x8, x9]
    13c4:      	and	x9, x24, #0xff
    13c8:      	cmp	x9, #0x2c
    13cc:      	b.ne	0x1390 <_stogir.checked-schedule.cluster!+0x3c0>
    13d0:      	lsr	x2, x24, #32
    13d4:      	cmp	w2, #0x1
    13d8:      	b.lt	0x1484 <_stogir.checked-schedule.cluster!+0x4b4>
    13dc:      	ldr	x9, [x21, #0x8]
    13e0:      	cmp	x9, x2
    13e4:      	b.le	0x136c <_stogir.checked-schedule.cluster!+0x39c>
    13e8:      	ldr	x9, [x21, #0x80]
    13ec:      	cmp	x9, x2
    13f0:      	b.le	0x136c <_stogir.checked-schedule.cluster!+0x39c>
    13f4:      	ldr	x9, [x21, #0x78]
    13f8:      	ldr	w9, [x9, x2, lsl #2]
    13fc:      	tbnz	w9, #0x1f, 0x136c <_stogir.checked-schedule.cluster!+0x39c>
    1400:      	add	x8, x8, x2, lsl #4
    1404:      	ldr	x8, [x8]
    1408:      	and	w9, w8, #0xff
    140c:      	sub	w9, w9, #0x29
    1410:      	cmp	w9, #0x3
    1414:      	b.hs	0x14d8 <_stogir.checked-schedule.cluster!+0x508>
    1418:      	sub	x0, x29, #0xc8
    141c:      	mov	x1, x21
    1420:      	bl	0x1420 <_stogir.checked-schedule.cluster!+0x450>
		0000000000001420:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1424:      	ldur	w8, [x29, #-0xc8]
    1428:      	cmp	w8, #0x1
    142c:      	b.eq	0x14f8 <_stogir.checked-schedule.cluster!+0x528>
    1430:      	ldur	w8, [x29, #-0xc0]
    1434:      	cbz	w8, 0x1390 <_stogir.checked-schedule.cluster!+0x3c0>
    1438:      	asr	x8, x24, #32
    143c:      	ldr	x9, [sp, #0x40]
    1440:      	ldr	w10, [x9, x8, lsl #2]
    1444:      	ldr	w11, [x9, x26, lsl #2]
    1448:      	ldrsw	x9, [x23, x8, lsl #2]
    144c:      	cmp	w10, w11
    1450:      	ldr	x10, [sp, #0x38]
    1454:      	mov	w11, #0x30              ; =48
    1458:      	csel	x10, x10, x11, eq
    145c:      	adrp	x11, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000145c:  ARM64_RELOC_PAGE21	l_str.385
    1460:      	add	x11, x11, #0x0
		0000000000001460:  ARM64_RELOC_PAGEOFF12	l_str.385
    1464:      	str	x10, [sp, #0x38]
    1468:      	ldr	x10, [sp, #0x48]
    146c:      	csel	x10, x10, x11, eq
    1470:      	str	x10, [sp, #0x48]
    1474:      	cbz	w9, 0x1530 <_stogir.checked-schedule.cluster!+0x560>
    1478:      	ldr	x10, [sp, #0x10]
    147c:      	str	w20, [x10, x9, lsl #2]
    1480:      	b	0x1538 <_stogir.checked-schedule.cluster!+0x568>
    1484:      	tbz	x24, #0x3f, 0x136c <_stogir.checked-schedule.cluster!+0x39c>
    1488:      	ldr	x8, [x21, #0x30]
    148c:      	ldr	x9, [x21, #0x58]
    1490:      	cmp	x8, x9
    1494:      	b.ne	0x136c <_stogir.checked-schedule.cluster!+0x39c>
    1498:      	asr	x9, x24, #32
    149c:      	cmn	x8, x9
    14a0:      	b.lt	0x136c <_stogir.checked-schedule.cluster!+0x39c>
    14a4:      	ldr	x8, [x21, #0x50]
    14a8:      	mvn	x9, x9
    14ac:      	ldr	w8, [x8, x9, lsl #2]
    14b0:      	cmp	w8, #0x0
    14b4:      	b.le	0x136c <_stogir.checked-schedule.cluster!+0x39c>
    14b8:      	ldr	x8, [x21, #0x28]
    14bc:      	eor	x9, x2, #0xffffffff
    14c0:      	add	x8, x8, x9, lsl #4
    14c4:      	ldr	x8, [x8]
    14c8:      	and	w9, w8, #0xff
    14cc:      	sub	w9, w9, #0x29
    14d0:      	cmp	w9, #0x3
    14d4:      	b.lo	0x1418 <_stogir.checked-schedule.cluster!+0x448>
    14d8:      	tst	x8, #0xff00
    14dc:      	b.eq	0x1508 <_stogir.checked-schedule.cluster!+0x538>
    14e0:      	and	x8, x8, #0xfe00
    14e4:      	cmp	x8, #0xe00
    14e8:      	b.hs	0x1508 <_stogir.checked-schedule.cluster!+0x538>
    14ec:      	stur	wzr, [x29, #-0xc8]
    14f0:      	stur	wzr, [x29, #-0xc0]
    14f4:      	b	0x1390 <_stogir.checked-schedule.cluster!+0x3c0>
    14f8:      	ldp	x9, x8, [x29, #-0xc0]
    14fc:      	str	x9, [sp, #0x48]
    1500:      	str	x8, [sp, #0x38]
    1504:      	b	0x1390 <_stogir.checked-schedule.cluster!+0x3c0>
    1508:      	mov	w8, #0x1                ; =1
    150c:      	adrp	x9, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000150c:  ARM64_RELOC_PAGE21	l_str.408
    1510:      	add	x9, x9, #0x0
		0000000000001510:  ARM64_RELOC_PAGEOFF12	l_str.408
    1514:      	stur	w8, [x29, #-0xc8]
    1518:      	mov	w8, #0x20               ; =32
    151c:      	str	x8, [sp, #0x38]
    1520:      	mov	w8, #0x20               ; =32
    1524:      	str	x9, [sp, #0x48]
    1528:      	stp	x9, x8, [x29, #-0xc0]
    152c:      	b	0x1390 <_stogir.checked-schedule.cluster!+0x3c0>
    1530:      	ldr	x9, [sp, #0x8]
    1534:      	str	w20, [x9, x8, lsl #2]
    1538:      	str	w20, [x23, x8, lsl #2]
    153c:      	mov	w8, #0x1                ; =1
    1540:      	strb	w8, [x25, x26]
    1544:      	b	0x1390 <_stogir.checked-schedule.cluster!+0x3c0>
    1548:      	ldr	x8, [sp, #0x30]
    154c:      	adrp	x22, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000154c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    1550:      	mov	x25, xzr
    1554:      	mov	w27, #0x2               ; =2
    1558:      	ldp	x24, x26, [x8, #0x28]
    155c:      	ldr	x22, [x22]
		000000000000155c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    1560:      	b	0x156c <_stogir.checked-schedule.cluster!+0x59c>
    1564:      	stp	x20, x2, [x29, #-0x90]
    1568:      	stur	x1, [x29, #-0x98]
    156c:      	cmp	x25, x26
    1570:      	b.ge	0x1588 <_stogir.checked-schedule.cluster!+0x5b8>
    1574:      	ldr	w20, [x24, x25, lsl #2]
    1578:      	add	x25, x25, #0x1
    157c:      	mov	w8, #0x1                ; =1
    1580:      	cbnz	w8, 0x1590 <_stogir.checked-schedule.cluster!+0x5c0>
    1584:      	b	0x1664 <_stogir.checked-schedule.cluster!+0x694>
    1588:      	mov	x8, xzr
    158c:      	cbz	w8, 0x1664 <_stogir.checked-schedule.cluster!+0x694>
    1590:      	ldr	x8, [sp, #0xe0]
    1594:      	ldrb	w8, [x8, w20, sxtw]
    1598:      	tbnz	w8, #0x0, 0x156c <_stogir.checked-schedule.cluster!+0x59c>
    159c:      	ldp	x23, x2, [x29, #-0x90]
    15a0:      	cmp	x23, x2
    15a4:      	b.lt	0x15e8 <_stogir.checked-schedule.cluster!+0x618>
    15a8:      	lsl	x8, x2, #1
    15ac:      	cmp	x2, #0x0
    15b0:      	csel	x3, x27, x8, eq
    15b4:      	cmp	x3, x2
    15b8:      	b.le	0x15e8 <_stogir.checked-schedule.cluster!+0x618>
    15bc:      	ldur	x1, [x29, #-0x98]
    15c0:      	add	x0, x19, #0x18
    15c4:      	mov	x4, x22
    15c8:      	mov	w5, #0x4                ; =4
    15cc:      	mov	w6, #0x4                ; =4
    15d0:      	mov	x28, x3
    15d4:      	bl	0x15d4 <_stogir.checked-schedule.cluster!+0x604>
		00000000000015d4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    15d8:      	cbz	w0, 0x1858 <_stogir.checked-schedule.cluster!+0x888>
    15dc:      	mov	x2, x28
    15e0:      	stur	x1, [x29, #-0x98]
    15e4:      	stur	x28, [x29, #-0x88]
    15e8:      	ldur	x1, [x29, #-0x98]
    15ec:      	ldr	x8, [sp, #0x68]
    15f0:      	str	w20, [x1, x23, lsl #2]
    15f4:      	ldr	w28, [x8, w20, sxtw #2]
    15f8:      	add	x20, x23, #0x1
    15fc:      	stur	x20, [x29, #-0x90]
    1600:      	cbnz	w28, 0x161c <_stogir.checked-schedule.cluster!+0x64c>
    1604:      	b	0x1564 <_stogir.checked-schedule.cluster!+0x594>
    1608:      	str	w28, [x1, x20, lsl #2]
    160c:      	add	x20, x20, #0x1
    1610:      	ldr	x8, [sp, #0xb8]
    1614:      	ldr	w28, [x8, w28, sxtw #2]
    1618:      	cbz	w28, 0x1564 <_stogir.checked-schedule.cluster!+0x594>
    161c:      	cmp	x20, x2
    1620:      	b.lt	0x1608 <_stogir.checked-schedule.cluster!+0x638>
    1624:      	lsl	x8, x2, #1
    1628:      	cmp	x2, #0x0
    162c:      	ldur	q0, [x19, #0x18]
    1630:      	csel	x23, x27, x8, eq
    1634:      	stur	q0, [x29, #-0x70]
    1638:      	cmp	x23, x2
    163c:      	b.le	0x1608 <_stogir.checked-schedule.cluster!+0x638>
    1640:      	sub	x0, x29, #0x70
    1644:      	mov	x3, x23
    1648:      	mov	x4, x22
    164c:      	mov	w5, #0x4                ; =4
    1650:      	mov	w6, #0x4                ; =4
    1654:      	bl	0x1654 <_stogir.checked-schedule.cluster!+0x684>
		0000000000001654:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    1658:      	cbz	w0, 0x1838 <_stogir.checked-schedule.cluster!+0x868>
    165c:      	mov	x2, x23
    1660:      	b	0x1608 <_stogir.checked-schedule.cluster!+0x638>
    1664:      	ldr	x25, [sp, #0x30]
    1668:      	ldur	x22, [x29, #-0x90]
    166c:      	ldr	x8, [x25, #0x30]
    1670:      	cmp	x22, x8
    1674:      	b.ne	0x1694 <_stogir.checked-schedule.cluster!+0x6c4>
    1678:      	ldr	x20, [sp, #0x28]
    167c:      	ldr	w23, [sp, #0x24]
    1680:      	ldr	x24, [sp, #0x18]
    1684:      	ldr	x26, [sp, #0x38]
    1688:      	cbz	x26, 0x1804 <_stogir.checked-schedule.cluster!+0x834>
    168c:      	ldr	x21, [sp, #0x48]
    1690:      	b	0x16ac <_stogir.checked-schedule.cluster!+0x6dc>
    1694:      	ldr	x20, [sp, #0x28]
    1698:      	ldr	w23, [sp, #0x24]
    169c:      	adrp	x21, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000169c:  ARM64_RELOC_PAGE21	l_str.386
    16a0:      	add	x21, x21, #0x0
		00000000000016a0:  ARM64_RELOC_PAGEOFF12	l_str.386
    16a4:      	ldr	x24, [sp, #0x18]
    16a8:      	mov	w26, #0x32              ; =50
    16ac:      	ldr	x2, [sp, #0x78]
    16b0:      	str	xzr, [sp, #0x70]
    16b4:      	cmp	x2, #0x1
    16b8:      	b.lt	0x16dc <_stogir.checked-schedule.cluster!+0x70c>
    16bc:      	adrp	x3, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		00000000000016bc:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    16c0:      	ldr	x1, [sp, #0x68]
    16c4:      	add	x8, sp, #0x68
    16c8:      	ldr	x3, [x3]
		00000000000016c8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    16cc:      	add	x0, x8, #0x18
    16d0:      	mov	w4, #0x4                ; =4
    16d4:      	mov	w5, #0x4                ; =4
    16d8:      	bl	0x16d8 <_stogir.checked-schedule.cluster!+0x708>
		00000000000016d8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    16dc:      	ldr	x2, [sp, #0xa0]
    16e0:      	str	xzr, [sp, #0x98]
    16e4:      	cmp	x2, #0x1
    16e8:      	b.lt	0x170c <_stogir.checked-schedule.cluster!+0x73c>
    16ec:      	adrp	x3, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		00000000000016ec:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    16f0:      	ldr	x1, [sp, #0x90]
    16f4:      	add	x8, sp, #0x90
    16f8:      	ldr	x3, [x3]
		00000000000016f8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    16fc:      	add	x0, x8, #0x18
    1700:      	mov	w4, #0x4                ; =4
    1704:      	mov	w5, #0x4                ; =4
    1708:      	bl	0x1708 <_stogir.checked-schedule.cluster!+0x738>
		0000000000001708:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    170c:      	ldr	x2, [sp, #0xc8]
    1710:      	str	xzr, [sp, #0xc0]
    1714:      	cmp	x2, #0x1
    1718:      	b.lt	0x173c <_stogir.checked-schedule.cluster!+0x76c>
    171c:      	adrp	x3, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000171c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    1720:      	ldr	x1, [sp, #0xb8]
    1724:      	add	x8, sp, #0xb8
    1728:      	ldr	x3, [x3]
		0000000000001728:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    172c:      	add	x0, x8, #0x18
    1730:      	mov	w4, #0x4                ; =4
    1734:      	mov	w5, #0x4                ; =4
    1738:      	bl	0x1738 <_stogir.checked-schedule.cluster!+0x768>
		0000000000001738:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    173c:      	ldr	x2, [sp, #0xf0]
    1740:      	str	xzr, [sp, #0xe8]
    1744:      	cmp	x2, #0x1
    1748:      	b.lt	0x176c <_stogir.checked-schedule.cluster!+0x79c>
    174c:      	adrp	x3, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000174c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__bool.0
    1750:      	ldr	x1, [sp, #0xe0]
    1754:      	add	x8, sp, #0xe0
    1758:      	ldr	x3, [x3]
		0000000000001758:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__bool.0
    175c:      	add	x0, x8, #0x18
    1760:      	mov	w4, #0x1                ; =1
    1764:      	mov	w5, #0x1                ; =1
    1768:      	bl	0x1768 <_stogir.checked-schedule.cluster!+0x798>
		0000000000001768:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    176c:      	cbz	x26, 0x17b0 <_stogir.checked-schedule.cluster!+0x7e0>
    1770:      	cbz	x22, 0x1778 <_stogir.checked-schedule.cluster!+0x7a8>
    1774:      	stur	xzr, [x29, #-0x90]
    1778:      	ldur	x2, [x29, #-0x88]
    177c:      	cmp	x2, #0x1
    1780:      	b.lt	0x17a0 <_stogir.checked-schedule.cluster!+0x7d0>
    1784:      	adrp	x3, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001784:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    1788:      	ldur	x1, [x29, #-0x98]
    178c:      	add	x0, x19, #0x18
    1790:      	ldr	x3, [x3]
		0000000000001790:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    1794:      	mov	w4, #0x4                ; =4
    1798:      	mov	w5, #0x4                ; =4
    179c:      	bl	0x179c <_stogir.checked-schedule.cluster!+0x7cc>
		000000000000179c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    17a0:      	mov	w8, #0x1                ; =1
    17a4:      	stp	x21, x26, [x20, #0x8]
    17a8:      	str	w8, [x20]
    17ac:      	b	0x10a4 <_stogir.checked-schedule.cluster!+0xd4>
    17b0:      	ldr	x8, [x25, #0x30]
    17b4:      	cbz	x8, 0x17bc <_stogir.checked-schedule.cluster!+0x7ec>
    17b8:      	str	xzr, [x25, #0x30]
    17bc:      	ldr	x2, [x25, #0x38]
    17c0:      	cmp	x2, #0x1
    17c4:      	b.lt	0x17e4 <_stogir.checked-schedule.cluster!+0x814>
    17c8:      	adrp	x3, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		00000000000017c8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    17cc:      	ldr	x1, [x25, #0x28]
    17d0:      	add	x0, x25, #0x40
    17d4:      	ldr	x3, [x3]
		00000000000017d4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    17d8:      	mov	w4, #0x4                ; =4
    17dc:      	mov	w5, #0x4                ; =4
    17e0:      	bl	0x17e0 <_stogir.checked-schedule.cluster!+0x810>
		00000000000017e0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    17e4:      	add	x8, sp, #0xb8
    17e8:      	str	wzr, [x20]
    17ec:      	ldp	q0, q1, [x8, #0x80]
    17f0:      	ldur	x8, [x29, #-0x78]
    17f4:      	str	w23, [x20, #0x8]
    17f8:      	str	x8, [x24, #0x20]
    17fc:      	stp	q0, q1, [x24]
    1800:      	b	0x10a4 <_stogir.checked-schedule.cluster!+0xd4>
    1804:      	ldur	x2, [x29, #-0x98]
    1808:      	sub	x0, x29, #0xb0
    180c:      	mov	x1, x21
    1810:      	mov	x3, x22
    1814:      	bl	0x1814 <_stogir.checked-schedule.cluster!+0x844>
		0000000000001814:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    1818:      	ldur	w8, [x29, #-0xb0]
    181c:      	cmp	w8, #0x1
    1820:      	b.ne	0x182c <_stogir.checked-schedule.cluster!+0x85c>
    1824:      	ldp	x21, x26, [x29, #-0xa8]
    1828:      	b	0x16ac <_stogir.checked-schedule.cluster!+0x6dc>
    182c:      	ldr	x21, [sp, #0x48]
    1830:      	mov	x26, xzr
    1834:      	b	0x16ac <_stogir.checked-schedule.cluster!+0x6dc>
    1838:      	lsl	x1, x23, #2
    183c:      	adrp	x0, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000183c:  ARM64_RELOC_PAGE21	l_cstr.204
    1840:      	add	x0, x0, #0x0
		0000000000001840:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    1844:      	bl	0x1844 <_stogir.checked-schedule.cluster!+0x874>
		0000000000001844:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    1848:      	lsl	x1, x22, #2
    184c:      	adrp	x0, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000184c:  ARM64_RELOC_PAGE21	l_cstr.204
    1850:      	add	x0, x0, #0x0
		0000000000001850:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    1854:      	bl	0x1854 <_stogir.checked-schedule.cluster!+0x884>
		0000000000001854:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    1858:      	lsl	x1, x28, #2
    185c:      	adrp	x0, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000185c:  ARM64_RELOC_PAGE21	l_cstr.204
    1860:      	add	x0, x0, #0x0
		0000000000001860:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    1864:      	bl	0x1864 <_stogir.checked-schedule.cluster!+0x894>
		0000000000001864:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at

0000000000001868 <_stogir.checked-schedule.validate-nodes>:
    1868:      	sub	sp, sp, #0xa0
    186c:      	stp	x26, x25, [sp, #0x50]
    1870:      	mov	w9, wzr
    1874:      	mov	x25, xzr
    1878:      	stp	x22, x21, [sp, #0x70]
    187c:      	mov	x21, x2
    1880:      	mov	x22, x1
    1884:      	stp	x20, x19, [sp, #0x80]
    1888:      	mov	x20, x3
    188c:      	mov	x19, x0
    1890:      	mov	x8, xzr
    1894:      	adrp	x10, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001894:  ARM64_RELOC_PAGE21	l_str.393
    1898:      	add	x10, x10, #0x0
		0000000000001898:  ARM64_RELOC_PAGEOFF12	l_str.393
    189c:      	adrp	x26, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		000000000000189c:  ARM64_RELOC_PAGE21	l_str.396
    18a0:      	add	x26, x26, #0x0
		00000000000018a0:  ARM64_RELOC_PAGEOFF12	l_str.396
    18a4:      	stp	x28, x27, [sp, #0x40]
    18a8:      	stp	x24, x23, [sp, #0x60]
    18ac:      	stp	x29, x30, [sp, #0x90]
    18b0:      	add	x29, sp, #0x90
    18b4:      	str	wzr, [sp, #0xc]
    18b8:      	b	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    18bc:      	mov	w9, w28
    18c0:      	mov	w8, #0x24               ; =36
    18c4:      	mov	x10, x26
    18c8:      	tbnz	w23, #0x1f, 0x19a8 <_stogir.checked-schedule.validate-nodes+0x140>
    18cc:      	cmp	x25, x20
    18d0:      	mov	x27, x10
    18d4:      	mov	w28, w9
    18d8:      	b.ge	0x18f0 <_stogir.checked-schedule.validate-nodes+0x88>
    18dc:      	ldr	w23, [x21, x25, lsl #2]
    18e0:      	add	x25, x25, #0x1
    18e4:      	mov	w9, #0x1                ; =1
    18e8:      	cbnz	w9, 0x18f8 <_stogir.checked-schedule.validate-nodes+0x90>
    18ec:      	b	0x1aac <_stogir.checked-schedule.validate-nodes+0x244>
    18f0:      	mov	x9, xzr
    18f4:      	cbz	w9, 0x1aac <_stogir.checked-schedule.validate-nodes+0x244>
    18f8:      	mov	w9, w28
    18fc:      	mov	x10, x27
    1900:      	cbnz	x8, 0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1904:      	cmp	w23, #0x1
    1908:      	b.lt	0x18bc <_stogir.checked-schedule.validate-nodes+0x54>
    190c:      	ldr	x8, [x22, #0x8]
    1910:      	and	x11, x23, #0x7fffffff
    1914:      	mov	w9, w28
    1918:      	mov	x10, x26
    191c:      	cmp	x8, x11
    1920:      	mov	w8, #0x24               ; =36
    1924:      	b.le	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1928:      	ldr	x8, [x22, #0x80]
    192c:      	mov	w9, w28
    1930:      	mov	x10, x26
    1934:      	cmp	x8, x11
    1938:      	mov	w8, #0x24               ; =36
    193c:      	b.le	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1940:      	ldr	x8, [x22, #0x78]
    1944:      	mov	w9, w28
    1948:      	mov	x10, x26
    194c:      	ldr	w12, [x8, x11, lsl #2]
    1950:      	mov	w8, #0x24               ; =36
    1954:      	tbnz	w12, #0x1f, 0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1958:      	ldr	x8, [x22]
    195c:      	add	x8, x8, x11, lsl #4
    1960:      	ldr	x24, [x8]
    1964:      	and	w8, w24, #0xff
    1968:      	sub	w8, w8, #0x29
    196c:      	cmp	w8, #0x2
    1970:      	b.hi	0x1a20 <_stogir.checked-schedule.validate-nodes+0x1b8>
    1974:      	add	x0, sp, #0x10
    1978:      	mov	x1, x22
    197c:      	mov	w2, w23
    1980:      	bl	0x1980 <_stogir.checked-schedule.validate-nodes+0x118>
		0000000000001980:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1984:      	ldr	w9, [sp, #0x10]
    1988:      	mov	x8, xzr
    198c:      	mov	x10, x27
    1990:      	cmp	w9, #0x1
    1994:      	mov	w9, w23
    1998:      	b.ne	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    199c:      	ldp	x10, x8, [sp, #0x18]
    19a0:      	mov	w9, w28
    19a4:      	b	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    19a8:      	ldr	x11, [x22, #0x30]
    19ac:      	ldr	x8, [x22, #0x58]
    19b0:      	mov	w9, w28
    19b4:      	mov	x10, x26
    19b8:      	cmp	x11, x8
    19bc:      	mov	w8, #0x24               ; =36
    19c0:      	b.ne	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    19c4:      	sxtw	x12, w23
    19c8:      	mov	w9, w28
    19cc:      	mov	w8, #0x24               ; =36
    19d0:      	mov	x10, x26
    19d4:      	cmn	x11, x12
    19d8:      	b.lt	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    19dc:      	ldr	x8, [x22, #0x50]
    19e0:      	mvn	x9, x12
    19e4:      	mov	x10, x26
    19e8:      	ldr	w8, [x8, x9, lsl #2]
    19ec:      	mov	w9, w28
    19f0:      	cmp	w8, #0x0
    19f4:      	mov	w8, #0x24               ; =36
    19f8:      	b.le	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    19fc:      	mvn	w8, w23
    1a00:      	ldr	x9, [x22, #0x28]
    1a04:      	and	x8, x8, #0x7fffffff
    1a08:      	add	x8, x9, x8, lsl #4
    1a0c:      	ldr	x24, [x8]
    1a10:      	and	w8, w24, #0xff
    1a14:      	sub	w8, w8, #0x29
    1a18:      	cmp	w8, #0x2
    1a1c:      	b.ls	0x1974 <_stogir.checked-schedule.validate-nodes+0x10c>
    1a20:      	and	x10, x24, #0xff
    1a24:      	mov	w9, wzr
    1a28:      	mov	x8, xzr
    1a2c:      	cmp	x10, #0x2c
    1a30:      	mov	x10, x27
    1a34:      	b.ne	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1a38:      	add	x0, sp, #0x28
    1a3c:      	mov	x1, x22
    1a40:      	mov	w2, w23
    1a44:      	bl	0x1a44 <_stogir.checked-schedule.validate-nodes+0x1dc>
		0000000000001a44:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    1a48:      	ldr	w8, [sp, #0x28]
    1a4c:      	cmp	w8, #0x1
    1a50:      	b.ne	0x1a60 <_stogir.checked-schedule.validate-nodes+0x1f8>
    1a54:      	ldp	x10, x8, [sp, #0x30]
    1a58:      	mov	w9, w28
    1a5c:      	b	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1a60:      	ldr	w11, [sp, #0x30]
    1a64:      	mov	w9, wzr
    1a68:      	mov	x8, xzr
    1a6c:      	mov	x10, x27
    1a70:      	cbz	w11, 0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1a74:      	lsr	x8, x24, #32
    1a78:      	mov	w9, w28
    1a7c:      	adrp	x10, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001a7c:  ARM64_RELOC_PAGE21	l_str.395
    1a80:      	add	x10, x10, #0x0
		0000000000001a80:  ARM64_RELOC_PAGEOFF12	l_str.395
    1a84:      	cmp	w28, w8
    1a88:      	mov	w8, #0x35               ; =53
    1a8c:      	b.ne	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1a90:      	ldr	w9, [sp, #0xc]
    1a94:      	mov	x8, xzr
    1a98:      	mov	x10, x27
    1a9c:      	add	w9, w9, #0x1
    1aa0:      	str	w9, [sp, #0xc]
    1aa4:      	mov	w9, w28
    1aa8:      	b	0x18cc <_stogir.checked-schedule.validate-nodes+0x64>
    1aac:      	cbz	x8, 0x1abc <_stogir.checked-schedule.validate-nodes+0x254>
    1ab0:      	mov	w9, #0x1                ; =1
    1ab4:      	stp	x27, x8, [x19, #0x8]
    1ab8:      	b	0x1ac8 <_stogir.checked-schedule.validate-nodes+0x260>
    1abc:      	ldr	w8, [sp, #0xc]
    1ac0:      	mov	w9, wzr
    1ac4:      	str	w8, [x19, #0x8]
    1ac8:      	str	w9, [x19]
    1acc:      	ldp	x29, x30, [sp, #0x90]
    1ad0:      	ldp	x20, x19, [sp, #0x80]
    1ad4:      	ldp	x22, x21, [sp, #0x70]
    1ad8:      	ldp	x24, x23, [sp, #0x60]
    1adc:      	ldp	x26, x25, [sp, #0x50]
    1ae0:      	ldp	x28, x27, [sp, #0x40]
    1ae4:      	add	sp, sp, #0xa0
    1ae8:      	ret

0000000000001aec <_stogir.checked.validate>:
    1aec:      	cmp	w2, #0x1
    1af0:      	b.lt	0x1c78 <_stogir.checked.validate+0x18c>
    1af4:      	ldr	x13, [x1, #0x8]
    1af8:      	mov	w10, w2
    1afc:      	cmp	x13, x10
    1b00:      	b.le	0x1cc8 <_stogir.checked.validate+0x1dc>
    1b04:      	ldr	x14, [x1, #0x80]
    1b08:      	cmp	x14, x10
    1b0c:      	b.le	0x1cc8 <_stogir.checked.validate+0x1dc>
    1b10:      	ldr	x8, [x1, #0x78]
    1b14:      	ldr	w11, [x8, x10, lsl #2]
    1b18:      	tbnz	w11, #0x1f, 0x1cc8 <_stogir.checked.validate+0x1dc>
    1b1c:      	ldr	x9, [x1]
    1b20:      	cmp	w11, #0x2
    1b24:      	add	x12, x9, x10, lsl #4
    1b28:      	ldr	x15, [x12]
    1b2c:      	and	w10, w15, #0xff
    1b30:      	sub	w10, w10, #0x29
    1b34:      	ccmp	w10, #0x3, #0x2, eq
    1b38:      	b.hs	0x1cac <_stogir.checked.validate+0x1c0>
    1b3c:      	sub	sp, sp, #0x10
    1b40:      	ubfx	w10, w15, #8, #8
    1b44:      	lsr	x15, x15, #32
    1b48:      	ldr	x12, [x12, #0x8]
    1b4c:      	mov	w16, #0x36              ; =54
    1b50:      	adrp	x2, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001b50:  ARM64_RELOC_PAGE21	l_str.400
    1b54:      	add	x2, x2, #0x0
		0000000000001b54:  ARM64_RELOC_PAGEOFF12	l_str.400
    1b58:      	sub	w17, w10, #0xc
    1b5c:      	mov	x11, xzr
    1b60:      	stp	w15, w12, [sp, #0x8]
    1b64:      	cmn	w17, #0xa
    1b68:      	adrp	x17, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001b68:  ARM64_RELOC_PAGE21	l_str.401
    1b6c:      	add	x17, x17, #0x0
		0000000000001b6c:  ARM64_RELOC_PAGEOFF12	l_str.401
    1b70:      	csel	x4, x16, xzr, lo
    1b74:      	csel	x5, x17, x2, lo
    1b78:      	cmp	x13, x14
    1b7c:      	add	x12, sp, #0x8
    1b80:      	csel	x13, x13, x14, lt
    1b84:      	adrp	x14, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001b84:  ARM64_RELOC_PAGE21	l_str.402
    1b88:      	add	x14, x14, #0x0
		0000000000001b88:  ARM64_RELOC_PAGEOFF12	l_str.402
    1b8c:      	mov	w15, #0x28              ; =40
    1b90:      	adrp	x16, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001b90:  ARM64_RELOC_PAGE21	l_str.403
    1b94:      	add	x16, x16, #0x0
		0000000000001b94:  ARM64_RELOC_PAGEOFF12	l_str.403
    1b98:      	b	0x1ba8 <_stogir.checked.validate+0xbc>
    1b9c:      	mov	w4, #0x22               ; =34
    1ba0:      	mov	x5, x14
    1ba4:      	tbnz	w3, #0x1f, 0x1c1c <_stogir.checked.validate+0x130>
    1ba8:      	cmp	x11, #0x1
    1bac:      	mov	x17, x5
    1bb0:      	mov	x2, x4
    1bb4:      	b.gt	0x1bcc <_stogir.checked.validate+0xe0>
    1bb8:      	ldr	w3, [x12, x11, lsl #2]
    1bbc:      	add	x11, x11, #0x1
    1bc0:      	mov	w4, #0x1                ; =1
    1bc4:      	cbnz	w4, 0x1bd8 <_stogir.checked.validate+0xec>
    1bc8:      	b	0x1ce4 <_stogir.checked.validate+0x1f8>
    1bcc:      	mov	x4, xzr
    1bd0:      	mov	w11, #0x2               ; =2
    1bd4:      	cbz	w4, 0x1ce4 <_stogir.checked.validate+0x1f8>
    1bd8:      	cmp	w3, #0x1
    1bdc:      	b.lt	0x1b9c <_stogir.checked.validate+0xb0>
    1be0:      	and	x3, x3, #0x7fffffff
    1be4:      	mov	w4, #0x22               ; =34
    1be8:      	mov	x5, x14
    1bec:      	cmp	x3, x13
    1bf0:      	b.ge	0x1ba8 <_stogir.checked.validate+0xbc>
    1bf4:      	ldr	w6, [x8, x3, lsl #2]
    1bf8:      	mov	w4, #0x22               ; =34
    1bfc:      	mov	x5, x14
    1c00:      	tbnz	w6, #0x1f, 0x1ba8 <_stogir.checked.validate+0xbc>
    1c04:      	add	x3, x9, x3, lsl #4
    1c08:      	ldrb	w3, [x3, #0x1]
    1c0c:      	cmp	w3, w10
    1c10:      	csel	x4, x2, x15, eq
    1c14:      	csel	x5, x17, x16, eq
    1c18:      	b	0x1ba8 <_stogir.checked.validate+0xbc>
    1c1c:      	ldr	x6, [x1, #0x30]
    1c20:      	ldr	x4, [x1, #0x58]
    1c24:      	mov	x5, x14
    1c28:      	cmp	x6, x4
    1c2c:      	mov	w4, #0x22               ; =34
    1c30:      	b.ne	0x1ba8 <_stogir.checked.validate+0xbc>
    1c34:      	sxtw	x7, w3
    1c38:      	mov	w4, #0x22               ; =34
    1c3c:      	mov	x5, x14
    1c40:      	cmn	x6, x7
    1c44:      	b.lt	0x1ba8 <_stogir.checked.validate+0xbc>
    1c48:      	ldr	x4, [x1, #0x50]
    1c4c:      	mvn	x5, x7
    1c50:      	ldr	w4, [x4, x5, lsl #2]
    1c54:      	mov	x5, x14
    1c58:      	cmp	w4, #0x0
    1c5c:      	mov	w4, #0x22               ; =34
    1c60:      	b.le	0x1ba8 <_stogir.checked.validate+0xbc>
    1c64:      	mvn	w3, w3
    1c68:      	ldr	x4, [x1, #0x28]
    1c6c:      	and	x3, x3, #0x7fffffff
    1c70:      	add	x3, x4, x3, lsl #4
    1c74:      	b	0x1c08 <_stogir.checked.validate+0x11c>
    1c78:      	tbz	w2, #0x1f, 0x1cc8 <_stogir.checked.validate+0x1dc>
    1c7c:      	ldr	x8, [x1, #0x30]
    1c80:      	ldr	x9, [x1, #0x58]
    1c84:      	cmp	x8, x9
    1c88:      	b.ne	0x1cc8 <_stogir.checked.validate+0x1dc>
    1c8c:      	sxtw	x9, w2
    1c90:      	cmn	x8, x9
    1c94:      	b.lt	0x1cc8 <_stogir.checked.validate+0x1dc>
    1c98:      	ldr	x8, [x1, #0x50]
    1c9c:      	mvn	x9, x9
    1ca0:      	ldr	w8, [x8, x9, lsl #2]
    1ca4:      	cmp	w8, #0x0
    1ca8:      	b.le	0x1cc8 <_stogir.checked.validate+0x1dc>
    1cac:      	mov	w8, #0x1                ; =1
    1cb0:      	adrp	x9, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001cb0:  ARM64_RELOC_PAGE21	l_str.410
    1cb4:      	add	x9, x9, #0x0
		0000000000001cb4:  ARM64_RELOC_PAGEOFF12	l_str.410
    1cb8:      	str	w8, [x0]
    1cbc:      	mov	w8, #0x26               ; =38
    1cc0:      	stp	x9, x8, [x0, #0x8]
    1cc4:      	ret
    1cc8:      	mov	w8, #0x1                ; =1
    1ccc:      	adrp	x9, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001ccc:  ARM64_RELOC_PAGE21	l_str.409
    1cd0:      	add	x9, x9, #0x0
		0000000000001cd0:  ARM64_RELOC_PAGEOFF12	l_str.409
    1cd4:      	str	w8, [x0]
    1cd8:      	mov	w8, #0x1a               ; =26
    1cdc:      	stp	x9, x8, [x0, #0x8]
    1ce0:      	ret
    1ce4:      	add	sp, sp, #0x10
    1ce8:      	cbz	x2, 0x1cfc <_stogir.checked.validate+0x210>
    1cec:      	mov	w8, #0x1                ; =1
    1cf0:      	stp	x17, x2, [x0, #0x8]
    1cf4:      	str	w8, [x0]
    1cf8:      	ret
    1cfc:      	str	w10, [x0, #0x8]
    1d00:      	str	wzr, [x0]
    1d04:      	ret

0000000000001d08 <_stogir.checked.validate-projection>:
    1d08:      	cmp	w2, #0x1
    1d0c:      	b.lt	0x1d98 <_stogir.checked.validate-projection+0x90>
    1d10:      	ldr	x8, [x1, #0x8]
    1d14:      	mov	w12, w2
    1d18:      	cmp	x8, x12
    1d1c:      	b.le	0x1de8 <_stogir.checked.validate-projection+0xe0>
    1d20:      	ldr	x10, [x1, #0x80]
    1d24:      	cmp	x10, x12
    1d28:      	b.le	0x1de8 <_stogir.checked.validate-projection+0xe0>
    1d2c:      	ldr	x9, [x1, #0x78]
    1d30:      	ldr	w13, [x9, x12, lsl #2]
    1d34:      	tbnz	w13, #0x1f, 0x1de8 <_stogir.checked.validate-projection+0xe0>
    1d38:      	ldr	x11, [x1]
    1d3c:      	lsl	x12, x12, #4
    1d40:      	cmp	w13, #0x1
    1d44:      	mov	w13, #0x12c             ; =300
    1d48:      	ldr	x12, [x11, x12]
    1d4c:      	and	x14, x12, #0xffff
    1d50:      	ccmp	x14, x13, #0x0, eq
    1d54:      	b.ne	0x1dcc <_stogir.checked.validate-projection+0xc4>
    1d58:      	lsr	x2, x12, #32
    1d5c:      	cmp	w2, #0x1
    1d60:      	b.lt	0x1e04 <_stogir.checked.validate-projection+0xfc>
    1d64:      	cmp	x8, x2
    1d68:      	b.ls	0x1e88 <_stogir.checked.validate-projection+0x180>
    1d6c:      	cmp	x10, x2
    1d70:      	b.ls	0x1e88 <_stogir.checked.validate-projection+0x180>
    1d74:      	ldr	w8, [x9, x2, lsl #2]
    1d78:      	tbnz	w8, #0x1f, 0x1e88 <_stogir.checked.validate-projection+0x180>
    1d7c:      	add	x8, x11, x2, lsl #4
    1d80:      	ldr	x8, [x8]
    1d84:      	and	w9, w8, #0xff
    1d88:      	sub	w9, w9, #0x29
    1d8c:      	cmp	w9, #0x2
    1d90:      	b.hi	0x1e58 <_stogir.checked.validate-projection+0x150>
    1d94:      	b	0x1d94 <_stogir.checked.validate-projection+0x8c>
		0000000000001d94:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1d98:      	tbz	w2, #0x1f, 0x1de8 <_stogir.checked.validate-projection+0xe0>
    1d9c:      	ldr	x8, [x1, #0x30]
    1da0:      	ldr	x9, [x1, #0x58]
    1da4:      	cmp	x8, x9
    1da8:      	b.ne	0x1de8 <_stogir.checked.validate-projection+0xe0>
    1dac:      	sxtw	x9, w2
    1db0:      	cmn	x8, x9
    1db4:      	b.lt	0x1de8 <_stogir.checked.validate-projection+0xe0>
    1db8:      	ldr	x8, [x1, #0x50]
    1dbc:      	mvn	x9, x9
    1dc0:      	ldr	w8, [x8, x9, lsl #2]
    1dc4:      	cmp	w8, #0x0
    1dc8:      	b.le	0x1de8 <_stogir.checked.validate-projection+0xe0>
    1dcc:      	mov	w8, #0x1                ; =1
    1dd0:      	adrp	x9, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001dd0:  ARM64_RELOC_PAGE21	l_str.412
    1dd4:      	add	x9, x9, #0x0
		0000000000001dd4:  ARM64_RELOC_PAGEOFF12	l_str.412
    1dd8:      	str	w8, [x0]
    1ddc:      	mov	w8, #0x1c               ; =28
    1de0:      	stp	x9, x8, [x0, #0x8]
    1de4:      	ret
    1de8:      	mov	w8, #0x1                ; =1
    1dec:      	adrp	x9, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001dec:  ARM64_RELOC_PAGE21	l_str.411
    1df0:      	add	x9, x9, #0x0
		0000000000001df0:  ARM64_RELOC_PAGEOFF12	l_str.411
    1df4:      	str	w8, [x0]
    1df8:      	mov	w8, #0x10               ; =16
    1dfc:      	stp	x9, x8, [x0, #0x8]
    1e00:      	ret
    1e04:      	tbz	x12, #0x3f, 0x1e88 <_stogir.checked.validate-projection+0x180>
    1e08:      	ldr	x8, [x1, #0x30]
    1e0c:      	ldr	x9, [x1, #0x58]
    1e10:      	cmp	x8, x9
    1e14:      	b.ne	0x1e88 <_stogir.checked.validate-projection+0x180>
    1e18:      	asr	x9, x12, #32
    1e1c:      	cmn	x8, x9
    1e20:      	b.lt	0x1e88 <_stogir.checked.validate-projection+0x180>
    1e24:      	ldr	x8, [x1, #0x50]
    1e28:      	mvn	x9, x9
    1e2c:      	ldr	w8, [x8, x9, lsl #2]
    1e30:      	cmp	w8, #0x0
    1e34:      	b.le	0x1e88 <_stogir.checked.validate-projection+0x180>
    1e38:      	ldr	x8, [x1, #0x28]
    1e3c:      	eor	x9, x2, #0xffffffff
    1e40:      	add	x8, x8, x9, lsl #4
    1e44:      	ldr	x8, [x8]
    1e48:      	and	w9, w8, #0xff
    1e4c:      	sub	w9, w9, #0x29
    1e50:      	cmp	w9, #0x2
    1e54:      	b.ls	0x1d94 <_stogir.checked.validate-projection+0x8c>
    1e58:      	and	x9, x8, #0xfe00
    1e5c:      	and	x8, x8, #0xff00
    1e60:      	cmp	x9, #0xdff
    1e64:      	ccmp	x8, #0x0, #0x4, ls
    1e68:      	b.ne	0x1ea4 <_stogir.checked.validate-projection+0x19c>
    1e6c:      	mov	w8, #0x1                ; =1
    1e70:      	adrp	x9, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001e70:  ARM64_RELOC_PAGE21	l_str.408
    1e74:      	add	x9, x9, #0x0
		0000000000001e74:  ARM64_RELOC_PAGEOFF12	l_str.408
    1e78:      	str	w8, [x0]
    1e7c:      	mov	w8, #0x20               ; =32
    1e80:      	stp	x9, x8, [x0, #0x8]
    1e84:      	ret
    1e88:      	mov	w8, #0x1                ; =1
    1e8c:      	adrp	x9, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001e8c:  ARM64_RELOC_PAGE21	l_str.407
    1e90:      	add	x9, x9, #0x0
		0000000000001e90:  ARM64_RELOC_PAGEOFF12	l_str.407
    1e94:      	str	w8, [x0]
    1e98:      	mov	w8, #0x17               ; =23
    1e9c:      	stp	x9, x8, [x0, #0x8]
    1ea0:      	ret
    1ea4:      	str	wzr, [x0]
    1ea8:      	str	wzr, [x0, #0x8]
    1eac:      	ret

0000000000001eb0 <_stogir.loops.depths>:
    1eb0:      	stp	x28, x27, [sp, #-0x60]!
    1eb4:      	stp	x26, x25, [sp, #0x10]
    1eb8:      	stp	x24, x23, [sp, #0x20]
    1ebc:      	stp	x22, x21, [sp, #0x30]
    1ec0:      	stp	x20, x19, [sp, #0x40]
    1ec4:      	stp	x29, x30, [sp, #0x50]
    1ec8:      	add	x29, sp, #0x50
    1ecc:      	sub	sp, sp, #0x1a0
    1ed0:      	sub	x8, x29, #0xd8
    1ed4:      	ldr	x20, [x3, #0x8]
    1ed8:      	ldr	q1, [x4]
    1edc:      	stur	x0, [x8, #-0x100]
    1ee0:      	sub	x8, x29, #0x80
    1ee4:      	ldr	q0, [x4]
    1ee8:      	stur	x3, [x8, #-0x100]
    1eec:      	sub	x8, x29, #0x8
    1ef0:      	mov	x27, x4
    1ef4:      	stur	xzr, [x8, #-0x100]
    1ef8:      	sub	x8, x29, #0x70
    1efc:      	mov	x21, x2
    1f00:      	mov	x22, x1
    1f04:      	sub	x9, x29, #0xc8
    1f08:      	stur	q1, [x8, #-0x100]
    1f0c:      	cmp	x20, #0x1
    1f10:      	sub	x8, x29, #0x90
    1f14:      	stp	xzr, xzr, [x29, #-0xc0]
    1f18:      	stur	xzr, [x29, #-0xc8]
    1f1c:      	stp	q0, q0, [x29, #-0xf0]
    1f20:      	stur	q0, [x9, #0x18]
    1f24:      	stp	xzr, xzr, [x29, #-0x98]
    1f28:      	stur	xzr, [x29, #-0xa0]
    1f2c:      	stur	q0, [x9, #0x40]
    1f30:      	stp	xzr, xzr, [x29, #-0x100]
    1f34:      	stur	x20, [x8, #-0x100]
    1f38:      	b.lt	0x2074 <_stogir.loops.depths+0x1c4>
    1f3c:      	ldr	q0, [x27]
    1f40:      	adrp	x4, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001f40:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    1f44:      	mov	x23, x20
    1f48:      	sub	x0, x29, #0x70
    1f4c:      	mov	x1, xzr
    1f50:      	mov	x2, xzr
    1f54:      	stur	q0, [x9, #0x58]
    1f58:      	mov	x3, x23
    1f5c:      	mov	w5, #0x4                ; =4
    1f60:      	ldr	x4, [x4]
		0000000000001f60:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    1f64:      	mov	w6, #0x4                ; =4
    1f68:      	sub	x20, x29, #0xc8
    1f6c:      	bl	0x1f6c <_stogir.loops.depths+0xbc>
		0000000000001f6c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    1f70:      	lsl	x19, x23, #2
    1f74:      	cbz	w0, 0x29fc <_stogir.loops.depths+0xb4c>
    1f78:      	mov	x25, x1
    1f7c:      	mov	x0, x1
    1f80:      	mov	x1, x19
    1f84:      	bl	0x1f84 <_stogir.loops.depths+0xd4>
		0000000000001f84:  ARM64_RELOC_BRANCH26	_bzero
    1f88:      	adrp	x4, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001f88:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    1f8c:      	sub	x0, x29, #0xe0
    1f90:      	mov	x1, xzr
    1f94:      	ldr	x4, [x4]
		0000000000001f94:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    1f98:      	mov	x2, xzr
    1f9c:      	mov	x3, x23
    1fa0:      	mov	w5, #0x4                ; =4
    1fa4:      	mov	w6, #0x4                ; =4
    1fa8:      	bl	0x1fa8 <_stogir.loops.depths+0xf8>
		0000000000001fa8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    1fac:      	cbz	w0, 0x29fc <_stogir.loops.depths+0xb4c>
    1fb0:      	sub	x8, x29, #0xa0
    1fb4:      	mov	x0, x1
    1fb8:      	stur	x1, [x8, #-0x100]
    1fbc:      	mov	x1, x19
    1fc0:      	bl	0x1fc0 <_stogir.loops.depths+0x110>
		0000000000001fc0:  ARM64_RELOC_BRANCH26	_bzero
    1fc4:      	adrp	x4, 0x1000 <_stogir.checked-schedule.cluster!+0x30>
		0000000000001fc4:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    1fc8:      	add	x0, x20, #0x18
    1fcc:      	mov	x1, xzr
    1fd0:      	ldr	x4, [x4]
		0000000000001fd0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    1fd4:      	mov	x2, xzr
    1fd8:      	mov	x3, x23
    1fdc:      	mov	w5, #0x4                ; =4
    1fe0:      	mov	w6, #0x4                ; =4
    1fe4:      	bl	0x1fe4 <_stogir.loops.depths+0x134>
		0000000000001fe4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    1fe8:      	cbz	w0, 0x29fc <_stogir.loops.depths+0xb4c>
    1fec:      	mov	x26, x1
    1ff0:      	mov	x20, x23
    1ff4:      	stur	x1, [x29, #-0xc8]
    1ff8:      	mov	x0, x1
    1ffc:      	mov	x1, x19
    2000:      	sub	x23, x29, #0xa0
    2004:      	stur	x20, [x29, #-0xb8]
    2008:      	bl	0x2008 <_stogir.loops.depths+0x158>
		0000000000002008:  ARM64_RELOC_BRANCH26	_bzero
    200c:      	stur	x20, [x29, #-0xc0]
    2010:      	adrp	x4, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002010:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2014:      	add	x0, x23, #0x18
    2018:      	ldr	x4, [x4]
		0000000000002018:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    201c:      	mov	x1, xzr
    2020:      	mov	x2, xzr
    2024:      	mov	x3, x20
    2028:      	mov	w5, #0x4                ; =4
    202c:      	mov	w6, #0x4                ; =4
    2030:      	bl	0x2030 <_stogir.loops.depths+0x180>
		0000000000002030:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    2034:      	cbz	w0, 0x29fc <_stogir.loops.depths+0xb4c>
    2038:      	mov	x28, x1
    203c:      	stur	x1, [x29, #-0xa0]
    2040:      	mov	x0, x1
    2044:      	mov	x1, x19
    2048:      	stur	x20, [x29, #-0x90]
    204c:      	bl	0x204c <_stogir.loops.depths+0x19c>
		000000000000204c:  ARM64_RELOC_BRANCH26	_bzero
    2050:      	cmp	x20, #0x1
    2054:      	stur	x20, [x29, #-0x98]
    2058:      	b.ne	0x2768 <_stogir.loops.depths+0x8b8>
    205c:      	sub	x8, x29, #0x8
    2060:      	mov	w2, #0x1                ; =1
    2064:      	stp	xzr, xzr, [x29, #-0x100]
    2068:      	stur	xzr, [x8, #-0x100]
    206c:      	stur	xzr, [x29, #-0x98]
    2070:      	b	0x299c <_stogir.loops.depths+0xaec>
    2074:      	mov	x8, xzr
    2078:      	mov	x25, xzr
    207c:      	mov	x19, xzr
    2080:      	stur	x20, [x29, #-0xc0]
    2084:      	cbnz	x20, 0x29c8 <_stogir.loops.depths+0xb18>
    2088:      	ldur	x2, [x29, #-0xb8]
    208c:      	sub	x10, x29, #0xa0
    2090:      	stur	x8, [x10, #-0x100]
    2094:      	cmp	x2, #0x1
    2098:      	b.lt	0x20c4 <_stogir.loops.depths+0x214>
    209c:      	adrp	x3, 0x2000 <_stogir.loops.depths+0x150>
		000000000000209c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    20a0:      	ldur	x1, [x29, #-0xc8]
    20a4:      	add	x0, x9, #0x18
    20a8:      	ldr	x3, [x3]
		00000000000020a8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    20ac:      	mov	w4, #0x4                ; =4
    20b0:      	mov	w5, #0x4                ; =4
    20b4:      	bl	0x20b4 <_stogir.loops.depths+0x204>
		00000000000020b4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    20b8:      	sub	x8, x29, #0xa0
    20bc:      	sub	x9, x29, #0xc8
    20c0:      	ldur	x8, [x8, #-0x100]
    20c4:      	sub	x10, x29, #0x58
    20c8:      	stur	x25, [x10, #-0x100]
    20cc:      	sub	x10, x29, #0x50
    20d0:      	stur	x20, [x10, #-0x100]
    20d4:      	sub	x10, x29, #0x48
    20d8:      	stur	x19, [x10, #-0x100]
    20dc:      	sub	x10, x29, #0x70
    20e0:      	ldur	q0, [x10, #-0x100]
    20e4:      	sub	x10, x29, #0x40
    20e8:      	stur	q0, [x10, #-0x100]
    20ec:      	sub	x10, x29, #0x30
    20f0:      	ldur	q0, [x29, #-0xe0]
    20f4:      	stur	x8, [x10, #-0x100]
    20f8:      	sub	x8, x29, #0x28
    20fc:      	stur	x20, [x8, #-0x100]
    2100:      	sub	x8, x29, #0xe0
    2104:      	stur	x19, [x8, #-0x100]
    2108:      	sub	x8, x29, #0x20
    210c:      	stur	x19, [x8, #-0x100]
    2110:      	sub	x8, x29, #0x18
    2114:      	stur	q0, [x8, #-0x100]
    2118:      	mov	x8, sp
    211c:      	sub	x10, x8, #0x30
    2120:      	mov	sp, x10
    2124:      	ldr	q0, [x27]
    2128:      	mov	x24, sp
    212c:      	stp	xzr, xzr, [x8, #-0x30]
    2130:      	stur	xzr, [x8, #-0x20]
    2134:      	sub	x11, x24, #0x30
    2138:      	sub	x12, x29, #0xb0
    213c:      	stur	q0, [x8, #-0x18]
    2140:      	sub	x8, x24, #0x30
    2144:      	stur	x8, [x12, #-0x100]
    2148:      	mov	sp, x11
    214c:      	ldr	q0, [x27]
    2150:      	mov	x23, sp
    2154:      	sub	x12, x29, #0xc8
    2158:      	sub	x11, x23, #0x30
    215c:      	sub	x8, x23, #0x30
    2160:      	stp	xzr, xzr, [x24, #-0x30]
    2164:      	stur	xzr, [x24, #-0x20]
    2168:      	stur	q0, [x24, #-0x18]
    216c:      	stur	x8, [x12, #-0x100]
    2170:      	mov	sp, x11
    2174:      	ldr	x19, [x22, #0x30]
    2178:      	ldr	q0, [x27]
    217c:      	sub	x8, x29, #0x88
    2180:      	stp	xzr, xzr, [x23, #-0x30]
    2184:      	lsl	x28, x19, #2
    2188:      	cmp	x19, #0x1
    218c:      	stur	xzr, [x23, #-0x20]
    2190:      	stur	q0, [x23, #-0x18]
    2194:      	stur	x10, [x8, #-0x100]
    2198:      	b.lt	0x21e8 <_stogir.loops.depths+0x338>
    219c:      	ldr	q0, [x27]
    21a0:      	adrp	x4, 0x2000 <_stogir.loops.depths+0x150>
		00000000000021a0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    21a4:      	sub	x0, x29, #0xa0
    21a8:      	mov	x1, xzr
    21ac:      	mov	x2, xzr
    21b0:      	mov	x3, x19
    21b4:      	stur	q0, [x9, #0x28]
    21b8:      	mov	w5, #0x4                ; =4
    21bc:      	mov	w6, #0x4                ; =4
    21c0:      	ldr	x4, [x4]
		00000000000021c0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    21c4:      	bl	0x21c4 <_stogir.loops.depths+0x314>
		00000000000021c4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    21c8:      	mov	x8, x0
    21cc:      	cbz	w8, 0x2a24 <_stogir.loops.depths+0xb74>
    21d0:      	sub	x8, x29, #0x88
    21d4:      	mov	x0, x1
    21d8:      	ldur	x27, [x8, #-0x100]
    21dc:      	str	x1, [x27]
    21e0:      	str	x19, [x27, #0x10]
    21e4:      	b	0x21f0 <_stogir.loops.depths+0x340>
    21e8:      	mov	x0, xzr
    21ec:      	mov	x27, x10
    21f0:      	mov	x1, x28
    21f4:      	sub	x24, x24, #0x18
    21f8:      	bl	0x21f8 <_stogir.loops.depths+0x348>
		00000000000021f8:  ARM64_RELOC_BRANCH26	_bzero
    21fc:      	ldr	x26, [x22, #0x30]
    2200:      	sub	x8, x29, #0xe8
    2204:      	str	x19, [x27, #0x8]
    2208:      	stur	x24, [x8, #-0x100]
    220c:      	lsl	x28, x26, #2
    2210:      	cmp	x26, #0x1
    2214:      	b.lt	0x225c <_stogir.loops.depths+0x3ac>
    2218:      	adrp	x4, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002218:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    221c:      	mov	x0, x24
    2220:      	mov	x1, xzr
    2224:      	ldr	x4, [x4]
		0000000000002224:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    2228:      	mov	x2, xzr
    222c:      	mov	x3, x26
    2230:      	mov	w5, #0x4                ; =4
    2234:      	mov	w6, #0x4                ; =4
    2238:      	bl	0x2238 <_stogir.loops.depths+0x388>
		0000000000002238:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    223c:      	sub	x9, x29, #0xb0
    2240:      	mov	x8, x0
    2244:      	ldur	x24, [x9, #-0x100]
    2248:      	cbz	w8, 0x2a24 <_stogir.loops.depths+0xb74>
    224c:      	mov	x0, x1
    2250:      	str	x1, [x24]
    2254:      	str	x26, [x24, #0x10]
    2258:      	b	0x2268 <_stogir.loops.depths+0x3b8>
    225c:      	sub	x8, x29, #0xb0
    2260:      	mov	x0, xzr
    2264:      	ldur	x24, [x8, #-0x100]
    2268:      	sub	x8, x23, #0x18
    226c:      	sub	x9, x29, #0x70
    2270:      	mov	x1, x28
    2274:      	stur	x8, [x9, #-0x100]
    2278:      	bl	0x2278 <_stogir.loops.depths+0x3c8>
		0000000000002278:  ARM64_RELOC_BRANCH26	_bzero
    227c:      	mov	x9, sp
    2280:      	sub	x11, x29, #0x98
    2284:      	str	x26, [x24, #0x8]
    2288:      	sub	x10, x9, #0x20
    228c:      	sub	x8, x9, #0x20
    2290:      	stur	x8, [x11, #-0x100]
    2294:      	mov	sp, x10
    2298:      	ldp	x10, x11, [x22]
    229c:      	sub	x12, x29, #0xc0
    22a0:      	stur	xzr, [x9, #-0x10]
    22a4:      	mov	x8, xzr
    22a8:      	mov	w16, #0x2               ; =2
    22ac:      	sub	x13, x29, #0xc8
    22b0:      	stp	x10, x11, [x9, #-0x20]
    22b4:      	sub	x9, x29, #0x80
    22b8:      	stur	x10, [x12, #-0x100]
    22bc:      	ldur	x12, [x9, #-0x100]
    22c0:      	sub	x9, x29, #0x88
    22c4:      	ldur	x14, [x9, #-0x100]
    22c8:      	sub	x9, x29, #0xc8
    22cc:      	sub	x10, x29, #0xb8
    22d0:      	ldur	x15, [x9, #-0x100]
    22d4:      	sub	x9, x29, #0xa8
    22d8:      	stur	x11, [x10, #-0x100]
    22dc:      	stur	x25, [x9, #-0x100]
    22e0:      	b	0x2308 <_stogir.loops.depths+0x458>
    22e4:      	sub	x8, x29, #0x98
    22e8:      	sub	x9, x29, #0x90
    22ec:      	ldur	x8, [x8, #-0x100]
    22f0:      	ldur	x20, [x9, #-0x100]
    22f4:      	sub	x9, x29, #0xa8
    22f8:      	ldur	x25, [x9, #-0x100]
    22fc:      	sub	x9, x29, #0xb0
    2300:      	ldr	x8, [x8, #0x10]
    2304:      	ldur	x24, [x9, #-0x100]
    2308:      	sub	x9, x29, #0xb8
    230c:      	ldur	x9, [x9, #-0x100]
    2310:      	cmp	x8, x9
    2314:      	b.ge	0x2340 <_stogir.loops.depths+0x490>
    2318:      	sub	x10, x29, #0xc0
    231c:      	add	x9, x8, #0x1
    2320:      	ldur	x10, [x10, #-0x100]
    2324:      	ldr	w19, [x10, x8, lsl #2]
    2328:      	sub	x8, x29, #0x98
    232c:      	ldur	x8, [x8, #-0x100]
    2330:      	str	x9, [x8, #0x10]
    2334:      	mov	w8, #0x1                ; =1
    2338:      	cbnz	w8, 0x2348 <_stogir.loops.depths+0x498>
    233c:      	b	0x2624 <_stogir.loops.depths+0x774>
    2340:      	mov	x8, xzr
    2344:      	cbz	w8, 0x2624 <_stogir.loops.depths+0x774>
    2348:      	ldr	x23, [x24]
    234c:      	str	xzr, [x15, #0x8]
    2350:      	str	w19, [x23, w19, sxtw #2]
    2354:      	ldr	x8, [x21]
    2358:      	add	x9, x8, w19, sxtw #4
    235c:      	ldr	x26, [x9, #0x8]
    2360:      	cmp	x26, #0x1
    2364:      	b.lt	0x22e4 <_stogir.loops.depths+0x434>
    2368:      	sub	x8, x29, #0x90
    236c:      	and	x17, x19, #0x7fffffff
    2370:      	ldur	x8, [x8, #-0x100]
    2374:      	cmp	x8, x17
    2378:      	ccmp	w19, #0x1, #0x8, gt
    237c:      	b.lt	0x22e4 <_stogir.loops.depths+0x434>
    2380:      	ldr	x9, [x9]
    2384:      	ldr	x0, [x14]
    2388:      	mov	w8, wzr
    238c:      	ldr	x1, [x15]
    2390:      	mov	x27, xzr
    2394:      	lsl	x28, x9, #3
    2398:      	sub	x9, x29, #0x90
    239c:      	ldur	x20, [x9, #-0x100]
    23a0:      	sub	x9, x29, #0xa8
    23a4:      	ldur	x25, [x9, #-0x100]
    23a8:      	b	0x23c8 <_stogir.loops.depths+0x518>
    23ac:      	str	w24, [x1, x27, lsl #2]
    23b0:      	add	x27, x27, #0x1
    23b4:      	str	x27, [x15, #0x8]
    23b8:      	mov	w8, #0x1                ; =1
    23bc:      	subs	x26, x26, #0x1
    23c0:      	add	x28, x28, #0x8
    23c4:      	b.eq	0x24e8 <_stogir.loops.depths+0x638>
    23c8:      	ldr	x9, [x21, #0x28]
    23cc:      	ldr	x10, [x22, #0x50]
    23d0:      	ldr	x9, [x9, x28]
    23d4:      	lsl	x9, x9, #4
    23d8:      	ldr	x24, [x10, x9]
    23dc:      	cmp	w24, #0x1
    23e0:      	and	x9, x24, #0x7fffffff
    23e4:      	ccmp	x20, x9, #0x0, ge
    23e8:      	b.ls	0x23bc <_stogir.loops.depths+0x50c>
    23ec:      	ldr	w10, [x25, x17, lsl #2]
    23f0:      	cmp	w10, #0x1
    23f4:      	b.lt	0x23bc <_stogir.loops.depths+0x50c>
    23f8:      	ldr	w11, [x25, x9, lsl #2]
    23fc:      	cmp	w11, #0x1
    2400:      	ccmp	w10, w11, #0x2, ge
    2404:      	b.hi	0x23bc <_stogir.loops.depths+0x50c>
    2408:      	sub	x10, x29, #0xa0
    240c:      	ldur	x11, [x10, #-0x100]
    2410:      	ldr	w10, [x11, x17, lsl #2]
    2414:      	ldr	w11, [x11, x9, lsl #2]
    2418:      	cmp	w10, w11
    241c:      	b.lt	0x23bc <_stogir.loops.depths+0x50c>
    2420:      	tbnz	w8, #0x0, 0x2430 <_stogir.loops.depths+0x580>
    2424:      	ldr	w8, [x0, w19, sxtw #2]
    2428:      	add	w8, w8, #0x1
    242c:      	str	w8, [x0, w19, sxtw #2]
    2430:      	ldr	w8, [x23, x9, lsl #2]
    2434:      	cmp	w8, w19
    2438:      	b.eq	0x23b8 <_stogir.loops.depths+0x508>
    243c:      	str	w19, [x23, x9, lsl #2]
    2440:      	ldr	x2, [x15, #0x10]
    2444:      	ldr	w8, [x0, x9, lsl #2]
    2448:      	cmp	x27, x2
    244c:      	add	w8, w8, #0x1
    2450:      	str	w8, [x0, x9, lsl #2]
    2454:      	b.lt	0x23ac <_stogir.loops.depths+0x4fc>
    2458:      	lsl	x8, x2, #1
    245c:      	cmp	x2, #0x0
    2460:      	csel	x3, x16, x8, eq
    2464:      	sub	x8, x29, #0x70
    2468:      	ldur	x8, [x8, #-0x100]
    246c:      	cmp	x3, x2
    2470:      	ldr	q0, [x8]
    2474:      	stur	q0, [x13, #0x28]
    2478:      	b.le	0x23ac <_stogir.loops.depths+0x4fc>
    247c:      	sub	x8, x29, #0xd0
    2480:      	adrp	x4, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002480:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2484:      	mov	w5, #0x4                ; =4
    2488:      	stur	x0, [x8, #-0x100]
    248c:      	sub	x8, x29, #0x78
    2490:      	sub	x0, x29, #0xa0
    2494:      	stur	x3, [x8, #-0x100]
    2498:      	mov	w6, #0x4                ; =4
    249c:      	ldr	x4, [x4]
		000000000000249c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    24a0:      	bl	0x24a0 <_stogir.loops.depths+0x5f0>
		00000000000024a0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    24a4:      	cbz	w0, 0x2a0c <_stogir.loops.depths+0xb5c>
    24a8:      	sub	x8, x29, #0xc8
    24ac:      	sub	x13, x29, #0xc8
    24b0:      	mov	w16, #0x2               ; =2
    24b4:      	ldur	x15, [x8, #-0x100]
    24b8:      	sub	x8, x29, #0x78
    24bc:      	and	x17, x19, #0x7fffffff
    24c0:      	ldur	x8, [x8, #-0x100]
    24c4:      	str	x1, [x15]
    24c8:      	str	x8, [x15, #0x10]
    24cc:      	sub	x8, x29, #0x80
    24d0:      	ldur	x12, [x8, #-0x100]
    24d4:      	sub	x8, x29, #0x88
    24d8:      	ldur	x14, [x8, #-0x100]
    24dc:      	sub	x8, x29, #0xd0
    24e0:      	ldur	x0, [x8, #-0x100]
    24e4:      	b	0x23ac <_stogir.loops.depths+0x4fc>
    24e8:      	cmp	x27, #0x0
    24ec:      	cset	w9, gt
    24f0:      	tst	w8, w9
    24f4:      	b.eq	0x22e4 <_stogir.loops.depths+0x434>
    24f8:      	ldr	x1, [x15]
    24fc:      	mov	x8, xzr
    2500:      	b	0x251c <_stogir.loops.depths+0x66c>
    2504:      	sub	x8, x29, #0x78
    2508:      	stp	x1, x27, [x15]
    250c:      	ldur	x8, [x8, #-0x100]
    2510:      	add	x8, x8, #0x1
    2514:      	cmp	x8, x27
    2518:      	b.ge	0x22e4 <_stogir.loops.depths+0x434>
    251c:      	sub	x9, x29, #0x78
    2520:      	stur	x8, [x9, #-0x100]
    2524:      	ldrsw	x8, [x1, x8, lsl #2]
    2528:      	ldr	x9, [x21]
    252c:      	add	x8, x9, x8, lsl #4
    2530:      	ldr	x25, [x8, #0x8]
    2534:      	cmp	x25, #0x1
    2538:      	b.lt	0x2504 <_stogir.loops.depths+0x654>
    253c:      	ldr	x8, [x8]
    2540:      	lsl	x24, x8, #3
    2544:      	b	0x255c <_stogir.loops.depths+0x6ac>
    2548:      	str	w20, [x1, x27, lsl #2]
    254c:      	add	x27, x27, #0x1
    2550:      	subs	x25, x25, #0x1
    2554:      	add	x24, x24, #0x8
    2558:      	b.eq	0x2504 <_stogir.loops.depths+0x654>
    255c:      	ldr	x8, [x21, #0x28]
    2560:      	ldr	x9, [x22, #0x50]
    2564:      	ldr	x8, [x8, x24]
    2568:      	lsl	x8, x8, #4
    256c:      	ldr	x20, [x9, x8]
    2570:      	ldr	x8, [x12]
    2574:      	ldr	w8, [x8, w20, sxtw #2]
    2578:      	cbz	w8, 0x2550 <_stogir.loops.depths+0x6a0>
    257c:      	ldr	w8, [x23, w20, sxtw #2]
    2580:      	cmp	w8, w19
    2584:      	b.eq	0x2550 <_stogir.loops.depths+0x6a0>
    2588:      	ldr	x8, [x14]
    258c:      	str	w19, [x23, w20, sxtw #2]
    2590:      	ldr	x2, [x15, #0x10]
    2594:      	ldr	w9, [x8, w20, sxtw #2]
    2598:      	cmp	x27, x2
    259c:      	add	w9, w9, #0x1
    25a0:      	str	w9, [x8, w20, sxtw #2]
    25a4:      	b.lt	0x2548 <_stogir.loops.depths+0x698>
    25a8:      	lsl	x8, x2, #1
    25ac:      	cmp	x2, #0x0
    25b0:      	csel	x26, x16, x8, eq
    25b4:      	sub	x8, x29, #0x70
    25b8:      	ldur	x8, [x8, #-0x100]
    25bc:      	cmp	x26, x2
    25c0:      	ldr	q0, [x8]
    25c4:      	stur	q0, [x13, #0x28]
    25c8:      	b.le	0x2548 <_stogir.loops.depths+0x698>
    25cc:      	adrp	x4, 0x2000 <_stogir.loops.depths+0x150>
		00000000000025cc:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    25d0:      	sub	x0, x29, #0xa0
    25d4:      	mov	x3, x26
    25d8:      	ldr	x4, [x4]
		00000000000025d8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    25dc:      	mov	w5, #0x4                ; =4
    25e0:      	mov	w6, #0x4                ; =4
    25e4:      	mov	x28, x21
    25e8:      	mov	x21, x22
    25ec:      	mov	x22, x15
    25f0:      	bl	0x25f0 <_stogir.loops.depths+0x740>
		00000000000025f0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    25f4:      	cbz	w0, 0x29ec <_stogir.loops.depths+0xb3c>
    25f8:      	sub	x8, x29, #0x80
    25fc:      	mov	x15, x22
    2600:      	str	x26, [x22, #0x10]
    2604:      	ldur	x12, [x8, #-0x100]
    2608:      	sub	x8, x29, #0x88
    260c:      	sub	x13, x29, #0xc8
    2610:      	ldur	x14, [x8, #-0x100]
    2614:      	mov	x22, x21
    2618:      	mov	x21, x28
    261c:      	mov	w16, #0x2               ; =2
    2620:      	b	0x2548 <_stogir.loops.depths+0x698>
    2624:      	cbz	x20, 0x2630 <_stogir.loops.depths+0x780>
    2628:      	sub	x8, x29, #0x50
    262c:      	stur	xzr, [x8, #-0x100]
    2630:      	sub	x8, x29, #0xe0
    2634:      	sub	x21, x29, #0x158
    2638:      	ldur	x19, [x8, #-0x100]
    263c:      	cmp	x19, #0x1
    2640:      	b.lt	0x266c <_stogir.loops.depths+0x7bc>
    2644:      	adrp	x3, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002644:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2648:      	add	x0, x21, #0x18
    264c:      	mov	x1, x25
    2650:      	ldr	x3, [x3]
		0000000000002650:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    2654:      	mov	x2, x19
    2658:      	mov	w4, #0x4                ; =4
    265c:      	mov	w5, #0x4                ; =4
    2660:      	mov	x20, x15
    2664:      	bl	0x2664 <_stogir.loops.depths+0x7b4>
		0000000000002664:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    2668:      	mov	x15, x20
    266c:      	sub	x8, x29, #0x50
    2670:      	cmp	x19, #0x1
    2674:      	stur	xzr, [x8, #-0x100]
    2678:      	sub	x8, x29, #0x58
    267c:      	stur	xzr, [x8, #-0x100]
    2680:      	sub	x8, x29, #0x48
    2684:      	stur	xzr, [x8, #-0x100]
    2688:      	sub	x8, x29, #0x28
    268c:      	stur	xzr, [x8, #-0x100]
    2690:      	b.lt	0x26c0 <_stogir.loops.depths+0x810>
    2694:      	adrp	x3, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002694:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2698:      	sub	x8, x29, #0xa0
    269c:      	add	x0, x21, #0x40
    26a0:      	ldr	x3, [x3]
		00000000000026a0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    26a4:      	ldur	x1, [x8, #-0x100]
    26a8:      	mov	x2, x19
    26ac:      	mov	w4, #0x4                ; =4
    26b0:      	mov	w5, #0x4                ; =4
    26b4:      	mov	x19, x15
    26b8:      	bl	0x26b8 <_stogir.loops.depths+0x808>
		00000000000026b8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    26bc:      	mov	x15, x19
    26c0:      	ldr	x2, [x24, #0x10]
    26c4:      	str	xzr, [x24, #0x8]
    26c8:      	cmp	x2, #0x1
    26cc:      	b.lt	0x26f8 <_stogir.loops.depths+0x848>
    26d0:      	adrp	x3, 0x2000 <_stogir.loops.depths+0x150>
		00000000000026d0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    26d4:      	sub	x8, x29, #0xe8
    26d8:      	ldr	x1, [x24]
    26dc:      	ldr	x3, [x3]
		00000000000026dc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    26e0:      	ldur	x0, [x8, #-0x100]
    26e4:      	mov	w4, #0x4                ; =4
    26e8:      	mov	w5, #0x4                ; =4
    26ec:      	mov	x19, x15
    26f0:      	bl	0x26f0 <_stogir.loops.depths+0x840>
		00000000000026f0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    26f4:      	mov	x15, x19
    26f8:      	ldr	x2, [x15, #0x10]
    26fc:      	str	xzr, [x15, #0x8]
    2700:      	cmp	x2, #0x1
    2704:      	b.lt	0x2728 <_stogir.loops.depths+0x878>
    2708:      	adrp	x3, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002708:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    270c:      	sub	x8, x29, #0x70
    2710:      	ldr	x1, [x15]
    2714:      	ldr	x3, [x3]
		0000000000002714:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    2718:      	ldur	x0, [x8, #-0x100]
    271c:      	mov	w4, #0x4                ; =4
    2720:      	mov	w5, #0x4                ; =4
    2724:      	bl	0x2724 <_stogir.loops.depths+0x874>
		0000000000002724:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    2728:      	sub	x8, x29, #0x88
    272c:      	sub	x9, x29, #0xd8
    2730:      	ldur	x8, [x8, #-0x100]
    2734:      	ldur	x9, [x9, #-0x100]
    2738:      	ldp	q0, q1, [x8]
    273c:      	ldr	x8, [x8, #0x20]
    2740:      	str	x8, [x9, #0x20]
    2744:      	stp	q0, q1, [x9]
    2748:      	sub	sp, x29, #0x50
    274c:      	ldp	x29, x30, [sp, #0x50]
    2750:      	ldp	x20, x19, [sp, #0x40]
    2754:      	ldp	x22, x21, [sp, #0x30]
    2758:      	ldp	x24, x23, [sp, #0x20]
    275c:      	ldp	x26, x25, [sp, #0x10]
    2760:      	ldp	x28, x27, [sp], #0x60
    2764:      	ret
    2768:      	sub	x9, x29, #0x80
    276c:      	sub	x23, x29, #0x108
    2770:      	mov	w8, #0x1                ; =1
    2774:      	ldur	x11, [x9, #-0x100]
    2778:      	sub	x9, x29, #0xa0
    277c:      	sub	x12, x29, #0xc8
    2780:      	ldur	x13, [x9, #-0x100]
    2784:      	b	0x2794 <_stogir.loops.depths+0x8e4>
    2788:      	add	x8, x8, #0x1
    278c:      	cmp	x20, x8
    2790:      	b.eq	0x27b8 <_stogir.loops.depths+0x908>
    2794:      	ldr	x9, [x11]
    2798:      	ldr	w9, [x9, x8, lsl #2]
    279c:      	cmp	w9, #0x1
    27a0:      	ccmp	x8, x9, #0x4, ge
    27a4:      	b.eq	0x2788 <_stogir.loops.depths+0x8d8>
    27a8:      	ldr	w10, [x26, x9, lsl #2]
    27ac:      	str	w10, [x28, x8, lsl #2]
    27b0:      	str	w8, [x26, x9, lsl #2]
    27b4:      	b	0x2788 <_stogir.loops.depths+0x8d8>
    27b8:      	sub	x8, x29, #0x78
    27bc:      	mov	x19, x25
    27c0:      	mov	x1, xzr
    27c4:      	stur	x27, [x8, #-0x100]
    27c8:      	mov	x2, xzr
    27cc:      	mov	x28, xzr
    27d0:      	mov	w25, wzr
    27d4:      	mov	w27, #0x1               ; =1
    27d8:      	mov	w24, #0x2               ; =2
    27dc:      	b	0x2800 <_stogir.loops.depths+0x950>
    27e0:      	sub	x8, x29, #0x8
    27e4:      	stp	x28, x2, [x29, #-0x100]
    27e8:      	stur	x1, [x8, #-0x100]
    27ec:      	sub	x8, x29, #0x90
    27f0:      	ldur	x20, [x8, #-0x100]
    27f4:      	add	x27, x27, #0x1
    27f8:      	cmp	x27, x20
    27fc:      	b.eq	0x294c <_stogir.loops.depths+0xa9c>
    2800:      	ldr	x8, [x11]
    2804:      	ldrsw	x8, [x8, x27, lsl #2]
    2808:      	cmp	x27, x8
    280c:      	b.ne	0x27f4 <_stogir.loops.depths+0x944>
    2810:      	cmp	x28, x2
    2814:      	add	w25, w25, #0x1
    2818:      	str	w25, [x19, x27, lsl #2]
    281c:      	b.lt	0x287c <_stogir.loops.depths+0x9cc>
    2820:      	lsl	x8, x2, #1
    2824:      	cmp	x2, #0x0
    2828:      	ldur	q0, [x23, #0x18]
    282c:      	csel	x26, x24, x8, eq
    2830:      	stur	q0, [x12, #0x58]
    2834:      	cmp	x26, x2
    2838:      	b.le	0x287c <_stogir.loops.depths+0x9cc>
    283c:      	adrp	x4, 0x2000 <_stogir.loops.depths+0x150>
		000000000000283c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2840:      	sub	x0, x29, #0x70
    2844:      	mov	x3, x26
    2848:      	ldr	x4, [x4]
		0000000000002848:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    284c:      	mov	w5, #0x4                ; =4
    2850:      	mov	w6, #0x4                ; =4
    2854:      	bl	0x2854 <_stogir.loops.depths+0x9a4>
		0000000000002854:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    2858:      	cbz	w0, 0x29ec <_stogir.loops.depths+0xb3c>
    285c:      	sub	x8, x29, #0x8
    2860:      	sub	x12, x29, #0xc8
    2864:      	stur	x26, [x29, #-0xf8]
    2868:      	stur	x1, [x8, #-0x100]
    286c:      	sub	x8, x29, #0x80
    2870:      	ldur	x11, [x8, #-0x100]
    2874:      	sub	x8, x29, #0xa0
    2878:      	ldur	x13, [x8, #-0x100]
    287c:      	str	w27, [x1, x28, lsl #2]
    2880:      	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
    2884:      	ldur	x2, [x29, #-0xf8]
    2888:      	cmp	x28, x8
    288c:      	add	x28, x28, #0x1
    2890:      	b.hi	0x27e0 <_stogir.loops.depths+0x930>
    2894:      	ldur	x8, [x29, #-0xc8]
    2898:      	b	0x28c8 <_stogir.loops.depths+0xa18>
    289c:      	sub	x8, x29, #0x80
    28a0:      	mov	x2, x26
    28a4:      	sub	x12, x29, #0xc8
    28a8:      	ldur	x11, [x8, #-0x100]
    28ac:      	sub	x8, x29, #0xa0
    28b0:      	ldur	x13, [x8, #-0x100]
    28b4:      	str	w20, [x1, x28, lsl #2]
    28b8:      	add	x28, x28, #0x1
    28bc:      	ldur	x8, [x29, #-0xc8]
    28c0:      	cmp	x28, #0x0
    28c4:      	b.le	0x27e0 <_stogir.loops.depths+0x930>
    28c8:      	add	x9, x1, x28, lsl #2
    28cc:      	ldursw	x9, [x9, #-0x4]
    28d0:      	ldr	w20, [x8, x9, lsl #2]
    28d4:      	cmp	w20, #0x1
    28d8:      	b.lt	0x2938 <_stogir.loops.depths+0xa88>
    28dc:      	ldur	x10, [x29, #-0xa0]
    28e0:      	cmp	x28, x2
    28e4:      	add	w25, w25, #0x1
    28e8:      	ldr	w10, [x10, w20, uxtw #2]
    28ec:      	str	w10, [x8, x9, lsl #2]
    28f0:      	str	w25, [x19, w20, uxtw #2]
    28f4:      	b.lt	0x28b4 <_stogir.loops.depths+0xa04>
    28f8:      	lsl	x8, x2, #1
    28fc:      	cmp	x2, #0x0
    2900:      	ldur	q0, [x23, #0x18]
    2904:      	csel	x26, x24, x8, eq
    2908:      	stur	q0, [x12, #0x58]
    290c:      	cmp	x26, x2
    2910:      	b.le	0x28b4 <_stogir.loops.depths+0xa04>
    2914:      	adrp	x4, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002914:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2918:      	sub	x0, x29, #0x70
    291c:      	mov	x3, x26
    2920:      	ldr	x4, [x4]
		0000000000002920:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    2924:      	mov	w5, #0x4                ; =4
    2928:      	mov	w6, #0x4                ; =4
    292c:      	bl	0x292c <_stogir.loops.depths+0xa7c>
		000000000000292c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    2930:      	cbnz	w0, 0x289c <_stogir.loops.depths+0x9ec>
    2934:      	b	0x29ec <_stogir.loops.depths+0xb3c>
    2938:      	sub	x28, x28, #0x1
    293c:      	str	w25, [x13, x9, lsl #2]
    2940:      	cmp	x28, #0x0
    2944:      	b.gt	0x28c8 <_stogir.loops.depths+0xa18>
    2948:      	b	0x27e0 <_stogir.loops.depths+0x930>
    294c:      	cmp	x2, #0x1
    2950:      	stur	xzr, [x29, #-0x100]
    2954:      	b.lt	0x2970 <_stogir.loops.depths+0xac0>
    2958:      	adrp	x3, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002958:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    295c:      	add	x0, x23, #0x18
    2960:      	mov	w4, #0x4                ; =4
    2964:      	ldr	x3, [x3]
		0000000000002964:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    2968:      	mov	w5, #0x4                ; =4
    296c:      	bl	0x296c <_stogir.loops.depths+0xabc>
		000000000000296c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    2970:      	sub	x8, x29, #0x8
    2974:      	ldur	x2, [x29, #-0x90]
    2978:      	mov	x25, x19
    297c:      	stur	xzr, [x8, #-0x100]
    2980:      	sub	x8, x29, #0x78
    2984:      	sub	x23, x29, #0xa0
    2988:      	ldur	x27, [x8, #-0x100]
    298c:      	cmp	x2, #0x1
    2990:      	stp	xzr, xzr, [x29, #-0x100]
    2994:      	stur	xzr, [x29, #-0x98]
    2998:      	b.lt	0x29b8 <_stogir.loops.depths+0xb08>
    299c:      	adrp	x3, 0x2000 <_stogir.loops.depths+0x150>
		000000000000299c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    29a0:      	ldur	x1, [x29, #-0xa0]
    29a4:      	add	x0, x23, #0x18
    29a8:      	ldr	x3, [x3]
		00000000000029a8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    29ac:      	mov	w4, #0x4                ; =4
    29b0:      	mov	w5, #0x4                ; =4
    29b4:      	bl	0x29b4 <_stogir.loops.depths+0xb04>
		00000000000029b4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    29b8:      	sub	x8, x29, #0xa0
    29bc:      	mov	x19, x20
    29c0:      	sub	x9, x29, #0xc8
    29c4:      	ldur	x8, [x8, #-0x100]
    29c8:      	stp	xzr, xzr, [x29, #-0xa0]
    29cc:      	stur	xzr, [x29, #-0x90]
    29d0:      	stur	xzr, [x29, #-0xc0]
    29d4:      	ldur	x2, [x29, #-0xb8]
    29d8:      	sub	x10, x29, #0xa0
    29dc:      	stur	x8, [x10, #-0x100]
    29e0:      	cmp	x2, #0x1
    29e4:      	b.ge	0x209c <_stogir.loops.depths+0x1ec>
    29e8:      	b	0x20c4 <_stogir.loops.depths+0x214>
    29ec:      	lsl	x1, x26, #2
    29f0:      	adrp	x0, 0x2000 <_stogir.loops.depths+0x150>
		00000000000029f0:  ARM64_RELOC_PAGE21	l_cstr.204
    29f4:      	add	x0, x0, #0x0
		00000000000029f4:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    29f8:      	bl	0x29f8 <_stogir.loops.depths+0xb48>
		00000000000029f8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    29fc:      	adrp	x0, 0x2000 <_stogir.loops.depths+0x150>
		00000000000029fc:  ARM64_RELOC_PAGE21	l_cstr.204
    2a00:      	add	x0, x0, #0x0
		0000000000002a00:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    2a04:      	mov	x1, x19
    2a08:      	bl	0x2a08 <_stogir.loops.depths+0xb58>
		0000000000002a08:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    2a0c:      	sub	x8, x29, #0x78
    2a10:      	adrp	x0, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002a10:  ARM64_RELOC_PAGE21	l_cstr.204
    2a14:      	add	x0, x0, #0x0
		0000000000002a14:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    2a18:      	ldur	x8, [x8, #-0x100]
    2a1c:      	lsl	x1, x8, #2
    2a20:      	bl	0x2a20 <_stogir.loops.depths+0xb70>
		0000000000002a20:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    2a24:      	adrp	x0, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002a24:  ARM64_RELOC_PAGE21	l_cstr.204
    2a28:      	add	x0, x0, #0x0
		0000000000002a28:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    2a2c:      	mov	x1, x28
    2a30:      	bl	0x2a30 <_stogir.loops.depths+0xb80>
		0000000000002a30:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at

0000000000002a34 <_stogir.pipeline.prepare-checked>:
    2a34:      	stp	x28, x27, [sp, #-0x60]!
    2a38:      	stp	x26, x25, [sp, #0x10]
    2a3c:      	stp	x24, x23, [sp, #0x20]
    2a40:      	stp	x22, x21, [sp, #0x30]
    2a44:      	stp	x20, x19, [sp, #0x40]
    2a48:      	stp	x29, x30, [sp, #0x50]
    2a4c:      	add	x29, sp, #0x50
    2a50:      	sub	sp, sp, #0x6c0
    2a54:      	cmp	w2, #0x1
    2a58:      	b.lt	0x2ab4 <_stogir.pipeline.prepare-checked+0x80>
    2a5c:      	ldr	x24, [x1, #0x8]
    2a60:      	mov	w19, w2
    2a64:      	cmp	x24, x19
    2a68:      	b.le	0x2ab4 <_stogir.pipeline.prepare-checked+0x80>
    2a6c:      	ldr	x20, [x1, #0x80]
    2a70:      	cmp	x20, x19
    2a74:      	b.le	0x2ab4 <_stogir.pipeline.prepare-checked+0x80>
    2a78:      	ldr	x21, [x1, #0x78]
    2a7c:      	ldr	w8, [x21, x19, lsl #2]
    2a80:      	tbnz	w8, #0x1f, 0x2ab4 <_stogir.pipeline.prepare-checked+0x80>
    2a84:      	stp	x0, x5, [sp, #0x90]
    2a88:      	add	x0, sp, #0x600
    2a8c:      	stp	x4, x3, [sp, #0x60]
    2a90:      	str	x1, [sp, #0xa0]
    2a94:      	bl	0x2a94 <_stogir.pipeline.prepare-checked+0x60>
		0000000000002a94:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    2a98:      	ldr	w8, [sp, #0x600]
    2a9c:      	cmp	w8, #0x1
    2aa0:      	b.ne	0x2aec <_stogir.pipeline.prepare-checked+0xb8>
    2aa4:      	ldr	x28, [sp, #0x608]
    2aa8:      	ldr	x22, [sp, #0x610]
    2aac:      	ldr	x9, [sp, #0x90]
    2ab0:      	b	0x2cd8 <_stogir.pipeline.prepare-checked+0x2a4>
    2ab4:      	mov	w8, #0x1                ; =1
    2ab8:      	adrp	x9, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002ab8:  ARM64_RELOC_PAGE21	l_str.627
    2abc:      	add	x9, x9, #0x0
		0000000000002abc:  ARM64_RELOC_PAGEOFF12	l_str.627
    2ac0:      	str	w8, [x0]
    2ac4:      	mov	w8, #0x17               ; =23
    2ac8:      	stp	x9, x8, [x0, #0x8]
    2acc:      	add	sp, sp, #0x6c0
    2ad0:      	ldp	x29, x30, [sp, #0x50]
    2ad4:      	ldp	x20, x19, [sp, #0x40]
    2ad8:      	ldp	x22, x21, [sp, #0x30]
    2adc:      	ldp	x24, x23, [sp, #0x20]
    2ae0:      	ldp	x26, x25, [sp, #0x10]
    2ae4:      	ldp	x28, x27, [sp], #0x60
    2ae8:      	ret
    2aec:      	ldp	x9, x8, [sp, #0x90]
    2af0:      	cmp	x24, x20
    2af4:      	ldr	x1, [sp, #0xa0]
    2af8:      	sub	x27, x29, #0xc0
    2afc:      	add	x25, sp, #0x550
    2b00:      	add	x23, sp, #0x410
    2b04:      	adrp	x28, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002b04:  ARM64_RELOC_PAGE21	l_str.816
    2b08:      	add	x28, x28, #0x0
		0000000000002b08:  ARM64_RELOC_PAGEOFF12	l_str.816
    2b0c:      	csel	x10, x24, x20, lt
    2b10:      	adrp	x26, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002b10:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2b14:      	add	x26, x26, #0x0
		0000000000002b14:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2b18:      	mov	w13, #0x1               ; =1
    2b1c:      	adrp	x11, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002b1c:  ARM64_RELOC_PAGE21	l_str.819
    2b20:      	add	x11, x11, #0x0
		0000000000002b20:  ARM64_RELOC_PAGEOFF12	l_str.819
    2b24:      	mov	w15, #0x5               ; =5
    2b28:      	adrp	x14, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002b28:  ARM64_RELOC_PAGE21	l_str.820
    2b2c:      	add	x14, x14, #0x0
		0000000000002b2c:  ARM64_RELOC_PAGEOFF12	l_str.820
    2b30:      	adrp	x12, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002b30:  ARM64_RELOC_PAGE21	l_str.821
    2b34:      	add	x12, x12, #0x0
		0000000000002b34:  ARM64_RELOC_PAGEOFF12	l_str.821
    2b38:      	mov	w16, #0x1d              ; =29
    2b3c:      	adrp	x17, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002b3c:  ARM64_RELOC_PAGE21	l_str.822
    2b40:      	add	x17, x17, #0x0
		0000000000002b40:  ARM64_RELOC_PAGEOFF12	l_str.822
    2b44:      	mov	w0, #-0x7fffffff        ; =-2147483647
    2b48:      	str	x19, [sp, #0x40]
    2b4c:      	cmp	x13, x24
    2b50:      	b.ge	0x2ce8 <_stogir.pipeline.prepare-checked+0x2b4>
    2b54:      	ldrsw	x2, [x21, x13, lsl #2]
    2b58:      	cmp	w2, #0x1
    2b5c:      	b.lt	0x2c9c <_stogir.pipeline.prepare-checked+0x268>
    2b60:      	ldr	x3, [x1]
    2b64:      	lsl	x4, x13, #4
    2b68:      	ldrb	w4, [x3, x4]
    2b6c:      	cmp	x4, #0x83
    2b70:      	b.hs	0x2c58 <_stogir.pipeline.prepare-checked+0x224>
    2b74:      	and	x5, x13, #0x7fffffff
    2b78:      	mov	w7, #0x1                ; =1
    2b7c:      	cmp	x24, x5
    2b80:      	ccmp	x20, x5, #0x4, gt
    2b84:      	ccmp	w13, #0x1, #0x8, gt
    2b88:      	cset	w6, lt
    2b8c:      	b	0x2ba4 <_stogir.pipeline.prepare-checked+0x170>
    2b90:      	mov	x22, xzr
    2b94:      	add	w7, w7, #0x1
    2b98:      	cmp	w7, w2
    2b9c:      	b.gt	0x2ca0 <_stogir.pipeline.prepare-checked+0x26c>
    2ba0:      	cbnz	x22, 0x2ca0 <_stogir.pipeline.prepare-checked+0x26c>
    2ba4:      	cmp	w7, #0x1
    2ba8:      	b.lt	0x2b90 <_stogir.pipeline.prepare-checked+0x15c>
    2bac:      	cmp	w7, #0x5
    2bb0:      	ldr	w22, [x26, x4, lsl #2]
    2bb4:      	csel	w19, w7, w15, lo
    2bb8:      	lsl	w19, w19, #2
    2bbc:      	sub	w19, w19, #0x4
    2bc0:      	lsr	w19, w22, w19
    2bc4:      	and	w19, w19, #0xf
    2bc8:      	cmp	w19, #0xc
    2bcc:      	b.ne	0x2b90 <_stogir.pipeline.prepare-checked+0x15c>
    2bd0:      	tbz	w6, #0x0, 0x2be0 <_stogir.pipeline.prepare-checked+0x1ac>
    2bd4:      	mov	x22, xzr
    2bd8:      	cbnz	w22, 0x2c0c <_stogir.pipeline.prepare-checked+0x1d8>
    2bdc:      	b	0x2cc4 <_stogir.pipeline.prepare-checked+0x290>
    2be0:      	ldr	w19, [x21, x5, lsl #2]
    2be4:      	mov	x22, xzr
    2be8:      	tbnz	w19, #0x1f, 0x2c50 <_stogir.pipeline.prepare-checked+0x21c>
    2bec:      	cmp	w7, w19
    2bf0:      	b.hi	0x2c08 <_stogir.pipeline.prepare-checked+0x1d4>
    2bf4:      	add	w19, w13, w7, lsr #2
    2bf8:      	and	w22, w7, #0x3
    2bfc:      	add	x19, x3, w19, uxtw #4
    2c00:      	ldr	w19, [x19, w22, uxtw #2]
    2c04:      	mov	w22, #0x1               ; =1
    2c08:      	cbz	w22, 0x2cc4 <_stogir.pipeline.prepare-checked+0x290>
    2c0c:      	cmp	w19, #0x1
    2c10:      	b.lt	0x2cd0 <_stogir.pipeline.prepare-checked+0x29c>
    2c14:      	and	x19, x19, #0x7fffffff
    2c18:      	cmp	x19, x10
    2c1c:      	b.ge	0x2cb8 <_stogir.pipeline.prepare-checked+0x284>
    2c20:      	ldr	w22, [x21, x19, lsl #2]
    2c24:      	tbnz	w22, #0x1f, 0x2cb8 <_stogir.pipeline.prepare-checked+0x284>
    2c28:      	lsl	x19, x19, #4
    2c2c:      	ldrb	w19, [x3, x19]
    2c30:      	sub	w19, w19, #0x4f
    2c34:      	cmp	w19, #0x34
    2c38:      	csel	x22, xzr, x16, lo
    2c3c:      	csel	x28, x28, x17, lo
    2c40:      	add	w7, w7, #0x1
    2c44:      	cmp	w7, w2
    2c48:      	b.le	0x2ba0 <_stogir.pipeline.prepare-checked+0x16c>
    2c4c:      	b	0x2ca0 <_stogir.pipeline.prepare-checked+0x26c>
    2c50:      	cbnz	w22, 0x2c0c <_stogir.pipeline.prepare-checked+0x1d8>
    2c54:      	b	0x2cc4 <_stogir.pipeline.prepare-checked+0x290>
    2c58:      	mov	w4, #0x5                ; =5
    2c5c:      	add	w3, w2, w0
    2c60:      	movk	w4, #0x8000, lsl #16
    2c64:      	cmp	w3, w4
    2c68:      	b.hs	0x2c74 <_stogir.pipeline.prepare-checked+0x240>
    2c6c:      	mov	w3, #0x1                ; =1
    2c70:      	b	0x2c90 <_stogir.pipeline.prepare-checked+0x25c>
    2c74:      	and	w4, w2, #0x7ffffffc
    2c78:      	and	w5, w2, #0x7ffffffc
    2c7c:      	orr	w3, w4, #0x1
    2c80:      	subs	w5, w5, #0x4
    2c84:      	b.ne	0x2c80 <_stogir.pipeline.prepare-checked+0x24c>
    2c88:      	cmp	w2, w4
    2c8c:      	b.eq	0x2c9c <_stogir.pipeline.prepare-checked+0x268>
    2c90:      	add	w3, w3, #0x1
    2c94:      	cmp	w3, w2
    2c98:      	b.le	0x2c90 <_stogir.pipeline.prepare-checked+0x25c>
    2c9c:      	mov	x22, xzr
    2ca0:      	adds	x3, x2, #0x4
    2ca4:      	add	x2, x2, #0x7
    2ca8:      	csel	x2, x2, x3, mi
    2cac:      	add	x13, x13, x2, asr #2
    2cb0:      	cbz	x22, 0x2b4c <_stogir.pipeline.prepare-checked+0x118>
    2cb4:      	b	0x2cd8 <_stogir.pipeline.prepare-checked+0x2a4>
    2cb8:      	mov	w22, #0x16              ; =22
    2cbc:      	mov	x28, x12
    2cc0:      	b	0x2cd8 <_stogir.pipeline.prepare-checked+0x2a4>
    2cc4:      	mov	w22, #0x16              ; =22
    2cc8:      	mov	x28, x11
    2ccc:      	b	0x2cd8 <_stogir.pipeline.prepare-checked+0x2a4>
    2cd0:      	mov	w22, #0x25              ; =37
    2cd4:      	mov	x28, x14
    2cd8:      	mov	w8, #0x1                ; =1
    2cdc:      	stp	x28, x22, [x9, #0x8]
    2ce0:      	str	w8, [x9]
    2ce4:      	b	0x2acc <_stogir.pipeline.prepare-checked+0x98>
    2ce8:      	ldr	q0, [x8]
    2cec:      	str	xzr, [sp, #0x5d0]
    2cf0:      	str	xzr, [sp, #0x5d8]
    2cf4:      	str	xzr, [sp, #0x5e0]
    2cf8:      	stur	q0, [x25, #0x98]
    2cfc:      	ldp	q1, q2, [x25, #0x80]
    2d00:      	stur	q0, [x25, #0xe8]
    2d04:      	stp	xzr, xzr, [x29, #-0xe8]
    2d08:      	ldr	x9, [sp, #0x5f0]
    2d0c:      	ldur	x10, [x29, #-0xd0]
    2d10:      	stur	xzr, [x29, #-0xf0]
    2d14:      	stp	q1, q2, [x23, #0x140]
    2d18:      	ldp	q1, q0, [x25, #0xd0]
    2d1c:      	stp	xzr, xzr, [x29, #-0xb8]
    2d20:      	stur	xzr, [x29, #-0xc0]
    2d24:      	stur	q0, [x25, #0x38]
    2d28:      	ldr	q0, [x8]
    2d2c:      	stur	q1, [x25, #0x28]
    2d30:      	ldr	x2, [sp, #0x588]
    2d34:      	stur	q0, [x27, #0x18]
    2d38:      	ldr	x22, [sp, #0x580]
    2d3c:      	ldr	x21, [sp, #0x578]
    2d40:      	ldp	q1, q0, [x27]
    2d44:      	str	x9, [sp, #0x570]
    2d48:      	ldur	x9, [x29, #-0xa0]
    2d4c:      	add	x19, x22, x24
    2d50:      	str	x10, [sp, #0x598]
    2d54:      	cmp	x19, x2
    2d58:      	stp	xzr, xzr, [x29, #-0x90]
    2d5c:      	stp	q1, q0, [x25, #0x50]
    2d60:      	ldr	q0, [x8]
    2d64:      	str	x9, [sp, #0x5c0]
    2d68:      	stur	xzr, [x29, #-0x80]
    2d6c:      	stur	q0, [x27, #0x48]
    2d70:      	b.le	0x2dc4 <_stogir.pipeline.prepare-checked+0x390>
    2d74:      	lsl	x9, x2, #1
    2d78:      	ldr	q0, [x8]
    2d7c:      	mov	x10, #0x4000000000000000 ; =4611686018427387904
    2d80:      	adrp	x4, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002d80:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2d84:      	add	x0, sp, #0x600
    2d88:      	mov	x1, x21
    2d8c:      	cmp	x9, x19
    2d90:      	str	q0, [x25, #0xb0]
    2d94:      	mov	w5, #0x4                ; =4
    2d98:      	csel	x8, x9, x19, gt
    2d9c:      	cmp	x2, x10
    2da0:      	ldr	x4, [x4]
		0000000000002da0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    2da4:      	csel	x20, x8, x19, lt
    2da8:      	mov	w6, #0x4                ; =4
    2dac:      	mov	x3, x20
    2db0:      	bl	0x2db0 <_stogir.pipeline.prepare-checked+0x37c>
		0000000000002db0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    2db4:      	cbz	w0, 0x72dc <_stogir.pipeline.prepare-checked+0x48a8>
    2db8:      	mov	x21, x1
    2dbc:      	str	x1, [sp, #0x578]
    2dc0:      	str	x20, [sp, #0x588]
    2dc4:      	add	x0, x21, x22, lsl #2
    2dc8:      	lsl	x1, x24, #2
    2dcc:      	bl	0x2dcc <_stogir.pipeline.prepare-checked+0x398>
		0000000000002dcc:  ARM64_RELOC_BRANCH26	_bzero
    2dd0:      	ldr	x8, [sp, #0xa0]
    2dd4:      	ldr	x12, [sp, #0x550]
    2dd8:      	str	x19, [sp, #0x580]
    2ddc:      	ldr	x9, [x8, #0x8]
    2de0:      	cmp	x9, #0x1
    2de4:      	b.le	0x2ec4 <_stogir.pipeline.prepare-checked+0x490>
    2de8:      	adrp	x22, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002de8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2dec:      	add	x19, sp, #0x550
    2df0:      	mov	w20, #0x1               ; =1
    2df4:      	ldr	x22, [x22]
		0000000000002df4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    2df8:      	mov	w24, #0x2               ; =2
    2dfc:      	add	x13, sp, #0x550
    2e00:      	adrp	x14, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002e00:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2e04:      	add	x14, x14, #0x0
		0000000000002e04:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2e08:      	b	0x2e38 <_stogir.pipeline.prepare-checked+0x404>
    2e0c:      	add	x9, x26, #0x1
    2e10:      	str	w20, [x12, x26, lsl #2]
    2e14:      	str	x9, [sp, #0x558]
    2e18:      	str	w20, [x21, x20, lsl #2]
    2e1c:      	ldr	x9, [x8, #0x8]
    2e20:      	adds	x10, x25, #0x4
    2e24:      	add	x11, x25, #0x7
    2e28:      	csel	x10, x11, x10, mi
    2e2c:      	add	x20, x20, x10, asr #2
    2e30:      	cmp	x20, x9
    2e34:      	b.ge	0x2ed4 <_stogir.pipeline.prepare-checked+0x4a0>
    2e38:      	ldr	x10, [x8]
    2e3c:      	lsl	x11, x20, #4
    2e40:      	ldr	w10, [x10, x11]
    2e44:      	ldr	x11, [x8, #0x78]
    2e48:      	and	w10, w10, #0xfe
    2e4c:      	ldrsw	x25, [x11, x20, lsl #2]
    2e50:      	sub	w10, w10, #0x68
    2e54:      	cmp	w10, #0x9
    2e58:      	b.hi	0x2e20 <_stogir.pipeline.prepare-checked+0x3ec>
    2e5c:      	ldr	x26, [sp, #0x558]
    2e60:      	ldr	x2, [sp, #0x560]
    2e64:      	cmp	x26, x2
    2e68:      	b.lt	0x2e0c <_stogir.pipeline.prepare-checked+0x3d8>
    2e6c:      	lsl	x9, x2, #1
    2e70:      	cmp	x2, #0x0
    2e74:      	ldur	q0, [x19, #0x18]
    2e78:      	csel	x23, x24, x9, eq
    2e7c:      	str	q0, [x13, #0xb0]
    2e80:      	cmp	x23, x2
    2e84:      	b.le	0x2e0c <_stogir.pipeline.prepare-checked+0x3d8>
    2e88:      	add	x0, sp, #0x600
    2e8c:      	mov	x1, x12
    2e90:      	mov	x3, x23
    2e94:      	mov	x4, x22
    2e98:      	mov	w5, #0x4                ; =4
    2e9c:      	mov	w6, #0x4                ; =4
    2ea0:      	bl	0x2ea0 <_stogir.pipeline.prepare-checked+0x46c>
		0000000000002ea0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    2ea4:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    2ea8:      	ldr	x8, [sp, #0xa0]
    2eac:      	mov	x12, x1
    2eb0:      	add	x13, sp, #0x550
    2eb4:      	adrp	x14, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002eb4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2eb8:      	add	x14, x14, #0x0
		0000000000002eb8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2ebc:      	str	x23, [sp, #0x560]
    2ec0:      	b	0x2e0c <_stogir.pipeline.prepare-checked+0x3d8>
    2ec4:      	add	x13, sp, #0x550
    2ec8:      	adrp	x14, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002ec8:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2ecc:      	add	x14, x14, #0x0
		0000000000002ecc:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2ed0:      	b	0x4ae8 <_stogir.pipeline.prepare-checked+0x20b4>
    2ed4:      	cmp	x9, #0x2
    2ed8:      	str	x12, [sp, #0x550]
    2edc:      	b.lt	0x4ae8 <_stogir.pipeline.prepare-checked+0x20b4>
    2ee0:      	adrp	x20, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002ee0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    2ee4:      	adrp	x15, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002ee4:  ARM64_RELOC_PAGE21	l_str.374
    2ee8:      	add	x15, x15, #0x0
		0000000000002ee8:  ARM64_RELOC_PAGEOFF12	l_str.374
    2eec:      	ldr	x20, [x20]
		0000000000002eec:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    2ef0:      	mov	w26, #0x1               ; =1
    2ef4:      	mov	w22, #0x27              ; =39
    2ef8:      	mov	w27, #0x2               ; =2
    2efc:      	b	0x2f18 <_stogir.pipeline.prepare-checked+0x4e4>
    2f00:      	adds	x10, x25, #0x4
    2f04:      	add	x11, x25, #0x7
    2f08:      	csel	x10, x11, x10, mi
    2f0c:      	add	x26, x26, x10, asr #2
    2f10:      	cmp	x26, x9
    2f14:      	b.ge	0x4ae4 <_stogir.pipeline.prepare-checked+0x20b0>
    2f18:      	ldr	x10, [x8]
    2f1c:      	lsl	x11, x26, #4
    2f20:      	ldrb	w10, [x10, x11]
    2f24:      	ldr	x11, [x8, #0x78]
    2f28:      	sub	w10, w10, #0x4f
    2f2c:      	ldrsw	x25, [x11, x26, lsl #2]
    2f30:      	cmp	w10, #0x33
    2f34:      	b.hi	0x2f00 <_stogir.pipeline.prepare-checked+0x4cc>
    2f38:      	ldr	x28, [sp, #0x578]
    2f3c:      	ldr	w10, [x28, x26, lsl #2]
    2f40:      	cbnz	w10, 0x2f00 <_stogir.pipeline.prepare-checked+0x4cc>
    2f44:      	ldur	x1, [x29, #-0x90]
    2f48:      	mov	x24, xzr
    2f4c:      	mov	w19, w26
    2f50:      	stur	xzr, [x29, #-0x88]
    2f54:      	ldr	w10, [x28, w19, sxtw #2]
    2f58:      	cbnz	w10, 0x3054 <_stogir.pipeline.prepare-checked+0x620>
    2f5c:      	cmp	x24, x9
    2f60:      	b.ge	0x30b4 <_stogir.pipeline.prepare-checked+0x680>
    2f64:      	ldur	x2, [x29, #-0x80]
    2f68:      	cmp	x24, x2
    2f6c:      	b.lt	0x2fc4 <_stogir.pipeline.prepare-checked+0x590>
    2f70:      	lsl	x9, x2, #1
    2f74:      	cmp	x2, #0x0
    2f78:      	csel	x21, x27, x9, eq
    2f7c:      	sub	x9, x29, #0x90
    2f80:      	ldur	q0, [x9, #0x18]
    2f84:      	cmp	x21, x2
    2f88:      	str	q0, [x13, #0xb0]
    2f8c:      	b.le	0x2fc4 <_stogir.pipeline.prepare-checked+0x590>
    2f90:      	add	x0, sp, #0x600
    2f94:      	mov	x3, x21
    2f98:      	mov	x4, x20
    2f9c:      	mov	w5, #0x4                ; =4
    2fa0:      	mov	w6, #0x4                ; =4
    2fa4:      	mov	x23, x15
    2fa8:      	bl	0x2fa8 <_stogir.pipeline.prepare-checked+0x574>
		0000000000002fa8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    2fac:      	cbz	w0, 0x72ac <_stogir.pipeline.prepare-checked+0x4878>
    2fb0:      	ldr	x8, [sp, #0xa0]
    2fb4:      	adrp	x14, 0x2000 <_stogir.loops.depths+0x150>
		0000000000002fb4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2fb8:      	add	x14, x14, #0x0
		0000000000002fb8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2fbc:      	mov	x15, x23
    2fc0:      	stur	x21, [x29, #-0x80]
    2fc4:      	cmp	w19, #0x1
    2fc8:      	str	w19, [x1, x24, lsl #2]
    2fcc:      	b.lt	0x3010 <_stogir.pipeline.prepare-checked+0x5dc>
    2fd0:      	ldr	x10, [x8, #0x8]
    2fd4:      	mov	w9, w19
    2fd8:      	cmp	x10, x9
    2fdc:      	b.le	0x3010 <_stogir.pipeline.prepare-checked+0x5dc>
    2fe0:      	ldr	x10, [x8, #0x80]
    2fe4:      	cmp	x10, x9
    2fe8:      	b.le	0x3010 <_stogir.pipeline.prepare-checked+0x5dc>
    2fec:      	ldr	x10, [x8, #0x78]
    2ff0:      	ldr	w10, [x10, x9, lsl #2]
    2ff4:      	cmp	w10, #0x1
    2ff8:      	b.lt	0x3010 <_stogir.pipeline.prepare-checked+0x5dc>
    2ffc:      	ldr	x10, [x8]
    3000:      	add	x9, x10, x9, lsl #4
    3004:      	ldr	w19, [x9, #0x4]
    3008:      	mov	w9, #0x1                ; =1
    300c:      	b	0x3014 <_stogir.pipeline.prepare-checked+0x5e0>
    3010:      	mov	x9, xzr
    3014:      	cbz	w9, 0x30a8 <_stogir.pipeline.prepare-checked+0x674>
    3018:      	cmp	w19, #0x1
    301c:      	b.lt	0x3098 <_stogir.pipeline.prepare-checked+0x664>
    3020:      	ldr	x9, [x8, #0x8]
    3024:      	and	x10, x19, #0x7fffffff
    3028:      	cmp	x9, x10
    302c:      	b.le	0x3098 <_stogir.pipeline.prepare-checked+0x664>
    3030:      	ldr	x11, [x8, #0x80]
    3034:      	cmp	x11, x10
    3038:      	b.le	0x3098 <_stogir.pipeline.prepare-checked+0x664>
    303c:      	ldr	x11, [x8, #0x78]
    3040:      	add	x24, x24, #0x1
    3044:      	add	x13, sp, #0x550
    3048:      	ldr	w10, [x11, x10, lsl #2]
    304c:      	tbz	w10, #0x1f, 0x2f54 <_stogir.pipeline.prepare-checked+0x520>
    3050:      	b	0x3098 <_stogir.pipeline.prepare-checked+0x664>
    3054:      	mov	x9, xzr
    3058:      	stp	x1, x24, [x29, #-0x90]
    305c:      	cmp	xzr, x24
    3060:      	b.ge	0x3078 <_stogir.pipeline.prepare-checked+0x644>
    3064:      	b	0x3080 <_stogir.pipeline.prepare-checked+0x64c>
    3068:      	sbfiz	x11, x11, #2, #32
    306c:      	str	w10, [x28, x11]
    3070:      	cmp	x9, x24
    3074:      	b.lt	0x3080 <_stogir.pipeline.prepare-checked+0x64c>
    3078:      	mov	x12, xzr
    307c:      	b	0x308c <_stogir.pipeline.prepare-checked+0x658>
    3080:      	ldr	w11, [x1, x9, lsl #2]
    3084:      	add	x9, x9, #0x1
    3088:      	mov	w12, #0x1               ; =1
    308c:      	cbnz	w12, 0x3068 <_stogir.pipeline.prepare-checked+0x634>
    3090:      	ldr	x9, [x8, #0x8]
    3094:      	b	0x2f00 <_stogir.pipeline.prepare-checked+0x4cc>
    3098:      	mov	w22, #0x1b              ; =27
    309c:      	adrp	x15, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		000000000000309c:  ARM64_RELOC_PAGE21	l_str.376
    30a0:      	add	x15, x15, #0x0
		00000000000030a0:  ARM64_RELOC_PAGEOFF12	l_str.376
    30a4:      	b	0x30b4 <_stogir.pipeline.prepare-checked+0x680>
    30a8:      	mov	w22, #0x1e              ; =30
    30ac:      	adrp	x15, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		00000000000030ac:  ARM64_RELOC_PAGE21	l_str.375
    30b0:      	add	x15, x15, #0x0
		00000000000030b0:  ARM64_RELOC_PAGEOFF12	l_str.375
    30b4:      	stur	x1, [x29, #-0x90]
    30b8:      	ldur	x2, [x29, #-0x80]
    30bc:      	ldr	x19, [sp, #0x40]
    30c0:      	stur	xzr, [x29, #-0x88]
    30c4:      	cmp	x2, #0x1
    30c8:      	b.lt	0x30f4 <_stogir.pipeline.prepare-checked+0x6c0>
    30cc:      	adrp	x3, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		00000000000030cc:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    30d0:      	ldur	x1, [x29, #-0x90]
    30d4:      	sub	x8, x29, #0x90
    30d8:      	ldr	x3, [x3]
		00000000000030d8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    30dc:      	add	x0, x8, #0x18
    30e0:      	mov	w4, #0x4                ; =4
    30e4:      	mov	w5, #0x4                ; =4
    30e8:      	mov	x20, x15
    30ec:      	bl	0x30ec <_stogir.pipeline.prepare-checked+0x6b8>
		00000000000030ec:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    30f0:      	mov	x15, x20
    30f4:      	cbz	x22, 0x3108 <_stogir.pipeline.prepare-checked+0x6d4>
    30f8:      	add	x0, sp, #0x550
    30fc:      	mov	x28, x15
    3100:      	bl	0x3100 <_stogir.pipeline.prepare-checked+0x6cc>
		0000000000003100:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    3104:      	b	0x2aac <_stogir.pipeline.prepare-checked+0x78>
    3108:      	add	x9, sp, #0x550
    310c:      	add	x8, sp, #0x9
    3110:      	ldr	x20, [sp, #0x98]
    3114:      	ldp	q0, q1, [x9, #0x50]
    3118:      	add	x0, sp, #0x120
    311c:      	add	x1, sp, #0xa8
    3120:      	mov	w2, #0x1                ; =1
    3124:      	mov	x3, x20
    3128:      	stur	q0, [sp, #0xf8]
    312c:      	ldp	q2, q0, [x9, #0x10]
    3130:      	stur	q1, [x8, #0xff]
    3134:      	ldr	x8, [sp, #0x5c0]
    3138:      	stur	q0, [sp, #0xc8]
    313c:      	ldp	q1, q0, [x9, #0x30]
    3140:      	str	x8, [sp, #0x118]
    3144:      	ldr	x8, [sp, #0x550]
    3148:      	ldr	x9, [sp, #0x558]
    314c:      	stur	q2, [sp, #0xb8]
    3150:      	stur	q1, [sp, #0xd8]
    3154:      	stur	q0, [sp, #0xe8]
    3158:      	stp	x8, x9, [sp, #0xa8]
    315c:      	bl	0x315c <_stogir.pipeline.prepare-checked+0x728>
		000000000000315c:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
    3160:      	add	x0, sp, #0x170
    3164:      	add	x1, sp, #0xa8
    3168:      	mov	w2, wzr
    316c:      	mov	x3, x20
    3170:      	bl	0x3170 <_stogir.pipeline.prepare-checked+0x73c>
		0000000000003170:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
    3174:      	ldr	q0, [x20]
    3178:      	add	x8, sp, #0x550
    317c:      	sub	x9, x29, #0xc0
    3180:      	ldr	x21, [sp, #0xd8]
    3184:      	stp	xzr, xzr, [x29, #-0x88]
    3188:      	stur	q0, [x9, #0x48]
    318c:      	stur	q0, [x8, #0x18]
    3190:      	cmp	x21, #0x1
    3194:      	stur	q0, [x9, #0x18]
    3198:      	ldr	q0, [x20]
    319c:      	stur	xzr, [x29, #-0x90]
    31a0:      	str	xzr, [sp, #0x560]
    31a4:      	str	xzr, [sp, #0x550]
    31a8:      	str	xzr, [sp, #0x558]
    31ac:      	stp	xzr, xzr, [x29, #-0xb8]
    31b0:      	str	q0, [sp, #0x80]
    31b4:      	stur	xzr, [x29, #-0xc0]
    31b8:      	b.lt	0x31fc <_stogir.pipeline.prepare-checked+0x7c8>
    31bc:      	ldr	q0, [x20]
    31c0:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		00000000000031c0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__bool.0
    31c4:      	sub	x0, x29, #0xf0
    31c8:      	mov	x1, xzr
    31cc:      	mov	x2, xzr
    31d0:      	mov	x3, x21
    31d4:      	str	q0, [x8, #0xd0]
    31d8:      	mov	w5, #0x1                ; =1
    31dc:      	mov	w6, #0x1                ; =1
    31e0:      	ldr	x4, [x4]
		00000000000031e0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__bool.0
    31e4:      	bl	0x31e4 <_stogir.pipeline.prepare-checked+0x7b0>
		00000000000031e4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    31e8:      	cbz	w0, 0x72fc <_stogir.pipeline.prepare-checked+0x48c8>
    31ec:      	mov	x20, x1
    31f0:      	stur	x1, [x29, #-0x90]
    31f4:      	stur	x21, [x29, #-0x80]
    31f8:      	b	0x3200 <_stogir.pipeline.prepare-checked+0x7cc>
    31fc:      	mov	x20, xzr
    3200:      	mov	x0, x20
    3204:      	mov	x1, x21
    3208:      	add	x22, sp, #0x550
    320c:      	bl	0x320c <_stogir.pipeline.prepare-checked+0x7d8>
		000000000000320c:  ARM64_RELOC_BRANCH26	_bzero
    3210:      	stur	x21, [x29, #-0x88]
    3214:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003214:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    3218:      	add	x0, x22, #0x18
    321c:      	ldr	x4, [x4]
		000000000000321c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    3220:      	mov	x1, xzr
    3224:      	mov	x2, xzr
    3228:      	mov	w3, #0x2                ; =2
    322c:      	mov	w5, #0x10               ; =16
    3230:      	mov	w6, #0x8                ; =8
    3234:      	bl	0x3234 <_stogir.pipeline.prepare-checked+0x800>
		0000000000003234:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3238:      	cbz	w0, 0x72ec <_stogir.pipeline.prepare-checked+0x48b8>
    323c:      	adrp	x8, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		000000000000323c:  ARM64_RELOC_PAGE21	lCPI22_0
    3240:      	mov	x21, x1
    3244:      	add	x12, sp, #0x550
    3248:      	ldr	q0, [x8]
		0000000000003248:  ARM64_RELOC_PAGEOFF12	lCPI22_0
    324c:      	str	x1, [sp, #0x550]
    3250:      	mov	w26, #0x1               ; =1
    3254:      	stp	x19, xzr, [x1]
    3258:      	adrp	x23, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003258:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    325c:      	mov	x1, xzr
    3260:      	stur	q0, [x12, #0x8]
    3264:      	mov	w27, #0x2               ; =2
    3268:      	mov	w24, #0x2               ; =2
    326c:      	strb	w26, [x20, x19]
    3270:      	mov	w19, #0x1               ; =1
    3274:      	ldr	x23, [x23]
		0000000000003274:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    3278:      	b	0x3294 <_stogir.pipeline.prepare-checked+0x860>
    327c:      	add	x8, x22, #0x1
    3280:      	str	w28, [x1, x22, lsl #2]
    3284:      	sub	x19, x19, #0x1
    3288:      	stur	x8, [x29, #-0xb8]
    328c:      	cmp	x19, #0x0
    3290:      	b.le	0x33b4 <_stogir.pipeline.prepare-checked+0x980>
    3294:      	add	x8, x21, x19, lsl #4
    3298:      	ldr	x11, [sp, #0x170]
    329c:      	ldp	x28, x9, [x8, #-0x10]
    32a0:      	lsl	x10, x28, #32
    32a4:      	add	x10, x11, x10, asr #28
    32a8:      	ldr	x11, [x10, #0x8]
    32ac:      	cmp	x9, x11
    32b0:      	b.ge	0x3360 <_stogir.pipeline.prepare-checked+0x92c>
    32b4:      	ldr	x10, [x10]
    32b8:      	ldr	x11, [sp, #0x198]
    32bc:      	add	x10, x11, x10, lsl #3
    32c0:      	ldr	x11, [sp, #0xf8]
    32c4:      	ldr	x10, [x10, x9, lsl #3]
    32c8:      	lsl	x10, x10, #4
    32cc:      	ldr	x28, [x11, x10]
    32d0:      	add	x10, x9, #0x1
    32d4:      	stur	x10, [x8, #-0x8]
    32d8:      	asr	x9, x28, #32
    32dc:      	ldrb	w8, [x20, x9]
    32e0:      	tbnz	w8, #0x0, 0x328c <_stogir.pipeline.prepare-checked+0x858>
    32e4:      	cmp	x19, x24
    32e8:      	strb	w26, [x20, x9]
    32ec:      	b.lt	0x334c <_stogir.pipeline.prepare-checked+0x918>
    32f0:      	lsl	x8, x24, #1
    32f4:      	cmp	x24, #0x0
    32f8:      	csel	x25, x27, x8, eq
    32fc:      	add	x8, sp, #0x550
    3300:      	ldur	q0, [x8, #0x18]
    3304:      	cmp	x25, x24
    3308:      	str	q0, [x12, #0xd0]
    330c:      	b.le	0x334c <_stogir.pipeline.prepare-checked+0x918>
    3310:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003310:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    3314:      	mov	x22, x1
    3318:      	sub	x0, x29, #0xf0
    331c:      	ldr	x4, [x4]
		000000000000331c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    3320:      	mov	x1, x21
    3324:      	mov	x2, x24
    3328:      	mov	x3, x25
    332c:      	mov	w5, #0x10               ; =16
    3330:      	mov	w6, #0x8                ; =8
    3334:      	bl	0x3334 <_stogir.pipeline.prepare-checked+0x900>
		0000000000003334:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3338:      	cbz	w0, 0x72cc <_stogir.pipeline.prepare-checked+0x4898>
    333c:      	mov	x21, x1
    3340:      	mov	x24, x25
    3344:      	mov	x1, x22
    3348:      	add	x12, sp, #0x550
    334c:      	lsr	x8, x28, #32
    3350:      	add	x9, x21, x19, lsl #4
    3354:      	add	x19, x19, #0x1
    3358:      	stp	x8, xzr, [x9]
    335c:      	b	0x328c <_stogir.pipeline.prepare-checked+0x858>
    3360:      	ldp	x22, x2, [x29, #-0xb8]
    3364:      	cmp	x22, x2
    3368:      	b.lt	0x327c <_stogir.pipeline.prepare-checked+0x848>
    336c:      	lsl	x8, x2, #1
    3370:      	cmp	x2, #0x0
    3374:      	csel	x25, x27, x8, eq
    3378:      	sub	x8, x29, #0xc0
    337c:      	ldur	q0, [x8, #0x18]
    3380:      	cmp	x25, x2
    3384:      	str	q0, [x12, #0xd0]
    3388:      	b.le	0x327c <_stogir.pipeline.prepare-checked+0x848>
    338c:      	sub	x0, x29, #0xf0
    3390:      	mov	x3, x25
    3394:      	mov	x4, x23
    3398:      	mov	w5, #0x4                ; =4
    339c:      	mov	w6, #0x4                ; =4
    33a0:      	bl	0x33a0 <_stogir.pipeline.prepare-checked+0x96c>
		00000000000033a0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    33a4:      	cbz	w0, 0x41c4 <_stogir.pipeline.prepare-checked+0x1790>
    33a8:      	add	x12, sp, #0x550
    33ac:      	stur	x25, [x29, #-0xb0]
    33b0:      	b	0x327c <_stogir.pipeline.prepare-checked+0x848>
    33b4:      	ldur	x23, [x29, #-0xb8]
    33b8:      	str	x19, [sp, #0x558]
    33bc:      	stur	x1, [x29, #-0xc0]
    33c0:      	subs	x19, x23, #0x1
    33c4:      	str	x21, [sp, #0x550]
    33c8:      	str	x24, [sp, #0x560]
    33cc:      	b.lt	0x3458 <_stogir.pipeline.prepare-checked+0xa24>
    33d0:      	adrp	x21, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		00000000000033d0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    33d4:      	mov	x20, xzr
    33d8:      	mov	x24, xzr
    33dc:      	ldr	x21, [x21]
		00000000000033dc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    33e0:      	mov	x1, xzr
    33e4:      	mov	w25, #0x2               ; =2
    33e8:      	b	0x3400 <_stogir.pipeline.prepare-checked+0x9cc>
    33ec:      	sub	x19, x19, #0x1
    33f0:      	str	w26, [x1, x24, lsl #2]
    33f4:      	add	x24, x24, #0x1
    33f8:      	cmn	x19, #0x1
    33fc:      	b.eq	0x3464 <_stogir.pipeline.prepare-checked+0xa30>
    3400:      	ldur	x8, [x29, #-0xc0]
    3404:      	cmp	x24, x20
    3408:      	ldr	w26, [x8, x19, lsl #2]
    340c:      	b.lt	0x33ec <_stogir.pipeline.prepare-checked+0x9b8>
    3410:      	lsl	x8, x20, #1
    3414:      	cmp	x20, #0x0
    3418:      	ldr	q0, [sp, #0x80]
    341c:      	csel	x22, x25, x8, eq
    3420:      	str	q0, [x12, #0xd0]
    3424:      	cmp	x22, x20
    3428:      	b.le	0x33ec <_stogir.pipeline.prepare-checked+0x9b8>
    342c:      	sub	x0, x29, #0xf0
    3430:      	mov	x2, x20
    3434:      	mov	x3, x22
    3438:      	mov	x4, x21
    343c:      	mov	w5, #0x4                ; =4
    3440:      	mov	w6, #0x4                ; =4
    3444:      	bl	0x3444 <_stogir.pipeline.prepare-checked+0xa10>
		0000000000003444:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3448:      	cbz	w0, 0x72bc <_stogir.pipeline.prepare-checked+0x4888>
    344c:      	mov	x20, x22
    3450:      	add	x12, sp, #0x550
    3454:      	b	0x33ec <_stogir.pipeline.prepare-checked+0x9b8>
    3458:      	mov	x1, xzr
    345c:      	mov	x23, xzr
    3460:      	mov	x20, xzr
    3464:      	ldur	x2, [x29, #-0x80]
    3468:      	mov	x19, x1
    346c:      	stur	xzr, [x29, #-0x88]
    3470:      	cmp	x2, #0x1
    3474:      	b.lt	0x349c <_stogir.pipeline.prepare-checked+0xa68>
    3478:      	adrp	x3, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003478:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__bool.0
    347c:      	ldur	x1, [x29, #-0x90]
    3480:      	sub	x8, x29, #0x90
    3484:      	ldr	x3, [x3]
		0000000000003484:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__bool.0
    3488:      	add	x0, x8, #0x18
    348c:      	mov	w4, #0x1                ; =1
    3490:      	mov	w5, #0x1                ; =1
    3494:      	bl	0x3494 <_stogir.pipeline.prepare-checked+0xa60>
		0000000000003494:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3498:      	mov	x1, x19
    349c:      	ldr	x2, [sp, #0x560]
    34a0:      	str	xzr, [sp, #0x558]
    34a4:      	cmp	x2, #0x1
    34a8:      	b.lt	0x34d0 <_stogir.pipeline.prepare-checked+0xa9c>
    34ac:      	adrp	x3, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		00000000000034ac:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    34b0:      	ldr	x1, [sp, #0x550]
    34b4:      	add	x8, sp, #0x550
    34b8:      	ldr	x3, [x3]
		00000000000034b8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    34bc:      	add	x0, x8, #0x18
    34c0:      	mov	w4, #0x10               ; =16
    34c4:      	mov	w5, #0x8                ; =8
    34c8:      	bl	0x34c8 <_stogir.pipeline.prepare-checked+0xa94>
		00000000000034c8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    34cc:      	mov	x1, x19
    34d0:      	ldur	x2, [x29, #-0xb0]
    34d4:      	stur	xzr, [x29, #-0xb8]
    34d8:      	cmp	x2, #0x1
    34dc:      	b.lt	0x3504 <_stogir.pipeline.prepare-checked+0xad0>
    34e0:      	adrp	x3, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		00000000000034e0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    34e4:      	ldur	x1, [x29, #-0xc0]
    34e8:      	sub	x8, x29, #0xc0
    34ec:      	ldr	x3, [x3]
		00000000000034ec:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    34f0:      	add	x0, x8, #0x18
    34f4:      	mov	w4, #0x4                ; =4
    34f8:      	mov	w5, #0x4                ; =4
    34fc:      	bl	0x34fc <_stogir.pipeline.prepare-checked+0xac8>
		00000000000034fc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3500:      	mov	x1, x19
    3504:      	ldr	q0, [sp, #0x80]
    3508:      	ldr	x4, [sp, #0x98]
    350c:      	add	x8, sp, #0x1c0
    3510:      	str	x20, [sp, #0x1d0]
    3514:      	ldr	x20, [sp, #0xd8]
    3518:      	add	x24, sp, #0x550
    351c:      	stur	q0, [x8, #0x18]
    3520:      	ldr	q0, [x4]
    3524:      	add	x8, sp, #0x550
    3528:      	ldr	q1, [x4]
    352c:      	cmp	x20, #0x1
    3530:      	stp	x1, x23, [sp, #0x1c0]
    3534:      	str	xzr, [sp, #0x550]
    3538:      	str	xzr, [sp, #0x560]
    353c:      	str	q1, [sp, #0x80]
    3540:      	str	xzr, [sp, #0x558]
    3544:      	stur	q0, [x8, #0x18]
    3548:      	b.lt	0x363c <_stogir.pipeline.prepare-checked+0xc08>
    354c:      	ldr	q0, [x4]
    3550:      	sub	x8, x29, #0xc0
    3554:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003554:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    3558:      	sub	x0, x29, #0x90
    355c:      	mov	x1, xzr
    3560:      	mov	x2, xzr
    3564:      	str	q0, [x8, #0x30]
    3568:      	mov	x3, x20
    356c:      	mov	w5, #0x4                ; =4
    3570:      	ldr	x4, [x4]
		0000000000003570:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    3574:      	mov	w6, #0x4                ; =4
    3578:      	bl	0x3578 <_stogir.pipeline.prepare-checked+0xb44>
		0000000000003578:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    357c:      	lsl	x8, x20, #2
    3580:      	cbz	w0, 0x730c <_stogir.pipeline.prepare-checked+0x48d8>
    3584:      	mov	x21, x1
    3588:      	mov	x0, x1
    358c:      	mov	x1, x8
    3590:      	bl	0x3590 <_stogir.pipeline.prepare-checked+0xb5c>
		0000000000003590:  ARM64_RELOC_BRANCH26	_bzero
    3594:      	adrp	x22, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003594:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    3598:      	mov	x19, xzr
    359c:      	mov	x1, xzr
    35a0:      	ldr	x22, [x22]
		00000000000035a0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    35a4:      	ldr	x4, [sp, #0x98]
    35a8:      	mov	x25, #-0x1              ; =-1
    35ac:      	mov	w26, #0x2               ; =2
    35b0:      	sub	x9, x29, #0xc0
    35b4:      	b	0x35dc <_stogir.pipeline.prepare-checked+0xba8>
    35b8:      	ldr	x4, [sp, #0x98]
    35bc:      	sub	x9, x29, #0xc0
    35c0:      	str	x23, [sp, #0x560]
    35c4:      	str	x25, [x1, x19, lsl #3]
    35c8:      	add	x19, x19, #0x1
    35cc:      	ldr	x8, [sp, #0xd8]
    35d0:      	str	x19, [sp, #0x558]
    35d4:      	cmp	x19, x8
    35d8:      	b.ge	0x3630 <_stogir.pipeline.prepare-checked+0xbfc>
    35dc:      	ldr	x2, [sp, #0x560]
    35e0:      	cmp	x19, x2
    35e4:      	b.lt	0x35c4 <_stogir.pipeline.prepare-checked+0xb90>
    35e8:      	lsl	x8, x2, #1
    35ec:      	cmp	x2, #0x0
    35f0:      	ldur	q0, [x24, #0x18]
    35f4:      	csel	x23, x26, x8, eq
    35f8:      	str	q0, [x9, #0x30]
    35fc:      	cmp	x23, x2
    3600:      	b.le	0x35c4 <_stogir.pipeline.prepare-checked+0xb90>
    3604:      	sub	x0, x29, #0x90
    3608:      	mov	x3, x23
    360c:      	mov	x4, x22
    3610:      	mov	w5, #0x8                ; =8
    3614:      	mov	w6, #0x8                ; =8
    3618:      	bl	0x3618 <_stogir.pipeline.prepare-checked+0xbe4>
		0000000000003618:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    361c:      	cbnz	w0, 0x35b8 <_stogir.pipeline.prepare-checked+0xb84>
    3620:      	lsl	x1, x23, #3
    3624:      	adrp	x0, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003624:  ARM64_RELOC_PAGE21	l_cstr.205
    3628:      	add	x0, x0, #0x0
		0000000000003628:  ARM64_RELOC_PAGEOFF12	l_cstr.205
    362c:      	bl	0x362c <_stogir.pipeline.prepare-checked+0xbf8>
		000000000000362c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    3630:      	ldr	x23, [sp, #0x1c8]
    3634:      	mov	x22, x20
    3638:      	b	0x3648 <_stogir.pipeline.prepare-checked+0xc14>
    363c:      	mov	x22, xzr
    3640:      	mov	x21, xzr
    3644:      	mov	x1, xzr
    3648:      	cmp	x23, #0x1
    364c:      	str	x1, [sp, #0x550]
    3650:      	b.lt	0x3690 <_stogir.pipeline.prepare-checked+0xc5c>
    3654:      	mov	x9, xzr
    3658:      	ldr	x8, [sp, #0x1c0]
    365c:      	ldrsw	x8, [x8, x9, lsl #2]
    3660:      	str	x9, [x1, x8, lsl #3]
    3664:      	add	x9, x9, #0x1
    3668:      	ldr	x8, [sp, #0x1c8]
    366c:      	cmp	x9, x8
    3670:      	b.lt	0x3658 <_stogir.pipeline.prepare-checked+0xc24>
    3674:      	cmp	x8, #0x1
    3678:      	b.lt	0x3690 <_stogir.pipeline.prepare-checked+0xc5c>
    367c:      	ldr	x9, [sp, #0x1c0]
    3680:      	cmp	x8, #0x1
    3684:      	ldrsw	x10, [x9]
    3688:      	str	w10, [x21, x10, lsl #2]
    368c:      	b.ne	0x4878 <_stogir.pipeline.prepare-checked+0x1e44>
    3690:      	ldr	x2, [sp, #0x560]
    3694:      	sub	x23, x29, #0xc0
    3698:      	add	x19, sp, #0x550
    369c:      	str	xzr, [sp, #0x558]
    36a0:      	cmp	x2, #0x1
    36a4:      	b.lt	0x36c8 <_stogir.pipeline.prepare-checked+0xc94>
    36a8:      	adrp	x3, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		00000000000036a8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    36ac:      	ldr	x1, [sp, #0x550]
    36b0:      	add	x0, x24, #0x18
    36b4:      	ldr	x3, [x3]
		00000000000036b4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    36b8:      	mov	w4, #0x8                ; =8
    36bc:      	mov	w5, #0x8                ; =8
    36c0:      	bl	0x36c0 <_stogir.pipeline.prepare-checked+0xc8c>
		00000000000036c0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    36c4:      	ldr	x4, [sp, #0x98]
    36c8:      	ldr	q0, [sp, #0x80]
    36cc:      	add	x8, sp, #0x1c0
    36d0:      	add	x0, sp, #0x210
    36d4:      	add	x1, sp, #0xa8
    36d8:      	add	x2, sp, #0x120
    36dc:      	add	x3, sp, #0x1e8
    36e0:      	stp	x21, x20, [sp, #0x1e8]
    36e4:      	str	x22, [sp, #0x1f8]
    36e8:      	stur	q0, [x8, #0x40]
    36ec:      	bl	0x36ec <_stogir.pipeline.prepare-checked+0xcb8>
		00000000000036ec:  ARM64_RELOC_BRANCH26	_stogir.loops.depths
    36f0:      	ldp	x8, x9, [sp, #0x98]
    36f4:      	str	xzr, [sp, #0x550]
    36f8:      	str	xzr, [sp, #0x560]
    36fc:      	str	xzr, [sp, #0x558]
    3700:      	ldr	x20, [x9, #0x8]
    3704:      	ldr	q0, [x8]
    3708:      	ldr	q1, [x8]
    370c:      	cmp	x20, #0x1
    3710:      	str	q1, [sp, #0x70]
    3714:      	stur	q0, [x19, #0x18]
    3718:      	b.lt	0x3754 <_stogir.pipeline.prepare-checked+0xd20>
    371c:      	ldr	q0, [x8]
    3720:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003720:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__bool.0
    3724:      	sub	x0, x29, #0x90
    3728:      	mov	x1, xzr
    372c:      	mov	x2, xzr
    3730:      	mov	x3, x20
    3734:      	str	q0, [x23, #0x30]
    3738:      	mov	w5, #0x1                ; =1
    373c:      	mov	w6, #0x1                ; =1
    3740:      	ldr	x4, [x4]
		0000000000003740:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__bool.0
    3744:      	bl	0x3744 <_stogir.pipeline.prepare-checked+0xd10>
		0000000000003744:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3748:      	cbz	w0, 0x731c <_stogir.pipeline.prepare-checked+0x48e8>
    374c:      	mov	x23, x20
    3750:      	b	0x375c <_stogir.pipeline.prepare-checked+0xd28>
    3754:      	mov	x1, xzr
    3758:      	mov	x23, xzr
    375c:      	str	x1, [sp, #0x80]
    3760:      	mov	x0, x1
    3764:      	mov	x1, x20
    3768:      	str	x20, [sp, #0x38]
    376c:      	bl	0x376c <_stogir.pipeline.prepare-checked+0xd38>
		000000000000376c:  ARM64_RELOC_BRANCH26	_bzero
    3770:      	adrp	x21, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003770:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    3774:      	ldr	x16, [sp, #0x80]
    3778:      	mov	x0, xzr
    377c:      	ldr	x21, [x21]
		000000000000377c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    3780:      	ldp	x8, x9, [sp, #0x98]
    3784:      	ldp	x10, x11, [sp, #0x60]
    3788:      	mov	x1, xzr
    378c:      	mov	x19, xzr
    3790:      	mov	w20, #0x1               ; =1
    3794:      	mov	w22, #0x2               ; =2
    3798:      	add	x14, sp, #0x550
    379c:      	adrp	x15, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		000000000000379c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    37a0:      	add	x15, x15, #0x0
		00000000000037a0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    37a4:      	sub	x17, x29, #0xc0
    37a8:      	cmp	x19, x10
    37ac:      	b.ge	0x37c0 <_stogir.pipeline.prepare-checked+0xd8c>
    37b0:      	ldr	w24, [x11, x19, lsl #2]
    37b4:      	add	x19, x19, #0x1
    37b8:      	mov	w12, #0x1               ; =1
    37bc:      	b	0x37c4 <_stogir.pipeline.prepare-checked+0xd90>
    37c0:      	mov	x12, xzr
    37c4:      	cbz	w12, 0x388c <_stogir.pipeline.prepare-checked+0xe58>
    37c8:      	cmp	w24, #0x1
    37cc:      	b.lt	0x37a8 <_stogir.pipeline.prepare-checked+0xd74>
    37d0:      	ldr	x13, [x9, #0x8]
    37d4:      	and	x12, x24, #0x7fffffff
    37d8:      	cmp	x13, x12
    37dc:      	b.le	0x37a8 <_stogir.pipeline.prepare-checked+0xd74>
    37e0:      	ldr	x13, [x9, #0x80]
    37e4:      	cmp	x13, x12
    37e8:      	b.le	0x37a8 <_stogir.pipeline.prepare-checked+0xd74>
    37ec:      	ldr	x13, [x9, #0x78]
    37f0:      	ldr	w13, [x13, x12, lsl #2]
    37f4:      	tbnz	w13, #0x1f, 0x37a8 <_stogir.pipeline.prepare-checked+0xd74>
    37f8:      	ldrb	w13, [x16, x12]
    37fc:      	tbnz	w13, #0x0, 0x37a8 <_stogir.pipeline.prepare-checked+0xd74>
    3800:      	strb	w20, [x16, x12]
    3804:      	ldr	x2, [sp, #0x560]
    3808:      	cmp	x0, x2
    380c:      	b.lt	0x387c <_stogir.pipeline.prepare-checked+0xe48>
    3810:      	lsl	x8, x2, #1
    3814:      	cmp	x2, #0x0
    3818:      	mov	x25, x23
    381c:      	mov	x26, x0
    3820:      	csel	x23, x22, x8, eq
    3824:      	add	x8, sp, #0x550
    3828:      	ldur	q0, [x8, #0x18]
    382c:      	cmp	x23, x2
    3830:      	str	q0, [x17, #0x30]
    3834:      	b.le	0x3858 <_stogir.pipeline.prepare-checked+0xe24>
    3838:      	sub	x0, x29, #0x90
    383c:      	mov	x3, x23
    3840:      	mov	x4, x21
    3844:      	mov	w5, #0x4                ; =4
    3848:      	mov	w6, #0x4                ; =4
    384c:      	bl	0x384c <_stogir.pipeline.prepare-checked+0xe18>
		000000000000384c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3850:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    3854:      	str	x23, [sp, #0x560]
    3858:      	ldp	x8, x9, [sp, #0x98]
    385c:      	add	x14, sp, #0x550
    3860:      	ldp	x10, x11, [sp, #0x60]
    3864:      	adrp	x15, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003864:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3868:      	add	x15, x15, #0x0
		0000000000003868:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    386c:      	ldr	x16, [sp, #0x80]
    3870:      	mov	x23, x25
    3874:      	sub	x17, x29, #0xc0
    3878:      	mov	x0, x26
    387c:      	str	w24, [x1, x0, lsl #2]
    3880:      	add	x0, x0, #0x1
    3884:      	str	x0, [sp, #0x558]
    3888:      	b	0x37a8 <_stogir.pipeline.prepare-checked+0xd74>
    388c:      	cmp	x0, #0x1
    3890:      	str	x23, [sp, #0x58]
    3894:      	str	x1, [sp, #0x550]
    3898:      	b.lt	0x3a54 <_stogir.pipeline.prepare-checked+0x1020>
    389c:      	mov	x20, xzr
    38a0:      	mov	w26, #0x82              ; =130
    38a4:      	mov	w12, #0x5               ; =5
    38a8:      	mov	w22, #0x1               ; =1
    38ac:      	mov	w13, #0x5e1c            ; =24092
    38b0:      	mov	w3, #0x2                ; =2
    38b4:      	b	0x38cc <_stogir.pipeline.prepare-checked+0xe98>
    38b8:      	add	x20, x20, #0x1
    38bc:      	str	x0, [sp, #0x558]
    38c0:      	cmp	x20, x0
    38c4:      	str	x1, [sp, #0x550]
    38c8:      	b.ge	0x3a54 <_stogir.pipeline.prepare-checked+0x1020>
    38cc:      	ldrsw	x28, [x1, x20, lsl #2]
    38d0:      	ldr	x10, [x9, #0x78]
    38d4:      	ldr	w24, [x10, x28, lsl #2]
    38d8:      	cmp	w24, #0x1
    38dc:      	b.lt	0x38b8 <_stogir.pipeline.prepare-checked+0xe84>
    38e0:      	ldr	x10, [x9]
    38e4:      	lsl	x11, x28, #4
    38e8:      	mov	w27, #0x1               ; =1
    38ec:      	ldrb	w19, [x10, x11]
    38f0:      	b	0x3934 <_stogir.pipeline.prepare-checked+0xf00>
    38f4:      	ldp	x8, x9, [sp, #0x98]
    38f8:      	add	x14, sp, #0x550
    38fc:      	ldr	x16, [sp, #0x80]
    3900:      	adrp	x15, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003900:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3904:      	add	x15, x15, #0x0
		0000000000003904:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3908:      	sub	x17, x29, #0xc0
    390c:      	mov	x0, x23
    3910:      	mov	w12, #0x5               ; =5
    3914:      	mov	w13, #0x5e1c            ; =24092
    3918:      	mov	w3, #0x2                ; =2
    391c:      	str	x21, [sp, #0x560]
    3920:      	str	w25, [x1, x0, lsl #2]
    3924:      	add	x0, x0, #0x1
    3928:      	add	w27, w27, #0x1
    392c:      	cmp	w27, w24
    3930:      	b.gt	0x38b8 <_stogir.pipeline.prepare-checked+0xe84>
    3934:      	cmp	w27, #0x1
    3938:      	ccmp	x19, x26, #0x2, ge
    393c:      	b.hi	0x3968 <_stogir.pipeline.prepare-checked+0xf34>
    3940:      	cmp	w27, #0x5
    3944:      	ldr	w11, [x15, x19, lsl #2]
    3948:      	csel	w10, w27, w12, lo
    394c:      	lsl	w10, w10, #2
    3950:      	sub	w10, w10, #0x4
    3954:      	lsr	w10, w11, w10
    3958:      	and	w10, w10, #0xf
    395c:      	cmp	w10, #0xf
    3960:      	b.ne	0x3974 <_stogir.pipeline.prepare-checked+0xf40>
    3964:      	b	0x3928 <_stogir.pipeline.prepare-checked+0xef4>
    3968:      	mov	w10, wzr
    396c:      	cmp	w10, #0xf
    3970:      	b.eq	0x3928 <_stogir.pipeline.prepare-checked+0xef4>
    3974:      	lsl	w10, w22, w10
    3978:      	and	w10, w10, w13
    397c:      	cbz	w10, 0x3928 <_stogir.pipeline.prepare-checked+0xef4>
    3980:      	cmp	w28, #0x1
    3984:      	b.lt	0x39b8 <_stogir.pipeline.prepare-checked+0xf84>
    3988:      	ldr	x10, [x9, #0x8]
    398c:      	cmp	x10, x28
    3990:      	b.le	0x39b8 <_stogir.pipeline.prepare-checked+0xf84>
    3994:      	ldr	x10, [x9, #0x80]
    3998:      	cmp	x10, x28
    399c:      	b.le	0x39b8 <_stogir.pipeline.prepare-checked+0xf84>
    39a0:      	ldr	x10, [x9, #0x78]
    39a4:      	ldr	w10, [x10, x28, lsl #2]
    39a8:      	cmp	w27, w10
    39ac:      	ccmp	w10, #0x0, #0x8, ls
    39b0:      	ccmp	w27, #0x1, #0x8, pl
    39b4:      	b.ge	0x3a30 <_stogir.pipeline.prepare-checked+0xffc>
    39b8:      	mov	x10, xzr
    39bc:      	cmp	w10, #0x1
    39c0:      	b.ne	0x3928 <_stogir.pipeline.prepare-checked+0xef4>
    39c4:      	cmp	w25, #0x1
    39c8:      	b.lt	0x3928 <_stogir.pipeline.prepare-checked+0xef4>
    39cc:      	and	x10, x25, #0x7fffffff
    39d0:      	ldrb	w11, [x16, x10]
    39d4:      	tbnz	w11, #0x0, 0x3928 <_stogir.pipeline.prepare-checked+0xef4>
    39d8:      	strb	w22, [x16, x10]
    39dc:      	ldr	x2, [sp, #0x560]
    39e0:      	cmp	x0, x2
    39e4:      	b.lt	0x3920 <_stogir.pipeline.prepare-checked+0xeec>
    39e8:      	lsl	x10, x2, #1
    39ec:      	cmp	x2, #0x0
    39f0:      	csel	x21, x3, x10, eq
    39f4:      	add	x10, sp, #0x550
    39f8:      	ldur	q0, [x10, #0x18]
    39fc:      	cmp	x21, x2
    3a00:      	str	q0, [x17, #0x30]
    3a04:      	b.le	0x3920 <_stogir.pipeline.prepare-checked+0xeec>
    3a08:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003a08:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    3a0c:      	mov	x23, x0
    3a10:      	sub	x0, x29, #0x90
    3a14:      	ldr	x4, [x4]
		0000000000003a14:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    3a18:      	mov	x3, x21
    3a1c:      	mov	w5, #0x4                ; =4
    3a20:      	mov	w6, #0x4                ; =4
    3a24:      	bl	0x3a24 <_stogir.pipeline.prepare-checked+0xff0>
		0000000000003a24:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3a28:      	cbnz	w0, 0x38f4 <_stogir.pipeline.prepare-checked+0xec0>
    3a2c:      	b	0x72ac <_stogir.pipeline.prepare-checked+0x4878>
    3a30:      	add	w10, w28, w27, lsr #2
    3a34:      	ldr	x11, [x9]
    3a38:      	add	x10, x11, w10, uxtw #4
    3a3c:      	and	w11, w27, #0x3
    3a40:      	ldr	w25, [x10, w11, uxtw #2]
    3a44:      	mov	w10, #0x1               ; =1
    3a48:      	cmp	w10, #0x1
    3a4c:      	b.ne	0x3928 <_stogir.pipeline.prepare-checked+0xef4>
    3a50:      	b	0x39c4 <_stogir.pipeline.prepare-checked+0xf90>
    3a54:      	cbz	x0, 0x3a5c <_stogir.pipeline.prepare-checked+0x1028>
    3a58:      	str	xzr, [sp, #0x558]
    3a5c:      	ldr	x2, [sp, #0x560]
    3a60:      	ldr	x20, [sp, #0x58]
    3a64:      	ldr	x19, [sp, #0x38]
    3a68:      	cmp	x2, #0x1
    3a6c:      	b.lt	0x3a9c <_stogir.pipeline.prepare-checked+0x1068>
    3a70:      	adrp	x3, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003a70:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    3a74:      	add	x8, sp, #0x550
    3a78:      	mov	w4, #0x4                ; =4
    3a7c:      	ldr	x3, [x3]
		0000000000003a7c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    3a80:      	add	x0, x8, #0x18
    3a84:      	mov	w5, #0x4                ; =4
    3a88:      	bl	0x3a88 <_stogir.pipeline.prepare-checked+0x1054>
		0000000000003a88:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3a8c:      	ldp	x8, x9, [sp, #0x98]
    3a90:      	sub	x17, x29, #0xc0
    3a94:      	ldr	x16, [sp, #0x80]
    3a98:      	add	x14, sp, #0x550
    3a9c:      	ldr	q1, [sp, #0x70]
    3aa0:      	add	x10, sp, #0x1c0
    3aa4:      	ldr	x24, [x9, #0x8]
    3aa8:      	ldr	q0, [x8]
    3aac:      	str	x16, [sp, #0x238]
    3ab0:      	stur	q1, [x10, #0x90]
    3ab4:      	ldr	q1, [x8]
    3ab8:      	cmp	x24, #0x1
    3abc:      	str	x19, [sp, #0x240]
    3ac0:      	str	x20, [sp, #0x248]
    3ac4:      	str	q0, [x17, #0x30]
    3ac8:      	str	xzr, [sp, #0x550]
    3acc:      	str	xzr, [sp, #0x560]
    3ad0:      	str	q1, [sp, #0x70]
    3ad4:      	str	xzr, [sp, #0x558]
    3ad8:      	stur	q0, [x14, #0x18]
    3adc:      	b.lt	0x3b1c <_stogir.pipeline.prepare-checked+0x10e8>
    3ae0:      	ldr	q0, [x8]
    3ae4:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003ae4:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.uses.Range.0
    3ae8:      	sub	x0, x29, #0xc0
    3aec:      	mov	x1, xzr
    3af0:      	mov	x2, xzr
    3af4:      	mov	x3, x24
    3af8:      	str	q0, [x17]
    3afc:      	mov	w5, #0x10               ; =16
    3b00:      	mov	w6, #0x8                ; =8
    3b04:      	ldr	x4, [x4]
		0000000000003b04:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.uses.Range.0
    3b08:      	bl	0x3b08 <_stogir.pipeline.prepare-checked+0x10d4>
		0000000000003b08:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3b0c:      	cbz	w0, 0x732c <_stogir.pipeline.prepare-checked+0x48f8>
    3b10:      	mov	x25, x1
    3b14:      	mov	x22, x24
    3b18:      	b	0x3b24 <_stogir.pipeline.prepare-checked+0x10f0>
    3b1c:      	mov	x25, xzr
    3b20:      	mov	x22, xzr
    3b24:      	lsl	x1, x24, #4
    3b28:      	mov	x0, x25
    3b2c:      	add	x19, sp, #0x550
    3b30:      	bl	0x3b30 <_stogir.pipeline.prepare-checked+0x10fc>
		0000000000003b30:  ARM64_RELOC_BRANCH26	_bzero
    3b34:      	ldr	x8, [sp, #0xa0]
    3b38:      	ldr	x26, [x8, #0x8]
    3b3c:      	lsl	x21, x26, #3
    3b40:      	cmp	x26, #0x1
    3b44:      	b.lt	0x3b84 <_stogir.pipeline.prepare-checked+0x1150>
    3b48:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003b48:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    3b4c:      	add	x0, x19, #0x18
    3b50:      	mov	x1, xzr
    3b54:      	ldr	x4, [x4]
		0000000000003b54:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    3b58:      	mov	x2, xzr
    3b5c:      	mov	x3, x26
    3b60:      	mov	w5, #0x8                ; =8
    3b64:      	mov	w6, #0x8                ; =8
    3b68:      	bl	0x3b68 <_stogir.pipeline.prepare-checked+0x1134>
		0000000000003b68:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3b6c:      	cbz	w0, 0x733c <_stogir.pipeline.prepare-checked+0x4908>
    3b70:      	mov	x27, x1
    3b74:      	mov	x28, x26
    3b78:      	str	x1, [sp, #0x550]
    3b7c:      	str	x26, [sp, #0x560]
    3b80:      	b	0x3b8c <_stogir.pipeline.prepare-checked+0x1158>
    3b84:      	mov	x28, xzr
    3b88:      	mov	x27, xzr
    3b8c:      	mov	x0, x27
    3b90:      	mov	x1, x21
    3b94:      	bl	0x3b94 <_stogir.pipeline.prepare-checked+0x1160>
		0000000000003b94:  ARM64_RELOC_BRANCH26	_bzero
    3b98:      	ldr	x8, [sp, #0xa0]
    3b9c:      	adrp	x1, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003b9c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3ba0:      	add	x1, x1, #0x0
		0000000000003ba0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3ba4:      	str	x26, [sp, #0x558]
    3ba8:      	ldr	x14, [x8, #0x8]
    3bac:      	cmp	x14, #0x2
    3bb0:      	b.lt	0x3ca0 <_stogir.pipeline.prepare-checked+0x126c>
    3bb4:      	mov	w9, #0x1                ; =1
    3bb8:      	mov	w10, #0x5               ; =5
    3bbc:      	mov	w11, #0x5e1c            ; =24092
    3bc0:      	mov	w12, #0x1               ; =1
    3bc4:      	b	0x3be4 <_stogir.pipeline.prepare-checked+0x11b0>
    3bc8:      	ldr	x14, [x8, #0x8]
    3bcc:      	adds	x15, x13, #0x4
    3bd0:      	add	x13, x13, #0x7
    3bd4:      	csel	x13, x13, x15, mi
    3bd8:      	add	x12, x12, x13, asr #2
    3bdc:      	cmp	x12, x14
    3be0:      	b.ge	0x3ca0 <_stogir.pipeline.prepare-checked+0x126c>
    3be4:      	ldr	x13, [x8, #0x78]
    3be8:      	ldrsw	x13, [x13, x12, lsl #2]
    3bec:      	cmp	w13, #0x1
    3bf0:      	b.lt	0x3bcc <_stogir.pipeline.prepare-checked+0x1198>
    3bf4:      	ldr	x14, [x8]
    3bf8:      	lsl	x15, x12, #4
    3bfc:      	ldrb	w14, [x14, x15]
    3c00:      	mov	w15, #0x1               ; =1
    3c04:      	ldr	w14, [x1, x14, lsl #2]
    3c08:      	b	0x3c18 <_stogir.pipeline.prepare-checked+0x11e4>
    3c0c:      	add	w15, w15, #0x1
    3c10:      	cmp	w15, w13
    3c14:      	b.gt	0x3bc8 <_stogir.pipeline.prepare-checked+0x1194>
    3c18:      	cmp	w15, #0x1
    3c1c:      	b.lt	0x3c44 <_stogir.pipeline.prepare-checked+0x1210>
    3c20:      	cmp	w15, #0x5
    3c24:      	csel	w16, w15, w10, lo
    3c28:      	lsl	w16, w16, #2
    3c2c:      	sub	w16, w16, #0x4
    3c30:      	lsr	w16, w14, w16
    3c34:      	and	w16, w16, #0xf
    3c38:      	cmp	w16, #0xf
    3c3c:      	b.ne	0x3c50 <_stogir.pipeline.prepare-checked+0x121c>
    3c40:      	b	0x3c0c <_stogir.pipeline.prepare-checked+0x11d8>
    3c44:      	mov	w16, wzr
    3c48:      	cmp	w16, #0xf
    3c4c:      	b.eq	0x3c0c <_stogir.pipeline.prepare-checked+0x11d8>
    3c50:      	lsl	w16, w9, w16
    3c54:      	and	w16, w16, w11
    3c58:      	cbz	w16, 0x3c0c <_stogir.pipeline.prepare-checked+0x11d8>
    3c5c:      	ldr	x16, [x8]
    3c60:      	add	w17, w15, #0x3
    3c64:      	cmp	w15, #0x0
    3c68:      	csel	w17, w17, w15, mi
    3c6c:      	asr	w0, w17, #2
    3c70:      	add	x16, x16, x12, lsl #4
    3c74:      	and	w17, w17, #0xfffffffc
    3c78:      	sub	w17, w15, w17
    3c7c:      	add	x16, x16, w0, sxtw #4
    3c80:      	ldr	w16, [x16, w17, sxtw #2]
    3c84:      	cmp	w16, #0x1
    3c88:      	b.lt	0x3c0c <_stogir.pipeline.prepare-checked+0x11d8>
    3c8c:      	add	x16, x25, x16, lsl #4
    3c90:      	ldr	x17, [x16, #0x8]
    3c94:      	add	x17, x17, #0x1
    3c98:      	str	x17, [x16, #0x8]
    3c9c:      	b	0x3c0c <_stogir.pipeline.prepare-checked+0x11d8>
    3ca0:      	cmp	x24, #0x1
    3ca4:      	b.lt	0x3d14 <_stogir.pipeline.prepare-checked+0x12e0>
    3ca8:      	mov	x23, xzr
    3cac:      	add	x8, x25, #0x8
    3cb0:      	mov	x9, x27
    3cb4:      	mov	x10, x24
    3cb8:      	ldr	x11, [x8]
    3cbc:      	stur	x23, [x8, #-0x8]
    3cc0:      	subs	x10, x10, #0x1
    3cc4:      	str	x23, [x9], #0x8
    3cc8:      	add	x8, x8, #0x10
    3ccc:      	add	x23, x11, x23
    3cd0:      	b.ne	0x3cb8 <_stogir.pipeline.prepare-checked+0x1284>
    3cd4:      	add	x21, sp, #0x550
    3cd8:      	cmp	x23, #0x1
    3cdc:      	b.lt	0x3d1c <_stogir.pipeline.prepare-checked+0x12e8>
    3ce0:      	adrp	x4, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003ce0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.uses.Use.0
    3ce4:      	sub	x0, x29, #0x90
    3ce8:      	mov	x1, xzr
    3cec:      	ldr	x4, [x4]
		0000000000003cec:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.uses.Use.0
    3cf0:      	mov	x2, xzr
    3cf4:      	mov	x3, x23
    3cf8:      	mov	w5, #0x8                ; =8
    3cfc:      	mov	w6, #0x4                ; =4
    3d00:      	bl	0x3d00 <_stogir.pipeline.prepare-checked+0x12cc>
		0000000000003d00:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3d04:      	cbz	w0, 0x734c <_stogir.pipeline.prepare-checked+0x4918>
    3d08:      	mov	x19, x1
    3d0c:      	mov	x20, x23
    3d10:      	b	0x3d24 <_stogir.pipeline.prepare-checked+0x12f0>
    3d14:      	add	x21, sp, #0x550
    3d18:      	mov	x23, xzr
    3d1c:      	mov	x19, xzr
    3d20:      	mov	x20, xzr
    3d24:      	lsl	x1, x23, #3
    3d28:      	mov	x0, x19
    3d2c:      	bl	0x3d2c <_stogir.pipeline.prepare-checked+0x12f8>
		0000000000003d2c:  ARM64_RELOC_BRANCH26	_bzero
    3d30:      	ldp	x9, x8, [sp, #0x98]
    3d34:      	add	x3, sp, #0x550
    3d38:      	adrp	x5, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003d38:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3d3c:      	add	x5, x5, #0x0
		0000000000003d3c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3d40:      	sub	x4, x29, #0xc0
    3d44:      	ldr	x15, [x8, #0x8]
    3d48:      	cmp	x15, #0x2
    3d4c:      	b.lt	0x3e44 <_stogir.pipeline.prepare-checked+0x1410>
    3d50:      	mov	w10, #0x1               ; =1
    3d54:      	mov	w11, #0x5               ; =5
    3d58:      	mov	w12, #0x5e1c            ; =24092
    3d5c:      	mov	w13, #0x1               ; =1
    3d60:      	b	0x3d80 <_stogir.pipeline.prepare-checked+0x134c>
    3d64:      	ldr	x15, [x8, #0x8]
    3d68:      	adds	x16, x14, #0x4
    3d6c:      	add	x14, x14, #0x7
    3d70:      	csel	x14, x14, x16, mi
    3d74:      	add	x13, x13, x14, asr #2
    3d78:      	cmp	x13, x15
    3d7c:      	b.ge	0x3e44 <_stogir.pipeline.prepare-checked+0x1410>
    3d80:      	ldr	x14, [x8, #0x78]
    3d84:      	ldrsw	x14, [x14, x13, lsl #2]
    3d88:      	cmp	w14, #0x1
    3d8c:      	b.lt	0x3d68 <_stogir.pipeline.prepare-checked+0x1334>
    3d90:      	ldr	x15, [x8]
    3d94:      	lsl	x16, x13, #4
    3d98:      	mov	w17, #0x1               ; =1
    3d9c:      	ldrb	w15, [x15, x16]
    3da0:      	mov	w16, w13
    3da4:      	ldr	w15, [x5, x15, lsl #2]
    3da8:      	b	0x3db8 <_stogir.pipeline.prepare-checked+0x1384>
    3dac:      	add	w17, w17, #0x1
    3db0:      	cmp	w17, w14
    3db4:      	b.gt	0x3d64 <_stogir.pipeline.prepare-checked+0x1330>
    3db8:      	cmp	w17, #0x1
    3dbc:      	b.lt	0x3de4 <_stogir.pipeline.prepare-checked+0x13b0>
    3dc0:      	cmp	w17, #0x5
    3dc4:      	csel	w0, w17, w11, lo
    3dc8:      	lsl	w0, w0, #2
    3dcc:      	sub	w0, w0, #0x4
    3dd0:      	lsr	w0, w15, w0
    3dd4:      	and	w0, w0, #0xf
    3dd8:      	cmp	w0, #0xf
    3ddc:      	b.ne	0x3df0 <_stogir.pipeline.prepare-checked+0x13bc>
    3de0:      	b	0x3dac <_stogir.pipeline.prepare-checked+0x1378>
    3de4:      	mov	w0, wzr
    3de8:      	cmp	w0, #0xf
    3dec:      	b.eq	0x3dac <_stogir.pipeline.prepare-checked+0x1378>
    3df0:      	lsl	w0, w10, w0
    3df4:      	and	w0, w0, w12
    3df8:      	cbz	w0, 0x3dac <_stogir.pipeline.prepare-checked+0x1378>
    3dfc:      	ldr	x0, [x8]
    3e00:      	add	w1, w17, #0x3
    3e04:      	cmp	w17, #0x0
    3e08:      	csel	w1, w1, w17, mi
    3e0c:      	asr	w2, w1, #2
    3e10:      	add	x0, x0, x13, lsl #4
    3e14:      	and	w1, w1, #0xfffffffc
    3e18:      	sub	w1, w17, w1
    3e1c:      	add	x0, x0, w2, sxtw #4
    3e20:      	ldr	w0, [x0, w1, sxtw #2]
    3e24:      	cmp	w0, #0x1
    3e28:      	b.lt	0x3dac <_stogir.pipeline.prepare-checked+0x1378>
    3e2c:      	ldr	x1, [x27, x0, lsl #3]
    3e30:      	orr	x2, x16, x17, lsl #32
    3e34:      	str	x2, [x19, x1, lsl #3]
    3e38:      	add	x1, x1, #0x1
    3e3c:      	str	x1, [x27, x0, lsl #3]
    3e40:      	b	0x3dac <_stogir.pipeline.prepare-checked+0x1378>
    3e44:      	cbz	x26, 0x3e4c <_stogir.pipeline.prepare-checked+0x1418>
    3e48:      	str	xzr, [sp, #0x558]
    3e4c:      	cmp	x28, #0x1
    3e50:      	b.lt	0x3e88 <_stogir.pipeline.prepare-checked+0x1454>
    3e54:      	adrp	x3, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003e54:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    3e58:      	add	x0, x21, #0x18
    3e5c:      	mov	x1, x27
    3e60:      	ldr	x3, [x3]
		0000000000003e60:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    3e64:      	mov	x2, x28
    3e68:      	mov	w4, #0x8                ; =8
    3e6c:      	mov	w5, #0x8                ; =8
    3e70:      	bl	0x3e70 <_stogir.pipeline.prepare-checked+0x143c>
		0000000000003e70:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3e74:      	ldp	x9, x8, [sp, #0x98]
    3e78:      	sub	x4, x29, #0xc0
    3e7c:      	adrp	x5, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003e7c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3e80:      	add	x5, x5, #0x0
		0000000000003e80:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3e84:      	add	x3, sp, #0x550
    3e88:      	ldr	q0, [sp, #0x70]
    3e8c:      	add	x13, sp, #0x1c0
    3e90:      	add	x12, sp, #0x2b0
    3e94:      	str	xzr, [sp, #0x308]
    3e98:      	add	x11, sp, #0x219
    3e9c:      	ldr	x28, [sp, #0x58]
    3ea0:      	stur	q0, [x13, #0xb8]
    3ea4:      	ldr	q0, [x9]
    3ea8:      	mov	x6, xzr
    3eac:      	str	xzr, [sp, #0x310]
    3eb0:      	stur	q0, [x12, #0x70]
    3eb4:      	ldr	x10, [sp, #0x328]
    3eb8:      	str	xzr, [sp, #0x318]
    3ebc:      	ldur	q1, [x11, #0xff]
    3ec0:      	stur	q0, [x12, #0x98]
    3ec4:      	ldr	q0, [x4, #0x30]
    3ec8:      	str	x10, [sp, #0x2d0]
    3ecc:      	add	x10, sp, #0x209
    3ed0:      	ldr	x11, [sp, #0x350]
    3ed4:      	ldur	q2, [x10, #0xff]
    3ed8:      	str	xzr, [sp, #0x340]
    3edc:      	ldr	x10, [sp, #0xd8]
    3ee0:      	str	xzr, [sp, #0x338]
    3ee4:      	str	xzr, [sp, #0x330]
    3ee8:      	cmp	x10, #0x1
    3eec:      	stp	q2, q1, [x13, #0xf0]
    3ef0:      	str	q0, [x13, #0xe0]
    3ef4:      	ldp	q1, q0, [x12, #0x80]
    3ef8:      	stp	x20, x19, [sp, #0x60]
    3efc:      	str	x19, [sp, #0x288]
    3f00:      	mov	x19, xzr
    3f04:      	stur	q0, [x12, #0x38]
    3f08:      	ldr	q0, [x9]
    3f0c:      	str	x20, [sp, #0x298]
    3f10:      	add	x20, sp, #0x550
    3f14:      	str	x25, [sp, #0x260]
    3f18:      	str	x24, [sp, #0x268]
    3f1c:      	str	x22, [sp, #0x270]
    3f20:      	str	x23, [sp, #0x290]
    3f24:      	str	x11, [sp, #0x2f8]
    3f28:      	stur	q1, [x12, #0x28]
    3f2c:      	str	xzr, [sp, #0x558]
    3f30:      	str	xzr, [sp, #0x550]
    3f34:      	str	xzr, [sp, #0x560]
    3f38:      	stur	q0, [x3, #0x18]
    3f3c:      	b.lt	0x3fd8 <_stogir.pipeline.prepare-checked+0x15a4>
    3f40:      	adrp	x23, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003f40:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    3f44:      	mov	w21, #0x2               ; =2
    3f48:      	ldr	x23, [x23]
		0000000000003f48:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    3f4c:      	b	0x3f68 <_stogir.pipeline.prepare-checked+0x1534>
    3f50:      	str	w22, [x6, x19, lsl #2]
    3f54:      	add	x19, x19, #0x1
    3f58:      	ldr	x10, [sp, #0xd8]
    3f5c:      	str	x19, [sp, #0x558]
    3f60:      	cmp	x19, x10
    3f64:      	b.ge	0x3fd8 <_stogir.pipeline.prepare-checked+0x15a4>
    3f68:      	ldr	x10, [sp, #0xd0]
    3f6c:      	ldr	x2, [sp, #0x560]
    3f70:      	ldr	w22, [x10, x19, lsl #2]
    3f74:      	cmp	x19, x2
    3f78:      	b.lt	0x3f50 <_stogir.pipeline.prepare-checked+0x151c>
    3f7c:      	lsl	x10, x2, #1
    3f80:      	cmp	x2, #0x0
    3f84:      	ldur	q0, [x20, #0x18]
    3f88:      	csel	x25, x21, x10, eq
    3f8c:      	str	q0, [x4, #0x30]
    3f90:      	cmp	x25, x2
    3f94:      	b.le	0x3f50 <_stogir.pipeline.prepare-checked+0x151c>
    3f98:      	sub	x0, x29, #0x90
    3f9c:      	mov	x1, x6
    3fa0:      	mov	x3, x25
    3fa4:      	mov	x4, x23
    3fa8:      	mov	w5, #0x4                ; =4
    3fac:      	mov	w6, #0x4                ; =4
    3fb0:      	bl	0x3fb0 <_stogir.pipeline.prepare-checked+0x157c>
		0000000000003fb0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    3fb4:      	cbz	w0, 0x41c4 <_stogir.pipeline.prepare-checked+0x1790>
    3fb8:      	ldp	x9, x8, [sp, #0x98]
    3fbc:      	mov	x6, x1
    3fc0:      	add	x3, sp, #0x550
    3fc4:      	adrp	x5, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003fc4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3fc8:      	add	x5, x5, #0x0
		0000000000003fc8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3fcc:      	sub	x4, x29, #0xc0
    3fd0:      	str	x25, [sp, #0x560]
    3fd4:      	b	0x3f50 <_stogir.pipeline.prepare-checked+0x151c>
    3fd8:      	ldr	x10, [x8, #0x8]
    3fdc:      	str	x6, [sp, #0x550]
    3fe0:      	cmp	x10, #0x2
    3fe4:      	b.lt	0x40e8 <_stogir.pipeline.prepare-checked+0x16b4>
    3fe8:      	adrp	x12, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003fe8:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    3fec:      	add	x12, x12, #0x0
		0000000000003fec:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    3ff0:      	adrp	x23, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003ff0:  ARM64_RELOC_PAGE21	l_str.654
    3ff4:      	add	x23, x23, #0x0
		0000000000003ff4:  ARM64_RELOC_PAGEOFF12	l_str.654
    3ff8:      	mov	w13, #0x1               ; =1
    3ffc:      	adrp	x11, 0x3000 <_stogir.pipeline.prepare-checked+0x5cc>
		0000000000003ffc:  ARM64_RELOC_PAGE21	l_str.655
    4000:      	add	x11, x11, #0x0
		0000000000004000:  ARM64_RELOC_PAGEOFF12	l_str.655
    4004:      	mov	w26, #0x19              ; =25
    4008:      	adrp	x14, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004008:  ARM64_RELOC_PAGE21	l_str.657
    400c:      	add	x14, x14, #0x0
		000000000000400c:  ARM64_RELOC_PAGEOFF12	l_str.657
    4010:      	b	0x402c <_stogir.pipeline.prepare-checked+0x15f8>
    4014:      	adds	x16, x15, #0x4
    4018:      	add	x15, x15, #0x7
    401c:      	csel	x15, x15, x16, mi
    4020:      	add	x13, x13, x15, asr #2
    4024:      	cmp	x13, x10
    4028:      	b.ge	0x40e0 <_stogir.pipeline.prepare-checked+0x16ac>
    402c:      	ldr	x16, [x8]
    4030:      	lsl	x15, x13, #4
    4034:      	ldr	x17, [x8, #0x78]
    4038:      	ldrb	w0, [x16, x15]
    403c:      	ldrsw	x15, [x17, x13, lsl #2]
    4040:      	cmp	x0, #0x82
    4044:      	b.hi	0x4014 <_stogir.pipeline.prepare-checked+0x15e0>
    4048:      	ldrb	w0, [x12, x0]
    404c:      	tbz	w0, #0x5, 0x4014 <_stogir.pipeline.prepare-checked+0x15e0>
    4050:      	cmp	w13, #0x1
    4054:      	b.lt	0x408c <_stogir.pipeline.prepare-checked+0x1658>
    4058:      	and	x0, x13, #0x7fffffff
    405c:      	cmp	x10, x0
    4060:      	b.le	0x408c <_stogir.pipeline.prepare-checked+0x1658>
    4064:      	ldr	x1, [x8, #0x80]
    4068:      	cmp	x1, x0
    406c:      	b.le	0x408c <_stogir.pipeline.prepare-checked+0x1658>
    4070:      	ldr	w1, [x17, x0, lsl #2]
    4074:      	cmp	w1, #0x1
    4078:      	b.lt	0x408c <_stogir.pipeline.prepare-checked+0x1658>
    407c:      	add	x0, x16, x0, lsl #4
    4080:      	mov	w1, #0x1                ; =1
    4084:      	ldr	w0, [x0, #0x4]
    4088:      	b	0x4090 <_stogir.pipeline.prepare-checked+0x165c>
    408c:      	mov	x1, xzr
    4090:      	cbz	w1, 0x4844 <_stogir.pipeline.prepare-checked+0x1e10>
    4094:      	cmp	w0, #0x1
    4098:      	b.lt	0x483c <_stogir.pipeline.prepare-checked+0x1e08>
    409c:      	and	x1, x0, #0x7fffffff
    40a0:      	cmp	x10, x1
    40a4:      	b.le	0x483c <_stogir.pipeline.prepare-checked+0x1e08>
    40a8:      	ldr	x10, [x8, #0x80]
    40ac:      	cmp	x10, x1
    40b0:      	b.le	0x483c <_stogir.pipeline.prepare-checked+0x1e08>
    40b4:      	ldr	w10, [x17, x1, lsl #2]
    40b8:      	tbnz	w10, #0x1f, 0x483c <_stogir.pipeline.prepare-checked+0x1e08>
    40bc:      	lsl	x10, x1, #4
    40c0:      	ldr	w10, [x16, x10]
    40c4:      	and	w10, w10, #0xfe
    40c8:      	sub	w10, w10, #0x68
    40cc:      	cmp	w10, #0x9
    40d0:      	b.hi	0x5454 <_stogir.pipeline.prepare-checked+0x2a20>
    40d4:      	str	w0, [x6, x13, lsl #2]
    40d8:      	ldr	x10, [x8, #0x8]
    40dc:      	b	0x4014 <_stogir.pipeline.prepare-checked+0x15e0>
    40e0:      	ldr	x6, [sp, #0x550]
    40e4:      	ldr	x19, [sp, #0x558]
    40e8:      	ldr	q0, [x3, #0x10]
    40ec:      	add	x12, sp, #0x269
    40f0:      	ldr	x11, [sp, #0x570]
    40f4:      	cmp	x10, #0x1
    40f8:      	add	x22, sp, #0x550
    40fc:      	str	x6, [sp, #0x358]
    4100:      	stur	q0, [x12, #0xff]
    4104:      	ldr	q0, [x9]
    4108:      	str	x11, [sp, #0x378]
    410c:      	str	x19, [sp, #0x360]
    4110:      	str	xzr, [sp, #0x560]
    4114:      	str	xzr, [sp, #0x550]
    4118:      	str	xzr, [sp, #0x558]
    411c:      	stur	q0, [x3, #0x18]
    4120:      	stp	xzr, xzr, [x29, #-0x88]
    4124:      	stur	xzr, [x29, #-0x90]
    4128:      	stur	q0, [x4, #0x48]
    412c:      	str	x6, [sp, #0x70]
    4130:      	b.lt	0x4464 <_stogir.pipeline.prepare-checked+0x1a30>
    4134:      	adrp	x23, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004134:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    4138:      	mov	x19, xzr
    413c:      	mov	x1, xzr
    4140:      	ldr	x23, [x23]
		0000000000004140:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    4144:      	mov	w20, #-0x1              ; =-1
    4148:      	mov	w21, #0x2               ; =2
    414c:      	b	0x4180 <_stogir.pipeline.prepare-checked+0x174c>
    4150:      	ldr	x8, [sp, #0xa0]
    4154:      	ldr	x6, [sp, #0x70]
    4158:      	adrp	x5, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004158:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    415c:      	add	x5, x5, #0x0
		000000000000415c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    4160:      	sub	x4, x29, #0xc0
    4164:      	str	x25, [sp, #0x560]
    4168:      	str	w20, [x1, x19, lsl #2]
    416c:      	add	x19, x19, #0x1
    4170:      	ldr	x9, [x8, #0x8]
    4174:      	str	x19, [sp, #0x558]
    4178:      	cmp	x19, x9
    417c:      	b.ge	0x41d4 <_stogir.pipeline.prepare-checked+0x17a0>
    4180:      	ldr	x2, [sp, #0x560]
    4184:      	cmp	x19, x2
    4188:      	b.lt	0x4168 <_stogir.pipeline.prepare-checked+0x1734>
    418c:      	lsl	x9, x2, #1
    4190:      	cmp	x2, #0x0
    4194:      	ldur	q0, [x22, #0x18]
    4198:      	csel	x25, x21, x9, eq
    419c:      	str	q0, [x4]
    41a0:      	cmp	x25, x2
    41a4:      	b.le	0x4168 <_stogir.pipeline.prepare-checked+0x1734>
    41a8:      	sub	x0, x29, #0xc0
    41ac:      	mov	x3, x25
    41b0:      	mov	x4, x23
    41b4:      	mov	w5, #0x4                ; =4
    41b8:      	mov	w6, #0x4                ; =4
    41bc:      	bl	0x41bc <_stogir.pipeline.prepare-checked+0x1788>
		00000000000041bc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    41c0:      	cbnz	w0, 0x4150 <_stogir.pipeline.prepare-checked+0x171c>
    41c4:      	lsl	x1, x25, #2
    41c8:      	adrp	x0, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		00000000000041c8:  ARM64_RELOC_PAGE21	l_cstr.204
    41cc:      	add	x0, x0, #0x0
		00000000000041cc:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    41d0:      	bl	0x41d0 <_stogir.pipeline.prepare-checked+0x179c>
		00000000000041d0:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    41d4:      	mov	x10, x1
    41d8:      	ldur	x1, [x29, #-0x90]
    41dc:      	cmp	x9, #0x2
    41e0:      	str	x10, [sp, #0x38]
    41e4:      	str	x10, [sp, #0x550]
    41e8:      	b.lt	0x4468 <_stogir.pipeline.prepare-checked+0x1a34>
    41ec:      	mov	w7, wzr
    41f0:      	mov	x26, xzr
    41f4:      	mov	w27, #0x1               ; =1
    41f8:      	adrp	x23, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		00000000000041f8:  ARM64_RELOC_PAGE21	l_str.635
    41fc:      	add	x23, x23, #0x0
		00000000000041fc:  ARM64_RELOC_PAGEOFF12	l_str.635
    4200:      	adrp	x0, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004200:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    4204:      	add	x0, x0, #0x0
		0000000000004204:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    4208:      	mov	w3, #0x2                ; =2
    420c:      	mov	w25, #0x5               ; =5
    4210:      	mov	w24, #0x5e1c            ; =24092
    4214:      	mov	w30, #0x18              ; =24
    4218:      	adrp	x22, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004218:  ARM64_RELOC_PAGE21	l_str.636
    421c:      	add	x22, x22, #0x0
		000000000000421c:  ARM64_RELOC_PAGEOFF12	l_str.636
    4220:      	mov	w20, #0x1               ; =1
    4224:      	b	0x4258 <_stogir.pipeline.prepare-checked+0x1824>
    4228:      	ldr	x23, [sp, #0x30]
    422c:      	ldr	x28, [sp, #0x58]
    4230:      	add	x9, x19, #0x1
    4234:      	str	w20, [x1, x19, lsl #2]
    4238:      	stur	x9, [x29, #-0x88]
    423c:      	adds	x9, x21, #0x4
    4240:      	add	x10, x21, #0x7
    4244:      	csel	x9, x10, x9, mi
    4248:      	add	x20, x20, x9, asr #2
    424c:      	ldr	x9, [x8, #0x8]
    4250:      	cmp	x20, x9
    4254:      	b.ge	0x47f4 <_stogir.pipeline.prepare-checked+0x1dc0>
    4258:      	ldr	x11, [x8]
    425c:      	lsl	x10, x20, #4
    4260:      	ldr	x12, [x8, #0x78]
    4264:      	ldrb	w10, [x11, x10]
    4268:      	ldrsw	x21, [x12, x20, lsl #2]
    426c:      	cmp	x10, #0x82
    4270:      	b.hi	0x423c <_stogir.pipeline.prepare-checked+0x1808>
    4274:      	ldr	w13, [x6, x20, lsl #2]
    4278:      	cbnz	w13, 0x423c <_stogir.pipeline.prepare-checked+0x1808>
    427c:      	ldrb	w13, [x0, x10]
    4280:      	tbz	w13, #0x6, 0x423c <_stogir.pipeline.prepare-checked+0x1808>
    4284:      	cmp	w21, #0x0
    4288:      	b.le	0x43c8 <_stogir.pipeline.prepare-checked+0x1994>
    428c:      	cmp	w20, #0x1
    4290:      	b.lt	0x4374 <_stogir.pipeline.prepare-checked+0x1940>
    4294:      	mov	w13, wzr
    4298:      	and	x14, x20, #0x7fffffff
    429c:      	mov	w15, #0x1               ; =1
    42a0:      	b	0x42b8 <_stogir.pipeline.prepare-checked+0x1884>
    42a4:      	mov	w26, #0x18              ; =24
    42a8:      	mov	x23, x22
    42ac:      	add	w15, w15, #0x1
    42b0:      	cmp	w15, w21
    42b4:      	b.gt	0x4360 <_stogir.pipeline.prepare-checked+0x192c>
    42b8:      	cmp	w15, #0x1
    42bc:      	b.lt	0x42e0 <_stogir.pipeline.prepare-checked+0x18ac>
    42c0:      	cmp	w15, #0x5
    42c4:      	ldr	w17, [x5, x10, lsl #2]
    42c8:      	csel	w16, w15, w25, lo
    42cc:      	lsl	w16, w16, #2
    42d0:      	sub	w16, w16, #0x4
    42d4:      	lsr	w16, w17, w16
    42d8:      	and	w16, w16, #0xf
    42dc:      	b	0x42e4 <_stogir.pipeline.prepare-checked+0x18b0>
    42e0:      	mov	w16, wzr
    42e4:      	cmp	w16, #0xf
    42e8:      	b.eq	0x42ac <_stogir.pipeline.prepare-checked+0x1878>
    42ec:      	lsl	w16, w27, w16
    42f0:      	and	w16, w16, w24
    42f4:      	cbz	w16, 0x42ac <_stogir.pipeline.prepare-checked+0x1878>
    42f8:      	cmp	x9, x14
    42fc:      	b.le	0x4320 <_stogir.pipeline.prepare-checked+0x18ec>
    4300:      	ldr	x16, [x8, #0x80]
    4304:      	cmp	x16, x14
    4308:      	b.le	0x4320 <_stogir.pipeline.prepare-checked+0x18ec>
    430c:      	ldr	w16, [x12, x14, lsl #2]
    4310:      	cmp	w15, w16
    4314:      	ccmp	w16, #0x0, #0x8, ls
    4318:      	ccmp	w15, #0x1, #0x8, pl
    431c:      	b.ge	0x4344 <_stogir.pipeline.prepare-checked+0x1910>
    4320:      	mov	x17, xzr
    4324:      	cbz	w17, 0x42a4 <_stogir.pipeline.prepare-checked+0x1870>
    4328:      	cmp	w16, #0x1
    432c:      	b.lt	0x42ac <_stogir.pipeline.prepare-checked+0x1878>
    4330:      	and	x16, x16, #0x7fffffff
    4334:      	ldr	w16, [x6, x16, lsl #2]
    4338:      	cmp	w16, #0x0
    433c:      	cinc	w13, w13, eq
    4340:      	b	0x42ac <_stogir.pipeline.prepare-checked+0x1878>
    4344:      	add	w16, w20, w15, lsr #2
    4348:      	and	w17, w15, #0x3
    434c:      	add	x16, x11, w16, uxtw #4
    4350:      	ldr	w16, [x16, w17, uxtw #2]
    4354:      	mov	w17, #0x1               ; =1
    4358:      	cbnz	w17, 0x4328 <_stogir.pipeline.prepare-checked+0x18f4>
    435c:      	b	0x42a4 <_stogir.pipeline.prepare-checked+0x1870>
    4360:      	ldr	x9, [sp, #0x38]
    4364:      	add	w7, w7, #0x1
    4368:      	str	w13, [x9, x20, lsl #2]
    436c:      	cbnz	w13, 0x423c <_stogir.pipeline.prepare-checked+0x1808>
    4370:      	b	0x43d4 <_stogir.pipeline.prepare-checked+0x19a0>
    4374:      	mov	w9, #0x1                ; =1
    4378:      	b	0x43b8 <_stogir.pipeline.prepare-checked+0x1984>
    437c:      	cmp	w9, #0x5
    4380:      	ldr	w12, [x5, x10, lsl #2]
    4384:      	csel	w11, w9, w25, lo
    4388:      	lsl	w11, w11, #2
    438c:      	sub	w11, w11, #0x4
    4390:      	lsr	w11, w12, w11
    4394:      	and	w11, w11, #0xf
    4398:      	lsl	w12, w27, w11
    439c:      	add	w9, w9, #0x1
    43a0:      	tst	w12, w24
    43a4:      	ccmp	w11, #0xf, #0x4, ne
    43a8:      	csel	x26, x30, x26, ne
    43ac:      	csel	x23, x22, x23, ne
    43b0:      	cmp	w9, w21
    43b4:      	b.gt	0x43c8 <_stogir.pipeline.prepare-checked+0x1994>
    43b8:      	cmp	w9, #0x1
    43bc:      	b.ge	0x437c <_stogir.pipeline.prepare-checked+0x1948>
    43c0:      	mov	w11, wzr
    43c4:      	b	0x4398 <_stogir.pipeline.prepare-checked+0x1964>
    43c8:      	ldr	x9, [sp, #0x38]
    43cc:      	add	w7, w7, #0x1
    43d0:      	str	wzr, [x9, x20, lsl #2]
    43d4:      	ldp	x19, x2, [x29, #-0x88]
    43d8:      	cmp	x19, x2
    43dc:      	b.lt	0x4230 <_stogir.pipeline.prepare-checked+0x17fc>
    43e0:      	lsl	x9, x2, #1
    43e4:      	cmp	x2, #0x0
    43e8:      	str	x23, [sp, #0x30]
    43ec:      	csel	x23, x3, x9, eq
    43f0:      	sub	x9, x29, #0x90
    43f4:      	ldur	q0, [x9, #0x18]
    43f8:      	cmp	x23, x2
    43fc:      	str	q0, [x4]
    4400:      	b.le	0x4228 <_stogir.pipeline.prepare-checked+0x17f4>
    4404:      	adrp	x4, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004404:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    4408:      	mov	x22, x0
    440c:      	sub	x0, x29, #0xc0
    4410:      	ldr	x4, [x4]
		0000000000004410:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    4414:      	mov	x3, x23
    4418:      	mov	w5, #0x4                ; =4
    441c:      	mov	w6, #0x4                ; =4
    4420:      	mov	w28, w7
    4424:      	bl	0x4424 <_stogir.pipeline.prepare-checked+0x19f0>
		0000000000004424:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    4428:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    442c:      	stur	x23, [x29, #-0x80]
    4430:      	ldr	x8, [sp, #0xa0]
    4434:      	ldr	x6, [sp, #0x70]
    4438:      	ldr	x23, [sp, #0x30]
    443c:      	adrp	x5, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		000000000000443c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    4440:      	add	x5, x5, #0x0
		0000000000004440:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    4444:      	sub	x4, x29, #0xc0
    4448:      	mov	w7, w28
    444c:      	mov	x0, x22
    4450:      	mov	w3, #0x2                ; =2
    4454:      	adrp	x22, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004454:  ARM64_RELOC_PAGE21	l_str.636
    4458:      	add	x22, x22, #0x0
		0000000000004458:  ARM64_RELOC_PAGEOFF12	l_str.636
    445c:      	mov	w30, #0x18              ; =24
    4460:      	b	0x422c <_stogir.pipeline.prepare-checked+0x17f8>
    4464:      	mov	x1, xzr
    4468:      	mov	w7, wzr
    446c:      	adrp	x23, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		000000000000446c:  ARM64_RELOC_PAGE21	l_str.635
    4470:      	add	x23, x23, #0x0
		0000000000004470:  ARM64_RELOC_PAGEOFF12	l_str.635
    4474:      	stur	x1, [x29, #-0x90]
    4478:      	ldur	x21, [x29, #-0x88]
    447c:      	mov	w24, #0x1               ; =1
    4480:      	cmp	x21, #0x1
    4484:      	b.lt	0x481c <_stogir.pipeline.prepare-checked+0x1de8>
    4488:      	mov	x22, xzr
    448c:      	mov	w30, #0x2               ; =2
    4490:      	mov	w25, #0x82              ; =130
    4494:      	mov	w26, #0x18              ; =24
    4498:      	adrp	x20, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004498:  ARM64_RELOC_PAGE21	l_str.640
    449c:      	add	x20, x20, #0x0
		000000000000449c:  ARM64_RELOC_PAGEOFF12	l_str.640
    44a0:      	ldr	w9, [x1, x22, lsl #2]
    44a4:      	ldr	x10, [x8, #0x78]
    44a8:      	mov	w19, #0x5e1c            ; =24092
    44ac:      	ldr	x15, [sp, #0x40]
    44b0:      	ldr	w11, [x10, w9, sxtw #2]
    44b4:      	sxtw	x10, w9
    44b8:      	cmp	w11, #0x1
    44bc:      	b.lt	0x45f0 <_stogir.pipeline.prepare-checked+0x1bbc>
    44c0:      	ldr	x12, [x8]
    44c4:      	lsl	x13, x10, #4
    44c8:      	ldr	x15, [sp, #0x40]
    44cc:      	ldp	x16, x14, [sp, #0x1e8]
    44d0:      	mov	w17, #0x1               ; =1
    44d4:      	ldrb	w13, [x12, x13]
    44d8:      	b	0x44ec <_stogir.pipeline.prepare-checked+0x1ab8>
    44dc:      	mov	x15, x0
    44e0:      	add	w17, w17, #0x1
    44e4:      	cmp	w17, w11
    44e8:      	b.gt	0x45f0 <_stogir.pipeline.prepare-checked+0x1bbc>
    44ec:      	cmp	w17, #0x1
    44f0:      	ccmp	x13, x25, #0x2, ge
    44f4:      	b.hi	0x451c <_stogir.pipeline.prepare-checked+0x1ae8>
    44f8:      	cmp	w17, #0x5
    44fc:      	mov	w0, #0x5                ; =5
    4500:      	ldr	w2, [x5, x13, lsl #2]
    4504:      	csel	w0, w17, w0, lo
    4508:      	lsl	w0, w0, #2
    450c:      	sub	w0, w0, #0x4
    4510:      	lsr	w0, w2, w0
    4514:      	and	w0, w0, #0xf
    4518:      	b	0x4520 <_stogir.pipeline.prepare-checked+0x1aec>
    451c:      	mov	w0, wzr
    4520:      	cmp	w0, #0xf
    4524:      	b.eq	0x44e0 <_stogir.pipeline.prepare-checked+0x1aac>
    4528:      	lsl	w0, w24, w0
    452c:      	and	w0, w0, w19
    4530:      	cbz	w0, 0x44e0 <_stogir.pipeline.prepare-checked+0x1aac>
    4534:      	cmp	w9, #0x1
    4538:      	b.lt	0x4558 <_stogir.pipeline.prepare-checked+0x1b24>
    453c:      	ldr	x0, [x8, #0x8]
    4540:      	cmp	x0, x9
    4544:      	b.le	0x4558 <_stogir.pipeline.prepare-checked+0x1b24>
    4548:      	ldr	x0, [x8, #0x80]
    454c:      	cmp	w17, #0x1
    4550:      	ccmp	x0, x9, #0x4, ge
    4554:      	b.gt	0x45d4 <_stogir.pipeline.prepare-checked+0x1ba0>
    4558:      	mov	x2, xzr
    455c:      	cbz	w2, 0x54d0 <_stogir.pipeline.prepare-checked+0x2a9c>
    4560:      	cmp	w0, #0x1
    4564:      	b.lt	0x44e0 <_stogir.pipeline.prepare-checked+0x1aac>
    4568:      	and	x0, x0, #0x7fffffff
    456c:      	ldr	w0, [x6, x0, lsl #2]
    4570:      	mov	x2, x0
    4574:      	cmp	w2, #0x1
    4578:      	b.lt	0x45a0 <_stogir.pipeline.prepare-checked+0x1b6c>
    457c:      	cmp	x14, x2
    4580:      	b.le	0x45a0 <_stogir.pipeline.prepare-checked+0x1b6c>
    4584:      	ldr	w3, [x16, x2, lsl #2]
    4588:      	cbz	w3, 0x45a0 <_stogir.pipeline.prepare-checked+0x1b6c>
    458c:      	cmp	x2, x15
    4590:      	b.eq	0x44dc <_stogir.pipeline.prepare-checked+0x1aa8>
    4594:      	cmp	x2, x3
    4598:      	mov	x2, x3
    459c:      	b.ne	0x4574 <_stogir.pipeline.prepare-checked+0x1b40>
    45a0:      	mov	x2, x15
    45a4:      	cmp	w2, #0x1
    45a8:      	b.lt	0x4718 <_stogir.pipeline.prepare-checked+0x1ce4>
    45ac:      	cmp	x14, x2
    45b0:      	b.le	0x4718 <_stogir.pipeline.prepare-checked+0x1ce4>
    45b4:      	ldr	w3, [x16, x2, lsl #2]
    45b8:      	cbz	w3, 0x4718 <_stogir.pipeline.prepare-checked+0x1ce4>
    45bc:      	cmp	x2, x0
    45c0:      	b.eq	0x44e0 <_stogir.pipeline.prepare-checked+0x1aac>
    45c4:      	cmp	x2, x3
    45c8:      	mov	x2, x3
    45cc:      	b.ne	0x45a4 <_stogir.pipeline.prepare-checked+0x1b70>
    45d0:      	b	0x4718 <_stogir.pipeline.prepare-checked+0x1ce4>
    45d4:      	add	w0, w10, w17, lsr #2
    45d8:      	and	w2, w17, #0x3
    45dc:      	add	x0, x12, w0, uxtw #4
    45e0:      	ldr	w0, [x0, w2, uxtw #2]
    45e4:      	mov	w2, #0x1                ; =1
    45e8:      	cbnz	w2, 0x4560 <_stogir.pipeline.prepare-checked+0x1b2c>
    45ec:      	b	0x54d0 <_stogir.pipeline.prepare-checked+0x2a9c>
    45f0:      	str	w15, [x6, x10, lsl #2]
    45f4:      	mov	x24, x20
    45f8:      	ldr	x9, [sp, #0x260]
    45fc:      	add	x9, x9, x10, lsl #4
    4600:      	ldr	x19, [x9, #0x8]
    4604:      	cmp	x19, #0x1
    4608:      	b.lt	0x46d0 <_stogir.pipeline.prepare-checked+0x1c9c>
    460c:      	ldr	x10, [x9]
    4610:      	ldr	x11, [sp, #0x68]
    4614:      	ldr	x9, [sp, #0x550]
    4618:      	add	x28, x11, x10, lsl #3
    461c:      	b	0x4638 <_stogir.pipeline.prepare-checked+0x1c04>
    4620:      	mov	x23, x27
    4624:      	str	w25, [x1, x21, lsl #2]
    4628:      	add	x21, x21, #0x1
    462c:      	ldr	x9, [sp, #0x550]
    4630:      	subs	x19, x19, #0x1
    4634:      	b.eq	0x46d0 <_stogir.pipeline.prepare-checked+0x1c9c>
    4638:      	ldr	x25, [x28], #0x8
    463c:      	sbfiz	x10, x25, #2, #32
    4640:      	ldr	w11, [x9, x10]
    4644:      	subs	w11, w11, #0x1
    4648:      	b.lt	0x4630 <_stogir.pipeline.prepare-checked+0x1bfc>
    464c:      	str	w11, [x9, x10]
    4650:      	b.ne	0x4630 <_stogir.pipeline.prepare-checked+0x1bfc>
    4654:      	ldur	x2, [x29, #-0x80]
    4658:      	cmp	x21, x2
    465c:      	b.lt	0x4624 <_stogir.pipeline.prepare-checked+0x1bf0>
    4660:      	lsl	x9, x2, #1
    4664:      	cmp	x2, #0x0
    4668:      	mov	x27, x23
    466c:      	csel	x23, x30, x9, eq
    4670:      	sub	x9, x29, #0x90
    4674:      	ldur	q0, [x9, #0x18]
    4678:      	cmp	x23, x2
    467c:      	str	q0, [x4]
    4680:      	b.le	0x4620 <_stogir.pipeline.prepare-checked+0x1bec>
    4684:      	adrp	x4, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004684:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    4688:      	sub	x0, x29, #0xc0
    468c:      	mov	x3, x23
    4690:      	ldr	x4, [x4]
		0000000000004690:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    4694:      	mov	w5, #0x4                ; =4
    4698:      	mov	w6, #0x4                ; =4
    469c:      	mov	w20, w7
    46a0:      	bl	0x46a0 <_stogir.pipeline.prepare-checked+0x1c6c>
		00000000000046a0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    46a4:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    46a8:      	ldr	x8, [sp, #0xa0]
    46ac:      	ldr	x6, [sp, #0x70]
    46b0:      	adrp	x5, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		00000000000046b0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    46b4:      	add	x5, x5, #0x0
		00000000000046b4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    46b8:      	stur	x23, [x29, #-0x80]
    46bc:      	sub	x4, x29, #0xc0
    46c0:      	mov	x23, x27
    46c4:      	mov	w7, w20
    46c8:      	mov	w30, #0x2               ; =2
    46cc:      	b	0x4624 <_stogir.pipeline.prepare-checked+0x1bf0>
    46d0:      	add	x22, x22, #0x1
    46d4:      	ldr	x28, [sp, #0x58]
    46d8:      	sub	w7, w7, #0x1
    46dc:      	cmp	x22, x21
    46e0:      	mov	w19, #0x1               ; =1
    46e4:      	mov	x20, x24
    46e8:      	mov	w24, #0x1               ; =1
    46ec:      	mov	w25, #0x82              ; =130
    46f0:      	stp	x1, x21, [x29, #-0x90]
    46f4:      	b.lt	0x44a0 <_stogir.pipeline.prepare-checked+0x1a6c>
    46f8:      	mov	x26, xzr
    46fc:      	add	x22, sp, #0x550
    4700:      	ldr	x2, [sp, #0x560]
    4704:      	mov	w21, w7
    4708:      	str	xzr, [sp, #0x558]
    470c:      	cmp	x2, #0x1
    4710:      	b.ge	0x473c <_stogir.pipeline.prepare-checked+0x1d08>
    4714:      	b	0x476c <_stogir.pipeline.prepare-checked+0x1d38>
    4718:      	mov	w19, wzr
    471c:      	mov	w26, #0x2b              ; =43
    4720:      	mov	x23, x20
    4724:      	add	x22, sp, #0x550
    4728:      	ldr	x2, [sp, #0x560]
    472c:      	mov	w21, w7
    4730:      	str	xzr, [sp, #0x558]
    4734:      	cmp	x2, #0x1
    4738:      	b.lt	0x476c <_stogir.pipeline.prepare-checked+0x1d38>
    473c:      	ldr	x8, [sp, #0x550]
    4740:      	adrp	x3, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004740:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    4744:      	add	x0, x22, #0x18
    4748:      	ldr	x3, [x3]
		0000000000004748:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    474c:      	mov	x20, x1
    4750:      	mov	w4, #0x4                ; =4
    4754:      	mov	x1, x8
    4758:      	mov	w5, #0x4                ; =4
    475c:      	bl	0x475c <_stogir.pipeline.prepare-checked+0x1d28>
		000000000000475c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4760:      	adrp	x5, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004760:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    4764:      	add	x5, x5, #0x0
		0000000000004764:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    4768:      	mov	x1, x20
    476c:      	ldur	x2, [x29, #-0x80]
    4770:      	str	xzr, [sp, #0x558]
    4774:      	str	xzr, [sp, #0x550]
    4778:      	cmp	x2, #0x1
    477c:      	str	xzr, [sp, #0x560]
    4780:      	stur	xzr, [x29, #-0x88]
    4784:      	b.lt	0x47ac <_stogir.pipeline.prepare-checked+0x1d78>
    4788:      	adrp	x3, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004788:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    478c:      	sub	x8, x29, #0x90
    4790:      	mov	w4, #0x4                ; =4
    4794:      	ldr	x3, [x3]
		0000000000004794:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    4798:      	add	x0, x8, #0x18
    479c:      	mov	w5, #0x4                ; =4
    47a0:      	bl	0x47a0 <_stogir.pipeline.prepare-checked+0x1d6c>
		00000000000047a0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    47a4:      	adrp	x5, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		00000000000047a4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    47a8:      	add	x5, x5, #0x0
		00000000000047a8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    47ac:      	ldr	x20, [sp, #0x60]
    47b0:      	tbz	w19, #0x0, 0x47dc <_stogir.pipeline.prepare-checked+0x1da8>
    47b4:      	ldp	x9, x8, [sp, #0x98]
    47b8:      	cmp	w21, #0x0
    47bc:      	ldr	x6, [sp, #0x80]
    47c0:      	add	x10, sp, #0x550
    47c4:      	sub	x7, x29, #0xc0
    47c8:      	b.le	0x4990 <_stogir.pipeline.prepare-checked+0x1f5c>
    47cc:      	adrp	x23, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		00000000000047cc:  ARM64_RELOC_PAGE21	l_str.643
    47d0:      	add	x23, x23, #0x0
		00000000000047d0:  ARM64_RELOC_PAGEOFF12	l_str.643
    47d4:      	mov	w26, #0x39              ; =57
    47d8:      	b	0x6ee0 <_stogir.pipeline.prepare-checked+0x44ac>
    47dc:      	ldp	x9, x8, [sp, #0x98]
    47e0:      	add	x10, sp, #0x550
    47e4:      	ldr	x6, [sp, #0x80]
    47e8:      	sub	x7, x29, #0xc0
    47ec:      	cbnz	x26, 0x6ee0 <_stogir.pipeline.prepare-checked+0x44ac>
    47f0:      	b	0x4998 <_stogir.pipeline.prepare-checked+0x1f64>
    47f4:      	add	x22, sp, #0x550
    47f8:      	stur	x1, [x29, #-0x90]
    47fc:      	cbz	x26, 0x4478 <_stogir.pipeline.prepare-checked+0x1a44>
    4800:      	mov	w19, wzr
    4804:      	ldr	x2, [sp, #0x560]
    4808:      	mov	w21, w7
    480c:      	str	xzr, [sp, #0x558]
    4810:      	cmp	x2, #0x1
    4814:      	b.ge	0x473c <_stogir.pipeline.prepare-checked+0x1d08>
    4818:      	b	0x476c <_stogir.pipeline.prepare-checked+0x1d38>
    481c:      	mov	x26, xzr
    4820:      	mov	w19, #0x1               ; =1
    4824:      	ldr	x2, [sp, #0x560]
    4828:      	mov	w21, w7
    482c:      	str	xzr, [sp, #0x558]
    4830:      	cmp	x2, #0x1
    4834:      	b.ge	0x473c <_stogir.pipeline.prepare-checked+0x1d08>
    4838:      	b	0x476c <_stogir.pipeline.prepare-checked+0x1d38>
    483c:      	mov	w26, #0x15              ; =21
    4840:      	mov	x23, x11
    4844:      	ldr	x2, [sp, #0x560]
    4848:      	str	xzr, [sp, #0x558]
    484c:      	cmp	x2, #0x1
    4850:      	b.lt	0x4870 <_stogir.pipeline.prepare-checked+0x1e3c>
    4854:      	adrp	x3, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004854:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    4858:      	ldr	x1, [sp, #0x550]
    485c:      	add	x0, x20, #0x18
    4860:      	ldr	x3, [x3]
		0000000000004860:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    4864:      	mov	w4, #0x4                ; =4
    4868:      	mov	w5, #0x4                ; =4
    486c:      	bl	0x486c <_stogir.pipeline.prepare-checked+0x1e38>
		000000000000486c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4870:      	ldr	x20, [sp, #0x60]
    4874:      	b	0x6f10 <_stogir.pipeline.prepare-checked+0x44dc>
    4878:      	ldr	x10, [sp, #0x550]
    487c:      	ldr	x12, [sp, #0x120]
    4880:      	mov	w11, wzr
    4884:      	ldr	x13, [sp, #0x148]
    4888:      	ldr	x14, [sp, #0xf8]
    488c:      	mov	w15, #0x1               ; =1
    4890:      	mov	w16, #0x1               ; =1
    4894:      	b	0x48b4 <_stogir.pipeline.prepare-checked+0x1e80>
    4898:      	add	x17, x16, #0x1
    489c:      	cmp	x17, x8
    48a0:      	cset	w17, ne
    48a4:      	csinc	x16, x15, x16, eq
    48a8:      	orr	w0, w17, w11
    48ac:      	and	w11, w17, w11
    48b0:      	tbz	w0, #0x0, 0x3690 <_stogir.pipeline.prepare-checked+0xc5c>
    48b4:      	ldrsw	x17, [x9, x16, lsl #2]
    48b8:      	add	x2, x12, x17, lsl #4
    48bc:      	ldr	x0, [x2, #0x8]
    48c0:      	cmp	x0, #0x1
    48c4:      	b.lt	0x4974 <_stogir.pipeline.prepare-checked+0x1f40>
    48c8:      	ldr	x2, [x2]
    48cc:      	mov	x1, xzr
    48d0:      	mov	w3, wzr
    48d4:      	add	x2, x13, x2, lsl #3
    48d8:      	b	0x48ec <_stogir.pipeline.prepare-checked+0x1eb8>
    48dc:      	mov	w3, w5
    48e0:      	add	x1, x1, #0x1
    48e4:      	cmp	x1, x0
    48e8:      	b.eq	0x4978 <_stogir.pipeline.prepare-checked+0x1f44>
    48ec:      	ldr	x5, [x2, x1, lsl #3]
    48f0:      	lsl	x5, x5, #4
    48f4:      	ldr	x5, [x14, x5]
    48f8:      	sbfiz	x6, x5, #2, #32
    48fc:      	ldr	w6, [x21, x6]
    4900:      	cbz	w6, 0x48e0 <_stogir.pipeline.prepare-checked+0x1eac>
    4904:      	cbz	w3, 0x48dc <_stogir.pipeline.prepare-checked+0x1ea8>
    4908:      	cmp	w3, w5
    490c:      	b.ne	0x491c <_stogir.pipeline.prepare-checked+0x1ee8>
    4910:      	b	0x48e0 <_stogir.pipeline.prepare-checked+0x1eac>
    4914:      	cmp	w3, w5
    4918:      	b.eq	0x48e0 <_stogir.pipeline.prepare-checked+0x1eac>
    491c:      	ldr	x7, [x10, w5, sxtw #3]
    4920:      	ldr	x6, [x10, w3, sxtw #3]
    4924:      	cmp	x6, x7
    4928:      	b.le	0x4950 <_stogir.pipeline.prepare-checked+0x1f1c>
    492c:      	sxtw	x19, w3
    4930:      	ldr	w3, [x21, x19, lsl #2]
    4934:      	ldr	x6, [x10, w3, sxtw #3]
    4938:      	sxtw	x19, w3
    493c:      	cmp	x6, x7
    4940:      	b.gt	0x4930 <_stogir.pipeline.prepare-checked+0x1efc>
    4944:      	cmp	x7, x6
    4948:      	b.le	0x4914 <_stogir.pipeline.prepare-checked+0x1ee0>
    494c:      	b	0x4958 <_stogir.pipeline.prepare-checked+0x1f24>
    4950:      	cmp	x7, x6
    4954:      	b.le	0x4914 <_stogir.pipeline.prepare-checked+0x1ee0>
    4958:      	sxtw	x7, w5
    495c:      	ldr	w5, [x21, x7, lsl #2]
    4960:      	ldr	x19, [x10, w5, sxtw #3]
    4964:      	sxtw	x7, w5
    4968:      	cmp	x19, x6
    496c:      	b.gt	0x495c <_stogir.pipeline.prepare-checked+0x1f28>
    4970:      	b	0x4914 <_stogir.pipeline.prepare-checked+0x1ee0>
    4974:      	mov	w3, wzr
    4978:      	ldr	w0, [x21, x17, lsl #2]
    497c:      	cmp	w0, w3
    4980:      	b.eq	0x4898 <_stogir.pipeline.prepare-checked+0x1e64>
    4984:      	mov	w11, #0x1               ; =1
    4988:      	str	w3, [x21, x17, lsl #2]
    498c:      	b	0x4898 <_stogir.pipeline.prepare-checked+0x1e64>
    4990:      	adrp	x23, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004990:  ARM64_RELOC_PAGE21	l_str.628
    4994:      	add	x23, x23, #0x0
		0000000000004994:  ARM64_RELOC_PAGEOFF12	l_str.628
    4998:      	ldr	q0, [x9]
    499c:      	ldr	x9, [x8, #0x8]
    49a0:      	add	x22, sp, #0x550
    49a4:      	str	xzr, [sp, #0x560]
    49a8:      	cmp	x9, #0x1
    49ac:      	str	xzr, [sp, #0x550]
    49b0:      	str	xzr, [sp, #0x558]
    49b4:      	stur	q0, [x10, #0x18]
    49b8:      	stp	xzr, xzr, [x29, #-0x88]
    49bc:      	stur	xzr, [x29, #-0x90]
    49c0:      	stur	q0, [x7, #0x48]
    49c4:      	b.lt	0x4ad4 <_stogir.pipeline.prepare-checked+0x20a0>
    49c8:      	mov	x27, x23
    49cc:      	adrp	x23, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		00000000000049cc:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    49d0:      	mov	x19, xzr
    49d4:      	ldr	x23, [x23]
		00000000000049d4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    49d8:      	mov	x1, xzr
    49dc:      	mov	w20, #-0x1              ; =-1
    49e0:      	mov	w21, #0x2               ; =2
    49e4:      	b	0x4a00 <_stogir.pipeline.prepare-checked+0x1fcc>
    49e8:      	str	w20, [x1, x19, lsl #2]
    49ec:      	add	x19, x19, #0x1
    49f0:      	ldr	x9, [x8, #0x8]
    49f4:      	str	x19, [sp, #0x558]
    49f8:      	cmp	x19, x9
    49fc:      	b.ge	0x4a60 <_stogir.pipeline.prepare-checked+0x202c>
    4a00:      	ldr	x2, [sp, #0x560]
    4a04:      	cmp	x19, x2
    4a08:      	b.lt	0x49e8 <_stogir.pipeline.prepare-checked+0x1fb4>
    4a0c:      	lsl	x9, x2, #1
    4a10:      	cmp	x2, #0x0
    4a14:      	ldur	q0, [x22, #0x18]
    4a18:      	csel	x25, x21, x9, eq
    4a1c:      	str	q0, [x7]
    4a20:      	cmp	x25, x2
    4a24:      	b.le	0x49e8 <_stogir.pipeline.prepare-checked+0x1fb4>
    4a28:      	sub	x0, x29, #0xc0
    4a2c:      	mov	x3, x25
    4a30:      	mov	x4, x23
    4a34:      	mov	w5, #0x4                ; =4
    4a38:      	mov	w6, #0x4                ; =4
    4a3c:      	bl	0x4a3c <_stogir.pipeline.prepare-checked+0x2008>
		0000000000004a3c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    4a40:      	cbz	w0, 0x41c4 <_stogir.pipeline.prepare-checked+0x1790>
    4a44:      	ldr	x8, [sp, #0xa0]
    4a48:      	ldr	x6, [sp, #0x80]
    4a4c:      	adrp	x5, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004a4c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    4a50:      	add	x5, x5, #0x0
		0000000000004a50:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    4a54:      	sub	x7, x29, #0xc0
    4a58:      	str	x25, [sp, #0x560]
    4a5c:      	b	0x49e8 <_stogir.pipeline.prepare-checked+0x1fb4>
    4a60:      	cmp	x9, #0x2
    4a64:      	mov	w21, wzr
    4a68:      	str	x1, [sp, #0x550]
    4a6c:      	b.lt	0x4d4c <_stogir.pipeline.prepare-checked+0x2318>
    4a70:      	mov	w10, #0x1               ; =1
    4a74:      	adrp	x11, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004a74:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    4a78:      	add	x11, x11, #0x0
		0000000000004a78:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    4a7c:      	b	0x4a98 <_stogir.pipeline.prepare-checked+0x2064>
    4a80:      	adds	x13, x12, #0x4
    4a84:      	add	x12, x12, #0x7
    4a88:      	csel	x12, x12, x13, mi
    4a8c:      	add	x10, x10, x12, asr #2
    4a90:      	cmp	x10, x9
    4a94:      	b.ge	0x4d48 <_stogir.pipeline.prepare-checked+0x2314>
    4a98:      	ldr	x12, [x8]
    4a9c:      	lsl	x13, x10, #4
    4aa0:      	ldrb	w13, [x12, x13]
    4aa4:      	ldr	x12, [x8, #0x78]
    4aa8:      	ldrsw	x12, [x12, x10, lsl #2]
    4aac:      	cmp	x13, #0x82
    4ab0:      	b.hi	0x4a80 <_stogir.pipeline.prepare-checked+0x204c>
    4ab4:      	ldrb	w14, [x6, x10]
    4ab8:      	cbz	w14, 0x4a80 <_stogir.pipeline.prepare-checked+0x204c>
    4abc:      	ldrb	w13, [x11, x13]
    4ac0:      	tbz	w13, #0x6, 0x4a80 <_stogir.pipeline.prepare-checked+0x204c>
    4ac4:      	str	wzr, [x1, x10, lsl #2]
    4ac8:      	add	w21, w21, #0x1
    4acc:      	ldr	x9, [x8, #0x8]
    4ad0:      	b	0x4a80 <_stogir.pipeline.prepare-checked+0x204c>
    4ad4:      	mov	w21, wzr
    4ad8:      	mov	x19, xzr
    4adc:      	mov	x30, xzr
    4ae0:      	b	0x4ee8 <_stogir.pipeline.prepare-checked+0x24b4>
    4ae4:      	ldr	x12, [sp, #0x550]
    4ae8:      	ldr	x16, [sp, #0x558]
    4aec:      	mov	x25, xzr
    4af0:      	mov	x22, xzr
    4af4:      	adrp	x15, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004af4:  ARM64_RELOC_PAGE21	l_str.839
    4af8:      	add	x15, x15, #0x0
		0000000000004af8:  ARM64_RELOC_PAGEOFF12	l_str.839
    4afc:      	add	x17, sp, #0x550
    4b00:      	mov	w0, #0x5                ; =5
    4b04:      	mov	w3, #0x2                ; =2
    4b08:      	str	x16, [sp, #0x38]
    4b0c:      	b	0x4b20 <_stogir.pipeline.prepare-checked+0x20ec>
    4b10:      	mov	x22, xzr
    4b14:      	ldr	x25, [sp, #0x58]
    4b18:      	ldr	x16, [sp, #0x38]
    4b1c:      	str	x1, [sp, #0x5a0]
    4b20:      	cmp	x25, x16
    4b24:      	b.ge	0x4b38 <_stogir.pipeline.prepare-checked+0x2104>
    4b28:      	ldr	w19, [x12, x25, lsl #2]
    4b2c:      	add	x25, x25, #0x1
    4b30:      	mov	w9, #0x1                ; =1
    4b34:      	b	0x4b3c <_stogir.pipeline.prepare-checked+0x2108>
    4b38:      	mov	x9, xzr
    4b3c:      	cbz	w9, 0x30b8 <_stogir.pipeline.prepare-checked+0x684>
    4b40:      	ldr	x1, [sp, #0x5a0]
    4b44:      	cbnz	x22, 0x4b1c <_stogir.pipeline.prepare-checked+0x20e8>
    4b48:      	ldr	x9, [x8, #0x78]
    4b4c:      	ldr	w28, [x9, w19, sxtw #2]
    4b50:      	cmp	w28, #0x1
    4b54:      	b.lt	0x4b1c <_stogir.pipeline.prepare-checked+0x20e8>
    4b58:      	sxtw	x9, w19
    4b5c:      	ldr	x10, [x8]
    4b60:      	lsl	x9, x9, #4
    4b64:      	ldrb	w5, [x10, x9]
    4b68:      	cmp	x5, #0x82
    4b6c:      	b.hi	0x4ce8 <_stogir.pipeline.prepare-checked+0x22b4>
    4b70:      	lsl	x26, x19, #32
    4b74:      	and	x16, x19, #0x7fffffff
    4b78:      	mov	w24, #0x1               ; =1
    4b7c:      	str	x25, [sp, #0x58]
    4b80:      	str	x5, [sp, #0x80]
    4b84:      	str	x16, [sp, #0x70]
    4b88:      	b	0x4be0 <_stogir.pipeline.prepare-checked+0x21ac>
    4b8c:      	ldr	x8, [sp, #0xa0]
    4b90:      	ldr	x5, [sp, #0x80]
    4b94:      	add	x13, sp, #0x550
    4b98:      	ldr	x16, [sp, #0x70]
    4b9c:      	adrp	x14, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004b9c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    4ba0:      	add	x14, x14, #0x0
		0000000000004ba0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    4ba4:      	mov	x15, x21
    4ba8:      	mov	x12, x25
    4bac:      	add	x17, sp, #0x550
    4bb0:      	mov	w0, #0x5                ; =5
    4bb4:      	mov	w3, #0x2                ; =2
    4bb8:      	str	x22, [sp, #0x5b0]
    4bbc:      	add	x9, x1, x23, lsl #4
    4bc0:      	bfi	x27, x24, #32, #32
    4bc4:      	orr	x10, x26, x20
    4bc8:      	stp	x10, x27, [x9]
    4bcc:      	add	x10, x23, #0x1
    4bd0:      	str	x10, [sp, #0x5a8]
    4bd4:      	add	w24, w24, #0x1
    4bd8:      	cmp	w24, w28
    4bdc:      	b.gt	0x4b10 <_stogir.pipeline.prepare-checked+0x20dc>
    4be0:      	cmp	w24, #0x1
    4be4:      	b.lt	0x4bd4 <_stogir.pipeline.prepare-checked+0x21a0>
    4be8:      	cmp	w24, #0x5
    4bec:      	ldr	w10, [x14, x5, lsl #2]
    4bf0:      	csel	w9, w24, w0, lo
    4bf4:      	lsl	w9, w9, #2
    4bf8:      	sub	w9, w9, #0x4
    4bfc:      	lsr	w9, w10, w9
    4c00:      	and	w9, w9, #0xf
    4c04:      	cmp	w9, #0xc
    4c08:      	b.ne	0x4bd4 <_stogir.pipeline.prepare-checked+0x21a0>
    4c0c:      	cmp	w19, #0x1
    4c10:      	b.lt	0x4c64 <_stogir.pipeline.prepare-checked+0x2230>
    4c14:      	ldr	x9, [x8, #0x8]
    4c18:      	cmp	x9, x16
    4c1c:      	b.le	0x4c64 <_stogir.pipeline.prepare-checked+0x2230>
    4c20:      	ldr	x9, [x8, #0x80]
    4c24:      	cmp	x9, x16
    4c28:      	b.le	0x4c64 <_stogir.pipeline.prepare-checked+0x2230>
    4c2c:      	ldr	x9, [x8, #0x78]
    4c30:      	ldr	w10, [x9, x16, lsl #2]
    4c34:      	mov	x9, xzr
    4c38:      	tbnz	w10, #0x1f, 0x4cd4 <_stogir.pipeline.prepare-checked+0x22a0>
    4c3c:      	cmp	w24, w10
    4c40:      	b.hi	0x4c68 <_stogir.pipeline.prepare-checked+0x2234>
    4c44:      	add	w9, w19, w24, lsr #2
    4c48:      	ldr	x10, [x8]
    4c4c:      	add	x9, x10, w9, uxtw #4
    4c50:      	and	w10, w24, #0x3
    4c54:      	ldr	w27, [x9, w10, uxtw #2]
    4c58:      	mov	w9, #0x1                ; =1
    4c5c:      	cbnz	w9, 0x4c6c <_stogir.pipeline.prepare-checked+0x2238>
    4c60:      	b	0x4cd8 <_stogir.pipeline.prepare-checked+0x22a4>
    4c64:      	mov	x9, xzr
    4c68:      	cbz	w9, 0x4cd8 <_stogir.pipeline.prepare-checked+0x22a4>
    4c6c:      	ldr	x9, [sp, #0x578]
    4c70:      	sbfiz	x10, x27, #2, #32
    4c74:      	ldr	w20, [x9, x10]
    4c78:      	cbz	w20, 0x4d38 <_stogir.pipeline.prepare-checked+0x2304>
    4c7c:      	ldr	x23, [sp, #0x5a8]
    4c80:      	ldr	x2, [sp, #0x5b0]
    4c84:      	cmp	x23, x2
    4c88:      	b.lt	0x4bbc <_stogir.pipeline.prepare-checked+0x2188>
    4c8c:      	lsl	x9, x2, #1
    4c90:      	cmp	x2, #0x0
    4c94:      	ldur	q0, [x17, #0x68]
    4c98:      	csel	x22, x3, x9, eq
    4c9c:      	str	q0, [x13, #0xb0]
    4ca0:      	cmp	x22, x2
    4ca4:      	b.le	0x4bbc <_stogir.pipeline.prepare-checked+0x2188>
    4ca8:      	adrp	x4, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004ca8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.cfg.Edge.0
    4cac:      	add	x0, sp, #0x600
    4cb0:      	mov	x3, x22
    4cb4:      	ldr	x4, [x4]
		0000000000004cb4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.cfg.Edge.0
    4cb8:      	mov	w5, #0x10               ; =16
    4cbc:      	mov	w6, #0x4                ; =4
    4cc0:      	mov	x25, x12
    4cc4:      	mov	x21, x15
    4cc8:      	bl	0x4cc8 <_stogir.pipeline.prepare-checked+0x2294>
		0000000000004cc8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    4ccc:      	cbnz	w0, 0x4b8c <_stogir.pipeline.prepare-checked+0x2158>
    4cd0:      	b	0x729c <_stogir.pipeline.prepare-checked+0x4868>
    4cd4:      	cbnz	w9, 0x4c6c <_stogir.pipeline.prepare-checked+0x2238>
    4cd8:      	mov	w22, #0x19              ; =25
    4cdc:      	adrp	x15, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004cdc:  ARM64_RELOC_PAGE21	l_str.380
    4ce0:      	add	x15, x15, #0x0
		0000000000004ce0:  ARM64_RELOC_PAGEOFF12	l_str.380
    4ce4:      	b	0x4b14 <_stogir.pipeline.prepare-checked+0x20e0>
    4ce8:      	mov	w9, #-0x7fffffff        ; =-2147483647
    4cec:      	mov	w10, #0x5               ; =5
    4cf0:      	add	w9, w28, w9
    4cf4:      	movk	w10, #0x8000, lsl #16
    4cf8:      	cmp	w9, w10
    4cfc:      	b.hs	0x4d08 <_stogir.pipeline.prepare-checked+0x22d4>
    4d00:      	mov	w9, #0x1                ; =1
    4d04:      	b	0x4d24 <_stogir.pipeline.prepare-checked+0x22f0>
    4d08:      	and	w10, w28, #0x7ffffffc
    4d0c:      	and	w11, w28, #0x7ffffffc
    4d10:      	orr	w9, w10, #0x1
    4d14:      	subs	w11, w11, #0x4
    4d18:      	b.ne	0x4d14 <_stogir.pipeline.prepare-checked+0x22e0>
    4d1c:      	cmp	w28, w10
    4d20:      	b.eq	0x4d30 <_stogir.pipeline.prepare-checked+0x22fc>
    4d24:      	add	w9, w9, #0x1
    4d28:      	cmp	w9, w28
    4d2c:      	b.le	0x4d24 <_stogir.pipeline.prepare-checked+0x22f0>
    4d30:      	mov	x22, xzr
    4d34:      	b	0x4b1c <_stogir.pipeline.prepare-checked+0x20e8>
    4d38:      	mov	w22, #0x1e              ; =30
    4d3c:      	adrp	x15, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004d3c:  ARM64_RELOC_PAGE21	l_str.381
    4d40:      	add	x15, x15, #0x0
		0000000000004d40:  ARM64_RELOC_PAGEOFF12	l_str.381
    4d44:      	b	0x4b14 <_stogir.pipeline.prepare-checked+0x20e0>
    4d48:      	ldr	x19, [sp, #0x558]
    4d4c:      	ldur	x30, [x29, #-0x90]
    4d50:      	cmp	x19, #0x2
    4d54:      	b.lt	0x4ec8 <_stogir.pipeline.prepare-checked+0x2494>
    4d58:      	str	w21, [sp, #0x40]
    4d5c:      	adrp	x23, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004d5c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    4d60:      	ldr	x20, [sp, #0x550]
    4d64:      	ldr	x23, [x23]
		0000000000004d64:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    4d68:      	ldr	x9, [sp, #0x68]
    4d6c:      	mov	w22, #0x2               ; =2
    4d70:      	mov	w24, #0x1               ; =1
    4d74:      	add	x21, x9, #0x8
    4d78:      	b	0x4db0 <_stogir.pipeline.prepare-checked+0x237c>
    4d7c:      	ldr	x8, [sp, #0xa0]
    4d80:      	ldr	x6, [sp, #0x80]
    4d84:      	mov	x30, x1
    4d88:      	adrp	x5, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004d88:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    4d8c:      	add	x5, x5, #0x0
		0000000000004d8c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    4d90:      	sub	x7, x29, #0xc0
    4d94:      	stur	x26, [x29, #-0x80]
    4d98:      	add	x9, x25, #0x1
    4d9c:      	str	w24, [x30, x25, lsl #2]
    4da0:      	stur	x9, [x29, #-0x88]
    4da4:      	add	x24, x24, #0x1
    4da8:      	cmp	x24, x19
    4dac:      	b.eq	0x4ed4 <_stogir.pipeline.prepare-checked+0x24a0>
    4db0:      	ldr	w9, [x20, x24, lsl #2]
    4db4:      	cbnz	w9, 0x4da4 <_stogir.pipeline.prepare-checked+0x2370>
    4db8:      	ldr	x9, [sp, #0x260]
    4dbc:      	add	x10, x9, x24, lsl #4
    4dc0:      	ldr	x9, [x10, #0x8]
    4dc4:      	cmp	x9, #0x1
    4dc8:      	b.lt	0x4e6c <_stogir.pipeline.prepare-checked+0x2438>
    4dcc:      	ldr	x10, [x10]
    4dd0:      	cmp	x9, #0x1
    4dd4:      	b.ne	0x4de4 <_stogir.pipeline.prepare-checked+0x23b0>
    4dd8:      	mov	x11, xzr
    4ddc:      	mov	w12, wzr
    4de0:      	b	0x4e34 <_stogir.pipeline.prepare-checked+0x2400>
    4de4:      	add	x14, x21, x10, lsl #3
    4de8:      	mov	w12, wzr
    4dec:      	mov	w13, wzr
    4df0:      	and	x11, x9, #0x7ffffffffffffffe
    4df4:      	and	x15, x9, #0x7ffffffffffffffe
    4df8:      	ldp	x16, x17, [x14, #-0x8]
    4dfc:      	subs	x15, x15, #0x2
    4e00:      	add	x14, x14, #0x10
    4e04:      	sbfiz	x16, x16, #2, #32
    4e08:      	sbfiz	x17, x17, #2, #32
    4e0c:      	ldr	w16, [x20, x16]
    4e10:      	ldr	w17, [x20, x17]
    4e14:      	mvn	w16, w16
    4e18:      	mvn	w17, w17
    4e1c:      	add	w12, w12, w16, lsr #31
    4e20:      	add	w13, w13, w17, lsr #31
    4e24:      	b.ne	0x4df8 <_stogir.pipeline.prepare-checked+0x23c4>
    4e28:      	cmp	x9, x11
    4e2c:      	add	w12, w13, w12
    4e30:      	b.eq	0x4e64 <_stogir.pipeline.prepare-checked+0x2430>
    4e34:      	lsl	x13, x11, #3
    4e38:      	sub	x9, x9, x11
    4e3c:      	ldr	x11, [sp, #0x68]
    4e40:      	add	x10, x13, x10, lsl #3
    4e44:      	add	x10, x11, x10
    4e48:      	ldr	x11, [x10], #0x8
    4e4c:      	subs	x9, x9, #0x1
    4e50:      	sbfiz	x11, x11, #2, #32
    4e54:      	ldr	w11, [x20, x11]
    4e58:      	mvn	w11, w11
    4e5c:      	add	w12, w12, w11, lsr #31
    4e60:      	b.ne	0x4e48 <_stogir.pipeline.prepare-checked+0x2414>
    4e64:      	str	w12, [x20, x24, lsl #2]
    4e68:      	cbnz	w12, 0x4da4 <_stogir.pipeline.prepare-checked+0x2370>
    4e6c:      	ldp	x25, x2, [x29, #-0x88]
    4e70:      	cmp	x25, x2
    4e74:      	b.lt	0x4d98 <_stogir.pipeline.prepare-checked+0x2364>
    4e78:      	lsl	x9, x2, #1
    4e7c:      	cmp	x2, #0x0
    4e80:      	csel	x26, x22, x9, eq
    4e84:      	sub	x9, x29, #0x90
    4e88:      	ldur	q0, [x9, #0x18]
    4e8c:      	cmp	x26, x2
    4e90:      	str	q0, [x7]
    4e94:      	b.le	0x4d98 <_stogir.pipeline.prepare-checked+0x2364>
    4e98:      	sub	x0, x29, #0xc0
    4e9c:      	mov	x1, x30
    4ea0:      	mov	x3, x26
    4ea4:      	mov	x4, x23
    4ea8:      	mov	w5, #0x4                ; =4
    4eac:      	mov	w6, #0x4                ; =4
    4eb0:      	bl	0x4eb0 <_stogir.pipeline.prepare-checked+0x247c>
		0000000000004eb0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    4eb4:      	cbnz	w0, 0x4d7c <_stogir.pipeline.prepare-checked+0x2348>
    4eb8:      	lsl	x1, x26, #2
    4ebc:      	adrp	x0, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004ebc:  ARM64_RELOC_PAGE21	l_cstr.204
    4ec0:      	add	x0, x0, #0x0
		0000000000004ec0:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    4ec4:      	bl	0x4ec4 <_stogir.pipeline.prepare-checked+0x2490>
		0000000000004ec4:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    4ec8:      	ldr	x20, [sp, #0x60]
    4ecc:      	mov	x23, x27
    4ed0:      	b	0x4ee8 <_stogir.pipeline.prepare-checked+0x24b4>
    4ed4:      	ldr	x20, [sp, #0x60]
    4ed8:      	ldr	w21, [sp, #0x40]
    4edc:      	mov	w19, #0x1               ; =1
    4ee0:      	mov	x23, x27
    4ee4:      	add	x22, sp, #0x550
    4ee8:      	ldur	x16, [x29, #-0x88]
    4eec:      	mov	x13, xzr
    4ef0:      	adrp	x12, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004ef0:  ARM64_RELOC_PAGE21	l_str.644
    4ef4:      	add	x12, x12, #0x0
		0000000000004ef4:  ARM64_RELOC_PAGEOFF12	l_str.644
    4ef8:      	adrp	x14, 0x4000 <_stogir.pipeline.prepare-checked+0x15cc>
		0000000000004ef8:  ARM64_RELOC_PAGE21	l_str.649
    4efc:      	add	x14, x14, #0x0
		0000000000004efc:  ARM64_RELOC_PAGEOFF12	l_str.649
    4f00:      	mov	w17, #0x82              ; =130
    4f04:      	mov	w0, #0x5                ; =5
    4f08:      	mov	w3, #0x5e1c             ; =24092
    4f0c:      	stur	x30, [x29, #-0x90]
    4f10:      	cmp	x13, x16
    4f14:      	cset	w27, lt
    4f18:      	b.ge	0x54f8 <_stogir.pipeline.prepare-checked+0x2ac4>
    4f1c:      	ldrsw	x25, [x30, x13, lsl #2]
    4f20:      	ldr	x9, [sp, #0x260]
    4f24:      	add	x10, x9, x25, lsl #4
    4f28:      	ldr	x9, [x10, #0x8]
    4f2c:      	cmp	x9, #0x1
    4f30:      	b.lt	0x524c <_stogir.pipeline.prepare-checked+0x2818>
    4f34:      	ldr	x10, [x10]
    4f38:      	ldr	x11, [sp, #0x68]
    4f3c:      	mov	x24, x12
    4f40:      	mov	x26, x13
    4f44:      	mov	w15, wzr
    4f48:      	mov	x13, xzr
    4f4c:      	add	x10, x11, x10, lsl #3
    4f50:      	ldp	x12, x11, [sp, #0x1e8]
    4f54:      	str	x16, [sp, #0x38]
    4f58:      	b	0x4f6c <_stogir.pipeline.prepare-checked+0x2538>
    4f5c:      	mov	w15, w14
    4f60:      	add	x13, x13, #0x1
    4f64:      	cmp	x9, x13
    4f68:      	b.eq	0x5178 <_stogir.pipeline.prepare-checked+0x2744>
    4f6c:      	add	x1, x10, x13, lsl #3
    4f70:      	mov	w14, w15
    4f74:      	ldrsw	x16, [x1]
    4f78:      	ldrb	w17, [x6, x16]
    4f7c:      	cbz	w17, 0x4f5c <_stogir.pipeline.prepare-checked+0x2528>
    4f80:      	cmp	w16, #0x1
    4f84:      	mov	w0, w16
    4f88:      	b.lt	0x5484 <_stogir.pipeline.prepare-checked+0x2a50>
    4f8c:      	ldr	x15, [x8, #0x8]
    4f90:      	cmp	x15, x0
    4f94:      	b.le	0x5440 <_stogir.pipeline.prepare-checked+0x2a0c>
    4f98:      	ldr	x17, [x8, #0x80]
    4f9c:      	cmp	x17, x0
    4fa0:      	b.le	0x5440 <_stogir.pipeline.prepare-checked+0x2a0c>
    4fa4:      	ldr	x16, [x8, #0x78]
    4fa8:      	ldr	w2, [x16, x0, lsl #2]
    4fac:      	tbnz	w2, #0x1f, 0x5440 <_stogir.pipeline.prepare-checked+0x2a0c>
    4fb0:      	ldr	w1, [x1, #0x4]
    4fb4:      	cmp	w1, #0x1
    4fb8:      	b.lt	0x54bc <_stogir.pipeline.prepare-checked+0x2a88>
    4fbc:      	cmp	w2, w1
    4fc0:      	b.lo	0x54bc <_stogir.pipeline.prepare-checked+0x2a88>
    4fc4:      	subs	w1, w1, #0x1
    4fc8:      	b.eq	0x5028 <_stogir.pipeline.prepare-checked+0x25f4>
    4fcc:      	ldr	x2, [x8]
    4fd0:      	lsl	x3, x0, #4
    4fd4:      	ldr	x3, [x2, x3]
    4fd8:      	and	x4, x3, #0xff
    4fdc:      	cmp	x4, #0x43
    4fe0:      	b.ne	0x5028 <_stogir.pipeline.prepare-checked+0x25f4>
    4fe4:      	lsr	x4, x3, #32
    4fe8:      	cmp	w4, #0x0
    4fec:      	ccmp	x17, x4, #0x0, gt
    4ff0:      	ccmp	x15, x4, #0x0, hi
    4ff4:      	b.ls	0x503c <_stogir.pipeline.prepare-checked+0x2608>
    4ff8:      	ldr	w0, [x16, x4, lsl #2]
    4ffc:      	mov	x3, xzr
    5000:      	tbnz	w0, #0x1f, 0x5170 <_stogir.pipeline.prepare-checked+0x273c>
    5004:      	cmp	w1, w0
    5008:      	b.hi	0x5040 <_stogir.pipeline.prepare-checked+0x260c>
    500c:      	add	w0, w4, w1, lsr #2
    5010:      	and	w1, w1, #0x3
    5014:      	mov	w3, #0x1                ; =1
    5018:      	add	x0, x2, w0, uxtw #4
    501c:      	ldr	w0, [x0, w1, uxtw #2]
    5020:      	cbnz	w3, 0x5044 <_stogir.pipeline.prepare-checked+0x2610>
    5024:      	b	0x5500 <_stogir.pipeline.prepare-checked+0x2acc>
    5028:      	ldr	x15, [sp, #0x70]
    502c:      	mov	w3, #0x5e1c             ; =24092
    5030:      	ldr	w16, [x15, x0, lsl #2]
    5034:      	cbnz	w16, 0x5078 <_stogir.pipeline.prepare-checked+0x2644>
    5038:      	b	0x5514 <_stogir.pipeline.prepare-checked+0x2ae0>
    503c:      	mov	x3, xzr
    5040:      	cbz	w3, 0x5500 <_stogir.pipeline.prepare-checked+0x2acc>
    5044:      	cmp	w0, #0x1
    5048:      	b.lt	0x5470 <_stogir.pipeline.prepare-checked+0x2a3c>
    504c:      	and	x0, x0, #0x7fffffff
    5050:      	mov	w3, #0x5e1c             ; =24092
    5054:      	cmp	x15, x0
    5058:      	b.ls	0x5470 <_stogir.pipeline.prepare-checked+0x2a3c>
    505c:      	cmp	x17, x0
    5060:      	b.ls	0x5470 <_stogir.pipeline.prepare-checked+0x2a3c>
    5064:      	ldr	w15, [x16, x0, lsl #2]
    5068:      	tbnz	w15, #0x1f, 0x5470 <_stogir.pipeline.prepare-checked+0x2a3c>
    506c:      	ldr	x15, [sp, #0x70]
    5070:      	ldr	w16, [x15, x0, lsl #2]
    5074:      	cbz	w16, 0x5528 <_stogir.pipeline.prepare-checked+0x2af4>
    5078:      	cbnz	w14, 0x5084 <_stogir.pipeline.prepare-checked+0x2650>
    507c:      	mov	w15, w16
    5080:      	b	0x4f60 <_stogir.pipeline.prepare-checked+0x252c>
    5084:      	cmp	w16, #0x1
    5088:      	ccmp	w14, #0x1, #0x8, ge
    508c:      	b.ge	0x5098 <_stogir.pipeline.prepare-checked+0x2664>
    5090:      	mov	w15, wzr
    5094:      	b	0x4f60 <_stogir.pipeline.prepare-checked+0x252c>
    5098:      	mov	w17, w14
    509c:      	mov	w15, wzr
    50a0:      	cmp	x11, x17
    50a4:      	b.le	0x4f60 <_stogir.pipeline.prepare-checked+0x252c>
    50a8:      	mov	w0, w16
    50ac:      	cmp	x11, x0
    50b0:      	b.ls	0x4f60 <_stogir.pipeline.prepare-checked+0x252c>
    50b4:      	ldr	w15, [x12, x17, lsl #2]
    50b8:      	cbz	w15, 0x4f60 <_stogir.pipeline.prepare-checked+0x252c>
    50bc:      	ldr	w15, [x12, x0, lsl #2]
    50c0:      	cbz	w15, 0x4f60 <_stogir.pipeline.prepare-checked+0x252c>
    50c4:      	mov	x8, #-0x1               ; =-1
    50c8:      	mov	w15, w14
    50cc:      	mov	w17, w15
    50d0:      	ldr	w15, [x12, w15, sxtw #2]
    50d4:      	add	x8, x8, #0x1
    50d8:      	cmp	w17, w15
    50dc:      	b.ne	0x50cc <_stogir.pipeline.prepare-checked+0x2698>
    50e0:      	mov	x17, #-0x1              ; =-1
    50e4:      	mov	w15, w16
    50e8:      	mov	w0, w15
    50ec:      	ldr	w15, [x12, w15, sxtw #2]
    50f0:      	add	x17, x17, #0x1
    50f4:      	cmp	w0, w15
    50f8:      	b.ne	0x50e8 <_stogir.pipeline.prepare-checked+0x26b4>
    50fc:      	cmp	x8, x17
    5100:      	mov	w15, w14
    5104:      	b.le	0x512c <_stogir.pipeline.prepare-checked+0x26f8>
    5108:      	sub	x8, x8, #0x1
    510c:      	ldr	w14, [x12, w14, sxtw #2]
    5110:      	cmp	x8, x17
    5114:      	b.gt	0x5108 <_stogir.pipeline.prepare-checked+0x26d4>
    5118:      	mov	w15, w14
    511c:      	mov	x8, x17
    5120:      	b	0x512c <_stogir.pipeline.prepare-checked+0x26f8>
    5124:      	ldr	w16, [x12, w16, sxtw #2]
    5128:      	sub	x17, x17, #0x1
    512c:      	cmp	x17, x8
    5130:      	b.gt	0x5124 <_stogir.pipeline.prepare-checked+0x26f0>
    5134:      	ldp	x28, x20, [sp, #0x58]
    5138:      	cmp	w15, w16
    513c:      	ldr	x8, [sp, #0xa0]
    5140:      	ldr	x6, [sp, #0x80]
    5144:      	adrp	x5, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005144:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    5148:      	add	x5, x5, #0x0
		0000000000005148:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    514c:      	sub	x7, x29, #0xc0
    5150:      	add	x22, sp, #0x550
    5154:      	mov	w3, #0x5e1c             ; =24092
    5158:      	b.eq	0x4f60 <_stogir.pipeline.prepare-checked+0x252c>
    515c:      	ldr	w15, [x12, w15, sxtw #2]
    5160:      	ldr	w16, [x12, w16, sxtw #2]
    5164:      	cmp	w15, w16
    5168:      	b.ne	0x515c <_stogir.pipeline.prepare-checked+0x2728>
    516c:      	b	0x4f60 <_stogir.pipeline.prepare-checked+0x252c>
    5170:      	cbnz	w3, 0x5044 <_stogir.pipeline.prepare-checked+0x2610>
    5174:      	b	0x5500 <_stogir.pipeline.prepare-checked+0x2acc>
    5178:      	ldr	x16, [sp, #0x38]
    517c:      	mov	x12, x24
    5180:      	mov	x13, x26
    5184:      	adrp	x14, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005184:  ARM64_RELOC_PAGE21	l_str.649
    5188:      	add	x14, x14, #0x0
		0000000000005188:  ARM64_RELOC_PAGEOFF12	l_str.649
    518c:      	mov	w17, #0x82              ; =130
    5190:      	mov	w0, #0x5                ; =5
    5194:      	cbz	w15, 0x524c <_stogir.pipeline.prepare-checked+0x2818>
    5198:      	ldr	x8, [sp, #0x70]
    519c:      	ldp	x9, x10, [sp, #0x1e8]
    51a0:      	mov	w11, w15
    51a4:      	ldr	w8, [x8, x25, lsl #2]
    51a8:      	cmp	w11, #0x1
    51ac:      	b.lt	0x549c <_stogir.pipeline.prepare-checked+0x2a68>
    51b0:      	mov	w12, w11
    51b4:      	cmp	x10, x12
    51b8:      	b.le	0x549c <_stogir.pipeline.prepare-checked+0x2a68>
    51bc:      	ldr	w12, [x9, x12, lsl #2]
    51c0:      	cbz	w12, 0x549c <_stogir.pipeline.prepare-checked+0x2a68>
    51c4:      	cmp	w11, w8
    51c8:      	b.eq	0x51dc <_stogir.pipeline.prepare-checked+0x27a8>
    51cc:      	cmp	w11, w12
    51d0:      	mov	w11, w12
    51d4:      	b.ne	0x51a8 <_stogir.pipeline.prepare-checked+0x2774>
    51d8:      	b	0x549c <_stogir.pipeline.prepare-checked+0x2a68>
    51dc:      	cmp	w15, w8
    51e0:      	b.eq	0x520c <_stogir.pipeline.prepare-checked+0x27d8>
    51e4:      	ldr	x10, [sp, #0x210]
    51e8:      	mov	w12, w15
    51ec:      	ldr	w11, [x10, w15, sxtw #2]
    51f0:      	ldrsw	x12, [x9, w12, sxtw #2]
    51f4:      	ldr	w13, [x10, x12, lsl #2]
    51f8:      	cmp	w13, w11
    51fc:      	csel	w15, w12, w15, lt
    5200:      	csel	w11, w13, w11, lt
    5204:      	cmp	w12, w8
    5208:      	b.ne	0x51f0 <_stogir.pipeline.prepare-checked+0x27bc>
    520c:      	ldr	x8, [sp, #0x70]
    5210:      	ldr	x6, [sp, #0x80]
    5214:      	adrp	x5, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005214:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    5218:      	add	x5, x5, #0x0
		0000000000005218:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    521c:      	ldr	x28, [sp, #0x58]
    5220:      	ldr	x16, [sp, #0x38]
    5224:      	str	w15, [x8, x25, lsl #2]
    5228:      	ldr	x8, [sp, #0xa0]
    522c:      	sub	x7, x29, #0xc0
    5230:      	mov	x12, x24
    5234:      	mov	x13, x26
    5238:      	adrp	x14, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005238:  ARM64_RELOC_PAGE21	l_str.649
    523c:      	add	x14, x14, #0x0
		000000000000523c:  ARM64_RELOC_PAGEOFF12	l_str.649
    5240:      	mov	w17, #0x82              ; =130
    5244:      	mov	w0, #0x5                ; =5
    5248:      	mov	w3, #0x5e1c             ; =24092
    524c:      	ldr	x9, [x8, #0x78]
    5250:      	str	w21, [sp, #0x40]
    5254:      	ldr	w20, [x9, x25, lsl #2]
    5258:      	cmp	w20, #0x1
    525c:      	b.lt	0x541c <_stogir.pipeline.prepare-checked+0x29e8>
    5260:      	ldr	x9, [x8]
    5264:      	lsl	x10, x25, #4
    5268:      	mov	x26, xzr
    526c:      	mov	w22, #0x1               ; =1
    5270:      	mov	w15, #0x1               ; =1
    5274:      	ldrb	w21, [x9, x10]
    5278:      	b	0x5290 <_stogir.pipeline.prepare-checked+0x285c>
    527c:      	mov	w26, #0x1e              ; =30
    5280:      	mov	x12, x14
    5284:      	add	w22, w22, #0x1
    5288:      	cmp	w22, w20
    528c:      	b.gt	0x5420 <_stogir.pipeline.prepare-checked+0x29ec>
    5290:      	cmp	w22, #0x1
    5294:      	ccmp	x21, x17, #0x2, ge
    5298:      	b.hi	0x52bc <_stogir.pipeline.prepare-checked+0x2888>
    529c:      	cmp	w22, #0x5
    52a0:      	ldr	w10, [x5, x21, lsl #2]
    52a4:      	csel	w9, w22, w0, lo
    52a8:      	lsl	w9, w9, #2
    52ac:      	sub	w9, w9, #0x4
    52b0:      	lsr	w9, w10, w9
    52b4:      	and	w9, w9, #0xf
    52b8:      	b	0x52c0 <_stogir.pipeline.prepare-checked+0x288c>
    52bc:      	mov	w9, wzr
    52c0:      	cmp	w9, #0xf
    52c4:      	b.eq	0x5284 <_stogir.pipeline.prepare-checked+0x2850>
    52c8:      	lsl	w9, w15, w9
    52cc:      	and	w9, w9, w3
    52d0:      	cbz	w9, 0x5284 <_stogir.pipeline.prepare-checked+0x2850>
    52d4:      	cmp	w25, #0x1
    52d8:      	b.lt	0x530c <_stogir.pipeline.prepare-checked+0x28d8>
    52dc:      	ldr	x9, [x8, #0x8]
    52e0:      	cmp	x9, x25
    52e4:      	b.le	0x530c <_stogir.pipeline.prepare-checked+0x28d8>
    52e8:      	ldr	x9, [x8, #0x80]
    52ec:      	cmp	x9, x25
    52f0:      	b.le	0x530c <_stogir.pipeline.prepare-checked+0x28d8>
    52f4:      	ldr	x9, [x8, #0x78]
    52f8:      	ldr	w9, [x9, x25, lsl #2]
    52fc:      	cmp	w22, w9
    5300:      	ccmp	w9, #0x0, #0x8, ls
    5304:      	ccmp	w22, #0x1, #0x8, pl
    5308:      	b.ge	0x53e4 <_stogir.pipeline.prepare-checked+0x29b0>
    530c:      	mov	x9, xzr
    5310:      	cbz	w9, 0x527c <_stogir.pipeline.prepare-checked+0x2848>
    5314:      	cmp	w24, #0x1
    5318:      	b.lt	0x5284 <_stogir.pipeline.prepare-checked+0x2850>
    531c:      	ldr	x9, [sp, #0x550]
    5320:      	and	x10, x24, #0x7fffffff
    5324:      	ldr	w11, [x9, x10, lsl #2]
    5328:      	subs	w11, w11, #0x1
    532c:      	b.lt	0x5284 <_stogir.pipeline.prepare-checked+0x2850>
    5330:      	str	w11, [x9, x10, lsl #2]
    5334:      	b.ne	0x5284 <_stogir.pipeline.prepare-checked+0x2850>
    5338:      	ldur	x2, [x29, #-0x80]
    533c:      	cmp	x16, x2
    5340:      	b.lt	0x5410 <_stogir.pipeline.prepare-checked+0x29dc>
    5344:      	lsl	x9, x2, #1
    5348:      	cmp	x2, #0x0
    534c:      	mov	w10, #0x2               ; =2
    5350:      	str	x23, [sp, #0x30]
    5354:      	csel	x23, x10, x9, eq
    5358:      	sub	x9, x29, #0x90
    535c:      	str	w27, [sp, #0x28]
    5360:      	ldur	q0, [x9, #0x18]
    5364:      	cmp	x23, x2
    5368:      	str	q0, [x7]
    536c:      	b.le	0x5404 <_stogir.pipeline.prepare-checked+0x29d0>
    5370:      	str	x16, [sp, #0x38]
    5374:      	adrp	x4, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005374:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    5378:      	sub	x0, x29, #0xc0
    537c:      	ldr	x4, [x4]
		000000000000537c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    5380:      	mov	x1, x30
    5384:      	mov	x3, x23
    5388:      	mov	w5, #0x4                ; =4
    538c:      	mov	w6, #0x4                ; =4
    5390:      	mov	x28, x13
    5394:      	mov	x27, x12
    5398:      	bl	0x5398 <_stogir.pipeline.prepare-checked+0x2964>
		0000000000005398:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    539c:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    53a0:      	stur	x23, [x29, #-0x80]
    53a4:      	ldp	x23, x16, [sp, #0x30]
    53a8:      	ldr	x8, [sp, #0xa0]
    53ac:      	mov	x30, x1
    53b0:      	adrp	x5, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		00000000000053b0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    53b4:      	add	x5, x5, #0x0
		00000000000053b4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    53b8:      	ldr	x6, [sp, #0x80]
    53bc:      	sub	x7, x29, #0xc0
    53c0:      	mov	x12, x27
    53c4:      	mov	x13, x28
    53c8:      	adrp	x14, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		00000000000053c8:  ARM64_RELOC_PAGE21	l_str.649
    53cc:      	add	x14, x14, #0x0
		00000000000053cc:  ARM64_RELOC_PAGEOFF12	l_str.649
    53d0:      	mov	w17, #0x82              ; =130
    53d4:      	mov	w0, #0x5                ; =5
    53d8:      	mov	w15, #0x1               ; =1
    53dc:      	mov	w3, #0x5e1c             ; =24092
    53e0:      	b	0x5408 <_stogir.pipeline.prepare-checked+0x29d4>
    53e4:      	add	w9, w25, w22, lsr #2
    53e8:      	ldr	x10, [x8]
    53ec:      	add	x9, x10, w9, uxtw #4
    53f0:      	and	w10, w22, #0x3
    53f4:      	ldr	w24, [x9, w10, uxtw #2]
    53f8:      	mov	w9, #0x1                ; =1
    53fc:      	cbnz	w9, 0x5314 <_stogir.pipeline.prepare-checked+0x28e0>
    5400:      	b	0x527c <_stogir.pipeline.prepare-checked+0x2848>
    5404:      	ldr	x23, [sp, #0x30]
    5408:      	ldr	x28, [sp, #0x58]
    540c:      	ldr	w27, [sp, #0x28]
    5410:      	str	w24, [x30, x16, lsl #2]
    5414:      	add	x16, x16, #0x1
    5418:      	b	0x5284 <_stogir.pipeline.prepare-checked+0x2850>
    541c:      	mov	x26, xzr
    5420:      	ldr	w21, [sp, #0x40]
    5424:      	ldr	x20, [sp, #0x60]
    5428:      	add	x13, x13, #0x1
    542c:      	add	x22, sp, #0x550
    5430:      	stp	x30, x16, [x29, #-0x90]
    5434:      	sub	w21, w21, #0x1
    5438:      	cbz	x26, 0x4f10 <_stogir.pipeline.prepare-checked+0x24dc>
    543c:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    5440:      	mov	w27, #0x1               ; =1
    5444:      	mov	w26, #0x21              ; =33
    5448:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005448:  ARM64_RELOC_PAGE21	l_str.659
    544c:      	add	x12, x12, #0x0
		000000000000544c:  ARM64_RELOC_PAGEOFF12	l_str.659
    5450:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    5454:      	mov	w26, #0x20              ; =32
    5458:      	mov	x23, x14
    545c:      	ldr	x2, [sp, #0x560]
    5460:      	str	xzr, [sp, #0x558]
    5464:      	cmp	x2, #0x1
    5468:      	b.ge	0x4854 <_stogir.pipeline.prepare-checked+0x1e20>
    546c:      	b	0x4870 <_stogir.pipeline.prepare-checked+0x1e3c>
    5470:      	mov	w27, #0x1               ; =1
    5474:      	mov	w26, #0x25              ; =37
    5478:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005478:  ARM64_RELOC_PAGE21	l_str.663
    547c:      	add	x12, x12, #0x0
		000000000000547c:  ARM64_RELOC_PAGEOFF12	l_str.663
    5480:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    5484:      	tbnz	w0, #0x1f, 0x553c <_stogir.pipeline.prepare-checked+0x2b08>
    5488:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005488:  ARM64_RELOC_PAGE21	l_str.659
    548c:      	add	x12, x12, #0x0
		000000000000548c:  ARM64_RELOC_PAGEOFF12	l_str.659
    5490:      	mov	w27, #0x1               ; =1
    5494:      	mov	w26, #0x21              ; =33
    5498:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    549c:      	mov	w27, #0x1               ; =1
    54a0:      	mov	w26, #0x29              ; =41
    54a4:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		00000000000054a4:  ARM64_RELOC_PAGE21	l_str.634
    54a8:      	add	x12, x12, #0x0
		00000000000054a8:  ARM64_RELOC_PAGEOFF12	l_str.634
    54ac:      	ldp	x28, x20, [sp, #0x58]
    54b0:      	add	x22, sp, #0x550
    54b4:      	ldr	x6, [sp, #0x80]
    54b8:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    54bc:      	mov	w27, #0x1               ; =1
    54c0:      	mov	w26, #0x13              ; =19
    54c4:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		00000000000054c4:  ARM64_RELOC_PAGE21	l_str.660
    54c8:      	add	x12, x12, #0x0
		00000000000054c8:  ARM64_RELOC_PAGEOFF12	l_str.660
    54cc:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    54d0:      	mov	w19, wzr
    54d4:      	adrp	x23, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		00000000000054d4:  ARM64_RELOC_PAGE21	l_str.639
    54d8:      	add	x23, x23, #0x0
		00000000000054d8:  ARM64_RELOC_PAGEOFF12	l_str.639
    54dc:      	add	x22, sp, #0x550
    54e0:      	ldr	x2, [sp, #0x560]
    54e4:      	mov	w21, w7
    54e8:      	str	xzr, [sp, #0x558]
    54ec:      	cmp	x2, #0x1
    54f0:      	b.ge	0x473c <_stogir.pipeline.prepare-checked+0x1d08>
    54f4:      	b	0x476c <_stogir.pipeline.prepare-checked+0x1d38>
    54f8:      	mov	x26, xzr
    54fc:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    5500:      	mov	w27, #0x1               ; =1
    5504:      	mov	w26, #0x17              ; =23
    5508:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005508:  ARM64_RELOC_PAGE21	l_str.662
    550c:      	add	x12, x12, #0x0
		000000000000550c:  ARM64_RELOC_PAGEOFF12	l_str.662
    5510:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    5514:      	mov	w27, #0x1               ; =1
    5518:      	mov	w26, #0xf               ; =15
    551c:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		000000000000551c:  ARM64_RELOC_PAGE21	l_str.665
    5520:      	add	x12, x12, #0x0
		0000000000005520:  ARM64_RELOC_PAGEOFF12	l_str.665
    5524:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    5528:      	mov	w27, #0x1               ; =1
    552c:      	mov	w26, #0x1a              ; =26
    5530:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005530:  ARM64_RELOC_PAGE21	l_str.664
    5534:      	add	x12, x12, #0x0
		0000000000005534:  ARM64_RELOC_PAGEOFF12	l_str.664
    5538:      	b	0x55a8 <_stogir.pipeline.prepare-checked+0x2b74>
    553c:      	ldr	x9, [x8, #0x30]
    5540:      	ldr	x8, [x8, #0x58]
    5544:      	adrp	x12, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005544:  ARM64_RELOC_PAGE21	l_str.659
    5548:      	add	x12, x12, #0x0
		0000000000005548:  ARM64_RELOC_PAGEOFF12	l_str.659
    554c:      	mov	w26, #0x21              ; =33
    5550:      	cmp	x9, x8
    5554:      	b.ne	0x5598 <_stogir.pipeline.prepare-checked+0x2b64>
    5558:      	neg	x8, x16
    555c:      	cmp	x9, x8
    5560:      	b.lt	0x5598 <_stogir.pipeline.prepare-checked+0x2b64>
    5564:      	ldr	x8, [sp, #0xa0]
    5568:      	mvn	x9, x16
    556c:      	mov	w27, #0x1               ; =1
    5570:      	ldr	x8, [x8, #0x50]
    5574:      	ldr	w8, [x8, x9, lsl #2]
    5578:      	mov	w9, #0x13               ; =19
    557c:      	cmp	w8, #0x0
    5580:      	mov	w8, #0x21               ; =33
    5584:      	csel	x26, x9, x8, gt
    5588:      	adrp	x8, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005588:  ARM64_RELOC_PAGE21	l_str.660
    558c:      	add	x8, x8, #0x0
		000000000000558c:  ARM64_RELOC_PAGEOFF12	l_str.660
    5590:      	csel	x12, x8, x12, gt
    5594:      	b	0x54ac <_stogir.pipeline.prepare-checked+0x2a78>
    5598:      	ldp	x28, x20, [sp, #0x58]
    559c:      	add	x22, sp, #0x550
    55a0:      	ldr	x6, [sp, #0x80]
    55a4:      	mov	w27, #0x1               ; =1
    55a8:      	cbz	x19, 0x55b0 <_stogir.pipeline.prepare-checked+0x2b7c>
    55ac:      	str	xzr, [sp, #0x558]
    55b0:      	ldr	x2, [sp, #0x560]
    55b4:      	mov	x24, x12
    55b8:      	cmp	x2, #0x1
    55bc:      	b.lt	0x55e8 <_stogir.pipeline.prepare-checked+0x2bb4>
    55c0:      	adrp	x3, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		00000000000055c0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    55c4:      	ldr	x1, [sp, #0x550]
    55c8:      	add	x0, x22, #0x18
    55cc:      	ldr	x3, [x3]
		00000000000055cc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    55d0:      	mov	w4, #0x4                ; =4
    55d4:      	mov	w5, #0x4                ; =4
    55d8:      	mov	x19, x30
    55dc:      	bl	0x55dc <_stogir.pipeline.prepare-checked+0x2ba8>
		00000000000055dc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    55e0:      	ldr	x6, [sp, #0x80]
    55e4:      	mov	x30, x19
    55e8:      	ldur	x2, [x29, #-0x80]
    55ec:      	str	xzr, [sp, #0x558]
    55f0:      	str	xzr, [sp, #0x550]
    55f4:      	cmp	x2, #0x1
    55f8:      	str	xzr, [sp, #0x560]
    55fc:      	stur	xzr, [x29, #-0x88]
    5600:      	b.lt	0x5628 <_stogir.pipeline.prepare-checked+0x2bf4>
    5604:      	adrp	x3, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005604:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    5608:      	sub	x8, x29, #0x90
    560c:      	mov	x1, x30
    5610:      	ldr	x3, [x3]
		0000000000005610:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    5614:      	add	x0, x8, #0x18
    5618:      	mov	w4, #0x4                ; =4
    561c:      	mov	w5, #0x4                ; =4
    5620:      	bl	0x5620 <_stogir.pipeline.prepare-checked+0x2bec>
		0000000000005620:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    5624:      	ldr	x6, [sp, #0x80]
    5628:      	tbz	w27, #0x0, 0x5644 <_stogir.pipeline.prepare-checked+0x2c10>
    562c:      	ldp	x8, x9, [sp, #0x98]
    5630:      	mov	x23, x24
    5634:      	add	x17, sp, #0x550
    5638:      	sub	x0, x29, #0xc0
    563c:      	cbnz	x26, 0x6ee0 <_stogir.pipeline.prepare-checked+0x44ac>
    5640:      	b	0x5668 <_stogir.pipeline.prepare-checked+0x2c34>
    5644:      	ldp	x8, x9, [sp, #0x98]
    5648:      	cmp	w21, #0x0
    564c:      	add	x17, sp, #0x550
    5650:      	sub	x0, x29, #0xc0
    5654:      	b.le	0x5668 <_stogir.pipeline.prepare-checked+0x2c34>
    5658:      	adrp	x23, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005658:  ARM64_RELOC_PAGE21	l_str.651
    565c:      	add	x23, x23, #0x0
		000000000000565c:  ARM64_RELOC_PAGEOFF12	l_str.651
    5660:      	mov	w26, #0x26              ; =38
    5664:      	b	0x6ee0 <_stogir.pipeline.prepare-checked+0x44ac>
    5668:      	str	x23, [sp, #0x30]
    566c:      	adrp	x19, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		000000000000566c:  ARM64_RELOC_PAGE21	l_str.389
    5670:      	add	x19, x19, #0x0
		0000000000005670:  ARM64_RELOC_PAGEOFF12	l_str.389
    5674:      	mov	w23, #0x1               ; =1
    5678:      	adrp	x20, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005678:  ARM64_RELOC_PAGE21	l_str.391
    567c:      	add	x20, x20, #0x0
		000000000000567c:  ARM64_RELOC_PAGEOFF12	l_str.391
    5680:      	b	0x569c <_stogir.pipeline.prepare-checked+0x2c68>
    5684:      	mov	x26, xzr
    5688:      	adds	x10, x21, #0x4
    568c:      	add	x11, x21, #0x7
    5690:      	csel	x10, x11, x10, mi
    5694:      	add	x23, x23, x10, asr #2
    5698:      	cbnz	x26, 0x57d4 <_stogir.pipeline.prepare-checked+0x2da0>
    569c:      	ldr	x10, [x9, #0x8]
    56a0:      	cmp	x23, x10
    56a4:      	b.ge	0x5740 <_stogir.pipeline.prepare-checked+0x2d0c>
    56a8:      	ldr	x10, [x9]
    56ac:      	lsl	x11, x23, #4
    56b0:      	ldr	x22, [x10, x11]
    56b4:      	ldr	x10, [x9, #0x78]
    56b8:      	and	x11, x22, #0xff
    56bc:      	ldrsw	x21, [x10, x23, lsl #2]
    56c0:      	cmp	x11, #0x2c
    56c4:      	b.ne	0x5684 <_stogir.pipeline.prepare-checked+0x2c50>
    56c8:      	ldrb	w10, [x6, x23]
    56cc:      	cbz	w10, 0x5684 <_stogir.pipeline.prepare-checked+0x2c50>
    56d0:      	add	x0, sp, #0x550
    56d4:      	mov	x1, x9
    56d8:      	mov	w2, w23
    56dc:      	bl	0x56dc <_stogir.pipeline.prepare-checked+0x2ca8>
		00000000000056dc:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    56e0:      	ldr	w8, [sp, #0x550]
    56e4:      	cmp	w8, #0x1
    56e8:      	b.ne	0x5708 <_stogir.pipeline.prepare-checked+0x2cd4>
    56ec:      	ldp	x8, x9, [sp, #0x98]
    56f0:      	add	x17, sp, #0x550
    56f4:      	ldr	x19, [sp, #0x558]
    56f8:      	ldr	x26, [sp, #0x560]
    56fc:      	sub	x0, x29, #0xc0
    5700:      	ldr	x6, [sp, #0x80]
    5704:      	b	0x5688 <_stogir.pipeline.prepare-checked+0x2c54>
    5708:      	ldp	x8, x9, [sp, #0x98]
    570c:      	add	x17, sp, #0x550
    5710:      	ldr	w10, [sp, #0x558]
    5714:      	ldr	x6, [sp, #0x80]
    5718:      	sub	x0, x29, #0xc0
    571c:      	cbz	w10, 0x5684 <_stogir.pipeline.prepare-checked+0x2c50>
    5720:      	asr	x10, x22, #32
    5724:      	ldr	x11, [sp, #0x70]
    5728:      	ldr	w10, [x11, x10, lsl #2]
    572c:      	cmp	w10, #0x1
    5730:      	b.lt	0x5958 <_stogir.pipeline.prepare-checked+0x2f24>
    5734:      	mov	x26, xzr
    5738:      	str	w10, [x11, x23, lsl #2]
    573c:      	b	0x5688 <_stogir.pipeline.prepare-checked+0x2c54>
    5740:      	ldr	x10, [sp, #0x100]
    5744:      	ldr	x26, [sp, #0x1e8]
    5748:      	cmp	x10, #0x1
    574c:      	b.lt	0x5890 <_stogir.pipeline.prepare-checked+0x2e5c>
    5750:      	ldr	x20, [sp, #0x1f0]
    5754:      	ldr	x19, [sp, #0x210]
    5758:      	mov	w11, wzr
    575c:      	ldr	x12, [sp, #0xf8]
    5760:      	mov	x13, xzr
    5764:      	b	0x5778 <_stogir.pipeline.prepare-checked+0x2d44>
    5768:      	mov	w11, #0x1               ; =1
    576c:      	add	x13, x13, #0x1
    5770:      	cmp	x13, x10
    5774:      	b.eq	0x57dc <_stogir.pipeline.prepare-checked+0x2da8>
    5778:      	add	x15, x12, x13, lsl #4
    577c:      	ldrsw	x14, [x15]
    5780:      	ldr	w16, [x26, x14, lsl #2]
    5784:      	cmp	w16, #0x1
    5788:      	b.lt	0x576c <_stogir.pipeline.prepare-checked+0x2d38>
    578c:      	ldrsw	x15, [x15, #0x4]
    5790:      	ldr	w16, [x26, x15, lsl #2]
    5794:      	cmp	w16, #0x1
    5798:      	ccmp	w14, w15, #0x8, ge
    579c:      	b.lt	0x576c <_stogir.pipeline.prepare-checked+0x2d38>
    57a0:      	cmp	w14, #0x1
    57a4:      	b.lt	0x5768 <_stogir.pipeline.prepare-checked+0x2d34>
    57a8:      	mov	w16, w14
    57ac:      	cmp	x20, x16
    57b0:      	b.le	0x5768 <_stogir.pipeline.prepare-checked+0x2d34>
    57b4:      	ldr	w16, [x26, x16, lsl #2]
    57b8:      	cbz	w16, 0x5768 <_stogir.pipeline.prepare-checked+0x2d34>
    57bc:      	cmp	w14, w15
    57c0:      	b.eq	0x576c <_stogir.pipeline.prepare-checked+0x2d38>
    57c4:      	cmp	w14, w16
    57c8:      	mov	w14, w16
    57cc:      	b.ne	0x57a0 <_stogir.pipeline.prepare-checked+0x2d6c>
    57d0:      	b	0x5768 <_stogir.pipeline.prepare-checked+0x2d34>
    57d4:      	mov	x23, x19
    57d8:      	b	0x6edc <_stogir.pipeline.prepare-checked+0x44a8>
    57dc:      	ldr	x12, [sp, #0x1c8]
    57e0:      	cbz	x12, 0x6230 <_stogir.pipeline.prepare-checked+0x37fc>
    57e4:      	add	x16, sp, #0x550
    57e8:      	tbz	w11, #0x0, 0x5898 <_stogir.pipeline.prepare-checked+0x2e64>
    57ec:      	ldr	x8, [sp, #0x98]
    57f0:      	cmp	x20, #0x1
    57f4:      	stp	xzr, xzr, [x29, #-0xf0]
    57f8:      	stur	xzr, [x29, #-0xe0]
    57fc:      	ldr	q0, [x8]
    5800:      	stur	q0, [x16, #0xe8]
    5804:      	b.lt	0x5964 <_stogir.pipeline.prepare-checked+0x2f30>
    5808:      	adrp	x23, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005808:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    580c:      	mov	x21, xzr
    5810:      	mov	x1, xzr
    5814:      	ldr	x23, [x23]
		0000000000005814:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    5818:      	mov	w22, #-0x1              ; =-1
    581c:      	mov	w24, #0x2               ; =2
    5820:      	add	x9, sp, #0x550
    5824:      	sub	x27, x29, #0xf0
    5828:      	b	0x5840 <_stogir.pipeline.prepare-checked+0x2e0c>
    582c:      	str	w22, [x1, x21, lsl #2]
    5830:      	add	x21, x21, #0x1
    5834:      	cmp	x20, x21
    5838:      	stur	x21, [x29, #-0xe8]
    583c:      	b.eq	0x594c <_stogir.pipeline.prepare-checked+0x2f18>
    5840:      	ldur	x2, [x29, #-0xe0]
    5844:      	cmp	x21, x2
    5848:      	b.lt	0x582c <_stogir.pipeline.prepare-checked+0x2df8>
    584c:      	lsl	x8, x2, #1
    5850:      	cmp	x2, #0x0
    5854:      	ldur	q0, [x27, #0x18]
    5858:      	csel	x25, x24, x8, eq
    585c:      	str	q0, [x9, #0x80]
    5860:      	cmp	x25, x2
    5864:      	b.le	0x582c <_stogir.pipeline.prepare-checked+0x2df8>
    5868:      	add	x0, sp, #0x5d0
    586c:      	mov	x3, x25
    5870:      	mov	x4, x23
    5874:      	mov	w5, #0x4                ; =4
    5878:      	mov	w6, #0x4                ; =4
    587c:      	bl	0x587c <_stogir.pipeline.prepare-checked+0x2e48>
		000000000000587c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    5880:      	cbz	w0, 0x41c4 <_stogir.pipeline.prepare-checked+0x1790>
    5884:      	add	x9, sp, #0x550
    5888:      	stur	x25, [x29, #-0xe0]
    588c:      	b	0x582c <_stogir.pipeline.prepare-checked+0x2df8>
    5890:      	ldr	x12, [sp, #0x1c8]
    5894:      	cbz	x12, 0x6230 <_stogir.pipeline.prepare-checked+0x37fc>
    5898:      	ldp	x10, x11, [sp, #0xa8]
    589c:      	mov	x8, xzr
    58a0:      	mov	x9, xzr
    58a4:      	cmp	xzr, x11
    58a8:      	b.ge	0x58c8 <_stogir.pipeline.prepare-checked+0x2e94>
    58ac:      	b	0x58d0 <_stogir.pipeline.prepare-checked+0x2e9c>
    58b0:      	sbfiz	x13, x13, #2, #32
    58b4:      	ldr	w13, [x26, x13]
    58b8:      	cmp	w13, #0x0
    58bc:      	cinc	x9, x9, gt
    58c0:      	cmp	x8, x11
    58c4:      	b.lt	0x58d0 <_stogir.pipeline.prepare-checked+0x2e9c>
    58c8:      	mov	x14, xzr
    58cc:      	b	0x58dc <_stogir.pipeline.prepare-checked+0x2ea8>
    58d0:      	ldr	w13, [x10, x8, lsl #2]
    58d4:      	add	x8, x8, #0x1
    58d8:      	mov	w14, #0x1               ; =1
    58dc:      	cbnz	w14, 0x58b0 <_stogir.pipeline.prepare-checked+0x2e7c>
    58e0:      	cmp	x9, x12
    58e4:      	b.ne	0x593c <_stogir.pipeline.prepare-checked+0x2f08>
    58e8:      	ldp	x8, x9, [sp, #0x98]
    58ec:      	mov	x12, xzr
    58f0:      	ldr	x13, [sp, #0x1c0]
    58f4:      	mov	x14, xzr
    58f8:      	add	x17, sp, #0x550
    58fc:      	sub	x0, x29, #0xc0
    5900:      	cmp	x14, x11
    5904:      	b.ge	0x5918 <_stogir.pipeline.prepare-checked+0x2ee4>
    5908:      	ldr	w15, [x10, x14, lsl #2]
    590c:      	add	x14, x14, #0x1
    5910:      	mov	w16, #0x1               ; =1
    5914:      	b	0x591c <_stogir.pipeline.prepare-checked+0x2ee8>
    5918:      	mov	x16, xzr
    591c:      	cbz	w16, 0x6230 <_stogir.pipeline.prepare-checked+0x37fc>
    5920:      	sbfiz	x16, x15, #2, #32
    5924:      	ldr	w16, [x26, x16]
    5928:      	cmp	w16, #0x1
    592c:      	b.lt	0x5900 <_stogir.pipeline.prepare-checked+0x2ecc>
    5930:      	str	w15, [x13, x12, lsl #2]
    5934:      	add	x12, x12, #0x1
    5938:      	b	0x5900 <_stogir.pipeline.prepare-checked+0x2ecc>
    593c:      	adrp	x23, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		000000000000593c:  ARM64_RELOC_PAGE21	l_str.492
    5940:      	add	x23, x23, #0x0
		0000000000005940:  ARM64_RELOC_PAGEOFF12	l_str.492
    5944:      	mov	w26, #0x32              ; =50
    5948:      	b	0x6ed8 <_stogir.pipeline.prepare-checked+0x44a4>
    594c:      	ldr	x12, [sp, #0x1c8]
    5950:      	add	x16, sp, #0x550
    5954:      	b	0x5968 <_stogir.pipeline.prepare-checked+0x2f34>
    5958:      	mov	w26, #0x21              ; =33
    595c:      	mov	x23, x20
    5960:      	b	0x6edc <_stogir.pipeline.prepare-checked+0x44a8>
    5964:      	mov	x1, xzr
    5968:      	cmp	x12, #0x1
    596c:      	stur	x1, [x29, #-0xf0]
    5970:      	b.lt	0x5994 <_stogir.pipeline.prepare-checked+0x2f60>
    5974:      	mov	x8, xzr
    5978:      	ldr	x9, [sp, #0x1c0]
    597c:      	ldrsw	x9, [x9, x8, lsl #2]
    5980:      	str	w8, [x1, x9, lsl #2]
    5984:      	add	x8, x8, #0x1
    5988:      	ldr	x9, [sp, #0x1c8]
    598c:      	cmp	x8, x9
    5990:      	b.lt	0x5978 <_stogir.pipeline.prepare-checked+0x2f44>
    5994:      	ldr	x8, [sp, #0x100]
    5998:      	cmp	x8, #0x1
    599c:      	b.lt	0x5a20 <_stogir.pipeline.prepare-checked+0x2fec>
    59a0:      	ldr	x10, [sp, #0xf8]
    59a4:      	ldur	x1, [x29, #-0xf0]
    59a8:      	mov	x9, xzr
    59ac:      	mov	w11, #0x1               ; =1
    59b0:      	b	0x59c4 <_stogir.pipeline.prepare-checked+0x2f90>
    59b4:      	mov	w11, wzr
    59b8:      	add	x9, x9, #0x1
    59bc:      	cmp	x9, x8
    59c0:      	b.eq	0x5a1c <_stogir.pipeline.prepare-checked+0x2fe8>
    59c4:      	add	x13, x10, x9, lsl #4
    59c8:      	ldrsw	x12, [x13]
    59cc:      	ldr	w14, [x1, x12, lsl #2]
    59d0:      	tbnz	w14, #0x1f, 0x59b8 <_stogir.pipeline.prepare-checked+0x2f84>
    59d4:      	ldrsw	x13, [x13, #0x4]
    59d8:      	ldr	w15, [x1, x13, lsl #2]
    59dc:      	tbnz	w15, #0x1f, 0x59b8 <_stogir.pipeline.prepare-checked+0x2f84>
    59e0:      	cmp	w14, w15
    59e4:      	b.lo	0x59b8 <_stogir.pipeline.prepare-checked+0x2f84>
    59e8:      	cmp	w12, #0x1
    59ec:      	b.lt	0x59b4 <_stogir.pipeline.prepare-checked+0x2f80>
    59f0:      	mov	w14, w12
    59f4:      	cmp	x20, x14
    59f8:      	b.le	0x59b4 <_stogir.pipeline.prepare-checked+0x2f80>
    59fc:      	ldr	w14, [x26, x14, lsl #2]
    5a00:      	cbz	w14, 0x59b4 <_stogir.pipeline.prepare-checked+0x2f80>
    5a04:      	cmp	w12, w13
    5a08:      	b.eq	0x59b8 <_stogir.pipeline.prepare-checked+0x2f84>
    5a0c:      	cmp	w12, w14
    5a10:      	mov	w12, w14
    5a14:      	b.ne	0x59e8 <_stogir.pipeline.prepare-checked+0x2fb4>
    5a18:      	b	0x59b4 <_stogir.pipeline.prepare-checked+0x2f80>
    5a1c:      	tbz	w11, #0x0, 0x61ec <_stogir.pipeline.prepare-checked+0x37b8>
    5a20:      	ldr	x8, [sp, #0x98]
    5a24:      	sub	x9, x29, #0xc0
    5a28:      	stp	xzr, xzr, [x29, #-0xc0]
    5a2c:      	stur	xzr, [x29, #-0xb0]
    5a30:      	ldur	x10, [x29, #-0xe8]
    5a34:      	ldr	q0, [x8]
    5a38:      	ldr	x8, [sp, #0x1c0]
    5a3c:      	str	xzr, [sp, #0x560]
    5a40:      	str	xzr, [sp, #0x550]
    5a44:      	cmp	x10, #0x1
    5a48:      	stur	q0, [x9, #0x18]
    5a4c:      	str	xzr, [sp, #0x558]
    5a50:      	stur	q0, [x16, #0x18]
    5a54:      	stp	xzr, xzr, [x29, #-0x90]
    5a58:      	stur	xzr, [x29, #-0x80]
    5a5c:      	stur	q0, [x9, #0x48]
    5a60:      	ldrsw	x8, [x8]
    5a64:      	str	x10, [sp, #0x28]
    5a68:      	str	x8, [sp, #0x38]
    5a6c:      	b.lt	0x5a80 <_stogir.pipeline.prepare-checked+0x304c>
    5a70:      	ldr	x8, [sp, #0x28]
    5a74:      	ldur	x0, [x29, #-0xf0]
    5a78:      	lsl	x1, x8, #2
    5a7c:      	bl	0x5a7c <_stogir.pipeline.prepare-checked+0x3048>
		0000000000005a7c:  ARM64_RELOC_BRANCH26	_bzero
    5a80:      	ldp	x24, x27, [sp, #0x198]
    5a84:      	adrp	x23, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005a84:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    5a88:      	ldr	x23, [x23]
		0000000000005a88:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    5a8c:      	mov	x21, xzr
    5a90:      	mov	x25, xzr
    5a94:      	mov	x22, xzr
    5a98:      	sub	x10, x29, #0xc0
    5a9c:      	mov	w28, #0x2               ; =2
    5aa0:      	add	x9, sp, #0x550
    5aa4:      	b	0x5ab4 <_stogir.pipeline.prepare-checked+0x3080>
    5aa8:      	str	x20, [x25, x21, lsl #3]
    5aac:      	add	x21, x21, #0x1
    5ab0:      	stur	x21, [x29, #-0xb8]
    5ab4:      	cmp	x22, x27
    5ab8:      	b.ge	0x5acc <_stogir.pipeline.prepare-checked+0x3098>
    5abc:      	ldr	x20, [x24, x22, lsl #3]
    5ac0:      	add	x22, x22, #0x1
    5ac4:      	mov	w8, #0x1                ; =1
    5ac8:      	b	0x5ad0 <_stogir.pipeline.prepare-checked+0x309c>
    5acc:      	mov	x8, xzr
    5ad0:      	cbz	w8, 0x5b30 <_stogir.pipeline.prepare-checked+0x30fc>
    5ad4:      	ldur	x2, [x29, #-0xb0]
    5ad8:      	cmp	x21, x2
    5adc:      	b.lt	0x5aa8 <_stogir.pipeline.prepare-checked+0x3074>
    5ae0:      	lsl	x8, x2, #1
    5ae4:      	cmp	x2, #0x0
    5ae8:      	ldur	q0, [x10, #0x18]
    5aec:      	csel	x26, x28, x8, eq
    5af0:      	str	q0, [x9, #0x80]
    5af4:      	cmp	x26, x2
    5af8:      	b.le	0x5aa8 <_stogir.pipeline.prepare-checked+0x3074>
    5afc:      	add	x0, sp, #0x5d0
    5b00:      	mov	x1, x25
    5b04:      	mov	x3, x26
    5b08:      	mov	x4, x23
    5b0c:      	mov	w5, #0x8                ; =8
    5b10:      	mov	w6, #0x8                ; =8
    5b14:      	bl	0x5b14 <_stogir.pipeline.prepare-checked+0x30e0>
		0000000000005b14:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    5b18:      	cbz	w0, 0x736c <_stogir.pipeline.prepare-checked+0x4938>
    5b1c:      	mov	x25, x1
    5b20:      	add	x9, sp, #0x550
    5b24:      	sub	x10, x29, #0xc0
    5b28:      	stur	x26, [x29, #-0xb0]
    5b2c:      	b	0x5aa8 <_stogir.pipeline.prepare-checked+0x3074>
    5b30:      	ldr	x8, [sp, #0x170]
    5b34:      	ldr	x9, [sp, #0x38]
    5b38:      	stur	x25, [x29, #-0xc0]
    5b3c:      	add	x8, x8, x9, lsl #4
    5b40:      	ldr	x21, [x8, #0x8]
    5b44:      	cmp	x21, #0x2
    5b48:      	b.lt	0x5c28 <_stogir.pipeline.prepare-checked+0x31f4>
    5b4c:      	ldr	x9, [x8]
    5b50:      	lsr	x8, x21, #1
    5b54:      	add	x9, x25, x9, lsl #3
    5b58:      	b	0x5b64 <_stogir.pipeline.prepare-checked+0x3130>
    5b5c:      	cmp	x10, #0x1
    5b60:      	b.le	0x5c28 <_stogir.pipeline.prepare-checked+0x31f4>
    5b64:      	mov	x10, x8
    5b68:      	sub	x8, x8, #0x1
    5b6c:      	mov	w13, #0x1               ; =1
    5b70:      	bfi	x13, x8, #1, #63
    5b74:      	cmp	x13, x21
    5b78:      	b.ge	0x5b5c <_stogir.pipeline.prepare-checked+0x3128>
    5b7c:      	lsl	x14, x8, #1
    5b80:      	sub	x11, x10, #0x1
    5b84:      	b	0x5ba8 <_stogir.pipeline.prepare-checked+0x3174>
    5b88:      	mov	w13, #0x1               ; =1
    5b8c:      	lsl	x14, x12, #1
    5b90:      	str	x16, [x9, x11, lsl #3]
    5b94:      	bfi	x13, x12, #1, #63
    5b98:      	mov	x11, x12
    5b9c:      	str	x15, [x9, x12, lsl #3]
    5ba0:      	cmp	x13, x21
    5ba4:      	b.ge	0x5b5c <_stogir.pipeline.prepare-checked+0x3128>
    5ba8:      	add	x12, x14, #0x2
    5bac:      	ldr	x14, [sp, #0xf8]
    5bb0:      	cmp	x12, x21
    5bb4:      	b.ge	0x5be8 <_stogir.pipeline.prepare-checked+0x31b4>
    5bb8:      	add	x15, x9, x13, lsl #3
    5bbc:      	ldp	x15, x16, [x15]
    5bc0:      	add	x17, x14, x16, lsl #4
    5bc4:      	add	x0, x14, x15, lsl #4
    5bc8:      	ldrsw	x17, [x17, #0x4]
    5bcc:      	ldrsw	x0, [x0, #0x4]
    5bd0:      	ldr	w17, [x19, x17, lsl #2]
    5bd4:      	ldr	w0, [x19, x0, lsl #2]
    5bd8:      	cmp	w17, w0
    5bdc:      	ccmp	x16, x15, #0x4, eq
    5be0:      	ccmp	w17, w0, #0x8, le
    5be4:      	b.lt	0x5bec <_stogir.pipeline.prepare-checked+0x31b8>
    5be8:      	mov	x12, x13
    5bec:      	ldr	x16, [x9, x12, lsl #3]
    5bf0:      	ldr	x15, [x9, x11, lsl #3]
    5bf4:      	add	x13, x14, x16, lsl #4
    5bf8:      	add	x14, x14, x15, lsl #4
    5bfc:      	cmp	x16, x15
    5c00:      	cset	w17, le
    5c04:      	ldrsw	x13, [x13, #0x4]
    5c08:      	ldrsw	x14, [x14, #0x4]
    5c0c:      	ldr	w13, [x19, x13, lsl #2]
    5c10:      	ldr	w14, [x19, x14, lsl #2]
    5c14:      	cmp	w13, w14
    5c18:      	csinc	w13, w17, wzr, eq
    5c1c:      	b.lt	0x5b88 <_stogir.pipeline.prepare-checked+0x3154>
    5c20:      	tbz	w13, #0x0, 0x5b88 <_stogir.pipeline.prepare-checked+0x3154>
    5c24:      	b	0x5b5c <_stogir.pipeline.prepare-checked+0x3128>
    5c28:      	ldr	x22, [sp, #0x558]
    5c2c:      	ldr	x2, [sp, #0x560]
    5c30:      	cmp	x22, x2
    5c34:      	b.lt	0x5c8c <_stogir.pipeline.prepare-checked+0x3258>
    5c38:      	lsl	x8, x2, #1
    5c3c:      	cmp	x2, #0x0
    5c40:      	mov	w9, #0x2                ; =2
    5c44:      	csel	x8, x9, x8, eq
    5c48:      	cmp	x8, x2
    5c4c:      	str	x8, [sp, #0x40]
    5c50:      	b.le	0x5c8c <_stogir.pipeline.prepare-checked+0x3258>
    5c54:      	adrp	x4, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005c54:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    5c58:      	add	x8, sp, #0x550
    5c5c:      	mov	x1, xzr
    5c60:      	ldr	x4, [x4]
		0000000000005c60:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    5c64:      	ldr	x3, [sp, #0x40]
    5c68:      	add	x0, x8, #0x18
    5c6c:      	mov	w5, #0x10               ; =16
    5c70:      	mov	w6, #0x8                ; =8
    5c74:      	bl	0x5c74 <_stogir.pipeline.prepare-checked+0x3240>
		0000000000005c74:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    5c78:      	cbz	w0, 0x73ac <_stogir.pipeline.prepare-checked+0x4978>
    5c7c:      	ldr	x8, [sp, #0x40]
    5c80:      	str	x1, [sp, #0x550]
    5c84:      	str	x8, [sp, #0x560]
    5c88:      	b	0x5c90 <_stogir.pipeline.prepare-checked+0x325c>
    5c8c:      	str	x2, [sp, #0x40]
    5c90:      	ldr	x26, [sp, #0x550]
    5c94:      	ldr	x10, [sp, #0x38]
    5c98:      	add	x27, x22, #0x1
    5c9c:      	add	x8, x26, x22, lsl #4
    5ca0:      	mov	w9, w10
    5ca4:      	stp	x9, x21, [x8]
    5ca8:      	mov	w9, #0x1                ; =1
    5cac:      	ldur	x8, [x29, #-0xf0]
    5cb0:      	str	x27, [sp, #0x558]
    5cb4:      	str	w9, [x8, x10, lsl #2]
    5cb8:      	mov	x28, x8
    5cbc:      	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
    5cc0:      	ldur	x24, [x29, #-0x90]
    5cc4:      	cmp	x22, x8
    5cc8:      	b.ls	0x5e34 <_stogir.pipeline.prepare-checked+0x3400>
    5ccc:      	ldr	x8, [sp, #0x40]
    5cd0:      	ldur	x19, [x29, #-0x88]
    5cd4:      	str	x26, [sp, #0x550]
    5cd8:      	str	x27, [sp, #0x558]
    5cdc:      	str	x8, [sp, #0x560]
    5ce0:      	ldr	x8, [sp, #0x1c8]
    5ce4:      	stur	x24, [x29, #-0x90]
    5ce8:      	cmp	x19, x8
    5cec:      	b.ne	0x6104 <_stogir.pipeline.prepare-checked+0x36d0>
    5cf0:      	cmp	x19, #0x1
    5cf4:      	b.lt	0x5d48 <_stogir.pipeline.prepare-checked+0x3314>
    5cf8:      	ldr	x8, [sp, #0x1c0]
    5cfc:      	cmp	x19, #0x8
    5d00:      	b.lo	0x5d1c <_stogir.pipeline.prepare-checked+0x32e8>
    5d04:      	lsl	x9, x19, #2
    5d08:      	add	x10, x8, x9
    5d0c:      	add	x9, x24, x9
    5d10:      	cmp	x24, x10
    5d14:      	ccmp	x8, x9, #0x2, lo
    5d18:      	b.hs	0x7250 <_stogir.pipeline.prepare-checked+0x481c>
    5d1c:      	mov	x9, xzr
    5d20:      	mov	x10, #-0x1              ; =-1
    5d24:      	mov	x11, x10
    5d28:      	mov	x10, x9
    5d2c:      	sub	x9, x19, x11
    5d30:      	add	x11, x24, x9, lsl #2
    5d34:      	add	x9, x10, #0x1
    5d38:      	cmp	x19, x9
    5d3c:      	ldur	w11, [x11, #-0x8]
    5d40:      	str	w11, [x8, x10, lsl #2]
    5d44:      	b.ne	0x5d24 <_stogir.pipeline.prepare-checked+0x32f0>
    5d48:      	ldr	x8, [sp, #0x28]
    5d4c:      	cbz	x8, 0x5d54 <_stogir.pipeline.prepare-checked+0x3320>
    5d50:      	stur	xzr, [x29, #-0xe8]
    5d54:      	ldur	x2, [x29, #-0xe0]
    5d58:      	cmp	x2, #0x1
    5d5c:      	b.lt	0x5d80 <_stogir.pipeline.prepare-checked+0x334c>
    5d60:      	adrp	x3, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005d60:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    5d64:      	sub	x8, x29, #0xf0
    5d68:      	mov	x1, x28
    5d6c:      	ldr	x3, [x3]
		0000000000005d6c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    5d70:      	add	x0, x8, #0x18
    5d74:      	mov	w4, #0x4                ; =4
    5d78:      	mov	w5, #0x4                ; =4
    5d7c:      	bl	0x5d7c <_stogir.pipeline.prepare-checked+0x3348>
		0000000000005d7c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    5d80:      	ldur	x2, [x29, #-0xb0]
    5d84:      	stp	xzr, xzr, [x29, #-0xf0]
    5d88:      	stur	xzr, [x29, #-0xe0]
    5d8c:      	cmp	x2, #0x1
    5d90:      	stur	xzr, [x29, #-0xb8]
    5d94:      	b.lt	0x5db8 <_stogir.pipeline.prepare-checked+0x3384>
    5d98:      	adrp	x3, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005d98:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    5d9c:      	sub	x8, x29, #0xc0
    5da0:      	mov	x1, x25
    5da4:      	ldr	x3, [x3]
		0000000000005da4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    5da8:      	add	x0, x8, #0x18
    5dac:      	mov	w4, #0x8                ; =8
    5db0:      	mov	w5, #0x8                ; =8
    5db4:      	bl	0x5db4 <_stogir.pipeline.prepare-checked+0x3380>
		0000000000005db4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    5db8:      	cbz	x27, 0x5dc0 <_stogir.pipeline.prepare-checked+0x338c>
    5dbc:      	str	xzr, [sp, #0x558]
    5dc0:      	ldr	x2, [sp, #0x560]
    5dc4:      	cmp	x2, #0x1
    5dc8:      	b.lt	0x5dec <_stogir.pipeline.prepare-checked+0x33b8>
    5dcc:      	adrp	x3, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005dcc:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    5dd0:      	ldr	x1, [sp, #0x550]
    5dd4:      	add	x8, sp, #0x550
    5dd8:      	ldr	x3, [x3]
		0000000000005dd8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    5ddc:      	add	x0, x8, #0x18
    5de0:      	mov	w4, #0x10               ; =16
    5de4:      	mov	w5, #0x8                ; =8
    5de8:      	bl	0x5de8 <_stogir.pipeline.prepare-checked+0x33b4>
		0000000000005de8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    5dec:      	cbz	x19, 0x5df4 <_stogir.pipeline.prepare-checked+0x33c0>
    5df0:      	stur	xzr, [x29, #-0x88]
    5df4:      	ldur	x2, [x29, #-0x80]
    5df8:      	ldp	x8, x9, [sp, #0x98]
    5dfc:      	add	x17, sp, #0x550
    5e00:      	sub	x0, x29, #0xc0
    5e04:      	cmp	x2, #0x1
    5e08:      	b.lt	0x6230 <_stogir.pipeline.prepare-checked+0x37fc>
    5e0c:      	adrp	x3, 0x5000 <_stogir.pipeline.prepare-checked+0x25cc>
		0000000000005e0c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    5e10:      	ldur	x1, [x29, #-0x90]
    5e14:      	sub	x8, x29, #0x90
    5e18:      	b	0x6210 <_stogir.pipeline.prepare-checked+0x37dc>
    5e1c:      	add	x8, x20, #0x1
    5e20:      	str	w22, [x24, x20, lsl #2]
    5e24:      	sub	x27, x27, #0x1
    5e28:      	stur	x8, [x29, #-0x88]
    5e2c:      	cmp	x27, #0x0
    5e30:      	b.le	0x5ccc <_stogir.pipeline.prepare-checked+0x3298>
    5e34:      	add	x8, x26, x27, lsl #4
    5e38:      	ldp	x22, x9, [x8, #-0x10]
    5e3c:      	cbz	x9, 0x601c <_stogir.pipeline.prepare-checked+0x35e8>
    5e40:      	ldr	x10, [sp, #0x170]
    5e44:      	sbfiz	x11, x22, #4, #32
    5e48:      	ldr	x12, [sp, #0xf8]
    5e4c:      	sub	x9, x9, #0x1
    5e50:      	ldr	x10, [x10, x11]
    5e54:      	cmp	x9, #0x2
    5e58:      	add	x10, x25, x10, lsl #3
    5e5c:      	ldr	x11, [x10]
    5e60:      	lsl	x13, x11, #4
    5e64:      	ldr	x11, [x10, x9, lsl #3]
    5e68:      	ldr	x20, [x12, x13]
    5e6c:      	str	x11, [x10]
    5e70:      	b.lt	0x5f1c <_stogir.pipeline.prepare-checked+0x34e8>
    5e74:      	mov	x15, xzr
    5e78:      	mov	x12, xzr
    5e7c:      	mov	w14, #0x1               ; =1
    5e80:      	b	0x5ea4 <_stogir.pipeline.prepare-checked+0x3470>
    5e84:      	mov	w14, #0x1               ; =1
    5e88:      	lsl	x15, x13, #1
    5e8c:      	str	x16, [x10, x12, lsl #3]
    5e90:      	bfi	x14, x13, #1, #63
    5e94:      	mov	x12, x13
    5e98:      	str	x11, [x10, x13, lsl #3]
    5e9c:      	cmp	x14, x9
    5ea0:      	b.ge	0x5f1c <_stogir.pipeline.prepare-checked+0x34e8>
    5ea4:      	add	x13, x15, #0x2
    5ea8:      	ldr	x15, [sp, #0xf8]
    5eac:      	cmp	x13, x9
    5eb0:      	b.ge	0x5ee4 <_stogir.pipeline.prepare-checked+0x34b0>
    5eb4:      	add	x16, x10, x14, lsl #3
    5eb8:      	ldp	x16, x17, [x16]
    5ebc:      	add	x0, x15, x17, lsl #4
    5ec0:      	add	x1, x15, x16, lsl #4
    5ec4:      	ldrsw	x0, [x0, #0x4]
    5ec8:      	ldrsw	x1, [x1, #0x4]
    5ecc:      	ldr	w0, [x19, x0, lsl #2]
    5ed0:      	ldr	w1, [x19, x1, lsl #2]
    5ed4:      	cmp	w0, w1
    5ed8:      	ccmp	x17, x16, #0x4, eq
    5edc:      	ccmp	w0, w1, #0x8, le
    5ee0:      	b.lt	0x5ee8 <_stogir.pipeline.prepare-checked+0x34b4>
    5ee4:      	mov	x13, x14
    5ee8:      	ldr	x16, [x10, x13, lsl #3]
    5eec:      	add	x14, x15, x16, lsl #4
    5ef0:      	add	x15, x15, x11, lsl #4
    5ef4:      	cmp	x16, x11
    5ef8:      	cset	w17, le
    5efc:      	ldrsw	x14, [x14, #0x4]
    5f00:      	ldrsw	x15, [x15, #0x4]
    5f04:      	ldr	w14, [x19, x14, lsl #2]
    5f08:      	ldr	w15, [x19, x15, lsl #2]
    5f0c:      	cmp	w14, w15
    5f10:      	csinc	w14, w17, wzr, eq
    5f14:      	b.lt	0x5e84 <_stogir.pipeline.prepare-checked+0x3450>
    5f18:      	tbz	w14, #0x0, 0x5e84 <_stogir.pipeline.prepare-checked+0x3450>
    5f1c:      	asr	x21, x20, #32
    5f20:      	stp	x22, x9, [x8, #-0x10]
    5f24:      	ldr	w8, [x28, x21, lsl #2]
    5f28:      	cbnz	w8, 0x5e2c <_stogir.pipeline.prepare-checked+0x33f8>
    5f2c:      	ldr	x8, [sp, #0x170]
    5f30:      	add	x8, x8, x21, lsl #4
    5f34:      	ldr	x22, [x8, #0x8]
    5f38:      	cmp	x22, #0x2
    5f3c:      	b.lt	0x6080 <_stogir.pipeline.prepare-checked+0x364c>
    5f40:      	ldr	x9, [x8]
    5f44:      	lsr	x8, x22, #1
    5f48:      	add	x9, x25, x9, lsl #3
    5f4c:      	b	0x5f58 <_stogir.pipeline.prepare-checked+0x3524>
    5f50:      	cmp	x10, #0x1
    5f54:      	b.le	0x6080 <_stogir.pipeline.prepare-checked+0x364c>
    5f58:      	mov	x10, x8
    5f5c:      	sub	x8, x8, #0x1
    5f60:      	mov	w13, #0x1               ; =1
    5f64:      	bfi	x13, x8, #1, #63
    5f68:      	cmp	x13, x22
    5f6c:      	b.ge	0x5f50 <_stogir.pipeline.prepare-checked+0x351c>
    5f70:      	lsl	x14, x8, #1
    5f74:      	sub	x11, x10, #0x1
    5f78:      	b	0x5f9c <_stogir.pipeline.prepare-checked+0x3568>
    5f7c:      	mov	w13, #0x1               ; =1
    5f80:      	lsl	x14, x12, #1
    5f84:      	str	x16, [x9, x11, lsl #3]
    5f88:      	bfi	x13, x12, #1, #63
    5f8c:      	mov	x11, x12
    5f90:      	str	x15, [x9, x12, lsl #3]
    5f94:      	cmp	x13, x22
    5f98:      	b.ge	0x5f50 <_stogir.pipeline.prepare-checked+0x351c>
    5f9c:      	add	x12, x14, #0x2
    5fa0:      	ldr	x14, [sp, #0xf8]
    5fa4:      	cmp	x12, x22
    5fa8:      	b.ge	0x5fdc <_stogir.pipeline.prepare-checked+0x35a8>
    5fac:      	add	x15, x9, x13, lsl #3
    5fb0:      	ldp	x15, x16, [x15]
    5fb4:      	add	x17, x14, x16, lsl #4
    5fb8:      	add	x0, x14, x15, lsl #4
    5fbc:      	ldrsw	x17, [x17, #0x4]
    5fc0:      	ldrsw	x0, [x0, #0x4]
    5fc4:      	ldr	w17, [x19, x17, lsl #2]
    5fc8:      	ldr	w0, [x19, x0, lsl #2]
    5fcc:      	cmp	w17, w0
    5fd0:      	ccmp	x16, x15, #0x4, eq
    5fd4:      	ccmp	w17, w0, #0x8, le
    5fd8:      	b.lt	0x5fe0 <_stogir.pipeline.prepare-checked+0x35ac>
    5fdc:      	mov	x12, x13
    5fe0:      	ldr	x16, [x9, x12, lsl #3]
    5fe4:      	ldr	x15, [x9, x11, lsl #3]
    5fe8:      	add	x13, x14, x16, lsl #4
    5fec:      	add	x14, x14, x15, lsl #4
    5ff0:      	cmp	x16, x15
    5ff4:      	cset	w17, le
    5ff8:      	ldrsw	x13, [x13, #0x4]
    5ffc:      	ldrsw	x14, [x14, #0x4]
    6000:      	ldr	w13, [x19, x13, lsl #2]
    6004:      	ldr	w14, [x19, x14, lsl #2]
    6008:      	cmp	w13, w14
    600c:      	csinc	w13, w17, wzr, eq
    6010:      	b.lt	0x5f7c <_stogir.pipeline.prepare-checked+0x3548>
    6014:      	tbz	w13, #0x0, 0x5f7c <_stogir.pipeline.prepare-checked+0x3548>
    6018:      	b	0x5f50 <_stogir.pipeline.prepare-checked+0x351c>
    601c:      	ldp	x20, x2, [x29, #-0x88]
    6020:      	cmp	x20, x2
    6024:      	b.lt	0x5e1c <_stogir.pipeline.prepare-checked+0x33e8>
    6028:      	lsl	x8, x2, #1
    602c:      	cmp	x2, #0x0
    6030:      	mov	w9, #0x2                ; =2
    6034:      	csel	x23, x9, x8, eq
    6038:      	sub	x8, x29, #0x90
    603c:      	ldur	q0, [x8, #0x18]
    6040:      	cmp	x23, x2
    6044:      	add	x8, sp, #0x550
    6048:      	str	q0, [x8, #0x80]
    604c:      	b.le	0x5e1c <_stogir.pipeline.prepare-checked+0x33e8>
    6050:      	adrp	x4, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006050:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6054:      	add	x0, sp, #0x5d0
    6058:      	mov	x1, x24
    605c:      	ldr	x4, [x4]
		000000000000605c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6060:      	mov	x3, x23
    6064:      	mov	w5, #0x4                ; =4
    6068:      	mov	w6, #0x4                ; =4
    606c:      	bl	0x606c <_stogir.pipeline.prepare-checked+0x3638>
		000000000000606c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    6070:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    6074:      	mov	x24, x1
    6078:      	stur	x23, [x29, #-0x80]
    607c:      	b	0x5e1c <_stogir.pipeline.prepare-checked+0x33e8>
    6080:      	ldr	x8, [sp, #0x40]
    6084:      	cmp	x27, x8
    6088:      	b.lt	0x60e8 <_stogir.pipeline.prepare-checked+0x36b4>
    608c:      	ldr	x9, [sp, #0x40]
    6090:      	mov	w10, #0x2               ; =2
    6094:      	lsl	x8, x9, #1
    6098:      	cmp	x9, #0x0
    609c:      	csel	x23, x10, x8, eq
    60a0:      	add	x8, sp, #0x550
    60a4:      	ldur	q0, [x8, #0x18]
    60a8:      	cmp	x23, x9
    60ac:      	add	x8, sp, #0x550
    60b0:      	str	q0, [x8, #0x80]
    60b4:      	b.le	0x60e8 <_stogir.pipeline.prepare-checked+0x36b4>
    60b8:      	adrp	x4, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		00000000000060b8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    60bc:      	ldr	x2, [sp, #0x40]
    60c0:      	add	x0, sp, #0x5d0
    60c4:      	ldr	x4, [x4]
		00000000000060c4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    60c8:      	mov	x1, x26
    60cc:      	mov	x3, x23
    60d0:      	mov	w5, #0x10               ; =16
    60d4:      	mov	w6, #0x8                ; =8
    60d8:      	bl	0x60d8 <_stogir.pipeline.prepare-checked+0x36a4>
		00000000000060d8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    60dc:      	cbz	w0, 0x739c <_stogir.pipeline.prepare-checked+0x4968>
    60e0:      	mov	x26, x1
    60e4:      	str	x23, [sp, #0x40]
    60e8:      	lsr	x8, x20, #32
    60ec:      	add	x9, x26, x27, lsl #4
    60f0:      	add	x27, x27, #0x1
    60f4:      	stp	x8, x22, [x9]
    60f8:      	mov	w8, #0x1                ; =1
    60fc:      	str	w8, [x28, x21, lsl #2]
    6100:      	b	0x5e2c <_stogir.pipeline.prepare-checked+0x33f8>
    6104:      	ldr	x8, [sp, #0x28]
    6108:      	cbz	x8, 0x6110 <_stogir.pipeline.prepare-checked+0x36dc>
    610c:      	stur	xzr, [x29, #-0xe8]
    6110:      	ldur	x2, [x29, #-0xe0]
    6114:      	cmp	x2, #0x1
    6118:      	b.lt	0x613c <_stogir.pipeline.prepare-checked+0x3708>
    611c:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		000000000000611c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6120:      	sub	x8, x29, #0xf0
    6124:      	mov	x1, x28
    6128:      	ldr	x3, [x3]
		0000000000006128:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    612c:      	add	x0, x8, #0x18
    6130:      	mov	w4, #0x4                ; =4
    6134:      	mov	w5, #0x4                ; =4
    6138:      	bl	0x6138 <_stogir.pipeline.prepare-checked+0x3704>
		0000000000006138:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    613c:      	ldur	x2, [x29, #-0xb0]
    6140:      	stp	xzr, xzr, [x29, #-0xf0]
    6144:      	stur	xzr, [x29, #-0xe0]
    6148:      	cmp	x2, #0x1
    614c:      	stur	xzr, [x29, #-0xb8]
    6150:      	b.lt	0x6174 <_stogir.pipeline.prepare-checked+0x3740>
    6154:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006154:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    6158:      	sub	x8, x29, #0xc0
    615c:      	mov	x1, x25
    6160:      	ldr	x3, [x3]
		0000000000006160:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    6164:      	add	x0, x8, #0x18
    6168:      	mov	w4, #0x8                ; =8
    616c:      	mov	w5, #0x8                ; =8
    6170:      	bl	0x6170 <_stogir.pipeline.prepare-checked+0x373c>
		0000000000006170:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6174:      	cbz	x27, 0x617c <_stogir.pipeline.prepare-checked+0x3748>
    6178:      	str	xzr, [sp, #0x558]
    617c:      	ldr	x2, [sp, #0x560]
    6180:      	cmp	x2, #0x1
    6184:      	b.lt	0x61a8 <_stogir.pipeline.prepare-checked+0x3774>
    6188:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006188:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    618c:      	ldr	x1, [sp, #0x550]
    6190:      	add	x8, sp, #0x550
    6194:      	ldr	x3, [x3]
		0000000000006194:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Frame.0
    6198:      	add	x0, x8, #0x18
    619c:      	mov	w4, #0x10               ; =16
    61a0:      	mov	w5, #0x8                ; =8
    61a4:      	bl	0x61a4 <_stogir.pipeline.prepare-checked+0x3770>
		00000000000061a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    61a8:      	cbz	x19, 0x61b0 <_stogir.pipeline.prepare-checked+0x377c>
    61ac:      	stur	xzr, [x29, #-0x88]
    61b0:      	ldur	x2, [x29, #-0x80]
    61b4:      	cmp	x2, #0x1
    61b8:      	b.lt	0x61dc <_stogir.pipeline.prepare-checked+0x37a8>
    61bc:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		00000000000061bc:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    61c0:      	ldur	x1, [x29, #-0x90]
    61c4:      	sub	x8, x29, #0x90
    61c8:      	ldr	x3, [x3]
		00000000000061c8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    61cc:      	add	x0, x8, #0x18
    61d0:      	mov	w4, #0x4                ; =4
    61d4:      	mov	w5, #0x4                ; =4
    61d8:      	bl	0x61d8 <_stogir.pipeline.prepare-checked+0x37a4>
		00000000000061d8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    61dc:      	adrp	x23, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		00000000000061dc:  ARM64_RELOC_PAGE21	l_str.493
    61e0:      	add	x23, x23, #0x0
		00000000000061e0:  ARM64_RELOC_PAGEOFF12	l_str.493
    61e4:      	mov	w26, #0x33              ; =51
    61e8:      	b	0x6ed8 <_stogir.pipeline.prepare-checked+0x44a4>
    61ec:      	ldur	x2, [x29, #-0xe0]
    61f0:      	ldp	x8, x9, [sp, #0x98]
    61f4:      	add	x17, sp, #0x550
    61f8:      	sub	x0, x29, #0xc0
    61fc:      	stur	xzr, [x29, #-0xe8]
    6200:      	cmp	x2, #0x1
    6204:      	b.lt	0x6230 <_stogir.pipeline.prepare-checked+0x37fc>
    6208:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006208:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    620c:      	sub	x8, x29, #0xf0
    6210:      	ldr	x3, [x3]
		0000000000006210:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6214:      	add	x0, x8, #0x18
    6218:      	mov	w4, #0x4                ; =4
    621c:      	mov	w5, #0x4                ; =4
    6220:      	bl	0x6220 <_stogir.pipeline.prepare-checked+0x37ec>
		0000000000006220:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6224:      	ldp	x8, x9, [sp, #0x98]
    6228:      	sub	x0, x29, #0xc0
    622c:      	add	x17, sp, #0x550
    6230:      	ldr	x20, [x9, #0x8]
    6234:      	ldr	q0, [x8]
    6238:      	ldr	x9, [sp, #0x260]
    623c:      	stp	xzr, xzr, [x29, #-0x88]
    6240:      	lsl	x23, x20, #2
    6244:      	cmp	x20, #0x1
    6248:      	stur	xzr, [x29, #-0x90]
    624c:      	stur	q0, [x0, #0x48]
    6250:      	stp	xzr, xzr, [x29, #-0xb8]
    6254:      	stur	xzr, [x29, #-0xc0]
    6258:      	stur	q0, [x0, #0x18]
    625c:      	str	xzr, [sp, #0x560]
    6260:      	str	xzr, [sp, #0x550]
    6264:      	str	xzr, [sp, #0x558]
    6268:      	stur	q0, [x17, #0x18]
    626c:      	stp	xzr, xzr, [x29, #-0xf0]
    6270:      	str	x9, [sp, #0x38]
    6274:      	stur	xzr, [x29, #-0xe0]
    6278:      	stur	q0, [x17, #0xe8]
    627c:      	b.lt	0x62cc <_stogir.pipeline.prepare-checked+0x3898>
    6280:      	ldr	q0, [x8]
    6284:      	adrp	x4, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006284:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6288:      	add	x0, sp, #0x5d0
    628c:      	mov	x1, xzr
    6290:      	mov	x2, xzr
    6294:      	mov	x3, x20
    6298:      	str	q0, [x17, #0x80]
    629c:      	mov	w5, #0x4                ; =4
    62a0:      	mov	w6, #0x4                ; =4
    62a4:      	ldr	x4, [x4]
		00000000000062a4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    62a8:      	mov	x19, x20
    62ac:      	bl	0x62ac <_stogir.pipeline.prepare-checked+0x3878>
		00000000000062ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    62b0:      	mov	x8, x0
    62b4:      	cbz	w8, 0x737c <_stogir.pipeline.prepare-checked+0x4948>
    62b8:      	mov	x0, x1
    62bc:      	mov	x20, x19
    62c0:      	stur	x1, [x29, #-0xc0]
    62c4:      	stur	x19, [x29, #-0xb0]
    62c8:      	b	0x62d0 <_stogir.pipeline.prepare-checked+0x389c>
    62cc:      	mov	x0, xzr
    62d0:      	mov	x1, x23
    62d4:      	add	x19, sp, #0x550
    62d8:      	bl	0x62d8 <_stogir.pipeline.prepare-checked+0x38a4>
		00000000000062d8:  ARM64_RELOC_BRANCH26	_bzero
    62dc:      	ldr	x8, [sp, #0xa0]
    62e0:      	str	x20, [sp, #0x10]
    62e4:      	stur	x20, [x29, #-0xb8]
    62e8:      	ldr	x21, [x8, #0x8]
    62ec:      	lsl	x23, x21, #3
    62f0:      	cmp	x21, #0x1
    62f4:      	b.lt	0x633c <_stogir.pipeline.prepare-checked+0x3908>
    62f8:      	adrp	x4, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		00000000000062f8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    62fc:      	add	x0, x19, #0x18
    6300:      	mov	x1, xzr
    6304:      	ldr	x4, [x4]
		0000000000006304:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    6308:      	mov	x2, xzr
    630c:      	mov	x3, x21
    6310:      	mov	w5, #0x8                ; =8
    6314:      	mov	w6, #0x8                ; =8
    6318:      	mov	x19, x21
    631c:      	bl	0x631c <_stogir.pipeline.prepare-checked+0x38e8>
		000000000000631c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    6320:      	mov	x8, x0
    6324:      	cbz	w8, 0x738c <_stogir.pipeline.prepare-checked+0x4958>
    6328:      	mov	x0, x1
    632c:      	mov	x21, x19
    6330:      	str	x1, [sp, #0x550]
    6334:      	str	x19, [sp, #0x560]
    6338:      	b	0x6340 <_stogir.pipeline.prepare-checked+0x390c>
    633c:      	mov	x0, xzr
    6340:      	mov	x1, x23
    6344:      	sub	x22, x29, #0x90
    6348:      	bl	0x6348 <_stogir.pipeline.prepare-checked+0x3914>
		0000000000006348:  ARM64_RELOC_BRANCH26	_bzero
    634c:      	ldr	x8, [sp, #0xa0]
    6350:      	str	x21, [sp, #0x8]
    6354:      	str	x21, [sp, #0x558]
    6358:      	ldr	x9, [x8, #0x8]
    635c:      	cmp	x9, #0x0
    6360:      	b.le	0x641c <_stogir.pipeline.prepare-checked+0x39e8>
    6364:      	adrp	x23, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006364:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    6368:      	mov	x19, xzr
    636c:      	mov	x1, xzr
    6370:      	ldr	x23, [x23]
		0000000000006370:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    6374:      	mov	x20, #-0x1              ; =-1
    6378:      	mov	w21, #0x2               ; =2
    637c:      	add	x10, sp, #0x550
    6380:      	b	0x639c <_stogir.pipeline.prepare-checked+0x3968>
    6384:      	str	x20, [x1, x19, lsl #3]
    6388:      	add	x19, x19, #0x1
    638c:      	ldr	x9, [x8, #0x8]
    6390:      	stur	x19, [x29, #-0x88]
    6394:      	cmp	x19, x9
    6398:      	b.ge	0x63f0 <_stogir.pipeline.prepare-checked+0x39bc>
    639c:      	ldur	x2, [x29, #-0x80]
    63a0:      	cmp	x19, x2
    63a4:      	b.lt	0x6384 <_stogir.pipeline.prepare-checked+0x3950>
    63a8:      	lsl	x9, x2, #1
    63ac:      	cmp	x2, #0x0
    63b0:      	ldur	q0, [x22, #0x18]
    63b4:      	csel	x27, x21, x9, eq
    63b8:      	str	q0, [x10, #0x80]
    63bc:      	cmp	x27, x2
    63c0:      	b.le	0x6384 <_stogir.pipeline.prepare-checked+0x3950>
    63c4:      	add	x0, sp, #0x5d0
    63c8:      	mov	x3, x27
    63cc:      	mov	x4, x23
    63d0:      	mov	w5, #0x8                ; =8
    63d4:      	mov	w6, #0x8                ; =8
    63d8:      	bl	0x63d8 <_stogir.pipeline.prepare-checked+0x39a4>
		00000000000063d8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    63dc:      	cbz	w0, 0x735c <_stogir.pipeline.prepare-checked+0x4928>
    63e0:      	ldr	x8, [sp, #0xa0]
    63e4:      	add	x10, sp, #0x550
    63e8:      	stur	x27, [x29, #-0x80]
    63ec:      	b	0x6384 <_stogir.pipeline.prepare-checked+0x3950>
    63f0:      	subs	x8, x19, #0x1
    63f4:      	stur	x1, [x29, #-0x90]
    63f8:      	b.ne	0x643c <_stogir.pipeline.prepare-checked+0x3a08>
    63fc:      	adrp	x8, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		00000000000063fc:  ARM64_RELOC_PAGE21	l_str.670
    6400:      	add	x8, x8, #0x0
		0000000000006400:  ARM64_RELOC_PAGEOFF12	l_str.670
    6404:      	ldur	x27, [x29, #-0xf0]
    6408:      	stp	xzr, x8, [sp, #0x20]
    640c:      	mov	w8, #0x1                ; =1
    6410:      	mov	x26, xzr
    6414:      	str	x8, [sp, #0x40]
    6418:      	b	0x682c <_stogir.pipeline.prepare-checked+0x3df8>
    641c:      	mov	x27, xzr
    6420:      	mov	x26, xzr
    6424:      	adrp	x8, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006424:  ARM64_RELOC_PAGE21	l_str.670
    6428:      	add	x8, x8, #0x0
		0000000000006428:  ARM64_RELOC_PAGEOFF12	l_str.670
    642c:      	str	xzr, [sp, #0x40]
    6430:      	stur	xzr, [x29, #-0x90]
    6434:      	stp	xzr, x8, [sp, #0x20]
    6438:      	b	0x682c <_stogir.pipeline.prepare-checked+0x3df8>
    643c:      	adrp	x9, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		000000000000643c:  ARM64_RELOC_PAGE21	l_str.670
    6440:      	add	x9, x9, #0x0
		0000000000006440:  ARM64_RELOC_PAGEOFF12	l_str.670
    6444:      	ldur	x10, [x29, #-0xc0]
    6448:      	ldr	x12, [sp, #0x550]
    644c:      	ldr	x5, [sp, #0xa0]
    6450:      	stp	xzr, x9, [sp, #0x20]
    6454:      	adrp	x9, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006454:  ARM64_RELOC_PAGE21	l_str.672
    6458:      	add	x9, x9, #0x0
		0000000000006458:  ARM64_RELOC_PAGEOFF12	l_str.672
    645c:      	adrp	x11, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		000000000000645c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    6460:      	add	x11, x11, #0x0
		0000000000006460:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    6464:      	adrp	x13, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006464:  ARM64_RELOC_PAGE21	l_str.673
    6468:      	add	x13, x13, #0x0
		0000000000006468:  ARM64_RELOC_PAGEOFF12	l_str.673
    646c:      	mov	w14, #0x1               ; =1
    6470:      	mov	w15, #-0x7fffffff       ; =-2147483647
    6474:      	mov	w16, #0x43              ; =67
    6478:      	mov	w17, #0x82              ; =130
    647c:      	mov	w0, #0x5                ; =5
    6480:      	mov	w2, #0x5e1c             ; =24092
    6484:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006484:  ARM64_RELOC_PAGE21	l_str.674
    6488:      	add	x3, x3, #0x0
		0000000000006488:  ARM64_RELOC_PAGEOFF12	l_str.674
    648c:      	mov	w4, #0x1                ; =1
    6490:      	cmp	w4, #0x1
    6494:      	b.lt	0x654c <_stogir.pipeline.prepare-checked+0x3b18>
    6498:      	ldr	x7, [x5, #0x8]
    649c:      	and	x6, x4, #0x7fffffff
    64a0:      	cmp	x7, x6
    64a4:      	b.le	0x658c <_stogir.pipeline.prepare-checked+0x3b58>
    64a8:      	ldr	x7, [x5, #0x80]
    64ac:      	cmp	x7, x6
    64b0:      	b.le	0x658c <_stogir.pipeline.prepare-checked+0x3b58>
    64b4:      	ldr	x7, [x5, #0x78]
    64b8:      	ldr	w6, [x7, x6, lsl #2]
    64bc:      	tbnz	w6, #0x1f, 0x658c <_stogir.pipeline.prepare-checked+0x3b58>
    64c0:      	ldr	x6, [sp, #0x80]
    64c4:      	ldrb	w6, [x6, x4]
    64c8:      	cbz	w6, 0x658c <_stogir.pipeline.prepare-checked+0x3b58>
    64cc:      	ldr	x5, [sp, #0x70]
    64d0:      	ldr	w6, [x5, x4, lsl #2]
    64d4:      	cmp	w6, #0x1
    64d8:      	b.lt	0x6730 <_stogir.pipeline.prepare-checked+0x3cfc>
    64dc:      	ldr	x5, [sp, #0xa0]
    64e0:      	lsl	x19, x4, #4
    64e4:      	ldr	x7, [x5]
    64e8:      	ldr	x5, [x5, #0x78]
    64ec:      	ldr	x20, [x7, x19]
    64f0:      	ldr	w5, [x5, x4, lsl #2]
    64f4:      	and	w7, w20, #0xff
    64f8:      	cmp	w7, #0x82
    64fc:      	b.hi	0x650c <_stogir.pipeline.prepare-checked+0x3ad8>
    6500:      	and	x19, x20, #0xff
    6504:      	ldrb	w19, [x11, x19]
    6508:      	tbnz	w19, #0x2, 0x66bc <_stogir.pipeline.prepare-checked+0x3c88>
    650c:      	ldr	x19, [x12, x6, lsl #3]
    6510:      	mov	x26, xzr
    6514:      	add	x19, x19, #0x1
    6518:      	str	x19, [x12, x6, lsl #3]
    651c:      	cmp	w5, #0x1
    6520:      	b.lt	0x66f8 <_stogir.pipeline.prepare-checked+0x3cc4>
    6524:      	sub	w19, w7, #0x68
    6528:      	cmp	w19, #0xa
    652c:      	b.hs	0x65ac <_stogir.pipeline.prepare-checked+0x3b78>
    6530:      	mov	w7, #0x5                ; =5
    6534:      	add	w6, w5, w15
    6538:      	movk	w7, #0x8000, lsl #16
    653c:      	cmp	w6, w7
    6540:      	b.hs	0x66d0 <_stogir.pipeline.prepare-checked+0x3c9c>
    6544:      	mov	w6, #0x1                ; =1
    6548:      	b	0x66ec <_stogir.pipeline.prepare-checked+0x3cb8>
    654c:      	tbz	w4, #0x1f, 0x658c <_stogir.pipeline.prepare-checked+0x3b58>
    6550:      	ldr	x6, [x5, #0x30]
    6554:      	ldr	x7, [x5, #0x58]
    6558:      	cmp	x6, x7
    655c:      	b.ne	0x658c <_stogir.pipeline.prepare-checked+0x3b58>
    6560:      	sxtw	x7, w4
    6564:      	cmn	x6, x7
    6568:      	b.ge	0x6574 <_stogir.pipeline.prepare-checked+0x3b40>
    656c:      	mov	x26, xzr
    6570:      	b	0x670c <_stogir.pipeline.prepare-checked+0x3cd8>
    6574:      	ldr	x5, [sp, #0xa0]
    6578:      	mvn	x7, x7
    657c:      	ldr	x6, [x5, #0x50]
    6580:      	ldr	w6, [x6, x7, lsl #2]
    6584:      	cmp	w6, #0x0
    6588:      	b.gt	0x64c0 <_stogir.pipeline.prepare-checked+0x3a8c>
    658c:      	mov	x26, xzr
    6590:      	cmp	x26, #0x0
    6594:      	cset	w19, eq
    6598:      	cmp	x4, x8
    659c:      	b.hs	0x673c <_stogir.pipeline.prepare-checked+0x3d08>
    65a0:      	add	x4, x4, #0x1
    65a4:      	cbz	x26, 0x6490 <_stogir.pipeline.prepare-checked+0x3a5c>
    65a8:      	b	0x673c <_stogir.pipeline.prepare-checked+0x3d08>
    65ac:      	mov	x19, xzr
    65b0:      	and	x20, x20, #0xff
    65b4:      	and	x21, x4, #0x7fffffff
    65b8:      	mov	w22, #0x1               ; =1
    65bc:      	b	0x65d4 <_stogir.pipeline.prepare-checked+0x3ba0>
    65c0:      	mov	w26, #0x19              ; =25
    65c4:      	str	x3, [sp, #0x28]
    65c8:      	add	w22, w22, #0x1
    65cc:      	cmp	w22, w5
    65d0:      	b.gt	0x66fc <_stogir.pipeline.prepare-checked+0x3cc8>
    65d4:      	cmp	w22, #0x1
    65d8:      	ccmp	w7, w16, #0x0, gt
    65dc:      	b.eq	0x65c8 <_stogir.pipeline.prepare-checked+0x3b94>
    65e0:      	cmp	w22, #0x1
    65e4:      	ccmp	w7, w17, #0x2, ge
    65e8:      	b.hi	0x6614 <_stogir.pipeline.prepare-checked+0x3be0>
    65ec:      	cmp	w22, #0x5
    65f0:      	adrp	x24, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		00000000000065f0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    65f4:      	add	x24, x24, #0x0
		00000000000065f4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    65f8:      	csel	w23, w22, w0, lo
    65fc:      	ldr	w24, [x24, x20, lsl #2]
    6600:      	lsl	w23, w23, #2
    6604:      	sub	w23, w23, #0x4
    6608:      	lsr	w23, w24, w23
    660c:      	and	w23, w23, #0xf
    6610:      	b	0x6618 <_stogir.pipeline.prepare-checked+0x3be4>
    6614:      	mov	w23, wzr
    6618:      	cmp	w23, #0xf
    661c:      	b.eq	0x65c8 <_stogir.pipeline.prepare-checked+0x3b94>
    6620:      	lsl	w23, w14, w23
    6624:      	and	w23, w23, w2
    6628:      	cbz	w23, 0x65c8 <_stogir.pipeline.prepare-checked+0x3b94>
    662c:      	cmp	w4, #0x1
    6630:      	b.lt	0x6670 <_stogir.pipeline.prepare-checked+0x3c3c>
    6634:      	ldr	x23, [sp, #0xa0]
    6638:      	ldr	x23, [x23, #0x8]
    663c:      	cmp	x23, x21
    6640:      	b.le	0x6670 <_stogir.pipeline.prepare-checked+0x3c3c>
    6644:      	ldr	x23, [sp, #0xa0]
    6648:      	ldr	x23, [x23, #0x80]
    664c:      	cmp	x23, x21
    6650:      	b.le	0x6670 <_stogir.pipeline.prepare-checked+0x3c3c>
    6654:      	ldr	x23, [sp, #0xa0]
    6658:      	ldr	x23, [x23, #0x78]
    665c:      	ldr	w23, [x23, x21, lsl #2]
    6660:      	cmp	w22, w23
    6664:      	ccmp	w23, #0x0, #0x8, ls
    6668:      	ccmp	w22, #0x1, #0x8, pl
    666c:      	b.ge	0x6698 <_stogir.pipeline.prepare-checked+0x3c64>
    6670:      	mov	x24, xzr
    6674:      	cbz	w24, 0x65c0 <_stogir.pipeline.prepare-checked+0x3b8c>
    6678:      	cmp	w23, #0x1
    667c:      	b.lt	0x65c8 <_stogir.pipeline.prepare-checked+0x3b94>
    6680:      	ldr	x24, [sp, #0x70]
    6684:      	and	x23, x23, #0x7fffffff
    6688:      	ldr	w23, [x24, x23, lsl #2]
    668c:      	cmp	w23, w6
    6690:      	cinc	x19, x19, eq
    6694:      	b	0x65c8 <_stogir.pipeline.prepare-checked+0x3b94>
    6698:      	ldr	x23, [sp, #0xa0]
    669c:      	add	w24, w4, w22, lsr #2
    66a0:      	ldr	x23, [x23]
    66a4:      	add	x23, x23, w24, uxtw #4
    66a8:      	and	w24, w22, #0x3
    66ac:      	ldr	w23, [x23, w24, uxtw #2]
    66b0:      	mov	w24, #0x1               ; =1
    66b4:      	cbnz	w24, 0x6678 <_stogir.pipeline.prepare-checked+0x3c44>
    66b8:      	b	0x65c0 <_stogir.pipeline.prepare-checked+0x3b8c>
    66bc:      	ldr	w19, [x10, x6, lsl #2]
    66c0:      	cbz	w19, 0x6724 <_stogir.pipeline.prepare-checked+0x3cf0>
    66c4:      	mov	w26, #0x13              ; =19
    66c8:      	str	x13, [sp, #0x28]
    66cc:      	b	0x651c <_stogir.pipeline.prepare-checked+0x3ae8>
    66d0:      	and	w7, w5, #0x7ffffffc
    66d4:      	and	w19, w5, #0x7ffffffc
    66d8:      	orr	w6, w7, #0x1
    66dc:      	subs	w19, w19, #0x4
    66e0:      	b.ne	0x66dc <_stogir.pipeline.prepare-checked+0x3ca8>
    66e4:      	cmp	w5, w7
    66e8:      	b.eq	0x66f8 <_stogir.pipeline.prepare-checked+0x3cc4>
    66ec:      	add	w6, w6, #0x1
    66f0:      	cmp	w6, w5
    66f4:      	b.le	0x66ec <_stogir.pipeline.prepare-checked+0x3cb8>
    66f8:      	mov	x19, xzr
    66fc:      	ldr	x5, [sp, #0x20]
    6700:      	str	x19, [x1, x4, lsl #3]
    6704:      	add	x5, x5, #0x1
    6708:      	str	x5, [sp, #0x20]
    670c:      	ldr	x5, [sp, #0xa0]
    6710:      	cmp	x26, #0x0
    6714:      	cset	w19, eq
    6718:      	cmp	x4, x8
    671c:      	b.lo	0x65a0 <_stogir.pipeline.prepare-checked+0x3b6c>
    6720:      	b	0x673c <_stogir.pipeline.prepare-checked+0x3d08>
    6724:      	mov	x26, xzr
    6728:      	str	w4, [x10, x6, lsl #2]
    672c:      	b	0x651c <_stogir.pipeline.prepare-checked+0x3ae8>
    6730:      	mov	w19, wzr
    6734:      	str	x9, [sp, #0x28]
    6738:      	mov	w26, #0x19              ; =25
    673c:      	ldur	x8, [x29, #-0x88]
    6740:      	ldur	x27, [x29, #-0xf0]
    6744:      	cmp	x8, #0x2
    6748:      	str	x8, [sp, #0x40]
    674c:      	b.lt	0x6824 <_stogir.pipeline.prepare-checked+0x3df0>
    6750:      	ldur	x20, [x29, #-0x90]
    6754:      	ldur	x21, [x29, #-0xc0]
    6758:      	mov	w24, #0x1               ; =1
    675c:      	ldr	x22, [sp, #0x550]
    6760:      	ldr	x11, [sp, #0x70]
    6764:      	mov	w25, #0x2               ; =2
    6768:      	ldr	x12, [sp, #0x40]
    676c:      	b	0x6798 <_stogir.pipeline.prepare-checked+0x3d64>
    6770:      	mov	x27, x1
    6774:      	stur	x23, [x29, #-0xe0]
    6778:      	ldr	x11, [sp, #0x70]
    677c:      	ldr	x12, [sp, #0x40]
    6780:      	add	x8, x28, #0x1
    6784:      	str	w24, [x27, x28, lsl #2]
    6788:      	stur	x8, [x29, #-0xe8]
    678c:      	add	x24, x24, #0x1
    6790:      	cmp	x12, x24
    6794:      	b.eq	0x6824 <_stogir.pipeline.prepare-checked+0x3df0>
    6798:      	ldr	x8, [x20, x24, lsl #3]
    679c:      	tbnz	x8, #0x3f, 0x678c <_stogir.pipeline.prepare-checked+0x3d58>
    67a0:      	ldrsw	x9, [x11, x24, lsl #2]
    67a4:      	ldr	w10, [x21, x9, lsl #2]
    67a8:      	cmp	w24, w10
    67ac:      	b.ne	0x67bc <_stogir.pipeline.prepare-checked+0x3d88>
    67b0:      	ldr	x9, [x22, x9, lsl #3]
    67b4:      	add	x8, x9, x8
    67b8:      	str	x8, [x20, x24, lsl #3]
    67bc:      	cbnz	x8, 0x678c <_stogir.pipeline.prepare-checked+0x3d58>
    67c0:      	ldp	x28, x2, [x29, #-0xe8]
    67c4:      	cmp	x28, x2
    67c8:      	b.lt	0x6778 <_stogir.pipeline.prepare-checked+0x3d44>
    67cc:      	lsl	x8, x2, #1
    67d0:      	cmp	x2, #0x0
    67d4:      	csel	x23, x25, x8, eq
    67d8:      	sub	x8, x29, #0xf0
    67dc:      	ldur	q0, [x8, #0x18]
    67e0:      	cmp	x23, x2
    67e4:      	add	x8, sp, #0x550
    67e8:      	str	q0, [x8, #0x80]
    67ec:      	b.le	0x6778 <_stogir.pipeline.prepare-checked+0x3d44>
    67f0:      	adrp	x4, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		00000000000067f0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    67f4:      	add	x0, sp, #0x5d0
    67f8:      	mov	x1, x27
    67fc:      	ldr	x4, [x4]
		00000000000067fc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6800:      	mov	x3, x23
    6804:      	mov	w5, #0x4                ; =4
    6808:      	mov	w6, #0x4                ; =4
    680c:      	bl	0x680c <_stogir.pipeline.prepare-checked+0x3dd8>
		000000000000680c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    6810:      	cbnz	w0, 0x6770 <_stogir.pipeline.prepare-checked+0x3d3c>
    6814:      	lsl	x1, x23, #2
    6818:      	adrp	x0, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006818:  ARM64_RELOC_PAGE21	l_cstr.204
    681c:      	add	x0, x0, #0x0
		000000000000681c:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    6820:      	bl	0x6820 <_stogir.pipeline.prepare-checked+0x3dec>
		0000000000006820:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    6824:      	stur	x27, [x29, #-0xf0]
    6828:      	cbz	w19, 0x6ab8 <_stogir.pipeline.prepare-checked+0x4084>
    682c:      	ldur	x20, [x29, #-0xe8]
    6830:      	mov	w19, #0x1               ; =1
    6834:      	cmp	x20, #0x1
    6838:      	b.lt	0x6ab8 <_stogir.pipeline.prepare-checked+0x4084>
    683c:      	ldp	x8, x15, [sp, #0x68]
    6840:      	mov	x21, xzr
    6844:      	ldr	x14, [sp, #0x80]
    6848:      	ldr	x16, [sp, #0x38]
    684c:      	mov	w1, #0x5                ; =5
    6850:      	mov	w3, #0x5e1c             ; =24092
    6854:      	mov	w4, #0x2                ; =2
    6858:      	add	x12, sp, #0x550
    685c:      	add	x0, x8, #0x4
    6860:      	ldr	x8, [sp, #0xa0]
    6864:      	adrp	x13, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006864:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    6868:      	add	x13, x13, #0x0
		0000000000006868:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    686c:      	mov	w17, #0x1               ; =1
    6870:      	str	x0, [sp, #0x18]
    6874:      	b	0x6890 <_stogir.pipeline.prepare-checked+0x3e5c>
    6878:      	str	w19, [x27, x20, lsl #2]
    687c:      	add	x20, x20, #0x1
    6880:      	stur	x20, [x29, #-0xe8]
    6884:      	add	x21, x21, #0x1
    6888:      	cmp	x21, x20
    688c:      	b.ge	0x6ab4 <_stogir.pipeline.prepare-checked+0x4080>
    6890:      	ldrsw	x28, [x27, x21, lsl #2]
    6894:      	add	x9, x16, x28, lsl #4
    6898:      	ldrsw	x22, [x15, x28, lsl #2]
    689c:      	ldr	x24, [x9, #0x8]
    68a0:      	cmp	x24, #0x1
    68a4:      	b.lt	0x69f8 <_stogir.pipeline.prepare-checked+0x3fc4>
    68a8:      	ldr	x9, [x9]
    68ac:      	add	x25, x0, x9, lsl #3
    68b0:      	b	0x68c8 <_stogir.pipeline.prepare-checked+0x3e94>
    68b4:      	str	w19, [x27, x20, lsl #2]
    68b8:      	add	x20, x20, #0x1
    68bc:      	subs	x24, x24, #0x1
    68c0:      	add	x25, x25, #0x8
    68c4:      	b.eq	0x69f8 <_stogir.pipeline.prepare-checked+0x3fc4>
    68c8:      	ldur	w19, [x25, #-0x4]
    68cc:      	ldrb	w9, [x14, w19, sxtw]
    68d0:      	tbz	w9, #0x0, 0x68bc <_stogir.pipeline.prepare-checked+0x3e88>
    68d4:      	ldr	w9, [x15, w19, sxtw #2]
    68d8:      	cmp	w9, w22
    68dc:      	b.ne	0x68bc <_stogir.pipeline.prepare-checked+0x3e88>
    68e0:      	ldr	x9, [x8]
    68e4:      	sbfiz	x10, x19, #4, #32
    68e8:      	ldr	x9, [x9, x10]
    68ec:      	and	w11, w9, #0xff
    68f0:      	sub	w10, w11, #0x68
    68f4:      	cmp	w10, #0xa
    68f8:      	b.lo	0x68bc <_stogir.pipeline.prepare-checked+0x3e88>
    68fc:      	ldr	w10, [x25]
    6900:      	cmp	w11, #0x43
    6904:      	b.ne	0x6910 <_stogir.pipeline.prepare-checked+0x3edc>
    6908:      	cmp	w10, #0x1
    690c:      	b.gt	0x68bc <_stogir.pipeline.prepare-checked+0x3e88>
    6910:      	cmp	w11, #0x82
    6914:      	mov	w11, wzr
    6918:      	b.hi	0x6944 <_stogir.pipeline.prepare-checked+0x3f10>
    691c:      	cmp	w10, #0x1
    6920:      	b.lt	0x6944 <_stogir.pipeline.prepare-checked+0x3f10>
    6924:      	cmp	w10, #0x5
    6928:      	and	x9, x9, #0xff
    692c:      	csel	w10, w10, w1, lo
    6930:      	ldr	w9, [x13, x9, lsl #2]
    6934:      	lsl	w10, w10, #2
    6938:      	sub	w10, w10, #0x4
    693c:      	lsr	w9, w9, w10
    6940:      	and	w11, w9, #0xf
    6944:      	cmp	w11, #0xf
    6948:      	b.eq	0x68bc <_stogir.pipeline.prepare-checked+0x3e88>
    694c:      	lsl	w9, w17, w11
    6950:      	and	w9, w9, w3
    6954:      	cbz	w9, 0x68bc <_stogir.pipeline.prepare-checked+0x3e88>
    6958:      	ldur	x9, [x29, #-0x90]
    695c:      	ldr	x10, [x9, w19, sxtw #3]
    6960:      	subs	x10, x10, #0x1
    6964:      	str	x10, [x9, w19, sxtw #3]
    6968:      	b.ne	0x68bc <_stogir.pipeline.prepare-checked+0x3e88>
    696c:      	ldur	x2, [x29, #-0xe0]
    6970:      	cmp	x20, x2
    6974:      	b.lt	0x68b4 <_stogir.pipeline.prepare-checked+0x3e80>
    6978:      	lsl	x9, x2, #1
    697c:      	cmp	x2, #0x0
    6980:      	csel	x23, x4, x9, eq
    6984:      	sub	x9, x29, #0xf0
    6988:      	ldur	q0, [x9, #0x18]
    698c:      	cmp	x23, x2
    6990:      	str	q0, [x12, #0x80]
    6994:      	b.le	0x68b4 <_stogir.pipeline.prepare-checked+0x3e80>
    6998:      	adrp	x4, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006998:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    699c:      	add	x0, sp, #0x5d0
    69a0:      	mov	x1, x27
    69a4:      	ldr	x4, [x4]
		00000000000069a4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    69a8:      	mov	x3, x23
    69ac:      	mov	w5, #0x4                ; =4
    69b0:      	mov	w6, #0x4                ; =4
    69b4:      	bl	0x69b4 <_stogir.pipeline.prepare-checked+0x3f80>
		00000000000069b4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    69b8:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    69bc:      	ldr	x8, [sp, #0xa0]
    69c0:      	ldr	x14, [sp, #0x80]
    69c4:      	mov	x27, x1
    69c8:      	ldr	x15, [sp, #0x70]
    69cc:      	ldr	x16, [sp, #0x38]
    69d0:      	add	x12, sp, #0x550
    69d4:      	ldr	x0, [sp, #0x18]
    69d8:      	adrp	x13, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		00000000000069d8:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    69dc:      	add	x13, x13, #0x0
		00000000000069dc:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    69e0:      	mov	w17, #0x1               ; =1
    69e4:      	mov	w1, #0x5                ; =5
    69e8:      	mov	w3, #0x5e1c             ; =24092
    69ec:      	mov	w4, #0x2                ; =2
    69f0:      	stur	x23, [x29, #-0xe0]
    69f4:      	b	0x68b4 <_stogir.pipeline.prepare-checked+0x3e80>
    69f8:      	ldur	x9, [x29, #-0xc0]
    69fc:      	stp	x27, x20, [x29, #-0xf0]
    6a00:      	ldr	w19, [x9, x22, lsl #2]
    6a04:      	cmp	w19, #0x1
    6a08:      	ccmp	w19, w28, #0x4, ge
    6a0c:      	b.eq	0x6884 <_stogir.pipeline.prepare-checked+0x3e50>
    6a10:      	ldur	x9, [x29, #-0x90]
    6a14:      	ldr	x10, [x9, w19, uxtw #3]
    6a18:      	subs	x10, x10, #0x1
    6a1c:      	str	x10, [x9, w19, uxtw #3]
    6a20:      	b.ne	0x6884 <_stogir.pipeline.prepare-checked+0x3e50>
    6a24:      	ldur	x2, [x29, #-0xe0]
    6a28:      	cmp	x20, x2
    6a2c:      	b.lt	0x6878 <_stogir.pipeline.prepare-checked+0x3e44>
    6a30:      	lsl	x9, x2, #1
    6a34:      	cmp	x2, #0x0
    6a38:      	csel	x23, x4, x9, eq
    6a3c:      	sub	x9, x29, #0xf0
    6a40:      	ldur	q0, [x9, #0x18]
    6a44:      	cmp	x23, x2
    6a48:      	str	q0, [x12, #0x80]
    6a4c:      	b.le	0x6878 <_stogir.pipeline.prepare-checked+0x3e44>
    6a50:      	adrp	x4, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006a50:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6a54:      	add	x0, sp, #0x5d0
    6a58:      	mov	x1, x27
    6a5c:      	ldr	x4, [x4]
		0000000000006a5c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6a60:      	mov	x3, x23
    6a64:      	mov	w5, #0x4                ; =4
    6a68:      	mov	w6, #0x4                ; =4
    6a6c:      	bl	0x6a6c <_stogir.pipeline.prepare-checked+0x4038>
		0000000000006a6c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    6a70:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    6a74:      	ldr	x8, [sp, #0xa0]
    6a78:      	ldr	x14, [sp, #0x80]
    6a7c:      	mov	x27, x1
    6a80:      	ldr	x15, [sp, #0x70]
    6a84:      	ldr	x16, [sp, #0x38]
    6a88:      	add	x12, sp, #0x550
    6a8c:      	ldr	x0, [sp, #0x18]
    6a90:      	stur	x1, [x29, #-0xf0]
    6a94:      	adrp	x13, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006a94:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    6a98:      	add	x13, x13, #0x0
		0000000000006a98:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    6a9c:      	mov	w17, #0x1               ; =1
    6aa0:      	mov	w1, #0x5                ; =5
    6aa4:      	mov	w3, #0x5e1c             ; =24092
    6aa8:      	mov	w4, #0x2                ; =2
    6aac:      	stur	x23, [x29, #-0xe0]
    6ab0:      	b	0x6878 <_stogir.pipeline.prepare-checked+0x3e44>
    6ab4:      	mov	w19, #0x1               ; =1
    6ab8:      	ldr	x8, [sp, #0x40]
    6abc:      	cbz	x8, 0x6ac4 <_stogir.pipeline.prepare-checked+0x4090>
    6ac0:      	stur	xzr, [x29, #-0x88]
    6ac4:      	ldur	x2, [x29, #-0x80]
    6ac8:      	cmp	x2, #0x1
    6acc:      	b.lt	0x6af0 <_stogir.pipeline.prepare-checked+0x40bc>
    6ad0:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006ad0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    6ad4:      	ldur	x1, [x29, #-0x90]
    6ad8:      	sub	x8, x29, #0x90
    6adc:      	ldr	x3, [x3]
		0000000000006adc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    6ae0:      	add	x0, x8, #0x18
    6ae4:      	mov	w4, #0x8                ; =8
    6ae8:      	mov	w5, #0x8                ; =8
    6aec:      	bl	0x6aec <_stogir.pipeline.prepare-checked+0x40b8>
		0000000000006aec:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6af0:      	ldr	x8, [sp, #0x10]
    6af4:      	stp	xzr, xzr, [x29, #-0x90]
    6af8:      	stur	xzr, [x29, #-0x80]
    6afc:      	cbz	x8, 0x6b04 <_stogir.pipeline.prepare-checked+0x40d0>
    6b00:      	stur	xzr, [x29, #-0xb8]
    6b04:      	ldur	x2, [x29, #-0xb0]
    6b08:      	cmp	x2, #0x1
    6b0c:      	b.lt	0x6b30 <_stogir.pipeline.prepare-checked+0x40fc>
    6b10:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006b10:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6b14:      	ldur	x1, [x29, #-0xc0]
    6b18:      	sub	x8, x29, #0xc0
    6b1c:      	ldr	x3, [x3]
		0000000000006b1c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6b20:      	add	x0, x8, #0x18
    6b24:      	mov	w4, #0x4                ; =4
    6b28:      	mov	w5, #0x4                ; =4
    6b2c:      	bl	0x6b2c <_stogir.pipeline.prepare-checked+0x40f8>
		0000000000006b2c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6b30:      	ldr	x8, [sp, #0x8]
    6b34:      	stp	xzr, xzr, [x29, #-0xc0]
    6b38:      	stur	xzr, [x29, #-0xb0]
    6b3c:      	cbz	x8, 0x6b44 <_stogir.pipeline.prepare-checked+0x4110>
    6b40:      	str	xzr, [sp, #0x558]
    6b44:      	ldr	x2, [sp, #0x560]
    6b48:      	cmp	x2, #0x1
    6b4c:      	b.lt	0x6b70 <_stogir.pipeline.prepare-checked+0x413c>
    6b50:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006b50:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    6b54:      	ldr	x1, [sp, #0x550]
    6b58:      	add	x8, sp, #0x550
    6b5c:      	ldr	x3, [x3]
		0000000000006b5c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    6b60:      	add	x0, x8, #0x18
    6b64:      	mov	w4, #0x8                ; =8
    6b68:      	mov	w5, #0x8                ; =8
    6b6c:      	bl	0x6b6c <_stogir.pipeline.prepare-checked+0x4138>
		0000000000006b6c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6b70:      	str	xzr, [sp, #0x558]
    6b74:      	str	xzr, [sp, #0x550]
    6b78:      	str	xzr, [sp, #0x560]
    6b7c:      	tbz	w19, #0x0, 0x6ba0 <_stogir.pipeline.prepare-checked+0x416c>
    6b80:      	ldur	x19, [x29, #-0xe8]
    6b84:      	ldr	x8, [sp, #0x20]
    6b88:      	cmp	x19, x8
    6b8c:      	b.eq	0x6bd8 <_stogir.pipeline.prepare-checked+0x41a4>
    6b90:      	adrp	x8, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006b90:  ARM64_RELOC_PAGE21	l_str.677
    6b94:      	add	x8, x8, #0x0
		0000000000006b94:  ARM64_RELOC_PAGEOFF12	l_str.677
    6b98:      	mov	w26, #0x16              ; =22
    6b9c:      	str	x8, [sp, #0x28]
    6ba0:      	ldur	x2, [x29, #-0xe0]
    6ba4:      	stur	xzr, [x29, #-0xe8]
    6ba8:      	cmp	x2, #0x1
    6bac:      	b.lt	0x6bd0 <_stogir.pipeline.prepare-checked+0x419c>
    6bb0:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006bb0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6bb4:      	sub	x8, x29, #0xf0
    6bb8:      	mov	x1, x27
    6bbc:      	ldr	x3, [x3]
		0000000000006bbc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6bc0:      	add	x0, x8, #0x18
    6bc4:      	mov	w4, #0x4                ; =4
    6bc8:      	mov	w5, #0x4                ; =4
    6bcc:      	bl	0x6bcc <_stogir.pipeline.prepare-checked+0x4198>
		0000000000006bcc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6bd0:      	ldr	x23, [sp, #0x28]
    6bd4:      	b	0x6ed8 <_stogir.pipeline.prepare-checked+0x44a4>
    6bd8:      	ldr	x8, [sp, #0x98]
    6bdc:      	adrp	x24, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006bdc:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6be0:      	mov	x20, xzr
    6be4:      	mov	x28, xzr
    6be8:      	mov	x25, xzr
    6bec:      	mov	x26, xzr
    6bf0:      	ldr	q0, [x8]
    6bf4:      	mov	w21, #0x2               ; =2
    6bf8:      	str	q0, [sp, #0x40]
    6bfc:      	ldr	x24, [x24]
		0000000000006bfc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6c00:      	ldr	x8, [sp, #0xa0]
    6c04:      	cmp	x20, x19
    6c08:      	b.ge	0x6c1c <_stogir.pipeline.prepare-checked+0x41e8>
    6c0c:      	ldr	w22, [x27, x20, lsl #2]
    6c10:      	add	x20, x20, #0x1
    6c14:      	mov	w9, #0x1                ; =1
    6c18:      	b	0x6c20 <_stogir.pipeline.prepare-checked+0x41ec>
    6c1c:      	mov	x9, xzr
    6c20:      	cbz	w9, 0x6ca0 <_stogir.pipeline.prepare-checked+0x426c>
    6c24:      	ldr	x9, [x8]
    6c28:      	sbfiz	x10, x22, #4, #32
    6c2c:      	ldr	w9, [x9, x10]
    6c30:      	and	w9, w9, #0xfe
    6c34:      	sub	w9, w9, #0x68
    6c38:      	cmp	w9, #0x9
    6c3c:      	b.hi	0x6c04 <_stogir.pipeline.prepare-checked+0x41d0>
    6c40:      	cmp	x25, x26
    6c44:      	b.lt	0x6c94 <_stogir.pipeline.prepare-checked+0x4260>
    6c48:      	lsl	x8, x26, #1
    6c4c:      	cmp	x26, #0x0
    6c50:      	ldr	q0, [sp, #0x40]
    6c54:      	csel	x23, x21, x8, eq
    6c58:      	add	x8, sp, #0x550
    6c5c:      	cmp	x23, x26
    6c60:      	str	q0, [x8, #0x80]
    6c64:      	b.le	0x6c94 <_stogir.pipeline.prepare-checked+0x4260>
    6c68:      	add	x0, sp, #0x5d0
    6c6c:      	mov	x1, x28
    6c70:      	mov	x2, x26
    6c74:      	mov	x3, x23
    6c78:      	mov	x4, x24
    6c7c:      	mov	w5, #0x4                ; =4
    6c80:      	mov	w6, #0x4                ; =4
    6c84:      	bl	0x6c84 <_stogir.pipeline.prepare-checked+0x4250>
		0000000000006c84:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    6c88:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    6c8c:      	mov	x28, x1
    6c90:      	mov	x26, x23
    6c94:      	str	w22, [x28, x25, lsl #2]
    6c98:      	add	x25, x25, #0x1
    6c9c:      	b	0x6c00 <_stogir.pipeline.prepare-checked+0x41cc>
    6ca0:      	adrp	x24, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006ca0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6ca4:      	mov	x20, xzr
    6ca8:      	mov	w21, #0x2               ; =2
    6cac:      	ldr	x24, [x24]
		0000000000006cac:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6cb0:      	ldr	x8, [sp, #0xa0]
    6cb4:      	cmp	x20, x19
    6cb8:      	b.ge	0x6ccc <_stogir.pipeline.prepare-checked+0x4298>
    6cbc:      	ldr	w22, [x27, x20, lsl #2]
    6cc0:      	add	x20, x20, #0x1
    6cc4:      	mov	w9, #0x1                ; =1
    6cc8:      	b	0x6cd0 <_stogir.pipeline.prepare-checked+0x429c>
    6ccc:      	mov	x9, xzr
    6cd0:      	cbz	w9, 0x6d48 <_stogir.pipeline.prepare-checked+0x4314>
    6cd4:      	ldr	x9, [x8]
    6cd8:      	sbfiz	x10, x22, #4, #32
    6cdc:      	ldrb	w9, [x9, x10]
    6ce0:      	cmp	x9, #0x47
    6ce4:      	b.ne	0x6cb4 <_stogir.pipeline.prepare-checked+0x4280>
    6ce8:      	cmp	x25, x26
    6cec:      	b.lt	0x6d3c <_stogir.pipeline.prepare-checked+0x4308>
    6cf0:      	lsl	x8, x26, #1
    6cf4:      	cmp	x26, #0x0
    6cf8:      	ldr	q0, [sp, #0x40]
    6cfc:      	csel	x23, x21, x8, eq
    6d00:      	add	x8, sp, #0x550
    6d04:      	cmp	x23, x26
    6d08:      	str	q0, [x8, #0x80]
    6d0c:      	b.le	0x6d3c <_stogir.pipeline.prepare-checked+0x4308>
    6d10:      	add	x0, sp, #0x5d0
    6d14:      	mov	x1, x28
    6d18:      	mov	x2, x26
    6d1c:      	mov	x3, x23
    6d20:      	mov	x4, x24
    6d24:      	mov	w5, #0x4                ; =4
    6d28:      	mov	w6, #0x4                ; =4
    6d2c:      	bl	0x6d2c <_stogir.pipeline.prepare-checked+0x42f8>
		0000000000006d2c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    6d30:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    6d34:      	mov	x28, x1
    6d38:      	mov	x26, x23
    6d3c:      	str	w22, [x28, x25, lsl #2]
    6d40:      	add	x25, x25, #0x1
    6d44:      	b	0x6cb0 <_stogir.pipeline.prepare-checked+0x427c>
    6d48:      	mov	x20, xzr
    6d4c:      	mov	w21, #0x47              ; =71
    6d50:      	mov	w22, #0x2               ; =2
    6d54:      	cmp	x20, x19
    6d58:      	b.ge	0x6d6c <_stogir.pipeline.prepare-checked+0x4338>
    6d5c:      	ldr	w24, [x27, x20, lsl #2]
    6d60:      	add	x20, x20, #0x1
    6d64:      	mov	w9, #0x1                ; =1
    6d68:      	b	0x6d70 <_stogir.pipeline.prepare-checked+0x433c>
    6d6c:      	mov	x9, xzr
    6d70:      	cbz	w9, 0x6df8 <_stogir.pipeline.prepare-checked+0x43c4>
    6d74:      	ldr	x9, [x8]
    6d78:      	sbfiz	x10, x24, #4, #32
    6d7c:      	ldrb	w9, [x9, x10]
    6d80:      	sub	w10, w9, #0x72
    6d84:      	cmn	w10, #0xb
    6d88:      	ccmp	w9, w21, #0x4, ls
    6d8c:      	b.eq	0x6d54 <_stogir.pipeline.prepare-checked+0x4320>
    6d90:      	cmp	x25, x26
    6d94:      	b.lt	0x6de8 <_stogir.pipeline.prepare-checked+0x43b4>
    6d98:      	lsl	x8, x26, #1
    6d9c:      	cmp	x26, #0x0
    6da0:      	ldr	q0, [sp, #0x40]
    6da4:      	csel	x23, x22, x8, eq
    6da8:      	add	x8, sp, #0x550
    6dac:      	cmp	x23, x26
    6db0:      	str	q0, [x8, #0x80]
    6db4:      	b.le	0x6de8 <_stogir.pipeline.prepare-checked+0x43b4>
    6db8:      	adrp	x4, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006db8:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6dbc:      	add	x0, sp, #0x5d0
    6dc0:      	mov	x1, x28
    6dc4:      	ldr	x4, [x4]
		0000000000006dc4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6dc8:      	mov	x2, x26
    6dcc:      	mov	x3, x23
    6dd0:      	mov	w5, #0x4                ; =4
    6dd4:      	mov	w6, #0x4                ; =4
    6dd8:      	bl	0x6dd8 <_stogir.pipeline.prepare-checked+0x43a4>
		0000000000006dd8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    6ddc:      	cbz	w0, 0x6814 <_stogir.pipeline.prepare-checked+0x3de0>
    6de0:      	mov	x28, x1
    6de4:      	mov	x26, x23
    6de8:      	ldr	x8, [sp, #0xa0]
    6dec:      	str	w24, [x28, x25, lsl #2]
    6df0:      	add	x25, x25, #0x1
    6df4:      	b	0x6d54 <_stogir.pipeline.prepare-checked+0x4320>
    6df8:      	ldur	x2, [x29, #-0xe0]
    6dfc:      	stur	xzr, [x29, #-0xe8]
    6e00:      	cmp	x2, #0x1
    6e04:      	b.lt	0x6e28 <_stogir.pipeline.prepare-checked+0x43f4>
    6e08:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006e08:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6e0c:      	ldur	x1, [x29, #-0xf0]
    6e10:      	sub	x8, x29, #0xf0
    6e14:      	ldr	x3, [x3]
		0000000000006e14:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6e18:      	add	x0, x8, #0x18
    6e1c:      	mov	w4, #0x4                ; =4
    6e20:      	mov	w5, #0x4                ; =4
    6e24:      	bl	0x6e24 <_stogir.pipeline.prepare-checked+0x43f0>
		0000000000006e24:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6e28:      	ldr	q0, [sp, #0x40]
    6e2c:      	add	x19, sp, #0x2b0
    6e30:      	add	x0, sp, #0x2b0
    6e34:      	str	x28, [sp, #0x380]
    6e38:      	str	x25, [sp, #0x388]
    6e3c:      	str	x26, [sp, #0x390]
    6e40:      	stur	q0, [x19, #0xe8]
    6e44:      	bl	0x6e44 <_stogir.pipeline.prepare-checked+0x4410>
		0000000000006e44:  ARM64_RELOC_BRANCH26	_stogir.schedule.release!
    6e48:      	ldp	x4, x5, [sp, #0x1c0]
    6e4c:      	add	x0, sp, #0x3a8
    6e50:      	ldr	x23, [sp, #0x98]
    6e54:      	add	x3, sp, #0x358
    6e58:      	mov	x1, x28
    6e5c:      	mov	x2, x25
    6e60:      	mov	x6, x23
    6e64:      	bl	0x6e64 <_stogir.pipeline.prepare-checked+0x4430>
		0000000000006e64:  ARM64_RELOC_BRANCH26	_stogir.schedule.pack
    6e68:      	add	x8, sp, #0x2e9
    6e6c:      	ldr	x1, [sp, #0xa0]
    6e70:      	ldr	x2, [sp, #0x70]
    6e74:      	ldur	q3, [x8, #0xff]
    6e78:      	add	x8, sp, #0x2a9
    6e7c:      	add	x0, sp, #0x3f8
    6e80:      	ldur	q1, [x8, #0xff]
    6e84:      	add	x8, sp, #0x2b9
    6e88:      	add	x3, sp, #0x2b0
    6e8c:      	ldur	q2, [x8, #0xff]
    6e90:      	add	x8, sp, #0x2c9
    6e94:      	mov	x4, x23
    6e98:      	ldur	q0, [x8, #0xff]
    6e9c:      	add	x8, sp, #0x2d9
    6ea0:      	stp	q1, q2, [x19]
    6ea4:      	ldur	q1, [x8, #0xff]
    6ea8:      	str	q0, [x19, #0x20]
    6eac:      	stp	q1, q3, [x19, #0x30]
    6eb0:      	bl	0x6eb0 <_stogir.pipeline.prepare-checked+0x447c>
		0000000000006eb0:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.cluster!
    6eb4:      	ldr	w8, [sp, #0x3f8]
    6eb8:      	ldr	x9, [sp, #0x400]
    6ebc:      	add	x0, sp, #0x380
    6ec0:      	ldr	x10, [sp, #0x408]
    6ec4:      	ldr	x23, [sp, #0x30]
    6ec8:      	cmp	w8, #0x1
    6ecc:      	csel	x26, x10, xzr, eq
    6ed0:      	csel	x23, x9, x23, eq
    6ed4:      	bl	0x6ed4 <_stogir.pipeline.prepare-checked+0x44a0>
		0000000000006ed4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    6ed8:      	ldr	x28, [sp, #0x58]
    6edc:      	ldr	x20, [sp, #0x60]
    6ee0:      	ldr	x2, [sp, #0x368]
    6ee4:      	str	xzr, [sp, #0x360]
    6ee8:      	cmp	x2, #0x1
    6eec:      	b.lt	0x6f10 <_stogir.pipeline.prepare-checked+0x44dc>
    6ef0:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006ef0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    6ef4:      	add	x8, sp, #0x358
    6ef8:      	mov	w4, #0x4                ; =4
    6efc:      	ldr	x3, [x3]
		0000000000006efc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    6f00:      	ldr	x1, [sp, #0x70]
    6f04:      	add	x0, x8, #0x18
    6f08:      	mov	w5, #0x4                ; =4
    6f0c:      	bl	0x6f0c <_stogir.pipeline.prepare-checked+0x44d8>
		0000000000006f0c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6f10:      	ldr	x2, [sp, #0x130]
    6f14:      	str	xzr, [sp, #0x128]
    6f18:      	cmp	x2, #0x1
    6f1c:      	b.lt	0x6f40 <_stogir.pipeline.prepare-checked+0x450c>
    6f20:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006f20:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Range.0
    6f24:      	ldr	x1, [sp, #0x120]
    6f28:      	add	x8, sp, #0x120
    6f2c:      	ldr	x3, [x3]
		0000000000006f2c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Range.0
    6f30:      	add	x0, x8, #0x18
    6f34:      	mov	w4, #0x10               ; =16
    6f38:      	mov	w5, #0x8                ; =8
    6f3c:      	bl	0x6f3c <_stogir.pipeline.prepare-checked+0x4508>
		0000000000006f3c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6f40:      	ldr	x2, [sp, #0x158]
    6f44:      	stp	xzr, xzr, [sp, #0x120]
    6f48:      	str	xzr, [sp, #0x130]
    6f4c:      	cmp	x2, #0x1
    6f50:      	str	xzr, [sp, #0x150]
    6f54:      	b.lt	0x6f78 <_stogir.pipeline.prepare-checked+0x4544>
    6f58:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006f58:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    6f5c:      	ldr	x1, [sp, #0x148]
    6f60:      	add	x8, sp, #0x120
    6f64:      	ldr	x3, [x3]
		0000000000006f64:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    6f68:      	add	x0, x8, #0x40
    6f6c:      	mov	w4, #0x8                ; =8
    6f70:      	mov	w5, #0x8                ; =8
    6f74:      	bl	0x6f74 <_stogir.pipeline.prepare-checked+0x4540>
		0000000000006f74:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6f78:      	ldr	x2, [sp, #0x180]
    6f7c:      	str	xzr, [sp, #0x178]
    6f80:      	cmp	x2, #0x1
    6f84:      	b.lt	0x6fa8 <_stogir.pipeline.prepare-checked+0x4574>
    6f88:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006f88:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.adjacency.Range.0
    6f8c:      	ldr	x1, [sp, #0x170]
    6f90:      	add	x8, sp, #0x170
    6f94:      	ldr	x3, [x3]
		0000000000006f94:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.adjacency.Range.0
    6f98:      	add	x0, x8, #0x18
    6f9c:      	mov	w4, #0x10               ; =16
    6fa0:      	mov	w5, #0x8                ; =8
    6fa4:      	bl	0x6fa4 <_stogir.pipeline.prepare-checked+0x4570>
		0000000000006fa4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6fa8:      	ldr	x2, [sp, #0x1a8]
    6fac:      	stp	xzr, xzr, [sp, #0x170]
    6fb0:      	str	xzr, [sp, #0x180]
    6fb4:      	cmp	x2, #0x1
    6fb8:      	str	xzr, [sp, #0x1a0]
    6fbc:      	b.lt	0x6fe0 <_stogir.pipeline.prepare-checked+0x45ac>
    6fc0:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006fc0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    6fc4:      	ldr	x1, [sp, #0x198]
    6fc8:      	add	x8, sp, #0x170
    6fcc:      	ldr	x3, [x3]
		0000000000006fcc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    6fd0:      	add	x0, x8, #0x40
    6fd4:      	mov	w4, #0x8                ; =8
    6fd8:      	mov	w5, #0x8                ; =8
    6fdc:      	bl	0x6fdc <_stogir.pipeline.prepare-checked+0x45a8>
		0000000000006fdc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    6fe0:      	cmp	x28, #0x1
    6fe4:      	str	xzr, [sp, #0x240]
    6fe8:      	b.lt	0x7010 <_stogir.pipeline.prepare-checked+0x45dc>
    6fec:      	adrp	x3, 0x6000 <_stogir.pipeline.prepare-checked+0x35cc>
		0000000000006fec:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__bool.0
    6ff0:      	add	x8, sp, #0x238
    6ff4:      	mov	x2, x28
    6ff8:      	ldr	x3, [x3]
		0000000000006ff8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__bool.0
    6ffc:      	ldr	x1, [sp, #0x80]
    7000:      	add	x0, x8, #0x18
    7004:      	mov	w4, #0x1                ; =1
    7008:      	mov	w5, #0x1                ; =1
    700c:      	bl	0x700c <_stogir.pipeline.prepare-checked+0x45d8>
		000000000000700c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    7010:      	ldr	x2, [sp, #0x270]
    7014:      	add	x19, sp, #0x260
    7018:      	str	xzr, [sp, #0x268]
    701c:      	cmp	x2, #0x1
    7020:      	b.lt	0x7040 <_stogir.pipeline.prepare-checked+0x460c>
    7024:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007024:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.uses.Range.0
    7028:      	ldr	x1, [sp, #0x260]
    702c:      	add	x0, x19, #0x18
    7030:      	ldr	x3, [x3]
		0000000000007030:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.uses.Range.0
    7034:      	mov	w4, #0x10               ; =16
    7038:      	mov	w5, #0x8                ; =8
    703c:      	bl	0x703c <_stogir.pipeline.prepare-checked+0x4608>
		000000000000703c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    7040:      	cmp	x20, #0x1
    7044:      	str	xzr, [sp, #0x268]
    7048:      	str	xzr, [sp, #0x260]
    704c:      	str	xzr, [sp, #0x270]
    7050:      	str	xzr, [sp, #0x290]
    7054:      	b.lt	0x7078 <_stogir.pipeline.prepare-checked+0x4644>
    7058:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007058:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.uses.Use.0
    705c:      	add	x0, x19, #0x40
    7060:      	mov	x2, x20
    7064:      	ldr	x3, [x3]
		0000000000007064:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.uses.Use.0
    7068:      	ldr	x1, [sp, #0x68]
    706c:      	mov	w4, #0x8                ; =8
    7070:      	mov	w5, #0x4                ; =4
    7074:      	bl	0x7074 <_stogir.pipeline.prepare-checked+0x4640>
		0000000000007074:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    7078:      	cbz	x26, 0x7194 <_stogir.pipeline.prepare-checked+0x4760>
    707c:      	ldr	x2, [sp, #0x1f8]
    7080:      	str	xzr, [sp, #0x1f0]
    7084:      	cmp	x2, #0x1
    7088:      	b.lt	0x70ac <_stogir.pipeline.prepare-checked+0x4678>
    708c:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000708c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    7090:      	ldr	x1, [sp, #0x1e8]
    7094:      	add	x8, sp, #0x1e8
    7098:      	ldr	x3, [x3]
		0000000000007098:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    709c:      	add	x0, x8, #0x18
    70a0:      	mov	w4, #0x4                ; =4
    70a4:      	mov	w5, #0x4                ; =4
    70a8:      	bl	0x70a8 <_stogir.pipeline.prepare-checked+0x4674>
		00000000000070a8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    70ac:      	ldr	x2, [sp, #0x220]
    70b0:      	str	xzr, [sp, #0x218]
    70b4:      	cmp	x2, #0x1
    70b8:      	b.lt	0x70dc <_stogir.pipeline.prepare-checked+0x46a8>
    70bc:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000070bc:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    70c0:      	ldr	x1, [sp, #0x210]
    70c4:      	add	x8, sp, #0x210
    70c8:      	ldr	x3, [x3]
		00000000000070c8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    70cc:      	add	x0, x8, #0x18
    70d0:      	mov	w4, #0x4                ; =4
    70d4:      	mov	w5, #0x4                ; =4
    70d8:      	bl	0x70d8 <_stogir.pipeline.prepare-checked+0x46a4>
		00000000000070d8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    70dc:      	add	x0, sp, #0xa8
    70e0:      	bl	0x70e0 <_stogir.pipeline.prepare-checked+0x46ac>
		00000000000070e0:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    70e4:      	ldr	x2, [sp, #0x1d0]
    70e8:      	str	xzr, [sp, #0x1c8]
    70ec:      	cmp	x2, #0x1
    70f0:      	b.lt	0x7114 <_stogir.pipeline.prepare-checked+0x46e0>
    70f4:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000070f4:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    70f8:      	ldr	x1, [sp, #0x1c0]
    70fc:      	add	x8, sp, #0x1c0
    7100:      	ldr	x3, [x3]
		0000000000007100:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    7104:      	add	x0, x8, #0x18
    7108:      	mov	w4, #0x4                ; =4
    710c:      	mov	w5, #0x4                ; =4
    7110:      	bl	0x7110 <_stogir.pipeline.prepare-checked+0x46dc>
		0000000000007110:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    7114:      	ldr	x2, [sp, #0x2c0]
    7118:      	str	xzr, [sp, #0x2b8]
    711c:      	cmp	x2, #0x1
    7120:      	b.lt	0x7144 <_stogir.pipeline.prepare-checked+0x4710>
    7124:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007124:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.schedule.Range.0
    7128:      	ldr	x1, [sp, #0x2b0]
    712c:      	add	x8, sp, #0x2b0
    7130:      	ldr	x3, [x3]
		0000000000007130:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.schedule.Range.0
    7134:      	add	x0, x8, #0x18
    7138:      	mov	w4, #0x10               ; =16
    713c:      	mov	w5, #0x8                ; =8
    7140:      	bl	0x7140 <_stogir.pipeline.prepare-checked+0x470c>
		0000000000007140:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    7144:      	ldr	x2, [sp, #0x2e8]
    7148:      	str	xzr, [sp, #0x2b8]
    714c:      	str	xzr, [sp, #0x2b0]
    7150:      	cmp	x2, #0x1
    7154:      	str	xzr, [sp, #0x2c0]
    7158:      	str	xzr, [sp, #0x2e0]
    715c:      	b.lt	0x7180 <_stogir.pipeline.prepare-checked+0x474c>
    7160:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007160:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    7164:      	ldr	x1, [sp, #0x2d8]
    7168:      	add	x8, sp, #0x2b0
    716c:      	ldr	x3, [x3]
		000000000000716c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    7170:      	add	x0, x8, #0x40
    7174:      	mov	w4, #0x4                ; =4
    7178:      	mov	w5, #0x4                ; =4
    717c:      	bl	0x717c <_stogir.pipeline.prepare-checked+0x4748>
		000000000000717c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    7180:      	ldr	x9, [sp, #0x90]
    7184:      	mov	w8, #0x1                ; =1
    7188:      	str	w8, [x9]
    718c:      	stp	x23, x26, [x9, #0x8]
    7190:      	b	0x2acc <_stogir.pipeline.prepare-checked+0x98>
    7194:      	add	x11, sp, #0x1c0
    7198:      	add	x8, sp, #0x410
    719c:      	ldr	x10, [sp, #0x230]
    71a0:      	ldp	q0, q1, [x11, #0x50]
    71a4:      	add	x8, x8, #0x118
    71a8:      	str	x10, [sp, #0x548]
    71ac:      	add	x10, sp, #0x2b0
    71b0:      	ldur	q2, [sp, #0xc8]
    71b4:      	ldr	x9, [sp, #0x208]
    71b8:      	ldr	x0, [sp, #0x90]
    71bc:      	add	x1, sp, #0x410
    71c0:      	stp	q0, q1, [x8]
    71c4:      	ldr	x8, [sp, #0x118]
    71c8:      	mov	w2, #0x140              ; =320
    71cc:      	str	x9, [sp, #0x520]
    71d0:      	ldr	x9, [sp, #0x1e0]
    71d4:      	str	x8, [sp, #0x480]
    71d8:      	add	x8, sp, #0xe9
    71dc:      	ldur	q0, [x8, #0xff]
    71e0:      	add	x8, sp, #0xf9
    71e4:      	str	x9, [sp, #0x4a8]
    71e8:      	ldur	q1, [x8, #0xff]
    71ec:      	add	x8, sp, #0x9
    71f0:      	str	wzr, [x0], #0x8
    71f4:      	stp	q0, q1, [x10, #0x250]
    71f8:      	ldur	q0, [sp, #0xd8]
    71fc:      	ldur	q1, [sp, #0xa8]
    7200:      	stp	q2, q0, [x10, #0x180]
    7204:      	ldur	q0, [sp, #0xb8]
    7208:      	ldur	q2, [x8, #0xff]
    720c:      	add	x8, sp, #0x410
    7210:      	stp	q1, q0, [x10, #0x160]
    7214:      	ldur	q0, [sp, #0xf8]
    7218:      	ldur	q1, [sp, #0xe8]
    721c:      	stp	q0, q2, [x10, #0x1b0]
    7220:      	str	q1, [x10, #0x1a0]
    7224:      	ldp	q1, q0, [x11]
    7228:      	stur	q0, [x8, #0x88]
    722c:      	ldp	q2, q0, [x10, #0x20]
    7230:      	stur	q1, [x8, #0x78]
    7234:      	stp	q2, q0, [x8, #0xc0]
    7238:      	ldp	q1, q0, [x10]
    723c:      	ldr	q2, [x10, #0x40]
    7240:      	stp	q1, q0, [x8, #0xa0]
    7244:      	str	q2, [x8, #0xe0]
    7248:      	bl	0x7248 <_stogir.pipeline.prepare-checked+0x4814>
		0000000000007248:  ARM64_RELOC_BRANCH26	_memcpy
    724c:      	b	0x2acc <_stogir.pipeline.prepare-checked+0x98>
    7250:      	add	x12, x24, x19, lsl #2
    7254:      	and	x9, x19, #0x7ffffffffffffff8
    7258:      	add	x11, x8, #0x10
    725c:      	sub	x10, x9, #0x1
    7260:      	and	x13, x19, #0x7ffffffffffffff8
    7264:      	sub	x12, x12, #0x10
    7268:      	ldp	q1, q0, [x12, #-0x10]
    726c:      	sub	x13, x13, #0x8
    7270:      	sub	x12, x12, #0x20
    7274:      	rev64.4s	v0, v0
    7278:      	rev64.4s	v1, v1
    727c:      	ext.16b	v0, v0, v0, #0x8
    7280:      	ext.16b	v1, v1, v1, #0x8
    7284:      	stp	q0, q1, [x11, #-0x10]
    7288:      	add	x11, x11, #0x20
    728c:      	cbnz	x13, 0x7268 <_stogir.pipeline.prepare-checked+0x4834>
    7290:      	cmp	x19, x9
    7294:      	b.ne	0x5d24 <_stogir.pipeline.prepare-checked+0x32f0>
    7298:      	b	0x5d48 <_stogir.pipeline.prepare-checked+0x3314>
    729c:      	lsl	x1, x22, #4
    72a0:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000072a0:  ARM64_RELOC_PAGE21	l_cstr.210
    72a4:      	add	x0, x0, #0x0
		00000000000072a4:  ARM64_RELOC_PAGEOFF12	l_cstr.210
    72a8:      	bl	0x72a8 <_stogir.pipeline.prepare-checked+0x4874>
		00000000000072a8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    72ac:      	lsl	x1, x21, #2
    72b0:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000072b0:  ARM64_RELOC_PAGE21	l_cstr.204
    72b4:      	add	x0, x0, #0x0
		00000000000072b4:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    72b8:      	bl	0x72b8 <_stogir.pipeline.prepare-checked+0x4884>
		00000000000072b8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    72bc:      	lsl	x1, x22, #2
    72c0:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000072c0:  ARM64_RELOC_PAGE21	l_cstr.204
    72c4:      	add	x0, x0, #0x0
		00000000000072c4:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    72c8:      	bl	0x72c8 <_stogir.pipeline.prepare-checked+0x4894>
		00000000000072c8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    72cc:      	lsl	x1, x25, #4
    72d0:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000072d0:  ARM64_RELOC_PAGE21	l_cstr.207
    72d4:      	add	x0, x0, #0x0
		00000000000072d4:  ARM64_RELOC_PAGEOFF12	l_cstr.207
    72d8:      	bl	0x72d8 <_stogir.pipeline.prepare-checked+0x48a4>
		00000000000072d8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    72dc:      	lsl	x1, x20, #2
    72e0:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000072e0:  ARM64_RELOC_PAGE21	l_cstr.204
    72e4:      	add	x0, x0, #0x0
		00000000000072e4:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    72e8:      	bl	0x72e8 <_stogir.pipeline.prepare-checked+0x48b4>
		00000000000072e8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    72ec:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000072ec:  ARM64_RELOC_PAGE21	l_cstr.207
    72f0:      	add	x0, x0, #0x0
		00000000000072f0:  ARM64_RELOC_PAGEOFF12	l_cstr.207
    72f4:      	mov	w1, #0x20               ; =32
    72f8:      	bl	0x72f8 <_stogir.pipeline.prepare-checked+0x48c4>
		00000000000072f8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    72fc:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000072fc:  ARM64_RELOC_PAGE21	l_cstr.203
    7300:      	add	x0, x0, #0x0
		0000000000007300:  ARM64_RELOC_PAGEOFF12	l_cstr.203
    7304:      	mov	x1, x21
    7308:      	bl	0x7308 <_stogir.pipeline.prepare-checked+0x48d4>
		0000000000007308:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    730c:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000730c:  ARM64_RELOC_PAGE21	l_cstr.204
    7310:      	add	x0, x0, #0x0
		0000000000007310:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    7314:      	mov	x1, x8
    7318:      	bl	0x7318 <_stogir.pipeline.prepare-checked+0x48e4>
		0000000000007318:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    731c:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000731c:  ARM64_RELOC_PAGE21	l_cstr.203
    7320:      	add	x0, x0, #0x0
		0000000000007320:  ARM64_RELOC_PAGEOFF12	l_cstr.203
    7324:      	mov	x1, x20
    7328:      	bl	0x7328 <_stogir.pipeline.prepare-checked+0x48f4>
		0000000000007328:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    732c:      	lsl	x1, x24, #4
    7330:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007330:  ARM64_RELOC_PAGE21	l_cstr.216
    7334:      	add	x0, x0, #0x0
		0000000000007334:  ARM64_RELOC_PAGEOFF12	l_cstr.216
    7338:      	bl	0x7338 <_stogir.pipeline.prepare-checked+0x4904>
		0000000000007338:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    733c:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000733c:  ARM64_RELOC_PAGE21	l_cstr.205
    7340:      	add	x0, x0, #0x0
		0000000000007340:  ARM64_RELOC_PAGEOFF12	l_cstr.205
    7344:      	mov	x1, x21
    7348:      	bl	0x7348 <_stogir.pipeline.prepare-checked+0x4914>
		0000000000007348:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    734c:      	lsl	x1, x23, #3
    7350:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007350:  ARM64_RELOC_PAGE21	l_cstr.217
    7354:      	add	x0, x0, #0x0
		0000000000007354:  ARM64_RELOC_PAGEOFF12	l_cstr.217
    7358:      	bl	0x7358 <_stogir.pipeline.prepare-checked+0x4924>
		0000000000007358:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    735c:      	lsl	x1, x27, #3
    7360:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007360:  ARM64_RELOC_PAGE21	l_cstr.205
    7364:      	add	x0, x0, #0x0
		0000000000007364:  ARM64_RELOC_PAGEOFF12	l_cstr.205
    7368:      	bl	0x7368 <_stogir.pipeline.prepare-checked+0x4934>
		0000000000007368:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    736c:      	lsl	x1, x26, #3
    7370:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007370:  ARM64_RELOC_PAGE21	l_cstr.205
    7374:      	add	x0, x0, #0x0
		0000000000007374:  ARM64_RELOC_PAGEOFF12	l_cstr.205
    7378:      	bl	0x7378 <_stogir.pipeline.prepare-checked+0x4944>
		0000000000007378:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    737c:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000737c:  ARM64_RELOC_PAGE21	l_cstr.204
    7380:      	add	x0, x0, #0x0
		0000000000007380:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    7384:      	mov	x1, x23
    7388:      	bl	0x7388 <_stogir.pipeline.prepare-checked+0x4954>
		0000000000007388:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    738c:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000738c:  ARM64_RELOC_PAGE21	l_cstr.205
    7390:      	add	x0, x0, #0x0
		0000000000007390:  ARM64_RELOC_PAGEOFF12	l_cstr.205
    7394:      	mov	x1, x23
    7398:      	bl	0x7398 <_stogir.pipeline.prepare-checked+0x4964>
		0000000000007398:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    739c:      	lsl	x1, x23, #4
    73a0:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000073a0:  ARM64_RELOC_PAGE21	l_cstr.207
    73a4:      	add	x0, x0, #0x0
		00000000000073a4:  ARM64_RELOC_PAGEOFF12	l_cstr.207
    73a8:      	bl	0x73a8 <_stogir.pipeline.prepare-checked+0x4974>
		00000000000073a8:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    73ac:      	ldr	x8, [sp, #0x40]
    73b0:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000073b0:  ARM64_RELOC_PAGE21	l_cstr.207
    73b4:      	add	x0, x0, #0x0
		00000000000073b4:  ARM64_RELOC_PAGEOFF12	l_cstr.207
    73b8:      	lsl	x1, x8, #4
    73bc:      	bl	0x73bc <_stogir.pipeline.prepare-checked+0x4988>
		00000000000073bc:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at

00000000000073c0 <_stogir.schedule.pack>:
    73c0:      	sub	sp, sp, #0xd0
    73c4:      	stp	x28, x27, [sp, #0x70]
    73c8:      	stp	x26, x25, [sp, #0x80]
    73cc:      	stp	x24, x23, [sp, #0x90]
    73d0:      	stp	x22, x21, [sp, #0xa0]
    73d4:      	stp	x20, x19, [sp, #0xb0]
    73d8:      	stp	x29, x30, [sp, #0xc0]
    73dc:      	add	x29, sp, #0xc0
    73e0:      	ldr	x21, [x3, #0x8]
    73e4:      	ldr	q0, [x6]
    73e8:      	mov	x28, x5
    73ec:      	ldr	q1, [x6]
    73f0:      	mov	x27, x4
    73f4:      	mov	x22, x3
    73f8:      	mov	x20, x2
    73fc:      	mov	x23, x1
    7400:      	mov	x19, x0
    7404:      	cmp	x21, #0x1
    7408:      	stp	xzr, xzr, [sp, #0x38]
    740c:      	str	xzr, [sp, #0x48]
    7410:      	stp	q0, q0, [sp, #0x50]
    7414:      	str	q1, [sp, #0x10]
    7418:      	b.lt	0x7458 <_stogir.schedule.pack+0x98>
    741c:      	ldr	q0, [x6]
    7420:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007420:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.schedule.Range.0
    7424:      	add	x0, sp, #0x20
    7428:      	mov	x1, xzr
    742c:      	mov	x2, xzr
    7430:      	mov	x3, x21
    7434:      	str	q0, [sp, #0x20]
    7438:      	mov	w5, #0x10               ; =16
    743c:      	mov	w6, #0x8                ; =8
    7440:      	ldr	x4, [x4]
		0000000000007440:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.schedule.Range.0
    7444:      	bl	0x7444 <_stogir.schedule.pack+0x84>
		0000000000007444:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    7448:      	cbz	w0, 0x7684 <_stogir.schedule.pack+0x2c4>
    744c:      	mov	x24, x1
    7450:      	str	x21, [sp, #0x8]
    7454:      	b	0x7460 <_stogir.schedule.pack+0xa0>
    7458:      	mov	x24, xzr
    745c:      	str	xzr, [sp, #0x8]
    7460:      	lsl	x1, x21, #4
    7464:      	mov	x0, x24
    7468:      	add	x26, sp, #0x38
    746c:      	bl	0x746c <_stogir.schedule.pack+0xac>
		000000000000746c:  ARM64_RELOC_BRANCH26	_bzero
    7470:      	ldr	x25, [x22, #0x8]
    7474:      	cmp	x25, #0x1
    7478:      	b.lt	0x74b8 <_stogir.schedule.pack+0xf8>
    747c:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000747c:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    7480:      	add	x0, x26, #0x18
    7484:      	mov	x1, xzr
    7488:      	ldr	x4, [x4]
		0000000000007488:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    748c:      	mov	x2, xzr
    7490:      	mov	x3, x25
    7494:      	mov	w5, #0x8                ; =8
    7498:      	mov	w6, #0x8                ; =8
    749c:      	bl	0x749c <_stogir.schedule.pack+0xdc>
		000000000000749c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    74a0:      	cbz	w0, 0x7694 <_stogir.schedule.pack+0x2d4>
    74a4:      	mov	x26, x1
    74a8:      	str	x1, [sp, #0x38]
    74ac:      	str	x25, [sp]
    74b0:      	str	x25, [sp, #0x48]
    74b4:      	b	0x74c0 <_stogir.schedule.pack+0x100>
    74b8:      	str	xzr, [sp]
    74bc:      	mov	x26, xzr
    74c0:      	lsl	x1, x25, #3
    74c4:      	mov	x0, x26
    74c8:      	bl	0x74c8 <_stogir.schedule.pack+0x108>
		00000000000074c8:  ARM64_RELOC_BRANCH26	_bzero
    74cc:      	mov	x8, xzr
    74d0:      	str	x25, [sp, #0x40]
    74d4:      	cmp	xzr, x20
    74d8:      	b.ge	0x74f0 <_stogir.schedule.pack+0x130>
    74dc:      	ldr	w9, [x23, x8, lsl #2]
    74e0:      	add	x8, x8, #0x1
    74e4:      	mov	w10, #0x1               ; =1
    74e8:      	cbnz	w10, 0x74f8 <_stogir.schedule.pack+0x138>
    74ec:      	b	0x7520 <_stogir.schedule.pack+0x160>
    74f0:      	mov	x10, xzr
    74f4:      	cbz	w10, 0x7520 <_stogir.schedule.pack+0x160>
    74f8:      	ldr	x10, [x22]
    74fc:      	sbfiz	x9, x9, #2, #32
    7500:      	ldrsw	x9, [x10, x9]
    7504:      	add	x9, x24, x9, lsl #4
    7508:      	ldr	x10, [x9, #0x8]
    750c:      	add	x10, x10, #0x1
    7510:      	str	x10, [x9, #0x8]
    7514:      	cmp	x8, x20
    7518:      	b.ge	0x74f0 <_stogir.schedule.pack+0x130>
    751c:      	b	0x74dc <_stogir.schedule.pack+0x11c>
    7520:      	mov	x9, xzr
    7524:      	mov	x8, xzr
    7528:      	cmp	xzr, x28
    752c:      	b.ge	0x7544 <_stogir.schedule.pack+0x184>
    7530:      	ldr	w10, [x27, x9, lsl #2]
    7534:      	add	x9, x9, #0x1
    7538:      	mov	w11, #0x1               ; =1
    753c:      	cbnz	w11, 0x754c <_stogir.schedule.pack+0x18c>
    7540:      	b	0x756c <_stogir.schedule.pack+0x1ac>
    7544:      	mov	x11, xzr
    7548:      	cbz	w11, 0x756c <_stogir.schedule.pack+0x1ac>
    754c:      	add	x11, x24, w10, sxtw #4
    7550:      	ldr	x12, [x11, #0x8]
    7554:      	str	x8, [x11]
    7558:      	str	x8, [x26, w10, sxtw #3]
    755c:      	add	x8, x12, x8
    7560:      	cmp	x9, x28
    7564:      	b.ge	0x7544 <_stogir.schedule.pack+0x184>
    7568:      	b	0x7530 <_stogir.schedule.pack+0x170>
    756c:      	cmp	x20, #0x1
    7570:      	b.lt	0x75a8 <_stogir.schedule.pack+0x1e8>
    7574:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007574:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    7578:      	add	x0, sp, #0x60
    757c:      	mov	x1, xzr
    7580:      	ldr	x4, [x4]
		0000000000007580:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    7584:      	mov	x2, xzr
    7588:      	mov	x3, x20
    758c:      	mov	w5, #0x4                ; =4
    7590:      	mov	w6, #0x4                ; =4
    7594:      	bl	0x7594 <_stogir.schedule.pack+0x1d4>
		0000000000007594:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    7598:      	cbz	w0, 0x76a4 <_stogir.schedule.pack+0x2e4>
    759c:      	mov	x27, x1
    75a0:      	mov	x28, x20
    75a4:      	b	0x75b0 <_stogir.schedule.pack+0x1f0>
    75a8:      	mov	x27, xzr
    75ac:      	mov	x28, xzr
    75b0:      	lsl	x1, x20, #2
    75b4:      	mov	x0, x27
    75b8:      	bl	0x75b8 <_stogir.schedule.pack+0x1f8>
		00000000000075b8:  ARM64_RELOC_BRANCH26	_bzero
    75bc:      	ldr	x2, [sp]
    75c0:      	mov	x8, xzr
    75c4:      	cmp	xzr, x20
    75c8:      	b.ge	0x75e0 <_stogir.schedule.pack+0x220>
    75cc:      	ldr	w9, [x23, x8, lsl #2]
    75d0:      	add	x8, x8, #0x1
    75d4:      	mov	w10, #0x1               ; =1
    75d8:      	cbnz	w10, 0x75e8 <_stogir.schedule.pack+0x228>
    75dc:      	b	0x7610 <_stogir.schedule.pack+0x250>
    75e0:      	mov	x10, xzr
    75e4:      	cbz	w10, 0x7610 <_stogir.schedule.pack+0x250>
    75e8:      	ldr	x10, [x22]
    75ec:      	sbfiz	x11, x9, #2, #32
    75f0:      	ldrsw	x10, [x10, x11]
    75f4:      	ldr	x11, [x26, x10, lsl #3]
    75f8:      	str	w9, [x27, x11, lsl #2]
    75fc:      	add	x9, x11, #0x1
    7600:      	str	x9, [x26, x10, lsl #3]
    7604:      	cmp	x8, x20
    7608:      	b.ge	0x75e0 <_stogir.schedule.pack+0x220>
    760c:      	b	0x75cc <_stogir.schedule.pack+0x20c>
    7610:      	cbz	x25, 0x7618 <_stogir.schedule.pack+0x258>
    7614:      	str	xzr, [sp, #0x40]
    7618:      	cmp	x2, #0x1
    761c:      	b.lt	0x7640 <_stogir.schedule.pack+0x280>
    7620:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007620:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i64.0
    7624:      	add	x8, sp, #0x38
    7628:      	mov	x1, x26
    762c:      	ldr	x3, [x3]
		000000000000762c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i64.0
    7630:      	add	x0, x8, #0x18
    7634:      	mov	w4, #0x8                ; =8
    7638:      	mov	w5, #0x8                ; =8
    763c:      	bl	0x763c <_stogir.schedule.pack+0x27c>
		000000000000763c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    7640:      	ldr	q0, [sp, #0x10]
    7644:      	ldr	x8, [sp, #0x8]
    7648:      	stp	x24, x21, [x19]
    764c:      	stp	x27, x20, [x19, #0x28]
    7650:      	ldp	x29, x30, [sp, #0xc0]
    7654:      	stur	q0, [x19, #0x18]
    7658:      	ldr	q0, [sp, #0x60]
    765c:      	str	x8, [x19, #0x10]
    7660:      	ldp	x22, x21, [sp, #0xa0]
    7664:      	str	x28, [x19, #0x38]
    7668:      	ldp	x24, x23, [sp, #0x90]
    766c:      	str	q0, [x19, #0x40]
    7670:      	ldp	x20, x19, [sp, #0xb0]
    7674:      	ldp	x26, x25, [sp, #0x80]
    7678:      	ldp	x28, x27, [sp, #0x70]
    767c:      	add	sp, sp, #0xd0
    7680:      	ret
    7684:      	lsl	x1, x21, #4
    7688:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007688:  ARM64_RELOC_PAGE21	l_cstr.213
    768c:      	add	x0, x0, #0x0
		000000000000768c:  ARM64_RELOC_PAGEOFF12	l_cstr.213
    7690:      	bl	0x7690 <_stogir.schedule.pack+0x2d0>
		0000000000007690:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    7694:      	lsl	x1, x25, #3
    7698:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007698:  ARM64_RELOC_PAGE21	l_cstr.205
    769c:      	add	x0, x0, #0x0
		000000000000769c:  ARM64_RELOC_PAGEOFF12	l_cstr.205
    76a0:      	bl	0x76a0 <_stogir.schedule.pack+0x2e0>
		00000000000076a0:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    76a4:      	lsl	x1, x20, #2
    76a8:      	adrp	x0, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000076a8:  ARM64_RELOC_PAGE21	l_cstr.204
    76ac:      	add	x0, x0, #0x0
		00000000000076ac:  ARM64_RELOC_PAGEOFF12	l_cstr.204
    76b0:      	bl	0x76b0 <_stogir.schedule.pack+0x2f0>
		00000000000076b0:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at

00000000000076b4 <_stogir.schedule.release!>:
    76b4:      	stp	x20, x19, [sp, #-0x20]!
    76b8:      	stp	x29, x30, [sp, #0x10]
    76bc:      	add	x29, sp, #0x10
    76c0:      	ldr	x8, [x0, #0x8]
    76c4:      	mov	x19, x0
    76c8:      	cbz	x8, 0x76d0 <_stogir.schedule.release!+0x1c>
    76cc:      	str	xzr, [x19, #0x8]
    76d0:      	ldr	x2, [x19, #0x10]
    76d4:      	cmp	x2, #0x1
    76d8:      	b.lt	0x76f8 <_stogir.schedule.release!+0x44>
    76dc:      	mov	x0, x19
    76e0:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000076e0:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__stogir.schedule.Range.0
    76e4:      	mov	w4, #0x10               ; =16
    76e8:      	ldr	x1, [x0], #0x18
    76ec:      	ldr	x3, [x3]
		00000000000076ec:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__stogir.schedule.Range.0
    76f0:      	mov	w5, #0x8                ; =8
    76f4:      	bl	0x76f4 <_stogir.schedule.release!+0x40>
		00000000000076f4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    76f8:      	ldr	x8, [x19, #0x30]
    76fc:      	stp	xzr, xzr, [x19]
    7700:      	str	xzr, [x19, #0x10]
    7704:      	cbz	x8, 0x770c <_stogir.schedule.release!+0x58>
    7708:      	str	xzr, [x19, #0x30]
    770c:      	ldr	x2, [x19, #0x38]
    7710:      	cmp	x2, #0x1
    7714:      	b.lt	0x7734 <_stogir.schedule.release!+0x80>
    7718:      	adrp	x3, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007718:  ARM64_RELOC_GOT_LOAD_PAGE21	_repl_static.coil.alloc.type-id__i32.0
    771c:      	ldr	x1, [x19, #0x28]
    7720:      	add	x0, x19, #0x40
    7724:      	ldr	x3, [x3]
		0000000000007724:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_repl_static.coil.alloc.type-id__i32.0
    7728:      	mov	w4, #0x4                ; =4
    772c:      	mov	w5, #0x4                ; =4
    7730:      	bl	0x7730 <_stogir.schedule.release!+0x7c>
		0000000000007730:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    7734:      	ldp	x29, x30, [sp, #0x10]
    7738:      	stp	xzr, xzr, [x19, #0x28]
    773c:      	stur	xzr, [x19, #0x38]
    7740:      	ldp	x20, x19, [sp], #0x20
    7744:      	ret

0000000000007748 <_stogir.verify.structure>:
    7748:      	sub	sp, sp, #0x70
    774c:      	ldr	x8, [x1, #0x8]
    7750:      	ldr	x9, [x1, #0x80]
    7754:      	stp	x28, x27, [sp, #0x10]
    7758:      	stp	x26, x25, [sp, #0x20]
    775c:      	cmp	x8, x9
    7760:      	stp	x24, x23, [sp, #0x30]
    7764:      	stp	x22, x21, [sp, #0x40]
    7768:      	stp	x20, x19, [sp, #0x50]
    776c:      	stp	x29, x30, [sp, #0x60]
    7770:      	b.ne	0x7bd4 <_stogir.verify.structure+0x48c>
    7774:      	mov	w9, wzr
    7778:      	adrp	x19, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007778:  ARM64_RELOC_PAGE21	l_str.859
    777c:      	add	x19, x19, #0x0
		000000000000777c:  ARM64_RELOC_PAGEOFF12	l_str.859
    7780:      	mov	w16, #0x1               ; =1
    7784:      	adrp	x6, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007784:  ARM64_RELOC_PAGE21	l_str.868
    7788:      	add	x6, x6, #0x0
		0000000000007788:  ARM64_RELOC_PAGEOFF12	l_str.868
    778c:      	adrp	x20, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000778c:  ARM64_RELOC_PAGE21	l_str.872
    7790:      	add	x20, x20, #0x0
		0000000000007790:  ARM64_RELOC_PAGEOFF12	l_str.872
    7794:      	mov	w24, #0x5e1c            ; =24092
    7798:      	adrp	x26, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007798:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    779c:      	add	x26, x26, #0x0
		000000000000779c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    77a0:      	mov	w27, #0x5               ; =5
    77a4:      	mov	w22, #0x818             ; =2072
    77a8:      	mov	w30, #0x1               ; =1
    77ac:      	b	0x77c4 <_stogir.verify.structure+0x7c>
    77b0:      	add	w9, w9, #0x1
    77b4:      	mov	x30, x10
    77b8:      	mov	x3, x17
    77bc:      	mov	x4, x19
    77c0:      	cbnz	x17, 0x7c3c <_stogir.verify.structure+0x4f4>
    77c4:      	cmp	x30, x8
    77c8:      	b.ge	0x7c14 <_stogir.verify.structure+0x4cc>
    77cc:      	ldr	x11, [x1, #0x78]
    77d0:      	ldr	w13, [x11, x30, lsl #2]
    77d4:      	lsr	w10, w13, #16
    77d8:      	cbnz	w10, 0x7c20 <_stogir.verify.structure+0x4d8>
    77dc:      	ldr	x5, [x1]
    77e0:      	lsl	x10, x30, #4
    77e4:      	ldr	x10, [x5, x10]
    77e8:      	and	w14, w10, #0xff
    77ec:      	cmp	w14, #0x82
    77f0:      	b.hi	0x7c04 <_stogir.verify.structure+0x4bc>
    77f4:      	ubfx	w15, w10, #8, #8
    77f8:      	cmp	w15, #0xe
    77fc:      	b.lo	0x7828 <_stogir.verify.structure+0xe0>
    7800:      	sub	w12, w15, #0x80
    7804:      	cmn	w12, #0x70
    7808:      	b.lo	0x7c04 <_stogir.verify.structure+0x4bc>
    780c:      	ubfx	w12, w10, #8, #4
    7810:      	mov	w3, #0x16               ; =22
    7814:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007814:  ARM64_RELOC_PAGE21	l_str.863
    7818:      	add	x4, x4, #0x0
		0000000000007818:  ARM64_RELOC_PAGEOFF12	l_str.863
    781c:      	sub	w12, w12, #0xe
    7820:      	cmn	w12, #0xd
    7824:      	b.lo	0x7c3c <_stogir.verify.structure+0x4f4>
    7828:      	and	x7, x10, #0xff
    782c:      	adrp	x12, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000782c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.OPERAND-SLOTS
    7830:      	add	x12, x12, #0x0
		0000000000007830:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.OPERAND-SLOTS
    7834:      	ldrsb	w12, [x12, x7]
    7838:      	tbnz	w12, #0x1f, 0x7844 <_stogir.verify.structure+0xfc>
    783c:      	cmp	w13, w12
    7840:      	b.ne	0x7c30 <_stogir.verify.structure+0x4e8>
    7844:      	adrp	x12, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007844:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.INPUT-COUNTS
    7848:      	add	x12, x12, #0x0
		0000000000007848:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.INPUT-COUNTS
    784c:      	add	x17, x13, #0x4
    7850:      	ldrb	w12, [x12, x7]
    7854:      	lsr	w10, w10, #16
    7858:      	lsr	x2, x17, #2
    785c:      	adrp	x17, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		000000000000785c:  ARM64_RELOC_PAGE21	l_str.865
    7860:      	add	x17, x17, #0x0
		0000000000007860:  ARM64_RELOC_PAGEOFF12	l_str.865
    7864:      	cmp	w12, #0xff
    7868:      	mov	w12, #0x24              ; =36
    786c:      	ccmp	w13, w10, #0x4, eq
    7870:      	add	x10, x30, x2
    7874:      	csel	x12, x12, xzr, ne
    7878:      	csel	x3, x17, x19, ne
    787c:      	cmp	x10, x8
    7880:      	mov	w17, #0x15              ; =21
    7884:      	csel	x17, x17, x12, gt
    7888:      	adrp	x12, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007888:  ARM64_RELOC_PAGE21	l_str.866
    788c:      	add	x12, x12, #0x0
		000000000000788c:  ARM64_RELOC_PAGEOFF12	l_str.866
    7890:      	csel	x19, x12, x3, gt
    7894:      	cbnz	x17, 0x78d4 <_stogir.verify.structure+0x18c>
    7898:      	cmp	w13, #0x4
    789c:      	b.lo	0x78d4 <_stogir.verify.structure+0x18c>
    78a0:      	add	x12, x11, x30, lsl #2
    78a4:      	mov	w3, #0x2                ; =2
    78a8:      	add	x17, x12, #0x4
    78ac:      	ldr	w4, [x17], #0x4
    78b0:      	cmn	w4, #0x1
    78b4:      	csel	x19, x19, x6, eq
    78b8:      	b.ne	0x78c8 <_stogir.verify.structure+0x180>
    78bc:      	cmp	x3, x2
    78c0:      	add	x3, x3, #0x1
    78c4:      	b.lo	0x78ac <_stogir.verify.structure+0x164>
    78c8:      	cmn	w4, #0x1
    78cc:      	mov	w12, #0x1b              ; =27
    78d0:      	csel	x17, xzr, x12, eq
    78d4:      	cbnz	x17, 0x77b0 <_stogir.verify.structure+0x68>
    78d8:      	cbz	w13, 0x77b0 <_stogir.verify.structure+0x68>
    78dc:      	cmp	w14, #0x78
    78e0:      	and	x21, x30, #0x7fffffff
    78e4:      	mov	w25, #0x2               ; =2
    78e8:      	ccmp	w15, #0x0, #0x0, eq
    78ec:      	cset	w12, ne
    78f0:      	cmp	w30, #0x1
    78f4:      	ccmp	x8, x21, #0x4, ge
    78f8:      	str	w12, [sp, #0xc]
    78fc:      	cset	w23, le
    7900:      	sub	w15, w25, #0x1
    7904:      	cmp	w15, #0x1
    7908:      	b.lt	0x7930 <_stogir.verify.structure+0x1e8>
    790c:      	cmp	w15, #0x5
    7910:      	ldr	w14, [x26, x7, lsl #2]
    7914:      	csel	w12, w15, w27, lo
    7918:      	lsl	w12, w12, #2
    791c:      	sub	w12, w12, #0x4
    7920:      	lsr	w12, w14, w12
    7924:      	and	w3, w12, #0xf
    7928:      	tbz	w23, #0x0, 0x7938 <_stogir.verify.structure+0x1f0>
    792c:      	b	0x794c <_stogir.verify.structure+0x204>
    7930:      	mov	w3, wzr
    7934:      	tbnz	w23, #0x0, 0x794c <_stogir.verify.structure+0x204>
    7938:      	ldr	w12, [x11, x21, lsl #2]
    793c:      	cmp	w15, w12
    7940:      	ccmp	w15, #0x1, #0x8, ls
    7944:      	ccmp	w12, #0x0, #0x8, ge
    7948:      	b.pl	0x7958 <_stogir.verify.structure+0x210>
    794c:      	mov	x14, xzr
    7950:      	cbnz	w14, 0x7970 <_stogir.verify.structure+0x228>
    7954:      	b	0x7be4 <_stogir.verify.structure+0x49c>
    7958:      	add	w12, w30, w15, lsr #2
    795c:      	and	w14, w15, #0x3
    7960:      	add	x12, x5, w12, uxtw #4
    7964:      	ldr	w2, [x12, w14, uxtw #2]
    7968:      	mov	w14, #0x1               ; =1
    796c:      	cbz	w14, 0x7be4 <_stogir.verify.structure+0x49c>
    7970:      	cmp	w3, #0x2
    7974:      	b.eq	0x7980 <_stogir.verify.structure+0x238>
    7978:      	cmp	w3, #0x9
    797c:      	b.ne	0x79d4 <_stogir.verify.structure+0x28c>
    7980:      	cmp	w2, #0x1
    7984:      	b.lt	0x79ec <_stogir.verify.structure+0x2a4>
    7988:      	and	x14, x2, #0x7fffffff
    798c:      	cmp	x8, x14
    7990:      	b.le	0x7a48 <_stogir.verify.structure+0x300>
    7994:      	ldr	w12, [x11, x14, lsl #2]
    7998:      	tbnz	w12, #0x1f, 0x7a48 <_stogir.verify.structure+0x300>
    799c:      	add	x14, x5, x14, lsl #4
    79a0:      	cbz	x14, 0x7a48 <_stogir.verify.structure+0x300>
    79a4:      	ldrb	w12, [x14]
    79a8:      	mov	w14, #0x1               ; =1
    79ac:      	mov	w4, #0x1                ; =1
    79b0:      	cmp	w12, #0x48
    79b4:      	mov	w12, #0x25              ; =37
    79b8:      	csel	x17, x12, xzr, eq
    79bc:      	adrp	x12, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		00000000000079bc:  ARM64_RELOC_PAGE21	l_str.871
    79c0:      	add	x12, x12, #0x0
		00000000000079c0:  ARM64_RELOC_PAGEOFF12	l_str.871
    79c4:      	csel	x19, x12, x19, eq
    79c8:      	cmp	w3, #0x8
    79cc:      	b.eq	0x7a5c <_stogir.verify.structure+0x314>
    79d0:      	b	0x7a7c <_stogir.verify.structure+0x334>
    79d4:      	mov	w14, wzr
    79d8:      	mov	w4, wzr
    79dc:      	mov	x17, xzr
    79e0:      	cmp	w3, #0x8
    79e4:      	b.eq	0x7a5c <_stogir.verify.structure+0x314>
    79e8:      	b	0x7a7c <_stogir.verify.structure+0x334>
    79ec:      	tbnz	w2, #0x1f, 0x7a04 <_stogir.verify.structure+0x2bc>
    79f0:      	cmp	w3, #0x8
    79f4:      	b.ne	0x7b2c <_stogir.verify.structure+0x3e4>
    79f8:      	mov	w4, wzr
    79fc:      	mov	w14, #0x1               ; =1
    7a00:      	b	0x7a74 <_stogir.verify.structure+0x32c>
    7a04:      	ldr	x14, [x1, #0x30]
    7a08:      	ldr	x12, [x1, #0x58]
    7a0c:      	cmp	x14, x12
    7a10:      	b.ne	0x7a48 <_stogir.verify.structure+0x300>
    7a14:      	sxtw	x17, w2
    7a18:      	cmn	x14, x17
    7a1c:      	b.lt	0x7a48 <_stogir.verify.structure+0x300>
    7a20:      	ldr	x12, [x1, #0x50]
    7a24:      	mvn	x14, x17
    7a28:      	ldr	w12, [x12, x14, lsl #2]
    7a2c:      	cmp	w12, #0x0
    7a30:      	b.le	0x7a48 <_stogir.verify.structure+0x300>
    7a34:      	ldr	x12, [x1, #0x28]
    7a38:      	mvn	w14, w2
    7a3c:      	and	x14, x14, #0x7fffffff
    7a40:      	add	x14, x12, x14, lsl #4
    7a44:      	cbnz	x14, 0x79a4 <_stogir.verify.structure+0x25c>
    7a48:      	mov	w4, wzr
    7a4c:      	mov	x17, xzr
    7a50:      	mov	w14, #0x1               ; =1
    7a54:      	cmp	w3, #0x8
    7a58:      	b.ne	0x7a7c <_stogir.verify.structure+0x334>
    7a5c:      	cmp	w2, #0x1
    7a60:      	b.lt	0x7a74 <_stogir.verify.structure+0x32c>
    7a64:      	ldr	x28, [x1, #0x140]
    7a68:      	and	x12, x2, #0x7fffffff
    7a6c:      	cmp	x28, x12
    7a70:      	b.ge	0x7abc <_stogir.verify.structure+0x374>
    7a74:      	mov	w17, #0x21              ; =33
    7a78:      	mov	x19, x20
    7a7c:      	cmp	w3, #0xf
    7a80:      	b.eq	0x7bc0 <_stogir.verify.structure+0x478>
    7a84:      	lsl	w12, w16, w3
    7a88:      	and	w12, w12, w24
    7a8c:      	cbz	w12, 0x7bc0 <_stogir.verify.structure+0x478>
    7a90:      	tbz	w14, #0x0, 0x7a9c <_stogir.verify.structure+0x354>
    7a94:      	tbz	w4, #0x0, 0x7b38 <_stogir.verify.structure+0x3f0>
    7a98:      	b	0x7bc0 <_stogir.verify.structure+0x478>
    7a9c:      	cmp	w2, #0x1
    7aa0:      	b.lt	0x7b1c <_stogir.verify.structure+0x3d4>
    7aa4:      	and	x12, x2, #0x7fffffff
    7aa8:      	cmp	x8, x12
    7aac:      	b.le	0x7bf4 <_stogir.verify.structure+0x4ac>
    7ab0:      	ldr	w12, [x11, x12, lsl #2]
    7ab4:      	tbz	w12, #0x1f, 0x7bc0 <_stogir.verify.structure+0x478>
    7ab8:      	b	0x7bf4 <_stogir.verify.structure+0x4ac>
    7abc:      	mov	w16, #0x18              ; =24
    7ac0:      	ldr	x28, [x1, #0x138]
    7ac4:      	umaddl	x12, w12, w16, x28
    7ac8:      	mov	x16, x20
    7acc:      	ldr	x20, [x1, #0x118]
    7ad0:      	ldp	x28, x12, [x12, #-0x18]
    7ad4:      	cmp	x28, #0x0
    7ad8:      	cset	w22, mi
    7adc:      	subs	x20, x20, x28
    7ae0:      	csinc	w22, w22, wzr, ge
    7ae4:      	cmp	x12, #0x0
    7ae8:      	csinc	w22, w22, wzr, pl
    7aec:      	cmp	x12, x20
    7af0:      	mov	x20, x16
    7af4:      	csinc	w12, w22, wzr, le
    7af8:      	mov	w16, #0x1               ; =1
    7afc:      	mov	w22, #0x818             ; =2072
    7b00:      	cmp	w12, #0x0
    7b04:      	mov	w12, #0x21              ; =33
    7b08:      	csel	x17, x12, x17, ne
    7b0c:      	csel	x19, x20, x19, ne
    7b10:      	cmp	w3, #0xf
    7b14:      	b.ne	0x7a84 <_stogir.verify.structure+0x33c>
    7b18:      	b	0x7bc0 <_stogir.verify.structure+0x478>
    7b1c:      	tbnz	w2, #0x1f, 0x7b90 <_stogir.verify.structure+0x448>
    7b20:      	cmp	w15, #0x1
    7b24:      	b.ge	0x7b50 <_stogir.verify.structure+0x408>
    7b28:      	b	0x7bf4 <_stogir.verify.structure+0x4ac>
    7b2c:      	lsr	w12, w24, w3
    7b30:      	mov	x17, xzr
    7b34:      	tbz	w12, #0x0, 0x7bc0 <_stogir.verify.structure+0x478>
    7b38:      	cmp	w15, #0x1
    7b3c:      	b.lt	0x7bf4 <_stogir.verify.structure+0x4ac>
    7b40:      	mov	w3, #0x1a               ; =26
    7b44:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007b44:  ARM64_RELOC_PAGE21	l_str.873
    7b48:      	add	x4, x4, #0x0
		0000000000007b48:  ARM64_RELOC_PAGEOFF12	l_str.873
    7b4c:      	cbnz	w2, 0x7c3c <_stogir.verify.structure+0x4f4>
    7b50:      	cmp	w15, #0x5
    7b54:      	ldr	w14, [x26, x7, lsl #2]
    7b58:      	csel	w12, w15, w27, lo
    7b5c:      	lsl	w12, w12, #2
    7b60:      	sub	w12, w12, #0x4
    7b64:      	lsr	w12, w14, w12
    7b68:      	and	w12, w12, #0xf
    7b6c:      	cmp	w12, #0xb
    7b70:      	b.hi	0x7b7c <_stogir.verify.structure+0x434>
    7b74:      	lsr	w12, w22, w12
    7b78:      	tbnz	w12, #0x0, 0x7bc0 <_stogir.verify.structure+0x478>
    7b7c:      	ldr	w12, [sp, #0xc]
    7b80:      	cmp	w25, #0x3
    7b84:      	csinc	w12, w12, wzr, eq
    7b88:      	tbz	w12, #0x0, 0x7bc0 <_stogir.verify.structure+0x478>
    7b8c:      	b	0x7bf4 <_stogir.verify.structure+0x4ac>
    7b90:      	ldr	x12, [x1, #0x30]
    7b94:      	ldr	x14, [x1, #0x58]
    7b98:      	cmp	x12, x14
    7b9c:      	b.ne	0x7bf4 <_stogir.verify.structure+0x4ac>
    7ba0:      	sxtw	x14, w2
    7ba4:      	cmn	x12, x14
    7ba8:      	b.lt	0x7bf4 <_stogir.verify.structure+0x4ac>
    7bac:      	ldr	x12, [x1, #0x50]
    7bb0:      	mvn	x14, x14
    7bb4:      	ldr	w12, [x12, x14, lsl #2]
    7bb8:      	cmp	w12, #0x0
    7bbc:      	b.le	0x7bf4 <_stogir.verify.structure+0x4ac>
    7bc0:      	cbnz	x17, 0x77b0 <_stogir.verify.structure+0x68>
    7bc4:      	cmp	w25, w13
    7bc8:      	add	w25, w25, #0x1
    7bcc:      	b.le	0x7900 <_stogir.verify.structure+0x1b8>
    7bd0:      	b	0x77b0 <_stogir.verify.structure+0x68>
    7bd4:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007bd4:  ARM64_RELOC_PAGE21	l_str.860
    7bd8:      	add	x4, x4, #0x0
		0000000000007bd8:  ARM64_RELOC_PAGEOFF12	l_str.860
    7bdc:      	mov	w3, #0x2c               ; =44
    7be0:      	b	0x7c3c <_stogir.verify.structure+0x4f4>
    7be4:      	mov	w3, #0x17               ; =23
    7be8:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007be8:  ARM64_RELOC_PAGE21	l_str.870
    7bec:      	add	x4, x4, #0x0
		0000000000007bec:  ARM64_RELOC_PAGEOFF12	l_str.870
    7bf0:      	b	0x7c3c <_stogir.verify.structure+0x4f4>
    7bf4:      	mov	w3, #0x1a               ; =26
    7bf8:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007bf8:  ARM64_RELOC_PAGE21	l_str.873
    7bfc:      	add	x4, x4, #0x0
		0000000000007bfc:  ARM64_RELOC_PAGEOFF12	l_str.873
    7c00:      	b	0x7c3c <_stogir.verify.structure+0x4f4>
    7c04:      	mov	w3, #0x16               ; =22
    7c08:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007c08:  ARM64_RELOC_PAGE21	l_str.863
    7c0c:      	add	x4, x4, #0x0
		0000000000007c0c:  ARM64_RELOC_PAGEOFF12	l_str.863
    7c10:      	b	0x7c3c <_stogir.verify.structure+0x4f4>
    7c14:      	str	wzr, [x0]
    7c18:      	str	w9, [x0, #0x8]
    7c1c:      	b	0x7c48 <_stogir.verify.structure+0x500>
    7c20:      	mov	w3, #0x23               ; =35
    7c24:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007c24:  ARM64_RELOC_PAGE21	l_str.862
    7c28:      	add	x4, x4, #0x0
		0000000000007c28:  ARM64_RELOC_PAGEOFF12	l_str.862
    7c2c:      	b	0x7c3c <_stogir.verify.structure+0x4f4>
    7c30:      	mov	w3, #0x23               ; =35
    7c34:      	adrp	x4, 0x7000 <_stogir.pipeline.prepare-checked+0x45cc>
		0000000000007c34:  ARM64_RELOC_PAGE21	l_str.864
    7c38:      	add	x4, x4, #0x0
		0000000000007c38:  ARM64_RELOC_PAGEOFF12	l_str.864
    7c3c:      	mov	w8, #0x1                ; =1
    7c40:      	stp	x4, x3, [x0, #0x8]
    7c44:      	str	w8, [x0]
    7c48:      	ldp	x29, x30, [sp, #0x60]
    7c4c:      	ldp	x20, x19, [sp, #0x50]
    7c50:      	ldp	x22, x21, [sp, #0x40]
    7c54:      	ldp	x24, x23, [sp, #0x30]
    7c58:      	ldp	x26, x25, [sp, #0x20]
    7c5c:      	ldp	x28, x27, [sp, #0x10]
    7c60:      	add	sp, sp, #0x70
    7c64:      	ret
