
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-bitcast-chains/build/bitcast-comparison/prepare-graph/before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_prepare_graph>:
       0:      	sub	sp, sp, #0x2e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x2c0]
      14:      	str	x20, [sp, #0x2c8]
      18:      	str	x21, [sp, #0x2d0]
      1c:      	str	x22, [sp, #0x2d8]
      20:      	add	x16, sp, #0x10
      24:      	orr	x3, x16, xzr
      28:      	add	x16, sp, #0x10
      2c:      	str	w2, [x16]
      30:      	add	x16, sp, #0x20
      34:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000034:  ARM64_RELOC_PAGE21	l_stogir.388
      38:      	ldr	x17, [x17]
		0000000000000038:  ARM64_RELOC_PAGEOFF12	l_stogir.388
      3c:      	str	x17, [x16]
      40:      	add	x16, sp, #0x20
      44:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000044:  ARM64_RELOC_PAGE21	l_stogir.389
      48:      	ldr	x17, [x17]
		0000000000000048:  ARM64_RELOC_PAGEOFF12	l_stogir.389
      4c:      	str	x17, [x16, #0x8]
      50:      	add	x8, sp, #0x30
      54:      	mov	x2, x3
      58:      	add	x4, sp, #0x20
      5c:      	mov	x3, #0x1                ; =1
      60:      	bl	0x60 <_gap_prepare_graph+0x60>
		0000000000000060:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare
      64:      	add	x16, sp, #0x30
      68:      	ldr	w0, [x16]
      6c:      	lsr	x16, x0, #0
      70:      	cmp	x16, #0x1
      74:      	b.eq	0x90 <_gap_prepare_graph+0x90>
      78:      	b.lo	0x80 <_gap_prepare_graph+0x80>
      7c:      	b	0x94 <_gap_prepare_graph+0x94>
      80:      	cmp	x16, #0x0
      84:      	b.eq	0x8c <_gap_prepare_graph+0x8c>
      88:      	b	0x94 <_gap_prepare_graph+0x94>
      8c:      	b	0xa0 <_gap_prepare_graph+0xa0>
      90:      	b	0x98 <_gap_prepare_graph+0x98>
      94:      	b	0x550 <_gap_prepare_graph+0x550>
      98:      	movz	x19, #0x0, lsl #48
      9c:      	b	0x524 <_gap_prepare_graph+0x524>
      a0:      	add	x16, sp, #0x30
      a4:      	orr	x0, x16, xzr
      a8:      	add	x16, sp, #0x180
      ac:      	orr	x1, x16, xzr
      b0:      	add	x0, x0, #0x8
      b4:      	add	x19, x1, #0xa0
      b8:      	add	x20, x19, #0x28
      bc:      	mov	x1, x0
      c0:      	add	x0, sp, #0x180
      c4:      	mov	x2, #0x140              ; =320
      c8:      	bl	0xc8 <_gap_prepare_graph+0xc8>
		00000000000000c8:  ARM64_RELOC_BRANCH26	_memmove
      cc:      	ldr	x0, [x19, #0x28]
      d0:      	ldr	x1, [x20, #0x8]
      d4:      	movz	x19, #0x0, lsl #48
      d8:      	movz	x2, #0x0, lsl #48
      dc:      	b	0x120 <_gap_prepare_graph+0x120>
      e0:      	movz	w3, #0x0, lsl #16
      e4:      	movz	w4, #0x0, lsl #16
      e8:      	ubfx	x3, x3, #0, #32
      ec:      	lsr	x16, x3, #0
      f0:      	cmp	x16, #0x1
      f4:      	b.eq	0x110 <_gap_prepare_graph+0x110>
      f8:      	b.lo	0x100 <_gap_prepare_graph+0x100>
      fc:      	b	0x114 <_gap_prepare_graph+0x114>
     100:      	cmp	x16, #0x0
     104:      	b.eq	0x10c <_gap_prepare_graph+0x10c>
     108:      	b	0x114 <_gap_prepare_graph+0x114>
     10c:      	b	0x148 <_gap_prepare_graph+0x148>
     110:      	b	0x118 <_gap_prepare_graph+0x118>
     114:      	b	0x548 <_gap_prepare_graph+0x548>
     118:      	sxtw	x4, w4
     11c:      	add	x19, x4, x19
     120:      	cmp	x2, x1
     124:      	b.ge	0xe0 <_gap_prepare_graph+0xe0>
     128:      	add	x3, x2, #0x1
     12c:      	add	x2, x0, x2, lsl #2
     130:      	ldr	w2, [x2]
     134:      	movn	w17, #0x0, lsl #16
     138:      	and	w4, w2, w17
     13c:      	mov	x2, x3
     140:      	mov	w3, #0x1                ; =1
     144:      	b	0xe8 <_gap_prepare_graph+0xe8>
     148:      	b	0x15c <_gap_prepare_graph+0x15c>
     14c:      	nop
     150:      	sub	x0, x0, #0x1
     154:      	add	x16, sp, #0x180
     158:      	str	x0, [x16, #0x8]
     15c:      	add	x16, sp, #0x180
     160:      	ldr	x0, [x16, #0x8]
     164:      	cmp	x0, #0x0
     168:      	b.ne	0x150 <_gap_prepare_graph+0x150>
     16c:      	add	x16, sp, #0x180
     170:      	orr	x0, x16, xzr
     174:      	add	x16, sp, #0x180
     178:      	ldr	x1, [x16, #0x10]
     17c:      	cmp	x1, #0x0
     180:      	b.le	0x1b0 <_gap_prepare_graph+0x1b0>
     184:      	add	x0, x0, #0x18
     188:      	add	x16, sp, #0x180
     18c:      	ldr	x2, [x16]
     190:      	fmov	d31, x1
     194:      	mov	x1, x2
     198:      	fmov	x2, d31
     19c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000019c:  ARM64_RELOC_PAGE21	l_stogir.390
     1a0:      	ldr	x3, [x3]
		00000000000001a0:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     1a4:      	mov	x4, #0x4                ; =4
     1a8:      	mov	x5, #0x4                ; =4
     1ac:      	bl	0x1ac <_gap_prepare_graph+0x1ac>
		00000000000001ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     1b0:      	add	x16, sp, #0x180
     1b4:      	orr	x20, x16, xzr
     1b8:      	add	x21, x20, #0x28
     1bc:      	add	x16, sp, #0x180
     1c0:      	movz	x17, #0x0, lsl #48
     1c4:      	str	x17, [x16]
     1c8:      	add	x16, sp, #0x180
     1cc:      	movz	x17, #0x0, lsl #48
     1d0:      	str	x17, [x16, #0x8]
     1d4:      	add	x16, sp, #0x180
     1d8:      	movz	x17, #0x0, lsl #48
     1dc:      	str	x17, [x16, #0x10]
     1e0:      	b	0x1f0 <_gap_prepare_graph+0x1f0>
     1e4:      	nop
     1e8:      	sub	x0, x0, #0x1
     1ec:      	str	x0, [x21, #0x8]
     1f0:      	ldr	x0, [x21, #0x8]
     1f4:      	cmp	x0, #0x0
     1f8:      	b.ne	0x1e8 <_gap_prepare_graph+0x1e8>
     1fc:      	ldr	x0, [x21, #0x10]
     200:      	cmp	x0, #0x0
     204:      	b.le	0x238 <_gap_prepare_graph+0x238>
     208:      	add	x1, x21, #0x18
     20c:      	add	x16, sp, #0x180
     210:      	ldr	x2, [x16, #0x28]
     214:      	fmov	d31, x0
     218:      	mov	x0, x1
     21c:      	mov	x1, x2
     220:      	fmov	x2, d31
     224:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000224:  ARM64_RELOC_PAGE21	l_stogir.390
     228:      	ldr	x3, [x3]
		0000000000000228:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     22c:      	mov	x4, #0x4                ; =4
     230:      	mov	x5, #0x4                ; =4
     234:      	bl	0x234 <_gap_prepare_graph+0x234>
		0000000000000234:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     238:      	add	x20, x20, #0x50
     23c:      	add	x16, sp, #0x180
     240:      	movz	x17, #0x0, lsl #48
     244:      	str	x17, [x16, #0x28]
     248:      	movz	x17, #0x0, lsl #48
     24c:      	str	x17, [x21, #0x8]
     250:      	movz	x17, #0x0, lsl #48
     254:      	str	x17, [x21, #0x10]
     258:      	b	0x268 <_gap_prepare_graph+0x268>
     25c:      	nop
     260:      	sub	x0, x0, #0x1
     264:      	str	x0, [x20, #0x8]
     268:      	ldr	x0, [x20, #0x8]
     26c:      	cmp	x0, #0x0
     270:      	b.ne	0x260 <_gap_prepare_graph+0x260>
     274:      	ldr	x0, [x20, #0x10]
     278:      	cmp	x0, #0x0
     27c:      	b.le	0x2b0 <_gap_prepare_graph+0x2b0>
     280:      	add	x1, x20, #0x18
     284:      	add	x16, sp, #0x180
     288:      	ldr	x2, [x16, #0x50]
     28c:      	fmov	d31, x0
     290:      	mov	x0, x1
     294:      	mov	x1, x2
     298:      	fmov	x2, d31
     29c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000029c:  ARM64_RELOC_PAGE21	l_stogir.391
     2a0:      	ldr	x3, [x3]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	l_stogir.391
     2a4:      	mov	x4, #0x10               ; =16
     2a8:      	mov	x5, #0x4                ; =4
     2ac:      	bl	0x2ac <_gap_prepare_graph+0x2ac>
		00000000000002ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     2b0:      	add	x16, sp, #0x180
     2b4:      	orr	x21, x16, xzr
     2b8:      	add	x22, x21, #0x78
     2bc:      	add	x16, sp, #0x180
     2c0:      	movz	x17, #0x0, lsl #48
     2c4:      	str	x17, [x16, #0x50]
     2c8:      	movz	x17, #0x0, lsl #48
     2cc:      	str	x17, [x20, #0x8]
     2d0:      	movz	x17, #0x0, lsl #48
     2d4:      	str	x17, [x20, #0x10]
     2d8:      	b	0x2e8 <_gap_prepare_graph+0x2e8>
     2dc:      	nop
     2e0:      	sub	x0, x0, #0x1
     2e4:      	str	x0, [x22, #0x8]
     2e8:      	ldr	x0, [x22, #0x8]
     2ec:      	cmp	x0, #0x0
     2f0:      	b.ne	0x2e0 <_gap_prepare_graph+0x2e0>
     2f4:      	ldr	x0, [x22, #0x10]
     2f8:      	cmp	x0, #0x0
     2fc:      	b.le	0x330 <_gap_prepare_graph+0x330>
     300:      	add	x1, x22, #0x18
     304:      	add	x16, sp, #0x180
     308:      	ldr	x2, [x16, #0x78]
     30c:      	fmov	d31, x0
     310:      	mov	x0, x1
     314:      	mov	x1, x2
     318:      	fmov	x2, d31
     31c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000031c:  ARM64_RELOC_PAGE21	l_stogir.390
     320:      	ldr	x3, [x3]
		0000000000000320:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     324:      	mov	x4, #0x4                ; =4
     328:      	mov	x5, #0x4                ; =4
     32c:      	bl	0x32c <_gap_prepare_graph+0x32c>
		000000000000032c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     330:      	add	x20, x21, #0xf0
     334:      	add	x16, sp, #0x180
     338:      	movz	x17, #0x0, lsl #48
     33c:      	str	x17, [x16, #0x78]
     340:      	movz	x17, #0x0, lsl #48
     344:      	str	x17, [x22, #0x8]
     348:      	movz	x17, #0x0, lsl #48
     34c:      	str	x17, [x22, #0x10]
     350:      	b	0x360 <_gap_prepare_graph+0x360>
     354:      	nop
     358:      	sub	x0, x0, #0x1
     35c:      	str	x0, [x20, #0x8]
     360:      	ldr	x0, [x20, #0x8]
     364:      	cmp	x0, #0x0
     368:      	b.ne	0x358 <_gap_prepare_graph+0x358>
     36c:      	ldr	x0, [x20, #0x10]
     370:      	cmp	x0, #0x0
     374:      	b.le	0x3a8 <_gap_prepare_graph+0x3a8>
     378:      	add	x1, x20, #0x18
     37c:      	add	x16, sp, #0x180
     380:      	ldr	x2, [x16, #0xf0]
     384:      	fmov	d31, x0
     388:      	mov	x0, x1
     38c:      	mov	x1, x2
     390:      	fmov	x2, d31
     394:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000394:  ARM64_RELOC_PAGE21	l_stogir.390
     398:      	ldr	x3, [x3]
		0000000000000398:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     39c:      	mov	x4, #0x4                ; =4
     3a0:      	mov	x5, #0x4                ; =4
     3a4:      	bl	0x3a4 <_gap_prepare_graph+0x3a4>
		00000000000003a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     3a8:      	add	x22, x21, #0x118
     3ac:      	add	x16, sp, #0x180
     3b0:      	movz	x17, #0x0, lsl #48
     3b4:      	str	x17, [x16, #0xf0]
     3b8:      	movz	x17, #0x0, lsl #48
     3bc:      	str	x17, [x20, #0x8]
     3c0:      	movz	x17, #0x0, lsl #48
     3c4:      	str	x17, [x20, #0x10]
     3c8:      	b	0x3d8 <_gap_prepare_graph+0x3d8>
     3cc:      	nop
     3d0:      	sub	x0, x0, #0x1
     3d4:      	str	x0, [x22, #0x8]
     3d8:      	ldr	x0, [x22, #0x8]
     3dc:      	cmp	x0, #0x0
     3e0:      	b.ne	0x3d0 <_gap_prepare_graph+0x3d0>
     3e4:      	ldr	x0, [x22, #0x10]
     3e8:      	cmp	x0, #0x0
     3ec:      	b.le	0x420 <_gap_prepare_graph+0x420>
     3f0:      	add	x1, x22, #0x18
     3f4:      	add	x16, sp, #0x180
     3f8:      	ldr	x2, [x16, #0x118]
     3fc:      	fmov	d31, x0
     400:      	mov	x0, x1
     404:      	mov	x1, x2
     408:      	fmov	x2, d31
     40c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000040c:  ARM64_RELOC_PAGE21	l_stogir.390
     410:      	ldr	x3, [x3]
		0000000000000410:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     414:      	mov	x4, #0x4                ; =4
     418:      	mov	x5, #0x4                ; =4
     41c:      	bl	0x41c <_gap_prepare_graph+0x41c>
		000000000000041c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     420:      	add	x20, x21, #0xa0
     424:      	add	x16, sp, #0x180
     428:      	movz	x17, #0x0, lsl #48
     42c:      	str	x17, [x16, #0x118]
     430:      	movz	x17, #0x0, lsl #48
     434:      	str	x17, [x22, #0x8]
     438:      	movz	x17, #0x0, lsl #48
     43c:      	str	x17, [x22, #0x10]
     440:      	b	0x450 <_gap_prepare_graph+0x450>
     444:      	nop
     448:      	sub	x0, x0, #0x1
     44c:      	str	x0, [x20, #0x8]
     450:      	ldr	x0, [x20, #0x8]
     454:      	cmp	x0, #0x0
     458:      	b.ne	0x448 <_gap_prepare_graph+0x448>
     45c:      	ldr	x0, [x20, #0x10]
     460:      	cmp	x0, #0x0
     464:      	b.le	0x498 <_gap_prepare_graph+0x498>
     468:      	add	x1, x20, #0x18
     46c:      	add	x16, sp, #0x180
     470:      	ldr	x2, [x16, #0xa0]
     474:      	fmov	d31, x0
     478:      	mov	x0, x1
     47c:      	mov	x1, x2
     480:      	fmov	x2, d31
     484:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000484:  ARM64_RELOC_PAGE21	l_stogir.392
     488:      	ldr	x3, [x3]
		0000000000000488:  ARM64_RELOC_PAGEOFF12	l_stogir.392
     48c:      	mov	x4, #0x10               ; =16
     490:      	mov	x5, #0x8                ; =8
     494:      	bl	0x494 <_gap_prepare_graph+0x494>
		0000000000000494:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     498:      	add	x21, x20, #0x28
     49c:      	add	x16, sp, #0x180
     4a0:      	movz	x17, #0x0, lsl #48
     4a4:      	str	x17, [x16, #0xa0]
     4a8:      	movz	x17, #0x0, lsl #48
     4ac:      	str	x17, [x20, #0x8]
     4b0:      	movz	x17, #0x0, lsl #48
     4b4:      	str	x17, [x20, #0x10]
     4b8:      	b	0x4c8 <_gap_prepare_graph+0x4c8>
     4bc:      	nop
     4c0:      	sub	x0, x0, #0x1
     4c4:      	str	x0, [x21, #0x8]
     4c8:      	ldr	x0, [x21, #0x8]
     4cc:      	cmp	x0, #0x0
     4d0:      	b.ne	0x4c0 <_gap_prepare_graph+0x4c0>
     4d4:      	ldr	x0, [x21, #0x10]
     4d8:      	cmp	x0, #0x0
     4dc:      	b.le	0x50c <_gap_prepare_graph+0x50c>
     4e0:      	add	x1, x21, #0x18
     4e4:      	ldr	x2, [x20, #0x28]
     4e8:      	fmov	d31, x0
     4ec:      	mov	x0, x1
     4f0:      	mov	x1, x2
     4f4:      	fmov	x2, d31
     4f8:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000004f8:  ARM64_RELOC_PAGE21	l_stogir.390
     4fc:      	ldr	x3, [x3]
		00000000000004fc:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     500:      	mov	x4, #0x4                ; =4
     504:      	mov	x5, #0x4                ; =4
     508:      	bl	0x508 <_gap_prepare_graph+0x508>
		0000000000000508:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     50c:      	movz	x17, #0x0, lsl #48
     510:      	str	x17, [x20, #0x28]
     514:      	movz	x17, #0x0, lsl #48
     518:      	str	x17, [x21, #0x8]
     51c:      	movz	x17, #0x0, lsl #48
     520:      	str	x17, [x21, #0x10]
     524:      	mov	x0, x19
     528:      	ldr	x19, [sp, #0x2c0]
     52c:      	ldr	x20, [sp, #0x2c8]
     530:      	ldr	x21, [sp, #0x2d0]
     534:      	ldr	x22, [sp, #0x2d8]
     538:      	ldr	x29, [sp]
     53c:      	ldr	x30, [sp, #0x8]
     540:      	add	sp, sp, #0x2e0
     544:      	ret
     548:      	brk	#0
     54c:      	b	0x548 <_gap_prepare_graph+0x548>
     550:      	brk	#0
     554:      	b	0x550 <_gap_prepare_graph+0x550>

0000000000000558 <_stogir.pipeline.prepare>:
     558:      	sub	sp, sp, #0x310
     55c:      	str	x29, [sp]
     560:      	str	x30, [sp, #0x8]
     564:      	mov	x29, sp
     568:      	str	x19, [sp, #0x2d0]
     56c:      	str	x20, [sp, #0x2d8]
     570:      	str	x21, [sp, #0x2e0]
     574:      	str	x22, [sp, #0x2e8]
     578:      	str	x23, [sp, #0x2f0]
     57c:      	str	x24, [sp, #0x2f8]
     580:      	str	x25, [sp, #0x300]
     584:      	mov	x19, x8
     588:      	add	x8, sp, #0x10
     58c:      	mov	x20, x0
     590:      	mov	w21, w1
     594:      	mov	x22, x2
     598:      	mov	x23, x3
     59c:      	mov	x24, x4
     5a0:      	bl	0x5a0 <_stogir.pipeline.prepare+0x48>
		00000000000005a0:  ARM64_RELOC_BRANCH26	_stogir.pipeline.validate-input
     5a4:      	add	x16, sp, #0x10
     5a8:      	ldr	w0, [x16]
     5ac:      	lsr	x16, x0, #0
     5b0:      	cmp	x16, #0x1
     5b4:      	b.eq	0x5d0 <_stogir.pipeline.prepare+0x78>
     5b8:      	b.lo	0x5c0 <_stogir.pipeline.prepare+0x68>
     5bc:      	b	0x5d4 <_stogir.pipeline.prepare+0x7c>
     5c0:      	cmp	x16, #0x0
     5c4:      	b.eq	0x5cc <_stogir.pipeline.prepare+0x74>
     5c8:      	b	0x5d4 <_stogir.pipeline.prepare+0x7c>
     5cc:      	b	0x618 <_stogir.pipeline.prepare+0xc0>
     5d0:      	b	0x5d8 <_stogir.pipeline.prepare+0x80>
     5d4:      	b	0x678 <_stogir.pipeline.prepare+0x120>
     5d8:      	add	x16, sp, #0x10
     5dc:      	orr	x0, x16, xzr
     5e0:      	add	x16, sp, #0x30
     5e4:      	orr	x25, x16, xzr
     5e8:      	add	x0, x0, #0x8
     5ec:      	add	x1, x25, #0x8
     5f0:      	add	x16, sp, #0x10
     5f4:      	ldr	x2, [x16, #0x8]
     5f8:      	ldr	x0, [x0, #0x8]
     5fc:      	add	x16, sp, #0x30
     600:      	mov	w17, #0x1               ; =1
     604:      	str	w17, [x16]
     608:      	add	x16, sp, #0x30
     60c:      	str	x2, [x16, #0x8]
     610:      	str	x0, [x1, #0x8]
     614:      	b	0x63c <_stogir.pipeline.prepare+0xe4>
     618:      	add	x16, sp, #0x180
     61c:      	orr	x25, x16, xzr
     620:      	add	x8, sp, #0x180
     624:      	mov	x0, x20
     628:      	mov	w1, w21
     62c:      	mov	x2, x22
     630:      	mov	x3, x23
     634:      	mov	x4, x24
     638:      	bl	0x638 <_stogir.pipeline.prepare+0xe0>
		0000000000000638:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare-checked
     63c:      	mov	x0, x19
     640:      	mov	x1, x25
     644:      	mov	x2, #0x148              ; =328
     648:      	bl	0x648 <_stogir.pipeline.prepare+0xf0>
		0000000000000648:  ARM64_RELOC_BRANCH26	_memmove
     64c:      	ldr	x19, [sp, #0x2d0]
     650:      	ldr	x20, [sp, #0x2d8]
     654:      	ldr	x21, [sp, #0x2e0]
     658:      	ldr	x22, [sp, #0x2e8]
     65c:      	ldr	x23, [sp, #0x2f0]
     660:      	ldr	x24, [sp, #0x2f8]
     664:      	ldr	x25, [sp, #0x300]
     668:      	ldr	x29, [sp]
     66c:      	ldr	x30, [sp, #0x8]
     670:      	add	sp, sp, #0x310
     674:      	ret
     678:      	brk	#0
     67c:      	b	0x678 <_stogir.pipeline.prepare+0x120>

0000000000000680 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32>:
     680:      	ldr	x1, [x0]
     684:      	ldr	x0, [x0, #0x8]
     688:      	str	x1, [x8]
     68c:      	str	x0, [x8, #0x8]
     690:      	movz	x17, #0x0, lsl #48
     694:      	str	x17, [x8, #0x10]
     698:      	ret

000000000000069c <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
     69c:      	sub	sp, sp, #0x10
     6a0:      	mov	x1, sp
     6a4:      	ldr	x2, [x0, #0x10]
     6a8:      	ldr	x3, [x0]
     6ac:      	ldr	x4, [x0, #0x8]
     6b0:      	cmp	x2, x4
     6b4:      	b.ge	0x6d8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x3c>
     6b8:      	add	x4, x2, #0x1
     6bc:      	add	x2, x3, x2, lsl #2
     6c0:      	str	x4, [x0, #0x10]
     6c4:      	ldr	w0, [x2]
     6c8:      	sxtw	x0, w0
     6cc:      	and	x0, x0, #0xffffffff
     6d0:      	mov	x2, #0x1                ; =1
     6d4:      	b	0x6e0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
     6d8:      	movz	x2, #0x0, lsl #48
     6dc:      	movz	x0, #0x0, lsl #48
     6e0:      	str	x2, [x1]
     6e4:      	str	x0, [x1, #0x8]
     6e8:      	ldr	x0, [sp]
     6ec:      	ldr	x1, [sp, #0x8]
     6f0:      	add	sp, sp, #0x10
     6f4:      	ret

00000000000006f8 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate>:
     6f8:      	sub	sp, sp, #0x40
     6fc:      	str	x29, [sp]
     700:      	str	x30, [sp, #0x8]
     704:      	mov	x29, sp
     708:      	str	x19, [sp, #0x20]
     70c:      	str	x20, [sp, #0x28]
     710:      	str	x21, [sp, #0x30]
     714:      	add	x19, x29, #0x10
     718:      	mov	x20, sp
     71c:      	sub	sp, sp, #0x10
     720:      	mov	x21, sp
     724:      	ldr	x0, [x1, #0x18]
     728:      	ldr	x1, [x1, #0x10]
     72c:      	cmp	x0, #0x10
     730:      	b.gt	0x750 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x58>
     734:      	mov	x0, x1
     738:      	bl	0x738 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x40>
		0000000000000738:  ARM64_RELOC_BRANCH26	_malloc
     73c:      	cmp	x0, #0x0
     740:      	b.ne	0x780 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x88>
     744:      	movz	x1, #0x0, lsl #48
     748:      	movz	x0, #0x0, lsl #48
     74c:      	b	0x784 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x8c>
     750:      	movz	x17, #0x0, lsl #48
     754:      	str	x17, [x21]
     758:      	mov	x2, x1
     75c:      	mov	x1, x0
     760:      	mov	x0, x21
     764:      	bl	0x764 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x6c>
		0000000000000764:  ARM64_RELOC_BRANCH26	_posix_memalign
     768:      	sxtw	x0, w0
     76c:      	cmp	x0, #0x0
     770:      	b.ne	0x788 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x90>
     774:      	ldr	x0, [x21]
     778:      	mov	x1, #0x1                ; =1
     77c:      	b	0x790 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     780:      	mov	x1, #0x1                ; =1
     784:      	b	0x790 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     788:      	movz	x1, #0x0, lsl #48
     78c:      	movz	x0, #0x0, lsl #48
     790:      	mov	sp, x20
     794:      	str	x1, [x19]
     798:      	str	x0, [x19, #0x8]
     79c:      	ldr	x0, [x29, #0x10]
     7a0:      	ldr	x1, [x29, #0x18]
     7a4:      	sub	sp, x29, #0x0
     7a8:      	ldr	x19, [sp, #0x20]
     7ac:      	ldr	x20, [sp, #0x28]
     7b0:      	ldr	x21, [sp, #0x30]
     7b4:      	ldr	x29, [sp]
     7b8:      	ldr	x30, [sp, #0x8]
     7bc:      	add	sp, sp, #0x40
     7c0:      	ret

00000000000007c4 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$resize>:
     7c4:      	ldr	x0, [x3, #0x10]
     7c8:      	ldr	x1, [x2, #0x10]
     7cc:      	cmp	x0, x1
     7d0:      	cset	w0, le
     7d4:      	ubfx	x0, x0, #0, #8
     7d8:      	ret

00000000000007dc <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap>:
     7dc:      	sub	sp, sp, #0x30
     7e0:      	str	x29, [sp]
     7e4:      	str	x30, [sp, #0x8]
     7e8:      	mov	x29, sp
     7ec:      	str	x19, [sp, #0x20]
     7f0:      	add	x19, sp, #0x10
     7f4:      	ldr	x0, [x3, #0x18]
     7f8:      	cmp	x0, #0x10
     7fc:      	b.le	0x834 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x58>
     800:      	movz	x1, #0x0, lsl #48
     804:      	movz	x0, #0x0, lsl #48
     808:      	b	0x810 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x34>
     80c:      	mov	x1, #0x1                ; =1
     810:      	str	x1, [x19]
     814:      	str	x0, [x19, #0x8]
     818:      	ldr	x0, [sp, #0x10]
     81c:      	ldr	x1, [sp, #0x18]
     820:      	ldr	x19, [sp, #0x20]
     824:      	ldr	x29, [sp]
     828:      	ldr	x30, [sp, #0x8]
     82c:      	add	sp, sp, #0x30
     830:      	ret
     834:      	ldr	x0, [x3, #0x10]
     838:      	fmov	d31, x0
     83c:      	mov	x0, x1
     840:      	fmov	x1, d31
     844:      	bl	0x844 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x68>
		0000000000000844:  ARM64_RELOC_BRANCH26	_realloc
     848:      	cmp	x0, #0x0
     84c:      	b.ne	0x80c <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x30>
     850:      	movz	x1, #0x0, lsl #48
     854:      	movz	x0, #0x0, lsl #48
     858:      	b	0x810 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x34>

000000000000085c <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate>:
     85c:      	sub	sp, sp, #0x10
     860:      	str	x29, [sp]
     864:      	str	x30, [sp, #0x8]
     868:      	mov	x29, sp
     86c:      	mov	x0, x1
     870:      	bl	0x870 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate+0x14>
		0000000000000870:  ARM64_RELOC_BRANCH26	_free
     874:      	movz	x0, #0x0, lsl #48
     878:      	ldr	x29, [sp]
     87c:      	ldr	x30, [sp, #0x8]
     880:      	add	sp, sp, #0x10
     884:      	ret

0000000000000888 <_stogir.pipeline.validate-input>:
     888:      	sub	sp, sp, #0x40
     88c:      	str	x29, [sp]
     890:      	str	x30, [sp, #0x8]
     894:      	mov	x29, sp
     898:      	str	x19, [sp, #0x30]
     89c:      	mov	x19, x8
     8a0:      	add	x8, sp, #0x10
     8a4:      	bl	0x8a4 <_stogir.pipeline.validate-input+0x1c>
		00000000000008a4:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input
     8a8:      	add	x16, sp, #0x10
     8ac:      	ldr	x0, [x16]
     8b0:      	str	x0, [x19]
     8b4:      	add	x16, sp, #0x10
     8b8:      	ldr	x0, [x16, #0x8]
     8bc:      	str	x0, [x19, #0x8]
     8c0:      	add	x16, sp, #0x10
     8c4:      	ldr	x0, [x16, #0x10]
     8c8:      	str	x0, [x19, #0x10]
     8cc:      	ldr	x19, [sp, #0x30]
     8d0:      	ldr	x29, [sp]
     8d4:      	ldr	x30, [sp, #0x8]
     8d8:      	add	sp, sp, #0x40
     8dc:      	ret

00000000000008e0 <_stogir.pipeline.prepare-checked>:
     8e0:      	sub	sp, sp, #0xfb0
     8e4:      	str	x29, [sp]
     8e8:      	str	x30, [sp, #0x8]
     8ec:      	mov	x29, sp
     8f0:      	str	x19, [sp, #0xf60]
     8f4:      	str	x20, [sp, #0xf68]
     8f8:      	str	x21, [sp, #0xf70]
     8fc:      	str	x22, [sp, #0xf78]
     900:      	str	x23, [sp, #0xf80]
     904:      	str	x24, [sp, #0xf88]
     908:      	str	x25, [sp, #0xf90]
     90c:      	str	x26, [sp, #0xf98]
     910:      	str	x27, [sp, #0xfa0]
     914:      	str	x28, [sp, #0xfa8]
     918:      	sxtw	x5, w1
     91c:      	cmp	x5, #0x0
     920:      	b.gt	0x9a0 <_stogir.pipeline.prepare-checked+0xc0>
     924:      	str	x8, [sp, #0xed8]
     928:      	add	x16, sp, #0x10
     92c:      	orr	x19, x16, xzr
     930:      	add	x16, sp, #0x10
     934:      	mov	w17, #0x1               ; =1
     938:      	str	w17, [x16]
     93c:      	add	x0, x19, #0x8
     940:      	add	x16, sp, #0x10
     944:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000944:  ARM64_RELOC_PAGE21	l_stogir.393
     948:      	ldr	x17, [x17]
		0000000000000948:  ARM64_RELOC_PAGEOFF12	l_stogir.393
     94c:      	str	x17, [x16, #0x8]
     950:      	mov	x17, #0x17              ; =23
     954:      	str	x17, [x0, #0x8]
     958:      	ldr	x0, [sp, #0xed8]
     95c:      	mov	x1, x19
     960:      	mov	x2, #0x148              ; =328
     964:      	bl	0x964 <_stogir.pipeline.prepare-checked+0x84>
		0000000000000964:  ARM64_RELOC_BRANCH26	_memmove
     968:      	ldr	x19, [sp, #0xf60]
     96c:      	ldr	x20, [sp, #0xf68]
     970:      	ldr	x21, [sp, #0xf70]
     974:      	ldr	x22, [sp, #0xf78]
     978:      	ldr	x23, [sp, #0xf80]
     97c:      	ldr	x24, [sp, #0xf88]
     980:      	ldr	x25, [sp, #0xf90]
     984:      	ldr	x26, [sp, #0xf98]
     988:      	ldr	x27, [sp, #0xfa0]
     98c:      	ldr	x28, [sp, #0xfa8]
     990:      	ldr	x29, [sp]
     994:      	ldr	x30, [sp, #0x8]
     998:      	add	sp, sp, #0xfb0
     99c:      	ret
     9a0:      	mov	x19, x8
     9a4:      	mov	x20, x0
     9a8:      	mov	w21, w1
     9ac:      	mov	x22, x2
     9b0:      	mov	x23, x3
     9b4:      	mov	x24, x4
     9b8:      	bl	0x9b8 <_stogir.pipeline.prepare-checked+0xd8>
		00000000000009b8:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
     9bc:      	cmp	x0, #0x0
     9c0:      	b.eq	0x1c40 <_stogir.pipeline.prepare-checked+0x1360>
     9c4:      	add	x16, sp, #0x160
     9c8:      	orr	x25, x16, xzr
     9cc:      	add	x8, sp, #0x160
     9d0:      	mov	x0, x20
     9d4:      	mov	x1, x24
     9d8:      	bl	0x9d8 <_stogir.pipeline.prepare-checked+0xf8>
		00000000000009d8:  ARM64_RELOC_BRANCH26	_stogir.cfg.build
     9dc:      	add	x16, sp, #0x160
     9e0:      	ldr	w0, [x16]
     9e4:      	lsr	x16, x0, #0
     9e8:      	cmp	x16, #0x1
     9ec:      	b.eq	0xa08 <_stogir.pipeline.prepare-checked+0x128>
     9f0:      	b.lo	0x9f8 <_stogir.pipeline.prepare-checked+0x118>
     9f4:      	b	0xa0c <_stogir.pipeline.prepare-checked+0x12c>
     9f8:      	cmp	x16, #0x0
     9fc:      	b.eq	0xa04 <_stogir.pipeline.prepare-checked+0x124>
     a00:      	b	0xa0c <_stogir.pipeline.prepare-checked+0x12c>
     a04:      	b	0xa50 <_stogir.pipeline.prepare-checked+0x170>
     a08:      	b	0xa10 <_stogir.pipeline.prepare-checked+0x130>
     a0c:      	b	0x1908 <_stogir.pipeline.prepare-checked+0x1028>
     a10:      	add	x16, sp, #0x1e0
     a14:      	orr	x20, x16, xzr
     a18:      	add	x0, x25, #0x8
     a1c:      	add	x1, x20, #0x8
     a20:      	add	x16, sp, #0x160
     a24:      	ldr	x2, [x16, #0x8]
     a28:      	ldr	x0, [x0, #0x8]
     a2c:      	add	x16, sp, #0x1e0
     a30:      	mov	w17, #0x1               ; =1
     a34:      	str	w17, [x16]
     a38:      	add	x16, sp, #0x1e0
     a3c:      	str	x2, [x16, #0x8]
     a40:      	str	x0, [x1, #0x8]
     a44:      	str	x19, [sp, #0xed8]
     a48:      	mov	x19, x20
     a4c:      	b	0x958 <_stogir.pipeline.prepare-checked+0x78>
     a50:      	add	x16, sp, #0x760
     a54:      	orr	x26, x16, xzr
     a58:      	add	x0, x25, #0x8
     a5c:      	add	x16, sp, #0x160
     a60:      	ldr	x1, [x16, #0x8]
     a64:      	ldr	x2, [x0, #0x8]
     a68:      	ldr	x3, [x0, #0x10]
     a6c:      	ldr	x4, [x0, #0x18]
     a70:      	ldr	x5, [x0, #0x20]
     a74:      	ldr	x6, [x0, #0x28]
     a78:      	ldr	x7, [x0, #0x30]
     a7c:      	ldr	x8, [x0, #0x38]
     a80:      	ldr	x9, [x0, #0x40]
     a84:      	ldr	x10, [x0, #0x48]
     a88:      	ldr	x11, [x0, #0x50]
     a8c:      	ldr	x12, [x0, #0x58]
     a90:      	ldr	x13, [x0, #0x60]
     a94:      	ldr	x14, [x0, #0x68]
     a98:      	ldr	x0, [x0, #0x70]
     a9c:      	add	x16, sp, #0x330
     aa0:      	str	x1, [x16]
     aa4:      	add	x16, sp, #0x330
     aa8:      	str	x2, [x16, #0x8]
     aac:      	add	x16, sp, #0x330
     ab0:      	str	x3, [x16, #0x10]
     ab4:      	add	x16, sp, #0x330
     ab8:      	str	x4, [x16, #0x18]
     abc:      	add	x16, sp, #0x330
     ac0:      	str	x5, [x16, #0x20]
     ac4:      	add	x16, sp, #0x330
     ac8:      	str	x6, [x16, #0x28]
     acc:      	add	x16, sp, #0x330
     ad0:      	str	x7, [x16, #0x30]
     ad4:      	add	x16, sp, #0x330
     ad8:      	str	x8, [x16, #0x38]
     adc:      	add	x16, sp, #0x330
     ae0:      	str	x9, [x16, #0x40]
     ae4:      	add	x16, sp, #0x330
     ae8:      	str	x10, [x16, #0x48]
     aec:      	add	x16, sp, #0x330
     af0:      	str	x11, [x16, #0x50]
     af4:      	add	x16, sp, #0x330
     af8:      	str	x12, [x16, #0x58]
     afc:      	add	x16, sp, #0x330
     b00:      	str	x13, [x16, #0x60]
     b04:      	add	x16, sp, #0x330
     b08:      	str	x14, [x16, #0x68]
     b0c:      	add	x16, sp, #0x330
     b10:      	str	x0, [x16, #0x70]
     b14:      	add	x8, sp, #0x400
     b18:      	add	x0, sp, #0x330
     b1c:      	mov	x2, x24
     b20:      	mov	x1, #0x1                ; =1
     b24:      	uxtb	w1, w1
     b28:      	bl	0xb28 <_stogir.pipeline.prepare-checked+0x248>
		0000000000000b28:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     b2c:      	add	x16, sp, #0x400
     b30:      	ldr	x0, [x16]
     b34:      	add	x16, sp, #0x3b0
     b38:      	str	x0, [x16]
     b3c:      	add	x16, sp, #0x400
     b40:      	ldr	x0, [x16, #0x8]
     b44:      	add	x16, sp, #0x3b0
     b48:      	str	x0, [x16, #0x8]
     b4c:      	add	x16, sp, #0x400
     b50:      	ldr	x0, [x16, #0x10]
     b54:      	add	x16, sp, #0x3b0
     b58:      	str	x0, [x16, #0x10]
     b5c:      	add	x16, sp, #0x400
     b60:      	ldr	x0, [x16, #0x18]
     b64:      	add	x16, sp, #0x3b0
     b68:      	str	x0, [x16, #0x18]
     b6c:      	add	x16, sp, #0x400
     b70:      	ldr	x0, [x16, #0x20]
     b74:      	add	x16, sp, #0x3b0
     b78:      	str	x0, [x16, #0x20]
     b7c:      	add	x16, sp, #0x400
     b80:      	ldr	x0, [x16, #0x28]
     b84:      	add	x16, sp, #0x3b0
     b88:      	str	x0, [x16, #0x28]
     b8c:      	add	x16, sp, #0x400
     b90:      	ldr	x0, [x16, #0x30]
     b94:      	add	x16, sp, #0x3b0
     b98:      	str	x0, [x16, #0x30]
     b9c:      	add	x16, sp, #0x400
     ba0:      	ldr	x0, [x16, #0x38]
     ba4:      	add	x16, sp, #0x3b0
     ba8:      	str	x0, [x16, #0x38]
     bac:      	add	x16, sp, #0x400
     bb0:      	ldr	x0, [x16, #0x40]
     bb4:      	add	x16, sp, #0x3b0
     bb8:      	str	x0, [x16, #0x40]
     bbc:      	add	x16, sp, #0x400
     bc0:      	ldr	x0, [x16, #0x48]
     bc4:      	add	x16, sp, #0x3b0
     bc8:      	str	x0, [x16, #0x48]
     bcc:      	add	x8, sp, #0x4a0
     bd0:      	add	x0, sp, #0x330
     bd4:      	mov	x2, x24
     bd8:      	movz	x1, #0x0, lsl #48
     bdc:      	uxtb	w1, w1
     be0:      	bl	0xbe0 <_stogir.pipeline.prepare-checked+0x300>
		0000000000000be0:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     be4:      	add	x16, sp, #0x4a0
     be8:      	ldr	x0, [x16]
     bec:      	add	x16, sp, #0x450
     bf0:      	str	x0, [x16]
     bf4:      	add	x16, sp, #0x4a0
     bf8:      	ldr	x0, [x16, #0x8]
     bfc:      	add	x16, sp, #0x450
     c00:      	str	x0, [x16, #0x8]
     c04:      	add	x16, sp, #0x4a0
     c08:      	ldr	x0, [x16, #0x10]
     c0c:      	add	x16, sp, #0x450
     c10:      	str	x0, [x16, #0x10]
     c14:      	add	x16, sp, #0x4a0
     c18:      	ldr	x0, [x16, #0x18]
     c1c:      	add	x16, sp, #0x450
     c20:      	str	x0, [x16, #0x18]
     c24:      	add	x16, sp, #0x4a0
     c28:      	ldr	x0, [x16, #0x20]
     c2c:      	add	x16, sp, #0x450
     c30:      	str	x0, [x16, #0x20]
     c34:      	add	x16, sp, #0x4a0
     c38:      	ldr	x0, [x16, #0x28]
     c3c:      	add	x16, sp, #0x450
     c40:      	str	x0, [x16, #0x28]
     c44:      	add	x16, sp, #0x4a0
     c48:      	ldr	x0, [x16, #0x30]
     c4c:      	add	x16, sp, #0x450
     c50:      	str	x0, [x16, #0x30]
     c54:      	add	x16, sp, #0x4a0
     c58:      	ldr	x0, [x16, #0x38]
     c5c:      	add	x16, sp, #0x450
     c60:      	str	x0, [x16, #0x38]
     c64:      	add	x16, sp, #0x4a0
     c68:      	ldr	x0, [x16, #0x40]
     c6c:      	add	x16, sp, #0x450
     c70:      	str	x0, [x16, #0x40]
     c74:      	add	x16, sp, #0x4a0
     c78:      	ldr	x0, [x16, #0x48]
     c7c:      	add	x16, sp, #0x450
     c80:      	str	x0, [x16, #0x48]
     c84:      	add	x8, sp, #0x520
     c88:      	add	x0, sp, #0x330
     c8c:      	add	x1, sp, #0x450
     c90:      	mov	w2, w21
     c94:      	mov	x3, x24
     c98:      	bl	0xc98 <_stogir.pipeline.prepare-checked+0x3b8>
		0000000000000c98:  ARM64_RELOC_BRANCH26	_stogir.adjacency.reverse-postorder
     c9c:      	add	x16, sp, #0x520
     ca0:      	ldr	x0, [x16]
     ca4:      	add	x16, sp, #0x4f0
     ca8:      	str	x0, [x16]
     cac:      	add	x16, sp, #0x520
     cb0:      	ldr	x0, [x16, #0x8]
     cb4:      	add	x16, sp, #0x4f0
     cb8:      	str	x0, [x16, #0x8]
     cbc:      	add	x16, sp, #0x520
     cc0:      	ldr	x0, [x16, #0x10]
     cc4:      	add	x16, sp, #0x4f0
     cc8:      	str	x0, [x16, #0x10]
     ccc:      	add	x16, sp, #0x520
     cd0:      	ldr	x0, [x16, #0x18]
     cd4:      	add	x16, sp, #0x4f0
     cd8:      	str	x0, [x16, #0x18]
     cdc:      	add	x16, sp, #0x520
     ce0:      	ldr	x0, [x16, #0x20]
     ce4:      	add	x16, sp, #0x4f0
     ce8:      	str	x0, [x16, #0x20]
     cec:      	add	x8, sp, #0x580
     cf0:      	add	x0, sp, #0x330
     cf4:      	add	x1, sp, #0x3b0
     cf8:      	add	x2, sp, #0x4f0
     cfc:      	mov	x3, x24
     d00:      	bl	0xd00 <_stogir.pipeline.prepare-checked+0x420>
		0000000000000d00:  ARM64_RELOC_BRANCH26	_stogir.dominators.build
     d04:      	add	x16, sp, #0x580
     d08:      	ldr	x0, [x16]
     d0c:      	add	x16, sp, #0x550
     d10:      	str	x0, [x16]
     d14:      	add	x16, sp, #0x580
     d18:      	ldr	x0, [x16, #0x8]
     d1c:      	add	x16, sp, #0x550
     d20:      	str	x0, [x16, #0x8]
     d24:      	add	x16, sp, #0x580
     d28:      	ldr	x0, [x16, #0x10]
     d2c:      	add	x16, sp, #0x550
     d30:      	str	x0, [x16, #0x10]
     d34:      	add	x16, sp, #0x580
     d38:      	ldr	x0, [x16, #0x18]
     d3c:      	add	x16, sp, #0x550
     d40:      	str	x0, [x16, #0x18]
     d44:      	add	x16, sp, #0x580
     d48:      	ldr	x0, [x16, #0x20]
     d4c:      	add	x16, sp, #0x550
     d50:      	str	x0, [x16, #0x20]
     d54:      	add	x8, sp, #0x5e0
     d58:      	add	x0, sp, #0x330
     d5c:      	add	x1, sp, #0x3b0
     d60:      	add	x2, sp, #0x550
     d64:      	mov	x3, x24
     d68:      	bl	0xd68 <_stogir.pipeline.prepare-checked+0x488>
		0000000000000d68:  ARM64_RELOC_BRANCH26	_stogir.loops.depths
     d6c:      	add	x16, sp, #0x5e0
     d70:      	ldr	x0, [x16]
     d74:      	add	x16, sp, #0x5b0
     d78:      	str	x0, [x16]
     d7c:      	add	x16, sp, #0x5e0
     d80:      	ldr	x0, [x16, #0x8]
     d84:      	add	x16, sp, #0x5b0
     d88:      	str	x0, [x16, #0x8]
     d8c:      	add	x16, sp, #0x5e0
     d90:      	ldr	x0, [x16, #0x10]
     d94:      	add	x16, sp, #0x5b0
     d98:      	str	x0, [x16, #0x10]
     d9c:      	add	x16, sp, #0x5e0
     da0:      	ldr	x0, [x16, #0x18]
     da4:      	add	x16, sp, #0x5b0
     da8:      	str	x0, [x16, #0x18]
     dac:      	add	x16, sp, #0x5e0
     db0:      	ldr	x0, [x16, #0x20]
     db4:      	add	x16, sp, #0x5b0
     db8:      	str	x0, [x16, #0x20]
     dbc:      	add	x8, sp, #0x640
     dc0:      	mov	x0, x20
     dc4:      	mov	x1, x22
     dc8:      	mov	x2, x23
     dcc:      	mov	x3, x24
     dd0:      	bl	0xdd0 <_stogir.pipeline.prepare-checked+0x4f0>
		0000000000000dd0:  ARM64_RELOC_BRANCH26	_stogir.liveness.mark
     dd4:      	add	x16, sp, #0x640
     dd8:      	ldr	x0, [x16]
     ddc:      	add	x16, sp, #0x610
     de0:      	str	x0, [x16]
     de4:      	add	x16, sp, #0x640
     de8:      	ldr	x0, [x16, #0x8]
     dec:      	add	x16, sp, #0x610
     df0:      	str	x0, [x16, #0x8]
     df4:      	add	x16, sp, #0x640
     df8:      	ldr	x0, [x16, #0x10]
     dfc:      	add	x16, sp, #0x610
     e00:      	str	x0, [x16, #0x10]
     e04:      	add	x16, sp, #0x640
     e08:      	ldr	x0, [x16, #0x18]
     e0c:      	add	x16, sp, #0x610
     e10:      	str	x0, [x16, #0x18]
     e14:      	add	x16, sp, #0x640
     e18:      	ldr	x0, [x16, #0x20]
     e1c:      	add	x16, sp, #0x610
     e20:      	str	x0, [x16, #0x20]
     e24:      	add	x8, sp, #0x6c0
     e28:      	mov	x0, x20
     e2c:      	mov	x1, x24
     e30:      	bl	0xe30 <_stogir.pipeline.prepare-checked+0x550>
		0000000000000e30:  ARM64_RELOC_BRANCH26	_stogir.uses.build
     e34:      	add	x16, sp, #0x6c0
     e38:      	ldr	x0, [x16]
     e3c:      	add	x16, sp, #0x670
     e40:      	str	x0, [x16]
     e44:      	add	x16, sp, #0x6c0
     e48:      	ldr	x0, [x16, #0x8]
     e4c:      	add	x16, sp, #0x670
     e50:      	str	x0, [x16, #0x8]
     e54:      	add	x16, sp, #0x6c0
     e58:      	ldr	x0, [x16, #0x10]
     e5c:      	add	x16, sp, #0x670
     e60:      	str	x0, [x16, #0x10]
     e64:      	add	x16, sp, #0x6c0
     e68:      	ldr	x0, [x16, #0x18]
     e6c:      	add	x16, sp, #0x670
     e70:      	str	x0, [x16, #0x18]
     e74:      	add	x16, sp, #0x6c0
     e78:      	ldr	x0, [x16, #0x20]
     e7c:      	add	x16, sp, #0x670
     e80:      	str	x0, [x16, #0x20]
     e84:      	add	x16, sp, #0x6c0
     e88:      	ldr	x0, [x16, #0x28]
     e8c:      	add	x16, sp, #0x670
     e90:      	str	x0, [x16, #0x28]
     e94:      	add	x16, sp, #0x6c0
     e98:      	ldr	x0, [x16, #0x30]
     e9c:      	add	x16, sp, #0x670
     ea0:      	str	x0, [x16, #0x30]
     ea4:      	add	x16, sp, #0x6c0
     ea8:      	ldr	x0, [x16, #0x38]
     eac:      	add	x16, sp, #0x670
     eb0:      	str	x0, [x16, #0x38]
     eb4:      	add	x16, sp, #0x6c0
     eb8:      	ldr	x0, [x16, #0x40]
     ebc:      	add	x16, sp, #0x670
     ec0:      	str	x0, [x16, #0x40]
     ec4:      	add	x16, sp, #0x6c0
     ec8:      	ldr	x0, [x16, #0x48]
     ecc:      	add	x16, sp, #0x670
     ed0:      	str	x0, [x16, #0x48]
     ed4:      	ldr	x0, [x24]
     ed8:      	ldr	x1, [x24, #0x8]
     edc:      	add	x16, sp, #0x710
     ee0:      	movz	x17, #0x0, lsl #48
     ee4:      	str	x17, [x16]
     ee8:      	add	x16, sp, #0x710
     eec:      	movz	x17, #0x0, lsl #48
     ef0:      	str	x17, [x16, #0x8]
     ef4:      	add	x16, sp, #0x710
     ef8:      	movz	x17, #0x0, lsl #48
     efc:      	str	x17, [x16, #0x10]
     f00:      	add	x16, sp, #0x710
     f04:      	str	x0, [x16, #0x18]
     f08:      	add	x16, sp, #0x710
     f0c:      	str	x1, [x16, #0x20]
     f10:      	add	x16, sp, #0x710
     f14:      	movz	x17, #0x0, lsl #48
     f18:      	str	x17, [x16, #0x28]
     f1c:      	add	x16, sp, #0x710
     f20:      	movz	x17, #0x0, lsl #48
     f24:      	str	x17, [x16, #0x30]
     f28:      	add	x16, sp, #0x710
     f2c:      	movz	x17, #0x0, lsl #48
     f30:      	str	x17, [x16, #0x38]
     f34:      	add	x16, sp, #0x710
     f38:      	str	x0, [x16, #0x40]
     f3c:      	add	x16, sp, #0x710
     f40:      	str	x1, [x16, #0x48]
     f44:      	add	x8, sp, #0x760
     f48:      	mov	x0, x20
     f4c:      	add	x1, sp, #0x330
     f50:      	mov	x2, x24
     f54:      	bl	0xf54 <_stogir.pipeline.prepare-checked+0x674>
		0000000000000f54:  ARM64_RELOC_BRANCH26	_stogir.placement.pinned
     f58:      	add	x16, sp, #0x760
     f5c:      	ldr	w0, [x16]
     f60:      	lsr	x16, x0, #0
     f64:      	cmp	x16, #0x1
     f68:      	b.eq	0xf84 <_stogir.pipeline.prepare-checked+0x6a4>
     f6c:      	b.lo	0xf74 <_stogir.pipeline.prepare-checked+0x694>
     f70:      	b	0xf88 <_stogir.pipeline.prepare-checked+0x6a8>
     f74:      	cmp	x16, #0x0
     f78:      	b.eq	0xf80 <_stogir.pipeline.prepare-checked+0x6a0>
     f7c:      	b	0xf88 <_stogir.pipeline.prepare-checked+0x6a8>
     f80:      	b	0x1424 <_stogir.pipeline.prepare-checked+0xb44>
     f84:      	b	0xf8c <_stogir.pipeline.prepare-checked+0x6ac>
     f88:      	b	0x1c08 <_stogir.pipeline.prepare-checked+0x1328>
     f8c:      	add	x0, x26, #0x8
     f90:      	add	x16, sp, #0x760
     f94:      	ldr	x21, [x16, #0x8]
     f98:      	ldr	x22, [x0, #0x8]
     f9c:      	add	x0, sp, #0x3b0
     fa0:      	bl	0xfa0 <_stogir.pipeline.prepare-checked+0x6c0>
		0000000000000fa0:  ARM64_RELOC_BRANCH26	_stogir.adjacency.release!
     fa4:      	add	x0, sp, #0x450
     fa8:      	bl	0xfa8 <_stogir.pipeline.prepare-checked+0x6c8>
		0000000000000fa8:  ARM64_RELOC_BRANCH26	_stogir.adjacency.release!
     fac:      	b	0xfbc <_stogir.pipeline.prepare-checked+0x6dc>
     fb0:      	sub	x0, x0, #0x1
     fb4:      	add	x16, sp, #0x610
     fb8:      	str	x0, [x16, #0x8]
     fbc:      	add	x16, sp, #0x610
     fc0:      	ldr	x0, [x16, #0x8]
     fc4:      	cmp	x0, #0x0
     fc8:      	b.ne	0xfb0 <_stogir.pipeline.prepare-checked+0x6d0>
     fcc:      	add	x16, sp, #0x610
     fd0:      	orr	x0, x16, xzr
     fd4:      	add	x16, sp, #0x610
     fd8:      	ldr	x1, [x16, #0x10]
     fdc:      	cmp	x1, #0x0
     fe0:      	b.le	0x1010 <_stogir.pipeline.prepare-checked+0x730>
     fe4:      	add	x0, x0, #0x18
     fe8:      	add	x16, sp, #0x610
     fec:      	ldr	x2, [x16]
     ff0:      	fmov	d31, x1
     ff4:      	mov	x1, x2
     ff8:      	fmov	x2, d31
     ffc:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000ffc:  ARM64_RELOC_PAGE21	l_stogir.394
    1000:      	ldr	x3, [x3]
		0000000000001000:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    1004:      	mov	x4, #0x1                ; =1
    1008:      	mov	x5, #0x1                ; =1
    100c:      	bl	0x100c <_stogir.pipeline.prepare-checked+0x72c>
		000000000000100c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1010:      	add	x16, sp, #0x610
    1014:      	movz	x17, #0x0, lsl #48
    1018:      	str	x17, [x16]
    101c:      	add	x16, sp, #0x610
    1020:      	movz	x17, #0x0, lsl #48
    1024:      	str	x17, [x16, #0x8]
    1028:      	add	x16, sp, #0x610
    102c:      	movz	x17, #0x0, lsl #48
    1030:      	str	x17, [x16, #0x10]
    1034:      	add	x0, sp, #0x670
    1038:      	bl	0x1038 <_stogir.pipeline.prepare-checked+0x758>
		0000000000001038:  ARM64_RELOC_BRANCH26	_stogir.uses.release!
    103c:      	cmp	x22, #0x0
    1040:      	b.ne	0x1c48 <_stogir.pipeline.prepare-checked+0x1368>
    1044:      	add	x16, sp, #0xa60
    1048:      	orr	x20, x16, xzr
    104c:      	add	x16, sp, #0xbb0
    1050:      	orr	x0, x16, xzr
    1054:      	add	x16, sp, #0xa60
    1058:      	movz	w17, #0x0, lsl #16
    105c:      	str	w17, [x16]
    1060:      	add	x1, x20, #0x8
    1064:      	add	x21, x0, #0x78
    1068:      	add	x22, x0, #0xa0
    106c:      	add	x23, x0, #0xf0
    1070:      	add	x24, x0, #0x118
    1074:      	add	x16, sp, #0x550
    1078:      	ldr	x25, [x16]
    107c:      	orr	x26, x1, xzr
    1080:      	add	x16, sp, #0x550
    1084:      	ldr	x27, [x16, #0x8]
    1088:      	add	x16, sp, #0x550
    108c:      	ldr	x28, [x16, #0x10]
    1090:      	add	x16, sp, #0x550
    1094:      	ldr	x0, [x16, #0x18]
    1098:      	add	x16, sp, #0x550
    109c:      	ldr	x1, [x16, #0x20]
    10a0:      	add	x16, sp, #0x5b0
    10a4:      	ldr	x2, [x16]
    10a8:      	add	x16, sp, #0x5b0
    10ac:      	ldr	x3, [x16, #0x8]
    10b0:      	add	x16, sp, #0x5b0
    10b4:      	ldr	x4, [x16, #0x10]
    10b8:      	add	x16, sp, #0x5b0
    10bc:      	ldr	x5, [x16, #0x18]
    10c0:      	add	x16, sp, #0x5b0
    10c4:      	ldr	x6, [x16, #0x20]
    10c8:      	add	x16, sp, #0x330
    10cc:      	ldr	x7, [x16]
    10d0:      	add	x16, sp, #0x330
    10d4:      	ldr	x8, [x16, #0x8]
    10d8:      	add	x16, sp, #0x330
    10dc:      	ldr	x9, [x16, #0x10]
    10e0:      	add	x16, sp, #0x330
    10e4:      	ldr	x10, [x16, #0x18]
    10e8:      	add	x16, sp, #0x330
    10ec:      	ldr	x11, [x16, #0x20]
    10f0:      	add	x16, sp, #0x330
    10f4:      	ldr	x12, [x16, #0x28]
    10f8:      	add	x16, sp, #0x330
    10fc:      	ldr	x13, [x16, #0x30]
    1100:      	add	x16, sp, #0x330
    1104:      	ldr	x14, [x16, #0x38]
    1108:      	add	x16, sp, #0x330
    110c:      	ldr	x15, [x16, #0x40]
    1110:      	str	x0, [sp, #0xe30]
    1114:      	add	x16, sp, #0x330
    1118:      	ldr	x0, [x16, #0x48]
    111c:      	str	x0, [sp, #0xe38]
    1120:      	add	x16, sp, #0x330
    1124:      	ldr	x0, [x16, #0x50]
    1128:      	str	x0, [sp, #0xe40]
    112c:      	add	x16, sp, #0x330
    1130:      	ldr	x0, [x16, #0x58]
    1134:      	str	x0, [sp, #0xe48]
    1138:      	add	x16, sp, #0x330
    113c:      	ldr	x0, [x16, #0x60]
    1140:      	str	x0, [sp, #0xe50]
    1144:      	add	x16, sp, #0x330
    1148:      	ldr	x0, [x16, #0x68]
    114c:      	str	x0, [sp, #0xe58]
    1150:      	add	x16, sp, #0x330
    1154:      	ldr	x0, [x16, #0x70]
    1158:      	str	x0, [sp, #0xe60]
    115c:      	add	x16, sp, #0x4f0
    1160:      	ldr	x0, [x16]
    1164:      	str	x0, [sp, #0xe68]
    1168:      	add	x16, sp, #0x4f0
    116c:      	ldr	x0, [x16, #0x8]
    1170:      	str	x0, [sp, #0xe70]
    1174:      	add	x16, sp, #0x4f0
    1178:      	ldr	x0, [x16, #0x10]
    117c:      	str	x0, [sp, #0xe78]
    1180:      	add	x16, sp, #0x4f0
    1184:      	ldr	x0, [x16, #0x18]
    1188:      	str	x0, [sp, #0xe80]
    118c:      	add	x16, sp, #0x4f0
    1190:      	ldr	x0, [x16, #0x20]
    1194:      	str	x0, [sp, #0xe88]
    1198:      	add	x16, sp, #0x710
    119c:      	ldr	x0, [x16]
    11a0:      	str	x0, [sp, #0xe90]
    11a4:      	add	x16, sp, #0x710
    11a8:      	ldr	x0, [x16, #0x8]
    11ac:      	str	x0, [sp, #0xe98]
    11b0:      	add	x16, sp, #0x710
    11b4:      	ldr	x0, [x16, #0x10]
    11b8:      	str	x0, [sp, #0xea0]
    11bc:      	add	x16, sp, #0x710
    11c0:      	ldr	x0, [x16, #0x18]
    11c4:      	str	x0, [sp, #0xea8]
    11c8:      	add	x16, sp, #0x710
    11cc:      	ldr	x0, [x16, #0x20]
    11d0:      	str	x0, [sp, #0xeb0]
    11d4:      	add	x16, sp, #0x710
    11d8:      	ldr	x0, [x16, #0x28]
    11dc:      	str	x0, [sp, #0xeb8]
    11e0:      	add	x16, sp, #0x710
    11e4:      	ldr	x0, [x16, #0x30]
    11e8:      	str	x0, [sp, #0xec0]
    11ec:      	add	x16, sp, #0x710
    11f0:      	ldr	x0, [x16, #0x38]
    11f4:      	str	x0, [sp, #0xec8]
    11f8:      	add	x16, sp, #0x710
    11fc:      	ldr	x0, [x16, #0x40]
    1200:      	str	x0, [sp, #0xed0]
    1204:      	add	x16, sp, #0x710
    1208:      	ldr	x0, [x16, #0x48]
    120c:      	str	x1, [sp, #0xf20]
    1210:      	str	x2, [sp, #0xf18]
    1214:      	str	x3, [sp, #0xef0]
    1218:      	str	x4, [sp, #0xef8]
    121c:      	str	x5, [sp, #0xf00]
    1220:      	str	x6, [sp, #0xf08]
    1224:      	str	x0, [sp, #0xf58]
    1228:      	add	x0, sp, #0xbb0
    122c:      	str	x19, [sp, #0xed8]
    1230:      	mov	x19, x10
    1234:      	str	x26, [sp, #0xee0]
    1238:      	mov	x26, x9
    123c:      	str	x20, [sp, #0xee8]
    1240:      	mov	x20, x8
    1244:      	str	x24, [sp, #0xf10]
    1248:      	mov	x24, x7
    124c:      	str	x28, [sp, #0xf28]
    1250:      	mov	x28, x11
    1254:      	str	x23, [sp, #0xf30]
    1258:      	mov	x23, x12
    125c:      	str	x27, [sp, #0xf38]
    1260:      	mov	x27, x13
    1264:      	str	x25, [sp, #0xf40]
    1268:      	mov	x25, x14
    126c:      	str	x22, [sp, #0xf48]
    1270:      	mov	x22, x15
    1274:      	str	x21, [sp, #0xf50]
    1278:      	ldr	x21, [sp, #0xe38]
    127c:      	movz	x1, #0x0, lsl #48
    1280:      	mov	x2, #0x140              ; =320
    1284:      	bl	0x1284 <_stogir.pipeline.prepare-checked+0x9a4>
		0000000000001284:  ARM64_RELOC_BRANCH26	_memset
    1288:      	add	x16, sp, #0xbb0
    128c:      	str	x24, [x16]
    1290:      	add	x16, sp, #0xbb0
    1294:      	str	x20, [x16, #0x8]
    1298:      	add	x16, sp, #0xbb0
    129c:      	str	x26, [x16, #0x10]
    12a0:      	add	x16, sp, #0xbb0
    12a4:      	str	x19, [x16, #0x18]
    12a8:      	add	x16, sp, #0xbb0
    12ac:      	str	x28, [x16, #0x20]
    12b0:      	add	x16, sp, #0xbb0
    12b4:      	str	x23, [x16, #0x28]
    12b8:      	add	x16, sp, #0xbb0
    12bc:      	str	x27, [x16, #0x30]
    12c0:      	add	x16, sp, #0xbb0
    12c4:      	str	x25, [x16, #0x38]
    12c8:      	add	x16, sp, #0xbb0
    12cc:      	str	x22, [x16, #0x40]
    12d0:      	add	x16, sp, #0xbb0
    12d4:      	str	x21, [x16, #0x48]
    12d8:      	ldr	x0, [sp, #0xe40]
    12dc:      	add	x16, sp, #0xbb0
    12e0:      	str	x0, [x16, #0x50]
    12e4:      	ldr	x0, [sp, #0xe48]
    12e8:      	add	x16, sp, #0xbb0
    12ec:      	str	x0, [x16, #0x58]
    12f0:      	ldr	x0, [sp, #0xe50]
    12f4:      	add	x16, sp, #0xbb0
    12f8:      	str	x0, [x16, #0x60]
    12fc:      	ldr	x0, [sp, #0xe58]
    1300:      	add	x16, sp, #0xbb0
    1304:      	str	x0, [x16, #0x68]
    1308:      	ldr	x0, [sp, #0xe60]
    130c:      	add	x16, sp, #0xbb0
    1310:      	str	x0, [x16, #0x70]
    1314:      	ldr	x0, [sp, #0xe68]
    1318:      	add	x16, sp, #0xbb0
    131c:      	str	x0, [x16, #0x78]
    1320:      	ldr	x0, [sp, #0xf50]
    1324:      	ldr	x1, [sp, #0xe70]
    1328:      	str	x1, [x0, #0x8]
    132c:      	ldr	x1, [sp, #0xe78]
    1330:      	str	x1, [x0, #0x10]
    1334:      	ldr	x1, [sp, #0xe80]
    1338:      	str	x1, [x0, #0x18]
    133c:      	ldr	x1, [sp, #0xe88]
    1340:      	str	x1, [x0, #0x20]
    1344:      	ldr	x0, [sp, #0xe90]
    1348:      	add	x16, sp, #0xbb0
    134c:      	str	x0, [x16, #0xa0]
    1350:      	ldr	x0, [sp, #0xf48]
    1354:      	ldr	x1, [sp, #0xe98]
    1358:      	str	x1, [x0, #0x8]
    135c:      	ldr	x1, [sp, #0xea0]
    1360:      	str	x1, [x0, #0x10]
    1364:      	ldr	x1, [sp, #0xea8]
    1368:      	str	x1, [x0, #0x18]
    136c:      	ldr	x1, [sp, #0xeb0]
    1370:      	str	x1, [x0, #0x20]
    1374:      	ldr	x1, [sp, #0xeb8]
    1378:      	str	x1, [x0, #0x28]
    137c:      	ldr	x1, [sp, #0xec0]
    1380:      	str	x1, [x0, #0x30]
    1384:      	ldr	x1, [sp, #0xec8]
    1388:      	str	x1, [x0, #0x38]
    138c:      	ldr	x1, [sp, #0xed0]
    1390:      	str	x1, [x0, #0x40]
    1394:      	ldr	x1, [sp, #0xf58]
    1398:      	str	x1, [x0, #0x48]
    139c:      	ldr	x0, [sp, #0xf40]
    13a0:      	add	x16, sp, #0xbb0
    13a4:      	str	x0, [x16, #0xf0]
    13a8:      	ldr	x0, [sp, #0xf30]
    13ac:      	ldr	x1, [sp, #0xf38]
    13b0:      	str	x1, [x0, #0x8]
    13b4:      	ldr	x1, [sp, #0xf28]
    13b8:      	str	x1, [x0, #0x10]
    13bc:      	ldr	x1, [sp, #0xe30]
    13c0:      	str	x1, [x0, #0x18]
    13c4:      	ldr	x1, [sp, #0xf20]
    13c8:      	str	x1, [x0, #0x20]
    13cc:      	ldr	x0, [sp, #0xf18]
    13d0:      	add	x16, sp, #0xbb0
    13d4:      	str	x0, [x16, #0x118]
    13d8:      	ldr	x0, [sp, #0xef0]
    13dc:      	ldr	x1, [sp, #0xf10]
    13e0:      	str	x0, [x1, #0x8]
    13e4:      	ldr	x0, [sp, #0xef8]
    13e8:      	str	x0, [x1, #0x10]
    13ec:      	ldr	x0, [sp, #0xf00]
    13f0:      	str	x0, [x1, #0x18]
    13f4:      	ldr	x0, [sp, #0xf08]
    13f8:      	str	x0, [x1, #0x20]
    13fc:      	add	x0, sp, #0xcf0
    1400:      	add	x1, sp, #0xbb0
    1404:      	mov	x2, #0x140              ; =320
    1408:      	bl	0x1408 <_stogir.pipeline.prepare-checked+0xb28>
		0000000000001408:  ARM64_RELOC_BRANCH26	_memmove
    140c:      	ldr	x0, [sp, #0xee0]
    1410:      	add	x1, sp, #0xcf0
    1414:      	mov	x2, #0x140              ; =320
    1418:      	bl	0x1418 <_stogir.pipeline.prepare-checked+0xb38>
		0000000000001418:  ARM64_RELOC_BRANCH26	_memmove
    141c:      	ldr	x19, [sp, #0xee8]
    1420:      	b	0xa4c <_stogir.pipeline.prepare-checked+0x16c>
    1424:      	add	x0, x26, #0x8
    1428:      	add	x16, sp, #0x760
    142c:      	ldr	x1, [x16, #0x8]
    1430:      	ldr	x2, [x0, #0x8]
    1434:      	ldr	x3, [x0, #0x10]
    1438:      	ldr	x4, [x0, #0x18]
    143c:      	ldr	x0, [x0, #0x20]
    1440:      	add	x16, sp, #0x790
    1444:      	str	x1, [x16]
    1448:      	add	x16, sp, #0x790
    144c:      	str	x2, [x16, #0x8]
    1450:      	add	x16, sp, #0x790
    1454:      	str	x3, [x16, #0x10]
    1458:      	add	x16, sp, #0x790
    145c:      	str	x4, [x16, #0x18]
    1460:      	add	x16, sp, #0x790
    1464:      	str	x0, [x16, #0x20]
    1468:      	add	x8, sp, #0x7c0
    146c:      	mov	x0, x20
    1470:      	add	x1, sp, #0x790
    1474:      	add	x2, sp, #0x550
    1478:      	mov	w3, w21
    147c:      	add	x4, sp, #0x670
    1480:      	mov	x5, x24
    1484:      	bl	0x1484 <_stogir.pipeline.prepare-checked+0xba4>
		0000000000001484:  ARM64_RELOC_BRANCH26	_stogir.placement.early-with-uses!
    1488:      	add	x16, sp, #0x7c0
    148c:      	ldr	w0, [x16]
    1490:      	lsr	x16, x0, #0
    1494:      	cmp	x16, #0x1
    1498:      	b.eq	0x14b4 <_stogir.pipeline.prepare-checked+0xbd4>
    149c:      	b.lo	0x14a4 <_stogir.pipeline.prepare-checked+0xbc4>
    14a0:      	b	0x14b8 <_stogir.pipeline.prepare-checked+0xbd8>
    14a4:      	cmp	x16, #0x0
    14a8:      	b.eq	0x14b0 <_stogir.pipeline.prepare-checked+0xbd0>
    14ac:      	b	0x14b8 <_stogir.pipeline.prepare-checked+0xbd8>
    14b0:      	b	0x16ac <_stogir.pipeline.prepare-checked+0xdcc>
    14b4:      	b	0x14bc <_stogir.pipeline.prepare-checked+0xbdc>
    14b8:      	b	0x1c10 <_stogir.pipeline.prepare-checked+0x1330>
    14bc:      	add	x16, sp, #0x7c0
    14c0:      	orr	x0, x16, xzr
    14c4:      	add	x0, x0, #0x8
    14c8:      	add	x16, sp, #0x7c0
    14cc:      	ldr	x21, [x16, #0x8]
    14d0:      	ldr	x22, [x0, #0x8]
    14d4:      	b	0x16b8 <_stogir.pipeline.prepare-checked+0xdd8>
    14d8:      	sub	x0, x0, #0x1
    14dc:      	add	x16, sp, #0x4f0
    14e0:      	str	x0, [x16, #0x8]
    14e4:      	add	x16, sp, #0x4f0
    14e8:      	ldr	x0, [x16, #0x8]
    14ec:      	cmp	x0, #0x0
    14f0:      	b.ne	0x14d8 <_stogir.pipeline.prepare-checked+0xbf8>
    14f4:      	add	x16, sp, #0x4f0
    14f8:      	orr	x0, x16, xzr
    14fc:      	add	x16, sp, #0x4f0
    1500:      	ldr	x1, [x16, #0x10]
    1504:      	cmp	x1, #0x0
    1508:      	b.le	0x1538 <_stogir.pipeline.prepare-checked+0xc58>
    150c:      	add	x0, x0, #0x18
    1510:      	add	x16, sp, #0x4f0
    1514:      	ldr	x2, [x16]
    1518:      	fmov	d31, x1
    151c:      	mov	x1, x2
    1520:      	fmov	x2, d31
    1524:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001524:  ARM64_RELOC_PAGE21	l_stogir.395
    1528:      	ldr	x3, [x3]
		0000000000001528:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    152c:      	mov	x4, #0x4                ; =4
    1530:      	mov	x5, #0x4                ; =4
    1534:      	bl	0x1534 <_stogir.pipeline.prepare-checked+0xc54>
		0000000000001534:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1538:      	add	x16, sp, #0x910
    153c:      	orr	x19, x16, xzr
    1540:      	add	x20, x19, #0x8
    1544:      	add	x16, sp, #0x4f0
    1548:      	movz	x17, #0x0, lsl #48
    154c:      	str	x17, [x16]
    1550:      	add	x16, sp, #0x4f0
    1554:      	movz	x17, #0x0, lsl #48
    1558:      	str	x17, [x16, #0x8]
    155c:      	add	x16, sp, #0x4f0
    1560:      	movz	x17, #0x0, lsl #48
    1564:      	str	x17, [x16, #0x10]
    1568:      	add	x0, sp, #0x710
    156c:      	bl	0x156c <_stogir.pipeline.prepare-checked+0xc8c>
		000000000000156c:  ARM64_RELOC_BRANCH26	_stogir.schedule.release!
    1570:      	add	x16, sp, #0x910
    1574:      	mov	w17, #0x1               ; =1
    1578:      	str	w17, [x16]
    157c:      	add	x16, sp, #0x910
    1580:      	str	x21, [x16, #0x8]
    1584:      	str	x22, [x20, #0x8]
    1588:      	b	0x1420 <_stogir.pipeline.prepare-checked+0xb40>
    158c:      	nop
    1590:      	sub	x0, x0, #0x1
    1594:      	add	x16, sp, #0x5b0
    1598:      	str	x0, [x16, #0x8]
    159c:      	add	x16, sp, #0x5b0
    15a0:      	ldr	x0, [x16, #0x8]
    15a4:      	cmp	x0, #0x0
    15a8:      	b.ne	0x1590 <_stogir.pipeline.prepare-checked+0xcb0>
    15ac:      	add	x16, sp, #0x5b0
    15b0:      	orr	x0, x16, xzr
    15b4:      	add	x16, sp, #0x5b0
    15b8:      	ldr	x1, [x16, #0x10]
    15bc:      	cmp	x1, #0x0
    15c0:      	b.le	0x15f0 <_stogir.pipeline.prepare-checked+0xd10>
    15c4:      	add	x0, x0, #0x18
    15c8:      	add	x16, sp, #0x5b0
    15cc:      	ldr	x2, [x16]
    15d0:      	fmov	d31, x1
    15d4:      	mov	x1, x2
    15d8:      	fmov	x2, d31
    15dc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		00000000000015dc:  ARM64_RELOC_PAGE21	l_stogir.395
    15e0:      	ldr	x3, [x3]
		00000000000015e0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    15e4:      	mov	x4, #0x4                ; =4
    15e8:      	mov	x5, #0x4                ; =4
    15ec:      	bl	0x15ec <_stogir.pipeline.prepare-checked+0xd0c>
		00000000000015ec:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    15f0:      	add	x16, sp, #0x5b0
    15f4:      	movz	x17, #0x0, lsl #48
    15f8:      	str	x17, [x16]
    15fc:      	add	x16, sp, #0x5b0
    1600:      	movz	x17, #0x0, lsl #48
    1604:      	str	x17, [x16, #0x8]
    1608:      	add	x16, sp, #0x5b0
    160c:      	movz	x17, #0x0, lsl #48
    1610:      	str	x17, [x16, #0x10]
    1614:      	add	x0, sp, #0x330
    1618:      	bl	0x1618 <_stogir.pipeline.prepare-checked+0xd38>
		0000000000001618:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    161c:      	b	0x14e4 <_stogir.pipeline.prepare-checked+0xc04>
    1620:      	sub	x0, x0, #0x1
    1624:      	add	x16, sp, #0x550
    1628:      	str	x0, [x16, #0x8]
    162c:      	add	x16, sp, #0x550
    1630:      	ldr	x0, [x16, #0x8]
    1634:      	cmp	x0, #0x0
    1638:      	b.ne	0x1620 <_stogir.pipeline.prepare-checked+0xd40>
    163c:      	add	x16, sp, #0x550
    1640:      	orr	x0, x16, xzr
    1644:      	add	x16, sp, #0x550
    1648:      	ldr	x1, [x16, #0x10]
    164c:      	cmp	x1, #0x0
    1650:      	b.le	0x1680 <_stogir.pipeline.prepare-checked+0xda0>
    1654:      	add	x0, x0, #0x18
    1658:      	add	x16, sp, #0x550
    165c:      	ldr	x2, [x16]
    1660:      	fmov	d31, x1
    1664:      	mov	x1, x2
    1668:      	fmov	x2, d31
    166c:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		000000000000166c:  ARM64_RELOC_PAGE21	l_stogir.395
    1670:      	ldr	x3, [x3]
		0000000000001670:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1674:      	mov	x4, #0x4                ; =4
    1678:      	mov	x5, #0x4                ; =4
    167c:      	bl	0x167c <_stogir.pipeline.prepare-checked+0xd9c>
		000000000000167c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1680:      	add	x16, sp, #0x550
    1684:      	movz	x17, #0x0, lsl #48
    1688:      	str	x17, [x16]
    168c:      	add	x16, sp, #0x550
    1690:      	movz	x17, #0x0, lsl #48
    1694:      	str	x17, [x16, #0x8]
    1698:      	add	x16, sp, #0x550
    169c:      	movz	x17, #0x0, lsl #48
    16a0:      	str	x17, [x16, #0x10]
    16a4:      	b	0x159c <_stogir.pipeline.prepare-checked+0xcbc>
    16a8:      	b	0x162c <_stogir.pipeline.prepare-checked+0xd4c>
    16ac:      	adrp	x21, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		00000000000016ac:  ARM64_RELOC_PAGE21	l_stogir.396
    16b0:      	ldr	x21, [x21]
		00000000000016b0:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    16b4:      	movz	x22, #0x0, lsl #48
    16b8:      	cmp	x22, #0x0
    16bc:      	b.ne	0x1730 <_stogir.pipeline.prepare-checked+0xe50>
    16c0:      	add	x8, sp, #0x7e0
    16c4:      	mov	x0, x20
    16c8:      	add	x1, sp, #0x790
    16cc:      	add	x2, sp, #0x550
    16d0:      	add	x3, sp, #0x5b0
    16d4:      	add	x4, sp, #0x610
    16d8:      	add	x5, sp, #0x670
    16dc:      	mov	x6, x24
    16e0:      	bl	0x16e0 <_stogir.pipeline.prepare-checked+0xe00>
		00000000000016e0:  ARM64_RELOC_BRANCH26	_stogir.placement.late-with-uses!
    16e4:      	add	x16, sp, #0x7e0
    16e8:      	ldr	w0, [x16]
    16ec:      	lsr	x16, x0, #0
    16f0:      	cmp	x16, #0x1
    16f4:      	b.eq	0x1710 <_stogir.pipeline.prepare-checked+0xe30>
    16f8:      	b.lo	0x1700 <_stogir.pipeline.prepare-checked+0xe20>
    16fc:      	b	0x1714 <_stogir.pipeline.prepare-checked+0xe34>
    1700:      	cmp	x16, #0x0
    1704:      	b.eq	0x170c <_stogir.pipeline.prepare-checked+0xe2c>
    1708:      	b	0x1714 <_stogir.pipeline.prepare-checked+0xe34>
    170c:      	b	0x1730 <_stogir.pipeline.prepare-checked+0xe50>
    1710:      	b	0x1718 <_stogir.pipeline.prepare-checked+0xe38>
    1714:      	b	0x1c18 <_stogir.pipeline.prepare-checked+0x1338>
    1718:      	add	x16, sp, #0x7e0
    171c:      	orr	x0, x16, xzr
    1720:      	add	x0, x0, #0x8
    1724:      	add	x16, sp, #0x7e0
    1728:      	ldr	x21, [x16, #0x8]
    172c:      	ldr	x22, [x0, #0x8]
    1730:      	cmp	x22, #0x0
    1734:      	b.ne	0x1798 <_stogir.pipeline.prepare-checked+0xeb8>
    1738:      	add	x8, sp, #0x800
    173c:      	mov	x0, x20
    1740:      	add	x1, sp, #0x790
    1744:      	add	x2, sp, #0x610
    1748:      	bl	0x1748 <_stogir.pipeline.prepare-checked+0xe68>
		0000000000001748:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.place!
    174c:      	add	x16, sp, #0x800
    1750:      	ldr	w0, [x16]
    1754:      	lsr	x16, x0, #0
    1758:      	cmp	x16, #0x1
    175c:      	b.eq	0x1778 <_stogir.pipeline.prepare-checked+0xe98>
    1760:      	b.lo	0x1768 <_stogir.pipeline.prepare-checked+0xe88>
    1764:      	b	0x177c <_stogir.pipeline.prepare-checked+0xe9c>
    1768:      	cmp	x16, #0x0
    176c:      	b.eq	0x1774 <_stogir.pipeline.prepare-checked+0xe94>
    1770:      	b	0x177c <_stogir.pipeline.prepare-checked+0xe9c>
    1774:      	b	0x1798 <_stogir.pipeline.prepare-checked+0xeb8>
    1778:      	b	0x1780 <_stogir.pipeline.prepare-checked+0xea0>
    177c:      	b	0x1c20 <_stogir.pipeline.prepare-checked+0x1340>
    1780:      	add	x16, sp, #0x800
    1784:      	orr	x0, x16, xzr
    1788:      	add	x0, x0, #0x8
    178c:      	add	x16, sp, #0x800
    1790:      	ldr	x21, [x16, #0x8]
    1794:      	ldr	x22, [x0, #0x8]
    1798:      	cmp	x22, #0x0
    179c:      	b.ne	0x180c <_stogir.pipeline.prepare-checked+0xf2c>
    17a0:      	add	x8, sp, #0x820
    17a4:      	add	x0, sp, #0x330
    17a8:      	add	x1, sp, #0x450
    17ac:      	add	x2, sp, #0x550
    17b0:      	add	x3, sp, #0x5b0
    17b4:      	add	x4, sp, #0x4f0
    17b8:      	mov	x5, x24
    17bc:      	bl	0x17bc <_stogir.pipeline.prepare-checked+0xedc>
		00000000000017bc:  ARM64_RELOC_BRANCH26	_stogir.loops.reorder!
    17c0:      	add	x16, sp, #0x820
    17c4:      	ldr	w0, [x16]
    17c8:      	lsr	x16, x0, #0
    17cc:      	cmp	x16, #0x1
    17d0:      	b.eq	0x17ec <_stogir.pipeline.prepare-checked+0xf0c>
    17d4:      	b.lo	0x17dc <_stogir.pipeline.prepare-checked+0xefc>
    17d8:      	b	0x17f0 <_stogir.pipeline.prepare-checked+0xf10>
    17dc:      	cmp	x16, #0x0
    17e0:      	b.eq	0x17e8 <_stogir.pipeline.prepare-checked+0xf08>
    17e4:      	b	0x17f0 <_stogir.pipeline.prepare-checked+0xf10>
    17e8:      	b	0x180c <_stogir.pipeline.prepare-checked+0xf2c>
    17ec:      	b	0x17f4 <_stogir.pipeline.prepare-checked+0xf14>
    17f0:      	b	0x1c28 <_stogir.pipeline.prepare-checked+0x1348>
    17f4:      	add	x16, sp, #0x820
    17f8:      	orr	x0, x16, xzr
    17fc:      	add	x0, x0, #0x8
    1800:      	add	x16, sp, #0x820
    1804:      	ldr	x21, [x16, #0x8]
    1808:      	ldr	x22, [x0, #0x8]
    180c:      	cmp	x22, #0x0
    1810:      	b.ne	0x187c <_stogir.pipeline.prepare-checked+0xf9c>
    1814:      	add	x16, sp, #0x840
    1818:      	orr	x23, x16, xzr
    181c:      	add	x8, sp, #0x840
    1820:      	mov	x0, x20
    1824:      	add	x1, sp, #0x790
    1828:      	add	x2, sp, #0x610
    182c:      	add	x3, sp, #0x670
    1830:      	mov	x4, x24
    1834:      	bl	0x1834 <_stogir.pipeline.prepare-checked+0xf54>
		0000000000001834:  ARM64_RELOC_BRANCH26	_stogir.schedule.order-with-uses
    1838:      	add	x16, sp, #0x840
    183c:      	ldr	w0, [x16]
    1840:      	lsr	x16, x0, #0
    1844:      	cmp	x16, #0x1
    1848:      	b.eq	0x1864 <_stogir.pipeline.prepare-checked+0xf84>
    184c:      	b.lo	0x1854 <_stogir.pipeline.prepare-checked+0xf74>
    1850:      	b	0x1868 <_stogir.pipeline.prepare-checked+0xf88>
    1854:      	cmp	x16, #0x0
    1858:      	b.eq	0x1860 <_stogir.pipeline.prepare-checked+0xf80>
    185c:      	b	0x1868 <_stogir.pipeline.prepare-checked+0xf88>
    1860:      	b	0x1910 <_stogir.pipeline.prepare-checked+0x1030>
    1864:      	b	0x186c <_stogir.pipeline.prepare-checked+0xf8c>
    1868:      	b	0x1c30 <_stogir.pipeline.prepare-checked+0x1350>
    186c:      	add	x0, x23, #0x8
    1870:      	add	x16, sp, #0x840
    1874:      	ldr	x21, [x16, #0x8]
    1878:      	ldr	x22, [x0, #0x8]
    187c:      	b	0x188c <_stogir.pipeline.prepare-checked+0xfac>
    1880:      	sub	x0, x0, #0x1
    1884:      	add	x16, sp, #0x790
    1888:      	str	x0, [x16, #0x8]
    188c:      	add	x16, sp, #0x790
    1890:      	ldr	x0, [x16, #0x8]
    1894:      	cmp	x0, #0x0
    1898:      	b.ne	0x1880 <_stogir.pipeline.prepare-checked+0xfa0>
    189c:      	add	x16, sp, #0x790
    18a0:      	orr	x0, x16, xzr
    18a4:      	add	x16, sp, #0x790
    18a8:      	ldr	x1, [x16, #0x10]
    18ac:      	cmp	x1, #0x0
    18b0:      	b.le	0x18e0 <_stogir.pipeline.prepare-checked+0x1000>
    18b4:      	add	x0, x0, #0x18
    18b8:      	add	x16, sp, #0x790
    18bc:      	ldr	x2, [x16]
    18c0:      	fmov	d31, x1
    18c4:      	mov	x1, x2
    18c8:      	fmov	x2, d31
    18cc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		00000000000018cc:  ARM64_RELOC_PAGE21	l_stogir.395
    18d0:      	ldr	x3, [x3]
		00000000000018d0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    18d4:      	mov	x4, #0x4                ; =4
    18d8:      	mov	x5, #0x4                ; =4
    18dc:      	bl	0x18dc <_stogir.pipeline.prepare-checked+0xffc>
		00000000000018dc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    18e0:      	add	x16, sp, #0x790
    18e4:      	movz	x17, #0x0, lsl #48
    18e8:      	str	x17, [x16]
    18ec:      	add	x16, sp, #0x790
    18f0:      	movz	x17, #0x0, lsl #48
    18f4:      	str	x17, [x16, #0x8]
    18f8:      	add	x16, sp, #0x790
    18fc:      	movz	x17, #0x0, lsl #48
    1900:      	str	x17, [x16, #0x10]
    1904:      	b	0xf9c <_stogir.pipeline.prepare-checked+0x6bc>
    1908:      	brk	#0
    190c:      	b	0x1908 <_stogir.pipeline.prepare-checked+0x1028>
    1910:      	add	x0, x23, #0x8
    1914:      	add	x16, sp, #0x840
    1918:      	ldr	x1, [x16, #0x8]
    191c:      	ldr	x2, [x0, #0x8]
    1920:      	ldr	x3, [x0, #0x10]
    1924:      	ldr	x4, [x0, #0x18]
    1928:      	ldr	x0, [x0, #0x20]
    192c:      	add	x16, sp, #0x870
    1930:      	str	x1, [x16]
    1934:      	add	x16, sp, #0x870
    1938:      	str	x2, [x16, #0x8]
    193c:      	add	x16, sp, #0x870
    1940:      	str	x3, [x16, #0x10]
    1944:      	add	x16, sp, #0x870
    1948:      	str	x4, [x16, #0x18]
    194c:      	add	x16, sp, #0x870
    1950:      	str	x0, [x16, #0x20]
    1954:      	b	0x1964 <_stogir.pipeline.prepare-checked+0x1084>
    1958:      	sub	x0, x0, #0x1
    195c:      	add	x16, sp, #0x710
    1960:      	str	x0, [x16, #0x8]
    1964:      	add	x16, sp, #0x710
    1968:      	ldr	x0, [x16, #0x8]
    196c:      	cmp	x0, #0x0
    1970:      	b.ne	0x1958 <_stogir.pipeline.prepare-checked+0x1078>
    1974:      	add	x16, sp, #0x710
    1978:      	orr	x0, x16, xzr
    197c:      	add	x16, sp, #0x710
    1980:      	ldr	x1, [x16, #0x10]
    1984:      	cmp	x1, #0x0
    1988:      	b.le	0x19b8 <_stogir.pipeline.prepare-checked+0x10d8>
    198c:      	add	x0, x0, #0x18
    1990:      	add	x16, sp, #0x710
    1994:      	ldr	x2, [x16]
    1998:      	fmov	d31, x1
    199c:      	mov	x1, x2
    19a0:      	fmov	x2, d31
    19a4:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		00000000000019a4:  ARM64_RELOC_PAGE21	l_stogir.397
    19a8:      	ldr	x3, [x3]
		00000000000019a8:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    19ac:      	mov	x4, #0x10               ; =16
    19b0:      	mov	x5, #0x8                ; =8
    19b4:      	bl	0x19b4 <_stogir.pipeline.prepare-checked+0x10d4>
		00000000000019b4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    19b8:      	add	x16, sp, #0x710
    19bc:      	orr	x0, x16, xzr
    19c0:      	add	x23, x0, #0x28
    19c4:      	add	x16, sp, #0x710
    19c8:      	movz	x17, #0x0, lsl #48
    19cc:      	str	x17, [x16]
    19d0:      	add	x16, sp, #0x710
    19d4:      	movz	x17, #0x0, lsl #48
    19d8:      	str	x17, [x16, #0x8]
    19dc:      	add	x16, sp, #0x710
    19e0:      	movz	x17, #0x0, lsl #48
    19e4:      	str	x17, [x16, #0x10]
    19e8:      	b	0x19f8 <_stogir.pipeline.prepare-checked+0x1118>
    19ec:      	nop
    19f0:      	sub	x0, x0, #0x1
    19f4:      	str	x0, [x23, #0x8]
    19f8:      	ldr	x0, [x23, #0x8]
    19fc:      	cmp	x0, #0x0
    1a00:      	b.ne	0x19f0 <_stogir.pipeline.prepare-checked+0x1110>
    1a04:      	ldr	x0, [x23, #0x10]
    1a08:      	cmp	x0, #0x0
    1a0c:      	b.le	0x1a40 <_stogir.pipeline.prepare-checked+0x1160>
    1a10:      	add	x1, x23, #0x18
    1a14:      	add	x16, sp, #0x710
    1a18:      	ldr	x2, [x16, #0x28]
    1a1c:      	fmov	d31, x0
    1a20:      	mov	x0, x1
    1a24:      	mov	x1, x2
    1a28:      	fmov	x2, d31
    1a2c:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001a2c:  ARM64_RELOC_PAGE21	l_stogir.395
    1a30:      	ldr	x3, [x3]
		0000000000001a30:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1a34:      	mov	x4, #0x4                ; =4
    1a38:      	mov	x5, #0x4                ; =4
    1a3c:      	bl	0x1a3c <_stogir.pipeline.prepare-checked+0x115c>
		0000000000001a3c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1a40:      	add	x16, sp, #0x710
    1a44:      	movz	x17, #0x0, lsl #48
    1a48:      	str	x17, [x16, #0x28]
    1a4c:      	movz	x17, #0x0, lsl #48
    1a50:      	str	x17, [x23, #0x8]
    1a54:      	movz	x17, #0x0, lsl #48
    1a58:      	str	x17, [x23, #0x10]
    1a5c:      	add	x8, sp, #0x8a0
    1a60:      	add	x0, sp, #0x870
    1a64:      	add	x1, sp, #0x790
    1a68:      	add	x2, sp, #0x4f0
    1a6c:      	mov	x3, x24
    1a70:      	bl	0x1a70 <_stogir.pipeline.prepare-checked+0x1190>
		0000000000001a70:  ARM64_RELOC_BRANCH26	_stogir.schedule.pack
    1a74:      	add	x16, sp, #0x8a0
    1a78:      	ldr	x0, [x16]
    1a7c:      	add	x16, sp, #0x710
    1a80:      	str	x0, [x16]
    1a84:      	add	x16, sp, #0x8a0
    1a88:      	ldr	x0, [x16, #0x8]
    1a8c:      	add	x16, sp, #0x710
    1a90:      	str	x0, [x16, #0x8]
    1a94:      	add	x16, sp, #0x8a0
    1a98:      	ldr	x0, [x16, #0x10]
    1a9c:      	add	x16, sp, #0x710
    1aa0:      	str	x0, [x16, #0x10]
    1aa4:      	add	x16, sp, #0x8a0
    1aa8:      	ldr	x0, [x16, #0x18]
    1aac:      	add	x16, sp, #0x710
    1ab0:      	str	x0, [x16, #0x18]
    1ab4:      	add	x16, sp, #0x8a0
    1ab8:      	ldr	x0, [x16, #0x20]
    1abc:      	add	x16, sp, #0x710
    1ac0:      	str	x0, [x16, #0x20]
    1ac4:      	add	x16, sp, #0x8a0
    1ac8:      	ldr	x0, [x16, #0x28]
    1acc:      	add	x16, sp, #0x710
    1ad0:      	str	x0, [x16, #0x28]
    1ad4:      	add	x16, sp, #0x8a0
    1ad8:      	ldr	x0, [x16, #0x30]
    1adc:      	add	x16, sp, #0x710
    1ae0:      	str	x0, [x16, #0x30]
    1ae4:      	add	x16, sp, #0x8a0
    1ae8:      	ldr	x0, [x16, #0x38]
    1aec:      	add	x16, sp, #0x710
    1af0:      	str	x0, [x16, #0x38]
    1af4:      	add	x16, sp, #0x8a0
    1af8:      	ldr	x0, [x16, #0x40]
    1afc:      	add	x16, sp, #0x710
    1b00:      	str	x0, [x16, #0x40]
    1b04:      	add	x16, sp, #0x8a0
    1b08:      	ldr	x0, [x16, #0x48]
    1b0c:      	add	x16, sp, #0x710
    1b10:      	str	x0, [x16, #0x48]
    1b14:      	add	x8, sp, #0x8f0
    1b18:      	mov	x0, x20
    1b1c:      	add	x1, sp, #0x790
    1b20:      	add	x2, sp, #0x710
    1b24:      	mov	x3, x24
    1b28:      	bl	0x1b28 <_stogir.pipeline.prepare-checked+0x1248>
		0000000000001b28:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.cluster!
    1b2c:      	add	x16, sp, #0x8f0
    1b30:      	ldr	w0, [x16]
    1b34:      	lsr	x16, x0, #0
    1b38:      	cmp	x16, #0x1
    1b3c:      	b.eq	0x1b58 <_stogir.pipeline.prepare-checked+0x1278>
    1b40:      	b.lo	0x1b48 <_stogir.pipeline.prepare-checked+0x1268>
    1b44:      	b	0x1b5c <_stogir.pipeline.prepare-checked+0x127c>
    1b48:      	cmp	x16, #0x0
    1b4c:      	b.eq	0x1b54 <_stogir.pipeline.prepare-checked+0x1274>
    1b50:      	b	0x1b5c <_stogir.pipeline.prepare-checked+0x127c>
    1b54:      	b	0x1b78 <_stogir.pipeline.prepare-checked+0x1298>
    1b58:      	b	0x1b60 <_stogir.pipeline.prepare-checked+0x1280>
    1b5c:      	b	0x1c38 <_stogir.pipeline.prepare-checked+0x1358>
    1b60:      	add	x16, sp, #0x8f0
    1b64:      	orr	x0, x16, xzr
    1b68:      	add	x0, x0, #0x8
    1b6c:      	add	x16, sp, #0x8f0
    1b70:      	ldr	x21, [x16, #0x8]
    1b74:      	ldr	x22, [x0, #0x8]
    1b78:      	b	0x1b8c <_stogir.pipeline.prepare-checked+0x12ac>
    1b7c:      	nop
    1b80:      	sub	x0, x0, #0x1
    1b84:      	add	x16, sp, #0x870
    1b88:      	str	x0, [x16, #0x8]
    1b8c:      	add	x16, sp, #0x870
    1b90:      	ldr	x0, [x16, #0x8]
    1b94:      	cmp	x0, #0x0
    1b98:      	b.ne	0x1b80 <_stogir.pipeline.prepare-checked+0x12a0>
    1b9c:      	add	x16, sp, #0x870
    1ba0:      	orr	x0, x16, xzr
    1ba4:      	add	x16, sp, #0x870
    1ba8:      	ldr	x1, [x16, #0x10]
    1bac:      	cmp	x1, #0x0
    1bb0:      	b.le	0x1be0 <_stogir.pipeline.prepare-checked+0x1300>
    1bb4:      	add	x0, x0, #0x18
    1bb8:      	add	x16, sp, #0x870
    1bbc:      	ldr	x2, [x16]
    1bc0:      	fmov	d31, x1
    1bc4:      	mov	x1, x2
    1bc8:      	fmov	x2, d31
    1bcc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001bcc:  ARM64_RELOC_PAGE21	l_stogir.395
    1bd0:      	ldr	x3, [x3]
		0000000000001bd0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1bd4:      	mov	x4, #0x4                ; =4
    1bd8:      	mov	x5, #0x4                ; =4
    1bdc:      	bl	0x1bdc <_stogir.pipeline.prepare-checked+0x12fc>
		0000000000001bdc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1be0:      	add	x16, sp, #0x870
    1be4:      	movz	x17, #0x0, lsl #48
    1be8:      	str	x17, [x16]
    1bec:      	add	x16, sp, #0x870
    1bf0:      	movz	x17, #0x0, lsl #48
    1bf4:      	str	x17, [x16, #0x8]
    1bf8:      	add	x16, sp, #0x870
    1bfc:      	movz	x17, #0x0, lsl #48
    1c00:      	str	x17, [x16, #0x10]
    1c04:      	b	0x187c <_stogir.pipeline.prepare-checked+0xf9c>
    1c08:      	brk	#0
    1c0c:      	b	0x1c08 <_stogir.pipeline.prepare-checked+0x1328>
    1c10:      	brk	#0
    1c14:      	b	0x1c10 <_stogir.pipeline.prepare-checked+0x1330>
    1c18:      	brk	#0
    1c1c:      	b	0x1c18 <_stogir.pipeline.prepare-checked+0x1338>
    1c20:      	brk	#0
    1c24:      	b	0x1c20 <_stogir.pipeline.prepare-checked+0x1340>
    1c28:      	brk	#0
    1c2c:      	b	0x1c28 <_stogir.pipeline.prepare-checked+0x1348>
    1c30:      	brk	#0
    1c34:      	b	0x1c30 <_stogir.pipeline.prepare-checked+0x1350>
    1c38:      	brk	#0
    1c3c:      	b	0x1c38 <_stogir.pipeline.prepare-checked+0x1358>
    1c40:      	str	x19, [sp, #0xed8]
    1c44:      	b	0x928 <_stogir.pipeline.prepare-checked+0x48>
    1c48:      	str	x19, [sp, #0xed8]
    1c4c:      	b	0x16a8 <_stogir.pipeline.prepare-checked+0xdc8>

0000000000001c50 <_stogir.cfg.release!>:
    1c50:      	sub	sp, sp, #0x30
    1c54:      	str	x29, [sp]
    1c58:      	str	x30, [sp, #0x8]
    1c5c:      	mov	x29, sp
    1c60:      	str	x19, [sp, #0x10]
    1c64:      	str	x20, [sp, #0x18]
    1c68:      	str	x21, [sp, #0x20]
    1c6c:      	b	0x1c78 <_stogir.cfg.release!+0x28>
    1c70:      	sub	x1, x1, #0x1
    1c74:      	str	x1, [x0, #0x8]
    1c78:      	ldr	x1, [x0, #0x8]
    1c7c:      	cmp	x1, #0x0
    1c80:      	b.ne	0x1c70 <_stogir.cfg.release!+0x20>
    1c84:      	ldr	x1, [x0, #0x10]
    1c88:      	cmp	x1, #0x0
    1c8c:      	b.le	0x1dd0 <_stogir.cfg.release!+0x180>
    1c90:      	add	x2, x0, #0x18
    1c94:      	ldr	x3, [x0]
    1c98:      	mov	x19, x0
    1c9c:      	mov	x0, x2
    1ca0:      	mov	x2, x1
    1ca4:      	mov	x1, x3
    1ca8:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001ca8:  ARM64_RELOC_PAGE21	l_stogir.398
    1cac:      	ldr	x3, [x3]
		0000000000001cac:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    1cb0:      	mov	x4, #0x4                ; =4
    1cb4:      	mov	x5, #0x4                ; =4
    1cb8:      	bl	0x1cb8 <_stogir.cfg.release!+0x68>
		0000000000001cb8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1cbc:      	add	x20, x19, #0x28
    1cc0:      	movz	x17, #0x0, lsl #48
    1cc4:      	str	x17, [x19]
    1cc8:      	movz	x17, #0x0, lsl #48
    1ccc:      	str	x17, [x19, #0x8]
    1cd0:      	movz	x17, #0x0, lsl #48
    1cd4:      	str	x17, [x19, #0x10]
    1cd8:      	b	0x1ce8 <_stogir.cfg.release!+0x98>
    1cdc:      	nop
    1ce0:      	sub	x0, x0, #0x1
    1ce4:      	str	x0, [x20, #0x8]
    1ce8:      	ldr	x0, [x20, #0x8]
    1cec:      	cmp	x0, #0x0
    1cf0:      	b.ne	0x1ce0 <_stogir.cfg.release!+0x90>
    1cf4:      	ldr	x0, [x20, #0x10]
    1cf8:      	cmp	x0, #0x0
    1cfc:      	b.le	0x1d2c <_stogir.cfg.release!+0xdc>
    1d00:      	add	x1, x20, #0x18
    1d04:      	ldr	x2, [x19, #0x28]
    1d08:      	fmov	d31, x0
    1d0c:      	mov	x0, x1
    1d10:      	mov	x1, x2
    1d14:      	fmov	x2, d31
    1d18:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001d18:  ARM64_RELOC_PAGE21	l_stogir.398
    1d1c:      	ldr	x3, [x3]
		0000000000001d1c:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    1d20:      	mov	x4, #0x4                ; =4
    1d24:      	mov	x5, #0x4                ; =4
    1d28:      	bl	0x1d28 <_stogir.cfg.release!+0xd8>
		0000000000001d28:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1d2c:      	add	x21, x19, #0x50
    1d30:      	movz	x17, #0x0, lsl #48
    1d34:      	str	x17, [x19, #0x28]
    1d38:      	movz	x17, #0x0, lsl #48
    1d3c:      	str	x17, [x20, #0x8]
    1d40:      	movz	x17, #0x0, lsl #48
    1d44:      	str	x17, [x20, #0x10]
    1d48:      	b	0x1d58 <_stogir.cfg.release!+0x108>
    1d4c:      	nop
    1d50:      	sub	x0, x0, #0x1
    1d54:      	str	x0, [x21, #0x8]
    1d58:      	ldr	x0, [x21, #0x8]
    1d5c:      	cmp	x0, #0x0
    1d60:      	b.ne	0x1d50 <_stogir.cfg.release!+0x100>
    1d64:      	ldr	x0, [x21, #0x10]
    1d68:      	cmp	x0, #0x0
    1d6c:      	b.le	0x1d9c <_stogir.cfg.release!+0x14c>
    1d70:      	add	x1, x21, #0x18
    1d74:      	ldr	x2, [x19, #0x50]
    1d78:      	fmov	d31, x0
    1d7c:      	mov	x0, x1
    1d80:      	mov	x1, x2
    1d84:      	fmov	x2, d31
    1d88:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001d88:  ARM64_RELOC_PAGE21	l_stogir.399
    1d8c:      	ldr	x3, [x3]
		0000000000001d8c:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    1d90:      	mov	x4, #0x10               ; =16
    1d94:      	mov	x5, #0x4                ; =4
    1d98:      	bl	0x1d98 <_stogir.cfg.release!+0x148>
		0000000000001d98:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1d9c:      	movz	x17, #0x0, lsl #48
    1da0:      	str	x17, [x19, #0x50]
    1da4:      	movz	x17, #0x0, lsl #48
    1da8:      	str	x17, [x21, #0x8]
    1dac:      	movz	x17, #0x0, lsl #48
    1db0:      	str	x17, [x21, #0x10]
    1db4:      	ldr	x19, [sp, #0x10]
    1db8:      	ldr	x20, [sp, #0x18]
    1dbc:      	ldr	x21, [sp, #0x20]
    1dc0:      	ldr	x29, [sp]
    1dc4:      	ldr	x30, [sp, #0x8]
    1dc8:      	add	sp, sp, #0x30
    1dcc:      	ret
    1dd0:      	mov	x19, x0
    1dd4:      	b	0x1cbc <_stogir.cfg.release!+0x6c>

0000000000001dd8 <_inherent$coil.arraylist.ArrayList$free!__i32>:
    1dd8:      	sub	sp, sp, #0x20
    1ddc:      	str	x29, [sp]
    1de0:      	str	x30, [sp, #0x8]
    1de4:      	mov	x29, sp
    1de8:      	str	x19, [sp, #0x10]
    1dec:      	b	0x1df8 <_inherent$coil.arraylist.ArrayList$free!__i32+0x20>
    1df0:      	sub	x1, x1, #0x1
    1df4:      	str	x1, [x0, #0x8]
    1df8:      	ldr	x1, [x0, #0x8]
    1dfc:      	cmp	x1, #0x0
    1e00:      	b.ne	0x1df0 <_inherent$coil.arraylist.ArrayList$free!__i32+0x18>
    1e04:      	ldr	x1, [x0, #0x10]
    1e08:      	cmp	x1, #0x0
    1e0c:      	b.le	0x1e6c <_inherent$coil.arraylist.ArrayList$free!__i32+0x94>
    1e10:      	add	x2, x0, #0x18
    1e14:      	ldr	x3, [x0]
    1e18:      	mov	x19, x0
    1e1c:      	mov	x0, x2
    1e20:      	mov	x2, x1
    1e24:      	mov	x1, x3
    1e28:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001e28:  ARM64_RELOC_PAGE21	l_stogir.400
    1e2c:      	ldr	x3, [x3]
		0000000000001e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    1e30:      	mov	x4, #0x4                ; =4
    1e34:      	mov	x5, #0x4                ; =4
    1e38:      	bl	0x1e38 <_inherent$coil.arraylist.ArrayList$free!__i32+0x60>
		0000000000001e38:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1e3c:      	movz	x17, #0x0, lsl #48
    1e40:      	str	x17, [x19]
    1e44:      	movz	x17, #0x0, lsl #48
    1e48:      	str	x17, [x19, #0x8]
    1e4c:      	movz	x17, #0x0, lsl #48
    1e50:      	str	x17, [x19, #0x10]
    1e54:      	movz	x0, #0x0, lsl #48
    1e58:      	ldr	x19, [sp, #0x10]
    1e5c:      	ldr	x29, [sp]
    1e60:      	ldr	x30, [sp, #0x8]
    1e64:      	add	sp, sp, #0x20
    1e68:      	ret
    1e6c:      	mov	x19, x0
    1e70:      	b	0x1e3c <_inherent$coil.arraylist.ArrayList$free!__i32+0x64>
    1e74:      	udf	#0x0

0000000000001e78 <_stogir.schedule.release!>:
    1e78:      	sub	sp, sp, #0x20
    1e7c:      	str	x29, [sp]
    1e80:      	str	x30, [sp, #0x8]
    1e84:      	mov	x29, sp
    1e88:      	str	x19, [sp, #0x10]
    1e8c:      	str	x20, [sp, #0x18]
    1e90:      	b	0x1ea0 <_stogir.schedule.release!+0x28>
    1e94:      	nop
    1e98:      	sub	x1, x1, #0x1
    1e9c:      	str	x1, [x0, #0x8]
    1ea0:      	ldr	x1, [x0, #0x8]
    1ea4:      	cmp	x1, #0x0
    1ea8:      	b.ne	0x1e98 <_stogir.schedule.release!+0x20>
    1eac:      	ldr	x1, [x0, #0x10]
    1eb0:      	cmp	x1, #0x0
    1eb4:      	b.le	0x1f84 <_stogir.schedule.release!+0x10c>
    1eb8:      	add	x2, x0, #0x18
    1ebc:      	ldr	x3, [x0]
    1ec0:      	mov	x19, x0
    1ec4:      	mov	x0, x2
    1ec8:      	mov	x2, x1
    1ecc:      	mov	x1, x3
    1ed0:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001ed0:  ARM64_RELOC_PAGE21	l_stogir.401
    1ed4:      	ldr	x3, [x3]
		0000000000001ed4:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    1ed8:      	mov	x4, #0x10               ; =16
    1edc:      	mov	x5, #0x8                ; =8
    1ee0:      	bl	0x1ee0 <_stogir.schedule.release!+0x68>
		0000000000001ee0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1ee4:      	add	x20, x19, #0x28
    1ee8:      	movz	x17, #0x0, lsl #48
    1eec:      	str	x17, [x19]
    1ef0:      	movz	x17, #0x0, lsl #48
    1ef4:      	str	x17, [x19, #0x8]
    1ef8:      	movz	x17, #0x0, lsl #48
    1efc:      	str	x17, [x19, #0x10]
    1f00:      	b	0x1f10 <_stogir.schedule.release!+0x98>
    1f04:      	nop
    1f08:      	sub	x0, x0, #0x1
    1f0c:      	str	x0, [x20, #0x8]
    1f10:      	ldr	x0, [x20, #0x8]
    1f14:      	cmp	x0, #0x0
    1f18:      	b.ne	0x1f08 <_stogir.schedule.release!+0x90>
    1f1c:      	ldr	x0, [x20, #0x10]
    1f20:      	cmp	x0, #0x0
    1f24:      	b.le	0x1f54 <_stogir.schedule.release!+0xdc>
    1f28:      	add	x1, x20, #0x18
    1f2c:      	ldr	x2, [x19, #0x28]
    1f30:      	fmov	d31, x0
    1f34:      	mov	x0, x1
    1f38:      	mov	x1, x2
    1f3c:      	fmov	x2, d31
    1f40:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001f40:  ARM64_RELOC_PAGE21	l_stogir.402
    1f44:      	ldr	x3, [x3]
		0000000000001f44:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    1f48:      	mov	x4, #0x4                ; =4
    1f4c:      	mov	x5, #0x4                ; =4
    1f50:      	bl	0x1f50 <_stogir.schedule.release!+0xd8>
		0000000000001f50:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1f54:      	movz	x17, #0x0, lsl #48
    1f58:      	str	x17, [x19, #0x28]
    1f5c:      	movz	x17, #0x0, lsl #48
    1f60:      	str	x17, [x20, #0x8]
    1f64:      	movz	x17, #0x0, lsl #48
    1f68:      	str	x17, [x20, #0x10]
    1f6c:      	ldr	x19, [sp, #0x10]
    1f70:      	ldr	x20, [sp, #0x18]
    1f74:      	ldr	x29, [sp]
    1f78:      	ldr	x30, [sp, #0x8]
    1f7c:      	add	sp, sp, #0x20
    1f80:      	ret
    1f84:      	mov	x19, x0
    1f88:      	b	0x1ee4 <_stogir.schedule.release!+0x6c>

0000000000001f8c <_stogir.verify.schedule-input>:
    1f8c:      	sub	sp, sp, #0x80
    1f90:      	str	x29, [sp]
    1f94:      	str	x30, [sp, #0x8]
    1f98:      	mov	x29, sp
    1f9c:      	str	x19, [sp, #0x50]
    1fa0:      	str	x20, [sp, #0x58]
    1fa4:      	str	x21, [sp, #0x60]
    1fa8:      	str	x22, [sp, #0x68]
    1fac:      	str	x23, [sp, #0x70]
    1fb0:      	mov	x19, x8
    1fb4:      	add	x8, sp, #0x10
    1fb8:      	mov	x20, x0
    1fbc:      	mov	w21, w1
    1fc0:      	mov	x22, x2
    1fc4:      	mov	x23, x3
    1fc8:      	bl	0x1fc8 <_stogir.verify.schedule-input+0x3c>
		0000000000001fc8:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    1fcc:      	add	x16, sp, #0x10
    1fd0:      	ldr	w0, [x16]
    1fd4:      	lsr	x16, x0, #0
    1fd8:      	cmp	x16, #0x1
    1fdc:      	b.eq	0x1ff8 <_stogir.verify.schedule-input+0x6c>
    1fe0:      	b.lo	0x1fe8 <_stogir.verify.schedule-input+0x5c>
    1fe4:      	b	0x1ffc <_stogir.verify.schedule-input+0x70>
    1fe8:      	cmp	x16, #0x0
    1fec:      	b.eq	0x1ff4 <_stogir.verify.schedule-input+0x68>
    1ff0:      	b	0x1ffc <_stogir.verify.schedule-input+0x70>
    1ff4:      	b	0x2020 <_stogir.verify.schedule-input+0x94>
    1ff8:      	b	0x2000 <_stogir.verify.schedule-input+0x74>
    1ffc:      	b	0x2080 <_stogir.verify.schedule-input+0xf4>
    2000:      	add	x16, sp, #0x10
    2004:      	orr	x0, x16, xzr
    2008:      	add	x0, x0, #0x8
    200c:      	add	x16, sp, #0x10
    2010:      	ldr	x1, [x16, #0x8]
    2014:      	ldr	x0, [x0, #0x8]
    2018:      	mov	x2, #0x1                ; =1
    201c:      	b	0x2050 <_stogir.verify.schedule-input+0xc4>
    2020:      	add	x8, sp, #0x30
    2024:      	mov	x0, x20
    2028:      	mov	w1, w21
    202c:      	mov	x2, x22
    2030:      	mov	x3, x23
    2034:      	bl	0x2034 <_stogir.verify.schedule-input+0xa8>
		0000000000002034:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input-structured
    2038:      	add	x16, sp, #0x30
    203c:      	ldr	x2, [x16]
    2040:      	add	x16, sp, #0x30
    2044:      	ldr	x1, [x16, #0x8]
    2048:      	add	x16, sp, #0x30
    204c:      	ldr	x0, [x16, #0x10]
    2050:      	str	x2, [x19]
    2054:      	str	x1, [x19, #0x8]
    2058:      	str	x0, [x19, #0x10]
    205c:      	ldr	x19, [sp, #0x50]
    2060:      	ldr	x20, [sp, #0x58]
    2064:      	ldr	x21, [sp, #0x60]
    2068:      	ldr	x22, [sp, #0x68]
    206c:      	ldr	x23, [sp, #0x70]
    2070:      	ldr	x29, [sp]
    2074:      	ldr	x30, [sp, #0x8]
    2078:      	add	sp, sp, #0x80
    207c:      	ret
    2080:      	brk	#0
    2084:      	b	0x2080 <_stogir.verify.schedule-input+0xf4>

0000000000002088 <_stogir.graph.contains?>:
    2088:      	sxtw	x1, w1
    208c:      	cmp	x1, #0x0
    2090:      	b.le	0x20d0 <_stogir.graph.contains?+0x48>
    2094:      	ldr	x2, [x0, #0x8]
    2098:      	cmp	x1, x2
    209c:      	b.ge	0x212c <_stogir.graph.contains?+0xa4>
    20a0:      	add	x2, x0, #0x78
    20a4:      	ldr	x2, [x2, #0x8]
    20a8:      	cmp	x1, x2
    20ac:      	b.ge	0x213c <_stogir.graph.contains?+0xb4>
    20b0:      	ldr	x0, [x0, #0x78]
    20b4:      	add	x0, x0, x1, lsl #2
    20b8:      	ldr	w0, [x0]
    20bc:      	sxtw	x0, w0
    20c0:      	cmp	x0, #0x0
    20c4:      	cset	w0, ge
    20c8:      	ubfx	x0, x0, #0, #8
    20cc:      	b	0x2140 <_stogir.graph.contains?+0xb8>
    20d0:      	cmp	x1, #0x0
    20d4:      	b.ge	0x2134 <_stogir.graph.contains?+0xac>
    20d8:      	add	x2, x0, #0x28
    20dc:      	add	x3, x0, #0x50
    20e0:      	ldr	x2, [x2, #0x8]
    20e4:      	ldr	x3, [x3, #0x8]
    20e8:      	cmp	x2, x3
    20ec:      	b.ne	0x214c <_stogir.graph.contains?+0xc4>
    20f0:      	movz	x16, #0x0, lsl #48
    20f4:      	sub	x3, x16, x1
    20f8:      	cmp	x3, x2
    20fc:      	b.gt	0x2144 <_stogir.graph.contains?+0xbc>
    2100:      	movz	x16, #0x0, lsl #48
    2104:      	sub	x1, x16, x1
    2108:      	sub	x1, x1, #0x1
    210c:      	ldr	x0, [x0, #0x50]
    2110:      	add	x0, x0, x1, lsl #2
    2114:      	ldr	w0, [x0]
    2118:      	sxtw	x0, w0
    211c:      	cmp	x0, #0x0
    2120:      	cset	w0, gt
    2124:      	ubfx	x0, x0, #0, #8
    2128:      	b	0x2148 <_stogir.graph.contains?+0xc0>
    212c:      	movz	x0, #0x0, lsl #48
    2130:      	b	0x2140 <_stogir.graph.contains?+0xb8>
    2134:      	movz	x0, #0x0, lsl #48
    2138:      	b	0x2148 <_stogir.graph.contains?+0xc0>
    213c:      	movz	x0, #0x0, lsl #48
    2140:      	b	0x2148 <_stogir.graph.contains?+0xc0>
    2144:      	movz	x0, #0x0, lsl #48
    2148:      	ret
    214c:      	movz	x0, #0x0, lsl #48
    2150:      	b	0x2148 <_stogir.graph.contains?+0xc0>
    2154:      	udf	#0x0

0000000000002158 <_stogir.cfg.build>:
    2158:      	sub	sp, sp, #0x2e0
    215c:      	str	x29, [sp, #0x10]
    2160:      	str	x30, [sp, #0x18]
    2164:      	add	x29, sp, #0x10
    2168:      	str	x19, [sp, #0x288]
    216c:      	str	x20, [sp, #0x290]
    2170:      	str	x21, [sp, #0x298]
    2174:      	str	x22, [sp, #0x2a0]
    2178:      	str	x23, [sp, #0x2a8]
    217c:      	str	x24, [sp, #0x2b0]
    2180:      	str	x25, [sp, #0x2b8]
    2184:      	str	x26, [sp, #0x2c0]
    2188:      	str	x27, [sp, #0x2c8]
    218c:      	str	x28, [sp, #0x2d0]
    2190:      	mov	x19, x8
    2194:      	add	x8, sp, #0x20
    2198:      	mov	x20, x0
    219c:      	mov	x21, x1
    21a0:      	bl	0x21a0 <_stogir.cfg.build+0x48>
		00000000000021a0:  ARM64_RELOC_BRANCH26	_stogir.verify.control-sources
    21a4:      	add	x16, sp, #0x20
    21a8:      	ldr	w0, [x16]
    21ac:      	lsr	x16, x0, #0
    21b0:      	cmp	x16, #0x1
    21b4:      	b.eq	0x21d0 <_stogir.cfg.build+0x78>
    21b8:      	b.lo	0x21c0 <_stogir.cfg.build+0x68>
    21bc:      	b	0x21d4 <_stogir.cfg.build+0x7c>
    21c0:      	cmp	x16, #0x0
    21c4:      	b.eq	0x21cc <_stogir.cfg.build+0x74>
    21c8:      	b	0x21d4 <_stogir.cfg.build+0x7c>
    21cc:      	b	0x2600 <_stogir.cfg.build+0x4a8>
    21d0:      	b	0x21d8 <_stogir.cfg.build+0x80>
    21d4:      	b	0x2cac <_stogir.cfg.build+0xb54>
    21d8:      	add	x16, sp, #0x20
    21dc:      	orr	x0, x16, xzr
    21e0:      	add	x0, x0, #0x8
    21e4:      	add	x16, sp, #0x20
    21e8:      	ldr	x21, [x16, #0x8]
    21ec:      	ldr	x22, [x0, #0x8]
    21f0:      	str	x19, [sp, #0x258]
    21f4:      	mov	x13, #0x1               ; =1
    21f8:      	movz	x0, #0x0, lsl #48
    21fc:      	movz	x1, #0x0, lsl #48
    2200:      	movz	x2, #0x0, lsl #48
    2204:      	movz	x3, #0x0, lsl #48
    2208:      	movz	x4, #0x0, lsl #48
    220c:      	movz	x5, #0x0, lsl #48
    2210:      	movz	x6, #0x0, lsl #48
    2214:      	movz	x7, #0x0, lsl #48
    2218:      	movz	x8, #0x0, lsl #48
    221c:      	movz	x9, #0x0, lsl #48
    2220:      	movz	x10, #0x0, lsl #48
    2224:      	movz	x11, #0x0, lsl #48
    2228:      	movz	x12, #0x0, lsl #48
    222c:      	b	0x2584 <_stogir.cfg.build+0x42c>
    2230:      	sub	w1, w0, #0x1
    2234:      	lsl	w1, w1, #2
    2238:      	ubfx	x1, x1, #0, #32
    223c:      	lsr	x1, x2, x1
    2240:      	and	w1, w1, #0xf
    2244:      	b	0x22f0 <_stogir.cfg.build+0x198>
    2248:      	lsl	x2, x2, #1
    224c:      	str	w23, [sp, #0x278]
    2250:      	mov	x23, x0
    2254:      	mov	x0, x19
    2258:      	str	w24, [sp, #0x280]
    225c:      	mov	x24, x1
    2260:      	mov	x1, x2
    2264:      	bl	0x2264 <_stogir.cfg.build+0x10c>
		0000000000002264:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge
    2268:      	add	x0, x24, #0x1
    226c:      	add	x16, sp, #0x40
    2270:      	ldr	x1, [x16, #0x50]
    2274:      	add	x1, x1, x24, lsl #4
    2278:      	str	x20, [x1]
    227c:      	str	x23, [x1, #0x8]
    2280:      	str	x0, [x19, #0x8]
    2284:      	add	x0, x28, #0x1
    2288:      	sxtw	x28, w0
    228c:      	ldr	x20, [sp, #0x270]
    2290:      	ldr	w23, [sp, #0x278]
    2294:      	ldr	w24, [sp, #0x280]
    2298:      	cmp	x22, #0x0
    229c:      	b.ne	0x22b0 <_stogir.cfg.build+0x158>
    22a0:      	cmp	x28, x27
    22a4:      	cset	w0, le
    22a8:      	ubfx	x0, x0, #0, #8
    22ac:      	b	0x22b4 <_stogir.cfg.build+0x15c>
    22b0:      	movz	x0, #0x0, lsl #48
    22b4:      	cmp	x0, #0x0
    22b8:      	b.eq	0x2cb4 <_stogir.cfg.build+0xb5c>
    22bc:      	orr	w0, w28, wzr
    22c0:      	uxtb	w16, w25
    22c4:      	cmp	w16, wzr
    22c8:      	b.eq	0x22f4 <_stogir.cfg.build+0x19c>
    22cc:      	sxtw	x1, w0
    22d0:      	ldr	w2, [x26]
    22d4:      	cmp	x1, #0x0
    22d8:      	b.le	0x22ec <_stogir.cfg.build+0x194>
    22dc:      	cmp	x1, #0x4
    22e0:      	b.le	0x2230 <_stogir.cfg.build+0xd8>
    22e4:      	mov	w1, #0x4                ; =4
    22e8:      	b	0x2234 <_stogir.cfg.build+0xdc>
    22ec:      	movz	w1, #0x0, lsl #16
    22f0:      	b	0x22f8 <_stogir.cfg.build+0x1a0>
    22f4:      	movz	w1, #0x0, lsl #16
    22f8:      	adrp	x16, 0x2000 <_stogir.verify.schedule-input+0x74>
		00000000000022f8:  ARM64_RELOC_PAGE21	l_stogir.403
    22fc:      	ldr	x16, [x16]
		00000000000022fc:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    2300:      	ldr	w2, [x16]
    2304:      	ubfx	x1, x1, #0, #32
    2308:      	cmp	x1, x2
    230c:      	b.ne	0x2cbc <_stogir.cfg.build+0xb64>
    2310:      	mov	w1, w23
    2314:      	mov	w2, w0
    2318:      	str	x20, [sp, #0x270]
    231c:      	fmov	s31, w0
    2320:      	mov	x0, x20
    2324:      	fmov	w20, s31
    2328:      	bl	0x2328 <_stogir.cfg.build+0x1d0>
		0000000000002328:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    232c:      	ubfx	x0, x0, #0, #32
    2330:      	lsr	x16, x0, #0
    2334:      	cmp	x16, #0x1
    2338:      	b.eq	0x2354 <_stogir.cfg.build+0x1fc>
    233c:      	b.lo	0x2344 <_stogir.cfg.build+0x1ec>
    2340:      	b	0x2358 <_stogir.cfg.build+0x200>
    2344:      	cmp	x16, #0x0
    2348:      	b.eq	0x2350 <_stogir.cfg.build+0x1f8>
    234c:      	b	0x2358 <_stogir.cfg.build+0x200>
    2350:      	b	0x235c <_stogir.cfg.build+0x204>
    2354:      	b	0x2374 <_stogir.cfg.build+0x21c>
    2358:      	b	0x2c9c <_stogir.cfg.build+0xb44>
    235c:      	str	w23, [sp, #0x278]
    2360:      	str	w24, [sp, #0x280]
    2364:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002364:  ARM64_RELOC_PAGE21	l_stogir.404
    2368:      	ldr	x21, [x21]
		0000000000002368:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    236c:      	mov	x22, #0x19              ; =25
    2370:      	b	0x2284 <_stogir.cfg.build+0x12c>
    2374:      	add	x16, sp, #0x40
    2378:      	ldr	x0, [x16, #0x28]
    237c:      	sxtw	x2, w1
    2380:      	add	x0, x0, x2, lsl #2
    2384:      	ldr	w0, [x0]
    2388:      	sxtw	x2, w0
    238c:      	cmp	x2, #0x0
    2390:      	b.ne	0x24dc <_stogir.cfg.build+0x384>
    2394:      	str	w23, [sp, #0x278]
    2398:      	str	w24, [sp, #0x280]
    239c:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		000000000000239c:  ARM64_RELOC_PAGE21	l_stogir.405
    23a0:      	ldr	x21, [x21]
		00000000000023a0:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    23a4:      	mov	x22, #0x1e              ; =30
    23a8:      	b	0x2284 <_stogir.cfg.build+0x12c>
    23ac:      	ldr	x20, [sp, #0x270]
    23b0:      	add	x0, sp, #0x1d0
    23b4:      	bl	0x23b4 <_stogir.cfg.build+0x25c>
		00000000000023b4:  ARM64_RELOC_BRANCH26	_coil.core.Iterator$coil.slice.SliceIter$next__i32
    23b8:      	ubfx	x0, x0, #0, #32
    23bc:      	lsr	x16, x0, #0
    23c0:      	cmp	x16, #0x1
    23c4:      	b.eq	0x23e0 <_stogir.cfg.build+0x288>
    23c8:      	b.lo	0x23d0 <_stogir.cfg.build+0x278>
    23cc:      	b	0x23e4 <_stogir.cfg.build+0x28c>
    23d0:      	cmp	x16, #0x0
    23d4:      	b.eq	0x23dc <_stogir.cfg.build+0x284>
    23d8:      	b	0x23e4 <_stogir.cfg.build+0x28c>
    23dc:      	b	0x2434 <_stogir.cfg.build+0x2dc>
    23e0:      	b	0x23e8 <_stogir.cfg.build+0x290>
    23e4:      	b	0x2ca4 <_stogir.cfg.build+0xb4c>
    23e8:      	ldr	x0, [x20]
    23ec:      	sxtw	x2, w1
    23f0:      	orr	w23, w1, wzr
    23f4:      	orr	w24, w1, wzr
    23f8:      	add	x0, x0, x2, lsl #4
    23fc:      	ldr	x0, [x0]
    2400:      	ldr	x1, [x20, #0x78]
    2404:      	uxtb	w0, w0
    2408:      	add	x1, x1, x2, lsl #2
    240c:      	cmp	x0, #0x83
    2410:      	cset	w25, lt
    2414:      	adrp	x16, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002414:  ARM64_RELOC_PAGE21	l_stogir.406
    2418:      	ldr	x16, [x16]
		0000000000002418:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    241c:      	add	x0, x16, x0, lsl #2
    2420:      	ldr	w1, [x1]
    2424:      	orr	x26, x0, xzr
    2428:      	sxtw	x27, w1
    242c:      	mov	x28, #0x1               ; =1
    2430:      	b	0x2298 <_stogir.cfg.build+0x140>
    2434:      	add	x0, sp, #0x150
    2438:      	bl	0x2438 <_stogir.cfg.build+0x2e0>
		0000000000002438:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    243c:      	mov	x0, x21
    2440:      	mov	x1, x22
    2444:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002444:  ARM64_RELOC_PAGE21	l_stogir.407
    2448:      	ldr	x2, [x2]
		0000000000002448:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    244c:      	movz	x3, #0x0, lsl #48
    2450:      	bl	0x2450 <_stogir.cfg.build+0x2f8>
		0000000000002450:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2454:      	cmp	x0, #0x0
    2458:      	b.eq	0x2544 <_stogir.cfg.build+0x3ec>
    245c:      	add	x16, sp, #0x40
    2460:      	ldr	x21, [x16]
    2464:      	add	x16, sp, #0x40
    2468:      	ldr	x22, [x16, #0x8]
    246c:      	add	x16, sp, #0x40
    2470:      	ldr	x0, [x16, #0x10]
    2474:      	add	x16, sp, #0x40
    2478:      	ldr	x1, [x16, #0x18]
    247c:      	add	x16, sp, #0x40
    2480:      	ldr	x2, [x16, #0x20]
    2484:      	add	x16, sp, #0x40
    2488:      	ldr	x3, [x16, #0x28]
    248c:      	add	x16, sp, #0x40
    2490:      	ldr	x4, [x16, #0x30]
    2494:      	add	x16, sp, #0x40
    2498:      	ldr	x5, [x16, #0x38]
    249c:      	add	x16, sp, #0x40
    24a0:      	ldr	x6, [x16, #0x40]
    24a4:      	add	x16, sp, #0x40
    24a8:      	ldr	x7, [x16, #0x48]
    24ac:      	add	x16, sp, #0x40
    24b0:      	ldr	x8, [x16, #0x50]
    24b4:      	add	x16, sp, #0x40
    24b8:      	ldr	x9, [x16, #0x58]
    24bc:      	add	x16, sp, #0x40
    24c0:      	ldr	x10, [x16, #0x60]
    24c4:      	add	x16, sp, #0x40
    24c8:      	ldr	x11, [x16, #0x68]
    24cc:      	add	x16, sp, #0x40
    24d0:      	ldr	x12, [x16, #0x70]
    24d4:      	movz	x13, #0x0, lsl #48
    24d8:      	b	0x2584 <_stogir.cfg.build+0x42c>
    24dc:      	add	x16, sp, #0x210
    24e0:      	movz	x17, #0x0, lsl #48
    24e4:      	str	x17, [x16]
    24e8:      	add	x16, sp, #0x210
    24ec:      	movz	x17, #0x0, lsl #48
    24f0:      	str	x17, [x16, #0x8]
    24f4:      	add	x16, sp, #0x210
    24f8:      	str	w0, [x16]
    24fc:      	add	x16, sp, #0x210
    2500:      	str	w24, [x16, #0x4]
    2504:      	add	x16, sp, #0x210
    2508:      	str	w1, [x16, #0x8]
    250c:      	add	x16, sp, #0x210
    2510:      	str	w20, [x16, #0xc]
    2514:      	add	x16, sp, #0x210
    2518:      	ldr	x20, [x16]
    251c:      	add	x16, sp, #0x210
    2520:      	ldr	x0, [x16, #0x8]
    2524:      	ldr	x1, [x19, #0x8]
    2528:      	ldr	x2, [x19, #0x10]
    252c:      	cmp	x1, x2
    2530:      	b.lt	0x2ccc <_stogir.cfg.build+0xb74>
    2534:      	cmp	x2, #0x0
    2538:      	b.ne	0x2248 <_stogir.cfg.build+0xf0>
    253c:      	mov	x2, #0x2                ; =2
    2540:      	b	0x224c <_stogir.cfg.build+0xf4>
    2544:      	add	x0, sp, #0x40
    2548:      	bl	0x2548 <_stogir.cfg.build+0x3f0>
		0000000000002548:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    254c:      	mov	x13, #0x1               ; =1
    2550:      	movz	x0, #0x0, lsl #48
    2554:      	movz	x1, #0x0, lsl #48
    2558:      	movz	x2, #0x0, lsl #48
    255c:      	movz	x3, #0x0, lsl #48
    2560:      	movz	x4, #0x0, lsl #48
    2564:      	movz	x5, #0x0, lsl #48
    2568:      	movz	x6, #0x0, lsl #48
    256c:      	movz	x7, #0x0, lsl #48
    2570:      	movz	x8, #0x0, lsl #48
    2574:      	movz	x9, #0x0, lsl #48
    2578:      	movz	x10, #0x0, lsl #48
    257c:      	movz	x11, #0x0, lsl #48
    2580:      	movz	x12, #0x0, lsl #48
    2584:      	ldr	x14, [sp, #0x258]
    2588:      	str	x13, [x14]
    258c:      	str	x21, [x14, #0x8]
    2590:      	str	x22, [x14, #0x10]
    2594:      	str	x0, [x14, #0x18]
    2598:      	str	x1, [x14, #0x20]
    259c:      	str	x2, [x14, #0x28]
    25a0:      	str	x3, [x14, #0x30]
    25a4:      	str	x4, [x14, #0x38]
    25a8:      	str	x5, [x14, #0x40]
    25ac:      	str	x6, [x14, #0x48]
    25b0:      	str	x7, [x14, #0x50]
    25b4:      	str	x8, [x14, #0x58]
    25b8:      	str	x9, [x14, #0x60]
    25bc:      	str	x10, [x14, #0x68]
    25c0:      	str	x11, [x14, #0x70]
    25c4:      	str	x12, [x14, #0x78]
    25c8:      	ldr	x19, [sp, #0x288]
    25cc:      	ldr	x20, [sp, #0x290]
    25d0:      	ldr	x21, [sp, #0x298]
    25d4:      	ldr	x22, [sp, #0x2a0]
    25d8:      	ldr	x23, [sp, #0x2a8]
    25dc:      	ldr	x24, [sp, #0x2b0]
    25e0:      	ldr	x25, [sp, #0x2b8]
    25e4:      	ldr	x26, [sp, #0x2c0]
    25e8:      	ldr	x27, [sp, #0x2c8]
    25ec:      	ldr	x28, [sp, #0x2d0]
    25f0:      	ldr	x29, [sp, #0x10]
    25f4:      	ldr	x30, [sp, #0x18]
    25f8:      	add	sp, sp, #0x2e0
    25fc:      	ret
    2600:      	add	x16, sp, #0x40
    2604:      	orr	x23, x16, xzr
    2608:      	add	x8, sp, #0xc0
    260c:      	mov	x0, x21
    2610:      	bl	0x2610 <_stogir.cfg.build+0x4b8>
		0000000000002610:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    2614:      	add	x24, x20, #0x78
    2618:      	add	x0, x23, #0x28
    261c:      	add	x1, x23, #0x28
    2620:      	add	x16, sp, #0xc0
    2624:      	ldr	x22, [x16]
    2628:      	orr	x25, x0, xzr
    262c:      	orr	x26, x1, xzr
    2630:      	add	x16, sp, #0xc0
    2634:      	ldr	x27, [x16, #0x8]
    2638:      	add	x16, sp, #0xc0
    263c:      	ldr	x28, [x16, #0x10]
    2640:      	add	x16, sp, #0xc0
    2644:      	ldr	x0, [x16, #0x18]
    2648:      	add	x16, sp, #0xc0
    264c:      	ldr	x1, [x16, #0x20]
    2650:      	add	x8, sp, #0xf0
    2654:      	str	x21, [sp, #0x240]
    2658:      	str	x25, [sp, #0x248]
    265c:      	mov	x25, x1
    2660:      	fmov	d31, x0
    2664:      	mov	x0, x21
    2668:      	fmov	x21, d31
    266c:      	bl	0x266c <_stogir.cfg.build+0x514>
		000000000000266c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    2670:      	add	x16, sp, #0xf0
    2674:      	ldr	x0, [x16]
    2678:      	add	x16, sp, #0xf0
    267c:      	ldr	x1, [x16, #0x8]
    2680:      	add	x16, sp, #0xf0
    2684:      	ldr	x2, [x16, #0x10]
    2688:      	add	x16, sp, #0xf0
    268c:      	ldr	x3, [x16, #0x18]
    2690:      	add	x16, sp, #0xf0
    2694:      	ldr	x4, [x16, #0x20]
    2698:      	add	x8, sp, #0x120
    269c:      	str	x26, [sp, #0x250]
    26a0:      	mov	x26, x0
    26a4:      	ldr	x0, [sp, #0x240]
    26a8:      	str	x19, [sp, #0x258]
    26ac:      	mov	x19, x1
    26b0:      	str	x23, [sp, #0x260]
    26b4:      	mov	x23, x2
    26b8:      	str	x24, [sp, #0x268]
    26bc:      	mov	x24, x3
    26c0:      	str	x20, [sp, #0x270]
    26c4:      	mov	x20, x4
    26c8:      	bl	0x26c8 <_stogir.cfg.build+0x570>
		00000000000026c8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge
    26cc:      	add	x16, sp, #0x120
    26d0:      	ldr	x0, [x16]
    26d4:      	add	x16, sp, #0x120
    26d8:      	ldr	x1, [x16, #0x8]
    26dc:      	add	x16, sp, #0x120
    26e0:      	ldr	x2, [x16, #0x10]
    26e4:      	add	x16, sp, #0x120
    26e8:      	ldr	x3, [x16, #0x18]
    26ec:      	add	x16, sp, #0x120
    26f0:      	ldr	x4, [x16, #0x20]
    26f4:      	add	x16, sp, #0x40
    26f8:      	str	x22, [x16]
    26fc:      	add	x16, sp, #0x40
    2700:      	str	x27, [x16, #0x8]
    2704:      	add	x16, sp, #0x40
    2708:      	str	x28, [x16, #0x10]
    270c:      	add	x16, sp, #0x40
    2710:      	str	x21, [x16, #0x18]
    2714:      	add	x16, sp, #0x40
    2718:      	str	x25, [x16, #0x20]
    271c:      	add	x16, sp, #0x40
    2720:      	str	x26, [x16, #0x28]
    2724:      	add	x16, sp, #0x40
    2728:      	str	x19, [x16, #0x30]
    272c:      	add	x16, sp, #0x40
    2730:      	str	x23, [x16, #0x38]
    2734:      	add	x16, sp, #0x40
    2738:      	str	x24, [x16, #0x40]
    273c:      	add	x16, sp, #0x40
    2740:      	str	x20, [x16, #0x48]
    2744:      	add	x16, sp, #0x40
    2748:      	str	x0, [x16, #0x50]
    274c:      	add	x16, sp, #0x40
    2750:      	str	x1, [x16, #0x58]
    2754:      	add	x16, sp, #0x40
    2758:      	str	x2, [x16, #0x60]
    275c:      	add	x16, sp, #0x40
    2760:      	str	x3, [x16, #0x68]
    2764:      	add	x16, sp, #0x40
    2768:      	str	x4, [x16, #0x70]
    276c:      	add	x8, sp, #0x180
    2770:      	ldr	x0, [sp, #0x240]
    2774:      	bl	0x2774 <_stogir.cfg.build+0x61c>
		0000000000002774:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    2778:      	add	x16, sp, #0x180
    277c:      	ldr	x0, [x16]
    2780:      	add	x16, sp, #0x150
    2784:      	str	x0, [x16]
    2788:      	add	x16, sp, #0x180
    278c:      	ldr	x0, [x16, #0x8]
    2790:      	add	x16, sp, #0x150
    2794:      	str	x0, [x16, #0x8]
    2798:      	add	x16, sp, #0x180
    279c:      	ldr	x0, [x16, #0x10]
    27a0:      	add	x16, sp, #0x150
    27a4:      	str	x0, [x16, #0x10]
    27a8:      	add	x16, sp, #0x180
    27ac:      	ldr	x0, [x16, #0x18]
    27b0:      	add	x16, sp, #0x150
    27b4:      	str	x0, [x16, #0x18]
    27b8:      	add	x16, sp, #0x180
    27bc:      	ldr	x0, [x16, #0x20]
    27c0:      	add	x16, sp, #0x150
    27c4:      	str	x0, [x16, #0x20]
    27c8:      	ldr	x0, [sp, #0x270]
    27cc:      	bl	0x27cc <_stogir.cfg.build+0x674>
		00000000000027cc:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    27d0:      	mov	x1, x0
    27d4:      	ldr	x0, [sp, #0x248]
    27d8:      	bl	0x27d8 <_stogir.cfg.build+0x680>
		00000000000027d8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    27dc:      	mov	x19, #0x1               ; =1
    27e0:      	b	0x282c <_stogir.cfg.build+0x6d4>
    27e4:      	nop
    27e8:      	orr	w0, w19, wzr
    27ec:      	orr	w22, w0, wzr
    27f0:      	add	x0, sp, #0x40
    27f4:      	mov	w1, w22
    27f8:      	bl	0x27f8 <_stogir.cfg.build+0x6a0>
		00000000000027f8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    27fc:      	ldr	x0, [sp, #0x250]
    2800:      	mov	x1, x19
    2804:      	mov	w2, w22
    2808:      	bl	0x2808 <_stogir.cfg.build+0x6b0>
		0000000000002808:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    280c:      	sxtw	x21, w21
    2810:      	add	x0, x21, #0x4
    2814:      	asr	x16, x0, #63
    2818:      	lsr	x16, x16, #62
    281c:      	add	x0, x0, x16
    2820:      	asr	x0, x0, #2
    2824:      	add	x19, x0, x19
    2828:      	str	x20, [sp, #0x270]
    282c:      	ldr	x20, [sp, #0x270]
    2830:      	ldr	x0, [x20, #0x8]
    2834:      	cmp	x19, x0
    2838:      	b.ge	0x2868 <_stogir.cfg.build+0x710>
    283c:      	ldr	x0, [x20]
    2840:      	add	x0, x0, x19, lsl #4
    2844:      	ldr	x0, [x0]
    2848:      	ldr	x1, [x20, #0x78]
    284c:      	uxtb	w0, w0
    2850:      	add	x1, x1, x19, lsl #2
    2854:      	ldr	w21, [x1]
    2858:      	bl	0x2858 <_stogir.cfg.build+0x700>
		0000000000002858:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-start?
    285c:      	cmp	x0, #0x0
    2860:      	b.ne	0x27e8 <_stogir.cfg.build+0x690>
    2864:      	b	0x280c <_stogir.cfg.build+0x6b4>
    2868:      	mov	x19, #0x1               ; =1
    286c:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		000000000000286c:  ARM64_RELOC_PAGE21	l_stogir.407
    2870:      	ldr	x21, [x21]
		0000000000002870:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2874:      	movz	x22, #0x0, lsl #48
    2878:      	b	0x291c <_stogir.cfg.build+0x7c4>
    287c:      	movz	w1, #0x0, lsl #16
    2880:      	movz	w0, #0x0, lsl #16
    2884:      	b	0x2ab4 <_stogir.cfg.build+0x95c>
    2888:      	movz	w3, #0x0, lsl #16
    288c:      	movz	w4, #0x0, lsl #16
    2890:      	ubfx	x3, x3, #0, #32
    2894:      	lsr	x16, x3, #0
    2898:      	cmp	x16, #0x1
    289c:      	b.eq	0x28b8 <_stogir.cfg.build+0x760>
    28a0:      	b.lo	0x28a8 <_stogir.cfg.build+0x750>
    28a4:      	b	0x28bc <_stogir.cfg.build+0x764>
    28a8:      	cmp	x16, #0x0
    28ac:      	b.eq	0x28b4 <_stogir.cfg.build+0x75c>
    28b0:      	b	0x28bc <_stogir.cfg.build+0x764>
    28b4:      	b	0x28fc <_stogir.cfg.build+0x7a4>
    28b8:      	b	0x28c0 <_stogir.cfg.build+0x768>
    28bc:      	b	0x2c8c <_stogir.cfg.build+0xb34>
    28c0:      	sxtw	x4, w4
    28c4:      	add	x16, sp, #0x40
    28c8:      	ldr	x3, [x16, #0x28]
    28cc:      	add	x3, x3, x4, lsl #2
    28d0:      	str	w25, [x3]
    28d4:      	cmp	x2, x1
    28d8:      	b.ge	0x2888 <_stogir.cfg.build+0x730>
    28dc:      	add	x3, x2, #0x1
    28e0:      	add	x2, x0, x2, lsl #2
    28e4:      	ldr	w2, [x2]
    28e8:      	movn	w17, #0x0, lsl #16
    28ec:      	and	w4, w2, w17
    28f0:      	mov	x2, x3
    28f4:      	mov	w3, #0x1                ; =1
    28f8:      	b	0x2890 <_stogir.cfg.build+0x738>
    28fc:      	sxtw	x23, w23
    2900:      	add	x0, x23, #0x4
    2904:      	asr	x16, x0, #63
    2908:      	lsr	x16, x16, #62
    290c:      	add	x0, x0, x16
    2910:      	asr	x0, x0, #2
    2914:      	add	x19, x0, x19
    2918:      	str	x26, [sp, #0x268]
    291c:      	mov	x0, x21
    2920:      	mov	x1, x22
    2924:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002924:  ARM64_RELOC_PAGE21	l_stogir.407
    2928:      	ldr	x2, [x2]
		0000000000002928:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    292c:      	movz	x3, #0x0, lsl #48
    2930:      	bl	0x2930 <_stogir.cfg.build+0x7d8>
		0000000000002930:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2934:      	cmp	x0, #0x0
    2938:      	b.eq	0x2950 <_stogir.cfg.build+0x7f8>
    293c:      	ldr	x0, [x20, #0x8]
    2940:      	cmp	x19, x0
    2944:      	cset	w0, lt
    2948:      	ubfx	x0, x0, #0, #8
    294c:      	b	0x2954 <_stogir.cfg.build+0x7fc>
    2950:      	movz	x0, #0x0, lsl #48
    2954:      	cmp	x0, #0x0
    2958:      	b.eq	0x2c08 <_stogir.cfg.build+0xab0>
    295c:      	ldr	x0, [x20]
    2960:      	add	x0, x0, x19, lsl #4
    2964:      	ldr	x0, [x0]
    2968:      	ldr	x1, [x20, #0x78]
    296c:      	uxtb	w0, w0
    2970:      	add	x1, x1, x19, lsl #2
    2974:      	ldr	w23, [x1]
    2978:      	bl	0x2978 <_stogir.cfg.build+0x820>
		0000000000002978:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    297c:      	cmp	x0, #0x0
    2980:      	b.eq	0x29a8 <_stogir.cfg.build+0x850>
    2984:      	add	x16, sp, #0x40
    2988:      	ldr	x0, [x16, #0x28]
    298c:      	add	x0, x0, x19, lsl #2
    2990:      	ldr	w0, [x0]
    2994:      	sxtw	x0, w0
    2998:      	cmp	x0, #0x0
    299c:      	cset	w0, eq
    29a0:      	ubfx	x0, x0, #0, #8
    29a4:      	b	0x29ac <_stogir.cfg.build+0x854>
    29a8:      	movz	x0, #0x0, lsl #48
    29ac:      	cmp	x0, #0x0
    29b0:      	b.eq	0x2ce0 <_stogir.cfg.build+0xb88>
    29b4:      	orr	w24, w19, wzr
    29b8:      	add	x0, sp, #0x150
    29bc:      	bl	0x29bc <_stogir.cfg.build+0x864>
		00000000000029bc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$clear!__i32
    29c0:      	sxtw	x24, w24
    29c4:      	movz	x25, #0x0, lsl #48
    29c8:      	b	0x2a30 <_stogir.cfg.build+0x8d8>
    29cc:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		00000000000029cc:  ARM64_RELOC_PAGE21	l_stogir.408
    29d0:      	ldr	x21, [x21]
		00000000000029d0:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    29d4:      	mov	x22, #0x1b              ; =27
    29d8:      	b	0x2a2c <_stogir.cfg.build+0x8d4>
    29dc:      	nop
    29e0:      	movz	x0, #0x0, lsl #48
    29e4:      	cmp	x0, #0x0
    29e8:      	b.eq	0x2ce8 <_stogir.cfg.build+0xb90>
    29ec:      	add	x16, sp, #0x40
    29f0:      	ldr	x0, [x16, #0x28]
    29f4:      	add	x0, x0, x24, lsl #2
    29f8:      	ldr	w0, [x0]
    29fc:      	sxtw	x25, w0
    2a00:      	cmp	x25, #0x0
    2a04:      	b.ne	0x2cf0 <_stogir.cfg.build+0xb98>
    2a08:      	add	x16, sp, #0x150
    2a0c:      	ldr	x0, [x16, #0x8]
    2a10:      	ldr	x1, [x20, #0x8]
    2a14:      	cmp	x0, x1
    2a18:      	b.lt	0x2a48 <_stogir.cfg.build+0x8f0>
    2a1c:      	ldr	x26, [sp, #0x268]
    2a20:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002a20:  ARM64_RELOC_PAGE21	l_stogir.409
    2a24:      	ldr	x21, [x21]
		0000000000002a24:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    2a28:      	mov	x22, #0x27              ; =39
    2a2c:      	str	x26, [sp, #0x268]
    2a30:      	cmp	x22, #0x0
    2a34:      	b.ne	0x29e0 <_stogir.cfg.build+0x888>
    2a38:      	cmp	x25, #0x0
    2a3c:      	cset	w0, eq
    2a40:      	ubfx	x0, x0, #0, #8
    2a44:      	b	0x29e4 <_stogir.cfg.build+0x88c>
    2a48:      	orr	x26, x0, xzr
    2a4c:      	add	x16, sp, #0x150
    2a50:      	ldr	x0, [x16, #0x10]
    2a54:      	cmp	x26, x0
    2a58:      	b.lt	0x2a7c <_stogir.cfg.build+0x924>
    2a5c:      	cmp	x0, #0x0
    2a60:      	b.ne	0x2a6c <_stogir.cfg.build+0x914>
    2a64:      	mov	x0, #0x2                ; =2
    2a68:      	b	0x2a70 <_stogir.cfg.build+0x918>
    2a6c:      	lsl	x0, x0, #1
    2a70:      	mov	x1, x0
    2a74:      	add	x0, sp, #0x150
    2a78:      	bl	0x2a78 <_stogir.cfg.build+0x920>
		0000000000002a78:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    2a7c:      	orr	w0, w24, wzr
    2a80:      	add	x1, x26, #0x1
    2a84:      	sxtw	x2, w0
    2a88:      	add	x16, sp, #0x150
    2a8c:      	ldr	x3, [x16]
    2a90:      	add	x3, x3, x26, lsl #2
    2a94:      	str	w0, [x3]
    2a98:      	add	x16, sp, #0x150
    2a9c:      	str	x1, [x16, #0x8]
    2aa0:      	cmp	x2, #0x0
    2aa4:      	b.gt	0x2af4 <_stogir.cfg.build+0x99c>
    2aa8:      	ldr	x26, [sp, #0x268]
    2aac:      	movz	w1, #0x0, lsl #16
    2ab0:      	movz	w0, #0x0, lsl #16
    2ab4:      	ubfx	x1, x1, #0, #32
    2ab8:      	lsr	x16, x1, #0
    2abc:      	cmp	x16, #0x1
    2ac0:      	b.eq	0x2adc <_stogir.cfg.build+0x984>
    2ac4:      	b.lo	0x2acc <_stogir.cfg.build+0x974>
    2ac8:      	b	0x2ae0 <_stogir.cfg.build+0x988>
    2acc:      	cmp	x16, #0x0
    2ad0:      	b.eq	0x2ad8 <_stogir.cfg.build+0x980>
    2ad4:      	b	0x2ae0 <_stogir.cfg.build+0x988>
    2ad8:      	b	0x2ae4 <_stogir.cfg.build+0x98c>
    2adc:      	b	0x2b7c <_stogir.cfg.build+0xa24>
    2ae0:      	b	0x2c94 <_stogir.cfg.build+0xb3c>
    2ae4:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002ae4:  ARM64_RELOC_PAGE21	l_stogir.410
    2ae8:      	ldr	x21, [x21]
		0000000000002ae8:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    2aec:      	mov	x22, #0x1e              ; =30
    2af0:      	b	0x29d8 <_stogir.cfg.build+0x880>
    2af4:      	lsl	x0, x2, #2
    2af8:      	ldr	x1, [x20, #0x8]
    2afc:      	cmp	x2, x1
    2b00:      	b.ge	0x2cf8 <_stogir.cfg.build+0xba0>
    2b04:      	ldr	x26, [sp, #0x268]
    2b08:      	ldr	x1, [x26, #0x8]
    2b0c:      	cmp	x2, x1
    2b10:      	b.ge	0x2bc0 <_stogir.cfg.build+0xa68>
    2b14:      	ldr	x1, [x20, #0x78]
    2b18:      	add	x1, x0, x1
    2b1c:      	ldr	w1, [x1]
    2b20:      	sxtw	x1, w1
    2b24:      	cmp	x1, #0x0
    2b28:      	cset	w1, ge
    2b2c:      	ubfx	x1, x1, #0, #8
    2b30:      	b	0x2bc4 <_stogir.cfg.build+0xa6c>
    2b34:      	mov	x0, x21
    2b38:      	mov	x1, x22
    2b3c:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002b3c:  ARM64_RELOC_PAGE21	l_stogir.407
    2b40:      	ldr	x2, [x2]
		0000000000002b40:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2b44:      	movz	x3, #0x0, lsl #48
    2b48:      	bl	0x2b48 <_stogir.cfg.build+0x9f0>
		0000000000002b48:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2b4c:      	cmp	x0, #0x0
    2b50:      	b.eq	0x28fc <_stogir.cfg.build+0x7a4>
    2b54:      	add	x8, sp, #0x1b0
    2b58:      	add	x0, sp, #0x150
    2b5c:      	bl	0x2b5c <_stogir.cfg.build+0xa04>
		0000000000002b5c:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2b60:      	add	x16, sp, #0x1b0
    2b64:      	ldr	x0, [x16]
    2b68:      	add	x16, sp, #0x1b0
    2b6c:      	ldr	x1, [x16, #0x8]
    2b70:      	add	x16, sp, #0x1b0
    2b74:      	ldr	x2, [x16, #0x10]
    2b78:      	b	0x28d4 <_stogir.cfg.build+0x77c>
    2b7c:      	sxtw	x0, w0
    2b80:      	cmp	x0, #0x0
    2b84:      	b.le	0x29cc <_stogir.cfg.build+0x874>
    2b88:      	ldr	x1, [x20, #0x8]
    2b8c:      	cmp	x0, x1
    2b90:      	b.ge	0x2c70 <_stogir.cfg.build+0xb18>
    2b94:      	ldr	x1, [x26, #0x8]
    2b98:      	cmp	x0, x1
    2b9c:      	b.ge	0x2c84 <_stogir.cfg.build+0xb2c>
    2ba0:      	ldr	x1, [x20, #0x78]
    2ba4:      	add	x1, x1, x0, lsl #2
    2ba8:      	ldr	w1, [x1]
    2bac:      	sxtw	x1, w1
    2bb0:      	cmp	x1, #0x0
    2bb4:      	cset	w1, ge
    2bb8:      	ubfx	x1, x1, #0, #8
    2bbc:      	b	0x2c88 <_stogir.cfg.build+0xb30>
    2bc0:      	movz	x1, #0x0, lsl #48
    2bc4:      	b	0x2bcc <_stogir.cfg.build+0xa74>
    2bc8:      	movz	x1, #0x0, lsl #48
    2bcc:      	cmp	x1, #0x0
    2bd0:      	b.eq	0x2aac <_stogir.cfg.build+0x954>
    2bd4:      	ldr	x1, [x20, #0x78]
    2bd8:      	add	x0, x0, x1
    2bdc:      	ldr	w0, [x0]
    2be0:      	sxtw	x0, w0
    2be4:      	cmp	x0, #0x1
    2be8:      	b.lt	0x287c <_stogir.cfg.build+0x724>
    2bec:      	ldr	x0, [x20]
    2bf0:      	add	x0, x0, x2, lsl #4
    2bf4:      	ldr	w0, [x0, #0x4]
    2bf8:      	movn	w17, #0x0, lsl #16
    2bfc:      	and	w0, w0, w17
    2c00:      	mov	w1, #0x1                ; =1
    2c04:      	b	0x2884 <_stogir.cfg.build+0x72c>
    2c08:      	mov	x0, x21
    2c0c:      	mov	x1, x22
    2c10:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002c10:  ARM64_RELOC_PAGE21	l_stogir.407
    2c14:      	ldr	x2, [x2]
		0000000000002c14:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2c18:      	movz	x3, #0x0, lsl #48
    2c1c:      	bl	0x2c1c <_stogir.cfg.build+0xac4>
		0000000000002c1c:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2c20:      	cmp	x0, #0x0
    2c24:      	b.eq	0x2434 <_stogir.cfg.build+0x2dc>
    2c28:      	ldr	x0, [sp, #0x260]
    2c2c:      	add	x19, x0, #0x50
    2c30:      	add	x8, sp, #0x1f0
    2c34:      	add	x0, sp, #0x40
    2c38:      	bl	0x2c38 <_stogir.cfg.build+0xae0>
		0000000000002c38:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2c3c:      	add	x16, sp, #0x1f0
    2c40:      	ldr	x0, [x16]
    2c44:      	add	x16, sp, #0x1d0
    2c48:      	str	x0, [x16]
    2c4c:      	add	x16, sp, #0x1f0
    2c50:      	ldr	x0, [x16, #0x8]
    2c54:      	add	x16, sp, #0x1d0
    2c58:      	str	x0, [x16, #0x8]
    2c5c:      	add	x16, sp, #0x1f0
    2c60:      	ldr	x0, [x16, #0x10]
    2c64:      	add	x16, sp, #0x1d0
    2c68:      	str	x0, [x16, #0x10]
    2c6c:      	b	0x23b0 <_stogir.cfg.build+0x258>
    2c70:      	movz	x1, #0x0, lsl #48
    2c74:      	cmp	x1, #0x0
    2c78:      	b.eq	0x29cc <_stogir.cfg.build+0x874>
    2c7c:      	mov	x24, x0
    2c80:      	b	0x29d8 <_stogir.cfg.build+0x880>
    2c84:      	movz	x1, #0x0, lsl #48
    2c88:      	b	0x2c74 <_stogir.cfg.build+0xb1c>
    2c8c:      	brk	#0
    2c90:      	b	0x2c8c <_stogir.cfg.build+0xb34>
    2c94:      	brk	#0
    2c98:      	b	0x2c94 <_stogir.cfg.build+0xb3c>
    2c9c:      	brk	#0
    2ca0:      	b	0x2c9c <_stogir.cfg.build+0xb44>
    2ca4:      	brk	#0
    2ca8:      	b	0x2ca4 <_stogir.cfg.build+0xb4c>
    2cac:      	brk	#0
    2cb0:      	b	0x2cac <_stogir.cfg.build+0xb54>
    2cb4:      	str	x20, [sp, #0x270]
    2cb8:      	b	0x23ac <_stogir.cfg.build+0x254>
    2cbc:      	str	x20, [sp, #0x270]
    2cc0:      	str	w23, [sp, #0x278]
    2cc4:      	str	w24, [sp, #0x280]
    2cc8:      	b	0x2284 <_stogir.cfg.build+0x12c>
    2ccc:      	str	w23, [sp, #0x278]
    2cd0:      	str	w24, [sp, #0x280]
    2cd4:      	mov	x23, x0
    2cd8:      	mov	x24, x1
    2cdc:      	b	0x2268 <_stogir.cfg.build+0x110>
    2ce0:      	ldr	x26, [sp, #0x268]
    2ce4:      	b	0x28fc <_stogir.cfg.build+0x7a4>
    2ce8:      	ldr	x26, [sp, #0x268]
    2cec:      	b	0x2b34 <_stogir.cfg.build+0x9dc>
    2cf0:      	ldr	x26, [sp, #0x268]
    2cf4:      	b	0x2a2c <_stogir.cfg.build+0x8d4>
    2cf8:      	ldr	x26, [sp, #0x268]
    2cfc:      	b	0x2bc8 <_stogir.cfg.build+0xa70>

0000000000002d00 <_stogir.adjacency.build>:
    2d00:      	sub	sp, sp, #0x70
    2d04:      	str	x29, [sp]
    2d08:      	str	x30, [sp, #0x8]
    2d0c:      	mov	x29, sp
    2d10:      	str	x19, [sp, #0x18]
    2d14:      	str	x20, [sp, #0x20]
    2d18:      	str	x21, [sp, #0x28]
    2d1c:      	str	x22, [sp, #0x30]
    2d20:      	str	x23, [sp, #0x38]
    2d24:      	str	x24, [sp, #0x40]
    2d28:      	str	x25, [sp, #0x48]
    2d2c:      	str	x26, [sp, #0x50]
    2d30:      	str	x27, [sp, #0x58]
    2d34:      	str	x28, [sp, #0x60]
    2d38:      	add	x3, x0, #0x28
    2d3c:      	ldr	x3, [x3, #0x8]
    2d40:      	orr	x19, x3, xzr
    2d44:      	mov	x20, sp
    2d48:      	sub	sp, sp, #0x50
    2d4c:      	mov	x21, sp
    2d50:      	sub	sp, sp, #0x30
    2d54:      	mov	x22, sp
    2d58:      	ldr	x3, [x2]
    2d5c:      	ldr	x2, [x2, #0x8]
    2d60:      	movz	x17, #0x0, lsl #48
    2d64:      	str	x17, [x21]
    2d68:      	movz	x17, #0x0, lsl #48
    2d6c:      	str	x17, [x21, #0x8]
    2d70:      	movz	x17, #0x0, lsl #48
    2d74:      	str	x17, [x21, #0x10]
    2d78:      	str	x3, [x21, #0x18]
    2d7c:      	str	x2, [x21, #0x20]
    2d80:      	movz	x17, #0x0, lsl #48
    2d84:      	str	x17, [x21, #0x28]
    2d88:      	movz	x17, #0x0, lsl #48
    2d8c:      	str	x17, [x21, #0x30]
    2d90:      	movz	x17, #0x0, lsl #48
    2d94:      	str	x17, [x21, #0x38]
    2d98:      	str	x3, [x21, #0x40]
    2d9c:      	str	x2, [x21, #0x48]
    2da0:      	movz	x17, #0x0, lsl #48
    2da4:      	str	x17, [x22]
    2da8:      	movz	x17, #0x0, lsl #48
    2dac:      	str	x17, [x22, #0x8]
    2db0:      	movz	x17, #0x0, lsl #48
    2db4:      	str	x17, [x22, #0x10]
    2db8:      	str	x3, [x22, #0x18]
    2dbc:      	str	x2, [x22, #0x20]
    2dc0:      	cmp	x19, #0x0
    2dc4:      	b.le	0x3170 <_stogir.adjacency.build+0x470>
    2dc8:      	cmp	x19, #0x0
    2dcc:      	b.ge	0x2dd8 <_stogir.adjacency.build+0xd8>
    2dd0:      	movz	x2, #0x0, lsl #48
    2dd4:      	b	0x2ddc <_stogir.adjacency.build+0xdc>
    2dd8:      	mov	x2, x19
    2ddc:      	mov	x23, x8
    2de0:      	mov	x24, x0
    2de4:      	mov	x0, x21
    2de8:      	mov	w25, w1
    2dec:      	mov	x1, x2
    2df0:      	bl	0x2df0 <_stogir.adjacency.build+0xf0>
		0000000000002df0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range
    2df4:      	lsl	x0, x19, #4
    2df8:      	ldr	x1, [x21]
    2dfc:      	mov	x2, x0
    2e00:      	mov	x0, x1
    2e04:      	movz	x1, #0x0, lsl #48
    2e08:      	bl	0x2e08 <_stogir.adjacency.build+0x108>
		0000000000002e08:  ARM64_RELOC_BRANCH26	_memset
    2e0c:      	str	x19, [x21, #0x8]
    2e10:      	ldr	x0, [x22, #0x8]
    2e14:      	orr	x26, x0, xzr
    2e18:      	ldr	x0, [x22, #0x10]
    2e1c:      	add	x27, x26, x19
    2e20:      	cmp	x27, x0
    2e24:      	b.le	0x2e58 <_stogir.adjacency.build+0x158>
    2e28:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2e2c:      	cmp	x0, x17
    2e30:      	b.gt	0x2e3c <_stogir.adjacency.build+0x13c>
    2e34:      	lsl	x0, x0, #1
    2e38:      	b	0x2e40 <_stogir.adjacency.build+0x140>
    2e3c:      	mov	x0, x27
    2e40:      	cmp	x0, x27
    2e44:      	b.gt	0x2e4c <_stogir.adjacency.build+0x14c>
    2e48:      	mov	x0, x27
    2e4c:      	mov	x1, x0
    2e50:      	mov	x0, x22
    2e54:      	bl	0x2e54 <_stogir.adjacency.build+0x154>
		0000000000002e54:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    2e58:      	add	x28, x24, #0x50
    2e5c:      	ubfx	x25, x25, #0, #8
    2e60:      	lsl	x0, x19, #3
    2e64:      	cmp	x25, #0x0
    2e68:      	cset	w19, ne
    2e6c:      	ldr	x1, [x22]
    2e70:      	add	x1, x1, x26, lsl #3
    2e74:      	mov	x2, x0
    2e78:      	mov	x0, x1
    2e7c:      	movz	x1, #0x0, lsl #48
    2e80:      	bl	0x2e80 <_stogir.adjacency.build+0x180>
		0000000000002e80:  ARM64_RELOC_BRANCH26	_memset
    2e84:      	str	x27, [x22, #0x8]
    2e88:      	ldr	x0, [x24, #0x50]
    2e8c:      	ldr	x1, [x28, #0x8]
    2e90:      	movz	x2, #0x0, lsl #48
    2e94:      	b	0x2ec0 <_stogir.adjacency.build+0x1c0>
    2e98:      	sxtw	x3, w4
    2e9c:      	ldr	x4, [x21]
    2ea0:      	orr	x5, x4, xzr
    2ea4:      	add	x5, x5, x3, lsl #4
    2ea8:      	add	x3, x4, x3, lsl #4
    2eac:      	ldr	x4, [x5]
    2eb0:      	ldr	x5, [x5, #0x8]
    2eb4:      	add	x5, x5, #0x1
    2eb8:      	str	x4, [x3]
    2ebc:      	str	x5, [x3, #0x8]
    2ec0:      	cmp	x2, x1
    2ec4:      	b.ge	0x2ee0 <_stogir.adjacency.build+0x1e0>
    2ec8:      	add	x3, x2, #0x1
    2ecc:      	add	x2, x0, x2, lsl #4
    2ed0:      	ldr	x4, [x2]
    2ed4:      	mov	x2, x3
    2ed8:      	mov	w3, #0x1                ; =1
    2edc:      	b	0x2ee8 <_stogir.adjacency.build+0x1e8>
    2ee0:      	movz	w3, #0x0, lsl #16
    2ee4:      	movz	x4, #0x0, lsl #48
    2ee8:      	ubfx	x3, x3, #0, #32
    2eec:      	lsr	x16, x3, #0
    2ef0:      	cmp	x16, #0x1
    2ef4:      	b.eq	0x2f10 <_stogir.adjacency.build+0x210>
    2ef8:      	b.lo	0x2f00 <_stogir.adjacency.build+0x200>
    2efc:      	b	0x2f14 <_stogir.adjacency.build+0x214>
    2f00:      	cmp	x16, #0x0
    2f04:      	b.eq	0x2f0c <_stogir.adjacency.build+0x20c>
    2f08:      	b	0x2f14 <_stogir.adjacency.build+0x214>
    2f0c:      	b	0x2f2c <_stogir.adjacency.build+0x22c>
    2f10:      	b	0x2f18 <_stogir.adjacency.build+0x218>
    2f14:      	b	0x3168 <_stogir.adjacency.build+0x468>
    2f18:      	uxtb	w16, w19
    2f1c:      	cmp	w16, wzr
    2f20:      	b.eq	0x2e98 <_stogir.adjacency.build+0x198>
    2f24:      	asr	x3, x4, #32
    2f28:      	b	0x2e9c <_stogir.adjacency.build+0x19c>
    2f2c:      	movz	x0, #0x0, lsl #48
    2f30:      	movz	x1, #0x0, lsl #48
    2f34:      	b	0x2f70 <_stogir.adjacency.build+0x270>
    2f38:      	add	x2, x0, #0x1
    2f3c:      	ldr	x3, [x21]
    2f40:      	orr	x4, x3, xzr
    2f44:      	add	x4, x4, x0, lsl #4
    2f48:      	add	x3, x3, x0, lsl #4
    2f4c:      	ldr	x4, [x4, #0x8]
    2f50:      	add	x5, x4, x1
    2f54:      	str	x1, [x3]
    2f58:      	str	x4, [x3, #0x8]
    2f5c:      	ldr	x3, [x22]
    2f60:      	add	x0, x3, x0, lsl #3
    2f64:      	str	x1, [x0]
    2f68:      	mov	x0, x2
    2f6c:      	mov	x1, x5
    2f70:      	ldr	x2, [x21, #0x8]
    2f74:      	cmp	x0, x2
    2f78:      	b.lt	0x2f38 <_stogir.adjacency.build+0x238>
    2f7c:      	add	x19, x21, #0x28
    2f80:      	ldr	x0, [x28, #0x8]
    2f84:      	orr	x26, x0, xzr
    2f88:      	ldr	x0, [x19, #0x8]
    2f8c:      	orr	x27, x0, xzr
    2f90:      	ldr	x0, [x19, #0x10]
    2f94:      	add	x1, x27, x26
    2f98:      	cmp	x1, x0
    2f9c:      	b.le	0x3180 <_stogir.adjacency.build+0x480>
    2fa0:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2fa4:      	cmp	x0, x17
    2fa8:      	b.gt	0x2fb4 <_stogir.adjacency.build+0x2b4>
    2fac:      	lsl	x0, x0, #1
    2fb0:      	b	0x2fb8 <_stogir.adjacency.build+0x2b8>
    2fb4:      	mov	x0, x1
    2fb8:      	cmp	x0, x1
    2fbc:      	b.gt	0x2fc4 <_stogir.adjacency.build+0x2c4>
    2fc0:      	mov	x0, x1
    2fc4:      	str	x23, [x29, #0x10]
    2fc8:      	mov	x23, x1
    2fcc:      	mov	x1, x0
    2fd0:      	mov	x0, x19
    2fd4:      	bl	0x2fd4 <_stogir.adjacency.build+0x2d4>
		0000000000002fd4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    2fd8:      	cmp	x25, #0x0
    2fdc:      	cset	w25, ne
    2fe0:      	lsl	x0, x26, #3
    2fe4:      	ldr	x1, [x21, #0x28]
    2fe8:      	add	x1, x1, x27, lsl #3
    2fec:      	mov	x2, x0
    2ff0:      	mov	x0, x1
    2ff4:      	movz	x1, #0x0, lsl #48
    2ff8:      	bl	0x2ff8 <_stogir.adjacency.build+0x2f8>
		0000000000002ff8:  ARM64_RELOC_BRANCH26	_memset
    2ffc:      	str	x23, [x19, #0x8]
    3000:      	movz	x0, #0x0, lsl #48
    3004:      	b	0x303c <_stogir.adjacency.build+0x33c>
    3008:      	sxtw	x1, w1
    300c:      	add	x2, x0, #0x1
    3010:      	ldr	x3, [x22]
    3014:      	add	x3, x3, x1, lsl #3
    3018:      	ldr	x3, [x3]
    301c:      	ldr	x4, [x21, #0x28]
    3020:      	add	x5, x3, #0x1
    3024:      	add	x3, x4, x3, lsl #3
    3028:      	str	x0, [x3]
    302c:      	ldr	x0, [x22]
    3030:      	add	x0, x0, x1, lsl #3
    3034:      	str	x5, [x0]
    3038:      	mov	x0, x2
    303c:      	ldr	x1, [x28, #0x8]
    3040:      	cmp	x0, x1
    3044:      	b.ge	0x3068 <_stogir.adjacency.build+0x368>
    3048:      	ldr	x1, [x24, #0x50]
    304c:      	add	x1, x1, x0, lsl #4
    3050:      	ldr	x1, [x1]
    3054:      	uxtb	w16, w25
    3058:      	cmp	w16, wzr
    305c:      	b.eq	0x3008 <_stogir.adjacency.build+0x308>
    3060:      	asr	x1, x1, #32
    3064:      	b	0x300c <_stogir.adjacency.build+0x30c>
    3068:      	b	0x3078 <_stogir.adjacency.build+0x378>
    306c:      	nop
    3070:      	sub	x0, x0, #0x1
    3074:      	str	x0, [x22, #0x8]
    3078:      	ldr	x0, [x22, #0x8]
    307c:      	cmp	x0, #0x0
    3080:      	b.ne	0x3070 <_stogir.adjacency.build+0x370>
    3084:      	ldr	x0, [x22, #0x10]
    3088:      	cmp	x0, #0x0
    308c:      	b.le	0x30bc <_stogir.adjacency.build+0x3bc>
    3090:      	add	x1, x22, #0x18
    3094:      	ldr	x2, [x22]
    3098:      	fmov	d31, x0
    309c:      	mov	x0, x1
    30a0:      	mov	x1, x2
    30a4:      	fmov	x2, d31
    30a8:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		00000000000030a8:  ARM64_RELOC_PAGE21	l_stogir.411
    30ac:      	ldr	x3, [x3]
		00000000000030ac:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    30b0:      	mov	x4, #0x8                ; =8
    30b4:      	mov	x5, #0x8                ; =8
    30b8:      	bl	0x30b8 <_stogir.adjacency.build+0x3b8>
		00000000000030b8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    30bc:      	movz	x17, #0x0, lsl #48
    30c0:      	str	x17, [x22]
    30c4:      	movz	x17, #0x0, lsl #48
    30c8:      	str	x17, [x22, #0x8]
    30cc:      	movz	x17, #0x0, lsl #48
    30d0:      	str	x17, [x22, #0x10]
    30d4:      	ldr	x0, [x21]
    30d8:      	ldr	x1, [x21, #0x8]
    30dc:      	ldr	x2, [x21, #0x10]
    30e0:      	ldr	x3, [x21, #0x18]
    30e4:      	ldr	x4, [x21, #0x20]
    30e8:      	ldr	x5, [x21, #0x28]
    30ec:      	ldr	x6, [x21, #0x30]
    30f0:      	ldr	x7, [x21, #0x38]
    30f4:      	ldr	x8, [x21, #0x40]
    30f8:      	ldr	x9, [x21, #0x48]
    30fc:      	mov	sp, x20
    3100:      	ldr	x10, [x29, #0x10]
    3104:      	str	x0, [x10]
    3108:      	str	x1, [x10, #0x8]
    310c:      	str	x2, [x10, #0x10]
    3110:      	str	x3, [x10, #0x18]
    3114:      	str	x4, [x10, #0x20]
    3118:      	str	x5, [x10, #0x28]
    311c:      	str	x6, [x10, #0x30]
    3120:      	str	x7, [x10, #0x38]
    3124:      	str	x8, [x10, #0x40]
    3128:      	str	x9, [x10, #0x48]
    312c:      	sub	sp, x29, #0x0
    3130:      	ldr	x19, [sp, #0x18]
    3134:      	ldr	x20, [sp, #0x20]
    3138:      	ldr	x21, [sp, #0x28]
    313c:      	ldr	x22, [sp, #0x30]
    3140:      	ldr	x23, [sp, #0x38]
    3144:      	ldr	x24, [sp, #0x40]
    3148:      	ldr	x25, [sp, #0x48]
    314c:      	ldr	x26, [sp, #0x50]
    3150:      	ldr	x27, [sp, #0x58]
    3154:      	ldr	x28, [sp, #0x60]
    3158:      	ldr	x29, [sp]
    315c:      	ldr	x30, [sp, #0x8]
    3160:      	add	sp, sp, #0x70
    3164:      	ret
    3168:      	brk	#0
    316c:      	b	0x3168 <_stogir.adjacency.build+0x468>
    3170:      	mov	x23, x8
    3174:      	mov	x24, x0
    3178:      	mov	w25, w1
    317c:      	b	0x2df4 <_stogir.adjacency.build+0xf4>
    3180:      	str	x23, [x29, #0x10]
    3184:      	mov	x23, x1
    3188:      	b	0x2fd8 <_stogir.adjacency.build+0x2d8>
    318c:      	udf	#0x0

0000000000003190 <_stogir.adjacency.reverse-postorder>:
    3190:      	sub	sp, sp, #0x120
    3194:      	str	x29, [sp]
    3198:      	str	x30, [sp, #0x8]
    319c:      	mov	x29, sp
    31a0:      	str	x19, [sp, #0xf0]
    31a4:      	str	x20, [sp, #0xf8]
    31a8:      	str	x21, [sp, #0x100]
    31ac:      	str	x22, [sp, #0x108]
    31b0:      	str	x23, [sp, #0x110]
    31b4:      	str	x24, [sp, #0x118]
    31b8:      	add	x4, x0, #0x28
    31bc:      	ldr	x5, [x3]
    31c0:      	ldr	x3, [x3, #0x8]
    31c4:      	add	x16, sp, #0x10
    31c8:      	movz	x17, #0x0, lsl #48
    31cc:      	str	x17, [x16]
    31d0:      	add	x16, sp, #0x10
    31d4:      	movz	x17, #0x0, lsl #48
    31d8:      	str	x17, [x16, #0x8]
    31dc:      	add	x16, sp, #0x10
    31e0:      	movz	x17, #0x0, lsl #48
    31e4:      	str	x17, [x16, #0x10]
    31e8:      	add	x16, sp, #0x10
    31ec:      	str	x5, [x16, #0x18]
    31f0:      	add	x16, sp, #0x10
    31f4:      	str	x3, [x16, #0x20]
    31f8:      	add	x16, sp, #0x40
    31fc:      	movz	x17, #0x0, lsl #48
    3200:      	str	x17, [x16]
    3204:      	add	x16, sp, #0x40
    3208:      	movz	x17, #0x0, lsl #48
    320c:      	str	x17, [x16, #0x8]
    3210:      	add	x16, sp, #0x40
    3214:      	movz	x17, #0x0, lsl #48
    3218:      	str	x17, [x16, #0x10]
    321c:      	add	x16, sp, #0x40
    3220:      	str	x5, [x16, #0x18]
    3224:      	add	x16, sp, #0x40
    3228:      	str	x3, [x16, #0x20]
    322c:      	add	x16, sp, #0x70
    3230:      	movz	x17, #0x0, lsl #48
    3234:      	str	x17, [x16]
    3238:      	add	x16, sp, #0x70
    323c:      	movz	x17, #0x0, lsl #48
    3240:      	str	x17, [x16, #0x8]
    3244:      	add	x16, sp, #0x70
    3248:      	movz	x17, #0x0, lsl #48
    324c:      	str	x17, [x16, #0x10]
    3250:      	add	x16, sp, #0x70
    3254:      	str	x5, [x16, #0x18]
    3258:      	add	x16, sp, #0x70
    325c:      	str	x3, [x16, #0x20]
    3260:      	add	x16, sp, #0xa0
    3264:      	movz	x17, #0x0, lsl #48
    3268:      	str	x17, [x16]
    326c:      	add	x16, sp, #0xa0
    3270:      	movz	x17, #0x0, lsl #48
    3274:      	str	x17, [x16, #0x8]
    3278:      	add	x16, sp, #0xa0
    327c:      	movz	x17, #0x0, lsl #48
    3280:      	str	x17, [x16, #0x10]
    3284:      	add	x16, sp, #0xa0
    3288:      	str	x5, [x16, #0x18]
    328c:      	add	x16, sp, #0xa0
    3290:      	str	x3, [x16, #0x20]
    3294:      	ldr	x3, [x4, #0x8]
    3298:      	orr	x19, x3, xzr
    329c:      	cmp	x19, #0x0
    32a0:      	b.le	0x37d8 <_stogir.adjacency.reverse-postorder+0x648>
    32a4:      	cmp	x19, #0x0
    32a8:      	b.ge	0x32b4 <_stogir.adjacency.reverse-postorder+0x124>
    32ac:      	movz	x3, #0x0, lsl #48
    32b0:      	b	0x32b8 <_stogir.adjacency.reverse-postorder+0x128>
    32b4:      	mov	x3, x19
    32b8:      	mov	x20, x8
    32bc:      	mov	x21, x0
    32c0:      	add	x0, sp, #0x10
    32c4:      	mov	x22, x1
    32c8:      	mov	x1, x3
    32cc:      	mov	w23, w2
    32d0:      	bl	0x32d0 <_stogir.adjacency.reverse-postorder+0x140>
		00000000000032d0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    32d4:      	lsr	x0, x19, #0
    32d8:      	add	x16, sp, #0x10
    32dc:      	ldr	x1, [x16]
    32e0:      	mov	x2, x0
    32e4:      	mov	x0, x1
    32e8:      	movz	x1, #0x0, lsl #48
    32ec:      	bl	0x32ec <_stogir.adjacency.reverse-postorder+0x15c>
		00000000000032ec:  ARM64_RELOC_BRANCH26	_memset
    32f0:      	add	x16, sp, #0x10
    32f4:      	str	x19, [x16, #0x8]
    32f8:      	add	x16, sp, #0xd0
    32fc:      	movz	x17, #0x0, lsl #48
    3300:      	str	x17, [x16]
    3304:      	add	x16, sp, #0xd0
    3308:      	movz	x17, #0x0, lsl #48
    330c:      	str	x17, [x16, #0x8]
    3310:      	add	x16, sp, #0xd0
    3314:      	str	w23, [x16]
    3318:      	add	x16, sp, #0xd0
    331c:      	movz	x17, #0x0, lsl #48
    3320:      	str	x17, [x16, #0x8]
    3324:      	add	x16, sp, #0xd0
    3328:      	ldr	x19, [x16]
    332c:      	add	x16, sp, #0x40
    3330:      	ldr	x0, [x16, #0x8]
    3334:      	orr	x24, x0, xzr
    3338:      	add	x16, sp, #0x40
    333c:      	ldr	x0, [x16, #0x10]
    3340:      	cmp	x24, x0
    3344:      	b.lt	0x3368 <_stogir.adjacency.reverse-postorder+0x1d8>
    3348:      	cmp	x0, #0x0
    334c:      	b.ne	0x3358 <_stogir.adjacency.reverse-postorder+0x1c8>
    3350:      	mov	x0, #0x2                ; =2
    3354:      	b	0x335c <_stogir.adjacency.reverse-postorder+0x1cc>
    3358:      	lsl	x0, x0, #1
    335c:      	mov	x1, x0
    3360:      	add	x0, sp, #0x40
    3364:      	bl	0x3364 <_stogir.adjacency.reverse-postorder+0x1d4>
		0000000000003364:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    3368:      	sxtw	x23, w23
    336c:      	add	x0, x24, #0x1
    3370:      	add	x16, sp, #0x40
    3374:      	ldr	x1, [x16]
    3378:      	add	x1, x1, x24, lsl #4
    337c:      	str	x19, [x1]
    3380:      	movz	x17, #0x0, lsl #48
    3384:      	str	x17, [x1, #0x8]
    3388:      	add	x16, sp, #0x40
    338c:      	str	x0, [x16, #0x8]
    3390:      	add	x16, sp, #0x10
    3394:      	ldr	x0, [x16]
    3398:      	add	x0, x0, x23
    339c:      	mov	w17, #0x1               ; =1
    33a0:      	strb	w17, [x0]
    33a4:      	b	0x3428 <_stogir.adjacency.reverse-postorder+0x298>
    33a8:      	lsl	x0, x0, #1
    33ac:      	mov	x1, x0
    33b0:      	add	x0, sp, #0x70
    33b4:      	bl	0x33b4 <_stogir.adjacency.reverse-postorder+0x224>
		00000000000033b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    33b8:      	add	x0, x23, #0x1
    33bc:      	add	x16, sp, #0x70
    33c0:      	ldr	x1, [x16]
    33c4:      	add	x1, x1, x23, lsl #2
    33c8:      	str	w19, [x1]
    33cc:      	add	x16, sp, #0x70
    33d0:      	str	x0, [x16, #0x8]
    33d4:      	add	x16, sp, #0x40
    33d8:      	ldr	x0, [x16, #0x8]
    33dc:      	cmp	x0, #0x0
    33e0:      	b.eq	0x3428 <_stogir.adjacency.reverse-postorder+0x298>
    33e4:      	sub	x0, x0, #0x1
    33e8:      	add	x16, sp, #0x40
    33ec:      	str	x0, [x16, #0x8]
    33f0:      	b	0x3428 <_stogir.adjacency.reverse-postorder+0x298>
    33f4:      	lsl	x0, x0, #1
    33f8:      	mov	x1, x0
    33fc:      	add	x0, sp, #0x40
    3400:      	bl	0x3400 <_stogir.adjacency.reverse-postorder+0x270>
		0000000000003400:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    3404:      	add	x0, x23, #0x1
    3408:      	add	x16, sp, #0x40
    340c:      	ldr	x1, [x16]
    3410:      	add	x1, x1, x23, lsl #4
    3414:      	str	x19, [x1]
    3418:      	movz	x17, #0x0, lsl #48
    341c:      	str	x17, [x1, #0x8]
    3420:      	add	x16, sp, #0x40
    3424:      	str	x0, [x16, #0x8]
    3428:      	add	x16, sp, #0x40
    342c:      	ldr	x0, [x16, #0x8]
    3430:      	cmp	x0, #0x0
    3434:      	b.le	0x3554 <_stogir.adjacency.reverse-postorder+0x3c4>
    3438:      	add	x16, sp, #0x40
    343c:      	ldr	x1, [x16]
    3440:      	sub	x0, x0, #0x1
    3444:      	add	x2, x1, x0, lsl #4
    3448:      	ldr	x3, [x2]
    344c:      	orr	w19, w3, wzr
    3450:      	ldr	x2, [x2, #0x8]
    3454:      	sxtw	x4, w19
    3458:      	ldr	x5, [x22]
    345c:      	add	x4, x5, x4, lsl #4
    3460:      	ldr	x5, [x4]
    3464:      	ldr	x4, [x4, #0x8]
    3468:      	cmp	x2, x4
    346c:      	b.lt	0x349c <_stogir.adjacency.reverse-postorder+0x30c>
    3470:      	add	x16, sp, #0x70
    3474:      	ldr	x0, [x16, #0x8]
    3478:      	orr	x23, x0, xzr
    347c:      	add	x16, sp, #0x70
    3480:      	ldr	x0, [x16, #0x10]
    3484:      	cmp	x23, x0
    3488:      	b.lt	0x33b8 <_stogir.adjacency.reverse-postorder+0x228>
    348c:      	cmp	x0, #0x0
    3490:      	b.ne	0x33a8 <_stogir.adjacency.reverse-postorder+0x218>
    3494:      	mov	x0, #0x2                ; =2
    3498:      	b	0x33ac <_stogir.adjacency.reverse-postorder+0x21c>
    349c:      	add	x4, x2, x5
    34a0:      	add	x2, x2, #0x1
    34a4:      	ldr	x5, [x22, #0x28]
    34a8:      	add	x0, x1, x0, lsl #4
    34ac:      	add	x1, x5, x4, lsl #3
    34b0:      	ldr	x1, [x1]
    34b4:      	ldr	x4, [x21, #0x50]
    34b8:      	add	x1, x4, x1, lsl #4
    34bc:      	ldr	x1, [x1]
    34c0:      	str	x3, [x0]
    34c4:      	lsr	x1, x1, #32
    34c8:      	str	x2, [x0, #0x8]
    34cc:      	sxtw	x0, w1
    34d0:      	add	x16, sp, #0x10
    34d4:      	ldr	x2, [x16]
    34d8:      	add	x3, x2, x0
    34dc:      	ldrb	w3, [x3]
    34e0:      	cmp	x3, #0x0
    34e4:      	b.ne	0x3428 <_stogir.adjacency.reverse-postorder+0x298>
    34e8:      	add	x0, x2, x0
    34ec:      	mov	w17, #0x1               ; =1
    34f0:      	strb	w17, [x0]
    34f4:      	add	x16, sp, #0xe0
    34f8:      	movz	x17, #0x0, lsl #48
    34fc:      	str	x17, [x16]
    3500:      	add	x16, sp, #0xe0
    3504:      	movz	x17, #0x0, lsl #48
    3508:      	str	x17, [x16, #0x8]
    350c:      	add	x16, sp, #0xe0
    3510:      	str	w1, [x16]
    3514:      	add	x16, sp, #0xe0
    3518:      	movz	x17, #0x0, lsl #48
    351c:      	str	x17, [x16, #0x8]
    3520:      	add	x16, sp, #0xe0
    3524:      	ldr	x19, [x16]
    3528:      	add	x16, sp, #0x40
    352c:      	ldr	x0, [x16, #0x8]
    3530:      	orr	x23, x0, xzr
    3534:      	add	x16, sp, #0x40
    3538:      	ldr	x0, [x16, #0x10]
    353c:      	cmp	x23, x0
    3540:      	b.lt	0x3404 <_stogir.adjacency.reverse-postorder+0x274>
    3544:      	cmp	x0, #0x0
    3548:      	b.ne	0x33f4 <_stogir.adjacency.reverse-postorder+0x264>
    354c:      	mov	x0, #0x2                ; =2
    3550:      	b	0x33f8 <_stogir.adjacency.reverse-postorder+0x268>
    3554:      	add	x16, sp, #0x70
    3558:      	ldr	x0, [x16, #0x8]
    355c:      	orr	x19, x0, xzr
    3560:      	b	0x3594 <_stogir.adjacency.reverse-postorder+0x404>
    3564:      	nop
    3568:      	lsl	x0, x0, #1
    356c:      	mov	x1, x0
    3570:      	add	x0, sp, #0xa0
    3574:      	bl	0x3574 <_stogir.adjacency.reverse-postorder+0x3e4>
		0000000000003574:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3578:      	add	x0, x22, #0x1
    357c:      	add	x16, sp, #0xa0
    3580:      	ldr	x1, [x16]
    3584:      	add	x1, x1, x22, lsl #2
    3588:      	str	w21, [x1]
    358c:      	add	x16, sp, #0xa0
    3590:      	str	x0, [x16, #0x8]
    3594:      	cmp	x19, #0x0
    3598:      	b.le	0x35dc <_stogir.adjacency.reverse-postorder+0x44c>
    359c:      	sub	x19, x19, #0x1
    35a0:      	add	x16, sp, #0x70
    35a4:      	ldr	x0, [x16]
    35a8:      	add	x0, x0, x19, lsl #2
    35ac:      	ldr	w21, [x0]
    35b0:      	add	x16, sp, #0xa0
    35b4:      	ldr	x0, [x16, #0x8]
    35b8:      	orr	x22, x0, xzr
    35bc:      	add	x16, sp, #0xa0
    35c0:      	ldr	x0, [x16, #0x10]
    35c4:      	cmp	x22, x0
    35c8:      	b.lt	0x3578 <_stogir.adjacency.reverse-postorder+0x3e8>
    35cc:      	cmp	x0, #0x0
    35d0:      	b.ne	0x3568 <_stogir.adjacency.reverse-postorder+0x3d8>
    35d4:      	mov	x0, #0x2                ; =2
    35d8:      	b	0x356c <_stogir.adjacency.reverse-postorder+0x3dc>
    35dc:      	b	0x35ec <_stogir.adjacency.reverse-postorder+0x45c>
    35e0:      	sub	x0, x0, #0x1
    35e4:      	add	x16, sp, #0x10
    35e8:      	str	x0, [x16, #0x8]
    35ec:      	add	x16, sp, #0x10
    35f0:      	ldr	x0, [x16, #0x8]
    35f4:      	cmp	x0, #0x0
    35f8:      	b.ne	0x35e0 <_stogir.adjacency.reverse-postorder+0x450>
    35fc:      	add	x16, sp, #0x10
    3600:      	orr	x0, x16, xzr
    3604:      	add	x16, sp, #0x10
    3608:      	ldr	x1, [x16, #0x10]
    360c:      	cmp	x1, #0x0
    3610:      	b.le	0x3640 <_stogir.adjacency.reverse-postorder+0x4b0>
    3614:      	add	x0, x0, #0x18
    3618:      	add	x16, sp, #0x10
    361c:      	ldr	x2, [x16]
    3620:      	fmov	d31, x1
    3624:      	mov	x1, x2
    3628:      	fmov	x2, d31
    362c:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		000000000000362c:  ARM64_RELOC_PAGE21	l_stogir.412
    3630:      	ldr	x3, [x3]
		0000000000003630:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    3634:      	mov	x4, #0x1                ; =1
    3638:      	mov	x5, #0x1                ; =1
    363c:      	bl	0x363c <_stogir.adjacency.reverse-postorder+0x4ac>
		000000000000363c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3640:      	add	x16, sp, #0x10
    3644:      	movz	x17, #0x0, lsl #48
    3648:      	str	x17, [x16]
    364c:      	add	x16, sp, #0x10
    3650:      	movz	x17, #0x0, lsl #48
    3654:      	str	x17, [x16, #0x8]
    3658:      	add	x16, sp, #0x10
    365c:      	movz	x17, #0x0, lsl #48
    3660:      	str	x17, [x16, #0x10]
    3664:      	b	0x3674 <_stogir.adjacency.reverse-postorder+0x4e4>
    3668:      	sub	x0, x0, #0x1
    366c:      	add	x16, sp, #0x40
    3670:      	str	x0, [x16, #0x8]
    3674:      	add	x16, sp, #0x40
    3678:      	ldr	x0, [x16, #0x8]
    367c:      	cmp	x0, #0x0
    3680:      	b.ne	0x3668 <_stogir.adjacency.reverse-postorder+0x4d8>
    3684:      	add	x16, sp, #0x40
    3688:      	orr	x0, x16, xzr
    368c:      	add	x16, sp, #0x40
    3690:      	ldr	x1, [x16, #0x10]
    3694:      	cmp	x1, #0x0
    3698:      	b.le	0x36c8 <_stogir.adjacency.reverse-postorder+0x538>
    369c:      	add	x0, x0, #0x18
    36a0:      	add	x16, sp, #0x40
    36a4:      	ldr	x2, [x16]
    36a8:      	fmov	d31, x1
    36ac:      	mov	x1, x2
    36b0:      	fmov	x2, d31
    36b4:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		00000000000036b4:  ARM64_RELOC_PAGE21	l_stogir.413
    36b8:      	ldr	x3, [x3]
		00000000000036b8:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    36bc:      	mov	x4, #0x10               ; =16
    36c0:      	mov	x5, #0x8                ; =8
    36c4:      	bl	0x36c4 <_stogir.adjacency.reverse-postorder+0x534>
		00000000000036c4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    36c8:      	add	x16, sp, #0x40
    36cc:      	movz	x17, #0x0, lsl #48
    36d0:      	str	x17, [x16]
    36d4:      	add	x16, sp, #0x40
    36d8:      	movz	x17, #0x0, lsl #48
    36dc:      	str	x17, [x16, #0x8]
    36e0:      	add	x16, sp, #0x40
    36e4:      	movz	x17, #0x0, lsl #48
    36e8:      	str	x17, [x16, #0x10]
    36ec:      	b	0x36fc <_stogir.adjacency.reverse-postorder+0x56c>
    36f0:      	sub	x0, x0, #0x1
    36f4:      	add	x16, sp, #0x70
    36f8:      	str	x0, [x16, #0x8]
    36fc:      	add	x16, sp, #0x70
    3700:      	ldr	x0, [x16, #0x8]
    3704:      	cmp	x0, #0x0
    3708:      	b.ne	0x36f0 <_stogir.adjacency.reverse-postorder+0x560>
    370c:      	add	x16, sp, #0x70
    3710:      	orr	x0, x16, xzr
    3714:      	add	x16, sp, #0x70
    3718:      	ldr	x1, [x16, #0x10]
    371c:      	cmp	x1, #0x0
    3720:      	b.le	0x3750 <_stogir.adjacency.reverse-postorder+0x5c0>
    3724:      	add	x0, x0, #0x18
    3728:      	add	x16, sp, #0x70
    372c:      	ldr	x2, [x16]
    3730:      	fmov	d31, x1
    3734:      	mov	x1, x2
    3738:      	fmov	x2, d31
    373c:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		000000000000373c:  ARM64_RELOC_PAGE21	l_stogir.414
    3740:      	ldr	x3, [x3]
		0000000000003740:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    3744:      	mov	x4, #0x4                ; =4
    3748:      	mov	x5, #0x4                ; =4
    374c:      	bl	0x374c <_stogir.adjacency.reverse-postorder+0x5bc>
		000000000000374c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3750:      	add	x16, sp, #0x70
    3754:      	movz	x17, #0x0, lsl #48
    3758:      	str	x17, [x16]
    375c:      	add	x16, sp, #0x70
    3760:      	movz	x17, #0x0, lsl #48
    3764:      	str	x17, [x16, #0x8]
    3768:      	add	x16, sp, #0x70
    376c:      	movz	x17, #0x0, lsl #48
    3770:      	str	x17, [x16, #0x10]
    3774:      	add	x16, sp, #0xa0
    3778:      	ldr	x0, [x16]
    377c:      	add	x16, sp, #0xa0
    3780:      	ldr	x1, [x16, #0x8]
    3784:      	add	x16, sp, #0xa0
    3788:      	ldr	x2, [x16, #0x10]
    378c:      	add	x16, sp, #0xa0
    3790:      	ldr	x3, [x16, #0x18]
    3794:      	add	x16, sp, #0xa0
    3798:      	ldr	x4, [x16, #0x20]
    379c:      	str	x0, [x20]
    37a0:      	str	x1, [x20, #0x8]
    37a4:      	str	x2, [x20, #0x10]
    37a8:      	str	x3, [x20, #0x18]
    37ac:      	str	x4, [x20, #0x20]
    37b0:      	ldr	x19, [sp, #0xf0]
    37b4:      	ldr	x20, [sp, #0xf8]
    37b8:      	ldr	x21, [sp, #0x100]
    37bc:      	ldr	x22, [sp, #0x108]
    37c0:      	ldr	x23, [sp, #0x110]
    37c4:      	ldr	x24, [sp, #0x118]
    37c8:      	ldr	x29, [sp]
    37cc:      	ldr	x30, [sp, #0x8]
    37d0:      	add	sp, sp, #0x120
    37d4:      	ret
    37d8:      	mov	x20, x8
    37dc:      	mov	x21, x0
    37e0:      	mov	x22, x1
    37e4:      	mov	w23, w2
    37e8:      	b	0x32d4 <_stogir.adjacency.reverse-postorder+0x144>
    37ec:      	udf	#0x0

00000000000037f0 <_stogir.dominators.build>:
    37f0:      	sub	sp, sp, #0xb0
    37f4:      	str	x29, [sp]
    37f8:      	str	x30, [sp, #0x8]
    37fc:      	mov	x29, sp
    3800:      	str	x19, [sp, #0x70]
    3804:      	str	x20, [sp, #0x78]
    3808:      	str	x21, [sp, #0x80]
    380c:      	str	x22, [sp, #0x88]
    3810:      	str	x23, [sp, #0x90]
    3814:      	str	x24, [sp, #0x98]
    3818:      	str	x25, [sp, #0xa0]
    381c:      	add	x19, x0, #0x28
    3820:      	ldr	x4, [x3]
    3824:      	ldr	x3, [x3, #0x8]
    3828:      	add	x16, sp, #0x10
    382c:      	movz	x17, #0x0, lsl #48
    3830:      	str	x17, [x16]
    3834:      	add	x16, sp, #0x10
    3838:      	movz	x17, #0x0, lsl #48
    383c:      	str	x17, [x16, #0x8]
    3840:      	add	x16, sp, #0x10
    3844:      	movz	x17, #0x0, lsl #48
    3848:      	str	x17, [x16, #0x10]
    384c:      	add	x16, sp, #0x10
    3850:      	str	x4, [x16, #0x18]
    3854:      	add	x16, sp, #0x10
    3858:      	str	x3, [x16, #0x20]
    385c:      	add	x16, sp, #0x40
    3860:      	movz	x17, #0x0, lsl #48
    3864:      	str	x17, [x16]
    3868:      	add	x16, sp, #0x40
    386c:      	movz	x17, #0x0, lsl #48
    3870:      	str	x17, [x16, #0x8]
    3874:      	add	x16, sp, #0x40
    3878:      	movz	x17, #0x0, lsl #48
    387c:      	str	x17, [x16, #0x10]
    3880:      	add	x16, sp, #0x40
    3884:      	str	x4, [x16, #0x18]
    3888:      	add	x16, sp, #0x40
    388c:      	str	x3, [x16, #0x20]
    3890:      	ldr	x3, [x19, #0x8]
    3894:      	orr	x20, x3, xzr
    3898:      	cmp	x20, #0x0
    389c:      	b.le	0x3c34 <_stogir.dominators.build+0x444>
    38a0:      	cmp	x20, #0x0
    38a4:      	b.ge	0x38b0 <_stogir.dominators.build+0xc0>
    38a8:      	movz	x3, #0x0, lsl #48
    38ac:      	b	0x38b4 <_stogir.dominators.build+0xc4>
    38b0:      	mov	x3, x20
    38b4:      	mov	x21, x8
    38b8:      	mov	x22, x0
    38bc:      	add	x0, sp, #0x10
    38c0:      	mov	x23, x1
    38c4:      	mov	x1, x3
    38c8:      	mov	x24, x2
    38cc:      	bl	0x38cc <_stogir.dominators.build+0xdc>
		00000000000038cc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    38d0:      	lsl	x0, x20, #2
    38d4:      	add	x16, sp, #0x10
    38d8:      	ldr	x1, [x16]
    38dc:      	mov	x2, x0
    38e0:      	mov	x0, x1
    38e4:      	movz	x1, #0x0, lsl #48
    38e8:      	bl	0x38e8 <_stogir.dominators.build+0xf8>
		00000000000038e8:  ARM64_RELOC_BRANCH26	_memset
    38ec:      	add	x16, sp, #0x10
    38f0:      	str	x20, [x16, #0x8]
    38f4:      	movz	x20, #0x0, lsl #48
    38f8:      	b	0x3934 <_stogir.dominators.build+0x144>
    38fc:      	nop
    3900:      	lsl	x0, x0, #1
    3904:      	mov	x1, x0
    3908:      	add	x0, sp, #0x40
    390c:      	bl	0x390c <_stogir.dominators.build+0x11c>
		000000000000390c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    3910:      	add	x20, x20, #0x1
    3914:      	add	x0, x25, #0x1
    3918:      	add	x16, sp, #0x40
    391c:      	ldr	x1, [x16]
    3920:      	add	x1, x1, x25, lsl #3
    3924:      	movn	x17, #0x0, lsl #48
    3928:      	str	x17, [x1]
    392c:      	add	x16, sp, #0x40
    3930:      	str	x0, [x16, #0x8]
    3934:      	ldr	x0, [x19, #0x8]
    3938:      	cmp	x20, x0
    393c:      	b.ge	0x396c <_stogir.dominators.build+0x17c>
    3940:      	add	x16, sp, #0x40
    3944:      	ldr	x0, [x16, #0x8]
    3948:      	orr	x25, x0, xzr
    394c:      	add	x16, sp, #0x40
    3950:      	ldr	x0, [x16, #0x10]
    3954:      	cmp	x25, x0
    3958:      	b.lt	0x3910 <_stogir.dominators.build+0x120>
    395c:      	cmp	x0, #0x0
    3960:      	b.ne	0x3900 <_stogir.dominators.build+0x110>
    3964:      	mov	x0, #0x2                ; =2
    3968:      	b	0x3904 <_stogir.dominators.build+0x114>
    396c:      	movz	x0, #0x0, lsl #48
    3970:      	b	0x39a0 <_stogir.dominators.build+0x1b0>
    3974:      	nop
    3978:      	add	x1, x0, #0x1
    397c:      	ldr	x2, [x24]
    3980:      	add	x2, x2, x0, lsl #2
    3984:      	ldr	w2, [x2]
    3988:      	sxtw	x2, w2
    398c:      	add	x16, sp, #0x40
    3990:      	ldr	x3, [x16]
    3994:      	add	x2, x3, x2, lsl #3
    3998:      	str	x0, [x2]
    399c:      	mov	x0, x1
    39a0:      	ldr	x1, [x24, #0x8]
    39a4:      	cmp	x0, x1
    39a8:      	b.lt	0x3978 <_stogir.dominators.build+0x188>
    39ac:      	cmp	x1, #0x0
    39b0:      	b.le	0x3b40 <_stogir.dominators.build+0x350>
    39b4:      	ldr	x0, [x24]
    39b8:      	ldr	w0, [x0]
    39bc:      	sxtw	x1, w0
    39c0:      	add	x16, sp, #0x10
    39c4:      	ldr	x2, [x16]
    39c8:      	add	x1, x2, x1, lsl #2
    39cc:      	str	w0, [x1]
    39d0:      	b	0x3b34 <_stogir.dominators.build+0x344>
    39d4:      	nop
    39d8:      	add	x16, sp, #0x10
    39dc:      	ldr	x6, [x16]
    39e0:      	add	x6, x6, x11, lsl #2
    39e4:      	ldr	w6, [x6]
    39e8:      	add	x16, sp, #0x40
    39ec:      	ldr	x9, [x16]
    39f0:      	orr	x10, x9, xzr
    39f4:      	sxtw	x11, w6
    39f8:      	add	x9, x8, x9
    39fc:      	lsl	x12, x11, #3
    3a00:      	add	x10, x10, x11, lsl #3
    3a04:      	ldr	x10, [x10]
    3a08:      	ldr	x9, [x9]
    3a0c:      	cmp	x10, x9
    3a10:      	b.gt	0x39d8 <_stogir.dominators.build+0x1e8>
    3a14:      	b	0x3a28 <_stogir.dominators.build+0x238>
    3a18:      	add	x16, sp, #0x10
    3a1c:      	ldr	x7, [x16]
    3a20:      	add	x7, x7, x10, lsl #2
    3a24:      	ldr	w7, [x7]
    3a28:      	add	x16, sp, #0x40
    3a2c:      	ldr	x8, [x16]
    3a30:      	orr	x9, x8, xzr
    3a34:      	sxtw	x10, w7
    3a38:      	add	x8, x12, x8
    3a3c:      	add	x9, x9, x10, lsl #3
    3a40:      	ldr	x9, [x9]
    3a44:      	ldr	x8, [x8]
    3a48:      	cmp	x9, x8
    3a4c:      	b.gt	0x3a18 <_stogir.dominators.build+0x228>
    3a50:      	sxtw	x10, w6
    3a54:      	sxtw	x8, w7
    3a58:      	cmp	x10, x8
    3a5c:      	b.eq	0x3a68 <_stogir.dominators.build+0x278>
    3a60:      	lsl	x8, x8, #3
    3a64:      	b	0x39e8 <_stogir.dominators.build+0x1f8>
    3a68:      	orr	w6, w10, wzr
    3a6c:      	add	x5, x5, #0x1
    3a70:      	sxtw	x7, w6
    3a74:      	cmp	x5, x3
    3a78:      	b.ge	0x3ac8 <_stogir.dominators.build+0x2d8>
    3a7c:      	add	x8, x4, x5
    3a80:      	ldr	x9, [x23, #0x28]
    3a84:      	add	x8, x9, x8, lsl #3
    3a88:      	ldr	x8, [x8]
    3a8c:      	ldr	x9, [x22, #0x50]
    3a90:      	add	x8, x9, x8, lsl #4
    3a94:      	ldr	x8, [x8]
    3a98:      	add	x16, sp, #0x10
    3a9c:      	ldr	x9, [x16]
    3aa0:      	sxtw	x10, w8
    3aa4:      	add	x9, x9, x10, lsl #2
    3aa8:      	ldr	w9, [x9]
    3aac:      	sxtw	x9, w9
    3ab0:      	cmp	x9, #0x0
    3ab4:      	b.eq	0x3a6c <_stogir.dominators.build+0x27c>
    3ab8:      	cmp	x7, #0x0
    3abc:      	b.eq	0x3a68 <_stogir.dominators.build+0x278>
    3ac0:      	orr	w7, w8, wzr
    3ac4:      	b	0x3a50 <_stogir.dominators.build+0x260>
    3ac8:      	add	x16, sp, #0x10
    3acc:      	ldr	x3, [x16]
    3ad0:      	add	x4, x3, x2, lsl #2
    3ad4:      	ldr	w4, [x4]
    3ad8:      	sxtw	x4, w4
    3adc:      	cmp	x4, x7
    3ae0:      	b.eq	0x3af0 <_stogir.dominators.build+0x300>
    3ae4:      	add	x1, x3, x2, lsl #2
    3ae8:      	str	w6, [x1]
    3aec:      	mov	x1, #0x1                ; =1
    3af0:      	add	x0, x0, #0x1
    3af4:      	ldr	x2, [x24, #0x8]
    3af8:      	cmp	x0, x2
    3afc:      	b.ge	0x3b2c <_stogir.dominators.build+0x33c>
    3b00:      	ldr	x2, [x24]
    3b04:      	add	x2, x2, x0, lsl #2
    3b08:      	ldr	w2, [x2]
    3b0c:      	sxtw	x2, w2
    3b10:      	ldr	x3, [x23]
    3b14:      	add	x3, x3, x2, lsl #4
    3b18:      	ldr	x4, [x3]
    3b1c:      	ldr	x3, [x3, #0x8]
    3b20:      	movz	x5, #0x0, lsl #48
    3b24:      	movz	w6, #0x0, lsl #16
    3b28:      	b	0x3a70 <_stogir.dominators.build+0x280>
    3b2c:      	cmp	x1, #0x0
    3b30:      	b.eq	0x3b40 <_stogir.dominators.build+0x350>
    3b34:      	mov	x0, #0x1                ; =1
    3b38:      	movz	x1, #0x0, lsl #48
    3b3c:      	b	0x3af4 <_stogir.dominators.build+0x304>
    3b40:      	b	0x3b54 <_stogir.dominators.build+0x364>
    3b44:      	nop
    3b48:      	sub	x0, x0, #0x1
    3b4c:      	add	x16, sp, #0x40
    3b50:      	str	x0, [x16, #0x8]
    3b54:      	add	x16, sp, #0x40
    3b58:      	ldr	x0, [x16, #0x8]
    3b5c:      	cmp	x0, #0x0
    3b60:      	b.ne	0x3b48 <_stogir.dominators.build+0x358>
    3b64:      	add	x16, sp, #0x40
    3b68:      	orr	x0, x16, xzr
    3b6c:      	add	x16, sp, #0x40
    3b70:      	ldr	x1, [x16, #0x10]
    3b74:      	cmp	x1, #0x0
    3b78:      	b.le	0x3ba8 <_stogir.dominators.build+0x3b8>
    3b7c:      	add	x0, x0, #0x18
    3b80:      	add	x16, sp, #0x40
    3b84:      	ldr	x2, [x16]
    3b88:      	fmov	d31, x1
    3b8c:      	mov	x1, x2
    3b90:      	fmov	x2, d31
    3b94:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		0000000000003b94:  ARM64_RELOC_PAGE21	l_stogir.415
    3b98:      	ldr	x3, [x3]
		0000000000003b98:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    3b9c:      	mov	x4, #0x8                ; =8
    3ba0:      	mov	x5, #0x8                ; =8
    3ba4:      	bl	0x3ba4 <_stogir.dominators.build+0x3b4>
		0000000000003ba4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3ba8:      	add	x16, sp, #0x40
    3bac:      	movz	x17, #0x0, lsl #48
    3bb0:      	str	x17, [x16]
    3bb4:      	add	x16, sp, #0x40
    3bb8:      	movz	x17, #0x0, lsl #48
    3bbc:      	str	x17, [x16, #0x8]
    3bc0:      	add	x16, sp, #0x40
    3bc4:      	movz	x17, #0x0, lsl #48
    3bc8:      	str	x17, [x16, #0x10]
    3bcc:      	add	x16, sp, #0x10
    3bd0:      	ldr	x0, [x16]
    3bd4:      	add	x16, sp, #0x10
    3bd8:      	ldr	x1, [x16, #0x8]
    3bdc:      	add	x16, sp, #0x10
    3be0:      	ldr	x2, [x16, #0x10]
    3be4:      	add	x16, sp, #0x10
    3be8:      	ldr	x3, [x16, #0x18]
    3bec:      	add	x16, sp, #0x10
    3bf0:      	ldr	x4, [x16, #0x20]
    3bf4:      	str	x0, [x21]
    3bf8:      	str	x1, [x21, #0x8]
    3bfc:      	str	x2, [x21, #0x10]
    3c00:      	str	x3, [x21, #0x18]
    3c04:      	str	x4, [x21, #0x20]
    3c08:      	ldr	x19, [sp, #0x70]
    3c0c:      	ldr	x20, [sp, #0x78]
    3c10:      	ldr	x21, [sp, #0x80]
    3c14:      	ldr	x22, [sp, #0x88]
    3c18:      	ldr	x23, [sp, #0x90]
    3c1c:      	ldr	x24, [sp, #0x98]
    3c20:      	ldr	x25, [sp, #0xa0]
    3c24:      	ldr	x29, [sp]
    3c28:      	ldr	x30, [sp, #0x8]
    3c2c:      	add	sp, sp, #0xb0
    3c30:      	ret
    3c34:      	mov	x21, x8
    3c38:      	mov	x22, x0
    3c3c:      	mov	x23, x1
    3c40:      	mov	x24, x2
    3c44:      	b	0x38d0 <_stogir.dominators.build+0xe0>

0000000000003c48 <_stogir.loops.depths>:
    3c48:      	sub	sp, sp, #0x1d0
    3c4c:      	str	x29, [sp]
    3c50:      	str	x30, [sp, #0x8]
    3c54:      	mov	x29, sp
    3c58:      	str	x19, [sp, #0x180]
    3c5c:      	str	x20, [sp, #0x188]
    3c60:      	str	x21, [sp, #0x190]
    3c64:      	str	x22, [sp, #0x198]
    3c68:      	str	x23, [sp, #0x1a0]
    3c6c:      	str	x24, [sp, #0x1a8]
    3c70:      	str	x25, [sp, #0x1b0]
    3c74:      	str	x26, [sp, #0x1b8]
    3c78:      	str	x27, [sp, #0x1c0]
    3c7c:      	str	x28, [sp, #0x1c8]
    3c80:      	add	x19, x0, #0x28
    3c84:      	mov	x20, x8
    3c88:      	add	x8, sp, #0x60
    3c8c:      	mov	x21, x0
    3c90:      	mov	x0, x2
    3c94:      	mov	x22, x1
    3c98:      	mov	x1, x3
    3c9c:      	mov	x23, x2
    3ca0:      	mov	x24, x3
    3ca4:      	bl	0x3ca4 <_stogir.loops.depths+0x5c>
		0000000000003ca4:  ARM64_RELOC_BRANCH26	_stogir.dominators.build-index
    3ca8:      	add	x16, sp, #0x60
    3cac:      	ldr	x0, [x16]
    3cb0:      	add	x16, sp, #0x10
    3cb4:      	str	x0, [x16]
    3cb8:      	add	x16, sp, #0x60
    3cbc:      	ldr	x0, [x16, #0x8]
    3cc0:      	add	x16, sp, #0x10
    3cc4:      	str	x0, [x16, #0x8]
    3cc8:      	add	x16, sp, #0x60
    3ccc:      	ldr	x0, [x16, #0x10]
    3cd0:      	add	x16, sp, #0x10
    3cd4:      	str	x0, [x16, #0x10]
    3cd8:      	add	x16, sp, #0x60
    3cdc:      	ldr	x0, [x16, #0x18]
    3ce0:      	add	x16, sp, #0x10
    3ce4:      	str	x0, [x16, #0x18]
    3ce8:      	add	x16, sp, #0x60
    3cec:      	ldr	x0, [x16, #0x20]
    3cf0:      	add	x16, sp, #0x10
    3cf4:      	str	x0, [x16, #0x20]
    3cf8:      	add	x16, sp, #0x60
    3cfc:      	ldr	x0, [x16, #0x28]
    3d00:      	add	x16, sp, #0x10
    3d04:      	str	x0, [x16, #0x28]
    3d08:      	add	x16, sp, #0x60
    3d0c:      	ldr	x0, [x16, #0x30]
    3d10:      	add	x16, sp, #0x10
    3d14:      	str	x0, [x16, #0x30]
    3d18:      	add	x16, sp, #0x60
    3d1c:      	ldr	x0, [x16, #0x38]
    3d20:      	add	x16, sp, #0x10
    3d24:      	str	x0, [x16, #0x38]
    3d28:      	add	x16, sp, #0x60
    3d2c:      	ldr	x0, [x16, #0x40]
    3d30:      	add	x16, sp, #0x10
    3d34:      	str	x0, [x16, #0x40]
    3d38:      	add	x16, sp, #0x60
    3d3c:      	ldr	x0, [x16, #0x48]
    3d40:      	add	x16, sp, #0x10
    3d44:      	str	x0, [x16, #0x48]
    3d48:      	ldr	x0, [x24]
    3d4c:      	ldr	x1, [x24, #0x8]
    3d50:      	add	x16, sp, #0xb0
    3d54:      	movz	x17, #0x0, lsl #48
    3d58:      	str	x17, [x16]
    3d5c:      	add	x16, sp, #0xb0
    3d60:      	movz	x17, #0x0, lsl #48
    3d64:      	str	x17, [x16, #0x8]
    3d68:      	add	x16, sp, #0xb0
    3d6c:      	movz	x17, #0x0, lsl #48
    3d70:      	str	x17, [x16, #0x10]
    3d74:      	add	x16, sp, #0xb0
    3d78:      	str	x0, [x16, #0x18]
    3d7c:      	add	x16, sp, #0xb0
    3d80:      	str	x1, [x16, #0x20]
    3d84:      	add	x16, sp, #0xe0
    3d88:      	movz	x17, #0x0, lsl #48
    3d8c:      	str	x17, [x16]
    3d90:      	add	x16, sp, #0xe0
    3d94:      	movz	x17, #0x0, lsl #48
    3d98:      	str	x17, [x16, #0x8]
    3d9c:      	add	x16, sp, #0xe0
    3da0:      	movz	x17, #0x0, lsl #48
    3da4:      	str	x17, [x16, #0x10]
    3da8:      	add	x16, sp, #0xe0
    3dac:      	str	x0, [x16, #0x18]
    3db0:      	add	x16, sp, #0xe0
    3db4:      	str	x1, [x16, #0x20]
    3db8:      	add	x16, sp, #0x110
    3dbc:      	movz	x17, #0x0, lsl #48
    3dc0:      	str	x17, [x16]
    3dc4:      	add	x16, sp, #0x110
    3dc8:      	movz	x17, #0x0, lsl #48
    3dcc:      	str	x17, [x16, #0x8]
    3dd0:      	add	x16, sp, #0x110
    3dd4:      	movz	x17, #0x0, lsl #48
    3dd8:      	str	x17, [x16, #0x10]
    3ddc:      	add	x16, sp, #0x110
    3de0:      	str	x0, [x16, #0x18]
    3de4:      	add	x16, sp, #0x110
    3de8:      	str	x1, [x16, #0x20]
    3dec:      	ldr	x0, [x19, #0x8]
    3df0:      	orr	x24, x0, xzr
    3df4:      	add	x16, sp, #0xb0
    3df8:      	ldr	x0, [x16, #0x8]
    3dfc:      	orr	x25, x0, xzr
    3e00:      	add	x16, sp, #0xb0
    3e04:      	ldr	x0, [x16, #0x10]
    3e08:      	add	x26, x25, x24
    3e0c:      	cmp	x26, x0
    3e10:      	b.le	0x3e44 <_stogir.loops.depths+0x1fc>
    3e14:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    3e18:      	cmp	x0, x17
    3e1c:      	b.gt	0x3e28 <_stogir.loops.depths+0x1e0>
    3e20:      	lsl	x0, x0, #1
    3e24:      	b	0x3e2c <_stogir.loops.depths+0x1e4>
    3e28:      	mov	x0, x26
    3e2c:      	cmp	x0, x26
    3e30:      	b.gt	0x3e38 <_stogir.loops.depths+0x1f0>
    3e34:      	mov	x0, x26
    3e38:      	mov	x1, x0
    3e3c:      	add	x0, sp, #0xb0
    3e40:      	bl	0x3e40 <_stogir.loops.depths+0x1f8>
		0000000000003e40:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3e44:      	lsl	x0, x24, #2
    3e48:      	add	x16, sp, #0xb0
    3e4c:      	ldr	x1, [x16]
    3e50:      	add	x1, x1, x25, lsl #2
    3e54:      	mov	x2, x0
    3e58:      	mov	x0, x1
    3e5c:      	movz	x1, #0x0, lsl #48
    3e60:      	bl	0x3e60 <_stogir.loops.depths+0x218>
		0000000000003e60:  ARM64_RELOC_BRANCH26	_memset
    3e64:      	add	x16, sp, #0xb0
    3e68:      	str	x26, [x16, #0x8]
    3e6c:      	ldr	x0, [x19, #0x8]
    3e70:      	mov	x1, x0
    3e74:      	add	x0, sp, #0xe0
    3e78:      	bl	0x3e78 <_stogir.loops.depths+0x230>
		0000000000003e78:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    3e7c:      	ldr	x0, [x21]
    3e80:      	ldr	x1, [x21, #0x8]
    3e84:      	orr	x19, x0, xzr
    3e88:      	orr	x24, x1, xzr
    3e8c:      	movz	x25, #0x0, lsl #48
    3e90:      	b	0x3ff4 <_stogir.loops.depths+0x3ac>
    3e94:      	lsl	x2, x2, #1
    3e98:      	str	x21, [sp, #0x170]
    3e9c:      	mov	w21, w0
    3ea0:      	add	x0, sp, #0x110
    3ea4:      	str	x22, [sp, #0x178]
    3ea8:      	mov	x22, x1
    3eac:      	mov	x1, x2
    3eb0:      	bl	0x3eb0 <_stogir.loops.depths+0x268>
		0000000000003eb0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3eb4:      	add	x0, x22, #0x1
    3eb8:      	add	x16, sp, #0x110
    3ebc:      	ldr	x1, [x16]
    3ec0:      	add	x1, x1, x22, lsl #2
    3ec4:      	str	w21, [x1]
    3ec8:      	add	x16, sp, #0x110
    3ecc:      	str	x0, [x16, #0x8]
    3ed0:      	b	0x3ee0 <_stogir.loops.depths+0x298>
    3ed4:      	nop
    3ed8:      	str	x21, [sp, #0x170]
    3edc:      	str	x22, [sp, #0x178]
    3ee0:      	add	x28, x28, #0x1
    3ee4:      	ldr	x21, [sp, #0x170]
    3ee8:      	ldr	x22, [sp, #0x178]
    3eec:      	cmp	x28, x25
    3ef0:      	b.ge	0x4438 <_stogir.loops.depths+0x7f0>
    3ef4:      	add	x0, x24, x28
    3ef8:      	ldr	x1, [x22, #0x28]
    3efc:      	add	x0, x1, x0, lsl #3
    3f00:      	ldr	x0, [x0]
    3f04:      	ldr	x1, [x21, #0x50]
    3f08:      	add	x0, x1, x0, lsl #4
    3f0c:      	ldr	x0, [x0]
    3f10:      	ldr	x1, [x23]
    3f14:      	sxtw	x2, w0
    3f18:      	add	x1, x1, x2, lsl #2
    3f1c:      	ldr	w1, [x1]
    3f20:      	sxtw	x1, w1
    3f24:      	cmp	x1, #0x0
    3f28:      	b.eq	0x3ed8 <_stogir.loops.depths+0x290>
    3f2c:      	add	x16, sp, #0xe0
    3f30:      	ldr	x1, [x16]
    3f34:      	add	x3, x1, x2, lsl #2
    3f38:      	ldr	w3, [x3]
    3f3c:      	sxtw	x3, w3
    3f40:      	cmp	x3, x26
    3f44:      	b.eq	0x4444 <_stogir.loops.depths+0x7fc>
    3f48:      	add	x1, x1, x2, lsl #2
    3f4c:      	str	w27, [x1]
    3f50:      	add	x16, sp, #0xb0
    3f54:      	ldr	x1, [x16]
    3f58:      	orr	x3, x1, xzr
    3f5c:      	add	x3, x3, x2, lsl #2
    3f60:      	add	x1, x1, x2, lsl #2
    3f64:      	ldr	w2, [x3]
    3f68:      	add	w2, w2, #0x1
    3f6c:      	str	w2, [x1]
    3f70:      	add	x16, sp, #0x110
    3f74:      	ldr	x1, [x16, #0x8]
    3f78:      	add	x16, sp, #0x110
    3f7c:      	ldr	x2, [x16, #0x10]
    3f80:      	cmp	x1, x2
    3f84:      	b.lt	0x4450 <_stogir.loops.depths+0x808>
    3f88:      	cmp	x2, #0x0
    3f8c:      	b.ne	0x3e94 <_stogir.loops.depths+0x24c>
    3f90:      	mov	x2, #0x2                ; =2
    3f94:      	b	0x3e98 <_stogir.loops.depths+0x250>
    3f98:      	add	x19, x19, #0x1
    3f9c:      	ldr	x21, [sp, #0x170]
    3fa0:      	ldr	x22, [sp, #0x178]
    3fa4:      	add	x16, sp, #0x110
    3fa8:      	ldr	x0, [x16, #0x8]
    3fac:      	cmp	x19, x0
    3fb0:      	b.ge	0x4464 <_stogir.loops.depths+0x81c>
    3fb4:      	add	x16, sp, #0x110
    3fb8:      	ldr	x0, [x16]
    3fbc:      	add	x0, x0, x19, lsl #2
    3fc0:      	ldr	w0, [x0]
    3fc4:      	sxtw	x0, w0
    3fc8:      	ldr	x1, [x22]
    3fcc:      	add	x0, x1, x0, lsl #4
    3fd0:      	ldr	x24, [x0]
    3fd4:      	ldr	x25, [x0, #0x8]
    3fd8:      	movz	x28, #0x0, lsl #48
    3fdc:      	b	0x3eec <_stogir.loops.depths+0x2a4>
    3fe0:      	ldr	x21, [sp, #0x170]
    3fe4:      	ldr	x22, [sp, #0x178]
    3fe8:      	ldr	x24, [sp, #0x160]
    3fec:      	ldr	x19, [sp, #0x158]
    3ff0:      	ldr	x25, [sp, #0x168]
    3ff4:      	cmp	x25, x24
    3ff8:      	b.ge	0x401c <_stogir.loops.depths+0x3d4>
    3ffc:      	add	x0, x25, #0x1
    4000:      	add	x1, x19, x25, lsl #2
    4004:      	ldr	w1, [x1]
    4008:      	movn	w17, #0x0, lsl #16
    400c:      	and	w1, w1, w17
    4010:      	mov	x25, x0
    4014:      	mov	w0, #0x1                ; =1
    4018:      	b	0x4024 <_stogir.loops.depths+0x3dc>
    401c:      	movz	w0, #0x0, lsl #16
    4020:      	movz	w1, #0x0, lsl #16
    4024:      	ubfx	x0, x0, #0, #32
    4028:      	lsr	x16, x0, #0
    402c:      	cmp	x16, #0x1
    4030:      	b.eq	0x404c <_stogir.loops.depths+0x404>
    4034:      	b.lo	0x403c <_stogir.loops.depths+0x3f4>
    4038:      	b	0x4050 <_stogir.loops.depths+0x408>
    403c:      	cmp	x16, #0x0
    4040:      	b.eq	0x4048 <_stogir.loops.depths+0x400>
    4044:      	b	0x4050 <_stogir.loops.depths+0x408>
    4048:      	b	0x4054 <_stogir.loops.depths+0x40c>
    404c:      	b	0x41ec <_stogir.loops.depths+0x5a4>
    4050:      	b	0x43e0 <_stogir.loops.depths+0x798>
    4054:      	add	x0, sp, #0x10
    4058:      	bl	0x4058 <_stogir.loops.depths+0x410>
		0000000000004058:  ARM64_RELOC_BRANCH26	_stogir.dominators.release-index!
    405c:      	b	0x406c <_stogir.loops.depths+0x424>
    4060:      	sub	x0, x0, #0x1
    4064:      	add	x16, sp, #0xe0
    4068:      	str	x0, [x16, #0x8]
    406c:      	add	x16, sp, #0xe0
    4070:      	ldr	x0, [x16, #0x8]
    4074:      	cmp	x0, #0x0
    4078:      	b.ne	0x4060 <_stogir.loops.depths+0x418>
    407c:      	add	x16, sp, #0xe0
    4080:      	orr	x0, x16, xzr
    4084:      	add	x16, sp, #0xe0
    4088:      	ldr	x1, [x16, #0x10]
    408c:      	cmp	x1, #0x0
    4090:      	b.le	0x40c0 <_stogir.loops.depths+0x478>
    4094:      	add	x0, x0, #0x18
    4098:      	add	x16, sp, #0xe0
    409c:      	ldr	x2, [x16]
    40a0:      	fmov	d31, x1
    40a4:      	mov	x1, x2
    40a8:      	fmov	x2, d31
    40ac:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3b8>
		00000000000040ac:  ARM64_RELOC_PAGE21	l_stogir.416
    40b0:      	ldr	x3, [x3]
		00000000000040b0:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    40b4:      	mov	x4, #0x4                ; =4
    40b8:      	mov	x5, #0x4                ; =4
    40bc:      	bl	0x40bc <_stogir.loops.depths+0x474>
		00000000000040bc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    40c0:      	add	x16, sp, #0xe0
    40c4:      	movz	x17, #0x0, lsl #48
    40c8:      	str	x17, [x16]
    40cc:      	add	x16, sp, #0xe0
    40d0:      	movz	x17, #0x0, lsl #48
    40d4:      	str	x17, [x16, #0x8]
    40d8:      	add	x16, sp, #0xe0
    40dc:      	movz	x17, #0x0, lsl #48
    40e0:      	str	x17, [x16, #0x10]
    40e4:      	b	0x40f4 <_stogir.loops.depths+0x4ac>
    40e8:      	sub	x0, x0, #0x1
    40ec:      	add	x16, sp, #0x110
    40f0:      	str	x0, [x16, #0x8]
    40f4:      	add	x16, sp, #0x110
    40f8:      	ldr	x0, [x16, #0x8]
    40fc:      	cmp	x0, #0x0
    4100:      	b.ne	0x40e8 <_stogir.loops.depths+0x4a0>
    4104:      	add	x16, sp, #0x110
    4108:      	orr	x0, x16, xzr
    410c:      	add	x16, sp, #0x110
    4110:      	ldr	x1, [x16, #0x10]
    4114:      	cmp	x1, #0x0
    4118:      	b.le	0x4148 <_stogir.loops.depths+0x500>
    411c:      	add	x0, x0, #0x18
    4120:      	add	x16, sp, #0x110
    4124:      	ldr	x2, [x16]
    4128:      	fmov	d31, x1
    412c:      	mov	x1, x2
    4130:      	fmov	x2, d31
    4134:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3b8>
		0000000000004134:  ARM64_RELOC_PAGE21	l_stogir.416
    4138:      	ldr	x3, [x3]
		0000000000004138:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    413c:      	mov	x4, #0x4                ; =4
    4140:      	mov	x5, #0x4                ; =4
    4144:      	bl	0x4144 <_stogir.loops.depths+0x4fc>
		0000000000004144:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4148:      	add	x16, sp, #0x110
    414c:      	movz	x17, #0x0, lsl #48
    4150:      	str	x17, [x16]
    4154:      	add	x16, sp, #0x110
    4158:      	movz	x17, #0x0, lsl #48
    415c:      	str	x17, [x16, #0x8]
    4160:      	add	x16, sp, #0x110
    4164:      	movz	x17, #0x0, lsl #48
    4168:      	str	x17, [x16, #0x10]
    416c:      	add	x16, sp, #0xb0
    4170:      	ldr	x0, [x16]
    4174:      	add	x16, sp, #0xb0
    4178:      	ldr	x1, [x16, #0x8]
    417c:      	add	x16, sp, #0xb0
    4180:      	ldr	x2, [x16, #0x10]
    4184:      	add	x16, sp, #0xb0
    4188:      	ldr	x3, [x16, #0x18]
    418c:      	add	x16, sp, #0xb0
    4190:      	ldr	x4, [x16, #0x20]
    4194:      	str	x0, [x20]
    4198:      	str	x1, [x20, #0x8]
    419c:      	str	x2, [x20, #0x10]
    41a0:      	str	x3, [x20, #0x18]
    41a4:      	str	x4, [x20, #0x20]
    41a8:      	ldr	x19, [sp, #0x180]
    41ac:      	ldr	x20, [sp, #0x188]
    41b0:      	ldr	x21, [sp, #0x190]
    41b4:      	ldr	x22, [sp, #0x198]
    41b8:      	ldr	x23, [sp, #0x1a0]
    41bc:      	ldr	x24, [sp, #0x1a8]
    41c0:      	ldr	x25, [sp, #0x1b0]
    41c4:      	ldr	x26, [sp, #0x1b8]
    41c8:      	ldr	x27, [sp, #0x1c0]
    41cc:      	ldr	x28, [sp, #0x1c8]
    41d0:      	ldr	x29, [sp]
    41d4:      	ldr	x30, [sp, #0x8]
    41d8:      	add	sp, sp, #0x1d0
    41dc:      	ret
    41e0:      	sub	x0, x0, #0x1
    41e4:      	add	x16, sp, #0x110
    41e8:      	str	x0, [x16, #0x8]
    41ec:      	add	x16, sp, #0x110
    41f0:      	ldr	x0, [x16, #0x8]
    41f4:      	cmp	x0, #0x0
    41f8:      	b.ne	0x41e0 <_stogir.loops.depths+0x598>
    41fc:      	sxtw	x26, w1
    4200:      	orr	w27, w1, wzr
    4204:      	lsl	x28, x26, #2
    4208:      	cmp	x26, #0x0
    420c:      	cset	w0, gt
    4210:      	add	x16, sp, #0xe0
    4214:      	ldr	x1, [x16]
    4218:      	add	x1, x1, x26, lsl #2
    421c:      	str	w27, [x1]
    4220:      	ldr	x1, [x22]
    4224:      	add	x1, x1, x26, lsl #4
    4228:      	ldr	x2, [x1]
    422c:      	ldr	x1, [x1, #0x8]
    4230:      	movz	x3, #0x0, lsl #48
    4234:      	movz	x4, #0x0, lsl #48
    4238:      	b	0x42b0 <_stogir.loops.depths+0x668>
    423c:      	lsl	x6, x6, #1
    4240:      	str	w0, [sp, #0x140]
    4244:      	add	x0, sp, #0x110
    4248:      	str	x2, [sp, #0x148]
    424c:      	str	x1, [sp, #0x150]
    4250:      	mov	x1, x6
    4254:      	str	x19, [sp, #0x158]
    4258:      	mov	x19, x3
    425c:      	str	x24, [sp, #0x160]
    4260:      	mov	w24, w5
    4264:      	str	x25, [sp, #0x168]
    4268:      	mov	x25, x4
    426c:      	bl	0x426c <_stogir.loops.depths+0x624>
		000000000000426c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4270:      	add	x0, x25, #0x1
    4274:      	add	x16, sp, #0x110
    4278:      	ldr	x1, [x16]
    427c:      	add	x1, x1, x25, lsl #2
    4280:      	str	w24, [x1]
    4284:      	add	x16, sp, #0x110
    4288:      	str	x0, [x16, #0x8]
    428c:      	mov	x4, #0x1                ; =1
    4290:      	add	x19, x19, #0x1
    4294:      	ldr	x2, [sp, #0x148]
    4298:      	ldr	x1, [sp, #0x150]
    429c:      	ldr	w0, [sp, #0x140]
    42a0:      	ldr	x24, [sp, #0x160]
    42a4:      	ldr	x25, [sp, #0x168]
    42a8:      	mov	x3, x19
    42ac:      	ldr	x19, [sp, #0x158]
    42b0:      	cmp	x3, x1
    42b4:      	b.ge	0x4470 <_stogir.loops.depths+0x828>
    42b8:      	add	x5, x2, x3
    42bc:      	ldr	x6, [x22, #0x28]
    42c0:      	add	x5, x6, x5, lsl #3
    42c4:      	ldr	x5, [x5]
    42c8:      	ldr	x6, [x21, #0x50]
    42cc:      	add	x5, x6, x5, lsl #4
    42d0:      	ldr	x5, [x5]
    42d4:      	uxtb	w16, w0
    42d8:      	cmp	w16, wzr
    42dc:      	b.eq	0x4480 <_stogir.loops.depths+0x838>
    42e0:      	sxtw	x6, w5
    42e4:      	cmp	x6, #0x0
    42e8:      	b.le	0x44a0 <_stogir.loops.depths+0x858>
    42ec:      	add	x16, sp, #0x10
    42f0:      	ldr	x7, [x16, #0x8]
    42f4:      	cmp	x26, x7
    42f8:      	b.ge	0x44c0 <_stogir.loops.depths+0x878>
    42fc:      	cmp	x6, x7
    4300:      	b.ge	0x44e0 <_stogir.loops.depths+0x898>
    4304:      	add	x16, sp, #0x10
    4308:      	ldr	x7, [x16]
    430c:      	add	x8, x28, x7
    4310:      	ldr	w8, [x8]
    4314:      	sxtw	x8, w8
    4318:      	cmp	x8, #0x0
    431c:      	b.le	0x4500 <_stogir.loops.depths+0x8b8>
    4320:      	lsl	x9, x6, #2
    4324:      	add	x6, x7, x6, lsl #2
    4328:      	ldr	w6, [x6]
    432c:      	sxtw	x6, w6
    4330:      	cmp	x6, #0x0
    4334:      	b.le	0x4520 <_stogir.loops.depths+0x8d8>
    4338:      	cmp	x8, x6
    433c:      	b.gt	0x4540 <_stogir.loops.depths+0x8f8>
    4340:      	add	x16, sp, #0x10
    4344:      	ldr	x6, [x16, #0x28]
    4348:      	orr	x7, x6, xzr
    434c:      	add	x7, x28, x7
    4350:      	add	x6, x9, x6
    4354:      	ldr	w7, [x7]
    4358:      	sxtw	x7, w7
    435c:      	ldr	w6, [x6]
    4360:      	sxtw	x6, w6
    4364:      	cmp	x7, x6
    4368:      	b.lt	0x4560 <_stogir.loops.depths+0x918>
    436c:      	cmp	x4, #0x0
    4370:      	b.ne	0x4394 <_stogir.loops.depths+0x74c>
    4374:      	add	x16, sp, #0xb0
    4378:      	ldr	x4, [x16]
    437c:      	orr	x6, x4, xzr
    4380:      	add	x6, x28, x6
    4384:      	add	x4, x28, x4
    4388:      	ldr	w6, [x6]
    438c:      	add	w6, w6, #0x1
    4390:      	str	w6, [x4]
    4394:      	add	x16, sp, #0xe0
    4398:      	ldr	x4, [x16]
    439c:      	add	x6, x9, x4
    43a0:      	ldr	w6, [x6]
    43a4:      	sxtw	x6, w6
    43a8:      	cmp	x6, x26
    43ac:      	b.ne	0x43e8 <_stogir.loops.depths+0x7a0>
    43b0:      	str	x2, [sp, #0x148]
    43b4:      	str	x1, [sp, #0x150]
    43b8:      	str	w0, [sp, #0x140]
    43bc:      	str	x24, [sp, #0x160]
    43c0:      	str	x19, [sp, #0x158]
    43c4:      	mov	x19, x3
    43c8:      	str	x25, [sp, #0x168]
    43cc:      	b	0x428c <_stogir.loops.depths+0x644>
    43d0:      	cmp	x4, #0x0
    43d4:      	b.eq	0x4580 <_stogir.loops.depths+0x938>
    43d8:      	movz	x19, #0x0, lsl #48
    43dc:      	b	0x3fa4 <_stogir.loops.depths+0x35c>
    43e0:      	brk	#0
    43e4:      	b	0x43e0 <_stogir.loops.depths+0x798>
    43e8:      	add	x4, x9, x4
    43ec:      	str	w27, [x4]
    43f0:      	add	x16, sp, #0xb0
    43f4:      	ldr	x4, [x16]
    43f8:      	orr	x6, x4, xzr
    43fc:      	add	x6, x9, x6
    4400:      	add	x4, x9, x4
    4404:      	ldr	w6, [x6]
    4408:      	add	w6, w6, #0x1
    440c:      	str	w6, [x4]
    4410:      	add	x16, sp, #0x110
    4414:      	ldr	x4, [x16, #0x8]
    4418:      	add	x16, sp, #0x110
    441c:      	ldr	x6, [x16, #0x10]
    4420:      	cmp	x4, x6
    4424:      	b.lt	0x458c <_stogir.loops.depths+0x944>
    4428:      	cmp	x6, #0x0
    442c:      	b.ne	0x423c <_stogir.loops.depths+0x5f4>
    4430:      	mov	x6, #0x2                ; =2
    4434:      	b	0x4240 <_stogir.loops.depths+0x5f8>
    4438:      	str	x21, [sp, #0x170]
    443c:      	str	x22, [sp, #0x178]
    4440:      	b	0x3f98 <_stogir.loops.depths+0x350>
    4444:      	str	x21, [sp, #0x170]
    4448:      	str	x22, [sp, #0x178]
    444c:      	b	0x3ee0 <_stogir.loops.depths+0x298>
    4450:      	str	x21, [sp, #0x170]
    4454:      	str	x22, [sp, #0x178]
    4458:      	mov	w21, w0
    445c:      	mov	x22, x1
    4460:      	b	0x3eb4 <_stogir.loops.depths+0x26c>
    4464:      	str	x21, [sp, #0x170]
    4468:      	str	x22, [sp, #0x178]
    446c:      	b	0x3fe0 <_stogir.loops.depths+0x398>
    4470:      	str	x24, [sp, #0x160]
    4474:      	str	x19, [sp, #0x158]
    4478:      	str	x25, [sp, #0x168]
    447c:      	b	0x43d0 <_stogir.loops.depths+0x788>
    4480:      	str	x2, [sp, #0x148]
    4484:      	str	x1, [sp, #0x150]
    4488:      	str	w0, [sp, #0x140]
    448c:      	str	x24, [sp, #0x160]
    4490:      	str	x19, [sp, #0x158]
    4494:      	mov	x19, x3
    4498:      	str	x25, [sp, #0x168]
    449c:      	b	0x4290 <_stogir.loops.depths+0x648>
    44a0:      	str	x2, [sp, #0x148]
    44a4:      	str	x1, [sp, #0x150]
    44a8:      	str	w0, [sp, #0x140]
    44ac:      	str	x24, [sp, #0x160]
    44b0:      	str	x19, [sp, #0x158]
    44b4:      	mov	x19, x3
    44b8:      	str	x25, [sp, #0x168]
    44bc:      	b	0x4290 <_stogir.loops.depths+0x648>
    44c0:      	str	x2, [sp, #0x148]
    44c4:      	str	x1, [sp, #0x150]
    44c8:      	str	w0, [sp, #0x140]
    44cc:      	str	x24, [sp, #0x160]
    44d0:      	str	x19, [sp, #0x158]
    44d4:      	mov	x19, x3
    44d8:      	str	x25, [sp, #0x168]
    44dc:      	b	0x4290 <_stogir.loops.depths+0x648>
    44e0:      	str	x2, [sp, #0x148]
    44e4:      	str	x1, [sp, #0x150]
    44e8:      	str	w0, [sp, #0x140]
    44ec:      	str	x24, [sp, #0x160]
    44f0:      	str	x19, [sp, #0x158]
    44f4:      	mov	x19, x3
    44f8:      	str	x25, [sp, #0x168]
    44fc:      	b	0x4290 <_stogir.loops.depths+0x648>
    4500:      	str	x2, [sp, #0x148]
    4504:      	str	x1, [sp, #0x150]
    4508:      	str	w0, [sp, #0x140]
    450c:      	str	x24, [sp, #0x160]
    4510:      	str	x19, [sp, #0x158]
    4514:      	mov	x19, x3
    4518:      	str	x25, [sp, #0x168]
    451c:      	b	0x4290 <_stogir.loops.depths+0x648>
    4520:      	str	x2, [sp, #0x148]
    4524:      	str	x1, [sp, #0x150]
    4528:      	str	w0, [sp, #0x140]
    452c:      	str	x24, [sp, #0x160]
    4530:      	str	x19, [sp, #0x158]
    4534:      	mov	x19, x3
    4538:      	str	x25, [sp, #0x168]
    453c:      	b	0x4290 <_stogir.loops.depths+0x648>
    4540:      	str	x2, [sp, #0x148]
    4544:      	str	x1, [sp, #0x150]
    4548:      	str	w0, [sp, #0x140]
    454c:      	str	x24, [sp, #0x160]
    4550:      	str	x19, [sp, #0x158]
    4554:      	mov	x19, x3
    4558:      	str	x25, [sp, #0x168]
    455c:      	b	0x4290 <_stogir.loops.depths+0x648>
    4560:      	str	x2, [sp, #0x148]
    4564:      	str	x1, [sp, #0x150]
    4568:      	str	w0, [sp, #0x140]
    456c:      	str	x24, [sp, #0x160]
    4570:      	str	x19, [sp, #0x158]
    4574:      	mov	x19, x3
    4578:      	str	x25, [sp, #0x168]
    457c:      	b	0x4290 <_stogir.loops.depths+0x648>
    4580:      	str	x21, [sp, #0x170]
    4584:      	str	x22, [sp, #0x178]
    4588:      	b	0x3fe0 <_stogir.loops.depths+0x398>
    458c:      	str	x2, [sp, #0x148]
    4590:      	str	x1, [sp, #0x150]
    4594:      	str	w0, [sp, #0x140]
    4598:      	str	x24, [sp, #0x160]
    459c:      	mov	w24, w5
    45a0:      	str	x19, [sp, #0x158]
    45a4:      	mov	x19, x3
    45a8:      	str	x25, [sp, #0x168]
    45ac:      	mov	x25, x4
    45b0:      	b	0x4270 <_stogir.loops.depths+0x628>

00000000000045b4 <_stogir.liveness.mark>:
    45b4:      	sub	sp, sp, #0x140
    45b8:      	str	x29, [sp]
    45bc:      	str	x30, [sp, #0x8]
    45c0:      	mov	x29, sp
    45c4:      	str	x19, [sp, #0xe8]
    45c8:      	str	x20, [sp, #0xf0]
    45cc:      	str	x21, [sp, #0xf8]
    45d0:      	str	x22, [sp, #0x100]
    45d4:      	str	x23, [sp, #0x108]
    45d8:      	str	x24, [sp, #0x110]
    45dc:      	str	x25, [sp, #0x118]
    45e0:      	str	x26, [sp, #0x120]
    45e4:      	str	x27, [sp, #0x128]
    45e8:      	str	x28, [sp, #0x130]
    45ec:      	add	x19, x0, #0x78
    45f0:      	mov	x20, x8
    45f4:      	add	x8, sp, #0x40
    45f8:      	mov	x21, x0
    45fc:      	mov	x0, x3
    4600:      	mov	x22, x1
    4604:      	mov	x23, x2
    4608:      	mov	x24, x3
    460c:      	bl	0x460c <_stogir.liveness.mark+0x58>
		000000000000460c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__bool
    4610:      	add	x16, sp, #0x40
    4614:      	ldr	x0, [x16]
    4618:      	add	x16, sp, #0x10
    461c:      	str	x0, [x16]
    4620:      	add	x16, sp, #0x40
    4624:      	ldr	x0, [x16, #0x8]
    4628:      	add	x16, sp, #0x10
    462c:      	str	x0, [x16, #0x8]
    4630:      	add	x16, sp, #0x40
    4634:      	ldr	x0, [x16, #0x10]
    4638:      	add	x16, sp, #0x10
    463c:      	str	x0, [x16, #0x10]
    4640:      	add	x16, sp, #0x40
    4644:      	ldr	x0, [x16, #0x18]
    4648:      	add	x16, sp, #0x10
    464c:      	str	x0, [x16, #0x18]
    4650:      	add	x16, sp, #0x40
    4654:      	ldr	x0, [x16, #0x20]
    4658:      	add	x16, sp, #0x10
    465c:      	str	x0, [x16, #0x20]
    4660:      	add	x8, sp, #0xa0
    4664:      	mov	x0, x24
    4668:      	bl	0x4668 <_stogir.liveness.mark+0xb4>
		0000000000004668:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    466c:      	add	x16, sp, #0xa0
    4670:      	ldr	x0, [x16]
    4674:      	add	x16, sp, #0x70
    4678:      	str	x0, [x16]
    467c:      	add	x16, sp, #0xa0
    4680:      	ldr	x0, [x16, #0x8]
    4684:      	add	x16, sp, #0x70
    4688:      	str	x0, [x16, #0x8]
    468c:      	add	x16, sp, #0xa0
    4690:      	ldr	x0, [x16, #0x10]
    4694:      	add	x16, sp, #0x70
    4698:      	str	x0, [x16, #0x10]
    469c:      	add	x16, sp, #0xa0
    46a0:      	ldr	x0, [x16, #0x18]
    46a4:      	add	x16, sp, #0x70
    46a8:      	str	x0, [x16, #0x18]
    46ac:      	add	x16, sp, #0xa0
    46b0:      	ldr	x0, [x16, #0x20]
    46b4:      	add	x16, sp, #0x70
    46b8:      	str	x0, [x16, #0x20]
    46bc:      	ldr	x0, [x21, #0x8]
    46c0:      	mov	x1, x0
    46c4:      	add	x0, sp, #0x10
    46c8:      	bl	0x46c8 <_stogir.liveness.mark+0x114>
		00000000000046c8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool
    46cc:      	movz	x24, #0x0, lsl #48
    46d0:      	cmp	x24, x23
    46d4:      	b.ge	0x46f8 <_stogir.liveness.mark+0x144>
    46d8:      	add	x0, x24, #0x1
    46dc:      	add	x1, x22, x24, lsl #2
    46e0:      	ldr	w1, [x1]
    46e4:      	movn	w17, #0x0, lsl #16
    46e8:      	and	w25, w1, w17
    46ec:      	mov	x24, x0
    46f0:      	mov	w0, #0x1                ; =1
    46f4:      	b	0x4700 <_stogir.liveness.mark+0x14c>
    46f8:      	movz	w0, #0x0, lsl #16
    46fc:      	movz	w25, #0x0, lsl #16
    4700:      	ubfx	x0, x0, #0, #32
    4704:      	lsr	x16, x0, #0
    4708:      	cmp	x16, #0x1
    470c:      	b.eq	0x4728 <_stogir.liveness.mark+0x174>
    4710:      	b.lo	0x4718 <_stogir.liveness.mark+0x164>
    4714:      	b	0x472c <_stogir.liveness.mark+0x178>
    4718:      	cmp	x16, #0x0
    471c:      	b.eq	0x4724 <_stogir.liveness.mark+0x170>
    4720:      	b	0x472c <_stogir.liveness.mark+0x178>
    4724:      	b	0x47bc <_stogir.liveness.mark+0x208>
    4728:      	b	0x4730 <_stogir.liveness.mark+0x17c>
    472c:      	b	0x4b34 <_stogir.liveness.mark+0x580>
    4730:      	sxtw	x0, w25
    4734:      	cmp	x0, #0x0
    4738:      	b.le	0x46d0 <_stogir.liveness.mark+0x11c>
    473c:      	ldr	x1, [x21, #0x8]
    4740:      	cmp	x0, x1
    4744:      	b.ge	0x46d0 <_stogir.liveness.mark+0x11c>
    4748:      	ldr	x1, [x19, #0x8]
    474c:      	cmp	x0, x1
    4750:      	b.ge	0x46d0 <_stogir.liveness.mark+0x11c>
    4754:      	ldr	x1, [x21, #0x78]
    4758:      	add	x1, x1, x0, lsl #2
    475c:      	ldr	w1, [x1]
    4760:      	sxtw	x1, w1
    4764:      	cmp	x1, #0x0
    4768:      	b.lt	0x46d0 <_stogir.liveness.mark+0x11c>
    476c:      	add	x16, sp, #0x10
    4770:      	ldr	x1, [x16]
    4774:      	add	x2, x1, x0
    4778:      	ldrb	w2, [x2]
    477c:      	cmp	x2, #0x0
    4780:      	b.ne	0x46d0 <_stogir.liveness.mark+0x11c>
    4784:      	add	x0, x1, x0
    4788:      	mov	w17, #0x1               ; =1
    478c:      	strb	w17, [x0]
    4790:      	add	x16, sp, #0x70
    4794:      	ldr	x0, [x16, #0x8]
    4798:      	orr	x26, x0, xzr
    479c:      	add	x16, sp, #0x70
    47a0:      	ldr	x0, [x16, #0x10]
    47a4:      	cmp	x26, x0
    47a8:      	b.lt	0x4b14 <_stogir.liveness.mark+0x560>
    47ac:      	cmp	x0, #0x0
    47b0:      	b.ne	0x4b04 <_stogir.liveness.mark+0x550>
    47b4:      	mov	x0, #0x2                ; =2
    47b8:      	b	0x4b08 <_stogir.liveness.mark+0x554>
    47bc:      	movz	x22, #0x0, lsl #48
    47c0:      	b	0x49e0 <_stogir.liveness.mark+0x42c>
    47c4:      	movz	w2, #0x0, lsl #16
    47c8:      	movz	w1, #0x0, lsl #16
    47cc:      	b	0x495c <_stogir.liveness.mark+0x3a8>
    47d0:      	sub	w1, w1, #0x1
    47d4:      	lsl	w1, w1, #2
    47d8:      	ubfx	x1, x1, #0, #32
    47dc:      	lsr	x1, x3, x1
    47e0:      	and	w1, w1, #0xf
    47e4:      	b	0x4880 <_stogir.liveness.mark+0x2cc>
    47e8:      	lsl	x3, x3, #1
    47ec:      	str	x19, [sp, #0xd0]
    47f0:      	mov	x19, x0
    47f4:      	add	x0, sp, #0x70
    47f8:      	str	x21, [sp, #0xd8]
    47fc:      	mov	w21, w1
    4800:      	mov	x1, x3
    4804:      	str	x23, [sp, #0xe0]
    4808:      	mov	x23, x2
    480c:      	bl	0x480c <_stogir.liveness.mark+0x258>
		000000000000480c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4810:      	add	x0, x23, #0x1
    4814:      	add	x16, sp, #0x70
    4818:      	ldr	x1, [x16]
    481c:      	add	x1, x1, x23, lsl #2
    4820:      	str	w21, [x1]
    4824:      	add	x16, sp, #0x70
    4828:      	str	x0, [x16, #0x8]
    482c:      	add	x0, x19, #0x1
    4830:      	sxtw	x19, w0
    4834:      	ldr	x21, [sp, #0xd8]
    4838:      	ldr	x23, [sp, #0xe0]
    483c:      	mov	x0, x19
    4840:      	ldr	x19, [sp, #0xd0]
    4844:      	cmp	x0, x28
    4848:      	b.gt	0x4b3c <_stogir.liveness.mark+0x588>
    484c:      	orr	w1, w0, wzr
    4850:      	sxtw	x2, w1
    4854:      	uxtb	w16, w26
    4858:      	cmp	w16, wzr
    485c:      	b.eq	0x4884 <_stogir.liveness.mark+0x2d0>
    4860:      	ldr	w3, [x27]
    4864:      	cmp	x2, #0x0
    4868:      	b.le	0x487c <_stogir.liveness.mark+0x2c8>
    486c:      	cmp	x2, #0x4
    4870:      	b.le	0x47d0 <_stogir.liveness.mark+0x21c>
    4874:      	mov	w1, #0x4                ; =4
    4878:      	b	0x47d4 <_stogir.liveness.mark+0x220>
    487c:      	movz	w1, #0x0, lsl #16
    4880:      	b	0x4888 <_stogir.liveness.mark+0x2d4>
    4884:      	movz	w1, #0x0, lsl #16
    4888:      	ubfx	x1, x1, #0, #32
    488c:      	cmp	x1, #0xf
    4890:      	b.hs	0x4b48 <_stogir.liveness.mark+0x594>
    4894:      	mov	x16, #0x1               ; =1
    4898:      	lsl	x1, x16, x1
    489c:      	mov	w17, #0x5e1c            ; =24092
    48a0:      	and	w1, w1, w17
    48a4:      	ubfx	x1, x1, #0, #32
    48a8:      	cmp	x1, #0x0
    48ac:      	b.eq	0x4b5c <_stogir.liveness.mark+0x5a8>
    48b0:      	uxtb	w16, w25
    48b4:      	cmp	w16, wzr
    48b8:      	b.ne	0x4954 <_stogir.liveness.mark+0x3a0>
    48bc:      	ldr	x1, [x21, #0x8]
    48c0:      	cmp	x23, x1
    48c4:      	b.ge	0x4954 <_stogir.liveness.mark+0x3a0>
    48c8:      	ldr	x1, [x19, #0x8]
    48cc:      	cmp	x23, x1
    48d0:      	b.ge	0x4954 <_stogir.liveness.mark+0x3a0>
    48d4:      	ldr	x1, [x21, #0x78]
    48d8:      	add	x1, x24, x1
    48dc:      	ldr	w1, [x1]
    48e0:      	sxtw	x1, w1
    48e4:      	cmp	x1, #0x0
    48e8:      	b.lt	0x4954 <_stogir.liveness.mark+0x3a0>
    48ec:      	cmp	x2, #0x1
    48f0:      	b.lt	0x47c4 <_stogir.liveness.mark+0x210>
    48f4:      	ldr	x1, [x21, #0x78]
    48f8:      	add	x1, x24, x1
    48fc:      	ldr	w1, [x1]
    4900:      	sxtw	x1, w1
    4904:      	cmp	x2, x1
    4908:      	b.gt	0x47c4 <_stogir.liveness.mark+0x210>
    490c:      	ldr	x1, [x21]
    4910:      	asr	x16, x2, #63
    4914:      	lsr	x16, x16, #62
    4918:      	add	x3, x2, x16
    491c:      	asr	x3, x3, #2
    4920:      	asr	x16, x2, #63
    4924:      	lsr	x16, x16, #62
    4928:      	add	x2, x2, x16
    492c:      	and	x2, x2, #0x3
    4930:      	sub	x2, x2, x16
    4934:      	add	x3, x3, x23
    4938:      	add	x1, x1, x3, lsl #4
    493c:      	add	x1, x1, x2, lsl #2
    4940:      	ldr	w1, [x1]
    4944:      	movn	w17, #0x0, lsl #16
    4948:      	and	w1, w1, w17
    494c:      	mov	w2, #0x1                ; =1
    4950:      	b	0x47cc <_stogir.liveness.mark+0x218>
    4954:      	movz	w2, #0x0, lsl #16
    4958:      	movz	w1, #0x0, lsl #16
    495c:      	ubfx	x2, x2, #0, #32
    4960:      	lsr	x16, x2, #0
    4964:      	cmp	x16, #0x1
    4968:      	b.eq	0x4994 <_stogir.liveness.mark+0x3e0>
    496c:      	b.lo	0x4974 <_stogir.liveness.mark+0x3c0>
    4970:      	b	0x4998 <_stogir.liveness.mark+0x3e4>
    4974:      	cmp	x16, #0x0
    4978:      	b.eq	0x4980 <_stogir.liveness.mark+0x3cc>
    497c:      	b	0x4998 <_stogir.liveness.mark+0x3e4>
    4980:      	str	x21, [sp, #0xd8]
    4984:      	str	x23, [sp, #0xe0]
    4988:      	str	x19, [sp, #0xd0]
    498c:      	mov	x19, x0
    4990:      	b	0x482c <_stogir.liveness.mark+0x278>
    4994:      	b	0x499c <_stogir.liveness.mark+0x3e8>
    4998:      	b	0x4afc <_stogir.liveness.mark+0x548>
    499c:      	sxtw	x2, w1
    49a0:      	cmp	x2, #0x0
    49a4:      	b.le	0x4b70 <_stogir.liveness.mark+0x5bc>
    49a8:      	add	x16, sp, #0x10
    49ac:      	ldr	x3, [x16]
    49b0:      	add	x2, x2, x3
    49b4:      	ldrb	w3, [x2]
    49b8:      	cmp	x3, #0x0
    49bc:      	b.eq	0x4a50 <_stogir.liveness.mark+0x49c>
    49c0:      	str	x21, [sp, #0xd8]
    49c4:      	str	x23, [sp, #0xe0]
    49c8:      	str	x19, [sp, #0xd0]
    49cc:      	mov	x19, x0
    49d0:      	b	0x482c <_stogir.liveness.mark+0x278>
    49d4:      	add	x22, x22, #0x1
    49d8:      	ldr	x21, [sp, #0xd8]
    49dc:      	ldr	x19, [sp, #0xd0]
    49e0:      	add	x16, sp, #0x70
    49e4:      	ldr	x0, [x16, #0x8]
    49e8:      	cmp	x22, x0
    49ec:      	b.ge	0x4a80 <_stogir.liveness.mark+0x4cc>
    49f0:      	add	x16, sp, #0x70
    49f4:      	ldr	x0, [x16]
    49f8:      	add	x0, x0, x22, lsl #2
    49fc:      	ldr	w0, [x0]
    4a00:      	sxtw	x23, w0
    4a04:      	ldr	x0, [x21]
    4a08:      	lsl	x24, x23, #2
    4a0c:      	cmp	x23, #0x0
    4a10:      	cset	w25, le
    4a14:      	add	x0, x0, x23, lsl #4
    4a18:      	ldr	x0, [x0]
    4a1c:      	ldr	x1, [x21, #0x78]
    4a20:      	uxtb	w0, w0
    4a24:      	add	x1, x1, x23, lsl #2
    4a28:      	cmp	x0, #0x83
    4a2c:      	cset	w26, lt
    4a30:      	adrp	x16, 0x4000 <_stogir.loops.depths+0x3b8>
		0000000000004a30:  ARM64_RELOC_PAGE21	l_stogir.417
    4a34:      	ldr	x16, [x16]
		0000000000004a34:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    4a38:      	add	x0, x16, x0, lsl #2
    4a3c:      	ldr	w1, [x1]
    4a40:      	orr	x27, x0, xzr
    4a44:      	sxtw	x28, w1
    4a48:      	mov	x0, #0x1                ; =1
    4a4c:      	b	0x4844 <_stogir.liveness.mark+0x290>
    4a50:      	mov	w17, #0x1               ; =1
    4a54:      	strb	w17, [x2]
    4a58:      	add	x16, sp, #0x70
    4a5c:      	ldr	x2, [x16, #0x8]
    4a60:      	add	x16, sp, #0x70
    4a64:      	ldr	x3, [x16, #0x10]
    4a68:      	cmp	x2, x3
    4a6c:      	b.lt	0x4b84 <_stogir.liveness.mark+0x5d0>
    4a70:      	cmp	x3, #0x0
    4a74:      	b.ne	0x47e8 <_stogir.liveness.mark+0x234>
    4a78:      	mov	x3, #0x2                ; =2
    4a7c:      	b	0x47ec <_stogir.liveness.mark+0x238>
    4a80:      	add	x0, sp, #0x70
    4a84:      	bl	0x4a84 <_stogir.liveness.mark+0x4d0>
		0000000000004a84:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    4a88:      	add	x16, sp, #0x10
    4a8c:      	ldr	x0, [x16]
    4a90:      	add	x16, sp, #0x10
    4a94:      	ldr	x1, [x16, #0x8]
    4a98:      	add	x16, sp, #0x10
    4a9c:      	ldr	x2, [x16, #0x10]
    4aa0:      	add	x16, sp, #0x10
    4aa4:      	ldr	x3, [x16, #0x18]
    4aa8:      	add	x16, sp, #0x10
    4aac:      	ldr	x4, [x16, #0x20]
    4ab0:      	str	x0, [x20]
    4ab4:      	str	x1, [x20, #0x8]
    4ab8:      	str	x2, [x20, #0x10]
    4abc:      	str	x3, [x20, #0x18]
    4ac0:      	str	x4, [x20, #0x20]
    4ac4:      	ldr	x19, [sp, #0xe8]
    4ac8:      	ldr	x20, [sp, #0xf0]
    4acc:      	ldr	x21, [sp, #0xf8]
    4ad0:      	ldr	x22, [sp, #0x100]
    4ad4:      	ldr	x23, [sp, #0x108]
    4ad8:      	ldr	x24, [sp, #0x110]
    4adc:      	ldr	x25, [sp, #0x118]
    4ae0:      	ldr	x26, [sp, #0x120]
    4ae4:      	ldr	x27, [sp, #0x128]
    4ae8:      	ldr	x28, [sp, #0x130]
    4aec:      	ldr	x29, [sp]
    4af0:      	ldr	x30, [sp, #0x8]
    4af4:      	add	sp, sp, #0x140
    4af8:      	ret
    4afc:      	brk	#0
    4b00:      	b	0x4afc <_stogir.liveness.mark+0x548>
    4b04:      	lsl	x0, x0, #1
    4b08:      	mov	x1, x0
    4b0c:      	add	x0, sp, #0x70
    4b10:      	bl	0x4b10 <_stogir.liveness.mark+0x55c>
		0000000000004b10:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4b14:      	add	x0, x26, #0x1
    4b18:      	add	x16, sp, #0x70
    4b1c:      	ldr	x1, [x16]
    4b20:      	add	x1, x1, x26, lsl #2
    4b24:      	str	w25, [x1]
    4b28:      	add	x16, sp, #0x70
    4b2c:      	str	x0, [x16, #0x8]
    4b30:      	b	0x46d0 <_stogir.liveness.mark+0x11c>
    4b34:      	brk	#0
    4b38:      	b	0x4b34 <_stogir.liveness.mark+0x580>
    4b3c:      	str	x21, [sp, #0xd8]
    4b40:      	str	x19, [sp, #0xd0]
    4b44:      	b	0x49d4 <_stogir.liveness.mark+0x420>
    4b48:      	str	x21, [sp, #0xd8]
    4b4c:      	str	x23, [sp, #0xe0]
    4b50:      	str	x19, [sp, #0xd0]
    4b54:      	mov	x19, x0
    4b58:      	b	0x482c <_stogir.liveness.mark+0x278>
    4b5c:      	str	x21, [sp, #0xd8]
    4b60:      	str	x23, [sp, #0xe0]
    4b64:      	str	x19, [sp, #0xd0]
    4b68:      	mov	x19, x0
    4b6c:      	b	0x482c <_stogir.liveness.mark+0x278>
    4b70:      	str	x21, [sp, #0xd8]
    4b74:      	str	x23, [sp, #0xe0]
    4b78:      	str	x19, [sp, #0xd0]
    4b7c:      	mov	x19, x0
    4b80:      	b	0x482c <_stogir.liveness.mark+0x278>
    4b84:      	str	x21, [sp, #0xd8]
    4b88:      	str	x23, [sp, #0xe0]
    4b8c:      	str	x19, [sp, #0xd0]
    4b90:      	mov	x19, x0
    4b94:      	mov	x23, x2
    4b98:      	mov	w21, w1
    4b9c:      	b	0x4810 <_stogir.liveness.mark+0x25c>

0000000000004ba0 <_stogir.uses.build>:
    4ba0:      	sub	sp, sp, #0xc0
    4ba4:      	str	x29, [sp]
    4ba8:      	str	x30, [sp, #0x8]
    4bac:      	mov	x29, sp
    4bb0:      	str	x19, [sp, #0x90]
    4bb4:      	str	x20, [sp, #0x98]
    4bb8:      	str	x21, [sp, #0xa0]
    4bbc:      	str	x22, [sp, #0xa8]
    4bc0:      	str	x23, [sp, #0xb0]
    4bc4:      	str	x24, [sp, #0xb8]
    4bc8:      	ldr	x2, [x1]
    4bcc:      	ldr	x1, [x1, #0x8]
    4bd0:      	add	x16, sp, #0x10
    4bd4:      	movz	x17, #0x0, lsl #48
    4bd8:      	str	x17, [x16]
    4bdc:      	add	x16, sp, #0x10
    4be0:      	movz	x17, #0x0, lsl #48
    4be4:      	str	x17, [x16, #0x8]
    4be8:      	add	x16, sp, #0x10
    4bec:      	movz	x17, #0x0, lsl #48
    4bf0:      	str	x17, [x16, #0x10]
    4bf4:      	add	x16, sp, #0x10
    4bf8:      	str	x2, [x16, #0x18]
    4bfc:      	add	x16, sp, #0x10
    4c00:      	str	x1, [x16, #0x20]
    4c04:      	add	x16, sp, #0x10
    4c08:      	movz	x17, #0x0, lsl #48
    4c0c:      	str	x17, [x16, #0x28]
    4c10:      	add	x16, sp, #0x10
    4c14:      	movz	x17, #0x0, lsl #48
    4c18:      	str	x17, [x16, #0x30]
    4c1c:      	add	x16, sp, #0x10
    4c20:      	movz	x17, #0x0, lsl #48
    4c24:      	str	x17, [x16, #0x38]
    4c28:      	add	x16, sp, #0x10
    4c2c:      	str	x2, [x16, #0x40]
    4c30:      	add	x16, sp, #0x10
    4c34:      	str	x1, [x16, #0x48]
    4c38:      	add	x16, sp, #0x60
    4c3c:      	movz	x17, #0x0, lsl #48
    4c40:      	str	x17, [x16]
    4c44:      	add	x16, sp, #0x60
    4c48:      	movz	x17, #0x0, lsl #48
    4c4c:      	str	x17, [x16, #0x8]
    4c50:      	add	x16, sp, #0x60
    4c54:      	movz	x17, #0x0, lsl #48
    4c58:      	str	x17, [x16, #0x10]
    4c5c:      	add	x16, sp, #0x60
    4c60:      	str	x2, [x16, #0x18]
    4c64:      	add	x16, sp, #0x60
    4c68:      	str	x1, [x16, #0x20]
    4c6c:      	ldr	x1, [x0, #0x8]
    4c70:      	orr	x19, x1, xzr
    4c74:      	cmp	x19, #0x0
    4c78:      	b.le	0x5094 <_stogir.uses.build+0x4f4>
    4c7c:      	cmp	x19, #0x0
    4c80:      	b.ge	0x4c8c <_stogir.uses.build+0xec>
    4c84:      	movz	x1, #0x0, lsl #48
    4c88:      	b	0x4c90 <_stogir.uses.build+0xf0>
    4c8c:      	mov	x1, x19
    4c90:      	mov	x20, x8
    4c94:      	mov	x21, x0
    4c98:      	add	x0, sp, #0x10
    4c9c:      	bl	0x4c9c <_stogir.uses.build+0xfc>
		0000000000004c9c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range
    4ca0:      	lsl	x0, x19, #4
    4ca4:      	add	x16, sp, #0x10
    4ca8:      	ldr	x1, [x16]
    4cac:      	mov	x2, x0
    4cb0:      	mov	x0, x1
    4cb4:      	movz	x1, #0x0, lsl #48
    4cb8:      	bl	0x4cb8 <_stogir.uses.build+0x118>
		0000000000004cb8:  ARM64_RELOC_BRANCH26	_memset
    4cbc:      	add	x16, sp, #0x10
    4cc0:      	str	x19, [x16, #0x8]
    4cc4:      	ldr	x0, [x21, #0x8]
    4cc8:      	orr	x19, x0, xzr
    4ccc:      	add	x16, sp, #0x60
    4cd0:      	ldr	x0, [x16, #0x8]
    4cd4:      	orr	x22, x0, xzr
    4cd8:      	add	x16, sp, #0x60
    4cdc:      	ldr	x0, [x16, #0x10]
    4ce0:      	add	x23, x22, x19
    4ce4:      	cmp	x23, x0
    4ce8:      	b.le	0x4d1c <_stogir.uses.build+0x17c>
    4cec:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    4cf0:      	cmp	x0, x17
    4cf4:      	b.gt	0x4d00 <_stogir.uses.build+0x160>
    4cf8:      	lsl	x0, x0, #1
    4cfc:      	b	0x4d04 <_stogir.uses.build+0x164>
    4d00:      	mov	x0, x23
    4d04:      	cmp	x0, x23
    4d08:      	b.gt	0x4d10 <_stogir.uses.build+0x170>
    4d0c:      	mov	x0, x23
    4d10:      	mov	x1, x0
    4d14:      	add	x0, sp, #0x60
    4d18:      	bl	0x4d18 <_stogir.uses.build+0x178>
		0000000000004d18:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    4d1c:      	lsl	x0, x19, #3
    4d20:      	add	x16, sp, #0x60
    4d24:      	ldr	x1, [x16]
    4d28:      	add	x1, x1, x22, lsl #3
    4d2c:      	mov	x2, x0
    4d30:      	mov	x0, x1
    4d34:      	movz	x1, #0x0, lsl #48
    4d38:      	bl	0x4d38 <_stogir.uses.build+0x198>
		0000000000004d38:  ARM64_RELOC_BRANCH26	_memset
    4d3c:      	add	x16, sp, #0x60
    4d40:      	str	x23, [x16, #0x8]
    4d44:      	mov	x0, #0x1                ; =1
    4d48:      	b	0x4e48 <_stogir.uses.build+0x2a8>
    4d4c:      	sub	w4, w4, #0x1
    4d50:      	lsl	w4, w4, #2
    4d54:      	ubfx	x4, x4, #0, #32
    4d58:      	lsr	x4, x1, x4
    4d5c:      	and	w4, w4, #0xf
    4d60:      	b	0x4d6c <_stogir.uses.build+0x1cc>
    4d64:      	nop
    4d68:      	movz	w4, #0x0, lsl #16
    4d6c:      	ubfx	x4, x4, #0, #32
    4d70:      	cmp	x4, #0xf
    4d74:      	b.hs	0x4e00 <_stogir.uses.build+0x260>
    4d78:      	mov	x16, #0x1               ; =1
    4d7c:      	lsl	x4, x16, x4
    4d80:      	mov	w17, #0x5e1c            ; =24092
    4d84:      	and	w4, w4, w17
    4d88:      	ubfx	x4, x4, #0, #32
    4d8c:      	cmp	x4, #0x0
    4d90:      	b.eq	0x4e00 <_stogir.uses.build+0x260>
    4d94:      	ldr	x4, [x21]
    4d98:      	asr	x16, x5, #63
    4d9c:      	lsr	x16, x16, #62
    4da0:      	add	x6, x5, x16
    4da4:      	asr	x6, x6, #2
    4da8:      	asr	x16, x5, #63
    4dac:      	lsr	x16, x16, #62
    4db0:      	add	x5, x5, x16
    4db4:      	and	x5, x5, #0x3
    4db8:      	sub	x5, x5, x16
    4dbc:      	add	x6, x6, x0
    4dc0:      	add	x4, x4, x6, lsl #4
    4dc4:      	add	x4, x4, x5, lsl #2
    4dc8:      	ldr	w4, [x4]
    4dcc:      	sxtw	x4, w4
    4dd0:      	cmp	x4, #0x0
    4dd4:      	b.le	0x4e00 <_stogir.uses.build+0x260>
    4dd8:      	add	x16, sp, #0x10
    4ddc:      	ldr	x5, [x16]
    4de0:      	orr	x6, x5, xzr
    4de4:      	add	x6, x6, x4, lsl #4
    4de8:      	add	x4, x5, x4, lsl #4
    4dec:      	ldr	x5, [x6]
    4df0:      	ldr	x6, [x6, #0x8]
    4df4:      	add	x6, x6, #0x1
    4df8:      	str	x5, [x4]
    4dfc:      	str	x6, [x4, #0x8]
    4e00:      	add	x3, x3, #0x1
    4e04:      	sxtw	x3, w3
    4e08:      	cmp	x3, x2
    4e0c:      	b.gt	0x4e30 <_stogir.uses.build+0x290>
    4e10:      	orr	w4, w3, wzr
    4e14:      	sxtw	x5, w4
    4e18:      	cmp	x5, #0x0
    4e1c:      	b.le	0x4d68 <_stogir.uses.build+0x1c8>
    4e20:      	cmp	x5, #0x4
    4e24:      	b.le	0x4d4c <_stogir.uses.build+0x1ac>
    4e28:      	mov	w4, #0x4                ; =4
    4e2c:      	b	0x4d50 <_stogir.uses.build+0x1b0>
    4e30:      	add	x1, x2, #0x4
    4e34:      	asr	x16, x1, #63
    4e38:      	lsr	x16, x16, #62
    4e3c:      	add	x1, x1, x16
    4e40:      	asr	x1, x1, #2
    4e44:      	add	x0, x1, x0
    4e48:      	ldr	x1, [x21, #0x8]
    4e4c:      	cmp	x0, x1
    4e50:      	b.ge	0x4e8c <_stogir.uses.build+0x2ec>
    4e54:      	ldr	x1, [x21]
    4e58:      	add	x1, x1, x0, lsl #4
    4e5c:      	ldr	x1, [x1]
    4e60:      	ldr	x2, [x21, #0x78]
    4e64:      	uxtb	w1, w1
    4e68:      	add	x2, x2, x0, lsl #2
    4e6c:      	adrp	x16, 0x4000 <_stogir.loops.depths+0x3b8>
		0000000000004e6c:  ARM64_RELOC_PAGE21	l_stogir.418
    4e70:      	ldr	x16, [x16]
		0000000000004e70:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    4e74:      	add	x1, x16, x1, lsl #2
    4e78:      	ldr	w2, [x2]
    4e7c:      	sxtw	x2, w2
    4e80:      	ldr	w1, [x1]
    4e84:      	mov	x3, #0x1                ; =1
    4e88:      	b	0x4e08 <_stogir.uses.build+0x268>
    4e8c:      	movn	x0, #0x0, lsl #48
    4e90:      	movz	x19, #0x0, lsl #48
    4e94:      	b	0x4ed0 <_stogir.uses.build+0x330>
    4e98:      	add	x16, sp, #0x10
    4e9c:      	ldr	x1, [x16]
    4ea0:      	orr	x2, x1, xzr
    4ea4:      	add	x2, x2, x0, lsl #4
    4ea8:      	add	x1, x1, x0, lsl #4
    4eac:      	ldr	x2, [x2, #0x8]
    4eb0:      	add	x3, x2, x19
    4eb4:      	str	x19, [x1]
    4eb8:      	str	x2, [x1, #0x8]
    4ebc:      	add	x16, sp, #0x60
    4ec0:      	ldr	x1, [x16]
    4ec4:      	add	x1, x1, x0, lsl #3
    4ec8:      	str	x19, [x1]
    4ecc:      	mov	x19, x3
    4ed0:      	add	x16, sp, #0x10
    4ed4:      	ldr	x1, [x16, #0x8]
    4ed8:      	add	x0, x0, #0x1
    4edc:      	cmp	x0, x1
    4ee0:      	b.lt	0x4e98 <_stogir.uses.build+0x2f8>
    4ee4:      	add	x16, sp, #0x10
    4ee8:      	orr	x0, x16, xzr
    4eec:      	add	x22, x0, #0x28
    4ef0:      	ldr	x0, [x22, #0x8]
    4ef4:      	orr	x23, x0, xzr
    4ef8:      	ldr	x0, [x22, #0x10]
    4efc:      	add	x24, x23, x19
    4f00:      	cmp	x24, x0
    4f04:      	b.le	0x4f38 <_stogir.uses.build+0x398>
    4f08:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    4f0c:      	cmp	x0, x17
    4f10:      	b.gt	0x4f1c <_stogir.uses.build+0x37c>
    4f14:      	lsl	x0, x0, #1
    4f18:      	b	0x4f20 <_stogir.uses.build+0x380>
    4f1c:      	mov	x0, x24
    4f20:      	cmp	x0, x24
    4f24:      	b.gt	0x4f2c <_stogir.uses.build+0x38c>
    4f28:      	mov	x0, x24
    4f2c:      	mov	x1, x0
    4f30:      	mov	x0, x22
    4f34:      	bl	0x4f34 <_stogir.uses.build+0x394>
		0000000000004f34:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use
    4f38:      	lsl	x0, x19, #3
    4f3c:      	add	x16, sp, #0x10
    4f40:      	ldr	x1, [x16, #0x28]
    4f44:      	add	x1, x1, x23, lsl #3
    4f48:      	mov	x2, x0
    4f4c:      	mov	x0, x1
    4f50:      	movz	x1, #0x0, lsl #48
    4f54:      	bl	0x4f54 <_stogir.uses.build+0x3b4>
		0000000000004f54:  ARM64_RELOC_BRANCH26	_memset
    4f58:      	str	x24, [x22, #0x8]
    4f5c:      	mov	x0, x21
    4f60:      	add	x1, sp, #0x10
    4f64:      	add	x2, sp, #0x60
    4f68:      	bl	0x4f68 <_stogir.uses.build+0x3c8>
		0000000000004f68:  ARM64_RELOC_BRANCH26	_stogir.uses.scan!__constfalse
    4f6c:      	b	0x4f7c <_stogir.uses.build+0x3dc>
    4f70:      	sub	x0, x0, #0x1
    4f74:      	add	x16, sp, #0x60
    4f78:      	str	x0, [x16, #0x8]
    4f7c:      	add	x16, sp, #0x60
    4f80:      	ldr	x0, [x16, #0x8]
    4f84:      	cmp	x0, #0x0
    4f88:      	b.ne	0x4f70 <_stogir.uses.build+0x3d0>
    4f8c:      	add	x16, sp, #0x60
    4f90:      	orr	x0, x16, xzr
    4f94:      	add	x16, sp, #0x60
    4f98:      	ldr	x1, [x16, #0x10]
    4f9c:      	cmp	x1, #0x0
    4fa0:      	b.le	0x4fd0 <_stogir.uses.build+0x430>
    4fa4:      	add	x0, x0, #0x18
    4fa8:      	add	x16, sp, #0x60
    4fac:      	ldr	x2, [x16]
    4fb0:      	fmov	d31, x1
    4fb4:      	mov	x1, x2
    4fb8:      	fmov	x2, d31
    4fbc:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3b8>
		0000000000004fbc:  ARM64_RELOC_PAGE21	l_stogir.419
    4fc0:      	ldr	x3, [x3]
		0000000000004fc0:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    4fc4:      	mov	x4, #0x8                ; =8
    4fc8:      	mov	x5, #0x8                ; =8
    4fcc:      	bl	0x4fcc <_stogir.uses.build+0x42c>
		0000000000004fcc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4fd0:      	add	x16, sp, #0x60
    4fd4:      	movz	x17, #0x0, lsl #48
    4fd8:      	str	x17, [x16]
    4fdc:      	add	x16, sp, #0x60
    4fe0:      	movz	x17, #0x0, lsl #48
    4fe4:      	str	x17, [x16, #0x8]
    4fe8:      	add	x16, sp, #0x60
    4fec:      	movz	x17, #0x0, lsl #48
    4ff0:      	str	x17, [x16, #0x10]
    4ff4:      	add	x16, sp, #0x10
    4ff8:      	ldr	x0, [x16]
    4ffc:      	add	x16, sp, #0x10
    5000:      	ldr	x1, [x16, #0x8]
    5004:      	add	x16, sp, #0x10
    5008:      	ldr	x2, [x16, #0x10]
    500c:      	add	x16, sp, #0x10
    5010:      	ldr	x3, [x16, #0x18]
    5014:      	add	x16, sp, #0x10
    5018:      	ldr	x4, [x16, #0x20]
    501c:      	add	x16, sp, #0x10
    5020:      	ldr	x5, [x16, #0x28]
    5024:      	add	x16, sp, #0x10
    5028:      	ldr	x6, [x16, #0x30]
    502c:      	add	x16, sp, #0x10
    5030:      	ldr	x7, [x16, #0x38]
    5034:      	add	x16, sp, #0x10
    5038:      	ldr	x8, [x16, #0x40]
    503c:      	add	x16, sp, #0x10
    5040:      	ldr	x9, [x16, #0x48]
    5044:      	str	x0, [x20]
    5048:      	str	x1, [x20, #0x8]
    504c:      	str	x2, [x20, #0x10]
    5050:      	str	x3, [x20, #0x18]
    5054:      	str	x4, [x20, #0x20]
    5058:      	str	x5, [x20, #0x28]
    505c:      	str	x6, [x20, #0x30]
    5060:      	str	x7, [x20, #0x38]
    5064:      	str	x8, [x20, #0x40]
    5068:      	str	x9, [x20, #0x48]
    506c:      	ldr	x19, [sp, #0x90]
    5070:      	ldr	x20, [sp, #0x98]
    5074:      	ldr	x21, [sp, #0xa0]
    5078:      	ldr	x22, [sp, #0xa8]
    507c:      	ldr	x23, [sp, #0xb0]
    5080:      	ldr	x24, [sp, #0xb8]
    5084:      	ldr	x29, [sp]
    5088:      	ldr	x30, [sp, #0x8]
    508c:      	add	sp, sp, #0xc0
    5090:      	ret
    5094:      	mov	x20, x8
    5098:      	mov	x21, x0
    509c:      	b	0x4ca0 <_stogir.uses.build+0x100>

00000000000050a0 <_inherent$coil.arraylist.ArrayList$new__i32>:
    50a0:      	ldr	x1, [x0]
    50a4:      	ldr	x0, [x0, #0x8]
    50a8:      	movz	x17, #0x0, lsl #48
    50ac:      	str	x17, [x8]
    50b0:      	movz	x17, #0x0, lsl #48
    50b4:      	str	x17, [x8, #0x8]
    50b8:      	movz	x17, #0x0, lsl #48
    50bc:      	str	x17, [x8, #0x10]
    50c0:      	str	x1, [x8, #0x18]
    50c4:      	str	x0, [x8, #0x20]
    50c8:      	ret
    50cc:      	udf	#0x0

00000000000050d0 <_stogir.placement.pinned>:
    50d0:      	sub	sp, sp, #0xb0
    50d4:      	str	x29, [sp, #0x10]
    50d8:      	str	x30, [sp, #0x18]
    50dc:      	add	x29, sp, #0x10
    50e0:      	str	x19, [sp, #0x60]
    50e4:      	str	x20, [sp, #0x68]
    50e8:      	str	x21, [sp, #0x70]
    50ec:      	str	x22, [sp, #0x78]
    50f0:      	str	x23, [sp, #0x80]
    50f4:      	str	x24, [sp, #0x88]
    50f8:      	str	x25, [sp, #0x90]
    50fc:      	str	x26, [sp, #0x98]
    5100:      	str	x27, [sp, #0xa0]
    5104:      	add	x19, x1, #0x28
    5108:      	ldr	x3, [x2]
    510c:      	ldr	x2, [x2, #0x8]
    5110:      	add	x16, sp, #0x20
    5114:      	movz	x17, #0x0, lsl #48
    5118:      	str	x17, [x16]
    511c:      	add	x16, sp, #0x20
    5120:      	movz	x17, #0x0, lsl #48
    5124:      	str	x17, [x16, #0x8]
    5128:      	add	x16, sp, #0x20
    512c:      	movz	x17, #0x0, lsl #48
    5130:      	str	x17, [x16, #0x10]
    5134:      	add	x16, sp, #0x20
    5138:      	str	x3, [x16, #0x18]
    513c:      	add	x16, sp, #0x20
    5140:      	str	x2, [x16, #0x20]
    5144:      	movz	x20, #0x0, lsl #48
    5148:      	b	0x5198 <_stogir.placement.pinned+0xc8>
    514c:      	nop
    5150:      	lsl	x2, x2, #1
    5154:      	mov	x23, x8
    5158:      	mov	x24, x0
    515c:      	add	x0, sp, #0x20
    5160:      	mov	x25, x1
    5164:      	mov	x1, x2
    5168:      	bl	0x5168 <_stogir.placement.pinned+0x98>
		0000000000005168:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    516c:      	add	x20, x20, #0x1
    5170:      	add	x0, x22, #0x1
    5174:      	add	x16, sp, #0x20
    5178:      	ldr	x1, [x16]
    517c:      	add	x1, x1, x22, lsl #2
    5180:      	str	w21, [x1]
    5184:      	add	x16, sp, #0x20
    5188:      	str	x0, [x16, #0x8]
    518c:      	mov	x8, x23
    5190:      	mov	x0, x24
    5194:      	mov	x1, x25
    5198:      	ldr	x2, [x19, #0x8]
    519c:      	cmp	x20, x2
    51a0:      	b.ge	0x561c <_stogir.placement.pinned+0x54c>
    51a4:      	ldr	x2, [x1, #0x28]
    51a8:      	add	x2, x2, x20, lsl #2
    51ac:      	ldr	w21, [x2]
    51b0:      	add	x16, sp, #0x20
    51b4:      	ldr	x2, [x16, #0x8]
    51b8:      	orr	x22, x2, xzr
    51bc:      	add	x16, sp, #0x20
    51c0:      	ldr	x2, [x16, #0x10]
    51c4:      	cmp	x22, x2
    51c8:      	b.lt	0x5628 <_stogir.placement.pinned+0x558>
    51cc:      	cmp	x2, #0x0
    51d0:      	b.ne	0x5150 <_stogir.placement.pinned+0x80>
    51d4:      	mov	x2, #0x2                ; =2
    51d8:      	b	0x5154 <_stogir.placement.pinned+0x84>
    51dc:      	add	x19, x24, #0x78
    51e0:      	add	x20, x24, #0x28
    51e4:      	add	x21, x24, #0x50
    51e8:      	mov	x22, #0x1               ; =1
    51ec:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		00000000000051ec:  ARM64_RELOC_PAGE21	l_stogir.420
    51f0:      	ldr	x25, [x25]
		00000000000051f0:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    51f4:      	movz	x26, #0x0, lsl #48
    51f8:      	b	0x5298 <_stogir.placement.pinned+0x1c8>
    51fc:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		00000000000051fc:  ARM64_RELOC_PAGE21	l_stogir.421
    5200:      	ldr	x25, [x25]
		0000000000005200:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    5204:      	mov	x26, #0x15              ; =21
    5208:      	b	0x527c <_stogir.placement.pinned+0x1ac>
    520c:      	nop
    5210:      	movz	w0, #0x0, lsl #16
    5214:      	uxtb	w16, w0
    5218:      	and	w0, w16, #0x20
    521c:      	uxtb	w0, w0
    5220:      	ubfx	x0, x0, #0, #8
    5224:      	cmp	x0, #0x0
    5228:      	b.eq	0x527c <_stogir.placement.pinned+0x1ac>
    522c:      	orr	w0, w22, wzr
    5230:      	mov	w1, w0
    5234:      	mov	x0, x24
    5238:      	mov	x2, #0x1                ; =1
    523c:      	bl	0x523c <_stogir.placement.pinned+0x16c>
		000000000000523c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5240:      	ubfx	x0, x0, #0, #32
    5244:      	lsr	x16, x0, #0
    5248:      	cmp	x16, #0x1
    524c:      	b.eq	0x5268 <_stogir.placement.pinned+0x198>
    5250:      	b.lo	0x5258 <_stogir.placement.pinned+0x188>
    5254:      	b	0x526c <_stogir.placement.pinned+0x19c>
    5258:      	cmp	x16, #0x0
    525c:      	b.eq	0x5264 <_stogir.placement.pinned+0x194>
    5260:      	b	0x526c <_stogir.placement.pinned+0x19c>
    5264:      	b	0x5270 <_stogir.placement.pinned+0x1a0>
    5268:      	b	0x52e4 <_stogir.placement.pinned+0x214>
    526c:      	b	0x560c <_stogir.placement.pinned+0x53c>
    5270:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		0000000000005270:  ARM64_RELOC_PAGE21	l_stogir.422
    5274:      	ldr	x25, [x25]
		0000000000005274:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    5278:      	mov	x26, #0x19              ; =25
    527c:      	sxtw	x27, w27
    5280:      	add	x0, x27, #0x4
    5284:      	asr	x16, x0, #63
    5288:      	lsr	x16, x16, #62
    528c:      	add	x0, x0, x16
    5290:      	asr	x0, x0, #2
    5294:      	add	x22, x0, x22
    5298:      	cmp	x26, #0x0
    529c:      	b.ne	0x532c <_stogir.placement.pinned+0x25c>
    52a0:      	ldr	x0, [x24, #0x8]
    52a4:      	cmp	x22, x0
    52a8:      	b.ge	0x532c <_stogir.placement.pinned+0x25c>
    52ac:      	ldr	x0, [x24]
    52b0:      	add	x0, x0, x22, lsl #4
    52b4:      	ldr	x0, [x0]
    52b8:      	ldr	x1, [x24, #0x78]
    52bc:      	uxtb	w0, w0
    52c0:      	add	x1, x1, x22, lsl #2
    52c4:      	ldr	w27, [x1]
    52c8:      	cmp	x0, #0x83
    52cc:      	b.ge	0x5210 <_stogir.placement.pinned+0x140>
    52d0:      	adrp	x17, 0x5000 <_stogir.uses.build+0x460>
		00000000000052d0:  ARM64_RELOC_PAGE21	l_stogir.423
    52d4:      	ldr	x17, [x17]
		00000000000052d4:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    52d8:      	add	x0, x0, x17
    52dc:      	ldrb	w0, [x0]
    52e0:      	b	0x5214 <_stogir.placement.pinned+0x144>
    52e4:      	sxtw	x0, w1
    52e8:      	cmp	x0, #0x0
    52ec:      	b.le	0x51fc <_stogir.placement.pinned+0x12c>
    52f0:      	lsl	x2, x0, #2
    52f4:      	ldr	x3, [x24, #0x8]
    52f8:      	cmp	x0, x3
    52fc:      	b.ge	0x5450 <_stogir.placement.pinned+0x380>
    5300:      	ldr	x3, [x19, #0x8]
    5304:      	cmp	x0, x3
    5308:      	b.ge	0x5448 <_stogir.placement.pinned+0x378>
    530c:      	ldr	x3, [x24, #0x78]
    5310:      	add	x3, x2, x3
    5314:      	ldr	w3, [x3]
    5318:      	sxtw	x3, w3
    531c:      	cmp	x3, #0x0
    5320:      	cset	w3, ge
    5324:      	ubfx	x3, x3, #0, #8
    5328:      	b	0x544c <_stogir.placement.pinned+0x37c>
    532c:      	cmp	x26, #0x0
    5330:      	b.ne	0x5364 <_stogir.placement.pinned+0x294>
    5334:      	add	x16, sp, #0x20
    5338:      	ldr	x25, [x16]
    533c:      	add	x16, sp, #0x20
    5340:      	ldr	x26, [x16, #0x8]
    5344:      	add	x16, sp, #0x20
    5348:      	ldr	x0, [x16, #0x10]
    534c:      	add	x16, sp, #0x20
    5350:      	ldr	x1, [x16, #0x18]
    5354:      	add	x16, sp, #0x20
    5358:      	ldr	x2, [x16, #0x20]
    535c:      	movz	x3, #0x0, lsl #48
    5360:      	b	0x53fc <_stogir.placement.pinned+0x32c>
    5364:      	b	0x5374 <_stogir.placement.pinned+0x2a4>
    5368:      	sub	x0, x0, #0x1
    536c:      	add	x16, sp, #0x20
    5370:      	str	x0, [x16, #0x8]
    5374:      	add	x16, sp, #0x20
    5378:      	ldr	x0, [x16, #0x8]
    537c:      	cmp	x0, #0x0
    5380:      	b.ne	0x5368 <_stogir.placement.pinned+0x298>
    5384:      	add	x16, sp, #0x20
    5388:      	orr	x0, x16, xzr
    538c:      	add	x16, sp, #0x20
    5390:      	ldr	x1, [x16, #0x10]
    5394:      	cmp	x1, #0x0
    5398:      	b.le	0x53c8 <_stogir.placement.pinned+0x2f8>
    539c:      	add	x0, x0, #0x18
    53a0:      	add	x16, sp, #0x20
    53a4:      	ldr	x2, [x16]
    53a8:      	fmov	d31, x1
    53ac:      	mov	x1, x2
    53b0:      	fmov	x2, d31
    53b4:      	adrp	x3, 0x5000 <_stogir.uses.build+0x460>
		00000000000053b4:  ARM64_RELOC_PAGE21	l_stogir.424
    53b8:      	ldr	x3, [x3]
		00000000000053b8:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    53bc:      	mov	x4, #0x4                ; =4
    53c0:      	mov	x5, #0x4                ; =4
    53c4:      	bl	0x53c4 <_stogir.placement.pinned+0x2f4>
		00000000000053c4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    53c8:      	add	x16, sp, #0x20
    53cc:      	movz	x17, #0x0, lsl #48
    53d0:      	str	x17, [x16]
    53d4:      	add	x16, sp, #0x20
    53d8:      	movz	x17, #0x0, lsl #48
    53dc:      	str	x17, [x16, #0x8]
    53e0:      	add	x16, sp, #0x20
    53e4:      	movz	x17, #0x0, lsl #48
    53e8:      	str	x17, [x16, #0x10]
    53ec:      	mov	x3, #0x1                ; =1
    53f0:      	movz	x0, #0x0, lsl #48
    53f4:      	movz	x1, #0x0, lsl #48
    53f8:      	movz	x2, #0x0, lsl #48
    53fc:      	str	x3, [x23]
    5400:      	str	x25, [x23, #0x8]
    5404:      	str	x26, [x23, #0x10]
    5408:      	str	x0, [x23, #0x18]
    540c:      	str	x1, [x23, #0x20]
    5410:      	str	x2, [x23, #0x28]
    5414:      	ldr	x19, [sp, #0x60]
    5418:      	ldr	x20, [sp, #0x68]
    541c:      	ldr	x21, [sp, #0x70]
    5420:      	ldr	x22, [sp, #0x78]
    5424:      	ldr	x23, [sp, #0x80]
    5428:      	ldr	x24, [sp, #0x88]
    542c:      	ldr	x25, [sp, #0x90]
    5430:      	ldr	x26, [sp, #0x98]
    5434:      	ldr	x27, [sp, #0xa0]
    5438:      	ldr	x29, [sp, #0x10]
    543c:      	ldr	x30, [sp, #0x18]
    5440:      	add	sp, sp, #0xb0
    5444:      	ret
    5448:      	movz	x3, #0x0, lsl #48
    544c:      	b	0x5454 <_stogir.placement.pinned+0x384>
    5450:      	movz	x3, #0x0, lsl #48
    5454:      	cmp	x3, #0x0
    5458:      	b.eq	0x51fc <_stogir.placement.pinned+0x12c>
    545c:      	movz	x16, #0x0, lsl #48
    5460:      	sub	x3, x16, x0
    5464:      	cmp	x0, #0x0
    5468:      	cset	w4, gt
    546c:      	sub	x5, x3, #0x1
    5470:      	uxtb	w16, w4
    5474:      	cmp	w16, wzr
    5478:      	b.eq	0x54c4 <_stogir.placement.pinned+0x3f4>
    547c:      	ldr	x3, [x24, #0x8]
    5480:      	cmp	x0, x3
    5484:      	b.ge	0x5504 <_stogir.placement.pinned+0x434>
    5488:      	ldr	x3, [x19, #0x8]
    548c:      	cmp	x0, x3
    5490:      	b.ge	0x55b8 <_stogir.placement.pinned+0x4e8>
    5494:      	ldr	x3, [x24, #0x78]
    5498:      	add	x2, x2, x3
    549c:      	ldr	w2, [x2]
    54a0:      	sxtw	x2, w2
    54a4:      	cmp	x2, #0x0
    54a8:      	cset	w2, ge
    54ac:      	ubfx	x2, x2, #0, #8
    54b0:      	b	0x55bc <_stogir.placement.pinned+0x4ec>
    54b4:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		00000000000054b4:  ARM64_RELOC_PAGE21	l_stogir.425
    54b8:      	ldr	x25, [x25]
		00000000000054b8:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    54bc:      	mov	x26, #0x20              ; =32
    54c0:      	b	0x5208 <_stogir.placement.pinned+0x138>
    54c4:      	cmp	x0, #0x0
    54c8:      	b.ge	0x550c <_stogir.placement.pinned+0x43c>
    54cc:      	ldr	x2, [x20, #0x8]
    54d0:      	ldr	x6, [x21, #0x8]
    54d4:      	cmp	x2, x6
    54d8:      	b.ne	0x55b0 <_stogir.placement.pinned+0x4e0>
    54dc:      	cmp	x3, x2
    54e0:      	b.gt	0x5604 <_stogir.placement.pinned+0x534>
    54e4:      	ldr	x2, [x24, #0x50]
    54e8:      	add	x2, x2, x5, lsl #2
    54ec:      	ldr	w2, [x2]
    54f0:      	sxtw	x2, w2
    54f4:      	cmp	x2, #0x0
    54f8:      	cset	w2, gt
    54fc:      	ubfx	x2, x2, #0, #8
    5500:      	b	0x5608 <_stogir.placement.pinned+0x538>
    5504:      	movz	x2, #0x0, lsl #48
    5508:      	b	0x5510 <_stogir.placement.pinned+0x440>
    550c:      	movz	x2, #0x0, lsl #48
    5510:      	cmp	x2, #0x0
    5514:      	b.eq	0x5548 <_stogir.placement.pinned+0x478>
    5518:      	uxtb	w16, w4
    551c:      	cmp	w16, wzr
    5520:      	b.eq	0x5534 <_stogir.placement.pinned+0x464>
    5524:      	ldr	x2, [x24]
    5528:      	add	x0, x2, x0, lsl #4
    552c:      	ldr	x0, [x0]
    5530:      	b	0x5540 <_stogir.placement.pinned+0x470>
    5534:      	ldr	x0, [x24, #0x28]
    5538:      	add	x0, x0, x5, lsl #4
    553c:      	ldr	x0, [x0]
    5540:      	mov	w2, #0x1                ; =1
    5544:      	b	0x5550 <_stogir.placement.pinned+0x480>
    5548:      	movz	w2, #0x0, lsl #16
    554c:      	movz	x0, #0x0, lsl #48
    5550:      	ubfx	x2, x2, #0, #32
    5554:      	lsr	x16, x2, #0
    5558:      	cmp	x16, #0x1
    555c:      	b.eq	0x5578 <_stogir.placement.pinned+0x4a8>
    5560:      	b.lo	0x5568 <_stogir.placement.pinned+0x498>
    5564:      	b	0x557c <_stogir.placement.pinned+0x4ac>
    5568:      	cmp	x16, #0x0
    556c:      	b.eq	0x5574 <_stogir.placement.pinned+0x4a4>
    5570:      	b	0x557c <_stogir.placement.pinned+0x4ac>
    5574:      	b	0x5580 <_stogir.placement.pinned+0x4b0>
    5578:      	b	0x5590 <_stogir.placement.pinned+0x4c0>
    557c:      	b	0x5614 <_stogir.placement.pinned+0x544>
    5580:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		0000000000005580:  ARM64_RELOC_PAGE21	l_stogir.421
    5584:      	ldr	x25, [x25]
		0000000000005584:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    5588:      	mov	x26, #0x15              ; =21
    558c:      	b	0x54c0 <_stogir.placement.pinned+0x3f0>
    5590:      	uxtb	w0, w0
    5594:      	cmp	x0, #0x83
    5598:      	b.ge	0x55c0 <_stogir.placement.pinned+0x4f0>
    559c:      	adrp	x17, 0x5000 <_stogir.uses.build+0x460>
		000000000000559c:  ARM64_RELOC_PAGE21	l_stogir.423
    55a0:      	ldr	x17, [x17]
		00000000000055a0:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    55a4:      	add	x0, x0, x17
    55a8:      	ldrb	w0, [x0]
    55ac:      	b	0x55c4 <_stogir.placement.pinned+0x4f4>
    55b0:      	movz	x2, #0x0, lsl #48
    55b4:      	b	0x5510 <_stogir.placement.pinned+0x440>
    55b8:      	movz	x2, #0x0, lsl #48
    55bc:      	b	0x5508 <_stogir.placement.pinned+0x438>
    55c0:      	movz	w0, #0x0, lsl #16
    55c4:      	uxtb	w16, w0
    55c8:      	and	w0, w16, #0x2
    55cc:      	uxtb	w0, w0
    55d0:      	ubfx	x0, x0, #0, #8
    55d4:      	cmp	x0, #0x0
    55d8:      	cset	w0, eq
    55dc:      	uxtb	w16, w0
    55e0:      	cmp	w16, wzr
    55e4:      	cset	x0, eq
    55e8:      	cmp	x0, #0x0
    55ec:      	b.eq	0x54b4 <_stogir.placement.pinned+0x3e4>
    55f0:      	add	x16, sp, #0x20
    55f4:      	ldr	x0, [x16]
    55f8:      	add	x0, x0, x22, lsl #2
    55fc:      	str	w1, [x0]
    5600:      	b	0x54c0 <_stogir.placement.pinned+0x3f0>
    5604:      	movz	x2, #0x0, lsl #48
    5608:      	b	0x55b4 <_stogir.placement.pinned+0x4e4>
    560c:      	brk	#0
    5610:      	b	0x560c <_stogir.placement.pinned+0x53c>
    5614:      	brk	#0
    5618:      	b	0x5614 <_stogir.placement.pinned+0x544>
    561c:      	mov	x23, x8
    5620:      	mov	x24, x0
    5624:      	b	0x51dc <_stogir.placement.pinned+0x10c>
    5628:      	mov	x23, x8
    562c:      	mov	x24, x0
    5630:      	mov	x25, x1
    5634:      	b	0x516c <_stogir.placement.pinned+0x9c>

0000000000005638 <_stogir.placement.early-with-uses!>:
    5638:      	sub	sp, sp, #0x1b0
    563c:      	str	x29, [sp, #0x10]
    5640:      	str	x30, [sp, #0x18]
    5644:      	add	x29, sp, #0x10
    5648:      	str	x19, [sp, #0x158]
    564c:      	str	x20, [sp, #0x160]
    5650:      	str	x21, [sp, #0x168]
    5654:      	str	x22, [sp, #0x170]
    5658:      	str	x23, [sp, #0x178]
    565c:      	str	x24, [sp, #0x180]
    5660:      	str	x25, [sp, #0x188]
    5664:      	str	x26, [sp, #0x190]
    5668:      	str	x27, [sp, #0x198]
    566c:      	str	x28, [sp, #0x1a0]
    5670:      	mov	x19, x8
    5674:      	add	x8, sp, #0x50
    5678:      	mov	x20, x0
    567c:      	mov	x0, x5
    5680:      	mov	x21, x1
    5684:      	mov	x22, x2
    5688:      	mov	w23, w3
    568c:      	mov	x24, x4
    5690:      	mov	x25, x5
    5694:      	bl	0x5694 <_stogir.placement.early-with-uses!+0x5c>
		0000000000005694:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    5698:      	add	x16, sp, #0x50
    569c:      	ldr	x0, [x16]
    56a0:      	add	x16, sp, #0x20
    56a4:      	str	x0, [x16]
    56a8:      	add	x16, sp, #0x50
    56ac:      	ldr	x0, [x16, #0x8]
    56b0:      	add	x16, sp, #0x20
    56b4:      	str	x0, [x16, #0x8]
    56b8:      	add	x16, sp, #0x50
    56bc:      	ldr	x0, [x16, #0x10]
    56c0:      	add	x16, sp, #0x20
    56c4:      	str	x0, [x16, #0x10]
    56c8:      	add	x16, sp, #0x50
    56cc:      	ldr	x0, [x16, #0x18]
    56d0:      	add	x16, sp, #0x20
    56d4:      	str	x0, [x16, #0x18]
    56d8:      	add	x16, sp, #0x50
    56dc:      	ldr	x0, [x16, #0x20]
    56e0:      	add	x16, sp, #0x20
    56e4:      	str	x0, [x16, #0x20]
    56e8:      	add	x8, sp, #0xb0
    56ec:      	mov	x0, x25
    56f0:      	bl	0x56f0 <_stogir.placement.early-with-uses!+0xb8>
		00000000000056f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    56f4:      	add	x16, sp, #0xb0
    56f8:      	ldr	x0, [x16]
    56fc:      	add	x16, sp, #0x80
    5700:      	str	x0, [x16]
    5704:      	add	x16, sp, #0xb0
    5708:      	ldr	x0, [x16, #0x8]
    570c:      	add	x16, sp, #0x80
    5710:      	str	x0, [x16, #0x8]
    5714:      	add	x16, sp, #0xb0
    5718:      	ldr	x0, [x16, #0x10]
    571c:      	add	x16, sp, #0x80
    5720:      	str	x0, [x16, #0x10]
    5724:      	add	x16, sp, #0xb0
    5728:      	ldr	x0, [x16, #0x18]
    572c:      	add	x16, sp, #0x80
    5730:      	str	x0, [x16, #0x18]
    5734:      	add	x16, sp, #0xb0
    5738:      	ldr	x0, [x16, #0x20]
    573c:      	add	x16, sp, #0x80
    5740:      	str	x0, [x16, #0x20]
    5744:      	movz	x25, #0x0, lsl #48
    5748:      	b	0x5784 <_stogir.placement.early-with-uses!+0x14c>
    574c:      	nop
    5750:      	lsl	x0, x0, #1
    5754:      	mov	x1, x0
    5758:      	add	x0, sp, #0x20
    575c:      	bl	0x575c <_stogir.placement.early-with-uses!+0x124>
		000000000000575c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5760:      	add	x25, x25, #0x1
    5764:      	add	x0, x26, #0x1
    5768:      	add	x16, sp, #0x20
    576c:      	ldr	x1, [x16]
    5770:      	add	x1, x1, x26, lsl #2
    5774:      	movn	w17, #0x0, lsl #16
    5778:      	str	w17, [x1]
    577c:      	add	x16, sp, #0x20
    5780:      	str	x0, [x16, #0x8]
    5784:      	ldr	x0, [x20, #0x8]
    5788:      	cmp	x25, x0
    578c:      	b.ge	0x57bc <_stogir.placement.early-with-uses!+0x184>
    5790:      	add	x16, sp, #0x20
    5794:      	ldr	x0, [x16, #0x8]
    5798:      	orr	x26, x0, xzr
    579c:      	add	x16, sp, #0x20
    57a0:      	ldr	x0, [x16, #0x10]
    57a4:      	cmp	x26, x0
    57a8:      	b.lt	0x5760 <_stogir.placement.early-with-uses!+0x128>
    57ac:      	cmp	x0, #0x0
    57b0:      	b.ne	0x5750 <_stogir.placement.early-with-uses!+0x118>
    57b4:      	mov	x0, #0x2                ; =2
    57b8:      	b	0x5754 <_stogir.placement.early-with-uses!+0x11c>
    57bc:      	mov	x25, #0x1               ; =1
    57c0:      	movz	x26, #0x0, lsl #48
    57c4:      	adrp	x27, 0x5000 <_stogir.uses.build+0x460>
		00000000000057c4:  ARM64_RELOC_PAGE21	l_stogir.426
    57c8:      	ldr	x27, [x27]
		00000000000057c8:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    57cc:      	movz	x28, #0x0, lsl #48
    57d0:      	b	0x5830 <_stogir.placement.early-with-uses!+0x1f8>
    57d4:      	lsl	x0, x0, #1
    57d8:      	mov	x1, x0
    57dc:      	add	x0, sp, #0x80
    57e0:      	bl	0x57e0 <_stogir.placement.early-with-uses!+0x1a8>
		00000000000057e0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    57e4:      	add	x0, x22, #0x1
    57e8:      	add	x16, sp, #0x80
    57ec:      	ldr	x1, [x16]
    57f0:      	add	x1, x1, x22, lsl #2
    57f4:      	str	w27, [x1]
    57f8:      	add	x16, sp, #0x80
    57fc:      	str	x0, [x16, #0x8]
    5800:      	add	x0, x26, #0x1
    5804:      	sxtw	x26, w0
    5808:      	add	x0, x19, #0x4
    580c:      	asr	x16, x0, #63
    5810:      	lsr	x16, x16, #62
    5814:      	add	x0, x0, x16
    5818:      	asr	x0, x0, #2
    581c:      	add	x25, x0, x25
    5820:      	ldr	x19, [sp, #0x108]
    5824:      	ldr	x22, [sp, #0x128]
    5828:      	ldr	x24, [sp, #0x120]
    582c:      	ldr	x27, [sp, #0x110]
    5830:      	ldr	x0, [x20, #0x8]
    5834:      	cmp	x25, x0
    5838:      	b.ge	0x5f60 <_stogir.placement.early-with-uses!+0x928>
    583c:      	lsl	x0, x25, #2
    5840:      	ldr	x1, [x20]
    5844:      	add	x1, x1, x25, lsl #4
    5848:      	ldr	x1, [x1]
    584c:      	ldr	x2, [x20, #0x78]
    5850:      	uxtb	w1, w1
    5854:      	add	x2, x2, x25, lsl #2
    5858:      	cmp	x1, #0x83
    585c:      	cset	w3, lt
    5860:      	ldr	w2, [x2]
    5864:      	uxtb	w16, w3
    5868:      	cmp	w16, wzr
    586c:      	b.eq	0x5884 <_stogir.placement.early-with-uses!+0x24c>
    5870:      	adrp	x17, 0x5000 <_stogir.uses.build+0x460>
		0000000000005870:  ARM64_RELOC_PAGE21	l_stogir.427
    5874:      	ldr	x17, [x17]
		0000000000005874:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    5878:      	add	x4, x1, x17
    587c:      	ldrb	w4, [x4]
    5880:      	b	0x5888 <_stogir.placement.early-with-uses!+0x250>
    5884:      	movz	w4, #0x0, lsl #16
    5888:      	ldr	x5, [x21]
    588c:      	add	x0, x5, x0
    5890:      	ldr	w0, [x0]
    5894:      	sxtw	x0, w0
    5898:      	cmp	x0, #0x0
    589c:      	b.ne	0x58c8 <_stogir.placement.early-with-uses!+0x290>
    58a0:      	uxtb	w16, w4
    58a4:      	and	w0, w16, #0x40
    58a8:      	uxtb	w0, w0
    58ac:      	ubfx	x0, x0, #0, #8
    58b0:      	cmp	x0, #0x0
    58b4:      	b.ne	0x58c0 <_stogir.placement.early-with-uses!+0x288>
    58b8:      	movz	x0, #0x0, lsl #48
    58bc:      	b	0x58c4 <_stogir.placement.early-with-uses!+0x28c>
    58c0:      	mov	x0, #0x1                ; =1
    58c4:      	b	0x58cc <_stogir.placement.early-with-uses!+0x294>
    58c8:      	movz	x0, #0x0, lsl #48
    58cc:      	sxtw	x2, w2
    58d0:      	cmp	x0, #0x0
    58d4:      	b.eq	0x5f74 <_stogir.placement.early-with-uses!+0x93c>
    58d8:      	orr	w0, w25, wzr
    58dc:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		00000000000058dc:  ARM64_RELOC_PAGE21	l_stogir.428
    58e0:      	ldr	x16, [x16]
		00000000000058e0:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    58e4:      	add	x1, x16, x1, lsl #2
    58e8:      	mov	x4, #0x1                ; =1
    58ec:      	movz	x5, #0x0, lsl #48
    58f0:      	b	0x5968 <_stogir.placement.early-with-uses!+0x330>
    58f4:      	sub	w7, w6, #0x1
    58f8:      	lsl	w7, w7, #2
    58fc:      	ubfx	x7, x7, #0, #32
    5900:      	lsr	x7, x8, x7
    5904:      	and	w7, w7, #0xf
    5908:      	b	0x59a4 <_stogir.placement.early-with-uses!+0x36c>
    590c:      	sxtw	x1, w1
    5910:      	cmp	x1, #0x0
    5914:      	b.le	0x5938 <_stogir.placement.early-with-uses!+0x300>
    5918:      	ldr	x0, [x21]
    591c:      	add	x0, x0, x1, lsl #2
    5920:      	ldr	w0, [x0]
    5924:      	sxtw	x0, w0
    5928:      	cmp	x0, #0x0
    592c:      	b.ne	0x5938 <_stogir.placement.early-with-uses!+0x300>
    5930:      	add	x0, x22, #0x1
    5934:      	sxtw	x22, w0
    5938:      	add	x0, x24, #0x1
    593c:      	sxtw	x24, w0
    5940:      	mov	x2, x19
    5944:      	ldr	x19, [sp, #0x108]
    5948:      	mov	w0, w27
    594c:      	ldr	w3, [sp, #0x100]
    5950:      	ldr	x1, [sp, #0x118]
    5954:      	mov	x4, x24
    5958:      	ldr	x24, [sp, #0x120]
    595c:      	mov	x5, x22
    5960:      	ldr	x22, [sp, #0x128]
    5964:      	ldr	x27, [sp, #0x110]
    5968:      	cmp	x4, x2
    596c:      	b.gt	0x5f8c <_stogir.placement.early-with-uses!+0x954>
    5970:      	orr	w6, w4, wzr
    5974:      	uxtb	w16, w3
    5978:      	cmp	w16, wzr
    597c:      	b.eq	0x59a8 <_stogir.placement.early-with-uses!+0x370>
    5980:      	sxtw	x7, w6
    5984:      	ldr	w8, [x1]
    5988:      	cmp	x7, #0x0
    598c:      	b.le	0x59a0 <_stogir.placement.early-with-uses!+0x368>
    5990:      	cmp	x7, #0x4
    5994:      	b.le	0x58f4 <_stogir.placement.early-with-uses!+0x2bc>
    5998:      	mov	w7, #0x4                ; =4
    599c:      	b	0x58f8 <_stogir.placement.early-with-uses!+0x2c0>
    59a0:      	movz	w7, #0x0, lsl #16
    59a4:      	b	0x59ac <_stogir.placement.early-with-uses!+0x374>
    59a8:      	movz	w7, #0x0, lsl #16
    59ac:      	ubfx	x7, x7, #0, #32
    59b0:      	cmp	x7, #0xf
    59b4:      	b.hs	0x5fac <_stogir.placement.early-with-uses!+0x974>
    59b8:      	mov	x16, #0x1               ; =1
    59bc:      	lsl	x7, x16, x7
    59c0:      	mov	w17, #0x5e1c            ; =24092
    59c4:      	and	w7, w7, w17
    59c8:      	ubfx	x7, x7, #0, #32
    59cc:      	cmp	x7, #0x0
    59d0:      	b.eq	0x5fd8 <_stogir.placement.early-with-uses!+0x9a0>
    59d4:      	str	w3, [sp, #0x100]
    59d8:      	str	x1, [sp, #0x118]
    59dc:      	mov	w1, w0
    59e0:      	str	x19, [sp, #0x108]
    59e4:      	mov	x19, x2
    59e8:      	mov	w2, w6
    59ec:      	str	x27, [sp, #0x110]
    59f0:      	mov	w27, w0
    59f4:      	mov	x0, x20
    59f8:      	str	x24, [sp, #0x120]
    59fc:      	mov	x24, x4
    5a00:      	str	x22, [sp, #0x128]
    5a04:      	mov	x22, x5
    5a08:      	bl	0x5a08 <_stogir.placement.early-with-uses!+0x3d0>
		0000000000005a08:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5a0c:      	ubfx	x0, x0, #0, #32
    5a10:      	lsr	x16, x0, #0
    5a14:      	cmp	x16, #0x1
    5a18:      	b.eq	0x5a34 <_stogir.placement.early-with-uses!+0x3fc>
    5a1c:      	b.lo	0x5a24 <_stogir.placement.early-with-uses!+0x3ec>
    5a20:      	b	0x5a38 <_stogir.placement.early-with-uses!+0x400>
    5a24:      	cmp	x16, #0x0
    5a28:      	b.eq	0x5a30 <_stogir.placement.early-with-uses!+0x3f8>
    5a2c:      	b	0x5a38 <_stogir.placement.early-with-uses!+0x400>
    5a30:      	b	0x5a3c <_stogir.placement.early-with-uses!+0x404>
    5a34:      	b	0x590c <_stogir.placement.early-with-uses!+0x2d4>
    5a38:      	b	0x5f58 <_stogir.placement.early-with-uses!+0x920>
    5a3c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		0000000000005a3c:  ARM64_RELOC_PAGE21	l_stogir.429
    5a40:      	ldr	x16, [x16]
		0000000000005a40:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    5a44:      	str	x16, [sp, #0x110]
    5a48:      	mov	x28, #0x18              ; =24
    5a4c:      	b	0x5938 <_stogir.placement.early-with-uses!+0x300>
    5a50:      	orr	w0, w22, wzr
    5a54:      	add	x16, sp, #0x20
    5a58:      	ldr	x1, [x16]
    5a5c:      	add	x1, x1, x25, lsl #2
    5a60:      	str	w0, [x1]
    5a64:      	cmp	x22, #0x0
    5a68:      	b.ne	0x5800 <_stogir.placement.early-with-uses!+0x1c8>
    5a6c:      	add	x16, sp, #0x80
    5a70:      	ldr	x0, [x16, #0x8]
    5a74:      	orr	x22, x0, xzr
    5a78:      	add	x16, sp, #0x80
    5a7c:      	ldr	x0, [x16, #0x10]
    5a80:      	cmp	x22, x0
    5a84:      	b.lt	0x57e4 <_stogir.placement.early-with-uses!+0x1ac>
    5a88:      	cmp	x0, #0x0
    5a8c:      	b.ne	0x57d4 <_stogir.placement.early-with-uses!+0x19c>
    5a90:      	mov	x0, #0x2                ; =2
    5a94:      	b	0x57d8 <_stogir.placement.early-with-uses!+0x1a0>
    5a98:      	sxtw	x23, w23
    5a9c:      	movz	x19, #0x0, lsl #48
    5aa0:      	movz	x22, #0x0, lsl #48
    5aa4:      	b	0x5bec <_stogir.placement.early-with-uses!+0x5b4>
    5aa8:      	movz	x1, #0x0, lsl #48
    5aac:      	movz	x2, #0x0, lsl #48
    5ab0:      	b	0x5ac4 <_stogir.placement.early-with-uses!+0x48c>
    5ab4:      	mov	x23, x3
    5ab8:      	b	0x5ac4 <_stogir.placement.early-with-uses!+0x48c>
    5abc:      	nop
    5ac0:      	mov	x1, #0x1                ; =1
    5ac4:      	cmp	x1, #0x0
    5ac8:      	b.ne	0x5c74 <_stogir.placement.early-with-uses!+0x63c>
    5acc:      	cmp	x23, #0x0
    5ad0:      	b.le	0x5ac0 <_stogir.placement.early-with-uses!+0x488>
    5ad4:      	ldr	x3, [x4, #0x8]
    5ad8:      	cmp	x23, x3
    5adc:      	b.ge	0x5ac0 <_stogir.placement.early-with-uses!+0x488>
    5ae0:      	ldr	x3, [x4]
    5ae4:      	add	x3, x3, x23, lsl #2
    5ae8:      	ldr	w3, [x3]
    5aec:      	sxtw	x3, w3
    5af0:      	cmp	x3, #0x0
    5af4:      	b.ne	0x5b00 <_stogir.placement.early-with-uses!+0x4c8>
    5af8:      	mov	x1, #0x1                ; =1
    5afc:      	b	0x5ab8 <_stogir.placement.early-with-uses!+0x480>
    5b00:      	cmp	x23, x0
    5b04:      	b.ne	0x5f40 <_stogir.placement.early-with-uses!+0x908>
    5b08:      	mov	x1, #0x1                ; =1
    5b0c:      	mov	x2, #0x1                ; =1
    5b10:      	b	0x5ab8 <_stogir.placement.early-with-uses!+0x480>
    5b14:      	nop
    5b18:      	lsl	x1, x1, #1
    5b1c:      	str	x4, [sp, #0x128]
    5b20:      	str	x20, [sp, #0x120]
    5b24:      	mov	x20, x0
    5b28:      	add	x0, sp, #0x80
    5b2c:      	bl	0x5b2c <_stogir.placement.early-with-uses!+0x4f4>
		0000000000005b2c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5b30:      	add	x0, x20, #0x1
    5b34:      	add	x16, sp, #0x80
    5b38:      	ldr	x1, [x16]
    5b3c:      	add	x1, x1, x20, lsl #2
    5b40:      	str	w27, [x1]
    5b44:      	add	x16, sp, #0x80
    5b48:      	str	x0, [x16, #0x8]
    5b4c:      	add	x25, x25, #0x1
    5b50:      	ldr	x4, [sp, #0x128]
    5b54:      	ldr	x20, [sp, #0x120]
    5b58:      	cmp	x25, x24
    5b5c:      	b.ge	0x6004 <_stogir.placement.early-with-uses!+0x9cc>
    5b60:      	add	x0, x23, x25
    5b64:      	ldr	x1, [x20, #0x28]
    5b68:      	add	x0, x1, x0, lsl #3
    5b6c:      	ldr	x0, [x0]
    5b70:      	add	x16, sp, #0x20
    5b74:      	ldr	x1, [x16]
    5b78:      	orr	w27, w0, wzr
    5b7c:      	sxtw	x0, w27
    5b80:      	add	x2, x1, x0, lsl #2
    5b84:      	ldr	w2, [x2]
    5b88:      	sxtw	x3, w2
    5b8c:      	cmp	x3, #0x0
    5b90:      	b.le	0x6010 <_stogir.placement.early-with-uses!+0x9d8>
    5b94:      	sub	w2, w2, #0x1
    5b98:      	add	x0, x1, x0, lsl #2
    5b9c:      	str	w2, [x0]
    5ba0:      	cmp	x3, #0x1
    5ba4:      	b.ne	0x601c <_stogir.placement.early-with-uses!+0x9e4>
    5ba8:      	add	x16, sp, #0x80
    5bac:      	ldr	x0, [x16, #0x8]
    5bb0:      	add	x16, sp, #0x80
    5bb4:      	ldr	x1, [x16, #0x10]
    5bb8:      	cmp	x0, x1
    5bbc:      	b.lt	0x6028 <_stogir.placement.early-with-uses!+0x9f0>
    5bc0:      	cmp	x1, #0x0
    5bc4:      	b.ne	0x5b18 <_stogir.placement.early-with-uses!+0x4e0>
    5bc8:      	mov	x1, #0x2                ; =2
    5bcc:      	b	0x5b1c <_stogir.placement.early-with-uses!+0x4e4>
    5bd0:      	add	x0, x22, #0x1
    5bd4:      	sub	x1, x26, #0x1
    5bd8:      	sxtw	x22, w0
    5bdc:      	sxtw	x26, w1
    5be0:      	add	x19, x19, #0x1
    5be4:      	ldr	x20, [sp, #0x140]
    5be8:      	ldr	x23, [sp, #0x150]
    5bec:      	cmp	x28, #0x0
    5bf0:      	b.ne	0x5e98 <_stogir.placement.early-with-uses!+0x860>
    5bf4:      	add	x16, sp, #0x80
    5bf8:      	ldr	x0, [x16, #0x8]
    5bfc:      	cmp	x19, x0
    5c00:      	b.ge	0x5e98 <_stogir.placement.early-with-uses!+0x860>
    5c04:      	add	x16, sp, #0x80
    5c08:      	ldr	x0, [x16]
    5c0c:      	add	x0, x0, x19, lsl #2
    5c10:      	ldr	w0, [x0]
    5c14:      	sxtw	x24, w0
    5c18:      	ldr	x1, [x20]
    5c1c:      	orr	w25, w0, wzr
    5c20:      	add	x0, x1, x24, lsl #4
    5c24:      	ldr	x0, [x0]
    5c28:      	ldr	x1, [x20, #0x78]
    5c2c:      	uxtb	w0, w0
    5c30:      	add	x1, x1, x24, lsl #2
    5c34:      	cmp	x0, #0x83
    5c38:      	cset	w27, lt
    5c3c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		0000000000005c3c:  ARM64_RELOC_PAGE21	l_stogir.428
    5c40:      	ldr	x16, [x16]
		0000000000005c40:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    5c44:      	add	x0, x16, x0, lsl #2
    5c48:      	ldr	w1, [x1]
    5c4c:      	sxtw	x1, w1
    5c50:      	mov	x3, x23
    5c54:      	mov	x2, #0x1                ; =1
    5c58:      	b	0x5cb0 <_stogir.placement.early-with-uses!+0x678>
    5c5c:      	sub	w6, w4, #0x1
    5c60:      	lsl	w6, w6, #2
    5c64:      	ubfx	x6, x6, #0, #32
    5c68:      	lsr	x6, x7, x6
    5c6c:      	and	w6, w6, #0xf
    5c70:      	b	0x5d0c <_stogir.placement.early-with-uses!+0x6d4>
    5c74:      	cmp	x2, #0x0
    5c78:      	b.ne	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    5c7c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		0000000000005c7c:  ARM64_RELOC_PAGE21	l_stogir.430
    5c80:      	ldr	x16, [x16]
		0000000000005c80:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    5c84:      	str	x16, [sp, #0x110]
    5c88:      	mov	x28, #0x2b              ; =43
    5c8c:      	add	x0, x20, #0x1
    5c90:      	sxtw	x20, w0
    5c94:      	str	x4, [sp, #0x128]
    5c98:      	ldr	x23, [sp, #0x150]
    5c9c:      	ldr	x1, [sp, #0x138]
    5ca0:      	ldr	x0, [sp, #0x130]
    5ca4:      	mov	x2, x20
    5ca8:      	ldr	x20, [sp, #0x140]
    5cac:      	ldr	x3, [sp, #0x148]
    5cb0:      	cmp	x28, #0x0
    5cb4:      	b.ne	0x5cc8 <_stogir.placement.early-with-uses!+0x690>
    5cb8:      	cmp	x2, x1
    5cbc:      	cset	w4, le
    5cc0:      	ubfx	x4, x4, #0, #8
    5cc4:      	b	0x5ccc <_stogir.placement.early-with-uses!+0x694>
    5cc8:      	movz	x4, #0x0, lsl #48
    5ccc:      	orr	w5, w3, wzr
    5cd0:      	cmp	x4, #0x0
    5cd4:      	b.eq	0x6038 <_stogir.placement.early-with-uses!+0xa00>
    5cd8:      	orr	w4, w2, wzr
    5cdc:      	uxtb	w16, w27
    5ce0:      	cmp	w16, wzr
    5ce4:      	b.eq	0x5d10 <_stogir.placement.early-with-uses!+0x6d8>
    5ce8:      	sxtw	x6, w4
    5cec:      	ldr	w7, [x0]
    5cf0:      	cmp	x6, #0x0
    5cf4:      	b.le	0x5d08 <_stogir.placement.early-with-uses!+0x6d0>
    5cf8:      	cmp	x6, #0x4
    5cfc:      	b.le	0x5c5c <_stogir.placement.early-with-uses!+0x624>
    5d00:      	mov	w6, #0x4                ; =4
    5d04:      	b	0x5c60 <_stogir.placement.early-with-uses!+0x628>
    5d08:      	movz	w6, #0x0, lsl #16
    5d0c:      	b	0x5d14 <_stogir.placement.early-with-uses!+0x6dc>
    5d10:      	movz	w6, #0x0, lsl #16
    5d14:      	ubfx	x6, x6, #0, #32
    5d18:      	cmp	x6, #0xf
    5d1c:      	b.hs	0x604c <_stogir.placement.early-with-uses!+0xa14>
    5d20:      	mov	x16, #0x1               ; =1
    5d24:      	lsl	x6, x16, x6
    5d28:      	mov	w17, #0x5e1c            ; =24092
    5d2c:      	and	w6, w6, w17
    5d30:      	ubfx	x6, x6, #0, #32
    5d34:      	cmp	x6, #0x0
    5d38:      	b.eq	0x606c <_stogir.placement.early-with-uses!+0xa34>
    5d3c:      	str	x0, [sp, #0x130]
    5d40:      	mov	x0, x20
    5d44:      	str	x1, [sp, #0x138]
    5d48:      	mov	w1, w25
    5d4c:      	str	x3, [sp, #0x148]
    5d50:      	str	x20, [sp, #0x140]
    5d54:      	mov	x20, x2
    5d58:      	mov	w2, w4
    5d5c:      	str	x23, [sp, #0x150]
    5d60:      	mov	w23, w5
    5d64:      	bl	0x5d64 <_stogir.placement.early-with-uses!+0x72c>
		0000000000005d64:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5d68:      	ubfx	x0, x0, #0, #32
    5d6c:      	lsr	x16, x0, #0
    5d70:      	cmp	x16, #0x1
    5d74:      	b.eq	0x5d90 <_stogir.placement.early-with-uses!+0x758>
    5d78:      	b.lo	0x5d80 <_stogir.placement.early-with-uses!+0x748>
    5d7c:      	b	0x5d94 <_stogir.placement.early-with-uses!+0x75c>
    5d80:      	cmp	x16, #0x0
    5d84:      	b.eq	0x5d8c <_stogir.placement.early-with-uses!+0x754>
    5d88:      	b	0x5d94 <_stogir.placement.early-with-uses!+0x75c>
    5d8c:      	b	0x5d98 <_stogir.placement.early-with-uses!+0x760>
    5d90:      	b	0x5de0 <_stogir.placement.early-with-uses!+0x7a8>
    5d94:      	b	0x5f50 <_stogir.placement.early-with-uses!+0x918>
    5d98:      	ldr	x4, [sp, #0x128]
    5d9c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		0000000000005d9c:  ARM64_RELOC_PAGE21	l_stogir.429
    5da0:      	ldr	x16, [x16]
		0000000000005da0:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    5da4:      	str	x16, [sp, #0x110]
    5da8:      	mov	x28, #0x18              ; =24
    5dac:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    5db0:      	cmp	x28, #0x0
    5db4:      	b.ne	0x608c <_stogir.placement.early-with-uses!+0xa54>
    5db8:      	ldr	x0, [x21]
    5dbc:      	add	x0, x0, x24, lsl #2
    5dc0:      	str	w23, [x0]
    5dc4:      	ldr	x20, [sp, #0x120]
    5dc8:      	ldr	x0, [x20]
    5dcc:      	add	x0, x0, x24, lsl #4
    5dd0:      	ldr	x23, [x0]
    5dd4:      	ldr	x24, [x0, #0x8]
    5dd8:      	movz	x25, #0x0, lsl #48
    5ddc:      	b	0x5b58 <_stogir.placement.early-with-uses!+0x520>
    5de0:      	sxtw	x1, w1
    5de4:      	cmp	x1, #0x0
    5de8:      	b.le	0x6094 <_stogir.placement.early-with-uses!+0xa5c>
    5dec:      	sxtw	x23, w23
    5df0:      	ldr	x0, [x21]
    5df4:      	add	x0, x0, x1, lsl #2
    5df8:      	ldr	w0, [x0]
    5dfc:      	sxtw	x0, w0
    5e00:      	mov	x2, x0
    5e04:      	movz	x1, #0x0, lsl #48
    5e08:      	movz	x3, #0x0, lsl #48
    5e0c:      	b	0x5e24 <_stogir.placement.early-with-uses!+0x7ec>
    5e10:      	mov	x2, x5
    5e14:      	b	0x5e20 <_stogir.placement.early-with-uses!+0x7e8>
    5e18:      	ldr	x4, [sp, #0x128]
    5e1c:      	mov	x1, #0x1                ; =1
    5e20:      	str	x4, [sp, #0x128]
    5e24:      	cmp	x1, #0x0
    5e28:      	b.ne	0x609c <_stogir.placement.early-with-uses!+0xa64>
    5e2c:      	cmp	x2, #0x0
    5e30:      	b.le	0x5e18 <_stogir.placement.early-with-uses!+0x7e0>
    5e34:      	ldr	x4, [sp, #0x128]
    5e38:      	ldr	x5, [x4, #0x8]
    5e3c:      	cmp	x2, x5
    5e40:      	b.ge	0x5e1c <_stogir.placement.early-with-uses!+0x7e4>
    5e44:      	ldr	x5, [x4]
    5e48:      	add	x5, x5, x2, lsl #2
    5e4c:      	ldr	w5, [x5]
    5e50:      	sxtw	x5, w5
    5e54:      	cmp	x5, #0x0
    5e58:      	b.ne	0x5e64 <_stogir.placement.early-with-uses!+0x82c>
    5e5c:      	mov	x1, #0x1                ; =1
    5e60:      	b	0x5e14 <_stogir.placement.early-with-uses!+0x7dc>
    5e64:      	cmp	x2, x23
    5e68:      	b.ne	0x5e88 <_stogir.placement.early-with-uses!+0x850>
    5e6c:      	mov	x1, #0x1                ; =1
    5e70:      	mov	x3, #0x1                ; =1
    5e74:      	b	0x5e14 <_stogir.placement.early-with-uses!+0x7dc>
    5e78:      	cmp	x3, #0x0
    5e7c:      	b.eq	0x5aa8 <_stogir.placement.early-with-uses!+0x470>
    5e80:      	str	x0, [sp, #0x148]
    5e84:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    5e88:      	cmp	x2, x5
    5e8c:      	b.ne	0x5e10 <_stogir.placement.early-with-uses!+0x7d8>
    5e90:      	mov	x1, #0x1                ; =1
    5e94:      	b	0x5e14 <_stogir.placement.early-with-uses!+0x7dc>
    5e98:      	add	x0, sp, #0x20
    5e9c:      	bl	0x5e9c <_stogir.placement.early-with-uses!+0x864>
		0000000000005e9c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    5ea0:      	add	x0, sp, #0x80
    5ea4:      	bl	0x5ea4 <_stogir.placement.early-with-uses!+0x86c>
		0000000000005ea4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    5ea8:      	ldr	x0, [sp, #0x110]
    5eac:      	mov	x1, x28
    5eb0:      	adrp	x2, 0x5000 <_stogir.uses.build+0x460>
		0000000000005eb0:  ARM64_RELOC_PAGE21	l_stogir.426
    5eb4:      	ldr	x2, [x2]
		0000000000005eb4:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    5eb8:      	movz	x3, #0x0, lsl #48
    5ebc:      	bl	0x5ebc <_stogir.placement.early-with-uses!+0x884>
		0000000000005ebc:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    5ec0:      	cmp	x0, #0x0
    5ec4:      	b.eq	0x60a4 <_stogir.placement.early-with-uses!+0xa6c>
    5ec8:      	cmp	x26, #0x0
    5ecc:      	b.le	0x5ee4 <_stogir.placement.early-with-uses!+0x8ac>
    5ed0:      	mov	x1, #0x1                ; =1
    5ed4:      	adrp	x0, 0x5000 <_stogir.uses.build+0x460>
		0000000000005ed4:  ARM64_RELOC_PAGE21	l_stogir.431
    5ed8:      	ldr	x0, [x0]
		0000000000005ed8:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    5edc:      	mov	x28, #0x39              ; =57
    5ee0:      	b	0x5ef0 <_stogir.placement.early-with-uses!+0x8b8>
    5ee4:      	and	x0, x22, #0xffffffff
    5ee8:      	movz	x1, #0x0, lsl #48
    5eec:      	movz	x28, #0x0, lsl #48
    5ef0:      	b	0x5ef8 <_stogir.placement.early-with-uses!+0x8c0>
    5ef4:      	mov	x1, #0x1                ; =1
    5ef8:      	ldr	x2, [sp, #0x108]
    5efc:      	str	x1, [x2]
    5f00:      	str	x0, [x2, #0x8]
    5f04:      	str	x28, [x2, #0x10]
    5f08:      	ldr	x19, [sp, #0x158]
    5f0c:      	ldr	x20, [sp, #0x160]
    5f10:      	ldr	x21, [sp, #0x168]
    5f14:      	ldr	x22, [sp, #0x170]
    5f18:      	ldr	x23, [sp, #0x178]
    5f1c:      	ldr	x24, [sp, #0x180]
    5f20:      	ldr	x25, [sp, #0x188]
    5f24:      	ldr	x26, [sp, #0x190]
    5f28:      	ldr	x27, [sp, #0x198]
    5f2c:      	ldr	x28, [sp, #0x1a0]
    5f30:      	ldr	x29, [sp, #0x10]
    5f34:      	ldr	x30, [sp, #0x18]
    5f38:      	add	sp, sp, #0x1b0
    5f3c:      	ret
    5f40:      	cmp	x23, x3
    5f44:      	b.ne	0x5ab4 <_stogir.placement.early-with-uses!+0x47c>
    5f48:      	mov	x1, #0x1                ; =1
    5f4c:      	b	0x5ab8 <_stogir.placement.early-with-uses!+0x480>
    5f50:      	brk	#0
    5f54:      	b	0x5f50 <_stogir.placement.early-with-uses!+0x918>
    5f58:      	brk	#0
    5f5c:      	b	0x5f58 <_stogir.placement.early-with-uses!+0x920>
    5f60:      	str	x19, [sp, #0x108]
    5f64:      	str	x22, [sp, #0x128]
    5f68:      	str	x24, [sp, #0x120]
    5f6c:      	str	x27, [sp, #0x110]
    5f70:      	b	0x5a98 <_stogir.placement.early-with-uses!+0x460>
    5f74:      	str	x19, [sp, #0x108]
    5f78:      	str	x22, [sp, #0x128]
    5f7c:      	str	x24, [sp, #0x120]
    5f80:      	mov	x19, x2
    5f84:      	str	x27, [sp, #0x110]
    5f88:      	b	0x5808 <_stogir.placement.early-with-uses!+0x1d0>
    5f8c:      	str	x19, [sp, #0x108]
    5f90:      	str	x22, [sp, #0x128]
    5f94:      	mov	x22, x5
    5f98:      	str	x24, [sp, #0x120]
    5f9c:      	mov	x19, x2
    5fa0:      	str	x27, [sp, #0x110]
    5fa4:      	mov	w27, w0
    5fa8:      	b	0x5a50 <_stogir.placement.early-with-uses!+0x418>
    5fac:      	str	x19, [sp, #0x108]
    5fb0:      	str	x22, [sp, #0x128]
    5fb4:      	mov	x22, x5
    5fb8:      	str	x24, [sp, #0x120]
    5fbc:      	mov	x24, x4
    5fc0:      	mov	x19, x2
    5fc4:      	str	x27, [sp, #0x110]
    5fc8:      	mov	w27, w0
    5fcc:      	str	w3, [sp, #0x100]
    5fd0:      	str	x1, [sp, #0x118]
    5fd4:      	b	0x5938 <_stogir.placement.early-with-uses!+0x300>
    5fd8:      	str	x19, [sp, #0x108]
    5fdc:      	str	x22, [sp, #0x128]
    5fe0:      	mov	x22, x5
    5fe4:      	str	x24, [sp, #0x120]
    5fe8:      	mov	x24, x4
    5fec:      	mov	x19, x2
    5ff0:      	str	x27, [sp, #0x110]
    5ff4:      	mov	w27, w0
    5ff8:      	str	w3, [sp, #0x100]
    5ffc:      	str	x1, [sp, #0x118]
    6000:      	b	0x5938 <_stogir.placement.early-with-uses!+0x300>
    6004:      	str	x4, [sp, #0x128]
    6008:      	str	x20, [sp, #0x120]
    600c:      	b	0x5bd0 <_stogir.placement.early-with-uses!+0x598>
    6010:      	str	x4, [sp, #0x128]
    6014:      	str	x20, [sp, #0x120]
    6018:      	b	0x5b4c <_stogir.placement.early-with-uses!+0x514>
    601c:      	str	x4, [sp, #0x128]
    6020:      	str	x20, [sp, #0x120]
    6024:      	b	0x5b4c <_stogir.placement.early-with-uses!+0x514>
    6028:      	str	x4, [sp, #0x128]
    602c:      	str	x20, [sp, #0x120]
    6030:      	mov	x20, x0
    6034:      	b	0x5b30 <_stogir.placement.early-with-uses!+0x4f8>
    6038:      	str	x20, [sp, #0x140]
    603c:      	ldr	x4, [sp, #0x128]
    6040:      	str	x23, [sp, #0x150]
    6044:      	mov	w23, w5
    6048:      	b	0x5db0 <_stogir.placement.early-with-uses!+0x778>
    604c:      	str	x3, [sp, #0x148]
    6050:      	str	x20, [sp, #0x140]
    6054:      	mov	x20, x2
    6058:      	ldr	x4, [sp, #0x128]
    605c:      	str	x23, [sp, #0x150]
    6060:      	str	x1, [sp, #0x138]
    6064:      	str	x0, [sp, #0x130]
    6068:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    606c:      	str	x3, [sp, #0x148]
    6070:      	str	x20, [sp, #0x140]
    6074:      	mov	x20, x2
    6078:      	ldr	x4, [sp, #0x128]
    607c:      	str	x23, [sp, #0x150]
    6080:      	str	x1, [sp, #0x138]
    6084:      	str	x0, [sp, #0x130]
    6088:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    608c:      	str	x4, [sp, #0x128]
    6090:      	b	0x5be0 <_stogir.placement.early-with-uses!+0x5a8>
    6094:      	ldr	x4, [sp, #0x128]
    6098:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    609c:      	ldr	x4, [sp, #0x128]
    60a0:      	b	0x5e78 <_stogir.placement.early-with-uses!+0x840>
    60a4:      	ldr	x0, [sp, #0x110]
    60a8:      	b	0x5ef4 <_stogir.placement.early-with-uses!+0x8bc>

00000000000060ac <_coil.core.Eq$slice<u8>$=>:
    60ac:      	sub	sp, sp, #0x10
    60b0:      	str	x29, [sp]
    60b4:      	str	x30, [sp, #0x8]
    60b8:      	mov	x29, sp
    60bc:      	cmp	x1, x3
    60c0:      	b.ne	0x60fc <_coil.core.Eq$slice<u8>$=+0x50>
    60c4:      	cmp	x1, #0x0
    60c8:      	b.ne	0x60d4 <_coil.core.Eq$slice<u8>$=+0x28>
    60cc:      	mov	x0, #0x1                ; =1
    60d0:      	b	0x60f8 <_coil.core.Eq$slice<u8>$=+0x4c>
    60d4:      	lsr	x1, x1, #0
    60d8:      	fmov	d31, x1
    60dc:      	mov	x1, x2
    60e0:      	fmov	x2, d31
    60e4:      	bl	0x60e4 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000060e4:  ARM64_RELOC_BRANCH26	_memcmp
    60e8:      	sxtw	x0, w0
    60ec:      	cmp	x0, #0x0
    60f0:      	cset	w0, eq
    60f4:      	ubfx	x0, x0, #0, #8
    60f8:      	b	0x6100 <_coil.core.Eq$slice<u8>$=+0x54>
    60fc:      	movz	x0, #0x0, lsl #48
    6100:      	ldr	x29, [sp]
    6104:      	ldr	x30, [sp, #0x8]
    6108:      	add	sp, sp, #0x10
    610c:      	ret

0000000000006110 <_stogir.placement.late-with-uses!>:
    6110:      	sub	sp, sp, #0x1e0
    6114:      	str	x29, [sp]
    6118:      	str	x30, [sp, #0x8]
    611c:      	mov	x29, sp
    6120:      	str	x19, [sp, #0x190]
    6124:      	str	x20, [sp, #0x198]
    6128:      	str	x21, [sp, #0x1a0]
    612c:      	str	x22, [sp, #0x1a8]
    6130:      	str	x23, [sp, #0x1b0]
    6134:      	str	x24, [sp, #0x1b8]
    6138:      	str	x25, [sp, #0x1c0]
    613c:      	str	x26, [sp, #0x1c8]
    6140:      	str	x27, [sp, #0x1d0]
    6144:      	str	x28, [sp, #0x1d8]
    6148:      	mov	x19, x8
    614c:      	add	x8, sp, #0x40
    6150:      	mov	x20, x0
    6154:      	mov	x0, x6
    6158:      	mov	x21, x1
    615c:      	mov	x22, x2
    6160:      	mov	x23, x3
    6164:      	mov	x24, x4
    6168:      	mov	x25, x5
    616c:      	mov	x26, x6
    6170:      	bl	0x6170 <_stogir.placement.late-with-uses!+0x60>
		0000000000006170:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    6174:      	add	x16, sp, #0x40
    6178:      	ldr	x0, [x16]
    617c:      	add	x16, sp, #0x10
    6180:      	str	x0, [x16]
    6184:      	add	x16, sp, #0x40
    6188:      	ldr	x0, [x16, #0x8]
    618c:      	add	x16, sp, #0x10
    6190:      	str	x0, [x16, #0x8]
    6194:      	add	x16, sp, #0x40
    6198:      	ldr	x0, [x16, #0x10]
    619c:      	add	x16, sp, #0x10
    61a0:      	str	x0, [x16, #0x10]
    61a4:      	add	x16, sp, #0x40
    61a8:      	ldr	x0, [x16, #0x18]
    61ac:      	add	x16, sp, #0x10
    61b0:      	str	x0, [x16, #0x18]
    61b4:      	add	x16, sp, #0x40
    61b8:      	ldr	x0, [x16, #0x20]
    61bc:      	add	x16, sp, #0x10
    61c0:      	str	x0, [x16, #0x20]
    61c4:      	add	x8, sp, #0xa0
    61c8:      	mov	x0, x26
    61cc:      	bl	0x61cc <_stogir.placement.late-with-uses!+0xbc>
		00000000000061cc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    61d0:      	add	x16, sp, #0xa0
    61d4:      	ldr	x0, [x16]
    61d8:      	add	x16, sp, #0x70
    61dc:      	str	x0, [x16]
    61e0:      	add	x16, sp, #0xa0
    61e4:      	ldr	x0, [x16, #0x8]
    61e8:      	add	x16, sp, #0x70
    61ec:      	str	x0, [x16, #0x8]
    61f0:      	add	x16, sp, #0xa0
    61f4:      	ldr	x0, [x16, #0x10]
    61f8:      	add	x16, sp, #0x70
    61fc:      	str	x0, [x16, #0x10]
    6200:      	add	x16, sp, #0xa0
    6204:      	ldr	x0, [x16, #0x18]
    6208:      	add	x16, sp, #0x70
    620c:      	str	x0, [x16, #0x18]
    6210:      	add	x16, sp, #0xa0
    6214:      	ldr	x0, [x16, #0x20]
    6218:      	add	x16, sp, #0x70
    621c:      	str	x0, [x16, #0x20]
    6220:      	movz	x26, #0x0, lsl #48
    6224:      	b	0x623c <_stogir.placement.late-with-uses!+0x12c>
    6228:      	add	x26, x26, #0x1
    622c:      	add	x0, sp, #0x10
    6230:      	mov	x1, #0xffff             ; =65535
    6234:      	movk	x1, #0xffff, lsl #16
    6238:      	bl	0x6238 <_stogir.placement.late-with-uses!+0x128>
		0000000000006238:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    623c:      	ldr	x0, [x20, #0x8]
    6240:      	cmp	x26, x0
    6244:      	b.lt	0x6228 <_stogir.placement.late-with-uses!+0x118>
    6248:      	add	x26, x20, #0x78
    624c:      	mov	x27, #0x1               ; =1
    6250:      	movz	x28, #0x0, lsl #48
    6254:      	b	0x6290 <_stogir.placement.late-with-uses!+0x180>
    6258:      	add	x28, x28, #0x1
    625c:      	add	x0, sp, #0x10
    6260:      	mov	x1, x27
    6264:      	movz	x2, #0x0, lsl #48
    6268:      	bl	0x6268 <_stogir.placement.late-with-uses!+0x158>
		0000000000006268:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    626c:      	sxtw	x28, w28
    6270:      	sxtw	x23, w23
    6274:      	add	x0, x23, #0x4
    6278:      	asr	x16, x0, #63
    627c:      	lsr	x16, x16, #62
    6280:      	add	x0, x0, x16
    6284:      	asr	x0, x0, #2
    6288:      	add	x27, x0, x27
    628c:      	ldr	x23, [sp, #0x110]
    6290:      	ldr	x0, [x20, #0x8]
    6294:      	cmp	x27, x0
    6298:      	b.ge	0x6bc0 <_stogir.placement.late-with-uses!+0xab0>
    629c:      	ldr	x0, [x20]
    62a0:      	add	x0, x0, x27, lsl #4
    62a4:      	ldr	x0, [x0]
    62a8:      	ldr	x1, [x20, #0x78]
    62ac:      	uxtb	w0, w0
    62b0:      	add	x1, x1, x27, lsl #2
    62b4:      	ldr	w1, [x1]
    62b8:      	str	x23, [sp, #0x110]
    62bc:      	mov	w23, w1
    62c0:      	bl	0x62c0 <_stogir.placement.late-with-uses!+0x1b0>
		00000000000062c0:  ARM64_RELOC_BRANCH26	_stogir.opcode.properties
    62c4:      	ldr	x1, [x24]
    62c8:      	add	x1, x27, x1
    62cc:      	ldrb	w1, [x1]
    62d0:      	cmp	x1, #0x0
    62d4:      	b.eq	0x6270 <_stogir.placement.late-with-uses!+0x160>
    62d8:      	uxtb	w0, w0
    62dc:      	uxtb	w16, w0
    62e0:      	and	w0, w16, #0x40
    62e4:      	uxtb	w0, w0
    62e8:      	ubfx	x0, x0, #0, #8
    62ec:      	cmp	x0, #0x0
    62f0:      	b.ne	0x6258 <_stogir.placement.late-with-uses!+0x148>
    62f4:      	b	0x6270 <_stogir.placement.late-with-uses!+0x160>
    62f8:      	mov	x23, #0x1               ; =1
    62fc:      	b	0x6378 <_stogir.placement.late-with-uses!+0x268>
    6300:      	add	x3, x27, #0x1
    6304:      	sxtw	x27, w3
    6308:      	add	x2, x2, #0x1
    630c:      	cmp	x2, x0
    6310:      	b.ge	0x6348 <_stogir.placement.late-with-uses!+0x238>
    6314:      	add	x3, x1, x2
    6318:      	ldr	x4, [x25, #0x28]
    631c:      	add	x3, x4, x3, lsl #3
    6320:      	ldr	x3, [x3]
    6324:      	add	x16, sp, #0x10
    6328:      	ldr	x4, [x16]
    632c:      	sxtw	x3, w3
    6330:      	add	x3, x4, x3, lsl #2
    6334:      	ldr	w3, [x3]
    6338:      	sxtw	x3, w3
    633c:      	cmp	x3, #0x0
    6340:      	b.ge	0x6300 <_stogir.placement.late-with-uses!+0x1f0>
    6344:      	b	0x6308 <_stogir.placement.late-with-uses!+0x1f8>
    6348:      	orr	w0, w27, wzr
    634c:      	mov	x1, x23
    6350:      	mov	w2, w0
    6354:      	add	x0, sp, #0x10
    6358:      	bl	0x6358 <_stogir.placement.late-with-uses!+0x248>
		0000000000006358:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    635c:      	cmp	x27, #0x0
    6360:      	b.ne	0x6374 <_stogir.placement.late-with-uses!+0x264>
    6364:      	orr	w0, w23, wzr
    6368:      	mov	w1, w0
    636c:      	add	x0, sp, #0x70
    6370:      	bl	0x6370 <_stogir.placement.late-with-uses!+0x260>
		0000000000006370:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    6374:      	add	x23, x23, #0x1
    6378:      	add	x16, sp, #0x10
    637c:      	ldr	x0, [x16, #0x8]
    6380:      	cmp	x23, x0
    6384:      	b.ge	0x63c0 <_stogir.placement.late-with-uses!+0x2b0>
    6388:      	add	x16, sp, #0x10
    638c:      	ldr	x0, [x16]
    6390:      	add	x0, x0, x23, lsl #2
    6394:      	ldr	w0, [x0]
    6398:      	sxtw	x0, w0
    639c:      	cmp	x0, #0x0
    63a0:      	b.ne	0x6374 <_stogir.placement.late-with-uses!+0x264>
    63a4:      	ldr	x0, [x25]
    63a8:      	add	x0, x0, x23, lsl #4
    63ac:      	ldr	x1, [x0]
    63b0:      	ldr	x0, [x0, #0x8]
    63b4:      	movz	x2, #0x0, lsl #48
    63b8:      	movz	x27, #0x0, lsl #48
    63bc:      	b	0x630c <_stogir.placement.late-with-uses!+0x1fc>
    63c0:      	add	x16, sp, #0xd0
    63c4:      	orr	x0, x16, xzr
    63c8:      	add	x16, sp, #0xf0
    63cc:      	orr	x1, x16, xzr
    63d0:      	add	x23, x0, #0x8
    63d4:      	add	x27, x1, #0x8
    63d8:      	movz	x0, #0x0, lsl #48
    63dc:      	adrp	x1, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		00000000000063dc:  ARM64_RELOC_PAGE21	l_stogir.432
    63e0:      	ldr	x1, [x1]
		00000000000063e0:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    63e4:      	movz	x2, #0x0, lsl #48
    63e8:      	b	0x6434 <_stogir.placement.late-with-uses!+0x324>
    63ec:      	movz	w6, #0x0, lsl #16
    63f0:      	movz	w5, #0x0, lsl #16
    63f4:      	b	0x67f4 <_stogir.placement.late-with-uses!+0x6e4>
    63f8:      	ldr	x19, [sp, #0x120]
    63fc:      	sub	x0, x19, #0x1
    6400:      	sxtw	x19, w0
    6404:      	ldr	x0, [sp, #0x150]
    6408:      	add	x0, x0, #0x1
    640c:      	mov	x20, x27
    6410:      	ldr	x21, [sp, #0x188]
    6414:      	ldr	x24, [sp, #0x130]
    6418:      	ldr	x25, [sp, #0x148]
    641c:      	ldr	x27, [sp, #0x160]
    6420:      	mov	x1, x28
    6424:      	mov	x28, x19
    6428:      	ldr	x19, [sp, #0x118]
    642c:      	mov	x2, x26
    6430:      	ldr	x26, [sp, #0x128]
    6434:      	str	x19, [sp, #0x118]
    6438:      	mov	x19, x0
    643c:      	mov	x0, x1
    6440:      	str	x28, [sp, #0x120]
    6444:      	mov	x28, x1
    6448:      	mov	x1, x2
    644c:      	str	x26, [sp, #0x128]
    6450:      	mov	x26, x2
    6454:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006454:  ARM64_RELOC_PAGE21	l_stogir.432
    6458:      	ldr	x2, [x2]
		0000000000006458:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    645c:      	movz	x3, #0x0, lsl #48
    6460:      	bl	0x6460 <_stogir.placement.late-with-uses!+0x350>
		0000000000006460:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6464:      	cmp	x0, #0x0
    6468:      	b.eq	0x6484 <_stogir.placement.late-with-uses!+0x374>
    646c:      	add	x0, sp, #0x70
    6470:      	bl	0x6470 <_stogir.placement.late-with-uses!+0x360>
		0000000000006470:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    6474:      	cmp	x19, x0
    6478:      	cset	w0, lt
    647c:      	ubfx	x0, x0, #0, #8
    6480:      	b	0x6488 <_stogir.placement.late-with-uses!+0x378>
    6484:      	movz	x0, #0x0, lsl #48
    6488:      	cmp	x0, #0x0
    648c:      	b.eq	0x6bc8 <_stogir.placement.late-with-uses!+0xab8>
    6490:      	add	x16, sp, #0x70
    6494:      	ldr	x0, [x16]
    6498:      	add	x0, x0, x19, lsl #2
    649c:      	ldr	w0, [x0]
    64a0:      	sxtw	x0, w0
    64a4:      	ldr	x1, [x25]
    64a8:      	add	x1, x1, x0, lsl #4
    64ac:      	ldr	x2, [x1]
    64b0:      	ldr	x1, [x1, #0x8]
    64b4:      	movz	x3, #0x0, lsl #48
    64b8:      	movz	w4, #0x0, lsl #16
    64bc:      	b	0x64f0 <_stogir.placement.late-with-uses!+0x3e0>
    64c0:      	movz	x19, #0x0, lsl #48
    64c4:      	add	x25, x25, #0x1
    64c8:      	ldr	x20, [sp, #0x158]
    64cc:      	mov	x0, x24
    64d0:      	ldr	x24, [sp, #0x130]
    64d4:      	ldr	x2, [sp, #0x138]
    64d8:      	ldr	x1, [sp, #0x140]
    64dc:      	ldr	x27, [sp, #0x160]
    64e0:      	mov	x3, x25
    64e4:      	ldr	x25, [sp, #0x148]
    64e8:      	mov	w4, w19
    64ec:      	ldr	x19, [sp, #0x150]
    64f0:      	cmp	x26, #0x0
    64f4:      	b.ne	0x6508 <_stogir.placement.late-with-uses!+0x3f8>
    64f8:      	cmp	x3, x1
    64fc:      	cset	w5, lt
    6500:      	ubfx	x5, x5, #0, #8
    6504:      	b	0x650c <_stogir.placement.late-with-uses!+0x3fc>
    6508:      	movz	x5, #0x0, lsl #48
    650c:      	sxtw	x6, w4
    6510:      	cmp	x6, #0x0
    6514:      	cset	w7, eq
    6518:      	cmp	x5, #0x0
    651c:      	b.eq	0x6bd0 <_stogir.placement.late-with-uses!+0xac0>
    6520:      	add	x5, x2, x3
    6524:      	ldr	x8, [x25, #0x28]
    6528:      	add	x5, x8, x5, lsl #3
    652c:      	ldr	x5, [x5]
    6530:      	ldr	x8, [x24]
    6534:      	orr	w9, w5, wzr
    6538:      	sxtw	x10, w9
    653c:      	add	x8, x8, x10
    6540:      	ldrb	w8, [x8]
    6544:      	cmp	x8, #0x0
    6548:      	b.eq	0x6bf4 <_stogir.placement.late-with-uses!+0xae4>
    654c:      	lsr	x5, x5, #32
    6550:      	add	x8, sp, #0xd0
    6554:      	str	x2, [sp, #0x138]
    6558:      	mov	w2, w9
    655c:      	str	x1, [sp, #0x140]
    6560:      	mov	x1, x21
    6564:      	str	x24, [sp, #0x130]
    6568:      	mov	x24, x0
    656c:      	mov	x0, x20
    6570:      	str	x25, [sp, #0x148]
    6574:      	mov	x25, x3
    6578:      	mov	w3, w5
    657c:      	str	x19, [sp, #0x150]
    6580:      	mov	w19, w4
    6584:      	str	x20, [sp, #0x158]
    6588:      	mov	x20, x6
    658c:      	str	x27, [sp, #0x160]
    6590:      	mov	w27, w7
    6594:      	bl	0x6594 <_stogir.placement.late-with-uses!+0x484>
		0000000000006594:  ARM64_RELOC_BRANCH26	_stogir.placement.use-block
    6598:      	add	x16, sp, #0xd0
    659c:      	ldr	w0, [x16]
    65a0:      	lsr	x16, x0, #0
    65a4:      	cmp	x16, #0x1
    65a8:      	b.eq	0x65c4 <_stogir.placement.late-with-uses!+0x4b4>
    65ac:      	b.lo	0x65b4 <_stogir.placement.late-with-uses!+0x4a4>
    65b0:      	b	0x65c8 <_stogir.placement.late-with-uses!+0x4b8>
    65b4:      	cmp	x16, #0x0
    65b8:      	b.eq	0x65c0 <_stogir.placement.late-with-uses!+0x4b0>
    65bc:      	b	0x65c8 <_stogir.placement.late-with-uses!+0x4b8>
    65c0:      	b	0x65dc <_stogir.placement.late-with-uses!+0x4cc>
    65c4:      	b	0x65cc <_stogir.placement.late-with-uses!+0x4bc>
    65c8:      	b	0x6a78 <_stogir.placement.late-with-uses!+0x968>
    65cc:      	add	x16, sp, #0xd0
    65d0:      	ldr	x28, [x16, #0x8]
    65d4:      	ldr	x26, [x23, #0x8]
    65d8:      	b	0x64c4 <_stogir.placement.late-with-uses!+0x3b4>
    65dc:      	add	x16, sp, #0xd0
    65e0:      	ldr	w0, [x16, #0x8]
    65e4:      	orr	w1, w0, wzr
    65e8:      	uxtb	w16, w27
    65ec:      	cmp	w16, wzr
    65f0:      	b.eq	0x662c <_stogir.placement.late-with-uses!+0x51c>
    65f4:      	mov	w19, w1
    65f8:      	b	0x64c4 <_stogir.placement.late-with-uses!+0x3b4>
    65fc:      	mov	x0, x28
    6600:      	mov	x1, x26
    6604:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006604:  ARM64_RELOC_PAGE21	l_stogir.432
    6608:      	ldr	x2, [x2]
		0000000000006608:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    660c:      	movz	x3, #0x0, lsl #48
    6610:      	bl	0x6610 <_stogir.placement.late-with-uses!+0x500>
		0000000000006610:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6614:      	cmp	x0, #0x0
    6618:      	b.eq	0x668c <_stogir.placement.late-with-uses!+0x57c>
    661c:      	uxtb	w16, w27
    6620:      	cmp	w16, wzr
    6624:      	cset	x0, eq
    6628:      	b	0x6690 <_stogir.placement.late-with-uses!+0x580>
    662c:      	cmp	x20, #0x0
    6630:      	b.le	0x64c0 <_stogir.placement.late-with-uses!+0x3b0>
    6634:      	sxtw	x0, w0
    6638:      	cmp	x0, #0x0
    663c:      	b.le	0x64c0 <_stogir.placement.late-with-uses!+0x3b0>
    6640:      	ldr	x2, [x22, #0x8]
    6644:      	cmp	x20, x2
    6648:      	b.ge	0x64c0 <_stogir.placement.late-with-uses!+0x3b0>
    664c:      	cmp	x0, x2
    6650:      	b.ge	0x64c0 <_stogir.placement.late-with-uses!+0x3b0>
    6654:      	ldr	x2, [x22]
    6658:      	add	x3, x2, x20, lsl #2
    665c:      	ldr	w3, [x3]
    6660:      	sxtw	x3, w3
    6664:      	cmp	x3, #0x0
    6668:      	b.eq	0x6a70 <_stogir.placement.late-with-uses!+0x960>
    666c:      	add	x0, x2, x0, lsl #2
    6670:      	ldr	w0, [x0]
    6674:      	sxtw	x0, w0
    6678:      	cmp	x0, #0x0
    667c:      	b.eq	0x6a70 <_stogir.placement.late-with-uses!+0x960>
    6680:      	mov	w2, w19
    6684:      	movz	x0, #0x0, lsl #48
    6688:      	b	0x6b88 <_stogir.placement.late-with-uses!+0xa78>
    668c:      	movz	x0, #0x0, lsl #48
    6690:      	lsl	x20, x24, #2
    6694:      	cmp	x0, #0x0
    6698:      	b.eq	0x6c20 <_stogir.placement.late-with-uses!+0xb10>
    669c:      	ldr	x0, [x21]
    66a0:      	add	x0, x20, x0
    66a4:      	ldr	w0, [x0]
    66a8:      	add	x8, sp, #0xf0
    66ac:      	ldr	x1, [sp, #0x110]
    66b0:      	mov	w2, w0
    66b4:      	mov	x0, x22
    66b8:      	mov	w3, w19
    66bc:      	bl	0x66bc <_stogir.placement.late-with-uses!+0x5ac>
		00000000000066bc:  ARM64_RELOC_BRANCH26	_stogir.placement.choose-block
    66c0:      	add	x16, sp, #0xf0
    66c4:      	ldr	w0, [x16]
    66c8:      	lsr	x16, x0, #0
    66cc:      	cmp	x16, #0x1
    66d0:      	b.eq	0x66f0 <_stogir.placement.late-with-uses!+0x5e0>
    66d4:      	b.lo	0x66dc <_stogir.placement.late-with-uses!+0x5cc>
    66d8:      	b	0x66f4 <_stogir.placement.late-with-uses!+0x5e4>
    66dc:      	cmp	x16, #0x0
    66e0:      	b.eq	0x66e8 <_stogir.placement.late-with-uses!+0x5d8>
    66e4:      	b	0x66f4 <_stogir.placement.late-with-uses!+0x5e4>
    66e8:      	ldr	x19, [sp, #0x160]
    66ec:      	b	0x670c <_stogir.placement.late-with-uses!+0x5fc>
    66f0:      	b	0x66f8 <_stogir.placement.late-with-uses!+0x5e8>
    66f4:      	b	0x6bb8 <_stogir.placement.late-with-uses!+0xaa8>
    66f8:      	add	x16, sp, #0xf0
    66fc:      	ldr	x28, [x16, #0x8]
    6700:      	ldr	x19, [sp, #0x160]
    6704:      	ldr	x26, [x19, #0x8]
    6708:      	b	0x6724 <_stogir.placement.late-with-uses!+0x614>
    670c:      	add	x16, sp, #0xf0
    6710:      	ldr	w0, [x16, #0x8]
    6714:      	mov	x1, x24
    6718:      	mov	w2, w0
    671c:      	mov	x0, x21
    6720:      	bl	0x6720 <_stogir.placement.late-with-uses!+0x610>
		0000000000006720:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    6724:      	mov	x0, x28
    6728:      	mov	x1, x26
    672c:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		000000000000672c:  ARM64_RELOC_PAGE21	l_stogir.432
    6730:      	ldr	x2, [x2]
		0000000000006730:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    6734:      	movz	x3, #0x0, lsl #48
    6738:      	bl	0x6738 <_stogir.placement.late-with-uses!+0x628>
		0000000000006738:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    673c:      	cmp	x0, #0x0
    6740:      	b.eq	0x6c28 <_stogir.placement.late-with-uses!+0xb18>
    6744:      	cmp	x24, #0x0
    6748:      	cset	w25, le
    674c:      	ldr	x27, [sp, #0x158]
    6750:      	ldr	x0, [x27]
    6754:      	add	x0, x0, x24, lsl #4
    6758:      	ldr	x0, [x0]
    675c:      	ldr	x1, [x27, #0x78]
    6760:      	uxtb	w0, w0
    6764:      	add	x1, x1, x24, lsl #2
    6768:      	cmp	x0, #0x83
    676c:      	cset	w2, lt
    6770:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006770:  ARM64_RELOC_PAGE21	l_stogir.433
    6774:      	ldr	x16, [x16]
		0000000000006774:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    6778:      	add	x0, x16, x0, lsl #2
    677c:      	ldr	w1, [x1]
    6780:      	sxtw	x1, w1
    6784:      	mov	x3, #0x1                ; =1
    6788:      	b	0x6874 <_stogir.placement.late-with-uses!+0x764>
    678c:      	sub	w4, w4, #0x1
    6790:      	lsl	w4, w4, #2
    6794:      	ubfx	x4, x4, #0, #32
    6798:      	lsr	x4, x6, x4
    679c:      	and	w4, w4, #0xf
    67a0:      	b	0x67a8 <_stogir.placement.late-with-uses!+0x698>
    67a4:      	movz	w4, #0x0, lsl #16
    67a8:      	b	0x67b4 <_stogir.placement.late-with-uses!+0x6a4>
    67ac:      	nop
    67b0:      	movz	w4, #0x0, lsl #16
    67b4:      	ubfx	x4, x4, #0, #32
    67b8:      	cmp	x4, #0xf
    67bc:      	b.hs	0x6c3c <_stogir.placement.late-with-uses!+0xb2c>
    67c0:      	mov	x16, #0x1               ; =1
    67c4:      	lsl	x4, x16, x4
    67c8:      	mov	w17, #0x5e1c            ; =24092
    67cc:      	and	w4, w4, w17
    67d0:      	ubfx	x4, x4, #0, #32
    67d4:      	cmp	x4, #0x0
    67d8:      	b.eq	0x6c5c <_stogir.placement.late-with-uses!+0xb4c>
    67dc:      	uxtb	w16, w25
    67e0:      	cmp	w16, wzr
    67e4:      	b.eq	0x68ac <_stogir.placement.late-with-uses!+0x79c>
    67e8:      	ldr	x4, [sp, #0x128]
    67ec:      	movz	w6, #0x0, lsl #16
    67f0:      	movz	w5, #0x0, lsl #16
    67f4:      	ubfx	x6, x6, #0, #32
    67f8:      	lsr	x16, x6, #0
    67fc:      	cmp	x16, #0x1
    6800:      	b.eq	0x681c <_stogir.placement.late-with-uses!+0x70c>
    6804:      	b.lo	0x680c <_stogir.placement.late-with-uses!+0x6fc>
    6808:      	b	0x6820 <_stogir.placement.late-with-uses!+0x710>
    680c:      	cmp	x16, #0x0
    6810:      	b.eq	0x6818 <_stogir.placement.late-with-uses!+0x708>
    6814:      	b	0x6820 <_stogir.placement.late-with-uses!+0x710>
    6818:      	b	0x6824 <_stogir.placement.late-with-uses!+0x714>
    681c:      	b	0x68e8 <_stogir.placement.late-with-uses!+0x7d8>
    6820:      	b	0x6bb0 <_stogir.placement.late-with-uses!+0xaa0>
    6824:      	str	x21, [sp, #0x188]
    6828:      	str	x4, [sp, #0x128]
    682c:      	str	x20, [sp, #0x180]
    6830:      	str	x19, [sp, #0x160]
    6834:      	mov	x19, x3
    6838:      	str	x1, [sp, #0x178]
    683c:      	str	w2, [sp, #0x168]
    6840:      	str	x0, [sp, #0x170]
    6844:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006844:  ARM64_RELOC_PAGE21	l_stogir.434
    6848:      	ldr	x28, [x28]
		0000000000006848:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    684c:      	mov	x26, #0x1e              ; =30
    6850:      	add	x0, x19, #0x1
    6854:      	sxtw	x19, w0
    6858:      	ldr	x21, [sp, #0x188]
    685c:      	ldr	x20, [sp, #0x180]
    6860:      	ldr	x1, [sp, #0x178]
    6864:      	ldr	w2, [sp, #0x168]
    6868:      	ldr	x0, [sp, #0x170]
    686c:      	mov	x3, x19
    6870:      	ldr	x19, [sp, #0x160]
    6874:      	cmp	x3, x1
    6878:      	b.gt	0x6c7c <_stogir.placement.late-with-uses!+0xb6c>
    687c:      	orr	w4, w3, wzr
    6880:      	sxtw	x5, w4
    6884:      	uxtb	w16, w2
    6888:      	cmp	w16, wzr
    688c:      	b.eq	0x67b0 <_stogir.placement.late-with-uses!+0x6a0>
    6890:      	ldr	w6, [x0]
    6894:      	cmp	x5, #0x0
    6898:      	b.le	0x67a4 <_stogir.placement.late-with-uses!+0x694>
    689c:      	cmp	x5, #0x4
    68a0:      	b.le	0x678c <_stogir.placement.late-with-uses!+0x67c>
    68a4:      	mov	w4, #0x4                ; =4
    68a8:      	b	0x6790 <_stogir.placement.late-with-uses!+0x680>
    68ac:      	ldr	x4, [x27, #0x8]
    68b0:      	cmp	x24, x4
    68b4:      	b.ge	0x6c88 <_stogir.placement.late-with-uses!+0xb78>
    68b8:      	ldr	x4, [sp, #0x128]
    68bc:      	ldr	x6, [x4, #0x8]
    68c0:      	cmp	x24, x6
    68c4:      	b.ge	0x694c <_stogir.placement.late-with-uses!+0x83c>
    68c8:      	ldr	x6, [x27, #0x78]
    68cc:      	add	x6, x20, x6
    68d0:      	ldr	w6, [x6]
    68d4:      	sxtw	x6, w6
    68d8:      	cmp	x6, #0x0
    68dc:      	cset	w6, ge
    68e0:      	ubfx	x6, x6, #0, #8
    68e4:      	b	0x6950 <_stogir.placement.late-with-uses!+0x840>
    68e8:      	sxtw	x6, w5
    68ec:      	cmp	x6, #0x0
    68f0:      	b.le	0x6c90 <_stogir.placement.late-with-uses!+0xb80>
    68f4:      	add	x16, sp, #0x10
    68f8:      	ldr	x7, [x16]
    68fc:      	add	x8, x7, x6, lsl #2
    6900:      	ldr	w8, [x8]
    6904:      	sxtw	x9, w8
    6908:      	cmp	x9, #0x0
    690c:      	b.le	0x6cb4 <_stogir.placement.late-with-uses!+0xba4>
    6910:      	sub	w8, w8, #0x1
    6914:      	add	x6, x7, x6, lsl #2
    6918:      	str	w8, [x6]
    691c:      	cmp	x9, #0x1
    6920:      	b.ne	0x6cd8 <_stogir.placement.late-with-uses!+0xbc8>
    6924:      	add	x16, sp, #0x70
    6928:      	ldr	x6, [x16, #0x8]
    692c:      	add	x16, sp, #0x70
    6930:      	ldr	x7, [x16, #0x10]
    6934:      	cmp	x6, x7
    6938:      	b.lt	0x6cfc <_stogir.placement.late-with-uses!+0xbec>
    693c:      	cmp	x7, #0x0
    6940:      	b.ne	0x6a80 <_stogir.placement.late-with-uses!+0x970>
    6944:      	mov	x7, #0x2                ; =2
    6948:      	b	0x6a84 <_stogir.placement.late-with-uses!+0x974>
    694c:      	movz	x6, #0x0, lsl #48
    6950:      	b	0x6958 <_stogir.placement.late-with-uses!+0x848>
    6954:      	movz	x6, #0x0, lsl #48
    6958:      	cmp	x6, #0x0
    695c:      	b.eq	0x67ec <_stogir.placement.late-with-uses!+0x6dc>
    6960:      	cmp	x5, #0x1
    6964:      	b.lt	0x63ec <_stogir.placement.late-with-uses!+0x2dc>
    6968:      	ldr	x6, [x27, #0x78]
    696c:      	add	x6, x20, x6
    6970:      	ldr	w6, [x6]
    6974:      	sxtw	x6, w6
    6978:      	cmp	x5, x6
    697c:      	b.gt	0x63ec <_stogir.placement.late-with-uses!+0x2dc>
    6980:      	ldr	x6, [x27]
    6984:      	asr	x16, x5, #63
    6988:      	lsr	x16, x16, #62
    698c:      	add	x7, x5, x16
    6990:      	asr	x7, x7, #2
    6994:      	asr	x16, x5, #63
    6998:      	lsr	x16, x16, #62
    699c:      	add	x5, x5, x16
    69a0:      	and	x5, x5, #0x3
    69a4:      	sub	x5, x5, x16
    69a8:      	add	x7, x7, x24
    69ac:      	add	x6, x6, x7, lsl #4
    69b0:      	add	x5, x6, x5, lsl #2
    69b4:      	ldr	w5, [x5]
    69b8:      	movn	w17, #0x0, lsl #16
    69bc:      	and	w5, w5, w17
    69c0:      	mov	w6, #0x1                ; =1
    69c4:      	b	0x63f4 <_stogir.placement.late-with-uses!+0x2e4>
    69c8:      	add	x0, sp, #0x10
    69cc:      	bl	0x69cc <_stogir.placement.late-with-uses!+0x8bc>
		00000000000069cc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    69d0:      	add	x0, sp, #0x70
    69d4:      	bl	0x69d4 <_stogir.placement.late-with-uses!+0x8c4>
		00000000000069d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    69d8:      	mov	x0, x28
    69dc:      	mov	x1, x26
    69e0:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		00000000000069e0:  ARM64_RELOC_PAGE21	l_stogir.432
    69e4:      	ldr	x2, [x2]
		00000000000069e4:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    69e8:      	movz	x3, #0x0, lsl #48
    69ec:      	bl	0x69ec <_stogir.placement.late-with-uses!+0x8dc>
		00000000000069ec:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    69f0:      	cmp	x0, #0x0
    69f4:      	b.eq	0x6a24 <_stogir.placement.late-with-uses!+0x914>
    69f8:      	cmp	x19, #0x0
    69fc:      	b.le	0x6a14 <_stogir.placement.late-with-uses!+0x904>
    6a00:      	mov	x0, #0x1                ; =1
    6a04:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006a04:  ARM64_RELOC_PAGE21	l_stogir.435
    6a08:      	ldr	x28, [x28]
		0000000000006a08:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    6a0c:      	mov	x26, #0x26              ; =38
    6a10:      	b	0x6a20 <_stogir.placement.late-with-uses!+0x910>
    6a14:      	movz	x0, #0x0, lsl #48
    6a18:      	movz	x28, #0x0, lsl #48
    6a1c:      	movz	x26, #0x0, lsl #48
    6a20:      	b	0x6a28 <_stogir.placement.late-with-uses!+0x918>
    6a24:      	mov	x0, #0x1                ; =1
    6a28:      	ldr	x1, [sp, #0x118]
    6a2c:      	str	x0, [x1]
    6a30:      	str	x28, [x1, #0x8]
    6a34:      	str	x26, [x1, #0x10]
    6a38:      	ldr	x19, [sp, #0x190]
    6a3c:      	ldr	x20, [sp, #0x198]
    6a40:      	ldr	x21, [sp, #0x1a0]
    6a44:      	ldr	x22, [sp, #0x1a8]
    6a48:      	ldr	x23, [sp, #0x1b0]
    6a4c:      	ldr	x24, [sp, #0x1b8]
    6a50:      	ldr	x25, [sp, #0x1c0]
    6a54:      	ldr	x26, [sp, #0x1c8]
    6a58:      	ldr	x27, [sp, #0x1d0]
    6a5c:      	ldr	x28, [sp, #0x1d8]
    6a60:      	ldr	x29, [sp]
    6a64:      	ldr	x30, [sp, #0x8]
    6a68:      	add	sp, sp, #0x1e0
    6a6c:      	ret
    6a70:      	movz	x19, #0x0, lsl #48
    6a74:      	b	0x64c4 <_stogir.placement.late-with-uses!+0x3b4>
    6a78:      	brk	#0
    6a7c:      	b	0x6a78 <_stogir.placement.late-with-uses!+0x968>
    6a80:      	lsl	x7, x7, #1
    6a84:      	str	w2, [sp, #0x168]
    6a88:      	str	x0, [sp, #0x170]
    6a8c:      	add	x0, sp, #0x70
    6a90:      	str	x1, [sp, #0x178]
    6a94:      	mov	x1, x7
    6a98:      	str	x4, [sp, #0x128]
    6a9c:      	str	x19, [sp, #0x160]
    6aa0:      	mov	x19, x3
    6aa4:      	str	x20, [sp, #0x180]
    6aa8:      	mov	w20, w5
    6aac:      	str	x21, [sp, #0x188]
    6ab0:      	mov	x21, x6
    6ab4:      	bl	0x6ab4 <_stogir.placement.late-with-uses!+0x9a4>
		0000000000006ab4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    6ab8:      	add	x0, x21, #0x1
    6abc:      	add	x16, sp, #0x70
    6ac0:      	ldr	x1, [x16]
    6ac4:      	add	x1, x1, x21, lsl #2
    6ac8:      	str	w20, [x1]
    6acc:      	add	x16, sp, #0x70
    6ad0:      	str	x0, [x16, #0x8]
    6ad4:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6ad8:      	ldr	x0, [x22]
    6adc:      	orr	x2, x0, xzr
    6ae0:      	add	x2, x2, x19, lsl #2
    6ae4:      	add	x0, x0, x1, lsl #2
    6ae8:      	ldr	w1, [x2]
    6aec:      	orr	w19, w1, wzr
    6af0:      	ldr	w0, [x0]
    6af4:      	orr	w1, w0, wzr
    6af8:      	sxtw	x19, w19
    6afc:      	sxtw	x1, w1
    6b00:      	cmp	x19, x1
    6b04:      	b.eq	0x6a74 <_stogir.placement.late-with-uses!+0x964>
    6b08:      	b	0x6ad8 <_stogir.placement.late-with-uses!+0x9c8>
    6b0c:      	nop
    6b10:      	sxtw	x1, w1
    6b14:      	sub	x2, x2, #0x1
    6b18:      	ldr	x3, [x22]
    6b1c:      	add	x1, x3, x1, lsl #2
    6b20:      	ldr	w1, [x1]
    6b24:      	cmp	x2, x0
    6b28:      	b.gt	0x6b10 <_stogir.placement.late-with-uses!+0xa00>
    6b2c:      	b	0x6af8 <_stogir.placement.late-with-uses!+0x9e8>
    6b30:      	sxtw	x19, w19
    6b34:      	sub	x0, x0, #0x1
    6b38:      	ldr	x3, [x22]
    6b3c:      	add	x3, x3, x19, lsl #2
    6b40:      	ldr	w3, [x3]
    6b44:      	orr	w19, w3, wzr
    6b48:      	cmp	x0, x2
    6b4c:      	b.gt	0x6b30 <_stogir.placement.late-with-uses!+0xa20>
    6b50:      	b	0x6b24 <_stogir.placement.late-with-uses!+0xa14>
    6b54:      	nop
    6b58:      	orr	w3, w4, wzr
    6b5c:      	add	x2, x2, #0x1
    6b60:      	ldr	x4, [x22]
    6b64:      	sxtw	x3, w3
    6b68:      	add	x4, x4, x3, lsl #2
    6b6c:      	ldr	w4, [x4]
    6b70:      	sxtw	x5, w4
    6b74:      	cmp	x3, x5
    6b78:      	b.eq	0x6b48 <_stogir.placement.late-with-uses!+0xa38>
    6b7c:      	b	0x6b58 <_stogir.placement.late-with-uses!+0xa48>
    6b80:      	orr	w2, w3, wzr
    6b84:      	add	x0, x0, #0x1
    6b88:      	ldr	x3, [x22]
    6b8c:      	sxtw	x2, w2
    6b90:      	add	x3, x3, x2, lsl #2
    6b94:      	ldr	w3, [x3]
    6b98:      	sxtw	x4, w3
    6b9c:      	cmp	x2, x4
    6ba0:      	b.ne	0x6b80 <_stogir.placement.late-with-uses!+0xa70>
    6ba4:      	mov	w3, w1
    6ba8:      	movz	x2, #0x0, lsl #48
    6bac:      	b	0x6b60 <_stogir.placement.late-with-uses!+0xa50>
    6bb0:      	brk	#0
    6bb4:      	b	0x6bb0 <_stogir.placement.late-with-uses!+0xaa0>
    6bb8:      	brk	#0
    6bbc:      	b	0x6bb8 <_stogir.placement.late-with-uses!+0xaa8>
    6bc0:      	str	x23, [sp, #0x110]
    6bc4:      	b	0x62f8 <_stogir.placement.late-with-uses!+0x1e8>
    6bc8:      	ldr	x19, [sp, #0x120]
    6bcc:      	b	0x69c8 <_stogir.placement.late-with-uses!+0x8b8>
    6bd0:      	str	x19, [sp, #0x150]
    6bd4:      	str	x20, [sp, #0x158]
    6bd8:      	str	x24, [sp, #0x130]
    6bdc:      	str	x25, [sp, #0x148]
    6be0:      	mov	x24, x0
    6be4:      	str	x27, [sp, #0x160]
    6be8:      	mov	w27, w7
    6bec:      	mov	w19, w4
    6bf0:      	b	0x65fc <_stogir.placement.late-with-uses!+0x4ec>
    6bf4:      	str	x19, [sp, #0x150]
    6bf8:      	str	x20, [sp, #0x158]
    6bfc:      	str	x24, [sp, #0x130]
    6c00:      	str	x25, [sp, #0x148]
    6c04:      	mov	x25, x3
    6c08:      	mov	x24, x0
    6c0c:      	str	x2, [sp, #0x138]
    6c10:      	str	x1, [sp, #0x140]
    6c14:      	str	x27, [sp, #0x160]
    6c18:      	mov	w19, w4
    6c1c:      	b	0x64c4 <_stogir.placement.late-with-uses!+0x3b4>
    6c20:      	ldr	x19, [sp, #0x160]
    6c24:      	b	0x6724 <_stogir.placement.late-with-uses!+0x614>
    6c28:      	ldr	x27, [sp, #0x158]
    6c2c:      	str	x21, [sp, #0x188]
    6c30:      	str	x19, [sp, #0x160]
    6c34:      	ldr	x19, [sp, #0x120]
    6c38:      	b	0x6404 <_stogir.placement.late-with-uses!+0x2f4>
    6c3c:      	str	x21, [sp, #0x188]
    6c40:      	str	x20, [sp, #0x180]
    6c44:      	str	x19, [sp, #0x160]
    6c48:      	mov	x19, x3
    6c4c:      	str	x1, [sp, #0x178]
    6c50:      	str	w2, [sp, #0x168]
    6c54:      	str	x0, [sp, #0x170]
    6c58:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6c5c:      	str	x21, [sp, #0x188]
    6c60:      	str	x20, [sp, #0x180]
    6c64:      	str	x19, [sp, #0x160]
    6c68:      	mov	x19, x3
    6c6c:      	str	x1, [sp, #0x178]
    6c70:      	str	w2, [sp, #0x168]
    6c74:      	str	x0, [sp, #0x170]
    6c78:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6c7c:      	str	x21, [sp, #0x188]
    6c80:      	str	x19, [sp, #0x160]
    6c84:      	b	0x63f8 <_stogir.placement.late-with-uses!+0x2e8>
    6c88:      	ldr	x4, [sp, #0x128]
    6c8c:      	b	0x6954 <_stogir.placement.late-with-uses!+0x844>
    6c90:      	str	x21, [sp, #0x188]
    6c94:      	str	x4, [sp, #0x128]
    6c98:      	str	x20, [sp, #0x180]
    6c9c:      	str	x19, [sp, #0x160]
    6ca0:      	mov	x19, x3
    6ca4:      	str	x1, [sp, #0x178]
    6ca8:      	str	w2, [sp, #0x168]
    6cac:      	str	x0, [sp, #0x170]
    6cb0:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6cb4:      	str	x21, [sp, #0x188]
    6cb8:      	str	x4, [sp, #0x128]
    6cbc:      	str	x20, [sp, #0x180]
    6cc0:      	str	x19, [sp, #0x160]
    6cc4:      	mov	x19, x3
    6cc8:      	str	x1, [sp, #0x178]
    6ccc:      	str	w2, [sp, #0x168]
    6cd0:      	str	x0, [sp, #0x170]
    6cd4:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6cd8:      	str	x21, [sp, #0x188]
    6cdc:      	str	x4, [sp, #0x128]
    6ce0:      	str	x20, [sp, #0x180]
    6ce4:      	str	x19, [sp, #0x160]
    6ce8:      	mov	x19, x3
    6cec:      	str	x1, [sp, #0x178]
    6cf0:      	str	w2, [sp, #0x168]
    6cf4:      	str	x0, [sp, #0x170]
    6cf8:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6cfc:      	str	x21, [sp, #0x188]
    6d00:      	str	x4, [sp, #0x128]
    6d04:      	str	x20, [sp, #0x180]
    6d08:      	str	x19, [sp, #0x160]
    6d0c:      	mov	x19, x3
    6d10:      	str	x1, [sp, #0x178]
    6d14:      	mov	x21, x6
    6d18:      	str	w2, [sp, #0x168]
    6d1c:      	str	x0, [sp, #0x170]
    6d20:      	mov	w20, w5
    6d24:      	b	0x6ab8 <_stogir.placement.late-with-uses!+0x9a8>

0000000000006d28 <_stogir.checked-schedule.place!>:
    6d28:      	sub	sp, sp, #0x90
    6d2c:      	str	x29, [sp]
    6d30:      	str	x30, [sp, #0x8]
    6d34:      	mov	x29, sp
    6d38:      	str	x19, [sp, #0x40]
    6d3c:      	str	x20, [sp, #0x48]
    6d40:      	str	x21, [sp, #0x50]
    6d44:      	str	x22, [sp, #0x58]
    6d48:      	str	x23, [sp, #0x60]
    6d4c:      	str	x24, [sp, #0x68]
    6d50:      	str	x25, [sp, #0x70]
    6d54:      	str	x26, [sp, #0x78]
    6d58:      	str	x27, [sp, #0x80]
    6d5c:      	str	x28, [sp, #0x88]
    6d60:      	add	x16, sp, #0x20
    6d64:      	orr	x3, x16, xzr
    6d68:      	add	x19, x3, #0x8
    6d6c:      	mov	x20, #0x1               ; =1
    6d70:      	movz	x21, #0x0, lsl #48
    6d74:      	adrp	x22, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006d74:  ARM64_RELOC_PAGE21	l_stogir.436
    6d78:      	ldr	x22, [x22]
		0000000000006d78:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    6d7c:      	movz	x23, #0x0, lsl #48
    6d80:      	b	0x6dc0 <_stogir.checked-schedule.place!+0x98>
    6d84:      	nop
    6d88:      	add	x16, sp, #0x20
    6d8c:      	ldr	x22, [x16, #0x8]
    6d90:      	ldr	x23, [x19, #0x8]
    6d94:      	sxtw	x24, w24
    6d98:      	add	x0, x24, #0x4
    6d9c:      	asr	x16, x0, #63
    6da0:      	lsr	x16, x16, #62
    6da4:      	add	x0, x0, x16
    6da8:      	asr	x0, x0, #2
    6dac:      	add	x20, x0, x20
    6db0:      	mov	x8, x25
    6db4:      	mov	x0, x26
    6db8:      	mov	x1, x27
    6dbc:      	mov	x2, x28
    6dc0:      	cmp	x23, #0x0
    6dc4:      	b.ne	0x6f38 <_stogir.checked-schedule.place!+0x210>
    6dc8:      	ldr	x3, [x0, #0x8]
    6dcc:      	cmp	x20, x3
    6dd0:      	b.ge	0x6f40 <_stogir.checked-schedule.place!+0x218>
    6dd4:      	ldr	x3, [x0]
    6dd8:      	add	x3, x3, x20, lsl #4
    6ddc:      	ldr	x4, [x3]
    6de0:      	uxtb	w5, w4
    6de4:      	ldr	x3, [x3, #0x8]
    6de8:      	add	x16, sp, #0x10
    6dec:      	str	x4, [x16]
    6df0:      	add	x16, sp, #0x10
    6df4:      	str	x3, [x16, #0x8]
    6df8:      	ldr	x3, [x0, #0x78]
    6dfc:      	add	x3, x3, x20, lsl #2
    6e00:      	ldr	w24, [x3]
    6e04:      	cmp	x5, #0x2c
    6e08:      	b.ne	0x6f48 <_stogir.checked-schedule.place!+0x220>
    6e0c:      	ldr	x3, [x2]
    6e10:      	add	x3, x20, x3
    6e14:      	ldrb	w3, [x3]
    6e18:      	cmp	x3, #0x0
    6e1c:      	b.eq	0x6f5c <_stogir.checked-schedule.place!+0x234>
    6e20:      	orr	w3, w20, wzr
    6e24:      	mov	x25, x8
    6e28:      	add	x8, sp, #0x20
    6e2c:      	mov	x26, x0
    6e30:      	mov	x27, x1
    6e34:      	mov	w1, w3
    6e38:      	mov	x28, x2
    6e3c:      	bl	0x6e3c <_stogir.checked-schedule.place!+0x114>
		0000000000006e3c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    6e40:      	add	x16, sp, #0x20
    6e44:      	ldr	w0, [x16]
    6e48:      	lsr	x16, x0, #0
    6e4c:      	cmp	x16, #0x1
    6e50:      	b.eq	0x6e6c <_stogir.checked-schedule.place!+0x144>
    6e54:      	b.lo	0x6e5c <_stogir.checked-schedule.place!+0x134>
    6e58:      	b	0x6e70 <_stogir.checked-schedule.place!+0x148>
    6e5c:      	cmp	x16, #0x0
    6e60:      	b.eq	0x6e68 <_stogir.checked-schedule.place!+0x140>
    6e64:      	b	0x6e70 <_stogir.checked-schedule.place!+0x148>
    6e68:      	b	0x6e74 <_stogir.checked-schedule.place!+0x14c>
    6e6c:      	b	0x6d88 <_stogir.checked-schedule.place!+0x60>
    6e70:      	b	0x6f30 <_stogir.checked-schedule.place!+0x208>
    6e74:      	add	x16, sp, #0x20
    6e78:      	ldr	w0, [x16, #0x8]
    6e7c:      	sxtw	x0, w0
    6e80:      	cmp	x0, #0x0
    6e84:      	b.eq	0x6f2c <_stogir.checked-schedule.place!+0x204>
    6e88:      	add	x16, sp, #0x10
    6e8c:      	ldr	w0, [x16, #0x4]
    6e90:      	sxtw	x0, w0
    6e94:      	ldr	x1, [x27]
    6e98:      	add	x0, x1, x0, lsl #2
    6e9c:      	ldr	w0, [x0]
    6ea0:      	sxtw	x2, w0
    6ea4:      	cmp	x2, #0x0
    6ea8:      	b.gt	0x6f1c <_stogir.checked-schedule.place!+0x1f4>
    6eac:      	adrp	x22, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006eac:  ARM64_RELOC_PAGE21	l_stogir.437
    6eb0:      	ldr	x22, [x22]
		0000000000006eb0:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    6eb4:      	mov	x23, #0x21              ; =33
    6eb8:      	b	0x6f2c <_stogir.checked-schedule.place!+0x204>
    6ebc:      	cmp	x23, #0x0
    6ec0:      	b.ne	0x6ed4 <_stogir.checked-schedule.place!+0x1ac>
    6ec4:      	and	x22, x21, #0xffffffff
    6ec8:      	movz	x0, #0x0, lsl #48
    6ecc:      	movz	x23, #0x0, lsl #48
    6ed0:      	b	0x6ed8 <_stogir.checked-schedule.place!+0x1b0>
    6ed4:      	mov	x0, #0x1                ; =1
    6ed8:      	str	x0, [x25]
    6edc:      	str	x22, [x25, #0x8]
    6ee0:      	str	x23, [x25, #0x10]
    6ee4:      	ldr	x19, [sp, #0x40]
    6ee8:      	ldr	x20, [sp, #0x48]
    6eec:      	ldr	x21, [sp, #0x50]
    6ef0:      	ldr	x22, [sp, #0x58]
    6ef4:      	ldr	x23, [sp, #0x60]
    6ef8:      	ldr	x24, [sp, #0x68]
    6efc:      	ldr	x25, [sp, #0x70]
    6f00:      	ldr	x26, [sp, #0x78]
    6f04:      	ldr	x27, [sp, #0x80]
    6f08:      	ldr	x28, [sp, #0x88]
    6f0c:      	ldr	x29, [sp]
    6f10:      	ldr	x30, [sp, #0x8]
    6f14:      	add	sp, sp, #0x90
    6f18:      	ret
    6f1c:      	add	x2, x21, #0x1
    6f20:      	add	x1, x1, x20, lsl #2
    6f24:      	sxtw	x21, w2
    6f28:      	str	w0, [x1]
    6f2c:      	b	0x6d94 <_stogir.checked-schedule.place!+0x6c>
    6f30:      	brk	#0
    6f34:      	b	0x6f30 <_stogir.checked-schedule.place!+0x208>
    6f38:      	mov	x25, x8
    6f3c:      	b	0x6ebc <_stogir.checked-schedule.place!+0x194>
    6f40:      	mov	x25, x8
    6f44:      	b	0x6ebc <_stogir.checked-schedule.place!+0x194>
    6f48:      	mov	x25, x8
    6f4c:      	mov	x26, x0
    6f50:      	mov	x27, x1
    6f54:      	mov	x28, x2
    6f58:      	b	0x6d94 <_stogir.checked-schedule.place!+0x6c>
    6f5c:      	mov	x25, x8
    6f60:      	mov	x26, x0
    6f64:      	mov	x27, x1
    6f68:      	mov	x28, x2
    6f6c:      	b	0x6d94 <_stogir.checked-schedule.place!+0x6c>

0000000000006f70 <_stogir.loops.reorder!>:
    6f70:      	sub	sp, sp, #0x290
    6f74:      	str	x29, [sp]
    6f78:      	str	x30, [sp, #0x8]
    6f7c:      	mov	x29, sp
    6f80:      	str	x19, [sp, #0x240]
    6f84:      	str	x20, [sp, #0x248]
    6f88:      	str	x21, [sp, #0x250]
    6f8c:      	str	x22, [sp, #0x258]
    6f90:      	str	x23, [sp, #0x260]
    6f94:      	str	x24, [sp, #0x268]
    6f98:      	str	x25, [sp, #0x270]
    6f9c:      	str	x26, [sp, #0x278]
    6fa0:      	str	x27, [sp, #0x280]
    6fa4:      	str	x28, [sp, #0x288]
    6fa8:      	add	x6, x0, #0x50
    6fac:      	ldr	x7, [x0, #0x50]
    6fb0:      	ldr	x6, [x6, #0x8]
    6fb4:      	orr	x19, x7, xzr
    6fb8:      	orr	x20, x6, xzr
    6fbc:      	movz	x21, #0x0, lsl #48
    6fc0:      	movz	x22, #0x0, lsl #48
    6fc4:      	b	0x73d4 <_stogir.loops.reorder!+0x464>
    6fc8:      	movz	w0, #0x0, lsl #16
    6fcc:      	movz	x1, #0x0, lsl #48
    6fd0:      	ubfx	x0, x0, #0, #32
    6fd4:      	lsr	x16, x0, #0
    6fd8:      	cmp	x16, #0x1
    6fdc:      	b.eq	0x6ff8 <_stogir.loops.reorder!+0x88>
    6fe0:      	b.lo	0x6fe8 <_stogir.loops.reorder!+0x78>
    6fe4:      	b	0x6ffc <_stogir.loops.reorder!+0x8c>
    6fe8:      	cmp	x16, #0x0
    6fec:      	b.eq	0x6ff4 <_stogir.loops.reorder!+0x84>
    6ff0:      	b	0x6ffc <_stogir.loops.reorder!+0x8c>
    6ff4:      	b	0x7084 <_stogir.loops.reorder!+0x114>
    6ff8:      	b	0x7000 <_stogir.loops.reorder!+0x90>
    6ffc:      	b	0x7ad4 <_stogir.loops.reorder!+0xb64>
    7000:      	orr	w0, w1, wzr
    7004:      	asr	x2, x1, #32
    7008:      	add	x16, sp, #0x30
    700c:      	ldr	x3, [x16]
    7010:      	sxtw	x4, w0
    7014:      	orr	x5, x3, xzr
    7018:      	add	x2, x3, x2, lsl #2
    701c:      	add	x3, x5, x4, lsl #2
    7020:      	ldr	w3, [x3]
    7024:      	sxtw	x3, w3
    7028:      	ldr	w2, [x2]
    702c:      	cmp	x3, #0x0
    7030:      	b.lt	0x7064 <_stogir.loops.reorder!+0xf4>
    7034:      	sxtw	x2, w2
    7038:      	cmp	x2, #0x0
    703c:      	b.lt	0x7064 <_stogir.loops.reorder!+0xf4>
    7040:      	cmp	x3, x2
    7044:      	b.lt	0x7064 <_stogir.loops.reorder!+0xf4>
    7048:      	lsr	x1, x1, #32
    704c:      	mov	w2, w0
    7050:      	mov	x0, x26
    7054:      	bl	0x7054 <_stogir.loops.reorder!+0xe4>
		0000000000007054:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    7058:      	cmp	x0, #0x0
    705c:      	b.ne	0x7064 <_stogir.loops.reorder!+0xf4>
    7060:      	movz	x22, #0x0, lsl #48
    7064:      	cmp	x21, x20
    7068:      	b.ge	0x6fc8 <_stogir.loops.reorder!+0x58>
    706c:      	add	x0, x21, #0x1
    7070:      	add	x1, x19, x21, lsl #4
    7074:      	ldr	x1, [x1]
    7078:      	mov	x21, x0
    707c:      	mov	w0, #0x1                ; =1
    7080:      	b	0x6fd0 <_stogir.loops.reorder!+0x60>
    7084:      	cmp	x22, #0x0
    7088:      	b.eq	0x7200 <_stogir.loops.reorder!+0x290>
    708c:      	add	x8, sp, #0xe0
    7090:      	ldr	x0, [sp, #0x230]
    7094:      	bl	0x7094 <_stogir.loops.reorder!+0x124>
		0000000000007094:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7098:      	add	x16, sp, #0xe0
    709c:      	ldr	x0, [x16]
    70a0:      	add	x16, sp, #0xb0
    70a4:      	str	x0, [x16]
    70a8:      	add	x16, sp, #0xe0
    70ac:      	ldr	x0, [x16, #0x8]
    70b0:      	add	x16, sp, #0xb0
    70b4:      	str	x0, [x16, #0x8]
    70b8:      	add	x16, sp, #0xe0
    70bc:      	ldr	x0, [x16, #0x10]
    70c0:      	add	x16, sp, #0xb0
    70c4:      	str	x0, [x16, #0x10]
    70c8:      	add	x16, sp, #0xe0
    70cc:      	ldr	x0, [x16, #0x18]
    70d0:      	add	x16, sp, #0xb0
    70d4:      	str	x0, [x16, #0x18]
    70d8:      	add	x16, sp, #0xe0
    70dc:      	ldr	x0, [x16, #0x20]
    70e0:      	add	x16, sp, #0xb0
    70e4:      	str	x0, [x16, #0x20]
    70e8:      	add	x8, sp, #0x140
    70ec:      	ldr	x0, [sp, #0x230]
    70f0:      	bl	0x70f0 <_stogir.loops.reorder!+0x180>
		00000000000070f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame
    70f4:      	add	x16, sp, #0x140
    70f8:      	ldr	x0, [x16]
    70fc:      	add	x16, sp, #0x110
    7100:      	str	x0, [x16]
    7104:      	add	x16, sp, #0x140
    7108:      	ldr	x0, [x16, #0x8]
    710c:      	add	x16, sp, #0x110
    7110:      	str	x0, [x16, #0x8]
    7114:      	add	x16, sp, #0x140
    7118:      	ldr	x0, [x16, #0x10]
    711c:      	add	x16, sp, #0x110
    7120:      	str	x0, [x16, #0x10]
    7124:      	add	x16, sp, #0x140
    7128:      	ldr	x0, [x16, #0x18]
    712c:      	add	x16, sp, #0x110
    7130:      	str	x0, [x16, #0x18]
    7134:      	add	x16, sp, #0x140
    7138:      	ldr	x0, [x16, #0x20]
    713c:      	add	x16, sp, #0x110
    7140:      	str	x0, [x16, #0x20]
    7144:      	add	x8, sp, #0x1a0
    7148:      	ldr	x0, [sp, #0x230]
    714c:      	bl	0x714c <_stogir.loops.reorder!+0x1dc>
		000000000000714c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7150:      	add	x16, sp, #0x1a0
    7154:      	ldr	x0, [x16]
    7158:      	add	x16, sp, #0x170
    715c:      	str	x0, [x16]
    7160:      	add	x16, sp, #0x1a0
    7164:      	ldr	x0, [x16, #0x8]
    7168:      	add	x16, sp, #0x170
    716c:      	str	x0, [x16, #0x8]
    7170:      	add	x16, sp, #0x1a0
    7174:      	ldr	x0, [x16, #0x10]
    7178:      	add	x16, sp, #0x170
    717c:      	str	x0, [x16, #0x10]
    7180:      	add	x16, sp, #0x1a0
    7184:      	ldr	x0, [x16, #0x18]
    7188:      	add	x16, sp, #0x170
    718c:      	str	x0, [x16, #0x18]
    7190:      	add	x16, sp, #0x1a0
    7194:      	ldr	x0, [x16, #0x20]
    7198:      	add	x16, sp, #0x170
    719c:      	str	x0, [x16, #0x20]
    71a0:      	ldr	x0, [x28]
    71a4:      	ldr	w19, [x0]
    71a8:      	movn	x0, #0x0, lsl #48
    71ac:      	b	0x71c4 <_stogir.loops.reorder!+0x254>
    71b0:      	add	x16, sp, #0x30
    71b4:      	ldr	x1, [x16]
    71b8:      	add	x1, x1, x0, lsl #2
    71bc:      	movz	w17, #0x0, lsl #16
    71c0:      	str	w17, [x1]
    71c4:      	add	x16, sp, #0x30
    71c8:      	ldr	x1, [x16, #0x8]
    71cc:      	add	x0, x0, #0x1
    71d0:      	cmp	x0, x1
    71d4:      	b.lt	0x71b0 <_stogir.loops.reorder!+0x240>
    71d8:      	add	x0, x25, #0x28
    71dc:      	add	x8, sp, #0x1d0
    71e0:      	bl	0x71e0 <_stogir.loops.reorder!+0x270>
		00000000000071e0:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64
    71e4:      	add	x16, sp, #0x1d0
    71e8:      	ldr	x20, [x16]
    71ec:      	add	x16, sp, #0x1d0
    71f0:      	ldr	x21, [x16, #0x8]
    71f4:      	add	x16, sp, #0x1d0
    71f8:      	ldr	x22, [x16, #0x10]
    71fc:      	b	0x7444 <_stogir.loops.reorder!+0x4d4>
    7200:      	add	x0, sp, #0x30
    7204:      	bl	0x7204 <_stogir.loops.reorder!+0x294>
		0000000000007204:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7208:      	movz	x1, #0x0, lsl #48
    720c:      	movz	x0, #0x0, lsl #48
    7210:      	movz	x2, #0x0, lsl #48
    7214:      	b	0x790c <_stogir.loops.reorder!+0x99c>
    7218:      	movz	w4, #0x0, lsl #16
    721c:      	movz	w5, #0x0, lsl #16
    7220:      	ubfx	x4, x4, #0, #32
    7224:      	lsr	x16, x4, #0
    7228:      	cmp	x16, #0x1
    722c:      	b.eq	0x7248 <_stogir.loops.reorder!+0x2d8>
    7230:      	b.lo	0x7238 <_stogir.loops.reorder!+0x2c8>
    7234:      	b	0x724c <_stogir.loops.reorder!+0x2dc>
    7238:      	cmp	x16, #0x0
    723c:      	b.eq	0x7244 <_stogir.loops.reorder!+0x2d4>
    7240:      	b	0x724c <_stogir.loops.reorder!+0x2dc>
    7244:      	b	0x7298 <_stogir.loops.reorder!+0x328>
    7248:      	b	0x7250 <_stogir.loops.reorder!+0x2e0>
    724c:      	b	0x7acc <_stogir.loops.reorder!+0xb5c>
    7250:      	sxtw	x5, w5
    7254:      	ldr	x4, [x26]
    7258:      	add	x4, x4, x5, lsl #2
    725c:      	ldr	w4, [x4]
    7260:      	sxtw	x4, w4
    7264:      	cmp	x4, #0x0
    7268:      	b.le	0x7270 <_stogir.loops.reorder!+0x300>
    726c:      	add	x2, x2, #0x1
    7270:      	cmp	x3, x1
    7274:      	b.ge	0x7218 <_stogir.loops.reorder!+0x2a8>
    7278:      	add	x4, x3, #0x1
    727c:      	add	x3, x0, x3, lsl #2
    7280:      	ldr	w3, [x3]
    7284:      	movn	w17, #0x0, lsl #16
    7288:      	and	w5, w3, w17
    728c:      	mov	x3, x4
    7290:      	mov	w4, #0x1                ; =1
    7294:      	b	0x7220 <_stogir.loops.reorder!+0x2b0>
    7298:      	ldr	x0, [x28, #0x8]
    729c:      	cmp	x2, x0
    72a0:      	b.ne	0x72d4 <_stogir.loops.reorder!+0x364>
    72a4:      	add	x8, sp, #0x10
    72a8:      	mov	x0, x24
    72ac:      	bl	0x72ac <_stogir.loops.reorder!+0x33c>
		00000000000072ac:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    72b0:      	add	x16, sp, #0x10
    72b4:      	ldr	x0, [x16]
    72b8:      	add	x16, sp, #0x10
    72bc:      	ldr	x1, [x16, #0x8]
    72c0:      	add	x16, sp, #0x10
    72c4:      	ldr	x2, [x16, #0x10]
    72c8:      	movz	x3, #0x0, lsl #48
    72cc:      	movz	x4, #0x0, lsl #48
    72d0:      	b	0x78d4 <_stogir.loops.reorder!+0x964>
    72d4:      	mov	x1, #0x1                ; =1
    72d8:      	adrp	x0, 0x7000 <_stogir.loops.reorder!+0x90>
		00000000000072d8:  ARM64_RELOC_PAGE21	l_stogir.438
    72dc:      	ldr	x0, [x0]
		00000000000072dc:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    72e0:      	mov	x2, #0x32               ; =50
    72e4:      	b	0x791c <_stogir.loops.reorder!+0x9ac>
    72e8:      	movz	w6, #0x0, lsl #16
    72ec:      	movz	x7, #0x0, lsl #48
    72f0:      	ubfx	x6, x6, #0, #32
    72f4:      	lsr	x16, x6, #0
    72f8:      	cmp	x16, #0x1
    72fc:      	b.eq	0x7334 <_stogir.loops.reorder!+0x3c4>
    7300:      	b.lo	0x7308 <_stogir.loops.reorder!+0x398>
    7304:      	b	0x7338 <_stogir.loops.reorder!+0x3c8>
    7308:      	cmp	x16, #0x0
    730c:      	b.eq	0x7314 <_stogir.loops.reorder!+0x3a4>
    7310:      	b	0x7338 <_stogir.loops.reorder!+0x3c8>
    7314:      	mov	x23, x8
    7318:      	mov	x24, x0
    731c:      	mov	x25, x1
    7320:      	mov	x26, x2
    7324:      	mov	x27, x3
    7328:      	mov	x28, x4
    732c:      	str	x5, [sp, #0x230]
    7330:      	b	0x73f4 <_stogir.loops.reorder!+0x484>
    7334:      	b	0x733c <_stogir.loops.reorder!+0x3cc>
    7338:      	b	0x7ac4 <_stogir.loops.reorder!+0xb54>
    733c:      	orr	w6, w7, wzr
    7340:      	ldr	x9, [x2]
    7344:      	sxtw	x10, w6
    7348:      	add	x11, x9, x10, lsl #2
    734c:      	ldr	w11, [x11]
    7350:      	sxtw	x11, w11
    7354:      	cmp	x11, #0x0
    7358:      	b.le	0x7adc <_stogir.loops.reorder!+0xb6c>
    735c:      	lsr	x7, x7, #32
    7360:      	sxtw	x11, w7
    7364:      	add	x9, x9, x11, lsl #2
    7368:      	ldr	w9, [x9]
    736c:      	sxtw	x9, w9
    7370:      	cmp	x9, #0x0
    7374:      	b.le	0x7afc <_stogir.loops.reorder!+0xb8c>
    7378:      	cmp	x10, x11
    737c:      	b.lt	0x7b1c <_stogir.loops.reorder!+0xbac>
    7380:      	mov	x23, x8
    7384:      	mov	x24, x0
    7388:      	mov	x0, x2
    738c:      	mov	x25, x1
    7390:      	mov	w1, w7
    7394:      	mov	x26, x2
    7398:      	mov	w2, w6
    739c:      	mov	x27, x3
    73a0:      	mov	x28, x4
    73a4:      	str	x5, [sp, #0x230]
    73a8:      	bl	0x73a8 <_stogir.loops.reorder!+0x438>
		00000000000073a8:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    73ac:      	cmp	x0, #0x0
    73b0:      	b.ne	0x73b8 <_stogir.loops.reorder!+0x448>
    73b4:      	mov	x21, #0x1               ; =1
    73b8:      	mov	x8, x23
    73bc:      	mov	x0, x24
    73c0:      	mov	x1, x25
    73c4:      	mov	x2, x26
    73c8:      	mov	x3, x27
    73cc:      	mov	x4, x28
    73d0:      	ldr	x5, [sp, #0x230]
    73d4:      	cmp	x22, x20
    73d8:      	b.ge	0x72e8 <_stogir.loops.reorder!+0x378>
    73dc:      	add	x6, x22, #0x1
    73e0:      	add	x7, x19, x22, lsl #4
    73e4:      	ldr	x7, [x7]
    73e8:      	mov	x22, x6
    73ec:      	mov	w6, #0x1                ; =1
    73f0:      	b	0x72f0 <_stogir.loops.reorder!+0x380>
    73f4:      	ldr	x0, [x28, #0x8]
    73f8:      	cmp	x0, #0x0
    73fc:      	b.ne	0x7960 <_stogir.loops.reorder!+0x9f0>
    7400:      	movz	x1, #0x0, lsl #48
    7404:      	movz	x0, #0x0, lsl #48
    7408:      	movz	x2, #0x0, lsl #48
    740c:      	b	0x791c <_stogir.loops.reorder!+0x9ac>
    7410:      	lsl	x1, x1, #1
    7414:      	str	x20, [sp, #0x238]
    7418:      	mov	x20, x0
    741c:      	add	x0, sp, #0xb0
    7420:      	bl	0x7420 <_stogir.loops.reorder!+0x4b0>
		0000000000007420:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    7424:      	add	x0, x20, #0x1
    7428:      	add	x16, sp, #0xb0
    742c:      	ldr	x1, [x16]
    7430:      	add	x1, x1, x20, lsl #3
    7434:      	str	x26, [x1]
    7438:      	add	x16, sp, #0xb0
    743c:      	str	x0, [x16, #0x8]
    7440:      	ldr	x20, [sp, #0x238]
    7444:      	cmp	x22, x21
    7448:      	b.ge	0x7468 <_stogir.loops.reorder!+0x4f8>
    744c:      	add	x0, x22, #0x1
    7450:      	add	x1, x20, x22, lsl #3
    7454:      	ldr	x1, [x1]
    7458:      	orr	x26, x1, xzr
    745c:      	mov	x22, x0
    7460:      	mov	w0, #0x1                ; =1
    7464:      	b	0x7470 <_stogir.loops.reorder!+0x500>
    7468:      	movz	w0, #0x0, lsl #16
    746c:      	movz	x26, #0x0, lsl #48
    7470:      	ubfx	x0, x0, #0, #32
    7474:      	lsr	x16, x0, #0
    7478:      	cmp	x16, #0x1
    747c:      	b.eq	0x7498 <_stogir.loops.reorder!+0x528>
    7480:      	b.lo	0x7488 <_stogir.loops.reorder!+0x518>
    7484:      	b	0x749c <_stogir.loops.reorder!+0x52c>
    7488:      	cmp	x16, #0x0
    748c:      	b.eq	0x7494 <_stogir.loops.reorder!+0x524>
    7490:      	b	0x749c <_stogir.loops.reorder!+0x52c>
    7494:      	b	0x74c8 <_stogir.loops.reorder!+0x558>
    7498:      	b	0x74a0 <_stogir.loops.reorder!+0x530>
    749c:      	b	0x7abc <_stogir.loops.reorder!+0xb4c>
    74a0:      	add	x16, sp, #0xb0
    74a4:      	ldr	x0, [x16, #0x8]
    74a8:      	add	x16, sp, #0xb0
    74ac:      	ldr	x1, [x16, #0x10]
    74b0:      	cmp	x0, x1
    74b4:      	b.lt	0x7b3c <_stogir.loops.reorder!+0xbcc>
    74b8:      	cmp	x1, #0x0
    74bc:      	b.ne	0x7410 <_stogir.loops.reorder!+0x4a0>
    74c0:      	mov	x1, #0x2                ; =2
    74c4:      	b	0x7414 <_stogir.loops.reorder!+0x4a4>
    74c8:      	sxtw	x20, w19
    74cc:      	ldr	x0, [x25]
    74d0:      	add	x0, x0, x20, lsl #4
    74d4:      	ldr	x1, [x0]
    74d8:      	ldr	x0, [x0, #0x8]
    74dc:      	add	x16, sp, #0x1f0
    74e0:      	str	x1, [x16]
    74e4:      	add	x16, sp, #0x1f0
    74e8:      	str	x0, [x16, #0x8]
    74ec:      	add	x0, sp, #0xb0
    74f0:      	add	x1, sp, #0x1f0
    74f4:      	mov	x2, x24
    74f8:      	mov	x3, x27
    74fc:      	bl	0x74fc <_stogir.loops.reorder!+0x58c>
		00000000000074fc:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    7500:      	add	x16, sp, #0x200
    7504:      	movz	x17, #0x0, lsl #48
    7508:      	str	x17, [x16]
    750c:      	add	x16, sp, #0x200
    7510:      	movz	x17, #0x0, lsl #48
    7514:      	str	x17, [x16, #0x8]
    7518:      	add	x16, sp, #0x200
    751c:      	str	w19, [x16]
    7520:      	add	x16, sp, #0x1f0
    7524:      	ldr	x0, [x16, #0x8]
    7528:      	add	x16, sp, #0x200
    752c:      	str	x0, [x16, #0x8]
    7530:      	add	x16, sp, #0x200
    7534:      	ldr	x1, [x16]
    7538:      	mov	x2, x0
    753c:      	add	x0, sp, #0x110
    7540:      	bl	0x7540 <_stogir.loops.reorder!+0x5d0>
		0000000000007540:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame
    7544:      	add	x16, sp, #0x30
    7548:      	ldr	x0, [x16]
    754c:      	add	x0, x0, x20, lsl #2
    7550:      	mov	w17, #0x1               ; =1
    7554:      	str	w17, [x0]
    7558:      	b	0x75ec <_stogir.loops.reorder!+0x67c>
    755c:      	lsl	x0, x0, #1
    7560:      	mov	x1, x0
    7564:      	add	x0, sp, #0x170
    7568:      	bl	0x7568 <_stogir.loops.reorder!+0x5f8>
		0000000000007568:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    756c:      	add	x0, x19, #0x1
    7570:      	add	x16, sp, #0x170
    7574:      	ldr	x1, [x16]
    7578:      	add	x1, x1, x19, lsl #2
    757c:      	str	w21, [x1]
    7580:      	add	x16, sp, #0x170
    7584:      	str	x0, [x16, #0x8]
    7588:      	add	x16, sp, #0x110
    758c:      	ldr	x0, [x16, #0x8]
    7590:      	cmp	x0, #0x0
    7594:      	b.eq	0x75ec <_stogir.loops.reorder!+0x67c>
    7598:      	sub	x0, x0, #0x1
    759c:      	add	x16, sp, #0x110
    75a0:      	str	x0, [x16, #0x8]
    75a4:      	b	0x75ec <_stogir.loops.reorder!+0x67c>
    75a8:      	lsl	x0, x0, #1
    75ac:      	mov	x1, x0
    75b0:      	add	x0, sp, #0x110
    75b4:      	bl	0x75b4 <_stogir.loops.reorder!+0x644>
		00000000000075b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    75b8:      	add	x0, x21, #0x1
    75bc:      	add	x16, sp, #0x110
    75c0:      	ldr	x1, [x16]
    75c4:      	add	x1, x1, x21, lsl #4
    75c8:      	str	x20, [x1]
    75cc:      	str	x19, [x1, #0x8]
    75d0:      	add	x16, sp, #0x110
    75d4:      	str	x0, [x16, #0x8]
    75d8:      	add	x16, sp, #0x30
    75dc:      	ldr	x0, [x16]
    75e0:      	add	x0, x0, x26, lsl #2
    75e4:      	mov	w17, #0x1               ; =1
    75e8:      	str	w17, [x0]
    75ec:      	add	x16, sp, #0x110
    75f0:      	ldr	x0, [x16, #0x8]
    75f4:      	cmp	x0, #0x0
    75f8:      	b.le	0x7784 <_stogir.loops.reorder!+0x814>
    75fc:      	add	x16, sp, #0x110
    7600:      	ldr	x1, [x16]
    7604:      	sub	x19, x0, #0x1
    7608:      	add	x0, x1, x19, lsl #4
    760c:      	ldr	x20, [x0]
    7610:      	orr	w21, w20, wzr
    7614:      	ldr	x0, [x0, #0x8]
    7618:      	sxtw	x1, w21
    761c:      	ldr	x2, [x25]
    7620:      	add	x1, x2, x1, lsl #4
    7624:      	ldr	x1, [x1]
    7628:      	cmp	x0, #0x0
    762c:      	b.ne	0x765c <_stogir.loops.reorder!+0x6ec>
    7630:      	add	x16, sp, #0x170
    7634:      	ldr	x0, [x16, #0x8]
    7638:      	orr	x19, x0, xzr
    763c:      	add	x16, sp, #0x170
    7640:      	ldr	x0, [x16, #0x10]
    7644:      	cmp	x19, x0
    7648:      	b.lt	0x756c <_stogir.loops.reorder!+0x5fc>
    764c:      	cmp	x0, #0x0
    7650:      	b.ne	0x755c <_stogir.loops.reorder!+0x5ec>
    7654:      	mov	x0, #0x2                ; =2
    7658:      	b	0x7560 <_stogir.loops.reorder!+0x5f0>
    765c:      	sub	x21, x0, #0x1
    7660:      	add	x16, sp, #0xb0
    7664:      	ldr	x0, [x16]
    7668:      	add	x2, x21, x1
    766c:      	orr	x3, x0, xzr
    7670:      	orr	x4, x0, xzr
    7674:      	add	x3, x3, x1, lsl #3
    7678:      	add	x0, x0, x1, lsl #3
    767c:      	add	x2, x4, x2, lsl #3
    7680:      	ldr	x3, [x3]
    7684:      	ldr	x4, [x24, #0x50]
    7688:      	add	x3, x4, x3, lsl #4
    768c:      	ldr	x3, [x3]
    7690:      	ldr	x2, [x2]
    7694:      	lsr	x22, x3, #32
    7698:      	str	x2, [x0]
    769c:      	sxtw	x26, w22
    76a0:      	add	x0, sp, #0xb0
    76a4:      	mov	x2, x21
    76a8:      	mov	x4, x24
    76ac:      	mov	x5, x27
    76b0:      	movz	x3, #0x0, lsl #48
    76b4:      	bl	0x76b4 <_stogir.loops.reorder!+0x744>
		00000000000076b4:  ARM64_RELOC_BRANCH26	_stogir.loops.sift!
    76b8:      	add	x16, sp, #0x110
    76bc:      	ldr	x0, [x16]
    76c0:      	add	x0, x0, x19, lsl #4
    76c4:      	str	x20, [x0]
    76c8:      	str	x21, [x0, #0x8]
    76cc:      	add	x16, sp, #0x30
    76d0:      	ldr	x0, [x16]
    76d4:      	add	x0, x0, x26, lsl #2
    76d8:      	ldr	w0, [x0]
    76dc:      	sxtw	x0, w0
    76e0:      	cmp	x0, #0x0
    76e4:      	b.ne	0x75ec <_stogir.loops.reorder!+0x67c>
    76e8:      	ldr	x0, [x25]
    76ec:      	add	x0, x0, x26, lsl #4
    76f0:      	ldr	x1, [x0]
    76f4:      	ldr	x0, [x0, #0x8]
    76f8:      	add	x16, sp, #0x210
    76fc:      	str	x1, [x16]
    7700:      	add	x16, sp, #0x210
    7704:      	str	x0, [x16, #0x8]
    7708:      	add	x0, sp, #0xb0
    770c:      	add	x1, sp, #0x210
    7710:      	mov	x2, x24
    7714:      	mov	x3, x27
    7718:      	bl	0x7718 <_stogir.loops.reorder!+0x7a8>
		0000000000007718:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    771c:      	add	x16, sp, #0x220
    7720:      	movz	x17, #0x0, lsl #48
    7724:      	str	x17, [x16]
    7728:      	add	x16, sp, #0x220
    772c:      	movz	x17, #0x0, lsl #48
    7730:      	str	x17, [x16, #0x8]
    7734:      	add	x16, sp, #0x220
    7738:      	str	w22, [x16]
    773c:      	add	x16, sp, #0x210
    7740:      	ldr	x0, [x16, #0x8]
    7744:      	orr	x19, x0, xzr
    7748:      	add	x16, sp, #0x220
    774c:      	str	x19, [x16, #0x8]
    7750:      	add	x16, sp, #0x220
    7754:      	ldr	x20, [x16]
    7758:      	add	x16, sp, #0x110
    775c:      	ldr	x0, [x16, #0x8]
    7760:      	orr	x21, x0, xzr
    7764:      	add	x16, sp, #0x110
    7768:      	ldr	x0, [x16, #0x10]
    776c:      	cmp	x21, x0
    7770:      	b.lt	0x75b8 <_stogir.loops.reorder!+0x648>
    7774:      	cmp	x0, #0x0
    7778:      	b.ne	0x75a8 <_stogir.loops.reorder!+0x638>
    777c:      	mov	x0, #0x2                ; =2
    7780:      	b	0x75ac <_stogir.loops.reorder!+0x63c>
    7784:      	add	x16, sp, #0x170
    7788:      	ldr	x0, [x16, #0x8]
    778c:      	ldr	x1, [x28, #0x8]
    7790:      	cmp	x0, x1
    7794:      	cset	w19, eq
    7798:      	uxtb	w16, w19
    779c:      	cmp	w16, wzr
    77a0:      	b.eq	0x7810 <_stogir.loops.reorder!+0x8a0>
    77a4:      	movn	x0, #0x0, lsl #48
    77a8:      	movz	x20, #0x0, lsl #48
    77ac:      	b	0x77c0 <_stogir.loops.reorder!+0x850>
    77b0:      	mov	x20, #0x1               ; =1
    77b4:      	ldr	x2, [x28]
    77b8:      	add	x2, x2, x0, lsl #2
    77bc:      	str	w1, [x2]
    77c0:      	ldr	x1, [x28, #0x8]
    77c4:      	add	x0, x0, #0x1
    77c8:      	cmp	x0, x1
    77cc:      	b.ge	0x7814 <_stogir.loops.reorder!+0x8a4>
    77d0:      	add	x16, sp, #0x170
    77d4:      	ldr	x1, [x16, #0x8]
    77d8:      	add	x16, sp, #0x170
    77dc:      	ldr	x2, [x16]
    77e0:      	sub	x1, x1, #0x1
    77e4:      	sub	x1, x1, x0
    77e8:      	add	x1, x2, x1, lsl #2
    77ec:      	ldr	w1, [x1]
    77f0:      	ldr	x2, [x28]
    77f4:      	sxtw	x3, w1
    77f8:      	add	x2, x2, x0, lsl #2
    77fc:      	ldr	w2, [x2]
    7800:      	sxtw	x2, w2
    7804:      	cmp	x2, x3
    7808:      	b.eq	0x77b4 <_stogir.loops.reorder!+0x844>
    780c:      	b	0x77b0 <_stogir.loops.reorder!+0x840>
    7810:      	movz	x20, #0x0, lsl #48
    7814:      	add	x0, sp, #0x30
    7818:      	bl	0x7818 <_stogir.loops.reorder!+0x8a8>
		0000000000007818:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    781c:      	add	x0, sp, #0xb0
    7820:      	bl	0x7820 <_stogir.loops.reorder!+0x8b0>
		0000000000007820:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    7824:      	add	x0, sp, #0x110
    7828:      	bl	0x7828 <_stogir.loops.reorder!+0x8b8>
		0000000000007828:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame
    782c:      	add	x0, sp, #0x170
    7830:      	bl	0x7830 <_stogir.loops.reorder!+0x8c0>
		0000000000007830:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7834:      	uxtb	w16, w19
    7838:      	cmp	w16, wzr
    783c:      	b.eq	0x78fc <_stogir.loops.reorder!+0x98c>
    7840:      	and	x0, x20, #0xff
    7844:      	movz	x1, #0x0, lsl #48
    7848:      	movz	x2, #0x0, lsl #48
    784c:      	b	0x790c <_stogir.loops.reorder!+0x99c>
    7850:      	movz	w5, #0x0, lsl #16
    7854:      	movz	w6, #0x0, lsl #16
    7858:      	ubfx	x5, x5, #0, #32
    785c:      	lsr	x16, x5, #0
    7860:      	cmp	x16, #0x1
    7864:      	b.eq	0x7880 <_stogir.loops.reorder!+0x910>
    7868:      	b.lo	0x7870 <_stogir.loops.reorder!+0x900>
    786c:      	b	0x7884 <_stogir.loops.reorder!+0x914>
    7870:      	cmp	x16, #0x0
    7874:      	b.eq	0x787c <_stogir.loops.reorder!+0x90c>
    7878:      	b	0x7884 <_stogir.loops.reorder!+0x914>
    787c:      	b	0x7910 <_stogir.loops.reorder!+0x9a0>
    7880:      	b	0x7888 <_stogir.loops.reorder!+0x918>
    7884:      	b	0x7ab4 <_stogir.loops.reorder!+0xb44>
    7888:      	sxtw	x5, w6
    788c:      	ldr	x7, [x26]
    7890:      	add	x7, x7, x5, lsl #2
    7894:      	ldr	w7, [x7]
    7898:      	sxtw	x7, w7
    789c:      	cmp	x7, #0x0
    78a0:      	b.le	0x78d4 <_stogir.loops.reorder!+0x964>
    78a4:      	ldr	x7, [x28]
    78a8:      	add	x7, x7, x4, lsl #2
    78ac:      	ldr	w7, [x7]
    78b0:      	sxtw	x7, w7
    78b4:      	cmp	x7, x5
    78b8:      	b.eq	0x78c0 <_stogir.loops.reorder!+0x950>
    78bc:      	mov	x3, #0x1                ; =1
    78c0:      	add	x5, x4, #0x1
    78c4:      	ldr	x7, [x28]
    78c8:      	add	x4, x7, x4, lsl #2
    78cc:      	str	w6, [x4]
    78d0:      	mov	x4, x5
    78d4:      	cmp	x2, x1
    78d8:      	b.ge	0x7850 <_stogir.loops.reorder!+0x8e0>
    78dc:      	add	x5, x2, #0x1
    78e0:      	add	x2, x0, x2, lsl #2
    78e4:      	ldr	w2, [x2]
    78e8:      	movn	w17, #0x0, lsl #16
    78ec:      	and	w6, w2, w17
    78f0:      	mov	x2, x5
    78f4:      	mov	w5, #0x1                ; =1
    78f8:      	b	0x7858 <_stogir.loops.reorder!+0x8e8>
    78fc:      	mov	x1, #0x1                ; =1
    7900:      	adrp	x0, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007900:  ARM64_RELOC_PAGE21	l_stogir.439
    7904:      	ldr	x0, [x0]
		0000000000007904:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    7908:      	mov	x2, #0x33               ; =51
    790c:      	b	0x791c <_stogir.loops.reorder!+0x9ac>
    7910:      	and	x0, x3, #0xff
    7914:      	movz	x1, #0x0, lsl #48
    7918:      	movz	x2, #0x0, lsl #48
    791c:      	str	x1, [x23]
    7920:      	str	x0, [x23, #0x8]
    7924:      	str	x2, [x23, #0x10]
    7928:      	ldr	x19, [sp, #0x240]
    792c:      	ldr	x20, [sp, #0x248]
    7930:      	ldr	x21, [sp, #0x250]
    7934:      	ldr	x22, [sp, #0x258]
    7938:      	ldr	x23, [sp, #0x260]
    793c:      	ldr	x24, [sp, #0x268]
    7940:      	ldr	x25, [sp, #0x270]
    7944:      	ldr	x26, [sp, #0x278]
    7948:      	ldr	x27, [sp, #0x280]
    794c:      	ldr	x28, [sp, #0x288]
    7950:      	ldr	x29, [sp]
    7954:      	ldr	x30, [sp, #0x8]
    7958:      	add	sp, sp, #0x290
    795c:      	ret
    7960:      	cmp	x21, #0x0
    7964:      	b.eq	0x79cc <_stogir.loops.reorder!+0xa5c>
    7968:      	add	x8, sp, #0x60
    796c:      	ldr	x0, [sp, #0x230]
    7970:      	bl	0x7970 <_stogir.loops.reorder!+0xa00>
		0000000000007970:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7974:      	add	x16, sp, #0x60
    7978:      	ldr	x0, [x16]
    797c:      	add	x16, sp, #0x30
    7980:      	str	x0, [x16]
    7984:      	add	x16, sp, #0x60
    7988:      	ldr	x0, [x16, #0x8]
    798c:      	add	x16, sp, #0x30
    7990:      	str	x0, [x16, #0x8]
    7994:      	add	x16, sp, #0x60
    7998:      	ldr	x0, [x16, #0x10]
    799c:      	add	x16, sp, #0x30
    79a0:      	str	x0, [x16, #0x10]
    79a4:      	add	x16, sp, #0x60
    79a8:      	ldr	x0, [x16, #0x18]
    79ac:      	add	x16, sp, #0x30
    79b0:      	str	x0, [x16, #0x18]
    79b4:      	add	x16, sp, #0x60
    79b8:      	ldr	x0, [x16, #0x20]
    79bc:      	add	x16, sp, #0x30
    79c0:      	str	x0, [x16, #0x20]
    79c4:      	movn	x19, #0x0, lsl #48
    79c8:      	b	0x7a78 <_stogir.loops.reorder!+0xb08>
    79cc:      	ldr	x0, [x24]
    79d0:      	ldr	x1, [x24, #0x8]
    79d4:      	movz	x2, #0x0, lsl #48
    79d8:      	movz	x3, #0x0, lsl #48
    79dc:      	b	0x7270 <_stogir.loops.reorder!+0x300>
    79e0:      	orr	w1, w0, wzr
    79e4:      	ldr	x2, [x28]
    79e8:      	add	x2, x2, x0, lsl #2
    79ec:      	ldr	w2, [x2]
    79f0:      	sxtw	x2, w2
    79f4:      	add	x16, sp, #0x30
    79f8:      	ldr	x3, [x16]
    79fc:      	add	x2, x3, x2, lsl #2
    7a00:      	str	w1, [x2]
    7a04:      	ldr	x1, [x28, #0x8]
    7a08:      	add	x0, x0, #0x1
    7a0c:      	cmp	x0, x1
    7a10:      	b.lt	0x79e0 <_stogir.loops.reorder!+0xa70>
    7a14:      	add	x0, x24, #0x50
    7a18:      	add	x8, sp, #0x90
    7a1c:      	bl	0x7a1c <_stogir.loops.reorder!+0xaac>
		0000000000007a1c:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge
    7a20:      	add	x16, sp, #0x90
    7a24:      	ldr	x19, [x16]
    7a28:      	add	x16, sp, #0x90
    7a2c:      	ldr	x20, [x16, #0x8]
    7a30:      	add	x16, sp, #0x90
    7a34:      	ldr	x21, [x16, #0x10]
    7a38:      	mov	x22, #0x1               ; =1
    7a3c:      	b	0x7064 <_stogir.loops.reorder!+0xf4>
    7a40:      	movn	x0, #0x0, lsl #48
    7a44:      	b	0x7a04 <_stogir.loops.reorder!+0xa94>
    7a48:      	lsl	x0, x0, #1
    7a4c:      	mov	x1, x0
    7a50:      	add	x0, sp, #0x30
    7a54:      	bl	0x7a54 <_stogir.loops.reorder!+0xae4>
		0000000000007a54:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    7a58:      	add	x0, x20, #0x1
    7a5c:      	add	x16, sp, #0x30
    7a60:      	ldr	x1, [x16]
    7a64:      	add	x1, x1, x20, lsl #2
    7a68:      	movn	w17, #0x0, lsl #16
    7a6c:      	str	w17, [x1]
    7a70:      	add	x16, sp, #0x30
    7a74:      	str	x0, [x16, #0x8]
    7a78:      	ldr	x0, [x26, #0x8]
    7a7c:      	add	x19, x19, #0x1
    7a80:      	cmp	x19, x0
    7a84:      	b.ge	0x7a40 <_stogir.loops.reorder!+0xad0>
    7a88:      	add	x16, sp, #0x30
    7a8c:      	ldr	x0, [x16, #0x8]
    7a90:      	orr	x20, x0, xzr
    7a94:      	add	x16, sp, #0x30
    7a98:      	ldr	x0, [x16, #0x10]
    7a9c:      	cmp	x20, x0
    7aa0:      	b.lt	0x7a58 <_stogir.loops.reorder!+0xae8>
    7aa4:      	cmp	x0, #0x0
    7aa8:      	b.ne	0x7a48 <_stogir.loops.reorder!+0xad8>
    7aac:      	mov	x0, #0x2                ; =2
    7ab0:      	b	0x7a4c <_stogir.loops.reorder!+0xadc>
    7ab4:      	brk	#0
    7ab8:      	b	0x7ab4 <_stogir.loops.reorder!+0xb44>
    7abc:      	brk	#0
    7ac0:      	b	0x7abc <_stogir.loops.reorder!+0xb4c>
    7ac4:      	brk	#0
    7ac8:      	b	0x7ac4 <_stogir.loops.reorder!+0xb54>
    7acc:      	brk	#0
    7ad0:      	b	0x7acc <_stogir.loops.reorder!+0xb5c>
    7ad4:      	brk	#0
    7ad8:      	b	0x7ad4 <_stogir.loops.reorder!+0xb64>
    7adc:      	mov	x23, x8
    7ae0:      	mov	x24, x0
    7ae4:      	mov	x25, x1
    7ae8:      	mov	x26, x2
    7aec:      	mov	x27, x3
    7af0:      	mov	x28, x4
    7af4:      	str	x5, [sp, #0x230]
    7af8:      	b	0x73b8 <_stogir.loops.reorder!+0x448>
    7afc:      	mov	x23, x8
    7b00:      	mov	x24, x0
    7b04:      	mov	x25, x1
    7b08:      	mov	x26, x2
    7b0c:      	mov	x27, x3
    7b10:      	mov	x28, x4
    7b14:      	str	x5, [sp, #0x230]
    7b18:      	b	0x73b8 <_stogir.loops.reorder!+0x448>
    7b1c:      	mov	x23, x8
    7b20:      	mov	x24, x0
    7b24:      	mov	x25, x1
    7b28:      	mov	x26, x2
    7b2c:      	mov	x27, x3
    7b30:      	mov	x28, x4
    7b34:      	str	x5, [sp, #0x230]
    7b38:      	b	0x73b8 <_stogir.loops.reorder!+0x448>
    7b3c:      	str	x20, [sp, #0x238]
    7b40:      	mov	x20, x0
    7b44:      	b	0x7424 <_stogir.loops.reorder!+0x4b4>

0000000000007b48 <_stogir.schedule.order-with-uses>:
    7b48:      	sub	sp, sp, #0x2a0
    7b4c:      	str	x29, [sp, #0x10]
    7b50:      	str	x30, [sp, #0x18]
    7b54:      	add	x29, sp, #0x10
    7b58:      	str	x19, [sp, #0x248]
    7b5c:      	str	x20, [sp, #0x250]
    7b60:      	str	x21, [sp, #0x258]
    7b64:      	str	x22, [sp, #0x260]
    7b68:      	str	x23, [sp, #0x268]
    7b6c:      	str	x24, [sp, #0x270]
    7b70:      	str	x25, [sp, #0x278]
    7b74:      	str	x26, [sp, #0x280]
    7b78:      	str	x27, [sp, #0x288]
    7b7c:      	str	x28, [sp, #0x290]
    7b80:      	mov	x19, x8
    7b84:      	add	x8, sp, #0x50
    7b88:      	mov	x20, x0
    7b8c:      	mov	x0, x4
    7b90:      	mov	x21, x1
    7b94:      	mov	x22, x2
    7b98:      	mov	x23, x3
    7b9c:      	mov	x24, x4
    7ba0:      	bl	0x7ba0 <_stogir.schedule.order-with-uses+0x58>
		0000000000007ba0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7ba4:      	add	x16, sp, #0x50
    7ba8:      	ldr	x0, [x16]
    7bac:      	add	x16, sp, #0x20
    7bb0:      	str	x0, [x16]
    7bb4:      	add	x16, sp, #0x50
    7bb8:      	ldr	x0, [x16, #0x8]
    7bbc:      	add	x16, sp, #0x20
    7bc0:      	str	x0, [x16, #0x8]
    7bc4:      	add	x16, sp, #0x50
    7bc8:      	ldr	x0, [x16, #0x10]
    7bcc:      	add	x16, sp, #0x20
    7bd0:      	str	x0, [x16, #0x10]
    7bd4:      	add	x16, sp, #0x50
    7bd8:      	ldr	x0, [x16, #0x18]
    7bdc:      	add	x16, sp, #0x20
    7be0:      	str	x0, [x16, #0x18]
    7be4:      	add	x16, sp, #0x50
    7be8:      	ldr	x0, [x16, #0x20]
    7bec:      	add	x16, sp, #0x20
    7bf0:      	str	x0, [x16, #0x20]
    7bf4:      	add	x8, sp, #0xb0
    7bf8:      	mov	x0, x24
    7bfc:      	bl	0x7bfc <_stogir.schedule.order-with-uses+0xb4>
		0000000000007bfc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7c00:      	add	x16, sp, #0xb0
    7c04:      	ldr	x0, [x16]
    7c08:      	add	x16, sp, #0x80
    7c0c:      	str	x0, [x16]
    7c10:      	add	x16, sp, #0xb0
    7c14:      	ldr	x0, [x16, #0x8]
    7c18:      	add	x16, sp, #0x80
    7c1c:      	str	x0, [x16, #0x8]
    7c20:      	add	x16, sp, #0xb0
    7c24:      	ldr	x0, [x16, #0x10]
    7c28:      	add	x16, sp, #0x80
    7c2c:      	str	x0, [x16, #0x10]
    7c30:      	add	x16, sp, #0xb0
    7c34:      	ldr	x0, [x16, #0x18]
    7c38:      	add	x16, sp, #0x80
    7c3c:      	str	x0, [x16, #0x18]
    7c40:      	add	x16, sp, #0xb0
    7c44:      	ldr	x0, [x16, #0x20]
    7c48:      	add	x16, sp, #0x80
    7c4c:      	str	x0, [x16, #0x20]
    7c50:      	add	x8, sp, #0x110
    7c54:      	mov	x0, x24
    7c58:      	bl	0x7c58 <_stogir.schedule.order-with-uses+0x110>
		0000000000007c58:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7c5c:      	add	x16, sp, #0x110
    7c60:      	ldr	x0, [x16]
    7c64:      	add	x16, sp, #0xe0
    7c68:      	str	x0, [x16]
    7c6c:      	add	x16, sp, #0x110
    7c70:      	ldr	x0, [x16, #0x8]
    7c74:      	add	x16, sp, #0xe0
    7c78:      	str	x0, [x16, #0x8]
    7c7c:      	add	x16, sp, #0x110
    7c80:      	ldr	x0, [x16, #0x10]
    7c84:      	add	x16, sp, #0xe0
    7c88:      	str	x0, [x16, #0x10]
    7c8c:      	add	x16, sp, #0x110
    7c90:      	ldr	x0, [x16, #0x18]
    7c94:      	add	x16, sp, #0xe0
    7c98:      	str	x0, [x16, #0x18]
    7c9c:      	add	x16, sp, #0x110
    7ca0:      	ldr	x0, [x16, #0x20]
    7ca4:      	add	x16, sp, #0xe0
    7ca8:      	str	x0, [x16, #0x20]
    7cac:      	add	x8, sp, #0x170
    7cb0:      	mov	x0, x24
    7cb4:      	bl	0x7cb4 <_stogir.schedule.order-with-uses+0x16c>
		0000000000007cb4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7cb8:      	add	x16, sp, #0x170
    7cbc:      	ldr	x0, [x16]
    7cc0:      	add	x16, sp, #0x140
    7cc4:      	str	x0, [x16]
    7cc8:      	add	x16, sp, #0x170
    7ccc:      	ldr	x0, [x16, #0x8]
    7cd0:      	add	x16, sp, #0x140
    7cd4:      	str	x0, [x16, #0x8]
    7cd8:      	add	x16, sp, #0x170
    7cdc:      	ldr	x0, [x16, #0x10]
    7ce0:      	add	x16, sp, #0x140
    7ce4:      	str	x0, [x16, #0x10]
    7ce8:      	add	x16, sp, #0x170
    7cec:      	ldr	x0, [x16, #0x18]
    7cf0:      	add	x16, sp, #0x140
    7cf4:      	str	x0, [x16, #0x18]
    7cf8:      	add	x16, sp, #0x170
    7cfc:      	ldr	x0, [x16, #0x20]
    7d00:      	add	x16, sp, #0x140
    7d04:      	str	x0, [x16, #0x20]
    7d08:      	ldr	x0, [x20, #0x8]
    7d0c:      	mov	x1, x0
    7d10:      	add	x0, sp, #0x80
    7d14:      	bl	0x7d14 <_stogir.schedule.order-with-uses+0x1cc>
		0000000000007d14:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    7d18:      	ldr	x0, [x20, #0x8]
    7d1c:      	mov	x1, x0
    7d20:      	add	x0, sp, #0xe0
    7d24:      	bl	0x7d24 <_stogir.schedule.order-with-uses+0x1dc>
		0000000000007d24:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64
    7d28:      	movz	x25, #0x0, lsl #48
    7d2c:      	b	0x7d64 <_stogir.schedule.order-with-uses+0x21c>
    7d30:      	lsl	x0, x0, #1
    7d34:      	mov	x1, x0
    7d38:      	add	x0, sp, #0x20
    7d3c:      	bl	0x7d3c <_stogir.schedule.order-with-uses+0x1f4>
		0000000000007d3c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    7d40:      	add	x25, x25, #0x1
    7d44:      	add	x0, x26, #0x1
    7d48:      	add	x16, sp, #0x20
    7d4c:      	ldr	x1, [x16]
    7d50:      	add	x1, x1, x26, lsl #3
    7d54:      	movn	x17, #0x0, lsl #48
    7d58:      	str	x17, [x1]
    7d5c:      	add	x16, sp, #0x20
    7d60:      	str	x0, [x16, #0x8]
    7d64:      	ldr	x0, [x20, #0x8]
    7d68:      	cmp	x25, x0
    7d6c:      	b.ge	0x7d9c <_stogir.schedule.order-with-uses+0x254>
    7d70:      	add	x16, sp, #0x20
    7d74:      	ldr	x0, [x16, #0x8]
    7d78:      	orr	x26, x0, xzr
    7d7c:      	add	x16, sp, #0x20
    7d80:      	ldr	x0, [x16, #0x10]
    7d84:      	cmp	x26, x0
    7d88:      	b.lt	0x7d40 <_stogir.schedule.order-with-uses+0x1f8>
    7d8c:      	cmp	x0, #0x0
    7d90:      	b.ne	0x7d30 <_stogir.schedule.order-with-uses+0x1e8>
    7d94:      	mov	x0, #0x2                ; =2
    7d98:      	b	0x7d34 <_stogir.schedule.order-with-uses+0x1ec>
    7d9c:      	mov	x25, #0x1               ; =1
    7da0:      	adrp	x27, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007da0:  ARM64_RELOC_PAGE21	l_stogir.440
    7da4:      	ldr	x27, [x27]
		0000000000007da4:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    7da8:      	movz	x28, #0x0, lsl #48
    7dac:      	movz	x26, #0x0, lsl #48
    7db0:      	b	0x7fcc <_stogir.schedule.order-with-uses+0x484>
    7db4:      	add	x16, sp, #0xe0
    7db8:      	ldr	x0, [x16]
    7dbc:      	orr	x1, x0, xzr
    7dc0:      	add	x1, x1, x19, lsl #3
    7dc4:      	add	x0, x0, x19, lsl #3
    7dc8:      	ldr	x1, [x1]
    7dcc:      	add	x1, x1, #0x1
    7dd0:      	str	x1, [x0]
    7dd4:      	sxtw	x27, w27
    7dd8:      	cmp	x22, #0x43
    7ddc:      	cset	w0, eq
    7de0:      	cmp	x22, #0x83
    7de4:      	cset	w1, lt
    7de8:      	adrp	x17, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007de8:  ARM64_RELOC_PAGE21	l_stogir.441
    7dec:      	ldr	x17, [x17]
		0000000000007dec:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    7df0:      	add	x2, x22, x17
    7df4:      	adrp	x16, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007df4:  ARM64_RELOC_PAGE21	l_stogir.442
    7df8:      	ldr	x16, [x16]
		0000000000007df8:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    7dfc:      	add	x3, x16, x22, lsl #2
    7e00:      	orr	x22, x3, xzr
    7e04:      	mov	x3, #0x1                ; =1
    7e08:      	movz	x4, #0x0, lsl #48
    7e0c:      	b	0x7e80 <_stogir.schedule.order-with-uses+0x338>
    7e10:      	movz	w5, #0x0, lsl #16
    7e14:      	uxtb	w16, w5
    7e18:      	and	w5, w16, #0x2
    7e1c:      	uxtb	w5, w5
    7e20:      	ubfx	x5, x5, #0, #8
    7e24:      	cmp	x5, #0x0
    7e28:      	cset	w5, eq
    7e2c:      	uxtb	w16, w5
    7e30:      	cmp	w16, wzr
    7e34:      	cset	x5, eq
    7e38:      	cmp	x5, #0x0
    7e3c:      	b.eq	0x7e9c <_stogir.schedule.order-with-uses+0x354>
    7e40:      	str	w24, [sp, #0x220]
    7e44:      	mov	x24, x4
    7e48:      	str	w0, [sp, #0x200]
    7e4c:      	str	w1, [sp, #0x208]
    7e50:      	str	x2, [sp, #0x210]
    7e54:      	str	x22, [sp, #0x218]
    7e58:      	mov	x22, x3
    7e5c:      	add	x0, x22, #0x1
    7e60:      	sxtw	x22, w0
    7e64:      	ldr	w0, [sp, #0x200]
    7e68:      	ldr	w1, [sp, #0x208]
    7e6c:      	ldr	x2, [sp, #0x210]
    7e70:      	mov	x3, x22
    7e74:      	ldr	x22, [sp, #0x218]
    7e78:      	mov	x4, x24
    7e7c:      	ldr	w24, [sp, #0x220]
    7e80:      	cmp	x3, x27
    7e84:      	b.gt	0x867c <_stogir.schedule.order-with-uses+0xb34>
    7e88:      	uxtb	w16, w1
    7e8c:      	cmp	w16, wzr
    7e90:      	b.eq	0x7e10 <_stogir.schedule.order-with-uses+0x2c8>
    7e94:      	ldrb	w5, [x2]
    7e98:      	b	0x7e14 <_stogir.schedule.order-with-uses+0x2cc>
    7e9c:      	orr	w5, w3, wzr
    7ea0:      	sxtw	x6, w5
    7ea4:      	uxtb	w16, w0
    7ea8:      	cmp	w16, wzr
    7eac:      	b.eq	0x7ed8 <_stogir.schedule.order-with-uses+0x390>
    7eb0:      	cmp	x6, #0x2
    7eb4:      	b.lt	0x7ed8 <_stogir.schedule.order-with-uses+0x390>
    7eb8:      	str	w24, [sp, #0x220]
    7ebc:      	mov	x24, x4
    7ec0:      	str	w0, [sp, #0x200]
    7ec4:      	str	w1, [sp, #0x208]
    7ec8:      	str	x2, [sp, #0x210]
    7ecc:      	str	x22, [sp, #0x218]
    7ed0:      	mov	x22, x3
    7ed4:      	b	0x7e5c <_stogir.schedule.order-with-uses+0x314>
    7ed8:      	uxtb	w16, w1
    7edc:      	cmp	w16, wzr
    7ee0:      	b.eq	0x7f08 <_stogir.schedule.order-with-uses+0x3c0>
    7ee4:      	ldr	w7, [x22]
    7ee8:      	cmp	x6, #0x0
    7eec:      	b.le	0x7f00 <_stogir.schedule.order-with-uses+0x3b8>
    7ef0:      	cmp	x6, #0x4
    7ef4:      	b.le	0x861c <_stogir.schedule.order-with-uses+0xad4>
    7ef8:      	mov	w6, #0x4                ; =4
    7efc:      	b	0x8620 <_stogir.schedule.order-with-uses+0xad8>
    7f00:      	movz	w6, #0x0, lsl #16
    7f04:      	b	0x7f0c <_stogir.schedule.order-with-uses+0x3c4>
    7f08:      	movz	w6, #0x0, lsl #16
    7f0c:      	ubfx	x6, x6, #0, #32
    7f10:      	cmp	x6, #0xf
    7f14:      	b.hs	0x8684 <_stogir.schedule.order-with-uses+0xb3c>
    7f18:      	mov	x16, #0x1               ; =1
    7f1c:      	lsl	x6, x16, x6
    7f20:      	mov	w17, #0x5e1c            ; =24092
    7f24:      	and	w6, w6, w17
    7f28:      	ubfx	x6, x6, #0, #32
    7f2c:      	cmp	x6, #0x0
    7f30:      	b.eq	0x86a4 <_stogir.schedule.order-with-uses+0xb5c>
    7f34:      	str	w0, [sp, #0x200]
    7f38:      	mov	x0, x20
    7f3c:      	str	w1, [sp, #0x208]
    7f40:      	mov	w1, w24
    7f44:      	str	x2, [sp, #0x210]
    7f48:      	mov	w2, w5
    7f4c:      	str	x22, [sp, #0x218]
    7f50:      	mov	x22, x3
    7f54:      	str	w24, [sp, #0x220]
    7f58:      	mov	x24, x4
    7f5c:      	bl	0x7f5c <_stogir.schedule.order-with-uses+0x414>
		0000000000007f5c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    7f60:      	ubfx	x0, x0, #0, #32
    7f64:      	lsr	x16, x0, #0
    7f68:      	cmp	x16, #0x1
    7f6c:      	b.eq	0x7f88 <_stogir.schedule.order-with-uses+0x440>
    7f70:      	b.lo	0x7f78 <_stogir.schedule.order-with-uses+0x430>
    7f74:      	b	0x7f8c <_stogir.schedule.order-with-uses+0x444>
    7f78:      	cmp	x16, #0x0
    7f7c:      	b.eq	0x7f84 <_stogir.schedule.order-with-uses+0x43c>
    7f80:      	b	0x7f8c <_stogir.schedule.order-with-uses+0x444>
    7f84:      	b	0x7f90 <_stogir.schedule.order-with-uses+0x448>
    7f88:      	b	0x8634 <_stogir.schedule.order-with-uses+0xaec>
    7f8c:      	b	0x8674 <_stogir.schedule.order-with-uses+0xb2c>
    7f90:      	adrp	x16, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007f90:  ARM64_RELOC_PAGE21	l_stogir.443
    7f94:      	ldr	x16, [x16]
		0000000000007f94:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    7f98:      	str	x16, [sp, #0x1f0]
    7f9c:      	mov	x28, #0x19              ; =25
    7fa0:      	b	0x865c <_stogir.schedule.order-with-uses+0xb14>
    7fa4:      	add	x26, x26, #0x1
    7fa8:      	add	x16, sp, #0x20
    7fac:      	ldr	x0, [x16]
    7fb0:      	add	x0, x0, x25, lsl #3
    7fb4:      	str	x24, [x0]
    7fb8:      	add	x25, x25, #0x1
    7fbc:      	ldr	x19, [sp, #0x1e8]
    7fc0:      	ldr	x22, [sp, #0x1f8]
    7fc4:      	ldr	x24, [sp, #0x1e0]
    7fc8:      	ldr	x27, [sp, #0x1f0]
    7fcc:      	cmp	x28, #0x0
    7fd0:      	b.ne	0x86c4 <_stogir.schedule.order-with-uses+0xb7c>
    7fd4:      	add	x16, sp, #0x20
    7fd8:      	ldr	x0, [x16, #0x8]
    7fdc:      	cmp	x25, x0
    7fe0:      	b.ge	0x86d8 <_stogir.schedule.order-with-uses+0xb90>
    7fe4:      	orr	w0, w25, wzr
    7fe8:      	mov	w1, w0
    7fec:      	str	x24, [sp, #0x1e0]
    7ff0:      	mov	w24, w0
    7ff4:      	mov	x0, x20
    7ff8:      	bl	0x7ff8 <_stogir.schedule.order-with-uses+0x4b0>
		0000000000007ff8:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
    7ffc:      	cmp	x0, #0x0
    8000:      	b.eq	0x86ec <_stogir.schedule.order-with-uses+0xba4>
    8004:      	ldr	x0, [x22]
    8008:      	add	x0, x25, x0
    800c:      	ldrb	w0, [x0]
    8010:      	cmp	x0, #0x0
    8014:      	b.eq	0x86fc <_stogir.schedule.order-with-uses+0xbb4>
    8018:      	ldr	x0, [x21]
    801c:      	add	x0, x0, x25, lsl #2
    8020:      	ldr	w0, [x0]
    8024:      	sxtw	x0, w0
    8028:      	ldr	x1, [x20]
    802c:      	add	x1, x1, x25, lsl #4
    8030:      	ldr	x1, [x1]
    8034:      	ldr	x2, [x20, #0x78]
    8038:      	add	x2, x2, x25, lsl #2
    803c:      	ldr	w2, [x2]
    8040:      	cmp	x0, #0x0
    8044:      	b.gt	0x8064 <_stogir.schedule.order-with-uses+0x51c>
    8048:      	str	x19, [sp, #0x1e8]
    804c:      	str	x22, [sp, #0x1f8]
    8050:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		0000000000008050:  ARM64_RELOC_PAGE21	l_stogir.444
    8054:      	ldr	x16, [x16]
		0000000000008054:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    8058:      	str	x16, [sp, #0x1f0]
    805c:      	mov	x28, #0x19              ; =25
    8060:      	b	0x7fb8 <_stogir.schedule.order-with-uses+0x470>
    8064:      	uxtb	w1, w1
    8068:      	orr	x3, x1, xzr
    806c:      	str	x19, [sp, #0x1e8]
    8070:      	mov	x19, x0
    8074:      	mov	w0, w3
    8078:      	str	x27, [sp, #0x1f0]
    807c:      	mov	w27, w2
    8080:      	str	x22, [sp, #0x1f8]
    8084:      	mov	w22, w1
    8088:      	bl	0x8088 <_stogir.schedule.order-with-uses+0x540>
		0000000000008088:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    808c:      	cmp	x0, #0x0
    8090:      	b.eq	0x7db4 <_stogir.schedule.order-with-uses+0x26c>
    8094:      	add	x16, sp, #0x80
    8098:      	ldr	x0, [x16]
    809c:      	add	x1, x0, x19, lsl #2
    80a0:      	ldr	w1, [x1]
    80a4:      	sxtw	x1, w1
    80a8:      	cmp	x1, #0x0
    80ac:      	b.ne	0x8660 <_stogir.schedule.order-with-uses+0xb18>
    80b0:      	add	x0, x0, x19, lsl #2
    80b4:      	str	w24, [x0]
    80b8:      	b	0x8670 <_stogir.schedule.order-with-uses+0xb28>
    80bc:      	lsl	x3, x3, #1
    80c0:      	str	x0, [sp, #0x228]
    80c4:      	add	x0, sp, #0x140
    80c8:      	str	x6, [sp, #0x1f8]
    80cc:      	str	w19, [sp, #0x230]
    80d0:      	mov	x19, x1
    80d4:      	mov	x1, x3
    80d8:      	str	x20, [sp, #0x238]
    80dc:      	mov	w20, w4
    80e0:      	str	x21, [sp, #0x240]
    80e4:      	mov	x21, x2
    80e8:      	bl	0x80e8 <_stogir.schedule.order-with-uses+0x5a0>
		00000000000080e8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    80ec:      	add	x0, x21, #0x1
    80f0:      	add	x16, sp, #0x140
    80f4:      	ldr	x1, [x16]
    80f8:      	add	x1, x1, x21, lsl #2
    80fc:      	str	w20, [x1]
    8100:      	add	x16, sp, #0x140
    8104:      	str	x0, [x16, #0x8]
    8108:      	b	0x8280 <_stogir.schedule.order-with-uses+0x738>
    810c:      	mov	x19, #0x1               ; =1
    8110:      	b	0x8148 <_stogir.schedule.order-with-uses+0x600>
    8114:      	nop
    8118:      	lsl	x0, x0, #1
    811c:      	mov	x1, x0
    8120:      	add	x0, sp, #0x140
    8124:      	bl	0x8124 <_stogir.schedule.order-with-uses+0x5dc>
		0000000000008124:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8128:      	add	x0, x24, #0x1
    812c:      	add	x16, sp, #0x140
    8130:      	ldr	x1, [x16]
    8134:      	add	x1, x1, x24, lsl #2
    8138:      	str	w22, [x1]
    813c:      	add	x16, sp, #0x140
    8140:      	str	x0, [x16, #0x8]
    8144:      	add	x19, x19, #0x1
    8148:      	add	x16, sp, #0x20
    814c:      	ldr	x0, [x16, #0x8]
    8150:      	cmp	x19, x0
    8154:      	b.ge	0x8210 <_stogir.schedule.order-with-uses+0x6c8>
    8158:      	add	x16, sp, #0x20
    815c:      	ldr	x0, [x16]
    8160:      	orr	x1, x0, xzr
    8164:      	add	x2, x1, x19, lsl #3
    8168:      	ldr	x2, [x2]
    816c:      	cmp	x2, #0x0
    8170:      	b.lt	0x8144 <_stogir.schedule.order-with-uses+0x5fc>
    8174:      	orr	w22, w19, wzr
    8178:      	ldr	x2, [x21]
    817c:      	sxtw	x3, w22
    8180:      	add	x2, x2, x19, lsl #2
    8184:      	ldr	w2, [x2]
    8188:      	sxtw	x2, w2
    818c:      	add	x16, sp, #0x80
    8190:      	ldr	x4, [x16]
    8194:      	add	x4, x4, x2, lsl #2
    8198:      	ldr	w4, [x4]
    819c:      	sxtw	x4, w4
    81a0:      	cmp	x4, x3
    81a4:      	b.ne	0x81cc <_stogir.schedule.order-with-uses+0x684>
    81a8:      	add	x1, x1, x19, lsl #3
    81ac:      	add	x0, x0, x19, lsl #3
    81b0:      	ldr	x1, [x1]
    81b4:      	add	x16, sp, #0xe0
    81b8:      	ldr	x3, [x16]
    81bc:      	add	x2, x3, x2, lsl #3
    81c0:      	ldr	x2, [x2]
    81c4:      	add	x1, x2, x1
    81c8:      	str	x1, [x0]
    81cc:      	add	x16, sp, #0x20
    81d0:      	ldr	x0, [x16]
    81d4:      	add	x0, x0, x19, lsl #3
    81d8:      	ldr	x0, [x0]
    81dc:      	cmp	x0, #0x0
    81e0:      	b.ne	0x8144 <_stogir.schedule.order-with-uses+0x5fc>
    81e4:      	add	x16, sp, #0x140
    81e8:      	ldr	x0, [x16, #0x8]
    81ec:      	orr	x24, x0, xzr
    81f0:      	add	x16, sp, #0x140
    81f4:      	ldr	x0, [x16, #0x10]
    81f8:      	cmp	x24, x0
    81fc:      	b.lt	0x8128 <_stogir.schedule.order-with-uses+0x5e0>
    8200:      	cmp	x0, #0x0
    8204:      	b.ne	0x8118 <_stogir.schedule.order-with-uses+0x5d0>
    8208:      	mov	x0, #0x2                ; =2
    820c:      	b	0x811c <_stogir.schedule.order-with-uses+0x5d4>
    8210:      	cmp	x28, #0x0
    8214:      	cset	w19, eq
    8218:      	movz	x22, #0x0, lsl #48
    821c:      	b	0x83cc <_stogir.schedule.order-with-uses+0x884>
    8220:      	sub	w2, w2, #0x1
    8224:      	lsl	w2, w2, #2
    8228:      	ubfx	x2, x2, #0, #32
    822c:      	lsr	x2, x3, x2
    8230:      	and	w2, w2, #0xf
    8234:      	b	0x845c <_stogir.schedule.order-with-uses+0x914>
    8238:      	movz	w8, #0x0, lsl #16
    823c:      	uxtb	w16, w8
    8240:      	and	w8, w16, #0x2
    8244:      	uxtb	w8, w8
    8248:      	ubfx	x8, x8, #0, #8
    824c:      	cmp	x8, #0x0
    8250:      	cset	w8, eq
    8254:      	uxtb	w16, w8
    8258:      	cmp	w16, wzr
    825c:      	cset	x8, eq
    8260:      	cmp	x8, #0x0
    8264:      	b.eq	0x8320 <_stogir.schedule.order-with-uses+0x7d8>
    8268:      	str	x20, [sp, #0x238]
    826c:      	str	x21, [sp, #0x240]
    8270:      	str	x6, [sp, #0x1f8]
    8274:      	str	x0, [sp, #0x228]
    8278:      	str	w19, [sp, #0x230]
    827c:      	mov	x19, x1
    8280:      	add	x19, x19, #0x1
    8284:      	ldr	x20, [sp, #0x238]
    8288:      	ldr	x21, [sp, #0x240]
    828c:      	ldr	x0, [sp, #0x228]
    8290:      	mov	x1, x19
    8294:      	ldr	w19, [sp, #0x230]
    8298:      	cmp	x1, x0
    829c:      	b.ge	0x870c <_stogir.schedule.order-with-uses+0xbc4>
    82a0:      	add	x2, x27, x1
    82a4:      	ldr	x3, [x23, #0x28]
    82a8:      	add	x2, x3, x2, lsl #3
    82ac:      	ldr	x2, [x2]
    82b0:      	ldr	x3, [x20]
    82b4:      	orr	w4, w2, wzr
    82b8:      	sxtw	x5, w4
    82bc:      	add	x3, x3, x5, lsl #4
    82c0:      	ldr	x3, [x3]
    82c4:      	ldr	x6, [sp, #0x1f8]
    82c8:      	ldr	x7, [x6]
    82cc:      	add	x7, x7, x5
    82d0:      	ldrb	w7, [x7]
    82d4:      	cmp	x7, #0x0
    82d8:      	b.eq	0x871c <_stogir.schedule.order-with-uses+0xbd4>
    82dc:      	ldr	x7, [x21]
    82e0:      	add	x7, x7, x5, lsl #2
    82e4:      	ldr	w7, [x7]
    82e8:      	sxtw	x7, w7
    82ec:      	cmp	x7, x25
    82f0:      	b.ne	0x8738 <_stogir.schedule.order-with-uses+0xbf0>
    82f4:      	uxtb	w3, w3
    82f8:      	cmp	x3, #0x83
    82fc:      	cset	w7, lt
    8300:      	uxtb	w16, w7
    8304:      	cmp	w16, wzr
    8308:      	b.eq	0x8238 <_stogir.schedule.order-with-uses+0x6f0>
    830c:      	adrp	x17, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		000000000000830c:  ARM64_RELOC_PAGE21	l_stogir.441
    8310:      	ldr	x17, [x17]
		0000000000008310:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    8314:      	add	x8, x3, x17
    8318:      	ldrb	w8, [x8]
    831c:      	b	0x823c <_stogir.schedule.order-with-uses+0x6f4>
    8320:      	lsr	x2, x2, #32
    8324:      	sxtw	x8, w2
    8328:      	cmp	x3, #0x43
    832c:      	b.ne	0x8424 <_stogir.schedule.order-with-uses+0x8dc>
    8330:      	cmp	x8, #0x2
    8334:      	b.lt	0x8424 <_stogir.schedule.order-with-uses+0x8dc>
    8338:      	str	x20, [sp, #0x238]
    833c:      	str	x21, [sp, #0x240]
    8340:      	str	x6, [sp, #0x1f8]
    8344:      	str	x0, [sp, #0x228]
    8348:      	str	w19, [sp, #0x230]
    834c:      	mov	x19, x1
    8350:      	b	0x8280 <_stogir.schedule.order-with-uses+0x738>
    8354:      	add	x16, sp, #0x80
    8358:      	ldr	x0, [x16]
    835c:      	add	x0, x0, x25, lsl #2
    8360:      	ldr	w0, [x0]
    8364:      	sxtw	x1, w0
    8368:      	cmp	x1, #0x0
    836c:      	b.le	0x83bc <_stogir.schedule.order-with-uses+0x874>
    8370:      	cmp	x1, x24
    8374:      	b.eq	0x83bc <_stogir.schedule.order-with-uses+0x874>
    8378:      	add	x16, sp, #0x20
    837c:      	ldr	x2, [x16]
    8380:      	orr	x3, x2, xzr
    8384:      	add	x3, x3, x1, lsl #3
    8388:      	add	x2, x2, x1, lsl #3
    838c:      	ldr	x3, [x3]
    8390:      	sub	x3, x3, #0x1
    8394:      	str	x3, [x2]
    8398:      	add	x16, sp, #0x20
    839c:      	ldr	x2, [x16]
    83a0:      	add	x1, x2, x1, lsl #3
    83a4:      	ldr	x1, [x1]
    83a8:      	cmp	x1, #0x0
    83ac:      	b.ne	0x83bc <_stogir.schedule.order-with-uses+0x874>
    83b0:      	mov	w1, w0
    83b4:      	add	x0, sp, #0x140
    83b8:      	bl	0x83b8 <_stogir.schedule.order-with-uses+0x870>
		00000000000083b8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    83bc:      	add	x22, x22, #0x1
    83c0:      	ldr	x20, [sp, #0x238]
    83c4:      	ldr	x21, [sp, #0x240]
    83c8:      	ldr	w19, [sp, #0x230]
    83cc:      	uxtb	w16, w19
    83d0:      	cmp	w16, wzr
    83d4:      	b.eq	0x8754 <_stogir.schedule.order-with-uses+0xc0c>
    83d8:      	add	x16, sp, #0x140
    83dc:      	ldr	x0, [x16, #0x8]
    83e0:      	cmp	x22, x0
    83e4:      	b.ge	0x875c <_stogir.schedule.order-with-uses+0xc14>
    83e8:      	add	x16, sp, #0x140
    83ec:      	ldr	x0, [x16]
    83f0:      	add	x0, x0, x22, lsl #2
    83f4:      	ldr	w0, [x0]
    83f8:      	sxtw	x24, w0
    83fc:      	ldr	x0, [x21]
    8400:      	add	x0, x0, x24, lsl #2
    8404:      	ldr	w0, [x0]
    8408:      	sxtw	x25, w0
    840c:      	ldr	x0, [x23]
    8410:      	add	x0, x0, x24, lsl #4
    8414:      	ldr	x27, [x0]
    8418:      	ldr	x0, [x0, #0x8]
    841c:      	movz	x1, #0x0, lsl #48
    8420:      	b	0x8298 <_stogir.schedule.order-with-uses+0x750>
    8424:      	uxtb	w16, w7
    8428:      	cmp	w16, wzr
    842c:      	b.eq	0x8460 <_stogir.schedule.order-with-uses+0x918>
    8430:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		0000000000008430:  ARM64_RELOC_PAGE21	l_stogir.442
    8434:      	ldr	x16, [x16]
		0000000000008434:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8438:      	add	x3, x16, x3, lsl #2
    843c:      	ldr	w3, [x3]
    8440:      	cmp	x8, #0x0
    8444:      	b.le	0x8458 <_stogir.schedule.order-with-uses+0x910>
    8448:      	cmp	x8, #0x4
    844c:      	b.le	0x8220 <_stogir.schedule.order-with-uses+0x6d8>
    8450:      	mov	w2, #0x4                ; =4
    8454:      	b	0x8224 <_stogir.schedule.order-with-uses+0x6dc>
    8458:      	movz	w2, #0x0, lsl #16
    845c:      	b	0x8464 <_stogir.schedule.order-with-uses+0x91c>
    8460:      	movz	w2, #0x0, lsl #16
    8464:      	ubfx	x2, x2, #0, #32
    8468:      	cmp	x2, #0xf
    846c:      	b.hs	0x8764 <_stogir.schedule.order-with-uses+0xc1c>
    8470:      	mov	x16, #0x1               ; =1
    8474:      	lsl	x2, x16, x2
    8478:      	mov	w17, #0x5e1c            ; =24092
    847c:      	and	w2, w2, w17
    8480:      	ubfx	x2, x2, #0, #32
    8484:      	cmp	x2, #0x0
    8488:      	b.eq	0x8780 <_stogir.schedule.order-with-uses+0xc38>
    848c:      	add	x16, sp, #0x20
    8490:      	ldr	x2, [x16]
    8494:      	orr	x3, x2, xzr
    8498:      	add	x3, x3, x5, lsl #3
    849c:      	add	x2, x2, x5, lsl #3
    84a0:      	ldr	x3, [x3]
    84a4:      	sub	x3, x3, #0x1
    84a8:      	str	x3, [x2]
    84ac:      	add	x16, sp, #0x20
    84b0:      	ldr	x2, [x16]
    84b4:      	add	x2, x2, x5, lsl #3
    84b8:      	ldr	x2, [x2]
    84bc:      	cmp	x2, #0x0
    84c0:      	b.ne	0x879c <_stogir.schedule.order-with-uses+0xc54>
    84c4:      	add	x16, sp, #0x140
    84c8:      	ldr	x2, [x16, #0x8]
    84cc:      	add	x16, sp, #0x140
    84d0:      	ldr	x3, [x16, #0x10]
    84d4:      	cmp	x2, x3
    84d8:      	b.lt	0x87b8 <_stogir.schedule.order-with-uses+0xc70>
    84dc:      	cmp	x3, #0x0
    84e0:      	b.ne	0x80bc <_stogir.schedule.order-with-uses+0x574>
    84e4:      	mov	x3, #0x2                ; =2
    84e8:      	b	0x80c0 <_stogir.schedule.order-with-uses+0x578>
    84ec:      	add	x0, sp, #0x20
    84f0:      	bl	0x84f0 <_stogir.schedule.order-with-uses+0x9a8>
		00000000000084f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    84f4:      	add	x0, sp, #0x80
    84f8:      	bl	0x84f8 <_stogir.schedule.order-with-uses+0x9b0>
		00000000000084f8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    84fc:      	add	x0, sp, #0xe0
    8500:      	bl	0x8500 <_stogir.schedule.order-with-uses+0x9b8>
		0000000000008500:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    8504:      	ldr	x0, [sp, #0x1f0]
    8508:      	mov	x1, x28
    850c:      	adrp	x2, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		000000000000850c:  ARM64_RELOC_PAGE21	l_stogir.440
    8510:      	ldr	x2, [x2]
		0000000000008510:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    8514:      	movz	x3, #0x0, lsl #48
    8518:      	bl	0x8518 <_stogir.schedule.order-with-uses+0x9d0>
		0000000000008518:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    851c:      	cmp	x0, #0x0
    8520:      	b.eq	0x8544 <_stogir.schedule.order-with-uses+0x9fc>
    8524:      	add	x0, sp, #0x140
    8528:      	bl	0x8528 <_stogir.schedule.order-with-uses+0x9e0>
		0000000000008528:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    852c:      	cmp	x0, x26
    8530:      	b.eq	0x8544 <_stogir.schedule.order-with-uses+0x9fc>
    8534:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		0000000000008534:  ARM64_RELOC_PAGE21	l_stogir.445
    8538:      	ldr	x16, [x16]
		0000000000008538:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    853c:      	str	x16, [sp, #0x1f0]
    8540:      	mov	x28, #0x16              ; =22
    8544:      	ldr	x0, [sp, #0x1f0]
    8548:      	mov	x1, x28
    854c:      	adrp	x2, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		000000000000854c:  ARM64_RELOC_PAGE21	l_stogir.440
    8550:      	ldr	x2, [x2]
		0000000000008550:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    8554:      	movz	x3, #0x0, lsl #48
    8558:      	bl	0x8558 <_stogir.schedule.order-with-uses+0xa10>
		0000000000008558:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    855c:      	cmp	x0, #0x0
    8560:      	b.eq	0x87dc <_stogir.schedule.order-with-uses+0xc94>
    8564:      	add	x8, sp, #0x1a0
    8568:      	ldr	x0, [sp, #0x238]
    856c:      	add	x1, sp, #0x140
    8570:      	ldr	x2, [sp, #0x1e0]
    8574:      	bl	0x8574 <_stogir.schedule.order-with-uses+0xa2c>
		0000000000008574:  ARM64_RELOC_BRANCH26	_stogir.schedule.entry-prefix
    8578:      	add	x16, sp, #0x1a0
    857c:      	ldr	x19, [x16]
    8580:      	add	x16, sp, #0x1a0
    8584:      	ldr	x28, [x16, #0x8]
    8588:      	add	x16, sp, #0x1a0
    858c:      	ldr	x20, [x16, #0x10]
    8590:      	add	x16, sp, #0x1a0
    8594:      	ldr	x21, [x16, #0x18]
    8598:      	add	x16, sp, #0x1a0
    859c:      	ldr	x22, [x16, #0x20]
    85a0:      	add	x0, sp, #0x140
    85a4:      	bl	0x85a4 <_stogir.schedule.order-with-uses+0xa5c>
		00000000000085a4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    85a8:      	movz	x0, #0x0, lsl #48
    85ac:      	b	0x85c8 <_stogir.schedule.order-with-uses+0xa80>
    85b0:      	add	x0, sp, #0x140
    85b4:      	bl	0x85b4 <_stogir.schedule.order-with-uses+0xa6c>
		00000000000085b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    85b8:      	mov	x0, #0x1                ; =1
    85bc:      	movz	x20, #0x0, lsl #48
    85c0:      	movz	x21, #0x0, lsl #48
    85c4:      	movz	x22, #0x0, lsl #48
    85c8:      	ldr	x1, [sp, #0x1e8]
    85cc:      	str	x0, [x1]
    85d0:      	str	x19, [x1, #0x8]
    85d4:      	str	x28, [x1, #0x10]
    85d8:      	str	x20, [x1, #0x18]
    85dc:      	str	x21, [x1, #0x20]
    85e0:      	str	x22, [x1, #0x28]
    85e4:      	ldr	x19, [sp, #0x248]
    85e8:      	ldr	x20, [sp, #0x250]
    85ec:      	ldr	x21, [sp, #0x258]
    85f0:      	ldr	x22, [sp, #0x260]
    85f4:      	ldr	x23, [sp, #0x268]
    85f8:      	ldr	x24, [sp, #0x270]
    85fc:      	ldr	x25, [sp, #0x278]
    8600:      	ldr	x26, [sp, #0x280]
    8604:      	ldr	x27, [sp, #0x288]
    8608:      	ldr	x28, [sp, #0x290]
    860c:      	ldr	x29, [sp, #0x10]
    8610:      	ldr	x30, [sp, #0x18]
    8614:      	add	sp, sp, #0x2a0
    8618:      	ret
    861c:      	sub	w6, w5, #0x1
    8620:      	lsl	w6, w6, #2
    8624:      	ubfx	x6, x6, #0, #32
    8628:      	lsr	x6, x7, x6
    862c:      	and	w6, w6, #0xf
    8630:      	b	0x7f04 <_stogir.schedule.order-with-uses+0x3bc>
    8634:      	sxtw	x1, w1
    8638:      	cmp	x1, #0x0
    863c:      	b.le	0x865c <_stogir.schedule.order-with-uses+0xb14>
    8640:      	ldr	x0, [x21]
    8644:      	add	x0, x0, x1, lsl #2
    8648:      	ldr	w0, [x0]
    864c:      	sxtw	x0, w0
    8650:      	cmp	x0, x19
    8654:      	b.ne	0x865c <_stogir.schedule.order-with-uses+0xb14>
    8658:      	add	x24, x24, #0x1
    865c:      	b	0x7e5c <_stogir.schedule.order-with-uses+0x314>
    8660:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		0000000000008660:  ARM64_RELOC_PAGE21	l_stogir.446
    8664:      	ldr	x16, [x16]
		0000000000008664:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    8668:      	str	x16, [sp, #0x1f0]
    866c:      	mov	x28, #0x13              ; =19
    8670:      	b	0x7dd4 <_stogir.schedule.order-with-uses+0x28c>
    8674:      	brk	#0
    8678:      	b	0x8674 <_stogir.schedule.order-with-uses+0xb2c>
    867c:      	mov	x24, x4
    8680:      	b	0x7fa4 <_stogir.schedule.order-with-uses+0x45c>
    8684:      	str	w24, [sp, #0x220]
    8688:      	mov	x24, x4
    868c:      	str	w0, [sp, #0x200]
    8690:      	str	w1, [sp, #0x208]
    8694:      	str	x2, [sp, #0x210]
    8698:      	str	x22, [sp, #0x218]
    869c:      	mov	x22, x3
    86a0:      	b	0x7e5c <_stogir.schedule.order-with-uses+0x314>
    86a4:      	str	w24, [sp, #0x220]
    86a8:      	mov	x24, x4
    86ac:      	str	w0, [sp, #0x200]
    86b0:      	str	w1, [sp, #0x208]
    86b4:      	str	x2, [sp, #0x210]
    86b8:      	str	x22, [sp, #0x218]
    86bc:      	mov	x22, x3
    86c0:      	b	0x7e5c <_stogir.schedule.order-with-uses+0x314>
    86c4:      	str	x19, [sp, #0x1e8]
    86c8:      	str	x22, [sp, #0x1f8]
    86cc:      	str	x24, [sp, #0x1e0]
    86d0:      	str	x27, [sp, #0x1f0]
    86d4:      	b	0x810c <_stogir.schedule.order-with-uses+0x5c4>
    86d8:      	str	x19, [sp, #0x1e8]
    86dc:      	str	x22, [sp, #0x1f8]
    86e0:      	str	x24, [sp, #0x1e0]
    86e4:      	str	x27, [sp, #0x1f0]
    86e8:      	b	0x810c <_stogir.schedule.order-with-uses+0x5c4>
    86ec:      	str	x19, [sp, #0x1e8]
    86f0:      	str	x22, [sp, #0x1f8]
    86f4:      	str	x27, [sp, #0x1f0]
    86f8:      	b	0x7fb8 <_stogir.schedule.order-with-uses+0x470>
    86fc:      	str	x19, [sp, #0x1e8]
    8700:      	str	x22, [sp, #0x1f8]
    8704:      	str	x27, [sp, #0x1f0]
    8708:      	b	0x7fb8 <_stogir.schedule.order-with-uses+0x470>
    870c:      	str	x20, [sp, #0x238]
    8710:      	str	x21, [sp, #0x240]
    8714:      	str	w19, [sp, #0x230]
    8718:      	b	0x8354 <_stogir.schedule.order-with-uses+0x80c>
    871c:      	str	x20, [sp, #0x238]
    8720:      	str	x21, [sp, #0x240]
    8724:      	str	x6, [sp, #0x1f8]
    8728:      	str	x0, [sp, #0x228]
    872c:      	str	w19, [sp, #0x230]
    8730:      	mov	x19, x1
    8734:      	b	0x8280 <_stogir.schedule.order-with-uses+0x738>
    8738:      	str	x20, [sp, #0x238]
    873c:      	str	x21, [sp, #0x240]
    8740:      	str	x6, [sp, #0x1f8]
    8744:      	str	x0, [sp, #0x228]
    8748:      	str	w19, [sp, #0x230]
    874c:      	mov	x19, x1
    8750:      	b	0x8280 <_stogir.schedule.order-with-uses+0x738>
    8754:      	str	x20, [sp, #0x238]
    8758:      	b	0x84ec <_stogir.schedule.order-with-uses+0x9a4>
    875c:      	str	x20, [sp, #0x238]
    8760:      	b	0x84ec <_stogir.schedule.order-with-uses+0x9a4>
    8764:      	str	x20, [sp, #0x238]
    8768:      	str	x21, [sp, #0x240]
    876c:      	str	x6, [sp, #0x1f8]
    8770:      	str	x0, [sp, #0x228]
    8774:      	str	w19, [sp, #0x230]
    8778:      	mov	x19, x1
    877c:      	b	0x8280 <_stogir.schedule.order-with-uses+0x738>
    8780:      	str	x20, [sp, #0x238]
    8784:      	str	x21, [sp, #0x240]
    8788:      	str	x6, [sp, #0x1f8]
    878c:      	str	x0, [sp, #0x228]
    8790:      	str	w19, [sp, #0x230]
    8794:      	mov	x19, x1
    8798:      	b	0x8280 <_stogir.schedule.order-with-uses+0x738>
    879c:      	str	x20, [sp, #0x238]
    87a0:      	str	x21, [sp, #0x240]
    87a4:      	str	x6, [sp, #0x1f8]
    87a8:      	str	x0, [sp, #0x228]
    87ac:      	str	w19, [sp, #0x230]
    87b0:      	mov	x19, x1
    87b4:      	b	0x8280 <_stogir.schedule.order-with-uses+0x738>
    87b8:      	str	x20, [sp, #0x238]
    87bc:      	str	x21, [sp, #0x240]
    87c0:      	str	x6, [sp, #0x1f8]
    87c4:      	str	x0, [sp, #0x228]
    87c8:      	mov	w20, w4
    87cc:      	mov	x21, x2
    87d0:      	str	w19, [sp, #0x230]
    87d4:      	mov	x19, x1
    87d8:      	b	0x80ec <_stogir.schedule.order-with-uses+0x5a4>
    87dc:      	ldr	x19, [sp, #0x1f0]
    87e0:      	b	0x85b0 <_stogir.schedule.order-with-uses+0xa68>
    87e4:      	udf	#0x0

00000000000087e8 <_stogir.schedule.pack>:
    87e8:      	sub	sp, sp, #0xd0
    87ec:      	str	x29, [sp]
    87f0:      	str	x30, [sp, #0x8]
    87f4:      	mov	x29, sp
    87f8:      	str	x19, [sp, #0x90]
    87fc:      	str	x20, [sp, #0x98]
    8800:      	str	x21, [sp, #0xa0]
    8804:      	str	x22, [sp, #0xa8]
    8808:      	str	x23, [sp, #0xb0]
    880c:      	str	x24, [sp, #0xb8]
    8810:      	str	x25, [sp, #0xc0]
    8814:      	str	x26, [sp, #0xc8]
    8818:      	ldr	x4, [x3]
    881c:      	ldr	x3, [x3, #0x8]
    8820:      	add	x16, sp, #0x10
    8824:      	movz	x17, #0x0, lsl #48
    8828:      	str	x17, [x16]
    882c:      	add	x16, sp, #0x10
    8830:      	movz	x17, #0x0, lsl #48
    8834:      	str	x17, [x16, #0x8]
    8838:      	add	x16, sp, #0x10
    883c:      	movz	x17, #0x0, lsl #48
    8840:      	str	x17, [x16, #0x10]
    8844:      	add	x16, sp, #0x10
    8848:      	str	x4, [x16, #0x18]
    884c:      	add	x16, sp, #0x10
    8850:      	str	x3, [x16, #0x20]
    8854:      	add	x16, sp, #0x10
    8858:      	movz	x17, #0x0, lsl #48
    885c:      	str	x17, [x16, #0x28]
    8860:      	add	x16, sp, #0x10
    8864:      	movz	x17, #0x0, lsl #48
    8868:      	str	x17, [x16, #0x30]
    886c:      	add	x16, sp, #0x10
    8870:      	movz	x17, #0x0, lsl #48
    8874:      	str	x17, [x16, #0x38]
    8878:      	add	x16, sp, #0x10
    887c:      	str	x4, [x16, #0x40]
    8880:      	add	x16, sp, #0x10
    8884:      	str	x3, [x16, #0x48]
    8888:      	add	x16, sp, #0x60
    888c:      	movz	x17, #0x0, lsl #48
    8890:      	str	x17, [x16]
    8894:      	add	x16, sp, #0x60
    8898:      	movz	x17, #0x0, lsl #48
    889c:      	str	x17, [x16, #0x8]
    88a0:      	add	x16, sp, #0x60
    88a4:      	movz	x17, #0x0, lsl #48
    88a8:      	str	x17, [x16, #0x10]
    88ac:      	add	x16, sp, #0x60
    88b0:      	str	x4, [x16, #0x18]
    88b4:      	add	x16, sp, #0x60
    88b8:      	str	x3, [x16, #0x20]
    88bc:      	ldr	x3, [x1, #0x8]
    88c0:      	orr	x19, x3, xzr
    88c4:      	cmp	x19, #0x0
    88c8:      	b.le	0x8d84 <_stogir.schedule.pack+0x59c>
    88cc:      	cmp	x19, #0x0
    88d0:      	b.ge	0x88dc <_stogir.schedule.pack+0xf4>
    88d4:      	movz	x3, #0x0, lsl #48
    88d8:      	b	0x88e0 <_stogir.schedule.pack+0xf8>
    88dc:      	mov	x3, x19
    88e0:      	mov	x20, x8
    88e4:      	mov	x21, x0
    88e8:      	add	x0, sp, #0x10
    88ec:      	mov	x22, x1
    88f0:      	mov	x1, x3
    88f4:      	mov	x23, x2
    88f8:      	bl	0x88f8 <_stogir.schedule.pack+0x110>
		00000000000088f8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range
    88fc:      	add	x16, sp, #0x10
    8900:      	orr	x24, x16, xzr
    8904:      	lsl	x0, x19, #4
    8908:      	add	x16, sp, #0x10
    890c:      	ldr	x1, [x16]
    8910:      	mov	x2, x0
    8914:      	mov	x0, x1
    8918:      	movz	x1, #0x0, lsl #48
    891c:      	bl	0x891c <_stogir.schedule.pack+0x134>
		000000000000891c:  ARM64_RELOC_BRANCH26	_memset
    8920:      	add	x16, sp, #0x10
    8924:      	str	x19, [x16, #0x8]
    8928:      	ldr	x0, [x22, #0x8]
    892c:      	orr	x19, x0, xzr
    8930:      	add	x16, sp, #0x60
    8934:      	ldr	x0, [x16, #0x8]
    8938:      	orr	x25, x0, xzr
    893c:      	add	x16, sp, #0x60
    8940:      	ldr	x0, [x16, #0x10]
    8944:      	add	x26, x25, x19
    8948:      	cmp	x26, x0
    894c:      	b.le	0x8980 <_stogir.schedule.pack+0x198>
    8950:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    8954:      	cmp	x0, x17
    8958:      	b.gt	0x8964 <_stogir.schedule.pack+0x17c>
    895c:      	lsl	x0, x0, #1
    8960:      	b	0x8968 <_stogir.schedule.pack+0x180>
    8964:      	mov	x0, x26
    8968:      	cmp	x0, x26
    896c:      	b.gt	0x8974 <_stogir.schedule.pack+0x18c>
    8970:      	mov	x0, x26
    8974:      	mov	x1, x0
    8978:      	add	x0, sp, #0x60
    897c:      	bl	0x897c <_stogir.schedule.pack+0x194>
		000000000000897c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    8980:      	lsl	x0, x19, #3
    8984:      	add	x16, sp, #0x60
    8988:      	ldr	x1, [x16]
    898c:      	add	x1, x1, x25, lsl #3
    8990:      	mov	x2, x0
    8994:      	mov	x0, x1
    8998:      	movz	x1, #0x0, lsl #48
    899c:      	bl	0x899c <_stogir.schedule.pack+0x1b4>
		000000000000899c:  ARM64_RELOC_BRANCH26	_memset
    89a0:      	add	x16, sp, #0x60
    89a4:      	str	x26, [x16, #0x8]
    89a8:      	ldr	x0, [x21]
    89ac:      	ldr	x1, [x21, #0x8]
    89b0:      	movz	x2, #0x0, lsl #48
    89b4:      	b	0x8a2c <_stogir.schedule.pack+0x244>
    89b8:      	movz	w3, #0x0, lsl #16
    89bc:      	movz	w4, #0x0, lsl #16
    89c0:      	ubfx	x3, x3, #0, #32
    89c4:      	lsr	x16, x3, #0
    89c8:      	cmp	x16, #0x1
    89cc:      	b.eq	0x89e8 <_stogir.schedule.pack+0x200>
    89d0:      	b.lo	0x89d8 <_stogir.schedule.pack+0x1f0>
    89d4:      	b	0x89ec <_stogir.schedule.pack+0x204>
    89d8:      	cmp	x16, #0x0
    89dc:      	b.eq	0x89e4 <_stogir.schedule.pack+0x1fc>
    89e0:      	b	0x89ec <_stogir.schedule.pack+0x204>
    89e4:      	b	0x8a54 <_stogir.schedule.pack+0x26c>
    89e8:      	b	0x89f0 <_stogir.schedule.pack+0x208>
    89ec:      	b	0x8d7c <_stogir.schedule.pack+0x594>
    89f0:      	sxtw	x4, w4
    89f4:      	ldr	x3, [x22]
    89f8:      	add	x3, x3, x4, lsl #2
    89fc:      	ldr	w3, [x3]
    8a00:      	sxtw	x3, w3
    8a04:      	add	x16, sp, #0x10
    8a08:      	ldr	x4, [x16]
    8a0c:      	orr	x5, x4, xzr
    8a10:      	add	x5, x5, x3, lsl #4
    8a14:      	add	x3, x4, x3, lsl #4
    8a18:      	ldr	x4, [x5]
    8a1c:      	ldr	x5, [x5, #0x8]
    8a20:      	add	x5, x5, #0x1
    8a24:      	str	x4, [x3]
    8a28:      	str	x5, [x3, #0x8]
    8a2c:      	cmp	x2, x1
    8a30:      	b.ge	0x89b8 <_stogir.schedule.pack+0x1d0>
    8a34:      	add	x3, x2, #0x1
    8a38:      	add	x2, x0, x2, lsl #2
    8a3c:      	ldr	w2, [x2]
    8a40:      	movn	w17, #0x0, lsl #16
    8a44:      	and	w4, w2, w17
    8a48:      	mov	x2, x3
    8a4c:      	mov	w3, #0x1                ; =1
    8a50:      	b	0x89c0 <_stogir.schedule.pack+0x1d8>
    8a54:      	ldr	x0, [x23]
    8a58:      	ldr	x1, [x23, #0x8]
    8a5c:      	movz	x2, #0x0, lsl #48
    8a60:      	movz	x3, #0x0, lsl #48
    8a64:      	b	0x8adc <_stogir.schedule.pack+0x2f4>
    8a68:      	movz	w4, #0x0, lsl #16
    8a6c:      	movz	w5, #0x0, lsl #16
    8a70:      	ubfx	x4, x4, #0, #32
    8a74:      	lsr	x16, x4, #0
    8a78:      	cmp	x16, #0x1
    8a7c:      	b.eq	0x8a98 <_stogir.schedule.pack+0x2b0>
    8a80:      	b.lo	0x8a88 <_stogir.schedule.pack+0x2a0>
    8a84:      	b	0x8a9c <_stogir.schedule.pack+0x2b4>
    8a88:      	cmp	x16, #0x0
    8a8c:      	b.eq	0x8a94 <_stogir.schedule.pack+0x2ac>
    8a90:      	b	0x8a9c <_stogir.schedule.pack+0x2b4>
    8a94:      	b	0x8b04 <_stogir.schedule.pack+0x31c>
    8a98:      	b	0x8aa0 <_stogir.schedule.pack+0x2b8>
    8a9c:      	b	0x8d74 <_stogir.schedule.pack+0x58c>
    8aa0:      	sxtw	x5, w5
    8aa4:      	add	x16, sp, #0x10
    8aa8:      	ldr	x4, [x16]
    8aac:      	orr	x6, x4, xzr
    8ab0:      	add	x6, x6, x5, lsl #4
    8ab4:      	add	x4, x4, x5, lsl #4
    8ab8:      	ldr	x6, [x6, #0x8]
    8abc:      	add	x7, x6, x2
    8ac0:      	str	x2, [x4]
    8ac4:      	str	x6, [x4, #0x8]
    8ac8:      	add	x16, sp, #0x60
    8acc:      	ldr	x4, [x16]
    8ad0:      	add	x4, x4, x5, lsl #3
    8ad4:      	str	x2, [x4]
    8ad8:      	mov	x2, x7
    8adc:      	cmp	x3, x1
    8ae0:      	b.ge	0x8a68 <_stogir.schedule.pack+0x280>
    8ae4:      	add	x4, x3, #0x1
    8ae8:      	add	x3, x0, x3, lsl #2
    8aec:      	ldr	w3, [x3]
    8af0:      	movn	w17, #0x0, lsl #16
    8af4:      	and	w5, w3, w17
    8af8:      	mov	x3, x4
    8afc:      	mov	w4, #0x1                ; =1
    8b00:      	b	0x8a70 <_stogir.schedule.pack+0x288>
    8b04:      	add	x19, x24, #0x28
    8b08:      	ldr	x0, [x21, #0x8]
    8b0c:      	orr	x23, x0, xzr
    8b10:      	ldr	x0, [x19, #0x8]
    8b14:      	orr	x24, x0, xzr
    8b18:      	ldr	x0, [x19, #0x10]
    8b1c:      	add	x25, x24, x23
    8b20:      	cmp	x25, x0
    8b24:      	b.le	0x8b58 <_stogir.schedule.pack+0x370>
    8b28:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    8b2c:      	cmp	x0, x17
    8b30:      	b.gt	0x8b3c <_stogir.schedule.pack+0x354>
    8b34:      	lsl	x0, x0, #1
    8b38:      	b	0x8b40 <_stogir.schedule.pack+0x358>
    8b3c:      	mov	x0, x25
    8b40:      	cmp	x0, x25
    8b44:      	b.gt	0x8b4c <_stogir.schedule.pack+0x364>
    8b48:      	mov	x0, x25
    8b4c:      	mov	x1, x0
    8b50:      	mov	x0, x19
    8b54:      	bl	0x8b54 <_stogir.schedule.pack+0x36c>
		0000000000008b54:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8b58:      	lsl	x0, x23, #2
    8b5c:      	add	x16, sp, #0x10
    8b60:      	ldr	x1, [x16, #0x28]
    8b64:      	add	x1, x1, x24, lsl #2
    8b68:      	mov	x2, x0
    8b6c:      	mov	x0, x1
    8b70:      	movz	x1, #0x0, lsl #48
    8b74:      	bl	0x8b74 <_stogir.schedule.pack+0x38c>
		0000000000008b74:  ARM64_RELOC_BRANCH26	_memset
    8b78:      	str	x25, [x19, #0x8]
    8b7c:      	ldr	x0, [x21]
    8b80:      	ldr	x1, [x21, #0x8]
    8b84:      	movz	x2, #0x0, lsl #48
    8b88:      	b	0x8c10 <_stogir.schedule.pack+0x428>
    8b8c:      	nop
    8b90:      	movz	w3, #0x0, lsl #16
    8b94:      	movz	w4, #0x0, lsl #16
    8b98:      	ubfx	x3, x3, #0, #32
    8b9c:      	lsr	x16, x3, #0
    8ba0:      	cmp	x16, #0x1
    8ba4:      	b.eq	0x8bc0 <_stogir.schedule.pack+0x3d8>
    8ba8:      	b.lo	0x8bb0 <_stogir.schedule.pack+0x3c8>
    8bac:      	b	0x8bc4 <_stogir.schedule.pack+0x3dc>
    8bb0:      	cmp	x16, #0x0
    8bb4:      	b.eq	0x8bbc <_stogir.schedule.pack+0x3d4>
    8bb8:      	b	0x8bc4 <_stogir.schedule.pack+0x3dc>
    8bbc:      	b	0x8c38 <_stogir.schedule.pack+0x450>
    8bc0:      	b	0x8bc8 <_stogir.schedule.pack+0x3e0>
    8bc4:      	b	0x8d6c <_stogir.schedule.pack+0x584>
    8bc8:      	sxtw	x3, w4
    8bcc:      	ldr	x5, [x22]
    8bd0:      	add	x3, x5, x3, lsl #2
    8bd4:      	ldr	w3, [x3]
    8bd8:      	sxtw	x3, w3
    8bdc:      	add	x16, sp, #0x60
    8be0:      	ldr	x5, [x16]
    8be4:      	add	x5, x5, x3, lsl #3
    8be8:      	ldr	x5, [x5]
    8bec:      	add	x16, sp, #0x10
    8bf0:      	ldr	x6, [x16, #0x28]
    8bf4:      	add	x7, x5, #0x1
    8bf8:      	add	x5, x6, x5, lsl #2
    8bfc:      	str	w4, [x5]
    8c00:      	add	x16, sp, #0x60
    8c04:      	ldr	x4, [x16]
    8c08:      	add	x3, x4, x3, lsl #3
    8c0c:      	str	x7, [x3]
    8c10:      	cmp	x2, x1
    8c14:      	b.ge	0x8b90 <_stogir.schedule.pack+0x3a8>
    8c18:      	add	x3, x2, #0x1
    8c1c:      	add	x2, x0, x2, lsl #2
    8c20:      	ldr	w2, [x2]
    8c24:      	movn	w17, #0x0, lsl #16
    8c28:      	and	w4, w2, w17
    8c2c:      	mov	x2, x3
    8c30:      	mov	w3, #0x1                ; =1
    8c34:      	b	0x8b98 <_stogir.schedule.pack+0x3b0>
    8c38:      	b	0x8c4c <_stogir.schedule.pack+0x464>
    8c3c:      	nop
    8c40:      	sub	x0, x0, #0x1
    8c44:      	add	x16, sp, #0x60
    8c48:      	str	x0, [x16, #0x8]
    8c4c:      	add	x16, sp, #0x60
    8c50:      	ldr	x0, [x16, #0x8]
    8c54:      	cmp	x0, #0x0
    8c58:      	b.ne	0x8c40 <_stogir.schedule.pack+0x458>
    8c5c:      	add	x16, sp, #0x60
    8c60:      	orr	x0, x16, xzr
    8c64:      	add	x16, sp, #0x60
    8c68:      	ldr	x1, [x16, #0x10]
    8c6c:      	cmp	x1, #0x0
    8c70:      	b.le	0x8ca0 <_stogir.schedule.pack+0x4b8>
    8c74:      	add	x0, x0, #0x18
    8c78:      	add	x16, sp, #0x60
    8c7c:      	ldr	x2, [x16]
    8c80:      	fmov	d31, x1
    8c84:      	mov	x1, x2
    8c88:      	fmov	x2, d31
    8c8c:      	adrp	x3, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		0000000000008c8c:  ARM64_RELOC_PAGE21	l_stogir.447
    8c90:      	ldr	x3, [x3]
		0000000000008c90:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    8c94:      	mov	x4, #0x8                ; =8
    8c98:      	mov	x5, #0x8                ; =8
    8c9c:      	bl	0x8c9c <_stogir.schedule.pack+0x4b4>
		0000000000008c9c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    8ca0:      	add	x16, sp, #0x60
    8ca4:      	movz	x17, #0x0, lsl #48
    8ca8:      	str	x17, [x16]
    8cac:      	add	x16, sp, #0x60
    8cb0:      	movz	x17, #0x0, lsl #48
    8cb4:      	str	x17, [x16, #0x8]
    8cb8:      	add	x16, sp, #0x60
    8cbc:      	movz	x17, #0x0, lsl #48
    8cc0:      	str	x17, [x16, #0x10]
    8cc4:      	add	x16, sp, #0x10
    8cc8:      	ldr	x0, [x16]
    8ccc:      	add	x16, sp, #0x10
    8cd0:      	ldr	x1, [x16, #0x8]
    8cd4:      	add	x16, sp, #0x10
    8cd8:      	ldr	x2, [x16, #0x10]
    8cdc:      	add	x16, sp, #0x10
    8ce0:      	ldr	x3, [x16, #0x18]
    8ce4:      	add	x16, sp, #0x10
    8ce8:      	ldr	x4, [x16, #0x20]
    8cec:      	add	x16, sp, #0x10
    8cf0:      	ldr	x5, [x16, #0x28]
    8cf4:      	add	x16, sp, #0x10
    8cf8:      	ldr	x6, [x16, #0x30]
    8cfc:      	add	x16, sp, #0x10
    8d00:      	ldr	x7, [x16, #0x38]
    8d04:      	add	x16, sp, #0x10
    8d08:      	ldr	x8, [x16, #0x40]
    8d0c:      	add	x16, sp, #0x10
    8d10:      	ldr	x9, [x16, #0x48]
    8d14:      	str	x0, [x20]
    8d18:      	str	x1, [x20, #0x8]
    8d1c:      	str	x2, [x20, #0x10]
    8d20:      	str	x3, [x20, #0x18]
    8d24:      	str	x4, [x20, #0x20]
    8d28:      	str	x5, [x20, #0x28]
    8d2c:      	str	x6, [x20, #0x30]
    8d30:      	str	x7, [x20, #0x38]
    8d34:      	str	x8, [x20, #0x40]
    8d38:      	str	x9, [x20, #0x48]
    8d3c:      	ldr	x19, [sp, #0x90]
    8d40:      	ldr	x20, [sp, #0x98]
    8d44:      	ldr	x21, [sp, #0xa0]
    8d48:      	ldr	x22, [sp, #0xa8]
    8d4c:      	ldr	x23, [sp, #0xb0]
    8d50:      	ldr	x24, [sp, #0xb8]
    8d54:      	ldr	x25, [sp, #0xc0]
    8d58:      	ldr	x26, [sp, #0xc8]
    8d5c:      	ldr	x29, [sp]
    8d60:      	ldr	x30, [sp, #0x8]
    8d64:      	add	sp, sp, #0xd0
    8d68:      	ret
    8d6c:      	brk	#0
    8d70:      	b	0x8d6c <_stogir.schedule.pack+0x584>
    8d74:      	brk	#0
    8d78:      	b	0x8d74 <_stogir.schedule.pack+0x58c>
    8d7c:      	brk	#0
    8d80:      	b	0x8d7c <_stogir.schedule.pack+0x594>
    8d84:      	mov	x20, x8
    8d88:      	mov	x21, x0
    8d8c:      	mov	x22, x1
    8d90:      	mov	x23, x2
    8d94:      	b	0x88fc <_stogir.schedule.pack+0x114>

0000000000008d98 <_stogir.checked-schedule.cluster!>:
    8d98:      	sub	sp, sp, #0x230
    8d9c:      	str	x29, [sp]
    8da0:      	str	x30, [sp, #0x8]
    8da4:      	mov	x29, sp
    8da8:      	str	x19, [sp, #0x1d8]
    8dac:      	str	x20, [sp, #0x1e0]
    8db0:      	str	x21, [sp, #0x1e8]
    8db4:      	str	x22, [sp, #0x1f0]
    8db8:      	str	x23, [sp, #0x1f8]
    8dbc:      	str	x24, [sp, #0x200]
    8dc0:      	str	x25, [sp, #0x208]
    8dc4:      	str	x26, [sp, #0x210]
    8dc8:      	str	x27, [sp, #0x218]
    8dcc:      	str	x28, [sp, #0x220]
    8dd0:      	add	x16, sp, #0x10
    8dd4:      	orr	x4, x16, xzr
    8dd8:      	add	x19, x2, #0x28
    8ddc:      	add	x20, x4, #0x8
    8de0:      	ldr	x4, [x2, #0x28]
    8de4:      	ldr	x5, [x19, #0x8]
    8de8:      	orr	x21, x4, xzr
    8dec:      	orr	x22, x5, xzr
    8df0:      	movz	x23, #0x0, lsl #48
    8df4:      	adrp	x24, 0x8000 <_stogir.schedule.order-with-uses+0x4b8>
		0000000000008df4:  ARM64_RELOC_PAGE21	l_stogir.448
    8df8:      	ldr	x24, [x24]
		0000000000008df8:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    8dfc:      	movz	x25, #0x0, lsl #48
    8e00:      	movz	x26, #0x0, lsl #48
    8e04:      	b	0x8e44 <_stogir.checked-schedule.cluster!+0xac>
    8e08:      	add	x16, sp, #0x10
    8e0c:      	ldr	w0, [x16, #0x8]
    8e10:      	sxtw	x0, w0
    8e14:      	cmp	x0, #0x0
    8e18:      	b.eq	0x8e24 <_stogir.checked-schedule.cluster!+0x8c>
    8e1c:      	add	x0, x23, #0x1
    8e20:      	sxtw	x23, w0
    8e24:      	mov	x8, x27
    8e28:      	mov	x0, x28
    8e2c:      	mov	x1, x21
    8e30:      	mov	x2, x22
    8e34:      	mov	x3, x26
    8e38:      	ldr	x22, [sp, #0x198]
    8e3c:      	ldr	x21, [sp, #0x190]
    8e40:      	ldr	x26, [sp, #0x1a0]
    8e44:      	cmp	x26, x22
    8e48:      	b.ge	0x8e6c <_stogir.checked-schedule.cluster!+0xd4>
    8e4c:      	add	x4, x26, #0x1
    8e50:      	add	x5, x21, x26, lsl #2
    8e54:      	ldr	w5, [x5]
    8e58:      	movn	w17, #0x0, lsl #16
    8e5c:      	and	w5, w5, w17
    8e60:      	mov	x26, x4
    8e64:      	mov	w4, #0x1                ; =1
    8e68:      	b	0x8e74 <_stogir.checked-schedule.cluster!+0xdc>
    8e6c:      	movz	w4, #0x0, lsl #16
    8e70:      	movz	w5, #0x0, lsl #16
    8e74:      	ubfx	x4, x4, #0, #32
    8e78:      	lsr	x16, x4, #0
    8e7c:      	cmp	x16, #0x1
    8e80:      	b.eq	0x8eb0 <_stogir.checked-schedule.cluster!+0x118>
    8e84:      	b.lo	0x8e8c <_stogir.checked-schedule.cluster!+0xf4>
    8e88:      	b	0x8eb4 <_stogir.checked-schedule.cluster!+0x11c>
    8e8c:      	cmp	x16, #0x0
    8e90:      	b.eq	0x8e98 <_stogir.checked-schedule.cluster!+0x100>
    8e94:      	b	0x8eb4 <_stogir.checked-schedule.cluster!+0x11c>
    8e98:      	mov	x27, x8
    8e9c:      	mov	x28, x0
    8ea0:      	mov	x21, x1
    8ea4:      	mov	x22, x2
    8ea8:      	mov	x26, x3
    8eac:      	b	0x8f44 <_stogir.checked-schedule.cluster!+0x1ac>
    8eb0:      	b	0x8eb8 <_stogir.checked-schedule.cluster!+0x120>
    8eb4:      	b	0x9700 <_stogir.checked-schedule.cluster!+0x968>
    8eb8:      	sxtw	x4, w5
    8ebc:      	ldr	x6, [x0]
    8ec0:      	add	x4, x6, x4, lsl #4
    8ec4:      	ldr	x4, [x4]
    8ec8:      	uxtb	w4, w4
    8ecc:      	cmp	x4, #0x2c
    8ed0:      	b.ne	0x9728 <_stogir.checked-schedule.cluster!+0x990>
    8ed4:      	mov	x27, x8
    8ed8:      	add	x8, sp, #0x10
    8edc:      	mov	x28, x0
    8ee0:      	str	x21, [sp, #0x190]
    8ee4:      	mov	x21, x1
    8ee8:      	mov	w1, w5
    8eec:      	str	x22, [sp, #0x198]
    8ef0:      	mov	x22, x2
    8ef4:      	str	x26, [sp, #0x1a0]
    8ef8:      	mov	x26, x3
    8efc:      	bl	0x8efc <_stogir.checked-schedule.cluster!+0x164>
		0000000000008efc:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    8f00:      	add	x16, sp, #0x10
    8f04:      	ldr	w0, [x16]
    8f08:      	lsr	x16, x0, #0
    8f0c:      	cmp	x16, #0x1
    8f10:      	b.eq	0x8f2c <_stogir.checked-schedule.cluster!+0x194>
    8f14:      	b.lo	0x8f1c <_stogir.checked-schedule.cluster!+0x184>
    8f18:      	b	0x8f30 <_stogir.checked-schedule.cluster!+0x198>
    8f1c:      	cmp	x16, #0x0
    8f20:      	b.eq	0x8f28 <_stogir.checked-schedule.cluster!+0x190>
    8f24:      	b	0x8f30 <_stogir.checked-schedule.cluster!+0x198>
    8f28:      	b	0x8e08 <_stogir.checked-schedule.cluster!+0x70>
    8f2c:      	b	0x8f34 <_stogir.checked-schedule.cluster!+0x19c>
    8f30:      	b	0x9718 <_stogir.checked-schedule.cluster!+0x980>
    8f34:      	add	x16, sp, #0x10
    8f38:      	ldr	x24, [x16, #0x8]
    8f3c:      	ldr	x25, [x20, #0x8]
    8f40:      	b	0x8e24 <_stogir.checked-schedule.cluster!+0x8c>
    8f44:      	cmp	x25, #0x0
    8f48:      	b.ne	0x8f80 <_stogir.checked-schedule.cluster!+0x1e8>
    8f4c:      	cmp	x23, #0x0
    8f50:      	b.ne	0x9560 <_stogir.checked-schedule.cluster!+0x7c8>
    8f54:      	add	x8, sp, #0x30
    8f58:      	mov	x0, x28
    8f5c:      	mov	x1, x22
    8f60:      	bl	0x8f60 <_stogir.checked-schedule.cluster!+0x1c8>
		0000000000008f60:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate
    8f64:      	add	x16, sp, #0x30
    8f68:      	ldr	x0, [x16]
    8f6c:      	add	x16, sp, #0x30
    8f70:      	ldr	x24, [x16, #0x8]
    8f74:      	add	x16, sp, #0x30
    8f78:      	ldr	x25, [x16, #0x10]
    8f7c:      	b	0x9354 <_stogir.checked-schedule.cluster!+0x5bc>
    8f80:      	mov	x0, #0x1                ; =1
    8f84:      	b	0x9354 <_stogir.checked-schedule.cluster!+0x5bc>
    8f88:      	add	x16, sp, #0xb0
    8f8c:      	ldr	x2, [x16]
    8f90:      	add	x1, x2, x1, lsl #2
    8f94:      	str	w26, [x1]
    8f98:      	add	x16, sp, #0x80
    8f9c:      	ldr	x1, [x16]
    8fa0:      	add	x0, x1, x0, lsl #2
    8fa4:      	str	w26, [x0]
    8fa8:      	add	x16, sp, #0xe0
    8fac:      	ldr	x0, [x16]
    8fb0:      	add	x0, x0, x28
    8fb4:      	mov	w17, #0x1               ; =1
    8fb8:      	strb	w17, [x0]
    8fbc:      	ldr	x28, [sp, #0x1c0]
    8fc0:      	ldr	x0, [sp, #0x1a8]
    8fc4:      	ldr	x26, [sp, #0x1b8]
    8fc8:      	ldr	x1, [sp, #0x1b0]
    8fcc:      	cmp	x1, x0
    8fd0:      	b.ge	0x8ff4 <_stogir.checked-schedule.cluster!+0x25c>
    8fd4:      	add	x2, x1, #0x1
    8fd8:      	add	x1, x26, x1, lsl #2
    8fdc:      	ldr	w1, [x1]
    8fe0:      	movn	w17, #0x0, lsl #16
    8fe4:      	and	w3, w1, w17
    8fe8:      	mov	x1, x2
    8fec:      	mov	w2, #0x1                ; =1
    8ff0:      	b	0x8ffc <_stogir.checked-schedule.cluster!+0x264>
    8ff4:      	movz	w2, #0x0, lsl #16
    8ff8:      	movz	w3, #0x0, lsl #16
    8ffc:      	ubfx	x2, x2, #0, #32
    9000:      	lsr	x16, x2, #0
    9004:      	cmp	x16, #0x1
    9008:      	b.eq	0x9028 <_stogir.checked-schedule.cluster!+0x290>
    900c:      	b.lo	0x9014 <_stogir.checked-schedule.cluster!+0x27c>
    9010:      	b	0x902c <_stogir.checked-schedule.cluster!+0x294>
    9014:      	cmp	x16, #0x0
    9018:      	b.eq	0x9020 <_stogir.checked-schedule.cluster!+0x288>
    901c:      	b	0x902c <_stogir.checked-schedule.cluster!+0x294>
    9020:      	str	x28, [sp, #0x1c0]
    9024:      	b	0x90d0 <_stogir.checked-schedule.cluster!+0x338>
    9028:      	b	0x9030 <_stogir.checked-schedule.cluster!+0x298>
    902c:      	b	0x9708 <_stogir.checked-schedule.cluster!+0x970>
    9030:      	sxtw	x2, w3
    9034:      	ldr	x4, [x28]
    9038:      	add	x4, x4, x2, lsl #4
    903c:      	ldr	x5, [x4]
    9040:      	uxtb	w6, w5
    9044:      	ldr	x4, [x4, #0x8]
    9048:      	add	x16, sp, #0x140
    904c:      	str	x5, [x16]
    9050:      	add	x16, sp, #0x140
    9054:      	str	x4, [x16, #0x8]
    9058:      	cmp	x6, #0x2c
    905c:      	b.ne	0x974c <_stogir.checked-schedule.cluster!+0x9b4>
    9060:      	lsr	x4, x5, #32
    9064:      	add	x8, sp, #0x150
    9068:      	str	x0, [sp, #0x1a8]
    906c:      	mov	x0, x28
    9070:      	str	x1, [sp, #0x1b0]
    9074:      	mov	w1, w4
    9078:      	str	x26, [sp, #0x1b8]
    907c:      	mov	w26, w3
    9080:      	str	x28, [sp, #0x1c0]
    9084:      	mov	x28, x2
    9088:      	bl	0x9088 <_stogir.checked-schedule.cluster!+0x2f0>
		0000000000009088:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    908c:      	add	x16, sp, #0x150
    9090:      	ldr	w0, [x16]
    9094:      	lsr	x16, x0, #0
    9098:      	cmp	x16, #0x1
    909c:      	b.eq	0x90b8 <_stogir.checked-schedule.cluster!+0x320>
    90a0:      	b.lo	0x90a8 <_stogir.checked-schedule.cluster!+0x310>
    90a4:      	b	0x90bc <_stogir.checked-schedule.cluster!+0x324>
    90a8:      	cmp	x16, #0x0
    90ac:      	b.eq	0x90b4 <_stogir.checked-schedule.cluster!+0x31c>
    90b0:      	b	0x90bc <_stogir.checked-schedule.cluster!+0x324>
    90b4:      	b	0x9674 <_stogir.checked-schedule.cluster!+0x8dc>
    90b8:      	b	0x90c0 <_stogir.checked-schedule.cluster!+0x328>
    90bc:      	b	0x9720 <_stogir.checked-schedule.cluster!+0x988>
    90c0:      	add	x16, sp, #0x150
    90c4:      	ldr	x24, [x16, #0x8]
    90c8:      	ldr	x25, [x20, #0x8]
    90cc:      	b	0x8fbc <_stogir.checked-schedule.cluster!+0x224>
    90d0:      	ldr	x0, [x22, #0x28]
    90d4:      	ldr	x1, [x19, #0x8]
    90d8:      	orr	x20, x0, xzr
    90dc:      	orr	x21, x1, xzr
    90e0:      	movz	x26, #0x0, lsl #48
    90e4:      	b	0x923c <_stogir.checked-schedule.cluster!+0x4a4>
    90e8:      	add	x0, sp, #0x110
    90ec:      	bl	0x90ec <_stogir.checked-schedule.cluster!+0x354>
		00000000000090ec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    90f0:      	mov	x0, #0x1                ; =1
    90f4:      	b	0x9354 <_stogir.checked-schedule.cluster!+0x5bc>
    90f8:      	adrp	x24, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		00000000000090f8:  ARM64_RELOC_PAGE21	l_stogir.449
    90fc:      	ldr	x24, [x24]
		00000000000090fc:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    9100:      	mov	x25, #0x32              ; =50
    9104:      	b	0x9278 <_stogir.checked-schedule.cluster!+0x4e0>
    9108:      	lsl	x2, x2, #1
    910c:      	str	x20, [sp, #0x1c8]
    9110:      	mov	x20, x0
    9114:      	add	x0, sp, #0x110
    9118:      	str	x21, [sp, #0x1d0]
    911c:      	mov	x21, x1
    9120:      	mov	x1, x2
    9124:      	bl	0x9124 <_stogir.checked-schedule.cluster!+0x38c>
		0000000000009124:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9128:      	add	x0, x21, #0x1
    912c:      	add	x16, sp, #0x110
    9130:      	ldr	x1, [x16]
    9134:      	add	x1, x1, x21, lsl #2
    9138:      	str	w28, [x1]
    913c:      	add	x16, sp, #0x110
    9140:      	str	x0, [x16, #0x8]
    9144:      	add	x16, sp, #0x50
    9148:      	ldr	x0, [x16]
    914c:      	add	x0, x0, x20, lsl #2
    9150:      	ldr	w0, [x0]
    9154:      	orr	w20, w0, wzr
    9158:      	b	0x91a0 <_stogir.checked-schedule.cluster!+0x408>
    915c:      	nop
    9160:      	lsl	x0, x0, #1
    9164:      	mov	x1, x0
    9168:      	add	x0, sp, #0x110
    916c:      	bl	0x916c <_stogir.checked-schedule.cluster!+0x3d4>
		000000000000916c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9170:      	add	x0, x28, #0x1
    9174:      	add	x16, sp, #0x110
    9178:      	ldr	x1, [x16]
    917c:      	add	x1, x1, x28, lsl #2
    9180:      	str	w20, [x1]
    9184:      	add	x16, sp, #0x110
    9188:      	str	x0, [x16, #0x8]
    918c:      	add	x16, sp, #0xb0
    9190:      	ldr	x0, [x16]
    9194:      	add	x0, x0, x21, lsl #2
    9198:      	ldr	w0, [x0]
    919c:      	orr	w20, w0, wzr
    91a0:      	sxtw	x21, w20
    91a4:      	cmp	x21, #0x0
    91a8:      	b.eq	0x9234 <_stogir.checked-schedule.cluster!+0x49c>
    91ac:      	add	x16, sp, #0x110
    91b0:      	ldr	x0, [x16, #0x8]
    91b4:      	orr	x28, x0, xzr
    91b8:      	add	x16, sp, #0x110
    91bc:      	ldr	x0, [x16, #0x10]
    91c0:      	cmp	x28, x0
    91c4:      	b.lt	0x9170 <_stogir.checked-schedule.cluster!+0x3d8>
    91c8:      	cmp	x0, #0x0
    91cc:      	b.ne	0x9160 <_stogir.checked-schedule.cluster!+0x3c8>
    91d0:      	mov	x0, #0x2                ; =2
    91d4:      	b	0x9164 <_stogir.checked-schedule.cluster!+0x3cc>
    91d8:      	movz	w0, #0x0, lsl #16
    91dc:      	movz	w28, #0x0, lsl #16
    91e0:      	ubfx	x0, x0, #0, #32
    91e4:      	lsr	x16, x0, #0
    91e8:      	cmp	x16, #0x1
    91ec:      	b.eq	0x9208 <_stogir.checked-schedule.cluster!+0x470>
    91f0:      	b.lo	0x91f8 <_stogir.checked-schedule.cluster!+0x460>
    91f4:      	b	0x920c <_stogir.checked-schedule.cluster!+0x474>
    91f8:      	cmp	x16, #0x0
    91fc:      	b.eq	0x9204 <_stogir.checked-schedule.cluster!+0x46c>
    9200:      	b	0x920c <_stogir.checked-schedule.cluster!+0x474>
    9204:      	b	0x9264 <_stogir.checked-schedule.cluster!+0x4cc>
    9208:      	b	0x9210 <_stogir.checked-schedule.cluster!+0x478>
    920c:      	b	0x96f8 <_stogir.checked-schedule.cluster!+0x960>
    9210:      	sxtw	x0, w28
    9214:      	add	x16, sp, #0xe0
    9218:      	ldr	x1, [x16]
    921c:      	add	x1, x1, x0
    9220:      	ldrb	w1, [x1]
    9224:      	cmp	x1, #0x0
    9228:      	b.eq	0x9398 <_stogir.checked-schedule.cluster!+0x600>
    922c:      	str	x21, [sp, #0x1d0]
    9230:      	str	x20, [sp, #0x1c8]
    9234:      	ldr	x21, [sp, #0x1d0]
    9238:      	ldr	x20, [sp, #0x1c8]
    923c:      	cmp	x26, x21
    9240:      	b.ge	0x91d8 <_stogir.checked-schedule.cluster!+0x440>
    9244:      	add	x0, x26, #0x1
    9248:      	add	x1, x20, x26, lsl #2
    924c:      	ldr	w1, [x1]
    9250:      	movn	w17, #0x0, lsl #16
    9254:      	and	w28, w1, w17
    9258:      	mov	x26, x0
    925c:      	mov	w0, #0x1                ; =1
    9260:      	b	0x91e0 <_stogir.checked-schedule.cluster!+0x448>
    9264:      	add	x16, sp, #0x110
    9268:      	ldr	x0, [x16, #0x8]
    926c:      	ldr	x1, [x19, #0x8]
    9270:      	cmp	x0, x1
    9274:      	b.ne	0x90f8 <_stogir.checked-schedule.cluster!+0x360>
    9278:      	cmp	x25, #0x0
    927c:      	b.ne	0x92dc <_stogir.checked-schedule.cluster!+0x544>
    9280:      	add	x8, sp, #0x170
    9284:      	ldr	x0, [sp, #0x1c0]
    9288:      	add	x1, sp, #0x110
    928c:      	bl	0x928c <_stogir.checked-schedule.cluster!+0x4f4>
		000000000000928c:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    9290:      	add	x16, sp, #0x170
    9294:      	ldr	w0, [x16]
    9298:      	lsr	x16, x0, #0
    929c:      	cmp	x16, #0x1
    92a0:      	b.eq	0x92bc <_stogir.checked-schedule.cluster!+0x524>
    92a4:      	b.lo	0x92ac <_stogir.checked-schedule.cluster!+0x514>
    92a8:      	b	0x92c0 <_stogir.checked-schedule.cluster!+0x528>
    92ac:      	cmp	x16, #0x0
    92b0:      	b.eq	0x92b8 <_stogir.checked-schedule.cluster!+0x520>
    92b4:      	b	0x92c0 <_stogir.checked-schedule.cluster!+0x528>
    92b8:      	b	0x92dc <_stogir.checked-schedule.cluster!+0x544>
    92bc:      	b	0x92c4 <_stogir.checked-schedule.cluster!+0x52c>
    92c0:      	b	0x9710 <_stogir.checked-schedule.cluster!+0x978>
    92c4:      	add	x16, sp, #0x170
    92c8:      	orr	x0, x16, xzr
    92cc:      	add	x0, x0, #0x8
    92d0:      	add	x16, sp, #0x170
    92d4:      	ldr	x24, [x16, #0x8]
    92d8:      	ldr	x25, [x0, #0x8]
    92dc:      	add	x0, sp, #0x50
    92e0:      	bl	0x92e0 <_stogir.checked-schedule.cluster!+0x548>
		00000000000092e0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    92e4:      	add	x0, sp, #0x80
    92e8:      	bl	0x92e8 <_stogir.checked-schedule.cluster!+0x550>
		00000000000092e8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    92ec:      	add	x0, sp, #0xb0
    92f0:      	bl	0x92f0 <_stogir.checked-schedule.cluster!+0x558>
		00000000000092f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    92f4:      	add	x0, sp, #0xe0
    92f8:      	bl	0x92f8 <_stogir.checked-schedule.cluster!+0x560>
		00000000000092f8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__bool
    92fc:      	cmp	x25, #0x0
    9300:      	b.ne	0x90e8 <_stogir.checked-schedule.cluster!+0x350>
    9304:      	and	x24, x23, #0xffffffff
    9308:      	mov	x0, x19
    930c:      	bl	0x930c <_stogir.checked-schedule.cluster!+0x574>
		000000000000930c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9310:      	add	x16, sp, #0x110
    9314:      	ldr	x0, [x16]
    9318:      	add	x16, sp, #0x110
    931c:      	ldr	x1, [x16, #0x8]
    9320:      	add	x16, sp, #0x110
    9324:      	ldr	x2, [x16, #0x10]
    9328:      	add	x16, sp, #0x110
    932c:      	ldr	x3, [x16, #0x18]
    9330:      	add	x16, sp, #0x110
    9334:      	ldr	x4, [x16, #0x20]
    9338:      	str	x0, [x22, #0x28]
    933c:      	str	x1, [x19, #0x8]
    9340:      	str	x2, [x19, #0x10]
    9344:      	str	x3, [x19, #0x18]
    9348:      	str	x4, [x19, #0x20]
    934c:      	movz	x0, #0x0, lsl #48
    9350:      	movz	x25, #0x0, lsl #48
    9354:      	str	x0, [x27]
    9358:      	str	x24, [x27, #0x8]
    935c:      	str	x25, [x27, #0x10]
    9360:      	ldr	x19, [sp, #0x1d8]
    9364:      	ldr	x20, [sp, #0x1e0]
    9368:      	ldr	x21, [sp, #0x1e8]
    936c:      	ldr	x22, [sp, #0x1f0]
    9370:      	ldr	x23, [sp, #0x1f8]
    9374:      	ldr	x24, [sp, #0x200]
    9378:      	ldr	x25, [sp, #0x208]
    937c:      	ldr	x26, [sp, #0x210]
    9380:      	ldr	x27, [sp, #0x218]
    9384:      	ldr	x28, [sp, #0x220]
    9388:      	ldr	x29, [sp]
    938c:      	ldr	x30, [sp, #0x8]
    9390:      	add	sp, sp, #0x230
    9394:      	ret
    9398:      	add	x16, sp, #0x110
    939c:      	ldr	x1, [x16, #0x8]
    93a0:      	add	x16, sp, #0x110
    93a4:      	ldr	x2, [x16, #0x10]
    93a8:      	cmp	x1, x2
    93ac:      	b.lt	0x9760 <_stogir.checked-schedule.cluster!+0x9c8>
    93b0:      	cmp	x2, #0x0
    93b4:      	b.ne	0x9108 <_stogir.checked-schedule.cluster!+0x370>
    93b8:      	mov	x2, #0x2                ; =2
    93bc:      	b	0x910c <_stogir.checked-schedule.cluster!+0x374>
    93c0:      	add	x16, sp, #0x150
    93c4:      	orr	x0, x16, xzr
    93c8:      	ldr	x1, [x22, #0x28]
    93cc:      	add	x20, x0, #0x8
    93d0:      	ldr	x0, [x19, #0x8]
    93d4:      	orr	x26, x1, xzr
    93d8:      	movz	x1, #0x0, lsl #48
    93dc:      	b	0x8fcc <_stogir.checked-schedule.cluster!+0x234>
    93e0:      	lsl	x0, x0, #1
    93e4:      	mov	x1, x0
    93e8:      	add	x0, sp, #0x50
    93ec:      	bl	0x93ec <_stogir.checked-schedule.cluster!+0x654>
		00000000000093ec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    93f0:      	add	x0, x26, #0x1
    93f4:      	add	x16, sp, #0x50
    93f8:      	ldr	x1, [x16]
    93fc:      	add	x1, x1, x26, lsl #2
    9400:      	movz	w17, #0x0, lsl #16
    9404:      	str	w17, [x1]
    9408:      	add	x16, sp, #0x50
    940c:      	str	x0, [x16, #0x8]
    9410:      	add	x16, sp, #0x80
    9414:      	ldr	x0, [x16, #0x8]
    9418:      	orr	x26, x0, xzr
    941c:      	add	x16, sp, #0x80
    9420:      	ldr	x0, [x16, #0x10]
    9424:      	cmp	x26, x0
    9428:      	b.lt	0x944c <_stogir.checked-schedule.cluster!+0x6b4>
    942c:      	cmp	x0, #0x0
    9430:      	b.ne	0x943c <_stogir.checked-schedule.cluster!+0x6a4>
    9434:      	mov	x0, #0x2                ; =2
    9438:      	b	0x9440 <_stogir.checked-schedule.cluster!+0x6a8>
    943c:      	lsl	x0, x0, #1
    9440:      	mov	x1, x0
    9444:      	add	x0, sp, #0x80
    9448:      	bl	0x9448 <_stogir.checked-schedule.cluster!+0x6b0>
		0000000000009448:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    944c:      	add	x0, x26, #0x1
    9450:      	add	x16, sp, #0x80
    9454:      	ldr	x1, [x16]
    9458:      	add	x1, x1, x26, lsl #2
    945c:      	movz	w17, #0x0, lsl #16
    9460:      	str	w17, [x1]
    9464:      	add	x16, sp, #0x80
    9468:      	str	x0, [x16, #0x8]
    946c:      	add	x16, sp, #0xb0
    9470:      	ldr	x0, [x16, #0x8]
    9474:      	orr	x26, x0, xzr
    9478:      	add	x16, sp, #0xb0
    947c:      	ldr	x0, [x16, #0x10]
    9480:      	cmp	x26, x0
    9484:      	b.lt	0x94a8 <_stogir.checked-schedule.cluster!+0x710>
    9488:      	cmp	x0, #0x0
    948c:      	b.ne	0x9498 <_stogir.checked-schedule.cluster!+0x700>
    9490:      	mov	x0, #0x2                ; =2
    9494:      	b	0x949c <_stogir.checked-schedule.cluster!+0x704>
    9498:      	lsl	x0, x0, #1
    949c:      	mov	x1, x0
    94a0:      	add	x0, sp, #0xb0
    94a4:      	bl	0x94a4 <_stogir.checked-schedule.cluster!+0x70c>
		00000000000094a4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    94a8:      	add	x0, x26, #0x1
    94ac:      	add	x16, sp, #0xb0
    94b0:      	ldr	x1, [x16]
    94b4:      	add	x1, x1, x26, lsl #2
    94b8:      	movz	w17, #0x0, lsl #16
    94bc:      	str	w17, [x1]
    94c0:      	add	x16, sp, #0xb0
    94c4:      	str	x0, [x16, #0x8]
    94c8:      	add	x16, sp, #0xe0
    94cc:      	ldr	x0, [x16, #0x8]
    94d0:      	orr	x26, x0, xzr
    94d4:      	add	x16, sp, #0xe0
    94d8:      	ldr	x0, [x16, #0x10]
    94dc:      	cmp	x26, x0
    94e0:      	b.lt	0x9504 <_stogir.checked-schedule.cluster!+0x76c>
    94e4:      	cmp	x0, #0x0
    94e8:      	b.ne	0x94f4 <_stogir.checked-schedule.cluster!+0x75c>
    94ec:      	mov	x0, #0x2                ; =2
    94f0:      	b	0x94f8 <_stogir.checked-schedule.cluster!+0x760>
    94f4:      	lsl	x0, x0, #1
    94f8:      	mov	x1, x0
    94fc:      	add	x0, sp, #0xe0
    9500:      	bl	0x9500 <_stogir.checked-schedule.cluster!+0x768>
		0000000000009500:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    9504:      	add	x20, x20, #0x1
    9508:      	add	x0, x26, #0x1
    950c:      	add	x16, sp, #0xe0
    9510:      	ldr	x1, [x16]
    9514:      	add	x1, x1, x26
    9518:      	movz	w17, #0x0, lsl #16
    951c:      	strb	w17, [x1]
    9520:      	add	x16, sp, #0xe0
    9524:      	str	x0, [x16, #0x8]
    9528:      	ldr	x0, [x28, #0x8]
    952c:      	cmp	x20, x0
    9530:      	b.ge	0x93c0 <_stogir.checked-schedule.cluster!+0x628>
    9534:      	add	x16, sp, #0x50
    9538:      	ldr	x0, [x16, #0x8]
    953c:      	orr	x26, x0, xzr
    9540:      	add	x16, sp, #0x50
    9544:      	ldr	x0, [x16, #0x10]
    9548:      	cmp	x26, x0
    954c:      	b.lt	0x93f0 <_stogir.checked-schedule.cluster!+0x658>
    9550:      	cmp	x0, #0x0
    9554:      	b.ne	0x93e0 <_stogir.checked-schedule.cluster!+0x648>
    9558:      	mov	x0, #0x2                ; =2
    955c:      	b	0x93e4 <_stogir.checked-schedule.cluster!+0x64c>
    9560:      	ldr	x0, [x26]
    9564:      	ldr	x1, [x26, #0x8]
    9568:      	add	x16, sp, #0x50
    956c:      	movz	x17, #0x0, lsl #48
    9570:      	str	x17, [x16]
    9574:      	add	x16, sp, #0x50
    9578:      	movz	x17, #0x0, lsl #48
    957c:      	str	x17, [x16, #0x8]
    9580:      	add	x16, sp, #0x50
    9584:      	movz	x17, #0x0, lsl #48
    9588:      	str	x17, [x16, #0x10]
    958c:      	add	x16, sp, #0x50
    9590:      	str	x0, [x16, #0x18]
    9594:      	add	x16, sp, #0x50
    9598:      	str	x1, [x16, #0x20]
    959c:      	add	x16, sp, #0x80
    95a0:      	movz	x17, #0x0, lsl #48
    95a4:      	str	x17, [x16]
    95a8:      	add	x16, sp, #0x80
    95ac:      	movz	x17, #0x0, lsl #48
    95b0:      	str	x17, [x16, #0x8]
    95b4:      	add	x16, sp, #0x80
    95b8:      	movz	x17, #0x0, lsl #48
    95bc:      	str	x17, [x16, #0x10]
    95c0:      	add	x16, sp, #0x80
    95c4:      	str	x0, [x16, #0x18]
    95c8:      	add	x16, sp, #0x80
    95cc:      	str	x1, [x16, #0x20]
    95d0:      	add	x16, sp, #0xb0
    95d4:      	movz	x17, #0x0, lsl #48
    95d8:      	str	x17, [x16]
    95dc:      	add	x16, sp, #0xb0
    95e0:      	movz	x17, #0x0, lsl #48
    95e4:      	str	x17, [x16, #0x8]
    95e8:      	add	x16, sp, #0xb0
    95ec:      	movz	x17, #0x0, lsl #48
    95f0:      	str	x17, [x16, #0x10]
    95f4:      	add	x16, sp, #0xb0
    95f8:      	str	x0, [x16, #0x18]
    95fc:      	add	x16, sp, #0xb0
    9600:      	str	x1, [x16, #0x20]
    9604:      	add	x16, sp, #0xe0
    9608:      	movz	x17, #0x0, lsl #48
    960c:      	str	x17, [x16]
    9610:      	add	x16, sp, #0xe0
    9614:      	movz	x17, #0x0, lsl #48
    9618:      	str	x17, [x16, #0x8]
    961c:      	add	x16, sp, #0xe0
    9620:      	movz	x17, #0x0, lsl #48
    9624:      	str	x17, [x16, #0x10]
    9628:      	add	x16, sp, #0xe0
    962c:      	str	x0, [x16, #0x18]
    9630:      	add	x16, sp, #0xe0
    9634:      	str	x1, [x16, #0x20]
    9638:      	add	x16, sp, #0x110
    963c:      	movz	x17, #0x0, lsl #48
    9640:      	str	x17, [x16]
    9644:      	add	x16, sp, #0x110
    9648:      	movz	x17, #0x0, lsl #48
    964c:      	str	x17, [x16, #0x8]
    9650:      	add	x16, sp, #0x110
    9654:      	movz	x17, #0x0, lsl #48
    9658:      	str	x17, [x16, #0x10]
    965c:      	add	x16, sp, #0x110
    9660:      	str	x0, [x16, #0x18]
    9664:      	add	x16, sp, #0x110
    9668:      	str	x1, [x16, #0x20]
    966c:      	movz	x20, #0x0, lsl #48
    9670:      	b	0x9528 <_stogir.checked-schedule.cluster!+0x790>
    9674:      	add	x16, sp, #0x150
    9678:      	ldr	w0, [x16, #0x8]
    967c:      	sxtw	x0, w0
    9680:      	cmp	x0, #0x0
    9684:      	b.eq	0x8fbc <_stogir.checked-schedule.cluster!+0x224>
    9688:      	add	x16, sp, #0x140
    968c:      	ldr	w0, [x16, #0x4]
    9690:      	sxtw	x0, w0
    9694:      	add	x16, sp, #0x80
    9698:      	ldr	x1, [x16]
    969c:      	add	x1, x1, x0, lsl #2
    96a0:      	ldr	w1, [x1]
    96a4:      	ldr	x2, [x21]
    96a8:      	orr	x3, x2, xzr
    96ac:      	add	x3, x3, x0, lsl #2
    96b0:      	add	x2, x2, x28, lsl #2
    96b4:      	ldr	w3, [x3]
    96b8:      	ldr	w2, [x2]
    96bc:      	sxtw	x3, w3
    96c0:      	sxtw	x2, w2
    96c4:      	cmp	x3, x2
    96c8:      	b.eq	0x96d8 <_stogir.checked-schedule.cluster!+0x940>
    96cc:      	adrp	x24, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		00000000000096cc:  ARM64_RELOC_PAGE21	l_stogir.450
    96d0:      	ldr	x24, [x24]
		00000000000096d0:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    96d4:      	mov	x25, #0x30              ; =48
    96d8:      	sxtw	x1, w1
    96dc:      	cmp	x1, #0x0
    96e0:      	b.ne	0x8f88 <_stogir.checked-schedule.cluster!+0x1f0>
    96e4:      	add	x16, sp, #0x50
    96e8:      	ldr	x1, [x16]
    96ec:      	add	x1, x1, x0, lsl #2
    96f0:      	str	w26, [x1]
    96f4:      	b	0x8f98 <_stogir.checked-schedule.cluster!+0x200>
    96f8:      	brk	#0
    96fc:      	b	0x96f8 <_stogir.checked-schedule.cluster!+0x960>
    9700:      	brk	#0
    9704:      	b	0x9700 <_stogir.checked-schedule.cluster!+0x968>
    9708:      	brk	#0
    970c:      	b	0x9708 <_stogir.checked-schedule.cluster!+0x970>
    9710:      	brk	#0
    9714:      	b	0x9710 <_stogir.checked-schedule.cluster!+0x978>
    9718:      	brk	#0
    971c:      	b	0x9718 <_stogir.checked-schedule.cluster!+0x980>
    9720:      	brk	#0
    9724:      	b	0x9720 <_stogir.checked-schedule.cluster!+0x988>
    9728:      	mov	x27, x8
    972c:      	mov	x28, x0
    9730:      	str	x22, [sp, #0x198]
    9734:      	mov	x22, x2
    9738:      	str	x21, [sp, #0x190]
    973c:      	mov	x21, x1
    9740:      	str	x26, [sp, #0x1a0]
    9744:      	mov	x26, x3
    9748:      	b	0x8e24 <_stogir.checked-schedule.cluster!+0x8c>
    974c:      	str	x28, [sp, #0x1c0]
    9750:      	str	x0, [sp, #0x1a8]
    9754:      	str	x26, [sp, #0x1b8]
    9758:      	str	x1, [sp, #0x1b0]
    975c:      	b	0x8fbc <_stogir.checked-schedule.cluster!+0x224>
    9760:      	str	x21, [sp, #0x1d0]
    9764:      	mov	x21, x1
    9768:      	str	x20, [sp, #0x1c8]
    976c:      	mov	x20, x0
    9770:      	b	0x9128 <_stogir.checked-schedule.cluster!+0x390>
    9774:      	udf	#0x0

0000000000009778 <_stogir.adjacency.release!>:
    9778:      	sub	sp, sp, #0x20
    977c:      	str	x29, [sp]
    9780:      	str	x30, [sp, #0x8]
    9784:      	mov	x29, sp
    9788:      	str	x19, [sp, #0x10]
    978c:      	str	x20, [sp, #0x18]
    9790:      	b	0x97a0 <_stogir.adjacency.release!+0x28>
    9794:      	nop
    9798:      	sub	x1, x1, #0x1
    979c:      	str	x1, [x0, #0x8]
    97a0:      	ldr	x1, [x0, #0x8]
    97a4:      	cmp	x1, #0x0
    97a8:      	b.ne	0x9798 <_stogir.adjacency.release!+0x20>
    97ac:      	ldr	x1, [x0, #0x10]
    97b0:      	cmp	x1, #0x0
    97b4:      	b.le	0x9884 <_stogir.adjacency.release!+0x10c>
    97b8:      	add	x2, x0, #0x18
    97bc:      	ldr	x3, [x0]
    97c0:      	mov	x19, x0
    97c4:      	mov	x0, x2
    97c8:      	mov	x2, x1
    97cc:      	mov	x1, x3
    97d0:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		00000000000097d0:  ARM64_RELOC_PAGE21	l_stogir.451
    97d4:      	ldr	x3, [x3]
		00000000000097d4:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    97d8:      	mov	x4, #0x10               ; =16
    97dc:      	mov	x5, #0x8                ; =8
    97e0:      	bl	0x97e0 <_stogir.adjacency.release!+0x68>
		00000000000097e0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    97e4:      	add	x20, x19, #0x28
    97e8:      	movz	x17, #0x0, lsl #48
    97ec:      	str	x17, [x19]
    97f0:      	movz	x17, #0x0, lsl #48
    97f4:      	str	x17, [x19, #0x8]
    97f8:      	movz	x17, #0x0, lsl #48
    97fc:      	str	x17, [x19, #0x10]
    9800:      	b	0x9810 <_stogir.adjacency.release!+0x98>
    9804:      	nop
    9808:      	sub	x0, x0, #0x1
    980c:      	str	x0, [x20, #0x8]
    9810:      	ldr	x0, [x20, #0x8]
    9814:      	cmp	x0, #0x0
    9818:      	b.ne	0x9808 <_stogir.adjacency.release!+0x90>
    981c:      	ldr	x0, [x20, #0x10]
    9820:      	cmp	x0, #0x0
    9824:      	b.le	0x9854 <_stogir.adjacency.release!+0xdc>
    9828:      	add	x1, x20, #0x18
    982c:      	ldr	x2, [x19, #0x28]
    9830:      	fmov	d31, x0
    9834:      	mov	x0, x1
    9838:      	mov	x1, x2
    983c:      	fmov	x2, d31
    9840:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009840:  ARM64_RELOC_PAGE21	l_stogir.452
    9844:      	ldr	x3, [x3]
		0000000000009844:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9848:      	mov	x4, #0x8                ; =8
    984c:      	mov	x5, #0x8                ; =8
    9850:      	bl	0x9850 <_stogir.adjacency.release!+0xd8>
		0000000000009850:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    9854:      	movz	x17, #0x0, lsl #48
    9858:      	str	x17, [x19, #0x28]
    985c:      	movz	x17, #0x0, lsl #48
    9860:      	str	x17, [x20, #0x8]
    9864:      	movz	x17, #0x0, lsl #48
    9868:      	str	x17, [x20, #0x10]
    986c:      	ldr	x19, [sp, #0x10]
    9870:      	ldr	x20, [sp, #0x18]
    9874:      	ldr	x29, [sp]
    9878:      	ldr	x30, [sp, #0x8]
    987c:      	add	sp, sp, #0x20
    9880:      	ret
    9884:      	mov	x19, x0
    9888:      	b	0x97e4 <_stogir.adjacency.release!+0x6c>
    988c:      	udf	#0x0

0000000000009890 <_inherent$coil.arraylist.ArrayList$free!__bool>:
    9890:      	sub	sp, sp, #0x20
    9894:      	str	x29, [sp]
    9898:      	str	x30, [sp, #0x8]
    989c:      	mov	x29, sp
    98a0:      	str	x19, [sp, #0x10]
    98a4:      	b	0x98b0 <_inherent$coil.arraylist.ArrayList$free!__bool+0x20>
    98a8:      	sub	x1, x1, #0x1
    98ac:      	str	x1, [x0, #0x8]
    98b0:      	ldr	x1, [x0, #0x8]
    98b4:      	cmp	x1, #0x0
    98b8:      	b.ne	0x98a8 <_inherent$coil.arraylist.ArrayList$free!__bool+0x18>
    98bc:      	ldr	x1, [x0, #0x10]
    98c0:      	cmp	x1, #0x0
    98c4:      	b.le	0x9924 <_inherent$coil.arraylist.ArrayList$free!__bool+0x94>
    98c8:      	add	x2, x0, #0x18
    98cc:      	ldr	x3, [x0]
    98d0:      	mov	x19, x0
    98d4:      	mov	x0, x2
    98d8:      	mov	x2, x1
    98dc:      	mov	x1, x3
    98e0:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		00000000000098e0:  ARM64_RELOC_PAGE21	l_stogir.453
    98e4:      	ldr	x3, [x3]
		00000000000098e4:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    98e8:      	mov	x4, #0x1                ; =1
    98ec:      	mov	x5, #0x1                ; =1
    98f0:      	bl	0x98f0 <_inherent$coil.arraylist.ArrayList$free!__bool+0x60>
		00000000000098f0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    98f4:      	movz	x17, #0x0, lsl #48
    98f8:      	str	x17, [x19]
    98fc:      	movz	x17, #0x0, lsl #48
    9900:      	str	x17, [x19, #0x8]
    9904:      	movz	x17, #0x0, lsl #48
    9908:      	str	x17, [x19, #0x10]
    990c:      	movz	x0, #0x0, lsl #48
    9910:      	ldr	x19, [sp, #0x10]
    9914:      	ldr	x29, [sp]
    9918:      	ldr	x30, [sp, #0x8]
    991c:      	add	sp, sp, #0x20
    9920:      	ret
    9924:      	mov	x19, x0
    9928:      	b	0x98f4 <_inherent$coil.arraylist.ArrayList$free!__bool+0x64>
    992c:      	udf	#0x0

0000000000009930 <_stogir.uses.release!>:
    9930:      	sub	sp, sp, #0x20
    9934:      	str	x29, [sp]
    9938:      	str	x30, [sp, #0x8]
    993c:      	mov	x29, sp
    9940:      	str	x19, [sp, #0x10]
    9944:      	str	x20, [sp, #0x18]
    9948:      	b	0x9958 <_stogir.uses.release!+0x28>
    994c:      	nop
    9950:      	sub	x1, x1, #0x1
    9954:      	str	x1, [x0, #0x8]
    9958:      	ldr	x1, [x0, #0x8]
    995c:      	cmp	x1, #0x0
    9960:      	b.ne	0x9950 <_stogir.uses.release!+0x20>
    9964:      	ldr	x1, [x0, #0x10]
    9968:      	cmp	x1, #0x0
    996c:      	b.le	0x9a3c <_stogir.uses.release!+0x10c>
    9970:      	add	x2, x0, #0x18
    9974:      	ldr	x3, [x0]
    9978:      	mov	x19, x0
    997c:      	mov	x0, x2
    9980:      	mov	x2, x1
    9984:      	mov	x1, x3
    9988:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009988:  ARM64_RELOC_PAGE21	l_stogir.454
    998c:      	ldr	x3, [x3]
		000000000000998c:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    9990:      	mov	x4, #0x10               ; =16
    9994:      	mov	x5, #0x8                ; =8
    9998:      	bl	0x9998 <_stogir.uses.release!+0x68>
		0000000000009998:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    999c:      	add	x20, x19, #0x28
    99a0:      	movz	x17, #0x0, lsl #48
    99a4:      	str	x17, [x19]
    99a8:      	movz	x17, #0x0, lsl #48
    99ac:      	str	x17, [x19, #0x8]
    99b0:      	movz	x17, #0x0, lsl #48
    99b4:      	str	x17, [x19, #0x10]
    99b8:      	b	0x99c8 <_stogir.uses.release!+0x98>
    99bc:      	nop
    99c0:      	sub	x0, x0, #0x1
    99c4:      	str	x0, [x20, #0x8]
    99c8:      	ldr	x0, [x20, #0x8]
    99cc:      	cmp	x0, #0x0
    99d0:      	b.ne	0x99c0 <_stogir.uses.release!+0x90>
    99d4:      	ldr	x0, [x20, #0x10]
    99d8:      	cmp	x0, #0x0
    99dc:      	b.le	0x9a0c <_stogir.uses.release!+0xdc>
    99e0:      	add	x1, x20, #0x18
    99e4:      	ldr	x2, [x19, #0x28]
    99e8:      	fmov	d31, x0
    99ec:      	mov	x0, x1
    99f0:      	mov	x1, x2
    99f4:      	fmov	x2, d31
    99f8:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		00000000000099f8:  ARM64_RELOC_PAGE21	l_stogir.455
    99fc:      	ldr	x3, [x3]
		00000000000099fc:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    9a00:      	mov	x4, #0x8                ; =8
    9a04:      	mov	x5, #0x4                ; =4
    9a08:      	bl	0x9a08 <_stogir.uses.release!+0xd8>
		0000000000009a08:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    9a0c:      	movz	x17, #0x0, lsl #48
    9a10:      	str	x17, [x19, #0x28]
    9a14:      	movz	x17, #0x0, lsl #48
    9a18:      	str	x17, [x20, #0x8]
    9a1c:      	movz	x17, #0x0, lsl #48
    9a20:      	str	x17, [x20, #0x10]
    9a24:      	ldr	x19, [sp, #0x10]
    9a28:      	ldr	x20, [sp, #0x18]
    9a2c:      	ldr	x29, [sp]
    9a30:      	ldr	x30, [sp, #0x8]
    9a34:      	add	sp, sp, #0x20
    9a38:      	ret
    9a3c:      	mov	x19, x0
    9a40:      	b	0x999c <_stogir.uses.release!+0x6c>
    9a44:      	udf	#0x0

0000000000009a48 <_stogir.verify.structure>:
    9a48:      	sub	sp, sp, #0x110
    9a4c:      	str	x29, [sp, #0x10]
    9a50:      	str	x30, [sp, #0x18]
    9a54:      	add	x29, sp, #0x10
    9a58:      	str	x19, [sp, #0xb8]
    9a5c:      	str	x20, [sp, #0xc0]
    9a60:      	str	x21, [sp, #0xc8]
    9a64:      	str	x22, [sp, #0xd0]
    9a68:      	str	x23, [sp, #0xd8]
    9a6c:      	str	x24, [sp, #0xe0]
    9a70:      	str	x25, [sp, #0xe8]
    9a74:      	str	x26, [sp, #0xf0]
    9a78:      	str	x27, [sp, #0xf8]
    9a7c:      	str	x28, [sp, #0x100]
    9a80:      	mov	x19, x8
    9a84:      	mov	x20, x0
    9a88:      	bl	0x9a88 <_stogir.verify.structure+0x40>
		0000000000009a88:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    9a8c:      	add	x21, x20, #0x78
    9a90:      	mov	x22, x0
    9a94:      	mov	x0, x21
    9a98:      	bl	0x9a98 <_stogir.verify.structure+0x50>
		0000000000009a98:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    9a9c:      	cmp	x22, x0
    9aa0:      	b.ne	0x9ad0 <_stogir.verify.structure+0x88>
    9aa4:      	adrp	x22, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009aa4:  ARM64_RELOC_PAGE21	l_stogir.456
    9aa8:      	ldr	x22, [x22]
		0000000000009aa8:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9aac:      	movz	x23, #0x0, lsl #48
    9ab0:      	b	0x9adc <_stogir.verify.structure+0x94>
    9ab4:      	ldr	x1, [sp, #0x88]
    9ab8:      	ldr	x5, [sp, #0x90]
    9abc:      	add	x5, x1, x5
    9ac0:      	ldr	x19, [sp, #0x40]
    9ac4:      	add	x1, x19, #0x1
    9ac8:      	sxtw	x19, w1
    9acc:      	b	0x9b0c <_stogir.verify.structure+0xc4>
    9ad0:      	adrp	x22, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009ad0:  ARM64_RELOC_PAGE21	l_stogir.457
    9ad4:      	ldr	x22, [x22]
		0000000000009ad4:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    9ad8:      	mov	x23, #0x2c              ; =44
    9adc:      	add	x24, x20, #0x110
    9ae0:      	add	x25, x20, #0x28
    9ae4:      	add	x26, x20, #0x50
    9ae8:      	add	x27, x24, #0x28
    9aec:      	mov	x28, #0x1               ; =1
    9af0:      	movz	x0, #0x0, lsl #48
    9af4:      	b	0x9b64 <_stogir.verify.structure+0x11c>
    9af8:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009af8:  ARM64_RELOC_PAGE21	l_stogir.458
    9afc:      	ldr	x16, [x16]
		0000000000009afc:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    9b00:      	str	x16, [sp, #0x38]
    9b04:      	mov	x16, #0x16              ; =22
    9b08:      	str	x16, [sp, #0x80]
    9b0c:      	b	0x9b40 <_stogir.verify.structure+0xf8>
    9b10:      	mov	x5, x28
    9b14:      	str	x19, [sp, #0x30]
    9b18:      	mov	x19, x0
    9b1c:      	mov	x0, x21
    9b20:      	mov	x2, x24
    9b24:      	mov	x3, x25
    9b28:      	mov	x4, x26
    9b2c:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009b2c:  ARM64_RELOC_PAGE21	l_stogir.459
    9b30:      	ldr	x16, [x16]
		0000000000009b30:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    9b34:      	str	x16, [sp, #0x38]
    9b38:      	mov	x16, #0x23              ; =35
    9b3c:      	str	x16, [sp, #0x80]
    9b40:      	mov	x21, x0
    9b44:      	mov	x24, x2
    9b48:      	mov	x25, x3
    9b4c:      	mov	x26, x4
    9b50:      	mov	x28, x5
    9b54:      	mov	x0, x19
    9b58:      	ldr	x19, [sp, #0x30]
    9b5c:      	ldr	x22, [sp, #0x38]
    9b60:      	ldr	x23, [sp, #0x80]
    9b64:      	cmp	x23, #0x0
    9b68:      	b.ne	0xa324 <_stogir.verify.structure+0x8dc>
    9b6c:      	ldr	x1, [x20, #0x8]
    9b70:      	cmp	x28, x1
    9b74:      	b.ge	0xa338 <_stogir.verify.structure+0x8f0>
    9b78:      	ldr	x1, [x20]
    9b7c:      	add	x1, x1, x28, lsl #4
    9b80:      	ldr	x1, [x1]
    9b84:      	ldr	x2, [x20, #0x78]
    9b88:      	add	x2, x2, x28, lsl #2
    9b8c:      	ldr	w2, [x2]
    9b90:      	sxtw	x2, w2
    9b94:      	cmp	x2, #0x0
    9b98:      	b.lt	0x9b10 <_stogir.verify.structure+0xc8>
    9b9c:      	mov	x17, #0xffff            ; =65535
    9ba0:      	cmp	x2, x17
    9ba4:      	b.gt	0xa34c <_stogir.verify.structure+0x904>
    9ba8:      	uxtb	w3, w1
    9bac:      	orr	x4, x3, xzr
    9bb0:      	cmp	x4, #0x83
    9bb4:      	cset	w5, lt
    9bb8:      	uxtb	w16, w5
    9bbc:      	cmp	w16, wzr
    9bc0:      	b.eq	0xa36c <_stogir.verify.structure+0x924>
    9bc4:      	ubfx	x1, x1, #0, #32
    9bc8:      	ubfx	x6, x1, #8, #8
    9bcc:      	orr	x7, x6, xzr
    9bd0:      	str	x0, [sp, #0x40]
    9bd4:      	mov	w0, w7
    9bd8:      	str	x19, [sp, #0x30]
    9bdc:      	mov	w19, w3
    9be0:      	str	x22, [sp, #0x38]
    9be4:      	mov	x22, x2
    9be8:      	str	x26, [sp, #0x48]
    9bec:      	mov	x26, x4
    9bf0:      	str	x25, [sp, #0x50]
    9bf4:      	mov	w25, w5
    9bf8:      	str	x21, [sp, #0x58]
    9bfc:      	mov	x21, x1
    9c00:      	str	x24, [sp, #0x60]
    9c04:      	mov	w24, w6
    9c08:      	bl	0x9c08 <_stogir.verify.structure+0x1c0>
		0000000000009c08:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    9c0c:      	cmp	x0, #0x0
    9c10:      	b.eq	0xa38c <_stogir.verify.structure+0x944>
    9c14:      	adrp	x17, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009c14:  ARM64_RELOC_PAGE21	l_stogir.460
    9c18:      	ldr	x17, [x17]
		0000000000009c18:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    9c1c:      	add	x0, x26, x17
    9c20:      	ldrsb	w0, [x0]
    9c24:      	sxtb	x0, w0
    9c28:      	cmp	x0, #0x0
    9c2c:      	b.lt	0xa044 <_stogir.verify.structure+0x5fc>
    9c30:      	uxtb	w16, w25
    9c34:      	cmp	w16, wzr
    9c38:      	b.eq	0xa118 <_stogir.verify.structure+0x6d0>
    9c3c:      	adrp	x17, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009c3c:  ARM64_RELOC_PAGE21	l_stogir.460
    9c40:      	ldr	x17, [x17]
		0000000000009c40:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    9c44:      	add	x0, x26, x17
    9c48:      	ldrsb	w0, [x0]
    9c4c:      	sxtb	w0, w0
    9c50:      	b	0xa11c <_stogir.verify.structure+0x6d4>
    9c54:      	ldr	x0, [sp, #0x38]
    9c58:      	ldr	x1, [sp, #0x80]
    9c5c:      	adrp	x2, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009c5c:  ARM64_RELOC_PAGE21	l_stogir.456
    9c60:      	ldr	x2, [x2]
		0000000000009c60:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9c64:      	movz	x3, #0x0, lsl #48
    9c68:      	bl	0x9c68 <_stogir.verify.structure+0x220>
		0000000000009c68:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    9c6c:      	cmp	x0, #0x0
    9c70:      	b.eq	0xa3a8 <_stogir.verify.structure+0x960>
    9c74:      	and	x0, x19, #0xffffffff
    9c78:      	movz	x1, #0x0, lsl #48
    9c7c:      	movz	x16, #0x0, lsl #48
    9c80:      	str	x16, [sp, #0x80]
    9c84:      	b	0x9c8c <_stogir.verify.structure+0x244>
    9c88:      	mov	x1, #0x1                ; =1
    9c8c:      	ldr	x2, [sp, #0x30]
    9c90:      	str	x1, [x2]
    9c94:      	str	x0, [x2, #0x8]
    9c98:      	ldr	x0, [sp, #0x80]
    9c9c:      	str	x0, [x2, #0x10]
    9ca0:      	ldr	x19, [sp, #0xb8]
    9ca4:      	ldr	x20, [sp, #0xc0]
    9ca8:      	ldr	x21, [sp, #0xc8]
    9cac:      	ldr	x22, [sp, #0xd0]
    9cb0:      	ldr	x23, [sp, #0xd8]
    9cb4:      	ldr	x24, [sp, #0xe0]
    9cb8:      	ldr	x25, [sp, #0xe8]
    9cbc:      	ldr	x26, [sp, #0xf0]
    9cc0:      	ldr	x27, [sp, #0xf8]
    9cc4:      	ldr	x28, [sp, #0x100]
    9cc8:      	ldr	x29, [sp, #0x10]
    9ccc:      	ldr	x30, [sp, #0x18]
    9cd0:      	add	sp, sp, #0x110
    9cd4:      	ret
    9cd8:      	mov	w9, w5
    9cdc:      	lsl	w9, w9, #2
    9ce0:      	ubfx	x9, x9, #0, #32
    9ce4:      	lsr	x8, x8, x9
    9ce8:      	and	w8, w8, #0xf
    9cec:      	b	0x9d0c <_stogir.verify.structure+0x2c4>
    9cf0:      	movz	x1, #0x0, lsl #48
    9cf4:      	cmp	x1, #0x0
    9cf8:      	b.eq	0xa158 <_stogir.verify.structure+0x710>
    9cfc:      	ldr	w1, [sp, #0xb0]
    9d00:      	ldr	w5, [sp, #0xa8]
    9d04:      	b	0x9db4 <_stogir.verify.structure+0x36c>
    9d08:      	movz	w8, #0x0, lsl #16
    9d0c:      	b	0x9d14 <_stogir.verify.structure+0x2cc>
    9d10:      	movz	w8, #0x0, lsl #16
    9d14:      	str	w0, [sp, #0x68]
    9d18:      	str	x2, [sp, #0x98]
    9d1c:      	mov	w2, w3
    9d20:      	str	x4, [sp, #0xa0]
    9d24:      	str	x22, [sp, #0x70]
    9d28:      	mov	x22, x1
    9d2c:      	mov	w1, w0
    9d30:      	mov	x0, x20
    9d34:      	str	x26, [sp, #0x78]
    9d38:      	mov	w26, w7
    9d3c:      	str	x23, [sp, #0x80]
    9d40:      	mov	w23, w8
    9d44:      	str	x19, [sp, #0x88]
    9d48:      	mov	w19, w5
    9d4c:      	str	x28, [sp, #0x90]
    9d50:      	mov	w28, w6
    9d54:      	bl	0x9d54 <_stogir.verify.structure+0x30c>
		0000000000009d54:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    9d58:      	ubfx	x0, x0, #0, #32
    9d5c:      	lsr	x16, x0, #0
    9d60:      	cmp	x16, #0x1
    9d64:      	b.eq	0x9d80 <_stogir.verify.structure+0x338>
    9d68:      	b.lo	0x9d70 <_stogir.verify.structure+0x328>
    9d6c:      	b	0x9d84 <_stogir.verify.structure+0x33c>
    9d70:      	cmp	x16, #0x0
    9d74:      	b.eq	0x9d7c <_stogir.verify.structure+0x334>
    9d78:      	b	0x9d84 <_stogir.verify.structure+0x33c>
    9d7c:      	b	0x9d88 <_stogir.verify.structure+0x340>
    9d80:      	b	0x9e68 <_stogir.verify.structure+0x420>
    9d84:      	b	0xa28c <_stogir.verify.structure+0x844>
    9d88:      	ldr	x0, [sp, #0x58]
    9d8c:      	ldr	x2, [sp, #0x60]
    9d90:      	mov	w1, w21
    9d94:      	mov	w5, w24
    9d98:      	ldr	x3, [sp, #0x50]
    9d9c:      	ldr	x4, [sp, #0x48]
    9da0:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009da0:  ARM64_RELOC_PAGE21	l_stogir.461
    9da4:      	ldr	x16, [x16]
		0000000000009da4:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    9da8:      	str	x16, [sp, #0x38]
    9dac:      	mov	x16, #0x17              ; =23
    9db0:      	str	x16, [sp, #0x80]
    9db4:      	ldr	x6, [sp, #0x98]
    9db8:      	add	x6, x6, #0x1
    9dbc:      	sxtw	x6, w6
    9dc0:      	ldr	x28, [sp, #0x90]
    9dc4:      	str	x0, [sp, #0x58]
    9dc8:      	ldr	x19, [sp, #0x88]
    9dcc:      	ldr	w0, [sp, #0x68]
    9dd0:      	str	x2, [sp, #0x60]
    9dd4:      	ldr	x26, [sp, #0x78]
    9dd8:      	mov	w21, w1
    9ddc:      	mov	w24, w5
    9de0:      	mov	x1, x22
    9de4:      	ldr	x22, [sp, #0x70]
    9de8:      	str	x3, [sp, #0x50]
    9dec:      	str	x4, [sp, #0x48]
    9df0:      	mov	x2, x6
    9df4:      	ldr	x23, [sp, #0x80]
    9df8:      	cmp	x23, #0x0
    9dfc:      	b.ne	0x9e10 <_stogir.verify.structure+0x3c8>
    9e00:      	cmp	x2, x22
    9e04:      	cset	w3, le
    9e08:      	ubfx	x3, x3, #0, #8
    9e0c:      	b	0x9e14 <_stogir.verify.structure+0x3cc>
    9e10:      	movz	x3, #0x0, lsl #48
    9e14:      	cmp	x3, #0x0
    9e18:      	b.eq	0xa3b0 <_stogir.verify.structure+0x968>
    9e1c:      	orr	w3, w2, wzr
    9e20:      	sxtw	x4, w3
    9e24:      	sub	w5, w3, #0x1
    9e28:      	cmp	x4, #0x0
    9e2c:      	cset	w6, gt
    9e30:      	cmp	x4, #0x4
    9e34:      	cset	w7, gt
    9e38:      	uxtb	w16, w25
    9e3c:      	cmp	w16, wzr
    9e40:      	b.eq	0x9d10 <_stogir.verify.structure+0x2c8>
    9e44:      	ldr	w8, [x26]
    9e48:      	uxtb	w16, w6
    9e4c:      	cmp	w16, wzr
    9e50:      	b.eq	0x9d08 <_stogir.verify.structure+0x2c0>
    9e54:      	uxtb	w16, w7
    9e58:      	cmp	w16, wzr
    9e5c:      	b.eq	0x9cd8 <_stogir.verify.structure+0x290>
    9e60:      	mov	w9, #0x4                ; =4
    9e64:      	b	0x9cdc <_stogir.verify.structure+0x294>
    9e68:      	ubfx	x23, x23, #0, #32
    9e6c:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009e6c:  ARM64_RELOC_PAGE21	l_stogir.462
    9e70:      	ldr	x16, [x16]
		0000000000009e70:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    9e74:      	ldr	w0, [x16]
    9e78:      	cmp	x23, x0
    9e7c:      	b.ne	0x9e90 <_stogir.verify.structure+0x448>
    9e80:      	mov	x0, #0x1                ; =1
    9e84:      	b	0x9ea8 <_stogir.verify.structure+0x460>
    9e88:      	movz	x1, #0x0, lsl #48
    9e8c:      	b	0x9f08 <_stogir.verify.structure+0x4c0>
    9e90:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009e90:  ARM64_RELOC_PAGE21	l_stogir.463
    9e94:      	ldr	x16, [x16]
		0000000000009e94:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    9e98:      	ldr	w0, [x16]
    9e9c:      	cmp	x23, x0
    9ea0:      	cset	w0, eq
    9ea4:      	ubfx	x0, x0, #0, #8
    9ea8:      	cmp	x0, #0x0
    9eac:      	b.eq	0xa3d0 <_stogir.verify.structure+0x988>
    9eb0:      	str	w24, [sp, #0xa8]
    9eb4:      	mov	x24, x0
    9eb8:      	mov	x0, x20
    9ebc:      	str	w21, [sp, #0xb0]
    9ec0:      	mov	w21, w1
    9ec4:      	bl	0x9ec4 <_stogir.verify.structure+0x47c>
		0000000000009ec4:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    9ec8:      	cmp	x0, #0x0
    9ecc:      	cset	w1, eq
    9ed0:      	uxtb	w16, w1
    9ed4:      	cmp	w16, wzr
    9ed8:      	cset	x1, eq
    9edc:      	cmp	x1, #0x0
    9ee0:      	b.eq	0x9f08 <_stogir.verify.structure+0x4c0>
    9ee4:      	ldr	w0, [x0]
    9ee8:      	uxtb	w0, w0
    9eec:      	cmp	x0, #0x48
    9ef0:      	b.ne	0x9f08 <_stogir.verify.structure+0x4c0>
    9ef4:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009ef4:  ARM64_RELOC_PAGE21	l_stogir.464
    9ef8:      	ldr	x16, [x16]
		0000000000009ef8:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    9efc:      	str	x16, [sp, #0x38]
    9f00:      	mov	x16, #0x25              ; =37
    9f04:      	str	x16, [sp, #0x80]
    9f08:      	sxtw	x21, w21
    9f0c:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009f0c:  ARM64_RELOC_PAGE21	l_stogir.465
    9f10:      	ldr	x16, [x16]
		0000000000009f10:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    9f14:      	ldr	w0, [x16]
    9f18:      	cmp	x23, x0
    9f1c:      	b.ne	0xa3e4 <_stogir.verify.structure+0x99c>
    9f20:      	cmp	x21, #0x0
    9f24:      	b.gt	0xa0b4 <_stogir.verify.structure+0x66c>
    9f28:      	ldr	x2, [sp, #0x60]
    9f2c:      	movz	w0, #0x0, lsl #16
    9f30:      	ubfx	x0, x0, #0, #32
    9f34:      	lsr	x16, x0, #0
    9f38:      	cmp	x16, #0x1
    9f3c:      	b.eq	0x9f58 <_stogir.verify.structure+0x510>
    9f40:      	b.lo	0x9f48 <_stogir.verify.structure+0x500>
    9f44:      	b	0x9f5c <_stogir.verify.structure+0x514>
    9f48:      	cmp	x16, #0x0
    9f4c:      	b.eq	0x9f54 <_stogir.verify.structure+0x50c>
    9f50:      	b	0x9f5c <_stogir.verify.structure+0x514>
    9f54:      	b	0x9f60 <_stogir.verify.structure+0x518>
    9f58:      	b	0x9f74 <_stogir.verify.structure+0x52c>
    9f5c:      	b	0xa31c <_stogir.verify.structure+0x8d4>
    9f60:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009f60:  ARM64_RELOC_PAGE21	l_stogir.466
    9f64:      	ldr	x16, [x16]
		0000000000009f64:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    9f68:      	str	x16, [sp, #0x38]
    9f6c:      	mov	x16, #0x21              ; =33
    9f70:      	str	x16, [sp, #0x80]
    9f74:      	cmp	x23, #0xf
    9f78:      	b.hs	0xa3ec <_stogir.verify.structure+0x9a4>
    9f7c:      	mov	x16, #0x1               ; =1
    9f80:      	lsl	x0, x16, x23
    9f84:      	mov	w17, #0x5e1c            ; =24092
    9f88:      	and	w0, w0, w17
    9f8c:      	ubfx	x0, x0, #0, #32
    9f90:      	cmp	x0, #0x0
    9f94:      	b.eq	0xa404 <_stogir.verify.structure+0x9bc>
    9f98:      	cmp	x24, #0x0
    9f9c:      	b.eq	0xa1a0 <_stogir.verify.structure+0x758>
    9fa0:      	ldr	x0, [sp, #0x58]
    9fa4:      	ldr	x3, [sp, #0x50]
    9fa8:      	ldr	x4, [sp, #0x48]
    9fac:      	b	0x9cf4 <_stogir.verify.structure+0x2ac>
    9fb0:      	orr	w0, w28, wzr
    9fb4:      	cmp	x26, #0x78
    9fb8:      	cset	w21, eq
    9fbc:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009fbc:  ARM64_RELOC_PAGE21	l_stogir.467
    9fc0:      	ldr	x16, [x16]
		0000000000009fc0:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    9fc4:      	add	x1, x16, x26, lsl #2
    9fc8:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x268>
		0000000000009fc8:  ARM64_RELOC_PAGE21	l_stogir.467
    9fcc:      	ldr	x16, [x16]
		0000000000009fcc:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    9fd0:      	add	x2, x16, x26, lsl #2
    9fd4:      	cmp	x24, #0x0
    9fd8:      	cset	w24, eq
    9fdc:      	orr	x26, x1, xzr
    9fe0:      	orr	x1, x2, xzr
    9fe4:      	mov	x2, #0x1                ; =1
    9fe8:      	b	0x9df8 <_stogir.verify.structure+0x3b0>
    9fec:      	nop
    9ff0:      	movz	x1, #0x0, lsl #48
    9ff4:      	cmp	x1, #0x0
    9ff8:      	b.eq	0x9fb0 <_stogir.verify.structure+0x568>
    9ffc:      	add	x1, x0, x28
    a000:      	ldr	x2, [x20, #0x78]
    a004:      	add	x1, x2, x1, lsl #2
    a008:      	ldr	w1, [x1]
    a00c:      	sxtw	x1, w1
    a010:      	cmn	x1, #0x1
    a014:      	b.eq	0xa028 <_stogir.verify.structure+0x5e0>
    a018:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a018:  ARM64_RELOC_PAGE21	l_stogir.468
    a01c:      	ldr	x16, [x16]
		000000000000a01c:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    a020:      	str	x16, [sp, #0x38]
    a024:      	mov	x23, #0x1b              ; =27
    a028:      	add	x0, x0, #0x1
    a02c:      	cmp	x23, #0x0
    a030:      	b.ne	0x9ff0 <_stogir.verify.structure+0x5a8>
    a034:      	cmp	x0, x19
    a038:      	cset	w1, lt
    a03c:      	ubfx	x1, x1, #0, #8
    a040:      	b	0x9ff4 <_stogir.verify.structure+0x5ac>
    a044:      	mov	w0, w19
    a048:      	bl	0xa048 <_stogir.verify.structure+0x600>
		000000000000a048:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
    a04c:      	sxtw	x0, w0
    a050:      	cmn	x0, #0x1
    a054:      	b.ne	0xa074 <_stogir.verify.structure+0x62c>
    a058:      	ubfx	x0, x21, #16, #16
    a05c:      	cmp	x22, x0
    a060:      	b.eq	0xa074 <_stogir.verify.structure+0x62c>
    a064:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a064:  ARM64_RELOC_PAGE21	l_stogir.469
    a068:      	ldr	x16, [x16]
		000000000000a068:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a06c:      	str	x16, [sp, #0x38]
    a070:      	mov	x23, #0x24              ; =36
    a074:      	add	x0, x22, #0x4
    a078:      	ldr	x1, [x20, #0x8]
    a07c:      	asr	x16, x0, #63
    a080:      	lsr	x16, x16, #62
    a084:      	add	x0, x0, x16
    a088:      	asr	x0, x0, #2
    a08c:      	orr	x19, x0, xzr
    a090:      	add	x0, x19, x28
    a094:      	cmp	x0, x1
    a098:      	b.le	0xa0ac <_stogir.verify.structure+0x664>
    a09c:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a09c:  ARM64_RELOC_PAGE21	l_stogir.470
    a0a0:      	ldr	x16, [x16]
		000000000000a0a0:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    a0a4:      	str	x16, [sp, #0x38]
    a0a8:      	mov	x23, #0x15              ; =21
    a0ac:      	mov	x0, #0x1                ; =1
    a0b0:      	b	0xa02c <_stogir.verify.structure+0x5e4>
    a0b4:      	ldr	x0, [x27, #0x8]
    a0b8:      	cmp	x21, x0
    a0bc:      	b.gt	0xa41c <_stogir.verify.structure+0x9d4>
    a0c0:      	sub	x0, x21, #0x1
    a0c4:      	ldr	x2, [sp, #0x60]
    a0c8:      	ldr	x3, [x2, #0x28]
    a0cc:      	mov	x17, #0x18              ; =24
    a0d0:      	mul	x0, x0, x17
    a0d4:      	add	x0, x0, x3
    a0d8:      	ldr	x3, [x0]
    a0dc:      	ldr	x0, [x0, #0x8]
    a0e0:      	ldr	x4, [x2, #0x8]
    a0e4:      	cmp	x3, #0x0
    a0e8:      	b.lt	0xa110 <_stogir.verify.structure+0x6c8>
    a0ec:      	cmp	x3, x4
    a0f0:      	b.gt	0xa110 <_stogir.verify.structure+0x6c8>
    a0f4:      	cmp	x0, #0x0
    a0f8:      	b.lt	0xa110 <_stogir.verify.structure+0x6c8>
    a0fc:      	sub	x3, x4, x3
    a100:      	cmp	x0, x3
    a104:      	b.gt	0xa110 <_stogir.verify.structure+0x6c8>
    a108:      	mov	w0, #0x1                ; =1
    a10c:      	b	0xa114 <_stogir.verify.structure+0x6cc>
    a110:      	movz	w0, #0x0, lsl #16
    a114:      	b	0x9f30 <_stogir.verify.structure+0x4e8>
    a118:      	mov	w0, #-0x2               ; =-2
    a11c:      	sxtw	x0, w0
    a120:      	cmp	x22, x0
    a124:      	b.eq	0xa044 <_stogir.verify.structure+0x5fc>
    a128:      	ldr	x0, [sp, #0x58]
    a12c:      	ldr	x2, [sp, #0x60]
    a130:      	ldr	x3, [sp, #0x50]
    a134:      	ldr	x4, [sp, #0x48]
    a138:      	mov	x5, x28
    a13c:      	ldr	x19, [sp, #0x40]
    a140:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a140:  ARM64_RELOC_PAGE21	l_stogir.471
    a144:      	ldr	x16, [x16]
		000000000000a144:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    a148:      	str	x16, [sp, #0x38]
    a14c:      	mov	x16, #0x23              ; =35
    a150:      	str	x16, [sp, #0x80]
    a154:      	b	0x9acc <_stogir.verify.structure+0x84>
    a158:      	cmp	x21, #0x0
    a15c:      	b.ne	0xa424 <_stogir.verify.structure+0x9dc>
    a160:      	uxtb	w16, w25
    a164:      	cmp	w16, wzr
    a168:      	b.eq	0xa294 <_stogir.verify.structure+0x84c>
    a16c:      	ldr	w1, [x22]
    a170:      	uxtb	w16, w28
    a174:      	cmp	w16, wzr
    a178:      	b.eq	0xa2dc <_stogir.verify.structure+0x894>
    a17c:      	uxtb	w16, w26
    a180:      	cmp	w16, wzr
    a184:      	b.eq	0xa18c <_stogir.verify.structure+0x744>
    a188:      	mov	w19, #0x4               ; =4
    a18c:      	lsl	w5, w19, #2
    a190:      	ubfx	x5, x5, #0, #32
    a194:      	lsr	x1, x1, x5
    a198:      	and	w1, w1, #0xf
    a19c:      	b	0xa2e0 <_stogir.verify.structure+0x898>
    a1a0:      	cmp	x21, #0x0
    a1a4:      	b.le	0xa430 <_stogir.verify.structure+0x9e8>
    a1a8:      	ldr	x0, [x20, #0x8]
    a1ac:      	cmp	x21, x0
    a1b0:      	b.ge	0xa438 <_stogir.verify.structure+0x9f0>
    a1b4:      	ldr	x0, [sp, #0x58]
    a1b8:      	ldr	x1, [x0, #0x8]
    a1bc:      	cmp	x21, x1
    a1c0:      	b.ge	0xa2ec <_stogir.verify.structure+0x8a4>
    a1c4:      	ldr	x1, [x20, #0x78]
    a1c8:      	add	x1, x1, x21, lsl #2
    a1cc:      	ldr	w1, [x1]
    a1d0:      	sxtw	x1, w1
    a1d4:      	cmp	x1, #0x0
    a1d8:      	cset	w1, ge
    a1dc:      	ubfx	x1, x1, #0, #8
    a1e0:      	b	0xa2f0 <_stogir.verify.structure+0x8a8>
    a1e4:      	ldr	w1, [sp, #0xb0]
    a1e8:      	uxtb	w16, w1
    a1ec:      	cmp	w16, wzr
    a1f0:      	b.eq	0xa440 <_stogir.verify.structure+0x9f8>
    a1f4:      	ldr	w5, [sp, #0xa8]
    a1f8:      	uxtb	w16, w5
    a1fc:      	cmp	w16, wzr
    a200:      	b.eq	0xa210 <_stogir.verify.structure+0x7c8>
    a204:      	ldr	x6, [sp, #0xa0]
    a208:      	cmp	x6, #0x2
    a20c:      	b.eq	0x9d04 <_stogir.verify.structure+0x2bc>
    a210:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a210:  ARM64_RELOC_PAGE21	l_stogir.472
    a214:      	ldr	x16, [x16]
		000000000000a214:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    a218:      	str	x16, [sp, #0x38]
    a21c:      	mov	x16, #0x1a              ; =26
    a220:      	str	x16, [sp, #0x80]
    a224:      	b	0x9d04 <_stogir.verify.structure+0x2bc>
    a228:      	movz	x1, #0x0, lsl #48
    a22c:      	ldr	x3, [sp, #0x50]
    a230:      	ldr	x4, [sp, #0x48]
    a234:      	b	0x9cf4 <_stogir.verify.structure+0x2ac>
    a238:      	cmp	x21, #0x0
    a23c:      	b.ge	0xa448 <_stogir.verify.structure+0xa00>
    a240:      	ldr	x3, [sp, #0x50]
    a244:      	ldr	x1, [x3, #0x8]
    a248:      	ldr	x4, [sp, #0x48]
    a24c:      	ldr	x5, [x4, #0x8]
    a250:      	cmp	x1, x5
    a254:      	b.ne	0xa2e4 <_stogir.verify.structure+0x89c>
    a258:      	movz	x16, #0x0, lsl #48
    a25c:      	sub	x5, x16, x21
    a260:      	cmp	x5, x1
    a264:      	b.gt	0xa314 <_stogir.verify.structure+0x8cc>
    a268:      	sub	x1, x5, #0x1
    a26c:      	ldr	x5, [x20, #0x50]
    a270:      	add	x1, x5, x1, lsl #2
    a274:      	ldr	w1, [x1]
    a278:      	sxtw	x1, w1
    a27c:      	cmp	x1, #0x0
    a280:      	cset	w1, gt
    a284:      	ubfx	x1, x1, #0, #8
    a288:      	b	0xa318 <_stogir.verify.structure+0x8d0>
    a28c:      	brk	#0
    a290:      	b	0xa28c <_stogir.verify.structure+0x844>
    a294:      	movz	w1, #0x0, lsl #16
    a298:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a298:  ARM64_RELOC_PAGE21	l_stogir.473
    a29c:      	ldr	x16, [x16]
		000000000000a29c:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    a2a0:      	ldr	w5, [x16]
    a2a4:      	ubfx	x1, x1, #0, #32
    a2a8:      	cmp	x1, x5
    a2ac:      	b.ne	0xa2bc <_stogir.verify.structure+0x874>
    a2b0:      	ldr	w1, [sp, #0xb0]
    a2b4:      	ldr	w5, [sp, #0xa8]
    a2b8:      	b	0x9d04 <_stogir.verify.structure+0x2bc>
    a2bc:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a2bc:  ARM64_RELOC_PAGE21	l_stogir.474
    a2c0:      	ldr	x16, [x16]
		000000000000a2c0:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    a2c4:      	ldr	w5, [x16]
    a2c8:      	cmp	x1, x5
    a2cc:      	b.ne	0xa2f4 <_stogir.verify.structure+0x8ac>
    a2d0:      	ldr	w1, [sp, #0xb0]
    a2d4:      	ldr	w5, [sp, #0xa8]
    a2d8:      	b	0x9d04 <_stogir.verify.structure+0x2bc>
    a2dc:      	movz	w1, #0x0, lsl #16
    a2e0:      	b	0xa298 <_stogir.verify.structure+0x850>
    a2e4:      	movz	x1, #0x0, lsl #48
    a2e8:      	b	0x9cf4 <_stogir.verify.structure+0x2ac>
    a2ec:      	movz	x1, #0x0, lsl #48
    a2f0:      	b	0xa22c <_stogir.verify.structure+0x7e4>
    a2f4:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a2f4:  ARM64_RELOC_PAGE21	l_stogir.475
    a2f8:      	ldr	x16, [x16]
		000000000000a2f8:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    a2fc:      	ldr	w5, [x16]
    a300:      	cmp	x1, x5
    a304:      	b.ne	0xa1e4 <_stogir.verify.structure+0x79c>
    a308:      	ldr	w1, [sp, #0xb0]
    a30c:      	ldr	w5, [sp, #0xa8]
    a310:      	b	0x9d04 <_stogir.verify.structure+0x2bc>
    a314:      	movz	x1, #0x0, lsl #48
    a318:      	b	0xa2e8 <_stogir.verify.structure+0x8a0>
    a31c:      	brk	#0
    a320:      	b	0xa31c <_stogir.verify.structure+0x8d4>
    a324:      	str	x19, [sp, #0x30]
    a328:      	mov	x19, x0
    a32c:      	str	x22, [sp, #0x38]
    a330:      	str	x23, [sp, #0x80]
    a334:      	b	0x9c54 <_stogir.verify.structure+0x20c>
    a338:      	str	x19, [sp, #0x30]
    a33c:      	mov	x19, x0
    a340:      	str	x22, [sp, #0x38]
    a344:      	str	x23, [sp, #0x80]
    a348:      	b	0x9c54 <_stogir.verify.structure+0x20c>
    a34c:      	mov	x5, x28
    a350:      	str	x19, [sp, #0x30]
    a354:      	mov	x19, x0
    a358:      	mov	x0, x21
    a35c:      	mov	x2, x24
    a360:      	mov	x3, x25
    a364:      	mov	x4, x26
    a368:      	b	0x9b2c <_stogir.verify.structure+0xe4>
    a36c:      	mov	x5, x28
    a370:      	str	x19, [sp, #0x30]
    a374:      	mov	x19, x0
    a378:      	mov	x0, x21
    a37c:      	mov	x2, x24
    a380:      	mov	x3, x25
    a384:      	mov	x4, x26
    a388:      	b	0x9af8 <_stogir.verify.structure+0xb0>
    a38c:      	mov	x5, x28
    a390:      	ldr	x19, [sp, #0x40]
    a394:      	ldr	x0, [sp, #0x58]
    a398:      	ldr	x2, [sp, #0x60]
    a39c:      	ldr	x3, [sp, #0x50]
    a3a0:      	ldr	x4, [sp, #0x48]
    a3a4:      	b	0x9af8 <_stogir.verify.structure+0xb0>
    a3a8:      	ldr	x0, [sp, #0x38]
    a3ac:      	b	0x9c88 <_stogir.verify.structure+0x240>
    a3b0:      	str	x28, [sp, #0x90]
    a3b4:      	ldr	x0, [sp, #0x58]
    a3b8:      	str	x19, [sp, #0x88]
    a3bc:      	ldr	x2, [sp, #0x60]
    a3c0:      	str	x23, [sp, #0x80]
    a3c4:      	ldr	x3, [sp, #0x50]
    a3c8:      	ldr	x4, [sp, #0x48]
    a3cc:      	b	0x9ab4 <_stogir.verify.structure+0x6c>
    a3d0:      	str	w21, [sp, #0xb0]
    a3d4:      	mov	w21, w1
    a3d8:      	str	w24, [sp, #0xa8]
    a3dc:      	mov	x24, x0
    a3e0:      	b	0x9e88 <_stogir.verify.structure+0x440>
    a3e4:      	ldr	x2, [sp, #0x60]
    a3e8:      	b	0x9f74 <_stogir.verify.structure+0x52c>
    a3ec:      	ldr	x0, [sp, #0x58]
    a3f0:      	ldr	w1, [sp, #0xb0]
    a3f4:      	ldr	w5, [sp, #0xa8]
    a3f8:      	ldr	x3, [sp, #0x50]
    a3fc:      	ldr	x4, [sp, #0x48]
    a400:      	b	0x9d04 <_stogir.verify.structure+0x2bc>
    a404:      	ldr	x0, [sp, #0x58]
    a408:      	ldr	w1, [sp, #0xb0]
    a40c:      	ldr	w5, [sp, #0xa8]
    a410:      	ldr	x3, [sp, #0x50]
    a414:      	ldr	x4, [sp, #0x48]
    a418:      	b	0x9d04 <_stogir.verify.structure+0x2bc>
    a41c:      	ldr	x2, [sp, #0x60]
    a420:      	b	0x9f2c <_stogir.verify.structure+0x4e4>
    a424:      	ldr	w1, [sp, #0xb0]
    a428:      	ldr	w5, [sp, #0xa8]
    a42c:      	b	0xa210 <_stogir.verify.structure+0x7c8>
    a430:      	ldr	x0, [sp, #0x58]
    a434:      	b	0xa238 <_stogir.verify.structure+0x7f0>
    a438:      	ldr	x0, [sp, #0x58]
    a43c:      	b	0xa228 <_stogir.verify.structure+0x7e0>
    a440:      	ldr	w5, [sp, #0xa8]
    a444:      	b	0xa210 <_stogir.verify.structure+0x7c8>
    a448:      	ldr	x3, [sp, #0x50]
    a44c:      	ldr	x4, [sp, #0x48]
    a450:      	b	0x9cf0 <_stogir.verify.structure+0x2a8>
    a454:      	udf	#0x0

000000000000a458 <_stogir.verify.schedule-input-structured>:
    a458:      	sub	sp, sp, #0x40
    a45c:      	str	x29, [sp]
    a460:      	str	x30, [sp, #0x8]
    a464:      	mov	x29, sp
    a468:      	str	x19, [sp, #0x30]
    a46c:      	sxtw	x1, w1
    a470:      	add	x4, x0, #0x28
    a474:      	add	x5, x0, #0x78
    a478:      	cmp	x1, #0x0
    a47c:      	cset	w6, gt
    a480:      	movz	x16, #0x0, lsl #48
    a484:      	sub	x7, x16, x1
    a488:      	sub	x9, x7, #0x1
    a48c:      	uxtb	w16, w6
    a490:      	cmp	w16, wzr
    a494:      	b.eq	0xa4d0 <_stogir.verify.schedule-input-structured+0x78>
    a498:      	ldr	x4, [x0, #0x8]
    a49c:      	cmp	x1, x4
    a4a0:      	b.ge	0xa51c <_stogir.verify.schedule-input-structured+0xc4>
    a4a4:      	ldr	x4, [x5, #0x8]
    a4a8:      	cmp	x1, x4
    a4ac:      	b.ge	0xa6f4 <_stogir.verify.schedule-input-structured+0x29c>
    a4b0:      	ldr	x4, [x0, #0x78]
    a4b4:      	add	x4, x4, x1, lsl #2
    a4b8:      	ldr	w4, [x4]
    a4bc:      	sxtw	x4, w4
    a4c0:      	cmp	x4, #0x0
    a4c4:      	cset	w4, ge
    a4c8:      	ubfx	x4, x4, #0, #8
    a4cc:      	b	0xa6f8 <_stogir.verify.schedule-input-structured+0x2a0>
    a4d0:      	cmp	x1, #0x0
    a4d4:      	b.ge	0xa524 <_stogir.verify.schedule-input-structured+0xcc>
    a4d8:      	add	x10, x0, #0x50
    a4dc:      	ldr	x4, [x4, #0x8]
    a4e0:      	ldr	x10, [x10, #0x8]
    a4e4:      	cmp	x4, x10
    a4e8:      	b.ne	0xa514 <_stogir.verify.schedule-input-structured+0xbc>
    a4ec:      	cmp	x7, x4
    a4f0:      	b.gt	0xa6fc <_stogir.verify.schedule-input-structured+0x2a4>
    a4f4:      	ldr	x4, [x0, #0x50]
    a4f8:      	add	x4, x4, x9, lsl #2
    a4fc:      	ldr	w4, [x4]
    a500:      	sxtw	x4, w4
    a504:      	cmp	x4, #0x0
    a508:      	cset	w4, gt
    a50c:      	ubfx	x4, x4, #0, #8
    a510:      	b	0xa700 <_stogir.verify.schedule-input-structured+0x2a8>
    a514:      	movz	x4, #0x0, lsl #48
    a518:      	b	0xa528 <_stogir.verify.schedule-input-structured+0xd0>
    a51c:      	movz	x4, #0x0, lsl #48
    a520:      	b	0xa528 <_stogir.verify.schedule-input-structured+0xd0>
    a524:      	movz	x4, #0x0, lsl #48
    a528:      	cmp	x4, #0x0
    a52c:      	b.eq	0xa560 <_stogir.verify.schedule-input-structured+0x108>
    a530:      	uxtb	w16, w6
    a534:      	cmp	w16, wzr
    a538:      	b.eq	0xa54c <_stogir.verify.schedule-input-structured+0xf4>
    a53c:      	ldr	x4, [x0]
    a540:      	add	x4, x4, x1, lsl #4
    a544:      	ldr	x4, [x4]
    a548:      	b	0xa558 <_stogir.verify.schedule-input-structured+0x100>
    a54c:      	ldr	x4, [x0, #0x28]
    a550:      	add	x4, x4, x9, lsl #4
    a554:      	ldr	x4, [x4]
    a558:      	mov	w6, #0x1                ; =1
    a55c:      	b	0xa568 <_stogir.verify.schedule-input-structured+0x110>
    a560:      	movz	w6, #0x0, lsl #16
    a564:      	movz	x4, #0x0, lsl #48
    a568:      	ubfx	x6, x6, #0, #32
    a56c:      	lsr	x16, x6, #0
    a570:      	cmp	x16, #0x1
    a574:      	b.eq	0xa590 <_stogir.verify.schedule-input-structured+0x138>
    a578:      	b.lo	0xa580 <_stogir.verify.schedule-input-structured+0x128>
    a57c:      	b	0xa594 <_stogir.verify.schedule-input-structured+0x13c>
    a580:      	cmp	x16, #0x0
    a584:      	b.eq	0xa58c <_stogir.verify.schedule-input-structured+0x134>
    a588:      	b	0xa594 <_stogir.verify.schedule-input-structured+0x13c>
    a58c:      	b	0xa598 <_stogir.verify.schedule-input-structured+0x140>
    a590:      	b	0xa6cc <_stogir.verify.schedule-input-structured+0x274>
    a594:      	b	0xa74c <_stogir.verify.schedule-input-structured+0x2f4>
    a598:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a598:  ARM64_RELOC_PAGE21	l_stogir.476
    a59c:      	ldr	x1, [x1]
		000000000000a59c:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    a5a0:      	mov	x4, #0xd                ; =13
    a5a4:      	b	0xa5b4 <_stogir.verify.schedule-input-structured+0x15c>
    a5a8:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a5a8:  ARM64_RELOC_PAGE21	l_stogir.477
    a5ac:      	ldr	x1, [x1]
		000000000000a5ac:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    a5b0:      	mov	x4, #0x1b               ; =27
    a5b4:      	cmp	x3, #0x0
    a5b8:      	b.ne	0xa5c8 <_stogir.verify.schedule-input-structured+0x170>
    a5bc:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a5bc:  ARM64_RELOC_PAGE21	l_stogir.478
    a5c0:      	ldr	x1, [x1]
		000000000000a5c0:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    a5c4:      	mov	x4, #0x25               ; =37
    a5c8:      	movz	x6, #0x0, lsl #48
    a5cc:      	b	0xa650 <_stogir.verify.schedule-input-structured+0x1f8>
    a5d0:      	movz	w7, #0x0, lsl #16
    a5d4:      	movz	w9, #0x0, lsl #16
    a5d8:      	ubfx	x7, x7, #0, #32
    a5dc:      	lsr	x16, x7, #0
    a5e0:      	cmp	x16, #0x1
    a5e4:      	b.eq	0xa600 <_stogir.verify.schedule-input-structured+0x1a8>
    a5e8:      	b.lo	0xa5f0 <_stogir.verify.schedule-input-structured+0x198>
    a5ec:      	b	0xa604 <_stogir.verify.schedule-input-structured+0x1ac>
    a5f0:      	cmp	x16, #0x0
    a5f4:      	b.eq	0xa5fc <_stogir.verify.schedule-input-structured+0x1a4>
    a5f8:      	b	0xa604 <_stogir.verify.schedule-input-structured+0x1ac>
    a5fc:      	b	0xa678 <_stogir.verify.schedule-input-structured+0x220>
    a600:      	b	0xa608 <_stogir.verify.schedule-input-structured+0x1b0>
    a604:      	b	0xa744 <_stogir.verify.schedule-input-structured+0x2ec>
    a608:      	sxtw	x9, w9
    a60c:      	cmp	x9, #0x0
    a610:      	b.le	0xa644 <_stogir.verify.schedule-input-structured+0x1ec>
    a614:      	ldr	x7, [x0, #0x8]
    a618:      	cmp	x9, x7
    a61c:      	b.ge	0xa644 <_stogir.verify.schedule-input-structured+0x1ec>
    a620:      	ldr	x7, [x5, #0x8]
    a624:      	cmp	x9, x7
    a628:      	b.ge	0xa644 <_stogir.verify.schedule-input-structured+0x1ec>
    a62c:      	ldr	x7, [x0, #0x78]
    a630:      	add	x7, x7, x9, lsl #2
    a634:      	ldr	w7, [x7]
    a638:      	sxtw	x7, w7
    a63c:      	cmp	x7, #0x0
    a640:      	b.ge	0xa650 <_stogir.verify.schedule-input-structured+0x1f8>
    a644:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a644:  ARM64_RELOC_PAGE21	l_stogir.479
    a648:      	ldr	x1, [x1]
		000000000000a648:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    a64c:      	mov	x4, #0x16               ; =22
    a650:      	cmp	x6, x3
    a654:      	b.ge	0xa5d0 <_stogir.verify.schedule-input-structured+0x178>
    a658:      	add	x7, x6, #0x1
    a65c:      	add	x6, x2, x6, lsl #2
    a660:      	ldr	w6, [x6]
    a664:      	movn	w17, #0x0, lsl #16
    a668:      	and	w9, w6, w17
    a66c:      	mov	x6, x7
    a670:      	mov	w7, #0x1                ; =1
    a674:      	b	0xa5d8 <_stogir.verify.schedule-input-structured+0x180>
    a678:      	cmp	x4, #0x0
    a67c:      	b.ne	0xa754 <_stogir.verify.schedule-input-structured+0x2fc>
    a680:      	mov	x19, x8
    a684:      	add	x8, sp, #0x10
    a688:      	bl	0xa688 <_stogir.verify.schedule-input-structured+0x230>
		000000000000a688:  ARM64_RELOC_BRANCH26	_stogir.verify.phis-structured
    a68c:      	add	x16, sp, #0x10
    a690:      	ldr	x0, [x16]
    a694:      	add	x16, sp, #0x10
    a698:      	ldr	x1, [x16, #0x8]
    a69c:      	add	x16, sp, #0x10
    a6a0:      	ldr	x4, [x16, #0x10]
    a6a4:      	b	0xa6ac <_stogir.verify.schedule-input-structured+0x254>
    a6a8:      	mov	x0, #0x1                ; =1
    a6ac:      	str	x0, [x19]
    a6b0:      	str	x1, [x19, #0x8]
    a6b4:      	str	x4, [x19, #0x10]
    a6b8:      	ldr	x19, [sp, #0x30]
    a6bc:      	ldr	x29, [sp]
    a6c0:      	ldr	x30, [sp, #0x8]
    a6c4:      	add	sp, sp, #0x40
    a6c8:      	ret
    a6cc:      	cmp	x1, #0x0
    a6d0:      	b.le	0xa5a8 <_stogir.verify.schedule-input-structured+0x150>
    a6d4:      	uxtb	w4, w4
    a6d8:      	cmp	x4, #0x83
    a6dc:      	b.ge	0xa704 <_stogir.verify.schedule-input-structured+0x2ac>
    a6e0:      	adrp	x17, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a6e0:  ARM64_RELOC_PAGE21	l_stogir.480
    a6e4:      	ldr	x17, [x17]
		000000000000a6e4:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    a6e8:      	add	x1, x4, x17
    a6ec:      	ldrb	w1, [x1]
    a6f0:      	b	0xa708 <_stogir.verify.schedule-input-structured+0x2b0>
    a6f4:      	movz	x4, #0x0, lsl #48
    a6f8:      	b	0xa520 <_stogir.verify.schedule-input-structured+0xc8>
    a6fc:      	movz	x4, #0x0, lsl #48
    a700:      	b	0xa518 <_stogir.verify.schedule-input-structured+0xc0>
    a704:      	movz	w1, #0x0, lsl #16
    a708:      	uxtb	w16, w1
    a70c:      	and	w1, w16, #0x2
    a710:      	uxtb	w1, w1
    a714:      	ubfx	x1, x1, #0, #8
    a718:      	cmp	x1, #0x0
    a71c:      	cset	w1, eq
    a720:      	uxtb	w16, w1
    a724:      	cmp	w16, wzr
    a728:      	cset	x1, eq
    a72c:      	cmp	x1, #0x0
    a730:      	b.eq	0xa5a8 <_stogir.verify.schedule-input-structured+0x150>
    a734:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a734:  ARM64_RELOC_PAGE21	l_stogir.481
    a738:      	ldr	x1, [x1]
		000000000000a738:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    a73c:      	movz	x4, #0x0, lsl #48
    a740:      	b	0xa5b4 <_stogir.verify.schedule-input-structured+0x15c>
    a744:      	brk	#0
    a748:      	b	0xa744 <_stogir.verify.schedule-input-structured+0x2ec>
    a74c:      	brk	#0
    a750:      	b	0xa74c <_stogir.verify.schedule-input-structured+0x2f4>
    a754:      	mov	x19, x8
    a758:      	b	0xa6a8 <_stogir.verify.schedule-input-structured+0x250>

000000000000a75c <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
    a75c:      	ldr	x0, [x0, #0x8]
    a760:      	ret

000000000000a764 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    a764:      	ldr	x0, [x0, #0x8]
    a768:      	ret

000000000000a76c <_stogir.verify.control-sources>:
    a76c:      	sub	sp, sp, #0x40
    a770:      	str	x29, [sp]
    a774:      	str	x30, [sp, #0x8]
    a778:      	mov	x29, sp
    a77c:      	str	x19, [sp, #0x30]
    a780:      	str	x20, [sp, #0x38]
    a784:      	mov	x19, x8
    a788:      	add	x8, sp, #0x10
    a78c:      	mov	x20, x0
    a790:      	bl	0xa790 <_stogir.verify.control-sources+0x24>
		000000000000a790:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    a794:      	add	x16, sp, #0x10
    a798:      	ldr	w0, [x16]
    a79c:      	lsr	x16, x0, #0
    a7a0:      	cmp	x16, #0x1
    a7a4:      	b.eq	0xa7c0 <_stogir.verify.control-sources+0x54>
    a7a8:      	b.lo	0xa7b0 <_stogir.verify.control-sources+0x44>
    a7ac:      	b	0xa7c4 <_stogir.verify.control-sources+0x58>
    a7b0:      	cmp	x16, #0x0
    a7b4:      	b.eq	0xa7bc <_stogir.verify.control-sources+0x50>
    a7b8:      	b	0xa7c4 <_stogir.verify.control-sources+0x58>
    a7bc:      	b	0xa810 <_stogir.verify.control-sources+0xa4>
    a7c0:      	b	0xa7c8 <_stogir.verify.control-sources+0x5c>
    a7c4:      	b	0xabc8 <_stogir.verify.control-sources+0x45c>
    a7c8:      	add	x16, sp, #0x10
    a7cc:      	orr	x0, x16, xzr
    a7d0:      	add	x0, x0, #0x8
    a7d4:      	add	x16, sp, #0x10
    a7d8:      	ldr	x1, [x16, #0x8]
    a7dc:      	ldr	x0, [x0, #0x8]
    a7e0:      	mov	x2, #0x1                ; =1
    a7e4:      	b	0xa7ec <_stogir.verify.control-sources+0x80>
    a7e8:      	mov	x2, #0x1                ; =1
    a7ec:      	str	x2, [x19]
    a7f0:      	str	x1, [x19, #0x8]
    a7f4:      	str	x0, [x19, #0x10]
    a7f8:      	ldr	x19, [sp, #0x30]
    a7fc:      	ldr	x20, [sp, #0x38]
    a800:      	ldr	x29, [sp]
    a804:      	ldr	x30, [sp, #0x8]
    a808:      	add	sp, sp, #0x40
    a80c:      	ret
    a810:      	add	x2, x20, #0x78
    a814:      	mov	x3, #0x1                ; =1
    a818:      	movz	x4, #0x0, lsl #48
    a81c:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a81c:  ARM64_RELOC_PAGE21	l_stogir.482
    a820:      	ldr	x1, [x1]
		000000000000a820:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    a824:      	movz	x0, #0x0, lsl #48
    a828:      	b	0xaa98 <_stogir.verify.control-sources+0x32c>
    a82c:      	movz	w12, #0x0, lsl #16
    a830:      	uxtb	w16, w12
    a834:      	and	w12, w16, #0x1
    a838:      	uxtb	w12, w12
    a83c:      	ubfx	x12, x12, #0, #8
    a840:      	cmp	x12, #0x0
    a844:      	b.ne	0xa854 <_stogir.verify.control-sources+0xe8>
    a848:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a848:  ARM64_RELOC_PAGE21	l_stogir.483
    a84c:      	ldr	x1, [x1]
		000000000000a84c:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    a850:      	mov	x0, #0x1d               ; =29
    a854:      	b	0xaa00 <_stogir.verify.control-sources+0x294>
    a858:      	movz	x5, #0x0, lsl #48
    a85c:      	cmp	x5, #0x0
    a860:      	b.eq	0xaba0 <_stogir.verify.control-sources+0x434>
    a864:      	orr	w5, w3, wzr
    a868:      	ldr	x6, [x20]
    a86c:      	sxtw	x5, w5
    a870:      	cmp	x5, #0x0
    a874:      	cset	w7, le
    a878:      	lsl	x8, x5, #2
    a87c:      	add	x6, x6, x3, lsl #4
    a880:      	ldr	x6, [x6]
    a884:      	ldr	x9, [x20, #0x78]
    a888:      	uxtb	w6, w6
    a88c:      	add	x9, x9, x3, lsl #2
    a890:      	cmp	x6, #0x83
    a894:      	cset	w10, lt
    a898:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a898:  ARM64_RELOC_PAGE21	l_stogir.484
    a89c:      	ldr	x16, [x16]
		000000000000a89c:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    a8a0:      	add	x6, x16, x6, lsl #2
    a8a4:      	ldr	w9, [x9]
    a8a8:      	sxtw	x9, w9
    a8ac:      	mov	x11, #0x1               ; =1
    a8b0:      	b	0xa92c <_stogir.verify.control-sources+0x1c0>
    a8b4:      	movz	w13, #0x0, lsl #16
    a8b8:      	movz	w12, #0x0, lsl #16
    a8bc:      	b	0xa8e0 <_stogir.verify.control-sources+0x174>
    a8c0:      	sub	w12, w12, #0x1
    a8c4:      	lsl	w12, w12, #2
    a8c8:      	ubfx	x12, x12, #0, #32
    a8cc:      	lsr	x12, x14, x12
    a8d0:      	and	w12, w12, #0xf
    a8d4:      	b	0xa984 <_stogir.verify.control-sources+0x218>
    a8d8:      	movz	w13, #0x0, lsl #16
    a8dc:      	movz	w12, #0x0, lsl #16
    a8e0:      	ubfx	x13, x13, #0, #32
    a8e4:      	lsr	x16, x13, #0
    a8e8:      	cmp	x16, #0x1
    a8ec:      	b.eq	0xa908 <_stogir.verify.control-sources+0x19c>
    a8f0:      	b.lo	0xa8f8 <_stogir.verify.control-sources+0x18c>
    a8f4:      	b	0xa90c <_stogir.verify.control-sources+0x1a0>
    a8f8:      	cmp	x16, #0x0
    a8fc:      	b.eq	0xa904 <_stogir.verify.control-sources+0x198>
    a900:      	b	0xa90c <_stogir.verify.control-sources+0x1a0>
    a904:      	b	0xa910 <_stogir.verify.control-sources+0x1a4>
    a908:      	b	0xa9e8 <_stogir.verify.control-sources+0x27c>
    a90c:      	b	0xabb8 <_stogir.verify.control-sources+0x44c>
    a910:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a910:  ARM64_RELOC_PAGE21	l_stogir.485
    a914:      	ldr	x1, [x1]
		000000000000a914:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    a918:      	mov	x0, #0x16               ; =22
    a91c:      	add	x4, x4, #0x1
    a920:      	sxtw	x4, w4
    a924:      	add	x11, x11, #0x1
    a928:      	sxtw	x11, w11
    a92c:      	cmp	x0, #0x0
    a930:      	b.ne	0xa944 <_stogir.verify.control-sources+0x1d8>
    a934:      	cmp	x11, x9
    a938:      	cset	w12, le
    a93c:      	ubfx	x12, x12, #0, #8
    a940:      	b	0xa948 <_stogir.verify.control-sources+0x1dc>
    a944:      	movz	x12, #0x0, lsl #48
    a948:      	cmp	x12, #0x0
    a94c:      	b.eq	0xaa80 <_stogir.verify.control-sources+0x314>
    a950:      	orr	w12, w11, wzr
    a954:      	sxtw	x13, w12
    a958:      	uxtb	w16, w10
    a95c:      	cmp	w16, wzr
    a960:      	b.eq	0xa988 <_stogir.verify.control-sources+0x21c>
    a964:      	ldr	w14, [x6]
    a968:      	cmp	x13, #0x0
    a96c:      	b.le	0xa980 <_stogir.verify.control-sources+0x214>
    a970:      	cmp	x13, #0x4
    a974:      	b.le	0xa8c0 <_stogir.verify.control-sources+0x154>
    a978:      	mov	w12, #0x4               ; =4
    a97c:      	b	0xa8c4 <_stogir.verify.control-sources+0x158>
    a980:      	movz	w12, #0x0, lsl #16
    a984:      	b	0xa98c <_stogir.verify.control-sources+0x220>
    a988:      	movz	w12, #0x0, lsl #16
    a98c:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a98c:  ARM64_RELOC_PAGE21	l_stogir.486
    a990:      	ldr	x16, [x16]
		000000000000a990:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    a994:      	ldr	w14, [x16]
    a998:      	ubfx	x12, x12, #0, #32
    a99c:      	cmp	x12, x14
    a9a0:      	b.ne	0xa924 <_stogir.verify.control-sources+0x1b8>
    a9a4:      	uxtb	w16, w7
    a9a8:      	cmp	w16, wzr
    a9ac:      	b.ne	0xa8d8 <_stogir.verify.control-sources+0x16c>
    a9b0:      	ldr	x12, [x20, #0x8]
    a9b4:      	cmp	x5, x12
    a9b8:      	b.ge	0xaa0c <_stogir.verify.control-sources+0x2a0>
    a9bc:      	ldr	x12, [x2, #0x8]
    a9c0:      	cmp	x5, x12
    a9c4:      	b.ge	0xaa04 <_stogir.verify.control-sources+0x298>
    a9c8:      	ldr	x12, [x20, #0x78]
    a9cc:      	add	x12, x8, x12
    a9d0:      	ldr	w12, [x12]
    a9d4:      	sxtw	x12, w12
    a9d8:      	cmp	x12, #0x0
    a9dc:      	cset	w12, ge
    a9e0:      	ubfx	x12, x12, #0, #8
    a9e4:      	b	0xaa08 <_stogir.verify.control-sources+0x29c>
    a9e8:      	sxtw	x12, w12
    a9ec:      	cmp	x12, #0x0
    a9f0:      	b.gt	0xaab4 <_stogir.verify.control-sources+0x348>
    a9f4:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000a9f4:  ARM64_RELOC_PAGE21	l_stogir.487
    a9f8:      	ldr	x1, [x1]
		000000000000a9f8:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    a9fc:      	mov	x0, #0x25               ; =37
    aa00:      	b	0xa91c <_stogir.verify.control-sources+0x1b0>
    aa04:      	movz	x12, #0x0, lsl #48
    aa08:      	b	0xaa10 <_stogir.verify.control-sources+0x2a4>
    aa0c:      	movz	x12, #0x0, lsl #48
    aa10:      	cmp	x12, #0x0
    aa14:      	b.eq	0xa8d8 <_stogir.verify.control-sources+0x16c>
    aa18:      	cmp	x13, #0x1
    aa1c:      	b.lt	0xa8b4 <_stogir.verify.control-sources+0x148>
    aa20:      	ldr	x12, [x20, #0x78]
    aa24:      	add	x12, x8, x12
    aa28:      	ldr	w12, [x12]
    aa2c:      	sxtw	x12, w12
    aa30:      	cmp	x13, x12
    aa34:      	b.gt	0xa8b4 <_stogir.verify.control-sources+0x148>
    aa38:      	ldr	x12, [x20]
    aa3c:      	asr	x16, x13, #63
    aa40:      	lsr	x16, x16, #62
    aa44:      	add	x14, x13, x16
    aa48:      	asr	x14, x14, #2
    aa4c:      	asr	x16, x13, #63
    aa50:      	lsr	x16, x16, #62
    aa54:      	add	x13, x13, x16
    aa58:      	and	x13, x13, #0x3
    aa5c:      	sub	x13, x13, x16
    aa60:      	add	x14, x14, x5
    aa64:      	add	x12, x12, x14, lsl #4
    aa68:      	add	x12, x12, x13, lsl #2
    aa6c:      	ldr	w12, [x12]
    aa70:      	movn	w17, #0x0, lsl #16
    aa74:      	and	w12, w12, w17
    aa78:      	mov	w13, #0x1               ; =1
    aa7c:      	b	0xa8bc <_stogir.verify.control-sources+0x150>
    aa80:      	add	x5, x9, #0x4
    aa84:      	asr	x16, x5, #63
    aa88:      	lsr	x16, x16, #62
    aa8c:      	add	x5, x5, x16
    aa90:      	asr	x5, x5, #2
    aa94:      	add	x3, x5, x3
    aa98:      	cmp	x0, #0x0
    aa9c:      	b.ne	0xa858 <_stogir.verify.control-sources+0xec>
    aaa0:      	ldr	x5, [x20, #0x8]
    aaa4:      	cmp	x3, x5
    aaa8:      	cset	w5, lt
    aaac:      	ubfx	x5, x5, #0, #8
    aab0:      	b	0xa85c <_stogir.verify.control-sources+0xf0>
    aab4:      	ldr	x13, [x20, #0x8]
    aab8:      	cmp	x12, x13
    aabc:      	b.ge	0xaaf4 <_stogir.verify.control-sources+0x388>
    aac0:      	ldr	x13, [x2, #0x8]
    aac4:      	cmp	x12, x13
    aac8:      	b.ge	0xaaec <_stogir.verify.control-sources+0x380>
    aacc:      	ldr	x13, [x20, #0x78]
    aad0:      	add	x13, x13, x12, lsl #2
    aad4:      	ldr	w13, [x13]
    aad8:      	sxtw	x13, w13
    aadc:      	cmp	x13, #0x0
    aae0:      	cset	w13, ge
    aae4:      	ubfx	x13, x13, #0, #8
    aae8:      	b	0xaaf0 <_stogir.verify.control-sources+0x384>
    aaec:      	movz	x13, #0x0, lsl #48
    aaf0:      	b	0xaaf8 <_stogir.verify.control-sources+0x38c>
    aaf4:      	movz	x13, #0x0, lsl #48
    aaf8:      	cmp	x13, #0x0
    aafc:      	b.eq	0xab38 <_stogir.verify.control-sources+0x3cc>
    ab00:      	cmp	x12, #0x0
    ab04:      	b.le	0xab18 <_stogir.verify.control-sources+0x3ac>
    ab08:      	ldr	x13, [x20]
    ab0c:      	add	x12, x13, x12, lsl #4
    ab10:      	ldr	x12, [x12]
    ab14:      	b	0xab30 <_stogir.verify.control-sources+0x3c4>
    ab18:      	movz	x16, #0x0, lsl #48
    ab1c:      	sub	x12, x16, x12
    ab20:      	ldr	x13, [x20, #0x28]
    ab24:      	sub	x12, x12, #0x1
    ab28:      	add	x12, x13, x12, lsl #4
    ab2c:      	ldr	x12, [x12]
    ab30:      	mov	w13, #0x1               ; =1
    ab34:      	b	0xab40 <_stogir.verify.control-sources+0x3d4>
    ab38:      	movz	w13, #0x0, lsl #16
    ab3c:      	movz	x12, #0x0, lsl #48
    ab40:      	ubfx	x13, x13, #0, #32
    ab44:      	lsr	x16, x13, #0
    ab48:      	cmp	x16, #0x1
    ab4c:      	b.eq	0xab68 <_stogir.verify.control-sources+0x3fc>
    ab50:      	b.lo	0xab58 <_stogir.verify.control-sources+0x3ec>
    ab54:      	b	0xab6c <_stogir.verify.control-sources+0x400>
    ab58:      	cmp	x16, #0x0
    ab5c:      	b.eq	0xab64 <_stogir.verify.control-sources+0x3f8>
    ab60:      	b	0xab6c <_stogir.verify.control-sources+0x400>
    ab64:      	b	0xab70 <_stogir.verify.control-sources+0x404>
    ab68:      	b	0xab80 <_stogir.verify.control-sources+0x414>
    ab6c:      	b	0xabc0 <_stogir.verify.control-sources+0x454>
    ab70:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000ab70:  ARM64_RELOC_PAGE21	l_stogir.485
    ab74:      	ldr	x1, [x1]
		000000000000ab74:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    ab78:      	mov	x0, #0x16               ; =22
    ab7c:      	b	0xa854 <_stogir.verify.control-sources+0xe8>
    ab80:      	uxtb	w12, w12
    ab84:      	cmp	x12, #0x83
    ab88:      	b.ge	0xa82c <_stogir.verify.control-sources+0xc0>
    ab8c:      	adrp	x17, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000ab8c:  ARM64_RELOC_PAGE21	l_stogir.488
    ab90:      	ldr	x17, [x17]
		000000000000ab90:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    ab94:      	add	x12, x12, x17
    ab98:      	ldrb	w12, [x12]
    ab9c:      	b	0xa830 <_stogir.verify.control-sources+0xc4>
    aba0:      	cmp	x0, #0x0
    aba4:      	b.ne	0xa7e8 <_stogir.verify.control-sources+0x7c>
    aba8:      	and	x1, x4, #0xffffffff
    abac:      	movz	x2, #0x0, lsl #48
    abb0:      	movz	x0, #0x0, lsl #48
    abb4:      	b	0xa7ec <_stogir.verify.control-sources+0x80>
    abb8:      	brk	#0
    abbc:      	b	0xabb8 <_stogir.verify.control-sources+0x44c>
    abc0:      	brk	#0
    abc4:      	b	0xabc0 <_stogir.verify.control-sources+0x454>
    abc8:      	brk	#0
    abcc:      	b	0xabc8 <_stogir.verify.control-sources+0x45c>

000000000000abd0 <_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge>:
    abd0:      	ldr	x1, [x0]
    abd4:      	ldr	x0, [x0, #0x8]
    abd8:      	movz	x17, #0x0, lsl #48
    abdc:      	str	x17, [x8]
    abe0:      	movz	x17, #0x0, lsl #48
    abe4:      	str	x17, [x8, #0x8]
    abe8:      	movz	x17, #0x0, lsl #48
    abec:      	str	x17, [x8, #0x10]
    abf0:      	str	x1, [x8, #0x18]
    abf4:      	str	x0, [x8, #0x20]
    abf8:      	ret

000000000000abfc <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32>:
    abfc:      	sub	sp, sp, #0x30
    ac00:      	str	x29, [sp]
    ac04:      	str	x30, [sp, #0x8]
    ac08:      	mov	x29, sp
    ac0c:      	str	x19, [sp, #0x10]
    ac10:      	str	x20, [sp, #0x18]
    ac14:      	str	x21, [sp, #0x20]
    ac18:      	str	x22, [sp, #0x28]
    ac1c:      	ldr	x2, [x0, #0x8]
    ac20:      	orr	x19, x2, xzr
    ac24:      	ldr	x2, [x0, #0x10]
    ac28:      	add	x20, x19, x1
    ac2c:      	cmp	x20, x2
    ac30:      	b.le	0xacac <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0xb0>
    ac34:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    ac38:      	cmp	x2, x17
    ac3c:      	b.gt	0xac48 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x4c>
    ac40:      	lsl	x2, x2, #1
    ac44:      	b	0xac4c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x50>
    ac48:      	mov	x2, x20
    ac4c:      	cmp	x2, x20
    ac50:      	b.gt	0xac58 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x5c>
    ac54:      	mov	x2, x20
    ac58:      	mov	x21, x0
    ac5c:      	mov	x22, x1
    ac60:      	mov	x1, x2
    ac64:      	bl	0xac64 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x68>
		000000000000ac64:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ac68:      	lsl	x0, x22, #2
    ac6c:      	ldr	x1, [x21]
    ac70:      	add	x1, x1, x19, lsl #2
    ac74:      	mov	x2, x0
    ac78:      	mov	x0, x1
    ac7c:      	movz	x1, #0x0, lsl #48
    ac80:      	bl	0xac80 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x84>
		000000000000ac80:  ARM64_RELOC_BRANCH26	_memset
    ac84:      	str	x20, [x21, #0x8]
    ac88:      	mov	x0, x20
    ac8c:      	ldr	x19, [sp, #0x10]
    ac90:      	ldr	x20, [sp, #0x18]
    ac94:      	ldr	x21, [sp, #0x20]
    ac98:      	ldr	x22, [sp, #0x28]
    ac9c:      	ldr	x29, [sp]
    aca0:      	ldr	x30, [sp, #0x8]
    aca4:      	add	sp, sp, #0x30
    aca8:      	ret
    acac:      	mov	x21, x0
    acb0:      	mov	x22, x1
    acb4:      	b	0xac68 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x6c>

000000000000acb8 <_stogir.opcode.block-start?>:
    acb8:      	sxtw	x0, w0
    acbc:      	cmp	x0, #0x0
    acc0:      	b.lt	0xace0 <_stogir.opcode.block-start?+0x28>
    acc4:      	cmp	x0, #0x83
    acc8:      	b.ge	0xace0 <_stogir.opcode.block-start?+0x28>
    accc:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000accc:  ARM64_RELOC_PAGE21	l_stogir.489
    acd0:      	ldr	x16, [x16]
		000000000000acd0:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    acd4:      	add	x0, x16, x0
    acd8:      	ldrb	w0, [x0]
    acdc:      	b	0xace4 <_stogir.opcode.block-start?+0x2c>
    ace0:      	movz	w0, #0x0, lsl #16
    ace4:      	uxtb	w16, w0
    ace8:      	and	w0, w16, #0x2
    acec:      	uxtb	w0, w0
    acf0:      	ubfx	x0, x0, #0, #8
    acf4:      	cmp	x0, #0x0
    acf8:      	cset	w0, eq
    acfc:      	uxtb	w16, w0
    ad00:      	cmp	w16, wzr
    ad04:      	cset	x0, eq
    ad08:      	ret

000000000000ad0c <_coil.core.Push$coil.arraylist.ArrayList$push!__i32>:
    ad0c:      	sub	sp, sp, #0x30
    ad10:      	str	x29, [sp]
    ad14:      	str	x30, [sp, #0x8]
    ad18:      	mov	x29, sp
    ad1c:      	str	x19, [sp, #0x10]
    ad20:      	str	x20, [sp, #0x18]
    ad24:      	str	x21, [sp, #0x20]
    ad28:      	ldr	x2, [x0, #0x8]
    ad2c:      	orr	x19, x2, xzr
    ad30:      	ldr	x2, [x0, #0x10]
    ad34:      	cmp	x19, x2
    ad38:      	b.lt	0xad4c <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x40>
    ad3c:      	cmp	x2, #0x0
    ad40:      	b.ne	0xad58 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x4c>
    ad44:      	mov	x2, #0x2                ; =2
    ad48:      	b	0xad5c <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x50>
    ad4c:      	mov	x20, x0
    ad50:      	mov	w21, w1
    ad54:      	b	0xad6c <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x60>
    ad58:      	lsl	x2, x2, #1
    ad5c:      	mov	x20, x0
    ad60:      	mov	w21, w1
    ad64:      	mov	x1, x2
    ad68:      	bl	0xad68 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x5c>
		000000000000ad68:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ad6c:      	add	x0, x19, #0x1
    ad70:      	ldr	x1, [x20]
    ad74:      	add	x1, x1, x19, lsl #2
    ad78:      	str	w21, [x1]
    ad7c:      	str	x0, [x20, #0x8]
    ad80:      	ldr	x19, [sp, #0x10]
    ad84:      	ldr	x20, [sp, #0x18]
    ad88:      	ldr	x21, [sp, #0x20]
    ad8c:      	ldr	x29, [sp]
    ad90:      	ldr	x30, [sp, #0x8]
    ad94:      	add	sp, sp, #0x30
    ad98:      	ret

000000000000ad9c <_coil.core.Set$coil.arraylist.ArrayList$set!__i32>:
    ad9c:      	ldr	x0, [x0]
    ada0:      	add	x0, x0, x1, lsl #2
    ada4:      	str	w2, [x0]
    ada8:      	movz	x0, #0x0, lsl #48
    adac:      	ret

000000000000adb0 <_stogir.opcode.control?>:
    adb0:      	sxtw	x0, w0
    adb4:      	cmp	x0, #0x0
    adb8:      	b.lt	0xadd8 <_stogir.opcode.control?+0x28>
    adbc:      	cmp	x0, #0x83
    adc0:      	b.ge	0xadd8 <_stogir.opcode.control?+0x28>
    adc4:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5b8>
		000000000000adc4:  ARM64_RELOC_PAGE21	l_stogir.490
    adc8:      	ldr	x16, [x16]
		000000000000adc8:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    adcc:      	add	x0, x16, x0
    add0:      	ldrb	w0, [x0]
    add4:      	b	0xaddc <_stogir.opcode.control?+0x2c>
    add8:      	movz	w0, #0x0, lsl #16
    addc:      	uxtb	w16, w0
    ade0:      	and	w0, w16, #0x1
    ade4:      	uxtb	w0, w0
    ade8:      	ubfx	x0, x0, #0, #8
    adec:      	ret

000000000000adf0 <_inherent$coil.arraylist.ArrayList$clear!__i32>:
    adf0:      	b	0xae00 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x10>
    adf4:      	nop
    adf8:      	sub	x1, x1, #0x1
    adfc:      	str	x1, [x0, #0x8]
    ae00:      	ldr	x1, [x0, #0x8]
    ae04:      	cmp	x1, #0x0
    ae08:      	b.ne	0xadf8 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x8>
    ae0c:      	movz	x0, #0x0, lsl #48
    ae10:      	ret

000000000000ae14 <_stogir.graph.operand>:
    ae14:      	sub	sp, sp, #0x10
    ae18:      	mov	x3, sp
    ae1c:      	sxtw	x1, w1
    ae20:      	cmp	x1, #0x0
    ae24:      	b.le	0xae68 <_stogir.graph.operand+0x54>
    ae28:      	lsl	x4, x1, #2
    ae2c:      	add	x5, x0, #0x78
    ae30:      	ldr	x6, [x0, #0x8]
    ae34:      	cmp	x1, x6
    ae38:      	b.ge	0xae9c <_stogir.graph.operand+0x88>
    ae3c:      	ldr	x5, [x5, #0x8]
    ae40:      	cmp	x1, x5
    ae44:      	b.ge	0xae94 <_stogir.graph.operand+0x80>
    ae48:      	ldr	x5, [x0, #0x78]
    ae4c:      	add	x5, x4, x5
    ae50:      	ldr	w5, [x5]
    ae54:      	sxtw	x5, w5
    ae58:      	cmp	x5, #0x0
    ae5c:      	cset	w5, ge
    ae60:      	ubfx	x5, x5, #0, #8
    ae64:      	b	0xae98 <_stogir.graph.operand+0x84>
    ae68:      	movz	x1, #0x0, lsl #48
    ae6c:      	movz	x0, #0x0, lsl #48
    ae70:      	str	x1, [x3]
    ae74:      	str	x0, [x3, #0x8]
    ae78:      	ldr	x0, [sp]
    ae7c:      	ldr	x1, [sp, #0x8]
    ae80:      	add	sp, sp, #0x10
    ae84:      	ret
    ae88:      	movz	x1, #0x0, lsl #48
    ae8c:      	movz	x0, #0x0, lsl #48
    ae90:      	b	0xae70 <_stogir.graph.operand+0x5c>
    ae94:      	movz	x5, #0x0, lsl #48
    ae98:      	b	0xaea0 <_stogir.graph.operand+0x8c>
    ae9c:      	movz	x5, #0x0, lsl #48
    aea0:      	cmp	x5, #0x0
    aea4:      	b.eq	0xae68 <_stogir.graph.operand+0x54>
    aea8:      	sxtw	x2, w2
    aeac:      	cmp	x2, #0x1
    aeb0:      	b.lt	0xae88 <_stogir.graph.operand+0x74>
    aeb4:      	ldr	x5, [x0, #0x78]
    aeb8:      	add	x4, x4, x5
    aebc:      	ldr	w4, [x4]
    aec0:      	sxtw	x4, w4
    aec4:      	cmp	x2, x4
    aec8:      	b.gt	0xae88 <_stogir.graph.operand+0x74>
    aecc:      	ldr	x0, [x0]
    aed0:      	asr	x16, x2, #63
    aed4:      	lsr	x16, x16, #62
    aed8:      	add	x4, x2, x16
    aedc:      	asr	x4, x4, #2
    aee0:      	asr	x16, x2, #63
    aee4:      	lsr	x16, x16, #62
    aee8:      	add	x2, x2, x16
    aeec:      	and	x2, x2, #0x3
    aef0:      	sub	x2, x2, x16
    aef4:      	add	x1, x4, x1
    aef8:      	add	x0, x0, x1, lsl #4
    aefc:      	add	x0, x0, x2, lsl #2
    af00:      	ldr	w0, [x0]
    af04:      	sxtw	x0, w0
    af08:      	and	x0, x0, #0xffffffff
    af0c:      	mov	x1, #0x1                ; =1
    af10:      	b	0xae90 <_stogir.graph.operand+0x7c>

000000000000af14 <_inherent$coil.arraylist.ArrayList$new__bool>:
    af14:      	ldr	x1, [x0]
    af18:      	ldr	x0, [x0, #0x8]
    af1c:      	movz	x17, #0x0, lsl #48
    af20:      	str	x17, [x8]
    af24:      	movz	x17, #0x0, lsl #48
    af28:      	str	x17, [x8, #0x8]
    af2c:      	movz	x17, #0x0, lsl #48
    af30:      	str	x17, [x8, #0x10]
    af34:      	str	x1, [x8, #0x18]
    af38:      	str	x0, [x8, #0x20]
    af3c:      	ret

000000000000af40 <_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame>:
    af40:      	ldr	x1, [x0]
    af44:      	ldr	x0, [x0, #0x8]
    af48:      	movz	x17, #0x0, lsl #48
    af4c:      	str	x17, [x8]
    af50:      	movz	x17, #0x0, lsl #48
    af54:      	str	x17, [x8, #0x8]
    af58:      	movz	x17, #0x0, lsl #48
    af5c:      	str	x17, [x8, #0x10]
    af60:      	str	x1, [x8, #0x18]
    af64:      	str	x0, [x8, #0x20]
    af68:      	ret

000000000000af6c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool>:
    af6c:      	sub	sp, sp, #0x30
    af70:      	str	x29, [sp]
    af74:      	str	x30, [sp, #0x8]
    af78:      	mov	x29, sp
    af7c:      	str	x19, [sp, #0x10]
    af80:      	str	x20, [sp, #0x18]
    af84:      	str	x21, [sp, #0x20]
    af88:      	str	x22, [sp, #0x28]
    af8c:      	ldr	x2, [x0, #0x8]
    af90:      	orr	x19, x2, xzr
    af94:      	ldr	x2, [x0, #0x10]
    af98:      	add	x20, x19, x1
    af9c:      	cmp	x20, x2
    afa0:      	b.le	0xb01c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xb0>
    afa4:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    afa8:      	cmp	x2, x17
    afac:      	b.gt	0xafb8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x4c>
    afb0:      	lsl	x2, x2, #1
    afb4:      	b	0xafbc <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x50>
    afb8:      	mov	x2, x20
    afbc:      	cmp	x2, x20
    afc0:      	b.gt	0xafc8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x5c>
    afc4:      	mov	x2, x20
    afc8:      	mov	x21, x0
    afcc:      	mov	x22, x1
    afd0:      	mov	x1, x2
    afd4:      	bl	0xafd4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x68>
		000000000000afd4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    afd8:      	lsr	x0, x22, #0
    afdc:      	ldr	x1, [x21]
    afe0:      	add	x1, x1, x19
    afe4:      	mov	x2, x0
    afe8:      	mov	x0, x1
    afec:      	movz	x1, #0x0, lsl #48
    aff0:      	bl	0xaff0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x84>
		000000000000aff0:  ARM64_RELOC_BRANCH26	_memset
    aff4:      	str	x20, [x21, #0x8]
    aff8:      	mov	x0, x20
    affc:      	ldr	x19, [sp, #0x10]
    b000:      	ldr	x20, [sp, #0x18]
    b004:      	ldr	x21, [sp, #0x20]
    b008:      	ldr	x22, [sp, #0x28]
    b00c:      	ldr	x29, [sp]
    b010:      	ldr	x30, [sp, #0x8]
    b014:      	add	sp, sp, #0x30
    b018:      	ret
    b01c:      	mov	x21, x0
    b020:      	mov	x22, x1
    b024:      	b	0xafd8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x6c>

000000000000b028 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame>:
    b028:      	sub	sp, sp, #0x30
    b02c:      	str	x29, [sp]
    b030:      	str	x30, [sp, #0x8]
    b034:      	mov	x29, sp
    b038:      	str	x19, [sp, #0x10]
    b03c:      	str	x20, [sp, #0x18]
    b040:      	str	x21, [sp, #0x20]
    b044:      	str	x22, [sp, #0x28]
    b048:      	ldr	x3, [x0, #0x8]
    b04c:      	orr	x19, x3, xzr
    b050:      	ldr	x3, [x0, #0x10]
    b054:      	cmp	x19, x3
    b058:      	b.lt	0xb06c <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x44>
    b05c:      	cmp	x3, #0x0
    b060:      	b.ne	0xb07c <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x54>
    b064:      	mov	x3, #0x2                ; =2
    b068:      	b	0xb080 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x58>
    b06c:      	mov	x20, x0
    b070:      	mov	x21, x1
    b074:      	mov	x22, x2
    b078:      	b	0xb094 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x6c>
    b07c:      	lsl	x3, x3, #1
    b080:      	mov	x20, x0
    b084:      	mov	x21, x1
    b088:      	mov	x1, x3
    b08c:      	mov	x22, x2
    b090:      	bl	0xb090 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x68>
		000000000000b090:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    b094:      	add	x0, x19, #0x1
    b098:      	ldr	x1, [x20]
    b09c:      	add	x1, x1, x19, lsl #4
    b0a0:      	str	x21, [x1]
    b0a4:      	str	x22, [x1, #0x8]
    b0a8:      	str	x0, [x20, #0x8]
    b0ac:      	ldr	x19, [sp, #0x10]
    b0b0:      	ldr	x20, [sp, #0x18]
    b0b4:      	ldr	x21, [sp, #0x20]
    b0b8:      	ldr	x22, [sp, #0x28]
    b0bc:      	ldr	x29, [sp]
    b0c0:      	ldr	x30, [sp, #0x8]
    b0c4:      	add	sp, sp, #0x30
    b0c8:      	ret
    b0cc:      	udf	#0x0

000000000000b0d0 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame>:
    b0d0:      	sub	sp, sp, #0x20
    b0d4:      	str	x29, [sp]
    b0d8:      	str	x30, [sp, #0x8]
    b0dc:      	mov	x29, sp
    b0e0:      	str	x19, [sp, #0x10]
    b0e4:      	b	0xb0f0 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x20>
    b0e8:      	sub	x1, x1, #0x1
    b0ec:      	str	x1, [x0, #0x8]
    b0f0:      	ldr	x1, [x0, #0x8]
    b0f4:      	cmp	x1, #0x0
    b0f8:      	b.ne	0xb0e8 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x18>
    b0fc:      	ldr	x1, [x0, #0x10]
    b100:      	cmp	x1, #0x0
    b104:      	b.le	0xb164 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x94>
    b108:      	add	x2, x0, #0x18
    b10c:      	ldr	x3, [x0]
    b110:      	mov	x19, x0
    b114:      	mov	x0, x2
    b118:      	mov	x2, x1
    b11c:      	mov	x1, x3
    b120:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000b120:  ARM64_RELOC_PAGE21	l_stogir.491
    b124:      	ldr	x3, [x3]
		000000000000b124:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    b128:      	mov	x4, #0x10               ; =16
    b12c:      	mov	x5, #0x8                ; =8
    b130:      	bl	0xb130 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x60>
		000000000000b130:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b134:      	movz	x17, #0x0, lsl #48
    b138:      	str	x17, [x19]
    b13c:      	movz	x17, #0x0, lsl #48
    b140:      	str	x17, [x19, #0x8]
    b144:      	movz	x17, #0x0, lsl #48
    b148:      	str	x17, [x19, #0x10]
    b14c:      	movz	x0, #0x0, lsl #48
    b150:      	ldr	x19, [sp, #0x10]
    b154:      	ldr	x29, [sp]
    b158:      	ldr	x30, [sp, #0x8]
    b15c:      	add	sp, sp, #0x20
    b160:      	ret
    b164:      	mov	x19, x0
    b168:      	b	0xb134 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x64>

000000000000b16c <_inherent$coil.arraylist.ArrayList$new__i64>:
    b16c:      	ldr	x1, [x0]
    b170:      	ldr	x0, [x0, #0x8]
    b174:      	movz	x17, #0x0, lsl #48
    b178:      	str	x17, [x8]
    b17c:      	movz	x17, #0x0, lsl #48
    b180:      	str	x17, [x8, #0x8]
    b184:      	movz	x17, #0x0, lsl #48
    b188:      	str	x17, [x8, #0x10]
    b18c:      	str	x1, [x8, #0x18]
    b190:      	str	x0, [x8, #0x20]
    b194:      	ret

000000000000b198 <_inherent$coil.arraylist.ArrayList$free!__i64>:
    b198:      	sub	sp, sp, #0x20
    b19c:      	str	x29, [sp]
    b1a0:      	str	x30, [sp, #0x8]
    b1a4:      	mov	x29, sp
    b1a8:      	str	x19, [sp, #0x10]
    b1ac:      	b	0xb1b8 <_inherent$coil.arraylist.ArrayList$free!__i64+0x20>
    b1b0:      	sub	x1, x1, #0x1
    b1b4:      	str	x1, [x0, #0x8]
    b1b8:      	ldr	x1, [x0, #0x8]
    b1bc:      	cmp	x1, #0x0
    b1c0:      	b.ne	0xb1b0 <_inherent$coil.arraylist.ArrayList$free!__i64+0x18>
    b1c4:      	ldr	x1, [x0, #0x10]
    b1c8:      	cmp	x1, #0x0
    b1cc:      	b.le	0xb22c <_inherent$coil.arraylist.ArrayList$free!__i64+0x94>
    b1d0:      	add	x2, x0, #0x18
    b1d4:      	ldr	x3, [x0]
    b1d8:      	mov	x19, x0
    b1dc:      	mov	x0, x2
    b1e0:      	mov	x2, x1
    b1e4:      	mov	x1, x3
    b1e8:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000b1e8:  ARM64_RELOC_PAGE21	l_stogir.492
    b1ec:      	ldr	x3, [x3]
		000000000000b1ec:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    b1f0:      	mov	x4, #0x8                ; =8
    b1f4:      	mov	x5, #0x8                ; =8
    b1f8:      	bl	0xb1f8 <_inherent$coil.arraylist.ArrayList$free!__i64+0x60>
		000000000000b1f8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b1fc:      	movz	x17, #0x0, lsl #48
    b200:      	str	x17, [x19]
    b204:      	movz	x17, #0x0, lsl #48
    b208:      	str	x17, [x19, #0x8]
    b20c:      	movz	x17, #0x0, lsl #48
    b210:      	str	x17, [x19, #0x10]
    b214:      	movz	x0, #0x0, lsl #48
    b218:      	ldr	x19, [sp, #0x10]
    b21c:      	ldr	x29, [sp]
    b220:      	ldr	x30, [sp, #0x8]
    b224:      	add	sp, sp, #0x20
    b228:      	ret
    b22c:      	mov	x19, x0
    b230:      	b	0xb1fc <_inherent$coil.arraylist.ArrayList$free!__i64+0x64>
    b234:      	udf	#0x0

000000000000b238 <_stogir.dominators.build-index>:
    b238:      	sub	sp, sp, #0x130
    b23c:      	str	x29, [sp]
    b240:      	str	x30, [sp, #0x8]
    b244:      	mov	x29, sp
    b248:      	str	x19, [sp, #0xf0]
    b24c:      	str	x20, [sp, #0xf8]
    b250:      	str	x21, [sp, #0x100]
    b254:      	str	x22, [sp, #0x108]
    b258:      	str	x23, [sp, #0x110]
    b25c:      	str	x24, [sp, #0x118]
    b260:      	str	x25, [sp, #0x120]
    b264:      	ldr	x2, [x0, #0x8]
    b268:      	orr	x19, x2, xzr
    b26c:      	ldr	x2, [x1]
    b270:      	ldr	x1, [x1, #0x8]
    b274:      	add	x16, sp, #0x10
    b278:      	movz	x17, #0x0, lsl #48
    b27c:      	str	x17, [x16]
    b280:      	add	x16, sp, #0x10
    b284:      	movz	x17, #0x0, lsl #48
    b288:      	str	x17, [x16, #0x8]
    b28c:      	add	x16, sp, #0x10
    b290:      	movz	x17, #0x0, lsl #48
    b294:      	str	x17, [x16, #0x10]
    b298:      	add	x16, sp, #0x10
    b29c:      	str	x2, [x16, #0x18]
    b2a0:      	add	x16, sp, #0x10
    b2a4:      	str	x1, [x16, #0x20]
    b2a8:      	add	x16, sp, #0x10
    b2ac:      	movz	x17, #0x0, lsl #48
    b2b0:      	str	x17, [x16, #0x28]
    b2b4:      	add	x16, sp, #0x10
    b2b8:      	movz	x17, #0x0, lsl #48
    b2bc:      	str	x17, [x16, #0x30]
    b2c0:      	add	x16, sp, #0x10
    b2c4:      	movz	x17, #0x0, lsl #48
    b2c8:      	str	x17, [x16, #0x38]
    b2cc:      	add	x16, sp, #0x10
    b2d0:      	str	x2, [x16, #0x40]
    b2d4:      	add	x16, sp, #0x10
    b2d8:      	str	x1, [x16, #0x48]
    b2dc:      	add	x16, sp, #0x60
    b2e0:      	movz	x17, #0x0, lsl #48
    b2e4:      	str	x17, [x16]
    b2e8:      	add	x16, sp, #0x60
    b2ec:      	movz	x17, #0x0, lsl #48
    b2f0:      	str	x17, [x16, #0x8]
    b2f4:      	add	x16, sp, #0x60
    b2f8:      	movz	x17, #0x0, lsl #48
    b2fc:      	str	x17, [x16, #0x10]
    b300:      	add	x16, sp, #0x60
    b304:      	str	x2, [x16, #0x18]
    b308:      	add	x16, sp, #0x60
    b30c:      	str	x1, [x16, #0x20]
    b310:      	add	x16, sp, #0x90
    b314:      	movz	x17, #0x0, lsl #48
    b318:      	str	x17, [x16]
    b31c:      	add	x16, sp, #0x90
    b320:      	movz	x17, #0x0, lsl #48
    b324:      	str	x17, [x16, #0x8]
    b328:      	add	x16, sp, #0x90
    b32c:      	movz	x17, #0x0, lsl #48
    b330:      	str	x17, [x16, #0x10]
    b334:      	add	x16, sp, #0x90
    b338:      	str	x2, [x16, #0x18]
    b33c:      	add	x16, sp, #0x90
    b340:      	str	x1, [x16, #0x20]
    b344:      	add	x16, sp, #0xc0
    b348:      	movz	x17, #0x0, lsl #48
    b34c:      	str	x17, [x16]
    b350:      	add	x16, sp, #0xc0
    b354:      	movz	x17, #0x0, lsl #48
    b358:      	str	x17, [x16, #0x8]
    b35c:      	add	x16, sp, #0xc0
    b360:      	movz	x17, #0x0, lsl #48
    b364:      	str	x17, [x16, #0x10]
    b368:      	add	x16, sp, #0xc0
    b36c:      	str	x2, [x16, #0x18]
    b370:      	add	x16, sp, #0xc0
    b374:      	str	x1, [x16, #0x20]
    b378:      	cmp	x19, #0x0
    b37c:      	b.le	0xb920 <_stogir.dominators.build-index+0x6e8>
    b380:      	cmp	x19, #0x0
    b384:      	b.ge	0xb390 <_stogir.dominators.build-index+0x158>
    b388:      	movz	x1, #0x0, lsl #48
    b38c:      	b	0xb394 <_stogir.dominators.build-index+0x15c>
    b390:      	mov	x1, x19
    b394:      	mov	x20, x8
    b398:      	mov	x21, x0
    b39c:      	add	x0, sp, #0x10
    b3a0:      	bl	0xb3a0 <_stogir.dominators.build-index+0x168>
		000000000000b3a0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b3a4:      	add	x16, sp, #0x10
    b3a8:      	orr	x0, x16, xzr
    b3ac:      	lsl	x1, x19, #2
    b3b0:      	add	x22, x0, #0x28
    b3b4:      	add	x16, sp, #0x10
    b3b8:      	ldr	x0, [x16]
    b3bc:      	mov	x2, x1
    b3c0:      	movz	x1, #0x0, lsl #48
    b3c4:      	bl	0xb3c4 <_stogir.dominators.build-index+0x18c>
		000000000000b3c4:  ARM64_RELOC_BRANCH26	_memset
    b3c8:      	add	x16, sp, #0x10
    b3cc:      	str	x19, [x16, #0x8]
    b3d0:      	ldr	x0, [x22, #0x8]
    b3d4:      	orr	x23, x0, xzr
    b3d8:      	ldr	x0, [x22, #0x10]
    b3dc:      	add	x24, x23, x19
    b3e0:      	cmp	x24, x0
    b3e4:      	b.le	0xb418 <_stogir.dominators.build-index+0x1e0>
    b3e8:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b3ec:      	cmp	x0, x17
    b3f0:      	b.gt	0xb3fc <_stogir.dominators.build-index+0x1c4>
    b3f4:      	lsl	x0, x0, #1
    b3f8:      	b	0xb400 <_stogir.dominators.build-index+0x1c8>
    b3fc:      	mov	x0, x24
    b400:      	cmp	x0, x24
    b404:      	b.gt	0xb40c <_stogir.dominators.build-index+0x1d4>
    b408:      	mov	x0, x24
    b40c:      	mov	x1, x0
    b410:      	mov	x0, x22
    b414:      	bl	0xb414 <_stogir.dominators.build-index+0x1dc>
		000000000000b414:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b418:      	lsl	x0, x19, #2
    b41c:      	add	x16, sp, #0x10
    b420:      	ldr	x1, [x16, #0x28]
    b424:      	add	x1, x1, x23, lsl #2
    b428:      	mov	x2, x0
    b42c:      	mov	x0, x1
    b430:      	movz	x1, #0x0, lsl #48
    b434:      	bl	0xb434 <_stogir.dominators.build-index+0x1fc>
		000000000000b434:  ARM64_RELOC_BRANCH26	_memset
    b438:      	str	x24, [x22, #0x8]
    b43c:      	add	x16, sp, #0x60
    b440:      	ldr	x0, [x16, #0x8]
    b444:      	orr	x22, x0, xzr
    b448:      	add	x16, sp, #0x60
    b44c:      	ldr	x0, [x16, #0x10]
    b450:      	add	x23, x22, x19
    b454:      	cmp	x23, x0
    b458:      	b.le	0xb48c <_stogir.dominators.build-index+0x254>
    b45c:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b460:      	cmp	x0, x17
    b464:      	b.gt	0xb470 <_stogir.dominators.build-index+0x238>
    b468:      	lsl	x0, x0, #1
    b46c:      	b	0xb474 <_stogir.dominators.build-index+0x23c>
    b470:      	mov	x0, x23
    b474:      	cmp	x0, x23
    b478:      	b.gt	0xb480 <_stogir.dominators.build-index+0x248>
    b47c:      	mov	x0, x23
    b480:      	mov	x1, x0
    b484:      	add	x0, sp, #0x60
    b488:      	bl	0xb488 <_stogir.dominators.build-index+0x250>
		000000000000b488:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b48c:      	lsl	x0, x19, #2
    b490:      	add	x16, sp, #0x60
    b494:      	ldr	x1, [x16]
    b498:      	add	x1, x1, x22, lsl #2
    b49c:      	mov	x2, x0
    b4a0:      	mov	x0, x1
    b4a4:      	movz	x1, #0x0, lsl #48
    b4a8:      	bl	0xb4a8 <_stogir.dominators.build-index+0x270>
		000000000000b4a8:  ARM64_RELOC_BRANCH26	_memset
    b4ac:      	add	x16, sp, #0x60
    b4b0:      	str	x23, [x16, #0x8]
    b4b4:      	add	x0, sp, #0x90
    b4b8:      	mov	x1, x19
    b4bc:      	bl	0xb4bc <_stogir.dominators.build-index+0x284>
		000000000000b4bc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    b4c0:      	movz	x0, #0x0, lsl #48
    b4c4:      	b	0xb4fc <_stogir.dominators.build-index+0x2c4>
    b4c8:      	orr	w2, w0, wzr
    b4cc:      	add	x16, sp, #0x60
    b4d0:      	ldr	x3, [x16]
    b4d4:      	add	x3, x3, x1, lsl #2
    b4d8:      	ldr	w3, [x3]
    b4dc:      	add	x16, sp, #0x90
    b4e0:      	ldr	x4, [x16]
    b4e4:      	add	x4, x4, x0, lsl #2
    b4e8:      	str	w3, [x4]
    b4ec:      	add	x16, sp, #0x60
    b4f0:      	ldr	x3, [x16]
    b4f4:      	add	x1, x3, x1, lsl #2
    b4f8:      	str	w2, [x1]
    b4fc:      	add	x0, x0, #0x1
    b500:      	cmp	x0, x19
    b504:      	b.ge	0xb52c <_stogir.dominators.build-index+0x2f4>
    b508:      	ldr	x1, [x21]
    b50c:      	add	x1, x1, x0, lsl #2
    b510:      	ldr	w1, [x1]
    b514:      	sxtw	x1, w1
    b518:      	cmp	x1, #0x0
    b51c:      	b.le	0xb4fc <_stogir.dominators.build-index+0x2c4>
    b520:      	cmp	x1, x0
    b524:      	b.ne	0xb4c8 <_stogir.dominators.build-index+0x290>
    b528:      	b	0xb4fc <_stogir.dominators.build-index+0x2c4>
    b52c:      	movz	x22, #0x0, lsl #48
    b530:      	movz	x0, #0x0, lsl #48
    b534:      	b	0xb678 <_stogir.dominators.build-index+0x440>
    b538:      	lsl	x0, x0, #1
    b53c:      	mov	x1, x0
    b540:      	add	x0, sp, #0xc0
    b544:      	bl	0xb544 <_stogir.dominators.build-index+0x30c>
		000000000000b544:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b548:      	sxtw	x0, w23
    b54c:      	orr	w1, w22, wzr
    b550:      	add	x2, x24, #0x1
    b554:      	add	x16, sp, #0xc0
    b558:      	ldr	x3, [x16]
    b55c:      	add	x3, x3, x24, lsl #2
    b560:      	str	w1, [x3]
    b564:      	add	x16, sp, #0xc0
    b568:      	str	x2, [x16, #0x8]
    b56c:      	b	0xb5a0 <_stogir.dominators.build-index+0x368>
    b570:      	lsl	x0, x0, #1
    b574:      	mov	x1, x0
    b578:      	add	x0, sp, #0xc0
    b57c:      	bl	0xb57c <_stogir.dominators.build-index+0x344>
		000000000000b57c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b580:      	sxtw	x0, w24
    b584:      	add	x1, x25, #0x1
    b588:      	add	x16, sp, #0xc0
    b58c:      	ldr	x2, [x16]
    b590:      	add	x2, x2, x25, lsl #2
    b594:      	str	w23, [x2]
    b598:      	add	x16, sp, #0xc0
    b59c:      	str	x1, [x16, #0x8]
    b5a0:      	add	x16, sp, #0xc0
    b5a4:      	ldr	x1, [x16, #0x8]
    b5a8:      	cmp	x1, #0x0
    b5ac:      	b.le	0xb678 <_stogir.dominators.build-index+0x440>
    b5b0:      	add	x16, sp, #0xc0
    b5b4:      	ldr	x2, [x16]
    b5b8:      	sub	x1, x1, #0x1
    b5bc:      	add	x1, x2, x1, lsl #2
    b5c0:      	ldr	w1, [x1]
    b5c4:      	sxtw	x1, w1
    b5c8:      	add	x16, sp, #0x60
    b5cc:      	ldr	x2, [x16]
    b5d0:      	add	x3, x2, x1, lsl #2
    b5d4:      	ldr	w23, [x3]
    b5d8:      	sxtw	x3, w23
    b5dc:      	cmp	x3, #0x0
    b5e0:      	b.le	0xb640 <_stogir.dominators.build-index+0x408>
    b5e4:      	add	x0, x0, #0x1
    b5e8:      	add	x16, sp, #0x90
    b5ec:      	ldr	x4, [x16]
    b5f0:      	orr	w24, w0, wzr
    b5f4:      	add	x0, x2, x1, lsl #2
    b5f8:      	add	x1, x4, x3, lsl #2
    b5fc:      	ldr	w1, [x1]
    b600:      	str	w1, [x0]
    b604:      	add	x16, sp, #0x10
    b608:      	ldr	x0, [x16]
    b60c:      	add	x0, x0, x3, lsl #2
    b610:      	str	w24, [x0]
    b614:      	add	x16, sp, #0xc0
    b618:      	ldr	x0, [x16, #0x8]
    b61c:      	orr	x25, x0, xzr
    b620:      	add	x16, sp, #0xc0
    b624:      	ldr	x0, [x16, #0x10]
    b628:      	cmp	x25, x0
    b62c:      	b.lt	0xb580 <_stogir.dominators.build-index+0x348>
    b630:      	cmp	x0, #0x0
    b634:      	b.ne	0xb570 <_stogir.dominators.build-index+0x338>
    b638:      	mov	x0, #0x2                ; =2
    b63c:      	b	0xb574 <_stogir.dominators.build-index+0x33c>
    b640:      	orr	w2, w0, wzr
    b644:      	add	x16, sp, #0x10
    b648:      	ldr	x3, [x16, #0x28]
    b64c:      	add	x1, x3, x1, lsl #2
    b650:      	str	w2, [x1]
    b654:      	add	x16, sp, #0xc0
    b658:      	ldr	x1, [x16, #0x8]
    b65c:      	cmp	x1, #0x0
    b660:      	b.eq	0xb5a0 <_stogir.dominators.build-index+0x368>
    b664:      	sub	x1, x1, #0x1
    b668:      	add	x16, sp, #0xc0
    b66c:      	str	x1, [x16, #0x8]
    b670:      	b	0xb5a0 <_stogir.dominators.build-index+0x368>
    b674:      	nop
    b678:      	add	x22, x22, #0x1
    b67c:      	cmp	x22, x19
    b680:      	b.ge	0xb6e0 <_stogir.dominators.build-index+0x4a8>
    b684:      	ldr	x1, [x21]
    b688:      	add	x1, x1, x22, lsl #2
    b68c:      	ldr	w1, [x1]
    b690:      	sxtw	x1, w1
    b694:      	cmp	x1, x22
    b698:      	b.ne	0xb678 <_stogir.dominators.build-index+0x440>
    b69c:      	add	x0, x0, #0x1
    b6a0:      	add	x16, sp, #0x10
    b6a4:      	ldr	x1, [x16]
    b6a8:      	orr	w23, w0, wzr
    b6ac:      	add	x0, x1, x22, lsl #2
    b6b0:      	str	w23, [x0]
    b6b4:      	add	x16, sp, #0xc0
    b6b8:      	ldr	x0, [x16, #0x8]
    b6bc:      	orr	x24, x0, xzr
    b6c0:      	add	x16, sp, #0xc0
    b6c4:      	ldr	x0, [x16, #0x10]
    b6c8:      	cmp	x24, x0
    b6cc:      	b.lt	0xb548 <_stogir.dominators.build-index+0x310>
    b6d0:      	cmp	x0, #0x0
    b6d4:      	b.ne	0xb538 <_stogir.dominators.build-index+0x300>
    b6d8:      	mov	x0, #0x2                ; =2
    b6dc:      	b	0xb53c <_stogir.dominators.build-index+0x304>
    b6e0:      	b	0xb6f4 <_stogir.dominators.build-index+0x4bc>
    b6e4:      	nop
    b6e8:      	sub	x0, x0, #0x1
    b6ec:      	add	x16, sp, #0xc0
    b6f0:      	str	x0, [x16, #0x8]
    b6f4:      	add	x16, sp, #0xc0
    b6f8:      	ldr	x0, [x16, #0x8]
    b6fc:      	cmp	x0, #0x0
    b700:      	b.ne	0xb6e8 <_stogir.dominators.build-index+0x4b0>
    b704:      	add	x16, sp, #0xc0
    b708:      	orr	x0, x16, xzr
    b70c:      	add	x16, sp, #0xc0
    b710:      	ldr	x1, [x16, #0x10]
    b714:      	cmp	x1, #0x0
    b718:      	b.le	0xb748 <_stogir.dominators.build-index+0x510>
    b71c:      	add	x0, x0, #0x18
    b720:      	add	x16, sp, #0xc0
    b724:      	ldr	x2, [x16]
    b728:      	fmov	d31, x1
    b72c:      	mov	x1, x2
    b730:      	fmov	x2, d31
    b734:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000b734:  ARM64_RELOC_PAGE21	l_stogir.493
    b738:      	ldr	x3, [x3]
		000000000000b738:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b73c:      	mov	x4, #0x4                ; =4
    b740:      	mov	x5, #0x4                ; =4
    b744:      	bl	0xb744 <_stogir.dominators.build-index+0x50c>
		000000000000b744:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b748:      	add	x16, sp, #0xc0
    b74c:      	movz	x17, #0x0, lsl #48
    b750:      	str	x17, [x16]
    b754:      	add	x16, sp, #0xc0
    b758:      	movz	x17, #0x0, lsl #48
    b75c:      	str	x17, [x16, #0x8]
    b760:      	add	x16, sp, #0xc0
    b764:      	movz	x17, #0x0, lsl #48
    b768:      	str	x17, [x16, #0x10]
    b76c:      	b	0xb77c <_stogir.dominators.build-index+0x544>
    b770:      	sub	x0, x0, #0x1
    b774:      	add	x16, sp, #0x90
    b778:      	str	x0, [x16, #0x8]
    b77c:      	add	x16, sp, #0x90
    b780:      	ldr	x0, [x16, #0x8]
    b784:      	cmp	x0, #0x0
    b788:      	b.ne	0xb770 <_stogir.dominators.build-index+0x538>
    b78c:      	add	x16, sp, #0x90
    b790:      	orr	x0, x16, xzr
    b794:      	add	x16, sp, #0x90
    b798:      	ldr	x1, [x16, #0x10]
    b79c:      	cmp	x1, #0x0
    b7a0:      	b.le	0xb7d0 <_stogir.dominators.build-index+0x598>
    b7a4:      	add	x0, x0, #0x18
    b7a8:      	add	x16, sp, #0x90
    b7ac:      	ldr	x2, [x16]
    b7b0:      	fmov	d31, x1
    b7b4:      	mov	x1, x2
    b7b8:      	fmov	x2, d31
    b7bc:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000b7bc:  ARM64_RELOC_PAGE21	l_stogir.493
    b7c0:      	ldr	x3, [x3]
		000000000000b7c0:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b7c4:      	mov	x4, #0x4                ; =4
    b7c8:      	mov	x5, #0x4                ; =4
    b7cc:      	bl	0xb7cc <_stogir.dominators.build-index+0x594>
		000000000000b7cc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b7d0:      	add	x16, sp, #0x90
    b7d4:      	movz	x17, #0x0, lsl #48
    b7d8:      	str	x17, [x16]
    b7dc:      	add	x16, sp, #0x90
    b7e0:      	movz	x17, #0x0, lsl #48
    b7e4:      	str	x17, [x16, #0x8]
    b7e8:      	add	x16, sp, #0x90
    b7ec:      	movz	x17, #0x0, lsl #48
    b7f0:      	str	x17, [x16, #0x10]
    b7f4:      	b	0xb804 <_stogir.dominators.build-index+0x5cc>
    b7f8:      	sub	x0, x0, #0x1
    b7fc:      	add	x16, sp, #0x60
    b800:      	str	x0, [x16, #0x8]
    b804:      	add	x16, sp, #0x60
    b808:      	ldr	x0, [x16, #0x8]
    b80c:      	cmp	x0, #0x0
    b810:      	b.ne	0xb7f8 <_stogir.dominators.build-index+0x5c0>
    b814:      	add	x16, sp, #0x60
    b818:      	orr	x0, x16, xzr
    b81c:      	add	x16, sp, #0x60
    b820:      	ldr	x1, [x16, #0x10]
    b824:      	cmp	x1, #0x0
    b828:      	b.le	0xb858 <_stogir.dominators.build-index+0x620>
    b82c:      	add	x0, x0, #0x18
    b830:      	add	x16, sp, #0x60
    b834:      	ldr	x2, [x16]
    b838:      	fmov	d31, x1
    b83c:      	mov	x1, x2
    b840:      	fmov	x2, d31
    b844:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000b844:  ARM64_RELOC_PAGE21	l_stogir.493
    b848:      	ldr	x3, [x3]
		000000000000b848:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b84c:      	mov	x4, #0x4                ; =4
    b850:      	mov	x5, #0x4                ; =4
    b854:      	bl	0xb854 <_stogir.dominators.build-index+0x61c>
		000000000000b854:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b858:      	add	x16, sp, #0x60
    b85c:      	movz	x17, #0x0, lsl #48
    b860:      	str	x17, [x16]
    b864:      	add	x16, sp, #0x60
    b868:      	movz	x17, #0x0, lsl #48
    b86c:      	str	x17, [x16, #0x8]
    b870:      	add	x16, sp, #0x60
    b874:      	movz	x17, #0x0, lsl #48
    b878:      	str	x17, [x16, #0x10]
    b87c:      	add	x16, sp, #0x10
    b880:      	ldr	x0, [x16]
    b884:      	add	x16, sp, #0x10
    b888:      	ldr	x1, [x16, #0x8]
    b88c:      	add	x16, sp, #0x10
    b890:      	ldr	x2, [x16, #0x10]
    b894:      	add	x16, sp, #0x10
    b898:      	ldr	x3, [x16, #0x18]
    b89c:      	add	x16, sp, #0x10
    b8a0:      	ldr	x4, [x16, #0x20]
    b8a4:      	add	x16, sp, #0x10
    b8a8:      	ldr	x5, [x16, #0x28]
    b8ac:      	add	x16, sp, #0x10
    b8b0:      	ldr	x6, [x16, #0x30]
    b8b4:      	add	x16, sp, #0x10
    b8b8:      	ldr	x7, [x16, #0x38]
    b8bc:      	add	x16, sp, #0x10
    b8c0:      	ldr	x8, [x16, #0x40]
    b8c4:      	add	x16, sp, #0x10
    b8c8:      	ldr	x9, [x16, #0x48]
    b8cc:      	str	x0, [x20]
    b8d0:      	str	x1, [x20, #0x8]
    b8d4:      	str	x2, [x20, #0x10]
    b8d8:      	str	x3, [x20, #0x18]
    b8dc:      	str	x4, [x20, #0x20]
    b8e0:      	str	x5, [x20, #0x28]
    b8e4:      	str	x6, [x20, #0x30]
    b8e8:      	str	x7, [x20, #0x38]
    b8ec:      	str	x8, [x20, #0x40]
    b8f0:      	str	x9, [x20, #0x48]
    b8f4:      	ldr	x19, [sp, #0xf0]
    b8f8:      	ldr	x20, [sp, #0xf8]
    b8fc:      	ldr	x21, [sp, #0x100]
    b900:      	ldr	x22, [sp, #0x108]
    b904:      	ldr	x23, [sp, #0x110]
    b908:      	ldr	x24, [sp, #0x118]
    b90c:      	ldr	x25, [sp, #0x120]
    b910:      	ldr	x29, [sp]
    b914:      	ldr	x30, [sp, #0x8]
    b918:      	add	sp, sp, #0x130
    b91c:      	ret
    b920:      	mov	x20, x8
    b924:      	mov	x21, x0
    b928:      	b	0xb3a4 <_stogir.dominators.build-index+0x16c>
    b92c:      	udf	#0x0

000000000000b930 <_stogir.dominators.release-index!>:
    b930:      	sub	sp, sp, #0x20
    b934:      	str	x29, [sp]
    b938:      	str	x30, [sp, #0x8]
    b93c:      	mov	x29, sp
    b940:      	str	x19, [sp, #0x10]
    b944:      	str	x20, [sp, #0x18]
    b948:      	b	0xb958 <_stogir.dominators.release-index!+0x28>
    b94c:      	nop
    b950:      	sub	x1, x1, #0x1
    b954:      	str	x1, [x0, #0x8]
    b958:      	ldr	x1, [x0, #0x8]
    b95c:      	cmp	x1, #0x0
    b960:      	b.ne	0xb950 <_stogir.dominators.release-index!+0x20>
    b964:      	ldr	x1, [x0, #0x10]
    b968:      	cmp	x1, #0x0
    b96c:      	b.le	0xba3c <_stogir.dominators.release-index!+0x10c>
    b970:      	add	x2, x0, #0x18
    b974:      	ldr	x3, [x0]
    b978:      	mov	x19, x0
    b97c:      	mov	x0, x2
    b980:      	mov	x2, x1
    b984:      	mov	x1, x3
    b988:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000b988:  ARM64_RELOC_PAGE21	l_stogir.494
    b98c:      	ldr	x3, [x3]
		000000000000b98c:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    b990:      	mov	x4, #0x4                ; =4
    b994:      	mov	x5, #0x4                ; =4
    b998:      	bl	0xb998 <_stogir.dominators.release-index!+0x68>
		000000000000b998:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b99c:      	add	x20, x19, #0x28
    b9a0:      	movz	x17, #0x0, lsl #48
    b9a4:      	str	x17, [x19]
    b9a8:      	movz	x17, #0x0, lsl #48
    b9ac:      	str	x17, [x19, #0x8]
    b9b0:      	movz	x17, #0x0, lsl #48
    b9b4:      	str	x17, [x19, #0x10]
    b9b8:      	b	0xb9c8 <_stogir.dominators.release-index!+0x98>
    b9bc:      	nop
    b9c0:      	sub	x0, x0, #0x1
    b9c4:      	str	x0, [x20, #0x8]
    b9c8:      	ldr	x0, [x20, #0x8]
    b9cc:      	cmp	x0, #0x0
    b9d0:      	b.ne	0xb9c0 <_stogir.dominators.release-index!+0x90>
    b9d4:      	ldr	x0, [x20, #0x10]
    b9d8:      	cmp	x0, #0x0
    b9dc:      	b.le	0xba0c <_stogir.dominators.release-index!+0xdc>
    b9e0:      	add	x1, x20, #0x18
    b9e4:      	ldr	x2, [x19, #0x28]
    b9e8:      	fmov	d31, x0
    b9ec:      	mov	x0, x1
    b9f0:      	mov	x1, x2
    b9f4:      	fmov	x2, d31
    b9f8:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000b9f8:  ARM64_RELOC_PAGE21	l_stogir.494
    b9fc:      	ldr	x3, [x3]
		000000000000b9fc:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    ba00:      	mov	x4, #0x4                ; =4
    ba04:      	mov	x5, #0x4                ; =4
    ba08:      	bl	0xba08 <_stogir.dominators.release-index!+0xd8>
		000000000000ba08:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    ba0c:      	movz	x17, #0x0, lsl #48
    ba10:      	str	x17, [x19, #0x28]
    ba14:      	movz	x17, #0x0, lsl #48
    ba18:      	str	x17, [x20, #0x8]
    ba1c:      	movz	x17, #0x0, lsl #48
    ba20:      	str	x17, [x20, #0x10]
    ba24:      	ldr	x19, [sp, #0x10]
    ba28:      	ldr	x20, [sp, #0x18]
    ba2c:      	ldr	x29, [sp]
    ba30:      	ldr	x30, [sp, #0x8]
    ba34:      	add	sp, sp, #0x20
    ba38:      	ret
    ba3c:      	mov	x19, x0
    ba40:      	b	0xb99c <_stogir.dominators.release-index!+0x6c>

000000000000ba44 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64>:
    ba44:      	sub	sp, sp, #0x30
    ba48:      	str	x29, [sp]
    ba4c:      	str	x30, [sp, #0x8]
    ba50:      	mov	x29, sp
    ba54:      	str	x19, [sp, #0x10]
    ba58:      	str	x20, [sp, #0x18]
    ba5c:      	str	x21, [sp, #0x20]
    ba60:      	str	x22, [sp, #0x28]
    ba64:      	ldr	x2, [x0, #0x8]
    ba68:      	orr	x19, x2, xzr
    ba6c:      	ldr	x2, [x0, #0x10]
    ba70:      	add	x20, x19, x1
    ba74:      	cmp	x20, x2
    ba78:      	b.le	0xbaf4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0xb0>
    ba7c:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    ba80:      	cmp	x2, x17
    ba84:      	b.gt	0xba90 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x4c>
    ba88:      	lsl	x2, x2, #1
    ba8c:      	b	0xba94 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x50>
    ba90:      	mov	x2, x20
    ba94:      	cmp	x2, x20
    ba98:      	b.gt	0xbaa0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x5c>
    ba9c:      	mov	x2, x20
    baa0:      	mov	x21, x0
    baa4:      	mov	x22, x1
    baa8:      	mov	x1, x2
    baac:      	bl	0xbaac <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x68>
		000000000000baac:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    bab0:      	lsl	x0, x22, #3
    bab4:      	ldr	x1, [x21]
    bab8:      	add	x1, x1, x19, lsl #3
    babc:      	mov	x2, x0
    bac0:      	mov	x0, x1
    bac4:      	movz	x1, #0x0, lsl #48
    bac8:      	bl	0xbac8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x84>
		000000000000bac8:  ARM64_RELOC_BRANCH26	_memset
    bacc:      	str	x20, [x21, #0x8]
    bad0:      	mov	x0, x20
    bad4:      	ldr	x19, [sp, #0x10]
    bad8:      	ldr	x20, [sp, #0x18]
    badc:      	ldr	x21, [sp, #0x20]
    bae0:      	ldr	x22, [sp, #0x28]
    bae4:      	ldr	x29, [sp]
    bae8:      	ldr	x30, [sp, #0x8]
    baec:      	add	sp, sp, #0x30
    baf0:      	ret
    baf4:      	mov	x21, x0
    baf8:      	mov	x22, x1
    bafc:      	b	0xbab0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x6c>

000000000000bb00 <_stogir.uses.scan!__constfalse>:
    bb00:      	sub	sp, sp, #0x10
    bb04:      	mov	x3, #0x1                ; =1
    bb08:      	b	0xbc2c <_stogir.uses.scan!__constfalse+0x12c>
    bb0c:      	sub	w10, w8, #0x1
    bb10:      	lsl	w10, w10, #2
    bb14:      	ubfx	x10, x10, #0, #32
    bb18:      	lsr	x10, x5, x10
    bb1c:      	and	w10, w10, #0xf
    bb20:      	b	0xbb2c <_stogir.uses.scan!__constfalse+0x2c>
    bb24:      	nop
    bb28:      	movz	w10, #0x0, lsl #16
    bb2c:      	ubfx	x10, x10, #0, #32
    bb30:      	cmp	x10, #0xf
    bb34:      	b.hs	0xbbe4 <_stogir.uses.scan!__constfalse+0xe4>
    bb38:      	mov	x16, #0x1               ; =1
    bb3c:      	lsl	x10, x16, x10
    bb40:      	mov	w17, #0x5e1c            ; =24092
    bb44:      	and	w10, w10, w17
    bb48:      	ubfx	x10, x10, #0, #32
    bb4c:      	cmp	x10, #0x0
    bb50:      	b.eq	0xbbe4 <_stogir.uses.scan!__constfalse+0xe4>
    bb54:      	ldr	x10, [x0]
    bb58:      	asr	x16, x9, #63
    bb5c:      	lsr	x16, x16, #62
    bb60:      	add	x11, x9, x16
    bb64:      	asr	x11, x11, #2
    bb68:      	asr	x16, x9, #63
    bb6c:      	lsr	x16, x16, #62
    bb70:      	add	x9, x9, x16
    bb74:      	and	x9, x9, #0x3
    bb78:      	sub	x9, x9, x16
    bb7c:      	add	x11, x11, x3
    bb80:      	add	x10, x10, x11, lsl #4
    bb84:      	add	x9, x10, x9, lsl #2
    bb88:      	ldr	w9, [x9]
    bb8c:      	sxtw	x9, w9
    bb90:      	cmp	x9, #0x0
    bb94:      	b.le	0xbbe4 <_stogir.uses.scan!__constfalse+0xe4>
    bb98:      	ldr	x10, [x2]
    bb9c:      	add	x10, x10, x9, lsl #3
    bba0:      	ldr	x10, [x10]
    bba4:      	mov	x16, sp
    bba8:      	movz	x17, #0x0, lsl #48
    bbac:      	str	x17, [x16]
    bbb0:      	add	x11, x10, #0x1
    bbb4:      	mov	x16, sp
    bbb8:      	str	w4, [x16]
    bbbc:      	mov	x16, sp
    bbc0:      	str	w8, [x16, #0x4]
    bbc4:      	mov	x16, sp
    bbc8:      	ldr	x8, [x16]
    bbcc:      	ldr	x12, [x1, #0x28]
    bbd0:      	add	x10, x12, x10, lsl #3
    bbd4:      	str	x8, [x10]
    bbd8:      	ldr	x8, [x2]
    bbdc:      	add	x8, x8, x9, lsl #3
    bbe0:      	str	x11, [x8]
    bbe4:      	add	x7, x7, #0x1
    bbe8:      	sxtw	x7, w7
    bbec:      	cmp	x7, x6
    bbf0:      	b.gt	0xbc14 <_stogir.uses.scan!__constfalse+0x114>
    bbf4:      	orr	w8, w7, wzr
    bbf8:      	sxtw	x9, w8
    bbfc:      	cmp	x9, #0x0
    bc00:      	b.le	0xbb28 <_stogir.uses.scan!__constfalse+0x28>
    bc04:      	cmp	x9, #0x4
    bc08:      	b.le	0xbb0c <_stogir.uses.scan!__constfalse+0xc>
    bc0c:      	mov	w10, #0x4               ; =4
    bc10:      	b	0xbb10 <_stogir.uses.scan!__constfalse+0x10>
    bc14:      	add	x4, x6, #0x4
    bc18:      	asr	x16, x4, #63
    bc1c:      	lsr	x16, x16, #62
    bc20:      	add	x4, x4, x16
    bc24:      	asr	x4, x4, #2
    bc28:      	add	x3, x4, x3
    bc2c:      	ldr	x4, [x0, #0x8]
    bc30:      	cmp	x3, x4
    bc34:      	b.ge	0xbc74 <_stogir.uses.scan!__constfalse+0x174>
    bc38:      	orr	w4, w3, wzr
    bc3c:      	ldr	x5, [x0]
    bc40:      	add	x5, x5, x3, lsl #4
    bc44:      	ldr	x5, [x5]
    bc48:      	ldr	x6, [x0, #0x78]
    bc4c:      	uxtb	w5, w5
    bc50:      	add	x6, x6, x3, lsl #2
    bc54:      	adrp	x16, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000bc54:  ARM64_RELOC_PAGE21	l_stogir.495
    bc58:      	ldr	x16, [x16]
		000000000000bc58:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    bc5c:      	add	x5, x16, x5, lsl #2
    bc60:      	ldr	w6, [x6]
    bc64:      	sxtw	x6, w6
    bc68:      	ldr	w5, [x5]
    bc6c:      	mov	x7, #0x1                ; =1
    bc70:      	b	0xbbec <_stogir.uses.scan!__constfalse+0xec>
    bc74:      	add	sp, sp, #0x10
    bc78:      	ret

000000000000bc7c <_stogir.opcode.properties>:
    bc7c:      	sxtw	x0, w0
    bc80:      	cmp	x0, #0x0
    bc84:      	b.lt	0xbca4 <_stogir.opcode.properties+0x28>
    bc88:      	cmp	x0, #0x83
    bc8c:      	b.ge	0xbca4 <_stogir.opcode.properties+0x28>
    bc90:      	adrp	x16, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000bc90:  ARM64_RELOC_PAGE21	l_stogir.496
    bc94:      	ldr	x16, [x16]
		000000000000bc94:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    bc98:      	add	x0, x16, x0
    bc9c:      	ldrb	w0, [x0]
    bca0:      	b	0xbca8 <_stogir.opcode.properties+0x2c>
    bca4:      	movz	x0, #0x0, lsl #48
    bca8:      	ret

000000000000bcac <_stogir.graph.lookup>:
    bcac:      	sxtw	x1, w1
    bcb0:      	add	x2, x0, #0x28
    bcb4:      	cmp	x1, #0x0
    bcb8:      	cset	w3, gt
    bcbc:      	movz	x16, #0x0, lsl #48
    bcc0:      	sub	x4, x16, x1
    bcc4:      	sub	x5, x4, #0x1
    bcc8:      	uxtb	w16, w3
    bccc:      	cmp	w16, wzr
    bcd0:      	b.eq	0xbd10 <_stogir.graph.lookup+0x64>
    bcd4:      	ldr	x2, [x0, #0x8]
    bcd8:      	cmp	x1, x2
    bcdc:      	b.ge	0xbd5c <_stogir.graph.lookup+0xb0>
    bce0:      	add	x2, x0, #0x78
    bce4:      	ldr	x2, [x2, #0x8]
    bce8:      	cmp	x1, x2
    bcec:      	b.ge	0xbdd4 <_stogir.graph.lookup+0x128>
    bcf0:      	ldr	x2, [x0, #0x78]
    bcf4:      	add	x2, x2, x1, lsl #2
    bcf8:      	ldr	w2, [x2]
    bcfc:      	sxtw	x2, w2
    bd00:      	cmp	x2, #0x0
    bd04:      	cset	w2, ge
    bd08:      	ubfx	x2, x2, #0, #8
    bd0c:      	b	0xbdd8 <_stogir.graph.lookup+0x12c>
    bd10:      	cmp	x1, #0x0
    bd14:      	b.ge	0xbd64 <_stogir.graph.lookup+0xb8>
    bd18:      	add	x6, x0, #0x50
    bd1c:      	ldr	x2, [x2, #0x8]
    bd20:      	ldr	x6, [x6, #0x8]
    bd24:      	cmp	x2, x6
    bd28:      	b.ne	0xbd54 <_stogir.graph.lookup+0xa8>
    bd2c:      	cmp	x4, x2
    bd30:      	b.gt	0xbddc <_stogir.graph.lookup+0x130>
    bd34:      	ldr	x2, [x0, #0x50]
    bd38:      	add	x2, x2, x5, lsl #2
    bd3c:      	ldr	w2, [x2]
    bd40:      	sxtw	x2, w2
    bd44:      	cmp	x2, #0x0
    bd48:      	cset	w2, gt
    bd4c:      	ubfx	x2, x2, #0, #8
    bd50:      	b	0xbde0 <_stogir.graph.lookup+0x134>
    bd54:      	movz	x2, #0x0, lsl #48
    bd58:      	b	0xbd68 <_stogir.graph.lookup+0xbc>
    bd5c:      	movz	x2, #0x0, lsl #48
    bd60:      	b	0xbd68 <_stogir.graph.lookup+0xbc>
    bd64:      	movz	x2, #0x0, lsl #48
    bd68:      	cmp	x2, #0x0
    bd6c:      	b.eq	0xbda8 <_stogir.graph.lookup+0xfc>
    bd70:      	uxtb	w16, w3
    bd74:      	cmp	w16, wzr
    bd78:      	b.eq	0xbd90 <_stogir.graph.lookup+0xe4>
    bd7c:      	ldr	x0, [x0]
    bd80:      	add	x0, x0, x1, lsl #4
    bd84:      	ldr	x1, [x0]
    bd88:      	ldr	x0, [x0, #0x8]
    bd8c:      	b	0xbda0 <_stogir.graph.lookup+0xf4>
    bd90:      	ldr	x0, [x0, #0x28]
    bd94:      	add	x0, x0, x5, lsl #4
    bd98:      	ldr	x1, [x0]
    bd9c:      	ldr	x0, [x0, #0x8]
    bda0:      	mov	x2, #0x1                ; =1
    bda4:      	b	0xbdb4 <_stogir.graph.lookup+0x108>
    bda8:      	movz	x2, #0x0, lsl #48
    bdac:      	movz	x1, #0x0, lsl #48
    bdb0:      	movz	x0, #0x0, lsl #48
    bdb4:      	str	x2, [x8]
    bdb8:      	str	x1, [x8, #0x8]
    bdbc:      	str	x0, [x8, #0x10]
    bdc0:      	movz	x17, #0x0, lsl #48
    bdc4:      	str	x17, [x8, #0x18]
    bdc8:      	movz	x17, #0x0, lsl #48
    bdcc:      	str	x17, [x8, #0x20]
    bdd0:      	ret
    bdd4:      	movz	x2, #0x0, lsl #48
    bdd8:      	b	0xbd60 <_stogir.graph.lookup+0xb4>
    bddc:      	movz	x2, #0x0, lsl #48
    bde0:      	b	0xbd58 <_stogir.graph.lookup+0xac>
    bde4:      	udf	#0x0

000000000000bde8 <_stogir.dominators.dominates?>:
    bde8:      	sxtw	x1, w1
    bdec:      	sxtw	x2, w2
    bdf0:      	movz	x3, #0x0, lsl #48
    bdf4:      	movz	x4, #0x0, lsl #48
    bdf8:      	b	0xbe0c <_stogir.dominators.dominates?+0x24>
    bdfc:      	mov	x2, x5
    be00:      	b	0xbe0c <_stogir.dominators.dominates?+0x24>
    be04:      	nop
    be08:      	mov	x3, #0x1                ; =1
    be0c:      	cmp	x3, #0x0
    be10:      	b.ne	0xbe5c <_stogir.dominators.dominates?+0x74>
    be14:      	cmp	x2, #0x0
    be18:      	b.le	0xbe08 <_stogir.dominators.dominates?+0x20>
    be1c:      	ldr	x5, [x0, #0x8]
    be20:      	cmp	x2, x5
    be24:      	b.ge	0xbe08 <_stogir.dominators.dominates?+0x20>
    be28:      	ldr	x5, [x0]
    be2c:      	add	x5, x5, x2, lsl #2
    be30:      	ldr	w5, [x5]
    be34:      	sxtw	x5, w5
    be38:      	cmp	x5, #0x0
    be3c:      	b.ne	0xbe48 <_stogir.dominators.dominates?+0x60>
    be40:      	mov	x3, #0x1                ; =1
    be44:      	b	0xbe00 <_stogir.dominators.dominates?+0x18>
    be48:      	cmp	x2, x1
    be4c:      	b.ne	0xbe64 <_stogir.dominators.dominates?+0x7c>
    be50:      	mov	x3, #0x1                ; =1
    be54:      	mov	x4, #0x1                ; =1
    be58:      	b	0xbe00 <_stogir.dominators.dominates?+0x18>
    be5c:      	mov	x0, x4
    be60:      	ret
    be64:      	cmp	x2, x5
    be68:      	b.ne	0xbdfc <_stogir.dominators.dominates?+0x14>
    be6c:      	mov	x3, #0x1                ; =1
    be70:      	b	0xbe00 <_stogir.dominators.dominates?+0x18>

000000000000be74 <_stogir.placement.use-block>:
    be74:      	sub	sp, sp, #0x50
    be78:      	str	x29, [sp, #0x10]
    be7c:      	str	x30, [sp, #0x18]
    be80:      	add	x29, sp, #0x10
    be84:      	str	x19, [sp, #0x30]
    be88:      	str	x20, [sp, #0x38]
    be8c:      	str	x21, [sp, #0x40]
    be90:      	str	x22, [sp, #0x48]
    be94:      	sxtw	x2, w2
    be98:      	add	x19, x0, #0x78
    be9c:      	add	x4, x0, #0x28
    bea0:      	lsl	x5, x2, #2
    bea4:      	cmp	x2, #0x0
    bea8:      	cset	w6, gt
    beac:      	movz	x16, #0x0, lsl #48
    beb0:      	sub	x7, x16, x2
    beb4:      	sub	x9, x7, #0x1
    beb8:      	uxtb	w16, w6
    bebc:      	cmp	w16, wzr
    bec0:      	b.eq	0xbefc <_stogir.placement.use-block+0x88>
    bec4:      	ldr	x4, [x0, #0x8]
    bec8:      	cmp	x2, x4
    becc:      	b.ge	0xbf48 <_stogir.placement.use-block+0xd4>
    bed0:      	ldr	x4, [x19, #0x8]
    bed4:      	cmp	x2, x4
    bed8:      	b.ge	0xc028 <_stogir.placement.use-block+0x1b4>
    bedc:      	ldr	x4, [x0, #0x78]
    bee0:      	add	x4, x5, x4
    bee4:      	ldr	w4, [x4]
    bee8:      	sxtw	x4, w4
    beec:      	cmp	x4, #0x0
    bef0:      	cset	w4, ge
    bef4:      	ubfx	x4, x4, #0, #8
    bef8:      	b	0xc02c <_stogir.placement.use-block+0x1b8>
    befc:      	cmp	x2, #0x0
    bf00:      	b.ge	0xbf50 <_stogir.placement.use-block+0xdc>
    bf04:      	add	x10, x0, #0x50
    bf08:      	ldr	x4, [x4, #0x8]
    bf0c:      	ldr	x10, [x10, #0x8]
    bf10:      	cmp	x4, x10
    bf14:      	b.ne	0xbf40 <_stogir.placement.use-block+0xcc>
    bf18:      	cmp	x7, x4
    bf1c:      	b.gt	0xc044 <_stogir.placement.use-block+0x1d0>
    bf20:      	ldr	x4, [x0, #0x50]
    bf24:      	add	x4, x4, x9, lsl #2
    bf28:      	ldr	w4, [x4]
    bf2c:      	sxtw	x4, w4
    bf30:      	cmp	x4, #0x0
    bf34:      	cset	w4, gt
    bf38:      	ubfx	x4, x4, #0, #8
    bf3c:      	b	0xc048 <_stogir.placement.use-block+0x1d4>
    bf40:      	movz	x4, #0x0, lsl #48
    bf44:      	b	0xbf54 <_stogir.placement.use-block+0xe0>
    bf48:      	movz	x4, #0x0, lsl #48
    bf4c:      	b	0xbf54 <_stogir.placement.use-block+0xe0>
    bf50:      	movz	x4, #0x0, lsl #48
    bf54:      	lsl	x7, x2, #4
    bf58:      	cmp	x4, #0x0
    bf5c:      	b.eq	0xbf90 <_stogir.placement.use-block+0x11c>
    bf60:      	uxtb	w16, w6
    bf64:      	cmp	w16, wzr
    bf68:      	b.eq	0xbf7c <_stogir.placement.use-block+0x108>
    bf6c:      	ldr	x4, [x0]
    bf70:      	add	x4, x7, x4
    bf74:      	ldr	x4, [x4]
    bf78:      	b	0xbf88 <_stogir.placement.use-block+0x114>
    bf7c:      	ldr	x4, [x0, #0x28]
    bf80:      	add	x4, x4, x9, lsl #4
    bf84:      	ldr	x4, [x4]
    bf88:      	mov	w6, #0x1                ; =1
    bf8c:      	b	0xbf98 <_stogir.placement.use-block+0x124>
    bf90:      	movz	w6, #0x0, lsl #16
    bf94:      	movz	x4, #0x0, lsl #48
    bf98:      	ubfx	x6, x6, #0, #32
    bf9c:      	lsr	x16, x6, #0
    bfa0:      	cmp	x16, #0x1
    bfa4:      	b.eq	0xbfc0 <_stogir.placement.use-block+0x14c>
    bfa8:      	b.lo	0xbfb0 <_stogir.placement.use-block+0x13c>
    bfac:      	b	0xbfc4 <_stogir.placement.use-block+0x150>
    bfb0:      	cmp	x16, #0x0
    bfb4:      	b.eq	0xbfbc <_stogir.placement.use-block+0x148>
    bfb8:      	b	0xbfc4 <_stogir.placement.use-block+0x150>
    bfbc:      	b	0xbfc8 <_stogir.placement.use-block+0x154>
    bfc0:      	b	0xc008 <_stogir.placement.use-block+0x194>
    bfc4:      	b	0xc0e8 <_stogir.placement.use-block+0x274>
    bfc8:      	mov	x20, x8
    bfcc:      	mov	x1, #0x1                ; =1
    bfd0:      	adrp	x0, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x94>
		000000000000bfd0:  ARM64_RELOC_PAGE21	l_stogir.497
    bfd4:      	ldr	x0, [x0]
		000000000000bfd4:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    bfd8:      	mov	x2, #0x21               ; =33
    bfdc:      	str	x1, [x20]
    bfe0:      	str	x0, [x20, #0x8]
    bfe4:      	str	x2, [x20, #0x10]
    bfe8:      	ldr	x19, [sp, #0x30]
    bfec:      	ldr	x20, [sp, #0x38]
    bff0:      	ldr	x21, [sp, #0x40]
    bff4:      	ldr	x22, [sp, #0x48]
    bff8:      	ldr	x29, [sp, #0x10]
    bffc:      	ldr	x30, [sp, #0x18]
    c000:      	add	sp, sp, #0x50
    c004:      	ret
    c008:      	cmp	x2, #0x0
    c00c:      	b.gt	0xc030 <_stogir.placement.use-block+0x1bc>
    c010:      	mov	x20, x8
    c014:      	mov	x1, #0x1                ; =1
    c018:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c018:  ARM64_RELOC_PAGE21	l_stogir.498
    c01c:      	ldr	x0, [x0]
		000000000000c01c:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    c020:      	mov	x2, #0x13               ; =19
    c024:      	b	0xbfdc <_stogir.placement.use-block+0x168>
    c028:      	movz	x4, #0x0, lsl #48
    c02c:      	b	0xbf4c <_stogir.placement.use-block+0xd8>
    c030:      	sxtw	x6, w3
    c034:      	cmp	x6, #0x1
    c038:      	b.ge	0xc04c <_stogir.placement.use-block+0x1d8>
    c03c:      	mov	x20, x8
    c040:      	b	0xc014 <_stogir.placement.use-block+0x1a0>
    c044:      	movz	x4, #0x0, lsl #48
    c048:      	b	0xbf44 <_stogir.placement.use-block+0xd0>
    c04c:      	ldr	x9, [x0, #0x78]
    c050:      	add	x10, x5, x9
    c054:      	ldr	w10, [x10]
    c058:      	sxtw	x10, w10
    c05c:      	cmp	x6, x10
    c060:      	b.gt	0xc2b0 <_stogir.placement.use-block+0x43c>
    c064:      	uxtb	w4, w4
    c068:      	cmp	x4, #0x43
    c06c:      	b.ne	0xc2b8 <_stogir.placement.use-block+0x444>
    c070:      	cmp	x6, #0x2
    c074:      	b.lt	0xc2c4 <_stogir.placement.use-block+0x450>
    c078:      	ldr	x4, [x0, #0x8]
    c07c:      	cmp	x2, x4
    c080:      	b.ge	0xc14c <_stogir.placement.use-block+0x2d8>
    c084:      	ldr	x4, [x19, #0x8]
    c088:      	cmp	x2, x4
    c08c:      	b.ge	0xc18c <_stogir.placement.use-block+0x318>
    c090:      	add	x2, x5, x9
    c094:      	ldr	w2, [x2]
    c098:      	sxtw	x2, w2
    c09c:      	cmp	x2, #0x0
    c0a0:      	cset	w2, ge
    c0a4:      	ubfx	x2, x2, #0, #8
    c0a8:      	b	0xc190 <_stogir.placement.use-block+0x31c>
    c0ac:      	and	x0, x0, #0xffffffff
    c0b0:      	movz	x1, #0x0, lsl #48
    c0b4:      	movz	x2, #0x0, lsl #48
    c0b8:      	b	0xc024 <_stogir.placement.use-block+0x1b0>
    c0bc:      	ldr	x0, [x22]
    c0c0:      	add	x0, x0, x2, lsl #2
    c0c4:      	ldr	w0, [x0]
    c0c8:      	sxtw	x0, w0
    c0cc:      	cmp	x0, #0x0
    c0d0:      	b.ne	0xc0ac <_stogir.placement.use-block+0x238>
    c0d4:      	mov	x1, #0x1                ; =1
    c0d8:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c0d8:  ARM64_RELOC_PAGE21	l_stogir.499
    c0dc:      	ldr	x0, [x0]
		000000000000c0dc:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    c0e0:      	mov	x2, #0xf                ; =15
    c0e4:      	b	0xc0b8 <_stogir.placement.use-block+0x244>
    c0e8:      	brk	#0
    c0ec:      	b	0xc0e8 <_stogir.placement.use-block+0x274>
    c0f0:      	movz	w4, #0x0, lsl #16
    c0f4:      	movz	w2, #0x0, lsl #16
    c0f8:      	ubfx	x4, x4, #0, #32
    c0fc:      	lsr	x16, x4, #0
    c100:      	cmp	x16, #0x1
    c104:      	b.eq	0xc120 <_stogir.placement.use-block+0x2ac>
    c108:      	b.lo	0xc110 <_stogir.placement.use-block+0x29c>
    c10c:      	b	0xc124 <_stogir.placement.use-block+0x2b0>
    c110:      	cmp	x16, #0x0
    c114:      	b.eq	0xc11c <_stogir.placement.use-block+0x2a8>
    c118:      	b	0xc124 <_stogir.placement.use-block+0x2b0>
    c11c:      	b	0xc128 <_stogir.placement.use-block+0x2b4>
    c120:      	b	0xc194 <_stogir.placement.use-block+0x320>
    c124:      	b	0xc2a0 <_stogir.placement.use-block+0x42c>
    c128:      	mov	x20, x8
    c12c:      	mov	x1, #0x1                ; =1
    c130:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c130:  ARM64_RELOC_PAGE21	l_stogir.500
    c134:      	ldr	x0, [x0]
		000000000000c134:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c138:      	mov	x2, #0x12               ; =18
    c13c:      	b	0xc0b8 <_stogir.placement.use-block+0x244>
    c140:      	movz	w4, #0x0, lsl #16
    c144:      	movz	w2, #0x0, lsl #16
    c148:      	b	0xc0f8 <_stogir.placement.use-block+0x284>
    c14c:      	movz	x2, #0x0, lsl #48
    c150:      	cmp	x2, #0x0
    c154:      	b.eq	0xc0f0 <_stogir.placement.use-block+0x27c>
    c158:      	ldr	x2, [x0, #0x78]
    c15c:      	add	x2, x5, x2
    c160:      	ldr	w2, [x2]
    c164:      	sxtw	x2, w2
    c168:      	cmp	x2, #0x1
    c16c:      	b.lt	0xc140 <_stogir.placement.use-block+0x2cc>
    c170:      	ldr	x2, [x0]
    c174:      	add	x2, x7, x2
    c178:      	ldr	w2, [x2, #0x4]
    c17c:      	movn	w17, #0x0, lsl #16
    c180:      	and	w2, w2, w17
    c184:      	mov	w4, #0x1                ; =1
    c188:      	b	0xc148 <_stogir.placement.use-block+0x2d4>
    c18c:      	movz	x2, #0x0, lsl #48
    c190:      	b	0xc150 <_stogir.placement.use-block+0x2dc>
    c194:      	sub	w3, w3, #0x1
    c198:      	mov	x20, x8
    c19c:      	mov	x21, x0
    c1a0:      	mov	x22, x1
    c1a4:      	mov	w1, w2
    c1a8:      	mov	w2, w3
    c1ac:      	bl	0xc1ac <_stogir.placement.use-block+0x338>
		000000000000c1ac:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    c1b0:      	ubfx	x0, x0, #0, #32
    c1b4:      	lsr	x16, x0, #0
    c1b8:      	cmp	x16, #0x1
    c1bc:      	b.eq	0xc1d8 <_stogir.placement.use-block+0x364>
    c1c0:      	b.lo	0xc1c8 <_stogir.placement.use-block+0x354>
    c1c4:      	b	0xc1dc <_stogir.placement.use-block+0x368>
    c1c8:      	cmp	x16, #0x0
    c1cc:      	b.eq	0xc1d4 <_stogir.placement.use-block+0x360>
    c1d0:      	b	0xc1dc <_stogir.placement.use-block+0x368>
    c1d4:      	b	0xc1e0 <_stogir.placement.use-block+0x36c>
    c1d8:      	b	0xc208 <_stogir.placement.use-block+0x394>
    c1dc:      	b	0xc2a8 <_stogir.placement.use-block+0x434>
    c1e0:      	mov	x1, #0x1                ; =1
    c1e4:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c1e4:  ARM64_RELOC_PAGE21	l_stogir.501
    c1e8:      	ldr	x0, [x0]
		000000000000c1e8:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    c1ec:      	mov	x2, #0x17               ; =23
    c1f0:      	b	0xc204 <_stogir.placement.use-block+0x390>
    c1f4:      	mov	x1, #0x1                ; =1
    c1f8:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c1f8:  ARM64_RELOC_PAGE21	l_stogir.502
    c1fc:      	ldr	x0, [x0]
		000000000000c1fc:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    c200:      	mov	x2, #0x25               ; =37
    c204:      	b	0xc13c <_stogir.placement.use-block+0x2c8>
    c208:      	sxtw	x1, w1
    c20c:      	cmp	x1, #0x0
    c210:      	b.le	0xc1f4 <_stogir.placement.use-block+0x380>
    c214:      	lsl	x0, x1, #2
    c218:      	ldr	x2, [x21, #0x8]
    c21c:      	cmp	x1, x2
    c220:      	b.ge	0xc268 <_stogir.placement.use-block+0x3f4>
    c224:      	ldr	x2, [x19, #0x8]
    c228:      	cmp	x1, x2
    c22c:      	b.ge	0xc260 <_stogir.placement.use-block+0x3ec>
    c230:      	ldr	x1, [x21, #0x78]
    c234:      	add	x1, x0, x1
    c238:      	ldr	w1, [x1]
    c23c:      	sxtw	x1, w1
    c240:      	cmp	x1, #0x0
    c244:      	cset	w1, ge
    c248:      	ubfx	x1, x1, #0, #8
    c24c:      	b	0xc264 <_stogir.placement.use-block+0x3f0>
    c250:      	and	x0, x0, #0xffffffff
    c254:      	movz	x1, #0x0, lsl #48
    c258:      	movz	x2, #0x0, lsl #48
    c25c:      	b	0xc204 <_stogir.placement.use-block+0x390>
    c260:      	movz	x1, #0x0, lsl #48
    c264:      	b	0xc26c <_stogir.placement.use-block+0x3f8>
    c268:      	movz	x1, #0x0, lsl #48
    c26c:      	cmp	x1, #0x0
    c270:      	b.eq	0xc1f4 <_stogir.placement.use-block+0x380>
    c274:      	ldr	x1, [x22]
    c278:      	add	x0, x0, x1
    c27c:      	ldr	w0, [x0]
    c280:      	sxtw	x0, w0
    c284:      	cmp	x0, #0x0
    c288:      	b.ne	0xc250 <_stogir.placement.use-block+0x3dc>
    c28c:      	mov	x1, #0x1                ; =1
    c290:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c290:  ARM64_RELOC_PAGE21	l_stogir.503
    c294:      	ldr	x0, [x0]
		000000000000c294:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    c298:      	mov	x2, #0x1a               ; =26
    c29c:      	b	0xc25c <_stogir.placement.use-block+0x3e8>
    c2a0:      	brk	#0
    c2a4:      	b	0xc2a0 <_stogir.placement.use-block+0x42c>
    c2a8:      	brk	#0
    c2ac:      	b	0xc2a8 <_stogir.placement.use-block+0x434>
    c2b0:      	mov	x20, x8
    c2b4:      	b	0xc014 <_stogir.placement.use-block+0x1a0>
    c2b8:      	mov	x20, x8
    c2bc:      	mov	x22, x1
    c2c0:      	b	0xc0bc <_stogir.placement.use-block+0x248>
    c2c4:      	mov	x20, x8
    c2c8:      	mov	x22, x1
    c2cc:      	b	0xc0bc <_stogir.placement.use-block+0x248>

000000000000c2d0 <_stogir.placement.choose-block>:
    c2d0:      	sxtw	x2, w2
    c2d4:      	sxtw	x4, w3
    c2d8:      	mov	x6, x4
    c2dc:      	movz	x5, #0x0, lsl #48
    c2e0:      	movz	x7, #0x0, lsl #48
    c2e4:      	b	0xc2f4 <_stogir.placement.choose-block+0x24>
    c2e8:      	mov	x6, x9
    c2ec:      	b	0xc2f4 <_stogir.placement.choose-block+0x24>
    c2f0:      	mov	x5, #0x1                ; =1
    c2f4:      	cmp	x5, #0x0
    c2f8:      	b.ne	0xc344 <_stogir.placement.choose-block+0x74>
    c2fc:      	cmp	x6, #0x0
    c300:      	b.le	0xc2f0 <_stogir.placement.choose-block+0x20>
    c304:      	ldr	x9, [x0, #0x8]
    c308:      	cmp	x6, x9
    c30c:      	b.ge	0xc2f0 <_stogir.placement.choose-block+0x20>
    c310:      	ldr	x9, [x0]
    c314:      	add	x9, x9, x6, lsl #2
    c318:      	ldr	w9, [x9]
    c31c:      	sxtw	x9, w9
    c320:      	cmp	x9, #0x0
    c324:      	b.ne	0xc330 <_stogir.placement.choose-block+0x60>
    c328:      	mov	x5, #0x1                ; =1
    c32c:      	b	0xc2ec <_stogir.placement.choose-block+0x1c>
    c330:      	cmp	x6, x2
    c334:      	b.ne	0xc350 <_stogir.placement.choose-block+0x80>
    c338:      	mov	x5, #0x1                ; =1
    c33c:      	mov	x7, #0x1                ; =1
    c340:      	b	0xc2ec <_stogir.placement.choose-block+0x1c>
    c344:      	cmp	x7, #0x0
    c348:      	b.eq	0xc3bc <_stogir.placement.choose-block+0xec>
    c34c:      	b	0xc364 <_stogir.placement.choose-block+0x94>
    c350:      	cmp	x6, x9
    c354:      	b.ne	0xc2e8 <_stogir.placement.choose-block+0x18>
    c358:      	mov	x5, #0x1                ; =1
    c35c:      	b	0xc2ec <_stogir.placement.choose-block+0x1c>
    c360:      	mov	x4, x5
    c364:      	sxtw	x3, w3
    c368:      	cmp	x3, x2
    c36c:      	b.eq	0xc3ac <_stogir.placement.choose-block+0xdc>
    c370:      	ldr	x5, [x0]
    c374:      	add	x3, x5, x3, lsl #2
    c378:      	ldr	w3, [x3]
    c37c:      	sxtw	x5, w3
    c380:      	ldr	x6, [x1]
    c384:      	orr	x7, x6, xzr
    c388:      	add	x7, x7, x5, lsl #2
    c38c:      	add	x6, x6, x4, lsl #2
    c390:      	ldr	w7, [x7]
    c394:      	sxtw	x7, w7
    c398:      	ldr	w6, [x6]
    c39c:      	sxtw	x6, w6
    c3a0:      	cmp	x7, x6
    c3a4:      	b.lt	0xc360 <_stogir.placement.choose-block+0x90>
    c3a8:      	b	0xc364 <_stogir.placement.choose-block+0x94>
    c3ac:      	and	x0, x4, #0xffffffff
    c3b0:      	movz	x1, #0x0, lsl #48
    c3b4:      	movz	x2, #0x0, lsl #48
    c3b8:      	b	0xc3cc <_stogir.placement.choose-block+0xfc>
    c3bc:      	mov	x1, #0x1                ; =1
    c3c0:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c3c0:  ARM64_RELOC_PAGE21	l_stogir.504
    c3c4:      	ldr	x0, [x0]
		000000000000c3c4:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    c3c8:      	mov	x2, #0x29               ; =41
    c3cc:      	str	x1, [x8]
    c3d0:      	str	x0, [x8, #0x8]
    c3d4:      	str	x2, [x8, #0x10]
    c3d8:      	ret

000000000000c3dc <_stogir.checked.validate-projection>:
    c3dc:      	sub	sp, sp, #0x40
    c3e0:      	str	x29, [sp]
    c3e4:      	str	x30, [sp, #0x8]
    c3e8:      	mov	x29, sp
    c3ec:      	str	x19, [sp, #0x30]
    c3f0:      	sxtw	x1, w1
    c3f4:      	add	x2, x0, #0x78
    c3f8:      	add	x3, x0, #0x28
    c3fc:      	lsl	x4, x1, #2
    c400:      	cmp	x1, #0x0
    c404:      	cset	w5, gt
    c408:      	movz	x16, #0x0, lsl #48
    c40c:      	sub	x6, x16, x1
    c410:      	sub	x7, x6, #0x1
    c414:      	uxtb	w16, w5
    c418:      	cmp	w16, wzr
    c41c:      	b.eq	0xc458 <_stogir.checked.validate-projection+0x7c>
    c420:      	ldr	x3, [x0, #0x8]
    c424:      	cmp	x1, x3
    c428:      	b.ge	0xc4a4 <_stogir.checked.validate-projection+0xc8>
    c42c:      	ldr	x2, [x2, #0x8]
    c430:      	cmp	x1, x2
    c434:      	b.ge	0xc574 <_stogir.checked.validate-projection+0x198>
    c438:      	ldr	x2, [x0, #0x78]
    c43c:      	add	x2, x4, x2
    c440:      	ldr	w2, [x2]
    c444:      	sxtw	x2, w2
    c448:      	cmp	x2, #0x0
    c44c:      	cset	w2, ge
    c450:      	ubfx	x2, x2, #0, #8
    c454:      	b	0xc578 <_stogir.checked.validate-projection+0x19c>
    c458:      	cmp	x1, #0x0
    c45c:      	b.ge	0xc4ac <_stogir.checked.validate-projection+0xd0>
    c460:      	add	x2, x0, #0x50
    c464:      	ldr	x3, [x3, #0x8]
    c468:      	ldr	x2, [x2, #0x8]
    c46c:      	cmp	x3, x2
    c470:      	b.ne	0xc49c <_stogir.checked.validate-projection+0xc0>
    c474:      	cmp	x6, x3
    c478:      	b.gt	0xc5e0 <_stogir.checked.validate-projection+0x204>
    c47c:      	ldr	x2, [x0, #0x50]
    c480:      	add	x2, x2, x7, lsl #2
    c484:      	ldr	w2, [x2]
    c488:      	sxtw	x2, w2
    c48c:      	cmp	x2, #0x0
    c490:      	cset	w2, gt
    c494:      	ubfx	x2, x2, #0, #8
    c498:      	b	0xc5e4 <_stogir.checked.validate-projection+0x208>
    c49c:      	movz	x2, #0x0, lsl #48
    c4a0:      	b	0xc4b0 <_stogir.checked.validate-projection+0xd4>
    c4a4:      	movz	x2, #0x0, lsl #48
    c4a8:      	b	0xc4b0 <_stogir.checked.validate-projection+0xd4>
    c4ac:      	movz	x2, #0x0, lsl #48
    c4b0:      	cmp	x2, #0x0
    c4b4:      	b.eq	0xc4e8 <_stogir.checked.validate-projection+0x10c>
    c4b8:      	uxtb	w16, w5
    c4bc:      	cmp	w16, wzr
    c4c0:      	b.eq	0xc4d4 <_stogir.checked.validate-projection+0xf8>
    c4c4:      	ldr	x2, [x0]
    c4c8:      	add	x2, x2, x1, lsl #4
    c4cc:      	ldr	x2, [x2]
    c4d0:      	b	0xc4e0 <_stogir.checked.validate-projection+0x104>
    c4d4:      	ldr	x2, [x0, #0x28]
    c4d8:      	add	x2, x2, x7, lsl #4
    c4dc:      	ldr	x2, [x2]
    c4e0:      	mov	w3, #0x1                ; =1
    c4e4:      	b	0xc4f0 <_stogir.checked.validate-projection+0x114>
    c4e8:      	movz	w3, #0x0, lsl #16
    c4ec:      	movz	x2, #0x0, lsl #48
    c4f0:      	ubfx	x3, x3, #0, #32
    c4f4:      	lsr	x16, x3, #0
    c4f8:      	cmp	x16, #0x1
    c4fc:      	b.eq	0xc518 <_stogir.checked.validate-projection+0x13c>
    c500:      	b.lo	0xc508 <_stogir.checked.validate-projection+0x12c>
    c504:      	b	0xc51c <_stogir.checked.validate-projection+0x140>
    c508:      	cmp	x16, #0x0
    c50c:      	b.eq	0xc514 <_stogir.checked.validate-projection+0x138>
    c510:      	b	0xc51c <_stogir.checked.validate-projection+0x140>
    c514:      	b	0xc520 <_stogir.checked.validate-projection+0x144>
    c518:      	b	0xc538 <_stogir.checked.validate-projection+0x15c>
    c51c:      	b	0xc5e8 <_stogir.checked.validate-projection+0x20c>
    c520:      	mov	x19, x8
    c524:      	mov	x0, #0x1                ; =1
    c528:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c528:  ARM64_RELOC_PAGE21	l_stogir.505
    c52c:      	ldr	x1, [x1]
		000000000000c52c:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    c530:      	mov	x2, #0x10               ; =16
    c534:      	b	0xc554 <_stogir.checked.validate-projection+0x178>
    c538:      	cmp	x1, #0x0
    c53c:      	b.gt	0xc57c <_stogir.checked.validate-projection+0x1a0>
    c540:      	mov	x19, x8
    c544:      	mov	x0, #0x1                ; =1
    c548:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c548:  ARM64_RELOC_PAGE21	l_stogir.506
    c54c:      	ldr	x1, [x1]
		000000000000c54c:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    c550:      	mov	x2, #0x1c               ; =28
    c554:      	str	x0, [x19]
    c558:      	str	x1, [x19, #0x8]
    c55c:      	str	x2, [x19, #0x10]
    c560:      	ldr	x19, [sp, #0x30]
    c564:      	ldr	x29, [sp]
    c568:      	ldr	x30, [sp, #0x8]
    c56c:      	add	sp, sp, #0x40
    c570:      	ret
    c574:      	movz	x2, #0x0, lsl #48
    c578:      	b	0xc4a8 <_stogir.checked.validate-projection+0xcc>
    c57c:      	uxtb	w1, w2
    c580:      	cmp	x1, #0x2c
    c584:      	b.ne	0xc5f0 <_stogir.checked.validate-projection+0x214>
    c588:      	orr	w1, w2, wzr
    c58c:      	ubfx	x1, x1, #0, #32
    c590:      	ubfx	x1, x1, #8, #8
    c594:      	cmp	x1, #0x1
    c598:      	b.ne	0xc5f8 <_stogir.checked.validate-projection+0x21c>
    c59c:      	ldr	x1, [x0, #0x78]
    c5a0:      	add	x1, x4, x1
    c5a4:      	ldr	w1, [x1]
    c5a8:      	sxtw	x1, w1
    c5ac:      	cmp	x1, #0x1
    c5b0:      	b.ne	0xc600 <_stogir.checked.validate-projection+0x224>
    c5b4:      	lsr	x1, x2, #32
    c5b8:      	mov	x19, x8
    c5bc:      	add	x8, sp, #0x10
    c5c0:      	bl	0xc5c0 <_stogir.checked.validate-projection+0x1e4>
		000000000000c5c0:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    c5c4:      	add	x16, sp, #0x10
    c5c8:      	ldr	x0, [x16]
    c5cc:      	add	x16, sp, #0x10
    c5d0:      	ldr	x1, [x16, #0x8]
    c5d4:      	add	x16, sp, #0x10
    c5d8:      	ldr	x2, [x16, #0x10]
    c5dc:      	b	0xc554 <_stogir.checked.validate-projection+0x178>
    c5e0:      	movz	x2, #0x0, lsl #48
    c5e4:      	b	0xc4a0 <_stogir.checked.validate-projection+0xc4>
    c5e8:      	brk	#0
    c5ec:      	b	0xc5e8 <_stogir.checked.validate-projection+0x20c>
    c5f0:      	mov	x19, x8
    c5f4:      	b	0xc544 <_stogir.checked.validate-projection+0x168>
    c5f8:      	mov	x19, x8
    c5fc:      	b	0xc544 <_stogir.checked.validate-projection+0x168>
    c600:      	mov	x19, x8
    c604:      	b	0xc544 <_stogir.checked.validate-projection+0x168>

000000000000c608 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge>:
    c608:      	ldr	x1, [x0]
    c60c:      	ldr	x0, [x0, #0x8]
    c610:      	str	x1, [x8]
    c614:      	str	x0, [x8, #0x8]
    c618:      	movz	x17, #0x0, lsl #48
    c61c:      	str	x17, [x8, #0x10]
    c620:      	ret

000000000000c624 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64>:
    c624:      	ldr	x1, [x0]
    c628:      	ldr	x0, [x0, #0x8]
    c62c:      	str	x1, [x8]
    c630:      	str	x0, [x8, #0x8]
    c634:      	movz	x17, #0x0, lsl #48
    c638:      	str	x17, [x8, #0x10]
    c63c:      	ret

000000000000c640 <_stogir.loops.heapify!>:
    c640:      	ldr	x4, [x1, #0x8]
    c644:      	asr	x16, x4, #63
    c648:      	lsr	x16, x16, #63
    c64c:      	add	x4, x4, x16
    c650:      	asr	x4, x4, #1
    c654:      	cmp	x4, #0x0
    c658:      	b.le	0xc7dc <_stogir.loops.heapify!+0x19c>
    c65c:      	sub	x4, x4, #0x1
    c660:      	ldr	x5, [x1]
    c664:      	ldr	x6, [x1, #0x8]
    c668:      	mov	x8, x4
    c66c:      	movz	x7, #0x0, lsl #48
    c670:      	b	0xc6b4 <_stogir.loops.heapify!+0x74>
    c674:      	nop
    c678:      	add	x8, x5, x8
    c67c:      	add	x10, x5, x9
    c680:      	ldr	x11, [x0]
    c684:      	orr	x12, x11, xzr
    c688:      	orr	x13, x11, xzr
    c68c:      	add	x12, x12, x8, lsl #3
    c690:      	add	x13, x13, x10, lsl #3
    c694:      	add	x8, x11, x8, lsl #3
    c698:      	ldr	x11, [x12]
    c69c:      	ldr	x12, [x13]
    c6a0:      	str	x12, [x8]
    c6a4:      	ldr	x8, [x0]
    c6a8:      	add	x8, x8, x10, lsl #3
    c6ac:      	str	x11, [x8]
    c6b0:      	mov	x8, x9
    c6b4:      	cmp	x7, #0x0
    c6b8:      	b.ne	0xc654 <_stogir.loops.heapify!+0x14>
    c6bc:      	lsl	x9, x8, #1
    c6c0:      	add	x9, x9, #0x1
    c6c4:      	cmp	x9, x6
    c6c8:      	b.ge	0xc654 <_stogir.loops.heapify!+0x14>
    c6cc:      	lsl	x9, x8, #1
    c6d0:      	add	x9, x9, #0x1
    c6d4:      	add	x10, x9, #0x1
    c6d8:      	cmp	x10, x6
    c6dc:      	b.ge	0xc75c <_stogir.loops.heapify!+0x11c>
    c6e0:      	add	x10, x9, x5
    c6e4:      	ldr	x11, [x0]
    c6e8:      	add	x12, x10, #0x1
    c6ec:      	orr	x13, x11, xzr
    c6f0:      	add	x10, x11, x10, lsl #3
    c6f4:      	add	x11, x13, x12, lsl #3
    c6f8:      	ldr	x11, [x11]
    c6fc:      	ldr	x10, [x10]
    c700:      	ldr	x12, [x2, #0x50]
    c704:      	orr	x13, x12, xzr
    c708:      	add	x13, x13, x11, lsl #4
    c70c:      	add	x12, x12, x10, lsl #4
    c710:      	ldr	x13, [x13]
    c714:      	ldr	x14, [x3]
    c718:      	asr	x13, x13, #32
    c71c:      	orr	x15, x14, xzr
    c720:      	add	x13, x15, x13, lsl #2
    c724:      	ldr	w13, [x13]
    c728:      	sxtw	x13, w13
    c72c:      	ldr	x12, [x12]
    c730:      	asr	x12, x12, #32
    c734:      	add	x12, x14, x12, lsl #2
    c738:      	ldr	w12, [x12]
    c73c:      	sxtw	x12, w12
    c740:      	cmp	x13, x12
    c744:      	b.lt	0xc758 <_stogir.loops.heapify!+0x118>
    c748:      	cmp	x13, x12
    c74c:      	b.ne	0xc75c <_stogir.loops.heapify!+0x11c>
    c750:      	cmp	x11, x10
    c754:      	b.le	0xc75c <_stogir.loops.heapify!+0x11c>
    c758:      	add	x9, x9, #0x1
    c75c:      	add	x10, x5, x8
    c760:      	ldr	x11, [x0]
    c764:      	add	x12, x5, x9
    c768:      	orr	x13, x11, xzr
    c76c:      	add	x10, x11, x10, lsl #3
    c770:      	add	x11, x13, x12, lsl #3
    c774:      	ldr	x11, [x11]
    c778:      	ldr	x10, [x10]
    c77c:      	ldr	x12, [x2, #0x50]
    c780:      	orr	x13, x12, xzr
    c784:      	add	x13, x13, x11, lsl #4
    c788:      	add	x12, x12, x10, lsl #4
    c78c:      	ldr	x13, [x13]
    c790:      	ldr	x14, [x3]
    c794:      	asr	x13, x13, #32
    c798:      	orr	x15, x14, xzr
    c79c:      	add	x13, x15, x13, lsl #2
    c7a0:      	ldr	w13, [x13]
    c7a4:      	sxtw	x13, w13
    c7a8:      	ldr	x12, [x12]
    c7ac:      	asr	x12, x12, #32
    c7b0:      	add	x12, x14, x12, lsl #2
    c7b4:      	ldr	w12, [x12]
    c7b8:      	sxtw	x12, w12
    c7bc:      	cmp	x13, x12
    c7c0:      	b.lt	0xc678 <_stogir.loops.heapify!+0x38>
    c7c4:      	cmp	x13, x12
    c7c8:      	b.ne	0xc7d4 <_stogir.loops.heapify!+0x194>
    c7cc:      	cmp	x11, x10
    c7d0:      	b.gt	0xc678 <_stogir.loops.heapify!+0x38>
    c7d4:      	mov	x7, #0x1                ; =1
    c7d8:      	b	0xc6b4 <_stogir.loops.heapify!+0x74>
    c7dc:      	ret

000000000000c7e0 <_stogir.loops.sift!>:
    c7e0:      	movz	x6, #0x0, lsl #48
    c7e4:      	b	0xc824 <_stogir.loops.sift!+0x44>
    c7e8:      	add	x3, x1, x3
    c7ec:      	add	x8, x1, x7
    c7f0:      	ldr	x9, [x0]
    c7f4:      	orr	x10, x9, xzr
    c7f8:      	orr	x11, x9, xzr
    c7fc:      	add	x10, x10, x3, lsl #3
    c800:      	add	x11, x11, x8, lsl #3
    c804:      	add	x3, x9, x3, lsl #3
    c808:      	ldr	x9, [x10]
    c80c:      	ldr	x10, [x11]
    c810:      	str	x10, [x3]
    c814:      	ldr	x3, [x0]
    c818:      	add	x3, x3, x8, lsl #3
    c81c:      	str	x9, [x3]
    c820:      	mov	x3, x7
    c824:      	cmp	x6, #0x0
    c828:      	b.ne	0xc94c <_stogir.loops.sift!+0x16c>
    c82c:      	lsl	x7, x3, #1
    c830:      	add	x7, x7, #0x1
    c834:      	cmp	x7, x2
    c838:      	b.ge	0xc94c <_stogir.loops.sift!+0x16c>
    c83c:      	lsl	x7, x3, #1
    c840:      	add	x7, x7, #0x1
    c844:      	add	x8, x7, #0x1
    c848:      	cmp	x8, x2
    c84c:      	b.ge	0xc8cc <_stogir.loops.sift!+0xec>
    c850:      	add	x8, x7, x1
    c854:      	ldr	x9, [x0]
    c858:      	add	x10, x8, #0x1
    c85c:      	orr	x11, x9, xzr
    c860:      	add	x8, x9, x8, lsl #3
    c864:      	add	x9, x11, x10, lsl #3
    c868:      	ldr	x9, [x9]
    c86c:      	ldr	x8, [x8]
    c870:      	ldr	x10, [x4, #0x50]
    c874:      	orr	x11, x10, xzr
    c878:      	add	x11, x11, x9, lsl #4
    c87c:      	add	x10, x10, x8, lsl #4
    c880:      	ldr	x11, [x11]
    c884:      	ldr	x12, [x5]
    c888:      	asr	x11, x11, #32
    c88c:      	orr	x13, x12, xzr
    c890:      	add	x11, x13, x11, lsl #2
    c894:      	ldr	w11, [x11]
    c898:      	sxtw	x11, w11
    c89c:      	ldr	x10, [x10]
    c8a0:      	asr	x10, x10, #32
    c8a4:      	add	x10, x12, x10, lsl #2
    c8a8:      	ldr	w10, [x10]
    c8ac:      	sxtw	x10, w10
    c8b0:      	cmp	x11, x10
    c8b4:      	b.lt	0xc8c8 <_stogir.loops.sift!+0xe8>
    c8b8:      	cmp	x11, x10
    c8bc:      	b.ne	0xc8cc <_stogir.loops.sift!+0xec>
    c8c0:      	cmp	x9, x8
    c8c4:      	b.le	0xc8cc <_stogir.loops.sift!+0xec>
    c8c8:      	add	x7, x7, #0x1
    c8cc:      	add	x8, x1, x3
    c8d0:      	ldr	x9, [x0]
    c8d4:      	add	x10, x1, x7
    c8d8:      	orr	x11, x9, xzr
    c8dc:      	add	x8, x9, x8, lsl #3
    c8e0:      	add	x9, x11, x10, lsl #3
    c8e4:      	ldr	x9, [x9]
    c8e8:      	ldr	x8, [x8]
    c8ec:      	ldr	x10, [x4, #0x50]
    c8f0:      	orr	x11, x10, xzr
    c8f4:      	add	x11, x11, x9, lsl #4
    c8f8:      	add	x10, x10, x8, lsl #4
    c8fc:      	ldr	x11, [x11]
    c900:      	ldr	x12, [x5]
    c904:      	asr	x11, x11, #32
    c908:      	orr	x13, x12, xzr
    c90c:      	add	x11, x13, x11, lsl #2
    c910:      	ldr	w11, [x11]
    c914:      	sxtw	x11, w11
    c918:      	ldr	x10, [x10]
    c91c:      	asr	x10, x10, #32
    c920:      	add	x10, x12, x10, lsl #2
    c924:      	ldr	w10, [x10]
    c928:      	sxtw	x10, w10
    c92c:      	cmp	x11, x10
    c930:      	b.lt	0xc7e8 <_stogir.loops.sift!+0x8>
    c934:      	cmp	x11, x10
    c938:      	b.ne	0xc944 <_stogir.loops.sift!+0x164>
    c93c:      	cmp	x9, x8
    c940:      	b.gt	0xc7e8 <_stogir.loops.sift!+0x8>
    c944:      	mov	x6, #0x1                ; =1
    c948:      	b	0xc824 <_stogir.loops.sift!+0x44>
    c94c:      	ret

000000000000c950 <_stogir.opcode.block-end?>:
    c950:      	sxtw	x0, w0
    c954:      	cmp	x0, #0x0
    c958:      	b.lt	0xc978 <_stogir.opcode.block-end?+0x28>
    c95c:      	cmp	x0, #0x83
    c960:      	b.ge	0xc978 <_stogir.opcode.block-end?+0x28>
    c964:      	adrp	x16, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000c964:  ARM64_RELOC_PAGE21	l_stogir.507
    c968:      	ldr	x16, [x16]
		000000000000c968:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    c96c:      	add	x0, x16, x0
    c970:      	ldrb	w0, [x0]
    c974:      	b	0xc97c <_stogir.opcode.block-end?+0x2c>
    c978:      	movz	w0, #0x0, lsl #16
    c97c:      	uxtb	w16, w0
    c980:      	and	w0, w16, #0x4
    c984:      	uxtb	w0, w0
    c988:      	ubfx	x0, x0, #0, #8
    c98c:      	cmp	x0, #0x0
    c990:      	cset	w0, eq
    c994:      	uxtb	w16, w0
    c998:      	cmp	w16, wzr
    c99c:      	cset	x0, eq
    c9a0:      	ret

000000000000c9a4 <_stogir.schedule.entry-prefix>:
    c9a4:      	sub	sp, sp, #0x90
    c9a8:      	str	x29, [sp]
    c9ac:      	str	x30, [sp, #0x8]
    c9b0:      	mov	x29, sp
    c9b4:      	str	x19, [sp, #0x40]
    c9b8:      	str	x20, [sp, #0x48]
    c9bc:      	str	x21, [sp, #0x50]
    c9c0:      	str	x22, [sp, #0x58]
    c9c4:      	str	x23, [sp, #0x60]
    c9c8:      	str	x24, [sp, #0x68]
    c9cc:      	str	x25, [sp, #0x70]
    c9d0:      	str	x26, [sp, #0x78]
    c9d4:      	str	x27, [sp, #0x80]
    c9d8:      	ldr	x3, [x2]
    c9dc:      	ldr	x2, [x2, #0x8]
    c9e0:      	add	x16, sp, #0x10
    c9e4:      	movz	x17, #0x0, lsl #48
    c9e8:      	str	x17, [x16]
    c9ec:      	add	x16, sp, #0x10
    c9f0:      	movz	x17, #0x0, lsl #48
    c9f4:      	str	x17, [x16, #0x8]
    c9f8:      	add	x16, sp, #0x10
    c9fc:      	movz	x17, #0x0, lsl #48
    ca00:      	str	x17, [x16, #0x10]
    ca04:      	add	x16, sp, #0x10
    ca08:      	str	x3, [x16, #0x18]
    ca0c:      	add	x16, sp, #0x10
    ca10:      	str	x2, [x16, #0x20]
    ca14:      	movz	x19, #0x0, lsl #48
    ca18:      	b	0xcb0c <_stogir.schedule.entry-prefix+0x168>
    ca1c:      	lsl	x2, x2, #1
    ca20:      	mov	x25, x8
    ca24:      	mov	x26, x0
    ca28:      	add	x0, sp, #0x10
    ca2c:      	mov	x27, x1
    ca30:      	mov	x1, x2
    ca34:      	bl	0xca34 <_stogir.schedule.entry-prefix+0x90>
		000000000000ca34:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ca38:      	add	x0, x24, #0x1
    ca3c:      	add	x16, sp, #0x10
    ca40:      	ldr	x1, [x16]
    ca44:      	add	x1, x1, x24, lsl #2
    ca48:      	str	w23, [x1]
    ca4c:      	add	x16, sp, #0x10
    ca50:      	str	x0, [x16, #0x8]
    ca54:      	mov	x8, x25
    ca58:      	mov	x0, x26
    ca5c:      	mov	x1, x27
    ca60:      	cmp	x22, x21
    ca64:      	b.ge	0xca88 <_stogir.schedule.entry-prefix+0xe4>
    ca68:      	add	x2, x22, #0x1
    ca6c:      	add	x3, x20, x22, lsl #2
    ca70:      	ldr	w3, [x3]
    ca74:      	movn	w17, #0x0, lsl #16
    ca78:      	and	w23, w3, w17
    ca7c:      	mov	x22, x2
    ca80:      	mov	w2, #0x1                ; =1
    ca84:      	b	0xca90 <_stogir.schedule.entry-prefix+0xec>
    ca88:      	movz	w2, #0x0, lsl #16
    ca8c:      	movz	w23, #0x0, lsl #16
    ca90:      	ubfx	x2, x2, #0, #32
    ca94:      	lsr	x16, x2, #0
    ca98:      	cmp	x16, #0x1
    ca9c:      	b.eq	0xcac4 <_stogir.schedule.entry-prefix+0x120>
    caa0:      	b.lo	0xcaa8 <_stogir.schedule.entry-prefix+0x104>
    caa4:      	b	0xcac8 <_stogir.schedule.entry-prefix+0x124>
    caa8:      	cmp	x16, #0x0
    caac:      	b.eq	0xcab4 <_stogir.schedule.entry-prefix+0x110>
    cab0:      	b	0xcac8 <_stogir.schedule.entry-prefix+0x124>
    cab4:      	mov	x25, x8
    cab8:      	mov	x26, x0
    cabc:      	mov	x27, x1
    cac0:      	b	0xcafc <_stogir.schedule.entry-prefix+0x158>
    cac4:      	b	0xcacc <_stogir.schedule.entry-prefix+0x128>
    cac8:      	b	0xcc24 <_stogir.schedule.entry-prefix+0x280>
    cacc:      	sxtw	x2, w23
    cad0:      	ldr	x3, [x0]
    cad4:      	add	x2, x3, x2, lsl #4
    cad8:      	ldr	x2, [x2]
    cadc:      	uxtb	w2, w2
    cae0:      	cmp	x2, #0x83
    cae4:      	b.ge	0xcb2c <_stogir.schedule.entry-prefix+0x188>
    cae8:      	adrp	x17, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000cae8:  ARM64_RELOC_PAGE21	l_stogir.508
    caec:      	ldr	x17, [x17]
		000000000000caec:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    caf0:      	add	x3, x2, x17
    caf4:      	ldrb	w3, [x3]
    caf8:      	b	0xcb30 <_stogir.schedule.entry-prefix+0x18c>
    cafc:      	add	x19, x19, #0x1
    cb00:      	mov	x8, x25
    cb04:      	mov	x0, x26
    cb08:      	mov	x1, x27
    cb0c:      	cmp	x19, #0x3
    cb10:      	b.ge	0xcc2c <_stogir.schedule.entry-prefix+0x288>
    cb14:      	ldr	x2, [x1]
    cb18:      	ldr	x3, [x1, #0x8]
    cb1c:      	orr	x20, x2, xzr
    cb20:      	orr	x21, x3, xzr
    cb24:      	movz	x22, #0x0, lsl #48
    cb28:      	b	0xca60 <_stogir.schedule.entry-prefix+0xbc>
    cb2c:      	movz	w3, #0x0, lsl #16
    cb30:      	uxtb	w16, w3
    cb34:      	and	w3, w16, #0x2
    cb38:      	uxtb	w3, w3
    cb3c:      	ubfx	x3, x3, #0, #8
    cb40:      	cmp	x3, #0x0
    cb44:      	cset	w3, eq
    cb48:      	uxtb	w16, w3
    cb4c:      	cmp	w16, wzr
    cb50:      	cset	x3, eq
    cb54:      	cmp	x3, #0x0
    cb58:      	b.eq	0xcb64 <_stogir.schedule.entry-prefix+0x1c0>
    cb5c:      	movz	x2, #0x0, lsl #48
    cb60:      	b	0xcb80 <_stogir.schedule.entry-prefix+0x1dc>
    cb64:      	cmp	x2, #0x47
    cb68:      	cset	w2, eq
    cb6c:      	uxtb	w16, w2
    cb70:      	cmp	w16, wzr
    cb74:      	mov	x16, #0x1               ; =1
    cb78:      	mov	x17, #0x2               ; =2
    cb7c:      	csel	x2, x16, x17, ne
    cb80:      	cmp	x2, x19
    cb84:      	b.ne	0xcc34 <_stogir.schedule.entry-prefix+0x290>
    cb88:      	add	x16, sp, #0x10
    cb8c:      	ldr	x2, [x16, #0x8]
    cb90:      	orr	x24, x2, xzr
    cb94:      	add	x16, sp, #0x10
    cb98:      	ldr	x2, [x16, #0x10]
    cb9c:      	cmp	x24, x2
    cba0:      	b.lt	0xcc44 <_stogir.schedule.entry-prefix+0x2a0>
    cba4:      	cmp	x2, #0x0
    cba8:      	b.ne	0xca1c <_stogir.schedule.entry-prefix+0x78>
    cbac:      	mov	x2, #0x2                ; =2
    cbb0:      	b	0xca20 <_stogir.schedule.entry-prefix+0x7c>
    cbb4:      	add	x16, sp, #0x10
    cbb8:      	ldr	x0, [x16]
    cbbc:      	add	x16, sp, #0x10
    cbc0:      	ldr	x1, [x16, #0x8]
    cbc4:      	add	x16, sp, #0x10
    cbc8:      	ldr	x2, [x16, #0x10]
    cbcc:      	add	x16, sp, #0x10
    cbd0:      	ldr	x3, [x16, #0x18]
    cbd4:      	add	x16, sp, #0x10
    cbd8:      	ldr	x4, [x16, #0x20]
    cbdc:      	str	x0, [x25]
    cbe0:      	str	x1, [x25, #0x8]
    cbe4:      	str	x2, [x25, #0x10]
    cbe8:      	str	x3, [x25, #0x18]
    cbec:      	str	x4, [x25, #0x20]
    cbf0:      	ldr	x19, [sp, #0x40]
    cbf4:      	ldr	x20, [sp, #0x48]
    cbf8:      	ldr	x21, [sp, #0x50]
    cbfc:      	ldr	x22, [sp, #0x58]
    cc00:      	ldr	x23, [sp, #0x60]
    cc04:      	ldr	x24, [sp, #0x68]
    cc08:      	ldr	x25, [sp, #0x70]
    cc0c:      	ldr	x26, [sp, #0x78]
    cc10:      	ldr	x27, [sp, #0x80]
    cc14:      	ldr	x29, [sp]
    cc18:      	ldr	x30, [sp, #0x8]
    cc1c:      	add	sp, sp, #0x90
    cc20:      	ret
    cc24:      	brk	#0
    cc28:      	b	0xcc24 <_stogir.schedule.entry-prefix+0x280>
    cc2c:      	mov	x25, x8
    cc30:      	b	0xcbb4 <_stogir.schedule.entry-prefix+0x210>
    cc34:      	mov	x25, x8
    cc38:      	mov	x26, x0
    cc3c:      	mov	x27, x1
    cc40:      	b	0xca54 <_stogir.schedule.entry-prefix+0xb0>
    cc44:      	mov	x25, x8
    cc48:      	mov	x26, x0
    cc4c:      	mov	x27, x1
    cc50:      	b	0xca38 <_stogir.schedule.entry-prefix+0x94>

000000000000cc54 <_stogir.checked-schedule.validate>:
    cc54:      	sub	sp, sp, #0x40
    cc58:      	str	x29, [sp]
    cc5c:      	str	x30, [sp, #0x8]
    cc60:      	mov	x29, sp
    cc64:      	str	x19, [sp, #0x30]
    cc68:      	add	x1, x1, #0x28
    cc6c:      	mov	x19, x8
    cc70:      	add	x8, sp, #0x10
    cc74:      	bl	0xcc74 <_stogir.checked-schedule.validate+0x20>
		000000000000cc74:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    cc78:      	add	x16, sp, #0x10
    cc7c:      	ldr	x0, [x16]
    cc80:      	str	x0, [x19]
    cc84:      	add	x16, sp, #0x10
    cc88:      	ldr	x0, [x16, #0x8]
    cc8c:      	str	x0, [x19, #0x8]
    cc90:      	add	x16, sp, #0x10
    cc94:      	ldr	x0, [x16, #0x10]
    cc98:      	str	x0, [x19, #0x10]
    cc9c:      	ldr	x19, [sp, #0x30]
    cca0:      	ldr	x29, [sp]
    cca4:      	ldr	x30, [sp, #0x8]
    cca8:      	add	sp, sp, #0x40
    ccac:      	ret

000000000000ccb0 <_stogir.checked.projection>:
    ccb0:      	sub	sp, sp, #0x40
    ccb4:      	str	x29, [sp]
    ccb8:      	str	x30, [sp, #0x8]
    ccbc:      	mov	x29, sp
    ccc0:      	str	x19, [sp, #0x30]
    ccc4:      	sxtw	x2, w1
    ccc8:      	add	x3, x0, #0x28
    cccc:      	cmp	x2, #0x0
    ccd0:      	cset	w4, gt
    ccd4:      	movz	x16, #0x0, lsl #48
    ccd8:      	sub	x5, x16, x2
    ccdc:      	sub	x6, x5, #0x1
    cce0:      	uxtb	w16, w4
    cce4:      	cmp	w16, wzr
    cce8:      	b.eq	0xcd28 <_stogir.checked.projection+0x78>
    ccec:      	ldr	x3, [x0, #0x8]
    ccf0:      	cmp	x2, x3
    ccf4:      	b.ge	0xcd74 <_stogir.checked.projection+0xc4>
    ccf8:      	add	x3, x0, #0x78
    ccfc:      	ldr	x3, [x3, #0x8]
    cd00:      	cmp	x2, x3
    cd04:      	b.ge	0xce74 <_stogir.checked.projection+0x1c4>
    cd08:      	ldr	x3, [x0, #0x78]
    cd0c:      	add	x3, x3, x2, lsl #2
    cd10:      	ldr	w3, [x3]
    cd14:      	sxtw	x3, w3
    cd18:      	cmp	x3, #0x0
    cd1c:      	cset	w3, ge
    cd20:      	ubfx	x3, x3, #0, #8
    cd24:      	b	0xce78 <_stogir.checked.projection+0x1c8>
    cd28:      	cmp	x2, #0x0
    cd2c:      	b.ge	0xcd7c <_stogir.checked.projection+0xcc>
    cd30:      	add	x7, x0, #0x50
    cd34:      	ldr	x3, [x3, #0x8]
    cd38:      	ldr	x7, [x7, #0x8]
    cd3c:      	cmp	x3, x7
    cd40:      	b.ne	0xcd6c <_stogir.checked.projection+0xbc>
    cd44:      	cmp	x5, x3
    cd48:      	b.gt	0xcea4 <_stogir.checked.projection+0x1f4>
    cd4c:      	ldr	x3, [x0, #0x50]
    cd50:      	add	x3, x3, x6, lsl #2
    cd54:      	ldr	w3, [x3]
    cd58:      	sxtw	x3, w3
    cd5c:      	cmp	x3, #0x0
    cd60:      	cset	w3, gt
    cd64:      	ubfx	x3, x3, #0, #8
    cd68:      	b	0xcea8 <_stogir.checked.projection+0x1f8>
    cd6c:      	movz	x3, #0x0, lsl #48
    cd70:      	b	0xcd80 <_stogir.checked.projection+0xd0>
    cd74:      	movz	x3, #0x0, lsl #48
    cd78:      	b	0xcd80 <_stogir.checked.projection+0xd0>
    cd7c:      	movz	x3, #0x0, lsl #48
    cd80:      	cmp	x3, #0x0
    cd84:      	b.eq	0xcdb8 <_stogir.checked.projection+0x108>
    cd88:      	uxtb	w16, w4
    cd8c:      	cmp	w16, wzr
    cd90:      	b.eq	0xcda4 <_stogir.checked.projection+0xf4>
    cd94:      	ldr	x3, [x0]
    cd98:      	add	x2, x3, x2, lsl #4
    cd9c:      	ldr	x2, [x2]
    cda0:      	b	0xcdb0 <_stogir.checked.projection+0x100>
    cda4:      	ldr	x2, [x0, #0x28]
    cda8:      	add	x2, x2, x6, lsl #4
    cdac:      	ldr	x2, [x2]
    cdb0:      	mov	w3, #0x1                ; =1
    cdb4:      	b	0xcdc0 <_stogir.checked.projection+0x110>
    cdb8:      	movz	w3, #0x0, lsl #16
    cdbc:      	movz	x2, #0x0, lsl #48
    cdc0:      	ubfx	x3, x3, #0, #32
    cdc4:      	lsr	x16, x3, #0
    cdc8:      	cmp	x16, #0x1
    cdcc:      	b.eq	0xcde8 <_stogir.checked.projection+0x138>
    cdd0:      	b.lo	0xcdd8 <_stogir.checked.projection+0x128>
    cdd4:      	b	0xcdec <_stogir.checked.projection+0x13c>
    cdd8:      	cmp	x16, #0x0
    cddc:      	b.eq	0xcde4 <_stogir.checked.projection+0x134>
    cde0:      	b	0xcdec <_stogir.checked.projection+0x13c>
    cde4:      	b	0xcdf0 <_stogir.checked.projection+0x140>
    cde8:      	b	0xce38 <_stogir.checked.projection+0x188>
    cdec:      	b	0xceac <_stogir.checked.projection+0x1fc>
    cdf0:      	mov	x19, x8
    cdf4:      	mov	x0, #0x1                ; =1
    cdf8:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000cdf8:  ARM64_RELOC_PAGE21	l_stogir.509
    cdfc:      	ldr	x1, [x1]
		000000000000cdfc:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    ce00:      	mov	x2, #0x17               ; =23
    ce04:      	b	0xce18 <_stogir.checked.projection+0x168>
    ce08:      	mov	x0, #0x1                ; =1
    ce0c:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000ce0c:  ARM64_RELOC_PAGE21	l_stogir.510
    ce10:      	ldr	x1, [x1]
		000000000000ce10:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    ce14:      	mov	x2, #0x20               ; =32
    ce18:      	str	x0, [x19]
    ce1c:      	str	x1, [x19, #0x8]
    ce20:      	str	x2, [x19, #0x10]
    ce24:      	ldr	x19, [sp, #0x30]
    ce28:      	ldr	x29, [sp]
    ce2c:      	ldr	x30, [sp, #0x8]
    ce30:      	add	sp, sp, #0x40
    ce34:      	ret
    ce38:      	uxtb	w3, w2
    ce3c:      	cmp	x3, #0x29
    ce40:      	b.lt	0xceb4 <_stogir.checked.projection+0x204>
    ce44:      	cmp	x3, #0x2b
    ce48:      	b.gt	0xcebc <_stogir.checked.projection+0x20c>
    ce4c:      	mov	x19, x8
    ce50:      	add	x8, sp, #0x10
    ce54:      	bl	0xce54 <_stogir.checked.projection+0x1a4>
		000000000000ce54:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    ce58:      	add	x16, sp, #0x10
    ce5c:      	ldr	x0, [x16]
    ce60:      	add	x16, sp, #0x10
    ce64:      	ldr	x1, [x16, #0x8]
    ce68:      	add	x16, sp, #0x10
    ce6c:      	ldr	x2, [x16, #0x10]
    ce70:      	b	0xce18 <_stogir.checked.projection+0x168>
    ce74:      	movz	x3, #0x0, lsl #48
    ce78:      	b	0xcd78 <_stogir.checked.projection+0xc8>
    ce7c:      	ubfx	x2, x2, #0, #32
    ce80:      	ubfx	x0, x2, #8, #8
    ce84:      	cmp	x0, #0x0
    ce88:      	b.eq	0xce08 <_stogir.checked.projection+0x158>
    ce8c:      	cmp	x0, #0xd
    ce90:      	b.gt	0xce08 <_stogir.checked.projection+0x158>
    ce94:      	movz	x0, #0x0, lsl #48
    ce98:      	movz	x1, #0x0, lsl #48
    ce9c:      	movz	x2, #0x0, lsl #48
    cea0:      	b	0xce18 <_stogir.checked.projection+0x168>
    cea4:      	movz	x3, #0x0, lsl #48
    cea8:      	b	0xcd70 <_stogir.checked.projection+0xc0>
    ceac:      	brk	#0
    ceb0:      	b	0xceac <_stogir.checked.projection+0x1fc>
    ceb4:      	mov	x19, x8
    ceb8:      	b	0xce7c <_stogir.checked.projection+0x1cc>
    cebc:      	mov	x19, x8
    cec0:      	b	0xce7c <_stogir.checked.projection+0x1cc>

000000000000cec4 <_stogir.checked-schedule.validate-nodes>:
    cec4:      	sub	sp, sp, #0xe0
    cec8:      	str	x29, [sp]
    cecc:      	str	x30, [sp, #0x8]
    ced0:      	mov	x29, sp
    ced4:      	str	x19, [sp, #0x88]
    ced8:      	str	x20, [sp, #0x90]
    cedc:      	str	x21, [sp, #0x98]
    cee0:      	str	x22, [sp, #0xa0]
    cee4:      	str	x23, [sp, #0xa8]
    cee8:      	str	x24, [sp, #0xb0]
    ceec:      	str	x25, [sp, #0xb8]
    cef0:      	str	x26, [sp, #0xc0]
    cef4:      	str	x27, [sp, #0xc8]
    cef8:      	str	x28, [sp, #0xd0]
    cefc:      	add	x19, x0, #0x28
    cf00:      	add	x20, x0, #0x78
    cf04:      	add	x21, x0, #0x50
    cf08:      	add	x16, sp, #0x20
    cf0c:      	orr	x2, x16, xzr
    cf10:      	add	x22, x2, #0x8
    cf14:      	add	x16, sp, #0x40
    cf18:      	orr	x2, x16, xzr
    cf1c:      	ldr	x3, [x1]
    cf20:      	add	x23, x2, #0x8
    cf24:      	ldr	x1, [x1, #0x8]
    cf28:      	orr	x24, x3, xzr
    cf2c:      	orr	x25, x1, xzr
    cf30:      	movz	x26, #0x0, lsl #48
    cf34:      	adrp	x27, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000cf34:  ARM64_RELOC_PAGE21	l_stogir.511
    cf38:      	ldr	x27, [x27]
		000000000000cf38:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    cf3c:      	movz	x28, #0x0, lsl #48
    cf40:      	movz	w1, #0x0, lsl #16
    cf44:      	movz	x2, #0x0, lsl #48
    cf48:      	b	0xcf70 <_stogir.checked-schedule.validate-nodes+0xac>
    cf4c:      	adrp	x27, 0xc000 <_stogir.placement.use-block+0x18c>
		000000000000cf4c:  ARM64_RELOC_PAGE21	l_stogir.512
    cf50:      	ldr	x27, [x27]
		000000000000cf50:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    cf54:      	mov	x28, #0x24              ; =36
    cf58:      	mov	x8, x19
    cf5c:      	ldr	x0, [sp, #0x68]
    cf60:      	ldr	x19, [sp, #0x60]
    cf64:      	mov	w1, w20
    cf68:      	ldr	x20, [sp, #0x70]
    cf6c:      	ldr	x2, [sp, #0x78]
    cf70:      	cmp	x2, x25
    cf74:      	b.ge	0xcf98 <_stogir.checked-schedule.validate-nodes+0xd4>
    cf78:      	add	x3, x2, #0x1
    cf7c:      	add	x2, x24, x2, lsl #2
    cf80:      	ldr	w2, [x2]
    cf84:      	movn	w17, #0x0, lsl #16
    cf88:      	and	w4, w2, w17
    cf8c:      	mov	x2, x3
    cf90:      	mov	w3, #0x1                ; =1
    cf94:      	b	0xcfa0 <_stogir.checked-schedule.validate-nodes+0xdc>
    cf98:      	movz	w3, #0x0, lsl #16
    cf9c:      	movz	w4, #0x0, lsl #16
    cfa0:      	ubfx	x3, x3, #0, #32
    cfa4:      	lsr	x16, x3, #0
    cfa8:      	cmp	x16, #0x1
    cfac:      	b.eq	0xcfcc <_stogir.checked-schedule.validate-nodes+0x108>
    cfb0:      	b.lo	0xcfb8 <_stogir.checked-schedule.validate-nodes+0xf4>
    cfb4:      	b	0xcfd0 <_stogir.checked-schedule.validate-nodes+0x10c>
    cfb8:      	cmp	x16, #0x0
    cfbc:      	b.eq	0xcfc4 <_stogir.checked-schedule.validate-nodes+0x100>
    cfc0:      	b	0xcfd0 <_stogir.checked-schedule.validate-nodes+0x10c>
    cfc4:      	mov	x19, x8
    cfc8:      	b	0xd038 <_stogir.checked-schedule.validate-nodes+0x174>
    cfcc:      	b	0xcfd4 <_stogir.checked-schedule.validate-nodes+0x110>
    cfd0:      	b	0xd2a0 <_stogir.checked-schedule.validate-nodes+0x3dc>
    cfd4:      	cmp	x28, #0x0
    cfd8:      	b.ne	0xd308 <_stogir.checked-schedule.validate-nodes+0x444>
    cfdc:      	sxtw	x3, w4
    cfe0:      	cmp	x3, #0x0
    cfe4:      	cset	w5, gt
    cfe8:      	movz	x16, #0x0, lsl #48
    cfec:      	sub	x6, x16, x3
    cff0:      	sub	x7, x6, #0x1
    cff4:      	uxtb	w16, w5
    cff8:      	cmp	w16, wzr
    cffc:      	b.eq	0xd098 <_stogir.checked-schedule.validate-nodes+0x1d4>
    d000:      	ldr	x6, [x0, #0x8]
    d004:      	cmp	x3, x6
    d008:      	b.ge	0xd0d8 <_stogir.checked-schedule.validate-nodes+0x214>
    d00c:      	ldr	x6, [x20, #0x8]
    d010:      	cmp	x3, x6
    d014:      	b.ge	0xd218 <_stogir.checked-schedule.validate-nodes+0x354>
    d018:      	ldr	x6, [x0, #0x78]
    d01c:      	add	x6, x6, x3, lsl #2
    d020:      	ldr	w6, [x6]
    d024:      	sxtw	x6, w6
    d028:      	cmp	x6, #0x0
    d02c:      	cset	w6, ge
    d030:      	ubfx	x6, x6, #0, #8
    d034:      	b	0xd21c <_stogir.checked-schedule.validate-nodes+0x358>
    d038:      	cmp	x28, #0x0
    d03c:      	b.ne	0xd050 <_stogir.checked-schedule.validate-nodes+0x18c>
    d040:      	and	x27, x26, #0xffffffff
    d044:      	movz	x0, #0x0, lsl #48
    d048:      	movz	x28, #0x0, lsl #48
    d04c:      	b	0xd054 <_stogir.checked-schedule.validate-nodes+0x190>
    d050:      	mov	x0, #0x1                ; =1
    d054:      	str	x0, [x19]
    d058:      	str	x27, [x19, #0x8]
    d05c:      	str	x28, [x19, #0x10]
    d060:      	ldr	x19, [sp, #0x88]
    d064:      	ldr	x20, [sp, #0x90]
    d068:      	ldr	x21, [sp, #0x98]
    d06c:      	ldr	x22, [sp, #0xa0]
    d070:      	ldr	x23, [sp, #0xa8]
    d074:      	ldr	x24, [sp, #0xb0]
    d078:      	ldr	x25, [sp, #0xb8]
    d07c:      	ldr	x26, [sp, #0xc0]
    d080:      	ldr	x27, [sp, #0xc8]
    d084:      	ldr	x28, [sp, #0xd0]
    d088:      	ldr	x29, [sp]
    d08c:      	ldr	x30, [sp, #0x8]
    d090:      	add	sp, sp, #0xe0
    d094:      	ret
    d098:      	cmp	x3, #0x0
    d09c:      	b.ge	0xd0e0 <_stogir.checked-schedule.validate-nodes+0x21c>
    d0a0:      	ldr	x9, [x19, #0x8]
    d0a4:      	ldr	x10, [x21, #0x8]
    d0a8:      	cmp	x9, x10
    d0ac:      	b.ne	0xd210 <_stogir.checked-schedule.validate-nodes+0x34c>
    d0b0:      	cmp	x6, x9
    d0b4:      	b.gt	0xd288 <_stogir.checked-schedule.validate-nodes+0x3c4>
    d0b8:      	ldr	x6, [x0, #0x50]
    d0bc:      	add	x6, x6, x7, lsl #2
    d0c0:      	ldr	w6, [x6]
    d0c4:      	sxtw	x6, w6
    d0c8:      	cmp	x6, #0x0
    d0cc:      	cset	w6, gt
    d0d0:      	ubfx	x6, x6, #0, #8
    d0d4:      	b	0xd28c <_stogir.checked-schedule.validate-nodes+0x3c8>
    d0d8:      	movz	x6, #0x0, lsl #48
    d0dc:      	b	0xd0e4 <_stogir.checked-schedule.validate-nodes+0x220>
    d0e0:      	movz	x6, #0x0, lsl #48
    d0e4:      	cmp	x6, #0x0
    d0e8:      	b.eq	0xd124 <_stogir.checked-schedule.validate-nodes+0x260>
    d0ec:      	uxtb	w16, w5
    d0f0:      	cmp	w16, wzr
    d0f4:      	b.eq	0xd10c <_stogir.checked-schedule.validate-nodes+0x248>
    d0f8:      	ldr	x5, [x0]
    d0fc:      	add	x3, x5, x3, lsl #4
    d100:      	ldr	x5, [x3]
    d104:      	ldr	x3, [x3, #0x8]
    d108:      	b	0xd11c <_stogir.checked-schedule.validate-nodes+0x258>
    d10c:      	ldr	x3, [x0, #0x28]
    d110:      	add	x3, x3, x7, lsl #4
    d114:      	ldr	x5, [x3]
    d118:      	ldr	x3, [x3, #0x8]
    d11c:      	mov	w6, #0x1                ; =1
    d120:      	b	0xd130 <_stogir.checked-schedule.validate-nodes+0x26c>
    d124:      	movz	w6, #0x0, lsl #16
    d128:      	movz	x5, #0x0, lsl #48
    d12c:      	movz	x3, #0x0, lsl #48
    d130:      	ubfx	x6, x6, #0, #32
    d134:      	lsr	x16, x6, #0
    d138:      	cmp	x16, #0x1
    d13c:      	b.eq	0xd170 <_stogir.checked-schedule.validate-nodes+0x2ac>
    d140:      	b.lo	0xd148 <_stogir.checked-schedule.validate-nodes+0x284>
    d144:      	b	0xd174 <_stogir.checked-schedule.validate-nodes+0x2b0>
    d148:      	cmp	x16, #0x0
    d14c:      	b.eq	0xd154 <_stogir.checked-schedule.validate-nodes+0x290>
    d150:      	b	0xd174 <_stogir.checked-schedule.validate-nodes+0x2b0>
    d154:      	str	x0, [sp, #0x68]
    d158:      	str	x19, [sp, #0x60]
    d15c:      	mov	x19, x8
    d160:      	str	x20, [sp, #0x70]
    d164:      	mov	w20, w1
    d168:      	str	x2, [sp, #0x78]
    d16c:      	b	0xcf4c <_stogir.checked-schedule.validate-nodes+0x88>
    d170:      	b	0xd178 <_stogir.checked-schedule.validate-nodes+0x2b4>
    d174:      	b	0xd2f0 <_stogir.checked-schedule.validate-nodes+0x42c>
    d178:      	uxtb	w6, w5
    d17c:      	add	x16, sp, #0x10
    d180:      	str	x5, [x16]
    d184:      	add	x16, sp, #0x10
    d188:      	str	x3, [x16, #0x8]
    d18c:      	cmp	x6, #0x29
    d190:      	b.lt	0xd324 <_stogir.checked-schedule.validate-nodes+0x460>
    d194:      	cmp	x6, #0x2b
    d198:      	b.gt	0xd344 <_stogir.checked-schedule.validate-nodes+0x480>
    d19c:      	str	x0, [sp, #0x68]
    d1a0:      	str	x2, [sp, #0x78]
    d1a4:      	str	w4, [sp, #0x80]
    d1a8:      	str	x19, [sp, #0x60]
    d1ac:      	mov	x19, x8
    d1b0:      	add	x8, sp, #0x20
    d1b4:      	str	x20, [sp, #0x70]
    d1b8:      	mov	w20, w1
    d1bc:      	mov	w1, w4
    d1c0:      	bl	0xd1c0 <_stogir.checked-schedule.validate-nodes+0x2fc>
		000000000000d1c0:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    d1c4:      	add	x16, sp, #0x20
    d1c8:      	ldr	w0, [x16]
    d1cc:      	lsr	x16, x0, #0
    d1d0:      	cmp	x16, #0x1
    d1d4:      	b.eq	0xd1f0 <_stogir.checked-schedule.validate-nodes+0x32c>
    d1d8:      	b.lo	0xd1e0 <_stogir.checked-schedule.validate-nodes+0x31c>
    d1dc:      	b	0xd1f4 <_stogir.checked-schedule.validate-nodes+0x330>
    d1e0:      	cmp	x16, #0x0
    d1e4:      	b.eq	0xd1ec <_stogir.checked-schedule.validate-nodes+0x328>
    d1e8:      	b	0xd1f4 <_stogir.checked-schedule.validate-nodes+0x330>
    d1ec:      	b	0xd2a8 <_stogir.checked-schedule.validate-nodes+0x3e4>
    d1f0:      	b	0xd1f8 <_stogir.checked-schedule.validate-nodes+0x334>
    d1f4:      	b	0xd300 <_stogir.checked-schedule.validate-nodes+0x43c>
    d1f8:      	add	x16, sp, #0x20
    d1fc:      	ldr	x27, [x16, #0x8]
    d200:      	ldr	x28, [x22, #0x8]
    d204:      	b	0xd2ac <_stogir.checked-schedule.validate-nodes+0x3e8>
    d208:      	movz	w20, #0x0, lsl #16
    d20c:      	b	0xcf58 <_stogir.checked-schedule.validate-nodes+0x94>
    d210:      	movz	x6, #0x0, lsl #48
    d214:      	b	0xd0e4 <_stogir.checked-schedule.validate-nodes+0x220>
    d218:      	movz	x6, #0x0, lsl #48
    d21c:      	b	0xd0dc <_stogir.checked-schedule.validate-nodes+0x218>
    d220:      	add	x16, sp, #0x10
    d224:      	ldr	w0, [x16]
    d228:      	uxtb	w0, w0
    d22c:      	cmp	x0, #0x2c
    d230:      	b.ne	0xd208 <_stogir.checked-schedule.validate-nodes+0x344>
    d234:      	add	x8, sp, #0x40
    d238:      	ldr	x0, [sp, #0x68]
    d23c:      	ldr	w1, [sp, #0x80]
    d240:      	bl	0xd240 <_stogir.checked-schedule.validate-nodes+0x37c>
		000000000000d240:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    d244:      	add	x16, sp, #0x40
    d248:      	ldr	w0, [x16]
    d24c:      	lsr	x16, x0, #0
    d250:      	cmp	x16, #0x1
    d254:      	b.eq	0xd270 <_stogir.checked-schedule.validate-nodes+0x3ac>
    d258:      	b.lo	0xd260 <_stogir.checked-schedule.validate-nodes+0x39c>
    d25c:      	b	0xd274 <_stogir.checked-schedule.validate-nodes+0x3b0>
    d260:      	cmp	x16, #0x0
    d264:      	b.eq	0xd26c <_stogir.checked-schedule.validate-nodes+0x3a8>
    d268:      	b	0xd274 <_stogir.checked-schedule.validate-nodes+0x3b0>
    d26c:      	b	0xd2b0 <_stogir.checked-schedule.validate-nodes+0x3ec>
    d270:      	b	0xd278 <_stogir.checked-schedule.validate-nodes+0x3b4>
    d274:      	b	0xd2f8 <_stogir.checked-schedule.validate-nodes+0x434>
    d278:      	add	x16, sp, #0x40
    d27c:      	ldr	x27, [x16, #0x8]
    d280:      	ldr	x28, [x23, #0x8]
    d284:      	b	0xd29c <_stogir.checked-schedule.validate-nodes+0x3d8>
    d288:      	movz	x6, #0x0, lsl #48
    d28c:      	b	0xd214 <_stogir.checked-schedule.validate-nodes+0x350>
    d290:      	adrp	x27, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000d290:  ARM64_RELOC_PAGE21	l_stogir.513
    d294:      	ldr	x27, [x27]
		000000000000d294:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    d298:      	mov	x28, #0x35              ; =53
    d29c:      	b	0xd20c <_stogir.checked-schedule.validate-nodes+0x348>
    d2a0:      	brk	#0
    d2a4:      	b	0xd2a0 <_stogir.checked-schedule.validate-nodes+0x3dc>
    d2a8:      	ldr	w20, [sp, #0x80]
    d2ac:      	b	0xd20c <_stogir.checked-schedule.validate-nodes+0x348>
    d2b0:      	add	x16, sp, #0x40
    d2b4:      	ldr	w0, [x16, #0x8]
    d2b8:      	sxtw	x0, w0
    d2bc:      	cmp	x0, #0x0
    d2c0:      	b.ne	0xd2cc <_stogir.checked-schedule.validate-nodes+0x408>
    d2c4:      	movz	w20, #0x0, lsl #16
    d2c8:      	b	0xd29c <_stogir.checked-schedule.validate-nodes+0x3d8>
    d2cc:      	sxtw	x0, w20
    d2d0:      	add	x16, sp, #0x10
    d2d4:      	ldr	w1, [x16, #0x4]
    d2d8:      	sxtw	x1, w1
    d2dc:      	cmp	x0, x1
    d2e0:      	b.ne	0xd290 <_stogir.checked-schedule.validate-nodes+0x3cc>
    d2e4:      	add	x0, x26, #0x1
    d2e8:      	sxtw	x26, w0
    d2ec:      	b	0xd29c <_stogir.checked-schedule.validate-nodes+0x3d8>
    d2f0:      	brk	#0
    d2f4:      	b	0xd2f0 <_stogir.checked-schedule.validate-nodes+0x42c>
    d2f8:      	brk	#0
    d2fc:      	b	0xd2f8 <_stogir.checked-schedule.validate-nodes+0x434>
    d300:      	brk	#0
    d304:      	b	0xd300 <_stogir.checked-schedule.validate-nodes+0x43c>
    d308:      	str	x0, [sp, #0x68]
    d30c:      	str	x19, [sp, #0x60]
    d310:      	mov	x19, x8
    d314:      	str	x20, [sp, #0x70]
    d318:      	mov	w20, w1
    d31c:      	str	x2, [sp, #0x78]
    d320:      	b	0xcf58 <_stogir.checked-schedule.validate-nodes+0x94>
    d324:      	str	x0, [sp, #0x68]
    d328:      	str	w4, [sp, #0x80]
    d32c:      	str	x19, [sp, #0x60]
    d330:      	mov	x19, x8
    d334:      	str	x20, [sp, #0x70]
    d338:      	mov	w20, w1
    d33c:      	str	x2, [sp, #0x78]
    d340:      	b	0xd220 <_stogir.checked-schedule.validate-nodes+0x35c>
    d344:      	str	x0, [sp, #0x68]
    d348:      	str	w4, [sp, #0x80]
    d34c:      	str	x19, [sp, #0x60]
    d350:      	mov	x19, x8
    d354:      	str	x20, [sp, #0x70]
    d358:      	mov	w20, w1
    d35c:      	str	x2, [sp, #0x78]
    d360:      	b	0xd220 <_stogir.checked-schedule.validate-nodes+0x35c>

000000000000d364 <_coil.alloc.sized-free>:
    d364:      	sub	sp, sp, #0x70
    d368:      	str	x29, [sp]
    d36c:      	str	x30, [sp, #0x8]
    d370:      	mov	x29, sp
    d374:      	str	x19, [sp, #0x60]
    d378:      	str	x20, [sp, #0x68]
    d37c:      	cmp	x2, #0x0
    d380:      	b.ne	0xd3a0 <_coil.alloc.sized-free+0x3c>
    d384:      	movz	x0, #0x0, lsl #48
    d388:      	ldr	x19, [sp, #0x60]
    d38c:      	ldr	x20, [sp, #0x68]
    d390:      	ldr	x29, [sp]
    d394:      	ldr	x30, [sp, #0x8]
    d398:      	add	sp, sp, #0x70
    d39c:      	ret
    d3a0:      	add	x8, sp, #0x10
    d3a4:      	mov	x19, x0
    d3a8:      	mov	x0, x3
    d3ac:      	mov	x3, x2
    d3b0:      	mov	x2, x5
    d3b4:      	mov	x20, x1
    d3b8:      	mov	x1, x4
    d3bc:      	bl	0xd3bc <_coil.alloc.sized-free+0x58>
		000000000000d3bc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    d3c0:      	add	x16, sp, #0x10
    d3c4:      	ldr	w0, [x16]
    d3c8:      	lsr	x16, x0, #0
    d3cc:      	cmp	x16, #0x1
    d3d0:      	b.eq	0xd3ec <_coil.alloc.sized-free+0x88>
    d3d4:      	b.lo	0xd3dc <_coil.alloc.sized-free+0x78>
    d3d8:      	b	0xd3f0 <_coil.alloc.sized-free+0x8c>
    d3dc:      	cmp	x16, #0x0
    d3e0:      	b.eq	0xd3e8 <_coil.alloc.sized-free+0x84>
    d3e4:      	b	0xd3f0 <_coil.alloc.sized-free+0x8c>
    d3e8:      	b	0xd3f4 <_coil.alloc.sized-free+0x90>
    d3ec:      	b	0xd3fc <_coil.alloc.sized-free+0x98>
    d3f0:      	b	0xd450 <_coil.alloc.sized-free+0xec>
    d3f4:      	movz	x0, #0x0, lsl #48
    d3f8:      	b	0xd44c <_coil.alloc.sized-free+0xe8>
    d3fc:      	add	x16, sp, #0x10
    d400:      	orr	x0, x16, xzr
    d404:      	add	x0, x0, #0x8
    d408:      	add	x16, sp, #0x10
    d40c:      	ldr	x1, [x16, #0x8]
    d410:      	add	x16, sp, #0x40
    d414:      	str	x1, [x16]
    d418:      	ldr	x1, [x0, #0x8]
    d41c:      	add	x16, sp, #0x40
    d420:      	str	x1, [x16, #0x8]
    d424:      	ldr	x1, [x0, #0x10]
    d428:      	add	x16, sp, #0x40
    d42c:      	str	x1, [x16, #0x10]
    d430:      	ldr	x0, [x0, #0x18]
    d434:      	add	x16, sp, #0x40
    d438:      	str	x0, [x16, #0x18]
    d43c:      	mov	x0, x19
    d440:      	mov	x1, x20
    d444:      	add	x2, sp, #0x40
    d448:      	bl	0xd448 <_coil.alloc.sized-free+0xe4>
		000000000000d448:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-free
    d44c:      	b	0xd388 <_coil.alloc.sized-free+0x24>
    d450:      	brk	#0
    d454:      	b	0xd450 <_coil.alloc.sized-free+0xec>

000000000000d458 <_stogir.types.valid?>:
    d458:      	sxtw	x1, w0
    d45c:      	cmp	x1, #0x0
    d460:      	b.lt	0xd474 <_stogir.types.valid?+0x1c>
    d464:      	cmp	x1, #0xd
    d468:      	b.gt	0xd474 <_stogir.types.valid?+0x1c>
    d46c:      	mov	x0, #0x1                ; =1
    d470:      	b	0xd4b0 <_stogir.types.valid?+0x58>
    d474:      	cmp	x1, #0xf
    d478:      	b.le	0xd4ac <_stogir.types.valid?+0x54>
    d47c:      	cmp	x1, #0x80
    d480:      	b.ge	0xd4a4 <_stogir.types.valid?+0x4c>
    d484:      	and	w0, w0, #0xf
    d488:      	ubfx	x0, x0, #0, #32
    d48c:      	cmp	x0, #0x1
    d490:      	b.lt	0xd4b4 <_stogir.types.valid?+0x5c>
    d494:      	cmp	x0, #0xd
    d498:      	cset	w0, le
    d49c:      	ubfx	x0, x0, #0, #8
    d4a0:      	b	0xd4b8 <_stogir.types.valid?+0x60>
    d4a4:      	movz	x0, #0x0, lsl #48
    d4a8:      	b	0xd4b0 <_stogir.types.valid?+0x58>
    d4ac:      	movz	x0, #0x0, lsl #48
    d4b0:      	ret
    d4b4:      	movz	x0, #0x0, lsl #48
    d4b8:      	b	0xd4a8 <_stogir.types.valid?+0x50>

000000000000d4bc <_stogir.opcode.input-count>:
    d4bc:      	sxtw	x0, w0
    d4c0:      	cmp	x0, #0x0
    d4c4:      	b.lt	0xd4e8 <_stogir.opcode.input-count+0x2c>
    d4c8:      	cmp	x0, #0x83
    d4cc:      	b.ge	0xd4e8 <_stogir.opcode.input-count+0x2c>
    d4d0:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000d4d0:  ARM64_RELOC_PAGE21	l_stogir.514
    d4d4:      	ldr	x16, [x16]
		000000000000d4d4:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    d4d8:      	add	x0, x16, x0
    d4dc:      	ldrsb	w0, [x0]
    d4e0:      	sxtb	x0, w0
    d4e4:      	b	0xd4ec <_stogir.opcode.input-count+0x30>
    d4e8:      	mov	x0, #-0x2               ; =-2
    d4ec:      	ret

000000000000d4f0 <_stogir.graph.borrow-node>:
    d4f0:      	sxtw	x1, w1
    d4f4:      	add	x2, x0, #0x28
    d4f8:      	cmp	x1, #0x0
    d4fc:      	cset	w3, gt
    d500:      	movz	x16, #0x0, lsl #48
    d504:      	sub	x4, x16, x1
    d508:      	sub	x5, x4, #0x1
    d50c:      	uxtb	w16, w3
    d510:      	cmp	w16, wzr
    d514:      	b.eq	0xd554 <_stogir.graph.borrow-node+0x64>
    d518:      	ldr	x2, [x0, #0x8]
    d51c:      	cmp	x1, x2
    d520:      	b.ge	0xd5a0 <_stogir.graph.borrow-node+0xb0>
    d524:      	add	x2, x0, #0x78
    d528:      	ldr	x2, [x2, #0x8]
    d52c:      	cmp	x1, x2
    d530:      	b.ge	0xd5e0 <_stogir.graph.borrow-node+0xf0>
    d534:      	ldr	x2, [x0, #0x78]
    d538:      	add	x2, x2, x1, lsl #2
    d53c:      	ldr	w2, [x2]
    d540:      	sxtw	x2, w2
    d544:      	cmp	x2, #0x0
    d548:      	cset	w2, ge
    d54c:      	ubfx	x2, x2, #0, #8
    d550:      	b	0xd5e4 <_stogir.graph.borrow-node+0xf4>
    d554:      	cmp	x1, #0x0
    d558:      	b.ge	0xd5a8 <_stogir.graph.borrow-node+0xb8>
    d55c:      	add	x6, x0, #0x50
    d560:      	ldr	x2, [x2, #0x8]
    d564:      	ldr	x6, [x6, #0x8]
    d568:      	cmp	x2, x6
    d56c:      	b.ne	0xd598 <_stogir.graph.borrow-node+0xa8>
    d570:      	cmp	x4, x2
    d574:      	b.gt	0xd5e8 <_stogir.graph.borrow-node+0xf8>
    d578:      	ldr	x2, [x0, #0x50]
    d57c:      	add	x2, x2, x5, lsl #2
    d580:      	ldr	w2, [x2]
    d584:      	sxtw	x2, w2
    d588:      	cmp	x2, #0x0
    d58c:      	cset	w2, gt
    d590:      	ubfx	x2, x2, #0, #8
    d594:      	b	0xd5ec <_stogir.graph.borrow-node+0xfc>
    d598:      	movz	x2, #0x0, lsl #48
    d59c:      	b	0xd5ac <_stogir.graph.borrow-node+0xbc>
    d5a0:      	movz	x2, #0x0, lsl #48
    d5a4:      	b	0xd5ac <_stogir.graph.borrow-node+0xbc>
    d5a8:      	movz	x2, #0x0, lsl #48
    d5ac:      	cmp	x2, #0x0
    d5b0:      	b.eq	0xd5d8 <_stogir.graph.borrow-node+0xe8>
    d5b4:      	uxtb	w16, w3
    d5b8:      	cmp	w16, wzr
    d5bc:      	b.eq	0xd5cc <_stogir.graph.borrow-node+0xdc>
    d5c0:      	ldr	x0, [x0]
    d5c4:      	add	x0, x0, x1, lsl #4
    d5c8:      	b	0xd5d4 <_stogir.graph.borrow-node+0xe4>
    d5cc:      	ldr	x0, [x0, #0x28]
    d5d0:      	add	x0, x0, x5, lsl #4
    d5d4:      	b	0xd5dc <_stogir.graph.borrow-node+0xec>
    d5d8:      	movz	x0, #0x0, lsl #48
    d5dc:      	ret
    d5e0:      	movz	x2, #0x0, lsl #48
    d5e4:      	b	0xd5a4 <_stogir.graph.borrow-node+0xb4>
    d5e8:      	movz	x2, #0x0, lsl #48
    d5ec:      	b	0xd59c <_stogir.graph.borrow-node+0xac>

000000000000d5f0 <_stogir.verify.phis-structured>:
    d5f0:      	sub	sp, sp, #0xd0
    d5f4:      	str	x29, [sp, #0x10]
    d5f8:      	str	x30, [sp, #0x18]
    d5fc:      	add	x29, sp, #0x10
    d600:      	str	x19, [sp, #0x78]
    d604:      	str	x20, [sp, #0x80]
    d608:      	str	x21, [sp, #0x88]
    d60c:      	str	x22, [sp, #0x90]
    d610:      	str	x23, [sp, #0x98]
    d614:      	str	x24, [sp, #0xa0]
    d618:      	str	x25, [sp, #0xa8]
    d61c:      	str	x26, [sp, #0xb0]
    d620:      	str	x27, [sp, #0xb8]
    d624:      	str	x28, [sp, #0xc0]
    d628:      	add	x19, x0, #0x78
    d62c:      	add	x20, x0, #0x28
    d630:      	add	x21, x0, #0x50
    d634:      	mov	x22, #0x1               ; =1
    d638:      	movz	x23, #0x0, lsl #48
    d63c:      	adrp	x24, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000d63c:  ARM64_RELOC_PAGE21	l_stogir.515
    d640:      	ldr	x24, [x24]
		000000000000d640:  ARM64_RELOC_PAGEOFF12	l_stogir.515
    d644:      	movz	x25, #0x0, lsl #48
    d648:      	b	0xd930 <_stogir.verify.phis-structured+0x340>
    d64c:      	movz	x6, #0x0, lsl #48
    d650:      	b	0xd660 <_stogir.verify.phis-structured+0x70>
    d654:      	movz	x6, #0x0, lsl #48
    d658:      	b	0xd668 <_stogir.verify.phis-structured+0x78>
    d65c:      	movz	x6, #0x0, lsl #48
    d660:      	b	0xd670 <_stogir.verify.phis-structured+0x80>
    d664:      	movz	x6, #0x0, lsl #48
    d668:      	b	0xd670 <_stogir.verify.phis-structured+0x80>
    d66c:      	movz	x6, #0x0, lsl #48
    d670:      	cmp	x6, #0x0
    d674:      	b.eq	0xd6a8 <_stogir.verify.phis-structured+0xb8>
    d678:      	uxtb	w16, w5
    d67c:      	cmp	w16, wzr
    d680:      	b.eq	0xd694 <_stogir.verify.phis-structured+0xa4>
    d684:      	ldr	x5, [x24]
    d688:      	add	x4, x5, x4, lsl #4
    d68c:      	ldr	x4, [x4]
    d690:      	b	0xd6a0 <_stogir.verify.phis-structured+0xb0>
    d694:      	ldr	x4, [x24, #0x28]
    d698:      	add	x4, x4, x7, lsl #4
    d69c:      	ldr	x4, [x4]
    d6a0:      	mov	w5, #0x1                ; =1
    d6a4:      	b	0xd6b0 <_stogir.verify.phis-structured+0xc0>
    d6a8:      	movz	w5, #0x0, lsl #16
    d6ac:      	movz	x4, #0x0, lsl #48
    d6b0:      	ubfx	x5, x5, #0, #32
    d6b4:      	lsr	x16, x5, #0
    d6b8:      	cmp	x16, #0x1
    d6bc:      	b.eq	0xd6d8 <_stogir.verify.phis-structured+0xe8>
    d6c0:      	b.lo	0xd6c8 <_stogir.verify.phis-structured+0xd8>
    d6c4:      	b	0xd6dc <_stogir.verify.phis-structured+0xec>
    d6c8:      	cmp	x16, #0x0
    d6cc:      	b.eq	0xd6d4 <_stogir.verify.phis-structured+0xe4>
    d6d0:      	b	0xd6dc <_stogir.verify.phis-structured+0xec>
    d6d4:      	b	0xd6e0 <_stogir.verify.phis-structured+0xf0>
    d6d8:      	b	0xd6f4 <_stogir.verify.phis-structured+0x104>
    d6dc:      	b	0xdb38 <_stogir.verify.phis-structured+0x548>
    d6e0:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000d6e0:  ARM64_RELOC_PAGE21	l_stogir.516
    d6e4:      	ldr	x16, [x16]
		000000000000d6e4:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    d6e8:      	str	x16, [sp, #0x68]
    d6ec:      	mov	x25, #0x11              ; =17
    d6f0:      	b	0xd714 <_stogir.verify.phis-structured+0x124>
    d6f4:      	ubfx	x4, x4, #0, #32
    d6f8:      	ubfx	x4, x4, #8, #8
    d6fc:      	cmp	x4, x0
    d700:      	b.eq	0xd714 <_stogir.verify.phis-structured+0x124>
    d704:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000d704:  ARM64_RELOC_PAGE21	l_stogir.517
    d708:      	ldr	x16, [x16]
		000000000000d708:  ARM64_RELOC_PAGEOFF12	l_stogir.517
    d70c:      	str	x16, [sp, #0x68]
    d710:      	mov	x25, #0x1a              ; =26
    d714:      	b	0xd76c <_stogir.verify.phis-structured+0x17c>
    d718:      	movz	w5, #0x0, lsl #16
    d71c:      	movz	w4, #0x0, lsl #16
    d720:      	b	0xd72c <_stogir.verify.phis-structured+0x13c>
    d724:      	movz	w5, #0x0, lsl #16
    d728:      	movz	w4, #0x0, lsl #16
    d72c:      	ubfx	x5, x5, #0, #32
    d730:      	lsr	x16, x5, #0
    d734:      	cmp	x16, #0x1
    d738:      	b.eq	0xd754 <_stogir.verify.phis-structured+0x164>
    d73c:      	b.lo	0xd744 <_stogir.verify.phis-structured+0x154>
    d740:      	b	0xd758 <_stogir.verify.phis-structured+0x168>
    d744:      	cmp	x16, #0x0
    d748:      	b.eq	0xd750 <_stogir.verify.phis-structured+0x160>
    d74c:      	b	0xd758 <_stogir.verify.phis-structured+0x168>
    d750:      	b	0xd75c <_stogir.verify.phis-structured+0x16c>
    d754:      	b	0xd7dc <_stogir.verify.phis-structured+0x1ec>
    d758:      	b	0xdb30 <_stogir.verify.phis-structured+0x540>
    d75c:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000d75c:  ARM64_RELOC_PAGE21	l_stogir.516
    d760:      	ldr	x16, [x16]
		000000000000d760:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    d764:      	str	x16, [sp, #0x68]
    d768:      	mov	x25, #0x11              ; =17
    d76c:      	add	x3, x3, #0x1
    d770:      	sxtw	x3, w3
    d774:      	cmp	x25, #0x0
    d778:      	b.ne	0xd78c <_stogir.verify.phis-structured+0x19c>
    d77c:      	cmp	x3, x27
    d780:      	cset	w4, le
    d784:      	ubfx	x4, x4, #0, #8
    d788:      	b	0xd790 <_stogir.verify.phis-structured+0x1a0>
    d78c:      	movz	x4, #0x0, lsl #48
    d790:      	cmp	x4, #0x0
    d794:      	b.eq	0xd8fc <_stogir.verify.phis-structured+0x30c>
    d798:      	uxtb	w16, w1
    d79c:      	cmp	w16, wzr
    d7a0:      	b.ne	0xd724 <_stogir.verify.phis-structured+0x134>
    d7a4:      	ldr	x4, [x24, #0x8]
    d7a8:      	cmp	x28, x4
    d7ac:      	b.ge	0xd840 <_stogir.verify.phis-structured+0x250>
    d7b0:      	ldr	x4, [x19, #0x8]
    d7b4:      	cmp	x28, x4
    d7b8:      	b.ge	0xd838 <_stogir.verify.phis-structured+0x248>
    d7bc:      	ldr	x4, [x24, #0x78]
    d7c0:      	add	x4, x2, x4
    d7c4:      	ldr	w4, [x4]
    d7c8:      	sxtw	x4, w4
    d7cc:      	cmp	x4, #0x0
    d7d0:      	cset	w4, ge
    d7d4:      	ubfx	x4, x4, #0, #8
    d7d8:      	b	0xd83c <_stogir.verify.phis-structured+0x24c>
    d7dc:      	sxtw	x4, w4
    d7e0:      	cmp	x4, #0x0
    d7e4:      	cset	w5, gt
    d7e8:      	movz	x16, #0x0, lsl #48
    d7ec:      	sub	x6, x16, x4
    d7f0:      	sub	x7, x6, #0x1
    d7f4:      	uxtb	w16, w5
    d7f8:      	cmp	w16, wzr
    d7fc:      	b.eq	0xd8bc <_stogir.verify.phis-structured+0x2cc>
    d800:      	ldr	x6, [x24, #0x8]
    d804:      	cmp	x4, x6
    d808:      	b.ge	0xd664 <_stogir.verify.phis-structured+0x74>
    d80c:      	ldr	x6, [x19, #0x8]
    d810:      	cmp	x4, x6
    d814:      	b.ge	0xd654 <_stogir.verify.phis-structured+0x64>
    d818:      	ldr	x6, [x24, #0x78]
    d81c:      	add	x6, x6, x4, lsl #2
    d820:      	ldr	w6, [x6]
    d824:      	sxtw	x6, w6
    d828:      	cmp	x6, #0x0
    d82c:      	cset	w6, ge
    d830:      	ubfx	x6, x6, #0, #8
    d834:      	b	0xd658 <_stogir.verify.phis-structured+0x68>
    d838:      	movz	x4, #0x0, lsl #48
    d83c:      	b	0xd844 <_stogir.verify.phis-structured+0x254>
    d840:      	movz	x4, #0x0, lsl #48
    d844:      	cmp	x4, #0x0
    d848:      	b.eq	0xd724 <_stogir.verify.phis-structured+0x134>
    d84c:      	orr	w4, w3, wzr
    d850:      	sxtw	x4, w4
    d854:      	cmp	x4, #0x1
    d858:      	b.lt	0xd718 <_stogir.verify.phis-structured+0x128>
    d85c:      	ldr	x5, [x24, #0x78]
    d860:      	add	x5, x2, x5
    d864:      	ldr	w5, [x5]
    d868:      	sxtw	x5, w5
    d86c:      	cmp	x4, x5
    d870:      	b.gt	0xd718 <_stogir.verify.phis-structured+0x128>
    d874:      	ldr	x5, [x24]
    d878:      	asr	x16, x4, #63
    d87c:      	lsr	x16, x16, #62
    d880:      	add	x6, x4, x16
    d884:      	asr	x6, x6, #2
    d888:      	asr	x16, x4, #63
    d88c:      	lsr	x16, x16, #62
    d890:      	add	x4, x4, x16
    d894:      	and	x4, x4, #0x3
    d898:      	sub	x4, x4, x16
    d89c:      	add	x6, x6, x28
    d8a0:      	add	x5, x5, x6, lsl #4
    d8a4:      	add	x4, x5, x4, lsl #2
    d8a8:      	ldr	w4, [x4]
    d8ac:      	movn	w17, #0x0, lsl #16
    d8b0:      	and	w4, w4, w17
    d8b4:      	mov	w5, #0x1                ; =1
    d8b8:      	b	0xd720 <_stogir.verify.phis-structured+0x130>
    d8bc:      	cmp	x4, #0x0
    d8c0:      	b.ge	0xd66c <_stogir.verify.phis-structured+0x7c>
    d8c4:      	ldr	x8, [x20, #0x8]
    d8c8:      	ldr	x9, [x21, #0x8]
    d8cc:      	cmp	x8, x9
    d8d0:      	b.ne	0xd65c <_stogir.verify.phis-structured+0x6c>
    d8d4:      	cmp	x6, x8
    d8d8:      	b.gt	0xd64c <_stogir.verify.phis-structured+0x5c>
    d8dc:      	ldr	x6, [x24, #0x50]
    d8e0:      	add	x6, x6, x7, lsl #2
    d8e4:      	ldr	w6, [x6]
    d8e8:      	sxtw	x6, w6
    d8ec:      	cmp	x6, #0x0
    d8f0:      	cset	w6, gt
    d8f4:      	ubfx	x6, x6, #0, #8
    d8f8:      	b	0xd650 <_stogir.verify.phis-structured+0x60>
    d8fc:      	add	x0, x23, #0x1
    d900:      	sxtw	x23, w0
    d904:      	add	x0, x27, #0x4
    d908:      	asr	x16, x0, #63
    d90c:      	lsr	x16, x16, #62
    d910:      	add	x0, x0, x16
    d914:      	asr	x0, x0, #2
    d918:      	ldr	x1, [sp, #0x70]
    d91c:      	add	x1, x0, x1
    d920:      	ldr	x8, [sp, #0x60]
    d924:      	mov	x0, x24
    d928:      	mov	x22, x1
    d92c:      	ldr	x24, [sp, #0x68]
    d930:      	cmp	x25, #0x0
    d934:      	b.ne	0xdb80 <_stogir.verify.phis-structured+0x590>
    d938:      	ldr	x1, [x0, #0x8]
    d93c:      	cmp	x22, x1
    d940:      	b.ge	0xdb8c <_stogir.verify.phis-structured+0x59c>
    d944:      	ldr	x1, [x0]
    d948:      	add	x1, x1, x22, lsl #4
    d94c:      	ldr	x26, [x1]
    d950:      	ldr	x1, [x0, #0x78]
    d954:      	uxtb	w2, w26
    d958:      	add	x1, x1, x22, lsl #2
    d95c:      	ldr	w1, [x1]
    d960:      	sxtw	x27, w1
    d964:      	cmp	x2, #0x43
    d968:      	b.ne	0xdb98 <_stogir.verify.phis-structured+0x5a8>
    d96c:      	orr	w28, w22, wzr
    d970:      	cmp	x27, #0x3
    d974:      	b.ge	0xd9cc <_stogir.verify.phis-structured+0x3dc>
    d978:      	str	x22, [sp, #0x70]
    d97c:      	str	x8, [sp, #0x60]
    d980:      	mov	x24, x0
    d984:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000d984:  ARM64_RELOC_PAGE21	l_stogir.518
    d988:      	ldr	x16, [x16]
		000000000000d988:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    d98c:      	str	x16, [sp, #0x68]
    d990:      	mov	x25, #0x2b              ; =43
    d994:      	ubfx	x26, x26, #0, #32
    d998:      	ubfx	x0, x26, #8, #8
    d99c:      	cmp	x0, #0x0
    d9a0:      	b.ne	0xd9b4 <_stogir.verify.phis-structured+0x3c4>
    d9a4:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000d9a4:  ARM64_RELOC_PAGE21	l_stogir.519
    d9a8:      	ldr	x16, [x16]
		000000000000d9a8:  ARM64_RELOC_PAGEOFF12	l_stogir.519
    d9ac:      	str	x16, [sp, #0x68]
    d9b0:      	mov	x25, #0x19              ; =25
    d9b4:      	sxtw	x28, w28
    d9b8:      	cmp	x28, #0x0
    d9bc:      	cset	w1, le
    d9c0:      	lsl	x2, x28, #2
    d9c4:      	mov	x3, #0x2                ; =2
    d9c8:      	b	0xd774 <_stogir.verify.phis-structured+0x184>
    d9cc:      	mov	w1, w28
    d9d0:      	str	x8, [sp, #0x60]
    d9d4:      	str	x24, [sp, #0x68]
    d9d8:      	mov	x24, x0
    d9dc:      	mov	x2, #0x1                ; =1
    d9e0:      	bl	0xd9e0 <_stogir.verify.phis-structured+0x3f0>
		000000000000d9e0:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    d9e4:      	ubfx	x0, x0, #0, #32
    d9e8:      	lsr	x16, x0, #0
    d9ec:      	cmp	x16, #0x1
    d9f0:      	b.eq	0xda0c <_stogir.verify.phis-structured+0x41c>
    d9f4:      	b.lo	0xd9fc <_stogir.verify.phis-structured+0x40c>
    d9f8:      	b	0xda10 <_stogir.verify.phis-structured+0x420>
    d9fc:      	cmp	x16, #0x0
    da00:      	b.eq	0xda08 <_stogir.verify.phis-structured+0x418>
    da04:      	b	0xda10 <_stogir.verify.phis-structured+0x420>
    da08:      	b	0xda14 <_stogir.verify.phis-structured+0x424>
    da0c:      	b	0xda90 <_stogir.verify.phis-structured+0x4a0>
    da10:      	b	0xdb70 <_stogir.verify.phis-structured+0x580>
    da14:      	str	x22, [sp, #0x70]
    da18:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000da18:  ARM64_RELOC_PAGE21	l_stogir.520
    da1c:      	ldr	x16, [x16]
		000000000000da1c:  ARM64_RELOC_PAGEOFF12	l_stogir.520
    da20:      	str	x16, [sp, #0x68]
    da24:      	mov	x25, #0x10              ; =16
    da28:      	b	0xd994 <_stogir.verify.phis-structured+0x3a4>
    da2c:      	cmp	x25, #0x0
    da30:      	b.ne	0xdbac <_stogir.verify.phis-structured+0x5bc>
    da34:      	and	x0, x23, #0xffffffff
    da38:      	movz	x1, #0x0, lsl #48
    da3c:      	movz	x25, #0x0, lsl #48
    da40:      	b	0xda48 <_stogir.verify.phis-structured+0x458>
    da44:      	mov	x1, #0x1                ; =1
    da48:      	ldr	x2, [sp, #0x60]
    da4c:      	str	x1, [x2]
    da50:      	str	x0, [x2, #0x8]
    da54:      	str	x25, [x2, #0x10]
    da58:      	ldr	x19, [sp, #0x78]
    da5c:      	ldr	x20, [sp, #0x80]
    da60:      	ldr	x21, [sp, #0x88]
    da64:      	ldr	x22, [sp, #0x90]
    da68:      	ldr	x23, [sp, #0x98]
    da6c:      	ldr	x24, [sp, #0xa0]
    da70:      	ldr	x25, [sp, #0xa8]
    da74:      	ldr	x26, [sp, #0xb0]
    da78:      	ldr	x27, [sp, #0xb8]
    da7c:      	ldr	x28, [sp, #0xc0]
    da80:      	ldr	x29, [sp, #0x10]
    da84:      	ldr	x30, [sp, #0x18]
    da88:      	add	sp, sp, #0xd0
    da8c:      	ret
    da90:      	orr	w0, w1, wzr
    da94:      	add	x8, sp, #0x20
    da98:      	mov	w1, w0
    da9c:      	str	x22, [sp, #0x70]
    daa0:      	mov	w22, w0
    daa4:      	mov	x0, x24
    daa8:      	bl	0xdaa8 <_stogir.verify.phis-structured+0x4b8>
		000000000000daa8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    daac:      	add	x16, sp, #0x20
    dab0:      	ldr	w0, [x16]
    dab4:      	lsr	x16, x0, #0
    dab8:      	cmp	x16, #0x1
    dabc:      	b.eq	0xdad8 <_stogir.verify.phis-structured+0x4e8>
    dac0:      	b.lo	0xdac8 <_stogir.verify.phis-structured+0x4d8>
    dac4:      	b	0xdadc <_stogir.verify.phis-structured+0x4ec>
    dac8:      	cmp	x16, #0x0
    dacc:      	b.eq	0xdad4 <_stogir.verify.phis-structured+0x4e4>
    dad0:      	b	0xdadc <_stogir.verify.phis-structured+0x4ec>
    dad4:      	b	0xdae0 <_stogir.verify.phis-structured+0x4f0>
    dad8:      	b	0xdaf4 <_stogir.verify.phis-structured+0x504>
    dadc:      	b	0xdb78 <_stogir.verify.phis-structured+0x588>
    dae0:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000dae0:  ARM64_RELOC_PAGE21	l_stogir.521
    dae4:      	ldr	x16, [x16]
		000000000000dae4:  ARM64_RELOC_PAGEOFF12	l_stogir.521
    dae8:      	str	x16, [sp, #0x68]
    daec:      	mov	x25, #0x12              ; =18
    daf0:      	b	0xdb2c <_stogir.verify.phis-structured+0x53c>
    daf4:      	sxtw	x22, w22
    daf8:      	add	x16, sp, #0x20
    dafc:      	ldr	x0, [x16, #0x8]
    db00:      	cmp	x22, #0x0
    db04:      	b.le	0xdb1c <_stogir.verify.phis-structured+0x52c>
    db08:      	uxtb	w0, w0
    db0c:      	cmp	x0, #0x70
    db10:      	b.eq	0xdb40 <_stogir.verify.phis-structured+0x550>
    db14:      	cmp	x0, #0x71
    db18:      	b.eq	0xdb40 <_stogir.verify.phis-structured+0x550>
    db1c:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000db1c:  ARM64_RELOC_PAGE21	l_stogir.522
    db20:      	ldr	x16, [x16]
		000000000000db20:  ARM64_RELOC_PAGEOFF12	l_stogir.522
    db24:      	str	x16, [sp, #0x68]
    db28:      	mov	x25, #0x26              ; =38
    db2c:      	b	0xda28 <_stogir.verify.phis-structured+0x438>
    db30:      	brk	#0
    db34:      	b	0xdb30 <_stogir.verify.phis-structured+0x540>
    db38:      	brk	#0
    db3c:      	b	0xdb38 <_stogir.verify.phis-structured+0x548>
    db40:      	ldr	x0, [x24, #0x78]
    db44:      	add	x0, x0, x22, lsl #2
    db48:      	ldr	w0, [x0]
    db4c:      	add	w0, w0, #0x1
    db50:      	sxtw	x0, w0
    db54:      	cmp	x27, x0
    db58:      	b.eq	0xdb6c <_stogir.verify.phis-structured+0x57c>
    db5c:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000db5c:  ARM64_RELOC_PAGE21	l_stogir.523
    db60:      	ldr	x16, [x16]
		000000000000db60:  ARM64_RELOC_PAGEOFF12	l_stogir.523
    db64:      	str	x16, [sp, #0x68]
    db68:      	mov	x25, #0x2b              ; =43
    db6c:      	b	0xdb2c <_stogir.verify.phis-structured+0x53c>
    db70:      	brk	#0
    db74:      	b	0xdb70 <_stogir.verify.phis-structured+0x580>
    db78:      	brk	#0
    db7c:      	b	0xdb78 <_stogir.verify.phis-structured+0x588>
    db80:      	str	x8, [sp, #0x60]
    db84:      	str	x24, [sp, #0x68]
    db88:      	b	0xda2c <_stogir.verify.phis-structured+0x43c>
    db8c:      	str	x8, [sp, #0x60]
    db90:      	str	x24, [sp, #0x68]
    db94:      	b	0xda2c <_stogir.verify.phis-structured+0x43c>
    db98:      	str	x22, [sp, #0x70]
    db9c:      	str	x8, [sp, #0x60]
    dba0:      	str	x24, [sp, #0x68]
    dba4:      	mov	x24, x0
    dba8:      	b	0xd904 <_stogir.verify.phis-structured+0x314>
    dbac:      	ldr	x0, [sp, #0x68]
    dbb0:      	b	0xda44 <_stogir.verify.phis-structured+0x454>

000000000000dbb4 <_inherent$coil.arraylist.ArrayList$reserve!__i32>:
    dbb4:      	sub	sp, sp, #0x50
    dbb8:      	str	x29, [sp]
    dbbc:      	str	x30, [sp, #0x8]
    dbc0:      	mov	x29, sp
    dbc4:      	str	x19, [sp, #0x40]
    dbc8:      	str	x20, [sp, #0x48]
    dbcc:      	add	x2, x0, #0x18
    dbd0:      	ldr	x3, [x0, #0x10]
    dbd4:      	ldr	x4, [x0, #0x18]
    dbd8:      	ldr	x2, [x2, #0x8]
    dbdc:      	add	x16, sp, #0x10
    dbe0:      	str	x4, [x16]
    dbe4:      	add	x16, sp, #0x10
    dbe8:      	str	x2, [x16, #0x8]
    dbec:      	cmp	x1, x3
    dbf0:      	b.le	0xdc60 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xac>
    dbf4:      	ldr	x2, [x0]
    dbf8:      	add	x8, sp, #0x20
    dbfc:      	mov	x19, x0
    dc00:      	add	x0, sp, #0x10
    dc04:      	mov	x20, x1
    dc08:      	fmov	d31, x1
    dc0c:      	mov	x1, x2
    dc10:      	mov	x2, x3
    dc14:      	fmov	x3, d31
    dc18:      	bl	0xdc18 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x64>
		000000000000dc18:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i32
    dc1c:      	add	x16, sp, #0x20
    dc20:      	ldr	w0, [x16]
    dc24:      	lsr	x16, x0, #0
    dc28:      	cmp	x16, #0x1
    dc2c:      	b.eq	0xdc48 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x94>
    dc30:      	b.lo	0xdc38 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x84>
    dc34:      	b	0xdc4c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x98>
    dc38:      	cmp	x16, #0x0
    dc3c:      	b.eq	0xdc44 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x90>
    dc40:      	b	0xdc4c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x98>
    dc44:      	b	0xdc7c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xc8>
    dc48:      	b	0xdc50 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x9c>
    dc4c:      	b	0xdc94 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe0>
    dc50:      	add	x16, sp, #0x20
    dc54:      	ldr	x0, [x16, #0x8]
    dc58:      	str	x0, [x19]
    dc5c:      	str	x20, [x19, #0x10]
    dc60:      	movz	x0, #0x0, lsl #48
    dc64:      	ldr	x19, [sp, #0x40]
    dc68:      	ldr	x20, [sp, #0x48]
    dc6c:      	ldr	x29, [sp]
    dc70:      	ldr	x30, [sp, #0x8]
    dc74:      	add	sp, sp, #0x50
    dc78:      	ret
    dc7c:      	lsl	x0, x20, #2
    dc80:      	mov	x1, x0
    dc84:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000dc84:  ARM64_RELOC_PAGE21	l_stogir.524
    dc88:      	ldr	x0, [x0]
		000000000000dc88:  ARM64_RELOC_PAGEOFF12	l_stogir.524
    dc8c:      	bl	0xdc8c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xd8>
		000000000000dc8c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    dc90:      	b	0xdc90 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xdc>
    dc94:      	brk	#0
    dc98:      	b	0xdc94 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe0>

000000000000dc9c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge>:
    dc9c:      	sub	sp, sp, #0x50
    dca0:      	str	x29, [sp]
    dca4:      	str	x30, [sp, #0x8]
    dca8:      	mov	x29, sp
    dcac:      	str	x19, [sp, #0x40]
    dcb0:      	str	x20, [sp, #0x48]
    dcb4:      	add	x2, x0, #0x18
    dcb8:      	ldr	x3, [x0, #0x10]
    dcbc:      	ldr	x4, [x0, #0x18]
    dcc0:      	ldr	x2, [x2, #0x8]
    dcc4:      	add	x16, sp, #0x10
    dcc8:      	str	x4, [x16]
    dccc:      	add	x16, sp, #0x10
    dcd0:      	str	x2, [x16, #0x8]
    dcd4:      	cmp	x1, x3
    dcd8:      	b.le	0xdd48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xac>
    dcdc:      	ldr	x2, [x0]
    dce0:      	add	x8, sp, #0x20
    dce4:      	mov	x19, x0
    dce8:      	add	x0, sp, #0x10
    dcec:      	mov	x20, x1
    dcf0:      	fmov	d31, x1
    dcf4:      	mov	x1, x2
    dcf8:      	mov	x2, x3
    dcfc:      	fmov	x3, d31
    dd00:      	bl	0xdd00 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x64>
		000000000000dd00:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.cfg.Edge
    dd04:      	add	x16, sp, #0x20
    dd08:      	ldr	w0, [x16]
    dd0c:      	lsr	x16, x0, #0
    dd10:      	cmp	x16, #0x1
    dd14:      	b.eq	0xdd30 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x94>
    dd18:      	b.lo	0xdd20 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x84>
    dd1c:      	b	0xdd34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x98>
    dd20:      	cmp	x16, #0x0
    dd24:      	b.eq	0xdd2c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x90>
    dd28:      	b	0xdd34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x98>
    dd2c:      	b	0xdd64 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xc8>
    dd30:      	b	0xdd38 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x9c>
    dd34:      	b	0xdd7c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe0>
    dd38:      	add	x16, sp, #0x20
    dd3c:      	ldr	x0, [x16, #0x8]
    dd40:      	str	x0, [x19]
    dd44:      	str	x20, [x19, #0x10]
    dd48:      	movz	x0, #0x0, lsl #48
    dd4c:      	ldr	x19, [sp, #0x40]
    dd50:      	ldr	x20, [sp, #0x48]
    dd54:      	ldr	x29, [sp]
    dd58:      	ldr	x30, [sp, #0x8]
    dd5c:      	add	sp, sp, #0x50
    dd60:      	ret
    dd64:      	lsl	x0, x20, #4
    dd68:      	mov	x1, x0
    dd6c:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000dd6c:  ARM64_RELOC_PAGE21	l_stogir.525
    dd70:      	ldr	x0, [x0]
		000000000000dd70:  ARM64_RELOC_PAGEOFF12	l_stogir.525
    dd74:      	bl	0xdd74 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xd8>
		000000000000dd74:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    dd78:      	b	0xdd78 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xdc>
    dd7c:      	brk	#0
    dd80:      	b	0xdd7c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe0>

000000000000dd84 <_inherent$coil.arraylist.ArrayList$reserve!__bool>:
    dd84:      	sub	sp, sp, #0x50
    dd88:      	str	x29, [sp]
    dd8c:      	str	x30, [sp, #0x8]
    dd90:      	mov	x29, sp
    dd94:      	str	x19, [sp, #0x40]
    dd98:      	str	x20, [sp, #0x48]
    dd9c:      	add	x2, x0, #0x18
    dda0:      	ldr	x3, [x0, #0x10]
    dda4:      	ldr	x4, [x0, #0x18]
    dda8:      	ldr	x2, [x2, #0x8]
    ddac:      	add	x16, sp, #0x10
    ddb0:      	str	x4, [x16]
    ddb4:      	add	x16, sp, #0x10
    ddb8:      	str	x2, [x16, #0x8]
    ddbc:      	cmp	x1, x3
    ddc0:      	b.le	0xde30 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xac>
    ddc4:      	ldr	x2, [x0]
    ddc8:      	add	x8, sp, #0x20
    ddcc:      	mov	x19, x0
    ddd0:      	add	x0, sp, #0x10
    ddd4:      	mov	x20, x1
    ddd8:      	fmov	d31, x1
    dddc:      	mov	x1, x2
    dde0:      	mov	x2, x3
    dde4:      	fmov	x3, d31
    dde8:      	bl	0xdde8 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x64>
		000000000000dde8:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__bool
    ddec:      	add	x16, sp, #0x20
    ddf0:      	ldr	w0, [x16]
    ddf4:      	lsr	x16, x0, #0
    ddf8:      	cmp	x16, #0x1
    ddfc:      	b.eq	0xde18 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x94>
    de00:      	b.lo	0xde08 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x84>
    de04:      	b	0xde1c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x98>
    de08:      	cmp	x16, #0x0
    de0c:      	b.eq	0xde14 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x90>
    de10:      	b	0xde1c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x98>
    de14:      	b	0xde4c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xc8>
    de18:      	b	0xde20 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x9c>
    de1c:      	b	0xde64 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe0>
    de20:      	add	x16, sp, #0x20
    de24:      	ldr	x0, [x16, #0x8]
    de28:      	str	x0, [x19]
    de2c:      	str	x20, [x19, #0x10]
    de30:      	movz	x0, #0x0, lsl #48
    de34:      	ldr	x19, [sp, #0x40]
    de38:      	ldr	x20, [sp, #0x48]
    de3c:      	ldr	x29, [sp]
    de40:      	ldr	x30, [sp, #0x8]
    de44:      	add	sp, sp, #0x50
    de48:      	ret
    de4c:      	lsr	x0, x20, #0
    de50:      	mov	x1, x0
    de54:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000de54:  ARM64_RELOC_PAGE21	l_stogir.526
    de58:      	ldr	x0, [x0]
		000000000000de58:  ARM64_RELOC_PAGEOFF12	l_stogir.526
    de5c:      	bl	0xde5c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xd8>
		000000000000de5c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    de60:      	b	0xde60 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xdc>
    de64:      	brk	#0
    de68:      	b	0xde64 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe0>

000000000000de6c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame>:
    de6c:      	sub	sp, sp, #0x50
    de70:      	str	x29, [sp]
    de74:      	str	x30, [sp, #0x8]
    de78:      	mov	x29, sp
    de7c:      	str	x19, [sp, #0x40]
    de80:      	str	x20, [sp, #0x48]
    de84:      	add	x2, x0, #0x18
    de88:      	ldr	x3, [x0, #0x10]
    de8c:      	ldr	x4, [x0, #0x18]
    de90:      	ldr	x2, [x2, #0x8]
    de94:      	add	x16, sp, #0x10
    de98:      	str	x4, [x16]
    de9c:      	add	x16, sp, #0x10
    dea0:      	str	x2, [x16, #0x8]
    dea4:      	cmp	x1, x3
    dea8:      	b.le	0xdf18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xac>
    deac:      	ldr	x2, [x0]
    deb0:      	add	x8, sp, #0x20
    deb4:      	mov	x19, x0
    deb8:      	add	x0, sp, #0x10
    debc:      	mov	x20, x1
    dec0:      	fmov	d31, x1
    dec4:      	mov	x1, x2
    dec8:      	mov	x2, x3
    decc:      	fmov	x3, d31
    ded0:      	bl	0xded0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x64>
		000000000000ded0:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Frame
    ded4:      	add	x16, sp, #0x20
    ded8:      	ldr	w0, [x16]
    dedc:      	lsr	x16, x0, #0
    dee0:      	cmp	x16, #0x1
    dee4:      	b.eq	0xdf00 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x94>
    dee8:      	b.lo	0xdef0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x84>
    deec:      	b	0xdf04 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x98>
    def0:      	cmp	x16, #0x0
    def4:      	b.eq	0xdefc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x90>
    def8:      	b	0xdf04 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x98>
    defc:      	b	0xdf34 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xc8>
    df00:      	b	0xdf08 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x9c>
    df04:      	b	0xdf4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe0>
    df08:      	add	x16, sp, #0x20
    df0c:      	ldr	x0, [x16, #0x8]
    df10:      	str	x0, [x19]
    df14:      	str	x20, [x19, #0x10]
    df18:      	movz	x0, #0x0, lsl #48
    df1c:      	ldr	x19, [sp, #0x40]
    df20:      	ldr	x20, [sp, #0x48]
    df24:      	ldr	x29, [sp]
    df28:      	ldr	x30, [sp, #0x8]
    df2c:      	add	sp, sp, #0x50
    df30:      	ret
    df34:      	lsl	x0, x20, #4
    df38:      	mov	x1, x0
    df3c:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x13c>
		000000000000df3c:  ARM64_RELOC_PAGE21	l_stogir.527
    df40:      	ldr	x0, [x0]
		000000000000df40:  ARM64_RELOC_PAGEOFF12	l_stogir.527
    df44:      	bl	0xdf44 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xd8>
		000000000000df44:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    df48:      	b	0xdf48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xdc>
    df4c:      	brk	#0
    df50:      	b	0xdf4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe0>

000000000000df54 <_inherent$coil.arraylist.ArrayList$reserve!__i64>:
    df54:      	sub	sp, sp, #0x50
    df58:      	str	x29, [sp]
    df5c:      	str	x30, [sp, #0x8]
    df60:      	mov	x29, sp
    df64:      	str	x19, [sp, #0x40]
    df68:      	str	x20, [sp, #0x48]
    df6c:      	add	x2, x0, #0x18
    df70:      	ldr	x3, [x0, #0x10]
    df74:      	ldr	x4, [x0, #0x18]
    df78:      	ldr	x2, [x2, #0x8]
    df7c:      	add	x16, sp, #0x10
    df80:      	str	x4, [x16]
    df84:      	add	x16, sp, #0x10
    df88:      	str	x2, [x16, #0x8]
    df8c:      	cmp	x1, x3
    df90:      	b.le	0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
    df94:      	ldr	x2, [x0]
    df98:      	add	x8, sp, #0x20
    df9c:      	mov	x19, x0
    dfa0:      	add	x0, sp, #0x10
    dfa4:      	mov	x20, x1
    dfa8:      	fmov	d31, x1
    dfac:      	mov	x1, x2
    dfb0:      	mov	x2, x3
    dfb4:      	fmov	x3, d31
    dfb8:      	bl	0xdfb8 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x64>
		000000000000dfb8:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i64
    dfbc:      	add	x16, sp, #0x20
    dfc0:      	ldr	w0, [x16]
    dfc4:      	lsr	x16, x0, #0
    dfc8:      	cmp	x16, #0x1
    dfcc:      	b.eq	0xdfe8 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
    dfd0:      	b.lo	0xdfd8 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x84>
    dfd4:      	b	0xdfec <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x98>
    dfd8:      	cmp	x16, #0x0
    dfdc:      	b.eq	0xdfe4 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x90>
    dfe0:      	b	0xdfec <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x98>
    dfe4:      	b	0xe01c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc8>
    dfe8:      	b	0xdff0 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x9c>
    dfec:      	b	0xe034 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe0>
    dff0:      	add	x16, sp, #0x20
    dff4:      	ldr	x0, [x16, #0x8]
    dff8:      	str	x0, [x19]
    dffc:      	str	x20, [x19, #0x10]
    e000:      	movz	x0, #0x0, lsl #48
    e004:      	ldr	x19, [sp, #0x40]
    e008:      	ldr	x20, [sp, #0x48]
    e00c:      	ldr	x29, [sp]
    e010:      	ldr	x30, [sp, #0x8]
    e014:      	add	sp, sp, #0x50
    e018:      	ret
    e01c:      	lsl	x0, x20, #3
    e020:      	mov	x1, x0
    e024:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e024:  ARM64_RELOC_PAGE21	l_stogir.528
    e028:      	ldr	x0, [x0]
		000000000000e028:  ARM64_RELOC_PAGEOFF12	l_stogir.528
    e02c:      	bl	0xe02c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xd8>
		000000000000e02c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e030:      	b	0xe030 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xdc>
    e034:      	brk	#0
    e038:      	b	0xe034 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe0>

000000000000e03c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range>:
    e03c:      	sub	sp, sp, #0x50
    e040:      	str	x29, [sp]
    e044:      	str	x30, [sp, #0x8]
    e048:      	mov	x29, sp
    e04c:      	str	x19, [sp, #0x40]
    e050:      	str	x20, [sp, #0x48]
    e054:      	add	x2, x0, #0x18
    e058:      	ldr	x3, [x0, #0x10]
    e05c:      	ldr	x4, [x0, #0x18]
    e060:      	ldr	x2, [x2, #0x8]
    e064:      	add	x16, sp, #0x10
    e068:      	str	x4, [x16]
    e06c:      	add	x16, sp, #0x10
    e070:      	str	x2, [x16, #0x8]
    e074:      	cmp	x1, x3
    e078:      	b.le	0xe0e8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xac>
    e07c:      	ldr	x2, [x0]
    e080:      	add	x8, sp, #0x20
    e084:      	mov	x19, x0
    e088:      	add	x0, sp, #0x10
    e08c:      	mov	x20, x1
    e090:      	fmov	d31, x1
    e094:      	mov	x1, x2
    e098:      	mov	x2, x3
    e09c:      	fmov	x3, d31
    e0a0:      	bl	0xe0a0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x64>
		000000000000e0a0:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Range
    e0a4:      	add	x16, sp, #0x20
    e0a8:      	ldr	w0, [x16]
    e0ac:      	lsr	x16, x0, #0
    e0b0:      	cmp	x16, #0x1
    e0b4:      	b.eq	0xe0d0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x94>
    e0b8:      	b.lo	0xe0c0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x84>
    e0bc:      	b	0xe0d4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x98>
    e0c0:      	cmp	x16, #0x0
    e0c4:      	b.eq	0xe0cc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x90>
    e0c8:      	b	0xe0d4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x98>
    e0cc:      	b	0xe104 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xc8>
    e0d0:      	b	0xe0d8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x9c>
    e0d4:      	b	0xe11c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe0>
    e0d8:      	add	x16, sp, #0x20
    e0dc:      	ldr	x0, [x16, #0x8]
    e0e0:      	str	x0, [x19]
    e0e4:      	str	x20, [x19, #0x10]
    e0e8:      	movz	x0, #0x0, lsl #48
    e0ec:      	ldr	x19, [sp, #0x40]
    e0f0:      	ldr	x20, [sp, #0x48]
    e0f4:      	ldr	x29, [sp]
    e0f8:      	ldr	x30, [sp, #0x8]
    e0fc:      	add	sp, sp, #0x50
    e100:      	ret
    e104:      	lsl	x0, x20, #4
    e108:      	mov	x1, x0
    e10c:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e10c:  ARM64_RELOC_PAGE21	l_stogir.529
    e110:      	ldr	x0, [x0]
		000000000000e110:  ARM64_RELOC_PAGEOFF12	l_stogir.529
    e114:      	bl	0xe114 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xd8>
		000000000000e114:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e118:      	b	0xe118 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xdc>
    e11c:      	brk	#0
    e120:      	b	0xe11c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe0>

000000000000e124 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use>:
    e124:      	sub	sp, sp, #0x50
    e128:      	str	x29, [sp]
    e12c:      	str	x30, [sp, #0x8]
    e130:      	mov	x29, sp
    e134:      	str	x19, [sp, #0x40]
    e138:      	str	x20, [sp, #0x48]
    e13c:      	add	x2, x0, #0x18
    e140:      	ldr	x3, [x0, #0x10]
    e144:      	ldr	x4, [x0, #0x18]
    e148:      	ldr	x2, [x2, #0x8]
    e14c:      	add	x16, sp, #0x10
    e150:      	str	x4, [x16]
    e154:      	add	x16, sp, #0x10
    e158:      	str	x2, [x16, #0x8]
    e15c:      	cmp	x1, x3
    e160:      	b.le	0xe1d0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xac>
    e164:      	ldr	x2, [x0]
    e168:      	add	x8, sp, #0x20
    e16c:      	mov	x19, x0
    e170:      	add	x0, sp, #0x10
    e174:      	mov	x20, x1
    e178:      	fmov	d31, x1
    e17c:      	mov	x1, x2
    e180:      	mov	x2, x3
    e184:      	fmov	x3, d31
    e188:      	bl	0xe188 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x64>
		000000000000e188:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Use
    e18c:      	add	x16, sp, #0x20
    e190:      	ldr	w0, [x16]
    e194:      	lsr	x16, x0, #0
    e198:      	cmp	x16, #0x1
    e19c:      	b.eq	0xe1b8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x94>
    e1a0:      	b.lo	0xe1a8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x84>
    e1a4:      	b	0xe1bc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x98>
    e1a8:      	cmp	x16, #0x0
    e1ac:      	b.eq	0xe1b4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x90>
    e1b0:      	b	0xe1bc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x98>
    e1b4:      	b	0xe1ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xc8>
    e1b8:      	b	0xe1c0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x9c>
    e1bc:      	b	0xe204 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe0>
    e1c0:      	add	x16, sp, #0x20
    e1c4:      	ldr	x0, [x16, #0x8]
    e1c8:      	str	x0, [x19]
    e1cc:      	str	x20, [x19, #0x10]
    e1d0:      	movz	x0, #0x0, lsl #48
    e1d4:      	ldr	x19, [sp, #0x40]
    e1d8:      	ldr	x20, [sp, #0x48]
    e1dc:      	ldr	x29, [sp]
    e1e0:      	ldr	x30, [sp, #0x8]
    e1e4:      	add	sp, sp, #0x50
    e1e8:      	ret
    e1ec:      	lsl	x0, x20, #3
    e1f0:      	mov	x1, x0
    e1f4:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e1f4:  ARM64_RELOC_PAGE21	l_stogir.530
    e1f8:      	ldr	x0, [x0]
		000000000000e1f8:  ARM64_RELOC_PAGEOFF12	l_stogir.530
    e1fc:      	bl	0xe1fc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xd8>
		000000000000e1fc:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e200:      	b	0xe200 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xdc>
    e204:      	brk	#0
    e208:      	b	0xe204 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe0>

000000000000e20c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range>:
    e20c:      	sub	sp, sp, #0x50
    e210:      	str	x29, [sp]
    e214:      	str	x30, [sp, #0x8]
    e218:      	mov	x29, sp
    e21c:      	str	x19, [sp, #0x40]
    e220:      	str	x20, [sp, #0x48]
    e224:      	add	x2, x0, #0x18
    e228:      	ldr	x3, [x0, #0x10]
    e22c:      	ldr	x4, [x0, #0x18]
    e230:      	ldr	x2, [x2, #0x8]
    e234:      	add	x16, sp, #0x10
    e238:      	str	x4, [x16]
    e23c:      	add	x16, sp, #0x10
    e240:      	str	x2, [x16, #0x8]
    e244:      	cmp	x1, x3
    e248:      	b.le	0xe2b8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xac>
    e24c:      	ldr	x2, [x0]
    e250:      	add	x8, sp, #0x20
    e254:      	mov	x19, x0
    e258:      	add	x0, sp, #0x10
    e25c:      	mov	x20, x1
    e260:      	fmov	d31, x1
    e264:      	mov	x1, x2
    e268:      	mov	x2, x3
    e26c:      	fmov	x3, d31
    e270:      	bl	0xe270 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x64>
		000000000000e270:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.schedule.Range
    e274:      	add	x16, sp, #0x20
    e278:      	ldr	w0, [x16]
    e27c:      	lsr	x16, x0, #0
    e280:      	cmp	x16, #0x1
    e284:      	b.eq	0xe2a0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x94>
    e288:      	b.lo	0xe290 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x84>
    e28c:      	b	0xe2a4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x98>
    e290:      	cmp	x16, #0x0
    e294:      	b.eq	0xe29c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x90>
    e298:      	b	0xe2a4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x98>
    e29c:      	b	0xe2d4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xc8>
    e2a0:      	b	0xe2a8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x9c>
    e2a4:      	b	0xe2ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe0>
    e2a8:      	add	x16, sp, #0x20
    e2ac:      	ldr	x0, [x16, #0x8]
    e2b0:      	str	x0, [x19]
    e2b4:      	str	x20, [x19, #0x10]
    e2b8:      	movz	x0, #0x0, lsl #48
    e2bc:      	ldr	x19, [sp, #0x40]
    e2c0:      	ldr	x20, [sp, #0x48]
    e2c4:      	ldr	x29, [sp]
    e2c8:      	ldr	x30, [sp, #0x8]
    e2cc:      	add	sp, sp, #0x50
    e2d0:      	ret
    e2d4:      	lsl	x0, x20, #4
    e2d8:      	mov	x1, x0
    e2dc:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e2dc:  ARM64_RELOC_PAGE21	l_stogir.531
    e2e0:      	ldr	x0, [x0]
		000000000000e2e0:  ARM64_RELOC_PAGEOFF12	l_stogir.531
    e2e4:      	bl	0xe2e4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xd8>
		000000000000e2e4:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e2e8:      	b	0xe2e8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xdc>
    e2ec:      	brk	#0
    e2f0:      	b	0xe2ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe0>

000000000000e2f4 <_stogir.checked.validate>:
    e2f4:      	sub	sp, sp, #0x20
    e2f8:      	str	x29, [sp]
    e2fc:      	str	x30, [sp, #0x8]
    e300:      	mov	x29, sp
    e304:      	str	x19, [sp, #0x10]
    e308:      	sxtw	x1, w1
    e30c:      	add	x2, x0, #0x78
    e310:      	add	x3, x0, #0x28
    e314:      	add	x4, x0, #0x50
    e318:      	lsl	x5, x1, #2
    e31c:      	cmp	x1, #0x0
    e320:      	cset	w6, gt
    e324:      	movz	x16, #0x0, lsl #48
    e328:      	sub	x7, x16, x1
    e32c:      	sub	x9, x7, #0x1
    e330:      	uxtb	w16, w6
    e334:      	cmp	w16, wzr
    e338:      	b.eq	0xe374 <_stogir.checked.validate+0x80>
    e33c:      	ldr	x7, [x0, #0x8]
    e340:      	cmp	x1, x7
    e344:      	b.ge	0xe3bc <_stogir.checked.validate+0xc8>
    e348:      	ldr	x7, [x2, #0x8]
    e34c:      	cmp	x1, x7
    e350:      	b.ge	0xe508 <_stogir.checked.validate+0x214>
    e354:      	ldr	x7, [x0, #0x78]
    e358:      	add	x7, x5, x7
    e35c:      	ldr	w7, [x7]
    e360:      	sxtw	x7, w7
    e364:      	cmp	x7, #0x0
    e368:      	cset	w7, ge
    e36c:      	ubfx	x7, x7, #0, #8
    e370:      	b	0xe50c <_stogir.checked.validate+0x218>
    e374:      	cmp	x1, #0x0
    e378:      	b.ge	0xe3c4 <_stogir.checked.validate+0xd0>
    e37c:      	ldr	x10, [x3, #0x8]
    e380:      	ldr	x11, [x4, #0x8]
    e384:      	cmp	x10, x11
    e388:      	b.ne	0xe3b4 <_stogir.checked.validate+0xc0>
    e38c:      	cmp	x7, x10
    e390:      	b.gt	0xe510 <_stogir.checked.validate+0x21c>
    e394:      	ldr	x7, [x0, #0x50]
    e398:      	add	x7, x7, x9, lsl #2
    e39c:      	ldr	w7, [x7]
    e3a0:      	sxtw	x7, w7
    e3a4:      	cmp	x7, #0x0
    e3a8:      	cset	w7, gt
    e3ac:      	ubfx	x7, x7, #0, #8
    e3b0:      	b	0xe514 <_stogir.checked.validate+0x220>
    e3b4:      	movz	x7, #0x0, lsl #48
    e3b8:      	b	0xe3c8 <_stogir.checked.validate+0xd4>
    e3bc:      	movz	x7, #0x0, lsl #48
    e3c0:      	b	0xe3c8 <_stogir.checked.validate+0xd4>
    e3c4:      	movz	x7, #0x0, lsl #48
    e3c8:      	cmp	x7, #0x0
    e3cc:      	b.eq	0xe408 <_stogir.checked.validate+0x114>
    e3d0:      	uxtb	w16, w6
    e3d4:      	cmp	w16, wzr
    e3d8:      	b.eq	0xe3f0 <_stogir.checked.validate+0xfc>
    e3dc:      	ldr	x6, [x0]
    e3e0:      	add	x6, x6, x1, lsl #4
    e3e4:      	ldr	x7, [x6]
    e3e8:      	ldr	x6, [x6, #0x8]
    e3ec:      	b	0xe400 <_stogir.checked.validate+0x10c>
    e3f0:      	ldr	x6, [x0, #0x28]
    e3f4:      	add	x6, x6, x9, lsl #4
    e3f8:      	ldr	x7, [x6]
    e3fc:      	ldr	x6, [x6, #0x8]
    e400:      	mov	w9, #0x1                ; =1
    e404:      	b	0xe414 <_stogir.checked.validate+0x120>
    e408:      	movz	w9, #0x0, lsl #16
    e40c:      	movz	x7, #0x0, lsl #48
    e410:      	movz	x6, #0x0, lsl #48
    e414:      	ubfx	x9, x9, #0, #32
    e418:      	lsr	x16, x9, #0
    e41c:      	cmp	x16, #0x1
    e420:      	b.eq	0xe43c <_stogir.checked.validate+0x148>
    e424:      	b.lo	0xe42c <_stogir.checked.validate+0x138>
    e428:      	b	0xe440 <_stogir.checked.validate+0x14c>
    e42c:      	cmp	x16, #0x0
    e430:      	b.eq	0xe438 <_stogir.checked.validate+0x144>
    e434:      	b	0xe440 <_stogir.checked.validate+0x14c>
    e438:      	b	0xe444 <_stogir.checked.validate+0x150>
    e43c:      	b	0xe48c <_stogir.checked.validate+0x198>
    e440:      	b	0xe71c <_stogir.checked.validate+0x428>
    e444:      	mov	x0, #0x1                ; =1
    e448:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e448:  ARM64_RELOC_PAGE21	l_stogir.532
    e44c:      	ldr	x11, [x11]
		000000000000e44c:  ARM64_RELOC_PAGEOFF12	l_stogir.532
    e450:      	mov	x12, #0x1a              ; =26
    e454:      	b	0xe468 <_stogir.checked.validate+0x174>
    e458:      	mov	x0, #0x1                ; =1
    e45c:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e45c:  ARM64_RELOC_PAGE21	l_stogir.533
    e460:      	ldr	x11, [x11]
		000000000000e460:  ARM64_RELOC_PAGEOFF12	l_stogir.533
    e464:      	mov	x12, #0x26              ; =38
    e468:      	str	x0, [x8]
    e46c:      	str	x11, [x8, #0x8]
    e470:      	str	x12, [x8, #0x10]
    e474:      	sub	sp, x29, #0x0
    e478:      	ldr	x19, [sp, #0x10]
    e47c:      	ldr	x29, [sp]
    e480:      	ldr	x30, [sp, #0x8]
    e484:      	add	sp, sp, #0x20
    e488:      	ret
    e48c:      	cmp	x1, #0x0
    e490:      	b.le	0xe458 <_stogir.checked.validate+0x164>
    e494:      	uxtb	w1, w7
    e498:      	cmp	x1, #0x29
    e49c:      	b.lt	0xe458 <_stogir.checked.validate+0x164>
    e4a0:      	cmp	x1, #0x2b
    e4a4:      	b.gt	0xe458 <_stogir.checked.validate+0x164>
    e4a8:      	ldr	x1, [x0, #0x78]
    e4ac:      	add	x1, x5, x1
    e4b0:      	ldr	w1, [x1]
    e4b4:      	sxtw	x1, w1
    e4b8:      	cmp	x1, #0x2
    e4bc:      	b.ne	0xe458 <_stogir.checked.validate+0x164>
    e4c0:      	orr	w1, w7, wzr
    e4c4:      	mov	x5, sp
    e4c8:      	ubfx	x1, x1, #0, #32
    e4cc:      	sub	sp, sp, #0x10
    e4d0:      	mov	x9, sp
    e4d4:      	sub	sp, sp, #0x10
    e4d8:      	mov	x10, sp
    e4dc:      	ubfx	x1, x1, #8, #8
    e4e0:      	cmp	x1, #0x1
    e4e4:      	b.lt	0xe6e0 <_stogir.checked.validate+0x3ec>
    e4e8:      	cmp	x1, #0xb
    e4ec:      	b.gt	0xe6e0 <_stogir.checked.validate+0x3ec>
    e4f0:      	cmp	x1, #0x1
    e4f4:      	b.eq	0xe6e0 <_stogir.checked.validate+0x3ec>
    e4f8:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e4f8:  ARM64_RELOC_PAGE21	l_stogir.534
    e4fc:      	ldr	x11, [x11]
		000000000000e4fc:  ARM64_RELOC_PAGEOFF12	l_stogir.534
    e500:      	movz	x12, #0x0, lsl #48
    e504:      	b	0xe6ec <_stogir.checked.validate+0x3f8>
    e508:      	movz	x7, #0x0, lsl #48
    e50c:      	b	0xe3c0 <_stogir.checked.validate+0xcc>
    e510:      	movz	x7, #0x0, lsl #48
    e514:      	b	0xe3b8 <_stogir.checked.validate+0xc4>
    e518:      	mov	x0, #0x1                ; =1
    e51c:      	mov	sp, x5
    e520:      	b	0xe468 <_stogir.checked.validate+0x174>
    e524:      	movz	w9, #0x0, lsl #16
    e528:      	movz	x7, #0x0, lsl #48
    e52c:      	ubfx	x9, x9, #0, #32
    e530:      	lsr	x16, x9, #0
    e534:      	cmp	x16, #0x1
    e538:      	b.eq	0xe554 <_stogir.checked.validate+0x260>
    e53c:      	b.lo	0xe544 <_stogir.checked.validate+0x250>
    e540:      	b	0xe558 <_stogir.checked.validate+0x264>
    e544:      	cmp	x16, #0x0
    e548:      	b.eq	0xe550 <_stogir.checked.validate+0x25c>
    e54c:      	b	0xe558 <_stogir.checked.validate+0x264>
    e550:      	b	0xe55c <_stogir.checked.validate+0x268>
    e554:      	b	0xe6c0 <_stogir.checked.validate+0x3cc>
    e558:      	b	0xe734 <_stogir.checked.validate+0x440>
    e55c:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e55c:  ARM64_RELOC_PAGE21	l_stogir.535
    e560:      	ldr	x11, [x11]
		000000000000e560:  ARM64_RELOC_PAGEOFF12	l_stogir.535
    e564:      	mov	x12, #0x22              ; =34
    e568:      	cmp	x6, #0x2
    e56c:      	b.ge	0xe590 <_stogir.checked.validate+0x29c>
    e570:      	add	x7, x6, #0x1
    e574:      	add	x6, x13, x6, lsl #2
    e578:      	ldr	w6, [x6]
    e57c:      	movn	w17, #0x0, lsl #16
    e580:      	and	w9, w6, w17
    e584:      	mov	x6, x7
    e588:      	mov	w7, #0x1                ; =1
    e58c:      	b	0xe598 <_stogir.checked.validate+0x2a4>
    e590:      	movz	w7, #0x0, lsl #16
    e594:      	movz	w9, #0x0, lsl #16
    e598:      	ubfx	x7, x7, #0, #32
    e59c:      	lsr	x16, x7, #0
    e5a0:      	cmp	x16, #0x1
    e5a4:      	b.eq	0xe5c0 <_stogir.checked.validate+0x2cc>
    e5a8:      	b.lo	0xe5b0 <_stogir.checked.validate+0x2bc>
    e5ac:      	b	0xe5c4 <_stogir.checked.validate+0x2d0>
    e5b0:      	cmp	x16, #0x0
    e5b4:      	b.eq	0xe5bc <_stogir.checked.validate+0x2c8>
    e5b8:      	b	0xe5c4 <_stogir.checked.validate+0x2d0>
    e5bc:      	b	0xe624 <_stogir.checked.validate+0x330>
    e5c0:      	b	0xe5c8 <_stogir.checked.validate+0x2d4>
    e5c4:      	b	0xe72c <_stogir.checked.validate+0x438>
    e5c8:      	sxtw	x9, w9
    e5cc:      	cmp	x9, #0x0
    e5d0:      	cset	w7, gt
    e5d4:      	movz	x16, #0x0, lsl #48
    e5d8:      	sub	x10, x16, x9
    e5dc:      	sub	x14, x10, #0x1
    e5e0:      	uxtb	w16, w7
    e5e4:      	cmp	w16, wzr
    e5e8:      	b.eq	0xe680 <_stogir.checked.validate+0x38c>
    e5ec:      	ldr	x10, [x0, #0x8]
    e5f0:      	cmp	x9, x10
    e5f4:      	b.ge	0xe678 <_stogir.checked.validate+0x384>
    e5f8:      	ldr	x10, [x2, #0x8]
    e5fc:      	cmp	x9, x10
    e600:      	b.ge	0xe714 <_stogir.checked.validate+0x420>
    e604:      	ldr	x10, [x0, #0x78]
    e608:      	add	x10, x10, x9, lsl #2
    e60c:      	ldr	w10, [x10]
    e610:      	sxtw	x10, w10
    e614:      	cmp	x10, #0x0
    e618:      	cset	w10, ge
    e61c:      	ubfx	x10, x10, #0, #8
    e620:      	b	0xe718 <_stogir.checked.validate+0x424>
    e624:      	cmp	x12, #0x0
    e628:      	b.ne	0xe518 <_stogir.checked.validate+0x224>
    e62c:      	and	x11, x1, #0xffffffff
    e630:      	movz	x0, #0x0, lsl #48
    e634:      	movz	x12, #0x0, lsl #48
    e638:      	b	0xe51c <_stogir.checked.validate+0x228>
    e63c:      	ldr	x7, [x0, #0x28]
    e640:      	add	x7, x7, x14, lsl #4
    e644:      	ldr	x7, [x7]
    e648:      	mov	w9, #0x1                ; =1
    e64c:      	b	0xe52c <_stogir.checked.validate+0x238>
    e650:      	movz	x10, #0x0, lsl #48
    e654:      	cmp	x10, #0x0
    e658:      	b.eq	0xe524 <_stogir.checked.validate+0x230>
    e65c:      	uxtb	w16, w7
    e660:      	cmp	w16, wzr
    e664:      	b.eq	0xe63c <_stogir.checked.validate+0x348>
    e668:      	ldr	x7, [x0]
    e66c:      	add	x7, x7, x9, lsl #4
    e670:      	ldr	x7, [x7]
    e674:      	b	0xe648 <_stogir.checked.validate+0x354>
    e678:      	movz	x10, #0x0, lsl #48
    e67c:      	b	0xe654 <_stogir.checked.validate+0x360>
    e680:      	cmp	x9, #0x0
    e684:      	b.ge	0xe650 <_stogir.checked.validate+0x35c>
    e688:      	ldr	x15, [x3, #0x8]
    e68c:      	ldr	x19, [x4, #0x8]
    e690:      	cmp	x15, x19
    e694:      	b.ne	0xe70c <_stogir.checked.validate+0x418>
    e698:      	cmp	x10, x15
    e69c:      	b.gt	0xe724 <_stogir.checked.validate+0x430>
    e6a0:      	ldr	x10, [x0, #0x50]
    e6a4:      	add	x10, x10, x14, lsl #2
    e6a8:      	ldr	w10, [x10]
    e6ac:      	sxtw	x10, w10
    e6b0:      	cmp	x10, #0x0
    e6b4:      	cset	w10, gt
    e6b8:      	ubfx	x10, x10, #0, #8
    e6bc:      	b	0xe728 <_stogir.checked.validate+0x434>
    e6c0:      	ubfx	x7, x7, #0, #32
    e6c4:      	ubfx	x7, x7, #8, #8
    e6c8:      	cmp	x7, x1
    e6cc:      	b.eq	0xe6dc <_stogir.checked.validate+0x3e8>
    e6d0:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e6d0:  ARM64_RELOC_PAGE21	l_stogir.536
    e6d4:      	ldr	x11, [x11]
		000000000000e6d4:  ARM64_RELOC_PAGEOFF12	l_stogir.536
    e6d8:      	mov	x12, #0x28              ; =40
    e6dc:      	b	0xe568 <_stogir.checked.validate+0x274>
    e6e0:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e6e0:  ARM64_RELOC_PAGE21	l_stogir.537
    e6e4:      	ldr	x11, [x11]
		000000000000e6e4:  ARM64_RELOC_PAGEOFF12	l_stogir.537
    e6e8:      	mov	x12, #0x36              ; =54
    e6ec:      	orr	x13, x10, xzr
    e6f0:      	lsr	x7, x7, #32
    e6f4:      	str	w7, [x9]
    e6f8:      	str	w6, [x9, #0x4]
    e6fc:      	ldr	x6, [x9]
    e700:      	str	x6, [x10]
    e704:      	movz	x6, #0x0, lsl #48
    e708:      	b	0xe568 <_stogir.checked.validate+0x274>
    e70c:      	movz	x10, #0x0, lsl #48
    e710:      	b	0xe654 <_stogir.checked.validate+0x360>
    e714:      	movz	x10, #0x0, lsl #48
    e718:      	b	0xe67c <_stogir.checked.validate+0x388>
    e71c:      	brk	#0
    e720:      	b	0xe71c <_stogir.checked.validate+0x428>
    e724:      	movz	x10, #0x0, lsl #48
    e728:      	b	0xe710 <_stogir.checked.validate+0x41c>
    e72c:      	brk	#0
    e730:      	b	0xe72c <_stogir.checked.validate+0x438>
    e734:      	brk	#0
    e738:      	b	0xe734 <_stogir.checked.validate+0x440>

000000000000e73c <_coil.alloc.sized-request>:
    e73c:      	cmp	x3, #0x0
    e740:      	b.le	0xe768 <_coil.alloc.sized-request+0x2c>
    e744:      	cmp	x1, #0x0
    e748:      	b.le	0xe768 <_coil.alloc.sized-request+0x2c>
    e74c:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    e750:      	sdiv	x4, x16, x1
    e754:      	cmp	x3, x4
    e758:      	b.gt	0xe768 <_coil.alloc.sized-request+0x2c>
    e75c:      	mul	x1, x3, x1
    e760:      	mov	x4, #0x1                ; =1
    e764:      	b	0xe77c <_coil.alloc.sized-request+0x40>
    e768:      	movz	x4, #0x0, lsl #48
    e76c:      	movz	x0, #0x0, lsl #48
    e770:      	movz	x3, #0x0, lsl #48
    e774:      	movz	x1, #0x0, lsl #48
    e778:      	movz	x2, #0x0, lsl #48
    e77c:      	str	x4, [x8]
    e780:      	str	x0, [x8, #0x8]
    e784:      	str	x3, [x8, #0x10]
    e788:      	str	x1, [x8, #0x18]
    e78c:      	str	x2, [x8, #0x20]
    e790:      	ret

000000000000e794 <_coil.alloc.raw-free>:
    e794:      	sub	sp, sp, #0x10
    e798:      	str	x29, [sp]
    e79c:      	str	x30, [sp, #0x8]
    e7a0:      	mov	x29, sp
    e7a4:      	ldr	x3, [x2, #0x8]
    e7a8:      	cmp	x3, #0x0
    e7ac:      	b.le	0xe7f4 <_coil.alloc.raw-free+0x60>
    e7b0:      	ldr	x3, [x2, #0x10]
    e7b4:      	cmp	x3, #0x0
    e7b8:      	b.le	0xe7f4 <_coil.alloc.raw-free+0x60>
    e7bc:      	ldr	x3, [x2, #0x18]
    e7c0:      	cmp	x3, #0x0
    e7c4:      	b.le	0xe7f4 <_coil.alloc.raw-free+0x60>
    e7c8:      	sub	x4, x3, #0x1
    e7cc:      	and	x3, x4, x3
    e7d0:      	cmp	x3, #0x0
    e7d4:      	b.ne	0xe7f4 <_coil.alloc.raw-free+0x60>
    e7d8:      	ldr	x3, [x0]
    e7dc:      	ldr	x0, [x0, #0x8]
    e7e0:      	ldr	x0, [x0, #0x18]
    e7e4:      	mov	x30, x0
    e7e8:      	mov	x0, x3
    e7ec:      	blr	x30
    e7f0:      	b	0xe7f8 <_coil.alloc.raw-free+0x64>
    e7f4:      	movz	x0, #0x0, lsl #48
    e7f8:      	ldr	x29, [sp]
    e7fc:      	ldr	x30, [sp, #0x8]
    e800:      	add	sp, sp, #0x10
    e804:      	ret

000000000000e808 <_coil.alloc.reallocate__i32>:
    e808:      	sub	sp, sp, #0x40
    e80c:      	str	x29, [sp, #0x10]
    e810:      	str	x30, [sp, #0x18]
    e814:      	add	x29, sp, #0x10
    e818:      	str	x19, [sp, #0x30]
    e81c:      	str	x20, [sp, #0x38]
    e820:      	mov	x19, x8
    e824:      	mov	x20, x3
    e828:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e828:  ARM64_RELOC_PAGE21	l_stogir.538
    e82c:      	ldr	x4, [x4]
		000000000000e82c:  ARM64_RELOC_PAGEOFF12	l_stogir.538
    e830:      	mov	x5, #0x4                ; =4
    e834:      	mov	x6, #0x4                ; =4
    e838:      	bl	0xe838 <_coil.alloc.reallocate__i32+0x30>
		000000000000e838:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    e83c:      	ubfx	x0, x0, #0, #32
    e840:      	lsr	x16, x0, #0
    e844:      	cmp	x16, #0x1
    e848:      	b.eq	0xe864 <_coil.alloc.reallocate__i32+0x5c>
    e84c:      	b.lo	0xe854 <_coil.alloc.reallocate__i32+0x4c>
    e850:      	b	0xe868 <_coil.alloc.reallocate__i32+0x60>
    e854:      	cmp	x16, #0x0
    e858:      	b.eq	0xe860 <_coil.alloc.reallocate__i32+0x58>
    e85c:      	b	0xe868 <_coil.alloc.reallocate__i32+0x60>
    e860:      	b	0xe86c <_coil.alloc.reallocate__i32+0x64>
    e864:      	b	0xe87c <_coil.alloc.reallocate__i32+0x74>
    e868:      	b	0xe8a4 <_coil.alloc.reallocate__i32+0x9c>
    e86c:      	movz	x0, #0x0, lsl #48
    e870:      	movz	x1, #0x0, lsl #48
    e874:      	movz	x20, #0x0, lsl #48
    e878:      	b	0xe880 <_coil.alloc.reallocate__i32+0x78>
    e87c:      	mov	x0, #0x1                ; =1
    e880:      	str	x0, [x19]
    e884:      	str	x1, [x19, #0x8]
    e888:      	str	x20, [x19, #0x10]
    e88c:      	ldr	x19, [sp, #0x30]
    e890:      	ldr	x20, [sp, #0x38]
    e894:      	ldr	x29, [sp, #0x10]
    e898:      	ldr	x30, [sp, #0x18]
    e89c:      	add	sp, sp, #0x40
    e8a0:      	ret
    e8a4:      	brk	#0
    e8a8:      	b	0xe8a4 <_coil.alloc.reallocate__i32+0x9c>
    e8ac:      	udf	#0x0

000000000000e8b0 <_coil.alloc.oom-at>:
    e8b0:      	sub	sp, sp, #0x20
    e8b4:      	str	x29, [sp]
    e8b8:      	str	x30, [sp, #0x8]
    e8bc:      	mov	x29, sp
    e8c0:      	str	x19, [sp, #0x10]
    e8c4:      	str	x20, [sp, #0x18]
    e8c8:      	movz	x2, #0x0, lsl #48
    e8cc:      	b	0xe8d4 <_coil.alloc.oom-at+0x24>
    e8d0:      	add	x2, x2, #0x1
    e8d4:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e8d4:  ARM64_RELOC_PAGE21	l_stogir.539
    e8d8:      	ldr	x17, [x17]
		000000000000e8d8:  ARM64_RELOC_PAGEOFF12	l_stogir.539
    e8dc:      	add	x3, x2, x17
    e8e0:      	ldrsb	w3, [x3]
    e8e4:      	sxtb	x3, w3
    e8e8:      	cmp	x3, #0x0
    e8ec:      	b.ne	0xe8d0 <_coil.alloc.oom-at+0x20>
    e8f0:      	mov	x19, x0
    e8f4:      	mov	x20, x1
    e8f8:      	mov	x0, #0x2                ; =2
    e8fc:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e8fc:  ARM64_RELOC_PAGE21	l_stogir.539
    e900:      	ldr	x1, [x1]
		000000000000e900:  ARM64_RELOC_PAGEOFF12	l_stogir.539
    e904:      	bl	0xe904 <_coil.alloc.oom-at+0x54>
		000000000000e904:  ARM64_RELOC_BRANCH26	_write
    e908:      	movz	x0, #0x0, lsl #48
    e90c:      	b	0xe914 <_coil.alloc.oom-at+0x64>
    e910:      	add	x0, x0, #0x1
    e914:      	add	x1, x0, x19
    e918:      	ldrsb	w1, [x1]
    e91c:      	sxtb	x1, w1
    e920:      	cmp	x1, #0x0
    e924:      	b.ne	0xe910 <_coil.alloc.oom-at+0x60>
    e928:      	mov	x1, x19
    e92c:      	mov	x2, x0
    e930:      	mov	x0, #0x2                ; =2
    e934:      	bl	0xe934 <_coil.alloc.oom-at+0x84>
		000000000000e934:  ARM64_RELOC_BRANCH26	_write
    e938:      	movz	x0, #0x0, lsl #48
    e93c:      	b	0xe944 <_coil.alloc.oom-at+0x94>
    e940:      	add	x0, x0, #0x1
    e944:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e944:  ARM64_RELOC_PAGE21	l_stogir.540
    e948:      	ldr	x17, [x17]
		000000000000e948:  ARM64_RELOC_PAGEOFF12	l_stogir.540
    e94c:      	add	x1, x0, x17
    e950:      	ldrsb	w1, [x1]
    e954:      	sxtb	x1, w1
    e958:      	cmp	x1, #0x0
    e95c:      	b.ne	0xe940 <_coil.alloc.oom-at+0x90>
    e960:      	mov	x2, x0
    e964:      	mov	x0, #0x2                ; =2
    e968:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e968:  ARM64_RELOC_PAGE21	l_stogir.540
    e96c:      	ldr	x1, [x1]
		000000000000e96c:  ARM64_RELOC_PAGEOFF12	l_stogir.540
    e970:      	bl	0xe970 <_coil.alloc.oom-at+0xc0>
		000000000000e970:  ARM64_RELOC_BRANCH26	_write
    e974:      	cmp	x20, #0x0
    e978:      	b.lt	0xea64 <_coil.alloc.oom-at+0x1b4>
    e97c:      	movz	x0, #0x0, lsl #48
    e980:      	b	0xe98c <_coil.alloc.oom-at+0xdc>
    e984:      	nop
    e988:      	add	x0, x0, #0x1
    e98c:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e98c:  ARM64_RELOC_PAGE21	l_stogir.541
    e990:      	ldr	x17, [x17]
		000000000000e990:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    e994:      	add	x1, x0, x17
    e998:      	ldrsb	w1, [x1]
    e99c:      	sxtb	x1, w1
    e9a0:      	cmp	x1, #0x0
    e9a4:      	b.ne	0xe988 <_coil.alloc.oom-at+0xd8>
    e9a8:      	mov	x2, x0
    e9ac:      	mov	x0, #0x2                ; =2
    e9b0:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e9b0:  ARM64_RELOC_PAGE21	l_stogir.541
    e9b4:      	ldr	x1, [x1]
		000000000000e9b4:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    e9b8:      	bl	0xe9b8 <_coil.alloc.oom-at+0x108>
		000000000000e9b8:  ARM64_RELOC_BRANCH26	_write
    e9bc:      	mov	x0, #0x18               ; =24
    e9c0:      	sub	x0, x0, #0x1
    e9c4:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000e9c4:  ARM64_RELOC_PAGE21	l_stogir.542
    e9c8:      	ldr	x17, [x17]
		000000000000e9c8:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    e9cc:      	add	x1, x0, x17
    e9d0:      	mov	x17, #0xa               ; =10
    e9d4:      	sdiv	x16, x20, x17
    e9d8:      	msub	x2, x16, x17, x20
    e9dc:      	mov	x17, #0xa               ; =10
    e9e0:      	sdiv	x3, x20, x17
    e9e4:      	orr	x20, x3, xzr
    e9e8:      	add	x2, x2, #0x30
    e9ec:      	uxtb	w2, w2
    e9f0:      	uxtb	w2, w2
    e9f4:      	strb	w2, [x1]
    e9f8:      	cmp	x20, #0x0
    e9fc:      	b.ne	0xe9c0 <_coil.alloc.oom-at+0x110>
    ea00:      	mov	x16, #0x18              ; =24
    ea04:      	sub	x1, x16, x0
    ea08:      	adrp	x16, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ea08:  ARM64_RELOC_PAGE21	l_stogir.542
    ea0c:      	ldr	x16, [x16]
		000000000000ea0c:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    ea10:      	add	x0, x16, x0
    ea14:      	mov	x2, x1
    ea18:      	mov	x1, x0
    ea1c:      	mov	x0, #0x2                ; =2
    ea20:      	bl	0xea20 <_coil.alloc.oom-at+0x170>
		000000000000ea20:  ARM64_RELOC_BRANCH26	_write
    ea24:      	movz	x0, #0x0, lsl #48
    ea28:      	b	0xea34 <_coil.alloc.oom-at+0x184>
    ea2c:      	nop
    ea30:      	add	x0, x0, #0x1
    ea34:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ea34:  ARM64_RELOC_PAGE21	l_stogir.543
    ea38:      	ldr	x17, [x17]
		000000000000ea38:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    ea3c:      	add	x1, x0, x17
    ea40:      	ldrsb	w1, [x1]
    ea44:      	sxtb	x1, w1
    ea48:      	cmp	x1, #0x0
    ea4c:      	b.ne	0xea30 <_coil.alloc.oom-at+0x180>
    ea50:      	mov	x2, x0
    ea54:      	mov	x0, #0x2                ; =2
    ea58:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ea58:  ARM64_RELOC_PAGE21	l_stogir.543
    ea5c:      	ldr	x1, [x1]
		000000000000ea5c:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    ea60:      	bl	0xea60 <_coil.alloc.oom-at+0x1b0>
		000000000000ea60:  ARM64_RELOC_BRANCH26	_write
    ea64:      	movz	x0, #0x0, lsl #48
    ea68:      	b	0xea74 <_coil.alloc.oom-at+0x1c4>
    ea6c:      	nop
    ea70:      	add	x0, x0, #0x1
    ea74:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ea74:  ARM64_RELOC_PAGE21	l_stogir.544
    ea78:      	ldr	x17, [x17]
		000000000000ea78:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    ea7c:      	add	x1, x0, x17
    ea80:      	ldrsb	w1, [x1]
    ea84:      	sxtb	x1, w1
    ea88:      	cmp	x1, #0x0
    ea8c:      	b.ne	0xea70 <_coil.alloc.oom-at+0x1c0>
    ea90:      	mov	x2, x0
    ea94:      	mov	x0, #0x2                ; =2
    ea98:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ea98:  ARM64_RELOC_PAGE21	l_stogir.544
    ea9c:      	ldr	x1, [x1]
		000000000000ea9c:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    eaa0:      	bl	0xeaa0 <_coil.alloc.oom-at+0x1f0>
		000000000000eaa0:  ARM64_RELOC_BRANCH26	_write
    eaa4:      	bl	0xeaa4 <_coil.alloc.oom-at+0x1f4>
		000000000000eaa4:  ARM64_RELOC_BRANCH26	_abort
    eaa8:      	b	0xeaa8 <_coil.alloc.oom-at+0x1f8>

000000000000eaac <_coil.alloc.reallocate__stogir.cfg.Edge>:
    eaac:      	sub	sp, sp, #0x40
    eab0:      	str	x29, [sp, #0x10]
    eab4:      	str	x30, [sp, #0x18]
    eab8:      	add	x29, sp, #0x10
    eabc:      	str	x19, [sp, #0x30]
    eac0:      	str	x20, [sp, #0x38]
    eac4:      	mov	x19, x8
    eac8:      	mov	x20, x3
    eacc:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000eacc:  ARM64_RELOC_PAGE21	l_stogir.545
    ead0:      	ldr	x4, [x4]
		000000000000ead0:  ARM64_RELOC_PAGEOFF12	l_stogir.545
    ead4:      	mov	x5, #0x10               ; =16
    ead8:      	mov	x6, #0x4                ; =4
    eadc:      	bl	0xeadc <_coil.alloc.reallocate__stogir.cfg.Edge+0x30>
		000000000000eadc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    eae0:      	ubfx	x0, x0, #0, #32
    eae4:      	lsr	x16, x0, #0
    eae8:      	cmp	x16, #0x1
    eaec:      	b.eq	0xeb08 <_coil.alloc.reallocate__stogir.cfg.Edge+0x5c>
    eaf0:      	b.lo	0xeaf8 <_coil.alloc.reallocate__stogir.cfg.Edge+0x4c>
    eaf4:      	b	0xeb0c <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    eaf8:      	cmp	x16, #0x0
    eafc:      	b.eq	0xeb04 <_coil.alloc.reallocate__stogir.cfg.Edge+0x58>
    eb00:      	b	0xeb0c <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    eb04:      	b	0xeb10 <_coil.alloc.reallocate__stogir.cfg.Edge+0x64>
    eb08:      	b	0xeb20 <_coil.alloc.reallocate__stogir.cfg.Edge+0x74>
    eb0c:      	b	0xeb48 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>
    eb10:      	movz	x0, #0x0, lsl #48
    eb14:      	movz	x1, #0x0, lsl #48
    eb18:      	movz	x20, #0x0, lsl #48
    eb1c:      	b	0xeb24 <_coil.alloc.reallocate__stogir.cfg.Edge+0x78>
    eb20:      	mov	x0, #0x1                ; =1
    eb24:      	str	x0, [x19]
    eb28:      	str	x1, [x19, #0x8]
    eb2c:      	str	x20, [x19, #0x10]
    eb30:      	ldr	x19, [sp, #0x30]
    eb34:      	ldr	x20, [sp, #0x38]
    eb38:      	ldr	x29, [sp, #0x10]
    eb3c:      	ldr	x30, [sp, #0x18]
    eb40:      	add	sp, sp, #0x40
    eb44:      	ret
    eb48:      	brk	#0
    eb4c:      	b	0xeb48 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>

000000000000eb50 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range>:
    eb50:      	sub	sp, sp, #0x50
    eb54:      	str	x29, [sp]
    eb58:      	str	x30, [sp, #0x8]
    eb5c:      	mov	x29, sp
    eb60:      	str	x19, [sp, #0x40]
    eb64:      	str	x20, [sp, #0x48]
    eb68:      	add	x2, x0, #0x18
    eb6c:      	ldr	x3, [x0, #0x10]
    eb70:      	ldr	x4, [x0, #0x18]
    eb74:      	ldr	x2, [x2, #0x8]
    eb78:      	add	x16, sp, #0x10
    eb7c:      	str	x4, [x16]
    eb80:      	add	x16, sp, #0x10
    eb84:      	str	x2, [x16, #0x8]
    eb88:      	cmp	x1, x3
    eb8c:      	b.le	0xebfc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xac>
    eb90:      	ldr	x2, [x0]
    eb94:      	add	x8, sp, #0x20
    eb98:      	mov	x19, x0
    eb9c:      	add	x0, sp, #0x10
    eba0:      	mov	x20, x1
    eba4:      	fmov	d31, x1
    eba8:      	mov	x1, x2
    ebac:      	mov	x2, x3
    ebb0:      	fmov	x3, d31
    ebb4:      	bl	0xebb4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x64>
		000000000000ebb4:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Range
    ebb8:      	add	x16, sp, #0x20
    ebbc:      	ldr	w0, [x16]
    ebc0:      	lsr	x16, x0, #0
    ebc4:      	cmp	x16, #0x1
    ebc8:      	b.eq	0xebe4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x94>
    ebcc:      	b.lo	0xebd4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x84>
    ebd0:      	b	0xebe8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x98>
    ebd4:      	cmp	x16, #0x0
    ebd8:      	b.eq	0xebe0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x90>
    ebdc:      	b	0xebe8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x98>
    ebe0:      	b	0xec18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xc8>
    ebe4:      	b	0xebec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x9c>
    ebe8:      	b	0xec30 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe0>
    ebec:      	add	x16, sp, #0x20
    ebf0:      	ldr	x0, [x16, #0x8]
    ebf4:      	str	x0, [x19]
    ebf8:      	str	x20, [x19, #0x10]
    ebfc:      	movz	x0, #0x0, lsl #48
    ec00:      	ldr	x19, [sp, #0x40]
    ec04:      	ldr	x20, [sp, #0x48]
    ec08:      	ldr	x29, [sp]
    ec0c:      	ldr	x30, [sp, #0x8]
    ec10:      	add	sp, sp, #0x50
    ec14:      	ret
    ec18:      	lsl	x0, x20, #4
    ec1c:      	mov	x1, x0
    ec20:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ec20:  ARM64_RELOC_PAGE21	l_stogir.546
    ec24:      	ldr	x0, [x0]
		000000000000ec24:  ARM64_RELOC_PAGEOFF12	l_stogir.546
    ec28:      	bl	0xec28 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xd8>
		000000000000ec28:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    ec2c:      	b	0xec2c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xdc>
    ec30:      	brk	#0
    ec34:      	b	0xec30 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe0>

000000000000ec38 <_coil.alloc.reallocate__bool>:
    ec38:      	sub	sp, sp, #0x40
    ec3c:      	str	x29, [sp, #0x10]
    ec40:      	str	x30, [sp, #0x18]
    ec44:      	add	x29, sp, #0x10
    ec48:      	str	x19, [sp, #0x30]
    ec4c:      	str	x20, [sp, #0x38]
    ec50:      	mov	x19, x8
    ec54:      	mov	x20, x3
    ec58:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ec58:  ARM64_RELOC_PAGE21	l_stogir.547
    ec5c:      	ldr	x4, [x4]
		000000000000ec5c:  ARM64_RELOC_PAGEOFF12	l_stogir.547
    ec60:      	mov	x5, #0x1                ; =1
    ec64:      	mov	x6, #0x1                ; =1
    ec68:      	bl	0xec68 <_coil.alloc.reallocate__bool+0x30>
		000000000000ec68:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ec6c:      	ubfx	x0, x0, #0, #32
    ec70:      	lsr	x16, x0, #0
    ec74:      	cmp	x16, #0x1
    ec78:      	b.eq	0xec94 <_coil.alloc.reallocate__bool+0x5c>
    ec7c:      	b.lo	0xec84 <_coil.alloc.reallocate__bool+0x4c>
    ec80:      	b	0xec98 <_coil.alloc.reallocate__bool+0x60>
    ec84:      	cmp	x16, #0x0
    ec88:      	b.eq	0xec90 <_coil.alloc.reallocate__bool+0x58>
    ec8c:      	b	0xec98 <_coil.alloc.reallocate__bool+0x60>
    ec90:      	b	0xec9c <_coil.alloc.reallocate__bool+0x64>
    ec94:      	b	0xecac <_coil.alloc.reallocate__bool+0x74>
    ec98:      	b	0xecd4 <_coil.alloc.reallocate__bool+0x9c>
    ec9c:      	movz	x0, #0x0, lsl #48
    eca0:      	movz	x1, #0x0, lsl #48
    eca4:      	movz	x20, #0x0, lsl #48
    eca8:      	b	0xecb0 <_coil.alloc.reallocate__bool+0x78>
    ecac:      	mov	x0, #0x1                ; =1
    ecb0:      	str	x0, [x19]
    ecb4:      	str	x1, [x19, #0x8]
    ecb8:      	str	x20, [x19, #0x10]
    ecbc:      	ldr	x19, [sp, #0x30]
    ecc0:      	ldr	x20, [sp, #0x38]
    ecc4:      	ldr	x29, [sp, #0x10]
    ecc8:      	ldr	x30, [sp, #0x18]
    eccc:      	add	sp, sp, #0x40
    ecd0:      	ret
    ecd4:      	brk	#0
    ecd8:      	b	0xecd4 <_coil.alloc.reallocate__bool+0x9c>

000000000000ecdc <_coil.alloc.reallocate__stogir.adjacency.Frame>:
    ecdc:      	sub	sp, sp, #0x40
    ece0:      	str	x29, [sp, #0x10]
    ece4:      	str	x30, [sp, #0x18]
    ece8:      	add	x29, sp, #0x10
    ecec:      	str	x19, [sp, #0x30]
    ecf0:      	str	x20, [sp, #0x38]
    ecf4:      	mov	x19, x8
    ecf8:      	mov	x20, x3
    ecfc:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ecfc:  ARM64_RELOC_PAGE21	l_stogir.548
    ed00:      	ldr	x4, [x4]
		000000000000ed00:  ARM64_RELOC_PAGEOFF12	l_stogir.548
    ed04:      	mov	x5, #0x10               ; =16
    ed08:      	mov	x6, #0x8                ; =8
    ed0c:      	bl	0xed0c <_coil.alloc.reallocate__stogir.adjacency.Frame+0x30>
		000000000000ed0c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ed10:      	ubfx	x0, x0, #0, #32
    ed14:      	lsr	x16, x0, #0
    ed18:      	cmp	x16, #0x1
    ed1c:      	b.eq	0xed38 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x5c>
    ed20:      	b.lo	0xed28 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x4c>
    ed24:      	b	0xed3c <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    ed28:      	cmp	x16, #0x0
    ed2c:      	b.eq	0xed34 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x58>
    ed30:      	b	0xed3c <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    ed34:      	b	0xed40 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x64>
    ed38:      	b	0xed50 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x74>
    ed3c:      	b	0xed78 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>
    ed40:      	movz	x0, #0x0, lsl #48
    ed44:      	movz	x1, #0x0, lsl #48
    ed48:      	movz	x20, #0x0, lsl #48
    ed4c:      	b	0xed54 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x78>
    ed50:      	mov	x0, #0x1                ; =1
    ed54:      	str	x0, [x19]
    ed58:      	str	x1, [x19, #0x8]
    ed5c:      	str	x20, [x19, #0x10]
    ed60:      	ldr	x19, [sp, #0x30]
    ed64:      	ldr	x20, [sp, #0x38]
    ed68:      	ldr	x29, [sp, #0x10]
    ed6c:      	ldr	x30, [sp, #0x18]
    ed70:      	add	sp, sp, #0x40
    ed74:      	ret
    ed78:      	brk	#0
    ed7c:      	b	0xed78 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>

000000000000ed80 <_coil.alloc.reallocate__i64>:
    ed80:      	sub	sp, sp, #0x40
    ed84:      	str	x29, [sp, #0x10]
    ed88:      	str	x30, [sp, #0x18]
    ed8c:      	add	x29, sp, #0x10
    ed90:      	str	x19, [sp, #0x30]
    ed94:      	str	x20, [sp, #0x38]
    ed98:      	mov	x19, x8
    ed9c:      	mov	x20, x3
    eda0:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000eda0:  ARM64_RELOC_PAGE21	l_stogir.549
    eda4:      	ldr	x4, [x4]
		000000000000eda4:  ARM64_RELOC_PAGEOFF12	l_stogir.549
    eda8:      	mov	x5, #0x8                ; =8
    edac:      	mov	x6, #0x8                ; =8
    edb0:      	bl	0xedb0 <_coil.alloc.reallocate__i64+0x30>
		000000000000edb0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    edb4:      	ubfx	x0, x0, #0, #32
    edb8:      	lsr	x16, x0, #0
    edbc:      	cmp	x16, #0x1
    edc0:      	b.eq	0xeddc <_coil.alloc.reallocate__i64+0x5c>
    edc4:      	b.lo	0xedcc <_coil.alloc.reallocate__i64+0x4c>
    edc8:      	b	0xede0 <_coil.alloc.reallocate__i64+0x60>
    edcc:      	cmp	x16, #0x0
    edd0:      	b.eq	0xedd8 <_coil.alloc.reallocate__i64+0x58>
    edd4:      	b	0xede0 <_coil.alloc.reallocate__i64+0x60>
    edd8:      	b	0xede4 <_coil.alloc.reallocate__i64+0x64>
    eddc:      	b	0xedf4 <_coil.alloc.reallocate__i64+0x74>
    ede0:      	b	0xee1c <_coil.alloc.reallocate__i64+0x9c>
    ede4:      	movz	x0, #0x0, lsl #48
    ede8:      	movz	x1, #0x0, lsl #48
    edec:      	movz	x20, #0x0, lsl #48
    edf0:      	b	0xedf8 <_coil.alloc.reallocate__i64+0x78>
    edf4:      	mov	x0, #0x1                ; =1
    edf8:      	str	x0, [x19]
    edfc:      	str	x1, [x19, #0x8]
    ee00:      	str	x20, [x19, #0x10]
    ee04:      	ldr	x19, [sp, #0x30]
    ee08:      	ldr	x20, [sp, #0x38]
    ee0c:      	ldr	x29, [sp, #0x10]
    ee10:      	ldr	x30, [sp, #0x18]
    ee14:      	add	sp, sp, #0x40
    ee18:      	ret
    ee1c:      	brk	#0
    ee20:      	b	0xee1c <_coil.alloc.reallocate__i64+0x9c>

000000000000ee24 <_coil.alloc.reallocate__stogir.uses.Range>:
    ee24:      	sub	sp, sp, #0x40
    ee28:      	str	x29, [sp, #0x10]
    ee2c:      	str	x30, [sp, #0x18]
    ee30:      	add	x29, sp, #0x10
    ee34:      	str	x19, [sp, #0x30]
    ee38:      	str	x20, [sp, #0x38]
    ee3c:      	mov	x19, x8
    ee40:      	mov	x20, x3
    ee44:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ee44:  ARM64_RELOC_PAGE21	l_stogir.550
    ee48:      	ldr	x4, [x4]
		000000000000ee48:  ARM64_RELOC_PAGEOFF12	l_stogir.550
    ee4c:      	mov	x5, #0x10               ; =16
    ee50:      	mov	x6, #0x8                ; =8
    ee54:      	bl	0xee54 <_coil.alloc.reallocate__stogir.uses.Range+0x30>
		000000000000ee54:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ee58:      	ubfx	x0, x0, #0, #32
    ee5c:      	lsr	x16, x0, #0
    ee60:      	cmp	x16, #0x1
    ee64:      	b.eq	0xee80 <_coil.alloc.reallocate__stogir.uses.Range+0x5c>
    ee68:      	b.lo	0xee70 <_coil.alloc.reallocate__stogir.uses.Range+0x4c>
    ee6c:      	b	0xee84 <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    ee70:      	cmp	x16, #0x0
    ee74:      	b.eq	0xee7c <_coil.alloc.reallocate__stogir.uses.Range+0x58>
    ee78:      	b	0xee84 <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    ee7c:      	b	0xee88 <_coil.alloc.reallocate__stogir.uses.Range+0x64>
    ee80:      	b	0xee98 <_coil.alloc.reallocate__stogir.uses.Range+0x74>
    ee84:      	b	0xeec0 <_coil.alloc.reallocate__stogir.uses.Range+0x9c>
    ee88:      	movz	x0, #0x0, lsl #48
    ee8c:      	movz	x1, #0x0, lsl #48
    ee90:      	movz	x20, #0x0, lsl #48
    ee94:      	b	0xee9c <_coil.alloc.reallocate__stogir.uses.Range+0x78>
    ee98:      	mov	x0, #0x1                ; =1
    ee9c:      	str	x0, [x19]
    eea0:      	str	x1, [x19, #0x8]
    eea4:      	str	x20, [x19, #0x10]
    eea8:      	ldr	x19, [sp, #0x30]
    eeac:      	ldr	x20, [sp, #0x38]
    eeb0:      	ldr	x29, [sp, #0x10]
    eeb4:      	ldr	x30, [sp, #0x18]
    eeb8:      	add	sp, sp, #0x40
    eebc:      	ret
    eec0:      	brk	#0
    eec4:      	b	0xeec0 <_coil.alloc.reallocate__stogir.uses.Range+0x9c>

000000000000eec8 <_coil.alloc.reallocate__stogir.uses.Use>:
    eec8:      	sub	sp, sp, #0x40
    eecc:      	str	x29, [sp, #0x10]
    eed0:      	str	x30, [sp, #0x18]
    eed4:      	add	x29, sp, #0x10
    eed8:      	str	x19, [sp, #0x30]
    eedc:      	str	x20, [sp, #0x38]
    eee0:      	mov	x19, x8
    eee4:      	mov	x20, x3
    eee8:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000eee8:  ARM64_RELOC_PAGE21	l_stogir.551
    eeec:      	ldr	x4, [x4]
		000000000000eeec:  ARM64_RELOC_PAGEOFF12	l_stogir.551
    eef0:      	mov	x5, #0x8                ; =8
    eef4:      	mov	x6, #0x4                ; =4
    eef8:      	bl	0xeef8 <_coil.alloc.reallocate__stogir.uses.Use+0x30>
		000000000000eef8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    eefc:      	ubfx	x0, x0, #0, #32
    ef00:      	lsr	x16, x0, #0
    ef04:      	cmp	x16, #0x1
    ef08:      	b.eq	0xef24 <_coil.alloc.reallocate__stogir.uses.Use+0x5c>
    ef0c:      	b.lo	0xef14 <_coil.alloc.reallocate__stogir.uses.Use+0x4c>
    ef10:      	b	0xef28 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    ef14:      	cmp	x16, #0x0
    ef18:      	b.eq	0xef20 <_coil.alloc.reallocate__stogir.uses.Use+0x58>
    ef1c:      	b	0xef28 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    ef20:      	b	0xef2c <_coil.alloc.reallocate__stogir.uses.Use+0x64>
    ef24:      	b	0xef3c <_coil.alloc.reallocate__stogir.uses.Use+0x74>
    ef28:      	b	0xef64 <_coil.alloc.reallocate__stogir.uses.Use+0x9c>
    ef2c:      	movz	x0, #0x0, lsl #48
    ef30:      	movz	x1, #0x0, lsl #48
    ef34:      	movz	x20, #0x0, lsl #48
    ef38:      	b	0xef40 <_coil.alloc.reallocate__stogir.uses.Use+0x78>
    ef3c:      	mov	x0, #0x1                ; =1
    ef40:      	str	x0, [x19]
    ef44:      	str	x1, [x19, #0x8]
    ef48:      	str	x20, [x19, #0x10]
    ef4c:      	ldr	x19, [sp, #0x30]
    ef50:      	ldr	x20, [sp, #0x38]
    ef54:      	ldr	x29, [sp, #0x10]
    ef58:      	ldr	x30, [sp, #0x18]
    ef5c:      	add	sp, sp, #0x40
    ef60:      	ret
    ef64:      	brk	#0
    ef68:      	b	0xef64 <_coil.alloc.reallocate__stogir.uses.Use+0x9c>

000000000000ef6c <_coil.alloc.reallocate__stogir.schedule.Range>:
    ef6c:      	sub	sp, sp, #0x40
    ef70:      	str	x29, [sp, #0x10]
    ef74:      	str	x30, [sp, #0x18]
    ef78:      	add	x29, sp, #0x10
    ef7c:      	str	x19, [sp, #0x30]
    ef80:      	str	x20, [sp, #0x38]
    ef84:      	mov	x19, x8
    ef88:      	mov	x20, x3
    ef8c:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
		000000000000ef8c:  ARM64_RELOC_PAGE21	l_stogir.552
    ef90:      	ldr	x4, [x4]
		000000000000ef90:  ARM64_RELOC_PAGEOFF12	l_stogir.552
    ef94:      	mov	x5, #0x10               ; =16
    ef98:      	mov	x6, #0x8                ; =8
    ef9c:      	bl	0xef9c <_coil.alloc.reallocate__stogir.schedule.Range+0x30>
		000000000000ef9c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    efa0:      	ubfx	x0, x0, #0, #32
    efa4:      	lsr	x16, x0, #0
    efa8:      	cmp	x16, #0x1
    efac:      	b.eq	0xefc8 <_coil.alloc.reallocate__stogir.schedule.Range+0x5c>
    efb0:      	b.lo	0xefb8 <_coil.alloc.reallocate__stogir.schedule.Range+0x4c>
    efb4:      	b	0xefcc <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    efb8:      	cmp	x16, #0x0
    efbc:      	b.eq	0xefc4 <_coil.alloc.reallocate__stogir.schedule.Range+0x58>
    efc0:      	b	0xefcc <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    efc4:      	b	0xefd0 <_coil.alloc.reallocate__stogir.schedule.Range+0x64>
    efc8:      	b	0xefe0 <_coil.alloc.reallocate__stogir.schedule.Range+0x74>
    efcc:      	b	0xf008 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>
    efd0:      	movz	x0, #0x0, lsl #48
    efd4:      	movz	x1, #0x0, lsl #48
    efd8:      	movz	x20, #0x0, lsl #48
    efdc:      	b	0xefe4 <_coil.alloc.reallocate__stogir.schedule.Range+0x78>
    efe0:      	mov	x0, #0x1                ; =1
    efe4:      	str	x0, [x19]
    efe8:      	str	x1, [x19, #0x8]
    efec:      	str	x20, [x19, #0x10]
    eff0:      	ldr	x19, [sp, #0x30]
    eff4:      	ldr	x20, [sp, #0x38]
    eff8:      	ldr	x29, [sp, #0x10]
    effc:      	ldr	x30, [sp, #0x18]
    f000:      	add	sp, sp, #0x40
    f004:      	ret
    f008:      	brk	#0
    f00c:      	b	0xf008 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>

000000000000f010 <_coil.alloc.sized-reallocate>:
    f010:      	sub	sp, sp, #0x90
    f014:      	str	x29, [sp, #0x10]
    f018:      	str	x30, [sp, #0x18]
    f01c:      	add	x29, sp, #0x10
    f020:      	str	x19, [sp, #0x50]
    f024:      	str	x20, [sp, #0x58]
    f028:      	str	x21, [sp, #0x60]
    f02c:      	str	x22, [sp, #0x68]
    f030:      	str	x23, [sp, #0x70]
    f034:      	str	x24, [sp, #0x78]
    f038:      	str	x25, [sp, #0x80]
    f03c:      	str	x26, [sp, #0x88]
    f040:      	add	x19, sp, #0x20
    f044:      	mov	x20, x0
    f048:      	mov	x21, x1
    f04c:      	mov	x22, x2
    f050:      	mov	x23, x3
    f054:      	mov	x24, x4
    f058:      	mov	x25, x5
    f05c:      	mov	x26, x6
    f060:      	movz	x7, #0x0, lsl #48
    f064:      	uxtb	w7, w7
    f068:      	bl	0xf068 <_coil.alloc.sized-reallocate+0x58>
		000000000000f068:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-resize
    f06c:      	ubfx	x0, x0, #0, #32
    f070:      	lsr	x16, x0, #0
    f074:      	cmp	x16, #0x1
    f078:      	b.eq	0xf094 <_coil.alloc.sized-reallocate+0x84>
    f07c:      	b.lo	0xf084 <_coil.alloc.sized-reallocate+0x74>
    f080:      	b	0xf098 <_coil.alloc.sized-reallocate+0x88>
    f084:      	cmp	x16, #0x0
    f088:      	b.eq	0xf090 <_coil.alloc.sized-reallocate+0x80>
    f08c:      	b	0xf098 <_coil.alloc.sized-reallocate+0x88>
    f090:      	b	0xf0e4 <_coil.alloc.sized-reallocate+0xd4>
    f094:      	b	0xf09c <_coil.alloc.sized-reallocate+0x8c>
    f098:      	b	0xf180 <_coil.alloc.sized-reallocate+0x170>
    f09c:      	mov	x23, x1
    f0a0:      	mov	x0, #0x1                ; =1
    f0a4:      	str	x0, [x19]
    f0a8:      	str	x23, [x19, #0x8]
    f0ac:      	ldr	x0, [sp, #0x20]
    f0b0:      	ldr	x1, [sp, #0x28]
    f0b4:      	ldr	x19, [sp, #0x50]
    f0b8:      	ldr	x20, [sp, #0x58]
    f0bc:      	ldr	x21, [sp, #0x60]
    f0c0:      	ldr	x22, [sp, #0x68]
    f0c4:      	ldr	x23, [sp, #0x70]
    f0c8:      	ldr	x24, [sp, #0x78]
    f0cc:      	ldr	x25, [sp, #0x80]
    f0d0:      	ldr	x26, [sp, #0x88]
    f0d4:      	ldr	x29, [sp, #0x10]
    f0d8:      	ldr	x30, [sp, #0x18]
    f0dc:      	add	sp, sp, #0x90
    f0e0:      	ret
    f0e4:      	mov	x0, x20
    f0e8:      	mov	x1, x24
    f0ec:      	mov	x2, x25
    f0f0:      	mov	x3, x26
    f0f4:      	mov	x4, x23
    f0f8:      	bl	0xf0f8 <_coil.alloc.sized-reallocate+0xe8>
		000000000000f0f8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    f0fc:      	ubfx	x0, x0, #0, #32
    f100:      	lsr	x16, x0, #0
    f104:      	cmp	x16, #0x1
    f108:      	b.eq	0xf124 <_coil.alloc.sized-reallocate+0x114>
    f10c:      	b.lo	0xf114 <_coil.alloc.sized-reallocate+0x104>
    f110:      	b	0xf128 <_coil.alloc.sized-reallocate+0x118>
    f114:      	cmp	x16, #0x0
    f118:      	b.eq	0xf120 <_coil.alloc.sized-reallocate+0x110>
    f11c:      	b	0xf128 <_coil.alloc.sized-reallocate+0x118>
    f120:      	b	0xf12c <_coil.alloc.sized-reallocate+0x11c>
    f124:      	b	0xf138 <_coil.alloc.sized-reallocate+0x128>
    f128:      	b	0xf188 <_coil.alloc.sized-reallocate+0x178>
    f12c:      	movz	x0, #0x0, lsl #48
    f130:      	movz	x23, #0x0, lsl #48
    f134:      	b	0xf17c <_coil.alloc.sized-reallocate+0x16c>
    f138:      	cmp	x22, x23
    f13c:      	b.ge	0xf144 <_coil.alloc.sized-reallocate+0x134>
    f140:      	mov	x23, x22
    f144:      	orr	x0, x1, xzr
    f148:      	mul	x2, x25, x23
    f14c:      	lsr	x2, x2, #0
    f150:      	mov	x23, x1
    f154:      	mov	x1, x21
    f158:      	bl	0xf158 <_coil.alloc.sized-reallocate+0x148>
		000000000000f158:  ARM64_RELOC_BRANCH26	_memcpy
    f15c:      	mov	x0, x20
    f160:      	mov	x1, x21
    f164:      	mov	x2, x22
    f168:      	mov	x3, x24
    f16c:      	mov	x4, x25
    f170:      	mov	x5, x26
    f174:      	bl	0xf174 <_coil.alloc.sized-reallocate+0x164>
		000000000000f174:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    f178:      	mov	x0, #0x1                ; =1
    f17c:      	b	0xf0a4 <_coil.alloc.sized-reallocate+0x94>
    f180:      	brk	#0
    f184:      	b	0xf180 <_coil.alloc.sized-reallocate+0x170>
    f188:      	brk	#0
    f18c:      	b	0xf188 <_coil.alloc.sized-reallocate+0x178>

000000000000f190 <_coil.alloc.reallocate__stogir.adjacency.Range>:
    f190:      	sub	sp, sp, #0x40
    f194:      	str	x29, [sp, #0x10]
    f198:      	str	x30, [sp, #0x18]
    f19c:      	add	x29, sp, #0x10
    f1a0:      	str	x19, [sp, #0x30]
    f1a4:      	str	x20, [sp, #0x38]
    f1a8:      	mov	x19, x8
    f1ac:      	mov	x20, x3
    f1b0:      	adrp	x4, 0xf000 <_coil.alloc.reallocate__stogir.schedule.Range+0x94>
		000000000000f1b0:  ARM64_RELOC_PAGE21	l_stogir.553
    f1b4:      	ldr	x4, [x4]
		000000000000f1b4:  ARM64_RELOC_PAGEOFF12	l_stogir.553
    f1b8:      	mov	x5, #0x10               ; =16
    f1bc:      	mov	x6, #0x8                ; =8
    f1c0:      	bl	0xf1c0 <_coil.alloc.reallocate__stogir.adjacency.Range+0x30>
		000000000000f1c0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f1c4:      	ubfx	x0, x0, #0, #32
    f1c8:      	lsr	x16, x0, #0
    f1cc:      	cmp	x16, #0x1
    f1d0:      	b.eq	0xf1ec <_coil.alloc.reallocate__stogir.adjacency.Range+0x5c>
    f1d4:      	b.lo	0xf1dc <_coil.alloc.reallocate__stogir.adjacency.Range+0x4c>
    f1d8:      	b	0xf1f0 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    f1dc:      	cmp	x16, #0x0
    f1e0:      	b.eq	0xf1e8 <_coil.alloc.reallocate__stogir.adjacency.Range+0x58>
    f1e4:      	b	0xf1f0 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    f1e8:      	b	0xf1f4 <_coil.alloc.reallocate__stogir.adjacency.Range+0x64>
    f1ec:      	b	0xf204 <_coil.alloc.reallocate__stogir.adjacency.Range+0x74>
    f1f0:      	b	0xf22c <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>
    f1f4:      	movz	x0, #0x0, lsl #48
    f1f8:      	movz	x1, #0x0, lsl #48
    f1fc:      	movz	x20, #0x0, lsl #48
    f200:      	b	0xf208 <_coil.alloc.reallocate__stogir.adjacency.Range+0x78>
    f204:      	mov	x0, #0x1                ; =1
    f208:      	str	x0, [x19]
    f20c:      	str	x1, [x19, #0x8]
    f210:      	str	x20, [x19, #0x10]
    f214:      	ldr	x19, [sp, #0x30]
    f218:      	ldr	x20, [sp, #0x38]
    f21c:      	ldr	x29, [sp, #0x10]
    f220:      	ldr	x30, [sp, #0x18]
    f224:      	add	sp, sp, #0x40
    f228:      	ret
    f22c:      	brk	#0
    f230:      	b	0xf22c <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>

000000000000f234 <_coil.alloc.sized-resize>:
    f234:      	sub	sp, sp, #0x130
    f238:      	str	x29, [sp, #0x10]
    f23c:      	str	x30, [sp, #0x18]
    f240:      	add	x29, sp, #0x10
    f244:      	str	x19, [sp, #0xf0]
    f248:      	str	x20, [sp, #0xf8]
    f24c:      	str	x21, [sp, #0x100]
    f250:      	str	x22, [sp, #0x108]
    f254:      	str	x23, [sp, #0x110]
    f258:      	str	x24, [sp, #0x118]
    f25c:      	str	x25, [sp, #0x120]
    f260:      	str	x26, [sp, #0x128]
    f264:      	add	x19, sp, #0x20
    f268:      	cmp	x3, #0x0
    f26c:      	b.ne	0xf2c8 <_coil.alloc.sized-resize+0x94>
    f270:      	mov	x3, x4
    f274:      	mov	x4, x5
    f278:      	mov	x5, x6
    f27c:      	bl	0xf27c <_coil.alloc.sized-resize+0x48>
		000000000000f27c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    f280:      	mov	x0, #0x1                ; =1
    f284:      	movz	x1, #0x0, lsl #48
    f288:      	str	x0, [x19]
    f28c:      	str	x1, [x19, #0x8]
    f290:      	ldr	x0, [sp, #0x20]
    f294:      	ldr	x1, [sp, #0x28]
    f298:      	ldr	x19, [sp, #0xf0]
    f29c:      	ldr	x20, [sp, #0xf8]
    f2a0:      	ldr	x21, [sp, #0x100]
    f2a4:      	ldr	x22, [sp, #0x108]
    f2a8:      	ldr	x23, [sp, #0x110]
    f2ac:      	ldr	x24, [sp, #0x118]
    f2b0:      	ldr	x25, [sp, #0x120]
    f2b4:      	ldr	x26, [sp, #0x128]
    f2b8:      	ldr	x29, [sp, #0x10]
    f2bc:      	ldr	x30, [sp, #0x18]
    f2c0:      	add	sp, sp, #0x130
    f2c4:      	ret
    f2c8:      	cmp	x2, #0x0
    f2cc:      	b.ne	0xf2e8 <_coil.alloc.sized-resize+0xb4>
    f2d0:      	mov	x1, x4
    f2d4:      	mov	x2, x5
    f2d8:      	mov	x4, x3
    f2dc:      	mov	x3, x6
    f2e0:      	bl	0xf2e0 <_coil.alloc.sized-resize+0xac>
		000000000000f2e0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    f2e4:      	b	0xf288 <_coil.alloc.sized-resize+0x54>
    f2e8:      	add	x8, sp, #0x30
    f2ec:      	mov	x20, x0
    f2f0:      	mov	x0, x4
    f2f4:      	mov	x21, x1
    f2f8:      	mov	x1, x5
    f2fc:      	mov	x22, x3
    f300:      	mov	x3, x2
    f304:      	mov	x2, x6
    f308:      	mov	x23, x4
    f30c:      	mov	x24, x5
    f310:      	mov	x25, x6
    f314:      	mov	w26, w7
    f318:      	bl	0xf318 <_coil.alloc.sized-resize+0xe4>
		000000000000f318:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f31c:      	add	x16, sp, #0x30
    f320:      	ldr	w0, [x16]
    f324:      	lsr	x16, x0, #0
    f328:      	cmp	x16, #0x1
    f32c:      	b.eq	0xf348 <_coil.alloc.sized-resize+0x114>
    f330:      	b.lo	0xf338 <_coil.alloc.sized-resize+0x104>
    f334:      	b	0xf34c <_coil.alloc.sized-resize+0x118>
    f338:      	cmp	x16, #0x0
    f33c:      	b.eq	0xf344 <_coil.alloc.sized-resize+0x110>
    f340:      	b	0xf34c <_coil.alloc.sized-resize+0x118>
    f344:      	b	0xf350 <_coil.alloc.sized-resize+0x11c>
    f348:      	b	0xf35c <_coil.alloc.sized-resize+0x128>
    f34c:      	b	0xf48c <_coil.alloc.sized-resize+0x258>
    f350:      	movz	x0, #0x0, lsl #48
    f354:      	movz	x1, #0x0, lsl #48
    f358:      	b	0xf2e4 <_coil.alloc.sized-resize+0xb0>
    f35c:      	add	x16, sp, #0x30
    f360:      	orr	x0, x16, xzr
    f364:      	add	x0, x0, #0x8
    f368:      	add	x16, sp, #0x30
    f36c:      	ldr	x1, [x16, #0x8]
    f370:      	add	x16, sp, #0x60
    f374:      	str	x1, [x16]
    f378:      	ldr	x1, [x0, #0x8]
    f37c:      	add	x16, sp, #0x60
    f380:      	str	x1, [x16, #0x8]
    f384:      	ldr	x1, [x0, #0x10]
    f388:      	add	x16, sp, #0x60
    f38c:      	str	x1, [x16, #0x10]
    f390:      	ldr	x0, [x0, #0x18]
    f394:      	add	x16, sp, #0x60
    f398:      	str	x0, [x16, #0x18]
    f39c:      	add	x8, sp, #0x80
    f3a0:      	mov	x0, x23
    f3a4:      	mov	x1, x24
    f3a8:      	mov	x2, x25
    f3ac:      	mov	x3, x22
    f3b0:      	bl	0xf3b0 <_coil.alloc.sized-resize+0x17c>
		000000000000f3b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f3b4:      	add	x16, sp, #0x80
    f3b8:      	ldr	w0, [x16]
    f3bc:      	lsr	x16, x0, #0
    f3c0:      	cmp	x16, #0x1
    f3c4:      	b.eq	0xf3e0 <_coil.alloc.sized-resize+0x1ac>
    f3c8:      	b.lo	0xf3d0 <_coil.alloc.sized-resize+0x19c>
    f3cc:      	b	0xf3e4 <_coil.alloc.sized-resize+0x1b0>
    f3d0:      	cmp	x16, #0x0
    f3d4:      	b.eq	0xf3dc <_coil.alloc.sized-resize+0x1a8>
    f3d8:      	b	0xf3e4 <_coil.alloc.sized-resize+0x1b0>
    f3dc:      	b	0xf3e8 <_coil.alloc.sized-resize+0x1b4>
    f3e0:      	b	0xf400 <_coil.alloc.sized-resize+0x1cc>
    f3e4:      	b	0xf494 <_coil.alloc.sized-resize+0x260>
    f3e8:      	movz	x0, #0x0, lsl #48
    f3ec:      	movz	x1, #0x0, lsl #48
    f3f0:      	b	0xf3fc <_coil.alloc.sized-resize+0x1c8>
    f3f4:      	movz	x0, #0x0, lsl #48
    f3f8:      	movz	x1, #0x0, lsl #48
    f3fc:      	b	0xf358 <_coil.alloc.sized-resize+0x124>
    f400:      	ubfx	x26, x26, #0, #8
    f404:      	add	x16, sp, #0x80
    f408:      	orr	x0, x16, xzr
    f40c:      	add	x0, x0, #0x8
    f410:      	add	x16, sp, #0x80
    f414:      	ldr	x1, [x16, #0x8]
    f418:      	add	x16, sp, #0xb0
    f41c:      	str	x1, [x16]
    f420:      	ldr	x1, [x0, #0x8]
    f424:      	add	x16, sp, #0xb0
    f428:      	str	x1, [x16, #0x8]
    f42c:      	ldr	x1, [x0, #0x10]
    f430:      	add	x16, sp, #0xb0
    f434:      	str	x1, [x16, #0x10]
    f438:      	ldr	x0, [x0, #0x18]
    f43c:      	add	x16, sp, #0xb0
    f440:      	str	x0, [x16, #0x18]
    f444:      	cmp	x26, #0x0
    f448:      	b.eq	0xf474 <_coil.alloc.sized-resize+0x240>
    f44c:      	mov	x0, x20
    f450:      	mov	x1, x21
    f454:      	add	x2, sp, #0x60
    f458:      	add	x3, sp, #0xb0
    f45c:      	bl	0xf45c <_coil.alloc.sized-resize+0x228>
		000000000000f45c:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-resize
    f460:      	cmp	x0, #0x0
    f464:      	b.eq	0xf3f4 <_coil.alloc.sized-resize+0x1c0>
    f468:      	orr	x1, x21, xzr
    f46c:      	mov	x0, #0x1                ; =1
    f470:      	b	0xf3fc <_coil.alloc.sized-resize+0x1c8>
    f474:      	mov	x0, x20
    f478:      	mov	x1, x21
    f47c:      	add	x2, sp, #0x60
    f480:      	add	x3, sp, #0xb0
    f484:      	bl	0xf484 <_coil.alloc.sized-resize+0x250>
		000000000000f484:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-remap
    f488:      	b	0xf3fc <_coil.alloc.sized-resize+0x1c8>
    f48c:      	brk	#0
    f490:      	b	0xf48c <_coil.alloc.sized-resize+0x258>
    f494:      	brk	#0
    f498:      	b	0xf494 <_coil.alloc.sized-resize+0x260>

000000000000f49c <_coil.alloc.sized-alloc>:
    f49c:      	sub	sp, sp, #0xa0
    f4a0:      	str	x29, [sp, #0x10]
    f4a4:      	str	x30, [sp, #0x18]
    f4a8:      	add	x29, sp, #0x10
    f4ac:      	str	x19, [sp, #0x90]
    f4b0:      	str	x20, [sp, #0x98]
    f4b4:      	add	x19, sp, #0x20
    f4b8:      	cmp	x4, #0x0
    f4bc:      	b.ne	0xf4f0 <_coil.alloc.sized-alloc+0x54>
    f4c0:      	mov	x0, #0x1                ; =1
    f4c4:      	movz	x1, #0x0, lsl #48
    f4c8:      	str	x0, [x19]
    f4cc:      	str	x1, [x19, #0x8]
    f4d0:      	ldr	x0, [sp, #0x20]
    f4d4:      	ldr	x1, [sp, #0x28]
    f4d8:      	ldr	x19, [sp, #0x90]
    f4dc:      	ldr	x20, [sp, #0x98]
    f4e0:      	ldr	x29, [sp, #0x10]
    f4e4:      	ldr	x30, [sp, #0x18]
    f4e8:      	add	sp, sp, #0xa0
    f4ec:      	ret
    f4f0:      	add	x8, sp, #0x30
    f4f4:      	mov	x20, x0
    f4f8:      	mov	x0, x1
    f4fc:      	mov	x1, x2
    f500:      	mov	x2, x3
    f504:      	mov	x3, x4
    f508:      	bl	0xf508 <_coil.alloc.sized-alloc+0x6c>
		000000000000f508:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f50c:      	add	x16, sp, #0x30
    f510:      	ldr	w0, [x16]
    f514:      	lsr	x16, x0, #0
    f518:      	cmp	x16, #0x1
    f51c:      	b.eq	0xf538 <_coil.alloc.sized-alloc+0x9c>
    f520:      	b.lo	0xf528 <_coil.alloc.sized-alloc+0x8c>
    f524:      	b	0xf53c <_coil.alloc.sized-alloc+0xa0>
    f528:      	cmp	x16, #0x0
    f52c:      	b.eq	0xf534 <_coil.alloc.sized-alloc+0x98>
    f530:      	b	0xf53c <_coil.alloc.sized-alloc+0xa0>
    f534:      	b	0xf540 <_coil.alloc.sized-alloc+0xa4>
    f538:      	b	0xf54c <_coil.alloc.sized-alloc+0xb0>
    f53c:      	b	0xf59c <_coil.alloc.sized-alloc+0x100>
    f540:      	movz	x0, #0x0, lsl #48
    f544:      	movz	x1, #0x0, lsl #48
    f548:      	b	0xf598 <_coil.alloc.sized-alloc+0xfc>
    f54c:      	add	x16, sp, #0x30
    f550:      	orr	x0, x16, xzr
    f554:      	add	x0, x0, #0x8
    f558:      	add	x16, sp, #0x30
    f55c:      	ldr	x1, [x16, #0x8]
    f560:      	add	x16, sp, #0x60
    f564:      	str	x1, [x16]
    f568:      	ldr	x1, [x0, #0x8]
    f56c:      	add	x16, sp, #0x60
    f570:      	str	x1, [x16, #0x8]
    f574:      	ldr	x1, [x0, #0x10]
    f578:      	add	x16, sp, #0x60
    f57c:      	str	x1, [x16, #0x10]
    f580:      	ldr	x0, [x0, #0x18]
    f584:      	add	x16, sp, #0x60
    f588:      	str	x0, [x16, #0x18]
    f58c:      	mov	x0, x20
    f590:      	add	x1, sp, #0x60
    f594:      	bl	0xf594 <_coil.alloc.sized-alloc+0xf8>
		000000000000f594:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-alloc
    f598:      	b	0xf4c8 <_coil.alloc.sized-alloc+0x2c>
    f59c:      	brk	#0
    f5a0:      	b	0xf59c <_coil.alloc.sized-alloc+0x100>

000000000000f5a4 <_coil.alloc.raw-resize>:
    f5a4:      	sub	sp, sp, #0x10
    f5a8:      	str	x29, [sp]
    f5ac:      	str	x30, [sp, #0x8]
    f5b0:      	mov	x29, sp
    f5b4:      	ldr	x4, [x2, #0x8]
    f5b8:      	cmp	x4, #0x0
    f5bc:      	b.le	0xf638 <_coil.alloc.raw-resize+0x94>
    f5c0:      	ldr	x4, [x2, #0x10]
    f5c4:      	cmp	x4, #0x0
    f5c8:      	b.le	0xf638 <_coil.alloc.raw-resize+0x94>
    f5cc:      	ldr	x4, [x2, #0x18]
    f5d0:      	cmp	x4, #0x0
    f5d4:      	b.le	0xf638 <_coil.alloc.raw-resize+0x94>
    f5d8:      	sub	x5, x4, #0x1
    f5dc:      	and	x4, x5, x4
    f5e0:      	cmp	x4, #0x0
    f5e4:      	b.ne	0xf638 <_coil.alloc.raw-resize+0x94>
    f5e8:      	ldr	x4, [x3, #0x8]
    f5ec:      	cmp	x4, #0x0
    f5f0:      	b.le	0xf638 <_coil.alloc.raw-resize+0x94>
    f5f4:      	ldr	x4, [x3, #0x10]
    f5f8:      	cmp	x4, #0x0
    f5fc:      	b.le	0xf638 <_coil.alloc.raw-resize+0x94>
    f600:      	ldr	x4, [x3, #0x18]
    f604:      	cmp	x4, #0x0
    f608:      	b.le	0xf638 <_coil.alloc.raw-resize+0x94>
    f60c:      	sub	x5, x4, #0x1
    f610:      	and	x4, x5, x4
    f614:      	cmp	x4, #0x0
    f618:      	b.ne	0xf638 <_coil.alloc.raw-resize+0x94>
    f61c:      	ldr	x4, [x0]
    f620:      	ldr	x0, [x0, #0x8]
    f624:      	ldr	x0, [x0, #0x8]
    f628:      	mov	x30, x0
    f62c:      	mov	x0, x4
    f630:      	blr	x30
    f634:      	b	0xf63c <_coil.alloc.raw-resize+0x98>
    f638:      	movz	x0, #0x0, lsl #48
    f63c:      	ldr	x29, [sp]
    f640:      	ldr	x30, [sp, #0x8]
    f644:      	add	sp, sp, #0x10
    f648:      	ret

000000000000f64c <_coil.alloc.raw-remap>:
    f64c:      	sub	sp, sp, #0x50
    f650:      	str	x29, [sp, #0x10]
    f654:      	str	x30, [sp, #0x18]
    f658:      	add	x29, sp, #0x10
    f65c:      	str	x19, [sp, #0x40]
    f660:      	add	x19, sp, #0x20
    f664:      	ldr	x4, [x2, #0x8]
    f668:      	cmp	x4, #0x0
    f66c:      	b.le	0xf6e8 <_coil.alloc.raw-remap+0x9c>
    f670:      	ldr	x4, [x2, #0x10]
    f674:      	cmp	x4, #0x0
    f678:      	b.le	0xf6e8 <_coil.alloc.raw-remap+0x9c>
    f67c:      	ldr	x4, [x2, #0x18]
    f680:      	cmp	x4, #0x0
    f684:      	b.le	0xf6e8 <_coil.alloc.raw-remap+0x9c>
    f688:      	sub	x5, x4, #0x1
    f68c:      	and	x4, x5, x4
    f690:      	cmp	x4, #0x0
    f694:      	b.ne	0xf6e8 <_coil.alloc.raw-remap+0x9c>
    f698:      	ldr	x4, [x3, #0x8]
    f69c:      	cmp	x4, #0x0
    f6a0:      	b.le	0xf6e8 <_coil.alloc.raw-remap+0x9c>
    f6a4:      	ldr	x4, [x3, #0x10]
    f6a8:      	cmp	x4, #0x0
    f6ac:      	b.le	0xf6e8 <_coil.alloc.raw-remap+0x9c>
    f6b0:      	ldr	x4, [x3, #0x18]
    f6b4:      	cmp	x4, #0x0
    f6b8:      	b.le	0xf6e8 <_coil.alloc.raw-remap+0x9c>
    f6bc:      	sub	x5, x4, #0x1
    f6c0:      	and	x4, x5, x4
    f6c4:      	cmp	x4, #0x0
    f6c8:      	b.ne	0xf6e8 <_coil.alloc.raw-remap+0x9c>
    f6cc:      	ldr	x4, [x0]
    f6d0:      	ldr	x0, [x0, #0x8]
    f6d4:      	ldr	x0, [x0, #0x10]
    f6d8:      	mov	x30, x0
    f6dc:      	mov	x0, x4
    f6e0:      	blr	x30
    f6e4:      	b	0xf6f0 <_coil.alloc.raw-remap+0xa4>
    f6e8:      	movz	x0, #0x0, lsl #48
    f6ec:      	movz	x1, #0x0, lsl #48
    f6f0:      	str	x0, [x19]
    f6f4:      	str	x1, [x19, #0x8]
    f6f8:      	ldr	x0, [sp, #0x20]
    f6fc:      	ldr	x1, [sp, #0x28]
    f700:      	ldr	x19, [sp, #0x40]
    f704:      	ldr	x29, [sp, #0x10]
    f708:      	ldr	x30, [sp, #0x18]
    f70c:      	add	sp, sp, #0x50
    f710:      	ret

000000000000f714 <_coil.alloc.raw-alloc>:
    f714:      	sub	sp, sp, #0x50
    f718:      	str	x29, [sp, #0x10]
    f71c:      	str	x30, [sp, #0x18]
    f720:      	add	x29, sp, #0x10
    f724:      	str	x19, [sp, #0x40]
    f728:      	add	x19, sp, #0x20
    f72c:      	ldr	x2, [x1, #0x8]
    f730:      	cmp	x2, #0x0
    f734:      	b.le	0xf77c <_coil.alloc.raw-alloc+0x68>
    f738:      	ldr	x2, [x1, #0x10]
    f73c:      	cmp	x2, #0x0
    f740:      	b.le	0xf77c <_coil.alloc.raw-alloc+0x68>
    f744:      	ldr	x2, [x1, #0x18]
    f748:      	cmp	x2, #0x0
    f74c:      	b.le	0xf77c <_coil.alloc.raw-alloc+0x68>
    f750:      	sub	x3, x2, #0x1
    f754:      	and	x2, x3, x2
    f758:      	cmp	x2, #0x0
    f75c:      	b.ne	0xf77c <_coil.alloc.raw-alloc+0x68>
    f760:      	ldr	x2, [x0]
    f764:      	ldr	x0, [x0, #0x8]
    f768:      	ldr	x0, [x0]
    f76c:      	mov	x30, x0
    f770:      	mov	x0, x2
    f774:      	blr	x30
    f778:      	b	0xf784 <_coil.alloc.raw-alloc+0x70>
    f77c:      	movz	x0, #0x0, lsl #48
    f780:      	movz	x1, #0x0, lsl #48
    f784:      	str	x0, [x19]
    f788:      	str	x1, [x19, #0x8]
    f78c:      	ldr	x0, [sp, #0x20]
    f790:      	ldr	x1, [sp, #0x28]
    f794:      	ldr	x19, [sp, #0x40]
    f798:      	ldr	x29, [sp, #0x10]
    f79c:      	ldr	x30, [sp, #0x18]
    f7a0:      	add	sp, sp, #0x50
    f7a4:      	ret
