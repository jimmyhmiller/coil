
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-bitcast-chains/build/bitcast-comparison/prepare-graph/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_prepare_graph>:
       0:      	sub	sp, sp, #0x2e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x2c0]
      14:      	str	x20, [sp, #0x2c8]
      18:      	str	x21, [sp, #0x2d0]
      1c:      	str	x22, [sp, #0x2d8]
      20:      	add	x16, sp, #0x10
      24:      	orr	x3, x16, xzr
      28:      	add	x16, sp, #0x10
      2c:      	str	w2, [x16]
      30:      	add	x16, sp, #0x20
      34:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000034:  ARM64_RELOC_PAGE21	l_stogir.388
      38:      	ldr	x17, [x17]
		0000000000000038:  ARM64_RELOC_PAGEOFF12	l_stogir.388
      3c:      	str	x17, [x16]
      40:      	add	x16, sp, #0x20
      44:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000044:  ARM64_RELOC_PAGE21	l_stogir.389
      48:      	ldr	x17, [x17]
		0000000000000048:  ARM64_RELOC_PAGEOFF12	l_stogir.389
      4c:      	str	x17, [x16, #0x8]
      50:      	add	x8, sp, #0x30
      54:      	mov	x2, x3
      58:      	add	x4, sp, #0x20
      5c:      	mov	x3, #0x1                ; =1
      60:      	bl	0x60 <_gap_prepare_graph+0x60>
		0000000000000060:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare
      64:      	add	x16, sp, #0x30
      68:      	ldr	w0, [x16]
      6c:      	lsr	x16, x0, #0
      70:      	cmp	x16, #0x1
      74:      	b.eq	0x90 <_gap_prepare_graph+0x90>
      78:      	b.lo	0x80 <_gap_prepare_graph+0x80>
      7c:      	b	0x94 <_gap_prepare_graph+0x94>
      80:      	cmp	x16, #0x0
      84:      	b.eq	0x8c <_gap_prepare_graph+0x8c>
      88:      	b	0x94 <_gap_prepare_graph+0x94>
      8c:      	b	0xa0 <_gap_prepare_graph+0xa0>
      90:      	b	0x98 <_gap_prepare_graph+0x98>
      94:      	b	0x550 <_gap_prepare_graph+0x550>
      98:      	movz	x19, #0x0, lsl #48
      9c:      	b	0x524 <_gap_prepare_graph+0x524>
      a0:      	add	x16, sp, #0x30
      a4:      	orr	x0, x16, xzr
      a8:      	add	x16, sp, #0x180
      ac:      	orr	x1, x16, xzr
      b0:      	add	x0, x0, #0x8
      b4:      	add	x19, x1, #0xa0
      b8:      	add	x20, x19, #0x28
      bc:      	mov	x1, x0
      c0:      	add	x0, sp, #0x180
      c4:      	mov	x2, #0x140              ; =320
      c8:      	bl	0xc8 <_gap_prepare_graph+0xc8>
		00000000000000c8:  ARM64_RELOC_BRANCH26	_memmove
      cc:      	ldr	x0, [x19, #0x28]
      d0:      	ldr	x1, [x20, #0x8]
      d4:      	movz	x19, #0x0, lsl #48
      d8:      	movz	x2, #0x0, lsl #48
      dc:      	b	0x120 <_gap_prepare_graph+0x120>
      e0:      	movz	w3, #0x0, lsl #16
      e4:      	movz	w4, #0x0, lsl #16
      e8:      	ubfx	x3, x3, #0, #32
      ec:      	lsr	x16, x3, #0
      f0:      	cmp	x16, #0x1
      f4:      	b.eq	0x110 <_gap_prepare_graph+0x110>
      f8:      	b.lo	0x100 <_gap_prepare_graph+0x100>
      fc:      	b	0x114 <_gap_prepare_graph+0x114>
     100:      	cmp	x16, #0x0
     104:      	b.eq	0x10c <_gap_prepare_graph+0x10c>
     108:      	b	0x114 <_gap_prepare_graph+0x114>
     10c:      	b	0x148 <_gap_prepare_graph+0x148>
     110:      	b	0x118 <_gap_prepare_graph+0x118>
     114:      	b	0x548 <_gap_prepare_graph+0x548>
     118:      	sxtw	x4, w4
     11c:      	add	x19, x4, x19
     120:      	cmp	x2, x1
     124:      	b.ge	0xe0 <_gap_prepare_graph+0xe0>
     128:      	add	x3, x2, #0x1
     12c:      	add	x2, x0, x2, lsl #2
     130:      	ldr	w2, [x2]
     134:      	movn	w17, #0x0, lsl #16
     138:      	and	w4, w2, w17
     13c:      	mov	x2, x3
     140:      	mov	w3, #0x1                ; =1
     144:      	b	0xe8 <_gap_prepare_graph+0xe8>
     148:      	b	0x15c <_gap_prepare_graph+0x15c>
     14c:      	nop
     150:      	sub	x0, x0, #0x1
     154:      	add	x16, sp, #0x180
     158:      	str	x0, [x16, #0x8]
     15c:      	add	x16, sp, #0x180
     160:      	ldr	x0, [x16, #0x8]
     164:      	cmp	x0, #0x0
     168:      	b.ne	0x150 <_gap_prepare_graph+0x150>
     16c:      	add	x16, sp, #0x180
     170:      	orr	x0, x16, xzr
     174:      	add	x16, sp, #0x180
     178:      	ldr	x1, [x16, #0x10]
     17c:      	cmp	x1, #0x0
     180:      	b.le	0x1b0 <_gap_prepare_graph+0x1b0>
     184:      	add	x0, x0, #0x18
     188:      	add	x16, sp, #0x180
     18c:      	ldr	x2, [x16]
     190:      	fmov	d31, x1
     194:      	mov	x1, x2
     198:      	fmov	x2, d31
     19c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000019c:  ARM64_RELOC_PAGE21	l_stogir.390
     1a0:      	ldr	x3, [x3]
		00000000000001a0:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     1a4:      	mov	x4, #0x4                ; =4
     1a8:      	mov	x5, #0x4                ; =4
     1ac:      	bl	0x1ac <_gap_prepare_graph+0x1ac>
		00000000000001ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     1b0:      	add	x16, sp, #0x180
     1b4:      	orr	x20, x16, xzr
     1b8:      	add	x21, x20, #0x28
     1bc:      	add	x16, sp, #0x180
     1c0:      	movz	x17, #0x0, lsl #48
     1c4:      	str	x17, [x16]
     1c8:      	add	x16, sp, #0x180
     1cc:      	movz	x17, #0x0, lsl #48
     1d0:      	str	x17, [x16, #0x8]
     1d4:      	add	x16, sp, #0x180
     1d8:      	movz	x17, #0x0, lsl #48
     1dc:      	str	x17, [x16, #0x10]
     1e0:      	b	0x1f0 <_gap_prepare_graph+0x1f0>
     1e4:      	nop
     1e8:      	sub	x0, x0, #0x1
     1ec:      	str	x0, [x21, #0x8]
     1f0:      	ldr	x0, [x21, #0x8]
     1f4:      	cmp	x0, #0x0
     1f8:      	b.ne	0x1e8 <_gap_prepare_graph+0x1e8>
     1fc:      	ldr	x0, [x21, #0x10]
     200:      	cmp	x0, #0x0
     204:      	b.le	0x238 <_gap_prepare_graph+0x238>
     208:      	add	x1, x21, #0x18
     20c:      	add	x16, sp, #0x180
     210:      	ldr	x2, [x16, #0x28]
     214:      	fmov	d31, x0
     218:      	mov	x0, x1
     21c:      	mov	x1, x2
     220:      	fmov	x2, d31
     224:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000224:  ARM64_RELOC_PAGE21	l_stogir.390
     228:      	ldr	x3, [x3]
		0000000000000228:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     22c:      	mov	x4, #0x4                ; =4
     230:      	mov	x5, #0x4                ; =4
     234:      	bl	0x234 <_gap_prepare_graph+0x234>
		0000000000000234:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     238:      	add	x20, x20, #0x50
     23c:      	add	x16, sp, #0x180
     240:      	movz	x17, #0x0, lsl #48
     244:      	str	x17, [x16, #0x28]
     248:      	movz	x17, #0x0, lsl #48
     24c:      	str	x17, [x21, #0x8]
     250:      	movz	x17, #0x0, lsl #48
     254:      	str	x17, [x21, #0x10]
     258:      	b	0x268 <_gap_prepare_graph+0x268>
     25c:      	nop
     260:      	sub	x0, x0, #0x1
     264:      	str	x0, [x20, #0x8]
     268:      	ldr	x0, [x20, #0x8]
     26c:      	cmp	x0, #0x0
     270:      	b.ne	0x260 <_gap_prepare_graph+0x260>
     274:      	ldr	x0, [x20, #0x10]
     278:      	cmp	x0, #0x0
     27c:      	b.le	0x2b0 <_gap_prepare_graph+0x2b0>
     280:      	add	x1, x20, #0x18
     284:      	add	x16, sp, #0x180
     288:      	ldr	x2, [x16, #0x50]
     28c:      	fmov	d31, x0
     290:      	mov	x0, x1
     294:      	mov	x1, x2
     298:      	fmov	x2, d31
     29c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000029c:  ARM64_RELOC_PAGE21	l_stogir.391
     2a0:      	ldr	x3, [x3]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	l_stogir.391
     2a4:      	mov	x4, #0x10               ; =16
     2a8:      	mov	x5, #0x4                ; =4
     2ac:      	bl	0x2ac <_gap_prepare_graph+0x2ac>
		00000000000002ac:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     2b0:      	add	x16, sp, #0x180
     2b4:      	orr	x21, x16, xzr
     2b8:      	add	x22, x21, #0x78
     2bc:      	add	x16, sp, #0x180
     2c0:      	movz	x17, #0x0, lsl #48
     2c4:      	str	x17, [x16, #0x50]
     2c8:      	movz	x17, #0x0, lsl #48
     2cc:      	str	x17, [x20, #0x8]
     2d0:      	movz	x17, #0x0, lsl #48
     2d4:      	str	x17, [x20, #0x10]
     2d8:      	b	0x2e8 <_gap_prepare_graph+0x2e8>
     2dc:      	nop
     2e0:      	sub	x0, x0, #0x1
     2e4:      	str	x0, [x22, #0x8]
     2e8:      	ldr	x0, [x22, #0x8]
     2ec:      	cmp	x0, #0x0
     2f0:      	b.ne	0x2e0 <_gap_prepare_graph+0x2e0>
     2f4:      	ldr	x0, [x22, #0x10]
     2f8:      	cmp	x0, #0x0
     2fc:      	b.le	0x330 <_gap_prepare_graph+0x330>
     300:      	add	x1, x22, #0x18
     304:      	add	x16, sp, #0x180
     308:      	ldr	x2, [x16, #0x78]
     30c:      	fmov	d31, x0
     310:      	mov	x0, x1
     314:      	mov	x1, x2
     318:      	fmov	x2, d31
     31c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000031c:  ARM64_RELOC_PAGE21	l_stogir.390
     320:      	ldr	x3, [x3]
		0000000000000320:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     324:      	mov	x4, #0x4                ; =4
     328:      	mov	x5, #0x4                ; =4
     32c:      	bl	0x32c <_gap_prepare_graph+0x32c>
		000000000000032c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     330:      	add	x20, x21, #0xf0
     334:      	add	x16, sp, #0x180
     338:      	movz	x17, #0x0, lsl #48
     33c:      	str	x17, [x16, #0x78]
     340:      	movz	x17, #0x0, lsl #48
     344:      	str	x17, [x22, #0x8]
     348:      	movz	x17, #0x0, lsl #48
     34c:      	str	x17, [x22, #0x10]
     350:      	b	0x360 <_gap_prepare_graph+0x360>
     354:      	nop
     358:      	sub	x0, x0, #0x1
     35c:      	str	x0, [x20, #0x8]
     360:      	ldr	x0, [x20, #0x8]
     364:      	cmp	x0, #0x0
     368:      	b.ne	0x358 <_gap_prepare_graph+0x358>
     36c:      	ldr	x0, [x20, #0x10]
     370:      	cmp	x0, #0x0
     374:      	b.le	0x3a8 <_gap_prepare_graph+0x3a8>
     378:      	add	x1, x20, #0x18
     37c:      	add	x16, sp, #0x180
     380:      	ldr	x2, [x16, #0xf0]
     384:      	fmov	d31, x0
     388:      	mov	x0, x1
     38c:      	mov	x1, x2
     390:      	fmov	x2, d31
     394:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000394:  ARM64_RELOC_PAGE21	l_stogir.390
     398:      	ldr	x3, [x3]
		0000000000000398:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     39c:      	mov	x4, #0x4                ; =4
     3a0:      	mov	x5, #0x4                ; =4
     3a4:      	bl	0x3a4 <_gap_prepare_graph+0x3a4>
		00000000000003a4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     3a8:      	add	x22, x21, #0x118
     3ac:      	add	x16, sp, #0x180
     3b0:      	movz	x17, #0x0, lsl #48
     3b4:      	str	x17, [x16, #0xf0]
     3b8:      	movz	x17, #0x0, lsl #48
     3bc:      	str	x17, [x20, #0x8]
     3c0:      	movz	x17, #0x0, lsl #48
     3c4:      	str	x17, [x20, #0x10]
     3c8:      	b	0x3d8 <_gap_prepare_graph+0x3d8>
     3cc:      	nop
     3d0:      	sub	x0, x0, #0x1
     3d4:      	str	x0, [x22, #0x8]
     3d8:      	ldr	x0, [x22, #0x8]
     3dc:      	cmp	x0, #0x0
     3e0:      	b.ne	0x3d0 <_gap_prepare_graph+0x3d0>
     3e4:      	ldr	x0, [x22, #0x10]
     3e8:      	cmp	x0, #0x0
     3ec:      	b.le	0x420 <_gap_prepare_graph+0x420>
     3f0:      	add	x1, x22, #0x18
     3f4:      	add	x16, sp, #0x180
     3f8:      	ldr	x2, [x16, #0x118]
     3fc:      	fmov	d31, x0
     400:      	mov	x0, x1
     404:      	mov	x1, x2
     408:      	fmov	x2, d31
     40c:      	adrp	x3, 0x0 <_gap_prepare_graph>
		000000000000040c:  ARM64_RELOC_PAGE21	l_stogir.390
     410:      	ldr	x3, [x3]
		0000000000000410:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     414:      	mov	x4, #0x4                ; =4
     418:      	mov	x5, #0x4                ; =4
     41c:      	bl	0x41c <_gap_prepare_graph+0x41c>
		000000000000041c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     420:      	add	x20, x21, #0xa0
     424:      	add	x16, sp, #0x180
     428:      	movz	x17, #0x0, lsl #48
     42c:      	str	x17, [x16, #0x118]
     430:      	movz	x17, #0x0, lsl #48
     434:      	str	x17, [x22, #0x8]
     438:      	movz	x17, #0x0, lsl #48
     43c:      	str	x17, [x22, #0x10]
     440:      	b	0x450 <_gap_prepare_graph+0x450>
     444:      	nop
     448:      	sub	x0, x0, #0x1
     44c:      	str	x0, [x20, #0x8]
     450:      	ldr	x0, [x20, #0x8]
     454:      	cmp	x0, #0x0
     458:      	b.ne	0x448 <_gap_prepare_graph+0x448>
     45c:      	ldr	x0, [x20, #0x10]
     460:      	cmp	x0, #0x0
     464:      	b.le	0x498 <_gap_prepare_graph+0x498>
     468:      	add	x1, x20, #0x18
     46c:      	add	x16, sp, #0x180
     470:      	ldr	x2, [x16, #0xa0]
     474:      	fmov	d31, x0
     478:      	mov	x0, x1
     47c:      	mov	x1, x2
     480:      	fmov	x2, d31
     484:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000484:  ARM64_RELOC_PAGE21	l_stogir.392
     488:      	ldr	x3, [x3]
		0000000000000488:  ARM64_RELOC_PAGEOFF12	l_stogir.392
     48c:      	mov	x4, #0x10               ; =16
     490:      	mov	x5, #0x8                ; =8
     494:      	bl	0x494 <_gap_prepare_graph+0x494>
		0000000000000494:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     498:      	add	x21, x20, #0x28
     49c:      	add	x16, sp, #0x180
     4a0:      	movz	x17, #0x0, lsl #48
     4a4:      	str	x17, [x16, #0xa0]
     4a8:      	movz	x17, #0x0, lsl #48
     4ac:      	str	x17, [x20, #0x8]
     4b0:      	movz	x17, #0x0, lsl #48
     4b4:      	str	x17, [x20, #0x10]
     4b8:      	b	0x4c8 <_gap_prepare_graph+0x4c8>
     4bc:      	nop
     4c0:      	sub	x0, x0, #0x1
     4c4:      	str	x0, [x21, #0x8]
     4c8:      	ldr	x0, [x21, #0x8]
     4cc:      	cmp	x0, #0x0
     4d0:      	b.ne	0x4c0 <_gap_prepare_graph+0x4c0>
     4d4:      	ldr	x0, [x21, #0x10]
     4d8:      	cmp	x0, #0x0
     4dc:      	b.le	0x50c <_gap_prepare_graph+0x50c>
     4e0:      	add	x1, x21, #0x18
     4e4:      	ldr	x2, [x20, #0x28]
     4e8:      	fmov	d31, x0
     4ec:      	mov	x0, x1
     4f0:      	mov	x1, x2
     4f4:      	fmov	x2, d31
     4f8:      	adrp	x3, 0x0 <_gap_prepare_graph>
		00000000000004f8:  ARM64_RELOC_PAGE21	l_stogir.390
     4fc:      	ldr	x3, [x3]
		00000000000004fc:  ARM64_RELOC_PAGEOFF12	l_stogir.390
     500:      	mov	x4, #0x4                ; =4
     504:      	mov	x5, #0x4                ; =4
     508:      	bl	0x508 <_gap_prepare_graph+0x508>
		0000000000000508:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
     50c:      	movz	x17, #0x0, lsl #48
     510:      	str	x17, [x20, #0x28]
     514:      	movz	x17, #0x0, lsl #48
     518:      	str	x17, [x21, #0x8]
     51c:      	movz	x17, #0x0, lsl #48
     520:      	str	x17, [x21, #0x10]
     524:      	mov	x0, x19
     528:      	ldr	x19, [sp, #0x2c0]
     52c:      	ldr	x20, [sp, #0x2c8]
     530:      	ldr	x21, [sp, #0x2d0]
     534:      	ldr	x22, [sp, #0x2d8]
     538:      	ldr	x29, [sp]
     53c:      	ldr	x30, [sp, #0x8]
     540:      	add	sp, sp, #0x2e0
     544:      	ret
     548:      	brk	#0
     54c:      	b	0x548 <_gap_prepare_graph+0x548>
     550:      	brk	#0
     554:      	b	0x550 <_gap_prepare_graph+0x550>

0000000000000558 <_stogir.pipeline.prepare>:
     558:      	sub	sp, sp, #0x310
     55c:      	str	x29, [sp]
     560:      	str	x30, [sp, #0x8]
     564:      	mov	x29, sp
     568:      	str	x19, [sp, #0x2d0]
     56c:      	str	x20, [sp, #0x2d8]
     570:      	str	x21, [sp, #0x2e0]
     574:      	str	x22, [sp, #0x2e8]
     578:      	str	x23, [sp, #0x2f0]
     57c:      	str	x24, [sp, #0x2f8]
     580:      	str	x25, [sp, #0x300]
     584:      	mov	x19, x8
     588:      	add	x8, sp, #0x10
     58c:      	mov	x20, x0
     590:      	mov	w21, w1
     594:      	mov	x22, x2
     598:      	mov	x23, x3
     59c:      	mov	x24, x4
     5a0:      	bl	0x5a0 <_stogir.pipeline.prepare+0x48>
		00000000000005a0:  ARM64_RELOC_BRANCH26	_stogir.pipeline.validate-input
     5a4:      	add	x16, sp, #0x10
     5a8:      	ldr	w0, [x16]
     5ac:      	lsr	x16, x0, #0
     5b0:      	cmp	x16, #0x1
     5b4:      	b.eq	0x5d0 <_stogir.pipeline.prepare+0x78>
     5b8:      	b.lo	0x5c0 <_stogir.pipeline.prepare+0x68>
     5bc:      	b	0x5d4 <_stogir.pipeline.prepare+0x7c>
     5c0:      	cmp	x16, #0x0
     5c4:      	b.eq	0x5cc <_stogir.pipeline.prepare+0x74>
     5c8:      	b	0x5d4 <_stogir.pipeline.prepare+0x7c>
     5cc:      	b	0x618 <_stogir.pipeline.prepare+0xc0>
     5d0:      	b	0x5d8 <_stogir.pipeline.prepare+0x80>
     5d4:      	b	0x678 <_stogir.pipeline.prepare+0x120>
     5d8:      	add	x16, sp, #0x10
     5dc:      	orr	x0, x16, xzr
     5e0:      	add	x16, sp, #0x30
     5e4:      	orr	x25, x16, xzr
     5e8:      	add	x0, x0, #0x8
     5ec:      	add	x1, x25, #0x8
     5f0:      	add	x16, sp, #0x10
     5f4:      	ldr	x2, [x16, #0x8]
     5f8:      	ldr	x0, [x0, #0x8]
     5fc:      	add	x16, sp, #0x30
     600:      	mov	w17, #0x1               ; =1
     604:      	str	w17, [x16]
     608:      	add	x16, sp, #0x30
     60c:      	str	x2, [x16, #0x8]
     610:      	str	x0, [x1, #0x8]
     614:      	b	0x63c <_stogir.pipeline.prepare+0xe4>
     618:      	add	x16, sp, #0x180
     61c:      	orr	x25, x16, xzr
     620:      	add	x8, sp, #0x180
     624:      	mov	x0, x20
     628:      	mov	w1, w21
     62c:      	mov	x2, x22
     630:      	mov	x3, x23
     634:      	mov	x4, x24
     638:      	bl	0x638 <_stogir.pipeline.prepare+0xe0>
		0000000000000638:  ARM64_RELOC_BRANCH26	_stogir.pipeline.prepare-checked
     63c:      	mov	x0, x19
     640:      	mov	x1, x25
     644:      	mov	x2, #0x148              ; =328
     648:      	bl	0x648 <_stogir.pipeline.prepare+0xf0>
		0000000000000648:  ARM64_RELOC_BRANCH26	_memmove
     64c:      	ldr	x19, [sp, #0x2d0]
     650:      	ldr	x20, [sp, #0x2d8]
     654:      	ldr	x21, [sp, #0x2e0]
     658:      	ldr	x22, [sp, #0x2e8]
     65c:      	ldr	x23, [sp, #0x2f0]
     660:      	ldr	x24, [sp, #0x2f8]
     664:      	ldr	x25, [sp, #0x300]
     668:      	ldr	x29, [sp]
     66c:      	ldr	x30, [sp, #0x8]
     670:      	add	sp, sp, #0x310
     674:      	ret
     678:      	brk	#0
     67c:      	b	0x678 <_stogir.pipeline.prepare+0x120>

0000000000000680 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32>:
     680:      	ldr	x1, [x0]
     684:      	ldr	x0, [x0, #0x8]
     688:      	str	x1, [x8]
     68c:      	str	x0, [x8, #0x8]
     690:      	movz	x17, #0x0, lsl #48
     694:      	str	x17, [x8, #0x10]
     698:      	ret

000000000000069c <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
     69c:      	sub	sp, sp, #0x10
     6a0:      	mov	x1, sp
     6a4:      	ldr	x2, [x0, #0x10]
     6a8:      	ldr	x3, [x0]
     6ac:      	ldr	x4, [x0, #0x8]
     6b0:      	cmp	x2, x4
     6b4:      	b.ge	0x6d8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x3c>
     6b8:      	add	x4, x2, #0x1
     6bc:      	add	x2, x3, x2, lsl #2
     6c0:      	str	x4, [x0, #0x10]
     6c4:      	ldr	w0, [x2]
     6c8:      	sxtw	x0, w0
     6cc:      	and	x0, x0, #0xffffffff
     6d0:      	mov	x2, #0x1                ; =1
     6d4:      	b	0x6e0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
     6d8:      	movz	x2, #0x0, lsl #48
     6dc:      	movz	x0, #0x0, lsl #48
     6e0:      	str	x2, [x1]
     6e4:      	str	x0, [x1, #0x8]
     6e8:      	ldr	x0, [sp]
     6ec:      	ldr	x1, [sp, #0x8]
     6f0:      	add	sp, sp, #0x10
     6f4:      	ret

00000000000006f8 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate>:
     6f8:      	sub	sp, sp, #0x40
     6fc:      	str	x29, [sp]
     700:      	str	x30, [sp, #0x8]
     704:      	mov	x29, sp
     708:      	str	x19, [sp, #0x20]
     70c:      	str	x20, [sp, #0x28]
     710:      	str	x21, [sp, #0x30]
     714:      	add	x19, x29, #0x10
     718:      	mov	x20, sp
     71c:      	sub	sp, sp, #0x10
     720:      	mov	x21, sp
     724:      	ldr	x0, [x1, #0x18]
     728:      	ldr	x1, [x1, #0x10]
     72c:      	cmp	x0, #0x10
     730:      	b.gt	0x750 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x58>
     734:      	mov	x0, x1
     738:      	bl	0x738 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x40>
		0000000000000738:  ARM64_RELOC_BRANCH26	_malloc
     73c:      	cmp	x0, #0x0
     740:      	b.ne	0x780 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x88>
     744:      	movz	x1, #0x0, lsl #48
     748:      	movz	x0, #0x0, lsl #48
     74c:      	b	0x784 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x8c>
     750:      	movz	x17, #0x0, lsl #48
     754:      	str	x17, [x21]
     758:      	mov	x2, x1
     75c:      	mov	x1, x0
     760:      	mov	x0, x21
     764:      	bl	0x764 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x6c>
		0000000000000764:  ARM64_RELOC_BRANCH26	_posix_memalign
     768:      	sxtw	x0, w0
     76c:      	cmp	x0, #0x0
     770:      	b.ne	0x788 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x90>
     774:      	ldr	x0, [x21]
     778:      	mov	x1, #0x1                ; =1
     77c:      	b	0x790 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     780:      	mov	x1, #0x1                ; =1
     784:      	b	0x790 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$allocate+0x98>
     788:      	movz	x1, #0x0, lsl #48
     78c:      	movz	x0, #0x0, lsl #48
     790:      	mov	sp, x20
     794:      	str	x1, [x19]
     798:      	str	x0, [x19, #0x8]
     79c:      	ldr	x0, [x29, #0x10]
     7a0:      	ldr	x1, [x29, #0x18]
     7a4:      	sub	sp, x29, #0x0
     7a8:      	ldr	x19, [sp, #0x20]
     7ac:      	ldr	x20, [sp, #0x28]
     7b0:      	ldr	x21, [sp, #0x30]
     7b4:      	ldr	x29, [sp]
     7b8:      	ldr	x30, [sp, #0x8]
     7bc:      	add	sp, sp, #0x40
     7c0:      	ret

00000000000007c4 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$resize>:
     7c4:      	ldr	x0, [x3, #0x10]
     7c8:      	ldr	x1, [x2, #0x10]
     7cc:      	cmp	x0, x1
     7d0:      	cset	w0, le
     7d4:      	ubfx	x0, x0, #0, #8
     7d8:      	ret

00000000000007dc <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap>:
     7dc:      	sub	sp, sp, #0x30
     7e0:      	str	x29, [sp]
     7e4:      	str	x30, [sp, #0x8]
     7e8:      	mov	x29, sp
     7ec:      	str	x19, [sp, #0x20]
     7f0:      	add	x19, sp, #0x10
     7f4:      	ldr	x0, [x3, #0x18]
     7f8:      	cmp	x0, #0x10
     7fc:      	b.le	0x834 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x58>
     800:      	movz	x1, #0x0, lsl #48
     804:      	movz	x0, #0x0, lsl #48
     808:      	b	0x810 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x34>
     80c:      	mov	x1, #0x1                ; =1
     810:      	str	x1, [x19]
     814:      	str	x0, [x19, #0x8]
     818:      	ldr	x0, [sp, #0x10]
     81c:      	ldr	x1, [sp, #0x18]
     820:      	ldr	x19, [sp, #0x20]
     824:      	ldr	x29, [sp]
     828:      	ldr	x30, [sp, #0x8]
     82c:      	add	sp, sp, #0x30
     830:      	ret
     834:      	ldr	x0, [x3, #0x10]
     838:      	fmov	d31, x0
     83c:      	mov	x0, x1
     840:      	fmov	x1, d31
     844:      	bl	0x844 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x68>
		0000000000000844:  ARM64_RELOC_BRANCH26	_realloc
     848:      	cmp	x0, #0x0
     84c:      	b.ne	0x80c <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x30>
     850:      	movz	x1, #0x0, lsl #48
     854:      	movz	x0, #0x0, lsl #48
     858:      	b	0x810 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$remap+0x34>

000000000000085c <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate>:
     85c:      	sub	sp, sp, #0x10
     860:      	str	x29, [sp]
     864:      	str	x30, [sp, #0x8]
     868:      	mov	x29, sp
     86c:      	mov	x0, x1
     870:      	bl	0x870 <_coil.alloc.Allocator$coil.alloc.MallocAllocator$deallocate+0x14>
		0000000000000870:  ARM64_RELOC_BRANCH26	_free
     874:      	movz	x0, #0x0, lsl #48
     878:      	ldr	x29, [sp]
     87c:      	ldr	x30, [sp, #0x8]
     880:      	add	sp, sp, #0x10
     884:      	ret

0000000000000888 <_stogir.pipeline.validate-input>:
     888:      	sub	sp, sp, #0x40
     88c:      	str	x29, [sp]
     890:      	str	x30, [sp, #0x8]
     894:      	mov	x29, sp
     898:      	str	x19, [sp, #0x30]
     89c:      	mov	x19, x8
     8a0:      	add	x8, sp, #0x10
     8a4:      	bl	0x8a4 <_stogir.pipeline.validate-input+0x1c>
		00000000000008a4:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input
     8a8:      	add	x16, sp, #0x10
     8ac:      	ldr	x0, [x16]
     8b0:      	str	x0, [x19]
     8b4:      	add	x16, sp, #0x10
     8b8:      	ldr	x0, [x16, #0x8]
     8bc:      	str	x0, [x19, #0x8]
     8c0:      	add	x16, sp, #0x10
     8c4:      	ldr	x0, [x16, #0x10]
     8c8:      	str	x0, [x19, #0x10]
     8cc:      	ldr	x19, [sp, #0x30]
     8d0:      	ldr	x29, [sp]
     8d4:      	ldr	x30, [sp, #0x8]
     8d8:      	add	sp, sp, #0x40
     8dc:      	ret

00000000000008e0 <_stogir.pipeline.prepare-checked>:
     8e0:      	sub	sp, sp, #0xfb0
     8e4:      	str	x29, [sp]
     8e8:      	str	x30, [sp, #0x8]
     8ec:      	mov	x29, sp
     8f0:      	str	x19, [sp, #0xf60]
     8f4:      	str	x20, [sp, #0xf68]
     8f8:      	str	x21, [sp, #0xf70]
     8fc:      	str	x22, [sp, #0xf78]
     900:      	str	x23, [sp, #0xf80]
     904:      	str	x24, [sp, #0xf88]
     908:      	str	x25, [sp, #0xf90]
     90c:      	str	x26, [sp, #0xf98]
     910:      	str	x27, [sp, #0xfa0]
     914:      	str	x28, [sp, #0xfa8]
     918:      	sxtw	x5, w1
     91c:      	cmp	x5, #0x0
     920:      	b.gt	0x9a0 <_stogir.pipeline.prepare-checked+0xc0>
     924:      	str	x8, [sp, #0xed8]
     928:      	add	x16, sp, #0x10
     92c:      	orr	x19, x16, xzr
     930:      	add	x16, sp, #0x10
     934:      	mov	w17, #0x1               ; =1
     938:      	str	w17, [x16]
     93c:      	add	x0, x19, #0x8
     940:      	add	x16, sp, #0x10
     944:      	adrp	x17, 0x0 <_gap_prepare_graph>
		0000000000000944:  ARM64_RELOC_PAGE21	l_stogir.393
     948:      	ldr	x17, [x17]
		0000000000000948:  ARM64_RELOC_PAGEOFF12	l_stogir.393
     94c:      	str	x17, [x16, #0x8]
     950:      	mov	x17, #0x17              ; =23
     954:      	str	x17, [x0, #0x8]
     958:      	ldr	x0, [sp, #0xed8]
     95c:      	mov	x1, x19
     960:      	mov	x2, #0x148              ; =328
     964:      	bl	0x964 <_stogir.pipeline.prepare-checked+0x84>
		0000000000000964:  ARM64_RELOC_BRANCH26	_memmove
     968:      	ldr	x19, [sp, #0xf60]
     96c:      	ldr	x20, [sp, #0xf68]
     970:      	ldr	x21, [sp, #0xf70]
     974:      	ldr	x22, [sp, #0xf78]
     978:      	ldr	x23, [sp, #0xf80]
     97c:      	ldr	x24, [sp, #0xf88]
     980:      	ldr	x25, [sp, #0xf90]
     984:      	ldr	x26, [sp, #0xf98]
     988:      	ldr	x27, [sp, #0xfa0]
     98c:      	ldr	x28, [sp, #0xfa8]
     990:      	ldr	x29, [sp]
     994:      	ldr	x30, [sp, #0x8]
     998:      	add	sp, sp, #0xfb0
     99c:      	ret
     9a0:      	mov	x19, x8
     9a4:      	mov	x20, x0
     9a8:      	mov	w21, w1
     9ac:      	mov	x22, x2
     9b0:      	mov	x23, x3
     9b4:      	mov	x24, x4
     9b8:      	bl	0x9b8 <_stogir.pipeline.prepare-checked+0xd8>
		00000000000009b8:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
     9bc:      	cmp	x0, #0x0
     9c0:      	b.eq	0x1c40 <_stogir.pipeline.prepare-checked+0x1360>
     9c4:      	add	x16, sp, #0x160
     9c8:      	orr	x25, x16, xzr
     9cc:      	add	x8, sp, #0x160
     9d0:      	mov	x0, x20
     9d4:      	mov	x1, x24
     9d8:      	bl	0x9d8 <_stogir.pipeline.prepare-checked+0xf8>
		00000000000009d8:  ARM64_RELOC_BRANCH26	_stogir.cfg.build
     9dc:      	add	x16, sp, #0x160
     9e0:      	ldr	w0, [x16]
     9e4:      	lsr	x16, x0, #0
     9e8:      	cmp	x16, #0x1
     9ec:      	b.eq	0xa08 <_stogir.pipeline.prepare-checked+0x128>
     9f0:      	b.lo	0x9f8 <_stogir.pipeline.prepare-checked+0x118>
     9f4:      	b	0xa0c <_stogir.pipeline.prepare-checked+0x12c>
     9f8:      	cmp	x16, #0x0
     9fc:      	b.eq	0xa04 <_stogir.pipeline.prepare-checked+0x124>
     a00:      	b	0xa0c <_stogir.pipeline.prepare-checked+0x12c>
     a04:      	b	0xa50 <_stogir.pipeline.prepare-checked+0x170>
     a08:      	b	0xa10 <_stogir.pipeline.prepare-checked+0x130>
     a0c:      	b	0x1908 <_stogir.pipeline.prepare-checked+0x1028>
     a10:      	add	x16, sp, #0x1e0
     a14:      	orr	x20, x16, xzr
     a18:      	add	x0, x25, #0x8
     a1c:      	add	x1, x20, #0x8
     a20:      	add	x16, sp, #0x160
     a24:      	ldr	x2, [x16, #0x8]
     a28:      	ldr	x0, [x0, #0x8]
     a2c:      	add	x16, sp, #0x1e0
     a30:      	mov	w17, #0x1               ; =1
     a34:      	str	w17, [x16]
     a38:      	add	x16, sp, #0x1e0
     a3c:      	str	x2, [x16, #0x8]
     a40:      	str	x0, [x1, #0x8]
     a44:      	str	x19, [sp, #0xed8]
     a48:      	mov	x19, x20
     a4c:      	b	0x958 <_stogir.pipeline.prepare-checked+0x78>
     a50:      	add	x16, sp, #0x760
     a54:      	orr	x26, x16, xzr
     a58:      	add	x0, x25, #0x8
     a5c:      	add	x16, sp, #0x160
     a60:      	ldr	x1, [x16, #0x8]
     a64:      	ldr	x2, [x0, #0x8]
     a68:      	ldr	x3, [x0, #0x10]
     a6c:      	ldr	x4, [x0, #0x18]
     a70:      	ldr	x5, [x0, #0x20]
     a74:      	ldr	x6, [x0, #0x28]
     a78:      	ldr	x7, [x0, #0x30]
     a7c:      	ldr	x8, [x0, #0x38]
     a80:      	ldr	x9, [x0, #0x40]
     a84:      	ldr	x10, [x0, #0x48]
     a88:      	ldr	x11, [x0, #0x50]
     a8c:      	ldr	x12, [x0, #0x58]
     a90:      	ldr	x13, [x0, #0x60]
     a94:      	ldr	x14, [x0, #0x68]
     a98:      	ldr	x0, [x0, #0x70]
     a9c:      	add	x16, sp, #0x330
     aa0:      	str	x1, [x16]
     aa4:      	add	x16, sp, #0x330
     aa8:      	str	x2, [x16, #0x8]
     aac:      	add	x16, sp, #0x330
     ab0:      	str	x3, [x16, #0x10]
     ab4:      	add	x16, sp, #0x330
     ab8:      	str	x4, [x16, #0x18]
     abc:      	add	x16, sp, #0x330
     ac0:      	str	x5, [x16, #0x20]
     ac4:      	add	x16, sp, #0x330
     ac8:      	str	x6, [x16, #0x28]
     acc:      	add	x16, sp, #0x330
     ad0:      	str	x7, [x16, #0x30]
     ad4:      	add	x16, sp, #0x330
     ad8:      	str	x8, [x16, #0x38]
     adc:      	add	x16, sp, #0x330
     ae0:      	str	x9, [x16, #0x40]
     ae4:      	add	x16, sp, #0x330
     ae8:      	str	x10, [x16, #0x48]
     aec:      	add	x16, sp, #0x330
     af0:      	str	x11, [x16, #0x50]
     af4:      	add	x16, sp, #0x330
     af8:      	str	x12, [x16, #0x58]
     afc:      	add	x16, sp, #0x330
     b00:      	str	x13, [x16, #0x60]
     b04:      	add	x16, sp, #0x330
     b08:      	str	x14, [x16, #0x68]
     b0c:      	add	x16, sp, #0x330
     b10:      	str	x0, [x16, #0x70]
     b14:      	add	x8, sp, #0x400
     b18:      	add	x0, sp, #0x330
     b1c:      	mov	x2, x24
     b20:      	mov	x1, #0x1                ; =1
     b24:      	uxtb	w1, w1
     b28:      	bl	0xb28 <_stogir.pipeline.prepare-checked+0x248>
		0000000000000b28:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     b2c:      	add	x16, sp, #0x400
     b30:      	ldr	x0, [x16]
     b34:      	add	x16, sp, #0x3b0
     b38:      	str	x0, [x16]
     b3c:      	add	x16, sp, #0x400
     b40:      	ldr	x0, [x16, #0x8]
     b44:      	add	x16, sp, #0x3b0
     b48:      	str	x0, [x16, #0x8]
     b4c:      	add	x16, sp, #0x400
     b50:      	ldr	x0, [x16, #0x10]
     b54:      	add	x16, sp, #0x3b0
     b58:      	str	x0, [x16, #0x10]
     b5c:      	add	x16, sp, #0x400
     b60:      	ldr	x0, [x16, #0x18]
     b64:      	add	x16, sp, #0x3b0
     b68:      	str	x0, [x16, #0x18]
     b6c:      	add	x16, sp, #0x400
     b70:      	ldr	x0, [x16, #0x20]
     b74:      	add	x16, sp, #0x3b0
     b78:      	str	x0, [x16, #0x20]
     b7c:      	add	x16, sp, #0x400
     b80:      	ldr	x0, [x16, #0x28]
     b84:      	add	x16, sp, #0x3b0
     b88:      	str	x0, [x16, #0x28]
     b8c:      	add	x16, sp, #0x400
     b90:      	ldr	x0, [x16, #0x30]
     b94:      	add	x16, sp, #0x3b0
     b98:      	str	x0, [x16, #0x30]
     b9c:      	add	x16, sp, #0x400
     ba0:      	ldr	x0, [x16, #0x38]
     ba4:      	add	x16, sp, #0x3b0
     ba8:      	str	x0, [x16, #0x38]
     bac:      	add	x16, sp, #0x400
     bb0:      	ldr	x0, [x16, #0x40]
     bb4:      	add	x16, sp, #0x3b0
     bb8:      	str	x0, [x16, #0x40]
     bbc:      	add	x16, sp, #0x400
     bc0:      	ldr	x0, [x16, #0x48]
     bc4:      	add	x16, sp, #0x3b0
     bc8:      	str	x0, [x16, #0x48]
     bcc:      	add	x8, sp, #0x4a0
     bd0:      	add	x0, sp, #0x330
     bd4:      	mov	x2, x24
     bd8:      	movz	x1, #0x0, lsl #48
     bdc:      	uxtb	w1, w1
     be0:      	bl	0xbe0 <_stogir.pipeline.prepare-checked+0x300>
		0000000000000be0:  ARM64_RELOC_BRANCH26	_stogir.adjacency.build
     be4:      	add	x16, sp, #0x4a0
     be8:      	ldr	x0, [x16]
     bec:      	add	x16, sp, #0x450
     bf0:      	str	x0, [x16]
     bf4:      	add	x16, sp, #0x4a0
     bf8:      	ldr	x0, [x16, #0x8]
     bfc:      	add	x16, sp, #0x450
     c00:      	str	x0, [x16, #0x8]
     c04:      	add	x16, sp, #0x4a0
     c08:      	ldr	x0, [x16, #0x10]
     c0c:      	add	x16, sp, #0x450
     c10:      	str	x0, [x16, #0x10]
     c14:      	add	x16, sp, #0x4a0
     c18:      	ldr	x0, [x16, #0x18]
     c1c:      	add	x16, sp, #0x450
     c20:      	str	x0, [x16, #0x18]
     c24:      	add	x16, sp, #0x4a0
     c28:      	ldr	x0, [x16, #0x20]
     c2c:      	add	x16, sp, #0x450
     c30:      	str	x0, [x16, #0x20]
     c34:      	add	x16, sp, #0x4a0
     c38:      	ldr	x0, [x16, #0x28]
     c3c:      	add	x16, sp, #0x450
     c40:      	str	x0, [x16, #0x28]
     c44:      	add	x16, sp, #0x4a0
     c48:      	ldr	x0, [x16, #0x30]
     c4c:      	add	x16, sp, #0x450
     c50:      	str	x0, [x16, #0x30]
     c54:      	add	x16, sp, #0x4a0
     c58:      	ldr	x0, [x16, #0x38]
     c5c:      	add	x16, sp, #0x450
     c60:      	str	x0, [x16, #0x38]
     c64:      	add	x16, sp, #0x4a0
     c68:      	ldr	x0, [x16, #0x40]
     c6c:      	add	x16, sp, #0x450
     c70:      	str	x0, [x16, #0x40]
     c74:      	add	x16, sp, #0x4a0
     c78:      	ldr	x0, [x16, #0x48]
     c7c:      	add	x16, sp, #0x450
     c80:      	str	x0, [x16, #0x48]
     c84:      	add	x8, sp, #0x520
     c88:      	add	x0, sp, #0x330
     c8c:      	add	x1, sp, #0x450
     c90:      	mov	w2, w21
     c94:      	mov	x3, x24
     c98:      	bl	0xc98 <_stogir.pipeline.prepare-checked+0x3b8>
		0000000000000c98:  ARM64_RELOC_BRANCH26	_stogir.adjacency.reverse-postorder
     c9c:      	add	x16, sp, #0x520
     ca0:      	ldr	x0, [x16]
     ca4:      	add	x16, sp, #0x4f0
     ca8:      	str	x0, [x16]
     cac:      	add	x16, sp, #0x520
     cb0:      	ldr	x0, [x16, #0x8]
     cb4:      	add	x16, sp, #0x4f0
     cb8:      	str	x0, [x16, #0x8]
     cbc:      	add	x16, sp, #0x520
     cc0:      	ldr	x0, [x16, #0x10]
     cc4:      	add	x16, sp, #0x4f0
     cc8:      	str	x0, [x16, #0x10]
     ccc:      	add	x16, sp, #0x520
     cd0:      	ldr	x0, [x16, #0x18]
     cd4:      	add	x16, sp, #0x4f0
     cd8:      	str	x0, [x16, #0x18]
     cdc:      	add	x16, sp, #0x520
     ce0:      	ldr	x0, [x16, #0x20]
     ce4:      	add	x16, sp, #0x4f0
     ce8:      	str	x0, [x16, #0x20]
     cec:      	add	x8, sp, #0x580
     cf0:      	add	x0, sp, #0x330
     cf4:      	add	x1, sp, #0x3b0
     cf8:      	add	x2, sp, #0x4f0
     cfc:      	mov	x3, x24
     d00:      	bl	0xd00 <_stogir.pipeline.prepare-checked+0x420>
		0000000000000d00:  ARM64_RELOC_BRANCH26	_stogir.dominators.build
     d04:      	add	x16, sp, #0x580
     d08:      	ldr	x0, [x16]
     d0c:      	add	x16, sp, #0x550
     d10:      	str	x0, [x16]
     d14:      	add	x16, sp, #0x580
     d18:      	ldr	x0, [x16, #0x8]
     d1c:      	add	x16, sp, #0x550
     d20:      	str	x0, [x16, #0x8]
     d24:      	add	x16, sp, #0x580
     d28:      	ldr	x0, [x16, #0x10]
     d2c:      	add	x16, sp, #0x550
     d30:      	str	x0, [x16, #0x10]
     d34:      	add	x16, sp, #0x580
     d38:      	ldr	x0, [x16, #0x18]
     d3c:      	add	x16, sp, #0x550
     d40:      	str	x0, [x16, #0x18]
     d44:      	add	x16, sp, #0x580
     d48:      	ldr	x0, [x16, #0x20]
     d4c:      	add	x16, sp, #0x550
     d50:      	str	x0, [x16, #0x20]
     d54:      	add	x8, sp, #0x5e0
     d58:      	add	x0, sp, #0x330
     d5c:      	add	x1, sp, #0x3b0
     d60:      	add	x2, sp, #0x550
     d64:      	mov	x3, x24
     d68:      	bl	0xd68 <_stogir.pipeline.prepare-checked+0x488>
		0000000000000d68:  ARM64_RELOC_BRANCH26	_stogir.loops.depths
     d6c:      	add	x16, sp, #0x5e0
     d70:      	ldr	x0, [x16]
     d74:      	add	x16, sp, #0x5b0
     d78:      	str	x0, [x16]
     d7c:      	add	x16, sp, #0x5e0
     d80:      	ldr	x0, [x16, #0x8]
     d84:      	add	x16, sp, #0x5b0
     d88:      	str	x0, [x16, #0x8]
     d8c:      	add	x16, sp, #0x5e0
     d90:      	ldr	x0, [x16, #0x10]
     d94:      	add	x16, sp, #0x5b0
     d98:      	str	x0, [x16, #0x10]
     d9c:      	add	x16, sp, #0x5e0
     da0:      	ldr	x0, [x16, #0x18]
     da4:      	add	x16, sp, #0x5b0
     da8:      	str	x0, [x16, #0x18]
     dac:      	add	x16, sp, #0x5e0
     db0:      	ldr	x0, [x16, #0x20]
     db4:      	add	x16, sp, #0x5b0
     db8:      	str	x0, [x16, #0x20]
     dbc:      	add	x8, sp, #0x640
     dc0:      	mov	x0, x20
     dc4:      	mov	x1, x22
     dc8:      	mov	x2, x23
     dcc:      	mov	x3, x24
     dd0:      	bl	0xdd0 <_stogir.pipeline.prepare-checked+0x4f0>
		0000000000000dd0:  ARM64_RELOC_BRANCH26	_stogir.liveness.mark
     dd4:      	add	x16, sp, #0x640
     dd8:      	ldr	x0, [x16]
     ddc:      	add	x16, sp, #0x610
     de0:      	str	x0, [x16]
     de4:      	add	x16, sp, #0x640
     de8:      	ldr	x0, [x16, #0x8]
     dec:      	add	x16, sp, #0x610
     df0:      	str	x0, [x16, #0x8]
     df4:      	add	x16, sp, #0x640
     df8:      	ldr	x0, [x16, #0x10]
     dfc:      	add	x16, sp, #0x610
     e00:      	str	x0, [x16, #0x10]
     e04:      	add	x16, sp, #0x640
     e08:      	ldr	x0, [x16, #0x18]
     e0c:      	add	x16, sp, #0x610
     e10:      	str	x0, [x16, #0x18]
     e14:      	add	x16, sp, #0x640
     e18:      	ldr	x0, [x16, #0x20]
     e1c:      	add	x16, sp, #0x610
     e20:      	str	x0, [x16, #0x20]
     e24:      	add	x8, sp, #0x6c0
     e28:      	mov	x0, x20
     e2c:      	mov	x1, x24
     e30:      	bl	0xe30 <_stogir.pipeline.prepare-checked+0x550>
		0000000000000e30:  ARM64_RELOC_BRANCH26	_stogir.uses.build
     e34:      	add	x16, sp, #0x6c0
     e38:      	ldr	x0, [x16]
     e3c:      	add	x16, sp, #0x670
     e40:      	str	x0, [x16]
     e44:      	add	x16, sp, #0x6c0
     e48:      	ldr	x0, [x16, #0x8]
     e4c:      	add	x16, sp, #0x670
     e50:      	str	x0, [x16, #0x8]
     e54:      	add	x16, sp, #0x6c0
     e58:      	ldr	x0, [x16, #0x10]
     e5c:      	add	x16, sp, #0x670
     e60:      	str	x0, [x16, #0x10]
     e64:      	add	x16, sp, #0x6c0
     e68:      	ldr	x0, [x16, #0x18]
     e6c:      	add	x16, sp, #0x670
     e70:      	str	x0, [x16, #0x18]
     e74:      	add	x16, sp, #0x6c0
     e78:      	ldr	x0, [x16, #0x20]
     e7c:      	add	x16, sp, #0x670
     e80:      	str	x0, [x16, #0x20]
     e84:      	add	x16, sp, #0x6c0
     e88:      	ldr	x0, [x16, #0x28]
     e8c:      	add	x16, sp, #0x670
     e90:      	str	x0, [x16, #0x28]
     e94:      	add	x16, sp, #0x6c0
     e98:      	ldr	x0, [x16, #0x30]
     e9c:      	add	x16, sp, #0x670
     ea0:      	str	x0, [x16, #0x30]
     ea4:      	add	x16, sp, #0x6c0
     ea8:      	ldr	x0, [x16, #0x38]
     eac:      	add	x16, sp, #0x670
     eb0:      	str	x0, [x16, #0x38]
     eb4:      	add	x16, sp, #0x6c0
     eb8:      	ldr	x0, [x16, #0x40]
     ebc:      	add	x16, sp, #0x670
     ec0:      	str	x0, [x16, #0x40]
     ec4:      	add	x16, sp, #0x6c0
     ec8:      	ldr	x0, [x16, #0x48]
     ecc:      	add	x16, sp, #0x670
     ed0:      	str	x0, [x16, #0x48]
     ed4:      	ldr	x0, [x24]
     ed8:      	ldr	x1, [x24, #0x8]
     edc:      	add	x16, sp, #0x710
     ee0:      	movz	x17, #0x0, lsl #48
     ee4:      	str	x17, [x16]
     ee8:      	add	x16, sp, #0x710
     eec:      	movz	x17, #0x0, lsl #48
     ef0:      	str	x17, [x16, #0x8]
     ef4:      	add	x16, sp, #0x710
     ef8:      	movz	x17, #0x0, lsl #48
     efc:      	str	x17, [x16, #0x10]
     f00:      	add	x16, sp, #0x710
     f04:      	str	x0, [x16, #0x18]
     f08:      	add	x16, sp, #0x710
     f0c:      	str	x1, [x16, #0x20]
     f10:      	add	x16, sp, #0x710
     f14:      	movz	x17, #0x0, lsl #48
     f18:      	str	x17, [x16, #0x28]
     f1c:      	add	x16, sp, #0x710
     f20:      	movz	x17, #0x0, lsl #48
     f24:      	str	x17, [x16, #0x30]
     f28:      	add	x16, sp, #0x710
     f2c:      	movz	x17, #0x0, lsl #48
     f30:      	str	x17, [x16, #0x38]
     f34:      	add	x16, sp, #0x710
     f38:      	str	x0, [x16, #0x40]
     f3c:      	add	x16, sp, #0x710
     f40:      	str	x1, [x16, #0x48]
     f44:      	add	x8, sp, #0x760
     f48:      	mov	x0, x20
     f4c:      	add	x1, sp, #0x330
     f50:      	mov	x2, x24
     f54:      	bl	0xf54 <_stogir.pipeline.prepare-checked+0x674>
		0000000000000f54:  ARM64_RELOC_BRANCH26	_stogir.placement.pinned
     f58:      	add	x16, sp, #0x760
     f5c:      	ldr	w0, [x16]
     f60:      	lsr	x16, x0, #0
     f64:      	cmp	x16, #0x1
     f68:      	b.eq	0xf84 <_stogir.pipeline.prepare-checked+0x6a4>
     f6c:      	b.lo	0xf74 <_stogir.pipeline.prepare-checked+0x694>
     f70:      	b	0xf88 <_stogir.pipeline.prepare-checked+0x6a8>
     f74:      	cmp	x16, #0x0
     f78:      	b.eq	0xf80 <_stogir.pipeline.prepare-checked+0x6a0>
     f7c:      	b	0xf88 <_stogir.pipeline.prepare-checked+0x6a8>
     f80:      	b	0x1424 <_stogir.pipeline.prepare-checked+0xb44>
     f84:      	b	0xf8c <_stogir.pipeline.prepare-checked+0x6ac>
     f88:      	b	0x1c08 <_stogir.pipeline.prepare-checked+0x1328>
     f8c:      	add	x0, x26, #0x8
     f90:      	add	x16, sp, #0x760
     f94:      	ldr	x21, [x16, #0x8]
     f98:      	ldr	x22, [x0, #0x8]
     f9c:      	add	x0, sp, #0x3b0
     fa0:      	bl	0xfa0 <_stogir.pipeline.prepare-checked+0x6c0>
		0000000000000fa0:  ARM64_RELOC_BRANCH26	_stogir.adjacency.release!
     fa4:      	add	x0, sp, #0x450
     fa8:      	bl	0xfa8 <_stogir.pipeline.prepare-checked+0x6c8>
		0000000000000fa8:  ARM64_RELOC_BRANCH26	_stogir.adjacency.release!
     fac:      	b	0xfbc <_stogir.pipeline.prepare-checked+0x6dc>
     fb0:      	sub	x0, x0, #0x1
     fb4:      	add	x16, sp, #0x610
     fb8:      	str	x0, [x16, #0x8]
     fbc:      	add	x16, sp, #0x610
     fc0:      	ldr	x0, [x16, #0x8]
     fc4:      	cmp	x0, #0x0
     fc8:      	b.ne	0xfb0 <_stogir.pipeline.prepare-checked+0x6d0>
     fcc:      	add	x16, sp, #0x610
     fd0:      	orr	x0, x16, xzr
     fd4:      	add	x16, sp, #0x610
     fd8:      	ldr	x1, [x16, #0x10]
     fdc:      	cmp	x1, #0x0
     fe0:      	b.le	0x1010 <_stogir.pipeline.prepare-checked+0x730>
     fe4:      	add	x0, x0, #0x18
     fe8:      	add	x16, sp, #0x610
     fec:      	ldr	x2, [x16]
     ff0:      	fmov	d31, x1
     ff4:      	mov	x1, x2
     ff8:      	fmov	x2, d31
     ffc:      	adrp	x3, 0x0 <_gap_prepare_graph>
		0000000000000ffc:  ARM64_RELOC_PAGE21	l_stogir.394
    1000:      	ldr	x3, [x3]
		0000000000001000:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    1004:      	mov	x4, #0x1                ; =1
    1008:      	mov	x5, #0x1                ; =1
    100c:      	bl	0x100c <_stogir.pipeline.prepare-checked+0x72c>
		000000000000100c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1010:      	add	x16, sp, #0x610
    1014:      	movz	x17, #0x0, lsl #48
    1018:      	str	x17, [x16]
    101c:      	add	x16, sp, #0x610
    1020:      	movz	x17, #0x0, lsl #48
    1024:      	str	x17, [x16, #0x8]
    1028:      	add	x16, sp, #0x610
    102c:      	movz	x17, #0x0, lsl #48
    1030:      	str	x17, [x16, #0x10]
    1034:      	add	x0, sp, #0x670
    1038:      	bl	0x1038 <_stogir.pipeline.prepare-checked+0x758>
		0000000000001038:  ARM64_RELOC_BRANCH26	_stogir.uses.release!
    103c:      	cmp	x22, #0x0
    1040:      	b.ne	0x1c48 <_stogir.pipeline.prepare-checked+0x1368>
    1044:      	add	x16, sp, #0xa60
    1048:      	orr	x20, x16, xzr
    104c:      	add	x16, sp, #0xbb0
    1050:      	orr	x0, x16, xzr
    1054:      	add	x16, sp, #0xa60
    1058:      	movz	w17, #0x0, lsl #16
    105c:      	str	w17, [x16]
    1060:      	add	x1, x20, #0x8
    1064:      	add	x21, x0, #0x78
    1068:      	add	x22, x0, #0xa0
    106c:      	add	x23, x0, #0xf0
    1070:      	add	x24, x0, #0x118
    1074:      	add	x16, sp, #0x550
    1078:      	ldr	x25, [x16]
    107c:      	orr	x26, x1, xzr
    1080:      	add	x16, sp, #0x550
    1084:      	ldr	x27, [x16, #0x8]
    1088:      	add	x16, sp, #0x550
    108c:      	ldr	x28, [x16, #0x10]
    1090:      	add	x16, sp, #0x550
    1094:      	ldr	x0, [x16, #0x18]
    1098:      	add	x16, sp, #0x550
    109c:      	ldr	x1, [x16, #0x20]
    10a0:      	add	x16, sp, #0x5b0
    10a4:      	ldr	x2, [x16]
    10a8:      	add	x16, sp, #0x5b0
    10ac:      	ldr	x3, [x16, #0x8]
    10b0:      	add	x16, sp, #0x5b0
    10b4:      	ldr	x4, [x16, #0x10]
    10b8:      	add	x16, sp, #0x5b0
    10bc:      	ldr	x5, [x16, #0x18]
    10c0:      	add	x16, sp, #0x5b0
    10c4:      	ldr	x6, [x16, #0x20]
    10c8:      	add	x16, sp, #0x330
    10cc:      	ldr	x7, [x16]
    10d0:      	add	x16, sp, #0x330
    10d4:      	ldr	x8, [x16, #0x8]
    10d8:      	add	x16, sp, #0x330
    10dc:      	ldr	x9, [x16, #0x10]
    10e0:      	add	x16, sp, #0x330
    10e4:      	ldr	x10, [x16, #0x18]
    10e8:      	add	x16, sp, #0x330
    10ec:      	ldr	x11, [x16, #0x20]
    10f0:      	add	x16, sp, #0x330
    10f4:      	ldr	x12, [x16, #0x28]
    10f8:      	add	x16, sp, #0x330
    10fc:      	ldr	x13, [x16, #0x30]
    1100:      	add	x16, sp, #0x330
    1104:      	ldr	x14, [x16, #0x38]
    1108:      	add	x16, sp, #0x330
    110c:      	ldr	x15, [x16, #0x40]
    1110:      	str	x0, [sp, #0xe30]
    1114:      	add	x16, sp, #0x330
    1118:      	ldr	x0, [x16, #0x48]
    111c:      	str	x0, [sp, #0xe38]
    1120:      	add	x16, sp, #0x330
    1124:      	ldr	x0, [x16, #0x50]
    1128:      	str	x0, [sp, #0xe40]
    112c:      	add	x16, sp, #0x330
    1130:      	ldr	x0, [x16, #0x58]
    1134:      	str	x0, [sp, #0xe48]
    1138:      	add	x16, sp, #0x330
    113c:      	ldr	x0, [x16, #0x60]
    1140:      	str	x0, [sp, #0xe50]
    1144:      	add	x16, sp, #0x330
    1148:      	ldr	x0, [x16, #0x68]
    114c:      	str	x0, [sp, #0xe58]
    1150:      	add	x16, sp, #0x330
    1154:      	ldr	x0, [x16, #0x70]
    1158:      	str	x0, [sp, #0xe60]
    115c:      	add	x16, sp, #0x4f0
    1160:      	ldr	x0, [x16]
    1164:      	str	x0, [sp, #0xe68]
    1168:      	add	x16, sp, #0x4f0
    116c:      	ldr	x0, [x16, #0x8]
    1170:      	str	x0, [sp, #0xe70]
    1174:      	add	x16, sp, #0x4f0
    1178:      	ldr	x0, [x16, #0x10]
    117c:      	str	x0, [sp, #0xe78]
    1180:      	add	x16, sp, #0x4f0
    1184:      	ldr	x0, [x16, #0x18]
    1188:      	str	x0, [sp, #0xe80]
    118c:      	add	x16, sp, #0x4f0
    1190:      	ldr	x0, [x16, #0x20]
    1194:      	str	x0, [sp, #0xe88]
    1198:      	add	x16, sp, #0x710
    119c:      	ldr	x0, [x16]
    11a0:      	str	x0, [sp, #0xe90]
    11a4:      	add	x16, sp, #0x710
    11a8:      	ldr	x0, [x16, #0x8]
    11ac:      	str	x0, [sp, #0xe98]
    11b0:      	add	x16, sp, #0x710
    11b4:      	ldr	x0, [x16, #0x10]
    11b8:      	str	x0, [sp, #0xea0]
    11bc:      	add	x16, sp, #0x710
    11c0:      	ldr	x0, [x16, #0x18]
    11c4:      	str	x0, [sp, #0xea8]
    11c8:      	add	x16, sp, #0x710
    11cc:      	ldr	x0, [x16, #0x20]
    11d0:      	str	x0, [sp, #0xeb0]
    11d4:      	add	x16, sp, #0x710
    11d8:      	ldr	x0, [x16, #0x28]
    11dc:      	str	x0, [sp, #0xeb8]
    11e0:      	add	x16, sp, #0x710
    11e4:      	ldr	x0, [x16, #0x30]
    11e8:      	str	x0, [sp, #0xec0]
    11ec:      	add	x16, sp, #0x710
    11f0:      	ldr	x0, [x16, #0x38]
    11f4:      	str	x0, [sp, #0xec8]
    11f8:      	add	x16, sp, #0x710
    11fc:      	ldr	x0, [x16, #0x40]
    1200:      	str	x0, [sp, #0xed0]
    1204:      	add	x16, sp, #0x710
    1208:      	ldr	x0, [x16, #0x48]
    120c:      	str	x1, [sp, #0xf20]
    1210:      	str	x2, [sp, #0xf18]
    1214:      	str	x3, [sp, #0xef0]
    1218:      	str	x4, [sp, #0xef8]
    121c:      	str	x5, [sp, #0xf00]
    1220:      	str	x6, [sp, #0xf08]
    1224:      	str	x0, [sp, #0xf58]
    1228:      	add	x0, sp, #0xbb0
    122c:      	str	x19, [sp, #0xed8]
    1230:      	mov	x19, x10
    1234:      	str	x26, [sp, #0xee0]
    1238:      	mov	x26, x9
    123c:      	str	x20, [sp, #0xee8]
    1240:      	mov	x20, x8
    1244:      	str	x24, [sp, #0xf10]
    1248:      	mov	x24, x7
    124c:      	str	x28, [sp, #0xf28]
    1250:      	mov	x28, x11
    1254:      	str	x23, [sp, #0xf30]
    1258:      	mov	x23, x12
    125c:      	str	x27, [sp, #0xf38]
    1260:      	mov	x27, x13
    1264:      	str	x25, [sp, #0xf40]
    1268:      	mov	x25, x14
    126c:      	str	x22, [sp, #0xf48]
    1270:      	mov	x22, x15
    1274:      	str	x21, [sp, #0xf50]
    1278:      	ldr	x21, [sp, #0xe38]
    127c:      	movz	x1, #0x0, lsl #48
    1280:      	mov	x2, #0x140              ; =320
    1284:      	bl	0x1284 <_stogir.pipeline.prepare-checked+0x9a4>
		0000000000001284:  ARM64_RELOC_BRANCH26	_memset
    1288:      	add	x16, sp, #0xbb0
    128c:      	str	x24, [x16]
    1290:      	add	x16, sp, #0xbb0
    1294:      	str	x20, [x16, #0x8]
    1298:      	add	x16, sp, #0xbb0
    129c:      	str	x26, [x16, #0x10]
    12a0:      	add	x16, sp, #0xbb0
    12a4:      	str	x19, [x16, #0x18]
    12a8:      	add	x16, sp, #0xbb0
    12ac:      	str	x28, [x16, #0x20]
    12b0:      	add	x16, sp, #0xbb0
    12b4:      	str	x23, [x16, #0x28]
    12b8:      	add	x16, sp, #0xbb0
    12bc:      	str	x27, [x16, #0x30]
    12c0:      	add	x16, sp, #0xbb0
    12c4:      	str	x25, [x16, #0x38]
    12c8:      	add	x16, sp, #0xbb0
    12cc:      	str	x22, [x16, #0x40]
    12d0:      	add	x16, sp, #0xbb0
    12d4:      	str	x21, [x16, #0x48]
    12d8:      	ldr	x0, [sp, #0xe40]
    12dc:      	add	x16, sp, #0xbb0
    12e0:      	str	x0, [x16, #0x50]
    12e4:      	ldr	x0, [sp, #0xe48]
    12e8:      	add	x16, sp, #0xbb0
    12ec:      	str	x0, [x16, #0x58]
    12f0:      	ldr	x0, [sp, #0xe50]
    12f4:      	add	x16, sp, #0xbb0
    12f8:      	str	x0, [x16, #0x60]
    12fc:      	ldr	x0, [sp, #0xe58]
    1300:      	add	x16, sp, #0xbb0
    1304:      	str	x0, [x16, #0x68]
    1308:      	ldr	x0, [sp, #0xe60]
    130c:      	add	x16, sp, #0xbb0
    1310:      	str	x0, [x16, #0x70]
    1314:      	ldr	x0, [sp, #0xe68]
    1318:      	add	x16, sp, #0xbb0
    131c:      	str	x0, [x16, #0x78]
    1320:      	ldr	x0, [sp, #0xf50]
    1324:      	ldr	x1, [sp, #0xe70]
    1328:      	str	x1, [x0, #0x8]
    132c:      	ldr	x1, [sp, #0xe78]
    1330:      	str	x1, [x0, #0x10]
    1334:      	ldr	x1, [sp, #0xe80]
    1338:      	str	x1, [x0, #0x18]
    133c:      	ldr	x1, [sp, #0xe88]
    1340:      	str	x1, [x0, #0x20]
    1344:      	ldr	x0, [sp, #0xe90]
    1348:      	add	x16, sp, #0xbb0
    134c:      	str	x0, [x16, #0xa0]
    1350:      	ldr	x0, [sp, #0xf48]
    1354:      	ldr	x1, [sp, #0xe98]
    1358:      	str	x1, [x0, #0x8]
    135c:      	ldr	x1, [sp, #0xea0]
    1360:      	str	x1, [x0, #0x10]
    1364:      	ldr	x1, [sp, #0xea8]
    1368:      	str	x1, [x0, #0x18]
    136c:      	ldr	x1, [sp, #0xeb0]
    1370:      	str	x1, [x0, #0x20]
    1374:      	ldr	x1, [sp, #0xeb8]
    1378:      	str	x1, [x0, #0x28]
    137c:      	ldr	x1, [sp, #0xec0]
    1380:      	str	x1, [x0, #0x30]
    1384:      	ldr	x1, [sp, #0xec8]
    1388:      	str	x1, [x0, #0x38]
    138c:      	ldr	x1, [sp, #0xed0]
    1390:      	str	x1, [x0, #0x40]
    1394:      	ldr	x1, [sp, #0xf58]
    1398:      	str	x1, [x0, #0x48]
    139c:      	ldr	x0, [sp, #0xf40]
    13a0:      	add	x16, sp, #0xbb0
    13a4:      	str	x0, [x16, #0xf0]
    13a8:      	ldr	x0, [sp, #0xf30]
    13ac:      	ldr	x1, [sp, #0xf38]
    13b0:      	str	x1, [x0, #0x8]
    13b4:      	ldr	x1, [sp, #0xf28]
    13b8:      	str	x1, [x0, #0x10]
    13bc:      	ldr	x1, [sp, #0xe30]
    13c0:      	str	x1, [x0, #0x18]
    13c4:      	ldr	x1, [sp, #0xf20]
    13c8:      	str	x1, [x0, #0x20]
    13cc:      	ldr	x0, [sp, #0xf18]
    13d0:      	add	x16, sp, #0xbb0
    13d4:      	str	x0, [x16, #0x118]
    13d8:      	ldr	x0, [sp, #0xef0]
    13dc:      	ldr	x1, [sp, #0xf10]
    13e0:      	str	x0, [x1, #0x8]
    13e4:      	ldr	x0, [sp, #0xef8]
    13e8:      	str	x0, [x1, #0x10]
    13ec:      	ldr	x0, [sp, #0xf00]
    13f0:      	str	x0, [x1, #0x18]
    13f4:      	ldr	x0, [sp, #0xf08]
    13f8:      	str	x0, [x1, #0x20]
    13fc:      	add	x0, sp, #0xcf0
    1400:      	add	x1, sp, #0xbb0
    1404:      	mov	x2, #0x140              ; =320
    1408:      	bl	0x1408 <_stogir.pipeline.prepare-checked+0xb28>
		0000000000001408:  ARM64_RELOC_BRANCH26	_memmove
    140c:      	ldr	x0, [sp, #0xee0]
    1410:      	add	x1, sp, #0xcf0
    1414:      	mov	x2, #0x140              ; =320
    1418:      	bl	0x1418 <_stogir.pipeline.prepare-checked+0xb38>
		0000000000001418:  ARM64_RELOC_BRANCH26	_memmove
    141c:      	ldr	x19, [sp, #0xee8]
    1420:      	b	0xa4c <_stogir.pipeline.prepare-checked+0x16c>
    1424:      	add	x0, x26, #0x8
    1428:      	add	x16, sp, #0x760
    142c:      	ldr	x1, [x16, #0x8]
    1430:      	ldr	x2, [x0, #0x8]
    1434:      	ldr	x3, [x0, #0x10]
    1438:      	ldr	x4, [x0, #0x18]
    143c:      	ldr	x0, [x0, #0x20]
    1440:      	add	x16, sp, #0x790
    1444:      	str	x1, [x16]
    1448:      	add	x16, sp, #0x790
    144c:      	str	x2, [x16, #0x8]
    1450:      	add	x16, sp, #0x790
    1454:      	str	x3, [x16, #0x10]
    1458:      	add	x16, sp, #0x790
    145c:      	str	x4, [x16, #0x18]
    1460:      	add	x16, sp, #0x790
    1464:      	str	x0, [x16, #0x20]
    1468:      	add	x8, sp, #0x7c0
    146c:      	mov	x0, x20
    1470:      	add	x1, sp, #0x790
    1474:      	add	x2, sp, #0x550
    1478:      	mov	w3, w21
    147c:      	add	x4, sp, #0x670
    1480:      	mov	x5, x24
    1484:      	bl	0x1484 <_stogir.pipeline.prepare-checked+0xba4>
		0000000000001484:  ARM64_RELOC_BRANCH26	_stogir.placement.early-with-uses!
    1488:      	add	x16, sp, #0x7c0
    148c:      	ldr	w0, [x16]
    1490:      	lsr	x16, x0, #0
    1494:      	cmp	x16, #0x1
    1498:      	b.eq	0x14b4 <_stogir.pipeline.prepare-checked+0xbd4>
    149c:      	b.lo	0x14a4 <_stogir.pipeline.prepare-checked+0xbc4>
    14a0:      	b	0x14b8 <_stogir.pipeline.prepare-checked+0xbd8>
    14a4:      	cmp	x16, #0x0
    14a8:      	b.eq	0x14b0 <_stogir.pipeline.prepare-checked+0xbd0>
    14ac:      	b	0x14b8 <_stogir.pipeline.prepare-checked+0xbd8>
    14b0:      	b	0x16ac <_stogir.pipeline.prepare-checked+0xdcc>
    14b4:      	b	0x14bc <_stogir.pipeline.prepare-checked+0xbdc>
    14b8:      	b	0x1c10 <_stogir.pipeline.prepare-checked+0x1330>
    14bc:      	add	x16, sp, #0x7c0
    14c0:      	orr	x0, x16, xzr
    14c4:      	add	x0, x0, #0x8
    14c8:      	add	x16, sp, #0x7c0
    14cc:      	ldr	x21, [x16, #0x8]
    14d0:      	ldr	x22, [x0, #0x8]
    14d4:      	b	0x16b8 <_stogir.pipeline.prepare-checked+0xdd8>
    14d8:      	sub	x0, x0, #0x1
    14dc:      	add	x16, sp, #0x4f0
    14e0:      	str	x0, [x16, #0x8]
    14e4:      	add	x16, sp, #0x4f0
    14e8:      	ldr	x0, [x16, #0x8]
    14ec:      	cmp	x0, #0x0
    14f0:      	b.ne	0x14d8 <_stogir.pipeline.prepare-checked+0xbf8>
    14f4:      	add	x16, sp, #0x4f0
    14f8:      	orr	x0, x16, xzr
    14fc:      	add	x16, sp, #0x4f0
    1500:      	ldr	x1, [x16, #0x10]
    1504:      	cmp	x1, #0x0
    1508:      	b.le	0x1538 <_stogir.pipeline.prepare-checked+0xc58>
    150c:      	add	x0, x0, #0x18
    1510:      	add	x16, sp, #0x4f0
    1514:      	ldr	x2, [x16]
    1518:      	fmov	d31, x1
    151c:      	mov	x1, x2
    1520:      	fmov	x2, d31
    1524:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001524:  ARM64_RELOC_PAGE21	l_stogir.395
    1528:      	ldr	x3, [x3]
		0000000000001528:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    152c:      	mov	x4, #0x4                ; =4
    1530:      	mov	x5, #0x4                ; =4
    1534:      	bl	0x1534 <_stogir.pipeline.prepare-checked+0xc54>
		0000000000001534:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1538:      	add	x16, sp, #0x910
    153c:      	orr	x19, x16, xzr
    1540:      	add	x20, x19, #0x8
    1544:      	add	x16, sp, #0x4f0
    1548:      	movz	x17, #0x0, lsl #48
    154c:      	str	x17, [x16]
    1550:      	add	x16, sp, #0x4f0
    1554:      	movz	x17, #0x0, lsl #48
    1558:      	str	x17, [x16, #0x8]
    155c:      	add	x16, sp, #0x4f0
    1560:      	movz	x17, #0x0, lsl #48
    1564:      	str	x17, [x16, #0x10]
    1568:      	add	x0, sp, #0x710
    156c:      	bl	0x156c <_stogir.pipeline.prepare-checked+0xc8c>
		000000000000156c:  ARM64_RELOC_BRANCH26	_stogir.schedule.release!
    1570:      	add	x16, sp, #0x910
    1574:      	mov	w17, #0x1               ; =1
    1578:      	str	w17, [x16]
    157c:      	add	x16, sp, #0x910
    1580:      	str	x21, [x16, #0x8]
    1584:      	str	x22, [x20, #0x8]
    1588:      	b	0x1420 <_stogir.pipeline.prepare-checked+0xb40>
    158c:      	nop
    1590:      	sub	x0, x0, #0x1
    1594:      	add	x16, sp, #0x5b0
    1598:      	str	x0, [x16, #0x8]
    159c:      	add	x16, sp, #0x5b0
    15a0:      	ldr	x0, [x16, #0x8]
    15a4:      	cmp	x0, #0x0
    15a8:      	b.ne	0x1590 <_stogir.pipeline.prepare-checked+0xcb0>
    15ac:      	add	x16, sp, #0x5b0
    15b0:      	orr	x0, x16, xzr
    15b4:      	add	x16, sp, #0x5b0
    15b8:      	ldr	x1, [x16, #0x10]
    15bc:      	cmp	x1, #0x0
    15c0:      	b.le	0x15f0 <_stogir.pipeline.prepare-checked+0xd10>
    15c4:      	add	x0, x0, #0x18
    15c8:      	add	x16, sp, #0x5b0
    15cc:      	ldr	x2, [x16]
    15d0:      	fmov	d31, x1
    15d4:      	mov	x1, x2
    15d8:      	fmov	x2, d31
    15dc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		00000000000015dc:  ARM64_RELOC_PAGE21	l_stogir.395
    15e0:      	ldr	x3, [x3]
		00000000000015e0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    15e4:      	mov	x4, #0x4                ; =4
    15e8:      	mov	x5, #0x4                ; =4
    15ec:      	bl	0x15ec <_stogir.pipeline.prepare-checked+0xd0c>
		00000000000015ec:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    15f0:      	add	x16, sp, #0x5b0
    15f4:      	movz	x17, #0x0, lsl #48
    15f8:      	str	x17, [x16]
    15fc:      	add	x16, sp, #0x5b0
    1600:      	movz	x17, #0x0, lsl #48
    1604:      	str	x17, [x16, #0x8]
    1608:      	add	x16, sp, #0x5b0
    160c:      	movz	x17, #0x0, lsl #48
    1610:      	str	x17, [x16, #0x10]
    1614:      	add	x0, sp, #0x330
    1618:      	bl	0x1618 <_stogir.pipeline.prepare-checked+0xd38>
		0000000000001618:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    161c:      	b	0x14e4 <_stogir.pipeline.prepare-checked+0xc04>
    1620:      	sub	x0, x0, #0x1
    1624:      	add	x16, sp, #0x550
    1628:      	str	x0, [x16, #0x8]
    162c:      	add	x16, sp, #0x550
    1630:      	ldr	x0, [x16, #0x8]
    1634:      	cmp	x0, #0x0
    1638:      	b.ne	0x1620 <_stogir.pipeline.prepare-checked+0xd40>
    163c:      	add	x16, sp, #0x550
    1640:      	orr	x0, x16, xzr
    1644:      	add	x16, sp, #0x550
    1648:      	ldr	x1, [x16, #0x10]
    164c:      	cmp	x1, #0x0
    1650:      	b.le	0x1680 <_stogir.pipeline.prepare-checked+0xda0>
    1654:      	add	x0, x0, #0x18
    1658:      	add	x16, sp, #0x550
    165c:      	ldr	x2, [x16]
    1660:      	fmov	d31, x1
    1664:      	mov	x1, x2
    1668:      	fmov	x2, d31
    166c:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		000000000000166c:  ARM64_RELOC_PAGE21	l_stogir.395
    1670:      	ldr	x3, [x3]
		0000000000001670:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1674:      	mov	x4, #0x4                ; =4
    1678:      	mov	x5, #0x4                ; =4
    167c:      	bl	0x167c <_stogir.pipeline.prepare-checked+0xd9c>
		000000000000167c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1680:      	add	x16, sp, #0x550
    1684:      	movz	x17, #0x0, lsl #48
    1688:      	str	x17, [x16]
    168c:      	add	x16, sp, #0x550
    1690:      	movz	x17, #0x0, lsl #48
    1694:      	str	x17, [x16, #0x8]
    1698:      	add	x16, sp, #0x550
    169c:      	movz	x17, #0x0, lsl #48
    16a0:      	str	x17, [x16, #0x10]
    16a4:      	b	0x159c <_stogir.pipeline.prepare-checked+0xcbc>
    16a8:      	b	0x162c <_stogir.pipeline.prepare-checked+0xd4c>
    16ac:      	adrp	x21, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		00000000000016ac:  ARM64_RELOC_PAGE21	l_stogir.396
    16b0:      	ldr	x21, [x21]
		00000000000016b0:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    16b4:      	movz	x22, #0x0, lsl #48
    16b8:      	cmp	x22, #0x0
    16bc:      	b.ne	0x1730 <_stogir.pipeline.prepare-checked+0xe50>
    16c0:      	add	x8, sp, #0x7e0
    16c4:      	mov	x0, x20
    16c8:      	add	x1, sp, #0x790
    16cc:      	add	x2, sp, #0x550
    16d0:      	add	x3, sp, #0x5b0
    16d4:      	add	x4, sp, #0x610
    16d8:      	add	x5, sp, #0x670
    16dc:      	mov	x6, x24
    16e0:      	bl	0x16e0 <_stogir.pipeline.prepare-checked+0xe00>
		00000000000016e0:  ARM64_RELOC_BRANCH26	_stogir.placement.late-with-uses!
    16e4:      	add	x16, sp, #0x7e0
    16e8:      	ldr	w0, [x16]
    16ec:      	lsr	x16, x0, #0
    16f0:      	cmp	x16, #0x1
    16f4:      	b.eq	0x1710 <_stogir.pipeline.prepare-checked+0xe30>
    16f8:      	b.lo	0x1700 <_stogir.pipeline.prepare-checked+0xe20>
    16fc:      	b	0x1714 <_stogir.pipeline.prepare-checked+0xe34>
    1700:      	cmp	x16, #0x0
    1704:      	b.eq	0x170c <_stogir.pipeline.prepare-checked+0xe2c>
    1708:      	b	0x1714 <_stogir.pipeline.prepare-checked+0xe34>
    170c:      	b	0x1730 <_stogir.pipeline.prepare-checked+0xe50>
    1710:      	b	0x1718 <_stogir.pipeline.prepare-checked+0xe38>
    1714:      	b	0x1c18 <_stogir.pipeline.prepare-checked+0x1338>
    1718:      	add	x16, sp, #0x7e0
    171c:      	orr	x0, x16, xzr
    1720:      	add	x0, x0, #0x8
    1724:      	add	x16, sp, #0x7e0
    1728:      	ldr	x21, [x16, #0x8]
    172c:      	ldr	x22, [x0, #0x8]
    1730:      	cmp	x22, #0x0
    1734:      	b.ne	0x1798 <_stogir.pipeline.prepare-checked+0xeb8>
    1738:      	add	x8, sp, #0x800
    173c:      	mov	x0, x20
    1740:      	add	x1, sp, #0x790
    1744:      	add	x2, sp, #0x610
    1748:      	bl	0x1748 <_stogir.pipeline.prepare-checked+0xe68>
		0000000000001748:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.place!
    174c:      	add	x16, sp, #0x800
    1750:      	ldr	w0, [x16]
    1754:      	lsr	x16, x0, #0
    1758:      	cmp	x16, #0x1
    175c:      	b.eq	0x1778 <_stogir.pipeline.prepare-checked+0xe98>
    1760:      	b.lo	0x1768 <_stogir.pipeline.prepare-checked+0xe88>
    1764:      	b	0x177c <_stogir.pipeline.prepare-checked+0xe9c>
    1768:      	cmp	x16, #0x0
    176c:      	b.eq	0x1774 <_stogir.pipeline.prepare-checked+0xe94>
    1770:      	b	0x177c <_stogir.pipeline.prepare-checked+0xe9c>
    1774:      	b	0x1798 <_stogir.pipeline.prepare-checked+0xeb8>
    1778:      	b	0x1780 <_stogir.pipeline.prepare-checked+0xea0>
    177c:      	b	0x1c20 <_stogir.pipeline.prepare-checked+0x1340>
    1780:      	add	x16, sp, #0x800
    1784:      	orr	x0, x16, xzr
    1788:      	add	x0, x0, #0x8
    178c:      	add	x16, sp, #0x800
    1790:      	ldr	x21, [x16, #0x8]
    1794:      	ldr	x22, [x0, #0x8]
    1798:      	cmp	x22, #0x0
    179c:      	b.ne	0x180c <_stogir.pipeline.prepare-checked+0xf2c>
    17a0:      	add	x8, sp, #0x820
    17a4:      	add	x0, sp, #0x330
    17a8:      	add	x1, sp, #0x450
    17ac:      	add	x2, sp, #0x550
    17b0:      	add	x3, sp, #0x5b0
    17b4:      	add	x4, sp, #0x4f0
    17b8:      	mov	x5, x24
    17bc:      	bl	0x17bc <_stogir.pipeline.prepare-checked+0xedc>
		00000000000017bc:  ARM64_RELOC_BRANCH26	_stogir.loops.reorder!
    17c0:      	add	x16, sp, #0x820
    17c4:      	ldr	w0, [x16]
    17c8:      	lsr	x16, x0, #0
    17cc:      	cmp	x16, #0x1
    17d0:      	b.eq	0x17ec <_stogir.pipeline.prepare-checked+0xf0c>
    17d4:      	b.lo	0x17dc <_stogir.pipeline.prepare-checked+0xefc>
    17d8:      	b	0x17f0 <_stogir.pipeline.prepare-checked+0xf10>
    17dc:      	cmp	x16, #0x0
    17e0:      	b.eq	0x17e8 <_stogir.pipeline.prepare-checked+0xf08>
    17e4:      	b	0x17f0 <_stogir.pipeline.prepare-checked+0xf10>
    17e8:      	b	0x180c <_stogir.pipeline.prepare-checked+0xf2c>
    17ec:      	b	0x17f4 <_stogir.pipeline.prepare-checked+0xf14>
    17f0:      	b	0x1c28 <_stogir.pipeline.prepare-checked+0x1348>
    17f4:      	add	x16, sp, #0x820
    17f8:      	orr	x0, x16, xzr
    17fc:      	add	x0, x0, #0x8
    1800:      	add	x16, sp, #0x820
    1804:      	ldr	x21, [x16, #0x8]
    1808:      	ldr	x22, [x0, #0x8]
    180c:      	cmp	x22, #0x0
    1810:      	b.ne	0x187c <_stogir.pipeline.prepare-checked+0xf9c>
    1814:      	add	x16, sp, #0x840
    1818:      	orr	x23, x16, xzr
    181c:      	add	x8, sp, #0x840
    1820:      	mov	x0, x20
    1824:      	add	x1, sp, #0x790
    1828:      	add	x2, sp, #0x610
    182c:      	add	x3, sp, #0x670
    1830:      	mov	x4, x24
    1834:      	bl	0x1834 <_stogir.pipeline.prepare-checked+0xf54>
		0000000000001834:  ARM64_RELOC_BRANCH26	_stogir.schedule.order-with-uses
    1838:      	add	x16, sp, #0x840
    183c:      	ldr	w0, [x16]
    1840:      	lsr	x16, x0, #0
    1844:      	cmp	x16, #0x1
    1848:      	b.eq	0x1864 <_stogir.pipeline.prepare-checked+0xf84>
    184c:      	b.lo	0x1854 <_stogir.pipeline.prepare-checked+0xf74>
    1850:      	b	0x1868 <_stogir.pipeline.prepare-checked+0xf88>
    1854:      	cmp	x16, #0x0
    1858:      	b.eq	0x1860 <_stogir.pipeline.prepare-checked+0xf80>
    185c:      	b	0x1868 <_stogir.pipeline.prepare-checked+0xf88>
    1860:      	b	0x1910 <_stogir.pipeline.prepare-checked+0x1030>
    1864:      	b	0x186c <_stogir.pipeline.prepare-checked+0xf8c>
    1868:      	b	0x1c30 <_stogir.pipeline.prepare-checked+0x1350>
    186c:      	add	x0, x23, #0x8
    1870:      	add	x16, sp, #0x840
    1874:      	ldr	x21, [x16, #0x8]
    1878:      	ldr	x22, [x0, #0x8]
    187c:      	b	0x188c <_stogir.pipeline.prepare-checked+0xfac>
    1880:      	sub	x0, x0, #0x1
    1884:      	add	x16, sp, #0x790
    1888:      	str	x0, [x16, #0x8]
    188c:      	add	x16, sp, #0x790
    1890:      	ldr	x0, [x16, #0x8]
    1894:      	cmp	x0, #0x0
    1898:      	b.ne	0x1880 <_stogir.pipeline.prepare-checked+0xfa0>
    189c:      	add	x16, sp, #0x790
    18a0:      	orr	x0, x16, xzr
    18a4:      	add	x16, sp, #0x790
    18a8:      	ldr	x1, [x16, #0x10]
    18ac:      	cmp	x1, #0x0
    18b0:      	b.le	0x18e0 <_stogir.pipeline.prepare-checked+0x1000>
    18b4:      	add	x0, x0, #0x18
    18b8:      	add	x16, sp, #0x790
    18bc:      	ldr	x2, [x16]
    18c0:      	fmov	d31, x1
    18c4:      	mov	x1, x2
    18c8:      	fmov	x2, d31
    18cc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		00000000000018cc:  ARM64_RELOC_PAGE21	l_stogir.395
    18d0:      	ldr	x3, [x3]
		00000000000018d0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    18d4:      	mov	x4, #0x4                ; =4
    18d8:      	mov	x5, #0x4                ; =4
    18dc:      	bl	0x18dc <_stogir.pipeline.prepare-checked+0xffc>
		00000000000018dc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    18e0:      	add	x16, sp, #0x790
    18e4:      	movz	x17, #0x0, lsl #48
    18e8:      	str	x17, [x16]
    18ec:      	add	x16, sp, #0x790
    18f0:      	movz	x17, #0x0, lsl #48
    18f4:      	str	x17, [x16, #0x8]
    18f8:      	add	x16, sp, #0x790
    18fc:      	movz	x17, #0x0, lsl #48
    1900:      	str	x17, [x16, #0x10]
    1904:      	b	0xf9c <_stogir.pipeline.prepare-checked+0x6bc>
    1908:      	brk	#0
    190c:      	b	0x1908 <_stogir.pipeline.prepare-checked+0x1028>
    1910:      	add	x0, x23, #0x8
    1914:      	add	x16, sp, #0x840
    1918:      	ldr	x1, [x16, #0x8]
    191c:      	ldr	x2, [x0, #0x8]
    1920:      	ldr	x3, [x0, #0x10]
    1924:      	ldr	x4, [x0, #0x18]
    1928:      	ldr	x0, [x0, #0x20]
    192c:      	add	x16, sp, #0x870
    1930:      	str	x1, [x16]
    1934:      	add	x16, sp, #0x870
    1938:      	str	x2, [x16, #0x8]
    193c:      	add	x16, sp, #0x870
    1940:      	str	x3, [x16, #0x10]
    1944:      	add	x16, sp, #0x870
    1948:      	str	x4, [x16, #0x18]
    194c:      	add	x16, sp, #0x870
    1950:      	str	x0, [x16, #0x20]
    1954:      	b	0x1964 <_stogir.pipeline.prepare-checked+0x1084>
    1958:      	sub	x0, x0, #0x1
    195c:      	add	x16, sp, #0x710
    1960:      	str	x0, [x16, #0x8]
    1964:      	add	x16, sp, #0x710
    1968:      	ldr	x0, [x16, #0x8]
    196c:      	cmp	x0, #0x0
    1970:      	b.ne	0x1958 <_stogir.pipeline.prepare-checked+0x1078>
    1974:      	add	x16, sp, #0x710
    1978:      	orr	x0, x16, xzr
    197c:      	add	x16, sp, #0x710
    1980:      	ldr	x1, [x16, #0x10]
    1984:      	cmp	x1, #0x0
    1988:      	b.le	0x19b8 <_stogir.pipeline.prepare-checked+0x10d8>
    198c:      	add	x0, x0, #0x18
    1990:      	add	x16, sp, #0x710
    1994:      	ldr	x2, [x16]
    1998:      	fmov	d31, x1
    199c:      	mov	x1, x2
    19a0:      	fmov	x2, d31
    19a4:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		00000000000019a4:  ARM64_RELOC_PAGE21	l_stogir.397
    19a8:      	ldr	x3, [x3]
		00000000000019a8:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    19ac:      	mov	x4, #0x10               ; =16
    19b0:      	mov	x5, #0x8                ; =8
    19b4:      	bl	0x19b4 <_stogir.pipeline.prepare-checked+0x10d4>
		00000000000019b4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    19b8:      	add	x16, sp, #0x710
    19bc:      	orr	x0, x16, xzr
    19c0:      	add	x23, x0, #0x28
    19c4:      	add	x16, sp, #0x710
    19c8:      	movz	x17, #0x0, lsl #48
    19cc:      	str	x17, [x16]
    19d0:      	add	x16, sp, #0x710
    19d4:      	movz	x17, #0x0, lsl #48
    19d8:      	str	x17, [x16, #0x8]
    19dc:      	add	x16, sp, #0x710
    19e0:      	movz	x17, #0x0, lsl #48
    19e4:      	str	x17, [x16, #0x10]
    19e8:      	b	0x19f8 <_stogir.pipeline.prepare-checked+0x1118>
    19ec:      	nop
    19f0:      	sub	x0, x0, #0x1
    19f4:      	str	x0, [x23, #0x8]
    19f8:      	ldr	x0, [x23, #0x8]
    19fc:      	cmp	x0, #0x0
    1a00:      	b.ne	0x19f0 <_stogir.pipeline.prepare-checked+0x1110>
    1a04:      	ldr	x0, [x23, #0x10]
    1a08:      	cmp	x0, #0x0
    1a0c:      	b.le	0x1a40 <_stogir.pipeline.prepare-checked+0x1160>
    1a10:      	add	x1, x23, #0x18
    1a14:      	add	x16, sp, #0x710
    1a18:      	ldr	x2, [x16, #0x28]
    1a1c:      	fmov	d31, x0
    1a20:      	mov	x0, x1
    1a24:      	mov	x1, x2
    1a28:      	fmov	x2, d31
    1a2c:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001a2c:  ARM64_RELOC_PAGE21	l_stogir.395
    1a30:      	ldr	x3, [x3]
		0000000000001a30:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1a34:      	mov	x4, #0x4                ; =4
    1a38:      	mov	x5, #0x4                ; =4
    1a3c:      	bl	0x1a3c <_stogir.pipeline.prepare-checked+0x115c>
		0000000000001a3c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1a40:      	add	x16, sp, #0x710
    1a44:      	movz	x17, #0x0, lsl #48
    1a48:      	str	x17, [x16, #0x28]
    1a4c:      	movz	x17, #0x0, lsl #48
    1a50:      	str	x17, [x23, #0x8]
    1a54:      	movz	x17, #0x0, lsl #48
    1a58:      	str	x17, [x23, #0x10]
    1a5c:      	add	x8, sp, #0x8a0
    1a60:      	add	x0, sp, #0x870
    1a64:      	add	x1, sp, #0x790
    1a68:      	add	x2, sp, #0x4f0
    1a6c:      	mov	x3, x24
    1a70:      	bl	0x1a70 <_stogir.pipeline.prepare-checked+0x1190>
		0000000000001a70:  ARM64_RELOC_BRANCH26	_stogir.schedule.pack
    1a74:      	add	x16, sp, #0x8a0
    1a78:      	ldr	x0, [x16]
    1a7c:      	add	x16, sp, #0x710
    1a80:      	str	x0, [x16]
    1a84:      	add	x16, sp, #0x8a0
    1a88:      	ldr	x0, [x16, #0x8]
    1a8c:      	add	x16, sp, #0x710
    1a90:      	str	x0, [x16, #0x8]
    1a94:      	add	x16, sp, #0x8a0
    1a98:      	ldr	x0, [x16, #0x10]
    1a9c:      	add	x16, sp, #0x710
    1aa0:      	str	x0, [x16, #0x10]
    1aa4:      	add	x16, sp, #0x8a0
    1aa8:      	ldr	x0, [x16, #0x18]
    1aac:      	add	x16, sp, #0x710
    1ab0:      	str	x0, [x16, #0x18]
    1ab4:      	add	x16, sp, #0x8a0
    1ab8:      	ldr	x0, [x16, #0x20]
    1abc:      	add	x16, sp, #0x710
    1ac0:      	str	x0, [x16, #0x20]
    1ac4:      	add	x16, sp, #0x8a0
    1ac8:      	ldr	x0, [x16, #0x28]
    1acc:      	add	x16, sp, #0x710
    1ad0:      	str	x0, [x16, #0x28]
    1ad4:      	add	x16, sp, #0x8a0
    1ad8:      	ldr	x0, [x16, #0x30]
    1adc:      	add	x16, sp, #0x710
    1ae0:      	str	x0, [x16, #0x30]
    1ae4:      	add	x16, sp, #0x8a0
    1ae8:      	ldr	x0, [x16, #0x38]
    1aec:      	add	x16, sp, #0x710
    1af0:      	str	x0, [x16, #0x38]
    1af4:      	add	x16, sp, #0x8a0
    1af8:      	ldr	x0, [x16, #0x40]
    1afc:      	add	x16, sp, #0x710
    1b00:      	str	x0, [x16, #0x40]
    1b04:      	add	x16, sp, #0x8a0
    1b08:      	ldr	x0, [x16, #0x48]
    1b0c:      	add	x16, sp, #0x710
    1b10:      	str	x0, [x16, #0x48]
    1b14:      	add	x8, sp, #0x8f0
    1b18:      	mov	x0, x20
    1b1c:      	add	x1, sp, #0x790
    1b20:      	add	x2, sp, #0x710
    1b24:      	mov	x3, x24
    1b28:      	bl	0x1b28 <_stogir.pipeline.prepare-checked+0x1248>
		0000000000001b28:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.cluster!
    1b2c:      	add	x16, sp, #0x8f0
    1b30:      	ldr	w0, [x16]
    1b34:      	lsr	x16, x0, #0
    1b38:      	cmp	x16, #0x1
    1b3c:      	b.eq	0x1b58 <_stogir.pipeline.prepare-checked+0x1278>
    1b40:      	b.lo	0x1b48 <_stogir.pipeline.prepare-checked+0x1268>
    1b44:      	b	0x1b5c <_stogir.pipeline.prepare-checked+0x127c>
    1b48:      	cmp	x16, #0x0
    1b4c:      	b.eq	0x1b54 <_stogir.pipeline.prepare-checked+0x1274>
    1b50:      	b	0x1b5c <_stogir.pipeline.prepare-checked+0x127c>
    1b54:      	b	0x1b78 <_stogir.pipeline.prepare-checked+0x1298>
    1b58:      	b	0x1b60 <_stogir.pipeline.prepare-checked+0x1280>
    1b5c:      	b	0x1c38 <_stogir.pipeline.prepare-checked+0x1358>
    1b60:      	add	x16, sp, #0x8f0
    1b64:      	orr	x0, x16, xzr
    1b68:      	add	x0, x0, #0x8
    1b6c:      	add	x16, sp, #0x8f0
    1b70:      	ldr	x21, [x16, #0x8]
    1b74:      	ldr	x22, [x0, #0x8]
    1b78:      	b	0x1b8c <_stogir.pipeline.prepare-checked+0x12ac>
    1b7c:      	nop
    1b80:      	sub	x0, x0, #0x1
    1b84:      	add	x16, sp, #0x870
    1b88:      	str	x0, [x16, #0x8]
    1b8c:      	add	x16, sp, #0x870
    1b90:      	ldr	x0, [x16, #0x8]
    1b94:      	cmp	x0, #0x0
    1b98:      	b.ne	0x1b80 <_stogir.pipeline.prepare-checked+0x12a0>
    1b9c:      	add	x16, sp, #0x870
    1ba0:      	orr	x0, x16, xzr
    1ba4:      	add	x16, sp, #0x870
    1ba8:      	ldr	x1, [x16, #0x10]
    1bac:      	cmp	x1, #0x0
    1bb0:      	b.le	0x1be0 <_stogir.pipeline.prepare-checked+0x1300>
    1bb4:      	add	x0, x0, #0x18
    1bb8:      	add	x16, sp, #0x870
    1bbc:      	ldr	x2, [x16]
    1bc0:      	fmov	d31, x1
    1bc4:      	mov	x1, x2
    1bc8:      	fmov	x2, d31
    1bcc:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001bcc:  ARM64_RELOC_PAGE21	l_stogir.395
    1bd0:      	ldr	x3, [x3]
		0000000000001bd0:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    1bd4:      	mov	x4, #0x4                ; =4
    1bd8:      	mov	x5, #0x4                ; =4
    1bdc:      	bl	0x1bdc <_stogir.pipeline.prepare-checked+0x12fc>
		0000000000001bdc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1be0:      	add	x16, sp, #0x870
    1be4:      	movz	x17, #0x0, lsl #48
    1be8:      	str	x17, [x16]
    1bec:      	add	x16, sp, #0x870
    1bf0:      	movz	x17, #0x0, lsl #48
    1bf4:      	str	x17, [x16, #0x8]
    1bf8:      	add	x16, sp, #0x870
    1bfc:      	movz	x17, #0x0, lsl #48
    1c00:      	str	x17, [x16, #0x10]
    1c04:      	b	0x187c <_stogir.pipeline.prepare-checked+0xf9c>
    1c08:      	brk	#0
    1c0c:      	b	0x1c08 <_stogir.pipeline.prepare-checked+0x1328>
    1c10:      	brk	#0
    1c14:      	b	0x1c10 <_stogir.pipeline.prepare-checked+0x1330>
    1c18:      	brk	#0
    1c1c:      	b	0x1c18 <_stogir.pipeline.prepare-checked+0x1338>
    1c20:      	brk	#0
    1c24:      	b	0x1c20 <_stogir.pipeline.prepare-checked+0x1340>
    1c28:      	brk	#0
    1c2c:      	b	0x1c28 <_stogir.pipeline.prepare-checked+0x1348>
    1c30:      	brk	#0
    1c34:      	b	0x1c30 <_stogir.pipeline.prepare-checked+0x1350>
    1c38:      	brk	#0
    1c3c:      	b	0x1c38 <_stogir.pipeline.prepare-checked+0x1358>
    1c40:      	str	x19, [sp, #0xed8]
    1c44:      	b	0x928 <_stogir.pipeline.prepare-checked+0x48>
    1c48:      	str	x19, [sp, #0xed8]
    1c4c:      	b	0x16a8 <_stogir.pipeline.prepare-checked+0xdc8>

0000000000001c50 <_stogir.cfg.release!>:
    1c50:      	sub	sp, sp, #0x30
    1c54:      	str	x29, [sp]
    1c58:      	str	x30, [sp, #0x8]
    1c5c:      	mov	x29, sp
    1c60:      	str	x19, [sp, #0x10]
    1c64:      	str	x20, [sp, #0x18]
    1c68:      	str	x21, [sp, #0x20]
    1c6c:      	b	0x1c78 <_stogir.cfg.release!+0x28>
    1c70:      	sub	x1, x1, #0x1
    1c74:      	str	x1, [x0, #0x8]
    1c78:      	ldr	x1, [x0, #0x8]
    1c7c:      	cmp	x1, #0x0
    1c80:      	b.ne	0x1c70 <_stogir.cfg.release!+0x20>
    1c84:      	ldr	x1, [x0, #0x10]
    1c88:      	cmp	x1, #0x0
    1c8c:      	b.le	0x1dd0 <_stogir.cfg.release!+0x180>
    1c90:      	add	x2, x0, #0x18
    1c94:      	ldr	x3, [x0]
    1c98:      	mov	x19, x0
    1c9c:      	mov	x0, x2
    1ca0:      	mov	x2, x1
    1ca4:      	mov	x1, x3
    1ca8:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001ca8:  ARM64_RELOC_PAGE21	l_stogir.398
    1cac:      	ldr	x3, [x3]
		0000000000001cac:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    1cb0:      	mov	x4, #0x4                ; =4
    1cb4:      	mov	x5, #0x4                ; =4
    1cb8:      	bl	0x1cb8 <_stogir.cfg.release!+0x68>
		0000000000001cb8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1cbc:      	add	x20, x19, #0x28
    1cc0:      	movz	x17, #0x0, lsl #48
    1cc4:      	str	x17, [x19]
    1cc8:      	movz	x17, #0x0, lsl #48
    1ccc:      	str	x17, [x19, #0x8]
    1cd0:      	movz	x17, #0x0, lsl #48
    1cd4:      	str	x17, [x19, #0x10]
    1cd8:      	b	0x1ce8 <_stogir.cfg.release!+0x98>
    1cdc:      	nop
    1ce0:      	sub	x0, x0, #0x1
    1ce4:      	str	x0, [x20, #0x8]
    1ce8:      	ldr	x0, [x20, #0x8]
    1cec:      	cmp	x0, #0x0
    1cf0:      	b.ne	0x1ce0 <_stogir.cfg.release!+0x90>
    1cf4:      	ldr	x0, [x20, #0x10]
    1cf8:      	cmp	x0, #0x0
    1cfc:      	b.le	0x1d2c <_stogir.cfg.release!+0xdc>
    1d00:      	add	x1, x20, #0x18
    1d04:      	ldr	x2, [x19, #0x28]
    1d08:      	fmov	d31, x0
    1d0c:      	mov	x0, x1
    1d10:      	mov	x1, x2
    1d14:      	fmov	x2, d31
    1d18:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001d18:  ARM64_RELOC_PAGE21	l_stogir.398
    1d1c:      	ldr	x3, [x3]
		0000000000001d1c:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    1d20:      	mov	x4, #0x4                ; =4
    1d24:      	mov	x5, #0x4                ; =4
    1d28:      	bl	0x1d28 <_stogir.cfg.release!+0xd8>
		0000000000001d28:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1d2c:      	add	x21, x19, #0x50
    1d30:      	movz	x17, #0x0, lsl #48
    1d34:      	str	x17, [x19, #0x28]
    1d38:      	movz	x17, #0x0, lsl #48
    1d3c:      	str	x17, [x20, #0x8]
    1d40:      	movz	x17, #0x0, lsl #48
    1d44:      	str	x17, [x20, #0x10]
    1d48:      	b	0x1d58 <_stogir.cfg.release!+0x108>
    1d4c:      	nop
    1d50:      	sub	x0, x0, #0x1
    1d54:      	str	x0, [x21, #0x8]
    1d58:      	ldr	x0, [x21, #0x8]
    1d5c:      	cmp	x0, #0x0
    1d60:      	b.ne	0x1d50 <_stogir.cfg.release!+0x100>
    1d64:      	ldr	x0, [x21, #0x10]
    1d68:      	cmp	x0, #0x0
    1d6c:      	b.le	0x1d9c <_stogir.cfg.release!+0x14c>
    1d70:      	add	x1, x21, #0x18
    1d74:      	ldr	x2, [x19, #0x50]
    1d78:      	fmov	d31, x0
    1d7c:      	mov	x0, x1
    1d80:      	mov	x1, x2
    1d84:      	fmov	x2, d31
    1d88:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001d88:  ARM64_RELOC_PAGE21	l_stogir.399
    1d8c:      	ldr	x3, [x3]
		0000000000001d8c:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    1d90:      	mov	x4, #0x10               ; =16
    1d94:      	mov	x5, #0x4                ; =4
    1d98:      	bl	0x1d98 <_stogir.cfg.release!+0x148>
		0000000000001d98:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1d9c:      	movz	x17, #0x0, lsl #48
    1da0:      	str	x17, [x19, #0x50]
    1da4:      	movz	x17, #0x0, lsl #48
    1da8:      	str	x17, [x21, #0x8]
    1dac:      	movz	x17, #0x0, lsl #48
    1db0:      	str	x17, [x21, #0x10]
    1db4:      	ldr	x19, [sp, #0x10]
    1db8:      	ldr	x20, [sp, #0x18]
    1dbc:      	ldr	x21, [sp, #0x20]
    1dc0:      	ldr	x29, [sp]
    1dc4:      	ldr	x30, [sp, #0x8]
    1dc8:      	add	sp, sp, #0x30
    1dcc:      	ret
    1dd0:      	mov	x19, x0
    1dd4:      	b	0x1cbc <_stogir.cfg.release!+0x6c>

0000000000001dd8 <_inherent$coil.arraylist.ArrayList$free!__i32>:
    1dd8:      	sub	sp, sp, #0x20
    1ddc:      	str	x29, [sp]
    1de0:      	str	x30, [sp, #0x8]
    1de4:      	mov	x29, sp
    1de8:      	str	x19, [sp, #0x10]
    1dec:      	b	0x1df8 <_inherent$coil.arraylist.ArrayList$free!__i32+0x20>
    1df0:      	sub	x1, x1, #0x1
    1df4:      	str	x1, [x0, #0x8]
    1df8:      	ldr	x1, [x0, #0x8]
    1dfc:      	cmp	x1, #0x0
    1e00:      	b.ne	0x1df0 <_inherent$coil.arraylist.ArrayList$free!__i32+0x18>
    1e04:      	ldr	x1, [x0, #0x10]
    1e08:      	cmp	x1, #0x0
    1e0c:      	b.le	0x1e6c <_inherent$coil.arraylist.ArrayList$free!__i32+0x94>
    1e10:      	add	x2, x0, #0x18
    1e14:      	ldr	x3, [x0]
    1e18:      	mov	x19, x0
    1e1c:      	mov	x0, x2
    1e20:      	mov	x2, x1
    1e24:      	mov	x1, x3
    1e28:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001e28:  ARM64_RELOC_PAGE21	l_stogir.400
    1e2c:      	ldr	x3, [x3]
		0000000000001e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    1e30:      	mov	x4, #0x4                ; =4
    1e34:      	mov	x5, #0x4                ; =4
    1e38:      	bl	0x1e38 <_inherent$coil.arraylist.ArrayList$free!__i32+0x60>
		0000000000001e38:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1e3c:      	movz	x17, #0x0, lsl #48
    1e40:      	str	x17, [x19]
    1e44:      	movz	x17, #0x0, lsl #48
    1e48:      	str	x17, [x19, #0x8]
    1e4c:      	movz	x17, #0x0, lsl #48
    1e50:      	str	x17, [x19, #0x10]
    1e54:      	movz	x0, #0x0, lsl #48
    1e58:      	ldr	x19, [sp, #0x10]
    1e5c:      	ldr	x29, [sp]
    1e60:      	ldr	x30, [sp, #0x8]
    1e64:      	add	sp, sp, #0x20
    1e68:      	ret
    1e6c:      	mov	x19, x0
    1e70:      	b	0x1e3c <_inherent$coil.arraylist.ArrayList$free!__i32+0x64>
    1e74:      	udf	#0x0

0000000000001e78 <_stogir.schedule.release!>:
    1e78:      	sub	sp, sp, #0x20
    1e7c:      	str	x29, [sp]
    1e80:      	str	x30, [sp, #0x8]
    1e84:      	mov	x29, sp
    1e88:      	str	x19, [sp, #0x10]
    1e8c:      	str	x20, [sp, #0x18]
    1e90:      	b	0x1ea0 <_stogir.schedule.release!+0x28>
    1e94:      	nop
    1e98:      	sub	x1, x1, #0x1
    1e9c:      	str	x1, [x0, #0x8]
    1ea0:      	ldr	x1, [x0, #0x8]
    1ea4:      	cmp	x1, #0x0
    1ea8:      	b.ne	0x1e98 <_stogir.schedule.release!+0x20>
    1eac:      	ldr	x1, [x0, #0x10]
    1eb0:      	cmp	x1, #0x0
    1eb4:      	b.le	0x1f84 <_stogir.schedule.release!+0x10c>
    1eb8:      	add	x2, x0, #0x18
    1ebc:      	ldr	x3, [x0]
    1ec0:      	mov	x19, x0
    1ec4:      	mov	x0, x2
    1ec8:      	mov	x2, x1
    1ecc:      	mov	x1, x3
    1ed0:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001ed0:  ARM64_RELOC_PAGE21	l_stogir.401
    1ed4:      	ldr	x3, [x3]
		0000000000001ed4:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    1ed8:      	mov	x4, #0x10               ; =16
    1edc:      	mov	x5, #0x8                ; =8
    1ee0:      	bl	0x1ee0 <_stogir.schedule.release!+0x68>
		0000000000001ee0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1ee4:      	add	x20, x19, #0x28
    1ee8:      	movz	x17, #0x0, lsl #48
    1eec:      	str	x17, [x19]
    1ef0:      	movz	x17, #0x0, lsl #48
    1ef4:      	str	x17, [x19, #0x8]
    1ef8:      	movz	x17, #0x0, lsl #48
    1efc:      	str	x17, [x19, #0x10]
    1f00:      	b	0x1f10 <_stogir.schedule.release!+0x98>
    1f04:      	nop
    1f08:      	sub	x0, x0, #0x1
    1f0c:      	str	x0, [x20, #0x8]
    1f10:      	ldr	x0, [x20, #0x8]
    1f14:      	cmp	x0, #0x0
    1f18:      	b.ne	0x1f08 <_stogir.schedule.release!+0x90>
    1f1c:      	ldr	x0, [x20, #0x10]
    1f20:      	cmp	x0, #0x0
    1f24:      	b.le	0x1f54 <_stogir.schedule.release!+0xdc>
    1f28:      	add	x1, x20, #0x18
    1f2c:      	ldr	x2, [x19, #0x28]
    1f30:      	fmov	d31, x0
    1f34:      	mov	x0, x1
    1f38:      	mov	x1, x2
    1f3c:      	fmov	x2, d31
    1f40:      	adrp	x3, 0x1000 <_stogir.pipeline.prepare-checked+0x720>
		0000000000001f40:  ARM64_RELOC_PAGE21	l_stogir.402
    1f44:      	ldr	x3, [x3]
		0000000000001f44:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    1f48:      	mov	x4, #0x4                ; =4
    1f4c:      	mov	x5, #0x4                ; =4
    1f50:      	bl	0x1f50 <_stogir.schedule.release!+0xd8>
		0000000000001f50:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    1f54:      	movz	x17, #0x0, lsl #48
    1f58:      	str	x17, [x19, #0x28]
    1f5c:      	movz	x17, #0x0, lsl #48
    1f60:      	str	x17, [x20, #0x8]
    1f64:      	movz	x17, #0x0, lsl #48
    1f68:      	str	x17, [x20, #0x10]
    1f6c:      	ldr	x19, [sp, #0x10]
    1f70:      	ldr	x20, [sp, #0x18]
    1f74:      	ldr	x29, [sp]
    1f78:      	ldr	x30, [sp, #0x8]
    1f7c:      	add	sp, sp, #0x20
    1f80:      	ret
    1f84:      	mov	x19, x0
    1f88:      	b	0x1ee4 <_stogir.schedule.release!+0x6c>

0000000000001f8c <_stogir.verify.schedule-input>:
    1f8c:      	sub	sp, sp, #0x80
    1f90:      	str	x29, [sp]
    1f94:      	str	x30, [sp, #0x8]
    1f98:      	mov	x29, sp
    1f9c:      	str	x19, [sp, #0x50]
    1fa0:      	str	x20, [sp, #0x58]
    1fa4:      	str	x21, [sp, #0x60]
    1fa8:      	str	x22, [sp, #0x68]
    1fac:      	str	x23, [sp, #0x70]
    1fb0:      	mov	x19, x8
    1fb4:      	add	x8, sp, #0x10
    1fb8:      	mov	x20, x0
    1fbc:      	mov	w21, w1
    1fc0:      	mov	x22, x2
    1fc4:      	mov	x23, x3
    1fc8:      	bl	0x1fc8 <_stogir.verify.schedule-input+0x3c>
		0000000000001fc8:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    1fcc:      	add	x16, sp, #0x10
    1fd0:      	ldr	w0, [x16]
    1fd4:      	lsr	x16, x0, #0
    1fd8:      	cmp	x16, #0x1
    1fdc:      	b.eq	0x1ff8 <_stogir.verify.schedule-input+0x6c>
    1fe0:      	b.lo	0x1fe8 <_stogir.verify.schedule-input+0x5c>
    1fe4:      	b	0x1ffc <_stogir.verify.schedule-input+0x70>
    1fe8:      	cmp	x16, #0x0
    1fec:      	b.eq	0x1ff4 <_stogir.verify.schedule-input+0x68>
    1ff0:      	b	0x1ffc <_stogir.verify.schedule-input+0x70>
    1ff4:      	b	0x2020 <_stogir.verify.schedule-input+0x94>
    1ff8:      	b	0x2000 <_stogir.verify.schedule-input+0x74>
    1ffc:      	b	0x2080 <_stogir.verify.schedule-input+0xf4>
    2000:      	add	x16, sp, #0x10
    2004:      	orr	x0, x16, xzr
    2008:      	add	x0, x0, #0x8
    200c:      	add	x16, sp, #0x10
    2010:      	ldr	x1, [x16, #0x8]
    2014:      	ldr	x0, [x0, #0x8]
    2018:      	mov	x2, #0x1                ; =1
    201c:      	b	0x2050 <_stogir.verify.schedule-input+0xc4>
    2020:      	add	x8, sp, #0x30
    2024:      	mov	x0, x20
    2028:      	mov	w1, w21
    202c:      	mov	x2, x22
    2030:      	mov	x3, x23
    2034:      	bl	0x2034 <_stogir.verify.schedule-input+0xa8>
		0000000000002034:  ARM64_RELOC_BRANCH26	_stogir.verify.schedule-input-structured
    2038:      	add	x16, sp, #0x30
    203c:      	ldr	x2, [x16]
    2040:      	add	x16, sp, #0x30
    2044:      	ldr	x1, [x16, #0x8]
    2048:      	add	x16, sp, #0x30
    204c:      	ldr	x0, [x16, #0x10]
    2050:      	str	x2, [x19]
    2054:      	str	x1, [x19, #0x8]
    2058:      	str	x0, [x19, #0x10]
    205c:      	ldr	x19, [sp, #0x50]
    2060:      	ldr	x20, [sp, #0x58]
    2064:      	ldr	x21, [sp, #0x60]
    2068:      	ldr	x22, [sp, #0x68]
    206c:      	ldr	x23, [sp, #0x70]
    2070:      	ldr	x29, [sp]
    2074:      	ldr	x30, [sp, #0x8]
    2078:      	add	sp, sp, #0x80
    207c:      	ret
    2080:      	brk	#0
    2084:      	b	0x2080 <_stogir.verify.schedule-input+0xf4>

0000000000002088 <_stogir.graph.contains?>:
    2088:      	sxtw	x1, w1
    208c:      	cmp	x1, #0x0
    2090:      	b.le	0x20d0 <_stogir.graph.contains?+0x48>
    2094:      	ldr	x2, [x0, #0x8]
    2098:      	cmp	x1, x2
    209c:      	b.ge	0x212c <_stogir.graph.contains?+0xa4>
    20a0:      	add	x2, x0, #0x78
    20a4:      	ldr	x2, [x2, #0x8]
    20a8:      	cmp	x1, x2
    20ac:      	b.ge	0x213c <_stogir.graph.contains?+0xb4>
    20b0:      	ldr	x0, [x0, #0x78]
    20b4:      	add	x0, x0, x1, lsl #2
    20b8:      	ldr	w0, [x0]
    20bc:      	sxtw	x0, w0
    20c0:      	cmp	x0, #0x0
    20c4:      	cset	w0, ge
    20c8:      	ubfx	x0, x0, #0, #8
    20cc:      	b	0x2140 <_stogir.graph.contains?+0xb8>
    20d0:      	cmp	x1, #0x0
    20d4:      	b.ge	0x2134 <_stogir.graph.contains?+0xac>
    20d8:      	add	x2, x0, #0x28
    20dc:      	add	x3, x0, #0x50
    20e0:      	ldr	x2, [x2, #0x8]
    20e4:      	ldr	x3, [x3, #0x8]
    20e8:      	cmp	x2, x3
    20ec:      	b.ne	0x214c <_stogir.graph.contains?+0xc4>
    20f0:      	movz	x16, #0x0, lsl #48
    20f4:      	sub	x3, x16, x1
    20f8:      	cmp	x3, x2
    20fc:      	b.gt	0x2144 <_stogir.graph.contains?+0xbc>
    2100:      	movz	x16, #0x0, lsl #48
    2104:      	sub	x1, x16, x1
    2108:      	sub	x1, x1, #0x1
    210c:      	ldr	x0, [x0, #0x50]
    2110:      	add	x0, x0, x1, lsl #2
    2114:      	ldr	w0, [x0]
    2118:      	sxtw	x0, w0
    211c:      	cmp	x0, #0x0
    2120:      	cset	w0, gt
    2124:      	ubfx	x0, x0, #0, #8
    2128:      	b	0x2148 <_stogir.graph.contains?+0xc0>
    212c:      	movz	x0, #0x0, lsl #48
    2130:      	b	0x2140 <_stogir.graph.contains?+0xb8>
    2134:      	movz	x0, #0x0, lsl #48
    2138:      	b	0x2148 <_stogir.graph.contains?+0xc0>
    213c:      	movz	x0, #0x0, lsl #48
    2140:      	b	0x2148 <_stogir.graph.contains?+0xc0>
    2144:      	movz	x0, #0x0, lsl #48
    2148:      	ret
    214c:      	movz	x0, #0x0, lsl #48
    2150:      	b	0x2148 <_stogir.graph.contains?+0xc0>
    2154:      	udf	#0x0

0000000000002158 <_stogir.cfg.build>:
    2158:      	sub	sp, sp, #0x2e0
    215c:      	str	x29, [sp, #0x10]
    2160:      	str	x30, [sp, #0x18]
    2164:      	add	x29, sp, #0x10
    2168:      	str	x19, [sp, #0x288]
    216c:      	str	x20, [sp, #0x290]
    2170:      	str	x21, [sp, #0x298]
    2174:      	str	x22, [sp, #0x2a0]
    2178:      	str	x23, [sp, #0x2a8]
    217c:      	str	x24, [sp, #0x2b0]
    2180:      	str	x25, [sp, #0x2b8]
    2184:      	str	x26, [sp, #0x2c0]
    2188:      	str	x27, [sp, #0x2c8]
    218c:      	str	x28, [sp, #0x2d0]
    2190:      	mov	x19, x8
    2194:      	add	x8, sp, #0x20
    2198:      	mov	x20, x0
    219c:      	mov	x21, x1
    21a0:      	bl	0x21a0 <_stogir.cfg.build+0x48>
		00000000000021a0:  ARM64_RELOC_BRANCH26	_stogir.verify.control-sources
    21a4:      	add	x16, sp, #0x20
    21a8:      	ldr	w0, [x16]
    21ac:      	lsr	x16, x0, #0
    21b0:      	cmp	x16, #0x1
    21b4:      	b.eq	0x21d0 <_stogir.cfg.build+0x78>
    21b8:      	b.lo	0x21c0 <_stogir.cfg.build+0x68>
    21bc:      	b	0x21d4 <_stogir.cfg.build+0x7c>
    21c0:      	cmp	x16, #0x0
    21c4:      	b.eq	0x21cc <_stogir.cfg.build+0x74>
    21c8:      	b	0x21d4 <_stogir.cfg.build+0x7c>
    21cc:      	b	0x2600 <_stogir.cfg.build+0x4a8>
    21d0:      	b	0x21d8 <_stogir.cfg.build+0x80>
    21d4:      	b	0x2cac <_stogir.cfg.build+0xb54>
    21d8:      	add	x16, sp, #0x20
    21dc:      	orr	x0, x16, xzr
    21e0:      	add	x0, x0, #0x8
    21e4:      	add	x16, sp, #0x20
    21e8:      	ldr	x21, [x16, #0x8]
    21ec:      	ldr	x22, [x0, #0x8]
    21f0:      	str	x19, [sp, #0x258]
    21f4:      	mov	x13, #0x1               ; =1
    21f8:      	movz	x0, #0x0, lsl #48
    21fc:      	movz	x1, #0x0, lsl #48
    2200:      	movz	x2, #0x0, lsl #48
    2204:      	movz	x3, #0x0, lsl #48
    2208:      	movz	x4, #0x0, lsl #48
    220c:      	movz	x5, #0x0, lsl #48
    2210:      	movz	x6, #0x0, lsl #48
    2214:      	movz	x7, #0x0, lsl #48
    2218:      	movz	x8, #0x0, lsl #48
    221c:      	movz	x9, #0x0, lsl #48
    2220:      	movz	x10, #0x0, lsl #48
    2224:      	movz	x11, #0x0, lsl #48
    2228:      	movz	x12, #0x0, lsl #48
    222c:      	b	0x2584 <_stogir.cfg.build+0x42c>
    2230:      	sub	w1, w0, #0x1
    2234:      	lsl	w1, w1, #2
    2238:      	ubfx	x1, x1, #0, #32
    223c:      	lsr	x1, x2, x1
    2240:      	and	w1, w1, #0xf
    2244:      	b	0x22f0 <_stogir.cfg.build+0x198>
    2248:      	lsl	x2, x2, #1
    224c:      	str	w23, [sp, #0x278]
    2250:      	mov	x23, x0
    2254:      	mov	x0, x19
    2258:      	str	w24, [sp, #0x280]
    225c:      	mov	x24, x1
    2260:      	mov	x1, x2
    2264:      	bl	0x2264 <_stogir.cfg.build+0x10c>
		0000000000002264:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge
    2268:      	add	x0, x24, #0x1
    226c:      	add	x16, sp, #0x40
    2270:      	ldr	x1, [x16, #0x50]
    2274:      	add	x1, x1, x24, lsl #4
    2278:      	str	x20, [x1]
    227c:      	str	x23, [x1, #0x8]
    2280:      	str	x0, [x19, #0x8]
    2284:      	add	x0, x28, #0x1
    2288:      	sxtw	x28, w0
    228c:      	ldr	x20, [sp, #0x270]
    2290:      	ldr	w23, [sp, #0x278]
    2294:      	ldr	w24, [sp, #0x280]
    2298:      	cmp	x22, #0x0
    229c:      	b.ne	0x22b0 <_stogir.cfg.build+0x158>
    22a0:      	cmp	x28, x27
    22a4:      	cset	w0, le
    22a8:      	ubfx	x0, x0, #0, #8
    22ac:      	b	0x22b4 <_stogir.cfg.build+0x15c>
    22b0:      	movz	x0, #0x0, lsl #48
    22b4:      	cmp	x0, #0x0
    22b8:      	b.eq	0x2cb4 <_stogir.cfg.build+0xb5c>
    22bc:      	orr	w0, w28, wzr
    22c0:      	uxtb	w16, w25
    22c4:      	cmp	w16, wzr
    22c8:      	b.eq	0x22f4 <_stogir.cfg.build+0x19c>
    22cc:      	sxtw	x1, w0
    22d0:      	ldr	w2, [x26]
    22d4:      	cmp	x1, #0x0
    22d8:      	b.le	0x22ec <_stogir.cfg.build+0x194>
    22dc:      	cmp	x1, #0x4
    22e0:      	b.le	0x2230 <_stogir.cfg.build+0xd8>
    22e4:      	mov	w1, #0x4                ; =4
    22e8:      	b	0x2234 <_stogir.cfg.build+0xdc>
    22ec:      	movz	w1, #0x0, lsl #16
    22f0:      	b	0x22f8 <_stogir.cfg.build+0x1a0>
    22f4:      	movz	w1, #0x0, lsl #16
    22f8:      	adrp	x16, 0x2000 <_stogir.verify.schedule-input+0x74>
		00000000000022f8:  ARM64_RELOC_PAGE21	l_stogir.403
    22fc:      	ldr	x16, [x16]
		00000000000022fc:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    2300:      	ldr	w2, [x16]
    2304:      	ubfx	x1, x1, #0, #32
    2308:      	cmp	x1, x2
    230c:      	b.ne	0x2cbc <_stogir.cfg.build+0xb64>
    2310:      	mov	w1, w23
    2314:      	mov	w2, w0
    2318:      	str	x20, [sp, #0x270]
    231c:      	fmov	s31, w0
    2320:      	mov	x0, x20
    2324:      	fmov	w20, s31
    2328:      	bl	0x2328 <_stogir.cfg.build+0x1d0>
		0000000000002328:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    232c:      	ubfx	x0, x0, #0, #32
    2330:      	lsr	x16, x0, #0
    2334:      	cmp	x16, #0x1
    2338:      	b.eq	0x2354 <_stogir.cfg.build+0x1fc>
    233c:      	b.lo	0x2344 <_stogir.cfg.build+0x1ec>
    2340:      	b	0x2358 <_stogir.cfg.build+0x200>
    2344:      	cmp	x16, #0x0
    2348:      	b.eq	0x2350 <_stogir.cfg.build+0x1f8>
    234c:      	b	0x2358 <_stogir.cfg.build+0x200>
    2350:      	b	0x235c <_stogir.cfg.build+0x204>
    2354:      	b	0x2374 <_stogir.cfg.build+0x21c>
    2358:      	b	0x2c9c <_stogir.cfg.build+0xb44>
    235c:      	str	w23, [sp, #0x278]
    2360:      	str	w24, [sp, #0x280]
    2364:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002364:  ARM64_RELOC_PAGE21	l_stogir.404
    2368:      	ldr	x21, [x21]
		0000000000002368:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    236c:      	mov	x22, #0x19              ; =25
    2370:      	b	0x2284 <_stogir.cfg.build+0x12c>
    2374:      	add	x16, sp, #0x40
    2378:      	ldr	x0, [x16, #0x28]
    237c:      	sxtw	x2, w1
    2380:      	add	x0, x0, x2, lsl #2
    2384:      	ldr	w0, [x0]
    2388:      	sxtw	x2, w0
    238c:      	cmp	x2, #0x0
    2390:      	b.ne	0x24dc <_stogir.cfg.build+0x384>
    2394:      	str	w23, [sp, #0x278]
    2398:      	str	w24, [sp, #0x280]
    239c:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		000000000000239c:  ARM64_RELOC_PAGE21	l_stogir.405
    23a0:      	ldr	x21, [x21]
		00000000000023a0:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    23a4:      	mov	x22, #0x1e              ; =30
    23a8:      	b	0x2284 <_stogir.cfg.build+0x12c>
    23ac:      	ldr	x20, [sp, #0x270]
    23b0:      	add	x0, sp, #0x1d0
    23b4:      	bl	0x23b4 <_stogir.cfg.build+0x25c>
		00000000000023b4:  ARM64_RELOC_BRANCH26	_coil.core.Iterator$coil.slice.SliceIter$next__i32
    23b8:      	ubfx	x0, x0, #0, #32
    23bc:      	lsr	x16, x0, #0
    23c0:      	cmp	x16, #0x1
    23c4:      	b.eq	0x23e0 <_stogir.cfg.build+0x288>
    23c8:      	b.lo	0x23d0 <_stogir.cfg.build+0x278>
    23cc:      	b	0x23e4 <_stogir.cfg.build+0x28c>
    23d0:      	cmp	x16, #0x0
    23d4:      	b.eq	0x23dc <_stogir.cfg.build+0x284>
    23d8:      	b	0x23e4 <_stogir.cfg.build+0x28c>
    23dc:      	b	0x2434 <_stogir.cfg.build+0x2dc>
    23e0:      	b	0x23e8 <_stogir.cfg.build+0x290>
    23e4:      	b	0x2ca4 <_stogir.cfg.build+0xb4c>
    23e8:      	ldr	x0, [x20]
    23ec:      	sxtw	x2, w1
    23f0:      	orr	w23, w1, wzr
    23f4:      	orr	w24, w1, wzr
    23f8:      	add	x0, x0, x2, lsl #4
    23fc:      	ldr	x0, [x0]
    2400:      	ldr	x1, [x20, #0x78]
    2404:      	uxtb	w0, w0
    2408:      	add	x1, x1, x2, lsl #2
    240c:      	cmp	x0, #0x83
    2410:      	cset	w25, lt
    2414:      	adrp	x16, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002414:  ARM64_RELOC_PAGE21	l_stogir.406
    2418:      	ldr	x16, [x16]
		0000000000002418:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    241c:      	add	x0, x16, x0, lsl #2
    2420:      	ldr	w1, [x1]
    2424:      	orr	x26, x0, xzr
    2428:      	sxtw	x27, w1
    242c:      	mov	x28, #0x1               ; =1
    2430:      	b	0x2298 <_stogir.cfg.build+0x140>
    2434:      	add	x0, sp, #0x150
    2438:      	bl	0x2438 <_stogir.cfg.build+0x2e0>
		0000000000002438:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    243c:      	mov	x0, x21
    2440:      	mov	x1, x22
    2444:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002444:  ARM64_RELOC_PAGE21	l_stogir.407
    2448:      	ldr	x2, [x2]
		0000000000002448:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    244c:      	movz	x3, #0x0, lsl #48
    2450:      	bl	0x2450 <_stogir.cfg.build+0x2f8>
		0000000000002450:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2454:      	cmp	x0, #0x0
    2458:      	b.eq	0x2544 <_stogir.cfg.build+0x3ec>
    245c:      	add	x16, sp, #0x40
    2460:      	ldr	x21, [x16]
    2464:      	add	x16, sp, #0x40
    2468:      	ldr	x22, [x16, #0x8]
    246c:      	add	x16, sp, #0x40
    2470:      	ldr	x0, [x16, #0x10]
    2474:      	add	x16, sp, #0x40
    2478:      	ldr	x1, [x16, #0x18]
    247c:      	add	x16, sp, #0x40
    2480:      	ldr	x2, [x16, #0x20]
    2484:      	add	x16, sp, #0x40
    2488:      	ldr	x3, [x16, #0x28]
    248c:      	add	x16, sp, #0x40
    2490:      	ldr	x4, [x16, #0x30]
    2494:      	add	x16, sp, #0x40
    2498:      	ldr	x5, [x16, #0x38]
    249c:      	add	x16, sp, #0x40
    24a0:      	ldr	x6, [x16, #0x40]
    24a4:      	add	x16, sp, #0x40
    24a8:      	ldr	x7, [x16, #0x48]
    24ac:      	add	x16, sp, #0x40
    24b0:      	ldr	x8, [x16, #0x50]
    24b4:      	add	x16, sp, #0x40
    24b8:      	ldr	x9, [x16, #0x58]
    24bc:      	add	x16, sp, #0x40
    24c0:      	ldr	x10, [x16, #0x60]
    24c4:      	add	x16, sp, #0x40
    24c8:      	ldr	x11, [x16, #0x68]
    24cc:      	add	x16, sp, #0x40
    24d0:      	ldr	x12, [x16, #0x70]
    24d4:      	movz	x13, #0x0, lsl #48
    24d8:      	b	0x2584 <_stogir.cfg.build+0x42c>
    24dc:      	add	x16, sp, #0x210
    24e0:      	movz	x17, #0x0, lsl #48
    24e4:      	str	x17, [x16]
    24e8:      	add	x16, sp, #0x210
    24ec:      	movz	x17, #0x0, lsl #48
    24f0:      	str	x17, [x16, #0x8]
    24f4:      	add	x16, sp, #0x210
    24f8:      	str	w0, [x16]
    24fc:      	add	x16, sp, #0x210
    2500:      	str	w24, [x16, #0x4]
    2504:      	add	x16, sp, #0x210
    2508:      	str	w1, [x16, #0x8]
    250c:      	add	x16, sp, #0x210
    2510:      	str	w20, [x16, #0xc]
    2514:      	add	x16, sp, #0x210
    2518:      	ldr	x20, [x16]
    251c:      	add	x16, sp, #0x210
    2520:      	ldr	x0, [x16, #0x8]
    2524:      	ldr	x1, [x19, #0x8]
    2528:      	ldr	x2, [x19, #0x10]
    252c:      	cmp	x1, x2
    2530:      	b.lt	0x2ccc <_stogir.cfg.build+0xb74>
    2534:      	cmp	x2, #0x0
    2538:      	b.ne	0x2248 <_stogir.cfg.build+0xf0>
    253c:      	mov	x2, #0x2                ; =2
    2540:      	b	0x224c <_stogir.cfg.build+0xf4>
    2544:      	add	x0, sp, #0x40
    2548:      	bl	0x2548 <_stogir.cfg.build+0x3f0>
		0000000000002548:  ARM64_RELOC_BRANCH26	_stogir.cfg.release!
    254c:      	mov	x13, #0x1               ; =1
    2550:      	movz	x0, #0x0, lsl #48
    2554:      	movz	x1, #0x0, lsl #48
    2558:      	movz	x2, #0x0, lsl #48
    255c:      	movz	x3, #0x0, lsl #48
    2560:      	movz	x4, #0x0, lsl #48
    2564:      	movz	x5, #0x0, lsl #48
    2568:      	movz	x6, #0x0, lsl #48
    256c:      	movz	x7, #0x0, lsl #48
    2570:      	movz	x8, #0x0, lsl #48
    2574:      	movz	x9, #0x0, lsl #48
    2578:      	movz	x10, #0x0, lsl #48
    257c:      	movz	x11, #0x0, lsl #48
    2580:      	movz	x12, #0x0, lsl #48
    2584:      	ldr	x14, [sp, #0x258]
    2588:      	str	x13, [x14]
    258c:      	str	x21, [x14, #0x8]
    2590:      	str	x22, [x14, #0x10]
    2594:      	str	x0, [x14, #0x18]
    2598:      	str	x1, [x14, #0x20]
    259c:      	str	x2, [x14, #0x28]
    25a0:      	str	x3, [x14, #0x30]
    25a4:      	str	x4, [x14, #0x38]
    25a8:      	str	x5, [x14, #0x40]
    25ac:      	str	x6, [x14, #0x48]
    25b0:      	str	x7, [x14, #0x50]
    25b4:      	str	x8, [x14, #0x58]
    25b8:      	str	x9, [x14, #0x60]
    25bc:      	str	x10, [x14, #0x68]
    25c0:      	str	x11, [x14, #0x70]
    25c4:      	str	x12, [x14, #0x78]
    25c8:      	ldr	x19, [sp, #0x288]
    25cc:      	ldr	x20, [sp, #0x290]
    25d0:      	ldr	x21, [sp, #0x298]
    25d4:      	ldr	x22, [sp, #0x2a0]
    25d8:      	ldr	x23, [sp, #0x2a8]
    25dc:      	ldr	x24, [sp, #0x2b0]
    25e0:      	ldr	x25, [sp, #0x2b8]
    25e4:      	ldr	x26, [sp, #0x2c0]
    25e8:      	ldr	x27, [sp, #0x2c8]
    25ec:      	ldr	x28, [sp, #0x2d0]
    25f0:      	ldr	x29, [sp, #0x10]
    25f4:      	ldr	x30, [sp, #0x18]
    25f8:      	add	sp, sp, #0x2e0
    25fc:      	ret
    2600:      	add	x16, sp, #0x40
    2604:      	orr	x23, x16, xzr
    2608:      	add	x8, sp, #0xc0
    260c:      	mov	x0, x21
    2610:      	bl	0x2610 <_stogir.cfg.build+0x4b8>
		0000000000002610:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    2614:      	add	x24, x20, #0x78
    2618:      	add	x0, x23, #0x28
    261c:      	add	x1, x23, #0x28
    2620:      	add	x16, sp, #0xc0
    2624:      	ldr	x22, [x16]
    2628:      	orr	x25, x0, xzr
    262c:      	orr	x26, x1, xzr
    2630:      	add	x16, sp, #0xc0
    2634:      	ldr	x27, [x16, #0x8]
    2638:      	add	x16, sp, #0xc0
    263c:      	ldr	x28, [x16, #0x10]
    2640:      	add	x16, sp, #0xc0
    2644:      	ldr	x0, [x16, #0x18]
    2648:      	add	x16, sp, #0xc0
    264c:      	ldr	x1, [x16, #0x20]
    2650:      	add	x8, sp, #0xf0
    2654:      	str	x21, [sp, #0x240]
    2658:      	str	x25, [sp, #0x248]
    265c:      	mov	x25, x1
    2660:      	fmov	d31, x0
    2664:      	mov	x0, x21
    2668:      	fmov	x21, d31
    266c:      	bl	0x266c <_stogir.cfg.build+0x514>
		000000000000266c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    2670:      	add	x16, sp, #0xf0
    2674:      	ldr	x0, [x16]
    2678:      	add	x16, sp, #0xf0
    267c:      	ldr	x1, [x16, #0x8]
    2680:      	add	x16, sp, #0xf0
    2684:      	ldr	x2, [x16, #0x10]
    2688:      	add	x16, sp, #0xf0
    268c:      	ldr	x3, [x16, #0x18]
    2690:      	add	x16, sp, #0xf0
    2694:      	ldr	x4, [x16, #0x20]
    2698:      	add	x8, sp, #0x120
    269c:      	str	x26, [sp, #0x250]
    26a0:      	mov	x26, x0
    26a4:      	ldr	x0, [sp, #0x240]
    26a8:      	str	x19, [sp, #0x258]
    26ac:      	mov	x19, x1
    26b0:      	str	x23, [sp, #0x260]
    26b4:      	mov	x23, x2
    26b8:      	str	x24, [sp, #0x268]
    26bc:      	mov	x24, x3
    26c0:      	str	x20, [sp, #0x270]
    26c4:      	mov	x20, x4
    26c8:      	bl	0x26c8 <_stogir.cfg.build+0x570>
		00000000000026c8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge
    26cc:      	add	x16, sp, #0x120
    26d0:      	ldr	x0, [x16]
    26d4:      	add	x16, sp, #0x120
    26d8:      	ldr	x1, [x16, #0x8]
    26dc:      	add	x16, sp, #0x120
    26e0:      	ldr	x2, [x16, #0x10]
    26e4:      	add	x16, sp, #0x120
    26e8:      	ldr	x3, [x16, #0x18]
    26ec:      	add	x16, sp, #0x120
    26f0:      	ldr	x4, [x16, #0x20]
    26f4:      	add	x16, sp, #0x40
    26f8:      	str	x22, [x16]
    26fc:      	add	x16, sp, #0x40
    2700:      	str	x27, [x16, #0x8]
    2704:      	add	x16, sp, #0x40
    2708:      	str	x28, [x16, #0x10]
    270c:      	add	x16, sp, #0x40
    2710:      	str	x21, [x16, #0x18]
    2714:      	add	x16, sp, #0x40
    2718:      	str	x25, [x16, #0x20]
    271c:      	add	x16, sp, #0x40
    2720:      	str	x26, [x16, #0x28]
    2724:      	add	x16, sp, #0x40
    2728:      	str	x19, [x16, #0x30]
    272c:      	add	x16, sp, #0x40
    2730:      	str	x23, [x16, #0x38]
    2734:      	add	x16, sp, #0x40
    2738:      	str	x24, [x16, #0x40]
    273c:      	add	x16, sp, #0x40
    2740:      	str	x20, [x16, #0x48]
    2744:      	add	x16, sp, #0x40
    2748:      	str	x0, [x16, #0x50]
    274c:      	add	x16, sp, #0x40
    2750:      	str	x1, [x16, #0x58]
    2754:      	add	x16, sp, #0x40
    2758:      	str	x2, [x16, #0x60]
    275c:      	add	x16, sp, #0x40
    2760:      	str	x3, [x16, #0x68]
    2764:      	add	x16, sp, #0x40
    2768:      	str	x4, [x16, #0x70]
    276c:      	add	x8, sp, #0x180
    2770:      	ldr	x0, [sp, #0x240]
    2774:      	bl	0x2774 <_stogir.cfg.build+0x61c>
		0000000000002774:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    2778:      	add	x16, sp, #0x180
    277c:      	ldr	x0, [x16]
    2780:      	add	x16, sp, #0x150
    2784:      	str	x0, [x16]
    2788:      	add	x16, sp, #0x180
    278c:      	ldr	x0, [x16, #0x8]
    2790:      	add	x16, sp, #0x150
    2794:      	str	x0, [x16, #0x8]
    2798:      	add	x16, sp, #0x180
    279c:      	ldr	x0, [x16, #0x10]
    27a0:      	add	x16, sp, #0x150
    27a4:      	str	x0, [x16, #0x10]
    27a8:      	add	x16, sp, #0x180
    27ac:      	ldr	x0, [x16, #0x18]
    27b0:      	add	x16, sp, #0x150
    27b4:      	str	x0, [x16, #0x18]
    27b8:      	add	x16, sp, #0x180
    27bc:      	ldr	x0, [x16, #0x20]
    27c0:      	add	x16, sp, #0x150
    27c4:      	str	x0, [x16, #0x20]
    27c8:      	ldr	x0, [sp, #0x270]
    27cc:      	bl	0x27cc <_stogir.cfg.build+0x674>
		00000000000027cc:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    27d0:      	mov	x1, x0
    27d4:      	ldr	x0, [sp, #0x248]
    27d8:      	bl	0x27d8 <_stogir.cfg.build+0x680>
		00000000000027d8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    27dc:      	mov	x19, #0x1               ; =1
    27e0:      	b	0x282c <_stogir.cfg.build+0x6d4>
    27e4:      	nop
    27e8:      	orr	w0, w19, wzr
    27ec:      	orr	w22, w0, wzr
    27f0:      	add	x0, sp, #0x40
    27f4:      	mov	w1, w22
    27f8:      	bl	0x27f8 <_stogir.cfg.build+0x6a0>
		00000000000027f8:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    27fc:      	ldr	x0, [sp, #0x250]
    2800:      	mov	x1, x19
    2804:      	mov	w2, w22
    2808:      	bl	0x2808 <_stogir.cfg.build+0x6b0>
		0000000000002808:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    280c:      	sxtw	x21, w21
    2810:      	add	x0, x21, #0x4
    2814:      	asr	x16, x0, #63
    2818:      	lsr	x16, x16, #62
    281c:      	add	x0, x0, x16
    2820:      	asr	x0, x0, #2
    2824:      	add	x19, x0, x19
    2828:      	str	x20, [sp, #0x270]
    282c:      	ldr	x20, [sp, #0x270]
    2830:      	ldr	x0, [x20, #0x8]
    2834:      	cmp	x19, x0
    2838:      	b.ge	0x2868 <_stogir.cfg.build+0x710>
    283c:      	ldr	x0, [x20]
    2840:      	add	x0, x0, x19, lsl #4
    2844:      	ldr	x0, [x0]
    2848:      	ldr	x1, [x20, #0x78]
    284c:      	uxtb	w0, w0
    2850:      	add	x1, x1, x19, lsl #2
    2854:      	ldr	w21, [x1]
    2858:      	bl	0x2858 <_stogir.cfg.build+0x700>
		0000000000002858:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-start?
    285c:      	cmp	x0, #0x0
    2860:      	b.ne	0x27e8 <_stogir.cfg.build+0x690>
    2864:      	b	0x280c <_stogir.cfg.build+0x6b4>
    2868:      	mov	x19, #0x1               ; =1
    286c:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		000000000000286c:  ARM64_RELOC_PAGE21	l_stogir.407
    2870:      	ldr	x21, [x21]
		0000000000002870:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2874:      	movz	x22, #0x0, lsl #48
    2878:      	b	0x291c <_stogir.cfg.build+0x7c4>
    287c:      	movz	w1, #0x0, lsl #16
    2880:      	movz	w0, #0x0, lsl #16
    2884:      	b	0x2ab4 <_stogir.cfg.build+0x95c>
    2888:      	movz	w3, #0x0, lsl #16
    288c:      	movz	w4, #0x0, lsl #16
    2890:      	ubfx	x3, x3, #0, #32
    2894:      	lsr	x16, x3, #0
    2898:      	cmp	x16, #0x1
    289c:      	b.eq	0x28b8 <_stogir.cfg.build+0x760>
    28a0:      	b.lo	0x28a8 <_stogir.cfg.build+0x750>
    28a4:      	b	0x28bc <_stogir.cfg.build+0x764>
    28a8:      	cmp	x16, #0x0
    28ac:      	b.eq	0x28b4 <_stogir.cfg.build+0x75c>
    28b0:      	b	0x28bc <_stogir.cfg.build+0x764>
    28b4:      	b	0x28fc <_stogir.cfg.build+0x7a4>
    28b8:      	b	0x28c0 <_stogir.cfg.build+0x768>
    28bc:      	b	0x2c8c <_stogir.cfg.build+0xb34>
    28c0:      	sxtw	x4, w4
    28c4:      	add	x16, sp, #0x40
    28c8:      	ldr	x3, [x16, #0x28]
    28cc:      	add	x3, x3, x4, lsl #2
    28d0:      	str	w25, [x3]
    28d4:      	cmp	x2, x1
    28d8:      	b.ge	0x2888 <_stogir.cfg.build+0x730>
    28dc:      	add	x3, x2, #0x1
    28e0:      	add	x2, x0, x2, lsl #2
    28e4:      	ldr	w2, [x2]
    28e8:      	movn	w17, #0x0, lsl #16
    28ec:      	and	w4, w2, w17
    28f0:      	mov	x2, x3
    28f4:      	mov	w3, #0x1                ; =1
    28f8:      	b	0x2890 <_stogir.cfg.build+0x738>
    28fc:      	sxtw	x23, w23
    2900:      	add	x0, x23, #0x4
    2904:      	asr	x16, x0, #63
    2908:      	lsr	x16, x16, #62
    290c:      	add	x0, x0, x16
    2910:      	asr	x0, x0, #2
    2914:      	add	x19, x0, x19
    2918:      	str	x26, [sp, #0x268]
    291c:      	mov	x0, x21
    2920:      	mov	x1, x22
    2924:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002924:  ARM64_RELOC_PAGE21	l_stogir.407
    2928:      	ldr	x2, [x2]
		0000000000002928:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    292c:      	movz	x3, #0x0, lsl #48
    2930:      	bl	0x2930 <_stogir.cfg.build+0x7d8>
		0000000000002930:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2934:      	cmp	x0, #0x0
    2938:      	b.eq	0x2950 <_stogir.cfg.build+0x7f8>
    293c:      	ldr	x0, [x20, #0x8]
    2940:      	cmp	x19, x0
    2944:      	cset	w0, lt
    2948:      	ubfx	x0, x0, #0, #8
    294c:      	b	0x2954 <_stogir.cfg.build+0x7fc>
    2950:      	movz	x0, #0x0, lsl #48
    2954:      	cmp	x0, #0x0
    2958:      	b.eq	0x2c08 <_stogir.cfg.build+0xab0>
    295c:      	ldr	x0, [x20]
    2960:      	add	x0, x0, x19, lsl #4
    2964:      	ldr	x0, [x0]
    2968:      	ldr	x1, [x20, #0x78]
    296c:      	uxtb	w0, w0
    2970:      	add	x1, x1, x19, lsl #2
    2974:      	ldr	w23, [x1]
    2978:      	bl	0x2978 <_stogir.cfg.build+0x820>
		0000000000002978:  ARM64_RELOC_BRANCH26	_stogir.opcode.control?
    297c:      	cmp	x0, #0x0
    2980:      	b.eq	0x29a8 <_stogir.cfg.build+0x850>
    2984:      	add	x16, sp, #0x40
    2988:      	ldr	x0, [x16, #0x28]
    298c:      	add	x0, x0, x19, lsl #2
    2990:      	ldr	w0, [x0]
    2994:      	sxtw	x0, w0
    2998:      	cmp	x0, #0x0
    299c:      	cset	w0, eq
    29a0:      	ubfx	x0, x0, #0, #8
    29a4:      	b	0x29ac <_stogir.cfg.build+0x854>
    29a8:      	movz	x0, #0x0, lsl #48
    29ac:      	cmp	x0, #0x0
    29b0:      	b.eq	0x2ce0 <_stogir.cfg.build+0xb88>
    29b4:      	orr	w24, w19, wzr
    29b8:      	add	x0, sp, #0x150
    29bc:      	bl	0x29bc <_stogir.cfg.build+0x864>
		00000000000029bc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$clear!__i32
    29c0:      	sxtw	x24, w24
    29c4:      	movz	x25, #0x0, lsl #48
    29c8:      	b	0x2a30 <_stogir.cfg.build+0x8d8>
    29cc:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		00000000000029cc:  ARM64_RELOC_PAGE21	l_stogir.408
    29d0:      	ldr	x21, [x21]
		00000000000029d0:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    29d4:      	mov	x22, #0x1b              ; =27
    29d8:      	b	0x2a2c <_stogir.cfg.build+0x8d4>
    29dc:      	nop
    29e0:      	movz	x0, #0x0, lsl #48
    29e4:      	cmp	x0, #0x0
    29e8:      	b.eq	0x2ce8 <_stogir.cfg.build+0xb90>
    29ec:      	add	x16, sp, #0x40
    29f0:      	ldr	x0, [x16, #0x28]
    29f4:      	add	x0, x0, x24, lsl #2
    29f8:      	ldr	w0, [x0]
    29fc:      	sxtw	x25, w0
    2a00:      	cmp	x25, #0x0
    2a04:      	b.ne	0x2cf0 <_stogir.cfg.build+0xb98>
    2a08:      	add	x16, sp, #0x150
    2a0c:      	ldr	x0, [x16, #0x8]
    2a10:      	ldr	x1, [x20, #0x8]
    2a14:      	cmp	x0, x1
    2a18:      	b.lt	0x2a48 <_stogir.cfg.build+0x8f0>
    2a1c:      	ldr	x26, [sp, #0x268]
    2a20:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002a20:  ARM64_RELOC_PAGE21	l_stogir.409
    2a24:      	ldr	x21, [x21]
		0000000000002a24:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    2a28:      	mov	x22, #0x27              ; =39
    2a2c:      	str	x26, [sp, #0x268]
    2a30:      	cmp	x22, #0x0
    2a34:      	b.ne	0x29e0 <_stogir.cfg.build+0x888>
    2a38:      	cmp	x25, #0x0
    2a3c:      	cset	w0, eq
    2a40:      	ubfx	x0, x0, #0, #8
    2a44:      	b	0x29e4 <_stogir.cfg.build+0x88c>
    2a48:      	orr	x26, x0, xzr
    2a4c:      	add	x16, sp, #0x150
    2a50:      	ldr	x0, [x16, #0x10]
    2a54:      	cmp	x26, x0
    2a58:      	b.lt	0x2a7c <_stogir.cfg.build+0x924>
    2a5c:      	cmp	x0, #0x0
    2a60:      	b.ne	0x2a6c <_stogir.cfg.build+0x914>
    2a64:      	mov	x0, #0x2                ; =2
    2a68:      	b	0x2a70 <_stogir.cfg.build+0x918>
    2a6c:      	lsl	x0, x0, #1
    2a70:      	mov	x1, x0
    2a74:      	add	x0, sp, #0x150
    2a78:      	bl	0x2a78 <_stogir.cfg.build+0x920>
		0000000000002a78:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    2a7c:      	orr	w0, w24, wzr
    2a80:      	add	x1, x26, #0x1
    2a84:      	sxtw	x2, w0
    2a88:      	add	x16, sp, #0x150
    2a8c:      	ldr	x3, [x16]
    2a90:      	add	x3, x3, x26, lsl #2
    2a94:      	str	w0, [x3]
    2a98:      	add	x16, sp, #0x150
    2a9c:      	str	x1, [x16, #0x8]
    2aa0:      	cmp	x2, #0x0
    2aa4:      	b.gt	0x2af4 <_stogir.cfg.build+0x99c>
    2aa8:      	ldr	x26, [sp, #0x268]
    2aac:      	movz	w1, #0x0, lsl #16
    2ab0:      	movz	w0, #0x0, lsl #16
    2ab4:      	ubfx	x1, x1, #0, #32
    2ab8:      	lsr	x16, x1, #0
    2abc:      	cmp	x16, #0x1
    2ac0:      	b.eq	0x2adc <_stogir.cfg.build+0x984>
    2ac4:      	b.lo	0x2acc <_stogir.cfg.build+0x974>
    2ac8:      	b	0x2ae0 <_stogir.cfg.build+0x988>
    2acc:      	cmp	x16, #0x0
    2ad0:      	b.eq	0x2ad8 <_stogir.cfg.build+0x980>
    2ad4:      	b	0x2ae0 <_stogir.cfg.build+0x988>
    2ad8:      	b	0x2ae4 <_stogir.cfg.build+0x98c>
    2adc:      	b	0x2b7c <_stogir.cfg.build+0xa24>
    2ae0:      	b	0x2c94 <_stogir.cfg.build+0xb3c>
    2ae4:      	adrp	x21, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002ae4:  ARM64_RELOC_PAGE21	l_stogir.410
    2ae8:      	ldr	x21, [x21]
		0000000000002ae8:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    2aec:      	mov	x22, #0x1e              ; =30
    2af0:      	b	0x29d8 <_stogir.cfg.build+0x880>
    2af4:      	lsl	x0, x2, #2
    2af8:      	ldr	x1, [x20, #0x8]
    2afc:      	cmp	x2, x1
    2b00:      	b.ge	0x2cf8 <_stogir.cfg.build+0xba0>
    2b04:      	ldr	x26, [sp, #0x268]
    2b08:      	ldr	x1, [x26, #0x8]
    2b0c:      	cmp	x2, x1
    2b10:      	b.ge	0x2bc0 <_stogir.cfg.build+0xa68>
    2b14:      	ldr	x1, [x20, #0x78]
    2b18:      	add	x1, x0, x1
    2b1c:      	ldr	w1, [x1]
    2b20:      	sxtw	x1, w1
    2b24:      	cmp	x1, #0x0
    2b28:      	cset	w1, ge
    2b2c:      	ubfx	x1, x1, #0, #8
    2b30:      	b	0x2bc4 <_stogir.cfg.build+0xa6c>
    2b34:      	mov	x0, x21
    2b38:      	mov	x1, x22
    2b3c:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002b3c:  ARM64_RELOC_PAGE21	l_stogir.407
    2b40:      	ldr	x2, [x2]
		0000000000002b40:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2b44:      	movz	x3, #0x0, lsl #48
    2b48:      	bl	0x2b48 <_stogir.cfg.build+0x9f0>
		0000000000002b48:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2b4c:      	cmp	x0, #0x0
    2b50:      	b.eq	0x28fc <_stogir.cfg.build+0x7a4>
    2b54:      	add	x8, sp, #0x1b0
    2b58:      	add	x0, sp, #0x150
    2b5c:      	bl	0x2b5c <_stogir.cfg.build+0xa04>
		0000000000002b5c:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2b60:      	add	x16, sp, #0x1b0
    2b64:      	ldr	x0, [x16]
    2b68:      	add	x16, sp, #0x1b0
    2b6c:      	ldr	x1, [x16, #0x8]
    2b70:      	add	x16, sp, #0x1b0
    2b74:      	ldr	x2, [x16, #0x10]
    2b78:      	b	0x28d4 <_stogir.cfg.build+0x77c>
    2b7c:      	sxtw	x0, w0
    2b80:      	cmp	x0, #0x0
    2b84:      	b.le	0x29cc <_stogir.cfg.build+0x874>
    2b88:      	ldr	x1, [x20, #0x8]
    2b8c:      	cmp	x0, x1
    2b90:      	b.ge	0x2c70 <_stogir.cfg.build+0xb18>
    2b94:      	ldr	x1, [x26, #0x8]
    2b98:      	cmp	x0, x1
    2b9c:      	b.ge	0x2c84 <_stogir.cfg.build+0xb2c>
    2ba0:      	ldr	x1, [x20, #0x78]
    2ba4:      	add	x1, x1, x0, lsl #2
    2ba8:      	ldr	w1, [x1]
    2bac:      	sxtw	x1, w1
    2bb0:      	cmp	x1, #0x0
    2bb4:      	cset	w1, ge
    2bb8:      	ubfx	x1, x1, #0, #8
    2bbc:      	b	0x2c88 <_stogir.cfg.build+0xb30>
    2bc0:      	movz	x1, #0x0, lsl #48
    2bc4:      	b	0x2bcc <_stogir.cfg.build+0xa74>
    2bc8:      	movz	x1, #0x0, lsl #48
    2bcc:      	cmp	x1, #0x0
    2bd0:      	b.eq	0x2aac <_stogir.cfg.build+0x954>
    2bd4:      	ldr	x1, [x20, #0x78]
    2bd8:      	add	x0, x0, x1
    2bdc:      	ldr	w0, [x0]
    2be0:      	sxtw	x0, w0
    2be4:      	cmp	x0, #0x1
    2be8:      	b.lt	0x287c <_stogir.cfg.build+0x724>
    2bec:      	ldr	x0, [x20]
    2bf0:      	add	x0, x0, x2, lsl #4
    2bf4:      	ldr	w0, [x0, #0x4]
    2bf8:      	movn	w17, #0x0, lsl #16
    2bfc:      	and	w0, w0, w17
    2c00:      	mov	w1, #0x1                ; =1
    2c04:      	b	0x2884 <_stogir.cfg.build+0x72c>
    2c08:      	mov	x0, x21
    2c0c:      	mov	x1, x22
    2c10:      	adrp	x2, 0x2000 <_stogir.verify.schedule-input+0x74>
		0000000000002c10:  ARM64_RELOC_PAGE21	l_stogir.407
    2c14:      	ldr	x2, [x2]
		0000000000002c14:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    2c18:      	movz	x3, #0x0, lsl #48
    2c1c:      	bl	0x2c1c <_stogir.cfg.build+0xac4>
		0000000000002c1c:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    2c20:      	cmp	x0, #0x0
    2c24:      	b.eq	0x2434 <_stogir.cfg.build+0x2dc>
    2c28:      	ldr	x0, [sp, #0x260]
    2c2c:      	add	x19, x0, #0x50
    2c30:      	add	x8, sp, #0x1f0
    2c34:      	add	x0, sp, #0x40
    2c38:      	bl	0x2c38 <_stogir.cfg.build+0xae0>
		0000000000002c38:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    2c3c:      	add	x16, sp, #0x1f0
    2c40:      	ldr	x0, [x16]
    2c44:      	add	x16, sp, #0x1d0
    2c48:      	str	x0, [x16]
    2c4c:      	add	x16, sp, #0x1f0
    2c50:      	ldr	x0, [x16, #0x8]
    2c54:      	add	x16, sp, #0x1d0
    2c58:      	str	x0, [x16, #0x8]
    2c5c:      	add	x16, sp, #0x1f0
    2c60:      	ldr	x0, [x16, #0x10]
    2c64:      	add	x16, sp, #0x1d0
    2c68:      	str	x0, [x16, #0x10]
    2c6c:      	b	0x23b0 <_stogir.cfg.build+0x258>
    2c70:      	movz	x1, #0x0, lsl #48
    2c74:      	cmp	x1, #0x0
    2c78:      	b.eq	0x29cc <_stogir.cfg.build+0x874>
    2c7c:      	mov	x24, x0
    2c80:      	b	0x29d8 <_stogir.cfg.build+0x880>
    2c84:      	movz	x1, #0x0, lsl #48
    2c88:      	b	0x2c74 <_stogir.cfg.build+0xb1c>
    2c8c:      	brk	#0
    2c90:      	b	0x2c8c <_stogir.cfg.build+0xb34>
    2c94:      	brk	#0
    2c98:      	b	0x2c94 <_stogir.cfg.build+0xb3c>
    2c9c:      	brk	#0
    2ca0:      	b	0x2c9c <_stogir.cfg.build+0xb44>
    2ca4:      	brk	#0
    2ca8:      	b	0x2ca4 <_stogir.cfg.build+0xb4c>
    2cac:      	brk	#0
    2cb0:      	b	0x2cac <_stogir.cfg.build+0xb54>
    2cb4:      	str	x20, [sp, #0x270]
    2cb8:      	b	0x23ac <_stogir.cfg.build+0x254>
    2cbc:      	str	x20, [sp, #0x270]
    2cc0:      	str	w23, [sp, #0x278]
    2cc4:      	str	w24, [sp, #0x280]
    2cc8:      	b	0x2284 <_stogir.cfg.build+0x12c>
    2ccc:      	str	w23, [sp, #0x278]
    2cd0:      	str	w24, [sp, #0x280]
    2cd4:      	mov	x23, x0
    2cd8:      	mov	x24, x1
    2cdc:      	b	0x2268 <_stogir.cfg.build+0x110>
    2ce0:      	ldr	x26, [sp, #0x268]
    2ce4:      	b	0x28fc <_stogir.cfg.build+0x7a4>
    2ce8:      	ldr	x26, [sp, #0x268]
    2cec:      	b	0x2b34 <_stogir.cfg.build+0x9dc>
    2cf0:      	ldr	x26, [sp, #0x268]
    2cf4:      	b	0x2a2c <_stogir.cfg.build+0x8d4>
    2cf8:      	ldr	x26, [sp, #0x268]
    2cfc:      	b	0x2bc8 <_stogir.cfg.build+0xa70>

0000000000002d00 <_stogir.adjacency.build>:
    2d00:      	sub	sp, sp, #0x70
    2d04:      	str	x29, [sp]
    2d08:      	str	x30, [sp, #0x8]
    2d0c:      	mov	x29, sp
    2d10:      	str	x19, [sp, #0x18]
    2d14:      	str	x20, [sp, #0x20]
    2d18:      	str	x21, [sp, #0x28]
    2d1c:      	str	x22, [sp, #0x30]
    2d20:      	str	x23, [sp, #0x38]
    2d24:      	str	x24, [sp, #0x40]
    2d28:      	str	x25, [sp, #0x48]
    2d2c:      	str	x26, [sp, #0x50]
    2d30:      	str	x27, [sp, #0x58]
    2d34:      	str	x28, [sp, #0x60]
    2d38:      	add	x3, x0, #0x28
    2d3c:      	ldr	x3, [x3, #0x8]
    2d40:      	orr	x19, x3, xzr
    2d44:      	mov	x20, sp
    2d48:      	sub	sp, sp, #0x50
    2d4c:      	mov	x21, sp
    2d50:      	sub	sp, sp, #0x30
    2d54:      	mov	x22, sp
    2d58:      	ldr	x3, [x2]
    2d5c:      	ldr	x2, [x2, #0x8]
    2d60:      	movz	x17, #0x0, lsl #48
    2d64:      	str	x17, [x21]
    2d68:      	movz	x17, #0x0, lsl #48
    2d6c:      	str	x17, [x21, #0x8]
    2d70:      	movz	x17, #0x0, lsl #48
    2d74:      	str	x17, [x21, #0x10]
    2d78:      	str	x3, [x21, #0x18]
    2d7c:      	str	x2, [x21, #0x20]
    2d80:      	movz	x17, #0x0, lsl #48
    2d84:      	str	x17, [x21, #0x28]
    2d88:      	movz	x17, #0x0, lsl #48
    2d8c:      	str	x17, [x21, #0x30]
    2d90:      	movz	x17, #0x0, lsl #48
    2d94:      	str	x17, [x21, #0x38]
    2d98:      	str	x3, [x21, #0x40]
    2d9c:      	str	x2, [x21, #0x48]
    2da0:      	movz	x17, #0x0, lsl #48
    2da4:      	str	x17, [x22]
    2da8:      	movz	x17, #0x0, lsl #48
    2dac:      	str	x17, [x22, #0x8]
    2db0:      	movz	x17, #0x0, lsl #48
    2db4:      	str	x17, [x22, #0x10]
    2db8:      	str	x3, [x22, #0x18]
    2dbc:      	str	x2, [x22, #0x20]
    2dc0:      	cmp	x19, #0x0
    2dc4:      	b.le	0x3170 <_stogir.adjacency.build+0x470>
    2dc8:      	cmp	x19, #0x0
    2dcc:      	b.ge	0x2dd8 <_stogir.adjacency.build+0xd8>
    2dd0:      	movz	x2, #0x0, lsl #48
    2dd4:      	b	0x2ddc <_stogir.adjacency.build+0xdc>
    2dd8:      	mov	x2, x19
    2ddc:      	mov	x23, x8
    2de0:      	mov	x24, x0
    2de4:      	mov	x0, x21
    2de8:      	mov	w25, w1
    2dec:      	mov	x1, x2
    2df0:      	bl	0x2df0 <_stogir.adjacency.build+0xf0>
		0000000000002df0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range
    2df4:      	lsl	x0, x19, #4
    2df8:      	ldr	x1, [x21]
    2dfc:      	mov	x2, x0
    2e00:      	mov	x0, x1
    2e04:      	movz	x1, #0x0, lsl #48
    2e08:      	bl	0x2e08 <_stogir.adjacency.build+0x108>
		0000000000002e08:  ARM64_RELOC_BRANCH26	_memset
    2e0c:      	str	x19, [x21, #0x8]
    2e10:      	ldr	x0, [x22, #0x8]
    2e14:      	orr	x26, x0, xzr
    2e18:      	ldr	x0, [x22, #0x10]
    2e1c:      	add	x27, x26, x19
    2e20:      	cmp	x27, x0
    2e24:      	b.le	0x2e58 <_stogir.adjacency.build+0x158>
    2e28:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2e2c:      	cmp	x0, x17
    2e30:      	b.gt	0x2e3c <_stogir.adjacency.build+0x13c>
    2e34:      	lsl	x0, x0, #1
    2e38:      	b	0x2e40 <_stogir.adjacency.build+0x140>
    2e3c:      	mov	x0, x27
    2e40:      	cmp	x0, x27
    2e44:      	b.gt	0x2e4c <_stogir.adjacency.build+0x14c>
    2e48:      	mov	x0, x27
    2e4c:      	mov	x1, x0
    2e50:      	mov	x0, x22
    2e54:      	bl	0x2e54 <_stogir.adjacency.build+0x154>
		0000000000002e54:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    2e58:      	add	x28, x24, #0x50
    2e5c:      	ubfx	x25, x25, #0, #8
    2e60:      	lsl	x0, x19, #3
    2e64:      	cmp	x25, #0x0
    2e68:      	cset	w19, ne
    2e6c:      	ldr	x1, [x22]
    2e70:      	add	x1, x1, x26, lsl #3
    2e74:      	mov	x2, x0
    2e78:      	mov	x0, x1
    2e7c:      	movz	x1, #0x0, lsl #48
    2e80:      	bl	0x2e80 <_stogir.adjacency.build+0x180>
		0000000000002e80:  ARM64_RELOC_BRANCH26	_memset
    2e84:      	str	x27, [x22, #0x8]
    2e88:      	ldr	x0, [x24, #0x50]
    2e8c:      	ldr	x1, [x28, #0x8]
    2e90:      	movz	x2, #0x0, lsl #48
    2e94:      	b	0x2ec0 <_stogir.adjacency.build+0x1c0>
    2e98:      	sxtw	x3, w4
    2e9c:      	ldr	x4, [x21]
    2ea0:      	orr	x5, x4, xzr
    2ea4:      	add	x5, x5, x3, lsl #4
    2ea8:      	add	x3, x4, x3, lsl #4
    2eac:      	ldr	x4, [x5]
    2eb0:      	ldr	x5, [x5, #0x8]
    2eb4:      	add	x5, x5, #0x1
    2eb8:      	str	x4, [x3]
    2ebc:      	str	x5, [x3, #0x8]
    2ec0:      	cmp	x2, x1
    2ec4:      	b.ge	0x2ee0 <_stogir.adjacency.build+0x1e0>
    2ec8:      	add	x3, x2, #0x1
    2ecc:      	add	x2, x0, x2, lsl #4
    2ed0:      	ldr	x4, [x2]
    2ed4:      	mov	x2, x3
    2ed8:      	mov	w3, #0x1                ; =1
    2edc:      	b	0x2ee8 <_stogir.adjacency.build+0x1e8>
    2ee0:      	movz	w3, #0x0, lsl #16
    2ee4:      	movz	x4, #0x0, lsl #48
    2ee8:      	ubfx	x3, x3, #0, #32
    2eec:      	lsr	x16, x3, #0
    2ef0:      	cmp	x16, #0x1
    2ef4:      	b.eq	0x2f10 <_stogir.adjacency.build+0x210>
    2ef8:      	b.lo	0x2f00 <_stogir.adjacency.build+0x200>
    2efc:      	b	0x2f14 <_stogir.adjacency.build+0x214>
    2f00:      	cmp	x16, #0x0
    2f04:      	b.eq	0x2f0c <_stogir.adjacency.build+0x20c>
    2f08:      	b	0x2f14 <_stogir.adjacency.build+0x214>
    2f0c:      	b	0x2f2c <_stogir.adjacency.build+0x22c>
    2f10:      	b	0x2f18 <_stogir.adjacency.build+0x218>
    2f14:      	b	0x3168 <_stogir.adjacency.build+0x468>
    2f18:      	uxtb	w16, w19
    2f1c:      	cmp	w16, wzr
    2f20:      	b.eq	0x2e98 <_stogir.adjacency.build+0x198>
    2f24:      	asr	x3, x4, #32
    2f28:      	b	0x2e9c <_stogir.adjacency.build+0x19c>
    2f2c:      	movz	x0, #0x0, lsl #48
    2f30:      	movz	x1, #0x0, lsl #48
    2f34:      	b	0x2f70 <_stogir.adjacency.build+0x270>
    2f38:      	add	x2, x0, #0x1
    2f3c:      	ldr	x3, [x21]
    2f40:      	orr	x4, x3, xzr
    2f44:      	add	x4, x4, x0, lsl #4
    2f48:      	add	x3, x3, x0, lsl #4
    2f4c:      	ldr	x4, [x4, #0x8]
    2f50:      	add	x5, x4, x1
    2f54:      	str	x1, [x3]
    2f58:      	str	x4, [x3, #0x8]
    2f5c:      	ldr	x3, [x22]
    2f60:      	add	x0, x3, x0, lsl #3
    2f64:      	str	x1, [x0]
    2f68:      	mov	x0, x2
    2f6c:      	mov	x1, x5
    2f70:      	ldr	x2, [x21, #0x8]
    2f74:      	cmp	x0, x2
    2f78:      	b.lt	0x2f38 <_stogir.adjacency.build+0x238>
    2f7c:      	add	x19, x21, #0x28
    2f80:      	ldr	x0, [x28, #0x8]
    2f84:      	orr	x26, x0, xzr
    2f88:      	ldr	x0, [x19, #0x8]
    2f8c:      	orr	x27, x0, xzr
    2f90:      	ldr	x0, [x19, #0x10]
    2f94:      	add	x1, x27, x26
    2f98:      	cmp	x1, x0
    2f9c:      	b.le	0x3180 <_stogir.adjacency.build+0x480>
    2fa0:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    2fa4:      	cmp	x0, x17
    2fa8:      	b.gt	0x2fb4 <_stogir.adjacency.build+0x2b4>
    2fac:      	lsl	x0, x0, #1
    2fb0:      	b	0x2fb8 <_stogir.adjacency.build+0x2b8>
    2fb4:      	mov	x0, x1
    2fb8:      	cmp	x0, x1
    2fbc:      	b.gt	0x2fc4 <_stogir.adjacency.build+0x2c4>
    2fc0:      	mov	x0, x1
    2fc4:      	str	x23, [x29, #0x10]
    2fc8:      	mov	x23, x1
    2fcc:      	mov	x1, x0
    2fd0:      	mov	x0, x19
    2fd4:      	bl	0x2fd4 <_stogir.adjacency.build+0x2d4>
		0000000000002fd4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    2fd8:      	cmp	x25, #0x0
    2fdc:      	cset	w25, ne
    2fe0:      	lsl	x0, x26, #3
    2fe4:      	ldr	x1, [x21, #0x28]
    2fe8:      	add	x1, x1, x27, lsl #3
    2fec:      	mov	x2, x0
    2ff0:      	mov	x0, x1
    2ff4:      	movz	x1, #0x0, lsl #48
    2ff8:      	bl	0x2ff8 <_stogir.adjacency.build+0x2f8>
		0000000000002ff8:  ARM64_RELOC_BRANCH26	_memset
    2ffc:      	str	x23, [x19, #0x8]
    3000:      	movz	x0, #0x0, lsl #48
    3004:      	b	0x303c <_stogir.adjacency.build+0x33c>
    3008:      	sxtw	x1, w1
    300c:      	add	x2, x0, #0x1
    3010:      	ldr	x3, [x22]
    3014:      	add	x3, x3, x1, lsl #3
    3018:      	ldr	x3, [x3]
    301c:      	ldr	x4, [x21, #0x28]
    3020:      	add	x5, x3, #0x1
    3024:      	add	x3, x4, x3, lsl #3
    3028:      	str	x0, [x3]
    302c:      	ldr	x0, [x22]
    3030:      	add	x0, x0, x1, lsl #3
    3034:      	str	x5, [x0]
    3038:      	mov	x0, x2
    303c:      	ldr	x1, [x28, #0x8]
    3040:      	cmp	x0, x1
    3044:      	b.ge	0x3068 <_stogir.adjacency.build+0x368>
    3048:      	ldr	x1, [x24, #0x50]
    304c:      	add	x1, x1, x0, lsl #4
    3050:      	ldr	x1, [x1]
    3054:      	uxtb	w16, w25
    3058:      	cmp	w16, wzr
    305c:      	b.eq	0x3008 <_stogir.adjacency.build+0x308>
    3060:      	asr	x1, x1, #32
    3064:      	b	0x300c <_stogir.adjacency.build+0x30c>
    3068:      	b	0x3078 <_stogir.adjacency.build+0x378>
    306c:      	nop
    3070:      	sub	x0, x0, #0x1
    3074:      	str	x0, [x22, #0x8]
    3078:      	ldr	x0, [x22, #0x8]
    307c:      	cmp	x0, #0x0
    3080:      	b.ne	0x3070 <_stogir.adjacency.build+0x370>
    3084:      	ldr	x0, [x22, #0x10]
    3088:      	cmp	x0, #0x0
    308c:      	b.le	0x30bc <_stogir.adjacency.build+0x3bc>
    3090:      	add	x1, x22, #0x18
    3094:      	ldr	x2, [x22]
    3098:      	fmov	d31, x0
    309c:      	mov	x0, x1
    30a0:      	mov	x1, x2
    30a4:      	fmov	x2, d31
    30a8:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		00000000000030a8:  ARM64_RELOC_PAGE21	l_stogir.411
    30ac:      	ldr	x3, [x3]
		00000000000030ac:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    30b0:      	mov	x4, #0x8                ; =8
    30b4:      	mov	x5, #0x8                ; =8
    30b8:      	bl	0x30b8 <_stogir.adjacency.build+0x3b8>
		00000000000030b8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    30bc:      	movz	x17, #0x0, lsl #48
    30c0:      	str	x17, [x22]
    30c4:      	movz	x17, #0x0, lsl #48
    30c8:      	str	x17, [x22, #0x8]
    30cc:      	movz	x17, #0x0, lsl #48
    30d0:      	str	x17, [x22, #0x10]
    30d4:      	ldr	x0, [x21]
    30d8:      	ldr	x1, [x21, #0x8]
    30dc:      	ldr	x2, [x21, #0x10]
    30e0:      	ldr	x3, [x21, #0x18]
    30e4:      	ldr	x4, [x21, #0x20]
    30e8:      	ldr	x5, [x21, #0x28]
    30ec:      	ldr	x6, [x21, #0x30]
    30f0:      	ldr	x7, [x21, #0x38]
    30f4:      	ldr	x8, [x21, #0x40]
    30f8:      	ldr	x9, [x21, #0x48]
    30fc:      	mov	sp, x20
    3100:      	ldr	x10, [x29, #0x10]
    3104:      	str	x0, [x10]
    3108:      	str	x1, [x10, #0x8]
    310c:      	str	x2, [x10, #0x10]
    3110:      	str	x3, [x10, #0x18]
    3114:      	str	x4, [x10, #0x20]
    3118:      	str	x5, [x10, #0x28]
    311c:      	str	x6, [x10, #0x30]
    3120:      	str	x7, [x10, #0x38]
    3124:      	str	x8, [x10, #0x40]
    3128:      	str	x9, [x10, #0x48]
    312c:      	sub	sp, x29, #0x0
    3130:      	ldr	x19, [sp, #0x18]
    3134:      	ldr	x20, [sp, #0x20]
    3138:      	ldr	x21, [sp, #0x28]
    313c:      	ldr	x22, [sp, #0x30]
    3140:      	ldr	x23, [sp, #0x38]
    3144:      	ldr	x24, [sp, #0x40]
    3148:      	ldr	x25, [sp, #0x48]
    314c:      	ldr	x26, [sp, #0x50]
    3150:      	ldr	x27, [sp, #0x58]
    3154:      	ldr	x28, [sp, #0x60]
    3158:      	ldr	x29, [sp]
    315c:      	ldr	x30, [sp, #0x8]
    3160:      	add	sp, sp, #0x70
    3164:      	ret
    3168:      	brk	#0
    316c:      	b	0x3168 <_stogir.adjacency.build+0x468>
    3170:      	mov	x23, x8
    3174:      	mov	x24, x0
    3178:      	mov	w25, w1
    317c:      	b	0x2df4 <_stogir.adjacency.build+0xf4>
    3180:      	str	x23, [x29, #0x10]
    3184:      	mov	x23, x1
    3188:      	b	0x2fd8 <_stogir.adjacency.build+0x2d8>
    318c:      	udf	#0x0

0000000000003190 <_stogir.adjacency.reverse-postorder>:
    3190:      	sub	sp, sp, #0x120
    3194:      	str	x29, [sp]
    3198:      	str	x30, [sp, #0x8]
    319c:      	mov	x29, sp
    31a0:      	str	x19, [sp, #0xf0]
    31a4:      	str	x20, [sp, #0xf8]
    31a8:      	str	x21, [sp, #0x100]
    31ac:      	str	x22, [sp, #0x108]
    31b0:      	str	x23, [sp, #0x110]
    31b4:      	str	x24, [sp, #0x118]
    31b8:      	add	x4, x0, #0x28
    31bc:      	ldr	x5, [x3]
    31c0:      	ldr	x3, [x3, #0x8]
    31c4:      	add	x16, sp, #0x10
    31c8:      	movz	x17, #0x0, lsl #48
    31cc:      	str	x17, [x16]
    31d0:      	add	x16, sp, #0x10
    31d4:      	movz	x17, #0x0, lsl #48
    31d8:      	str	x17, [x16, #0x8]
    31dc:      	add	x16, sp, #0x10
    31e0:      	movz	x17, #0x0, lsl #48
    31e4:      	str	x17, [x16, #0x10]
    31e8:      	add	x16, sp, #0x10
    31ec:      	str	x5, [x16, #0x18]
    31f0:      	add	x16, sp, #0x10
    31f4:      	str	x3, [x16, #0x20]
    31f8:      	add	x16, sp, #0x40
    31fc:      	movz	x17, #0x0, lsl #48
    3200:      	str	x17, [x16]
    3204:      	add	x16, sp, #0x40
    3208:      	movz	x17, #0x0, lsl #48
    320c:      	str	x17, [x16, #0x8]
    3210:      	add	x16, sp, #0x40
    3214:      	movz	x17, #0x0, lsl #48
    3218:      	str	x17, [x16, #0x10]
    321c:      	add	x16, sp, #0x40
    3220:      	str	x5, [x16, #0x18]
    3224:      	add	x16, sp, #0x40
    3228:      	str	x3, [x16, #0x20]
    322c:      	add	x16, sp, #0x70
    3230:      	movz	x17, #0x0, lsl #48
    3234:      	str	x17, [x16]
    3238:      	add	x16, sp, #0x70
    323c:      	movz	x17, #0x0, lsl #48
    3240:      	str	x17, [x16, #0x8]
    3244:      	add	x16, sp, #0x70
    3248:      	movz	x17, #0x0, lsl #48
    324c:      	str	x17, [x16, #0x10]
    3250:      	add	x16, sp, #0x70
    3254:      	str	x5, [x16, #0x18]
    3258:      	add	x16, sp, #0x70
    325c:      	str	x3, [x16, #0x20]
    3260:      	add	x16, sp, #0xa0
    3264:      	movz	x17, #0x0, lsl #48
    3268:      	str	x17, [x16]
    326c:      	add	x16, sp, #0xa0
    3270:      	movz	x17, #0x0, lsl #48
    3274:      	str	x17, [x16, #0x8]
    3278:      	add	x16, sp, #0xa0
    327c:      	movz	x17, #0x0, lsl #48
    3280:      	str	x17, [x16, #0x10]
    3284:      	add	x16, sp, #0xa0
    3288:      	str	x5, [x16, #0x18]
    328c:      	add	x16, sp, #0xa0
    3290:      	str	x3, [x16, #0x20]
    3294:      	ldr	x3, [x4, #0x8]
    3298:      	orr	x19, x3, xzr
    329c:      	cmp	x19, #0x0
    32a0:      	b.le	0x37d8 <_stogir.adjacency.reverse-postorder+0x648>
    32a4:      	cmp	x19, #0x0
    32a8:      	b.ge	0x32b4 <_stogir.adjacency.reverse-postorder+0x124>
    32ac:      	movz	x3, #0x0, lsl #48
    32b0:      	b	0x32b8 <_stogir.adjacency.reverse-postorder+0x128>
    32b4:      	mov	x3, x19
    32b8:      	mov	x20, x8
    32bc:      	mov	x21, x0
    32c0:      	add	x0, sp, #0x10
    32c4:      	mov	x22, x1
    32c8:      	mov	x1, x3
    32cc:      	mov	w23, w2
    32d0:      	bl	0x32d0 <_stogir.adjacency.reverse-postorder+0x140>
		00000000000032d0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    32d4:      	lsr	x0, x19, #0
    32d8:      	add	x16, sp, #0x10
    32dc:      	ldr	x1, [x16]
    32e0:      	mov	x2, x0
    32e4:      	mov	x0, x1
    32e8:      	movz	x1, #0x0, lsl #48
    32ec:      	bl	0x32ec <_stogir.adjacency.reverse-postorder+0x15c>
		00000000000032ec:  ARM64_RELOC_BRANCH26	_memset
    32f0:      	add	x16, sp, #0x10
    32f4:      	str	x19, [x16, #0x8]
    32f8:      	add	x16, sp, #0xd0
    32fc:      	movz	x17, #0x0, lsl #48
    3300:      	str	x17, [x16]
    3304:      	add	x16, sp, #0xd0
    3308:      	movz	x17, #0x0, lsl #48
    330c:      	str	x17, [x16, #0x8]
    3310:      	add	x16, sp, #0xd0
    3314:      	str	w23, [x16]
    3318:      	add	x16, sp, #0xd0
    331c:      	movz	x17, #0x0, lsl #48
    3320:      	str	x17, [x16, #0x8]
    3324:      	add	x16, sp, #0xd0
    3328:      	ldr	x19, [x16]
    332c:      	add	x16, sp, #0x40
    3330:      	ldr	x0, [x16, #0x8]
    3334:      	orr	x24, x0, xzr
    3338:      	add	x16, sp, #0x40
    333c:      	ldr	x0, [x16, #0x10]
    3340:      	cmp	x24, x0
    3344:      	b.lt	0x3368 <_stogir.adjacency.reverse-postorder+0x1d8>
    3348:      	cmp	x0, #0x0
    334c:      	b.ne	0x3358 <_stogir.adjacency.reverse-postorder+0x1c8>
    3350:      	mov	x0, #0x2                ; =2
    3354:      	b	0x335c <_stogir.adjacency.reverse-postorder+0x1cc>
    3358:      	lsl	x0, x0, #1
    335c:      	mov	x1, x0
    3360:      	add	x0, sp, #0x40
    3364:      	bl	0x3364 <_stogir.adjacency.reverse-postorder+0x1d4>
		0000000000003364:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    3368:      	sxtw	x23, w23
    336c:      	add	x0, x24, #0x1
    3370:      	add	x16, sp, #0x40
    3374:      	ldr	x1, [x16]
    3378:      	add	x1, x1, x24, lsl #4
    337c:      	str	x19, [x1]
    3380:      	movz	x17, #0x0, lsl #48
    3384:      	str	x17, [x1, #0x8]
    3388:      	add	x16, sp, #0x40
    338c:      	str	x0, [x16, #0x8]
    3390:      	add	x16, sp, #0x10
    3394:      	ldr	x0, [x16]
    3398:      	add	x0, x0, x23
    339c:      	mov	w17, #0x1               ; =1
    33a0:      	strb	w17, [x0]
    33a4:      	b	0x3428 <_stogir.adjacency.reverse-postorder+0x298>
    33a8:      	lsl	x0, x0, #1
    33ac:      	mov	x1, x0
    33b0:      	add	x0, sp, #0x70
    33b4:      	bl	0x33b4 <_stogir.adjacency.reverse-postorder+0x224>
		00000000000033b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    33b8:      	add	x0, x23, #0x1
    33bc:      	add	x16, sp, #0x70
    33c0:      	ldr	x1, [x16]
    33c4:      	add	x1, x1, x23, lsl #2
    33c8:      	str	w19, [x1]
    33cc:      	add	x16, sp, #0x70
    33d0:      	str	x0, [x16, #0x8]
    33d4:      	add	x16, sp, #0x40
    33d8:      	ldr	x0, [x16, #0x8]
    33dc:      	cmp	x0, #0x0
    33e0:      	b.eq	0x3428 <_stogir.adjacency.reverse-postorder+0x298>
    33e4:      	sub	x0, x0, #0x1
    33e8:      	add	x16, sp, #0x40
    33ec:      	str	x0, [x16, #0x8]
    33f0:      	b	0x3428 <_stogir.adjacency.reverse-postorder+0x298>
    33f4:      	lsl	x0, x0, #1
    33f8:      	mov	x1, x0
    33fc:      	add	x0, sp, #0x40
    3400:      	bl	0x3400 <_stogir.adjacency.reverse-postorder+0x270>
		0000000000003400:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    3404:      	add	x0, x23, #0x1
    3408:      	add	x16, sp, #0x40
    340c:      	ldr	x1, [x16]
    3410:      	add	x1, x1, x23, lsl #4
    3414:      	str	x19, [x1]
    3418:      	movz	x17, #0x0, lsl #48
    341c:      	str	x17, [x1, #0x8]
    3420:      	add	x16, sp, #0x40
    3424:      	str	x0, [x16, #0x8]
    3428:      	add	x16, sp, #0x40
    342c:      	ldr	x0, [x16, #0x8]
    3430:      	cmp	x0, #0x0
    3434:      	b.le	0x3554 <_stogir.adjacency.reverse-postorder+0x3c4>
    3438:      	add	x16, sp, #0x40
    343c:      	ldr	x1, [x16]
    3440:      	sub	x0, x0, #0x1
    3444:      	add	x2, x1, x0, lsl #4
    3448:      	ldr	x3, [x2]
    344c:      	orr	w19, w3, wzr
    3450:      	ldr	x2, [x2, #0x8]
    3454:      	sxtw	x4, w19
    3458:      	ldr	x5, [x22]
    345c:      	add	x4, x5, x4, lsl #4
    3460:      	ldr	x5, [x4]
    3464:      	ldr	x4, [x4, #0x8]
    3468:      	cmp	x2, x4
    346c:      	b.lt	0x349c <_stogir.adjacency.reverse-postorder+0x30c>
    3470:      	add	x16, sp, #0x70
    3474:      	ldr	x0, [x16, #0x8]
    3478:      	orr	x23, x0, xzr
    347c:      	add	x16, sp, #0x70
    3480:      	ldr	x0, [x16, #0x10]
    3484:      	cmp	x23, x0
    3488:      	b.lt	0x33b8 <_stogir.adjacency.reverse-postorder+0x228>
    348c:      	cmp	x0, #0x0
    3490:      	b.ne	0x33a8 <_stogir.adjacency.reverse-postorder+0x218>
    3494:      	mov	x0, #0x2                ; =2
    3498:      	b	0x33ac <_stogir.adjacency.reverse-postorder+0x21c>
    349c:      	add	x4, x2, x5
    34a0:      	add	x2, x2, #0x1
    34a4:      	ldr	x5, [x22, #0x28]
    34a8:      	add	x0, x1, x0, lsl #4
    34ac:      	add	x1, x5, x4, lsl #3
    34b0:      	ldr	x1, [x1]
    34b4:      	ldr	x4, [x21, #0x50]
    34b8:      	add	x1, x4, x1, lsl #4
    34bc:      	ldr	x1, [x1]
    34c0:      	str	x3, [x0]
    34c4:      	lsr	x1, x1, #32
    34c8:      	str	x2, [x0, #0x8]
    34cc:      	sxtw	x0, w1
    34d0:      	add	x16, sp, #0x10
    34d4:      	ldr	x2, [x16]
    34d8:      	add	x3, x2, x0
    34dc:      	ldrb	w3, [x3]
    34e0:      	cmp	x3, #0x0
    34e4:      	b.ne	0x3428 <_stogir.adjacency.reverse-postorder+0x298>
    34e8:      	add	x0, x2, x0
    34ec:      	mov	w17, #0x1               ; =1
    34f0:      	strb	w17, [x0]
    34f4:      	add	x16, sp, #0xe0
    34f8:      	movz	x17, #0x0, lsl #48
    34fc:      	str	x17, [x16]
    3500:      	add	x16, sp, #0xe0
    3504:      	movz	x17, #0x0, lsl #48
    3508:      	str	x17, [x16, #0x8]
    350c:      	add	x16, sp, #0xe0
    3510:      	str	w1, [x16]
    3514:      	add	x16, sp, #0xe0
    3518:      	movz	x17, #0x0, lsl #48
    351c:      	str	x17, [x16, #0x8]
    3520:      	add	x16, sp, #0xe0
    3524:      	ldr	x19, [x16]
    3528:      	add	x16, sp, #0x40
    352c:      	ldr	x0, [x16, #0x8]
    3530:      	orr	x23, x0, xzr
    3534:      	add	x16, sp, #0x40
    3538:      	ldr	x0, [x16, #0x10]
    353c:      	cmp	x23, x0
    3540:      	b.lt	0x3404 <_stogir.adjacency.reverse-postorder+0x274>
    3544:      	cmp	x0, #0x0
    3548:      	b.ne	0x33f4 <_stogir.adjacency.reverse-postorder+0x264>
    354c:      	mov	x0, #0x2                ; =2
    3550:      	b	0x33f8 <_stogir.adjacency.reverse-postorder+0x268>
    3554:      	add	x16, sp, #0x70
    3558:      	ldr	x0, [x16, #0x8]
    355c:      	orr	x19, x0, xzr
    3560:      	b	0x3594 <_stogir.adjacency.reverse-postorder+0x404>
    3564:      	nop
    3568:      	lsl	x0, x0, #1
    356c:      	mov	x1, x0
    3570:      	add	x0, sp, #0xa0
    3574:      	bl	0x3574 <_stogir.adjacency.reverse-postorder+0x3e4>
		0000000000003574:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3578:      	add	x0, x22, #0x1
    357c:      	add	x16, sp, #0xa0
    3580:      	ldr	x1, [x16]
    3584:      	add	x1, x1, x22, lsl #2
    3588:      	str	w21, [x1]
    358c:      	add	x16, sp, #0xa0
    3590:      	str	x0, [x16, #0x8]
    3594:      	cmp	x19, #0x0
    3598:      	b.le	0x35dc <_stogir.adjacency.reverse-postorder+0x44c>
    359c:      	sub	x19, x19, #0x1
    35a0:      	add	x16, sp, #0x70
    35a4:      	ldr	x0, [x16]
    35a8:      	add	x0, x0, x19, lsl #2
    35ac:      	ldr	w21, [x0]
    35b0:      	add	x16, sp, #0xa0
    35b4:      	ldr	x0, [x16, #0x8]
    35b8:      	orr	x22, x0, xzr
    35bc:      	add	x16, sp, #0xa0
    35c0:      	ldr	x0, [x16, #0x10]
    35c4:      	cmp	x22, x0
    35c8:      	b.lt	0x3578 <_stogir.adjacency.reverse-postorder+0x3e8>
    35cc:      	cmp	x0, #0x0
    35d0:      	b.ne	0x3568 <_stogir.adjacency.reverse-postorder+0x3d8>
    35d4:      	mov	x0, #0x2                ; =2
    35d8:      	b	0x356c <_stogir.adjacency.reverse-postorder+0x3dc>
    35dc:      	b	0x35ec <_stogir.adjacency.reverse-postorder+0x45c>
    35e0:      	sub	x0, x0, #0x1
    35e4:      	add	x16, sp, #0x10
    35e8:      	str	x0, [x16, #0x8]
    35ec:      	add	x16, sp, #0x10
    35f0:      	ldr	x0, [x16, #0x8]
    35f4:      	cmp	x0, #0x0
    35f8:      	b.ne	0x35e0 <_stogir.adjacency.reverse-postorder+0x450>
    35fc:      	add	x16, sp, #0x10
    3600:      	orr	x0, x16, xzr
    3604:      	add	x16, sp, #0x10
    3608:      	ldr	x1, [x16, #0x10]
    360c:      	cmp	x1, #0x0
    3610:      	b.le	0x3640 <_stogir.adjacency.reverse-postorder+0x4b0>
    3614:      	add	x0, x0, #0x18
    3618:      	add	x16, sp, #0x10
    361c:      	ldr	x2, [x16]
    3620:      	fmov	d31, x1
    3624:      	mov	x1, x2
    3628:      	fmov	x2, d31
    362c:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		000000000000362c:  ARM64_RELOC_PAGE21	l_stogir.412
    3630:      	ldr	x3, [x3]
		0000000000003630:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    3634:      	mov	x4, #0x1                ; =1
    3638:      	mov	x5, #0x1                ; =1
    363c:      	bl	0x363c <_stogir.adjacency.reverse-postorder+0x4ac>
		000000000000363c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3640:      	add	x16, sp, #0x10
    3644:      	movz	x17, #0x0, lsl #48
    3648:      	str	x17, [x16]
    364c:      	add	x16, sp, #0x10
    3650:      	movz	x17, #0x0, lsl #48
    3654:      	str	x17, [x16, #0x8]
    3658:      	add	x16, sp, #0x10
    365c:      	movz	x17, #0x0, lsl #48
    3660:      	str	x17, [x16, #0x10]
    3664:      	b	0x3674 <_stogir.adjacency.reverse-postorder+0x4e4>
    3668:      	sub	x0, x0, #0x1
    366c:      	add	x16, sp, #0x40
    3670:      	str	x0, [x16, #0x8]
    3674:      	add	x16, sp, #0x40
    3678:      	ldr	x0, [x16, #0x8]
    367c:      	cmp	x0, #0x0
    3680:      	b.ne	0x3668 <_stogir.adjacency.reverse-postorder+0x4d8>
    3684:      	add	x16, sp, #0x40
    3688:      	orr	x0, x16, xzr
    368c:      	add	x16, sp, #0x40
    3690:      	ldr	x1, [x16, #0x10]
    3694:      	cmp	x1, #0x0
    3698:      	b.le	0x36c8 <_stogir.adjacency.reverse-postorder+0x538>
    369c:      	add	x0, x0, #0x18
    36a0:      	add	x16, sp, #0x40
    36a4:      	ldr	x2, [x16]
    36a8:      	fmov	d31, x1
    36ac:      	mov	x1, x2
    36b0:      	fmov	x2, d31
    36b4:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		00000000000036b4:  ARM64_RELOC_PAGE21	l_stogir.413
    36b8:      	ldr	x3, [x3]
		00000000000036b8:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    36bc:      	mov	x4, #0x10               ; =16
    36c0:      	mov	x5, #0x8                ; =8
    36c4:      	bl	0x36c4 <_stogir.adjacency.reverse-postorder+0x534>
		00000000000036c4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    36c8:      	add	x16, sp, #0x40
    36cc:      	movz	x17, #0x0, lsl #48
    36d0:      	str	x17, [x16]
    36d4:      	add	x16, sp, #0x40
    36d8:      	movz	x17, #0x0, lsl #48
    36dc:      	str	x17, [x16, #0x8]
    36e0:      	add	x16, sp, #0x40
    36e4:      	movz	x17, #0x0, lsl #48
    36e8:      	str	x17, [x16, #0x10]
    36ec:      	b	0x36fc <_stogir.adjacency.reverse-postorder+0x56c>
    36f0:      	sub	x0, x0, #0x1
    36f4:      	add	x16, sp, #0x70
    36f8:      	str	x0, [x16, #0x8]
    36fc:      	add	x16, sp, #0x70
    3700:      	ldr	x0, [x16, #0x8]
    3704:      	cmp	x0, #0x0
    3708:      	b.ne	0x36f0 <_stogir.adjacency.reverse-postorder+0x560>
    370c:      	add	x16, sp, #0x70
    3710:      	orr	x0, x16, xzr
    3714:      	add	x16, sp, #0x70
    3718:      	ldr	x1, [x16, #0x10]
    371c:      	cmp	x1, #0x0
    3720:      	b.le	0x3750 <_stogir.adjacency.reverse-postorder+0x5c0>
    3724:      	add	x0, x0, #0x18
    3728:      	add	x16, sp, #0x70
    372c:      	ldr	x2, [x16]
    3730:      	fmov	d31, x1
    3734:      	mov	x1, x2
    3738:      	fmov	x2, d31
    373c:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		000000000000373c:  ARM64_RELOC_PAGE21	l_stogir.414
    3740:      	ldr	x3, [x3]
		0000000000003740:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    3744:      	mov	x4, #0x4                ; =4
    3748:      	mov	x5, #0x4                ; =4
    374c:      	bl	0x374c <_stogir.adjacency.reverse-postorder+0x5bc>
		000000000000374c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3750:      	add	x16, sp, #0x70
    3754:      	movz	x17, #0x0, lsl #48
    3758:      	str	x17, [x16]
    375c:      	add	x16, sp, #0x70
    3760:      	movz	x17, #0x0, lsl #48
    3764:      	str	x17, [x16, #0x8]
    3768:      	add	x16, sp, #0x70
    376c:      	movz	x17, #0x0, lsl #48
    3770:      	str	x17, [x16, #0x10]
    3774:      	add	x16, sp, #0xa0
    3778:      	ldr	x0, [x16]
    377c:      	add	x16, sp, #0xa0
    3780:      	ldr	x1, [x16, #0x8]
    3784:      	add	x16, sp, #0xa0
    3788:      	ldr	x2, [x16, #0x10]
    378c:      	add	x16, sp, #0xa0
    3790:      	ldr	x3, [x16, #0x18]
    3794:      	add	x16, sp, #0xa0
    3798:      	ldr	x4, [x16, #0x20]
    379c:      	str	x0, [x20]
    37a0:      	str	x1, [x20, #0x8]
    37a4:      	str	x2, [x20, #0x10]
    37a8:      	str	x3, [x20, #0x18]
    37ac:      	str	x4, [x20, #0x20]
    37b0:      	ldr	x19, [sp, #0xf0]
    37b4:      	ldr	x20, [sp, #0xf8]
    37b8:      	ldr	x21, [sp, #0x100]
    37bc:      	ldr	x22, [sp, #0x108]
    37c0:      	ldr	x23, [sp, #0x110]
    37c4:      	ldr	x24, [sp, #0x118]
    37c8:      	ldr	x29, [sp]
    37cc:      	ldr	x30, [sp, #0x8]
    37d0:      	add	sp, sp, #0x120
    37d4:      	ret
    37d8:      	mov	x20, x8
    37dc:      	mov	x21, x0
    37e0:      	mov	x22, x1
    37e4:      	mov	w23, w2
    37e8:      	b	0x32d4 <_stogir.adjacency.reverse-postorder+0x144>
    37ec:      	udf	#0x0

00000000000037f0 <_stogir.dominators.build>:
    37f0:      	sub	sp, sp, #0xb0
    37f4:      	str	x29, [sp]
    37f8:      	str	x30, [sp, #0x8]
    37fc:      	mov	x29, sp
    3800:      	str	x19, [sp, #0x70]
    3804:      	str	x20, [sp, #0x78]
    3808:      	str	x21, [sp, #0x80]
    380c:      	str	x22, [sp, #0x88]
    3810:      	str	x23, [sp, #0x90]
    3814:      	str	x24, [sp, #0x98]
    3818:      	str	x25, [sp, #0xa0]
    381c:      	add	x19, x0, #0x28
    3820:      	ldr	x4, [x3]
    3824:      	ldr	x3, [x3, #0x8]
    3828:      	add	x16, sp, #0x10
    382c:      	movz	x17, #0x0, lsl #48
    3830:      	str	x17, [x16]
    3834:      	add	x16, sp, #0x10
    3838:      	movz	x17, #0x0, lsl #48
    383c:      	str	x17, [x16, #0x8]
    3840:      	add	x16, sp, #0x10
    3844:      	movz	x17, #0x0, lsl #48
    3848:      	str	x17, [x16, #0x10]
    384c:      	add	x16, sp, #0x10
    3850:      	str	x4, [x16, #0x18]
    3854:      	add	x16, sp, #0x10
    3858:      	str	x3, [x16, #0x20]
    385c:      	add	x16, sp, #0x40
    3860:      	movz	x17, #0x0, lsl #48
    3864:      	str	x17, [x16]
    3868:      	add	x16, sp, #0x40
    386c:      	movz	x17, #0x0, lsl #48
    3870:      	str	x17, [x16, #0x8]
    3874:      	add	x16, sp, #0x40
    3878:      	movz	x17, #0x0, lsl #48
    387c:      	str	x17, [x16, #0x10]
    3880:      	add	x16, sp, #0x40
    3884:      	str	x4, [x16, #0x18]
    3888:      	add	x16, sp, #0x40
    388c:      	str	x3, [x16, #0x20]
    3890:      	ldr	x3, [x19, #0x8]
    3894:      	orr	x20, x3, xzr
    3898:      	cmp	x20, #0x0
    389c:      	b.le	0x3c34 <_stogir.dominators.build+0x444>
    38a0:      	cmp	x20, #0x0
    38a4:      	b.ge	0x38b0 <_stogir.dominators.build+0xc0>
    38a8:      	movz	x3, #0x0, lsl #48
    38ac:      	b	0x38b4 <_stogir.dominators.build+0xc4>
    38b0:      	mov	x3, x20
    38b4:      	mov	x21, x8
    38b8:      	mov	x22, x0
    38bc:      	add	x0, sp, #0x10
    38c0:      	mov	x23, x1
    38c4:      	mov	x1, x3
    38c8:      	mov	x24, x2
    38cc:      	bl	0x38cc <_stogir.dominators.build+0xdc>
		00000000000038cc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    38d0:      	lsl	x0, x20, #2
    38d4:      	add	x16, sp, #0x10
    38d8:      	ldr	x1, [x16]
    38dc:      	mov	x2, x0
    38e0:      	mov	x0, x1
    38e4:      	movz	x1, #0x0, lsl #48
    38e8:      	bl	0x38e8 <_stogir.dominators.build+0xf8>
		00000000000038e8:  ARM64_RELOC_BRANCH26	_memset
    38ec:      	add	x16, sp, #0x10
    38f0:      	str	x20, [x16, #0x8]
    38f4:      	movz	x20, #0x0, lsl #48
    38f8:      	b	0x3934 <_stogir.dominators.build+0x144>
    38fc:      	nop
    3900:      	lsl	x0, x0, #1
    3904:      	mov	x1, x0
    3908:      	add	x0, sp, #0x40
    390c:      	bl	0x390c <_stogir.dominators.build+0x11c>
		000000000000390c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    3910:      	add	x20, x20, #0x1
    3914:      	add	x0, x25, #0x1
    3918:      	add	x16, sp, #0x40
    391c:      	ldr	x1, [x16]
    3920:      	add	x1, x1, x25, lsl #3
    3924:      	movn	x17, #0x0, lsl #48
    3928:      	str	x17, [x1]
    392c:      	add	x16, sp, #0x40
    3930:      	str	x0, [x16, #0x8]
    3934:      	ldr	x0, [x19, #0x8]
    3938:      	cmp	x20, x0
    393c:      	b.ge	0x396c <_stogir.dominators.build+0x17c>
    3940:      	add	x16, sp, #0x40
    3944:      	ldr	x0, [x16, #0x8]
    3948:      	orr	x25, x0, xzr
    394c:      	add	x16, sp, #0x40
    3950:      	ldr	x0, [x16, #0x10]
    3954:      	cmp	x25, x0
    3958:      	b.lt	0x3910 <_stogir.dominators.build+0x120>
    395c:      	cmp	x0, #0x0
    3960:      	b.ne	0x3900 <_stogir.dominators.build+0x110>
    3964:      	mov	x0, #0x2                ; =2
    3968:      	b	0x3904 <_stogir.dominators.build+0x114>
    396c:      	movz	x0, #0x0, lsl #48
    3970:      	b	0x39a0 <_stogir.dominators.build+0x1b0>
    3974:      	nop
    3978:      	add	x1, x0, #0x1
    397c:      	ldr	x2, [x24]
    3980:      	add	x2, x2, x0, lsl #2
    3984:      	ldr	w2, [x2]
    3988:      	sxtw	x2, w2
    398c:      	add	x16, sp, #0x40
    3990:      	ldr	x3, [x16]
    3994:      	add	x2, x3, x2, lsl #3
    3998:      	str	x0, [x2]
    399c:      	mov	x0, x1
    39a0:      	ldr	x1, [x24, #0x8]
    39a4:      	cmp	x0, x1
    39a8:      	b.lt	0x3978 <_stogir.dominators.build+0x188>
    39ac:      	cmp	x1, #0x0
    39b0:      	b.le	0x3b40 <_stogir.dominators.build+0x350>
    39b4:      	ldr	x0, [x24]
    39b8:      	ldr	w0, [x0]
    39bc:      	sxtw	x1, w0
    39c0:      	add	x16, sp, #0x10
    39c4:      	ldr	x2, [x16]
    39c8:      	add	x1, x2, x1, lsl #2
    39cc:      	str	w0, [x1]
    39d0:      	b	0x3b34 <_stogir.dominators.build+0x344>
    39d4:      	nop
    39d8:      	add	x16, sp, #0x10
    39dc:      	ldr	x6, [x16]
    39e0:      	add	x6, x6, x11, lsl #2
    39e4:      	ldr	w6, [x6]
    39e8:      	add	x16, sp, #0x40
    39ec:      	ldr	x9, [x16]
    39f0:      	orr	x10, x9, xzr
    39f4:      	sxtw	x11, w6
    39f8:      	add	x9, x8, x9
    39fc:      	lsl	x12, x11, #3
    3a00:      	add	x10, x10, x11, lsl #3
    3a04:      	ldr	x10, [x10]
    3a08:      	ldr	x9, [x9]
    3a0c:      	cmp	x10, x9
    3a10:      	b.gt	0x39d8 <_stogir.dominators.build+0x1e8>
    3a14:      	b	0x3a28 <_stogir.dominators.build+0x238>
    3a18:      	add	x16, sp, #0x10
    3a1c:      	ldr	x7, [x16]
    3a20:      	add	x7, x7, x10, lsl #2
    3a24:      	ldr	w7, [x7]
    3a28:      	add	x16, sp, #0x40
    3a2c:      	ldr	x8, [x16]
    3a30:      	orr	x9, x8, xzr
    3a34:      	sxtw	x10, w7
    3a38:      	add	x8, x12, x8
    3a3c:      	add	x9, x9, x10, lsl #3
    3a40:      	ldr	x9, [x9]
    3a44:      	ldr	x8, [x8]
    3a48:      	cmp	x9, x8
    3a4c:      	b.gt	0x3a18 <_stogir.dominators.build+0x228>
    3a50:      	sxtw	x10, w6
    3a54:      	sxtw	x8, w7
    3a58:      	cmp	x10, x8
    3a5c:      	b.eq	0x3a68 <_stogir.dominators.build+0x278>
    3a60:      	lsl	x8, x8, #3
    3a64:      	b	0x39e8 <_stogir.dominators.build+0x1f8>
    3a68:      	orr	w6, w10, wzr
    3a6c:      	add	x5, x5, #0x1
    3a70:      	sxtw	x7, w6
    3a74:      	cmp	x5, x3
    3a78:      	b.ge	0x3ac8 <_stogir.dominators.build+0x2d8>
    3a7c:      	add	x8, x4, x5
    3a80:      	ldr	x9, [x23, #0x28]
    3a84:      	add	x8, x9, x8, lsl #3
    3a88:      	ldr	x8, [x8]
    3a8c:      	ldr	x9, [x22, #0x50]
    3a90:      	add	x8, x9, x8, lsl #4
    3a94:      	ldr	x8, [x8]
    3a98:      	add	x16, sp, #0x10
    3a9c:      	ldr	x9, [x16]
    3aa0:      	sxtw	x10, w8
    3aa4:      	add	x9, x9, x10, lsl #2
    3aa8:      	ldr	w9, [x9]
    3aac:      	sxtw	x9, w9
    3ab0:      	cmp	x9, #0x0
    3ab4:      	b.eq	0x3a6c <_stogir.dominators.build+0x27c>
    3ab8:      	cmp	x7, #0x0
    3abc:      	b.eq	0x3a68 <_stogir.dominators.build+0x278>
    3ac0:      	orr	w7, w8, wzr
    3ac4:      	b	0x3a50 <_stogir.dominators.build+0x260>
    3ac8:      	add	x16, sp, #0x10
    3acc:      	ldr	x3, [x16]
    3ad0:      	add	x4, x3, x2, lsl #2
    3ad4:      	ldr	w4, [x4]
    3ad8:      	sxtw	x4, w4
    3adc:      	cmp	x4, x7
    3ae0:      	b.eq	0x3af0 <_stogir.dominators.build+0x300>
    3ae4:      	add	x1, x3, x2, lsl #2
    3ae8:      	str	w6, [x1]
    3aec:      	mov	x1, #0x1                ; =1
    3af0:      	add	x0, x0, #0x1
    3af4:      	ldr	x2, [x24, #0x8]
    3af8:      	cmp	x0, x2
    3afc:      	b.ge	0x3b2c <_stogir.dominators.build+0x33c>
    3b00:      	ldr	x2, [x24]
    3b04:      	add	x2, x2, x0, lsl #2
    3b08:      	ldr	w2, [x2]
    3b0c:      	sxtw	x2, w2
    3b10:      	ldr	x3, [x23]
    3b14:      	add	x3, x3, x2, lsl #4
    3b18:      	ldr	x4, [x3]
    3b1c:      	ldr	x3, [x3, #0x8]
    3b20:      	movz	x5, #0x0, lsl #48
    3b24:      	movz	w6, #0x0, lsl #16
    3b28:      	b	0x3a70 <_stogir.dominators.build+0x280>
    3b2c:      	cmp	x1, #0x0
    3b30:      	b.eq	0x3b40 <_stogir.dominators.build+0x350>
    3b34:      	mov	x0, #0x1                ; =1
    3b38:      	movz	x1, #0x0, lsl #48
    3b3c:      	b	0x3af4 <_stogir.dominators.build+0x304>
    3b40:      	b	0x3b54 <_stogir.dominators.build+0x364>
    3b44:      	nop
    3b48:      	sub	x0, x0, #0x1
    3b4c:      	add	x16, sp, #0x40
    3b50:      	str	x0, [x16, #0x8]
    3b54:      	add	x16, sp, #0x40
    3b58:      	ldr	x0, [x16, #0x8]
    3b5c:      	cmp	x0, #0x0
    3b60:      	b.ne	0x3b48 <_stogir.dominators.build+0x358>
    3b64:      	add	x16, sp, #0x40
    3b68:      	orr	x0, x16, xzr
    3b6c:      	add	x16, sp, #0x40
    3b70:      	ldr	x1, [x16, #0x10]
    3b74:      	cmp	x1, #0x0
    3b78:      	b.le	0x3ba8 <_stogir.dominators.build+0x3b8>
    3b7c:      	add	x0, x0, #0x18
    3b80:      	add	x16, sp, #0x40
    3b84:      	ldr	x2, [x16]
    3b88:      	fmov	d31, x1
    3b8c:      	mov	x1, x2
    3b90:      	fmov	x2, d31
    3b94:      	adrp	x3, 0x3000 <_stogir.adjacency.build+0x300>
		0000000000003b94:  ARM64_RELOC_PAGE21	l_stogir.415
    3b98:      	ldr	x3, [x3]
		0000000000003b98:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    3b9c:      	mov	x4, #0x8                ; =8
    3ba0:      	mov	x5, #0x8                ; =8
    3ba4:      	bl	0x3ba4 <_stogir.dominators.build+0x3b4>
		0000000000003ba4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    3ba8:      	add	x16, sp, #0x40
    3bac:      	movz	x17, #0x0, lsl #48
    3bb0:      	str	x17, [x16]
    3bb4:      	add	x16, sp, #0x40
    3bb8:      	movz	x17, #0x0, lsl #48
    3bbc:      	str	x17, [x16, #0x8]
    3bc0:      	add	x16, sp, #0x40
    3bc4:      	movz	x17, #0x0, lsl #48
    3bc8:      	str	x17, [x16, #0x10]
    3bcc:      	add	x16, sp, #0x10
    3bd0:      	ldr	x0, [x16]
    3bd4:      	add	x16, sp, #0x10
    3bd8:      	ldr	x1, [x16, #0x8]
    3bdc:      	add	x16, sp, #0x10
    3be0:      	ldr	x2, [x16, #0x10]
    3be4:      	add	x16, sp, #0x10
    3be8:      	ldr	x3, [x16, #0x18]
    3bec:      	add	x16, sp, #0x10
    3bf0:      	ldr	x4, [x16, #0x20]
    3bf4:      	str	x0, [x21]
    3bf8:      	str	x1, [x21, #0x8]
    3bfc:      	str	x2, [x21, #0x10]
    3c00:      	str	x3, [x21, #0x18]
    3c04:      	str	x4, [x21, #0x20]
    3c08:      	ldr	x19, [sp, #0x70]
    3c0c:      	ldr	x20, [sp, #0x78]
    3c10:      	ldr	x21, [sp, #0x80]
    3c14:      	ldr	x22, [sp, #0x88]
    3c18:      	ldr	x23, [sp, #0x90]
    3c1c:      	ldr	x24, [sp, #0x98]
    3c20:      	ldr	x25, [sp, #0xa0]
    3c24:      	ldr	x29, [sp]
    3c28:      	ldr	x30, [sp, #0x8]
    3c2c:      	add	sp, sp, #0xb0
    3c30:      	ret
    3c34:      	mov	x21, x8
    3c38:      	mov	x22, x0
    3c3c:      	mov	x23, x1
    3c40:      	mov	x24, x2
    3c44:      	b	0x38d0 <_stogir.dominators.build+0xe0>

0000000000003c48 <_stogir.loops.depths>:
    3c48:      	sub	sp, sp, #0x1d0
    3c4c:      	str	x29, [sp]
    3c50:      	str	x30, [sp, #0x8]
    3c54:      	mov	x29, sp
    3c58:      	str	x19, [sp, #0x180]
    3c5c:      	str	x20, [sp, #0x188]
    3c60:      	str	x21, [sp, #0x190]
    3c64:      	str	x22, [sp, #0x198]
    3c68:      	str	x23, [sp, #0x1a0]
    3c6c:      	str	x24, [sp, #0x1a8]
    3c70:      	str	x25, [sp, #0x1b0]
    3c74:      	str	x26, [sp, #0x1b8]
    3c78:      	str	x27, [sp, #0x1c0]
    3c7c:      	str	x28, [sp, #0x1c8]
    3c80:      	add	x19, x0, #0x28
    3c84:      	mov	x20, x8
    3c88:      	add	x8, sp, #0x60
    3c8c:      	mov	x21, x0
    3c90:      	mov	x0, x2
    3c94:      	mov	x22, x1
    3c98:      	mov	x1, x3
    3c9c:      	mov	x23, x2
    3ca0:      	mov	x24, x3
    3ca4:      	bl	0x3ca4 <_stogir.loops.depths+0x5c>
		0000000000003ca4:  ARM64_RELOC_BRANCH26	_stogir.dominators.build-index
    3ca8:      	add	x16, sp, #0x60
    3cac:      	ldr	x0, [x16]
    3cb0:      	add	x16, sp, #0x10
    3cb4:      	str	x0, [x16]
    3cb8:      	add	x16, sp, #0x60
    3cbc:      	ldr	x0, [x16, #0x8]
    3cc0:      	add	x16, sp, #0x10
    3cc4:      	str	x0, [x16, #0x8]
    3cc8:      	add	x16, sp, #0x60
    3ccc:      	ldr	x0, [x16, #0x10]
    3cd0:      	add	x16, sp, #0x10
    3cd4:      	str	x0, [x16, #0x10]
    3cd8:      	add	x16, sp, #0x60
    3cdc:      	ldr	x0, [x16, #0x18]
    3ce0:      	add	x16, sp, #0x10
    3ce4:      	str	x0, [x16, #0x18]
    3ce8:      	add	x16, sp, #0x60
    3cec:      	ldr	x0, [x16, #0x20]
    3cf0:      	add	x16, sp, #0x10
    3cf4:      	str	x0, [x16, #0x20]
    3cf8:      	add	x16, sp, #0x60
    3cfc:      	ldr	x0, [x16, #0x28]
    3d00:      	add	x16, sp, #0x10
    3d04:      	str	x0, [x16, #0x28]
    3d08:      	add	x16, sp, #0x60
    3d0c:      	ldr	x0, [x16, #0x30]
    3d10:      	add	x16, sp, #0x10
    3d14:      	str	x0, [x16, #0x30]
    3d18:      	add	x16, sp, #0x60
    3d1c:      	ldr	x0, [x16, #0x38]
    3d20:      	add	x16, sp, #0x10
    3d24:      	str	x0, [x16, #0x38]
    3d28:      	add	x16, sp, #0x60
    3d2c:      	ldr	x0, [x16, #0x40]
    3d30:      	add	x16, sp, #0x10
    3d34:      	str	x0, [x16, #0x40]
    3d38:      	add	x16, sp, #0x60
    3d3c:      	ldr	x0, [x16, #0x48]
    3d40:      	add	x16, sp, #0x10
    3d44:      	str	x0, [x16, #0x48]
    3d48:      	ldr	x0, [x24]
    3d4c:      	ldr	x1, [x24, #0x8]
    3d50:      	add	x16, sp, #0xb0
    3d54:      	movz	x17, #0x0, lsl #48
    3d58:      	str	x17, [x16]
    3d5c:      	add	x16, sp, #0xb0
    3d60:      	movz	x17, #0x0, lsl #48
    3d64:      	str	x17, [x16, #0x8]
    3d68:      	add	x16, sp, #0xb0
    3d6c:      	movz	x17, #0x0, lsl #48
    3d70:      	str	x17, [x16, #0x10]
    3d74:      	add	x16, sp, #0xb0
    3d78:      	str	x0, [x16, #0x18]
    3d7c:      	add	x16, sp, #0xb0
    3d80:      	str	x1, [x16, #0x20]
    3d84:      	add	x16, sp, #0xe0
    3d88:      	movz	x17, #0x0, lsl #48
    3d8c:      	str	x17, [x16]
    3d90:      	add	x16, sp, #0xe0
    3d94:      	movz	x17, #0x0, lsl #48
    3d98:      	str	x17, [x16, #0x8]
    3d9c:      	add	x16, sp, #0xe0
    3da0:      	movz	x17, #0x0, lsl #48
    3da4:      	str	x17, [x16, #0x10]
    3da8:      	add	x16, sp, #0xe0
    3dac:      	str	x0, [x16, #0x18]
    3db0:      	add	x16, sp, #0xe0
    3db4:      	str	x1, [x16, #0x20]
    3db8:      	add	x16, sp, #0x110
    3dbc:      	movz	x17, #0x0, lsl #48
    3dc0:      	str	x17, [x16]
    3dc4:      	add	x16, sp, #0x110
    3dc8:      	movz	x17, #0x0, lsl #48
    3dcc:      	str	x17, [x16, #0x8]
    3dd0:      	add	x16, sp, #0x110
    3dd4:      	movz	x17, #0x0, lsl #48
    3dd8:      	str	x17, [x16, #0x10]
    3ddc:      	add	x16, sp, #0x110
    3de0:      	str	x0, [x16, #0x18]
    3de4:      	add	x16, sp, #0x110
    3de8:      	str	x1, [x16, #0x20]
    3dec:      	ldr	x0, [x19, #0x8]
    3df0:      	orr	x24, x0, xzr
    3df4:      	add	x16, sp, #0xb0
    3df8:      	ldr	x0, [x16, #0x8]
    3dfc:      	orr	x25, x0, xzr
    3e00:      	add	x16, sp, #0xb0
    3e04:      	ldr	x0, [x16, #0x10]
    3e08:      	add	x26, x25, x24
    3e0c:      	cmp	x26, x0
    3e10:      	b.le	0x3e44 <_stogir.loops.depths+0x1fc>
    3e14:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    3e18:      	cmp	x0, x17
    3e1c:      	b.gt	0x3e28 <_stogir.loops.depths+0x1e0>
    3e20:      	lsl	x0, x0, #1
    3e24:      	b	0x3e2c <_stogir.loops.depths+0x1e4>
    3e28:      	mov	x0, x26
    3e2c:      	cmp	x0, x26
    3e30:      	b.gt	0x3e38 <_stogir.loops.depths+0x1f0>
    3e34:      	mov	x0, x26
    3e38:      	mov	x1, x0
    3e3c:      	add	x0, sp, #0xb0
    3e40:      	bl	0x3e40 <_stogir.loops.depths+0x1f8>
		0000000000003e40:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3e44:      	lsl	x0, x24, #2
    3e48:      	add	x16, sp, #0xb0
    3e4c:      	ldr	x1, [x16]
    3e50:      	add	x1, x1, x25, lsl #2
    3e54:      	mov	x2, x0
    3e58:      	mov	x0, x1
    3e5c:      	movz	x1, #0x0, lsl #48
    3e60:      	bl	0x3e60 <_stogir.loops.depths+0x218>
		0000000000003e60:  ARM64_RELOC_BRANCH26	_memset
    3e64:      	add	x16, sp, #0xb0
    3e68:      	str	x26, [x16, #0x8]
    3e6c:      	ldr	x0, [x19, #0x8]
    3e70:      	mov	x1, x0
    3e74:      	add	x0, sp, #0xe0
    3e78:      	bl	0x3e78 <_stogir.loops.depths+0x230>
		0000000000003e78:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    3e7c:      	ldr	x0, [x21]
    3e80:      	ldr	x1, [x21, #0x8]
    3e84:      	orr	x19, x0, xzr
    3e88:      	orr	x24, x1, xzr
    3e8c:      	movz	x25, #0x0, lsl #48
    3e90:      	b	0x3ff4 <_stogir.loops.depths+0x3ac>
    3e94:      	lsl	x2, x2, #1
    3e98:      	str	x21, [sp, #0x170]
    3e9c:      	mov	w21, w0
    3ea0:      	add	x0, sp, #0x110
    3ea4:      	str	x22, [sp, #0x178]
    3ea8:      	mov	x22, x1
    3eac:      	mov	x1, x2
    3eb0:      	bl	0x3eb0 <_stogir.loops.depths+0x268>
		0000000000003eb0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    3eb4:      	add	x0, x22, #0x1
    3eb8:      	add	x16, sp, #0x110
    3ebc:      	ldr	x1, [x16]
    3ec0:      	add	x1, x1, x22, lsl #2
    3ec4:      	str	w21, [x1]
    3ec8:      	add	x16, sp, #0x110
    3ecc:      	str	x0, [x16, #0x8]
    3ed0:      	b	0x3ee0 <_stogir.loops.depths+0x298>
    3ed4:      	nop
    3ed8:      	str	x21, [sp, #0x170]
    3edc:      	str	x22, [sp, #0x178]
    3ee0:      	add	x28, x28, #0x1
    3ee4:      	ldr	x21, [sp, #0x170]
    3ee8:      	ldr	x22, [sp, #0x178]
    3eec:      	cmp	x28, x25
    3ef0:      	b.ge	0x4438 <_stogir.loops.depths+0x7f0>
    3ef4:      	add	x0, x24, x28
    3ef8:      	ldr	x1, [x22, #0x28]
    3efc:      	add	x0, x1, x0, lsl #3
    3f00:      	ldr	x0, [x0]
    3f04:      	ldr	x1, [x21, #0x50]
    3f08:      	add	x0, x1, x0, lsl #4
    3f0c:      	ldr	x0, [x0]
    3f10:      	ldr	x1, [x23]
    3f14:      	sxtw	x2, w0
    3f18:      	add	x1, x1, x2, lsl #2
    3f1c:      	ldr	w1, [x1]
    3f20:      	sxtw	x1, w1
    3f24:      	cmp	x1, #0x0
    3f28:      	b.eq	0x3ed8 <_stogir.loops.depths+0x290>
    3f2c:      	add	x16, sp, #0xe0
    3f30:      	ldr	x1, [x16]
    3f34:      	add	x3, x1, x2, lsl #2
    3f38:      	ldr	w3, [x3]
    3f3c:      	sxtw	x3, w3
    3f40:      	cmp	x3, x26
    3f44:      	b.eq	0x4444 <_stogir.loops.depths+0x7fc>
    3f48:      	add	x1, x1, x2, lsl #2
    3f4c:      	str	w27, [x1]
    3f50:      	add	x16, sp, #0xb0
    3f54:      	ldr	x1, [x16]
    3f58:      	orr	x3, x1, xzr
    3f5c:      	add	x3, x3, x2, lsl #2
    3f60:      	add	x1, x1, x2, lsl #2
    3f64:      	ldr	w2, [x3]
    3f68:      	add	w2, w2, #0x1
    3f6c:      	str	w2, [x1]
    3f70:      	add	x16, sp, #0x110
    3f74:      	ldr	x1, [x16, #0x8]
    3f78:      	add	x16, sp, #0x110
    3f7c:      	ldr	x2, [x16, #0x10]
    3f80:      	cmp	x1, x2
    3f84:      	b.lt	0x4450 <_stogir.loops.depths+0x808>
    3f88:      	cmp	x2, #0x0
    3f8c:      	b.ne	0x3e94 <_stogir.loops.depths+0x24c>
    3f90:      	mov	x2, #0x2                ; =2
    3f94:      	b	0x3e98 <_stogir.loops.depths+0x250>
    3f98:      	add	x19, x19, #0x1
    3f9c:      	ldr	x21, [sp, #0x170]
    3fa0:      	ldr	x22, [sp, #0x178]
    3fa4:      	add	x16, sp, #0x110
    3fa8:      	ldr	x0, [x16, #0x8]
    3fac:      	cmp	x19, x0
    3fb0:      	b.ge	0x4464 <_stogir.loops.depths+0x81c>
    3fb4:      	add	x16, sp, #0x110
    3fb8:      	ldr	x0, [x16]
    3fbc:      	add	x0, x0, x19, lsl #2
    3fc0:      	ldr	w0, [x0]
    3fc4:      	sxtw	x0, w0
    3fc8:      	ldr	x1, [x22]
    3fcc:      	add	x0, x1, x0, lsl #4
    3fd0:      	ldr	x24, [x0]
    3fd4:      	ldr	x25, [x0, #0x8]
    3fd8:      	movz	x28, #0x0, lsl #48
    3fdc:      	b	0x3eec <_stogir.loops.depths+0x2a4>
    3fe0:      	ldr	x21, [sp, #0x170]
    3fe4:      	ldr	x22, [sp, #0x178]
    3fe8:      	ldr	x24, [sp, #0x160]
    3fec:      	ldr	x19, [sp, #0x158]
    3ff0:      	ldr	x25, [sp, #0x168]
    3ff4:      	cmp	x25, x24
    3ff8:      	b.ge	0x401c <_stogir.loops.depths+0x3d4>
    3ffc:      	add	x0, x25, #0x1
    4000:      	add	x1, x19, x25, lsl #2
    4004:      	ldr	w1, [x1]
    4008:      	movn	w17, #0x0, lsl #16
    400c:      	and	w1, w1, w17
    4010:      	mov	x25, x0
    4014:      	mov	w0, #0x1                ; =1
    4018:      	b	0x4024 <_stogir.loops.depths+0x3dc>
    401c:      	movz	w0, #0x0, lsl #16
    4020:      	movz	w1, #0x0, lsl #16
    4024:      	ubfx	x0, x0, #0, #32
    4028:      	lsr	x16, x0, #0
    402c:      	cmp	x16, #0x1
    4030:      	b.eq	0x404c <_stogir.loops.depths+0x404>
    4034:      	b.lo	0x403c <_stogir.loops.depths+0x3f4>
    4038:      	b	0x4050 <_stogir.loops.depths+0x408>
    403c:      	cmp	x16, #0x0
    4040:      	b.eq	0x4048 <_stogir.loops.depths+0x400>
    4044:      	b	0x4050 <_stogir.loops.depths+0x408>
    4048:      	b	0x4054 <_stogir.loops.depths+0x40c>
    404c:      	b	0x41ec <_stogir.loops.depths+0x5a4>
    4050:      	b	0x43e0 <_stogir.loops.depths+0x798>
    4054:      	add	x0, sp, #0x10
    4058:      	bl	0x4058 <_stogir.loops.depths+0x410>
		0000000000004058:  ARM64_RELOC_BRANCH26	_stogir.dominators.release-index!
    405c:      	b	0x406c <_stogir.loops.depths+0x424>
    4060:      	sub	x0, x0, #0x1
    4064:      	add	x16, sp, #0xe0
    4068:      	str	x0, [x16, #0x8]
    406c:      	add	x16, sp, #0xe0
    4070:      	ldr	x0, [x16, #0x8]
    4074:      	cmp	x0, #0x0
    4078:      	b.ne	0x4060 <_stogir.loops.depths+0x418>
    407c:      	add	x16, sp, #0xe0
    4080:      	orr	x0, x16, xzr
    4084:      	add	x16, sp, #0xe0
    4088:      	ldr	x1, [x16, #0x10]
    408c:      	cmp	x1, #0x0
    4090:      	b.le	0x40c0 <_stogir.loops.depths+0x478>
    4094:      	add	x0, x0, #0x18
    4098:      	add	x16, sp, #0xe0
    409c:      	ldr	x2, [x16]
    40a0:      	fmov	d31, x1
    40a4:      	mov	x1, x2
    40a8:      	fmov	x2, d31
    40ac:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3b8>
		00000000000040ac:  ARM64_RELOC_PAGE21	l_stogir.416
    40b0:      	ldr	x3, [x3]
		00000000000040b0:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    40b4:      	mov	x4, #0x4                ; =4
    40b8:      	mov	x5, #0x4                ; =4
    40bc:      	bl	0x40bc <_stogir.loops.depths+0x474>
		00000000000040bc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    40c0:      	add	x16, sp, #0xe0
    40c4:      	movz	x17, #0x0, lsl #48
    40c8:      	str	x17, [x16]
    40cc:      	add	x16, sp, #0xe0
    40d0:      	movz	x17, #0x0, lsl #48
    40d4:      	str	x17, [x16, #0x8]
    40d8:      	add	x16, sp, #0xe0
    40dc:      	movz	x17, #0x0, lsl #48
    40e0:      	str	x17, [x16, #0x10]
    40e4:      	b	0x40f4 <_stogir.loops.depths+0x4ac>
    40e8:      	sub	x0, x0, #0x1
    40ec:      	add	x16, sp, #0x110
    40f0:      	str	x0, [x16, #0x8]
    40f4:      	add	x16, sp, #0x110
    40f8:      	ldr	x0, [x16, #0x8]
    40fc:      	cmp	x0, #0x0
    4100:      	b.ne	0x40e8 <_stogir.loops.depths+0x4a0>
    4104:      	add	x16, sp, #0x110
    4108:      	orr	x0, x16, xzr
    410c:      	add	x16, sp, #0x110
    4110:      	ldr	x1, [x16, #0x10]
    4114:      	cmp	x1, #0x0
    4118:      	b.le	0x4148 <_stogir.loops.depths+0x500>
    411c:      	add	x0, x0, #0x18
    4120:      	add	x16, sp, #0x110
    4124:      	ldr	x2, [x16]
    4128:      	fmov	d31, x1
    412c:      	mov	x1, x2
    4130:      	fmov	x2, d31
    4134:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3b8>
		0000000000004134:  ARM64_RELOC_PAGE21	l_stogir.416
    4138:      	ldr	x3, [x3]
		0000000000004138:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    413c:      	mov	x4, #0x4                ; =4
    4140:      	mov	x5, #0x4                ; =4
    4144:      	bl	0x4144 <_stogir.loops.depths+0x4fc>
		0000000000004144:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4148:      	add	x16, sp, #0x110
    414c:      	movz	x17, #0x0, lsl #48
    4150:      	str	x17, [x16]
    4154:      	add	x16, sp, #0x110
    4158:      	movz	x17, #0x0, lsl #48
    415c:      	str	x17, [x16, #0x8]
    4160:      	add	x16, sp, #0x110
    4164:      	movz	x17, #0x0, lsl #48
    4168:      	str	x17, [x16, #0x10]
    416c:      	add	x16, sp, #0xb0
    4170:      	ldr	x0, [x16]
    4174:      	add	x16, sp, #0xb0
    4178:      	ldr	x1, [x16, #0x8]
    417c:      	add	x16, sp, #0xb0
    4180:      	ldr	x2, [x16, #0x10]
    4184:      	add	x16, sp, #0xb0
    4188:      	ldr	x3, [x16, #0x18]
    418c:      	add	x16, sp, #0xb0
    4190:      	ldr	x4, [x16, #0x20]
    4194:      	str	x0, [x20]
    4198:      	str	x1, [x20, #0x8]
    419c:      	str	x2, [x20, #0x10]
    41a0:      	str	x3, [x20, #0x18]
    41a4:      	str	x4, [x20, #0x20]
    41a8:      	ldr	x19, [sp, #0x180]
    41ac:      	ldr	x20, [sp, #0x188]
    41b0:      	ldr	x21, [sp, #0x190]
    41b4:      	ldr	x22, [sp, #0x198]
    41b8:      	ldr	x23, [sp, #0x1a0]
    41bc:      	ldr	x24, [sp, #0x1a8]
    41c0:      	ldr	x25, [sp, #0x1b0]
    41c4:      	ldr	x26, [sp, #0x1b8]
    41c8:      	ldr	x27, [sp, #0x1c0]
    41cc:      	ldr	x28, [sp, #0x1c8]
    41d0:      	ldr	x29, [sp]
    41d4:      	ldr	x30, [sp, #0x8]
    41d8:      	add	sp, sp, #0x1d0
    41dc:      	ret
    41e0:      	sub	x0, x0, #0x1
    41e4:      	add	x16, sp, #0x110
    41e8:      	str	x0, [x16, #0x8]
    41ec:      	add	x16, sp, #0x110
    41f0:      	ldr	x0, [x16, #0x8]
    41f4:      	cmp	x0, #0x0
    41f8:      	b.ne	0x41e0 <_stogir.loops.depths+0x598>
    41fc:      	sxtw	x26, w1
    4200:      	orr	w27, w1, wzr
    4204:      	lsl	x28, x26, #2
    4208:      	cmp	x26, #0x0
    420c:      	cset	w0, gt
    4210:      	add	x16, sp, #0xe0
    4214:      	ldr	x1, [x16]
    4218:      	add	x1, x1, x26, lsl #2
    421c:      	str	w27, [x1]
    4220:      	ldr	x1, [x22]
    4224:      	add	x1, x1, x26, lsl #4
    4228:      	ldr	x2, [x1]
    422c:      	ldr	x1, [x1, #0x8]
    4230:      	movz	x3, #0x0, lsl #48
    4234:      	movz	x4, #0x0, lsl #48
    4238:      	b	0x42b0 <_stogir.loops.depths+0x668>
    423c:      	lsl	x6, x6, #1
    4240:      	str	w0, [sp, #0x140]
    4244:      	add	x0, sp, #0x110
    4248:      	str	x2, [sp, #0x148]
    424c:      	str	x1, [sp, #0x150]
    4250:      	mov	x1, x6
    4254:      	str	x19, [sp, #0x158]
    4258:      	mov	x19, x3
    425c:      	str	x24, [sp, #0x160]
    4260:      	mov	w24, w5
    4264:      	str	x25, [sp, #0x168]
    4268:      	mov	x25, x4
    426c:      	bl	0x426c <_stogir.loops.depths+0x624>
		000000000000426c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4270:      	add	x0, x25, #0x1
    4274:      	add	x16, sp, #0x110
    4278:      	ldr	x1, [x16]
    427c:      	add	x1, x1, x25, lsl #2
    4280:      	str	w24, [x1]
    4284:      	add	x16, sp, #0x110
    4288:      	str	x0, [x16, #0x8]
    428c:      	mov	x4, #0x1                ; =1
    4290:      	add	x19, x19, #0x1
    4294:      	ldr	x2, [sp, #0x148]
    4298:      	ldr	x1, [sp, #0x150]
    429c:      	ldr	w0, [sp, #0x140]
    42a0:      	ldr	x24, [sp, #0x160]
    42a4:      	ldr	x25, [sp, #0x168]
    42a8:      	mov	x3, x19
    42ac:      	ldr	x19, [sp, #0x158]
    42b0:      	cmp	x3, x1
    42b4:      	b.ge	0x4470 <_stogir.loops.depths+0x828>
    42b8:      	add	x5, x2, x3
    42bc:      	ldr	x6, [x22, #0x28]
    42c0:      	add	x5, x6, x5, lsl #3
    42c4:      	ldr	x5, [x5]
    42c8:      	ldr	x6, [x21, #0x50]
    42cc:      	add	x5, x6, x5, lsl #4
    42d0:      	ldr	x5, [x5]
    42d4:      	uxtb	w16, w0
    42d8:      	cmp	w16, wzr
    42dc:      	b.eq	0x4480 <_stogir.loops.depths+0x838>
    42e0:      	sxtw	x6, w5
    42e4:      	cmp	x6, #0x0
    42e8:      	b.le	0x44a0 <_stogir.loops.depths+0x858>
    42ec:      	add	x16, sp, #0x10
    42f0:      	ldr	x7, [x16, #0x8]
    42f4:      	cmp	x26, x7
    42f8:      	b.ge	0x44c0 <_stogir.loops.depths+0x878>
    42fc:      	cmp	x6, x7
    4300:      	b.ge	0x44e0 <_stogir.loops.depths+0x898>
    4304:      	add	x16, sp, #0x10
    4308:      	ldr	x7, [x16]
    430c:      	add	x8, x28, x7
    4310:      	ldr	w8, [x8]
    4314:      	sxtw	x8, w8
    4318:      	cmp	x8, #0x0
    431c:      	b.le	0x4500 <_stogir.loops.depths+0x8b8>
    4320:      	lsl	x9, x6, #2
    4324:      	add	x6, x7, x6, lsl #2
    4328:      	ldr	w6, [x6]
    432c:      	sxtw	x6, w6
    4330:      	cmp	x6, #0x0
    4334:      	b.le	0x4520 <_stogir.loops.depths+0x8d8>
    4338:      	cmp	x8, x6
    433c:      	b.gt	0x4540 <_stogir.loops.depths+0x8f8>
    4340:      	add	x16, sp, #0x10
    4344:      	ldr	x6, [x16, #0x28]
    4348:      	orr	x7, x6, xzr
    434c:      	add	x7, x28, x7
    4350:      	add	x6, x9, x6
    4354:      	ldr	w7, [x7]
    4358:      	sxtw	x7, w7
    435c:      	ldr	w6, [x6]
    4360:      	sxtw	x6, w6
    4364:      	cmp	x7, x6
    4368:      	b.lt	0x4560 <_stogir.loops.depths+0x918>
    436c:      	cmp	x4, #0x0
    4370:      	b.ne	0x4394 <_stogir.loops.depths+0x74c>
    4374:      	add	x16, sp, #0xb0
    4378:      	ldr	x4, [x16]
    437c:      	orr	x6, x4, xzr
    4380:      	add	x6, x28, x6
    4384:      	add	x4, x28, x4
    4388:      	ldr	w6, [x6]
    438c:      	add	w6, w6, #0x1
    4390:      	str	w6, [x4]
    4394:      	add	x16, sp, #0xe0
    4398:      	ldr	x4, [x16]
    439c:      	add	x6, x9, x4
    43a0:      	ldr	w6, [x6]
    43a4:      	sxtw	x6, w6
    43a8:      	cmp	x6, x26
    43ac:      	b.ne	0x43e8 <_stogir.loops.depths+0x7a0>
    43b0:      	str	x2, [sp, #0x148]
    43b4:      	str	x1, [sp, #0x150]
    43b8:      	str	w0, [sp, #0x140]
    43bc:      	str	x24, [sp, #0x160]
    43c0:      	str	x19, [sp, #0x158]
    43c4:      	mov	x19, x3
    43c8:      	str	x25, [sp, #0x168]
    43cc:      	b	0x428c <_stogir.loops.depths+0x644>
    43d0:      	cmp	x4, #0x0
    43d4:      	b.eq	0x4580 <_stogir.loops.depths+0x938>
    43d8:      	movz	x19, #0x0, lsl #48
    43dc:      	b	0x3fa4 <_stogir.loops.depths+0x35c>
    43e0:      	brk	#0
    43e4:      	b	0x43e0 <_stogir.loops.depths+0x798>
    43e8:      	add	x4, x9, x4
    43ec:      	str	w27, [x4]
    43f0:      	add	x16, sp, #0xb0
    43f4:      	ldr	x4, [x16]
    43f8:      	orr	x6, x4, xzr
    43fc:      	add	x6, x9, x6
    4400:      	add	x4, x9, x4
    4404:      	ldr	w6, [x6]
    4408:      	add	w6, w6, #0x1
    440c:      	str	w6, [x4]
    4410:      	add	x16, sp, #0x110
    4414:      	ldr	x4, [x16, #0x8]
    4418:      	add	x16, sp, #0x110
    441c:      	ldr	x6, [x16, #0x10]
    4420:      	cmp	x4, x6
    4424:      	b.lt	0x458c <_stogir.loops.depths+0x944>
    4428:      	cmp	x6, #0x0
    442c:      	b.ne	0x423c <_stogir.loops.depths+0x5f4>
    4430:      	mov	x6, #0x2                ; =2
    4434:      	b	0x4240 <_stogir.loops.depths+0x5f8>
    4438:      	str	x21, [sp, #0x170]
    443c:      	str	x22, [sp, #0x178]
    4440:      	b	0x3f98 <_stogir.loops.depths+0x350>
    4444:      	str	x21, [sp, #0x170]
    4448:      	str	x22, [sp, #0x178]
    444c:      	b	0x3ee0 <_stogir.loops.depths+0x298>
    4450:      	str	x21, [sp, #0x170]
    4454:      	str	x22, [sp, #0x178]
    4458:      	mov	w21, w0
    445c:      	mov	x22, x1
    4460:      	b	0x3eb4 <_stogir.loops.depths+0x26c>
    4464:      	str	x21, [sp, #0x170]
    4468:      	str	x22, [sp, #0x178]
    446c:      	b	0x3fe0 <_stogir.loops.depths+0x398>
    4470:      	str	x24, [sp, #0x160]
    4474:      	str	x19, [sp, #0x158]
    4478:      	str	x25, [sp, #0x168]
    447c:      	b	0x43d0 <_stogir.loops.depths+0x788>
    4480:      	str	x2, [sp, #0x148]
    4484:      	str	x1, [sp, #0x150]
    4488:      	str	w0, [sp, #0x140]
    448c:      	str	x24, [sp, #0x160]
    4490:      	str	x19, [sp, #0x158]
    4494:      	mov	x19, x3
    4498:      	str	x25, [sp, #0x168]
    449c:      	b	0x4290 <_stogir.loops.depths+0x648>
    44a0:      	str	x2, [sp, #0x148]
    44a4:      	str	x1, [sp, #0x150]
    44a8:      	str	w0, [sp, #0x140]
    44ac:      	str	x24, [sp, #0x160]
    44b0:      	str	x19, [sp, #0x158]
    44b4:      	mov	x19, x3
    44b8:      	str	x25, [sp, #0x168]
    44bc:      	b	0x4290 <_stogir.loops.depths+0x648>
    44c0:      	str	x2, [sp, #0x148]
    44c4:      	str	x1, [sp, #0x150]
    44c8:      	str	w0, [sp, #0x140]
    44cc:      	str	x24, [sp, #0x160]
    44d0:      	str	x19, [sp, #0x158]
    44d4:      	mov	x19, x3
    44d8:      	str	x25, [sp, #0x168]
    44dc:      	b	0x4290 <_stogir.loops.depths+0x648>
    44e0:      	str	x2, [sp, #0x148]
    44e4:      	str	x1, [sp, #0x150]
    44e8:      	str	w0, [sp, #0x140]
    44ec:      	str	x24, [sp, #0x160]
    44f0:      	str	x19, [sp, #0x158]
    44f4:      	mov	x19, x3
    44f8:      	str	x25, [sp, #0x168]
    44fc:      	b	0x4290 <_stogir.loops.depths+0x648>
    4500:      	str	x2, [sp, #0x148]
    4504:      	str	x1, [sp, #0x150]
    4508:      	str	w0, [sp, #0x140]
    450c:      	str	x24, [sp, #0x160]
    4510:      	str	x19, [sp, #0x158]
    4514:      	mov	x19, x3
    4518:      	str	x25, [sp, #0x168]
    451c:      	b	0x4290 <_stogir.loops.depths+0x648>
    4520:      	str	x2, [sp, #0x148]
    4524:      	str	x1, [sp, #0x150]
    4528:      	str	w0, [sp, #0x140]
    452c:      	str	x24, [sp, #0x160]
    4530:      	str	x19, [sp, #0x158]
    4534:      	mov	x19, x3
    4538:      	str	x25, [sp, #0x168]
    453c:      	b	0x4290 <_stogir.loops.depths+0x648>
    4540:      	str	x2, [sp, #0x148]
    4544:      	str	x1, [sp, #0x150]
    4548:      	str	w0, [sp, #0x140]
    454c:      	str	x24, [sp, #0x160]
    4550:      	str	x19, [sp, #0x158]
    4554:      	mov	x19, x3
    4558:      	str	x25, [sp, #0x168]
    455c:      	b	0x4290 <_stogir.loops.depths+0x648>
    4560:      	str	x2, [sp, #0x148]
    4564:      	str	x1, [sp, #0x150]
    4568:      	str	w0, [sp, #0x140]
    456c:      	str	x24, [sp, #0x160]
    4570:      	str	x19, [sp, #0x158]
    4574:      	mov	x19, x3
    4578:      	str	x25, [sp, #0x168]
    457c:      	b	0x4290 <_stogir.loops.depths+0x648>
    4580:      	str	x21, [sp, #0x170]
    4584:      	str	x22, [sp, #0x178]
    4588:      	b	0x3fe0 <_stogir.loops.depths+0x398>
    458c:      	str	x2, [sp, #0x148]
    4590:      	str	x1, [sp, #0x150]
    4594:      	str	w0, [sp, #0x140]
    4598:      	str	x24, [sp, #0x160]
    459c:      	mov	w24, w5
    45a0:      	str	x19, [sp, #0x158]
    45a4:      	mov	x19, x3
    45a8:      	str	x25, [sp, #0x168]
    45ac:      	mov	x25, x4
    45b0:      	b	0x4270 <_stogir.loops.depths+0x628>

00000000000045b4 <_stogir.liveness.mark>:
    45b4:      	sub	sp, sp, #0x140
    45b8:      	str	x29, [sp]
    45bc:      	str	x30, [sp, #0x8]
    45c0:      	mov	x29, sp
    45c4:      	str	x19, [sp, #0xe8]
    45c8:      	str	x20, [sp, #0xf0]
    45cc:      	str	x21, [sp, #0xf8]
    45d0:      	str	x22, [sp, #0x100]
    45d4:      	str	x23, [sp, #0x108]
    45d8:      	str	x24, [sp, #0x110]
    45dc:      	str	x25, [sp, #0x118]
    45e0:      	str	x26, [sp, #0x120]
    45e4:      	str	x27, [sp, #0x128]
    45e8:      	str	x28, [sp, #0x130]
    45ec:      	add	x19, x0, #0x78
    45f0:      	mov	x20, x8
    45f4:      	add	x8, sp, #0x40
    45f8:      	mov	x21, x0
    45fc:      	mov	x0, x3
    4600:      	mov	x22, x1
    4604:      	mov	x23, x2
    4608:      	mov	x24, x3
    460c:      	bl	0x460c <_stogir.liveness.mark+0x58>
		000000000000460c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__bool
    4610:      	add	x16, sp, #0x40
    4614:      	ldr	x0, [x16]
    4618:      	add	x16, sp, #0x10
    461c:      	str	x0, [x16]
    4620:      	add	x16, sp, #0x40
    4624:      	ldr	x0, [x16, #0x8]
    4628:      	add	x16, sp, #0x10
    462c:      	str	x0, [x16, #0x8]
    4630:      	add	x16, sp, #0x40
    4634:      	ldr	x0, [x16, #0x10]
    4638:      	add	x16, sp, #0x10
    463c:      	str	x0, [x16, #0x10]
    4640:      	add	x16, sp, #0x40
    4644:      	ldr	x0, [x16, #0x18]
    4648:      	add	x16, sp, #0x10
    464c:      	str	x0, [x16, #0x18]
    4650:      	add	x16, sp, #0x40
    4654:      	ldr	x0, [x16, #0x20]
    4658:      	add	x16, sp, #0x10
    465c:      	str	x0, [x16, #0x20]
    4660:      	add	x8, sp, #0xa0
    4664:      	mov	x0, x24
    4668:      	bl	0x4668 <_stogir.liveness.mark+0xb4>
		0000000000004668:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    466c:      	add	x16, sp, #0xa0
    4670:      	ldr	x0, [x16]
    4674:      	add	x16, sp, #0x70
    4678:      	str	x0, [x16]
    467c:      	add	x16, sp, #0xa0
    4680:      	ldr	x0, [x16, #0x8]
    4684:      	add	x16, sp, #0x70
    4688:      	str	x0, [x16, #0x8]
    468c:      	add	x16, sp, #0xa0
    4690:      	ldr	x0, [x16, #0x10]
    4694:      	add	x16, sp, #0x70
    4698:      	str	x0, [x16, #0x10]
    469c:      	add	x16, sp, #0xa0
    46a0:      	ldr	x0, [x16, #0x18]
    46a4:      	add	x16, sp, #0x70
    46a8:      	str	x0, [x16, #0x18]
    46ac:      	add	x16, sp, #0xa0
    46b0:      	ldr	x0, [x16, #0x20]
    46b4:      	add	x16, sp, #0x70
    46b8:      	str	x0, [x16, #0x20]
    46bc:      	ldr	x0, [x21, #0x8]
    46c0:      	mov	x1, x0
    46c4:      	add	x0, sp, #0x10
    46c8:      	bl	0x46c8 <_stogir.liveness.mark+0x114>
		00000000000046c8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool
    46cc:      	movz	x24, #0x0, lsl #48
    46d0:      	cmp	x24, x23
    46d4:      	b.ge	0x46f8 <_stogir.liveness.mark+0x144>
    46d8:      	add	x0, x24, #0x1
    46dc:      	add	x1, x22, x24, lsl #2
    46e0:      	ldr	w1, [x1]
    46e4:      	movn	w17, #0x0, lsl #16
    46e8:      	and	w25, w1, w17
    46ec:      	mov	x24, x0
    46f0:      	mov	w0, #0x1                ; =1
    46f4:      	b	0x4700 <_stogir.liveness.mark+0x14c>
    46f8:      	movz	w0, #0x0, lsl #16
    46fc:      	movz	w25, #0x0, lsl #16
    4700:      	ubfx	x0, x0, #0, #32
    4704:      	lsr	x16, x0, #0
    4708:      	cmp	x16, #0x1
    470c:      	b.eq	0x4728 <_stogir.liveness.mark+0x174>
    4710:      	b.lo	0x4718 <_stogir.liveness.mark+0x164>
    4714:      	b	0x472c <_stogir.liveness.mark+0x178>
    4718:      	cmp	x16, #0x0
    471c:      	b.eq	0x4724 <_stogir.liveness.mark+0x170>
    4720:      	b	0x472c <_stogir.liveness.mark+0x178>
    4724:      	b	0x47bc <_stogir.liveness.mark+0x208>
    4728:      	b	0x4730 <_stogir.liveness.mark+0x17c>
    472c:      	b	0x4b34 <_stogir.liveness.mark+0x580>
    4730:      	sxtw	x0, w25
    4734:      	cmp	x0, #0x0
    4738:      	b.le	0x46d0 <_stogir.liveness.mark+0x11c>
    473c:      	ldr	x1, [x21, #0x8]
    4740:      	cmp	x0, x1
    4744:      	b.ge	0x46d0 <_stogir.liveness.mark+0x11c>
    4748:      	ldr	x1, [x19, #0x8]
    474c:      	cmp	x0, x1
    4750:      	b.ge	0x46d0 <_stogir.liveness.mark+0x11c>
    4754:      	ldr	x1, [x21, #0x78]
    4758:      	add	x1, x1, x0, lsl #2
    475c:      	ldr	w1, [x1]
    4760:      	sxtw	x1, w1
    4764:      	cmp	x1, #0x0
    4768:      	b.lt	0x46d0 <_stogir.liveness.mark+0x11c>
    476c:      	add	x16, sp, #0x10
    4770:      	ldr	x1, [x16]
    4774:      	add	x2, x1, x0
    4778:      	ldrb	w2, [x2]
    477c:      	cmp	x2, #0x0
    4780:      	b.ne	0x46d0 <_stogir.liveness.mark+0x11c>
    4784:      	add	x0, x1, x0
    4788:      	mov	w17, #0x1               ; =1
    478c:      	strb	w17, [x0]
    4790:      	add	x16, sp, #0x70
    4794:      	ldr	x0, [x16, #0x8]
    4798:      	orr	x26, x0, xzr
    479c:      	add	x16, sp, #0x70
    47a0:      	ldr	x0, [x16, #0x10]
    47a4:      	cmp	x26, x0
    47a8:      	b.lt	0x4b14 <_stogir.liveness.mark+0x560>
    47ac:      	cmp	x0, #0x0
    47b0:      	b.ne	0x4b04 <_stogir.liveness.mark+0x550>
    47b4:      	mov	x0, #0x2                ; =2
    47b8:      	b	0x4b08 <_stogir.liveness.mark+0x554>
    47bc:      	movz	x22, #0x0, lsl #48
    47c0:      	b	0x49e0 <_stogir.liveness.mark+0x42c>
    47c4:      	movz	w2, #0x0, lsl #16
    47c8:      	movz	w1, #0x0, lsl #16
    47cc:      	b	0x495c <_stogir.liveness.mark+0x3a8>
    47d0:      	sub	w1, w1, #0x1
    47d4:      	lsl	w1, w1, #2
    47d8:      	ubfx	x1, x1, #0, #32
    47dc:      	lsr	x1, x3, x1
    47e0:      	and	w1, w1, #0xf
    47e4:      	b	0x4880 <_stogir.liveness.mark+0x2cc>
    47e8:      	lsl	x3, x3, #1
    47ec:      	str	x19, [sp, #0xd0]
    47f0:      	mov	x19, x0
    47f4:      	add	x0, sp, #0x70
    47f8:      	str	x21, [sp, #0xd8]
    47fc:      	mov	w21, w1
    4800:      	mov	x1, x3
    4804:      	str	x23, [sp, #0xe0]
    4808:      	mov	x23, x2
    480c:      	bl	0x480c <_stogir.liveness.mark+0x258>
		000000000000480c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4810:      	add	x0, x23, #0x1
    4814:      	add	x16, sp, #0x70
    4818:      	ldr	x1, [x16]
    481c:      	add	x1, x1, x23, lsl #2
    4820:      	str	w21, [x1]
    4824:      	add	x16, sp, #0x70
    4828:      	str	x0, [x16, #0x8]
    482c:      	add	x0, x19, #0x1
    4830:      	sxtw	x19, w0
    4834:      	ldr	x21, [sp, #0xd8]
    4838:      	ldr	x23, [sp, #0xe0]
    483c:      	mov	x0, x19
    4840:      	ldr	x19, [sp, #0xd0]
    4844:      	cmp	x0, x28
    4848:      	b.gt	0x4b3c <_stogir.liveness.mark+0x588>
    484c:      	orr	w1, w0, wzr
    4850:      	sxtw	x2, w1
    4854:      	uxtb	w16, w26
    4858:      	cmp	w16, wzr
    485c:      	b.eq	0x4884 <_stogir.liveness.mark+0x2d0>
    4860:      	ldr	w3, [x27]
    4864:      	cmp	x2, #0x0
    4868:      	b.le	0x487c <_stogir.liveness.mark+0x2c8>
    486c:      	cmp	x2, #0x4
    4870:      	b.le	0x47d0 <_stogir.liveness.mark+0x21c>
    4874:      	mov	w1, #0x4                ; =4
    4878:      	b	0x47d4 <_stogir.liveness.mark+0x220>
    487c:      	movz	w1, #0x0, lsl #16
    4880:      	b	0x4888 <_stogir.liveness.mark+0x2d4>
    4884:      	movz	w1, #0x0, lsl #16
    4888:      	ubfx	x1, x1, #0, #32
    488c:      	cmp	x1, #0xf
    4890:      	b.hs	0x4b48 <_stogir.liveness.mark+0x594>
    4894:      	mov	x16, #0x1               ; =1
    4898:      	lsl	x1, x16, x1
    489c:      	mov	w17, #0x5e1c            ; =24092
    48a0:      	and	w1, w1, w17
    48a4:      	ubfx	x1, x1, #0, #32
    48a8:      	cmp	x1, #0x0
    48ac:      	b.eq	0x4b5c <_stogir.liveness.mark+0x5a8>
    48b0:      	uxtb	w16, w25
    48b4:      	cmp	w16, wzr
    48b8:      	b.ne	0x4954 <_stogir.liveness.mark+0x3a0>
    48bc:      	ldr	x1, [x21, #0x8]
    48c0:      	cmp	x23, x1
    48c4:      	b.ge	0x4954 <_stogir.liveness.mark+0x3a0>
    48c8:      	ldr	x1, [x19, #0x8]
    48cc:      	cmp	x23, x1
    48d0:      	b.ge	0x4954 <_stogir.liveness.mark+0x3a0>
    48d4:      	ldr	x1, [x21, #0x78]
    48d8:      	add	x1, x24, x1
    48dc:      	ldr	w1, [x1]
    48e0:      	sxtw	x1, w1
    48e4:      	cmp	x1, #0x0
    48e8:      	b.lt	0x4954 <_stogir.liveness.mark+0x3a0>
    48ec:      	cmp	x2, #0x1
    48f0:      	b.lt	0x47c4 <_stogir.liveness.mark+0x210>
    48f4:      	ldr	x1, [x21, #0x78]
    48f8:      	add	x1, x24, x1
    48fc:      	ldr	w1, [x1]
    4900:      	sxtw	x1, w1
    4904:      	cmp	x2, x1
    4908:      	b.gt	0x47c4 <_stogir.liveness.mark+0x210>
    490c:      	ldr	x1, [x21]
    4910:      	asr	x16, x2, #63
    4914:      	lsr	x16, x16, #62
    4918:      	add	x3, x2, x16
    491c:      	asr	x3, x3, #2
    4920:      	asr	x16, x2, #63
    4924:      	lsr	x16, x16, #62
    4928:      	add	x2, x2, x16
    492c:      	and	x2, x2, #0x3
    4930:      	sub	x2, x2, x16
    4934:      	add	x3, x3, x23
    4938:      	add	x1, x1, x3, lsl #4
    493c:      	add	x1, x1, x2, lsl #2
    4940:      	ldr	w1, [x1]
    4944:      	movn	w17, #0x0, lsl #16
    4948:      	and	w1, w1, w17
    494c:      	mov	w2, #0x1                ; =1
    4950:      	b	0x47cc <_stogir.liveness.mark+0x218>
    4954:      	movz	w2, #0x0, lsl #16
    4958:      	movz	w1, #0x0, lsl #16
    495c:      	ubfx	x2, x2, #0, #32
    4960:      	lsr	x16, x2, #0
    4964:      	cmp	x16, #0x1
    4968:      	b.eq	0x4994 <_stogir.liveness.mark+0x3e0>
    496c:      	b.lo	0x4974 <_stogir.liveness.mark+0x3c0>
    4970:      	b	0x4998 <_stogir.liveness.mark+0x3e4>
    4974:      	cmp	x16, #0x0
    4978:      	b.eq	0x4980 <_stogir.liveness.mark+0x3cc>
    497c:      	b	0x4998 <_stogir.liveness.mark+0x3e4>
    4980:      	str	x21, [sp, #0xd8]
    4984:      	str	x23, [sp, #0xe0]
    4988:      	str	x19, [sp, #0xd0]
    498c:      	mov	x19, x0
    4990:      	b	0x482c <_stogir.liveness.mark+0x278>
    4994:      	b	0x499c <_stogir.liveness.mark+0x3e8>
    4998:      	b	0x4afc <_stogir.liveness.mark+0x548>
    499c:      	sxtw	x2, w1
    49a0:      	cmp	x2, #0x0
    49a4:      	b.le	0x4b70 <_stogir.liveness.mark+0x5bc>
    49a8:      	add	x16, sp, #0x10
    49ac:      	ldr	x3, [x16]
    49b0:      	add	x2, x2, x3
    49b4:      	ldrb	w3, [x2]
    49b8:      	cmp	x3, #0x0
    49bc:      	b.eq	0x4a50 <_stogir.liveness.mark+0x49c>
    49c0:      	str	x21, [sp, #0xd8]
    49c4:      	str	x23, [sp, #0xe0]
    49c8:      	str	x19, [sp, #0xd0]
    49cc:      	mov	x19, x0
    49d0:      	b	0x482c <_stogir.liveness.mark+0x278>
    49d4:      	add	x22, x22, #0x1
    49d8:      	ldr	x21, [sp, #0xd8]
    49dc:      	ldr	x19, [sp, #0xd0]
    49e0:      	add	x16, sp, #0x70
    49e4:      	ldr	x0, [x16, #0x8]
    49e8:      	cmp	x22, x0
    49ec:      	b.ge	0x4a80 <_stogir.liveness.mark+0x4cc>
    49f0:      	add	x16, sp, #0x70
    49f4:      	ldr	x0, [x16]
    49f8:      	add	x0, x0, x22, lsl #2
    49fc:      	ldr	w0, [x0]
    4a00:      	sxtw	x23, w0
    4a04:      	ldr	x0, [x21]
    4a08:      	lsl	x24, x23, #2
    4a0c:      	cmp	x23, #0x0
    4a10:      	cset	w25, le
    4a14:      	add	x0, x0, x23, lsl #4
    4a18:      	ldr	x0, [x0]
    4a1c:      	ldr	x1, [x21, #0x78]
    4a20:      	uxtb	w0, w0
    4a24:      	add	x1, x1, x23, lsl #2
    4a28:      	cmp	x0, #0x83
    4a2c:      	cset	w26, lt
    4a30:      	adrp	x16, 0x4000 <_stogir.loops.depths+0x3b8>
		0000000000004a30:  ARM64_RELOC_PAGE21	l_stogir.417
    4a34:      	ldr	x16, [x16]
		0000000000004a34:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    4a38:      	add	x0, x16, x0, lsl #2
    4a3c:      	ldr	w1, [x1]
    4a40:      	orr	x27, x0, xzr
    4a44:      	sxtw	x28, w1
    4a48:      	mov	x0, #0x1                ; =1
    4a4c:      	b	0x4844 <_stogir.liveness.mark+0x290>
    4a50:      	mov	w17, #0x1               ; =1
    4a54:      	strb	w17, [x2]
    4a58:      	add	x16, sp, #0x70
    4a5c:      	ldr	x2, [x16, #0x8]
    4a60:      	add	x16, sp, #0x70
    4a64:      	ldr	x3, [x16, #0x10]
    4a68:      	cmp	x2, x3
    4a6c:      	b.lt	0x4b84 <_stogir.liveness.mark+0x5d0>
    4a70:      	cmp	x3, #0x0
    4a74:      	b.ne	0x47e8 <_stogir.liveness.mark+0x234>
    4a78:      	mov	x3, #0x2                ; =2
    4a7c:      	b	0x47ec <_stogir.liveness.mark+0x238>
    4a80:      	add	x0, sp, #0x70
    4a84:      	bl	0x4a84 <_stogir.liveness.mark+0x4d0>
		0000000000004a84:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    4a88:      	add	x16, sp, #0x10
    4a8c:      	ldr	x0, [x16]
    4a90:      	add	x16, sp, #0x10
    4a94:      	ldr	x1, [x16, #0x8]
    4a98:      	add	x16, sp, #0x10
    4a9c:      	ldr	x2, [x16, #0x10]
    4aa0:      	add	x16, sp, #0x10
    4aa4:      	ldr	x3, [x16, #0x18]
    4aa8:      	add	x16, sp, #0x10
    4aac:      	ldr	x4, [x16, #0x20]
    4ab0:      	str	x0, [x20]
    4ab4:      	str	x1, [x20, #0x8]
    4ab8:      	str	x2, [x20, #0x10]
    4abc:      	str	x3, [x20, #0x18]
    4ac0:      	str	x4, [x20, #0x20]
    4ac4:      	ldr	x19, [sp, #0xe8]
    4ac8:      	ldr	x20, [sp, #0xf0]
    4acc:      	ldr	x21, [sp, #0xf8]
    4ad0:      	ldr	x22, [sp, #0x100]
    4ad4:      	ldr	x23, [sp, #0x108]
    4ad8:      	ldr	x24, [sp, #0x110]
    4adc:      	ldr	x25, [sp, #0x118]
    4ae0:      	ldr	x26, [sp, #0x120]
    4ae4:      	ldr	x27, [sp, #0x128]
    4ae8:      	ldr	x28, [sp, #0x130]
    4aec:      	ldr	x29, [sp]
    4af0:      	ldr	x30, [sp, #0x8]
    4af4:      	add	sp, sp, #0x140
    4af8:      	ret
    4afc:      	brk	#0
    4b00:      	b	0x4afc <_stogir.liveness.mark+0x548>
    4b04:      	lsl	x0, x0, #1
    4b08:      	mov	x1, x0
    4b0c:      	add	x0, sp, #0x70
    4b10:      	bl	0x4b10 <_stogir.liveness.mark+0x55c>
		0000000000004b10:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    4b14:      	add	x0, x26, #0x1
    4b18:      	add	x16, sp, #0x70
    4b1c:      	ldr	x1, [x16]
    4b20:      	add	x1, x1, x26, lsl #2
    4b24:      	str	w25, [x1]
    4b28:      	add	x16, sp, #0x70
    4b2c:      	str	x0, [x16, #0x8]
    4b30:      	b	0x46d0 <_stogir.liveness.mark+0x11c>
    4b34:      	brk	#0
    4b38:      	b	0x4b34 <_stogir.liveness.mark+0x580>
    4b3c:      	str	x21, [sp, #0xd8]
    4b40:      	str	x19, [sp, #0xd0]
    4b44:      	b	0x49d4 <_stogir.liveness.mark+0x420>
    4b48:      	str	x21, [sp, #0xd8]
    4b4c:      	str	x23, [sp, #0xe0]
    4b50:      	str	x19, [sp, #0xd0]
    4b54:      	mov	x19, x0
    4b58:      	b	0x482c <_stogir.liveness.mark+0x278>
    4b5c:      	str	x21, [sp, #0xd8]
    4b60:      	str	x23, [sp, #0xe0]
    4b64:      	str	x19, [sp, #0xd0]
    4b68:      	mov	x19, x0
    4b6c:      	b	0x482c <_stogir.liveness.mark+0x278>
    4b70:      	str	x21, [sp, #0xd8]
    4b74:      	str	x23, [sp, #0xe0]
    4b78:      	str	x19, [sp, #0xd0]
    4b7c:      	mov	x19, x0
    4b80:      	b	0x482c <_stogir.liveness.mark+0x278>
    4b84:      	str	x21, [sp, #0xd8]
    4b88:      	str	x23, [sp, #0xe0]
    4b8c:      	str	x19, [sp, #0xd0]
    4b90:      	mov	x19, x0
    4b94:      	mov	x23, x2
    4b98:      	mov	w21, w1
    4b9c:      	b	0x4810 <_stogir.liveness.mark+0x25c>

0000000000004ba0 <_stogir.uses.build>:
    4ba0:      	sub	sp, sp, #0xc0
    4ba4:      	str	x29, [sp]
    4ba8:      	str	x30, [sp, #0x8]
    4bac:      	mov	x29, sp
    4bb0:      	str	x19, [sp, #0x90]
    4bb4:      	str	x20, [sp, #0x98]
    4bb8:      	str	x21, [sp, #0xa0]
    4bbc:      	str	x22, [sp, #0xa8]
    4bc0:      	str	x23, [sp, #0xb0]
    4bc4:      	str	x24, [sp, #0xb8]
    4bc8:      	ldr	x2, [x1]
    4bcc:      	ldr	x1, [x1, #0x8]
    4bd0:      	add	x16, sp, #0x10
    4bd4:      	movz	x17, #0x0, lsl #48
    4bd8:      	str	x17, [x16]
    4bdc:      	add	x16, sp, #0x10
    4be0:      	movz	x17, #0x0, lsl #48
    4be4:      	str	x17, [x16, #0x8]
    4be8:      	add	x16, sp, #0x10
    4bec:      	movz	x17, #0x0, lsl #48
    4bf0:      	str	x17, [x16, #0x10]
    4bf4:      	add	x16, sp, #0x10
    4bf8:      	str	x2, [x16, #0x18]
    4bfc:      	add	x16, sp, #0x10
    4c00:      	str	x1, [x16, #0x20]
    4c04:      	add	x16, sp, #0x10
    4c08:      	movz	x17, #0x0, lsl #48
    4c0c:      	str	x17, [x16, #0x28]
    4c10:      	add	x16, sp, #0x10
    4c14:      	movz	x17, #0x0, lsl #48
    4c18:      	str	x17, [x16, #0x30]
    4c1c:      	add	x16, sp, #0x10
    4c20:      	movz	x17, #0x0, lsl #48
    4c24:      	str	x17, [x16, #0x38]
    4c28:      	add	x16, sp, #0x10
    4c2c:      	str	x2, [x16, #0x40]
    4c30:      	add	x16, sp, #0x10
    4c34:      	str	x1, [x16, #0x48]
    4c38:      	add	x16, sp, #0x60
    4c3c:      	movz	x17, #0x0, lsl #48
    4c40:      	str	x17, [x16]
    4c44:      	add	x16, sp, #0x60
    4c48:      	movz	x17, #0x0, lsl #48
    4c4c:      	str	x17, [x16, #0x8]
    4c50:      	add	x16, sp, #0x60
    4c54:      	movz	x17, #0x0, lsl #48
    4c58:      	str	x17, [x16, #0x10]
    4c5c:      	add	x16, sp, #0x60
    4c60:      	str	x2, [x16, #0x18]
    4c64:      	add	x16, sp, #0x60
    4c68:      	str	x1, [x16, #0x20]
    4c6c:      	ldr	x1, [x0, #0x8]
    4c70:      	orr	x19, x1, xzr
    4c74:      	cmp	x19, #0x0
    4c78:      	b.le	0x5094 <_stogir.uses.build+0x4f4>
    4c7c:      	cmp	x19, #0x0
    4c80:      	b.ge	0x4c8c <_stogir.uses.build+0xec>
    4c84:      	movz	x1, #0x0, lsl #48
    4c88:      	b	0x4c90 <_stogir.uses.build+0xf0>
    4c8c:      	mov	x1, x19
    4c90:      	mov	x20, x8
    4c94:      	mov	x21, x0
    4c98:      	add	x0, sp, #0x10
    4c9c:      	bl	0x4c9c <_stogir.uses.build+0xfc>
		0000000000004c9c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range
    4ca0:      	lsl	x0, x19, #4
    4ca4:      	add	x16, sp, #0x10
    4ca8:      	ldr	x1, [x16]
    4cac:      	mov	x2, x0
    4cb0:      	mov	x0, x1
    4cb4:      	movz	x1, #0x0, lsl #48
    4cb8:      	bl	0x4cb8 <_stogir.uses.build+0x118>
		0000000000004cb8:  ARM64_RELOC_BRANCH26	_memset
    4cbc:      	add	x16, sp, #0x10
    4cc0:      	str	x19, [x16, #0x8]
    4cc4:      	ldr	x0, [x21, #0x8]
    4cc8:      	orr	x19, x0, xzr
    4ccc:      	add	x16, sp, #0x60
    4cd0:      	ldr	x0, [x16, #0x8]
    4cd4:      	orr	x22, x0, xzr
    4cd8:      	add	x16, sp, #0x60
    4cdc:      	ldr	x0, [x16, #0x10]
    4ce0:      	add	x23, x22, x19
    4ce4:      	cmp	x23, x0
    4ce8:      	b.le	0x4d1c <_stogir.uses.build+0x17c>
    4cec:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    4cf0:      	cmp	x0, x17
    4cf4:      	b.gt	0x4d00 <_stogir.uses.build+0x160>
    4cf8:      	lsl	x0, x0, #1
    4cfc:      	b	0x4d04 <_stogir.uses.build+0x164>
    4d00:      	mov	x0, x23
    4d04:      	cmp	x0, x23
    4d08:      	b.gt	0x4d10 <_stogir.uses.build+0x170>
    4d0c:      	mov	x0, x23
    4d10:      	mov	x1, x0
    4d14:      	add	x0, sp, #0x60
    4d18:      	bl	0x4d18 <_stogir.uses.build+0x178>
		0000000000004d18:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    4d1c:      	lsl	x0, x19, #3
    4d20:      	add	x16, sp, #0x60
    4d24:      	ldr	x1, [x16]
    4d28:      	add	x1, x1, x22, lsl #3
    4d2c:      	mov	x2, x0
    4d30:      	mov	x0, x1
    4d34:      	movz	x1, #0x0, lsl #48
    4d38:      	bl	0x4d38 <_stogir.uses.build+0x198>
		0000000000004d38:  ARM64_RELOC_BRANCH26	_memset
    4d3c:      	add	x16, sp, #0x60
    4d40:      	str	x23, [x16, #0x8]
    4d44:      	mov	x0, #0x1                ; =1
    4d48:      	b	0x4e48 <_stogir.uses.build+0x2a8>
    4d4c:      	sub	w4, w4, #0x1
    4d50:      	lsl	w4, w4, #2
    4d54:      	ubfx	x4, x4, #0, #32
    4d58:      	lsr	x4, x1, x4
    4d5c:      	and	w4, w4, #0xf
    4d60:      	b	0x4d6c <_stogir.uses.build+0x1cc>
    4d64:      	nop
    4d68:      	movz	w4, #0x0, lsl #16
    4d6c:      	ubfx	x4, x4, #0, #32
    4d70:      	cmp	x4, #0xf
    4d74:      	b.hs	0x4e00 <_stogir.uses.build+0x260>
    4d78:      	mov	x16, #0x1               ; =1
    4d7c:      	lsl	x4, x16, x4
    4d80:      	mov	w17, #0x5e1c            ; =24092
    4d84:      	and	w4, w4, w17
    4d88:      	ubfx	x4, x4, #0, #32
    4d8c:      	cmp	x4, #0x0
    4d90:      	b.eq	0x4e00 <_stogir.uses.build+0x260>
    4d94:      	ldr	x4, [x21]
    4d98:      	asr	x16, x5, #63
    4d9c:      	lsr	x16, x16, #62
    4da0:      	add	x6, x5, x16
    4da4:      	asr	x6, x6, #2
    4da8:      	asr	x16, x5, #63
    4dac:      	lsr	x16, x16, #62
    4db0:      	add	x5, x5, x16
    4db4:      	and	x5, x5, #0x3
    4db8:      	sub	x5, x5, x16
    4dbc:      	add	x6, x6, x0
    4dc0:      	add	x4, x4, x6, lsl #4
    4dc4:      	add	x4, x4, x5, lsl #2
    4dc8:      	ldr	w4, [x4]
    4dcc:      	sxtw	x4, w4
    4dd0:      	cmp	x4, #0x0
    4dd4:      	b.le	0x4e00 <_stogir.uses.build+0x260>
    4dd8:      	add	x16, sp, #0x10
    4ddc:      	ldr	x5, [x16]
    4de0:      	orr	x6, x5, xzr
    4de4:      	add	x6, x6, x4, lsl #4
    4de8:      	add	x4, x5, x4, lsl #4
    4dec:      	ldr	x5, [x6]
    4df0:      	ldr	x6, [x6, #0x8]
    4df4:      	add	x6, x6, #0x1
    4df8:      	str	x5, [x4]
    4dfc:      	str	x6, [x4, #0x8]
    4e00:      	add	x3, x3, #0x1
    4e04:      	sxtw	x3, w3
    4e08:      	cmp	x3, x2
    4e0c:      	b.gt	0x4e30 <_stogir.uses.build+0x290>
    4e10:      	orr	w4, w3, wzr
    4e14:      	sxtw	x5, w4
    4e18:      	cmp	x5, #0x0
    4e1c:      	b.le	0x4d68 <_stogir.uses.build+0x1c8>
    4e20:      	cmp	x5, #0x4
    4e24:      	b.le	0x4d4c <_stogir.uses.build+0x1ac>
    4e28:      	mov	w4, #0x4                ; =4
    4e2c:      	b	0x4d50 <_stogir.uses.build+0x1b0>
    4e30:      	add	x1, x2, #0x4
    4e34:      	asr	x16, x1, #63
    4e38:      	lsr	x16, x16, #62
    4e3c:      	add	x1, x1, x16
    4e40:      	asr	x1, x1, #2
    4e44:      	add	x0, x1, x0
    4e48:      	ldr	x1, [x21, #0x8]
    4e4c:      	cmp	x0, x1
    4e50:      	b.ge	0x4e8c <_stogir.uses.build+0x2ec>
    4e54:      	ldr	x1, [x21]
    4e58:      	add	x1, x1, x0, lsl #4
    4e5c:      	ldr	x1, [x1]
    4e60:      	ldr	x2, [x21, #0x78]
    4e64:      	uxtb	w1, w1
    4e68:      	add	x2, x2, x0, lsl #2
    4e6c:      	adrp	x16, 0x4000 <_stogir.loops.depths+0x3b8>
		0000000000004e6c:  ARM64_RELOC_PAGE21	l_stogir.418
    4e70:      	ldr	x16, [x16]
		0000000000004e70:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    4e74:      	add	x1, x16, x1, lsl #2
    4e78:      	ldr	w2, [x2]
    4e7c:      	sxtw	x2, w2
    4e80:      	ldr	w1, [x1]
    4e84:      	mov	x3, #0x1                ; =1
    4e88:      	b	0x4e08 <_stogir.uses.build+0x268>
    4e8c:      	movn	x0, #0x0, lsl #48
    4e90:      	movz	x19, #0x0, lsl #48
    4e94:      	b	0x4ed0 <_stogir.uses.build+0x330>
    4e98:      	add	x16, sp, #0x10
    4e9c:      	ldr	x1, [x16]
    4ea0:      	orr	x2, x1, xzr
    4ea4:      	add	x2, x2, x0, lsl #4
    4ea8:      	add	x1, x1, x0, lsl #4
    4eac:      	ldr	x2, [x2, #0x8]
    4eb0:      	add	x3, x2, x19
    4eb4:      	str	x19, [x1]
    4eb8:      	str	x2, [x1, #0x8]
    4ebc:      	add	x16, sp, #0x60
    4ec0:      	ldr	x1, [x16]
    4ec4:      	add	x1, x1, x0, lsl #3
    4ec8:      	str	x19, [x1]
    4ecc:      	mov	x19, x3
    4ed0:      	add	x16, sp, #0x10
    4ed4:      	ldr	x1, [x16, #0x8]
    4ed8:      	add	x0, x0, #0x1
    4edc:      	cmp	x0, x1
    4ee0:      	b.lt	0x4e98 <_stogir.uses.build+0x2f8>
    4ee4:      	add	x16, sp, #0x10
    4ee8:      	orr	x0, x16, xzr
    4eec:      	add	x22, x0, #0x28
    4ef0:      	ldr	x0, [x22, #0x8]
    4ef4:      	orr	x23, x0, xzr
    4ef8:      	ldr	x0, [x22, #0x10]
    4efc:      	add	x24, x23, x19
    4f00:      	cmp	x24, x0
    4f04:      	b.le	0x4f38 <_stogir.uses.build+0x398>
    4f08:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    4f0c:      	cmp	x0, x17
    4f10:      	b.gt	0x4f1c <_stogir.uses.build+0x37c>
    4f14:      	lsl	x0, x0, #1
    4f18:      	b	0x4f20 <_stogir.uses.build+0x380>
    4f1c:      	mov	x0, x24
    4f20:      	cmp	x0, x24
    4f24:      	b.gt	0x4f2c <_stogir.uses.build+0x38c>
    4f28:      	mov	x0, x24
    4f2c:      	mov	x1, x0
    4f30:      	mov	x0, x22
    4f34:      	bl	0x4f34 <_stogir.uses.build+0x394>
		0000000000004f34:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use
    4f38:      	lsl	x0, x19, #3
    4f3c:      	add	x16, sp, #0x10
    4f40:      	ldr	x1, [x16, #0x28]
    4f44:      	add	x1, x1, x23, lsl #3
    4f48:      	mov	x2, x0
    4f4c:      	mov	x0, x1
    4f50:      	movz	x1, #0x0, lsl #48
    4f54:      	bl	0x4f54 <_stogir.uses.build+0x3b4>
		0000000000004f54:  ARM64_RELOC_BRANCH26	_memset
    4f58:      	str	x24, [x22, #0x8]
    4f5c:      	mov	x0, x21
    4f60:      	add	x1, sp, #0x10
    4f64:      	add	x2, sp, #0x60
    4f68:      	bl	0x4f68 <_stogir.uses.build+0x3c8>
		0000000000004f68:  ARM64_RELOC_BRANCH26	_stogir.uses.scan!__constfalse
    4f6c:      	b	0x4f7c <_stogir.uses.build+0x3dc>
    4f70:      	sub	x0, x0, #0x1
    4f74:      	add	x16, sp, #0x60
    4f78:      	str	x0, [x16, #0x8]
    4f7c:      	add	x16, sp, #0x60
    4f80:      	ldr	x0, [x16, #0x8]
    4f84:      	cmp	x0, #0x0
    4f88:      	b.ne	0x4f70 <_stogir.uses.build+0x3d0>
    4f8c:      	add	x16, sp, #0x60
    4f90:      	orr	x0, x16, xzr
    4f94:      	add	x16, sp, #0x60
    4f98:      	ldr	x1, [x16, #0x10]
    4f9c:      	cmp	x1, #0x0
    4fa0:      	b.le	0x4fd0 <_stogir.uses.build+0x430>
    4fa4:      	add	x0, x0, #0x18
    4fa8:      	add	x16, sp, #0x60
    4fac:      	ldr	x2, [x16]
    4fb0:      	fmov	d31, x1
    4fb4:      	mov	x1, x2
    4fb8:      	fmov	x2, d31
    4fbc:      	adrp	x3, 0x4000 <_stogir.loops.depths+0x3b8>
		0000000000004fbc:  ARM64_RELOC_PAGE21	l_stogir.419
    4fc0:      	ldr	x3, [x3]
		0000000000004fc0:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    4fc4:      	mov	x4, #0x8                ; =8
    4fc8:      	mov	x5, #0x8                ; =8
    4fcc:      	bl	0x4fcc <_stogir.uses.build+0x42c>
		0000000000004fcc:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    4fd0:      	add	x16, sp, #0x60
    4fd4:      	movz	x17, #0x0, lsl #48
    4fd8:      	str	x17, [x16]
    4fdc:      	add	x16, sp, #0x60
    4fe0:      	movz	x17, #0x0, lsl #48
    4fe4:      	str	x17, [x16, #0x8]
    4fe8:      	add	x16, sp, #0x60
    4fec:      	movz	x17, #0x0, lsl #48
    4ff0:      	str	x17, [x16, #0x10]
    4ff4:      	add	x16, sp, #0x10
    4ff8:      	ldr	x0, [x16]
    4ffc:      	add	x16, sp, #0x10
    5000:      	ldr	x1, [x16, #0x8]
    5004:      	add	x16, sp, #0x10
    5008:      	ldr	x2, [x16, #0x10]
    500c:      	add	x16, sp, #0x10
    5010:      	ldr	x3, [x16, #0x18]
    5014:      	add	x16, sp, #0x10
    5018:      	ldr	x4, [x16, #0x20]
    501c:      	add	x16, sp, #0x10
    5020:      	ldr	x5, [x16, #0x28]
    5024:      	add	x16, sp, #0x10
    5028:      	ldr	x6, [x16, #0x30]
    502c:      	add	x16, sp, #0x10
    5030:      	ldr	x7, [x16, #0x38]
    5034:      	add	x16, sp, #0x10
    5038:      	ldr	x8, [x16, #0x40]
    503c:      	add	x16, sp, #0x10
    5040:      	ldr	x9, [x16, #0x48]
    5044:      	str	x0, [x20]
    5048:      	str	x1, [x20, #0x8]
    504c:      	str	x2, [x20, #0x10]
    5050:      	str	x3, [x20, #0x18]
    5054:      	str	x4, [x20, #0x20]
    5058:      	str	x5, [x20, #0x28]
    505c:      	str	x6, [x20, #0x30]
    5060:      	str	x7, [x20, #0x38]
    5064:      	str	x8, [x20, #0x40]
    5068:      	str	x9, [x20, #0x48]
    506c:      	ldr	x19, [sp, #0x90]
    5070:      	ldr	x20, [sp, #0x98]
    5074:      	ldr	x21, [sp, #0xa0]
    5078:      	ldr	x22, [sp, #0xa8]
    507c:      	ldr	x23, [sp, #0xb0]
    5080:      	ldr	x24, [sp, #0xb8]
    5084:      	ldr	x29, [sp]
    5088:      	ldr	x30, [sp, #0x8]
    508c:      	add	sp, sp, #0xc0
    5090:      	ret
    5094:      	mov	x20, x8
    5098:      	mov	x21, x0
    509c:      	b	0x4ca0 <_stogir.uses.build+0x100>

00000000000050a0 <_inherent$coil.arraylist.ArrayList$new__i32>:
    50a0:      	ldr	x1, [x0]
    50a4:      	ldr	x0, [x0, #0x8]
    50a8:      	movz	x17, #0x0, lsl #48
    50ac:      	str	x17, [x8]
    50b0:      	movz	x17, #0x0, lsl #48
    50b4:      	str	x17, [x8, #0x8]
    50b8:      	movz	x17, #0x0, lsl #48
    50bc:      	str	x17, [x8, #0x10]
    50c0:      	str	x1, [x8, #0x18]
    50c4:      	str	x0, [x8, #0x20]
    50c8:      	ret
    50cc:      	udf	#0x0

00000000000050d0 <_stogir.placement.pinned>:
    50d0:      	sub	sp, sp, #0xb0
    50d4:      	str	x29, [sp, #0x10]
    50d8:      	str	x30, [sp, #0x18]
    50dc:      	add	x29, sp, #0x10
    50e0:      	str	x19, [sp, #0x60]
    50e4:      	str	x20, [sp, #0x68]
    50e8:      	str	x21, [sp, #0x70]
    50ec:      	str	x22, [sp, #0x78]
    50f0:      	str	x23, [sp, #0x80]
    50f4:      	str	x24, [sp, #0x88]
    50f8:      	str	x25, [sp, #0x90]
    50fc:      	str	x26, [sp, #0x98]
    5100:      	str	x27, [sp, #0xa0]
    5104:      	add	x19, x1, #0x28
    5108:      	ldr	x3, [x2]
    510c:      	ldr	x2, [x2, #0x8]
    5110:      	add	x16, sp, #0x20
    5114:      	movz	x17, #0x0, lsl #48
    5118:      	str	x17, [x16]
    511c:      	add	x16, sp, #0x20
    5120:      	movz	x17, #0x0, lsl #48
    5124:      	str	x17, [x16, #0x8]
    5128:      	add	x16, sp, #0x20
    512c:      	movz	x17, #0x0, lsl #48
    5130:      	str	x17, [x16, #0x10]
    5134:      	add	x16, sp, #0x20
    5138:      	str	x3, [x16, #0x18]
    513c:      	add	x16, sp, #0x20
    5140:      	str	x2, [x16, #0x20]
    5144:      	movz	x20, #0x0, lsl #48
    5148:      	b	0x5198 <_stogir.placement.pinned+0xc8>
    514c:      	nop
    5150:      	lsl	x2, x2, #1
    5154:      	mov	x23, x8
    5158:      	mov	x24, x0
    515c:      	add	x0, sp, #0x20
    5160:      	mov	x25, x1
    5164:      	mov	x1, x2
    5168:      	bl	0x5168 <_stogir.placement.pinned+0x98>
		0000000000005168:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    516c:      	add	x20, x20, #0x1
    5170:      	add	x0, x22, #0x1
    5174:      	add	x16, sp, #0x20
    5178:      	ldr	x1, [x16]
    517c:      	add	x1, x1, x22, lsl #2
    5180:      	str	w21, [x1]
    5184:      	add	x16, sp, #0x20
    5188:      	str	x0, [x16, #0x8]
    518c:      	mov	x8, x23
    5190:      	mov	x0, x24
    5194:      	mov	x1, x25
    5198:      	ldr	x2, [x19, #0x8]
    519c:      	cmp	x20, x2
    51a0:      	b.ge	0x561c <_stogir.placement.pinned+0x54c>
    51a4:      	ldr	x2, [x1, #0x28]
    51a8:      	add	x2, x2, x20, lsl #2
    51ac:      	ldr	w21, [x2]
    51b0:      	add	x16, sp, #0x20
    51b4:      	ldr	x2, [x16, #0x8]
    51b8:      	orr	x22, x2, xzr
    51bc:      	add	x16, sp, #0x20
    51c0:      	ldr	x2, [x16, #0x10]
    51c4:      	cmp	x22, x2
    51c8:      	b.lt	0x5628 <_stogir.placement.pinned+0x558>
    51cc:      	cmp	x2, #0x0
    51d0:      	b.ne	0x5150 <_stogir.placement.pinned+0x80>
    51d4:      	mov	x2, #0x2                ; =2
    51d8:      	b	0x5154 <_stogir.placement.pinned+0x84>
    51dc:      	add	x19, x24, #0x78
    51e0:      	add	x20, x24, #0x28
    51e4:      	add	x21, x24, #0x50
    51e8:      	mov	x22, #0x1               ; =1
    51ec:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		00000000000051ec:  ARM64_RELOC_PAGE21	l_stogir.420
    51f0:      	ldr	x25, [x25]
		00000000000051f0:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    51f4:      	movz	x26, #0x0, lsl #48
    51f8:      	b	0x5298 <_stogir.placement.pinned+0x1c8>
    51fc:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		00000000000051fc:  ARM64_RELOC_PAGE21	l_stogir.421
    5200:      	ldr	x25, [x25]
		0000000000005200:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    5204:      	mov	x26, #0x15              ; =21
    5208:      	b	0x527c <_stogir.placement.pinned+0x1ac>
    520c:      	nop
    5210:      	movz	w0, #0x0, lsl #16
    5214:      	uxtb	w16, w0
    5218:      	and	w0, w16, #0x20
    521c:      	uxtb	w0, w0
    5220:      	ubfx	x0, x0, #0, #8
    5224:      	cmp	x0, #0x0
    5228:      	b.eq	0x527c <_stogir.placement.pinned+0x1ac>
    522c:      	orr	w0, w22, wzr
    5230:      	mov	w1, w0
    5234:      	mov	x0, x24
    5238:      	mov	x2, #0x1                ; =1
    523c:      	bl	0x523c <_stogir.placement.pinned+0x16c>
		000000000000523c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5240:      	ubfx	x0, x0, #0, #32
    5244:      	lsr	x16, x0, #0
    5248:      	cmp	x16, #0x1
    524c:      	b.eq	0x5268 <_stogir.placement.pinned+0x198>
    5250:      	b.lo	0x5258 <_stogir.placement.pinned+0x188>
    5254:      	b	0x526c <_stogir.placement.pinned+0x19c>
    5258:      	cmp	x16, #0x0
    525c:      	b.eq	0x5264 <_stogir.placement.pinned+0x194>
    5260:      	b	0x526c <_stogir.placement.pinned+0x19c>
    5264:      	b	0x5270 <_stogir.placement.pinned+0x1a0>
    5268:      	b	0x52e4 <_stogir.placement.pinned+0x214>
    526c:      	b	0x560c <_stogir.placement.pinned+0x53c>
    5270:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		0000000000005270:  ARM64_RELOC_PAGE21	l_stogir.422
    5274:      	ldr	x25, [x25]
		0000000000005274:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    5278:      	mov	x26, #0x19              ; =25
    527c:      	sxtw	x27, w27
    5280:      	add	x0, x27, #0x4
    5284:      	asr	x16, x0, #63
    5288:      	lsr	x16, x16, #62
    528c:      	add	x0, x0, x16
    5290:      	asr	x0, x0, #2
    5294:      	add	x22, x0, x22
    5298:      	cmp	x26, #0x0
    529c:      	b.ne	0x532c <_stogir.placement.pinned+0x25c>
    52a0:      	ldr	x0, [x24, #0x8]
    52a4:      	cmp	x22, x0
    52a8:      	b.ge	0x532c <_stogir.placement.pinned+0x25c>
    52ac:      	ldr	x0, [x24]
    52b0:      	add	x0, x0, x22, lsl #4
    52b4:      	ldr	x0, [x0]
    52b8:      	ldr	x1, [x24, #0x78]
    52bc:      	uxtb	w0, w0
    52c0:      	add	x1, x1, x22, lsl #2
    52c4:      	ldr	w27, [x1]
    52c8:      	cmp	x0, #0x83
    52cc:      	b.ge	0x5210 <_stogir.placement.pinned+0x140>
    52d0:      	adrp	x17, 0x5000 <_stogir.uses.build+0x460>
		00000000000052d0:  ARM64_RELOC_PAGE21	l_stogir.423
    52d4:      	ldr	x17, [x17]
		00000000000052d4:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    52d8:      	add	x0, x0, x17
    52dc:      	ldrb	w0, [x0]
    52e0:      	b	0x5214 <_stogir.placement.pinned+0x144>
    52e4:      	sxtw	x0, w1
    52e8:      	cmp	x0, #0x0
    52ec:      	b.le	0x51fc <_stogir.placement.pinned+0x12c>
    52f0:      	lsl	x2, x0, #2
    52f4:      	ldr	x3, [x24, #0x8]
    52f8:      	cmp	x0, x3
    52fc:      	b.ge	0x5450 <_stogir.placement.pinned+0x380>
    5300:      	ldr	x3, [x19, #0x8]
    5304:      	cmp	x0, x3
    5308:      	b.ge	0x5448 <_stogir.placement.pinned+0x378>
    530c:      	ldr	x3, [x24, #0x78]
    5310:      	add	x3, x2, x3
    5314:      	ldr	w3, [x3]
    5318:      	sxtw	x3, w3
    531c:      	cmp	x3, #0x0
    5320:      	cset	w3, ge
    5324:      	ubfx	x3, x3, #0, #8
    5328:      	b	0x544c <_stogir.placement.pinned+0x37c>
    532c:      	cmp	x26, #0x0
    5330:      	b.ne	0x5364 <_stogir.placement.pinned+0x294>
    5334:      	add	x16, sp, #0x20
    5338:      	ldr	x25, [x16]
    533c:      	add	x16, sp, #0x20
    5340:      	ldr	x26, [x16, #0x8]
    5344:      	add	x16, sp, #0x20
    5348:      	ldr	x0, [x16, #0x10]
    534c:      	add	x16, sp, #0x20
    5350:      	ldr	x1, [x16, #0x18]
    5354:      	add	x16, sp, #0x20
    5358:      	ldr	x2, [x16, #0x20]
    535c:      	movz	x3, #0x0, lsl #48
    5360:      	b	0x53fc <_stogir.placement.pinned+0x32c>
    5364:      	b	0x5374 <_stogir.placement.pinned+0x2a4>
    5368:      	sub	x0, x0, #0x1
    536c:      	add	x16, sp, #0x20
    5370:      	str	x0, [x16, #0x8]
    5374:      	add	x16, sp, #0x20
    5378:      	ldr	x0, [x16, #0x8]
    537c:      	cmp	x0, #0x0
    5380:      	b.ne	0x5368 <_stogir.placement.pinned+0x298>
    5384:      	add	x16, sp, #0x20
    5388:      	orr	x0, x16, xzr
    538c:      	add	x16, sp, #0x20
    5390:      	ldr	x1, [x16, #0x10]
    5394:      	cmp	x1, #0x0
    5398:      	b.le	0x53c8 <_stogir.placement.pinned+0x2f8>
    539c:      	add	x0, x0, #0x18
    53a0:      	add	x16, sp, #0x20
    53a4:      	ldr	x2, [x16]
    53a8:      	fmov	d31, x1
    53ac:      	mov	x1, x2
    53b0:      	fmov	x2, d31
    53b4:      	adrp	x3, 0x5000 <_stogir.uses.build+0x460>
		00000000000053b4:  ARM64_RELOC_PAGE21	l_stogir.424
    53b8:      	ldr	x3, [x3]
		00000000000053b8:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    53bc:      	mov	x4, #0x4                ; =4
    53c0:      	mov	x5, #0x4                ; =4
    53c4:      	bl	0x53c4 <_stogir.placement.pinned+0x2f4>
		00000000000053c4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    53c8:      	add	x16, sp, #0x20
    53cc:      	movz	x17, #0x0, lsl #48
    53d0:      	str	x17, [x16]
    53d4:      	add	x16, sp, #0x20
    53d8:      	movz	x17, #0x0, lsl #48
    53dc:      	str	x17, [x16, #0x8]
    53e0:      	add	x16, sp, #0x20
    53e4:      	movz	x17, #0x0, lsl #48
    53e8:      	str	x17, [x16, #0x10]
    53ec:      	mov	x3, #0x1                ; =1
    53f0:      	movz	x0, #0x0, lsl #48
    53f4:      	movz	x1, #0x0, lsl #48
    53f8:      	movz	x2, #0x0, lsl #48
    53fc:      	str	x3, [x23]
    5400:      	str	x25, [x23, #0x8]
    5404:      	str	x26, [x23, #0x10]
    5408:      	str	x0, [x23, #0x18]
    540c:      	str	x1, [x23, #0x20]
    5410:      	str	x2, [x23, #0x28]
    5414:      	ldr	x19, [sp, #0x60]
    5418:      	ldr	x20, [sp, #0x68]
    541c:      	ldr	x21, [sp, #0x70]
    5420:      	ldr	x22, [sp, #0x78]
    5424:      	ldr	x23, [sp, #0x80]
    5428:      	ldr	x24, [sp, #0x88]
    542c:      	ldr	x25, [sp, #0x90]
    5430:      	ldr	x26, [sp, #0x98]
    5434:      	ldr	x27, [sp, #0xa0]
    5438:      	ldr	x29, [sp, #0x10]
    543c:      	ldr	x30, [sp, #0x18]
    5440:      	add	sp, sp, #0xb0
    5444:      	ret
    5448:      	movz	x3, #0x0, lsl #48
    544c:      	b	0x5454 <_stogir.placement.pinned+0x384>
    5450:      	movz	x3, #0x0, lsl #48
    5454:      	cmp	x3, #0x0
    5458:      	b.eq	0x51fc <_stogir.placement.pinned+0x12c>
    545c:      	movz	x16, #0x0, lsl #48
    5460:      	sub	x3, x16, x0
    5464:      	cmp	x0, #0x0
    5468:      	cset	w4, gt
    546c:      	sub	x5, x3, #0x1
    5470:      	uxtb	w16, w4
    5474:      	cmp	w16, wzr
    5478:      	b.eq	0x54c4 <_stogir.placement.pinned+0x3f4>
    547c:      	ldr	x3, [x24, #0x8]
    5480:      	cmp	x0, x3
    5484:      	b.ge	0x5504 <_stogir.placement.pinned+0x434>
    5488:      	ldr	x3, [x19, #0x8]
    548c:      	cmp	x0, x3
    5490:      	b.ge	0x55b8 <_stogir.placement.pinned+0x4e8>
    5494:      	ldr	x3, [x24, #0x78]
    5498:      	add	x2, x2, x3
    549c:      	ldr	w2, [x2]
    54a0:      	sxtw	x2, w2
    54a4:      	cmp	x2, #0x0
    54a8:      	cset	w2, ge
    54ac:      	ubfx	x2, x2, #0, #8
    54b0:      	b	0x55bc <_stogir.placement.pinned+0x4ec>
    54b4:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		00000000000054b4:  ARM64_RELOC_PAGE21	l_stogir.425
    54b8:      	ldr	x25, [x25]
		00000000000054b8:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    54bc:      	mov	x26, #0x20              ; =32
    54c0:      	b	0x5208 <_stogir.placement.pinned+0x138>
    54c4:      	cmp	x0, #0x0
    54c8:      	b.ge	0x550c <_stogir.placement.pinned+0x43c>
    54cc:      	ldr	x2, [x20, #0x8]
    54d0:      	ldr	x6, [x21, #0x8]
    54d4:      	cmp	x2, x6
    54d8:      	b.ne	0x55b0 <_stogir.placement.pinned+0x4e0>
    54dc:      	cmp	x3, x2
    54e0:      	b.gt	0x5604 <_stogir.placement.pinned+0x534>
    54e4:      	ldr	x2, [x24, #0x50]
    54e8:      	add	x2, x2, x5, lsl #2
    54ec:      	ldr	w2, [x2]
    54f0:      	sxtw	x2, w2
    54f4:      	cmp	x2, #0x0
    54f8:      	cset	w2, gt
    54fc:      	ubfx	x2, x2, #0, #8
    5500:      	b	0x5608 <_stogir.placement.pinned+0x538>
    5504:      	movz	x2, #0x0, lsl #48
    5508:      	b	0x5510 <_stogir.placement.pinned+0x440>
    550c:      	movz	x2, #0x0, lsl #48
    5510:      	cmp	x2, #0x0
    5514:      	b.eq	0x5548 <_stogir.placement.pinned+0x478>
    5518:      	uxtb	w16, w4
    551c:      	cmp	w16, wzr
    5520:      	b.eq	0x5534 <_stogir.placement.pinned+0x464>
    5524:      	ldr	x2, [x24]
    5528:      	add	x0, x2, x0, lsl #4
    552c:      	ldr	x0, [x0]
    5530:      	b	0x5540 <_stogir.placement.pinned+0x470>
    5534:      	ldr	x0, [x24, #0x28]
    5538:      	add	x0, x0, x5, lsl #4
    553c:      	ldr	x0, [x0]
    5540:      	mov	w2, #0x1                ; =1
    5544:      	b	0x5550 <_stogir.placement.pinned+0x480>
    5548:      	movz	w2, #0x0, lsl #16
    554c:      	movz	x0, #0x0, lsl #48
    5550:      	ubfx	x2, x2, #0, #32
    5554:      	lsr	x16, x2, #0
    5558:      	cmp	x16, #0x1
    555c:      	b.eq	0x5578 <_stogir.placement.pinned+0x4a8>
    5560:      	b.lo	0x5568 <_stogir.placement.pinned+0x498>
    5564:      	b	0x557c <_stogir.placement.pinned+0x4ac>
    5568:      	cmp	x16, #0x0
    556c:      	b.eq	0x5574 <_stogir.placement.pinned+0x4a4>
    5570:      	b	0x557c <_stogir.placement.pinned+0x4ac>
    5574:      	b	0x5580 <_stogir.placement.pinned+0x4b0>
    5578:      	b	0x5590 <_stogir.placement.pinned+0x4c0>
    557c:      	b	0x5614 <_stogir.placement.pinned+0x544>
    5580:      	adrp	x25, 0x5000 <_stogir.uses.build+0x460>
		0000000000005580:  ARM64_RELOC_PAGE21	l_stogir.421
    5584:      	ldr	x25, [x25]
		0000000000005584:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    5588:      	mov	x26, #0x15              ; =21
    558c:      	b	0x54c0 <_stogir.placement.pinned+0x3f0>
    5590:      	uxtb	w0, w0
    5594:      	cmp	x0, #0x83
    5598:      	b.ge	0x55c0 <_stogir.placement.pinned+0x4f0>
    559c:      	adrp	x17, 0x5000 <_stogir.uses.build+0x460>
		000000000000559c:  ARM64_RELOC_PAGE21	l_stogir.423
    55a0:      	ldr	x17, [x17]
		00000000000055a0:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    55a4:      	add	x0, x0, x17
    55a8:      	ldrb	w0, [x0]
    55ac:      	b	0x55c4 <_stogir.placement.pinned+0x4f4>
    55b0:      	movz	x2, #0x0, lsl #48
    55b4:      	b	0x5510 <_stogir.placement.pinned+0x440>
    55b8:      	movz	x2, #0x0, lsl #48
    55bc:      	b	0x5508 <_stogir.placement.pinned+0x438>
    55c0:      	movz	w0, #0x0, lsl #16
    55c4:      	uxtb	w16, w0
    55c8:      	and	w0, w16, #0x2
    55cc:      	uxtb	w0, w0
    55d0:      	ubfx	x0, x0, #0, #8
    55d4:      	cmp	x0, #0x0
    55d8:      	cset	w0, eq
    55dc:      	uxtb	w16, w0
    55e0:      	cmp	w16, wzr
    55e4:      	cset	x0, eq
    55e8:      	cmp	x0, #0x0
    55ec:      	b.eq	0x54b4 <_stogir.placement.pinned+0x3e4>
    55f0:      	add	x16, sp, #0x20
    55f4:      	ldr	x0, [x16]
    55f8:      	add	x0, x0, x22, lsl #2
    55fc:      	str	w1, [x0]
    5600:      	b	0x54c0 <_stogir.placement.pinned+0x3f0>
    5604:      	movz	x2, #0x0, lsl #48
    5608:      	b	0x55b4 <_stogir.placement.pinned+0x4e4>
    560c:      	brk	#0
    5610:      	b	0x560c <_stogir.placement.pinned+0x53c>
    5614:      	brk	#0
    5618:      	b	0x5614 <_stogir.placement.pinned+0x544>
    561c:      	mov	x23, x8
    5620:      	mov	x24, x0
    5624:      	b	0x51dc <_stogir.placement.pinned+0x10c>
    5628:      	mov	x23, x8
    562c:      	mov	x24, x0
    5630:      	mov	x25, x1
    5634:      	b	0x516c <_stogir.placement.pinned+0x9c>

0000000000005638 <_stogir.placement.early-with-uses!>:
    5638:      	sub	sp, sp, #0x1b0
    563c:      	str	x29, [sp, #0x10]
    5640:      	str	x30, [sp, #0x18]
    5644:      	add	x29, sp, #0x10
    5648:      	str	x19, [sp, #0x158]
    564c:      	str	x20, [sp, #0x160]
    5650:      	str	x21, [sp, #0x168]
    5654:      	str	x22, [sp, #0x170]
    5658:      	str	x23, [sp, #0x178]
    565c:      	str	x24, [sp, #0x180]
    5660:      	str	x25, [sp, #0x188]
    5664:      	str	x26, [sp, #0x190]
    5668:      	str	x27, [sp, #0x198]
    566c:      	str	x28, [sp, #0x1a0]
    5670:      	mov	x19, x8
    5674:      	add	x8, sp, #0x50
    5678:      	mov	x20, x0
    567c:      	mov	x0, x5
    5680:      	mov	x21, x1
    5684:      	mov	x22, x2
    5688:      	mov	w23, w3
    568c:      	mov	x24, x4
    5690:      	mov	x25, x5
    5694:      	bl	0x5694 <_stogir.placement.early-with-uses!+0x5c>
		0000000000005694:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    5698:      	add	x16, sp, #0x50
    569c:      	ldr	x0, [x16]
    56a0:      	add	x16, sp, #0x20
    56a4:      	str	x0, [x16]
    56a8:      	add	x16, sp, #0x50
    56ac:      	ldr	x0, [x16, #0x8]
    56b0:      	add	x16, sp, #0x20
    56b4:      	str	x0, [x16, #0x8]
    56b8:      	add	x16, sp, #0x50
    56bc:      	ldr	x0, [x16, #0x10]
    56c0:      	add	x16, sp, #0x20
    56c4:      	str	x0, [x16, #0x10]
    56c8:      	add	x16, sp, #0x50
    56cc:      	ldr	x0, [x16, #0x18]
    56d0:      	add	x16, sp, #0x20
    56d4:      	str	x0, [x16, #0x18]
    56d8:      	add	x16, sp, #0x50
    56dc:      	ldr	x0, [x16, #0x20]
    56e0:      	add	x16, sp, #0x20
    56e4:      	str	x0, [x16, #0x20]
    56e8:      	add	x8, sp, #0xb0
    56ec:      	mov	x0, x25
    56f0:      	bl	0x56f0 <_stogir.placement.early-with-uses!+0xb8>
		00000000000056f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    56f4:      	add	x16, sp, #0xb0
    56f8:      	ldr	x0, [x16]
    56fc:      	add	x16, sp, #0x80
    5700:      	str	x0, [x16]
    5704:      	add	x16, sp, #0xb0
    5708:      	ldr	x0, [x16, #0x8]
    570c:      	add	x16, sp, #0x80
    5710:      	str	x0, [x16, #0x8]
    5714:      	add	x16, sp, #0xb0
    5718:      	ldr	x0, [x16, #0x10]
    571c:      	add	x16, sp, #0x80
    5720:      	str	x0, [x16, #0x10]
    5724:      	add	x16, sp, #0xb0
    5728:      	ldr	x0, [x16, #0x18]
    572c:      	add	x16, sp, #0x80
    5730:      	str	x0, [x16, #0x18]
    5734:      	add	x16, sp, #0xb0
    5738:      	ldr	x0, [x16, #0x20]
    573c:      	add	x16, sp, #0x80
    5740:      	str	x0, [x16, #0x20]
    5744:      	movz	x25, #0x0, lsl #48
    5748:      	b	0x5784 <_stogir.placement.early-with-uses!+0x14c>
    574c:      	nop
    5750:      	lsl	x0, x0, #1
    5754:      	mov	x1, x0
    5758:      	add	x0, sp, #0x20
    575c:      	bl	0x575c <_stogir.placement.early-with-uses!+0x124>
		000000000000575c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5760:      	add	x25, x25, #0x1
    5764:      	add	x0, x26, #0x1
    5768:      	add	x16, sp, #0x20
    576c:      	ldr	x1, [x16]
    5770:      	add	x1, x1, x26, lsl #2
    5774:      	movn	w17, #0x0, lsl #16
    5778:      	str	w17, [x1]
    577c:      	add	x16, sp, #0x20
    5780:      	str	x0, [x16, #0x8]
    5784:      	ldr	x0, [x20, #0x8]
    5788:      	cmp	x25, x0
    578c:      	b.ge	0x57bc <_stogir.placement.early-with-uses!+0x184>
    5790:      	add	x16, sp, #0x20
    5794:      	ldr	x0, [x16, #0x8]
    5798:      	orr	x26, x0, xzr
    579c:      	add	x16, sp, #0x20
    57a0:      	ldr	x0, [x16, #0x10]
    57a4:      	cmp	x26, x0
    57a8:      	b.lt	0x5760 <_stogir.placement.early-with-uses!+0x128>
    57ac:      	cmp	x0, #0x0
    57b0:      	b.ne	0x5750 <_stogir.placement.early-with-uses!+0x118>
    57b4:      	mov	x0, #0x2                ; =2
    57b8:      	b	0x5754 <_stogir.placement.early-with-uses!+0x11c>
    57bc:      	mov	x25, #0x1               ; =1
    57c0:      	movz	x26, #0x0, lsl #48
    57c4:      	adrp	x27, 0x5000 <_stogir.uses.build+0x460>
		00000000000057c4:  ARM64_RELOC_PAGE21	l_stogir.426
    57c8:      	ldr	x27, [x27]
		00000000000057c8:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    57cc:      	movz	x28, #0x0, lsl #48
    57d0:      	b	0x5830 <_stogir.placement.early-with-uses!+0x1f8>
    57d4:      	lsl	x0, x0, #1
    57d8:      	mov	x1, x0
    57dc:      	add	x0, sp, #0x80
    57e0:      	bl	0x57e0 <_stogir.placement.early-with-uses!+0x1a8>
		00000000000057e0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    57e4:      	add	x0, x22, #0x1
    57e8:      	add	x16, sp, #0x80
    57ec:      	ldr	x1, [x16]
    57f0:      	add	x1, x1, x22, lsl #2
    57f4:      	str	w27, [x1]
    57f8:      	add	x16, sp, #0x80
    57fc:      	str	x0, [x16, #0x8]
    5800:      	add	x0, x26, #0x1
    5804:      	sxtw	x26, w0
    5808:      	add	x0, x19, #0x4
    580c:      	asr	x16, x0, #63
    5810:      	lsr	x16, x16, #62
    5814:      	add	x0, x0, x16
    5818:      	asr	x0, x0, #2
    581c:      	add	x25, x0, x25
    5820:      	ldr	x19, [sp, #0x108]
    5824:      	ldr	x22, [sp, #0x128]
    5828:      	ldr	x24, [sp, #0x120]
    582c:      	ldr	x27, [sp, #0x110]
    5830:      	ldr	x0, [x20, #0x8]
    5834:      	cmp	x25, x0
    5838:      	b.ge	0x5f60 <_stogir.placement.early-with-uses!+0x928>
    583c:      	lsl	x0, x25, #2
    5840:      	ldr	x1, [x20]
    5844:      	add	x1, x1, x25, lsl #4
    5848:      	ldr	x1, [x1]
    584c:      	ldr	x2, [x20, #0x78]
    5850:      	uxtb	w1, w1
    5854:      	add	x2, x2, x25, lsl #2
    5858:      	cmp	x1, #0x83
    585c:      	cset	w3, lt
    5860:      	ldr	w2, [x2]
    5864:      	uxtb	w16, w3
    5868:      	cmp	w16, wzr
    586c:      	b.eq	0x5884 <_stogir.placement.early-with-uses!+0x24c>
    5870:      	adrp	x17, 0x5000 <_stogir.uses.build+0x460>
		0000000000005870:  ARM64_RELOC_PAGE21	l_stogir.427
    5874:      	ldr	x17, [x17]
		0000000000005874:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    5878:      	add	x4, x1, x17
    587c:      	ldrb	w4, [x4]
    5880:      	b	0x5888 <_stogir.placement.early-with-uses!+0x250>
    5884:      	movz	w4, #0x0, lsl #16
    5888:      	ldr	x5, [x21]
    588c:      	add	x0, x5, x0
    5890:      	ldr	w0, [x0]
    5894:      	sxtw	x0, w0
    5898:      	cmp	x0, #0x0
    589c:      	b.ne	0x58c8 <_stogir.placement.early-with-uses!+0x290>
    58a0:      	uxtb	w16, w4
    58a4:      	and	w0, w16, #0x40
    58a8:      	uxtb	w0, w0
    58ac:      	ubfx	x0, x0, #0, #8
    58b0:      	cmp	x0, #0x0
    58b4:      	b.ne	0x58c0 <_stogir.placement.early-with-uses!+0x288>
    58b8:      	movz	x0, #0x0, lsl #48
    58bc:      	b	0x58c4 <_stogir.placement.early-with-uses!+0x28c>
    58c0:      	mov	x0, #0x1                ; =1
    58c4:      	b	0x58cc <_stogir.placement.early-with-uses!+0x294>
    58c8:      	movz	x0, #0x0, lsl #48
    58cc:      	sxtw	x2, w2
    58d0:      	cmp	x0, #0x0
    58d4:      	b.eq	0x5f74 <_stogir.placement.early-with-uses!+0x93c>
    58d8:      	orr	w0, w25, wzr
    58dc:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		00000000000058dc:  ARM64_RELOC_PAGE21	l_stogir.428
    58e0:      	ldr	x16, [x16]
		00000000000058e0:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    58e4:      	add	x1, x16, x1, lsl #2
    58e8:      	mov	x4, #0x1                ; =1
    58ec:      	movz	x5, #0x0, lsl #48
    58f0:      	b	0x5968 <_stogir.placement.early-with-uses!+0x330>
    58f4:      	sub	w7, w6, #0x1
    58f8:      	lsl	w7, w7, #2
    58fc:      	ubfx	x7, x7, #0, #32
    5900:      	lsr	x7, x8, x7
    5904:      	and	w7, w7, #0xf
    5908:      	b	0x59a4 <_stogir.placement.early-with-uses!+0x36c>
    590c:      	sxtw	x1, w1
    5910:      	cmp	x1, #0x0
    5914:      	b.le	0x5938 <_stogir.placement.early-with-uses!+0x300>
    5918:      	ldr	x0, [x21]
    591c:      	add	x0, x0, x1, lsl #2
    5920:      	ldr	w0, [x0]
    5924:      	sxtw	x0, w0
    5928:      	cmp	x0, #0x0
    592c:      	b.ne	0x5938 <_stogir.placement.early-with-uses!+0x300>
    5930:      	add	x0, x22, #0x1
    5934:      	sxtw	x22, w0
    5938:      	add	x0, x24, #0x1
    593c:      	sxtw	x24, w0
    5940:      	mov	x2, x19
    5944:      	ldr	x19, [sp, #0x108]
    5948:      	mov	w0, w27
    594c:      	ldr	w3, [sp, #0x100]
    5950:      	ldr	x1, [sp, #0x118]
    5954:      	mov	x4, x24
    5958:      	ldr	x24, [sp, #0x120]
    595c:      	mov	x5, x22
    5960:      	ldr	x22, [sp, #0x128]
    5964:      	ldr	x27, [sp, #0x110]
    5968:      	cmp	x4, x2
    596c:      	b.gt	0x5f8c <_stogir.placement.early-with-uses!+0x954>
    5970:      	orr	w6, w4, wzr
    5974:      	uxtb	w16, w3
    5978:      	cmp	w16, wzr
    597c:      	b.eq	0x59a8 <_stogir.placement.early-with-uses!+0x370>
    5980:      	sxtw	x7, w6
    5984:      	ldr	w8, [x1]
    5988:      	cmp	x7, #0x0
    598c:      	b.le	0x59a0 <_stogir.placement.early-with-uses!+0x368>
    5990:      	cmp	x7, #0x4
    5994:      	b.le	0x58f4 <_stogir.placement.early-with-uses!+0x2bc>
    5998:      	mov	w7, #0x4                ; =4
    599c:      	b	0x58f8 <_stogir.placement.early-with-uses!+0x2c0>
    59a0:      	movz	w7, #0x0, lsl #16
    59a4:      	b	0x59ac <_stogir.placement.early-with-uses!+0x374>
    59a8:      	movz	w7, #0x0, lsl #16
    59ac:      	ubfx	x7, x7, #0, #32
    59b0:      	cmp	x7, #0xf
    59b4:      	b.hs	0x5fac <_stogir.placement.early-with-uses!+0x974>
    59b8:      	mov	x16, #0x1               ; =1
    59bc:      	lsl	x7, x16, x7
    59c0:      	mov	w17, #0x5e1c            ; =24092
    59c4:      	and	w7, w7, w17
    59c8:      	ubfx	x7, x7, #0, #32
    59cc:      	cmp	x7, #0x0
    59d0:      	b.eq	0x5fd8 <_stogir.placement.early-with-uses!+0x9a0>
    59d4:      	str	w3, [sp, #0x100]
    59d8:      	str	x1, [sp, #0x118]
    59dc:      	mov	w1, w0
    59e0:      	str	x19, [sp, #0x108]
    59e4:      	mov	x19, x2
    59e8:      	mov	w2, w6
    59ec:      	str	x27, [sp, #0x110]
    59f0:      	mov	w27, w0
    59f4:      	mov	x0, x20
    59f8:      	str	x24, [sp, #0x120]
    59fc:      	mov	x24, x4
    5a00:      	str	x22, [sp, #0x128]
    5a04:      	mov	x22, x5
    5a08:      	bl	0x5a08 <_stogir.placement.early-with-uses!+0x3d0>
		0000000000005a08:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5a0c:      	ubfx	x0, x0, #0, #32
    5a10:      	lsr	x16, x0, #0
    5a14:      	cmp	x16, #0x1
    5a18:      	b.eq	0x5a34 <_stogir.placement.early-with-uses!+0x3fc>
    5a1c:      	b.lo	0x5a24 <_stogir.placement.early-with-uses!+0x3ec>
    5a20:      	b	0x5a38 <_stogir.placement.early-with-uses!+0x400>
    5a24:      	cmp	x16, #0x0
    5a28:      	b.eq	0x5a30 <_stogir.placement.early-with-uses!+0x3f8>
    5a2c:      	b	0x5a38 <_stogir.placement.early-with-uses!+0x400>
    5a30:      	b	0x5a3c <_stogir.placement.early-with-uses!+0x404>
    5a34:      	b	0x590c <_stogir.placement.early-with-uses!+0x2d4>
    5a38:      	b	0x5f58 <_stogir.placement.early-with-uses!+0x920>
    5a3c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		0000000000005a3c:  ARM64_RELOC_PAGE21	l_stogir.429
    5a40:      	ldr	x16, [x16]
		0000000000005a40:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    5a44:      	str	x16, [sp, #0x110]
    5a48:      	mov	x28, #0x18              ; =24
    5a4c:      	b	0x5938 <_stogir.placement.early-with-uses!+0x300>
    5a50:      	orr	w0, w22, wzr
    5a54:      	add	x16, sp, #0x20
    5a58:      	ldr	x1, [x16]
    5a5c:      	add	x1, x1, x25, lsl #2
    5a60:      	str	w0, [x1]
    5a64:      	cmp	x22, #0x0
    5a68:      	b.ne	0x5800 <_stogir.placement.early-with-uses!+0x1c8>
    5a6c:      	add	x16, sp, #0x80
    5a70:      	ldr	x0, [x16, #0x8]
    5a74:      	orr	x22, x0, xzr
    5a78:      	add	x16, sp, #0x80
    5a7c:      	ldr	x0, [x16, #0x10]
    5a80:      	cmp	x22, x0
    5a84:      	b.lt	0x57e4 <_stogir.placement.early-with-uses!+0x1ac>
    5a88:      	cmp	x0, #0x0
    5a8c:      	b.ne	0x57d4 <_stogir.placement.early-with-uses!+0x19c>
    5a90:      	mov	x0, #0x2                ; =2
    5a94:      	b	0x57d8 <_stogir.placement.early-with-uses!+0x1a0>
    5a98:      	sxtw	x23, w23
    5a9c:      	movz	x19, #0x0, lsl #48
    5aa0:      	movz	x22, #0x0, lsl #48
    5aa4:      	b	0x5bec <_stogir.placement.early-with-uses!+0x5b4>
    5aa8:      	movz	x1, #0x0, lsl #48
    5aac:      	movz	x2, #0x0, lsl #48
    5ab0:      	b	0x5ac4 <_stogir.placement.early-with-uses!+0x48c>
    5ab4:      	mov	x23, x3
    5ab8:      	b	0x5ac4 <_stogir.placement.early-with-uses!+0x48c>
    5abc:      	nop
    5ac0:      	mov	x1, #0x1                ; =1
    5ac4:      	cmp	x1, #0x0
    5ac8:      	b.ne	0x5c74 <_stogir.placement.early-with-uses!+0x63c>
    5acc:      	cmp	x23, #0x0
    5ad0:      	b.le	0x5ac0 <_stogir.placement.early-with-uses!+0x488>
    5ad4:      	ldr	x3, [x4, #0x8]
    5ad8:      	cmp	x23, x3
    5adc:      	b.ge	0x5ac0 <_stogir.placement.early-with-uses!+0x488>
    5ae0:      	ldr	x3, [x4]
    5ae4:      	add	x3, x3, x23, lsl #2
    5ae8:      	ldr	w3, [x3]
    5aec:      	sxtw	x3, w3
    5af0:      	cmp	x3, #0x0
    5af4:      	b.ne	0x5b00 <_stogir.placement.early-with-uses!+0x4c8>
    5af8:      	mov	x1, #0x1                ; =1
    5afc:      	b	0x5ab8 <_stogir.placement.early-with-uses!+0x480>
    5b00:      	cmp	x23, x0
    5b04:      	b.ne	0x5f40 <_stogir.placement.early-with-uses!+0x908>
    5b08:      	mov	x1, #0x1                ; =1
    5b0c:      	mov	x2, #0x1                ; =1
    5b10:      	b	0x5ab8 <_stogir.placement.early-with-uses!+0x480>
    5b14:      	nop
    5b18:      	lsl	x1, x1, #1
    5b1c:      	str	x4, [sp, #0x128]
    5b20:      	str	x20, [sp, #0x120]
    5b24:      	mov	x20, x0
    5b28:      	add	x0, sp, #0x80
    5b2c:      	bl	0x5b2c <_stogir.placement.early-with-uses!+0x4f4>
		0000000000005b2c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    5b30:      	add	x0, x20, #0x1
    5b34:      	add	x16, sp, #0x80
    5b38:      	ldr	x1, [x16]
    5b3c:      	add	x1, x1, x20, lsl #2
    5b40:      	str	w27, [x1]
    5b44:      	add	x16, sp, #0x80
    5b48:      	str	x0, [x16, #0x8]
    5b4c:      	add	x25, x25, #0x1
    5b50:      	ldr	x4, [sp, #0x128]
    5b54:      	ldr	x20, [sp, #0x120]
    5b58:      	cmp	x25, x24
    5b5c:      	b.ge	0x6004 <_stogir.placement.early-with-uses!+0x9cc>
    5b60:      	add	x0, x23, x25
    5b64:      	ldr	x1, [x20, #0x28]
    5b68:      	add	x0, x1, x0, lsl #3
    5b6c:      	ldr	x0, [x0]
    5b70:      	add	x16, sp, #0x20
    5b74:      	ldr	x1, [x16]
    5b78:      	orr	w27, w0, wzr
    5b7c:      	sxtw	x0, w27
    5b80:      	add	x2, x1, x0, lsl #2
    5b84:      	ldr	w2, [x2]
    5b88:      	sxtw	x3, w2
    5b8c:      	cmp	x3, #0x0
    5b90:      	b.le	0x6010 <_stogir.placement.early-with-uses!+0x9d8>
    5b94:      	sub	w2, w2, #0x1
    5b98:      	add	x0, x1, x0, lsl #2
    5b9c:      	str	w2, [x0]
    5ba0:      	cmp	x3, #0x1
    5ba4:      	b.ne	0x601c <_stogir.placement.early-with-uses!+0x9e4>
    5ba8:      	add	x16, sp, #0x80
    5bac:      	ldr	x0, [x16, #0x8]
    5bb0:      	add	x16, sp, #0x80
    5bb4:      	ldr	x1, [x16, #0x10]
    5bb8:      	cmp	x0, x1
    5bbc:      	b.lt	0x6028 <_stogir.placement.early-with-uses!+0x9f0>
    5bc0:      	cmp	x1, #0x0
    5bc4:      	b.ne	0x5b18 <_stogir.placement.early-with-uses!+0x4e0>
    5bc8:      	mov	x1, #0x2                ; =2
    5bcc:      	b	0x5b1c <_stogir.placement.early-with-uses!+0x4e4>
    5bd0:      	add	x0, x22, #0x1
    5bd4:      	sub	x1, x26, #0x1
    5bd8:      	sxtw	x22, w0
    5bdc:      	sxtw	x26, w1
    5be0:      	add	x19, x19, #0x1
    5be4:      	ldr	x20, [sp, #0x140]
    5be8:      	ldr	x23, [sp, #0x150]
    5bec:      	cmp	x28, #0x0
    5bf0:      	b.ne	0x5e98 <_stogir.placement.early-with-uses!+0x860>
    5bf4:      	add	x16, sp, #0x80
    5bf8:      	ldr	x0, [x16, #0x8]
    5bfc:      	cmp	x19, x0
    5c00:      	b.ge	0x5e98 <_stogir.placement.early-with-uses!+0x860>
    5c04:      	add	x16, sp, #0x80
    5c08:      	ldr	x0, [x16]
    5c0c:      	add	x0, x0, x19, lsl #2
    5c10:      	ldr	w0, [x0]
    5c14:      	sxtw	x24, w0
    5c18:      	ldr	x1, [x20]
    5c1c:      	orr	w25, w0, wzr
    5c20:      	add	x0, x1, x24, lsl #4
    5c24:      	ldr	x0, [x0]
    5c28:      	ldr	x1, [x20, #0x78]
    5c2c:      	uxtb	w0, w0
    5c30:      	add	x1, x1, x24, lsl #2
    5c34:      	cmp	x0, #0x83
    5c38:      	cset	w27, lt
    5c3c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		0000000000005c3c:  ARM64_RELOC_PAGE21	l_stogir.428
    5c40:      	ldr	x16, [x16]
		0000000000005c40:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    5c44:      	add	x0, x16, x0, lsl #2
    5c48:      	ldr	w1, [x1]
    5c4c:      	sxtw	x1, w1
    5c50:      	mov	x3, x23
    5c54:      	mov	x2, #0x1                ; =1
    5c58:      	b	0x5cb0 <_stogir.placement.early-with-uses!+0x678>
    5c5c:      	sub	w6, w4, #0x1
    5c60:      	lsl	w6, w6, #2
    5c64:      	ubfx	x6, x6, #0, #32
    5c68:      	lsr	x6, x7, x6
    5c6c:      	and	w6, w6, #0xf
    5c70:      	b	0x5d0c <_stogir.placement.early-with-uses!+0x6d4>
    5c74:      	cmp	x2, #0x0
    5c78:      	b.ne	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    5c7c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		0000000000005c7c:  ARM64_RELOC_PAGE21	l_stogir.430
    5c80:      	ldr	x16, [x16]
		0000000000005c80:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    5c84:      	str	x16, [sp, #0x110]
    5c88:      	mov	x28, #0x2b              ; =43
    5c8c:      	add	x0, x20, #0x1
    5c90:      	sxtw	x20, w0
    5c94:      	str	x4, [sp, #0x128]
    5c98:      	ldr	x23, [sp, #0x150]
    5c9c:      	ldr	x1, [sp, #0x138]
    5ca0:      	ldr	x0, [sp, #0x130]
    5ca4:      	mov	x2, x20
    5ca8:      	ldr	x20, [sp, #0x140]
    5cac:      	ldr	x3, [sp, #0x148]
    5cb0:      	cmp	x28, #0x0
    5cb4:      	b.ne	0x5cc8 <_stogir.placement.early-with-uses!+0x690>
    5cb8:      	cmp	x2, x1
    5cbc:      	cset	w4, le
    5cc0:      	ubfx	x4, x4, #0, #8
    5cc4:      	b	0x5ccc <_stogir.placement.early-with-uses!+0x694>
    5cc8:      	movz	x4, #0x0, lsl #48
    5ccc:      	orr	w5, w3, wzr
    5cd0:      	cmp	x4, #0x0
    5cd4:      	b.eq	0x6038 <_stogir.placement.early-with-uses!+0xa00>
    5cd8:      	orr	w4, w2, wzr
    5cdc:      	uxtb	w16, w27
    5ce0:      	cmp	w16, wzr
    5ce4:      	b.eq	0x5d10 <_stogir.placement.early-with-uses!+0x6d8>
    5ce8:      	sxtw	x6, w4
    5cec:      	ldr	w7, [x0]
    5cf0:      	cmp	x6, #0x0
    5cf4:      	b.le	0x5d08 <_stogir.placement.early-with-uses!+0x6d0>
    5cf8:      	cmp	x6, #0x4
    5cfc:      	b.le	0x5c5c <_stogir.placement.early-with-uses!+0x624>
    5d00:      	mov	w6, #0x4                ; =4
    5d04:      	b	0x5c60 <_stogir.placement.early-with-uses!+0x628>
    5d08:      	movz	w6, #0x0, lsl #16
    5d0c:      	b	0x5d14 <_stogir.placement.early-with-uses!+0x6dc>
    5d10:      	movz	w6, #0x0, lsl #16
    5d14:      	ubfx	x6, x6, #0, #32
    5d18:      	cmp	x6, #0xf
    5d1c:      	b.hs	0x604c <_stogir.placement.early-with-uses!+0xa14>
    5d20:      	mov	x16, #0x1               ; =1
    5d24:      	lsl	x6, x16, x6
    5d28:      	mov	w17, #0x5e1c            ; =24092
    5d2c:      	and	w6, w6, w17
    5d30:      	ubfx	x6, x6, #0, #32
    5d34:      	cmp	x6, #0x0
    5d38:      	b.eq	0x606c <_stogir.placement.early-with-uses!+0xa34>
    5d3c:      	str	x0, [sp, #0x130]
    5d40:      	mov	x0, x20
    5d44:      	str	x1, [sp, #0x138]
    5d48:      	mov	w1, w25
    5d4c:      	str	x3, [sp, #0x148]
    5d50:      	str	x20, [sp, #0x140]
    5d54:      	mov	x20, x2
    5d58:      	mov	w2, w4
    5d5c:      	str	x23, [sp, #0x150]
    5d60:      	mov	w23, w5
    5d64:      	bl	0x5d64 <_stogir.placement.early-with-uses!+0x72c>
		0000000000005d64:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5d68:      	ubfx	x0, x0, #0, #32
    5d6c:      	lsr	x16, x0, #0
    5d70:      	cmp	x16, #0x1
    5d74:      	b.eq	0x5d90 <_stogir.placement.early-with-uses!+0x758>
    5d78:      	b.lo	0x5d80 <_stogir.placement.early-with-uses!+0x748>
    5d7c:      	b	0x5d94 <_stogir.placement.early-with-uses!+0x75c>
    5d80:      	cmp	x16, #0x0
    5d84:      	b.eq	0x5d8c <_stogir.placement.early-with-uses!+0x754>
    5d88:      	b	0x5d94 <_stogir.placement.early-with-uses!+0x75c>
    5d8c:      	b	0x5d98 <_stogir.placement.early-with-uses!+0x760>
    5d90:      	b	0x5de0 <_stogir.placement.early-with-uses!+0x7a8>
    5d94:      	b	0x5f50 <_stogir.placement.early-with-uses!+0x918>
    5d98:      	ldr	x4, [sp, #0x128]
    5d9c:      	adrp	x16, 0x5000 <_stogir.uses.build+0x460>
		0000000000005d9c:  ARM64_RELOC_PAGE21	l_stogir.429
    5da0:      	ldr	x16, [x16]
		0000000000005da0:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    5da4:      	str	x16, [sp, #0x110]
    5da8:      	mov	x28, #0x18              ; =24
    5dac:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    5db0:      	cmp	x28, #0x0
    5db4:      	b.ne	0x608c <_stogir.placement.early-with-uses!+0xa54>
    5db8:      	ldr	x0, [x21]
    5dbc:      	add	x0, x0, x24, lsl #2
    5dc0:      	str	w23, [x0]
    5dc4:      	ldr	x20, [sp, #0x120]
    5dc8:      	ldr	x0, [x20]
    5dcc:      	add	x0, x0, x24, lsl #4
    5dd0:      	ldr	x23, [x0]
    5dd4:      	ldr	x24, [x0, #0x8]
    5dd8:      	movz	x25, #0x0, lsl #48
    5ddc:      	b	0x5b58 <_stogir.placement.early-with-uses!+0x520>
    5de0:      	sxtw	x1, w1
    5de4:      	cmp	x1, #0x0
    5de8:      	b.le	0x6094 <_stogir.placement.early-with-uses!+0xa5c>
    5dec:      	sxtw	x23, w23
    5df0:      	ldr	x0, [x21]
    5df4:      	add	x0, x0, x1, lsl #2
    5df8:      	ldr	w0, [x0]
    5dfc:      	sxtw	x0, w0
    5e00:      	mov	x2, x0
    5e04:      	movz	x1, #0x0, lsl #48
    5e08:      	movz	x3, #0x0, lsl #48
    5e0c:      	b	0x5e24 <_stogir.placement.early-with-uses!+0x7ec>
    5e10:      	mov	x2, x5
    5e14:      	b	0x5e20 <_stogir.placement.early-with-uses!+0x7e8>
    5e18:      	ldr	x4, [sp, #0x128]
    5e1c:      	mov	x1, #0x1                ; =1
    5e20:      	str	x4, [sp, #0x128]
    5e24:      	cmp	x1, #0x0
    5e28:      	b.ne	0x609c <_stogir.placement.early-with-uses!+0xa64>
    5e2c:      	cmp	x2, #0x0
    5e30:      	b.le	0x5e18 <_stogir.placement.early-with-uses!+0x7e0>
    5e34:      	ldr	x4, [sp, #0x128]
    5e38:      	ldr	x5, [x4, #0x8]
    5e3c:      	cmp	x2, x5
    5e40:      	b.ge	0x5e1c <_stogir.placement.early-with-uses!+0x7e4>
    5e44:      	ldr	x5, [x4]
    5e48:      	add	x5, x5, x2, lsl #2
    5e4c:      	ldr	w5, [x5]
    5e50:      	sxtw	x5, w5
    5e54:      	cmp	x5, #0x0
    5e58:      	b.ne	0x5e64 <_stogir.placement.early-with-uses!+0x82c>
    5e5c:      	mov	x1, #0x1                ; =1
    5e60:      	b	0x5e14 <_stogir.placement.early-with-uses!+0x7dc>
    5e64:      	cmp	x2, x23
    5e68:      	b.ne	0x5e88 <_stogir.placement.early-with-uses!+0x850>
    5e6c:      	mov	x1, #0x1                ; =1
    5e70:      	mov	x3, #0x1                ; =1
    5e74:      	b	0x5e14 <_stogir.placement.early-with-uses!+0x7dc>
    5e78:      	cmp	x3, #0x0
    5e7c:      	b.eq	0x5aa8 <_stogir.placement.early-with-uses!+0x470>
    5e80:      	str	x0, [sp, #0x148]
    5e84:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    5e88:      	cmp	x2, x5
    5e8c:      	b.ne	0x5e10 <_stogir.placement.early-with-uses!+0x7d8>
    5e90:      	mov	x1, #0x1                ; =1
    5e94:      	b	0x5e14 <_stogir.placement.early-with-uses!+0x7dc>
    5e98:      	add	x0, sp, #0x20
    5e9c:      	bl	0x5e9c <_stogir.placement.early-with-uses!+0x864>
		0000000000005e9c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    5ea0:      	add	x0, sp, #0x80
    5ea4:      	bl	0x5ea4 <_stogir.placement.early-with-uses!+0x86c>
		0000000000005ea4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    5ea8:      	ldr	x0, [sp, #0x110]
    5eac:      	mov	x1, x28
    5eb0:      	adrp	x2, 0x5000 <_stogir.uses.build+0x460>
		0000000000005eb0:  ARM64_RELOC_PAGE21	l_stogir.426
    5eb4:      	ldr	x2, [x2]
		0000000000005eb4:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    5eb8:      	movz	x3, #0x0, lsl #48
    5ebc:      	bl	0x5ebc <_stogir.placement.early-with-uses!+0x884>
		0000000000005ebc:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    5ec0:      	cmp	x0, #0x0
    5ec4:      	b.eq	0x60a4 <_stogir.placement.early-with-uses!+0xa6c>
    5ec8:      	cmp	x26, #0x0
    5ecc:      	b.le	0x5ee4 <_stogir.placement.early-with-uses!+0x8ac>
    5ed0:      	mov	x1, #0x1                ; =1
    5ed4:      	adrp	x0, 0x5000 <_stogir.uses.build+0x460>
		0000000000005ed4:  ARM64_RELOC_PAGE21	l_stogir.431
    5ed8:      	ldr	x0, [x0]
		0000000000005ed8:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    5edc:      	mov	x28, #0x39              ; =57
    5ee0:      	b	0x5ef0 <_stogir.placement.early-with-uses!+0x8b8>
    5ee4:      	and	x0, x22, #0xffffffff
    5ee8:      	movz	x1, #0x0, lsl #48
    5eec:      	movz	x28, #0x0, lsl #48
    5ef0:      	b	0x5ef8 <_stogir.placement.early-with-uses!+0x8c0>
    5ef4:      	mov	x1, #0x1                ; =1
    5ef8:      	ldr	x2, [sp, #0x108]
    5efc:      	str	x1, [x2]
    5f00:      	str	x0, [x2, #0x8]
    5f04:      	str	x28, [x2, #0x10]
    5f08:      	ldr	x19, [sp, #0x158]
    5f0c:      	ldr	x20, [sp, #0x160]
    5f10:      	ldr	x21, [sp, #0x168]
    5f14:      	ldr	x22, [sp, #0x170]
    5f18:      	ldr	x23, [sp, #0x178]
    5f1c:      	ldr	x24, [sp, #0x180]
    5f20:      	ldr	x25, [sp, #0x188]
    5f24:      	ldr	x26, [sp, #0x190]
    5f28:      	ldr	x27, [sp, #0x198]
    5f2c:      	ldr	x28, [sp, #0x1a0]
    5f30:      	ldr	x29, [sp, #0x10]
    5f34:      	ldr	x30, [sp, #0x18]
    5f38:      	add	sp, sp, #0x1b0
    5f3c:      	ret
    5f40:      	cmp	x23, x3
    5f44:      	b.ne	0x5ab4 <_stogir.placement.early-with-uses!+0x47c>
    5f48:      	mov	x1, #0x1                ; =1
    5f4c:      	b	0x5ab8 <_stogir.placement.early-with-uses!+0x480>
    5f50:      	brk	#0
    5f54:      	b	0x5f50 <_stogir.placement.early-with-uses!+0x918>
    5f58:      	brk	#0
    5f5c:      	b	0x5f58 <_stogir.placement.early-with-uses!+0x920>
    5f60:      	str	x19, [sp, #0x108]
    5f64:      	str	x22, [sp, #0x128]
    5f68:      	str	x24, [sp, #0x120]
    5f6c:      	str	x27, [sp, #0x110]
    5f70:      	b	0x5a98 <_stogir.placement.early-with-uses!+0x460>
    5f74:      	str	x19, [sp, #0x108]
    5f78:      	str	x22, [sp, #0x128]
    5f7c:      	str	x24, [sp, #0x120]
    5f80:      	mov	x19, x2
    5f84:      	str	x27, [sp, #0x110]
    5f88:      	b	0x5808 <_stogir.placement.early-with-uses!+0x1d0>
    5f8c:      	str	x19, [sp, #0x108]
    5f90:      	str	x22, [sp, #0x128]
    5f94:      	mov	x22, x5
    5f98:      	str	x24, [sp, #0x120]
    5f9c:      	mov	x19, x2
    5fa0:      	str	x27, [sp, #0x110]
    5fa4:      	mov	w27, w0
    5fa8:      	b	0x5a50 <_stogir.placement.early-with-uses!+0x418>
    5fac:      	str	x19, [sp, #0x108]
    5fb0:      	str	x22, [sp, #0x128]
    5fb4:      	mov	x22, x5
    5fb8:      	str	x24, [sp, #0x120]
    5fbc:      	mov	x24, x4
    5fc0:      	mov	x19, x2
    5fc4:      	str	x27, [sp, #0x110]
    5fc8:      	mov	w27, w0
    5fcc:      	str	w3, [sp, #0x100]
    5fd0:      	str	x1, [sp, #0x118]
    5fd4:      	b	0x5938 <_stogir.placement.early-with-uses!+0x300>
    5fd8:      	str	x19, [sp, #0x108]
    5fdc:      	str	x22, [sp, #0x128]
    5fe0:      	mov	x22, x5
    5fe4:      	str	x24, [sp, #0x120]
    5fe8:      	mov	x24, x4
    5fec:      	mov	x19, x2
    5ff0:      	str	x27, [sp, #0x110]
    5ff4:      	mov	w27, w0
    5ff8:      	str	w3, [sp, #0x100]
    5ffc:      	str	x1, [sp, #0x118]
    6000:      	b	0x5938 <_stogir.placement.early-with-uses!+0x300>
    6004:      	str	x4, [sp, #0x128]
    6008:      	str	x20, [sp, #0x120]
    600c:      	b	0x5bd0 <_stogir.placement.early-with-uses!+0x598>
    6010:      	str	x4, [sp, #0x128]
    6014:      	str	x20, [sp, #0x120]
    6018:      	b	0x5b4c <_stogir.placement.early-with-uses!+0x514>
    601c:      	str	x4, [sp, #0x128]
    6020:      	str	x20, [sp, #0x120]
    6024:      	b	0x5b4c <_stogir.placement.early-with-uses!+0x514>
    6028:      	str	x4, [sp, #0x128]
    602c:      	str	x20, [sp, #0x120]
    6030:      	mov	x20, x0
    6034:      	b	0x5b30 <_stogir.placement.early-with-uses!+0x4f8>
    6038:      	str	x20, [sp, #0x140]
    603c:      	ldr	x4, [sp, #0x128]
    6040:      	str	x23, [sp, #0x150]
    6044:      	mov	w23, w5
    6048:      	b	0x5db0 <_stogir.placement.early-with-uses!+0x778>
    604c:      	str	x3, [sp, #0x148]
    6050:      	str	x20, [sp, #0x140]
    6054:      	mov	x20, x2
    6058:      	ldr	x4, [sp, #0x128]
    605c:      	str	x23, [sp, #0x150]
    6060:      	str	x1, [sp, #0x138]
    6064:      	str	x0, [sp, #0x130]
    6068:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    606c:      	str	x3, [sp, #0x148]
    6070:      	str	x20, [sp, #0x140]
    6074:      	mov	x20, x2
    6078:      	ldr	x4, [sp, #0x128]
    607c:      	str	x23, [sp, #0x150]
    6080:      	str	x1, [sp, #0x138]
    6084:      	str	x0, [sp, #0x130]
    6088:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    608c:      	str	x4, [sp, #0x128]
    6090:      	b	0x5be0 <_stogir.placement.early-with-uses!+0x5a8>
    6094:      	ldr	x4, [sp, #0x128]
    6098:      	b	0x5c8c <_stogir.placement.early-with-uses!+0x654>
    609c:      	ldr	x4, [sp, #0x128]
    60a0:      	b	0x5e78 <_stogir.placement.early-with-uses!+0x840>
    60a4:      	ldr	x0, [sp, #0x110]
    60a8:      	b	0x5ef4 <_stogir.placement.early-with-uses!+0x8bc>

00000000000060ac <_coil.core.Eq$slice<u8>$=>:
    60ac:      	sub	sp, sp, #0x10
    60b0:      	str	x29, [sp]
    60b4:      	str	x30, [sp, #0x8]
    60b8:      	mov	x29, sp
    60bc:      	cmp	x1, x3
    60c0:      	b.ne	0x60fc <_coil.core.Eq$slice<u8>$=+0x50>
    60c4:      	cmp	x1, #0x0
    60c8:      	b.ne	0x60d4 <_coil.core.Eq$slice<u8>$=+0x28>
    60cc:      	mov	x0, #0x1                ; =1
    60d0:      	b	0x60f8 <_coil.core.Eq$slice<u8>$=+0x4c>
    60d4:      	lsr	x1, x1, #0
    60d8:      	fmov	d31, x1
    60dc:      	mov	x1, x2
    60e0:      	fmov	x2, d31
    60e4:      	bl	0x60e4 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000060e4:  ARM64_RELOC_BRANCH26	_memcmp
    60e8:      	sxtw	x0, w0
    60ec:      	cmp	x0, #0x0
    60f0:      	cset	w0, eq
    60f4:      	ubfx	x0, x0, #0, #8
    60f8:      	b	0x6100 <_coil.core.Eq$slice<u8>$=+0x54>
    60fc:      	movz	x0, #0x0, lsl #48
    6100:      	ldr	x29, [sp]
    6104:      	ldr	x30, [sp, #0x8]
    6108:      	add	sp, sp, #0x10
    610c:      	ret

0000000000006110 <_stogir.placement.late-with-uses!>:
    6110:      	sub	sp, sp, #0x1e0
    6114:      	str	x29, [sp]
    6118:      	str	x30, [sp, #0x8]
    611c:      	mov	x29, sp
    6120:      	str	x19, [sp, #0x190]
    6124:      	str	x20, [sp, #0x198]
    6128:      	str	x21, [sp, #0x1a0]
    612c:      	str	x22, [sp, #0x1a8]
    6130:      	str	x23, [sp, #0x1b0]
    6134:      	str	x24, [sp, #0x1b8]
    6138:      	str	x25, [sp, #0x1c0]
    613c:      	str	x26, [sp, #0x1c8]
    6140:      	str	x27, [sp, #0x1d0]
    6144:      	str	x28, [sp, #0x1d8]
    6148:      	mov	x19, x8
    614c:      	add	x8, sp, #0x40
    6150:      	mov	x20, x0
    6154:      	mov	x0, x6
    6158:      	mov	x21, x1
    615c:      	mov	x22, x2
    6160:      	mov	x23, x3
    6164:      	mov	x24, x4
    6168:      	mov	x25, x5
    616c:      	mov	x26, x6
    6170:      	bl	0x6170 <_stogir.placement.late-with-uses!+0x60>
		0000000000006170:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    6174:      	add	x16, sp, #0x40
    6178:      	ldr	x0, [x16]
    617c:      	add	x16, sp, #0x10
    6180:      	str	x0, [x16]
    6184:      	add	x16, sp, #0x40
    6188:      	ldr	x0, [x16, #0x8]
    618c:      	add	x16, sp, #0x10
    6190:      	str	x0, [x16, #0x8]
    6194:      	add	x16, sp, #0x40
    6198:      	ldr	x0, [x16, #0x10]
    619c:      	add	x16, sp, #0x10
    61a0:      	str	x0, [x16, #0x10]
    61a4:      	add	x16, sp, #0x40
    61a8:      	ldr	x0, [x16, #0x18]
    61ac:      	add	x16, sp, #0x10
    61b0:      	str	x0, [x16, #0x18]
    61b4:      	add	x16, sp, #0x40
    61b8:      	ldr	x0, [x16, #0x20]
    61bc:      	add	x16, sp, #0x10
    61c0:      	str	x0, [x16, #0x20]
    61c4:      	add	x8, sp, #0xa0
    61c8:      	mov	x0, x26
    61cc:      	bl	0x61cc <_stogir.placement.late-with-uses!+0xbc>
		00000000000061cc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    61d0:      	add	x16, sp, #0xa0
    61d4:      	ldr	x0, [x16]
    61d8:      	add	x16, sp, #0x70
    61dc:      	str	x0, [x16]
    61e0:      	add	x16, sp, #0xa0
    61e4:      	ldr	x0, [x16, #0x8]
    61e8:      	add	x16, sp, #0x70
    61ec:      	str	x0, [x16, #0x8]
    61f0:      	add	x16, sp, #0xa0
    61f4:      	ldr	x0, [x16, #0x10]
    61f8:      	add	x16, sp, #0x70
    61fc:      	str	x0, [x16, #0x10]
    6200:      	add	x16, sp, #0xa0
    6204:      	ldr	x0, [x16, #0x18]
    6208:      	add	x16, sp, #0x70
    620c:      	str	x0, [x16, #0x18]
    6210:      	add	x16, sp, #0xa0
    6214:      	ldr	x0, [x16, #0x20]
    6218:      	add	x16, sp, #0x70
    621c:      	str	x0, [x16, #0x20]
    6220:      	movz	x26, #0x0, lsl #48
    6224:      	b	0x623c <_stogir.placement.late-with-uses!+0x12c>
    6228:      	add	x26, x26, #0x1
    622c:      	add	x0, sp, #0x10
    6230:      	mov	x1, #0xffff             ; =65535
    6234:      	movk	x1, #0xffff, lsl #16
    6238:      	bl	0x6238 <_stogir.placement.late-with-uses!+0x128>
		0000000000006238:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    623c:      	ldr	x0, [x20, #0x8]
    6240:      	cmp	x26, x0
    6244:      	b.lt	0x6228 <_stogir.placement.late-with-uses!+0x118>
    6248:      	add	x26, x20, #0x78
    624c:      	mov	x27, #0x1               ; =1
    6250:      	movz	x28, #0x0, lsl #48
    6254:      	b	0x6290 <_stogir.placement.late-with-uses!+0x180>
    6258:      	add	x28, x28, #0x1
    625c:      	add	x0, sp, #0x10
    6260:      	mov	x1, x27
    6264:      	movz	x2, #0x0, lsl #48
    6268:      	bl	0x6268 <_stogir.placement.late-with-uses!+0x158>
		0000000000006268:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    626c:      	sxtw	x28, w28
    6270:      	sxtw	x23, w23
    6274:      	add	x0, x23, #0x4
    6278:      	asr	x16, x0, #63
    627c:      	lsr	x16, x16, #62
    6280:      	add	x0, x0, x16
    6284:      	asr	x0, x0, #2
    6288:      	add	x27, x0, x27
    628c:      	ldr	x23, [sp, #0x110]
    6290:      	ldr	x0, [x20, #0x8]
    6294:      	cmp	x27, x0
    6298:      	b.ge	0x6bc0 <_stogir.placement.late-with-uses!+0xab0>
    629c:      	ldr	x0, [x20]
    62a0:      	add	x0, x0, x27, lsl #4
    62a4:      	ldr	x0, [x0]
    62a8:      	ldr	x1, [x20, #0x78]
    62ac:      	uxtb	w0, w0
    62b0:      	add	x1, x1, x27, lsl #2
    62b4:      	ldr	w1, [x1]
    62b8:      	str	x23, [sp, #0x110]
    62bc:      	mov	w23, w1
    62c0:      	bl	0x62c0 <_stogir.placement.late-with-uses!+0x1b0>
		00000000000062c0:  ARM64_RELOC_BRANCH26	_stogir.opcode.properties
    62c4:      	ldr	x1, [x24]
    62c8:      	add	x1, x27, x1
    62cc:      	ldrb	w1, [x1]
    62d0:      	cmp	x1, #0x0
    62d4:      	b.eq	0x6270 <_stogir.placement.late-with-uses!+0x160>
    62d8:      	uxtb	w0, w0
    62dc:      	uxtb	w16, w0
    62e0:      	and	w0, w16, #0x40
    62e4:      	uxtb	w0, w0
    62e8:      	ubfx	x0, x0, #0, #8
    62ec:      	cmp	x0, #0x0
    62f0:      	b.ne	0x6258 <_stogir.placement.late-with-uses!+0x148>
    62f4:      	b	0x6270 <_stogir.placement.late-with-uses!+0x160>
    62f8:      	mov	x23, #0x1               ; =1
    62fc:      	b	0x6378 <_stogir.placement.late-with-uses!+0x268>
    6300:      	add	x3, x27, #0x1
    6304:      	sxtw	x27, w3
    6308:      	add	x2, x2, #0x1
    630c:      	cmp	x2, x0
    6310:      	b.ge	0x6348 <_stogir.placement.late-with-uses!+0x238>
    6314:      	add	x3, x1, x2
    6318:      	ldr	x4, [x25, #0x28]
    631c:      	add	x3, x4, x3, lsl #3
    6320:      	ldr	x3, [x3]
    6324:      	add	x16, sp, #0x10
    6328:      	ldr	x4, [x16]
    632c:      	sxtw	x3, w3
    6330:      	add	x3, x4, x3, lsl #2
    6334:      	ldr	w3, [x3]
    6338:      	sxtw	x3, w3
    633c:      	cmp	x3, #0x0
    6340:      	b.ge	0x6300 <_stogir.placement.late-with-uses!+0x1f0>
    6344:      	b	0x6308 <_stogir.placement.late-with-uses!+0x1f8>
    6348:      	orr	w0, w27, wzr
    634c:      	mov	x1, x23
    6350:      	mov	w2, w0
    6354:      	add	x0, sp, #0x10
    6358:      	bl	0x6358 <_stogir.placement.late-with-uses!+0x248>
		0000000000006358:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    635c:      	cmp	x27, #0x0
    6360:      	b.ne	0x6374 <_stogir.placement.late-with-uses!+0x264>
    6364:      	orr	w0, w23, wzr
    6368:      	mov	w1, w0
    636c:      	add	x0, sp, #0x70
    6370:      	bl	0x6370 <_stogir.placement.late-with-uses!+0x260>
		0000000000006370:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    6374:      	add	x23, x23, #0x1
    6378:      	add	x16, sp, #0x10
    637c:      	ldr	x0, [x16, #0x8]
    6380:      	cmp	x23, x0
    6384:      	b.ge	0x63c0 <_stogir.placement.late-with-uses!+0x2b0>
    6388:      	add	x16, sp, #0x10
    638c:      	ldr	x0, [x16]
    6390:      	add	x0, x0, x23, lsl #2
    6394:      	ldr	w0, [x0]
    6398:      	sxtw	x0, w0
    639c:      	cmp	x0, #0x0
    63a0:      	b.ne	0x6374 <_stogir.placement.late-with-uses!+0x264>
    63a4:      	ldr	x0, [x25]
    63a8:      	add	x0, x0, x23, lsl #4
    63ac:      	ldr	x1, [x0]
    63b0:      	ldr	x0, [x0, #0x8]
    63b4:      	movz	x2, #0x0, lsl #48
    63b8:      	movz	x27, #0x0, lsl #48
    63bc:      	b	0x630c <_stogir.placement.late-with-uses!+0x1fc>
    63c0:      	add	x16, sp, #0xd0
    63c4:      	orr	x0, x16, xzr
    63c8:      	add	x16, sp, #0xf0
    63cc:      	orr	x1, x16, xzr
    63d0:      	add	x23, x0, #0x8
    63d4:      	add	x27, x1, #0x8
    63d8:      	movz	x0, #0x0, lsl #48
    63dc:      	adrp	x1, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		00000000000063dc:  ARM64_RELOC_PAGE21	l_stogir.432
    63e0:      	ldr	x1, [x1]
		00000000000063e0:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    63e4:      	movz	x2, #0x0, lsl #48
    63e8:      	b	0x6434 <_stogir.placement.late-with-uses!+0x324>
    63ec:      	movz	w6, #0x0, lsl #16
    63f0:      	movz	w5, #0x0, lsl #16
    63f4:      	b	0x67f4 <_stogir.placement.late-with-uses!+0x6e4>
    63f8:      	ldr	x19, [sp, #0x120]
    63fc:      	sub	x0, x19, #0x1
    6400:      	sxtw	x19, w0
    6404:      	ldr	x0, [sp, #0x150]
    6408:      	add	x0, x0, #0x1
    640c:      	mov	x20, x27
    6410:      	ldr	x21, [sp, #0x188]
    6414:      	ldr	x24, [sp, #0x130]
    6418:      	ldr	x25, [sp, #0x148]
    641c:      	ldr	x27, [sp, #0x160]
    6420:      	mov	x1, x28
    6424:      	mov	x28, x19
    6428:      	ldr	x19, [sp, #0x118]
    642c:      	mov	x2, x26
    6430:      	ldr	x26, [sp, #0x128]
    6434:      	str	x19, [sp, #0x118]
    6438:      	mov	x19, x0
    643c:      	mov	x0, x1
    6440:      	str	x28, [sp, #0x120]
    6444:      	mov	x28, x1
    6448:      	mov	x1, x2
    644c:      	str	x26, [sp, #0x128]
    6450:      	mov	x26, x2
    6454:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006454:  ARM64_RELOC_PAGE21	l_stogir.432
    6458:      	ldr	x2, [x2]
		0000000000006458:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    645c:      	movz	x3, #0x0, lsl #48
    6460:      	bl	0x6460 <_stogir.placement.late-with-uses!+0x350>
		0000000000006460:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6464:      	cmp	x0, #0x0
    6468:      	b.eq	0x6484 <_stogir.placement.late-with-uses!+0x374>
    646c:      	add	x0, sp, #0x70
    6470:      	bl	0x6470 <_stogir.placement.late-with-uses!+0x360>
		0000000000006470:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    6474:      	cmp	x19, x0
    6478:      	cset	w0, lt
    647c:      	ubfx	x0, x0, #0, #8
    6480:      	b	0x6488 <_stogir.placement.late-with-uses!+0x378>
    6484:      	movz	x0, #0x0, lsl #48
    6488:      	cmp	x0, #0x0
    648c:      	b.eq	0x6bc8 <_stogir.placement.late-with-uses!+0xab8>
    6490:      	add	x16, sp, #0x70
    6494:      	ldr	x0, [x16]
    6498:      	add	x0, x0, x19, lsl #2
    649c:      	ldr	w0, [x0]
    64a0:      	sxtw	x0, w0
    64a4:      	ldr	x1, [x25]
    64a8:      	add	x1, x1, x0, lsl #4
    64ac:      	ldr	x2, [x1]
    64b0:      	ldr	x1, [x1, #0x8]
    64b4:      	movz	x3, #0x0, lsl #48
    64b8:      	movz	w4, #0x0, lsl #16
    64bc:      	b	0x64f0 <_stogir.placement.late-with-uses!+0x3e0>
    64c0:      	movz	x19, #0x0, lsl #48
    64c4:      	add	x25, x25, #0x1
    64c8:      	ldr	x20, [sp, #0x158]
    64cc:      	mov	x0, x24
    64d0:      	ldr	x24, [sp, #0x130]
    64d4:      	ldr	x2, [sp, #0x138]
    64d8:      	ldr	x1, [sp, #0x140]
    64dc:      	ldr	x27, [sp, #0x160]
    64e0:      	mov	x3, x25
    64e4:      	ldr	x25, [sp, #0x148]
    64e8:      	mov	w4, w19
    64ec:      	ldr	x19, [sp, #0x150]
    64f0:      	cmp	x26, #0x0
    64f4:      	b.ne	0x6508 <_stogir.placement.late-with-uses!+0x3f8>
    64f8:      	cmp	x3, x1
    64fc:      	cset	w5, lt
    6500:      	ubfx	x5, x5, #0, #8
    6504:      	b	0x650c <_stogir.placement.late-with-uses!+0x3fc>
    6508:      	movz	x5, #0x0, lsl #48
    650c:      	sxtw	x6, w4
    6510:      	cmp	x6, #0x0
    6514:      	cset	w7, eq
    6518:      	cmp	x5, #0x0
    651c:      	b.eq	0x6bd0 <_stogir.placement.late-with-uses!+0xac0>
    6520:      	add	x5, x2, x3
    6524:      	ldr	x8, [x25, #0x28]
    6528:      	add	x5, x8, x5, lsl #3
    652c:      	ldr	x5, [x5]
    6530:      	ldr	x8, [x24]
    6534:      	orr	w9, w5, wzr
    6538:      	sxtw	x10, w9
    653c:      	add	x8, x8, x10
    6540:      	ldrb	w8, [x8]
    6544:      	cmp	x8, #0x0
    6548:      	b.eq	0x6bf4 <_stogir.placement.late-with-uses!+0xae4>
    654c:      	lsr	x5, x5, #32
    6550:      	add	x8, sp, #0xd0
    6554:      	str	x2, [sp, #0x138]
    6558:      	mov	w2, w9
    655c:      	str	x1, [sp, #0x140]
    6560:      	mov	x1, x21
    6564:      	str	x24, [sp, #0x130]
    6568:      	mov	x24, x0
    656c:      	mov	x0, x20
    6570:      	str	x25, [sp, #0x148]
    6574:      	mov	x25, x3
    6578:      	mov	w3, w5
    657c:      	str	x19, [sp, #0x150]
    6580:      	mov	w19, w4
    6584:      	str	x20, [sp, #0x158]
    6588:      	mov	x20, x6
    658c:      	str	x27, [sp, #0x160]
    6590:      	mov	w27, w7
    6594:      	bl	0x6594 <_stogir.placement.late-with-uses!+0x484>
		0000000000006594:  ARM64_RELOC_BRANCH26	_stogir.placement.use-block
    6598:      	add	x16, sp, #0xd0
    659c:      	ldr	w0, [x16]
    65a0:      	lsr	x16, x0, #0
    65a4:      	cmp	x16, #0x1
    65a8:      	b.eq	0x65c4 <_stogir.placement.late-with-uses!+0x4b4>
    65ac:      	b.lo	0x65b4 <_stogir.placement.late-with-uses!+0x4a4>
    65b0:      	b	0x65c8 <_stogir.placement.late-with-uses!+0x4b8>
    65b4:      	cmp	x16, #0x0
    65b8:      	b.eq	0x65c0 <_stogir.placement.late-with-uses!+0x4b0>
    65bc:      	b	0x65c8 <_stogir.placement.late-with-uses!+0x4b8>
    65c0:      	b	0x65dc <_stogir.placement.late-with-uses!+0x4cc>
    65c4:      	b	0x65cc <_stogir.placement.late-with-uses!+0x4bc>
    65c8:      	b	0x6a78 <_stogir.placement.late-with-uses!+0x968>
    65cc:      	add	x16, sp, #0xd0
    65d0:      	ldr	x28, [x16, #0x8]
    65d4:      	ldr	x26, [x23, #0x8]
    65d8:      	b	0x64c4 <_stogir.placement.late-with-uses!+0x3b4>
    65dc:      	add	x16, sp, #0xd0
    65e0:      	ldr	w0, [x16, #0x8]
    65e4:      	orr	w1, w0, wzr
    65e8:      	uxtb	w16, w27
    65ec:      	cmp	w16, wzr
    65f0:      	b.eq	0x662c <_stogir.placement.late-with-uses!+0x51c>
    65f4:      	mov	w19, w1
    65f8:      	b	0x64c4 <_stogir.placement.late-with-uses!+0x3b4>
    65fc:      	mov	x0, x28
    6600:      	mov	x1, x26
    6604:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006604:  ARM64_RELOC_PAGE21	l_stogir.432
    6608:      	ldr	x2, [x2]
		0000000000006608:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    660c:      	movz	x3, #0x0, lsl #48
    6610:      	bl	0x6610 <_stogir.placement.late-with-uses!+0x500>
		0000000000006610:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    6614:      	cmp	x0, #0x0
    6618:      	b.eq	0x668c <_stogir.placement.late-with-uses!+0x57c>
    661c:      	uxtb	w16, w27
    6620:      	cmp	w16, wzr
    6624:      	cset	x0, eq
    6628:      	b	0x6690 <_stogir.placement.late-with-uses!+0x580>
    662c:      	cmp	x20, #0x0
    6630:      	b.le	0x64c0 <_stogir.placement.late-with-uses!+0x3b0>
    6634:      	sxtw	x0, w0
    6638:      	cmp	x0, #0x0
    663c:      	b.le	0x64c0 <_stogir.placement.late-with-uses!+0x3b0>
    6640:      	ldr	x2, [x22, #0x8]
    6644:      	cmp	x20, x2
    6648:      	b.ge	0x64c0 <_stogir.placement.late-with-uses!+0x3b0>
    664c:      	cmp	x0, x2
    6650:      	b.ge	0x64c0 <_stogir.placement.late-with-uses!+0x3b0>
    6654:      	ldr	x2, [x22]
    6658:      	add	x3, x2, x20, lsl #2
    665c:      	ldr	w3, [x3]
    6660:      	sxtw	x3, w3
    6664:      	cmp	x3, #0x0
    6668:      	b.eq	0x6a70 <_stogir.placement.late-with-uses!+0x960>
    666c:      	add	x0, x2, x0, lsl #2
    6670:      	ldr	w0, [x0]
    6674:      	sxtw	x0, w0
    6678:      	cmp	x0, #0x0
    667c:      	b.eq	0x6a70 <_stogir.placement.late-with-uses!+0x960>
    6680:      	mov	w2, w19
    6684:      	movz	x0, #0x0, lsl #48
    6688:      	b	0x6b88 <_stogir.placement.late-with-uses!+0xa78>
    668c:      	movz	x0, #0x0, lsl #48
    6690:      	lsl	x20, x24, #2
    6694:      	cmp	x0, #0x0
    6698:      	b.eq	0x6c20 <_stogir.placement.late-with-uses!+0xb10>
    669c:      	ldr	x0, [x21]
    66a0:      	add	x0, x20, x0
    66a4:      	ldr	w0, [x0]
    66a8:      	add	x8, sp, #0xf0
    66ac:      	ldr	x1, [sp, #0x110]
    66b0:      	mov	w2, w0
    66b4:      	mov	x0, x22
    66b8:      	mov	w3, w19
    66bc:      	bl	0x66bc <_stogir.placement.late-with-uses!+0x5ac>
		00000000000066bc:  ARM64_RELOC_BRANCH26	_stogir.placement.choose-block
    66c0:      	add	x16, sp, #0xf0
    66c4:      	ldr	w0, [x16]
    66c8:      	lsr	x16, x0, #0
    66cc:      	cmp	x16, #0x1
    66d0:      	b.eq	0x66f0 <_stogir.placement.late-with-uses!+0x5e0>
    66d4:      	b.lo	0x66dc <_stogir.placement.late-with-uses!+0x5cc>
    66d8:      	b	0x66f4 <_stogir.placement.late-with-uses!+0x5e4>
    66dc:      	cmp	x16, #0x0
    66e0:      	b.eq	0x66e8 <_stogir.placement.late-with-uses!+0x5d8>
    66e4:      	b	0x66f4 <_stogir.placement.late-with-uses!+0x5e4>
    66e8:      	ldr	x19, [sp, #0x160]
    66ec:      	b	0x670c <_stogir.placement.late-with-uses!+0x5fc>
    66f0:      	b	0x66f8 <_stogir.placement.late-with-uses!+0x5e8>
    66f4:      	b	0x6bb8 <_stogir.placement.late-with-uses!+0xaa8>
    66f8:      	add	x16, sp, #0xf0
    66fc:      	ldr	x28, [x16, #0x8]
    6700:      	ldr	x19, [sp, #0x160]
    6704:      	ldr	x26, [x19, #0x8]
    6708:      	b	0x6724 <_stogir.placement.late-with-uses!+0x614>
    670c:      	add	x16, sp, #0xf0
    6710:      	ldr	w0, [x16, #0x8]
    6714:      	mov	x1, x24
    6718:      	mov	w2, w0
    671c:      	mov	x0, x21
    6720:      	bl	0x6720 <_stogir.placement.late-with-uses!+0x610>
		0000000000006720:  ARM64_RELOC_BRANCH26	_coil.core.Set$coil.arraylist.ArrayList$set!__i32
    6724:      	mov	x0, x28
    6728:      	mov	x1, x26
    672c:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		000000000000672c:  ARM64_RELOC_PAGE21	l_stogir.432
    6730:      	ldr	x2, [x2]
		0000000000006730:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    6734:      	movz	x3, #0x0, lsl #48
    6738:      	bl	0x6738 <_stogir.placement.late-with-uses!+0x628>
		0000000000006738:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    673c:      	cmp	x0, #0x0
    6740:      	b.eq	0x6c28 <_stogir.placement.late-with-uses!+0xb18>
    6744:      	cmp	x24, #0x0
    6748:      	cset	w25, le
    674c:      	ldr	x27, [sp, #0x158]
    6750:      	ldr	x0, [x27]
    6754:      	add	x0, x0, x24, lsl #4
    6758:      	ldr	x0, [x0]
    675c:      	ldr	x1, [x27, #0x78]
    6760:      	uxtb	w0, w0
    6764:      	add	x1, x1, x24, lsl #2
    6768:      	cmp	x0, #0x83
    676c:      	cset	w2, lt
    6770:      	adrp	x16, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006770:  ARM64_RELOC_PAGE21	l_stogir.433
    6774:      	ldr	x16, [x16]
		0000000000006774:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    6778:      	add	x0, x16, x0, lsl #2
    677c:      	ldr	w1, [x1]
    6780:      	sxtw	x1, w1
    6784:      	mov	x3, #0x1                ; =1
    6788:      	b	0x6874 <_stogir.placement.late-with-uses!+0x764>
    678c:      	sub	w4, w4, #0x1
    6790:      	lsl	w4, w4, #2
    6794:      	ubfx	x4, x4, #0, #32
    6798:      	lsr	x4, x6, x4
    679c:      	and	w4, w4, #0xf
    67a0:      	b	0x67a8 <_stogir.placement.late-with-uses!+0x698>
    67a4:      	movz	w4, #0x0, lsl #16
    67a8:      	b	0x67b4 <_stogir.placement.late-with-uses!+0x6a4>
    67ac:      	nop
    67b0:      	movz	w4, #0x0, lsl #16
    67b4:      	ubfx	x4, x4, #0, #32
    67b8:      	cmp	x4, #0xf
    67bc:      	b.hs	0x6c3c <_stogir.placement.late-with-uses!+0xb2c>
    67c0:      	mov	x16, #0x1               ; =1
    67c4:      	lsl	x4, x16, x4
    67c8:      	mov	w17, #0x5e1c            ; =24092
    67cc:      	and	w4, w4, w17
    67d0:      	ubfx	x4, x4, #0, #32
    67d4:      	cmp	x4, #0x0
    67d8:      	b.eq	0x6c5c <_stogir.placement.late-with-uses!+0xb4c>
    67dc:      	uxtb	w16, w25
    67e0:      	cmp	w16, wzr
    67e4:      	b.eq	0x68ac <_stogir.placement.late-with-uses!+0x79c>
    67e8:      	ldr	x4, [sp, #0x128]
    67ec:      	movz	w6, #0x0, lsl #16
    67f0:      	movz	w5, #0x0, lsl #16
    67f4:      	ubfx	x6, x6, #0, #32
    67f8:      	lsr	x16, x6, #0
    67fc:      	cmp	x16, #0x1
    6800:      	b.eq	0x681c <_stogir.placement.late-with-uses!+0x70c>
    6804:      	b.lo	0x680c <_stogir.placement.late-with-uses!+0x6fc>
    6808:      	b	0x6820 <_stogir.placement.late-with-uses!+0x710>
    680c:      	cmp	x16, #0x0
    6810:      	b.eq	0x6818 <_stogir.placement.late-with-uses!+0x708>
    6814:      	b	0x6820 <_stogir.placement.late-with-uses!+0x710>
    6818:      	b	0x6824 <_stogir.placement.late-with-uses!+0x714>
    681c:      	b	0x68e8 <_stogir.placement.late-with-uses!+0x7d8>
    6820:      	b	0x6bb0 <_stogir.placement.late-with-uses!+0xaa0>
    6824:      	str	x21, [sp, #0x188]
    6828:      	str	x4, [sp, #0x128]
    682c:      	str	x20, [sp, #0x180]
    6830:      	str	x19, [sp, #0x160]
    6834:      	mov	x19, x3
    6838:      	str	x1, [sp, #0x178]
    683c:      	str	w2, [sp, #0x168]
    6840:      	str	x0, [sp, #0x170]
    6844:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006844:  ARM64_RELOC_PAGE21	l_stogir.434
    6848:      	ldr	x28, [x28]
		0000000000006848:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    684c:      	mov	x26, #0x1e              ; =30
    6850:      	add	x0, x19, #0x1
    6854:      	sxtw	x19, w0
    6858:      	ldr	x21, [sp, #0x188]
    685c:      	ldr	x20, [sp, #0x180]
    6860:      	ldr	x1, [sp, #0x178]
    6864:      	ldr	w2, [sp, #0x168]
    6868:      	ldr	x0, [sp, #0x170]
    686c:      	mov	x3, x19
    6870:      	ldr	x19, [sp, #0x160]
    6874:      	cmp	x3, x1
    6878:      	b.gt	0x6c7c <_stogir.placement.late-with-uses!+0xb6c>
    687c:      	orr	w4, w3, wzr
    6880:      	sxtw	x5, w4
    6884:      	uxtb	w16, w2
    6888:      	cmp	w16, wzr
    688c:      	b.eq	0x67b0 <_stogir.placement.late-with-uses!+0x6a0>
    6890:      	ldr	w6, [x0]
    6894:      	cmp	x5, #0x0
    6898:      	b.le	0x67a4 <_stogir.placement.late-with-uses!+0x694>
    689c:      	cmp	x5, #0x4
    68a0:      	b.le	0x678c <_stogir.placement.late-with-uses!+0x67c>
    68a4:      	mov	w4, #0x4                ; =4
    68a8:      	b	0x6790 <_stogir.placement.late-with-uses!+0x680>
    68ac:      	ldr	x4, [x27, #0x8]
    68b0:      	cmp	x24, x4
    68b4:      	b.ge	0x6c88 <_stogir.placement.late-with-uses!+0xb78>
    68b8:      	ldr	x4, [sp, #0x128]
    68bc:      	ldr	x6, [x4, #0x8]
    68c0:      	cmp	x24, x6
    68c4:      	b.ge	0x694c <_stogir.placement.late-with-uses!+0x83c>
    68c8:      	ldr	x6, [x27, #0x78]
    68cc:      	add	x6, x20, x6
    68d0:      	ldr	w6, [x6]
    68d4:      	sxtw	x6, w6
    68d8:      	cmp	x6, #0x0
    68dc:      	cset	w6, ge
    68e0:      	ubfx	x6, x6, #0, #8
    68e4:      	b	0x6950 <_stogir.placement.late-with-uses!+0x840>
    68e8:      	sxtw	x6, w5
    68ec:      	cmp	x6, #0x0
    68f0:      	b.le	0x6c90 <_stogir.placement.late-with-uses!+0xb80>
    68f4:      	add	x16, sp, #0x10
    68f8:      	ldr	x7, [x16]
    68fc:      	add	x8, x7, x6, lsl #2
    6900:      	ldr	w8, [x8]
    6904:      	sxtw	x9, w8
    6908:      	cmp	x9, #0x0
    690c:      	b.le	0x6cb4 <_stogir.placement.late-with-uses!+0xba4>
    6910:      	sub	w8, w8, #0x1
    6914:      	add	x6, x7, x6, lsl #2
    6918:      	str	w8, [x6]
    691c:      	cmp	x9, #0x1
    6920:      	b.ne	0x6cd8 <_stogir.placement.late-with-uses!+0xbc8>
    6924:      	add	x16, sp, #0x70
    6928:      	ldr	x6, [x16, #0x8]
    692c:      	add	x16, sp, #0x70
    6930:      	ldr	x7, [x16, #0x10]
    6934:      	cmp	x6, x7
    6938:      	b.lt	0x6cfc <_stogir.placement.late-with-uses!+0xbec>
    693c:      	cmp	x7, #0x0
    6940:      	b.ne	0x6a80 <_stogir.placement.late-with-uses!+0x970>
    6944:      	mov	x7, #0x2                ; =2
    6948:      	b	0x6a84 <_stogir.placement.late-with-uses!+0x974>
    694c:      	movz	x6, #0x0, lsl #48
    6950:      	b	0x6958 <_stogir.placement.late-with-uses!+0x848>
    6954:      	movz	x6, #0x0, lsl #48
    6958:      	cmp	x6, #0x0
    695c:      	b.eq	0x67ec <_stogir.placement.late-with-uses!+0x6dc>
    6960:      	cmp	x5, #0x1
    6964:      	b.lt	0x63ec <_stogir.placement.late-with-uses!+0x2dc>
    6968:      	ldr	x6, [x27, #0x78]
    696c:      	add	x6, x20, x6
    6970:      	ldr	w6, [x6]
    6974:      	sxtw	x6, w6
    6978:      	cmp	x5, x6
    697c:      	b.gt	0x63ec <_stogir.placement.late-with-uses!+0x2dc>
    6980:      	ldr	x6, [x27]
    6984:      	asr	x16, x5, #63
    6988:      	lsr	x16, x16, #62
    698c:      	add	x7, x5, x16
    6990:      	asr	x7, x7, #2
    6994:      	asr	x16, x5, #63
    6998:      	lsr	x16, x16, #62
    699c:      	add	x5, x5, x16
    69a0:      	and	x5, x5, #0x3
    69a4:      	sub	x5, x5, x16
    69a8:      	add	x7, x7, x24
    69ac:      	add	x6, x6, x7, lsl #4
    69b0:      	add	x5, x6, x5, lsl #2
    69b4:      	ldr	w5, [x5]
    69b8:      	movn	w17, #0x0, lsl #16
    69bc:      	and	w5, w5, w17
    69c0:      	mov	w6, #0x1                ; =1
    69c4:      	b	0x63f4 <_stogir.placement.late-with-uses!+0x2e4>
    69c8:      	add	x0, sp, #0x10
    69cc:      	bl	0x69cc <_stogir.placement.late-with-uses!+0x8bc>
		00000000000069cc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    69d0:      	add	x0, sp, #0x70
    69d4:      	bl	0x69d4 <_stogir.placement.late-with-uses!+0x8c4>
		00000000000069d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    69d8:      	mov	x0, x28
    69dc:      	mov	x1, x26
    69e0:      	adrp	x2, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		00000000000069e0:  ARM64_RELOC_PAGE21	l_stogir.432
    69e4:      	ldr	x2, [x2]
		00000000000069e4:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    69e8:      	movz	x3, #0x0, lsl #48
    69ec:      	bl	0x69ec <_stogir.placement.late-with-uses!+0x8dc>
		00000000000069ec:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    69f0:      	cmp	x0, #0x0
    69f4:      	b.eq	0x6a24 <_stogir.placement.late-with-uses!+0x914>
    69f8:      	cmp	x19, #0x0
    69fc:      	b.le	0x6a14 <_stogir.placement.late-with-uses!+0x904>
    6a00:      	mov	x0, #0x1                ; =1
    6a04:      	adrp	x28, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006a04:  ARM64_RELOC_PAGE21	l_stogir.435
    6a08:      	ldr	x28, [x28]
		0000000000006a08:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    6a0c:      	mov	x26, #0x26              ; =38
    6a10:      	b	0x6a20 <_stogir.placement.late-with-uses!+0x910>
    6a14:      	movz	x0, #0x0, lsl #48
    6a18:      	movz	x28, #0x0, lsl #48
    6a1c:      	movz	x26, #0x0, lsl #48
    6a20:      	b	0x6a28 <_stogir.placement.late-with-uses!+0x918>
    6a24:      	mov	x0, #0x1                ; =1
    6a28:      	ldr	x1, [sp, #0x118]
    6a2c:      	str	x0, [x1]
    6a30:      	str	x28, [x1, #0x8]
    6a34:      	str	x26, [x1, #0x10]
    6a38:      	ldr	x19, [sp, #0x190]
    6a3c:      	ldr	x20, [sp, #0x198]
    6a40:      	ldr	x21, [sp, #0x1a0]
    6a44:      	ldr	x22, [sp, #0x1a8]
    6a48:      	ldr	x23, [sp, #0x1b0]
    6a4c:      	ldr	x24, [sp, #0x1b8]
    6a50:      	ldr	x25, [sp, #0x1c0]
    6a54:      	ldr	x26, [sp, #0x1c8]
    6a58:      	ldr	x27, [sp, #0x1d0]
    6a5c:      	ldr	x28, [sp, #0x1d8]
    6a60:      	ldr	x29, [sp]
    6a64:      	ldr	x30, [sp, #0x8]
    6a68:      	add	sp, sp, #0x1e0
    6a6c:      	ret
    6a70:      	movz	x19, #0x0, lsl #48
    6a74:      	b	0x64c4 <_stogir.placement.late-with-uses!+0x3b4>
    6a78:      	brk	#0
    6a7c:      	b	0x6a78 <_stogir.placement.late-with-uses!+0x968>
    6a80:      	lsl	x7, x7, #1
    6a84:      	str	w2, [sp, #0x168]
    6a88:      	str	x0, [sp, #0x170]
    6a8c:      	add	x0, sp, #0x70
    6a90:      	str	x1, [sp, #0x178]
    6a94:      	mov	x1, x7
    6a98:      	str	x4, [sp, #0x128]
    6a9c:      	str	x19, [sp, #0x160]
    6aa0:      	mov	x19, x3
    6aa4:      	str	x20, [sp, #0x180]
    6aa8:      	mov	w20, w5
    6aac:      	str	x21, [sp, #0x188]
    6ab0:      	mov	x21, x6
    6ab4:      	bl	0x6ab4 <_stogir.placement.late-with-uses!+0x9a4>
		0000000000006ab4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    6ab8:      	add	x0, x21, #0x1
    6abc:      	add	x16, sp, #0x70
    6ac0:      	ldr	x1, [x16]
    6ac4:      	add	x1, x1, x21, lsl #2
    6ac8:      	str	w20, [x1]
    6acc:      	add	x16, sp, #0x70
    6ad0:      	str	x0, [x16, #0x8]
    6ad4:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6ad8:      	ldr	x0, [x22]
    6adc:      	orr	x2, x0, xzr
    6ae0:      	add	x2, x2, x19, lsl #2
    6ae4:      	add	x0, x0, x1, lsl #2
    6ae8:      	ldr	w1, [x2]
    6aec:      	orr	w19, w1, wzr
    6af0:      	ldr	w0, [x0]
    6af4:      	orr	w1, w0, wzr
    6af8:      	sxtw	x19, w19
    6afc:      	sxtw	x1, w1
    6b00:      	cmp	x19, x1
    6b04:      	b.eq	0x6a74 <_stogir.placement.late-with-uses!+0x964>
    6b08:      	b	0x6ad8 <_stogir.placement.late-with-uses!+0x9c8>
    6b0c:      	nop
    6b10:      	sxtw	x1, w1
    6b14:      	sub	x2, x2, #0x1
    6b18:      	ldr	x3, [x22]
    6b1c:      	add	x1, x3, x1, lsl #2
    6b20:      	ldr	w1, [x1]
    6b24:      	cmp	x2, x0
    6b28:      	b.gt	0x6b10 <_stogir.placement.late-with-uses!+0xa00>
    6b2c:      	b	0x6af8 <_stogir.placement.late-with-uses!+0x9e8>
    6b30:      	sxtw	x19, w19
    6b34:      	sub	x0, x0, #0x1
    6b38:      	ldr	x3, [x22]
    6b3c:      	add	x3, x3, x19, lsl #2
    6b40:      	ldr	w3, [x3]
    6b44:      	orr	w19, w3, wzr
    6b48:      	cmp	x0, x2
    6b4c:      	b.gt	0x6b30 <_stogir.placement.late-with-uses!+0xa20>
    6b50:      	b	0x6b24 <_stogir.placement.late-with-uses!+0xa14>
    6b54:      	nop
    6b58:      	orr	w3, w4, wzr
    6b5c:      	add	x2, x2, #0x1
    6b60:      	ldr	x4, [x22]
    6b64:      	sxtw	x3, w3
    6b68:      	add	x4, x4, x3, lsl #2
    6b6c:      	ldr	w4, [x4]
    6b70:      	sxtw	x5, w4
    6b74:      	cmp	x3, x5
    6b78:      	b.eq	0x6b48 <_stogir.placement.late-with-uses!+0xa38>
    6b7c:      	b	0x6b58 <_stogir.placement.late-with-uses!+0xa48>
    6b80:      	orr	w2, w3, wzr
    6b84:      	add	x0, x0, #0x1
    6b88:      	ldr	x3, [x22]
    6b8c:      	sxtw	x2, w2
    6b90:      	add	x3, x3, x2, lsl #2
    6b94:      	ldr	w3, [x3]
    6b98:      	sxtw	x4, w3
    6b9c:      	cmp	x2, x4
    6ba0:      	b.ne	0x6b80 <_stogir.placement.late-with-uses!+0xa70>
    6ba4:      	mov	w3, w1
    6ba8:      	movz	x2, #0x0, lsl #48
    6bac:      	b	0x6b60 <_stogir.placement.late-with-uses!+0xa50>
    6bb0:      	brk	#0
    6bb4:      	b	0x6bb0 <_stogir.placement.late-with-uses!+0xaa0>
    6bb8:      	brk	#0
    6bbc:      	b	0x6bb8 <_stogir.placement.late-with-uses!+0xaa8>
    6bc0:      	str	x23, [sp, #0x110]
    6bc4:      	b	0x62f8 <_stogir.placement.late-with-uses!+0x1e8>
    6bc8:      	ldr	x19, [sp, #0x120]
    6bcc:      	b	0x69c8 <_stogir.placement.late-with-uses!+0x8b8>
    6bd0:      	str	x19, [sp, #0x150]
    6bd4:      	str	x20, [sp, #0x158]
    6bd8:      	str	x24, [sp, #0x130]
    6bdc:      	str	x25, [sp, #0x148]
    6be0:      	mov	x24, x0
    6be4:      	str	x27, [sp, #0x160]
    6be8:      	mov	w27, w7
    6bec:      	mov	w19, w4
    6bf0:      	b	0x65fc <_stogir.placement.late-with-uses!+0x4ec>
    6bf4:      	str	x19, [sp, #0x150]
    6bf8:      	str	x20, [sp, #0x158]
    6bfc:      	str	x24, [sp, #0x130]
    6c00:      	str	x25, [sp, #0x148]
    6c04:      	mov	x25, x3
    6c08:      	mov	x24, x0
    6c0c:      	str	x2, [sp, #0x138]
    6c10:      	str	x1, [sp, #0x140]
    6c14:      	str	x27, [sp, #0x160]
    6c18:      	mov	w19, w4
    6c1c:      	b	0x64c4 <_stogir.placement.late-with-uses!+0x3b4>
    6c20:      	ldr	x19, [sp, #0x160]
    6c24:      	b	0x6724 <_stogir.placement.late-with-uses!+0x614>
    6c28:      	ldr	x27, [sp, #0x158]
    6c2c:      	str	x21, [sp, #0x188]
    6c30:      	str	x19, [sp, #0x160]
    6c34:      	ldr	x19, [sp, #0x120]
    6c38:      	b	0x6404 <_stogir.placement.late-with-uses!+0x2f4>
    6c3c:      	str	x21, [sp, #0x188]
    6c40:      	str	x20, [sp, #0x180]
    6c44:      	str	x19, [sp, #0x160]
    6c48:      	mov	x19, x3
    6c4c:      	str	x1, [sp, #0x178]
    6c50:      	str	w2, [sp, #0x168]
    6c54:      	str	x0, [sp, #0x170]
    6c58:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6c5c:      	str	x21, [sp, #0x188]
    6c60:      	str	x20, [sp, #0x180]
    6c64:      	str	x19, [sp, #0x160]
    6c68:      	mov	x19, x3
    6c6c:      	str	x1, [sp, #0x178]
    6c70:      	str	w2, [sp, #0x168]
    6c74:      	str	x0, [sp, #0x170]
    6c78:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6c7c:      	str	x21, [sp, #0x188]
    6c80:      	str	x19, [sp, #0x160]
    6c84:      	b	0x63f8 <_stogir.placement.late-with-uses!+0x2e8>
    6c88:      	ldr	x4, [sp, #0x128]
    6c8c:      	b	0x6954 <_stogir.placement.late-with-uses!+0x844>
    6c90:      	str	x21, [sp, #0x188]
    6c94:      	str	x4, [sp, #0x128]
    6c98:      	str	x20, [sp, #0x180]
    6c9c:      	str	x19, [sp, #0x160]
    6ca0:      	mov	x19, x3
    6ca4:      	str	x1, [sp, #0x178]
    6ca8:      	str	w2, [sp, #0x168]
    6cac:      	str	x0, [sp, #0x170]
    6cb0:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6cb4:      	str	x21, [sp, #0x188]
    6cb8:      	str	x4, [sp, #0x128]
    6cbc:      	str	x20, [sp, #0x180]
    6cc0:      	str	x19, [sp, #0x160]
    6cc4:      	mov	x19, x3
    6cc8:      	str	x1, [sp, #0x178]
    6ccc:      	str	w2, [sp, #0x168]
    6cd0:      	str	x0, [sp, #0x170]
    6cd4:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6cd8:      	str	x21, [sp, #0x188]
    6cdc:      	str	x4, [sp, #0x128]
    6ce0:      	str	x20, [sp, #0x180]
    6ce4:      	str	x19, [sp, #0x160]
    6ce8:      	mov	x19, x3
    6cec:      	str	x1, [sp, #0x178]
    6cf0:      	str	w2, [sp, #0x168]
    6cf4:      	str	x0, [sp, #0x170]
    6cf8:      	b	0x6850 <_stogir.placement.late-with-uses!+0x740>
    6cfc:      	str	x21, [sp, #0x188]
    6d00:      	str	x4, [sp, #0x128]
    6d04:      	str	x20, [sp, #0x180]
    6d08:      	str	x19, [sp, #0x160]
    6d0c:      	mov	x19, x3
    6d10:      	str	x1, [sp, #0x178]
    6d14:      	mov	x21, x6
    6d18:      	str	w2, [sp, #0x168]
    6d1c:      	str	x0, [sp, #0x170]
    6d20:      	mov	w20, w5
    6d24:      	b	0x6ab8 <_stogir.placement.late-with-uses!+0x9a8>

0000000000006d28 <_stogir.checked-schedule.place!>:
    6d28:      	sub	sp, sp, #0x90
    6d2c:      	str	x29, [sp]
    6d30:      	str	x30, [sp, #0x8]
    6d34:      	mov	x29, sp
    6d38:      	str	x19, [sp, #0x40]
    6d3c:      	str	x20, [sp, #0x48]
    6d40:      	str	x21, [sp, #0x50]
    6d44:      	str	x22, [sp, #0x58]
    6d48:      	str	x23, [sp, #0x60]
    6d4c:      	str	x24, [sp, #0x68]
    6d50:      	str	x25, [sp, #0x70]
    6d54:      	str	x26, [sp, #0x78]
    6d58:      	str	x27, [sp, #0x80]
    6d5c:      	str	x28, [sp, #0x88]
    6d60:      	add	x16, sp, #0x20
    6d64:      	orr	x3, x16, xzr
    6d68:      	add	x19, x3, #0x8
    6d6c:      	mov	x20, #0x1               ; =1
    6d70:      	movz	x21, #0x0, lsl #48
    6d74:      	adrp	x22, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006d74:  ARM64_RELOC_PAGE21	l_stogir.436
    6d78:      	ldr	x22, [x22]
		0000000000006d78:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    6d7c:      	movz	x23, #0x0, lsl #48
    6d80:      	b	0x6dc0 <_stogir.checked-schedule.place!+0x98>
    6d84:      	nop
    6d88:      	add	x16, sp, #0x20
    6d8c:      	ldr	x22, [x16, #0x8]
    6d90:      	ldr	x23, [x19, #0x8]
    6d94:      	sxtw	x24, w24
    6d98:      	add	x0, x24, #0x4
    6d9c:      	asr	x16, x0, #63
    6da0:      	lsr	x16, x16, #62
    6da4:      	add	x0, x0, x16
    6da8:      	asr	x0, x0, #2
    6dac:      	add	x20, x0, x20
    6db0:      	mov	x8, x25
    6db4:      	mov	x0, x26
    6db8:      	mov	x1, x27
    6dbc:      	mov	x2, x28
    6dc0:      	cmp	x23, #0x0
    6dc4:      	b.ne	0x6f38 <_stogir.checked-schedule.place!+0x210>
    6dc8:      	ldr	x3, [x0, #0x8]
    6dcc:      	cmp	x20, x3
    6dd0:      	b.ge	0x6f40 <_stogir.checked-schedule.place!+0x218>
    6dd4:      	ldr	x3, [x0]
    6dd8:      	add	x3, x3, x20, lsl #4
    6ddc:      	ldr	x4, [x3]
    6de0:      	uxtb	w5, w4
    6de4:      	ldr	x3, [x3, #0x8]
    6de8:      	add	x16, sp, #0x10
    6dec:      	str	x4, [x16]
    6df0:      	add	x16, sp, #0x10
    6df4:      	str	x3, [x16, #0x8]
    6df8:      	ldr	x3, [x0, #0x78]
    6dfc:      	add	x3, x3, x20, lsl #2
    6e00:      	ldr	w24, [x3]
    6e04:      	cmp	x5, #0x2c
    6e08:      	b.ne	0x6f48 <_stogir.checked-schedule.place!+0x220>
    6e0c:      	ldr	x3, [x2]
    6e10:      	add	x3, x20, x3
    6e14:      	ldrb	w3, [x3]
    6e18:      	cmp	x3, #0x0
    6e1c:      	b.eq	0x6f5c <_stogir.checked-schedule.place!+0x234>
    6e20:      	orr	w3, w20, wzr
    6e24:      	mov	x25, x8
    6e28:      	add	x8, sp, #0x20
    6e2c:      	mov	x26, x0
    6e30:      	mov	x27, x1
    6e34:      	mov	w1, w3
    6e38:      	mov	x28, x2
    6e3c:      	bl	0x6e3c <_stogir.checked-schedule.place!+0x114>
		0000000000006e3c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    6e40:      	add	x16, sp, #0x20
    6e44:      	ldr	w0, [x16]
    6e48:      	lsr	x16, x0, #0
    6e4c:      	cmp	x16, #0x1
    6e50:      	b.eq	0x6e6c <_stogir.checked-schedule.place!+0x144>
    6e54:      	b.lo	0x6e5c <_stogir.checked-schedule.place!+0x134>
    6e58:      	b	0x6e70 <_stogir.checked-schedule.place!+0x148>
    6e5c:      	cmp	x16, #0x0
    6e60:      	b.eq	0x6e68 <_stogir.checked-schedule.place!+0x140>
    6e64:      	b	0x6e70 <_stogir.checked-schedule.place!+0x148>
    6e68:      	b	0x6e74 <_stogir.checked-schedule.place!+0x14c>
    6e6c:      	b	0x6d88 <_stogir.checked-schedule.place!+0x60>
    6e70:      	b	0x6f30 <_stogir.checked-schedule.place!+0x208>
    6e74:      	add	x16, sp, #0x20
    6e78:      	ldr	w0, [x16, #0x8]
    6e7c:      	sxtw	x0, w0
    6e80:      	cmp	x0, #0x0
    6e84:      	b.eq	0x6f2c <_stogir.checked-schedule.place!+0x204>
    6e88:      	add	x16, sp, #0x10
    6e8c:      	ldr	w0, [x16, #0x4]
    6e90:      	sxtw	x0, w0
    6e94:      	ldr	x1, [x27]
    6e98:      	add	x0, x1, x0, lsl #2
    6e9c:      	ldr	w0, [x0]
    6ea0:      	sxtw	x2, w0
    6ea4:      	cmp	x2, #0x0
    6ea8:      	b.gt	0x6f1c <_stogir.checked-schedule.place!+0x1f4>
    6eac:      	adrp	x22, 0x6000 <_stogir.placement.early-with-uses!+0x9c8>
		0000000000006eac:  ARM64_RELOC_PAGE21	l_stogir.437
    6eb0:      	ldr	x22, [x22]
		0000000000006eb0:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    6eb4:      	mov	x23, #0x21              ; =33
    6eb8:      	b	0x6f2c <_stogir.checked-schedule.place!+0x204>
    6ebc:      	cmp	x23, #0x0
    6ec0:      	b.ne	0x6ed4 <_stogir.checked-schedule.place!+0x1ac>
    6ec4:      	and	x22, x21, #0xffffffff
    6ec8:      	movz	x0, #0x0, lsl #48
    6ecc:      	movz	x23, #0x0, lsl #48
    6ed0:      	b	0x6ed8 <_stogir.checked-schedule.place!+0x1b0>
    6ed4:      	mov	x0, #0x1                ; =1
    6ed8:      	str	x0, [x25]
    6edc:      	str	x22, [x25, #0x8]
    6ee0:      	str	x23, [x25, #0x10]
    6ee4:      	ldr	x19, [sp, #0x40]
    6ee8:      	ldr	x20, [sp, #0x48]
    6eec:      	ldr	x21, [sp, #0x50]
    6ef0:      	ldr	x22, [sp, #0x58]
    6ef4:      	ldr	x23, [sp, #0x60]
    6ef8:      	ldr	x24, [sp, #0x68]
    6efc:      	ldr	x25, [sp, #0x70]
    6f00:      	ldr	x26, [sp, #0x78]
    6f04:      	ldr	x27, [sp, #0x80]
    6f08:      	ldr	x28, [sp, #0x88]
    6f0c:      	ldr	x29, [sp]
    6f10:      	ldr	x30, [sp, #0x8]
    6f14:      	add	sp, sp, #0x90
    6f18:      	ret
    6f1c:      	add	x2, x21, #0x1
    6f20:      	add	x1, x1, x20, lsl #2
    6f24:      	sxtw	x21, w2
    6f28:      	str	w0, [x1]
    6f2c:      	b	0x6d94 <_stogir.checked-schedule.place!+0x6c>
    6f30:      	brk	#0
    6f34:      	b	0x6f30 <_stogir.checked-schedule.place!+0x208>
    6f38:      	mov	x25, x8
    6f3c:      	b	0x6ebc <_stogir.checked-schedule.place!+0x194>
    6f40:      	mov	x25, x8
    6f44:      	b	0x6ebc <_stogir.checked-schedule.place!+0x194>
    6f48:      	mov	x25, x8
    6f4c:      	mov	x26, x0
    6f50:      	mov	x27, x1
    6f54:      	mov	x28, x2
    6f58:      	b	0x6d94 <_stogir.checked-schedule.place!+0x6c>
    6f5c:      	mov	x25, x8
    6f60:      	mov	x26, x0
    6f64:      	mov	x27, x1
    6f68:      	mov	x28, x2
    6f6c:      	b	0x6d94 <_stogir.checked-schedule.place!+0x6c>

0000000000006f70 <_stogir.loops.reorder!>:
    6f70:      	sub	sp, sp, #0x2b0
    6f74:      	str	x29, [sp]
    6f78:      	str	x30, [sp, #0x8]
    6f7c:      	mov	x29, sp
    6f80:      	str	x19, [sp, #0x260]
    6f84:      	str	x20, [sp, #0x268]
    6f88:      	str	x21, [sp, #0x270]
    6f8c:      	str	x22, [sp, #0x278]
    6f90:      	str	x23, [sp, #0x280]
    6f94:      	str	x24, [sp, #0x288]
    6f98:      	str	x25, [sp, #0x290]
    6f9c:      	str	x26, [sp, #0x298]
    6fa0:      	str	x27, [sp, #0x2a0]
    6fa4:      	str	x28, [sp, #0x2a8]
    6fa8:      	add	x6, x0, #0x50
    6fac:      	ldr	x7, [x0, #0x50]
    6fb0:      	ldr	x6, [x6, #0x8]
    6fb4:      	orr	x19, x7, xzr
    6fb8:      	orr	x20, x6, xzr
    6fbc:      	movz	x21, #0x0, lsl #48
    6fc0:      	movz	x22, #0x0, lsl #48
    6fc4:      	b	0x73d4 <_stogir.loops.reorder!+0x464>
    6fc8:      	movz	w0, #0x0, lsl #16
    6fcc:      	movz	x1, #0x0, lsl #48
    6fd0:      	ubfx	x0, x0, #0, #32
    6fd4:      	lsr	x16, x0, #0
    6fd8:      	cmp	x16, #0x1
    6fdc:      	b.eq	0x6ff8 <_stogir.loops.reorder!+0x88>
    6fe0:      	b.lo	0x6fe8 <_stogir.loops.reorder!+0x78>
    6fe4:      	b	0x6ffc <_stogir.loops.reorder!+0x8c>
    6fe8:      	cmp	x16, #0x0
    6fec:      	b.eq	0x6ff4 <_stogir.loops.reorder!+0x84>
    6ff0:      	b	0x6ffc <_stogir.loops.reorder!+0x8c>
    6ff4:      	b	0x7084 <_stogir.loops.reorder!+0x114>
    6ff8:      	b	0x7000 <_stogir.loops.reorder!+0x90>
    6ffc:      	b	0x7aec <_stogir.loops.reorder!+0xb7c>
    7000:      	orr	w0, w1, wzr
    7004:      	asr	x2, x1, #32
    7008:      	add	x16, sp, #0x50
    700c:      	ldr	x3, [x16]
    7010:      	sxtw	x4, w0
    7014:      	orr	x5, x3, xzr
    7018:      	add	x2, x3, x2, lsl #2
    701c:      	add	x3, x5, x4, lsl #2
    7020:      	ldr	w3, [x3]
    7024:      	sxtw	x3, w3
    7028:      	ldr	w2, [x2]
    702c:      	cmp	x3, #0x0
    7030:      	b.lt	0x7064 <_stogir.loops.reorder!+0xf4>
    7034:      	sxtw	x2, w2
    7038:      	cmp	x2, #0x0
    703c:      	b.lt	0x7064 <_stogir.loops.reorder!+0xf4>
    7040:      	cmp	x3, x2
    7044:      	b.lt	0x7064 <_stogir.loops.reorder!+0xf4>
    7048:      	lsr	x1, x1, #32
    704c:      	mov	w2, w0
    7050:      	mov	x0, x26
    7054:      	bl	0x7054 <_stogir.loops.reorder!+0xe4>
		0000000000007054:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    7058:      	cmp	x0, #0x0
    705c:      	b.ne	0x7064 <_stogir.loops.reorder!+0xf4>
    7060:      	movz	x22, #0x0, lsl #48
    7064:      	cmp	x21, x20
    7068:      	b.ge	0x6fc8 <_stogir.loops.reorder!+0x58>
    706c:      	add	x0, x21, #0x1
    7070:      	add	x1, x19, x21, lsl #4
    7074:      	ldr	x1, [x1]
    7078:      	mov	x21, x0
    707c:      	mov	w0, #0x1                ; =1
    7080:      	b	0x6fd0 <_stogir.loops.reorder!+0x60>
    7084:      	cmp	x22, #0x0
    7088:      	b.eq	0x7200 <_stogir.loops.reorder!+0x290>
    708c:      	add	x8, sp, #0x100
    7090:      	ldr	x0, [sp, #0x250]
    7094:      	bl	0x7094 <_stogir.loops.reorder!+0x124>
		0000000000007094:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7098:      	add	x16, sp, #0x100
    709c:      	ldr	x0, [x16]
    70a0:      	add	x16, sp, #0xd0
    70a4:      	str	x0, [x16]
    70a8:      	add	x16, sp, #0x100
    70ac:      	ldr	x0, [x16, #0x8]
    70b0:      	add	x16, sp, #0xd0
    70b4:      	str	x0, [x16, #0x8]
    70b8:      	add	x16, sp, #0x100
    70bc:      	ldr	x0, [x16, #0x10]
    70c0:      	add	x16, sp, #0xd0
    70c4:      	str	x0, [x16, #0x10]
    70c8:      	add	x16, sp, #0x100
    70cc:      	ldr	x0, [x16, #0x18]
    70d0:      	add	x16, sp, #0xd0
    70d4:      	str	x0, [x16, #0x18]
    70d8:      	add	x16, sp, #0x100
    70dc:      	ldr	x0, [x16, #0x20]
    70e0:      	add	x16, sp, #0xd0
    70e4:      	str	x0, [x16, #0x20]
    70e8:      	add	x8, sp, #0x160
    70ec:      	ldr	x0, [sp, #0x250]
    70f0:      	bl	0x70f0 <_stogir.loops.reorder!+0x180>
		00000000000070f0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame
    70f4:      	add	x16, sp, #0x160
    70f8:      	ldr	x0, [x16]
    70fc:      	add	x16, sp, #0x130
    7100:      	str	x0, [x16]
    7104:      	add	x16, sp, #0x160
    7108:      	ldr	x0, [x16, #0x8]
    710c:      	add	x16, sp, #0x130
    7110:      	str	x0, [x16, #0x8]
    7114:      	add	x16, sp, #0x160
    7118:      	ldr	x0, [x16, #0x10]
    711c:      	add	x16, sp, #0x130
    7120:      	str	x0, [x16, #0x10]
    7124:      	add	x16, sp, #0x160
    7128:      	ldr	x0, [x16, #0x18]
    712c:      	add	x16, sp, #0x130
    7130:      	str	x0, [x16, #0x18]
    7134:      	add	x16, sp, #0x160
    7138:      	ldr	x0, [x16, #0x20]
    713c:      	add	x16, sp, #0x130
    7140:      	str	x0, [x16, #0x20]
    7144:      	add	x8, sp, #0x1c0
    7148:      	ldr	x0, [sp, #0x250]
    714c:      	bl	0x714c <_stogir.loops.reorder!+0x1dc>
		000000000000714c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7150:      	add	x16, sp, #0x1c0
    7154:      	ldr	x0, [x16]
    7158:      	add	x16, sp, #0x190
    715c:      	str	x0, [x16]
    7160:      	add	x16, sp, #0x1c0
    7164:      	ldr	x0, [x16, #0x8]
    7168:      	add	x16, sp, #0x190
    716c:      	str	x0, [x16, #0x8]
    7170:      	add	x16, sp, #0x1c0
    7174:      	ldr	x0, [x16, #0x10]
    7178:      	add	x16, sp, #0x190
    717c:      	str	x0, [x16, #0x10]
    7180:      	add	x16, sp, #0x1c0
    7184:      	ldr	x0, [x16, #0x18]
    7188:      	add	x16, sp, #0x190
    718c:      	str	x0, [x16, #0x18]
    7190:      	add	x16, sp, #0x1c0
    7194:      	ldr	x0, [x16, #0x20]
    7198:      	add	x16, sp, #0x190
    719c:      	str	x0, [x16, #0x20]
    71a0:      	ldr	x0, [x28]
    71a4:      	ldr	w19, [x0]
    71a8:      	movn	x0, #0x0, lsl #48
    71ac:      	b	0x71c4 <_stogir.loops.reorder!+0x254>
    71b0:      	add	x16, sp, #0x50
    71b4:      	ldr	x1, [x16]
    71b8:      	add	x1, x1, x0, lsl #2
    71bc:      	movz	w17, #0x0, lsl #16
    71c0:      	str	w17, [x1]
    71c4:      	add	x16, sp, #0x50
    71c8:      	ldr	x1, [x16, #0x8]
    71cc:      	add	x0, x0, #0x1
    71d0:      	cmp	x0, x1
    71d4:      	b.lt	0x71b0 <_stogir.loops.reorder!+0x240>
    71d8:      	add	x0, x25, #0x28
    71dc:      	add	x8, sp, #0x1f0
    71e0:      	bl	0x71e0 <_stogir.loops.reorder!+0x270>
		00000000000071e0:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64
    71e4:      	add	x16, sp, #0x1f0
    71e8:      	ldr	x20, [x16]
    71ec:      	add	x16, sp, #0x1f0
    71f0:      	ldr	x21, [x16, #0x8]
    71f4:      	add	x16, sp, #0x1f0
    71f8:      	ldr	x22, [x16, #0x10]
    71fc:      	b	0x7444 <_stogir.loops.reorder!+0x4d4>
    7200:      	add	x0, sp, #0x50
    7204:      	bl	0x7204 <_stogir.loops.reorder!+0x294>
		0000000000007204:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7208:      	movz	x1, #0x0, lsl #48
    720c:      	movz	x0, #0x0, lsl #48
    7210:      	movz	x2, #0x0, lsl #48
    7214:      	b	0x790c <_stogir.loops.reorder!+0x99c>
    7218:      	movz	w4, #0x0, lsl #16
    721c:      	movz	w5, #0x0, lsl #16
    7220:      	ubfx	x4, x4, #0, #32
    7224:      	lsr	x16, x4, #0
    7228:      	cmp	x16, #0x1
    722c:      	b.eq	0x7248 <_stogir.loops.reorder!+0x2d8>
    7230:      	b.lo	0x7238 <_stogir.loops.reorder!+0x2c8>
    7234:      	b	0x724c <_stogir.loops.reorder!+0x2dc>
    7238:      	cmp	x16, #0x0
    723c:      	b.eq	0x7244 <_stogir.loops.reorder!+0x2d4>
    7240:      	b	0x724c <_stogir.loops.reorder!+0x2dc>
    7244:      	b	0x7298 <_stogir.loops.reorder!+0x328>
    7248:      	b	0x7250 <_stogir.loops.reorder!+0x2e0>
    724c:      	b	0x7ae4 <_stogir.loops.reorder!+0xb74>
    7250:      	sxtw	x5, w5
    7254:      	ldr	x4, [x26]
    7258:      	add	x4, x4, x5, lsl #2
    725c:      	ldr	w4, [x4]
    7260:      	sxtw	x4, w4
    7264:      	cmp	x4, #0x0
    7268:      	b.le	0x7270 <_stogir.loops.reorder!+0x300>
    726c:      	add	x3, x3, #0x1
    7270:      	cmp	x2, x1
    7274:      	b.ge	0x7218 <_stogir.loops.reorder!+0x2a8>
    7278:      	add	x4, x2, #0x1
    727c:      	add	x2, x0, x2, lsl #2
    7280:      	ldr	w2, [x2]
    7284:      	movn	w17, #0x0, lsl #16
    7288:      	and	w5, w2, w17
    728c:      	mov	x2, x4
    7290:      	mov	w4, #0x1                ; =1
    7294:      	b	0x7220 <_stogir.loops.reorder!+0x2b0>
    7298:      	ldr	x0, [x28, #0x8]
    729c:      	cmp	x3, x0
    72a0:      	b.ne	0x72d4 <_stogir.loops.reorder!+0x364>
    72a4:      	add	x8, sp, #0x30
    72a8:      	mov	x0, x24
    72ac:      	bl	0x72ac <_stogir.loops.reorder!+0x33c>
		00000000000072ac:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    72b0:      	add	x16, sp, #0x30
    72b4:      	ldr	x0, [x16]
    72b8:      	add	x16, sp, #0x30
    72bc:      	ldr	x1, [x16, #0x8]
    72c0:      	add	x16, sp, #0x30
    72c4:      	ldr	x2, [x16, #0x10]
    72c8:      	movz	x3, #0x0, lsl #48
    72cc:      	movz	x4, #0x0, lsl #48
    72d0:      	b	0x78d4 <_stogir.loops.reorder!+0x964>
    72d4:      	mov	x1, #0x1                ; =1
    72d8:      	adrp	x0, 0x7000 <_stogir.loops.reorder!+0x90>
		00000000000072d8:  ARM64_RELOC_PAGE21	l_stogir.438
    72dc:      	ldr	x0, [x0]
		00000000000072dc:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    72e0:      	mov	x2, #0x32               ; =50
    72e4:      	b	0x791c <_stogir.loops.reorder!+0x9ac>
    72e8:      	movz	w6, #0x0, lsl #16
    72ec:      	movz	x7, #0x0, lsl #48
    72f0:      	ubfx	x6, x6, #0, #32
    72f4:      	lsr	x16, x6, #0
    72f8:      	cmp	x16, #0x1
    72fc:      	b.eq	0x7334 <_stogir.loops.reorder!+0x3c4>
    7300:      	b.lo	0x7308 <_stogir.loops.reorder!+0x398>
    7304:      	b	0x7338 <_stogir.loops.reorder!+0x3c8>
    7308:      	cmp	x16, #0x0
    730c:      	b.eq	0x7314 <_stogir.loops.reorder!+0x3a4>
    7310:      	b	0x7338 <_stogir.loops.reorder!+0x3c8>
    7314:      	mov	x23, x8
    7318:      	mov	x24, x0
    731c:      	mov	x25, x1
    7320:      	mov	x26, x2
    7324:      	mov	x27, x3
    7328:      	mov	x28, x4
    732c:      	str	x5, [sp, #0x250]
    7330:      	b	0x73f4 <_stogir.loops.reorder!+0x484>
    7334:      	b	0x733c <_stogir.loops.reorder!+0x3cc>
    7338:      	b	0x7adc <_stogir.loops.reorder!+0xb6c>
    733c:      	orr	w6, w7, wzr
    7340:      	ldr	x9, [x2]
    7344:      	sxtw	x10, w6
    7348:      	add	x11, x9, x10, lsl #2
    734c:      	ldr	w11, [x11]
    7350:      	sxtw	x11, w11
    7354:      	cmp	x11, #0x0
    7358:      	b.le	0x7af4 <_stogir.loops.reorder!+0xb84>
    735c:      	lsr	x7, x7, #32
    7360:      	sxtw	x11, w7
    7364:      	add	x9, x9, x11, lsl #2
    7368:      	ldr	w9, [x9]
    736c:      	sxtw	x9, w9
    7370:      	cmp	x9, #0x0
    7374:      	b.le	0x7b14 <_stogir.loops.reorder!+0xba4>
    7378:      	cmp	x10, x11
    737c:      	b.lt	0x7b34 <_stogir.loops.reorder!+0xbc4>
    7380:      	mov	x23, x8
    7384:      	mov	x24, x0
    7388:      	mov	x0, x2
    738c:      	mov	x25, x1
    7390:      	mov	w1, w7
    7394:      	mov	x26, x2
    7398:      	mov	w2, w6
    739c:      	mov	x27, x3
    73a0:      	mov	x28, x4
    73a4:      	str	x5, [sp, #0x250]
    73a8:      	bl	0x73a8 <_stogir.loops.reorder!+0x438>
		00000000000073a8:  ARM64_RELOC_BRANCH26	_stogir.dominators.dominates?
    73ac:      	cmp	x0, #0x0
    73b0:      	b.ne	0x73b8 <_stogir.loops.reorder!+0x448>
    73b4:      	mov	x21, #0x1               ; =1
    73b8:      	mov	x8, x23
    73bc:      	mov	x0, x24
    73c0:      	mov	x1, x25
    73c4:      	mov	x2, x26
    73c8:      	mov	x3, x27
    73cc:      	mov	x4, x28
    73d0:      	ldr	x5, [sp, #0x250]
    73d4:      	cmp	x22, x20
    73d8:      	b.ge	0x72e8 <_stogir.loops.reorder!+0x378>
    73dc:      	add	x6, x22, #0x1
    73e0:      	add	x7, x19, x22, lsl #4
    73e4:      	ldr	x7, [x7]
    73e8:      	mov	x22, x6
    73ec:      	mov	w6, #0x1                ; =1
    73f0:      	b	0x72f0 <_stogir.loops.reorder!+0x380>
    73f4:      	ldr	x0, [x28, #0x8]
    73f8:      	cmp	x0, #0x0
    73fc:      	b.ne	0x7960 <_stogir.loops.reorder!+0x9f0>
    7400:      	movz	x1, #0x0, lsl #48
    7404:      	movz	x0, #0x0, lsl #48
    7408:      	movz	x2, #0x0, lsl #48
    740c:      	b	0x791c <_stogir.loops.reorder!+0x9ac>
    7410:      	lsl	x1, x1, #1
    7414:      	str	x20, [sp, #0x258]
    7418:      	mov	x20, x0
    741c:      	add	x0, sp, #0xd0
    7420:      	bl	0x7420 <_stogir.loops.reorder!+0x4b0>
		0000000000007420:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    7424:      	add	x0, x20, #0x1
    7428:      	add	x16, sp, #0xd0
    742c:      	ldr	x1, [x16]
    7430:      	add	x1, x1, x20, lsl #3
    7434:      	str	x26, [x1]
    7438:      	add	x16, sp, #0xd0
    743c:      	str	x0, [x16, #0x8]
    7440:      	ldr	x20, [sp, #0x258]
    7444:      	cmp	x22, x21
    7448:      	b.ge	0x7468 <_stogir.loops.reorder!+0x4f8>
    744c:      	add	x0, x22, #0x1
    7450:      	add	x1, x20, x22, lsl #3
    7454:      	ldr	x1, [x1]
    7458:      	orr	x26, x1, xzr
    745c:      	mov	x22, x0
    7460:      	mov	w0, #0x1                ; =1
    7464:      	b	0x7470 <_stogir.loops.reorder!+0x500>
    7468:      	movz	w0, #0x0, lsl #16
    746c:      	movz	x26, #0x0, lsl #48
    7470:      	ubfx	x0, x0, #0, #32
    7474:      	lsr	x16, x0, #0
    7478:      	cmp	x16, #0x1
    747c:      	b.eq	0x7498 <_stogir.loops.reorder!+0x528>
    7480:      	b.lo	0x7488 <_stogir.loops.reorder!+0x518>
    7484:      	b	0x749c <_stogir.loops.reorder!+0x52c>
    7488:      	cmp	x16, #0x0
    748c:      	b.eq	0x7494 <_stogir.loops.reorder!+0x524>
    7490:      	b	0x749c <_stogir.loops.reorder!+0x52c>
    7494:      	b	0x74c8 <_stogir.loops.reorder!+0x558>
    7498:      	b	0x74a0 <_stogir.loops.reorder!+0x530>
    749c:      	b	0x7ad4 <_stogir.loops.reorder!+0xb64>
    74a0:      	add	x16, sp, #0xd0
    74a4:      	ldr	x0, [x16, #0x8]
    74a8:      	add	x16, sp, #0xd0
    74ac:      	ldr	x1, [x16, #0x10]
    74b0:      	cmp	x0, x1
    74b4:      	b.lt	0x7b54 <_stogir.loops.reorder!+0xbe4>
    74b8:      	cmp	x1, #0x0
    74bc:      	b.ne	0x7410 <_stogir.loops.reorder!+0x4a0>
    74c0:      	mov	x1, #0x2                ; =2
    74c4:      	b	0x7414 <_stogir.loops.reorder!+0x4a4>
    74c8:      	sxtw	x20, w19
    74cc:      	ldr	x0, [x25]
    74d0:      	add	x0, x0, x20, lsl #4
    74d4:      	ldr	x1, [x0]
    74d8:      	ldr	x0, [x0, #0x8]
    74dc:      	add	x16, sp, #0x210
    74e0:      	str	x1, [x16]
    74e4:      	add	x16, sp, #0x210
    74e8:      	str	x0, [x16, #0x8]
    74ec:      	add	x0, sp, #0xd0
    74f0:      	add	x1, sp, #0x210
    74f4:      	mov	x2, x24
    74f8:      	mov	x3, x27
    74fc:      	bl	0x74fc <_stogir.loops.reorder!+0x58c>
		00000000000074fc:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    7500:      	add	x16, sp, #0x220
    7504:      	movz	x17, #0x0, lsl #48
    7508:      	str	x17, [x16]
    750c:      	add	x16, sp, #0x220
    7510:      	movz	x17, #0x0, lsl #48
    7514:      	str	x17, [x16, #0x8]
    7518:      	add	x16, sp, #0x220
    751c:      	str	w19, [x16]
    7520:      	add	x16, sp, #0x210
    7524:      	ldr	x0, [x16, #0x8]
    7528:      	add	x16, sp, #0x220
    752c:      	str	x0, [x16, #0x8]
    7530:      	add	x16, sp, #0x220
    7534:      	ldr	x1, [x16]
    7538:      	mov	x2, x0
    753c:      	add	x0, sp, #0x130
    7540:      	bl	0x7540 <_stogir.loops.reorder!+0x5d0>
		0000000000007540:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame
    7544:      	add	x16, sp, #0x50
    7548:      	ldr	x0, [x16]
    754c:      	add	x0, x0, x20, lsl #2
    7550:      	mov	w17, #0x1               ; =1
    7554:      	str	w17, [x0]
    7558:      	b	0x75ec <_stogir.loops.reorder!+0x67c>
    755c:      	lsl	x0, x0, #1
    7560:      	mov	x1, x0
    7564:      	add	x0, sp, #0x190
    7568:      	bl	0x7568 <_stogir.loops.reorder!+0x5f8>
		0000000000007568:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    756c:      	add	x0, x19, #0x1
    7570:      	add	x16, sp, #0x190
    7574:      	ldr	x1, [x16]
    7578:      	add	x1, x1, x19, lsl #2
    757c:      	str	w21, [x1]
    7580:      	add	x16, sp, #0x190
    7584:      	str	x0, [x16, #0x8]
    7588:      	add	x16, sp, #0x130
    758c:      	ldr	x0, [x16, #0x8]
    7590:      	cmp	x0, #0x0
    7594:      	b.eq	0x75ec <_stogir.loops.reorder!+0x67c>
    7598:      	sub	x0, x0, #0x1
    759c:      	add	x16, sp, #0x130
    75a0:      	str	x0, [x16, #0x8]
    75a4:      	b	0x75ec <_stogir.loops.reorder!+0x67c>
    75a8:      	lsl	x0, x0, #1
    75ac:      	mov	x1, x0
    75b0:      	add	x0, sp, #0x130
    75b4:      	bl	0x75b4 <_stogir.loops.reorder!+0x644>
		00000000000075b4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    75b8:      	add	x0, x21, #0x1
    75bc:      	add	x16, sp, #0x130
    75c0:      	ldr	x1, [x16]
    75c4:      	add	x1, x1, x21, lsl #4
    75c8:      	str	x20, [x1]
    75cc:      	str	x19, [x1, #0x8]
    75d0:      	add	x16, sp, #0x130
    75d4:      	str	x0, [x16, #0x8]
    75d8:      	add	x16, sp, #0x50
    75dc:      	ldr	x0, [x16]
    75e0:      	add	x0, x0, x26, lsl #2
    75e4:      	mov	w17, #0x1               ; =1
    75e8:      	str	w17, [x0]
    75ec:      	add	x16, sp, #0x130
    75f0:      	ldr	x0, [x16, #0x8]
    75f4:      	cmp	x0, #0x0
    75f8:      	b.le	0x7784 <_stogir.loops.reorder!+0x814>
    75fc:      	add	x16, sp, #0x130
    7600:      	ldr	x1, [x16]
    7604:      	sub	x19, x0, #0x1
    7608:      	add	x0, x1, x19, lsl #4
    760c:      	ldr	x20, [x0]
    7610:      	orr	w21, w20, wzr
    7614:      	ldr	x0, [x0, #0x8]
    7618:      	sxtw	x1, w21
    761c:      	ldr	x2, [x25]
    7620:      	add	x1, x2, x1, lsl #4
    7624:      	ldr	x1, [x1]
    7628:      	cmp	x0, #0x0
    762c:      	b.ne	0x765c <_stogir.loops.reorder!+0x6ec>
    7630:      	add	x16, sp, #0x190
    7634:      	ldr	x0, [x16, #0x8]
    7638:      	orr	x19, x0, xzr
    763c:      	add	x16, sp, #0x190
    7640:      	ldr	x0, [x16, #0x10]
    7644:      	cmp	x19, x0
    7648:      	b.lt	0x756c <_stogir.loops.reorder!+0x5fc>
    764c:      	cmp	x0, #0x0
    7650:      	b.ne	0x755c <_stogir.loops.reorder!+0x5ec>
    7654:      	mov	x0, #0x2                ; =2
    7658:      	b	0x7560 <_stogir.loops.reorder!+0x5f0>
    765c:      	sub	x21, x0, #0x1
    7660:      	add	x16, sp, #0xd0
    7664:      	ldr	x0, [x16]
    7668:      	add	x2, x21, x1
    766c:      	orr	x3, x0, xzr
    7670:      	orr	x4, x0, xzr
    7674:      	add	x3, x3, x1, lsl #3
    7678:      	add	x0, x0, x1, lsl #3
    767c:      	add	x2, x4, x2, lsl #3
    7680:      	ldr	x3, [x3]
    7684:      	ldr	x4, [x24, #0x50]
    7688:      	add	x3, x4, x3, lsl #4
    768c:      	ldr	x3, [x3]
    7690:      	ldr	x2, [x2]
    7694:      	lsr	x22, x3, #32
    7698:      	str	x2, [x0]
    769c:      	sxtw	x26, w22
    76a0:      	add	x0, sp, #0xd0
    76a4:      	mov	x2, x21
    76a8:      	mov	x4, x24
    76ac:      	mov	x5, x27
    76b0:      	movz	x3, #0x0, lsl #48
    76b4:      	bl	0x76b4 <_stogir.loops.reorder!+0x744>
		00000000000076b4:  ARM64_RELOC_BRANCH26	_stogir.loops.sift!
    76b8:      	add	x16, sp, #0x130
    76bc:      	ldr	x0, [x16]
    76c0:      	add	x0, x0, x19, lsl #4
    76c4:      	str	x20, [x0]
    76c8:      	str	x21, [x0, #0x8]
    76cc:      	add	x16, sp, #0x50
    76d0:      	ldr	x0, [x16]
    76d4:      	add	x0, x0, x26, lsl #2
    76d8:      	ldr	w0, [x0]
    76dc:      	sxtw	x0, w0
    76e0:      	cmp	x0, #0x0
    76e4:      	b.ne	0x75ec <_stogir.loops.reorder!+0x67c>
    76e8:      	ldr	x0, [x25]
    76ec:      	add	x0, x0, x26, lsl #4
    76f0:      	ldr	x1, [x0]
    76f4:      	ldr	x0, [x0, #0x8]
    76f8:      	add	x16, sp, #0x230
    76fc:      	str	x1, [x16]
    7700:      	add	x16, sp, #0x230
    7704:      	str	x0, [x16, #0x8]
    7708:      	add	x0, sp, #0xd0
    770c:      	add	x1, sp, #0x230
    7710:      	mov	x2, x24
    7714:      	mov	x3, x27
    7718:      	bl	0x7718 <_stogir.loops.reorder!+0x7a8>
		0000000000007718:  ARM64_RELOC_BRANCH26	_stogir.loops.heapify!
    771c:      	add	x16, sp, #0x240
    7720:      	movz	x17, #0x0, lsl #48
    7724:      	str	x17, [x16]
    7728:      	add	x16, sp, #0x240
    772c:      	movz	x17, #0x0, lsl #48
    7730:      	str	x17, [x16, #0x8]
    7734:      	add	x16, sp, #0x240
    7738:      	str	w22, [x16]
    773c:      	add	x16, sp, #0x230
    7740:      	ldr	x0, [x16, #0x8]
    7744:      	orr	x19, x0, xzr
    7748:      	add	x16, sp, #0x240
    774c:      	str	x19, [x16, #0x8]
    7750:      	add	x16, sp, #0x240
    7754:      	ldr	x20, [x16]
    7758:      	add	x16, sp, #0x130
    775c:      	ldr	x0, [x16, #0x8]
    7760:      	orr	x21, x0, xzr
    7764:      	add	x16, sp, #0x130
    7768:      	ldr	x0, [x16, #0x10]
    776c:      	cmp	x21, x0
    7770:      	b.lt	0x75b8 <_stogir.loops.reorder!+0x648>
    7774:      	cmp	x0, #0x0
    7778:      	b.ne	0x75a8 <_stogir.loops.reorder!+0x638>
    777c:      	mov	x0, #0x2                ; =2
    7780:      	b	0x75ac <_stogir.loops.reorder!+0x63c>
    7784:      	add	x16, sp, #0x190
    7788:      	ldr	x0, [x16, #0x8]
    778c:      	ldr	x1, [x28, #0x8]
    7790:      	cmp	x0, x1
    7794:      	cset	w19, eq
    7798:      	uxtb	w16, w19
    779c:      	cmp	w16, wzr
    77a0:      	b.eq	0x7810 <_stogir.loops.reorder!+0x8a0>
    77a4:      	movn	x0, #0x0, lsl #48
    77a8:      	movz	x20, #0x0, lsl #48
    77ac:      	b	0x77c0 <_stogir.loops.reorder!+0x850>
    77b0:      	mov	x20, #0x1               ; =1
    77b4:      	ldr	x2, [x28]
    77b8:      	add	x2, x2, x0, lsl #2
    77bc:      	str	w1, [x2]
    77c0:      	ldr	x1, [x28, #0x8]
    77c4:      	add	x0, x0, #0x1
    77c8:      	cmp	x0, x1
    77cc:      	b.ge	0x7814 <_stogir.loops.reorder!+0x8a4>
    77d0:      	add	x16, sp, #0x190
    77d4:      	ldr	x1, [x16, #0x8]
    77d8:      	add	x16, sp, #0x190
    77dc:      	ldr	x2, [x16]
    77e0:      	sub	x1, x1, #0x1
    77e4:      	sub	x1, x1, x0
    77e8:      	add	x1, x2, x1, lsl #2
    77ec:      	ldr	w1, [x1]
    77f0:      	ldr	x2, [x28]
    77f4:      	sxtw	x3, w1
    77f8:      	add	x2, x2, x0, lsl #2
    77fc:      	ldr	w2, [x2]
    7800:      	sxtw	x2, w2
    7804:      	cmp	x2, x3
    7808:      	b.eq	0x77b4 <_stogir.loops.reorder!+0x844>
    780c:      	b	0x77b0 <_stogir.loops.reorder!+0x840>
    7810:      	movz	x20, #0x0, lsl #48
    7814:      	add	x0, sp, #0x50
    7818:      	bl	0x7818 <_stogir.loops.reorder!+0x8a8>
		0000000000007818:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    781c:      	add	x0, sp, #0xd0
    7820:      	bl	0x7820 <_stogir.loops.reorder!+0x8b0>
		0000000000007820:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    7824:      	add	x0, sp, #0x130
    7828:      	bl	0x7828 <_stogir.loops.reorder!+0x8b8>
		0000000000007828:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame
    782c:      	add	x0, sp, #0x190
    7830:      	bl	0x7830 <_stogir.loops.reorder!+0x8c0>
		0000000000007830:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    7834:      	uxtb	w16, w19
    7838:      	cmp	w16, wzr
    783c:      	b.eq	0x78fc <_stogir.loops.reorder!+0x98c>
    7840:      	and	x0, x20, #0xff
    7844:      	movz	x1, #0x0, lsl #48
    7848:      	movz	x2, #0x0, lsl #48
    784c:      	b	0x790c <_stogir.loops.reorder!+0x99c>
    7850:      	movz	w5, #0x0, lsl #16
    7854:      	movz	w6, #0x0, lsl #16
    7858:      	ubfx	x5, x5, #0, #32
    785c:      	lsr	x16, x5, #0
    7860:      	cmp	x16, #0x1
    7864:      	b.eq	0x7880 <_stogir.loops.reorder!+0x910>
    7868:      	b.lo	0x7870 <_stogir.loops.reorder!+0x900>
    786c:      	b	0x7884 <_stogir.loops.reorder!+0x914>
    7870:      	cmp	x16, #0x0
    7874:      	b.eq	0x787c <_stogir.loops.reorder!+0x90c>
    7878:      	b	0x7884 <_stogir.loops.reorder!+0x914>
    787c:      	b	0x7910 <_stogir.loops.reorder!+0x9a0>
    7880:      	b	0x7888 <_stogir.loops.reorder!+0x918>
    7884:      	b	0x7acc <_stogir.loops.reorder!+0xb5c>
    7888:      	sxtw	x5, w6
    788c:      	ldr	x7, [x26]
    7890:      	add	x7, x7, x5, lsl #2
    7894:      	ldr	w7, [x7]
    7898:      	sxtw	x7, w7
    789c:      	cmp	x7, #0x0
    78a0:      	b.le	0x78d4 <_stogir.loops.reorder!+0x964>
    78a4:      	ldr	x7, [x28]
    78a8:      	add	x7, x7, x4, lsl #2
    78ac:      	ldr	w7, [x7]
    78b0:      	sxtw	x7, w7
    78b4:      	cmp	x7, x5
    78b8:      	b.eq	0x78c0 <_stogir.loops.reorder!+0x950>
    78bc:      	mov	x3, #0x1                ; =1
    78c0:      	add	x5, x4, #0x1
    78c4:      	ldr	x7, [x28]
    78c8:      	add	x4, x7, x4, lsl #2
    78cc:      	str	w6, [x4]
    78d0:      	mov	x4, x5
    78d4:      	cmp	x2, x1
    78d8:      	b.ge	0x7850 <_stogir.loops.reorder!+0x8e0>
    78dc:      	add	x5, x2, #0x1
    78e0:      	add	x2, x0, x2, lsl #2
    78e4:      	ldr	w2, [x2]
    78e8:      	movn	w17, #0x0, lsl #16
    78ec:      	and	w6, w2, w17
    78f0:      	mov	x2, x5
    78f4:      	mov	w5, #0x1                ; =1
    78f8:      	b	0x7858 <_stogir.loops.reorder!+0x8e8>
    78fc:      	mov	x1, #0x1                ; =1
    7900:      	adrp	x0, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007900:  ARM64_RELOC_PAGE21	l_stogir.439
    7904:      	ldr	x0, [x0]
		0000000000007904:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    7908:      	mov	x2, #0x33               ; =51
    790c:      	b	0x791c <_stogir.loops.reorder!+0x9ac>
    7910:      	and	x0, x3, #0xff
    7914:      	movz	x1, #0x0, lsl #48
    7918:      	movz	x2, #0x0, lsl #48
    791c:      	str	x1, [x23]
    7920:      	str	x0, [x23, #0x8]
    7924:      	str	x2, [x23, #0x10]
    7928:      	ldr	x19, [sp, #0x260]
    792c:      	ldr	x20, [sp, #0x268]
    7930:      	ldr	x21, [sp, #0x270]
    7934:      	ldr	x22, [sp, #0x278]
    7938:      	ldr	x23, [sp, #0x280]
    793c:      	ldr	x24, [sp, #0x288]
    7940:      	ldr	x25, [sp, #0x290]
    7944:      	ldr	x26, [sp, #0x298]
    7948:      	ldr	x27, [sp, #0x2a0]
    794c:      	ldr	x28, [sp, #0x2a8]
    7950:      	ldr	x29, [sp]
    7954:      	ldr	x30, [sp, #0x8]
    7958:      	add	sp, sp, #0x2b0
    795c:      	ret
    7960:      	cmp	x21, #0x0
    7964:      	b.eq	0x79cc <_stogir.loops.reorder!+0xa5c>
    7968:      	add	x8, sp, #0x80
    796c:      	ldr	x0, [sp, #0x250]
    7970:      	bl	0x7970 <_stogir.loops.reorder!+0xa00>
		0000000000007970:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7974:      	add	x16, sp, #0x80
    7978:      	ldr	x0, [x16]
    797c:      	add	x16, sp, #0x50
    7980:      	str	x0, [x16]
    7984:      	add	x16, sp, #0x80
    7988:      	ldr	x0, [x16, #0x8]
    798c:      	add	x16, sp, #0x50
    7990:      	str	x0, [x16, #0x8]
    7994:      	add	x16, sp, #0x80
    7998:      	ldr	x0, [x16, #0x10]
    799c:      	add	x16, sp, #0x50
    79a0:      	str	x0, [x16, #0x10]
    79a4:      	add	x16, sp, #0x80
    79a8:      	ldr	x0, [x16, #0x18]
    79ac:      	add	x16, sp, #0x50
    79b0:      	str	x0, [x16, #0x18]
    79b4:      	add	x16, sp, #0x80
    79b8:      	ldr	x0, [x16, #0x20]
    79bc:      	add	x16, sp, #0x50
    79c0:      	str	x0, [x16, #0x20]
    79c4:      	movn	x19, #0x0, lsl #48
    79c8:      	b	0x7a90 <_stogir.loops.reorder!+0xb20>
    79cc:      	add	x8, sp, #0x10
    79d0:      	mov	x0, x24
    79d4:      	bl	0x79d4 <_stogir.loops.reorder!+0xa64>
		00000000000079d4:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__i32
    79d8:      	add	x16, sp, #0x10
    79dc:      	ldr	x0, [x16]
    79e0:      	add	x16, sp, #0x10
    79e4:      	ldr	x1, [x16, #0x8]
    79e8:      	add	x16, sp, #0x10
    79ec:      	ldr	x2, [x16, #0x10]
    79f0:      	movz	x3, #0x0, lsl #48
    79f4:      	b	0x7270 <_stogir.loops.reorder!+0x300>
    79f8:      	orr	w1, w0, wzr
    79fc:      	ldr	x2, [x28]
    7a00:      	add	x2, x2, x0, lsl #2
    7a04:      	ldr	w2, [x2]
    7a08:      	sxtw	x2, w2
    7a0c:      	add	x16, sp, #0x50
    7a10:      	ldr	x3, [x16]
    7a14:      	add	x2, x3, x2, lsl #2
    7a18:      	str	w1, [x2]
    7a1c:      	ldr	x1, [x28, #0x8]
    7a20:      	add	x0, x0, #0x1
    7a24:      	cmp	x0, x1
    7a28:      	b.lt	0x79f8 <_stogir.loops.reorder!+0xa88>
    7a2c:      	add	x0, x24, #0x50
    7a30:      	add	x8, sp, #0xb0
    7a34:      	bl	0x7a34 <_stogir.loops.reorder!+0xac4>
		0000000000007a34:  ARM64_RELOC_BRANCH26	_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge
    7a38:      	add	x16, sp, #0xb0
    7a3c:      	ldr	x19, [x16]
    7a40:      	add	x16, sp, #0xb0
    7a44:      	ldr	x20, [x16, #0x8]
    7a48:      	add	x16, sp, #0xb0
    7a4c:      	ldr	x21, [x16, #0x10]
    7a50:      	mov	x22, #0x1               ; =1
    7a54:      	b	0x7064 <_stogir.loops.reorder!+0xf4>
    7a58:      	movn	x0, #0x0, lsl #48
    7a5c:      	b	0x7a1c <_stogir.loops.reorder!+0xaac>
    7a60:      	lsl	x0, x0, #1
    7a64:      	mov	x1, x0
    7a68:      	add	x0, sp, #0x50
    7a6c:      	bl	0x7a6c <_stogir.loops.reorder!+0xafc>
		0000000000007a6c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    7a70:      	add	x0, x20, #0x1
    7a74:      	add	x16, sp, #0x50
    7a78:      	ldr	x1, [x16]
    7a7c:      	add	x1, x1, x20, lsl #2
    7a80:      	movn	w17, #0x0, lsl #16
    7a84:      	str	w17, [x1]
    7a88:      	add	x16, sp, #0x50
    7a8c:      	str	x0, [x16, #0x8]
    7a90:      	ldr	x0, [x26, #0x8]
    7a94:      	add	x19, x19, #0x1
    7a98:      	cmp	x19, x0
    7a9c:      	b.ge	0x7a58 <_stogir.loops.reorder!+0xae8>
    7aa0:      	add	x16, sp, #0x50
    7aa4:      	ldr	x0, [x16, #0x8]
    7aa8:      	orr	x20, x0, xzr
    7aac:      	add	x16, sp, #0x50
    7ab0:      	ldr	x0, [x16, #0x10]
    7ab4:      	cmp	x20, x0
    7ab8:      	b.lt	0x7a70 <_stogir.loops.reorder!+0xb00>
    7abc:      	cmp	x0, #0x0
    7ac0:      	b.ne	0x7a60 <_stogir.loops.reorder!+0xaf0>
    7ac4:      	mov	x0, #0x2                ; =2
    7ac8:      	b	0x7a64 <_stogir.loops.reorder!+0xaf4>
    7acc:      	brk	#0
    7ad0:      	b	0x7acc <_stogir.loops.reorder!+0xb5c>
    7ad4:      	brk	#0
    7ad8:      	b	0x7ad4 <_stogir.loops.reorder!+0xb64>
    7adc:      	brk	#0
    7ae0:      	b	0x7adc <_stogir.loops.reorder!+0xb6c>
    7ae4:      	brk	#0
    7ae8:      	b	0x7ae4 <_stogir.loops.reorder!+0xb74>
    7aec:      	brk	#0
    7af0:      	b	0x7aec <_stogir.loops.reorder!+0xb7c>
    7af4:      	mov	x23, x8
    7af8:      	mov	x24, x0
    7afc:      	mov	x25, x1
    7b00:      	mov	x26, x2
    7b04:      	mov	x27, x3
    7b08:      	mov	x28, x4
    7b0c:      	str	x5, [sp, #0x250]
    7b10:      	b	0x73b8 <_stogir.loops.reorder!+0x448>
    7b14:      	mov	x23, x8
    7b18:      	mov	x24, x0
    7b1c:      	mov	x25, x1
    7b20:      	mov	x26, x2
    7b24:      	mov	x27, x3
    7b28:      	mov	x28, x4
    7b2c:      	str	x5, [sp, #0x250]
    7b30:      	b	0x73b8 <_stogir.loops.reorder!+0x448>
    7b34:      	mov	x23, x8
    7b38:      	mov	x24, x0
    7b3c:      	mov	x25, x1
    7b40:      	mov	x26, x2
    7b44:      	mov	x27, x3
    7b48:      	mov	x28, x4
    7b4c:      	str	x5, [sp, #0x250]
    7b50:      	b	0x73b8 <_stogir.loops.reorder!+0x448>
    7b54:      	str	x20, [sp, #0x258]
    7b58:      	mov	x20, x0
    7b5c:      	b	0x7424 <_stogir.loops.reorder!+0x4b4>

0000000000007b60 <_stogir.schedule.order-with-uses>:
    7b60:      	sub	sp, sp, #0x2a0
    7b64:      	str	x29, [sp, #0x10]
    7b68:      	str	x30, [sp, #0x18]
    7b6c:      	add	x29, sp, #0x10
    7b70:      	str	x19, [sp, #0x248]
    7b74:      	str	x20, [sp, #0x250]
    7b78:      	str	x21, [sp, #0x258]
    7b7c:      	str	x22, [sp, #0x260]
    7b80:      	str	x23, [sp, #0x268]
    7b84:      	str	x24, [sp, #0x270]
    7b88:      	str	x25, [sp, #0x278]
    7b8c:      	str	x26, [sp, #0x280]
    7b90:      	str	x27, [sp, #0x288]
    7b94:      	str	x28, [sp, #0x290]
    7b98:      	mov	x19, x8
    7b9c:      	add	x8, sp, #0x50
    7ba0:      	mov	x20, x0
    7ba4:      	mov	x0, x4
    7ba8:      	mov	x21, x1
    7bac:      	mov	x22, x2
    7bb0:      	mov	x23, x3
    7bb4:      	mov	x24, x4
    7bb8:      	bl	0x7bb8 <_stogir.schedule.order-with-uses+0x58>
		0000000000007bb8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7bbc:      	add	x16, sp, #0x50
    7bc0:      	ldr	x0, [x16]
    7bc4:      	add	x16, sp, #0x20
    7bc8:      	str	x0, [x16]
    7bcc:      	add	x16, sp, #0x50
    7bd0:      	ldr	x0, [x16, #0x8]
    7bd4:      	add	x16, sp, #0x20
    7bd8:      	str	x0, [x16, #0x8]
    7bdc:      	add	x16, sp, #0x50
    7be0:      	ldr	x0, [x16, #0x10]
    7be4:      	add	x16, sp, #0x20
    7be8:      	str	x0, [x16, #0x10]
    7bec:      	add	x16, sp, #0x50
    7bf0:      	ldr	x0, [x16, #0x18]
    7bf4:      	add	x16, sp, #0x20
    7bf8:      	str	x0, [x16, #0x18]
    7bfc:      	add	x16, sp, #0x50
    7c00:      	ldr	x0, [x16, #0x20]
    7c04:      	add	x16, sp, #0x20
    7c08:      	str	x0, [x16, #0x20]
    7c0c:      	add	x8, sp, #0xb0
    7c10:      	mov	x0, x24
    7c14:      	bl	0x7c14 <_stogir.schedule.order-with-uses+0xb4>
		0000000000007c14:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7c18:      	add	x16, sp, #0xb0
    7c1c:      	ldr	x0, [x16]
    7c20:      	add	x16, sp, #0x80
    7c24:      	str	x0, [x16]
    7c28:      	add	x16, sp, #0xb0
    7c2c:      	ldr	x0, [x16, #0x8]
    7c30:      	add	x16, sp, #0x80
    7c34:      	str	x0, [x16, #0x8]
    7c38:      	add	x16, sp, #0xb0
    7c3c:      	ldr	x0, [x16, #0x10]
    7c40:      	add	x16, sp, #0x80
    7c44:      	str	x0, [x16, #0x10]
    7c48:      	add	x16, sp, #0xb0
    7c4c:      	ldr	x0, [x16, #0x18]
    7c50:      	add	x16, sp, #0x80
    7c54:      	str	x0, [x16, #0x18]
    7c58:      	add	x16, sp, #0xb0
    7c5c:      	ldr	x0, [x16, #0x20]
    7c60:      	add	x16, sp, #0x80
    7c64:      	str	x0, [x16, #0x20]
    7c68:      	add	x8, sp, #0x110
    7c6c:      	mov	x0, x24
    7c70:      	bl	0x7c70 <_stogir.schedule.order-with-uses+0x110>
		0000000000007c70:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i64
    7c74:      	add	x16, sp, #0x110
    7c78:      	ldr	x0, [x16]
    7c7c:      	add	x16, sp, #0xe0
    7c80:      	str	x0, [x16]
    7c84:      	add	x16, sp, #0x110
    7c88:      	ldr	x0, [x16, #0x8]
    7c8c:      	add	x16, sp, #0xe0
    7c90:      	str	x0, [x16, #0x8]
    7c94:      	add	x16, sp, #0x110
    7c98:      	ldr	x0, [x16, #0x10]
    7c9c:      	add	x16, sp, #0xe0
    7ca0:      	str	x0, [x16, #0x10]
    7ca4:      	add	x16, sp, #0x110
    7ca8:      	ldr	x0, [x16, #0x18]
    7cac:      	add	x16, sp, #0xe0
    7cb0:      	str	x0, [x16, #0x18]
    7cb4:      	add	x16, sp, #0x110
    7cb8:      	ldr	x0, [x16, #0x20]
    7cbc:      	add	x16, sp, #0xe0
    7cc0:      	str	x0, [x16, #0x20]
    7cc4:      	add	x8, sp, #0x170
    7cc8:      	mov	x0, x24
    7ccc:      	bl	0x7ccc <_stogir.schedule.order-with-uses+0x16c>
		0000000000007ccc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$new__i32
    7cd0:      	add	x16, sp, #0x170
    7cd4:      	ldr	x0, [x16]
    7cd8:      	add	x16, sp, #0x140
    7cdc:      	str	x0, [x16]
    7ce0:      	add	x16, sp, #0x170
    7ce4:      	ldr	x0, [x16, #0x8]
    7ce8:      	add	x16, sp, #0x140
    7cec:      	str	x0, [x16, #0x8]
    7cf0:      	add	x16, sp, #0x170
    7cf4:      	ldr	x0, [x16, #0x10]
    7cf8:      	add	x16, sp, #0x140
    7cfc:      	str	x0, [x16, #0x10]
    7d00:      	add	x16, sp, #0x170
    7d04:      	ldr	x0, [x16, #0x18]
    7d08:      	add	x16, sp, #0x140
    7d0c:      	str	x0, [x16, #0x18]
    7d10:      	add	x16, sp, #0x170
    7d14:      	ldr	x0, [x16, #0x20]
    7d18:      	add	x16, sp, #0x140
    7d1c:      	str	x0, [x16, #0x20]
    7d20:      	ldr	x0, [x20, #0x8]
    7d24:      	mov	x1, x0
    7d28:      	add	x0, sp, #0x80
    7d2c:      	bl	0x7d2c <_stogir.schedule.order-with-uses+0x1cc>
		0000000000007d2c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    7d30:      	ldr	x0, [x20, #0x8]
    7d34:      	mov	x1, x0
    7d38:      	add	x0, sp, #0xe0
    7d3c:      	bl	0x7d3c <_stogir.schedule.order-with-uses+0x1dc>
		0000000000007d3c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64
    7d40:      	movz	x25, #0x0, lsl #48
    7d44:      	b	0x7d7c <_stogir.schedule.order-with-uses+0x21c>
    7d48:      	lsl	x0, x0, #1
    7d4c:      	mov	x1, x0
    7d50:      	add	x0, sp, #0x20
    7d54:      	bl	0x7d54 <_stogir.schedule.order-with-uses+0x1f4>
		0000000000007d54:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    7d58:      	add	x25, x25, #0x1
    7d5c:      	add	x0, x26, #0x1
    7d60:      	add	x16, sp, #0x20
    7d64:      	ldr	x1, [x16]
    7d68:      	add	x1, x1, x26, lsl #3
    7d6c:      	movn	x17, #0x0, lsl #48
    7d70:      	str	x17, [x1]
    7d74:      	add	x16, sp, #0x20
    7d78:      	str	x0, [x16, #0x8]
    7d7c:      	ldr	x0, [x20, #0x8]
    7d80:      	cmp	x25, x0
    7d84:      	b.ge	0x7db4 <_stogir.schedule.order-with-uses+0x254>
    7d88:      	add	x16, sp, #0x20
    7d8c:      	ldr	x0, [x16, #0x8]
    7d90:      	orr	x26, x0, xzr
    7d94:      	add	x16, sp, #0x20
    7d98:      	ldr	x0, [x16, #0x10]
    7d9c:      	cmp	x26, x0
    7da0:      	b.lt	0x7d58 <_stogir.schedule.order-with-uses+0x1f8>
    7da4:      	cmp	x0, #0x0
    7da8:      	b.ne	0x7d48 <_stogir.schedule.order-with-uses+0x1e8>
    7dac:      	mov	x0, #0x2                ; =2
    7db0:      	b	0x7d4c <_stogir.schedule.order-with-uses+0x1ec>
    7db4:      	mov	x25, #0x1               ; =1
    7db8:      	adrp	x27, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007db8:  ARM64_RELOC_PAGE21	l_stogir.440
    7dbc:      	ldr	x27, [x27]
		0000000000007dbc:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    7dc0:      	movz	x28, #0x0, lsl #48
    7dc4:      	movz	x26, #0x0, lsl #48
    7dc8:      	b	0x7fe4 <_stogir.schedule.order-with-uses+0x484>
    7dcc:      	add	x16, sp, #0xe0
    7dd0:      	ldr	x0, [x16]
    7dd4:      	orr	x1, x0, xzr
    7dd8:      	add	x1, x1, x19, lsl #3
    7ddc:      	add	x0, x0, x19, lsl #3
    7de0:      	ldr	x1, [x1]
    7de4:      	add	x1, x1, #0x1
    7de8:      	str	x1, [x0]
    7dec:      	sxtw	x27, w27
    7df0:      	cmp	x22, #0x43
    7df4:      	cset	w0, eq
    7df8:      	cmp	x22, #0x83
    7dfc:      	cset	w1, lt
    7e00:      	adrp	x17, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007e00:  ARM64_RELOC_PAGE21	l_stogir.441
    7e04:      	ldr	x17, [x17]
		0000000000007e04:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    7e08:      	add	x2, x22, x17
    7e0c:      	adrp	x16, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007e0c:  ARM64_RELOC_PAGE21	l_stogir.442
    7e10:      	ldr	x16, [x16]
		0000000000007e10:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    7e14:      	add	x3, x16, x22, lsl #2
    7e18:      	orr	x22, x3, xzr
    7e1c:      	mov	x3, #0x1                ; =1
    7e20:      	movz	x4, #0x0, lsl #48
    7e24:      	b	0x7e98 <_stogir.schedule.order-with-uses+0x338>
    7e28:      	movz	w5, #0x0, lsl #16
    7e2c:      	uxtb	w16, w5
    7e30:      	and	w5, w16, #0x2
    7e34:      	uxtb	w5, w5
    7e38:      	ubfx	x5, x5, #0, #8
    7e3c:      	cmp	x5, #0x0
    7e40:      	cset	w5, eq
    7e44:      	uxtb	w16, w5
    7e48:      	cmp	w16, wzr
    7e4c:      	cset	x5, eq
    7e50:      	cmp	x5, #0x0
    7e54:      	b.eq	0x7eb4 <_stogir.schedule.order-with-uses+0x354>
    7e58:      	str	w24, [sp, #0x220]
    7e5c:      	mov	x24, x4
    7e60:      	str	w0, [sp, #0x200]
    7e64:      	str	w1, [sp, #0x208]
    7e68:      	str	x2, [sp, #0x210]
    7e6c:      	str	x22, [sp, #0x218]
    7e70:      	mov	x22, x3
    7e74:      	add	x0, x22, #0x1
    7e78:      	sxtw	x22, w0
    7e7c:      	ldr	w0, [sp, #0x200]
    7e80:      	ldr	w1, [sp, #0x208]
    7e84:      	ldr	x2, [sp, #0x210]
    7e88:      	mov	x3, x22
    7e8c:      	ldr	x22, [sp, #0x218]
    7e90:      	mov	x4, x24
    7e94:      	ldr	w24, [sp, #0x220]
    7e98:      	cmp	x3, x27
    7e9c:      	b.gt	0x8694 <_stogir.schedule.order-with-uses+0xb34>
    7ea0:      	uxtb	w16, w1
    7ea4:      	cmp	w16, wzr
    7ea8:      	b.eq	0x7e28 <_stogir.schedule.order-with-uses+0x2c8>
    7eac:      	ldrb	w5, [x2]
    7eb0:      	b	0x7e2c <_stogir.schedule.order-with-uses+0x2cc>
    7eb4:      	orr	w5, w3, wzr
    7eb8:      	sxtw	x6, w5
    7ebc:      	uxtb	w16, w0
    7ec0:      	cmp	w16, wzr
    7ec4:      	b.eq	0x7ef0 <_stogir.schedule.order-with-uses+0x390>
    7ec8:      	cmp	x6, #0x2
    7ecc:      	b.lt	0x7ef0 <_stogir.schedule.order-with-uses+0x390>
    7ed0:      	str	w24, [sp, #0x220]
    7ed4:      	mov	x24, x4
    7ed8:      	str	w0, [sp, #0x200]
    7edc:      	str	w1, [sp, #0x208]
    7ee0:      	str	x2, [sp, #0x210]
    7ee4:      	str	x22, [sp, #0x218]
    7ee8:      	mov	x22, x3
    7eec:      	b	0x7e74 <_stogir.schedule.order-with-uses+0x314>
    7ef0:      	uxtb	w16, w1
    7ef4:      	cmp	w16, wzr
    7ef8:      	b.eq	0x7f20 <_stogir.schedule.order-with-uses+0x3c0>
    7efc:      	ldr	w7, [x22]
    7f00:      	cmp	x6, #0x0
    7f04:      	b.le	0x7f18 <_stogir.schedule.order-with-uses+0x3b8>
    7f08:      	cmp	x6, #0x4
    7f0c:      	b.le	0x8634 <_stogir.schedule.order-with-uses+0xad4>
    7f10:      	mov	w6, #0x4                ; =4
    7f14:      	b	0x8638 <_stogir.schedule.order-with-uses+0xad8>
    7f18:      	movz	w6, #0x0, lsl #16
    7f1c:      	b	0x7f24 <_stogir.schedule.order-with-uses+0x3c4>
    7f20:      	movz	w6, #0x0, lsl #16
    7f24:      	ubfx	x6, x6, #0, #32
    7f28:      	cmp	x6, #0xf
    7f2c:      	b.hs	0x869c <_stogir.schedule.order-with-uses+0xb3c>
    7f30:      	mov	x16, #0x1               ; =1
    7f34:      	lsl	x6, x16, x6
    7f38:      	mov	w17, #0x5e1c            ; =24092
    7f3c:      	and	w6, w6, w17
    7f40:      	ubfx	x6, x6, #0, #32
    7f44:      	cmp	x6, #0x0
    7f48:      	b.eq	0x86bc <_stogir.schedule.order-with-uses+0xb5c>
    7f4c:      	str	w0, [sp, #0x200]
    7f50:      	mov	x0, x20
    7f54:      	str	w1, [sp, #0x208]
    7f58:      	mov	w1, w24
    7f5c:      	str	x2, [sp, #0x210]
    7f60:      	mov	w2, w5
    7f64:      	str	x22, [sp, #0x218]
    7f68:      	mov	x22, x3
    7f6c:      	str	w24, [sp, #0x220]
    7f70:      	mov	x24, x4
    7f74:      	bl	0x7f74 <_stogir.schedule.order-with-uses+0x414>
		0000000000007f74:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    7f78:      	ubfx	x0, x0, #0, #32
    7f7c:      	lsr	x16, x0, #0
    7f80:      	cmp	x16, #0x1
    7f84:      	b.eq	0x7fa0 <_stogir.schedule.order-with-uses+0x440>
    7f88:      	b.lo	0x7f90 <_stogir.schedule.order-with-uses+0x430>
    7f8c:      	b	0x7fa4 <_stogir.schedule.order-with-uses+0x444>
    7f90:      	cmp	x16, #0x0
    7f94:      	b.eq	0x7f9c <_stogir.schedule.order-with-uses+0x43c>
    7f98:      	b	0x7fa4 <_stogir.schedule.order-with-uses+0x444>
    7f9c:      	b	0x7fa8 <_stogir.schedule.order-with-uses+0x448>
    7fa0:      	b	0x864c <_stogir.schedule.order-with-uses+0xaec>
    7fa4:      	b	0x868c <_stogir.schedule.order-with-uses+0xb2c>
    7fa8:      	adrp	x16, 0x7000 <_stogir.loops.reorder!+0x90>
		0000000000007fa8:  ARM64_RELOC_PAGE21	l_stogir.443
    7fac:      	ldr	x16, [x16]
		0000000000007fac:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    7fb0:      	str	x16, [sp, #0x1f0]
    7fb4:      	mov	x28, #0x19              ; =25
    7fb8:      	b	0x8674 <_stogir.schedule.order-with-uses+0xb14>
    7fbc:      	add	x26, x26, #0x1
    7fc0:      	add	x16, sp, #0x20
    7fc4:      	ldr	x0, [x16]
    7fc8:      	add	x0, x0, x25, lsl #3
    7fcc:      	str	x24, [x0]
    7fd0:      	add	x25, x25, #0x1
    7fd4:      	ldr	x19, [sp, #0x1e8]
    7fd8:      	ldr	x22, [sp, #0x1f8]
    7fdc:      	ldr	x24, [sp, #0x1e0]
    7fe0:      	ldr	x27, [sp, #0x1f0]
    7fe4:      	cmp	x28, #0x0
    7fe8:      	b.ne	0x86dc <_stogir.schedule.order-with-uses+0xb7c>
    7fec:      	add	x16, sp, #0x20
    7ff0:      	ldr	x0, [x16, #0x8]
    7ff4:      	cmp	x25, x0
    7ff8:      	b.ge	0x86f0 <_stogir.schedule.order-with-uses+0xb90>
    7ffc:      	orr	w0, w25, wzr
    8000:      	mov	w1, w0
    8004:      	str	x24, [sp, #0x1e0]
    8008:      	mov	w24, w0
    800c:      	mov	x0, x20
    8010:      	bl	0x8010 <_stogir.schedule.order-with-uses+0x4b0>
		0000000000008010:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
    8014:      	cmp	x0, #0x0
    8018:      	b.eq	0x8704 <_stogir.schedule.order-with-uses+0xba4>
    801c:      	ldr	x0, [x22]
    8020:      	add	x0, x25, x0
    8024:      	ldrb	w0, [x0]
    8028:      	cmp	x0, #0x0
    802c:      	b.eq	0x8714 <_stogir.schedule.order-with-uses+0xbb4>
    8030:      	ldr	x0, [x21]
    8034:      	add	x0, x0, x25, lsl #2
    8038:      	ldr	w0, [x0]
    803c:      	sxtw	x0, w0
    8040:      	ldr	x1, [x20]
    8044:      	add	x1, x1, x25, lsl #4
    8048:      	ldr	x1, [x1]
    804c:      	ldr	x2, [x20, #0x78]
    8050:      	add	x2, x2, x25, lsl #2
    8054:      	ldr	w2, [x2]
    8058:      	cmp	x0, #0x0
    805c:      	b.gt	0x807c <_stogir.schedule.order-with-uses+0x51c>
    8060:      	str	x19, [sp, #0x1e8]
    8064:      	str	x22, [sp, #0x1f8]
    8068:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		0000000000008068:  ARM64_RELOC_PAGE21	l_stogir.444
    806c:      	ldr	x16, [x16]
		000000000000806c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    8070:      	str	x16, [sp, #0x1f0]
    8074:      	mov	x28, #0x19              ; =25
    8078:      	b	0x7fd0 <_stogir.schedule.order-with-uses+0x470>
    807c:      	uxtb	w1, w1
    8080:      	orr	x3, x1, xzr
    8084:      	str	x19, [sp, #0x1e8]
    8088:      	mov	x19, x0
    808c:      	mov	w0, w3
    8090:      	str	x27, [sp, #0x1f0]
    8094:      	mov	w27, w2
    8098:      	str	x22, [sp, #0x1f8]
    809c:      	mov	w22, w1
    80a0:      	bl	0x80a0 <_stogir.schedule.order-with-uses+0x540>
		00000000000080a0:  ARM64_RELOC_BRANCH26	_stogir.opcode.block-end?
    80a4:      	cmp	x0, #0x0
    80a8:      	b.eq	0x7dcc <_stogir.schedule.order-with-uses+0x26c>
    80ac:      	add	x16, sp, #0x80
    80b0:      	ldr	x0, [x16]
    80b4:      	add	x1, x0, x19, lsl #2
    80b8:      	ldr	w1, [x1]
    80bc:      	sxtw	x1, w1
    80c0:      	cmp	x1, #0x0
    80c4:      	b.ne	0x8678 <_stogir.schedule.order-with-uses+0xb18>
    80c8:      	add	x0, x0, x19, lsl #2
    80cc:      	str	w24, [x0]
    80d0:      	b	0x8688 <_stogir.schedule.order-with-uses+0xb28>
    80d4:      	lsl	x3, x3, #1
    80d8:      	str	x0, [sp, #0x228]
    80dc:      	add	x0, sp, #0x140
    80e0:      	str	x6, [sp, #0x1f8]
    80e4:      	str	w19, [sp, #0x230]
    80e8:      	mov	x19, x1
    80ec:      	mov	x1, x3
    80f0:      	str	x20, [sp, #0x238]
    80f4:      	mov	w20, w4
    80f8:      	str	x21, [sp, #0x240]
    80fc:      	mov	x21, x2
    8100:      	bl	0x8100 <_stogir.schedule.order-with-uses+0x5a0>
		0000000000008100:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8104:      	add	x0, x21, #0x1
    8108:      	add	x16, sp, #0x140
    810c:      	ldr	x1, [x16]
    8110:      	add	x1, x1, x21, lsl #2
    8114:      	str	w20, [x1]
    8118:      	add	x16, sp, #0x140
    811c:      	str	x0, [x16, #0x8]
    8120:      	b	0x8298 <_stogir.schedule.order-with-uses+0x738>
    8124:      	mov	x19, #0x1               ; =1
    8128:      	b	0x8160 <_stogir.schedule.order-with-uses+0x600>
    812c:      	nop
    8130:      	lsl	x0, x0, #1
    8134:      	mov	x1, x0
    8138:      	add	x0, sp, #0x140
    813c:      	bl	0x813c <_stogir.schedule.order-with-uses+0x5dc>
		000000000000813c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8140:      	add	x0, x24, #0x1
    8144:      	add	x16, sp, #0x140
    8148:      	ldr	x1, [x16]
    814c:      	add	x1, x1, x24, lsl #2
    8150:      	str	w22, [x1]
    8154:      	add	x16, sp, #0x140
    8158:      	str	x0, [x16, #0x8]
    815c:      	add	x19, x19, #0x1
    8160:      	add	x16, sp, #0x20
    8164:      	ldr	x0, [x16, #0x8]
    8168:      	cmp	x19, x0
    816c:      	b.ge	0x8228 <_stogir.schedule.order-with-uses+0x6c8>
    8170:      	add	x16, sp, #0x20
    8174:      	ldr	x0, [x16]
    8178:      	orr	x1, x0, xzr
    817c:      	add	x2, x1, x19, lsl #3
    8180:      	ldr	x2, [x2]
    8184:      	cmp	x2, #0x0
    8188:      	b.lt	0x815c <_stogir.schedule.order-with-uses+0x5fc>
    818c:      	orr	w22, w19, wzr
    8190:      	ldr	x2, [x21]
    8194:      	sxtw	x3, w22
    8198:      	add	x2, x2, x19, lsl #2
    819c:      	ldr	w2, [x2]
    81a0:      	sxtw	x2, w2
    81a4:      	add	x16, sp, #0x80
    81a8:      	ldr	x4, [x16]
    81ac:      	add	x4, x4, x2, lsl #2
    81b0:      	ldr	w4, [x4]
    81b4:      	sxtw	x4, w4
    81b8:      	cmp	x4, x3
    81bc:      	b.ne	0x81e4 <_stogir.schedule.order-with-uses+0x684>
    81c0:      	add	x1, x1, x19, lsl #3
    81c4:      	add	x0, x0, x19, lsl #3
    81c8:      	ldr	x1, [x1]
    81cc:      	add	x16, sp, #0xe0
    81d0:      	ldr	x3, [x16]
    81d4:      	add	x2, x3, x2, lsl #3
    81d8:      	ldr	x2, [x2]
    81dc:      	add	x1, x2, x1
    81e0:      	str	x1, [x0]
    81e4:      	add	x16, sp, #0x20
    81e8:      	ldr	x0, [x16]
    81ec:      	add	x0, x0, x19, lsl #3
    81f0:      	ldr	x0, [x0]
    81f4:      	cmp	x0, #0x0
    81f8:      	b.ne	0x815c <_stogir.schedule.order-with-uses+0x5fc>
    81fc:      	add	x16, sp, #0x140
    8200:      	ldr	x0, [x16, #0x8]
    8204:      	orr	x24, x0, xzr
    8208:      	add	x16, sp, #0x140
    820c:      	ldr	x0, [x16, #0x10]
    8210:      	cmp	x24, x0
    8214:      	b.lt	0x8140 <_stogir.schedule.order-with-uses+0x5e0>
    8218:      	cmp	x0, #0x0
    821c:      	b.ne	0x8130 <_stogir.schedule.order-with-uses+0x5d0>
    8220:      	mov	x0, #0x2                ; =2
    8224:      	b	0x8134 <_stogir.schedule.order-with-uses+0x5d4>
    8228:      	cmp	x28, #0x0
    822c:      	cset	w19, eq
    8230:      	movz	x22, #0x0, lsl #48
    8234:      	b	0x83e4 <_stogir.schedule.order-with-uses+0x884>
    8238:      	sub	w2, w2, #0x1
    823c:      	lsl	w2, w2, #2
    8240:      	ubfx	x2, x2, #0, #32
    8244:      	lsr	x2, x3, x2
    8248:      	and	w2, w2, #0xf
    824c:      	b	0x8474 <_stogir.schedule.order-with-uses+0x914>
    8250:      	movz	w8, #0x0, lsl #16
    8254:      	uxtb	w16, w8
    8258:      	and	w8, w16, #0x2
    825c:      	uxtb	w8, w8
    8260:      	ubfx	x8, x8, #0, #8
    8264:      	cmp	x8, #0x0
    8268:      	cset	w8, eq
    826c:      	uxtb	w16, w8
    8270:      	cmp	w16, wzr
    8274:      	cset	x8, eq
    8278:      	cmp	x8, #0x0
    827c:      	b.eq	0x8338 <_stogir.schedule.order-with-uses+0x7d8>
    8280:      	str	x20, [sp, #0x238]
    8284:      	str	x21, [sp, #0x240]
    8288:      	str	x6, [sp, #0x1f8]
    828c:      	str	x0, [sp, #0x228]
    8290:      	str	w19, [sp, #0x230]
    8294:      	mov	x19, x1
    8298:      	add	x19, x19, #0x1
    829c:      	ldr	x20, [sp, #0x238]
    82a0:      	ldr	x21, [sp, #0x240]
    82a4:      	ldr	x0, [sp, #0x228]
    82a8:      	mov	x1, x19
    82ac:      	ldr	w19, [sp, #0x230]
    82b0:      	cmp	x1, x0
    82b4:      	b.ge	0x8724 <_stogir.schedule.order-with-uses+0xbc4>
    82b8:      	add	x2, x27, x1
    82bc:      	ldr	x3, [x23, #0x28]
    82c0:      	add	x2, x3, x2, lsl #3
    82c4:      	ldr	x2, [x2]
    82c8:      	ldr	x3, [x20]
    82cc:      	orr	w4, w2, wzr
    82d0:      	sxtw	x5, w4
    82d4:      	add	x3, x3, x5, lsl #4
    82d8:      	ldr	x3, [x3]
    82dc:      	ldr	x6, [sp, #0x1f8]
    82e0:      	ldr	x7, [x6]
    82e4:      	add	x7, x7, x5
    82e8:      	ldrb	w7, [x7]
    82ec:      	cmp	x7, #0x0
    82f0:      	b.eq	0x8734 <_stogir.schedule.order-with-uses+0xbd4>
    82f4:      	ldr	x7, [x21]
    82f8:      	add	x7, x7, x5, lsl #2
    82fc:      	ldr	w7, [x7]
    8300:      	sxtw	x7, w7
    8304:      	cmp	x7, x25
    8308:      	b.ne	0x8750 <_stogir.schedule.order-with-uses+0xbf0>
    830c:      	uxtb	w3, w3
    8310:      	cmp	x3, #0x83
    8314:      	cset	w7, lt
    8318:      	uxtb	w16, w7
    831c:      	cmp	w16, wzr
    8320:      	b.eq	0x8250 <_stogir.schedule.order-with-uses+0x6f0>
    8324:      	adrp	x17, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		0000000000008324:  ARM64_RELOC_PAGE21	l_stogir.441
    8328:      	ldr	x17, [x17]
		0000000000008328:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    832c:      	add	x8, x3, x17
    8330:      	ldrb	w8, [x8]
    8334:      	b	0x8254 <_stogir.schedule.order-with-uses+0x6f4>
    8338:      	lsr	x2, x2, #32
    833c:      	sxtw	x8, w2
    8340:      	cmp	x3, #0x43
    8344:      	b.ne	0x843c <_stogir.schedule.order-with-uses+0x8dc>
    8348:      	cmp	x8, #0x2
    834c:      	b.lt	0x843c <_stogir.schedule.order-with-uses+0x8dc>
    8350:      	str	x20, [sp, #0x238]
    8354:      	str	x21, [sp, #0x240]
    8358:      	str	x6, [sp, #0x1f8]
    835c:      	str	x0, [sp, #0x228]
    8360:      	str	w19, [sp, #0x230]
    8364:      	mov	x19, x1
    8368:      	b	0x8298 <_stogir.schedule.order-with-uses+0x738>
    836c:      	add	x16, sp, #0x80
    8370:      	ldr	x0, [x16]
    8374:      	add	x0, x0, x25, lsl #2
    8378:      	ldr	w0, [x0]
    837c:      	sxtw	x1, w0
    8380:      	cmp	x1, #0x0
    8384:      	b.le	0x83d4 <_stogir.schedule.order-with-uses+0x874>
    8388:      	cmp	x1, x24
    838c:      	b.eq	0x83d4 <_stogir.schedule.order-with-uses+0x874>
    8390:      	add	x16, sp, #0x20
    8394:      	ldr	x2, [x16]
    8398:      	orr	x3, x2, xzr
    839c:      	add	x3, x3, x1, lsl #3
    83a0:      	add	x2, x2, x1, lsl #3
    83a4:      	ldr	x3, [x3]
    83a8:      	sub	x3, x3, #0x1
    83ac:      	str	x3, [x2]
    83b0:      	add	x16, sp, #0x20
    83b4:      	ldr	x2, [x16]
    83b8:      	add	x1, x2, x1, lsl #3
    83bc:      	ldr	x1, [x1]
    83c0:      	cmp	x1, #0x0
    83c4:      	b.ne	0x83d4 <_stogir.schedule.order-with-uses+0x874>
    83c8:      	mov	w1, w0
    83cc:      	add	x0, sp, #0x140
    83d0:      	bl	0x83d0 <_stogir.schedule.order-with-uses+0x870>
		00000000000083d0:  ARM64_RELOC_BRANCH26	_coil.core.Push$coil.arraylist.ArrayList$push!__i32
    83d4:      	add	x22, x22, #0x1
    83d8:      	ldr	x20, [sp, #0x238]
    83dc:      	ldr	x21, [sp, #0x240]
    83e0:      	ldr	w19, [sp, #0x230]
    83e4:      	uxtb	w16, w19
    83e8:      	cmp	w16, wzr
    83ec:      	b.eq	0x876c <_stogir.schedule.order-with-uses+0xc0c>
    83f0:      	add	x16, sp, #0x140
    83f4:      	ldr	x0, [x16, #0x8]
    83f8:      	cmp	x22, x0
    83fc:      	b.ge	0x8774 <_stogir.schedule.order-with-uses+0xc14>
    8400:      	add	x16, sp, #0x140
    8404:      	ldr	x0, [x16]
    8408:      	add	x0, x0, x22, lsl #2
    840c:      	ldr	w0, [x0]
    8410:      	sxtw	x24, w0
    8414:      	ldr	x0, [x21]
    8418:      	add	x0, x0, x24, lsl #2
    841c:      	ldr	w0, [x0]
    8420:      	sxtw	x25, w0
    8424:      	ldr	x0, [x23]
    8428:      	add	x0, x0, x24, lsl #4
    842c:      	ldr	x27, [x0]
    8430:      	ldr	x0, [x0, #0x8]
    8434:      	movz	x1, #0x0, lsl #48
    8438:      	b	0x82b0 <_stogir.schedule.order-with-uses+0x750>
    843c:      	uxtb	w16, w7
    8440:      	cmp	w16, wzr
    8444:      	b.eq	0x8478 <_stogir.schedule.order-with-uses+0x918>
    8448:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		0000000000008448:  ARM64_RELOC_PAGE21	l_stogir.442
    844c:      	ldr	x16, [x16]
		000000000000844c:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    8450:      	add	x3, x16, x3, lsl #2
    8454:      	ldr	w3, [x3]
    8458:      	cmp	x8, #0x0
    845c:      	b.le	0x8470 <_stogir.schedule.order-with-uses+0x910>
    8460:      	cmp	x8, #0x4
    8464:      	b.le	0x8238 <_stogir.schedule.order-with-uses+0x6d8>
    8468:      	mov	w2, #0x4                ; =4
    846c:      	b	0x823c <_stogir.schedule.order-with-uses+0x6dc>
    8470:      	movz	w2, #0x0, lsl #16
    8474:      	b	0x847c <_stogir.schedule.order-with-uses+0x91c>
    8478:      	movz	w2, #0x0, lsl #16
    847c:      	ubfx	x2, x2, #0, #32
    8480:      	cmp	x2, #0xf
    8484:      	b.hs	0x877c <_stogir.schedule.order-with-uses+0xc1c>
    8488:      	mov	x16, #0x1               ; =1
    848c:      	lsl	x2, x16, x2
    8490:      	mov	w17, #0x5e1c            ; =24092
    8494:      	and	w2, w2, w17
    8498:      	ubfx	x2, x2, #0, #32
    849c:      	cmp	x2, #0x0
    84a0:      	b.eq	0x8798 <_stogir.schedule.order-with-uses+0xc38>
    84a4:      	add	x16, sp, #0x20
    84a8:      	ldr	x2, [x16]
    84ac:      	orr	x3, x2, xzr
    84b0:      	add	x3, x3, x5, lsl #3
    84b4:      	add	x2, x2, x5, lsl #3
    84b8:      	ldr	x3, [x3]
    84bc:      	sub	x3, x3, #0x1
    84c0:      	str	x3, [x2]
    84c4:      	add	x16, sp, #0x20
    84c8:      	ldr	x2, [x16]
    84cc:      	add	x2, x2, x5, lsl #3
    84d0:      	ldr	x2, [x2]
    84d4:      	cmp	x2, #0x0
    84d8:      	b.ne	0x87b4 <_stogir.schedule.order-with-uses+0xc54>
    84dc:      	add	x16, sp, #0x140
    84e0:      	ldr	x2, [x16, #0x8]
    84e4:      	add	x16, sp, #0x140
    84e8:      	ldr	x3, [x16, #0x10]
    84ec:      	cmp	x2, x3
    84f0:      	b.lt	0x87d0 <_stogir.schedule.order-with-uses+0xc70>
    84f4:      	cmp	x3, #0x0
    84f8:      	b.ne	0x80d4 <_stogir.schedule.order-with-uses+0x574>
    84fc:      	mov	x3, #0x2                ; =2
    8500:      	b	0x80d8 <_stogir.schedule.order-with-uses+0x578>
    8504:      	add	x0, sp, #0x20
    8508:      	bl	0x8508 <_stogir.schedule.order-with-uses+0x9a8>
		0000000000008508:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    850c:      	add	x0, sp, #0x80
    8510:      	bl	0x8510 <_stogir.schedule.order-with-uses+0x9b0>
		0000000000008510:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    8514:      	add	x0, sp, #0xe0
    8518:      	bl	0x8518 <_stogir.schedule.order-with-uses+0x9b8>
		0000000000008518:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i64
    851c:      	ldr	x0, [sp, #0x1f0]
    8520:      	mov	x1, x28
    8524:      	adrp	x2, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		0000000000008524:  ARM64_RELOC_PAGE21	l_stogir.440
    8528:      	ldr	x2, [x2]
		0000000000008528:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    852c:      	movz	x3, #0x0, lsl #48
    8530:      	bl	0x8530 <_stogir.schedule.order-with-uses+0x9d0>
		0000000000008530:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    8534:      	cmp	x0, #0x0
    8538:      	b.eq	0x855c <_stogir.schedule.order-with-uses+0x9fc>
    853c:      	add	x0, sp, #0x140
    8540:      	bl	0x8540 <_stogir.schedule.order-with-uses+0x9e0>
		0000000000008540:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    8544:      	cmp	x0, x26
    8548:      	b.eq	0x855c <_stogir.schedule.order-with-uses+0x9fc>
    854c:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		000000000000854c:  ARM64_RELOC_PAGE21	l_stogir.445
    8550:      	ldr	x16, [x16]
		0000000000008550:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    8554:      	str	x16, [sp, #0x1f0]
    8558:      	mov	x28, #0x16              ; =22
    855c:      	ldr	x0, [sp, #0x1f0]
    8560:      	mov	x1, x28
    8564:      	adrp	x2, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		0000000000008564:  ARM64_RELOC_PAGE21	l_stogir.440
    8568:      	ldr	x2, [x2]
		0000000000008568:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    856c:      	movz	x3, #0x0, lsl #48
    8570:      	bl	0x8570 <_stogir.schedule.order-with-uses+0xa10>
		0000000000008570:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    8574:      	cmp	x0, #0x0
    8578:      	b.eq	0x87f4 <_stogir.schedule.order-with-uses+0xc94>
    857c:      	add	x8, sp, #0x1a0
    8580:      	ldr	x0, [sp, #0x238]
    8584:      	add	x1, sp, #0x140
    8588:      	ldr	x2, [sp, #0x1e0]
    858c:      	bl	0x858c <_stogir.schedule.order-with-uses+0xa2c>
		000000000000858c:  ARM64_RELOC_BRANCH26	_stogir.schedule.entry-prefix
    8590:      	add	x16, sp, #0x1a0
    8594:      	ldr	x19, [x16]
    8598:      	add	x16, sp, #0x1a0
    859c:      	ldr	x28, [x16, #0x8]
    85a0:      	add	x16, sp, #0x1a0
    85a4:      	ldr	x20, [x16, #0x10]
    85a8:      	add	x16, sp, #0x1a0
    85ac:      	ldr	x21, [x16, #0x18]
    85b0:      	add	x16, sp, #0x1a0
    85b4:      	ldr	x22, [x16, #0x20]
    85b8:      	add	x0, sp, #0x140
    85bc:      	bl	0x85bc <_stogir.schedule.order-with-uses+0xa5c>
		00000000000085bc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    85c0:      	movz	x0, #0x0, lsl #48
    85c4:      	b	0x85e0 <_stogir.schedule.order-with-uses+0xa80>
    85c8:      	add	x0, sp, #0x140
    85cc:      	bl	0x85cc <_stogir.schedule.order-with-uses+0xa6c>
		00000000000085cc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    85d0:      	mov	x0, #0x1                ; =1
    85d4:      	movz	x20, #0x0, lsl #48
    85d8:      	movz	x21, #0x0, lsl #48
    85dc:      	movz	x22, #0x0, lsl #48
    85e0:      	ldr	x1, [sp, #0x1e8]
    85e4:      	str	x0, [x1]
    85e8:      	str	x19, [x1, #0x8]
    85ec:      	str	x28, [x1, #0x10]
    85f0:      	str	x20, [x1, #0x18]
    85f4:      	str	x21, [x1, #0x20]
    85f8:      	str	x22, [x1, #0x28]
    85fc:      	ldr	x19, [sp, #0x248]
    8600:      	ldr	x20, [sp, #0x250]
    8604:      	ldr	x21, [sp, #0x258]
    8608:      	ldr	x22, [sp, #0x260]
    860c:      	ldr	x23, [sp, #0x268]
    8610:      	ldr	x24, [sp, #0x270]
    8614:      	ldr	x25, [sp, #0x278]
    8618:      	ldr	x26, [sp, #0x280]
    861c:      	ldr	x27, [sp, #0x288]
    8620:      	ldr	x28, [sp, #0x290]
    8624:      	ldr	x29, [sp, #0x10]
    8628:      	ldr	x30, [sp, #0x18]
    862c:      	add	sp, sp, #0x2a0
    8630:      	ret
    8634:      	sub	w6, w5, #0x1
    8638:      	lsl	w6, w6, #2
    863c:      	ubfx	x6, x6, #0, #32
    8640:      	lsr	x6, x7, x6
    8644:      	and	w6, w6, #0xf
    8648:      	b	0x7f1c <_stogir.schedule.order-with-uses+0x3bc>
    864c:      	sxtw	x1, w1
    8650:      	cmp	x1, #0x0
    8654:      	b.le	0x8674 <_stogir.schedule.order-with-uses+0xb14>
    8658:      	ldr	x0, [x21]
    865c:      	add	x0, x0, x1, lsl #2
    8660:      	ldr	w0, [x0]
    8664:      	sxtw	x0, w0
    8668:      	cmp	x0, x19
    866c:      	b.ne	0x8674 <_stogir.schedule.order-with-uses+0xb14>
    8670:      	add	x24, x24, #0x1
    8674:      	b	0x7e74 <_stogir.schedule.order-with-uses+0x314>
    8678:      	adrp	x16, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		0000000000008678:  ARM64_RELOC_PAGE21	l_stogir.446
    867c:      	ldr	x16, [x16]
		000000000000867c:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    8680:      	str	x16, [sp, #0x1f0]
    8684:      	mov	x28, #0x13              ; =19
    8688:      	b	0x7dec <_stogir.schedule.order-with-uses+0x28c>
    868c:      	brk	#0
    8690:      	b	0x868c <_stogir.schedule.order-with-uses+0xb2c>
    8694:      	mov	x24, x4
    8698:      	b	0x7fbc <_stogir.schedule.order-with-uses+0x45c>
    869c:      	str	w24, [sp, #0x220]
    86a0:      	mov	x24, x4
    86a4:      	str	w0, [sp, #0x200]
    86a8:      	str	w1, [sp, #0x208]
    86ac:      	str	x2, [sp, #0x210]
    86b0:      	str	x22, [sp, #0x218]
    86b4:      	mov	x22, x3
    86b8:      	b	0x7e74 <_stogir.schedule.order-with-uses+0x314>
    86bc:      	str	w24, [sp, #0x220]
    86c0:      	mov	x24, x4
    86c4:      	str	w0, [sp, #0x200]
    86c8:      	str	w1, [sp, #0x208]
    86cc:      	str	x2, [sp, #0x210]
    86d0:      	str	x22, [sp, #0x218]
    86d4:      	mov	x22, x3
    86d8:      	b	0x7e74 <_stogir.schedule.order-with-uses+0x314>
    86dc:      	str	x19, [sp, #0x1e8]
    86e0:      	str	x22, [sp, #0x1f8]
    86e4:      	str	x24, [sp, #0x1e0]
    86e8:      	str	x27, [sp, #0x1f0]
    86ec:      	b	0x8124 <_stogir.schedule.order-with-uses+0x5c4>
    86f0:      	str	x19, [sp, #0x1e8]
    86f4:      	str	x22, [sp, #0x1f8]
    86f8:      	str	x24, [sp, #0x1e0]
    86fc:      	str	x27, [sp, #0x1f0]
    8700:      	b	0x8124 <_stogir.schedule.order-with-uses+0x5c4>
    8704:      	str	x19, [sp, #0x1e8]
    8708:      	str	x22, [sp, #0x1f8]
    870c:      	str	x27, [sp, #0x1f0]
    8710:      	b	0x7fd0 <_stogir.schedule.order-with-uses+0x470>
    8714:      	str	x19, [sp, #0x1e8]
    8718:      	str	x22, [sp, #0x1f8]
    871c:      	str	x27, [sp, #0x1f0]
    8720:      	b	0x7fd0 <_stogir.schedule.order-with-uses+0x470>
    8724:      	str	x20, [sp, #0x238]
    8728:      	str	x21, [sp, #0x240]
    872c:      	str	w19, [sp, #0x230]
    8730:      	b	0x836c <_stogir.schedule.order-with-uses+0x80c>
    8734:      	str	x20, [sp, #0x238]
    8738:      	str	x21, [sp, #0x240]
    873c:      	str	x6, [sp, #0x1f8]
    8740:      	str	x0, [sp, #0x228]
    8744:      	str	w19, [sp, #0x230]
    8748:      	mov	x19, x1
    874c:      	b	0x8298 <_stogir.schedule.order-with-uses+0x738>
    8750:      	str	x20, [sp, #0x238]
    8754:      	str	x21, [sp, #0x240]
    8758:      	str	x6, [sp, #0x1f8]
    875c:      	str	x0, [sp, #0x228]
    8760:      	str	w19, [sp, #0x230]
    8764:      	mov	x19, x1
    8768:      	b	0x8298 <_stogir.schedule.order-with-uses+0x738>
    876c:      	str	x20, [sp, #0x238]
    8770:      	b	0x8504 <_stogir.schedule.order-with-uses+0x9a4>
    8774:      	str	x20, [sp, #0x238]
    8778:      	b	0x8504 <_stogir.schedule.order-with-uses+0x9a4>
    877c:      	str	x20, [sp, #0x238]
    8780:      	str	x21, [sp, #0x240]
    8784:      	str	x6, [sp, #0x1f8]
    8788:      	str	x0, [sp, #0x228]
    878c:      	str	w19, [sp, #0x230]
    8790:      	mov	x19, x1
    8794:      	b	0x8298 <_stogir.schedule.order-with-uses+0x738>
    8798:      	str	x20, [sp, #0x238]
    879c:      	str	x21, [sp, #0x240]
    87a0:      	str	x6, [sp, #0x1f8]
    87a4:      	str	x0, [sp, #0x228]
    87a8:      	str	w19, [sp, #0x230]
    87ac:      	mov	x19, x1
    87b0:      	b	0x8298 <_stogir.schedule.order-with-uses+0x738>
    87b4:      	str	x20, [sp, #0x238]
    87b8:      	str	x21, [sp, #0x240]
    87bc:      	str	x6, [sp, #0x1f8]
    87c0:      	str	x0, [sp, #0x228]
    87c4:      	str	w19, [sp, #0x230]
    87c8:      	mov	x19, x1
    87cc:      	b	0x8298 <_stogir.schedule.order-with-uses+0x738>
    87d0:      	str	x20, [sp, #0x238]
    87d4:      	str	x21, [sp, #0x240]
    87d8:      	str	x6, [sp, #0x1f8]
    87dc:      	str	x0, [sp, #0x228]
    87e0:      	mov	w20, w4
    87e4:      	mov	x21, x2
    87e8:      	str	w19, [sp, #0x230]
    87ec:      	mov	x19, x1
    87f0:      	b	0x8104 <_stogir.schedule.order-with-uses+0x5a4>
    87f4:      	ldr	x19, [sp, #0x1f0]
    87f8:      	b	0x85c8 <_stogir.schedule.order-with-uses+0xa68>
    87fc:      	udf	#0x0

0000000000008800 <_stogir.schedule.pack>:
    8800:      	sub	sp, sp, #0xd0
    8804:      	str	x29, [sp]
    8808:      	str	x30, [sp, #0x8]
    880c:      	mov	x29, sp
    8810:      	str	x19, [sp, #0x90]
    8814:      	str	x20, [sp, #0x98]
    8818:      	str	x21, [sp, #0xa0]
    881c:      	str	x22, [sp, #0xa8]
    8820:      	str	x23, [sp, #0xb0]
    8824:      	str	x24, [sp, #0xb8]
    8828:      	str	x25, [sp, #0xc0]
    882c:      	str	x26, [sp, #0xc8]
    8830:      	ldr	x4, [x3]
    8834:      	ldr	x3, [x3, #0x8]
    8838:      	add	x16, sp, #0x10
    883c:      	movz	x17, #0x0, lsl #48
    8840:      	str	x17, [x16]
    8844:      	add	x16, sp, #0x10
    8848:      	movz	x17, #0x0, lsl #48
    884c:      	str	x17, [x16, #0x8]
    8850:      	add	x16, sp, #0x10
    8854:      	movz	x17, #0x0, lsl #48
    8858:      	str	x17, [x16, #0x10]
    885c:      	add	x16, sp, #0x10
    8860:      	str	x4, [x16, #0x18]
    8864:      	add	x16, sp, #0x10
    8868:      	str	x3, [x16, #0x20]
    886c:      	add	x16, sp, #0x10
    8870:      	movz	x17, #0x0, lsl #48
    8874:      	str	x17, [x16, #0x28]
    8878:      	add	x16, sp, #0x10
    887c:      	movz	x17, #0x0, lsl #48
    8880:      	str	x17, [x16, #0x30]
    8884:      	add	x16, sp, #0x10
    8888:      	movz	x17, #0x0, lsl #48
    888c:      	str	x17, [x16, #0x38]
    8890:      	add	x16, sp, #0x10
    8894:      	str	x4, [x16, #0x40]
    8898:      	add	x16, sp, #0x10
    889c:      	str	x3, [x16, #0x48]
    88a0:      	add	x16, sp, #0x60
    88a4:      	movz	x17, #0x0, lsl #48
    88a8:      	str	x17, [x16]
    88ac:      	add	x16, sp, #0x60
    88b0:      	movz	x17, #0x0, lsl #48
    88b4:      	str	x17, [x16, #0x8]
    88b8:      	add	x16, sp, #0x60
    88bc:      	movz	x17, #0x0, lsl #48
    88c0:      	str	x17, [x16, #0x10]
    88c4:      	add	x16, sp, #0x60
    88c8:      	str	x4, [x16, #0x18]
    88cc:      	add	x16, sp, #0x60
    88d0:      	str	x3, [x16, #0x20]
    88d4:      	ldr	x3, [x1, #0x8]
    88d8:      	orr	x19, x3, xzr
    88dc:      	cmp	x19, #0x0
    88e0:      	b.le	0x8d9c <_stogir.schedule.pack+0x59c>
    88e4:      	cmp	x19, #0x0
    88e8:      	b.ge	0x88f4 <_stogir.schedule.pack+0xf4>
    88ec:      	movz	x3, #0x0, lsl #48
    88f0:      	b	0x88f8 <_stogir.schedule.pack+0xf8>
    88f4:      	mov	x3, x19
    88f8:      	mov	x20, x8
    88fc:      	mov	x21, x0
    8900:      	add	x0, sp, #0x10
    8904:      	mov	x22, x1
    8908:      	mov	x1, x3
    890c:      	mov	x23, x2
    8910:      	bl	0x8910 <_stogir.schedule.pack+0x110>
		0000000000008910:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range
    8914:      	add	x16, sp, #0x10
    8918:      	orr	x24, x16, xzr
    891c:      	lsl	x0, x19, #4
    8920:      	add	x16, sp, #0x10
    8924:      	ldr	x1, [x16]
    8928:      	mov	x2, x0
    892c:      	mov	x0, x1
    8930:      	movz	x1, #0x0, lsl #48
    8934:      	bl	0x8934 <_stogir.schedule.pack+0x134>
		0000000000008934:  ARM64_RELOC_BRANCH26	_memset
    8938:      	add	x16, sp, #0x10
    893c:      	str	x19, [x16, #0x8]
    8940:      	ldr	x0, [x22, #0x8]
    8944:      	orr	x19, x0, xzr
    8948:      	add	x16, sp, #0x60
    894c:      	ldr	x0, [x16, #0x8]
    8950:      	orr	x25, x0, xzr
    8954:      	add	x16, sp, #0x60
    8958:      	ldr	x0, [x16, #0x10]
    895c:      	add	x26, x25, x19
    8960:      	cmp	x26, x0
    8964:      	b.le	0x8998 <_stogir.schedule.pack+0x198>
    8968:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    896c:      	cmp	x0, x17
    8970:      	b.gt	0x897c <_stogir.schedule.pack+0x17c>
    8974:      	lsl	x0, x0, #1
    8978:      	b	0x8980 <_stogir.schedule.pack+0x180>
    897c:      	mov	x0, x26
    8980:      	cmp	x0, x26
    8984:      	b.gt	0x898c <_stogir.schedule.pack+0x18c>
    8988:      	mov	x0, x26
    898c:      	mov	x1, x0
    8990:      	add	x0, sp, #0x60
    8994:      	bl	0x8994 <_stogir.schedule.pack+0x194>
		0000000000008994:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    8998:      	lsl	x0, x19, #3
    899c:      	add	x16, sp, #0x60
    89a0:      	ldr	x1, [x16]
    89a4:      	add	x1, x1, x25, lsl #3
    89a8:      	mov	x2, x0
    89ac:      	mov	x0, x1
    89b0:      	movz	x1, #0x0, lsl #48
    89b4:      	bl	0x89b4 <_stogir.schedule.pack+0x1b4>
		00000000000089b4:  ARM64_RELOC_BRANCH26	_memset
    89b8:      	add	x16, sp, #0x60
    89bc:      	str	x26, [x16, #0x8]
    89c0:      	ldr	x0, [x21]
    89c4:      	ldr	x1, [x21, #0x8]
    89c8:      	movz	x2, #0x0, lsl #48
    89cc:      	b	0x8a44 <_stogir.schedule.pack+0x244>
    89d0:      	movz	w3, #0x0, lsl #16
    89d4:      	movz	w4, #0x0, lsl #16
    89d8:      	ubfx	x3, x3, #0, #32
    89dc:      	lsr	x16, x3, #0
    89e0:      	cmp	x16, #0x1
    89e4:      	b.eq	0x8a00 <_stogir.schedule.pack+0x200>
    89e8:      	b.lo	0x89f0 <_stogir.schedule.pack+0x1f0>
    89ec:      	b	0x8a04 <_stogir.schedule.pack+0x204>
    89f0:      	cmp	x16, #0x0
    89f4:      	b.eq	0x89fc <_stogir.schedule.pack+0x1fc>
    89f8:      	b	0x8a04 <_stogir.schedule.pack+0x204>
    89fc:      	b	0x8a6c <_stogir.schedule.pack+0x26c>
    8a00:      	b	0x8a08 <_stogir.schedule.pack+0x208>
    8a04:      	b	0x8d94 <_stogir.schedule.pack+0x594>
    8a08:      	sxtw	x4, w4
    8a0c:      	ldr	x3, [x22]
    8a10:      	add	x3, x3, x4, lsl #2
    8a14:      	ldr	w3, [x3]
    8a18:      	sxtw	x3, w3
    8a1c:      	add	x16, sp, #0x10
    8a20:      	ldr	x4, [x16]
    8a24:      	orr	x5, x4, xzr
    8a28:      	add	x5, x5, x3, lsl #4
    8a2c:      	add	x3, x4, x3, lsl #4
    8a30:      	ldr	x4, [x5]
    8a34:      	ldr	x5, [x5, #0x8]
    8a38:      	add	x5, x5, #0x1
    8a3c:      	str	x4, [x3]
    8a40:      	str	x5, [x3, #0x8]
    8a44:      	cmp	x2, x1
    8a48:      	b.ge	0x89d0 <_stogir.schedule.pack+0x1d0>
    8a4c:      	add	x3, x2, #0x1
    8a50:      	add	x2, x0, x2, lsl #2
    8a54:      	ldr	w2, [x2]
    8a58:      	movn	w17, #0x0, lsl #16
    8a5c:      	and	w4, w2, w17
    8a60:      	mov	x2, x3
    8a64:      	mov	w3, #0x1                ; =1
    8a68:      	b	0x89d8 <_stogir.schedule.pack+0x1d8>
    8a6c:      	ldr	x0, [x23]
    8a70:      	ldr	x1, [x23, #0x8]
    8a74:      	movz	x2, #0x0, lsl #48
    8a78:      	movz	x3, #0x0, lsl #48
    8a7c:      	b	0x8af4 <_stogir.schedule.pack+0x2f4>
    8a80:      	movz	w4, #0x0, lsl #16
    8a84:      	movz	w5, #0x0, lsl #16
    8a88:      	ubfx	x4, x4, #0, #32
    8a8c:      	lsr	x16, x4, #0
    8a90:      	cmp	x16, #0x1
    8a94:      	b.eq	0x8ab0 <_stogir.schedule.pack+0x2b0>
    8a98:      	b.lo	0x8aa0 <_stogir.schedule.pack+0x2a0>
    8a9c:      	b	0x8ab4 <_stogir.schedule.pack+0x2b4>
    8aa0:      	cmp	x16, #0x0
    8aa4:      	b.eq	0x8aac <_stogir.schedule.pack+0x2ac>
    8aa8:      	b	0x8ab4 <_stogir.schedule.pack+0x2b4>
    8aac:      	b	0x8b1c <_stogir.schedule.pack+0x31c>
    8ab0:      	b	0x8ab8 <_stogir.schedule.pack+0x2b8>
    8ab4:      	b	0x8d8c <_stogir.schedule.pack+0x58c>
    8ab8:      	sxtw	x5, w5
    8abc:      	add	x16, sp, #0x10
    8ac0:      	ldr	x4, [x16]
    8ac4:      	orr	x6, x4, xzr
    8ac8:      	add	x6, x6, x5, lsl #4
    8acc:      	add	x4, x4, x5, lsl #4
    8ad0:      	ldr	x6, [x6, #0x8]
    8ad4:      	add	x7, x6, x2
    8ad8:      	str	x2, [x4]
    8adc:      	str	x6, [x4, #0x8]
    8ae0:      	add	x16, sp, #0x60
    8ae4:      	ldr	x4, [x16]
    8ae8:      	add	x4, x4, x5, lsl #3
    8aec:      	str	x2, [x4]
    8af0:      	mov	x2, x7
    8af4:      	cmp	x3, x1
    8af8:      	b.ge	0x8a80 <_stogir.schedule.pack+0x280>
    8afc:      	add	x4, x3, #0x1
    8b00:      	add	x3, x0, x3, lsl #2
    8b04:      	ldr	w3, [x3]
    8b08:      	movn	w17, #0x0, lsl #16
    8b0c:      	and	w5, w3, w17
    8b10:      	mov	x3, x4
    8b14:      	mov	w4, #0x1                ; =1
    8b18:      	b	0x8a88 <_stogir.schedule.pack+0x288>
    8b1c:      	add	x19, x24, #0x28
    8b20:      	ldr	x0, [x21, #0x8]
    8b24:      	orr	x23, x0, xzr
    8b28:      	ldr	x0, [x19, #0x8]
    8b2c:      	orr	x24, x0, xzr
    8b30:      	ldr	x0, [x19, #0x10]
    8b34:      	add	x25, x24, x23
    8b38:      	cmp	x25, x0
    8b3c:      	b.le	0x8b70 <_stogir.schedule.pack+0x370>
    8b40:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    8b44:      	cmp	x0, x17
    8b48:      	b.gt	0x8b54 <_stogir.schedule.pack+0x354>
    8b4c:      	lsl	x0, x0, #1
    8b50:      	b	0x8b58 <_stogir.schedule.pack+0x358>
    8b54:      	mov	x0, x25
    8b58:      	cmp	x0, x25
    8b5c:      	b.gt	0x8b64 <_stogir.schedule.pack+0x364>
    8b60:      	mov	x0, x25
    8b64:      	mov	x1, x0
    8b68:      	mov	x0, x19
    8b6c:      	bl	0x8b6c <_stogir.schedule.pack+0x36c>
		0000000000008b6c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    8b70:      	lsl	x0, x23, #2
    8b74:      	add	x16, sp, #0x10
    8b78:      	ldr	x1, [x16, #0x28]
    8b7c:      	add	x1, x1, x24, lsl #2
    8b80:      	mov	x2, x0
    8b84:      	mov	x0, x1
    8b88:      	movz	x1, #0x0, lsl #48
    8b8c:      	bl	0x8b8c <_stogir.schedule.pack+0x38c>
		0000000000008b8c:  ARM64_RELOC_BRANCH26	_memset
    8b90:      	str	x25, [x19, #0x8]
    8b94:      	ldr	x0, [x21]
    8b98:      	ldr	x1, [x21, #0x8]
    8b9c:      	movz	x2, #0x0, lsl #48
    8ba0:      	b	0x8c28 <_stogir.schedule.pack+0x428>
    8ba4:      	nop
    8ba8:      	movz	w3, #0x0, lsl #16
    8bac:      	movz	w4, #0x0, lsl #16
    8bb0:      	ubfx	x3, x3, #0, #32
    8bb4:      	lsr	x16, x3, #0
    8bb8:      	cmp	x16, #0x1
    8bbc:      	b.eq	0x8bd8 <_stogir.schedule.pack+0x3d8>
    8bc0:      	b.lo	0x8bc8 <_stogir.schedule.pack+0x3c8>
    8bc4:      	b	0x8bdc <_stogir.schedule.pack+0x3dc>
    8bc8:      	cmp	x16, #0x0
    8bcc:      	b.eq	0x8bd4 <_stogir.schedule.pack+0x3d4>
    8bd0:      	b	0x8bdc <_stogir.schedule.pack+0x3dc>
    8bd4:      	b	0x8c50 <_stogir.schedule.pack+0x450>
    8bd8:      	b	0x8be0 <_stogir.schedule.pack+0x3e0>
    8bdc:      	b	0x8d84 <_stogir.schedule.pack+0x584>
    8be0:      	sxtw	x3, w4
    8be4:      	ldr	x5, [x22]
    8be8:      	add	x3, x5, x3, lsl #2
    8bec:      	ldr	w3, [x3]
    8bf0:      	sxtw	x3, w3
    8bf4:      	add	x16, sp, #0x60
    8bf8:      	ldr	x5, [x16]
    8bfc:      	add	x5, x5, x3, lsl #3
    8c00:      	ldr	x5, [x5]
    8c04:      	add	x16, sp, #0x10
    8c08:      	ldr	x6, [x16, #0x28]
    8c0c:      	add	x7, x5, #0x1
    8c10:      	add	x5, x6, x5, lsl #2
    8c14:      	str	w4, [x5]
    8c18:      	add	x16, sp, #0x60
    8c1c:      	ldr	x4, [x16]
    8c20:      	add	x3, x4, x3, lsl #3
    8c24:      	str	x7, [x3]
    8c28:      	cmp	x2, x1
    8c2c:      	b.ge	0x8ba8 <_stogir.schedule.pack+0x3a8>
    8c30:      	add	x3, x2, #0x1
    8c34:      	add	x2, x0, x2, lsl #2
    8c38:      	ldr	w2, [x2]
    8c3c:      	movn	w17, #0x0, lsl #16
    8c40:      	and	w4, w2, w17
    8c44:      	mov	x2, x3
    8c48:      	mov	w3, #0x1                ; =1
    8c4c:      	b	0x8bb0 <_stogir.schedule.pack+0x3b0>
    8c50:      	b	0x8c64 <_stogir.schedule.pack+0x464>
    8c54:      	nop
    8c58:      	sub	x0, x0, #0x1
    8c5c:      	add	x16, sp, #0x60
    8c60:      	str	x0, [x16, #0x8]
    8c64:      	add	x16, sp, #0x60
    8c68:      	ldr	x0, [x16, #0x8]
    8c6c:      	cmp	x0, #0x0
    8c70:      	b.ne	0x8c58 <_stogir.schedule.pack+0x458>
    8c74:      	add	x16, sp, #0x60
    8c78:      	orr	x0, x16, xzr
    8c7c:      	add	x16, sp, #0x60
    8c80:      	ldr	x1, [x16, #0x10]
    8c84:      	cmp	x1, #0x0
    8c88:      	b.le	0x8cb8 <_stogir.schedule.pack+0x4b8>
    8c8c:      	add	x0, x0, #0x18
    8c90:      	add	x16, sp, #0x60
    8c94:      	ldr	x2, [x16]
    8c98:      	fmov	d31, x1
    8c9c:      	mov	x1, x2
    8ca0:      	fmov	x2, d31
    8ca4:      	adrp	x3, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		0000000000008ca4:  ARM64_RELOC_PAGE21	l_stogir.447
    8ca8:      	ldr	x3, [x3]
		0000000000008ca8:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    8cac:      	mov	x4, #0x8                ; =8
    8cb0:      	mov	x5, #0x8                ; =8
    8cb4:      	bl	0x8cb4 <_stogir.schedule.pack+0x4b4>
		0000000000008cb4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    8cb8:      	add	x16, sp, #0x60
    8cbc:      	movz	x17, #0x0, lsl #48
    8cc0:      	str	x17, [x16]
    8cc4:      	add	x16, sp, #0x60
    8cc8:      	movz	x17, #0x0, lsl #48
    8ccc:      	str	x17, [x16, #0x8]
    8cd0:      	add	x16, sp, #0x60
    8cd4:      	movz	x17, #0x0, lsl #48
    8cd8:      	str	x17, [x16, #0x10]
    8cdc:      	add	x16, sp, #0x10
    8ce0:      	ldr	x0, [x16]
    8ce4:      	add	x16, sp, #0x10
    8ce8:      	ldr	x1, [x16, #0x8]
    8cec:      	add	x16, sp, #0x10
    8cf0:      	ldr	x2, [x16, #0x10]
    8cf4:      	add	x16, sp, #0x10
    8cf8:      	ldr	x3, [x16, #0x18]
    8cfc:      	add	x16, sp, #0x10
    8d00:      	ldr	x4, [x16, #0x20]
    8d04:      	add	x16, sp, #0x10
    8d08:      	ldr	x5, [x16, #0x28]
    8d0c:      	add	x16, sp, #0x10
    8d10:      	ldr	x6, [x16, #0x30]
    8d14:      	add	x16, sp, #0x10
    8d18:      	ldr	x7, [x16, #0x38]
    8d1c:      	add	x16, sp, #0x10
    8d20:      	ldr	x8, [x16, #0x40]
    8d24:      	add	x16, sp, #0x10
    8d28:      	ldr	x9, [x16, #0x48]
    8d2c:      	str	x0, [x20]
    8d30:      	str	x1, [x20, #0x8]
    8d34:      	str	x2, [x20, #0x10]
    8d38:      	str	x3, [x20, #0x18]
    8d3c:      	str	x4, [x20, #0x20]
    8d40:      	str	x5, [x20, #0x28]
    8d44:      	str	x6, [x20, #0x30]
    8d48:      	str	x7, [x20, #0x38]
    8d4c:      	str	x8, [x20, #0x40]
    8d50:      	str	x9, [x20, #0x48]
    8d54:      	ldr	x19, [sp, #0x90]
    8d58:      	ldr	x20, [sp, #0x98]
    8d5c:      	ldr	x21, [sp, #0xa0]
    8d60:      	ldr	x22, [sp, #0xa8]
    8d64:      	ldr	x23, [sp, #0xb0]
    8d68:      	ldr	x24, [sp, #0xb8]
    8d6c:      	ldr	x25, [sp, #0xc0]
    8d70:      	ldr	x26, [sp, #0xc8]
    8d74:      	ldr	x29, [sp]
    8d78:      	ldr	x30, [sp, #0x8]
    8d7c:      	add	sp, sp, #0xd0
    8d80:      	ret
    8d84:      	brk	#0
    8d88:      	b	0x8d84 <_stogir.schedule.pack+0x584>
    8d8c:      	brk	#0
    8d90:      	b	0x8d8c <_stogir.schedule.pack+0x58c>
    8d94:      	brk	#0
    8d98:      	b	0x8d94 <_stogir.schedule.pack+0x594>
    8d9c:      	mov	x20, x8
    8da0:      	mov	x21, x0
    8da4:      	mov	x22, x1
    8da8:      	mov	x23, x2
    8dac:      	b	0x8914 <_stogir.schedule.pack+0x114>

0000000000008db0 <_stogir.checked-schedule.cluster!>:
    8db0:      	sub	sp, sp, #0x230
    8db4:      	str	x29, [sp]
    8db8:      	str	x30, [sp, #0x8]
    8dbc:      	mov	x29, sp
    8dc0:      	str	x19, [sp, #0x1d8]
    8dc4:      	str	x20, [sp, #0x1e0]
    8dc8:      	str	x21, [sp, #0x1e8]
    8dcc:      	str	x22, [sp, #0x1f0]
    8dd0:      	str	x23, [sp, #0x1f8]
    8dd4:      	str	x24, [sp, #0x200]
    8dd8:      	str	x25, [sp, #0x208]
    8ddc:      	str	x26, [sp, #0x210]
    8de0:      	str	x27, [sp, #0x218]
    8de4:      	str	x28, [sp, #0x220]
    8de8:      	add	x16, sp, #0x10
    8dec:      	orr	x4, x16, xzr
    8df0:      	add	x19, x2, #0x28
    8df4:      	add	x20, x4, #0x8
    8df8:      	ldr	x4, [x2, #0x28]
    8dfc:      	ldr	x5, [x19, #0x8]
    8e00:      	orr	x21, x4, xzr
    8e04:      	orr	x22, x5, xzr
    8e08:      	movz	x23, #0x0, lsl #48
    8e0c:      	adrp	x24, 0x8000 <_stogir.schedule.order-with-uses+0x4a0>
		0000000000008e0c:  ARM64_RELOC_PAGE21	l_stogir.448
    8e10:      	ldr	x24, [x24]
		0000000000008e10:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    8e14:      	movz	x25, #0x0, lsl #48
    8e18:      	movz	x26, #0x0, lsl #48
    8e1c:      	b	0x8e5c <_stogir.checked-schedule.cluster!+0xac>
    8e20:      	add	x16, sp, #0x10
    8e24:      	ldr	w0, [x16, #0x8]
    8e28:      	sxtw	x0, w0
    8e2c:      	cmp	x0, #0x0
    8e30:      	b.eq	0x8e3c <_stogir.checked-schedule.cluster!+0x8c>
    8e34:      	add	x0, x23, #0x1
    8e38:      	sxtw	x23, w0
    8e3c:      	mov	x8, x27
    8e40:      	mov	x0, x28
    8e44:      	mov	x1, x21
    8e48:      	mov	x2, x22
    8e4c:      	mov	x3, x26
    8e50:      	ldr	x22, [sp, #0x198]
    8e54:      	ldr	x21, [sp, #0x190]
    8e58:      	ldr	x26, [sp, #0x1a0]
    8e5c:      	cmp	x26, x22
    8e60:      	b.ge	0x8e84 <_stogir.checked-schedule.cluster!+0xd4>
    8e64:      	add	x4, x26, #0x1
    8e68:      	add	x5, x21, x26, lsl #2
    8e6c:      	ldr	w5, [x5]
    8e70:      	movn	w17, #0x0, lsl #16
    8e74:      	and	w5, w5, w17
    8e78:      	mov	x26, x4
    8e7c:      	mov	w4, #0x1                ; =1
    8e80:      	b	0x8e8c <_stogir.checked-schedule.cluster!+0xdc>
    8e84:      	movz	w4, #0x0, lsl #16
    8e88:      	movz	w5, #0x0, lsl #16
    8e8c:      	ubfx	x4, x4, #0, #32
    8e90:      	lsr	x16, x4, #0
    8e94:      	cmp	x16, #0x1
    8e98:      	b.eq	0x8ec8 <_stogir.checked-schedule.cluster!+0x118>
    8e9c:      	b.lo	0x8ea4 <_stogir.checked-schedule.cluster!+0xf4>
    8ea0:      	b	0x8ecc <_stogir.checked-schedule.cluster!+0x11c>
    8ea4:      	cmp	x16, #0x0
    8ea8:      	b.eq	0x8eb0 <_stogir.checked-schedule.cluster!+0x100>
    8eac:      	b	0x8ecc <_stogir.checked-schedule.cluster!+0x11c>
    8eb0:      	mov	x27, x8
    8eb4:      	mov	x28, x0
    8eb8:      	mov	x21, x1
    8ebc:      	mov	x22, x2
    8ec0:      	mov	x26, x3
    8ec4:      	b	0x8f5c <_stogir.checked-schedule.cluster!+0x1ac>
    8ec8:      	b	0x8ed0 <_stogir.checked-schedule.cluster!+0x120>
    8ecc:      	b	0x9718 <_stogir.checked-schedule.cluster!+0x968>
    8ed0:      	sxtw	x4, w5
    8ed4:      	ldr	x6, [x0]
    8ed8:      	add	x4, x6, x4, lsl #4
    8edc:      	ldr	x4, [x4]
    8ee0:      	uxtb	w4, w4
    8ee4:      	cmp	x4, #0x2c
    8ee8:      	b.ne	0x9740 <_stogir.checked-schedule.cluster!+0x990>
    8eec:      	mov	x27, x8
    8ef0:      	add	x8, sp, #0x10
    8ef4:      	mov	x28, x0
    8ef8:      	str	x21, [sp, #0x190]
    8efc:      	mov	x21, x1
    8f00:      	mov	w1, w5
    8f04:      	str	x22, [sp, #0x198]
    8f08:      	mov	x22, x2
    8f0c:      	str	x26, [sp, #0x1a0]
    8f10:      	mov	x26, x3
    8f14:      	bl	0x8f14 <_stogir.checked-schedule.cluster!+0x164>
		0000000000008f14:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    8f18:      	add	x16, sp, #0x10
    8f1c:      	ldr	w0, [x16]
    8f20:      	lsr	x16, x0, #0
    8f24:      	cmp	x16, #0x1
    8f28:      	b.eq	0x8f44 <_stogir.checked-schedule.cluster!+0x194>
    8f2c:      	b.lo	0x8f34 <_stogir.checked-schedule.cluster!+0x184>
    8f30:      	b	0x8f48 <_stogir.checked-schedule.cluster!+0x198>
    8f34:      	cmp	x16, #0x0
    8f38:      	b.eq	0x8f40 <_stogir.checked-schedule.cluster!+0x190>
    8f3c:      	b	0x8f48 <_stogir.checked-schedule.cluster!+0x198>
    8f40:      	b	0x8e20 <_stogir.checked-schedule.cluster!+0x70>
    8f44:      	b	0x8f4c <_stogir.checked-schedule.cluster!+0x19c>
    8f48:      	b	0x9730 <_stogir.checked-schedule.cluster!+0x980>
    8f4c:      	add	x16, sp, #0x10
    8f50:      	ldr	x24, [x16, #0x8]
    8f54:      	ldr	x25, [x20, #0x8]
    8f58:      	b	0x8e3c <_stogir.checked-schedule.cluster!+0x8c>
    8f5c:      	cmp	x25, #0x0
    8f60:      	b.ne	0x8f98 <_stogir.checked-schedule.cluster!+0x1e8>
    8f64:      	cmp	x23, #0x0
    8f68:      	b.ne	0x9578 <_stogir.checked-schedule.cluster!+0x7c8>
    8f6c:      	add	x8, sp, #0x30
    8f70:      	mov	x0, x28
    8f74:      	mov	x1, x22
    8f78:      	bl	0x8f78 <_stogir.checked-schedule.cluster!+0x1c8>
		0000000000008f78:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate
    8f7c:      	add	x16, sp, #0x30
    8f80:      	ldr	x0, [x16]
    8f84:      	add	x16, sp, #0x30
    8f88:      	ldr	x24, [x16, #0x8]
    8f8c:      	add	x16, sp, #0x30
    8f90:      	ldr	x25, [x16, #0x10]
    8f94:      	b	0x936c <_stogir.checked-schedule.cluster!+0x5bc>
    8f98:      	mov	x0, #0x1                ; =1
    8f9c:      	b	0x936c <_stogir.checked-schedule.cluster!+0x5bc>
    8fa0:      	add	x16, sp, #0xb0
    8fa4:      	ldr	x2, [x16]
    8fa8:      	add	x1, x2, x1, lsl #2
    8fac:      	str	w26, [x1]
    8fb0:      	add	x16, sp, #0x80
    8fb4:      	ldr	x1, [x16]
    8fb8:      	add	x0, x1, x0, lsl #2
    8fbc:      	str	w26, [x0]
    8fc0:      	add	x16, sp, #0xe0
    8fc4:      	ldr	x0, [x16]
    8fc8:      	add	x0, x0, x28
    8fcc:      	mov	w17, #0x1               ; =1
    8fd0:      	strb	w17, [x0]
    8fd4:      	ldr	x28, [sp, #0x1c0]
    8fd8:      	ldr	x0, [sp, #0x1a8]
    8fdc:      	ldr	x26, [sp, #0x1b8]
    8fe0:      	ldr	x1, [sp, #0x1b0]
    8fe4:      	cmp	x1, x0
    8fe8:      	b.ge	0x900c <_stogir.checked-schedule.cluster!+0x25c>
    8fec:      	add	x2, x1, #0x1
    8ff0:      	add	x1, x26, x1, lsl #2
    8ff4:      	ldr	w1, [x1]
    8ff8:      	movn	w17, #0x0, lsl #16
    8ffc:      	and	w3, w1, w17
    9000:      	mov	x1, x2
    9004:      	mov	w2, #0x1                ; =1
    9008:      	b	0x9014 <_stogir.checked-schedule.cluster!+0x264>
    900c:      	movz	w2, #0x0, lsl #16
    9010:      	movz	w3, #0x0, lsl #16
    9014:      	ubfx	x2, x2, #0, #32
    9018:      	lsr	x16, x2, #0
    901c:      	cmp	x16, #0x1
    9020:      	b.eq	0x9040 <_stogir.checked-schedule.cluster!+0x290>
    9024:      	b.lo	0x902c <_stogir.checked-schedule.cluster!+0x27c>
    9028:      	b	0x9044 <_stogir.checked-schedule.cluster!+0x294>
    902c:      	cmp	x16, #0x0
    9030:      	b.eq	0x9038 <_stogir.checked-schedule.cluster!+0x288>
    9034:      	b	0x9044 <_stogir.checked-schedule.cluster!+0x294>
    9038:      	str	x28, [sp, #0x1c0]
    903c:      	b	0x90e8 <_stogir.checked-schedule.cluster!+0x338>
    9040:      	b	0x9048 <_stogir.checked-schedule.cluster!+0x298>
    9044:      	b	0x9720 <_stogir.checked-schedule.cluster!+0x970>
    9048:      	sxtw	x2, w3
    904c:      	ldr	x4, [x28]
    9050:      	add	x4, x4, x2, lsl #4
    9054:      	ldr	x5, [x4]
    9058:      	uxtb	w6, w5
    905c:      	ldr	x4, [x4, #0x8]
    9060:      	add	x16, sp, #0x140
    9064:      	str	x5, [x16]
    9068:      	add	x16, sp, #0x140
    906c:      	str	x4, [x16, #0x8]
    9070:      	cmp	x6, #0x2c
    9074:      	b.ne	0x9764 <_stogir.checked-schedule.cluster!+0x9b4>
    9078:      	lsr	x4, x5, #32
    907c:      	add	x8, sp, #0x150
    9080:      	str	x0, [sp, #0x1a8]
    9084:      	mov	x0, x28
    9088:      	str	x1, [sp, #0x1b0]
    908c:      	mov	w1, w4
    9090:      	str	x26, [sp, #0x1b8]
    9094:      	mov	w26, w3
    9098:      	str	x28, [sp, #0x1c0]
    909c:      	mov	x28, x2
    90a0:      	bl	0x90a0 <_stogir.checked-schedule.cluster!+0x2f0>
		00000000000090a0:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    90a4:      	add	x16, sp, #0x150
    90a8:      	ldr	w0, [x16]
    90ac:      	lsr	x16, x0, #0
    90b0:      	cmp	x16, #0x1
    90b4:      	b.eq	0x90d0 <_stogir.checked-schedule.cluster!+0x320>
    90b8:      	b.lo	0x90c0 <_stogir.checked-schedule.cluster!+0x310>
    90bc:      	b	0x90d4 <_stogir.checked-schedule.cluster!+0x324>
    90c0:      	cmp	x16, #0x0
    90c4:      	b.eq	0x90cc <_stogir.checked-schedule.cluster!+0x31c>
    90c8:      	b	0x90d4 <_stogir.checked-schedule.cluster!+0x324>
    90cc:      	b	0x968c <_stogir.checked-schedule.cluster!+0x8dc>
    90d0:      	b	0x90d8 <_stogir.checked-schedule.cluster!+0x328>
    90d4:      	b	0x9738 <_stogir.checked-schedule.cluster!+0x988>
    90d8:      	add	x16, sp, #0x150
    90dc:      	ldr	x24, [x16, #0x8]
    90e0:      	ldr	x25, [x20, #0x8]
    90e4:      	b	0x8fd4 <_stogir.checked-schedule.cluster!+0x224>
    90e8:      	ldr	x0, [x22, #0x28]
    90ec:      	ldr	x1, [x19, #0x8]
    90f0:      	orr	x20, x0, xzr
    90f4:      	orr	x21, x1, xzr
    90f8:      	movz	x26, #0x0, lsl #48
    90fc:      	b	0x9254 <_stogir.checked-schedule.cluster!+0x4a4>
    9100:      	add	x0, sp, #0x110
    9104:      	bl	0x9104 <_stogir.checked-schedule.cluster!+0x354>
		0000000000009104:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9108:      	mov	x0, #0x1                ; =1
    910c:      	b	0x936c <_stogir.checked-schedule.cluster!+0x5bc>
    9110:      	adrp	x24, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009110:  ARM64_RELOC_PAGE21	l_stogir.449
    9114:      	ldr	x24, [x24]
		0000000000009114:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    9118:      	mov	x25, #0x32              ; =50
    911c:      	b	0x9290 <_stogir.checked-schedule.cluster!+0x4e0>
    9120:      	lsl	x2, x2, #1
    9124:      	str	x20, [sp, #0x1c8]
    9128:      	mov	x20, x0
    912c:      	add	x0, sp, #0x110
    9130:      	str	x21, [sp, #0x1d0]
    9134:      	mov	x21, x1
    9138:      	mov	x1, x2
    913c:      	bl	0x913c <_stogir.checked-schedule.cluster!+0x38c>
		000000000000913c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9140:      	add	x0, x21, #0x1
    9144:      	add	x16, sp, #0x110
    9148:      	ldr	x1, [x16]
    914c:      	add	x1, x1, x21, lsl #2
    9150:      	str	w28, [x1]
    9154:      	add	x16, sp, #0x110
    9158:      	str	x0, [x16, #0x8]
    915c:      	add	x16, sp, #0x50
    9160:      	ldr	x0, [x16]
    9164:      	add	x0, x0, x20, lsl #2
    9168:      	ldr	w0, [x0]
    916c:      	orr	w20, w0, wzr
    9170:      	b	0x91b8 <_stogir.checked-schedule.cluster!+0x408>
    9174:      	nop
    9178:      	lsl	x0, x0, #1
    917c:      	mov	x1, x0
    9180:      	add	x0, sp, #0x110
    9184:      	bl	0x9184 <_stogir.checked-schedule.cluster!+0x3d4>
		0000000000009184:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9188:      	add	x0, x28, #0x1
    918c:      	add	x16, sp, #0x110
    9190:      	ldr	x1, [x16]
    9194:      	add	x1, x1, x28, lsl #2
    9198:      	str	w20, [x1]
    919c:      	add	x16, sp, #0x110
    91a0:      	str	x0, [x16, #0x8]
    91a4:      	add	x16, sp, #0xb0
    91a8:      	ldr	x0, [x16]
    91ac:      	add	x0, x0, x21, lsl #2
    91b0:      	ldr	w0, [x0]
    91b4:      	orr	w20, w0, wzr
    91b8:      	sxtw	x21, w20
    91bc:      	cmp	x21, #0x0
    91c0:      	b.eq	0x924c <_stogir.checked-schedule.cluster!+0x49c>
    91c4:      	add	x16, sp, #0x110
    91c8:      	ldr	x0, [x16, #0x8]
    91cc:      	orr	x28, x0, xzr
    91d0:      	add	x16, sp, #0x110
    91d4:      	ldr	x0, [x16, #0x10]
    91d8:      	cmp	x28, x0
    91dc:      	b.lt	0x9188 <_stogir.checked-schedule.cluster!+0x3d8>
    91e0:      	cmp	x0, #0x0
    91e4:      	b.ne	0x9178 <_stogir.checked-schedule.cluster!+0x3c8>
    91e8:      	mov	x0, #0x2                ; =2
    91ec:      	b	0x917c <_stogir.checked-schedule.cluster!+0x3cc>
    91f0:      	movz	w0, #0x0, lsl #16
    91f4:      	movz	w28, #0x0, lsl #16
    91f8:      	ubfx	x0, x0, #0, #32
    91fc:      	lsr	x16, x0, #0
    9200:      	cmp	x16, #0x1
    9204:      	b.eq	0x9220 <_stogir.checked-schedule.cluster!+0x470>
    9208:      	b.lo	0x9210 <_stogir.checked-schedule.cluster!+0x460>
    920c:      	b	0x9224 <_stogir.checked-schedule.cluster!+0x474>
    9210:      	cmp	x16, #0x0
    9214:      	b.eq	0x921c <_stogir.checked-schedule.cluster!+0x46c>
    9218:      	b	0x9224 <_stogir.checked-schedule.cluster!+0x474>
    921c:      	b	0x927c <_stogir.checked-schedule.cluster!+0x4cc>
    9220:      	b	0x9228 <_stogir.checked-schedule.cluster!+0x478>
    9224:      	b	0x9710 <_stogir.checked-schedule.cluster!+0x960>
    9228:      	sxtw	x0, w28
    922c:      	add	x16, sp, #0xe0
    9230:      	ldr	x1, [x16]
    9234:      	add	x1, x1, x0
    9238:      	ldrb	w1, [x1]
    923c:      	cmp	x1, #0x0
    9240:      	b.eq	0x93b0 <_stogir.checked-schedule.cluster!+0x600>
    9244:      	str	x21, [sp, #0x1d0]
    9248:      	str	x20, [sp, #0x1c8]
    924c:      	ldr	x21, [sp, #0x1d0]
    9250:      	ldr	x20, [sp, #0x1c8]
    9254:      	cmp	x26, x21
    9258:      	b.ge	0x91f0 <_stogir.checked-schedule.cluster!+0x440>
    925c:      	add	x0, x26, #0x1
    9260:      	add	x1, x20, x26, lsl #2
    9264:      	ldr	w1, [x1]
    9268:      	movn	w17, #0x0, lsl #16
    926c:      	and	w28, w1, w17
    9270:      	mov	x26, x0
    9274:      	mov	w0, #0x1                ; =1
    9278:      	b	0x91f8 <_stogir.checked-schedule.cluster!+0x448>
    927c:      	add	x16, sp, #0x110
    9280:      	ldr	x0, [x16, #0x8]
    9284:      	ldr	x1, [x19, #0x8]
    9288:      	cmp	x0, x1
    928c:      	b.ne	0x9110 <_stogir.checked-schedule.cluster!+0x360>
    9290:      	cmp	x25, #0x0
    9294:      	b.ne	0x92f4 <_stogir.checked-schedule.cluster!+0x544>
    9298:      	add	x8, sp, #0x170
    929c:      	ldr	x0, [sp, #0x1c0]
    92a0:      	add	x1, sp, #0x110
    92a4:      	bl	0x92a4 <_stogir.checked-schedule.cluster!+0x4f4>
		00000000000092a4:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    92a8:      	add	x16, sp, #0x170
    92ac:      	ldr	w0, [x16]
    92b0:      	lsr	x16, x0, #0
    92b4:      	cmp	x16, #0x1
    92b8:      	b.eq	0x92d4 <_stogir.checked-schedule.cluster!+0x524>
    92bc:      	b.lo	0x92c4 <_stogir.checked-schedule.cluster!+0x514>
    92c0:      	b	0x92d8 <_stogir.checked-schedule.cluster!+0x528>
    92c4:      	cmp	x16, #0x0
    92c8:      	b.eq	0x92d0 <_stogir.checked-schedule.cluster!+0x520>
    92cc:      	b	0x92d8 <_stogir.checked-schedule.cluster!+0x528>
    92d0:      	b	0x92f4 <_stogir.checked-schedule.cluster!+0x544>
    92d4:      	b	0x92dc <_stogir.checked-schedule.cluster!+0x52c>
    92d8:      	b	0x9728 <_stogir.checked-schedule.cluster!+0x978>
    92dc:      	add	x16, sp, #0x170
    92e0:      	orr	x0, x16, xzr
    92e4:      	add	x0, x0, #0x8
    92e8:      	add	x16, sp, #0x170
    92ec:      	ldr	x24, [x16, #0x8]
    92f0:      	ldr	x25, [x0, #0x8]
    92f4:      	add	x0, sp, #0x50
    92f8:      	bl	0x92f8 <_stogir.checked-schedule.cluster!+0x548>
		00000000000092f8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    92fc:      	add	x0, sp, #0x80
    9300:      	bl	0x9300 <_stogir.checked-schedule.cluster!+0x550>
		0000000000009300:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9304:      	add	x0, sp, #0xb0
    9308:      	bl	0x9308 <_stogir.checked-schedule.cluster!+0x558>
		0000000000009308:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    930c:      	add	x0, sp, #0xe0
    9310:      	bl	0x9310 <_stogir.checked-schedule.cluster!+0x560>
		0000000000009310:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__bool
    9314:      	cmp	x25, #0x0
    9318:      	b.ne	0x9100 <_stogir.checked-schedule.cluster!+0x350>
    931c:      	and	x24, x23, #0xffffffff
    9320:      	mov	x0, x19
    9324:      	bl	0x9324 <_stogir.checked-schedule.cluster!+0x574>
		0000000000009324:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$free!__i32
    9328:      	add	x16, sp, #0x110
    932c:      	ldr	x0, [x16]
    9330:      	add	x16, sp, #0x110
    9334:      	ldr	x1, [x16, #0x8]
    9338:      	add	x16, sp, #0x110
    933c:      	ldr	x2, [x16, #0x10]
    9340:      	add	x16, sp, #0x110
    9344:      	ldr	x3, [x16, #0x18]
    9348:      	add	x16, sp, #0x110
    934c:      	ldr	x4, [x16, #0x20]
    9350:      	str	x0, [x22, #0x28]
    9354:      	str	x1, [x19, #0x8]
    9358:      	str	x2, [x19, #0x10]
    935c:      	str	x3, [x19, #0x18]
    9360:      	str	x4, [x19, #0x20]
    9364:      	movz	x0, #0x0, lsl #48
    9368:      	movz	x25, #0x0, lsl #48
    936c:      	str	x0, [x27]
    9370:      	str	x24, [x27, #0x8]
    9374:      	str	x25, [x27, #0x10]
    9378:      	ldr	x19, [sp, #0x1d8]
    937c:      	ldr	x20, [sp, #0x1e0]
    9380:      	ldr	x21, [sp, #0x1e8]
    9384:      	ldr	x22, [sp, #0x1f0]
    9388:      	ldr	x23, [sp, #0x1f8]
    938c:      	ldr	x24, [sp, #0x200]
    9390:      	ldr	x25, [sp, #0x208]
    9394:      	ldr	x26, [sp, #0x210]
    9398:      	ldr	x27, [sp, #0x218]
    939c:      	ldr	x28, [sp, #0x220]
    93a0:      	ldr	x29, [sp]
    93a4:      	ldr	x30, [sp, #0x8]
    93a8:      	add	sp, sp, #0x230
    93ac:      	ret
    93b0:      	add	x16, sp, #0x110
    93b4:      	ldr	x1, [x16, #0x8]
    93b8:      	add	x16, sp, #0x110
    93bc:      	ldr	x2, [x16, #0x10]
    93c0:      	cmp	x1, x2
    93c4:      	b.lt	0x9778 <_stogir.checked-schedule.cluster!+0x9c8>
    93c8:      	cmp	x2, #0x0
    93cc:      	b.ne	0x9120 <_stogir.checked-schedule.cluster!+0x370>
    93d0:      	mov	x2, #0x2                ; =2
    93d4:      	b	0x9124 <_stogir.checked-schedule.cluster!+0x374>
    93d8:      	add	x16, sp, #0x150
    93dc:      	orr	x0, x16, xzr
    93e0:      	ldr	x1, [x22, #0x28]
    93e4:      	add	x20, x0, #0x8
    93e8:      	ldr	x0, [x19, #0x8]
    93ec:      	orr	x26, x1, xzr
    93f0:      	movz	x1, #0x0, lsl #48
    93f4:      	b	0x8fe4 <_stogir.checked-schedule.cluster!+0x234>
    93f8:      	lsl	x0, x0, #1
    93fc:      	mov	x1, x0
    9400:      	add	x0, sp, #0x50
    9404:      	bl	0x9404 <_stogir.checked-schedule.cluster!+0x654>
		0000000000009404:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9408:      	add	x0, x26, #0x1
    940c:      	add	x16, sp, #0x50
    9410:      	ldr	x1, [x16]
    9414:      	add	x1, x1, x26, lsl #2
    9418:      	movz	w17, #0x0, lsl #16
    941c:      	str	w17, [x1]
    9420:      	add	x16, sp, #0x50
    9424:      	str	x0, [x16, #0x8]
    9428:      	add	x16, sp, #0x80
    942c:      	ldr	x0, [x16, #0x8]
    9430:      	orr	x26, x0, xzr
    9434:      	add	x16, sp, #0x80
    9438:      	ldr	x0, [x16, #0x10]
    943c:      	cmp	x26, x0
    9440:      	b.lt	0x9464 <_stogir.checked-schedule.cluster!+0x6b4>
    9444:      	cmp	x0, #0x0
    9448:      	b.ne	0x9454 <_stogir.checked-schedule.cluster!+0x6a4>
    944c:      	mov	x0, #0x2                ; =2
    9450:      	b	0x9458 <_stogir.checked-schedule.cluster!+0x6a8>
    9454:      	lsl	x0, x0, #1
    9458:      	mov	x1, x0
    945c:      	add	x0, sp, #0x80
    9460:      	bl	0x9460 <_stogir.checked-schedule.cluster!+0x6b0>
		0000000000009460:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    9464:      	add	x0, x26, #0x1
    9468:      	add	x16, sp, #0x80
    946c:      	ldr	x1, [x16]
    9470:      	add	x1, x1, x26, lsl #2
    9474:      	movz	w17, #0x0, lsl #16
    9478:      	str	w17, [x1]
    947c:      	add	x16, sp, #0x80
    9480:      	str	x0, [x16, #0x8]
    9484:      	add	x16, sp, #0xb0
    9488:      	ldr	x0, [x16, #0x8]
    948c:      	orr	x26, x0, xzr
    9490:      	add	x16, sp, #0xb0
    9494:      	ldr	x0, [x16, #0x10]
    9498:      	cmp	x26, x0
    949c:      	b.lt	0x94c0 <_stogir.checked-schedule.cluster!+0x710>
    94a0:      	cmp	x0, #0x0
    94a4:      	b.ne	0x94b0 <_stogir.checked-schedule.cluster!+0x700>
    94a8:      	mov	x0, #0x2                ; =2
    94ac:      	b	0x94b4 <_stogir.checked-schedule.cluster!+0x704>
    94b0:      	lsl	x0, x0, #1
    94b4:      	mov	x1, x0
    94b8:      	add	x0, sp, #0xb0
    94bc:      	bl	0x94bc <_stogir.checked-schedule.cluster!+0x70c>
		00000000000094bc:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    94c0:      	add	x0, x26, #0x1
    94c4:      	add	x16, sp, #0xb0
    94c8:      	ldr	x1, [x16]
    94cc:      	add	x1, x1, x26, lsl #2
    94d0:      	movz	w17, #0x0, lsl #16
    94d4:      	str	w17, [x1]
    94d8:      	add	x16, sp, #0xb0
    94dc:      	str	x0, [x16, #0x8]
    94e0:      	add	x16, sp, #0xe0
    94e4:      	ldr	x0, [x16, #0x8]
    94e8:      	orr	x26, x0, xzr
    94ec:      	add	x16, sp, #0xe0
    94f0:      	ldr	x0, [x16, #0x10]
    94f4:      	cmp	x26, x0
    94f8:      	b.lt	0x951c <_stogir.checked-schedule.cluster!+0x76c>
    94fc:      	cmp	x0, #0x0
    9500:      	b.ne	0x950c <_stogir.checked-schedule.cluster!+0x75c>
    9504:      	mov	x0, #0x2                ; =2
    9508:      	b	0x9510 <_stogir.checked-schedule.cluster!+0x760>
    950c:      	lsl	x0, x0, #1
    9510:      	mov	x1, x0
    9514:      	add	x0, sp, #0xe0
    9518:      	bl	0x9518 <_stogir.checked-schedule.cluster!+0x768>
		0000000000009518:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    951c:      	add	x20, x20, #0x1
    9520:      	add	x0, x26, #0x1
    9524:      	add	x16, sp, #0xe0
    9528:      	ldr	x1, [x16]
    952c:      	add	x1, x1, x26
    9530:      	movz	w17, #0x0, lsl #16
    9534:      	strb	w17, [x1]
    9538:      	add	x16, sp, #0xe0
    953c:      	str	x0, [x16, #0x8]
    9540:      	ldr	x0, [x28, #0x8]
    9544:      	cmp	x20, x0
    9548:      	b.ge	0x93d8 <_stogir.checked-schedule.cluster!+0x628>
    954c:      	add	x16, sp, #0x50
    9550:      	ldr	x0, [x16, #0x8]
    9554:      	orr	x26, x0, xzr
    9558:      	add	x16, sp, #0x50
    955c:      	ldr	x0, [x16, #0x10]
    9560:      	cmp	x26, x0
    9564:      	b.lt	0x9408 <_stogir.checked-schedule.cluster!+0x658>
    9568:      	cmp	x0, #0x0
    956c:      	b.ne	0x93f8 <_stogir.checked-schedule.cluster!+0x648>
    9570:      	mov	x0, #0x2                ; =2
    9574:      	b	0x93fc <_stogir.checked-schedule.cluster!+0x64c>
    9578:      	ldr	x0, [x26]
    957c:      	ldr	x1, [x26, #0x8]
    9580:      	add	x16, sp, #0x50
    9584:      	movz	x17, #0x0, lsl #48
    9588:      	str	x17, [x16]
    958c:      	add	x16, sp, #0x50
    9590:      	movz	x17, #0x0, lsl #48
    9594:      	str	x17, [x16, #0x8]
    9598:      	add	x16, sp, #0x50
    959c:      	movz	x17, #0x0, lsl #48
    95a0:      	str	x17, [x16, #0x10]
    95a4:      	add	x16, sp, #0x50
    95a8:      	str	x0, [x16, #0x18]
    95ac:      	add	x16, sp, #0x50
    95b0:      	str	x1, [x16, #0x20]
    95b4:      	add	x16, sp, #0x80
    95b8:      	movz	x17, #0x0, lsl #48
    95bc:      	str	x17, [x16]
    95c0:      	add	x16, sp, #0x80
    95c4:      	movz	x17, #0x0, lsl #48
    95c8:      	str	x17, [x16, #0x8]
    95cc:      	add	x16, sp, #0x80
    95d0:      	movz	x17, #0x0, lsl #48
    95d4:      	str	x17, [x16, #0x10]
    95d8:      	add	x16, sp, #0x80
    95dc:      	str	x0, [x16, #0x18]
    95e0:      	add	x16, sp, #0x80
    95e4:      	str	x1, [x16, #0x20]
    95e8:      	add	x16, sp, #0xb0
    95ec:      	movz	x17, #0x0, lsl #48
    95f0:      	str	x17, [x16]
    95f4:      	add	x16, sp, #0xb0
    95f8:      	movz	x17, #0x0, lsl #48
    95fc:      	str	x17, [x16, #0x8]
    9600:      	add	x16, sp, #0xb0
    9604:      	movz	x17, #0x0, lsl #48
    9608:      	str	x17, [x16, #0x10]
    960c:      	add	x16, sp, #0xb0
    9610:      	str	x0, [x16, #0x18]
    9614:      	add	x16, sp, #0xb0
    9618:      	str	x1, [x16, #0x20]
    961c:      	add	x16, sp, #0xe0
    9620:      	movz	x17, #0x0, lsl #48
    9624:      	str	x17, [x16]
    9628:      	add	x16, sp, #0xe0
    962c:      	movz	x17, #0x0, lsl #48
    9630:      	str	x17, [x16, #0x8]
    9634:      	add	x16, sp, #0xe0
    9638:      	movz	x17, #0x0, lsl #48
    963c:      	str	x17, [x16, #0x10]
    9640:      	add	x16, sp, #0xe0
    9644:      	str	x0, [x16, #0x18]
    9648:      	add	x16, sp, #0xe0
    964c:      	str	x1, [x16, #0x20]
    9650:      	add	x16, sp, #0x110
    9654:      	movz	x17, #0x0, lsl #48
    9658:      	str	x17, [x16]
    965c:      	add	x16, sp, #0x110
    9660:      	movz	x17, #0x0, lsl #48
    9664:      	str	x17, [x16, #0x8]
    9668:      	add	x16, sp, #0x110
    966c:      	movz	x17, #0x0, lsl #48
    9670:      	str	x17, [x16, #0x10]
    9674:      	add	x16, sp, #0x110
    9678:      	str	x0, [x16, #0x18]
    967c:      	add	x16, sp, #0x110
    9680:      	str	x1, [x16, #0x20]
    9684:      	movz	x20, #0x0, lsl #48
    9688:      	b	0x9540 <_stogir.checked-schedule.cluster!+0x790>
    968c:      	add	x16, sp, #0x150
    9690:      	ldr	w0, [x16, #0x8]
    9694:      	sxtw	x0, w0
    9698:      	cmp	x0, #0x0
    969c:      	b.eq	0x8fd4 <_stogir.checked-schedule.cluster!+0x224>
    96a0:      	add	x16, sp, #0x140
    96a4:      	ldr	w0, [x16, #0x4]
    96a8:      	sxtw	x0, w0
    96ac:      	add	x16, sp, #0x80
    96b0:      	ldr	x1, [x16]
    96b4:      	add	x1, x1, x0, lsl #2
    96b8:      	ldr	w1, [x1]
    96bc:      	ldr	x2, [x21]
    96c0:      	orr	x3, x2, xzr
    96c4:      	add	x3, x3, x0, lsl #2
    96c8:      	add	x2, x2, x28, lsl #2
    96cc:      	ldr	w3, [x3]
    96d0:      	ldr	w2, [x2]
    96d4:      	sxtw	x3, w3
    96d8:      	sxtw	x2, w2
    96dc:      	cmp	x3, x2
    96e0:      	b.eq	0x96f0 <_stogir.checked-schedule.cluster!+0x940>
    96e4:      	adrp	x24, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		00000000000096e4:  ARM64_RELOC_PAGE21	l_stogir.450
    96e8:      	ldr	x24, [x24]
		00000000000096e8:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    96ec:      	mov	x25, #0x30              ; =48
    96f0:      	sxtw	x1, w1
    96f4:      	cmp	x1, #0x0
    96f8:      	b.ne	0x8fa0 <_stogir.checked-schedule.cluster!+0x1f0>
    96fc:      	add	x16, sp, #0x50
    9700:      	ldr	x1, [x16]
    9704:      	add	x1, x1, x0, lsl #2
    9708:      	str	w26, [x1]
    970c:      	b	0x8fb0 <_stogir.checked-schedule.cluster!+0x200>
    9710:      	brk	#0
    9714:      	b	0x9710 <_stogir.checked-schedule.cluster!+0x960>
    9718:      	brk	#0
    971c:      	b	0x9718 <_stogir.checked-schedule.cluster!+0x968>
    9720:      	brk	#0
    9724:      	b	0x9720 <_stogir.checked-schedule.cluster!+0x970>
    9728:      	brk	#0
    972c:      	b	0x9728 <_stogir.checked-schedule.cluster!+0x978>
    9730:      	brk	#0
    9734:      	b	0x9730 <_stogir.checked-schedule.cluster!+0x980>
    9738:      	brk	#0
    973c:      	b	0x9738 <_stogir.checked-schedule.cluster!+0x988>
    9740:      	mov	x27, x8
    9744:      	mov	x28, x0
    9748:      	str	x22, [sp, #0x198]
    974c:      	mov	x22, x2
    9750:      	str	x21, [sp, #0x190]
    9754:      	mov	x21, x1
    9758:      	str	x26, [sp, #0x1a0]
    975c:      	mov	x26, x3
    9760:      	b	0x8e3c <_stogir.checked-schedule.cluster!+0x8c>
    9764:      	str	x28, [sp, #0x1c0]
    9768:      	str	x0, [sp, #0x1a8]
    976c:      	str	x26, [sp, #0x1b8]
    9770:      	str	x1, [sp, #0x1b0]
    9774:      	b	0x8fd4 <_stogir.checked-schedule.cluster!+0x224>
    9778:      	str	x21, [sp, #0x1d0]
    977c:      	mov	x21, x1
    9780:      	str	x20, [sp, #0x1c8]
    9784:      	mov	x20, x0
    9788:      	b	0x9140 <_stogir.checked-schedule.cluster!+0x390>
    978c:      	udf	#0x0

0000000000009790 <_stogir.adjacency.release!>:
    9790:      	sub	sp, sp, #0x20
    9794:      	str	x29, [sp]
    9798:      	str	x30, [sp, #0x8]
    979c:      	mov	x29, sp
    97a0:      	str	x19, [sp, #0x10]
    97a4:      	str	x20, [sp, #0x18]
    97a8:      	b	0x97b8 <_stogir.adjacency.release!+0x28>
    97ac:      	nop
    97b0:      	sub	x1, x1, #0x1
    97b4:      	str	x1, [x0, #0x8]
    97b8:      	ldr	x1, [x0, #0x8]
    97bc:      	cmp	x1, #0x0
    97c0:      	b.ne	0x97b0 <_stogir.adjacency.release!+0x20>
    97c4:      	ldr	x1, [x0, #0x10]
    97c8:      	cmp	x1, #0x0
    97cc:      	b.le	0x989c <_stogir.adjacency.release!+0x10c>
    97d0:      	add	x2, x0, #0x18
    97d4:      	ldr	x3, [x0]
    97d8:      	mov	x19, x0
    97dc:      	mov	x0, x2
    97e0:      	mov	x2, x1
    97e4:      	mov	x1, x3
    97e8:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		00000000000097e8:  ARM64_RELOC_PAGE21	l_stogir.451
    97ec:      	ldr	x3, [x3]
		00000000000097ec:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    97f0:      	mov	x4, #0x10               ; =16
    97f4:      	mov	x5, #0x8                ; =8
    97f8:      	bl	0x97f8 <_stogir.adjacency.release!+0x68>
		00000000000097f8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    97fc:      	add	x20, x19, #0x28
    9800:      	movz	x17, #0x0, lsl #48
    9804:      	str	x17, [x19]
    9808:      	movz	x17, #0x0, lsl #48
    980c:      	str	x17, [x19, #0x8]
    9810:      	movz	x17, #0x0, lsl #48
    9814:      	str	x17, [x19, #0x10]
    9818:      	b	0x9828 <_stogir.adjacency.release!+0x98>
    981c:      	nop
    9820:      	sub	x0, x0, #0x1
    9824:      	str	x0, [x20, #0x8]
    9828:      	ldr	x0, [x20, #0x8]
    982c:      	cmp	x0, #0x0
    9830:      	b.ne	0x9820 <_stogir.adjacency.release!+0x90>
    9834:      	ldr	x0, [x20, #0x10]
    9838:      	cmp	x0, #0x0
    983c:      	b.le	0x986c <_stogir.adjacency.release!+0xdc>
    9840:      	add	x1, x20, #0x18
    9844:      	ldr	x2, [x19, #0x28]
    9848:      	fmov	d31, x0
    984c:      	mov	x0, x1
    9850:      	mov	x1, x2
    9854:      	fmov	x2, d31
    9858:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009858:  ARM64_RELOC_PAGE21	l_stogir.452
    985c:      	ldr	x3, [x3]
		000000000000985c:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9860:      	mov	x4, #0x8                ; =8
    9864:      	mov	x5, #0x8                ; =8
    9868:      	bl	0x9868 <_stogir.adjacency.release!+0xd8>
		0000000000009868:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    986c:      	movz	x17, #0x0, lsl #48
    9870:      	str	x17, [x19, #0x28]
    9874:      	movz	x17, #0x0, lsl #48
    9878:      	str	x17, [x20, #0x8]
    987c:      	movz	x17, #0x0, lsl #48
    9880:      	str	x17, [x20, #0x10]
    9884:      	ldr	x19, [sp, #0x10]
    9888:      	ldr	x20, [sp, #0x18]
    988c:      	ldr	x29, [sp]
    9890:      	ldr	x30, [sp, #0x8]
    9894:      	add	sp, sp, #0x20
    9898:      	ret
    989c:      	mov	x19, x0
    98a0:      	b	0x97fc <_stogir.adjacency.release!+0x6c>
    98a4:      	udf	#0x0

00000000000098a8 <_inherent$coil.arraylist.ArrayList$free!__bool>:
    98a8:      	sub	sp, sp, #0x20
    98ac:      	str	x29, [sp]
    98b0:      	str	x30, [sp, #0x8]
    98b4:      	mov	x29, sp
    98b8:      	str	x19, [sp, #0x10]
    98bc:      	b	0x98c8 <_inherent$coil.arraylist.ArrayList$free!__bool+0x20>
    98c0:      	sub	x1, x1, #0x1
    98c4:      	str	x1, [x0, #0x8]
    98c8:      	ldr	x1, [x0, #0x8]
    98cc:      	cmp	x1, #0x0
    98d0:      	b.ne	0x98c0 <_inherent$coil.arraylist.ArrayList$free!__bool+0x18>
    98d4:      	ldr	x1, [x0, #0x10]
    98d8:      	cmp	x1, #0x0
    98dc:      	b.le	0x993c <_inherent$coil.arraylist.ArrayList$free!__bool+0x94>
    98e0:      	add	x2, x0, #0x18
    98e4:      	ldr	x3, [x0]
    98e8:      	mov	x19, x0
    98ec:      	mov	x0, x2
    98f0:      	mov	x2, x1
    98f4:      	mov	x1, x3
    98f8:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		00000000000098f8:  ARM64_RELOC_PAGE21	l_stogir.453
    98fc:      	ldr	x3, [x3]
		00000000000098fc:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    9900:      	mov	x4, #0x1                ; =1
    9904:      	mov	x5, #0x1                ; =1
    9908:      	bl	0x9908 <_inherent$coil.arraylist.ArrayList$free!__bool+0x60>
		0000000000009908:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    990c:      	movz	x17, #0x0, lsl #48
    9910:      	str	x17, [x19]
    9914:      	movz	x17, #0x0, lsl #48
    9918:      	str	x17, [x19, #0x8]
    991c:      	movz	x17, #0x0, lsl #48
    9920:      	str	x17, [x19, #0x10]
    9924:      	movz	x0, #0x0, lsl #48
    9928:      	ldr	x19, [sp, #0x10]
    992c:      	ldr	x29, [sp]
    9930:      	ldr	x30, [sp, #0x8]
    9934:      	add	sp, sp, #0x20
    9938:      	ret
    993c:      	mov	x19, x0
    9940:      	b	0x990c <_inherent$coil.arraylist.ArrayList$free!__bool+0x64>
    9944:      	udf	#0x0

0000000000009948 <_stogir.uses.release!>:
    9948:      	sub	sp, sp, #0x20
    994c:      	str	x29, [sp]
    9950:      	str	x30, [sp, #0x8]
    9954:      	mov	x29, sp
    9958:      	str	x19, [sp, #0x10]
    995c:      	str	x20, [sp, #0x18]
    9960:      	b	0x9970 <_stogir.uses.release!+0x28>
    9964:      	nop
    9968:      	sub	x1, x1, #0x1
    996c:      	str	x1, [x0, #0x8]
    9970:      	ldr	x1, [x0, #0x8]
    9974:      	cmp	x1, #0x0
    9978:      	b.ne	0x9968 <_stogir.uses.release!+0x20>
    997c:      	ldr	x1, [x0, #0x10]
    9980:      	cmp	x1, #0x0
    9984:      	b.le	0x9a54 <_stogir.uses.release!+0x10c>
    9988:      	add	x2, x0, #0x18
    998c:      	ldr	x3, [x0]
    9990:      	mov	x19, x0
    9994:      	mov	x0, x2
    9998:      	mov	x2, x1
    999c:      	mov	x1, x3
    99a0:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		00000000000099a0:  ARM64_RELOC_PAGE21	l_stogir.454
    99a4:      	ldr	x3, [x3]
		00000000000099a4:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    99a8:      	mov	x4, #0x10               ; =16
    99ac:      	mov	x5, #0x8                ; =8
    99b0:      	bl	0x99b0 <_stogir.uses.release!+0x68>
		00000000000099b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    99b4:      	add	x20, x19, #0x28
    99b8:      	movz	x17, #0x0, lsl #48
    99bc:      	str	x17, [x19]
    99c0:      	movz	x17, #0x0, lsl #48
    99c4:      	str	x17, [x19, #0x8]
    99c8:      	movz	x17, #0x0, lsl #48
    99cc:      	str	x17, [x19, #0x10]
    99d0:      	b	0x99e0 <_stogir.uses.release!+0x98>
    99d4:      	nop
    99d8:      	sub	x0, x0, #0x1
    99dc:      	str	x0, [x20, #0x8]
    99e0:      	ldr	x0, [x20, #0x8]
    99e4:      	cmp	x0, #0x0
    99e8:      	b.ne	0x99d8 <_stogir.uses.release!+0x90>
    99ec:      	ldr	x0, [x20, #0x10]
    99f0:      	cmp	x0, #0x0
    99f4:      	b.le	0x9a24 <_stogir.uses.release!+0xdc>
    99f8:      	add	x1, x20, #0x18
    99fc:      	ldr	x2, [x19, #0x28]
    9a00:      	fmov	d31, x0
    9a04:      	mov	x0, x1
    9a08:      	mov	x1, x2
    9a0c:      	fmov	x2, d31
    9a10:      	adrp	x3, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009a10:  ARM64_RELOC_PAGE21	l_stogir.455
    9a14:      	ldr	x3, [x3]
		0000000000009a14:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    9a18:      	mov	x4, #0x8                ; =8
    9a1c:      	mov	x5, #0x4                ; =4
    9a20:      	bl	0x9a20 <_stogir.uses.release!+0xd8>
		0000000000009a20:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    9a24:      	movz	x17, #0x0, lsl #48
    9a28:      	str	x17, [x19, #0x28]
    9a2c:      	movz	x17, #0x0, lsl #48
    9a30:      	str	x17, [x20, #0x8]
    9a34:      	movz	x17, #0x0, lsl #48
    9a38:      	str	x17, [x20, #0x10]
    9a3c:      	ldr	x19, [sp, #0x10]
    9a40:      	ldr	x20, [sp, #0x18]
    9a44:      	ldr	x29, [sp]
    9a48:      	ldr	x30, [sp, #0x8]
    9a4c:      	add	sp, sp, #0x20
    9a50:      	ret
    9a54:      	mov	x19, x0
    9a58:      	b	0x99b4 <_stogir.uses.release!+0x6c>
    9a5c:      	udf	#0x0

0000000000009a60 <_stogir.verify.structure>:
    9a60:      	sub	sp, sp, #0x110
    9a64:      	str	x29, [sp, #0x10]
    9a68:      	str	x30, [sp, #0x18]
    9a6c:      	add	x29, sp, #0x10
    9a70:      	str	x19, [sp, #0xb8]
    9a74:      	str	x20, [sp, #0xc0]
    9a78:      	str	x21, [sp, #0xc8]
    9a7c:      	str	x22, [sp, #0xd0]
    9a80:      	str	x23, [sp, #0xd8]
    9a84:      	str	x24, [sp, #0xe0]
    9a88:      	str	x25, [sp, #0xe8]
    9a8c:      	str	x26, [sp, #0xf0]
    9a90:      	str	x27, [sp, #0xf8]
    9a94:      	str	x28, [sp, #0x100]
    9a98:      	mov	x19, x8
    9a9c:      	mov	x20, x0
    9aa0:      	bl	0x9aa0 <_stogir.verify.structure+0x40>
		0000000000009aa0:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
    9aa4:      	add	x21, x20, #0x78
    9aa8:      	mov	x22, x0
    9aac:      	mov	x0, x21
    9ab0:      	bl	0x9ab0 <_stogir.verify.structure+0x50>
		0000000000009ab0:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
    9ab4:      	cmp	x22, x0
    9ab8:      	b.ne	0x9ae8 <_stogir.verify.structure+0x88>
    9abc:      	adrp	x22, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009abc:  ARM64_RELOC_PAGE21	l_stogir.456
    9ac0:      	ldr	x22, [x22]
		0000000000009ac0:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9ac4:      	movz	x23, #0x0, lsl #48
    9ac8:      	b	0x9af4 <_stogir.verify.structure+0x94>
    9acc:      	ldr	x1, [sp, #0x88]
    9ad0:      	ldr	x5, [sp, #0x90]
    9ad4:      	add	x5, x1, x5
    9ad8:      	ldr	x19, [sp, #0x40]
    9adc:      	add	x1, x19, #0x1
    9ae0:      	sxtw	x19, w1
    9ae4:      	b	0x9b24 <_stogir.verify.structure+0xc4>
    9ae8:      	adrp	x22, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009ae8:  ARM64_RELOC_PAGE21	l_stogir.457
    9aec:      	ldr	x22, [x22]
		0000000000009aec:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    9af0:      	mov	x23, #0x2c              ; =44
    9af4:      	add	x24, x20, #0x110
    9af8:      	add	x25, x20, #0x28
    9afc:      	add	x26, x20, #0x50
    9b00:      	add	x27, x24, #0x28
    9b04:      	mov	x28, #0x1               ; =1
    9b08:      	movz	x0, #0x0, lsl #48
    9b0c:      	b	0x9b7c <_stogir.verify.structure+0x11c>
    9b10:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009b10:  ARM64_RELOC_PAGE21	l_stogir.458
    9b14:      	ldr	x16, [x16]
		0000000000009b14:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    9b18:      	str	x16, [sp, #0x38]
    9b1c:      	mov	x16, #0x16              ; =22
    9b20:      	str	x16, [sp, #0x80]
    9b24:      	b	0x9b58 <_stogir.verify.structure+0xf8>
    9b28:      	mov	x5, x28
    9b2c:      	str	x19, [sp, #0x30]
    9b30:      	mov	x19, x0
    9b34:      	mov	x0, x21
    9b38:      	mov	x2, x24
    9b3c:      	mov	x3, x25
    9b40:      	mov	x4, x26
    9b44:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009b44:  ARM64_RELOC_PAGE21	l_stogir.459
    9b48:      	ldr	x16, [x16]
		0000000000009b48:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    9b4c:      	str	x16, [sp, #0x38]
    9b50:      	mov	x16, #0x23              ; =35
    9b54:      	str	x16, [sp, #0x80]
    9b58:      	mov	x21, x0
    9b5c:      	mov	x24, x2
    9b60:      	mov	x25, x3
    9b64:      	mov	x26, x4
    9b68:      	mov	x28, x5
    9b6c:      	mov	x0, x19
    9b70:      	ldr	x19, [sp, #0x30]
    9b74:      	ldr	x22, [sp, #0x38]
    9b78:      	ldr	x23, [sp, #0x80]
    9b7c:      	cmp	x23, #0x0
    9b80:      	b.ne	0xa33c <_stogir.verify.structure+0x8dc>
    9b84:      	ldr	x1, [x20, #0x8]
    9b88:      	cmp	x28, x1
    9b8c:      	b.ge	0xa350 <_stogir.verify.structure+0x8f0>
    9b90:      	ldr	x1, [x20]
    9b94:      	add	x1, x1, x28, lsl #4
    9b98:      	ldr	x1, [x1]
    9b9c:      	ldr	x2, [x20, #0x78]
    9ba0:      	add	x2, x2, x28, lsl #2
    9ba4:      	ldr	w2, [x2]
    9ba8:      	sxtw	x2, w2
    9bac:      	cmp	x2, #0x0
    9bb0:      	b.lt	0x9b28 <_stogir.verify.structure+0xc8>
    9bb4:      	mov	x17, #0xffff            ; =65535
    9bb8:      	cmp	x2, x17
    9bbc:      	b.gt	0xa364 <_stogir.verify.structure+0x904>
    9bc0:      	uxtb	w3, w1
    9bc4:      	orr	x4, x3, xzr
    9bc8:      	cmp	x4, #0x83
    9bcc:      	cset	w5, lt
    9bd0:      	uxtb	w16, w5
    9bd4:      	cmp	w16, wzr
    9bd8:      	b.eq	0xa384 <_stogir.verify.structure+0x924>
    9bdc:      	ubfx	x1, x1, #0, #32
    9be0:      	ubfx	x6, x1, #8, #8
    9be4:      	orr	x7, x6, xzr
    9be8:      	str	x0, [sp, #0x40]
    9bec:      	mov	w0, w7
    9bf0:      	str	x19, [sp, #0x30]
    9bf4:      	mov	w19, w3
    9bf8:      	str	x22, [sp, #0x38]
    9bfc:      	mov	x22, x2
    9c00:      	str	x26, [sp, #0x48]
    9c04:      	mov	x26, x4
    9c08:      	str	x25, [sp, #0x50]
    9c0c:      	mov	w25, w5
    9c10:      	str	x21, [sp, #0x58]
    9c14:      	mov	x21, x1
    9c18:      	str	x24, [sp, #0x60]
    9c1c:      	mov	w24, w6
    9c20:      	bl	0x9c20 <_stogir.verify.structure+0x1c0>
		0000000000009c20:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    9c24:      	cmp	x0, #0x0
    9c28:      	b.eq	0xa3a4 <_stogir.verify.structure+0x944>
    9c2c:      	adrp	x17, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009c2c:  ARM64_RELOC_PAGE21	l_stogir.460
    9c30:      	ldr	x17, [x17]
		0000000000009c30:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    9c34:      	add	x0, x26, x17
    9c38:      	ldrsb	w0, [x0]
    9c3c:      	sxtb	x0, w0
    9c40:      	cmp	x0, #0x0
    9c44:      	b.lt	0xa05c <_stogir.verify.structure+0x5fc>
    9c48:      	uxtb	w16, w25
    9c4c:      	cmp	w16, wzr
    9c50:      	b.eq	0xa130 <_stogir.verify.structure+0x6d0>
    9c54:      	adrp	x17, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009c54:  ARM64_RELOC_PAGE21	l_stogir.460
    9c58:      	ldr	x17, [x17]
		0000000000009c58:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    9c5c:      	add	x0, x26, x17
    9c60:      	ldrsb	w0, [x0]
    9c64:      	sxtb	w0, w0
    9c68:      	b	0xa134 <_stogir.verify.structure+0x6d4>
    9c6c:      	ldr	x0, [sp, #0x38]
    9c70:      	ldr	x1, [sp, #0x80]
    9c74:      	adrp	x2, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009c74:  ARM64_RELOC_PAGE21	l_stogir.456
    9c78:      	ldr	x2, [x2]
		0000000000009c78:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9c7c:      	movz	x3, #0x0, lsl #48
    9c80:      	bl	0x9c80 <_stogir.verify.structure+0x220>
		0000000000009c80:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
    9c84:      	cmp	x0, #0x0
    9c88:      	b.eq	0xa3c0 <_stogir.verify.structure+0x960>
    9c8c:      	and	x0, x19, #0xffffffff
    9c90:      	movz	x1, #0x0, lsl #48
    9c94:      	movz	x16, #0x0, lsl #48
    9c98:      	str	x16, [sp, #0x80]
    9c9c:      	b	0x9ca4 <_stogir.verify.structure+0x244>
    9ca0:      	mov	x1, #0x1                ; =1
    9ca4:      	ldr	x2, [sp, #0x30]
    9ca8:      	str	x1, [x2]
    9cac:      	str	x0, [x2, #0x8]
    9cb0:      	ldr	x0, [sp, #0x80]
    9cb4:      	str	x0, [x2, #0x10]
    9cb8:      	ldr	x19, [sp, #0xb8]
    9cbc:      	ldr	x20, [sp, #0xc0]
    9cc0:      	ldr	x21, [sp, #0xc8]
    9cc4:      	ldr	x22, [sp, #0xd0]
    9cc8:      	ldr	x23, [sp, #0xd8]
    9ccc:      	ldr	x24, [sp, #0xe0]
    9cd0:      	ldr	x25, [sp, #0xe8]
    9cd4:      	ldr	x26, [sp, #0xf0]
    9cd8:      	ldr	x27, [sp, #0xf8]
    9cdc:      	ldr	x28, [sp, #0x100]
    9ce0:      	ldr	x29, [sp, #0x10]
    9ce4:      	ldr	x30, [sp, #0x18]
    9ce8:      	add	sp, sp, #0x110
    9cec:      	ret
    9cf0:      	mov	w9, w5
    9cf4:      	lsl	w9, w9, #2
    9cf8:      	ubfx	x9, x9, #0, #32
    9cfc:      	lsr	x8, x8, x9
    9d00:      	and	w8, w8, #0xf
    9d04:      	b	0x9d24 <_stogir.verify.structure+0x2c4>
    9d08:      	movz	x1, #0x0, lsl #48
    9d0c:      	cmp	x1, #0x0
    9d10:      	b.eq	0xa170 <_stogir.verify.structure+0x710>
    9d14:      	ldr	w1, [sp, #0xb0]
    9d18:      	ldr	w5, [sp, #0xa8]
    9d1c:      	b	0x9dcc <_stogir.verify.structure+0x36c>
    9d20:      	movz	w8, #0x0, lsl #16
    9d24:      	b	0x9d2c <_stogir.verify.structure+0x2cc>
    9d28:      	movz	w8, #0x0, lsl #16
    9d2c:      	str	w0, [sp, #0x68]
    9d30:      	str	x2, [sp, #0x98]
    9d34:      	mov	w2, w3
    9d38:      	str	x4, [sp, #0xa0]
    9d3c:      	str	x22, [sp, #0x70]
    9d40:      	mov	x22, x1
    9d44:      	mov	w1, w0
    9d48:      	mov	x0, x20
    9d4c:      	str	x26, [sp, #0x78]
    9d50:      	mov	w26, w7
    9d54:      	str	x23, [sp, #0x80]
    9d58:      	mov	w23, w8
    9d5c:      	str	x19, [sp, #0x88]
    9d60:      	mov	w19, w5
    9d64:      	str	x28, [sp, #0x90]
    9d68:      	mov	w28, w6
    9d6c:      	bl	0x9d6c <_stogir.verify.structure+0x30c>
		0000000000009d6c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    9d70:      	ubfx	x0, x0, #0, #32
    9d74:      	lsr	x16, x0, #0
    9d78:      	cmp	x16, #0x1
    9d7c:      	b.eq	0x9d98 <_stogir.verify.structure+0x338>
    9d80:      	b.lo	0x9d88 <_stogir.verify.structure+0x328>
    9d84:      	b	0x9d9c <_stogir.verify.structure+0x33c>
    9d88:      	cmp	x16, #0x0
    9d8c:      	b.eq	0x9d94 <_stogir.verify.structure+0x334>
    9d90:      	b	0x9d9c <_stogir.verify.structure+0x33c>
    9d94:      	b	0x9da0 <_stogir.verify.structure+0x340>
    9d98:      	b	0x9e80 <_stogir.verify.structure+0x420>
    9d9c:      	b	0xa2a4 <_stogir.verify.structure+0x844>
    9da0:      	ldr	x0, [sp, #0x58]
    9da4:      	ldr	x2, [sp, #0x60]
    9da8:      	mov	w1, w21
    9dac:      	mov	w5, w24
    9db0:      	ldr	x3, [sp, #0x50]
    9db4:      	ldr	x4, [sp, #0x48]
    9db8:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009db8:  ARM64_RELOC_PAGE21	l_stogir.461
    9dbc:      	ldr	x16, [x16]
		0000000000009dbc:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    9dc0:      	str	x16, [sp, #0x38]
    9dc4:      	mov	x16, #0x17              ; =23
    9dc8:      	str	x16, [sp, #0x80]
    9dcc:      	ldr	x6, [sp, #0x98]
    9dd0:      	add	x6, x6, #0x1
    9dd4:      	sxtw	x6, w6
    9dd8:      	ldr	x28, [sp, #0x90]
    9ddc:      	str	x0, [sp, #0x58]
    9de0:      	ldr	x19, [sp, #0x88]
    9de4:      	ldr	w0, [sp, #0x68]
    9de8:      	str	x2, [sp, #0x60]
    9dec:      	ldr	x26, [sp, #0x78]
    9df0:      	mov	w21, w1
    9df4:      	mov	w24, w5
    9df8:      	mov	x1, x22
    9dfc:      	ldr	x22, [sp, #0x70]
    9e00:      	str	x3, [sp, #0x50]
    9e04:      	str	x4, [sp, #0x48]
    9e08:      	mov	x2, x6
    9e0c:      	ldr	x23, [sp, #0x80]
    9e10:      	cmp	x23, #0x0
    9e14:      	b.ne	0x9e28 <_stogir.verify.structure+0x3c8>
    9e18:      	cmp	x2, x22
    9e1c:      	cset	w3, le
    9e20:      	ubfx	x3, x3, #0, #8
    9e24:      	b	0x9e2c <_stogir.verify.structure+0x3cc>
    9e28:      	movz	x3, #0x0, lsl #48
    9e2c:      	cmp	x3, #0x0
    9e30:      	b.eq	0xa3c8 <_stogir.verify.structure+0x968>
    9e34:      	orr	w3, w2, wzr
    9e38:      	sxtw	x4, w3
    9e3c:      	sub	w5, w3, #0x1
    9e40:      	cmp	x4, #0x0
    9e44:      	cset	w6, gt
    9e48:      	cmp	x4, #0x4
    9e4c:      	cset	w7, gt
    9e50:      	uxtb	w16, w25
    9e54:      	cmp	w16, wzr
    9e58:      	b.eq	0x9d28 <_stogir.verify.structure+0x2c8>
    9e5c:      	ldr	w8, [x26]
    9e60:      	uxtb	w16, w6
    9e64:      	cmp	w16, wzr
    9e68:      	b.eq	0x9d20 <_stogir.verify.structure+0x2c0>
    9e6c:      	uxtb	w16, w7
    9e70:      	cmp	w16, wzr
    9e74:      	b.eq	0x9cf0 <_stogir.verify.structure+0x290>
    9e78:      	mov	w9, #0x4                ; =4
    9e7c:      	b	0x9cf4 <_stogir.verify.structure+0x294>
    9e80:      	ubfx	x23, x23, #0, #32
    9e84:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009e84:  ARM64_RELOC_PAGE21	l_stogir.462
    9e88:      	ldr	x16, [x16]
		0000000000009e88:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    9e8c:      	ldr	w0, [x16]
    9e90:      	cmp	x23, x0
    9e94:      	b.ne	0x9ea8 <_stogir.verify.structure+0x448>
    9e98:      	mov	x0, #0x1                ; =1
    9e9c:      	b	0x9ec0 <_stogir.verify.structure+0x460>
    9ea0:      	movz	x1, #0x0, lsl #48
    9ea4:      	b	0x9f20 <_stogir.verify.structure+0x4c0>
    9ea8:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009ea8:  ARM64_RELOC_PAGE21	l_stogir.463
    9eac:      	ldr	x16, [x16]
		0000000000009eac:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    9eb0:      	ldr	w0, [x16]
    9eb4:      	cmp	x23, x0
    9eb8:      	cset	w0, eq
    9ebc:      	ubfx	x0, x0, #0, #8
    9ec0:      	cmp	x0, #0x0
    9ec4:      	b.eq	0xa3e8 <_stogir.verify.structure+0x988>
    9ec8:      	str	w24, [sp, #0xa8]
    9ecc:      	mov	x24, x0
    9ed0:      	mov	x0, x20
    9ed4:      	str	w21, [sp, #0xb0]
    9ed8:      	mov	w21, w1
    9edc:      	bl	0x9edc <_stogir.verify.structure+0x47c>
		0000000000009edc:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    9ee0:      	cmp	x0, #0x0
    9ee4:      	cset	w1, eq
    9ee8:      	uxtb	w16, w1
    9eec:      	cmp	w16, wzr
    9ef0:      	cset	x1, eq
    9ef4:      	cmp	x1, #0x0
    9ef8:      	b.eq	0x9f20 <_stogir.verify.structure+0x4c0>
    9efc:      	ldr	w0, [x0]
    9f00:      	uxtb	w0, w0
    9f04:      	cmp	x0, #0x48
    9f08:      	b.ne	0x9f20 <_stogir.verify.structure+0x4c0>
    9f0c:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009f0c:  ARM64_RELOC_PAGE21	l_stogir.464
    9f10:      	ldr	x16, [x16]
		0000000000009f10:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    9f14:      	str	x16, [sp, #0x38]
    9f18:      	mov	x16, #0x25              ; =37
    9f1c:      	str	x16, [sp, #0x80]
    9f20:      	sxtw	x21, w21
    9f24:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009f24:  ARM64_RELOC_PAGE21	l_stogir.465
    9f28:      	ldr	x16, [x16]
		0000000000009f28:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    9f2c:      	ldr	w0, [x16]
    9f30:      	cmp	x23, x0
    9f34:      	b.ne	0xa3fc <_stogir.verify.structure+0x99c>
    9f38:      	cmp	x21, #0x0
    9f3c:      	b.gt	0xa0cc <_stogir.verify.structure+0x66c>
    9f40:      	ldr	x2, [sp, #0x60]
    9f44:      	movz	w0, #0x0, lsl #16
    9f48:      	ubfx	x0, x0, #0, #32
    9f4c:      	lsr	x16, x0, #0
    9f50:      	cmp	x16, #0x1
    9f54:      	b.eq	0x9f70 <_stogir.verify.structure+0x510>
    9f58:      	b.lo	0x9f60 <_stogir.verify.structure+0x500>
    9f5c:      	b	0x9f74 <_stogir.verify.structure+0x514>
    9f60:      	cmp	x16, #0x0
    9f64:      	b.eq	0x9f6c <_stogir.verify.structure+0x50c>
    9f68:      	b	0x9f74 <_stogir.verify.structure+0x514>
    9f6c:      	b	0x9f78 <_stogir.verify.structure+0x518>
    9f70:      	b	0x9f8c <_stogir.verify.structure+0x52c>
    9f74:      	b	0xa334 <_stogir.verify.structure+0x8d4>
    9f78:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009f78:  ARM64_RELOC_PAGE21	l_stogir.466
    9f7c:      	ldr	x16, [x16]
		0000000000009f7c:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    9f80:      	str	x16, [sp, #0x38]
    9f84:      	mov	x16, #0x21              ; =33
    9f88:      	str	x16, [sp, #0x80]
    9f8c:      	cmp	x23, #0xf
    9f90:      	b.hs	0xa404 <_stogir.verify.structure+0x9a4>
    9f94:      	mov	x16, #0x1               ; =1
    9f98:      	lsl	x0, x16, x23
    9f9c:      	mov	w17, #0x5e1c            ; =24092
    9fa0:      	and	w0, w0, w17
    9fa4:      	ubfx	x0, x0, #0, #32
    9fa8:      	cmp	x0, #0x0
    9fac:      	b.eq	0xa41c <_stogir.verify.structure+0x9bc>
    9fb0:      	cmp	x24, #0x0
    9fb4:      	b.eq	0xa1b8 <_stogir.verify.structure+0x758>
    9fb8:      	ldr	x0, [sp, #0x58]
    9fbc:      	ldr	x3, [sp, #0x50]
    9fc0:      	ldr	x4, [sp, #0x48]
    9fc4:      	b	0x9d0c <_stogir.verify.structure+0x2ac>
    9fc8:      	orr	w0, w28, wzr
    9fcc:      	cmp	x26, #0x78
    9fd0:      	cset	w21, eq
    9fd4:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009fd4:  ARM64_RELOC_PAGE21	l_stogir.467
    9fd8:      	ldr	x16, [x16]
		0000000000009fd8:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    9fdc:      	add	x1, x16, x26, lsl #2
    9fe0:      	adrp	x16, 0x9000 <_stogir.checked-schedule.cluster!+0x250>
		0000000000009fe0:  ARM64_RELOC_PAGE21	l_stogir.467
    9fe4:      	ldr	x16, [x16]
		0000000000009fe4:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    9fe8:      	add	x2, x16, x26, lsl #2
    9fec:      	cmp	x24, #0x0
    9ff0:      	cset	w24, eq
    9ff4:      	orr	x26, x1, xzr
    9ff8:      	orr	x1, x2, xzr
    9ffc:      	mov	x2, #0x1                ; =1
    a000:      	b	0x9e10 <_stogir.verify.structure+0x3b0>
    a004:      	nop
    a008:      	movz	x1, #0x0, lsl #48
    a00c:      	cmp	x1, #0x0
    a010:      	b.eq	0x9fc8 <_stogir.verify.structure+0x568>
    a014:      	add	x1, x0, x28
    a018:      	ldr	x2, [x20, #0x78]
    a01c:      	add	x1, x2, x1, lsl #2
    a020:      	ldr	w1, [x1]
    a024:      	sxtw	x1, w1
    a028:      	cmn	x1, #0x1
    a02c:      	b.eq	0xa040 <_stogir.verify.structure+0x5e0>
    a030:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a030:  ARM64_RELOC_PAGE21	l_stogir.468
    a034:      	ldr	x16, [x16]
		000000000000a034:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    a038:      	str	x16, [sp, #0x38]
    a03c:      	mov	x23, #0x1b              ; =27
    a040:      	add	x0, x0, #0x1
    a044:      	cmp	x23, #0x0
    a048:      	b.ne	0xa008 <_stogir.verify.structure+0x5a8>
    a04c:      	cmp	x0, x19
    a050:      	cset	w1, lt
    a054:      	ubfx	x1, x1, #0, #8
    a058:      	b	0xa00c <_stogir.verify.structure+0x5ac>
    a05c:      	mov	w0, w19
    a060:      	bl	0xa060 <_stogir.verify.structure+0x600>
		000000000000a060:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
    a064:      	sxtw	x0, w0
    a068:      	cmn	x0, #0x1
    a06c:      	b.ne	0xa08c <_stogir.verify.structure+0x62c>
    a070:      	ubfx	x0, x21, #16, #16
    a074:      	cmp	x22, x0
    a078:      	b.eq	0xa08c <_stogir.verify.structure+0x62c>
    a07c:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a07c:  ARM64_RELOC_PAGE21	l_stogir.469
    a080:      	ldr	x16, [x16]
		000000000000a080:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a084:      	str	x16, [sp, #0x38]
    a088:      	mov	x23, #0x24              ; =36
    a08c:      	add	x0, x22, #0x4
    a090:      	ldr	x1, [x20, #0x8]
    a094:      	asr	x16, x0, #63
    a098:      	lsr	x16, x16, #62
    a09c:      	add	x0, x0, x16
    a0a0:      	asr	x0, x0, #2
    a0a4:      	orr	x19, x0, xzr
    a0a8:      	add	x0, x19, x28
    a0ac:      	cmp	x0, x1
    a0b0:      	b.le	0xa0c4 <_stogir.verify.structure+0x664>
    a0b4:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a0b4:  ARM64_RELOC_PAGE21	l_stogir.470
    a0b8:      	ldr	x16, [x16]
		000000000000a0b8:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    a0bc:      	str	x16, [sp, #0x38]
    a0c0:      	mov	x23, #0x15              ; =21
    a0c4:      	mov	x0, #0x1                ; =1
    a0c8:      	b	0xa044 <_stogir.verify.structure+0x5e4>
    a0cc:      	ldr	x0, [x27, #0x8]
    a0d0:      	cmp	x21, x0
    a0d4:      	b.gt	0xa434 <_stogir.verify.structure+0x9d4>
    a0d8:      	sub	x0, x21, #0x1
    a0dc:      	ldr	x2, [sp, #0x60]
    a0e0:      	ldr	x3, [x2, #0x28]
    a0e4:      	mov	x17, #0x18              ; =24
    a0e8:      	mul	x0, x0, x17
    a0ec:      	add	x0, x0, x3
    a0f0:      	ldr	x3, [x0]
    a0f4:      	ldr	x0, [x0, #0x8]
    a0f8:      	ldr	x4, [x2, #0x8]
    a0fc:      	cmp	x3, #0x0
    a100:      	b.lt	0xa128 <_stogir.verify.structure+0x6c8>
    a104:      	cmp	x3, x4
    a108:      	b.gt	0xa128 <_stogir.verify.structure+0x6c8>
    a10c:      	cmp	x0, #0x0
    a110:      	b.lt	0xa128 <_stogir.verify.structure+0x6c8>
    a114:      	sub	x3, x4, x3
    a118:      	cmp	x0, x3
    a11c:      	b.gt	0xa128 <_stogir.verify.structure+0x6c8>
    a120:      	mov	w0, #0x1                ; =1
    a124:      	b	0xa12c <_stogir.verify.structure+0x6cc>
    a128:      	movz	w0, #0x0, lsl #16
    a12c:      	b	0x9f48 <_stogir.verify.structure+0x4e8>
    a130:      	mov	w0, #-0x2               ; =-2
    a134:      	sxtw	x0, w0
    a138:      	cmp	x22, x0
    a13c:      	b.eq	0xa05c <_stogir.verify.structure+0x5fc>
    a140:      	ldr	x0, [sp, #0x58]
    a144:      	ldr	x2, [sp, #0x60]
    a148:      	ldr	x3, [sp, #0x50]
    a14c:      	ldr	x4, [sp, #0x48]
    a150:      	mov	x5, x28
    a154:      	ldr	x19, [sp, #0x40]
    a158:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a158:  ARM64_RELOC_PAGE21	l_stogir.471
    a15c:      	ldr	x16, [x16]
		000000000000a15c:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    a160:      	str	x16, [sp, #0x38]
    a164:      	mov	x16, #0x23              ; =35
    a168:      	str	x16, [sp, #0x80]
    a16c:      	b	0x9ae4 <_stogir.verify.structure+0x84>
    a170:      	cmp	x21, #0x0
    a174:      	b.ne	0xa43c <_stogir.verify.structure+0x9dc>
    a178:      	uxtb	w16, w25
    a17c:      	cmp	w16, wzr
    a180:      	b.eq	0xa2ac <_stogir.verify.structure+0x84c>
    a184:      	ldr	w1, [x22]
    a188:      	uxtb	w16, w28
    a18c:      	cmp	w16, wzr
    a190:      	b.eq	0xa2f4 <_stogir.verify.structure+0x894>
    a194:      	uxtb	w16, w26
    a198:      	cmp	w16, wzr
    a19c:      	b.eq	0xa1a4 <_stogir.verify.structure+0x744>
    a1a0:      	mov	w19, #0x4               ; =4
    a1a4:      	lsl	w5, w19, #2
    a1a8:      	ubfx	x5, x5, #0, #32
    a1ac:      	lsr	x1, x1, x5
    a1b0:      	and	w1, w1, #0xf
    a1b4:      	b	0xa2f8 <_stogir.verify.structure+0x898>
    a1b8:      	cmp	x21, #0x0
    a1bc:      	b.le	0xa448 <_stogir.verify.structure+0x9e8>
    a1c0:      	ldr	x0, [x20, #0x8]
    a1c4:      	cmp	x21, x0
    a1c8:      	b.ge	0xa450 <_stogir.verify.structure+0x9f0>
    a1cc:      	ldr	x0, [sp, #0x58]
    a1d0:      	ldr	x1, [x0, #0x8]
    a1d4:      	cmp	x21, x1
    a1d8:      	b.ge	0xa304 <_stogir.verify.structure+0x8a4>
    a1dc:      	ldr	x1, [x20, #0x78]
    a1e0:      	add	x1, x1, x21, lsl #2
    a1e4:      	ldr	w1, [x1]
    a1e8:      	sxtw	x1, w1
    a1ec:      	cmp	x1, #0x0
    a1f0:      	cset	w1, ge
    a1f4:      	ubfx	x1, x1, #0, #8
    a1f8:      	b	0xa308 <_stogir.verify.structure+0x8a8>
    a1fc:      	ldr	w1, [sp, #0xb0]
    a200:      	uxtb	w16, w1
    a204:      	cmp	w16, wzr
    a208:      	b.eq	0xa458 <_stogir.verify.structure+0x9f8>
    a20c:      	ldr	w5, [sp, #0xa8]
    a210:      	uxtb	w16, w5
    a214:      	cmp	w16, wzr
    a218:      	b.eq	0xa228 <_stogir.verify.structure+0x7c8>
    a21c:      	ldr	x6, [sp, #0xa0]
    a220:      	cmp	x6, #0x2
    a224:      	b.eq	0x9d1c <_stogir.verify.structure+0x2bc>
    a228:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a228:  ARM64_RELOC_PAGE21	l_stogir.472
    a22c:      	ldr	x16, [x16]
		000000000000a22c:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    a230:      	str	x16, [sp, #0x38]
    a234:      	mov	x16, #0x1a              ; =26
    a238:      	str	x16, [sp, #0x80]
    a23c:      	b	0x9d1c <_stogir.verify.structure+0x2bc>
    a240:      	movz	x1, #0x0, lsl #48
    a244:      	ldr	x3, [sp, #0x50]
    a248:      	ldr	x4, [sp, #0x48]
    a24c:      	b	0x9d0c <_stogir.verify.structure+0x2ac>
    a250:      	cmp	x21, #0x0
    a254:      	b.ge	0xa460 <_stogir.verify.structure+0xa00>
    a258:      	ldr	x3, [sp, #0x50]
    a25c:      	ldr	x1, [x3, #0x8]
    a260:      	ldr	x4, [sp, #0x48]
    a264:      	ldr	x5, [x4, #0x8]
    a268:      	cmp	x1, x5
    a26c:      	b.ne	0xa2fc <_stogir.verify.structure+0x89c>
    a270:      	movz	x16, #0x0, lsl #48
    a274:      	sub	x5, x16, x21
    a278:      	cmp	x5, x1
    a27c:      	b.gt	0xa32c <_stogir.verify.structure+0x8cc>
    a280:      	sub	x1, x5, #0x1
    a284:      	ldr	x5, [x20, #0x50]
    a288:      	add	x1, x5, x1, lsl #2
    a28c:      	ldr	w1, [x1]
    a290:      	sxtw	x1, w1
    a294:      	cmp	x1, #0x0
    a298:      	cset	w1, gt
    a29c:      	ubfx	x1, x1, #0, #8
    a2a0:      	b	0xa330 <_stogir.verify.structure+0x8d0>
    a2a4:      	brk	#0
    a2a8:      	b	0xa2a4 <_stogir.verify.structure+0x844>
    a2ac:      	movz	w1, #0x0, lsl #16
    a2b0:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a2b0:  ARM64_RELOC_PAGE21	l_stogir.473
    a2b4:      	ldr	x16, [x16]
		000000000000a2b4:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    a2b8:      	ldr	w5, [x16]
    a2bc:      	ubfx	x1, x1, #0, #32
    a2c0:      	cmp	x1, x5
    a2c4:      	b.ne	0xa2d4 <_stogir.verify.structure+0x874>
    a2c8:      	ldr	w1, [sp, #0xb0]
    a2cc:      	ldr	w5, [sp, #0xa8]
    a2d0:      	b	0x9d1c <_stogir.verify.structure+0x2bc>
    a2d4:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a2d4:  ARM64_RELOC_PAGE21	l_stogir.474
    a2d8:      	ldr	x16, [x16]
		000000000000a2d8:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    a2dc:      	ldr	w5, [x16]
    a2e0:      	cmp	x1, x5
    a2e4:      	b.ne	0xa30c <_stogir.verify.structure+0x8ac>
    a2e8:      	ldr	w1, [sp, #0xb0]
    a2ec:      	ldr	w5, [sp, #0xa8]
    a2f0:      	b	0x9d1c <_stogir.verify.structure+0x2bc>
    a2f4:      	movz	w1, #0x0, lsl #16
    a2f8:      	b	0xa2b0 <_stogir.verify.structure+0x850>
    a2fc:      	movz	x1, #0x0, lsl #48
    a300:      	b	0x9d0c <_stogir.verify.structure+0x2ac>
    a304:      	movz	x1, #0x0, lsl #48
    a308:      	b	0xa244 <_stogir.verify.structure+0x7e4>
    a30c:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a30c:  ARM64_RELOC_PAGE21	l_stogir.475
    a310:      	ldr	x16, [x16]
		000000000000a310:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    a314:      	ldr	w5, [x16]
    a318:      	cmp	x1, x5
    a31c:      	b.ne	0xa1fc <_stogir.verify.structure+0x79c>
    a320:      	ldr	w1, [sp, #0xb0]
    a324:      	ldr	w5, [sp, #0xa8]
    a328:      	b	0x9d1c <_stogir.verify.structure+0x2bc>
    a32c:      	movz	x1, #0x0, lsl #48
    a330:      	b	0xa300 <_stogir.verify.structure+0x8a0>
    a334:      	brk	#0
    a338:      	b	0xa334 <_stogir.verify.structure+0x8d4>
    a33c:      	str	x19, [sp, #0x30]
    a340:      	mov	x19, x0
    a344:      	str	x22, [sp, #0x38]
    a348:      	str	x23, [sp, #0x80]
    a34c:      	b	0x9c6c <_stogir.verify.structure+0x20c>
    a350:      	str	x19, [sp, #0x30]
    a354:      	mov	x19, x0
    a358:      	str	x22, [sp, #0x38]
    a35c:      	str	x23, [sp, #0x80]
    a360:      	b	0x9c6c <_stogir.verify.structure+0x20c>
    a364:      	mov	x5, x28
    a368:      	str	x19, [sp, #0x30]
    a36c:      	mov	x19, x0
    a370:      	mov	x0, x21
    a374:      	mov	x2, x24
    a378:      	mov	x3, x25
    a37c:      	mov	x4, x26
    a380:      	b	0x9b44 <_stogir.verify.structure+0xe4>
    a384:      	mov	x5, x28
    a388:      	str	x19, [sp, #0x30]
    a38c:      	mov	x19, x0
    a390:      	mov	x0, x21
    a394:      	mov	x2, x24
    a398:      	mov	x3, x25
    a39c:      	mov	x4, x26
    a3a0:      	b	0x9b10 <_stogir.verify.structure+0xb0>
    a3a4:      	mov	x5, x28
    a3a8:      	ldr	x19, [sp, #0x40]
    a3ac:      	ldr	x0, [sp, #0x58]
    a3b0:      	ldr	x2, [sp, #0x60]
    a3b4:      	ldr	x3, [sp, #0x50]
    a3b8:      	ldr	x4, [sp, #0x48]
    a3bc:      	b	0x9b10 <_stogir.verify.structure+0xb0>
    a3c0:      	ldr	x0, [sp, #0x38]
    a3c4:      	b	0x9ca0 <_stogir.verify.structure+0x240>
    a3c8:      	str	x28, [sp, #0x90]
    a3cc:      	ldr	x0, [sp, #0x58]
    a3d0:      	str	x19, [sp, #0x88]
    a3d4:      	ldr	x2, [sp, #0x60]
    a3d8:      	str	x23, [sp, #0x80]
    a3dc:      	ldr	x3, [sp, #0x50]
    a3e0:      	ldr	x4, [sp, #0x48]
    a3e4:      	b	0x9acc <_stogir.verify.structure+0x6c>
    a3e8:      	str	w21, [sp, #0xb0]
    a3ec:      	mov	w21, w1
    a3f0:      	str	w24, [sp, #0xa8]
    a3f4:      	mov	x24, x0
    a3f8:      	b	0x9ea0 <_stogir.verify.structure+0x440>
    a3fc:      	ldr	x2, [sp, #0x60]
    a400:      	b	0x9f8c <_stogir.verify.structure+0x52c>
    a404:      	ldr	x0, [sp, #0x58]
    a408:      	ldr	w1, [sp, #0xb0]
    a40c:      	ldr	w5, [sp, #0xa8]
    a410:      	ldr	x3, [sp, #0x50]
    a414:      	ldr	x4, [sp, #0x48]
    a418:      	b	0x9d1c <_stogir.verify.structure+0x2bc>
    a41c:      	ldr	x0, [sp, #0x58]
    a420:      	ldr	w1, [sp, #0xb0]
    a424:      	ldr	w5, [sp, #0xa8]
    a428:      	ldr	x3, [sp, #0x50]
    a42c:      	ldr	x4, [sp, #0x48]
    a430:      	b	0x9d1c <_stogir.verify.structure+0x2bc>
    a434:      	ldr	x2, [sp, #0x60]
    a438:      	b	0x9f44 <_stogir.verify.structure+0x4e4>
    a43c:      	ldr	w1, [sp, #0xb0]
    a440:      	ldr	w5, [sp, #0xa8]
    a444:      	b	0xa228 <_stogir.verify.structure+0x7c8>
    a448:      	ldr	x0, [sp, #0x58]
    a44c:      	b	0xa250 <_stogir.verify.structure+0x7f0>
    a450:      	ldr	x0, [sp, #0x58]
    a454:      	b	0xa240 <_stogir.verify.structure+0x7e0>
    a458:      	ldr	w5, [sp, #0xa8]
    a45c:      	b	0xa228 <_stogir.verify.structure+0x7c8>
    a460:      	ldr	x3, [sp, #0x50]
    a464:      	ldr	x4, [sp, #0x48]
    a468:      	b	0x9d08 <_stogir.verify.structure+0x2a8>
    a46c:      	udf	#0x0

000000000000a470 <_stogir.verify.schedule-input-structured>:
    a470:      	sub	sp, sp, #0x40
    a474:      	str	x29, [sp]
    a478:      	str	x30, [sp, #0x8]
    a47c:      	mov	x29, sp
    a480:      	str	x19, [sp, #0x30]
    a484:      	sxtw	x1, w1
    a488:      	add	x4, x0, #0x28
    a48c:      	add	x5, x0, #0x78
    a490:      	cmp	x1, #0x0
    a494:      	cset	w6, gt
    a498:      	movz	x16, #0x0, lsl #48
    a49c:      	sub	x7, x16, x1
    a4a0:      	sub	x9, x7, #0x1
    a4a4:      	uxtb	w16, w6
    a4a8:      	cmp	w16, wzr
    a4ac:      	b.eq	0xa4e8 <_stogir.verify.schedule-input-structured+0x78>
    a4b0:      	ldr	x4, [x0, #0x8]
    a4b4:      	cmp	x1, x4
    a4b8:      	b.ge	0xa534 <_stogir.verify.schedule-input-structured+0xc4>
    a4bc:      	ldr	x4, [x5, #0x8]
    a4c0:      	cmp	x1, x4
    a4c4:      	b.ge	0xa70c <_stogir.verify.schedule-input-structured+0x29c>
    a4c8:      	ldr	x4, [x0, #0x78]
    a4cc:      	add	x4, x4, x1, lsl #2
    a4d0:      	ldr	w4, [x4]
    a4d4:      	sxtw	x4, w4
    a4d8:      	cmp	x4, #0x0
    a4dc:      	cset	w4, ge
    a4e0:      	ubfx	x4, x4, #0, #8
    a4e4:      	b	0xa710 <_stogir.verify.schedule-input-structured+0x2a0>
    a4e8:      	cmp	x1, #0x0
    a4ec:      	b.ge	0xa53c <_stogir.verify.schedule-input-structured+0xcc>
    a4f0:      	add	x10, x0, #0x50
    a4f4:      	ldr	x4, [x4, #0x8]
    a4f8:      	ldr	x10, [x10, #0x8]
    a4fc:      	cmp	x4, x10
    a500:      	b.ne	0xa52c <_stogir.verify.schedule-input-structured+0xbc>
    a504:      	cmp	x7, x4
    a508:      	b.gt	0xa714 <_stogir.verify.schedule-input-structured+0x2a4>
    a50c:      	ldr	x4, [x0, #0x50]
    a510:      	add	x4, x4, x9, lsl #2
    a514:      	ldr	w4, [x4]
    a518:      	sxtw	x4, w4
    a51c:      	cmp	x4, #0x0
    a520:      	cset	w4, gt
    a524:      	ubfx	x4, x4, #0, #8
    a528:      	b	0xa718 <_stogir.verify.schedule-input-structured+0x2a8>
    a52c:      	movz	x4, #0x0, lsl #48
    a530:      	b	0xa540 <_stogir.verify.schedule-input-structured+0xd0>
    a534:      	movz	x4, #0x0, lsl #48
    a538:      	b	0xa540 <_stogir.verify.schedule-input-structured+0xd0>
    a53c:      	movz	x4, #0x0, lsl #48
    a540:      	cmp	x4, #0x0
    a544:      	b.eq	0xa578 <_stogir.verify.schedule-input-structured+0x108>
    a548:      	uxtb	w16, w6
    a54c:      	cmp	w16, wzr
    a550:      	b.eq	0xa564 <_stogir.verify.schedule-input-structured+0xf4>
    a554:      	ldr	x4, [x0]
    a558:      	add	x4, x4, x1, lsl #4
    a55c:      	ldr	x4, [x4]
    a560:      	b	0xa570 <_stogir.verify.schedule-input-structured+0x100>
    a564:      	ldr	x4, [x0, #0x28]
    a568:      	add	x4, x4, x9, lsl #4
    a56c:      	ldr	x4, [x4]
    a570:      	mov	w6, #0x1                ; =1
    a574:      	b	0xa580 <_stogir.verify.schedule-input-structured+0x110>
    a578:      	movz	w6, #0x0, lsl #16
    a57c:      	movz	x4, #0x0, lsl #48
    a580:      	ubfx	x6, x6, #0, #32
    a584:      	lsr	x16, x6, #0
    a588:      	cmp	x16, #0x1
    a58c:      	b.eq	0xa5a8 <_stogir.verify.schedule-input-structured+0x138>
    a590:      	b.lo	0xa598 <_stogir.verify.schedule-input-structured+0x128>
    a594:      	b	0xa5ac <_stogir.verify.schedule-input-structured+0x13c>
    a598:      	cmp	x16, #0x0
    a59c:      	b.eq	0xa5a4 <_stogir.verify.schedule-input-structured+0x134>
    a5a0:      	b	0xa5ac <_stogir.verify.schedule-input-structured+0x13c>
    a5a4:      	b	0xa5b0 <_stogir.verify.schedule-input-structured+0x140>
    a5a8:      	b	0xa6e4 <_stogir.verify.schedule-input-structured+0x274>
    a5ac:      	b	0xa764 <_stogir.verify.schedule-input-structured+0x2f4>
    a5b0:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a5b0:  ARM64_RELOC_PAGE21	l_stogir.476
    a5b4:      	ldr	x1, [x1]
		000000000000a5b4:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    a5b8:      	mov	x4, #0xd                ; =13
    a5bc:      	b	0xa5cc <_stogir.verify.schedule-input-structured+0x15c>
    a5c0:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a5c0:  ARM64_RELOC_PAGE21	l_stogir.477
    a5c4:      	ldr	x1, [x1]
		000000000000a5c4:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    a5c8:      	mov	x4, #0x1b               ; =27
    a5cc:      	cmp	x3, #0x0
    a5d0:      	b.ne	0xa5e0 <_stogir.verify.schedule-input-structured+0x170>
    a5d4:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a5d4:  ARM64_RELOC_PAGE21	l_stogir.478
    a5d8:      	ldr	x1, [x1]
		000000000000a5d8:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    a5dc:      	mov	x4, #0x25               ; =37
    a5e0:      	movz	x6, #0x0, lsl #48
    a5e4:      	b	0xa668 <_stogir.verify.schedule-input-structured+0x1f8>
    a5e8:      	movz	w7, #0x0, lsl #16
    a5ec:      	movz	w9, #0x0, lsl #16
    a5f0:      	ubfx	x7, x7, #0, #32
    a5f4:      	lsr	x16, x7, #0
    a5f8:      	cmp	x16, #0x1
    a5fc:      	b.eq	0xa618 <_stogir.verify.schedule-input-structured+0x1a8>
    a600:      	b.lo	0xa608 <_stogir.verify.schedule-input-structured+0x198>
    a604:      	b	0xa61c <_stogir.verify.schedule-input-structured+0x1ac>
    a608:      	cmp	x16, #0x0
    a60c:      	b.eq	0xa614 <_stogir.verify.schedule-input-structured+0x1a4>
    a610:      	b	0xa61c <_stogir.verify.schedule-input-structured+0x1ac>
    a614:      	b	0xa690 <_stogir.verify.schedule-input-structured+0x220>
    a618:      	b	0xa620 <_stogir.verify.schedule-input-structured+0x1b0>
    a61c:      	b	0xa75c <_stogir.verify.schedule-input-structured+0x2ec>
    a620:      	sxtw	x9, w9
    a624:      	cmp	x9, #0x0
    a628:      	b.le	0xa65c <_stogir.verify.schedule-input-structured+0x1ec>
    a62c:      	ldr	x7, [x0, #0x8]
    a630:      	cmp	x9, x7
    a634:      	b.ge	0xa65c <_stogir.verify.schedule-input-structured+0x1ec>
    a638:      	ldr	x7, [x5, #0x8]
    a63c:      	cmp	x9, x7
    a640:      	b.ge	0xa65c <_stogir.verify.schedule-input-structured+0x1ec>
    a644:      	ldr	x7, [x0, #0x78]
    a648:      	add	x7, x7, x9, lsl #2
    a64c:      	ldr	w7, [x7]
    a650:      	sxtw	x7, w7
    a654:      	cmp	x7, #0x0
    a658:      	b.ge	0xa668 <_stogir.verify.schedule-input-structured+0x1f8>
    a65c:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a65c:  ARM64_RELOC_PAGE21	l_stogir.479
    a660:      	ldr	x1, [x1]
		000000000000a660:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    a664:      	mov	x4, #0x16               ; =22
    a668:      	cmp	x6, x3
    a66c:      	b.ge	0xa5e8 <_stogir.verify.schedule-input-structured+0x178>
    a670:      	add	x7, x6, #0x1
    a674:      	add	x6, x2, x6, lsl #2
    a678:      	ldr	w6, [x6]
    a67c:      	movn	w17, #0x0, lsl #16
    a680:      	and	w9, w6, w17
    a684:      	mov	x6, x7
    a688:      	mov	w7, #0x1                ; =1
    a68c:      	b	0xa5f0 <_stogir.verify.schedule-input-structured+0x180>
    a690:      	cmp	x4, #0x0
    a694:      	b.ne	0xa76c <_stogir.verify.schedule-input-structured+0x2fc>
    a698:      	mov	x19, x8
    a69c:      	add	x8, sp, #0x10
    a6a0:      	bl	0xa6a0 <_stogir.verify.schedule-input-structured+0x230>
		000000000000a6a0:  ARM64_RELOC_BRANCH26	_stogir.verify.phis-structured
    a6a4:      	add	x16, sp, #0x10
    a6a8:      	ldr	x0, [x16]
    a6ac:      	add	x16, sp, #0x10
    a6b0:      	ldr	x1, [x16, #0x8]
    a6b4:      	add	x16, sp, #0x10
    a6b8:      	ldr	x4, [x16, #0x10]
    a6bc:      	b	0xa6c4 <_stogir.verify.schedule-input-structured+0x254>
    a6c0:      	mov	x0, #0x1                ; =1
    a6c4:      	str	x0, [x19]
    a6c8:      	str	x1, [x19, #0x8]
    a6cc:      	str	x4, [x19, #0x10]
    a6d0:      	ldr	x19, [sp, #0x30]
    a6d4:      	ldr	x29, [sp]
    a6d8:      	ldr	x30, [sp, #0x8]
    a6dc:      	add	sp, sp, #0x40
    a6e0:      	ret
    a6e4:      	cmp	x1, #0x0
    a6e8:      	b.le	0xa5c0 <_stogir.verify.schedule-input-structured+0x150>
    a6ec:      	uxtb	w4, w4
    a6f0:      	cmp	x4, #0x83
    a6f4:      	b.ge	0xa71c <_stogir.verify.schedule-input-structured+0x2ac>
    a6f8:      	adrp	x17, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a6f8:  ARM64_RELOC_PAGE21	l_stogir.480
    a6fc:      	ldr	x17, [x17]
		000000000000a6fc:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    a700:      	add	x1, x4, x17
    a704:      	ldrb	w1, [x1]
    a708:      	b	0xa720 <_stogir.verify.schedule-input-structured+0x2b0>
    a70c:      	movz	x4, #0x0, lsl #48
    a710:      	b	0xa538 <_stogir.verify.schedule-input-structured+0xc8>
    a714:      	movz	x4, #0x0, lsl #48
    a718:      	b	0xa530 <_stogir.verify.schedule-input-structured+0xc0>
    a71c:      	movz	w1, #0x0, lsl #16
    a720:      	uxtb	w16, w1
    a724:      	and	w1, w16, #0x2
    a728:      	uxtb	w1, w1
    a72c:      	ubfx	x1, x1, #0, #8
    a730:      	cmp	x1, #0x0
    a734:      	cset	w1, eq
    a738:      	uxtb	w16, w1
    a73c:      	cmp	w16, wzr
    a740:      	cset	x1, eq
    a744:      	cmp	x1, #0x0
    a748:      	b.eq	0xa5c0 <_stogir.verify.schedule-input-structured+0x150>
    a74c:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a74c:  ARM64_RELOC_PAGE21	l_stogir.481
    a750:      	ldr	x1, [x1]
		000000000000a750:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    a754:      	movz	x4, #0x0, lsl #48
    a758:      	b	0xa5cc <_stogir.verify.schedule-input-structured+0x15c>
    a75c:      	brk	#0
    a760:      	b	0xa75c <_stogir.verify.schedule-input-structured+0x2ec>
    a764:      	brk	#0
    a768:      	b	0xa764 <_stogir.verify.schedule-input-structured+0x2f4>
    a76c:      	mov	x19, x8
    a770:      	b	0xa6c0 <_stogir.verify.schedule-input-structured+0x250>

000000000000a774 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
    a774:      	ldr	x0, [x0, #0x8]
    a778:      	ret

000000000000a77c <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    a77c:      	ldr	x0, [x0, #0x8]
    a780:      	ret

000000000000a784 <_stogir.verify.control-sources>:
    a784:      	sub	sp, sp, #0x40
    a788:      	str	x29, [sp]
    a78c:      	str	x30, [sp, #0x8]
    a790:      	mov	x29, sp
    a794:      	str	x19, [sp, #0x30]
    a798:      	str	x20, [sp, #0x38]
    a79c:      	mov	x19, x8
    a7a0:      	add	x8, sp, #0x10
    a7a4:      	mov	x20, x0
    a7a8:      	bl	0xa7a8 <_stogir.verify.control-sources+0x24>
		000000000000a7a8:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
    a7ac:      	add	x16, sp, #0x10
    a7b0:      	ldr	w0, [x16]
    a7b4:      	lsr	x16, x0, #0
    a7b8:      	cmp	x16, #0x1
    a7bc:      	b.eq	0xa7d8 <_stogir.verify.control-sources+0x54>
    a7c0:      	b.lo	0xa7c8 <_stogir.verify.control-sources+0x44>
    a7c4:      	b	0xa7dc <_stogir.verify.control-sources+0x58>
    a7c8:      	cmp	x16, #0x0
    a7cc:      	b.eq	0xa7d4 <_stogir.verify.control-sources+0x50>
    a7d0:      	b	0xa7dc <_stogir.verify.control-sources+0x58>
    a7d4:      	b	0xa828 <_stogir.verify.control-sources+0xa4>
    a7d8:      	b	0xa7e0 <_stogir.verify.control-sources+0x5c>
    a7dc:      	b	0xabe0 <_stogir.verify.control-sources+0x45c>
    a7e0:      	add	x16, sp, #0x10
    a7e4:      	orr	x0, x16, xzr
    a7e8:      	add	x0, x0, #0x8
    a7ec:      	add	x16, sp, #0x10
    a7f0:      	ldr	x1, [x16, #0x8]
    a7f4:      	ldr	x0, [x0, #0x8]
    a7f8:      	mov	x2, #0x1                ; =1
    a7fc:      	b	0xa804 <_stogir.verify.control-sources+0x80>
    a800:      	mov	x2, #0x1                ; =1
    a804:      	str	x2, [x19]
    a808:      	str	x1, [x19, #0x8]
    a80c:      	str	x0, [x19, #0x10]
    a810:      	ldr	x19, [sp, #0x30]
    a814:      	ldr	x20, [sp, #0x38]
    a818:      	ldr	x29, [sp]
    a81c:      	ldr	x30, [sp, #0x8]
    a820:      	add	sp, sp, #0x40
    a824:      	ret
    a828:      	add	x2, x20, #0x78
    a82c:      	mov	x3, #0x1                ; =1
    a830:      	movz	x4, #0x0, lsl #48
    a834:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a834:  ARM64_RELOC_PAGE21	l_stogir.482
    a838:      	ldr	x1, [x1]
		000000000000a838:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    a83c:      	movz	x0, #0x0, lsl #48
    a840:      	b	0xaab0 <_stogir.verify.control-sources+0x32c>
    a844:      	movz	w12, #0x0, lsl #16
    a848:      	uxtb	w16, w12
    a84c:      	and	w12, w16, #0x1
    a850:      	uxtb	w12, w12
    a854:      	ubfx	x12, x12, #0, #8
    a858:      	cmp	x12, #0x0
    a85c:      	b.ne	0xa86c <_stogir.verify.control-sources+0xe8>
    a860:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a860:  ARM64_RELOC_PAGE21	l_stogir.483
    a864:      	ldr	x1, [x1]
		000000000000a864:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    a868:      	mov	x0, #0x1d               ; =29
    a86c:      	b	0xaa18 <_stogir.verify.control-sources+0x294>
    a870:      	movz	x5, #0x0, lsl #48
    a874:      	cmp	x5, #0x0
    a878:      	b.eq	0xabb8 <_stogir.verify.control-sources+0x434>
    a87c:      	orr	w5, w3, wzr
    a880:      	ldr	x6, [x20]
    a884:      	sxtw	x5, w5
    a888:      	cmp	x5, #0x0
    a88c:      	cset	w7, le
    a890:      	lsl	x8, x5, #2
    a894:      	add	x6, x6, x3, lsl #4
    a898:      	ldr	x6, [x6]
    a89c:      	ldr	x9, [x20, #0x78]
    a8a0:      	uxtb	w6, w6
    a8a4:      	add	x9, x9, x3, lsl #2
    a8a8:      	cmp	x6, #0x83
    a8ac:      	cset	w10, lt
    a8b0:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a8b0:  ARM64_RELOC_PAGE21	l_stogir.484
    a8b4:      	ldr	x16, [x16]
		000000000000a8b4:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    a8b8:      	add	x6, x16, x6, lsl #2
    a8bc:      	ldr	w9, [x9]
    a8c0:      	sxtw	x9, w9
    a8c4:      	mov	x11, #0x1               ; =1
    a8c8:      	b	0xa944 <_stogir.verify.control-sources+0x1c0>
    a8cc:      	movz	w13, #0x0, lsl #16
    a8d0:      	movz	w12, #0x0, lsl #16
    a8d4:      	b	0xa8f8 <_stogir.verify.control-sources+0x174>
    a8d8:      	sub	w12, w12, #0x1
    a8dc:      	lsl	w12, w12, #2
    a8e0:      	ubfx	x12, x12, #0, #32
    a8e4:      	lsr	x12, x14, x12
    a8e8:      	and	w12, w12, #0xf
    a8ec:      	b	0xa99c <_stogir.verify.control-sources+0x218>
    a8f0:      	movz	w13, #0x0, lsl #16
    a8f4:      	movz	w12, #0x0, lsl #16
    a8f8:      	ubfx	x13, x13, #0, #32
    a8fc:      	lsr	x16, x13, #0
    a900:      	cmp	x16, #0x1
    a904:      	b.eq	0xa920 <_stogir.verify.control-sources+0x19c>
    a908:      	b.lo	0xa910 <_stogir.verify.control-sources+0x18c>
    a90c:      	b	0xa924 <_stogir.verify.control-sources+0x1a0>
    a910:      	cmp	x16, #0x0
    a914:      	b.eq	0xa91c <_stogir.verify.control-sources+0x198>
    a918:      	b	0xa924 <_stogir.verify.control-sources+0x1a0>
    a91c:      	b	0xa928 <_stogir.verify.control-sources+0x1a4>
    a920:      	b	0xaa00 <_stogir.verify.control-sources+0x27c>
    a924:      	b	0xabd0 <_stogir.verify.control-sources+0x44c>
    a928:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a928:  ARM64_RELOC_PAGE21	l_stogir.485
    a92c:      	ldr	x1, [x1]
		000000000000a92c:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    a930:      	mov	x0, #0x16               ; =22
    a934:      	add	x4, x4, #0x1
    a938:      	sxtw	x4, w4
    a93c:      	add	x11, x11, #0x1
    a940:      	sxtw	x11, w11
    a944:      	cmp	x0, #0x0
    a948:      	b.ne	0xa95c <_stogir.verify.control-sources+0x1d8>
    a94c:      	cmp	x11, x9
    a950:      	cset	w12, le
    a954:      	ubfx	x12, x12, #0, #8
    a958:      	b	0xa960 <_stogir.verify.control-sources+0x1dc>
    a95c:      	movz	x12, #0x0, lsl #48
    a960:      	cmp	x12, #0x0
    a964:      	b.eq	0xaa98 <_stogir.verify.control-sources+0x314>
    a968:      	orr	w12, w11, wzr
    a96c:      	sxtw	x13, w12
    a970:      	uxtb	w16, w10
    a974:      	cmp	w16, wzr
    a978:      	b.eq	0xa9a0 <_stogir.verify.control-sources+0x21c>
    a97c:      	ldr	w14, [x6]
    a980:      	cmp	x13, #0x0
    a984:      	b.le	0xa998 <_stogir.verify.control-sources+0x214>
    a988:      	cmp	x13, #0x4
    a98c:      	b.le	0xa8d8 <_stogir.verify.control-sources+0x154>
    a990:      	mov	w12, #0x4               ; =4
    a994:      	b	0xa8dc <_stogir.verify.control-sources+0x158>
    a998:      	movz	w12, #0x0, lsl #16
    a99c:      	b	0xa9a4 <_stogir.verify.control-sources+0x220>
    a9a0:      	movz	w12, #0x0, lsl #16
    a9a4:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000a9a4:  ARM64_RELOC_PAGE21	l_stogir.486
    a9a8:      	ldr	x16, [x16]
		000000000000a9a8:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    a9ac:      	ldr	w14, [x16]
    a9b0:      	ubfx	x12, x12, #0, #32
    a9b4:      	cmp	x12, x14
    a9b8:      	b.ne	0xa93c <_stogir.verify.control-sources+0x1b8>
    a9bc:      	uxtb	w16, w7
    a9c0:      	cmp	w16, wzr
    a9c4:      	b.ne	0xa8f0 <_stogir.verify.control-sources+0x16c>
    a9c8:      	ldr	x12, [x20, #0x8]
    a9cc:      	cmp	x5, x12
    a9d0:      	b.ge	0xaa24 <_stogir.verify.control-sources+0x2a0>
    a9d4:      	ldr	x12, [x2, #0x8]
    a9d8:      	cmp	x5, x12
    a9dc:      	b.ge	0xaa1c <_stogir.verify.control-sources+0x298>
    a9e0:      	ldr	x12, [x20, #0x78]
    a9e4:      	add	x12, x8, x12
    a9e8:      	ldr	w12, [x12]
    a9ec:      	sxtw	x12, w12
    a9f0:      	cmp	x12, #0x0
    a9f4:      	cset	w12, ge
    a9f8:      	ubfx	x12, x12, #0, #8
    a9fc:      	b	0xaa20 <_stogir.verify.control-sources+0x29c>
    aa00:      	sxtw	x12, w12
    aa04:      	cmp	x12, #0x0
    aa08:      	b.gt	0xaacc <_stogir.verify.control-sources+0x348>
    aa0c:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000aa0c:  ARM64_RELOC_PAGE21	l_stogir.487
    aa10:      	ldr	x1, [x1]
		000000000000aa10:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    aa14:      	mov	x0, #0x25               ; =37
    aa18:      	b	0xa934 <_stogir.verify.control-sources+0x1b0>
    aa1c:      	movz	x12, #0x0, lsl #48
    aa20:      	b	0xaa28 <_stogir.verify.control-sources+0x2a4>
    aa24:      	movz	x12, #0x0, lsl #48
    aa28:      	cmp	x12, #0x0
    aa2c:      	b.eq	0xa8f0 <_stogir.verify.control-sources+0x16c>
    aa30:      	cmp	x13, #0x1
    aa34:      	b.lt	0xa8cc <_stogir.verify.control-sources+0x148>
    aa38:      	ldr	x12, [x20, #0x78]
    aa3c:      	add	x12, x8, x12
    aa40:      	ldr	w12, [x12]
    aa44:      	sxtw	x12, w12
    aa48:      	cmp	x13, x12
    aa4c:      	b.gt	0xa8cc <_stogir.verify.control-sources+0x148>
    aa50:      	ldr	x12, [x20]
    aa54:      	asr	x16, x13, #63
    aa58:      	lsr	x16, x16, #62
    aa5c:      	add	x14, x13, x16
    aa60:      	asr	x14, x14, #2
    aa64:      	asr	x16, x13, #63
    aa68:      	lsr	x16, x16, #62
    aa6c:      	add	x13, x13, x16
    aa70:      	and	x13, x13, #0x3
    aa74:      	sub	x13, x13, x16
    aa78:      	add	x14, x14, x5
    aa7c:      	add	x12, x12, x14, lsl #4
    aa80:      	add	x12, x12, x13, lsl #2
    aa84:      	ldr	w12, [x12]
    aa88:      	movn	w17, #0x0, lsl #16
    aa8c:      	and	w12, w12, w17
    aa90:      	mov	w13, #0x1               ; =1
    aa94:      	b	0xa8d4 <_stogir.verify.control-sources+0x150>
    aa98:      	add	x5, x9, #0x4
    aa9c:      	asr	x16, x5, #63
    aaa0:      	lsr	x16, x16, #62
    aaa4:      	add	x5, x5, x16
    aaa8:      	asr	x5, x5, #2
    aaac:      	add	x3, x5, x3
    aab0:      	cmp	x0, #0x0
    aab4:      	b.ne	0xa870 <_stogir.verify.control-sources+0xec>
    aab8:      	ldr	x5, [x20, #0x8]
    aabc:      	cmp	x3, x5
    aac0:      	cset	w5, lt
    aac4:      	ubfx	x5, x5, #0, #8
    aac8:      	b	0xa874 <_stogir.verify.control-sources+0xf0>
    aacc:      	ldr	x13, [x20, #0x8]
    aad0:      	cmp	x12, x13
    aad4:      	b.ge	0xab0c <_stogir.verify.control-sources+0x388>
    aad8:      	ldr	x13, [x2, #0x8]
    aadc:      	cmp	x12, x13
    aae0:      	b.ge	0xab04 <_stogir.verify.control-sources+0x380>
    aae4:      	ldr	x13, [x20, #0x78]
    aae8:      	add	x13, x13, x12, lsl #2
    aaec:      	ldr	w13, [x13]
    aaf0:      	sxtw	x13, w13
    aaf4:      	cmp	x13, #0x0
    aaf8:      	cset	w13, ge
    aafc:      	ubfx	x13, x13, #0, #8
    ab00:      	b	0xab08 <_stogir.verify.control-sources+0x384>
    ab04:      	movz	x13, #0x0, lsl #48
    ab08:      	b	0xab10 <_stogir.verify.control-sources+0x38c>
    ab0c:      	movz	x13, #0x0, lsl #48
    ab10:      	cmp	x13, #0x0
    ab14:      	b.eq	0xab50 <_stogir.verify.control-sources+0x3cc>
    ab18:      	cmp	x12, #0x0
    ab1c:      	b.le	0xab30 <_stogir.verify.control-sources+0x3ac>
    ab20:      	ldr	x13, [x20]
    ab24:      	add	x12, x13, x12, lsl #4
    ab28:      	ldr	x12, [x12]
    ab2c:      	b	0xab48 <_stogir.verify.control-sources+0x3c4>
    ab30:      	movz	x16, #0x0, lsl #48
    ab34:      	sub	x12, x16, x12
    ab38:      	ldr	x13, [x20, #0x28]
    ab3c:      	sub	x12, x12, #0x1
    ab40:      	add	x12, x13, x12, lsl #4
    ab44:      	ldr	x12, [x12]
    ab48:      	mov	w13, #0x1               ; =1
    ab4c:      	b	0xab58 <_stogir.verify.control-sources+0x3d4>
    ab50:      	movz	w13, #0x0, lsl #16
    ab54:      	movz	x12, #0x0, lsl #48
    ab58:      	ubfx	x13, x13, #0, #32
    ab5c:      	lsr	x16, x13, #0
    ab60:      	cmp	x16, #0x1
    ab64:      	b.eq	0xab80 <_stogir.verify.control-sources+0x3fc>
    ab68:      	b.lo	0xab70 <_stogir.verify.control-sources+0x3ec>
    ab6c:      	b	0xab84 <_stogir.verify.control-sources+0x400>
    ab70:      	cmp	x16, #0x0
    ab74:      	b.eq	0xab7c <_stogir.verify.control-sources+0x3f8>
    ab78:      	b	0xab84 <_stogir.verify.control-sources+0x400>
    ab7c:      	b	0xab88 <_stogir.verify.control-sources+0x404>
    ab80:      	b	0xab98 <_stogir.verify.control-sources+0x414>
    ab84:      	b	0xabd8 <_stogir.verify.control-sources+0x454>
    ab88:      	adrp	x1, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000ab88:  ARM64_RELOC_PAGE21	l_stogir.485
    ab8c:      	ldr	x1, [x1]
		000000000000ab8c:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    ab90:      	mov	x0, #0x16               ; =22
    ab94:      	b	0xa86c <_stogir.verify.control-sources+0xe8>
    ab98:      	uxtb	w12, w12
    ab9c:      	cmp	x12, #0x83
    aba0:      	b.ge	0xa844 <_stogir.verify.control-sources+0xc0>
    aba4:      	adrp	x17, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000aba4:  ARM64_RELOC_PAGE21	l_stogir.488
    aba8:      	ldr	x17, [x17]
		000000000000aba8:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    abac:      	add	x12, x12, x17
    abb0:      	ldrb	w12, [x12]
    abb4:      	b	0xa848 <_stogir.verify.control-sources+0xc4>
    abb8:      	cmp	x0, #0x0
    abbc:      	b.ne	0xa800 <_stogir.verify.control-sources+0x7c>
    abc0:      	and	x1, x4, #0xffffffff
    abc4:      	movz	x2, #0x0, lsl #48
    abc8:      	movz	x0, #0x0, lsl #48
    abcc:      	b	0xa804 <_stogir.verify.control-sources+0x80>
    abd0:      	brk	#0
    abd4:      	b	0xabd0 <_stogir.verify.control-sources+0x44c>
    abd8:      	brk	#0
    abdc:      	b	0xabd8 <_stogir.verify.control-sources+0x454>
    abe0:      	brk	#0
    abe4:      	b	0xabe0 <_stogir.verify.control-sources+0x45c>

000000000000abe8 <_inherent$coil.arraylist.ArrayList$new__stogir.cfg.Edge>:
    abe8:      	ldr	x1, [x0]
    abec:      	ldr	x0, [x0, #0x8]
    abf0:      	movz	x17, #0x0, lsl #48
    abf4:      	str	x17, [x8]
    abf8:      	movz	x17, #0x0, lsl #48
    abfc:      	str	x17, [x8, #0x8]
    ac00:      	movz	x17, #0x0, lsl #48
    ac04:      	str	x17, [x8, #0x10]
    ac08:      	str	x1, [x8, #0x18]
    ac0c:      	str	x0, [x8, #0x20]
    ac10:      	ret

000000000000ac14 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32>:
    ac14:      	sub	sp, sp, #0x30
    ac18:      	str	x29, [sp]
    ac1c:      	str	x30, [sp, #0x8]
    ac20:      	mov	x29, sp
    ac24:      	str	x19, [sp, #0x10]
    ac28:      	str	x20, [sp, #0x18]
    ac2c:      	str	x21, [sp, #0x20]
    ac30:      	str	x22, [sp, #0x28]
    ac34:      	ldr	x2, [x0, #0x8]
    ac38:      	orr	x19, x2, xzr
    ac3c:      	ldr	x2, [x0, #0x10]
    ac40:      	add	x20, x19, x1
    ac44:      	cmp	x20, x2
    ac48:      	b.le	0xacc4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0xb0>
    ac4c:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    ac50:      	cmp	x2, x17
    ac54:      	b.gt	0xac60 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x4c>
    ac58:      	lsl	x2, x2, #1
    ac5c:      	b	0xac64 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x50>
    ac60:      	mov	x2, x20
    ac64:      	cmp	x2, x20
    ac68:      	b.gt	0xac70 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x5c>
    ac6c:      	mov	x2, x20
    ac70:      	mov	x21, x0
    ac74:      	mov	x22, x1
    ac78:      	mov	x1, x2
    ac7c:      	bl	0xac7c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x68>
		000000000000ac7c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ac80:      	lsl	x0, x22, #2
    ac84:      	ldr	x1, [x21]
    ac88:      	add	x1, x1, x19, lsl #2
    ac8c:      	mov	x2, x0
    ac90:      	mov	x0, x1
    ac94:      	movz	x1, #0x0, lsl #48
    ac98:      	bl	0xac98 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x84>
		000000000000ac98:  ARM64_RELOC_BRANCH26	_memset
    ac9c:      	str	x20, [x21, #0x8]
    aca0:      	mov	x0, x20
    aca4:      	ldr	x19, [sp, #0x10]
    aca8:      	ldr	x20, [sp, #0x18]
    acac:      	ldr	x21, [sp, #0x20]
    acb0:      	ldr	x22, [sp, #0x28]
    acb4:      	ldr	x29, [sp]
    acb8:      	ldr	x30, [sp, #0x8]
    acbc:      	add	sp, sp, #0x30
    acc0:      	ret
    acc4:      	mov	x21, x0
    acc8:      	mov	x22, x1
    accc:      	b	0xac80 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32+0x6c>

000000000000acd0 <_stogir.opcode.block-start?>:
    acd0:      	sxtw	x0, w0
    acd4:      	cmp	x0, #0x0
    acd8:      	b.lt	0xacf8 <_stogir.opcode.block-start?+0x28>
    acdc:      	cmp	x0, #0x83
    ace0:      	b.ge	0xacf8 <_stogir.opcode.block-start?+0x28>
    ace4:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000ace4:  ARM64_RELOC_PAGE21	l_stogir.489
    ace8:      	ldr	x16, [x16]
		000000000000ace8:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    acec:      	add	x0, x16, x0
    acf0:      	ldrb	w0, [x0]
    acf4:      	b	0xacfc <_stogir.opcode.block-start?+0x2c>
    acf8:      	movz	w0, #0x0, lsl #16
    acfc:      	uxtb	w16, w0
    ad00:      	and	w0, w16, #0x2
    ad04:      	uxtb	w0, w0
    ad08:      	ubfx	x0, x0, #0, #8
    ad0c:      	cmp	x0, #0x0
    ad10:      	cset	w0, eq
    ad14:      	uxtb	w16, w0
    ad18:      	cmp	w16, wzr
    ad1c:      	cset	x0, eq
    ad20:      	ret

000000000000ad24 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32>:
    ad24:      	sub	sp, sp, #0x30
    ad28:      	str	x29, [sp]
    ad2c:      	str	x30, [sp, #0x8]
    ad30:      	mov	x29, sp
    ad34:      	str	x19, [sp, #0x10]
    ad38:      	str	x20, [sp, #0x18]
    ad3c:      	str	x21, [sp, #0x20]
    ad40:      	ldr	x2, [x0, #0x8]
    ad44:      	orr	x19, x2, xzr
    ad48:      	ldr	x2, [x0, #0x10]
    ad4c:      	cmp	x19, x2
    ad50:      	b.lt	0xad64 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x40>
    ad54:      	cmp	x2, #0x0
    ad58:      	b.ne	0xad70 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x4c>
    ad5c:      	mov	x2, #0x2                ; =2
    ad60:      	b	0xad74 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x50>
    ad64:      	mov	x20, x0
    ad68:      	mov	w21, w1
    ad6c:      	b	0xad84 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x60>
    ad70:      	lsl	x2, x2, #1
    ad74:      	mov	x20, x0
    ad78:      	mov	w21, w1
    ad7c:      	mov	x1, x2
    ad80:      	bl	0xad80 <_coil.core.Push$coil.arraylist.ArrayList$push!__i32+0x5c>
		000000000000ad80:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ad84:      	add	x0, x19, #0x1
    ad88:      	ldr	x1, [x20]
    ad8c:      	add	x1, x1, x19, lsl #2
    ad90:      	str	w21, [x1]
    ad94:      	str	x0, [x20, #0x8]
    ad98:      	ldr	x19, [sp, #0x10]
    ad9c:      	ldr	x20, [sp, #0x18]
    ada0:      	ldr	x21, [sp, #0x20]
    ada4:      	ldr	x29, [sp]
    ada8:      	ldr	x30, [sp, #0x8]
    adac:      	add	sp, sp, #0x30
    adb0:      	ret

000000000000adb4 <_coil.core.Set$coil.arraylist.ArrayList$set!__i32>:
    adb4:      	ldr	x0, [x0]
    adb8:      	add	x0, x0, x1, lsl #2
    adbc:      	str	w2, [x0]
    adc0:      	movz	x0, #0x0, lsl #48
    adc4:      	ret

000000000000adc8 <_stogir.opcode.control?>:
    adc8:      	sxtw	x0, w0
    adcc:      	cmp	x0, #0x0
    add0:      	b.lt	0xadf0 <_stogir.opcode.control?+0x28>
    add4:      	cmp	x0, #0x83
    add8:      	b.ge	0xadf0 <_stogir.opcode.control?+0x28>
    addc:      	adrp	x16, 0xa000 <_stogir.verify.structure+0x5a0>
		000000000000addc:  ARM64_RELOC_PAGE21	l_stogir.490
    ade0:      	ldr	x16, [x16]
		000000000000ade0:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    ade4:      	add	x0, x16, x0
    ade8:      	ldrb	w0, [x0]
    adec:      	b	0xadf4 <_stogir.opcode.control?+0x2c>
    adf0:      	movz	w0, #0x0, lsl #16
    adf4:      	uxtb	w16, w0
    adf8:      	and	w0, w16, #0x1
    adfc:      	uxtb	w0, w0
    ae00:      	ubfx	x0, x0, #0, #8
    ae04:      	ret

000000000000ae08 <_inherent$coil.arraylist.ArrayList$clear!__i32>:
    ae08:      	b	0xae18 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x10>
    ae0c:      	nop
    ae10:      	sub	x1, x1, #0x1
    ae14:      	str	x1, [x0, #0x8]
    ae18:      	ldr	x1, [x0, #0x8]
    ae1c:      	cmp	x1, #0x0
    ae20:      	b.ne	0xae10 <_inherent$coil.arraylist.ArrayList$clear!__i32+0x8>
    ae24:      	movz	x0, #0x0, lsl #48
    ae28:      	ret

000000000000ae2c <_stogir.graph.operand>:
    ae2c:      	sub	sp, sp, #0x10
    ae30:      	mov	x3, sp
    ae34:      	sxtw	x1, w1
    ae38:      	cmp	x1, #0x0
    ae3c:      	b.le	0xae80 <_stogir.graph.operand+0x54>
    ae40:      	lsl	x4, x1, #2
    ae44:      	add	x5, x0, #0x78
    ae48:      	ldr	x6, [x0, #0x8]
    ae4c:      	cmp	x1, x6
    ae50:      	b.ge	0xaeb4 <_stogir.graph.operand+0x88>
    ae54:      	ldr	x5, [x5, #0x8]
    ae58:      	cmp	x1, x5
    ae5c:      	b.ge	0xaeac <_stogir.graph.operand+0x80>
    ae60:      	ldr	x5, [x0, #0x78]
    ae64:      	add	x5, x4, x5
    ae68:      	ldr	w5, [x5]
    ae6c:      	sxtw	x5, w5
    ae70:      	cmp	x5, #0x0
    ae74:      	cset	w5, ge
    ae78:      	ubfx	x5, x5, #0, #8
    ae7c:      	b	0xaeb0 <_stogir.graph.operand+0x84>
    ae80:      	movz	x1, #0x0, lsl #48
    ae84:      	movz	x0, #0x0, lsl #48
    ae88:      	str	x1, [x3]
    ae8c:      	str	x0, [x3, #0x8]
    ae90:      	ldr	x0, [sp]
    ae94:      	ldr	x1, [sp, #0x8]
    ae98:      	add	sp, sp, #0x10
    ae9c:      	ret
    aea0:      	movz	x1, #0x0, lsl #48
    aea4:      	movz	x0, #0x0, lsl #48
    aea8:      	b	0xae88 <_stogir.graph.operand+0x5c>
    aeac:      	movz	x5, #0x0, lsl #48
    aeb0:      	b	0xaeb8 <_stogir.graph.operand+0x8c>
    aeb4:      	movz	x5, #0x0, lsl #48
    aeb8:      	cmp	x5, #0x0
    aebc:      	b.eq	0xae80 <_stogir.graph.operand+0x54>
    aec0:      	sxtw	x2, w2
    aec4:      	cmp	x2, #0x1
    aec8:      	b.lt	0xaea0 <_stogir.graph.operand+0x74>
    aecc:      	ldr	x5, [x0, #0x78]
    aed0:      	add	x4, x4, x5
    aed4:      	ldr	w4, [x4]
    aed8:      	sxtw	x4, w4
    aedc:      	cmp	x2, x4
    aee0:      	b.gt	0xaea0 <_stogir.graph.operand+0x74>
    aee4:      	ldr	x0, [x0]
    aee8:      	asr	x16, x2, #63
    aeec:      	lsr	x16, x16, #62
    aef0:      	add	x4, x2, x16
    aef4:      	asr	x4, x4, #2
    aef8:      	asr	x16, x2, #63
    aefc:      	lsr	x16, x16, #62
    af00:      	add	x2, x2, x16
    af04:      	and	x2, x2, #0x3
    af08:      	sub	x2, x2, x16
    af0c:      	add	x1, x4, x1
    af10:      	add	x0, x0, x1, lsl #4
    af14:      	add	x0, x0, x2, lsl #2
    af18:      	ldr	w0, [x0]
    af1c:      	sxtw	x0, w0
    af20:      	and	x0, x0, #0xffffffff
    af24:      	mov	x1, #0x1                ; =1
    af28:      	b	0xaea8 <_stogir.graph.operand+0x7c>

000000000000af2c <_inherent$coil.arraylist.ArrayList$new__bool>:
    af2c:      	ldr	x1, [x0]
    af30:      	ldr	x0, [x0, #0x8]
    af34:      	movz	x17, #0x0, lsl #48
    af38:      	str	x17, [x8]
    af3c:      	movz	x17, #0x0, lsl #48
    af40:      	str	x17, [x8, #0x8]
    af44:      	movz	x17, #0x0, lsl #48
    af48:      	str	x17, [x8, #0x10]
    af4c:      	str	x1, [x8, #0x18]
    af50:      	str	x0, [x8, #0x20]
    af54:      	ret

000000000000af58 <_inherent$coil.arraylist.ArrayList$new__stogir.adjacency.Frame>:
    af58:      	ldr	x1, [x0]
    af5c:      	ldr	x0, [x0, #0x8]
    af60:      	movz	x17, #0x0, lsl #48
    af64:      	str	x17, [x8]
    af68:      	movz	x17, #0x0, lsl #48
    af6c:      	str	x17, [x8, #0x8]
    af70:      	movz	x17, #0x0, lsl #48
    af74:      	str	x17, [x8, #0x10]
    af78:      	str	x1, [x8, #0x18]
    af7c:      	str	x0, [x8, #0x20]
    af80:      	ret

000000000000af84 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool>:
    af84:      	sub	sp, sp, #0x30
    af88:      	str	x29, [sp]
    af8c:      	str	x30, [sp, #0x8]
    af90:      	mov	x29, sp
    af94:      	str	x19, [sp, #0x10]
    af98:      	str	x20, [sp, #0x18]
    af9c:      	str	x21, [sp, #0x20]
    afa0:      	str	x22, [sp, #0x28]
    afa4:      	ldr	x2, [x0, #0x8]
    afa8:      	orr	x19, x2, xzr
    afac:      	ldr	x2, [x0, #0x10]
    afb0:      	add	x20, x19, x1
    afb4:      	cmp	x20, x2
    afb8:      	b.le	0xb034 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0xb0>
    afbc:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    afc0:      	cmp	x2, x17
    afc4:      	b.gt	0xafd0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x4c>
    afc8:      	lsl	x2, x2, #1
    afcc:      	b	0xafd4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x50>
    afd0:      	mov	x2, x20
    afd4:      	cmp	x2, x20
    afd8:      	b.gt	0xafe0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x5c>
    afdc:      	mov	x2, x20
    afe0:      	mov	x21, x0
    afe4:      	mov	x22, x1
    afe8:      	mov	x1, x2
    afec:      	bl	0xafec <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x68>
		000000000000afec:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__bool
    aff0:      	lsr	x0, x22, #0
    aff4:      	ldr	x1, [x21]
    aff8:      	add	x1, x1, x19
    affc:      	mov	x2, x0
    b000:      	mov	x0, x1
    b004:      	movz	x1, #0x0, lsl #48
    b008:      	bl	0xb008 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x84>
		000000000000b008:  ARM64_RELOC_BRANCH26	_memset
    b00c:      	str	x20, [x21, #0x8]
    b010:      	mov	x0, x20
    b014:      	ldr	x19, [sp, #0x10]
    b018:      	ldr	x20, [sp, #0x18]
    b01c:      	ldr	x21, [sp, #0x20]
    b020:      	ldr	x22, [sp, #0x28]
    b024:      	ldr	x29, [sp]
    b028:      	ldr	x30, [sp, #0x8]
    b02c:      	add	sp, sp, #0x30
    b030:      	ret
    b034:      	mov	x21, x0
    b038:      	mov	x22, x1
    b03c:      	b	0xaff0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x6c>

000000000000b040 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame>:
    b040:      	sub	sp, sp, #0x30
    b044:      	str	x29, [sp]
    b048:      	str	x30, [sp, #0x8]
    b04c:      	mov	x29, sp
    b050:      	str	x19, [sp, #0x10]
    b054:      	str	x20, [sp, #0x18]
    b058:      	str	x21, [sp, #0x20]
    b05c:      	str	x22, [sp, #0x28]
    b060:      	ldr	x3, [x0, #0x8]
    b064:      	orr	x19, x3, xzr
    b068:      	ldr	x3, [x0, #0x10]
    b06c:      	cmp	x19, x3
    b070:      	b.lt	0xb084 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x44>
    b074:      	cmp	x3, #0x0
    b078:      	b.ne	0xb094 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x54>
    b07c:      	mov	x3, #0x2                ; =2
    b080:      	b	0xb098 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x58>
    b084:      	mov	x20, x0
    b088:      	mov	x21, x1
    b08c:      	mov	x22, x2
    b090:      	b	0xb0ac <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x6c>
    b094:      	lsl	x3, x3, #1
    b098:      	mov	x20, x0
    b09c:      	mov	x21, x1
    b0a0:      	mov	x1, x3
    b0a4:      	mov	x22, x2
    b0a8:      	bl	0xb0a8 <_coil.core.Push$coil.arraylist.ArrayList$push!__stogir.adjacency.Frame+0x68>
		000000000000b0a8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame
    b0ac:      	add	x0, x19, #0x1
    b0b0:      	ldr	x1, [x20]
    b0b4:      	add	x1, x1, x19, lsl #4
    b0b8:      	str	x21, [x1]
    b0bc:      	str	x22, [x1, #0x8]
    b0c0:      	str	x0, [x20, #0x8]
    b0c4:      	ldr	x19, [sp, #0x10]
    b0c8:      	ldr	x20, [sp, #0x18]
    b0cc:      	ldr	x21, [sp, #0x20]
    b0d0:      	ldr	x22, [sp, #0x28]
    b0d4:      	ldr	x29, [sp]
    b0d8:      	ldr	x30, [sp, #0x8]
    b0dc:      	add	sp, sp, #0x30
    b0e0:      	ret
    b0e4:      	udf	#0x0

000000000000b0e8 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame>:
    b0e8:      	sub	sp, sp, #0x20
    b0ec:      	str	x29, [sp]
    b0f0:      	str	x30, [sp, #0x8]
    b0f4:      	mov	x29, sp
    b0f8:      	str	x19, [sp, #0x10]
    b0fc:      	b	0xb108 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x20>
    b100:      	sub	x1, x1, #0x1
    b104:      	str	x1, [x0, #0x8]
    b108:      	ldr	x1, [x0, #0x8]
    b10c:      	cmp	x1, #0x0
    b110:      	b.ne	0xb100 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x18>
    b114:      	ldr	x1, [x0, #0x10]
    b118:      	cmp	x1, #0x0
    b11c:      	b.le	0xb17c <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x94>
    b120:      	add	x2, x0, #0x18
    b124:      	ldr	x3, [x0]
    b128:      	mov	x19, x0
    b12c:      	mov	x0, x2
    b130:      	mov	x2, x1
    b134:      	mov	x1, x3
    b138:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000b138:  ARM64_RELOC_PAGE21	l_stogir.491
    b13c:      	ldr	x3, [x3]
		000000000000b13c:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    b140:      	mov	x4, #0x10               ; =16
    b144:      	mov	x5, #0x8                ; =8
    b148:      	bl	0xb148 <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x60>
		000000000000b148:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b14c:      	movz	x17, #0x0, lsl #48
    b150:      	str	x17, [x19]
    b154:      	movz	x17, #0x0, lsl #48
    b158:      	str	x17, [x19, #0x8]
    b15c:      	movz	x17, #0x0, lsl #48
    b160:      	str	x17, [x19, #0x10]
    b164:      	movz	x0, #0x0, lsl #48
    b168:      	ldr	x19, [sp, #0x10]
    b16c:      	ldr	x29, [sp]
    b170:      	ldr	x30, [sp, #0x8]
    b174:      	add	sp, sp, #0x20
    b178:      	ret
    b17c:      	mov	x19, x0
    b180:      	b	0xb14c <_inherent$coil.arraylist.ArrayList$free!__stogir.adjacency.Frame+0x64>

000000000000b184 <_inherent$coil.arraylist.ArrayList$new__i64>:
    b184:      	ldr	x1, [x0]
    b188:      	ldr	x0, [x0, #0x8]
    b18c:      	movz	x17, #0x0, lsl #48
    b190:      	str	x17, [x8]
    b194:      	movz	x17, #0x0, lsl #48
    b198:      	str	x17, [x8, #0x8]
    b19c:      	movz	x17, #0x0, lsl #48
    b1a0:      	str	x17, [x8, #0x10]
    b1a4:      	str	x1, [x8, #0x18]
    b1a8:      	str	x0, [x8, #0x20]
    b1ac:      	ret

000000000000b1b0 <_inherent$coil.arraylist.ArrayList$free!__i64>:
    b1b0:      	sub	sp, sp, #0x20
    b1b4:      	str	x29, [sp]
    b1b8:      	str	x30, [sp, #0x8]
    b1bc:      	mov	x29, sp
    b1c0:      	str	x19, [sp, #0x10]
    b1c4:      	b	0xb1d0 <_inherent$coil.arraylist.ArrayList$free!__i64+0x20>
    b1c8:      	sub	x1, x1, #0x1
    b1cc:      	str	x1, [x0, #0x8]
    b1d0:      	ldr	x1, [x0, #0x8]
    b1d4:      	cmp	x1, #0x0
    b1d8:      	b.ne	0xb1c8 <_inherent$coil.arraylist.ArrayList$free!__i64+0x18>
    b1dc:      	ldr	x1, [x0, #0x10]
    b1e0:      	cmp	x1, #0x0
    b1e4:      	b.le	0xb244 <_inherent$coil.arraylist.ArrayList$free!__i64+0x94>
    b1e8:      	add	x2, x0, #0x18
    b1ec:      	ldr	x3, [x0]
    b1f0:      	mov	x19, x0
    b1f4:      	mov	x0, x2
    b1f8:      	mov	x2, x1
    b1fc:      	mov	x1, x3
    b200:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000b200:  ARM64_RELOC_PAGE21	l_stogir.492
    b204:      	ldr	x3, [x3]
		000000000000b204:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    b208:      	mov	x4, #0x8                ; =8
    b20c:      	mov	x5, #0x8                ; =8
    b210:      	bl	0xb210 <_inherent$coil.arraylist.ArrayList$free!__i64+0x60>
		000000000000b210:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b214:      	movz	x17, #0x0, lsl #48
    b218:      	str	x17, [x19]
    b21c:      	movz	x17, #0x0, lsl #48
    b220:      	str	x17, [x19, #0x8]
    b224:      	movz	x17, #0x0, lsl #48
    b228:      	str	x17, [x19, #0x10]
    b22c:      	movz	x0, #0x0, lsl #48
    b230:      	ldr	x19, [sp, #0x10]
    b234:      	ldr	x29, [sp]
    b238:      	ldr	x30, [sp, #0x8]
    b23c:      	add	sp, sp, #0x20
    b240:      	ret
    b244:      	mov	x19, x0
    b248:      	b	0xb214 <_inherent$coil.arraylist.ArrayList$free!__i64+0x64>
    b24c:      	udf	#0x0

000000000000b250 <_stogir.dominators.build-index>:
    b250:      	sub	sp, sp, #0x130
    b254:      	str	x29, [sp]
    b258:      	str	x30, [sp, #0x8]
    b25c:      	mov	x29, sp
    b260:      	str	x19, [sp, #0xf0]
    b264:      	str	x20, [sp, #0xf8]
    b268:      	str	x21, [sp, #0x100]
    b26c:      	str	x22, [sp, #0x108]
    b270:      	str	x23, [sp, #0x110]
    b274:      	str	x24, [sp, #0x118]
    b278:      	str	x25, [sp, #0x120]
    b27c:      	ldr	x2, [x0, #0x8]
    b280:      	orr	x19, x2, xzr
    b284:      	ldr	x2, [x1]
    b288:      	ldr	x1, [x1, #0x8]
    b28c:      	add	x16, sp, #0x10
    b290:      	movz	x17, #0x0, lsl #48
    b294:      	str	x17, [x16]
    b298:      	add	x16, sp, #0x10
    b29c:      	movz	x17, #0x0, lsl #48
    b2a0:      	str	x17, [x16, #0x8]
    b2a4:      	add	x16, sp, #0x10
    b2a8:      	movz	x17, #0x0, lsl #48
    b2ac:      	str	x17, [x16, #0x10]
    b2b0:      	add	x16, sp, #0x10
    b2b4:      	str	x2, [x16, #0x18]
    b2b8:      	add	x16, sp, #0x10
    b2bc:      	str	x1, [x16, #0x20]
    b2c0:      	add	x16, sp, #0x10
    b2c4:      	movz	x17, #0x0, lsl #48
    b2c8:      	str	x17, [x16, #0x28]
    b2cc:      	add	x16, sp, #0x10
    b2d0:      	movz	x17, #0x0, lsl #48
    b2d4:      	str	x17, [x16, #0x30]
    b2d8:      	add	x16, sp, #0x10
    b2dc:      	movz	x17, #0x0, lsl #48
    b2e0:      	str	x17, [x16, #0x38]
    b2e4:      	add	x16, sp, #0x10
    b2e8:      	str	x2, [x16, #0x40]
    b2ec:      	add	x16, sp, #0x10
    b2f0:      	str	x1, [x16, #0x48]
    b2f4:      	add	x16, sp, #0x60
    b2f8:      	movz	x17, #0x0, lsl #48
    b2fc:      	str	x17, [x16]
    b300:      	add	x16, sp, #0x60
    b304:      	movz	x17, #0x0, lsl #48
    b308:      	str	x17, [x16, #0x8]
    b30c:      	add	x16, sp, #0x60
    b310:      	movz	x17, #0x0, lsl #48
    b314:      	str	x17, [x16, #0x10]
    b318:      	add	x16, sp, #0x60
    b31c:      	str	x2, [x16, #0x18]
    b320:      	add	x16, sp, #0x60
    b324:      	str	x1, [x16, #0x20]
    b328:      	add	x16, sp, #0x90
    b32c:      	movz	x17, #0x0, lsl #48
    b330:      	str	x17, [x16]
    b334:      	add	x16, sp, #0x90
    b338:      	movz	x17, #0x0, lsl #48
    b33c:      	str	x17, [x16, #0x8]
    b340:      	add	x16, sp, #0x90
    b344:      	movz	x17, #0x0, lsl #48
    b348:      	str	x17, [x16, #0x10]
    b34c:      	add	x16, sp, #0x90
    b350:      	str	x2, [x16, #0x18]
    b354:      	add	x16, sp, #0x90
    b358:      	str	x1, [x16, #0x20]
    b35c:      	add	x16, sp, #0xc0
    b360:      	movz	x17, #0x0, lsl #48
    b364:      	str	x17, [x16]
    b368:      	add	x16, sp, #0xc0
    b36c:      	movz	x17, #0x0, lsl #48
    b370:      	str	x17, [x16, #0x8]
    b374:      	add	x16, sp, #0xc0
    b378:      	movz	x17, #0x0, lsl #48
    b37c:      	str	x17, [x16, #0x10]
    b380:      	add	x16, sp, #0xc0
    b384:      	str	x2, [x16, #0x18]
    b388:      	add	x16, sp, #0xc0
    b38c:      	str	x1, [x16, #0x20]
    b390:      	cmp	x19, #0x0
    b394:      	b.le	0xb938 <_stogir.dominators.build-index+0x6e8>
    b398:      	cmp	x19, #0x0
    b39c:      	b.ge	0xb3a8 <_stogir.dominators.build-index+0x158>
    b3a0:      	movz	x1, #0x0, lsl #48
    b3a4:      	b	0xb3ac <_stogir.dominators.build-index+0x15c>
    b3a8:      	mov	x1, x19
    b3ac:      	mov	x20, x8
    b3b0:      	mov	x21, x0
    b3b4:      	add	x0, sp, #0x10
    b3b8:      	bl	0xb3b8 <_stogir.dominators.build-index+0x168>
		000000000000b3b8:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b3bc:      	add	x16, sp, #0x10
    b3c0:      	orr	x0, x16, xzr
    b3c4:      	lsl	x1, x19, #2
    b3c8:      	add	x22, x0, #0x28
    b3cc:      	add	x16, sp, #0x10
    b3d0:      	ldr	x0, [x16]
    b3d4:      	mov	x2, x1
    b3d8:      	movz	x1, #0x0, lsl #48
    b3dc:      	bl	0xb3dc <_stogir.dominators.build-index+0x18c>
		000000000000b3dc:  ARM64_RELOC_BRANCH26	_memset
    b3e0:      	add	x16, sp, #0x10
    b3e4:      	str	x19, [x16, #0x8]
    b3e8:      	ldr	x0, [x22, #0x8]
    b3ec:      	orr	x23, x0, xzr
    b3f0:      	ldr	x0, [x22, #0x10]
    b3f4:      	add	x24, x23, x19
    b3f8:      	cmp	x24, x0
    b3fc:      	b.le	0xb430 <_stogir.dominators.build-index+0x1e0>
    b400:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b404:      	cmp	x0, x17
    b408:      	b.gt	0xb414 <_stogir.dominators.build-index+0x1c4>
    b40c:      	lsl	x0, x0, #1
    b410:      	b	0xb418 <_stogir.dominators.build-index+0x1c8>
    b414:      	mov	x0, x24
    b418:      	cmp	x0, x24
    b41c:      	b.gt	0xb424 <_stogir.dominators.build-index+0x1d4>
    b420:      	mov	x0, x24
    b424:      	mov	x1, x0
    b428:      	mov	x0, x22
    b42c:      	bl	0xb42c <_stogir.dominators.build-index+0x1dc>
		000000000000b42c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b430:      	lsl	x0, x19, #2
    b434:      	add	x16, sp, #0x10
    b438:      	ldr	x1, [x16, #0x28]
    b43c:      	add	x1, x1, x23, lsl #2
    b440:      	mov	x2, x0
    b444:      	mov	x0, x1
    b448:      	movz	x1, #0x0, lsl #48
    b44c:      	bl	0xb44c <_stogir.dominators.build-index+0x1fc>
		000000000000b44c:  ARM64_RELOC_BRANCH26	_memset
    b450:      	str	x24, [x22, #0x8]
    b454:      	add	x16, sp, #0x60
    b458:      	ldr	x0, [x16, #0x8]
    b45c:      	orr	x22, x0, xzr
    b460:      	add	x16, sp, #0x60
    b464:      	ldr	x0, [x16, #0x10]
    b468:      	add	x23, x22, x19
    b46c:      	cmp	x23, x0
    b470:      	b.le	0xb4a4 <_stogir.dominators.build-index+0x254>
    b474:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    b478:      	cmp	x0, x17
    b47c:      	b.gt	0xb488 <_stogir.dominators.build-index+0x238>
    b480:      	lsl	x0, x0, #1
    b484:      	b	0xb48c <_stogir.dominators.build-index+0x23c>
    b488:      	mov	x0, x23
    b48c:      	cmp	x0, x23
    b490:      	b.gt	0xb498 <_stogir.dominators.build-index+0x248>
    b494:      	mov	x0, x23
    b498:      	mov	x1, x0
    b49c:      	add	x0, sp, #0x60
    b4a0:      	bl	0xb4a0 <_stogir.dominators.build-index+0x250>
		000000000000b4a0:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b4a4:      	lsl	x0, x19, #2
    b4a8:      	add	x16, sp, #0x60
    b4ac:      	ldr	x1, [x16]
    b4b0:      	add	x1, x1, x22, lsl #2
    b4b4:      	mov	x2, x0
    b4b8:      	mov	x0, x1
    b4bc:      	movz	x1, #0x0, lsl #48
    b4c0:      	bl	0xb4c0 <_stogir.dominators.build-index+0x270>
		000000000000b4c0:  ARM64_RELOC_BRANCH26	_memset
    b4c4:      	add	x16, sp, #0x60
    b4c8:      	str	x23, [x16, #0x8]
    b4cc:      	add	x0, sp, #0x90
    b4d0:      	mov	x1, x19
    b4d4:      	bl	0xb4d4 <_stogir.dominators.build-index+0x284>
		000000000000b4d4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$extend-zeroed!__i32
    b4d8:      	movz	x0, #0x0, lsl #48
    b4dc:      	b	0xb514 <_stogir.dominators.build-index+0x2c4>
    b4e0:      	orr	w2, w0, wzr
    b4e4:      	add	x16, sp, #0x60
    b4e8:      	ldr	x3, [x16]
    b4ec:      	add	x3, x3, x1, lsl #2
    b4f0:      	ldr	w3, [x3]
    b4f4:      	add	x16, sp, #0x90
    b4f8:      	ldr	x4, [x16]
    b4fc:      	add	x4, x4, x0, lsl #2
    b500:      	str	w3, [x4]
    b504:      	add	x16, sp, #0x60
    b508:      	ldr	x3, [x16]
    b50c:      	add	x1, x3, x1, lsl #2
    b510:      	str	w2, [x1]
    b514:      	add	x0, x0, #0x1
    b518:      	cmp	x0, x19
    b51c:      	b.ge	0xb544 <_stogir.dominators.build-index+0x2f4>
    b520:      	ldr	x1, [x21]
    b524:      	add	x1, x1, x0, lsl #2
    b528:      	ldr	w1, [x1]
    b52c:      	sxtw	x1, w1
    b530:      	cmp	x1, #0x0
    b534:      	b.le	0xb514 <_stogir.dominators.build-index+0x2c4>
    b538:      	cmp	x1, x0
    b53c:      	b.ne	0xb4e0 <_stogir.dominators.build-index+0x290>
    b540:      	b	0xb514 <_stogir.dominators.build-index+0x2c4>
    b544:      	movz	x22, #0x0, lsl #48
    b548:      	movz	x0, #0x0, lsl #48
    b54c:      	b	0xb690 <_stogir.dominators.build-index+0x440>
    b550:      	lsl	x0, x0, #1
    b554:      	mov	x1, x0
    b558:      	add	x0, sp, #0xc0
    b55c:      	bl	0xb55c <_stogir.dominators.build-index+0x30c>
		000000000000b55c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b560:      	sxtw	x0, w23
    b564:      	orr	w1, w22, wzr
    b568:      	add	x2, x24, #0x1
    b56c:      	add	x16, sp, #0xc0
    b570:      	ldr	x3, [x16]
    b574:      	add	x3, x3, x24, lsl #2
    b578:      	str	w1, [x3]
    b57c:      	add	x16, sp, #0xc0
    b580:      	str	x2, [x16, #0x8]
    b584:      	b	0xb5b8 <_stogir.dominators.build-index+0x368>
    b588:      	lsl	x0, x0, #1
    b58c:      	mov	x1, x0
    b590:      	add	x0, sp, #0xc0
    b594:      	bl	0xb594 <_stogir.dominators.build-index+0x344>
		000000000000b594:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    b598:      	sxtw	x0, w24
    b59c:      	add	x1, x25, #0x1
    b5a0:      	add	x16, sp, #0xc0
    b5a4:      	ldr	x2, [x16]
    b5a8:      	add	x2, x2, x25, lsl #2
    b5ac:      	str	w23, [x2]
    b5b0:      	add	x16, sp, #0xc0
    b5b4:      	str	x1, [x16, #0x8]
    b5b8:      	add	x16, sp, #0xc0
    b5bc:      	ldr	x1, [x16, #0x8]
    b5c0:      	cmp	x1, #0x0
    b5c4:      	b.le	0xb690 <_stogir.dominators.build-index+0x440>
    b5c8:      	add	x16, sp, #0xc0
    b5cc:      	ldr	x2, [x16]
    b5d0:      	sub	x1, x1, #0x1
    b5d4:      	add	x1, x2, x1, lsl #2
    b5d8:      	ldr	w1, [x1]
    b5dc:      	sxtw	x1, w1
    b5e0:      	add	x16, sp, #0x60
    b5e4:      	ldr	x2, [x16]
    b5e8:      	add	x3, x2, x1, lsl #2
    b5ec:      	ldr	w23, [x3]
    b5f0:      	sxtw	x3, w23
    b5f4:      	cmp	x3, #0x0
    b5f8:      	b.le	0xb658 <_stogir.dominators.build-index+0x408>
    b5fc:      	add	x0, x0, #0x1
    b600:      	add	x16, sp, #0x90
    b604:      	ldr	x4, [x16]
    b608:      	orr	w24, w0, wzr
    b60c:      	add	x0, x2, x1, lsl #2
    b610:      	add	x1, x4, x3, lsl #2
    b614:      	ldr	w1, [x1]
    b618:      	str	w1, [x0]
    b61c:      	add	x16, sp, #0x10
    b620:      	ldr	x0, [x16]
    b624:      	add	x0, x0, x3, lsl #2
    b628:      	str	w24, [x0]
    b62c:      	add	x16, sp, #0xc0
    b630:      	ldr	x0, [x16, #0x8]
    b634:      	orr	x25, x0, xzr
    b638:      	add	x16, sp, #0xc0
    b63c:      	ldr	x0, [x16, #0x10]
    b640:      	cmp	x25, x0
    b644:      	b.lt	0xb598 <_stogir.dominators.build-index+0x348>
    b648:      	cmp	x0, #0x0
    b64c:      	b.ne	0xb588 <_stogir.dominators.build-index+0x338>
    b650:      	mov	x0, #0x2                ; =2
    b654:      	b	0xb58c <_stogir.dominators.build-index+0x33c>
    b658:      	orr	w2, w0, wzr
    b65c:      	add	x16, sp, #0x10
    b660:      	ldr	x3, [x16, #0x28]
    b664:      	add	x1, x3, x1, lsl #2
    b668:      	str	w2, [x1]
    b66c:      	add	x16, sp, #0xc0
    b670:      	ldr	x1, [x16, #0x8]
    b674:      	cmp	x1, #0x0
    b678:      	b.eq	0xb5b8 <_stogir.dominators.build-index+0x368>
    b67c:      	sub	x1, x1, #0x1
    b680:      	add	x16, sp, #0xc0
    b684:      	str	x1, [x16, #0x8]
    b688:      	b	0xb5b8 <_stogir.dominators.build-index+0x368>
    b68c:      	nop
    b690:      	add	x22, x22, #0x1
    b694:      	cmp	x22, x19
    b698:      	b.ge	0xb6f8 <_stogir.dominators.build-index+0x4a8>
    b69c:      	ldr	x1, [x21]
    b6a0:      	add	x1, x1, x22, lsl #2
    b6a4:      	ldr	w1, [x1]
    b6a8:      	sxtw	x1, w1
    b6ac:      	cmp	x1, x22
    b6b0:      	b.ne	0xb690 <_stogir.dominators.build-index+0x440>
    b6b4:      	add	x0, x0, #0x1
    b6b8:      	add	x16, sp, #0x10
    b6bc:      	ldr	x1, [x16]
    b6c0:      	orr	w23, w0, wzr
    b6c4:      	add	x0, x1, x22, lsl #2
    b6c8:      	str	w23, [x0]
    b6cc:      	add	x16, sp, #0xc0
    b6d0:      	ldr	x0, [x16, #0x8]
    b6d4:      	orr	x24, x0, xzr
    b6d8:      	add	x16, sp, #0xc0
    b6dc:      	ldr	x0, [x16, #0x10]
    b6e0:      	cmp	x24, x0
    b6e4:      	b.lt	0xb560 <_stogir.dominators.build-index+0x310>
    b6e8:      	cmp	x0, #0x0
    b6ec:      	b.ne	0xb550 <_stogir.dominators.build-index+0x300>
    b6f0:      	mov	x0, #0x2                ; =2
    b6f4:      	b	0xb554 <_stogir.dominators.build-index+0x304>
    b6f8:      	b	0xb70c <_stogir.dominators.build-index+0x4bc>
    b6fc:      	nop
    b700:      	sub	x0, x0, #0x1
    b704:      	add	x16, sp, #0xc0
    b708:      	str	x0, [x16, #0x8]
    b70c:      	add	x16, sp, #0xc0
    b710:      	ldr	x0, [x16, #0x8]
    b714:      	cmp	x0, #0x0
    b718:      	b.ne	0xb700 <_stogir.dominators.build-index+0x4b0>
    b71c:      	add	x16, sp, #0xc0
    b720:      	orr	x0, x16, xzr
    b724:      	add	x16, sp, #0xc0
    b728:      	ldr	x1, [x16, #0x10]
    b72c:      	cmp	x1, #0x0
    b730:      	b.le	0xb760 <_stogir.dominators.build-index+0x510>
    b734:      	add	x0, x0, #0x18
    b738:      	add	x16, sp, #0xc0
    b73c:      	ldr	x2, [x16]
    b740:      	fmov	d31, x1
    b744:      	mov	x1, x2
    b748:      	fmov	x2, d31
    b74c:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000b74c:  ARM64_RELOC_PAGE21	l_stogir.493
    b750:      	ldr	x3, [x3]
		000000000000b750:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b754:      	mov	x4, #0x4                ; =4
    b758:      	mov	x5, #0x4                ; =4
    b75c:      	bl	0xb75c <_stogir.dominators.build-index+0x50c>
		000000000000b75c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b760:      	add	x16, sp, #0xc0
    b764:      	movz	x17, #0x0, lsl #48
    b768:      	str	x17, [x16]
    b76c:      	add	x16, sp, #0xc0
    b770:      	movz	x17, #0x0, lsl #48
    b774:      	str	x17, [x16, #0x8]
    b778:      	add	x16, sp, #0xc0
    b77c:      	movz	x17, #0x0, lsl #48
    b780:      	str	x17, [x16, #0x10]
    b784:      	b	0xb794 <_stogir.dominators.build-index+0x544>
    b788:      	sub	x0, x0, #0x1
    b78c:      	add	x16, sp, #0x90
    b790:      	str	x0, [x16, #0x8]
    b794:      	add	x16, sp, #0x90
    b798:      	ldr	x0, [x16, #0x8]
    b79c:      	cmp	x0, #0x0
    b7a0:      	b.ne	0xb788 <_stogir.dominators.build-index+0x538>
    b7a4:      	add	x16, sp, #0x90
    b7a8:      	orr	x0, x16, xzr
    b7ac:      	add	x16, sp, #0x90
    b7b0:      	ldr	x1, [x16, #0x10]
    b7b4:      	cmp	x1, #0x0
    b7b8:      	b.le	0xb7e8 <_stogir.dominators.build-index+0x598>
    b7bc:      	add	x0, x0, #0x18
    b7c0:      	add	x16, sp, #0x90
    b7c4:      	ldr	x2, [x16]
    b7c8:      	fmov	d31, x1
    b7cc:      	mov	x1, x2
    b7d0:      	fmov	x2, d31
    b7d4:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000b7d4:  ARM64_RELOC_PAGE21	l_stogir.493
    b7d8:      	ldr	x3, [x3]
		000000000000b7d8:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b7dc:      	mov	x4, #0x4                ; =4
    b7e0:      	mov	x5, #0x4                ; =4
    b7e4:      	bl	0xb7e4 <_stogir.dominators.build-index+0x594>
		000000000000b7e4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b7e8:      	add	x16, sp, #0x90
    b7ec:      	movz	x17, #0x0, lsl #48
    b7f0:      	str	x17, [x16]
    b7f4:      	add	x16, sp, #0x90
    b7f8:      	movz	x17, #0x0, lsl #48
    b7fc:      	str	x17, [x16, #0x8]
    b800:      	add	x16, sp, #0x90
    b804:      	movz	x17, #0x0, lsl #48
    b808:      	str	x17, [x16, #0x10]
    b80c:      	b	0xb81c <_stogir.dominators.build-index+0x5cc>
    b810:      	sub	x0, x0, #0x1
    b814:      	add	x16, sp, #0x60
    b818:      	str	x0, [x16, #0x8]
    b81c:      	add	x16, sp, #0x60
    b820:      	ldr	x0, [x16, #0x8]
    b824:      	cmp	x0, #0x0
    b828:      	b.ne	0xb810 <_stogir.dominators.build-index+0x5c0>
    b82c:      	add	x16, sp, #0x60
    b830:      	orr	x0, x16, xzr
    b834:      	add	x16, sp, #0x60
    b838:      	ldr	x1, [x16, #0x10]
    b83c:      	cmp	x1, #0x0
    b840:      	b.le	0xb870 <_stogir.dominators.build-index+0x620>
    b844:      	add	x0, x0, #0x18
    b848:      	add	x16, sp, #0x60
    b84c:      	ldr	x2, [x16]
    b850:      	fmov	d31, x1
    b854:      	mov	x1, x2
    b858:      	fmov	x2, d31
    b85c:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000b85c:  ARM64_RELOC_PAGE21	l_stogir.493
    b860:      	ldr	x3, [x3]
		000000000000b860:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b864:      	mov	x4, #0x4                ; =4
    b868:      	mov	x5, #0x4                ; =4
    b86c:      	bl	0xb86c <_stogir.dominators.build-index+0x61c>
		000000000000b86c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b870:      	add	x16, sp, #0x60
    b874:      	movz	x17, #0x0, lsl #48
    b878:      	str	x17, [x16]
    b87c:      	add	x16, sp, #0x60
    b880:      	movz	x17, #0x0, lsl #48
    b884:      	str	x17, [x16, #0x8]
    b888:      	add	x16, sp, #0x60
    b88c:      	movz	x17, #0x0, lsl #48
    b890:      	str	x17, [x16, #0x10]
    b894:      	add	x16, sp, #0x10
    b898:      	ldr	x0, [x16]
    b89c:      	add	x16, sp, #0x10
    b8a0:      	ldr	x1, [x16, #0x8]
    b8a4:      	add	x16, sp, #0x10
    b8a8:      	ldr	x2, [x16, #0x10]
    b8ac:      	add	x16, sp, #0x10
    b8b0:      	ldr	x3, [x16, #0x18]
    b8b4:      	add	x16, sp, #0x10
    b8b8:      	ldr	x4, [x16, #0x20]
    b8bc:      	add	x16, sp, #0x10
    b8c0:      	ldr	x5, [x16, #0x28]
    b8c4:      	add	x16, sp, #0x10
    b8c8:      	ldr	x6, [x16, #0x30]
    b8cc:      	add	x16, sp, #0x10
    b8d0:      	ldr	x7, [x16, #0x38]
    b8d4:      	add	x16, sp, #0x10
    b8d8:      	ldr	x8, [x16, #0x40]
    b8dc:      	add	x16, sp, #0x10
    b8e0:      	ldr	x9, [x16, #0x48]
    b8e4:      	str	x0, [x20]
    b8e8:      	str	x1, [x20, #0x8]
    b8ec:      	str	x2, [x20, #0x10]
    b8f0:      	str	x3, [x20, #0x18]
    b8f4:      	str	x4, [x20, #0x20]
    b8f8:      	str	x5, [x20, #0x28]
    b8fc:      	str	x6, [x20, #0x30]
    b900:      	str	x7, [x20, #0x38]
    b904:      	str	x8, [x20, #0x40]
    b908:      	str	x9, [x20, #0x48]
    b90c:      	ldr	x19, [sp, #0xf0]
    b910:      	ldr	x20, [sp, #0xf8]
    b914:      	ldr	x21, [sp, #0x100]
    b918:      	ldr	x22, [sp, #0x108]
    b91c:      	ldr	x23, [sp, #0x110]
    b920:      	ldr	x24, [sp, #0x118]
    b924:      	ldr	x25, [sp, #0x120]
    b928:      	ldr	x29, [sp]
    b92c:      	ldr	x30, [sp, #0x8]
    b930:      	add	sp, sp, #0x130
    b934:      	ret
    b938:      	mov	x20, x8
    b93c:      	mov	x21, x0
    b940:      	b	0xb3bc <_stogir.dominators.build-index+0x16c>
    b944:      	udf	#0x0

000000000000b948 <_stogir.dominators.release-index!>:
    b948:      	sub	sp, sp, #0x20
    b94c:      	str	x29, [sp]
    b950:      	str	x30, [sp, #0x8]
    b954:      	mov	x29, sp
    b958:      	str	x19, [sp, #0x10]
    b95c:      	str	x20, [sp, #0x18]
    b960:      	b	0xb970 <_stogir.dominators.release-index!+0x28>
    b964:      	nop
    b968:      	sub	x1, x1, #0x1
    b96c:      	str	x1, [x0, #0x8]
    b970:      	ldr	x1, [x0, #0x8]
    b974:      	cmp	x1, #0x0
    b978:      	b.ne	0xb968 <_stogir.dominators.release-index!+0x20>
    b97c:      	ldr	x1, [x0, #0x10]
    b980:      	cmp	x1, #0x0
    b984:      	b.le	0xba54 <_stogir.dominators.release-index!+0x10c>
    b988:      	add	x2, x0, #0x18
    b98c:      	ldr	x3, [x0]
    b990:      	mov	x19, x0
    b994:      	mov	x0, x2
    b998:      	mov	x2, x1
    b99c:      	mov	x1, x3
    b9a0:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000b9a0:  ARM64_RELOC_PAGE21	l_stogir.494
    b9a4:      	ldr	x3, [x3]
		000000000000b9a4:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    b9a8:      	mov	x4, #0x4                ; =4
    b9ac:      	mov	x5, #0x4                ; =4
    b9b0:      	bl	0xb9b0 <_stogir.dominators.release-index!+0x68>
		000000000000b9b0:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    b9b4:      	add	x20, x19, #0x28
    b9b8:      	movz	x17, #0x0, lsl #48
    b9bc:      	str	x17, [x19]
    b9c0:      	movz	x17, #0x0, lsl #48
    b9c4:      	str	x17, [x19, #0x8]
    b9c8:      	movz	x17, #0x0, lsl #48
    b9cc:      	str	x17, [x19, #0x10]
    b9d0:      	b	0xb9e0 <_stogir.dominators.release-index!+0x98>
    b9d4:      	nop
    b9d8:      	sub	x0, x0, #0x1
    b9dc:      	str	x0, [x20, #0x8]
    b9e0:      	ldr	x0, [x20, #0x8]
    b9e4:      	cmp	x0, #0x0
    b9e8:      	b.ne	0xb9d8 <_stogir.dominators.release-index!+0x90>
    b9ec:      	ldr	x0, [x20, #0x10]
    b9f0:      	cmp	x0, #0x0
    b9f4:      	b.le	0xba24 <_stogir.dominators.release-index!+0xdc>
    b9f8:      	add	x1, x20, #0x18
    b9fc:      	ldr	x2, [x19, #0x28]
    ba00:      	fmov	d31, x0
    ba04:      	mov	x0, x1
    ba08:      	mov	x1, x2
    ba0c:      	fmov	x2, d31
    ba10:      	adrp	x3, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000ba10:  ARM64_RELOC_PAGE21	l_stogir.494
    ba14:      	ldr	x3, [x3]
		000000000000ba14:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    ba18:      	mov	x4, #0x4                ; =4
    ba1c:      	mov	x5, #0x4                ; =4
    ba20:      	bl	0xba20 <_stogir.dominators.release-index!+0xd8>
		000000000000ba20:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    ba24:      	movz	x17, #0x0, lsl #48
    ba28:      	str	x17, [x19, #0x28]
    ba2c:      	movz	x17, #0x0, lsl #48
    ba30:      	str	x17, [x20, #0x8]
    ba34:      	movz	x17, #0x0, lsl #48
    ba38:      	str	x17, [x20, #0x10]
    ba3c:      	ldr	x19, [sp, #0x10]
    ba40:      	ldr	x20, [sp, #0x18]
    ba44:      	ldr	x29, [sp]
    ba48:      	ldr	x30, [sp, #0x8]
    ba4c:      	add	sp, sp, #0x20
    ba50:      	ret
    ba54:      	mov	x19, x0
    ba58:      	b	0xb9b4 <_stogir.dominators.release-index!+0x6c>

000000000000ba5c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64>:
    ba5c:      	sub	sp, sp, #0x30
    ba60:      	str	x29, [sp]
    ba64:      	str	x30, [sp, #0x8]
    ba68:      	mov	x29, sp
    ba6c:      	str	x19, [sp, #0x10]
    ba70:      	str	x20, [sp, #0x18]
    ba74:      	str	x21, [sp, #0x20]
    ba78:      	str	x22, [sp, #0x28]
    ba7c:      	ldr	x2, [x0, #0x8]
    ba80:      	orr	x19, x2, xzr
    ba84:      	ldr	x2, [x0, #0x10]
    ba88:      	add	x20, x19, x1
    ba8c:      	cmp	x20, x2
    ba90:      	b.le	0xbb0c <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0xb0>
    ba94:      	mov	x17, #0x3fffffffffffffff ; =4611686018427387903
    ba98:      	cmp	x2, x17
    ba9c:      	b.gt	0xbaa8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x4c>
    baa0:      	lsl	x2, x2, #1
    baa4:      	b	0xbaac <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x50>
    baa8:      	mov	x2, x20
    baac:      	cmp	x2, x20
    bab0:      	b.gt	0xbab8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x5c>
    bab4:      	mov	x2, x20
    bab8:      	mov	x21, x0
    babc:      	mov	x22, x1
    bac0:      	mov	x1, x2
    bac4:      	bl	0xbac4 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x68>
		000000000000bac4:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i64
    bac8:      	lsl	x0, x22, #3
    bacc:      	ldr	x1, [x21]
    bad0:      	add	x1, x1, x19, lsl #3
    bad4:      	mov	x2, x0
    bad8:      	mov	x0, x1
    badc:      	movz	x1, #0x0, lsl #48
    bae0:      	bl	0xbae0 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x84>
		000000000000bae0:  ARM64_RELOC_BRANCH26	_memset
    bae4:      	str	x20, [x21, #0x8]
    bae8:      	mov	x0, x20
    baec:      	ldr	x19, [sp, #0x10]
    baf0:      	ldr	x20, [sp, #0x18]
    baf4:      	ldr	x21, [sp, #0x20]
    baf8:      	ldr	x22, [sp, #0x28]
    bafc:      	ldr	x29, [sp]
    bb00:      	ldr	x30, [sp, #0x8]
    bb04:      	add	sp, sp, #0x30
    bb08:      	ret
    bb0c:      	mov	x21, x0
    bb10:      	mov	x22, x1
    bb14:      	b	0xbac8 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__i64+0x6c>

000000000000bb18 <_stogir.uses.scan!__constfalse>:
    bb18:      	sub	sp, sp, #0x10
    bb1c:      	mov	x3, #0x1                ; =1
    bb20:      	b	0xbc44 <_stogir.uses.scan!__constfalse+0x12c>
    bb24:      	sub	w10, w8, #0x1
    bb28:      	lsl	w10, w10, #2
    bb2c:      	ubfx	x10, x10, #0, #32
    bb30:      	lsr	x10, x5, x10
    bb34:      	and	w10, w10, #0xf
    bb38:      	b	0xbb44 <_stogir.uses.scan!__constfalse+0x2c>
    bb3c:      	nop
    bb40:      	movz	w10, #0x0, lsl #16
    bb44:      	ubfx	x10, x10, #0, #32
    bb48:      	cmp	x10, #0xf
    bb4c:      	b.hs	0xbbfc <_stogir.uses.scan!__constfalse+0xe4>
    bb50:      	mov	x16, #0x1               ; =1
    bb54:      	lsl	x10, x16, x10
    bb58:      	mov	w17, #0x5e1c            ; =24092
    bb5c:      	and	w10, w10, w17
    bb60:      	ubfx	x10, x10, #0, #32
    bb64:      	cmp	x10, #0x0
    bb68:      	b.eq	0xbbfc <_stogir.uses.scan!__constfalse+0xe4>
    bb6c:      	ldr	x10, [x0]
    bb70:      	asr	x16, x9, #63
    bb74:      	lsr	x16, x16, #62
    bb78:      	add	x11, x9, x16
    bb7c:      	asr	x11, x11, #2
    bb80:      	asr	x16, x9, #63
    bb84:      	lsr	x16, x16, #62
    bb88:      	add	x9, x9, x16
    bb8c:      	and	x9, x9, #0x3
    bb90:      	sub	x9, x9, x16
    bb94:      	add	x11, x11, x3
    bb98:      	add	x10, x10, x11, lsl #4
    bb9c:      	add	x9, x10, x9, lsl #2
    bba0:      	ldr	w9, [x9]
    bba4:      	sxtw	x9, w9
    bba8:      	cmp	x9, #0x0
    bbac:      	b.le	0xbbfc <_stogir.uses.scan!__constfalse+0xe4>
    bbb0:      	ldr	x10, [x2]
    bbb4:      	add	x10, x10, x9, lsl #3
    bbb8:      	ldr	x10, [x10]
    bbbc:      	mov	x16, sp
    bbc0:      	movz	x17, #0x0, lsl #48
    bbc4:      	str	x17, [x16]
    bbc8:      	add	x11, x10, #0x1
    bbcc:      	mov	x16, sp
    bbd0:      	str	w4, [x16]
    bbd4:      	mov	x16, sp
    bbd8:      	str	w8, [x16, #0x4]
    bbdc:      	mov	x16, sp
    bbe0:      	ldr	x8, [x16]
    bbe4:      	ldr	x12, [x1, #0x28]
    bbe8:      	add	x10, x12, x10, lsl #3
    bbec:      	str	x8, [x10]
    bbf0:      	ldr	x8, [x2]
    bbf4:      	add	x8, x8, x9, lsl #3
    bbf8:      	str	x11, [x8]
    bbfc:      	add	x7, x7, #0x1
    bc00:      	sxtw	x7, w7
    bc04:      	cmp	x7, x6
    bc08:      	b.gt	0xbc2c <_stogir.uses.scan!__constfalse+0x114>
    bc0c:      	orr	w8, w7, wzr
    bc10:      	sxtw	x9, w8
    bc14:      	cmp	x9, #0x0
    bc18:      	b.le	0xbb40 <_stogir.uses.scan!__constfalse+0x28>
    bc1c:      	cmp	x9, #0x4
    bc20:      	b.le	0xbb24 <_stogir.uses.scan!__constfalse+0xc>
    bc24:      	mov	w10, #0x4               ; =4
    bc28:      	b	0xbb28 <_stogir.uses.scan!__constfalse+0x10>
    bc2c:      	add	x4, x6, #0x4
    bc30:      	asr	x16, x4, #63
    bc34:      	lsr	x16, x16, #62
    bc38:      	add	x4, x4, x16
    bc3c:      	asr	x4, x4, #2
    bc40:      	add	x3, x4, x3
    bc44:      	ldr	x4, [x0, #0x8]
    bc48:      	cmp	x3, x4
    bc4c:      	b.ge	0xbc8c <_stogir.uses.scan!__constfalse+0x174>
    bc50:      	orr	w4, w3, wzr
    bc54:      	ldr	x5, [x0]
    bc58:      	add	x5, x5, x3, lsl #4
    bc5c:      	ldr	x5, [x5]
    bc60:      	ldr	x6, [x0, #0x78]
    bc64:      	uxtb	w5, w5
    bc68:      	add	x6, x6, x3, lsl #2
    bc6c:      	adrp	x16, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000bc6c:  ARM64_RELOC_PAGE21	l_stogir.495
    bc70:      	ldr	x16, [x16]
		000000000000bc70:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    bc74:      	add	x5, x16, x5, lsl #2
    bc78:      	ldr	w6, [x6]
    bc7c:      	sxtw	x6, w6
    bc80:      	ldr	w5, [x5]
    bc84:      	mov	x7, #0x1                ; =1
    bc88:      	b	0xbc04 <_stogir.uses.scan!__constfalse+0xec>
    bc8c:      	add	sp, sp, #0x10
    bc90:      	ret

000000000000bc94 <_stogir.opcode.properties>:
    bc94:      	sxtw	x0, w0
    bc98:      	cmp	x0, #0x0
    bc9c:      	b.lt	0xbcbc <_stogir.opcode.properties+0x28>
    bca0:      	cmp	x0, #0x83
    bca4:      	b.ge	0xbcbc <_stogir.opcode.properties+0x28>
    bca8:      	adrp	x16, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000bca8:  ARM64_RELOC_PAGE21	l_stogir.496
    bcac:      	ldr	x16, [x16]
		000000000000bcac:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    bcb0:      	add	x0, x16, x0
    bcb4:      	ldrb	w0, [x0]
    bcb8:      	b	0xbcc0 <_stogir.opcode.properties+0x2c>
    bcbc:      	movz	x0, #0x0, lsl #48
    bcc0:      	ret

000000000000bcc4 <_stogir.graph.lookup>:
    bcc4:      	sxtw	x1, w1
    bcc8:      	add	x2, x0, #0x28
    bccc:      	cmp	x1, #0x0
    bcd0:      	cset	w3, gt
    bcd4:      	movz	x16, #0x0, lsl #48
    bcd8:      	sub	x4, x16, x1
    bcdc:      	sub	x5, x4, #0x1
    bce0:      	uxtb	w16, w3
    bce4:      	cmp	w16, wzr
    bce8:      	b.eq	0xbd28 <_stogir.graph.lookup+0x64>
    bcec:      	ldr	x2, [x0, #0x8]
    bcf0:      	cmp	x1, x2
    bcf4:      	b.ge	0xbd74 <_stogir.graph.lookup+0xb0>
    bcf8:      	add	x2, x0, #0x78
    bcfc:      	ldr	x2, [x2, #0x8]
    bd00:      	cmp	x1, x2
    bd04:      	b.ge	0xbdec <_stogir.graph.lookup+0x128>
    bd08:      	ldr	x2, [x0, #0x78]
    bd0c:      	add	x2, x2, x1, lsl #2
    bd10:      	ldr	w2, [x2]
    bd14:      	sxtw	x2, w2
    bd18:      	cmp	x2, #0x0
    bd1c:      	cset	w2, ge
    bd20:      	ubfx	x2, x2, #0, #8
    bd24:      	b	0xbdf0 <_stogir.graph.lookup+0x12c>
    bd28:      	cmp	x1, #0x0
    bd2c:      	b.ge	0xbd7c <_stogir.graph.lookup+0xb8>
    bd30:      	add	x6, x0, #0x50
    bd34:      	ldr	x2, [x2, #0x8]
    bd38:      	ldr	x6, [x6, #0x8]
    bd3c:      	cmp	x2, x6
    bd40:      	b.ne	0xbd6c <_stogir.graph.lookup+0xa8>
    bd44:      	cmp	x4, x2
    bd48:      	b.gt	0xbdf4 <_stogir.graph.lookup+0x130>
    bd4c:      	ldr	x2, [x0, #0x50]
    bd50:      	add	x2, x2, x5, lsl #2
    bd54:      	ldr	w2, [x2]
    bd58:      	sxtw	x2, w2
    bd5c:      	cmp	x2, #0x0
    bd60:      	cset	w2, gt
    bd64:      	ubfx	x2, x2, #0, #8
    bd68:      	b	0xbdf8 <_stogir.graph.lookup+0x134>
    bd6c:      	movz	x2, #0x0, lsl #48
    bd70:      	b	0xbd80 <_stogir.graph.lookup+0xbc>
    bd74:      	movz	x2, #0x0, lsl #48
    bd78:      	b	0xbd80 <_stogir.graph.lookup+0xbc>
    bd7c:      	movz	x2, #0x0, lsl #48
    bd80:      	cmp	x2, #0x0
    bd84:      	b.eq	0xbdc0 <_stogir.graph.lookup+0xfc>
    bd88:      	uxtb	w16, w3
    bd8c:      	cmp	w16, wzr
    bd90:      	b.eq	0xbda8 <_stogir.graph.lookup+0xe4>
    bd94:      	ldr	x0, [x0]
    bd98:      	add	x0, x0, x1, lsl #4
    bd9c:      	ldr	x1, [x0]
    bda0:      	ldr	x0, [x0, #0x8]
    bda4:      	b	0xbdb8 <_stogir.graph.lookup+0xf4>
    bda8:      	ldr	x0, [x0, #0x28]
    bdac:      	add	x0, x0, x5, lsl #4
    bdb0:      	ldr	x1, [x0]
    bdb4:      	ldr	x0, [x0, #0x8]
    bdb8:      	mov	x2, #0x1                ; =1
    bdbc:      	b	0xbdcc <_stogir.graph.lookup+0x108>
    bdc0:      	movz	x2, #0x0, lsl #48
    bdc4:      	movz	x1, #0x0, lsl #48
    bdc8:      	movz	x0, #0x0, lsl #48
    bdcc:      	str	x2, [x8]
    bdd0:      	str	x1, [x8, #0x8]
    bdd4:      	str	x0, [x8, #0x10]
    bdd8:      	movz	x17, #0x0, lsl #48
    bddc:      	str	x17, [x8, #0x18]
    bde0:      	movz	x17, #0x0, lsl #48
    bde4:      	str	x17, [x8, #0x20]
    bde8:      	ret
    bdec:      	movz	x2, #0x0, lsl #48
    bdf0:      	b	0xbd78 <_stogir.graph.lookup+0xb4>
    bdf4:      	movz	x2, #0x0, lsl #48
    bdf8:      	b	0xbd70 <_stogir.graph.lookup+0xac>
    bdfc:      	udf	#0x0

000000000000be00 <_stogir.dominators.dominates?>:
    be00:      	sxtw	x1, w1
    be04:      	sxtw	x2, w2
    be08:      	movz	x3, #0x0, lsl #48
    be0c:      	movz	x4, #0x0, lsl #48
    be10:      	b	0xbe24 <_stogir.dominators.dominates?+0x24>
    be14:      	mov	x2, x5
    be18:      	b	0xbe24 <_stogir.dominators.dominates?+0x24>
    be1c:      	nop
    be20:      	mov	x3, #0x1                ; =1
    be24:      	cmp	x3, #0x0
    be28:      	b.ne	0xbe74 <_stogir.dominators.dominates?+0x74>
    be2c:      	cmp	x2, #0x0
    be30:      	b.le	0xbe20 <_stogir.dominators.dominates?+0x20>
    be34:      	ldr	x5, [x0, #0x8]
    be38:      	cmp	x2, x5
    be3c:      	b.ge	0xbe20 <_stogir.dominators.dominates?+0x20>
    be40:      	ldr	x5, [x0]
    be44:      	add	x5, x5, x2, lsl #2
    be48:      	ldr	w5, [x5]
    be4c:      	sxtw	x5, w5
    be50:      	cmp	x5, #0x0
    be54:      	b.ne	0xbe60 <_stogir.dominators.dominates?+0x60>
    be58:      	mov	x3, #0x1                ; =1
    be5c:      	b	0xbe18 <_stogir.dominators.dominates?+0x18>
    be60:      	cmp	x2, x1
    be64:      	b.ne	0xbe7c <_stogir.dominators.dominates?+0x7c>
    be68:      	mov	x3, #0x1                ; =1
    be6c:      	mov	x4, #0x1                ; =1
    be70:      	b	0xbe18 <_stogir.dominators.dominates?+0x18>
    be74:      	mov	x0, x4
    be78:      	ret
    be7c:      	cmp	x2, x5
    be80:      	b.ne	0xbe14 <_stogir.dominators.dominates?+0x14>
    be84:      	mov	x3, #0x1                ; =1
    be88:      	b	0xbe18 <_stogir.dominators.dominates?+0x18>

000000000000be8c <_stogir.placement.use-block>:
    be8c:      	sub	sp, sp, #0x50
    be90:      	str	x29, [sp, #0x10]
    be94:      	str	x30, [sp, #0x18]
    be98:      	add	x29, sp, #0x10
    be9c:      	str	x19, [sp, #0x30]
    bea0:      	str	x20, [sp, #0x38]
    bea4:      	str	x21, [sp, #0x40]
    bea8:      	str	x22, [sp, #0x48]
    beac:      	sxtw	x2, w2
    beb0:      	add	x19, x0, #0x78
    beb4:      	add	x4, x0, #0x28
    beb8:      	lsl	x5, x2, #2
    bebc:      	cmp	x2, #0x0
    bec0:      	cset	w6, gt
    bec4:      	movz	x16, #0x0, lsl #48
    bec8:      	sub	x7, x16, x2
    becc:      	sub	x9, x7, #0x1
    bed0:      	uxtb	w16, w6
    bed4:      	cmp	w16, wzr
    bed8:      	b.eq	0xbf14 <_stogir.placement.use-block+0x88>
    bedc:      	ldr	x4, [x0, #0x8]
    bee0:      	cmp	x2, x4
    bee4:      	b.ge	0xbf60 <_stogir.placement.use-block+0xd4>
    bee8:      	ldr	x4, [x19, #0x8]
    beec:      	cmp	x2, x4
    bef0:      	b.ge	0xc040 <_stogir.placement.use-block+0x1b4>
    bef4:      	ldr	x4, [x0, #0x78]
    bef8:      	add	x4, x5, x4
    befc:      	ldr	w4, [x4]
    bf00:      	sxtw	x4, w4
    bf04:      	cmp	x4, #0x0
    bf08:      	cset	w4, ge
    bf0c:      	ubfx	x4, x4, #0, #8
    bf10:      	b	0xc044 <_stogir.placement.use-block+0x1b8>
    bf14:      	cmp	x2, #0x0
    bf18:      	b.ge	0xbf68 <_stogir.placement.use-block+0xdc>
    bf1c:      	add	x10, x0, #0x50
    bf20:      	ldr	x4, [x4, #0x8]
    bf24:      	ldr	x10, [x10, #0x8]
    bf28:      	cmp	x4, x10
    bf2c:      	b.ne	0xbf58 <_stogir.placement.use-block+0xcc>
    bf30:      	cmp	x7, x4
    bf34:      	b.gt	0xc05c <_stogir.placement.use-block+0x1d0>
    bf38:      	ldr	x4, [x0, #0x50]
    bf3c:      	add	x4, x4, x9, lsl #2
    bf40:      	ldr	w4, [x4]
    bf44:      	sxtw	x4, w4
    bf48:      	cmp	x4, #0x0
    bf4c:      	cset	w4, gt
    bf50:      	ubfx	x4, x4, #0, #8
    bf54:      	b	0xc060 <_stogir.placement.use-block+0x1d4>
    bf58:      	movz	x4, #0x0, lsl #48
    bf5c:      	b	0xbf6c <_stogir.placement.use-block+0xe0>
    bf60:      	movz	x4, #0x0, lsl #48
    bf64:      	b	0xbf6c <_stogir.placement.use-block+0xe0>
    bf68:      	movz	x4, #0x0, lsl #48
    bf6c:      	lsl	x7, x2, #4
    bf70:      	cmp	x4, #0x0
    bf74:      	b.eq	0xbfa8 <_stogir.placement.use-block+0x11c>
    bf78:      	uxtb	w16, w6
    bf7c:      	cmp	w16, wzr
    bf80:      	b.eq	0xbf94 <_stogir.placement.use-block+0x108>
    bf84:      	ldr	x4, [x0]
    bf88:      	add	x4, x7, x4
    bf8c:      	ldr	x4, [x4]
    bf90:      	b	0xbfa0 <_stogir.placement.use-block+0x114>
    bf94:      	ldr	x4, [x0, #0x28]
    bf98:      	add	x4, x4, x9, lsl #4
    bf9c:      	ldr	x4, [x4]
    bfa0:      	mov	w6, #0x1                ; =1
    bfa4:      	b	0xbfb0 <_stogir.placement.use-block+0x124>
    bfa8:      	movz	w6, #0x0, lsl #16
    bfac:      	movz	x4, #0x0, lsl #48
    bfb0:      	ubfx	x6, x6, #0, #32
    bfb4:      	lsr	x16, x6, #0
    bfb8:      	cmp	x16, #0x1
    bfbc:      	b.eq	0xbfd8 <_stogir.placement.use-block+0x14c>
    bfc0:      	b.lo	0xbfc8 <_stogir.placement.use-block+0x13c>
    bfc4:      	b	0xbfdc <_stogir.placement.use-block+0x150>
    bfc8:      	cmp	x16, #0x0
    bfcc:      	b.eq	0xbfd4 <_stogir.placement.use-block+0x148>
    bfd0:      	b	0xbfdc <_stogir.placement.use-block+0x150>
    bfd4:      	b	0xbfe0 <_stogir.placement.use-block+0x154>
    bfd8:      	b	0xc020 <_stogir.placement.use-block+0x194>
    bfdc:      	b	0xc100 <_stogir.placement.use-block+0x274>
    bfe0:      	mov	x20, x8
    bfe4:      	mov	x1, #0x1                ; =1
    bfe8:      	adrp	x0, 0xb000 <_inherent$coil.arraylist.ArrayList$extend-zeroed!__bool+0x7c>
		000000000000bfe8:  ARM64_RELOC_PAGE21	l_stogir.497
    bfec:      	ldr	x0, [x0]
		000000000000bfec:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    bff0:      	mov	x2, #0x21               ; =33
    bff4:      	str	x1, [x20]
    bff8:      	str	x0, [x20, #0x8]
    bffc:      	str	x2, [x20, #0x10]
    c000:      	ldr	x19, [sp, #0x30]
    c004:      	ldr	x20, [sp, #0x38]
    c008:      	ldr	x21, [sp, #0x40]
    c00c:      	ldr	x22, [sp, #0x48]
    c010:      	ldr	x29, [sp, #0x10]
    c014:      	ldr	x30, [sp, #0x18]
    c018:      	add	sp, sp, #0x50
    c01c:      	ret
    c020:      	cmp	x2, #0x0
    c024:      	b.gt	0xc048 <_stogir.placement.use-block+0x1bc>
    c028:      	mov	x20, x8
    c02c:      	mov	x1, #0x1                ; =1
    c030:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c030:  ARM64_RELOC_PAGE21	l_stogir.498
    c034:      	ldr	x0, [x0]
		000000000000c034:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    c038:      	mov	x2, #0x13               ; =19
    c03c:      	b	0xbff4 <_stogir.placement.use-block+0x168>
    c040:      	movz	x4, #0x0, lsl #48
    c044:      	b	0xbf64 <_stogir.placement.use-block+0xd8>
    c048:      	sxtw	x6, w3
    c04c:      	cmp	x6, #0x1
    c050:      	b.ge	0xc064 <_stogir.placement.use-block+0x1d8>
    c054:      	mov	x20, x8
    c058:      	b	0xc02c <_stogir.placement.use-block+0x1a0>
    c05c:      	movz	x4, #0x0, lsl #48
    c060:      	b	0xbf5c <_stogir.placement.use-block+0xd0>
    c064:      	ldr	x9, [x0, #0x78]
    c068:      	add	x10, x5, x9
    c06c:      	ldr	w10, [x10]
    c070:      	sxtw	x10, w10
    c074:      	cmp	x6, x10
    c078:      	b.gt	0xc2c8 <_stogir.placement.use-block+0x43c>
    c07c:      	uxtb	w4, w4
    c080:      	cmp	x4, #0x43
    c084:      	b.ne	0xc2d0 <_stogir.placement.use-block+0x444>
    c088:      	cmp	x6, #0x2
    c08c:      	b.lt	0xc2dc <_stogir.placement.use-block+0x450>
    c090:      	ldr	x4, [x0, #0x8]
    c094:      	cmp	x2, x4
    c098:      	b.ge	0xc164 <_stogir.placement.use-block+0x2d8>
    c09c:      	ldr	x4, [x19, #0x8]
    c0a0:      	cmp	x2, x4
    c0a4:      	b.ge	0xc1a4 <_stogir.placement.use-block+0x318>
    c0a8:      	add	x2, x5, x9
    c0ac:      	ldr	w2, [x2]
    c0b0:      	sxtw	x2, w2
    c0b4:      	cmp	x2, #0x0
    c0b8:      	cset	w2, ge
    c0bc:      	ubfx	x2, x2, #0, #8
    c0c0:      	b	0xc1a8 <_stogir.placement.use-block+0x31c>
    c0c4:      	and	x0, x0, #0xffffffff
    c0c8:      	movz	x1, #0x0, lsl #48
    c0cc:      	movz	x2, #0x0, lsl #48
    c0d0:      	b	0xc03c <_stogir.placement.use-block+0x1b0>
    c0d4:      	ldr	x0, [x22]
    c0d8:      	add	x0, x0, x2, lsl #2
    c0dc:      	ldr	w0, [x0]
    c0e0:      	sxtw	x0, w0
    c0e4:      	cmp	x0, #0x0
    c0e8:      	b.ne	0xc0c4 <_stogir.placement.use-block+0x238>
    c0ec:      	mov	x1, #0x1                ; =1
    c0f0:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c0f0:  ARM64_RELOC_PAGE21	l_stogir.499
    c0f4:      	ldr	x0, [x0]
		000000000000c0f4:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    c0f8:      	mov	x2, #0xf                ; =15
    c0fc:      	b	0xc0d0 <_stogir.placement.use-block+0x244>
    c100:      	brk	#0
    c104:      	b	0xc100 <_stogir.placement.use-block+0x274>
    c108:      	movz	w4, #0x0, lsl #16
    c10c:      	movz	w2, #0x0, lsl #16
    c110:      	ubfx	x4, x4, #0, #32
    c114:      	lsr	x16, x4, #0
    c118:      	cmp	x16, #0x1
    c11c:      	b.eq	0xc138 <_stogir.placement.use-block+0x2ac>
    c120:      	b.lo	0xc128 <_stogir.placement.use-block+0x29c>
    c124:      	b	0xc13c <_stogir.placement.use-block+0x2b0>
    c128:      	cmp	x16, #0x0
    c12c:      	b.eq	0xc134 <_stogir.placement.use-block+0x2a8>
    c130:      	b	0xc13c <_stogir.placement.use-block+0x2b0>
    c134:      	b	0xc140 <_stogir.placement.use-block+0x2b4>
    c138:      	b	0xc1ac <_stogir.placement.use-block+0x320>
    c13c:      	b	0xc2b8 <_stogir.placement.use-block+0x42c>
    c140:      	mov	x20, x8
    c144:      	mov	x1, #0x1                ; =1
    c148:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c148:  ARM64_RELOC_PAGE21	l_stogir.500
    c14c:      	ldr	x0, [x0]
		000000000000c14c:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c150:      	mov	x2, #0x12               ; =18
    c154:      	b	0xc0d0 <_stogir.placement.use-block+0x244>
    c158:      	movz	w4, #0x0, lsl #16
    c15c:      	movz	w2, #0x0, lsl #16
    c160:      	b	0xc110 <_stogir.placement.use-block+0x284>
    c164:      	movz	x2, #0x0, lsl #48
    c168:      	cmp	x2, #0x0
    c16c:      	b.eq	0xc108 <_stogir.placement.use-block+0x27c>
    c170:      	ldr	x2, [x0, #0x78]
    c174:      	add	x2, x5, x2
    c178:      	ldr	w2, [x2]
    c17c:      	sxtw	x2, w2
    c180:      	cmp	x2, #0x1
    c184:      	b.lt	0xc158 <_stogir.placement.use-block+0x2cc>
    c188:      	ldr	x2, [x0]
    c18c:      	add	x2, x7, x2
    c190:      	ldr	w2, [x2, #0x4]
    c194:      	movn	w17, #0x0, lsl #16
    c198:      	and	w2, w2, w17
    c19c:      	mov	w4, #0x1                ; =1
    c1a0:      	b	0xc160 <_stogir.placement.use-block+0x2d4>
    c1a4:      	movz	x2, #0x0, lsl #48
    c1a8:      	b	0xc168 <_stogir.placement.use-block+0x2dc>
    c1ac:      	sub	w3, w3, #0x1
    c1b0:      	mov	x20, x8
    c1b4:      	mov	x21, x0
    c1b8:      	mov	x22, x1
    c1bc:      	mov	w1, w2
    c1c0:      	mov	w2, w3
    c1c4:      	bl	0xc1c4 <_stogir.placement.use-block+0x338>
		000000000000c1c4:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    c1c8:      	ubfx	x0, x0, #0, #32
    c1cc:      	lsr	x16, x0, #0
    c1d0:      	cmp	x16, #0x1
    c1d4:      	b.eq	0xc1f0 <_stogir.placement.use-block+0x364>
    c1d8:      	b.lo	0xc1e0 <_stogir.placement.use-block+0x354>
    c1dc:      	b	0xc1f4 <_stogir.placement.use-block+0x368>
    c1e0:      	cmp	x16, #0x0
    c1e4:      	b.eq	0xc1ec <_stogir.placement.use-block+0x360>
    c1e8:      	b	0xc1f4 <_stogir.placement.use-block+0x368>
    c1ec:      	b	0xc1f8 <_stogir.placement.use-block+0x36c>
    c1f0:      	b	0xc220 <_stogir.placement.use-block+0x394>
    c1f4:      	b	0xc2c0 <_stogir.placement.use-block+0x434>
    c1f8:      	mov	x1, #0x1                ; =1
    c1fc:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c1fc:  ARM64_RELOC_PAGE21	l_stogir.501
    c200:      	ldr	x0, [x0]
		000000000000c200:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    c204:      	mov	x2, #0x17               ; =23
    c208:      	b	0xc21c <_stogir.placement.use-block+0x390>
    c20c:      	mov	x1, #0x1                ; =1
    c210:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c210:  ARM64_RELOC_PAGE21	l_stogir.502
    c214:      	ldr	x0, [x0]
		000000000000c214:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    c218:      	mov	x2, #0x25               ; =37
    c21c:      	b	0xc154 <_stogir.placement.use-block+0x2c8>
    c220:      	sxtw	x1, w1
    c224:      	cmp	x1, #0x0
    c228:      	b.le	0xc20c <_stogir.placement.use-block+0x380>
    c22c:      	lsl	x0, x1, #2
    c230:      	ldr	x2, [x21, #0x8]
    c234:      	cmp	x1, x2
    c238:      	b.ge	0xc280 <_stogir.placement.use-block+0x3f4>
    c23c:      	ldr	x2, [x19, #0x8]
    c240:      	cmp	x1, x2
    c244:      	b.ge	0xc278 <_stogir.placement.use-block+0x3ec>
    c248:      	ldr	x1, [x21, #0x78]
    c24c:      	add	x1, x0, x1
    c250:      	ldr	w1, [x1]
    c254:      	sxtw	x1, w1
    c258:      	cmp	x1, #0x0
    c25c:      	cset	w1, ge
    c260:      	ubfx	x1, x1, #0, #8
    c264:      	b	0xc27c <_stogir.placement.use-block+0x3f0>
    c268:      	and	x0, x0, #0xffffffff
    c26c:      	movz	x1, #0x0, lsl #48
    c270:      	movz	x2, #0x0, lsl #48
    c274:      	b	0xc21c <_stogir.placement.use-block+0x390>
    c278:      	movz	x1, #0x0, lsl #48
    c27c:      	b	0xc284 <_stogir.placement.use-block+0x3f8>
    c280:      	movz	x1, #0x0, lsl #48
    c284:      	cmp	x1, #0x0
    c288:      	b.eq	0xc20c <_stogir.placement.use-block+0x380>
    c28c:      	ldr	x1, [x22]
    c290:      	add	x0, x0, x1
    c294:      	ldr	w0, [x0]
    c298:      	sxtw	x0, w0
    c29c:      	cmp	x0, #0x0
    c2a0:      	b.ne	0xc268 <_stogir.placement.use-block+0x3dc>
    c2a4:      	mov	x1, #0x1                ; =1
    c2a8:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c2a8:  ARM64_RELOC_PAGE21	l_stogir.503
    c2ac:      	ldr	x0, [x0]
		000000000000c2ac:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    c2b0:      	mov	x2, #0x1a               ; =26
    c2b4:      	b	0xc274 <_stogir.placement.use-block+0x3e8>
    c2b8:      	brk	#0
    c2bc:      	b	0xc2b8 <_stogir.placement.use-block+0x42c>
    c2c0:      	brk	#0
    c2c4:      	b	0xc2c0 <_stogir.placement.use-block+0x434>
    c2c8:      	mov	x20, x8
    c2cc:      	b	0xc02c <_stogir.placement.use-block+0x1a0>
    c2d0:      	mov	x20, x8
    c2d4:      	mov	x22, x1
    c2d8:      	b	0xc0d4 <_stogir.placement.use-block+0x248>
    c2dc:      	mov	x20, x8
    c2e0:      	mov	x22, x1
    c2e4:      	b	0xc0d4 <_stogir.placement.use-block+0x248>

000000000000c2e8 <_stogir.placement.choose-block>:
    c2e8:      	sxtw	x2, w2
    c2ec:      	sxtw	x4, w3
    c2f0:      	mov	x6, x4
    c2f4:      	movz	x5, #0x0, lsl #48
    c2f8:      	movz	x7, #0x0, lsl #48
    c2fc:      	b	0xc30c <_stogir.placement.choose-block+0x24>
    c300:      	mov	x6, x9
    c304:      	b	0xc30c <_stogir.placement.choose-block+0x24>
    c308:      	mov	x5, #0x1                ; =1
    c30c:      	cmp	x5, #0x0
    c310:      	b.ne	0xc35c <_stogir.placement.choose-block+0x74>
    c314:      	cmp	x6, #0x0
    c318:      	b.le	0xc308 <_stogir.placement.choose-block+0x20>
    c31c:      	ldr	x9, [x0, #0x8]
    c320:      	cmp	x6, x9
    c324:      	b.ge	0xc308 <_stogir.placement.choose-block+0x20>
    c328:      	ldr	x9, [x0]
    c32c:      	add	x9, x9, x6, lsl #2
    c330:      	ldr	w9, [x9]
    c334:      	sxtw	x9, w9
    c338:      	cmp	x9, #0x0
    c33c:      	b.ne	0xc348 <_stogir.placement.choose-block+0x60>
    c340:      	mov	x5, #0x1                ; =1
    c344:      	b	0xc304 <_stogir.placement.choose-block+0x1c>
    c348:      	cmp	x6, x2
    c34c:      	b.ne	0xc368 <_stogir.placement.choose-block+0x80>
    c350:      	mov	x5, #0x1                ; =1
    c354:      	mov	x7, #0x1                ; =1
    c358:      	b	0xc304 <_stogir.placement.choose-block+0x1c>
    c35c:      	cmp	x7, #0x0
    c360:      	b.eq	0xc3d4 <_stogir.placement.choose-block+0xec>
    c364:      	b	0xc37c <_stogir.placement.choose-block+0x94>
    c368:      	cmp	x6, x9
    c36c:      	b.ne	0xc300 <_stogir.placement.choose-block+0x18>
    c370:      	mov	x5, #0x1                ; =1
    c374:      	b	0xc304 <_stogir.placement.choose-block+0x1c>
    c378:      	mov	x4, x5
    c37c:      	sxtw	x3, w3
    c380:      	cmp	x3, x2
    c384:      	b.eq	0xc3c4 <_stogir.placement.choose-block+0xdc>
    c388:      	ldr	x5, [x0]
    c38c:      	add	x3, x5, x3, lsl #2
    c390:      	ldr	w3, [x3]
    c394:      	sxtw	x5, w3
    c398:      	ldr	x6, [x1]
    c39c:      	orr	x7, x6, xzr
    c3a0:      	add	x7, x7, x5, lsl #2
    c3a4:      	add	x6, x6, x4, lsl #2
    c3a8:      	ldr	w7, [x7]
    c3ac:      	sxtw	x7, w7
    c3b0:      	ldr	w6, [x6]
    c3b4:      	sxtw	x6, w6
    c3b8:      	cmp	x7, x6
    c3bc:      	b.lt	0xc378 <_stogir.placement.choose-block+0x90>
    c3c0:      	b	0xc37c <_stogir.placement.choose-block+0x94>
    c3c4:      	and	x0, x4, #0xffffffff
    c3c8:      	movz	x1, #0x0, lsl #48
    c3cc:      	movz	x2, #0x0, lsl #48
    c3d0:      	b	0xc3e4 <_stogir.placement.choose-block+0xfc>
    c3d4:      	mov	x1, #0x1                ; =1
    c3d8:      	adrp	x0, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c3d8:  ARM64_RELOC_PAGE21	l_stogir.504
    c3dc:      	ldr	x0, [x0]
		000000000000c3dc:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    c3e0:      	mov	x2, #0x29               ; =41
    c3e4:      	str	x1, [x8]
    c3e8:      	str	x0, [x8, #0x8]
    c3ec:      	str	x2, [x8, #0x10]
    c3f0:      	ret

000000000000c3f4 <_stogir.checked.validate-projection>:
    c3f4:      	sub	sp, sp, #0x40
    c3f8:      	str	x29, [sp]
    c3fc:      	str	x30, [sp, #0x8]
    c400:      	mov	x29, sp
    c404:      	str	x19, [sp, #0x30]
    c408:      	sxtw	x1, w1
    c40c:      	add	x2, x0, #0x78
    c410:      	add	x3, x0, #0x28
    c414:      	lsl	x4, x1, #2
    c418:      	cmp	x1, #0x0
    c41c:      	cset	w5, gt
    c420:      	movz	x16, #0x0, lsl #48
    c424:      	sub	x6, x16, x1
    c428:      	sub	x7, x6, #0x1
    c42c:      	uxtb	w16, w5
    c430:      	cmp	w16, wzr
    c434:      	b.eq	0xc470 <_stogir.checked.validate-projection+0x7c>
    c438:      	ldr	x3, [x0, #0x8]
    c43c:      	cmp	x1, x3
    c440:      	b.ge	0xc4bc <_stogir.checked.validate-projection+0xc8>
    c444:      	ldr	x2, [x2, #0x8]
    c448:      	cmp	x1, x2
    c44c:      	b.ge	0xc58c <_stogir.checked.validate-projection+0x198>
    c450:      	ldr	x2, [x0, #0x78]
    c454:      	add	x2, x4, x2
    c458:      	ldr	w2, [x2]
    c45c:      	sxtw	x2, w2
    c460:      	cmp	x2, #0x0
    c464:      	cset	w2, ge
    c468:      	ubfx	x2, x2, #0, #8
    c46c:      	b	0xc590 <_stogir.checked.validate-projection+0x19c>
    c470:      	cmp	x1, #0x0
    c474:      	b.ge	0xc4c4 <_stogir.checked.validate-projection+0xd0>
    c478:      	add	x2, x0, #0x50
    c47c:      	ldr	x3, [x3, #0x8]
    c480:      	ldr	x2, [x2, #0x8]
    c484:      	cmp	x3, x2
    c488:      	b.ne	0xc4b4 <_stogir.checked.validate-projection+0xc0>
    c48c:      	cmp	x6, x3
    c490:      	b.gt	0xc5f8 <_stogir.checked.validate-projection+0x204>
    c494:      	ldr	x2, [x0, #0x50]
    c498:      	add	x2, x2, x7, lsl #2
    c49c:      	ldr	w2, [x2]
    c4a0:      	sxtw	x2, w2
    c4a4:      	cmp	x2, #0x0
    c4a8:      	cset	w2, gt
    c4ac:      	ubfx	x2, x2, #0, #8
    c4b0:      	b	0xc5fc <_stogir.checked.validate-projection+0x208>
    c4b4:      	movz	x2, #0x0, lsl #48
    c4b8:      	b	0xc4c8 <_stogir.checked.validate-projection+0xd4>
    c4bc:      	movz	x2, #0x0, lsl #48
    c4c0:      	b	0xc4c8 <_stogir.checked.validate-projection+0xd4>
    c4c4:      	movz	x2, #0x0, lsl #48
    c4c8:      	cmp	x2, #0x0
    c4cc:      	b.eq	0xc500 <_stogir.checked.validate-projection+0x10c>
    c4d0:      	uxtb	w16, w5
    c4d4:      	cmp	w16, wzr
    c4d8:      	b.eq	0xc4ec <_stogir.checked.validate-projection+0xf8>
    c4dc:      	ldr	x2, [x0]
    c4e0:      	add	x2, x2, x1, lsl #4
    c4e4:      	ldr	x2, [x2]
    c4e8:      	b	0xc4f8 <_stogir.checked.validate-projection+0x104>
    c4ec:      	ldr	x2, [x0, #0x28]
    c4f0:      	add	x2, x2, x7, lsl #4
    c4f4:      	ldr	x2, [x2]
    c4f8:      	mov	w3, #0x1                ; =1
    c4fc:      	b	0xc508 <_stogir.checked.validate-projection+0x114>
    c500:      	movz	w3, #0x0, lsl #16
    c504:      	movz	x2, #0x0, lsl #48
    c508:      	ubfx	x3, x3, #0, #32
    c50c:      	lsr	x16, x3, #0
    c510:      	cmp	x16, #0x1
    c514:      	b.eq	0xc530 <_stogir.checked.validate-projection+0x13c>
    c518:      	b.lo	0xc520 <_stogir.checked.validate-projection+0x12c>
    c51c:      	b	0xc534 <_stogir.checked.validate-projection+0x140>
    c520:      	cmp	x16, #0x0
    c524:      	b.eq	0xc52c <_stogir.checked.validate-projection+0x138>
    c528:      	b	0xc534 <_stogir.checked.validate-projection+0x140>
    c52c:      	b	0xc538 <_stogir.checked.validate-projection+0x144>
    c530:      	b	0xc550 <_stogir.checked.validate-projection+0x15c>
    c534:      	b	0xc600 <_stogir.checked.validate-projection+0x20c>
    c538:      	mov	x19, x8
    c53c:      	mov	x0, #0x1                ; =1
    c540:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c540:  ARM64_RELOC_PAGE21	l_stogir.505
    c544:      	ldr	x1, [x1]
		000000000000c544:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    c548:      	mov	x2, #0x10               ; =16
    c54c:      	b	0xc56c <_stogir.checked.validate-projection+0x178>
    c550:      	cmp	x1, #0x0
    c554:      	b.gt	0xc594 <_stogir.checked.validate-projection+0x1a0>
    c558:      	mov	x19, x8
    c55c:      	mov	x0, #0x1                ; =1
    c560:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c560:  ARM64_RELOC_PAGE21	l_stogir.506
    c564:      	ldr	x1, [x1]
		000000000000c564:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    c568:      	mov	x2, #0x1c               ; =28
    c56c:      	str	x0, [x19]
    c570:      	str	x1, [x19, #0x8]
    c574:      	str	x2, [x19, #0x10]
    c578:      	ldr	x19, [sp, #0x30]
    c57c:      	ldr	x29, [sp]
    c580:      	ldr	x30, [sp, #0x8]
    c584:      	add	sp, sp, #0x40
    c588:      	ret
    c58c:      	movz	x2, #0x0, lsl #48
    c590:      	b	0xc4c0 <_stogir.checked.validate-projection+0xcc>
    c594:      	uxtb	w1, w2
    c598:      	cmp	x1, #0x2c
    c59c:      	b.ne	0xc608 <_stogir.checked.validate-projection+0x214>
    c5a0:      	orr	w1, w2, wzr
    c5a4:      	ubfx	x1, x1, #0, #32
    c5a8:      	ubfx	x1, x1, #8, #8
    c5ac:      	cmp	x1, #0x1
    c5b0:      	b.ne	0xc610 <_stogir.checked.validate-projection+0x21c>
    c5b4:      	ldr	x1, [x0, #0x78]
    c5b8:      	add	x1, x4, x1
    c5bc:      	ldr	w1, [x1]
    c5c0:      	sxtw	x1, w1
    c5c4:      	cmp	x1, #0x1
    c5c8:      	b.ne	0xc618 <_stogir.checked.validate-projection+0x224>
    c5cc:      	lsr	x1, x2, #32
    c5d0:      	mov	x19, x8
    c5d4:      	add	x8, sp, #0x10
    c5d8:      	bl	0xc5d8 <_stogir.checked.validate-projection+0x1e4>
		000000000000c5d8:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    c5dc:      	add	x16, sp, #0x10
    c5e0:      	ldr	x0, [x16]
    c5e4:      	add	x16, sp, #0x10
    c5e8:      	ldr	x1, [x16, #0x8]
    c5ec:      	add	x16, sp, #0x10
    c5f0:      	ldr	x2, [x16, #0x10]
    c5f4:      	b	0xc56c <_stogir.checked.validate-projection+0x178>
    c5f8:      	movz	x2, #0x0, lsl #48
    c5fc:      	b	0xc4b8 <_stogir.checked.validate-projection+0xc4>
    c600:      	brk	#0
    c604:      	b	0xc600 <_stogir.checked.validate-projection+0x20c>
    c608:      	mov	x19, x8
    c60c:      	b	0xc55c <_stogir.checked.validate-projection+0x168>
    c610:      	mov	x19, x8
    c614:      	b	0xc55c <_stogir.checked.validate-projection+0x168>
    c618:      	mov	x19, x8
    c61c:      	b	0xc55c <_stogir.checked.validate-projection+0x168>

000000000000c620 <_coil.core.Iterable$coil.arraylist.ArrayList$iter__stogir.cfg.Edge>:
    c620:      	ldr	x1, [x0]
    c624:      	ldr	x0, [x0, #0x8]
    c628:      	str	x1, [x8]
    c62c:      	str	x0, [x8, #0x8]
    c630:      	movz	x17, #0x0, lsl #48
    c634:      	str	x17, [x8, #0x10]
    c638:      	ret

000000000000c63c <_coil.core.Iterable$coil.arraylist.ArrayList$iter__i64>:
    c63c:      	ldr	x1, [x0]
    c640:      	ldr	x0, [x0, #0x8]
    c644:      	str	x1, [x8]
    c648:      	str	x0, [x8, #0x8]
    c64c:      	movz	x17, #0x0, lsl #48
    c650:      	str	x17, [x8, #0x10]
    c654:      	ret

000000000000c658 <_stogir.loops.heapify!>:
    c658:      	ldr	x4, [x1, #0x8]
    c65c:      	asr	x16, x4, #63
    c660:      	lsr	x16, x16, #63
    c664:      	add	x4, x4, x16
    c668:      	asr	x4, x4, #1
    c66c:      	cmp	x4, #0x0
    c670:      	b.le	0xc7f4 <_stogir.loops.heapify!+0x19c>
    c674:      	sub	x4, x4, #0x1
    c678:      	ldr	x5, [x1]
    c67c:      	ldr	x6, [x1, #0x8]
    c680:      	mov	x8, x4
    c684:      	movz	x7, #0x0, lsl #48
    c688:      	b	0xc6cc <_stogir.loops.heapify!+0x74>
    c68c:      	nop
    c690:      	add	x8, x5, x8
    c694:      	add	x10, x5, x9
    c698:      	ldr	x11, [x0]
    c69c:      	orr	x12, x11, xzr
    c6a0:      	orr	x13, x11, xzr
    c6a4:      	add	x12, x12, x8, lsl #3
    c6a8:      	add	x13, x13, x10, lsl #3
    c6ac:      	add	x8, x11, x8, lsl #3
    c6b0:      	ldr	x11, [x12]
    c6b4:      	ldr	x12, [x13]
    c6b8:      	str	x12, [x8]
    c6bc:      	ldr	x8, [x0]
    c6c0:      	add	x8, x8, x10, lsl #3
    c6c4:      	str	x11, [x8]
    c6c8:      	mov	x8, x9
    c6cc:      	cmp	x7, #0x0
    c6d0:      	b.ne	0xc66c <_stogir.loops.heapify!+0x14>
    c6d4:      	lsl	x9, x8, #1
    c6d8:      	add	x9, x9, #0x1
    c6dc:      	cmp	x9, x6
    c6e0:      	b.ge	0xc66c <_stogir.loops.heapify!+0x14>
    c6e4:      	lsl	x9, x8, #1
    c6e8:      	add	x9, x9, #0x1
    c6ec:      	add	x10, x9, #0x1
    c6f0:      	cmp	x10, x6
    c6f4:      	b.ge	0xc774 <_stogir.loops.heapify!+0x11c>
    c6f8:      	add	x10, x9, x5
    c6fc:      	ldr	x11, [x0]
    c700:      	add	x12, x10, #0x1
    c704:      	orr	x13, x11, xzr
    c708:      	add	x10, x11, x10, lsl #3
    c70c:      	add	x11, x13, x12, lsl #3
    c710:      	ldr	x11, [x11]
    c714:      	ldr	x10, [x10]
    c718:      	ldr	x12, [x2, #0x50]
    c71c:      	orr	x13, x12, xzr
    c720:      	add	x13, x13, x11, lsl #4
    c724:      	add	x12, x12, x10, lsl #4
    c728:      	ldr	x13, [x13]
    c72c:      	ldr	x14, [x3]
    c730:      	asr	x13, x13, #32
    c734:      	orr	x15, x14, xzr
    c738:      	add	x13, x15, x13, lsl #2
    c73c:      	ldr	w13, [x13]
    c740:      	sxtw	x13, w13
    c744:      	ldr	x12, [x12]
    c748:      	asr	x12, x12, #32
    c74c:      	add	x12, x14, x12, lsl #2
    c750:      	ldr	w12, [x12]
    c754:      	sxtw	x12, w12
    c758:      	cmp	x13, x12
    c75c:      	b.lt	0xc770 <_stogir.loops.heapify!+0x118>
    c760:      	cmp	x13, x12
    c764:      	b.ne	0xc774 <_stogir.loops.heapify!+0x11c>
    c768:      	cmp	x11, x10
    c76c:      	b.le	0xc774 <_stogir.loops.heapify!+0x11c>
    c770:      	add	x9, x9, #0x1
    c774:      	add	x10, x5, x8
    c778:      	ldr	x11, [x0]
    c77c:      	add	x12, x5, x9
    c780:      	orr	x13, x11, xzr
    c784:      	add	x10, x11, x10, lsl #3
    c788:      	add	x11, x13, x12, lsl #3
    c78c:      	ldr	x11, [x11]
    c790:      	ldr	x10, [x10]
    c794:      	ldr	x12, [x2, #0x50]
    c798:      	orr	x13, x12, xzr
    c79c:      	add	x13, x13, x11, lsl #4
    c7a0:      	add	x12, x12, x10, lsl #4
    c7a4:      	ldr	x13, [x13]
    c7a8:      	ldr	x14, [x3]
    c7ac:      	asr	x13, x13, #32
    c7b0:      	orr	x15, x14, xzr
    c7b4:      	add	x13, x15, x13, lsl #2
    c7b8:      	ldr	w13, [x13]
    c7bc:      	sxtw	x13, w13
    c7c0:      	ldr	x12, [x12]
    c7c4:      	asr	x12, x12, #32
    c7c8:      	add	x12, x14, x12, lsl #2
    c7cc:      	ldr	w12, [x12]
    c7d0:      	sxtw	x12, w12
    c7d4:      	cmp	x13, x12
    c7d8:      	b.lt	0xc690 <_stogir.loops.heapify!+0x38>
    c7dc:      	cmp	x13, x12
    c7e0:      	b.ne	0xc7ec <_stogir.loops.heapify!+0x194>
    c7e4:      	cmp	x11, x10
    c7e8:      	b.gt	0xc690 <_stogir.loops.heapify!+0x38>
    c7ec:      	mov	x7, #0x1                ; =1
    c7f0:      	b	0xc6cc <_stogir.loops.heapify!+0x74>
    c7f4:      	ret

000000000000c7f8 <_stogir.loops.sift!>:
    c7f8:      	movz	x6, #0x0, lsl #48
    c7fc:      	b	0xc83c <_stogir.loops.sift!+0x44>
    c800:      	add	x3, x1, x3
    c804:      	add	x8, x1, x7
    c808:      	ldr	x9, [x0]
    c80c:      	orr	x10, x9, xzr
    c810:      	orr	x11, x9, xzr
    c814:      	add	x10, x10, x3, lsl #3
    c818:      	add	x11, x11, x8, lsl #3
    c81c:      	add	x3, x9, x3, lsl #3
    c820:      	ldr	x9, [x10]
    c824:      	ldr	x10, [x11]
    c828:      	str	x10, [x3]
    c82c:      	ldr	x3, [x0]
    c830:      	add	x3, x3, x8, lsl #3
    c834:      	str	x9, [x3]
    c838:      	mov	x3, x7
    c83c:      	cmp	x6, #0x0
    c840:      	b.ne	0xc964 <_stogir.loops.sift!+0x16c>
    c844:      	lsl	x7, x3, #1
    c848:      	add	x7, x7, #0x1
    c84c:      	cmp	x7, x2
    c850:      	b.ge	0xc964 <_stogir.loops.sift!+0x16c>
    c854:      	lsl	x7, x3, #1
    c858:      	add	x7, x7, #0x1
    c85c:      	add	x8, x7, #0x1
    c860:      	cmp	x8, x2
    c864:      	b.ge	0xc8e4 <_stogir.loops.sift!+0xec>
    c868:      	add	x8, x7, x1
    c86c:      	ldr	x9, [x0]
    c870:      	add	x10, x8, #0x1
    c874:      	orr	x11, x9, xzr
    c878:      	add	x8, x9, x8, lsl #3
    c87c:      	add	x9, x11, x10, lsl #3
    c880:      	ldr	x9, [x9]
    c884:      	ldr	x8, [x8]
    c888:      	ldr	x10, [x4, #0x50]
    c88c:      	orr	x11, x10, xzr
    c890:      	add	x11, x11, x9, lsl #4
    c894:      	add	x10, x10, x8, lsl #4
    c898:      	ldr	x11, [x11]
    c89c:      	ldr	x12, [x5]
    c8a0:      	asr	x11, x11, #32
    c8a4:      	orr	x13, x12, xzr
    c8a8:      	add	x11, x13, x11, lsl #2
    c8ac:      	ldr	w11, [x11]
    c8b0:      	sxtw	x11, w11
    c8b4:      	ldr	x10, [x10]
    c8b8:      	asr	x10, x10, #32
    c8bc:      	add	x10, x12, x10, lsl #2
    c8c0:      	ldr	w10, [x10]
    c8c4:      	sxtw	x10, w10
    c8c8:      	cmp	x11, x10
    c8cc:      	b.lt	0xc8e0 <_stogir.loops.sift!+0xe8>
    c8d0:      	cmp	x11, x10
    c8d4:      	b.ne	0xc8e4 <_stogir.loops.sift!+0xec>
    c8d8:      	cmp	x9, x8
    c8dc:      	b.le	0xc8e4 <_stogir.loops.sift!+0xec>
    c8e0:      	add	x7, x7, #0x1
    c8e4:      	add	x8, x1, x3
    c8e8:      	ldr	x9, [x0]
    c8ec:      	add	x10, x1, x7
    c8f0:      	orr	x11, x9, xzr
    c8f4:      	add	x8, x9, x8, lsl #3
    c8f8:      	add	x9, x11, x10, lsl #3
    c8fc:      	ldr	x9, [x9]
    c900:      	ldr	x8, [x8]
    c904:      	ldr	x10, [x4, #0x50]
    c908:      	orr	x11, x10, xzr
    c90c:      	add	x11, x11, x9, lsl #4
    c910:      	add	x10, x10, x8, lsl #4
    c914:      	ldr	x11, [x11]
    c918:      	ldr	x12, [x5]
    c91c:      	asr	x11, x11, #32
    c920:      	orr	x13, x12, xzr
    c924:      	add	x11, x13, x11, lsl #2
    c928:      	ldr	w11, [x11]
    c92c:      	sxtw	x11, w11
    c930:      	ldr	x10, [x10]
    c934:      	asr	x10, x10, #32
    c938:      	add	x10, x12, x10, lsl #2
    c93c:      	ldr	w10, [x10]
    c940:      	sxtw	x10, w10
    c944:      	cmp	x11, x10
    c948:      	b.lt	0xc800 <_stogir.loops.sift!+0x8>
    c94c:      	cmp	x11, x10
    c950:      	b.ne	0xc95c <_stogir.loops.sift!+0x164>
    c954:      	cmp	x9, x8
    c958:      	b.gt	0xc800 <_stogir.loops.sift!+0x8>
    c95c:      	mov	x6, #0x1                ; =1
    c960:      	b	0xc83c <_stogir.loops.sift!+0x44>
    c964:      	ret

000000000000c968 <_stogir.opcode.block-end?>:
    c968:      	sxtw	x0, w0
    c96c:      	cmp	x0, #0x0
    c970:      	b.lt	0xc990 <_stogir.opcode.block-end?+0x28>
    c974:      	cmp	x0, #0x83
    c978:      	b.ge	0xc990 <_stogir.opcode.block-end?+0x28>
    c97c:      	adrp	x16, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000c97c:  ARM64_RELOC_PAGE21	l_stogir.507
    c980:      	ldr	x16, [x16]
		000000000000c980:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    c984:      	add	x0, x16, x0
    c988:      	ldrb	w0, [x0]
    c98c:      	b	0xc994 <_stogir.opcode.block-end?+0x2c>
    c990:      	movz	w0, #0x0, lsl #16
    c994:      	uxtb	w16, w0
    c998:      	and	w0, w16, #0x4
    c99c:      	uxtb	w0, w0
    c9a0:      	ubfx	x0, x0, #0, #8
    c9a4:      	cmp	x0, #0x0
    c9a8:      	cset	w0, eq
    c9ac:      	uxtb	w16, w0
    c9b0:      	cmp	w16, wzr
    c9b4:      	cset	x0, eq
    c9b8:      	ret

000000000000c9bc <_stogir.schedule.entry-prefix>:
    c9bc:      	sub	sp, sp, #0x90
    c9c0:      	str	x29, [sp]
    c9c4:      	str	x30, [sp, #0x8]
    c9c8:      	mov	x29, sp
    c9cc:      	str	x19, [sp, #0x40]
    c9d0:      	str	x20, [sp, #0x48]
    c9d4:      	str	x21, [sp, #0x50]
    c9d8:      	str	x22, [sp, #0x58]
    c9dc:      	str	x23, [sp, #0x60]
    c9e0:      	str	x24, [sp, #0x68]
    c9e4:      	str	x25, [sp, #0x70]
    c9e8:      	str	x26, [sp, #0x78]
    c9ec:      	str	x27, [sp, #0x80]
    c9f0:      	ldr	x3, [x2]
    c9f4:      	ldr	x2, [x2, #0x8]
    c9f8:      	add	x16, sp, #0x10
    c9fc:      	movz	x17, #0x0, lsl #48
    ca00:      	str	x17, [x16]
    ca04:      	add	x16, sp, #0x10
    ca08:      	movz	x17, #0x0, lsl #48
    ca0c:      	str	x17, [x16, #0x8]
    ca10:      	add	x16, sp, #0x10
    ca14:      	movz	x17, #0x0, lsl #48
    ca18:      	str	x17, [x16, #0x10]
    ca1c:      	add	x16, sp, #0x10
    ca20:      	str	x3, [x16, #0x18]
    ca24:      	add	x16, sp, #0x10
    ca28:      	str	x2, [x16, #0x20]
    ca2c:      	movz	x19, #0x0, lsl #48
    ca30:      	b	0xcb24 <_stogir.schedule.entry-prefix+0x168>
    ca34:      	lsl	x2, x2, #1
    ca38:      	mov	x25, x8
    ca3c:      	mov	x26, x0
    ca40:      	add	x0, sp, #0x10
    ca44:      	mov	x27, x1
    ca48:      	mov	x1, x2
    ca4c:      	bl	0xca4c <_stogir.schedule.entry-prefix+0x90>
		000000000000ca4c:  ARM64_RELOC_BRANCH26	_inherent$coil.arraylist.ArrayList$reserve!__i32
    ca50:      	add	x0, x24, #0x1
    ca54:      	add	x16, sp, #0x10
    ca58:      	ldr	x1, [x16]
    ca5c:      	add	x1, x1, x24, lsl #2
    ca60:      	str	w23, [x1]
    ca64:      	add	x16, sp, #0x10
    ca68:      	str	x0, [x16, #0x8]
    ca6c:      	mov	x8, x25
    ca70:      	mov	x0, x26
    ca74:      	mov	x1, x27
    ca78:      	cmp	x22, x21
    ca7c:      	b.ge	0xcaa0 <_stogir.schedule.entry-prefix+0xe4>
    ca80:      	add	x2, x22, #0x1
    ca84:      	add	x3, x20, x22, lsl #2
    ca88:      	ldr	w3, [x3]
    ca8c:      	movn	w17, #0x0, lsl #16
    ca90:      	and	w23, w3, w17
    ca94:      	mov	x22, x2
    ca98:      	mov	w2, #0x1                ; =1
    ca9c:      	b	0xcaa8 <_stogir.schedule.entry-prefix+0xec>
    caa0:      	movz	w2, #0x0, lsl #16
    caa4:      	movz	w23, #0x0, lsl #16
    caa8:      	ubfx	x2, x2, #0, #32
    caac:      	lsr	x16, x2, #0
    cab0:      	cmp	x16, #0x1
    cab4:      	b.eq	0xcadc <_stogir.schedule.entry-prefix+0x120>
    cab8:      	b.lo	0xcac0 <_stogir.schedule.entry-prefix+0x104>
    cabc:      	b	0xcae0 <_stogir.schedule.entry-prefix+0x124>
    cac0:      	cmp	x16, #0x0
    cac4:      	b.eq	0xcacc <_stogir.schedule.entry-prefix+0x110>
    cac8:      	b	0xcae0 <_stogir.schedule.entry-prefix+0x124>
    cacc:      	mov	x25, x8
    cad0:      	mov	x26, x0
    cad4:      	mov	x27, x1
    cad8:      	b	0xcb14 <_stogir.schedule.entry-prefix+0x158>
    cadc:      	b	0xcae4 <_stogir.schedule.entry-prefix+0x128>
    cae0:      	b	0xcc3c <_stogir.schedule.entry-prefix+0x280>
    cae4:      	sxtw	x2, w23
    cae8:      	ldr	x3, [x0]
    caec:      	add	x2, x3, x2, lsl #4
    caf0:      	ldr	x2, [x2]
    caf4:      	uxtb	w2, w2
    caf8:      	cmp	x2, #0x83
    cafc:      	b.ge	0xcb44 <_stogir.schedule.entry-prefix+0x188>
    cb00:      	adrp	x17, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000cb00:  ARM64_RELOC_PAGE21	l_stogir.508
    cb04:      	ldr	x17, [x17]
		000000000000cb04:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    cb08:      	add	x3, x2, x17
    cb0c:      	ldrb	w3, [x3]
    cb10:      	b	0xcb48 <_stogir.schedule.entry-prefix+0x18c>
    cb14:      	add	x19, x19, #0x1
    cb18:      	mov	x8, x25
    cb1c:      	mov	x0, x26
    cb20:      	mov	x1, x27
    cb24:      	cmp	x19, #0x3
    cb28:      	b.ge	0xcc44 <_stogir.schedule.entry-prefix+0x288>
    cb2c:      	ldr	x2, [x1]
    cb30:      	ldr	x3, [x1, #0x8]
    cb34:      	orr	x20, x2, xzr
    cb38:      	orr	x21, x3, xzr
    cb3c:      	movz	x22, #0x0, lsl #48
    cb40:      	b	0xca78 <_stogir.schedule.entry-prefix+0xbc>
    cb44:      	movz	w3, #0x0, lsl #16
    cb48:      	uxtb	w16, w3
    cb4c:      	and	w3, w16, #0x2
    cb50:      	uxtb	w3, w3
    cb54:      	ubfx	x3, x3, #0, #8
    cb58:      	cmp	x3, #0x0
    cb5c:      	cset	w3, eq
    cb60:      	uxtb	w16, w3
    cb64:      	cmp	w16, wzr
    cb68:      	cset	x3, eq
    cb6c:      	cmp	x3, #0x0
    cb70:      	b.eq	0xcb7c <_stogir.schedule.entry-prefix+0x1c0>
    cb74:      	movz	x2, #0x0, lsl #48
    cb78:      	b	0xcb98 <_stogir.schedule.entry-prefix+0x1dc>
    cb7c:      	cmp	x2, #0x47
    cb80:      	cset	w2, eq
    cb84:      	uxtb	w16, w2
    cb88:      	cmp	w16, wzr
    cb8c:      	mov	x16, #0x1               ; =1
    cb90:      	mov	x17, #0x2               ; =2
    cb94:      	csel	x2, x16, x17, ne
    cb98:      	cmp	x2, x19
    cb9c:      	b.ne	0xcc4c <_stogir.schedule.entry-prefix+0x290>
    cba0:      	add	x16, sp, #0x10
    cba4:      	ldr	x2, [x16, #0x8]
    cba8:      	orr	x24, x2, xzr
    cbac:      	add	x16, sp, #0x10
    cbb0:      	ldr	x2, [x16, #0x10]
    cbb4:      	cmp	x24, x2
    cbb8:      	b.lt	0xcc5c <_stogir.schedule.entry-prefix+0x2a0>
    cbbc:      	cmp	x2, #0x0
    cbc0:      	b.ne	0xca34 <_stogir.schedule.entry-prefix+0x78>
    cbc4:      	mov	x2, #0x2                ; =2
    cbc8:      	b	0xca38 <_stogir.schedule.entry-prefix+0x7c>
    cbcc:      	add	x16, sp, #0x10
    cbd0:      	ldr	x0, [x16]
    cbd4:      	add	x16, sp, #0x10
    cbd8:      	ldr	x1, [x16, #0x8]
    cbdc:      	add	x16, sp, #0x10
    cbe0:      	ldr	x2, [x16, #0x10]
    cbe4:      	add	x16, sp, #0x10
    cbe8:      	ldr	x3, [x16, #0x18]
    cbec:      	add	x16, sp, #0x10
    cbf0:      	ldr	x4, [x16, #0x20]
    cbf4:      	str	x0, [x25]
    cbf8:      	str	x1, [x25, #0x8]
    cbfc:      	str	x2, [x25, #0x10]
    cc00:      	str	x3, [x25, #0x18]
    cc04:      	str	x4, [x25, #0x20]
    cc08:      	ldr	x19, [sp, #0x40]
    cc0c:      	ldr	x20, [sp, #0x48]
    cc10:      	ldr	x21, [sp, #0x50]
    cc14:      	ldr	x22, [sp, #0x58]
    cc18:      	ldr	x23, [sp, #0x60]
    cc1c:      	ldr	x24, [sp, #0x68]
    cc20:      	ldr	x25, [sp, #0x70]
    cc24:      	ldr	x26, [sp, #0x78]
    cc28:      	ldr	x27, [sp, #0x80]
    cc2c:      	ldr	x29, [sp]
    cc30:      	ldr	x30, [sp, #0x8]
    cc34:      	add	sp, sp, #0x90
    cc38:      	ret
    cc3c:      	brk	#0
    cc40:      	b	0xcc3c <_stogir.schedule.entry-prefix+0x280>
    cc44:      	mov	x25, x8
    cc48:      	b	0xcbcc <_stogir.schedule.entry-prefix+0x210>
    cc4c:      	mov	x25, x8
    cc50:      	mov	x26, x0
    cc54:      	mov	x27, x1
    cc58:      	b	0xca6c <_stogir.schedule.entry-prefix+0xb0>
    cc5c:      	mov	x25, x8
    cc60:      	mov	x26, x0
    cc64:      	mov	x27, x1
    cc68:      	b	0xca50 <_stogir.schedule.entry-prefix+0x94>

000000000000cc6c <_stogir.checked-schedule.validate>:
    cc6c:      	sub	sp, sp, #0x40
    cc70:      	str	x29, [sp]
    cc74:      	str	x30, [sp, #0x8]
    cc78:      	mov	x29, sp
    cc7c:      	str	x19, [sp, #0x30]
    cc80:      	add	x1, x1, #0x28
    cc84:      	mov	x19, x8
    cc88:      	add	x8, sp, #0x10
    cc8c:      	bl	0xcc8c <_stogir.checked-schedule.validate+0x20>
		000000000000cc8c:  ARM64_RELOC_BRANCH26	_stogir.checked-schedule.validate-nodes
    cc90:      	add	x16, sp, #0x10
    cc94:      	ldr	x0, [x16]
    cc98:      	str	x0, [x19]
    cc9c:      	add	x16, sp, #0x10
    cca0:      	ldr	x0, [x16, #0x8]
    cca4:      	str	x0, [x19, #0x8]
    cca8:      	add	x16, sp, #0x10
    ccac:      	ldr	x0, [x16, #0x10]
    ccb0:      	str	x0, [x19, #0x10]
    ccb4:      	ldr	x19, [sp, #0x30]
    ccb8:      	ldr	x29, [sp]
    ccbc:      	ldr	x30, [sp, #0x8]
    ccc0:      	add	sp, sp, #0x40
    ccc4:      	ret

000000000000ccc8 <_stogir.checked.projection>:
    ccc8:      	sub	sp, sp, #0x40
    cccc:      	str	x29, [sp]
    ccd0:      	str	x30, [sp, #0x8]
    ccd4:      	mov	x29, sp
    ccd8:      	str	x19, [sp, #0x30]
    ccdc:      	sxtw	x2, w1
    cce0:      	add	x3, x0, #0x28
    cce4:      	cmp	x2, #0x0
    cce8:      	cset	w4, gt
    ccec:      	movz	x16, #0x0, lsl #48
    ccf0:      	sub	x5, x16, x2
    ccf4:      	sub	x6, x5, #0x1
    ccf8:      	uxtb	w16, w4
    ccfc:      	cmp	w16, wzr
    cd00:      	b.eq	0xcd40 <_stogir.checked.projection+0x78>
    cd04:      	ldr	x3, [x0, #0x8]
    cd08:      	cmp	x2, x3
    cd0c:      	b.ge	0xcd8c <_stogir.checked.projection+0xc4>
    cd10:      	add	x3, x0, #0x78
    cd14:      	ldr	x3, [x3, #0x8]
    cd18:      	cmp	x2, x3
    cd1c:      	b.ge	0xce8c <_stogir.checked.projection+0x1c4>
    cd20:      	ldr	x3, [x0, #0x78]
    cd24:      	add	x3, x3, x2, lsl #2
    cd28:      	ldr	w3, [x3]
    cd2c:      	sxtw	x3, w3
    cd30:      	cmp	x3, #0x0
    cd34:      	cset	w3, ge
    cd38:      	ubfx	x3, x3, #0, #8
    cd3c:      	b	0xce90 <_stogir.checked.projection+0x1c8>
    cd40:      	cmp	x2, #0x0
    cd44:      	b.ge	0xcd94 <_stogir.checked.projection+0xcc>
    cd48:      	add	x7, x0, #0x50
    cd4c:      	ldr	x3, [x3, #0x8]
    cd50:      	ldr	x7, [x7, #0x8]
    cd54:      	cmp	x3, x7
    cd58:      	b.ne	0xcd84 <_stogir.checked.projection+0xbc>
    cd5c:      	cmp	x5, x3
    cd60:      	b.gt	0xcebc <_stogir.checked.projection+0x1f4>
    cd64:      	ldr	x3, [x0, #0x50]
    cd68:      	add	x3, x3, x6, lsl #2
    cd6c:      	ldr	w3, [x3]
    cd70:      	sxtw	x3, w3
    cd74:      	cmp	x3, #0x0
    cd78:      	cset	w3, gt
    cd7c:      	ubfx	x3, x3, #0, #8
    cd80:      	b	0xcec0 <_stogir.checked.projection+0x1f8>
    cd84:      	movz	x3, #0x0, lsl #48
    cd88:      	b	0xcd98 <_stogir.checked.projection+0xd0>
    cd8c:      	movz	x3, #0x0, lsl #48
    cd90:      	b	0xcd98 <_stogir.checked.projection+0xd0>
    cd94:      	movz	x3, #0x0, lsl #48
    cd98:      	cmp	x3, #0x0
    cd9c:      	b.eq	0xcdd0 <_stogir.checked.projection+0x108>
    cda0:      	uxtb	w16, w4
    cda4:      	cmp	w16, wzr
    cda8:      	b.eq	0xcdbc <_stogir.checked.projection+0xf4>
    cdac:      	ldr	x3, [x0]
    cdb0:      	add	x2, x3, x2, lsl #4
    cdb4:      	ldr	x2, [x2]
    cdb8:      	b	0xcdc8 <_stogir.checked.projection+0x100>
    cdbc:      	ldr	x2, [x0, #0x28]
    cdc0:      	add	x2, x2, x6, lsl #4
    cdc4:      	ldr	x2, [x2]
    cdc8:      	mov	w3, #0x1                ; =1
    cdcc:      	b	0xcdd8 <_stogir.checked.projection+0x110>
    cdd0:      	movz	w3, #0x0, lsl #16
    cdd4:      	movz	x2, #0x0, lsl #48
    cdd8:      	ubfx	x3, x3, #0, #32
    cddc:      	lsr	x16, x3, #0
    cde0:      	cmp	x16, #0x1
    cde4:      	b.eq	0xce00 <_stogir.checked.projection+0x138>
    cde8:      	b.lo	0xcdf0 <_stogir.checked.projection+0x128>
    cdec:      	b	0xce04 <_stogir.checked.projection+0x13c>
    cdf0:      	cmp	x16, #0x0
    cdf4:      	b.eq	0xcdfc <_stogir.checked.projection+0x134>
    cdf8:      	b	0xce04 <_stogir.checked.projection+0x13c>
    cdfc:      	b	0xce08 <_stogir.checked.projection+0x140>
    ce00:      	b	0xce50 <_stogir.checked.projection+0x188>
    ce04:      	b	0xcec4 <_stogir.checked.projection+0x1fc>
    ce08:      	mov	x19, x8
    ce0c:      	mov	x0, #0x1                ; =1
    ce10:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000ce10:  ARM64_RELOC_PAGE21	l_stogir.509
    ce14:      	ldr	x1, [x1]
		000000000000ce14:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    ce18:      	mov	x2, #0x17               ; =23
    ce1c:      	b	0xce30 <_stogir.checked.projection+0x168>
    ce20:      	mov	x0, #0x1                ; =1
    ce24:      	adrp	x1, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000ce24:  ARM64_RELOC_PAGE21	l_stogir.510
    ce28:      	ldr	x1, [x1]
		000000000000ce28:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    ce2c:      	mov	x2, #0x20               ; =32
    ce30:      	str	x0, [x19]
    ce34:      	str	x1, [x19, #0x8]
    ce38:      	str	x2, [x19, #0x10]
    ce3c:      	ldr	x19, [sp, #0x30]
    ce40:      	ldr	x29, [sp]
    ce44:      	ldr	x30, [sp, #0x8]
    ce48:      	add	sp, sp, #0x40
    ce4c:      	ret
    ce50:      	uxtb	w3, w2
    ce54:      	cmp	x3, #0x29
    ce58:      	b.lt	0xcecc <_stogir.checked.projection+0x204>
    ce5c:      	cmp	x3, #0x2b
    ce60:      	b.gt	0xced4 <_stogir.checked.projection+0x20c>
    ce64:      	mov	x19, x8
    ce68:      	add	x8, sp, #0x10
    ce6c:      	bl	0xce6c <_stogir.checked.projection+0x1a4>
		000000000000ce6c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    ce70:      	add	x16, sp, #0x10
    ce74:      	ldr	x0, [x16]
    ce78:      	add	x16, sp, #0x10
    ce7c:      	ldr	x1, [x16, #0x8]
    ce80:      	add	x16, sp, #0x10
    ce84:      	ldr	x2, [x16, #0x10]
    ce88:      	b	0xce30 <_stogir.checked.projection+0x168>
    ce8c:      	movz	x3, #0x0, lsl #48
    ce90:      	b	0xcd90 <_stogir.checked.projection+0xc8>
    ce94:      	ubfx	x2, x2, #0, #32
    ce98:      	ubfx	x0, x2, #8, #8
    ce9c:      	cmp	x0, #0x0
    cea0:      	b.eq	0xce20 <_stogir.checked.projection+0x158>
    cea4:      	cmp	x0, #0xd
    cea8:      	b.gt	0xce20 <_stogir.checked.projection+0x158>
    ceac:      	movz	x0, #0x0, lsl #48
    ceb0:      	movz	x1, #0x0, lsl #48
    ceb4:      	movz	x2, #0x0, lsl #48
    ceb8:      	b	0xce30 <_stogir.checked.projection+0x168>
    cebc:      	movz	x3, #0x0, lsl #48
    cec0:      	b	0xcd88 <_stogir.checked.projection+0xc0>
    cec4:      	brk	#0
    cec8:      	b	0xcec4 <_stogir.checked.projection+0x1fc>
    cecc:      	mov	x19, x8
    ced0:      	b	0xce94 <_stogir.checked.projection+0x1cc>
    ced4:      	mov	x19, x8
    ced8:      	b	0xce94 <_stogir.checked.projection+0x1cc>

000000000000cedc <_stogir.checked-schedule.validate-nodes>:
    cedc:      	sub	sp, sp, #0xe0
    cee0:      	str	x29, [sp]
    cee4:      	str	x30, [sp, #0x8]
    cee8:      	mov	x29, sp
    ceec:      	str	x19, [sp, #0x88]
    cef0:      	str	x20, [sp, #0x90]
    cef4:      	str	x21, [sp, #0x98]
    cef8:      	str	x22, [sp, #0xa0]
    cefc:      	str	x23, [sp, #0xa8]
    cf00:      	str	x24, [sp, #0xb0]
    cf04:      	str	x25, [sp, #0xb8]
    cf08:      	str	x26, [sp, #0xc0]
    cf0c:      	str	x27, [sp, #0xc8]
    cf10:      	str	x28, [sp, #0xd0]
    cf14:      	add	x19, x0, #0x28
    cf18:      	add	x20, x0, #0x78
    cf1c:      	add	x21, x0, #0x50
    cf20:      	add	x16, sp, #0x20
    cf24:      	orr	x2, x16, xzr
    cf28:      	add	x22, x2, #0x8
    cf2c:      	add	x16, sp, #0x40
    cf30:      	orr	x2, x16, xzr
    cf34:      	ldr	x3, [x1]
    cf38:      	add	x23, x2, #0x8
    cf3c:      	ldr	x1, [x1, #0x8]
    cf40:      	orr	x24, x3, xzr
    cf44:      	orr	x25, x1, xzr
    cf48:      	movz	x26, #0x0, lsl #48
    cf4c:      	adrp	x27, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000cf4c:  ARM64_RELOC_PAGE21	l_stogir.511
    cf50:      	ldr	x27, [x27]
		000000000000cf50:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    cf54:      	movz	x28, #0x0, lsl #48
    cf58:      	movz	w1, #0x0, lsl #16
    cf5c:      	movz	x2, #0x0, lsl #48
    cf60:      	b	0xcf88 <_stogir.checked-schedule.validate-nodes+0xac>
    cf64:      	adrp	x27, 0xc000 <_stogir.placement.use-block+0x174>
		000000000000cf64:  ARM64_RELOC_PAGE21	l_stogir.512
    cf68:      	ldr	x27, [x27]
		000000000000cf68:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    cf6c:      	mov	x28, #0x24              ; =36
    cf70:      	mov	x8, x19
    cf74:      	ldr	x0, [sp, #0x68]
    cf78:      	ldr	x19, [sp, #0x60]
    cf7c:      	mov	w1, w20
    cf80:      	ldr	x20, [sp, #0x70]
    cf84:      	ldr	x2, [sp, #0x78]
    cf88:      	cmp	x2, x25
    cf8c:      	b.ge	0xcfb0 <_stogir.checked-schedule.validate-nodes+0xd4>
    cf90:      	add	x3, x2, #0x1
    cf94:      	add	x2, x24, x2, lsl #2
    cf98:      	ldr	w2, [x2]
    cf9c:      	movn	w17, #0x0, lsl #16
    cfa0:      	and	w4, w2, w17
    cfa4:      	mov	x2, x3
    cfa8:      	mov	w3, #0x1                ; =1
    cfac:      	b	0xcfb8 <_stogir.checked-schedule.validate-nodes+0xdc>
    cfb0:      	movz	w3, #0x0, lsl #16
    cfb4:      	movz	w4, #0x0, lsl #16
    cfb8:      	ubfx	x3, x3, #0, #32
    cfbc:      	lsr	x16, x3, #0
    cfc0:      	cmp	x16, #0x1
    cfc4:      	b.eq	0xcfe4 <_stogir.checked-schedule.validate-nodes+0x108>
    cfc8:      	b.lo	0xcfd0 <_stogir.checked-schedule.validate-nodes+0xf4>
    cfcc:      	b	0xcfe8 <_stogir.checked-schedule.validate-nodes+0x10c>
    cfd0:      	cmp	x16, #0x0
    cfd4:      	b.eq	0xcfdc <_stogir.checked-schedule.validate-nodes+0x100>
    cfd8:      	b	0xcfe8 <_stogir.checked-schedule.validate-nodes+0x10c>
    cfdc:      	mov	x19, x8
    cfe0:      	b	0xd050 <_stogir.checked-schedule.validate-nodes+0x174>
    cfe4:      	b	0xcfec <_stogir.checked-schedule.validate-nodes+0x110>
    cfe8:      	b	0xd2b8 <_stogir.checked-schedule.validate-nodes+0x3dc>
    cfec:      	cmp	x28, #0x0
    cff0:      	b.ne	0xd320 <_stogir.checked-schedule.validate-nodes+0x444>
    cff4:      	sxtw	x3, w4
    cff8:      	cmp	x3, #0x0
    cffc:      	cset	w5, gt
    d000:      	movz	x16, #0x0, lsl #48
    d004:      	sub	x6, x16, x3
    d008:      	sub	x7, x6, #0x1
    d00c:      	uxtb	w16, w5
    d010:      	cmp	w16, wzr
    d014:      	b.eq	0xd0b0 <_stogir.checked-schedule.validate-nodes+0x1d4>
    d018:      	ldr	x6, [x0, #0x8]
    d01c:      	cmp	x3, x6
    d020:      	b.ge	0xd0f0 <_stogir.checked-schedule.validate-nodes+0x214>
    d024:      	ldr	x6, [x20, #0x8]
    d028:      	cmp	x3, x6
    d02c:      	b.ge	0xd230 <_stogir.checked-schedule.validate-nodes+0x354>
    d030:      	ldr	x6, [x0, #0x78]
    d034:      	add	x6, x6, x3, lsl #2
    d038:      	ldr	w6, [x6]
    d03c:      	sxtw	x6, w6
    d040:      	cmp	x6, #0x0
    d044:      	cset	w6, ge
    d048:      	ubfx	x6, x6, #0, #8
    d04c:      	b	0xd234 <_stogir.checked-schedule.validate-nodes+0x358>
    d050:      	cmp	x28, #0x0
    d054:      	b.ne	0xd068 <_stogir.checked-schedule.validate-nodes+0x18c>
    d058:      	and	x27, x26, #0xffffffff
    d05c:      	movz	x0, #0x0, lsl #48
    d060:      	movz	x28, #0x0, lsl #48
    d064:      	b	0xd06c <_stogir.checked-schedule.validate-nodes+0x190>
    d068:      	mov	x0, #0x1                ; =1
    d06c:      	str	x0, [x19]
    d070:      	str	x27, [x19, #0x8]
    d074:      	str	x28, [x19, #0x10]
    d078:      	ldr	x19, [sp, #0x88]
    d07c:      	ldr	x20, [sp, #0x90]
    d080:      	ldr	x21, [sp, #0x98]
    d084:      	ldr	x22, [sp, #0xa0]
    d088:      	ldr	x23, [sp, #0xa8]
    d08c:      	ldr	x24, [sp, #0xb0]
    d090:      	ldr	x25, [sp, #0xb8]
    d094:      	ldr	x26, [sp, #0xc0]
    d098:      	ldr	x27, [sp, #0xc8]
    d09c:      	ldr	x28, [sp, #0xd0]
    d0a0:      	ldr	x29, [sp]
    d0a4:      	ldr	x30, [sp, #0x8]
    d0a8:      	add	sp, sp, #0xe0
    d0ac:      	ret
    d0b0:      	cmp	x3, #0x0
    d0b4:      	b.ge	0xd0f8 <_stogir.checked-schedule.validate-nodes+0x21c>
    d0b8:      	ldr	x9, [x19, #0x8]
    d0bc:      	ldr	x10, [x21, #0x8]
    d0c0:      	cmp	x9, x10
    d0c4:      	b.ne	0xd228 <_stogir.checked-schedule.validate-nodes+0x34c>
    d0c8:      	cmp	x6, x9
    d0cc:      	b.gt	0xd2a0 <_stogir.checked-schedule.validate-nodes+0x3c4>
    d0d0:      	ldr	x6, [x0, #0x50]
    d0d4:      	add	x6, x6, x7, lsl #2
    d0d8:      	ldr	w6, [x6]
    d0dc:      	sxtw	x6, w6
    d0e0:      	cmp	x6, #0x0
    d0e4:      	cset	w6, gt
    d0e8:      	ubfx	x6, x6, #0, #8
    d0ec:      	b	0xd2a4 <_stogir.checked-schedule.validate-nodes+0x3c8>
    d0f0:      	movz	x6, #0x0, lsl #48
    d0f4:      	b	0xd0fc <_stogir.checked-schedule.validate-nodes+0x220>
    d0f8:      	movz	x6, #0x0, lsl #48
    d0fc:      	cmp	x6, #0x0
    d100:      	b.eq	0xd13c <_stogir.checked-schedule.validate-nodes+0x260>
    d104:      	uxtb	w16, w5
    d108:      	cmp	w16, wzr
    d10c:      	b.eq	0xd124 <_stogir.checked-schedule.validate-nodes+0x248>
    d110:      	ldr	x5, [x0]
    d114:      	add	x3, x5, x3, lsl #4
    d118:      	ldr	x5, [x3]
    d11c:      	ldr	x3, [x3, #0x8]
    d120:      	b	0xd134 <_stogir.checked-schedule.validate-nodes+0x258>
    d124:      	ldr	x3, [x0, #0x28]
    d128:      	add	x3, x3, x7, lsl #4
    d12c:      	ldr	x5, [x3]
    d130:      	ldr	x3, [x3, #0x8]
    d134:      	mov	w6, #0x1                ; =1
    d138:      	b	0xd148 <_stogir.checked-schedule.validate-nodes+0x26c>
    d13c:      	movz	w6, #0x0, lsl #16
    d140:      	movz	x5, #0x0, lsl #48
    d144:      	movz	x3, #0x0, lsl #48
    d148:      	ubfx	x6, x6, #0, #32
    d14c:      	lsr	x16, x6, #0
    d150:      	cmp	x16, #0x1
    d154:      	b.eq	0xd188 <_stogir.checked-schedule.validate-nodes+0x2ac>
    d158:      	b.lo	0xd160 <_stogir.checked-schedule.validate-nodes+0x284>
    d15c:      	b	0xd18c <_stogir.checked-schedule.validate-nodes+0x2b0>
    d160:      	cmp	x16, #0x0
    d164:      	b.eq	0xd16c <_stogir.checked-schedule.validate-nodes+0x290>
    d168:      	b	0xd18c <_stogir.checked-schedule.validate-nodes+0x2b0>
    d16c:      	str	x0, [sp, #0x68]
    d170:      	str	x19, [sp, #0x60]
    d174:      	mov	x19, x8
    d178:      	str	x20, [sp, #0x70]
    d17c:      	mov	w20, w1
    d180:      	str	x2, [sp, #0x78]
    d184:      	b	0xcf64 <_stogir.checked-schedule.validate-nodes+0x88>
    d188:      	b	0xd190 <_stogir.checked-schedule.validate-nodes+0x2b4>
    d18c:      	b	0xd308 <_stogir.checked-schedule.validate-nodes+0x42c>
    d190:      	uxtb	w6, w5
    d194:      	add	x16, sp, #0x10
    d198:      	str	x5, [x16]
    d19c:      	add	x16, sp, #0x10
    d1a0:      	str	x3, [x16, #0x8]
    d1a4:      	cmp	x6, #0x29
    d1a8:      	b.lt	0xd33c <_stogir.checked-schedule.validate-nodes+0x460>
    d1ac:      	cmp	x6, #0x2b
    d1b0:      	b.gt	0xd35c <_stogir.checked-schedule.validate-nodes+0x480>
    d1b4:      	str	x0, [sp, #0x68]
    d1b8:      	str	x2, [sp, #0x78]
    d1bc:      	str	w4, [sp, #0x80]
    d1c0:      	str	x19, [sp, #0x60]
    d1c4:      	mov	x19, x8
    d1c8:      	add	x8, sp, #0x20
    d1cc:      	str	x20, [sp, #0x70]
    d1d0:      	mov	w20, w1
    d1d4:      	mov	w1, w4
    d1d8:      	bl	0xd1d8 <_stogir.checked-schedule.validate-nodes+0x2fc>
		000000000000d1d8:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    d1dc:      	add	x16, sp, #0x20
    d1e0:      	ldr	w0, [x16]
    d1e4:      	lsr	x16, x0, #0
    d1e8:      	cmp	x16, #0x1
    d1ec:      	b.eq	0xd208 <_stogir.checked-schedule.validate-nodes+0x32c>
    d1f0:      	b.lo	0xd1f8 <_stogir.checked-schedule.validate-nodes+0x31c>
    d1f4:      	b	0xd20c <_stogir.checked-schedule.validate-nodes+0x330>
    d1f8:      	cmp	x16, #0x0
    d1fc:      	b.eq	0xd204 <_stogir.checked-schedule.validate-nodes+0x328>
    d200:      	b	0xd20c <_stogir.checked-schedule.validate-nodes+0x330>
    d204:      	b	0xd2c0 <_stogir.checked-schedule.validate-nodes+0x3e4>
    d208:      	b	0xd210 <_stogir.checked-schedule.validate-nodes+0x334>
    d20c:      	b	0xd318 <_stogir.checked-schedule.validate-nodes+0x43c>
    d210:      	add	x16, sp, #0x20
    d214:      	ldr	x27, [x16, #0x8]
    d218:      	ldr	x28, [x22, #0x8]
    d21c:      	b	0xd2c4 <_stogir.checked-schedule.validate-nodes+0x3e8>
    d220:      	movz	w20, #0x0, lsl #16
    d224:      	b	0xcf70 <_stogir.checked-schedule.validate-nodes+0x94>
    d228:      	movz	x6, #0x0, lsl #48
    d22c:      	b	0xd0fc <_stogir.checked-schedule.validate-nodes+0x220>
    d230:      	movz	x6, #0x0, lsl #48
    d234:      	b	0xd0f4 <_stogir.checked-schedule.validate-nodes+0x218>
    d238:      	add	x16, sp, #0x10
    d23c:      	ldr	w0, [x16]
    d240:      	uxtb	w0, w0
    d244:      	cmp	x0, #0x2c
    d248:      	b.ne	0xd220 <_stogir.checked-schedule.validate-nodes+0x344>
    d24c:      	add	x8, sp, #0x40
    d250:      	ldr	x0, [sp, #0x68]
    d254:      	ldr	w1, [sp, #0x80]
    d258:      	bl	0xd258 <_stogir.checked-schedule.validate-nodes+0x37c>
		000000000000d258:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    d25c:      	add	x16, sp, #0x40
    d260:      	ldr	w0, [x16]
    d264:      	lsr	x16, x0, #0
    d268:      	cmp	x16, #0x1
    d26c:      	b.eq	0xd288 <_stogir.checked-schedule.validate-nodes+0x3ac>
    d270:      	b.lo	0xd278 <_stogir.checked-schedule.validate-nodes+0x39c>
    d274:      	b	0xd28c <_stogir.checked-schedule.validate-nodes+0x3b0>
    d278:      	cmp	x16, #0x0
    d27c:      	b.eq	0xd284 <_stogir.checked-schedule.validate-nodes+0x3a8>
    d280:      	b	0xd28c <_stogir.checked-schedule.validate-nodes+0x3b0>
    d284:      	b	0xd2c8 <_stogir.checked-schedule.validate-nodes+0x3ec>
    d288:      	b	0xd290 <_stogir.checked-schedule.validate-nodes+0x3b4>
    d28c:      	b	0xd310 <_stogir.checked-schedule.validate-nodes+0x434>
    d290:      	add	x16, sp, #0x40
    d294:      	ldr	x27, [x16, #0x8]
    d298:      	ldr	x28, [x23, #0x8]
    d29c:      	b	0xd2b4 <_stogir.checked-schedule.validate-nodes+0x3d8>
    d2a0:      	movz	x6, #0x0, lsl #48
    d2a4:      	b	0xd22c <_stogir.checked-schedule.validate-nodes+0x350>
    d2a8:      	adrp	x27, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000d2a8:  ARM64_RELOC_PAGE21	l_stogir.513
    d2ac:      	ldr	x27, [x27]
		000000000000d2ac:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    d2b0:      	mov	x28, #0x35              ; =53
    d2b4:      	b	0xd224 <_stogir.checked-schedule.validate-nodes+0x348>
    d2b8:      	brk	#0
    d2bc:      	b	0xd2b8 <_stogir.checked-schedule.validate-nodes+0x3dc>
    d2c0:      	ldr	w20, [sp, #0x80]
    d2c4:      	b	0xd224 <_stogir.checked-schedule.validate-nodes+0x348>
    d2c8:      	add	x16, sp, #0x40
    d2cc:      	ldr	w0, [x16, #0x8]
    d2d0:      	sxtw	x0, w0
    d2d4:      	cmp	x0, #0x0
    d2d8:      	b.ne	0xd2e4 <_stogir.checked-schedule.validate-nodes+0x408>
    d2dc:      	movz	w20, #0x0, lsl #16
    d2e0:      	b	0xd2b4 <_stogir.checked-schedule.validate-nodes+0x3d8>
    d2e4:      	sxtw	x0, w20
    d2e8:      	add	x16, sp, #0x10
    d2ec:      	ldr	w1, [x16, #0x4]
    d2f0:      	sxtw	x1, w1
    d2f4:      	cmp	x0, x1
    d2f8:      	b.ne	0xd2a8 <_stogir.checked-schedule.validate-nodes+0x3cc>
    d2fc:      	add	x0, x26, #0x1
    d300:      	sxtw	x26, w0
    d304:      	b	0xd2b4 <_stogir.checked-schedule.validate-nodes+0x3d8>
    d308:      	brk	#0
    d30c:      	b	0xd308 <_stogir.checked-schedule.validate-nodes+0x42c>
    d310:      	brk	#0
    d314:      	b	0xd310 <_stogir.checked-schedule.validate-nodes+0x434>
    d318:      	brk	#0
    d31c:      	b	0xd318 <_stogir.checked-schedule.validate-nodes+0x43c>
    d320:      	str	x0, [sp, #0x68]
    d324:      	str	x19, [sp, #0x60]
    d328:      	mov	x19, x8
    d32c:      	str	x20, [sp, #0x70]
    d330:      	mov	w20, w1
    d334:      	str	x2, [sp, #0x78]
    d338:      	b	0xcf70 <_stogir.checked-schedule.validate-nodes+0x94>
    d33c:      	str	x0, [sp, #0x68]
    d340:      	str	w4, [sp, #0x80]
    d344:      	str	x19, [sp, #0x60]
    d348:      	mov	x19, x8
    d34c:      	str	x20, [sp, #0x70]
    d350:      	mov	w20, w1
    d354:      	str	x2, [sp, #0x78]
    d358:      	b	0xd238 <_stogir.checked-schedule.validate-nodes+0x35c>
    d35c:      	str	x0, [sp, #0x68]
    d360:      	str	w4, [sp, #0x80]
    d364:      	str	x19, [sp, #0x60]
    d368:      	mov	x19, x8
    d36c:      	str	x20, [sp, #0x70]
    d370:      	mov	w20, w1
    d374:      	str	x2, [sp, #0x78]
    d378:      	b	0xd238 <_stogir.checked-schedule.validate-nodes+0x35c>

000000000000d37c <_coil.alloc.sized-free>:
    d37c:      	sub	sp, sp, #0x70
    d380:      	str	x29, [sp]
    d384:      	str	x30, [sp, #0x8]
    d388:      	mov	x29, sp
    d38c:      	str	x19, [sp, #0x60]
    d390:      	str	x20, [sp, #0x68]
    d394:      	cmp	x2, #0x0
    d398:      	b.ne	0xd3b8 <_coil.alloc.sized-free+0x3c>
    d39c:      	movz	x0, #0x0, lsl #48
    d3a0:      	ldr	x19, [sp, #0x60]
    d3a4:      	ldr	x20, [sp, #0x68]
    d3a8:      	ldr	x29, [sp]
    d3ac:      	ldr	x30, [sp, #0x8]
    d3b0:      	add	sp, sp, #0x70
    d3b4:      	ret
    d3b8:      	add	x8, sp, #0x10
    d3bc:      	mov	x19, x0
    d3c0:      	mov	x0, x3
    d3c4:      	mov	x3, x2
    d3c8:      	mov	x2, x5
    d3cc:      	mov	x20, x1
    d3d0:      	mov	x1, x4
    d3d4:      	bl	0xd3d4 <_coil.alloc.sized-free+0x58>
		000000000000d3d4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    d3d8:      	add	x16, sp, #0x10
    d3dc:      	ldr	w0, [x16]
    d3e0:      	lsr	x16, x0, #0
    d3e4:      	cmp	x16, #0x1
    d3e8:      	b.eq	0xd404 <_coil.alloc.sized-free+0x88>
    d3ec:      	b.lo	0xd3f4 <_coil.alloc.sized-free+0x78>
    d3f0:      	b	0xd408 <_coil.alloc.sized-free+0x8c>
    d3f4:      	cmp	x16, #0x0
    d3f8:      	b.eq	0xd400 <_coil.alloc.sized-free+0x84>
    d3fc:      	b	0xd408 <_coil.alloc.sized-free+0x8c>
    d400:      	b	0xd40c <_coil.alloc.sized-free+0x90>
    d404:      	b	0xd414 <_coil.alloc.sized-free+0x98>
    d408:      	b	0xd468 <_coil.alloc.sized-free+0xec>
    d40c:      	movz	x0, #0x0, lsl #48
    d410:      	b	0xd464 <_coil.alloc.sized-free+0xe8>
    d414:      	add	x16, sp, #0x10
    d418:      	orr	x0, x16, xzr
    d41c:      	add	x0, x0, #0x8
    d420:      	add	x16, sp, #0x10
    d424:      	ldr	x1, [x16, #0x8]
    d428:      	add	x16, sp, #0x40
    d42c:      	str	x1, [x16]
    d430:      	ldr	x1, [x0, #0x8]
    d434:      	add	x16, sp, #0x40
    d438:      	str	x1, [x16, #0x8]
    d43c:      	ldr	x1, [x0, #0x10]
    d440:      	add	x16, sp, #0x40
    d444:      	str	x1, [x16, #0x10]
    d448:      	ldr	x0, [x0, #0x18]
    d44c:      	add	x16, sp, #0x40
    d450:      	str	x0, [x16, #0x18]
    d454:      	mov	x0, x19
    d458:      	mov	x1, x20
    d45c:      	add	x2, sp, #0x40
    d460:      	bl	0xd460 <_coil.alloc.sized-free+0xe4>
		000000000000d460:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-free
    d464:      	b	0xd3a0 <_coil.alloc.sized-free+0x24>
    d468:      	brk	#0
    d46c:      	b	0xd468 <_coil.alloc.sized-free+0xec>

000000000000d470 <_stogir.types.valid?>:
    d470:      	sxtw	x1, w0
    d474:      	cmp	x1, #0x0
    d478:      	b.lt	0xd48c <_stogir.types.valid?+0x1c>
    d47c:      	cmp	x1, #0xd
    d480:      	b.gt	0xd48c <_stogir.types.valid?+0x1c>
    d484:      	mov	x0, #0x1                ; =1
    d488:      	b	0xd4c8 <_stogir.types.valid?+0x58>
    d48c:      	cmp	x1, #0xf
    d490:      	b.le	0xd4c4 <_stogir.types.valid?+0x54>
    d494:      	cmp	x1, #0x80
    d498:      	b.ge	0xd4bc <_stogir.types.valid?+0x4c>
    d49c:      	and	w0, w0, #0xf
    d4a0:      	ubfx	x0, x0, #0, #32
    d4a4:      	cmp	x0, #0x1
    d4a8:      	b.lt	0xd4cc <_stogir.types.valid?+0x5c>
    d4ac:      	cmp	x0, #0xd
    d4b0:      	cset	w0, le
    d4b4:      	ubfx	x0, x0, #0, #8
    d4b8:      	b	0xd4d0 <_stogir.types.valid?+0x60>
    d4bc:      	movz	x0, #0x0, lsl #48
    d4c0:      	b	0xd4c8 <_stogir.types.valid?+0x58>
    d4c4:      	movz	x0, #0x0, lsl #48
    d4c8:      	ret
    d4cc:      	movz	x0, #0x0, lsl #48
    d4d0:      	b	0xd4c0 <_stogir.types.valid?+0x50>

000000000000d4d4 <_stogir.opcode.input-count>:
    d4d4:      	sxtw	x0, w0
    d4d8:      	cmp	x0, #0x0
    d4dc:      	b.lt	0xd500 <_stogir.opcode.input-count+0x2c>
    d4e0:      	cmp	x0, #0x83
    d4e4:      	b.ge	0xd500 <_stogir.opcode.input-count+0x2c>
    d4e8:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000d4e8:  ARM64_RELOC_PAGE21	l_stogir.514
    d4ec:      	ldr	x16, [x16]
		000000000000d4ec:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    d4f0:      	add	x0, x16, x0
    d4f4:      	ldrsb	w0, [x0]
    d4f8:      	sxtb	x0, w0
    d4fc:      	b	0xd504 <_stogir.opcode.input-count+0x30>
    d500:      	mov	x0, #-0x2               ; =-2
    d504:      	ret

000000000000d508 <_stogir.graph.borrow-node>:
    d508:      	sxtw	x1, w1
    d50c:      	add	x2, x0, #0x28
    d510:      	cmp	x1, #0x0
    d514:      	cset	w3, gt
    d518:      	movz	x16, #0x0, lsl #48
    d51c:      	sub	x4, x16, x1
    d520:      	sub	x5, x4, #0x1
    d524:      	uxtb	w16, w3
    d528:      	cmp	w16, wzr
    d52c:      	b.eq	0xd56c <_stogir.graph.borrow-node+0x64>
    d530:      	ldr	x2, [x0, #0x8]
    d534:      	cmp	x1, x2
    d538:      	b.ge	0xd5b8 <_stogir.graph.borrow-node+0xb0>
    d53c:      	add	x2, x0, #0x78
    d540:      	ldr	x2, [x2, #0x8]
    d544:      	cmp	x1, x2
    d548:      	b.ge	0xd5f8 <_stogir.graph.borrow-node+0xf0>
    d54c:      	ldr	x2, [x0, #0x78]
    d550:      	add	x2, x2, x1, lsl #2
    d554:      	ldr	w2, [x2]
    d558:      	sxtw	x2, w2
    d55c:      	cmp	x2, #0x0
    d560:      	cset	w2, ge
    d564:      	ubfx	x2, x2, #0, #8
    d568:      	b	0xd5fc <_stogir.graph.borrow-node+0xf4>
    d56c:      	cmp	x1, #0x0
    d570:      	b.ge	0xd5c0 <_stogir.graph.borrow-node+0xb8>
    d574:      	add	x6, x0, #0x50
    d578:      	ldr	x2, [x2, #0x8]
    d57c:      	ldr	x6, [x6, #0x8]
    d580:      	cmp	x2, x6
    d584:      	b.ne	0xd5b0 <_stogir.graph.borrow-node+0xa8>
    d588:      	cmp	x4, x2
    d58c:      	b.gt	0xd600 <_stogir.graph.borrow-node+0xf8>
    d590:      	ldr	x2, [x0, #0x50]
    d594:      	add	x2, x2, x5, lsl #2
    d598:      	ldr	w2, [x2]
    d59c:      	sxtw	x2, w2
    d5a0:      	cmp	x2, #0x0
    d5a4:      	cset	w2, gt
    d5a8:      	ubfx	x2, x2, #0, #8
    d5ac:      	b	0xd604 <_stogir.graph.borrow-node+0xfc>
    d5b0:      	movz	x2, #0x0, lsl #48
    d5b4:      	b	0xd5c4 <_stogir.graph.borrow-node+0xbc>
    d5b8:      	movz	x2, #0x0, lsl #48
    d5bc:      	b	0xd5c4 <_stogir.graph.borrow-node+0xbc>
    d5c0:      	movz	x2, #0x0, lsl #48
    d5c4:      	cmp	x2, #0x0
    d5c8:      	b.eq	0xd5f0 <_stogir.graph.borrow-node+0xe8>
    d5cc:      	uxtb	w16, w3
    d5d0:      	cmp	w16, wzr
    d5d4:      	b.eq	0xd5e4 <_stogir.graph.borrow-node+0xdc>
    d5d8:      	ldr	x0, [x0]
    d5dc:      	add	x0, x0, x1, lsl #4
    d5e0:      	b	0xd5ec <_stogir.graph.borrow-node+0xe4>
    d5e4:      	ldr	x0, [x0, #0x28]
    d5e8:      	add	x0, x0, x5, lsl #4
    d5ec:      	b	0xd5f4 <_stogir.graph.borrow-node+0xec>
    d5f0:      	movz	x0, #0x0, lsl #48
    d5f4:      	ret
    d5f8:      	movz	x2, #0x0, lsl #48
    d5fc:      	b	0xd5bc <_stogir.graph.borrow-node+0xb4>
    d600:      	movz	x2, #0x0, lsl #48
    d604:      	b	0xd5b4 <_stogir.graph.borrow-node+0xac>

000000000000d608 <_stogir.verify.phis-structured>:
    d608:      	sub	sp, sp, #0xd0
    d60c:      	str	x29, [sp, #0x10]
    d610:      	str	x30, [sp, #0x18]
    d614:      	add	x29, sp, #0x10
    d618:      	str	x19, [sp, #0x78]
    d61c:      	str	x20, [sp, #0x80]
    d620:      	str	x21, [sp, #0x88]
    d624:      	str	x22, [sp, #0x90]
    d628:      	str	x23, [sp, #0x98]
    d62c:      	str	x24, [sp, #0xa0]
    d630:      	str	x25, [sp, #0xa8]
    d634:      	str	x26, [sp, #0xb0]
    d638:      	str	x27, [sp, #0xb8]
    d63c:      	str	x28, [sp, #0xc0]
    d640:      	add	x19, x0, #0x78
    d644:      	add	x20, x0, #0x28
    d648:      	add	x21, x0, #0x50
    d64c:      	mov	x22, #0x1               ; =1
    d650:      	movz	x23, #0x0, lsl #48
    d654:      	adrp	x24, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000d654:  ARM64_RELOC_PAGE21	l_stogir.515
    d658:      	ldr	x24, [x24]
		000000000000d658:  ARM64_RELOC_PAGEOFF12	l_stogir.515
    d65c:      	movz	x25, #0x0, lsl #48
    d660:      	b	0xd948 <_stogir.verify.phis-structured+0x340>
    d664:      	movz	x6, #0x0, lsl #48
    d668:      	b	0xd678 <_stogir.verify.phis-structured+0x70>
    d66c:      	movz	x6, #0x0, lsl #48
    d670:      	b	0xd680 <_stogir.verify.phis-structured+0x78>
    d674:      	movz	x6, #0x0, lsl #48
    d678:      	b	0xd688 <_stogir.verify.phis-structured+0x80>
    d67c:      	movz	x6, #0x0, lsl #48
    d680:      	b	0xd688 <_stogir.verify.phis-structured+0x80>
    d684:      	movz	x6, #0x0, lsl #48
    d688:      	cmp	x6, #0x0
    d68c:      	b.eq	0xd6c0 <_stogir.verify.phis-structured+0xb8>
    d690:      	uxtb	w16, w5
    d694:      	cmp	w16, wzr
    d698:      	b.eq	0xd6ac <_stogir.verify.phis-structured+0xa4>
    d69c:      	ldr	x5, [x24]
    d6a0:      	add	x4, x5, x4, lsl #4
    d6a4:      	ldr	x4, [x4]
    d6a8:      	b	0xd6b8 <_stogir.verify.phis-structured+0xb0>
    d6ac:      	ldr	x4, [x24, #0x28]
    d6b0:      	add	x4, x4, x7, lsl #4
    d6b4:      	ldr	x4, [x4]
    d6b8:      	mov	w5, #0x1                ; =1
    d6bc:      	b	0xd6c8 <_stogir.verify.phis-structured+0xc0>
    d6c0:      	movz	w5, #0x0, lsl #16
    d6c4:      	movz	x4, #0x0, lsl #48
    d6c8:      	ubfx	x5, x5, #0, #32
    d6cc:      	lsr	x16, x5, #0
    d6d0:      	cmp	x16, #0x1
    d6d4:      	b.eq	0xd6f0 <_stogir.verify.phis-structured+0xe8>
    d6d8:      	b.lo	0xd6e0 <_stogir.verify.phis-structured+0xd8>
    d6dc:      	b	0xd6f4 <_stogir.verify.phis-structured+0xec>
    d6e0:      	cmp	x16, #0x0
    d6e4:      	b.eq	0xd6ec <_stogir.verify.phis-structured+0xe4>
    d6e8:      	b	0xd6f4 <_stogir.verify.phis-structured+0xec>
    d6ec:      	b	0xd6f8 <_stogir.verify.phis-structured+0xf0>
    d6f0:      	b	0xd70c <_stogir.verify.phis-structured+0x104>
    d6f4:      	b	0xdb50 <_stogir.verify.phis-structured+0x548>
    d6f8:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000d6f8:  ARM64_RELOC_PAGE21	l_stogir.516
    d6fc:      	ldr	x16, [x16]
		000000000000d6fc:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    d700:      	str	x16, [sp, #0x68]
    d704:      	mov	x25, #0x11              ; =17
    d708:      	b	0xd72c <_stogir.verify.phis-structured+0x124>
    d70c:      	ubfx	x4, x4, #0, #32
    d710:      	ubfx	x4, x4, #8, #8
    d714:      	cmp	x4, x0
    d718:      	b.eq	0xd72c <_stogir.verify.phis-structured+0x124>
    d71c:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000d71c:  ARM64_RELOC_PAGE21	l_stogir.517
    d720:      	ldr	x16, [x16]
		000000000000d720:  ARM64_RELOC_PAGEOFF12	l_stogir.517
    d724:      	str	x16, [sp, #0x68]
    d728:      	mov	x25, #0x1a              ; =26
    d72c:      	b	0xd784 <_stogir.verify.phis-structured+0x17c>
    d730:      	movz	w5, #0x0, lsl #16
    d734:      	movz	w4, #0x0, lsl #16
    d738:      	b	0xd744 <_stogir.verify.phis-structured+0x13c>
    d73c:      	movz	w5, #0x0, lsl #16
    d740:      	movz	w4, #0x0, lsl #16
    d744:      	ubfx	x5, x5, #0, #32
    d748:      	lsr	x16, x5, #0
    d74c:      	cmp	x16, #0x1
    d750:      	b.eq	0xd76c <_stogir.verify.phis-structured+0x164>
    d754:      	b.lo	0xd75c <_stogir.verify.phis-structured+0x154>
    d758:      	b	0xd770 <_stogir.verify.phis-structured+0x168>
    d75c:      	cmp	x16, #0x0
    d760:      	b.eq	0xd768 <_stogir.verify.phis-structured+0x160>
    d764:      	b	0xd770 <_stogir.verify.phis-structured+0x168>
    d768:      	b	0xd774 <_stogir.verify.phis-structured+0x16c>
    d76c:      	b	0xd7f4 <_stogir.verify.phis-structured+0x1ec>
    d770:      	b	0xdb48 <_stogir.verify.phis-structured+0x540>
    d774:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000d774:  ARM64_RELOC_PAGE21	l_stogir.516
    d778:      	ldr	x16, [x16]
		000000000000d778:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    d77c:      	str	x16, [sp, #0x68]
    d780:      	mov	x25, #0x11              ; =17
    d784:      	add	x3, x3, #0x1
    d788:      	sxtw	x3, w3
    d78c:      	cmp	x25, #0x0
    d790:      	b.ne	0xd7a4 <_stogir.verify.phis-structured+0x19c>
    d794:      	cmp	x3, x27
    d798:      	cset	w4, le
    d79c:      	ubfx	x4, x4, #0, #8
    d7a0:      	b	0xd7a8 <_stogir.verify.phis-structured+0x1a0>
    d7a4:      	movz	x4, #0x0, lsl #48
    d7a8:      	cmp	x4, #0x0
    d7ac:      	b.eq	0xd914 <_stogir.verify.phis-structured+0x30c>
    d7b0:      	uxtb	w16, w1
    d7b4:      	cmp	w16, wzr
    d7b8:      	b.ne	0xd73c <_stogir.verify.phis-structured+0x134>
    d7bc:      	ldr	x4, [x24, #0x8]
    d7c0:      	cmp	x28, x4
    d7c4:      	b.ge	0xd858 <_stogir.verify.phis-structured+0x250>
    d7c8:      	ldr	x4, [x19, #0x8]
    d7cc:      	cmp	x28, x4
    d7d0:      	b.ge	0xd850 <_stogir.verify.phis-structured+0x248>
    d7d4:      	ldr	x4, [x24, #0x78]
    d7d8:      	add	x4, x2, x4
    d7dc:      	ldr	w4, [x4]
    d7e0:      	sxtw	x4, w4
    d7e4:      	cmp	x4, #0x0
    d7e8:      	cset	w4, ge
    d7ec:      	ubfx	x4, x4, #0, #8
    d7f0:      	b	0xd854 <_stogir.verify.phis-structured+0x24c>
    d7f4:      	sxtw	x4, w4
    d7f8:      	cmp	x4, #0x0
    d7fc:      	cset	w5, gt
    d800:      	movz	x16, #0x0, lsl #48
    d804:      	sub	x6, x16, x4
    d808:      	sub	x7, x6, #0x1
    d80c:      	uxtb	w16, w5
    d810:      	cmp	w16, wzr
    d814:      	b.eq	0xd8d4 <_stogir.verify.phis-structured+0x2cc>
    d818:      	ldr	x6, [x24, #0x8]
    d81c:      	cmp	x4, x6
    d820:      	b.ge	0xd67c <_stogir.verify.phis-structured+0x74>
    d824:      	ldr	x6, [x19, #0x8]
    d828:      	cmp	x4, x6
    d82c:      	b.ge	0xd66c <_stogir.verify.phis-structured+0x64>
    d830:      	ldr	x6, [x24, #0x78]
    d834:      	add	x6, x6, x4, lsl #2
    d838:      	ldr	w6, [x6]
    d83c:      	sxtw	x6, w6
    d840:      	cmp	x6, #0x0
    d844:      	cset	w6, ge
    d848:      	ubfx	x6, x6, #0, #8
    d84c:      	b	0xd670 <_stogir.verify.phis-structured+0x68>
    d850:      	movz	x4, #0x0, lsl #48
    d854:      	b	0xd85c <_stogir.verify.phis-structured+0x254>
    d858:      	movz	x4, #0x0, lsl #48
    d85c:      	cmp	x4, #0x0
    d860:      	b.eq	0xd73c <_stogir.verify.phis-structured+0x134>
    d864:      	orr	w4, w3, wzr
    d868:      	sxtw	x4, w4
    d86c:      	cmp	x4, #0x1
    d870:      	b.lt	0xd730 <_stogir.verify.phis-structured+0x128>
    d874:      	ldr	x5, [x24, #0x78]
    d878:      	add	x5, x2, x5
    d87c:      	ldr	w5, [x5]
    d880:      	sxtw	x5, w5
    d884:      	cmp	x4, x5
    d888:      	b.gt	0xd730 <_stogir.verify.phis-structured+0x128>
    d88c:      	ldr	x5, [x24]
    d890:      	asr	x16, x4, #63
    d894:      	lsr	x16, x16, #62
    d898:      	add	x6, x4, x16
    d89c:      	asr	x6, x6, #2
    d8a0:      	asr	x16, x4, #63
    d8a4:      	lsr	x16, x16, #62
    d8a8:      	add	x4, x4, x16
    d8ac:      	and	x4, x4, #0x3
    d8b0:      	sub	x4, x4, x16
    d8b4:      	add	x6, x6, x28
    d8b8:      	add	x5, x5, x6, lsl #4
    d8bc:      	add	x4, x5, x4, lsl #2
    d8c0:      	ldr	w4, [x4]
    d8c4:      	movn	w17, #0x0, lsl #16
    d8c8:      	and	w4, w4, w17
    d8cc:      	mov	w5, #0x1                ; =1
    d8d0:      	b	0xd738 <_stogir.verify.phis-structured+0x130>
    d8d4:      	cmp	x4, #0x0
    d8d8:      	b.ge	0xd684 <_stogir.verify.phis-structured+0x7c>
    d8dc:      	ldr	x8, [x20, #0x8]
    d8e0:      	ldr	x9, [x21, #0x8]
    d8e4:      	cmp	x8, x9
    d8e8:      	b.ne	0xd674 <_stogir.verify.phis-structured+0x6c>
    d8ec:      	cmp	x6, x8
    d8f0:      	b.gt	0xd664 <_stogir.verify.phis-structured+0x5c>
    d8f4:      	ldr	x6, [x24, #0x50]
    d8f8:      	add	x6, x6, x7, lsl #2
    d8fc:      	ldr	w6, [x6]
    d900:      	sxtw	x6, w6
    d904:      	cmp	x6, #0x0
    d908:      	cset	w6, gt
    d90c:      	ubfx	x6, x6, #0, #8
    d910:      	b	0xd668 <_stogir.verify.phis-structured+0x60>
    d914:      	add	x0, x23, #0x1
    d918:      	sxtw	x23, w0
    d91c:      	add	x0, x27, #0x4
    d920:      	asr	x16, x0, #63
    d924:      	lsr	x16, x16, #62
    d928:      	add	x0, x0, x16
    d92c:      	asr	x0, x0, #2
    d930:      	ldr	x1, [sp, #0x70]
    d934:      	add	x1, x0, x1
    d938:      	ldr	x8, [sp, #0x60]
    d93c:      	mov	x0, x24
    d940:      	mov	x22, x1
    d944:      	ldr	x24, [sp, #0x68]
    d948:      	cmp	x25, #0x0
    d94c:      	b.ne	0xdb98 <_stogir.verify.phis-structured+0x590>
    d950:      	ldr	x1, [x0, #0x8]
    d954:      	cmp	x22, x1
    d958:      	b.ge	0xdba4 <_stogir.verify.phis-structured+0x59c>
    d95c:      	ldr	x1, [x0]
    d960:      	add	x1, x1, x22, lsl #4
    d964:      	ldr	x26, [x1]
    d968:      	ldr	x1, [x0, #0x78]
    d96c:      	uxtb	w2, w26
    d970:      	add	x1, x1, x22, lsl #2
    d974:      	ldr	w1, [x1]
    d978:      	sxtw	x27, w1
    d97c:      	cmp	x2, #0x43
    d980:      	b.ne	0xdbb0 <_stogir.verify.phis-structured+0x5a8>
    d984:      	orr	w28, w22, wzr
    d988:      	cmp	x27, #0x3
    d98c:      	b.ge	0xd9e4 <_stogir.verify.phis-structured+0x3dc>
    d990:      	str	x22, [sp, #0x70]
    d994:      	str	x8, [sp, #0x60]
    d998:      	mov	x24, x0
    d99c:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000d99c:  ARM64_RELOC_PAGE21	l_stogir.518
    d9a0:      	ldr	x16, [x16]
		000000000000d9a0:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    d9a4:      	str	x16, [sp, #0x68]
    d9a8:      	mov	x25, #0x2b              ; =43
    d9ac:      	ubfx	x26, x26, #0, #32
    d9b0:      	ubfx	x0, x26, #8, #8
    d9b4:      	cmp	x0, #0x0
    d9b8:      	b.ne	0xd9cc <_stogir.verify.phis-structured+0x3c4>
    d9bc:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000d9bc:  ARM64_RELOC_PAGE21	l_stogir.519
    d9c0:      	ldr	x16, [x16]
		000000000000d9c0:  ARM64_RELOC_PAGEOFF12	l_stogir.519
    d9c4:      	str	x16, [sp, #0x68]
    d9c8:      	mov	x25, #0x19              ; =25
    d9cc:      	sxtw	x28, w28
    d9d0:      	cmp	x28, #0x0
    d9d4:      	cset	w1, le
    d9d8:      	lsl	x2, x28, #2
    d9dc:      	mov	x3, #0x2                ; =2
    d9e0:      	b	0xd78c <_stogir.verify.phis-structured+0x184>
    d9e4:      	mov	w1, w28
    d9e8:      	str	x8, [sp, #0x60]
    d9ec:      	str	x24, [sp, #0x68]
    d9f0:      	mov	x24, x0
    d9f4:      	mov	x2, #0x1                ; =1
    d9f8:      	bl	0xd9f8 <_stogir.verify.phis-structured+0x3f0>
		000000000000d9f8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    d9fc:      	ubfx	x0, x0, #0, #32
    da00:      	lsr	x16, x0, #0
    da04:      	cmp	x16, #0x1
    da08:      	b.eq	0xda24 <_stogir.verify.phis-structured+0x41c>
    da0c:      	b.lo	0xda14 <_stogir.verify.phis-structured+0x40c>
    da10:      	b	0xda28 <_stogir.verify.phis-structured+0x420>
    da14:      	cmp	x16, #0x0
    da18:      	b.eq	0xda20 <_stogir.verify.phis-structured+0x418>
    da1c:      	b	0xda28 <_stogir.verify.phis-structured+0x420>
    da20:      	b	0xda2c <_stogir.verify.phis-structured+0x424>
    da24:      	b	0xdaa8 <_stogir.verify.phis-structured+0x4a0>
    da28:      	b	0xdb88 <_stogir.verify.phis-structured+0x580>
    da2c:      	str	x22, [sp, #0x70]
    da30:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000da30:  ARM64_RELOC_PAGE21	l_stogir.520
    da34:      	ldr	x16, [x16]
		000000000000da34:  ARM64_RELOC_PAGEOFF12	l_stogir.520
    da38:      	str	x16, [sp, #0x68]
    da3c:      	mov	x25, #0x10              ; =16
    da40:      	b	0xd9ac <_stogir.verify.phis-structured+0x3a4>
    da44:      	cmp	x25, #0x0
    da48:      	b.ne	0xdbc4 <_stogir.verify.phis-structured+0x5bc>
    da4c:      	and	x0, x23, #0xffffffff
    da50:      	movz	x1, #0x0, lsl #48
    da54:      	movz	x25, #0x0, lsl #48
    da58:      	b	0xda60 <_stogir.verify.phis-structured+0x458>
    da5c:      	mov	x1, #0x1                ; =1
    da60:      	ldr	x2, [sp, #0x60]
    da64:      	str	x1, [x2]
    da68:      	str	x0, [x2, #0x8]
    da6c:      	str	x25, [x2, #0x10]
    da70:      	ldr	x19, [sp, #0x78]
    da74:      	ldr	x20, [sp, #0x80]
    da78:      	ldr	x21, [sp, #0x88]
    da7c:      	ldr	x22, [sp, #0x90]
    da80:      	ldr	x23, [sp, #0x98]
    da84:      	ldr	x24, [sp, #0xa0]
    da88:      	ldr	x25, [sp, #0xa8]
    da8c:      	ldr	x26, [sp, #0xb0]
    da90:      	ldr	x27, [sp, #0xb8]
    da94:      	ldr	x28, [sp, #0xc0]
    da98:      	ldr	x29, [sp, #0x10]
    da9c:      	ldr	x30, [sp, #0x18]
    daa0:      	add	sp, sp, #0xd0
    daa4:      	ret
    daa8:      	orr	w0, w1, wzr
    daac:      	add	x8, sp, #0x20
    dab0:      	mov	w1, w0
    dab4:      	str	x22, [sp, #0x70]
    dab8:      	mov	w22, w0
    dabc:      	mov	x0, x24
    dac0:      	bl	0xdac0 <_stogir.verify.phis-structured+0x4b8>
		000000000000dac0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    dac4:      	add	x16, sp, #0x20
    dac8:      	ldr	w0, [x16]
    dacc:      	lsr	x16, x0, #0
    dad0:      	cmp	x16, #0x1
    dad4:      	b.eq	0xdaf0 <_stogir.verify.phis-structured+0x4e8>
    dad8:      	b.lo	0xdae0 <_stogir.verify.phis-structured+0x4d8>
    dadc:      	b	0xdaf4 <_stogir.verify.phis-structured+0x4ec>
    dae0:      	cmp	x16, #0x0
    dae4:      	b.eq	0xdaec <_stogir.verify.phis-structured+0x4e4>
    dae8:      	b	0xdaf4 <_stogir.verify.phis-structured+0x4ec>
    daec:      	b	0xdaf8 <_stogir.verify.phis-structured+0x4f0>
    daf0:      	b	0xdb0c <_stogir.verify.phis-structured+0x504>
    daf4:      	b	0xdb90 <_stogir.verify.phis-structured+0x588>
    daf8:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000daf8:  ARM64_RELOC_PAGE21	l_stogir.521
    dafc:      	ldr	x16, [x16]
		000000000000dafc:  ARM64_RELOC_PAGEOFF12	l_stogir.521
    db00:      	str	x16, [sp, #0x68]
    db04:      	mov	x25, #0x12              ; =18
    db08:      	b	0xdb44 <_stogir.verify.phis-structured+0x53c>
    db0c:      	sxtw	x22, w22
    db10:      	add	x16, sp, #0x20
    db14:      	ldr	x0, [x16, #0x8]
    db18:      	cmp	x22, #0x0
    db1c:      	b.le	0xdb34 <_stogir.verify.phis-structured+0x52c>
    db20:      	uxtb	w0, w0
    db24:      	cmp	x0, #0x70
    db28:      	b.eq	0xdb58 <_stogir.verify.phis-structured+0x550>
    db2c:      	cmp	x0, #0x71
    db30:      	b.eq	0xdb58 <_stogir.verify.phis-structured+0x550>
    db34:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000db34:  ARM64_RELOC_PAGE21	l_stogir.522
    db38:      	ldr	x16, [x16]
		000000000000db38:  ARM64_RELOC_PAGEOFF12	l_stogir.522
    db3c:      	str	x16, [sp, #0x68]
    db40:      	mov	x25, #0x26              ; =38
    db44:      	b	0xda40 <_stogir.verify.phis-structured+0x438>
    db48:      	brk	#0
    db4c:      	b	0xdb48 <_stogir.verify.phis-structured+0x540>
    db50:      	brk	#0
    db54:      	b	0xdb50 <_stogir.verify.phis-structured+0x548>
    db58:      	ldr	x0, [x24, #0x78]
    db5c:      	add	x0, x0, x22, lsl #2
    db60:      	ldr	w0, [x0]
    db64:      	add	w0, w0, #0x1
    db68:      	sxtw	x0, w0
    db6c:      	cmp	x27, x0
    db70:      	b.eq	0xdb84 <_stogir.verify.phis-structured+0x57c>
    db74:      	adrp	x16, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000db74:  ARM64_RELOC_PAGE21	l_stogir.523
    db78:      	ldr	x16, [x16]
		000000000000db78:  ARM64_RELOC_PAGEOFF12	l_stogir.523
    db7c:      	str	x16, [sp, #0x68]
    db80:      	mov	x25, #0x2b              ; =43
    db84:      	b	0xdb44 <_stogir.verify.phis-structured+0x53c>
    db88:      	brk	#0
    db8c:      	b	0xdb88 <_stogir.verify.phis-structured+0x580>
    db90:      	brk	#0
    db94:      	b	0xdb90 <_stogir.verify.phis-structured+0x588>
    db98:      	str	x8, [sp, #0x60]
    db9c:      	str	x24, [sp, #0x68]
    dba0:      	b	0xda44 <_stogir.verify.phis-structured+0x43c>
    dba4:      	str	x8, [sp, #0x60]
    dba8:      	str	x24, [sp, #0x68]
    dbac:      	b	0xda44 <_stogir.verify.phis-structured+0x43c>
    dbb0:      	str	x22, [sp, #0x70]
    dbb4:      	str	x8, [sp, #0x60]
    dbb8:      	str	x24, [sp, #0x68]
    dbbc:      	mov	x24, x0
    dbc0:      	b	0xd91c <_stogir.verify.phis-structured+0x314>
    dbc4:      	ldr	x0, [sp, #0x68]
    dbc8:      	b	0xda5c <_stogir.verify.phis-structured+0x454>

000000000000dbcc <_inherent$coil.arraylist.ArrayList$reserve!__i32>:
    dbcc:      	sub	sp, sp, #0x50
    dbd0:      	str	x29, [sp]
    dbd4:      	str	x30, [sp, #0x8]
    dbd8:      	mov	x29, sp
    dbdc:      	str	x19, [sp, #0x40]
    dbe0:      	str	x20, [sp, #0x48]
    dbe4:      	add	x2, x0, #0x18
    dbe8:      	ldr	x3, [x0, #0x10]
    dbec:      	ldr	x4, [x0, #0x18]
    dbf0:      	ldr	x2, [x2, #0x8]
    dbf4:      	add	x16, sp, #0x10
    dbf8:      	str	x4, [x16]
    dbfc:      	add	x16, sp, #0x10
    dc00:      	str	x2, [x16, #0x8]
    dc04:      	cmp	x1, x3
    dc08:      	b.le	0xdc78 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xac>
    dc0c:      	ldr	x2, [x0]
    dc10:      	add	x8, sp, #0x20
    dc14:      	mov	x19, x0
    dc18:      	add	x0, sp, #0x10
    dc1c:      	mov	x20, x1
    dc20:      	fmov	d31, x1
    dc24:      	mov	x1, x2
    dc28:      	mov	x2, x3
    dc2c:      	fmov	x3, d31
    dc30:      	bl	0xdc30 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x64>
		000000000000dc30:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i32
    dc34:      	add	x16, sp, #0x20
    dc38:      	ldr	w0, [x16]
    dc3c:      	lsr	x16, x0, #0
    dc40:      	cmp	x16, #0x1
    dc44:      	b.eq	0xdc60 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x94>
    dc48:      	b.lo	0xdc50 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x84>
    dc4c:      	b	0xdc64 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x98>
    dc50:      	cmp	x16, #0x0
    dc54:      	b.eq	0xdc5c <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x90>
    dc58:      	b	0xdc64 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x98>
    dc5c:      	b	0xdc94 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xc8>
    dc60:      	b	0xdc68 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0x9c>
    dc64:      	b	0xdcac <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe0>
    dc68:      	add	x16, sp, #0x20
    dc6c:      	ldr	x0, [x16, #0x8]
    dc70:      	str	x0, [x19]
    dc74:      	str	x20, [x19, #0x10]
    dc78:      	movz	x0, #0x0, lsl #48
    dc7c:      	ldr	x19, [sp, #0x40]
    dc80:      	ldr	x20, [sp, #0x48]
    dc84:      	ldr	x29, [sp]
    dc88:      	ldr	x30, [sp, #0x8]
    dc8c:      	add	sp, sp, #0x50
    dc90:      	ret
    dc94:      	lsl	x0, x20, #2
    dc98:      	mov	x1, x0
    dc9c:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000dc9c:  ARM64_RELOC_PAGE21	l_stogir.524
    dca0:      	ldr	x0, [x0]
		000000000000dca0:  ARM64_RELOC_PAGEOFF12	l_stogir.524
    dca4:      	bl	0xdca4 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xd8>
		000000000000dca4:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    dca8:      	b	0xdca8 <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xdc>
    dcac:      	brk	#0
    dcb0:      	b	0xdcac <_inherent$coil.arraylist.ArrayList$reserve!__i32+0xe0>

000000000000dcb4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge>:
    dcb4:      	sub	sp, sp, #0x50
    dcb8:      	str	x29, [sp]
    dcbc:      	str	x30, [sp, #0x8]
    dcc0:      	mov	x29, sp
    dcc4:      	str	x19, [sp, #0x40]
    dcc8:      	str	x20, [sp, #0x48]
    dccc:      	add	x2, x0, #0x18
    dcd0:      	ldr	x3, [x0, #0x10]
    dcd4:      	ldr	x4, [x0, #0x18]
    dcd8:      	ldr	x2, [x2, #0x8]
    dcdc:      	add	x16, sp, #0x10
    dce0:      	str	x4, [x16]
    dce4:      	add	x16, sp, #0x10
    dce8:      	str	x2, [x16, #0x8]
    dcec:      	cmp	x1, x3
    dcf0:      	b.le	0xdd60 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xac>
    dcf4:      	ldr	x2, [x0]
    dcf8:      	add	x8, sp, #0x20
    dcfc:      	mov	x19, x0
    dd00:      	add	x0, sp, #0x10
    dd04:      	mov	x20, x1
    dd08:      	fmov	d31, x1
    dd0c:      	mov	x1, x2
    dd10:      	mov	x2, x3
    dd14:      	fmov	x3, d31
    dd18:      	bl	0xdd18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x64>
		000000000000dd18:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.cfg.Edge
    dd1c:      	add	x16, sp, #0x20
    dd20:      	ldr	w0, [x16]
    dd24:      	lsr	x16, x0, #0
    dd28:      	cmp	x16, #0x1
    dd2c:      	b.eq	0xdd48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x94>
    dd30:      	b.lo	0xdd38 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x84>
    dd34:      	b	0xdd4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x98>
    dd38:      	cmp	x16, #0x0
    dd3c:      	b.eq	0xdd44 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x90>
    dd40:      	b	0xdd4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x98>
    dd44:      	b	0xdd7c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xc8>
    dd48:      	b	0xdd50 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0x9c>
    dd4c:      	b	0xdd94 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe0>
    dd50:      	add	x16, sp, #0x20
    dd54:      	ldr	x0, [x16, #0x8]
    dd58:      	str	x0, [x19]
    dd5c:      	str	x20, [x19, #0x10]
    dd60:      	movz	x0, #0x0, lsl #48
    dd64:      	ldr	x19, [sp, #0x40]
    dd68:      	ldr	x20, [sp, #0x48]
    dd6c:      	ldr	x29, [sp]
    dd70:      	ldr	x30, [sp, #0x8]
    dd74:      	add	sp, sp, #0x50
    dd78:      	ret
    dd7c:      	lsl	x0, x20, #4
    dd80:      	mov	x1, x0
    dd84:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000dd84:  ARM64_RELOC_PAGE21	l_stogir.525
    dd88:      	ldr	x0, [x0]
		000000000000dd88:  ARM64_RELOC_PAGEOFF12	l_stogir.525
    dd8c:      	bl	0xdd8c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xd8>
		000000000000dd8c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    dd90:      	b	0xdd90 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xdc>
    dd94:      	brk	#0
    dd98:      	b	0xdd94 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.cfg.Edge+0xe0>

000000000000dd9c <_inherent$coil.arraylist.ArrayList$reserve!__bool>:
    dd9c:      	sub	sp, sp, #0x50
    dda0:      	str	x29, [sp]
    dda4:      	str	x30, [sp, #0x8]
    dda8:      	mov	x29, sp
    ddac:      	str	x19, [sp, #0x40]
    ddb0:      	str	x20, [sp, #0x48]
    ddb4:      	add	x2, x0, #0x18
    ddb8:      	ldr	x3, [x0, #0x10]
    ddbc:      	ldr	x4, [x0, #0x18]
    ddc0:      	ldr	x2, [x2, #0x8]
    ddc4:      	add	x16, sp, #0x10
    ddc8:      	str	x4, [x16]
    ddcc:      	add	x16, sp, #0x10
    ddd0:      	str	x2, [x16, #0x8]
    ddd4:      	cmp	x1, x3
    ddd8:      	b.le	0xde48 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xac>
    dddc:      	ldr	x2, [x0]
    dde0:      	add	x8, sp, #0x20
    dde4:      	mov	x19, x0
    dde8:      	add	x0, sp, #0x10
    ddec:      	mov	x20, x1
    ddf0:      	fmov	d31, x1
    ddf4:      	mov	x1, x2
    ddf8:      	mov	x2, x3
    ddfc:      	fmov	x3, d31
    de00:      	bl	0xde00 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x64>
		000000000000de00:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__bool
    de04:      	add	x16, sp, #0x20
    de08:      	ldr	w0, [x16]
    de0c:      	lsr	x16, x0, #0
    de10:      	cmp	x16, #0x1
    de14:      	b.eq	0xde30 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x94>
    de18:      	b.lo	0xde20 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x84>
    de1c:      	b	0xde34 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x98>
    de20:      	cmp	x16, #0x0
    de24:      	b.eq	0xde2c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x90>
    de28:      	b	0xde34 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x98>
    de2c:      	b	0xde64 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xc8>
    de30:      	b	0xde38 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0x9c>
    de34:      	b	0xde7c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe0>
    de38:      	add	x16, sp, #0x20
    de3c:      	ldr	x0, [x16, #0x8]
    de40:      	str	x0, [x19]
    de44:      	str	x20, [x19, #0x10]
    de48:      	movz	x0, #0x0, lsl #48
    de4c:      	ldr	x19, [sp, #0x40]
    de50:      	ldr	x20, [sp, #0x48]
    de54:      	ldr	x29, [sp]
    de58:      	ldr	x30, [sp, #0x8]
    de5c:      	add	sp, sp, #0x50
    de60:      	ret
    de64:      	lsr	x0, x20, #0
    de68:      	mov	x1, x0
    de6c:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000de6c:  ARM64_RELOC_PAGE21	l_stogir.526
    de70:      	ldr	x0, [x0]
		000000000000de70:  ARM64_RELOC_PAGEOFF12	l_stogir.526
    de74:      	bl	0xde74 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xd8>
		000000000000de74:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    de78:      	b	0xde78 <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xdc>
    de7c:      	brk	#0
    de80:      	b	0xde7c <_inherent$coil.arraylist.ArrayList$reserve!__bool+0xe0>

000000000000de84 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame>:
    de84:      	sub	sp, sp, #0x50
    de88:      	str	x29, [sp]
    de8c:      	str	x30, [sp, #0x8]
    de90:      	mov	x29, sp
    de94:      	str	x19, [sp, #0x40]
    de98:      	str	x20, [sp, #0x48]
    de9c:      	add	x2, x0, #0x18
    dea0:      	ldr	x3, [x0, #0x10]
    dea4:      	ldr	x4, [x0, #0x18]
    dea8:      	ldr	x2, [x2, #0x8]
    deac:      	add	x16, sp, #0x10
    deb0:      	str	x4, [x16]
    deb4:      	add	x16, sp, #0x10
    deb8:      	str	x2, [x16, #0x8]
    debc:      	cmp	x1, x3
    dec0:      	b.le	0xdf30 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xac>
    dec4:      	ldr	x2, [x0]
    dec8:      	add	x8, sp, #0x20
    decc:      	mov	x19, x0
    ded0:      	add	x0, sp, #0x10
    ded4:      	mov	x20, x1
    ded8:      	fmov	d31, x1
    dedc:      	mov	x1, x2
    dee0:      	mov	x2, x3
    dee4:      	fmov	x3, d31
    dee8:      	bl	0xdee8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x64>
		000000000000dee8:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Frame
    deec:      	add	x16, sp, #0x20
    def0:      	ldr	w0, [x16]
    def4:      	lsr	x16, x0, #0
    def8:      	cmp	x16, #0x1
    defc:      	b.eq	0xdf18 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x94>
    df00:      	b.lo	0xdf08 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x84>
    df04:      	b	0xdf1c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x98>
    df08:      	cmp	x16, #0x0
    df0c:      	b.eq	0xdf14 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x90>
    df10:      	b	0xdf1c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x98>
    df14:      	b	0xdf4c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xc8>
    df18:      	b	0xdf20 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0x9c>
    df1c:      	b	0xdf64 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe0>
    df20:      	add	x16, sp, #0x20
    df24:      	ldr	x0, [x16, #0x8]
    df28:      	str	x0, [x19]
    df2c:      	str	x20, [x19, #0x10]
    df30:      	movz	x0, #0x0, lsl #48
    df34:      	ldr	x19, [sp, #0x40]
    df38:      	ldr	x20, [sp, #0x48]
    df3c:      	ldr	x29, [sp]
    df40:      	ldr	x30, [sp, #0x8]
    df44:      	add	sp, sp, #0x50
    df48:      	ret
    df4c:      	lsl	x0, x20, #4
    df50:      	mov	x1, x0
    df54:      	adrp	x0, 0xd000 <_stogir.checked-schedule.validate-nodes+0x124>
		000000000000df54:  ARM64_RELOC_PAGE21	l_stogir.527
    df58:      	ldr	x0, [x0]
		000000000000df58:  ARM64_RELOC_PAGEOFF12	l_stogir.527
    df5c:      	bl	0xdf5c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xd8>
		000000000000df5c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    df60:      	b	0xdf60 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xdc>
    df64:      	brk	#0
    df68:      	b	0xdf64 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Frame+0xe0>

000000000000df6c <_inherent$coil.arraylist.ArrayList$reserve!__i64>:
    df6c:      	sub	sp, sp, #0x50
    df70:      	str	x29, [sp]
    df74:      	str	x30, [sp, #0x8]
    df78:      	mov	x29, sp
    df7c:      	str	x19, [sp, #0x40]
    df80:      	str	x20, [sp, #0x48]
    df84:      	add	x2, x0, #0x18
    df88:      	ldr	x3, [x0, #0x10]
    df8c:      	ldr	x4, [x0, #0x18]
    df90:      	ldr	x2, [x2, #0x8]
    df94:      	add	x16, sp, #0x10
    df98:      	str	x4, [x16]
    df9c:      	add	x16, sp, #0x10
    dfa0:      	str	x2, [x16, #0x8]
    dfa4:      	cmp	x1, x3
    dfa8:      	b.le	0xe018 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xac>
    dfac:      	ldr	x2, [x0]
    dfb0:      	add	x8, sp, #0x20
    dfb4:      	mov	x19, x0
    dfb8:      	add	x0, sp, #0x10
    dfbc:      	mov	x20, x1
    dfc0:      	fmov	d31, x1
    dfc4:      	mov	x1, x2
    dfc8:      	mov	x2, x3
    dfcc:      	fmov	x3, d31
    dfd0:      	bl	0xdfd0 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x64>
		000000000000dfd0:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__i64
    dfd4:      	add	x16, sp, #0x20
    dfd8:      	ldr	w0, [x16]
    dfdc:      	lsr	x16, x0, #0
    dfe0:      	cmp	x16, #0x1
    dfe4:      	b.eq	0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
    dfe8:      	b.lo	0xdff0 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x84>
    dfec:      	b	0xe004 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x98>
    dff0:      	cmp	x16, #0x0
    dff4:      	b.eq	0xdffc <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x90>
    dff8:      	b	0xe004 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x98>
    dffc:      	b	0xe034 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xc8>
    e000:      	b	0xe008 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x9c>
    e004:      	b	0xe04c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe0>
    e008:      	add	x16, sp, #0x20
    e00c:      	ldr	x0, [x16, #0x8]
    e010:      	str	x0, [x19]
    e014:      	str	x20, [x19, #0x10]
    e018:      	movz	x0, #0x0, lsl #48
    e01c:      	ldr	x19, [sp, #0x40]
    e020:      	ldr	x20, [sp, #0x48]
    e024:      	ldr	x29, [sp]
    e028:      	ldr	x30, [sp, #0x8]
    e02c:      	add	sp, sp, #0x50
    e030:      	ret
    e034:      	lsl	x0, x20, #3
    e038:      	mov	x1, x0
    e03c:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e03c:  ARM64_RELOC_PAGE21	l_stogir.528
    e040:      	ldr	x0, [x0]
		000000000000e040:  ARM64_RELOC_PAGEOFF12	l_stogir.528
    e044:      	bl	0xe044 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xd8>
		000000000000e044:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e048:      	b	0xe048 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xdc>
    e04c:      	brk	#0
    e050:      	b	0xe04c <_inherent$coil.arraylist.ArrayList$reserve!__i64+0xe0>

000000000000e054 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range>:
    e054:      	sub	sp, sp, #0x50
    e058:      	str	x29, [sp]
    e05c:      	str	x30, [sp, #0x8]
    e060:      	mov	x29, sp
    e064:      	str	x19, [sp, #0x40]
    e068:      	str	x20, [sp, #0x48]
    e06c:      	add	x2, x0, #0x18
    e070:      	ldr	x3, [x0, #0x10]
    e074:      	ldr	x4, [x0, #0x18]
    e078:      	ldr	x2, [x2, #0x8]
    e07c:      	add	x16, sp, #0x10
    e080:      	str	x4, [x16]
    e084:      	add	x16, sp, #0x10
    e088:      	str	x2, [x16, #0x8]
    e08c:      	cmp	x1, x3
    e090:      	b.le	0xe100 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xac>
    e094:      	ldr	x2, [x0]
    e098:      	add	x8, sp, #0x20
    e09c:      	mov	x19, x0
    e0a0:      	add	x0, sp, #0x10
    e0a4:      	mov	x20, x1
    e0a8:      	fmov	d31, x1
    e0ac:      	mov	x1, x2
    e0b0:      	mov	x2, x3
    e0b4:      	fmov	x3, d31
    e0b8:      	bl	0xe0b8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x64>
		000000000000e0b8:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Range
    e0bc:      	add	x16, sp, #0x20
    e0c0:      	ldr	w0, [x16]
    e0c4:      	lsr	x16, x0, #0
    e0c8:      	cmp	x16, #0x1
    e0cc:      	b.eq	0xe0e8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x94>
    e0d0:      	b.lo	0xe0d8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x84>
    e0d4:      	b	0xe0ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x98>
    e0d8:      	cmp	x16, #0x0
    e0dc:      	b.eq	0xe0e4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x90>
    e0e0:      	b	0xe0ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x98>
    e0e4:      	b	0xe11c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xc8>
    e0e8:      	b	0xe0f0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0x9c>
    e0ec:      	b	0xe134 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe0>
    e0f0:      	add	x16, sp, #0x20
    e0f4:      	ldr	x0, [x16, #0x8]
    e0f8:      	str	x0, [x19]
    e0fc:      	str	x20, [x19, #0x10]
    e100:      	movz	x0, #0x0, lsl #48
    e104:      	ldr	x19, [sp, #0x40]
    e108:      	ldr	x20, [sp, #0x48]
    e10c:      	ldr	x29, [sp]
    e110:      	ldr	x30, [sp, #0x8]
    e114:      	add	sp, sp, #0x50
    e118:      	ret
    e11c:      	lsl	x0, x20, #4
    e120:      	mov	x1, x0
    e124:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e124:  ARM64_RELOC_PAGE21	l_stogir.529
    e128:      	ldr	x0, [x0]
		000000000000e128:  ARM64_RELOC_PAGEOFF12	l_stogir.529
    e12c:      	bl	0xe12c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xd8>
		000000000000e12c:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e130:      	b	0xe130 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xdc>
    e134:      	brk	#0
    e138:      	b	0xe134 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Range+0xe0>

000000000000e13c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use>:
    e13c:      	sub	sp, sp, #0x50
    e140:      	str	x29, [sp]
    e144:      	str	x30, [sp, #0x8]
    e148:      	mov	x29, sp
    e14c:      	str	x19, [sp, #0x40]
    e150:      	str	x20, [sp, #0x48]
    e154:      	add	x2, x0, #0x18
    e158:      	ldr	x3, [x0, #0x10]
    e15c:      	ldr	x4, [x0, #0x18]
    e160:      	ldr	x2, [x2, #0x8]
    e164:      	add	x16, sp, #0x10
    e168:      	str	x4, [x16]
    e16c:      	add	x16, sp, #0x10
    e170:      	str	x2, [x16, #0x8]
    e174:      	cmp	x1, x3
    e178:      	b.le	0xe1e8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xac>
    e17c:      	ldr	x2, [x0]
    e180:      	add	x8, sp, #0x20
    e184:      	mov	x19, x0
    e188:      	add	x0, sp, #0x10
    e18c:      	mov	x20, x1
    e190:      	fmov	d31, x1
    e194:      	mov	x1, x2
    e198:      	mov	x2, x3
    e19c:      	fmov	x3, d31
    e1a0:      	bl	0xe1a0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x64>
		000000000000e1a0:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.uses.Use
    e1a4:      	add	x16, sp, #0x20
    e1a8:      	ldr	w0, [x16]
    e1ac:      	lsr	x16, x0, #0
    e1b0:      	cmp	x16, #0x1
    e1b4:      	b.eq	0xe1d0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x94>
    e1b8:      	b.lo	0xe1c0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x84>
    e1bc:      	b	0xe1d4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x98>
    e1c0:      	cmp	x16, #0x0
    e1c4:      	b.eq	0xe1cc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x90>
    e1c8:      	b	0xe1d4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x98>
    e1cc:      	b	0xe204 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xc8>
    e1d0:      	b	0xe1d8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0x9c>
    e1d4:      	b	0xe21c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe0>
    e1d8:      	add	x16, sp, #0x20
    e1dc:      	ldr	x0, [x16, #0x8]
    e1e0:      	str	x0, [x19]
    e1e4:      	str	x20, [x19, #0x10]
    e1e8:      	movz	x0, #0x0, lsl #48
    e1ec:      	ldr	x19, [sp, #0x40]
    e1f0:      	ldr	x20, [sp, #0x48]
    e1f4:      	ldr	x29, [sp]
    e1f8:      	ldr	x30, [sp, #0x8]
    e1fc:      	add	sp, sp, #0x50
    e200:      	ret
    e204:      	lsl	x0, x20, #3
    e208:      	mov	x1, x0
    e20c:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e20c:  ARM64_RELOC_PAGE21	l_stogir.530
    e210:      	ldr	x0, [x0]
		000000000000e210:  ARM64_RELOC_PAGEOFF12	l_stogir.530
    e214:      	bl	0xe214 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xd8>
		000000000000e214:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e218:      	b	0xe218 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xdc>
    e21c:      	brk	#0
    e220:      	b	0xe21c <_inherent$coil.arraylist.ArrayList$reserve!__stogir.uses.Use+0xe0>

000000000000e224 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range>:
    e224:      	sub	sp, sp, #0x50
    e228:      	str	x29, [sp]
    e22c:      	str	x30, [sp, #0x8]
    e230:      	mov	x29, sp
    e234:      	str	x19, [sp, #0x40]
    e238:      	str	x20, [sp, #0x48]
    e23c:      	add	x2, x0, #0x18
    e240:      	ldr	x3, [x0, #0x10]
    e244:      	ldr	x4, [x0, #0x18]
    e248:      	ldr	x2, [x2, #0x8]
    e24c:      	add	x16, sp, #0x10
    e250:      	str	x4, [x16]
    e254:      	add	x16, sp, #0x10
    e258:      	str	x2, [x16, #0x8]
    e25c:      	cmp	x1, x3
    e260:      	b.le	0xe2d0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xac>
    e264:      	ldr	x2, [x0]
    e268:      	add	x8, sp, #0x20
    e26c:      	mov	x19, x0
    e270:      	add	x0, sp, #0x10
    e274:      	mov	x20, x1
    e278:      	fmov	d31, x1
    e27c:      	mov	x1, x2
    e280:      	mov	x2, x3
    e284:      	fmov	x3, d31
    e288:      	bl	0xe288 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x64>
		000000000000e288:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.schedule.Range
    e28c:      	add	x16, sp, #0x20
    e290:      	ldr	w0, [x16]
    e294:      	lsr	x16, x0, #0
    e298:      	cmp	x16, #0x1
    e29c:      	b.eq	0xe2b8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x94>
    e2a0:      	b.lo	0xe2a8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x84>
    e2a4:      	b	0xe2bc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x98>
    e2a8:      	cmp	x16, #0x0
    e2ac:      	b.eq	0xe2b4 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x90>
    e2b0:      	b	0xe2bc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x98>
    e2b4:      	b	0xe2ec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xc8>
    e2b8:      	b	0xe2c0 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0x9c>
    e2bc:      	b	0xe304 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe0>
    e2c0:      	add	x16, sp, #0x20
    e2c4:      	ldr	x0, [x16, #0x8]
    e2c8:      	str	x0, [x19]
    e2cc:      	str	x20, [x19, #0x10]
    e2d0:      	movz	x0, #0x0, lsl #48
    e2d4:      	ldr	x19, [sp, #0x40]
    e2d8:      	ldr	x20, [sp, #0x48]
    e2dc:      	ldr	x29, [sp]
    e2e0:      	ldr	x30, [sp, #0x8]
    e2e4:      	add	sp, sp, #0x50
    e2e8:      	ret
    e2ec:      	lsl	x0, x20, #4
    e2f0:      	mov	x1, x0
    e2f4:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e2f4:  ARM64_RELOC_PAGE21	l_stogir.531
    e2f8:      	ldr	x0, [x0]
		000000000000e2f8:  ARM64_RELOC_PAGEOFF12	l_stogir.531
    e2fc:      	bl	0xe2fc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xd8>
		000000000000e2fc:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    e300:      	b	0xe300 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xdc>
    e304:      	brk	#0
    e308:      	b	0xe304 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.schedule.Range+0xe0>

000000000000e30c <_stogir.checked.validate>:
    e30c:      	sub	sp, sp, #0x20
    e310:      	str	x29, [sp]
    e314:      	str	x30, [sp, #0x8]
    e318:      	mov	x29, sp
    e31c:      	str	x19, [sp, #0x10]
    e320:      	sxtw	x1, w1
    e324:      	add	x2, x0, #0x78
    e328:      	add	x3, x0, #0x28
    e32c:      	add	x4, x0, #0x50
    e330:      	lsl	x5, x1, #2
    e334:      	cmp	x1, #0x0
    e338:      	cset	w6, gt
    e33c:      	movz	x16, #0x0, lsl #48
    e340:      	sub	x7, x16, x1
    e344:      	sub	x9, x7, #0x1
    e348:      	uxtb	w16, w6
    e34c:      	cmp	w16, wzr
    e350:      	b.eq	0xe38c <_stogir.checked.validate+0x80>
    e354:      	ldr	x7, [x0, #0x8]
    e358:      	cmp	x1, x7
    e35c:      	b.ge	0xe3d4 <_stogir.checked.validate+0xc8>
    e360:      	ldr	x7, [x2, #0x8]
    e364:      	cmp	x1, x7
    e368:      	b.ge	0xe520 <_stogir.checked.validate+0x214>
    e36c:      	ldr	x7, [x0, #0x78]
    e370:      	add	x7, x5, x7
    e374:      	ldr	w7, [x7]
    e378:      	sxtw	x7, w7
    e37c:      	cmp	x7, #0x0
    e380:      	cset	w7, ge
    e384:      	ubfx	x7, x7, #0, #8
    e388:      	b	0xe524 <_stogir.checked.validate+0x218>
    e38c:      	cmp	x1, #0x0
    e390:      	b.ge	0xe3dc <_stogir.checked.validate+0xd0>
    e394:      	ldr	x10, [x3, #0x8]
    e398:      	ldr	x11, [x4, #0x8]
    e39c:      	cmp	x10, x11
    e3a0:      	b.ne	0xe3cc <_stogir.checked.validate+0xc0>
    e3a4:      	cmp	x7, x10
    e3a8:      	b.gt	0xe528 <_stogir.checked.validate+0x21c>
    e3ac:      	ldr	x7, [x0, #0x50]
    e3b0:      	add	x7, x7, x9, lsl #2
    e3b4:      	ldr	w7, [x7]
    e3b8:      	sxtw	x7, w7
    e3bc:      	cmp	x7, #0x0
    e3c0:      	cset	w7, gt
    e3c4:      	ubfx	x7, x7, #0, #8
    e3c8:      	b	0xe52c <_stogir.checked.validate+0x220>
    e3cc:      	movz	x7, #0x0, lsl #48
    e3d0:      	b	0xe3e0 <_stogir.checked.validate+0xd4>
    e3d4:      	movz	x7, #0x0, lsl #48
    e3d8:      	b	0xe3e0 <_stogir.checked.validate+0xd4>
    e3dc:      	movz	x7, #0x0, lsl #48
    e3e0:      	cmp	x7, #0x0
    e3e4:      	b.eq	0xe420 <_stogir.checked.validate+0x114>
    e3e8:      	uxtb	w16, w6
    e3ec:      	cmp	w16, wzr
    e3f0:      	b.eq	0xe408 <_stogir.checked.validate+0xfc>
    e3f4:      	ldr	x6, [x0]
    e3f8:      	add	x6, x6, x1, lsl #4
    e3fc:      	ldr	x7, [x6]
    e400:      	ldr	x6, [x6, #0x8]
    e404:      	b	0xe418 <_stogir.checked.validate+0x10c>
    e408:      	ldr	x6, [x0, #0x28]
    e40c:      	add	x6, x6, x9, lsl #4
    e410:      	ldr	x7, [x6]
    e414:      	ldr	x6, [x6, #0x8]
    e418:      	mov	w9, #0x1                ; =1
    e41c:      	b	0xe42c <_stogir.checked.validate+0x120>
    e420:      	movz	w9, #0x0, lsl #16
    e424:      	movz	x7, #0x0, lsl #48
    e428:      	movz	x6, #0x0, lsl #48
    e42c:      	ubfx	x9, x9, #0, #32
    e430:      	lsr	x16, x9, #0
    e434:      	cmp	x16, #0x1
    e438:      	b.eq	0xe454 <_stogir.checked.validate+0x148>
    e43c:      	b.lo	0xe444 <_stogir.checked.validate+0x138>
    e440:      	b	0xe458 <_stogir.checked.validate+0x14c>
    e444:      	cmp	x16, #0x0
    e448:      	b.eq	0xe450 <_stogir.checked.validate+0x144>
    e44c:      	b	0xe458 <_stogir.checked.validate+0x14c>
    e450:      	b	0xe45c <_stogir.checked.validate+0x150>
    e454:      	b	0xe4a4 <_stogir.checked.validate+0x198>
    e458:      	b	0xe734 <_stogir.checked.validate+0x428>
    e45c:      	mov	x0, #0x1                ; =1
    e460:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e460:  ARM64_RELOC_PAGE21	l_stogir.532
    e464:      	ldr	x11, [x11]
		000000000000e464:  ARM64_RELOC_PAGEOFF12	l_stogir.532
    e468:      	mov	x12, #0x1a              ; =26
    e46c:      	b	0xe480 <_stogir.checked.validate+0x174>
    e470:      	mov	x0, #0x1                ; =1
    e474:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e474:  ARM64_RELOC_PAGE21	l_stogir.533
    e478:      	ldr	x11, [x11]
		000000000000e478:  ARM64_RELOC_PAGEOFF12	l_stogir.533
    e47c:      	mov	x12, #0x26              ; =38
    e480:      	str	x0, [x8]
    e484:      	str	x11, [x8, #0x8]
    e488:      	str	x12, [x8, #0x10]
    e48c:      	sub	sp, x29, #0x0
    e490:      	ldr	x19, [sp, #0x10]
    e494:      	ldr	x29, [sp]
    e498:      	ldr	x30, [sp, #0x8]
    e49c:      	add	sp, sp, #0x20
    e4a0:      	ret
    e4a4:      	cmp	x1, #0x0
    e4a8:      	b.le	0xe470 <_stogir.checked.validate+0x164>
    e4ac:      	uxtb	w1, w7
    e4b0:      	cmp	x1, #0x29
    e4b4:      	b.lt	0xe470 <_stogir.checked.validate+0x164>
    e4b8:      	cmp	x1, #0x2b
    e4bc:      	b.gt	0xe470 <_stogir.checked.validate+0x164>
    e4c0:      	ldr	x1, [x0, #0x78]
    e4c4:      	add	x1, x5, x1
    e4c8:      	ldr	w1, [x1]
    e4cc:      	sxtw	x1, w1
    e4d0:      	cmp	x1, #0x2
    e4d4:      	b.ne	0xe470 <_stogir.checked.validate+0x164>
    e4d8:      	orr	w1, w7, wzr
    e4dc:      	mov	x5, sp
    e4e0:      	ubfx	x1, x1, #0, #32
    e4e4:      	sub	sp, sp, #0x10
    e4e8:      	mov	x9, sp
    e4ec:      	sub	sp, sp, #0x10
    e4f0:      	mov	x10, sp
    e4f4:      	ubfx	x1, x1, #8, #8
    e4f8:      	cmp	x1, #0x1
    e4fc:      	b.lt	0xe6f8 <_stogir.checked.validate+0x3ec>
    e500:      	cmp	x1, #0xb
    e504:      	b.gt	0xe6f8 <_stogir.checked.validate+0x3ec>
    e508:      	cmp	x1, #0x1
    e50c:      	b.eq	0xe6f8 <_stogir.checked.validate+0x3ec>
    e510:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e510:  ARM64_RELOC_PAGE21	l_stogir.534
    e514:      	ldr	x11, [x11]
		000000000000e514:  ARM64_RELOC_PAGEOFF12	l_stogir.534
    e518:      	movz	x12, #0x0, lsl #48
    e51c:      	b	0xe704 <_stogir.checked.validate+0x3f8>
    e520:      	movz	x7, #0x0, lsl #48
    e524:      	b	0xe3d8 <_stogir.checked.validate+0xcc>
    e528:      	movz	x7, #0x0, lsl #48
    e52c:      	b	0xe3d0 <_stogir.checked.validate+0xc4>
    e530:      	mov	x0, #0x1                ; =1
    e534:      	mov	sp, x5
    e538:      	b	0xe480 <_stogir.checked.validate+0x174>
    e53c:      	movz	w9, #0x0, lsl #16
    e540:      	movz	x7, #0x0, lsl #48
    e544:      	ubfx	x9, x9, #0, #32
    e548:      	lsr	x16, x9, #0
    e54c:      	cmp	x16, #0x1
    e550:      	b.eq	0xe56c <_stogir.checked.validate+0x260>
    e554:      	b.lo	0xe55c <_stogir.checked.validate+0x250>
    e558:      	b	0xe570 <_stogir.checked.validate+0x264>
    e55c:      	cmp	x16, #0x0
    e560:      	b.eq	0xe568 <_stogir.checked.validate+0x25c>
    e564:      	b	0xe570 <_stogir.checked.validate+0x264>
    e568:      	b	0xe574 <_stogir.checked.validate+0x268>
    e56c:      	b	0xe6d8 <_stogir.checked.validate+0x3cc>
    e570:      	b	0xe74c <_stogir.checked.validate+0x440>
    e574:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e574:  ARM64_RELOC_PAGE21	l_stogir.535
    e578:      	ldr	x11, [x11]
		000000000000e578:  ARM64_RELOC_PAGEOFF12	l_stogir.535
    e57c:      	mov	x12, #0x22              ; =34
    e580:      	cmp	x6, #0x2
    e584:      	b.ge	0xe5a8 <_stogir.checked.validate+0x29c>
    e588:      	add	x7, x6, #0x1
    e58c:      	add	x6, x13, x6, lsl #2
    e590:      	ldr	w6, [x6]
    e594:      	movn	w17, #0x0, lsl #16
    e598:      	and	w9, w6, w17
    e59c:      	mov	x6, x7
    e5a0:      	mov	w7, #0x1                ; =1
    e5a4:      	b	0xe5b0 <_stogir.checked.validate+0x2a4>
    e5a8:      	movz	w7, #0x0, lsl #16
    e5ac:      	movz	w9, #0x0, lsl #16
    e5b0:      	ubfx	x7, x7, #0, #32
    e5b4:      	lsr	x16, x7, #0
    e5b8:      	cmp	x16, #0x1
    e5bc:      	b.eq	0xe5d8 <_stogir.checked.validate+0x2cc>
    e5c0:      	b.lo	0xe5c8 <_stogir.checked.validate+0x2bc>
    e5c4:      	b	0xe5dc <_stogir.checked.validate+0x2d0>
    e5c8:      	cmp	x16, #0x0
    e5cc:      	b.eq	0xe5d4 <_stogir.checked.validate+0x2c8>
    e5d0:      	b	0xe5dc <_stogir.checked.validate+0x2d0>
    e5d4:      	b	0xe63c <_stogir.checked.validate+0x330>
    e5d8:      	b	0xe5e0 <_stogir.checked.validate+0x2d4>
    e5dc:      	b	0xe744 <_stogir.checked.validate+0x438>
    e5e0:      	sxtw	x9, w9
    e5e4:      	cmp	x9, #0x0
    e5e8:      	cset	w7, gt
    e5ec:      	movz	x16, #0x0, lsl #48
    e5f0:      	sub	x10, x16, x9
    e5f4:      	sub	x14, x10, #0x1
    e5f8:      	uxtb	w16, w7
    e5fc:      	cmp	w16, wzr
    e600:      	b.eq	0xe698 <_stogir.checked.validate+0x38c>
    e604:      	ldr	x10, [x0, #0x8]
    e608:      	cmp	x9, x10
    e60c:      	b.ge	0xe690 <_stogir.checked.validate+0x384>
    e610:      	ldr	x10, [x2, #0x8]
    e614:      	cmp	x9, x10
    e618:      	b.ge	0xe72c <_stogir.checked.validate+0x420>
    e61c:      	ldr	x10, [x0, #0x78]
    e620:      	add	x10, x10, x9, lsl #2
    e624:      	ldr	w10, [x10]
    e628:      	sxtw	x10, w10
    e62c:      	cmp	x10, #0x0
    e630:      	cset	w10, ge
    e634:      	ubfx	x10, x10, #0, #8
    e638:      	b	0xe730 <_stogir.checked.validate+0x424>
    e63c:      	cmp	x12, #0x0
    e640:      	b.ne	0xe530 <_stogir.checked.validate+0x224>
    e644:      	and	x11, x1, #0xffffffff
    e648:      	movz	x0, #0x0, lsl #48
    e64c:      	movz	x12, #0x0, lsl #48
    e650:      	b	0xe534 <_stogir.checked.validate+0x228>
    e654:      	ldr	x7, [x0, #0x28]
    e658:      	add	x7, x7, x14, lsl #4
    e65c:      	ldr	x7, [x7]
    e660:      	mov	w9, #0x1                ; =1
    e664:      	b	0xe544 <_stogir.checked.validate+0x238>
    e668:      	movz	x10, #0x0, lsl #48
    e66c:      	cmp	x10, #0x0
    e670:      	b.eq	0xe53c <_stogir.checked.validate+0x230>
    e674:      	uxtb	w16, w7
    e678:      	cmp	w16, wzr
    e67c:      	b.eq	0xe654 <_stogir.checked.validate+0x348>
    e680:      	ldr	x7, [x0]
    e684:      	add	x7, x7, x9, lsl #4
    e688:      	ldr	x7, [x7]
    e68c:      	b	0xe660 <_stogir.checked.validate+0x354>
    e690:      	movz	x10, #0x0, lsl #48
    e694:      	b	0xe66c <_stogir.checked.validate+0x360>
    e698:      	cmp	x9, #0x0
    e69c:      	b.ge	0xe668 <_stogir.checked.validate+0x35c>
    e6a0:      	ldr	x15, [x3, #0x8]
    e6a4:      	ldr	x19, [x4, #0x8]
    e6a8:      	cmp	x15, x19
    e6ac:      	b.ne	0xe724 <_stogir.checked.validate+0x418>
    e6b0:      	cmp	x10, x15
    e6b4:      	b.gt	0xe73c <_stogir.checked.validate+0x430>
    e6b8:      	ldr	x10, [x0, #0x50]
    e6bc:      	add	x10, x10, x14, lsl #2
    e6c0:      	ldr	w10, [x10]
    e6c4:      	sxtw	x10, w10
    e6c8:      	cmp	x10, #0x0
    e6cc:      	cset	w10, gt
    e6d0:      	ubfx	x10, x10, #0, #8
    e6d4:      	b	0xe740 <_stogir.checked.validate+0x434>
    e6d8:      	ubfx	x7, x7, #0, #32
    e6dc:      	ubfx	x7, x7, #8, #8
    e6e0:      	cmp	x7, x1
    e6e4:      	b.eq	0xe6f4 <_stogir.checked.validate+0x3e8>
    e6e8:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e6e8:  ARM64_RELOC_PAGE21	l_stogir.536
    e6ec:      	ldr	x11, [x11]
		000000000000e6ec:  ARM64_RELOC_PAGEOFF12	l_stogir.536
    e6f0:      	mov	x12, #0x28              ; =40
    e6f4:      	b	0xe580 <_stogir.checked.validate+0x274>
    e6f8:      	adrp	x11, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e6f8:  ARM64_RELOC_PAGE21	l_stogir.537
    e6fc:      	ldr	x11, [x11]
		000000000000e6fc:  ARM64_RELOC_PAGEOFF12	l_stogir.537
    e700:      	mov	x12, #0x36              ; =54
    e704:      	orr	x13, x10, xzr
    e708:      	lsr	x7, x7, #32
    e70c:      	str	w7, [x9]
    e710:      	str	w6, [x9, #0x4]
    e714:      	ldr	x6, [x9]
    e718:      	str	x6, [x10]
    e71c:      	movz	x6, #0x0, lsl #48
    e720:      	b	0xe580 <_stogir.checked.validate+0x274>
    e724:      	movz	x10, #0x0, lsl #48
    e728:      	b	0xe66c <_stogir.checked.validate+0x360>
    e72c:      	movz	x10, #0x0, lsl #48
    e730:      	b	0xe694 <_stogir.checked.validate+0x388>
    e734:      	brk	#0
    e738:      	b	0xe734 <_stogir.checked.validate+0x428>
    e73c:      	movz	x10, #0x0, lsl #48
    e740:      	b	0xe728 <_stogir.checked.validate+0x41c>
    e744:      	brk	#0
    e748:      	b	0xe744 <_stogir.checked.validate+0x438>
    e74c:      	brk	#0
    e750:      	b	0xe74c <_stogir.checked.validate+0x440>

000000000000e754 <_coil.alloc.sized-request>:
    e754:      	cmp	x3, #0x0
    e758:      	b.le	0xe780 <_coil.alloc.sized-request+0x2c>
    e75c:      	cmp	x1, #0x0
    e760:      	b.le	0xe780 <_coil.alloc.sized-request+0x2c>
    e764:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    e768:      	sdiv	x4, x16, x1
    e76c:      	cmp	x3, x4
    e770:      	b.gt	0xe780 <_coil.alloc.sized-request+0x2c>
    e774:      	mul	x1, x3, x1
    e778:      	mov	x4, #0x1                ; =1
    e77c:      	b	0xe794 <_coil.alloc.sized-request+0x40>
    e780:      	movz	x4, #0x0, lsl #48
    e784:      	movz	x0, #0x0, lsl #48
    e788:      	movz	x3, #0x0, lsl #48
    e78c:      	movz	x1, #0x0, lsl #48
    e790:      	movz	x2, #0x0, lsl #48
    e794:      	str	x4, [x8]
    e798:      	str	x0, [x8, #0x8]
    e79c:      	str	x3, [x8, #0x10]
    e7a0:      	str	x1, [x8, #0x18]
    e7a4:      	str	x2, [x8, #0x20]
    e7a8:      	ret

000000000000e7ac <_coil.alloc.raw-free>:
    e7ac:      	sub	sp, sp, #0x10
    e7b0:      	str	x29, [sp]
    e7b4:      	str	x30, [sp, #0x8]
    e7b8:      	mov	x29, sp
    e7bc:      	ldr	x3, [x2, #0x8]
    e7c0:      	cmp	x3, #0x0
    e7c4:      	b.le	0xe80c <_coil.alloc.raw-free+0x60>
    e7c8:      	ldr	x3, [x2, #0x10]
    e7cc:      	cmp	x3, #0x0
    e7d0:      	b.le	0xe80c <_coil.alloc.raw-free+0x60>
    e7d4:      	ldr	x3, [x2, #0x18]
    e7d8:      	cmp	x3, #0x0
    e7dc:      	b.le	0xe80c <_coil.alloc.raw-free+0x60>
    e7e0:      	sub	x4, x3, #0x1
    e7e4:      	and	x3, x4, x3
    e7e8:      	cmp	x3, #0x0
    e7ec:      	b.ne	0xe80c <_coil.alloc.raw-free+0x60>
    e7f0:      	ldr	x3, [x0]
    e7f4:      	ldr	x0, [x0, #0x8]
    e7f8:      	ldr	x0, [x0, #0x18]
    e7fc:      	mov	x30, x0
    e800:      	mov	x0, x3
    e804:      	blr	x30
    e808:      	b	0xe810 <_coil.alloc.raw-free+0x64>
    e80c:      	movz	x0, #0x0, lsl #48
    e810:      	ldr	x29, [sp]
    e814:      	ldr	x30, [sp, #0x8]
    e818:      	add	sp, sp, #0x10
    e81c:      	ret

000000000000e820 <_coil.alloc.reallocate__i32>:
    e820:      	sub	sp, sp, #0x40
    e824:      	str	x29, [sp, #0x10]
    e828:      	str	x30, [sp, #0x18]
    e82c:      	add	x29, sp, #0x10
    e830:      	str	x19, [sp, #0x30]
    e834:      	str	x20, [sp, #0x38]
    e838:      	mov	x19, x8
    e83c:      	mov	x20, x3
    e840:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e840:  ARM64_RELOC_PAGE21	l_stogir.538
    e844:      	ldr	x4, [x4]
		000000000000e844:  ARM64_RELOC_PAGEOFF12	l_stogir.538
    e848:      	mov	x5, #0x4                ; =4
    e84c:      	mov	x6, #0x4                ; =4
    e850:      	bl	0xe850 <_coil.alloc.reallocate__i32+0x30>
		000000000000e850:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    e854:      	ubfx	x0, x0, #0, #32
    e858:      	lsr	x16, x0, #0
    e85c:      	cmp	x16, #0x1
    e860:      	b.eq	0xe87c <_coil.alloc.reallocate__i32+0x5c>
    e864:      	b.lo	0xe86c <_coil.alloc.reallocate__i32+0x4c>
    e868:      	b	0xe880 <_coil.alloc.reallocate__i32+0x60>
    e86c:      	cmp	x16, #0x0
    e870:      	b.eq	0xe878 <_coil.alloc.reallocate__i32+0x58>
    e874:      	b	0xe880 <_coil.alloc.reallocate__i32+0x60>
    e878:      	b	0xe884 <_coil.alloc.reallocate__i32+0x64>
    e87c:      	b	0xe894 <_coil.alloc.reallocate__i32+0x74>
    e880:      	b	0xe8bc <_coil.alloc.reallocate__i32+0x9c>
    e884:      	movz	x0, #0x0, lsl #48
    e888:      	movz	x1, #0x0, lsl #48
    e88c:      	movz	x20, #0x0, lsl #48
    e890:      	b	0xe898 <_coil.alloc.reallocate__i32+0x78>
    e894:      	mov	x0, #0x1                ; =1
    e898:      	str	x0, [x19]
    e89c:      	str	x1, [x19, #0x8]
    e8a0:      	str	x20, [x19, #0x10]
    e8a4:      	ldr	x19, [sp, #0x30]
    e8a8:      	ldr	x20, [sp, #0x38]
    e8ac:      	ldr	x29, [sp, #0x10]
    e8b0:      	ldr	x30, [sp, #0x18]
    e8b4:      	add	sp, sp, #0x40
    e8b8:      	ret
    e8bc:      	brk	#0
    e8c0:      	b	0xe8bc <_coil.alloc.reallocate__i32+0x9c>
    e8c4:      	udf	#0x0

000000000000e8c8 <_coil.alloc.oom-at>:
    e8c8:      	sub	sp, sp, #0x20
    e8cc:      	str	x29, [sp]
    e8d0:      	str	x30, [sp, #0x8]
    e8d4:      	mov	x29, sp
    e8d8:      	str	x19, [sp, #0x10]
    e8dc:      	str	x20, [sp, #0x18]
    e8e0:      	movz	x2, #0x0, lsl #48
    e8e4:      	b	0xe8ec <_coil.alloc.oom-at+0x24>
    e8e8:      	add	x2, x2, #0x1
    e8ec:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e8ec:  ARM64_RELOC_PAGE21	l_stogir.539
    e8f0:      	ldr	x17, [x17]
		000000000000e8f0:  ARM64_RELOC_PAGEOFF12	l_stogir.539
    e8f4:      	add	x3, x2, x17
    e8f8:      	ldrsb	w3, [x3]
    e8fc:      	sxtb	x3, w3
    e900:      	cmp	x3, #0x0
    e904:      	b.ne	0xe8e8 <_coil.alloc.oom-at+0x20>
    e908:      	mov	x19, x0
    e90c:      	mov	x20, x1
    e910:      	mov	x0, #0x2                ; =2
    e914:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e914:  ARM64_RELOC_PAGE21	l_stogir.539
    e918:      	ldr	x1, [x1]
		000000000000e918:  ARM64_RELOC_PAGEOFF12	l_stogir.539
    e91c:      	bl	0xe91c <_coil.alloc.oom-at+0x54>
		000000000000e91c:  ARM64_RELOC_BRANCH26	_write
    e920:      	movz	x0, #0x0, lsl #48
    e924:      	b	0xe92c <_coil.alloc.oom-at+0x64>
    e928:      	add	x0, x0, #0x1
    e92c:      	add	x1, x0, x19
    e930:      	ldrsb	w1, [x1]
    e934:      	sxtb	x1, w1
    e938:      	cmp	x1, #0x0
    e93c:      	b.ne	0xe928 <_coil.alloc.oom-at+0x60>
    e940:      	mov	x1, x19
    e944:      	mov	x2, x0
    e948:      	mov	x0, #0x2                ; =2
    e94c:      	bl	0xe94c <_coil.alloc.oom-at+0x84>
		000000000000e94c:  ARM64_RELOC_BRANCH26	_write
    e950:      	movz	x0, #0x0, lsl #48
    e954:      	b	0xe95c <_coil.alloc.oom-at+0x94>
    e958:      	add	x0, x0, #0x1
    e95c:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e95c:  ARM64_RELOC_PAGE21	l_stogir.540
    e960:      	ldr	x17, [x17]
		000000000000e960:  ARM64_RELOC_PAGEOFF12	l_stogir.540
    e964:      	add	x1, x0, x17
    e968:      	ldrsb	w1, [x1]
    e96c:      	sxtb	x1, w1
    e970:      	cmp	x1, #0x0
    e974:      	b.ne	0xe958 <_coil.alloc.oom-at+0x90>
    e978:      	mov	x2, x0
    e97c:      	mov	x0, #0x2                ; =2
    e980:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e980:  ARM64_RELOC_PAGE21	l_stogir.540
    e984:      	ldr	x1, [x1]
		000000000000e984:  ARM64_RELOC_PAGEOFF12	l_stogir.540
    e988:      	bl	0xe988 <_coil.alloc.oom-at+0xc0>
		000000000000e988:  ARM64_RELOC_BRANCH26	_write
    e98c:      	cmp	x20, #0x0
    e990:      	b.lt	0xea7c <_coil.alloc.oom-at+0x1b4>
    e994:      	movz	x0, #0x0, lsl #48
    e998:      	b	0xe9a4 <_coil.alloc.oom-at+0xdc>
    e99c:      	nop
    e9a0:      	add	x0, x0, #0x1
    e9a4:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e9a4:  ARM64_RELOC_PAGE21	l_stogir.541
    e9a8:      	ldr	x17, [x17]
		000000000000e9a8:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    e9ac:      	add	x1, x0, x17
    e9b0:      	ldrsb	w1, [x1]
    e9b4:      	sxtb	x1, w1
    e9b8:      	cmp	x1, #0x0
    e9bc:      	b.ne	0xe9a0 <_coil.alloc.oom-at+0xd8>
    e9c0:      	mov	x2, x0
    e9c4:      	mov	x0, #0x2                ; =2
    e9c8:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e9c8:  ARM64_RELOC_PAGE21	l_stogir.541
    e9cc:      	ldr	x1, [x1]
		000000000000e9cc:  ARM64_RELOC_PAGEOFF12	l_stogir.541
    e9d0:      	bl	0xe9d0 <_coil.alloc.oom-at+0x108>
		000000000000e9d0:  ARM64_RELOC_BRANCH26	_write
    e9d4:      	mov	x0, #0x18               ; =24
    e9d8:      	sub	x0, x0, #0x1
    e9dc:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000e9dc:  ARM64_RELOC_PAGE21	l_stogir.542
    e9e0:      	ldr	x17, [x17]
		000000000000e9e0:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    e9e4:      	add	x1, x0, x17
    e9e8:      	mov	x17, #0xa               ; =10
    e9ec:      	sdiv	x16, x20, x17
    e9f0:      	msub	x2, x16, x17, x20
    e9f4:      	mov	x17, #0xa               ; =10
    e9f8:      	sdiv	x3, x20, x17
    e9fc:      	orr	x20, x3, xzr
    ea00:      	add	x2, x2, #0x30
    ea04:      	uxtb	w2, w2
    ea08:      	uxtb	w2, w2
    ea0c:      	strb	w2, [x1]
    ea10:      	cmp	x20, #0x0
    ea14:      	b.ne	0xe9d8 <_coil.alloc.oom-at+0x110>
    ea18:      	mov	x16, #0x18              ; =24
    ea1c:      	sub	x1, x16, x0
    ea20:      	adrp	x16, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ea20:  ARM64_RELOC_PAGE21	l_stogir.542
    ea24:      	ldr	x16, [x16]
		000000000000ea24:  ARM64_RELOC_PAGEOFF12	l_stogir.542
    ea28:      	add	x0, x16, x0
    ea2c:      	mov	x2, x1
    ea30:      	mov	x1, x0
    ea34:      	mov	x0, #0x2                ; =2
    ea38:      	bl	0xea38 <_coil.alloc.oom-at+0x170>
		000000000000ea38:  ARM64_RELOC_BRANCH26	_write
    ea3c:      	movz	x0, #0x0, lsl #48
    ea40:      	b	0xea4c <_coil.alloc.oom-at+0x184>
    ea44:      	nop
    ea48:      	add	x0, x0, #0x1
    ea4c:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ea4c:  ARM64_RELOC_PAGE21	l_stogir.543
    ea50:      	ldr	x17, [x17]
		000000000000ea50:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    ea54:      	add	x1, x0, x17
    ea58:      	ldrsb	w1, [x1]
    ea5c:      	sxtb	x1, w1
    ea60:      	cmp	x1, #0x0
    ea64:      	b.ne	0xea48 <_coil.alloc.oom-at+0x180>
    ea68:      	mov	x2, x0
    ea6c:      	mov	x0, #0x2                ; =2
    ea70:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ea70:  ARM64_RELOC_PAGE21	l_stogir.543
    ea74:      	ldr	x1, [x1]
		000000000000ea74:  ARM64_RELOC_PAGEOFF12	l_stogir.543
    ea78:      	bl	0xea78 <_coil.alloc.oom-at+0x1b0>
		000000000000ea78:  ARM64_RELOC_BRANCH26	_write
    ea7c:      	movz	x0, #0x0, lsl #48
    ea80:      	b	0xea8c <_coil.alloc.oom-at+0x1c4>
    ea84:      	nop
    ea88:      	add	x0, x0, #0x1
    ea8c:      	adrp	x17, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ea8c:  ARM64_RELOC_PAGE21	l_stogir.544
    ea90:      	ldr	x17, [x17]
		000000000000ea90:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    ea94:      	add	x1, x0, x17
    ea98:      	ldrsb	w1, [x1]
    ea9c:      	sxtb	x1, w1
    eaa0:      	cmp	x1, #0x0
    eaa4:      	b.ne	0xea88 <_coil.alloc.oom-at+0x1c0>
    eaa8:      	mov	x2, x0
    eaac:      	mov	x0, #0x2                ; =2
    eab0:      	adrp	x1, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000eab0:  ARM64_RELOC_PAGE21	l_stogir.544
    eab4:      	ldr	x1, [x1]
		000000000000eab4:  ARM64_RELOC_PAGEOFF12	l_stogir.544
    eab8:      	bl	0xeab8 <_coil.alloc.oom-at+0x1f0>
		000000000000eab8:  ARM64_RELOC_BRANCH26	_write
    eabc:      	bl	0xeabc <_coil.alloc.oom-at+0x1f4>
		000000000000eabc:  ARM64_RELOC_BRANCH26	_abort
    eac0:      	b	0xeac0 <_coil.alloc.oom-at+0x1f8>

000000000000eac4 <_coil.alloc.reallocate__stogir.cfg.Edge>:
    eac4:      	sub	sp, sp, #0x40
    eac8:      	str	x29, [sp, #0x10]
    eacc:      	str	x30, [sp, #0x18]
    ead0:      	add	x29, sp, #0x10
    ead4:      	str	x19, [sp, #0x30]
    ead8:      	str	x20, [sp, #0x38]
    eadc:      	mov	x19, x8
    eae0:      	mov	x20, x3
    eae4:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000eae4:  ARM64_RELOC_PAGE21	l_stogir.545
    eae8:      	ldr	x4, [x4]
		000000000000eae8:  ARM64_RELOC_PAGEOFF12	l_stogir.545
    eaec:      	mov	x5, #0x10               ; =16
    eaf0:      	mov	x6, #0x4                ; =4
    eaf4:      	bl	0xeaf4 <_coil.alloc.reallocate__stogir.cfg.Edge+0x30>
		000000000000eaf4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    eaf8:      	ubfx	x0, x0, #0, #32
    eafc:      	lsr	x16, x0, #0
    eb00:      	cmp	x16, #0x1
    eb04:      	b.eq	0xeb20 <_coil.alloc.reallocate__stogir.cfg.Edge+0x5c>
    eb08:      	b.lo	0xeb10 <_coil.alloc.reallocate__stogir.cfg.Edge+0x4c>
    eb0c:      	b	0xeb24 <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    eb10:      	cmp	x16, #0x0
    eb14:      	b.eq	0xeb1c <_coil.alloc.reallocate__stogir.cfg.Edge+0x58>
    eb18:      	b	0xeb24 <_coil.alloc.reallocate__stogir.cfg.Edge+0x60>
    eb1c:      	b	0xeb28 <_coil.alloc.reallocate__stogir.cfg.Edge+0x64>
    eb20:      	b	0xeb38 <_coil.alloc.reallocate__stogir.cfg.Edge+0x74>
    eb24:      	b	0xeb60 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>
    eb28:      	movz	x0, #0x0, lsl #48
    eb2c:      	movz	x1, #0x0, lsl #48
    eb30:      	movz	x20, #0x0, lsl #48
    eb34:      	b	0xeb3c <_coil.alloc.reallocate__stogir.cfg.Edge+0x78>
    eb38:      	mov	x0, #0x1                ; =1
    eb3c:      	str	x0, [x19]
    eb40:      	str	x1, [x19, #0x8]
    eb44:      	str	x20, [x19, #0x10]
    eb48:      	ldr	x19, [sp, #0x30]
    eb4c:      	ldr	x20, [sp, #0x38]
    eb50:      	ldr	x29, [sp, #0x10]
    eb54:      	ldr	x30, [sp, #0x18]
    eb58:      	add	sp, sp, #0x40
    eb5c:      	ret
    eb60:      	brk	#0
    eb64:      	b	0xeb60 <_coil.alloc.reallocate__stogir.cfg.Edge+0x9c>

000000000000eb68 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range>:
    eb68:      	sub	sp, sp, #0x50
    eb6c:      	str	x29, [sp]
    eb70:      	str	x30, [sp, #0x8]
    eb74:      	mov	x29, sp
    eb78:      	str	x19, [sp, #0x40]
    eb7c:      	str	x20, [sp, #0x48]
    eb80:      	add	x2, x0, #0x18
    eb84:      	ldr	x3, [x0, #0x10]
    eb88:      	ldr	x4, [x0, #0x18]
    eb8c:      	ldr	x2, [x2, #0x8]
    eb90:      	add	x16, sp, #0x10
    eb94:      	str	x4, [x16]
    eb98:      	add	x16, sp, #0x10
    eb9c:      	str	x2, [x16, #0x8]
    eba0:      	cmp	x1, x3
    eba4:      	b.le	0xec14 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xac>
    eba8:      	ldr	x2, [x0]
    ebac:      	add	x8, sp, #0x20
    ebb0:      	mov	x19, x0
    ebb4:      	add	x0, sp, #0x10
    ebb8:      	mov	x20, x1
    ebbc:      	fmov	d31, x1
    ebc0:      	mov	x1, x2
    ebc4:      	mov	x2, x3
    ebc8:      	fmov	x3, d31
    ebcc:      	bl	0xebcc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x64>
		000000000000ebcc:  ARM64_RELOC_BRANCH26	_coil.alloc.reallocate__stogir.adjacency.Range
    ebd0:      	add	x16, sp, #0x20
    ebd4:      	ldr	w0, [x16]
    ebd8:      	lsr	x16, x0, #0
    ebdc:      	cmp	x16, #0x1
    ebe0:      	b.eq	0xebfc <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x94>
    ebe4:      	b.lo	0xebec <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x84>
    ebe8:      	b	0xec00 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x98>
    ebec:      	cmp	x16, #0x0
    ebf0:      	b.eq	0xebf8 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x90>
    ebf4:      	b	0xec00 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x98>
    ebf8:      	b	0xec30 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xc8>
    ebfc:      	b	0xec04 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0x9c>
    ec00:      	b	0xec48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe0>
    ec04:      	add	x16, sp, #0x20
    ec08:      	ldr	x0, [x16, #0x8]
    ec0c:      	str	x0, [x19]
    ec10:      	str	x20, [x19, #0x10]
    ec14:      	movz	x0, #0x0, lsl #48
    ec18:      	ldr	x19, [sp, #0x40]
    ec1c:      	ldr	x20, [sp, #0x48]
    ec20:      	ldr	x29, [sp]
    ec24:      	ldr	x30, [sp, #0x8]
    ec28:      	add	sp, sp, #0x50
    ec2c:      	ret
    ec30:      	lsl	x0, x20, #4
    ec34:      	mov	x1, x0
    ec38:      	adrp	x0, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ec38:  ARM64_RELOC_PAGE21	l_stogir.546
    ec3c:      	ldr	x0, [x0]
		000000000000ec3c:  ARM64_RELOC_PAGEOFF12	l_stogir.546
    ec40:      	bl	0xec40 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xd8>
		000000000000ec40:  ARM64_RELOC_BRANCH26	_coil.alloc.oom-at
    ec44:      	b	0xec44 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xdc>
    ec48:      	brk	#0
    ec4c:      	b	0xec48 <_inherent$coil.arraylist.ArrayList$reserve!__stogir.adjacency.Range+0xe0>

000000000000ec50 <_coil.alloc.reallocate__bool>:
    ec50:      	sub	sp, sp, #0x40
    ec54:      	str	x29, [sp, #0x10]
    ec58:      	str	x30, [sp, #0x18]
    ec5c:      	add	x29, sp, #0x10
    ec60:      	str	x19, [sp, #0x30]
    ec64:      	str	x20, [sp, #0x38]
    ec68:      	mov	x19, x8
    ec6c:      	mov	x20, x3
    ec70:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ec70:  ARM64_RELOC_PAGE21	l_stogir.547
    ec74:      	ldr	x4, [x4]
		000000000000ec74:  ARM64_RELOC_PAGEOFF12	l_stogir.547
    ec78:      	mov	x5, #0x1                ; =1
    ec7c:      	mov	x6, #0x1                ; =1
    ec80:      	bl	0xec80 <_coil.alloc.reallocate__bool+0x30>
		000000000000ec80:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ec84:      	ubfx	x0, x0, #0, #32
    ec88:      	lsr	x16, x0, #0
    ec8c:      	cmp	x16, #0x1
    ec90:      	b.eq	0xecac <_coil.alloc.reallocate__bool+0x5c>
    ec94:      	b.lo	0xec9c <_coil.alloc.reallocate__bool+0x4c>
    ec98:      	b	0xecb0 <_coil.alloc.reallocate__bool+0x60>
    ec9c:      	cmp	x16, #0x0
    eca0:      	b.eq	0xeca8 <_coil.alloc.reallocate__bool+0x58>
    eca4:      	b	0xecb0 <_coil.alloc.reallocate__bool+0x60>
    eca8:      	b	0xecb4 <_coil.alloc.reallocate__bool+0x64>
    ecac:      	b	0xecc4 <_coil.alloc.reallocate__bool+0x74>
    ecb0:      	b	0xecec <_coil.alloc.reallocate__bool+0x9c>
    ecb4:      	movz	x0, #0x0, lsl #48
    ecb8:      	movz	x1, #0x0, lsl #48
    ecbc:      	movz	x20, #0x0, lsl #48
    ecc0:      	b	0xecc8 <_coil.alloc.reallocate__bool+0x78>
    ecc4:      	mov	x0, #0x1                ; =1
    ecc8:      	str	x0, [x19]
    eccc:      	str	x1, [x19, #0x8]
    ecd0:      	str	x20, [x19, #0x10]
    ecd4:      	ldr	x19, [sp, #0x30]
    ecd8:      	ldr	x20, [sp, #0x38]
    ecdc:      	ldr	x29, [sp, #0x10]
    ece0:      	ldr	x30, [sp, #0x18]
    ece4:      	add	sp, sp, #0x40
    ece8:      	ret
    ecec:      	brk	#0
    ecf0:      	b	0xecec <_coil.alloc.reallocate__bool+0x9c>

000000000000ecf4 <_coil.alloc.reallocate__stogir.adjacency.Frame>:
    ecf4:      	sub	sp, sp, #0x40
    ecf8:      	str	x29, [sp, #0x10]
    ecfc:      	str	x30, [sp, #0x18]
    ed00:      	add	x29, sp, #0x10
    ed04:      	str	x19, [sp, #0x30]
    ed08:      	str	x20, [sp, #0x38]
    ed0c:      	mov	x19, x8
    ed10:      	mov	x20, x3
    ed14:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ed14:  ARM64_RELOC_PAGE21	l_stogir.548
    ed18:      	ldr	x4, [x4]
		000000000000ed18:  ARM64_RELOC_PAGEOFF12	l_stogir.548
    ed1c:      	mov	x5, #0x10               ; =16
    ed20:      	mov	x6, #0x8                ; =8
    ed24:      	bl	0xed24 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x30>
		000000000000ed24:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ed28:      	ubfx	x0, x0, #0, #32
    ed2c:      	lsr	x16, x0, #0
    ed30:      	cmp	x16, #0x1
    ed34:      	b.eq	0xed50 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x5c>
    ed38:      	b.lo	0xed40 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x4c>
    ed3c:      	b	0xed54 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    ed40:      	cmp	x16, #0x0
    ed44:      	b.eq	0xed4c <_coil.alloc.reallocate__stogir.adjacency.Frame+0x58>
    ed48:      	b	0xed54 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x60>
    ed4c:      	b	0xed58 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x64>
    ed50:      	b	0xed68 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x74>
    ed54:      	b	0xed90 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>
    ed58:      	movz	x0, #0x0, lsl #48
    ed5c:      	movz	x1, #0x0, lsl #48
    ed60:      	movz	x20, #0x0, lsl #48
    ed64:      	b	0xed6c <_coil.alloc.reallocate__stogir.adjacency.Frame+0x78>
    ed68:      	mov	x0, #0x1                ; =1
    ed6c:      	str	x0, [x19]
    ed70:      	str	x1, [x19, #0x8]
    ed74:      	str	x20, [x19, #0x10]
    ed78:      	ldr	x19, [sp, #0x30]
    ed7c:      	ldr	x20, [sp, #0x38]
    ed80:      	ldr	x29, [sp, #0x10]
    ed84:      	ldr	x30, [sp, #0x18]
    ed88:      	add	sp, sp, #0x40
    ed8c:      	ret
    ed90:      	brk	#0
    ed94:      	b	0xed90 <_coil.alloc.reallocate__stogir.adjacency.Frame+0x9c>

000000000000ed98 <_coil.alloc.reallocate__i64>:
    ed98:      	sub	sp, sp, #0x40
    ed9c:      	str	x29, [sp, #0x10]
    eda0:      	str	x30, [sp, #0x18]
    eda4:      	add	x29, sp, #0x10
    eda8:      	str	x19, [sp, #0x30]
    edac:      	str	x20, [sp, #0x38]
    edb0:      	mov	x19, x8
    edb4:      	mov	x20, x3
    edb8:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000edb8:  ARM64_RELOC_PAGE21	l_stogir.549
    edbc:      	ldr	x4, [x4]
		000000000000edbc:  ARM64_RELOC_PAGEOFF12	l_stogir.549
    edc0:      	mov	x5, #0x8                ; =8
    edc4:      	mov	x6, #0x8                ; =8
    edc8:      	bl	0xedc8 <_coil.alloc.reallocate__i64+0x30>
		000000000000edc8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    edcc:      	ubfx	x0, x0, #0, #32
    edd0:      	lsr	x16, x0, #0
    edd4:      	cmp	x16, #0x1
    edd8:      	b.eq	0xedf4 <_coil.alloc.reallocate__i64+0x5c>
    eddc:      	b.lo	0xede4 <_coil.alloc.reallocate__i64+0x4c>
    ede0:      	b	0xedf8 <_coil.alloc.reallocate__i64+0x60>
    ede4:      	cmp	x16, #0x0
    ede8:      	b.eq	0xedf0 <_coil.alloc.reallocate__i64+0x58>
    edec:      	b	0xedf8 <_coil.alloc.reallocate__i64+0x60>
    edf0:      	b	0xedfc <_coil.alloc.reallocate__i64+0x64>
    edf4:      	b	0xee0c <_coil.alloc.reallocate__i64+0x74>
    edf8:      	b	0xee34 <_coil.alloc.reallocate__i64+0x9c>
    edfc:      	movz	x0, #0x0, lsl #48
    ee00:      	movz	x1, #0x0, lsl #48
    ee04:      	movz	x20, #0x0, lsl #48
    ee08:      	b	0xee10 <_coil.alloc.reallocate__i64+0x78>
    ee0c:      	mov	x0, #0x1                ; =1
    ee10:      	str	x0, [x19]
    ee14:      	str	x1, [x19, #0x8]
    ee18:      	str	x20, [x19, #0x10]
    ee1c:      	ldr	x19, [sp, #0x30]
    ee20:      	ldr	x20, [sp, #0x38]
    ee24:      	ldr	x29, [sp, #0x10]
    ee28:      	ldr	x30, [sp, #0x18]
    ee2c:      	add	sp, sp, #0x40
    ee30:      	ret
    ee34:      	brk	#0
    ee38:      	b	0xee34 <_coil.alloc.reallocate__i64+0x9c>

000000000000ee3c <_coil.alloc.reallocate__stogir.uses.Range>:
    ee3c:      	sub	sp, sp, #0x40
    ee40:      	str	x29, [sp, #0x10]
    ee44:      	str	x30, [sp, #0x18]
    ee48:      	add	x29, sp, #0x10
    ee4c:      	str	x19, [sp, #0x30]
    ee50:      	str	x20, [sp, #0x38]
    ee54:      	mov	x19, x8
    ee58:      	mov	x20, x3
    ee5c:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ee5c:  ARM64_RELOC_PAGE21	l_stogir.550
    ee60:      	ldr	x4, [x4]
		000000000000ee60:  ARM64_RELOC_PAGEOFF12	l_stogir.550
    ee64:      	mov	x5, #0x10               ; =16
    ee68:      	mov	x6, #0x8                ; =8
    ee6c:      	bl	0xee6c <_coil.alloc.reallocate__stogir.uses.Range+0x30>
		000000000000ee6c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ee70:      	ubfx	x0, x0, #0, #32
    ee74:      	lsr	x16, x0, #0
    ee78:      	cmp	x16, #0x1
    ee7c:      	b.eq	0xee98 <_coil.alloc.reallocate__stogir.uses.Range+0x5c>
    ee80:      	b.lo	0xee88 <_coil.alloc.reallocate__stogir.uses.Range+0x4c>
    ee84:      	b	0xee9c <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    ee88:      	cmp	x16, #0x0
    ee8c:      	b.eq	0xee94 <_coil.alloc.reallocate__stogir.uses.Range+0x58>
    ee90:      	b	0xee9c <_coil.alloc.reallocate__stogir.uses.Range+0x60>
    ee94:      	b	0xeea0 <_coil.alloc.reallocate__stogir.uses.Range+0x64>
    ee98:      	b	0xeeb0 <_coil.alloc.reallocate__stogir.uses.Range+0x74>
    ee9c:      	b	0xeed8 <_coil.alloc.reallocate__stogir.uses.Range+0x9c>
    eea0:      	movz	x0, #0x0, lsl #48
    eea4:      	movz	x1, #0x0, lsl #48
    eea8:      	movz	x20, #0x0, lsl #48
    eeac:      	b	0xeeb4 <_coil.alloc.reallocate__stogir.uses.Range+0x78>
    eeb0:      	mov	x0, #0x1                ; =1
    eeb4:      	str	x0, [x19]
    eeb8:      	str	x1, [x19, #0x8]
    eebc:      	str	x20, [x19, #0x10]
    eec0:      	ldr	x19, [sp, #0x30]
    eec4:      	ldr	x20, [sp, #0x38]
    eec8:      	ldr	x29, [sp, #0x10]
    eecc:      	ldr	x30, [sp, #0x18]
    eed0:      	add	sp, sp, #0x40
    eed4:      	ret
    eed8:      	brk	#0
    eedc:      	b	0xeed8 <_coil.alloc.reallocate__stogir.uses.Range+0x9c>

000000000000eee0 <_coil.alloc.reallocate__stogir.uses.Use>:
    eee0:      	sub	sp, sp, #0x40
    eee4:      	str	x29, [sp, #0x10]
    eee8:      	str	x30, [sp, #0x18]
    eeec:      	add	x29, sp, #0x10
    eef0:      	str	x19, [sp, #0x30]
    eef4:      	str	x20, [sp, #0x38]
    eef8:      	mov	x19, x8
    eefc:      	mov	x20, x3
    ef00:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000ef00:  ARM64_RELOC_PAGE21	l_stogir.551
    ef04:      	ldr	x4, [x4]
		000000000000ef04:  ARM64_RELOC_PAGEOFF12	l_stogir.551
    ef08:      	mov	x5, #0x8                ; =8
    ef0c:      	mov	x6, #0x4                ; =4
    ef10:      	bl	0xef10 <_coil.alloc.reallocate__stogir.uses.Use+0x30>
		000000000000ef10:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    ef14:      	ubfx	x0, x0, #0, #32
    ef18:      	lsr	x16, x0, #0
    ef1c:      	cmp	x16, #0x1
    ef20:      	b.eq	0xef3c <_coil.alloc.reallocate__stogir.uses.Use+0x5c>
    ef24:      	b.lo	0xef2c <_coil.alloc.reallocate__stogir.uses.Use+0x4c>
    ef28:      	b	0xef40 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    ef2c:      	cmp	x16, #0x0
    ef30:      	b.eq	0xef38 <_coil.alloc.reallocate__stogir.uses.Use+0x58>
    ef34:      	b	0xef40 <_coil.alloc.reallocate__stogir.uses.Use+0x60>
    ef38:      	b	0xef44 <_coil.alloc.reallocate__stogir.uses.Use+0x64>
    ef3c:      	b	0xef54 <_coil.alloc.reallocate__stogir.uses.Use+0x74>
    ef40:      	b	0xef7c <_coil.alloc.reallocate__stogir.uses.Use+0x9c>
    ef44:      	movz	x0, #0x0, lsl #48
    ef48:      	movz	x1, #0x0, lsl #48
    ef4c:      	movz	x20, #0x0, lsl #48
    ef50:      	b	0xef58 <_coil.alloc.reallocate__stogir.uses.Use+0x78>
    ef54:      	mov	x0, #0x1                ; =1
    ef58:      	str	x0, [x19]
    ef5c:      	str	x1, [x19, #0x8]
    ef60:      	str	x20, [x19, #0x10]
    ef64:      	ldr	x19, [sp, #0x30]
    ef68:      	ldr	x20, [sp, #0x38]
    ef6c:      	ldr	x29, [sp, #0x10]
    ef70:      	ldr	x30, [sp, #0x18]
    ef74:      	add	sp, sp, #0x40
    ef78:      	ret
    ef7c:      	brk	#0
    ef80:      	b	0xef7c <_coil.alloc.reallocate__stogir.uses.Use+0x9c>

000000000000ef84 <_coil.alloc.reallocate__stogir.schedule.Range>:
    ef84:      	sub	sp, sp, #0x40
    ef88:      	str	x29, [sp, #0x10]
    ef8c:      	str	x30, [sp, #0x18]
    ef90:      	add	x29, sp, #0x10
    ef94:      	str	x19, [sp, #0x30]
    ef98:      	str	x20, [sp, #0x38]
    ef9c:      	mov	x19, x8
    efa0:      	mov	x20, x3
    efa4:      	adrp	x4, 0xe000 <_inherent$coil.arraylist.ArrayList$reserve!__i64+0x94>
		000000000000efa4:  ARM64_RELOC_PAGE21	l_stogir.552
    efa8:      	ldr	x4, [x4]
		000000000000efa8:  ARM64_RELOC_PAGEOFF12	l_stogir.552
    efac:      	mov	x5, #0x10               ; =16
    efb0:      	mov	x6, #0x8                ; =8
    efb4:      	bl	0xefb4 <_coil.alloc.reallocate__stogir.schedule.Range+0x30>
		000000000000efb4:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    efb8:      	ubfx	x0, x0, #0, #32
    efbc:      	lsr	x16, x0, #0
    efc0:      	cmp	x16, #0x1
    efc4:      	b.eq	0xefe0 <_coil.alloc.reallocate__stogir.schedule.Range+0x5c>
    efc8:      	b.lo	0xefd0 <_coil.alloc.reallocate__stogir.schedule.Range+0x4c>
    efcc:      	b	0xefe4 <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    efd0:      	cmp	x16, #0x0
    efd4:      	b.eq	0xefdc <_coil.alloc.reallocate__stogir.schedule.Range+0x58>
    efd8:      	b	0xefe4 <_coil.alloc.reallocate__stogir.schedule.Range+0x60>
    efdc:      	b	0xefe8 <_coil.alloc.reallocate__stogir.schedule.Range+0x64>
    efe0:      	b	0xeff8 <_coil.alloc.reallocate__stogir.schedule.Range+0x74>
    efe4:      	b	0xf020 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>
    efe8:      	movz	x0, #0x0, lsl #48
    efec:      	movz	x1, #0x0, lsl #48
    eff0:      	movz	x20, #0x0, lsl #48
    eff4:      	b	0xeffc <_coil.alloc.reallocate__stogir.schedule.Range+0x78>
    eff8:      	mov	x0, #0x1                ; =1
    effc:      	str	x0, [x19]
    f000:      	str	x1, [x19, #0x8]
    f004:      	str	x20, [x19, #0x10]
    f008:      	ldr	x19, [sp, #0x30]
    f00c:      	ldr	x20, [sp, #0x38]
    f010:      	ldr	x29, [sp, #0x10]
    f014:      	ldr	x30, [sp, #0x18]
    f018:      	add	sp, sp, #0x40
    f01c:      	ret
    f020:      	brk	#0
    f024:      	b	0xf020 <_coil.alloc.reallocate__stogir.schedule.Range+0x9c>

000000000000f028 <_coil.alloc.sized-reallocate>:
    f028:      	sub	sp, sp, #0x90
    f02c:      	str	x29, [sp, #0x10]
    f030:      	str	x30, [sp, #0x18]
    f034:      	add	x29, sp, #0x10
    f038:      	str	x19, [sp, #0x50]
    f03c:      	str	x20, [sp, #0x58]
    f040:      	str	x21, [sp, #0x60]
    f044:      	str	x22, [sp, #0x68]
    f048:      	str	x23, [sp, #0x70]
    f04c:      	str	x24, [sp, #0x78]
    f050:      	str	x25, [sp, #0x80]
    f054:      	str	x26, [sp, #0x88]
    f058:      	add	x19, sp, #0x20
    f05c:      	mov	x20, x0
    f060:      	mov	x21, x1
    f064:      	mov	x22, x2
    f068:      	mov	x23, x3
    f06c:      	mov	x24, x4
    f070:      	mov	x25, x5
    f074:      	mov	x26, x6
    f078:      	movz	x7, #0x0, lsl #48
    f07c:      	uxtb	w7, w7
    f080:      	bl	0xf080 <_coil.alloc.sized-reallocate+0x58>
		000000000000f080:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-resize
    f084:      	ubfx	x0, x0, #0, #32
    f088:      	lsr	x16, x0, #0
    f08c:      	cmp	x16, #0x1
    f090:      	b.eq	0xf0ac <_coil.alloc.sized-reallocate+0x84>
    f094:      	b.lo	0xf09c <_coil.alloc.sized-reallocate+0x74>
    f098:      	b	0xf0b0 <_coil.alloc.sized-reallocate+0x88>
    f09c:      	cmp	x16, #0x0
    f0a0:      	b.eq	0xf0a8 <_coil.alloc.sized-reallocate+0x80>
    f0a4:      	b	0xf0b0 <_coil.alloc.sized-reallocate+0x88>
    f0a8:      	b	0xf0fc <_coil.alloc.sized-reallocate+0xd4>
    f0ac:      	b	0xf0b4 <_coil.alloc.sized-reallocate+0x8c>
    f0b0:      	b	0xf198 <_coil.alloc.sized-reallocate+0x170>
    f0b4:      	mov	x23, x1
    f0b8:      	mov	x0, #0x1                ; =1
    f0bc:      	str	x0, [x19]
    f0c0:      	str	x23, [x19, #0x8]
    f0c4:      	ldr	x0, [sp, #0x20]
    f0c8:      	ldr	x1, [sp, #0x28]
    f0cc:      	ldr	x19, [sp, #0x50]
    f0d0:      	ldr	x20, [sp, #0x58]
    f0d4:      	ldr	x21, [sp, #0x60]
    f0d8:      	ldr	x22, [sp, #0x68]
    f0dc:      	ldr	x23, [sp, #0x70]
    f0e0:      	ldr	x24, [sp, #0x78]
    f0e4:      	ldr	x25, [sp, #0x80]
    f0e8:      	ldr	x26, [sp, #0x88]
    f0ec:      	ldr	x29, [sp, #0x10]
    f0f0:      	ldr	x30, [sp, #0x18]
    f0f4:      	add	sp, sp, #0x90
    f0f8:      	ret
    f0fc:      	mov	x0, x20
    f100:      	mov	x1, x24
    f104:      	mov	x2, x25
    f108:      	mov	x3, x26
    f10c:      	mov	x4, x23
    f110:      	bl	0xf110 <_coil.alloc.sized-reallocate+0xe8>
		000000000000f110:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    f114:      	ubfx	x0, x0, #0, #32
    f118:      	lsr	x16, x0, #0
    f11c:      	cmp	x16, #0x1
    f120:      	b.eq	0xf13c <_coil.alloc.sized-reallocate+0x114>
    f124:      	b.lo	0xf12c <_coil.alloc.sized-reallocate+0x104>
    f128:      	b	0xf140 <_coil.alloc.sized-reallocate+0x118>
    f12c:      	cmp	x16, #0x0
    f130:      	b.eq	0xf138 <_coil.alloc.sized-reallocate+0x110>
    f134:      	b	0xf140 <_coil.alloc.sized-reallocate+0x118>
    f138:      	b	0xf144 <_coil.alloc.sized-reallocate+0x11c>
    f13c:      	b	0xf150 <_coil.alloc.sized-reallocate+0x128>
    f140:      	b	0xf1a0 <_coil.alloc.sized-reallocate+0x178>
    f144:      	movz	x0, #0x0, lsl #48
    f148:      	movz	x23, #0x0, lsl #48
    f14c:      	b	0xf194 <_coil.alloc.sized-reallocate+0x16c>
    f150:      	cmp	x22, x23
    f154:      	b.ge	0xf15c <_coil.alloc.sized-reallocate+0x134>
    f158:      	mov	x23, x22
    f15c:      	orr	x0, x1, xzr
    f160:      	mul	x2, x25, x23
    f164:      	lsr	x2, x2, #0
    f168:      	mov	x23, x1
    f16c:      	mov	x1, x21
    f170:      	bl	0xf170 <_coil.alloc.sized-reallocate+0x148>
		000000000000f170:  ARM64_RELOC_BRANCH26	_memcpy
    f174:      	mov	x0, x20
    f178:      	mov	x1, x21
    f17c:      	mov	x2, x22
    f180:      	mov	x3, x24
    f184:      	mov	x4, x25
    f188:      	mov	x5, x26
    f18c:      	bl	0xf18c <_coil.alloc.sized-reallocate+0x164>
		000000000000f18c:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    f190:      	mov	x0, #0x1                ; =1
    f194:      	b	0xf0bc <_coil.alloc.sized-reallocate+0x94>
    f198:      	brk	#0
    f19c:      	b	0xf198 <_coil.alloc.sized-reallocate+0x170>
    f1a0:      	brk	#0
    f1a4:      	b	0xf1a0 <_coil.alloc.sized-reallocate+0x178>

000000000000f1a8 <_coil.alloc.reallocate__stogir.adjacency.Range>:
    f1a8:      	sub	sp, sp, #0x40
    f1ac:      	str	x29, [sp, #0x10]
    f1b0:      	str	x30, [sp, #0x18]
    f1b4:      	add	x29, sp, #0x10
    f1b8:      	str	x19, [sp, #0x30]
    f1bc:      	str	x20, [sp, #0x38]
    f1c0:      	mov	x19, x8
    f1c4:      	mov	x20, x3
    f1c8:      	adrp	x4, 0xf000 <_coil.alloc.reallocate__stogir.schedule.Range+0x7c>
		000000000000f1c8:  ARM64_RELOC_PAGE21	l_stogir.553
    f1cc:      	ldr	x4, [x4]
		000000000000f1cc:  ARM64_RELOC_PAGEOFF12	l_stogir.553
    f1d0:      	mov	x5, #0x10               ; =16
    f1d4:      	mov	x6, #0x8                ; =8
    f1d8:      	bl	0xf1d8 <_coil.alloc.reallocate__stogir.adjacency.Range+0x30>
		000000000000f1d8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-reallocate
    f1dc:      	ubfx	x0, x0, #0, #32
    f1e0:      	lsr	x16, x0, #0
    f1e4:      	cmp	x16, #0x1
    f1e8:      	b.eq	0xf204 <_coil.alloc.reallocate__stogir.adjacency.Range+0x5c>
    f1ec:      	b.lo	0xf1f4 <_coil.alloc.reallocate__stogir.adjacency.Range+0x4c>
    f1f0:      	b	0xf208 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    f1f4:      	cmp	x16, #0x0
    f1f8:      	b.eq	0xf200 <_coil.alloc.reallocate__stogir.adjacency.Range+0x58>
    f1fc:      	b	0xf208 <_coil.alloc.reallocate__stogir.adjacency.Range+0x60>
    f200:      	b	0xf20c <_coil.alloc.reallocate__stogir.adjacency.Range+0x64>
    f204:      	b	0xf21c <_coil.alloc.reallocate__stogir.adjacency.Range+0x74>
    f208:      	b	0xf244 <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>
    f20c:      	movz	x0, #0x0, lsl #48
    f210:      	movz	x1, #0x0, lsl #48
    f214:      	movz	x20, #0x0, lsl #48
    f218:      	b	0xf220 <_coil.alloc.reallocate__stogir.adjacency.Range+0x78>
    f21c:      	mov	x0, #0x1                ; =1
    f220:      	str	x0, [x19]
    f224:      	str	x1, [x19, #0x8]
    f228:      	str	x20, [x19, #0x10]
    f22c:      	ldr	x19, [sp, #0x30]
    f230:      	ldr	x20, [sp, #0x38]
    f234:      	ldr	x29, [sp, #0x10]
    f238:      	ldr	x30, [sp, #0x18]
    f23c:      	add	sp, sp, #0x40
    f240:      	ret
    f244:      	brk	#0
    f248:      	b	0xf244 <_coil.alloc.reallocate__stogir.adjacency.Range+0x9c>

000000000000f24c <_coil.alloc.sized-resize>:
    f24c:      	sub	sp, sp, #0x130
    f250:      	str	x29, [sp, #0x10]
    f254:      	str	x30, [sp, #0x18]
    f258:      	add	x29, sp, #0x10
    f25c:      	str	x19, [sp, #0xf0]
    f260:      	str	x20, [sp, #0xf8]
    f264:      	str	x21, [sp, #0x100]
    f268:      	str	x22, [sp, #0x108]
    f26c:      	str	x23, [sp, #0x110]
    f270:      	str	x24, [sp, #0x118]
    f274:      	str	x25, [sp, #0x120]
    f278:      	str	x26, [sp, #0x128]
    f27c:      	add	x19, sp, #0x20
    f280:      	cmp	x3, #0x0
    f284:      	b.ne	0xf2e0 <_coil.alloc.sized-resize+0x94>
    f288:      	mov	x3, x4
    f28c:      	mov	x4, x5
    f290:      	mov	x5, x6
    f294:      	bl	0xf294 <_coil.alloc.sized-resize+0x48>
		000000000000f294:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-free
    f298:      	mov	x0, #0x1                ; =1
    f29c:      	movz	x1, #0x0, lsl #48
    f2a0:      	str	x0, [x19]
    f2a4:      	str	x1, [x19, #0x8]
    f2a8:      	ldr	x0, [sp, #0x20]
    f2ac:      	ldr	x1, [sp, #0x28]
    f2b0:      	ldr	x19, [sp, #0xf0]
    f2b4:      	ldr	x20, [sp, #0xf8]
    f2b8:      	ldr	x21, [sp, #0x100]
    f2bc:      	ldr	x22, [sp, #0x108]
    f2c0:      	ldr	x23, [sp, #0x110]
    f2c4:      	ldr	x24, [sp, #0x118]
    f2c8:      	ldr	x25, [sp, #0x120]
    f2cc:      	ldr	x26, [sp, #0x128]
    f2d0:      	ldr	x29, [sp, #0x10]
    f2d4:      	ldr	x30, [sp, #0x18]
    f2d8:      	add	sp, sp, #0x130
    f2dc:      	ret
    f2e0:      	cmp	x2, #0x0
    f2e4:      	b.ne	0xf300 <_coil.alloc.sized-resize+0xb4>
    f2e8:      	mov	x1, x4
    f2ec:      	mov	x2, x5
    f2f0:      	mov	x4, x3
    f2f4:      	mov	x3, x6
    f2f8:      	bl	0xf2f8 <_coil.alloc.sized-resize+0xac>
		000000000000f2f8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-alloc
    f2fc:      	b	0xf2a0 <_coil.alloc.sized-resize+0x54>
    f300:      	add	x8, sp, #0x30
    f304:      	mov	x20, x0
    f308:      	mov	x0, x4
    f30c:      	mov	x21, x1
    f310:      	mov	x1, x5
    f314:      	mov	x22, x3
    f318:      	mov	x3, x2
    f31c:      	mov	x2, x6
    f320:      	mov	x23, x4
    f324:      	mov	x24, x5
    f328:      	mov	x25, x6
    f32c:      	mov	w26, w7
    f330:      	bl	0xf330 <_coil.alloc.sized-resize+0xe4>
		000000000000f330:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f334:      	add	x16, sp, #0x30
    f338:      	ldr	w0, [x16]
    f33c:      	lsr	x16, x0, #0
    f340:      	cmp	x16, #0x1
    f344:      	b.eq	0xf360 <_coil.alloc.sized-resize+0x114>
    f348:      	b.lo	0xf350 <_coil.alloc.sized-resize+0x104>
    f34c:      	b	0xf364 <_coil.alloc.sized-resize+0x118>
    f350:      	cmp	x16, #0x0
    f354:      	b.eq	0xf35c <_coil.alloc.sized-resize+0x110>
    f358:      	b	0xf364 <_coil.alloc.sized-resize+0x118>
    f35c:      	b	0xf368 <_coil.alloc.sized-resize+0x11c>
    f360:      	b	0xf374 <_coil.alloc.sized-resize+0x128>
    f364:      	b	0xf4a4 <_coil.alloc.sized-resize+0x258>
    f368:      	movz	x0, #0x0, lsl #48
    f36c:      	movz	x1, #0x0, lsl #48
    f370:      	b	0xf2fc <_coil.alloc.sized-resize+0xb0>
    f374:      	add	x16, sp, #0x30
    f378:      	orr	x0, x16, xzr
    f37c:      	add	x0, x0, #0x8
    f380:      	add	x16, sp, #0x30
    f384:      	ldr	x1, [x16, #0x8]
    f388:      	add	x16, sp, #0x60
    f38c:      	str	x1, [x16]
    f390:      	ldr	x1, [x0, #0x8]
    f394:      	add	x16, sp, #0x60
    f398:      	str	x1, [x16, #0x8]
    f39c:      	ldr	x1, [x0, #0x10]
    f3a0:      	add	x16, sp, #0x60
    f3a4:      	str	x1, [x16, #0x10]
    f3a8:      	ldr	x0, [x0, #0x18]
    f3ac:      	add	x16, sp, #0x60
    f3b0:      	str	x0, [x16, #0x18]
    f3b4:      	add	x8, sp, #0x80
    f3b8:      	mov	x0, x23
    f3bc:      	mov	x1, x24
    f3c0:      	mov	x2, x25
    f3c4:      	mov	x3, x22
    f3c8:      	bl	0xf3c8 <_coil.alloc.sized-resize+0x17c>
		000000000000f3c8:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f3cc:      	add	x16, sp, #0x80
    f3d0:      	ldr	w0, [x16]
    f3d4:      	lsr	x16, x0, #0
    f3d8:      	cmp	x16, #0x1
    f3dc:      	b.eq	0xf3f8 <_coil.alloc.sized-resize+0x1ac>
    f3e0:      	b.lo	0xf3e8 <_coil.alloc.sized-resize+0x19c>
    f3e4:      	b	0xf3fc <_coil.alloc.sized-resize+0x1b0>
    f3e8:      	cmp	x16, #0x0
    f3ec:      	b.eq	0xf3f4 <_coil.alloc.sized-resize+0x1a8>
    f3f0:      	b	0xf3fc <_coil.alloc.sized-resize+0x1b0>
    f3f4:      	b	0xf400 <_coil.alloc.sized-resize+0x1b4>
    f3f8:      	b	0xf418 <_coil.alloc.sized-resize+0x1cc>
    f3fc:      	b	0xf4ac <_coil.alloc.sized-resize+0x260>
    f400:      	movz	x0, #0x0, lsl #48
    f404:      	movz	x1, #0x0, lsl #48
    f408:      	b	0xf414 <_coil.alloc.sized-resize+0x1c8>
    f40c:      	movz	x0, #0x0, lsl #48
    f410:      	movz	x1, #0x0, lsl #48
    f414:      	b	0xf370 <_coil.alloc.sized-resize+0x124>
    f418:      	ubfx	x26, x26, #0, #8
    f41c:      	add	x16, sp, #0x80
    f420:      	orr	x0, x16, xzr
    f424:      	add	x0, x0, #0x8
    f428:      	add	x16, sp, #0x80
    f42c:      	ldr	x1, [x16, #0x8]
    f430:      	add	x16, sp, #0xb0
    f434:      	str	x1, [x16]
    f438:      	ldr	x1, [x0, #0x8]
    f43c:      	add	x16, sp, #0xb0
    f440:      	str	x1, [x16, #0x8]
    f444:      	ldr	x1, [x0, #0x10]
    f448:      	add	x16, sp, #0xb0
    f44c:      	str	x1, [x16, #0x10]
    f450:      	ldr	x0, [x0, #0x18]
    f454:      	add	x16, sp, #0xb0
    f458:      	str	x0, [x16, #0x18]
    f45c:      	cmp	x26, #0x0
    f460:      	b.eq	0xf48c <_coil.alloc.sized-resize+0x240>
    f464:      	mov	x0, x20
    f468:      	mov	x1, x21
    f46c:      	add	x2, sp, #0x60
    f470:      	add	x3, sp, #0xb0
    f474:      	bl	0xf474 <_coil.alloc.sized-resize+0x228>
		000000000000f474:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-resize
    f478:      	cmp	x0, #0x0
    f47c:      	b.eq	0xf40c <_coil.alloc.sized-resize+0x1c0>
    f480:      	orr	x1, x21, xzr
    f484:      	mov	x0, #0x1                ; =1
    f488:      	b	0xf414 <_coil.alloc.sized-resize+0x1c8>
    f48c:      	mov	x0, x20
    f490:      	mov	x1, x21
    f494:      	add	x2, sp, #0x60
    f498:      	add	x3, sp, #0xb0
    f49c:      	bl	0xf49c <_coil.alloc.sized-resize+0x250>
		000000000000f49c:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-remap
    f4a0:      	b	0xf414 <_coil.alloc.sized-resize+0x1c8>
    f4a4:      	brk	#0
    f4a8:      	b	0xf4a4 <_coil.alloc.sized-resize+0x258>
    f4ac:      	brk	#0
    f4b0:      	b	0xf4ac <_coil.alloc.sized-resize+0x260>

000000000000f4b4 <_coil.alloc.sized-alloc>:
    f4b4:      	sub	sp, sp, #0xa0
    f4b8:      	str	x29, [sp, #0x10]
    f4bc:      	str	x30, [sp, #0x18]
    f4c0:      	add	x29, sp, #0x10
    f4c4:      	str	x19, [sp, #0x90]
    f4c8:      	str	x20, [sp, #0x98]
    f4cc:      	add	x19, sp, #0x20
    f4d0:      	cmp	x4, #0x0
    f4d4:      	b.ne	0xf508 <_coil.alloc.sized-alloc+0x54>
    f4d8:      	mov	x0, #0x1                ; =1
    f4dc:      	movz	x1, #0x0, lsl #48
    f4e0:      	str	x0, [x19]
    f4e4:      	str	x1, [x19, #0x8]
    f4e8:      	ldr	x0, [sp, #0x20]
    f4ec:      	ldr	x1, [sp, #0x28]
    f4f0:      	ldr	x19, [sp, #0x90]
    f4f4:      	ldr	x20, [sp, #0x98]
    f4f8:      	ldr	x29, [sp, #0x10]
    f4fc:      	ldr	x30, [sp, #0x18]
    f500:      	add	sp, sp, #0xa0
    f504:      	ret
    f508:      	add	x8, sp, #0x30
    f50c:      	mov	x20, x0
    f510:      	mov	x0, x1
    f514:      	mov	x1, x2
    f518:      	mov	x2, x3
    f51c:      	mov	x3, x4
    f520:      	bl	0xf520 <_coil.alloc.sized-alloc+0x6c>
		000000000000f520:  ARM64_RELOC_BRANCH26	_coil.alloc.sized-request
    f524:      	add	x16, sp, #0x30
    f528:      	ldr	w0, [x16]
    f52c:      	lsr	x16, x0, #0
    f530:      	cmp	x16, #0x1
    f534:      	b.eq	0xf550 <_coil.alloc.sized-alloc+0x9c>
    f538:      	b.lo	0xf540 <_coil.alloc.sized-alloc+0x8c>
    f53c:      	b	0xf554 <_coil.alloc.sized-alloc+0xa0>
    f540:      	cmp	x16, #0x0
    f544:      	b.eq	0xf54c <_coil.alloc.sized-alloc+0x98>
    f548:      	b	0xf554 <_coil.alloc.sized-alloc+0xa0>
    f54c:      	b	0xf558 <_coil.alloc.sized-alloc+0xa4>
    f550:      	b	0xf564 <_coil.alloc.sized-alloc+0xb0>
    f554:      	b	0xf5b4 <_coil.alloc.sized-alloc+0x100>
    f558:      	movz	x0, #0x0, lsl #48
    f55c:      	movz	x1, #0x0, lsl #48
    f560:      	b	0xf5b0 <_coil.alloc.sized-alloc+0xfc>
    f564:      	add	x16, sp, #0x30
    f568:      	orr	x0, x16, xzr
    f56c:      	add	x0, x0, #0x8
    f570:      	add	x16, sp, #0x30
    f574:      	ldr	x1, [x16, #0x8]
    f578:      	add	x16, sp, #0x60
    f57c:      	str	x1, [x16]
    f580:      	ldr	x1, [x0, #0x8]
    f584:      	add	x16, sp, #0x60
    f588:      	str	x1, [x16, #0x8]
    f58c:      	ldr	x1, [x0, #0x10]
    f590:      	add	x16, sp, #0x60
    f594:      	str	x1, [x16, #0x10]
    f598:      	ldr	x0, [x0, #0x18]
    f59c:      	add	x16, sp, #0x60
    f5a0:      	str	x0, [x16, #0x18]
    f5a4:      	mov	x0, x20
    f5a8:      	add	x1, sp, #0x60
    f5ac:      	bl	0xf5ac <_coil.alloc.sized-alloc+0xf8>
		000000000000f5ac:  ARM64_RELOC_BRANCH26	_coil.alloc.raw-alloc
    f5b0:      	b	0xf4e0 <_coil.alloc.sized-alloc+0x2c>
    f5b4:      	brk	#0
    f5b8:      	b	0xf5b4 <_coil.alloc.sized-alloc+0x100>

000000000000f5bc <_coil.alloc.raw-resize>:
    f5bc:      	sub	sp, sp, #0x10
    f5c0:      	str	x29, [sp]
    f5c4:      	str	x30, [sp, #0x8]
    f5c8:      	mov	x29, sp
    f5cc:      	ldr	x4, [x2, #0x8]
    f5d0:      	cmp	x4, #0x0
    f5d4:      	b.le	0xf650 <_coil.alloc.raw-resize+0x94>
    f5d8:      	ldr	x4, [x2, #0x10]
    f5dc:      	cmp	x4, #0x0
    f5e0:      	b.le	0xf650 <_coil.alloc.raw-resize+0x94>
    f5e4:      	ldr	x4, [x2, #0x18]
    f5e8:      	cmp	x4, #0x0
    f5ec:      	b.le	0xf650 <_coil.alloc.raw-resize+0x94>
    f5f0:      	sub	x5, x4, #0x1
    f5f4:      	and	x4, x5, x4
    f5f8:      	cmp	x4, #0x0
    f5fc:      	b.ne	0xf650 <_coil.alloc.raw-resize+0x94>
    f600:      	ldr	x4, [x3, #0x8]
    f604:      	cmp	x4, #0x0
    f608:      	b.le	0xf650 <_coil.alloc.raw-resize+0x94>
    f60c:      	ldr	x4, [x3, #0x10]
    f610:      	cmp	x4, #0x0
    f614:      	b.le	0xf650 <_coil.alloc.raw-resize+0x94>
    f618:      	ldr	x4, [x3, #0x18]
    f61c:      	cmp	x4, #0x0
    f620:      	b.le	0xf650 <_coil.alloc.raw-resize+0x94>
    f624:      	sub	x5, x4, #0x1
    f628:      	and	x4, x5, x4
    f62c:      	cmp	x4, #0x0
    f630:      	b.ne	0xf650 <_coil.alloc.raw-resize+0x94>
    f634:      	ldr	x4, [x0]
    f638:      	ldr	x0, [x0, #0x8]
    f63c:      	ldr	x0, [x0, #0x8]
    f640:      	mov	x30, x0
    f644:      	mov	x0, x4
    f648:      	blr	x30
    f64c:      	b	0xf654 <_coil.alloc.raw-resize+0x98>
    f650:      	movz	x0, #0x0, lsl #48
    f654:      	ldr	x29, [sp]
    f658:      	ldr	x30, [sp, #0x8]
    f65c:      	add	sp, sp, #0x10
    f660:      	ret

000000000000f664 <_coil.alloc.raw-remap>:
    f664:      	sub	sp, sp, #0x50
    f668:      	str	x29, [sp, #0x10]
    f66c:      	str	x30, [sp, #0x18]
    f670:      	add	x29, sp, #0x10
    f674:      	str	x19, [sp, #0x40]
    f678:      	add	x19, sp, #0x20
    f67c:      	ldr	x4, [x2, #0x8]
    f680:      	cmp	x4, #0x0
    f684:      	b.le	0xf700 <_coil.alloc.raw-remap+0x9c>
    f688:      	ldr	x4, [x2, #0x10]
    f68c:      	cmp	x4, #0x0
    f690:      	b.le	0xf700 <_coil.alloc.raw-remap+0x9c>
    f694:      	ldr	x4, [x2, #0x18]
    f698:      	cmp	x4, #0x0
    f69c:      	b.le	0xf700 <_coil.alloc.raw-remap+0x9c>
    f6a0:      	sub	x5, x4, #0x1
    f6a4:      	and	x4, x5, x4
    f6a8:      	cmp	x4, #0x0
    f6ac:      	b.ne	0xf700 <_coil.alloc.raw-remap+0x9c>
    f6b0:      	ldr	x4, [x3, #0x8]
    f6b4:      	cmp	x4, #0x0
    f6b8:      	b.le	0xf700 <_coil.alloc.raw-remap+0x9c>
    f6bc:      	ldr	x4, [x3, #0x10]
    f6c0:      	cmp	x4, #0x0
    f6c4:      	b.le	0xf700 <_coil.alloc.raw-remap+0x9c>
    f6c8:      	ldr	x4, [x3, #0x18]
    f6cc:      	cmp	x4, #0x0
    f6d0:      	b.le	0xf700 <_coil.alloc.raw-remap+0x9c>
    f6d4:      	sub	x5, x4, #0x1
    f6d8:      	and	x4, x5, x4
    f6dc:      	cmp	x4, #0x0
    f6e0:      	b.ne	0xf700 <_coil.alloc.raw-remap+0x9c>
    f6e4:      	ldr	x4, [x0]
    f6e8:      	ldr	x0, [x0, #0x8]
    f6ec:      	ldr	x0, [x0, #0x10]
    f6f0:      	mov	x30, x0
    f6f4:      	mov	x0, x4
    f6f8:      	blr	x30
    f6fc:      	b	0xf708 <_coil.alloc.raw-remap+0xa4>
    f700:      	movz	x0, #0x0, lsl #48
    f704:      	movz	x1, #0x0, lsl #48
    f708:      	str	x0, [x19]
    f70c:      	str	x1, [x19, #0x8]
    f710:      	ldr	x0, [sp, #0x20]
    f714:      	ldr	x1, [sp, #0x28]
    f718:      	ldr	x19, [sp, #0x40]
    f71c:      	ldr	x29, [sp, #0x10]
    f720:      	ldr	x30, [sp, #0x18]
    f724:      	add	sp, sp, #0x50
    f728:      	ret

000000000000f72c <_coil.alloc.raw-alloc>:
    f72c:      	sub	sp, sp, #0x50
    f730:      	str	x29, [sp, #0x10]
    f734:      	str	x30, [sp, #0x18]
    f738:      	add	x29, sp, #0x10
    f73c:      	str	x19, [sp, #0x40]
    f740:      	add	x19, sp, #0x20
    f744:      	ldr	x2, [x1, #0x8]
    f748:      	cmp	x2, #0x0
    f74c:      	b.le	0xf794 <_coil.alloc.raw-alloc+0x68>
    f750:      	ldr	x2, [x1, #0x10]
    f754:      	cmp	x2, #0x0
    f758:      	b.le	0xf794 <_coil.alloc.raw-alloc+0x68>
    f75c:      	ldr	x2, [x1, #0x18]
    f760:      	cmp	x2, #0x0
    f764:      	b.le	0xf794 <_coil.alloc.raw-alloc+0x68>
    f768:      	sub	x3, x2, #0x1
    f76c:      	and	x2, x3, x2
    f770:      	cmp	x2, #0x0
    f774:      	b.ne	0xf794 <_coil.alloc.raw-alloc+0x68>
    f778:      	ldr	x2, [x0]
    f77c:      	ldr	x0, [x0, #0x8]
    f780:      	ldr	x0, [x0]
    f784:      	mov	x30, x0
    f788:      	mov	x0, x2
    f78c:      	blr	x30
    f790:      	b	0xf79c <_coil.alloc.raw-alloc+0x70>
    f794:      	movz	x0, #0x0, lsl #48
    f798:      	movz	x1, #0x0, lsl #48
    f79c:      	str	x0, [x19]
    f7a0:      	str	x1, [x19, #0x8]
    f7a4:      	ldr	x0, [sp, #0x20]
    f7a8:      	ldr	x1, [sp, #0x28]
    f7ac:      	ldr	x19, [sp, #0x40]
    f7b0:      	ldr	x29, [sp, #0x10]
    f7b4:      	ldr	x30, [sp, #0x18]
    f7b8:      	add	sp, sp, #0x50
    f7bc:      	ret
