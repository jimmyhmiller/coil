
/Users/jimmyhmiller/Documents/Code/projects/coil/.worktrees/stogir-bitcast-chains/build/bitcast-comparison/verify-graph/before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0x8c <_gap_verify_graph+0x8c>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x78 <_gap_verify_graph+0x78>
      60:      	add	x0, sp, #0x30
      64:      	mov	x1, x19
      68:      	mov	x2, #0x1a0              ; =416
      6c:      	bl	0x6c <_gap_verify_graph+0x6c>
		000000000000006c:  ARM64_RELOC_BRANCH26	_memmove
      70:      	add	x16, sp, #0x30
      74:      	ldr	x0, [x16, #0x8]
      78:      	ldr	x19, [sp, #0x1d0]
      7c:      	ldr	x29, [sp]
      80:      	ldr	x30, [sp, #0x8]
      84:      	add	sp, sp, #0x1e0
      88:      	ret
      8c:      	brk	#0
      90:      	b	0x8c <_gap_verify_graph+0x8c>

0000000000000094 <_stogir.verify.integer-operations-target>:
      94:      	sub	sp, sp, #0x70
      98:      	str	x29, [sp]
      9c:      	str	x30, [sp, #0x8]
      a0:      	mov	x29, sp
      a4:      	str	x19, [sp, #0x50]
      a8:      	str	x20, [sp, #0x58]
      ac:      	str	x21, [sp, #0x60]
      b0:      	mov	x19, x8
      b4:      	add	x8, sp, #0x10
      b8:      	mov	x20, x0
      bc:      	mov	w21, w1
      c0:      	bl	0xc0 <_stogir.verify.integer-operations-target+0x2c>
		00000000000000c0:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      c4:      	add	x16, sp, #0x10
      c8:      	ldr	w0, [x16]
      cc:      	lsr	x16, x0, #0
      d0:      	cmp	x16, #0x1
      d4:      	b.eq	0xf0 <_stogir.verify.integer-operations-target+0x5c>
      d8:      	b.lo	0xe0 <_stogir.verify.integer-operations-target+0x4c>
      dc:      	b	0xf4 <_stogir.verify.integer-operations-target+0x60>
      e0:      	cmp	x16, #0x0
      e4:      	b.eq	0xec <_stogir.verify.integer-operations-target+0x58>
      e8:      	b	0xf4 <_stogir.verify.integer-operations-target+0x60>
      ec:      	b	0x118 <_stogir.verify.integer-operations-target+0x84>
      f0:      	b	0xf8 <_stogir.verify.integer-operations-target+0x64>
      f4:      	b	0x168 <_stogir.verify.integer-operations-target+0xd4>
      f8:      	add	x16, sp, #0x10
      fc:      	orr	x0, x16, xzr
     100:      	add	x0, x0, #0x8
     104:      	add	x16, sp, #0x10
     108:      	ldr	x1, [x16, #0x8]
     10c:      	ldr	x0, [x0, #0x8]
     110:      	mov	x2, #0x1                ; =1
     114:      	b	0x140 <_stogir.verify.integer-operations-target+0xac>
     118:      	add	x8, sp, #0x30
     11c:      	mov	x0, x20
     120:      	mov	w1, w21
     124:      	bl	0x124 <_stogir.verify.integer-operations-target+0x90>
		0000000000000124:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     128:      	add	x16, sp, #0x30
     12c:      	ldr	x2, [x16]
     130:      	add	x16, sp, #0x30
     134:      	ldr	x1, [x16, #0x8]
     138:      	add	x16, sp, #0x30
     13c:      	ldr	x0, [x16, #0x10]
     140:      	str	x2, [x19]
     144:      	str	x1, [x19, #0x8]
     148:      	str	x0, [x19, #0x10]
     14c:      	ldr	x19, [sp, #0x50]
     150:      	ldr	x20, [sp, #0x58]
     154:      	ldr	x21, [sp, #0x60]
     158:      	ldr	x29, [sp]
     15c:      	ldr	x30, [sp, #0x8]
     160:      	add	sp, sp, #0x70
     164:      	ret
     168:      	brk	#0
     16c:      	b	0x168 <_stogir.verify.integer-operations-target+0xd4>

0000000000000170 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     170:      	ldr	x0, [x0, #0x8]
     174:      	ret

0000000000000178 <_stogir.verify.structure>:
     178:      	sub	sp, sp, #0x110
     17c:      	str	x29, [sp, #0x10]
     180:      	str	x30, [sp, #0x18]
     184:      	add	x29, sp, #0x10
     188:      	str	x19, [sp, #0xb8]
     18c:      	str	x20, [sp, #0xc0]
     190:      	str	x21, [sp, #0xc8]
     194:      	str	x22, [sp, #0xd0]
     198:      	str	x23, [sp, #0xd8]
     19c:      	str	x24, [sp, #0xe0]
     1a0:      	str	x25, [sp, #0xe8]
     1a4:      	str	x26, [sp, #0xf0]
     1a8:      	str	x27, [sp, #0xf8]
     1ac:      	str	x28, [sp, #0x100]
     1b0:      	mov	x19, x8
     1b4:      	mov	x20, x0
     1b8:      	bl	0x1b8 <_stogir.verify.structure+0x40>
		00000000000001b8:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node
     1bc:      	add	x21, x20, #0x78
     1c0:      	mov	x22, x0
     1c4:      	mov	x0, x21
     1c8:      	bl	0x1c8 <_stogir.verify.structure+0x50>
		00000000000001c8:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
     1cc:      	cmp	x22, x0
     1d0:      	b.ne	0x200 <_stogir.verify.structure+0x88>
     1d4:      	adrp	x22, 0x0 <_gap_verify_graph>
		00000000000001d4:  ARM64_RELOC_PAGE21	l_stogir.311
     1d8:      	ldr	x22, [x22]
		00000000000001d8:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     1dc:      	movz	x23, #0x0, lsl #48
     1e0:      	b	0x20c <_stogir.verify.structure+0x94>
     1e4:      	ldr	x1, [sp, #0x88]
     1e8:      	ldr	x5, [sp, #0x90]
     1ec:      	add	x5, x1, x5
     1f0:      	ldr	x19, [sp, #0x40]
     1f4:      	add	x1, x19, #0x1
     1f8:      	sxtw	x19, w1
     1fc:      	b	0x23c <_stogir.verify.structure+0xc4>
     200:      	adrp	x22, 0x0 <_gap_verify_graph>
		0000000000000200:  ARM64_RELOC_PAGE21	l_stogir.312
     204:      	ldr	x22, [x22]
		0000000000000204:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     208:      	mov	x23, #0x2c              ; =44
     20c:      	add	x24, x20, #0x110
     210:      	add	x25, x20, #0x28
     214:      	add	x26, x20, #0x50
     218:      	add	x27, x24, #0x28
     21c:      	mov	x28, #0x1               ; =1
     220:      	movz	x0, #0x0, lsl #48
     224:      	b	0x294 <_stogir.verify.structure+0x11c>
     228:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000228:  ARM64_RELOC_PAGE21	l_stogir.313
     22c:      	ldr	x16, [x16]
		000000000000022c:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     230:      	str	x16, [sp, #0x38]
     234:      	mov	x16, #0x16              ; =22
     238:      	str	x16, [sp, #0x80]
     23c:      	b	0x270 <_stogir.verify.structure+0xf8>
     240:      	mov	x5, x28
     244:      	str	x19, [sp, #0x30]
     248:      	mov	x19, x0
     24c:      	mov	x0, x21
     250:      	mov	x2, x24
     254:      	mov	x3, x25
     258:      	mov	x4, x26
     25c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000025c:  ARM64_RELOC_PAGE21	l_stogir.314
     260:      	ldr	x16, [x16]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     264:      	str	x16, [sp, #0x38]
     268:      	mov	x16, #0x23              ; =35
     26c:      	str	x16, [sp, #0x80]
     270:      	mov	x21, x0
     274:      	mov	x24, x2
     278:      	mov	x25, x3
     27c:      	mov	x26, x4
     280:      	mov	x28, x5
     284:      	mov	x0, x19
     288:      	ldr	x19, [sp, #0x30]
     28c:      	ldr	x22, [sp, #0x38]
     290:      	ldr	x23, [sp, #0x80]
     294:      	cmp	x23, #0x0
     298:      	b.ne	0xa54 <_stogir.verify.structure+0x8dc>
     29c:      	ldr	x1, [x20, #0x8]
     2a0:      	cmp	x28, x1
     2a4:      	b.ge	0xa68 <_stogir.verify.structure+0x8f0>
     2a8:      	ldr	x1, [x20]
     2ac:      	add	x1, x1, x28, lsl #4
     2b0:      	ldr	x1, [x1]
     2b4:      	ldr	x2, [x20, #0x78]
     2b8:      	add	x2, x2, x28, lsl #2
     2bc:      	ldr	w2, [x2]
     2c0:      	sxtw	x2, w2
     2c4:      	cmp	x2, #0x0
     2c8:      	b.lt	0x240 <_stogir.verify.structure+0xc8>
     2cc:      	mov	x17, #0xffff            ; =65535
     2d0:      	cmp	x2, x17
     2d4:      	b.gt	0xa7c <_stogir.verify.structure+0x904>
     2d8:      	uxtb	w3, w1
     2dc:      	orr	x4, x3, xzr
     2e0:      	cmp	x4, #0x83
     2e4:      	cset	w5, lt
     2e8:      	uxtb	w16, w5
     2ec:      	cmp	w16, wzr
     2f0:      	b.eq	0xa9c <_stogir.verify.structure+0x924>
     2f4:      	ubfx	x1, x1, #0, #32
     2f8:      	ubfx	x6, x1, #8, #8
     2fc:      	orr	x7, x6, xzr
     300:      	str	x0, [sp, #0x40]
     304:      	mov	w0, w7
     308:      	str	x19, [sp, #0x30]
     30c:      	mov	w19, w3
     310:      	str	x22, [sp, #0x38]
     314:      	mov	x22, x2
     318:      	str	x26, [sp, #0x48]
     31c:      	mov	x26, x4
     320:      	str	x25, [sp, #0x50]
     324:      	mov	w25, w5
     328:      	str	x21, [sp, #0x58]
     32c:      	mov	x21, x1
     330:      	str	x24, [sp, #0x60]
     334:      	mov	w24, w6
     338:      	bl	0x338 <_stogir.verify.structure+0x1c0>
		0000000000000338:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     33c:      	cmp	x0, #0x0
     340:      	b.eq	0xabc <_stogir.verify.structure+0x944>
     344:      	adrp	x17, 0x0 <_gap_verify_graph>
		0000000000000344:  ARM64_RELOC_PAGE21	l_stogir.315
     348:      	ldr	x17, [x17]
		0000000000000348:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     34c:      	add	x0, x26, x17
     350:      	ldrsb	w0, [x0]
     354:      	sxtb	x0, w0
     358:      	cmp	x0, #0x0
     35c:      	b.lt	0x774 <_stogir.verify.structure+0x5fc>
     360:      	uxtb	w16, w25
     364:      	cmp	w16, wzr
     368:      	b.eq	0x848 <_stogir.verify.structure+0x6d0>
     36c:      	adrp	x17, 0x0 <_gap_verify_graph>
		000000000000036c:  ARM64_RELOC_PAGE21	l_stogir.315
     370:      	ldr	x17, [x17]
		0000000000000370:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     374:      	add	x0, x26, x17
     378:      	ldrsb	w0, [x0]
     37c:      	sxtb	w0, w0
     380:      	b	0x84c <_stogir.verify.structure+0x6d4>
     384:      	ldr	x0, [sp, #0x38]
     388:      	ldr	x1, [sp, #0x80]
     38c:      	adrp	x2, 0x0 <_gap_verify_graph>
		000000000000038c:  ARM64_RELOC_PAGE21	l_stogir.311
     390:      	ldr	x2, [x2]
		0000000000000390:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     394:      	movz	x3, #0x0, lsl #48
     398:      	bl	0x398 <_stogir.verify.structure+0x220>
		0000000000000398:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
     39c:      	cmp	x0, #0x0
     3a0:      	b.eq	0xad8 <_stogir.verify.structure+0x960>
     3a4:      	and	x0, x19, #0xffffffff
     3a8:      	movz	x1, #0x0, lsl #48
     3ac:      	movz	x16, #0x0, lsl #48
     3b0:      	str	x16, [sp, #0x80]
     3b4:      	b	0x3bc <_stogir.verify.structure+0x244>
     3b8:      	mov	x1, #0x1                ; =1
     3bc:      	ldr	x2, [sp, #0x30]
     3c0:      	str	x1, [x2]
     3c4:      	str	x0, [x2, #0x8]
     3c8:      	ldr	x0, [sp, #0x80]
     3cc:      	str	x0, [x2, #0x10]
     3d0:      	ldr	x19, [sp, #0xb8]
     3d4:      	ldr	x20, [sp, #0xc0]
     3d8:      	ldr	x21, [sp, #0xc8]
     3dc:      	ldr	x22, [sp, #0xd0]
     3e0:      	ldr	x23, [sp, #0xd8]
     3e4:      	ldr	x24, [sp, #0xe0]
     3e8:      	ldr	x25, [sp, #0xe8]
     3ec:      	ldr	x26, [sp, #0xf0]
     3f0:      	ldr	x27, [sp, #0xf8]
     3f4:      	ldr	x28, [sp, #0x100]
     3f8:      	ldr	x29, [sp, #0x10]
     3fc:      	ldr	x30, [sp, #0x18]
     400:      	add	sp, sp, #0x110
     404:      	ret
     408:      	mov	w9, w5
     40c:      	lsl	w9, w9, #2
     410:      	ubfx	x9, x9, #0, #32
     414:      	lsr	x8, x8, x9
     418:      	and	w8, w8, #0xf
     41c:      	b	0x43c <_stogir.verify.structure+0x2c4>
     420:      	movz	x1, #0x0, lsl #48
     424:      	cmp	x1, #0x0
     428:      	b.eq	0x888 <_stogir.verify.structure+0x710>
     42c:      	ldr	w1, [sp, #0xb0]
     430:      	ldr	w5, [sp, #0xa8]
     434:      	b	0x4e4 <_stogir.verify.structure+0x36c>
     438:      	movz	w8, #0x0, lsl #16
     43c:      	b	0x444 <_stogir.verify.structure+0x2cc>
     440:      	movz	w8, #0x0, lsl #16
     444:      	str	w0, [sp, #0x68]
     448:      	str	x2, [sp, #0x98]
     44c:      	mov	w2, w3
     450:      	str	x4, [sp, #0xa0]
     454:      	str	x22, [sp, #0x70]
     458:      	mov	x22, x1
     45c:      	mov	w1, w0
     460:      	mov	x0, x20
     464:      	str	x26, [sp, #0x78]
     468:      	mov	w26, w7
     46c:      	str	x23, [sp, #0x80]
     470:      	mov	w23, w8
     474:      	str	x19, [sp, #0x88]
     478:      	mov	w19, w5
     47c:      	str	x28, [sp, #0x90]
     480:      	mov	w28, w6
     484:      	bl	0x484 <_stogir.verify.structure+0x30c>
		0000000000000484:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     488:      	ubfx	x0, x0, #0, #32
     48c:      	lsr	x16, x0, #0
     490:      	cmp	x16, #0x1
     494:      	b.eq	0x4b0 <_stogir.verify.structure+0x338>
     498:      	b.lo	0x4a0 <_stogir.verify.structure+0x328>
     49c:      	b	0x4b4 <_stogir.verify.structure+0x33c>
     4a0:      	cmp	x16, #0x0
     4a4:      	b.eq	0x4ac <_stogir.verify.structure+0x334>
     4a8:      	b	0x4b4 <_stogir.verify.structure+0x33c>
     4ac:      	b	0x4b8 <_stogir.verify.structure+0x340>
     4b0:      	b	0x598 <_stogir.verify.structure+0x420>
     4b4:      	b	0x9bc <_stogir.verify.structure+0x844>
     4b8:      	ldr	x0, [sp, #0x58]
     4bc:      	ldr	x2, [sp, #0x60]
     4c0:      	mov	w1, w21
     4c4:      	mov	w5, w24
     4c8:      	ldr	x3, [sp, #0x50]
     4cc:      	ldr	x4, [sp, #0x48]
     4d0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000004d0:  ARM64_RELOC_PAGE21	l_stogir.316
     4d4:      	ldr	x16, [x16]
		00000000000004d4:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     4d8:      	str	x16, [sp, #0x38]
     4dc:      	mov	x16, #0x17              ; =23
     4e0:      	str	x16, [sp, #0x80]
     4e4:      	ldr	x6, [sp, #0x98]
     4e8:      	add	x6, x6, #0x1
     4ec:      	sxtw	x6, w6
     4f0:      	ldr	x28, [sp, #0x90]
     4f4:      	str	x0, [sp, #0x58]
     4f8:      	ldr	x19, [sp, #0x88]
     4fc:      	ldr	w0, [sp, #0x68]
     500:      	str	x2, [sp, #0x60]
     504:      	ldr	x26, [sp, #0x78]
     508:      	mov	w21, w1
     50c:      	mov	w24, w5
     510:      	mov	x1, x22
     514:      	ldr	x22, [sp, #0x70]
     518:      	str	x3, [sp, #0x50]
     51c:      	str	x4, [sp, #0x48]
     520:      	mov	x2, x6
     524:      	ldr	x23, [sp, #0x80]
     528:      	cmp	x23, #0x0
     52c:      	b.ne	0x540 <_stogir.verify.structure+0x3c8>
     530:      	cmp	x2, x22
     534:      	cset	w3, le
     538:      	ubfx	x3, x3, #0, #8
     53c:      	b	0x544 <_stogir.verify.structure+0x3cc>
     540:      	movz	x3, #0x0, lsl #48
     544:      	cmp	x3, #0x0
     548:      	b.eq	0xae0 <_stogir.verify.structure+0x968>
     54c:      	orr	w3, w2, wzr
     550:      	sxtw	x4, w3
     554:      	sub	w5, w3, #0x1
     558:      	cmp	x4, #0x0
     55c:      	cset	w6, gt
     560:      	cmp	x4, #0x4
     564:      	cset	w7, gt
     568:      	uxtb	w16, w25
     56c:      	cmp	w16, wzr
     570:      	b.eq	0x440 <_stogir.verify.structure+0x2c8>
     574:      	ldr	w8, [x26]
     578:      	uxtb	w16, w6
     57c:      	cmp	w16, wzr
     580:      	b.eq	0x438 <_stogir.verify.structure+0x2c0>
     584:      	uxtb	w16, w7
     588:      	cmp	w16, wzr
     58c:      	b.eq	0x408 <_stogir.verify.structure+0x290>
     590:      	mov	w9, #0x4                ; =4
     594:      	b	0x40c <_stogir.verify.structure+0x294>
     598:      	ubfx	x23, x23, #0, #32
     59c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000059c:  ARM64_RELOC_PAGE21	l_stogir.317
     5a0:      	ldr	x16, [x16]
		00000000000005a0:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     5a4:      	ldr	w0, [x16]
     5a8:      	cmp	x23, x0
     5ac:      	b.ne	0x5c0 <_stogir.verify.structure+0x448>
     5b0:      	mov	x0, #0x1                ; =1
     5b4:      	b	0x5d8 <_stogir.verify.structure+0x460>
     5b8:      	movz	x1, #0x0, lsl #48
     5bc:      	b	0x638 <_stogir.verify.structure+0x4c0>
     5c0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000005c0:  ARM64_RELOC_PAGE21	l_stogir.318
     5c4:      	ldr	x16, [x16]
		00000000000005c4:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     5c8:      	ldr	w0, [x16]
     5cc:      	cmp	x23, x0
     5d0:      	cset	w0, eq
     5d4:      	ubfx	x0, x0, #0, #8
     5d8:      	cmp	x0, #0x0
     5dc:      	b.eq	0xb00 <_stogir.verify.structure+0x988>
     5e0:      	str	w24, [sp, #0xa8]
     5e4:      	mov	x24, x0
     5e8:      	mov	x0, x20
     5ec:      	str	w21, [sp, #0xb0]
     5f0:      	mov	w21, w1
     5f4:      	bl	0x5f4 <_stogir.verify.structure+0x47c>
		00000000000005f4:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     5f8:      	cmp	x0, #0x0
     5fc:      	cset	w1, eq
     600:      	uxtb	w16, w1
     604:      	cmp	w16, wzr
     608:      	cset	x1, eq
     60c:      	cmp	x1, #0x0
     610:      	b.eq	0x638 <_stogir.verify.structure+0x4c0>
     614:      	ldr	w0, [x0]
     618:      	uxtb	w0, w0
     61c:      	cmp	x0, #0x48
     620:      	b.ne	0x638 <_stogir.verify.structure+0x4c0>
     624:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000624:  ARM64_RELOC_PAGE21	l_stogir.319
     628:      	ldr	x16, [x16]
		0000000000000628:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     62c:      	str	x16, [sp, #0x38]
     630:      	mov	x16, #0x25              ; =37
     634:      	str	x16, [sp, #0x80]
     638:      	sxtw	x21, w21
     63c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000063c:  ARM64_RELOC_PAGE21	l_stogir.320
     640:      	ldr	x16, [x16]
		0000000000000640:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     644:      	ldr	w0, [x16]
     648:      	cmp	x23, x0
     64c:      	b.ne	0xb14 <_stogir.verify.structure+0x99c>
     650:      	cmp	x21, #0x0
     654:      	b.gt	0x7e4 <_stogir.verify.structure+0x66c>
     658:      	ldr	x2, [sp, #0x60]
     65c:      	movz	w0, #0x0, lsl #16
     660:      	ubfx	x0, x0, #0, #32
     664:      	lsr	x16, x0, #0
     668:      	cmp	x16, #0x1
     66c:      	b.eq	0x688 <_stogir.verify.structure+0x510>
     670:      	b.lo	0x678 <_stogir.verify.structure+0x500>
     674:      	b	0x68c <_stogir.verify.structure+0x514>
     678:      	cmp	x16, #0x0
     67c:      	b.eq	0x684 <_stogir.verify.structure+0x50c>
     680:      	b	0x68c <_stogir.verify.structure+0x514>
     684:      	b	0x690 <_stogir.verify.structure+0x518>
     688:      	b	0x6a4 <_stogir.verify.structure+0x52c>
     68c:      	b	0xa4c <_stogir.verify.structure+0x8d4>
     690:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000690:  ARM64_RELOC_PAGE21	l_stogir.321
     694:      	ldr	x16, [x16]
		0000000000000694:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     698:      	str	x16, [sp, #0x38]
     69c:      	mov	x16, #0x21              ; =33
     6a0:      	str	x16, [sp, #0x80]
     6a4:      	cmp	x23, #0xf
     6a8:      	b.hs	0xb1c <_stogir.verify.structure+0x9a4>
     6ac:      	mov	x16, #0x1               ; =1
     6b0:      	lsl	x0, x16, x23
     6b4:      	mov	w17, #0x5e1c            ; =24092
     6b8:      	and	w0, w0, w17
     6bc:      	ubfx	x0, x0, #0, #32
     6c0:      	cmp	x0, #0x0
     6c4:      	b.eq	0xb34 <_stogir.verify.structure+0x9bc>
     6c8:      	cmp	x24, #0x0
     6cc:      	b.eq	0x8d0 <_stogir.verify.structure+0x758>
     6d0:      	ldr	x0, [sp, #0x58]
     6d4:      	ldr	x3, [sp, #0x50]
     6d8:      	ldr	x4, [sp, #0x48]
     6dc:      	b	0x424 <_stogir.verify.structure+0x2ac>
     6e0:      	orr	w0, w28, wzr
     6e4:      	cmp	x26, #0x78
     6e8:      	cset	w21, eq
     6ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000006ec:  ARM64_RELOC_PAGE21	l_stogir.322
     6f0:      	ldr	x16, [x16]
		00000000000006f0:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     6f4:      	add	x1, x16, x26, lsl #2
     6f8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000006f8:  ARM64_RELOC_PAGE21	l_stogir.322
     6fc:      	ldr	x16, [x16]
		00000000000006fc:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     700:      	add	x2, x16, x26, lsl #2
     704:      	cmp	x24, #0x0
     708:      	cset	w24, eq
     70c:      	orr	x26, x1, xzr
     710:      	orr	x1, x2, xzr
     714:      	mov	x2, #0x1                ; =1
     718:      	b	0x528 <_stogir.verify.structure+0x3b0>
     71c:      	nop
     720:      	movz	x1, #0x0, lsl #48
     724:      	cmp	x1, #0x0
     728:      	b.eq	0x6e0 <_stogir.verify.structure+0x568>
     72c:      	add	x1, x0, x28
     730:      	ldr	x2, [x20, #0x78]
     734:      	add	x1, x2, x1, lsl #2
     738:      	ldr	w1, [x1]
     73c:      	sxtw	x1, w1
     740:      	cmn	x1, #0x1
     744:      	b.eq	0x758 <_stogir.verify.structure+0x5e0>
     748:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000748:  ARM64_RELOC_PAGE21	l_stogir.323
     74c:      	ldr	x16, [x16]
		000000000000074c:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     750:      	str	x16, [sp, #0x38]
     754:      	mov	x23, #0x1b              ; =27
     758:      	add	x0, x0, #0x1
     75c:      	cmp	x23, #0x0
     760:      	b.ne	0x720 <_stogir.verify.structure+0x5a8>
     764:      	cmp	x0, x19
     768:      	cset	w1, lt
     76c:      	ubfx	x1, x1, #0, #8
     770:      	b	0x724 <_stogir.verify.structure+0x5ac>
     774:      	mov	w0, w19
     778:      	bl	0x778 <_stogir.verify.structure+0x600>
		0000000000000778:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     77c:      	sxtw	x0, w0
     780:      	cmn	x0, #0x1
     784:      	b.ne	0x7a4 <_stogir.verify.structure+0x62c>
     788:      	ubfx	x0, x21, #16, #16
     78c:      	cmp	x22, x0
     790:      	b.eq	0x7a4 <_stogir.verify.structure+0x62c>
     794:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000794:  ARM64_RELOC_PAGE21	l_stogir.324
     798:      	ldr	x16, [x16]
		0000000000000798:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     79c:      	str	x16, [sp, #0x38]
     7a0:      	mov	x23, #0x24              ; =36
     7a4:      	add	x0, x22, #0x4
     7a8:      	ldr	x1, [x20, #0x8]
     7ac:      	asr	x16, x0, #63
     7b0:      	lsr	x16, x16, #62
     7b4:      	add	x0, x0, x16
     7b8:      	asr	x0, x0, #2
     7bc:      	orr	x19, x0, xzr
     7c0:      	add	x0, x19, x28
     7c4:      	cmp	x0, x1
     7c8:      	b.le	0x7dc <_stogir.verify.structure+0x664>
     7cc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007cc:  ARM64_RELOC_PAGE21	l_stogir.325
     7d0:      	ldr	x16, [x16]
		00000000000007d0:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     7d4:      	str	x16, [sp, #0x38]
     7d8:      	mov	x23, #0x15              ; =21
     7dc:      	mov	x0, #0x1                ; =1
     7e0:      	b	0x75c <_stogir.verify.structure+0x5e4>
     7e4:      	ldr	x0, [x27, #0x8]
     7e8:      	cmp	x21, x0
     7ec:      	b.gt	0xb4c <_stogir.verify.structure+0x9d4>
     7f0:      	sub	x0, x21, #0x1
     7f4:      	ldr	x2, [sp, #0x60]
     7f8:      	ldr	x3, [x2, #0x28]
     7fc:      	mov	x17, #0x18              ; =24
     800:      	mul	x0, x0, x17
     804:      	add	x0, x0, x3
     808:      	ldr	x3, [x0]
     80c:      	ldr	x0, [x0, #0x8]
     810:      	ldr	x4, [x2, #0x8]
     814:      	cmp	x3, #0x0
     818:      	b.lt	0x840 <_stogir.verify.structure+0x6c8>
     81c:      	cmp	x3, x4
     820:      	b.gt	0x840 <_stogir.verify.structure+0x6c8>
     824:      	cmp	x0, #0x0
     828:      	b.lt	0x840 <_stogir.verify.structure+0x6c8>
     82c:      	sub	x3, x4, x3
     830:      	cmp	x0, x3
     834:      	b.gt	0x840 <_stogir.verify.structure+0x6c8>
     838:      	mov	w0, #0x1                ; =1
     83c:      	b	0x844 <_stogir.verify.structure+0x6cc>
     840:      	movz	w0, #0x0, lsl #16
     844:      	b	0x660 <_stogir.verify.structure+0x4e8>
     848:      	mov	w0, #-0x2               ; =-2
     84c:      	sxtw	x0, w0
     850:      	cmp	x22, x0
     854:      	b.eq	0x774 <_stogir.verify.structure+0x5fc>
     858:      	ldr	x0, [sp, #0x58]
     85c:      	ldr	x2, [sp, #0x60]
     860:      	ldr	x3, [sp, #0x50]
     864:      	ldr	x4, [sp, #0x48]
     868:      	mov	x5, x28
     86c:      	ldr	x19, [sp, #0x40]
     870:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000870:  ARM64_RELOC_PAGE21	l_stogir.326
     874:      	ldr	x16, [x16]
		0000000000000874:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     878:      	str	x16, [sp, #0x38]
     87c:      	mov	x16, #0x23              ; =35
     880:      	str	x16, [sp, #0x80]
     884:      	b	0x1fc <_stogir.verify.structure+0x84>
     888:      	cmp	x21, #0x0
     88c:      	b.ne	0xb54 <_stogir.verify.structure+0x9dc>
     890:      	uxtb	w16, w25
     894:      	cmp	w16, wzr
     898:      	b.eq	0x9c4 <_stogir.verify.structure+0x84c>
     89c:      	ldr	w1, [x22]
     8a0:      	uxtb	w16, w28
     8a4:      	cmp	w16, wzr
     8a8:      	b.eq	0xa0c <_stogir.verify.structure+0x894>
     8ac:      	uxtb	w16, w26
     8b0:      	cmp	w16, wzr
     8b4:      	b.eq	0x8bc <_stogir.verify.structure+0x744>
     8b8:      	mov	w19, #0x4               ; =4
     8bc:      	lsl	w5, w19, #2
     8c0:      	ubfx	x5, x5, #0, #32
     8c4:      	lsr	x1, x1, x5
     8c8:      	and	w1, w1, #0xf
     8cc:      	b	0xa10 <_stogir.verify.structure+0x898>
     8d0:      	cmp	x21, #0x0
     8d4:      	b.le	0xb60 <_stogir.verify.structure+0x9e8>
     8d8:      	ldr	x0, [x20, #0x8]
     8dc:      	cmp	x21, x0
     8e0:      	b.ge	0xb68 <_stogir.verify.structure+0x9f0>
     8e4:      	ldr	x0, [sp, #0x58]
     8e8:      	ldr	x1, [x0, #0x8]
     8ec:      	cmp	x21, x1
     8f0:      	b.ge	0xa1c <_stogir.verify.structure+0x8a4>
     8f4:      	ldr	x1, [x20, #0x78]
     8f8:      	add	x1, x1, x21, lsl #2
     8fc:      	ldr	w1, [x1]
     900:      	sxtw	x1, w1
     904:      	cmp	x1, #0x0
     908:      	cset	w1, ge
     90c:      	ubfx	x1, x1, #0, #8
     910:      	b	0xa20 <_stogir.verify.structure+0x8a8>
     914:      	ldr	w1, [sp, #0xb0]
     918:      	uxtb	w16, w1
     91c:      	cmp	w16, wzr
     920:      	b.eq	0xb70 <_stogir.verify.structure+0x9f8>
     924:      	ldr	w5, [sp, #0xa8]
     928:      	uxtb	w16, w5
     92c:      	cmp	w16, wzr
     930:      	b.eq	0x940 <_stogir.verify.structure+0x7c8>
     934:      	ldr	x6, [sp, #0xa0]
     938:      	cmp	x6, #0x2
     93c:      	b.eq	0x434 <_stogir.verify.structure+0x2bc>
     940:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000940:  ARM64_RELOC_PAGE21	l_stogir.327
     944:      	ldr	x16, [x16]
		0000000000000944:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     948:      	str	x16, [sp, #0x38]
     94c:      	mov	x16, #0x1a              ; =26
     950:      	str	x16, [sp, #0x80]
     954:      	b	0x434 <_stogir.verify.structure+0x2bc>
     958:      	movz	x1, #0x0, lsl #48
     95c:      	ldr	x3, [sp, #0x50]
     960:      	ldr	x4, [sp, #0x48]
     964:      	b	0x424 <_stogir.verify.structure+0x2ac>
     968:      	cmp	x21, #0x0
     96c:      	b.ge	0xb78 <_stogir.verify.structure+0xa00>
     970:      	ldr	x3, [sp, #0x50]
     974:      	ldr	x1, [x3, #0x8]
     978:      	ldr	x4, [sp, #0x48]
     97c:      	ldr	x5, [x4, #0x8]
     980:      	cmp	x1, x5
     984:      	b.ne	0xa14 <_stogir.verify.structure+0x89c>
     988:      	movz	x16, #0x0, lsl #48
     98c:      	sub	x5, x16, x21
     990:      	cmp	x5, x1
     994:      	b.gt	0xa44 <_stogir.verify.structure+0x8cc>
     998:      	sub	x1, x5, #0x1
     99c:      	ldr	x5, [x20, #0x50]
     9a0:      	add	x1, x5, x1, lsl #2
     9a4:      	ldr	w1, [x1]
     9a8:      	sxtw	x1, w1
     9ac:      	cmp	x1, #0x0
     9b0:      	cset	w1, gt
     9b4:      	ubfx	x1, x1, #0, #8
     9b8:      	b	0xa48 <_stogir.verify.structure+0x8d0>
     9bc:      	brk	#0
     9c0:      	b	0x9bc <_stogir.verify.structure+0x844>
     9c4:      	movz	w1, #0x0, lsl #16
     9c8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000009c8:  ARM64_RELOC_PAGE21	l_stogir.328
     9cc:      	ldr	x16, [x16]
		00000000000009cc:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     9d0:      	ldr	w5, [x16]
     9d4:      	ubfx	x1, x1, #0, #32
     9d8:      	cmp	x1, x5
     9dc:      	b.ne	0x9ec <_stogir.verify.structure+0x874>
     9e0:      	ldr	w1, [sp, #0xb0]
     9e4:      	ldr	w5, [sp, #0xa8]
     9e8:      	b	0x434 <_stogir.verify.structure+0x2bc>
     9ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000009ec:  ARM64_RELOC_PAGE21	l_stogir.329
     9f0:      	ldr	x16, [x16]
		00000000000009f0:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     9f4:      	ldr	w5, [x16]
     9f8:      	cmp	x1, x5
     9fc:      	b.ne	0xa24 <_stogir.verify.structure+0x8ac>
     a00:      	ldr	w1, [sp, #0xb0]
     a04:      	ldr	w5, [sp, #0xa8]
     a08:      	b	0x434 <_stogir.verify.structure+0x2bc>
     a0c:      	movz	w1, #0x0, lsl #16
     a10:      	b	0x9c8 <_stogir.verify.structure+0x850>
     a14:      	movz	x1, #0x0, lsl #48
     a18:      	b	0x424 <_stogir.verify.structure+0x2ac>
     a1c:      	movz	x1, #0x0, lsl #48
     a20:      	b	0x95c <_stogir.verify.structure+0x7e4>
     a24:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000a24:  ARM64_RELOC_PAGE21	l_stogir.330
     a28:      	ldr	x16, [x16]
		0000000000000a28:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     a2c:      	ldr	w5, [x16]
     a30:      	cmp	x1, x5
     a34:      	b.ne	0x914 <_stogir.verify.structure+0x79c>
     a38:      	ldr	w1, [sp, #0xb0]
     a3c:      	ldr	w5, [sp, #0xa8]
     a40:      	b	0x434 <_stogir.verify.structure+0x2bc>
     a44:      	movz	x1, #0x0, lsl #48
     a48:      	b	0xa18 <_stogir.verify.structure+0x8a0>
     a4c:      	brk	#0
     a50:      	b	0xa4c <_stogir.verify.structure+0x8d4>
     a54:      	str	x19, [sp, #0x30]
     a58:      	mov	x19, x0
     a5c:      	str	x22, [sp, #0x38]
     a60:      	str	x23, [sp, #0x80]
     a64:      	b	0x384 <_stogir.verify.structure+0x20c>
     a68:      	str	x19, [sp, #0x30]
     a6c:      	mov	x19, x0
     a70:      	str	x22, [sp, #0x38]
     a74:      	str	x23, [sp, #0x80]
     a78:      	b	0x384 <_stogir.verify.structure+0x20c>
     a7c:      	mov	x5, x28
     a80:      	str	x19, [sp, #0x30]
     a84:      	mov	x19, x0
     a88:      	mov	x0, x21
     a8c:      	mov	x2, x24
     a90:      	mov	x3, x25
     a94:      	mov	x4, x26
     a98:      	b	0x25c <_stogir.verify.structure+0xe4>
     a9c:      	mov	x5, x28
     aa0:      	str	x19, [sp, #0x30]
     aa4:      	mov	x19, x0
     aa8:      	mov	x0, x21
     aac:      	mov	x2, x24
     ab0:      	mov	x3, x25
     ab4:      	mov	x4, x26
     ab8:      	b	0x228 <_stogir.verify.structure+0xb0>
     abc:      	mov	x5, x28
     ac0:      	ldr	x19, [sp, #0x40]
     ac4:      	ldr	x0, [sp, #0x58]
     ac8:      	ldr	x2, [sp, #0x60]
     acc:      	ldr	x3, [sp, #0x50]
     ad0:      	ldr	x4, [sp, #0x48]
     ad4:      	b	0x228 <_stogir.verify.structure+0xb0>
     ad8:      	ldr	x0, [sp, #0x38]
     adc:      	b	0x3b8 <_stogir.verify.structure+0x240>
     ae0:      	str	x28, [sp, #0x90]
     ae4:      	ldr	x0, [sp, #0x58]
     ae8:      	str	x19, [sp, #0x88]
     aec:      	ldr	x2, [sp, #0x60]
     af0:      	str	x23, [sp, #0x80]
     af4:      	ldr	x3, [sp, #0x50]
     af8:      	ldr	x4, [sp, #0x48]
     afc:      	b	0x1e4 <_stogir.verify.structure+0x6c>
     b00:      	str	w21, [sp, #0xb0]
     b04:      	mov	w21, w1
     b08:      	str	w24, [sp, #0xa8]
     b0c:      	mov	x24, x0
     b10:      	b	0x5b8 <_stogir.verify.structure+0x440>
     b14:      	ldr	x2, [sp, #0x60]
     b18:      	b	0x6a4 <_stogir.verify.structure+0x52c>
     b1c:      	ldr	x0, [sp, #0x58]
     b20:      	ldr	w1, [sp, #0xb0]
     b24:      	ldr	w5, [sp, #0xa8]
     b28:      	ldr	x3, [sp, #0x50]
     b2c:      	ldr	x4, [sp, #0x48]
     b30:      	b	0x434 <_stogir.verify.structure+0x2bc>
     b34:      	ldr	x0, [sp, #0x58]
     b38:      	ldr	w1, [sp, #0xb0]
     b3c:      	ldr	w5, [sp, #0xa8]
     b40:      	ldr	x3, [sp, #0x50]
     b44:      	ldr	x4, [sp, #0x48]
     b48:      	b	0x434 <_stogir.verify.structure+0x2bc>
     b4c:      	ldr	x2, [sp, #0x60]
     b50:      	b	0x65c <_stogir.verify.structure+0x4e4>
     b54:      	ldr	w1, [sp, #0xb0]
     b58:      	ldr	w5, [sp, #0xa8]
     b5c:      	b	0x940 <_stogir.verify.structure+0x7c8>
     b60:      	ldr	x0, [sp, #0x58]
     b64:      	b	0x968 <_stogir.verify.structure+0x7f0>
     b68:      	ldr	x0, [sp, #0x58]
     b6c:      	b	0x958 <_stogir.verify.structure+0x7e0>
     b70:      	ldr	w5, [sp, #0xa8]
     b74:      	b	0x940 <_stogir.verify.structure+0x7c8>
     b78:      	ldr	x3, [sp, #0x50]
     b7c:      	ldr	x4, [sp, #0x48]
     b80:      	b	0x420 <_stogir.verify.structure+0x2a8>

0000000000000b84 <_stogir.verify.integer-operations-target-structured>:
     b84:      	sub	sp, sp, #0x340
     b88:      	str	x29, [sp, #0x10]
     b8c:      	str	x30, [sp, #0x18]
     b90:      	add	x29, sp, #0x10
     b94:      	str	x19, [sp, #0x2f0]
     b98:      	str	x20, [sp, #0x2f8]
     b9c:      	str	x21, [sp, #0x300]
     ba0:      	str	x22, [sp, #0x308]
     ba4:      	str	x23, [sp, #0x310]
     ba8:      	str	x24, [sp, #0x318]
     bac:      	str	x25, [sp, #0x320]
     bb0:      	str	x26, [sp, #0x328]
     bb4:      	str	x27, [sp, #0x330]
     bb8:      	str	x28, [sp, #0x338]
     bbc:      	orr	w19, w1, wzr
     bc0:      	orr	w20, w1, wzr
     bc4:      	orr	w21, w1, wzr
     bc8:      	add	x22, x0, #0x78
     bcc:      	add	x23, x0, #0x28
     bd0:      	add	x24, x0, #0x50
     bd4:      	add	x16, sp, #0x30
     bd8:      	orr	x1, x16, xzr
     bdc:      	add	x25, x1, #0x8
     be0:      	add	x16, sp, #0x50
     be4:      	orr	x1, x16, xzr
     be8:      	add	x26, x1, #0x8
     bec:      	add	x16, sp, #0xe0
     bf0:      	orr	x1, x16, xzr
     bf4:      	add	x27, x1, #0x8
     bf8:      	add	x16, sp, #0x100
     bfc:      	orr	x1, x16, xzr
     c00:      	add	x28, x1, #0x8
     c04:      	add	x16, sp, #0x120
     c08:      	orr	x1, x16, xzr
     c0c:      	add	x1, x1, #0x8
     c10:      	add	x16, sp, #0x140
     c14:      	orr	x2, x16, xzr
     c18:      	add	x2, x2, #0x8
     c1c:      	add	x16, sp, #0x160
     c20:      	orr	x3, x16, xzr
     c24:      	add	x3, x3, #0x8
     c28:      	add	x16, sp, #0x180
     c2c:      	orr	x4, x16, xzr
     c30:      	add	x4, x4, #0x8
     c34:      	add	x16, sp, #0x1a0
     c38:      	orr	x5, x16, xzr
     c3c:      	add	x5, x5, #0x8
     c40:      	add	x16, sp, #0x1f0
     c44:      	orr	x6, x16, xzr
     c48:      	add	x6, x6, #0x8
     c4c:      	mov	x7, #0x1                ; =1
     c50:      	movz	x9, #0x0, lsl #48
     c54:      	adrp	x10, 0x0 <_gap_verify_graph>
		0000000000000c54:  ARM64_RELOC_PAGE21	l_stogir.331
     c58:      	ldr	x10, [x10]
		0000000000000c58:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     c5c:      	movz	x11, #0x0, lsl #48
     c60:      	cmp	x11, #0x0
     c64:      	b.ne	0x1be4 <_stogir.verify.integer-operations-target-structured+0x1060>
     c68:      	ldr	x12, [x0, #0x8]
     c6c:      	cmp	x7, x12
     c70:      	b.ge	0x1bf8 <_stogir.verify.integer-operations-target-structured+0x1074>
     c74:      	ldr	x12, [x0]
     c78:      	add	x12, x12, x7, lsl #4
     c7c:      	ldr	x13, [x12]
     c80:      	uxtb	w14, w13
     c84:      	ldr	x12, [x12, #0x8]
     c88:      	orr	x15, x14, xzr
     c8c:      	add	x16, sp, #0x20
     c90:      	str	x13, [x16]
     c94:      	add	x16, sp, #0x20
     c98:      	str	x12, [x16, #0x8]
     c9c:      	ldr	x12, [x0, #0x78]
     ca0:      	add	x12, x12, x7, lsl #2
     ca4:      	ldr	w12, [x12]
     ca8:      	cmp	x15, #0x83
     cac:      	b.ge	0x1468 <_stogir.verify.integer-operations-target-structured+0x8e4>
     cb0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cb0:  ARM64_RELOC_PAGE21	l_stogir.332
     cb4:      	ldr	x16, [x16]
		0000000000000cb4:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     cb8:      	add	x13, x16, x15, lsl #1
     cbc:      	ldrh	w13, [x13]
     cc0:      	cmp	x15, #0xe
     cc4:      	b.lt	0x1c0c <_stogir.verify.integer-operations-target-structured+0x1088>
     cc8:      	str	x0, [sp, #0x230]
     ccc:      	cmp	x15, #0x17
     cd0:      	cset	w0, le
     cd4:      	ubfx	x0, x0, #0, #8
     cd8:      	str	x0, [sp, #0x238]
     cdc:      	orr	w0, w7, wzr
     ce0:      	str	x1, [sp, #0x240]
     ce4:      	and	w1, w13, #0x4
     ce8:      	ubfx	x1, x1, #0, #32
     cec:      	str	x8, [sp, #0x260]
     cf0:      	str	x2, [sp, #0x2b8]
     cf4:      	add	x2, sp, #0x20
     cf8:      	str	x3, [sp, #0x2a8]
     cfc:      	mov	w3, w12
     d00:      	str	x4, [sp, #0x298]
     d04:      	str	x5, [sp, #0x290]
     d08:      	str	x6, [sp, #0x288]
     d0c:      	str	x7, [sp, #0x280]
     d10:      	str	w14, [sp, #0x2a0]
     d14:      	str	w12, [sp, #0x2b0]
     d18:      	str	w0, [sp, #0x2c0]
     d1c:      	str	w19, [sp, #0x248]
     d20:      	mov	w19, w13
     d24:      	str	w20, [sp, #0x250]
     d28:      	mov	x20, x9
     d2c:      	str	w21, [sp, #0x258]
     d30:      	mov	x21, x1
     d34:      	mov	w1, w0
     d38:      	ldr	x0, [sp, #0x230]
     d3c:      	str	x24, [sp, #0x268]
     d40:      	mov	x24, x15
     d44:      	str	x23, [sp, #0x270]
     d48:      	mov	x23, x11
     d4c:      	str	x22, [sp, #0x278]
     d50:      	mov	x22, x10
     d54:      	bl	0xd54 <_stogir.verify.integer-operations-target-structured+0x1d0>
		0000000000000d54:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
     d58:      	uxtb	w1, w0
     d5c:      	cmp	x1, #0x0
     d60:      	cset	w1, ne
     d64:      	cmp	x21, #0x0
     d68:      	b.ne	0x1478 <_stogir.verify.integer-operations-target-structured+0x8f4>
     d6c:      	uxtb	w16, w1
     d70:      	cmp	w16, wzr
     d74:      	b.ne	0x1478 <_stogir.verify.integer-operations-target-structured+0x8f4>
     d78:      	str	x0, [sp, #0x2c8]
     d7c:      	mov	w21, w1
     d80:      	cmp	x24, #0x44
     d84:      	b.ne	0x14ec <_stogir.verify.integer-operations-target-structured+0x968>
     d88:      	uxtb	w16, w21
     d8c:      	cmp	w16, wzr
     d90:      	b.eq	0x14e4 <_stogir.verify.integer-operations-target-structured+0x960>
     d94:      	movz	x0, #0x0, lsl #48
     d98:      	cmp	x0, #0x0
     d9c:      	b.eq	0xdf0 <_stogir.verify.integer-operations-target-structured+0x26c>
     da0:      	add	x8, sp, #0x50
     da4:      	ldr	x0, [sp, #0x230]
     da8:      	ldr	w1, [sp, #0x2c0]
     dac:      	bl	0xdac <_stogir.verify.integer-operations-target-structured+0x228>
		0000000000000dac:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
     db0:      	add	x16, sp, #0x50
     db4:      	ldr	w0, [x16]
     db8:      	lsr	x16, x0, #0
     dbc:      	cmp	x16, #0x1
     dc0:      	b.eq	0xddc <_stogir.verify.integer-operations-target-structured+0x258>
     dc4:      	b.lo	0xdcc <_stogir.verify.integer-operations-target-structured+0x248>
     dc8:      	b	0xde0 <_stogir.verify.integer-operations-target-structured+0x25c>
     dcc:      	cmp	x16, #0x0
     dd0:      	b.eq	0xdd8 <_stogir.verify.integer-operations-target-structured+0x254>
     dd4:      	b	0xde0 <_stogir.verify.integer-operations-target-structured+0x25c>
     dd8:      	b	0x14f4 <_stogir.verify.integer-operations-target-structured+0x970>
     ddc:      	b	0xde4 <_stogir.verify.integer-operations-target-structured+0x260>
     de0:      	b	0x1500 <_stogir.verify.integer-operations-target-structured+0x97c>
     de4:      	add	x16, sp, #0x50
     de8:      	ldr	x22, [x16, #0x8]
     dec:      	ldr	x23, [x26, #0x8]
     df0:      	cmp	x24, #0x1d
     df4:      	b.ne	0x1508 <_stogir.verify.integer-operations-target-structured+0x984>
     df8:      	mov	x0, #0x1                ; =1
     dfc:      	cmp	x0, #0x0
     e00:      	b.eq	0x1520 <_stogir.verify.integer-operations-target-structured+0x99c>
     e04:      	add	x16, sp, #0x20
     e08:      	ldr	w0, [x16, #0xc]
     e0c:      	sxtw	x0, w0
     e10:      	cmp	x0, #0x0
     e14:      	b.ne	0x1518 <_stogir.verify.integer-operations-target-structured+0x994>
     e18:      	movz	x0, #0x0, lsl #48
     e1c:      	cmp	x0, #0x0
     e20:      	b.eq	0xe7c <_stogir.verify.integer-operations-target-structured+0x2f8>
     e24:      	add	x16, sp, #0x20
     e28:      	ldr	w0, [x16, #0xc]
     e2c:      	add	x8, sp, #0x70
     e30:      	mov	w1, w0
     e34:      	ldr	x0, [sp, #0x230]
     e38:      	bl	0xe38 <_stogir.verify.integer-operations-target-structured+0x2b4>
		0000000000000e38:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
     e3c:      	add	x16, sp, #0x70
     e40:      	ldr	w0, [x16]
     e44:      	lsr	x16, x0, #0
     e48:      	cmp	x16, #0x1
     e4c:      	b.eq	0xe68 <_stogir.verify.integer-operations-target-structured+0x2e4>
     e50:      	b.lo	0xe58 <_stogir.verify.integer-operations-target-structured+0x2d4>
     e54:      	b	0xe6c <_stogir.verify.integer-operations-target-structured+0x2e8>
     e58:      	cmp	x16, #0x0
     e5c:      	b.eq	0xe64 <_stogir.verify.integer-operations-target-structured+0x2e0>
     e60:      	b	0xe6c <_stogir.verify.integer-operations-target-structured+0x2e8>
     e64:      	b	0xe70 <_stogir.verify.integer-operations-target-structured+0x2ec>
     e68:      	b	0x1528 <_stogir.verify.integer-operations-target-structured+0x9a4>
     e6c:      	b	0x15d0 <_stogir.verify.integer-operations-target-structured+0xa4c>
     e70:      	adrp	x22, 0x0 <_gap_verify_graph>
		0000000000000e70:  ARM64_RELOC_PAGE21	l_stogir.333
     e74:      	ldr	x22, [x22]
		0000000000000e74:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     e78:      	mov	x23, #0x16              ; =22
     e7c:      	and	w0, w19, #0x8
     e80:      	ubfx	x0, x0, #0, #32
     e84:      	cmp	x0, #0x0
     e88:      	b.ne	0x15d8 <_stogir.verify.integer-operations-target-structured+0xa54>
     e8c:      	movz	x0, #0x0, lsl #48
     e90:      	cmp	x24, #0x2c
     e94:      	cset	w1, eq
     e98:      	cmp	x0, #0x0
     e9c:      	b.eq	0x15e0 <_stogir.verify.integer-operations-target-structured+0xa5c>
     ea0:      	mov	x0, #0x1                ; =1
     ea4:      	cmp	x0, #0x0
     ea8:      	b.eq	0xf18 <_stogir.verify.integer-operations-target-structured+0x394>
     eac:      	uxtb	w16, w1
     eb0:      	cmp	w16, wzr
     eb4:      	b.eq	0x15e8 <_stogir.verify.integer-operations-target-structured+0xa64>
     eb8:      	add	x8, sp, #0xa0
     ebc:      	ldr	x0, [sp, #0x230]
     ec0:      	ldr	w1, [sp, #0x2c0]
     ec4:      	bl	0xec4 <_stogir.verify.integer-operations-target-structured+0x340>
		0000000000000ec4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
     ec8:      	add	x16, sp, #0xa0
     ecc:      	ldr	x0, [x16]
     ed0:      	add	x16, sp, #0xa0
     ed4:      	ldr	x1, [x16, #0x8]
     ed8:      	add	x16, sp, #0xa0
     edc:      	ldr	x2, [x16, #0x10]
     ee0:      	ubfx	x0, x0, #0, #32
     ee4:      	lsr	x16, x0, #0
     ee8:      	cmp	x16, #0x1
     eec:      	b.eq	0xf08 <_stogir.verify.integer-operations-target-structured+0x384>
     ef0:      	b.lo	0xef8 <_stogir.verify.integer-operations-target-structured+0x374>
     ef4:      	b	0xf0c <_stogir.verify.integer-operations-target-structured+0x388>
     ef8:      	cmp	x16, #0x0
     efc:      	b.eq	0xf04 <_stogir.verify.integer-operations-target-structured+0x380>
     f00:      	b	0xf0c <_stogir.verify.integer-operations-target-structured+0x388>
     f04:      	b	0x1614 <_stogir.verify.integer-operations-target-structured+0xa90>
     f08:      	b	0xf10 <_stogir.verify.integer-operations-target-structured+0x38c>
     f0c:      	b	0x1620 <_stogir.verify.integer-operations-target-structured+0xa9c>
     f10:      	mov	x22, x1
     f14:      	mov	x23, x2
     f18:      	and	w0, w19, #0x10
     f1c:      	ubfx	x0, x0, #0, #32
     f20:      	cmp	x0, #0x0
     f24:      	b.ne	0x1628 <_stogir.verify.integer-operations-target-structured+0xaa4>
     f28:      	movz	x0, #0x0, lsl #48
     f2c:      	cmp	x0, #0x0
     f30:      	b.eq	0xf84 <_stogir.verify.integer-operations-target-structured+0x400>
     f34:      	add	x8, sp, #0xe0
     f38:      	ldr	x0, [sp, #0x230]
     f3c:      	ldr	w1, [sp, #0x2c0]
     f40:      	bl	0xf40 <_stogir.verify.integer-operations-target-structured+0x3bc>
		0000000000000f40:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
     f44:      	add	x16, sp, #0xe0
     f48:      	ldr	w0, [x16]
     f4c:      	lsr	x16, x0, #0
     f50:      	cmp	x16, #0x1
     f54:      	b.eq	0xf70 <_stogir.verify.integer-operations-target-structured+0x3ec>
     f58:      	b.lo	0xf60 <_stogir.verify.integer-operations-target-structured+0x3dc>
     f5c:      	b	0xf74 <_stogir.verify.integer-operations-target-structured+0x3f0>
     f60:      	cmp	x16, #0x0
     f64:      	b.eq	0xf6c <_stogir.verify.integer-operations-target-structured+0x3e8>
     f68:      	b	0xf74 <_stogir.verify.integer-operations-target-structured+0x3f0>
     f6c:      	b	0x1630 <_stogir.verify.integer-operations-target-structured+0xaac>
     f70:      	b	0xf78 <_stogir.verify.integer-operations-target-structured+0x3f4>
     f74:      	b	0x163c <_stogir.verify.integer-operations-target-structured+0xab8>
     f78:      	add	x16, sp, #0xe0
     f7c:      	ldr	x22, [x16, #0x8]
     f80:      	ldr	x23, [x27, #0x8]
     f84:      	and	w0, w19, #0x20
     f88:      	ubfx	x0, x0, #0, #32
     f8c:      	cmp	x0, #0x0
     f90:      	b.ne	0x1644 <_stogir.verify.integer-operations-target-structured+0xac0>
     f94:      	movz	x0, #0x0, lsl #48
     f98:      	cmp	x0, #0x0
     f9c:      	b.eq	0xff0 <_stogir.verify.integer-operations-target-structured+0x46c>
     fa0:      	add	x8, sp, #0x100
     fa4:      	ldr	x0, [sp, #0x230]
     fa8:      	ldr	w1, [sp, #0x2c0]
     fac:      	bl	0xfac <_stogir.verify.integer-operations-target-structured+0x428>
		0000000000000fac:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
     fb0:      	add	x16, sp, #0x100
     fb4:      	ldr	w0, [x16]
     fb8:      	lsr	x16, x0, #0
     fbc:      	cmp	x16, #0x1
     fc0:      	b.eq	0xfdc <_stogir.verify.integer-operations-target-structured+0x458>
     fc4:      	b.lo	0xfcc <_stogir.verify.integer-operations-target-structured+0x448>
     fc8:      	b	0xfe0 <_stogir.verify.integer-operations-target-structured+0x45c>
     fcc:      	cmp	x16, #0x0
     fd0:      	b.eq	0xfd8 <_stogir.verify.integer-operations-target-structured+0x454>
     fd4:      	b	0xfe0 <_stogir.verify.integer-operations-target-structured+0x45c>
     fd8:      	b	0x164c <_stogir.verify.integer-operations-target-structured+0xac8>
     fdc:      	b	0xfe4 <_stogir.verify.integer-operations-target-structured+0x460>
     fe0:      	b	0x1658 <_stogir.verify.integer-operations-target-structured+0xad4>
     fe4:      	add	x16, sp, #0x100
     fe8:      	ldr	x22, [x16, #0x8]
     fec:      	ldr	x23, [x28, #0x8]
     ff0:      	and	w0, w19, #0x40
     ff4:      	ubfx	x0, x0, #0, #32
     ff8:      	cmp	x0, #0x0
     ffc:      	b.ne	0x1660 <_stogir.verify.integer-operations-target-structured+0xadc>
    1000:      	movz	x0, #0x0, lsl #48
    1004:      	cmp	x0, #0x0
    1008:      	b.eq	0x1c14 <_stogir.verify.integer-operations-target-structured+0x1090>
    100c:      	add	x8, sp, #0x120
    1010:      	ldr	x0, [sp, #0x230]
    1014:      	ldr	w1, [sp, #0x2c0]
    1018:      	bl	0x1018 <_stogir.verify.integer-operations-target-structured+0x494>
		0000000000001018:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    101c:      	add	x16, sp, #0x120
    1020:      	ldr	w0, [x16]
    1024:      	lsr	x16, x0, #0
    1028:      	cmp	x16, #0x1
    102c:      	b.eq	0x104c <_stogir.verify.integer-operations-target-structured+0x4c8>
    1030:      	b.lo	0x1038 <_stogir.verify.integer-operations-target-structured+0x4b4>
    1034:      	b	0x1050 <_stogir.verify.integer-operations-target-structured+0x4cc>
    1038:      	cmp	x16, #0x0
    103c:      	b.eq	0x1044 <_stogir.verify.integer-operations-target-structured+0x4c0>
    1040:      	b	0x1050 <_stogir.verify.integer-operations-target-structured+0x4cc>
    1044:      	ldr	x0, [sp, #0x240]
    1048:      	b	0x1668 <_stogir.verify.integer-operations-target-structured+0xae4>
    104c:      	b	0x1054 <_stogir.verify.integer-operations-target-structured+0x4d0>
    1050:      	b	0x1674 <_stogir.verify.integer-operations-target-structured+0xaf0>
    1054:      	add	x16, sp, #0x120
    1058:      	ldr	x22, [x16, #0x8]
    105c:      	ldr	x0, [sp, #0x240]
    1060:      	ldr	x23, [x0, #0x8]
    1064:      	and	w1, w19, #0x80
    1068:      	ubfx	x1, x1, #0, #32
    106c:      	cmp	x1, #0x0
    1070:      	b.ne	0x167c <_stogir.verify.integer-operations-target-structured+0xaf8>
    1074:      	movz	x1, #0x0, lsl #48
    1078:      	cmp	x1, #0x0
    107c:      	b.eq	0x1c1c <_stogir.verify.integer-operations-target-structured+0x1098>
    1080:      	add	x8, sp, #0x140
    1084:      	ldr	w1, [sp, #0x2c0]
    1088:      	str	x0, [sp, #0x240]
    108c:      	ldr	x0, [sp, #0x230]
    1090:      	bl	0x1090 <_stogir.verify.integer-operations-target-structured+0x50c>
		0000000000001090:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    1094:      	add	x16, sp, #0x140
    1098:      	ldr	w0, [x16]
    109c:      	lsr	x16, x0, #0
    10a0:      	cmp	x16, #0x1
    10a4:      	b.eq	0x10c4 <_stogir.verify.integer-operations-target-structured+0x540>
    10a8:      	b.lo	0x10b0 <_stogir.verify.integer-operations-target-structured+0x52c>
    10ac:      	b	0x10c8 <_stogir.verify.integer-operations-target-structured+0x544>
    10b0:      	cmp	x16, #0x0
    10b4:      	b.eq	0x10bc <_stogir.verify.integer-operations-target-structured+0x538>
    10b8:      	b	0x10c8 <_stogir.verify.integer-operations-target-structured+0x544>
    10bc:      	ldr	x0, [sp, #0x2b8]
    10c0:      	b	0x1684 <_stogir.verify.integer-operations-target-structured+0xb00>
    10c4:      	b	0x10cc <_stogir.verify.integer-operations-target-structured+0x548>
    10c8:      	b	0x1690 <_stogir.verify.integer-operations-target-structured+0xb0c>
    10cc:      	add	x16, sp, #0x140
    10d0:      	ldr	x22, [x16, #0x8]
    10d4:      	ldr	x0, [sp, #0x2b8]
    10d8:      	ldr	x23, [x0, #0x8]
    10dc:      	and	w1, w19, #0x100
    10e0:      	ubfx	x1, x1, #0, #32
    10e4:      	cmp	x1, #0x0
    10e8:      	b.ne	0x1698 <_stogir.verify.integer-operations-target-structured+0xb14>
    10ec:      	movz	x1, #0x0, lsl #48
    10f0:      	cmp	x1, #0x0
    10f4:      	b.eq	0x1c28 <_stogir.verify.integer-operations-target-structured+0x10a4>
    10f8:      	add	x8, sp, #0x160
    10fc:      	ldr	w1, [sp, #0x2c0]
    1100:      	ldr	w2, [sp, #0x250]
    1104:      	str	x0, [sp, #0x2b8]
    1108:      	ldr	x0, [sp, #0x230]
    110c:      	bl	0x110c <_stogir.verify.integer-operations-target-structured+0x588>
		000000000000110c:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1110:      	add	x16, sp, #0x160
    1114:      	ldr	w0, [x16]
    1118:      	lsr	x16, x0, #0
    111c:      	cmp	x16, #0x1
    1120:      	b.eq	0x1140 <_stogir.verify.integer-operations-target-structured+0x5bc>
    1124:      	b.lo	0x112c <_stogir.verify.integer-operations-target-structured+0x5a8>
    1128:      	b	0x1144 <_stogir.verify.integer-operations-target-structured+0x5c0>
    112c:      	cmp	x16, #0x0
    1130:      	b.eq	0x1138 <_stogir.verify.integer-operations-target-structured+0x5b4>
    1134:      	b	0x1144 <_stogir.verify.integer-operations-target-structured+0x5c0>
    1138:      	ldr	x0, [sp, #0x2a8]
    113c:      	b	0x16a0 <_stogir.verify.integer-operations-target-structured+0xb1c>
    1140:      	b	0x1148 <_stogir.verify.integer-operations-target-structured+0x5c4>
    1144:      	b	0x16ac <_stogir.verify.integer-operations-target-structured+0xb28>
    1148:      	add	x16, sp, #0x160
    114c:      	ldr	x22, [x16, #0x8]
    1150:      	ldr	x0, [sp, #0x2a8]
    1154:      	ldr	x23, [x0, #0x8]
    1158:      	and	w1, w19, #0x200
    115c:      	ubfx	x1, x1, #0, #32
    1160:      	cmp	x1, #0x0
    1164:      	b.ne	0x16b4 <_stogir.verify.integer-operations-target-structured+0xb30>
    1168:      	movz	x1, #0x0, lsl #48
    116c:      	cmp	x1, #0x0
    1170:      	b.eq	0x1c34 <_stogir.verify.integer-operations-target-structured+0x10b0>
    1174:      	add	x8, sp, #0x180
    1178:      	ldr	w1, [sp, #0x2c0]
    117c:      	ldr	w2, [sp, #0x258]
    1180:      	str	x0, [sp, #0x2a8]
    1184:      	ldr	x0, [sp, #0x230]
    1188:      	bl	0x1188 <_stogir.verify.integer-operations-target-structured+0x604>
		0000000000001188:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    118c:      	add	x16, sp, #0x180
    1190:      	ldr	w0, [x16]
    1194:      	lsr	x16, x0, #0
    1198:      	cmp	x16, #0x1
    119c:      	b.eq	0x11bc <_stogir.verify.integer-operations-target-structured+0x638>
    11a0:      	b.lo	0x11a8 <_stogir.verify.integer-operations-target-structured+0x624>
    11a4:      	b	0x11c0 <_stogir.verify.integer-operations-target-structured+0x63c>
    11a8:      	cmp	x16, #0x0
    11ac:      	b.eq	0x11b4 <_stogir.verify.integer-operations-target-structured+0x630>
    11b0:      	b	0x11c0 <_stogir.verify.integer-operations-target-structured+0x63c>
    11b4:      	ldr	x0, [sp, #0x298]
    11b8:      	b	0x16bc <_stogir.verify.integer-operations-target-structured+0xb38>
    11bc:      	b	0x11c4 <_stogir.verify.integer-operations-target-structured+0x640>
    11c0:      	b	0x16c8 <_stogir.verify.integer-operations-target-structured+0xb44>
    11c4:      	add	x16, sp, #0x180
    11c8:      	ldr	x22, [x16, #0x8]
    11cc:      	ldr	x0, [sp, #0x298]
    11d0:      	ldr	x23, [x0, #0x8]
    11d4:      	cmp	x24, #0x3c
    11d8:      	b.ne	0x1c40 <_stogir.verify.integer-operations-target-structured+0x10bc>
    11dc:      	add	x8, sp, #0x1a0
    11e0:      	ldr	w1, [sp, #0x2c0]
    11e4:      	str	x0, [sp, #0x298]
    11e8:      	ldr	x0, [sp, #0x230]
    11ec:      	bl	0x11ec <_stogir.verify.integer-operations-target-structured+0x668>
		00000000000011ec:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    11f0:      	add	x16, sp, #0x1a0
    11f4:      	ldr	w0, [x16]
    11f8:      	lsr	x16, x0, #0
    11fc:      	cmp	x16, #0x1
    1200:      	b.eq	0x1220 <_stogir.verify.integer-operations-target-structured+0x69c>
    1204:      	b.lo	0x120c <_stogir.verify.integer-operations-target-structured+0x688>
    1208:      	b	0x1224 <_stogir.verify.integer-operations-target-structured+0x6a0>
    120c:      	cmp	x16, #0x0
    1210:      	b.eq	0x1218 <_stogir.verify.integer-operations-target-structured+0x694>
    1214:      	b	0x1224 <_stogir.verify.integer-operations-target-structured+0x6a0>
    1218:      	ldr	x0, [sp, #0x290]
    121c:      	b	0x16d0 <_stogir.verify.integer-operations-target-structured+0xb4c>
    1220:      	b	0x1228 <_stogir.verify.integer-operations-target-structured+0x6a4>
    1224:      	b	0x16dc <_stogir.verify.integer-operations-target-structured+0xb58>
    1228:      	add	x16, sp, #0x1a0
    122c:      	ldr	x22, [x16, #0x8]
    1230:      	ldr	x0, [sp, #0x290]
    1234:      	ldr	x23, [x0, #0x8]
    1238:      	cmp	x24, #0x78
    123c:      	b.ne	0x1c4c <_stogir.verify.integer-operations-target-structured+0x10c8>
    1240:      	add	x16, sp, #0x20
    1244:      	ldr	w1, [x16]
    1248:      	ubfx	x1, x1, #8, #8
    124c:      	cmp	x1, #0x0
    1250:      	b.ne	0x16e4 <_stogir.verify.integer-operations-target-structured+0xb60>
    1254:      	add	x16, sp, #0x20
    1258:      	ldr	w1, [x16, #0x8]
    125c:      	sxtw	x1, w1
    1260:      	cmp	x1, #0x0
    1264:      	b.eq	0x1274 <_stogir.verify.integer-operations-target-structured+0x6f0>
    1268:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001268:  ARM64_RELOC_PAGE21	l_stogir.334
    126c:      	ldr	x22, [x22]
		000000000000126c:  ARM64_RELOC_PAGEOFF12	l_stogir.334
    1270:      	mov	x23, #0x1f              ; =31
    1274:      	str	x0, [sp, #0x290]
    1278:      	add	x0, x20, #0x1
    127c:      	sxtw	x20, w0
    1280:      	ldr	x0, [sp, #0x2c8]
    1284:      	uxth	w0, w0
    1288:      	mov	w17, #0x8               ; =8
    128c:      	uxth	w16, w0
    1290:      	ubfx	w17, w17, #0, #4
    1294:      	lsr	w0, w16, w17
    1298:      	uxth	w0, w0
    129c:      	uxtb	w0, w0
    12a0:      	cmp	x0, #0x0
    12a4:      	b.eq	0x1c54 <_stogir.verify.integer-operations-target-structured+0x10d0>
    12a8:      	add	x8, sp, #0x1f0
    12ac:      	ldr	w1, [sp, #0x2c0]
    12b0:      	str	x25, [sp, #0x2d0]
    12b4:      	mov	x25, x0
    12b8:      	ldr	x0, [sp, #0x230]
    12bc:      	bl	0x12bc <_stogir.verify.integer-operations-target-structured+0x738>
		00000000000012bc:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    12c0:      	add	x16, sp, #0x1f0
    12c4:      	ldr	w0, [x16]
    12c8:      	lsr	x16, x0, #0
    12cc:      	cmp	x16, #0x1
    12d0:      	b.eq	0x12f0 <_stogir.verify.integer-operations-target-structured+0x76c>
    12d4:      	b.lo	0x12dc <_stogir.verify.integer-operations-target-structured+0x758>
    12d8:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x770>
    12dc:      	cmp	x16, #0x0
    12e0:      	b.eq	0x12e8 <_stogir.verify.integer-operations-target-structured+0x764>
    12e4:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x770>
    12e8:      	ldr	x0, [sp, #0x288]
    12ec:      	b	0x177c <_stogir.verify.integer-operations-target-structured+0xbf8>
    12f0:      	b	0x12f8 <_stogir.verify.integer-operations-target-structured+0x774>
    12f4:      	b	0x1788 <_stogir.verify.integer-operations-target-structured+0xc04>
    12f8:      	add	x16, sp, #0x1f0
    12fc:      	ldr	x22, [x16, #0x8]
    1300:      	ldr	x0, [sp, #0x288]
    1304:      	ldr	x23, [x0, #0x8]
    1308:      	uxtb	w16, w21
    130c:      	cmp	w16, wzr
    1310:      	b.eq	0x1790 <_stogir.verify.integer-operations-target-structured+0xc0c>
    1314:      	movz	x1, #0x0, lsl #48
    1318:      	and	w2, w19, #0x1
    131c:      	and	w3, w19, #0x2
    1320:      	ubfx	x2, x2, #0, #32
    1324:      	ubfx	x3, x3, #0, #32
    1328:      	cmp	x2, #0x0
    132c:      	cset	w2, eq
    1330:      	cmp	x3, #0x0
    1334:      	cset	w3, eq
    1338:      	uxtb	w16, w2
    133c:      	cmp	w16, wzr
    1340:      	cset	x19, eq
    1344:      	uxtb	w16, w3
    1348:      	cmp	w16, wzr
    134c:      	cset	x21, eq
    1350:      	cmp	x1, #0x0
    1354:      	b.eq	0x1c64 <_stogir.verify.integer-operations-target-structured+0x10e0>
    1358:      	cmp	x25, #0x0
    135c:      	b.eq	0x1798 <_stogir.verify.integer-operations-target-structured+0xc14>
    1360:      	movz	x1, #0x0, lsl #48
    1364:      	cmp	x1, #0x0
    1368:      	b.eq	0x1c6c <_stogir.verify.integer-operations-target-structured+0x10e8>
    136c:      	ldr	x25, [sp, #0x238]
    1370:      	cmp	x25, #0x0
    1374:      	b.eq	0x17a0 <_stogir.verify.integer-operations-target-structured+0xc1c>
    1378:      	mov	x1, #0x1                ; =1
    137c:      	cmp	x1, #0x0
    1380:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0x10f0>
    1384:      	ldr	w1, [sp, #0x2c0]
    1388:      	str	x0, [sp, #0x288]
    138c:      	ldr	x0, [sp, #0x230]
    1390:      	mov	x2, #0x1                ; =1
    1394:      	bl	0x1394 <_stogir.verify.integer-operations-target-structured+0x810>
		0000000000001394:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1398:      	ubfx	x0, x0, #0, #32
    139c:      	lsr	x16, x0, #0
    13a0:      	cmp	x16, #0x1
    13a4:      	b.eq	0x13c0 <_stogir.verify.integer-operations-target-structured+0x83c>
    13a8:      	b.lo	0x13b0 <_stogir.verify.integer-operations-target-structured+0x82c>
    13ac:      	b	0x13c4 <_stogir.verify.integer-operations-target-structured+0x840>
    13b0:      	cmp	x16, #0x0
    13b4:      	b.eq	0x13bc <_stogir.verify.integer-operations-target-structured+0x838>
    13b8:      	b	0x13c4 <_stogir.verify.integer-operations-target-structured+0x840>
    13bc:      	b	0x13c8 <_stogir.verify.integer-operations-target-structured+0x844>
    13c0:      	b	0x17c8 <_stogir.verify.integer-operations-target-structured+0xc44>
    13c4:      	b	0x1b70 <_stogir.verify.integer-operations-target-structured+0xfec>
    13c8:      	str	x26, [sp, #0x2d8]
    13cc:      	str	x27, [sp, #0x2e0]
    13d0:      	str	x28, [sp, #0x2e8]
    13d4:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		00000000000013d4:  ARM64_RELOC_PAGE21	l_stogir.335
    13d8:      	ldr	x22, [x22]
		00000000000013d8:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    13dc:      	mov	x23, #0x17              ; =23
    13e0:      	add	x0, x20, #0x1
    13e4:      	sxtw	x20, w0
    13e8:      	ldr	w0, [sp, #0x2b0]
    13ec:      	sxtw	x0, w0
    13f0:      	add	x0, x0, #0x4
    13f4:      	asr	x16, x0, #63
    13f8:      	lsr	x16, x16, #62
    13fc:      	add	x0, x0, x16
    1400:      	asr	x0, x0, #2
    1404:      	ldr	x1, [sp, #0x280]
    1408:      	add	x1, x0, x1
    140c:      	ldr	x8, [sp, #0x260]
    1410:      	ldr	x0, [sp, #0x230]
    1414:      	ldr	w19, [sp, #0x248]
    1418:      	ldr	x25, [sp, #0x2d0]
    141c:      	ldr	x26, [sp, #0x2d8]
    1420:      	ldr	x27, [sp, #0x2e0]
    1424:      	ldr	x28, [sp, #0x2e8]
    1428:      	ldr	x2, [sp, #0x2b8]
    142c:      	ldr	x3, [sp, #0x2a8]
    1430:      	ldr	w21, [sp, #0x258]
    1434:      	ldr	x4, [sp, #0x298]
    1438:      	ldr	x5, [sp, #0x290]
    143c:      	ldr	x6, [sp, #0x288]
    1440:      	ldr	x24, [sp, #0x268]
    1444:      	mov	x7, x1
    1448:      	ldr	x1, [sp, #0x240]
    144c:      	mov	x9, x20
    1450:      	ldr	w20, [sp, #0x250]
    1454:      	mov	x10, x22
    1458:      	ldr	x22, [sp, #0x278]
    145c:      	mov	x11, x23
    1460:      	ldr	x23, [sp, #0x270]
    1464:      	b	0xc60 <_stogir.verify.integer-operations-target-structured+0xdc>
    1468:      	movz	w13, #0x0, lsl #16
    146c:      	b	0xcc0 <_stogir.verify.integer-operations-target-structured+0x13c>
    1470:      	movz	x0, #0x0, lsl #48
    1474:      	b	0xcd8 <_stogir.verify.integer-operations-target-structured+0x154>
    1478:      	add	x8, sp, #0x30
    147c:      	ldr	w2, [sp, #0x248]
    1480:      	str	x0, [sp, #0x2c8]
    1484:      	ldr	x0, [sp, #0x230]
    1488:      	mov	w21, w1
    148c:      	ldr	w1, [sp, #0x2c0]
    1490:      	bl	0x1490 <_stogir.verify.integer-operations-target-structured+0x90c>
		0000000000001490:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    1494:      	add	x16, sp, #0x30
    1498:      	ldr	w0, [x16]
    149c:      	lsr	x16, x0, #0
    14a0:      	cmp	x16, #0x1
    14a4:      	b.eq	0x14c0 <_stogir.verify.integer-operations-target-structured+0x93c>
    14a8:      	b.lo	0x14b0 <_stogir.verify.integer-operations-target-structured+0x92c>
    14ac:      	b	0x14c4 <_stogir.verify.integer-operations-target-structured+0x940>
    14b0:      	cmp	x16, #0x0
    14b4:      	b.eq	0x14bc <_stogir.verify.integer-operations-target-structured+0x938>
    14b8:      	b	0x14c4 <_stogir.verify.integer-operations-target-structured+0x940>
    14bc:      	b	0x14d8 <_stogir.verify.integer-operations-target-structured+0x954>
    14c0:      	b	0x14c8 <_stogir.verify.integer-operations-target-structured+0x944>
    14c4:      	b	0x1b78 <_stogir.verify.integer-operations-target-structured+0xff4>
    14c8:      	add	x16, sp, #0x30
    14cc:      	ldr	x22, [x16, #0x8]
    14d0:      	ldr	x23, [x25, #0x8]
    14d4:      	b	0xd80 <_stogir.verify.integer-operations-target-structured+0x1fc>
    14d8:      	add	x0, x20, #0x1
    14dc:      	sxtw	x20, w0
    14e0:      	b	0x14d4 <_stogir.verify.integer-operations-target-structured+0x950>
    14e4:      	mov	x0, #0x1                ; =1
    14e8:      	b	0xd98 <_stogir.verify.integer-operations-target-structured+0x214>
    14ec:      	movz	x0, #0x0, lsl #48
    14f0:      	b	0xd98 <_stogir.verify.integer-operations-target-structured+0x214>
    14f4:      	add	x0, x20, #0x1
    14f8:      	sxtw	x20, w0
    14fc:      	b	0xdf0 <_stogir.verify.integer-operations-target-structured+0x26c>
    1500:      	brk	#0
    1504:      	b	0x1500 <_stogir.verify.integer-operations-target-structured+0x97c>
    1508:      	cmp	x24, #0x1e
    150c:      	cset	w0, eq
    1510:      	ubfx	x0, x0, #0, #8
    1514:      	b	0xdfc <_stogir.verify.integer-operations-target-structured+0x278>
    1518:      	mov	x0, #0x1                ; =1
    151c:      	b	0xe1c <_stogir.verify.integer-operations-target-structured+0x298>
    1520:      	movz	x0, #0x0, lsl #48
    1524:      	b	0xe1c <_stogir.verify.integer-operations-target-structured+0x298>
    1528:      	add	x16, sp, #0x70
    152c:      	ldr	x0, [x16, #0x8]
    1530:      	add	x16, sp, #0x20
    1534:      	ldr	w1, [x16, #0xc]
    1538:      	sxtw	x1, w1
    153c:      	cmp	x1, #0x0
    1540:      	b.ge	0x1560 <_stogir.verify.integer-operations-target-structured+0x9dc>
    1544:      	mov	x0, #0x1                ; =1
    1548:      	cmp	x0, #0x0
    154c:      	b.eq	0x155c <_stogir.verify.integer-operations-target-structured+0x9d8>
    1550:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001550:  ARM64_RELOC_PAGE21	l_stogir.336
    1554:      	ldr	x22, [x22]
		0000000000001554:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    1558:      	mov	x23, #0x2d              ; =45
    155c:      	b	0xe7c <_stogir.verify.integer-operations-target-structured+0x2f8>
    1560:      	uxtb	w0, w0
    1564:      	cmp	x0, #0x83
    1568:      	b.ge	0x15c0 <_stogir.verify.integer-operations-target-structured+0xa3c>
    156c:      	adrp	x17, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		000000000000156c:  ARM64_RELOC_PAGE21	l_stogir.337
    1570:      	ldr	x17, [x17]
		0000000000001570:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    1574:      	add	x1, x0, x17
    1578:      	ldrb	w1, [x1]
    157c:      	uxtb	w16, w1
    1580:      	and	w1, w16, #0x2
    1584:      	uxtb	w1, w1
    1588:      	ubfx	x1, x1, #0, #8
    158c:      	cmp	x1, #0x0
    1590:      	cset	w1, eq
    1594:      	uxtb	w16, w1
    1598:      	cmp	w16, wzr
    159c:      	cset	x1, eq
    15a0:      	cmp	x1, #0x0
    15a4:      	b.ne	0x15c8 <_stogir.verify.integer-operations-target-structured+0xa44>
    15a8:      	cmp	x0, #0x65
    15ac:      	b.eq	0x15c8 <_stogir.verify.integer-operations-target-structured+0xa44>
    15b0:      	cmp	x0, #0x66
    15b4:      	b.eq	0x15c8 <_stogir.verify.integer-operations-target-structured+0xa44>
    15b8:      	mov	x0, #0x1                ; =1
    15bc:      	b	0x1548 <_stogir.verify.integer-operations-target-structured+0x9c4>
    15c0:      	movz	w1, #0x0, lsl #16
    15c4:      	b	0x157c <_stogir.verify.integer-operations-target-structured+0x9f8>
    15c8:      	movz	x0, #0x0, lsl #48
    15cc:      	b	0x15bc <_stogir.verify.integer-operations-target-structured+0xa38>
    15d0:      	brk	#0
    15d4:      	b	0x15d0 <_stogir.verify.integer-operations-target-structured+0xa4c>
    15d8:      	mov	x0, #0x1                ; =1
    15dc:      	b	0xe90 <_stogir.verify.integer-operations-target-structured+0x30c>
    15e0:      	ubfx	x0, x1, #0, #8
    15e4:      	b	0xea4 <_stogir.verify.integer-operations-target-structured+0x320>
    15e8:      	add	x8, sp, #0xc0
    15ec:      	ldr	x0, [sp, #0x230]
    15f0:      	ldr	w1, [sp, #0x2c0]
    15f4:      	bl	0x15f4 <_stogir.verify.integer-operations-target-structured+0xa70>
		00000000000015f4:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    15f8:      	add	x16, sp, #0xc0
    15fc:      	ldr	x0, [x16]
    1600:      	add	x16, sp, #0xc0
    1604:      	ldr	x1, [x16, #0x8]
    1608:      	add	x16, sp, #0xc0
    160c:      	ldr	x2, [x16, #0x10]
    1610:      	b	0xee0 <_stogir.verify.integer-operations-target-structured+0x35c>
    1614:      	add	x0, x20, #0x1
    1618:      	sxtw	x20, w0
    161c:      	b	0xf18 <_stogir.verify.integer-operations-target-structured+0x394>
    1620:      	brk	#0
    1624:      	b	0x1620 <_stogir.verify.integer-operations-target-structured+0xa9c>
    1628:      	mov	x0, #0x1                ; =1
    162c:      	b	0xf2c <_stogir.verify.integer-operations-target-structured+0x3a8>
    1630:      	add	x0, x20, #0x1
    1634:      	sxtw	x20, w0
    1638:      	b	0xf84 <_stogir.verify.integer-operations-target-structured+0x400>
    163c:      	brk	#0
    1640:      	b	0x163c <_stogir.verify.integer-operations-target-structured+0xab8>
    1644:      	mov	x0, #0x1                ; =1
    1648:      	b	0xf98 <_stogir.verify.integer-operations-target-structured+0x414>
    164c:      	add	x0, x20, #0x1
    1650:      	sxtw	x20, w0
    1654:      	b	0xff0 <_stogir.verify.integer-operations-target-structured+0x46c>
    1658:      	brk	#0
    165c:      	b	0x1658 <_stogir.verify.integer-operations-target-structured+0xad4>
    1660:      	mov	x0, #0x1                ; =1
    1664:      	b	0x1004 <_stogir.verify.integer-operations-target-structured+0x480>
    1668:      	add	x1, x20, #0x1
    166c:      	sxtw	x20, w1
    1670:      	b	0x1064 <_stogir.verify.integer-operations-target-structured+0x4e0>
    1674:      	brk	#0
    1678:      	b	0x1674 <_stogir.verify.integer-operations-target-structured+0xaf0>
    167c:      	mov	x1, #0x1                ; =1
    1680:      	b	0x1078 <_stogir.verify.integer-operations-target-structured+0x4f4>
    1684:      	add	x1, x20, #0x1
    1688:      	sxtw	x20, w1
    168c:      	b	0x10dc <_stogir.verify.integer-operations-target-structured+0x558>
    1690:      	brk	#0
    1694:      	b	0x1690 <_stogir.verify.integer-operations-target-structured+0xb0c>
    1698:      	mov	x1, #0x1                ; =1
    169c:      	b	0x10f0 <_stogir.verify.integer-operations-target-structured+0x56c>
    16a0:      	add	x1, x20, #0x1
    16a4:      	sxtw	x20, w1
    16a8:      	b	0x1158 <_stogir.verify.integer-operations-target-structured+0x5d4>
    16ac:      	brk	#0
    16b0:      	b	0x16ac <_stogir.verify.integer-operations-target-structured+0xb28>
    16b4:      	mov	x1, #0x1                ; =1
    16b8:      	b	0x116c <_stogir.verify.integer-operations-target-structured+0x5e8>
    16bc:      	add	x1, x20, #0x1
    16c0:      	sxtw	x20, w1
    16c4:      	b	0x11d4 <_stogir.verify.integer-operations-target-structured+0x650>
    16c8:      	brk	#0
    16cc:      	b	0x16c8 <_stogir.verify.integer-operations-target-structured+0xb44>
    16d0:      	add	x1, x20, #0x1
    16d4:      	sxtw	x20, w1
    16d8:      	b	0x1238 <_stogir.verify.integer-operations-target-structured+0x6b4>
    16dc:      	brk	#0
    16e0:      	b	0x16dc <_stogir.verify.integer-operations-target-structured+0xb58>
    16e4:      	add	x16, sp, #0x20
    16e8:      	ldr	w1, [x16, #0x8]
    16ec:      	add	x8, sp, #0x1c0
    16f0:      	str	x0, [sp, #0x290]
    16f4:      	ldr	x0, [sp, #0x230]
    16f8:      	bl	0x16f8 <_stogir.verify.integer-operations-target-structured+0xb74>
		00000000000016f8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    16fc:      	add	x16, sp, #0x1c0
    1700:      	ldr	w0, [x16]
    1704:      	lsr	x16, x0, #0
    1708:      	cmp	x16, #0x1
    170c:      	b.eq	0x1728 <_stogir.verify.integer-operations-target-structured+0xba4>
    1710:      	b.lo	0x1718 <_stogir.verify.integer-operations-target-structured+0xb94>
    1714:      	b	0x172c <_stogir.verify.integer-operations-target-structured+0xba8>
    1718:      	cmp	x16, #0x0
    171c:      	b.eq	0x1724 <_stogir.verify.integer-operations-target-structured+0xba0>
    1720:      	b	0x172c <_stogir.verify.integer-operations-target-structured+0xba8>
    1724:      	b	0x1730 <_stogir.verify.integer-operations-target-structured+0xbac>
    1728:      	b	0x1740 <_stogir.verify.integer-operations-target-structured+0xbbc>
    172c:      	b	0x1774 <_stogir.verify.integer-operations-target-structured+0xbf0>
    1730:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001730:  ARM64_RELOC_PAGE21	l_stogir.338
    1734:      	ldr	x22, [x22]
		0000000000001734:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    1738:      	mov	x23, #0x14              ; =20
    173c:      	b	0x1278 <_stogir.verify.integer-operations-target-structured+0x6f4>
    1740:      	add	x16, sp, #0x1c0
    1744:      	ldr	x0, [x16, #0x8]
    1748:      	add	x16, sp, #0x20
    174c:      	ldr	w1, [x16]
    1750:      	ubfx	x0, x0, #0, #32
    1754:      	ubfx	x1, x1, #8, #8
    1758:      	ubfx	x0, x0, #8, #8
    175c:      	cmp	x0, x1
    1760:      	b.eq	0x1770 <_stogir.verify.integer-operations-target-structured+0xbec>
    1764:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001764:  ARM64_RELOC_PAGE21	l_stogir.339
    1768:      	ldr	x22, [x22]
		0000000000001768:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    176c:      	mov	x23, #0x1a              ; =26
    1770:      	b	0x173c <_stogir.verify.integer-operations-target-structured+0xbb8>
    1774:      	brk	#0
    1778:      	b	0x1774 <_stogir.verify.integer-operations-target-structured+0xbf0>
    177c:      	add	x1, x20, #0x1
    1780:      	sxtw	x20, w1
    1784:      	b	0x1308 <_stogir.verify.integer-operations-target-structured+0x784>
    1788:      	brk	#0
    178c:      	b	0x1788 <_stogir.verify.integer-operations-target-structured+0xc04>
    1790:      	mov	x1, #0x1                ; =1
    1794:      	b	0x1318 <_stogir.verify.integer-operations-target-structured+0x794>
    1798:      	mov	x1, #0x1                ; =1
    179c:      	b	0x1364 <_stogir.verify.integer-operations-target-structured+0x7e0>
    17a0:      	cmp	x19, #0x0
    17a4:      	b.eq	0x17b0 <_stogir.verify.integer-operations-target-structured+0xc2c>
    17a8:      	mov	x1, #0x1                ; =1
    17ac:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x7f8>
    17b0:      	mov	x1, x21
    17b4:      	b	0x17ac <_stogir.verify.integer-operations-target-structured+0xc28>
    17b8:      	movz	x1, #0x0, lsl #48
    17bc:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x7f8>
    17c0:      	movz	x1, #0x0, lsl #48
    17c4:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x7f8>
    17c8:      	sxtw	x1, w1
    17cc:      	cmp	x1, #0x0
    17d0:      	cset	w0, gt
    17d4:      	movz	x16, #0x0, lsl #48
    17d8:      	sub	x2, x16, x1
    17dc:      	sub	x3, x2, #0x1
    17e0:      	uxtb	w16, w0
    17e4:      	cmp	w16, wzr
    17e8:      	b.eq	0x1c88 <_stogir.verify.integer-operations-target-structured+0x1104>
    17ec:      	ldr	x4, [sp, #0x230]
    17f0:      	ldr	x2, [x4, #0x8]
    17f4:      	cmp	x1, x2
    17f8:      	b.ge	0x1c94 <_stogir.verify.integer-operations-target-structured+0x1110>
    17fc:      	ldr	x5, [sp, #0x278]
    1800:      	ldr	x2, [x5, #0x8]
    1804:      	cmp	x1, x2
    1808:      	b.ge	0x1880 <_stogir.verify.integer-operations-target-structured+0xcfc>
    180c:      	ldr	x2, [x4, #0x78]
    1810:      	add	x2, x2, x1, lsl #2
    1814:      	ldr	w2, [x2]
    1818:      	sxtw	x2, w2
    181c:      	cmp	x2, #0x0
    1820:      	cset	w2, ge
    1824:      	ubfx	x2, x2, #0, #8
    1828:      	ldr	x6, [sp, #0x270]
    182c:      	ldr	x8, [sp, #0x268]
    1830:      	cmp	x2, #0x0
    1834:      	b.eq	0x18fc <_stogir.verify.integer-operations-target-structured+0xd78>
    1838:      	uxtb	w16, w0
    183c:      	cmp	w16, wzr
    1840:      	b.eq	0x18f0 <_stogir.verify.integer-operations-target-structured+0xd6c>
    1844:      	ldr	x0, [x4]
    1848:      	add	x0, x0, x1, lsl #4
    184c:      	cmp	x0, #0x0
    1850:      	b.ne	0x1904 <_stogir.verify.integer-operations-target-structured+0xd80>
    1854:      	str	x4, [sp, #0x230]
    1858:      	str	x5, [sp, #0x278]
    185c:      	str	x26, [sp, #0x2d8]
    1860:      	str	x27, [sp, #0x2e0]
    1864:      	str	x28, [sp, #0x2e8]
    1868:      	str	x6, [sp, #0x270]
    186c:      	str	x8, [sp, #0x268]
    1870:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001870:  ARM64_RELOC_PAGE21	l_stogir.335
    1874:      	ldr	x22, [x22]
		0000000000001874:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    1878:      	mov	x23, #0x17              ; =23
    187c:      	b	0x13e0 <_stogir.verify.integer-operations-target-structured+0x85c>
    1880:      	movz	x2, #0x0, lsl #48
    1884:      	b	0x1828 <_stogir.verify.integer-operations-target-structured+0xca4>
    1888:      	movz	x2, #0x0, lsl #48
    188c:      	b	0x1828 <_stogir.verify.integer-operations-target-structured+0xca4>
    1890:      	cmp	x1, #0x0
    1894:      	b.ge	0x1c9c <_stogir.verify.integer-operations-target-structured+0x1118>
    1898:      	ldr	x6, [sp, #0x270]
    189c:      	ldr	x7, [x6, #0x8]
    18a0:      	ldr	x8, [sp, #0x268]
    18a4:      	ldr	x9, [x8, #0x8]
    18a8:      	cmp	x7, x9
    18ac:      	b.ne	0x18e0 <_stogir.verify.integer-operations-target-structured+0xd5c>
    18b0:      	cmp	x2, x7
    18b4:      	b.gt	0x18d8 <_stogir.verify.integer-operations-target-structured+0xd54>
    18b8:      	ldr	x2, [x4, #0x50]
    18bc:      	add	x2, x2, x3, lsl #2
    18c0:      	ldr	w2, [x2]
    18c4:      	sxtw	x2, w2
    18c8:      	cmp	x2, #0x0
    18cc:      	cset	w2, gt
    18d0:      	ubfx	x2, x2, #0, #8
    18d4:      	b	0x1830 <_stogir.verify.integer-operations-target-structured+0xcac>
    18d8:      	movz	x2, #0x0, lsl #48
    18dc:      	b	0x18d4 <_stogir.verify.integer-operations-target-structured+0xd50>
    18e0:      	movz	x2, #0x0, lsl #48
    18e4:      	b	0x18d4 <_stogir.verify.integer-operations-target-structured+0xd50>
    18e8:      	movz	x2, #0x0, lsl #48
    18ec:      	b	0x18d4 <_stogir.verify.integer-operations-target-structured+0xd50>
    18f0:      	ldr	x0, [x4, #0x28]
    18f4:      	add	x0, x0, x3, lsl #4
    18f8:      	b	0x184c <_stogir.verify.integer-operations-target-structured+0xcc8>
    18fc:      	movz	x0, #0x0, lsl #48
    1900:      	b	0x184c <_stogir.verify.integer-operations-target-structured+0xcc8>
    1904:      	ldr	w0, [x0]
    1908:      	add	x16, sp, #0x20
    190c:      	ldr	w1, [x16]
    1910:      	ubfx	x0, x0, #8, #8
    1914:      	orr	x2, x0, xzr
    1918:      	ubfx	x1, x1, #8, #8
    191c:      	cmp	x1, #0x6
    1920:      	b.ne	0x1a64 <_stogir.verify.integer-operations-target-structured+0xee0>
    1924:      	cmp	x2, #0x6
    1928:      	b.ne	0x1a5c <_stogir.verify.integer-operations-target-structured+0xed8>
    192c:      	cmp	x24, #0x1a
    1930:      	b.ne	0x1a4c <_stogir.verify.integer-operations-target-structured+0xec8>
    1934:      	mov	x1, #0x1                ; =1
    1938:      	cmp	x2, #0x1
    193c:      	cset	w3, ge
    1940:      	uxtb	w16, w3
    1944:      	cmp	w16, wzr
    1948:      	b.eq	0x1ca8 <_stogir.verify.integer-operations-target-structured+0x1124>
    194c:      	cmp	x2, #0xb
    1950:      	cset	w7, le
    1954:      	uxtb	w16, w7
    1958:      	cmp	w16, wzr
    195c:      	b.eq	0x1cd0 <_stogir.verify.integer-operations-target-structured+0x114c>
    1960:      	cmp	x21, #0x0
    1964:      	b.eq	0x1cf8 <_stogir.verify.integer-operations-target-structured+0x1174>
    1968:      	ldr	w13, [sp, #0x2a0]
    196c:      	str	x4, [sp, #0x230]
    1970:      	str	x5, [sp, #0x278]
    1974:      	str	x6, [sp, #0x270]
    1978:      	str	x8, [sp, #0x268]
    197c:      	mov	x21, x2
    1980:      	str	x26, [sp, #0x2d8]
    1984:      	mov	x26, x1
    1988:      	mov	w1, w0
    198c:      	mov	w0, w13
    1990:      	str	x27, [sp, #0x2e0]
    1994:      	mov	w27, w3
    1998:      	str	x28, [sp, #0x2e8]
    199c:      	mov	w28, w7
    19a0:      	bl	0x19a0 <_stogir.verify.integer-operations-target-structured+0xe1c>
		00000000000019a0:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    19a4:      	cmp	x0, #0x0
    19a8:      	b.ne	0x1a6c <_stogir.verify.integer-operations-target-structured+0xee8>
    19ac:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		00000000000019ac:  ARM64_RELOC_PAGE21	l_stogir.340
    19b0:      	ldr	x22, [x22]
		00000000000019b0:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    19b4:      	mov	x23, #0x1c              ; =28
    19b8:      	add	x16, sp, #0x20
    19bc:      	ldr	w0, [x16]
    19c0:      	cmp	x25, #0x0
    19c4:      	b.eq	0x1b04 <_stogir.verify.integer-operations-target-structured+0xf80>
    19c8:      	mov	x1, #0x1                ; =1
    19cc:      	ubfx	x0, x0, #8, #8
    19d0:      	sxtw	x1, w1
    19d4:      	cmp	x0, x1
    19d8:      	b.eq	0x19e8 <_stogir.verify.integer-operations-target-structured+0xe64>
    19dc:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		00000000000019dc:  ARM64_RELOC_PAGE21	l_stogir.341
    19e0:      	ldr	x22, [x22]
		00000000000019e0:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    19e4:      	mov	x23, #0x26              ; =38
    19e8:      	cmp	x25, #0x0
    19ec:      	b.eq	0x19f4 <_stogir.verify.integer-operations-target-structured+0xe70>
    19f0:      	mov	x19, #0x1               ; =1
    19f4:      	cmp	x19, #0x0
    19f8:      	b.eq	0x1a48 <_stogir.verify.integer-operations-target-structured+0xec4>
    19fc:      	ldr	x0, [sp, #0x230]
    1a00:      	ldr	w1, [sp, #0x2c0]
    1a04:      	mov	x2, #0x2                ; =2
    1a08:      	bl	0x1a08 <_stogir.verify.integer-operations-target-structured+0xe84>
		0000000000001a08:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1a0c:      	ubfx	x0, x0, #0, #32
    1a10:      	lsr	x16, x0, #0
    1a14:      	cmp	x16, #0x1
    1a18:      	b.eq	0x1a34 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1a1c:      	b.lo	0x1a24 <_stogir.verify.integer-operations-target-structured+0xea0>
    1a20:      	b	0x1a38 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1a24:      	cmp	x16, #0x0
    1a28:      	b.eq	0x1a30 <_stogir.verify.integer-operations-target-structured+0xeac>
    1a2c:      	b	0x1a38 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1a30:      	b	0x1a3c <_stogir.verify.integer-operations-target-structured+0xeb8>
    1a34:      	b	0x1b0c <_stogir.verify.integer-operations-target-structured+0xf88>
    1a38:      	b	0x1b68 <_stogir.verify.integer-operations-target-structured+0xfe4>
    1a3c:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001a3c:  ARM64_RELOC_PAGE21	l_stogir.342
    1a40:      	ldr	x22, [x22]
		0000000000001a40:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    1a44:      	mov	x23, #0x1d              ; =29
    1a48:      	b	0x187c <_stogir.verify.integer-operations-target-structured+0xcf8>
    1a4c:      	cmp	x24, #0x1b
    1a50:      	cset	w1, eq
    1a54:      	ubfx	x1, x1, #0, #8
    1a58:      	b	0x1938 <_stogir.verify.integer-operations-target-structured+0xdb4>
    1a5c:      	movz	x1, #0x0, lsl #48
    1a60:      	b	0x1938 <_stogir.verify.integer-operations-target-structured+0xdb4>
    1a64:      	movz	x1, #0x0, lsl #48
    1a68:      	b	0x1938 <_stogir.verify.integer-operations-target-structured+0xdb4>
    1a6c:      	cmp	x19, #0x0
    1a70:      	b.eq	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1a74:      	cmp	x24, #0x3a
    1a78:      	cset	w0, eq
    1a7c:      	cmp	x24, #0x1a
    1a80:      	b.lt	0x1adc <_stogir.verify.integer-operations-target-structured+0xf58>
    1a84:      	cmp	x24, #0x1e
    1a88:      	b.gt	0x1adc <_stogir.verify.integer-operations-target-structured+0xf58>
    1a8c:      	uxtb	w16, w27
    1a90:      	cmp	w16, wzr
    1a94:      	b.eq	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1a98:      	uxtb	w16, w28
    1a9c:      	cmp	w16, wzr
    1aa0:      	b.eq	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1aa4:      	cmp	x21, #0x1
    1aa8:      	b.ne	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1aac:      	cmp	x24, #0x2e
    1ab0:      	b.eq	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1ab4:      	cmp	x24, #0x2f
    1ab8:      	b.eq	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1abc:      	cmp	x24, #0x30
    1ac0:      	b.eq	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1ac4:      	uxtb	w16, w0
    1ac8:      	cmp	w16, wzr
    1acc:      	b.ne	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1ad0:      	cmp	x24, #0x3b
    1ad4:      	b.ne	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1ad8:      	b	0x19b8 <_stogir.verify.integer-operations-target-structured+0xe34>
    1adc:      	cmp	x24, #0x2e
    1ae0:      	b.lt	0x1aec <_stogir.verify.integer-operations-target-structured+0xf68>
    1ae4:      	cmp	x24, #0x35
    1ae8:      	b.le	0x1a8c <_stogir.verify.integer-operations-target-structured+0xf08>
    1aec:      	uxtb	w16, w0
    1af0:      	cmp	w16, wzr
    1af4:      	b.ne	0x1a8c <_stogir.verify.integer-operations-target-structured+0xf08>
    1af8:      	cmp	x24, #0x3b
    1afc:      	b.eq	0x1a8c <_stogir.verify.integer-operations-target-structured+0xf08>
    1b00:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1b04:      	mov	x1, x21
    1b08:      	b	0x19cc <_stogir.verify.integer-operations-target-structured+0xe48>
    1b0c:      	ldr	x0, [sp, #0x230]
    1b10:      	bl	0x1b10 <_stogir.verify.integer-operations-target-structured+0xf8c>
		0000000000001b10:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1b14:      	cmp	x0, #0x0
    1b18:      	b.ne	0x1b2c <_stogir.verify.integer-operations-target-structured+0xfa8>
    1b1c:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001b1c:  ARM64_RELOC_PAGE21	l_stogir.342
    1b20:      	ldr	x22, [x22]
		0000000000001b20:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    1b24:      	mov	x23, #0x1d              ; =29
    1b28:      	b	0x1a48 <_stogir.verify.integer-operations-target-structured+0xec4>
    1b2c:      	ldr	w0, [x0]
    1b30:      	ubfx	x0, x0, #8, #8
    1b34:      	cmp	x21, x0
    1b38:      	b.eq	0x1b54 <_stogir.verify.integer-operations-target-structured+0xfd0>
    1b3c:      	cmp	x26, #0x0
    1b40:      	b.eq	0x1b58 <_stogir.verify.integer-operations-target-structured+0xfd4>
    1b44:      	cmp	x0, #0x5
    1b48:      	b.eq	0x1b54 <_stogir.verify.integer-operations-target-structured+0xfd0>
    1b4c:      	cmp	x0, #0xb
    1b50:      	b.ne	0x1b58 <_stogir.verify.integer-operations-target-structured+0xfd4>
    1b54:      	b	0x1b28 <_stogir.verify.integer-operations-target-structured+0xfa4>
    1b58:      	adrp	x22, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001b58:  ARM64_RELOC_PAGE21	l_stogir.343
    1b5c:      	ldr	x22, [x22]
		0000000000001b5c:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    1b60:      	mov	x23, #0x1d              ; =29
    1b64:      	b	0x1b54 <_stogir.verify.integer-operations-target-structured+0xfd0>
    1b68:      	brk	#0
    1b6c:      	b	0x1b68 <_stogir.verify.integer-operations-target-structured+0xfe4>
    1b70:      	brk	#0
    1b74:      	b	0x1b70 <_stogir.verify.integer-operations-target-structured+0xfec>
    1b78:      	brk	#0
    1b7c:      	b	0x1b78 <_stogir.verify.integer-operations-target-structured+0xff4>
    1b80:      	cmp	x23, #0x0
    1b84:      	b.ne	0x1bdc <_stogir.verify.integer-operations-target-structured+0x1058>
    1b88:      	and	x22, x20, #0xffffffff
    1b8c:      	movz	x0, #0x0, lsl #48
    1b90:      	movz	x23, #0x0, lsl #48
    1b94:      	ldr	x1, [sp, #0x260]
    1b98:      	str	x0, [x1]
    1b9c:      	str	x22, [x1, #0x8]
    1ba0:      	str	x23, [x1, #0x10]
    1ba4:      	ldr	x19, [sp, #0x2f0]
    1ba8:      	ldr	x20, [sp, #0x2f8]
    1bac:      	ldr	x21, [sp, #0x300]
    1bb0:      	ldr	x22, [sp, #0x308]
    1bb4:      	ldr	x23, [sp, #0x310]
    1bb8:      	ldr	x24, [sp, #0x318]
    1bbc:      	ldr	x25, [sp, #0x320]
    1bc0:      	ldr	x26, [sp, #0x328]
    1bc4:      	ldr	x27, [sp, #0x330]
    1bc8:      	ldr	x28, [sp, #0x338]
    1bcc:      	ldr	x29, [sp, #0x10]
    1bd0:      	ldr	x30, [sp, #0x18]
    1bd4:      	add	sp, sp, #0x340
    1bd8:      	ret
    1bdc:      	mov	x0, #0x1                ; =1
    1be0:      	b	0x1b94 <_stogir.verify.integer-operations-target-structured+0x1010>
    1be4:      	mov	x20, x9
    1be8:      	str	x8, [sp, #0x260]
    1bec:      	mov	x22, x10
    1bf0:      	mov	x23, x11
    1bf4:      	b	0x1b80 <_stogir.verify.integer-operations-target-structured+0xffc>
    1bf8:      	mov	x20, x9
    1bfc:      	str	x8, [sp, #0x260]
    1c00:      	mov	x22, x10
    1c04:      	mov	x23, x11
    1c08:      	b	0x1b80 <_stogir.verify.integer-operations-target-structured+0xffc>
    1c0c:      	str	x0, [sp, #0x230]
    1c10:      	b	0x1470 <_stogir.verify.integer-operations-target-structured+0x8ec>
    1c14:      	ldr	x0, [sp, #0x240]
    1c18:      	b	0x1064 <_stogir.verify.integer-operations-target-structured+0x4e0>
    1c1c:      	str	x0, [sp, #0x240]
    1c20:      	ldr	x0, [sp, #0x2b8]
    1c24:      	b	0x10dc <_stogir.verify.integer-operations-target-structured+0x558>
    1c28:      	str	x0, [sp, #0x2b8]
    1c2c:      	ldr	x0, [sp, #0x2a8]
    1c30:      	b	0x1158 <_stogir.verify.integer-operations-target-structured+0x5d4>
    1c34:      	str	x0, [sp, #0x2a8]
    1c38:      	ldr	x0, [sp, #0x298]
    1c3c:      	b	0x11d4 <_stogir.verify.integer-operations-target-structured+0x650>
    1c40:      	str	x0, [sp, #0x298]
    1c44:      	ldr	x0, [sp, #0x290]
    1c48:      	b	0x1238 <_stogir.verify.integer-operations-target-structured+0x6b4>
    1c4c:      	str	x0, [sp, #0x290]
    1c50:      	b	0x1280 <_stogir.verify.integer-operations-target-structured+0x6fc>
    1c54:      	str	x25, [sp, #0x2d0]
    1c58:      	mov	x25, x0
    1c5c:      	ldr	x0, [sp, #0x288]
    1c60:      	b	0x1308 <_stogir.verify.integer-operations-target-structured+0x784>
    1c64:      	ldr	x25, [sp, #0x238]
    1c68:      	b	0x17c0 <_stogir.verify.integer-operations-target-structured+0xc3c>
    1c6c:      	ldr	x25, [sp, #0x238]
    1c70:      	b	0x17b8 <_stogir.verify.integer-operations-target-structured+0xc34>
    1c74:      	str	x26, [sp, #0x2d8]
    1c78:      	str	x27, [sp, #0x2e0]
    1c7c:      	str	x28, [sp, #0x2e8]
    1c80:      	str	x0, [sp, #0x288]
    1c84:      	b	0x13e8 <_stogir.verify.integer-operations-target-structured+0x864>
    1c88:      	ldr	x4, [sp, #0x230]
    1c8c:      	ldr	x5, [sp, #0x278]
    1c90:      	b	0x1890 <_stogir.verify.integer-operations-target-structured+0xd0c>
    1c94:      	ldr	x5, [sp, #0x278]
    1c98:      	b	0x1888 <_stogir.verify.integer-operations-target-structured+0xd04>
    1c9c:      	ldr	x6, [sp, #0x270]
    1ca0:      	ldr	x8, [sp, #0x268]
    1ca4:      	b	0x18e8 <_stogir.verify.integer-operations-target-structured+0xd64>
    1ca8:      	str	x4, [sp, #0x230]
    1cac:      	str	x5, [sp, #0x278]
    1cb0:      	str	x26, [sp, #0x2d8]
    1cb4:      	mov	x26, x1
    1cb8:      	str	x27, [sp, #0x2e0]
    1cbc:      	str	x28, [sp, #0x2e8]
    1cc0:      	mov	x21, x2
    1cc4:      	str	x6, [sp, #0x270]
    1cc8:      	str	x8, [sp, #0x268]
    1ccc:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1cd0:      	str	x4, [sp, #0x230]
    1cd4:      	str	x5, [sp, #0x278]
    1cd8:      	str	x26, [sp, #0x2d8]
    1cdc:      	mov	x26, x1
    1ce0:      	str	x27, [sp, #0x2e0]
    1ce4:      	str	x28, [sp, #0x2e8]
    1ce8:      	mov	x21, x2
    1cec:      	str	x6, [sp, #0x270]
    1cf0:      	str	x8, [sp, #0x268]
    1cf4:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xe28>
    1cf8:      	str	x4, [sp, #0x230]
    1cfc:      	str	x5, [sp, #0x278]
    1d00:      	str	x26, [sp, #0x2d8]
    1d04:      	mov	x26, x1
    1d08:      	str	x27, [sp, #0x2e0]
    1d0c:      	str	x28, [sp, #0x2e8]
    1d10:      	mov	x21, x2
    1d14:      	mov	w27, w3
    1d18:      	mov	w28, w7
    1d1c:      	str	x6, [sp, #0x270]
    1d20:      	str	x8, [sp, #0x268]
    1d24:      	b	0x1a6c <_stogir.verify.integer-operations-target-structured+0xee8>

0000000000001d28 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    1d28:      	ldr	x0, [x0, #0x8]
    1d2c:      	ret

0000000000001d30 <_coil.core.Eq$slice<u8>$=>:
    1d30:      	sub	sp, sp, #0x10
    1d34:      	str	x29, [sp]
    1d38:      	str	x30, [sp, #0x8]
    1d3c:      	mov	x29, sp
    1d40:      	cmp	x1, x3
    1d44:      	b.ne	0x1d80 <_coil.core.Eq$slice<u8>$=+0x50>
    1d48:      	cmp	x1, #0x0
    1d4c:      	b.ne	0x1d58 <_coil.core.Eq$slice<u8>$=+0x28>
    1d50:      	mov	x0, #0x1                ; =1
    1d54:      	b	0x1d7c <_coil.core.Eq$slice<u8>$=+0x4c>
    1d58:      	lsr	x1, x1, #0
    1d5c:      	fmov	d31, x1
    1d60:      	mov	x1, x2
    1d64:      	fmov	x2, d31
    1d68:      	bl	0x1d68 <_coil.core.Eq$slice<u8>$=+0x38>
		0000000000001d68:  ARM64_RELOC_BRANCH26	_memcmp
    1d6c:      	sxtw	x0, w0
    1d70:      	cmp	x0, #0x0
    1d74:      	cset	w0, eq
    1d78:      	ubfx	x0, x0, #0, #8
    1d7c:      	b	0x1d84 <_coil.core.Eq$slice<u8>$=+0x54>
    1d80:      	movz	x0, #0x0, lsl #48
    1d84:      	ldr	x29, [sp]
    1d88:      	ldr	x30, [sp, #0x8]
    1d8c:      	add	sp, sp, #0x10
    1d90:      	ret

0000000000001d94 <_stogir.types.valid?>:
    1d94:      	sxtw	x1, w0
    1d98:      	cmp	x1, #0x0
    1d9c:      	b.lt	0x1db0 <_stogir.types.valid?+0x1c>
    1da0:      	cmp	x1, #0xd
    1da4:      	b.gt	0x1db0 <_stogir.types.valid?+0x1c>
    1da8:      	mov	x0, #0x1                ; =1
    1dac:      	b	0x1dec <_stogir.types.valid?+0x58>
    1db0:      	cmp	x1, #0xf
    1db4:      	b.le	0x1de8 <_stogir.types.valid?+0x54>
    1db8:      	cmp	x1, #0x80
    1dbc:      	b.ge	0x1de0 <_stogir.types.valid?+0x4c>
    1dc0:      	and	w0, w0, #0xf
    1dc4:      	ubfx	x0, x0, #0, #32
    1dc8:      	cmp	x0, #0x1
    1dcc:      	b.lt	0x1df0 <_stogir.types.valid?+0x5c>
    1dd0:      	cmp	x0, #0xd
    1dd4:      	cset	w0, le
    1dd8:      	ubfx	x0, x0, #0, #8
    1ddc:      	b	0x1df4 <_stogir.types.valid?+0x60>
    1de0:      	movz	x0, #0x0, lsl #48
    1de4:      	b	0x1dec <_stogir.types.valid?+0x58>
    1de8:      	movz	x0, #0x0, lsl #48
    1dec:      	ret
    1df0:      	movz	x0, #0x0, lsl #48
    1df4:      	b	0x1de4 <_stogir.types.valid?+0x50>

0000000000001df8 <_stogir.opcode.input-count>:
    1df8:      	sxtw	x0, w0
    1dfc:      	cmp	x0, #0x0
    1e00:      	b.lt	0x1e24 <_stogir.opcode.input-count+0x2c>
    1e04:      	cmp	x0, #0x83
    1e08:      	b.ge	0x1e24 <_stogir.opcode.input-count+0x2c>
    1e0c:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x47c>
		0000000000001e0c:  ARM64_RELOC_PAGE21	l_stogir.344
    1e10:      	ldr	x16, [x16]
		0000000000001e10:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    1e14:      	add	x0, x16, x0
    1e18:      	ldrsb	w0, [x0]
    1e1c:      	sxtb	x0, w0
    1e20:      	b	0x1e28 <_stogir.opcode.input-count+0x30>
    1e24:      	mov	x0, #-0x2               ; =-2
    1e28:      	ret

0000000000001e2c <_stogir.graph.operand>:
    1e2c:      	sub	sp, sp, #0x10
    1e30:      	mov	x3, sp
    1e34:      	sxtw	x1, w1
    1e38:      	cmp	x1, #0x0
    1e3c:      	b.le	0x1e80 <_stogir.graph.operand+0x54>
    1e40:      	lsl	x4, x1, #2
    1e44:      	add	x5, x0, #0x78
    1e48:      	ldr	x6, [x0, #0x8]
    1e4c:      	cmp	x1, x6
    1e50:      	b.ge	0x1eb4 <_stogir.graph.operand+0x88>
    1e54:      	ldr	x5, [x5, #0x8]
    1e58:      	cmp	x1, x5
    1e5c:      	b.ge	0x1eac <_stogir.graph.operand+0x80>
    1e60:      	ldr	x5, [x0, #0x78]
    1e64:      	add	x5, x4, x5
    1e68:      	ldr	w5, [x5]
    1e6c:      	sxtw	x5, w5
    1e70:      	cmp	x5, #0x0
    1e74:      	cset	w5, ge
    1e78:      	ubfx	x5, x5, #0, #8
    1e7c:      	b	0x1eb0 <_stogir.graph.operand+0x84>
    1e80:      	movz	x1, #0x0, lsl #48
    1e84:      	movz	x0, #0x0, lsl #48
    1e88:      	str	x1, [x3]
    1e8c:      	str	x0, [x3, #0x8]
    1e90:      	ldr	x0, [sp]
    1e94:      	ldr	x1, [sp, #0x8]
    1e98:      	add	sp, sp, #0x10
    1e9c:      	ret
    1ea0:      	movz	x1, #0x0, lsl #48
    1ea4:      	movz	x0, #0x0, lsl #48
    1ea8:      	b	0x1e88 <_stogir.graph.operand+0x5c>
    1eac:      	movz	x5, #0x0, lsl #48
    1eb0:      	b	0x1eb8 <_stogir.graph.operand+0x8c>
    1eb4:      	movz	x5, #0x0, lsl #48
    1eb8:      	cmp	x5, #0x0
    1ebc:      	b.eq	0x1e80 <_stogir.graph.operand+0x54>
    1ec0:      	sxtw	x2, w2
    1ec4:      	cmp	x2, #0x1
    1ec8:      	b.lt	0x1ea0 <_stogir.graph.operand+0x74>
    1ecc:      	ldr	x5, [x0, #0x78]
    1ed0:      	add	x4, x4, x5
    1ed4:      	ldr	w4, [x4]
    1ed8:      	sxtw	x4, w4
    1edc:      	cmp	x2, x4
    1ee0:      	b.gt	0x1ea0 <_stogir.graph.operand+0x74>
    1ee4:      	ldr	x0, [x0]
    1ee8:      	asr	x16, x2, #63
    1eec:      	lsr	x16, x16, #62
    1ef0:      	add	x4, x2, x16
    1ef4:      	asr	x4, x4, #2
    1ef8:      	asr	x16, x2, #63
    1efc:      	lsr	x16, x16, #62
    1f00:      	add	x2, x2, x16
    1f04:      	and	x2, x2, #0x3
    1f08:      	sub	x2, x2, x16
    1f0c:      	add	x1, x4, x1
    1f10:      	add	x0, x0, x1, lsl #4
    1f14:      	add	x0, x0, x2, lsl #2
    1f18:      	ldr	w0, [x0]
    1f1c:      	sxtw	x0, w0
    1f20:      	and	x0, x0, #0xffffffff
    1f24:      	mov	x1, #0x1                ; =1
    1f28:      	b	0x1ea8 <_stogir.graph.operand+0x7c>

0000000000001f2c <_stogir.graph.borrow-node>:
    1f2c:      	sxtw	x1, w1
    1f30:      	add	x2, x0, #0x28
    1f34:      	cmp	x1, #0x0
    1f38:      	cset	w3, gt
    1f3c:      	movz	x16, #0x0, lsl #48
    1f40:      	sub	x4, x16, x1
    1f44:      	sub	x5, x4, #0x1
    1f48:      	uxtb	w16, w3
    1f4c:      	cmp	w16, wzr
    1f50:      	b.eq	0x1f90 <_stogir.graph.borrow-node+0x64>
    1f54:      	ldr	x2, [x0, #0x8]
    1f58:      	cmp	x1, x2
    1f5c:      	b.ge	0x1fdc <_stogir.graph.borrow-node+0xb0>
    1f60:      	add	x2, x0, #0x78
    1f64:      	ldr	x2, [x2, #0x8]
    1f68:      	cmp	x1, x2
    1f6c:      	b.ge	0x201c <_stogir.graph.borrow-node+0xf0>
    1f70:      	ldr	x2, [x0, #0x78]
    1f74:      	add	x2, x2, x1, lsl #2
    1f78:      	ldr	w2, [x2]
    1f7c:      	sxtw	x2, w2
    1f80:      	cmp	x2, #0x0
    1f84:      	cset	w2, ge
    1f88:      	ubfx	x2, x2, #0, #8
    1f8c:      	b	0x2020 <_stogir.graph.borrow-node+0xf4>
    1f90:      	cmp	x1, #0x0
    1f94:      	b.ge	0x1fe4 <_stogir.graph.borrow-node+0xb8>
    1f98:      	add	x6, x0, #0x50
    1f9c:      	ldr	x2, [x2, #0x8]
    1fa0:      	ldr	x6, [x6, #0x8]
    1fa4:      	cmp	x2, x6
    1fa8:      	b.ne	0x1fd4 <_stogir.graph.borrow-node+0xa8>
    1fac:      	cmp	x4, x2
    1fb0:      	b.gt	0x2024 <_stogir.graph.borrow-node+0xf8>
    1fb4:      	ldr	x2, [x0, #0x50]
    1fb8:      	add	x2, x2, x5, lsl #2
    1fbc:      	ldr	w2, [x2]
    1fc0:      	sxtw	x2, w2
    1fc4:      	cmp	x2, #0x0
    1fc8:      	cset	w2, gt
    1fcc:      	ubfx	x2, x2, #0, #8
    1fd0:      	b	0x2028 <_stogir.graph.borrow-node+0xfc>
    1fd4:      	movz	x2, #0x0, lsl #48
    1fd8:      	b	0x1fe8 <_stogir.graph.borrow-node+0xbc>
    1fdc:      	movz	x2, #0x0, lsl #48
    1fe0:      	b	0x1fe8 <_stogir.graph.borrow-node+0xbc>
    1fe4:      	movz	x2, #0x0, lsl #48
    1fe8:      	cmp	x2, #0x0
    1fec:      	b.eq	0x2014 <_stogir.graph.borrow-node+0xe8>
    1ff0:      	uxtb	w16, w3
    1ff4:      	cmp	w16, wzr
    1ff8:      	b.eq	0x2008 <_stogir.graph.borrow-node+0xdc>
    1ffc:      	ldr	x0, [x0]
    2000:      	add	x0, x0, x1, lsl #4
    2004:      	b	0x2010 <_stogir.graph.borrow-node+0xe4>
    2008:      	ldr	x0, [x0, #0x28]
    200c:      	add	x0, x0, x5, lsl #4
    2010:      	b	0x2018 <_stogir.graph.borrow-node+0xec>
    2014:      	movz	x0, #0x0, lsl #48
    2018:      	ret
    201c:      	movz	x2, #0x0, lsl #48
    2020:      	b	0x1fe0 <_stogir.graph.borrow-node+0xb4>
    2024:      	movz	x2, #0x0, lsl #48
    2028:      	b	0x1fd8 <_stogir.graph.borrow-node+0xac>

000000000000202c <_stogir.verify.classifications>:
    202c:      	sub	sp, sp, #0x70
    2030:      	str	x29, [sp]
    2034:      	str	x30, [sp, #0x8]
    2038:      	mov	x29, sp
    203c:      	str	x19, [sp, #0x20]
    2040:      	str	x20, [sp, #0x28]
    2044:      	str	x21, [sp, #0x30]
    2048:      	str	x22, [sp, #0x38]
    204c:      	str	x23, [sp, #0x40]
    2050:      	str	x24, [sp, #0x48]
    2054:      	str	x25, [sp, #0x50]
    2058:      	str	x26, [sp, #0x58]
    205c:      	str	x27, [sp, #0x60]
    2060:      	str	x28, [sp, #0x68]
    2064:      	ldr	w4, [x2]
    2068:      	uxtb	w19, w4
    206c:      	orr	x5, x19, xzr
    2070:      	orr	w20, w5, wzr
    2074:      	ubfx	x21, x4, #8, #8
    2078:      	orr	x4, x21, xzr
    207c:      	mov	x22, x0
    2080:      	mov	w0, w4
    2084:      	mov	w23, w1
    2088:      	mov	x24, x2
    208c:      	mov	w25, w3
    2090:      	bl	0x2090 <_stogir.verify.classifications+0x64>
		0000000000002090:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2094:      	fmov	d31, x0
    2098:      	mov	w0, w20
    209c:      	fmov	x20, d31
    20a0:      	bl	0x20a0 <_stogir.verify.classifications+0x74>
		00000000000020a0:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    20a4:      	cmp	x0, #0x0
    20a8:      	b.eq	0x20c4 <_stogir.verify.classifications+0x98>
    20ac:      	cmp	x20, #0x0
    20b0:      	cset	w0, ne
    20b4:      	uxtb	w16, w0
    20b8:      	cmp	w16, wzr
    20bc:      	cset	x26, eq
    20c0:      	b	0x20c8 <_stogir.verify.classifications+0x9c>
    20c4:      	movz	x26, #0x0, lsl #48
    20c8:      	cmp	x26, #0x0
    20cc:      	cset	w27, ne
    20d0:      	uxtb	w16, w27
    20d4:      	cmp	w16, wzr
    20d8:      	b.eq	0x210c <_stogir.verify.classifications+0xe0>
    20dc:      	ldr	w0, [x24, #0x4]
    20e0:      	mov	w1, w0
    20e4:      	mov	x0, x22
    20e8:      	bl	0x20e8 <_stogir.verify.classifications+0xbc>
		00000000000020e8:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    20ec:      	cmp	x0, #0x0
    20f0:      	b.ne	0x20fc <_stogir.verify.classifications+0xd0>
    20f4:      	movn	w28, #0x0, lsl #16
    20f8:      	b	0x2108 <_stogir.verify.classifications+0xdc>
    20fc:      	ldr	w0, [x0]
    2100:      	ubfx	x0, x0, #8, #8
    2104:      	orr	x28, x0, xzr
    2108:      	b	0x2110 <_stogir.verify.classifications+0xe4>
    210c:      	movn	w28, #0x0, lsl #16
    2110:      	sxtw	x0, w28
    2114:      	cmp	x26, #0x0
    2118:      	b.eq	0x25a8 <_stogir.verify.classifications+0x57c>
    211c:      	mov	x26, x0
    2120:      	mov	w0, w28
    2124:      	bl	0x2124 <_stogir.verify.classifications+0xf8>
		0000000000002124:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2128:      	cmp	x0, #0x0
    212c:      	b.eq	0x2544 <_stogir.verify.classifications+0x518>
    2130:      	movz	x0, #0x0, lsl #48
    2134:      	b	0x213c <_stogir.verify.classifications+0x110>
    2138:      	mov	x0, #0x1                ; =1
    213c:      	b	0x2154 <_stogir.verify.classifications+0x128>
    2140:      	movz	x15, #0x0, lsl #48
    2144:      	b	0x21c8 <_stogir.verify.classifications+0x19c>
    2148:      	movz	x20, #0x0, lsl #48
    214c:      	b	0x21d0 <_stogir.verify.classifications+0x1a4>
    2150:      	movz	x0, #0x0, lsl #48
    2154:      	sxtw	x25, w25
    2158:      	cmp	x26, #0xf
    215c:      	cset	w1, gt
    2160:      	cmp	x26, #0x80
    2164:      	cset	w2, lt
    2168:      	cmp	x19, #0x83
    216c:      	cset	w3, lt
    2170:      	sxtw	x23, w23
    2174:      	and	w4, w28, #0xf
    2178:      	adrp	x16, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002178:  ARM64_RELOC_PAGE21	l_stogir.345
    217c:      	ldr	x16, [x16]
		000000000000217c:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    2180:      	add	x5, x16, x19, lsl #2
    2184:      	add	x6, x22, #0x28
    2188:      	add	x7, x22, #0x78
    218c:      	add	x8, x22, #0x50
    2190:      	cmp	x23, #0x0
    2194:      	cset	w9, le
    2198:      	lsl	x10, x23, #2
    219c:      	ubfx	x4, x4, #0, #32
    21a0:      	cmp	x4, #0x1
    21a4:      	cset	w11, ge
    21a8:      	cmp	x4, #0xd
    21ac:      	cset	w4, le
    21b0:      	ubfx	x4, x4, #0, #8
    21b4:      	mov	x12, #0x1               ; =1
    21b8:      	b	0x2270 <_stogir.verify.classifications+0x244>
    21bc:      	movz	x15, #0x0, lsl #48
    21c0:      	b	0x21f0 <_stogir.verify.classifications+0x1c4>
    21c4:      	movz	x15, #0x0, lsl #48
    21c8:      	b	0x21f8 <_stogir.verify.classifications+0x1cc>
    21cc:      	movz	x20, #0x0, lsl #48
    21d0:      	b	0x2268 <_stogir.verify.classifications+0x23c>
    21d4:      	sub	w13, w13, #0x1
    21d8:      	lsl	w13, w13, #2
    21dc:      	ubfx	x13, x13, #0, #32
    21e0:      	lsr	x13, x15, x13
    21e4:      	and	w13, w13, #0xf
    21e8:      	b	0x22b4 <_stogir.verify.classifications+0x288>
    21ec:      	movz	x15, #0x0, lsl #48
    21f0:      	b	0x21f8 <_stogir.verify.classifications+0x1cc>
    21f4:      	movz	x15, #0x0, lsl #48
    21f8:      	cmp	x15, #0x0
    21fc:      	b.eq	0x2224 <_stogir.verify.classifications+0x1f8>
    2200:      	uxtb	w16, w14
    2204:      	cmp	w16, wzr
    2208:      	b.eq	0x2218 <_stogir.verify.classifications+0x1ec>
    220c:      	ldr	x14, [x22]
    2210:      	add	x13, x14, x13, lsl #4
    2214:      	b	0x2220 <_stogir.verify.classifications+0x1f4>
    2218:      	ldr	x13, [x22, #0x28]
    221c:      	add	x13, x13, x19, lsl #4
    2220:      	b	0x2228 <_stogir.verify.classifications+0x1fc>
    2224:      	movz	x13, #0x0, lsl #48
    2228:      	cmp	x13, #0x0
    222c:      	b.eq	0x2268 <_stogir.verify.classifications+0x23c>
    2230:      	ldr	w13, [x13]
    2234:      	ubfx	x13, x13, #8, #8
    2238:      	orr	x14, x13, xzr
    223c:      	cmp	x14, #0xf
    2240:      	b.le	0x2268 <_stogir.verify.classifications+0x23c>
    2244:      	cmp	x14, #0x80
    2248:      	b.ge	0x2268 <_stogir.verify.classifications+0x23c>
    224c:      	and	w13, w13, #0xf
    2250:      	ubfx	x13, x13, #0, #32
    2254:      	cmp	x13, #0x1
    2258:      	b.lt	0x2268 <_stogir.verify.classifications+0x23c>
    225c:      	cmp	x13, #0xd
    2260:      	b.gt	0x2268 <_stogir.verify.classifications+0x23c>
    2264:      	mov	x20, #0x1               ; =1
    2268:      	add	x12, x12, #0x1
    226c:      	sxtw	x12, w12
    2270:      	cmp	x20, #0x0
    2274:      	b.ne	0x23f0 <_stogir.verify.classifications+0x3c4>
    2278:      	cmp	x12, x25
    227c:      	b.gt	0x23f0 <_stogir.verify.classifications+0x3c4>
    2280:      	orr	w13, w12, wzr
    2284:      	sxtw	x14, w13
    2288:      	uxtb	w16, w3
    228c:      	cmp	w16, wzr
    2290:      	b.eq	0x22b8 <_stogir.verify.classifications+0x28c>
    2294:      	ldr	w15, [x5]
    2298:      	cmp	x14, #0x0
    229c:      	b.le	0x22b0 <_stogir.verify.classifications+0x284>
    22a0:      	cmp	x14, #0x4
    22a4:      	b.le	0x21d4 <_stogir.verify.classifications+0x1a8>
    22a8:      	mov	w13, #0x4               ; =4
    22ac:      	b	0x21d8 <_stogir.verify.classifications+0x1ac>
    22b0:      	movz	w13, #0x0, lsl #16
    22b4:      	b	0x22bc <_stogir.verify.classifications+0x290>
    22b8:      	movz	w13, #0x0, lsl #16
    22bc:      	adrp	x16, 0x2000 <_stogir.graph.borrow-node+0xd4>
		00000000000022bc:  ARM64_RELOC_PAGE21	l_stogir.346
    22c0:      	ldr	x16, [x16]
		00000000000022c0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    22c4:      	ldr	w15, [x16]
    22c8:      	ubfx	x13, x13, #0, #32
    22cc:      	cmp	x13, x15
    22d0:      	b.eq	0x22e8 <_stogir.verify.classifications+0x2bc>
    22d4:      	adrp	x16, 0x2000 <_stogir.graph.borrow-node+0xd4>
		00000000000022d4:  ARM64_RELOC_PAGE21	l_stogir.347
    22d8:      	ldr	x16, [x16]
		00000000000022d8:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    22dc:      	ldr	w15, [x16]
    22e0:      	cmp	x13, x15
    22e4:      	b.ne	0x2268 <_stogir.verify.classifications+0x23c>
    22e8:      	cmp	x12, #0x1
    22ec:      	b.ne	0x2328 <_stogir.verify.classifications+0x2fc>
    22f0:      	uxtb	w16, w27
    22f4:      	cmp	w16, wzr
    22f8:      	b.eq	0x2328 <_stogir.verify.classifications+0x2fc>
    22fc:      	uxtb	w16, w1
    2300:      	cmp	w16, wzr
    2304:      	b.eq	0x21cc <_stogir.verify.classifications+0x1a0>
    2308:      	uxtb	w16, w2
    230c:      	cmp	w16, wzr
    2310:      	b.eq	0x2148 <_stogir.verify.classifications+0x11c>
    2314:      	uxtb	w16, w11
    2318:      	cmp	w16, wzr
    231c:      	b.eq	0x24f8 <_stogir.verify.classifications+0x4cc>
    2320:      	mov	x20, x4
    2324:      	b	0x24fc <_stogir.verify.classifications+0x4d0>
    2328:      	cmp	x12, #0x1
    232c:      	b.ne	0x2390 <_stogir.verify.classifications+0x364>
    2330:      	ldr	w13, [x24, #0x4]
    2334:      	sxtw	x13, w13
    2338:      	cmp	x13, #0x0
    233c:      	cset	w14, gt
    2340:      	movz	x16, #0x0, lsl #48
    2344:      	sub	x15, x16, x13
    2348:      	sub	x19, x15, #0x1
    234c:      	uxtb	w16, w14
    2350:      	cmp	w16, wzr
    2354:      	b.eq	0x23a0 <_stogir.verify.classifications+0x374>
    2358:      	ldr	x15, [x22, #0x8]
    235c:      	cmp	x13, x15
    2360:      	b.ge	0x21ec <_stogir.verify.classifications+0x1c0>
    2364:      	ldr	x15, [x7, #0x8]
    2368:      	cmp	x13, x15
    236c:      	b.ge	0x21bc <_stogir.verify.classifications+0x190>
    2370:      	ldr	x15, [x22, #0x78]
    2374:      	add	x15, x15, x13, lsl #2
    2378:      	ldr	w15, [x15]
    237c:      	sxtw	x15, w15
    2380:      	cmp	x15, #0x0
    2384:      	cset	w15, ge
    2388:      	ubfx	x15, x15, #0, #8
    238c:      	b	0x21c0 <_stogir.verify.classifications+0x194>
    2390:      	cmp	x12, #0x2
    2394:      	b.ne	0x23e0 <_stogir.verify.classifications+0x3b4>
    2398:      	ldr	w13, [x24, #0x8]
    239c:      	b	0x2334 <_stogir.verify.classifications+0x308>
    23a0:      	cmp	x13, #0x0
    23a4:      	b.ge	0x21f4 <_stogir.verify.classifications+0x1c8>
    23a8:      	ldr	x21, [x6, #0x8]
    23ac:      	ldr	x26, [x8, #0x8]
    23b0:      	cmp	x21, x26
    23b4:      	b.ne	0x21c4 <_stogir.verify.classifications+0x198>
    23b8:      	cmp	x15, x21
    23bc:      	b.gt	0x2140 <_stogir.verify.classifications+0x114>
    23c0:      	ldr	x15, [x22, #0x50]
    23c4:      	add	x15, x15, x19, lsl #2
    23c8:      	ldr	w15, [x15]
    23cc:      	sxtw	x15, w15
    23d0:      	cmp	x15, #0x0
    23d4:      	cset	w15, gt
    23d8:      	ubfx	x15, x15, #0, #8
    23dc:      	b	0x2144 <_stogir.verify.classifications+0x118>
    23e0:      	cmp	x12, #0x3
    23e4:      	b.ne	0x2454 <_stogir.verify.classifications+0x428>
    23e8:      	ldr	w13, [x24, #0xc]
    23ec:      	b	0x239c <_stogir.verify.classifications+0x370>
    23f0:      	uxtb	w20, w20
    23f4:      	uxtb	w0, w0
    23f8:      	add	x16, sp, #0x10
    23fc:      	movz	w17, #0x0, lsl #16
    2400:      	strh	w17, [x16]
    2404:      	add	x16, sp, #0x10
    2408:      	strb	w20, [x16]
    240c:      	add	x16, sp, #0x10
    2410:      	strb	w0, [x16, #0x1]
    2414:      	add	x16, sp, #0x10
    2418:      	ldrh	w0, [x16]
    241c:      	ldr	x19, [sp, #0x20]
    2420:      	ldr	x20, [sp, #0x28]
    2424:      	ldr	x21, [sp, #0x30]
    2428:      	ldr	x22, [sp, #0x38]
    242c:      	ldr	x23, [sp, #0x40]
    2430:      	ldr	x24, [sp, #0x48]
    2434:      	ldr	x25, [sp, #0x50]
    2438:      	ldr	x26, [sp, #0x58]
    243c:      	ldr	x27, [sp, #0x60]
    2440:      	ldr	x28, [sp, #0x68]
    2444:      	ldr	x29, [sp]
    2448:      	ldr	x30, [sp, #0x8]
    244c:      	add	sp, sp, #0x70
    2450:      	ret
    2454:      	uxtb	w16, w9
    2458:      	cmp	w16, wzr
    245c:      	b.ne	0x2504 <_stogir.verify.classifications+0x4d8>
    2460:      	ldr	x13, [x22, #0x8]
    2464:      	cmp	x23, x13
    2468:      	b.ge	0x2504 <_stogir.verify.classifications+0x4d8>
    246c:      	ldr	x13, [x7, #0x8]
    2470:      	cmp	x23, x13
    2474:      	b.ge	0x2504 <_stogir.verify.classifications+0x4d8>
    2478:      	ldr	x13, [x22, #0x78]
    247c:      	add	x13, x10, x13
    2480:      	ldr	w13, [x13]
    2484:      	sxtw	x13, w13
    2488:      	cmp	x13, #0x0
    248c:      	b.lt	0x2504 <_stogir.verify.classifications+0x4d8>
    2490:      	cmp	x14, #0x1
    2494:      	b.lt	0x2584 <_stogir.verify.classifications+0x558>
    2498:      	ldr	x13, [x22, #0x78]
    249c:      	add	x13, x10, x13
    24a0:      	ldr	w13, [x13]
    24a4:      	sxtw	x13, w13
    24a8:      	cmp	x14, x13
    24ac:      	b.gt	0x2584 <_stogir.verify.classifications+0x558>
    24b0:      	ldr	x13, [x22]
    24b4:      	asr	x16, x14, #63
    24b8:      	lsr	x16, x16, #62
    24bc:      	add	x15, x14, x16
    24c0:      	asr	x15, x15, #2
    24c4:      	asr	x16, x14, #63
    24c8:      	lsr	x16, x16, #62
    24cc:      	add	x14, x14, x16
    24d0:      	and	x14, x14, #0x3
    24d4:      	sub	x14, x14, x16
    24d8:      	add	x15, x15, x23
    24dc:      	add	x13, x13, x15, lsl #4
    24e0:      	add	x13, x13, x14, lsl #2
    24e4:      	ldr	w13, [x13]
    24e8:      	movn	w17, #0x0, lsl #16
    24ec:      	and	w13, w13, w17
    24f0:      	mov	w14, #0x1               ; =1
    24f4:      	b	0x258c <_stogir.verify.classifications+0x560>
    24f8:      	movz	x20, #0x0, lsl #48
    24fc:      	b	0x214c <_stogir.verify.classifications+0x120>
    2500:      	b	0x23ec <_stogir.verify.classifications+0x3c0>
    2504:      	movz	w14, #0x0, lsl #16
    2508:      	movz	w13, #0x0, lsl #16
    250c:      	ubfx	x14, x14, #0, #32
    2510:      	lsr	x16, x14, #0
    2514:      	cmp	x16, #0x1
    2518:      	b.eq	0x2534 <_stogir.verify.classifications+0x508>
    251c:      	b.lo	0x2524 <_stogir.verify.classifications+0x4f8>
    2520:      	b	0x2538 <_stogir.verify.classifications+0x50c>
    2524:      	cmp	x16, #0x0
    2528:      	b.eq	0x2530 <_stogir.verify.classifications+0x504>
    252c:      	b	0x2538 <_stogir.verify.classifications+0x50c>
    2530:      	b	0x253c <_stogir.verify.classifications+0x510>
    2534:      	b	0x2500 <_stogir.verify.classifications+0x4d4>
    2538:      	b	0x25a0 <_stogir.verify.classifications+0x574>
    253c:      	movz	w13, #0x0, lsl #16
    2540:      	b	0x2500 <_stogir.verify.classifications+0x4d4>
    2544:      	cmp	x19, #0x18
    2548:      	b.ne	0x2554 <_stogir.verify.classifications+0x528>
    254c:      	mov	x0, #0x1                ; =1
    2550:      	b	0x213c <_stogir.verify.classifications+0x110>
    2554:      	cmp	x19, #0x19
    2558:      	b.ne	0x2564 <_stogir.verify.classifications+0x538>
    255c:      	mov	x0, #0x1                ; =1
    2560:      	b	0x213c <_stogir.verify.classifications+0x110>
    2564:      	cmp	x21, #0xc
    2568:      	b.eq	0x2138 <_stogir.verify.classifications+0x10c>
    256c:      	cmp	x21, #0xd
    2570:      	b.eq	0x2138 <_stogir.verify.classifications+0x10c>
    2574:      	cmp	x26, #0xc
    2578:      	b.ne	0x2590 <_stogir.verify.classifications+0x564>
    257c:      	mov	x0, #0x1                ; =1
    2580:      	b	0x259c <_stogir.verify.classifications+0x570>
    2584:      	movz	w14, #0x0, lsl #16
    2588:      	movz	w13, #0x0, lsl #16
    258c:      	b	0x250c <_stogir.verify.classifications+0x4e0>
    2590:      	cmp	x26, #0xd
    2594:      	cset	w0, eq
    2598:      	ubfx	x0, x0, #0, #8
    259c:      	b	0x213c <_stogir.verify.classifications+0x110>
    25a0:      	brk	#0
    25a4:      	b	0x25a0 <_stogir.verify.classifications+0x574>
    25a8:      	mov	x26, x0
    25ac:      	b	0x2150 <_stogir.verify.classifications+0x124>

00000000000025b0 <_stogir.vector.validate>:
    25b0:      	sub	sp, sp, #0x220
    25b4:      	str	x29, [sp]
    25b8:      	str	x30, [sp, #0x8]
    25bc:      	mov	x29, sp
    25c0:      	str	x19, [sp, #0x1d0]
    25c4:      	str	x20, [sp, #0x1d8]
    25c8:      	str	x21, [sp, #0x1e0]
    25cc:      	str	x22, [sp, #0x1e8]
    25d0:      	str	x23, [sp, #0x1f0]
    25d4:      	str	x24, [sp, #0x1f8]
    25d8:      	str	x25, [sp, #0x200]
    25dc:      	str	x26, [sp, #0x208]
    25e0:      	str	x27, [sp, #0x210]
    25e4:      	str	x28, [sp, #0x218]
    25e8:      	orr	w19, w1, wzr
    25ec:      	mov	x20, x8
    25f0:      	add	x8, sp, #0x10
    25f4:      	mov	x21, x0
    25f8:      	mov	w22, w1
    25fc:      	mov	w1, w19
    2600:      	mov	w23, w2
    2604:      	bl	0x2604 <_stogir.vector.validate+0x54>
		0000000000002604:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    2608:      	add	x16, sp, #0x10
    260c:      	ldr	w0, [x16]
    2610:      	lsr	x16, x0, #0
    2614:      	cmp	x16, #0x1
    2618:      	b.eq	0x2634 <_stogir.vector.validate+0x84>
    261c:      	b.lo	0x2624 <_stogir.vector.validate+0x74>
    2620:      	b	0x2638 <_stogir.vector.validate+0x88>
    2624:      	cmp	x16, #0x0
    2628:      	b.eq	0x2630 <_stogir.vector.validate+0x80>
    262c:      	b	0x2638 <_stogir.vector.validate+0x88>
    2630:      	b	0x263c <_stogir.vector.validate+0x8c>
    2634:      	b	0x26c8 <_stogir.vector.validate+0x118>
    2638:      	b	0x28e4 <_stogir.vector.validate+0x334>
    263c:      	str	x20, [sp, #0x1a8]
    2640:      	mov	x0, #0x1                ; =1
    2644:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002644:  ARM64_RELOC_PAGE21	l_stogir.348
    2648:      	ldr	x19, [x19]
		0000000000002648:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    264c:      	mov	x25, #0x1a              ; =26
    2650:      	b	0x2680 <_stogir.vector.validate+0xd0>
    2654:      	add	x8, sp, #0x70
    2658:      	mov	x0, x21
    265c:      	ldr	w1, [sp, #0x1a0]
    2660:      	mov	w2, w23
    2664:      	bl	0x2664 <_stogir.vector.validate+0xb4>
		0000000000002664:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    2668:      	add	x16, sp, #0x70
    266c:      	ldr	x0, [x16]
    2670:      	add	x16, sp, #0x70
    2674:      	ldr	x19, [x16, #0x8]
    2678:      	add	x16, sp, #0x70
    267c:      	ldr	x25, [x16, #0x10]
    2680:      	ldr	x1, [sp, #0x1a8]
    2684:      	str	x0, [x1]
    2688:      	str	x19, [x1, #0x8]
    268c:      	str	x25, [x1, #0x10]
    2690:      	ldr	x19, [sp, #0x1d0]
    2694:      	ldr	x20, [sp, #0x1d8]
    2698:      	ldr	x21, [sp, #0x1e0]
    269c:      	ldr	x22, [sp, #0x1e8]
    26a0:      	ldr	x23, [sp, #0x1f0]
    26a4:      	ldr	x24, [sp, #0x1f8]
    26a8:      	ldr	x25, [sp, #0x200]
    26ac:      	ldr	x26, [sp, #0x208]
    26b0:      	ldr	x27, [sp, #0x210]
    26b4:      	ldr	x28, [sp, #0x218]
    26b8:      	ldr	x29, [sp]
    26bc:      	ldr	x30, [sp, #0x8]
    26c0:      	add	sp, sp, #0x220
    26c4:      	ret
    26c8:      	sxtw	x22, w22
    26cc:      	add	x16, sp, #0x10
    26d0:      	orr	x0, x16, xzr
    26d4:      	cmp	x22, #0x0
    26d8:      	cset	w24, le
    26dc:      	add	x0, x0, #0x8
    26e0:      	add	x16, sp, #0x10
    26e4:      	ldr	x25, [x16, #0x8]
    26e8:      	add	x16, sp, #0x40
    26ec:      	str	x25, [x16]
    26f0:      	ldr	x0, [x0, #0x8]
    26f4:      	add	x16, sp, #0x40
    26f8:      	str	x0, [x16, #0x8]
    26fc:      	uxtb	w16, w24
    2700:      	cmp	w16, wzr
    2704:      	b.eq	0x2720 <_stogir.vector.validate+0x170>
    2708:      	str	x20, [sp, #0x1a8]
    270c:      	mov	x0, #0x1                ; =1
    2710:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002710:  ARM64_RELOC_PAGE21	l_stogir.349
    2714:      	ldr	x19, [x19]
		0000000000002714:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    2718:      	mov	x25, #0x3b              ; =59
    271c:      	b	0x2680 <_stogir.vector.validate+0xd0>
    2720:      	lsl	x26, x22, #2
    2724:      	uxtb	w0, w25
    2728:      	add	x27, x21, #0x78
    272c:      	orr	x28, x0, xzr
    2730:      	cmp	x28, #0x44
    2734:      	cset	w0, eq
    2738:      	ldr	x1, [x21, #0x78]
    273c:      	add	x1, x1, x22, lsl #2
    2740:      	ldr	w1, [x1]
    2744:      	cmp	x28, #0x24
    2748:      	b.ne	0x278c <_stogir.vector.validate+0x1dc>
    274c:      	str	x20, [sp, #0x1a8]
    2750:      	str	w19, [sp, #0x1a0]
    2754:      	uxtb	w16, w0
    2758:      	cmp	w16, wzr
    275c:      	b.eq	0x2654 <_stogir.vector.validate+0xa4>
    2760:      	add	x8, sp, #0x50
    2764:      	mov	x0, x21
    2768:      	ldr	w1, [sp, #0x1a0]
    276c:      	bl	0x276c <_stogir.vector.validate+0x1bc>
		000000000000276c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    2770:      	add	x16, sp, #0x50
    2774:      	ldr	x0, [x16]
    2778:      	add	x16, sp, #0x50
    277c:      	ldr	x19, [x16, #0x8]
    2780:      	add	x16, sp, #0x50
    2784:      	ldr	x25, [x16, #0x10]
    2788:      	b	0x2680 <_stogir.vector.validate+0xd0>
    278c:      	uxtb	w16, w0
    2790:      	cmp	w16, wzr
    2794:      	b.ne	0x2f9c <_stogir.vector.validate+0x9ec>
    2798:      	cmp	x28, #0x3c
    279c:      	b.ne	0x284c <_stogir.vector.validate+0x29c>
    27a0:      	add	x8, sp, #0x90
    27a4:      	mov	x0, x21
    27a8:      	mov	w1, w19
    27ac:      	bl	0x27ac <_stogir.vector.validate+0x1fc>
		00000000000027ac:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    27b0:      	add	x16, sp, #0x90
    27b4:      	ldr	x0, [x16]
    27b8:      	add	x16, sp, #0x90
    27bc:      	ldr	x19, [x16, #0x8]
    27c0:      	add	x16, sp, #0x90
    27c4:      	ldr	x25, [x16, #0x10]
    27c8:      	str	x20, [sp, #0x1a8]
    27cc:      	b	0x2848 <_stogir.vector.validate+0x298>
    27d0:      	cmp	x28, #0x41
    27d4:      	cset	w0, eq
    27d8:      	cmp	x28, #0x48
    27dc:      	cset	w1, eq
    27e0:      	cmp	x28, #0x55
    27e4:      	cset	w2, ge
    27e8:      	cmp	x28, #0x58
    27ec:      	cset	w3, le
    27f0:      	cmp	x28, #0x47
    27f4:      	b.ne	0x28ec <_stogir.vector.validate+0x33c>
    27f8:      	str	x20, [sp, #0x1a8]
    27fc:      	mov	w20, w0
    2800:      	str	w1, [sp, #0x1b0]
    2804:      	str	w2, [sp, #0x1b8]
    2808:      	str	w3, [sp, #0x1c0]
    280c:      	mov	x0, x21
    2810:      	ldr	w1, [sp, #0x1a0]
    2814:      	bl	0x2814 <_stogir.vector.validate+0x264>
		0000000000002814:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2818:      	cmp	x0, #0x0
    281c:      	b.eq	0x290c <_stogir.vector.validate+0x35c>
    2820:      	add	x8, sp, #0xf0
    2824:      	mov	x0, x21
    2828:      	ldr	w1, [sp, #0x1a0]
    282c:      	bl	0x282c <_stogir.vector.validate+0x27c>
		000000000000282c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    2830:      	add	x16, sp, #0xf0
    2834:      	ldr	x0, [x16]
    2838:      	add	x16, sp, #0xf0
    283c:      	ldr	x19, [x16, #0x8]
    2840:      	add	x16, sp, #0xf0
    2844:      	ldr	x25, [x16, #0x10]
    2848:      	b	0x2680 <_stogir.vector.validate+0xd0>
    284c:      	cmp	x28, #0x3d
    2850:      	b.lt	0x2890 <_stogir.vector.validate+0x2e0>
    2854:      	cmp	x28, #0x3f
    2858:      	b.gt	0x2890 <_stogir.vector.validate+0x2e0>
    285c:      	add	x8, sp, #0xb0
    2860:      	mov	x0, x21
    2864:      	mov	w1, w19
    2868:      	mov	w2, w23
    286c:      	bl	0x286c <_stogir.vector.validate+0x2bc>
		000000000000286c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    2870:      	add	x16, sp, #0xb0
    2874:      	ldr	x0, [x16]
    2878:      	add	x16, sp, #0xb0
    287c:      	ldr	x19, [x16, #0x8]
    2880:      	add	x16, sp, #0xb0
    2884:      	ldr	x25, [x16, #0x10]
    2888:      	str	x20, [sp, #0x1a8]
    288c:      	b	0x2848 <_stogir.vector.validate+0x298>
    2890:      	mov	x0, x21
    2894:      	str	w19, [sp, #0x1a0]
    2898:      	fmov	s31, w1
    289c:      	mov	w1, w19
    28a0:      	fmov	w19, s31
    28a4:      	bl	0x28a4 <_stogir.vector.validate+0x2f4>
		00000000000028a4:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    28a8:      	cmp	x0, #0x0
    28ac:      	b.eq	0x27d0 <_stogir.vector.validate+0x220>
    28b0:      	add	x8, sp, #0xd0
    28b4:      	mov	x0, x21
    28b8:      	ldr	w1, [sp, #0x1a0]
    28bc:      	mov	w2, w23
    28c0:      	bl	0x28c0 <_stogir.vector.validate+0x310>
		00000000000028c0:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    28c4:      	add	x16, sp, #0xd0
    28c8:      	ldr	x0, [x16]
    28cc:      	add	x16, sp, #0xd0
    28d0:      	ldr	x19, [x16, #0x8]
    28d4:      	add	x16, sp, #0xd0
    28d8:      	ldr	x25, [x16, #0x10]
    28dc:      	str	x20, [sp, #0x1a8]
    28e0:      	b	0x2848 <_stogir.vector.validate+0x298>
    28e4:      	brk	#0
    28e8:      	b	0x28e4 <_stogir.vector.validate+0x334>
    28ec:      	cmp	x28, #0x4f
    28f0:      	b.ne	0x2988 <_stogir.vector.validate+0x3d8>
    28f4:      	str	x20, [sp, #0x1a8]
    28f8:      	mov	w20, w0
    28fc:      	str	w1, [sp, #0x1b0]
    2900:      	str	w2, [sp, #0x1b8]
    2904:      	str	w3, [sp, #0x1c0]
    2908:      	b	0x280c <_stogir.vector.validate+0x25c>
    290c:      	uxtb	w16, w20
    2910:      	cmp	w16, wzr
    2914:      	b.ne	0x2958 <_stogir.vector.validate+0x3a8>
    2918:      	ldr	w0, [sp, #0x1b0]
    291c:      	uxtb	w16, w0
    2920:      	cmp	w16, wzr
    2924:      	b.ne	0x2958 <_stogir.vector.validate+0x3a8>
    2928:      	ldr	w0, [sp, #0x1b8]
    292c:      	uxtb	w16, w0
    2930:      	cmp	w16, wzr
    2934:      	b.eq	0x2948 <_stogir.vector.validate+0x398>
    2938:      	ldr	w0, [sp, #0x1c0]
    293c:      	uxtb	w16, w0
    2940:      	cmp	w16, wzr
    2944:      	b.ne	0x2958 <_stogir.vector.validate+0x3a8>
    2948:      	movz	x0, #0x0, lsl #48
    294c:      	movz	x19, #0x0, lsl #48
    2950:      	movz	x25, #0x0, lsl #48
    2954:      	b	0x2984 <_stogir.vector.validate+0x3d4>
    2958:      	add	x8, sp, #0x110
    295c:      	mov	x0, x21
    2960:      	ldr	w1, [sp, #0x1a0]
    2964:      	mov	w2, w23
    2968:      	bl	0x2968 <_stogir.vector.validate+0x3b8>
		0000000000002968:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    296c:      	add	x16, sp, #0x110
    2970:      	ldr	x0, [x16]
    2974:      	add	x16, sp, #0x110
    2978:      	ldr	x19, [x16, #0x8]
    297c:      	add	x16, sp, #0x110
    2980:      	ldr	x25, [x16, #0x10]
    2984:      	b	0x2848 <_stogir.vector.validate+0x298>
    2988:      	cmp	x28, #0x50
    298c:      	b.eq	0x2fa8 <_stogir.vector.validate+0x9f8>
    2990:      	cmp	x28, #0x78
    2994:      	b.ne	0x29b0 <_stogir.vector.validate+0x400>
    2998:      	str	x20, [sp, #0x1a8]
    299c:      	mov	w20, w0
    29a0:      	str	w1, [sp, #0x1b0]
    29a4:      	str	w2, [sp, #0x1b8]
    29a8:      	str	w3, [sp, #0x1c0]
    29ac:      	b	0x280c <_stogir.vector.validate+0x25c>
    29b0:      	uxtb	w16, w0
    29b4:      	cmp	w16, wzr
    29b8:      	b.ne	0x2a78 <_stogir.vector.validate+0x4c8>
    29bc:      	uxtb	w16, w1
    29c0:      	cmp	w16, wzr
    29c4:      	b.ne	0x2a78 <_stogir.vector.validate+0x4c8>
    29c8:      	uxtb	w16, w2
    29cc:      	cmp	w16, wzr
    29d0:      	b.eq	0x29e0 <_stogir.vector.validate+0x430>
    29d4:      	uxtb	w16, w3
    29d8:      	cmp	w16, wzr
    29dc:      	b.ne	0x2a78 <_stogir.vector.validate+0x4c8>
    29e0:      	str	w1, [sp, #0x1b0]
    29e4:      	ldr	w1, [sp, #0x1a0]
    29e8:      	str	w2, [sp, #0x1b8]
    29ec:      	str	w3, [sp, #0x1c0]
    29f0:      	str	x20, [sp, #0x1a8]
    29f4:      	mov	w20, w0
    29f8:      	mov	x0, x21
    29fc:      	bl	0x29fc <_stogir.vector.validate+0x44c>
		00000000000029fc:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    2a00:      	cmp	x0, #0x0
    2a04:      	b.ne	0x280c <_stogir.vector.validate+0x25c>
    2a08:      	sxtw	x20, w19
    2a0c:      	ubfx	x25, x25, #0, #32
    2a10:      	ubfx	x0, x25, #8, #8
    2a14:      	orr	x1, x0, xzr
    2a18:      	orr	w19, w1, wzr
    2a1c:      	cmp	x28, #0x5b
    2a20:      	b.ne	0x2aa4 <_stogir.vector.validate+0x4f4>
    2a24:      	str	w19, [sp, #0x1c8]
    2a28:      	cmp	x20, #0x2
    2a2c:      	b.ne	0x2a90 <_stogir.vector.validate+0x4e0>
    2a30:      	add	x16, sp, #0x40
    2a34:      	ldr	w0, [x16, #0x4]
    2a38:      	add	x16, sp, #0x40
    2a3c:      	ldr	w1, [x16, #0x8]
    2a40:      	add	x8, sp, #0x130
    2a44:      	mov	w2, w23
    2a48:      	mov	w3, w0
    2a4c:      	mov	x0, x21
    2a50:      	mov	w4, w1
    2a54:      	ldr	w1, [sp, #0x1c8]
    2a58:      	bl	0x2a58 <_stogir.vector.validate+0x4a8>
		0000000000002a58:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    2a5c:      	add	x16, sp, #0x130
    2a60:      	ldr	x0, [x16]
    2a64:      	add	x16, sp, #0x130
    2a68:      	ldr	x19, [x16, #0x8]
    2a6c:      	add	x16, sp, #0x130
    2a70:      	ldr	x25, [x16, #0x10]
    2a74:      	b	0x2aa0 <_stogir.vector.validate+0x4f0>
    2a78:      	str	x20, [sp, #0x1a8]
    2a7c:      	mov	w20, w0
    2a80:      	str	w1, [sp, #0x1b0]
    2a84:      	str	w2, [sp, #0x1b8]
    2a88:      	str	w3, [sp, #0x1c0]
    2a8c:      	b	0x280c <_stogir.vector.validate+0x25c>
    2a90:      	mov	x0, #0x1                ; =1
    2a94:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002a94:  ARM64_RELOC_PAGE21	l_stogir.350
    2a98:      	ldr	x19, [x19]
		0000000000002a98:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    2a9c:      	mov	x25, #0x19              ; =25
    2aa0:      	b	0x2848 <_stogir.vector.validate+0x298>
    2aa4:      	cmp	x28, #0x5c
    2aa8:      	b.eq	0x2fc0 <_stogir.vector.validate+0xa10>
    2aac:      	orr	x25, x0, xzr
    2ab0:      	cmp	x28, #0x5d
    2ab4:      	b.ne	0x2b30 <_stogir.vector.validate+0x580>
    2ab8:      	mov	x28, x25
    2abc:      	cmp	x20, #0x3
    2ac0:      	b.ne	0x2b1c <_stogir.vector.validate+0x56c>
    2ac4:      	cmp	x28, #0x0
    2ac8:      	b.ne	0x2b1c <_stogir.vector.validate+0x56c>
    2acc:      	add	x16, sp, #0x40
    2ad0:      	ldr	w0, [x16, #0x4]
    2ad4:      	add	x16, sp, #0x40
    2ad8:      	ldr	w1, [x16, #0x8]
    2adc:      	add	x16, sp, #0x40
    2ae0:      	ldr	w2, [x16, #0xc]
    2ae4:      	add	x8, sp, #0x150
    2ae8:      	mov	w3, w1
    2aec:      	mov	w1, w23
    2af0:      	mov	w4, w2
    2af4:      	mov	w2, w0
    2af8:      	mov	x0, x21
    2afc:      	bl	0x2afc <_stogir.vector.validate+0x54c>
		0000000000002afc:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    2b00:      	add	x16, sp, #0x150
    2b04:      	ldr	x0, [x16]
    2b08:      	add	x16, sp, #0x150
    2b0c:      	ldr	x19, [x16, #0x8]
    2b10:      	add	x16, sp, #0x150
    2b14:      	ldr	x25, [x16, #0x10]
    2b18:      	b	0x2b2c <_stogir.vector.validate+0x57c>
    2b1c:      	mov	x0, #0x1                ; =1
    2b20:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002b20:  ARM64_RELOC_PAGE21	l_stogir.351
    2b24:      	ldr	x19, [x19]
		0000000000002b24:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    2b28:      	mov	x25, #0x1a              ; =26
    2b2c:      	b	0x2aa0 <_stogir.vector.validate+0x4f0>
    2b30:      	cmp	x28, #0x5e
    2b34:      	b.eq	0x2fc8 <_stogir.vector.validate+0xa18>
    2b38:      	cmp	x28, #0x43
    2b3c:      	b.ne	0x2ba8 <_stogir.vector.validate+0x5f8>
    2b40:      	cmp	x25, #0xf
    2b44:      	b.le	0x2eb8 <_stogir.vector.validate+0x908>
    2b48:      	cmp	x25, #0x80
    2b4c:      	b.ge	0x2eb8 <_stogir.vector.validate+0x908>
    2b50:      	and	w0, w1, #0xf
    2b54:      	ubfx	x0, x0, #0, #32
    2b58:      	cmp	x0, #0x1
    2b5c:      	b.lt	0x2eb8 <_stogir.vector.validate+0x908>
    2b60:      	cmp	x0, #0xd
    2b64:      	b.gt	0x2eb8 <_stogir.vector.validate+0x908>
    2b68:      	mov	w0, w19
    2b6c:      	mov	w1, w23
    2b70:      	bl	0x2b70 <_stogir.vector.validate+0x5c0>
		0000000000002b70:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2b74:      	sxtw	x0, w0
    2b78:      	cmp	x0, #0x0
    2b7c:      	b.le	0x2eb8 <_stogir.vector.validate+0x908>
    2b80:      	cmp	x20, #0x3
    2b84:      	b.lt	0x2eb8 <_stogir.vector.validate+0x908>
    2b88:      	mov	w28, w19
    2b8c:      	mov	x0, x25
    2b90:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002b90:  ARM64_RELOC_PAGE21	l_stogir.352
    2b94:      	ldr	x19, [x19]
		0000000000002b94:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    2b98:      	movz	x25, #0x0, lsl #48
    2b9c:      	b	0x2ecc <_stogir.vector.validate+0x91c>
    2ba0:      	mov	x0, #0x1                ; =1
    2ba4:      	b	0x2b2c <_stogir.vector.validate+0x57c>
    2ba8:      	mov	x0, #0x1                ; =1
    2bac:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002bac:  ARM64_RELOC_PAGE21	l_stogir.353
    2bb0:      	ldr	x19, [x19]
		0000000000002bb0:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    2bb4:      	mov	x25, #0x28              ; =40
    2bb8:      	b	0x2ba4 <_stogir.vector.validate+0x5f4>
    2bbc:      	add	x16, sp, #0x40
    2bc0:      	ldr	w0, [x16, #0x4]
    2bc4:      	sxtw	x0, w0
    2bc8:      	ldr	x1, [x21, #0x78]
    2bcc:      	add	x0, x1, x0, lsl #2
    2bd0:      	ldr	w0, [x0]
    2bd4:      	add	w0, w0, #0x1
    2bd8:      	sxtw	x0, w0
    2bdc:      	cmp	x20, x0
    2be0:      	cset	w0, eq
    2be4:      	uxtb	w16, w0
    2be8:      	cmp	w16, wzr
    2bec:      	cset	x0, eq
    2bf0:      	cmp	x0, #0x0
    2bf4:      	b.eq	0x2c04 <_stogir.vector.validate+0x654>
    2bf8:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002bf8:  ARM64_RELOC_PAGE21	l_stogir.354
    2bfc:      	ldr	x19, [x19]
		0000000000002bfc:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    2c00:      	mov	x25, #0x19              ; =25
    2c04:      	add	x0, x21, #0x28
    2c08:      	add	x1, x21, #0x50
    2c0c:      	mov	x2, #0x2                ; =2
    2c10:      	b	0x2cfc <_stogir.vector.validate+0x74c>
    2c14:      	movz	x5, #0x0, lsl #48
    2c18:      	b	0x2c20 <_stogir.vector.validate+0x670>
    2c1c:      	movz	x5, #0x0, lsl #48
    2c20:      	cmp	x5, #0x0
    2c24:      	b.eq	0x2c58 <_stogir.vector.validate+0x6a8>
    2c28:      	uxtb	w16, w4
    2c2c:      	cmp	w16, wzr
    2c30:      	b.eq	0x2c44 <_stogir.vector.validate+0x694>
    2c34:      	ldr	x4, [x21]
    2c38:      	add	x3, x4, x3, lsl #4
    2c3c:      	ldr	x3, [x3]
    2c40:      	b	0x2c50 <_stogir.vector.validate+0x6a0>
    2c44:      	ldr	x3, [x21, #0x28]
    2c48:      	add	x3, x3, x6, lsl #4
    2c4c:      	ldr	x3, [x3]
    2c50:      	mov	w4, #0x1                ; =1
    2c54:      	b	0x2c60 <_stogir.vector.validate+0x6b0>
    2c58:      	movz	w4, #0x0, lsl #16
    2c5c:      	movz	x3, #0x0, lsl #48
    2c60:      	ubfx	x4, x4, #0, #32
    2c64:      	lsr	x16, x4, #0
    2c68:      	cmp	x16, #0x1
    2c6c:      	b.eq	0x2c88 <_stogir.vector.validate+0x6d8>
    2c70:      	b.lo	0x2c78 <_stogir.vector.validate+0x6c8>
    2c74:      	b	0x2c8c <_stogir.vector.validate+0x6dc>
    2c78:      	cmp	x16, #0x0
    2c7c:      	b.eq	0x2c84 <_stogir.vector.validate+0x6d4>
    2c80:      	b	0x2c8c <_stogir.vector.validate+0x6dc>
    2c84:      	b	0x2c90 <_stogir.vector.validate+0x6e0>
    2c88:      	b	0x2e98 <_stogir.vector.validate+0x8e8>
    2c8c:      	b	0x2f8c <_stogir.vector.validate+0x9dc>
    2c90:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002c90:  ARM64_RELOC_PAGE21	l_stogir.355
    2c94:      	ldr	x19, [x19]
		0000000000002c94:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    2c98:      	mov	x25, #0x18              ; =24
    2c9c:      	b	0x2cf4 <_stogir.vector.validate+0x744>
    2ca0:      	movz	w4, #0x0, lsl #16
    2ca4:      	movz	w3, #0x0, lsl #16
    2ca8:      	b	0x2cb8 <_stogir.vector.validate+0x708>
    2cac:      	nop
    2cb0:      	movz	w4, #0x0, lsl #16
    2cb4:      	movz	w3, #0x0, lsl #16
    2cb8:      	ubfx	x4, x4, #0, #32
    2cbc:      	lsr	x16, x4, #0
    2cc0:      	cmp	x16, #0x1
    2cc4:      	b.eq	0x2ce0 <_stogir.vector.validate+0x730>
    2cc8:      	b.lo	0x2cd0 <_stogir.vector.validate+0x720>
    2ccc:      	b	0x2ce4 <_stogir.vector.validate+0x734>
    2cd0:      	cmp	x16, #0x0
    2cd4:      	b.eq	0x2cdc <_stogir.vector.validate+0x72c>
    2cd8:      	b	0x2ce4 <_stogir.vector.validate+0x734>
    2cdc:      	b	0x2ce8 <_stogir.vector.validate+0x738>
    2ce0:      	b	0x2d50 <_stogir.vector.validate+0x7a0>
    2ce4:      	b	0x2f84 <_stogir.vector.validate+0x9d4>
    2ce8:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002ce8:  ARM64_RELOC_PAGE21	l_stogir.355
    2cec:      	ldr	x19, [x19]
		0000000000002cec:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    2cf0:      	mov	x25, #0x18              ; =24
    2cf4:      	add	x2, x2, #0x1
    2cf8:      	sxtw	x2, w2
    2cfc:      	cmp	x25, #0x0
    2d00:      	b.ne	0x2e70 <_stogir.vector.validate+0x8c0>
    2d04:      	cmp	x2, x20
    2d08:      	b.gt	0x2e70 <_stogir.vector.validate+0x8c0>
    2d0c:      	uxtb	w16, w24
    2d10:      	cmp	w16, wzr
    2d14:      	b.ne	0x2cb0 <_stogir.vector.validate+0x700>
    2d18:      	ldr	x3, [x21, #0x8]
    2d1c:      	cmp	x22, x3
    2d20:      	b.ge	0x2db4 <_stogir.vector.validate+0x804>
    2d24:      	ldr	x3, [x27, #0x8]
    2d28:      	cmp	x22, x3
    2d2c:      	b.ge	0x2dac <_stogir.vector.validate+0x7fc>
    2d30:      	ldr	x3, [x21, #0x78]
    2d34:      	add	x3, x26, x3
    2d38:      	ldr	w3, [x3]
    2d3c:      	sxtw	x3, w3
    2d40:      	cmp	x3, #0x0
    2d44:      	cset	w3, ge
    2d48:      	ubfx	x3, x3, #0, #8
    2d4c:      	b	0x2db0 <_stogir.vector.validate+0x800>
    2d50:      	sxtw	x3, w3
    2d54:      	cmp	x3, #0x0
    2d58:      	cset	w4, gt
    2d5c:      	movz	x16, #0x0, lsl #48
    2d60:      	sub	x5, x16, x3
    2d64:      	sub	x6, x5, #0x1
    2d68:      	uxtb	w16, w4
    2d6c:      	cmp	w16, wzr
    2d70:      	b.eq	0x2e30 <_stogir.vector.validate+0x880>
    2d74:      	ldr	x5, [x21, #0x8]
    2d78:      	cmp	x3, x5
    2d7c:      	b.ge	0x2c14 <_stogir.vector.validate+0x664>
    2d80:      	ldr	x5, [x27, #0x8]
    2d84:      	cmp	x3, x5
    2d88:      	b.ge	0x2f34 <_stogir.vector.validate+0x984>
    2d8c:      	ldr	x5, [x21, #0x78]
    2d90:      	add	x5, x5, x3, lsl #2
    2d94:      	ldr	w5, [x5]
    2d98:      	sxtw	x5, w5
    2d9c:      	cmp	x5, #0x0
    2da0:      	cset	w5, ge
    2da4:      	ubfx	x5, x5, #0, #8
    2da8:      	b	0x2f38 <_stogir.vector.validate+0x988>
    2dac:      	movz	x3, #0x0, lsl #48
    2db0:      	b	0x2db8 <_stogir.vector.validate+0x808>
    2db4:      	movz	x3, #0x0, lsl #48
    2db8:      	cmp	x3, #0x0
    2dbc:      	b.eq	0x2cb0 <_stogir.vector.validate+0x700>
    2dc0:      	orr	w3, w2, wzr
    2dc4:      	sxtw	x3, w3
    2dc8:      	cmp	x3, #0x1
    2dcc:      	b.lt	0x2ca0 <_stogir.vector.validate+0x6f0>
    2dd0:      	ldr	x4, [x21, #0x78]
    2dd4:      	add	x4, x26, x4
    2dd8:      	ldr	w4, [x4]
    2ddc:      	sxtw	x4, w4
    2de0:      	cmp	x3, x4
    2de4:      	b.gt	0x2ca0 <_stogir.vector.validate+0x6f0>
    2de8:      	ldr	x4, [x21]
    2dec:      	asr	x16, x3, #63
    2df0:      	lsr	x16, x16, #62
    2df4:      	add	x5, x3, x16
    2df8:      	asr	x5, x5, #2
    2dfc:      	asr	x16, x3, #63
    2e00:      	lsr	x16, x16, #62
    2e04:      	add	x3, x3, x16
    2e08:      	and	x3, x3, #0x3
    2e0c:      	sub	x3, x3, x16
    2e10:      	add	x5, x5, x22
    2e14:      	add	x4, x4, x5, lsl #4
    2e18:      	add	x3, x4, x3, lsl #2
    2e1c:      	ldr	w3, [x3]
    2e20:      	movn	w17, #0x0, lsl #16
    2e24:      	and	w3, w3, w17
    2e28:      	mov	w4, #0x1                ; =1
    2e2c:      	b	0x2ca8 <_stogir.vector.validate+0x6f8>
    2e30:      	cmp	x3, #0x0
    2e34:      	b.ge	0x2c1c <_stogir.vector.validate+0x66c>
    2e38:      	ldr	x7, [x0, #0x8]
    2e3c:      	ldr	x8, [x1, #0x8]
    2e40:      	cmp	x7, x8
    2e44:      	b.ne	0x2f2c <_stogir.vector.validate+0x97c>
    2e48:      	cmp	x5, x7
    2e4c:      	b.gt	0x2f60 <_stogir.vector.validate+0x9b0>
    2e50:      	ldr	x5, [x21, #0x50]
    2e54:      	add	x5, x5, x6, lsl #2
    2e58:      	ldr	w5, [x5]
    2e5c:      	sxtw	x5, w5
    2e60:      	cmp	x5, #0x0
    2e64:      	cset	w5, gt
    2e68:      	ubfx	x5, x5, #0, #8
    2e6c:      	b	0x2f64 <_stogir.vector.validate+0x9b4>
    2e70:      	cmp	x25, #0x0
    2e74:      	b.ne	0x2ba0 <_stogir.vector.validate+0x5f0>
    2e78:      	ldr	w0, [sp, #0x1c8]
    2e7c:      	mov	w1, w23
    2e80:      	bl	0x2e80 <_stogir.vector.validate+0x8d0>
		0000000000002e80:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2e84:      	sxtw	x0, w0
    2e88:      	and	x19, x0, #0xffffffff
    2e8c:      	movz	x0, #0x0, lsl #48
    2e90:      	movz	x25, #0x0, lsl #48
    2e94:      	b	0x2ba4 <_stogir.vector.validate+0x5f4>
    2e98:      	ubfx	x3, x3, #0, #32
    2e9c:      	ubfx	x3, x3, #8, #8
    2ea0:      	cmp	x3, x28
    2ea4:      	b.eq	0x2eb4 <_stogir.vector.validate+0x904>
    2ea8:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002ea8:  ARM64_RELOC_PAGE21	l_stogir.356
    2eac:      	ldr	x19, [x19]
		0000000000002eac:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    2eb0:      	mov	x25, #0x1e              ; =30
    2eb4:      	b	0x2c9c <_stogir.vector.validate+0x6ec>
    2eb8:      	mov	w28, w19
    2ebc:      	mov	x0, x25
    2ec0:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002ec0:  ARM64_RELOC_PAGE21	l_stogir.357
    2ec4:      	ldr	x19, [x19]
		0000000000002ec4:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    2ec8:      	mov	x25, #0x20              ; =32
    2ecc:      	add	x16, sp, #0x40
    2ed0:      	ldr	w1, [x16, #0x4]
    2ed4:      	add	x8, sp, #0x170
    2ed8:      	str	w28, [sp, #0x1c8]
    2edc:      	mov	x28, x0
    2ee0:      	mov	x0, x21
    2ee4:      	bl	0x2ee4 <_stogir.vector.validate+0x934>
		0000000000002ee4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    2ee8:      	add	x16, sp, #0x170
    2eec:      	ldr	w0, [x16]
    2ef0:      	lsr	x16, x0, #0
    2ef4:      	cmp	x16, #0x1
    2ef8:      	b.eq	0x2f14 <_stogir.vector.validate+0x964>
    2efc:      	b.lo	0x2f04 <_stogir.vector.validate+0x954>
    2f00:      	b	0x2f18 <_stogir.vector.validate+0x968>
    2f04:      	cmp	x16, #0x0
    2f08:      	b.eq	0x2f10 <_stogir.vector.validate+0x960>
    2f0c:      	b	0x2f18 <_stogir.vector.validate+0x968>
    2f10:      	b	0x2f1c <_stogir.vector.validate+0x96c>
    2f14:      	b	0x2f3c <_stogir.vector.validate+0x98c>
    2f18:      	b	0x2f94 <_stogir.vector.validate+0x9e4>
    2f1c:      	adrp	x19, 0x2000 <_stogir.graph.borrow-node+0xd4>
		0000000000002f1c:  ARM64_RELOC_PAGE21	l_stogir.358
    2f20:      	ldr	x19, [x19]
		0000000000002f20:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    2f24:      	mov	x25, #0x19              ; =25
    2f28:      	b	0x2c04 <_stogir.vector.validate+0x654>
    2f2c:      	movz	x5, #0x0, lsl #48
    2f30:      	b	0x2c20 <_stogir.vector.validate+0x670>
    2f34:      	movz	x5, #0x0, lsl #48
    2f38:      	b	0x2c18 <_stogir.vector.validate+0x668>
    2f3c:      	add	x16, sp, #0x170
    2f40:      	ldr	x0, [x16, #0x8]
    2f44:      	add	x16, sp, #0x40
    2f48:      	ldr	w1, [x16, #0x4]
    2f4c:      	sxtw	x1, w1
    2f50:      	cmp	x1, #0x0
    2f54:      	b.gt	0x2f68 <_stogir.vector.validate+0x9b8>
    2f58:      	mov	x0, #0x1                ; =1
    2f5c:      	b	0x2bf0 <_stogir.vector.validate+0x640>
    2f60:      	movz	x5, #0x0, lsl #48
    2f64:      	b	0x2f30 <_stogir.vector.validate+0x980>
    2f68:      	uxtb	w0, w0
    2f6c:      	cmp	x0, #0x70
    2f70:      	b.eq	0x2bbc <_stogir.vector.validate+0x60c>
    2f74:      	cmp	x0, #0x71
    2f78:      	b.eq	0x2bbc <_stogir.vector.validate+0x60c>
    2f7c:      	mov	x0, #0x1                ; =1
    2f80:      	b	0x2bf0 <_stogir.vector.validate+0x640>
    2f84:      	brk	#0
    2f88:      	b	0x2f84 <_stogir.vector.validate+0x9d4>
    2f8c:      	brk	#0
    2f90:      	b	0x2f8c <_stogir.vector.validate+0x9dc>
    2f94:      	brk	#0
    2f98:      	b	0x2f94 <_stogir.vector.validate+0x9e4>
    2f9c:      	str	x20, [sp, #0x1a8]
    2fa0:      	str	w19, [sp, #0x1a0]
    2fa4:      	b	0x2754 <_stogir.vector.validate+0x1a4>
    2fa8:      	str	x20, [sp, #0x1a8]
    2fac:      	mov	w20, w0
    2fb0:      	str	w1, [sp, #0x1b0]
    2fb4:      	str	w2, [sp, #0x1b8]
    2fb8:      	str	w3, [sp, #0x1c0]
    2fbc:      	b	0x280c <_stogir.vector.validate+0x25c>
    2fc0:      	str	w19, [sp, #0x1c8]
    2fc4:      	b	0x2a28 <_stogir.vector.validate+0x478>
    2fc8:      	mov	x28, x25
    2fcc:      	b	0x2abc <_stogir.vector.validate+0x50c>

0000000000002fd0 <_stogir.copy.validate>:
    2fd0:      	sub	sp, sp, #0x10
    2fd4:      	sxtw	x1, w1
    2fd8:      	add	x2, x0, #0x78
    2fdc:      	add	x3, x0, #0x28
    2fe0:      	add	x4, x0, #0x50
    2fe4:      	lsl	x5, x1, #2
    2fe8:      	cmp	x1, #0x0
    2fec:      	cset	w6, gt
    2ff0:      	movz	x16, #0x0, lsl #48
    2ff4:      	sub	x7, x16, x1
    2ff8:      	sub	x9, x7, #0x1
    2ffc:      	uxtb	w16, w6
    3000:      	cmp	w16, wzr
    3004:      	b.eq	0x3040 <_stogir.copy.validate+0x70>
    3008:      	ldr	x7, [x0, #0x8]
    300c:      	cmp	x1, x7
    3010:      	b.ge	0x309c <_stogir.copy.validate+0xcc>
    3014:      	ldr	x7, [x2, #0x8]
    3018:      	cmp	x1, x7
    301c:      	b.ge	0x322c <_stogir.copy.validate+0x25c>
    3020:      	ldr	x7, [x0, #0x78]
    3024:      	add	x7, x5, x7
    3028:      	ldr	w7, [x7]
    302c:      	sxtw	x7, w7
    3030:      	cmp	x7, #0x0
    3034:      	cset	w7, ge
    3038:      	ubfx	x7, x7, #0, #8
    303c:      	b	0x3230 <_stogir.copy.validate+0x260>
    3040:      	cmp	x1, #0x0
    3044:      	b.ge	0x30a4 <_stogir.copy.validate+0xd4>
    3048:      	ldr	x10, [x3, #0x8]
    304c:      	ldr	x11, [x4, #0x8]
    3050:      	cmp	x10, x11
    3054:      	b.ne	0x3080 <_stogir.copy.validate+0xb0>
    3058:      	cmp	x7, x10
    305c:      	b.gt	0x3234 <_stogir.copy.validate+0x264>
    3060:      	ldr	x7, [x0, #0x50]
    3064:      	add	x7, x7, x9, lsl #2
    3068:      	ldr	w7, [x7]
    306c:      	sxtw	x7, w7
    3070:      	cmp	x7, #0x0
    3074:      	cset	w7, gt
    3078:      	ubfx	x7, x7, #0, #8
    307c:      	b	0x3238 <_stogir.copy.validate+0x268>
    3080:      	movz	x7, #0x0, lsl #48
    3084:      	b	0x30a8 <_stogir.copy.validate+0xd8>
    3088:      	mov	x1, #0x1                ; =1
    308c:      	adrp	x0, 0x3000 <_stogir.copy.validate+0x30>
		000000000000308c:  ARM64_RELOC_PAGE21	l_stogir.359
    3090:      	ldr	x0, [x0]
		0000000000003090:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    3094:      	mov	x2, #0x21               ; =33
    3098:      	b	0x3134 <_stogir.copy.validate+0x164>
    309c:      	movz	x7, #0x0, lsl #48
    30a0:      	b	0x30a8 <_stogir.copy.validate+0xd8>
    30a4:      	movz	x7, #0x0, lsl #48
    30a8:      	cmp	x7, #0x0
    30ac:      	b.eq	0x30e8 <_stogir.copy.validate+0x118>
    30b0:      	uxtb	w16, w6
    30b4:      	cmp	w16, wzr
    30b8:      	b.eq	0x30d0 <_stogir.copy.validate+0x100>
    30bc:      	ldr	x6, [x0]
    30c0:      	add	x6, x6, x1, lsl #4
    30c4:      	ldr	x7, [x6]
    30c8:      	ldr	x6, [x6, #0x8]
    30cc:      	b	0x30e0 <_stogir.copy.validate+0x110>
    30d0:      	ldr	x6, [x0, #0x28]
    30d4:      	add	x6, x6, x9, lsl #4
    30d8:      	ldr	x7, [x6]
    30dc:      	ldr	x6, [x6, #0x8]
    30e0:      	mov	w9, #0x1                ; =1
    30e4:      	b	0x30f4 <_stogir.copy.validate+0x124>
    30e8:      	movz	w9, #0x0, lsl #16
    30ec:      	movz	x7, #0x0, lsl #48
    30f0:      	movz	x6, #0x0, lsl #48
    30f4:      	ubfx	x9, x9, #0, #32
    30f8:      	lsr	x16, x9, #0
    30fc:      	cmp	x16, #0x1
    3100:      	b.eq	0x311c <_stogir.copy.validate+0x14c>
    3104:      	b.lo	0x310c <_stogir.copy.validate+0x13c>
    3108:      	b	0x3120 <_stogir.copy.validate+0x150>
    310c:      	cmp	x16, #0x0
    3110:      	b.eq	0x3118 <_stogir.copy.validate+0x148>
    3114:      	b	0x3120 <_stogir.copy.validate+0x150>
    3118:      	b	0x3124 <_stogir.copy.validate+0x154>
    311c:      	b	0x3148 <_stogir.copy.validate+0x178>
    3120:      	b	0x323c <_stogir.copy.validate+0x26c>
    3124:      	mov	x1, #0x1                ; =1
    3128:      	adrp	x0, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003128:  ARM64_RELOC_PAGE21	l_stogir.360
    312c:      	ldr	x0, [x0]
		000000000000312c:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    3130:      	mov	x2, #0x18               ; =24
    3134:      	str	x1, [x8]
    3138:      	str	x0, [x8, #0x8]
    313c:      	str	x2, [x8, #0x10]
    3140:      	add	sp, sp, #0x10
    3144:      	ret
    3148:      	mov	x16, sp
    314c:      	str	x7, [x16]
    3150:      	mov	x16, sp
    3154:      	str	x6, [x16, #0x8]
    3158:      	cmp	x1, #0x0
    315c:      	b.le	0x3088 <_stogir.copy.validate+0xb8>
    3160:      	uxtb	w1, w7
    3164:      	cmp	x1, #0x44
    3168:      	b.ne	0x3088 <_stogir.copy.validate+0xb8>
    316c:      	ldr	x1, [x0, #0x78]
    3170:      	add	x1, x5, x1
    3174:      	ldr	w1, [x1]
    3178:      	sxtw	x1, w1
    317c:      	cmp	x1, #0x2
    3180:      	b.ne	0x3088 <_stogir.copy.validate+0xb8>
    3184:      	ubfx	x7, x7, #0, #32
    3188:      	ubfx	x1, x7, #8, #8
    318c:      	orr	x5, x1, xzr
    3190:      	cmp	x5, #0x0
    3194:      	b.eq	0x3088 <_stogir.copy.validate+0xb8>
    3198:      	cmp	x5, #0xd
    319c:      	b.le	0x31c8 <_stogir.copy.validate+0x1f8>
    31a0:      	cmp	x5, #0xf
    31a4:      	b.le	0x3088 <_stogir.copy.validate+0xb8>
    31a8:      	cmp	x5, #0x80
    31ac:      	b.ge	0x3088 <_stogir.copy.validate+0xb8>
    31b0:      	and	w1, w1, #0xf
    31b4:      	ubfx	x1, x1, #0, #32
    31b8:      	cmp	x1, #0x1
    31bc:      	b.lt	0x3088 <_stogir.copy.validate+0xb8>
    31c0:      	cmp	x1, #0xd
    31c4:      	b.gt	0x3088 <_stogir.copy.validate+0xb8>
    31c8:      	mov	x16, sp
    31cc:      	ldr	w1, [x16, #0x4]
    31d0:      	sxtw	x1, w1
    31d4:      	cmp	x1, #0x0
    31d8:      	cset	w6, gt
    31dc:      	movz	x16, #0x0, lsl #48
    31e0:      	sub	x7, x16, x1
    31e4:      	sub	x9, x7, #0x1
    31e8:      	uxtb	w16, w6
    31ec:      	cmp	w16, wzr
    31f0:      	b.eq	0x3258 <_stogir.copy.validate+0x288>
    31f4:      	ldr	x3, [x0, #0x8]
    31f8:      	cmp	x1, x3
    31fc:      	b.ge	0x3298 <_stogir.copy.validate+0x2c8>
    3200:      	ldr	x2, [x2, #0x8]
    3204:      	cmp	x1, x2
    3208:      	b.ge	0x335c <_stogir.copy.validate+0x38c>
    320c:      	ldr	x2, [x0, #0x78]
    3210:      	add	x2, x2, x1, lsl #2
    3214:      	ldr	w2, [x2]
    3218:      	sxtw	x2, w2
    321c:      	cmp	x2, #0x0
    3220:      	cset	w2, ge
    3224:      	ubfx	x2, x2, #0, #8
    3228:      	b	0x3360 <_stogir.copy.validate+0x390>
    322c:      	movz	x7, #0x0, lsl #48
    3230:      	b	0x30a0 <_stogir.copy.validate+0xd0>
    3234:      	movz	x7, #0x0, lsl #48
    3238:      	b	0x3084 <_stogir.copy.validate+0xb4>
    323c:      	brk	#0
    3240:      	b	0x323c <_stogir.copy.validate+0x26c>
    3244:      	mov	x1, #0x1                ; =1
    3248:      	adrp	x0, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003248:  ARM64_RELOC_PAGE21	l_stogir.361
    324c:      	ldr	x0, [x0]
		000000000000324c:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    3250:      	mov	x2, #0x20               ; =32
    3254:      	b	0x3098 <_stogir.copy.validate+0xc8>
    3258:      	cmp	x1, #0x0
    325c:      	b.ge	0x32a0 <_stogir.copy.validate+0x2d0>
    3260:      	ldr	x2, [x3, #0x8]
    3264:      	ldr	x3, [x4, #0x8]
    3268:      	cmp	x2, x3
    326c:      	b.ne	0x3354 <_stogir.copy.validate+0x384>
    3270:      	cmp	x7, x2
    3274:      	b.gt	0x3364 <_stogir.copy.validate+0x394>
    3278:      	ldr	x2, [x0, #0x50]
    327c:      	add	x2, x2, x9, lsl #2
    3280:      	ldr	w2, [x2]
    3284:      	sxtw	x2, w2
    3288:      	cmp	x2, #0x0
    328c:      	cset	w2, gt
    3290:      	ubfx	x2, x2, #0, #8
    3294:      	b	0x3368 <_stogir.copy.validate+0x398>
    3298:      	movz	x2, #0x0, lsl #48
    329c:      	b	0x32a4 <_stogir.copy.validate+0x2d4>
    32a0:      	movz	x2, #0x0, lsl #48
    32a4:      	cmp	x2, #0x0
    32a8:      	b.eq	0x32dc <_stogir.copy.validate+0x30c>
    32ac:      	uxtb	w16, w6
    32b0:      	cmp	w16, wzr
    32b4:      	b.eq	0x32c8 <_stogir.copy.validate+0x2f8>
    32b8:      	ldr	x0, [x0]
    32bc:      	add	x0, x0, x1, lsl #4
    32c0:      	ldr	x0, [x0]
    32c4:      	b	0x32d4 <_stogir.copy.validate+0x304>
    32c8:      	ldr	x0, [x0, #0x28]
    32cc:      	add	x0, x0, x9, lsl #4
    32d0:      	ldr	x0, [x0]
    32d4:      	mov	w1, #0x1                ; =1
    32d8:      	b	0x32e4 <_stogir.copy.validate+0x314>
    32dc:      	movz	w1, #0x0, lsl #16
    32e0:      	movz	x0, #0x0, lsl #48
    32e4:      	ubfx	x1, x1, #0, #32
    32e8:      	lsr	x16, x1, #0
    32ec:      	cmp	x16, #0x1
    32f0:      	b.eq	0x330c <_stogir.copy.validate+0x33c>
    32f4:      	b.lo	0x32fc <_stogir.copy.validate+0x32c>
    32f8:      	b	0x3310 <_stogir.copy.validate+0x340>
    32fc:      	cmp	x16, #0x0
    3300:      	b.eq	0x3308 <_stogir.copy.validate+0x338>
    3304:      	b	0x3310 <_stogir.copy.validate+0x340>
    3308:      	b	0x3314 <_stogir.copy.validate+0x344>
    330c:      	b	0x3328 <_stogir.copy.validate+0x358>
    3310:      	b	0x336c <_stogir.copy.validate+0x39c>
    3314:      	mov	x1, #0x1                ; =1
    3318:      	adrp	x0, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003318:  ARM64_RELOC_PAGE21	l_stogir.362
    331c:      	ldr	x0, [x0]
		000000000000331c:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    3320:      	mov	x2, #0x13               ; =19
    3324:      	b	0x3254 <_stogir.copy.validate+0x284>
    3328:      	mov	x16, sp
    332c:      	ldr	w1, [x16]
    3330:      	ubfx	x0, x0, #0, #32
    3334:      	ubfx	x0, x0, #8, #8
    3338:      	ubfx	x1, x1, #8, #8
    333c:      	cmp	x0, x1
    3340:      	b.ne	0x3244 <_stogir.copy.validate+0x274>
    3344:      	and	x0, x5, #0xffffffff
    3348:      	movz	x1, #0x0, lsl #48
    334c:      	movz	x2, #0x0, lsl #48
    3350:      	b	0x3254 <_stogir.copy.validate+0x284>
    3354:      	movz	x2, #0x0, lsl #48
    3358:      	b	0x32a4 <_stogir.copy.validate+0x2d4>
    335c:      	movz	x2, #0x0, lsl #48
    3360:      	b	0x329c <_stogir.copy.validate+0x2cc>
    3364:      	movz	x2, #0x0, lsl #48
    3368:      	b	0x3358 <_stogir.copy.validate+0x388>
    336c:      	brk	#0
    3370:      	b	0x336c <_stogir.copy.validate+0x39c>

0000000000003374 <_stogir.graph.lookup>:
    3374:      	sxtw	x1, w1
    3378:      	add	x2, x0, #0x28
    337c:      	cmp	x1, #0x0
    3380:      	cset	w3, gt
    3384:      	movz	x16, #0x0, lsl #48
    3388:      	sub	x4, x16, x1
    338c:      	sub	x5, x4, #0x1
    3390:      	uxtb	w16, w3
    3394:      	cmp	w16, wzr
    3398:      	b.eq	0x33d8 <_stogir.graph.lookup+0x64>
    339c:      	ldr	x2, [x0, #0x8]
    33a0:      	cmp	x1, x2
    33a4:      	b.ge	0x3424 <_stogir.graph.lookup+0xb0>
    33a8:      	add	x2, x0, #0x78
    33ac:      	ldr	x2, [x2, #0x8]
    33b0:      	cmp	x1, x2
    33b4:      	b.ge	0x349c <_stogir.graph.lookup+0x128>
    33b8:      	ldr	x2, [x0, #0x78]
    33bc:      	add	x2, x2, x1, lsl #2
    33c0:      	ldr	w2, [x2]
    33c4:      	sxtw	x2, w2
    33c8:      	cmp	x2, #0x0
    33cc:      	cset	w2, ge
    33d0:      	ubfx	x2, x2, #0, #8
    33d4:      	b	0x34a0 <_stogir.graph.lookup+0x12c>
    33d8:      	cmp	x1, #0x0
    33dc:      	b.ge	0x342c <_stogir.graph.lookup+0xb8>
    33e0:      	add	x6, x0, #0x50
    33e4:      	ldr	x2, [x2, #0x8]
    33e8:      	ldr	x6, [x6, #0x8]
    33ec:      	cmp	x2, x6
    33f0:      	b.ne	0x341c <_stogir.graph.lookup+0xa8>
    33f4:      	cmp	x4, x2
    33f8:      	b.gt	0x34a4 <_stogir.graph.lookup+0x130>
    33fc:      	ldr	x2, [x0, #0x50]
    3400:      	add	x2, x2, x5, lsl #2
    3404:      	ldr	w2, [x2]
    3408:      	sxtw	x2, w2
    340c:      	cmp	x2, #0x0
    3410:      	cset	w2, gt
    3414:      	ubfx	x2, x2, #0, #8
    3418:      	b	0x34a8 <_stogir.graph.lookup+0x134>
    341c:      	movz	x2, #0x0, lsl #48
    3420:      	b	0x3430 <_stogir.graph.lookup+0xbc>
    3424:      	movz	x2, #0x0, lsl #48
    3428:      	b	0x3430 <_stogir.graph.lookup+0xbc>
    342c:      	movz	x2, #0x0, lsl #48
    3430:      	cmp	x2, #0x0
    3434:      	b.eq	0x3470 <_stogir.graph.lookup+0xfc>
    3438:      	uxtb	w16, w3
    343c:      	cmp	w16, wzr
    3440:      	b.eq	0x3458 <_stogir.graph.lookup+0xe4>
    3444:      	ldr	x0, [x0]
    3448:      	add	x0, x0, x1, lsl #4
    344c:      	ldr	x1, [x0]
    3450:      	ldr	x0, [x0, #0x8]
    3454:      	b	0x3468 <_stogir.graph.lookup+0xf4>
    3458:      	ldr	x0, [x0, #0x28]
    345c:      	add	x0, x0, x5, lsl #4
    3460:      	ldr	x1, [x0]
    3464:      	ldr	x0, [x0, #0x8]
    3468:      	mov	x2, #0x1                ; =1
    346c:      	b	0x347c <_stogir.graph.lookup+0x108>
    3470:      	movz	x2, #0x0, lsl #48
    3474:      	movz	x1, #0x0, lsl #48
    3478:      	movz	x0, #0x0, lsl #48
    347c:      	str	x2, [x8]
    3480:      	str	x1, [x8, #0x8]
    3484:      	str	x0, [x8, #0x10]
    3488:      	movz	x17, #0x0, lsl #48
    348c:      	str	x17, [x8, #0x18]
    3490:      	movz	x17, #0x0, lsl #48
    3494:      	str	x17, [x8, #0x20]
    3498:      	ret
    349c:      	movz	x2, #0x0, lsl #48
    34a0:      	b	0x3428 <_stogir.graph.lookup+0xb4>
    34a4:      	movz	x2, #0x0, lsl #48
    34a8:      	b	0x3420 <_stogir.graph.lookup+0xac>

00000000000034ac <_stogir.checked.validate-projection>:
    34ac:      	sub	sp, sp, #0x40
    34b0:      	str	x29, [sp]
    34b4:      	str	x30, [sp, #0x8]
    34b8:      	mov	x29, sp
    34bc:      	str	x19, [sp, #0x30]
    34c0:      	sxtw	x1, w1
    34c4:      	add	x2, x0, #0x78
    34c8:      	add	x3, x0, #0x28
    34cc:      	lsl	x4, x1, #2
    34d0:      	cmp	x1, #0x0
    34d4:      	cset	w5, gt
    34d8:      	movz	x16, #0x0, lsl #48
    34dc:      	sub	x6, x16, x1
    34e0:      	sub	x7, x6, #0x1
    34e4:      	uxtb	w16, w5
    34e8:      	cmp	w16, wzr
    34ec:      	b.eq	0x3528 <_stogir.checked.validate-projection+0x7c>
    34f0:      	ldr	x3, [x0, #0x8]
    34f4:      	cmp	x1, x3
    34f8:      	b.ge	0x3574 <_stogir.checked.validate-projection+0xc8>
    34fc:      	ldr	x2, [x2, #0x8]
    3500:      	cmp	x1, x2
    3504:      	b.ge	0x3644 <_stogir.checked.validate-projection+0x198>
    3508:      	ldr	x2, [x0, #0x78]
    350c:      	add	x2, x4, x2
    3510:      	ldr	w2, [x2]
    3514:      	sxtw	x2, w2
    3518:      	cmp	x2, #0x0
    351c:      	cset	w2, ge
    3520:      	ubfx	x2, x2, #0, #8
    3524:      	b	0x3648 <_stogir.checked.validate-projection+0x19c>
    3528:      	cmp	x1, #0x0
    352c:      	b.ge	0x357c <_stogir.checked.validate-projection+0xd0>
    3530:      	add	x2, x0, #0x50
    3534:      	ldr	x3, [x3, #0x8]
    3538:      	ldr	x2, [x2, #0x8]
    353c:      	cmp	x3, x2
    3540:      	b.ne	0x356c <_stogir.checked.validate-projection+0xc0>
    3544:      	cmp	x6, x3
    3548:      	b.gt	0x36b0 <_stogir.checked.validate-projection+0x204>
    354c:      	ldr	x2, [x0, #0x50]
    3550:      	add	x2, x2, x7, lsl #2
    3554:      	ldr	w2, [x2]
    3558:      	sxtw	x2, w2
    355c:      	cmp	x2, #0x0
    3560:      	cset	w2, gt
    3564:      	ubfx	x2, x2, #0, #8
    3568:      	b	0x36b4 <_stogir.checked.validate-projection+0x208>
    356c:      	movz	x2, #0x0, lsl #48
    3570:      	b	0x3580 <_stogir.checked.validate-projection+0xd4>
    3574:      	movz	x2, #0x0, lsl #48
    3578:      	b	0x3580 <_stogir.checked.validate-projection+0xd4>
    357c:      	movz	x2, #0x0, lsl #48
    3580:      	cmp	x2, #0x0
    3584:      	b.eq	0x35b8 <_stogir.checked.validate-projection+0x10c>
    3588:      	uxtb	w16, w5
    358c:      	cmp	w16, wzr
    3590:      	b.eq	0x35a4 <_stogir.checked.validate-projection+0xf8>
    3594:      	ldr	x2, [x0]
    3598:      	add	x2, x2, x1, lsl #4
    359c:      	ldr	x2, [x2]
    35a0:      	b	0x35b0 <_stogir.checked.validate-projection+0x104>
    35a4:      	ldr	x2, [x0, #0x28]
    35a8:      	add	x2, x2, x7, lsl #4
    35ac:      	ldr	x2, [x2]
    35b0:      	mov	w3, #0x1                ; =1
    35b4:      	b	0x35c0 <_stogir.checked.validate-projection+0x114>
    35b8:      	movz	w3, #0x0, lsl #16
    35bc:      	movz	x2, #0x0, lsl #48
    35c0:      	ubfx	x3, x3, #0, #32
    35c4:      	lsr	x16, x3, #0
    35c8:      	cmp	x16, #0x1
    35cc:      	b.eq	0x35e8 <_stogir.checked.validate-projection+0x13c>
    35d0:      	b.lo	0x35d8 <_stogir.checked.validate-projection+0x12c>
    35d4:      	b	0x35ec <_stogir.checked.validate-projection+0x140>
    35d8:      	cmp	x16, #0x0
    35dc:      	b.eq	0x35e4 <_stogir.checked.validate-projection+0x138>
    35e0:      	b	0x35ec <_stogir.checked.validate-projection+0x140>
    35e4:      	b	0x35f0 <_stogir.checked.validate-projection+0x144>
    35e8:      	b	0x3608 <_stogir.checked.validate-projection+0x15c>
    35ec:      	b	0x36b8 <_stogir.checked.validate-projection+0x20c>
    35f0:      	mov	x19, x8
    35f4:      	mov	x0, #0x1                ; =1
    35f8:      	adrp	x1, 0x3000 <_stogir.copy.validate+0x30>
		00000000000035f8:  ARM64_RELOC_PAGE21	l_stogir.363
    35fc:      	ldr	x1, [x1]
		00000000000035fc:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    3600:      	mov	x2, #0x10               ; =16
    3604:      	b	0x3624 <_stogir.checked.validate-projection+0x178>
    3608:      	cmp	x1, #0x0
    360c:      	b.gt	0x364c <_stogir.checked.validate-projection+0x1a0>
    3610:      	mov	x19, x8
    3614:      	mov	x0, #0x1                ; =1
    3618:      	adrp	x1, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003618:  ARM64_RELOC_PAGE21	l_stogir.364
    361c:      	ldr	x1, [x1]
		000000000000361c:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    3620:      	mov	x2, #0x1c               ; =28
    3624:      	str	x0, [x19]
    3628:      	str	x1, [x19, #0x8]
    362c:      	str	x2, [x19, #0x10]
    3630:      	ldr	x19, [sp, #0x30]
    3634:      	ldr	x29, [sp]
    3638:      	ldr	x30, [sp, #0x8]
    363c:      	add	sp, sp, #0x40
    3640:      	ret
    3644:      	movz	x2, #0x0, lsl #48
    3648:      	b	0x3578 <_stogir.checked.validate-projection+0xcc>
    364c:      	uxtb	w1, w2
    3650:      	cmp	x1, #0x2c
    3654:      	b.ne	0x36c0 <_stogir.checked.validate-projection+0x214>
    3658:      	orr	w1, w2, wzr
    365c:      	ubfx	x1, x1, #0, #32
    3660:      	ubfx	x1, x1, #8, #8
    3664:      	cmp	x1, #0x1
    3668:      	b.ne	0x36c8 <_stogir.checked.validate-projection+0x21c>
    366c:      	ldr	x1, [x0, #0x78]
    3670:      	add	x1, x4, x1
    3674:      	ldr	w1, [x1]
    3678:      	sxtw	x1, w1
    367c:      	cmp	x1, #0x1
    3680:      	b.ne	0x36d0 <_stogir.checked.validate-projection+0x224>
    3684:      	lsr	x1, x2, #32
    3688:      	mov	x19, x8
    368c:      	add	x8, sp, #0x10
    3690:      	bl	0x3690 <_stogir.checked.validate-projection+0x1e4>
		0000000000003690:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    3694:      	add	x16, sp, #0x10
    3698:      	ldr	x0, [x16]
    369c:      	add	x16, sp, #0x10
    36a0:      	ldr	x1, [x16, #0x8]
    36a4:      	add	x16, sp, #0x10
    36a8:      	ldr	x2, [x16, #0x10]
    36ac:      	b	0x3624 <_stogir.checked.validate-projection+0x178>
    36b0:      	movz	x2, #0x0, lsl #48
    36b4:      	b	0x3570 <_stogir.checked.validate-projection+0xc4>
    36b8:      	brk	#0
    36bc:      	b	0x36b8 <_stogir.checked.validate-projection+0x20c>
    36c0:      	mov	x19, x8
    36c4:      	b	0x3614 <_stogir.checked.validate-projection+0x168>
    36c8:      	mov	x19, x8
    36cc:      	b	0x3614 <_stogir.checked.validate-projection+0x168>
    36d0:      	mov	x19, x8
    36d4:      	b	0x3614 <_stogir.checked.validate-projection+0x168>

00000000000036d8 <_stogir.checked.validate>:
    36d8:      	sub	sp, sp, #0x20
    36dc:      	str	x29, [sp]
    36e0:      	str	x30, [sp, #0x8]
    36e4:      	mov	x29, sp
    36e8:      	str	x19, [sp, #0x10]
    36ec:      	sxtw	x1, w1
    36f0:      	add	x2, x0, #0x78
    36f4:      	add	x3, x0, #0x28
    36f8:      	add	x4, x0, #0x50
    36fc:      	lsl	x5, x1, #2
    3700:      	cmp	x1, #0x0
    3704:      	cset	w6, gt
    3708:      	movz	x16, #0x0, lsl #48
    370c:      	sub	x7, x16, x1
    3710:      	sub	x9, x7, #0x1
    3714:      	uxtb	w16, w6
    3718:      	cmp	w16, wzr
    371c:      	b.eq	0x3758 <_stogir.checked.validate+0x80>
    3720:      	ldr	x7, [x0, #0x8]
    3724:      	cmp	x1, x7
    3728:      	b.ge	0x37a0 <_stogir.checked.validate+0xc8>
    372c:      	ldr	x7, [x2, #0x8]
    3730:      	cmp	x1, x7
    3734:      	b.ge	0x38ec <_stogir.checked.validate+0x214>
    3738:      	ldr	x7, [x0, #0x78]
    373c:      	add	x7, x5, x7
    3740:      	ldr	w7, [x7]
    3744:      	sxtw	x7, w7
    3748:      	cmp	x7, #0x0
    374c:      	cset	w7, ge
    3750:      	ubfx	x7, x7, #0, #8
    3754:      	b	0x38f0 <_stogir.checked.validate+0x218>
    3758:      	cmp	x1, #0x0
    375c:      	b.ge	0x37a8 <_stogir.checked.validate+0xd0>
    3760:      	ldr	x10, [x3, #0x8]
    3764:      	ldr	x11, [x4, #0x8]
    3768:      	cmp	x10, x11
    376c:      	b.ne	0x3798 <_stogir.checked.validate+0xc0>
    3770:      	cmp	x7, x10
    3774:      	b.gt	0x38f4 <_stogir.checked.validate+0x21c>
    3778:      	ldr	x7, [x0, #0x50]
    377c:      	add	x7, x7, x9, lsl #2
    3780:      	ldr	w7, [x7]
    3784:      	sxtw	x7, w7
    3788:      	cmp	x7, #0x0
    378c:      	cset	w7, gt
    3790:      	ubfx	x7, x7, #0, #8
    3794:      	b	0x38f8 <_stogir.checked.validate+0x220>
    3798:      	movz	x7, #0x0, lsl #48
    379c:      	b	0x37ac <_stogir.checked.validate+0xd4>
    37a0:      	movz	x7, #0x0, lsl #48
    37a4:      	b	0x37ac <_stogir.checked.validate+0xd4>
    37a8:      	movz	x7, #0x0, lsl #48
    37ac:      	cmp	x7, #0x0
    37b0:      	b.eq	0x37ec <_stogir.checked.validate+0x114>
    37b4:      	uxtb	w16, w6
    37b8:      	cmp	w16, wzr
    37bc:      	b.eq	0x37d4 <_stogir.checked.validate+0xfc>
    37c0:      	ldr	x6, [x0]
    37c4:      	add	x6, x6, x1, lsl #4
    37c8:      	ldr	x7, [x6]
    37cc:      	ldr	x6, [x6, #0x8]
    37d0:      	b	0x37e4 <_stogir.checked.validate+0x10c>
    37d4:      	ldr	x6, [x0, #0x28]
    37d8:      	add	x6, x6, x9, lsl #4
    37dc:      	ldr	x7, [x6]
    37e0:      	ldr	x6, [x6, #0x8]
    37e4:      	mov	w9, #0x1                ; =1
    37e8:      	b	0x37f8 <_stogir.checked.validate+0x120>
    37ec:      	movz	w9, #0x0, lsl #16
    37f0:      	movz	x7, #0x0, lsl #48
    37f4:      	movz	x6, #0x0, lsl #48
    37f8:      	ubfx	x9, x9, #0, #32
    37fc:      	lsr	x16, x9, #0
    3800:      	cmp	x16, #0x1
    3804:      	b.eq	0x3820 <_stogir.checked.validate+0x148>
    3808:      	b.lo	0x3810 <_stogir.checked.validate+0x138>
    380c:      	b	0x3824 <_stogir.checked.validate+0x14c>
    3810:      	cmp	x16, #0x0
    3814:      	b.eq	0x381c <_stogir.checked.validate+0x144>
    3818:      	b	0x3824 <_stogir.checked.validate+0x14c>
    381c:      	b	0x3828 <_stogir.checked.validate+0x150>
    3820:      	b	0x3870 <_stogir.checked.validate+0x198>
    3824:      	b	0x3b00 <_stogir.checked.validate+0x428>
    3828:      	mov	x0, #0x1                ; =1
    382c:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x30>
		000000000000382c:  ARM64_RELOC_PAGE21	l_stogir.365
    3830:      	ldr	x11, [x11]
		0000000000003830:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    3834:      	mov	x12, #0x1a              ; =26
    3838:      	b	0x384c <_stogir.checked.validate+0x174>
    383c:      	mov	x0, #0x1                ; =1
    3840:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003840:  ARM64_RELOC_PAGE21	l_stogir.366
    3844:      	ldr	x11, [x11]
		0000000000003844:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    3848:      	mov	x12, #0x26              ; =38
    384c:      	str	x0, [x8]
    3850:      	str	x11, [x8, #0x8]
    3854:      	str	x12, [x8, #0x10]
    3858:      	sub	sp, x29, #0x0
    385c:      	ldr	x19, [sp, #0x10]
    3860:      	ldr	x29, [sp]
    3864:      	ldr	x30, [sp, #0x8]
    3868:      	add	sp, sp, #0x20
    386c:      	ret
    3870:      	cmp	x1, #0x0
    3874:      	b.le	0x383c <_stogir.checked.validate+0x164>
    3878:      	uxtb	w1, w7
    387c:      	cmp	x1, #0x29
    3880:      	b.lt	0x383c <_stogir.checked.validate+0x164>
    3884:      	cmp	x1, #0x2b
    3888:      	b.gt	0x383c <_stogir.checked.validate+0x164>
    388c:      	ldr	x1, [x0, #0x78]
    3890:      	add	x1, x5, x1
    3894:      	ldr	w1, [x1]
    3898:      	sxtw	x1, w1
    389c:      	cmp	x1, #0x2
    38a0:      	b.ne	0x383c <_stogir.checked.validate+0x164>
    38a4:      	orr	w1, w7, wzr
    38a8:      	mov	x5, sp
    38ac:      	ubfx	x1, x1, #0, #32
    38b0:      	sub	sp, sp, #0x10
    38b4:      	mov	x9, sp
    38b8:      	sub	sp, sp, #0x10
    38bc:      	mov	x10, sp
    38c0:      	ubfx	x1, x1, #8, #8
    38c4:      	cmp	x1, #0x1
    38c8:      	b.lt	0x3ac4 <_stogir.checked.validate+0x3ec>
    38cc:      	cmp	x1, #0xb
    38d0:      	b.gt	0x3ac4 <_stogir.checked.validate+0x3ec>
    38d4:      	cmp	x1, #0x1
    38d8:      	b.eq	0x3ac4 <_stogir.checked.validate+0x3ec>
    38dc:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x30>
		00000000000038dc:  ARM64_RELOC_PAGE21	l_stogir.367
    38e0:      	ldr	x11, [x11]
		00000000000038e0:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    38e4:      	movz	x12, #0x0, lsl #48
    38e8:      	b	0x3ad0 <_stogir.checked.validate+0x3f8>
    38ec:      	movz	x7, #0x0, lsl #48
    38f0:      	b	0x37a4 <_stogir.checked.validate+0xcc>
    38f4:      	movz	x7, #0x0, lsl #48
    38f8:      	b	0x379c <_stogir.checked.validate+0xc4>
    38fc:      	mov	x0, #0x1                ; =1
    3900:      	mov	sp, x5
    3904:      	b	0x384c <_stogir.checked.validate+0x174>
    3908:      	movz	w9, #0x0, lsl #16
    390c:      	movz	x7, #0x0, lsl #48
    3910:      	ubfx	x9, x9, #0, #32
    3914:      	lsr	x16, x9, #0
    3918:      	cmp	x16, #0x1
    391c:      	b.eq	0x3938 <_stogir.checked.validate+0x260>
    3920:      	b.lo	0x3928 <_stogir.checked.validate+0x250>
    3924:      	b	0x393c <_stogir.checked.validate+0x264>
    3928:      	cmp	x16, #0x0
    392c:      	b.eq	0x3934 <_stogir.checked.validate+0x25c>
    3930:      	b	0x393c <_stogir.checked.validate+0x264>
    3934:      	b	0x3940 <_stogir.checked.validate+0x268>
    3938:      	b	0x3aa4 <_stogir.checked.validate+0x3cc>
    393c:      	b	0x3b18 <_stogir.checked.validate+0x440>
    3940:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003940:  ARM64_RELOC_PAGE21	l_stogir.368
    3944:      	ldr	x11, [x11]
		0000000000003944:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    3948:      	mov	x12, #0x22              ; =34
    394c:      	cmp	x6, #0x2
    3950:      	b.ge	0x3974 <_stogir.checked.validate+0x29c>
    3954:      	add	x7, x6, #0x1
    3958:      	add	x6, x13, x6, lsl #2
    395c:      	ldr	w6, [x6]
    3960:      	movn	w17, #0x0, lsl #16
    3964:      	and	w9, w6, w17
    3968:      	mov	x6, x7
    396c:      	mov	w7, #0x1                ; =1
    3970:      	b	0x397c <_stogir.checked.validate+0x2a4>
    3974:      	movz	w7, #0x0, lsl #16
    3978:      	movz	w9, #0x0, lsl #16
    397c:      	ubfx	x7, x7, #0, #32
    3980:      	lsr	x16, x7, #0
    3984:      	cmp	x16, #0x1
    3988:      	b.eq	0x39a4 <_stogir.checked.validate+0x2cc>
    398c:      	b.lo	0x3994 <_stogir.checked.validate+0x2bc>
    3990:      	b	0x39a8 <_stogir.checked.validate+0x2d0>
    3994:      	cmp	x16, #0x0
    3998:      	b.eq	0x39a0 <_stogir.checked.validate+0x2c8>
    399c:      	b	0x39a8 <_stogir.checked.validate+0x2d0>
    39a0:      	b	0x3a08 <_stogir.checked.validate+0x330>
    39a4:      	b	0x39ac <_stogir.checked.validate+0x2d4>
    39a8:      	b	0x3b10 <_stogir.checked.validate+0x438>
    39ac:      	sxtw	x9, w9
    39b0:      	cmp	x9, #0x0
    39b4:      	cset	w7, gt
    39b8:      	movz	x16, #0x0, lsl #48
    39bc:      	sub	x10, x16, x9
    39c0:      	sub	x14, x10, #0x1
    39c4:      	uxtb	w16, w7
    39c8:      	cmp	w16, wzr
    39cc:      	b.eq	0x3a64 <_stogir.checked.validate+0x38c>
    39d0:      	ldr	x10, [x0, #0x8]
    39d4:      	cmp	x9, x10
    39d8:      	b.ge	0x3a5c <_stogir.checked.validate+0x384>
    39dc:      	ldr	x10, [x2, #0x8]
    39e0:      	cmp	x9, x10
    39e4:      	b.ge	0x3af8 <_stogir.checked.validate+0x420>
    39e8:      	ldr	x10, [x0, #0x78]
    39ec:      	add	x10, x10, x9, lsl #2
    39f0:      	ldr	w10, [x10]
    39f4:      	sxtw	x10, w10
    39f8:      	cmp	x10, #0x0
    39fc:      	cset	w10, ge
    3a00:      	ubfx	x10, x10, #0, #8
    3a04:      	b	0x3afc <_stogir.checked.validate+0x424>
    3a08:      	cmp	x12, #0x0
    3a0c:      	b.ne	0x38fc <_stogir.checked.validate+0x224>
    3a10:      	and	x11, x1, #0xffffffff
    3a14:      	movz	x0, #0x0, lsl #48
    3a18:      	movz	x12, #0x0, lsl #48
    3a1c:      	b	0x3900 <_stogir.checked.validate+0x228>
    3a20:      	ldr	x7, [x0, #0x28]
    3a24:      	add	x7, x7, x14, lsl #4
    3a28:      	ldr	x7, [x7]
    3a2c:      	mov	w9, #0x1                ; =1
    3a30:      	b	0x3910 <_stogir.checked.validate+0x238>
    3a34:      	movz	x10, #0x0, lsl #48
    3a38:      	cmp	x10, #0x0
    3a3c:      	b.eq	0x3908 <_stogir.checked.validate+0x230>
    3a40:      	uxtb	w16, w7
    3a44:      	cmp	w16, wzr
    3a48:      	b.eq	0x3a20 <_stogir.checked.validate+0x348>
    3a4c:      	ldr	x7, [x0]
    3a50:      	add	x7, x7, x9, lsl #4
    3a54:      	ldr	x7, [x7]
    3a58:      	b	0x3a2c <_stogir.checked.validate+0x354>
    3a5c:      	movz	x10, #0x0, lsl #48
    3a60:      	b	0x3a38 <_stogir.checked.validate+0x360>
    3a64:      	cmp	x9, #0x0
    3a68:      	b.ge	0x3a34 <_stogir.checked.validate+0x35c>
    3a6c:      	ldr	x15, [x3, #0x8]
    3a70:      	ldr	x19, [x4, #0x8]
    3a74:      	cmp	x15, x19
    3a78:      	b.ne	0x3af0 <_stogir.checked.validate+0x418>
    3a7c:      	cmp	x10, x15
    3a80:      	b.gt	0x3b08 <_stogir.checked.validate+0x430>
    3a84:      	ldr	x10, [x0, #0x50]
    3a88:      	add	x10, x10, x14, lsl #2
    3a8c:      	ldr	w10, [x10]
    3a90:      	sxtw	x10, w10
    3a94:      	cmp	x10, #0x0
    3a98:      	cset	w10, gt
    3a9c:      	ubfx	x10, x10, #0, #8
    3aa0:      	b	0x3b0c <_stogir.checked.validate+0x434>
    3aa4:      	ubfx	x7, x7, #0, #32
    3aa8:      	ubfx	x7, x7, #8, #8
    3aac:      	cmp	x7, x1
    3ab0:      	b.eq	0x3ac0 <_stogir.checked.validate+0x3e8>
    3ab4:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003ab4:  ARM64_RELOC_PAGE21	l_stogir.369
    3ab8:      	ldr	x11, [x11]
		0000000000003ab8:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    3abc:      	mov	x12, #0x28              ; =40
    3ac0:      	b	0x394c <_stogir.checked.validate+0x274>
    3ac4:      	adrp	x11, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003ac4:  ARM64_RELOC_PAGE21	l_stogir.370
    3ac8:      	ldr	x11, [x11]
		0000000000003ac8:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    3acc:      	mov	x12, #0x36              ; =54
    3ad0:      	orr	x13, x10, xzr
    3ad4:      	lsr	x7, x7, #32
    3ad8:      	str	w7, [x9]
    3adc:      	str	w6, [x9, #0x4]
    3ae0:      	ldr	x6, [x9]
    3ae4:      	str	x6, [x10]
    3ae8:      	movz	x6, #0x0, lsl #48
    3aec:      	b	0x394c <_stogir.checked.validate+0x274>
    3af0:      	movz	x10, #0x0, lsl #48
    3af4:      	b	0x3a38 <_stogir.checked.validate+0x360>
    3af8:      	movz	x10, #0x0, lsl #48
    3afc:      	b	0x3a60 <_stogir.checked.validate+0x388>
    3b00:      	brk	#0
    3b04:      	b	0x3b00 <_stogir.checked.validate+0x428>
    3b08:      	movz	x10, #0x0, lsl #48
    3b0c:      	b	0x3af4 <_stogir.checked.validate+0x41c>
    3b10:      	brk	#0
    3b14:      	b	0x3b10 <_stogir.checked.validate+0x438>
    3b18:      	brk	#0
    3b1c:      	b	0x3b18 <_stogir.checked.validate+0x440>

0000000000003b20 <_stogir.atomic.validate>:
    3b20:      	sub	sp, sp, #0x120
    3b24:      	str	x29, [sp, #0x10]
    3b28:      	str	x30, [sp, #0x18]
    3b2c:      	add	x29, sp, #0x10
    3b30:      	str	x19, [sp, #0xd0]
    3b34:      	str	x20, [sp, #0xd8]
    3b38:      	str	x21, [sp, #0xe0]
    3b3c:      	str	x22, [sp, #0xe8]
    3b40:      	str	x23, [sp, #0xf0]
    3b44:      	str	x24, [sp, #0xf8]
    3b48:      	str	x25, [sp, #0x100]
    3b4c:      	str	x26, [sp, #0x108]
    3b50:      	str	x27, [sp, #0x110]
    3b54:      	mov	x19, x8
    3b58:      	add	x8, sp, #0x20
    3b5c:      	mov	x20, x0
    3b60:      	mov	w21, w1
    3b64:      	bl	0x3b64 <_stogir.atomic.validate+0x44>
		0000000000003b64:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3b68:      	add	x16, sp, #0x20
    3b6c:      	ldr	w0, [x16]
    3b70:      	lsr	x16, x0, #0
    3b74:      	cmp	x16, #0x1
    3b78:      	b.eq	0x3b94 <_stogir.atomic.validate+0x74>
    3b7c:      	b.lo	0x3b84 <_stogir.atomic.validate+0x64>
    3b80:      	b	0x3b98 <_stogir.atomic.validate+0x78>
    3b84:      	cmp	x16, #0x0
    3b88:      	b.eq	0x3b90 <_stogir.atomic.validate+0x70>
    3b8c:      	b	0x3b98 <_stogir.atomic.validate+0x78>
    3b90:      	b	0x3b9c <_stogir.atomic.validate+0x7c>
    3b94:      	b	0x3bec <_stogir.atomic.validate+0xcc>
    3b98:      	b	0x4284 <_stogir.atomic.validate+0x764>
    3b9c:      	mov	x0, #0x1                ; =1
    3ba0:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003ba0:  ARM64_RELOC_PAGE21	l_stogir.371
    3ba4:      	ldr	x24, [x24]
		0000000000003ba4:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    3ba8:      	mov	x25, #0x1a              ; =26
    3bac:      	str	x0, [x19]
    3bb0:      	str	x24, [x19, #0x8]
    3bb4:      	str	x25, [x19, #0x10]
    3bb8:      	ldr	x19, [sp, #0xd0]
    3bbc:      	ldr	x20, [sp, #0xd8]
    3bc0:      	ldr	x21, [sp, #0xe0]
    3bc4:      	ldr	x22, [sp, #0xe8]
    3bc8:      	ldr	x23, [sp, #0xf0]
    3bcc:      	ldr	x24, [sp, #0xf8]
    3bd0:      	ldr	x25, [sp, #0x100]
    3bd4:      	ldr	x26, [sp, #0x108]
    3bd8:      	ldr	x27, [sp, #0x110]
    3bdc:      	ldr	x29, [sp, #0x10]
    3be0:      	ldr	x30, [sp, #0x18]
    3be4:      	add	sp, sp, #0x120
    3be8:      	ret
    3bec:      	sxtw	x0, w21
    3bf0:      	add	x16, sp, #0x20
    3bf4:      	orr	x1, x16, xzr
    3bf8:      	add	x1, x1, #0x8
    3bfc:      	add	x16, sp, #0x20
    3c00:      	ldr	x22, [x16, #0x8]
    3c04:      	add	x16, sp, #0x50
    3c08:      	str	x22, [x16]
    3c0c:      	uxtb	w2, w22
    3c10:      	ldr	x1, [x1, #0x8]
    3c14:      	orr	x23, x2, xzr
    3c18:      	add	x16, sp, #0x50
    3c1c:      	str	x1, [x16, #0x8]
    3c20:      	cmp	x0, #0x0
    3c24:      	b.le	0x3c64 <_stogir.atomic.validate+0x144>
    3c28:      	cmp	x23, #0x7e
    3c2c:      	b.lt	0x3c64 <_stogir.atomic.validate+0x144>
    3c30:      	cmp	x23, #0x82
    3c34:      	b.gt	0x3c64 <_stogir.atomic.validate+0x144>
    3c38:      	ldr	x1, [x20, #0x78]
    3c3c:      	add	x0, x1, x0, lsl #2
    3c40:      	ldr	w0, [x0]
    3c44:      	cmp	x23, #0x83
    3c48:      	b.ge	0x4140 <_stogir.atomic.validate+0x620>
    3c4c:      	adrp	x17, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003c4c:  ARM64_RELOC_PAGE21	l_stogir.372
    3c50:      	ldr	x17, [x17]
		0000000000003c50:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    3c54:      	add	x1, x23, x17
    3c58:      	ldrsb	w1, [x1]
    3c5c:      	sxtb	w1, w1
    3c60:      	b	0x4144 <_stogir.atomic.validate+0x624>
    3c64:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003c64:  ARM64_RELOC_PAGE21	l_stogir.373
    3c68:      	ldr	x24, [x24]
		0000000000003c68:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    3c6c:      	mov	x25, #0x20              ; =32
    3c70:      	add	x16, sp, #0x50
    3c74:      	ldr	w0, [x16, #0x4]
    3c78:      	add	x8, sp, #0x60
    3c7c:      	mov	w1, w0
    3c80:      	mov	x0, x20
    3c84:      	bl	0x3c84 <_stogir.atomic.validate+0x164>
		0000000000003c84:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3c88:      	add	x16, sp, #0x60
    3c8c:      	ldr	w0, [x16]
    3c90:      	lsr	x16, x0, #0
    3c94:      	cmp	x16, #0x1
    3c98:      	b.eq	0x3cb4 <_stogir.atomic.validate+0x194>
    3c9c:      	b.lo	0x3ca4 <_stogir.atomic.validate+0x184>
    3ca0:      	b	0x3cb8 <_stogir.atomic.validate+0x198>
    3ca4:      	cmp	x16, #0x0
    3ca8:      	b.eq	0x3cb0 <_stogir.atomic.validate+0x190>
    3cac:      	b	0x3cb8 <_stogir.atomic.validate+0x198>
    3cb0:      	b	0x3cbc <_stogir.atomic.validate+0x19c>
    3cb4:      	b	0x3db8 <_stogir.atomic.validate+0x298>
    3cb8:      	b	0x428c <_stogir.atomic.validate+0x76c>
    3cbc:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003cbc:  ARM64_RELOC_PAGE21	l_stogir.374
    3cc0:      	ldr	x24, [x24]
		0000000000003cc0:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    3cc4:      	mov	x25, #0x16              ; =22
    3cc8:      	b	0x3cec <_stogir.atomic.validate+0x1cc>
    3ccc:      	mov	x0, #0x1                ; =1
    3cd0:      	b	0x3bac <_stogir.atomic.validate+0x8c>
    3cd4:      	mov	x0, #0x1                ; =1
    3cd8:      	cmp	x0, #0x0
    3cdc:      	b.eq	0x3cec <_stogir.atomic.validate+0x1cc>
    3ce0:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003ce0:  ARM64_RELOC_PAGE21	l_stogir.375
    3ce4:      	ldr	x24, [x24]
		0000000000003ce4:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    3ce8:      	mov	x25, #0x16              ; =22
    3cec:      	cmp	x23, #0x82
    3cf0:      	cset	w26, eq
    3cf4:      	ubfx	x22, x22, #0, #32
    3cf8:      	ubfx	x0, x22, #8, #8
    3cfc:      	orr	x22, x0, xzr
    3d00:      	cmp	x22, #0x0
    3d04:      	cset	w0, eq
    3d08:      	uxtb	w16, w26
    3d0c:      	cmp	w16, wzr
    3d10:      	b.eq	0x3d2c <_stogir.atomic.validate+0x20c>
    3d14:      	uxtb	w16, w0
    3d18:      	cmp	w16, wzr
    3d1c:      	b.ne	0x3d2c <_stogir.atomic.validate+0x20c>
    3d20:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003d20:  ARM64_RELOC_PAGE21	l_stogir.376
    3d24:      	ldr	x24, [x24]
		0000000000003d24:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    3d28:      	mov	x25, #0x19              ; =25
    3d2c:      	uxtb	w16, w26
    3d30:      	cmp	w16, wzr
    3d34:      	b.eq	0x3d40 <_stogir.atomic.validate+0x220>
    3d38:      	movz	x1, #0x0, lsl #48
    3d3c:      	b	0x3d44 <_stogir.atomic.validate+0x224>
    3d40:      	mov	x1, #0x1                ; =1
    3d44:      	cmp	x1, #0x0
    3d48:      	b.eq	0x3df4 <_stogir.atomic.validate+0x2d4>
    3d4c:      	add	x1, x20, #0x28
    3d50:      	add	x16, sp, #0x50
    3d54:      	ldr	w2, [x16, #0x8]
    3d58:      	sxtw	x2, w2
    3d5c:      	cmp	x2, #0x0
    3d60:      	cset	w3, gt
    3d64:      	movz	x16, #0x0, lsl #48
    3d68:      	sub	x4, x16, x2
    3d6c:      	sub	x5, x4, #0x1
    3d70:      	uxtb	w16, w3
    3d74:      	cmp	w16, wzr
    3d78:      	b.eq	0x3ec8 <_stogir.atomic.validate+0x3a8>
    3d7c:      	ldr	x1, [x20, #0x8]
    3d80:      	cmp	x2, x1
    3d84:      	b.ge	0x3fb8 <_stogir.atomic.validate+0x498>
    3d88:      	add	x1, x20, #0x78
    3d8c:      	ldr	x1, [x1, #0x8]
    3d90:      	cmp	x2, x1
    3d94:      	b.ge	0x40d0 <_stogir.atomic.validate+0x5b0>
    3d98:      	ldr	x1, [x20, #0x78]
    3d9c:      	add	x1, x1, x2, lsl #2
    3da0:      	ldr	w1, [x1]
    3da4:      	sxtw	x1, w1
    3da8:      	cmp	x1, #0x0
    3dac:      	cset	w1, ge
    3db0:      	ubfx	x1, x1, #0, #8
    3db4:      	b	0x40d4 <_stogir.atomic.validate+0x5b4>
    3db8:      	add	x16, sp, #0x60
    3dbc:      	ldr	x0, [x16, #0x8]
    3dc0:      	add	x16, sp, #0x50
    3dc4:      	ldr	w1, [x16, #0x4]
    3dc8:      	sxtw	x1, w1
    3dcc:      	cmp	x1, #0x0
    3dd0:      	b.gt	0x3f0c <_stogir.atomic.validate+0x3ec>
    3dd4:      	mov	x0, #0x1                ; =1
    3dd8:      	b	0x3cd8 <_stogir.atomic.validate+0x1b8>
    3ddc:      	movz	x0, #0x0, lsl #48
    3de0:      	cmp	x0, #0x0
    3de4:      	b.eq	0x3df4 <_stogir.atomic.validate+0x2d4>
    3de8:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003de8:  ARM64_RELOC_PAGE21	l_stogir.377
    3dec:      	ldr	x24, [x24]
		0000000000003dec:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    3df0:      	mov	x25, #0x22              ; =34
    3df4:      	cmp	x23, #0x80
    3df8:      	cset	w27, eq
    3dfc:      	uxtb	w16, w27
    3e00:      	cmp	w16, wzr
    3e04:      	b.eq	0x3e10 <_stogir.atomic.validate+0x2f0>
    3e08:      	mov	x0, #0x1                ; =1
    3e0c:      	b	0x3e1c <_stogir.atomic.validate+0x2fc>
    3e10:      	cmp	x23, #0x81
    3e14:      	cset	w0, eq
    3e18:      	ubfx	x0, x0, #0, #8
    3e1c:      	cmp	x0, #0x0
    3e20:      	b.eq	0x3e94 <_stogir.atomic.validate+0x374>
    3e24:      	mov	x0, x20
    3e28:      	mov	w1, w21
    3e2c:      	mov	x2, #0x4                ; =4
    3e30:      	bl	0x3e30 <_stogir.atomic.validate+0x310>
		0000000000003e30:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    3e34:      	ubfx	x0, x0, #0, #32
    3e38:      	lsr	x16, x0, #0
    3e3c:      	cmp	x16, #0x1
    3e40:      	b.eq	0x3e5c <_stogir.atomic.validate+0x33c>
    3e44:      	b.lo	0x3e4c <_stogir.atomic.validate+0x32c>
    3e48:      	b	0x3e60 <_stogir.atomic.validate+0x340>
    3e4c:      	cmp	x16, #0x0
    3e50:      	b.eq	0x3e58 <_stogir.atomic.validate+0x338>
    3e54:      	b	0x3e60 <_stogir.atomic.validate+0x340>
    3e58:      	b	0x3e64 <_stogir.atomic.validate+0x344>
    3e5c:      	b	0x40a8 <_stogir.atomic.validate+0x588>
    3e60:      	b	0x42a4 <_stogir.atomic.validate+0x784>
    3e64:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003e64:  ARM64_RELOC_PAGE21	l_stogir.378
    3e68:      	ldr	x24, [x24]
		0000000000003e68:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    3e6c:      	mov	x25, #0x1d              ; =29
    3e70:      	b	0x3e94 <_stogir.atomic.validate+0x374>
    3e74:      	mov	x0, x20
    3e78:      	mov	w2, w22
    3e7c:      	bl	0x3e7c <_stogir.atomic.validate+0x35c>
		0000000000003e7c:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    3e80:      	cmp	x0, #0x0
    3e84:      	b.ne	0x3e94 <_stogir.atomic.validate+0x374>
    3e88:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003e88:  ARM64_RELOC_PAGE21	l_stogir.379
    3e8c:      	ldr	x24, [x24]
		0000000000003e8c:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    3e90:      	mov	x25, #0x24              ; =36
    3e94:      	cmp	x25, #0x0
    3e98:      	b.ne	0x3ccc <_stogir.atomic.validate+0x1ac>
    3e9c:      	uxtb	w16, w26
    3ea0:      	cmp	w16, wzr
    3ea4:      	b.eq	0x3f38 <_stogir.atomic.validate+0x418>
    3ea8:      	movz	x0, #0x0, lsl #48
    3eac:      	b	0x3eb8 <_stogir.atomic.validate+0x398>
    3eb0:      	mov	w0, #0x1                ; =1
    3eb4:      	sxtw	x0, w0
    3eb8:      	and	x24, x0, #0xffffffff
    3ebc:      	movz	x0, #0x0, lsl #48
    3ec0:      	movz	x25, #0x0, lsl #48
    3ec4:      	b	0x3cd0 <_stogir.atomic.validate+0x1b0>
    3ec8:      	cmp	x2, #0x0
    3ecc:      	b.ge	0x3fc0 <_stogir.atomic.validate+0x4a0>
    3ed0:      	add	x6, x20, #0x50
    3ed4:      	ldr	x1, [x1, #0x8]
    3ed8:      	ldr	x6, [x6, #0x8]
    3edc:      	cmp	x1, x6
    3ee0:      	b.ne	0x40c8 <_stogir.atomic.validate+0x5a8>
    3ee4:      	cmp	x4, x1
    3ee8:      	b.gt	0x427c <_stogir.atomic.validate+0x75c>
    3eec:      	ldr	x1, [x20, #0x50]
    3ef0:      	add	x1, x1, x5, lsl #2
    3ef4:      	ldr	w1, [x1]
    3ef8:      	sxtw	x1, w1
    3efc:      	cmp	x1, #0x0
    3f00:      	cset	w1, gt
    3f04:      	ubfx	x1, x1, #0, #8
    3f08:      	b	0x4280 <_stogir.atomic.validate+0x760>
    3f0c:      	uxtb	w0, w0
    3f10:      	cmp	x0, #0x83
    3f14:      	cset	w1, lt
    3f18:      	uxtb	w16, w1
    3f1c:      	cmp	w16, wzr
    3f20:      	b.eq	0x4104 <_stogir.atomic.validate+0x5e4>
    3f24:      	adrp	x17, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003f24:  ARM64_RELOC_PAGE21	l_stogir.380
    3f28:      	ldr	x17, [x17]
		0000000000003f28:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    3f2c:      	add	x2, x0, x17
    3f30:      	ldrb	w2, [x2]
    3f34:      	b	0x4108 <_stogir.atomic.validate+0x5e8>
    3f38:      	sxtw	x22, w22
    3f3c:      	cmp	x22, #0x0
    3f40:      	b.ne	0x41d8 <_stogir.atomic.validate+0x6b8>
    3f44:      	movz	w0, #0x0, lsl #16
    3f48:      	b	0x3eb4 <_stogir.atomic.validate+0x394>
    3f4c:      	mov	x0, #0x1                ; =1
    3f50:      	b	0x3de0 <_stogir.atomic.validate+0x2c0>
    3f54:      	mov	x0, #0x1                ; =1
    3f58:      	cmp	x0, #0x0
    3f5c:      	b.eq	0x3ddc <_stogir.atomic.validate+0x2bc>
    3f60:      	orr	w0, w22, wzr
    3f64:      	add	x16, sp, #0x50
    3f68:      	ldr	w1, [x16, #0xc]
    3f6c:      	mov	w2, w0
    3f70:      	mov	x0, x20
    3f74:      	bl	0x3f74 <_stogir.atomic.validate+0x454>
		0000000000003f74:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    3f78:      	cmp	x0, #0x0
    3f7c:      	b.eq	0x3f4c <_stogir.atomic.validate+0x42c>
    3f80:      	movz	x0, #0x0, lsl #48
    3f84:      	b	0x3f50 <_stogir.atomic.validate+0x430>
    3f88:      	cmp	x22, #0x5
    3f8c:      	cset	w0, gt
    3f90:      	ubfx	x0, x0, #0, #8
    3f94:      	cmp	x0, #0x0
    3f98:      	b.eq	0x3fa8 <_stogir.atomic.validate+0x488>
    3f9c:      	adrp	x24, 0x3000 <_stogir.copy.validate+0x30>
		0000000000003f9c:  ARM64_RELOC_PAGE21	l_stogir.381
    3fa0:      	ldr	x24, [x24]
		0000000000003fa0:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    3fa4:      	mov	x25, #0x25              ; =37
    3fa8:      	cmp	x23, #0x7e
    3fac:      	b.ne	0x3f54 <_stogir.atomic.validate+0x434>
    3fb0:      	movz	x0, #0x0, lsl #48
    3fb4:      	b	0x3f58 <_stogir.atomic.validate+0x438>
    3fb8:      	movz	x1, #0x0, lsl #48
    3fbc:      	b	0x3fc4 <_stogir.atomic.validate+0x4a4>
    3fc0:      	movz	x1, #0x0, lsl #48
    3fc4:      	cmp	x1, #0x0
    3fc8:      	b.eq	0x3ffc <_stogir.atomic.validate+0x4dc>
    3fcc:      	uxtb	w16, w3
    3fd0:      	cmp	w16, wzr
    3fd4:      	b.eq	0x3fe8 <_stogir.atomic.validate+0x4c8>
    3fd8:      	ldr	x1, [x20]
    3fdc:      	add	x1, x1, x2, lsl #4
    3fe0:      	ldr	x1, [x1]
    3fe4:      	b	0x3ff4 <_stogir.atomic.validate+0x4d4>
    3fe8:      	ldr	x1, [x20, #0x28]
    3fec:      	add	x1, x1, x5, lsl #4
    3ff0:      	ldr	x1, [x1]
    3ff4:      	mov	w2, #0x1                ; =1
    3ff8:      	b	0x4004 <_stogir.atomic.validate+0x4e4>
    3ffc:      	movz	w2, #0x0, lsl #16
    4000:      	movz	x1, #0x0, lsl #48
    4004:      	ubfx	x2, x2, #0, #32
    4008:      	lsr	x16, x2, #0
    400c:      	cmp	x16, #0x1
    4010:      	b.eq	0x402c <_stogir.atomic.validate+0x50c>
    4014:      	b.lo	0x401c <_stogir.atomic.validate+0x4fc>
    4018:      	b	0x4030 <_stogir.atomic.validate+0x510>
    401c:      	cmp	x16, #0x0
    4020:      	b.eq	0x4028 <_stogir.atomic.validate+0x508>
    4024:      	b	0x4030 <_stogir.atomic.validate+0x510>
    4028:      	b	0x405c <_stogir.atomic.validate+0x53c>
    402c:      	b	0x4034 <_stogir.atomic.validate+0x514>
    4030:      	b	0x429c <_stogir.atomic.validate+0x77c>
    4034:      	orr	w2, w1, wzr
    4038:      	ubfx	x2, x2, #0, #32
    403c:      	ubfx	x2, x2, #8, #8
    4040:      	cmp	x2, #0x6
    4044:      	b.ne	0x405c <_stogir.atomic.validate+0x53c>
    4048:      	uxtb	w1, w1
    404c:      	cmp	x1, #0x46
    4050:      	b.eq	0x405c <_stogir.atomic.validate+0x53c>
    4054:      	cmp	x1, #0x48
    4058:      	b.ne	0x4068 <_stogir.atomic.validate+0x548>
    405c:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4e0>
		000000000000405c:  ARM64_RELOC_PAGE21	l_stogir.382
    4060:      	ldr	x24, [x24]
		0000000000004060:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    4064:      	mov	x25, #0x1b              ; =27
    4068:      	cmp	x23, #0x7f
    406c:      	b.ne	0x4098 <_stogir.atomic.validate+0x578>
    4070:      	uxtb	w16, w0
    4074:      	cmp	w16, wzr
    4078:      	b.eq	0x4164 <_stogir.atomic.validate+0x644>
    407c:      	movz	x0, #0x0, lsl #48
    4080:      	b	0x4168 <_stogir.atomic.validate+0x648>
    4084:      	add	x16, sp, #0x90
    4088:      	ldr	x0, [x16, #0x8]
    408c:      	ubfx	x0, x0, #0, #32
    4090:      	ubfx	x0, x0, #8, #8
    4094:      	orr	x22, x0, xzr
    4098:      	cmp	x22, #0x2
    409c:      	b.ge	0x3f88 <_stogir.atomic.validate+0x468>
    40a0:      	mov	x0, #0x1                ; =1
    40a4:      	b	0x3f94 <_stogir.atomic.validate+0x474>
    40a8:      	uxtb	w16, w27
    40ac:      	cmp	w16, wzr
    40b0:      	b.eq	0x3e74 <_stogir.atomic.validate+0x354>
    40b4:      	sxtw	x1, w1
    40b8:      	cmp	x1, #0x0
    40bc:      	b.ge	0x4258 <_stogir.atomic.validate+0x738>
    40c0:      	mov	x0, #0x1                ; =1
    40c4:      	b	0x4264 <_stogir.atomic.validate+0x744>
    40c8:      	movz	x1, #0x0, lsl #48
    40cc:      	b	0x3fc4 <_stogir.atomic.validate+0x4a4>
    40d0:      	movz	x1, #0x0, lsl #48
    40d4:      	b	0x3fbc <_stogir.atomic.validate+0x49c>
    40d8:      	movz	w0, #0x0, lsl #16
    40dc:      	uxtb	w16, w0
    40e0:      	and	w0, w16, #0x4
    40e4:      	uxtb	w0, w0
    40e8:      	ubfx	x0, x0, #0, #8
    40ec:      	cmp	x0, #0x0
    40f0:      	cset	w0, eq
    40f4:      	uxtb	w16, w0
    40f8:      	cmp	w16, wzr
    40fc:      	cset	x0, eq
    4100:      	b	0x3cd8 <_stogir.atomic.validate+0x1b8>
    4104:      	movz	w2, #0x0, lsl #16
    4108:      	uxtb	w16, w2
    410c:      	and	w2, w16, #0x1
    4110:      	uxtb	w2, w2
    4114:      	ubfx	x2, x2, #0, #8
    4118:      	cmp	x2, #0x0
    411c:      	b.eq	0x3cd4 <_stogir.atomic.validate+0x1b4>
    4120:      	uxtb	w16, w1
    4124:      	cmp	w16, wzr
    4128:      	b.eq	0x40d8 <_stogir.atomic.validate+0x5b8>
    412c:      	adrp	x17, 0x4000 <_stogir.atomic.validate+0x4e0>
		000000000000412c:  ARM64_RELOC_PAGE21	l_stogir.380
    4130:      	ldr	x17, [x17]
		0000000000004130:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    4134:      	add	x0, x0, x17
    4138:      	ldrb	w0, [x0]
    413c:      	b	0x40dc <_stogir.atomic.validate+0x5bc>
    4140:      	mov	w1, #-0x2               ; =-2
    4144:      	sxtw	x0, w0
    4148:      	sxtw	x1, w1
    414c:      	cmp	x0, x1
    4150:      	b.ne	0x3c64 <_stogir.atomic.validate+0x144>
    4154:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004154:  ARM64_RELOC_PAGE21	l_stogir.383
    4158:      	ldr	x24, [x24]
		0000000000004158:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    415c:      	movz	x25, #0x0, lsl #48
    4160:      	b	0x3c70 <_stogir.atomic.validate+0x150>
    4164:      	mov	x0, #0x1                ; =1
    4168:      	cmp	x0, #0x0
    416c:      	b.eq	0x417c <_stogir.atomic.validate+0x65c>
    4170:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004170:  ARM64_RELOC_PAGE21	l_stogir.384
    4174:      	ldr	x24, [x24]
		0000000000004174:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    4178:      	mov	x25, #0x19              ; =25
    417c:      	add	x16, sp, #0x50
    4180:      	ldr	w0, [x16, #0xc]
    4184:      	add	x8, sp, #0x90
    4188:      	mov	w1, w0
    418c:      	mov	x0, x20
    4190:      	bl	0x4190 <_stogir.atomic.validate+0x670>
		0000000000004190:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4194:      	add	x16, sp, #0x90
    4198:      	ldr	w0, [x16]
    419c:      	lsr	x16, x0, #0
    41a0:      	cmp	x16, #0x1
    41a4:      	b.eq	0x41c0 <_stogir.atomic.validate+0x6a0>
    41a8:      	b.lo	0x41b0 <_stogir.atomic.validate+0x690>
    41ac:      	b	0x41c4 <_stogir.atomic.validate+0x6a4>
    41b0:      	cmp	x16, #0x0
    41b4:      	b.eq	0x41bc <_stogir.atomic.validate+0x69c>
    41b8:      	b	0x41c4 <_stogir.atomic.validate+0x6a4>
    41bc:      	b	0x41c8 <_stogir.atomic.validate+0x6a8>
    41c0:      	b	0x4084 <_stogir.atomic.validate+0x564>
    41c4:      	b	0x42ac <_stogir.atomic.validate+0x78c>
    41c8:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4e0>
		00000000000041c8:  ARM64_RELOC_PAGE21	l_stogir.385
    41cc:      	ldr	x24, [x24]
		00000000000041cc:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    41d0:      	mov	x25, #0x1a              ; =26
    41d4:      	b	0x4098 <_stogir.atomic.validate+0x578>
    41d8:      	cmp	x22, #0x1
    41dc:      	b.eq	0x3eb0 <_stogir.atomic.validate+0x390>
    41e0:      	cmp	x22, #0x2
    41e4:      	b.eq	0x3eb0 <_stogir.atomic.validate+0x390>
    41e8:      	cmp	x22, #0x7
    41ec:      	b.eq	0x3eb0 <_stogir.atomic.validate+0x390>
    41f0:      	cmp	x22, #0x8
    41f4:      	b.eq	0x3eb0 <_stogir.atomic.validate+0x390>
    41f8:      	cmp	x22, #0x3
    41fc:      	b.eq	0x4294 <_stogir.atomic.validate+0x774>
    4200:      	cmp	x22, #0x9
    4204:      	b.eq	0x4294 <_stogir.atomic.validate+0x774>
    4208:      	cmp	x22, #0x4
    420c:      	b.eq	0x42b4 <_stogir.atomic.validate+0x794>
    4210:      	cmp	x22, #0xa
    4214:      	b.eq	0x42b4 <_stogir.atomic.validate+0x794>
    4218:      	cmp	x22, #0xd
    421c:      	b.eq	0x42b4 <_stogir.atomic.validate+0x794>
    4220:      	cmp	x22, #0x5
    4224:      	b.eq	0x42bc <_stogir.atomic.validate+0x79c>
    4228:      	cmp	x22, #0xb
    422c:      	b.eq	0x42bc <_stogir.atomic.validate+0x79c>
    4230:      	cmp	x22, #0xc
    4234:      	b.eq	0x42bc <_stogir.atomic.validate+0x79c>
    4238:      	cmp	x22, #0x6
    423c:      	cset	w0, eq
    4240:      	uxtb	w16, w0
    4244:      	cmp	w16, wzr
    4248:      	mov	w16, #0x8               ; =8
    424c:      	movn	w17, #0x0, lsl #16
    4250:      	csel	w0, w16, w17, ne
    4254:      	b	0x42c0 <_stogir.atomic.validate+0x7a0>
    4258:      	cmp	x1, #0x9
    425c:      	cset	w0, gt
    4260:      	ubfx	x0, x0, #0, #8
    4264:      	cmp	x0, #0x0
    4268:      	b.eq	0x4278 <_stogir.atomic.validate+0x758>
    426c:      	adrp	x24, 0x4000 <_stogir.atomic.validate+0x4e0>
		000000000000426c:  ARM64_RELOC_PAGE21	l_stogir.386
    4270:      	ldr	x24, [x24]
		0000000000004270:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    4274:      	mov	x25, #0x1c              ; =28
    4278:      	b	0x3e94 <_stogir.atomic.validate+0x374>
    427c:      	movz	x1, #0x0, lsl #48
    4280:      	b	0x40cc <_stogir.atomic.validate+0x5ac>
    4284:      	brk	#0
    4288:      	b	0x4284 <_stogir.atomic.validate+0x764>
    428c:      	brk	#0
    4290:      	b	0x428c <_stogir.atomic.validate+0x76c>
    4294:      	mov	w0, #0x2                ; =2
    4298:      	b	0x3eb4 <_stogir.atomic.validate+0x394>
    429c:      	brk	#0
    42a0:      	b	0x429c <_stogir.atomic.validate+0x77c>
    42a4:      	brk	#0
    42a8:      	b	0x42a4 <_stogir.atomic.validate+0x784>
    42ac:      	brk	#0
    42b0:      	b	0x42ac <_stogir.atomic.validate+0x78c>
    42b4:      	mov	w0, #0x4                ; =4
    42b8:      	b	0x4298 <_stogir.atomic.validate+0x778>
    42bc:      	mov	w0, #0x8                ; =8
    42c0:      	b	0x42b8 <_stogir.atomic.validate+0x798>

00000000000042c4 <_stogir.terminal.validate>:
    42c4:      	sub	sp, sp, #0x50
    42c8:      	str	x29, [sp]
    42cc:      	str	x30, [sp, #0x8]
    42d0:      	mov	x29, sp
    42d4:      	str	x19, [sp, #0x40]
    42d8:      	sxtw	x1, w1
    42dc:      	add	x2, x0, #0x78
    42e0:      	add	x3, x0, #0x28
    42e4:      	lsl	x4, x1, #2
    42e8:      	cmp	x1, #0x0
    42ec:      	cset	w5, gt
    42f0:      	movz	x16, #0x0, lsl #48
    42f4:      	sub	x6, x16, x1
    42f8:      	sub	x7, x6, #0x1
    42fc:      	uxtb	w16, w5
    4300:      	cmp	w16, wzr
    4304:      	b.eq	0x4340 <_stogir.terminal.validate+0x7c>
    4308:      	ldr	x3, [x0, #0x8]
    430c:      	cmp	x1, x3
    4310:      	b.ge	0x438c <_stogir.terminal.validate+0xc8>
    4314:      	ldr	x2, [x2, #0x8]
    4318:      	cmp	x1, x2
    431c:      	b.ge	0x4478 <_stogir.terminal.validate+0x1b4>
    4320:      	ldr	x2, [x0, #0x78]
    4324:      	add	x2, x4, x2
    4328:      	ldr	w2, [x2]
    432c:      	sxtw	x2, w2
    4330:      	cmp	x2, #0x0
    4334:      	cset	w2, ge
    4338:      	ubfx	x2, x2, #0, #8
    433c:      	b	0x447c <_stogir.terminal.validate+0x1b8>
    4340:      	cmp	x1, #0x0
    4344:      	b.ge	0x4394 <_stogir.terminal.validate+0xd0>
    4348:      	add	x2, x0, #0x50
    434c:      	ldr	x3, [x3, #0x8]
    4350:      	ldr	x2, [x2, #0x8]
    4354:      	cmp	x3, x2
    4358:      	b.ne	0x4384 <_stogir.terminal.validate+0xc0>
    435c:      	cmp	x6, x3
    4360:      	b.gt	0x44b8 <_stogir.terminal.validate+0x1f4>
    4364:      	ldr	x2, [x0, #0x50]
    4368:      	add	x2, x2, x7, lsl #2
    436c:      	ldr	w2, [x2]
    4370:      	sxtw	x2, w2
    4374:      	cmp	x2, #0x0
    4378:      	cset	w2, gt
    437c:      	ubfx	x2, x2, #0, #8
    4380:      	b	0x44bc <_stogir.terminal.validate+0x1f8>
    4384:      	movz	x2, #0x0, lsl #48
    4388:      	b	0x4398 <_stogir.terminal.validate+0xd4>
    438c:      	movz	x2, #0x0, lsl #48
    4390:      	b	0x4398 <_stogir.terminal.validate+0xd4>
    4394:      	movz	x2, #0x0, lsl #48
    4398:      	cmp	x2, #0x0
    439c:      	b.eq	0x43d8 <_stogir.terminal.validate+0x114>
    43a0:      	uxtb	w16, w5
    43a4:      	cmp	w16, wzr
    43a8:      	b.eq	0x43c0 <_stogir.terminal.validate+0xfc>
    43ac:      	ldr	x2, [x0]
    43b0:      	add	x2, x2, x1, lsl #4
    43b4:      	ldr	x3, [x2]
    43b8:      	ldr	x2, [x2, #0x8]
    43bc:      	b	0x43d0 <_stogir.terminal.validate+0x10c>
    43c0:      	ldr	x2, [x0, #0x28]
    43c4:      	add	x2, x2, x7, lsl #4
    43c8:      	ldr	x3, [x2]
    43cc:      	ldr	x2, [x2, #0x8]
    43d0:      	mov	w5, #0x1                ; =1
    43d4:      	b	0x43e4 <_stogir.terminal.validate+0x120>
    43d8:      	movz	w5, #0x0, lsl #16
    43dc:      	movz	x3, #0x0, lsl #48
    43e0:      	movz	x2, #0x0, lsl #48
    43e4:      	ubfx	x5, x5, #0, #32
    43e8:      	lsr	x16, x5, #0
    43ec:      	cmp	x16, #0x1
    43f0:      	b.eq	0x440c <_stogir.terminal.validate+0x148>
    43f4:      	b.lo	0x43fc <_stogir.terminal.validate+0x138>
    43f8:      	b	0x4410 <_stogir.terminal.validate+0x14c>
    43fc:      	cmp	x16, #0x0
    4400:      	b.eq	0x4408 <_stogir.terminal.validate+0x144>
    4404:      	b	0x4410 <_stogir.terminal.validate+0x14c>
    4408:      	b	0x4414 <_stogir.terminal.validate+0x150>
    440c:      	b	0x442c <_stogir.terminal.validate+0x168>
    4410:      	b	0x4584 <_stogir.terminal.validate+0x2c0>
    4414:      	mov	x19, x8
    4418:      	mov	x0, #0x1                ; =1
    441c:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		000000000000441c:  ARM64_RELOC_PAGE21	l_stogir.387
    4420:      	ldr	x1, [x1]
		0000000000004420:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    4424:      	mov	x2, #0x21               ; =33
    4428:      	b	0x4458 <_stogir.terminal.validate+0x194>
    442c:      	add	x16, sp, #0x10
    4430:      	str	x3, [x16]
    4434:      	add	x16, sp, #0x10
    4438:      	str	x2, [x16, #0x8]
    443c:      	cmp	x1, #0x0
    4440:      	b.gt	0x4480 <_stogir.terminal.validate+0x1bc>
    4444:      	mov	x19, x8
    4448:      	mov	x0, #0x1                ; =1
    444c:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		000000000000444c:  ARM64_RELOC_PAGE21	l_stogir.388
    4450:      	ldr	x1, [x1]
		0000000000004450:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    4454:      	mov	x2, #0x1b               ; =27
    4458:      	str	x0, [x19]
    445c:      	str	x1, [x19, #0x8]
    4460:      	str	x2, [x19, #0x10]
    4464:      	ldr	x19, [sp, #0x40]
    4468:      	ldr	x29, [sp]
    446c:      	ldr	x30, [sp, #0x8]
    4470:      	add	sp, sp, #0x50
    4474:      	ret
    4478:      	movz	x2, #0x0, lsl #48
    447c:      	b	0x4390 <_stogir.terminal.validate+0xcc>
    4480:      	uxtb	w3, w3
    4484:      	orr	x1, x3, xzr
    4488:      	cmp	x1, #0x60
    448c:      	cset	w2, eq
    4490:      	cmp	x1, #0x79
    4494:      	cset	w1, eq
    4498:      	uxtb	w16, w2
    449c:      	cmp	w16, wzr
    44a0:      	b.ne	0x44c0 <_stogir.terminal.validate+0x1fc>
    44a4:      	uxtb	w16, w1
    44a8:      	cmp	w16, wzr
    44ac:      	b.ne	0x44c0 <_stogir.terminal.validate+0x1fc>
    44b0:      	mov	x19, x8
    44b4:      	b	0x4448 <_stogir.terminal.validate+0x184>
    44b8:      	movz	x2, #0x0, lsl #48
    44bc:      	b	0x4388 <_stogir.terminal.validate+0xc4>
    44c0:      	add	x16, sp, #0x10
    44c4:      	ldr	w5, [x16]
    44c8:      	ubfx	x5, x5, #8, #8
    44cc:      	cmp	x5, #0x0
    44d0:      	b.ne	0x458c <_stogir.terminal.validate+0x2c8>
    44d4:      	uxtb	w16, w2
    44d8:      	cmp	w16, wzr
    44dc:      	mov	w16, #0x1               ; =1
    44e0:      	mov	w17, #0x3               ; =3
    44e4:      	csel	w2, w16, w17, ne
    44e8:      	ldr	x5, [x0, #0x78]
    44ec:      	sxtw	x2, w2
    44f0:      	add	x4, x4, x5
    44f4:      	ldr	w4, [x4]
    44f8:      	sxtw	x4, w4
    44fc:      	cmp	x4, x2
    4500:      	b.ne	0x4594 <_stogir.terminal.validate+0x2d0>
    4504:      	uxtb	w16, w1
    4508:      	cmp	w16, wzr
    450c:      	b.eq	0x4564 <_stogir.terminal.validate+0x2a0>
    4510:      	add	x16, sp, #0x10
    4514:      	ldr	w2, [x16, #0x8]
    4518:      	sxtw	x2, w2
    451c:      	cmp	x2, #0x0
    4520:      	b.eq	0x4564 <_stogir.terminal.validate+0x2a0>
    4524:      	mov	x19, x8
    4528:      	b	0x4448 <_stogir.terminal.validate+0x184>
    452c:      	movz	w1, #0x0, lsl #16
    4530:      	mov	x19, x8
    4534:      	add	x8, sp, #0x20
    4538:      	fmov	s31, w1
    453c:      	mov	w1, w3
    4540:      	fmov	w3, s31
    4544:      	bl	0x4544 <_stogir.terminal.validate+0x280>
		0000000000004544:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    4548:      	add	x16, sp, #0x20
    454c:      	ldr	x0, [x16]
    4550:      	add	x16, sp, #0x20
    4554:      	ldr	x1, [x16, #0x8]
    4558:      	add	x16, sp, #0x20
    455c:      	ldr	x2, [x16, #0x10]
    4560:      	b	0x4458 <_stogir.terminal.validate+0x194>
    4564:      	add	x16, sp, #0x10
    4568:      	ldr	w2, [x16, #0x4]
    456c:      	uxtb	w16, w1
    4570:      	cmp	w16, wzr
    4574:      	b.eq	0x452c <_stogir.terminal.validate+0x268>
    4578:      	add	x16, sp, #0x10
    457c:      	ldr	w1, [x16, #0xc]
    4580:      	b	0x4530 <_stogir.terminal.validate+0x26c>
    4584:      	brk	#0
    4588:      	b	0x4584 <_stogir.terminal.validate+0x2c0>
    458c:      	mov	x19, x8
    4590:      	b	0x4448 <_stogir.terminal.validate+0x184>
    4594:      	mov	x19, x8
    4598:      	b	0x4448 <_stogir.terminal.validate+0x184>

000000000000459c <_stogir.switch.validate>:
    459c:      	sub	sp, sp, #0x70
    45a0:      	str	x29, [sp]
    45a4:      	str	x30, [sp, #0x8]
    45a8:      	mov	x29, sp
    45ac:      	str	x19, [sp, #0x60]
    45b0:      	sxtw	x1, w1
    45b4:      	add	x2, x0, #0x78
    45b8:      	add	x3, x0, #0x28
    45bc:      	lsl	x4, x1, #2
    45c0:      	cmp	x1, #0x0
    45c4:      	cset	w5, gt
    45c8:      	movz	x16, #0x0, lsl #48
    45cc:      	sub	x6, x16, x1
    45d0:      	sub	x7, x6, #0x1
    45d4:      	uxtb	w16, w5
    45d8:      	cmp	w16, wzr
    45dc:      	b.eq	0x4618 <_stogir.switch.validate+0x7c>
    45e0:      	ldr	x3, [x0, #0x8]
    45e4:      	cmp	x1, x3
    45e8:      	b.ge	0x4664 <_stogir.switch.validate+0xc8>
    45ec:      	ldr	x2, [x2, #0x8]
    45f0:      	cmp	x1, x2
    45f4:      	b.ge	0x4750 <_stogir.switch.validate+0x1b4>
    45f8:      	ldr	x2, [x0, #0x78]
    45fc:      	add	x2, x4, x2
    4600:      	ldr	w2, [x2]
    4604:      	sxtw	x2, w2
    4608:      	cmp	x2, #0x0
    460c:      	cset	w2, ge
    4610:      	ubfx	x2, x2, #0, #8
    4614:      	b	0x4754 <_stogir.switch.validate+0x1b8>
    4618:      	cmp	x1, #0x0
    461c:      	b.ge	0x466c <_stogir.switch.validate+0xd0>
    4620:      	add	x2, x0, #0x50
    4624:      	ldr	x3, [x3, #0x8]
    4628:      	ldr	x2, [x2, #0x8]
    462c:      	cmp	x3, x2
    4630:      	b.ne	0x465c <_stogir.switch.validate+0xc0>
    4634:      	cmp	x6, x3
    4638:      	b.gt	0x478c <_stogir.switch.validate+0x1f0>
    463c:      	ldr	x2, [x0, #0x50]
    4640:      	add	x2, x2, x7, lsl #2
    4644:      	ldr	w2, [x2]
    4648:      	sxtw	x2, w2
    464c:      	cmp	x2, #0x0
    4650:      	cset	w2, gt
    4654:      	ubfx	x2, x2, #0, #8
    4658:      	b	0x4790 <_stogir.switch.validate+0x1f4>
    465c:      	movz	x2, #0x0, lsl #48
    4660:      	b	0x4670 <_stogir.switch.validate+0xd4>
    4664:      	movz	x2, #0x0, lsl #48
    4668:      	b	0x4670 <_stogir.switch.validate+0xd4>
    466c:      	movz	x2, #0x0, lsl #48
    4670:      	cmp	x2, #0x0
    4674:      	b.eq	0x46b0 <_stogir.switch.validate+0x114>
    4678:      	uxtb	w16, w5
    467c:      	cmp	w16, wzr
    4680:      	b.eq	0x4698 <_stogir.switch.validate+0xfc>
    4684:      	ldr	x2, [x0]
    4688:      	add	x2, x2, x1, lsl #4
    468c:      	ldr	x3, [x2]
    4690:      	ldr	x2, [x2, #0x8]
    4694:      	b	0x46a8 <_stogir.switch.validate+0x10c>
    4698:      	ldr	x2, [x0, #0x28]
    469c:      	add	x2, x2, x7, lsl #4
    46a0:      	ldr	x3, [x2]
    46a4:      	ldr	x2, [x2, #0x8]
    46a8:      	mov	w5, #0x1                ; =1
    46ac:      	b	0x46bc <_stogir.switch.validate+0x120>
    46b0:      	movz	w5, #0x0, lsl #16
    46b4:      	movz	x3, #0x0, lsl #48
    46b8:      	movz	x2, #0x0, lsl #48
    46bc:      	ubfx	x5, x5, #0, #32
    46c0:      	lsr	x16, x5, #0
    46c4:      	cmp	x16, #0x1
    46c8:      	b.eq	0x46e4 <_stogir.switch.validate+0x148>
    46cc:      	b.lo	0x46d4 <_stogir.switch.validate+0x138>
    46d0:      	b	0x46e8 <_stogir.switch.validate+0x14c>
    46d4:      	cmp	x16, #0x0
    46d8:      	b.eq	0x46e0 <_stogir.switch.validate+0x144>
    46dc:      	b	0x46e8 <_stogir.switch.validate+0x14c>
    46e0:      	b	0x46ec <_stogir.switch.validate+0x150>
    46e4:      	b	0x4704 <_stogir.switch.validate+0x168>
    46e8:      	b	0x4870 <_stogir.switch.validate+0x2d4>
    46ec:      	mov	x19, x8
    46f0:      	mov	x0, #0x1                ; =1
    46f4:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		00000000000046f4:  ARM64_RELOC_PAGE21	l_stogir.389
    46f8:      	ldr	x1, [x1]
		00000000000046f8:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    46fc:      	mov	x2, #0x1a               ; =26
    4700:      	b	0x4730 <_stogir.switch.validate+0x194>
    4704:      	add	x16, sp, #0x10
    4708:      	str	x3, [x16]
    470c:      	add	x16, sp, #0x10
    4710:      	str	x2, [x16, #0x8]
    4714:      	cmp	x1, #0x0
    4718:      	b.gt	0x4758 <_stogir.switch.validate+0x1bc>
    471c:      	mov	x19, x8
    4720:      	mov	x0, #0x1                ; =1
    4724:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004724:  ARM64_RELOC_PAGE21	l_stogir.390
    4728:      	ldr	x1, [x1]
		0000000000004728:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    472c:      	mov	x2, #0x20               ; =32
    4730:      	str	x0, [x19]
    4734:      	str	x1, [x19, #0x8]
    4738:      	str	x2, [x19, #0x10]
    473c:      	ldr	x19, [sp, #0x60]
    4740:      	ldr	x29, [sp]
    4744:      	ldr	x30, [sp, #0x8]
    4748:      	add	sp, sp, #0x70
    474c:      	ret
    4750:      	movz	x2, #0x0, lsl #48
    4754:      	b	0x4668 <_stogir.switch.validate+0xcc>
    4758:      	uxtb	w3, w3
    475c:      	orr	x1, x3, xzr
    4760:      	cmp	x1, #0x75
    4764:      	cset	w2, eq
    4768:      	uxtb	w16, w2
    476c:      	cmp	w16, wzr
    4770:      	b.ne	0x4794 <_stogir.switch.validate+0x1f8>
    4774:      	cmp	x1, #0x6d
    4778:      	b.lt	0x4878 <_stogir.switch.validate+0x2dc>
    477c:      	cmp	x1, #0x6f
    4780:      	b.le	0x4794 <_stogir.switch.validate+0x1f8>
    4784:      	mov	x19, x8
    4788:      	b	0x4720 <_stogir.switch.validate+0x184>
    478c:      	movz	x2, #0x0, lsl #48
    4790:      	b	0x4660 <_stogir.switch.validate+0xc4>
    4794:      	add	x16, sp, #0x10
    4798:      	ldr	w5, [x16]
    479c:      	ubfx	x5, x5, #8, #8
    47a0:      	cmp	x5, #0x0
    47a4:      	b.ne	0x4880 <_stogir.switch.validate+0x2e4>
    47a8:      	ldr	x5, [x0, #0x78]
    47ac:      	add	x4, x4, x5
    47b0:      	ldr	w4, [x4]
    47b4:      	cmp	x1, #0x6d
    47b8:      	b.eq	0x4818 <_stogir.switch.validate+0x27c>
    47bc:      	cmp	x1, #0x6e
    47c0:      	b.eq	0x4818 <_stogir.switch.validate+0x27c>
    47c4:      	mov	w1, #0x2                ; =2
    47c8:      	b	0x481c <_stogir.switch.validate+0x280>
    47cc:      	add	x16, sp, #0x10
    47d0:      	ldr	w1, [x16, #0x4]
    47d4:      	add	x16, sp, #0x10
    47d8:      	ldr	w2, [x16, #0x8]
    47dc:      	add	x16, sp, #0x10
    47e0:      	ldr	w4, [x16, #0xc]
    47e4:      	add	x8, sp, #0x40
    47e8:      	fmov	s31, w1
    47ec:      	mov	w1, w3
    47f0:      	mov	w3, w2
    47f4:      	fmov	w2, s31
    47f8:      	bl	0x47f8 <_stogir.switch.validate+0x25c>
		00000000000047f8:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    47fc:      	add	x16, sp, #0x40
    4800:      	ldr	x0, [x16]
    4804:      	add	x16, sp, #0x40
    4808:      	ldr	x1, [x16, #0x8]
    480c:      	add	x16, sp, #0x40
    4810:      	ldr	x2, [x16, #0x10]
    4814:      	b	0x4730 <_stogir.switch.validate+0x194>
    4818:      	mov	w1, #0x3                ; =3
    481c:      	sxtw	x4, w4
    4820:      	sxtw	x1, w1
    4824:      	cmp	x4, x1
    4828:      	b.ne	0x4888 <_stogir.switch.validate+0x2ec>
    482c:      	uxtb	w16, w2
    4830:      	cmp	w16, wzr
    4834:      	b.eq	0x4890 <_stogir.switch.validate+0x2f4>
    4838:      	add	x16, sp, #0x10
    483c:      	ldr	w1, [x16, #0x4]
    4840:      	add	x16, sp, #0x10
    4844:      	ldr	w2, [x16, #0x8]
    4848:      	mov	x19, x8
    484c:      	add	x8, sp, #0x20
    4850:      	bl	0x4850 <_stogir.switch.validate+0x2b4>
		0000000000004850:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    4854:      	add	x16, sp, #0x20
    4858:      	ldr	x0, [x16]
    485c:      	add	x16, sp, #0x20
    4860:      	ldr	x1, [x16, #0x8]
    4864:      	add	x16, sp, #0x20
    4868:      	ldr	x2, [x16, #0x10]
    486c:      	b	0x4814 <_stogir.switch.validate+0x278>
    4870:      	brk	#0
    4874:      	b	0x4870 <_stogir.switch.validate+0x2d4>
    4878:      	mov	x19, x8
    487c:      	b	0x4720 <_stogir.switch.validate+0x184>
    4880:      	mov	x19, x8
    4884:      	b	0x4720 <_stogir.switch.validate+0x184>
    4888:      	mov	x19, x8
    488c:      	b	0x4720 <_stogir.switch.validate+0x184>
    4890:      	mov	x19, x8
    4894:      	b	0x47cc <_stogir.switch.validate+0x230>

0000000000004898 <_stogir.stack.validate>:
    4898:      	sub	sp, sp, #0x90
    489c:      	str	x29, [sp]
    48a0:      	str	x30, [sp, #0x8]
    48a4:      	mov	x29, sp
    48a8:      	str	x19, [sp, #0x60]
    48ac:      	str	x20, [sp, #0x68]
    48b0:      	str	x21, [sp, #0x70]
    48b4:      	str	x22, [sp, #0x78]
    48b8:      	str	x23, [sp, #0x80]
    48bc:      	sxtw	x1, w1
    48c0:      	add	x2, x0, #0x78
    48c4:      	add	x3, x0, #0x28
    48c8:      	add	x4, x0, #0x50
    48cc:      	lsl	x5, x1, #2
    48d0:      	cmp	x1, #0x0
    48d4:      	cset	w6, gt
    48d8:      	movz	x16, #0x0, lsl #48
    48dc:      	sub	x7, x16, x1
    48e0:      	cmp	x1, #0x0
    48e4:      	cset	w9, lt
    48e8:      	sub	x10, x7, #0x1
    48ec:      	lsl	x11, x10, #2
    48f0:      	uxtb	w16, w6
    48f4:      	cmp	w16, wzr
    48f8:      	b.eq	0x4934 <_stogir.stack.validate+0x9c>
    48fc:      	ldr	x12, [x0, #0x8]
    4900:      	cmp	x1, x12
    4904:      	b.ge	0x49a4 <_stogir.stack.validate+0x10c>
    4908:      	ldr	x12, [x2, #0x8]
    490c:      	cmp	x1, x12
    4910:      	b.ge	0x4ae4 <_stogir.stack.validate+0x24c>
    4914:      	ldr	x12, [x0, #0x78]
    4918:      	add	x12, x5, x12
    491c:      	ldr	w12, [x12]
    4920:      	sxtw	x12, w12
    4924:      	cmp	x12, #0x0
    4928:      	cset	w12, ge
    492c:      	ubfx	x12, x12, #0, #8
    4930:      	b	0x4ae8 <_stogir.stack.validate+0x250>
    4934:      	uxtb	w16, w9
    4938:      	cmp	w16, wzr
    493c:      	b.eq	0x49ac <_stogir.stack.validate+0x114>
    4940:      	ldr	x12, [x3, #0x8]
    4944:      	ldr	x13, [x4, #0x8]
    4948:      	cmp	x12, x13
    494c:      	b.ne	0x4978 <_stogir.stack.validate+0xe0>
    4950:      	cmp	x7, x12
    4954:      	b.gt	0x4aec <_stogir.stack.validate+0x254>
    4958:      	ldr	x12, [x0, #0x50]
    495c:      	add	x12, x11, x12
    4960:      	ldr	w12, [x12]
    4964:      	sxtw	x12, w12
    4968:      	cmp	x12, #0x0
    496c:      	cset	w12, gt
    4970:      	ubfx	x12, x12, #0, #8
    4974:      	b	0x4af0 <_stogir.stack.validate+0x258>
    4978:      	movz	x12, #0x0, lsl #48
    497c:      	b	0x49b0 <_stogir.stack.validate+0x118>
    4980:      	uxtb	w16, w15
    4984:      	cmp	w16, wzr
    4988:      	b.eq	0x4b0c <_stogir.stack.validate+0x274>
    498c:      	mov	x22, x8
    4990:      	mov	x0, #0x1                ; =1
    4994:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004994:  ARM64_RELOC_PAGE21	l_stogir.391
    4998:      	ldr	x1, [x1]
		0000000000004998:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    499c:      	mov	x2, #0x19               ; =25
    49a0:      	b	0x4a48 <_stogir.stack.validate+0x1b0>
    49a4:      	movz	x12, #0x0, lsl #48
    49a8:      	b	0x49b0 <_stogir.stack.validate+0x118>
    49ac:      	movz	x12, #0x0, lsl #48
    49b0:      	lsl	x13, x1, #4
    49b4:      	lsl	x10, x10, #4
    49b8:      	cmp	x12, #0x0
    49bc:      	b.eq	0x49f8 <_stogir.stack.validate+0x160>
    49c0:      	uxtb	w16, w6
    49c4:      	cmp	w16, wzr
    49c8:      	b.eq	0x49e0 <_stogir.stack.validate+0x148>
    49cc:      	ldr	x12, [x0]
    49d0:      	add	x12, x13, x12
    49d4:      	ldr	x14, [x12]
    49d8:      	ldr	x12, [x12, #0x8]
    49dc:      	b	0x49f0 <_stogir.stack.validate+0x158>
    49e0:      	ldr	x12, [x0, #0x28]
    49e4:      	add	x12, x10, x12
    49e8:      	ldr	x14, [x12]
    49ec:      	ldr	x12, [x12, #0x8]
    49f0:      	mov	w15, #0x1               ; =1
    49f4:      	b	0x4a04 <_stogir.stack.validate+0x16c>
    49f8:      	movz	w15, #0x0, lsl #16
    49fc:      	movz	x14, #0x0, lsl #48
    4a00:      	movz	x12, #0x0, lsl #48
    4a04:      	ubfx	x15, x15, #0, #32
    4a08:      	lsr	x16, x15, #0
    4a0c:      	cmp	x16, #0x1
    4a10:      	b.eq	0x4a2c <_stogir.stack.validate+0x194>
    4a14:      	b.lo	0x4a1c <_stogir.stack.validate+0x184>
    4a18:      	b	0x4a30 <_stogir.stack.validate+0x198>
    4a1c:      	cmp	x16, #0x0
    4a20:      	b.eq	0x4a28 <_stogir.stack.validate+0x190>
    4a24:      	b	0x4a30 <_stogir.stack.validate+0x198>
    4a28:      	b	0x4a34 <_stogir.stack.validate+0x19c>
    4a2c:      	b	0x4a78 <_stogir.stack.validate+0x1e0>
    4a30:      	b	0x4e24 <_stogir.stack.validate+0x58c>
    4a34:      	mov	x22, x8
    4a38:      	mov	x0, #0x1                ; =1
    4a3c:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004a3c:  ARM64_RELOC_PAGE21	l_stogir.392
    4a40:      	ldr	x1, [x1]
		0000000000004a40:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    4a44:      	mov	x2, #0x19               ; =25
    4a48:      	str	x0, [x22]
    4a4c:      	str	x1, [x22, #0x8]
    4a50:      	str	x2, [x22, #0x10]
    4a54:      	ldr	x19, [sp, #0x60]
    4a58:      	ldr	x20, [sp, #0x68]
    4a5c:      	ldr	x21, [sp, #0x70]
    4a60:      	ldr	x22, [sp, #0x78]
    4a64:      	ldr	x23, [sp, #0x80]
    4a68:      	ldr	x29, [sp]
    4a6c:      	ldr	x30, [sp, #0x8]
    4a70:      	add	sp, sp, #0x90
    4a74:      	ret
    4a78:      	cmp	x1, #0x0
    4a7c:      	cset	w15, le
    4a80:      	uxtb	w19, w14
    4a84:      	add	x16, sp, #0x10
    4a88:      	str	x14, [x16]
    4a8c:      	orr	x14, x19, xzr
    4a90:      	add	x16, sp, #0x10
    4a94:      	str	x12, [x16, #0x8]
    4a98:      	cmp	x14, #0x42
    4a9c:      	b.ne	0x4980 <_stogir.stack.validate+0xe8>
    4aa0:      	uxtb	w16, w6
    4aa4:      	cmp	w16, wzr
    4aa8:      	b.eq	0x4b58 <_stogir.stack.validate+0x2c0>
    4aac:      	ldr	x3, [x0, #0x8]
    4ab0:      	cmp	x1, x3
    4ab4:      	b.ge	0x4b9c <_stogir.stack.validate+0x304>
    4ab8:      	ldr	x2, [x2, #0x8]
    4abc:      	cmp	x1, x2
    4ac0:      	b.ge	0x4c84 <_stogir.stack.validate+0x3ec>
    4ac4:      	ldr	x1, [x0, #0x78]
    4ac8:      	add	x1, x5, x1
    4acc:      	ldr	w1, [x1]
    4ad0:      	sxtw	x1, w1
    4ad4:      	cmp	x1, #0x0
    4ad8:      	cset	w1, ge
    4adc:      	ubfx	x1, x1, #0, #8
    4ae0:      	b	0x4c88 <_stogir.stack.validate+0x3f0>
    4ae4:      	movz	x12, #0x0, lsl #48
    4ae8:      	b	0x49a8 <_stogir.stack.validate+0x110>
    4aec:      	movz	x12, #0x0, lsl #48
    4af0:      	b	0x497c <_stogir.stack.validate+0xe4>
    4af4:      	mov	x0, #0x1                ; =1
    4af8:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004af8:  ARM64_RELOC_PAGE21	l_stogir.393
    4afc:      	ldr	x1, [x1]
		0000000000004afc:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    4b00:      	mov	x2, #0x1e               ; =30
    4b04:      	mov	x22, x8
    4b08:      	b	0x49a0 <_stogir.stack.validate+0x108>
    4b0c:      	cmp	x14, #0x51
    4b10:      	cset	w1, eq
    4b14:      	cmp	x14, #0x53
    4b18:      	cset	w20, eq
    4b1c:      	cmp	x14, #0x54
    4b20:      	cset	w21, eq
    4b24:      	uxtb	w16, w1
    4b28:      	cmp	w16, wzr
    4b2c:      	b.ne	0x4c8c <_stogir.stack.validate+0x3f4>
    4b30:      	cmp	x14, #0x52
    4b34:      	b.eq	0x4c8c <_stogir.stack.validate+0x3f4>
    4b38:      	uxtb	w16, w20
    4b3c:      	cmp	w16, wzr
    4b40:      	b.ne	0x4c8c <_stogir.stack.validate+0x3f4>
    4b44:      	uxtb	w16, w21
    4b48:      	cmp	w16, wzr
    4b4c:      	b.ne	0x4c8c <_stogir.stack.validate+0x3f4>
    4b50:      	mov	x22, x8
    4b54:      	b	0x4990 <_stogir.stack.validate+0xf8>
    4b58:      	uxtb	w16, w9
    4b5c:      	cmp	w16, wzr
    4b60:      	b.eq	0x4ba4 <_stogir.stack.validate+0x30c>
    4b64:      	ldr	x1, [x3, #0x8]
    4b68:      	ldr	x2, [x4, #0x8]
    4b6c:      	cmp	x1, x2
    4b70:      	b.ne	0x4c7c <_stogir.stack.validate+0x3e4>
    4b74:      	cmp	x7, x1
    4b78:      	b.gt	0x4dcc <_stogir.stack.validate+0x534>
    4b7c:      	ldr	x1, [x0, #0x50]
    4b80:      	add	x1, x11, x1
    4b84:      	ldr	w1, [x1]
    4b88:      	sxtw	x1, w1
    4b8c:      	cmp	x1, #0x0
    4b90:      	cset	w1, gt
    4b94:      	ubfx	x1, x1, #0, #8
    4b98:      	b	0x4dd0 <_stogir.stack.validate+0x538>
    4b9c:      	movz	x1, #0x0, lsl #48
    4ba0:      	b	0x4ba8 <_stogir.stack.validate+0x310>
    4ba4:      	movz	x1, #0x0, lsl #48
    4ba8:      	cmp	x1, #0x0
    4bac:      	b.eq	0x4be0 <_stogir.stack.validate+0x348>
    4bb0:      	uxtb	w16, w6
    4bb4:      	cmp	w16, wzr
    4bb8:      	b.eq	0x4bcc <_stogir.stack.validate+0x334>
    4bbc:      	ldr	x1, [x0]
    4bc0:      	add	x1, x13, x1
    4bc4:      	ldr	x1, [x1]
    4bc8:      	b	0x4bd8 <_stogir.stack.validate+0x340>
    4bcc:      	ldr	x1, [x0, #0x28]
    4bd0:      	add	x1, x10, x1
    4bd4:      	ldr	x1, [x1]
    4bd8:      	mov	w2, #0x1                ; =1
    4bdc:      	b	0x4be8 <_stogir.stack.validate+0x350>
    4be0:      	movz	w2, #0x0, lsl #16
    4be4:      	movz	x1, #0x0, lsl #48
    4be8:      	ubfx	x2, x2, #0, #32
    4bec:      	lsr	x16, x2, #0
    4bf0:      	cmp	x16, #0x1
    4bf4:      	b.eq	0x4c10 <_stogir.stack.validate+0x378>
    4bf8:      	b.lo	0x4c00 <_stogir.stack.validate+0x368>
    4bfc:      	b	0x4c14 <_stogir.stack.validate+0x37c>
    4c00:      	cmp	x16, #0x0
    4c04:      	b.eq	0x4c0c <_stogir.stack.validate+0x374>
    4c08:      	b	0x4c14 <_stogir.stack.validate+0x37c>
    4c0c:      	b	0x4c18 <_stogir.stack.validate+0x380>
    4c10:      	b	0x4c2c <_stogir.stack.validate+0x394>
    4c14:      	b	0x4e2c <_stogir.stack.validate+0x594>
    4c18:      	mov	x0, #0x1                ; =1
    4c1c:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004c1c:  ARM64_RELOC_PAGE21	l_stogir.394
    4c20:      	ldr	x1, [x1]
		0000000000004c20:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    4c24:      	mov	x2, #0x21               ; =33
    4c28:      	b	0x4b04 <_stogir.stack.validate+0x26c>
    4c2c:      	uxtb	w16, w15
    4c30:      	cmp	w16, wzr
    4c34:      	b.ne	0x4af4 <_stogir.stack.validate+0x25c>
    4c38:      	uxtb	w2, w1
    4c3c:      	cmp	x2, #0x42
    4c40:      	b.ne	0x4af4 <_stogir.stack.validate+0x25c>
    4c44:      	ubfx	x1, x1, #0, #32
    4c48:      	ubfx	x1, x1, #8, #8
    4c4c:      	cmp	x1, #0x6
    4c50:      	b.ne	0x4af4 <_stogir.stack.validate+0x25c>
    4c54:      	ldr	x0, [x0, #0x78]
    4c58:      	add	x0, x5, x0
    4c5c:      	ldr	w0, [x0]
    4c60:      	sxtw	x0, w0
    4c64:      	cmp	x0, #0x0
    4c68:      	b.ne	0x4af4 <_stogir.stack.validate+0x25c>
    4c6c:      	movz	x0, #0x0, lsl #48
    4c70:      	mov	x1, #0x8                ; =8
    4c74:      	movz	x2, #0x0, lsl #48
    4c78:      	b	0x4b04 <_stogir.stack.validate+0x26c>
    4c7c:      	movz	x1, #0x0, lsl #48
    4c80:      	b	0x4ba8 <_stogir.stack.validate+0x310>
    4c84:      	movz	x1, #0x0, lsl #48
    4c88:      	b	0x4ba0 <_stogir.stack.validate+0x308>
    4c8c:      	ldr	x2, [x0, #0x78]
    4c90:      	add	x2, x5, x2
    4c94:      	ldr	w2, [x2]
    4c98:      	uxtb	w16, w1
    4c9c:      	cmp	w16, wzr
    4ca0:      	b.eq	0x4d00 <_stogir.stack.validate+0x468>
    4ca4:      	mov	w1, #0x3                ; =3
    4ca8:      	b	0x4d14 <_stogir.stack.validate+0x47c>
    4cac:      	add	x16, sp, #0x10
    4cb0:      	ldr	w0, [x16]
    4cb4:      	add	x16, sp, #0x10
    4cb8:      	ldr	w1, [x16, #0x4]
    4cbc:      	add	x16, sp, #0x10
    4cc0:      	ldr	w2, [x16, #0x8]
    4cc4:      	ubfx	x0, x0, #8, #8
    4cc8:      	add	x8, sp, #0x20
    4ccc:      	mov	w3, w1
    4cd0:      	mov	w1, w19
    4cd4:      	mov	w4, w2
    4cd8:      	mov	w2, w0
    4cdc:      	mov	x0, x23
    4ce0:      	bl	0x4ce0 <_stogir.stack.validate+0x448>
		0000000000004ce0:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    4ce4:      	add	x16, sp, #0x20
    4ce8:      	ldr	x0, [x16]
    4cec:      	add	x16, sp, #0x20
    4cf0:      	ldr	x1, [x16, #0x8]
    4cf4:      	add	x16, sp, #0x20
    4cf8:      	ldr	x2, [x16, #0x10]
    4cfc:      	b	0x49a0 <_stogir.stack.validate+0x108>
    4d00:      	uxtb	w16, w20
    4d04:      	cmp	w16, wzr
    4d08:      	mov	w16, #0x1               ; =1
    4d0c:      	mov	w17, #0x2               ; =2
    4d10:      	csel	w1, w16, w17, ne
    4d14:      	sxtw	x2, w2
    4d18:      	sxtw	x1, w1
    4d1c:      	cmp	x2, x1
    4d20:      	b.ne	0x4e34 <_stogir.stack.validate+0x59c>
    4d24:      	add	x16, sp, #0x10
    4d28:      	ldr	w1, [x16]
    4d2c:      	orr	x2, x1, xzr
    4d30:      	ubfx	x2, x2, #16, #16
    4d34:      	uxth	w16, w2
    4d38:      	and	w2, w16, #0x8000
    4d3c:      	uxth	w2, w2
    4d40:      	ubfx	x2, x2, #0, #16
    4d44:      	cmp	x2, #0x0
    4d48:      	b.ne	0x4dd4 <_stogir.stack.validate+0x53c>
    4d4c:      	mov	x22, x8
    4d50:      	mov	x23, x0
    4d54:      	uxtb	w16, w20
    4d58:      	cmp	w16, wzr
    4d5c:      	b.ne	0x4cac <_stogir.stack.validate+0x414>
    4d60:      	uxtb	w16, w21
    4d64:      	cmp	w16, wzr
    4d68:      	b.ne	0x4cac <_stogir.stack.validate+0x414>
    4d6c:      	add	x16, sp, #0x10
    4d70:      	ldr	w0, [x16]
    4d74:      	add	x16, sp, #0x10
    4d78:      	ldr	w1, [x16, #0x4]
    4d7c:      	add	x16, sp, #0x10
    4d80:      	ldr	w2, [x16, #0x8]
    4d84:      	ubfx	x0, x0, #8, #8
    4d88:      	add	x16, sp, #0x10
    4d8c:      	ldr	w3, [x16, #0xc]
    4d90:      	add	x8, sp, #0x40
    4d94:      	mov	w4, w2
    4d98:      	mov	w2, w0
    4d9c:      	mov	x0, x23
    4da0:      	mov	w5, w3
    4da4:      	mov	w3, w1
    4da8:      	mov	w1, w19
    4dac:      	bl	0x4dac <_stogir.stack.validate+0x514>
		0000000000004dac:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    4db0:      	add	x16, sp, #0x40
    4db4:      	ldr	x0, [x16]
    4db8:      	add	x16, sp, #0x40
    4dbc:      	ldr	x1, [x16, #0x8]
    4dc0:      	add	x16, sp, #0x40
    4dc4:      	ldr	x2, [x16, #0x10]
    4dc8:      	b	0x4cfc <_stogir.stack.validate+0x464>
    4dcc:      	movz	x1, #0x0, lsl #48
    4dd0:      	b	0x4c80 <_stogir.stack.validate+0x3e8>
    4dd4:      	uxtb	w2, w1
    4dd8:      	cmp	x2, #0x51
    4ddc:      	b.ne	0x4e3c <_stogir.stack.validate+0x5a4>
    4de0:      	ubfx	x1, x1, #16, #16
    4de4:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    4de8:      	b.ne	0x4e44 <_stogir.stack.validate+0x5ac>
    4dec:      	add	x16, sp, #0x10
    4df0:      	ldr	w1, [x16, #0x4]
    4df4:      	add	x16, sp, #0x10
    4df8:      	ldr	w2, [x16, #0x8]
    4dfc:      	mov	x22, x8
    4e00:      	mov	x23, x0
    4e04:      	bl	0x4e04 <_stogir.stack.validate+0x56c>
		0000000000004e04:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    4e08:      	cmp	x0, #0x0
    4e0c:      	b.ne	0x4d54 <_stogir.stack.validate+0x4bc>
    4e10:      	mov	x0, #0x1                ; =1
    4e14:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004e14:  ARM64_RELOC_PAGE21	l_stogir.395
    4e18:      	ldr	x1, [x1]
		0000000000004e18:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    4e1c:      	mov	x2, #0x26               ; =38
    4e20:      	b	0x4cfc <_stogir.stack.validate+0x464>
    4e24:      	brk	#0
    4e28:      	b	0x4e24 <_stogir.stack.validate+0x58c>
    4e2c:      	brk	#0
    4e30:      	b	0x4e2c <_stogir.stack.validate+0x594>
    4e34:      	mov	x22, x8
    4e38:      	b	0x4990 <_stogir.stack.validate+0xf8>
    4e3c:      	mov	x22, x8
    4e40:      	b	0x4e10 <_stogir.stack.validate+0x578>
    4e44:      	mov	x22, x8
    4e48:      	b	0x4e10 <_stogir.stack.validate+0x578>

0000000000004e4c <_stogir.locals.validate>:
    4e4c:      	sub	sp, sp, #0xc0
    4e50:      	str	x29, [sp]
    4e54:      	str	x30, [sp, #0x8]
    4e58:      	mov	x29, sp
    4e5c:      	str	x19, [sp, #0x70]
    4e60:      	str	x20, [sp, #0x78]
    4e64:      	str	x21, [sp, #0x80]
    4e68:      	str	x22, [sp, #0x88]
    4e6c:      	str	x23, [sp, #0x90]
    4e70:      	str	x24, [sp, #0x98]
    4e74:      	str	x25, [sp, #0xa0]
    4e78:      	str	x26, [sp, #0xa8]
    4e7c:      	str	x27, [sp, #0xb0]
    4e80:      	str	x28, [sp, #0xb8]
    4e84:      	sxtw	x1, w1
    4e88:      	add	x19, x0, #0x78
    4e8c:      	add	x20, x0, #0x28
    4e90:      	add	x21, x0, #0x50
    4e94:      	lsl	x3, x1, #2
    4e98:      	cmp	x1, #0x0
    4e9c:      	cset	w4, gt
    4ea0:      	movz	x16, #0x0, lsl #48
    4ea4:      	sub	x5, x16, x1
    4ea8:      	sub	x6, x5, #0x1
    4eac:      	uxtb	w16, w4
    4eb0:      	cmp	w16, wzr
    4eb4:      	b.eq	0x4ef0 <_stogir.locals.validate+0xa4>
    4eb8:      	ldr	x5, [x0, #0x8]
    4ebc:      	cmp	x1, x5
    4ec0:      	b.ge	0x4f74 <_stogir.locals.validate+0x128>
    4ec4:      	ldr	x5, [x19, #0x8]
    4ec8:      	cmp	x1, x5
    4ecc:      	b.ge	0x5078 <_stogir.locals.validate+0x22c>
    4ed0:      	ldr	x5, [x0, #0x78]
    4ed4:      	add	x5, x3, x5
    4ed8:      	ldr	w5, [x5]
    4edc:      	sxtw	x5, w5
    4ee0:      	cmp	x5, #0x0
    4ee4:      	cset	w5, ge
    4ee8:      	ubfx	x5, x5, #0, #8
    4eec:      	b	0x507c <_stogir.locals.validate+0x230>
    4ef0:      	cmp	x1, #0x0
    4ef4:      	b.ge	0x4f7c <_stogir.locals.validate+0x130>
    4ef8:      	ldr	x7, [x20, #0x8]
    4efc:      	ldr	x9, [x21, #0x8]
    4f00:      	cmp	x7, x9
    4f04:      	b.ne	0x4f30 <_stogir.locals.validate+0xe4>
    4f08:      	cmp	x5, x7
    4f0c:      	b.gt	0x50fc <_stogir.locals.validate+0x2b0>
    4f10:      	ldr	x5, [x0, #0x50]
    4f14:      	add	x5, x5, x6, lsl #2
    4f18:      	ldr	w5, [x5]
    4f1c:      	sxtw	x5, w5
    4f20:      	cmp	x5, #0x0
    4f24:      	cset	w5, gt
    4f28:      	ubfx	x5, x5, #0, #8
    4f2c:      	b	0x5100 <_stogir.locals.validate+0x2b4>
    4f30:      	movz	x5, #0x0, lsl #48
    4f34:      	b	0x4f80 <_stogir.locals.validate+0x134>
    4f38:      	cmp	x4, #0x0
    4f3c:      	cset	w4, ne
    4f40:      	uxtb	w16, w4
    4f44:      	cmp	w16, wzr
    4f48:      	mov	w16, #0x2               ; =2
    4f4c:      	mov	w17, #0x3               ; =3
    4f50:      	csel	w4, w16, w17, ne
    4f54:      	cmp	x1, #0x0
    4f58:      	b.gt	0x5080 <_stogir.locals.validate+0x234>
    4f5c:      	mov	x26, x8
    4f60:      	mov	x2, #0x1                ; =1
    4f64:      	adrp	x1, 0x4000 <_stogir.atomic.validate+0x4e0>
		0000000000004f64:  ARM64_RELOC_PAGE21	l_stogir.396
    4f68:      	ldr	x1, [x1]
		0000000000004f68:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    4f6c:      	mov	x0, #0x17               ; =23
    4f70:      	b	0x5010 <_stogir.locals.validate+0x1c4>
    4f74:      	movz	x5, #0x0, lsl #48
    4f78:      	b	0x4f80 <_stogir.locals.validate+0x134>
    4f7c:      	movz	x5, #0x0, lsl #48
    4f80:      	cmp	x5, #0x0
    4f84:      	b.eq	0x4fc0 <_stogir.locals.validate+0x174>
    4f88:      	uxtb	w16, w4
    4f8c:      	cmp	w16, wzr
    4f90:      	b.eq	0x4fa8 <_stogir.locals.validate+0x15c>
    4f94:      	ldr	x4, [x0]
    4f98:      	add	x4, x4, x1, lsl #4
    4f9c:      	ldr	x5, [x4]
    4fa0:      	ldr	x4, [x4, #0x8]
    4fa4:      	b	0x4fb8 <_stogir.locals.validate+0x16c>
    4fa8:      	ldr	x4, [x0, #0x28]
    4fac:      	add	x4, x4, x6, lsl #4
    4fb0:      	ldr	x5, [x4]
    4fb4:      	ldr	x4, [x4, #0x8]
    4fb8:      	mov	w6, #0x1                ; =1
    4fbc:      	b	0x4fcc <_stogir.locals.validate+0x180>
    4fc0:      	movz	w6, #0x0, lsl #16
    4fc4:      	movz	x5, #0x0, lsl #48
    4fc8:      	movz	x4, #0x0, lsl #48
    4fcc:      	ubfx	x6, x6, #0, #32
    4fd0:      	lsr	x16, x6, #0
    4fd4:      	cmp	x16, #0x1
    4fd8:      	b.eq	0x4ff4 <_stogir.locals.validate+0x1a8>
    4fdc:      	b.lo	0x4fe4 <_stogir.locals.validate+0x198>
    4fe0:      	b	0x4ff8 <_stogir.locals.validate+0x1ac>
    4fe4:      	cmp	x16, #0x0
    4fe8:      	b.eq	0x4ff0 <_stogir.locals.validate+0x1a4>
    4fec:      	b	0x4ff8 <_stogir.locals.validate+0x1ac>
    4ff0:      	b	0x4ffc <_stogir.locals.validate+0x1b0>
    4ff4:      	b	0x5054 <_stogir.locals.validate+0x208>
    4ff8:      	b	0x5224 <_stogir.locals.validate+0x3d8>
    4ffc:      	mov	x26, x8
    5000:      	mov	x2, #0x1                ; =1
    5004:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005004:  ARM64_RELOC_PAGE21	l_stogir.397
    5008:      	ldr	x1, [x1]
		0000000000005008:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    500c:      	mov	x0, #0x17               ; =23
    5010:      	str	x2, [x26]
    5014:      	str	x1, [x26, #0x8]
    5018:      	str	x0, [x26, #0x10]
    501c:      	ldr	x19, [sp, #0x70]
    5020:      	ldr	x20, [sp, #0x78]
    5024:      	ldr	x21, [sp, #0x80]
    5028:      	ldr	x22, [sp, #0x88]
    502c:      	ldr	x23, [sp, #0x90]
    5030:      	ldr	x24, [sp, #0x98]
    5034:      	ldr	x25, [sp, #0xa0]
    5038:      	ldr	x26, [sp, #0xa8]
    503c:      	ldr	x27, [sp, #0xb0]
    5040:      	ldr	x28, [sp, #0xb8]
    5044:      	ldr	x29, [sp]
    5048:      	ldr	x30, [sp, #0x8]
    504c:      	add	sp, sp, #0xc0
    5050:      	ret
    5054:      	uxtb	w6, w5
    5058:      	add	x16, sp, #0x10
    505c:      	str	x5, [x16]
    5060:      	add	x16, sp, #0x10
    5064:      	str	x4, [x16, #0x8]
    5068:      	cmp	x6, #0x55
    506c:      	b.ne	0x50e0 <_stogir.locals.validate+0x294>
    5070:      	mov	x4, #0x1                ; =1
    5074:      	b	0x50ec <_stogir.locals.validate+0x2a0>
    5078:      	movz	x5, #0x0, lsl #48
    507c:      	b	0x4f78 <_stogir.locals.validate+0x12c>
    5080:      	cmp	x6, #0x48
    5084:      	cset	w24, eq
    5088:      	uxtb	w16, w23
    508c:      	cmp	w16, wzr
    5090:      	b.ne	0x5104 <_stogir.locals.validate+0x2b8>
    5094:      	uxtb	w16, w24
    5098:      	cmp	w16, wzr
    509c:      	b.ne	0x5104 <_stogir.locals.validate+0x2b8>
    50a0:      	cmp	x6, #0x55
    50a4:      	b.lt	0x555c <_stogir.locals.validate+0x710>
    50a8:      	cmp	x6, #0x58
    50ac:      	b.le	0x5104 <_stogir.locals.validate+0x2b8>
    50b0:      	mov	x26, x8
    50b4:      	b	0x4f60 <_stogir.locals.validate+0x114>
    50b8:      	cmp	x6, #0x58
    50bc:      	cset	w5, eq
    50c0:      	ubfx	x22, x5, #0, #8
    50c4:      	cmp	x6, #0x41
    50c8:      	cset	w23, eq
    50cc:      	uxtb	w16, w23
    50d0:      	cmp	w16, wzr
    50d4:      	b.eq	0x4f38 <_stogir.locals.validate+0xec>
    50d8:      	mov	w4, #0x1                ; =1
    50dc:      	b	0x4f54 <_stogir.locals.validate+0x108>
    50e0:      	cmp	x6, #0x56
    50e4:      	cset	w4, eq
    50e8:      	ubfx	x4, x4, #0, #8
    50ec:      	cmp	x6, #0x57
    50f0:      	b.ne	0x50b8 <_stogir.locals.validate+0x26c>
    50f4:      	mov	x22, #0x1               ; =1
    50f8:      	b	0x50c4 <_stogir.locals.validate+0x278>
    50fc:      	movz	x5, #0x0, lsl #48
    5100:      	b	0x4f34 <_stogir.locals.validate+0xe8>
    5104:      	sxtw	x4, w4
    5108:      	ldr	x5, [x0, #0x78]
    510c:      	add	x3, x3, x5
    5110:      	ldr	w3, [x3]
    5114:      	sxtw	x3, w3
    5118:      	cmp	x3, x4
    511c:      	b.ne	0x5564 <_stogir.locals.validate+0x718>
    5120:      	uxtb	w16, w23
    5124:      	cmp	w16, wzr
    5128:      	b.ne	0x5148 <_stogir.locals.validate+0x2fc>
    512c:      	uxtb	w16, w24
    5130:      	cmp	w16, wzr
    5134:      	b.ne	0x5148 <_stogir.locals.validate+0x2fc>
    5138:      	add	x16, sp, #0x10
    513c:      	ldr	w1, [x16, #0x8]
    5140:      	sxtw	x1, w1
    5144:      	b	0x5160 <_stogir.locals.validate+0x314>
    5148:      	uxtb	w16, w24
    514c:      	cmp	w16, wzr
    5150:      	b.ne	0x5160 <_stogir.locals.validate+0x314>
    5154:      	add	x16, sp, #0x10
    5158:      	ldr	w1, [x16, #0x4]
    515c:      	sxtw	x1, w1
    5160:      	add	x16, sp, #0x20
    5164:      	orr	x25, x16, xzr
    5168:      	mov	x26, x8
    516c:      	add	x8, sp, #0x20
    5170:      	mov	x27, x0
    5174:      	mov	w28, w2
    5178:      	bl	0x5178 <_stogir.locals.validate+0x32c>
		0000000000005178:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    517c:      	add	x16, sp, #0x20
    5180:      	ldr	w0, [x16]
    5184:      	lsr	x16, x0, #0
    5188:      	cmp	x16, #0x1
    518c:      	b.eq	0x51a8 <_stogir.locals.validate+0x35c>
    5190:      	b.lo	0x5198 <_stogir.locals.validate+0x34c>
    5194:      	b	0x51ac <_stogir.locals.validate+0x360>
    5198:      	cmp	x16, #0x0
    519c:      	b.eq	0x51a4 <_stogir.locals.validate+0x358>
    51a0:      	b	0x51ac <_stogir.locals.validate+0x360>
    51a4:      	b	0x51c8 <_stogir.locals.validate+0x37c>
    51a8:      	b	0x51b0 <_stogir.locals.validate+0x364>
    51ac:      	b	0x53e0 <_stogir.locals.validate+0x594>
    51b0:      	add	x0, x25, #0x8
    51b4:      	add	x16, sp, #0x20
    51b8:      	ldr	x1, [x16, #0x8]
    51bc:      	ldr	x0, [x0, #0x8]
    51c0:      	mov	x2, #0x1                ; =1
    51c4:      	b	0x4f70 <_stogir.locals.validate+0x124>
    51c8:      	add	x16, sp, #0x20
    51cc:      	ldr	x25, [x16, #0x8]
    51d0:      	uxtb	w16, w24
    51d4:      	cmp	w16, wzr
    51d8:      	b.eq	0x51f0 <_stogir.locals.validate+0x3a4>
    51dc:      	sxtw	x25, w25
    51e0:      	and	x1, x25, #0xffffffff
    51e4:      	movz	x2, #0x0, lsl #48
    51e8:      	movz	x0, #0x0, lsl #48
    51ec:      	b	0x51c4 <_stogir.locals.validate+0x378>
    51f0:      	uxtb	w16, w23
    51f4:      	cmp	w16, wzr
    51f8:      	b.eq	0x5240 <_stogir.locals.validate+0x3f4>
    51fc:      	add	x16, sp, #0x10
    5200:      	ldr	w0, [x16]
    5204:      	ubfx	x0, x0, #8, #8
    5208:      	cmp	x0, #0x6
    520c:      	b.ne	0x522c <_stogir.locals.validate+0x3e0>
    5210:      	sxtw	x28, w28
    5214:      	and	x1, x28, #0xffffffff
    5218:      	movz	x2, #0x0, lsl #48
    521c:      	movz	x0, #0x0, lsl #48
    5220:      	b	0x523c <_stogir.locals.validate+0x3f0>
    5224:      	brk	#0
    5228:      	b	0x5224 <_stogir.locals.validate+0x3d8>
    522c:      	mov	x2, #0x1                ; =1
    5230:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005230:  ARM64_RELOC_PAGE21	l_stogir.398
    5234:      	ldr	x1, [x1]
		0000000000005234:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    5238:      	mov	x0, #0x21               ; =33
    523c:      	b	0x51ec <_stogir.locals.validate+0x3a0>
    5240:      	add	x16, sp, #0x10
    5244:      	ldr	w0, [x16, #0x4]
    5248:      	sxtw	x0, w0
    524c:      	cmp	x0, #0x0
    5250:      	cset	w1, gt
    5254:      	movz	x16, #0x0, lsl #48
    5258:      	sub	x2, x16, x0
    525c:      	sub	x3, x2, #0x1
    5260:      	uxtb	w16, w1
    5264:      	cmp	w16, wzr
    5268:      	b.eq	0x5334 <_stogir.locals.validate+0x4e8>
    526c:      	ldr	x2, [x27, #0x8]
    5270:      	cmp	x0, x2
    5274:      	b.ge	0x532c <_stogir.locals.validate+0x4e0>
    5278:      	ldr	x2, [x19, #0x8]
    527c:      	cmp	x0, x2
    5280:      	b.ge	0x53d0 <_stogir.locals.validate+0x584>
    5284:      	ldr	x2, [x27, #0x78]
    5288:      	add	x2, x2, x0, lsl #2
    528c:      	ldr	w2, [x2]
    5290:      	sxtw	x2, w2
    5294:      	cmp	x2, #0x0
    5298:      	cset	w2, ge
    529c:      	ubfx	x2, x2, #0, #8
    52a0:      	b	0x53d4 <_stogir.locals.validate+0x588>
    52a4:      	movz	w1, #0x0, lsl #16
    52a8:      	movz	x0, #0x0, lsl #48
    52ac:      	ubfx	x1, x1, #0, #32
    52b0:      	lsr	x16, x1, #0
    52b4:      	cmp	x16, #0x1
    52b8:      	b.eq	0x52d4 <_stogir.locals.validate+0x488>
    52bc:      	b.lo	0x52c4 <_stogir.locals.validate+0x478>
    52c0:      	b	0x52d8 <_stogir.locals.validate+0x48c>
    52c4:      	cmp	x16, #0x0
    52c8:      	b.eq	0x52d0 <_stogir.locals.validate+0x484>
    52cc:      	b	0x52d8 <_stogir.locals.validate+0x48c>
    52d0:      	b	0x52dc <_stogir.locals.validate+0x490>
    52d4:      	b	0x5374 <_stogir.locals.validate+0x528>
    52d8:      	b	0x5530 <_stogir.locals.validate+0x6e4>
    52dc:      	mov	x2, #0x1                ; =1
    52e0:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		00000000000052e0:  ARM64_RELOC_PAGE21	l_stogir.399
    52e4:      	ldr	x1, [x1]
		00000000000052e4:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    52e8:      	mov	x0, #0x1c               ; =28
    52ec:      	b	0x523c <_stogir.locals.validate+0x3f0>
    52f0:      	ldr	x0, [x27, #0x28]
    52f4:      	add	x0, x0, x3, lsl #4
    52f8:      	ldr	x0, [x0]
    52fc:      	mov	w1, #0x1                ; =1
    5300:      	b	0x52ac <_stogir.locals.validate+0x460>
    5304:      	movz	x2, #0x0, lsl #48
    5308:      	cmp	x2, #0x0
    530c:      	b.eq	0x52a4 <_stogir.locals.validate+0x458>
    5310:      	uxtb	w16, w1
    5314:      	cmp	w16, wzr
    5318:      	b.eq	0x52f0 <_stogir.locals.validate+0x4a4>
    531c:      	ldr	x1, [x27]
    5320:      	add	x0, x1, x0, lsl #4
    5324:      	ldr	x0, [x0]
    5328:      	b	0x52fc <_stogir.locals.validate+0x4b0>
    532c:      	movz	x2, #0x0, lsl #48
    5330:      	b	0x5308 <_stogir.locals.validate+0x4bc>
    5334:      	cmp	x0, #0x0
    5338:      	b.ge	0x5304 <_stogir.locals.validate+0x4b8>
    533c:      	ldr	x4, [x20, #0x8]
    5340:      	ldr	x5, [x21, #0x8]
    5344:      	cmp	x4, x5
    5348:      	b.ne	0x53c8 <_stogir.locals.validate+0x57c>
    534c:      	cmp	x2, x4
    5350:      	b.gt	0x53d8 <_stogir.locals.validate+0x58c>
    5354:      	ldr	x2, [x27, #0x50]
    5358:      	add	x2, x2, x3, lsl #2
    535c:      	ldr	w2, [x2]
    5360:      	sxtw	x2, w2
    5364:      	cmp	x2, #0x0
    5368:      	cset	w2, gt
    536c:      	ubfx	x2, x2, #0, #8
    5370:      	b	0x53dc <_stogir.locals.validate+0x590>
    5374:      	add	x16, sp, #0x10
    5378:      	ldr	w1, [x16, #0x4]
    537c:      	sxtw	x1, w1
    5380:      	cmp	x1, #0x0
    5384:      	b.le	0x53b4 <_stogir.locals.validate+0x568>
    5388:      	uxtb	w0, w0
    538c:      	cmp	x0, #0x83
    5390:      	cset	w1, lt
    5394:      	uxtb	w16, w1
    5398:      	cmp	w16, wzr
    539c:      	b.eq	0x53e8 <_stogir.locals.validate+0x59c>
    53a0:      	adrp	x17, 0x5000 <_stogir.locals.validate+0x1b4>
		00000000000053a0:  ARM64_RELOC_PAGE21	l_stogir.400
    53a4:      	ldr	x17, [x17]
		00000000000053a4:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    53a8:      	add	x2, x0, x17
    53ac:      	ldrb	w2, [x2]
    53b0:      	b	0x53ec <_stogir.locals.validate+0x5a0>
    53b4:      	mov	x2, #0x1                ; =1
    53b8:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		00000000000053b8:  ARM64_RELOC_PAGE21	l_stogir.401
    53bc:      	ldr	x1, [x1]
		00000000000053bc:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    53c0:      	mov	x0, #0x1c               ; =28
    53c4:      	b	0x52ec <_stogir.locals.validate+0x4a0>
    53c8:      	movz	x2, #0x0, lsl #48
    53cc:      	b	0x5308 <_stogir.locals.validate+0x4bc>
    53d0:      	movz	x2, #0x0, lsl #48
    53d4:      	b	0x5330 <_stogir.locals.validate+0x4e4>
    53d8:      	movz	x2, #0x0, lsl #48
    53dc:      	b	0x53cc <_stogir.locals.validate+0x580>
    53e0:      	brk	#0
    53e4:      	b	0x53e0 <_stogir.locals.validate+0x594>
    53e8:      	movz	w2, #0x0, lsl #16
    53ec:      	uxtb	w16, w2
    53f0:      	and	w2, w16, #0x1
    53f4:      	uxtb	w2, w2
    53f8:      	ubfx	x2, x2, #0, #8
    53fc:      	cmp	x2, #0x0
    5400:      	b.eq	0x53b4 <_stogir.locals.validate+0x568>
    5404:      	uxtb	w16, w1
    5408:      	cmp	w16, wzr
    540c:      	b.eq	0x5424 <_stogir.locals.validate+0x5d8>
    5410:      	adrp	x17, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005410:  ARM64_RELOC_PAGE21	l_stogir.400
    5414:      	ldr	x17, [x17]
		0000000000005414:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    5418:      	add	x0, x0, x17
    541c:      	ldrb	w0, [x0]
    5420:      	b	0x5428 <_stogir.locals.validate+0x5dc>
    5424:      	movz	w0, #0x0, lsl #16
    5428:      	uxtb	w16, w0
    542c:      	and	w0, w16, #0x4
    5430:      	uxtb	w0, w0
    5434:      	ubfx	x0, x0, #0, #8
    5438:      	cmp	x0, #0x0
    543c:      	cset	w0, eq
    5440:      	uxtb	w16, w0
    5444:      	cmp	w16, wzr
    5448:      	cset	x0, eq
    544c:      	cmp	x0, #0x0
    5450:      	b.ne	0x53b4 <_stogir.locals.validate+0x568>
    5454:      	cmp	x22, #0x0
    5458:      	b.eq	0x54e0 <_stogir.locals.validate+0x694>
    545c:      	add	x16, sp, #0x10
    5460:      	ldr	w0, [x16, #0xc]
    5464:      	add	x8, sp, #0x40
    5468:      	mov	w1, w0
    546c:      	mov	x0, x27
    5470:      	bl	0x5470 <_stogir.locals.validate+0x624>
		0000000000005470:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    5474:      	add	x16, sp, #0x40
    5478:      	ldr	x0, [x16]
    547c:      	add	x16, sp, #0x40
    5480:      	ldr	x19, [x16, #0x8]
    5484:      	b	0x54ec <_stogir.locals.validate+0x6a0>
    5488:      	orr	w0, w19, wzr
    548c:      	ubfx	x0, x0, #0, #32
    5490:      	ubfx	x0, x0, #8, #8
    5494:      	mov	w1, w28
    5498:      	bl	0x5498 <_stogir.locals.validate+0x64c>
		0000000000005498:  ARM64_RELOC_BRANCH26	_stogir.types.size
    549c:      	sxtw	x0, w0
    54a0:      	cmp	x0, #0x0
    54a4:      	b.le	0x54cc <_stogir.locals.validate+0x680>
    54a8:      	cmp	x0, x25
    54ac:      	b.gt	0x54cc <_stogir.locals.validate+0x680>
    54b0:      	cmp	x22, #0x0
    54b4:      	b.eq	0x5538 <_stogir.locals.validate+0x6ec>
    54b8:      	add	x16, sp, #0x10
    54bc:      	ldr	w1, [x16]
    54c0:      	ubfx	x1, x1, #8, #8
    54c4:      	cmp	x1, #0x0
    54c8:      	b.eq	0x5538 <_stogir.locals.validate+0x6ec>
    54cc:      	mov	x2, #0x1                ; =1
    54d0:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		00000000000054d0:  ARM64_RELOC_PAGE21	l_stogir.402
    54d4:      	ldr	x1, [x1]
		00000000000054d4:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    54d8:      	mov	x0, #0x23               ; =35
    54dc:      	b	0x53c4 <_stogir.locals.validate+0x578>
    54e0:      	add	x16, sp, #0x10
    54e4:      	ldr	x19, [x16]
    54e8:      	mov	x0, #0x1                ; =1
    54ec:      	ubfx	x0, x0, #0, #32
    54f0:      	lsr	x16, x0, #0
    54f4:      	cmp	x16, #0x1
    54f8:      	b.eq	0x5514 <_stogir.locals.validate+0x6c8>
    54fc:      	b.lo	0x5504 <_stogir.locals.validate+0x6b8>
    5500:      	b	0x5518 <_stogir.locals.validate+0x6cc>
    5504:      	cmp	x16, #0x0
    5508:      	b.eq	0x5510 <_stogir.locals.validate+0x6c4>
    550c:      	b	0x5518 <_stogir.locals.validate+0x6cc>
    5510:      	b	0x551c <_stogir.locals.validate+0x6d0>
    5514:      	b	0x5488 <_stogir.locals.validate+0x63c>
    5518:      	b	0x5554 <_stogir.locals.validate+0x708>
    551c:      	mov	x2, #0x1                ; =1
    5520:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005520:  ARM64_RELOC_PAGE21	l_stogir.403
    5524:      	ldr	x1, [x1]
		0000000000005524:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    5528:      	mov	x0, #0x19               ; =25
    552c:      	b	0x54dc <_stogir.locals.validate+0x690>
    5530:      	brk	#0
    5534:      	b	0x5530 <_stogir.locals.validate+0x6e4>
    5538:      	uxtb	w19, w19
    553c:      	cmp	x19, #0x48
    5540:      	b.eq	0x54cc <_stogir.locals.validate+0x680>
    5544:      	and	x1, x0, #0xffffffff
    5548:      	movz	x2, #0x0, lsl #48
    554c:      	movz	x0, #0x0, lsl #48
    5550:      	b	0x54dc <_stogir.locals.validate+0x690>
    5554:      	brk	#0
    5558:      	b	0x5554 <_stogir.locals.validate+0x708>
    555c:      	mov	x26, x8
    5560:      	b	0x4f60 <_stogir.locals.validate+0x114>
    5564:      	mov	x26, x8
    5568:      	b	0x4f60 <_stogir.locals.validate+0x114>

000000000000556c <_stogir.conversion.validate>:
    556c:      	sub	sp, sp, #0x40
    5570:      	str	x29, [sp]
    5574:      	str	x30, [sp, #0x8]
    5578:      	mov	x29, sp
    557c:      	str	x19, [sp, #0x30]
    5580:      	sxtw	x1, w1
    5584:      	add	x3, x0, #0x78
    5588:      	add	x4, x0, #0x28
    558c:      	add	x5, x0, #0x50
    5590:      	lsl	x6, x1, #2
    5594:      	cmp	x1, #0x0
    5598:      	cset	w7, gt
    559c:      	movz	x16, #0x0, lsl #48
    55a0:      	sub	x9, x16, x1
    55a4:      	sub	x10, x9, #0x1
    55a8:      	uxtb	w16, w7
    55ac:      	cmp	w16, wzr
    55b0:      	b.eq	0x55ec <_stogir.conversion.validate+0x80>
    55b4:      	ldr	x9, [x0, #0x8]
    55b8:      	cmp	x1, x9
    55bc:      	b.ge	0x5634 <_stogir.conversion.validate+0xc8>
    55c0:      	ldr	x9, [x3, #0x8]
    55c4:      	cmp	x1, x9
    55c8:      	b.ge	0x5704 <_stogir.conversion.validate+0x198>
    55cc:      	ldr	x9, [x0, #0x78]
    55d0:      	add	x9, x6, x9
    55d4:      	ldr	w9, [x9]
    55d8:      	sxtw	x9, w9
    55dc:      	cmp	x9, #0x0
    55e0:      	cset	w9, ge
    55e4:      	ubfx	x9, x9, #0, #8
    55e8:      	b	0x5708 <_stogir.conversion.validate+0x19c>
    55ec:      	cmp	x1, #0x0
    55f0:      	b.ge	0x563c <_stogir.conversion.validate+0xd0>
    55f4:      	ldr	x11, [x4, #0x8]
    55f8:      	ldr	x12, [x5, #0x8]
    55fc:      	cmp	x11, x12
    5600:      	b.ne	0x562c <_stogir.conversion.validate+0xc0>
    5604:      	cmp	x9, x11
    5608:      	b.gt	0x5794 <_stogir.conversion.validate+0x228>
    560c:      	ldr	x9, [x0, #0x50]
    5610:      	add	x9, x9, x10, lsl #2
    5614:      	ldr	w9, [x9]
    5618:      	sxtw	x9, w9
    561c:      	cmp	x9, #0x0
    5620:      	cset	w9, gt
    5624:      	ubfx	x9, x9, #0, #8
    5628:      	b	0x5798 <_stogir.conversion.validate+0x22c>
    562c:      	movz	x9, #0x0, lsl #48
    5630:      	b	0x5640 <_stogir.conversion.validate+0xd4>
    5634:      	movz	x9, #0x0, lsl #48
    5638:      	b	0x5640 <_stogir.conversion.validate+0xd4>
    563c:      	movz	x9, #0x0, lsl #48
    5640:      	cmp	x9, #0x0
    5644:      	b.eq	0x5678 <_stogir.conversion.validate+0x10c>
    5648:      	uxtb	w16, w7
    564c:      	cmp	w16, wzr
    5650:      	b.eq	0x5664 <_stogir.conversion.validate+0xf8>
    5654:      	ldr	x7, [x0]
    5658:      	add	x7, x7, x1, lsl #4
    565c:      	ldr	x7, [x7]
    5660:      	b	0x5670 <_stogir.conversion.validate+0x104>
    5664:      	ldr	x7, [x0, #0x28]
    5668:      	add	x7, x7, x10, lsl #4
    566c:      	ldr	x7, [x7]
    5670:      	mov	w9, #0x1                ; =1
    5674:      	b	0x5680 <_stogir.conversion.validate+0x114>
    5678:      	movz	w9, #0x0, lsl #16
    567c:      	movz	x7, #0x0, lsl #48
    5680:      	ubfx	x9, x9, #0, #32
    5684:      	lsr	x16, x9, #0
    5688:      	cmp	x16, #0x1
    568c:      	b.eq	0x56a8 <_stogir.conversion.validate+0x13c>
    5690:      	b.lo	0x5698 <_stogir.conversion.validate+0x12c>
    5694:      	b	0x56ac <_stogir.conversion.validate+0x140>
    5698:      	cmp	x16, #0x0
    569c:      	b.eq	0x56a4 <_stogir.conversion.validate+0x138>
    56a0:      	b	0x56ac <_stogir.conversion.validate+0x140>
    56a4:      	b	0x56b0 <_stogir.conversion.validate+0x144>
    56a8:      	b	0x56e4 <_stogir.conversion.validate+0x178>
    56ac:      	b	0x5800 <_stogir.conversion.validate+0x294>
    56b0:      	mov	x19, x8
    56b4:      	mov	x0, #0x1                ; =1
    56b8:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		00000000000056b8:  ARM64_RELOC_PAGE21	l_stogir.404
    56bc:      	ldr	x1, [x1]
		00000000000056bc:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    56c0:      	mov	x2, #0x12               ; =18
    56c4:      	str	x0, [x19]
    56c8:      	str	x1, [x19, #0x8]
    56cc:      	str	x2, [x19, #0x10]
    56d0:      	ldr	x19, [sp, #0x30]
    56d4:      	ldr	x29, [sp]
    56d8:      	ldr	x30, [sp, #0x8]
    56dc:      	add	sp, sp, #0x40
    56e0:      	ret
    56e4:      	cmp	x1, #0x0
    56e8:      	b.gt	0x570c <_stogir.conversion.validate+0x1a0>
    56ec:      	mov	x19, x8
    56f0:      	mov	x0, #0x1                ; =1
    56f4:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		00000000000056f4:  ARM64_RELOC_PAGE21	l_stogir.405
    56f8:      	ldr	x1, [x1]
		00000000000056f8:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    56fc:      	mov	x2, #0x1e               ; =30
    5700:      	b	0x56c4 <_stogir.conversion.validate+0x158>
    5704:      	movz	x9, #0x0, lsl #48
    5708:      	b	0x5638 <_stogir.conversion.validate+0xcc>
    570c:      	uxtb	w1, w7
    5710:      	orr	x9, x1, xzr
    5714:      	cmp	x9, #0x21
    5718:      	b.lt	0x5914 <_stogir.conversion.validate+0x3a8>
    571c:      	cmp	x9, #0x27
    5720:      	b.gt	0x591c <_stogir.conversion.validate+0x3b0>
    5724:      	ldr	x9, [x0, #0x78]
    5728:      	add	x6, x6, x9
    572c:      	ldr	w6, [x6]
    5730:      	sxtw	x6, w6
    5734:      	cmp	x6, #0x1
    5738:      	b.ne	0x5924 <_stogir.conversion.validate+0x3b8>
    573c:      	asr	x6, x7, #32
    5740:      	cmp	x6, #0x0
    5744:      	cset	w10, gt
    5748:      	movz	x16, #0x0, lsl #48
    574c:      	sub	x11, x16, x6
    5750:      	sub	x12, x11, #0x1
    5754:      	uxtb	w16, w10
    5758:      	cmp	w16, wzr
    575c:      	b.eq	0x57c0 <_stogir.conversion.validate+0x254>
    5760:      	ldr	x4, [x0, #0x8]
    5764:      	cmp	x6, x4
    5768:      	b.ge	0x5808 <_stogir.conversion.validate+0x29c>
    576c:      	ldr	x3, [x3, #0x8]
    5770:      	cmp	x6, x3
    5774:      	b.ge	0x58a4 <_stogir.conversion.validate+0x338>
    5778:      	add	x3, x9, x6, lsl #2
    577c:      	ldr	w3, [x3]
    5780:      	sxtw	x3, w3
    5784:      	cmp	x3, #0x0
    5788:      	cset	w3, ge
    578c:      	ubfx	x3, x3, #0, #8
    5790:      	b	0x58a8 <_stogir.conversion.validate+0x33c>
    5794:      	movz	x9, #0x0, lsl #48
    5798:      	b	0x5630 <_stogir.conversion.validate+0xc4>
    579c:      	uxtb	w3, w0
    57a0:      	cmp	x3, #0x48
    57a4:      	b.ne	0x58ac <_stogir.conversion.validate+0x340>
    57a8:      	mov	x19, x8
    57ac:      	mov	x0, #0x1                ; =1
    57b0:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		00000000000057b0:  ARM64_RELOC_PAGE21	l_stogir.406
    57b4:      	ldr	x1, [x1]
		00000000000057b4:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    57b8:      	mov	x2, #0x25               ; =37
    57bc:      	b	0x5700 <_stogir.conversion.validate+0x194>
    57c0:      	cmp	x6, #0x0
    57c4:      	b.ge	0x5810 <_stogir.conversion.validate+0x2a4>
    57c8:      	ldr	x3, [x4, #0x8]
    57cc:      	ldr	x4, [x5, #0x8]
    57d0:      	cmp	x3, x4
    57d4:      	b.ne	0x589c <_stogir.conversion.validate+0x330>
    57d8:      	cmp	x11, x3
    57dc:      	b.gt	0x5904 <_stogir.conversion.validate+0x398>
    57e0:      	ldr	x3, [x0, #0x50]
    57e4:      	add	x3, x3, x12, lsl #2
    57e8:      	ldr	w3, [x3]
    57ec:      	sxtw	x3, w3
    57f0:      	cmp	x3, #0x0
    57f4:      	cset	w3, gt
    57f8:      	ubfx	x3, x3, #0, #8
    57fc:      	b	0x5908 <_stogir.conversion.validate+0x39c>
    5800:      	brk	#0
    5804:      	b	0x5800 <_stogir.conversion.validate+0x294>
    5808:      	movz	x3, #0x0, lsl #48
    580c:      	b	0x5814 <_stogir.conversion.validate+0x2a8>
    5810:      	movz	x3, #0x0, lsl #48
    5814:      	cmp	x3, #0x0
    5818:      	b.eq	0x584c <_stogir.conversion.validate+0x2e0>
    581c:      	uxtb	w16, w10
    5820:      	cmp	w16, wzr
    5824:      	b.eq	0x5838 <_stogir.conversion.validate+0x2cc>
    5828:      	ldr	x0, [x0]
    582c:      	add	x0, x0, x6, lsl #4
    5830:      	ldr	x0, [x0]
    5834:      	b	0x5844 <_stogir.conversion.validate+0x2d8>
    5838:      	ldr	x0, [x0, #0x28]
    583c:      	add	x0, x0, x12, lsl #4
    5840:      	ldr	x0, [x0]
    5844:      	mov	w3, #0x1                ; =1
    5848:      	b	0x5854 <_stogir.conversion.validate+0x2e8>
    584c:      	movz	w3, #0x0, lsl #16
    5850:      	movz	x0, #0x0, lsl #48
    5854:      	ubfx	x3, x3, #0, #32
    5858:      	lsr	x16, x3, #0
    585c:      	cmp	x16, #0x1
    5860:      	b.eq	0x587c <_stogir.conversion.validate+0x310>
    5864:      	b.lo	0x586c <_stogir.conversion.validate+0x300>
    5868:      	b	0x5880 <_stogir.conversion.validate+0x314>
    586c:      	cmp	x16, #0x0
    5870:      	b.eq	0x5878 <_stogir.conversion.validate+0x30c>
    5874:      	b	0x5880 <_stogir.conversion.validate+0x314>
    5878:      	b	0x5884 <_stogir.conversion.validate+0x318>
    587c:      	b	0x579c <_stogir.conversion.validate+0x230>
    5880:      	b	0x590c <_stogir.conversion.validate+0x3a0>
    5884:      	mov	x19, x8
    5888:      	mov	x0, #0x1                ; =1
    588c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		000000000000588c:  ARM64_RELOC_PAGE21	l_stogir.407
    5890:      	ldr	x1, [x1]
		0000000000005890:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    5894:      	mov	x2, #0x19               ; =25
    5898:      	b	0x57bc <_stogir.conversion.validate+0x250>
    589c:      	movz	x3, #0x0, lsl #48
    58a0:      	b	0x5814 <_stogir.conversion.validate+0x2a8>
    58a4:      	movz	x3, #0x0, lsl #48
    58a8:      	b	0x580c <_stogir.conversion.validate+0x2a0>
    58ac:      	cmp	x3, #0x46
    58b0:      	b.eq	0x592c <_stogir.conversion.validate+0x3c0>
    58b4:      	ubfx	x7, x7, #0, #32
    58b8:      	ubfx	x0, x0, #0, #32
    58bc:      	ubfx	x3, x7, #8, #8
    58c0:      	ubfx	x0, x0, #8, #8
    58c4:      	mov	x19, x8
    58c8:      	add	x8, sp, #0x10
    58cc:      	fmov	s31, w0
    58d0:      	mov	w0, w1
    58d4:      	fmov	w1, s31
    58d8:      	fmov	s31, w2
    58dc:      	mov	w2, w3
    58e0:      	fmov	w3, s31
    58e4:      	bl	0x58e4 <_stogir.conversion.validate+0x378>
		00000000000058e4:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    58e8:      	add	x16, sp, #0x10
    58ec:      	ldr	x0, [x16]
    58f0:      	add	x16, sp, #0x10
    58f4:      	ldr	x1, [x16, #0x8]
    58f8:      	add	x16, sp, #0x10
    58fc:      	ldr	x2, [x16, #0x10]
    5900:      	b	0x57bc <_stogir.conversion.validate+0x250>
    5904:      	movz	x3, #0x0, lsl #48
    5908:      	b	0x58a0 <_stogir.conversion.validate+0x334>
    590c:      	brk	#0
    5910:      	b	0x590c <_stogir.conversion.validate+0x3a0>
    5914:      	mov	x19, x8
    5918:      	b	0x56f0 <_stogir.conversion.validate+0x184>
    591c:      	mov	x19, x8
    5920:      	b	0x56f0 <_stogir.conversion.validate+0x184>
    5924:      	mov	x19, x8
    5928:      	b	0x56f0 <_stogir.conversion.validate+0x184>
    592c:      	mov	x19, x8
    5930:      	b	0x57ac <_stogir.conversion.validate+0x240>

0000000000005934 <_stogir.conditional.validate>:
    5934:      	sub	sp, sp, #0x40
    5938:      	str	x29, [sp]
    593c:      	str	x30, [sp, #0x8]
    5940:      	mov	x29, sp
    5944:      	str	x19, [sp, #0x30]
    5948:      	sxtw	x1, w1
    594c:      	add	x2, x0, #0x78
    5950:      	add	x3, x0, #0x28
    5954:      	lsl	x4, x1, #2
    5958:      	cmp	x1, #0x0
    595c:      	cset	w5, gt
    5960:      	movz	x16, #0x0, lsl #48
    5964:      	sub	x6, x16, x1
    5968:      	sub	x7, x6, #0x1
    596c:      	uxtb	w16, w5
    5970:      	cmp	w16, wzr
    5974:      	b.eq	0x59b0 <_stogir.conditional.validate+0x7c>
    5978:      	ldr	x3, [x0, #0x8]
    597c:      	cmp	x1, x3
    5980:      	b.ge	0x59fc <_stogir.conditional.validate+0xc8>
    5984:      	ldr	x2, [x2, #0x8]
    5988:      	cmp	x1, x2
    598c:      	b.ge	0x5ad8 <_stogir.conditional.validate+0x1a4>
    5990:      	ldr	x2, [x0, #0x78]
    5994:      	add	x2, x4, x2
    5998:      	ldr	w2, [x2]
    599c:      	sxtw	x2, w2
    59a0:      	cmp	x2, #0x0
    59a4:      	cset	w2, ge
    59a8:      	ubfx	x2, x2, #0, #8
    59ac:      	b	0x5adc <_stogir.conditional.validate+0x1a8>
    59b0:      	cmp	x1, #0x0
    59b4:      	b.ge	0x5a04 <_stogir.conditional.validate+0xd0>
    59b8:      	add	x2, x0, #0x50
    59bc:      	ldr	x3, [x3, #0x8]
    59c0:      	ldr	x2, [x2, #0x8]
    59c4:      	cmp	x3, x2
    59c8:      	b.ne	0x59f4 <_stogir.conditional.validate+0xc0>
    59cc:      	cmp	x6, x3
    59d0:      	b.gt	0x5b58 <_stogir.conditional.validate+0x224>
    59d4:      	ldr	x2, [x0, #0x50]
    59d8:      	add	x2, x2, x7, lsl #2
    59dc:      	ldr	w2, [x2]
    59e0:      	sxtw	x2, w2
    59e4:      	cmp	x2, #0x0
    59e8:      	cset	w2, gt
    59ec:      	ubfx	x2, x2, #0, #8
    59f0:      	b	0x5b5c <_stogir.conditional.validate+0x228>
    59f4:      	movz	x2, #0x0, lsl #48
    59f8:      	b	0x5a08 <_stogir.conditional.validate+0xd4>
    59fc:      	movz	x2, #0x0, lsl #48
    5a00:      	b	0x5a08 <_stogir.conditional.validate+0xd4>
    5a04:      	movz	x2, #0x0, lsl #48
    5a08:      	cmp	x2, #0x0
    5a0c:      	b.eq	0x5a48 <_stogir.conditional.validate+0x114>
    5a10:      	uxtb	w16, w5
    5a14:      	cmp	w16, wzr
    5a18:      	b.eq	0x5a30 <_stogir.conditional.validate+0xfc>
    5a1c:      	ldr	x2, [x0]
    5a20:      	add	x2, x2, x1, lsl #4
    5a24:      	ldr	x3, [x2]
    5a28:      	ldr	x2, [x2, #0x8]
    5a2c:      	b	0x5a40 <_stogir.conditional.validate+0x10c>
    5a30:      	ldr	x2, [x0, #0x28]
    5a34:      	add	x2, x2, x7, lsl #4
    5a38:      	ldr	x3, [x2]
    5a3c:      	ldr	x2, [x2, #0x8]
    5a40:      	mov	w5, #0x1                ; =1
    5a44:      	b	0x5a54 <_stogir.conditional.validate+0x120>
    5a48:      	movz	w5, #0x0, lsl #16
    5a4c:      	movz	x3, #0x0, lsl #48
    5a50:      	movz	x2, #0x0, lsl #48
    5a54:      	ubfx	x5, x5, #0, #32
    5a58:      	lsr	x16, x5, #0
    5a5c:      	cmp	x16, #0x1
    5a60:      	b.eq	0x5a7c <_stogir.conditional.validate+0x148>
    5a64:      	b.lo	0x5a6c <_stogir.conditional.validate+0x138>
    5a68:      	b	0x5a80 <_stogir.conditional.validate+0x14c>
    5a6c:      	cmp	x16, #0x0
    5a70:      	b.eq	0x5a78 <_stogir.conditional.validate+0x144>
    5a74:      	b	0x5a80 <_stogir.conditional.validate+0x14c>
    5a78:      	b	0x5a84 <_stogir.conditional.validate+0x150>
    5a7c:      	b	0x5a9c <_stogir.conditional.validate+0x168>
    5a80:      	b	0x5b60 <_stogir.conditional.validate+0x22c>
    5a84:      	mov	x19, x8
    5a88:      	mov	x0, #0x1                ; =1
    5a8c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005a8c:  ARM64_RELOC_PAGE21	l_stogir.408
    5a90:      	ldr	x1, [x1]
		0000000000005a90:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    5a94:      	mov	x2, #0x18               ; =24
    5a98:      	b	0x5ab8 <_stogir.conditional.validate+0x184>
    5a9c:      	cmp	x1, #0x0
    5aa0:      	b.gt	0x5ae0 <_stogir.conditional.validate+0x1ac>
    5aa4:      	mov	x19, x8
    5aa8:      	mov	x0, #0x1                ; =1
    5aac:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005aac:  ARM64_RELOC_PAGE21	l_stogir.409
    5ab0:      	ldr	x1, [x1]
		0000000000005ab0:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    5ab4:      	mov	x2, #0x18               ; =24
    5ab8:      	str	x0, [x19]
    5abc:      	str	x1, [x19, #0x8]
    5ac0:      	str	x2, [x19, #0x10]
    5ac4:      	ldr	x19, [sp, #0x30]
    5ac8:      	ldr	x29, [sp]
    5acc:      	ldr	x30, [sp, #0x8]
    5ad0:      	add	sp, sp, #0x40
    5ad4:      	ret
    5ad8:      	movz	x2, #0x0, lsl #48
    5adc:      	b	0x5a00 <_stogir.conditional.validate+0xcc>
    5ae0:      	uxtb	w1, w3
    5ae4:      	cmp	x1, #0x3c
    5ae8:      	b.ne	0x5b68 <_stogir.conditional.validate+0x234>
    5aec:      	ldr	x1, [x0, #0x78]
    5af0:      	add	x1, x4, x1
    5af4:      	ldr	w1, [x1]
    5af8:      	sxtw	x1, w1
    5afc:      	cmp	x1, #0x3
    5b00:      	b.ne	0x5b70 <_stogir.conditional.validate+0x23c>
    5b04:      	orr	w1, w2, wzr
    5b08:      	orr	w4, w3, wzr
    5b0c:      	lsr	x3, x3, #32
    5b10:      	lsr	x2, x2, #32
    5b14:      	ubfx	x4, x4, #0, #32
    5b18:      	ubfx	x4, x4, #8, #8
    5b1c:      	mov	x19, x8
    5b20:      	add	x8, sp, #0x10
    5b24:      	fmov	s31, w1
    5b28:      	mov	w1, w4
    5b2c:      	mov	w4, w2
    5b30:      	mov	w2, w3
    5b34:      	fmov	w3, s31
    5b38:      	bl	0x5b38 <_stogir.conditional.validate+0x204>
		0000000000005b38:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    5b3c:      	add	x16, sp, #0x10
    5b40:      	ldr	x0, [x16]
    5b44:      	add	x16, sp, #0x10
    5b48:      	ldr	x1, [x16, #0x8]
    5b4c:      	add	x16, sp, #0x10
    5b50:      	ldr	x2, [x16, #0x10]
    5b54:      	b	0x5ab8 <_stogir.conditional.validate+0x184>
    5b58:      	movz	x2, #0x0, lsl #48
    5b5c:      	b	0x59f8 <_stogir.conditional.validate+0xc4>
    5b60:      	brk	#0
    5b64:      	b	0x5b60 <_stogir.conditional.validate+0x22c>
    5b68:      	mov	x19, x8
    5b6c:      	b	0x5aa8 <_stogir.conditional.validate+0x174>
    5b70:      	mov	x19, x8
    5b74:      	b	0x5aa8 <_stogir.conditional.validate+0x174>

0000000000005b78 <_stogir.floating.validate>:
    5b78:      	sub	sp, sp, #0x50
    5b7c:      	str	x29, [sp]
    5b80:      	str	x30, [sp, #0x8]
    5b84:      	mov	x29, sp
    5b88:      	str	x19, [sp, #0x40]
    5b8c:      	sxtw	x1, w1
    5b90:      	add	x2, x0, #0x78
    5b94:      	add	x3, x0, #0x28
    5b98:      	add	x4, x0, #0x50
    5b9c:      	lsl	x5, x1, #2
    5ba0:      	cmp	x1, #0x0
    5ba4:      	cset	w6, gt
    5ba8:      	movz	x16, #0x0, lsl #48
    5bac:      	sub	x7, x16, x1
    5bb0:      	sub	x9, x7, #0x1
    5bb4:      	uxtb	w16, w6
    5bb8:      	cmp	w16, wzr
    5bbc:      	b.eq	0x5bf8 <_stogir.floating.validate+0x80>
    5bc0:      	ldr	x7, [x0, #0x8]
    5bc4:      	cmp	x1, x7
    5bc8:      	b.ge	0x5c40 <_stogir.floating.validate+0xc8>
    5bcc:      	ldr	x7, [x2, #0x8]
    5bd0:      	cmp	x1, x7
    5bd4:      	b.ge	0x5d2c <_stogir.floating.validate+0x1b4>
    5bd8:      	ldr	x7, [x0, #0x78]
    5bdc:      	add	x7, x5, x7
    5be0:      	ldr	w7, [x7]
    5be4:      	sxtw	x7, w7
    5be8:      	cmp	x7, #0x0
    5bec:      	cset	w7, ge
    5bf0:      	ubfx	x7, x7, #0, #8
    5bf4:      	b	0x5d30 <_stogir.floating.validate+0x1b8>
    5bf8:      	cmp	x1, #0x0
    5bfc:      	b.ge	0x5c48 <_stogir.floating.validate+0xd0>
    5c00:      	ldr	x10, [x3, #0x8]
    5c04:      	ldr	x11, [x4, #0x8]
    5c08:      	cmp	x10, x11
    5c0c:      	b.ne	0x5c38 <_stogir.floating.validate+0xc0>
    5c10:      	cmp	x7, x10
    5c14:      	b.gt	0x5db8 <_stogir.floating.validate+0x240>
    5c18:      	ldr	x7, [x0, #0x50]
    5c1c:      	add	x7, x7, x9, lsl #2
    5c20:      	ldr	w7, [x7]
    5c24:      	sxtw	x7, w7
    5c28:      	cmp	x7, #0x0
    5c2c:      	cset	w7, gt
    5c30:      	ubfx	x7, x7, #0, #8
    5c34:      	b	0x5dbc <_stogir.floating.validate+0x244>
    5c38:      	movz	x7, #0x0, lsl #48
    5c3c:      	b	0x5c4c <_stogir.floating.validate+0xd4>
    5c40:      	movz	x7, #0x0, lsl #48
    5c44:      	b	0x5c4c <_stogir.floating.validate+0xd4>
    5c48:      	movz	x7, #0x0, lsl #48
    5c4c:      	cmp	x7, #0x0
    5c50:      	b.eq	0x5c8c <_stogir.floating.validate+0x114>
    5c54:      	uxtb	w16, w6
    5c58:      	cmp	w16, wzr
    5c5c:      	b.eq	0x5c74 <_stogir.floating.validate+0xfc>
    5c60:      	ldr	x6, [x0]
    5c64:      	add	x6, x6, x1, lsl #4
    5c68:      	ldr	x7, [x6]
    5c6c:      	ldr	x6, [x6, #0x8]
    5c70:      	b	0x5c84 <_stogir.floating.validate+0x10c>
    5c74:      	ldr	x6, [x0, #0x28]
    5c78:      	add	x6, x6, x9, lsl #4
    5c7c:      	ldr	x7, [x6]
    5c80:      	ldr	x6, [x6, #0x8]
    5c84:      	mov	w9, #0x1                ; =1
    5c88:      	b	0x5c98 <_stogir.floating.validate+0x120>
    5c8c:      	movz	w9, #0x0, lsl #16
    5c90:      	movz	x7, #0x0, lsl #48
    5c94:      	movz	x6, #0x0, lsl #48
    5c98:      	ubfx	x9, x9, #0, #32
    5c9c:      	lsr	x16, x9, #0
    5ca0:      	cmp	x16, #0x1
    5ca4:      	b.eq	0x5cc0 <_stogir.floating.validate+0x148>
    5ca8:      	b.lo	0x5cb0 <_stogir.floating.validate+0x138>
    5cac:      	b	0x5cc4 <_stogir.floating.validate+0x14c>
    5cb0:      	cmp	x16, #0x0
    5cb4:      	b.eq	0x5cbc <_stogir.floating.validate+0x144>
    5cb8:      	b	0x5cc4 <_stogir.floating.validate+0x14c>
    5cbc:      	b	0x5cc8 <_stogir.floating.validate+0x150>
    5cc0:      	b	0x5cfc <_stogir.floating.validate+0x184>
    5cc4:      	b	0x6018 <_stogir.floating.validate+0x4a0>
    5cc8:      	mov	x19, x8
    5ccc:      	mov	x0, #0x1                ; =1
    5cd0:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005cd0:  ARM64_RELOC_PAGE21	l_stogir.410
    5cd4:      	ldr	x1, [x1]
		0000000000005cd4:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    5cd8:      	mov	x2, #0x1c               ; =28
    5cdc:      	str	x0, [x19]
    5ce0:      	str	x1, [x19, #0x8]
    5ce4:      	str	x2, [x19, #0x10]
    5ce8:      	ldr	x19, [sp, #0x40]
    5cec:      	ldr	x29, [sp]
    5cf0:      	ldr	x30, [sp, #0x8]
    5cf4:      	add	sp, sp, #0x50
    5cf8:      	ret
    5cfc:      	add	x16, sp, #0x10
    5d00:      	str	x7, [x16]
    5d04:      	add	x16, sp, #0x10
    5d08:      	str	x6, [x16, #0x8]
    5d0c:      	cmp	x1, #0x0
    5d10:      	b.gt	0x5d34 <_stogir.floating.validate+0x1bc>
    5d14:      	mov	x19, x8
    5d18:      	mov	x0, #0x1                ; =1
    5d1c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005d1c:  ARM64_RELOC_PAGE21	l_stogir.411
    5d20:      	ldr	x1, [x1]
		0000000000005d20:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    5d24:      	mov	x2, #0x1c               ; =28
    5d28:      	b	0x5cdc <_stogir.floating.validate+0x164>
    5d2c:      	movz	x7, #0x0, lsl #48
    5d30:      	b	0x5c44 <_stogir.floating.validate+0xcc>
    5d34:      	uxtb	w7, w7
    5d38:      	orr	x1, x7, xzr
    5d3c:      	cmp	x1, #0xe
    5d40:      	cset	w6, ge
    5d44:      	cmp	x1, #0x19
    5d48:      	cset	w9, le
    5d4c:      	cmp	x1, #0x1f
    5d50:      	cset	w10, eq
    5d54:      	cmp	x1, #0x20
    5d58:      	cset	w11, eq
    5d5c:      	uxtb	w16, w6
    5d60:      	cmp	w16, wzr
    5d64:      	b.eq	0x5dc0 <_stogir.floating.validate+0x248>
    5d68:      	uxtb	w16, w9
    5d6c:      	cmp	w16, wzr
    5d70:      	b.eq	0x5dc0 <_stogir.floating.validate+0x248>
    5d74:      	cmp	x1, #0x1d
    5d78:      	cset	w1, eq
    5d7c:      	ldr	x12, [x0, #0x78]
    5d80:      	add	x5, x5, x12
    5d84:      	ldr	w5, [x5]
    5d88:      	uxtb	w16, w10
    5d8c:      	cmp	w16, wzr
    5d90:      	b.ne	0x5e00 <_stogir.floating.validate+0x288>
    5d94:      	uxtb	w16, w11
    5d98:      	cmp	w16, wzr
    5d9c:      	b.ne	0x5e00 <_stogir.floating.validate+0x288>
    5da0:      	uxtb	w16, w1
    5da4:      	cmp	w16, wzr
    5da8:      	mov	w16, #0x3               ; =3
    5dac:      	mov	w17, #0x2               ; =2
    5db0:      	csel	w10, w16, w17, ne
    5db4:      	b	0x5e04 <_stogir.floating.validate+0x28c>
    5db8:      	movz	x7, #0x0, lsl #48
    5dbc:      	b	0x5c3c <_stogir.floating.validate+0xc4>
    5dc0:      	uxtb	w16, w10
    5dc4:      	cmp	w16, wzr
    5dc8:      	b.ne	0x5d74 <_stogir.floating.validate+0x1fc>
    5dcc:      	uxtb	w16, w11
    5dd0:      	cmp	w16, wzr
    5dd4:      	b.ne	0x5d74 <_stogir.floating.validate+0x1fc>
    5dd8:      	cmp	x1, #0x1a
    5ddc:      	b.lt	0x5de8 <_stogir.floating.validate+0x270>
    5de0:      	cmp	x1, #0x1d
    5de4:      	b.le	0x5d74 <_stogir.floating.validate+0x1fc>
    5de8:      	cmp	x1, #0x3a
    5dec:      	b.eq	0x5d74 <_stogir.floating.validate+0x1fc>
    5df0:      	cmp	x1, #0x3b
    5df4:      	b.eq	0x5d74 <_stogir.floating.validate+0x1fc>
    5df8:      	mov	x19, x8
    5dfc:      	b	0x5d18 <_stogir.floating.validate+0x1a0>
    5e00:      	mov	w10, #0x1               ; =1
    5e04:      	sxtw	x5, w5
    5e08:      	sxtw	x10, w10
    5e0c:      	cmp	x5, x10
    5e10:      	b.ne	0x6028 <_stogir.floating.validate+0x4b0>
    5e14:      	add	x16, sp, #0x10
    5e18:      	ldr	w5, [x16, #0x4]
    5e1c:      	sxtw	x5, w5
    5e20:      	cmp	x5, #0x0
    5e24:      	cset	w10, gt
    5e28:      	movz	x16, #0x0, lsl #48
    5e2c:      	sub	x11, x16, x5
    5e30:      	sub	x12, x11, #0x1
    5e34:      	uxtb	w16, w10
    5e38:      	cmp	w16, wzr
    5e3c:      	b.eq	0x5e8c <_stogir.floating.validate+0x314>
    5e40:      	ldr	x3, [x0, #0x8]
    5e44:      	cmp	x5, x3
    5e48:      	b.ge	0x5ecc <_stogir.floating.validate+0x354>
    5e4c:      	ldr	x2, [x2, #0x8]
    5e50:      	cmp	x5, x2
    5e54:      	b.ge	0x5f98 <_stogir.floating.validate+0x420>
    5e58:      	ldr	x2, [x0, #0x78]
    5e5c:      	add	x2, x2, x5, lsl #2
    5e60:      	ldr	w2, [x2]
    5e64:      	sxtw	x2, w2
    5e68:      	cmp	x2, #0x0
    5e6c:      	cset	w2, ge
    5e70:      	ubfx	x2, x2, #0, #8
    5e74:      	b	0x5f9c <_stogir.floating.validate+0x424>
    5e78:      	mov	x0, #0x1                ; =1
    5e7c:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005e7c:  ARM64_RELOC_PAGE21	l_stogir.412
    5e80:      	ldr	x1, [x1]
		0000000000005e80:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    5e84:      	mov	x2, #0x1d               ; =29
    5e88:      	b	0x5d28 <_stogir.floating.validate+0x1b0>
    5e8c:      	cmp	x5, #0x0
    5e90:      	b.ge	0x5ed4 <_stogir.floating.validate+0x35c>
    5e94:      	ldr	x2, [x3, #0x8]
    5e98:      	ldr	x3, [x4, #0x8]
    5e9c:      	cmp	x2, x3
    5ea0:      	b.ne	0x5f90 <_stogir.floating.validate+0x418>
    5ea4:      	cmp	x11, x2
    5ea8:      	b.gt	0x6010 <_stogir.floating.validate+0x498>
    5eac:      	ldr	x2, [x0, #0x50]
    5eb0:      	add	x2, x2, x12, lsl #2
    5eb4:      	ldr	w2, [x2]
    5eb8:      	sxtw	x2, w2
    5ebc:      	cmp	x2, #0x0
    5ec0:      	cset	w2, gt
    5ec4:      	ubfx	x2, x2, #0, #8
    5ec8:      	b	0x6014 <_stogir.floating.validate+0x49c>
    5ecc:      	movz	x2, #0x0, lsl #48
    5ed0:      	b	0x5ed8 <_stogir.floating.validate+0x360>
    5ed4:      	movz	x2, #0x0, lsl #48
    5ed8:      	cmp	x2, #0x0
    5edc:      	b.eq	0x5f10 <_stogir.floating.validate+0x398>
    5ee0:      	uxtb	w16, w10
    5ee4:      	cmp	w16, wzr
    5ee8:      	b.eq	0x5efc <_stogir.floating.validate+0x384>
    5eec:      	ldr	x2, [x0]
    5ef0:      	add	x2, x2, x5, lsl #4
    5ef4:      	ldr	x2, [x2]
    5ef8:      	b	0x5f08 <_stogir.floating.validate+0x390>
    5efc:      	ldr	x2, [x0, #0x28]
    5f00:      	add	x2, x2, x12, lsl #4
    5f04:      	ldr	x2, [x2]
    5f08:      	mov	w3, #0x1                ; =1
    5f0c:      	b	0x5f18 <_stogir.floating.validate+0x3a0>
    5f10:      	movz	w3, #0x0, lsl #16
    5f14:      	movz	x2, #0x0, lsl #48
    5f18:      	ubfx	x3, x3, #0, #32
    5f1c:      	lsr	x16, x3, #0
    5f20:      	cmp	x16, #0x1
    5f24:      	b.eq	0x5f40 <_stogir.floating.validate+0x3c8>
    5f28:      	b.lo	0x5f30 <_stogir.floating.validate+0x3b8>
    5f2c:      	b	0x5f44 <_stogir.floating.validate+0x3cc>
    5f30:      	cmp	x16, #0x0
    5f34:      	b.eq	0x5f3c <_stogir.floating.validate+0x3c4>
    5f38:      	b	0x5f44 <_stogir.floating.validate+0x3cc>
    5f3c:      	b	0x5f48 <_stogir.floating.validate+0x3d0>
    5f40:      	b	0x5f60 <_stogir.floating.validate+0x3e8>
    5f44:      	b	0x6020 <_stogir.floating.validate+0x4a8>
    5f48:      	mov	x19, x8
    5f4c:      	mov	x0, #0x1                ; =1
    5f50:      	adrp	x1, 0x5000 <_stogir.locals.validate+0x1b4>
		0000000000005f50:  ARM64_RELOC_PAGE21	l_stogir.413
    5f54:      	ldr	x1, [x1]
		0000000000005f54:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    5f58:      	mov	x2, #0x18               ; =24
    5f5c:      	b	0x5e88 <_stogir.floating.validate+0x310>
    5f60:      	add	x16, sp, #0x10
    5f64:      	ldr	w3, [x16]
    5f68:      	ubfx	x2, x2, #0, #32
    5f6c:      	ubfx	x2, x2, #8, #8
    5f70:      	uxtb	w16, w6
    5f74:      	cmp	w16, wzr
    5f78:      	b.eq	0x5fd4 <_stogir.floating.validate+0x45c>
    5f7c:      	uxtb	w16, w9
    5f80:      	cmp	w16, wzr
    5f84:      	b.eq	0x5fd4 <_stogir.floating.validate+0x45c>
    5f88:      	mov	w4, #0x1                ; =1
    5f8c:      	b	0x5fd8 <_stogir.floating.validate+0x460>
    5f90:      	movz	x2, #0x0, lsl #48
    5f94:      	b	0x5ed8 <_stogir.floating.validate+0x360>
    5f98:      	movz	x2, #0x0, lsl #48
    5f9c:      	b	0x5ed0 <_stogir.floating.validate+0x358>
    5fa0:      	movz	w1, #0x0, lsl #16
    5fa4:      	mov	w5, w1
    5fa8:      	mov	w1, w7
    5fac:      	mov	x19, x8
    5fb0:      	add	x8, sp, #0x20
    5fb4:      	bl	0x5fb4 <_stogir.floating.validate+0x43c>
		0000000000005fb4:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    5fb8:      	add	x16, sp, #0x20
    5fbc:      	ldr	x0, [x16]
    5fc0:      	add	x16, sp, #0x20
    5fc4:      	ldr	x1, [x16, #0x8]
    5fc8:      	add	x16, sp, #0x20
    5fcc:      	ldr	x2, [x16, #0x10]
    5fd0:      	b	0x5e88 <_stogir.floating.validate+0x310>
    5fd4:      	orr	x4, x2, xzr
    5fd8:      	sxtw	x4, w4
    5fdc:      	ubfx	x3, x3, #8, #8
    5fe0:      	cmp	x3, x4
    5fe4:      	b.ne	0x6030 <_stogir.floating.validate+0x4b8>
    5fe8:      	add	x16, sp, #0x10
    5fec:      	ldr	w3, [x16, #0x4]
    5ff0:      	add	x16, sp, #0x10
    5ff4:      	ldr	w4, [x16, #0x8]
    5ff8:      	uxtb	w16, w1
    5ffc:      	cmp	w16, wzr
    6000:      	b.eq	0x5fa0 <_stogir.floating.validate+0x428>
    6004:      	add	x16, sp, #0x10
    6008:      	ldr	w1, [x16, #0xc]
    600c:      	b	0x5fa4 <_stogir.floating.validate+0x42c>
    6010:      	movz	x2, #0x0, lsl #48
    6014:      	b	0x5f94 <_stogir.floating.validate+0x41c>
    6018:      	brk	#0
    601c:      	b	0x6018 <_stogir.floating.validate+0x4a0>
    6020:      	brk	#0
    6024:      	b	0x6020 <_stogir.floating.validate+0x4a8>
    6028:      	mov	x19, x8
    602c:      	b	0x5d18 <_stogir.floating.validate+0x1a0>
    6030:      	mov	x19, x8
    6034:      	b	0x5e78 <_stogir.floating.validate+0x300>

0000000000006038 <_stogir.integer-unary.valid-type?>:
    6038:      	sxtw	x0, w0
    603c:      	cmp	x0, #0x2d
    6040:      	cset	w2, eq
    6044:      	cmp	x0, #0x1f
    6048:      	cset	w3, eq
    604c:      	cmp	x0, #0x20
    6050:      	cset	w4, eq
    6054:      	cmp	x0, #0x36
    6058:      	cset	w5, eq
    605c:      	uxtb	w16, w3
    6060:      	cmp	w16, wzr
    6064:      	b.ne	0x60ac <_stogir.integer-unary.valid-type?+0x74>
    6068:      	uxtb	w16, w4
    606c:      	cmp	w16, wzr
    6070:      	b.ne	0x60ac <_stogir.integer-unary.valid-type?+0x74>
    6074:      	uxtb	w16, w2
    6078:      	cmp	w16, wzr
    607c:      	b.ne	0x60ac <_stogir.integer-unary.valid-type?+0x74>
    6080:      	uxtb	w16, w5
    6084:      	cmp	w16, wzr
    6088:      	b.ne	0x60ac <_stogir.integer-unary.valid-type?+0x74>
    608c:      	cmp	x0, #0x37
    6090:      	b.eq	0x60ac <_stogir.integer-unary.valid-type?+0x74>
    6094:      	cmp	x0, #0x38
    6098:      	b.eq	0x60ac <_stogir.integer-unary.valid-type?+0x74>
    609c:      	cmp	x0, #0x39
    60a0:      	b.eq	0x60ac <_stogir.integer-unary.valid-type?+0x74>
    60a4:      	movz	x0, #0x0, lsl #48
    60a8:      	b	0x60e4 <_stogir.integer-unary.valid-type?+0xac>
    60ac:      	sxtw	x1, w1
    60b0:      	cmp	x1, #0x1
    60b4:      	b.lt	0x60e0 <_stogir.integer-unary.valid-type?+0xa8>
    60b8:      	cmp	x1, #0xb
    60bc:      	cset	w0, le
    60c0:      	uxtb	w16, w0
    60c4:      	cmp	w16, wzr
    60c8:      	b.eq	0x60e0 <_stogir.integer-unary.valid-type?+0xa8>
    60cc:      	uxtb	w16, w2
    60d0:      	cmp	w16, wzr
    60d4:      	b.eq	0x60f0 <_stogir.integer-unary.valid-type?+0xb8>
    60d8:      	mov	x0, #0x1                ; =1
    60dc:      	b	0x60ec <_stogir.integer-unary.valid-type?+0xb4>
    60e0:      	movz	x0, #0x0, lsl #48
    60e4:      	ret
    60e8:      	mov	x0, #0x1                ; =1
    60ec:      	b	0x60e4 <_stogir.integer-unary.valid-type?+0xac>
    60f0:      	cmp	x1, #0x1
    60f4:      	b.ne	0x6100 <_stogir.integer-unary.valid-type?+0xc8>
    60f8:      	movz	x0, #0x0, lsl #48
    60fc:      	b	0x60ec <_stogir.integer-unary.valid-type?+0xb4>
    6100:      	cmp	x1, #0x6
    6104:      	cset	w2, eq
    6108:      	uxtb	w16, w3
    610c:      	cmp	w16, wzr
    6110:      	b.eq	0x6124 <_stogir.integer-unary.valid-type?+0xec>
    6114:      	uxtb	w16, w2
    6118:      	cmp	w16, wzr
    611c:      	cset	x0, eq
    6120:      	b	0x60ec <_stogir.integer-unary.valid-type?+0xb4>
    6124:      	uxtb	w16, w4
    6128:      	cmp	w16, wzr
    612c:      	b.eq	0x6148 <_stogir.integer-unary.valid-type?+0x110>
    6130:      	cmp	x1, #0x7
    6134:      	b.lt	0x6140 <_stogir.integer-unary.valid-type?+0x108>
    6138:      	ubfx	x0, x0, #0, #8
    613c:      	b	0x6144 <_stogir.integer-unary.valid-type?+0x10c>
    6140:      	movz	x0, #0x0, lsl #48
    6144:      	b	0x60ec <_stogir.integer-unary.valid-type?+0xb4>
    6148:      	uxtb	w16, w5
    614c:      	cmp	w16, wzr
    6150:      	b.eq	0x60e8 <_stogir.integer-unary.valid-type?+0xb0>
    6154:      	cmp	x1, #0x3
    6158:      	b.ne	0x6174 <_stogir.integer-unary.valid-type?+0x13c>
    615c:      	mov	x0, #0x1                ; =1
    6160:      	b	0x6170 <_stogir.integer-unary.valid-type?+0x138>
    6164:      	cmp	x1, #0xb
    6168:      	cset	w0, eq
    616c:      	ubfx	x0, x0, #0, #8
    6170:      	b	0x60ec <_stogir.integer-unary.valid-type?+0xb4>
    6174:      	cmp	x1, #0x4
    6178:      	b.ne	0x6184 <_stogir.integer-unary.valid-type?+0x14c>
    617c:      	mov	x0, #0x1                ; =1
    6180:      	b	0x6170 <_stogir.integer-unary.valid-type?+0x138>
    6184:      	cmp	x1, #0x5
    6188:      	b.ne	0x6194 <_stogir.integer-unary.valid-type?+0x15c>
    618c:      	mov	x0, #0x1                ; =1
    6190:      	b	0x6170 <_stogir.integer-unary.valid-type?+0x138>
    6194:      	uxtb	w16, w2
    6198:      	cmp	w16, wzr
    619c:      	b.eq	0x61a8 <_stogir.integer-unary.valid-type?+0x170>
    61a0:      	mov	x0, #0x1                ; =1
    61a4:      	b	0x6170 <_stogir.integer-unary.valid-type?+0x138>
    61a8:      	cmp	x1, #0x9
    61ac:      	b.ne	0x61b8 <_stogir.integer-unary.valid-type?+0x180>
    61b0:      	mov	x0, #0x1                ; =1
    61b4:      	b	0x6170 <_stogir.integer-unary.valid-type?+0x138>
    61b8:      	cmp	x1, #0xa
    61bc:      	b.ne	0x6164 <_stogir.integer-unary.valid-type?+0x12c>
    61c0:      	mov	x0, #0x1                ; =1
    61c4:      	b	0x6170 <_stogir.integer-unary.valid-type?+0x138>

00000000000061c8 <_stogir.types.vector?>:
    61c8:      	sxtw	x1, w0
    61cc:      	cmp	x1, #0xf
    61d0:      	b.le	0x61fc <_stogir.types.vector?+0x34>
    61d4:      	cmp	x1, #0x80
    61d8:      	b.ge	0x620c <_stogir.types.vector?+0x44>
    61dc:      	and	w0, w0, #0xf
    61e0:      	ubfx	x0, x0, #0, #32
    61e4:      	cmp	x0, #0x1
    61e8:      	b.lt	0x6204 <_stogir.types.vector?+0x3c>
    61ec:      	cmp	x0, #0xd
    61f0:      	cset	w0, le
    61f4:      	ubfx	x0, x0, #0, #8
    61f8:      	b	0x6208 <_stogir.types.vector?+0x40>
    61fc:      	movz	x0, #0x0, lsl #48
    6200:      	b	0x6208 <_stogir.types.vector?+0x40>
    6204:      	movz	x0, #0x0, lsl #48
    6208:      	ret
    620c:      	movz	x0, #0x0, lsl #48
    6210:      	b	0x6208 <_stogir.types.vector?+0x40>

0000000000006214 <_stogir.floating.operation?>:
    6214:      	sxtw	x0, w0
    6218:      	cmp	x0, #0xe
    621c:      	b.lt	0x6230 <_stogir.floating.operation?+0x1c>
    6220:      	cmp	x0, #0x19
    6224:      	b.gt	0x6230 <_stogir.floating.operation?+0x1c>
    6228:      	mov	x0, #0x1                ; =1
    622c:      	b	0x625c <_stogir.floating.operation?+0x48>
    6230:      	cmp	x0, #0x1f
    6234:      	b.eq	0x6258 <_stogir.floating.operation?+0x44>
    6238:      	cmp	x0, #0x20
    623c:      	b.eq	0x6258 <_stogir.floating.operation?+0x44>
    6240:      	cmp	x0, #0x1a
    6244:      	b.lt	0x6270 <_stogir.floating.operation?+0x5c>
    6248:      	cmp	x0, #0x1d
    624c:      	b.gt	0x6270 <_stogir.floating.operation?+0x5c>
    6250:      	mov	x0, #0x1                ; =1
    6254:      	b	0x626c <_stogir.floating.operation?+0x58>
    6258:      	mov	x0, #0x1                ; =1
    625c:      	ret
    6260:      	cmp	x0, #0x3b
    6264:      	cset	w0, eq
    6268:      	ubfx	x0, x0, #0, #8
    626c:      	b	0x625c <_stogir.floating.operation?+0x48>
    6270:      	cmp	x0, #0x3a
    6274:      	b.ne	0x6260 <_stogir.floating.operation?+0x4c>
    6278:      	mov	x0, #0x1                ; =1
    627c:      	b	0x626c <_stogir.floating.operation?+0x58>

0000000000006280 <_stogir.vector-lanes.validate>:
    6280:      	sub	sp, sp, #0x50
    6284:      	str	x29, [sp]
    6288:      	str	x30, [sp, #0x8]
    628c:      	mov	x29, sp
    6290:      	str	x19, [sp, #0x40]
    6294:      	sxtw	x1, w1
    6298:      	add	x3, x0, #0x78
    629c:      	add	x4, x0, #0x28
    62a0:      	lsl	x5, x1, #2
    62a4:      	cmp	x1, #0x0
    62a8:      	cset	w6, gt
    62ac:      	movz	x16, #0x0, lsl #48
    62b0:      	sub	x7, x16, x1
    62b4:      	sub	x9, x7, #0x1
    62b8:      	uxtb	w16, w6
    62bc:      	cmp	w16, wzr
    62c0:      	b.eq	0x62fc <_stogir.vector-lanes.validate+0x7c>
    62c4:      	ldr	x4, [x0, #0x8]
    62c8:      	cmp	x1, x4
    62cc:      	b.ge	0x6348 <_stogir.vector-lanes.validate+0xc8>
    62d0:      	ldr	x3, [x3, #0x8]
    62d4:      	cmp	x1, x3
    62d8:      	b.ge	0x6434 <_stogir.vector-lanes.validate+0x1b4>
    62dc:      	ldr	x3, [x0, #0x78]
    62e0:      	add	x3, x5, x3
    62e4:      	ldr	w3, [x3]
    62e8:      	sxtw	x3, w3
    62ec:      	cmp	x3, #0x0
    62f0:      	cset	w3, ge
    62f4:      	ubfx	x3, x3, #0, #8
    62f8:      	b	0x6438 <_stogir.vector-lanes.validate+0x1b8>
    62fc:      	cmp	x1, #0x0
    6300:      	b.ge	0x6350 <_stogir.vector-lanes.validate+0xd0>
    6304:      	add	x3, x0, #0x50
    6308:      	ldr	x4, [x4, #0x8]
    630c:      	ldr	x3, [x3, #0x8]
    6310:      	cmp	x4, x3
    6314:      	b.ne	0x6340 <_stogir.vector-lanes.validate+0xc0>
    6318:      	cmp	x7, x4
    631c:      	b.gt	0x6478 <_stogir.vector-lanes.validate+0x1f8>
    6320:      	ldr	x3, [x0, #0x50]
    6324:      	add	x3, x3, x9, lsl #2
    6328:      	ldr	w3, [x3]
    632c:      	sxtw	x3, w3
    6330:      	cmp	x3, #0x0
    6334:      	cset	w3, gt
    6338:      	ubfx	x3, x3, #0, #8
    633c:      	b	0x647c <_stogir.vector-lanes.validate+0x1fc>
    6340:      	movz	x3, #0x0, lsl #48
    6344:      	b	0x6354 <_stogir.vector-lanes.validate+0xd4>
    6348:      	movz	x3, #0x0, lsl #48
    634c:      	b	0x6354 <_stogir.vector-lanes.validate+0xd4>
    6350:      	movz	x3, #0x0, lsl #48
    6354:      	cmp	x3, #0x0
    6358:      	b.eq	0x6394 <_stogir.vector-lanes.validate+0x114>
    635c:      	uxtb	w16, w6
    6360:      	cmp	w16, wzr
    6364:      	b.eq	0x637c <_stogir.vector-lanes.validate+0xfc>
    6368:      	ldr	x3, [x0]
    636c:      	add	x3, x3, x1, lsl #4
    6370:      	ldr	x4, [x3]
    6374:      	ldr	x3, [x3, #0x8]
    6378:      	b	0x638c <_stogir.vector-lanes.validate+0x10c>
    637c:      	ldr	x3, [x0, #0x28]
    6380:      	add	x3, x3, x9, lsl #4
    6384:      	ldr	x4, [x3]
    6388:      	ldr	x3, [x3, #0x8]
    638c:      	mov	w6, #0x1                ; =1
    6390:      	b	0x63a0 <_stogir.vector-lanes.validate+0x120>
    6394:      	movz	w6, #0x0, lsl #16
    6398:      	movz	x4, #0x0, lsl #48
    639c:      	movz	x3, #0x0, lsl #48
    63a0:      	ubfx	x6, x6, #0, #32
    63a4:      	lsr	x16, x6, #0
    63a8:      	cmp	x16, #0x1
    63ac:      	b.eq	0x63c8 <_stogir.vector-lanes.validate+0x148>
    63b0:      	b.lo	0x63b8 <_stogir.vector-lanes.validate+0x138>
    63b4:      	b	0x63cc <_stogir.vector-lanes.validate+0x14c>
    63b8:      	cmp	x16, #0x0
    63bc:      	b.eq	0x63c4 <_stogir.vector-lanes.validate+0x144>
    63c0:      	b	0x63cc <_stogir.vector-lanes.validate+0x14c>
    63c4:      	b	0x63d0 <_stogir.vector-lanes.validate+0x150>
    63c8:      	b	0x63e8 <_stogir.vector-lanes.validate+0x168>
    63cc:      	b	0x6530 <_stogir.vector-lanes.validate+0x2b0>
    63d0:      	mov	x19, x8
    63d4:      	mov	x0, #0x1                ; =1
    63d8:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x488>
		00000000000063d8:  ARM64_RELOC_PAGE21	l_stogir.414
    63dc:      	ldr	x1, [x1]
		00000000000063dc:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    63e0:      	mov	x2, #0x1f               ; =31
    63e4:      	b	0x6414 <_stogir.vector-lanes.validate+0x194>
    63e8:      	add	x16, sp, #0x10
    63ec:      	str	x4, [x16]
    63f0:      	add	x16, sp, #0x10
    63f4:      	str	x3, [x16, #0x8]
    63f8:      	cmp	x1, #0x0
    63fc:      	b.gt	0x643c <_stogir.vector-lanes.validate+0x1bc>
    6400:      	mov	x19, x8
    6404:      	mov	x0, #0x1                ; =1
    6408:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x488>
		0000000000006408:  ARM64_RELOC_PAGE21	l_stogir.415
    640c:      	ldr	x1, [x1]
		000000000000640c:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    6410:      	mov	x2, #0x25               ; =37
    6414:      	str	x0, [x19]
    6418:      	str	x1, [x19, #0x8]
    641c:      	str	x2, [x19, #0x10]
    6420:      	ldr	x19, [sp, #0x40]
    6424:      	ldr	x29, [sp]
    6428:      	ldr	x30, [sp, #0x8]
    642c:      	add	sp, sp, #0x50
    6430:      	ret
    6434:      	movz	x3, #0x0, lsl #48
    6438:      	b	0x634c <_stogir.vector-lanes.validate+0xcc>
    643c:      	uxtb	w4, w4
    6440:      	orr	x1, x4, xzr
    6444:      	cmp	x1, #0x3d
    6448:      	b.lt	0x6538 <_stogir.vector-lanes.validate+0x2b8>
    644c:      	cmp	x1, #0x3f
    6450:      	b.gt	0x6540 <_stogir.vector-lanes.validate+0x2c0>
    6454:      	cmp	x1, #0x3e
    6458:      	cset	w3, eq
    645c:      	ldr	x6, [x0, #0x78]
    6460:      	add	x5, x5, x6
    6464:      	ldr	w5, [x5]
    6468:      	cmp	x1, #0x3d
    646c:      	b.ne	0x64cc <_stogir.vector-lanes.validate+0x24c>
    6470:      	mov	w6, #0x2                ; =2
    6474:      	b	0x64e0 <_stogir.vector-lanes.validate+0x260>
    6478:      	movz	x3, #0x0, lsl #48
    647c:      	b	0x6344 <_stogir.vector-lanes.validate+0xc4>
    6480:      	movz	w3, #0x0, lsl #16
    6484:      	ubfx	x5, x5, #8, #8
    6488:      	mov	x19, x8
    648c:      	add	x8, sp, #0x20
    6490:      	fmov	s31, w1
    6494:      	mov	w1, w4
    6498:      	mov	w4, w6
    649c:      	mov	w6, w3
    64a0:      	mov	w3, w2
    64a4:      	mov	w2, w5
    64a8:      	fmov	w5, s31
    64ac:      	bl	0x64ac <_stogir.vector-lanes.validate+0x22c>
		00000000000064ac:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    64b0:      	add	x16, sp, #0x20
    64b4:      	ldr	x0, [x16]
    64b8:      	add	x16, sp, #0x20
    64bc:      	ldr	x1, [x16, #0x8]
    64c0:      	add	x16, sp, #0x20
    64c4:      	ldr	x2, [x16, #0x10]
    64c8:      	b	0x6414 <_stogir.vector-lanes.validate+0x194>
    64cc:      	uxtb	w16, w3
    64d0:      	cmp	w16, wzr
    64d4:      	mov	w16, #0x3               ; =3
    64d8:      	mov	w17, #0x1               ; =1
    64dc:      	csel	w6, w16, w17, ne
    64e0:      	sxtw	x5, w5
    64e4:      	sxtw	x6, w6
    64e8:      	cmp	x5, x6
    64ec:      	b.ne	0x6548 <_stogir.vector-lanes.validate+0x2c8>
    64f0:      	add	x16, sp, #0x10
    64f4:      	ldr	w5, [x16]
    64f8:      	add	x16, sp, #0x10
    64fc:      	ldr	w6, [x16, #0x4]
    6500:      	cmp	x1, #0x3f
    6504:      	b.ne	0x6510 <_stogir.vector-lanes.validate+0x290>
    6508:      	movz	w1, #0x0, lsl #16
    650c:      	b	0x6518 <_stogir.vector-lanes.validate+0x298>
    6510:      	add	x16, sp, #0x10
    6514:      	ldr	w1, [x16, #0x8]
    6518:      	uxtb	w16, w3
    651c:      	cmp	w16, wzr
    6520:      	b.eq	0x6480 <_stogir.vector-lanes.validate+0x200>
    6524:      	add	x16, sp, #0x10
    6528:      	ldr	w3, [x16, #0xc]
    652c:      	b	0x6484 <_stogir.vector-lanes.validate+0x204>
    6530:      	brk	#0
    6534:      	b	0x6530 <_stogir.vector-lanes.validate+0x2b0>
    6538:      	mov	x19, x8
    653c:      	b	0x6404 <_stogir.vector-lanes.validate+0x184>
    6540:      	mov	x19, x8
    6544:      	b	0x6404 <_stogir.vector-lanes.validate+0x184>
    6548:      	mov	x19, x8
    654c:      	b	0x6404 <_stogir.vector-lanes.validate+0x184>

0000000000006550 <_stogir.vector-comparison.node?>:
    6550:      	sxtw	x1, w1
    6554:      	add	x2, x0, #0x28
    6558:      	cmp	x1, #0x0
    655c:      	cset	w3, gt
    6560:      	movz	x16, #0x0, lsl #48
    6564:      	sub	x4, x16, x1
    6568:      	sub	x5, x4, #0x1
    656c:      	uxtb	w16, w3
    6570:      	cmp	w16, wzr
    6574:      	b.eq	0x65b4 <_stogir.vector-comparison.node?+0x64>
    6578:      	ldr	x2, [x0, #0x8]
    657c:      	cmp	x1, x2
    6580:      	b.ge	0x6600 <_stogir.vector-comparison.node?+0xb0>
    6584:      	add	x2, x0, #0x78
    6588:      	ldr	x2, [x2, #0x8]
    658c:      	cmp	x1, x2
    6590:      	b.ge	0x66dc <_stogir.vector-comparison.node?+0x18c>
    6594:      	ldr	x2, [x0, #0x78]
    6598:      	add	x2, x2, x1, lsl #2
    659c:      	ldr	w2, [x2]
    65a0:      	sxtw	x2, w2
    65a4:      	cmp	x2, #0x0
    65a8:      	cset	w2, ge
    65ac:      	ubfx	x2, x2, #0, #8
    65b0:      	b	0x66e0 <_stogir.vector-comparison.node?+0x190>
    65b4:      	cmp	x1, #0x0
    65b8:      	b.ge	0x6608 <_stogir.vector-comparison.node?+0xb8>
    65bc:      	add	x6, x0, #0x50
    65c0:      	ldr	x2, [x2, #0x8]
    65c4:      	ldr	x6, [x6, #0x8]
    65c8:      	cmp	x2, x6
    65cc:      	b.ne	0x65f8 <_stogir.vector-comparison.node?+0xa8>
    65d0:      	cmp	x4, x2
    65d4:      	b.gt	0x66e4 <_stogir.vector-comparison.node?+0x194>
    65d8:      	ldr	x2, [x0, #0x50]
    65dc:      	add	x2, x2, x5, lsl #2
    65e0:      	ldr	w2, [x2]
    65e4:      	sxtw	x2, w2
    65e8:      	cmp	x2, #0x0
    65ec:      	cset	w2, gt
    65f0:      	ubfx	x2, x2, #0, #8
    65f4:      	b	0x66e8 <_stogir.vector-comparison.node?+0x198>
    65f8:      	movz	x2, #0x0, lsl #48
    65fc:      	b	0x660c <_stogir.vector-comparison.node?+0xbc>
    6600:      	movz	x2, #0x0, lsl #48
    6604:      	b	0x660c <_stogir.vector-comparison.node?+0xbc>
    6608:      	movz	x2, #0x0, lsl #48
    660c:      	cmp	x2, #0x0
    6610:      	b.eq	0x6644 <_stogir.vector-comparison.node?+0xf4>
    6614:      	uxtb	w16, w3
    6618:      	cmp	w16, wzr
    661c:      	b.eq	0x6630 <_stogir.vector-comparison.node?+0xe0>
    6620:      	ldr	x0, [x0]
    6624:      	add	x0, x0, x1, lsl #4
    6628:      	ldr	x0, [x0]
    662c:      	b	0x663c <_stogir.vector-comparison.node?+0xec>
    6630:      	ldr	x0, [x0, #0x28]
    6634:      	add	x0, x0, x5, lsl #4
    6638:      	ldr	x0, [x0]
    663c:      	mov	w1, #0x1                ; =1
    6640:      	b	0x664c <_stogir.vector-comparison.node?+0xfc>
    6644:      	movz	w1, #0x0, lsl #16
    6648:      	movz	x0, #0x0, lsl #48
    664c:      	ubfx	x1, x1, #0, #32
    6650:      	lsr	x16, x1, #0
    6654:      	cmp	x16, #0x1
    6658:      	b.eq	0x6674 <_stogir.vector-comparison.node?+0x124>
    665c:      	b.lo	0x6664 <_stogir.vector-comparison.node?+0x114>
    6660:      	b	0x6678 <_stogir.vector-comparison.node?+0x128>
    6664:      	cmp	x16, #0x0
    6668:      	b.eq	0x6670 <_stogir.vector-comparison.node?+0x120>
    666c:      	b	0x6678 <_stogir.vector-comparison.node?+0x128>
    6670:      	b	0x667c <_stogir.vector-comparison.node?+0x12c>
    6674:      	b	0x668c <_stogir.vector-comparison.node?+0x13c>
    6678:      	b	0x6704 <_stogir.vector-comparison.node?+0x1b4>
    667c:      	movz	x0, #0x0, lsl #48
    6680:      	b	0x6688 <_stogir.vector-comparison.node?+0x138>
    6684:      	movz	x0, #0x0, lsl #48
    6688:      	ret
    668c:      	uxtb	w1, w0
    6690:      	cmp	x1, #0xe
    6694:      	b.lt	0x6684 <_stogir.vector-comparison.node?+0x134>
    6698:      	cmp	x1, #0x19
    669c:      	b.gt	0x6684 <_stogir.vector-comparison.node?+0x134>
    66a0:      	ubfx	x0, x0, #0, #32
    66a4:      	ubfx	x0, x0, #8, #8
    66a8:      	orr	x1, x0, xzr
    66ac:      	cmp	x1, #0xf
    66b0:      	b.le	0x66ec <_stogir.vector-comparison.node?+0x19c>
    66b4:      	cmp	x1, #0x80
    66b8:      	b.ge	0x66f4 <_stogir.vector-comparison.node?+0x1a4>
    66bc:      	and	w0, w0, #0xf
    66c0:      	ubfx	x0, x0, #0, #32
    66c4:      	cmp	x0, #0x1
    66c8:      	b.lt	0x66fc <_stogir.vector-comparison.node?+0x1ac>
    66cc:      	cmp	x0, #0xd
    66d0:      	cset	w0, le
    66d4:      	ubfx	x0, x0, #0, #8
    66d8:      	b	0x6700 <_stogir.vector-comparison.node?+0x1b0>
    66dc:      	movz	x2, #0x0, lsl #48
    66e0:      	b	0x6604 <_stogir.vector-comparison.node?+0xb4>
    66e4:      	movz	x2, #0x0, lsl #48
    66e8:      	b	0x65fc <_stogir.vector-comparison.node?+0xac>
    66ec:      	movz	x0, #0x0, lsl #48
    66f0:      	b	0x6688 <_stogir.vector-comparison.node?+0x138>
    66f4:      	movz	x0, #0x0, lsl #48
    66f8:      	b	0x66f0 <_stogir.vector-comparison.node?+0x1a0>
    66fc:      	movz	x0, #0x0, lsl #48
    6700:      	b	0x66f8 <_stogir.vector-comparison.node?+0x1a8>
    6704:      	brk	#0
    6708:      	b	0x6704 <_stogir.vector-comparison.node?+0x1b4>

000000000000670c <_stogir.vector-comparison.validate>:
    670c:      	sub	sp, sp, #0x50
    6710:      	str	x29, [sp]
    6714:      	str	x30, [sp, #0x8]
    6718:      	mov	x29, sp
    671c:      	str	x19, [sp, #0x40]
    6720:      	sxtw	x1, w1
    6724:      	add	x3, x0, #0x78
    6728:      	add	x4, x0, #0x28
    672c:      	lsl	x5, x1, #2
    6730:      	cmp	x1, #0x0
    6734:      	cset	w6, gt
    6738:      	movz	x16, #0x0, lsl #48
    673c:      	sub	x7, x16, x1
    6740:      	sub	x9, x7, #0x1
    6744:      	uxtb	w16, w6
    6748:      	cmp	w16, wzr
    674c:      	b.eq	0x6788 <_stogir.vector-comparison.validate+0x7c>
    6750:      	ldr	x4, [x0, #0x8]
    6754:      	cmp	x1, x4
    6758:      	b.ge	0x67d4 <_stogir.vector-comparison.validate+0xc8>
    675c:      	ldr	x4, [x3, #0x8]
    6760:      	cmp	x1, x4
    6764:      	b.ge	0x68c4 <_stogir.vector-comparison.validate+0x1b8>
    6768:      	ldr	x4, [x0, #0x78]
    676c:      	add	x4, x5, x4
    6770:      	ldr	w4, [x4]
    6774:      	sxtw	x4, w4
    6778:      	cmp	x4, #0x0
    677c:      	cset	w4, ge
    6780:      	ubfx	x4, x4, #0, #8
    6784:      	b	0x68c8 <_stogir.vector-comparison.validate+0x1bc>
    6788:      	cmp	x1, #0x0
    678c:      	b.ge	0x67dc <_stogir.vector-comparison.validate+0xd0>
    6790:      	add	x10, x0, #0x50
    6794:      	ldr	x4, [x4, #0x8]
    6798:      	ldr	x10, [x10, #0x8]
    679c:      	cmp	x4, x10
    67a0:      	b.ne	0x67cc <_stogir.vector-comparison.validate+0xc0>
    67a4:      	cmp	x7, x4
    67a8:      	b.gt	0x6910 <_stogir.vector-comparison.validate+0x204>
    67ac:      	ldr	x4, [x0, #0x50]
    67b0:      	add	x4, x4, x9, lsl #2
    67b4:      	ldr	w4, [x4]
    67b8:      	sxtw	x4, w4
    67bc:      	cmp	x4, #0x0
    67c0:      	cset	w4, gt
    67c4:      	ubfx	x4, x4, #0, #8
    67c8:      	b	0x6914 <_stogir.vector-comparison.validate+0x208>
    67cc:      	movz	x4, #0x0, lsl #48
    67d0:      	b	0x67e0 <_stogir.vector-comparison.validate+0xd4>
    67d4:      	movz	x4, #0x0, lsl #48
    67d8:      	b	0x67e0 <_stogir.vector-comparison.validate+0xd4>
    67dc:      	movz	x4, #0x0, lsl #48
    67e0:      	lsl	x7, x1, #4
    67e4:      	cmp	x4, #0x0
    67e8:      	b.eq	0x6824 <_stogir.vector-comparison.validate+0x118>
    67ec:      	uxtb	w16, w6
    67f0:      	cmp	w16, wzr
    67f4:      	b.eq	0x680c <_stogir.vector-comparison.validate+0x100>
    67f8:      	ldr	x4, [x0]
    67fc:      	add	x4, x7, x4
    6800:      	ldr	x6, [x4]
    6804:      	ldr	x4, [x4, #0x8]
    6808:      	b	0x681c <_stogir.vector-comparison.validate+0x110>
    680c:      	ldr	x4, [x0, #0x28]
    6810:      	add	x4, x4, x9, lsl #4
    6814:      	ldr	x6, [x4]
    6818:      	ldr	x4, [x4, #0x8]
    681c:      	mov	w9, #0x1                ; =1
    6820:      	b	0x6830 <_stogir.vector-comparison.validate+0x124>
    6824:      	movz	w9, #0x0, lsl #16
    6828:      	movz	x6, #0x0, lsl #48
    682c:      	movz	x4, #0x0, lsl #48
    6830:      	ubfx	x9, x9, #0, #32
    6834:      	lsr	x16, x9, #0
    6838:      	cmp	x16, #0x1
    683c:      	b.eq	0x6858 <_stogir.vector-comparison.validate+0x14c>
    6840:      	b.lo	0x6848 <_stogir.vector-comparison.validate+0x13c>
    6844:      	b	0x685c <_stogir.vector-comparison.validate+0x150>
    6848:      	cmp	x16, #0x0
    684c:      	b.eq	0x6854 <_stogir.vector-comparison.validate+0x148>
    6850:      	b	0x685c <_stogir.vector-comparison.validate+0x150>
    6854:      	b	0x6860 <_stogir.vector-comparison.validate+0x154>
    6858:      	b	0x6894 <_stogir.vector-comparison.validate+0x188>
    685c:      	b	0x6a10 <_stogir.vector-comparison.validate+0x304>
    6860:      	mov	x19, x8
    6864:      	mov	x0, #0x1                ; =1
    6868:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x488>
		0000000000006868:  ARM64_RELOC_PAGE21	l_stogir.416
    686c:      	ldr	x1, [x1]
		000000000000686c:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    6870:      	mov	x2, #0x25               ; =37
    6874:      	str	x0, [x19]
    6878:      	str	x1, [x19, #0x8]
    687c:      	str	x2, [x19, #0x10]
    6880:      	ldr	x19, [sp, #0x40]
    6884:      	ldr	x29, [sp]
    6888:      	ldr	x30, [sp, #0x8]
    688c:      	add	sp, sp, #0x50
    6890:      	ret
    6894:      	add	x16, sp, #0x10
    6898:      	str	x6, [x16]
    689c:      	add	x16, sp, #0x10
    68a0:      	str	x4, [x16, #0x8]
    68a4:      	cmp	x1, #0x0
    68a8:      	b.gt	0x68cc <_stogir.vector-comparison.validate+0x1c0>
    68ac:      	mov	x19, x8
    68b0:      	mov	x0, #0x1                ; =1
    68b4:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x488>
		00000000000068b4:  ARM64_RELOC_PAGE21	l_stogir.417
    68b8:      	ldr	x1, [x1]
		00000000000068b8:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    68bc:      	mov	x2, #0x2b               ; =43
    68c0:      	b	0x6874 <_stogir.vector-comparison.validate+0x168>
    68c4:      	movz	x4, #0x0, lsl #48
    68c8:      	b	0x67d8 <_stogir.vector-comparison.validate+0xcc>
    68cc:      	ldr	x4, [x0, #0x8]
    68d0:      	cmp	x1, x4
    68d4:      	b.ge	0x6918 <_stogir.vector-comparison.validate+0x20c>
    68d8:      	ldr	x3, [x3, #0x8]
    68dc:      	cmp	x1, x3
    68e0:      	b.ge	0x6918 <_stogir.vector-comparison.validate+0x20c>
    68e4:      	ldr	x1, [x0, #0x78]
    68e8:      	add	x1, x5, x1
    68ec:      	ldr	w1, [x1]
    68f0:      	sxtw	x1, w1
    68f4:      	cmp	x1, #0x0
    68f8:      	b.lt	0x6918 <_stogir.vector-comparison.validate+0x20c>
    68fc:      	ldr	x1, [x0]
    6900:      	add	x1, x7, x1
    6904:      	ldr	x1, [x1]
    6908:      	mov	w3, #0x1                ; =1
    690c:      	b	0x6920 <_stogir.vector-comparison.validate+0x214>
    6910:      	movz	x4, #0x0, lsl #48
    6914:      	b	0x67d0 <_stogir.vector-comparison.validate+0xc4>
    6918:      	movz	w3, #0x0, lsl #16
    691c:      	movz	x1, #0x0, lsl #48
    6920:      	ubfx	x3, x3, #0, #32
    6924:      	lsr	x16, x3, #0
    6928:      	cmp	x16, #0x1
    692c:      	b.eq	0x6948 <_stogir.vector-comparison.validate+0x23c>
    6930:      	b.lo	0x6938 <_stogir.vector-comparison.validate+0x22c>
    6934:      	b	0x694c <_stogir.vector-comparison.validate+0x240>
    6938:      	cmp	x16, #0x0
    693c:      	b.eq	0x6944 <_stogir.vector-comparison.validate+0x238>
    6940:      	b	0x694c <_stogir.vector-comparison.validate+0x240>
    6944:      	b	0x6950 <_stogir.vector-comparison.validate+0x244>
    6948:      	b	0x6958 <_stogir.vector-comparison.validate+0x24c>
    694c:      	b	0x6a18 <_stogir.vector-comparison.validate+0x30c>
    6950:      	mov	x19, x8
    6954:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1a4>
    6958:      	uxtb	w3, w1
    695c:      	cmp	x3, #0xe
    6960:      	b.lt	0x6a20 <_stogir.vector-comparison.validate+0x314>
    6964:      	cmp	x3, #0x19
    6968:      	b.gt	0x6a28 <_stogir.vector-comparison.validate+0x31c>
    696c:      	ubfx	x1, x1, #0, #32
    6970:      	ubfx	x1, x1, #8, #8
    6974:      	orr	x3, x1, xzr
    6978:      	cmp	x3, #0xf
    697c:      	b.le	0x6a30 <_stogir.vector-comparison.validate+0x324>
    6980:      	cmp	x3, #0x80
    6984:      	b.ge	0x6a38 <_stogir.vector-comparison.validate+0x32c>
    6988:      	and	w1, w1, #0xf
    698c:      	ubfx	x1, x1, #0, #32
    6990:      	cmp	x1, #0x1
    6994:      	b.lt	0x6a40 <_stogir.vector-comparison.validate+0x334>
    6998:      	cmp	x1, #0xd
    699c:      	b.gt	0x6a48 <_stogir.vector-comparison.validate+0x33c>
    69a0:      	ldr	x1, [x0, #0x78]
    69a4:      	add	x1, x5, x1
    69a8:      	ldr	w1, [x1]
    69ac:      	sxtw	x1, w1
    69b0:      	cmp	x1, #0x2
    69b4:      	b.ne	0x6a50 <_stogir.vector-comparison.validate+0x344>
    69b8:      	add	x16, sp, #0x10
    69bc:      	ldr	w1, [x16]
    69c0:      	uxtb	w3, w1
    69c4:      	add	x16, sp, #0x10
    69c8:      	ldr	w4, [x16, #0x4]
    69cc:      	ubfx	x1, x1, #8, #8
    69d0:      	add	x16, sp, #0x10
    69d4:      	ldr	w5, [x16, #0x8]
    69d8:      	mov	x19, x8
    69dc:      	add	x8, sp, #0x20
    69e0:      	fmov	s31, w1
    69e4:      	mov	w1, w3
    69e8:      	mov	w3, w2
    69ec:      	fmov	w2, s31
    69f0:      	bl	0x69f0 <_stogir.vector-comparison.validate+0x2e4>
		00000000000069f0:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    69f4:      	add	x16, sp, #0x20
    69f8:      	ldr	x0, [x16]
    69fc:      	add	x16, sp, #0x20
    6a00:      	ldr	x1, [x16, #0x8]
    6a04:      	add	x16, sp, #0x20
    6a08:      	ldr	x2, [x16, #0x10]
    6a0c:      	b	0x68c0 <_stogir.vector-comparison.validate+0x1b4>
    6a10:      	brk	#0
    6a14:      	b	0x6a10 <_stogir.vector-comparison.validate+0x304>
    6a18:      	brk	#0
    6a1c:      	b	0x6a18 <_stogir.vector-comparison.validate+0x30c>
    6a20:      	mov	x19, x8
    6a24:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1a4>
    6a28:      	mov	x19, x8
    6a2c:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1a4>
    6a30:      	mov	x19, x8
    6a34:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1a4>
    6a38:      	mov	x19, x8
    6a3c:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1a4>
    6a40:      	mov	x19, x8
    6a44:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1a4>
    6a48:      	mov	x19, x8
    6a4c:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1a4>
    6a50:      	mov	x19, x8
    6a54:      	b	0x68b0 <_stogir.vector-comparison.validate+0x1a4>

0000000000006a58 <_stogir.vector-arithmetic.node?>:
    6a58:      	sxtw	x1, w1
    6a5c:      	add	x2, x0, #0x28
    6a60:      	cmp	x1, #0x0
    6a64:      	cset	w3, gt
    6a68:      	movz	x16, #0x0, lsl #48
    6a6c:      	sub	x4, x16, x1
    6a70:      	sub	x5, x4, #0x1
    6a74:      	uxtb	w16, w3
    6a78:      	cmp	w16, wzr
    6a7c:      	b.eq	0x6abc <_stogir.vector-arithmetic.node?+0x64>
    6a80:      	ldr	x2, [x0, #0x8]
    6a84:      	cmp	x1, x2
    6a88:      	b.ge	0x6b08 <_stogir.vector-arithmetic.node?+0xb0>
    6a8c:      	add	x2, x0, #0x78
    6a90:      	ldr	x2, [x2, #0x8]
    6a94:      	cmp	x1, x2
    6a98:      	b.ge	0x6c2c <_stogir.vector-arithmetic.node?+0x1d4>
    6a9c:      	ldr	x2, [x0, #0x78]
    6aa0:      	add	x2, x2, x1, lsl #2
    6aa4:      	ldr	w2, [x2]
    6aa8:      	sxtw	x2, w2
    6aac:      	cmp	x2, #0x0
    6ab0:      	cset	w2, ge
    6ab4:      	ubfx	x2, x2, #0, #8
    6ab8:      	b	0x6c30 <_stogir.vector-arithmetic.node?+0x1d8>
    6abc:      	cmp	x1, #0x0
    6ac0:      	b.ge	0x6b10 <_stogir.vector-arithmetic.node?+0xb8>
    6ac4:      	add	x6, x0, #0x50
    6ac8:      	ldr	x2, [x2, #0x8]
    6acc:      	ldr	x6, [x6, #0x8]
    6ad0:      	cmp	x2, x6
    6ad4:      	b.ne	0x6b00 <_stogir.vector-arithmetic.node?+0xa8>
    6ad8:      	cmp	x4, x2
    6adc:      	b.gt	0x6c3c <_stogir.vector-arithmetic.node?+0x1e4>
    6ae0:      	ldr	x2, [x0, #0x50]
    6ae4:      	add	x2, x2, x5, lsl #2
    6ae8:      	ldr	w2, [x2]
    6aec:      	sxtw	x2, w2
    6af0:      	cmp	x2, #0x0
    6af4:      	cset	w2, gt
    6af8:      	ubfx	x2, x2, #0, #8
    6afc:      	b	0x6c40 <_stogir.vector-arithmetic.node?+0x1e8>
    6b00:      	movz	x2, #0x0, lsl #48
    6b04:      	b	0x6b14 <_stogir.vector-arithmetic.node?+0xbc>
    6b08:      	movz	x2, #0x0, lsl #48
    6b0c:      	b	0x6b14 <_stogir.vector-arithmetic.node?+0xbc>
    6b10:      	movz	x2, #0x0, lsl #48
    6b14:      	cmp	x2, #0x0
    6b18:      	b.eq	0x6b4c <_stogir.vector-arithmetic.node?+0xf4>
    6b1c:      	uxtb	w16, w3
    6b20:      	cmp	w16, wzr
    6b24:      	b.eq	0x6b38 <_stogir.vector-arithmetic.node?+0xe0>
    6b28:      	ldr	x0, [x0]
    6b2c:      	add	x0, x0, x1, lsl #4
    6b30:      	ldr	x0, [x0]
    6b34:      	b	0x6b44 <_stogir.vector-arithmetic.node?+0xec>
    6b38:      	ldr	x0, [x0, #0x28]
    6b3c:      	add	x0, x0, x5, lsl #4
    6b40:      	ldr	x0, [x0]
    6b44:      	mov	w1, #0x1                ; =1
    6b48:      	b	0x6b54 <_stogir.vector-arithmetic.node?+0xfc>
    6b4c:      	movz	w1, #0x0, lsl #16
    6b50:      	movz	x0, #0x0, lsl #48
    6b54:      	ubfx	x1, x1, #0, #32
    6b58:      	lsr	x16, x1, #0
    6b5c:      	cmp	x16, #0x1
    6b60:      	b.eq	0x6b7c <_stogir.vector-arithmetic.node?+0x124>
    6b64:      	b.lo	0x6b6c <_stogir.vector-arithmetic.node?+0x114>
    6b68:      	b	0x6b80 <_stogir.vector-arithmetic.node?+0x128>
    6b6c:      	cmp	x16, #0x0
    6b70:      	b.eq	0x6b78 <_stogir.vector-arithmetic.node?+0x120>
    6b74:      	b	0x6b80 <_stogir.vector-arithmetic.node?+0x128>
    6b78:      	b	0x6b84 <_stogir.vector-arithmetic.node?+0x12c>
    6b7c:      	b	0x6b94 <_stogir.vector-arithmetic.node?+0x13c>
    6b80:      	b	0x6c4c <_stogir.vector-arithmetic.node?+0x1f4>
    6b84:      	movz	x0, #0x0, lsl #48
    6b88:      	b	0x6b90 <_stogir.vector-arithmetic.node?+0x138>
    6b8c:      	movz	x0, #0x0, lsl #48
    6b90:      	ret
    6b94:      	uxtb	w1, w0
    6b98:      	cmp	x1, #0x1f
    6b9c:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6ba0:      	cmp	x1, #0x20
    6ba4:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6ba8:      	cmp	x1, #0x2d
    6bac:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6bb0:      	cmp	x1, #0x36
    6bb4:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6bb8:      	cmp	x1, #0x37
    6bbc:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6bc0:      	cmp	x1, #0x38
    6bc4:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6bc8:      	cmp	x1, #0x39
    6bcc:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6bd0:      	cmp	x1, #0x3a
    6bd4:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6bd8:      	cmp	x1, #0x3b
    6bdc:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6be0:      	cmp	x1, #0x31
    6be4:      	b.lt	0x6c54 <_stogir.vector-arithmetic.node?+0x1fc>
    6be8:      	cmp	x1, #0x35
    6bec:      	b.gt	0x6c54 <_stogir.vector-arithmetic.node?+0x1fc>
    6bf0:      	ubfx	x0, x0, #0, #32
    6bf4:      	ubfx	x0, x0, #8, #8
    6bf8:      	orr	x1, x0, xzr
    6bfc:      	cmp	x1, #0xf
    6c00:      	b.le	0x6b8c <_stogir.vector-arithmetic.node?+0x134>
    6c04:      	cmp	x1, #0x80
    6c08:      	b.ge	0x6c34 <_stogir.vector-arithmetic.node?+0x1dc>
    6c0c:      	and	w0, w0, #0xf
    6c10:      	ubfx	x0, x0, #0, #32
    6c14:      	cmp	x0, #0x1
    6c18:      	b.lt	0x6c44 <_stogir.vector-arithmetic.node?+0x1ec>
    6c1c:      	cmp	x0, #0xd
    6c20:      	cset	w0, le
    6c24:      	ubfx	x0, x0, #0, #8
    6c28:      	b	0x6c48 <_stogir.vector-arithmetic.node?+0x1f0>
    6c2c:      	movz	x2, #0x0, lsl #48
    6c30:      	b	0x6b0c <_stogir.vector-arithmetic.node?+0xb4>
    6c34:      	movz	x0, #0x0, lsl #48
    6c38:      	b	0x6b90 <_stogir.vector-arithmetic.node?+0x138>
    6c3c:      	movz	x2, #0x0, lsl #48
    6c40:      	b	0x6b04 <_stogir.vector-arithmetic.node?+0xac>
    6c44:      	movz	x0, #0x0, lsl #48
    6c48:      	b	0x6c38 <_stogir.vector-arithmetic.node?+0x1e0>
    6c4c:      	brk	#0
    6c50:      	b	0x6c4c <_stogir.vector-arithmetic.node?+0x1f4>
    6c54:      	cmp	x1, #0x1a
    6c58:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6c5c:      	cmp	x1, #0x1b
    6c60:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6c64:      	cmp	x1, #0x1c
    6c68:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6c6c:      	cmp	x1, #0x1d
    6c70:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6c74:      	cmp	x1, #0x1e
    6c78:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6c7c:      	cmp	x1, #0x2e
    6c80:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6c84:      	cmp	x1, #0x2f
    6c88:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6c8c:      	cmp	x1, #0x30
    6c90:      	b.eq	0x6bf0 <_stogir.vector-arithmetic.node?+0x198>
    6c94:      	movz	x0, #0x0, lsl #48
    6c98:      	b	0x6b90 <_stogir.vector-arithmetic.node?+0x138>

0000000000006c9c <_stogir.vector-arithmetic.validate>:
    6c9c:      	sub	sp, sp, #0x60
    6ca0:      	str	x29, [sp]
    6ca4:      	str	x30, [sp, #0x8]
    6ca8:      	mov	x29, sp
    6cac:      	str	x19, [sp, #0x40]
    6cb0:      	str	x20, [sp, #0x48]
    6cb4:      	str	x21, [sp, #0x50]
    6cb8:      	str	x22, [sp, #0x58]
    6cbc:      	sxtw	x2, w1
    6cc0:      	add	x3, x0, #0x78
    6cc4:      	add	x4, x0, #0x28
    6cc8:      	lsl	x19, x2, #2
    6ccc:      	cmp	x2, #0x0
    6cd0:      	cset	w5, gt
    6cd4:      	movz	x16, #0x0, lsl #48
    6cd8:      	sub	x6, x16, x2
    6cdc:      	sub	x7, x6, #0x1
    6ce0:      	uxtb	w16, w5
    6ce4:      	cmp	w16, wzr
    6ce8:      	b.eq	0x6d24 <_stogir.vector-arithmetic.validate+0x88>
    6cec:      	ldr	x4, [x0, #0x8]
    6cf0:      	cmp	x2, x4
    6cf4:      	b.ge	0x6d70 <_stogir.vector-arithmetic.validate+0xd4>
    6cf8:      	ldr	x3, [x3, #0x8]
    6cfc:      	cmp	x2, x3
    6d00:      	b.ge	0x6e68 <_stogir.vector-arithmetic.validate+0x1cc>
    6d04:      	ldr	x3, [x0, #0x78]
    6d08:      	add	x3, x19, x3
    6d0c:      	ldr	w3, [x3]
    6d10:      	sxtw	x3, w3
    6d14:      	cmp	x3, #0x0
    6d18:      	cset	w3, ge
    6d1c:      	ubfx	x3, x3, #0, #8
    6d20:      	b	0x6e6c <_stogir.vector-arithmetic.validate+0x1d0>
    6d24:      	cmp	x2, #0x0
    6d28:      	b.ge	0x6d78 <_stogir.vector-arithmetic.validate+0xdc>
    6d2c:      	add	x3, x0, #0x50
    6d30:      	ldr	x4, [x4, #0x8]
    6d34:      	ldr	x3, [x3, #0x8]
    6d38:      	cmp	x4, x3
    6d3c:      	b.ne	0x6d68 <_stogir.vector-arithmetic.validate+0xcc>
    6d40:      	cmp	x6, x4
    6d44:      	b.gt	0x6f00 <_stogir.vector-arithmetic.validate+0x264>
    6d48:      	ldr	x3, [x0, #0x50]
    6d4c:      	add	x3, x3, x7, lsl #2
    6d50:      	ldr	w3, [x3]
    6d54:      	sxtw	x3, w3
    6d58:      	cmp	x3, #0x0
    6d5c:      	cset	w3, gt
    6d60:      	ubfx	x3, x3, #0, #8
    6d64:      	b	0x6f04 <_stogir.vector-arithmetic.validate+0x268>
    6d68:      	movz	x3, #0x0, lsl #48
    6d6c:      	b	0x6d7c <_stogir.vector-arithmetic.validate+0xe0>
    6d70:      	movz	x3, #0x0, lsl #48
    6d74:      	b	0x6d7c <_stogir.vector-arithmetic.validate+0xe0>
    6d78:      	movz	x3, #0x0, lsl #48
    6d7c:      	cmp	x3, #0x0
    6d80:      	b.eq	0x6dbc <_stogir.vector-arithmetic.validate+0x120>
    6d84:      	uxtb	w16, w5
    6d88:      	cmp	w16, wzr
    6d8c:      	b.eq	0x6da4 <_stogir.vector-arithmetic.validate+0x108>
    6d90:      	ldr	x3, [x0]
    6d94:      	add	x3, x3, x2, lsl #4
    6d98:      	ldr	x20, [x3]
    6d9c:      	ldr	x3, [x3, #0x8]
    6da0:      	b	0x6db4 <_stogir.vector-arithmetic.validate+0x118>
    6da4:      	ldr	x3, [x0, #0x28]
    6da8:      	add	x3, x3, x7, lsl #4
    6dac:      	ldr	x20, [x3]
    6db0:      	ldr	x3, [x3, #0x8]
    6db4:      	mov	w4, #0x1                ; =1
    6db8:      	b	0x6dc8 <_stogir.vector-arithmetic.validate+0x12c>
    6dbc:      	movz	w4, #0x0, lsl #16
    6dc0:      	movz	x20, #0x0, lsl #48
    6dc4:      	movz	x3, #0x0, lsl #48
    6dc8:      	ubfx	x4, x4, #0, #32
    6dcc:      	lsr	x16, x4, #0
    6dd0:      	cmp	x16, #0x1
    6dd4:      	b.eq	0x6df0 <_stogir.vector-arithmetic.validate+0x154>
    6dd8:      	b.lo	0x6de0 <_stogir.vector-arithmetic.validate+0x144>
    6ddc:      	b	0x6df4 <_stogir.vector-arithmetic.validate+0x158>
    6de0:      	cmp	x16, #0x0
    6de4:      	b.eq	0x6dec <_stogir.vector-arithmetic.validate+0x150>
    6de8:      	b	0x6df4 <_stogir.vector-arithmetic.validate+0x158>
    6dec:      	b	0x6df8 <_stogir.vector-arithmetic.validate+0x15c>
    6df0:      	b	0x6e10 <_stogir.vector-arithmetic.validate+0x174>
    6df4:      	b	0x6f98 <_stogir.vector-arithmetic.validate+0x2fc>
    6df8:      	mov	x21, x8
    6dfc:      	mov	x0, #0x1                ; =1
    6e00:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x488>
		0000000000006e00:  ARM64_RELOC_PAGE21	l_stogir.418
    6e04:      	ldr	x1, [x1]
		0000000000006e04:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    6e08:      	mov	x2, #0x25               ; =37
    6e0c:      	b	0x6e3c <_stogir.vector-arithmetic.validate+0x1a0>
    6e10:      	add	x16, sp, #0x10
    6e14:      	str	x20, [x16]
    6e18:      	add	x16, sp, #0x10
    6e1c:      	str	x3, [x16, #0x8]
    6e20:      	cmp	x2, #0x0
    6e24:      	b.gt	0x6e70 <_stogir.vector-arithmetic.validate+0x1d4>
    6e28:      	mov	x21, x8
    6e2c:      	mov	x0, #0x1                ; =1
    6e30:      	adrp	x1, 0x6000 <_stogir.floating.validate+0x488>
		0000000000006e30:  ARM64_RELOC_PAGE21	l_stogir.419
    6e34:      	ldr	x1, [x1]
		0000000000006e34:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    6e38:      	mov	x2, #0x2b               ; =43
    6e3c:      	str	x0, [x21]
    6e40:      	str	x1, [x21, #0x8]
    6e44:      	str	x2, [x21, #0x10]
    6e48:      	ldr	x19, [sp, #0x40]
    6e4c:      	ldr	x20, [sp, #0x48]
    6e50:      	ldr	x21, [sp, #0x50]
    6e54:      	ldr	x22, [sp, #0x58]
    6e58:      	ldr	x29, [sp]
    6e5c:      	ldr	x30, [sp, #0x8]
    6e60:      	add	sp, sp, #0x60
    6e64:      	ret
    6e68:      	movz	x3, #0x0, lsl #48
    6e6c:      	b	0x6d74 <_stogir.vector-arithmetic.validate+0xd8>
    6e70:      	mov	x21, x8
    6e74:      	mov	x22, x0
    6e78:      	bl	0x6e78 <_stogir.vector-arithmetic.validate+0x1dc>
		0000000000006e78:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    6e7c:      	cmp	x0, #0x0
    6e80:      	b.eq	0x6e2c <_stogir.vector-arithmetic.validate+0x190>
    6e84:      	uxtb	w20, w20
    6e88:      	ldr	x0, [x22, #0x78]
    6e8c:      	orr	x1, x20, xzr
    6e90:      	cmp	x1, #0x1d
    6e94:      	cset	w2, eq
    6e98:      	cmp	x1, #0x1e
    6e9c:      	cset	w3, eq
    6ea0:      	add	x0, x19, x0
    6ea4:      	ldr	w0, [x0]
    6ea8:      	cmp	x1, #0x1f
    6eac:      	b.eq	0x6f4c <_stogir.vector-arithmetic.validate+0x2b0>
    6eb0:      	cmp	x1, #0x20
    6eb4:      	b.eq	0x6f4c <_stogir.vector-arithmetic.validate+0x2b0>
    6eb8:      	cmp	x1, #0x2d
    6ebc:      	b.eq	0x6f4c <_stogir.vector-arithmetic.validate+0x2b0>
    6ec0:      	cmp	x1, #0x36
    6ec4:      	b.eq	0x6f4c <_stogir.vector-arithmetic.validate+0x2b0>
    6ec8:      	cmp	x1, #0x37
    6ecc:      	b.eq	0x6f4c <_stogir.vector-arithmetic.validate+0x2b0>
    6ed0:      	cmp	x1, #0x38
    6ed4:      	b.eq	0x6f4c <_stogir.vector-arithmetic.validate+0x2b0>
    6ed8:      	cmp	x1, #0x39
    6edc:      	b.eq	0x6f4c <_stogir.vector-arithmetic.validate+0x2b0>
    6ee0:      	uxtb	w16, w2
    6ee4:      	cmp	w16, wzr
    6ee8:      	b.ne	0x6fa0 <_stogir.vector-arithmetic.validate+0x304>
    6eec:      	uxtb	w16, w3
    6ef0:      	cmp	w16, wzr
    6ef4:      	b.ne	0x6fa0 <_stogir.vector-arithmetic.validate+0x304>
    6ef8:      	mov	w1, #0x2                ; =2
    6efc:      	b	0x6fa4 <_stogir.vector-arithmetic.validate+0x308>
    6f00:      	movz	x3, #0x0, lsl #48
    6f04:      	b	0x6d6c <_stogir.vector-arithmetic.validate+0xd0>
    6f08:      	add	x16, sp, #0x10
    6f0c:      	ldr	w2, [x16, #0xc]
    6f10:      	ubfx	x0, x0, #8, #8
    6f14:      	add	x8, sp, #0x20
    6f18:      	mov	w3, w1
    6f1c:      	mov	w1, w20
    6f20:      	mov	w5, w2
    6f24:      	mov	w2, w0
    6f28:      	mov	x0, x22
    6f2c:      	bl	0x6f2c <_stogir.vector-arithmetic.validate+0x290>
		0000000000006f2c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    6f30:      	add	x16, sp, #0x20
    6f34:      	ldr	x0, [x16]
    6f38:      	add	x16, sp, #0x20
    6f3c:      	ldr	x1, [x16, #0x8]
    6f40:      	add	x16, sp, #0x20
    6f44:      	ldr	x2, [x16, #0x10]
    6f48:      	b	0x6e3c <_stogir.vector-arithmetic.validate+0x1a0>
    6f4c:      	mov	w1, #0x1                ; =1
    6f50:      	sxtw	x0, w0
    6f54:      	sxtw	x1, w1
    6f58:      	cmp	x0, x1
    6f5c:      	b.ne	0x6e2c <_stogir.vector-arithmetic.validate+0x190>
    6f60:      	add	x16, sp, #0x10
    6f64:      	ldr	w0, [x16]
    6f68:      	add	x16, sp, #0x10
    6f6c:      	ldr	w1, [x16, #0x4]
    6f70:      	add	x16, sp, #0x10
    6f74:      	ldr	w4, [x16, #0x8]
    6f78:      	uxtb	w16, w2
    6f7c:      	cmp	w16, wzr
    6f80:      	b.ne	0x6f08 <_stogir.vector-arithmetic.validate+0x26c>
    6f84:      	uxtb	w16, w3
    6f88:      	cmp	w16, wzr
    6f8c:      	b.ne	0x6f08 <_stogir.vector-arithmetic.validate+0x26c>
    6f90:      	movz	w2, #0x0, lsl #16
    6f94:      	b	0x6f10 <_stogir.vector-arithmetic.validate+0x274>
    6f98:      	brk	#0
    6f9c:      	b	0x6f98 <_stogir.vector-arithmetic.validate+0x2fc>
    6fa0:      	mov	w1, #0x3                ; =3
    6fa4:      	b	0x6f50 <_stogir.vector-arithmetic.validate+0x2b4>

0000000000006fa8 <_stogir.vector.memory-inputs>:
    6fa8:      	sub	sp, sp, #0x40
    6fac:      	str	x29, [sp]
    6fb0:      	str	x30, [sp, #0x8]
    6fb4:      	mov	x29, sp
    6fb8:      	str	x19, [sp, #0x10]
    6fbc:      	str	x20, [sp, #0x18]
    6fc0:      	str	x21, [sp, #0x20]
    6fc4:      	str	x22, [sp, #0x28]
    6fc8:      	str	x23, [sp, #0x30]
    6fcc:      	str	x24, [sp, #0x38]
    6fd0:      	sxtw	x5, w1
    6fd4:      	cmp	x5, #0xf
    6fd8:      	b.le	0x7424 <_stogir.vector.memory-inputs+0x47c>
    6fdc:      	cmp	x5, #0x80
    6fe0:      	b.ge	0x742c <_stogir.vector.memory-inputs+0x484>
    6fe4:      	and	w5, w1, #0xf
    6fe8:      	ubfx	x5, x5, #0, #32
    6fec:      	cmp	x5, #0x1
    6ff0:      	b.lt	0x7434 <_stogir.vector.memory-inputs+0x48c>
    6ff4:      	cmp	x5, #0xd
    6ff8:      	b.gt	0x743c <_stogir.vector.memory-inputs+0x494>
    6ffc:      	mov	x19, x8
    7000:      	mov	x20, x0
    7004:      	mov	w0, w1
    7008:      	mov	w21, w1
    700c:      	mov	w1, w2
    7010:      	mov	w22, w2
    7014:      	mov	w23, w3
    7018:      	mov	w24, w4
    701c:      	bl	0x701c <_stogir.vector.memory-inputs+0x74>
		000000000000701c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    7020:      	sxtw	x0, w0
    7024:      	cmp	x0, #0x0
    7028:      	b.le	0x7094 <_stogir.vector.memory-inputs+0xec>
    702c:      	sxtw	x23, w23
    7030:      	cmp	x23, #0x0
    7034:      	cset	w0, gt
    7038:      	movz	x16, #0x0, lsl #48
    703c:      	sub	x1, x16, x23
    7040:      	add	x2, x20, #0x28
    7044:      	add	x3, x20, #0x78
    7048:      	add	x4, x20, #0x50
    704c:      	sub	x5, x1, #0x1
    7050:      	uxtb	w16, w0
    7054:      	cmp	w16, wzr
    7058:      	b.eq	0x7168 <_stogir.vector.memory-inputs+0x1c0>
    705c:      	ldr	x1, [x20, #0x8]
    7060:      	cmp	x23, x1
    7064:      	b.ge	0x7160 <_stogir.vector.memory-inputs+0x1b8>
    7068:      	ldr	x1, [x3, #0x8]
    706c:      	cmp	x23, x1
    7070:      	b.ge	0x71f8 <_stogir.vector.memory-inputs+0x250>
    7074:      	ldr	x1, [x20, #0x78]
    7078:      	add	x1, x1, x23, lsl #2
    707c:      	ldr	w1, [x1]
    7080:      	sxtw	x1, w1
    7084:      	cmp	x1, #0x0
    7088:      	cset	w1, ge
    708c:      	ubfx	x1, x1, #0, #8
    7090:      	b	0x71fc <_stogir.vector.memory-inputs+0x254>
    7094:      	mov	x1, #0x1                ; =1
    7098:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007098:  ARM64_RELOC_PAGE21	l_stogir.420
    709c:      	ldr	x0, [x0]
		000000000000709c:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    70a0:      	mov	x2, #0x32               ; =50
    70a4:      	str	x1, [x19]
    70a8:      	str	x0, [x19, #0x8]
    70ac:      	str	x2, [x19, #0x10]
    70b0:      	ldr	x19, [sp, #0x10]
    70b4:      	ldr	x20, [sp, #0x18]
    70b8:      	ldr	x21, [sp, #0x20]
    70bc:      	ldr	x22, [sp, #0x28]
    70c0:      	ldr	x23, [sp, #0x30]
    70c4:      	ldr	x24, [sp, #0x38]
    70c8:      	ldr	x29, [sp]
    70cc:      	ldr	x30, [sp, #0x8]
    70d0:      	add	sp, sp, #0x40
    70d4:      	ret
    70d8:      	movz	w1, #0x0, lsl #16
    70dc:      	movz	x0, #0x0, lsl #48
    70e0:      	ubfx	x1, x1, #0, #32
    70e4:      	lsr	x16, x1, #0
    70e8:      	cmp	x16, #0x1
    70ec:      	b.eq	0x7108 <_stogir.vector.memory-inputs+0x160>
    70f0:      	b.lo	0x70f8 <_stogir.vector.memory-inputs+0x150>
    70f4:      	b	0x710c <_stogir.vector.memory-inputs+0x164>
    70f8:      	cmp	x16, #0x0
    70fc:      	b.eq	0x7104 <_stogir.vector.memory-inputs+0x15c>
    7100:      	b	0x710c <_stogir.vector.memory-inputs+0x164>
    7104:      	b	0x7110 <_stogir.vector.memory-inputs+0x168>
    7108:      	b	0x71a8 <_stogir.vector.memory-inputs+0x200>
    710c:      	b	0x740c <_stogir.vector.memory-inputs+0x464>
    7110:      	mov	x1, #0x1                ; =1
    7114:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007114:  ARM64_RELOC_PAGE21	l_stogir.421
    7118:      	ldr	x0, [x0]
		0000000000007118:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    711c:      	mov	x2, #0x1d               ; =29
    7120:      	b	0x70a4 <_stogir.vector.memory-inputs+0xfc>
    7124:      	ldr	x0, [x20, #0x28]
    7128:      	add	x0, x0, x5, lsl #4
    712c:      	ldr	x0, [x0]
    7130:      	mov	w1, #0x1                ; =1
    7134:      	b	0x70e0 <_stogir.vector.memory-inputs+0x138>
    7138:      	movz	x1, #0x0, lsl #48
    713c:      	cmp	x1, #0x0
    7140:      	b.eq	0x70d8 <_stogir.vector.memory-inputs+0x130>
    7144:      	uxtb	w16, w0
    7148:      	cmp	w16, wzr
    714c:      	b.eq	0x7124 <_stogir.vector.memory-inputs+0x17c>
    7150:      	ldr	x0, [x20]
    7154:      	add	x0, x0, x23, lsl #4
    7158:      	ldr	x0, [x0]
    715c:      	b	0x7130 <_stogir.vector.memory-inputs+0x188>
    7160:      	movz	x1, #0x0, lsl #48
    7164:      	b	0x713c <_stogir.vector.memory-inputs+0x194>
    7168:      	cmp	x23, #0x0
    716c:      	b.ge	0x7138 <_stogir.vector.memory-inputs+0x190>
    7170:      	ldr	x6, [x2, #0x8]
    7174:      	ldr	x7, [x4, #0x8]
    7178:      	cmp	x6, x7
    717c:      	b.ne	0x71f0 <_stogir.vector.memory-inputs+0x248>
    7180:      	cmp	x1, x6
    7184:      	b.gt	0x7200 <_stogir.vector.memory-inputs+0x258>
    7188:      	ldr	x1, [x20, #0x50]
    718c:      	add	x1, x1, x5, lsl #2
    7190:      	ldr	w1, [x1]
    7194:      	sxtw	x1, w1
    7198:      	cmp	x1, #0x0
    719c:      	cset	w1, gt
    71a0:      	ubfx	x1, x1, #0, #8
    71a4:      	b	0x7204 <_stogir.vector.memory-inputs+0x25c>
    71a8:      	cmp	x23, #0x0
    71ac:      	b.le	0x71dc <_stogir.vector.memory-inputs+0x234>
    71b0:      	uxtb	w0, w0
    71b4:      	cmp	x0, #0x83
    71b8:      	cset	w1, lt
    71bc:      	uxtb	w16, w1
    71c0:      	cmp	w16, wzr
    71c4:      	b.eq	0x7208 <_stogir.vector.memory-inputs+0x260>
    71c8:      	adrp	x17, 0x7000 <_stogir.vector.memory-inputs+0x58>
		00000000000071c8:  ARM64_RELOC_PAGE21	l_stogir.422
    71cc:      	ldr	x17, [x17]
		00000000000071cc:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    71d0:      	add	x5, x0, x17
    71d4:      	ldrb	w5, [x5]
    71d8:      	b	0x720c <_stogir.vector.memory-inputs+0x264>
    71dc:      	mov	x1, #0x1                ; =1
    71e0:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x58>
		00000000000071e0:  ARM64_RELOC_PAGE21	l_stogir.423
    71e4:      	ldr	x0, [x0]
		00000000000071e4:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    71e8:      	mov	x2, #0x2c               ; =44
    71ec:      	b	0x7120 <_stogir.vector.memory-inputs+0x178>
    71f0:      	movz	x1, #0x0, lsl #48
    71f4:      	b	0x713c <_stogir.vector.memory-inputs+0x194>
    71f8:      	movz	x1, #0x0, lsl #48
    71fc:      	b	0x7164 <_stogir.vector.memory-inputs+0x1bc>
    7200:      	movz	x1, #0x0, lsl #48
    7204:      	b	0x71f4 <_stogir.vector.memory-inputs+0x24c>
    7208:      	movz	w5, #0x0, lsl #16
    720c:      	uxtb	w16, w5
    7210:      	and	w5, w16, #0x1
    7214:      	uxtb	w5, w5
    7218:      	ubfx	x5, x5, #0, #8
    721c:      	cmp	x5, #0x0
    7220:      	b.eq	0x71dc <_stogir.vector.memory-inputs+0x234>
    7224:      	uxtb	w16, w1
    7228:      	cmp	w16, wzr
    722c:      	b.eq	0x7244 <_stogir.vector.memory-inputs+0x29c>
    7230:      	adrp	x17, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007230:  ARM64_RELOC_PAGE21	l_stogir.422
    7234:      	ldr	x17, [x17]
		0000000000007234:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    7238:      	add	x0, x0, x17
    723c:      	ldrb	w0, [x0]
    7240:      	b	0x7248 <_stogir.vector.memory-inputs+0x2a0>
    7244:      	movz	w0, #0x0, lsl #16
    7248:      	uxtb	w16, w0
    724c:      	and	w0, w16, #0x4
    7250:      	uxtb	w0, w0
    7254:      	ubfx	x0, x0, #0, #8
    7258:      	cmp	x0, #0x0
    725c:      	cset	w0, eq
    7260:      	uxtb	w16, w0
    7264:      	cmp	w16, wzr
    7268:      	cset	x0, eq
    726c:      	cmp	x0, #0x0
    7270:      	b.ne	0x71dc <_stogir.vector.memory-inputs+0x234>
    7274:      	sxtw	x24, w24
    7278:      	cmp	x24, #0x0
    727c:      	cset	w0, gt
    7280:      	movz	x16, #0x0, lsl #48
    7284:      	sub	x1, x16, x24
    7288:      	sub	x5, x1, #0x1
    728c:      	uxtb	w16, w0
    7290:      	cmp	w16, wzr
    7294:      	b.eq	0x72e4 <_stogir.vector.memory-inputs+0x33c>
    7298:      	ldr	x1, [x20, #0x8]
    729c:      	cmp	x24, x1
    72a0:      	b.ge	0x7324 <_stogir.vector.memory-inputs+0x37c>
    72a4:      	ldr	x1, [x3, #0x8]
    72a8:      	cmp	x24, x1
    72ac:      	b.ge	0x7404 <_stogir.vector.memory-inputs+0x45c>
    72b0:      	ldr	x1, [x20, #0x78]
    72b4:      	add	x1, x1, x24, lsl #2
    72b8:      	ldr	w1, [x1]
    72bc:      	sxtw	x1, w1
    72c0:      	cmp	x1, #0x0
    72c4:      	cset	w1, ge
    72c8:      	ubfx	x1, x1, #0, #8
    72cc:      	b	0x7408 <_stogir.vector.memory-inputs+0x460>
    72d0:      	mov	x1, #0x1                ; =1
    72d4:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x58>
		00000000000072d4:  ARM64_RELOC_PAGE21	l_stogir.424
    72d8:      	ldr	x0, [x0]
		00000000000072d8:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    72dc:      	mov	x2, #0x2b               ; =43
    72e0:      	b	0x71ec <_stogir.vector.memory-inputs+0x244>
    72e4:      	cmp	x24, #0x0
    72e8:      	b.ge	0x732c <_stogir.vector.memory-inputs+0x384>
    72ec:      	ldr	x2, [x2, #0x8]
    72f0:      	ldr	x3, [x4, #0x8]
    72f4:      	cmp	x2, x3
    72f8:      	b.ne	0x73fc <_stogir.vector.memory-inputs+0x454>
    72fc:      	cmp	x1, x2
    7300:      	b.gt	0x7414 <_stogir.vector.memory-inputs+0x46c>
    7304:      	ldr	x1, [x20, #0x50]
    7308:      	add	x1, x1, x5, lsl #2
    730c:      	ldr	w1, [x1]
    7310:      	sxtw	x1, w1
    7314:      	cmp	x1, #0x0
    7318:      	cset	w1, gt
    731c:      	ubfx	x1, x1, #0, #8
    7320:      	b	0x7418 <_stogir.vector.memory-inputs+0x470>
    7324:      	movz	x1, #0x0, lsl #48
    7328:      	b	0x7330 <_stogir.vector.memory-inputs+0x388>
    732c:      	movz	x1, #0x0, lsl #48
    7330:      	cmp	x1, #0x0
    7334:      	b.eq	0x7368 <_stogir.vector.memory-inputs+0x3c0>
    7338:      	uxtb	w16, w0
    733c:      	cmp	w16, wzr
    7340:      	b.eq	0x7354 <_stogir.vector.memory-inputs+0x3ac>
    7344:      	ldr	x0, [x20]
    7348:      	add	x0, x0, x24, lsl #4
    734c:      	ldr	x0, [x0]
    7350:      	b	0x7360 <_stogir.vector.memory-inputs+0x3b8>
    7354:      	ldr	x0, [x20, #0x28]
    7358:      	add	x0, x0, x5, lsl #4
    735c:      	ldr	x0, [x0]
    7360:      	mov	w1, #0x1                ; =1
    7364:      	b	0x7370 <_stogir.vector.memory-inputs+0x3c8>
    7368:      	movz	w1, #0x0, lsl #16
    736c:      	movz	x0, #0x0, lsl #48
    7370:      	ubfx	x1, x1, #0, #32
    7374:      	lsr	x16, x1, #0
    7378:      	cmp	x16, #0x1
    737c:      	b.eq	0x7398 <_stogir.vector.memory-inputs+0x3f0>
    7380:      	b.lo	0x7388 <_stogir.vector.memory-inputs+0x3e0>
    7384:      	b	0x739c <_stogir.vector.memory-inputs+0x3f4>
    7388:      	cmp	x16, #0x0
    738c:      	b.eq	0x7394 <_stogir.vector.memory-inputs+0x3ec>
    7390:      	b	0x739c <_stogir.vector.memory-inputs+0x3f4>
    7394:      	b	0x73a0 <_stogir.vector.memory-inputs+0x3f8>
    7398:      	b	0x73b4 <_stogir.vector.memory-inputs+0x40c>
    739c:      	b	0x741c <_stogir.vector.memory-inputs+0x474>
    73a0:      	mov	x1, #0x1                ; =1
    73a4:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x58>
		00000000000073a4:  ARM64_RELOC_PAGE21	l_stogir.425
    73a8:      	ldr	x0, [x0]
		00000000000073a8:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    73ac:      	mov	x2, #0x1d               ; =29
    73b0:      	b	0x72e0 <_stogir.vector.memory-inputs+0x338>
    73b4:      	orr	w1, w0, wzr
    73b8:      	ubfx	x1, x1, #0, #32
    73bc:      	ubfx	x1, x1, #8, #8
    73c0:      	cmp	x1, #0x6
    73c4:      	b.ne	0x72d0 <_stogir.vector.memory-inputs+0x328>
    73c8:      	uxtb	w0, w0
    73cc:      	cmp	x0, #0x48
    73d0:      	b.eq	0x72d0 <_stogir.vector.memory-inputs+0x328>
    73d4:      	cmp	x0, #0x46
    73d8:      	b.eq	0x72d0 <_stogir.vector.memory-inputs+0x328>
    73dc:      	mov	w0, w21
    73e0:      	mov	w1, w22
    73e4:      	bl	0x73e4 <_stogir.vector.memory-inputs+0x43c>
		00000000000073e4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    73e8:      	sxtw	x0, w0
    73ec:      	and	x0, x0, #0xffffffff
    73f0:      	movz	x1, #0x0, lsl #48
    73f4:      	movz	x2, #0x0, lsl #48
    73f8:      	b	0x72e0 <_stogir.vector.memory-inputs+0x338>
    73fc:      	movz	x1, #0x0, lsl #48
    7400:      	b	0x7330 <_stogir.vector.memory-inputs+0x388>
    7404:      	movz	x1, #0x0, lsl #48
    7408:      	b	0x7328 <_stogir.vector.memory-inputs+0x380>
    740c:      	brk	#0
    7410:      	b	0x740c <_stogir.vector.memory-inputs+0x464>
    7414:      	movz	x1, #0x0, lsl #48
    7418:      	b	0x7400 <_stogir.vector.memory-inputs+0x458>
    741c:      	brk	#0
    7420:      	b	0x741c <_stogir.vector.memory-inputs+0x474>
    7424:      	mov	x19, x8
    7428:      	b	0x7094 <_stogir.vector.memory-inputs+0xec>
    742c:      	mov	x19, x8
    7430:      	b	0x7094 <_stogir.vector.memory-inputs+0xec>
    7434:      	mov	x19, x8
    7438:      	b	0x7094 <_stogir.vector.memory-inputs+0xec>
    743c:      	mov	x19, x8
    7440:      	b	0x7094 <_stogir.vector.memory-inputs+0xec>

0000000000007444 <_stogir.vector.store-inputs>:
    7444:      	sub	sp, sp, #0x40
    7448:      	str	x29, [sp]
    744c:      	str	x30, [sp, #0x8]
    7450:      	mov	x29, sp
    7454:      	str	x19, [sp, #0x30]
    7458:      	sxtw	x4, w4
    745c:      	add	x5, x0, #0x28
    7460:      	cmp	x4, #0x0
    7464:      	cset	w6, gt
    7468:      	movz	x16, #0x0, lsl #48
    746c:      	sub	x7, x16, x4
    7470:      	sub	x9, x7, #0x1
    7474:      	uxtb	w16, w6
    7478:      	cmp	w16, wzr
    747c:      	b.eq	0x74bc <_stogir.vector.store-inputs+0x78>
    7480:      	ldr	x5, [x0, #0x8]
    7484:      	cmp	x4, x5
    7488:      	b.ge	0x7508 <_stogir.vector.store-inputs+0xc4>
    748c:      	add	x5, x0, #0x78
    7490:      	ldr	x5, [x5, #0x8]
    7494:      	cmp	x4, x5
    7498:      	b.ge	0x75fc <_stogir.vector.store-inputs+0x1b8>
    749c:      	ldr	x5, [x0, #0x78]
    74a0:      	add	x5, x5, x4, lsl #2
    74a4:      	ldr	w5, [x5]
    74a8:      	sxtw	x5, w5
    74ac:      	cmp	x5, #0x0
    74b0:      	cset	w5, ge
    74b4:      	ubfx	x5, x5, #0, #8
    74b8:      	b	0x7600 <_stogir.vector.store-inputs+0x1bc>
    74bc:      	cmp	x4, #0x0
    74c0:      	b.ge	0x7510 <_stogir.vector.store-inputs+0xcc>
    74c4:      	add	x10, x0, #0x50
    74c8:      	ldr	x5, [x5, #0x8]
    74cc:      	ldr	x10, [x10, #0x8]
    74d0:      	cmp	x5, x10
    74d4:      	b.ne	0x7500 <_stogir.vector.store-inputs+0xbc>
    74d8:      	cmp	x7, x5
    74dc:      	b.gt	0x7604 <_stogir.vector.store-inputs+0x1c0>
    74e0:      	ldr	x5, [x0, #0x50]
    74e4:      	add	x5, x5, x9, lsl #2
    74e8:      	ldr	w5, [x5]
    74ec:      	sxtw	x5, w5
    74f0:      	cmp	x5, #0x0
    74f4:      	cset	w5, gt
    74f8:      	ubfx	x5, x5, #0, #8
    74fc:      	b	0x7608 <_stogir.vector.store-inputs+0x1c4>
    7500:      	movz	x5, #0x0, lsl #48
    7504:      	b	0x7514 <_stogir.vector.store-inputs+0xd0>
    7508:      	movz	x5, #0x0, lsl #48
    750c:      	b	0x7514 <_stogir.vector.store-inputs+0xd0>
    7510:      	movz	x5, #0x0, lsl #48
    7514:      	cmp	x5, #0x0
    7518:      	b.eq	0x754c <_stogir.vector.store-inputs+0x108>
    751c:      	uxtb	w16, w6
    7520:      	cmp	w16, wzr
    7524:      	b.eq	0x7538 <_stogir.vector.store-inputs+0xf4>
    7528:      	ldr	x5, [x0]
    752c:      	add	x4, x5, x4, lsl #4
    7530:      	ldr	x4, [x4]
    7534:      	b	0x7544 <_stogir.vector.store-inputs+0x100>
    7538:      	ldr	x4, [x0, #0x28]
    753c:      	add	x4, x4, x9, lsl #4
    7540:      	ldr	x4, [x4]
    7544:      	mov	w5, #0x1                ; =1
    7548:      	b	0x7554 <_stogir.vector.store-inputs+0x110>
    754c:      	movz	w5, #0x0, lsl #16
    7550:      	movz	x4, #0x0, lsl #48
    7554:      	ubfx	x5, x5, #0, #32
    7558:      	lsr	x16, x5, #0
    755c:      	cmp	x16, #0x1
    7560:      	b.eq	0x757c <_stogir.vector.store-inputs+0x138>
    7564:      	b.lo	0x756c <_stogir.vector.store-inputs+0x128>
    7568:      	b	0x7580 <_stogir.vector.store-inputs+0x13c>
    756c:      	cmp	x16, #0x0
    7570:      	b.eq	0x7578 <_stogir.vector.store-inputs+0x134>
    7574:      	b	0x7580 <_stogir.vector.store-inputs+0x13c>
    7578:      	b	0x7584 <_stogir.vector.store-inputs+0x140>
    757c:      	b	0x759c <_stogir.vector.store-inputs+0x158>
    7580:      	b	0x760c <_stogir.vector.store-inputs+0x1c8>
    7584:      	mov	x19, x8
    7588:      	mov	x0, #0x1                ; =1
    758c:      	adrp	x1, 0x7000 <_stogir.vector.memory-inputs+0x58>
		000000000000758c:  ARM64_RELOC_PAGE21	l_stogir.426
    7590:      	ldr	x1, [x1]
		0000000000007590:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    7594:      	mov	x2, #0x1a               ; =26
    7598:      	b	0x75dc <_stogir.vector.store-inputs+0x198>
    759c:      	ubfx	x4, x4, #0, #32
    75a0:      	ubfx	x4, x4, #8, #8
    75a4:      	mov	x19, x8
    75a8:      	add	x8, sp, #0x10
    75ac:      	fmov	s31, w1
    75b0:      	mov	w1, w4
    75b4:      	mov	w4, w3
    75b8:      	mov	w3, w2
    75bc:      	fmov	w2, s31
    75c0:      	bl	0x75c0 <_stogir.vector.store-inputs+0x17c>
		00000000000075c0:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    75c4:      	add	x16, sp, #0x10
    75c8:      	ldr	x0, [x16]
    75cc:      	add	x16, sp, #0x10
    75d0:      	ldr	x1, [x16, #0x8]
    75d4:      	add	x16, sp, #0x10
    75d8:      	ldr	x2, [x16, #0x10]
    75dc:      	str	x0, [x19]
    75e0:      	str	x1, [x19, #0x8]
    75e4:      	str	x2, [x19, #0x10]
    75e8:      	ldr	x19, [sp, #0x30]
    75ec:      	ldr	x29, [sp]
    75f0:      	ldr	x30, [sp, #0x8]
    75f4:      	add	sp, sp, #0x40
    75f8:      	ret
    75fc:      	movz	x5, #0x0, lsl #48
    7600:      	b	0x750c <_stogir.vector.store-inputs+0xc8>
    7604:      	movz	x5, #0x0, lsl #48
    7608:      	b	0x7504 <_stogir.vector.store-inputs+0xc0>
    760c:      	brk	#0
    7610:      	b	0x760c <_stogir.vector.store-inputs+0x1c8>

0000000000007614 <_stogir.types.size>:
    7614:      	sxtw	x2, w0
    7618:      	sxtw	x3, w1
    761c:      	cmp	x2, #0xf
    7620:      	cset	w4, gt
    7624:      	cmp	x2, #0x0
    7628:      	cset	w5, eq
    762c:      	cmp	x3, #0x4
    7630:      	cset	w6, eq
    7634:      	cmp	x3, #0x8
    7638:      	cset	w7, eq
    763c:      	uxtb	w16, w4
    7640:      	cmp	w16, wzr
    7644:      	b.eq	0x7708 <_stogir.types.size+0xf4>
    7648:      	cmp	x2, #0x80
    764c:      	cset	w8, lt
    7650:      	uxtb	w16, w8
    7654:      	cmp	w16, wzr
    7658:      	b.eq	0x7708 <_stogir.types.size+0xf4>
    765c:      	and	w0, w0, #0xf
    7660:      	ubfx	x9, x0, #0, #32
    7664:      	cmp	x9, #0x1
    7668:      	cset	w10, ge
    766c:      	uxtb	w16, w10
    7670:      	cmp	w16, wzr
    7674:      	b.eq	0x7708 <_stogir.types.size+0xf4>
    7678:      	cmp	x9, #0xd
    767c:      	cset	w9, le
    7680:      	uxtb	w16, w9
    7684:      	cmp	w16, wzr
    7688:      	b.eq	0x7708 <_stogir.types.size+0xf4>
    768c:      	cmp	x2, #0x0
    7690:      	cset	w3, ge
    7694:      	cmp	x2, #0xd
    7698:      	cset	w11, le
    769c:      	uxtb	w16, w3
    76a0:      	cmp	w16, wzr
    76a4:      	b.eq	0x76b4 <_stogir.types.size+0xa0>
    76a8:      	uxtb	w16, w11
    76ac:      	cmp	w16, wzr
    76b0:      	b.ne	0x76e8 <_stogir.types.size+0xd4>
    76b4:      	uxtb	w16, w4
    76b8:      	cmp	w16, wzr
    76bc:      	b.eq	0x76e4 <_stogir.types.size+0xd0>
    76c0:      	uxtb	w16, w8
    76c4:      	cmp	w16, wzr
    76c8:      	b.eq	0x76e4 <_stogir.types.size+0xd0>
    76cc:      	uxtb	w16, w10
    76d0:      	cmp	w16, wzr
    76d4:      	b.eq	0x76e4 <_stogir.types.size+0xd0>
    76d8:      	uxtb	w16, w9
    76dc:      	cmp	w16, wzr
    76e0:      	b.ne	0x76e8 <_stogir.types.size+0xd4>
    76e4:      	movn	w0, #0x0, lsl #16
    76e8:      	uxtb	w16, w6
    76ec:      	cmp	w16, wzr
    76f0:      	b.ne	0x7828 <_stogir.types.size+0x214>
    76f4:      	uxtb	w16, w7
    76f8:      	cmp	w16, wzr
    76fc:      	b.ne	0x7828 <_stogir.types.size+0x214>
    7700:      	movn	w1, #0x0, lsl #16
    7704:      	b	0x77bc <_stogir.types.size+0x1a8>
    7708:      	uxtb	w16, w6
    770c:      	cmp	w16, wzr
    7710:      	b.ne	0x7728 <_stogir.types.size+0x114>
    7714:      	uxtb	w16, w7
    7718:      	cmp	w16, wzr
    771c:      	b.ne	0x7728 <_stogir.types.size+0x114>
    7720:      	movn	x3, #0x0, lsl #48
    7724:      	b	0x7740 <_stogir.types.size+0x12c>
    7728:      	uxtb	w16, w5
    772c:      	cmp	w16, wzr
    7730:      	b.eq	0x7748 <_stogir.types.size+0x134>
    7734:      	movz	x3, #0x0, lsl #48
    7738:      	b	0x7740 <_stogir.types.size+0x12c>
    773c:      	mov	x3, #0x1                ; =1
    7740:      	mov	x0, x3
    7744:      	ret
    7748:      	cmp	x2, #0x1
    774c:      	b.eq	0x773c <_stogir.types.size+0x128>
    7750:      	cmp	x2, #0x2
    7754:      	b.eq	0x773c <_stogir.types.size+0x128>
    7758:      	cmp	x2, #0x7
    775c:      	b.eq	0x773c <_stogir.types.size+0x128>
    7760:      	cmp	x2, #0x8
    7764:      	b.eq	0x773c <_stogir.types.size+0x128>
    7768:      	cmp	x2, #0x3
    776c:      	b.eq	0x78ac <_stogir.types.size+0x298>
    7770:      	cmp	x2, #0x9
    7774:      	b.eq	0x78ac <_stogir.types.size+0x298>
    7778:      	cmp	x2, #0x4
    777c:      	b.eq	0x78dc <_stogir.types.size+0x2c8>
    7780:      	cmp	x2, #0xa
    7784:      	b.eq	0x78dc <_stogir.types.size+0x2c8>
    7788:      	cmp	x2, #0xd
    778c:      	b.eq	0x78dc <_stogir.types.size+0x2c8>
    7790:      	cmp	x2, #0x5
    7794:      	b.eq	0x78ec <_stogir.types.size+0x2d8>
    7798:      	cmp	x2, #0xb
    779c:      	b.eq	0x78ec <_stogir.types.size+0x2d8>
    77a0:      	cmp	x2, #0xc
    77a4:      	b.eq	0x78ec <_stogir.types.size+0x2d8>
    77a8:      	cmp	x2, #0x6
    77ac:      	b.eq	0x77b4 <_stogir.types.size+0x1a0>
    77b0:      	movn	x3, #0x0, lsl #48
    77b4:      	b	0x78f0 <_stogir.types.size+0x2dc>
    77b8:      	mov	w1, #0x1                ; =1
    77bc:      	sxtw	x0, w1
    77c0:      	cmp	x0, #0x0
    77c4:      	b.ge	0x77d0 <_stogir.types.size+0x1bc>
    77c8:      	movn	x3, #0x0, lsl #48
    77cc:      	b	0x7740 <_stogir.types.size+0x12c>
    77d0:      	uxtb	w16, w4
    77d4:      	cmp	w16, wzr
    77d8:      	b.eq	0x78b4 <_stogir.types.size+0x2a0>
    77dc:      	uxtb	w16, w8
    77e0:      	cmp	w16, wzr
    77e4:      	b.eq	0x78b4 <_stogir.types.size+0x2a0>
    77e8:      	uxtb	w16, w10
    77ec:      	cmp	w16, wzr
    77f0:      	b.eq	0x78b4 <_stogir.types.size+0x2a0>
    77f4:      	uxtb	w16, w9
    77f8:      	cmp	w16, wzr
    77fc:      	b.eq	0x78b4 <_stogir.types.size+0x2a0>
    7800:      	ubfx	x0, x2, #4, #32
    7804:      	sub	w0, w0, #0x1
    7808:      	sxtw	x0, w0
    780c:      	mov	x16, #0x1               ; =1
    7810:      	lsl	x0, x16, x0
    7814:      	b	0x781c <_stogir.types.size+0x208>
    7818:      	movn	w0, #0x0, lsl #16
    781c:      	mul	w0, w0, w1
    7820:      	sxtw	x3, w0
    7824:      	b	0x77cc <_stogir.types.size+0x1b8>
    7828:      	sxtw	x0, w0
    782c:      	cmp	x0, #0x0
    7830:      	b.ne	0x783c <_stogir.types.size+0x228>
    7834:      	movz	w1, #0x0, lsl #16
    7838:      	b	0x77bc <_stogir.types.size+0x1a8>
    783c:      	cmp	x0, #0x1
    7840:      	b.eq	0x77b8 <_stogir.types.size+0x1a4>
    7844:      	cmp	x0, #0x2
    7848:      	b.eq	0x77b8 <_stogir.types.size+0x1a4>
    784c:      	cmp	x0, #0x7
    7850:      	b.eq	0x77b8 <_stogir.types.size+0x1a4>
    7854:      	cmp	x0, #0x8
    7858:      	b.eq	0x77b8 <_stogir.types.size+0x1a4>
    785c:      	cmp	x0, #0x3
    7860:      	b.eq	0x78e4 <_stogir.types.size+0x2d0>
    7864:      	cmp	x0, #0x9
    7868:      	b.eq	0x78e4 <_stogir.types.size+0x2d0>
    786c:      	cmp	x0, #0x4
    7870:      	b.eq	0x78f4 <_stogir.types.size+0x2e0>
    7874:      	cmp	x0, #0xa
    7878:      	b.eq	0x78f4 <_stogir.types.size+0x2e0>
    787c:      	cmp	x0, #0xd
    7880:      	b.eq	0x78f4 <_stogir.types.size+0x2e0>
    7884:      	cmp	x0, #0x5
    7888:      	b.eq	0x78fc <_stogir.types.size+0x2e8>
    788c:      	cmp	x0, #0xb
    7890:      	b.eq	0x78fc <_stogir.types.size+0x2e8>
    7894:      	cmp	x0, #0xc
    7898:      	b.eq	0x78fc <_stogir.types.size+0x2e8>
    789c:      	cmp	x0, #0x6
    78a0:      	b.eq	0x78a8 <_stogir.types.size+0x294>
    78a4:      	movn	w1, #0x0, lsl #16
    78a8:      	b	0x7900 <_stogir.types.size+0x2ec>
    78ac:      	mov	x3, #0x2                ; =2
    78b0:      	b	0x7740 <_stogir.types.size+0x12c>
    78b4:      	uxtb	w16, w3
    78b8:      	cmp	w16, wzr
    78bc:      	b.eq	0x7818 <_stogir.types.size+0x204>
    78c0:      	uxtb	w16, w11
    78c4:      	cmp	w16, wzr
    78c8:      	b.eq	0x7818 <_stogir.types.size+0x204>
    78cc:      	uxtb	w16, w5
    78d0:      	cmp	w16, wzr
    78d4:      	cset	w0, eq
    78d8:      	b	0x781c <_stogir.types.size+0x208>
    78dc:      	mov	x3, #0x4                ; =4
    78e0:      	b	0x78b0 <_stogir.types.size+0x29c>
    78e4:      	mov	w1, #0x2                ; =2
    78e8:      	b	0x77bc <_stogir.types.size+0x1a8>
    78ec:      	mov	x3, #0x8                ; =8
    78f0:      	b	0x78e0 <_stogir.types.size+0x2cc>
    78f4:      	mov	w1, #0x4                ; =4
    78f8:      	b	0x78e8 <_stogir.types.size+0x2d4>
    78fc:      	mov	w1, #0x8                ; =8
    7900:      	b	0x78f8 <_stogir.types.size+0x2e4>

0000000000007904 <_stogir.checked.projection>:
    7904:      	sub	sp, sp, #0x40
    7908:      	str	x29, [sp]
    790c:      	str	x30, [sp, #0x8]
    7910:      	mov	x29, sp
    7914:      	str	x19, [sp, #0x30]
    7918:      	sxtw	x2, w1
    791c:      	add	x3, x0, #0x28
    7920:      	cmp	x2, #0x0
    7924:      	cset	w4, gt
    7928:      	movz	x16, #0x0, lsl #48
    792c:      	sub	x5, x16, x2
    7930:      	sub	x6, x5, #0x1
    7934:      	uxtb	w16, w4
    7938:      	cmp	w16, wzr
    793c:      	b.eq	0x797c <_stogir.checked.projection+0x78>
    7940:      	ldr	x3, [x0, #0x8]
    7944:      	cmp	x2, x3
    7948:      	b.ge	0x79c8 <_stogir.checked.projection+0xc4>
    794c:      	add	x3, x0, #0x78
    7950:      	ldr	x3, [x3, #0x8]
    7954:      	cmp	x2, x3
    7958:      	b.ge	0x7ac8 <_stogir.checked.projection+0x1c4>
    795c:      	ldr	x3, [x0, #0x78]
    7960:      	add	x3, x3, x2, lsl #2
    7964:      	ldr	w3, [x3]
    7968:      	sxtw	x3, w3
    796c:      	cmp	x3, #0x0
    7970:      	cset	w3, ge
    7974:      	ubfx	x3, x3, #0, #8
    7978:      	b	0x7acc <_stogir.checked.projection+0x1c8>
    797c:      	cmp	x2, #0x0
    7980:      	b.ge	0x79d0 <_stogir.checked.projection+0xcc>
    7984:      	add	x7, x0, #0x50
    7988:      	ldr	x3, [x3, #0x8]
    798c:      	ldr	x7, [x7, #0x8]
    7990:      	cmp	x3, x7
    7994:      	b.ne	0x79c0 <_stogir.checked.projection+0xbc>
    7998:      	cmp	x5, x3
    799c:      	b.gt	0x7af8 <_stogir.checked.projection+0x1f4>
    79a0:      	ldr	x3, [x0, #0x50]
    79a4:      	add	x3, x3, x6, lsl #2
    79a8:      	ldr	w3, [x3]
    79ac:      	sxtw	x3, w3
    79b0:      	cmp	x3, #0x0
    79b4:      	cset	w3, gt
    79b8:      	ubfx	x3, x3, #0, #8
    79bc:      	b	0x7afc <_stogir.checked.projection+0x1f8>
    79c0:      	movz	x3, #0x0, lsl #48
    79c4:      	b	0x79d4 <_stogir.checked.projection+0xd0>
    79c8:      	movz	x3, #0x0, lsl #48
    79cc:      	b	0x79d4 <_stogir.checked.projection+0xd0>
    79d0:      	movz	x3, #0x0, lsl #48
    79d4:      	cmp	x3, #0x0
    79d8:      	b.eq	0x7a0c <_stogir.checked.projection+0x108>
    79dc:      	uxtb	w16, w4
    79e0:      	cmp	w16, wzr
    79e4:      	b.eq	0x79f8 <_stogir.checked.projection+0xf4>
    79e8:      	ldr	x3, [x0]
    79ec:      	add	x2, x3, x2, lsl #4
    79f0:      	ldr	x2, [x2]
    79f4:      	b	0x7a04 <_stogir.checked.projection+0x100>
    79f8:      	ldr	x2, [x0, #0x28]
    79fc:      	add	x2, x2, x6, lsl #4
    7a00:      	ldr	x2, [x2]
    7a04:      	mov	w3, #0x1                ; =1
    7a08:      	b	0x7a14 <_stogir.checked.projection+0x110>
    7a0c:      	movz	w3, #0x0, lsl #16
    7a10:      	movz	x2, #0x0, lsl #48
    7a14:      	ubfx	x3, x3, #0, #32
    7a18:      	lsr	x16, x3, #0
    7a1c:      	cmp	x16, #0x1
    7a20:      	b.eq	0x7a3c <_stogir.checked.projection+0x138>
    7a24:      	b.lo	0x7a2c <_stogir.checked.projection+0x128>
    7a28:      	b	0x7a40 <_stogir.checked.projection+0x13c>
    7a2c:      	cmp	x16, #0x0
    7a30:      	b.eq	0x7a38 <_stogir.checked.projection+0x134>
    7a34:      	b	0x7a40 <_stogir.checked.projection+0x13c>
    7a38:      	b	0x7a44 <_stogir.checked.projection+0x140>
    7a3c:      	b	0x7a8c <_stogir.checked.projection+0x188>
    7a40:      	b	0x7b00 <_stogir.checked.projection+0x1fc>
    7a44:      	mov	x19, x8
    7a48:      	mov	x0, #0x1                ; =1
    7a4c:      	adrp	x1, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007a4c:  ARM64_RELOC_PAGE21	l_stogir.427
    7a50:      	ldr	x1, [x1]
		0000000000007a50:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    7a54:      	mov	x2, #0x17               ; =23
    7a58:      	b	0x7a6c <_stogir.checked.projection+0x168>
    7a5c:      	mov	x0, #0x1                ; =1
    7a60:      	adrp	x1, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007a60:  ARM64_RELOC_PAGE21	l_stogir.428
    7a64:      	ldr	x1, [x1]
		0000000000007a64:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    7a68:      	mov	x2, #0x20               ; =32
    7a6c:      	str	x0, [x19]
    7a70:      	str	x1, [x19, #0x8]
    7a74:      	str	x2, [x19, #0x10]
    7a78:      	ldr	x19, [sp, #0x30]
    7a7c:      	ldr	x29, [sp]
    7a80:      	ldr	x30, [sp, #0x8]
    7a84:      	add	sp, sp, #0x40
    7a88:      	ret
    7a8c:      	uxtb	w3, w2
    7a90:      	cmp	x3, #0x29
    7a94:      	b.lt	0x7b08 <_stogir.checked.projection+0x204>
    7a98:      	cmp	x3, #0x2b
    7a9c:      	b.gt	0x7b10 <_stogir.checked.projection+0x20c>
    7aa0:      	mov	x19, x8
    7aa4:      	add	x8, sp, #0x10
    7aa8:      	bl	0x7aa8 <_stogir.checked.projection+0x1a4>
		0000000000007aa8:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    7aac:      	add	x16, sp, #0x10
    7ab0:      	ldr	x0, [x16]
    7ab4:      	add	x16, sp, #0x10
    7ab8:      	ldr	x1, [x16, #0x8]
    7abc:      	add	x16, sp, #0x10
    7ac0:      	ldr	x2, [x16, #0x10]
    7ac4:      	b	0x7a6c <_stogir.checked.projection+0x168>
    7ac8:      	movz	x3, #0x0, lsl #48
    7acc:      	b	0x79cc <_stogir.checked.projection+0xc8>
    7ad0:      	ubfx	x2, x2, #0, #32
    7ad4:      	ubfx	x0, x2, #8, #8
    7ad8:      	cmp	x0, #0x0
    7adc:      	b.eq	0x7a5c <_stogir.checked.projection+0x158>
    7ae0:      	cmp	x0, #0xd
    7ae4:      	b.gt	0x7a5c <_stogir.checked.projection+0x158>
    7ae8:      	movz	x0, #0x0, lsl #48
    7aec:      	movz	x1, #0x0, lsl #48
    7af0:      	movz	x2, #0x0, lsl #48
    7af4:      	b	0x7a6c <_stogir.checked.projection+0x168>
    7af8:      	movz	x3, #0x0, lsl #48
    7afc:      	b	0x79c4 <_stogir.checked.projection+0xc0>
    7b00:      	brk	#0
    7b04:      	b	0x7b00 <_stogir.checked.projection+0x1fc>
    7b08:      	mov	x19, x8
    7b0c:      	b	0x7ad0 <_stogir.checked.projection+0x1cc>
    7b10:      	mov	x19, x8
    7b14:      	b	0x7ad0 <_stogir.checked.projection+0x1cc>

0000000000007b18 <_stogir.atomic.ordinary?>:
    7b18:      	sxtw	x1, w1
    7b1c:      	add	x3, x0, #0x28
    7b20:      	cmp	x1, #0x0
    7b24:      	cset	w4, gt
    7b28:      	movz	x16, #0x0, lsl #48
    7b2c:      	sub	x5, x16, x1
    7b30:      	sub	x6, x5, #0x1
    7b34:      	uxtb	w16, w4
    7b38:      	cmp	w16, wzr
    7b3c:      	b.eq	0x7b7c <_stogir.atomic.ordinary?+0x64>
    7b40:      	ldr	x3, [x0, #0x8]
    7b44:      	cmp	x1, x3
    7b48:      	b.ge	0x7bc8 <_stogir.atomic.ordinary?+0xb0>
    7b4c:      	add	x3, x0, #0x78
    7b50:      	ldr	x3, [x3, #0x8]
    7b54:      	cmp	x1, x3
    7b58:      	b.ge	0x7c80 <_stogir.atomic.ordinary?+0x168>
    7b5c:      	ldr	x3, [x0, #0x78]
    7b60:      	add	x3, x3, x1, lsl #2
    7b64:      	ldr	w3, [x3]
    7b68:      	sxtw	x3, w3
    7b6c:      	cmp	x3, #0x0
    7b70:      	cset	w3, ge
    7b74:      	ubfx	x3, x3, #0, #8
    7b78:      	b	0x7c84 <_stogir.atomic.ordinary?+0x16c>
    7b7c:      	cmp	x1, #0x0
    7b80:      	b.ge	0x7bd0 <_stogir.atomic.ordinary?+0xb8>
    7b84:      	add	x7, x0, #0x50
    7b88:      	ldr	x3, [x3, #0x8]
    7b8c:      	ldr	x7, [x7, #0x8]
    7b90:      	cmp	x3, x7
    7b94:      	b.ne	0x7bc0 <_stogir.atomic.ordinary?+0xa8>
    7b98:      	cmp	x5, x3
    7b9c:      	b.gt	0x7ca0 <_stogir.atomic.ordinary?+0x188>
    7ba0:      	ldr	x3, [x0, #0x50]
    7ba4:      	add	x3, x3, x6, lsl #2
    7ba8:      	ldr	w3, [x3]
    7bac:      	sxtw	x3, w3
    7bb0:      	cmp	x3, #0x0
    7bb4:      	cset	w3, gt
    7bb8:      	ubfx	x3, x3, #0, #8
    7bbc:      	b	0x7ca4 <_stogir.atomic.ordinary?+0x18c>
    7bc0:      	movz	x3, #0x0, lsl #48
    7bc4:      	b	0x7bd4 <_stogir.atomic.ordinary?+0xbc>
    7bc8:      	movz	x3, #0x0, lsl #48
    7bcc:      	b	0x7bd4 <_stogir.atomic.ordinary?+0xbc>
    7bd0:      	movz	x3, #0x0, lsl #48
    7bd4:      	cmp	x3, #0x0
    7bd8:      	b.eq	0x7c0c <_stogir.atomic.ordinary?+0xf4>
    7bdc:      	uxtb	w16, w4
    7be0:      	cmp	w16, wzr
    7be4:      	b.eq	0x7bf8 <_stogir.atomic.ordinary?+0xe0>
    7be8:      	ldr	x0, [x0]
    7bec:      	add	x0, x0, x1, lsl #4
    7bf0:      	ldr	x0, [x0]
    7bf4:      	b	0x7c04 <_stogir.atomic.ordinary?+0xec>
    7bf8:      	ldr	x0, [x0, #0x28]
    7bfc:      	add	x0, x0, x6, lsl #4
    7c00:      	ldr	x0, [x0]
    7c04:      	mov	w1, #0x1                ; =1
    7c08:      	b	0x7c14 <_stogir.atomic.ordinary?+0xfc>
    7c0c:      	movz	w1, #0x0, lsl #16
    7c10:      	movz	x0, #0x0, lsl #48
    7c14:      	ubfx	x1, x1, #0, #32
    7c18:      	lsr	x16, x1, #0
    7c1c:      	cmp	x16, #0x1
    7c20:      	b.eq	0x7c3c <_stogir.atomic.ordinary?+0x124>
    7c24:      	b.lo	0x7c2c <_stogir.atomic.ordinary?+0x114>
    7c28:      	b	0x7c40 <_stogir.atomic.ordinary?+0x128>
    7c2c:      	cmp	x16, #0x0
    7c30:      	b.eq	0x7c38 <_stogir.atomic.ordinary?+0x120>
    7c34:      	b	0x7c40 <_stogir.atomic.ordinary?+0x128>
    7c38:      	b	0x7c44 <_stogir.atomic.ordinary?+0x12c>
    7c3c:      	b	0x7c54 <_stogir.atomic.ordinary?+0x13c>
    7c40:      	b	0x7ca8 <_stogir.atomic.ordinary?+0x190>
    7c44:      	movz	x0, #0x0, lsl #48
    7c48:      	b	0x7c50 <_stogir.atomic.ordinary?+0x138>
    7c4c:      	movz	x0, #0x0, lsl #48
    7c50:      	ret
    7c54:      	sxtw	x2, w2
    7c58:      	orr	w1, w0, wzr
    7c5c:      	ubfx	x1, x1, #0, #32
    7c60:      	ubfx	x1, x1, #8, #8
    7c64:      	cmp	x1, x2
    7c68:      	b.ne	0x7c4c <_stogir.atomic.ordinary?+0x134>
    7c6c:      	uxtb	w0, w0
    7c70:      	cmp	x0, #0x46
    7c74:      	b.ne	0x7c88 <_stogir.atomic.ordinary?+0x170>
    7c78:      	movz	x0, #0x0, lsl #48
    7c7c:      	b	0x7c9c <_stogir.atomic.ordinary?+0x184>
    7c80:      	movz	x3, #0x0, lsl #48
    7c84:      	b	0x7bcc <_stogir.atomic.ordinary?+0xb4>
    7c88:      	cmp	x0, #0x48
    7c8c:      	cset	w0, eq
    7c90:      	uxtb	w16, w0
    7c94:      	cmp	w16, wzr
    7c98:      	cset	x0, eq
    7c9c:      	b	0x7c50 <_stogir.atomic.ordinary?+0x138>
    7ca0:      	movz	x3, #0x0, lsl #48
    7ca4:      	b	0x7bc4 <_stogir.atomic.ordinary?+0xac>
    7ca8:      	brk	#0
    7cac:      	b	0x7ca8 <_stogir.atomic.ordinary?+0x190>

0000000000007cb0 <_stogir.types.scalar-size>:
    7cb0:      	sxtw	x1, w1
    7cb4:      	cmp	x1, #0x4
    7cb8:      	b.eq	0x7ccc <_stogir.types.scalar-size+0x1c>
    7cbc:      	cmp	x1, #0x8
    7cc0:      	b.eq	0x7ccc <_stogir.types.scalar-size+0x1c>
    7cc4:      	movn	x1, #0x0, lsl #48
    7cc8:      	b	0x7ce4 <_stogir.types.scalar-size+0x34>
    7ccc:      	sxtw	x0, w0
    7cd0:      	cmp	x0, #0x0
    7cd4:      	b.ne	0x7cec <_stogir.types.scalar-size+0x3c>
    7cd8:      	movz	x1, #0x0, lsl #48
    7cdc:      	b	0x7ce4 <_stogir.types.scalar-size+0x34>
    7ce0:      	mov	x1, #0x1                ; =1
    7ce4:      	mov	x0, x1
    7ce8:      	ret
    7cec:      	cmp	x0, #0x1
    7cf0:      	b.eq	0x7ce0 <_stogir.types.scalar-size+0x30>
    7cf4:      	cmp	x0, #0x2
    7cf8:      	b.eq	0x7ce0 <_stogir.types.scalar-size+0x30>
    7cfc:      	cmp	x0, #0x7
    7d00:      	b.eq	0x7ce0 <_stogir.types.scalar-size+0x30>
    7d04:      	cmp	x0, #0x8
    7d08:      	b.eq	0x7ce0 <_stogir.types.scalar-size+0x30>
    7d0c:      	cmp	x0, #0x3
    7d10:      	b.eq	0x7d5c <_stogir.types.scalar-size+0xac>
    7d14:      	cmp	x0, #0x9
    7d18:      	b.eq	0x7d5c <_stogir.types.scalar-size+0xac>
    7d1c:      	cmp	x0, #0x4
    7d20:      	b.eq	0x7d64 <_stogir.types.scalar-size+0xb4>
    7d24:      	cmp	x0, #0xa
    7d28:      	b.eq	0x7d64 <_stogir.types.scalar-size+0xb4>
    7d2c:      	cmp	x0, #0xd
    7d30:      	b.eq	0x7d64 <_stogir.types.scalar-size+0xb4>
    7d34:      	cmp	x0, #0x5
    7d38:      	b.eq	0x7d6c <_stogir.types.scalar-size+0xbc>
    7d3c:      	cmp	x0, #0xb
    7d40:      	b.eq	0x7d6c <_stogir.types.scalar-size+0xbc>
    7d44:      	cmp	x0, #0xc
    7d48:      	b.eq	0x7d6c <_stogir.types.scalar-size+0xbc>
    7d4c:      	cmp	x0, #0x6
    7d50:      	b.eq	0x7d58 <_stogir.types.scalar-size+0xa8>
    7d54:      	movn	x1, #0x0, lsl #48
    7d58:      	b	0x7d70 <_stogir.types.scalar-size+0xc0>
    7d5c:      	mov	x1, #0x2                ; =2
    7d60:      	b	0x7ce4 <_stogir.types.scalar-size+0x34>
    7d64:      	mov	x1, #0x4                ; =4
    7d68:      	b	0x7d60 <_stogir.types.scalar-size+0xb0>
    7d6c:      	mov	x1, #0x8                ; =8
    7d70:      	b	0x7d68 <_stogir.types.scalar-size+0xb8>

0000000000007d74 <_stogir.terminal.inputs>:
    7d74:      	sxtw	x1, w1
    7d78:      	cmp	x1, #0x60
    7d7c:      	cset	w4, eq
    7d80:      	uxtb	w16, w4
    7d84:      	cmp	w16, wzr
    7d88:      	b.ne	0x7db4 <_stogir.terminal.inputs+0x40>
    7d8c:      	cmp	x1, #0x79
    7d90:      	b.eq	0x7db4 <_stogir.terminal.inputs+0x40>
    7d94:      	mov	x1, #0x1                ; =1
    7d98:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007d98:  ARM64_RELOC_PAGE21	l_stogir.429
    7d9c:      	ldr	x0, [x0]
		0000000000007d9c:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    7da0:      	mov	x2, #0x25               ; =37
    7da4:      	str	x1, [x8]
    7da8:      	str	x0, [x8, #0x8]
    7dac:      	str	x2, [x8, #0x10]
    7db0:      	ret
    7db4:      	sxtw	x3, w3
    7db8:      	uxtb	w16, w4
    7dbc:      	cmp	w16, wzr
    7dc0:      	b.eq	0x7dcc <_stogir.terminal.inputs+0x58>
    7dc4:      	cmp	x3, #0x0
    7dc8:      	b.ne	0x7d94 <_stogir.terminal.inputs+0x20>
    7dcc:      	sxtw	x2, w2
    7dd0:      	cmp	x2, #0x0
    7dd4:      	cset	w1, gt
    7dd8:      	movz	x16, #0x0, lsl #48
    7ddc:      	sub	x4, x16, x2
    7de0:      	add	x5, x0, #0x28
    7de4:      	add	x6, x0, #0x78
    7de8:      	add	x7, x0, #0x50
    7dec:      	sub	x9, x4, #0x1
    7df0:      	uxtb	w16, w1
    7df4:      	cmp	w16, wzr
    7df8:      	b.eq	0x7ec4 <_stogir.terminal.inputs+0x150>
    7dfc:      	ldr	x4, [x0, #0x8]
    7e00:      	cmp	x2, x4
    7e04:      	b.ge	0x7ebc <_stogir.terminal.inputs+0x148>
    7e08:      	ldr	x4, [x6, #0x8]
    7e0c:      	cmp	x2, x4
    7e10:      	b.ge	0x7f54 <_stogir.terminal.inputs+0x1e0>
    7e14:      	ldr	x4, [x0, #0x78]
    7e18:      	add	x4, x4, x2, lsl #2
    7e1c:      	ldr	w4, [x4]
    7e20:      	sxtw	x4, w4
    7e24:      	cmp	x4, #0x0
    7e28:      	cset	w4, ge
    7e2c:      	ubfx	x4, x4, #0, #8
    7e30:      	b	0x7f58 <_stogir.terminal.inputs+0x1e4>
    7e34:      	movz	w4, #0x0, lsl #16
    7e38:      	movz	x1, #0x0, lsl #48
    7e3c:      	ubfx	x4, x4, #0, #32
    7e40:      	lsr	x16, x4, #0
    7e44:      	cmp	x16, #0x1
    7e48:      	b.eq	0x7e64 <_stogir.terminal.inputs+0xf0>
    7e4c:      	b.lo	0x7e54 <_stogir.terminal.inputs+0xe0>
    7e50:      	b	0x7e68 <_stogir.terminal.inputs+0xf4>
    7e54:      	cmp	x16, #0x0
    7e58:      	b.eq	0x7e60 <_stogir.terminal.inputs+0xec>
    7e5c:      	b	0x7e68 <_stogir.terminal.inputs+0xf4>
    7e60:      	b	0x7e6c <_stogir.terminal.inputs+0xf8>
    7e64:      	b	0x7f04 <_stogir.terminal.inputs+0x190>
    7e68:      	b	0x8094 <_stogir.terminal.inputs+0x320>
    7e6c:      	mov	x1, #0x1                ; =1
    7e70:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007e70:  ARM64_RELOC_PAGE21	l_stogir.430
    7e74:      	ldr	x0, [x0]
		0000000000007e74:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    7e78:      	mov	x2, #0x1d               ; =29
    7e7c:      	b	0x7da4 <_stogir.terminal.inputs+0x30>
    7e80:      	ldr	x1, [x0, #0x28]
    7e84:      	add	x1, x1, x9, lsl #4
    7e88:      	ldr	x1, [x1]
    7e8c:      	mov	w4, #0x1                ; =1
    7e90:      	b	0x7e3c <_stogir.terminal.inputs+0xc8>
    7e94:      	movz	x4, #0x0, lsl #48
    7e98:      	cmp	x4, #0x0
    7e9c:      	b.eq	0x7e34 <_stogir.terminal.inputs+0xc0>
    7ea0:      	uxtb	w16, w1
    7ea4:      	cmp	w16, wzr
    7ea8:      	b.eq	0x7e80 <_stogir.terminal.inputs+0x10c>
    7eac:      	ldr	x1, [x0]
    7eb0:      	add	x1, x1, x2, lsl #4
    7eb4:      	ldr	x1, [x1]
    7eb8:      	b	0x7e8c <_stogir.terminal.inputs+0x118>
    7ebc:      	movz	x4, #0x0, lsl #48
    7ec0:      	b	0x7e98 <_stogir.terminal.inputs+0x124>
    7ec4:      	cmp	x2, #0x0
    7ec8:      	b.ge	0x7e94 <_stogir.terminal.inputs+0x120>
    7ecc:      	ldr	x10, [x5, #0x8]
    7ed0:      	ldr	x11, [x7, #0x8]
    7ed4:      	cmp	x10, x11
    7ed8:      	b.ne	0x7f4c <_stogir.terminal.inputs+0x1d8>
    7edc:      	cmp	x4, x10
    7ee0:      	b.gt	0x7f5c <_stogir.terminal.inputs+0x1e8>
    7ee4:      	ldr	x4, [x0, #0x50]
    7ee8:      	add	x4, x4, x9, lsl #2
    7eec:      	ldr	w4, [x4]
    7ef0:      	sxtw	x4, w4
    7ef4:      	cmp	x4, #0x0
    7ef8:      	cset	w4, gt
    7efc:      	ubfx	x4, x4, #0, #8
    7f00:      	b	0x7f60 <_stogir.terminal.inputs+0x1ec>
    7f04:      	cmp	x2, #0x0
    7f08:      	b.le	0x7f38 <_stogir.terminal.inputs+0x1c4>
    7f0c:      	uxtb	w1, w1
    7f10:      	cmp	x1, #0x83
    7f14:      	cset	w2, lt
    7f18:      	uxtb	w16, w2
    7f1c:      	cmp	w16, wzr
    7f20:      	b.eq	0x7f64 <_stogir.terminal.inputs+0x1f0>
    7f24:      	adrp	x17, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007f24:  ARM64_RELOC_PAGE21	l_stogir.431
    7f28:      	ldr	x17, [x17]
		0000000000007f28:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    7f2c:      	add	x4, x1, x17
    7f30:      	ldrb	w4, [x4]
    7f34:      	b	0x7f68 <_stogir.terminal.inputs+0x1f4>
    7f38:      	mov	x1, #0x1                ; =1
    7f3c:      	adrp	x0, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007f3c:  ARM64_RELOC_PAGE21	l_stogir.432
    7f40:      	ldr	x0, [x0]
		0000000000007f40:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    7f44:      	mov	x2, #0x2c               ; =44
    7f48:      	b	0x7e7c <_stogir.terminal.inputs+0x108>
    7f4c:      	movz	x4, #0x0, lsl #48
    7f50:      	b	0x7e98 <_stogir.terminal.inputs+0x124>
    7f54:      	movz	x4, #0x0, lsl #48
    7f58:      	b	0x7ec0 <_stogir.terminal.inputs+0x14c>
    7f5c:      	movz	x4, #0x0, lsl #48
    7f60:      	b	0x7f50 <_stogir.terminal.inputs+0x1dc>
    7f64:      	movz	w4, #0x0, lsl #16
    7f68:      	uxtb	w16, w4
    7f6c:      	and	w4, w16, #0x1
    7f70:      	uxtb	w4, w4
    7f74:      	ubfx	x4, x4, #0, #8
    7f78:      	cmp	x4, #0x0
    7f7c:      	b.eq	0x7f38 <_stogir.terminal.inputs+0x1c4>
    7f80:      	uxtb	w16, w2
    7f84:      	cmp	w16, wzr
    7f88:      	b.eq	0x7fa0 <_stogir.terminal.inputs+0x22c>
    7f8c:      	adrp	x17, 0x7000 <_stogir.vector.memory-inputs+0x58>
		0000000000007f8c:  ARM64_RELOC_PAGE21	l_stogir.431
    7f90:      	ldr	x17, [x17]
		0000000000007f90:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    7f94:      	add	x1, x1, x17
    7f98:      	ldrb	w1, [x1]
    7f9c:      	b	0x7fa4 <_stogir.terminal.inputs+0x230>
    7fa0:      	movz	w1, #0x0, lsl #16
    7fa4:      	uxtb	w16, w1
    7fa8:      	and	w1, w16, #0x4
    7fac:      	uxtb	w1, w1
    7fb0:      	ubfx	x1, x1, #0, #8
    7fb4:      	cmp	x1, #0x0
    7fb8:      	cset	w1, eq
    7fbc:      	uxtb	w16, w1
    7fc0:      	cmp	w16, wzr
    7fc4:      	cset	x1, eq
    7fc8:      	cmp	x1, #0x0
    7fcc:      	b.ne	0x7f38 <_stogir.terminal.inputs+0x1c4>
    7fd0:      	cmp	x3, #0x0
    7fd4:      	b.ne	0x7fe8 <_stogir.terminal.inputs+0x274>
    7fd8:      	movz	x1, #0x0, lsl #48
    7fdc:      	movz	x0, #0x0, lsl #48
    7fe0:      	movz	x2, #0x0, lsl #48
    7fe4:      	b	0x7f48 <_stogir.terminal.inputs+0x1d4>
    7fe8:      	cmp	x3, #0x0
    7fec:      	cset	w1, gt
    7ff0:      	movz	x16, #0x0, lsl #48
    7ff4:      	sub	x2, x16, x3
    7ff8:      	sub	x4, x2, #0x1
    7ffc:      	uxtb	w16, w1
    8000:      	cmp	w16, wzr
    8004:      	b.eq	0x8054 <_stogir.terminal.inputs+0x2e0>
    8008:      	ldr	x2, [x0, #0x8]
    800c:      	cmp	x3, x2
    8010:      	b.ge	0x809c <_stogir.terminal.inputs+0x328>
    8014:      	ldr	x2, [x6, #0x8]
    8018:      	cmp	x3, x2
    801c:      	b.ge	0x815c <_stogir.terminal.inputs+0x3e8>
    8020:      	ldr	x2, [x0, #0x78]
    8024:      	add	x2, x2, x3, lsl #2
    8028:      	ldr	w2, [x2]
    802c:      	sxtw	x2, w2
    8030:      	cmp	x2, #0x0
    8034:      	cset	w2, ge
    8038:      	ubfx	x2, x2, #0, #8
    803c:      	b	0x8160 <_stogir.terminal.inputs+0x3ec>
    8040:      	mov	x1, #0x1                ; =1
    8044:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008044:  ARM64_RELOC_PAGE21	l_stogir.433
    8048:      	ldr	x0, [x0]
		0000000000008048:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    804c:      	mov	x2, #0x2e               ; =46
    8050:      	b	0x7fe4 <_stogir.terminal.inputs+0x270>
    8054:      	cmp	x3, #0x0
    8058:      	b.ge	0x80a4 <_stogir.terminal.inputs+0x330>
    805c:      	ldr	x5, [x5, #0x8]
    8060:      	ldr	x6, [x7, #0x8]
    8064:      	cmp	x5, x6
    8068:      	b.ne	0x8154 <_stogir.terminal.inputs+0x3e0>
    806c:      	cmp	x2, x5
    8070:      	b.gt	0x8164 <_stogir.terminal.inputs+0x3f0>
    8074:      	ldr	x2, [x0, #0x50]
    8078:      	add	x2, x2, x4, lsl #2
    807c:      	ldr	w2, [x2]
    8080:      	sxtw	x2, w2
    8084:      	cmp	x2, #0x0
    8088:      	cset	w2, gt
    808c:      	ubfx	x2, x2, #0, #8
    8090:      	b	0x8168 <_stogir.terminal.inputs+0x3f4>
    8094:      	brk	#0
    8098:      	b	0x8094 <_stogir.terminal.inputs+0x320>
    809c:      	movz	x2, #0x0, lsl #48
    80a0:      	b	0x80a8 <_stogir.terminal.inputs+0x334>
    80a4:      	movz	x2, #0x0, lsl #48
    80a8:      	cmp	x2, #0x0
    80ac:      	b.eq	0x80e0 <_stogir.terminal.inputs+0x36c>
    80b0:      	uxtb	w16, w1
    80b4:      	cmp	w16, wzr
    80b8:      	b.eq	0x80cc <_stogir.terminal.inputs+0x358>
    80bc:      	ldr	x0, [x0]
    80c0:      	add	x0, x0, x3, lsl #4
    80c4:      	ldr	x0, [x0]
    80c8:      	b	0x80d8 <_stogir.terminal.inputs+0x364>
    80cc:      	ldr	x0, [x0, #0x28]
    80d0:      	add	x0, x0, x4, lsl #4
    80d4:      	ldr	x0, [x0]
    80d8:      	mov	w1, #0x1                ; =1
    80dc:      	b	0x80e8 <_stogir.terminal.inputs+0x374>
    80e0:      	movz	w1, #0x0, lsl #16
    80e4:      	movz	x0, #0x0, lsl #48
    80e8:      	ubfx	x1, x1, #0, #32
    80ec:      	lsr	x16, x1, #0
    80f0:      	cmp	x16, #0x1
    80f4:      	b.eq	0x8110 <_stogir.terminal.inputs+0x39c>
    80f8:      	b.lo	0x8100 <_stogir.terminal.inputs+0x38c>
    80fc:      	b	0x8114 <_stogir.terminal.inputs+0x3a0>
    8100:      	cmp	x16, #0x0
    8104:      	b.eq	0x810c <_stogir.terminal.inputs+0x398>
    8108:      	b	0x8114 <_stogir.terminal.inputs+0x3a0>
    810c:      	b	0x8118 <_stogir.terminal.inputs+0x3a4>
    8110:      	b	0x812c <_stogir.terminal.inputs+0x3b8>
    8114:      	b	0x81ac <_stogir.terminal.inputs+0x438>
    8118:      	mov	x1, #0x1                ; =1
    811c:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x28c>
		000000000000811c:  ARM64_RELOC_PAGE21	l_stogir.434
    8120:      	ldr	x0, [x0]
		0000000000008120:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    8124:      	mov	x2, #0x1d               ; =29
    8128:      	b	0x8050 <_stogir.terminal.inputs+0x2dc>
    812c:      	cmp	x3, #0x0
    8130:      	b.le	0x8040 <_stogir.terminal.inputs+0x2cc>
    8134:      	uxtb	w0, w0
    8138:      	cmp	x0, #0x83
    813c:      	b.ge	0x816c <_stogir.terminal.inputs+0x3f8>
    8140:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008140:  ARM64_RELOC_PAGE21	l_stogir.431
    8144:      	ldr	x17, [x17]
		0000000000008144:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    8148:      	add	x0, x0, x17
    814c:      	ldrb	w0, [x0]
    8150:      	b	0x8170 <_stogir.terminal.inputs+0x3fc>
    8154:      	movz	x2, #0x0, lsl #48
    8158:      	b	0x80a8 <_stogir.terminal.inputs+0x334>
    815c:      	movz	x2, #0x0, lsl #48
    8160:      	b	0x80a0 <_stogir.terminal.inputs+0x32c>
    8164:      	movz	x2, #0x0, lsl #48
    8168:      	b	0x8158 <_stogir.terminal.inputs+0x3e4>
    816c:      	movz	w0, #0x0, lsl #16
    8170:      	uxtb	w16, w0
    8174:      	and	w0, w16, #0x8
    8178:      	uxtb	w0, w0
    817c:      	ubfx	x0, x0, #0, #8
    8180:      	cmp	x0, #0x0
    8184:      	cset	w0, eq
    8188:      	uxtb	w16, w0
    818c:      	cmp	w16, wzr
    8190:      	cset	x0, eq
    8194:      	cmp	x0, #0x0
    8198:      	b.eq	0x8040 <_stogir.terminal.inputs+0x2cc>
    819c:      	and	x0, x3, #0xffffffff
    81a0:      	movz	x1, #0x0, lsl #48
    81a4:      	movz	x2, #0x0, lsl #48
    81a8:      	b	0x8050 <_stogir.terminal.inputs+0x2dc>
    81ac:      	brk	#0
    81b0:      	b	0x81ac <_stogir.terminal.inputs+0x438>

00000000000081b4 <_stogir.switch.switch-inputs>:
    81b4:      	sxtw	x1, w1
    81b8:      	add	x3, x0, #0x28
    81bc:      	add	x4, x0, #0x78
    81c0:      	add	x5, x0, #0x50
    81c4:      	cmp	x1, #0x0
    81c8:      	cset	w6, gt
    81cc:      	movz	x16, #0x0, lsl #48
    81d0:      	sub	x7, x16, x1
    81d4:      	sub	x9, x7, #0x1
    81d8:      	uxtb	w16, w6
    81dc:      	cmp	w16, wzr
    81e0:      	b.eq	0x821c <_stogir.switch.switch-inputs+0x68>
    81e4:      	ldr	x7, [x0, #0x8]
    81e8:      	cmp	x1, x7
    81ec:      	b.ge	0x8278 <_stogir.switch.switch-inputs+0xc4>
    81f0:      	ldr	x7, [x4, #0x8]
    81f4:      	cmp	x1, x7
    81f8:      	b.ge	0x8348 <_stogir.switch.switch-inputs+0x194>
    81fc:      	ldr	x7, [x0, #0x78]
    8200:      	add	x7, x7, x1, lsl #2
    8204:      	ldr	w7, [x7]
    8208:      	sxtw	x7, w7
    820c:      	cmp	x7, #0x0
    8210:      	cset	w7, ge
    8214:      	ubfx	x7, x7, #0, #8
    8218:      	b	0x834c <_stogir.switch.switch-inputs+0x198>
    821c:      	cmp	x1, #0x0
    8220:      	b.ge	0x8280 <_stogir.switch.switch-inputs+0xcc>
    8224:      	ldr	x10, [x3, #0x8]
    8228:      	ldr	x11, [x5, #0x8]
    822c:      	cmp	x10, x11
    8230:      	b.ne	0x825c <_stogir.switch.switch-inputs+0xa8>
    8234:      	cmp	x7, x10
    8238:      	b.gt	0x8350 <_stogir.switch.switch-inputs+0x19c>
    823c:      	ldr	x7, [x0, #0x50]
    8240:      	add	x7, x7, x9, lsl #2
    8244:      	ldr	w7, [x7]
    8248:      	sxtw	x7, w7
    824c:      	cmp	x7, #0x0
    8250:      	cset	w7, gt
    8254:      	ubfx	x7, x7, #0, #8
    8258:      	b	0x8354 <_stogir.switch.switch-inputs+0x1a0>
    825c:      	movz	x7, #0x0, lsl #48
    8260:      	b	0x8284 <_stogir.switch.switch-inputs+0xd0>
    8264:      	mov	x1, #0x1                ; =1
    8268:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008268:  ARM64_RELOC_PAGE21	l_stogir.435
    826c:      	ldr	x0, [x0]
		000000000000826c:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    8270:      	mov	x2, #0x16               ; =22
    8274:      	b	0x8304 <_stogir.switch.switch-inputs+0x150>
    8278:      	movz	x7, #0x0, lsl #48
    827c:      	b	0x8284 <_stogir.switch.switch-inputs+0xd0>
    8280:      	movz	x7, #0x0, lsl #48
    8284:      	cmp	x7, #0x0
    8288:      	b.eq	0x82bc <_stogir.switch.switch-inputs+0x108>
    828c:      	uxtb	w16, w6
    8290:      	cmp	w16, wzr
    8294:      	b.eq	0x82a8 <_stogir.switch.switch-inputs+0xf4>
    8298:      	ldr	x6, [x0]
    829c:      	add	x6, x6, x1, lsl #4
    82a0:      	ldr	x6, [x6]
    82a4:      	b	0x82b4 <_stogir.switch.switch-inputs+0x100>
    82a8:      	ldr	x6, [x0, #0x28]
    82ac:      	add	x6, x6, x9, lsl #4
    82b0:      	ldr	x6, [x6]
    82b4:      	mov	w7, #0x1                ; =1
    82b8:      	b	0x82c4 <_stogir.switch.switch-inputs+0x110>
    82bc:      	movz	w7, #0x0, lsl #16
    82c0:      	movz	x6, #0x0, lsl #48
    82c4:      	ubfx	x7, x7, #0, #32
    82c8:      	lsr	x16, x7, #0
    82cc:      	cmp	x16, #0x1
    82d0:      	b.eq	0x82ec <_stogir.switch.switch-inputs+0x138>
    82d4:      	b.lo	0x82dc <_stogir.switch.switch-inputs+0x128>
    82d8:      	b	0x82f0 <_stogir.switch.switch-inputs+0x13c>
    82dc:      	cmp	x16, #0x0
    82e0:      	b.eq	0x82e8 <_stogir.switch.switch-inputs+0x134>
    82e4:      	b	0x82f0 <_stogir.switch.switch-inputs+0x13c>
    82e8:      	b	0x82f4 <_stogir.switch.switch-inputs+0x140>
    82ec:      	b	0x8314 <_stogir.switch.switch-inputs+0x160>
    82f0:      	b	0x854c <_stogir.switch.switch-inputs+0x398>
    82f4:      	mov	x1, #0x1                ; =1
    82f8:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x28c>
		00000000000082f8:  ARM64_RELOC_PAGE21	l_stogir.436
    82fc:      	ldr	x0, [x0]
		00000000000082fc:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    8300:      	mov	x2, #0x16               ; =22
    8304:      	str	x1, [x8]
    8308:      	str	x0, [x8, #0x8]
    830c:      	str	x2, [x8, #0x10]
    8310:      	ret
    8314:      	cmp	x1, #0x0
    8318:      	b.le	0x8264 <_stogir.switch.switch-inputs+0xb0>
    831c:      	uxtb	w6, w6
    8320:      	cmp	x6, #0x83
    8324:      	cset	w1, lt
    8328:      	uxtb	w16, w1
    832c:      	cmp	w16, wzr
    8330:      	b.eq	0x8358 <_stogir.switch.switch-inputs+0x1a4>
    8334:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008334:  ARM64_RELOC_PAGE21	l_stogir.437
    8338:      	ldr	x17, [x17]
		0000000000008338:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    833c:      	add	x7, x6, x17
    8340:      	ldrb	w7, [x7]
    8344:      	b	0x835c <_stogir.switch.switch-inputs+0x1a8>
    8348:      	movz	x7, #0x0, lsl #48
    834c:      	b	0x827c <_stogir.switch.switch-inputs+0xc8>
    8350:      	movz	x7, #0x0, lsl #48
    8354:      	b	0x8260 <_stogir.switch.switch-inputs+0xac>
    8358:      	movz	w7, #0x0, lsl #16
    835c:      	uxtb	w16, w7
    8360:      	and	w7, w16, #0x1
    8364:      	uxtb	w7, w7
    8368:      	ubfx	x7, x7, #0, #8
    836c:      	cmp	x7, #0x0
    8370:      	b.eq	0x8264 <_stogir.switch.switch-inputs+0xb0>
    8374:      	uxtb	w16, w1
    8378:      	cmp	w16, wzr
    837c:      	b.eq	0x8394 <_stogir.switch.switch-inputs+0x1e0>
    8380:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008380:  ARM64_RELOC_PAGE21	l_stogir.437
    8384:      	ldr	x17, [x17]
		0000000000008384:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    8388:      	add	x1, x6, x17
    838c:      	ldrb	w1, [x1]
    8390:      	b	0x8398 <_stogir.switch.switch-inputs+0x1e4>
    8394:      	movz	w1, #0x0, lsl #16
    8398:      	uxtb	w16, w1
    839c:      	and	w1, w16, #0x4
    83a0:      	uxtb	w1, w1
    83a4:      	ubfx	x1, x1, #0, #8
    83a8:      	cmp	x1, #0x0
    83ac:      	cset	w1, eq
    83b0:      	uxtb	w16, w1
    83b4:      	cmp	w16, wzr
    83b8:      	cset	x1, eq
    83bc:      	cmp	x1, #0x0
    83c0:      	b.ne	0x8264 <_stogir.switch.switch-inputs+0xb0>
    83c4:      	sxtw	x2, w2
    83c8:      	cmp	x2, #0x0
    83cc:      	cset	w1, gt
    83d0:      	movz	x16, #0x0, lsl #48
    83d4:      	sub	x6, x16, x2
    83d8:      	sub	x7, x6, #0x1
    83dc:      	uxtb	w16, w1
    83e0:      	cmp	w16, wzr
    83e4:      	b.eq	0x8434 <_stogir.switch.switch-inputs+0x280>
    83e8:      	ldr	x3, [x0, #0x8]
    83ec:      	cmp	x2, x3
    83f0:      	b.ge	0x8474 <_stogir.switch.switch-inputs+0x2c0>
    83f4:      	ldr	x3, [x4, #0x8]
    83f8:      	cmp	x2, x3
    83fc:      	b.ge	0x8544 <_stogir.switch.switch-inputs+0x390>
    8400:      	ldr	x3, [x0, #0x78]
    8404:      	add	x3, x3, x2, lsl #2
    8408:      	ldr	w3, [x3]
    840c:      	sxtw	x3, w3
    8410:      	cmp	x3, #0x0
    8414:      	cset	w3, ge
    8418:      	ubfx	x3, x3, #0, #8
    841c:      	b	0x8548 <_stogir.switch.switch-inputs+0x394>
    8420:      	mov	x1, #0x1                ; =1
    8424:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008424:  ARM64_RELOC_PAGE21	l_stogir.438
    8428:      	ldr	x0, [x0]
		0000000000008428:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    842c:      	mov	x2, #0x20               ; =32
    8430:      	b	0x8274 <_stogir.switch.switch-inputs+0xc0>
    8434:      	cmp	x2, #0x0
    8438:      	b.ge	0x847c <_stogir.switch.switch-inputs+0x2c8>
    843c:      	ldr	x3, [x3, #0x8]
    8440:      	ldr	x4, [x5, #0x8]
    8444:      	cmp	x3, x4
    8448:      	b.ne	0x853c <_stogir.switch.switch-inputs+0x388>
    844c:      	cmp	x6, x3
    8450:      	b.gt	0x8554 <_stogir.switch.switch-inputs+0x3a0>
    8454:      	ldr	x3, [x0, #0x50]
    8458:      	add	x3, x3, x7, lsl #2
    845c:      	ldr	w3, [x3]
    8460:      	sxtw	x3, w3
    8464:      	cmp	x3, #0x0
    8468:      	cset	w3, gt
    846c:      	ubfx	x3, x3, #0, #8
    8470:      	b	0x8558 <_stogir.switch.switch-inputs+0x3a4>
    8474:      	movz	x3, #0x0, lsl #48
    8478:      	b	0x8480 <_stogir.switch.switch-inputs+0x2cc>
    847c:      	movz	x3, #0x0, lsl #48
    8480:      	cmp	x3, #0x0
    8484:      	b.eq	0x84b8 <_stogir.switch.switch-inputs+0x304>
    8488:      	uxtb	w16, w1
    848c:      	cmp	w16, wzr
    8490:      	b.eq	0x84a4 <_stogir.switch.switch-inputs+0x2f0>
    8494:      	ldr	x0, [x0]
    8498:      	add	x0, x0, x2, lsl #4
    849c:      	ldr	x0, [x0]
    84a0:      	b	0x84b0 <_stogir.switch.switch-inputs+0x2fc>
    84a4:      	ldr	x0, [x0, #0x28]
    84a8:      	add	x0, x0, x7, lsl #4
    84ac:      	ldr	x0, [x0]
    84b0:      	mov	w1, #0x1                ; =1
    84b4:      	b	0x84c0 <_stogir.switch.switch-inputs+0x30c>
    84b8:      	movz	w1, #0x0, lsl #16
    84bc:      	movz	x0, #0x0, lsl #48
    84c0:      	ubfx	x1, x1, #0, #32
    84c4:      	lsr	x16, x1, #0
    84c8:      	cmp	x16, #0x1
    84cc:      	b.eq	0x84e8 <_stogir.switch.switch-inputs+0x334>
    84d0:      	b.lo	0x84d8 <_stogir.switch.switch-inputs+0x324>
    84d4:      	b	0x84ec <_stogir.switch.switch-inputs+0x338>
    84d8:      	cmp	x16, #0x0
    84dc:      	b.eq	0x84e4 <_stogir.switch.switch-inputs+0x330>
    84e0:      	b	0x84ec <_stogir.switch.switch-inputs+0x338>
    84e4:      	b	0x84f0 <_stogir.switch.switch-inputs+0x33c>
    84e8:      	b	0x8504 <_stogir.switch.switch-inputs+0x350>
    84ec:      	b	0x855c <_stogir.switch.switch-inputs+0x3a8>
    84f0:      	mov	x1, #0x1                ; =1
    84f4:      	adrp	x0, 0x8000 <_stogir.terminal.inputs+0x28c>
		00000000000084f4:  ARM64_RELOC_PAGE21	l_stogir.439
    84f8:      	ldr	x0, [x0]
		00000000000084f8:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    84fc:      	mov	x2, #0x17               ; =23
    8500:      	b	0x8430 <_stogir.switch.switch-inputs+0x27c>
    8504:      	orr	w1, w0, wzr
    8508:      	ubfx	x1, x1, #0, #32
    850c:      	ubfx	x1, x1, #8, #8
    8510:      	cmp	x1, #0x1
    8514:      	b.lt	0x8420 <_stogir.switch.switch-inputs+0x26c>
    8518:      	cmp	x1, #0xb
    851c:      	b.gt	0x8420 <_stogir.switch.switch-inputs+0x26c>
    8520:      	uxtb	w0, w0
    8524:      	cmp	x0, #0x48
    8528:      	b.eq	0x8420 <_stogir.switch.switch-inputs+0x26c>
    852c:      	and	x0, x1, #0xffffffff
    8530:      	movz	x1, #0x0, lsl #48
    8534:      	movz	x2, #0x0, lsl #48
    8538:      	b	0x8430 <_stogir.switch.switch-inputs+0x27c>
    853c:      	movz	x3, #0x0, lsl #48
    8540:      	b	0x8480 <_stogir.switch.switch-inputs+0x2cc>
    8544:      	movz	x3, #0x0, lsl #48
    8548:      	b	0x8478 <_stogir.switch.switch-inputs+0x2c4>
    854c:      	brk	#0
    8550:      	b	0x854c <_stogir.switch.switch-inputs+0x398>
    8554:      	movz	x3, #0x0, lsl #48
    8558:      	b	0x8540 <_stogir.switch.switch-inputs+0x38c>
    855c:      	brk	#0
    8560:      	b	0x855c <_stogir.switch.switch-inputs+0x3a8>

0000000000008564 <_stogir.switch.case-inputs>:
    8564:      	sub	sp, sp, #0xb0
    8568:      	str	x29, [sp]
    856c:      	str	x30, [sp, #0x8]
    8570:      	mov	x29, sp
    8574:      	str	x19, [sp, #0x70]
    8578:      	str	x20, [sp, #0x78]
    857c:      	str	x21, [sp, #0x80]
    8580:      	str	x22, [sp, #0x88]
    8584:      	str	x23, [sp, #0x90]
    8588:      	str	x24, [sp, #0x98]
    858c:      	str	x25, [sp, #0xa0]
    8590:      	str	x26, [sp, #0xa8]
    8594:      	sxtw	x2, w2
    8598:      	add	x5, x0, #0x78
    859c:      	add	x6, x0, #0x28
    85a0:      	lsl	x7, x2, #2
    85a4:      	cmp	x2, #0x0
    85a8:      	cset	w9, gt
    85ac:      	movz	x16, #0x0, lsl #48
    85b0:      	sub	x10, x16, x2
    85b4:      	sub	x11, x10, #0x1
    85b8:      	uxtb	w16, w9
    85bc:      	cmp	w16, wzr
    85c0:      	b.eq	0x85fc <_stogir.switch.case-inputs+0x98>
    85c4:      	ldr	x6, [x0, #0x8]
    85c8:      	cmp	x2, x6
    85cc:      	b.ge	0x8648 <_stogir.switch.case-inputs+0xe4>
    85d0:      	ldr	x5, [x5, #0x8]
    85d4:      	cmp	x2, x5
    85d8:      	b.ge	0x8740 <_stogir.switch.case-inputs+0x1dc>
    85dc:      	ldr	x5, [x0, #0x78]
    85e0:      	add	x5, x7, x5
    85e4:      	ldr	w5, [x5]
    85e8:      	sxtw	x5, w5
    85ec:      	cmp	x5, #0x0
    85f0:      	cset	w5, ge
    85f4:      	ubfx	x5, x5, #0, #8
    85f8:      	b	0x8744 <_stogir.switch.case-inputs+0x1e0>
    85fc:      	cmp	x2, #0x0
    8600:      	b.ge	0x8650 <_stogir.switch.case-inputs+0xec>
    8604:      	add	x5, x0, #0x50
    8608:      	ldr	x6, [x6, #0x8]
    860c:      	ldr	x5, [x5, #0x8]
    8610:      	cmp	x6, x5
    8614:      	b.ne	0x8640 <_stogir.switch.case-inputs+0xdc>
    8618:      	cmp	x10, x6
    861c:      	b.gt	0x8808 <_stogir.switch.case-inputs+0x2a4>
    8620:      	ldr	x5, [x0, #0x50]
    8624:      	add	x5, x5, x11, lsl #2
    8628:      	ldr	w5, [x5]
    862c:      	sxtw	x5, w5
    8630:      	cmp	x5, #0x0
    8634:      	cset	w5, gt
    8638:      	ubfx	x5, x5, #0, #8
    863c:      	b	0x880c <_stogir.switch.case-inputs+0x2a8>
    8640:      	movz	x5, #0x0, lsl #48
    8644:      	b	0x8654 <_stogir.switch.case-inputs+0xf0>
    8648:      	movz	x5, #0x0, lsl #48
    864c:      	b	0x8654 <_stogir.switch.case-inputs+0xf0>
    8650:      	movz	x5, #0x0, lsl #48
    8654:      	cmp	x5, #0x0
    8658:      	b.eq	0x8694 <_stogir.switch.case-inputs+0x130>
    865c:      	uxtb	w16, w9
    8660:      	cmp	w16, wzr
    8664:      	b.eq	0x867c <_stogir.switch.case-inputs+0x118>
    8668:      	ldr	x5, [x0]
    866c:      	add	x5, x5, x2, lsl #4
    8670:      	ldr	x6, [x5]
    8674:      	ldr	x5, [x5, #0x8]
    8678:      	b	0x868c <_stogir.switch.case-inputs+0x128>
    867c:      	ldr	x5, [x0, #0x28]
    8680:      	add	x5, x5, x11, lsl #4
    8684:      	ldr	x6, [x5]
    8688:      	ldr	x5, [x5, #0x8]
    868c:      	mov	w9, #0x1                ; =1
    8690:      	b	0x86a0 <_stogir.switch.case-inputs+0x13c>
    8694:      	movz	w9, #0x0, lsl #16
    8698:      	movz	x6, #0x0, lsl #48
    869c:      	movz	x5, #0x0, lsl #48
    86a0:      	ubfx	x9, x9, #0, #32
    86a4:      	lsr	x16, x9, #0
    86a8:      	cmp	x16, #0x1
    86ac:      	b.eq	0x86c8 <_stogir.switch.case-inputs+0x164>
    86b0:      	b.lo	0x86b8 <_stogir.switch.case-inputs+0x154>
    86b4:      	b	0x86cc <_stogir.switch.case-inputs+0x168>
    86b8:      	cmp	x16, #0x0
    86bc:      	b.eq	0x86c4 <_stogir.switch.case-inputs+0x160>
    86c0:      	b	0x86cc <_stogir.switch.case-inputs+0x168>
    86c4:      	b	0x86d0 <_stogir.switch.case-inputs+0x16c>
    86c8:      	b	0x8720 <_stogir.switch.case-inputs+0x1bc>
    86cc:      	b	0x8810 <_stogir.switch.case-inputs+0x2ac>
    86d0:      	mov	x21, x8
    86d4:      	mov	x2, #0x1                ; =1
    86d8:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x28c>
		00000000000086d8:  ARM64_RELOC_PAGE21	l_stogir.440
    86dc:      	ldr	x1, [x1]
		00000000000086dc:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    86e0:      	mov	x0, #0x1a               ; =26
    86e4:      	str	x2, [x21]
    86e8:      	str	x1, [x21, #0x8]
    86ec:      	str	x0, [x21, #0x10]
    86f0:      	ldr	x19, [sp, #0x70]
    86f4:      	ldr	x20, [sp, #0x78]
    86f8:      	ldr	x21, [sp, #0x80]
    86fc:      	ldr	x22, [sp, #0x88]
    8700:      	ldr	x23, [sp, #0x90]
    8704:      	ldr	x24, [sp, #0x98]
    8708:      	ldr	x25, [sp, #0xa0]
    870c:      	ldr	x26, [sp, #0xa8]
    8710:      	ldr	x29, [sp]
    8714:      	ldr	x30, [sp, #0x8]
    8718:      	add	sp, sp, #0xb0
    871c:      	ret
    8720:      	cmp	x2, #0x0
    8724:      	b.gt	0x8748 <_stogir.switch.case-inputs+0x1e4>
    8728:      	mov	x21, x8
    872c:      	mov	x2, #0x1                ; =1
    8730:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008730:  ARM64_RELOC_PAGE21	l_stogir.441
    8734:      	ldr	x1, [x1]
		0000000000008734:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    8738:      	mov	x0, #0x1f               ; =31
    873c:      	b	0x86e4 <_stogir.switch.case-inputs+0x180>
    8740:      	movz	x5, #0x0, lsl #48
    8744:      	b	0x864c <_stogir.switch.case-inputs+0xe8>
    8748:      	uxtb	w2, w6
    874c:      	cmp	x2, #0x75
    8750:      	b.ne	0x896c <_stogir.switch.case-inputs+0x408>
    8754:      	orr	w2, w6, wzr
    8758:      	ubfx	x2, x2, #0, #32
    875c:      	ubfx	x2, x2, #8, #8
    8760:      	cmp	x2, #0x0
    8764:      	b.ne	0x8974 <_stogir.switch.case-inputs+0x410>
    8768:      	ldr	x2, [x0, #0x78]
    876c:      	add	x2, x7, x2
    8770:      	ldr	w2, [x2]
    8774:      	sxtw	x2, w2
    8778:      	cmp	x2, #0x2
    877c:      	b.ne	0x897c <_stogir.switch.case-inputs+0x418>
    8780:      	sxtw	x19, w1
    8784:      	cmp	x19, #0x6d
    8788:      	b.lt	0x8984 <_stogir.switch.case-inputs+0x420>
    878c:      	cmp	x19, #0x6f
    8790:      	b.gt	0x898c <_stogir.switch.case-inputs+0x428>
    8794:      	add	x16, sp, #0x10
    8798:      	orr	x20, x16, xzr
    879c:      	lsr	x1, x6, #32
    87a0:      	mov	w2, w5
    87a4:      	mov	x21, x8
    87a8:      	add	x8, sp, #0x10
    87ac:      	mov	x22, x0
    87b0:      	mov	w23, w3
    87b4:      	mov	w24, w4
    87b8:      	bl	0x87b8 <_stogir.switch.case-inputs+0x254>
		00000000000087b8:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    87bc:      	add	x16, sp, #0x10
    87c0:      	ldr	w0, [x16]
    87c4:      	lsr	x16, x0, #0
    87c8:      	cmp	x16, #0x1
    87cc:      	b.eq	0x87e8 <_stogir.switch.case-inputs+0x284>
    87d0:      	b.lo	0x87d8 <_stogir.switch.case-inputs+0x274>
    87d4:      	b	0x87ec <_stogir.switch.case-inputs+0x288>
    87d8:      	cmp	x16, #0x0
    87dc:      	b.eq	0x87e4 <_stogir.switch.case-inputs+0x280>
    87e0:      	b	0x87ec <_stogir.switch.case-inputs+0x288>
    87e4:      	b	0x8818 <_stogir.switch.case-inputs+0x2b4>
    87e8:      	b	0x87f0 <_stogir.switch.case-inputs+0x28c>
    87ec:      	b	0x8954 <_stogir.switch.case-inputs+0x3f0>
    87f0:      	add	x0, x20, #0x8
    87f4:      	add	x16, sp, #0x10
    87f8:      	ldr	x1, [x16, #0x8]
    87fc:      	ldr	x0, [x0, #0x8]
    8800:      	mov	x2, #0x1                ; =1
    8804:      	b	0x873c <_stogir.switch.case-inputs+0x1d8>
    8808:      	movz	x5, #0x0, lsl #48
    880c:      	b	0x8644 <_stogir.switch.case-inputs+0xe0>
    8810:      	brk	#0
    8814:      	b	0x8810 <_stogir.switch.case-inputs+0x2ac>
    8818:      	add	x16, sp, #0x10
    881c:      	ldr	w20, [x16, #0x8]
    8820:      	sxtw	x25, w20
    8824:      	cmp	x19, #0x6f
    8828:      	b.ne	0x883c <_stogir.switch.case-inputs+0x2d8>
    882c:      	and	x1, x25, #0xffffffff
    8830:      	movz	x2, #0x0, lsl #48
    8834:      	movz	x0, #0x0, lsl #48
    8838:      	b	0x8804 <_stogir.switch.case-inputs+0x2a0>
    883c:      	add	x16, sp, #0x30
    8840:      	orr	x26, x16, xzr
    8844:      	add	x8, sp, #0x30
    8848:      	mov	x0, x22
    884c:      	mov	w1, w23
    8850:      	mov	w2, w20
    8854:      	bl	0x8854 <_stogir.switch.case-inputs+0x2f0>
		0000000000008854:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    8858:      	add	x16, sp, #0x30
    885c:      	ldr	w0, [x16]
    8860:      	lsr	x16, x0, #0
    8864:      	cmp	x16, #0x1
    8868:      	b.eq	0x8884 <_stogir.switch.case-inputs+0x320>
    886c:      	b.lo	0x8874 <_stogir.switch.case-inputs+0x310>
    8870:      	b	0x8888 <_stogir.switch.case-inputs+0x324>
    8874:      	cmp	x16, #0x0
    8878:      	b.eq	0x8880 <_stogir.switch.case-inputs+0x31c>
    887c:      	b	0x8888 <_stogir.switch.case-inputs+0x324>
    8880:      	b	0x88a4 <_stogir.switch.case-inputs+0x340>
    8884:      	b	0x888c <_stogir.switch.case-inputs+0x328>
    8888:      	b	0x895c <_stogir.switch.case-inputs+0x3f8>
    888c:      	add	x0, x26, #0x8
    8890:      	add	x16, sp, #0x30
    8894:      	ldr	x1, [x16, #0x8]
    8898:      	ldr	x0, [x0, #0x8]
    889c:      	mov	x2, #0x1                ; =1
    88a0:      	b	0x8838 <_stogir.switch.case-inputs+0x2d4>
    88a4:      	add	x16, sp, #0x30
    88a8:      	ldr	x26, [x16, #0x8]
    88ac:      	cmp	x19, #0x6d
    88b0:      	b.eq	0x88b8 <_stogir.switch.case-inputs+0x354>
    88b4:      	orr	w23, w24, wzr
    88b8:      	add	x16, sp, #0x50
    88bc:      	orr	x19, x16, xzr
    88c0:      	add	x8, sp, #0x50
    88c4:      	mov	x0, x22
    88c8:      	mov	w1, w23
    88cc:      	mov	w2, w20
    88d0:      	bl	0x88d0 <_stogir.switch.case-inputs+0x36c>
		00000000000088d0:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    88d4:      	add	x16, sp, #0x50
    88d8:      	ldr	w0, [x16]
    88dc:      	lsr	x16, x0, #0
    88e0:      	cmp	x16, #0x1
    88e4:      	b.eq	0x8900 <_stogir.switch.case-inputs+0x39c>
    88e8:      	b.lo	0x88f0 <_stogir.switch.case-inputs+0x38c>
    88ec:      	b	0x8904 <_stogir.switch.case-inputs+0x3a0>
    88f0:      	cmp	x16, #0x0
    88f4:      	b.eq	0x88fc <_stogir.switch.case-inputs+0x398>
    88f8:      	b	0x8904 <_stogir.switch.case-inputs+0x3a0>
    88fc:      	b	0x8930 <_stogir.switch.case-inputs+0x3cc>
    8900:      	b	0x8908 <_stogir.switch.case-inputs+0x3a4>
    8904:      	b	0x8964 <_stogir.switch.case-inputs+0x400>
    8908:      	add	x0, x19, #0x8
    890c:      	add	x16, sp, #0x50
    8910:      	ldr	x1, [x16, #0x8]
    8914:      	ldr	x0, [x0, #0x8]
    8918:      	mov	x2, #0x1                ; =1
    891c:      	b	0x892c <_stogir.switch.case-inputs+0x3c8>
    8920:      	and	x1, x25, #0xffffffff
    8924:      	movz	x2, #0x0, lsl #48
    8928:      	movz	x0, #0x0, lsl #48
    892c:      	b	0x88a0 <_stogir.switch.case-inputs+0x33c>
    8930:      	add	x16, sp, #0x50
    8934:      	ldr	x0, [x16, #0x8]
    8938:      	cmp	x26, x0
    893c:      	b.ls	0x8920 <_stogir.switch.case-inputs+0x3bc>
    8940:      	mov	x2, #0x1                ; =1
    8944:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008944:  ARM64_RELOC_PAGE21	l_stogir.442
    8948:      	ldr	x1, [x1]
		0000000000008948:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    894c:      	mov	x0, #0x1a               ; =26
    8950:      	b	0x892c <_stogir.switch.case-inputs+0x3c8>
    8954:      	brk	#0
    8958:      	b	0x8954 <_stogir.switch.case-inputs+0x3f0>
    895c:      	brk	#0
    8960:      	b	0x895c <_stogir.switch.case-inputs+0x3f8>
    8964:      	brk	#0
    8968:      	b	0x8964 <_stogir.switch.case-inputs+0x400>
    896c:      	mov	x21, x8
    8970:      	b	0x872c <_stogir.switch.case-inputs+0x1c8>
    8974:      	mov	x21, x8
    8978:      	b	0x872c <_stogir.switch.case-inputs+0x1c8>
    897c:      	mov	x21, x8
    8980:      	b	0x872c <_stogir.switch.case-inputs+0x1c8>
    8984:      	mov	x21, x8
    8988:      	b	0x872c <_stogir.switch.case-inputs+0x1c8>
    898c:      	mov	x21, x8
    8990:      	b	0x872c <_stogir.switch.case-inputs+0x1c8>

0000000000008994 <_stogir.stack.valid-frame-object-inputs?>:
    8994:      	sub	sp, sp, #0x30
    8998:      	str	x29, [sp]
    899c:      	str	x30, [sp, #0x8]
    89a0:      	mov	x29, sp
    89a4:      	sxtw	x1, w1
    89a8:      	mov	x3, sp
    89ac:      	add	x4, x0, #0x28
    89b0:      	add	x5, x0, #0x78
    89b4:      	add	x6, x0, #0x50
    89b8:      	sub	sp, sp, #0x10
    89bc:      	mov	x7, sp
    89c0:      	mov	x8, #0x1                ; =1
    89c4:      	movz	x9, #0x0, lsl #48
    89c8:      	b	0x8acc <_stogir.stack.valid-frame-object-inputs?+0x138>
    89cc:      	movz	x12, #0x0, lsl #48
    89d0:      	b	0x8a3c <_stogir.stack.valid-frame-object-inputs?+0xa8>
    89d4:      	movz	w11, #0x0, lsl #16
    89d8:      	movz	x10, #0x0, lsl #48
    89dc:      	ubfx	x11, x11, #0, #32
    89e0:      	lsr	x16, x11, #0
    89e4:      	cmp	x16, #0x1
    89e8:      	b.eq	0x8a04 <_stogir.stack.valid-frame-object-inputs?+0x70>
    89ec:      	b.lo	0x89f4 <_stogir.stack.valid-frame-object-inputs?+0x60>
    89f0:      	b	0x8a08 <_stogir.stack.valid-frame-object-inputs?+0x74>
    89f4:      	cmp	x16, #0x0
    89f8:      	b.eq	0x8a00 <_stogir.stack.valid-frame-object-inputs?+0x6c>
    89fc:      	b	0x8a08 <_stogir.stack.valid-frame-object-inputs?+0x74>
    8a00:      	b	0x8a28 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8a04:      	b	0x8a0c <_stogir.stack.valid-frame-object-inputs?+0x78>
    8a08:      	b	0x8d78 <_stogir.stack.valid-frame-object-inputs?+0x3e4>
    8a0c:      	uxtb	w11, w10
    8a10:      	ubfx	x10, x10, #0, #32
    8a14:      	ubfx	x10, x10, #8, #8
    8a18:      	cmp	x11, x10
    8a1c:      	b.eq	0x8d64 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    8a20:      	cmp	x11, #0x49
    8a24:      	b.eq	0x8d64 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    8a28:      	movz	x8, #0x0, lsl #48
    8a2c:      	b	0x8ba4 <_stogir.stack.valid-frame-object-inputs?+0x210>
    8a30:      	movz	x12, #0x0, lsl #48
    8a34:      	b	0x8a44 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    8a38:      	movz	x12, #0x0, lsl #48
    8a3c:      	b	0x8a4c <_stogir.stack.valid-frame-object-inputs?+0xb8>
    8a40:      	movz	x12, #0x0, lsl #48
    8a44:      	b	0x8a4c <_stogir.stack.valid-frame-object-inputs?+0xb8>
    8a48:      	movz	x12, #0x0, lsl #48
    8a4c:      	cmp	x12, #0x0
    8a50:      	b.eq	0x8a8c <_stogir.stack.valid-frame-object-inputs?+0xf8>
    8a54:      	uxtb	w16, w11
    8a58:      	cmp	w16, wzr
    8a5c:      	b.eq	0x8a74 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    8a60:      	ldr	x11, [x0]
    8a64:      	add	x10, x11, x10, lsl #4
    8a68:      	ldr	x11, [x10]
    8a6c:      	ldr	x10, [x10, #0x8]
    8a70:      	b	0x8a84 <_stogir.stack.valid-frame-object-inputs?+0xf0>
    8a74:      	ldr	x10, [x0, #0x28]
    8a78:      	add	x10, x10, x13, lsl #4
    8a7c:      	ldr	x11, [x10]
    8a80:      	ldr	x10, [x10, #0x8]
    8a84:      	mov	w12, #0x1               ; =1
    8a88:      	b	0x8a98 <_stogir.stack.valid-frame-object-inputs?+0x104>
    8a8c:      	movz	w12, #0x0, lsl #16
    8a90:      	movz	x11, #0x0, lsl #48
    8a94:      	movz	x10, #0x0, lsl #48
    8a98:      	ubfx	x12, x12, #0, #32
    8a9c:      	lsr	x16, x12, #0
    8aa0:      	cmp	x16, #0x1
    8aa4:      	b.eq	0x8ac0 <_stogir.stack.valid-frame-object-inputs?+0x12c>
    8aa8:      	b.lo	0x8ab0 <_stogir.stack.valid-frame-object-inputs?+0x11c>
    8aac:      	b	0x8ac4 <_stogir.stack.valid-frame-object-inputs?+0x130>
    8ab0:      	cmp	x16, #0x0
    8ab4:      	b.eq	0x8abc <_stogir.stack.valid-frame-object-inputs?+0x128>
    8ab8:      	b	0x8ac4 <_stogir.stack.valid-frame-object-inputs?+0x130>
    8abc:      	b	0x8ac8 <_stogir.stack.valid-frame-object-inputs?+0x134>
    8ac0:      	b	0x8b7c <_stogir.stack.valid-frame-object-inputs?+0x1e8>
    8ac4:      	b	0x8cd0 <_stogir.stack.valid-frame-object-inputs?+0x33c>
    8ac8:      	movz	x8, #0x0, lsl #48
    8acc:      	cmp	x8, #0x0
    8ad0:      	b.eq	0x8c2c <_stogir.stack.valid-frame-object-inputs?+0x298>
    8ad4:      	cmp	x9, #0x0
    8ad8:      	b.ne	0x8c2c <_stogir.stack.valid-frame-object-inputs?+0x298>
    8adc:      	orr	w10, w1, wzr
    8ae0:      	sxtw	x10, w10
    8ae4:      	cmp	x10, #0x0
    8ae8:      	cset	w11, gt
    8aec:      	movz	x16, #0x0, lsl #48
    8af0:      	sub	x12, x16, x10
    8af4:      	sub	x13, x12, #0x1
    8af8:      	uxtb	w16, w11
    8afc:      	cmp	w16, wzr
    8b00:      	b.eq	0x8b3c <_stogir.stack.valid-frame-object-inputs?+0x1a8>
    8b04:      	ldr	x12, [x0, #0x8]
    8b08:      	cmp	x10, x12
    8b0c:      	b.ge	0x8a40 <_stogir.stack.valid-frame-object-inputs?+0xac>
    8b10:      	ldr	x12, [x5, #0x8]
    8b14:      	cmp	x10, x12
    8b18:      	b.ge	0x8a30 <_stogir.stack.valid-frame-object-inputs?+0x9c>
    8b1c:      	ldr	x12, [x0, #0x78]
    8b20:      	add	x12, x12, x10, lsl #2
    8b24:      	ldr	w12, [x12]
    8b28:      	sxtw	x12, w12
    8b2c:      	cmp	x12, #0x0
    8b30:      	cset	w12, ge
    8b34:      	ubfx	x12, x12, #0, #8
    8b38:      	b	0x8a34 <_stogir.stack.valid-frame-object-inputs?+0xa0>
    8b3c:      	cmp	x10, #0x0
    8b40:      	b.ge	0x8a48 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    8b44:      	ldr	x14, [x4, #0x8]
    8b48:      	ldr	x15, [x6, #0x8]
    8b4c:      	cmp	x14, x15
    8b50:      	b.ne	0x8a38 <_stogir.stack.valid-frame-object-inputs?+0xa4>
    8b54:      	cmp	x12, x14
    8b58:      	b.gt	0x89cc <_stogir.stack.valid-frame-object-inputs?+0x38>
    8b5c:      	ldr	x12, [x0, #0x50]
    8b60:      	add	x12, x12, x13, lsl #2
    8b64:      	ldr	w12, [x12]
    8b68:      	sxtw	x12, w12
    8b6c:      	cmp	x12, #0x0
    8b70:      	cset	w12, gt
    8b74:      	ubfx	x12, x12, #0, #8
    8b78:      	b	0x89d0 <_stogir.stack.valid-frame-object-inputs?+0x3c>
    8b7c:      	uxtb	w12, w11
    8b80:      	asr	x13, x11, #32
    8b84:      	str	x11, [x7]
    8b88:      	str	x10, [x7, #0x8]
    8b8c:      	cmp	x12, #0x68
    8b90:      	b.ne	0x8ba8 <_stogir.stack.valid-frame-object-inputs?+0x214>
    8b94:      	cmp	x13, #0x0
    8b98:      	cset	w8, eq
    8b9c:      	ubfx	x8, x8, #0, #8
    8ba0:      	mov	x9, #0x1                ; =1
    8ba4:      	b	0x8acc <_stogir.stack.valid-frame-object-inputs?+0x138>
    8ba8:      	cmp	x1, #0x0
    8bac:      	b.le	0x8a28 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8bb0:      	cmp	x12, #0x51
    8bb4:      	b.ne	0x8a28 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8bb8:      	cmp	x13, #0x0
    8bbc:      	b.le	0x8a28 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8bc0:      	cmp	x13, x1
    8bc4:      	b.ge	0x8a28 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8bc8:      	sxtw	x10, w10
    8bcc:      	cmp	x10, #0x0
    8bd0:      	b.ge	0x8a28 <_stogir.stack.valid-frame-object-inputs?+0x94>
    8bd4:      	cmp	x10, #0x0
    8bd8:      	cset	w11, gt
    8bdc:      	movz	x16, #0x0, lsl #48
    8be0:      	sub	x12, x16, x10
    8be4:      	sub	x13, x12, #0x1
    8be8:      	uxtb	w16, w11
    8bec:      	cmp	w16, wzr
    8bf0:      	b.eq	0x8d1c <_stogir.stack.valid-frame-object-inputs?+0x388>
    8bf4:      	ldr	x12, [x0, #0x8]
    8bf8:      	cmp	x10, x12
    8bfc:      	b.ge	0x8d14 <_stogir.stack.valid-frame-object-inputs?+0x380>
    8c00:      	ldr	x12, [x5, #0x8]
    8c04:      	cmp	x10, x12
    8c08:      	b.ge	0x8d5c <_stogir.stack.valid-frame-object-inputs?+0x3c8>
    8c0c:      	ldr	x12, [x0, #0x78]
    8c10:      	add	x12, x12, x10, lsl #2
    8c14:      	ldr	w12, [x12]
    8c18:      	sxtw	x12, w12
    8c1c:      	cmp	x12, #0x0
    8c20:      	cset	w12, ge
    8c24:      	ubfx	x12, x12, #0, #8
    8c28:      	b	0x8d60 <_stogir.stack.valid-frame-object-inputs?+0x3cc>
    8c2c:      	cmp	x8, #0x0
    8c30:      	b.ne	0x8c38 <_stogir.stack.valid-frame-object-inputs?+0x2a4>
    8c34:      	movz	x9, #0x0, lsl #48
    8c38:      	mov	sp, x3
    8c3c:      	cmp	x9, #0x0
    8c40:      	b.eq	0x8c98 <_stogir.stack.valid-frame-object-inputs?+0x304>
    8c44:      	sxtw	x1, w2
    8c48:      	cmp	x1, #0x0
    8c4c:      	b.ge	0x8cb0 <_stogir.stack.valid-frame-object-inputs?+0x31c>
    8c50:      	add	x8, x29, #0x10
    8c54:      	mov	w1, w2
    8c58:      	bl	0x8c58 <_stogir.stack.valid-frame-object-inputs?+0x2c4>
		0000000000008c58:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    8c5c:      	add	x16, x29, #0x10
    8c60:      	ldr	w0, [x16]
    8c64:      	lsr	x16, x0, #0
    8c68:      	cmp	x16, #0x1
    8c6c:      	b.eq	0x8c88 <_stogir.stack.valid-frame-object-inputs?+0x2f4>
    8c70:      	b.lo	0x8c78 <_stogir.stack.valid-frame-object-inputs?+0x2e4>
    8c74:      	b	0x8c8c <_stogir.stack.valid-frame-object-inputs?+0x2f8>
    8c78:      	cmp	x16, #0x0
    8c7c:      	b.eq	0x8c84 <_stogir.stack.valid-frame-object-inputs?+0x2f0>
    8c80:      	b	0x8c8c <_stogir.stack.valid-frame-object-inputs?+0x2f8>
    8c84:      	b	0x8cb8 <_stogir.stack.valid-frame-object-inputs?+0x324>
    8c88:      	b	0x8c90 <_stogir.stack.valid-frame-object-inputs?+0x2fc>
    8c8c:      	b	0x8d70 <_stogir.stack.valid-frame-object-inputs?+0x3dc>
    8c90:      	movz	x0, #0x0, lsl #48
    8c94:      	b	0x8ccc <_stogir.stack.valid-frame-object-inputs?+0x338>
    8c98:      	movz	x0, #0x0, lsl #48
    8c9c:      	sub	sp, x29, #0x0
    8ca0:      	ldr	x29, [sp]
    8ca4:      	ldr	x30, [sp, #0x8]
    8ca8:      	add	sp, sp, #0x30
    8cac:      	ret
    8cb0:      	movz	x0, #0x0, lsl #48
    8cb4:      	b	0x8c9c <_stogir.stack.valid-frame-object-inputs?+0x308>
    8cb8:      	add	x16, x29, #0x10
    8cbc:      	ldr	x0, [x16, #0x8]
    8cc0:      	cmp	x0, #0x0
    8cc4:      	cset	w0, gt
    8cc8:      	ubfx	x0, x0, #0, #8
    8ccc:      	b	0x8cb4 <_stogir.stack.valid-frame-object-inputs?+0x320>
    8cd0:      	brk	#0
    8cd4:      	b	0x8cd0 <_stogir.stack.valid-frame-object-inputs?+0x33c>
    8cd8:      	ldr	x10, [x0, #0x28]
    8cdc:      	add	x10, x10, x13, lsl #4
    8ce0:      	ldr	x10, [x10]
    8ce4:      	mov	w11, #0x1               ; =1
    8ce8:      	b	0x89dc <_stogir.stack.valid-frame-object-inputs?+0x48>
    8cec:      	movz	x12, #0x0, lsl #48
    8cf0:      	cmp	x12, #0x0
    8cf4:      	b.eq	0x89d4 <_stogir.stack.valid-frame-object-inputs?+0x40>
    8cf8:      	uxtb	w16, w11
    8cfc:      	cmp	w16, wzr
    8d00:      	b.eq	0x8cd8 <_stogir.stack.valid-frame-object-inputs?+0x344>
    8d04:      	ldr	x11, [x0]
    8d08:      	add	x10, x11, x10, lsl #4
    8d0c:      	ldr	x10, [x10]
    8d10:      	b	0x8ce4 <_stogir.stack.valid-frame-object-inputs?+0x350>
    8d14:      	movz	x12, #0x0, lsl #48
    8d18:      	b	0x8cf0 <_stogir.stack.valid-frame-object-inputs?+0x35c>
    8d1c:      	ldr	x14, [x4, #0x8]
    8d20:      	ldr	x15, [x6, #0x8]
    8d24:      	cmp	x14, x15
    8d28:      	b.ne	0x8cec <_stogir.stack.valid-frame-object-inputs?+0x358>
    8d2c:      	cmp	x12, x14
    8d30:      	b.gt	0x8d54 <_stogir.stack.valid-frame-object-inputs?+0x3c0>
    8d34:      	ldr	x12, [x0, #0x50]
    8d38:      	add	x12, x12, x13, lsl #2
    8d3c:      	ldr	w12, [x12]
    8d40:      	sxtw	x12, w12
    8d44:      	cmp	x12, #0x0
    8d48:      	cset	w12, gt
    8d4c:      	ubfx	x12, x12, #0, #8
    8d50:      	b	0x8d58 <_stogir.stack.valid-frame-object-inputs?+0x3c4>
    8d54:      	movz	x12, #0x0, lsl #48
    8d58:      	b	0x8cf0 <_stogir.stack.valid-frame-object-inputs?+0x35c>
    8d5c:      	movz	x12, #0x0, lsl #48
    8d60:      	b	0x8d18 <_stogir.stack.valid-frame-object-inputs?+0x384>
    8d64:      	ldr	w1, [x7, #0x4]
    8d68:      	sxtw	x1, w1
    8d6c:      	b	0x8a2c <_stogir.stack.valid-frame-object-inputs?+0x98>
    8d70:      	brk	#0
    8d74:      	b	0x8d70 <_stogir.stack.valid-frame-object-inputs?+0x3dc>
    8d78:      	brk	#0
    8d7c:      	b	0x8d78 <_stogir.stack.valid-frame-object-inputs?+0x3e4>

0000000000008d80 <_stogir.stack.validate-scope-inputs>:
    8d80:      	sxtw	x1, w1
    8d84:      	cmp	x1, #0x53
    8d88:      	cset	w5, eq
    8d8c:      	uxtb	w16, w5
    8d90:      	cmp	w16, wzr
    8d94:      	b.ne	0x8dc0 <_stogir.stack.validate-scope-inputs+0x40>
    8d98:      	cmp	x1, #0x54
    8d9c:      	b.eq	0x8dc0 <_stogir.stack.validate-scope-inputs+0x40>
    8da0:      	mov	x0, #0x1                ; =1
    8da4:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008da4:  ARM64_RELOC_PAGE21	l_stogir.443
    8da8:      	ldr	x1, [x1]
		0000000000008da8:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    8dac:      	mov	x2, #0x22               ; =34
    8db0:      	str	x0, [x8]
    8db4:      	str	x1, [x8, #0x8]
    8db8:      	str	x2, [x8, #0x10]
    8dbc:      	ret
    8dc0:      	uxtb	w16, w5
    8dc4:      	cmp	w16, wzr
    8dc8:      	mov	w16, #0x6               ; =6
    8dcc:      	movz	w17, #0x0, lsl #16
    8dd0:      	csel	w1, w16, w17, ne
    8dd4:      	sxtw	x2, w2
    8dd8:      	sxtw	x1, w1
    8ddc:      	cmp	x2, x1
    8de0:      	b.ne	0x8da0 <_stogir.stack.validate-scope-inputs+0x20>
    8de4:      	sxtw	x3, w3
    8de8:      	cmp	x3, #0x0
    8dec:      	cset	w1, gt
    8df0:      	movz	x16, #0x0, lsl #48
    8df4:      	sub	x2, x16, x3
    8df8:      	add	x6, x0, #0x28
    8dfc:      	add	x7, x0, #0x78
    8e00:      	add	x9, x0, #0x50
    8e04:      	sub	x10, x2, #0x1
    8e08:      	uxtb	w16, w1
    8e0c:      	cmp	w16, wzr
    8e10:      	b.eq	0x8edc <_stogir.stack.validate-scope-inputs+0x15c>
    8e14:      	ldr	x2, [x0, #0x8]
    8e18:      	cmp	x3, x2
    8e1c:      	b.ge	0x8ed4 <_stogir.stack.validate-scope-inputs+0x154>
    8e20:      	ldr	x2, [x7, #0x8]
    8e24:      	cmp	x3, x2
    8e28:      	b.ge	0x8f6c <_stogir.stack.validate-scope-inputs+0x1ec>
    8e2c:      	ldr	x2, [x0, #0x78]
    8e30:      	add	x2, x2, x3, lsl #2
    8e34:      	ldr	w2, [x2]
    8e38:      	sxtw	x2, w2
    8e3c:      	cmp	x2, #0x0
    8e40:      	cset	w2, ge
    8e44:      	ubfx	x2, x2, #0, #8
    8e48:      	b	0x8f70 <_stogir.stack.validate-scope-inputs+0x1f0>
    8e4c:      	movz	w2, #0x0, lsl #16
    8e50:      	movz	x1, #0x0, lsl #48
    8e54:      	ubfx	x2, x2, #0, #32
    8e58:      	lsr	x16, x2, #0
    8e5c:      	cmp	x16, #0x1
    8e60:      	b.eq	0x8e7c <_stogir.stack.validate-scope-inputs+0xfc>
    8e64:      	b.lo	0x8e6c <_stogir.stack.validate-scope-inputs+0xec>
    8e68:      	b	0x8e80 <_stogir.stack.validate-scope-inputs+0x100>
    8e6c:      	cmp	x16, #0x0
    8e70:      	b.eq	0x8e78 <_stogir.stack.validate-scope-inputs+0xf8>
    8e74:      	b	0x8e80 <_stogir.stack.validate-scope-inputs+0x100>
    8e78:      	b	0x8e84 <_stogir.stack.validate-scope-inputs+0x104>
    8e7c:      	b	0x8f1c <_stogir.stack.validate-scope-inputs+0x19c>
    8e80:      	b	0x9130 <_stogir.stack.validate-scope-inputs+0x3b0>
    8e84:      	mov	x0, #0x1                ; =1
    8e88:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008e88:  ARM64_RELOC_PAGE21	l_stogir.444
    8e8c:      	ldr	x1, [x1]
		0000000000008e8c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    8e90:      	mov	x2, #0x1b               ; =27
    8e94:      	b	0x8db0 <_stogir.stack.validate-scope-inputs+0x30>
    8e98:      	ldr	x1, [x0, #0x28]
    8e9c:      	add	x1, x1, x10, lsl #4
    8ea0:      	ldr	x1, [x1]
    8ea4:      	mov	w2, #0x1                ; =1
    8ea8:      	b	0x8e54 <_stogir.stack.validate-scope-inputs+0xd4>
    8eac:      	movz	x2, #0x0, lsl #48
    8eb0:      	cmp	x2, #0x0
    8eb4:      	b.eq	0x8e4c <_stogir.stack.validate-scope-inputs+0xcc>
    8eb8:      	uxtb	w16, w1
    8ebc:      	cmp	w16, wzr
    8ec0:      	b.eq	0x8e98 <_stogir.stack.validate-scope-inputs+0x118>
    8ec4:      	ldr	x1, [x0]
    8ec8:      	add	x1, x1, x3, lsl #4
    8ecc:      	ldr	x1, [x1]
    8ed0:      	b	0x8ea4 <_stogir.stack.validate-scope-inputs+0x124>
    8ed4:      	movz	x2, #0x0, lsl #48
    8ed8:      	b	0x8eb0 <_stogir.stack.validate-scope-inputs+0x130>
    8edc:      	cmp	x3, #0x0
    8ee0:      	b.ge	0x8eac <_stogir.stack.validate-scope-inputs+0x12c>
    8ee4:      	ldr	x11, [x6, #0x8]
    8ee8:      	ldr	x12, [x9, #0x8]
    8eec:      	cmp	x11, x12
    8ef0:      	b.ne	0x8f64 <_stogir.stack.validate-scope-inputs+0x1e4>
    8ef4:      	cmp	x2, x11
    8ef8:      	b.gt	0x8f74 <_stogir.stack.validate-scope-inputs+0x1f4>
    8efc:      	ldr	x2, [x0, #0x50]
    8f00:      	add	x2, x2, x10, lsl #2
    8f04:      	ldr	w2, [x2]
    8f08:      	sxtw	x2, w2
    8f0c:      	cmp	x2, #0x0
    8f10:      	cset	w2, gt
    8f14:      	ubfx	x2, x2, #0, #8
    8f18:      	b	0x8f78 <_stogir.stack.validate-scope-inputs+0x1f8>
    8f1c:      	cmp	x3, #0x0
    8f20:      	b.le	0x8f50 <_stogir.stack.validate-scope-inputs+0x1d0>
    8f24:      	uxtb	w1, w1
    8f28:      	cmp	x1, #0x83
    8f2c:      	cset	w2, lt
    8f30:      	uxtb	w16, w2
    8f34:      	cmp	w16, wzr
    8f38:      	b.eq	0x8f7c <_stogir.stack.validate-scope-inputs+0x1fc>
    8f3c:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008f3c:  ARM64_RELOC_PAGE21	l_stogir.445
    8f40:      	ldr	x17, [x17]
		0000000000008f40:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    8f44:      	add	x3, x1, x17
    8f48:      	ldrb	w3, [x3]
    8f4c:      	b	0x8f80 <_stogir.stack.validate-scope-inputs+0x200>
    8f50:      	mov	x0, #0x1                ; =1
    8f54:      	adrp	x1, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008f54:  ARM64_RELOC_PAGE21	l_stogir.446
    8f58:      	ldr	x1, [x1]
		0000000000008f58:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    8f5c:      	mov	x2, #0x1b               ; =27
    8f60:      	b	0x8e94 <_stogir.stack.validate-scope-inputs+0x114>
    8f64:      	movz	x2, #0x0, lsl #48
    8f68:      	b	0x8eb0 <_stogir.stack.validate-scope-inputs+0x130>
    8f6c:      	movz	x2, #0x0, lsl #48
    8f70:      	b	0x8ed8 <_stogir.stack.validate-scope-inputs+0x158>
    8f74:      	movz	x2, #0x0, lsl #48
    8f78:      	b	0x8f68 <_stogir.stack.validate-scope-inputs+0x1e8>
    8f7c:      	movz	w3, #0x0, lsl #16
    8f80:      	uxtb	w16, w3
    8f84:      	and	w3, w16, #0x1
    8f88:      	uxtb	w3, w3
    8f8c:      	ubfx	x3, x3, #0, #8
    8f90:      	cmp	x3, #0x0
    8f94:      	b.eq	0x8f50 <_stogir.stack.validate-scope-inputs+0x1d0>
    8f98:      	uxtb	w16, w2
    8f9c:      	cmp	w16, wzr
    8fa0:      	b.eq	0x8fb8 <_stogir.stack.validate-scope-inputs+0x238>
    8fa4:      	adrp	x17, 0x8000 <_stogir.terminal.inputs+0x28c>
		0000000000008fa4:  ARM64_RELOC_PAGE21	l_stogir.445
    8fa8:      	ldr	x17, [x17]
		0000000000008fa8:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    8fac:      	add	x1, x1, x17
    8fb0:      	ldrb	w1, [x1]
    8fb4:      	b	0x8fbc <_stogir.stack.validate-scope-inputs+0x23c>
    8fb8:      	movz	w1, #0x0, lsl #16
    8fbc:      	uxtb	w16, w1
    8fc0:      	and	w1, w16, #0x4
    8fc4:      	uxtb	w1, w1
    8fc8:      	ubfx	x1, x1, #0, #8
    8fcc:      	cmp	x1, #0x0
    8fd0:      	cset	w1, eq
    8fd4:      	uxtb	w16, w1
    8fd8:      	cmp	w16, wzr
    8fdc:      	cset	x1, eq
    8fe0:      	cmp	x1, #0x0
    8fe4:      	b.ne	0x8f50 <_stogir.stack.validate-scope-inputs+0x1d0>
    8fe8:      	uxtb	w16, w5
    8fec:      	cmp	w16, wzr
    8ff0:      	b.eq	0x9004 <_stogir.stack.validate-scope-inputs+0x284>
    8ff4:      	movz	x0, #0x0, lsl #48
    8ff8:      	mov	x1, #0x8                ; =8
    8ffc:      	movz	x2, #0x0, lsl #48
    9000:      	b	0x8f60 <_stogir.stack.validate-scope-inputs+0x1e0>
    9004:      	sxtw	x4, w4
    9008:      	cmp	x4, #0x0
    900c:      	cset	w1, gt
    9010:      	movz	x16, #0x0, lsl #48
    9014:      	sub	x2, x16, x4
    9018:      	sub	x3, x2, #0x1
    901c:      	uxtb	w16, w1
    9020:      	cmp	w16, wzr
    9024:      	b.eq	0x90f0 <_stogir.stack.validate-scope-inputs+0x370>
    9028:      	ldr	x2, [x0, #0x8]
    902c:      	cmp	x4, x2
    9030:      	b.ge	0x90e8 <_stogir.stack.validate-scope-inputs+0x368>
    9034:      	ldr	x2, [x7, #0x8]
    9038:      	cmp	x4, x2
    903c:      	b.ge	0x9184 <_stogir.stack.validate-scope-inputs+0x404>
    9040:      	ldr	x2, [x0, #0x78]
    9044:      	add	x2, x2, x4, lsl #2
    9048:      	ldr	w2, [x2]
    904c:      	sxtw	x2, w2
    9050:      	cmp	x2, #0x0
    9054:      	cset	w2, ge
    9058:      	ubfx	x2, x2, #0, #8
    905c:      	b	0x9188 <_stogir.stack.validate-scope-inputs+0x408>
    9060:      	movz	w1, #0x0, lsl #16
    9064:      	movz	x0, #0x0, lsl #48
    9068:      	ubfx	x1, x1, #0, #32
    906c:      	lsr	x16, x1, #0
    9070:      	cmp	x16, #0x1
    9074:      	b.eq	0x9090 <_stogir.stack.validate-scope-inputs+0x310>
    9078:      	b.lo	0x9080 <_stogir.stack.validate-scope-inputs+0x300>
    907c:      	b	0x9094 <_stogir.stack.validate-scope-inputs+0x314>
    9080:      	cmp	x16, #0x0
    9084:      	b.eq	0x908c <_stogir.stack.validate-scope-inputs+0x30c>
    9088:      	b	0x9094 <_stogir.stack.validate-scope-inputs+0x314>
    908c:      	b	0x9098 <_stogir.stack.validate-scope-inputs+0x318>
    9090:      	b	0x9138 <_stogir.stack.validate-scope-inputs+0x3b8>
    9094:      	b	0x9194 <_stogir.stack.validate-scope-inputs+0x414>
    9098:      	mov	x0, #0x1                ; =1
    909c:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		000000000000909c:  ARM64_RELOC_PAGE21	l_stogir.447
    90a0:      	ldr	x1, [x1]
		00000000000090a0:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    90a4:      	mov	x2, #0x1b               ; =27
    90a8:      	b	0x9000 <_stogir.stack.validate-scope-inputs+0x280>
    90ac:      	ldr	x0, [x0, #0x28]
    90b0:      	add	x0, x0, x3, lsl #4
    90b4:      	ldr	x0, [x0]
    90b8:      	mov	w1, #0x1                ; =1
    90bc:      	b	0x9068 <_stogir.stack.validate-scope-inputs+0x2e8>
    90c0:      	movz	x2, #0x0, lsl #48
    90c4:      	cmp	x2, #0x0
    90c8:      	b.eq	0x9060 <_stogir.stack.validate-scope-inputs+0x2e0>
    90cc:      	uxtb	w16, w1
    90d0:      	cmp	w16, wzr
    90d4:      	b.eq	0x90ac <_stogir.stack.validate-scope-inputs+0x32c>
    90d8:      	ldr	x0, [x0]
    90dc:      	add	x0, x0, x4, lsl #4
    90e0:      	ldr	x0, [x0]
    90e4:      	b	0x90b8 <_stogir.stack.validate-scope-inputs+0x338>
    90e8:      	movz	x2, #0x0, lsl #48
    90ec:      	b	0x90c4 <_stogir.stack.validate-scope-inputs+0x344>
    90f0:      	cmp	x4, #0x0
    90f4:      	b.ge	0x90c0 <_stogir.stack.validate-scope-inputs+0x340>
    90f8:      	ldr	x5, [x6, #0x8]
    90fc:      	ldr	x6, [x9, #0x8]
    9100:      	cmp	x5, x6
    9104:      	b.ne	0x917c <_stogir.stack.validate-scope-inputs+0x3fc>
    9108:      	cmp	x2, x5
    910c:      	b.gt	0x918c <_stogir.stack.validate-scope-inputs+0x40c>
    9110:      	ldr	x2, [x0, #0x50]
    9114:      	add	x2, x2, x3, lsl #2
    9118:      	ldr	w2, [x2]
    911c:      	sxtw	x2, w2
    9120:      	cmp	x2, #0x0
    9124:      	cset	w2, gt
    9128:      	ubfx	x2, x2, #0, #8
    912c:      	b	0x9190 <_stogir.stack.validate-scope-inputs+0x410>
    9130:      	brk	#0
    9134:      	b	0x9130 <_stogir.stack.validate-scope-inputs+0x3b0>
    9138:      	orr	w1, w0, wzr
    913c:      	ubfx	x1, x1, #0, #32
    9140:      	ubfx	x1, x1, #8, #8
    9144:      	cmp	x1, #0x6
    9148:      	b.ne	0x9168 <_stogir.stack.validate-scope-inputs+0x3e8>
    914c:      	uxtb	w0, w0
    9150:      	cmp	x0, #0x48
    9154:      	b.eq	0x9168 <_stogir.stack.validate-scope-inputs+0x3e8>
    9158:      	movz	x0, #0x0, lsl #48
    915c:      	mov	x1, #0x8                ; =8
    9160:      	movz	x2, #0x0, lsl #48
    9164:      	b	0x9178 <_stogir.stack.validate-scope-inputs+0x3f8>
    9168:      	mov	x0, #0x1                ; =1
    916c:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		000000000000916c:  ARM64_RELOC_PAGE21	l_stogir.448
    9170:      	ldr	x1, [x1]
		0000000000009170:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    9174:      	mov	x2, #0x29               ; =41
    9178:      	b	0x90a8 <_stogir.stack.validate-scope-inputs+0x328>
    917c:      	movz	x2, #0x0, lsl #48
    9180:      	b	0x90c4 <_stogir.stack.validate-scope-inputs+0x344>
    9184:      	movz	x2, #0x0, lsl #48
    9188:      	b	0x90ec <_stogir.stack.validate-scope-inputs+0x36c>
    918c:      	movz	x2, #0x0, lsl #48
    9190:      	b	0x9180 <_stogir.stack.validate-scope-inputs+0x400>
    9194:      	brk	#0
    9198:      	b	0x9194 <_stogir.stack.validate-scope-inputs+0x414>

000000000000919c <_stogir.stack.validate-inputs>:
    919c:      	sub	sp, sp, #0x110
    91a0:      	str	x29, [sp]
    91a4:      	str	x30, [sp, #0x8]
    91a8:      	mov	x29, sp
    91ac:      	str	x19, [sp, #0xb8]
    91b0:      	str	x20, [sp, #0xc0]
    91b4:      	str	x21, [sp, #0xc8]
    91b8:      	str	x22, [sp, #0xd0]
    91bc:      	str	x23, [sp, #0xd8]
    91c0:      	str	x24, [sp, #0xe0]
    91c4:      	str	x25, [sp, #0xe8]
    91c8:      	str	x26, [sp, #0xf0]
    91cc:      	str	x27, [sp, #0xf8]
    91d0:      	str	x28, [sp, #0x100]
    91d4:      	sxtw	x1, w1
    91d8:      	cmp	x1, #0x51
    91dc:      	cset	w19, eq
    91e0:      	uxtb	w16, w19
    91e4:      	cmp	w16, wzr
    91e8:      	b.ne	0x9250 <_stogir.stack.validate-inputs+0xb4>
    91ec:      	cmp	x1, #0x52
    91f0:      	b.eq	0x9250 <_stogir.stack.validate-inputs+0xb4>
    91f4:      	str	x8, [sp, #0x90]
    91f8:      	mov	x2, #0x1                ; =1
    91fc:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		00000000000091fc:  ARM64_RELOC_PAGE21	l_stogir.449
    9200:      	ldr	x1, [x1]
		0000000000009200:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    9204:      	mov	x0, #0x29               ; =41
    9208:      	ldr	x3, [sp, #0x90]
    920c:      	str	x2, [x3]
    9210:      	str	x1, [x3, #0x8]
    9214:      	str	x0, [x3, #0x10]
    9218:      	ldr	x19, [sp, #0xb8]
    921c:      	ldr	x20, [sp, #0xc0]
    9220:      	ldr	x21, [sp, #0xc8]
    9224:      	ldr	x22, [sp, #0xd0]
    9228:      	ldr	x23, [sp, #0xd8]
    922c:      	ldr	x24, [sp, #0xe0]
    9230:      	ldr	x25, [sp, #0xe8]
    9234:      	ldr	x26, [sp, #0xf0]
    9238:      	ldr	x27, [sp, #0xf8]
    923c:      	ldr	x28, [sp, #0x100]
    9240:      	ldr	x29, [sp]
    9244:      	ldr	x30, [sp, #0x8]
    9248:      	add	sp, sp, #0x110
    924c:      	ret
    9250:      	uxtb	w16, w19
    9254:      	cmp	w16, wzr
    9258:      	mov	w16, #0x6               ; =6
    925c:      	movz	w17, #0x0, lsl #16
    9260:      	csel	w1, w16, w17, ne
    9264:      	sxtw	x2, w2
    9268:      	sxtw	x1, w1
    926c:      	cmp	x2, x1
    9270:      	b.ne	0x9794 <_stogir.stack.validate-inputs+0x5f8>
    9274:      	sxtw	x20, w5
    9278:      	uxtb	w16, w19
    927c:      	cmp	w16, wzr
    9280:      	b.eq	0x92a4 <_stogir.stack.validate-inputs+0x108>
    9284:      	cmp	x20, #0x0
    9288:      	b.eq	0x92a4 <_stogir.stack.validate-inputs+0x108>
    928c:      	cmp	x20, #0x0
    9290:      	b.le	0x9338 <_stogir.stack.validate-inputs+0x19c>
    9294:      	sub	x1, x20, #0x1
    9298:      	and	x1, x1, x20
    929c:      	cmp	x1, #0x0
    92a0:      	b.ne	0x9338 <_stogir.stack.validate-inputs+0x19c>
    92a4:      	mov	w1, w3
    92a8:      	mov	x21, x8
    92ac:      	add	x8, sp, #0x10
    92b0:      	mov	x22, x0
    92b4:      	mov	w23, w3
    92b8:      	mov	w24, w4
    92bc:      	bl	0x92bc <_stogir.stack.validate-inputs+0x120>
		00000000000092bc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    92c0:      	add	x16, sp, #0x10
    92c4:      	ldr	w0, [x16]
    92c8:      	lsr	x16, x0, #0
    92cc:      	cmp	x16, #0x1
    92d0:      	b.eq	0x92ec <_stogir.stack.validate-inputs+0x150>
    92d4:      	b.lo	0x92dc <_stogir.stack.validate-inputs+0x140>
    92d8:      	b	0x92f0 <_stogir.stack.validate-inputs+0x154>
    92dc:      	cmp	x16, #0x0
    92e0:      	b.eq	0x92e8 <_stogir.stack.validate-inputs+0x14c>
    92e4:      	b	0x92f0 <_stogir.stack.validate-inputs+0x154>
    92e8:      	b	0x92f4 <_stogir.stack.validate-inputs+0x158>
    92ec:      	b	0x930c <_stogir.stack.validate-inputs+0x170>
    92f0:      	b	0x95b0 <_stogir.stack.validate-inputs+0x414>
    92f4:      	str	x21, [sp, #0x90]
    92f8:      	mov	x2, #0x1                ; =1
    92fc:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		00000000000092fc:  ARM64_RELOC_PAGE21	l_stogir.450
    9300:      	ldr	x1, [x1]
		0000000000009300:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    9304:      	mov	x0, #0x1f               ; =31
    9308:      	b	0x9208 <_stogir.stack.validate-inputs+0x6c>
    930c:      	sxtw	x23, w23
    9310:      	add	x16, sp, #0x10
    9314:      	ldr	x0, [x16, #0x8]
    9318:      	cmp	x23, #0x0
    931c:      	b.gt	0x9340 <_stogir.stack.validate-inputs+0x1a4>
    9320:      	str	x21, [sp, #0x90]
    9324:      	mov	x2, #0x1                ; =1
    9328:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009328:  ARM64_RELOC_PAGE21	l_stogir.451
    932c:      	ldr	x1, [x1]
		000000000000932c:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    9330:      	mov	x0, #0x1f               ; =31
    9334:      	b	0x9308 <_stogir.stack.validate-inputs+0x16c>
    9338:      	str	x8, [sp, #0x90]
    933c:      	b	0x91f8 <_stogir.stack.validate-inputs+0x5c>
    9340:      	uxtb	w0, w0
    9344:      	cmp	x0, #0x83
    9348:      	cset	w1, lt
    934c:      	uxtb	w16, w1
    9350:      	cmp	w16, wzr
    9354:      	b.eq	0x936c <_stogir.stack.validate-inputs+0x1d0>
    9358:      	adrp	x17, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009358:  ARM64_RELOC_PAGE21	l_stogir.452
    935c:      	ldr	x17, [x17]
		000000000000935c:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    9360:      	add	x2, x0, x17
    9364:      	ldrb	w2, [x2]
    9368:      	b	0x9370 <_stogir.stack.validate-inputs+0x1d4>
    936c:      	movz	w2, #0x0, lsl #16
    9370:      	uxtb	w16, w2
    9374:      	and	w2, w16, #0x1
    9378:      	uxtb	w2, w2
    937c:      	ubfx	x2, x2, #0, #8
    9380:      	cmp	x2, #0x0
    9384:      	b.eq	0x979c <_stogir.stack.validate-inputs+0x600>
    9388:      	uxtb	w16, w1
    938c:      	cmp	w16, wzr
    9390:      	b.eq	0x93a8 <_stogir.stack.validate-inputs+0x20c>
    9394:      	adrp	x17, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009394:  ARM64_RELOC_PAGE21	l_stogir.452
    9398:      	ldr	x17, [x17]
		0000000000009398:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    939c:      	add	x0, x0, x17
    93a0:      	ldrb	w0, [x0]
    93a4:      	b	0x93ac <_stogir.stack.validate-inputs+0x210>
    93a8:      	movz	w0, #0x0, lsl #16
    93ac:      	uxtb	w16, w0
    93b0:      	and	w0, w16, #0x4
    93b4:      	uxtb	w0, w0
    93b8:      	ubfx	x0, x0, #0, #8
    93bc:      	cmp	x0, #0x0
    93c0:      	cset	w0, eq
    93c4:      	uxtb	w16, w0
    93c8:      	cmp	w16, wzr
    93cc:      	cset	x0, eq
    93d0:      	cmp	x0, #0x0
    93d4:      	b.ne	0x97a4 <_stogir.stack.validate-inputs+0x608>
    93d8:      	add	x8, sp, #0x40
    93dc:      	mov	x0, x22
    93e0:      	mov	w1, w24
    93e4:      	bl	0x93e4 <_stogir.stack.validate-inputs+0x248>
		00000000000093e4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    93e8:      	add	x16, sp, #0x40
    93ec:      	ldr	w0, [x16]
    93f0:      	lsr	x16, x0, #0
    93f4:      	cmp	x16, #0x1
    93f8:      	b.eq	0x9414 <_stogir.stack.validate-inputs+0x278>
    93fc:      	b.lo	0x9404 <_stogir.stack.validate-inputs+0x268>
    9400:      	b	0x9418 <_stogir.stack.validate-inputs+0x27c>
    9404:      	cmp	x16, #0x0
    9408:      	b.eq	0x9410 <_stogir.stack.validate-inputs+0x274>
    940c:      	b	0x9418 <_stogir.stack.validate-inputs+0x27c>
    9410:      	b	0x941c <_stogir.stack.validate-inputs+0x280>
    9414:      	b	0x9434 <_stogir.stack.validate-inputs+0x298>
    9418:      	b	0x969c <_stogir.stack.validate-inputs+0x500>
    941c:      	str	x21, [sp, #0x90]
    9420:      	mov	x2, #0x1                ; =1
    9424:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009424:  ARM64_RELOC_PAGE21	l_stogir.453
    9428:      	ldr	x1, [x1]
		0000000000009428:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    942c:      	mov	x0, #0x18               ; =24
    9430:      	b	0x9334 <_stogir.stack.validate-inputs+0x198>
    9434:      	add	x16, sp, #0x40
    9438:      	ldr	x0, [x16, #0x8]
    943c:      	orr	w1, w0, wzr
    9440:      	ubfx	x1, x1, #0, #32
    9444:      	ubfx	x1, x1, #8, #8
    9448:      	cmp	x1, #0x1
    944c:      	b.lt	0x97ac <_stogir.stack.validate-inputs+0x610>
    9450:      	cmp	x1, #0xb
    9454:      	b.gt	0x97b4 <_stogir.stack.validate-inputs+0x618>
    9458:      	uxtb	w0, w0
    945c:      	cmp	x0, #0x48
    9460:      	b.eq	0x97bc <_stogir.stack.validate-inputs+0x620>
    9464:      	sxtw	x0, w24
    9468:      	cmp	x1, #0x0
    946c:      	cset	w23, eq
    9470:      	cmp	x1, #0x1
    9474:      	cset	w25, eq
    9478:      	cmp	x1, #0x2
    947c:      	cset	w26, eq
    9480:      	cmp	x1, #0x7
    9484:      	cset	w27, eq
    9488:      	cmp	x1, #0x8
    948c:      	cset	w28, eq
    9490:      	cmp	x1, #0x3
    9494:      	cset	w2, eq
    9498:      	cmp	x1, #0x9
    949c:      	cset	w3, eq
    94a0:      	cmp	x1, #0x4
    94a4:      	cset	w4, eq
    94a8:      	cmp	x1, #0xa
    94ac:      	cset	w5, eq
    94b0:      	cmp	x1, #0xd
    94b4:      	cset	w6, eq
    94b8:      	cmp	x1, #0x5
    94bc:      	cset	w7, eq
    94c0:      	cmp	x1, #0xb
    94c4:      	cset	w8, eq
    94c8:      	cmp	x1, #0xc
    94cc:      	cset	w9, eq
    94d0:      	cmp	x1, #0x6
    94d4:      	cset	w1, eq
    94d8:      	uxtb	w16, w1
    94dc:      	cmp	w16, wzr
    94e0:      	mov	w16, #0x8               ; =8
    94e4:      	movn	w17, #0x0, lsl #16
    94e8:      	csel	w1, w16, w17, ne
    94ec:      	cmp	x0, #0x0
    94f0:      	b.ge	0x97c4 <_stogir.stack.validate-inputs+0x628>
    94f4:      	uxtb	w16, w19
    94f8:      	cmp	w16, wzr
    94fc:      	b.eq	0x9508 <_stogir.stack.validate-inputs+0x36c>
    9500:      	cmp	x20, #0x10
    9504:      	b.gt	0x950c <_stogir.stack.validate-inputs+0x370>
    9508:      	mov	x20, #0x10              ; =16
    950c:      	mov	x0, x22
    9510:      	mov	w19, w2
    9514:      	mov	x2, x20
    9518:      	mov	w20, w3
    951c:      	mov	w22, w4
    9520:      	str	w7, [sp, #0x98]
    9524:      	str	w8, [sp, #0xa0]
    9528:      	add	x8, sp, #0x70
    952c:      	str	w9, [sp, #0xa8]
    9530:      	str	w1, [sp, #0xb0]
    9534:      	mov	w1, w24
    9538:      	mov	w24, w5
    953c:      	str	x21, [sp, #0x90]
    9540:      	mov	w21, w6
    9544:      	bl	0x9544 <_stogir.stack.validate-inputs+0x3a8>
		0000000000009544:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    9548:      	add	x16, sp, #0x70
    954c:      	ldr	w0, [x16]
    9550:      	lsr	x16, x0, #0
    9554:      	cmp	x16, #0x1
    9558:      	b.eq	0x9574 <_stogir.stack.validate-inputs+0x3d8>
    955c:      	b.lo	0x9564 <_stogir.stack.validate-inputs+0x3c8>
    9560:      	b	0x9578 <_stogir.stack.validate-inputs+0x3dc>
    9564:      	cmp	x16, #0x0
    9568:      	b.eq	0x9570 <_stogir.stack.validate-inputs+0x3d4>
    956c:      	b	0x9578 <_stogir.stack.validate-inputs+0x3dc>
    9570:      	b	0x96a4 <_stogir.stack.validate-inputs+0x508>
    9574:      	b	0x957c <_stogir.stack.validate-inputs+0x3e0>
    9578:      	b	0x9778 <_stogir.stack.validate-inputs+0x5dc>
    957c:      	add	x16, sp, #0x70
    9580:      	orr	x0, x16, xzr
    9584:      	add	x0, x0, #0x8
    9588:      	add	x16, sp, #0x70
    958c:      	ldr	x1, [x16, #0x8]
    9590:      	ldr	x0, [x0, #0x8]
    9594:      	mov	x2, #0x1                ; =1
    9598:      	b	0x9600 <_stogir.stack.validate-inputs+0x464>
    959c:      	mov	x2, #0x1                ; =1
    95a0:      	adrp	x1, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		00000000000095a0:  ARM64_RELOC_PAGE21	l_stogir.454
    95a4:      	ldr	x1, [x1]
		00000000000095a4:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    95a8:      	mov	x0, #0x29               ; =41
    95ac:      	b	0x9430 <_stogir.stack.validate-inputs+0x294>
    95b0:      	brk	#0
    95b4:      	b	0x95b0 <_stogir.stack.validate-inputs+0x414>
    95b8:      	mov	w3, #0x1                ; =1
    95bc:      	sxtw	x3, w3
    95c0:      	and	x1, x3, #0xffffffff
    95c4:      	movz	x2, #0x0, lsl #48
    95c8:      	movz	x0, #0x0, lsl #48
    95cc:      	b	0x95ac <_stogir.stack.validate-inputs+0x410>
    95d0:      	uxtb	w16, w23
    95d4:      	cmp	w16, wzr
    95d8:      	b.eq	0x9604 <_stogir.stack.validate-inputs+0x468>
    95dc:      	movz	w3, #0x0, lsl #16
    95e0:      	b	0x95bc <_stogir.stack.validate-inputs+0x420>
    95e4:      	mov	w16, #0x1               ; =1
    95e8:      	str	w16, [sp, #0xb0]
    95ec:      	ldr	w3, [sp, #0xb0]
    95f0:      	sxtw	x3, w3
    95f4:      	and	x1, x3, #0xffffffff
    95f8:      	movz	x2, #0x0, lsl #48
    95fc:      	movz	x0, #0x0, lsl #48
    9600:      	b	0x95cc <_stogir.stack.validate-inputs+0x430>
    9604:      	uxtb	w16, w25
    9608:      	cmp	w16, wzr
    960c:      	b.ne	0x95b8 <_stogir.stack.validate-inputs+0x41c>
    9610:      	uxtb	w16, w26
    9614:      	cmp	w16, wzr
    9618:      	b.ne	0x95b8 <_stogir.stack.validate-inputs+0x41c>
    961c:      	uxtb	w16, w27
    9620:      	cmp	w16, wzr
    9624:      	b.ne	0x95b8 <_stogir.stack.validate-inputs+0x41c>
    9628:      	uxtb	w16, w28
    962c:      	cmp	w16, wzr
    9630:      	b.ne	0x95b8 <_stogir.stack.validate-inputs+0x41c>
    9634:      	uxtb	w16, w19
    9638:      	cmp	w16, wzr
    963c:      	b.ne	0x9764 <_stogir.stack.validate-inputs+0x5c8>
    9640:      	uxtb	w16, w20
    9644:      	cmp	w16, wzr
    9648:      	b.ne	0x9764 <_stogir.stack.validate-inputs+0x5c8>
    964c:      	uxtb	w16, w22
    9650:      	cmp	w16, wzr
    9654:      	b.ne	0x9780 <_stogir.stack.validate-inputs+0x5e4>
    9658:      	uxtb	w16, w24
    965c:      	cmp	w16, wzr
    9660:      	b.ne	0x9780 <_stogir.stack.validate-inputs+0x5e4>
    9664:      	uxtb	w16, w21
    9668:      	cmp	w16, wzr
    966c:      	b.ne	0x9780 <_stogir.stack.validate-inputs+0x5e4>
    9670:      	uxtb	w16, w0
    9674:      	cmp	w16, wzr
    9678:      	b.ne	0x9694 <_stogir.stack.validate-inputs+0x4f8>
    967c:      	uxtb	w16, w1
    9680:      	cmp	w16, wzr
    9684:      	b.ne	0x9694 <_stogir.stack.validate-inputs+0x4f8>
    9688:      	uxtb	w16, w2
    968c:      	cmp	w16, wzr
    9690:      	b.eq	0x9698 <_stogir.stack.validate-inputs+0x4fc>
    9694:      	mov	w3, #0x8                ; =8
    9698:      	b	0x9784 <_stogir.stack.validate-inputs+0x5e8>
    969c:      	brk	#0
    96a0:      	b	0x969c <_stogir.stack.validate-inputs+0x500>
    96a4:      	uxtb	w16, w23
    96a8:      	cmp	w16, wzr
    96ac:      	b.eq	0x96bc <_stogir.stack.validate-inputs+0x520>
    96b0:      	movz	w16, #0x0, lsl #16
    96b4:      	str	w16, [sp, #0xb0]
    96b8:      	b	0x95ec <_stogir.stack.validate-inputs+0x450>
    96bc:      	uxtb	w16, w25
    96c0:      	cmp	w16, wzr
    96c4:      	b.ne	0x95e4 <_stogir.stack.validate-inputs+0x448>
    96c8:      	uxtb	w16, w26
    96cc:      	cmp	w16, wzr
    96d0:      	b.ne	0x95e4 <_stogir.stack.validate-inputs+0x448>
    96d4:      	uxtb	w16, w27
    96d8:      	cmp	w16, wzr
    96dc:      	b.ne	0x95e4 <_stogir.stack.validate-inputs+0x448>
    96e0:      	uxtb	w16, w28
    96e4:      	cmp	w16, wzr
    96e8:      	b.ne	0x95e4 <_stogir.stack.validate-inputs+0x448>
    96ec:      	uxtb	w16, w19
    96f0:      	cmp	w16, wzr
    96f4:      	b.ne	0x976c <_stogir.stack.validate-inputs+0x5d0>
    96f8:      	uxtb	w16, w20
    96fc:      	cmp	w16, wzr
    9700:      	b.ne	0x976c <_stogir.stack.validate-inputs+0x5d0>
    9704:      	uxtb	w16, w22
    9708:      	cmp	w16, wzr
    970c:      	b.ne	0x9788 <_stogir.stack.validate-inputs+0x5ec>
    9710:      	uxtb	w16, w24
    9714:      	cmp	w16, wzr
    9718:      	b.ne	0x9788 <_stogir.stack.validate-inputs+0x5ec>
    971c:      	uxtb	w16, w21
    9720:      	cmp	w16, wzr
    9724:      	b.ne	0x9788 <_stogir.stack.validate-inputs+0x5ec>
    9728:      	ldr	w0, [sp, #0x98]
    972c:      	uxtb	w16, w0
    9730:      	cmp	w16, wzr
    9734:      	b.ne	0x9758 <_stogir.stack.validate-inputs+0x5bc>
    9738:      	ldr	w1, [sp, #0xa0]
    973c:      	uxtb	w16, w1
    9740:      	cmp	w16, wzr
    9744:      	b.ne	0x9758 <_stogir.stack.validate-inputs+0x5bc>
    9748:      	ldr	w2, [sp, #0xa8]
    974c:      	uxtb	w16, w2
    9750:      	cmp	w16, wzr
    9754:      	b.eq	0x9760 <_stogir.stack.validate-inputs+0x5c4>
    9758:      	mov	w16, #0x8               ; =8
    975c:      	str	w16, [sp, #0xb0]
    9760:      	b	0x9790 <_stogir.stack.validate-inputs+0x5f4>
    9764:      	mov	w3, #0x2                ; =2
    9768:      	b	0x95bc <_stogir.stack.validate-inputs+0x420>
    976c:      	mov	w16, #0x2               ; =2
    9770:      	str	w16, [sp, #0xb0]
    9774:      	b	0x95ec <_stogir.stack.validate-inputs+0x450>
    9778:      	brk	#0
    977c:      	b	0x9778 <_stogir.stack.validate-inputs+0x5dc>
    9780:      	mov	w3, #0x4                ; =4
    9784:      	b	0x9768 <_stogir.stack.validate-inputs+0x5cc>
    9788:      	mov	w16, #0x4               ; =4
    978c:      	str	w16, [sp, #0xb0]
    9790:      	b	0x9774 <_stogir.stack.validate-inputs+0x5d8>
    9794:      	str	x8, [sp, #0x90]
    9798:      	b	0x91f8 <_stogir.stack.validate-inputs+0x5c>
    979c:      	str	x21, [sp, #0x90]
    97a0:      	b	0x9324 <_stogir.stack.validate-inputs+0x188>
    97a4:      	str	x21, [sp, #0x90]
    97a8:      	b	0x9324 <_stogir.stack.validate-inputs+0x188>
    97ac:      	str	x21, [sp, #0x90]
    97b0:      	b	0x959c <_stogir.stack.validate-inputs+0x400>
    97b4:      	str	x21, [sp, #0x90]
    97b8:      	b	0x959c <_stogir.stack.validate-inputs+0x400>
    97bc:      	str	x21, [sp, #0x90]
    97c0:      	b	0x959c <_stogir.stack.validate-inputs+0x400>
    97c4:      	str	x21, [sp, #0x90]
    97c8:      	mov	w19, w2
    97cc:      	mov	w20, w3
    97d0:      	mov	w3, w1
    97d4:      	mov	w22, w4
    97d8:      	mov	w24, w5
    97dc:      	mov	w21, w6
    97e0:      	mov	w0, w7
    97e4:      	mov	w1, w8
    97e8:      	mov	w2, w9
    97ec:      	b	0x95d0 <_stogir.stack.validate-inputs+0x434>

00000000000097f0 <_stogir.locals.shape>:
    97f0:      	sub	sp, sp, #0x60
    97f4:      	str	x29, [sp]
    97f8:      	str	x30, [sp, #0x8]
    97fc:      	mov	x29, sp
    9800:      	str	x19, [sp, #0x20]
    9804:      	str	x20, [sp, #0x28]
    9808:      	str	x21, [sp, #0x30]
    980c:      	str	x22, [sp, #0x38]
    9810:      	str	x23, [sp, #0x40]
    9814:      	str	x24, [sp, #0x48]
    9818:      	str	x25, [sp, #0x50]
    981c:      	str	x26, [sp, #0x58]
    9820:      	sxtw	x19, w1
    9824:      	add	x20, x0, #0x78
    9828:      	add	x21, x0, #0x28
    982c:      	add	x22, x0, #0x50
    9830:      	lsl	x23, x19, #2
    9834:      	cmp	x19, #0x0
    9838:      	cset	w1, gt
    983c:      	movz	x16, #0x0, lsl #48
    9840:      	sub	x3, x16, x19
    9844:      	sub	x4, x3, #0x1
    9848:      	uxtb	w16, w1
    984c:      	cmp	w16, wzr
    9850:      	b.eq	0x988c <_stogir.locals.shape+0x9c>
    9854:      	ldr	x3, [x0, #0x8]
    9858:      	cmp	x19, x3
    985c:      	b.ge	0x98e8 <_stogir.locals.shape+0xf8>
    9860:      	ldr	x3, [x20, #0x8]
    9864:      	cmp	x19, x3
    9868:      	b.ge	0x9a84 <_stogir.locals.shape+0x294>
    986c:      	ldr	x3, [x0, #0x78]
    9870:      	add	x3, x23, x3
    9874:      	ldr	w3, [x3]
    9878:      	sxtw	x3, w3
    987c:      	cmp	x3, #0x0
    9880:      	cset	w3, ge
    9884:      	ubfx	x3, x3, #0, #8
    9888:      	b	0x9a88 <_stogir.locals.shape+0x298>
    988c:      	cmp	x19, #0x0
    9890:      	b.ge	0x98f0 <_stogir.locals.shape+0x100>
    9894:      	ldr	x5, [x21, #0x8]
    9898:      	ldr	x6, [x22, #0x8]
    989c:      	cmp	x5, x6
    98a0:      	b.ne	0x98cc <_stogir.locals.shape+0xdc>
    98a4:      	cmp	x3, x5
    98a8:      	b.gt	0x9b80 <_stogir.locals.shape+0x390>
    98ac:      	ldr	x3, [x0, #0x50]
    98b0:      	add	x3, x3, x4, lsl #2
    98b4:      	ldr	w3, [x3]
    98b8:      	sxtw	x3, w3
    98bc:      	cmp	x3, #0x0
    98c0:      	cset	w3, gt
    98c4:      	ubfx	x3, x3, #0, #8
    98c8:      	b	0x9b84 <_stogir.locals.shape+0x394>
    98cc:      	movz	x3, #0x0, lsl #48
    98d0:      	b	0x98f4 <_stogir.locals.shape+0x104>
    98d4:      	mov	x1, #0x1                ; =1
    98d8:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		00000000000098d8:  ARM64_RELOC_PAGE21	l_stogir.455
    98dc:      	ldr	x0, [x0]
		00000000000098dc:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    98e0:      	mov	x24, #0x1c              ; =28
    98e4:      	b	0x9984 <_stogir.locals.shape+0x194>
    98e8:      	movz	x3, #0x0, lsl #48
    98ec:      	b	0x98f4 <_stogir.locals.shape+0x104>
    98f0:      	movz	x3, #0x0, lsl #48
    98f4:      	cmp	x3, #0x0
    98f8:      	b.eq	0x9934 <_stogir.locals.shape+0x144>
    98fc:      	uxtb	w16, w1
    9900:      	cmp	w16, wzr
    9904:      	b.eq	0x991c <_stogir.locals.shape+0x12c>
    9908:      	ldr	x1, [x0]
    990c:      	add	x1, x1, x19, lsl #4
    9910:      	ldr	x3, [x1]
    9914:      	ldr	x1, [x1, #0x8]
    9918:      	b	0x992c <_stogir.locals.shape+0x13c>
    991c:      	ldr	x1, [x0, #0x28]
    9920:      	add	x1, x1, x4, lsl #4
    9924:      	ldr	x3, [x1]
    9928:      	ldr	x1, [x1, #0x8]
    992c:      	mov	w4, #0x1                ; =1
    9930:      	b	0x9940 <_stogir.locals.shape+0x150>
    9934:      	movz	w4, #0x0, lsl #16
    9938:      	movz	x3, #0x0, lsl #48
    993c:      	movz	x1, #0x0, lsl #48
    9940:      	ubfx	x4, x4, #0, #32
    9944:      	lsr	x16, x4, #0
    9948:      	cmp	x16, #0x1
    994c:      	b.eq	0x9968 <_stogir.locals.shape+0x178>
    9950:      	b.lo	0x9958 <_stogir.locals.shape+0x168>
    9954:      	b	0x996c <_stogir.locals.shape+0x17c>
    9958:      	cmp	x16, #0x0
    995c:      	b.eq	0x9964 <_stogir.locals.shape+0x174>
    9960:      	b	0x996c <_stogir.locals.shape+0x17c>
    9964:      	b	0x9970 <_stogir.locals.shape+0x180>
    9968:      	b	0x99c0 <_stogir.locals.shape+0x1d0>
    996c:      	b	0x9b90 <_stogir.locals.shape+0x3a0>
    9970:      	mov	x25, x8
    9974:      	mov	x1, #0x1                ; =1
    9978:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009978:  ARM64_RELOC_PAGE21	l_stogir.456
    997c:      	ldr	x0, [x0]
		000000000000997c:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    9980:      	mov	x24, #0x16              ; =22
    9984:      	str	x1, [x25]
    9988:      	str	x0, [x25, #0x8]
    998c:      	str	x24, [x25, #0x10]
    9990:      	ldr	x19, [sp, #0x20]
    9994:      	ldr	x20, [sp, #0x28]
    9998:      	ldr	x21, [sp, #0x30]
    999c:      	ldr	x22, [sp, #0x38]
    99a0:      	ldr	x23, [sp, #0x40]
    99a4:      	ldr	x24, [sp, #0x48]
    99a8:      	ldr	x25, [sp, #0x50]
    99ac:      	ldr	x26, [sp, #0x58]
    99b0:      	ldr	x29, [sp]
    99b4:      	ldr	x30, [sp, #0x8]
    99b8:      	add	sp, sp, #0x60
    99bc:      	ret
    99c0:      	asr	x24, x1, #32
    99c4:      	orr	w4, w3, wzr
    99c8:      	add	x16, sp, #0x10
    99cc:      	str	x3, [x16]
    99d0:      	ubfx	x4, x4, #0, #32
    99d4:      	add	x16, sp, #0x10
    99d8:      	str	x1, [x16, #0x8]
    99dc:      	ubfx	x1, x4, #8, #8
    99e0:      	mov	x25, x8
    99e4:      	mov	x26, x0
    99e8:      	mov	w0, w1
    99ec:      	mov	w1, w2
    99f0:      	bl	0x99f0 <_stogir.locals.shape+0x200>
		00000000000099f0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    99f4:      	sxtw	x0, w0
    99f8:      	cmp	x24, #0x0
    99fc:      	b.ne	0x9a04 <_stogir.locals.shape+0x214>
    9a00:      	mov	x24, x0
    9a04:      	add	x16, sp, #0x10
    9a08:      	ldr	w1, [x16, #0x8]
    9a0c:      	sxtw	x1, w1
    9a10:      	cmp	x1, #0x0
    9a14:      	cset	w2, eq
    9a18:      	ubfx	x2, x2, #0, #8
    9a1c:      	cmp	x1, #0x0
    9a20:      	b.le	0x9ac4 <_stogir.locals.shape+0x2d4>
    9a24:      	add	x3, x26, #0x110
    9a28:      	add	x4, x3, #0x28
    9a2c:      	ldr	x4, [x4, #0x8]
    9a30:      	cmp	x1, x4
    9a34:      	b.gt	0x9a8c <_stogir.locals.shape+0x29c>
    9a38:      	sub	x1, x1, #0x1
    9a3c:      	mov	x17, #0x18              ; =24
    9a40:      	mul	x1, x1, x17
    9a44:      	ldr	x4, [x3, #0x28]
    9a48:      	add	x1, x1, x4
    9a4c:      	ldr	x4, [x1]
    9a50:      	ldr	x1, [x1, #0x8]
    9a54:      	ldr	x3, [x3, #0x8]
    9a58:      	cmp	x4, #0x0
    9a5c:      	b.lt	0x9b88 <_stogir.locals.shape+0x398>
    9a60:      	cmp	x4, x3
    9a64:      	b.gt	0x9b88 <_stogir.locals.shape+0x398>
    9a68:      	cmp	x1, #0x0
    9a6c:      	b.lt	0x9b88 <_stogir.locals.shape+0x398>
    9a70:      	sub	x3, x3, x4
    9a74:      	cmp	x1, x3
    9a78:      	b.gt	0x9b88 <_stogir.locals.shape+0x398>
    9a7c:      	mov	w1, #0x1                ; =1
    9a80:      	b	0x9b8c <_stogir.locals.shape+0x39c>
    9a84:      	movz	x3, #0x0, lsl #48
    9a88:      	b	0x98ec <_stogir.locals.shape+0xfc>
    9a8c:      	movz	w1, #0x0, lsl #16
    9a90:      	ubfx	x1, x1, #0, #32
    9a94:      	lsr	x16, x1, #0
    9a98:      	cmp	x16, #0x1
    9a9c:      	b.eq	0x9ab8 <_stogir.locals.shape+0x2c8>
    9aa0:      	b.lo	0x9aa8 <_stogir.locals.shape+0x2b8>
    9aa4:      	b	0x9abc <_stogir.locals.shape+0x2cc>
    9aa8:      	cmp	x16, #0x0
    9aac:      	b.eq	0x9ab4 <_stogir.locals.shape+0x2c4>
    9ab0:      	b	0x9abc <_stogir.locals.shape+0x2cc>
    9ab4:      	b	0x9ac4 <_stogir.locals.shape+0x2d4>
    9ab8:      	b	0x9ac0 <_stogir.locals.shape+0x2d0>
    9abc:      	b	0x9b98 <_stogir.locals.shape+0x3a8>
    9ac0:      	mov	x2, #0x1                ; =1
    9ac4:      	cmp	x19, #0x0
    9ac8:      	b.le	0x98d4 <_stogir.locals.shape+0xe4>
    9acc:      	add	x16, sp, #0x10
    9ad0:      	ldr	w1, [x16]
    9ad4:      	uxtb	w1, w1
    9ad8:      	cmp	x1, #0x48
    9adc:      	b.ne	0x98d4 <_stogir.locals.shape+0xe4>
    9ae0:      	ldr	x1, [x26, #0x78]
    9ae4:      	add	x3, x23, x1
    9ae8:      	ldr	w3, [x3]
    9aec:      	sxtw	x3, w3
    9af0:      	cmp	x3, #0x3
    9af4:      	b.ne	0x98d4 <_stogir.locals.shape+0xe4>
    9af8:      	cmp	x0, #0x0
    9afc:      	b.le	0x98d4 <_stogir.locals.shape+0xe4>
    9b00:      	cmp	x2, #0x0
    9b04:      	b.eq	0x98d4 <_stogir.locals.shape+0xe4>
    9b08:      	cmp	x24, #0x0
    9b0c:      	b.le	0x98d4 <_stogir.locals.shape+0xe4>
    9b10:      	sub	x2, x24, #0x1
    9b14:      	and	x2, x2, x24
    9b18:      	cmp	x2, #0x0
    9b1c:      	b.ne	0x98d4 <_stogir.locals.shape+0xe4>
    9b20:      	add	x16, sp, #0x10
    9b24:      	ldr	w2, [x16, #0x4]
    9b28:      	sxtw	x2, w2
    9b2c:      	cmp	x2, #0x0
    9b30:      	cset	w3, gt
    9b34:      	movz	x16, #0x0, lsl #48
    9b38:      	sub	x4, x16, x2
    9b3c:      	sub	x5, x4, #0x1
    9b40:      	uxtb	w16, w3
    9b44:      	cmp	w16, wzr
    9b48:      	b.eq	0x9bb4 <_stogir.locals.shape+0x3c4>
    9b4c:      	ldr	x4, [x26, #0x8]
    9b50:      	cmp	x2, x4
    9b54:      	b.ge	0x9bf4 <_stogir.locals.shape+0x404>
    9b58:      	ldr	x4, [x20, #0x8]
    9b5c:      	cmp	x2, x4
    9b60:      	b.ge	0x9cc0 <_stogir.locals.shape+0x4d0>
    9b64:      	add	x1, x1, x2, lsl #2
    9b68:      	ldr	w1, [x1]
    9b6c:      	sxtw	x1, w1
    9b70:      	cmp	x1, #0x0
    9b74:      	cset	w1, ge
    9b78:      	ubfx	x1, x1, #0, #8
    9b7c:      	b	0x9cc4 <_stogir.locals.shape+0x4d4>
    9b80:      	movz	x3, #0x0, lsl #48
    9b84:      	b	0x98d0 <_stogir.locals.shape+0xe0>
    9b88:      	movz	w1, #0x0, lsl #16
    9b8c:      	b	0x9a90 <_stogir.locals.shape+0x2a0>
    9b90:      	brk	#0
    9b94:      	b	0x9b90 <_stogir.locals.shape+0x3a0>
    9b98:      	brk	#0
    9b9c:      	b	0x9b98 <_stogir.locals.shape+0x3a8>
    9ba0:      	mov	x1, #0x1                ; =1
    9ba4:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009ba4:  ARM64_RELOC_PAGE21	l_stogir.457
    9ba8:      	ldr	x0, [x0]
		0000000000009ba8:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    9bac:      	mov	x24, #0x2c              ; =44
    9bb0:      	b	0x98e4 <_stogir.locals.shape+0xf4>
    9bb4:      	cmp	x2, #0x0
    9bb8:      	b.ge	0x9bfc <_stogir.locals.shape+0x40c>
    9bbc:      	ldr	x1, [x21, #0x8]
    9bc0:      	ldr	x6, [x22, #0x8]
    9bc4:      	cmp	x1, x6
    9bc8:      	b.ne	0x9cb8 <_stogir.locals.shape+0x4c8>
    9bcc:      	cmp	x4, x1
    9bd0:      	b.gt	0x9cc8 <_stogir.locals.shape+0x4d8>
    9bd4:      	ldr	x1, [x26, #0x50]
    9bd8:      	add	x1, x1, x5, lsl #2
    9bdc:      	ldr	w1, [x1]
    9be0:      	sxtw	x1, w1
    9be4:      	cmp	x1, #0x0
    9be8:      	cset	w1, gt
    9bec:      	ubfx	x1, x1, #0, #8
    9bf0:      	b	0x9ccc <_stogir.locals.shape+0x4dc>
    9bf4:      	movz	x1, #0x0, lsl #48
    9bf8:      	b	0x9c00 <_stogir.locals.shape+0x410>
    9bfc:      	movz	x1, #0x0, lsl #48
    9c00:      	cmp	x1, #0x0
    9c04:      	b.eq	0x9c38 <_stogir.locals.shape+0x448>
    9c08:      	uxtb	w16, w3
    9c0c:      	cmp	w16, wzr
    9c10:      	b.eq	0x9c24 <_stogir.locals.shape+0x434>
    9c14:      	ldr	x1, [x26]
    9c18:      	add	x1, x1, x2, lsl #4
    9c1c:      	ldr	x1, [x1]
    9c20:      	b	0x9c30 <_stogir.locals.shape+0x440>
    9c24:      	ldr	x1, [x26, #0x28]
    9c28:      	add	x1, x1, x5, lsl #4
    9c2c:      	ldr	x1, [x1]
    9c30:      	mov	w2, #0x1                ; =1
    9c34:      	b	0x9c40 <_stogir.locals.shape+0x450>
    9c38:      	movz	w2, #0x0, lsl #16
    9c3c:      	movz	x1, #0x0, lsl #48
    9c40:      	ubfx	x2, x2, #0, #32
    9c44:      	lsr	x16, x2, #0
    9c48:      	cmp	x16, #0x1
    9c4c:      	b.eq	0x9c68 <_stogir.locals.shape+0x478>
    9c50:      	b.lo	0x9c58 <_stogir.locals.shape+0x468>
    9c54:      	b	0x9c6c <_stogir.locals.shape+0x47c>
    9c58:      	cmp	x16, #0x0
    9c5c:      	b.eq	0x9c64 <_stogir.locals.shape+0x474>
    9c60:      	b	0x9c6c <_stogir.locals.shape+0x47c>
    9c64:      	b	0x9c70 <_stogir.locals.shape+0x480>
    9c68:      	b	0x9c84 <_stogir.locals.shape+0x494>
    9c6c:      	b	0x9d08 <_stogir.locals.shape+0x518>
    9c70:      	mov	x1, #0x1                ; =1
    9c74:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009c74:  ARM64_RELOC_PAGE21	l_stogir.458
    9c78:      	ldr	x0, [x0]
		0000000000009c78:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    9c7c:      	mov	x24, #0x1d              ; =29
    9c80:      	b	0x9bb0 <_stogir.locals.shape+0x3c0>
    9c84:      	add	x16, sp, #0x10
    9c88:      	ldr	w2, [x16, #0x4]
    9c8c:      	sxtw	x2, w2
    9c90:      	cmp	x2, #0x0
    9c94:      	b.le	0x9ba0 <_stogir.locals.shape+0x3b0>
    9c98:      	uxtb	w1, w1
    9c9c:      	cmp	x1, #0x83
    9ca0:      	b.ge	0x9cd0 <_stogir.locals.shape+0x4e0>
    9ca4:      	adrp	x17, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009ca4:  ARM64_RELOC_PAGE21	l_stogir.459
    9ca8:      	ldr	x17, [x17]
		0000000000009ca8:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    9cac:      	add	x1, x1, x17
    9cb0:      	ldrb	w1, [x1]
    9cb4:      	b	0x9cd4 <_stogir.locals.shape+0x4e4>
    9cb8:      	movz	x1, #0x0, lsl #48
    9cbc:      	b	0x9c00 <_stogir.locals.shape+0x410>
    9cc0:      	movz	x1, #0x0, lsl #48
    9cc4:      	b	0x9bf8 <_stogir.locals.shape+0x408>
    9cc8:      	movz	x1, #0x0, lsl #48
    9ccc:      	b	0x9cbc <_stogir.locals.shape+0x4cc>
    9cd0:      	movz	w1, #0x0, lsl #16
    9cd4:      	uxtb	w16, w1
    9cd8:      	and	w1, w16, #0x2
    9cdc:      	uxtb	w1, w1
    9ce0:      	ubfx	x1, x1, #0, #8
    9ce4:      	cmp	x1, #0x0
    9ce8:      	cset	w1, eq
    9cec:      	uxtb	w16, w1
    9cf0:      	cmp	w16, wzr
    9cf4:      	cset	x1, eq
    9cf8:      	cmp	x1, #0x0
    9cfc:      	b.eq	0x9ba0 <_stogir.locals.shape+0x3b0>
    9d00:      	movz	x1, #0x0, lsl #48
    9d04:      	b	0x9bb0 <_stogir.locals.shape+0x3c0>
    9d08:      	brk	#0
    9d0c:      	b	0x9d08 <_stogir.locals.shape+0x518>

0000000000009d10 <_stogir.conversion.policy>:
    9d10:      	sub	sp, sp, #0x70
    9d14:      	str	x29, [sp]
    9d18:      	str	x30, [sp, #0x8]
    9d1c:      	mov	x29, sp
    9d20:      	str	x19, [sp, #0x18]
    9d24:      	str	x20, [sp, #0x20]
    9d28:      	str	x21, [sp, #0x28]
    9d2c:      	str	x22, [sp, #0x30]
    9d30:      	str	x23, [sp, #0x38]
    9d34:      	str	x24, [sp, #0x40]
    9d38:      	str	x25, [sp, #0x48]
    9d3c:      	str	x26, [sp, #0x50]
    9d40:      	str	x27, [sp, #0x58]
    9d44:      	str	x28, [sp, #0x60]
    9d48:      	sxtw	x19, w0
    9d4c:      	sxtw	x20, w1
    9d50:      	sxtw	x21, w2
    9d54:      	cmp	x19, #0x24
    9d58:      	b.ne	0x9d94 <_stogir.conversion.policy+0x84>
    9d5c:      	cmp	x20, #0xf
    9d60:      	b.le	0x9f7c <_stogir.conversion.policy+0x26c>
    9d64:      	cmp	x20, #0x80
    9d68:      	b.ge	0x9f7c <_stogir.conversion.policy+0x26c>
    9d6c:      	and	w0, w1, #0xf
    9d70:      	ubfx	x0, x0, #0, #32
    9d74:      	cmp	x0, #0x1
    9d78:      	b.lt	0x9f7c <_stogir.conversion.policy+0x26c>
    9d7c:      	cmp	x0, #0xd
    9d80:      	b.gt	0x9f7c <_stogir.conversion.policy+0x26c>
    9d84:      	mov	x22, #0x1               ; =1
    9d88:      	b	0x9d90 <_stogir.conversion.policy+0x80>
    9d8c:      	movz	x22, #0x0, lsl #48
    9d90:      	b	0x9d98 <_stogir.conversion.policy+0x88>
    9d94:      	movz	x22, #0x0, lsl #48
    9d98:      	sxtw	x0, w3
    9d9c:      	cmp	x20, #0xd
    9da0:      	cset	w23, eq
    9da4:      	cmp	x20, #0xc
    9da8:      	cset	w24, eq
    9dac:      	cmp	x0, #0x4
    9db0:      	cset	w25, eq
    9db4:      	cmp	x0, #0x8
    9db8:      	cset	w26, eq
    9dbc:      	cmp	x22, #0x0
    9dc0:      	b.eq	0xa240 <_stogir.conversion.policy+0x530>
    9dc4:      	orr	w0, w3, wzr
    9dc8:      	str	x8, [sp, #0x10]
    9dcc:      	mov	w28, w2
    9dd0:      	mov	w27, w3
    9dd4:      	fmov	s31, w0
    9dd8:      	mov	w0, w1
    9ddc:      	fmov	w1, s31
    9de0:      	bl	0x9de0 <_stogir.conversion.policy+0xd0>
		0000000000009de0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    9de4:      	b	0x9dec <_stogir.conversion.policy+0xdc>
    9de8:      	mov	w0, #0x1                ; =1
    9dec:      	cmp	x21, #0xd
    9df0:      	cset	w1, eq
    9df4:      	cmp	x21, #0xc
    9df8:      	cset	w2, eq
    9dfc:      	cmp	x22, #0x0
    9e00:      	b.eq	0xa250 <_stogir.conversion.policy+0x540>
    9e04:      	mov	w22, w0
    9e08:      	mov	w0, w28
    9e0c:      	mov	w28, w1
    9e10:      	mov	w1, w27
    9e14:      	mov	w25, w2
    9e18:      	bl	0x9e18 <_stogir.conversion.policy+0x108>
		0000000000009e18:  ARM64_RELOC_BRANCH26	_stogir.types.size
    9e1c:      	orr	w27, w0, wzr
    9e20:      	mov	w0, w25
    9e24:      	b	0x9e2c <_stogir.conversion.policy+0x11c>
    9e28:      	mov	w27, #0x1               ; =1
    9e2c:      	cmp	x19, #0x21
    9e30:      	b.lt	0x9f04 <_stogir.conversion.policy+0x1f4>
    9e34:      	cmp	x19, #0x27
    9e38:      	b.gt	0x9f04 <_stogir.conversion.policy+0x1f4>
    9e3c:      	lsl	w1, w22, #3
    9e40:      	sxtw	x1, w1
    9e44:      	cmp	x1, #0x0
    9e48:      	b.le	0x9f04 <_stogir.conversion.policy+0x1f4>
    9e4c:      	lsl	w2, w27, #3
    9e50:      	sxtw	x2, w2
    9e54:      	cmp	x2, #0x0
    9e58:      	b.le	0x9f04 <_stogir.conversion.policy+0x1f4>
    9e5c:      	cmp	x19, #0x26
    9e60:      	cset	w3, eq
    9e64:      	cmp	x20, #0x1
    9e68:      	cset	w4, ge
    9e6c:      	cmp	x20, #0xb
    9e70:      	cset	w5, le
    9e74:      	cmp	x21, #0x1
    9e78:      	cset	w6, ge
    9e7c:      	cmp	x21, #0xb
    9e80:      	cset	w7, le
    9e84:      	cmp	x19, #0x25
    9e88:      	b.lt	0xa0fc <_stogir.conversion.policy+0x3ec>
    9e8c:      	ubfx	x8, x28, #0, #8
    9e90:      	cmp	x19, #0x25
    9e94:      	b.ne	0xa16c <_stogir.conversion.policy+0x45c>
    9e98:      	uxtb	w16, w4
    9e9c:      	cmp	w16, wzr
    9ea0:      	b.eq	0xa164 <_stogir.conversion.policy+0x454>
    9ea4:      	uxtb	w16, w5
    9ea8:      	cmp	w16, wzr
    9eac:      	b.eq	0xa164 <_stogir.conversion.policy+0x454>
    9eb0:      	uxtb	w16, w0
    9eb4:      	cmp	w16, wzr
    9eb8:      	b.eq	0x9ec0 <_stogir.conversion.policy+0x1b0>
    9ebc:      	mov	x8, #0x1                ; =1
    9ec0:      	b	0xa168 <_stogir.conversion.policy+0x458>
    9ec4:      	uxtb	w16, w25
    9ec8:      	cmp	w16, wzr
    9ecc:      	b.ne	0x9f5c <_stogir.conversion.policy+0x24c>
    9ed0:      	uxtb	w16, w26
    9ed4:      	cmp	w16, wzr
    9ed8:      	b.ne	0x9f5c <_stogir.conversion.policy+0x24c>
    9edc:      	movn	w27, #0x0, lsl #16
    9ee0:      	b	0x9e2c <_stogir.conversion.policy+0x11c>
    9ee4:      	uxtb	w16, w25
    9ee8:      	cmp	w16, wzr
    9eec:      	b.ne	0x9f6c <_stogir.conversion.policy+0x25c>
    9ef0:      	uxtb	w16, w26
    9ef4:      	cmp	w16, wzr
    9ef8:      	b.ne	0x9f6c <_stogir.conversion.policy+0x25c>
    9efc:      	movn	w0, #0x0, lsl #16
    9f00:      	b	0x9dec <_stogir.conversion.policy+0xdc>
    9f04:      	mov	x1, #0x1                ; =1
    9f08:      	adrp	x0, 0x9000 <_stogir.stack.validate-scope-inputs+0x280>
		0000000000009f08:  ARM64_RELOC_PAGE21	l_stogir.460
    9f0c:      	ldr	x0, [x0]
		0000000000009f0c:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    9f10:      	mov	x2, #0x22               ; =34
    9f14:      	ldr	x3, [sp, #0x10]
    9f18:      	str	x1, [x3]
    9f1c:      	str	x0, [x3, #0x8]
    9f20:      	str	x2, [x3, #0x10]
    9f24:      	ldr	x19, [sp, #0x18]
    9f28:      	ldr	x20, [sp, #0x20]
    9f2c:      	ldr	x21, [sp, #0x28]
    9f30:      	ldr	x22, [sp, #0x30]
    9f34:      	ldr	x23, [sp, #0x38]
    9f38:      	ldr	x24, [sp, #0x40]
    9f3c:      	ldr	x25, [sp, #0x48]
    9f40:      	ldr	x26, [sp, #0x50]
    9f44:      	ldr	x27, [sp, #0x58]
    9f48:      	ldr	x28, [sp, #0x60]
    9f4c:      	ldr	x29, [sp]
    9f50:      	ldr	x30, [sp, #0x8]
    9f54:      	add	sp, sp, #0x70
    9f58:      	ret
    9f5c:      	cmp	x21, #0x0
    9f60:      	b.ne	0x9fb4 <_stogir.conversion.policy+0x2a4>
    9f64:      	movz	w27, #0x0, lsl #16
    9f68:      	b	0x9e2c <_stogir.conversion.policy+0x11c>
    9f6c:      	cmp	x20, #0x0
    9f70:      	b.ne	0xa02c <_stogir.conversion.policy+0x31c>
    9f74:      	movz	w0, #0x0, lsl #16
    9f78:      	b	0x9dec <_stogir.conversion.policy+0xdc>
    9f7c:      	cmp	x21, #0xf
    9f80:      	b.le	0x9d8c <_stogir.conversion.policy+0x7c>
    9f84:      	cmp	x21, #0x80
    9f88:      	b.ge	0x9fac <_stogir.conversion.policy+0x29c>
    9f8c:      	and	w0, w2, #0xf
    9f90:      	ubfx	x0, x0, #0, #32
    9f94:      	cmp	x0, #0x1
    9f98:      	b.lt	0xa0a4 <_stogir.conversion.policy+0x394>
    9f9c:      	cmp	x0, #0xd
    9fa0:      	cset	w0, le
    9fa4:      	ubfx	x22, x0, #0, #8
    9fa8:      	b	0xa0a8 <_stogir.conversion.policy+0x398>
    9fac:      	movz	x22, #0x0, lsl #48
    9fb0:      	b	0x9d90 <_stogir.conversion.policy+0x80>
    9fb4:      	cmp	x21, #0x1
    9fb8:      	b.eq	0x9e28 <_stogir.conversion.policy+0x118>
    9fbc:      	cmp	x21, #0x2
    9fc0:      	b.eq	0x9e28 <_stogir.conversion.policy+0x118>
    9fc4:      	cmp	x21, #0x7
    9fc8:      	b.eq	0x9e28 <_stogir.conversion.policy+0x118>
    9fcc:      	cmp	x21, #0x8
    9fd0:      	b.eq	0x9e28 <_stogir.conversion.policy+0x118>
    9fd4:      	cmp	x21, #0x3
    9fd8:      	b.eq	0xa198 <_stogir.conversion.policy+0x488>
    9fdc:      	cmp	x21, #0x9
    9fe0:      	b.eq	0xa198 <_stogir.conversion.policy+0x488>
    9fe4:      	cmp	x21, #0x4
    9fe8:      	b.eq	0xa208 <_stogir.conversion.policy+0x4f8>
    9fec:      	cmp	x21, #0xa
    9ff0:      	b.eq	0xa208 <_stogir.conversion.policy+0x4f8>
    9ff4:      	uxtb	w16, w28
    9ff8:      	cmp	w16, wzr
    9ffc:      	b.ne	0xa208 <_stogir.conversion.policy+0x4f8>
    a000:      	cmp	x21, #0x5
    a004:      	b.eq	0xa228 <_stogir.conversion.policy+0x518>
    a008:      	cmp	x21, #0xb
    a00c:      	b.eq	0xa228 <_stogir.conversion.policy+0x518>
    a010:      	uxtb	w16, w0
    a014:      	cmp	w16, wzr
    a018:      	b.ne	0xa228 <_stogir.conversion.policy+0x518>
    a01c:      	cmp	x21, #0x6
    a020:      	b.eq	0xa028 <_stogir.conversion.policy+0x318>
    a024:      	movn	w27, #0x0, lsl #16
    a028:      	b	0xa22c <_stogir.conversion.policy+0x51c>
    a02c:      	cmp	x20, #0x1
    a030:      	b.eq	0x9de8 <_stogir.conversion.policy+0xd8>
    a034:      	cmp	x20, #0x2
    a038:      	b.eq	0x9de8 <_stogir.conversion.policy+0xd8>
    a03c:      	cmp	x20, #0x7
    a040:      	b.eq	0x9de8 <_stogir.conversion.policy+0xd8>
    a044:      	cmp	x20, #0x8
    a048:      	b.eq	0x9de8 <_stogir.conversion.policy+0xd8>
    a04c:      	cmp	x20, #0x3
    a050:      	b.eq	0xa1a0 <_stogir.conversion.policy+0x490>
    a054:      	cmp	x20, #0x9
    a058:      	b.eq	0xa1a0 <_stogir.conversion.policy+0x490>
    a05c:      	cmp	x20, #0x4
    a060:      	b.eq	0xa210 <_stogir.conversion.policy+0x500>
    a064:      	cmp	x20, #0xa
    a068:      	b.eq	0xa210 <_stogir.conversion.policy+0x500>
    a06c:      	uxtb	w16, w23
    a070:      	cmp	w16, wzr
    a074:      	b.ne	0xa210 <_stogir.conversion.policy+0x500>
    a078:      	cmp	x20, #0x5
    a07c:      	b.eq	0xa230 <_stogir.conversion.policy+0x520>
    a080:      	cmp	x20, #0xb
    a084:      	b.eq	0xa230 <_stogir.conversion.policy+0x520>
    a088:      	uxtb	w16, w24
    a08c:      	cmp	w16, wzr
    a090:      	b.ne	0xa230 <_stogir.conversion.policy+0x520>
    a094:      	cmp	x20, #0x6
    a098:      	b.ne	0xa238 <_stogir.conversion.policy+0x528>
    a09c:      	mov	w0, w27
    a0a0:      	b	0xa23c <_stogir.conversion.policy+0x52c>
    a0a4:      	movz	x22, #0x0, lsl #48
    a0a8:      	b	0x9fb0 <_stogir.conversion.policy+0x2a0>
    a0ac:      	mov	x0, #0x1                ; =1
    a0b0:      	cmp	x0, #0x0
    a0b4:      	b.ne	0x9f04 <_stogir.conversion.policy+0x1f4>
    a0b8:      	cmp	x19, #0x23
    a0bc:      	b.eq	0xa0cc <_stogir.conversion.policy+0x3bc>
    a0c0:      	uxtb	w16, w3
    a0c4:      	cmp	w16, wzr
    a0c8:      	b.eq	0xa0d0 <_stogir.conversion.policy+0x3c0>
    a0cc:      	mov	x1, x2
    a0d0:      	and	x0, x1, #0xffffffff
    a0d4:      	movz	x1, #0x0, lsl #48
    a0d8:      	movz	x2, #0x0, lsl #48
    a0dc:      	b	0x9f14 <_stogir.conversion.policy+0x204>
    a0e0:      	movz	x8, #0x0, lsl #48
    a0e4:      	cmp	x8, #0x0
    a0e8:      	cset	w0, ne
    a0ec:      	uxtb	w16, w0
    a0f0:      	cmp	w16, wzr
    a0f4:      	cset	x0, eq
    a0f8:      	b	0xa0b0 <_stogir.conversion.policy+0x3a0>
    a0fc:      	cmp	x19, #0x24
    a100:      	b.ne	0xa11c <_stogir.conversion.policy+0x40c>
    a104:      	cmp	x1, x2
    a108:      	cset	w0, eq
    a10c:      	uxtb	w16, w0
    a110:      	cmp	w16, wzr
    a114:      	cset	x0, eq
    a118:      	b	0xa0b0 <_stogir.conversion.policy+0x3a0>
    a11c:      	uxtb	w16, w4
    a120:      	cmp	w16, wzr
    a124:      	b.eq	0xa0ac <_stogir.conversion.policy+0x39c>
    a128:      	uxtb	w16, w5
    a12c:      	cmp	w16, wzr
    a130:      	b.eq	0xa0ac <_stogir.conversion.policy+0x39c>
    a134:      	uxtb	w16, w6
    a138:      	cmp	w16, wzr
    a13c:      	b.eq	0xa1d8 <_stogir.conversion.policy+0x4c8>
    a140:      	uxtb	w16, w7
    a144:      	cmp	w16, wzr
    a148:      	b.eq	0xa1d8 <_stogir.conversion.policy+0x4c8>
    a14c:      	cmp	x19, #0x23
    a150:      	b.ne	0xa218 <_stogir.conversion.policy+0x508>
    a154:      	cmp	x2, x1
    a158:      	cset	w0, ge
    a15c:      	ubfx	x0, x0, #0, #8
    a160:      	b	0xa224 <_stogir.conversion.policy+0x514>
    a164:      	movz	x8, #0x0, lsl #48
    a168:      	b	0xa0e4 <_stogir.conversion.policy+0x3d4>
    a16c:      	uxtb	w16, w3
    a170:      	cmp	w16, wzr
    a174:      	b.eq	0xa1b0 <_stogir.conversion.policy+0x4a0>
    a178:      	uxtb	w16, w24
    a17c:      	cmp	w16, wzr
    a180:      	b.ne	0xa1f4 <_stogir.conversion.policy+0x4e4>
    a184:      	uxtb	w16, w23
    a188:      	cmp	w16, wzr
    a18c:      	b.ne	0xa1f4 <_stogir.conversion.policy+0x4e4>
    a190:      	movz	x8, #0x0, lsl #48
    a194:      	b	0xa1ac <_stogir.conversion.policy+0x49c>
    a198:      	mov	w27, #0x2               ; =2
    a19c:      	b	0x9e2c <_stogir.conversion.policy+0x11c>
    a1a0:      	mov	w0, #0x2                ; =2
    a1a4:      	b	0x9dec <_stogir.conversion.policy+0xdc>
    a1a8:      	movz	x8, #0x0, lsl #48
    a1ac:      	b	0xa0e4 <_stogir.conversion.policy+0x3d4>
    a1b0:      	cmp	x19, #0x27
    a1b4:      	b.ne	0xa0e0 <_stogir.conversion.policy+0x3d0>
    a1b8:      	uxtb	w16, w24
    a1bc:      	cmp	w16, wzr
    a1c0:      	b.ne	0xa1e0 <_stogir.conversion.policy+0x4d0>
    a1c4:      	uxtb	w16, w23
    a1c8:      	cmp	w16, wzr
    a1cc:      	b.ne	0xa1e0 <_stogir.conversion.policy+0x4d0>
    a1d0:      	movz	x8, #0x0, lsl #48
    a1d4:      	b	0xa1f0 <_stogir.conversion.policy+0x4e0>
    a1d8:      	mov	x0, #0x1                ; =1
    a1dc:      	b	0xa0b0 <_stogir.conversion.policy+0x3a0>
    a1e0:      	uxtb	w16, w0
    a1e4:      	cmp	w16, wzr
    a1e8:      	b.eq	0xa1f0 <_stogir.conversion.policy+0x4e0>
    a1ec:      	mov	x8, #0x1                ; =1
    a1f0:      	b	0xa0e4 <_stogir.conversion.policy+0x3d4>
    a1f4:      	uxtb	w16, w6
    a1f8:      	cmp	w16, wzr
    a1fc:      	b.eq	0xa1a8 <_stogir.conversion.policy+0x498>
    a200:      	ubfx	x8, x7, #0, #8
    a204:      	b	0xa1ac <_stogir.conversion.policy+0x49c>
    a208:      	mov	w27, #0x4               ; =4
    a20c:      	b	0xa19c <_stogir.conversion.policy+0x48c>
    a210:      	mov	w0, #0x4                ; =4
    a214:      	b	0xa1a4 <_stogir.conversion.policy+0x494>
    a218:      	cmp	x2, x1
    a21c:      	cset	w0, le
    a220:      	ubfx	x0, x0, #0, #8
    a224:      	b	0xa1dc <_stogir.conversion.policy+0x4cc>
    a228:      	mov	w27, #0x8               ; =8
    a22c:      	b	0xa20c <_stogir.conversion.policy+0x4fc>
    a230:      	mov	w0, #0x8                ; =8
    a234:      	b	0xa214 <_stogir.conversion.policy+0x504>
    a238:      	movn	w0, #0x0, lsl #16
    a23c:      	b	0xa234 <_stogir.conversion.policy+0x524>
    a240:      	str	x8, [sp, #0x10]
    a244:      	mov	w28, w2
    a248:      	mov	w27, w3
    a24c:      	b	0x9ee4 <_stogir.conversion.policy+0x1d4>
    a250:      	mov	w22, w0
    a254:      	mov	w28, w1
    a258:      	mov	w0, w2
    a25c:      	b	0x9ec4 <_stogir.conversion.policy+0x1b4>

000000000000a260 <_stogir.conditional.operands>:
    a260:      	sub	sp, sp, #0x20
    a264:      	sxtw	x5, w1
    a268:      	cmp	x5, #0x0
    a26c:      	b.eq	0xa2b8 <_stogir.conditional.operands+0x58>
    a270:      	cmp	x5, #0x0
    a274:      	b.lt	0xa290 <_stogir.conditional.operands+0x30>
    a278:      	cmp	x5, #0xd
    a27c:      	b.gt	0xa290 <_stogir.conditional.operands+0x30>
    a280:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a280:  ARM64_RELOC_PAGE21	l_stogir.461
    a284:      	ldr	x1, [x1]
		000000000000a284:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    a288:      	movz	x6, #0x0, lsl #48
    a28c:      	b	0xa2c4 <_stogir.conditional.operands+0x64>
    a290:      	cmp	x5, #0xf
    a294:      	b.le	0xa2b8 <_stogir.conditional.operands+0x58>
    a298:      	cmp	x5, #0x80
    a29c:      	b.ge	0xa2b8 <_stogir.conditional.operands+0x58>
    a2a0:      	and	w1, w1, #0xf
    a2a4:      	ubfx	x1, x1, #0, #32
    a2a8:      	cmp	x1, #0x1
    a2ac:      	b.lt	0xa2b8 <_stogir.conditional.operands+0x58>
    a2b0:      	cmp	x1, #0xd
    a2b4:      	b.le	0xa280 <_stogir.conditional.operands+0x20>
    a2b8:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a2b8:  ARM64_RELOC_PAGE21	l_stogir.462
    a2bc:      	ldr	x1, [x1]
		000000000000a2bc:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    a2c0:      	mov	x6, #0x2b               ; =43
    a2c4:      	sxtw	x2, w2
    a2c8:      	add	x7, x0, #0x28
    a2cc:      	add	x9, x0, #0x78
    a2d0:      	add	x10, x0, #0x50
    a2d4:      	cmp	x2, #0x0
    a2d8:      	cset	w11, gt
    a2dc:      	movz	x16, #0x0, lsl #48
    a2e0:      	sub	x12, x16, x2
    a2e4:      	sub	x13, x12, #0x1
    a2e8:      	uxtb	w16, w11
    a2ec:      	cmp	w16, wzr
    a2f0:      	b.eq	0xa32c <_stogir.conditional.operands+0xcc>
    a2f4:      	ldr	x12, [x0, #0x8]
    a2f8:      	cmp	x2, x12
    a2fc:      	b.ge	0xa37c <_stogir.conditional.operands+0x11c>
    a300:      	ldr	x12, [x9, #0x8]
    a304:      	cmp	x2, x12
    a308:      	b.ge	0xa670 <_stogir.conditional.operands+0x410>
    a30c:      	ldr	x12, [x0, #0x78]
    a310:      	add	x12, x12, x2, lsl #2
    a314:      	ldr	w12, [x12]
    a318:      	sxtw	x12, w12
    a31c:      	cmp	x12, #0x0
    a320:      	cset	w12, ge
    a324:      	ubfx	x12, x12, #0, #8
    a328:      	b	0xa674 <_stogir.conditional.operands+0x414>
    a32c:      	cmp	x2, #0x0
    a330:      	b.ge	0xa384 <_stogir.conditional.operands+0x124>
    a334:      	ldr	x14, [x7, #0x8]
    a338:      	ldr	x15, [x10, #0x8]
    a33c:      	cmp	x14, x15
    a340:      	b.ne	0xa36c <_stogir.conditional.operands+0x10c>
    a344:      	cmp	x12, x14
    a348:      	b.gt	0xa678 <_stogir.conditional.operands+0x418>
    a34c:      	ldr	x12, [x0, #0x50]
    a350:      	add	x12, x12, x13, lsl #2
    a354:      	ldr	w12, [x12]
    a358:      	sxtw	x12, w12
    a35c:      	cmp	x12, #0x0
    a360:      	cset	w12, gt
    a364:      	ubfx	x12, x12, #0, #8
    a368:      	b	0xa67c <_stogir.conditional.operands+0x41c>
    a36c:      	movz	x12, #0x0, lsl #48
    a370:      	b	0xa388 <_stogir.conditional.operands+0x128>
    a374:      	movz	x12, #0x0, lsl #48
    a378:      	b	0xa414 <_stogir.conditional.operands+0x1b4>
    a37c:      	movz	x12, #0x0, lsl #48
    a380:      	b	0xa388 <_stogir.conditional.operands+0x128>
    a384:      	movz	x12, #0x0, lsl #48
    a388:      	cmp	x12, #0x0
    a38c:      	b.eq	0xa3c0 <_stogir.conditional.operands+0x160>
    a390:      	uxtb	w16, w11
    a394:      	cmp	w16, wzr
    a398:      	b.eq	0xa3ac <_stogir.conditional.operands+0x14c>
    a39c:      	ldr	x11, [x0]
    a3a0:      	add	x2, x11, x2, lsl #4
    a3a4:      	ldr	x2, [x2]
    a3a8:      	b	0xa3b8 <_stogir.conditional.operands+0x158>
    a3ac:      	ldr	x2, [x0, #0x28]
    a3b0:      	add	x2, x2, x13, lsl #4
    a3b4:      	ldr	x2, [x2]
    a3b8:      	mov	w11, #0x1               ; =1
    a3bc:      	b	0xa3c8 <_stogir.conditional.operands+0x168>
    a3c0:      	movz	w11, #0x0, lsl #16
    a3c4:      	movz	x2, #0x0, lsl #48
    a3c8:      	ubfx	x11, x11, #0, #32
    a3cc:      	lsr	x16, x11, #0
    a3d0:      	cmp	x16, #0x1
    a3d4:      	b.eq	0xa3f0 <_stogir.conditional.operands+0x190>
    a3d8:      	b.lo	0xa3e0 <_stogir.conditional.operands+0x180>
    a3dc:      	b	0xa3f4 <_stogir.conditional.operands+0x194>
    a3e0:      	cmp	x16, #0x0
    a3e4:      	b.eq	0xa3ec <_stogir.conditional.operands+0x18c>
    a3e8:      	b	0xa3f4 <_stogir.conditional.operands+0x194>
    a3ec:      	b	0xa3f8 <_stogir.conditional.operands+0x198>
    a3f0:      	b	0xa418 <_stogir.conditional.operands+0x1b8>
    a3f4:      	b	0xa690 <_stogir.conditional.operands+0x430>
    a3f8:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a3f8:  ARM64_RELOC_PAGE21	l_stogir.463
    a3fc:      	ldr	x1, [x1]
		000000000000a3fc:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    a400:      	mov	x6, #0x16               ; =22
    a404:      	b	0xa458 <_stogir.conditional.operands+0x1f8>
    a408:      	movz	x12, #0x0, lsl #48
    a40c:      	b	0xa48c <_stogir.conditional.operands+0x22c>
    a410:      	movz	x12, #0x0, lsl #48
    a414:      	b	0xa494 <_stogir.conditional.operands+0x234>
    a418:      	uxtb	w11, w2
    a41c:      	cmp	x11, #0x48
    a420:      	b.eq	0xa44c <_stogir.conditional.operands+0x1ec>
    a424:      	cmp	x11, #0x46
    a428:      	b.eq	0xa44c <_stogir.conditional.operands+0x1ec>
    a42c:      	ubfx	x11, x2, #0, #32
    a430:      	ubfx	x11, x11, #8, #8
    a434:      	cmp	x11, #0x0
    a438:      	b.eq	0xa44c <_stogir.conditional.operands+0x1ec>
    a43c:      	ubfx	x2, x2, #0, #32
    a440:      	ubfx	x2, x2, #8, #8
    a444:      	cmp	x2, #0xd
    a448:      	b.le	0xa458 <_stogir.conditional.operands+0x1f8>
    a44c:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a44c:  ARM64_RELOC_PAGE21	l_stogir.464
    a450:      	ldr	x1, [x1]
		000000000000a450:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    a454:      	mov	x6, #0x2a               ; =42
    a458:      	add	x16, sp, #0x10
    a45c:      	orr	x2, x16, xzr
    a460:      	mov	x16, sp
    a464:      	str	w3, [x16]
    a468:      	mov	x16, sp
    a46c:      	str	w4, [x16, #0x4]
    a470:      	mov	x16, sp
    a474:      	ldr	x3, [x16]
    a478:      	add	x16, sp, #0x10
    a47c:      	str	x3, [x16]
    a480:      	movz	x3, #0x0, lsl #48
    a484:      	b	0xa544 <_stogir.conditional.operands+0x2e4>
    a488:      	movz	x12, #0x0, lsl #48
    a48c:      	b	0xa494 <_stogir.conditional.operands+0x234>
    a490:      	movz	x12, #0x0, lsl #48
    a494:      	cmp	x12, #0x0
    a498:      	b.eq	0xa4cc <_stogir.conditional.operands+0x26c>
    a49c:      	uxtb	w16, w4
    a4a0:      	cmp	w16, wzr
    a4a4:      	b.eq	0xa4b8 <_stogir.conditional.operands+0x258>
    a4a8:      	ldr	x4, [x0]
    a4ac:      	add	x4, x4, x11, lsl #4
    a4b0:      	ldr	x4, [x4]
    a4b4:      	b	0xa4c4 <_stogir.conditional.operands+0x264>
    a4b8:      	ldr	x4, [x0, #0x28]
    a4bc:      	add	x4, x4, x13, lsl #4
    a4c0:      	ldr	x4, [x4]
    a4c4:      	mov	w11, #0x1               ; =1
    a4c8:      	b	0xa4d4 <_stogir.conditional.operands+0x274>
    a4cc:      	movz	w11, #0x0, lsl #16
    a4d0:      	movz	x4, #0x0, lsl #48
    a4d4:      	ubfx	x11, x11, #0, #32
    a4d8:      	lsr	x16, x11, #0
    a4dc:      	cmp	x16, #0x1
    a4e0:      	b.eq	0xa4fc <_stogir.conditional.operands+0x29c>
    a4e4:      	b.lo	0xa4ec <_stogir.conditional.operands+0x28c>
    a4e8:      	b	0xa500 <_stogir.conditional.operands+0x2a0>
    a4ec:      	cmp	x16, #0x0
    a4f0:      	b.eq	0xa4f8 <_stogir.conditional.operands+0x298>
    a4f4:      	b	0xa500 <_stogir.conditional.operands+0x2a0>
    a4f8:      	b	0xa504 <_stogir.conditional.operands+0x2a4>
    a4fc:      	b	0xa514 <_stogir.conditional.operands+0x2b4>
    a500:      	b	0xa688 <_stogir.conditional.operands+0x428>
    a504:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a504:  ARM64_RELOC_PAGE21	l_stogir.465
    a508:      	ldr	x1, [x1]
		000000000000a508:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    a50c:      	mov	x6, #0x10               ; =16
    a510:      	b	0xa544 <_stogir.conditional.operands+0x2e4>
    a514:      	uxtb	w11, w4
    a518:      	cmp	x11, #0x48
    a51c:      	b.eq	0xa538 <_stogir.conditional.operands+0x2d8>
    a520:      	cmp	x11, #0x46
    a524:      	b.eq	0xa538 <_stogir.conditional.operands+0x2d8>
    a528:      	ubfx	x4, x4, #0, #32
    a52c:      	ubfx	x4, x4, #8, #8
    a530:      	cmp	x4, x5
    a534:      	b.eq	0xa544 <_stogir.conditional.operands+0x2e4>
    a538:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a538:  ARM64_RELOC_PAGE21	l_stogir.466
    a53c:      	ldr	x1, [x1]
		000000000000a53c:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    a540:      	mov	x6, #0x21               ; =33
    a544:      	cmp	x3, #0x2
    a548:      	b.ge	0xa56c <_stogir.conditional.operands+0x30c>
    a54c:      	add	x4, x3, #0x1
    a550:      	add	x3, x2, x3, lsl #2
    a554:      	ldr	w3, [x3]
    a558:      	movn	w17, #0x0, lsl #16
    a55c:      	and	w11, w3, w17
    a560:      	mov	x3, x4
    a564:      	mov	w4, #0x1                ; =1
    a568:      	b	0xa574 <_stogir.conditional.operands+0x314>
    a56c:      	movz	w4, #0x0, lsl #16
    a570:      	movz	w11, #0x0, lsl #16
    a574:      	ubfx	x4, x4, #0, #32
    a578:      	lsr	x16, x4, #0
    a57c:      	cmp	x16, #0x1
    a580:      	b.eq	0xa59c <_stogir.conditional.operands+0x33c>
    a584:      	b.lo	0xa58c <_stogir.conditional.operands+0x32c>
    a588:      	b	0xa5a0 <_stogir.conditional.operands+0x340>
    a58c:      	cmp	x16, #0x0
    a590:      	b.eq	0xa598 <_stogir.conditional.operands+0x338>
    a594:      	b	0xa5a0 <_stogir.conditional.operands+0x340>
    a598:      	b	0xa600 <_stogir.conditional.operands+0x3a0>
    a59c:      	b	0xa5a4 <_stogir.conditional.operands+0x344>
    a5a0:      	b	0xa680 <_stogir.conditional.operands+0x420>
    a5a4:      	sxtw	x11, w11
    a5a8:      	cmp	x11, #0x0
    a5ac:      	cset	w4, gt
    a5b0:      	movz	x16, #0x0, lsl #48
    a5b4:      	sub	x12, x16, x11
    a5b8:      	sub	x13, x12, #0x1
    a5bc:      	uxtb	w16, w4
    a5c0:      	cmp	w16, wzr
    a5c4:      	b.eq	0xa630 <_stogir.conditional.operands+0x3d0>
    a5c8:      	ldr	x12, [x0, #0x8]
    a5cc:      	cmp	x11, x12
    a5d0:      	b.ge	0xa488 <_stogir.conditional.operands+0x228>
    a5d4:      	ldr	x12, [x9, #0x8]
    a5d8:      	cmp	x11, x12
    a5dc:      	b.ge	0xa408 <_stogir.conditional.operands+0x1a8>
    a5e0:      	ldr	x12, [x0, #0x78]
    a5e4:      	add	x12, x12, x11, lsl #2
    a5e8:      	ldr	w12, [x12]
    a5ec:      	sxtw	x12, w12
    a5f0:      	cmp	x12, #0x0
    a5f4:      	cset	w12, ge
    a5f8:      	ubfx	x12, x12, #0, #8
    a5fc:      	b	0xa40c <_stogir.conditional.operands+0x1ac>
    a600:      	cmp	x6, #0x0
    a604:      	b.ne	0xa618 <_stogir.conditional.operands+0x3b8>
    a608:      	and	x1, x5, #0xffffffff
    a60c:      	movz	x0, #0x0, lsl #48
    a610:      	movz	x6, #0x0, lsl #48
    a614:      	b	0xa61c <_stogir.conditional.operands+0x3bc>
    a618:      	mov	x0, #0x1                ; =1
    a61c:      	str	x0, [x8]
    a620:      	str	x1, [x8, #0x8]
    a624:      	str	x6, [x8, #0x10]
    a628:      	add	sp, sp, #0x20
    a62c:      	ret
    a630:      	cmp	x11, #0x0
    a634:      	b.ge	0xa490 <_stogir.conditional.operands+0x230>
    a638:      	ldr	x14, [x7, #0x8]
    a63c:      	ldr	x15, [x10, #0x8]
    a640:      	cmp	x14, x15
    a644:      	b.ne	0xa410 <_stogir.conditional.operands+0x1b0>
    a648:      	cmp	x12, x14
    a64c:      	b.gt	0xa374 <_stogir.conditional.operands+0x114>
    a650:      	ldr	x12, [x0, #0x50]
    a654:      	add	x12, x12, x13, lsl #2
    a658:      	ldr	w12, [x12]
    a65c:      	sxtw	x12, w12
    a660:      	cmp	x12, #0x0
    a664:      	cset	w12, gt
    a668:      	ubfx	x12, x12, #0, #8
    a66c:      	b	0xa378 <_stogir.conditional.operands+0x118>
    a670:      	movz	x12, #0x0, lsl #48
    a674:      	b	0xa380 <_stogir.conditional.operands+0x120>
    a678:      	movz	x12, #0x0, lsl #48
    a67c:      	b	0xa370 <_stogir.conditional.operands+0x110>
    a680:      	brk	#0
    a684:      	b	0xa680 <_stogir.conditional.operands+0x420>
    a688:      	brk	#0
    a68c:      	b	0xa688 <_stogir.conditional.operands+0x428>
    a690:      	brk	#0
    a694:      	b	0xa690 <_stogir.conditional.operands+0x430>

000000000000a698 <_stogir.floating.operands>:
    a698:      	sub	sp, sp, #0x90
    a69c:      	str	x29, [sp]
    a6a0:      	str	x30, [sp, #0x8]
    a6a4:      	mov	x29, sp
    a6a8:      	str	x19, [sp, #0x60]
    a6ac:      	str	x20, [sp, #0x68]
    a6b0:      	str	x21, [sp, #0x70]
    a6b4:      	str	x22, [sp, #0x78]
    a6b8:      	str	x23, [sp, #0x80]
    a6bc:      	sxtw	x1, w1
    a6c0:      	sxtw	x19, w2
    a6c4:      	cmp	x1, #0x1f
    a6c8:      	cset	w2, eq
    a6cc:      	cmp	x1, #0x20
    a6d0:      	cset	w6, eq
    a6d4:      	cmp	x1, #0xe
    a6d8:      	b.lt	0xa704 <_stogir.floating.operands+0x6c>
    a6dc:      	cmp	x1, #0x19
    a6e0:      	b.gt	0xa704 <_stogir.floating.operands+0x6c>
    a6e4:      	cmp	x19, #0xc
    a6e8:      	b.eq	0xa7a0 <_stogir.floating.operands+0x108>
    a6ec:      	cmp	x19, #0xd
    a6f0:      	b.eq	0xa7a0 <_stogir.floating.operands+0x108>
    a6f4:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a6f4:  ARM64_RELOC_PAGE21	l_stogir.467
    a6f8:      	ldr	x20, [x20]
		000000000000a6f8:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    a6fc:      	mov	x21, #0x22              ; =34
    a700:      	b	0xa7ac <_stogir.floating.operands+0x114>
    a704:      	uxtb	w16, w2
    a708:      	cmp	w16, wzr
    a70c:      	b.ne	0xa6e4 <_stogir.floating.operands+0x4c>
    a710:      	uxtb	w16, w6
    a714:      	cmp	w16, wzr
    a718:      	b.ne	0xa6e4 <_stogir.floating.operands+0x4c>
    a71c:      	cmp	x1, #0x1a
    a720:      	b.lt	0xa72c <_stogir.floating.operands+0x94>
    a724:      	cmp	x1, #0x1d
    a728:      	b.le	0xa6e4 <_stogir.floating.operands+0x4c>
    a72c:      	cmp	x1, #0x3a
    a730:      	b.eq	0xa6e4 <_stogir.floating.operands+0x4c>
    a734:      	cmp	x1, #0x3b
    a738:      	b.eq	0xa6e4 <_stogir.floating.operands+0x4c>
    a73c:      	b	0xa6f4 <_stogir.floating.operands+0x5c>
    a740:      	movz	w1, #0x0, lsl #16
    a744:      	uxtb	w16, w1
    a748:      	and	w1, w16, #0x2
    a74c:      	uxtb	w1, w1
    a750:      	ubfx	x1, x1, #0, #8
    a754:      	cmp	x1, #0x0
    a758:      	cset	w1, eq
    a75c:      	uxtb	w16, w1
    a760:      	cmp	w16, wzr
    a764:      	cset	x1, eq
    a768:      	cmp	x1, #0x0
    a76c:      	b.ne	0xa78c <_stogir.floating.operands+0xf4>
    a770:      	cmp	x0, #0x65
    a774:      	b.eq	0xa78c <_stogir.floating.operands+0xf4>
    a778:      	cmp	x0, #0x66
    a77c:      	b.eq	0xa78c <_stogir.floating.operands+0xf4>
    a780:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a780:  ARM64_RELOC_PAGE21	l_stogir.468
    a784:      	ldr	x20, [x20]
		000000000000a784:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    a788:      	mov	x21, #0x2d              ; =45
    a78c:      	b	0xa89c <_stogir.floating.operands+0x204>
    a790:      	movz	x11, #0x0, lsl #48
    a794:      	b	0xa808 <_stogir.floating.operands+0x170>
    a798:      	movz	x11, #0x0, lsl #48
    a79c:      	b	0xa810 <_stogir.floating.operands+0x178>
    a7a0:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a7a0:  ARM64_RELOC_PAGE21	l_stogir.469
    a7a4:      	ldr	x20, [x20]
		000000000000a7a4:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    a7a8:      	movz	x21, #0x0, lsl #48
    a7ac:      	add	x16, sp, #0x10
    a7b0:      	str	w3, [x16]
    a7b4:      	uxtb	w16, w2
    a7b8:      	cmp	w16, wzr
    a7bc:      	b.ne	0xa7d0 <_stogir.floating.operands+0x138>
    a7c0:      	uxtb	w16, w6
    a7c4:      	cmp	w16, wzr
    a7c8:      	b.ne	0xa7d0 <_stogir.floating.operands+0x138>
    a7cc:      	orr	w3, w4, wzr
    a7d0:      	add	x16, sp, #0x20
    a7d4:      	orr	x2, x16, xzr
    a7d8:      	add	x4, x0, #0x28
    a7dc:      	add	x6, x0, #0x78
    a7e0:      	add	x7, x0, #0x50
    a7e4:      	add	x16, sp, #0x10
    a7e8:      	str	w3, [x16, #0x4]
    a7ec:      	add	x16, sp, #0x10
    a7f0:      	ldr	x3, [x16]
    a7f4:      	add	x16, sp, #0x20
    a7f8:      	str	x3, [x16]
    a7fc:      	movz	x3, #0x0, lsl #48
    a800:      	b	0xa8bc <_stogir.floating.operands+0x224>
    a804:      	movz	x11, #0x0, lsl #48
    a808:      	b	0xa810 <_stogir.floating.operands+0x178>
    a80c:      	movz	x11, #0x0, lsl #48
    a810:      	cmp	x11, #0x0
    a814:      	b.eq	0xa848 <_stogir.floating.operands+0x1b0>
    a818:      	uxtb	w16, w9
    a81c:      	cmp	w16, wzr
    a820:      	b.eq	0xa834 <_stogir.floating.operands+0x19c>
    a824:      	ldr	x9, [x0]
    a828:      	add	x9, x9, x10, lsl #4
    a82c:      	ldr	x9, [x9]
    a830:      	b	0xa840 <_stogir.floating.operands+0x1a8>
    a834:      	ldr	x9, [x0, #0x28]
    a838:      	add	x9, x9, x12, lsl #4
    a83c:      	ldr	x9, [x9]
    a840:      	mov	w10, #0x1               ; =1
    a844:      	b	0xa850 <_stogir.floating.operands+0x1b8>
    a848:      	movz	w10, #0x0, lsl #16
    a84c:      	movz	x9, #0x0, lsl #48
    a850:      	ubfx	x10, x10, #0, #32
    a854:      	lsr	x16, x10, #0
    a858:      	cmp	x16, #0x1
    a85c:      	b.eq	0xa878 <_stogir.floating.operands+0x1e0>
    a860:      	b.lo	0xa868 <_stogir.floating.operands+0x1d0>
    a864:      	b	0xa87c <_stogir.floating.operands+0x1e4>
    a868:      	cmp	x16, #0x0
    a86c:      	b.eq	0xa874 <_stogir.floating.operands+0x1dc>
    a870:      	b	0xa87c <_stogir.floating.operands+0x1e4>
    a874:      	b	0xa880 <_stogir.floating.operands+0x1e8>
    a878:      	b	0xa8a0 <_stogir.floating.operands+0x208>
    a87c:      	b	0xaab0 <_stogir.floating.operands+0x418>
    a880:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a880:  ARM64_RELOC_PAGE21	l_stogir.470
    a884:      	ldr	x20, [x20]
		000000000000a884:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    a888:      	mov	x21, #0x18              ; =24
    a88c:      	b	0xa8bc <_stogir.floating.operands+0x224>
    a890:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a890:  ARM64_RELOC_PAGE21	l_stogir.471
    a894:      	ldr	x20, [x20]
		000000000000a894:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    a898:      	mov	x21, #0x21              ; =33
    a89c:      	b	0xa988 <_stogir.floating.operands+0x2f0>
    a8a0:      	ubfx	x9, x9, #0, #32
    a8a4:      	ubfx	x9, x9, #8, #8
    a8a8:      	cmp	x9, x19
    a8ac:      	b.eq	0xa8bc <_stogir.floating.operands+0x224>
    a8b0:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a8b0:  ARM64_RELOC_PAGE21	l_stogir.472
    a8b4:      	ldr	x20, [x20]
		000000000000a8b4:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    a8b8:      	mov	x21, #0x1e              ; =30
    a8bc:      	cmp	x3, #0x2
    a8c0:      	b.ge	0xa8e4 <_stogir.floating.operands+0x24c>
    a8c4:      	add	x9, x3, #0x1
    a8c8:      	add	x3, x2, x3, lsl #2
    a8cc:      	ldr	w3, [x3]
    a8d0:      	movn	w17, #0x0, lsl #16
    a8d4:      	and	w10, w3, w17
    a8d8:      	mov	x3, x9
    a8dc:      	mov	w9, #0x1                ; =1
    a8e0:      	b	0xa8ec <_stogir.floating.operands+0x254>
    a8e4:      	movz	w9, #0x0, lsl #16
    a8e8:      	movz	w10, #0x0, lsl #16
    a8ec:      	ubfx	x9, x9, #0, #32
    a8f0:      	lsr	x16, x9, #0
    a8f4:      	cmp	x16, #0x1
    a8f8:      	b.eq	0xa914 <_stogir.floating.operands+0x27c>
    a8fc:      	b.lo	0xa904 <_stogir.floating.operands+0x26c>
    a900:      	b	0xa918 <_stogir.floating.operands+0x280>
    a904:      	cmp	x16, #0x0
    a908:      	b.eq	0xa910 <_stogir.floating.operands+0x278>
    a90c:      	b	0xa918 <_stogir.floating.operands+0x280>
    a910:      	b	0xa978 <_stogir.floating.operands+0x2e0>
    a914:      	b	0xa91c <_stogir.floating.operands+0x284>
    a918:      	b	0xaaa8 <_stogir.floating.operands+0x410>
    a91c:      	sxtw	x10, w10
    a920:      	cmp	x10, #0x0
    a924:      	cset	w9, gt
    a928:      	movz	x16, #0x0, lsl #48
    a92c:      	sub	x11, x16, x10
    a930:      	sub	x12, x11, #0x1
    a934:      	uxtb	w16, w9
    a938:      	cmp	w16, wzr
    a93c:      	b.eq	0xa9fc <_stogir.floating.operands+0x364>
    a940:      	ldr	x11, [x0, #0x8]
    a944:      	cmp	x10, x11
    a948:      	b.ge	0xa804 <_stogir.floating.operands+0x16c>
    a94c:      	ldr	x11, [x6, #0x8]
    a950:      	cmp	x10, x11
    a954:      	b.ge	0xa790 <_stogir.floating.operands+0xf8>
    a958:      	ldr	x11, [x0, #0x78]
    a95c:      	add	x11, x11, x10, lsl #2
    a960:      	ldr	w11, [x11]
    a964:      	sxtw	x11, w11
    a968:      	cmp	x11, #0x0
    a96c:      	cset	w11, ge
    a970:      	ubfx	x11, x11, #0, #8
    a974:      	b	0xa794 <_stogir.floating.operands+0xfc>
    a978:      	sxtw	x22, w5
    a97c:      	cmp	x22, #0x0
    a980:      	b.ne	0xa9a0 <_stogir.floating.operands+0x308>
    a984:      	mov	x23, x8
    a988:      	cmp	x21, #0x0
    a98c:      	b.ne	0xaa3c <_stogir.floating.operands+0x3a4>
    a990:      	and	x20, x19, #0xffffffff
    a994:      	movz	x0, #0x0, lsl #48
    a998:      	movz	x21, #0x0, lsl #48
    a99c:      	b	0xaa40 <_stogir.floating.operands+0x3a8>
    a9a0:      	cmp	x1, #0x1d
    a9a4:      	b.ne	0xaac0 <_stogir.floating.operands+0x428>
    a9a8:      	mov	w1, w5
    a9ac:      	mov	x23, x8
    a9b0:      	add	x8, sp, #0x30
    a9b4:      	bl	0xa9b4 <_stogir.floating.operands+0x31c>
		000000000000a9b4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    a9b8:      	add	x16, sp, #0x30
    a9bc:      	ldr	w0, [x16]
    a9c0:      	lsr	x16, x0, #0
    a9c4:      	cmp	x16, #0x1
    a9c8:      	b.eq	0xa9e4 <_stogir.floating.operands+0x34c>
    a9cc:      	b.lo	0xa9d4 <_stogir.floating.operands+0x33c>
    a9d0:      	b	0xa9e8 <_stogir.floating.operands+0x350>
    a9d4:      	cmp	x16, #0x0
    a9d8:      	b.eq	0xa9e0 <_stogir.floating.operands+0x348>
    a9dc:      	b	0xa9e8 <_stogir.floating.operands+0x350>
    a9e0:      	b	0xa9ec <_stogir.floating.operands+0x354>
    a9e4:      	b	0xaa78 <_stogir.floating.operands+0x3e0>
    a9e8:      	b	0xaab8 <_stogir.floating.operands+0x420>
    a9ec:      	adrp	x20, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000a9ec:  ARM64_RELOC_PAGE21	l_stogir.473
    a9f0:      	ldr	x20, [x20]
		000000000000a9f0:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    a9f4:      	mov	x21, #0x16              ; =22
    a9f8:      	b	0xa78c <_stogir.floating.operands+0xf4>
    a9fc:      	cmp	x10, #0x0
    aa00:      	b.ge	0xa80c <_stogir.floating.operands+0x174>
    aa04:      	ldr	x13, [x4, #0x8]
    aa08:      	ldr	x14, [x7, #0x8]
    aa0c:      	cmp	x13, x14
    aa10:      	b.ne	0xa798 <_stogir.floating.operands+0x100>
    aa14:      	cmp	x11, x13
    aa18:      	b.gt	0xaa70 <_stogir.floating.operands+0x3d8>
    aa1c:      	ldr	x11, [x0, #0x50]
    aa20:      	add	x11, x11, x12, lsl #2
    aa24:      	ldr	w11, [x11]
    aa28:      	sxtw	x11, w11
    aa2c:      	cmp	x11, #0x0
    aa30:      	cset	w11, gt
    aa34:      	ubfx	x11, x11, #0, #8
    aa38:      	b	0xaa74 <_stogir.floating.operands+0x3dc>
    aa3c:      	mov	x0, #0x1                ; =1
    aa40:      	str	x0, [x23]
    aa44:      	str	x20, [x23, #0x8]
    aa48:      	str	x21, [x23, #0x10]
    aa4c:      	ldr	x19, [sp, #0x60]
    aa50:      	ldr	x20, [sp, #0x68]
    aa54:      	ldr	x21, [sp, #0x70]
    aa58:      	ldr	x22, [sp, #0x78]
    aa5c:      	ldr	x23, [sp, #0x80]
    aa60:      	ldr	x29, [sp]
    aa64:      	ldr	x30, [sp, #0x8]
    aa68:      	add	sp, sp, #0x90
    aa6c:      	ret
    aa70:      	movz	x11, #0x0, lsl #48
    aa74:      	b	0xa79c <_stogir.floating.operands+0x104>
    aa78:      	add	x16, sp, #0x30
    aa7c:      	ldr	x0, [x16, #0x8]
    aa80:      	cmp	x22, #0x0
    aa84:      	b.lt	0xa780 <_stogir.floating.operands+0xe8>
    aa88:      	uxtb	w0, w0
    aa8c:      	cmp	x0, #0x83
    aa90:      	b.ge	0xa740 <_stogir.floating.operands+0xa8>
    aa94:      	adrp	x17, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000aa94:  ARM64_RELOC_PAGE21	l_stogir.474
    aa98:      	ldr	x17, [x17]
		000000000000aa98:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    aa9c:      	add	x1, x0, x17
    aaa0:      	ldrb	w1, [x1]
    aaa4:      	b	0xa744 <_stogir.floating.operands+0xac>
    aaa8:      	brk	#0
    aaac:      	b	0xaaa8 <_stogir.floating.operands+0x410>
    aab0:      	brk	#0
    aab4:      	b	0xaab0 <_stogir.floating.operands+0x418>
    aab8:      	brk	#0
    aabc:      	b	0xaab8 <_stogir.floating.operands+0x420>
    aac0:      	mov	x23, x8
    aac4:      	b	0xa890 <_stogir.floating.operands+0x1f8>

000000000000aac8 <_stogir.vector-lanes.operands>:
    aac8:      	sub	sp, sp, #0x110
    aacc:      	str	x29, [sp]
    aad0:      	str	x30, [sp, #0x8]
    aad4:      	mov	x29, sp
    aad8:      	str	x19, [sp, #0xc0]
    aadc:      	str	x20, [sp, #0xc8]
    aae0:      	str	x21, [sp, #0xd0]
    aae4:      	str	x22, [sp, #0xd8]
    aae8:      	str	x23, [sp, #0xe0]
    aaec:      	str	x24, [sp, #0xe8]
    aaf0:      	str	x25, [sp, #0xf0]
    aaf4:      	str	x26, [sp, #0xf8]
    aaf8:      	str	x27, [sp, #0x100]
    aafc:      	str	x28, [sp, #0x108]
    ab00:      	sxtw	x4, w4
    ab04:      	add	x7, x0, #0x28
    ab08:      	cmp	x4, #0x0
    ab0c:      	cset	w9, gt
    ab10:      	movz	x16, #0x0, lsl #48
    ab14:      	sub	x10, x16, x4
    ab18:      	sub	x11, x10, #0x1
    ab1c:      	uxtb	w16, w9
    ab20:      	cmp	w16, wzr
    ab24:      	b.eq	0xab64 <_stogir.vector-lanes.operands+0x9c>
    ab28:      	ldr	x7, [x0, #0x8]
    ab2c:      	cmp	x4, x7
    ab30:      	b.ge	0xabb8 <_stogir.vector-lanes.operands+0xf0>
    ab34:      	add	x7, x0, #0x78
    ab38:      	ldr	x7, [x7, #0x8]
    ab3c:      	cmp	x4, x7
    ab40:      	b.ge	0xacb8 <_stogir.vector-lanes.operands+0x1f0>
    ab44:      	ldr	x7, [x0, #0x78]
    ab48:      	add	x7, x7, x4, lsl #2
    ab4c:      	ldr	w7, [x7]
    ab50:      	sxtw	x7, w7
    ab54:      	cmp	x7, #0x0
    ab58:      	cset	w7, ge
    ab5c:      	ubfx	x7, x7, #0, #8
    ab60:      	b	0xacbc <_stogir.vector-lanes.operands+0x1f4>
    ab64:      	cmp	x4, #0x0
    ab68:      	b.ge	0xabc0 <_stogir.vector-lanes.operands+0xf8>
    ab6c:      	add	x12, x0, #0x50
    ab70:      	ldr	x7, [x7, #0x8]
    ab74:      	ldr	x12, [x12, #0x8]
    ab78:      	cmp	x7, x12
    ab7c:      	b.ne	0xaba8 <_stogir.vector-lanes.operands+0xe0>
    ab80:      	cmp	x10, x7
    ab84:      	b.gt	0xae6c <_stogir.vector-lanes.operands+0x3a4>
    ab88:      	ldr	x7, [x0, #0x50]
    ab8c:      	add	x7, x7, x11, lsl #2
    ab90:      	ldr	w7, [x7]
    ab94:      	sxtw	x7, w7
    ab98:      	cmp	x7, #0x0
    ab9c:      	cset	w7, gt
    aba0:      	ubfx	x7, x7, #0, #8
    aba4:      	b	0xae70 <_stogir.vector-lanes.operands+0x3a8>
    aba8:      	movz	x7, #0x0, lsl #48
    abac:      	b	0xabc4 <_stogir.vector-lanes.operands+0xfc>
    abb0:      	mov	x2, #0x1                ; =1
    abb4:      	b	0xac48 <_stogir.vector-lanes.operands+0x180>
    abb8:      	movz	x7, #0x0, lsl #48
    abbc:      	b	0xabc4 <_stogir.vector-lanes.operands+0xfc>
    abc0:      	movz	x7, #0x0, lsl #48
    abc4:      	cmp	x7, #0x0
    abc8:      	b.eq	0xabfc <_stogir.vector-lanes.operands+0x134>
    abcc:      	uxtb	w16, w9
    abd0:      	cmp	w16, wzr
    abd4:      	b.eq	0xabe8 <_stogir.vector-lanes.operands+0x120>
    abd8:      	ldr	x7, [x0]
    abdc:      	add	x4, x7, x4, lsl #4
    abe0:      	ldr	x4, [x4]
    abe4:      	b	0xabf4 <_stogir.vector-lanes.operands+0x12c>
    abe8:      	ldr	x4, [x0, #0x28]
    abec:      	add	x4, x4, x11, lsl #4
    abf0:      	ldr	x4, [x4]
    abf4:      	mov	w7, #0x1                ; =1
    abf8:      	b	0xac04 <_stogir.vector-lanes.operands+0x13c>
    abfc:      	movz	w7, #0x0, lsl #16
    ac00:      	movz	x4, #0x0, lsl #48
    ac04:      	ubfx	x7, x7, #0, #32
    ac08:      	lsr	x16, x7, #0
    ac0c:      	cmp	x16, #0x1
    ac10:      	b.eq	0xac2c <_stogir.vector-lanes.operands+0x164>
    ac14:      	b.lo	0xac1c <_stogir.vector-lanes.operands+0x154>
    ac18:      	b	0xac30 <_stogir.vector-lanes.operands+0x168>
    ac1c:      	cmp	x16, #0x0
    ac20:      	b.eq	0xac28 <_stogir.vector-lanes.operands+0x160>
    ac24:      	b	0xac30 <_stogir.vector-lanes.operands+0x168>
    ac28:      	b	0xac34 <_stogir.vector-lanes.operands+0x16c>
    ac2c:      	b	0xac90 <_stogir.vector-lanes.operands+0x1c8>
    ac30:      	b	0xb140 <_stogir.vector-lanes.operands+0x678>
    ac34:      	str	x8, [sp, #0xa0]
    ac38:      	mov	x2, #0x1                ; =1
    ac3c:      	adrp	x1, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000ac3c:  ARM64_RELOC_PAGE21	l_stogir.475
    ac40:      	ldr	x1, [x1]
		000000000000ac40:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    ac44:      	mov	x0, #0x1b               ; =27
    ac48:      	ldr	x3, [sp, #0xa0]
    ac4c:      	str	x2, [x3]
    ac50:      	str	x1, [x3, #0x8]
    ac54:      	str	x0, [x3, #0x10]
    ac58:      	ldr	x19, [sp, #0xc0]
    ac5c:      	ldr	x20, [sp, #0xc8]
    ac60:      	ldr	x21, [sp, #0xd0]
    ac64:      	ldr	x22, [sp, #0xd8]
    ac68:      	ldr	x23, [sp, #0xe0]
    ac6c:      	ldr	x24, [sp, #0xe8]
    ac70:      	ldr	x25, [sp, #0xf0]
    ac74:      	ldr	x26, [sp, #0xf8]
    ac78:      	ldr	x27, [sp, #0x100]
    ac7c:      	ldr	x28, [sp, #0x108]
    ac80:      	ldr	x29, [sp]
    ac84:      	ldr	x30, [sp, #0x8]
    ac88:      	add	sp, sp, #0x110
    ac8c:      	ret
    ac90:      	sxtw	x19, w1
    ac94:      	sxtw	x1, w2
    ac98:      	orr	w7, w4, wzr
    ac9c:      	ubfx	x7, x7, #0, #32
    aca0:      	ubfx	x7, x7, #8, #8
    aca4:      	orr	x20, x7, xzr
    aca8:      	cmp	x19, #0x3d
    acac:      	b.ne	0xacc0 <_stogir.vector-lanes.operands+0x1f8>
    acb0:      	mov	x21, x20
    acb4:      	b	0xacc4 <_stogir.vector-lanes.operands+0x1fc>
    acb8:      	movz	x7, #0x0, lsl #48
    acbc:      	b	0xabbc <_stogir.vector-lanes.operands+0xf4>
    acc0:      	mov	x21, x1
    acc4:      	cmp	x19, #0x3d
    acc8:      	b.eq	0xacd0 <_stogir.vector-lanes.operands+0x208>
    accc:      	mov	x1, x20
    acd0:      	orr	w22, w21, wzr
    acd4:      	sxtw	x23, w22
    acd8:      	cmp	x23, #0xf
    acdc:      	cset	w24, gt
    ace0:      	cmp	x23, #0x80
    ace4:      	cset	w25, lt
    ace8:      	and	w7, w22, #0xf
    acec:      	ubfx	x7, x7, #0, #32
    acf0:      	cmp	x7, #0x1
    acf4:      	cset	w26, ge
    acf8:      	cmp	x7, #0xd
    acfc:      	cset	w27, le
    ad00:      	cmp	x19, #0x3d
    ad04:      	b.lt	0xad54 <_stogir.vector-lanes.operands+0x28c>
    ad08:      	cmp	x19, #0x3f
    ad0c:      	b.gt	0xad54 <_stogir.vector-lanes.operands+0x28c>
    ad10:      	uxtb	w16, w24
    ad14:      	cmp	w16, wzr
    ad18:      	b.eq	0xad54 <_stogir.vector-lanes.operands+0x28c>
    ad1c:      	uxtb	w16, w25
    ad20:      	cmp	w16, wzr
    ad24:      	b.eq	0xad54 <_stogir.vector-lanes.operands+0x28c>
    ad28:      	uxtb	w16, w26
    ad2c:      	cmp	w16, wzr
    ad30:      	b.eq	0xad54 <_stogir.vector-lanes.operands+0x28c>
    ad34:      	uxtb	w16, w27
    ad38:      	cmp	w16, wzr
    ad3c:      	b.eq	0xad54 <_stogir.vector-lanes.operands+0x28c>
    ad40:      	sxtw	x7, w3
    ad44:      	cmp	x7, #0x4
    ad48:      	b.eq	0xb170 <_stogir.vector-lanes.operands+0x6a8>
    ad4c:      	cmp	x7, #0x8
    ad50:      	b.eq	0xb170 <_stogir.vector-lanes.operands+0x6a8>
    ad54:      	adrp	x28, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000ad54:  ARM64_RELOC_PAGE21	l_stogir.476
    ad58:      	ldr	x28, [x28]
		000000000000ad58:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    ad5c:      	mov	x4, #0x36               ; =54
    ad60:      	sxtw	x7, w5
    ad64:      	sxtw	x9, w6
    ad68:      	cmp	x9, #0x0
    ad6c:      	cset	w9, eq
    ad70:      	cmp	x19, #0x3f
    ad74:      	b.ne	0xb1a4 <_stogir.vector-lanes.operands+0x6dc>
    ad78:      	mov	w0, w22
    ad7c:      	mov	w2, w3
    ad80:      	mov	x19, x8
    ad84:      	mov	x20, x4
    ad88:      	mov	x22, x7
    ad8c:      	mov	w23, w9
    ad90:      	bl	0xad90 <_stogir.vector-lanes.operands+0x2c8>
		000000000000ad90:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    ad94:      	cmp	x0, #0x0
    ad98:      	b.eq	0xaf78 <_stogir.vector-lanes.operands+0x4b0>
    ad9c:      	movz	x0, #0x0, lsl #48
    ada0:      	b	0xaf7c <_stogir.vector-lanes.operands+0x4b4>
    ada4:      	cmp	x19, #0x3d
    ada8:      	b.ne	0xb1b0 <_stogir.vector-lanes.operands+0x6e8>
    adac:      	str	x0, [sp, #0x80]
    adb0:      	mov	w0, w22
    adb4:      	str	w3, [sp, #0xb0]
    adb8:      	str	x1, [sp, #0xa0]
    adbc:      	mov	w1, w2
    adc0:      	mov	w2, w3
    adc4:      	str	x4, [sp, #0xa8]
    adc8:      	str	w8, [sp, #0xb8]
    adcc:      	str	w22, [sp, #0x88]
    add0:      	mov	x22, x7
    add4:      	str	x28, [sp, #0x90]
    add8:      	mov	w28, w5
    addc:      	str	x21, [sp, #0x98]
    ade0:      	mov	w21, w6
    ade4:      	bl	0xade4 <_stogir.vector-lanes.operands+0x31c>
		000000000000ade4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    ade8:      	cmp	x0, #0x0
    adec:      	b.ne	0xae04 <_stogir.vector-lanes.operands+0x33c>
    adf0:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000adf0:  ARM64_RELOC_PAGE21	l_stogir.477
    adf4:      	ldr	x16, [x16]
		000000000000adf4:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    adf8:      	str	x16, [sp, #0x90]
    adfc:      	mov	x16, #0x26              ; =38
    ae00:      	str	x16, [sp, #0xa8]
    ae04:      	cmp	x19, #0x3e
    ae08:      	b.ne	0xae9c <_stogir.vector-lanes.operands+0x3d4>
    ae0c:      	cmp	x20, x23
    ae10:      	cset	w0, eq
    ae14:      	uxtb	w16, w0
    ae18:      	cmp	w16, wzr
    ae1c:      	cset	x0, eq
    ae20:      	b	0xaea0 <_stogir.vector-lanes.operands+0x3d8>
    ae24:      	mov	x0, #0x1                ; =1
    ae28:      	cmp	x0, #0x0
    ae2c:      	b.eq	0xae3c <_stogir.vector-lanes.operands+0x374>
    ae30:      	adrp	x28, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000ae30:  ARM64_RELOC_PAGE21	l_stogir.478
    ae34:      	ldr	x28, [x28]
		000000000000ae34:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    ae38:      	mov	x20, #0x24              ; =36
    ae3c:      	str	x21, [sp, #0x98]
    ae40:      	str	x19, [sp, #0xa0]
    ae44:      	str	x28, [sp, #0x90]
    ae48:      	str	x20, [sp, #0xa8]
    ae4c:      	ldr	x0, [sp, #0xa8]
    ae50:      	cmp	x0, #0x0
    ae54:      	b.ne	0xb1e0 <_stogir.vector-lanes.operands+0x718>
    ae58:      	ldr	x0, [sp, #0x98]
    ae5c:      	and	x1, x0, #0xffffffff
    ae60:      	movz	x2, #0x0, lsl #48
    ae64:      	movz	x0, #0x0, lsl #48
    ae68:      	b	0xabb4 <_stogir.vector-lanes.operands+0xec>
    ae6c:      	movz	x7, #0x0, lsl #48
    ae70:      	b	0xabac <_stogir.vector-lanes.operands+0xe4>
    ae74:      	ldr	w0, [sp, #0xb8]
    ae78:      	uxtb	w16, w0
    ae7c:      	cmp	w16, wzr
    ae80:      	b.ne	0xae98 <_stogir.vector-lanes.operands+0x3d0>
    ae84:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000ae84:  ARM64_RELOC_PAGE21	l_stogir.479
    ae88:      	ldr	x16, [x16]
		000000000000ae88:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    ae8c:      	str	x16, [sp, #0x90]
    ae90:      	mov	x16, #0x20              ; =32
    ae94:      	str	x16, [sp, #0xa8]
    ae98:      	b	0xae4c <_stogir.vector-lanes.operands+0x384>
    ae9c:      	movz	x0, #0x0, lsl #48
    aea0:      	cmp	x0, #0x0
    aea4:      	b.eq	0xaebc <_stogir.vector-lanes.operands+0x3f4>
    aea8:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000aea8:  ARM64_RELOC_PAGE21	l_stogir.480
    aeac:      	ldr	x16, [x16]
		000000000000aeac:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    aeb0:      	str	x16, [sp, #0x90]
    aeb4:      	mov	x16, #0x27              ; =39
    aeb8:      	str	x16, [sp, #0xa8]
    aebc:      	add	x8, sp, #0x10
    aec0:      	ldr	x0, [sp, #0x80]
    aec4:      	mov	w1, w28
    aec8:      	bl	0xaec8 <_stogir.vector-lanes.operands+0x400>
		000000000000aec8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    aecc:      	add	x16, sp, #0x10
    aed0:      	ldr	w0, [x16]
    aed4:      	lsr	x16, x0, #0
    aed8:      	cmp	x16, #0x1
    aedc:      	b.eq	0xaef8 <_stogir.vector-lanes.operands+0x430>
    aee0:      	b.lo	0xaee8 <_stogir.vector-lanes.operands+0x420>
    aee4:      	b	0xaefc <_stogir.vector-lanes.operands+0x434>
    aee8:      	cmp	x16, #0x0
    aeec:      	b.eq	0xaef4 <_stogir.vector-lanes.operands+0x42c>
    aef0:      	b	0xaefc <_stogir.vector-lanes.operands+0x434>
    aef4:      	b	0xaf00 <_stogir.vector-lanes.operands+0x438>
    aef8:      	b	0xafa4 <_stogir.vector-lanes.operands+0x4dc>
    aefc:      	b	0xb194 <_stogir.vector-lanes.operands+0x6cc>
    af00:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000af00:  ARM64_RELOC_PAGE21	l_stogir.481
    af04:      	ldr	x16, [x16]
		000000000000af04:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    af08:      	str	x16, [sp, #0x90]
    af0c:      	mov	x16, #0x19              ; =25
    af10:      	str	x16, [sp, #0xa8]
    af14:      	cmp	x19, #0x3e
    af18:      	b.ne	0xae74 <_stogir.vector-lanes.operands+0x3ac>
    af1c:      	add	x8, sp, #0x50
    af20:      	ldr	x0, [sp, #0x80]
    af24:      	mov	w1, w21
    af28:      	bl	0xaf28 <_stogir.vector-lanes.operands+0x460>
		000000000000af28:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    af2c:      	add	x16, sp, #0x50
    af30:      	ldr	w0, [x16]
    af34:      	lsr	x16, x0, #0
    af38:      	cmp	x16, #0x1
    af3c:      	b.eq	0xaf58 <_stogir.vector-lanes.operands+0x490>
    af40:      	b.lo	0xaf48 <_stogir.vector-lanes.operands+0x480>
    af44:      	b	0xaf5c <_stogir.vector-lanes.operands+0x494>
    af48:      	cmp	x16, #0x0
    af4c:      	b.eq	0xaf54 <_stogir.vector-lanes.operands+0x48c>
    af50:      	b	0xaf5c <_stogir.vector-lanes.operands+0x494>
    af54:      	b	0xaf60 <_stogir.vector-lanes.operands+0x498>
    af58:      	b	0xb090 <_stogir.vector-lanes.operands+0x5c8>
    af5c:      	b	0xb19c <_stogir.vector-lanes.operands+0x6d4>
    af60:      	adrp	x16, 0xa000 <_stogir.conversion.policy+0x2f0>
		000000000000af60:  ARM64_RELOC_PAGE21	l_stogir.482
    af64:      	ldr	x16, [x16]
		000000000000af64:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    af68:      	str	x16, [sp, #0x90]
    af6c:      	mov	x16, #0x20              ; =32
    af70:      	str	x16, [sp, #0xa8]
    af74:      	b	0xae98 <_stogir.vector-lanes.operands+0x3d0>
    af78:      	mov	x0, #0x1                ; =1
    af7c:      	cmp	x0, #0x0
    af80:      	b.eq	0xaf8c <_stogir.vector-lanes.operands+0x4c4>
    af84:      	mov	x0, #0x1                ; =1
    af88:      	b	0xae28 <_stogir.vector-lanes.operands+0x360>
    af8c:      	cmp	x22, #0x0
    af90:      	b.ne	0xae24 <_stogir.vector-lanes.operands+0x35c>
    af94:      	uxtb	w16, w23
    af98:      	cmp	w16, wzr
    af9c:      	cset	x0, eq
    afa0:      	b	0xae28 <_stogir.vector-lanes.operands+0x360>
    afa4:      	add	x16, sp, #0x10
    afa8:      	orr	x0, x16, xzr
    afac:      	add	x0, x0, #0x8
    afb0:      	add	x16, sp, #0x10
    afb4:      	ldr	x1, [x16, #0x8]
    afb8:      	add	x16, sp, #0x40
    afbc:      	str	x1, [x16]
    afc0:      	ldr	x0, [x0, #0x8]
    afc4:      	ubfx	x1, x1, #0, #32
    afc8:      	add	x16, sp, #0x40
    afcc:      	str	x0, [x16, #0x8]
    afd0:      	ubfx	x0, x1, #8, #8
    afd4:      	cmp	x0, #0x1
    afd8:      	b.lt	0xb000 <_stogir.vector-lanes.operands+0x538>
    afdc:      	cmp	x0, #0xb
    afe0:      	b.gt	0xb000 <_stogir.vector-lanes.operands+0x538>
    afe4:      	add	x16, sp, #0x40
    afe8:      	ldr	w0, [x16]
    afec:      	uxtb	w0, w0
    aff0:      	cmp	x0, #0x48
    aff4:      	b.eq	0xb000 <_stogir.vector-lanes.operands+0x538>
    aff8:      	cmp	x0, #0x46
    affc:      	b.ne	0xb014 <_stogir.vector-lanes.operands+0x54c>
    b000:      	adrp	x16, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b000:  ARM64_RELOC_PAGE21	l_stogir.483
    b004:      	ldr	x16, [x16]
		000000000000b004:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    b008:      	str	x16, [sp, #0x90]
    b00c:      	mov	x16, #0x2b              ; =43
    b010:      	str	x16, [sp, #0xa8]
    b014:      	cmp	x22, #0x0
    b018:      	b.ge	0xb044 <_stogir.vector-lanes.operands+0x57c>
    b01c:      	add	x16, sp, #0x40
    b020:      	ldr	w0, [x16]
    b024:      	uxtb	w1, w0
    b028:      	ubfx	x0, x0, #8, #8
    b02c:      	cmp	x1, x0
    b030:      	b.eq	0xb0e8 <_stogir.vector-lanes.operands+0x620>
    b034:      	cmp	x1, #0x49
    b038:      	b.eq	0xb0e8 <_stogir.vector-lanes.operands+0x620>
    b03c:      	movz	x0, #0x0, lsl #48
    b040:      	b	0xb08c <_stogir.vector-lanes.operands+0x5c4>
    b044:      	movz	x0, #0x0, lsl #48
    b048:      	cmp	x0, #0x0
    b04c:      	b.eq	0xb064 <_stogir.vector-lanes.operands+0x59c>
    b050:      	adrp	x16, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b050:  ARM64_RELOC_PAGE21	l_stogir.484
    b054:      	ldr	x16, [x16]
		000000000000b054:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    b058:      	str	x16, [sp, #0x90]
    b05c:      	mov	x16, #0x28              ; =40
    b060:      	str	x16, [sp, #0xa8]
    b064:      	b	0xaf14 <_stogir.vector-lanes.operands+0x44c>
    b068:      	movn	w2, #0x0, lsl #16
    b06c:      	ubfx	x0, x0, #0, #32
    b070:      	ubfx	x1, x1, #0, #32
    b074:      	lsl	x1, x1, #32
    b078:      	orr	x0, x1, x0
    b07c:      	sxtw	x2, w2
    b080:      	cmp	x0, x2
    b084:      	cset	w0, hs
    b088:      	ubfx	x0, x0, #0, #8
    b08c:      	b	0xb048 <_stogir.vector-lanes.operands+0x580>
    b090:      	add	x16, sp, #0x50
    b094:      	ldr	x0, [x16, #0x8]
    b098:      	uxtb	w1, w0
    b09c:      	cmp	x1, #0x48
    b0a0:      	b.eq	0xb0d0 <_stogir.vector-lanes.operands+0x608>
    b0a4:      	cmp	x1, #0x46
    b0a8:      	b.eq	0xb0d0 <_stogir.vector-lanes.operands+0x608>
    b0ac:      	ldr	w1, [sp, #0xb0]
    b0b0:      	ubfx	x0, x0, #0, #32
    b0b4:      	ubfx	x0, x0, #8, #8
    b0b8:      	mov	w2, w1
    b0bc:      	mov	w1, w0
    b0c0:      	ldr	w0, [sp, #0x88]
    b0c4:      	bl	0xb0c4 <_stogir.vector-lanes.operands+0x5fc>
		000000000000b0c4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    b0c8:      	cmp	x0, #0x0
    b0cc:      	b.ne	0xb0e4 <_stogir.vector-lanes.operands+0x61c>
    b0d0:      	adrp	x16, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b0d0:  ARM64_RELOC_PAGE21	l_stogir.485
    b0d4:      	ldr	x16, [x16]
		000000000000b0d4:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    b0d8:      	str	x16, [sp, #0x90]
    b0dc:      	mov	x16, #0x27              ; =39
    b0e0:      	str	x16, [sp, #0xa8]
    b0e4:      	b	0xaf74 <_stogir.vector-lanes.operands+0x4ac>
    b0e8:      	add	x16, sp, #0x40
    b0ec:      	ldr	w0, [x16, #0x8]
    b0f0:      	add	x16, sp, #0x40
    b0f4:      	ldr	w1, [x16, #0xc]
    b0f8:      	uxtb	w16, w24
    b0fc:      	cmp	w16, wzr
    b100:      	b.eq	0xb148 <_stogir.vector-lanes.operands+0x680>
    b104:      	uxtb	w16, w25
    b108:      	cmp	w16, wzr
    b10c:      	b.eq	0xb148 <_stogir.vector-lanes.operands+0x680>
    b110:      	uxtb	w16, w26
    b114:      	cmp	w16, wzr
    b118:      	b.eq	0xb148 <_stogir.vector-lanes.operands+0x680>
    b11c:      	uxtb	w16, w27
    b120:      	cmp	w16, wzr
    b124:      	b.eq	0xb148 <_stogir.vector-lanes.operands+0x680>
    b128:      	ubfx	x2, x23, #4, #32
    b12c:      	sub	w2, w2, #0x1
    b130:      	sxtw	x2, w2
    b134:      	mov	x16, #0x1               ; =1
    b138:      	lsl	x2, x16, x2
    b13c:      	b	0xb06c <_stogir.vector-lanes.operands+0x5a4>
    b140:      	brk	#0
    b144:      	b	0xb140 <_stogir.vector-lanes.operands+0x678>
    b148:      	cmp	x23, #0x0
    b14c:      	b.lt	0xb068 <_stogir.vector-lanes.operands+0x5a0>
    b150:      	cmp	x23, #0xd
    b154:      	b.gt	0xb068 <_stogir.vector-lanes.operands+0x5a0>
    b158:      	cmp	x23, #0x0
    b15c:      	cset	w2, eq
    b160:      	uxtb	w16, w2
    b164:      	cmp	w16, wzr
    b168:      	cset	w2, eq
    b16c:      	b	0xb06c <_stogir.vector-lanes.operands+0x5a4>
    b170:      	uxtb	w4, w4
    b174:      	cmp	x4, #0x48
    b178:      	b.eq	0xad54 <_stogir.vector-lanes.operands+0x28c>
    b17c:      	cmp	x4, #0x46
    b180:      	b.eq	0xad54 <_stogir.vector-lanes.operands+0x28c>
    b184:      	adrp	x28, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b184:  ARM64_RELOC_PAGE21	l_stogir.486
    b188:      	ldr	x28, [x28]
		000000000000b188:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    b18c:      	movz	x4, #0x0, lsl #48
    b190:      	b	0xad60 <_stogir.vector-lanes.operands+0x298>
    b194:      	brk	#0
    b198:      	b	0xb194 <_stogir.vector-lanes.operands+0x6cc>
    b19c:      	brk	#0
    b1a0:      	b	0xb19c <_stogir.vector-lanes.operands+0x6d4>
    b1a4:      	mov	x1, x8
    b1a8:      	mov	w8, w9
    b1ac:      	b	0xada4 <_stogir.vector-lanes.operands+0x2dc>
    b1b0:      	str	x21, [sp, #0x98]
    b1b4:      	str	x1, [sp, #0xa0]
    b1b8:      	str	x0, [sp, #0x80]
    b1bc:      	str	w3, [sp, #0xb0]
    b1c0:      	mov	w21, w6
    b1c4:      	str	w22, [sp, #0x88]
    b1c8:      	mov	x22, x7
    b1cc:      	str	w8, [sp, #0xb8]
    b1d0:      	str	x28, [sp, #0x90]
    b1d4:      	mov	w28, w5
    b1d8:      	str	x4, [sp, #0xa8]
    b1dc:      	b	0xae04 <_stogir.vector-lanes.operands+0x33c>
    b1e0:      	ldr	x1, [sp, #0x90]
    b1e4:      	b	0xabb0 <_stogir.vector-lanes.operands+0xe8>

000000000000b1e8 <_stogir.vector-comparison.operands>:
    b1e8:      	sub	sp, sp, #0xc0
    b1ec:      	str	x29, [sp]
    b1f0:      	str	x30, [sp, #0x8]
    b1f4:      	mov	x29, sp
    b1f8:      	str	x19, [sp, #0x70]
    b1fc:      	str	x20, [sp, #0x78]
    b200:      	str	x21, [sp, #0x80]
    b204:      	str	x22, [sp, #0x88]
    b208:      	str	x23, [sp, #0x90]
    b20c:      	str	x24, [sp, #0x98]
    b210:      	str	x25, [sp, #0xa0]
    b214:      	str	x26, [sp, #0xa8]
    b218:      	str	x27, [sp, #0xb0]
    b21c:      	mov	x19, x8
    b220:      	add	x8, sp, #0x10
    b224:      	mov	x20, x0
    b228:      	mov	w21, w1
    b22c:      	mov	w1, w4
    b230:      	mov	w22, w2
    b234:      	mov	w23, w3
    b238:      	mov	w24, w5
    b23c:      	bl	0xb23c <_stogir.vector-comparison.operands+0x54>
		000000000000b23c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b240:      	add	x16, sp, #0x10
    b244:      	ldr	w0, [x16]
    b248:      	lsr	x16, x0, #0
    b24c:      	cmp	x16, #0x1
    b250:      	b.eq	0xb26c <_stogir.vector-comparison.operands+0x84>
    b254:      	b.lo	0xb25c <_stogir.vector-comparison.operands+0x74>
    b258:      	b	0xb270 <_stogir.vector-comparison.operands+0x88>
    b25c:      	cmp	x16, #0x0
    b260:      	b.eq	0xb268 <_stogir.vector-comparison.operands+0x80>
    b264:      	b	0xb270 <_stogir.vector-comparison.operands+0x88>
    b268:      	b	0xb274 <_stogir.vector-comparison.operands+0x8c>
    b26c:      	b	0xb2c4 <_stogir.vector-comparison.operands+0xdc>
    b270:      	b	0xb440 <_stogir.vector-comparison.operands+0x258>
    b274:      	mov	x1, #0x1                ; =1
    b278:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b278:  ARM64_RELOC_PAGE21	l_stogir.487
    b27c:      	ldr	x0, [x0]
		000000000000b27c:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b280:      	mov	x2, #0x21               ; =33
    b284:      	str	x1, [x19]
    b288:      	str	x0, [x19, #0x8]
    b28c:      	str	x2, [x19, #0x10]
    b290:      	ldr	x19, [sp, #0x70]
    b294:      	ldr	x20, [sp, #0x78]
    b298:      	ldr	x21, [sp, #0x80]
    b29c:      	ldr	x22, [sp, #0x88]
    b2a0:      	ldr	x23, [sp, #0x90]
    b2a4:      	ldr	x24, [sp, #0x98]
    b2a8:      	ldr	x25, [sp, #0xa0]
    b2ac:      	ldr	x26, [sp, #0xa8]
    b2b0:      	ldr	x27, [sp, #0xb0]
    b2b4:      	ldr	x29, [sp]
    b2b8:      	ldr	x30, [sp, #0x8]
    b2bc:      	add	sp, sp, #0xc0
    b2c0:      	ret
    b2c4:      	add	x16, sp, #0x10
    b2c8:      	ldr	x25, [x16, #0x8]
    b2cc:      	add	x8, sp, #0x40
    b2d0:      	mov	x0, x20
    b2d4:      	mov	w1, w24
    b2d8:      	bl	0xb2d8 <_stogir.vector-comparison.operands+0xf0>
		000000000000b2d8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b2dc:      	add	x16, sp, #0x40
    b2e0:      	ldr	w0, [x16]
    b2e4:      	lsr	x16, x0, #0
    b2e8:      	cmp	x16, #0x1
    b2ec:      	b.eq	0xb308 <_stogir.vector-comparison.operands+0x120>
    b2f0:      	b.lo	0xb2f8 <_stogir.vector-comparison.operands+0x110>
    b2f4:      	b	0xb30c <_stogir.vector-comparison.operands+0x124>
    b2f8:      	cmp	x16, #0x0
    b2fc:      	b.eq	0xb304 <_stogir.vector-comparison.operands+0x11c>
    b300:      	b	0xb30c <_stogir.vector-comparison.operands+0x124>
    b304:      	b	0xb310 <_stogir.vector-comparison.operands+0x128>
    b308:      	b	0xb324 <_stogir.vector-comparison.operands+0x13c>
    b30c:      	b	0xb448 <_stogir.vector-comparison.operands+0x260>
    b310:      	mov	x1, #0x1                ; =1
    b314:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b314:  ARM64_RELOC_PAGE21	l_stogir.487
    b318:      	ldr	x0, [x0]
		000000000000b318:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    b31c:      	mov	x2, #0x21               ; =33
    b320:      	b	0xb284 <_stogir.vector-comparison.operands+0x9c>
    b324:      	sxtw	x0, w23
    b328:      	add	x16, sp, #0x40
    b32c:      	ldr	x20, [x16, #0x8]
    b330:      	cmp	x0, #0x4
    b334:      	b.eq	0xb354 <_stogir.vector-comparison.operands+0x16c>
    b338:      	cmp	x0, #0x8
    b33c:      	b.eq	0xb354 <_stogir.vector-comparison.operands+0x16c>
    b340:      	mov	x1, #0x1                ; =1
    b344:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b344:  ARM64_RELOC_PAGE21	l_stogir.488
    b348:      	ldr	x0, [x0]
		000000000000b348:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    b34c:      	mov	x2, #0x33               ; =51
    b350:      	b	0xb320 <_stogir.vector-comparison.operands+0x138>
    b354:      	orr	w0, w25, wzr
    b358:      	ubfx	x0, x0, #0, #32
    b35c:      	ubfx	x24, x0, #8, #8
    b360:      	orr	x26, x24, xzr
    b364:      	mov	w0, w21
    b368:      	mov	w1, w26
    b36c:      	bl	0xb36c <_stogir.vector-comparison.operands+0x184>
		000000000000b36c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    b370:      	cmp	x0, #0x0
    b374:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b378:      	orr	w0, w20, wzr
    b37c:      	ubfx	x0, x0, #0, #32
    b380:      	ubfx	x0, x0, #8, #8
    b384:      	cmp	x24, x0
    b388:      	b.ne	0xb340 <_stogir.vector-comparison.operands+0x158>
    b38c:      	uxtb	w25, w25
    b390:      	cmp	x25, #0x48
    b394:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b398:      	cmp	x25, #0x46
    b39c:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b3a0:      	uxtb	w20, w20
    b3a4:      	cmp	x20, #0x48
    b3a8:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b3ac:      	cmp	x20, #0x46
    b3b0:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b3b4:      	sxtw	x0, w22
    b3b8:      	cmp	x0, #0xf
    b3bc:      	cset	w1, gt
    b3c0:      	uxtb	w16, w1
    b3c4:      	cmp	w16, wzr
    b3c8:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b3cc:      	cmp	x0, #0x80
    b3d0:      	cset	w2, lt
    b3d4:      	uxtb	w16, w2
    b3d8:      	cmp	w16, wzr
    b3dc:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b3e0:      	and	w3, w22, #0xf
    b3e4:      	ubfx	x4, x3, #0, #32
    b3e8:      	cmp	x4, #0x1
    b3ec:      	cset	w5, ge
    b3f0:      	uxtb	w16, w5
    b3f4:      	cmp	w16, wzr
    b3f8:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b3fc:      	cmp	x4, #0xd
    b400:      	cset	w4, le
    b404:      	uxtb	w16, w4
    b408:      	cmp	w16, wzr
    b40c:      	b.eq	0xb340 <_stogir.vector-comparison.operands+0x158>
    b410:      	cmp	x0, #0x0
    b414:      	cset	w6, ge
    b418:      	cmp	x0, #0xd
    b41c:      	cset	w7, le
    b420:      	uxtb	w16, w6
    b424:      	cmp	w16, wzr
    b428:      	b.eq	0xb450 <_stogir.vector-comparison.operands+0x268>
    b42c:      	uxtb	w16, w7
    b430:      	cmp	w16, wzr
    b434:      	b.eq	0xb450 <_stogir.vector-comparison.operands+0x268>
    b438:      	mov	w8, w3
    b43c:      	b	0xb484 <_stogir.vector-comparison.operands+0x29c>
    b440:      	brk	#0
    b444:      	b	0xb440 <_stogir.vector-comparison.operands+0x258>
    b448:      	brk	#0
    b44c:      	b	0xb448 <_stogir.vector-comparison.operands+0x260>
    b450:      	uxtb	w16, w1
    b454:      	cmp	w16, wzr
    b458:      	b.eq	0xb480 <_stogir.vector-comparison.operands+0x298>
    b45c:      	uxtb	w16, w2
    b460:      	cmp	w16, wzr
    b464:      	b.eq	0xb480 <_stogir.vector-comparison.operands+0x298>
    b468:      	uxtb	w16, w5
    b46c:      	cmp	w16, wzr
    b470:      	b.eq	0xb480 <_stogir.vector-comparison.operands+0x298>
    b474:      	uxtb	w16, w4
    b478:      	cmp	w16, wzr
    b47c:      	b.ne	0xb438 <_stogir.vector-comparison.operands+0x250>
    b480:      	movn	w8, #0x0, lsl #16
    b484:      	sxtw	x8, w8
    b488:      	cmp	x8, #0x1
    b48c:      	b.lt	0xb340 <_stogir.vector-comparison.operands+0x158>
    b490:      	cmp	x8, #0xb
    b494:      	b.gt	0xb340 <_stogir.vector-comparison.operands+0x158>
    b498:      	uxtb	w16, w1
    b49c:      	cmp	w16, wzr
    b4a0:      	b.eq	0xb4e0 <_stogir.vector-comparison.operands+0x2f8>
    b4a4:      	uxtb	w16, w2
    b4a8:      	cmp	w16, wzr
    b4ac:      	b.eq	0xb4e0 <_stogir.vector-comparison.operands+0x2f8>
    b4b0:      	uxtb	w16, w5
    b4b4:      	cmp	w16, wzr
    b4b8:      	b.eq	0xb4e0 <_stogir.vector-comparison.operands+0x2f8>
    b4bc:      	uxtb	w16, w4
    b4c0:      	cmp	w16, wzr
    b4c4:      	b.eq	0xb4e0 <_stogir.vector-comparison.operands+0x2f8>
    b4c8:      	ubfx	x0, x0, #4, #32
    b4cc:      	sub	w0, w0, #0x1
    b4d0:      	sxtw	x0, w0
    b4d4:      	mov	x16, #0x1               ; =1
    b4d8:      	lsl	x0, x16, x0
    b4dc:      	b	0xb5ec <_stogir.vector-comparison.operands+0x404>
    b4e0:      	uxtb	w16, w6
    b4e4:      	cmp	w16, wzr
    b4e8:      	b.eq	0xb5e8 <_stogir.vector-comparison.operands+0x400>
    b4ec:      	uxtb	w16, w7
    b4f0:      	cmp	w16, wzr
    b4f4:      	b.eq	0xb5e8 <_stogir.vector-comparison.operands+0x400>
    b4f8:      	cmp	x0, #0x0
    b4fc:      	cset	w0, eq
    b500:      	uxtb	w16, w0
    b504:      	cmp	w16, wzr
    b508:      	cset	w0, eq
    b50c:      	b	0xb5ec <_stogir.vector-comparison.operands+0x404>
    b510:      	movn	w8, #0x0, lsl #16
    b514:      	sxtw	x0, w0
    b518:      	sxtw	x8, w8
    b51c:      	cmp	x0, x8
    b520:      	b.ne	0xb340 <_stogir.vector-comparison.operands+0x158>
    b524:      	uxtb	w16, w6
    b528:      	cmp	w16, wzr
    b52c:      	b.eq	0xb53c <_stogir.vector-comparison.operands+0x354>
    b530:      	uxtb	w16, w7
    b534:      	cmp	w16, wzr
    b538:      	b.ne	0xb570 <_stogir.vector-comparison.operands+0x388>
    b53c:      	uxtb	w16, w1
    b540:      	cmp	w16, wzr
    b544:      	b.eq	0xb56c <_stogir.vector-comparison.operands+0x384>
    b548:      	uxtb	w16, w2
    b54c:      	cmp	w16, wzr
    b550:      	b.eq	0xb56c <_stogir.vector-comparison.operands+0x384>
    b554:      	uxtb	w16, w5
    b558:      	cmp	w16, wzr
    b55c:      	b.eq	0xb56c <_stogir.vector-comparison.operands+0x384>
    b560:      	uxtb	w16, w4
    b564:      	cmp	w16, wzr
    b568:      	b.ne	0xb570 <_stogir.vector-comparison.operands+0x388>
    b56c:      	movn	w3, #0x0, lsl #16
    b570:      	mov	w0, w3
    b574:      	mov	w1, w23
    b578:      	bl	0xb578 <_stogir.vector-comparison.operands+0x390>
		000000000000b578:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    b57c:      	uxtb	w16, w21
    b580:      	cmp	w16, wzr
    b584:      	b.ne	0xb5bc <_stogir.vector-comparison.operands+0x3d4>
    b588:      	uxtb	w16, w22
    b58c:      	cmp	w16, wzr
    b590:      	b.eq	0xb5b8 <_stogir.vector-comparison.operands+0x3d0>
    b594:      	uxtb	w16, w25
    b598:      	cmp	w16, wzr
    b59c:      	b.eq	0xb5b8 <_stogir.vector-comparison.operands+0x3d0>
    b5a0:      	uxtb	w16, w26
    b5a4:      	cmp	w16, wzr
    b5a8:      	b.eq	0xb5b8 <_stogir.vector-comparison.operands+0x3d0>
    b5ac:      	uxtb	w16, w27
    b5b0:      	cmp	w16, wzr
    b5b4:      	b.ne	0xb5bc <_stogir.vector-comparison.operands+0x3d4>
    b5b8:      	movn	w20, #0x0, lsl #16
    b5bc:      	sxtw	x21, w0
    b5c0:      	mov	w0, w20
    b5c4:      	mov	w1, w23
    b5c8:      	bl	0xb5c8 <_stogir.vector-comparison.operands+0x3e0>
		000000000000b5c8:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    b5cc:      	sxtw	x0, w0
    b5d0:      	cmp	x21, x0
    b5d4:      	b.ne	0xb340 <_stogir.vector-comparison.operands+0x158>
    b5d8:      	and	x0, x24, #0xffffffff
    b5dc:      	movz	x1, #0x0, lsl #48
    b5e0:      	movz	x2, #0x0, lsl #48
    b5e4:      	b	0xb350 <_stogir.vector-comparison.operands+0x168>
    b5e8:      	movn	w0, #0x0, lsl #16
    b5ec:      	and	w20, w26, #0xf
    b5f0:      	cmp	x24, #0xd
    b5f4:      	cset	w21, le
    b5f8:      	cmp	x24, #0xf
    b5fc:      	cset	w22, gt
    b600:      	cmp	x24, #0x80
    b604:      	cset	w25, lt
    b608:      	ubfx	x8, x20, #0, #32
    b60c:      	cmp	x8, #0x1
    b610:      	cset	w26, ge
    b614:      	cmp	x8, #0xd
    b618:      	cset	w27, le
    b61c:      	uxtb	w16, w22
    b620:      	cmp	w16, wzr
    b624:      	b.eq	0xb664 <_stogir.vector-comparison.operands+0x47c>
    b628:      	uxtb	w16, w25
    b62c:      	cmp	w16, wzr
    b630:      	b.eq	0xb664 <_stogir.vector-comparison.operands+0x47c>
    b634:      	uxtb	w16, w26
    b638:      	cmp	w16, wzr
    b63c:      	b.eq	0xb664 <_stogir.vector-comparison.operands+0x47c>
    b640:      	uxtb	w16, w27
    b644:      	cmp	w16, wzr
    b648:      	b.eq	0xb664 <_stogir.vector-comparison.operands+0x47c>
    b64c:      	ubfx	x8, x24, #4, #32
    b650:      	sub	w8, w8, #0x1
    b654:      	sxtw	x8, w8
    b658:      	mov	x16, #0x1               ; =1
    b65c:      	lsl	x8, x16, x8
    b660:      	b	0xb514 <_stogir.vector-comparison.operands+0x32c>
    b664:      	uxtb	w16, w21
    b668:      	cmp	w16, wzr
    b66c:      	b.eq	0xb510 <_stogir.vector-comparison.operands+0x328>
    b670:      	cmp	x24, #0x0
    b674:      	cset	w8, eq
    b678:      	uxtb	w16, w8
    b67c:      	cmp	w16, wzr
    b680:      	cset	w8, eq
    b684:      	b	0xb514 <_stogir.vector-comparison.operands+0x32c>

000000000000b688 <_stogir.vector-arithmetic.operands>:
    b688:      	sub	sp, sp, #0x70
    b68c:      	str	x29, [sp]
    b690:      	str	x30, [sp, #0x8]
    b694:      	mov	x29, sp
    b698:      	str	x19, [sp, #0x20]
    b69c:      	str	x20, [sp, #0x28]
    b6a0:      	str	x21, [sp, #0x30]
    b6a4:      	str	x22, [sp, #0x38]
    b6a8:      	str	x23, [sp, #0x40]
    b6ac:      	str	x24, [sp, #0x48]
    b6b0:      	str	x25, [sp, #0x50]
    b6b4:      	str	x26, [sp, #0x58]
    b6b8:      	str	x27, [sp, #0x60]
    b6bc:      	str	x28, [sp, #0x68]
    b6c0:      	mov	x19, x8
    b6c4:      	mov	x20, x0
    b6c8:      	mov	w0, w1
    b6cc:      	mov	w21, w1
    b6d0:      	mov	w1, w2
    b6d4:      	mov	w22, w2
    b6d8:      	mov	w23, w3
    b6dc:      	mov	w24, w4
    b6e0:      	mov	w25, w5
    b6e4:      	bl	0xb6e4 <_stogir.vector-arithmetic.operands+0x5c>
		000000000000b6e4:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    b6e8:      	cmp	x0, #0x0
    b6ec:      	b.eq	0xb700 <_stogir.vector-arithmetic.operands+0x78>
    b6f0:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b6f0:  ARM64_RELOC_PAGE21	l_stogir.489
    b6f4:      	ldr	x0, [x0]
		000000000000b6f4:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    b6f8:      	movz	x1, #0x0, lsl #48
    b6fc:      	b	0xb70c <_stogir.vector-arithmetic.operands+0x84>
    b700:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b700:  ARM64_RELOC_PAGE21	l_stogir.490
    b704:      	ldr	x0, [x0]
		000000000000b704:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    b708:      	mov	x1, #0x37               ; =55
    b70c:      	sxtw	x21, w21
    b710:      	sxtw	x22, w22
    b714:      	cmp	x21, #0x31
    b718:      	cset	w2, ge
    b71c:      	cmp	x21, #0x35
    b720:      	cset	w3, le
    b724:      	cmp	x21, #0x1f
    b728:      	cset	w4, eq
    b72c:      	cmp	x21, #0x20
    b730:      	cset	w5, eq
    b734:      	cmp	x21, #0x2d
    b738:      	cset	w6, eq
    b73c:      	cmp	x21, #0x36
    b740:      	cset	w7, eq
    b744:      	cmp	x21, #0x37
    b748:      	cset	w8, eq
    b74c:      	cmp	x21, #0x38
    b750:      	cset	w9, eq
    b754:      	cmp	x21, #0x39
    b758:      	cset	w10, eq
    b75c:      	add	x11, x20, #0x28
    b760:      	add	x12, x20, #0x78
    b764:      	add	x13, x20, #0x50
    b768:      	movz	x14, #0x0, lsl #48
    b76c:      	b	0xb890 <_stogir.vector-arithmetic.operands+0x208>
    b770:      	movz	x27, #0x0, lsl #48
    b774:      	b	0xb784 <_stogir.vector-arithmetic.operands+0xfc>
    b778:      	movz	x27, #0x0, lsl #48
    b77c:      	b	0xb78c <_stogir.vector-arithmetic.operands+0x104>
    b780:      	movz	x27, #0x0, lsl #48
    b784:      	b	0xb79c <_stogir.vector-arithmetic.operands+0x114>
    b788:      	movz	x27, #0x0, lsl #48
    b78c:      	str	w4, [sp, #0x10]
    b790:      	str	w5, [sp, #0x18]
    b794:      	b	0xb79c <_stogir.vector-arithmetic.operands+0x114>
    b798:      	movz	x27, #0x0, lsl #48
    b79c:      	cmp	x27, #0x0
    b7a0:      	b.eq	0xb7d4 <_stogir.vector-arithmetic.operands+0x14c>
    b7a4:      	uxtb	w16, w26
    b7a8:      	cmp	w16, wzr
    b7ac:      	b.eq	0xb7c0 <_stogir.vector-arithmetic.operands+0x138>
    b7b0:      	ldr	x4, [x20]
    b7b4:      	add	x4, x4, x15, lsl #4
    b7b8:      	ldr	x4, [x4]
    b7bc:      	b	0xb7cc <_stogir.vector-arithmetic.operands+0x144>
    b7c0:      	ldr	x4, [x20, #0x28]
    b7c4:      	add	x4, x4, x28, lsl #4
    b7c8:      	ldr	x4, [x4]
    b7cc:      	mov	w5, #0x1                ; =1
    b7d0:      	b	0xb7dc <_stogir.vector-arithmetic.operands+0x154>
    b7d4:      	movz	w5, #0x0, lsl #16
    b7d8:      	movz	x4, #0x0, lsl #48
    b7dc:      	ubfx	x5, x5, #0, #32
    b7e0:      	lsr	x16, x5, #0
    b7e4:      	cmp	x16, #0x1
    b7e8:      	b.eq	0xb804 <_stogir.vector-arithmetic.operands+0x17c>
    b7ec:      	b.lo	0xb7f4 <_stogir.vector-arithmetic.operands+0x16c>
    b7f0:      	b	0xb808 <_stogir.vector-arithmetic.operands+0x180>
    b7f4:      	cmp	x16, #0x0
    b7f8:      	b.eq	0xb800 <_stogir.vector-arithmetic.operands+0x178>
    b7fc:      	b	0xb808 <_stogir.vector-arithmetic.operands+0x180>
    b800:      	b	0xb80c <_stogir.vector-arithmetic.operands+0x184>
    b804:      	b	0xb81c <_stogir.vector-arithmetic.operands+0x194>
    b808:      	b	0xbb5c <_stogir.vector-arithmetic.operands+0x4d4>
    b80c:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b80c:  ARM64_RELOC_PAGE21	l_stogir.491
    b810:      	ldr	x0, [x0]
		000000000000b810:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    b814:      	mov	x1, #0x21               ; =33
    b818:      	b	0xb880 <_stogir.vector-arithmetic.operands+0x1f8>
    b81c:      	orr	w5, w4, wzr
    b820:      	ubfx	x5, x5, #0, #32
    b824:      	ubfx	x5, x5, #8, #8
    b828:      	cmp	x5, x22
    b82c:      	b.eq	0xb860 <_stogir.vector-arithmetic.operands+0x1d8>
    b830:      	cmp	x14, #0x1
    b834:      	b.ne	0xb874 <_stogir.vector-arithmetic.operands+0x1ec>
    b838:      	uxtb	w16, w2
    b83c:      	cmp	w16, wzr
    b840:      	b.eq	0xb874 <_stogir.vector-arithmetic.operands+0x1ec>
    b844:      	uxtb	w16, w3
    b848:      	cmp	w16, wzr
    b84c:      	b.eq	0xb874 <_stogir.vector-arithmetic.operands+0x1ec>
    b850:      	cmp	x5, #0x1
    b854:      	b.lt	0xb874 <_stogir.vector-arithmetic.operands+0x1ec>
    b858:      	cmp	x5, #0xb
    b85c:      	b.gt	0xb874 <_stogir.vector-arithmetic.operands+0x1ec>
    b860:      	uxtb	w4, w4
    b864:      	cmp	x4, #0x48
    b868:      	b.eq	0xb874 <_stogir.vector-arithmetic.operands+0x1ec>
    b86c:      	cmp	x4, #0x46
    b870:      	b.ne	0xb880 <_stogir.vector-arithmetic.operands+0x1f8>
    b874:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b874:  ARM64_RELOC_PAGE21	l_stogir.492
    b878:      	ldr	x0, [x0]
		000000000000b878:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    b87c:      	mov	x1, #0x32               ; =50
    b880:      	add	x4, x14, #0x1
    b884:      	sxtw	x14, w4
    b888:      	ldr	w4, [sp, #0x10]
    b88c:      	ldr	w5, [sp, #0x18]
    b890:      	uxtb	w16, w4
    b894:      	cmp	w16, wzr
    b898:      	b.ne	0xb8ec <_stogir.vector-arithmetic.operands+0x264>
    b89c:      	uxtb	w16, w5
    b8a0:      	cmp	w16, wzr
    b8a4:      	b.ne	0xb8ec <_stogir.vector-arithmetic.operands+0x264>
    b8a8:      	uxtb	w16, w6
    b8ac:      	cmp	w16, wzr
    b8b0:      	b.ne	0xb8ec <_stogir.vector-arithmetic.operands+0x264>
    b8b4:      	uxtb	w16, w7
    b8b8:      	cmp	w16, wzr
    b8bc:      	b.ne	0xb8ec <_stogir.vector-arithmetic.operands+0x264>
    b8c0:      	uxtb	w16, w8
    b8c4:      	cmp	w16, wzr
    b8c8:      	b.ne	0xb8ec <_stogir.vector-arithmetic.operands+0x264>
    b8cc:      	uxtb	w16, w9
    b8d0:      	cmp	w16, wzr
    b8d4:      	b.ne	0xb8ec <_stogir.vector-arithmetic.operands+0x264>
    b8d8:      	uxtb	w16, w10
    b8dc:      	cmp	w16, wzr
    b8e0:      	b.ne	0xb8ec <_stogir.vector-arithmetic.operands+0x264>
    b8e4:      	mov	x15, #0x2               ; =2
    b8e8:      	b	0xb8f0 <_stogir.vector-arithmetic.operands+0x268>
    b8ec:      	mov	x15, #0x1               ; =1
    b8f0:      	cmp	x14, x15
    b8f4:      	b.ge	0xb9b0 <_stogir.vector-arithmetic.operands+0x328>
    b8f8:      	cmp	x14, #0x0
    b8fc:      	b.ne	0xb908 <_stogir.vector-arithmetic.operands+0x280>
    b900:      	mov	w15, w23
    b904:      	b	0xb90c <_stogir.vector-arithmetic.operands+0x284>
    b908:      	mov	w15, w24
    b90c:      	sxtw	x15, w15
    b910:      	cmp	x15, #0x0
    b914:      	cset	w26, gt
    b918:      	movz	x16, #0x0, lsl #48
    b91c:      	sub	x27, x16, x15
    b920:      	sub	x28, x27, #0x1
    b924:      	uxtb	w16, w26
    b928:      	cmp	w16, wzr
    b92c:      	b.eq	0xb968 <_stogir.vector-arithmetic.operands+0x2e0>
    b930:      	ldr	x27, [x20, #0x8]
    b934:      	cmp	x15, x27
    b938:      	b.ge	0xb788 <_stogir.vector-arithmetic.operands+0x100>
    b93c:      	ldr	x27, [x12, #0x8]
    b940:      	cmp	x15, x27
    b944:      	b.ge	0xb778 <_stogir.vector-arithmetic.operands+0xf0>
    b948:      	ldr	x27, [x20, #0x78]
    b94c:      	add	x27, x27, x15, lsl #2
    b950:      	ldr	w27, [x27]
    b954:      	sxtw	x27, w27
    b958:      	cmp	x27, #0x0
    b95c:      	cset	w27, ge
    b960:      	ubfx	x27, x27, #0, #8
    b964:      	b	0xb77c <_stogir.vector-arithmetic.operands+0xf4>
    b968:      	cmp	x15, #0x0
    b96c:      	b.ge	0xbc38 <_stogir.vector-arithmetic.operands+0x5b0>
    b970:      	str	w4, [sp, #0x10]
    b974:      	ldr	x4, [x11, #0x8]
    b978:      	str	w5, [sp, #0x18]
    b97c:      	ldr	x5, [x13, #0x8]
    b980:      	cmp	x4, x5
    b984:      	b.ne	0xb780 <_stogir.vector-arithmetic.operands+0xf8>
    b988:      	cmp	x27, x4
    b98c:      	b.gt	0xb770 <_stogir.vector-arithmetic.operands+0xe8>
    b990:      	ldr	x4, [x20, #0x50]
    b994:      	add	x4, x4, x28, lsl #2
    b998:      	ldr	w4, [x4]
    b99c:      	sxtw	x4, w4
    b9a0:      	cmp	x4, #0x0
    b9a4:      	cset	w4, gt
    b9a8:      	ubfx	x27, x4, #0, #8
    b9ac:      	b	0xb774 <_stogir.vector-arithmetic.operands+0xec>
    b9b0:      	sxtw	x25, w25
    b9b4:      	cmp	x25, #0x0
    b9b8:      	b.ne	0xb9c4 <_stogir.vector-arithmetic.operands+0x33c>
    b9bc:      	movz	x2, #0x0, lsl #48
    b9c0:      	b	0xb9c8 <_stogir.vector-arithmetic.operands+0x340>
    b9c4:      	mov	x2, #0x1                ; =1
    b9c8:      	cmp	x2, #0x0
    b9cc:      	b.eq	0xb9f8 <_stogir.vector-arithmetic.operands+0x370>
    b9d0:      	cmp	x21, #0x1d
    b9d4:      	b.ne	0xbab0 <_stogir.vector-arithmetic.operands+0x428>
    b9d8:      	mov	x2, #0x1                ; =1
    b9dc:      	b	0xbabc <_stogir.vector-arithmetic.operands+0x434>
    b9e0:      	mov	x2, #0x1                ; =1
    b9e4:      	cmp	x2, #0x0
    b9e8:      	b.eq	0xba58 <_stogir.vector-arithmetic.operands+0x3d0>
    b9ec:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000b9ec:  ARM64_RELOC_PAGE21	l_stogir.493
    b9f0:      	ldr	x0, [x0]
		000000000000b9f0:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    b9f4:      	mov	x1, #0x23               ; =35
    b9f8:      	cmp	x1, #0x0
    b9fc:      	b.ne	0xba10 <_stogir.vector-arithmetic.operands+0x388>
    ba00:      	and	x0, x22, #0xffffffff
    ba04:      	movz	x2, #0x0, lsl #48
    ba08:      	movz	x1, #0x0, lsl #48
    ba0c:      	b	0xba14 <_stogir.vector-arithmetic.operands+0x38c>
    ba10:      	mov	x2, #0x1                ; =1
    ba14:      	str	x2, [x19]
    ba18:      	str	x0, [x19, #0x8]
    ba1c:      	str	x1, [x19, #0x10]
    ba20:      	ldr	x19, [sp, #0x20]
    ba24:      	ldr	x20, [sp, #0x28]
    ba28:      	ldr	x21, [sp, #0x30]
    ba2c:      	ldr	x22, [sp, #0x38]
    ba30:      	ldr	x23, [sp, #0x40]
    ba34:      	ldr	x24, [sp, #0x48]
    ba38:      	ldr	x25, [sp, #0x50]
    ba3c:      	ldr	x26, [sp, #0x58]
    ba40:      	ldr	x27, [sp, #0x60]
    ba44:      	ldr	x28, [sp, #0x68]
    ba48:      	ldr	x29, [sp]
    ba4c:      	ldr	x30, [sp, #0x8]
    ba50:      	add	sp, sp, #0x70
    ba54:      	ret
    ba58:      	cmp	x25, #0x0
    ba5c:      	cset	w2, gt
    ba60:      	movz	x16, #0x0, lsl #48
    ba64:      	sub	x3, x16, x25
    ba68:      	sub	x4, x3, #0x1
    ba6c:      	uxtb	w16, w2
    ba70:      	cmp	w16, wzr
    ba74:      	b.eq	0xbb1c <_stogir.vector-arithmetic.operands+0x494>
    ba78:      	ldr	x3, [x20, #0x8]
    ba7c:      	cmp	x25, x3
    ba80:      	b.ge	0xbb64 <_stogir.vector-arithmetic.operands+0x4dc>
    ba84:      	ldr	x3, [x12, #0x8]
    ba88:      	cmp	x25, x3
    ba8c:      	b.ge	0xbc20 <_stogir.vector-arithmetic.operands+0x598>
    ba90:      	ldr	x3, [x20, #0x78]
    ba94:      	add	x3, x3, x25, lsl #2
    ba98:      	ldr	w3, [x3]
    ba9c:      	sxtw	x3, w3
    baa0:      	cmp	x3, #0x0
    baa4:      	cset	w3, ge
    baa8:      	ubfx	x3, x3, #0, #8
    baac:      	b	0xbc24 <_stogir.vector-arithmetic.operands+0x59c>
    bab0:      	cmp	x21, #0x1e
    bab4:      	cset	w2, eq
    bab8:      	ubfx	x2, x2, #0, #8
    babc:      	cmp	x2, #0x0
    bac0:      	b.eq	0xb9e0 <_stogir.vector-arithmetic.operands+0x358>
    bac4:      	movz	x2, #0x0, lsl #48
    bac8:      	b	0xb9e4 <_stogir.vector-arithmetic.operands+0x35c>
    bacc:      	movz	w3, #0x0, lsl #16
    bad0:      	uxtb	w16, w3
    bad4:      	and	w3, w16, #0x2
    bad8:      	uxtb	w3, w3
    badc:      	ubfx	x3, x3, #0, #8
    bae0:      	cmp	x3, #0x0
    bae4:      	cset	w3, eq
    bae8:      	uxtb	w16, w3
    baec:      	cmp	w16, wzr
    baf0:      	cset	x3, eq
    baf4:      	cmp	x3, #0x0
    baf8:      	b.ne	0xbb18 <_stogir.vector-arithmetic.operands+0x490>
    bafc:      	cmp	x2, #0x65
    bb00:      	b.eq	0xbb18 <_stogir.vector-arithmetic.operands+0x490>
    bb04:      	cmp	x2, #0x66
    bb08:      	b.eq	0xbb18 <_stogir.vector-arithmetic.operands+0x490>
    bb0c:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000bb0c:  ARM64_RELOC_PAGE21	l_stogir.494
    bb10:      	ldr	x0, [x0]
		000000000000bb10:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    bb14:      	mov	x1, #0x34               ; =52
    bb18:      	b	0xb9f8 <_stogir.vector-arithmetic.operands+0x370>
    bb1c:      	cmp	x25, #0x0
    bb20:      	b.ge	0xbb6c <_stogir.vector-arithmetic.operands+0x4e4>
    bb24:      	ldr	x5, [x11, #0x8]
    bb28:      	ldr	x6, [x13, #0x8]
    bb2c:      	cmp	x5, x6
    bb30:      	b.ne	0xbc18 <_stogir.vector-arithmetic.operands+0x590>
    bb34:      	cmp	x3, x5
    bb38:      	b.gt	0xbc28 <_stogir.vector-arithmetic.operands+0x5a0>
    bb3c:      	ldr	x3, [x20, #0x50]
    bb40:      	add	x3, x3, x4, lsl #2
    bb44:      	ldr	w3, [x3]
    bb48:      	sxtw	x3, w3
    bb4c:      	cmp	x3, #0x0
    bb50:      	cset	w3, gt
    bb54:      	ubfx	x3, x3, #0, #8
    bb58:      	b	0xbc2c <_stogir.vector-arithmetic.operands+0x5a4>
    bb5c:      	brk	#0
    bb60:      	b	0xbb5c <_stogir.vector-arithmetic.operands+0x4d4>
    bb64:      	movz	x3, #0x0, lsl #48
    bb68:      	b	0xbb70 <_stogir.vector-arithmetic.operands+0x4e8>
    bb6c:      	movz	x3, #0x0, lsl #48
    bb70:      	cmp	x3, #0x0
    bb74:      	b.eq	0xbba8 <_stogir.vector-arithmetic.operands+0x520>
    bb78:      	uxtb	w16, w2
    bb7c:      	cmp	w16, wzr
    bb80:      	b.eq	0xbb94 <_stogir.vector-arithmetic.operands+0x50c>
    bb84:      	ldr	x2, [x20]
    bb88:      	add	x2, x2, x25, lsl #4
    bb8c:      	ldr	x2, [x2]
    bb90:      	b	0xbba0 <_stogir.vector-arithmetic.operands+0x518>
    bb94:      	ldr	x2, [x20, #0x28]
    bb98:      	add	x2, x2, x4, lsl #4
    bb9c:      	ldr	x2, [x2]
    bba0:      	mov	w3, #0x1                ; =1
    bba4:      	b	0xbbb0 <_stogir.vector-arithmetic.operands+0x528>
    bba8:      	movz	w3, #0x0, lsl #16
    bbac:      	movz	x2, #0x0, lsl #48
    bbb0:      	ubfx	x3, x3, #0, #32
    bbb4:      	lsr	x16, x3, #0
    bbb8:      	cmp	x16, #0x1
    bbbc:      	b.eq	0xbbd8 <_stogir.vector-arithmetic.operands+0x550>
    bbc0:      	b.lo	0xbbc8 <_stogir.vector-arithmetic.operands+0x540>
    bbc4:      	b	0xbbdc <_stogir.vector-arithmetic.operands+0x554>
    bbc8:      	cmp	x16, #0x0
    bbcc:      	b.eq	0xbbd4 <_stogir.vector-arithmetic.operands+0x54c>
    bbd0:      	b	0xbbdc <_stogir.vector-arithmetic.operands+0x554>
    bbd4:      	b	0xbbe0 <_stogir.vector-arithmetic.operands+0x558>
    bbd8:      	b	0xbbf0 <_stogir.vector-arithmetic.operands+0x568>
    bbdc:      	b	0xbc30 <_stogir.vector-arithmetic.operands+0x5a8>
    bbe0:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000bbe0:  ARM64_RELOC_PAGE21	l_stogir.495
    bbe4:      	ldr	x0, [x0]
		000000000000bbe4:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    bbe8:      	mov	x1, #0x1d               ; =29
    bbec:      	b	0xbb18 <_stogir.vector-arithmetic.operands+0x490>
    bbf0:      	cmp	x25, #0x0
    bbf4:      	b.le	0xbb0c <_stogir.vector-arithmetic.operands+0x484>
    bbf8:      	uxtb	w2, w2
    bbfc:      	cmp	x2, #0x83
    bc00:      	b.ge	0xbacc <_stogir.vector-arithmetic.operands+0x444>
    bc04:      	adrp	x17, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000bc04:  ARM64_RELOC_PAGE21	l_stogir.496
    bc08:      	ldr	x17, [x17]
		000000000000bc08:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    bc0c:      	add	x3, x2, x17
    bc10:      	ldrb	w3, [x3]
    bc14:      	b	0xbad0 <_stogir.vector-arithmetic.operands+0x448>
    bc18:      	movz	x3, #0x0, lsl #48
    bc1c:      	b	0xbb70 <_stogir.vector-arithmetic.operands+0x4e8>
    bc20:      	movz	x3, #0x0, lsl #48
    bc24:      	b	0xbb68 <_stogir.vector-arithmetic.operands+0x4e0>
    bc28:      	movz	x3, #0x0, lsl #48
    bc2c:      	b	0xbc1c <_stogir.vector-arithmetic.operands+0x594>
    bc30:      	brk	#0
    bc34:      	b	0xbc30 <_stogir.vector-arithmetic.operands+0x5a8>
    bc38:      	str	w4, [sp, #0x10]
    bc3c:      	str	w5, [sp, #0x18]
    bc40:      	b	0xb798 <_stogir.vector-arithmetic.operands+0x110>

000000000000bc44 <_stogir.switch.key>:
    bc44:      	sub	sp, sp, #0x20
    bc48:      	str	x29, [sp]
    bc4c:      	str	x30, [sp, #0x8]
    bc50:      	mov	x29, sp
    bc54:      	str	x19, [sp, #0x10]
    bc58:      	str	x20, [sp, #0x18]
    bc5c:      	sxtw	x3, w2
    bc60:      	cmp	x3, #0x1
    bc64:      	b.lt	0xbf80 <_stogir.switch.key+0x33c>
    bc68:      	cmp	x3, #0xb
    bc6c:      	b.gt	0xbf88 <_stogir.switch.key+0x344>
    bc70:      	sxtw	x1, w1
    bc74:      	cmp	x1, #0x0
    bc78:      	cset	w4, gt
    bc7c:      	movz	x16, #0x0, lsl #48
    bc80:      	sub	x5, x16, x1
    bc84:      	add	x6, x0, #0x28
    bc88:      	sub	x7, x5, #0x1
    bc8c:      	uxtb	w16, w4
    bc90:      	cmp	w16, wzr
    bc94:      	b.eq	0xbd2c <_stogir.switch.key+0xe8>
    bc98:      	ldr	x5, [x0, #0x8]
    bc9c:      	cmp	x1, x5
    bca0:      	b.ge	0xbd70 <_stogir.switch.key+0x12c>
    bca4:      	add	x5, x0, #0x78
    bca8:      	ldr	x5, [x5, #0x8]
    bcac:      	cmp	x1, x5
    bcb0:      	b.ge	0xbe30 <_stogir.switch.key+0x1ec>
    bcb4:      	ldr	x5, [x0, #0x78]
    bcb8:      	add	x5, x5, x1, lsl #2
    bcbc:      	ldr	w5, [x5]
    bcc0:      	sxtw	x5, w5
    bcc4:      	cmp	x5, #0x0
    bcc8:      	cset	w5, ge
    bccc:      	ubfx	x5, x5, #0, #8
    bcd0:      	b	0xbe34 <_stogir.switch.key+0x1f0>
    bcd4:      	mov	x1, #0x1                ; =1
    bcd8:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000bcd8:  ARM64_RELOC_PAGE21	l_stogir.497
    bcdc:      	ldr	x0, [x0]
		000000000000bcdc:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    bce0:      	mov	x2, #0x24               ; =36
    bce4:      	str	x1, [x20]
    bce8:      	str	x0, [x20, #0x8]
    bcec:      	str	x2, [x20, #0x10]
    bcf0:      	ldr	x19, [sp, #0x10]
    bcf4:      	ldr	x20, [sp, #0x18]
    bcf8:      	ldr	x29, [sp]
    bcfc:      	ldr	x30, [sp, #0x8]
    bd00:      	add	sp, sp, #0x20
    bd04:      	ret
    bd08:      	mov	w6, #0x1                ; =1
    bd0c:      	cmp	x1, #0x0
    bd10:      	b.lt	0xbe38 <_stogir.switch.key+0x1f4>
    bd14:      	mov	x20, x8
    bd18:      	mov	x1, #0x1                ; =1
    bd1c:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000bd1c:  ARM64_RELOC_PAGE21	l_stogir.498
    bd20:      	ldr	x0, [x0]
		000000000000bd20:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    bd24:      	mov	x2, #0x30               ; =48
    bd28:      	b	0xbce4 <_stogir.switch.key+0xa0>
    bd2c:      	cmp	x1, #0x0
    bd30:      	b.ge	0xbd78 <_stogir.switch.key+0x134>
    bd34:      	add	x9, x0, #0x50
    bd38:      	ldr	x6, [x6, #0x8]
    bd3c:      	ldr	x9, [x9, #0x8]
    bd40:      	cmp	x6, x9
    bd44:      	b.ne	0xbe28 <_stogir.switch.key+0x1e4>
    bd48:      	cmp	x5, x6
    bd4c:      	b.gt	0xbee4 <_stogir.switch.key+0x2a0>
    bd50:      	ldr	x5, [x0, #0x50]
    bd54:      	add	x5, x5, x7, lsl #2
    bd58:      	ldr	w5, [x5]
    bd5c:      	sxtw	x5, w5
    bd60:      	cmp	x5, #0x0
    bd64:      	cset	w5, gt
    bd68:      	ubfx	x5, x5, #0, #8
    bd6c:      	b	0xbee8 <_stogir.switch.key+0x2a4>
    bd70:      	movz	x5, #0x0, lsl #48
    bd74:      	b	0xbd7c <_stogir.switch.key+0x138>
    bd78:      	movz	x5, #0x0, lsl #48
    bd7c:      	cmp	x5, #0x0
    bd80:      	b.eq	0xbdbc <_stogir.switch.key+0x178>
    bd84:      	uxtb	w16, w4
    bd88:      	cmp	w16, wzr
    bd8c:      	b.eq	0xbda4 <_stogir.switch.key+0x160>
    bd90:      	ldr	x0, [x0]
    bd94:      	add	x0, x0, x1, lsl #4
    bd98:      	ldr	x4, [x0]
    bd9c:      	ldr	x0, [x0, #0x8]
    bda0:      	b	0xbdb4 <_stogir.switch.key+0x170>
    bda4:      	ldr	x0, [x0, #0x28]
    bda8:      	add	x0, x0, x7, lsl #4
    bdac:      	ldr	x4, [x0]
    bdb0:      	ldr	x0, [x0, #0x8]
    bdb4:      	mov	w5, #0x1                ; =1
    bdb8:      	b	0xbdc8 <_stogir.switch.key+0x184>
    bdbc:      	movz	w5, #0x0, lsl #16
    bdc0:      	movz	x4, #0x0, lsl #48
    bdc4:      	movz	x0, #0x0, lsl #48
    bdc8:      	ubfx	x5, x5, #0, #32
    bdcc:      	lsr	x16, x5, #0
    bdd0:      	cmp	x16, #0x1
    bdd4:      	b.eq	0xbdf0 <_stogir.switch.key+0x1ac>
    bdd8:      	b.lo	0xbde0 <_stogir.switch.key+0x19c>
    bddc:      	b	0xbdf4 <_stogir.switch.key+0x1b0>
    bde0:      	cmp	x16, #0x0
    bde4:      	b.eq	0xbdec <_stogir.switch.key+0x1a8>
    bde8:      	b	0xbdf4 <_stogir.switch.key+0x1b0>
    bdec:      	b	0xbdf8 <_stogir.switch.key+0x1b4>
    bdf0:      	b	0xbe10 <_stogir.switch.key+0x1cc>
    bdf4:      	b	0xbf68 <_stogir.switch.key+0x324>
    bdf8:      	mov	x20, x8
    bdfc:      	mov	x1, #0x1                ; =1
    be00:      	adrp	x0, 0xb000 <_stogir.vector-lanes.operands+0x538>
		000000000000be00:  ARM64_RELOC_PAGE21	l_stogir.499
    be04:      	ldr	x0, [x0]
		000000000000be04:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    be08:      	mov	x2, #0x1c               ; =28
    be0c:      	b	0xbd28 <_stogir.switch.key+0xe4>
    be10:      	cmp	x3, #0x1
    be14:      	cset	w5, eq
    be18:      	cmp	x3, #0x0
    be1c:      	b.ne	0xbe60 <_stogir.switch.key+0x21c>
    be20:      	movz	w6, #0x0, lsl #16
    be24:      	b	0xbd0c <_stogir.switch.key+0xc8>
    be28:      	movz	x5, #0x0, lsl #48
    be2c:      	b	0xbd7c <_stogir.switch.key+0x138>
    be30:      	movz	x5, #0x0, lsl #48
    be34:      	b	0xbd74 <_stogir.switch.key+0x130>
    be38:      	orr	w1, w4, wzr
    be3c:      	uxtb	w4, w4
    be40:      	ubfx	x1, x1, #0, #32
    be44:      	ubfx	x1, x1, #8, #8
    be48:      	cmp	x4, x1
    be4c:      	b.eq	0xbeec <_stogir.switch.key+0x2a8>
    be50:      	cmp	x4, #0x49
    be54:      	b.eq	0xbeec <_stogir.switch.key+0x2a8>
    be58:      	mov	x20, x8
    be5c:      	b	0xbd18 <_stogir.switch.key+0xd4>
    be60:      	uxtb	w16, w5
    be64:      	cmp	w16, wzr
    be68:      	b.ne	0xbd08 <_stogir.switch.key+0xc4>
    be6c:      	cmp	x3, #0x2
    be70:      	b.eq	0xbd08 <_stogir.switch.key+0xc4>
    be74:      	cmp	x3, #0x7
    be78:      	b.eq	0xbd08 <_stogir.switch.key+0xc4>
    be7c:      	cmp	x3, #0x8
    be80:      	b.eq	0xbd08 <_stogir.switch.key+0xc4>
    be84:      	cmp	x3, #0x3
    be88:      	b.eq	0xbf60 <_stogir.switch.key+0x31c>
    be8c:      	cmp	x3, #0x9
    be90:      	b.eq	0xbf60 <_stogir.switch.key+0x31c>
    be94:      	cmp	x3, #0x4
    be98:      	b.eq	0xbf70 <_stogir.switch.key+0x32c>
    be9c:      	cmp	x3, #0xa
    bea0:      	b.eq	0xbf70 <_stogir.switch.key+0x32c>
    bea4:      	cmp	x3, #0xd
    bea8:      	b.eq	0xbf70 <_stogir.switch.key+0x32c>
    beac:      	cmp	x3, #0x5
    beb0:      	b.eq	0xbf78 <_stogir.switch.key+0x334>
    beb4:      	cmp	x3, #0xb
    beb8:      	b.eq	0xbf78 <_stogir.switch.key+0x334>
    bebc:      	cmp	x3, #0xc
    bec0:      	b.eq	0xbf78 <_stogir.switch.key+0x334>
    bec4:      	cmp	x3, #0x6
    bec8:      	cset	w6, eq
    becc:      	uxtb	w16, w6
    bed0:      	cmp	w16, wzr
    bed4:      	mov	w16, #0x8               ; =8
    bed8:      	movn	w17, #0x0, lsl #16
    bedc:      	csel	w6, w16, w17, ne
    bee0:      	b	0xbf7c <_stogir.switch.key+0x338>
    bee4:      	movz	x5, #0x0, lsl #48
    bee8:      	b	0xbe2c <_stogir.switch.key+0x1e8>
    beec:      	cmp	x1, x3
    bef0:      	b.ne	0xbf90 <_stogir.switch.key+0x34c>
    bef4:      	lsl	w1, w6, #3
    bef8:      	orr	w3, w0, wzr
    befc:      	sxtw	x1, w1
    bf00:      	ubfx	x3, x3, #0, #32
    bf04:      	lsr	x0, x0, #32
    bf08:      	ubfx	x0, x0, #0, #32
    bf0c:      	lsl	x0, x0, #32
    bf10:      	orr	x19, x0, x3
    bf14:      	cmp	x1, #0x40
    bf18:      	b.ge	0xbf30 <_stogir.switch.key+0x2ec>
    bf1c:      	lsr	x0, x19, x1
    bf20:      	cmp	x0, #0x0
    bf24:      	b.eq	0xbf30 <_stogir.switch.key+0x2ec>
    bf28:      	mov	x20, x8
    bf2c:      	b	0xbd18 <_stogir.switch.key+0xd4>
    bf30:      	uxtb	w16, w5
    bf34:      	cmp	w16, wzr
    bf38:      	b.eq	0xbf44 <_stogir.switch.key+0x300>
    bf3c:      	cmp	x19, #0x1
    bf40:      	b.hi	0xbf28 <_stogir.switch.key+0x2e4>
    bf44:      	mov	w0, w2
    bf48:      	mov	x20, x8
    bf4c:      	bl	0xbf4c <_stogir.switch.key+0x308>
		000000000000bf4c:  ARM64_RELOC_BRANCH26	_stogir.switch.sign-mask
    bf50:      	eor	x0, x0, x19
    bf54:      	movz	x1, #0x0, lsl #48
    bf58:      	movz	x2, #0x0, lsl #48
    bf5c:      	b	0xbd28 <_stogir.switch.key+0xe4>
    bf60:      	mov	w6, #0x2                ; =2
    bf64:      	b	0xbd0c <_stogir.switch.key+0xc8>
    bf68:      	brk	#0
    bf6c:      	b	0xbf68 <_stogir.switch.key+0x324>
    bf70:      	mov	w6, #0x4                ; =4
    bf74:      	b	0xbf64 <_stogir.switch.key+0x320>
    bf78:      	mov	w6, #0x8                ; =8
    bf7c:      	b	0xbf74 <_stogir.switch.key+0x330>
    bf80:      	mov	x20, x8
    bf84:      	b	0xbcd4 <_stogir.switch.key+0x90>
    bf88:      	mov	x20, x8
    bf8c:      	b	0xbcd4 <_stogir.switch.key+0x90>
    bf90:      	mov	x20, x8
    bf94:      	b	0xbd18 <_stogir.switch.key+0xd4>

000000000000bf98 <_stogir.stack.constant-size>:
    bf98:      	sub	sp, sp, #0x10
    bf9c:      	str	x29, [sp]
    bfa0:      	str	x30, [sp, #0x8]
    bfa4:      	mov	x29, sp
    bfa8:      	mov	x2, sp
    bfac:      	sxtw	x1, w1
    bfb0:      	sub	sp, sp, #0x10
    bfb4:      	mov	x3, sp
    bfb8:      	add	x4, x0, #0x28
    bfbc:      	cmp	x1, #0x0
    bfc0:      	cset	w5, gt
    bfc4:      	movz	x16, #0x0, lsl #48
    bfc8:      	sub	x6, x16, x1
    bfcc:      	sub	x7, x6, #0x1
    bfd0:      	uxtb	w16, w5
    bfd4:      	cmp	w16, wzr
    bfd8:      	b.eq	0xc018 <_stogir.stack.constant-size+0x80>
    bfdc:      	ldr	x4, [x0, #0x8]
    bfe0:      	cmp	x1, x4
    bfe4:      	b.ge	0xc064 <_stogir.stack.constant-size+0xcc>
    bfe8:      	add	x4, x0, #0x78
    bfec:      	ldr	x4, [x4, #0x8]
    bff0:      	cmp	x1, x4
    bff4:      	b.ge	0xc1a4 <_stogir.stack.constant-size+0x20c>
    bff8:      	ldr	x4, [x0, #0x78]
    bffc:      	add	x4, x4, x1, lsl #2
    c000:      	ldr	w4, [x4]
    c004:      	sxtw	x4, w4
    c008:      	cmp	x4, #0x0
    c00c:      	cset	w4, ge
    c010:      	ubfx	x4, x4, #0, #8
    c014:      	b	0xc1a8 <_stogir.stack.constant-size+0x210>
    c018:      	cmp	x1, #0x0
    c01c:      	b.ge	0xc06c <_stogir.stack.constant-size+0xd4>
    c020:      	add	x9, x0, #0x50
    c024:      	ldr	x4, [x4, #0x8]
    c028:      	ldr	x9, [x9, #0x8]
    c02c:      	cmp	x4, x9
    c030:      	b.ne	0xc05c <_stogir.stack.constant-size+0xc4>
    c034:      	cmp	x6, x4
    c038:      	b.gt	0xc22c <_stogir.stack.constant-size+0x294>
    c03c:      	ldr	x4, [x0, #0x50]
    c040:      	add	x4, x4, x7, lsl #2
    c044:      	ldr	w4, [x4]
    c048:      	sxtw	x4, w4
    c04c:      	cmp	x4, #0x0
    c050:      	cset	w4, gt
    c054:      	ubfx	x4, x4, #0, #8
    c058:      	b	0xc230 <_stogir.stack.constant-size+0x298>
    c05c:      	movz	x4, #0x0, lsl #48
    c060:      	b	0xc070 <_stogir.stack.constant-size+0xd8>
    c064:      	movz	x4, #0x0, lsl #48
    c068:      	b	0xc070 <_stogir.stack.constant-size+0xd8>
    c06c:      	movz	x4, #0x0, lsl #48
    c070:      	cmp	x4, #0x0
    c074:      	b.eq	0xc0b0 <_stogir.stack.constant-size+0x118>
    c078:      	uxtb	w16, w5
    c07c:      	cmp	w16, wzr
    c080:      	b.eq	0xc098 <_stogir.stack.constant-size+0x100>
    c084:      	ldr	x0, [x0]
    c088:      	add	x0, x0, x1, lsl #4
    c08c:      	ldr	x4, [x0]
    c090:      	ldr	x0, [x0, #0x8]
    c094:      	b	0xc0a8 <_stogir.stack.constant-size+0x110>
    c098:      	ldr	x0, [x0, #0x28]
    c09c:      	add	x0, x0, x7, lsl #4
    c0a0:      	ldr	x4, [x0]
    c0a4:      	ldr	x0, [x0, #0x8]
    c0a8:      	mov	w5, #0x1                ; =1
    c0ac:      	b	0xc0bc <_stogir.stack.constant-size+0x124>
    c0b0:      	movz	w5, #0x0, lsl #16
    c0b4:      	movz	x4, #0x0, lsl #48
    c0b8:      	movz	x0, #0x0, lsl #48
    c0bc:      	ubfx	x5, x5, #0, #32
    c0c0:      	lsr	x16, x5, #0
    c0c4:      	cmp	x16, #0x1
    c0c8:      	b.eq	0xc0e4 <_stogir.stack.constant-size+0x14c>
    c0cc:      	b.lo	0xc0d4 <_stogir.stack.constant-size+0x13c>
    c0d0:      	b	0xc0e8 <_stogir.stack.constant-size+0x150>
    c0d4:      	cmp	x16, #0x0
    c0d8:      	b.eq	0xc0e0 <_stogir.stack.constant-size+0x148>
    c0dc:      	b	0xc0e8 <_stogir.stack.constant-size+0x150>
    c0e0:      	b	0xc0ec <_stogir.stack.constant-size+0x154>
    c0e4:      	b	0xc180 <_stogir.stack.constant-size+0x1e8>
    c0e8:      	b	0xc2c8 <_stogir.stack.constant-size+0x330>
    c0ec:      	mov	x1, #0x1                ; =1
    c0f0:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x68>
		000000000000c0f0:  ARM64_RELOC_PAGE21	l_stogir.500
    c0f4:      	ldr	x0, [x0]
		000000000000c0f4:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    c0f8:      	mov	x3, #0x18               ; =24
    c0fc:      	b	0xc15c <_stogir.stack.constant-size+0x1c4>
    c100:      	mov	w4, #0x1                ; =1
    c104:      	ldr	w5, [x3, #0x8]
    c108:      	ldr	w6, [x3, #0xc]
    c10c:      	cmp	x1, #0x0
    c110:      	b.ge	0xc14c <_stogir.stack.constant-size+0x1b4>
    c114:      	cmp	x0, #0x1
    c118:      	b.lt	0xc14c <_stogir.stack.constant-size+0x1b4>
    c11c:      	cmp	x0, #0xb
    c120:      	cset	w1, le
    c124:      	uxtb	w16, w1
    c128:      	cmp	w16, wzr
    c12c:      	b.eq	0xc14c <_stogir.stack.constant-size+0x1b4>
    c130:      	ldr	w3, [x3]
    c134:      	uxtb	w7, w3
    c138:      	ubfx	x3, x3, #8, #8
    c13c:      	cmp	x7, x3
    c140:      	b.eq	0xc234 <_stogir.stack.constant-size+0x29c>
    c144:      	cmp	x7, #0x49
    c148:      	b.eq	0xc234 <_stogir.stack.constant-size+0x29c>
    c14c:      	mov	x1, #0x1                ; =1
    c150:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x68>
		000000000000c150:  ARM64_RELOC_PAGE21	l_stogir.501
    c154:      	ldr	x0, [x0]
		000000000000c154:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    c158:      	mov	x3, #0x30               ; =48
    c15c:      	mov	sp, x2
    c160:      	str	x1, [x8]
    c164:      	str	x0, [x8, #0x8]
    c168:      	str	x3, [x8, #0x10]
    c16c:      	sub	sp, x29, #0x0
    c170:      	ldr	x29, [sp]
    c174:      	ldr	x30, [sp, #0x8]
    c178:      	add	sp, sp, #0x10
    c17c:      	ret
    c180:      	orr	w5, w4, wzr
    c184:      	str	x4, [x3]
    c188:      	ubfx	x5, x5, #0, #32
    c18c:      	str	x0, [x3, #0x8]
    c190:      	ubfx	x0, x5, #8, #8
    c194:      	cmp	x0, #0x0
    c198:      	b.ne	0xc1ac <_stogir.stack.constant-size+0x214>
    c19c:      	movz	w4, #0x0, lsl #16
    c1a0:      	b	0xc104 <_stogir.stack.constant-size+0x16c>
    c1a4:      	movz	x4, #0x0, lsl #48
    c1a8:      	b	0xc068 <_stogir.stack.constant-size+0xd0>
    c1ac:      	cmp	x0, #0x1
    c1b0:      	b.eq	0xc100 <_stogir.stack.constant-size+0x168>
    c1b4:      	cmp	x0, #0x2
    c1b8:      	b.eq	0xc100 <_stogir.stack.constant-size+0x168>
    c1bc:      	cmp	x0, #0x7
    c1c0:      	b.eq	0xc100 <_stogir.stack.constant-size+0x168>
    c1c4:      	cmp	x0, #0x8
    c1c8:      	b.eq	0xc100 <_stogir.stack.constant-size+0x168>
    c1cc:      	cmp	x0, #0x3
    c1d0:      	b.eq	0xc2c0 <_stogir.stack.constant-size+0x328>
    c1d4:      	cmp	x0, #0x9
    c1d8:      	b.eq	0xc2c0 <_stogir.stack.constant-size+0x328>
    c1dc:      	cmp	x0, #0x4
    c1e0:      	b.eq	0xc2d0 <_stogir.stack.constant-size+0x338>
    c1e4:      	cmp	x0, #0xa
    c1e8:      	b.eq	0xc2d0 <_stogir.stack.constant-size+0x338>
    c1ec:      	cmp	x0, #0xd
    c1f0:      	b.eq	0xc2d0 <_stogir.stack.constant-size+0x338>
    c1f4:      	cmp	x0, #0x5
    c1f8:      	b.eq	0xc2d8 <_stogir.stack.constant-size+0x340>
    c1fc:      	cmp	x0, #0xb
    c200:      	b.eq	0xc2d8 <_stogir.stack.constant-size+0x340>
    c204:      	cmp	x0, #0xc
    c208:      	b.eq	0xc2d8 <_stogir.stack.constant-size+0x340>
    c20c:      	cmp	x0, #0x6
    c210:      	cset	w4, eq
    c214:      	uxtb	w16, w4
    c218:      	cmp	w16, wzr
    c21c:      	mov	w16, #0x8               ; =8
    c220:      	movn	w17, #0x0, lsl #16
    c224:      	csel	w4, w16, w17, ne
    c228:      	b	0xc2dc <_stogir.stack.constant-size+0x344>
    c22c:      	movz	x4, #0x0, lsl #48
    c230:      	b	0xc060 <_stogir.stack.constant-size+0xc8>
    c234:      	sxtw	x3, w4
    c238:      	cmp	x3, #0x0
    c23c:      	b.le	0xc14c <_stogir.stack.constant-size+0x1b4>
    c240:      	lsl	w4, w4, #3
    c244:      	ubfx	x5, x5, #0, #32
    c248:      	ubfx	x6, x6, #0, #32
    c24c:      	lsl	x6, x6, #32
    c250:      	orr	x5, x6, x5
    c254:      	cmp	x3, #0x8
    c258:      	b.ge	0xc26c <_stogir.stack.constant-size+0x2d4>
    c25c:      	sxtw	x3, w4
    c260:      	lsr	x3, x5, x3
    c264:      	cmp	x3, #0x0
    c268:      	b.ne	0xc14c <_stogir.stack.constant-size+0x1b4>
    c26c:      	cmp	x0, #0x7
    c270:      	b.lt	0xc29c <_stogir.stack.constant-size+0x304>
    c274:      	uxtb	w16, w1
    c278:      	cmp	w16, wzr
    c27c:      	b.eq	0xc29c <_stogir.stack.constant-size+0x304>
    c280:      	sub	w0, w4, #0x1
    c284:      	sxtw	x0, w0
    c288:      	mov	x16, #0x1               ; =1
    c28c:      	lsl	x0, x16, x0
    c290:      	and	x0, x0, x5
    c294:      	cmp	x0, #0x0
    c298:      	b.ne	0xc14c <_stogir.stack.constant-size+0x1b4>
    c29c:      	mov	x17, #-0x10             ; =-16
    c2a0:      	movk	x17, #0x7fff, lsl #48
    c2a4:      	cmp	x5, x17
    c2a8:      	b.hi	0xc14c <_stogir.stack.constant-size+0x1b4>
    c2ac:      	add	x0, x5, #0xf
    c2b0:      	and	x0, x0, #0xfffffffffffffff0
    c2b4:      	movz	x1, #0x0, lsl #48
    c2b8:      	movz	x3, #0x0, lsl #48
    c2bc:      	b	0xc15c <_stogir.stack.constant-size+0x1c4>
    c2c0:      	mov	w4, #0x2                ; =2
    c2c4:      	b	0xc104 <_stogir.stack.constant-size+0x16c>
    c2c8:      	brk	#0
    c2cc:      	b	0xc2c8 <_stogir.stack.constant-size+0x330>
    c2d0:      	mov	w4, #0x4                ; =4
    c2d4:      	b	0xc2c4 <_stogir.stack.constant-size+0x32c>
    c2d8:      	mov	w4, #0x8                ; =8
    c2dc:      	b	0xc2d4 <_stogir.stack.constant-size+0x33c>

000000000000c2e0 <_stogir.stack.constant-size-aligned>:
    c2e0:      	sub	sp, sp, #0x10
    c2e4:      	cmp	x2, #0x10
    c2e8:      	b.lt	0xc368 <_stogir.stack.constant-size-aligned+0x88>
    c2ec:      	cmp	x2, #0x0
    c2f0:      	b.le	0xc368 <_stogir.stack.constant-size-aligned+0x88>
    c2f4:      	sub	x3, x2, #0x1
    c2f8:      	and	x3, x3, x2
    c2fc:      	cmp	x3, #0x0
    c300:      	b.ne	0xc368 <_stogir.stack.constant-size-aligned+0x88>
    c304:      	sxtw	x1, w1
    c308:      	cmp	x1, #0x0
    c30c:      	cset	w3, gt
    c310:      	movz	x16, #0x0, lsl #48
    c314:      	sub	x4, x16, x1
    c318:      	add	x5, x0, #0x28
    c31c:      	sub	x6, x4, #0x1
    c320:      	uxtb	w16, w3
    c324:      	cmp	w16, wzr
    c328:      	b.eq	0xc3f8 <_stogir.stack.constant-size-aligned+0x118>
    c32c:      	ldr	x4, [x0, #0x8]
    c330:      	cmp	x1, x4
    c334:      	b.ge	0xc43c <_stogir.stack.constant-size-aligned+0x15c>
    c338:      	add	x4, x0, #0x78
    c33c:      	ldr	x4, [x4, #0x8]
    c340:      	cmp	x1, x4
    c344:      	b.ge	0xc50c <_stogir.stack.constant-size-aligned+0x22c>
    c348:      	ldr	x4, [x0, #0x78]
    c34c:      	add	x4, x4, x1, lsl #2
    c350:      	ldr	w4, [x4]
    c354:      	sxtw	x4, w4
    c358:      	cmp	x4, #0x0
    c35c:      	cset	w4, ge
    c360:      	ubfx	x4, x4, #0, #8
    c364:      	b	0xc510 <_stogir.stack.constant-size-aligned+0x230>
    c368:      	mov	x1, #0x1                ; =1
    c36c:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x68>
		000000000000c36c:  ARM64_RELOC_PAGE21	l_stogir.502
    c370:      	ldr	x0, [x0]
		000000000000c370:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    c374:      	mov	x2, #0x20               ; =32
    c378:      	str	x1, [x8]
    c37c:      	str	x0, [x8, #0x8]
    c380:      	str	x2, [x8, #0x10]
    c384:      	add	sp, sp, #0x10
    c388:      	ret
    c38c:      	mov	w3, #0x1                ; =1
    c390:      	mov	x16, sp
    c394:      	ldr	w4, [x16, #0x8]
    c398:      	mov	x16, sp
    c39c:      	ldr	w5, [x16, #0xc]
    c3a0:      	cmp	x1, #0x0
    c3a4:      	b.ge	0xc3e4 <_stogir.stack.constant-size-aligned+0x104>
    c3a8:      	cmp	x0, #0x1
    c3ac:      	b.lt	0xc3e4 <_stogir.stack.constant-size-aligned+0x104>
    c3b0:      	cmp	x0, #0xb
    c3b4:      	cset	w1, le
    c3b8:      	uxtb	w16, w1
    c3bc:      	cmp	w16, wzr
    c3c0:      	b.eq	0xc3e4 <_stogir.stack.constant-size-aligned+0x104>
    c3c4:      	mov	x16, sp
    c3c8:      	ldr	w6, [x16]
    c3cc:      	uxtb	w7, w6
    c3d0:      	ubfx	x6, x6, #8, #8
    c3d4:      	cmp	x7, x6
    c3d8:      	b.eq	0xc59c <_stogir.stack.constant-size-aligned+0x2bc>
    c3dc:      	cmp	x7, #0x49
    c3e0:      	b.eq	0xc59c <_stogir.stack.constant-size-aligned+0x2bc>
    c3e4:      	mov	x1, #0x1                ; =1
    c3e8:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x68>
		000000000000c3e8:  ARM64_RELOC_PAGE21	l_stogir.503
    c3ec:      	ldr	x0, [x0]
		000000000000c3ec:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    c3f0:      	mov	x2, #0x30               ; =48
    c3f4:      	b	0xc378 <_stogir.stack.constant-size-aligned+0x98>
    c3f8:      	cmp	x1, #0x0
    c3fc:      	b.ge	0xc444 <_stogir.stack.constant-size-aligned+0x164>
    c400:      	add	x7, x0, #0x50
    c404:      	ldr	x5, [x5, #0x8]
    c408:      	ldr	x7, [x7, #0x8]
    c40c:      	cmp	x5, x7
    c410:      	b.ne	0xc504 <_stogir.stack.constant-size-aligned+0x224>
    c414:      	cmp	x4, x5
    c418:      	b.gt	0xc594 <_stogir.stack.constant-size-aligned+0x2b4>
    c41c:      	ldr	x4, [x0, #0x50]
    c420:      	add	x4, x4, x6, lsl #2
    c424:      	ldr	w4, [x4]
    c428:      	sxtw	x4, w4
    c42c:      	cmp	x4, #0x0
    c430:      	cset	w4, gt
    c434:      	ubfx	x4, x4, #0, #8
    c438:      	b	0xc598 <_stogir.stack.constant-size-aligned+0x2b8>
    c43c:      	movz	x4, #0x0, lsl #48
    c440:      	b	0xc448 <_stogir.stack.constant-size-aligned+0x168>
    c444:      	movz	x4, #0x0, lsl #48
    c448:      	cmp	x4, #0x0
    c44c:      	b.eq	0xc488 <_stogir.stack.constant-size-aligned+0x1a8>
    c450:      	uxtb	w16, w3
    c454:      	cmp	w16, wzr
    c458:      	b.eq	0xc470 <_stogir.stack.constant-size-aligned+0x190>
    c45c:      	ldr	x0, [x0]
    c460:      	add	x0, x0, x1, lsl #4
    c464:      	ldr	x3, [x0]
    c468:      	ldr	x0, [x0, #0x8]
    c46c:      	b	0xc480 <_stogir.stack.constant-size-aligned+0x1a0>
    c470:      	ldr	x0, [x0, #0x28]
    c474:      	add	x0, x0, x6, lsl #4
    c478:      	ldr	x3, [x0]
    c47c:      	ldr	x0, [x0, #0x8]
    c480:      	mov	w4, #0x1                ; =1
    c484:      	b	0xc494 <_stogir.stack.constant-size-aligned+0x1b4>
    c488:      	movz	w4, #0x0, lsl #16
    c48c:      	movz	x3, #0x0, lsl #48
    c490:      	movz	x0, #0x0, lsl #48
    c494:      	ubfx	x4, x4, #0, #32
    c498:      	lsr	x16, x4, #0
    c49c:      	cmp	x16, #0x1
    c4a0:      	b.eq	0xc4bc <_stogir.stack.constant-size-aligned+0x1dc>
    c4a4:      	b.lo	0xc4ac <_stogir.stack.constant-size-aligned+0x1cc>
    c4a8:      	b	0xc4c0 <_stogir.stack.constant-size-aligned+0x1e0>
    c4ac:      	cmp	x16, #0x0
    c4b0:      	b.eq	0xc4b8 <_stogir.stack.constant-size-aligned+0x1d8>
    c4b4:      	b	0xc4c0 <_stogir.stack.constant-size-aligned+0x1e0>
    c4b8:      	b	0xc4c4 <_stogir.stack.constant-size-aligned+0x1e4>
    c4bc:      	b	0xc4d8 <_stogir.stack.constant-size-aligned+0x1f8>
    c4c0:      	b	0xc640 <_stogir.stack.constant-size-aligned+0x360>
    c4c4:      	mov	x1, #0x1                ; =1
    c4c8:      	adrp	x0, 0xc000 <_stogir.stack.constant-size+0x68>
		000000000000c4c8:  ARM64_RELOC_PAGE21	l_stogir.504
    c4cc:      	ldr	x0, [x0]
		000000000000c4cc:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    c4d0:      	mov	x2, #0x18               ; =24
    c4d4:      	b	0xc3f4 <_stogir.stack.constant-size-aligned+0x114>
    c4d8:      	orr	w4, w3, wzr
    c4dc:      	mov	x16, sp
    c4e0:      	str	x3, [x16]
    c4e4:      	ubfx	x4, x4, #0, #32
    c4e8:      	mov	x16, sp
    c4ec:      	str	x0, [x16, #0x8]
    c4f0:      	ubfx	x0, x4, #8, #8
    c4f4:      	cmp	x0, #0x0
    c4f8:      	b.ne	0xc514 <_stogir.stack.constant-size-aligned+0x234>
    c4fc:      	movz	w3, #0x0, lsl #16
    c500:      	b	0xc390 <_stogir.stack.constant-size-aligned+0xb0>
    c504:      	movz	x4, #0x0, lsl #48
    c508:      	b	0xc448 <_stogir.stack.constant-size-aligned+0x168>
    c50c:      	movz	x4, #0x0, lsl #48
    c510:      	b	0xc440 <_stogir.stack.constant-size-aligned+0x160>
    c514:      	cmp	x0, #0x1
    c518:      	b.eq	0xc38c <_stogir.stack.constant-size-aligned+0xac>
    c51c:      	cmp	x0, #0x2
    c520:      	b.eq	0xc38c <_stogir.stack.constant-size-aligned+0xac>
    c524:      	cmp	x0, #0x7
    c528:      	b.eq	0xc38c <_stogir.stack.constant-size-aligned+0xac>
    c52c:      	cmp	x0, #0x8
    c530:      	b.eq	0xc38c <_stogir.stack.constant-size-aligned+0xac>
    c534:      	cmp	x0, #0x3
    c538:      	b.eq	0xc638 <_stogir.stack.constant-size-aligned+0x358>
    c53c:      	cmp	x0, #0x9
    c540:      	b.eq	0xc638 <_stogir.stack.constant-size-aligned+0x358>
    c544:      	cmp	x0, #0x4
    c548:      	b.eq	0xc648 <_stogir.stack.constant-size-aligned+0x368>
    c54c:      	cmp	x0, #0xa
    c550:      	b.eq	0xc648 <_stogir.stack.constant-size-aligned+0x368>
    c554:      	cmp	x0, #0xd
    c558:      	b.eq	0xc648 <_stogir.stack.constant-size-aligned+0x368>
    c55c:      	cmp	x0, #0x5
    c560:      	b.eq	0xc650 <_stogir.stack.constant-size-aligned+0x370>
    c564:      	cmp	x0, #0xb
    c568:      	b.eq	0xc650 <_stogir.stack.constant-size-aligned+0x370>
    c56c:      	cmp	x0, #0xc
    c570:      	b.eq	0xc650 <_stogir.stack.constant-size-aligned+0x370>
    c574:      	cmp	x0, #0x6
    c578:      	cset	w3, eq
    c57c:      	uxtb	w16, w3
    c580:      	cmp	w16, wzr
    c584:      	mov	w16, #0x8               ; =8
    c588:      	movn	w17, #0x0, lsl #16
    c58c:      	csel	w3, w16, w17, ne
    c590:      	b	0xc654 <_stogir.stack.constant-size-aligned+0x374>
    c594:      	movz	x4, #0x0, lsl #48
    c598:      	b	0xc508 <_stogir.stack.constant-size-aligned+0x228>
    c59c:      	sxtw	x6, w3
    c5a0:      	cmp	x6, #0x0
    c5a4:      	b.le	0xc3e4 <_stogir.stack.constant-size-aligned+0x104>
    c5a8:      	lsl	w3, w3, #3
    c5ac:      	ubfx	x4, x4, #0, #32
    c5b0:      	ubfx	x5, x5, #0, #32
    c5b4:      	lsl	x5, x5, #32
    c5b8:      	orr	x4, x5, x4
    c5bc:      	cmp	x6, #0x8
    c5c0:      	b.ge	0xc5d4 <_stogir.stack.constant-size-aligned+0x2f4>
    c5c4:      	sxtw	x5, w3
    c5c8:      	lsr	x5, x4, x5
    c5cc:      	cmp	x5, #0x0
    c5d0:      	b.ne	0xc3e4 <_stogir.stack.constant-size-aligned+0x104>
    c5d4:      	cmp	x0, #0x7
    c5d8:      	b.lt	0xc604 <_stogir.stack.constant-size-aligned+0x324>
    c5dc:      	uxtb	w16, w1
    c5e0:      	cmp	w16, wzr
    c5e4:      	b.eq	0xc604 <_stogir.stack.constant-size-aligned+0x324>
    c5e8:      	sub	w0, w3, #0x1
    c5ec:      	sxtw	x0, w0
    c5f0:      	mov	x16, #0x1               ; =1
    c5f4:      	lsl	x0, x16, x0
    c5f8:      	and	x0, x0, x4
    c5fc:      	cmp	x0, #0x0
    c600:      	b.ne	0xc3e4 <_stogir.stack.constant-size-aligned+0x104>
    c604:      	sub	x0, x2, #0x1
    c608:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    c60c:      	sub	x0, x16, x0
    c610:      	cmp	x4, x0
    c614:      	b.hi	0xc3e4 <_stogir.stack.constant-size-aligned+0x104>
    c618:      	sub	x0, x2, #0x1
    c61c:      	movz	x16, #0x0, lsl #48
    c620:      	sub	x1, x16, x2
    c624:      	add	x0, x0, x4
    c628:      	and	x0, x1, x0
    c62c:      	movz	x1, #0x0, lsl #48
    c630:      	movz	x2, #0x0, lsl #48
    c634:      	b	0xc3f4 <_stogir.stack.constant-size-aligned+0x114>
    c638:      	mov	w3, #0x2                ; =2
    c63c:      	b	0xc390 <_stogir.stack.constant-size-aligned+0xb0>
    c640:      	brk	#0
    c644:      	b	0xc640 <_stogir.stack.constant-size-aligned+0x360>
    c648:      	mov	w3, #0x4                ; =4
    c64c:      	b	0xc63c <_stogir.stack.constant-size-aligned+0x35c>
    c650:      	mov	w3, #0x8                ; =8
    c654:      	b	0xc64c <_stogir.stack.constant-size-aligned+0x36c>

000000000000c658 <_stogir.vector-lanes.compatible?>:
    c658:      	and	w3, w0, #0xf
    c65c:      	sxtw	x0, w0
    c660:      	ubfx	x4, x3, #0, #32
    c664:      	cmp	x0, #0xf
    c668:      	cset	w5, gt
    c66c:      	cmp	x0, #0x80
    c670:      	cset	w6, lt
    c674:      	cmp	x4, #0x1
    c678:      	cset	w7, ge
    c67c:      	cmp	x4, #0xd
    c680:      	cset	w4, le
    c684:      	cmp	x0, #0x0
    c688:      	b.lt	0xc694 <_stogir.vector-lanes.compatible?+0x3c>
    c68c:      	cmp	x0, #0xd
    c690:      	b.le	0xc6c8 <_stogir.vector-lanes.compatible?+0x70>
    c694:      	uxtb	w16, w5
    c698:      	cmp	w16, wzr
    c69c:      	b.eq	0xc6c4 <_stogir.vector-lanes.compatible?+0x6c>
    c6a0:      	uxtb	w16, w6
    c6a4:      	cmp	w16, wzr
    c6a8:      	b.eq	0xc6c4 <_stogir.vector-lanes.compatible?+0x6c>
    c6ac:      	uxtb	w16, w7
    c6b0:      	cmp	w16, wzr
    c6b4:      	b.eq	0xc6c4 <_stogir.vector-lanes.compatible?+0x6c>
    c6b8:      	uxtb	w16, w4
    c6bc:      	cmp	w16, wzr
    c6c0:      	b.ne	0xc6c8 <_stogir.vector-lanes.compatible?+0x70>
    c6c4:      	movn	w3, #0x0, lsl #16
    c6c8:      	uxtb	w16, w5
    c6cc:      	cmp	w16, wzr
    c6d0:      	b.eq	0xc72c <_stogir.vector-lanes.compatible?+0xd4>
    c6d4:      	uxtb	w16, w6
    c6d8:      	cmp	w16, wzr
    c6dc:      	b.eq	0xc72c <_stogir.vector-lanes.compatible?+0xd4>
    c6e0:      	uxtb	w16, w7
    c6e4:      	cmp	w16, wzr
    c6e8:      	b.eq	0xc72c <_stogir.vector-lanes.compatible?+0xd4>
    c6ec:      	uxtb	w16, w4
    c6f0:      	cmp	w16, wzr
    c6f4:      	b.eq	0xc72c <_stogir.vector-lanes.compatible?+0xd4>
    c6f8:      	sxtw	x0, w2
    c6fc:      	cmp	x0, #0x4
    c700:      	cset	w4, eq
    c704:      	cmp	x0, #0x8
    c708:      	cset	w0, eq
    c70c:      	uxtb	w16, w4
    c710:      	cmp	w16, wzr
    c714:      	b.ne	0xc73c <_stogir.vector-lanes.compatible?+0xe4>
    c718:      	uxtb	w16, w0
    c71c:      	cmp	w16, wzr
    c720:      	b.ne	0xc73c <_stogir.vector-lanes.compatible?+0xe4>
    c724:      	movz	x0, #0x0, lsl #48
    c728:      	b	0xc738 <_stogir.vector-lanes.compatible?+0xe0>
    c72c:      	movz	x0, #0x0, lsl #48
    c730:      	ret
    c734:      	movz	x0, #0x0, lsl #48
    c738:      	b	0xc730 <_stogir.vector-lanes.compatible?+0xd8>
    c73c:      	sxtw	x1, w1
    c740:      	cmp	x1, #0x0
    c744:      	b.lt	0xc734 <_stogir.vector-lanes.compatible?+0xdc>
    c748:      	cmp	x1, #0xd
    c74c:      	b.gt	0xc734 <_stogir.vector-lanes.compatible?+0xdc>
    c750:      	cmp	x1, #0x0
    c754:      	b.le	0xc76c <_stogir.vector-lanes.compatible?+0x114>
    c758:      	sxtw	x3, w3
    c75c:      	cmp	x3, x1
    c760:      	b.ne	0xc774 <_stogir.vector-lanes.compatible?+0x11c>
    c764:      	mov	x0, #0x1                ; =1
    c768:      	b	0xc770 <_stogir.vector-lanes.compatible?+0x118>
    c76c:      	movz	x0, #0x0, lsl #48
    c770:      	b	0xc738 <_stogir.vector-lanes.compatible?+0xe0>
    c774:      	cmp	x3, #0x1
    c778:      	b.lt	0xc7b4 <_stogir.vector-lanes.compatible?+0x15c>
    c77c:      	cmp	x3, #0xb
    c780:      	b.gt	0xc7b4 <_stogir.vector-lanes.compatible?+0x15c>
    c784:      	cmp	x1, #0x1
    c788:      	b.lt	0xc7bc <_stogir.vector-lanes.compatible?+0x164>
    c78c:      	cmp	x1, #0xb
    c790:      	b.gt	0xc7bc <_stogir.vector-lanes.compatible?+0x164>
    c794:      	uxtb	w16, w4
    c798:      	cmp	w16, wzr
    c79c:      	b.ne	0xc7e0 <_stogir.vector-lanes.compatible?+0x188>
    c7a0:      	uxtb	w16, w0
    c7a4:      	cmp	w16, wzr
    c7a8:      	b.ne	0xc7e0 <_stogir.vector-lanes.compatible?+0x188>
    c7ac:      	movn	w3, #0x0, lsl #16
    c7b0:      	b	0xc7f4 <_stogir.vector-lanes.compatible?+0x19c>
    c7b4:      	movz	x0, #0x0, lsl #48
    c7b8:      	b	0xc768 <_stogir.vector-lanes.compatible?+0x110>
    c7bc:      	movz	x0, #0x0, lsl #48
    c7c0:      	b	0xc7b8 <_stogir.vector-lanes.compatible?+0x160>
    c7c4:      	mov	w2, #0x1                ; =1
    c7c8:      	sxtw	x3, w3
    c7cc:      	sxtw	x2, w2
    c7d0:      	cmp	x3, x2
    c7d4:      	cset	w0, eq
    c7d8:      	ubfx	x0, x0, #0, #8
    c7dc:      	b	0xc7c0 <_stogir.vector-lanes.compatible?+0x168>
    c7e0:      	cmp	x3, #0x0
    c7e4:      	b.ne	0xc894 <_stogir.vector-lanes.compatible?+0x23c>
    c7e8:      	movz	w3, #0x0, lsl #16
    c7ec:      	b	0xc7f4 <_stogir.vector-lanes.compatible?+0x19c>
    c7f0:      	mov	w3, #0x1                ; =1
    c7f4:      	uxtb	w16, w4
    c7f8:      	cmp	w16, wzr
    c7fc:      	b.ne	0xc814 <_stogir.vector-lanes.compatible?+0x1bc>
    c800:      	uxtb	w16, w0
    c804:      	cmp	w16, wzr
    c808:      	b.ne	0xc814 <_stogir.vector-lanes.compatible?+0x1bc>
    c80c:      	movn	w2, #0x0, lsl #16
    c810:      	b	0xc7c8 <_stogir.vector-lanes.compatible?+0x170>
    c814:      	cmp	x1, #0x0
    c818:      	b.ne	0xc824 <_stogir.vector-lanes.compatible?+0x1cc>
    c81c:      	movz	w2, #0x0, lsl #16
    c820:      	b	0xc7c8 <_stogir.vector-lanes.compatible?+0x170>
    c824:      	cmp	x1, #0x1
    c828:      	b.eq	0xc7c4 <_stogir.vector-lanes.compatible?+0x16c>
    c82c:      	cmp	x1, #0x2
    c830:      	b.eq	0xc7c4 <_stogir.vector-lanes.compatible?+0x16c>
    c834:      	cmp	x1, #0x7
    c838:      	b.eq	0xc7c4 <_stogir.vector-lanes.compatible?+0x16c>
    c83c:      	cmp	x1, #0x8
    c840:      	b.eq	0xc7c4 <_stogir.vector-lanes.compatible?+0x16c>
    c844:      	cmp	x1, #0x3
    c848:      	b.eq	0xc904 <_stogir.vector-lanes.compatible?+0x2ac>
    c84c:      	cmp	x1, #0x9
    c850:      	b.eq	0xc904 <_stogir.vector-lanes.compatible?+0x2ac>
    c854:      	cmp	x1, #0x4
    c858:      	b.eq	0xc914 <_stogir.vector-lanes.compatible?+0x2bc>
    c85c:      	cmp	x1, #0xa
    c860:      	b.eq	0xc914 <_stogir.vector-lanes.compatible?+0x2bc>
    c864:      	cmp	x1, #0xd
    c868:      	b.eq	0xc914 <_stogir.vector-lanes.compatible?+0x2bc>
    c86c:      	cmp	x1, #0x5
    c870:      	b.eq	0xc924 <_stogir.vector-lanes.compatible?+0x2cc>
    c874:      	cmp	x1, #0xb
    c878:      	b.eq	0xc924 <_stogir.vector-lanes.compatible?+0x2cc>
    c87c:      	cmp	x1, #0xc
    c880:      	b.eq	0xc924 <_stogir.vector-lanes.compatible?+0x2cc>
    c884:      	cmp	x1, #0x6
    c888:      	b.eq	0xc890 <_stogir.vector-lanes.compatible?+0x238>
    c88c:      	movn	w2, #0x0, lsl #16
    c890:      	b	0xc928 <_stogir.vector-lanes.compatible?+0x2d0>
    c894:      	cmp	x3, #0x1
    c898:      	b.eq	0xc7f0 <_stogir.vector-lanes.compatible?+0x198>
    c89c:      	cmp	x3, #0x2
    c8a0:      	b.eq	0xc7f0 <_stogir.vector-lanes.compatible?+0x198>
    c8a4:      	cmp	x3, #0x7
    c8a8:      	b.eq	0xc7f0 <_stogir.vector-lanes.compatible?+0x198>
    c8ac:      	cmp	x3, #0x8
    c8b0:      	b.eq	0xc7f0 <_stogir.vector-lanes.compatible?+0x198>
    c8b4:      	cmp	x3, #0x3
    c8b8:      	b.eq	0xc90c <_stogir.vector-lanes.compatible?+0x2b4>
    c8bc:      	cmp	x3, #0x9
    c8c0:      	b.eq	0xc90c <_stogir.vector-lanes.compatible?+0x2b4>
    c8c4:      	cmp	x3, #0x4
    c8c8:      	b.eq	0xc91c <_stogir.vector-lanes.compatible?+0x2c4>
    c8cc:      	cmp	x3, #0xa
    c8d0:      	b.eq	0xc91c <_stogir.vector-lanes.compatible?+0x2c4>
    c8d4:      	cmp	x3, #0xd
    c8d8:      	b.eq	0xc91c <_stogir.vector-lanes.compatible?+0x2c4>
    c8dc:      	cmp	x3, #0x5
    c8e0:      	b.eq	0xc92c <_stogir.vector-lanes.compatible?+0x2d4>
    c8e4:      	cmp	x3, #0xb
    c8e8:      	b.eq	0xc92c <_stogir.vector-lanes.compatible?+0x2d4>
    c8ec:      	cmp	x3, #0xc
    c8f0:      	b.eq	0xc92c <_stogir.vector-lanes.compatible?+0x2d4>
    c8f4:      	cmp	x3, #0x6
    c8f8:      	b.ne	0xc934 <_stogir.vector-lanes.compatible?+0x2dc>
    c8fc:      	mov	w3, w2
    c900:      	b	0xc938 <_stogir.vector-lanes.compatible?+0x2e0>
    c904:      	mov	w2, #0x2                ; =2
    c908:      	b	0xc7c8 <_stogir.vector-lanes.compatible?+0x170>
    c90c:      	mov	w3, #0x2                ; =2
    c910:      	b	0xc7f4 <_stogir.vector-lanes.compatible?+0x19c>
    c914:      	mov	w2, #0x4                ; =4
    c918:      	b	0xc908 <_stogir.vector-lanes.compatible?+0x2b0>
    c91c:      	mov	w3, #0x4                ; =4
    c920:      	b	0xc910 <_stogir.vector-lanes.compatible?+0x2b8>
    c924:      	mov	w2, #0x8                ; =8
    c928:      	b	0xc918 <_stogir.vector-lanes.compatible?+0x2c0>
    c92c:      	mov	w3, #0x8                ; =8
    c930:      	b	0xc920 <_stogir.vector-lanes.compatible?+0x2c8>
    c934:      	movn	w3, #0x0, lsl #16
    c938:      	b	0xc930 <_stogir.vector-lanes.compatible?+0x2d8>

000000000000c93c <_stogir.vector-comparison.valid-type?>:
    c93c:      	sxtw	x0, w0
    c940:      	cmp	x0, #0xe
    c944:      	b.lt	0xc9dc <_stogir.vector-comparison.valid-type?+0xa0>
    c948:      	cmp	x0, #0x19
    c94c:      	b.gt	0xc9dc <_stogir.vector-comparison.valid-type?+0xa0>
    c950:      	sxtw	x2, w1
    c954:      	cmp	x2, #0xf
    c958:      	cset	w3, gt
    c95c:      	uxtb	w16, w3
    c960:      	cmp	w16, wzr
    c964:      	b.eq	0xc9e4 <_stogir.vector-comparison.valid-type?+0xa8>
    c968:      	cmp	x2, #0x80
    c96c:      	cset	w4, lt
    c970:      	uxtb	w16, w4
    c974:      	cmp	w16, wzr
    c978:      	b.eq	0xc9e4 <_stogir.vector-comparison.valid-type?+0xa8>
    c97c:      	and	w1, w1, #0xf
    c980:      	ubfx	x5, x1, #0, #32
    c984:      	cmp	x5, #0x1
    c988:      	cset	w6, ge
    c98c:      	uxtb	w16, w6
    c990:      	cmp	w16, wzr
    c994:      	b.eq	0xc9e4 <_stogir.vector-comparison.valid-type?+0xa8>
    c998:      	cmp	x5, #0xd
    c99c:      	cset	w5, le
    c9a0:      	uxtb	w16, w5
    c9a4:      	cmp	w16, wzr
    c9a8:      	b.eq	0xc9e4 <_stogir.vector-comparison.valid-type?+0xa8>
    c9ac:      	cmp	x2, #0x0
    c9b0:      	cset	w7, ge
    c9b4:      	cmp	x2, #0xd
    c9b8:      	cset	w2, le
    c9bc:      	uxtb	w16, w7
    c9c0:      	cmp	w16, wzr
    c9c4:      	b.eq	0xc9f4 <_stogir.vector-comparison.valid-type?+0xb8>
    c9c8:      	uxtb	w16, w2
    c9cc:      	cmp	w16, wzr
    c9d0:      	b.eq	0xc9f4 <_stogir.vector-comparison.valid-type?+0xb8>
    c9d4:      	mov	w8, w1
    c9d8:      	b	0xca28 <_stogir.vector-comparison.valid-type?+0xec>
    c9dc:      	movz	x0, #0x0, lsl #48
    c9e0:      	ret
    c9e4:      	movz	x0, #0x0, lsl #48
    c9e8:      	b	0xc9e0 <_stogir.vector-comparison.valid-type?+0xa4>
    c9ec:      	mov	x0, #0x1                ; =1
    c9f0:      	b	0xc9e8 <_stogir.vector-comparison.valid-type?+0xac>
    c9f4:      	uxtb	w16, w3
    c9f8:      	cmp	w16, wzr
    c9fc:      	b.eq	0xca24 <_stogir.vector-comparison.valid-type?+0xe8>
    ca00:      	uxtb	w16, w4
    ca04:      	cmp	w16, wzr
    ca08:      	b.eq	0xca24 <_stogir.vector-comparison.valid-type?+0xe8>
    ca0c:      	uxtb	w16, w6
    ca10:      	cmp	w16, wzr
    ca14:      	b.eq	0xca24 <_stogir.vector-comparison.valid-type?+0xe8>
    ca18:      	uxtb	w16, w5
    ca1c:      	cmp	w16, wzr
    ca20:      	b.ne	0xc9d4 <_stogir.vector-comparison.valid-type?+0x98>
    ca24:      	movn	w8, #0x0, lsl #16
    ca28:      	sxtw	x8, w8
    ca2c:      	cmp	x8, #0xc
    ca30:      	b.eq	0xc9ec <_stogir.vector-comparison.valid-type?+0xb0>
    ca34:      	cmp	x8, #0xd
    ca38:      	b.eq	0xc9ec <_stogir.vector-comparison.valid-type?+0xb0>
    ca3c:      	uxtb	w16, w7
    ca40:      	cmp	w16, wzr
    ca44:      	b.eq	0xca54 <_stogir.vector-comparison.valid-type?+0x118>
    ca48:      	uxtb	w16, w2
    ca4c:      	cmp	w16, wzr
    ca50:      	b.ne	0xca88 <_stogir.vector-comparison.valid-type?+0x14c>
    ca54:      	uxtb	w16, w3
    ca58:      	cmp	w16, wzr
    ca5c:      	b.eq	0xca84 <_stogir.vector-comparison.valid-type?+0x148>
    ca60:      	uxtb	w16, w4
    ca64:      	cmp	w16, wzr
    ca68:      	b.eq	0xca84 <_stogir.vector-comparison.valid-type?+0x148>
    ca6c:      	uxtb	w16, w6
    ca70:      	cmp	w16, wzr
    ca74:      	b.eq	0xca84 <_stogir.vector-comparison.valid-type?+0x148>
    ca78:      	uxtb	w16, w5
    ca7c:      	cmp	w16, wzr
    ca80:      	b.ne	0xca88 <_stogir.vector-comparison.valid-type?+0x14c>
    ca84:      	movn	w1, #0x0, lsl #16
    ca88:      	sxtw	x1, w1
    ca8c:      	cmp	x1, #0x1
    ca90:      	b.lt	0xcaac <_stogir.vector-comparison.valid-type?+0x170>
    ca94:      	cmp	x1, #0xb
    ca98:      	b.gt	0xcaac <_stogir.vector-comparison.valid-type?+0x170>
    ca9c:      	cmp	x0, #0x17
    caa0:      	cset	w0, le
    caa4:      	ubfx	x0, x0, #0, #8
    caa8:      	b	0xcab0 <_stogir.vector-comparison.valid-type?+0x174>
    caac:      	movz	x0, #0x0, lsl #48
    cab0:      	b	0xc9f0 <_stogir.vector-comparison.valid-type?+0xb4>

000000000000cab4 <_stogir.vector-arithmetic.valid-type?>:
    cab4:      	sub	sp, sp, #0x30
    cab8:      	str	x29, [sp]
    cabc:      	str	x30, [sp, #0x8]
    cac0:      	mov	x29, sp
    cac4:      	str	x19, [sp, #0x10]
    cac8:      	str	x20, [sp, #0x18]
    cacc:      	str	x21, [sp, #0x20]
    cad0:      	str	x22, [sp, #0x28]
    cad4:      	sxtw	x2, w1
    cad8:      	and	w1, w1, #0xf
    cadc:      	cmp	x2, #0xf
    cae0:      	cset	w3, gt
    cae4:      	cmp	x2, #0x80
    cae8:      	cset	w4, lt
    caec:      	ubfx	x5, x1, #0, #32
    caf0:      	cmp	x5, #0x1
    caf4:      	cset	w6, ge
    caf8:      	cmp	x5, #0xd
    cafc:      	cset	w5, le
    cb00:      	cmp	x2, #0x0
    cb04:      	b.lt	0xcb10 <_stogir.vector-arithmetic.valid-type?+0x5c>
    cb08:      	cmp	x2, #0xd
    cb0c:      	b.le	0xcb44 <_stogir.vector-arithmetic.valid-type?+0x90>
    cb10:      	uxtb	w16, w3
    cb14:      	cmp	w16, wzr
    cb18:      	b.eq	0xcb40 <_stogir.vector-arithmetic.valid-type?+0x8c>
    cb1c:      	uxtb	w16, w4
    cb20:      	cmp	w16, wzr
    cb24:      	b.eq	0xcb40 <_stogir.vector-arithmetic.valid-type?+0x8c>
    cb28:      	uxtb	w16, w6
    cb2c:      	cmp	w16, wzr
    cb30:      	b.eq	0xcb40 <_stogir.vector-arithmetic.valid-type?+0x8c>
    cb34:      	uxtb	w16, w5
    cb38:      	cmp	w16, wzr
    cb3c:      	b.ne	0xcb44 <_stogir.vector-arithmetic.valid-type?+0x90>
    cb40:      	movn	w1, #0x0, lsl #16
    cb44:      	uxtb	w16, w3
    cb48:      	cmp	w16, wzr
    cb4c:      	b.eq	0xcd34 <_stogir.vector-arithmetic.valid-type?+0x280>
    cb50:      	uxtb	w16, w4
    cb54:      	cmp	w16, wzr
    cb58:      	b.eq	0xcd34 <_stogir.vector-arithmetic.valid-type?+0x280>
    cb5c:      	uxtb	w16, w6
    cb60:      	cmp	w16, wzr
    cb64:      	b.eq	0xcd34 <_stogir.vector-arithmetic.valid-type?+0x280>
    cb68:      	uxtb	w16, w5
    cb6c:      	cmp	w16, wzr
    cb70:      	b.eq	0xcd34 <_stogir.vector-arithmetic.valid-type?+0x280>
    cb74:      	sxtw	x2, w0
    cb78:      	cmp	x2, #0x1f
    cb7c:      	cset	w19, eq
    cb80:      	cmp	x2, #0x20
    cb84:      	cset	w20, eq
    cb88:      	cmp	x2, #0x2e
    cb8c:      	cset	w3, eq
    cb90:      	cmp	x2, #0x2f
    cb94:      	cset	w4, eq
    cb98:      	cmp	x2, #0x30
    cb9c:      	cset	w5, eq
    cba0:      	cmp	x2, #0x1e
    cba4:      	cset	w6, eq
    cba8:      	cmp	x2, #0x31
    cbac:      	cset	w7, ge
    cbb0:      	cmp	x2, #0x35
    cbb4:      	cset	w8, le
    cbb8:      	cmp	x2, #0x3a
    cbbc:      	cset	w9, eq
    cbc0:      	cmp	x2, #0x3b
    cbc4:      	cset	w10, eq
    cbc8:      	cmp	x2, #0x2d
    cbcc:      	cset	w11, eq
    cbd0:      	cmp	x2, #0x36
    cbd4:      	cset	w12, eq
    cbd8:      	cmp	x2, #0x37
    cbdc:      	cset	w13, eq
    cbe0:      	cmp	x2, #0x38
    cbe4:      	cset	w14, eq
    cbe8:      	cmp	x2, #0x39
    cbec:      	cset	w15, eq
    cbf0:      	uxtb	w16, w19
    cbf4:      	cmp	w16, wzr
    cbf8:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cbfc:      	uxtb	w16, w20
    cc00:      	cmp	w16, wzr
    cc04:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc08:      	uxtb	w16, w11
    cc0c:      	cmp	w16, wzr
    cc10:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc14:      	uxtb	w16, w12
    cc18:      	cmp	w16, wzr
    cc1c:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc20:      	uxtb	w16, w13
    cc24:      	cmp	w16, wzr
    cc28:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc2c:      	uxtb	w16, w14
    cc30:      	cmp	w16, wzr
    cc34:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc38:      	uxtb	w16, w15
    cc3c:      	cmp	w16, wzr
    cc40:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc44:      	uxtb	w16, w9
    cc48:      	cmp	w16, wzr
    cc4c:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc50:      	uxtb	w16, w10
    cc54:      	cmp	w16, wzr
    cc58:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    cc5c:      	uxtb	w16, w7
    cc60:      	cmp	w16, wzr
    cc64:      	b.eq	0xce40 <_stogir.vector-arithmetic.valid-type?+0x38c>
    cc68:      	uxtb	w16, w8
    cc6c:      	cmp	w16, wzr
    cc70:      	b.eq	0xce40 <_stogir.vector-arithmetic.valid-type?+0x38c>
    cc74:      	sxtw	x2, w1
    cc78:      	cmp	x2, #0xc
    cc7c:      	cset	w21, eq
    cc80:      	cmp	x2, #0xd
    cc84:      	cset	w22, eq
    cc88:      	uxtb	w16, w19
    cc8c:      	cmp	w16, wzr
    cc90:      	b.ne	0xcd60 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    cc94:      	uxtb	w16, w20
    cc98:      	cmp	w16, wzr
    cc9c:      	b.ne	0xcd60 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    cca0:      	uxtb	w16, w11
    cca4:      	cmp	w16, wzr
    cca8:      	b.ne	0xcd60 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    ccac:      	uxtb	w16, w12
    ccb0:      	cmp	w16, wzr
    ccb4:      	b.ne	0xcd60 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    ccb8:      	uxtb	w16, w13
    ccbc:      	cmp	w16, wzr
    ccc0:      	b.ne	0xcd60 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    ccc4:      	uxtb	w16, w14
    ccc8:      	cmp	w16, wzr
    cccc:      	b.ne	0xcd60 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    ccd0:      	uxtb	w16, w15
    ccd4:      	cmp	w16, wzr
    ccd8:      	b.ne	0xcd60 <_stogir.vector-arithmetic.valid-type?+0x2ac>
    ccdc:      	cmp	x2, #0x1
    cce0:      	cset	w0, eq
    cce4:      	cmp	x2, #0x1
    cce8:      	cset	w1, ge
    ccec:      	cmp	x2, #0xb
    ccf0:      	cset	w2, le
    ccf4:      	uxtb	w16, w7
    ccf8:      	cmp	w16, wzr
    ccfc:      	b.eq	0xcdb0 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    cd00:      	uxtb	w16, w8
    cd04:      	cmp	w16, wzr
    cd08:      	b.eq	0xcdb0 <_stogir.vector-arithmetic.valid-type?+0x2fc>
    cd0c:      	uxtb	w16, w1
    cd10:      	cmp	w16, wzr
    cd14:      	b.eq	0xce38 <_stogir.vector-arithmetic.valid-type?+0x384>
    cd18:      	uxtb	w16, w2
    cd1c:      	cmp	w16, wzr
    cd20:      	b.eq	0xce38 <_stogir.vector-arithmetic.valid-type?+0x384>
    cd24:      	uxtb	w16, w0
    cd28:      	cmp	w16, wzr
    cd2c:      	cset	x0, eq
    cd30:      	b	0xce3c <_stogir.vector-arithmetic.valid-type?+0x388>
    cd34:      	movz	x0, #0x0, lsl #48
    cd38:      	ldr	x19, [sp, #0x10]
    cd3c:      	ldr	x20, [sp, #0x18]
    cd40:      	ldr	x21, [sp, #0x20]
    cd44:      	ldr	x22, [sp, #0x28]
    cd48:      	ldr	x29, [sp]
    cd4c:      	ldr	x30, [sp, #0x8]
    cd50:      	add	sp, sp, #0x30
    cd54:      	ret
    cd58:      	ubfx	x0, x20, #0, #8
    cd5c:      	b	0xcd38 <_stogir.vector-arithmetic.valid-type?+0x284>
    cd60:      	bl	0xcd60 <_stogir.vector-arithmetic.valid-type?+0x2ac>
		000000000000cd60:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    cd64:      	cmp	x0, #0x0
    cd68:      	b.eq	0xcd74 <_stogir.vector-arithmetic.valid-type?+0x2c0>
    cd6c:      	mov	x0, #0x1                ; =1
    cd70:      	b	0xcd5c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    cd74:      	uxtb	w16, w21
    cd78:      	cmp	w16, wzr
    cd7c:      	b.ne	0xcd94 <_stogir.vector-arithmetic.valid-type?+0x2e0>
    cd80:      	uxtb	w16, w22
    cd84:      	cmp	w16, wzr
    cd88:      	b.ne	0xcd94 <_stogir.vector-arithmetic.valid-type?+0x2e0>
    cd8c:      	movz	x0, #0x0, lsl #48
    cd90:      	b	0xcd5c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    cd94:      	uxtb	w16, w19
    cd98:      	cmp	w16, wzr
    cd9c:      	b.eq	0xcd58 <_stogir.vector-arithmetic.valid-type?+0x2a4>
    cda0:      	mov	x0, #0x1                ; =1
    cda4:      	b	0xcd5c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    cda8:      	movz	x0, #0x0, lsl #48
    cdac:      	b	0xcd5c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    cdb0:      	uxtb	w16, w3
    cdb4:      	cmp	w16, wzr
    cdb8:      	b.ne	0xce24 <_stogir.vector-arithmetic.valid-type?+0x370>
    cdbc:      	uxtb	w16, w4
    cdc0:      	cmp	w16, wzr
    cdc4:      	b.ne	0xce24 <_stogir.vector-arithmetic.valid-type?+0x370>
    cdc8:      	uxtb	w16, w5
    cdcc:      	cmp	w16, wzr
    cdd0:      	b.ne	0xce24 <_stogir.vector-arithmetic.valid-type?+0x370>
    cdd4:      	uxtb	w16, w21
    cdd8:      	cmp	w16, wzr
    cddc:      	b.ne	0xce98 <_stogir.vector-arithmetic.valid-type?+0x3e4>
    cde0:      	uxtb	w16, w22
    cde4:      	cmp	w16, wzr
    cde8:      	b.ne	0xce98 <_stogir.vector-arithmetic.valid-type?+0x3e4>
    cdec:      	uxtb	w16, w1
    cdf0:      	cmp	w16, wzr
    cdf4:      	b.eq	0xcea8 <_stogir.vector-arithmetic.valid-type?+0x3f4>
    cdf8:      	uxtb	w16, w2
    cdfc:      	cmp	w16, wzr
    ce00:      	b.eq	0xcea8 <_stogir.vector-arithmetic.valid-type?+0x3f4>
    ce04:      	uxtb	w16, w0
    ce08:      	cmp	w16, wzr
    ce0c:      	b.eq	0xceb0 <_stogir.vector-arithmetic.valid-type?+0x3fc>
    ce10:      	uxtb	w16, w9
    ce14:      	cmp	w16, wzr
    ce18:      	b.eq	0xceb8 <_stogir.vector-arithmetic.valid-type?+0x404>
    ce1c:      	mov	x0, #0x1                ; =1
    ce20:      	b	0xcebc <_stogir.vector-arithmetic.valid-type?+0x408>
    ce24:      	uxtb	w16, w1
    ce28:      	cmp	w16, wzr
    ce2c:      	b.eq	0xcda8 <_stogir.vector-arithmetic.valid-type?+0x2f4>
    ce30:      	ubfx	x0, x2, #0, #8
    ce34:      	b	0xcdac <_stogir.vector-arithmetic.valid-type?+0x2f8>
    ce38:      	movz	x0, #0x0, lsl #48
    ce3c:      	b	0xcdac <_stogir.vector-arithmetic.valid-type?+0x2f8>
    ce40:      	cmp	x2, #0x1a
    ce44:      	b.eq	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce48:      	cmp	x2, #0x1b
    ce4c:      	b.eq	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce50:      	cmp	x2, #0x1c
    ce54:      	b.eq	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce58:      	cmp	x2, #0x1d
    ce5c:      	b.eq	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce60:      	uxtb	w16, w6
    ce64:      	cmp	w16, wzr
    ce68:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce6c:      	uxtb	w16, w3
    ce70:      	cmp	w16, wzr
    ce74:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce78:      	uxtb	w16, w4
    ce7c:      	cmp	w16, wzr
    ce80:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce84:      	uxtb	w16, w5
    ce88:      	cmp	w16, wzr
    ce8c:      	b.ne	0xcc74 <_stogir.vector-arithmetic.valid-type?+0x1c0>
    ce90:      	movz	x0, #0x0, lsl #48
    ce94:      	b	0xcd5c <_stogir.vector-arithmetic.valid-type?+0x2a8>
    ce98:      	uxtb	w16, w6
    ce9c:      	cmp	w16, wzr
    cea0:      	cset	x0, eq
    cea4:      	b	0xcdac <_stogir.vector-arithmetic.valid-type?+0x2f8>
    cea8:      	movz	x0, #0x0, lsl #48
    ceac:      	b	0xcea4 <_stogir.vector-arithmetic.valid-type?+0x3f0>
    ceb0:      	mov	x0, #0x1                ; =1
    ceb4:      	b	0xceac <_stogir.vector-arithmetic.valid-type?+0x3f8>
    ceb8:      	ubfx	x0, x10, #0, #8
    cebc:      	b	0xceb4 <_stogir.vector-arithmetic.valid-type?+0x400>

000000000000cec0 <_stogir.switch.sign-mask>:
    cec0:      	sxtw	x0, w0
    cec4:      	cmp	x0, #0x7
    cec8:      	b.lt	0xcee4 <_stogir.switch.sign-mask+0x24>
    cecc:      	cmp	x0, #0xb
    ced0:      	b.gt	0xcee4 <_stogir.switch.sign-mask+0x24>
    ced4:      	cmp	x0, #0x0
    ced8:      	b.ne	0xcf08 <_stogir.switch.sign-mask+0x48>
    cedc:      	movz	w0, #0x0, lsl #16
    cee0:      	b	0xcef0 <_stogir.switch.sign-mask+0x30>
    cee4:      	movz	x0, #0x0, lsl #48
    cee8:      	ret
    ceec:      	mov	w0, #0x1                ; =1
    cef0:      	lsl	w0, w0, #3
    cef4:      	sub	w0, w0, #0x1
    cef8:      	sxtw	x0, w0
    cefc:      	mov	x16, #0x1               ; =1
    cf00:      	lsl	x0, x16, x0
    cf04:      	b	0xcee8 <_stogir.switch.sign-mask+0x28>
    cf08:      	cmp	x0, #0x1
    cf0c:      	b.eq	0xceec <_stogir.switch.sign-mask+0x2c>
    cf10:      	cmp	x0, #0x2
    cf14:      	b.eq	0xceec <_stogir.switch.sign-mask+0x2c>
    cf18:      	cmp	x0, #0x7
    cf1c:      	b.eq	0xceec <_stogir.switch.sign-mask+0x2c>
    cf20:      	cmp	x0, #0x8
    cf24:      	b.eq	0xceec <_stogir.switch.sign-mask+0x2c>
    cf28:      	cmp	x0, #0x3
    cf2c:      	b.eq	0xcf88 <_stogir.switch.sign-mask+0xc8>
    cf30:      	cmp	x0, #0x9
    cf34:      	b.eq	0xcf88 <_stogir.switch.sign-mask+0xc8>
    cf38:      	cmp	x0, #0x4
    cf3c:      	b.eq	0xcf90 <_stogir.switch.sign-mask+0xd0>
    cf40:      	cmp	x0, #0xa
    cf44:      	b.eq	0xcf90 <_stogir.switch.sign-mask+0xd0>
    cf48:      	cmp	x0, #0xd
    cf4c:      	b.eq	0xcf90 <_stogir.switch.sign-mask+0xd0>
    cf50:      	cmp	x0, #0x5
    cf54:      	b.eq	0xcf98 <_stogir.switch.sign-mask+0xd8>
    cf58:      	cmp	x0, #0xb
    cf5c:      	b.eq	0xcf98 <_stogir.switch.sign-mask+0xd8>
    cf60:      	cmp	x0, #0xc
    cf64:      	b.eq	0xcf98 <_stogir.switch.sign-mask+0xd8>
    cf68:      	cmp	x0, #0x6
    cf6c:      	cset	w0, eq
    cf70:      	uxtb	w16, w0
    cf74:      	cmp	w16, wzr
    cf78:      	mov	w16, #0x8               ; =8
    cf7c:      	movn	w17, #0x0, lsl #16
    cf80:      	csel	w0, w16, w17, ne
    cf84:      	b	0xcf9c <_stogir.switch.sign-mask+0xdc>
    cf88:      	mov	w0, #0x2                ; =2
    cf8c:      	b	0xcef0 <_stogir.switch.sign-mask+0x30>
    cf90:      	mov	w0, #0x4                ; =4
    cf94:      	b	0xcf8c <_stogir.switch.sign-mask+0xcc>
    cf98:      	mov	w0, #0x8                ; =8
    cf9c:      	b	0xcf94 <_stogir.switch.sign-mask+0xd4>
