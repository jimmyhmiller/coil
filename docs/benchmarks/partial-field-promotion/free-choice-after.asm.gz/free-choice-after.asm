
build/partial-field-comparison/emitter/stogir-after.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000001b6c8 <_stogir.allocation.free-decision-for-class>:
   1b6c8: d10203ff     	sub	sp, sp, #0x80
   1b6cc: f90003fd     	str	x29, [sp]
   1b6d0: f90007fe     	str	x30, [sp, #0x8]
   1b6d4: 910003fd     	mov	x29, sp
   1b6d8: f90017f3     	str	x19, [sp, #0x28]
   1b6dc: f9001bf4     	str	x20, [sp, #0x30]
   1b6e0: f9001ff5     	str	x21, [sp, #0x38]
   1b6e4: f90023f6     	str	x22, [sp, #0x40]
   1b6e8: f90027f7     	str	x23, [sp, #0x48]
   1b6ec: f9002bf8     	str	x24, [sp, #0x50]
   1b6f0: f9002ff9     	str	x25, [sp, #0x58]
   1b6f4: f90033fa     	str	x26, [sp, #0x60]
   1b6f8: f90037fb     	str	x27, [sp, #0x68]
   1b6fc: f9003bfc     	str	x28, [sp, #0x70]
   1b700: 910043a8     	add	x8, x29, #0x10
   1b704: 9100a009     	add	x9, x0, #0x28
   1b708: f940042a     	ldr	x10, [x1, #0x8]
   1b70c: f9402c0b     	ldr	x11, [x0, #0x58]
   1b710: f940052c     	ldr	x12, [x9, #0x8]
   1b714: d2e0000d     	movz	x13, #0x0, lsl #48
   1b718: 14000003     	b	0x1b724 <_stogir.allocation.free-decision-for-class+0x5c>
   1b71c: d503201f     	nop
   1b720: aa0e03ec     	mov	x12, x14
   1b724: eb0c01bf     	cmp	x13, x12
   1b728: 540001ca     	b.ge	0x1b760 <_stogir.allocation.free-decision-for-class+0x98>
   1b72c: cb0d018e     	sub	x14, x12, x13
   1b730: f940140f     	ldr	x15, [x0, #0x28]
   1b734: 937ffdd0     	asr	x16, x14, #63
   1b738: d37ffe10     	lsr	x16, x16, #63
   1b73c: 8b1001ce     	add	x14, x14, x16
   1b740: 9341fdce     	asr	x14, x14, #1
   1b744: 8b0d01ce     	add	x14, x14, x13
   1b748: 8b0e11ef     	add	x15, x15, x14, lsl #4
   1b74c: f94001ef     	ldr	x15, [x15]
   1b750: eb0201ff     	cmp	x15, x2
   1b754: 54fffe6a     	b.ge	0x1b720 <_stogir.allocation.free-decision-for-class+0x58>
   1b758: 910005cd     	add	x13, x14, #0x1
   1b75c: 17fffff2     	b	0x1b724 <_stogir.allocation.free-decision-for-class+0x5c>
   1b760: f940052c     	ldr	x12, [x9, #0x8]
   1b764: eb0c01bf     	cmp	x13, x12
   1b768: 540001ea     	b.ge	0x1b7a4 <_stogir.allocation.free-decision-for-class+0xdc>
   1b76c: f940140c     	ldr	x12, [x0, #0x28]
   1b770: 8b0d118e     	add	x14, x12, x13, lsl #4
   1b774: f94001ce     	ldr	x14, [x14]
   1b778: eb0201df     	cmp	x14, x2
   1b77c: 54000141     	b.ne	0x1b7a4 <_stogir.allocation.free-decision-for-class+0xdc>
   1b780: 8b0d118e     	add	x14, x12, x13, lsl #4
   1b784: f94005ce     	ldr	x14, [x14, #0x8]
   1b788: 93407dce     	sxtw	x14, w14
   1b78c: f10009df     	cmp	x14, #0x2
   1b790: 540000a1     	b.ne	0x1b7a4 <_stogir.allocation.free-decision-for-class+0xdc>
   1b794: 8b0d118c     	add	x12, x12, x13, lsl #4
   1b798: f940058c     	ldr	x12, [x12, #0x8]
   1b79c: 9360fd8c     	asr	x12, x12, #32
   1b7a0: 14000002     	b	0x1b7a8 <_stogir.allocation.free-decision-for-class+0xe0>
   1b7a4: 92e0000c     	movn	x12, #0x0, lsl #48
   1b7a8: f940040d     	ldr	x13, [x0, #0x8]
   1b7ac: f10001bf     	cmp	x13, #0x0
   1b7b0: 54000061     	b.ne	0x1b7bc <_stogir.allocation.free-decision-for-class+0xf4>
   1b7b4: aa0203ed     	mov	x13, x2
   1b7b8: 14000005     	b	0x1b7cc <_stogir.allocation.free-decision-for-class+0x104>
   1b7bc: f940000e     	ldr	x14, [x0]
   1b7c0: d10005ad     	sub	x13, x13, #0x1
   1b7c4: 8b0d11cd     	add	x13, x14, x13, lsl #4
   1b7c8: f94005ad     	ldr	x13, [x13, #0x8]
   1b7cc: 910003ee     	mov	x14, sp
   1b7d0: d10043ff     	sub	sp, sp, #0x10
   1b7d4: 910003ef     	mov	x15, sp
   1b7d8: d2e00013     	movz	x19, #0x0, lsl #48
   1b7dc: d2e00014     	movz	x20, #0x0, lsl #48
   1b7e0: d2e00015     	movz	x21, #0x0, lsl #48
   1b7e4: d29ffff6     	mov	x22, #0xffff            ; =65535
   1b7e8: f2bffff6     	movk	x22, #0xffff, lsl #16
   1b7ec: 92f00017     	mov	x23, #0x7fffffffffffffff ; =9223372036854775807
   1b7f0: 92f00018     	mov	x24, #0x7fffffffffffffff ; =9223372036854775807
   1b7f4: 14000008     	b	0x1b814 <_stogir.allocation.free-decision-for-class+0x14c>
   1b7f8: 92607ed5     	and	x21, x22, #0xffffffff00000000
   1b7fc: d360ff36     	lsr	x22, x25, #32
   1b800: d3407ed6     	ubfx	x22, x22, #0, #32
   1b804: ca1602b6     	eor	x22, x21, x22
   1b808: aa1b03f7     	mov	x23, x27
   1b80c: d2800035     	mov	x21, #0x1               ; =1
   1b810: 91000673     	add	x19, x19, #0x1
   1b814: f9400539     	ldr	x25, [x9, #0x8]
   1b818: 2a1f02da     	orr	w26, w22, wzr
   1b81c: 93407f5a     	sxtw	x26, w26
   1b820: eb19027f     	cmp	x19, x25
   1b824: 5400034a     	b.ge	0x1b88c <_stogir.allocation.free-decision-for-class+0x1c4>
   1b828: f100029f     	cmp	x20, #0x0
   1b82c: 54000301     	b.ne	0x1b88c <_stogir.allocation.free-decision-for-class+0x1c4>
   1b830: f9401419     	ldr	x25, [x0, #0x28]
   1b834: 8b131339     	add	x25, x25, x19, lsl #4
   1b838: f940033b     	ldr	x27, [x25]
   1b83c: f9400739     	ldr	x25, [x25, #0x8]
   1b840: f90001fb     	str	x27, [x15]
   1b844: f90005f9     	str	x25, [x15, #0x8]
   1b848: eb02037f     	cmp	x27, x2
   1b84c: 54fffe2b     	b.lt	0x1b810 <_stogir.allocation.free-decision-for-class+0x148>
   1b850: 2a1f033c     	orr	w28, w25, wzr
   1b854: 93407f9c     	sxtw	x28, w28
   1b858: f1000b9f     	cmp	x28, #0x2
   1b85c: 54fffda1     	b.ne	0x1b810 <_stogir.allocation.free-decision-for-class+0x148>
   1b860: 92f00011     	mov	x17, #0x7fffffffffffffff ; =9223372036854775807
   1b864: eb11037f     	cmp	x27, x17
   1b868: 54fffd40     	b.eq	0x1b810 <_stogir.allocation.free-decision-for-class+0x148>
   1b86c: f10002bf     	cmp	x21, #0x0
   1b870: 54fffc40     	b.eq	0x1b7f8 <_stogir.allocation.free-decision-for-class+0x130>
   1b874: 9360ff39     	asr	x25, x25, #32
   1b878: eb1a033f     	cmp	x25, x26
   1b87c: 54000060     	b.eq	0x1b888 <_stogir.allocation.free-decision-for-class+0x1c0>
   1b880: aa1b03f8     	mov	x24, x27
   1b884: d2800034     	mov	x20, #0x1               ; =1
   1b888: 17ffffe2     	b	0x1b810 <_stogir.allocation.free-decision-for-class+0x148>
   1b88c: 8a030163     	and	x3, x11, x3
   1b890: 93407d8c     	sxtw	x12, w12
   1b894: 910001df     	mov	sp, x14
   1b898: f100019f     	cmp	x12, #0x0
   1b89c: 5400010b     	b.lt	0x1b8bc <_stogir.allocation.free-decision-for-class+0x1f4>
   1b8a0: f101019f     	cmp	x12, #0x40
   1b8a4: 540000aa     	b.ge	0x1b8b8 <_stogir.allocation.free-decision-for-class+0x1f0>
   1b8a8: d2800030     	mov	x16, #0x1               ; =1
   1b8ac: 9acc2209     	lsl	x9, x16, x12
   1b8b0: 8a030123     	and	x3, x9, x3
   1b8b4: 14000002     	b	0x1b8bc <_stogir.allocation.free-decision-for-class+0x1f4>
   1b8b8: d2e00003     	movz	x3, #0x0, lsl #48
   1b8bc: 93407c84     	sxtw	x4, w4
   1b8c0: aa0203f3     	mov	x19, x2
   1b8c4: aa0203eb     	mov	x11, x2
   1b8c8: aa0203ee     	mov	x14, x2
   1b8cc: d29fffe9     	mov	x9, #0xffff             ; =65535
   1b8d0: f2bfffe9     	movk	x9, #0xffff, lsl #16
   1b8d4: d29fffec     	mov	x12, #0xffff            ; =65535
   1b8d8: f2bfffec     	movk	x12, #0xffff, lsl #16
   1b8dc: d29fffef     	mov	x15, #0xffff            ; =65535
   1b8e0: f2bfffef     	movk	x15, #0xffff, lsl #16
   1b8e4: 1400003a     	b	0x1b9cc <_stogir.allocation.free-decision-for-class+0x304>
   1b8e8: aa1703f6     	mov	x22, x23
   1b8ec: eb16029f     	cmp	x20, x22
   1b8f0: 9a96d294     	csel	x20, x20, x22, le
   1b8f4: eb0d029f     	cmp	x20, x13
   1b8f8: 54000c6a     	b.ge	0x1ba84 <_stogir.allocation.free-decision-for-class+0x3bc>
   1b8fc: f90013a1     	str	x1, [x29, #0x20]
   1b900: aa0703fb     	mov	x27, x7
   1b904: d2e00016     	movz	x22, #0x0, lsl #48
   1b908: 14000003     	b	0x1b914 <_stogir.allocation.free-decision-for-class+0x24c>
   1b90c: d503201f     	nop
   1b910: aa1c03fb     	mov	x27, x28
   1b914: eb1b02df     	cmp	x22, x27
   1b918: 5400018a     	b.ge	0x1b948 <_stogir.allocation.free-decision-for-class+0x280>
   1b91c: cb16037c     	sub	x28, x27, x22
   1b920: 937fff90     	asr	x16, x28, #63
   1b924: d37ffe10     	lsr	x16, x16, #63
   1b928: 8b10039c     	add	x28, x28, x16
   1b92c: 9341ff9c     	asr	x28, x28, #1
   1b930: 8b16039c     	add	x28, x28, x22
   1b934: f87c78c1     	ldr	x1, [x6, x28, lsl #3]
   1b938: eb14003f     	cmp	x1, x20
   1b93c: 54fffeaa     	b.ge	0x1b910 <_stogir.allocation.free-decision-for-class+0x248>
   1b940: 91000796     	add	x22, x28, #0x1
   1b944: 17fffff4     	b	0x1b914 <_stogir.allocation.free-decision-for-class+0x24c>
   1b948: eb0702df     	cmp	x22, x7
   1b94c: 5400008a     	b.ge	0x1b95c <_stogir.allocation.free-decision-for-class+0x294>
   1b950: f87678c1     	ldr	x1, [x6, x22, lsl #3]
   1b954: eb14003f     	cmp	x1, x20
   1b958: 540000a0     	b.eq	0x1b96c <_stogir.allocation.free-decision-for-class+0x2a4>
   1b95c: aa1f0281     	orr	x1, x20, xzr
   1b960: 9ac50c30     	sdiv	x16, x1, x5
   1b964: 9b058601     	msub	x1, x16, x5, x1
   1b968: cb010294     	sub	x20, x20, x1
   1b96c: d3407eb5     	ubfx	x21, x21, #0, #32
   1b970: d2e00010     	movz	x16, #0x0, lsl #48
   1b974: ca150201     	eor	x1, x16, x21
   1b978: eb13029f     	cmp	x20, x19
   1b97c: 5400006d     	b.le	0x1b988 <_stogir.allocation.free-decision-for-class+0x2c0>
   1b980: aa1403f3     	mov	x19, x20
   1b984: aa0103ef     	mov	x15, x1
   1b988: eb02029f     	cmp	x20, x2
   1b98c: 540001ad     	b.le	0x1b9c0 <_stogir.allocation.free-decision-for-class+0x2f8>
   1b990: eb0d029f     	cmp	x20, x13
   1b994: 5400016b     	b.lt	0x1b9c0 <_stogir.allocation.free-decision-for-class+0x2f8>
   1b998: b9407015     	ldr	w21, [x0, #0x70]
   1b99c: 93407eb5     	sxtw	x21, w21
   1b9a0: eb15033f     	cmp	x25, x21
   1b9a4: 54000061     	b.ne	0x1b9b0 <_stogir.allocation.free-decision-for-class+0x2e8>
   1b9a8: aa0103e9     	mov	x9, x1
   1b9ac: aa1403eb     	mov	x11, x20
   1b9b0: eb04033f     	cmp	x25, x4
   1b9b4: 54000061     	b.ne	0x1b9c0 <_stogir.allocation.free-decision-for-class+0x2f8>
   1b9b8: aa0103ec     	mov	x12, x1
   1b9bc: aa1403ee     	mov	x14, x20
   1b9c0: d1000461     	sub	x1, x3, #0x1
   1b9c4: 8a030023     	and	x3, x1, x3
   1b9c8: f94013a1     	ldr	x1, [x29, #0x20]
   1b9cc: f100007f     	cmp	x3, #0x0
   1b9d0: 540001a0     	b.eq	0x1ba04 <_stogir.allocation.free-decision-for-class+0x33c>
   1b9d4: dac00074     	rbit	x20, x3
   1b9d8: dac01294     	clz	x20, x20
   1b9dc: eb0a029f     	cmp	x20, x10
   1b9e0: 5400056a     	b.ge	0x1ba8c <_stogir.allocation.free-decision-for-class+0x3c4>
   1b9e4: 2a1f0295     	orr	w21, w20, wzr
   1b9e8: f9400036     	ldr	x22, [x1]
   1b9ec: 93407eb9     	sxtw	x25, w21
   1b9f0: f8747ad4     	ldr	x20, [x22, x20, lsl #3]
   1b9f4: eb1a033f     	cmp	x25, x26
   1b9f8: 54fff781     	b.ne	0x1b8e8 <_stogir.allocation.free-decision-for-class+0x220>
   1b9fc: aa1803f6     	mov	x22, x24
   1ba00: 17ffffbb     	b	0x1b8ec <_stogir.allocation.free-decision-for-class+0x224>
   1ba04: 2a1f0120     	orr	w0, w9, wzr
   1ba08: 93407c00     	sxtw	x0, w0
   1ba0c: f100001f     	cmp	x0, #0x0
   1ba10: 5400008b     	b.lt	0x1ba20 <_stogir.allocation.free-decision-for-class+0x358>
   1ba14: aa0903ef     	mov	x15, x9
   1ba18: aa0b03f3     	mov	x19, x11
   1ba1c: 14000007     	b	0x1ba38 <_stogir.allocation.free-decision-for-class+0x370>
   1ba20: 2a1f0180     	orr	w0, w12, wzr
   1ba24: 93407c00     	sxtw	x0, w0
   1ba28: f100001f     	cmp	x0, #0x0
   1ba2c: 5400006b     	b.lt	0x1ba38 <_stogir.allocation.free-decision-for-class+0x370>
   1ba30: aa0c03ef     	mov	x15, x12
   1ba34: aa0e03f3     	mov	x19, x14
   1ba38: f900010f     	str	x15, [x8]
   1ba3c: f9000513     	str	x19, [x8, #0x8]
   1ba40: f9400ba0     	ldr	x0, [x29, #0x10]
   1ba44: f9400fa1     	ldr	x1, [x29, #0x18]
   1ba48: d10003bf     	sub	sp, x29, #0x0
   1ba4c: f94017f3     	ldr	x19, [sp, #0x28]
   1ba50: f9401bf4     	ldr	x20, [sp, #0x30]
   1ba54: f9401ff5     	ldr	x21, [sp, #0x38]
   1ba58: f94023f6     	ldr	x22, [sp, #0x40]
   1ba5c: f94027f7     	ldr	x23, [sp, #0x48]
   1ba60: f9402bf8     	ldr	x24, [sp, #0x50]
   1ba64: f9402ff9     	ldr	x25, [sp, #0x58]
   1ba68: f94033fa     	ldr	x26, [sp, #0x60]
   1ba6c: f94037fb     	ldr	x27, [sp, #0x68]
   1ba70: f9403bfc     	ldr	x28, [sp, #0x70]
   1ba74: f94003fd     	ldr	x29, [sp]
   1ba78: f94007fe     	ldr	x30, [sp, #0x8]
   1ba7c: 910203ff     	add	sp, sp, #0x80
   1ba80: d65f03c0     	ret
   1ba84: f90013a1     	str	x1, [x29, #0x20]
   1ba88: 17ffffb9     	b	0x1b96c <_stogir.allocation.free-decision-for-class+0x2a4>
   1ba8c: f90013a1     	str	x1, [x29, #0x20]
   1ba90: 17ffffcc     	b	0x1b9c0 <_stogir.allocation.free-decision-for-class+0x2f8>
